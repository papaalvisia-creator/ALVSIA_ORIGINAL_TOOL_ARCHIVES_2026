-- !!! DO NOT MODIFY THIS FILE. !!!
-- AUTO GENERATE BY pubgm_patch.py 2026-11-11 11:24:19
global_patch_make_time = "" ..
"Patch Version : 4.7.0.21756\n" ..
"Mode : TAPD\n" ..
"Branch : Release4.7.0\n" ..
"Git Engine : 85c8c9418653e0138b69c48c4eef0611996a4f12\n" ..
"Git Survive : 6a97e519d923143519569ff4f32b8d031f8d5a57\n" ..
"Git Lua : 0c094178ab032c4da9eef49b154837981b04f271\n" ..
"SVN Xls : 1704877\n" ..
"P4 Content : 995904\n" ..
"BuildNo : #1\n" ..
"HostName : PUBGM-VPC68\n" ..
"Mfg. Date : 2026-11-11 11:24:19\n" ..
"Pipeline : #p-cc3b4324542f4168a9a0638d1266cb56\n"

global_patch_make_time_map = {
    ["Patch Version"] = "4.7.0.21756",
    ["Mode"] = "TAPD",
    ["Branch"] = "Release4.7.0",
    ["Git Engine"] = "85c8c9418653e0138b69c48c4eef0611996a4f12",
    ["Git Survive"] = "6a97e519d923143519569ff4f32b8d031f8d5a57",
    ["Git Lua"] = "0c094178ab032c4da9eef49b154837981b04f271",
    ["SVN Xls"] = "1704877",
    ["P4 Content"] = "995904",
    ["Pipeline"] =  "p-cc3b4324542f4168a9a0638d1266cb56",
    ["BuildNo"] =  "#1",
    ["HostName"] = "PUBGM-VPC68",
    ["Mfg. Date"] = "2026-11-11 11:24:19",
}

global_patch_tss = "0bc9cxxOwJk6WpiNNzr1DQ=="
