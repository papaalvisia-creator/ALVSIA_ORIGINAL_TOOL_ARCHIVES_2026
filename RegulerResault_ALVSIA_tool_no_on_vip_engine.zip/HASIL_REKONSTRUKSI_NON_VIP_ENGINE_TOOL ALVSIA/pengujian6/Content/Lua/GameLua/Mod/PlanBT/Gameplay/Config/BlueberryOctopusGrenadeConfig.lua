local BlueberryOctopusGrenadeConfig = {
  ItemID = 602603,
  SkillID = 602603,
  BuffID = 450911,
  FuseTime = 6,
  ExplosionRadius = 800,
  InkDuration = 6.0,
  ExcludeThrower = false,
  LineOfSight = {
    Enable = true,
    TraceChannelName = "ECC_Pawn",
    CollisionFreeRadius = 50,
    DebugDrawSeconds = 0
  },
  WeaponBPPath = "/Game/Mod/PlanBT/Arts_PlayerBluePrints/Weapon/BlueberryOctopus/BP_Grenade_BlueberryOctopus_Weapon.BP_Grenade_BlueberryOctopus_Weapon_C",
  ExplodeVFXPath = "/Game/Mod/PlanBT/Arts_Effect/Par/P_PLanBT_OctopusGrenade_Splash_L3.P_PLanBT_OctopusGrenade_Splash_L3",
  ExplodeSFXPath = "/Game/Mod/PlanBT/WwiseEvent/PlanBT_OctopusGrenade_450/Play_PlanBT_OctopusGrenade_Explo.Play_PlanBT_OctopusGrenade_Explo",
  InkScreenEffectBPPath = "/Game/Mod/PlanBT/BluePrints/ScreenAppearance/BP_OctopusScreenEffect1.BP_OctopusScreenEffect1_C",
  InkAvatarMaterialPath = "/Game/Res/IG4500/Arts_Player/Characters/Materials/M_CharacterPBR_ChangeableColor.M_CharacterPBR_ChangeableColor",
  InkParamName = "IsInk",
  InkFadeOutDuration = 1.0,
  InkFadeOutTickInterval = 0.033,
  InkTintParamName = {
    "TintColor",
    "TintColor_Low"
  },
  InkTintColor = {
    R = 0.0,
    G = 0.0,
    B = 0.0,
    A = 1.0
  },
  InkOriginalColorParamName = "\233\162\156\232\137\178",
  InkScreenEffectName = "PlanBT_InkHit"
}
return BlueberryOctopusGrenadeConfig
