﻿--- A PrimitiveComponent owns collision geometry and may participate in scene queries, overlap/hit events, and rigid-body simulation. Collision settings, overlap generation, and physics simulation are independent controls: configure all controls required by the intended behavior. Positions use cm, linear velocities use cm/s, and angular velocities exposed here use degrees/s.
--- [Notice] This API is Class API. Categorized by type hierarchy. Provides direct access to programming objects in the editor. Suitable for advanced development.
--- [Notice] This API is under controlled access. Its functionality and parameters may change in future versions. Please be aware before using.
--- @realm Both This class is exposed in both the Server-side and Client-side sandbox VMs (shared class). Individual fields or methods on this class may still further restrict their availability to a single realm; check the per-member [ServerOnly]/[ClientOnly]/[Both] tag and @realm annotation before use.
---@class WoWPrimitiveComponentBase:WoWSceneComponentBase
---@field CanCharacterStepUpOn CanBeCharacterBase [Both] Whether Characters may step up onto this component or use it as their movement base. ECB_No blocks stepping up and makes standing Characters slide off; ECB_Yes allows both; ECB_Owner defers to the owning Actor. This property is NOT replicated and is used by client-predicted Character movement, so set the same value on both Server and every Client; otherwise movement corrections (rubber-banding) occur.
---@field OnComponentBeginOverlap function(OverlappedComponent:WoWPrimitiveComponentBase, OtherActor:WoWActorBase, OtherComp:WoWPrimitiveComponentBase, OtherBodyIndex:integer, bFromSweep:boolean, SweepResult:FHitResult) [Both] [ReadOnly] Register through AddEnvControlEvent to handle a newly tracked overlap. OverlappedComponent is this component; OtherActor and OtherComp identify the other object; OtherBodyIndex identifies its body. bFromSweep is true when swept movement created the overlap, in which case SweepResult contains useful contact data. Registration alone does not configure collision.
---@field OnComponentEndOverlap function(OverlappedComponent:WoWPrimitiveComponentBase, OtherActor:WoWActorBase, OtherComp:WoWPrimitiveComponentBase, OtherBodyIndex:integer) [Both] [ReadOnly] Register through AddEnvControlEvent to handle the end of a previously tracked overlap. The parameters identify this component, the other Actor/component, and the other body's index. Disabling collision, overlap generation, or changing responses can also end an existing overlap.
---@field OnComponentHit function(HitComponent:WoWPrimitiveComponentBase, OtherActor:WoWActorBase, OtherComp:WoWPrimitiveComponentBase, NormalImpulse:FVector, Hit:FHitResult) [Both] [ReadOnly] Register through AddEnvControlEvent to handle blocking contact from swept movement, Character movement, or physics simulation. This requires a Block response rather than Overlap. Physics-simulation contacts additionally require Simulation Generates Hit Events; swept blocking hits do not. NormalImpulse is normally zero for swept hits and populated for simulated-body contacts.
---@field bGenerateOverlapEvents boolean [Both] Enable maintenance of overlap state and Begin/EndOverlap events for this component. Both components must enable this flag, use QueryOnly or QueryAndPhysics collision, and resolve their channel responses to Overlap. This flag does not perform an immediate world query, and registering a callback does not configure collision.
local WoWPrimitiveComponentBase = {}

--- ============ Methods ============

--- Apply a world-space force to one rigid body. Call every frame while the force should act; do not multiply Force by DeltaTime. The target body must simulate physics. This call executes only in the current realm and does not itself send an RPC.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@param Force FVector World-space force vector; with default Unreal units, values represent kg*cm/s^2.
---@param BoneName string Optional SkeletalMesh body name; use "None" or omit it for the root body.
---@param bAccelChange boolean Optional. True treats Force as acceleration so mass has no effect; defaults to false.
function WoWPrimitiveComponentBase:AddForce(Force, BoneName, bAccelChange) end

--- Apply a world-space force at a world-space point on one rigid body. Call every frame while the force should act; do not multiply Force by DeltaTime. Applying the force away from the center of mass also creates torque. The target body must simulate physics.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@param Force FVector World-space force vector; with default Unreal units, values represent kg*cm/s^2.
---@param Location FVector World-space application point in cm; this determines the torque generated by the force.
---@param BoneName string Optional SkeletalMesh body name; use "None" or omit it for the root body.
function WoWPrimitiveComponentBase:AddForceAtLocation(Force, Location, BoneName) end

--- Add an Actor to this component's movement-ignore list. All components owned by that Actor are skipped when this component performs swept movement and updates movement overlaps. This does not globally disable collision, simulated-physics contact, or unrelated traces, and the relationship is directional. Client changes are local; Server uses the creative replicated setter when available.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@param InActor WoWActorBase Valid Actor whose owned components should be ignored by this component's movement queries.
function WoWPrimitiveComponentBase:AddIgnoreActor(InActor) end

--- Add one component to this component's movement-ignore list. It is skipped when this component performs swept movement and updates movement overlaps; this does not disable physics-simulation contact or unrelated traces. The relationship is directional, so the other component may need a matching entry when it also moves. Client changes are local; Server uses the creative replicated setter when available.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@param InComponent PrimitiveComponent Valid PrimitiveComponent to ignore when this component performs movement queries.
function WoWPrimitiveComponentBase:AddIgnoreComponent(InComponent) end

--- Apply a one-time world-space impulse to one rigid body, for example a jump, recoil, or impact. Call once per event rather than every frame. The target body must simulate physics. This call executes only in the current realm and does not itself send an RPC.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@param Impulse FVector World-space impulse vector; with default Unreal units, values represent kg*cm/s.
---@param BoneName string Optional SkeletalMesh body name; use "None" or omit it for the root body.
---@param bVelChange boolean Optional. True treats Impulse as a direct velocity change so mass has no effect; defaults to false.
function WoWPrimitiveComponentBase:AddImpulse(Impulse, BoneName, bVelChange) end

--- Apply a one-time outward impulse from a world-space origin to this component's simulated body or bodies inside Radius. Use for explosion-like effects and call once per event. This does not search for or affect other components in the world. The call executes only in the current realm.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@param Origin FVector World-space center of the radial impulse, in cm.
---@param Radius number Maximum effect radius in cm; bodies outside it receive no impulse.
---@param Strength number Impulse strength at the origin, interpreted according to bVelChange.
---@param Falloff ERadialImpulseFalloff RIF_Constant for equal strength inside Radius, or RIF_Linear to decrease strength with distance.
---@param bVelChange boolean Optional. True applies Strength as a mass-independent velocity change; defaults to false.
function WoWPrimitiveComponentBase:AddRadialImpulse(Origin, Radius, Strength, Falloff, bVelChange) end

--- Return this component's object channel. Other components use this value to select their response to this component. This reads collision configuration and does not perform a scene query.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@return ECollisionChannel Current object channel, such as ECC_WorldDynamic or ECC_Pawn.
function WoWPrimitiveComponentBase:GetCollisionObjectType() end

--- Return the collision profile name stored on this component. This reads configuration and performs no world query. Later per-channel changes may make the effective settings differ from the original profile preset.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@return string Stored profile name; effective per-channel settings may have been changed afterwards.
function WoWPrimitiveComponentBase:GetCollisionProfileName() end

--- Read this component's configured response to one object channel. This does not query the world or calculate the final interaction with a particular component, because that result also depends on the other component's response.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@param Channel ECollisionChannel Object channel whose configured response will be read.
---@return ECollisionResponse Configured ECR_Ignore, ECR_Overlap, or ECR_Block response.
function WoWPrimitiveComponentBase:GetCollisionResponseToChannel(Channel) end

--- Return the unique Actors represented by this component's currently tracked overlaps. This reads maintained overlap state rather than performing a fresh geometry query, so results depend on query collision, bGenerateOverlapEvents on both sides, compatible channel responses, and prior overlap updates.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@return WoWActorBase[] Unique currently overlapping Actors; an Actor appears once even when several owned components overlap. Empty when none are tracked.
function WoWPrimitiveComponentBase:GetOverlappingActors() end

--- Return the unique PrimitiveComponents in this component's currently tracked overlaps. This is not a fresh world query and does not discover contacts for which overlap generation was disabled.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@return WoWPrimitiveComponentBase[] Unique currently overlapping PrimitiveComponents; empty when none are tracked.
function WoWPrimitiveComponentBase:GetOverlappingComponents() end

--- Return one rigid body's current world-space angular velocity in degrees per second.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@param BoneName string Optional SkeletalMesh body name; use "None" or omit it for the root body.
---@return FVector Angular velocity around the world X/Y/Z axes, in degrees/s.
function WoWPrimitiveComponentBase:GetPhysicsAngularVelocityInDegrees(BoneName) end

--- Return one rigid body's current world-space linear velocity. This reads physics state and does not predict future movement.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@param BoneName string Optional SkeletalMesh body name; use "None" or omit it for the root body.
---@return FVector World-space linear velocity in cm/s; zero when no matching body is available.
function WoWPrimitiveComponentBase:GetPhysicsLinearVelocity(BoneName) end

--- Check whether maintained overlap state contains at least one component owned by Other. This does not perform a new collision query, so false can also mean overlap generation or collision responses were not configured.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@param Other WoWActorBase Actor whose owned components will be checked in the tracked overlap set.
---@return boolean True when at least one active overlap with a component owned by Other is tracked.
function WoWPrimitiveComponentBase:IsOverlappingActor(Other) end

--- Remove the first matching Actor from this component's movement-ignore list, restoring normal movement-query handling against its components. This does not modify collision channels or simulated-physics contacts. Repeated additions may require repeated removals. Client changes are local; Server uses the creative replicated setter when available.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@param InActor WoWActorBase Valid Actor whose movement-ignore entry will be removed.
function WoWPrimitiveComponentBase:RemoveIgnoreActor(InActor) end

--- Remove the first matching component from this component's movement-ignore list, restoring normal movement-query handling. This does not change collision channels or simulated-physics contacts. Because AddIgnoreComponent permits duplicates, repeated additions may require repeated removals. Client changes are local; Server uses the creative replicated setter when available.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@param InComponent PrimitiveComponent Valid PrimitiveComponent whose movement-ignore entry will be removed.
function WoWPrimitiveComponentBase:RemoveIgnoreComponent(InComponent) end

--- Choose which collision systems use this component. NoCollision disables queries and physics collision; QueryOnly supports traces, sweeps, and overlaps; PhysicsOnly supports rigid-body collision but not queries; QueryAndPhysics supports both. Changing the mode may begin or end tracked overlaps. Client calls are local; Server uses the creative setter when available so the state can replicate.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@param NewType CollisionEnabled NoCollision, QueryOnly, PhysicsOnly, or QueryAndPhysics. Traces and overlap events require a query-capable mode.
function WoWPrimitiveComponentBase:SetCollisionEnabled(NewType) end

--- Apply an existing project collision profile. The profile replaces collision-enabled mode, object type, and all per-channel responses, so call per-channel setters afterwards when custom overrides are needed. Applying a profile may begin or end tracked overlaps. Client calls are local; Server uses the creative setter when available so the state can replicate.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@param InCollisionProfileName InCollisionProfileName Name of a collision profile defined by the project, mapped through InCollisionProfileName.
function WoWPrimitiveComponentBase:SetCollisionProfileName(InCollisionProfileName) end

--- Set how this component responds to objects of one collision channel. Unreal combines both objects' settings: Ignore on either side suppresses contact, Block requires both sides to Block, and the remaining Block/Overlap combinations resolve to Overlap. Overlap events also require query collision and bGenerateOverlapEvents on both components. This native setter is local to the executing realm.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@param Channel ECollisionChannel Object channel to configure, such as ECC_Pawn; this is the other object's ObjectType.
---@param NewResponse ECollisionResponse ECR_Ignore, ECR_Overlap, or ECR_Block.
function WoWPrimitiveComponentBase:SetCollisionResponseToChannel(Channel, NewResponse) end

--- Set one rigid body's world-space angular velocity. By default this replaces the current velocity; set bAddToCurrent=true to add to it. Prefer torque or angular impulse for physically driven rotation. The target body must simulate physics.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@param NewAngVel FVector Angular velocity around the world X/Y/Z axes, in degrees/s.
---@param bAddToCurrent boolean Optional. True adds NewAngVel to the current velocity; false replaces it. Defaults to false.
---@param BoneName string Optional SkeletalMesh body name; use "None" or omit it for the root body.
function WoWPrimitiveComponentBase:SetPhysicsAngularVelocityInDegrees(NewAngVel, bAddToCurrent, BoneName) end

--- Replace the root rigid body's world-space linear velocity. Prefer AddForce or AddImpulse for physically driven motion. This sandbox override clamps each X/Y/Z component independently to [0, 20000] cm/s, so it cannot set negative velocity. It always uses bAddToCurrent=false and BoneName=None.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@param NewVel FVector Requested world-space velocity in cm/s; each component is clamped independently to [0, 20000].
function WoWPrimitiveComponentBase:SetPhysicsLinearVelocity(NewVel) end

--- Enable or disable rigid-body simulation. The component needs a valid physics body; physical contacts also require physics-capable collision. Enabling simulation on a simple attached body detaches it, while disabling simulation does not reattach it. Client calls are local; Server uses DSSetSimulatePhysics when available so supported creative components can replicate the state.
--- @realm Both This API is safe to call from both the Server-side and Client-side sandbox VMs (shared API). Its behavior is consistent across both realms, so it can be freely used in scripts on either side.
---@param bSimulate boolean True to make the body dynamic under physics; false to stop simulation and return transform control to gameplay code.
function WoWPrimitiveComponentBase:SetSimulatePhysics(bSimulate) end
