﻿GameProcess = {
    GameProcess1 = UGCLuaGlobalDefine.Enum_GameProcessType.GameMatchPrepare,  -- Match preparation phase
    GameProcess2 = UGCLuaGlobalDefine.Enum_GameProcessType.UGCGameInitialize, -- Game initialization
    GameProcess3 = UGCLuaGlobalDefine.Enum_GameProcessType.EnterGameProcess,  -- Enter game process
    GameProcess4 = UGCLuaGlobalDefine.Enum_GameProcessType.EnterANewRound,    -- Start a new round
    GameProcess5 = UGCLuaGlobalDefine.Enum_GameProcessType.RoundReadyPre,     -- Round ready pre-phase
    GameProcess6 = UGCLuaGlobalDefine.Enum_GameProcessType.RoundReady,        -- Round ready, players reset
    GameProcess7 = UGCLuaGlobalDefine.Enum_GameProcessType.RoundFighting,     -- Round fighting phase
    GameProcess8 = UGCLuaGlobalDefine.Enum_GameProcessType.RoundFinish,       -- Round finished
    GameProcess9 = UGCLuaGlobalDefine.Enum_GameProcessType.GameFinish,        -- Game finished
}

EquipSlot = {
    EquipSlot1 = 1, -- Primary weapon slot 1
    EquipSlot2 = 2, -- Primary weapon slot 2
    EquipSlot3 = 3, -- Pistol slot
    EquipSlot4 = 4, -- Helmet slot
    EquipSlot5 = 5, -- Armor slot
    EquipSlot6 = 6, -- Backpack slot
}

CustomRank =
{
    Rank1 = UGCLuaGlobalDefine.Enum_CustomRank.Rank1,
    Rank2 = UGCLuaGlobalDefine.Enum_CustomRank.Rank2,
    Rank3 = UGCLuaGlobalDefine.Enum_CustomRank.Rank3,
    Rank4 = UGCLuaGlobalDefine.Enum_CustomRank.Rank4,
    Rank5 = UGCLuaGlobalDefine.Enum_CustomRank.Rank5,
}

TeamRoundOutcome = {
    TeamRoundOutcome1 = UGCLuaGlobalDefine.Enum_OutcomeType.Win,  -- Round win
    TeamRoundOutcome2 = UGCLuaGlobalDefine.Enum_OutcomeType.Lose, -- Round lose
    TeamRoundOutcome3 = UGCLuaGlobalDefine.Enum_OutcomeType.Draw, -- Round draw
}

CharacterAction = {
    CharacterAction1 = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Jump,      -- Jump
    CharacterAction2 = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Crouch,    -- Crouch
    CharacterAction3 = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Prone,     -- Prone
    CharacterAction4 = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Vault,     -- Vault (hidden)
    CharacterAction5 = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Vault,     -- Vault
    CharacterAction6 = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Shoveling, -- Slide tackle
}

PlayerPawnState = {
    PlayerPawnState1 = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Move,       -- Normal movement
    PlayerPawnState2 = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Sprint,     -- Sprint
    PlayerPawnState3 = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.InAir,      -- In air
    PlayerPawnState4 = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.CrouchMove, -- Crouch move
    PlayerPawnState5 = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Falling,    -- Falling
}

Operator = {
    Operator_plus   = 1, -- Addition (+)
    Operator_minus  = 2, -- Subtraction (-)
    Operator_times  = 3, -- Multiplication (*)
    Operator_divide = 4, -- Division (/)
}

Integer_Operator = {
    Operator_Integer_plus   = 1, -- Addition (+)
    Operator_Integer_minus  = 2, -- Subtraction (-)
    Operator_Integer_times  = 3, -- Multiplication (*)
    Operator_Integer_divide = 4, -- Division (/)
    Operator_Integer_mod    = 5, -- Modulo (%)
    Operator_Integer_power  = 6, -- Power (^)
}

RoundingMethod = {
    RoundingMethod_Floor = 1, -- Floor (round down)
    RoundingMethod_ceil  = 2, -- Ceil (round up)
    RoundingMethod_round = 3, -- Round (half up)
}

minmax = {
    minmax_min = 2, -- Minimum value
    minmax_max = 1, -- Maximum value
}

LogBaseType = {
    LogBaseType_E   = 1, -- Natural logarithm base e
    LogBaseType_TEN = 2, -- Logarithm base 10
}

PickUp = {
    PickUp1 = 10001, -- Restore health
    PickUp2 = 10002, -- Repair
    PickUp3 = 10003, -- Speed up
    PickUp4 = 10004, -- Slow down
    PickUp5 = 10005, -- Stun
    PickUp6 = 10007, -- Invincible
    PickUp7 = 10008, -- Gold coin
    PickUp8 = 10009, -- Blue coin
    PickUp9 = 10010, -- Red coin
}

ActionRestriction = {
    ActionRestriction1 = UGCLuaGlobalDefine.Enum_ForbiddenPawnState.ForbiddenMove,    -- Forbid movement
    ActionRestriction2 = UGCLuaGlobalDefine.Enum_ForbiddenPawnState.ForbbiddenAttack, -- Forbid attack
}

DmgTypeChara = {
    DmgTypeChara1 = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.ShootDamage,         -- Gunshot damage
    DmgTypeChara2 = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.MeleeDamage,         -- Fist melee damage
    DmgTypeChara3 = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.GrenadeRadiusDamage, -- Grenade damage
    DmgTypeChara4 = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.BurningDamage,       -- Fire damage
    DmgTypeChara5 = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.PoisonDamage,        -- Poison zone damage
    DmgTypeChara6 = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.SkillDamage,         -- Skill damage
}

SkillSlot = {
    SkillSlot1 = 1, -- Skill slot 1
    SkillSlot2 = 2, -- Skill slot 2
    SkillSlot3 = 3, -- Skill slot 3
    SkillSlot4 = 4, -- Skill slot 4
}

ForbiddenPawnStat = {
    ForbiddenMove    = 1, -- Forbid all movement
    ForbbiddenAttack = 6, -- Forbid attack
}

Enum_UGCLuaAIPawnAttrType = {
    Hp              = 1, -- Health points
    TakeDamageScale = 2, -- Damage reduction multiplier
    DamageScale     = 3, -- Damage multiplier
    SpeedRate       = 4, -- Movement speed
    JumpZVelocity   = 5, -- Jump height
}

bAllMap = {
    bAllMap1 = true,  -- Audible across the entire map
    bAllMap2 = false, -- Default distance
}

TimerCountType = {
    Timer_CountUp   = 0, -- Count up (stopwatch)
    Timer_CountDown = 1, -- Count down (countdown)
}

PokerDeckSuitType = {
    PokerDeckSuitBlack  = 1, -- Spades
    PokerDeckSuitRed    = 2, -- Hearts
    PokerDeckSuitFlower = 3, -- Clubs
    PokerDeckSuitBlock  = 4, -- Diamonds
    PokerDeckSuitjoker  = 5, -- Joker
}

PokerDragType = {
    PokerDragTypeFree = 1, -- Free drag
    PokerDragTypexy   = 2, -- XY plane
    PokerDragTypeyz   = 3, -- YZ plane
    PokerDragTypezx   = 4, -- ZX plane
}

WeaponSlotPreset = {
    WeaponSlot1 = 1, -- Primary weapon 1
    WeaponSlot2 = 2, -- Primary weapon 2
    WeaponSlot3 = 3, -- Pistol
    WeaponSlot4 = 4, -- Melee weapon
    WeaponSlot5 = 0, -- None
}

WeaponSlotPreset2 = {
    WeaponSlotpreset1 = 1, -- Primary weapon 1
    WeaponSlotpreset2 = 2, -- Primary weapon 2
    WeaponSlotpreset3 = 3, -- Pistol
}

MobCMDInsertMethod = {
    MobCMD_ImmediateExecution = 1, -- Execute immediately
    MobCMD_InsertToFirst      = 2, -- Insert at front of queue
    MobCMD_InsertAtEnd        = 3, -- Insert at end of queue
}

Skillpolicy = {
    Skillpolicy1 = 0, -- Override
    Skillpolicy2 = 1, -- No override
    Skillpolicy3 = 2, -- Adaptive
}

MobSize = {
    MobSize_Small  = 0, -- Small
    MobSize_Medium = 1, -- Medium (used for wow)
    MobSize_Large  = 2, -- Large
}

MobColor = {
    MobColor_White  = 0, -- Original color
    MobColor_Yellow = 1, -- Yellow
    MobColor_Red    = 2, -- Red
    MobColor_Blue   = 3, -- Blue
    MobColor_Cyan   = 4, -- Cyan
    MobColor_Green  = 5, -- Green
}

NoChange = {
    NoChange = -1, -- No modification
}

SelectorDeviceIcon = {
    IconColor_Default   = UGCLuaGlobalDefine.Enum_SelectorDeviceIconType.Default,   -- Default
    IconColor_Red       = UGCLuaGlobalDefine.Enum_SelectorDeviceIconType.Red,       -- Red
    IconColor_Orange    = UGCLuaGlobalDefine.Enum_SelectorDeviceIconType.Orange,    -- Orange
    IconColor_Yellow    = UGCLuaGlobalDefine.Enum_SelectorDeviceIconType.Yellow,    -- Yellow
    IconColor_Green     = UGCLuaGlobalDefine.Enum_SelectorDeviceIconType.Green,     -- Green
    IconColor_BlueGreen = UGCLuaGlobalDefine.Enum_SelectorDeviceIconType.BlueGreen, -- Blue-green
    IconColor_Blue      = UGCLuaGlobalDefine.Enum_SelectorDeviceIconType.Blue,      -- Blue
    IconColor_Purple    = UGCLuaGlobalDefine.Enum_SelectorDeviceIconType.Purple,    -- Purple
}

SelectorDeviceTextColor = {
    TextColor_White     = UGCLuaGlobalDefine.Enum_SelectorDeviceTextColorType.White,     -- White
    TextColor_Red       = UGCLuaGlobalDefine.Enum_SelectorDeviceTextColorType.Red,       -- Red
    TextColor_Orange    = UGCLuaGlobalDefine.Enum_SelectorDeviceTextColorType.Orange,    -- Orange
    TextColor_Yellow    = UGCLuaGlobalDefine.Enum_SelectorDeviceTextColorType.Yellow,    -- Yellow
    TextColor_Green     = UGCLuaGlobalDefine.Enum_SelectorDeviceTextColorType.Green,     -- Green
    TextColor_BlueGreen = UGCLuaGlobalDefine.Enum_SelectorDeviceTextColorType.BlueGreen, -- Blue-green
    TextColor_Blue      = UGCLuaGlobalDefine.Enum_SelectorDeviceTextColorType.Blue,      -- Blue
    TextColor_Purple    = UGCLuaGlobalDefine.Enum_SelectorDeviceTextColorType.Purple,    -- Purple
}

TaskStatus = {
    TaskStatus1 = UGCLuaGlobalDefine.Enum_TaskStatus.Pending,        -- Pending acceptance
    TaskStatus2 = UGCLuaGlobalDefine.Enum_TaskStatus.InProgress,     -- In progress
    TaskStatus3 = UGCLuaGlobalDefine.Enum_TaskStatus.PendingAcclaim, -- Pending submission
    TaskStatus4 = UGCLuaGlobalDefine.Enum_TaskStatus.Success,        -- Success
    TaskStatus5 = UGCLuaGlobalDefine.Enum_TaskStatus.Fail,           -- Fail
}

CustomMonsterUIBarPosition = {
    Location0 = 0, -- Health bar top-center
    Location1 = 1, -- Health bar top-left
    Location2 = 2, -- Health bar top-right
    Location3 = 3, -- Health bar bottom-center
    Location4 = 4, -- Health bar bottom-left
    Location5 = 5, -- Health bar bottom-right
    Location6 = 6, -- Health bar hidden
}

mergetype = {
    mergetype1 = true,  -- Keep dictionary 1
    mergetype2 = false, -- Keep dictionary 2
}

Talentstate = {
    talentstate1 = 0, -- Locked
    talentstate2 = 1, -- Unlocked
    talentstate3 = 2, -- Activated
}

Axis = {
    Axis_X = UGCLuaGlobalDefine.Enum_VectorAxis.X, -- X axis
    Axis_Y = UGCLuaGlobalDefine.Enum_VectorAxis.Y, -- Y axis
    Axis_Z = UGCLuaGlobalDefine.Enum_VectorAxis.Z, -- Z axis
}

WorldDir = {
    World_Forward  = UGCLuaGlobalDefine.Enum_VectorWorldDir.Forward,  -- Forward
    World_Backward = UGCLuaGlobalDefine.Enum_VectorWorldDir.Backward, -- Backward
    World_Up       = UGCLuaGlobalDefine.Enum_VectorWorldDir.Up,       -- Up
    World_Down     = UGCLuaGlobalDefine.Enum_VectorWorldDir.Down,     -- Down
    World_Left     = UGCLuaGlobalDefine.Enum_VectorWorldDir.Left,     -- Left
    World_Right    = UGCLuaGlobalDefine.Enum_VectorWorldDir.Right,    -- Right
}

CollisionEnabled = {
    NoCollision     = UGCLuaGlobalDefine.Enum_CollisionEnabled.NoCollision,     -- Disable both query and physics collision
    QueryOnly       = UGCLuaGlobalDefine.Enum_CollisionEnabled.QueryOnly,       -- Enable overlap/trace query only
    PhysicsOnly     = UGCLuaGlobalDefine.Enum_CollisionEnabled.PhysicsOnly,     -- Enable physics simulation collision only
    QueryAndPhysics = UGCLuaGlobalDefine.Enum_CollisionEnabled.QueryAndPhysics, -- Enable both query and physics collision
    TriggerOnly     = UGCLuaGlobalDefine.Enum_CollisionEnabled.TriggerOnly,     -- Trigger interaction only
    QueryAndTrigger = UGCLuaGlobalDefine.Enum_CollisionEnabled.QueryAndTrigger, -- Enable query and trigger interaction
}

ECollisionResponse = {
    ECR_Ignore = 0,  -- Ignore the other collision object.
    ECR_Overlap = 1, -- Generate overlap events without blocking movement.
    ECR_Block = 2,   -- Block the other collision object.
}

ECollisionChannel = {
    ECC_WorldStatic = 0,          -- Object: WorldStatic
    ECC_WorldDynamic = 1,         -- Object: WorldDynamic
    ECC_Pawn = 2,                 -- Object: Pawn
    ECC_Visibility = 3,           -- Trace: Visibility
    ECC_Camera = 4,               -- Trace: Camera
    ECC_PhysicsBody = 5,          -- Object: PhysicsBody
    ECC_Vehicle = 6,              -- Object: Vehicle
    ECC_Destructible = 7,         -- Object: Destructible
    ECC_EngineTraceChannel1 = 8,  -- Engine reserved
    ECC_EngineTraceChannel2 = 9,  -- Engine reserved
    ECC_EngineTraceChannel3 = 10, -- Engine reserved
    ECC_EngineTraceChannel4 = 11, -- Engine reserved
    ECC_EngineTraceChannel5 = 12, -- Engine reserved
    ECC_EngineTraceChannel6 = 13, -- Engine reserved
    ECC_GameTraceChannel1 = 14,   -- Object: Teleporter
    ECC_GameTraceChannel2 = 15,   -- Trace: TraceTeleport
    ECC_GameTraceChannel3 = 16,   -- Object: PlayerPawn
    ECC_GameTraceChannel4 = 17,   -- Object: PlayerHand
    ECC_GameTraceChannel5 = 18,   -- Object: Trigger
    ECC_GameTraceChannel6 = 19,   -- Object: Bullet
    ECC_GameTraceChannel7 = 20,   -- Trace: PlayerApplyDamage
    ECC_GameTraceChannel8 = 21,   -- Trace: BotApplyDamage
    ECC_GameTraceChannel9 = 22,   -- Object: STEMesh
    ECC_GameTraceChannel10 = 23,  -- Object: PropMesh
    ECC_GameTraceChannel11 = 24,  -- Trace: Footstep
    ECC_GameTraceChannel12 = 25,  -- Trace: TestHeight
    ECC_GameTraceChannel13 = 26,  -- Trace: PickUpVisible
    ECC_GameTraceChannel14 = 27,  -- Trace: WheelCollision
    ECC_GameTraceChannel15 = 28,  -- Object: VaultMesh
    ECC_GameTraceChannel16 = 29,  -- Trace: AutoAim
    ECC_GameTraceChannel17 = 30,  -- Object: Projectile
    ECC_GameTraceChannel18 = 31,  -- Object: SreadingBlockerOverlap (project spelling)
    ECC_OverlapAll_Deprecated = 32,
}

-- ForObjects/OverlapObjects APIs use EObjectTypeQuery values, not
-- ECollisionChannel values. The query index is compacted to include only
-- object channels, so values after Pawn no longer match ECollisionChannel.
CollisionObjectType = {
    WorldStatic = 0,             -- ObjectTypeQuery1  -> ECC_WorldStatic
    WorldDynamic = 1,            -- ObjectTypeQuery2  -> ECC_WorldDynamic
    Pawn = 2,                    -- ObjectTypeQuery3  -> ECC_Pawn
    PhysicsBody = 3,             -- ObjectTypeQuery4  -> ECC_PhysicsBody (channel 5)
    Vehicle = 4,                 -- ObjectTypeQuery5  -> ECC_Vehicle (channel 6)
    Destructible = 5,            -- ObjectTypeQuery6  -> ECC_Destructible (channel 7)
    Teleporter = 6,              -- ObjectTypeQuery7  -> ECC_GameTraceChannel1
    PlayerPawn = 7,              -- ObjectTypeQuery8  -> ECC_GameTraceChannel3
    PlayerHand = 8,              -- ObjectTypeQuery9  -> ECC_GameTraceChannel4
    Trigger = 9,                 -- ObjectTypeQuery10 -> ECC_GameTraceChannel5
    Bullet = 10,                 -- ObjectTypeQuery11 -> ECC_GameTraceChannel6
    STEMesh = 11,                -- ObjectTypeQuery12 -> ECC_GameTraceChannel9
    PropMesh = 12,               -- ObjectTypeQuery13 -> ECC_GameTraceChannel10
    VaultMesh = 13,              -- ObjectTypeQuery14 -> ECC_GameTraceChannel15
    Projectile = 14,             -- ObjectTypeQuery15 -> ECC_GameTraceChannel17
    SreadingBlockerOverlap = 15, -- ObjectTypeQuery16 -> ECC_GameTraceChannel18
}

-- Collision Preset is a complete collision-response profile selected by name.
-- It is not an Object Type and must not be passed to ForObjects APIs.
-- Use these names with SetCollisionProfileName; use CollisionObjectType for queries.
InCollisionProfileName = {
    NoCollision                = UGCLuaGlobalDefine.InCollisionProfileName.NoCollision,                -- No collision (disables all query and physics collision)
    BlockAll                   = UGCLuaGlobalDefine.InCollisionProfileName.BlockAll,                   -- WorldStatic object that blocks all actors by default
    OverlapAll                 = UGCLuaGlobalDefine.InCollisionProfileName.OverlapAll,                 -- WorldStatic object that overlaps all actors by default
    BlockAllDynamic            = UGCLuaGlobalDefine.InCollisionProfileName.BlockAllDynamic,            -- WorldDynamic object that blocks all actors by default
    OverlapAllDynamic          = UGCLuaGlobalDefine.InCollisionProfileName.OverlapAllDynamic,          -- WorldDynamic object that overlaps all actors by default
    IgnoreOnlyPawn             = UGCLuaGlobalDefine.InCollisionProfileName.IgnoreOnlyPawn,             -- WorldDynamic object that ignores Pawn and Vehicle
    OverlapOnlyPawn            = UGCLuaGlobalDefine.InCollisionProfileName.OverlapOnlyPawn,            -- WorldDynamic object that overlaps Pawn and Vehicle
    Pawn                       = UGCLuaGlobalDefine.InCollisionProfileName.Pawn,                       -- Pawn capsule for playerable character or AI
    Spectator                  = UGCLuaGlobalDefine.InCollisionProfileName.Spectator,                  -- Pawn object that ignores all actors except WorldStatic
    CharacterMesh              = UGCLuaGlobalDefine.InCollisionProfileName.CharacterMesh,              -- Mesh used for character skeletal mesh
    PhysicsActor               = UGCLuaGlobalDefine.InCollisionProfileName.PhysicsActor,               -- Simulating physics actors
    Destructible               = UGCLuaGlobalDefine.InCollisionProfileName.Destructible,               -- Destructible actors
    InvisibleWall              = UGCLuaGlobalDefine.InCollisionProfileName.InvisibleWall,              -- Invisible WorldStatic wall
    InvisibleWallDynamic       = UGCLuaGlobalDefine.InCollisionProfileName.InvisibleWallDynamic,       -- Invisible WorldDynamic wall
    Trigger                    = UGCLuaGlobalDefine.InCollisionProfileName.Trigger,                    -- Trigger object used for overlap detection
    Ragdoll                    = UGCLuaGlobalDefine.InCollisionProfileName.Ragdoll,                    -- Simulating skeletal mesh ragdoll
    Vehicle                    = UGCLuaGlobalDefine.InCollisionProfileName.Vehicle,                    -- Vehicle object
    UI                         = UGCLuaGlobalDefine.InCollisionProfileName.UI,                         -- UI object (overlaps all, blocks Visibility)
    PlayerTrigger              = UGCLuaGlobalDefine.InCollisionProfileName.PlayerTrigger,              -- Trigger that overlaps Pawn and PlayerPawn only
    PhysicalTrigger            = UGCLuaGlobalDefine.InCollisionProfileName.PhysicalTrigger,            -- Trigger for physical interaction events
    PhysicalTriggerOnly        = UGCLuaGlobalDefine.InCollisionProfileName.PhysicalTriggerOnly,        -- Trigger-only mode for physical interaction
    Bullet                     = UGCLuaGlobalDefine.InCollisionProfileName.Bullet,                     -- Bullet collision profile
    PickUpTriggerBox           = UGCLuaGlobalDefine.InCollisionProfileName.PickUpTriggerBox,           -- Trigger box used for VR player hand pick up
    PropMesh                   = UGCLuaGlobalDefine.InCollisionProfileName.PropMesh,                   -- Prop mesh collision profile
    PickUpTrigger              = UGCLuaGlobalDefine.InCollisionProfileName.PickUpTrigger,              -- Trigger for item pick up overlap
    WireMesh                   = UGCLuaGlobalDefine.InCollisionProfileName.WireMesh,                   -- Wire mesh (only bullet and camera can pass through)
    StepsQueryOnly             = UGCLuaGlobalDefine.InCollisionProfileName.StepsQueryOnly,             -- Query-only profile for building steps
    Smoke                      = UGCLuaGlobalDefine.InCollisionProfileName.Smoke,                      -- Smoke area (no collision)
    Pet                        = UGCLuaGlobalDefine.InCollisionProfileName.Pet,                        -- Pet object collision profile
    BlockAISight               = UGCLuaGlobalDefine.InCollisionProfileName.BlockAISight,               -- Blocks AI sight check
    CreaturesVehicle           = UGCLuaGlobalDefine.InCollisionProfileName.CreaturesVehicle,           -- Creature vehicle collision profile
    CharacterTriggerForVehicle = UGCLuaGlobalDefine.InCollisionProfileName.CharacterTriggerForVehicle, -- Trigger for vehicle hitting character
    Water                      = UGCLuaGlobalDefine.InCollisionProfileName.Water,                      -- Water area collision profile
    WaterPlane                 = UGCLuaGlobalDefine.InCollisionProfileName.WaterPlane,                 -- Water plane surface collision profile
    NoWaterArea                = UGCLuaGlobalDefine.InCollisionProfileName.NoWaterArea,                -- No-water zone collision profile
    BioVehicleMesh             = UGCLuaGlobalDefine.InCollisionProfileName.BioVehicleMesh,             -- Bio vehicle mesh collision profile
    InvisibleBlockPawnVehicle  = UGCLuaGlobalDefine.InCollisionProfileName.InvisibleBlockPawnVehicle,  -- Invisible wall that blocks only Pawn and Vehicle
    OnlyCollideStatic          = UGCLuaGlobalDefine.InCollisionProfileName.OnlyCollideStatic,          -- Physics-only, collides with landscape/static only
}

EasingStyle = {
    Linear = 0,
    Sine = 1,
    Quad = 2,
    Cubic = 3,
    Quart = 4,
    Quint = 5,
    Exponential = 6,
    Circular = 7,
    Back = 8,
    Bounce = 9,
}

EasingDirection = {
    In = 0,    -- The easing style is applied in a forward direction
    Out = 1,   -- The easing style is applied in a reverse direction
    InOut = 2, -- The easing style is applied forward for the first half and in reverse for the second half
}

ParticleSystemParameter = {
    BeamStart = "BeamStart",
    BeamEnd = "BeamEnd",
}

Operator_FVector = {
    Operator_FVector_plus   = UGCLuaGlobalDefine.Enum_Operator_FVector["+"], -- Vector addition (+)
    Operator_FVector_minus  = UGCLuaGlobalDefine.Enum_Operator_FVector["-"], -- Vector subtraction (-)
    Operator_FVector_times  = UGCLuaGlobalDefine.Enum_Operator_FVector["*"], -- Vector multiplication (*)
    Operator_FVector_divide = UGCLuaGlobalDefine.Enum_Operator_FVector["/"], -- Vector division (/)
}

MaterialColorType = {
    MaterialColorType_White  = UGCLuaGlobalDefine.Enum_MaterialColorType.White,  -- Original color (white)
    MaterialColorType_Yellow = UGCLuaGlobalDefine.Enum_MaterialColorType.Yellow, -- Yellow
    MaterialColorType_Red    = UGCLuaGlobalDefine.Enum_MaterialColorType.Red,    -- Red
    MaterialColorType_Blue   = UGCLuaGlobalDefine.Enum_MaterialColorType.Blue,   -- Blue
    MaterialColorType_Cyan   = UGCLuaGlobalDefine.Enum_MaterialColorType.Cyan,   -- Cyan
    MaterialColorType_Green  = UGCLuaGlobalDefine.Enum_MaterialColorType.Green,  -- Green
}

ModelSizeType = {
    ModelSizeType_Min = UGCLuaGlobalDefine.Enum_ModelSizeType.Min, -- Small size
    ModelSizeType_Mid = UGCLuaGlobalDefine.Enum_ModelSizeType.Mid, -- Medium size
    ModelSizeType_Max = UGCLuaGlobalDefine.Enum_ModelSizeType.Max, -- Large size
}

Operator_Integer = {
    Operator_Integer_plus   = UGCLuaGlobalDefine.Enum_Operator_Integer["+"], -- Integer addition (+)
    Operator_Integer_minus  = UGCLuaGlobalDefine.Enum_Operator_Integer["-"], -- Integer subtraction (-)
    Operator_Integer_times  = UGCLuaGlobalDefine.Enum_Operator_Integer["*"], -- Integer multiplication (*)
    Operator_Integer_divide = UGCLuaGlobalDefine.Enum_Operator_Integer["/"], -- Integer division (/)
    Operator_Integer_mod    = UGCLuaGlobalDefine.Enum_Operator_Integer["%"], -- Integer modulo (%)
    Operator_Integer_power  = UGCLuaGlobalDefine.Enum_Operator_Integer["^"], -- Integer power (^)
}

Operator_Real = {
    Operator_Real_plus   = UGCLuaGlobalDefine.Enum_Operator_Real["+"], -- Real addition (+)
    Operator_Real_minus  = UGCLuaGlobalDefine.Enum_Operator_Real["-"], -- Real subtraction (-)
    Operator_Real_times  = UGCLuaGlobalDefine.Enum_Operator_Real["*"], -- Real multiplication (*)
    Operator_Real_divide = UGCLuaGlobalDefine.Enum_Operator_Real["/"], -- Real division (/)
    Operator_Real_mod    = UGCLuaGlobalDefine.Enum_Operator_Real["%"], -- Real modulo (%)
    Operator_Real_power  = UGCLuaGlobalDefine.Enum_Operator_Real["^"], -- Real power (^)
}

VectorAxis = {
    VectorAxis_X = UGCLuaGlobalDefine.Enum_VectorAxis.X, -- X axis
    VectorAxis_Y = UGCLuaGlobalDefine.Enum_VectorAxis.Y, -- Y axis
    VectorAxis_Z = UGCLuaGlobalDefine.Enum_VectorAxis.Z, -- Z axis
}

VectorWorldDir = {
    VectorWorldDir_Forward  = UGCLuaGlobalDefine.Enum_VectorWorldDir.Forward,  -- World forward
    VectorWorldDir_Backward = UGCLuaGlobalDefine.Enum_VectorWorldDir.Backward, -- World backward
    VectorWorldDir_Up       = UGCLuaGlobalDefine.Enum_VectorWorldDir.Up,       -- World up
    VectorWorldDir_Down     = UGCLuaGlobalDefine.Enum_VectorWorldDir.Down,     -- World down
    VectorWorldDir_Left     = UGCLuaGlobalDefine.Enum_VectorWorldDir.Left,     -- World left
    VectorWorldDir_Right    = UGCLuaGlobalDefine.Enum_VectorWorldDir.Right,    -- World right
}

UGCGameObjType = {
    UGCGameObjType_Player      = UGCLuaGlobalDefine.Enum_UGCGameObjType.Player,      -- Character / Player
    UGCGameObjType_Instance    = UGCLuaGlobalDefine.Enum_UGCGameObjType.Instance,    -- Game component instance
    UGCGameObjType_Pickup      = UGCLuaGlobalDefine.Enum_UGCGameObjType.Pickup,      -- Pickup item
    UGCGameObjType_TriggerArea = UGCLuaGlobalDefine.Enum_UGCGameObjType.TriggerArea, -- Trigger area
}

GameProcessType = {
    GameProcessType_GameMatchPrepare  = UGCLuaGlobalDefine.Enum_GameProcessType.GameMatchPrepare,  -- Match preparation phase
    GameProcessType_UGCGameInitialize = UGCLuaGlobalDefine.Enum_GameProcessType.UGCGameInitialize, -- Game initialization (after VM created and global code executed)
    GameProcessType_EnterGameProcess  = UGCLuaGlobalDefine.Enum_GameProcessType.EnterGameProcess,  -- Enter game process
    GameProcessType_EnterANewRound    = UGCLuaGlobalDefine.Enum_GameProcessType.EnterANewRound,    -- Start a new round (objects reset, players not yet)
    GameProcessType_RoundReadyPre     = UGCLuaGlobalDefine.Enum_GameProcessType.RoundReadyPre,     -- Round ready pre-phase (players not yet reset)
    GameProcessType_RoundReady        = UGCLuaGlobalDefine.Enum_GameProcessType.RoundReady,        -- Round ready (players reset)
    GameProcessType_RoundFighting     = UGCLuaGlobalDefine.Enum_GameProcessType.RoundFighting,     -- Round fighting phase
    GameProcessType_RoundFinish       = UGCLuaGlobalDefine.Enum_GameProcessType.RoundFinish,       -- Round finished, settling round
    GameProcessType_GameFinish        = UGCLuaGlobalDefine.Enum_GameProcessType.GameFinish,        -- Game finished, settling game
}

OutcomeType = {
    OutcomeType_Win  = UGCLuaGlobalDefine.Enum_OutcomeType.Win,  -- Win
    OutcomeType_Lose = UGCLuaGlobalDefine.Enum_OutcomeType.Lose, -- Lose
    OutcomeType_Draw = UGCLuaGlobalDefine.Enum_OutcomeType.Draw, -- Draw
}

UGCLuaPawnState = {
    UGCLuaPawnState_Move                   = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Move,                   -- Move
    UGCLuaPawnState_Sprint                 = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Sprint,                 -- Sprint
    UGCLuaPawnState_ProneMove              = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.ProneMove,              -- Prone move
    UGCLuaPawnState_Stand                  = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Stand,                  -- Stand
    UGCLuaPawnState_Crouch                 = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Crouch,                 -- Crouch
    UGCLuaPawnState_Prone                  = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Prone,                  -- Prone
    UGCLuaPawnState_Jump                   = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Jump,                   -- Jump
    UGCLuaPawnState_GunFire                = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.GunFire,                -- Gun fire
    UGCLuaPawnState_GunReload              = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.GunReload,              -- Gun reload
    UGCLuaPawnState_GunADS                 = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.GunADS,                 -- Aim down sights
    UGCLuaPawnState_Picth                  = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Picth,                  -- Lean
    UGCLuaPawnState_SwitchWeapon           = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.SwitchWeapon,           -- Switch weapon
    UGCLuaPawnState_Pick                   = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Pick,                   -- Pick up
    UGCLuaPawnState_MeleeAttack            = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.MeleeAttack,            -- Melee attack
    UGCLuaPawnState_HoldGrenade            = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.HoldGrenade,            -- Hold grenade
    UGCLuaPawnState_Save                   = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Save,                   -- Rescue
    UGCLuaPawnState_UseConsumables         = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.UseConsumables,         -- Use consumables
    UGCLuaPawnState_Dying                  = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Dying,                  -- Dying
    UGCLuaPawnState_Dead                   = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Dead,                   -- Dead
    UGCLuaPawnState_DriveVehicle           = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.DriveVehicle,           -- Drive vehicle (driver)
    UGCLuaPawnState_InVehicle              = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.InVehicle,              -- In vehicle (passenger)
    UGCLuaPawnState_LeanOutVehicle         = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.LeanOutVehicle,         -- Lean out and shoot
    UGCLuaPawnState_Swim                   = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Swim,                   -- Swim
    UGCLuaPawnState_InParachute            = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.InParachute,            -- In parachute
    UGCLuaPawnState_Vault                  = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Vault,                  -- Vault / climb
    UGCLuaPawnState_InPlane                = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.InPlane,                -- In plane
    UGCLuaPawnState_GunOBOReload           = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.GunOBOReload,           -- One-by-one / tactical reload
    UGCLuaPawnState_SwitchPP               = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.SwitchPP,               -- Switch TPP/FPP
    UGCLuaPawnState_PlayEmote              = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.PlayEmote,              -- Play emote / change outfit
    UGCLuaPawnState_HoldShield             = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.HoldShield,             -- Hold shield (unused)
    UGCLuaPawnState_Imprisonment           = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Imprisonment,           -- Imprisoned (unused)
    UGCLuaPawnState_StunBurnNag            = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.StunBurnNag,            -- Pat fire / cover eyes
    UGCLuaPawnState_Skill                  = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Skill,                  -- Use skill
    UGCLuaPawnState_DetectPaintDecal       = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.DetectPaintDecal,       -- Spray paint
    UGCLuaPawnState_Revival                = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Revival,                -- Revive
    UGCLuaPawnState_AirAttackLocator       = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.AirAttackLocator,       -- Heavy fire airstrike locating
    UGCLuaPawnState_ControlUnmannedVehicle = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.ControlUnmannedVehicle, -- Control UCAV
    UGCLuaPawnState_Shoveling              = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Shoveling,              -- Slide tackle
    UGCLuaPawnState_RemoteControlVehicle   = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.RemoteControlVehicle,   -- Remote control vehicle (cold UAV)
    UGCLuaPawnState_Build                  = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Build,                  -- Build
    UGCLuaPawnState_GunFillGas             = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.GunFillGas,             -- Gun fill gas
    UGCLuaPawnState_Shoulder               = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Shoulder,               -- Shoulder fire
    UGCLuaPawnState_Variation              = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Variation,              -- Variation / transform
    UGCLuaPawnState_CarryBack              = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.CarryBack,              -- Carry teammate
    UGCLuaPawnState_BeCarriedBack          = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.BeCarriedBack,          -- Being carried
    UGCLuaPawnState_Dizziness              = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Dizziness,              -- Dizzy
    UGCLuaPawnState_Knock                  = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Knock,                  -- Knocked away
    UGCLuaPawnState_InZipline              = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.InZipline,              -- On zipline
    UGCLuaPawnState_StairsMove             = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.StairsMove,             -- Climb ladder
    UGCLuaPawnState_InActivityActor        = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.InActivityActor,        -- In interactive object
    UGCLuaPawnState_DriveMovePlatForm      = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.DriveMovePlatForm,      -- Drive moving platform
    UGCLuaPawnState_Slide                  = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Slide,                  -- Glide
    UGCLuaPawnState_WeaponAccPrepare       = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.WeaponAccPrepare,       -- Weapon charge
    UGCLuaPawnState_Arrest                 = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Arrest,                 -- Arrested
    UGCLuaPawnState_AirBorne               = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.AirBorne,               -- Airborne dance
    UGCLuaPawnState_SplineMove             = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.SplineMove,             -- Spline move
    UGCLuaPawnState_MovableEmote           = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.MovableEmote,           -- Movable emote
    UGCLuaPawnState_PassiveVariation       = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.PassiveVariation,       -- Passive variation
    UGCLuaPawnState_ControlDrone           = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.ControlDrone,           -- Control drone
    UGCLuaPawnState_Restricted             = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Restricted,             -- Restricted action
    UGCLuaPawnState_FlyingArmor            = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.FlyingArmor,            -- Flying armor
    UGCLuaPawnState_Diving                 = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Diving,                 -- Diving
    UGCLuaPawnState_ShapeShifting          = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.ShapeShifting,          -- Special shape shifting
    UGCLuaPawnState_NoneState              = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.NoneState,              -- None / unconcerned
    UGCLuaPawnState_CrouchMove             = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.CrouchMove,             -- Crouch move
    UGCLuaPawnState_InAir                  = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.InAir,                  -- In air (rising or falling)
    UGCLuaPawnState_Falling                = UGCLuaGlobalDefine.Enum_UGCLuaPawnState.Falling,                -- Falling
}

GameplayButtonType = {
    GameplayButtonType_Attack    = UGCLuaGlobalDefine.Enum_GameplayButtonType.Attack,    -- Attack (fire/melee)
    GameplayButtonType_SwitchGun = UGCLuaGlobalDefine.Enum_GameplayButtonType.SwitchGun, -- Switch weapon
    GameplayButtonType_Prone     = UGCLuaGlobalDefine.Enum_GameplayButtonType.Prone,     -- Go prone
    GameplayButtonType_Jump      = UGCLuaGlobalDefine.Enum_GameplayButtonType.Jump,      -- Jump
    GameplayButtonType_Rescue    = UGCLuaGlobalDefine.Enum_GameplayButtonType.Rescue,    -- Rescue teammate
    GameplayButtonType_Carry     = UGCLuaGlobalDefine.Enum_GameplayButtonType.Carry,     -- Carry teammate
    GameplayButtonType_Crouch    = UGCLuaGlobalDefine.Enum_GameplayButtonType.Crouch,    -- Crouch
    GameplayButtonType_Skill     = UGCLuaGlobalDefine.Enum_GameplayButtonType.Skill,     -- Use skill
    GameplayButtonType_Throw     = UGCLuaGlobalDefine.Enum_GameplayButtonType.Throw,     -- Throw
}

ForbiddenPawnState = {
    ForbiddenPawnState_ForbiddenMove           = UGCLuaGlobalDefine.Enum_ForbiddenPawnState.ForbiddenMove,           -- Forbid all movement
    ForbiddenPawnState_ForbbiddenJump          = UGCLuaGlobalDefine.Enum_ForbiddenPawnState.ForbbiddenJump,          -- Forbid jump
    ForbiddenPawnState_ForbbiddenCrouch        = UGCLuaGlobalDefine.Enum_ForbiddenPawnState.ForbbiddenCrouch,        -- Forbid crouch
    ForbiddenPawnState_ForbbiddenProne         = UGCLuaGlobalDefine.Enum_ForbiddenPawnState.ForbbiddenProne,         -- Forbid prone
    ForbiddenPawnState_ForbbiddenSprint        = UGCLuaGlobalDefine.Enum_ForbiddenPawnState.ForbbiddenSprint,        -- Forbid sprint
    ForbiddenPawnState_ForbbiddenAttack        = UGCLuaGlobalDefine.Enum_ForbiddenPawnState.ForbbiddenAttack,        -- Forbid attack
    ForbiddenPawnState_ForbbiddenViewControll  = UGCLuaGlobalDefine.Enum_ForbiddenPawnState.ForbbiddenViewControll,  -- Forbid view control
    ForbiddenPawnState_ForbbiddenPickItem      = UGCLuaGlobalDefine.Enum_ForbiddenPawnState.ForbbiddenPickItem,      -- Forbid pick up item
    ForbiddenPawnState_ForbbiddenUseItem       = UGCLuaGlobalDefine.Enum_ForbiddenPawnState.ForbbiddenUseItem,       -- Forbid use item
    ForbiddenPawnState_ForbbiddenGetOnVehicle  = UGCLuaGlobalDefine.Enum_ForbiddenPawnState.ForbbiddenGetOnVehicle,  -- Forbid get on vehicle
    ForbiddenPawnState_ForbbiddenGetOutVehicle = UGCLuaGlobalDefine.Enum_ForbiddenPawnState.ForbbiddenGetOutVehicle, -- Forbid get out vehicle
}

UGCLuaDamageType = {
    UGCLuaDamageType_InvalidDamageType          = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.InvalidDamageType,          -- Invalid damage type
    UGCLuaDamageType_ShootDamage                = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.ShootDamage,                -- Weapon shooting damage
    UGCLuaDamageType_STPointDamage              = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.STPointDamage,              -- Point damage (intermediate)
    UGCLuaDamageType_CustomRadiusDamage         = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.CustomRadiusDamage,         -- Custom radius damage (intermediate)
    UGCLuaDamageType_PoisonDamage               = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.PoisonDamage,               -- Poison zone damage
    UGCLuaDamageType_DrowningDamage             = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.DrowningDamage,             -- Drowning damage
    UGCLuaDamageType_FallingDamage              = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.FallingDamage,              -- Falling damage
    UGCLuaDamageType_MeleeDamage                = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.MeleeDamage,                -- Fist melee damage
    UGCLuaDamageType_GrenadeRadiusDamage        = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.GrenadeRadiusDamage,        -- Grenade radius damage
    UGCLuaDamageType_BurningDamage              = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.BurningDamage,              -- Fire burning damage
    UGCLuaDamageType_AirAttackDamage            = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.AirAttackDamage,            -- Air attack damage
    UGCLuaDamageType_VehicleDamage              = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.VehicleDamage,              -- Vehicle impact damage
    UGCLuaDamageType_VehicleExplodeRadiusDamage = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.VehicleExplodeRadiusDamage, -- Vehicle explosion damage
    UGCLuaDamageType_LastBreathWithoutRescue    = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.LastBreathWithoutRescue,    -- Knocked down without rescue
    UGCLuaDamageType_WinnerFakeDeath            = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.WinnerFakeDeath,            -- Winner fake death
    UGCLuaDamageType_SkillDamage                = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.SkillDamage,                -- Skill damage
    UGCLuaDamageType_PoisonFogDamage            = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.PoisonFogDamage,            -- Poison fog damage
    UGCLuaDamageType_GasolineCanExplosion       = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.GasolineCanExplosion,       -- Gasoline can explosion
    UGCLuaDamageType_ZombieDamage               = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.ZombieDamage,               -- Zombie damage
    UGCLuaDamageType_LowTemperatureDamage       = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.LowTemperatureDamage,       -- Low temperature damage
    UGCLuaDamageType_TopFiveGaveUpDamage        = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.TopFiveGaveUpDamage,        -- Top-5 gave-up damage
    UGCLuaDamageType_Resurrection               = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.Resurrection,               -- Resurrection
    UGCLuaDamageType_TyrantMonsterStonedDamage  = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.TyrantMonsterStonedDamage,  -- Tyrant monster stone damage
    UGCLuaDamageType_RPGExplosionDamage         = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.RPGExplosionDamage,         -- RPG explosion damage
    UGCLuaDamageType_CartridgeExplosionDamage   = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.CartridgeExplosionDamage,   -- Cartridge explosion damage
    UGCLuaDamageType_DotDamage                  = UGCLuaGlobalDefine.Enum_UGCLuaDamageType.DotDamage,                  -- Generic DOT damage
}

BinaryCmpOpType = {
    BinaryCmpOpType_max = UGCLuaGlobalDefine.Enum_BinaryCmpOpType["max"], -- Maximum value
    BinaryCmpOpType_min = UGCLuaGlobalDefine.Enum_BinaryCmpOpType["min"], -- Minimum value
}

UGCLuaAIPawnAttrType = {
    UGCLuaAIPawnAttrType_Hp              = UGCLuaGlobalDefine.Enum_UGCLuaAIPawnAttrType.Hp,              -- Health points
    UGCLuaAIPawnAttrType_TakeDamageScale = UGCLuaGlobalDefine.Enum_UGCLuaAIPawnAttrType.TakeDamageScale, -- Damage reduction multiplier
    UGCLuaAIPawnAttrType_DamageScale     = UGCLuaGlobalDefine.Enum_UGCLuaAIPawnAttrType.DamageScale,     -- Damage multiplier
    UGCLuaAIPawnAttrType_SpeedRate       = UGCLuaGlobalDefine.Enum_UGCLuaAIPawnAttrType.SpeedRate,       -- Movement speed
    UGCLuaAIPawnAttrType_JumpZVelocity   = UGCLuaGlobalDefine.Enum_UGCLuaAIPawnAttrType.JumpZVelocity,   -- Jump height
}

UGCLuaSurviveWeaponPropSlot = {
    UGCLuaSurviveWeaponPropSlot_SWPS_None               = UGCLuaGlobalDefine.Enum_UGCLuaSurviveWeaponPropSlot.SWPS_None,               -- None
    UGCLuaSurviveWeaponPropSlot_SWPS_MainShootWeapon1   = UGCLuaGlobalDefine.Enum_UGCLuaSurviveWeaponPropSlot.SWPS_MainShootWeapon1,   -- Primary weapon 1
    UGCLuaSurviveWeaponPropSlot_SWPS_MainShootWeapon2   = UGCLuaGlobalDefine.Enum_UGCLuaSurviveWeaponPropSlot.SWPS_MainShootWeapon2,   -- Primary weapon 2
    UGCLuaSurviveWeaponPropSlot_SWPS_SubShootWeapon     = UGCLuaGlobalDefine.Enum_UGCLuaSurviveWeaponPropSlot.SWPS_SubShootWeapon,     -- Pistol / sub weapon
    UGCLuaSurviveWeaponPropSlot_SWPS_MeleeWeapon        = UGCLuaGlobalDefine.Enum_UGCLuaSurviveWeaponPropSlot.SWPS_MeleeWeapon,        -- Melee weapon
    UGCLuaSurviveWeaponPropSlot_SWPS_HandProp           = UGCLuaGlobalDefine.Enum_UGCLuaSurviveWeaponPropSlot.SWPS_HandProp,           -- Throwable
    UGCLuaSurviveWeaponPropSlot_SWPS_TempSpecialWeapon  = UGCLuaGlobalDefine.Enum_UGCLuaSurviveWeaponPropSlot.SWPS_TempSpecialWeapon,  -- Temporary special weapon
    UGCLuaSurviveWeaponPropSlot_SWPS_ShiftGrenadeWeapon = UGCLuaGlobalDefine.Enum_UGCLuaSurviveWeaponPropSlot.SWPS_ShiftGrenadeWeapon, -- Shift grenade weapon
    UGCLuaSurviveWeaponPropSlot_SWPS_VehicleWeapon      = UGCLuaGlobalDefine.Enum_UGCLuaSurviveWeaponPropSlot.SWPS_VehicleWeapon,      -- Vehicle weapon
    UGCLuaSurviveWeaponPropSlot_SWPS_Max                = UGCLuaGlobalDefine.Enum_UGCLuaSurviveWeaponPropSlot.SWPS_Max,                -- Max value
}

UGCLuaWeaponPropertyName = {
    UGCLuaWeaponPropertyName_AccessoriesVRecoilFactor                   = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.AccessoriesVRecoilFactor,                   -- Vertical recoil factor
    UGCLuaWeaponPropertyName_AccessoriesRecoveryFactor                  = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.AccessoriesRecoveryFactor,                  -- Recovery factor
    UGCLuaWeaponPropertyName_AccessoriesHRecoilFactor                   = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.AccessoriesHRecoilFactor,                   -- Horizontal recoil factor
    UGCLuaWeaponPropertyName_AnimationKick                              = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.AnimationKick,                              -- Animation kick
    UGCLuaWeaponPropertyName_RecoilKick                                 = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.RecoilKick,                                 -- Recoil kick
    UGCLuaWeaponPropertyName_RecoilKickADS                              = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.RecoilKickADS,                              -- ADS recoil kick
    UGCLuaWeaponPropertyName_FireAnimationRate                          = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.FireAnimationRate,                          -- Fire animation rate
    UGCLuaWeaponPropertyName_ShotGunVerticalSpread                      = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.ShotGunVerticalSpread,                      -- Shotgun vertical spread
    UGCLuaWeaponPropertyName_ShotGunHorizontalSpread                    = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.ShotGunHorizontalSpread,                    -- Shotgun horizontal spread
    UGCLuaWeaponPropertyName_GameDeviationFactor                        = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.GameDeviationFactor,                        -- Game deviation factor
    UGCLuaWeaponPropertyName_GameDeviationAccuracy                      = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.GameDeviationAccuracy,                      -- Game deviation accuracy
    UGCLuaWeaponPropertyName_AccessoriesDeviationFactor                 = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.AccessoriesDeviationFactor,                 -- Accessories deviation factor
    UGCLuaWeaponPropertyName_PreFireTime                                = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.PreFireTime,                                -- Pre-fire time
    UGCLuaWeaponPropertyName_PreFireAnimScale                           = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.PreFireAnimScale,                           -- Pre-fire anim scale
    UGCLuaWeaponPropertyName_PostFireTime                               = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.PostFireTime,                               -- Post-fire time
    UGCLuaWeaponPropertyName_PostReloadTime                             = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.PostReloadTime,                             -- Post-reload time
    UGCLuaWeaponPropertyName_ShootInterval                              = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.ShootInterval,                              -- Shoot interval
    UGCLuaWeaponPropertyName_BurstShootInterval                         = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.BurstShootInterval,                         -- Burst shoot interval
    UGCLuaWeaponPropertyName_ReloadTime                                 = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.ReloadTime,                                 -- Reload time
    UGCLuaWeaponPropertyName_ReloadTimeTactical                         = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.ReloadTimeTactical,                         -- Tactical reload time
    UGCLuaWeaponPropertyName_ReloadTimeMagOut                           = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.ReloadTimeMagOut,                           -- Reload mag out time
    UGCLuaWeaponPropertyName_ReloadTimeMagIn                            = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.ReloadTimeMagIn,                            -- Reload mag in time
    UGCLuaWeaponPropertyName_ReloadDurationStart                        = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.ReloadDurationStart,                        -- Reload duration start
    UGCLuaWeaponPropertyName_ReloadDurationLoop                         = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.ReloadDurationLoop,                         -- Reload duration loop
    UGCLuaWeaponPropertyName_ReloadRate                                 = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.ReloadRate,                                 -- Reload rate
    UGCLuaWeaponPropertyName_WeaponAimInTime                            = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.WeaponAimInTime,                            -- Weapon aim in time
    UGCLuaWeaponPropertyName_WeaponAimPitchRate                         = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.WeaponAimPitchRate,                         -- Weapon aim pitch rate
    UGCLuaWeaponPropertyName_WeaponAimYawRate                           = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.WeaponAimYawRate,                           -- Weapon aim yaw rate
    UGCLuaWeaponPropertyName_GameMotionPitchRate                        = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.GameMotionPitchRate,                        -- Game motion pitch rate
    UGCLuaWeaponPropertyName_GameMotionYawRate                          = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.GameMotionYawRate,                          -- Game motion yaw rate
    UGCLuaWeaponPropertyName_SensitiveFirePitchRate                     = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.SensitiveFirePitchRate,                     -- Sensitive fire pitch rate
    UGCLuaWeaponPropertyName_SensitiveFireYawRate                       = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.SensitiveFireYawRate,                       -- Sensitive fire yaw rate
    UGCLuaWeaponPropertyName_BaseImpactDamage                           = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.BaseImpactDamage,                           -- Base impact damage
    UGCLuaWeaponPropertyName_WeaponHitPartCoffHead                      = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.WeaponHitPartCoffHead,                      -- Hit part coefficient head
    UGCLuaWeaponPropertyName_WeaponHitPartCoffHand                      = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.WeaponHitPartCoffHand,                      -- Hit part coefficient hand
    UGCLuaWeaponPropertyName_WeaponHitPartCoffFoot                      = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.WeaponHitPartCoffFoot,                      -- Hit part coefficient foot
    UGCLuaWeaponPropertyName_WeaponHitPartCoffBody                      = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.WeaponHitPartCoffBody,                      -- Hit part coefficient body
    UGCLuaWeaponPropertyName_WeaponHitPartCoffLimbs                     = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.WeaponHitPartCoffLimbs,                     -- Hit part coefficient limbs
    UGCLuaWeaponPropertyName_VehicleDamageScale                         = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.VehicleDamageScale,                         -- Vehicle damage scale
    UGCLuaWeaponPropertyName_RangeModifier                              = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.RangeModifier,                              -- Range modifier
    UGCLuaWeaponPropertyName_ReferenceDistance                          = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.ReferenceDistance,                          -- Reference distance
    UGCLuaWeaponPropertyName_IgnoreRangeAttenuatDis                     = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.IgnoreRangeAttenuatDis,                     -- Ignore range attenuation distance
    UGCLuaWeaponPropertyName_ForegripParam                              = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.ForegripParam,                              -- Foregrip param
    UGCLuaWeaponPropertyName_MagParam                                   = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.MagParam,                                   -- Mag param
    UGCLuaWeaponPropertyName_ReloadAnimSlot                             = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.ReloadAnimSlot,                             -- Reload anim slot
    UGCLuaWeaponPropertyName_MaxBulletNumInOneClip                      = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.MaxBulletNumInOneClip,                      -- Max bullet num in one clip
    UGCLuaWeaponPropertyName_ExtendMaxBulletNumInOneClip                = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.ExtendMaxBulletNumInOneClip,                -- Extend max bullet num in one clip
    UGCLuaWeaponPropertyName_WeaponBodyLength                           = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.WeaponBodyLength,                           -- Weapon body length
    UGCLuaWeaponPropertyName_BulletRange                                = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.BulletRange,                                -- Bullet range
    UGCLuaWeaponPropertyName_BulletFireSpeed                            = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.BulletFireSpeed,                            -- Bullet fire speed
    UGCLuaWeaponPropertyName_ExtraHitPerformScale                       = UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName.ExtraHitPerformScale,                       -- Extra hit perform scale
}

SelectorDeviceIconType = {
    SelectorDeviceIconType_Default   = UGCLuaGlobalDefine.Enum_SelectorDeviceIconType.Default,   -- Default
    SelectorDeviceIconType_Red       = UGCLuaGlobalDefine.Enum_SelectorDeviceIconType.Red,       -- Red
    SelectorDeviceIconType_Orange    = UGCLuaGlobalDefine.Enum_SelectorDeviceIconType.Orange,    -- Orange
    SelectorDeviceIconType_Yellow    = UGCLuaGlobalDefine.Enum_SelectorDeviceIconType.Yellow,    -- Yellow
    SelectorDeviceIconType_Green     = UGCLuaGlobalDefine.Enum_SelectorDeviceIconType.Green,     -- Green
    SelectorDeviceIconType_BlueGreen = UGCLuaGlobalDefine.Enum_SelectorDeviceIconType.BlueGreen, -- Blue-green
    SelectorDeviceIconType_Blue      = UGCLuaGlobalDefine.Enum_SelectorDeviceIconType.Blue,      -- Blue
    SelectorDeviceIconType_Purple    = UGCLuaGlobalDefine.Enum_SelectorDeviceIconType.Purple,    -- Purple
}

SelectorDeviceTextColorType = {
    SelectorDeviceTextColorType_White     = UGCLuaGlobalDefine.Enum_SelectorDeviceTextColorType.White,     -- White
    SelectorDeviceTextColorType_Red       = UGCLuaGlobalDefine.Enum_SelectorDeviceTextColorType.Red,       -- Red
    SelectorDeviceTextColorType_Orange    = UGCLuaGlobalDefine.Enum_SelectorDeviceTextColorType.Orange,    -- Orange
    SelectorDeviceTextColorType_Yellow    = UGCLuaGlobalDefine.Enum_SelectorDeviceTextColorType.Yellow,    -- Yellow
    SelectorDeviceTextColorType_Green     = UGCLuaGlobalDefine.Enum_SelectorDeviceTextColorType.Green,     -- Green
    SelectorDeviceTextColorType_BlueGreen = UGCLuaGlobalDefine.Enum_SelectorDeviceTextColorType.BlueGreen, -- Blue-green
    SelectorDeviceTextColorType_Blue      = UGCLuaGlobalDefine.Enum_SelectorDeviceTextColorType.Blue,      -- Blue
    SelectorDeviceTextColorType_Purple    = UGCLuaGlobalDefine.Enum_SelectorDeviceTextColorType.Purple,    -- Purple
}

DeviceDragType = {
    DistanceNoChangeBetweenCamera = 0,
    AlongRelativePlaneX = 1,
    AlongRelativePlaneY = 2,
    AlongRelativePlaneZ = 3,
}

NativeControlType = {
    NativeControlType_MiniMap         = 1,       -- Mini map
    NativeControlType_Backpack        = 2,       -- Backpack
    NativeControlType_CircleTips      = 3,       -- Circle tips
    NativeControlType_TeamUI          = 4,       -- Team UI
    NativeControlType_PlayerHPUI      = 5,       -- Player HP UI
    NativeControlType_BearingInfoUI   = 6,       -- Bearing info UI
    NativeControlType_EquipmentBar    = 7,       -- Equipment bar
    NativeControlType_SurvivingPlayer = 8,       -- Surviving player count
    NativeControlType_KillPlayerNum   = 9,       -- Kill player count
    NativeControlType_VehicleExit     = 10,      -- Vehicle exit button
    NativeControlType_Climb           = 11,      -- Climb button
    NativeControlType_Jump            = 12,      -- Jump button
    NativeControlType_Crouch          = 13,      -- Crouch button
    NativeControlType_Prone           = 14,      -- Prone button
    NativeControlType_Consumable      = 15,      -- Consumable panel
    NativeControlType_Grenade         = 16,      -- Grenade panel
    NativeControlType_SkillPanel      = 17,      -- Skill panel
    NativeControlType_FireButton      = 18,      -- Fire button
    NativeControlType_ReloadButton    = 19,      -- Reload button
    NativeControlType_AimButton       = 20,      -- Aim button
    NativeControlType_LeanButton      = 21,      -- Lean button
    NativeControlType_VehicleLeanOut  = 22,      -- Vehicle lean out
    NativeControlType_CancelGrenade   = 23,      -- Cancel grenade
    NativeControlType_PMode           = 24,      -- P mode
    NativeControlType_QuickSign       = 25,      -- Quick sign
    NativeControlType_ChatPanel       = 26,      -- Chat panel
    NativeControlType_EmotePanel      = 27,      -- Emote panel
    NativeControlType_PropShopEntry   = 28,      -- Prop shop entry
    NativeControlType_MoveJoystick    = 29,      -- Move joystick
    NativeControlType_CameraRotation  = 30,      -- Camera rotation
}

EAttachmentRule = {
    KeepRelative = 0, -- /** Keeps current relative transform as the relative transform to the new parent. */
    KeepWorld = 1,    -- /** Automatically calculates the relative transform such that the attached component maintains the same world transform. */
    SnapToTarget = 2, -- /** Snaps transform to the attach point */
}

--- Rules for preserving an Actor transform when detaching from its parent.
--- Unlike EAttachmentRule, detachment has no SnapToTarget option.
---@class EDetachmentRule
EDetachmentRule = {
    KeepRelative = 0, -- Keep the current parent-relative transform as the new world transform.
    KeepWorld = 1,    -- Preserve the current world transform when detaching.
}

ETouchIndex = {
    Touch1 = 0,
    Touch2 = 1,
    Touch3 = 2,
    Touch4 = 3,
    Touch5 = 4,
    Touch6 = 5,
    Touch7 = 6,
    Touch8 = 7,
    Touch9 = 8,
    Touch10 = 9,
}

--- Camera mode (Client-only CameraAPI)
---@class CameraMode
CameraMode = {
    CM_FirstPerson = UGCLuaGlobalDefine.Enum_CameraMode.CM_FirstPerson, -- First-person camera
    CM_ThirdPerson = UGCLuaGlobalDefine.Enum_CameraMode.CM_ThirdPerson, -- Third-person camera
    CM_Free        = UGCLuaGlobalDefine.Enum_CameraMode.CM_Free,        -- Free camera
}

--- AI path following completion result (mirrors UE EPathFollowingResult::Type).
--- Used by AIController:OnMoveCompleted callback.
---@class PathFollowingResult
PathFollowingResult = {
    Success = UGCLuaGlobalDefine.Enum_PathFollowingResult.Success, -- Reached destination
    Blocked = UGCLuaGlobalDefine.Enum_PathFollowingResult.Blocked, -- Movement was blocked
    OffPath = UGCLuaGlobalDefine.Enum_PathFollowingResult.OffPath, -- Agent is not on path
    Aborted = UGCLuaGlobalDefine.Enum_PathFollowingResult.Aborted, -- Aborted and stopped (failure)
    Invalid = UGCLuaGlobalDefine.Enum_PathFollowingResult.Invalid, -- Request was invalid
}

--- AI path following request result (mirrors UE EPathFollowingRequestResult::Type).
--- Returned by AIController:MoveTo and related APIs.
---@class PathFollowingRequestResult
PathFollowingRequestResult = {
    Failed            = UGCLuaGlobalDefine.Enum_PathFollowingRequestResult.Failed,            -- Move request failed
    AlreadyAtGoal     = UGCLuaGlobalDefine.Enum_PathFollowingRequestResult.AlreadyAtGoal,     -- Already at goal, no movement needed
    RequestSuccessful = UGCLuaGlobalDefine.Enum_PathFollowingRequestResult.RequestSuccessful, -- Move request accepted and being processed
}

--- AI path following current status (mirrors UE EPathFollowingStatus::Type).
--- Used to query the current path following state of an AIController.
---@class PathFollowingStatus
PathFollowingStatus = {
    Idle    = UGCLuaGlobalDefine.Enum_PathFollowingStatus.Idle,    -- No requests
    Waiting = UGCLuaGlobalDefine.Enum_PathFollowingStatus.Waiting, -- Request with incomplete path, will start after UpdateMove()
    Paused  = UGCLuaGlobalDefine.Enum_PathFollowingStatus.Paused,  -- Request paused, will continue after ResumeMove()
    Moving  = UGCLuaGlobalDefine.Enum_PathFollowingStatus.Moving,  -- Following path
}

--- Whether a character can step up onto / stand on a component (mirrors UE ECanBeCharacterBase).
--- Used by PrimitiveComponent.CanCharacterStepUpOn. Not replicated: set it on both DS and Client.
---@class CanBeCharacterBase
CanBeCharacterBase = {
    ECB_No    = UGCLuaGlobalDefine.Enum_CanBeCharacterBase.ECB_No,    -- Cannot step up / stand on
    ECB_Yes   = UGCLuaGlobalDefine.Enum_CanBeCharacterBase.ECB_Yes,   -- Can step up / stand on
    ECB_Owner = UGCLuaGlobalDefine.Enum_CanBeCharacterBase.ECB_Owner, -- Decided by owner actor (Pawn uses CanBeBaseForCharacter)
}


CharacterBoneName = {
    -- Spine
    CharacterBoneName_pelvis   = UGCLuaGlobalDefine.Enum_CharacterBoneName.pelvis,
    CharacterBoneName_spine_01 = UGCLuaGlobalDefine.Enum_CharacterBoneName.spine_01,
    CharacterBoneName_spine_02 = UGCLuaGlobalDefine.Enum_CharacterBoneName.spine_02,
    CharacterBoneName_spine_03 = UGCLuaGlobalDefine.Enum_CharacterBoneName.spine_03,
    CharacterBoneName_neck_01  = UGCLuaGlobalDefine.Enum_CharacterBoneName.neck_01,
    CharacterBoneName_head     = UGCLuaGlobalDefine.Enum_CharacterBoneName.head,

    -- Left arm
    CharacterBoneName_upperarm_l  = UGCLuaGlobalDefine.Enum_CharacterBoneName.upperarm_l,
    CharacterBoneName_lowerarm_l  = UGCLuaGlobalDefine.Enum_CharacterBoneName.lowerarm_l,
    CharacterBoneName_hand_l      = UGCLuaGlobalDefine.Enum_CharacterBoneName.hand_l,
    CharacterBoneName_thumb_01_l  = UGCLuaGlobalDefine.Enum_CharacterBoneName.thumb_01_l,
    CharacterBoneName_thumb_02_l  = UGCLuaGlobalDefine.Enum_CharacterBoneName.thumb_02_l,
    CharacterBoneName_thumb_03_l  = UGCLuaGlobalDefine.Enum_CharacterBoneName.thumb_03_l,
    CharacterBoneName_index_01_l  = UGCLuaGlobalDefine.Enum_CharacterBoneName.index_01_l,
    CharacterBoneName_index_02_l  = UGCLuaGlobalDefine.Enum_CharacterBoneName.index_02_l,
    CharacterBoneName_index_03_l  = UGCLuaGlobalDefine.Enum_CharacterBoneName.index_03_l,
    CharacterBoneName_middle_01_l = UGCLuaGlobalDefine.Enum_CharacterBoneName.middle_01_l,
    CharacterBoneName_middle_02_l = UGCLuaGlobalDefine.Enum_CharacterBoneName.middle_02_l,
    CharacterBoneName_middle_03_l = UGCLuaGlobalDefine.Enum_CharacterBoneName.middle_03_l,
    CharacterBoneName_ring_01_l   = UGCLuaGlobalDefine.Enum_CharacterBoneName.ring_01_l,
    CharacterBoneName_ring_02_l   = UGCLuaGlobalDefine.Enum_CharacterBoneName.ring_02_l,
    CharacterBoneName_ring_03_l   = UGCLuaGlobalDefine.Enum_CharacterBoneName.ring_03_l,
    CharacterBoneName_pinky_01_l  = UGCLuaGlobalDefine.Enum_CharacterBoneName.pinky_01_l,
    CharacterBoneName_pinky_02_l  = UGCLuaGlobalDefine.Enum_CharacterBoneName.pinky_02_l,
    CharacterBoneName_pinky_03_l  = UGCLuaGlobalDefine.Enum_CharacterBoneName.pinky_03_l,

    -- Right arm
    CharacterBoneName_upperarm_r  = UGCLuaGlobalDefine.Enum_CharacterBoneName.upperarm_r,
    CharacterBoneName_lowerarm_r  = UGCLuaGlobalDefine.Enum_CharacterBoneName.lowerarm_r,
    CharacterBoneName_hand_r      = UGCLuaGlobalDefine.Enum_CharacterBoneName.hand_r,
    CharacterBoneName_thumb_01_r  = UGCLuaGlobalDefine.Enum_CharacterBoneName.thumb_01_r,
    CharacterBoneName_thumb_02_r  = UGCLuaGlobalDefine.Enum_CharacterBoneName.thumb_02_r,
    CharacterBoneName_thumb_03_r  = UGCLuaGlobalDefine.Enum_CharacterBoneName.thumb_03_r,
    CharacterBoneName_index_01_r  = UGCLuaGlobalDefine.Enum_CharacterBoneName.index_01_r,
    CharacterBoneName_index_02_r  = UGCLuaGlobalDefine.Enum_CharacterBoneName.index_02_r,
    CharacterBoneName_index_03_r  = UGCLuaGlobalDefine.Enum_CharacterBoneName.index_03_r,
    CharacterBoneName_middle_01_r = UGCLuaGlobalDefine.Enum_CharacterBoneName.middle_01_r,
    CharacterBoneName_middle_02_r = UGCLuaGlobalDefine.Enum_CharacterBoneName.middle_02_r,
    CharacterBoneName_middle_03_r = UGCLuaGlobalDefine.Enum_CharacterBoneName.middle_03_r,
    CharacterBoneName_ring_01_r   = UGCLuaGlobalDefine.Enum_CharacterBoneName.ring_01_r,
    CharacterBoneName_ring_02_r   = UGCLuaGlobalDefine.Enum_CharacterBoneName.ring_02_r,
    CharacterBoneName_ring_03_r   = UGCLuaGlobalDefine.Enum_CharacterBoneName.ring_03_r,
    CharacterBoneName_pinky_01_r  = UGCLuaGlobalDefine.Enum_CharacterBoneName.pinky_01_r,
    CharacterBoneName_pinky_02_r  = UGCLuaGlobalDefine.Enum_CharacterBoneName.pinky_02_r,
    CharacterBoneName_pinky_03_r  = UGCLuaGlobalDefine.Enum_CharacterBoneName.pinky_03_r,

    -- Legs
    CharacterBoneName_thigh_l = UGCLuaGlobalDefine.Enum_CharacterBoneName.thigh_l,
    CharacterBoneName_calf_l  = UGCLuaGlobalDefine.Enum_CharacterBoneName.calf_l,
    CharacterBoneName_foot_l  = UGCLuaGlobalDefine.Enum_CharacterBoneName.foot_l,
    CharacterBoneName_ball_l  = UGCLuaGlobalDefine.Enum_CharacterBoneName.ball_l,
    CharacterBoneName_thigh_r = UGCLuaGlobalDefine.Enum_CharacterBoneName.thigh_r,
    CharacterBoneName_calf_r  = UGCLuaGlobalDefine.Enum_CharacterBoneName.calf_r,
    CharacterBoneName_foot_r  = UGCLuaGlobalDefine.Enum_CharacterBoneName.foot_r,
    CharacterBoneName_ball_r  = UGCLuaGlobalDefine.Enum_CharacterBoneName.ball_r,
}


CharacterSocketName = {
    CharacterSocketName_WeaponSocket_1 =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.WeaponSocket_1,
    CharacterSocketName_Throw_Socket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.Throw_Socket,
    CharacterSocketName_hand_rSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.hand_rSocket,
    CharacterSocketName_hand_lSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.hand_lSocket,
    CharacterSocketName_item_lSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.item_lSocket,
    CharacterSocketName_item_lSocket_0 =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.item_lSocket_0,
    CharacterSocketName_item_rSocket_2035 =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.item_rSocket_2035,
    CharacterSocketName_Mag =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.Mag,
    CharacterSocketName_Mag_R =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.Mag_R,
    CharacterSocketName_WeaponPointShield =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.WeaponPointShield,
    CharacterSocketName_interactSocket_r =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.interactSocket_r,
    CharacterSocketName_SpikeTrap_Socket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.SpikeTrap_Socket,
    CharacterSocketName_MeleeWeapon =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.MeleeWeapon,

    CharacterSocketName_MainWeaponBackSocketL =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.MainWeaponBackSocketL,
    CharacterSocketName_MainWeaponBackSocketR =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.MainWeaponBackSocketR,
    CharacterSocketName_MainWeaponBackSocketL_NoBag =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.MainWeaponBackSocketL_NoBag,
    CharacterSocketName_MainWeaponBackSocketR_NoBag =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.MainWeaponBackSocketR_NoBag,
    CharacterSocketName_SubWeaponBackSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.SubWeaponBackSocket,

    CharacterSocketName_HelmetSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.HelmetSocket,
    CharacterSocketName_FaceSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.FaceSocket,
    CharacterSocketName_BeardSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.BeardSocket,
    CharacterSocketName_FirstPersonCameraPoint =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.FirstPersonCameraPoint,

    CharacterSocketName_FPPSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.FPPSocket,
    CharacterSocketName_FPSAPistolSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.FPSAPistolSocket,
    CharacterSocketName_FPSARifleSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.FPSARifleSocket,
    CharacterSocketName_neck_01Socket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.neck_01Socket,

    CharacterSocketName_Parachute_Socket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.Parachute_Socket,
    CharacterSocketName_BackpackPetScoket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.BackpackPetScoket,
    CharacterSocketName_Pendant_Socket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.Pendant_Socket,
    CharacterSocketName_Ring =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.Ring,
    CharacterSocketName_ClothSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.ClothSocket,
    CharacterSocketName_DriverVehMesh =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.DriverVehMesh,
    CharacterSocketName_Skill_Device_Socket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.Skill_Device_Socket,

    CharacterSocketName_VH_HitBoxSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.VH_HitBoxSocket,
    CharacterSocketName_NearDead_HitBoxSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.NearDead_HitBoxSocket,

    CharacterSocketName_calf_lSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.calf_lSocket,
    CharacterSocketName_calf_rSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.calf_rSocket,
    CharacterSocketName_calf_lSocket_Effect =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.calf_lSocket_Effect,
    CharacterSocketName_calf_rSocket_Effect =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.calf_rSocket_Effect,
    CharacterSocketName_upperarm_lSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.upperarm_lSocket,
    CharacterSocketName_UpperArmSocket_R =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.UpperArmSocket_R,
    CharacterSocketName_LeftWaistSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.LeftWaistSocket,
    CharacterSocketName_foot_lSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.foot_lSocket,
    CharacterSocketName_foot_rSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.foot_rSocket,

    CharacterSocketName_spine_03Socket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.spine_03Socket,
    CharacterSocketName_RootSocket =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.RootSocket,
    CharacterSocketName_RootSocket_0 =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.RootSocket_0,
    CharacterSocketName_RootSocket_1 =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.RootSocket_1,
    CharacterSocketName_RootSocket_02 =
        UGCLuaGlobalDefine.Enum_CharacterSocketName.RootSocket_02,
}