local ClientEVOConfig = {
  bInit = false,
  bLevelStreamingBackEndEnable = false,
  SavedLevelStreamingRemoveLevelTimeLimit = 5,
  SavedLevelStreamingOptSpecialApplyWorldOffsetActorNum = 1,
  SavedLevelStreamingOptSpecialHeavyRegComponentNum = 1,
  SavedLevelStreamingOptSpecialRegComponentTimeLimit = 3,
  SavedLevelStreamingOptSpecialUnRegComponentTimeLimit = 3,
  SavedLevelStreamingOptSpecialHeavyUnRegComponentNum = 1,
  SavedLevelStreamingOptSpecialRouteActorEndPlayGranularity = 10,
  SavedLevelStreamingOptSpecialComponentsRegistrationGranularity = 10,
  SavedLevelStreamingOptSpecialHISMPhysicBodyIncrementClearNum = 150,
  SavedLevelStreamingOptSpecialHeavyActorBeginPlayNum = 0,
  SavedLevelStreamingOptSpecialRouteActorInitializeGranularity = 3,
  SavedLevelStreamingOptSpecialLimitPreformStep = 1,
  SavedLevelStreamingOptSpecialSortLevlFromPriority = 1,
  SavedLevelStreamingOptSpecialIncrementalUnregisterComponents = 1,
  SavedLevelStreamingOptSpecialMaxUnLoadLevelGCMemoryThresholds = 50000,
  SavedLevelStreamingOptSpecialBodyStreamingCountPerTimeLimit = 20,
  SavedLevelStreamingOptSpecialBodyStreamingTimeLimit = 5,
  SavedSuperFrameEnableUpdateLevelStreamingInUpdateCamera = 0,
  bTickAsyncLoadingSetInFighting = false,
  bTickAsyncLoadingBackEndEnable = false,
  SavedTickAsyncLoadingOptSpecialMaxHeavyObjectPostLoadCost = 32768,
  SavedTickAsyncLoadingOptSpecialIncrementalUpdateDistanceVolumeGranularity = 100,
  SavedTickAsyncLoadingOptSpecialPostLoadThreadEnabled = 1,
  SavedTickAsyncLoadingOptSpecialTexCubeMaxSizeLimit = 32,
  SavedLightOptSwitcher = 0,
  CloudLightLossyOptEnable = nil,
  CloudLightCommonOptEnable = nil,
  bLightOptAppliedInFighting = false,
  bLightLossyOptCurrentEnabled = false,
  bLightOptForceEnableByGM = false,
  SavedLightOptCmdValues = {},
  ManagedTickNonTypicalModList = {
    21001,
    21002,
    21003,
    21004,
    880047,
    40001,
    40002,
    40003,
    40004,
    40005,
    40006,
    26000,
    12050,
    12051,
    12054,
    12055,
    999008,
    999009,
    12021,
    12022,
    12023,
    12024,
    12025,
    12026,
    12027,
    12028,
    12029,
    12030,
    12031,
    12032,
    12033,
    12034,
    12035,
    12036,
    12037,
    12038,
    12039,
    12040,
    12041,
    12042,
    12043,
    12044,
    12045,
    12101,
    12102,
    12103,
    12104,
    12105,
    12106,
    12107,
    12108,
    12109,
    12201,
    12202,
    12203,
    12204,
    12205,
    12206,
    12207,
    12208,
    12209
  },
  bEnterBorderland = false,
  BorderlandModList = {
    2301,
    2302,
    2303,
    2304,
    2305,
    2306,
    2311,
    2312,
    2313,
    2314,
    2315,
    2316,
    90016,
    90017,
    90018,
    90019,
    90020,
    90021
  },
  bEnterTMod = false,
  TModList = {
    23001,
    23004,
    23005,
    23006,
    23007,
    23008,
    23009,
    23010,
    23012,
    23013,
    23104,
    23015,
    23016,
    23017,
    23018,
    23019,
    23020,
    91067,
    91068,
    91069,
    91070,
    91071,
    91072,
    91073,
    91074
  },
  bEnterSingleMode = false,
  SingModlList = {
    24005,
    24006,
    24007,
    24008,
    24009,
    24010
  },
  SavedUseLowFakeLandScape = 0,
  bUseLowFakeLandScapeBackEndEnable = false,
  bEnableSlateGICloud = false,
  bEnableInvalidationPanelsCloud = false,
  bEnableSlateVerifyHitTestVisibilityCloud = false,
  bEnableRemoveVolatilePrepassFlagCloud = false,
  bEnableFixSlateFastPathHitTestCloud = false,
  MaxFontAtlasPagesBeforeFlushRequest = 1,
  bForceOneFontAtlasPage = false,
  bEnableUIDynamicBatch = false,
  bSlateThrottleSwitchEnabled = false,
  bEnableSlateThrottle = false,
  bSlateGIThrottleSwitchEnabled = false,
  bEnableSlateGIThrottle = false,
  bLightSlateGIThrottleSwitchEnabled = false,
  bEnableLightSlateGIThrottle = false,
  bUseLightSlateGIThrottleWhiteList = true,
  bLightWidgetTickFrequencySwitchEnabled = false,
  bEnableLightWidgetTickFrequency = false,
  bUseLightWidgetTickFrequencyWhiteList = true,
  bWidgetTickFrequencySwitchEnabled = false,
  bEnableWidgetTickFrequency = false,
  bUseWidgetTickFrequencyWhiteList = true,
  bSlateGIThrottleSetByGM = false,
  bSlateFrequencySetByGM = false,
  bEnableSlateLayoutCache = false,
  bEnableSlateLayoutCacheBackendValue = false,
  NewObjectPoolGCConfigValue = nil,
  TextureMipOffsetbackUp = -1,
  bEnableIOSPSOCache = false,
  NewObjectPoolAvailableMod = {
    BaseMod = true,
    Mecha = true,
    Atlantis = true,
    NewbieGame = true,
    TPlanPVE = true,
    CreativeBase = true,
    HeavyWeapon = true,
    Halloween4 = true,
    IceWorld3 = true,
    EasternRealm = true,
    Neon = true,
    ZNQ7th = true,
    SteamTrain = true,
    Egypt2 = true,
    TDM = false
  },
  LayoutCacheAvailableMod = {
    BaseMod = true,
    SteamTrain = true,
    TPlanPVE = true,
    PlanTF = true,
    Halloween5 = true,
    Escape = true,
    IceWorld4 = true,
    ZNQ8th = true
  },
  InvalidationPanelsAvailableMod = {
    TDM = false,
    PlanPH = false,
    SocialIsland = false
  },
  ActorSpawnQueueAvailableMod = {BaseMod = true, TPlanX = false},
  SlateGIAvailableMod = {
    CreativeBase = false,
    MainCity = false,
    SocialIsland = false,
    PlanPH = false,
    PlanCH = false,
    SingleTraining = false
  },
  bNeedDelayEnableSlateGI = false,
  bNewObjectPoolGCOptimizationEnable = false,
  bNewObjectPoolDefferedPhysicsState = false,
  bEnable400AnimationOptimization = false,
  bEnableNotRenderedParallelUpdateBackEnd = false,
  bEnableNotRenderedParallelUpdateApplied = false,
  bEnableRefreshBonesTickAnimationOptBackEnd = false,
  bEnableRefreshBonesTickAnimationOptApplied = false,
  DefaultJankCollectionTimeThresholdOnIni = 0,
  DefaultSleepTimeThodOnIni = 5.0E-4,
  DefaultSleepSlackTimeOnIni = 5.0E-4,
  CurrentWorldName = "",
  LastWorldName = "",
  CurrentModID = 0,
  CurrentModType = "",
  SlateThrottleExcludeModType = {BRTDM = true},
  SlateTickDownWhitList = {
    Baltic_Main = 1,
    FourMaps_Main = 1,
    PUBG_Desert = 1,
    DihorOtok_Main = 1,
    PUBG_Savage_Main = 1
  },
  SlateThrottleWhiteList = {Baltic_Main = 1, UEDPIE_1_Baltic_Main = 1},
  bUseSlateThrottleWhiteList = true,
  SlateGIThrottleWhiteList = {Baltic_Main = 1, UEDPIE_1_Baltic_Main = 1},
  bUseSlateGIThrottleWhiteList = true,
  bLevelEnd = false,
  bCallLoadingUIOpend = false,
  backupHLODScale = 1.0,
  CurrentBattleFPSLevel = 1,
  CollectorTimerID = 0,
  DefaultGCSweepTimeOnIni = 0,
  EnableGCSweepTimeModifiy_GCloud = 0,
  CloseGCWhitList = {
    AR_Library = 1,
    TD_FoolsDayBigHead_Factory = 1,
    TD_Factory_Depot_Main = 1,
    HP_City_Main = 1,
    TD_Ruins_Half = 1,
    TD_RushHour = 1,
    TD_Santorini = 1
  },
  BackUpbUseNewHole = -1,
  BakcUpNumVisibleComponents = 0,
  BackGrassUpdateIntervel = 5,
  bFirstEnterLobby = true,
  bOpenDevLog = false,
  ManagedTickSysFlagBackEnd = 0,
  bEnableActorSpawnQueueCloud = false,
  bEnableActorSpawnQueueLightOpt = false,
  bTextureGroupBiasApplied = false,
  CachedFlashFavorVerySmooth50Device = nil
}
local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")

function ClientEVOConfig.IsFlashFavorVerySmooth50Device()
  if ClientEVOConfig.CachedFlashFavorVerySmooth50Device ~= nil then
    return ClientEVOConfig.CachedFlashFavorVerySmooth50Device
  end
  local platformName = Client.GetDevicePlatformName()
  local DevicePlatformNameMacros = require("client.slua.config.ClientMacros.DevicePlatformNameMacros")
  local TCDeviceLevel = Client.GetTCDeviceLevel()
  local GraphicHelperUtil = require("client.slua.umg.NewSetting.GraphicsNew.GraphicHelperUtil")
  local IsFlashFavorEnabled = GraphicHelperUtil.IsFlashFavorEnabled()
  local IsScreenSizeOK = not (math.max(Client.GetPhysicalScreenWidth(), Client.GetPhysicalScreenHeight()) > 1900)
  local SuperFrameScaleFactorDownConfig = require("client.logic.client_evo_config.SuperFrameScaleFactorDownConfig")
  local TableUtil = require("common.table_util")
  local DeviceModel = Client.GetDeviceModel()
  local Soc = Client.GetLowerSOCModelAboveAndroid12()
  local IsHardWareOk = TableUtil.IsInTable(SuperFrameScaleFactorDownConfig.WhiteListDeviceModel, DeviceModel) or TableUtil.IsInTable(SuperFrameScaleFactorDownConfig.WhiteListSOC, Soc)
  local device_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.device_module)
  local OSMajorVersion = device_module:GetOSMajorVersion()
  local isOsVersionOk = 12 < OSMajorVersion
  IsHardWareOk = true
  isOsVersionOk = true
  IsScreenSizeOK = true
  log(bWriteLog and "IsFlashFavorVerySmooth50Device:IsFlashFavorEnabled:" .. tostring(IsFlashFavorEnabled) .. ",TCDeviceLevel:" .. tostring(TCDeviceLevel) .. ",IsScreenSizeOk:" .. tostring(IsScreenSizeOK) .. ",DeviceModel:" .. tostring(DeviceModel) .. ",Soc:" .. tostring(Soc) .. ",IsHardWareOk:" .. tostring(IsHardWareOk) .. ",isOsVersionOk:" .. tostring(isOsVersionOk))
  ClientEVOConfig.CachedFlashFavorVerySmooth50Device = IsFlashFavorEnabled and platformName == DevicePlatformNameMacros.Android and (TCDeviceLevel == 5 or TCDeviceLevel == 6) and IsScreenSizeOK and IsHardWareOk and isOsVersionOk
  return ClientEVOConfig.CachedFlashFavorVerySmooth50Device
end

function ClientEVOConfig.IsSuperFrameScaleFactorDownEnable()
  local EnableSuperFrameScaleFactorDown = HDmpveRemote.HDmpveRemoteConfigGetInt("EnableSuperFrameScaleFactorDown", 0)
  local platformName = Client.GetDevicePlatformName()
  local DevicePlatformNameMacros = require("client.slua.config.ClientMacros.DevicePlatformNameMacros")
  local TCDeviceLevel = Client.GetTCDeviceLevel()
  local GraphicHelperUtil = require("client.slua.umg.NewSetting.GraphicsNew.GraphicHelperUtil")
  local IsFlashFavorEnabled = GraphicHelperUtil.IsFlashFavorEnabled()
  log(bWriteLog and "IsSuperFrameScaleFactorDownEnable:CloudSwitch:" .. tostring(EnableSuperFrameScaleFactorDown) .. ",IsFlashFavorEnabled:" .. tostring(IsFlashFavorEnabled) .. ",TCDeviceLevel:" .. tostring(TCDeviceLevel))
  return 0 < EnableSuperFrameScaleFactorDown and IsFlashFavorEnabled and platformName == DevicePlatformNameMacros.Android and (TCDeviceLevel == 5 or TCDeviceLevel == 6)
end

function ClientEVOConfig.Init()
  if ClientEVOConfig.bInit == true then
    return
  end
  ClientEVOConfig.bInit = true
  ClientEVOConfig.CollectorTimerID = 0
  EventSystem:registEvent(EVENTTYPE_STATE, EVENTID_GAMESTATE_ON_PRE_BATTLE_RESULT, ClientEVOConfig.HandleOnPreBattleResult)
  EventSystem:registEvent(EVENTTYPE_ACCOUNT, EVENTID_BATTLE_RESULT_ON_START_PHASE, ClientEVOConfig.HandleOnBattleResultStartPase)
  EventSystem:registEvent(EVENTTYPE_ACCOUNT, EVENTID_BATTLE_RESULT_ON_END_PHASE, ClientEVOConfig.HandleOnBattleResultEndPase)
  EventSystem:registEvent(EVENTTYPE_LOBBY, EVENTID_LOADING_PRE_BEGIN, ClientEVOConfig.HandleOnLoadingPreBegin)
  EventSystem:registEvent(EVENTTYPE_LOBBY, EVENTID_LOADING_FINISH, ClientEVOConfig.HandleOnLoadingEnd)
  local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
  ClientEVOConfig.DefaultJankCollectionTimeThresholdOnIni = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableFloatValue("Jank.CollectionTimeThreshold")
  ClientEVOConfig.DefaultSleepTimeThodOnIni = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableFloatValue("Engine.GSleepTimeThod")
  ClientEVOConfig.DefaultSleepSlackTimeOnIni = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableFloatValue("Engine.GSleepSlackTimeThod")
  ClientEVOConfig.backupHLODScale = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableFloatValue("r.HLOD.DistanceScale")
  ClientEVOConfig.BackGrassUpdateIntervel = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.PowerOptSepcial.LandScapeSeries.GrassUpdateInterval")
  local LogicSettingGraphics = require("client.slua.logic.setting.logic_setting_graphics")
  local settingConfig = LogicSettingGraphics.GetSettingConfig()
  ClientEVOConfig.CurrentBattleFPSLevel = settingConfig.BattleFPS
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  if HDmpveRemote.HDmpveRemoteConfigGetInt("DisablePreloadInLobby", 0) == 1 then
    ClientEVOConfig.NewObjectPoolAvailableMod.NoviceGuidance = false
    ClientEVOConfig.NewObjectPoolAvailableMod.MainCity = false
    ClientEVOConfig.NewObjectPoolAvailableMod.PlanPH = false
  end
  ClientEVOConfig.MaxFontAtlasPagesBeforeFlushRequest = HDmpveRemote.HDmpveRemoteConfigGetInt("MaxFontAtlasPagesBeforeFlushRequest", 1)
  local CurConfigPageNum = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("Slate.MaxFontAtlasPagesBeforeFlushRequest")
  if CurConfigPageNum < ClientEVOConfig.MaxFontAtlasPagesBeforeFlushRequest then
    GameInstance:ExecuteCMD("Slate.MaxFontAtlasPagesBeforeFlushRequest", ClientEVOConfig.MaxFontAtlasPagesBeforeFlushRequest)
    log_shipping_client(string.format("[ClientEVOConfig] MaxFontAtlasPagesBeforeFlushRequest=%d", ClientEVOConfig.MaxFontAtlasPagesBeforeFlushRequest))
  end
  ClientEVOConfig.bForceOneFontAtlasPage = HDmpveRemote.HDmpveRemoteConfigGetBool("ForceOneFontAtlasPage", false)
  if ClientEVOConfig.bForceOneFontAtlasPage then
    ClientEVOConfig.MaxFontAtlasPagesBeforeFlushRequest = 1
    GameInstance:ExecuteCMD("Slate.MaxFontAtlasPagesBeforeFlushRequest", 1)
    log_shipping_client(string.format("[ClientEVOConfig] bForceOneFontAtlasPage=%s", tostring(ClientEVOConfig.bForceOneFontAtlasPage)))
  end
end

function ClientEVOConfig.ShouldEnableNotRenderedParallelUpdate()
  return ClientEVOConfig.bEnableNotRenderedParallelUpdateBackEnd and GameStatus.IsInFightingNotSocialNotMainCityNotHome()
end

function ClientEVOConfig.ToggleNotRenderedParallelUpdate(bEnable)
  local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
  local currentStatus = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("a.EnableNotRenderedParallelUpdate") or 0
  local bApplied = currentStatus == 1
  ClientEVOConfig.bEnableNotRenderedParallelUpdateApplied = bApplied
  if bEnable == bApplied then
    return
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  local value = bEnable and 1 or 0
  GameInstance:ExecuteCMD("a.IgnoreEvaluationPhaseSkipped", value)
  GameInstance:ExecuteCMD("a.EnableNotRenderedParallelUpdate", value)
  GameInstance:ExecuteCMD("a.SkipFlipWhenNoEvaluation", value)
  GameInstance:ExecuteCMD("a.UseSymmetricSwapForParallelEval", 0)
  ClientEVOConfig.bEnableNotRenderedParallelUpdateApplied = bEnable
  log_shipping_client(string.format("[AnimationOpt] EnableNotRenderedParallelUpdateApplied==%s", tostring(bEnable)))
end

function ClientEVOConfig.RefreshNotRenderedParallelUpdate()
  ClientEVOConfig.ToggleNotRenderedParallelUpdate(ClientEVOConfig.ShouldEnableNotRenderedParallelUpdate())
end

function ClientEVOConfig.ShouldEnableRefreshBonesTickAnimationOpt()
  return ClientEVOConfig.bEnableRefreshBonesTickAnimationOptBackEnd and GameStatus.IsInFightingNotSocialNotMainCityNotHome()
end

function ClientEVOConfig.ToggleRefreshBonesTickAnimationOpt(bEnable)
  local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
  local currentStatus = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("a.PrimeDormantSubInstanceUpdateCounter") or 0
  local bApplied = currentStatus ~= 0
  ClientEVOConfig.bEnableRefreshBonesTickAnimationOptApplied = bApplied
  if bEnable == bApplied then
    return
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  local value = bEnable and 1 or 0
  GameInstance:ExecuteCMD("a.PrimeDormantSubInstanceUpdateCounter", value)
  ClientEVOConfig.bEnableRefreshBonesTickAnimationOptApplied = bEnable
  log_shipping_client(string.format("[AnimationOpt] EnableRefreshBonesTickAnimationOptApplied==%s", tostring(bEnable)))
end

function ClientEVOConfig.RefreshBonesTickAnimationOpt()
  ClientEVOConfig.ToggleRefreshBonesTickAnimationOpt(ClientEVOConfig.ShouldEnableRefreshBonesTickAnimationOpt())
end

function ClientEVOConfig.Optimize_Android_32_OOM()
  local so_version = Client.GetAndroidSOVersion()
  if so_version ~= 32 or Client.GetMemorySize() >= 4 then
    return
  end
  if HDmpveRemote.HDmpveRemoteConfigGetIntSeprate32Bit("Android_Performance_32_OOM", 0) == 1 then
    local STExtraGameInstance = import("STExtraGameInstance")
    local GameInstance = STExtraGameInstance.GetInstance()
    GameInstance:ExecuteCMD("g.EnableNewObjectPool", 0)
  end
end

function ClientEVOConfig.Optimize_Android_Performance_Swap_2G()
  local mem = Client.GetMemorySize()
  if mem ~= 2 then
    return
  end
  local enable = HDmpveRemote.HDmpveRemoteConfigGetInt("Android_Performance_Swap", 0)
  if enable == 0 then
    return
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  GameInstance:ExecuteCMD("s.ActorChanCleanUpOptSpecial.Enable", 0)
  GameInstance:ExecuteCMD("am.EnablePreloadAnimInGame", 0)
  GameInstance:ExecuteCMD("p.LowMemorySizeConfig", 5)
  GameInstance:ExecuteCMD("diy.SetDecalBakingRTSize", 256)
  GameInstance:ExecuteCMD("Engine.TickGCWhenTravelWorld", 1)
  GameInstance:ExecuteCMD("r.LevelStreamingDistanceOffset", -15000)
end

function ClientEVOConfig.Optimize_Android_Performance_Swap_3G()
  local mem = Client.GetMemorySize()
  if mem ~= 3 then
    return
  end
  local enable = HDmpveRemote.HDmpveRemoteConfigGetInt("Android_Performance_Swap", 0)
  if enable == 0 then
    return
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  GameInstance:ExecuteCMD("r.Streaming.MaxTempMemoryAllowed", 4)
  GameInstance:ExecuteCMD("r.Streaming.DropMips", 2)
  GameInstance:ExecuteCMD("s.ActorChanCleanUpOptSpecial.Enable", 0)
  GameInstance:ExecuteCMD("am.EnablePreloadAnimInGame", 0)
  GameInstance:ExecuteCMD("p.LowMemorySizeConfig", 0)
  GameInstance:ExecuteCMD("diy.SetDecalBakingRTSize", 256)
  GameInstance:ExecuteCMD("Engine.TickGCWhenTravelWorld", 1)
  GameInstance:ExecuteCMD("r.LevelStreamingDistanceOffset", -15000)
end

function ClientEVOConfig.Optimize_Android_Performance_Swap_4G()
  local mem = Client.GetMemorySize()
  if mem ~= 4 then
    return
  end
  local enable = HDmpveRemote.HDmpveRemoteConfigGetInt("Android_Performance_Swap4", 0)
  if enable == 0 then
    return
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  GameInstance:ExecuteCMD("r.Streaming.MaxTempMemoryAllowed", 4)
  GameInstance:ExecuteCMD("r.Streaming.DropMips", 2)
  GameInstance:ExecuteCMD("s.ActorChanCleanUpOptSpecial.Enable", 0)
  GameInstance:ExecuteCMD("am.EnablePreloadAnimInGame", 0)
  GameInstance:ExecuteCMD("diy.SetDecalBakingRTSize", 256)
  GameInstance:ExecuteCMD("Engine.TickGCWhenTravelWorld", 1)
  GameInstance:ExecuteCMD("r.LevelStreamingDistanceOffset", -1500)
end

function ClientEVOConfig.DisableLevelStreamingOpt()
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  local GameplayStatics = import("GameplayStatics")
  GameplayStatics.FlushLevelStreaming(GameInstance)
  local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
  ClientEVOConfig.SavedLevelStreamingRemoveLevelTimeLimit = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.LevelStreamingRemoveLevelTimeLimit")
  ClientEVOConfig.SavedLevelStreamingOptSpecialApplyWorldOffsetActorNum = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableFloatValue("s.LevelStreamingOptSpecial.ApplyWorldOffsetActorNum")
  ClientEVOConfig.SavedLevelStreamingOptSpecialHeavyRegComponentNum = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.LevelStreamingOptSpecial.HeavyRegComponentNum")
  ClientEVOConfig.SavedLevelStreamingOptSpecialRegComponentTimeLimit = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.LevelStreamingOptSpecial.RegComponentTimeLimit")
  ClientEVOConfig.SavedLevelStreamingOptSpecialUnRegComponentTimeLimit = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.LevelStreamingOptSpecial.UnRegComponentTimeLimit")
  ClientEVOConfig.SavedLevelStreamingOptSpecialHeavyUnRegComponentNum = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.LevelStreamingOptSpecial.HeavyUnRegComponentNum")
  ClientEVOConfig.SavedLevelStreamingOptSpecialRouteActorEndPlayGranularity = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.LevelStreamingOptSpecial.RouteActorEndPlayGranularity")
  ClientEVOConfig.SavedLevelStreamingOptSpecialComponentsRegistrationGranularity = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.LevelStreamingOptSpecial.ComponentsRegistrationGranularity")
  ClientEVOConfig.SavedLevelStreamingOptSpecialHISMPhysicBodyIncrementClearNum = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.LevelStreamingOptSpecial.HISMPhysicBodyIncrementClearNum")
  ClientEVOConfig.SavedLevelStreamingOptSpecialHeavyActorBeginPlayNum = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.LevelStreamingOptSpecial.HeavyActorBeginPlayNum")
  ClientEVOConfig.SavedLevelStreamingOptSpecialRouteActorInitializeGranularity = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.LevelStreamingOptSpecial.RouteActorInitializeGranularity")
  ClientEVOConfig.SavedLevelStreamingOptSpecialLimitPreformStep = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.LevelStreamingOptSpecial.LimitPreformStep")
  ClientEVOConfig.SavedLevelStreamingOptSpecialSortLevlFromPriority = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.LevelStreamingOptSpecial.SortLevlFromPriority")
  ClientEVOConfig.SavedLevelStreamingOptSpecialIncrementalUnregisterComponents = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.LevelStreamingOptSpecial.IncrementalUnregisterComponents")
  ClientEVOConfig.SavedLevelStreamingOptSpecialMaxUnLoadLevelGCMemoryThresholds = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.LevelStreamingOptSpecial.MaxUnLoadLevelGCMemoryThresholds")
  ClientEVOConfig.SavedLevelStreamingOptSpecialBodyStreamingCountPerTimeLimit = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.LevelStreamingOptSpecial.BodyStreamingCountPerTimeLimit")
  ClientEVOConfig.SavedLevelStreamingOptSpecialBodyStreamingTimeLimit = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.LevelStreamingOptSpecial.BodyStreamingTimeLimit")
  ClientEVOConfig.SavedSuperFrameEnableUpdateLevelStreamingInUpdateCamera = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("r.SuperFrame.EnableUpdateLevelStreamingInUpdateCamera")
  GameInstance:ExecuteCMD("s.LevelStreamingRemoveLevelTimeLimit", 99)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.ApplyWorldOffsetActorNum", 0)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.HeavyRegComponentNum", 0)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.RegComponentTimeLimit", 0)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.UnRegComponentTimeLimit", 0)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.HeavyUnRegComponentNum", 0)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.RouteActorEndPlayGranularity", 0)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.ComponentsRegistrationGranularity", 0)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.HISMPhysicBodyIncrementClearNum", 0)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.HeavyActorBeginPlayNum", 0)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.RouteActorInitializeGranularity", 0)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.LimitPreformStep", 0)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.SortLevlFromPriority", 0)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.IncrementalUnregisterComponents", 0)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.MaxUnLoadLevelGCMemoryThresholds", 0)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.BodyStreamingCountPerTimeLimit", 999999)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.BodyStreamingTimeLimit", 0)
  GameInstance:ExecuteCMD("r.SuperFrame.EnableUpdateLevelStreamingInUpdateCamera", 0)
end

function ClientEVOConfig.EnableLevelStreamingOpt()
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  local GameplayStatics = import("GameplayStatics")
  GameplayStatics.FlushLevelStreaming(GameInstance)
  GameInstance:ExecuteCMD("s.LevelStreamingRemoveLevelTimeLimit", ClientEVOConfig.SavedLevelStreamingRemoveLevelTimeLimit)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.ApplyWorldOffsetActorNum", ClientEVOConfig.SavedLevelStreamingOptSpecialApplyWorldOffsetActorNum)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.HeavyRegComponentNum", ClientEVOConfig.SavedLevelStreamingOptSpecialHeavyRegComponentNum)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.RegComponentTimeLimit", ClientEVOConfig.SavedLevelStreamingOptSpecialRegComponentTimeLimit)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.UnRegComponentTimeLimit", ClientEVOConfig.SavedLevelStreamingOptSpecialUnRegComponentTimeLimit)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.HeavyUnRegComponentNum", ClientEVOConfig.SavedLevelStreamingOptSpecialHeavyUnRegComponentNum)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.RouteActorEndPlayGranularity", ClientEVOConfig.SavedLevelStreamingOptSpecialRouteActorEndPlayGranularity)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.ComponentsRegistrationGranularity", ClientEVOConfig.SavedLevelStreamingOptSpecialComponentsRegistrationGranularity)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.HISMPhysicBodyIncrementClearNum", ClientEVOConfig.SavedLevelStreamingOptSpecialHISMPhysicBodyIncrementClearNum)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.HeavyActorBeginPlayNum", ClientEVOConfig.SavedLevelStreamingOptSpecialHeavyActorBeginPlayNum)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.RouteActorInitializeGranularity", ClientEVOConfig.SavedLevelStreamingOptSpecialRouteActorInitializeGranularity)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.LimitPreformStep", ClientEVOConfig.SavedLevelStreamingOptSpecialLimitPreformStep)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.SortLevlFromPriority", ClientEVOConfig.SavedLevelStreamingOptSpecialSortLevlFromPriority)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.IncrementalUnregisterComponents", ClientEVOConfig.SavedLevelStreamingOptSpecialIncrementalUnregisterComponents)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.MaxUnLoadLevelGCMemoryThresholds", ClientEVOConfig.SavedLevelStreamingOptSpecialMaxUnLoadLevelGCMemoryThresholds)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.BodyStreamingCountPerTimeLimit", ClientEVOConfig.SavedLevelStreamingOptSpecialBodyStreamingCountPerTimeLimit)
  GameInstance:ExecuteCMD("s.LevelStreamingOptSpecial.BodyStreamingTimeLimit", ClientEVOConfig.SavedLevelStreamingOptSpecialBodyStreamingTimeLimit)
  GameInstance:ExecuteCMD("r.SuperFrame.EnableUpdateLevelStreamingInUpdateCamera", ClientEVOConfig.SavedSuperFrameEnableUpdateLevelStreamingInUpdateCamera)
end

function ClientEVOConfig.DisableTickAsyncLoadingOpt()
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  local GameplayStatics = import("GameplayStatics")
  local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
  ClientEVOConfig.SavedTickAsyncLoadingOptSpecialMaxHeavyObjectPostLoadCost = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.TickAsyncLoadingOptSpecial.MaxHeavyObjectPostLoadCost")
  ClientEVOConfig.SavedTickAsyncLoadingOptSpecialIncrementalUpdateDistanceVolumeGranularity = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.TickAsyncLoadingOptSpecial.IncrementalUpdateDistanceVolumeGranularity")
  ClientEVOConfig.SavedTickAsyncLoadingOptSpecialPostLoadThreadEnabled = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.TickAsyncLoadingOptSpecial.PostLoadThreadEnabled")
  ClientEVOConfig.SavedTickAsyncLoadingOptSpecialTexCubeMaxSizeLimit = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.TickAsyncLoadingOptSpecial.TexCubeMaxSizeLimit")
  GameInstance:ExecuteCMD("s.TickAsyncLoadingOptSpecial.MaxHeavyObjectPostLoadCost", 0)
  GameInstance:ExecuteCMD("s.TickAsyncLoadingOptSpecial.IncrementalUpdateDistanceVolumeGranularity", 0)
  GameInstance:ExecuteCMD("s.TickAsyncLoadingOptSpecial.PostLoadThreadEnabled", 0)
  GameInstance:ExecuteCMD("s.TickAsyncLoadingOptSpecial.TexCubeMaxSizeLimit", 0)
end

function ClientEVOConfig.EnableTickAsyncLoadingOpt()
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  local GameplayStatics = import("GameplayStatics")
  GameInstance:ExecuteCMD("s.TickAsyncLoadingOptSpecial.MaxHeavyObjectPostLoadCost", ClientEVOConfig.SavedTickAsyncLoadingOptSpecialMaxHeavyObjectPostLoadCost)
  GameInstance:ExecuteCMD("s.TickAsyncLoadingOptSpecial.IncrementalUpdateDistanceVolumeGranularity", ClientEVOConfig.SavedTickAsyncLoadingOptSpecialIncrementalUpdateDistanceVolumeGranularity)
  GameInstance:ExecuteCMD("s.TickAsyncLoadingOptSpecial.PostLoadThreadEnabled", ClientEVOConfig.SavedTickAsyncLoadingOptSpecialPostLoadThreadEnabled)
  GameInstance:ExecuteCMD("s.TickAsyncLoadingOptSpecial.TexCubeMaxSizeLimit", ClientEVOConfig.SavedTickAsyncLoadingOptSpecialTexCubeMaxSizeLimit)
end

ClientEVOConfig.LightCommonOptCmdList = {
  {
    "mv.UseLowSimulateLODProfile",
    1
  },
  {
    "weaponmgr.TickHideWeaonIntervel",
    5
  }
}
ClientEVOConfig.LightLossyOptCmdList = {
  {
    "a.URO.GlobalAnimUROBias",
    1
  },
  {
    "r.MipLODBiasFromQuality",
    1
  },
  {
    "r.Mobile.LowDeviceLODBias",
    1
  },
  {
    "grass.densityScale",
    0.4
  },
  {
    "r.SuperFrame.ScreenSizeCullFactor",
    1.2
  },
  {
    "r.SkeletalMeshLODRadiusScale",
    0.7
  },
  {
    "weapon.GEnableWeaponCulingScreensize",
    0.1
  },
  {
    "mv.SimulateLODProfile",
    1
  },
  {
    "weapon.WeaponCreateHitInfoCD",
    0.2
  },
  {
    "weapon.SimulateInactiveWeaponTickIntervel",
    5
  },
  {
    "weapon.SimulateDefaultWeaponTickIntervel",
    2
  },
  {
    "a.LowDeviceDisableStandBy",
    1
  },
  {
    "Slate.TextOutlineMode",
    2
  }
}

function ClientEVOConfig.SnapshotLightOptCmdValues()
  local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
  local optCmdLists = {
    ClientEVOConfig.LightCommonOptCmdList,
    ClientEVOConfig.LightLossyOptCmdList
  }
  local snapshotCount = 0
  for _, cmdList in ipairs(optCmdLists) do
    for _, cmdInfo in ipairs(cmdList) do
      local cmdName = cmdInfo[1]
      if ClientEVOConfig.SavedLightOptCmdValues[cmdName] == nil then
        ClientEVOConfig.SavedLightOptCmdValues[cmdName] = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableFloatValue(cmdName)
        snapshotCount = snapshotCount + 1
      end
    end
  end
  log_shipping_client("[ClientEVOConfig] SnapshotLightOptCmd count:" .. tostring(snapshotCount))
end

function ClientEVOConfig.ApplyLightOptCmdList(cmdList, cmdValueOverrides)
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  ClientEVOConfig.SnapshotLightOptCmdValues()
  for _, cmdInfo in ipairs(cmdList) do
    local cmdName = cmdInfo[1]
    local applyValue = cmdInfo[2]
    if cmdValueOverrides and cmdValueOverrides[cmdName] ~= nil then
      applyValue = cmdValueOverrides[cmdName]
    end
    GameInstance:ExecuteCMD(cmdName, applyValue)
    log_shipping_client(string.format("[ClientEVOConfig] ApplyLightOptCmd %s %s (backup:%s)", cmdName, tostring(applyValue), tostring(ClientEVOConfig.SavedLightOptCmdValues[cmdName])))
  end
end

function ClientEVOConfig.ResetLightOptCmdList(cmdList)
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  local resetCount = 0
  for _, cmdInfo in ipairs(cmdList) do
    local cmdName = cmdInfo[1]
    local resetValue = ClientEVOConfig.SavedLightOptCmdValues[cmdName]
    if resetValue ~= nil then
      ClientEVOConfig.SavedLightOptCmdValues[cmdName] = nil
      GameInstance:ExecuteCMD(cmdName, resetValue)
      resetCount = resetCount + 1
      log_shipping_client(string.format("[ClientEVOConfig] ResetLightOptCmd %s %s", cmdName, tostring(resetValue)))
    end
  end
  return resetCount
end

function ClientEVOConfig.ApplyLightManagedTickOpt(bForce)
  if not bForce then
    local TableUtil = require("common.table_util")
    if TableUtil.IsInTable(ClientEVOConfig.ManagedTickNonTypicalModList, ClientEVOConfig.CurrentModID) then
      log_shipping_client(string.format("[ClientEVOConfig] LightManagedTick skip, ModID:%s", tostring(ClientEVOConfig.CurrentModID)))
      return
    end
  end
  Client.SwitchMapMangedTickProfile(999007)
  Client.RefershAllManagedTickConfigWhenFPSChanged()
end

function ClientEVOConfig.ApplyLightCommonOptCmds(cmdValueOverrides)
  ClientEVOConfig.ApplyLightOptCmdList(ClientEVOConfig.LightCommonOptCmdList, cmdValueOverrides)
  ClientEVOConfig.ApplyLightOptCmdList(ClientEVOConfig.LightLossyOptCmdList, cmdValueOverrides)
  ClientEVOConfig.ApplyLightManagedTickOpt(true)
  log_shipping_client("[ClientEVOConfig] ApplyLightCommonOptCmds (GM)")
end

function ClientEVOConfig.ResetLightCommonOptCmds()
  ClientEVOConfig.ResetLightOptCmdList(ClientEVOConfig.LightCommonOptCmdList)
  ClientEVOConfig.ResetLightOptCmdList(ClientEVOConfig.LightLossyOptCmdList)
end

function ClientEVOConfig.IsLightPackage()
  local GraphicHelperUtil = require("client.slua.umg.NewSetting.GraphicsNew.GraphicHelperUtil")
  return GraphicHelperUtil.IsFlashFavorEnabled()
end

function ClientEVOConfig.IsFlashOnlyQualityEnabled()
  local logic_setting_graphics = require("client.slua.logic.setting.logic_setting_graphics")
  return logic_setting_graphics.IsFlashOnlyQuality(nil)
end

function ClientEVOConfig.ApplyLightLossyOpt(bEnabled)
  local SmartBearerManagerLuaBridge = import("SmartBearerManagerLuaBridge")
  if bEnabled and bEnabled == ClientEVOConfig.bLightLossyOptCurrentEnabled then
    log_shipping_client("[ClientEVOConfig] ApplyLightLossyOpt skip, already true")
    return
  end
  SmartBearerManagerLuaBridge.SetLightOptSwitcher(bEnabled and ClientEVOConfig.SavedLightOptSwitcher or 0)
  local bMidLowEndDevice = Client.GetTCDeviceLevel() < 7
  local bLossyCmdEnable = bEnabled and bMidLowEndDevice and ClientEVOConfig.CloudLightLossyOptEnable == 1
  SmartBearerManagerLuaBridge.SetLightLossyOptEnable(bLossyCmdEnable)
  ClientEVOConfig.bEnableActorSpawnQueueLightOpt = SmartBearerManagerLuaBridge.IsLightOptSwitcherEnable(6)
  ClientEVOConfig.ToggleActorSpawnQueue(ClientEVOConfig.bEnableActorSpawnQueueCloud or ClientEVOConfig.bEnableActorSpawnQueueLightOpt)
  if bEnabled then
    ClientEVOConfig.ApplyLightManagedTickOpt()
  end
  local cmdAction
  if bLossyCmdEnable then
    ClientEVOConfig.ApplyLightOptCmdList(ClientEVOConfig.LightLossyOptCmdList)
    cmdAction = "applied"
  else
    cmdAction = "reset(" .. tostring(ClientEVOConfig.ResetLightOptCmdList(ClientEVOConfig.LightLossyOptCmdList)) .. ")"
  end
  ClientEVOConfig.bLightLossyOptCurrentEnabled = bEnabled
  log_shipping_client("[ClientEVOConfig] ApplyLightLossyOpt Switcher:" .. tostring(bEnabled and ClientEVOConfig.SavedLightOptSwitcher or 0) .. " LossyCmd:" .. tostring(bLossyCmdEnable) .. " Cmd:" .. cmdAction)
end

function ClientEVOConfig.ApplyLightCommonOpt(bEnabled)
  local SmartBearerManagerLuaBridge = import("SmartBearerManagerLuaBridge")
  SmartBearerManagerLuaBridge.SetLightCommonOptEnable(bEnabled and ClientEVOConfig.CloudLightCommonOptEnable == 1)
  local cmdAction
  if bEnabled and ClientEVOConfig.CloudLightCommonOptEnable == 1 then
    ClientEVOConfig.ApplyLightOptCmdList(ClientEVOConfig.LightCommonOptCmdList)
    cmdAction = "applied"
  else
    cmdAction = "reset(" .. tostring(ClientEVOConfig.ResetLightOptCmdList(ClientEVOConfig.LightCommonOptCmdList)) .. ")"
  end
  log_shipping_client("[ClientEVOConfig] ApplyLightCommonOpt Common:" .. tostring(bEnabled and ClientEVOConfig.CloudLightCommonOptEnable == 1) .. " Cmd:" .. cmdAction)
end

function ClientEVOConfig.ApplyFlashOnlyQualityOptDynamic(bFlashOnly)
  local SmartBearerManagerLuaBridge = import("SmartBearerManagerLuaBridge")
  if not SmartBearerManagerLuaBridge or not SmartBearerManagerLuaBridge.SetLightOptSwitcher then
    return
  end
  if not ClientEVOConfig.IsLightPackage() then
    return
  end
  if ClientEVOConfig.bLightOptForceEnableByGM then
    return
  end
  local bInFighting = GameStatus.IsInFightingNotSocialNotMainCityNotHome()
  local bFlashOnlyOptEnabled = false
  if bInFighting then
    if not ClientEVOConfig.bLightOptAppliedInFighting then
      return
    end
    bFlashOnlyOptEnabled = bFlashOnly == true
  end
  ClientEVOConfig.ApplyLightLossyOpt(bFlashOnlyOptEnabled)
  log_shipping_client("[ClientEVOConfig] ApplyFlashOnlyQualityOptDynamic FlashOnly:" .. tostring(bFlashOnlyOptEnabled) .. " InFighting:" .. tostring(bInFighting))
end

function ClientEVOConfig.EnterFightingLightOpt()
  local SmartBearerManagerLuaBridge = import("SmartBearerManagerLuaBridge")
  if not SmartBearerManagerLuaBridge or not SmartBearerManagerLuaBridge.SetLightOptSwitcher then
    return
  end
  if ClientEVOConfig.bLightOptForceEnableByGM then
    SmartBearerManagerLuaBridge.SetLightOptSwitcher(2147483647)
    SmartBearerManagerLuaBridge.SetLightLossyOptEnable(true)
    SmartBearerManagerLuaBridge.SetLightCommonOptEnable(true)
    ClientEVOConfig.ApplyLightCommonOptCmds()
    ClientEVOConfig.bLightOptAppliedInFighting = true
    ClientEVOConfig.bLightLossyOptCurrentEnabled = true
    log_shipping_client("[ClientEVOConfig] EnterFightingLightOpt GMForce: Switcher 2147483647, Lossy/Common true, all cmd lists applied")
    return
  end
  if not ClientEVOConfig.IsLightPackage() then
    return
  end
  if ClientEVOConfig.CloudLightCommonOptEnable == nil then
    ClientEVOConfig.CloudLightLossyOptEnable = HDmpveRemote.HDmpveRemoteConfigGetInt("LightLossyOptEnable", 1)
    ClientEVOConfig.CloudLightCommonOptEnable = HDmpveRemote.HDmpveRemoteConfigGetInt("LightCommonOptEnable", 1)
  end
  ClientEVOConfig.ApplyLightCommonOpt(true)
  local bFlashOnlyOptEnabled = ClientEVOConfig.IsFlashOnlyQualityEnabled()
  ClientEVOConfig.ApplyLightLossyOpt(bFlashOnlyOptEnabled)
  ClientEVOConfig.bLightOptAppliedInFighting = true
  log_shipping_client("[ClientEVOConfig] EnterFightingLightOpt Switcher:" .. tostring(bFlashOnlyOptEnabled and ClientEVOConfig.SavedLightOptSwitcher or 0) .. " CloudLossy:" .. tostring(ClientEVOConfig.CloudLightLossyOptEnable) .. " CloudCommon:" .. tostring(ClientEVOConfig.CloudLightCommonOptEnable) .. " FlashOnly:" .. tostring(bFlashOnlyOptEnabled) .. " Applied:" .. tostring(ClientEVOConfig.bLightOptAppliedInFighting))
end

function ClientEVOConfig.LeaveFightingLightOpt()
  local SmartBearerManagerLuaBridge = import("SmartBearerManagerLuaBridge")
  if not SmartBearerManagerLuaBridge or not SmartBearerManagerLuaBridge.SetLightOptSwitcher then
    return
  end
  ClientEVOConfig.ApplyLightLossyOpt(false)
  ClientEVOConfig.ApplyLightCommonOpt(false)
  ClientEVOConfig.bLightOptAppliedInFighting = false
  log_shipping_client("[ClientEVOConfig] LeaveFightingLightOpt Applied:false LossyCurrent:" .. tostring(ClientEVOConfig.bLightLossyOptCurrentEnabled))
end

function ClientEVOConfig.GMForceEnableLightOptSwitcher()
  ClientEVOConfig.bLightOptForceEnableByGM = true
  log_shipping_client("[ClientEVOConfig] GMForceEnableLightOptSwitcher")
end

function ClientEVOConfig.BuildLightOptStatusReport()
  local function SafeCall(func)
    if func == nil then
      return nil
    end
    local ok, result = pcall(func)
    if ok then
      return result
    end
    return nil
  end
  
  local SmartBearerManagerLuaBridge = import("SmartBearerManagerLuaBridge")
  local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
  local lines = {}
  
  local function AddLine(str)
    lines[#lines + 1] = str
  end
  
  local bInFighting = false
  if GameStatus and GameStatus.IsInFightingNotSocialNotMainCityNotHome then
    bInFighting = SafeCall(function()
      return GameStatus.IsInFightingNotSocialNotMainCityNotHome()
    end) == true
  end
  local bLightPackage = false
  if ClientEVOConfig.IsLightPackage then
    bLightPackage = SafeCall(function()
      return ClientEVOConfig.IsLightPackage()
    end) == true
  end
  local bFlashOnly = false
  if ClientEVOConfig.IsFlashOnlyQualityEnabled then
    bFlashOnly = SafeCall(function()
      return ClientEVOConfig.IsFlashOnlyQualityEnabled()
    end) == true
  end
  local tcDeviceLevel = -1
  if Client and Client.GetTCDeviceLevel then
    local tcVal = SafeCall(function()
      return Client.GetTCDeviceLevel()
    end)
    if tcVal ~= nil then
      tcDeviceLevel = tcVal
    end
  end
  local bMidLowEnd = 0 <= tcDeviceLevel and tcDeviceLevel < 7
  local lossyFailReason, commonFailReason
  local bLossyExpected = true
  local bCommonExpected = true
  if not bInFighting then
    lossyFailReason, commonFailReason = "\233\157\158\230\136\152\230\150\151", "\233\157\158\230\136\152\230\150\151"
    bLossyExpected, bCommonExpected = false, false
  elseif not bLightPackage then
    lossyFailReason, commonFailReason = "\233\157\158\229\176\143\229\140\133", "\233\157\158\229\176\143\229\140\133"
    bLossyExpected, bCommonExpected = false, false
  elseif not bFlashOnly then
    lossyFailReason = "\231\148\187\232\180\168\229\133\179"
    bLossyExpected = false
  end
  if bLossyExpected and ClientEVOConfig.CloudLightLossyOptEnable ~= 1 then
    lossyFailReason = "\228\186\145\230\142\167\229\133\179"
    bLossyExpected = false
  end
  if bLossyExpected and not bMidLowEnd then
    lossyFailReason = "\233\156\128\228\184\173\228\189\142\231\171\175"
    bLossyExpected = false
  end
  if bCommonExpected and ClientEVOConfig.CloudLightCommonOptEnable ~= 1 then
    commonFailReason = "\228\186\145\230\142\167\229\133\179"
    bCommonExpected = false
  end
  
  local function FormatExpected(bExpected, failReason)
    if bExpected then
      return "\229\188\128"
    end
    return string.format("\229\133\179(%s)", failReason or "\229\133\179")
  end
  
  local bLossyActual, bCommonActual
  if SmartBearerManagerLuaBridge and SmartBearerManagerLuaBridge.IsLightLossyOptEnable then
    bLossyActual = SafeCall(function()
      return SmartBearerManagerLuaBridge.IsLightLossyOptEnable()
    end)
  end
  if SmartBearerManagerLuaBridge and SmartBearerManagerLuaBridge.IsLightCommonOptEnable then
    bCommonActual = SafeCall(function()
      return SmartBearerManagerLuaBridge.IsLightCommonOptEnable()
    end)
  end
  
  local function FormatBridgeBool(value)
    if value == nil then
      return "\228\184\141\229\143\175\231\148\168"
    end
    return value == true and "\229\183\178\232\174\190\231\189\174" or "\230\156\170\232\174\190\231\189\174"
  end
  
  AddLine("======== Light/Flash \228\188\152\229\140\150\229\188\128\229\133\179\231\138\182\230\128\129 ========")
  if ClientEVOConfig.bLightOptForceEnableByGM then
    AddLine("[\232\173\166\229\145\138] GM\229\188\186\229\136\182\229\183\178\229\188\128\229\144\175, \232\183\179\232\191\135\229\133\168\233\131\168\229\136\164\229\174\154, \233\135\141\230\150\176\231\153\187\229\189\149\229\144\142\230\129\162\229\164\141")
    AddLine("")
  end
  AddLine("\227\128\144\229\188\128\229\133\179\229\188\128\229\144\175\231\138\182\230\128\129\227\128\145")
  AddLine(string.format(" \231\142\175\229\162\131: \229\176\143\229\140\133=%s | Flash\231\148\187\232\180\168=%s | \229\156\186\230\153\175=%s | TC=%s(\228\184\173\228\189\142\231\171\175) | \228\186\145\230\142\167: \230\156\137\230\141\159=%s \233\128\154\231\148\168=%s", bLightPackage and "\229\188\128" or "\229\133\179", bFlashOnly and "\229\188\128" or "\229\133\179", bInFighting and "\230\136\152\230\150\151" or "\233\157\158\230\136\152\230\150\151", tostring(tcDeviceLevel), ClientEVOConfig.CloudLightLossyOptEnable == nil and "\230\156\170\232\175\187\229\143\150" or tostring(ClientEVOConfig.CloudLightLossyOptEnable), ClientEVOConfig.CloudLightCommonOptEnable == nil and "\230\156\170\232\175\187\229\143\150" or tostring(ClientEVOConfig.CloudLightCommonOptEnable)))
  if ClientEVOConfig.bLightOptForceEnableByGM then
    AddLine(" \230\156\137\230\141\159\228\188\152\229\140\150: \228\184\141\233\128\130\231\148\168(GM\229\188\186\229\136\182)")
    AddLine(" \233\128\154\231\148\168\228\188\152\229\140\150: \228\184\141\233\128\130\231\148\168(GM\229\188\186\229\136\182)")
  else
    local function FormatResult(bExpected, bActual)
      if bActual == nil then
        return "[\229\188\130\229\184\184]"
      end
      return bExpected == (bActual == true) and "\230\173\163\229\184\184" or "[\229\188\130\229\184\184]"
    end
    
    AddLine(string.format(" \230\156\137\230\141\159\228\188\152\229\140\150: \233\162\132\230\156\159=%s, \229\188\149\230\147\142\229\174\158\233\153\133=%s \226\134\146 %s", FormatExpected(bLossyExpected, lossyFailReason), FormatBridgeBool(bLossyActual), FormatResult(bLossyExpected, bLossyActual)))
    AddLine(string.format(" \233\128\154\231\148\168\228\188\152\229\140\150: \233\162\132\230\156\159=%s, \229\188\149\230\147\142\229\174\158\233\153\133=%s \226\134\146 %s", FormatExpected(bCommonExpected, commonFailReason), FormatBridgeBool(bCommonActual), FormatResult(bCommonExpected, bCommonActual)))
  end
  local bitsStr = "0"
  local switcherDecimal = 0
  local bSwitcherUnavailable = false
  for i = 1, 6 do
    local bitVal
    if SmartBearerManagerLuaBridge and SmartBearerManagerLuaBridge.IsLightOptSwitcherEnable then
      bitVal = SafeCall(function()
        return SmartBearerManagerLuaBridge.IsLightOptSwitcherEnable(i)
      end)
    end
    if bitVal == nil then
      bSwitcherUnavailable = true
      bitsStr = bitsStr .. "?"
    else
      local bBitOn = bitVal == true or bitVal == 1
      bitsStr = bitsStr .. (bBitOn and "1" or "0")
      if bBitOn then
        switcherDecimal = switcherDecimal + math.floor(2 ^ i)
      end
    end
  end
  AddLine("")
  AddLine("\227\128\144\229\144\142\229\143\176bit\229\188\128\229\133\179\231\187\132\227\128\145")
  if bSwitcherUnavailable then
    AddLine(" LightOptSwitcher: \228\184\141\229\143\175\231\148\168")
  else
    AddLine(string.format(" LightOptSwitcher: %s (bit1~6, \229\141\129\232\191\155\229\136\182=%d)", bitsStr, switcherDecimal))
  end
  
  local function GetCvarFloat(cmdName)
    if uSTExtraBlueprintFunctionLibrary and uSTExtraBlueprintFunctionLibrary.GetConsoleVariableFloatValue then
      return SafeCall(function()
        return uSTExtraBlueprintFunctionLibrary.GetConsoleVariableFloatValue(cmdName)
      end)
    end
    return nil
  end
  
  local function FormatCmdGroup(groupName, cmdList)
    local bApplied = false
    for _, cmdInfo in ipairs(cmdList) do
      if ClientEVOConfig.SavedLightOptCmdValues[cmdInfo[1]] ~= nil then
        bApplied = true
        break
      end
    end
    local groupLines = {
      string.format(" %s(\229\133\177%d\230\157\161): %s", groupName, #cmdList, bApplied and "\229\183\178\228\184\139\229\143\145" or "\230\156\170\228\184\139\229\143\145")
    }
    if bApplied then
      for idx = 1, math.min(2, #cmdList) do
        local cmdName = cmdList[idx][1]
        local expectValue = cmdList[idx][2]
        local actualValue = GetCvarFloat(cmdName)
        local actualStr = "\228\184\141\229\143\175\231\148\168"
        local bMismatch = false
        if actualValue ~= nil then
          actualStr = tostring(actualValue)
          bMismatch = math.abs(actualValue - expectValue) > 1.0E-4
        end
        groupLines[#groupLines + 1] = string.format(" - %s = %s (\230\156\159\230\156\155:%s)%s", cmdName, actualStr, tostring(expectValue), bMismatch and " [\229\188\130\229\184\184]" or "")
      end
    end
    return table.concat(groupLines, "\n")
  end
  
  AddLine("")
  AddLine("\227\128\144\229\145\189\228\187\164\231\187\132\232\174\190\231\189\174\231\138\182\230\128\129\227\128\145")
  AddLine(FormatCmdGroup("\233\128\154\231\148\168\229\145\189\228\187\164\231\187\132", ClientEVOConfig.LightCommonOptCmdList))
  AddLine(FormatCmdGroup("\230\156\137\230\141\159\229\145\189\228\187\164\231\187\132", ClientEVOConfig.LightLossyOptCmdList))
  local managedTickCvar = GetCvarFloat("tick.EnableManagedTickSysFlag")
  local TableUtil = require("common.table_util")
  local bNonTypicalMod = false
  if TableUtil and TableUtil.IsInTable then
    bNonTypicalMod = SafeCall(function()
      return TableUtil.IsInTable(ClientEVOConfig.ManagedTickNonTypicalModList, ClientEVOConfig.CurrentModID)
    end) == true
  end
  AddLine("")
  AddLine("\227\128\144ManagedTick\233\153\141\233\162\145\227\128\145")
  AddLine(string.format(" \229\144\142\229\143\176\229\128\188: %s | cvar: %s | ModID: %s(%s)", tostring(ClientEVOConfig.ManagedTickSysFlagBackEnd), managedTickCvar == nil and "\228\184\141\229\143\175\231\148\168" or tostring(managedTickCvar), tostring(ClientEVOConfig.CurrentModID), bNonTypicalMod and "\233\157\158Typical\226\134\146\228\191\157\230\140\129\230\168\161\229\188\143\233\133\141\231\189\174" or "Typical\226\134\146\229\186\148\229\136\135999007"))
  AddLine("")
  AddLine("\227\128\144\233\147\190\232\183\175\230\160\135\232\174\176\227\128\145")
  AddLine(string.format(" \230\156\172\229\177\128\229\183\178\230\137\167\232\161\140: %s | \230\156\137\230\141\159\233\147\190\231\138\182\230\128\129: %s", tostring(ClientEVOConfig.bLightOptAppliedInFighting), tostring(ClientEVOConfig.bLightLossyOptCurrentEnabled)))
  AddLine("==========================================")
  return table.concat(lines, "\n")
end

function ClientEVOConfig.OpenDevLog()
  ClientEVOConfig.bOpenDevLog = true
  local STExtraGameInstance = import("STExtraGameInstance")
  STExtraGameInstance.GetInstance():ExecuteCMD("log.CloseLogOnTestOrShipping", 0)
  local PandoraAdapter = require("client.slua.logic.Pandora.pandora_v2_adapter")
  PandoraAdapter:SetDebugLog(true)
  local gamelet_interface = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_gamelet_interface)
  gamelet_interface:EnableLog(true)
end

function ClientEVOConfig.ReadSlateThrottleRemoteSwitch(opts, isIpad)
  if opts.bNeedLightPackage and not ClientEVOConfig.IsLightPackage() then
    ClientEVOConfig[opts.switchField] = false
    ClientEVOConfig[opts.enableField] = false
    return false
  end
  if opts.bExcludeLightPackage and ClientEVOConfig.IsLightPackage() then
    ClientEVOConfig[opts.switchField] = false
    ClientEVOConfig[opts.enableField] = false
    return false
  end
  local value = HDmpveRemote.HDmpveRemoteConfigGetInt(opts.remoteKey, opts.defaultValue)
  local bPass = 0 < value
  if opts.bExcludeIpad and bPass then
    bPass = not isIpad
  end
  if bPass then
    ClientEVOConfig[opts.switchField] = true
    ClientEVOConfig[opts.useWhiteListField] = value == 1
    log_shipping_client(string.format("[%s] %s==true %s==%s", opts.logTag, opts.remoteKey, opts.useWhiteListField, tostring(ClientEVOConfig[opts.useWhiteListField])))
    return true
  end
  ClientEVOConfig[opts.switchField] = false
  ClientEVOConfig[opts.enableField] = false
  log_shipping_client(string.format("[%s] %s==false", opts.logTag, opts.remoteKey))
  return false
end

function ClientEVOConfig.EvalSlateThrottleEnabled(bSwitchEnabled, bUseWhiteList, whiteList, minFpsLevel, fpsLevel)
  if not bSwitchEnabled then
    return false
  end
  if minFpsLevel and fpsLevel < minFpsLevel then
    return false
  end
  if bUseWhiteList then
    local TableUtil = require("common.table_util")
    if not whiteList or not whiteList[ClientEVOConfig.CurrentWorldName] then
      return false
    end
    if TableUtil.IsInTable(ClientEVOConfig.TModList, ClientEVOConfig.CurrentModID) then
      return false
    end
    if ClientEVOConfig.SlateThrottleExcludeModType[ClientEVOConfig.CurrentModType] then
      return false
    end
  end
  return true
end

function ClientEVOConfig.GetLightThrottleFrequency()
  return 30
end

function ClientEVOConfig.OnPreBackEndSwitcherSet(SmartBearerSwitcher, SuperFrameSwitcher, ClientBackEndSwitcherA, ClientBackEndSwitcherB, ClientBackEndSwitcherC, PostLoadSwitcher)
  local GameplayStatics = import("GameplayStatics")
  if SuperFrameSwitcher and SuperFrameSwitcher & 16777216 ~= 0 then
    ClientEVOConfig.DisableTickAsyncLoadingOpt()
    ClientEVOConfig.bTickAsyncLoadingBackEndEnable = true
  end
  if SuperFrameSwitcher and SuperFrameSwitcher & 8388608 ~= 0 then
    ClientEVOConfig.bLevelStreamingBackEndEnable = true
  end
  if ClientBackEndSwitcherC and ClientBackEndSwitcherC & 2 ~= 0 then
    ClientEVOConfig.bUseLowFakeLandScapeBackEndEnable = true
  end
  if HDmpveRemote.HDmpveRemoteConfigGetBool("EnableSlateGlobalInvalidation", false) == true then
    ClientEVOConfig.bEnableSlateGICloud = true
    log_shipping_client("[ClientEVOConfig] Cloud Switch: EnableSlateGlobalInvalidation==true")
  else
    ClientEVOConfig.bEnableSlateGICloud = false
    log_shipping_client("[ClientEVOConfig] Cloud Switch: EnableSlateGlobalInvalidation==false")
  end
  if HDmpveRemote.HDmpveRemoteConfigGetBool("EnableInvalidationPanels", false) == true or IsEditor then
    ClientEVOConfig.bEnableInvalidationPanelsCloud = true
    log_shipping_client("[ClientEVOConfig] Cloud Switch: EnableInvalidationPanels==true")
  else
    ClientEVOConfig.bEnableInvalidationPanelsCloud = false
    log_shipping_client("[ClientEVOConfig] Cloud Switch: EnableInvalidationPanels==false")
  end
  if HDmpveRemote.HDmpveRemoteConfigGetBool("EnableSlateVerifyHitTestVisibility", false) == true or IsEditor then
    ClientEVOConfig.bEnableSlateVerifyHitTestVisibilityCloud = true
    log_shipping_client("[ClientEVOConfig] Cloud Switch: EnableSlateVerifyHitTestVisibility==true")
  else
    ClientEVOConfig.bEnableSlateVerifyHitTestVisibilityCloud = false
    log_shipping_client("[ClientEVOConfig] Cloud Switch: EnableSlateVerifyHitTestVisibility==false")
  end
  if HDmpveRemote.HDmpveRemoteConfigGetBool("EnableRemoveVolatilePrepassFlag", false) == true or IsEditor then
    ClientEVOConfig.bEnableRemoveVolatilePrepassFlagCloud = true
    log_shipping_client("[ClientEVOConfig] Cloud Switch: EnableRemoveVolatilePrepassFlag==true")
  else
    ClientEVOConfig.bEnableRemoveVolatilePrepassFlagCloud = false
    log_shipping_client("[ClientEVOConfig] Cloud Switch: EnableRemoveVolatilePrepassFlag==false")
  end
  if HDmpveRemote.HDmpveRemoteConfigGetBool("EnableFixSlateFastPathHitTest", false) == true or IsEditor then
    ClientEVOConfig.bEnableFixSlateFastPathHitTestCloud = true
    log_shipping_client("[ClientEVOConfig] Cloud Switch: EnableFixSlateFastPathHitTest==true")
  else
    ClientEVOConfig.bEnableFixSlateFastPathHitTestCloud = false
    log_shipping_client("[ClientEVOConfig] Cloud Switch: EnableFixSlateFastPathHitTest==false")
  end
  if HDmpveRemote.HDmpveRemoteConfigGetBool("EnableActorSpawnQueue470", false) == true then
    ClientEVOConfig.bEnableActorSpawnQueueCloud = true
    log_shipping_client("[ClientEVOConfig] Cloud Switch: EnableActorSpawnQueue==true")
  else
    ClientEVOConfig.bEnableActorSpawnQueueCloud = false
    log_shipping_client("[ClientEVOConfig] Cloud Switch: EnableActorSpawnQueue==false")
  end
  if ClientBackEndSwitcherA and ClientBackEndSwitcherA & 32 ~= 0 then
    ClientEVOConfig.bEnableUIDynamicBatch = true
    log(bWriteLog and "[UIDynamicBatch] ClientBackEndSwitcherA UIDynamicBatch==5")
  end
  if ClientBackEndSwitcherA and ClientBackEndSwitcherA & 32768 ~= 0 then
    ClientEVOConfig.bEnableSlateLayoutCacheBackendValue = true
    ClientEVOConfig.bEnableSlateLayoutCache = true
    log(bWriteLog and "[UIDynamicBatch] ClientBackEndSwitcherA SlateLayoutCache==15")
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  if ClientBackEndSwitcherB and ClientBackEndSwitcherB & 2048 ~= 0 and GameInstance:IsIOSVersionAbove14() then
    ClientEVOConfig.bEnableIOSPSOCache = true
    log(bWriteLog and "[IOSPSOCache] ClientBackEndSwitcherB IOSPSOCache==11")
  end
  local deviceModel = string.lower(Client.GetDeviceModel() or "")
  local isIpad = deviceModel:sub(1, 4) == "ipad"
  ClientEVOConfig.ReadSlateThrottleRemoteSwitch({
    remoteKey = "EnableSlateThrottle",
    defaultValue = 0,
    logTag = "UIThrottle",
    switchField = "bSlateThrottleSwitchEnabled",
    enableField = "bEnableSlateThrottle",
    useWhiteListField = "bUseSlateThrottleWhiteList",
    bExcludeIpad = true
  }, isIpad)
  GameInstance:ExecuteCMD("Slate.EnableThrottle", ClientEVOConfig.bSlateThrottleSwitchEnabled and 1 or 0)
  if not ClientEVOConfig.bSlateGIThrottleSetByGM then
    ClientEVOConfig.ReadSlateThrottleRemoteSwitch({
      remoteKey = "EnableSlateGIThrottle",
      defaultValue = 0,
      logTag = "SlateGIThrottle",
      switchField = "bSlateGIThrottleSwitchEnabled",
      enableField = "bEnableSlateGIThrottle",
      useWhiteListField = "bUseSlateGIThrottleWhiteList",
      bExcludeIpad = true
    }, isIpad)
    ClientEVOConfig.ReadSlateThrottleRemoteSwitch({
      remoteKey = "EnableLightSlateGIThrottle",
      defaultValue = 1,
      logTag = "LightSlateGIThrottle",
      switchField = "bLightSlateGIThrottleSwitchEnabled",
      enableField = "bEnableLightSlateGIThrottle",
      useWhiteListField = "bUseLightSlateGIThrottleWhiteList",
      bNeedLightPackage = true,
      bExcludeIpad = true
    }, isIpad)
    if ClientEVOConfig.bSlateGIThrottleSwitchEnabled or ClientEVOConfig.bLightSlateGIThrottleSwitchEnabled then
      GameInstance:ExecuteCMD("Slate.EnableGIThrottle", 1)
      GameInstance:ExecuteCMD("Slate.EnableGIThrottle", 1)
    else
      GameInstance:ExecuteCMD("Slate.EnableGIThrottle", 0)
      GameInstance:ExecuteCMD("Slate.EnableGIThrottle", 0)
    end
  else
    log_shipping_client("[SlateGIThrottle] Skip backend setting because Slate.EnableGIThrottle was set by GM")
  end
  ClientEVOConfig.ReadSlateThrottleRemoteSwitch({
    remoteKey = "EnableLightWidgetTickFrequency",
    defaultValue = 1,
    logTag = "LightWidgetTickFrequency",
    switchField = "bLightWidgetTickFrequencySwitchEnabled",
    enableField = "bEnableLightWidgetTickFrequency",
    useWhiteListField = "bUseLightWidgetTickFrequencyWhiteList",
    bNeedLightPackage = true,
    bExcludeIpad = false
  }, isIpad)
  ClientEVOConfig.ReadSlateThrottleRemoteSwitch({
    remoteKey = "EnableWidgetTickFrequency",
    defaultValue = 0,
    logTag = "WidgetTickFrequency",
    switchField = "bWidgetTickFrequencySwitchEnabled",
    enableField = "bEnableWidgetTickFrequency",
    useWhiteListField = "bUseWidgetTickFrequencyWhiteList",
    bExcludeLightPackage = true,
    bExcludeIpad = false
  }, isIpad)
  local EnableNotRenderedParallelUpdate = HDmpveRemote.HDmpveRemoteConfigGetInt("EnableNotRenderedParallelUpdate", 0)
  ClientEVOConfig.bEnableNotRenderedParallelUpdateBackEnd = 0 < EnableNotRenderedParallelUpdate
  log_shipping_client(string.format("[AnimationOpt] EnableNotRenderedParallelUpdateBackEnd==%s", tostring(ClientEVOConfig.bEnableNotRenderedParallelUpdateBackEnd)))
  ClientEVOConfig.RefreshNotRenderedParallelUpdate()
  local EnableRefreshBonesTickAnimationOpt = HDmpveRemote.HDmpveRemoteConfigGetInt("EnableRefreshBonesTickAnimationOpt", 0)
  ClientEVOConfig.bEnableRefreshBonesTickAnimationOptBackEnd = 0 < EnableRefreshBonesTickAnimationOpt
  log_shipping_client(string.format("[AnimationOpt] EnableRefreshBonesTickAnimationOptBackEnd==%s", tostring(ClientEVOConfig.bEnableRefreshBonesTickAnimationOptBackEnd)))
  ClientEVOConfig.RefreshBonesTickAnimationOpt()
  if ClientBackEndSwitcherC and ClientBackEndSwitcherC & 16 ~= 0 then
    ClientEVOConfig.bNewObjectPoolGCOptimizationEnable = true
  end
  if ClientBackEndSwitcherC and ClientBackEndSwitcherC & 64 ~= 0 then
    ClientEVOConfig.bNewObjectPoolDefferedPhysicsState = true
  end
  if ClientBackEndSwitcherC and ClientBackEndSwitcherC & 512 ~= 0 then
    ClientEVOConfig.bEnable400AnimationOptimization = true
  end
  log_shipping_client("ClientEVOConfig.OnPreBackEndSwitcherSet ClientBackEndSwitcherC: " .. tostring(ClientBackEndSwitcherC))
  local EnableJankCollectionFromRemote = HDmpveRemote.HDmpveRemoteConfigGetInt("EnableJankCollection", 1)
  GameInstance:ExecuteCMD("Jank.EnableCollection", EnableJankCollectionFromRemote)
  local platformName = Client.GetDevicePlatformName()
  local DevicePlatformNameMacros = require("client.slua.config.ClientMacros.DevicePlatformNameMacros")
  if ClientEVOConfig.DefaultSleepTimeThodOnIni > 1.0E-6 and 1.0E-6 < ClientEVOConfig.DefaultSleepSlackTimeOnIni then
    if platformName == DevicePlatformNameMacros.IOS then
      local sleepvalue = Client.HDmpveRemoteConfigGetInt("GSleepTimeThod_IOS", -1)
      if sleepvalue < 0 then
        GameInstance:ExecuteCMD("Engine.GSleepTimeThod", ClientEVOConfig.DefaultSleepTimeThodOnIni)
      else
        GameInstance:ExecuteCMD("Engine.GSleepTimeThod", sleepvalue / 10000)
      end
      local sleepSlackvalue = Client.HDmpveRemoteConfigGetInt("GSleepSlackTimeThod_IOS", -1)
      if sleepSlackvalue < 0 then
        GameInstance:ExecuteCMD("Engine.GSleepSlackTimeThod", ClientEVOConfig.DefaultSleepSlackTimeOnIni)
      else
        GameInstance:ExecuteCMD("Engine.GSleepSlackTimeThod", sleepSlackvalue / 10000)
      end
    elseif platformName == DevicePlatformNameMacros.Android then
      local sleepvalue = Client.HDmpveRemoteConfigGetInt("GSleepTimeThod_AOS", -1)
      if sleepvalue < 0 then
        GameInstance:ExecuteCMD("Engine.GSleepTimeThod", ClientEVOConfig.DefaultSleepTimeThodOnIni)
      else
        GameInstance:ExecuteCMD("Engine.GSleepTimeThod", sleepvalue / 10000)
      end
      local sleepSlackvalue = Client.HDmpveRemoteConfigGetInt("GSleepSlackTimeThod_AOS", -1)
      if sleepSlackvalue < 0 then
        GameInstance:ExecuteCMD("Engine.GSleepSlackTimeThod", ClientEVOConfig.DefaultSleepSlackTimeOnIni)
      else
        GameInstance:ExecuteCMD("Engine.GSleepSlackTimeThod", sleepSlackvalue / 10000)
      end
    end
    local delayValue = Client.HDmpveRemoteConfigGetInt("DealyHideLoadingUI", 0)
    GameInstance:ExecuteCMD("s.DealyHideLoadingUI", delayValue / 1000)
  end
  ClientEVOConfig.EnableGCSweepTimeModifiy_GCloud = Client.HDmpveRemoteConfigGetInt("EnableGCSweepTimeModifiy", 0)
  local EnableSimulateMoveOptSwitcher = Client.HDmpveRemoteConfigGetInt("EnableSimulateMoveOpt", 0)
  GameInstance:ExecuteCMD("mv.SimulateOptBackEndSwitcher", EnableSimulateMoveOptSwitcher)
  if not Client.IsEditor() then
    if 3 <= EnableSimulateMoveOptSwitcher then
      GameInstance:ExecuteCMD("st.CompOpt.Enable", 1)
    else
      GameInstance:ExecuteCMD("st.CompOpt.Enable", 0)
    end
  else
    GameInstance:ExecuteCMD("st.CompOpt.Enable", 1)
  end
  if not Client.IsDevelopment() and not ClientEVOConfig.bOpenDevLog then
    GameInstance:ExecuteCMD("log.CloseLogOnTestOrShipping", Client.HDmpveRemoteConfigGetInt("GCloseLogOnTestOrShipping", 0))
  end
  Client.SetFixPostLoadSubojbectsBugEnable(Client.HDmpveRemoteConfigGetInt("OpenFixPostLoadSubojbectsBug", 0))
  if ClientBackEndSwitcherB and ClientBackEndSwitcherB & 1048576 ~= 0 then
    GameInstance:ExecuteCMD("r.UseCahcedFileModule", 1)
  end
  if ClientBackEndSwitcherB and ClientBackEndSwitcherB & 32768 ~= 0 then
    GameInstance:ExecuteCMD("r.FindFileInPakFilesOptEnable", 1)
    GameInstance:ExecuteCMD("r.FindFileInPakFilesMountPointOptEnable", 1)
  end
  if ClientBackEndSwitcherB and ClientBackEndSwitcherB & 65536 ~= 0 then
    GameInstance:ExecuteCMD("r.EnableShaderSerializeBaseOpt", 1)
  end
  if ClientBackEndSwitcherB and ClientBackEndSwitcherB & 33554432 ~= 0 then
    GameInstance:ExecuteCMD("Slate.EnableIsChildWidgetCulledOpt", 1)
    GameInstance:ExecuteCMD("Slate.EnableArrangeLayeredChildrenOpt", 1)
    GameInstance:ExecuteCMD("Slate.EnableCalculateCullingAndClippingRulesOpt", 1)
    GameInstance:ExecuteCMD("Slate.EnableAddShapedTextElementOpt", 1)
    GameInstance:ExecuteCMD("Slate.EnableNewKeyboardConfigOpt", 1)
    GameInstance:ExecuteCMD("Slate.EnableGetShaderResourceOpt", 1)
    GameInstance:ExecuteCMD("Slate.EnableTunePrePassSortMapOpt", 1)
    GameInstance:ExecuteCMD("Slate.EnableTunePassOpt", 1)
    GameInstance:ExecuteCMD("Slate.EnableTuneElementsNewOpt", 1)
    GameInstance:ExecuteCMD("Slate.EnableAlwaysPaintOpt", 1)
  end
  local EnableROCOrrange = HDmpveRemote.HDmpveRemoteConfigGetInt("EnableROCOrrange", 0)
  GameInstance:ExecuteCMD("r.EnableROCOrrange", EnableROCOrrange)
  GameInstance:ExecuteCMD("r.EnableDynamicShaderOrrange", EnableROCOrrange)
  local EnableNewLandScapeStragety = HDmpveRemote.HDmpveRemoteConfigGetInt("EnableNewLandScapeStragety", 0)
  GameInstance:ExecuteCMD("r.UseNewStragetyV2", EnableNewLandScapeStragety)
  local EnableRenderPipeLine = HDmpveRemote.HDmpveRemoteConfigGetInt("EnableRenderPipeLine", 0)
  GameInstance:ExecuteCMD("r.EnableStaticShaderOrrange", EnableRenderPipeLine)
  local EnableLandScapeSubsectionbox = HDmpveRemote.HDmpveRemoteConfigGetInt("EnableLandScapeSubsectionbox", 0)
  GameInstance:ExecuteCMD("r.Landscape.EnableSubSectionOptimize", EnableLandScapeSubsectionbox)
  local EnableIgnoreDynamicInstancingShader = HDmpveRemote.HDmpveRemoteConfigGetInt("EnableIgnoreDynamicInstancingShader", 0)
  GameInstance:ExecuteCMD("r.Mobile.IgnoreDynamicInstancingShader", EnableIgnoreDynamicInstancingShader)
  local ForceEnableSubSection = HDmpveRemote.HDmpveRemoteConfigGetInt("ForceEnableSubSection", 1)
  GameInstance:ExecuteCMD("r.ForceEnableSubSection", ForceEnableSubSection)
  GameInstance:ExecuteCMD("r.ParticleDynamicInstance", Client.HDmpveRemoteConfigGetInt("EnableParticleDynamicInstance", 0))
  ClientEVOConfig.ManagedTickSysFlagBackEnd = 2
  if not Client.IsEditor() then
    ClientEVOConfig.ManagedTickSysFlagBackEnd = HDmpveRemote.HDmpveRemoteConfigGetInt("EnableManagedTickSys", 0)
  end
  log(bWriteLog and "ManagedTickSys enable form backend:" .. tostring(ClientEVOConfig.ManagedTickSysFlagBackEnd))
  if 2 <= ClientEVOConfig.ManagedTickSysFlagBackEnd then
    Client.ReadManagedTickMapSwitchers()
  end
  local SequenceEnableOpt = HDmpveRemote.HDmpveRemoteConfigGetInt("SequenceEnableOpt", 0)
  GameInstance:ExecuteCMD("r.SequenceEnableOpt", SequenceEnableOpt)
  local PickUpJankOpt = HDmpveRemote.HDmpveRemoteConfigGetInt("PickUpJankOpt", 0)
  GameInstance:ExecuteCMD("r.EnablePickUpUnLimitPool", PickUpJankOpt)
  GameInstance:ExecuteCMD("z.EnablePreCreateWidgetCache", HDmpveRemote.HDmpveRemoteConfigGetInt("EnablePreCreateWidgetCache", 0))
  local LoadObjectOpt = HDmpveRemote.HDmpveRemoteConfigGetInt("EnableLoadObjectOpt", 0)
  GameInstance:ExecuteCMD("s.EnableLoadObjectOpt", LoadObjectOpt)
  if 0 < LoadObjectOpt then
    GameInstance:ExecuteCMD("s.LoadObjectOpt.DeadLoopTime", LoadObjectOpt)
  else
    GameInstance:ExecuteCMD("s.LoadObjectOpt.DeadLoopTime", -1)
  end
  if ClientEVOConfig.IsFlashFavorVerySmooth50Device() then
    GameInstance:ExecuteCMD("r.FrameImproveModeInVerySmooth", 1)
    GameInstance:ExecuteCMD("r.PUBGDeviceFPSVerySmooth", 60)
    GameInstance.Userdetailsetting.PUBGDeviceFPSVerySmooth = 60
    log("OnPreBackEndSwitcherSet: SuperFrame VerySmooth FPS unlock -> 60")
  end
end

function ClientEVOConfig.HandleOnLoadingPreBegin()
  if not Client then
    return
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  local GameplayStatics = import("GameplayStatics")
  if ClientEVOConfig.CollectorTimerID and ClientEVOConfig.CollectorTimerID > 0 then
    local time_ticker = require("common.time_ticker")
    time_ticker.RemoveTimer(ClientEVOConfig.CollectorTimerID)
    ClientEVOConfig.CollectorTimerID = 0
  end
  GameInstance:ExecuteCMD("Jank.EnableCollectionFromGamePlay", 0)
  GameInstance:ExecuteCMD("s.EnableLoadObjectOptFromGamePlay", 0)
  Client.ClearJankStats()
  Client.SyncLoadInfoCollector_OnLevelEnd()
  ClientEVOConfig.bCallLoadingUIOpend = true
end

function ClientEVOConfig.HandleOnLoadingEnd()
  if not Client or not ClientEVOConfig.bCallLoadingUIOpend then
    return
  end
  ClientEVOConfig.bCallLoadingUIOpend = false
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
  local GameplayStatics = import("GameplayStatics")
  local time_ticker = require("common.time_ticker")
  ClientEVOConfig.CollectorTimerID = time_ticker.AddTimerOnce(10, function()
    ClientEVOConfig.CollectorTimerID = 0
    if GameStatus.IsInFightingStatus() and not GameStatus.IsIn2DLobby() then
      GameInstance:ExecuteCMD("Jank.EnableCollectionFromGamePlay", 1)
      GameInstance:ExecuteCMD("s.EnableLoadObjectOptFromGamePlay", 1)
      Client.ClearJankStats()
      Client.SyncLoadInfoCollector_OnLevelStart()
    end
  end)
  if GameStatus.IsInFightingStatus() and not GameStatus.IsIn2DLobby() then
    local logic_cloud_game = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_cloud_game)
    log(bWriteLog and "LobbySystem:on_match_success SendMessageToCloudGame MatchBegin")
    logic_cloud_game:SendMessageToCloudGame(logic_cloud_game.ProtocolName.MatchBegin, "MatchBegin")
  end
end

function ClientEVOConfig.HandleOnPreBattleResult()
  if not Client then
    return
  end
  if ClientEVOConfig.CollectorTimerID and ClientEVOConfig.CollectorTimerID > 0 then
    local time_ticker = require("common.time_ticker")
    time_ticker.RemoveTimer(ClientEVOConfig.CollectorTimerID)
    ClientEVOConfig.CollectorTimerID = 0
  end
  if ClientEVOConfig.bLevelEnd then
    return
  end
  ClientEVOConfig.bLevelEnd = true
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  ClientEVOConfig.ToggleNotRenderedParallelUpdate(false)
  ClientEVOConfig.ToggleRefreshBonesTickAnimationOpt(false)
  if not GameStatus.IsInFightingStatus() or GameStatus.IsIn2DLobby() then
    GameInstance:ExecuteCMD("Jank.EnableCollectionFromGamePlay", 0)
    GameInstance:ExecuteCMD("Slate.EnableDownTickIntervalForGamePlay", 0)
    GameInstance:ExecuteCMD("s.EnableLoadObjectOptFromGamePlay", 0)
    Client.SyncLoadInfoCollector_Reset()
    Client.ClearJankStats()
    return
  end
  if not PublishRegionMacros.IsBlueholeOperationRegion() then
    local TApmHelper = import("TApmHelper")
    local TApmSceneMarker = import("TApmSceneMarker")
    TApmHelper.postEvent(606, "end", false)
    log(bWriteLog and "TApmSceneMarker.MarkFlowScene(111)")
    TApmSceneMarker.MarkFlowScene(111)
  end
  GameInstance:ExecuteCMD("Jank.EnableCollectionFromGamePlay", 0)
  GameInstance:ExecuteCMD("Slate.EnableDownTickIntervalForGamePlay", 0)
  GameInstance:ExecuteCMD("s.EnableLoadObjectOptFromGamePlay", 0)
  Client.ClearJankStats()
  Client.SyncLoadInfoCollector_OnLevelEnd()
  ClientEVOConfig.ToggleSlateGI(false)
  ClientEVOConfig.ToggleSlateLayoutCache(false)
  ClientEVOConfig.ToggleActorSpawnQueue(false)
  if not ClientEVOConfig.bSlateGIThrottleSetByGM then
    GameInstance:ExecuteCMD("Slate.DisableVolatileThrottle", 0)
    GameInstance:ExecuteCMD("Slate.EnableGIThrottleSkipUpdateOpt", 0)
    GameInstance:ExecuteCMD("Slate.EnableGIThrottle", 0)
    GameInstance:ExecuteCMD("Slate.EnableGIThrottle", 0)
  end
  GameInstance:ExecuteCMD("Slate.EnableWidgetTickFrequency", 0)
  GameInstance:ExecuteCMD("Slate.EnableThrottle", 0)
  GameInstance:ExecuteCMD("Slate.EnableIsChildWidgetCulledOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableArrangeLayeredChildrenOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableCalculateCullingAndClippingRulesOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableAddShapedTextElementOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableNewKeyboardConfigOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableGetShaderResourceOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableTunePrePassSortMapOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableTunePassOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableTuneElementsNewOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableAlwaysPaintOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableTuneElements", 0)
  GameInstance:ExecuteCMD("Slate.EnableLinePreMerge", 0)
  GameInstance:ExecuteCMD("Slate.UIDynamicBatchOpt", 0)
  GameInstance:ExecuteCMD("Slate.UIDynamicBatchTextOpt", 0)
  GameInstance:ExecuteCMD("Slate.UIDynamicBatchCustomOpt", 0)
end

function ClientEVOConfig.OnBeforeConfirmBackToLobby()
  if not Client then
    return
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  ClientEVOConfig.ToggleNotRenderedParallelUpdate(false)
  ClientEVOConfig.ToggleRefreshBonesTickAnimationOpt(false)
  if ClientEVOConfig.CollectorTimerID and ClientEVOConfig.CollectorTimerID > 0 then
    local time_ticker = require("common.time_ticker")
    time_ticker.RemoveTimer(ClientEVOConfig.CollectorTimerID)
    ClientEVOConfig.CollectorTimerID = 0
  end
  ClientEVOConfig.bLevelEnd = true
  if not PublishRegionMacros.IsBlueholeOperationRegion() then
    local TApmHelper = import("TApmHelper")
    local TApmSceneMarker = import("TApmSceneMarker")
    TApmHelper.postEvent(606, "end", false)
    TApmSceneMarker.MarkFlowScene(111)
  end
  GameInstance:ExecuteCMD("Jank.EnableCollectionFromGamePlay", 0)
  GameInstance:ExecuteCMD("Slate.EnableDownTickIntervalForGamePlay", 0)
  GameInstance:ExecuteCMD("s.EnableLoadObjectOptFromGamePlay", 0)
  Client.ClearJankStats()
  Client.SyncLoadInfoCollector_OnLevelEnd()
end

function ClientEVOConfig.HandleOnBattleResultStartPase()
  if not Client then
    return
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  ClientEVOConfig.ToggleSlateGI(false)
  ClientEVOConfig.ToggleSlateLayoutCache(false)
  if not ClientEVOConfig.bSlateGIThrottleSetByGM then
    GameInstance:ExecuteCMD("Slate.DisableVolatileThrottle", 0)
    GameInstance:ExecuteCMD("Slate.EnableGIThrottleSkipUpdateOpt", 0)
    GameInstance:ExecuteCMD("Slate.EnableGIThrottle", 0)
    GameInstance:ExecuteCMD("Slate.EnableGIThrottle", 0)
  end
  GameInstance:ExecuteCMD("Slate.EnableWidgetTickFrequency", 0)
  GameInstance:ExecuteCMD("Slate.EnableThrottle", 0)
  GameInstance:ExecuteCMD("Slate.EnableIsChildWidgetCulledOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableArrangeLayeredChildrenOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableCalculateCullingAndClippingRulesOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableAddShapedTextElementOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableNewKeyboardConfigOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableGetShaderResourceOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableTunePrePassSortMapOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableTunePassOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableTuneElementsNewOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableAlwaysPaintOpt", 0)
  GameInstance:ExecuteCMD("Slate.EnableTuneElements", 0)
  GameInstance:ExecuteCMD("Slate.EnableLinePreMerge", 0)
  GameInstance:ExecuteCMD("Slate.UIDynamicBatchOpt", 0)
  GameInstance:ExecuteCMD("Slate.UIDynamicBatchTextOpt", 0)
  GameInstance:ExecuteCMD("Slate.UIDynamicBatchCustomOpt", 0)
end

function ClientEVOConfig.HandleOnBattleResultEndPase()
  if not Client then
    return
  end
end

function ClientEVOConfig.PostBackEndSwitcherSet(SmartBearerSwitcher, SuperFrameSwitcher, ClientBackEndSwitcherA, ClientBackEndSwitcherB, ClientBackEndSwitcherC, PostLoadSwitcher)
  local switcher = "SmartBearerSwitcher:" .. tostring(SmartBearerSwitcher) .. ",SuperFrameSwitcher:" .. tostring(SuperFrameSwitcher) .. ",ClientBackEndSwitcherA:" .. tostring(ClientBackEndSwitcherA) .. ",ClientBackEndSwitcherB:" .. tostring(ClientBackEndSwitcherB) .. ",ClientBackEndSwitcherC:" .. tostring(ClientBackEndSwitcherC) .. ",PostLoadSwitcher:" .. tostring(PostLoadSwitcher)
  local SmartBearerManagerLuaBridge = import("SmartBearerManagerLuaBridge")
  if SmartBearerManagerLuaBridge and SmartBearerManagerLuaBridge.IsLightLossyOptEnable then
    switcher = switcher .. ",LightGlobalOptLossy:" .. tostring(SmartBearerManagerLuaBridge.IsLightLossyOptEnable()) .. ",LightGlobalOptCommon:" .. tostring(SmartBearerManagerLuaBridge.IsLightCommonOptEnable())
  end
  Client.AddAttachFileString("ClientEVOBackEndSwitcher", false, switcher)
  local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
  ClientEVOConfig.SavedUseLowFakeLandScape = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("r.FakeLandscape.EnableLow")
  if not PublishRegionMacros.IsBlueholeOperationRegion() then
    local TApmHelper = import("TApmHelper")
    TApmHelper.postEvent(788, Client.GetYYXDeviceModel(), false)
  end
end

function ClientEVOConfig.ApplyTextureGroupBiasFallback()
  local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
  local IsTextureStreamingOpen = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("r.TextureStreaming") or 0
  local EnableBiasWhenTexStreamingOff = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("r.EnableBiasWhenTexStreamingOff") or 0
  if IsTextureStreamingOpen == 0 and EnableBiasWhenTexStreamingOff == 1 then
    if ClientEVOConfig.bTextureGroupBiasApplied then
      return
    end
    Client.SetAllTextureGroupBiasFromQuality()
    ClientEVOConfig.bTextureGroupBiasApplied = true
    log_shipping_client("[ClientEVOConfig] ApplyTextureGroupBiasFallback: TextureStreaming=0, bias applied via C++")
  end
end

function ClientEVOConfig.ResetTextureGroupBiasFallback()
  if not ClientEVOConfig.bTextureGroupBiasApplied then
    return
  end
  Client.ResetAllTextureGroupBiasFromQuality()
  ClientEVOConfig.bTextureGroupBiasApplied = false
  log_shipping_client("[ClientEVOConfig] ResetTextureGroupBiasFallback: bias reset")
end

function ClientEVOConfig.OnModePreSwitch(preState, nextState)
  if not Client then
    return
  end
  if GameStatus.IsPreSwitchEnterFightingFromLobbyOrMainCity(preState, nextState) then
    ClientEVOConfig.ToggleNotRenderedParallelUpdate(ClientEVOConfig.bEnableNotRenderedParallelUpdateBackEnd)
    ClientEVOConfig.ToggleRefreshBonesTickAnimationOpt(ClientEVOConfig.bEnableRefreshBonesTickAnimationOptBackEnd)
  end
  if preState == nextState then
    log(bWriteLog and "[ClientEVOConfig] OnModePreSwitch return preState == nextState!!")
    return
  end
  log(bWriteLog and "[ClientEVOConfig] OnModePreSwitch nextState=" .. tostring(nextState))
  if ClientEVOConfig.bLevelStreamingBackEndEnable then
    if nextState == GameStatus.Lobby and ClientEVOConfig.bEnterBorderland then
      ClientEVOConfig.bEnterBorderland = false
      ClientEVOConfig.EnableLevelStreamingOpt()
    elseif nextState == GameStatus.Lobby and ClientEVOConfig.bEnterTMod then
      ClientEVOConfig.bEnterTMod = false
      ClientEVOConfig.EnableLevelStreamingOpt()
    elseif nextState == GameStatus.Lobby and ClientEVOConfig.bEnterSingleMode then
      ClientEVOConfig.bEnterSingleMode = false
      ClientEVOConfig.EnableLevelStreamingOpt()
    end
  end
  if ClientEVOConfig.bTickAsyncLoadingBackEndEnable then
    if nextState == GameStatus.Lobby and ClientEVOConfig.bTickAsyncLoadingSetInFighting then
      ClientEVOConfig.DisableTickAsyncLoadingOpt()
      ClientEVOConfig.bTickAsyncLoadingSetInFighting = false
    end
    if nextState == GameStatus.Fighting and not ClientEVOConfig.bTickAsyncLoadingSetInFighting then
      ClientEVOConfig.EnableTickAsyncLoadingOpt()
      ClientEVOConfig.bTickAsyncLoadingSetInFighting = true
    end
  end
  if nextState ~= GameStatus.Fighting then
    ClientEVOConfig.ToggleProfileInNeon(false, "lobby")
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  if ClientEVOConfig.bEnableUIDynamicBatch then
    if nextState == GameStatus.Lobby then
      GameInstance:ExecuteCMD("Slate.EnableTuneElements", 0)
      GameInstance:ExecuteCMD("Slate.EnableLinePreMerge", 0)
      GameInstance:ExecuteCMD("Slate.UIDynamicBatchOpt", 0)
      GameInstance:ExecuteCMD("Slate.UIDynamicBatchTextOpt", 0)
      GameInstance:ExecuteCMD("Slate.UIDynamicBatchCustomOpt", 0)
      GameInstance:ExecuteCMD("Slate.EnableRenderTune", 0)
      GameInstance:ExecuteCMD("Slate.EnableTuneClipping", 0)
      log(bWriteLog and "[UIDynamicBatch] Slate.EnableRenderTune 0")
    end
    if nextState == GameStatus.Fighting then
      local nDeviceLevel = GameInstance:GetExactDeviceLevel()
      if nDeviceLevel <= 1 then
        GameInstance:ExecuteCMD("Slate.EnableTuneElements", 1)
        GameInstance:ExecuteCMD("Slate.EnableLinePreMerge", 1)
        GameInstance:ExecuteCMD("Slate.UIDynamicBatchOpt", 1)
        GameInstance:ExecuteCMD("Slate.UIDynamicBatchCustomOpt", 1)
        GameInstance:ExecuteCMD("Slate.EnableRenderTune", 1)
        GameInstance:ExecuteCMD("Slate.EnableTuneClipping", 1)
        log(bWriteLog and "[UIDynamicBatch] Slate.EnableRenderTune 1")
      end
      GameInstance:ResetLastTimeMobileContentScaleFactor()
    end
  end
  local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
  if not ClientEVOConfig.DefaultHitTestOptimization then
    ClientEVOConfig.DefaultHitTestOptimization = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("s.GEnableHitTestOptimization") or 0
  end
  if nextState == GameStatus.Fighting then
    GameInstance:ExecuteCMD("s.GEnableHitTestOptimization", 0)
  else
    GameInstance:ExecuteCMD("s.GEnableHitTestOptimization", ClientEVOConfig.DefaultHitTestOptimization)
  end
  if nextState ~= GameStatus.Fighting and not Client.IsEditor() then
    GameInstance:ExecuteCMD("g.EnableNewObjectPool", 0)
  end
  if ClientEVOConfig.bEnableIOSPSOCache and uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("r.IOSPSORuntimeCache") ~= 0 then
    if nextState == GameStatus.Lobby then
      FuncUtil.UE4ExecuteConsoleCommand("MetalPSOCache.Save")
      GameInstance:ExecuteCMD("r.MetalPSOCacheMode", 5)
      log(bWriteLog and "[IOSPSOCache] r.MetalPSOCacheMode 5 ignore")
    end
    if nextState == GameStatus.Fighting then
      GameInstance:ExecuteCMD("r.MetalPSOCacheMode", 3)
      log(bWriteLog and "[IOSPSOCache] r.MetalPSOCacheMode 3 Append And Use")
    end
  end
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  if nextState == GameStatus.Lobby then
    GameInstance:ExecuteCMD("r.Mobile.IOSAsyncCreatePSO", 0)
    GameInstance:ExecuteCMD("r.Mobile.IOSAsyncCreatePSOTranslucent", 0)
    GameInstance:ExecuteCMD("r.AsyncCreateTexture", 0)
    ClientEVOConfig.ResetTextureGroupBiasFallback()
    local EnergySaving = import("EnergySavingManagerLuaBridge")
    if EnergySaving then
      EnergySaving.CloseEnergySavingMode()
    end
    GameInstance:ExecuteCMD("r.HLOD.EnableScopeDistanceScale", 0)
    GameInstance:ExecuteCMD("a.URO.Enable", 0)
    GameInstance:ExecuteCMD("r.CachePSOSeparateFighting", 0)
    if PublishRegionMacros.IsFITVersion() then
      GameInstance:ExecuteCMD("r.GlobalParticleMinTimeBetweenTick", 0)
    end
    GameInstance:ExecuteCMD("r.ParticleMinTimeBetweenTick", 0)
    GameInstance:ExecuteCMD("r.ParticleMinTimeTickDistance", 5000)
    GameInstance:ExecuteCMD("r.EnableDynamicRenderingThreadTickFrequency", 1)
    GameInstance:ExecuteCMD("r.HideAvatarLODNewMethod", 0)
    GameInstance:ExecuteCMD("r.EnableClothBiasLODAutonomous", 0)
    if Client.HDmpveRemoteConfigGetInt("SkipWaitRHIThreadForFlushResInGame", 0) == 1 then
      GameInstance:ExecuteCMD("r.RHI.SkipWaitRHIThreadForFlushRes", 0)
    end
    local AsyncCompilePSOSkinModeInGame = Client.HDmpveRemoteConfigGetInt("AsyncCompileSkinModeInGame", -1)
    if 0 <= AsyncCompilePSOSkinModeInGame then
      GameInstance:ExecuteCMD("r.AsyncCompileSkinMode", 0)
    end
  else
    GameInstance:ExecuteCMD("a.URO.Enable", 1)
    GameInstance:ExecuteCMD("r.CachePSOSeparateFighting", 1)
    local nDeviceLevel = GameInstance:GetExactDeviceLevel()
    if PublishRegionMacros.IsFITVersion() and nDeviceLevel <= 1 then
      GameInstance:ExecuteCMD("r.GlobalParticleMinTimeBetweenTick", 1)
      GameInstance:ExecuteCMD("r.ParticleMinTimeBetweenTick", 100)
    else
      GameInstance:ExecuteCMD("r.ParticleMinTimeBetweenTick", 25)
    end
    GameInstance:ExecuteCMD("r.ParticleMinTimeTickDistance", 0)
    GameInstance:ExecuteCMD("r.EnableDynamicRenderingThreadTickFrequency", 0)
    GameInstance:ExecuteCMD("r.HideAvatarLODNewMethod", 1)
    GameInstance:ExecuteCMD("r.EnableClothBiasLODAutonomous", 1)
    if Client.HDmpveRemoteConfigGetInt("SkipWaitRHIThreadForFlushResInGame", 0) == 1 then
      GameInstance:ExecuteCMD("r.RHI.SkipWaitRHIThreadForFlushRes", 1)
    end
    local AsyncCompilePSOSkinModeInGame = Client.HDmpveRemoteConfigGetInt("AsyncCompileSkinModeInGame", -1)
    if 0 <= AsyncCompilePSOSkinModeInGame then
      GameInstance:ExecuteCMD("r.AsyncCompileSkinMode", AsyncCompilePSOSkinModeInGame)
    end
  end
  local lowVirDevice = Client.GetAndroidSOVersion() == 32 and 3 > Client.GetMemorySize()
  if nextState == GameStatus.Fighting and not lowVirDevice then
    GameInstance:ExecuteCMD("r.Mobile.IOSAsyncCreatePSO", 1)
    GameInstance:ExecuteCMD("r.Mobile.IOSAsyncCreatePSOTranslucent", 1)
    local nDeviceLevel = GameInstance:GetExactDeviceLevel()
    if nDeviceLevel <= 0 then
      GameInstance:ExecuteCMD("r.AsyncCreateTexture", 1)
    end
  end
  if 0 < ClientEVOConfig.ManagedTickSysFlagBackEnd and nextState == GameStatus.Fighting then
    GameInstance:ExecuteCMD("tick.EnableManagedTickSysFlag", ClientEVOConfig.ManagedTickSysFlagBackEnd)
  else
    GameInstance:ExecuteCMD("tick.EnableManagedTickSysFlag", 0)
  end
  Client.SwitchMapMangedTickProfile(ClientEVOConfig.CurrentModID)
  if nextState == GameStatus.Fighting and not ClientEVOConfig.bLightOptAppliedInFighting then
    ClientEVOConfig.EnterFightingLightOpt()
  elseif nextState == GameStatus.Lobby and ClientEVOConfig.bLightOptAppliedInFighting then
    ClientEVOConfig.LeaveFightingLightOpt()
  end
  local Enable3DShareUI = Client.HDmpveRemoteConfigGetBool("Enable3DShareUI", false)
  if Enable3DShareUI then
    if nextState == GameStatus.Fighting then
      GameInstance:ExecuteCMD("slate.Enable3DShareUI", 1)
    else
      GameInstance:ExecuteCMD("slate.Enable3DShareUI", 0)
    end
  end
  if nextState == GameStatus.Lobby then
    ClientEVOConfig.ToggleSlateGI(false)
    ClientEVOConfig.ToggleActorSpawnQueue(false)
  end
  if nextState == GameStatus.Fighting then
    ClientEVOConfig.ToggleSlateVerifyHitTestVisibility(true)
    ClientEVOConfig.ToggleRemoveVolatilePrepassFlag(true)
    ClientEVOConfig.ToggleFixSlateFastPathHitTest(true)
  end
end

function ClientEVOConfig.OnSetInGameModeID(ModID)
  if not Client then
    return
  end
  log(bWriteLog and "[ClientEVOConfig] OnSetInGameModeID ModID=" .. tostring(ModID))
  local TableUtil = require("common.table_util")
  ClientEVOConfig.CurrentModID = ModID
  ClientEVOConfig.CurrentModType = ""
  if ClientEVOConfig.bLevelStreamingBackEndEnable then
    if not ClientEVOConfig.bEnterBorderland and TableUtil.IsInTable(ClientEVOConfig.BorderlandModList, ModID) then
      ClientEVOConfig.bEnterBorderland = true
      ClientEVOConfig.DisableLevelStreamingOpt()
    elseif not ClientEVOConfig.bEnterTMod and TableUtil.IsInTable(ClientEVOConfig.TModList, ModID) then
      ClientEVOConfig.bEnterTMod = true
      ClientEVOConfig.DisableLevelStreamingOpt()
    elseif not ClientEVOConfig.bEnterSingleMode and TableUtil.IsInTable(ClientEVOConfig.SingModlList, ModID) then
      ClientEVOConfig.bEnterSingleMode = true
      ClientEVOConfig.DisableLevelStreamingOpt()
    end
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
  if ModID and tonumber(ModID) then
    local SubModeCfg = CDataTable.GetTableData("BTMode", tonumber(ModID))
    if SubModeCfg and SubModeCfg.ModType then
      log(bWriteLog and "ClientEVOConfig.OnSetInGameModeID: " .. SubModeCfg.ModType)
      local StringUtil = require("common.string_util")
      local ModTypes = StringUtil.Split(SubModeCfg.ModType, ";")
      local ModType = ModTypes and ModTypes[1]
      ClientEVOConfig.CurrentModType = ModType or ""
      if ModType and (ClientEVOConfig.SlateGIAvailableMod[ModType] == true or ClientEVOConfig.SlateGIAvailableMod[ModType] == nil) and not ClientEVOConfig.IsCreativeMode() then
        log_shipping_client("ClientEVOConfig ToggleSlateGI Mod: " .. SubModeCfg.ModType)
        ClientEVOConfig.ToggleSlateGI(true)
      else
        ClientEVOConfig.ToggleSlateGI(false)
        log_shipping_client("ClientEVOConfig ToggleSlateGI Mod: " .. SubModeCfg.ModType .. " Not Supported Mod")
      end
      local bNewObjectPoolEnabled = false
      if ModType and (ClientEVOConfig.NewObjectPoolAvailableMod[ModType] == true or ClientEVOConfig.NewObjectPoolAvailableMod[ModType] == nil) then
        bNewObjectPoolEnabled = true
        if HDmpveRemote.HDmpveRemoteConfigGetInt("ForceDisableObjectPool", 0) == 1 then
          bNewObjectPoolEnabled = false
        end
      end
      if bNewObjectPoolEnabled then
        GameInstance:ExecuteCMD("g.EnableNewObjectPool", 1)
        log(bWriteLog and "ClientEVOConfig.OnSetInGameModeID: " .. SubModeCfg.ModType .. " EnableNewObjectPool: " .. tostring(1))
      else
        GameInstance:ExecuteCMD("g.EnableNewObjectPool", 0)
        log(bWriteLog and "ClientEVOConfig.OnSetInGameModeID: " .. SubModeCfg.ModType .. " EnableNewObjectPool: 0 Not Supported Mod")
      end
      if ModType and ClientEVOConfig.LayoutCacheAvailableMod[ModType] then
        log_shipping_client("ClientEVOConfig ToggleSlateLayoutCache Mod: " .. SubModeCfg.ModType)
        ClientEVOConfig.ToggleSlateLayoutCache(true)
      end
      if ModType and ClientEVOConfig.InvalidationPanelsAvailableMod[ModType] == false then
        log_shipping_client("ClientEVOConfig ToggleInvalidationPanels Disable for Mod: " .. SubModeCfg.ModType)
        ClientEVOConfig.ToggleInvalidationPanels(false)
      else
        ClientEVOConfig.ToggleInvalidationPanels(ClientEVOConfig.bEnableInvalidationPanelsCloud or IsEditor)
      end
      if ModType and ClientEVOConfig.ActorSpawnQueueAvailableMod[ModType] == true then
        log_shipping_client("ClientEVOConfig ToggleActorSpawnQueue Enable for Mod: " .. SubModeCfg.ModType)
        ClientEVOConfig.ToggleActorSpawnQueue(ClientEVOConfig.bEnableActorSpawnQueueCloud or IsEditor)
      else
        ClientEVOConfig.ToggleActorSpawnQueue(false)
      end
    end
  end
  if not ClientEVOConfig.NewObjectPoolGCConfigValue then
    local CVarEnableTemporalDisregardForGC = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("g.EnableTemporalDisregardForGC")
    local CVarNewObjectPoolDisregardForGC = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("g.NewObjectPool.DisregardForGC")
    ClientEVOConfig.NewObjectPoolGCConfigValue = CVarEnableTemporalDisregardForGC == 1 and CVarNewObjectPoolDisregardForGC == 1
  end
  if ClientEVOConfig.bNewObjectPoolGCOptimizationEnable and ClientEVOConfig.NewObjectPoolGCConfigValue then
    GameInstance:ExecuteCMD("g.EnableTemporalDisregardForGC", 1)
    GameInstance:ExecuteCMD("g.NewObjectPool.DisregardForGC", 1)
  else
    GameInstance:ExecuteCMD("g.EnableTemporalDisregardForGC", 0)
    GameInstance:ExecuteCMD("g.NewObjectPool.DisregardForGC", 0)
  end
  if ClientEVOConfig.bNewObjectPoolDefferedPhysicsState or Client.IsEditor() then
    GameInstance:ExecuteCMD("p.CanForcePhysicsStateDeferred", 1)
  else
    GameInstance:ExecuteCMD("p.CanForcePhysicsStateDeferred", 0)
  end
end

function ClientEVOConfig.OnPreLoadMap(mapName)
  if not Client then
    return
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  Client.ClearSyncLoadCacheSystem()
  GameInstance:ExecuteCMD("s.EnableSyncLoadCacheSystem_GamePlay", 0)
  log(bWriteLog and "[ClientEVOConfig] OnPreLoadMap EnableSyncLoadCacheSystem_GamePlay~2")
  ClientEVOConfig.LastWorldName = ClientEVOConfig.CurrentWorldName
  ClientEVOConfig.CurrentWorldName = Client.GetCleanFileName(mapName)
  if ClientEVOConfig.bUseLowFakeLandScapeBackEndEnable then
    local bIsBalticMaps = string.find(mapName, "Baltic_Main", 1)
    if bIsBalticMaps then
      GameInstance:ExecuteCMD("r.FakeLandscape.EnableLow", 1)
    else
      GameInstance:ExecuteCMD("r.FakeLandscape.EnableLow", ClientEVOConfig.SavedUseLowFakeLandScape)
    end
  end
  ClientEVOConfig.ToggleProfileInNeon(true, ClientEVOConfig.CurrentWorldName)
  if ClientEVOConfig.BackUpbUseNewHole == -1 then
    local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
    ClientEVOConfig.BackUpbUseNewHole = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("r.UseNewLandscapeHole")
    ClientEVOConfig.BakcUpNumVisibleComponents = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("r.VisiableComponentNumOnLanded")
    log_shipping_client("[ClientEVOConfig] LandscapeBackup BackUpbUseNewHole " .. tostring(ClientEVOConfig.BackUpbUseNewHole) .. " BakcUpNumVisibleComponents " .. tostring(ClientEVOConfig.BakcUpNumVisibleComponents))
  end
  local SmartBearerManagerLuaBridge = import("SmartBearerManagerLuaBridge")
  if SmartBearerManagerLuaBridge ~= nil then
    local bSubMountPointOptEnable = SmartBearerManagerLuaBridge.IsClientBackEndSwitcherBEnable(23)
    local bFindFileOpt_Pandora = SmartBearerManagerLuaBridge.IsClientBackEndSwitcherBEnable(24)
    local bIsBRMap = string.find(mapName, "Baltic_Main", 1) or string.find(mapName, "FourMaps_Main", 1)
    log_shipping_client("[ClientEVOConfig] SubMountPointOpt bIsBRMap[" .. tostring(bIsBRMap) .. "] bSubMountPointOptEnable[" .. tostring(bSubMountPointOptEnable) .. "] bFindFileOpt_Pandora[" .. tostring(bFindFileOpt_Pandora) .. "]")
    if bIsBRMap and bSubMountPointOptEnable and Client.EnableSubMountPoint() then
      GameInstance:ExecuteCMD("r.FindFileSubMountPointOpt", 1)
      GameInstance:ExecuteCMD("r.TrustSubMountPoint", 1)
    else
      GameInstance:ExecuteCMD("r.FindFileSubMountPointOpt", 0)
      GameInstance:ExecuteCMD("r.FindFileOptEnablePandoraPakOpt", 0)
    end
    if bIsBRMap and bFindFileOpt_Pandora then
      GameInstance:ExecuteCMD("r.FindFileOptEnablePandoraPakOpt", 1)
    else
      GameInstance:ExecuteCMD("r.TrustSubMountPoint", 0)
    end
  end
end

function ClientEVOConfig.OnModePostSwitch(preState, nextState)
  if not Client then
    return
  end
  ClientEVOConfig.RefreshNotRenderedParallelUpdate()
  ClientEVOConfig.RefreshBonesTickAnimationOpt()
  if preState == nextState then
    log(bWriteLog and "[ClientEVOConfig] OnModePostSwitch return preState == nextState!!")
    return
  end
  ClientEVOConfig.bLevelEnd = false
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  GameInstance:ExecuteCMD("Slate.EnableDownTickIntervalForGamePlay", 0)
  Client.ResetAllSlateTickEveryFrame()
  log(bWriteLog and "[ClientEVOConfig] OnModePostSwitch nextState=" .. tostring(nextState) .. ",CurrentModID:" .. tostring(ClientEVOConfig.CurrentModID))
  Client.TPerforPlatDataReport(GameFrontendHUD, 401, tostring(ClientEVOConfig.CurrentModID))
  Client.ClearSyncLoadCacheSystem()
  if not GameStatus.InSupportDownloadState() then
    GameInstance:ExecuteCMD("s.EnableSyncLoadCacheSystem_GamePlay", 1)
    log(bWriteLog and "[ClientEVOConfig] OnModePostSwitch EnableSyncLoadCacheSystem_GamePlay new ~1")
  else
    GameInstance:ExecuteCMD("s.EnableSyncLoadCacheSystem_GamePlay", 0)
    log(bWriteLog and "[ClientEVOConfig] OnModePostSwitch EnableSyncLoadCacheSystem_GamePlay new ~0")
  end
  if not PublishRegionMacros.IsBlueholeOperationRegion() then
    if nextState == GameStatus.Fighting then
      local logic_mode_selection = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection)
      local _, viewId = logic_mode_selection:GetCurSelectInfo()
      local logic_enter_game = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game)
      local BTMode = CDataTable.GetTableData("BTMode", logic_enter_game.sub_mode)
      local ModeFightType = -1
      if BTMode and BTMode.ModeFightType then
        ModeFightType = BTMode.ModeFightType
      end
      local viewTable = CDataTable.GetSplitTableData("Lobby", "ModeSelection", "view_contain_table", viewId)
      local RankType = -1
      if viewTable and viewTable.is_rank then
        RankType = viewTable.is_rank
      end
      local TApmHelper = import("TApmHelper")
      local tempValue = ModeFightType % 10 * 10
      tempValue = tempValue + RankType % 10
      log(bWriteLog and "[ClientEVOConfig] PostModeID to TGPA" .. tostring(logic_enter_game.sub_mode) .. "ModeType: " .. tostring(ModeFightType) .. "RankType: " .. tostring(RankType) .. "TGPAValue: " .. tostring(tempValue))
      TApmHelper.PostGameStatusToTGPAIS(40, tostring(tempValue))
    else
      local TApmHelper = import("TApmHelper")
      TApmHelper.PostGameStatusToTGPAIS(40, tostring(0))
      log(bWriteLog and "[ClientEVOConfig] PostModeID to TGPA" .. tostring(0))
    end
  end
end

function ClientEVOConfig.ToggleProfileInNeon(bEnable, mapName)
  log(bWriteLog and "[ClientEVOConfig] ToggleProfileInNeon currmap" .. mapName .. "Enable?:" .. tostring(bEnable))
  local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  if bEnable then
    local Pos = string.find(mapName, "PUBG_Neon_Main")
    if Pos then
      log(bWriteLog and "[ClientEVOConfig] ToggleProfileInNeon NEon Toggle")
      local mipLodBias = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("r.MipLODBiasFromQuality")
      local TCDeviceLevel = Client.GetTCDeviceLevel()
      if TCDeviceLevel < 7 and ClientEVOConfig.TextureMipOffsetbackUp == -1 then
        if mipLodBias < 1 then
          GameInstance:ExecuteCMD("r.MipLODBiasFromQuality", 1)
          ClientEVOConfig.TextureMipOffsetbackUp = 0
        end
        GameInstance:ExecuteCMD("r.SuperFrame.ScreenSizeCullFactor", 1.2)
      end
    end
  else
    log(bWriteLog and "[ClientEVOConfig] ToggleProfileInNeon NEon Toggle")
    local TCDeviceLevel = Client.GetTCDeviceLevel()
    if TCDeviceLevel < 7 and ClientEVOConfig.TextureMipOffsetbackUp == 0 then
      GameInstance:ExecuteCMD("r.MipLODBiasFromQuality", 0)
      ClientEVOConfig.TextureMipOffsetbackUp = -1
      GameInstance:ExecuteCMD("r.SuperFrame.ScreenSizeCullFactor", 1.0)
    end
  end
end

function ClientEVOConfig.GetSlateGIState()
  local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
  local SlateGIStatus = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("slate.EnableGI")
  if SlateGIStatus == 1 then
    return true
  else
    return false
  end
end

function ClientEVOConfig.GetIBState()
  local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
  local IBStatus = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("Slate.EnableInvalidationPanels")
  if IBStatus == 1 then
    return true
  else
    return false
  end
end

function ClientEVOConfig.ToggleInvalidationPanels(bEnable)
  if not ClientEVOConfig.bEnableInvalidationPanelsCloud and not IsEditor then
    log_shipping_client("[ClientEVOConfig] ToggleInvalidationPanels Cloud Switch Off")
    bEnable = false
  end
  if Client.IsWindowOB() then
    log_shipping_client("[ClientEVOConfig] ToggleInvalidationPanels Window is OB, disable InvalidationPanels")
    bEnable = false
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  if bEnable then
    GameInstance:ExecuteCMD("Slate.EnableInvalidationPanels", 1)
    log_shipping_client("[ClientEVOConfig] ToggleInvalidationPanels Slate.EnableInvalidationPanels 1")
  else
    GameInstance:ExecuteCMD("Slate.EnableInvalidationPanels", 0)
    log_shipping_client("[ClientEVOConfig] ToggleInvalidationPanels Slate.EnableInvalidationPanels 0")
  end
end

function ClientEVOConfig.ToggleSlateVerifyHitTestVisibility(bEnable)
  if not ClientEVOConfig.bEnableSlateVerifyHitTestVisibilityCloud and not IsEditor then
    log_shipping_client("[ClientEVOConfig] ToggleSlateVerifyHitTestVisibility Cloud Switch Off")
    bEnable = false
  else
    log_shipping_client("[ClientEVOConfig] ToggleSlateVerifyHitTestVisibility Cloud Switch On")
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  if not GameInstance or not slua.isValid(GameInstance) then
    log_shipping_client("[ClientEVOConfig] ToggleSlateVerifyHitTestVisibility GameInstance is nil or invalid")
    return
  end
  if bEnable then
    GameInstance:ExecuteCMD("Slate.VerifyHitTestVisibility", 1)
    log_shipping_client("[ClientEVOConfig] ToggleSlateVerifyHitTestVisibility Slate.VerifyHitTestVisibility 1")
  else
    GameInstance:ExecuteCMD("Slate.VerifyHitTestVisibility", 0)
    log_shipping_client("[ClientEVOConfig] ToggleSlateVerifyHitTestVisibility Slate.VerifyHitTestVisibility 0")
  end
end

function ClientEVOConfig.ToggleFixSlateFastPathHitTest(bEnable)
  if not ClientEVOConfig.bEnableFixSlateFastPathHitTestCloud and not IsEditor then
    log_shipping_client("[ClientEVOConfig] ToggleFixSlateFastPathHitTest Cloud Switch Off")
    bEnable = false
  else
    log_shipping_client("[ClientEVOConfig] ToggleFixSlateFastPathHitTest Cloud Switch On")
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  if not GameInstance or not slua.isValid(GameInstance) then
    log_shipping_client("[ClientEVOConfig] ToggleFixSlateFastPathHitTest GameInstance is nil or invalid")
    return
  end
  if bEnable then
    GameInstance:ExecuteCMD("Slate.EnableRemoveFromParentHittestGridOnFastPath", 1)
    GameInstance:ExecuteCMD("Slate.RemoveGridFromParentIfCanNotCache", 1)
    log_shipping_client("[ClientEVOConfig] ToggleFixSlateFastPathHitTest Enabled")
  else
    GameInstance:ExecuteCMD("Slate.EnableRemoveFromParentHittestGridOnFastPath", 0)
    GameInstance:ExecuteCMD("Slate.RemoveGridFromParentIfCanNotCache", 0)
    log_shipping_client("[ClientEVOConfig] ToggleFixSlateFastPathHitTest Disabled")
  end
end

function ClientEVOConfig.ToggleRemoveVolatilePrepassFlag(bEnable)
  if not ClientEVOConfig.bEnableRemoveVolatilePrepassFlagCloud and not IsEditor then
    log_shipping_client("[ClientEVOConfig] ToggleRemoveVolatilePrepassFlag Cloud Switch Off")
    bEnable = false
  else
    log_shipping_client("[ClientEVOConfig] ToggleRemoveVolatilePrepassFlag Cloud Switch On")
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  if not GameInstance or not slua.isValid(GameInstance) then
    log_shipping_client("[ClientEVOConfig] ToggleRemoveVolatilePrepassFlag GameInstance is nil or invalid")
    return
  end
  if bEnable then
    GameInstance:ExecuteCMD("Slate.RemoveVolatilePrepassFlagIfCanNotCache", 1)
    log_shipping_client("[ClientEVOConfig] ToggleRemoveVolatilePrepassFlag Enabled")
  else
    GameInstance:ExecuteCMD("Slate.RemoveVolatilePrepassFlagIfCanNotCache", 0)
    log_shipping_client("[ClientEVOConfig] ToggleRemoveVolatilePrepassFlag Disabled")
  end
end

function ClientEVOConfig.ToggleSlateGI(bEnable, bNeedDelay)
  ClientEVOConfig.bNeedDelayEnableSlateGI = false
  bNeedDelay = bNeedDelay or false
  if not ClientEVOConfig.bEnableSlateGICloud and not IsEditor then
    log_shipping_client("[ClientEVOConfig] ToggleSlateGI Cloud Switch Off")
    bEnable = false
  else
    log_shipping_client("[ClientEVOConfig] ToggleSlateGI Cloud Switch On")
  end
  if ClientEVOConfig.CurrentModID == 0 then
    log_shipping_client("[ClientEVOConfig] ToggleSlateGI CurrentModID is 0, disable SlateGI")
    bEnable = false
  end
  if Client.IsWindowOB() then
    log_shipping_client("[ClientEVOConfig] ToggleSlateGI Window is OB, disable SlateGI")
    bEnable = false
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  if not GameInstance or not slua.isValid(GameInstance) then
    log_shipping_client("[ClientEVOConfig] ToggleSlateGI GameInstance is nil or invalid")
    return
  end
  local MaxAllowDeviceLevel = HDmpveRemote.HDmpveRemoteConfigGetInt("SlateGIMaxAllowDeviceLevel", 99)
  local DeviceLevel = GameInstance:GetDeviceLevel()
  if MaxAllowDeviceLevel < DeviceLevel then
    log_shipping_client("[ClientEVOConfig] ToggleSlateGI DeviceLevel:" .. tostring(DeviceLevel) .. ", MaxAllowDeviceLevel:" .. tostring(MaxAllowDeviceLevel) .. ", Disable SlateGI")
    bEnable = false
  end
  local SlateGIStatus = ClientEVOConfig.GetSlateGIState()
  log_shipping_client("[ClientEVOConfig] ToggleSlateGI Current SlateGI Status:" .. tostring(SlateGIStatus) .. ", Enable?:" .. tostring(bEnable))
  if bEnable then
    if SlateGIStatus == true then
      log_shipping_client("[ClientEVOConfig] ToggleSlateGI SlateGI already enabled")
      return
    end
    if bNeedDelay then
      log_shipping_client("[ClientEVOConfig] ToggleSlateGI SlateGI will be enabled after game ui created")
      ClientEVOConfig.bNeedDelayEnableSlateGI = true
      return
    end
    GameInstance:ExecuteCMD("slate.EnableGI", 1)
    GameInstance:ExecuteCMD("slate.EnableInvalidationPanels", 0)
    log_shipping_client("[ClientEVOConfig] ToggleSlateGI Slate.EnableGI 1")
  else
    if SlateGIStatus == false then
      log_shipping_client("[ClientEVOConfig] ToggleSlateGI SlateGI already disabled")
      return
    end
    GameInstance:ExecuteCMD("slate.EnableGI", 0)
    log_shipping_client("[ClientEVOConfig] ToggleSlateGI Slate.EnableGI 0")
  end
end

function ClientEVOConfig.GetActorSpawnQueueState()
  local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
  local ActorSpawnQueueEnable = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("net.ActorSpawnQueue.Enable")
  return ActorSpawnQueueEnable == 1
end

function ClientEVOConfig.ToggleActorSpawnQueue(bEnable)
  if not ClientEVOConfig.bEnableActorSpawnQueueCloud and not ClientEVOConfig.bEnableActorSpawnQueueLightOpt then
    bEnable = false
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  local ActorSpawnQueueEnable = ClientEVOConfig.GetActorSpawnQueueState()
  log_shipping_client("[ClientEVOConfig] ToggleActorSpawnQueue Current ActorSpawnQueue Status:" .. tostring(ActorSpawnQueueEnable) .. ", Enable?:" .. tostring(bEnable))
  if bEnable then
    local ActorSpawnQueueValue = 1
    local SubModeCfg = CDataTable.GetTableData("BTMode", tonumber(ClientEVOConfig.CurrentModID))
    if SubModeCfg and SubModeCfg.ModType then
      local StringUtil = require("common.string_util")
      local ModTypes = StringUtil.Split(SubModeCfg.ModType, ";")
      local ModType = ModTypes and ModTypes[1]
      if ModType and ClientEVOConfig.ActorSpawnQueueAvailableMod[ModType] == false then
        ActorSpawnQueueValue = 0
      end
    end
    GameInstance:ExecuteCMD("net.ActorSpawnQueue.Enable", ActorSpawnQueueValue)
    GameInstance:ExecuteCMD("net.ActorSpawnQueue.UseObjectPool", 1)
    GameInstance:ExecuteCMD("BudgetScheduler.Enable", 1)
    GameInstance:ExecuteCMD("net.FrameBudget.Enable", 1)
    log_shipping_client("[ClientEVOConfig] ToggleActorSpawnQueue net.ActorSpawnQueue.Enable " .. tostring(ActorSpawnQueueValue))
  else
    GameInstance:ExecuteCMD("net.ActorSpawnQueue.Enable", 0)
    GameInstance:ExecuteCMD("BudgetScheduler.Enable", 0)
    GameInstance:ExecuteCMD("net.FrameBudget.Enable", 0)
    log_shipping_client("[ClientEVOConfig] ToggleActorSpawnQueue net.ActorSpawnQueue.Enable 0")
  end
end

function ClientEVOConfig.ToggleSlateLayoutCache(bEnable)
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  ClientEVOConfig.bEnableSlateLayoutCache = ClientEVOConfig.bEnableSlateLayoutCacheBackendValue
  SwitcherModifiedCount = 0
  if not ClientEVOConfig.bEnableSlateLayoutCache then
    GameInstance:ExecuteCMD("slate.EnableLayoutCaching", 0)
    GameInstance:ExecuteCMD("slate.AutoFixSlateLayoutCaching", 0)
    return
  end
  local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
  local SlateLayoutCacheStatus = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableIntValue("slate.EnableLayoutCaching")
  if bEnable then
    if SlateLayoutCacheStatus ~= 1 then
      GameInstance:ExecuteCMD("slate.EnableLayoutCaching", 1)
      GameInstance:ExecuteCMD("slate.AutoFixSlateLayoutCaching", 1)
      log_shipping_client("[ClientEVOConfig] ToggleSlateLayoutCache Slate.EnableLayoutCaching 1")
      log_shipping_client("[ClientEVOConfig] ToggleSlateLayoutCache Slate.AutoFixSlateLayoutCaching 1")
    end
  elseif SlateLayoutCacheStatus == 1 then
    GameInstance:ExecuteCMD("slate.EnableLayoutCaching", 0)
    GameInstance:ExecuteCMD("slate.AutoFixSlateLayoutCaching", 0)
    log_shipping_client("[ClientEVOConfig] ToggleSlateLayoutCache Slate.EnableLayoutCaching 0")
    log_shipping_client("[ClientEVOConfig] ToggleSlateLayoutCache Slate.AutoFixSlateLayoutCaching 0")
  end
end

function ClientEVOConfig.GetDesiredSlateLayoutCacheState()
  if GameStatus.GetGameStatus() ~= GameStatus.Fighting then
    return 0
  end
  return ClientEVOConfig.bEnableSlateLayoutCache and 1 or 0
end

function ClientEVOConfig.ReportDeviceOverHeatInfo(key, value)
  if not PublishRegionMacros.IsBlueholeOperationRegion() then
    local TApmHelper = import("TApmHelper")
    TApmHelper.postEvent(key, tostring(value), false)
  end
end

function ClientEVOConfig.OnPostSetFPS(fpsLevel)
  if not Client then
    return
  end
  log(bWriteLog and "[ClientEVOConfig] OnPostSetFPS")
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  local TableUtil = require("common.table_util")
  if Client.IsEmulator() then
    GameInstance:ExecuteCMD("s.EnableExtDbgStat", 1)
  end
  if 7 <= fpsLevel and ClientEVOConfig.SlateTickDownWhitList[ClientEVOConfig.CurrentWorldName] and not TableUtil.IsInTable(ClientEVOConfig.TModList, ClientEVOConfig.CurrentModID) then
    if fpsLevel == 7 then
      GameInstance:ExecuteCMD("Slate.DownTickInterval", 0.0333)
    elseif fpsLevel == 8 then
      GameInstance:ExecuteCMD("Slate.DownTickInterval", 0.0333)
    end
    GameInstance:ExecuteCMD("Slate.EnableDownTickIntervalForGamePlay", 1)
  else
    GameInstance:ExecuteCMD("Slate.EnableDownTickIntervalForGamePlay", 0)
  end
  log_shipping_client("[ClientEVOConfig.OnPostSetFPS] Current WorldName:" .. tostring(ClientEVOConfig.CurrentWorldName) .. ",fpsLevel:" .. tostring(fpsLevel) .. ",CurrentModID:" .. tostring(ClientEVOConfig.CurrentModID) .. ",CurrentModType:" .. tostring(ClientEVOConfig.CurrentModType))
  ClientEVOConfig.bEnableSlateThrottle = ClientEVOConfig.EvalSlateThrottleEnabled(ClientEVOConfig.bSlateThrottleSwitchEnabled, ClientEVOConfig.bUseSlateThrottleWhiteList, ClientEVOConfig.SlateThrottleWhiteList, 8, fpsLevel)
  if not ClientEVOConfig.bSlateGIThrottleSetByGM then
    ClientEVOConfig.bEnableSlateGIThrottle = ClientEVOConfig.EvalSlateThrottleEnabled(ClientEVOConfig.bSlateGIThrottleSwitchEnabled, ClientEVOConfig.bUseSlateGIThrottleWhiteList, ClientEVOConfig.SlateGIThrottleWhiteList, 5, fpsLevel)
  end
  ClientEVOConfig.bEnableLightSlateGIThrottle = ClientEVOConfig.EvalSlateThrottleEnabled(ClientEVOConfig.bLightSlateGIThrottleSwitchEnabled, ClientEVOConfig.bUseLightSlateGIThrottleWhiteList, ClientEVOConfig.SlateGIThrottleWhiteList, nil, fpsLevel)
  ClientEVOConfig.bEnableLightWidgetTickFrequency = ClientEVOConfig.EvalSlateThrottleEnabled(ClientEVOConfig.bLightWidgetTickFrequencySwitchEnabled, ClientEVOConfig.bUseLightWidgetTickFrequencyWhiteList, ClientEVOConfig.SlateGIThrottleWhiteList, nil, fpsLevel)
  ClientEVOConfig.bEnableWidgetTickFrequency = ClientEVOConfig.EvalSlateThrottleEnabled(ClientEVOConfig.bWidgetTickFrequencySwitchEnabled, ClientEVOConfig.bUseWidgetTickFrequencyWhiteList, ClientEVOConfig.SlateGIThrottleWhiteList, 5, fpsLevel)
  if not ClientEVOConfig.bSlateGIThrottleSetByGM then
    local bEnableGIThrottle = ClientEVOConfig.bEnableLightSlateGIThrottle or ClientEVOConfig.bEnableSlateGIThrottle
    GameInstance:ExecuteCMD("Slate.EnableGIThrottle", bEnableGIThrottle and 1 or 0)
    if ClientEVOConfig.bEnableLightSlateGIThrottle then
      GameInstance:ExecuteCMD("Slate.DisableVolatileThrottle", 1)
      GameInstance:ExecuteCMD("Slate.EnableGIThrottleSkipUpdateOpt", 1)
    else
      GameInstance:ExecuteCMD("Slate.DisableVolatileThrottle", 0)
      GameInstance:ExecuteCMD("Slate.EnableGIThrottleSkipUpdateOpt", 0)
    end
  end
  if not ClientEVOConfig.bSlateFrequencySetByGM then
    if ClientEVOConfig.bEnableLightSlateGIThrottle then
      GameInstance:ExecuteCMD("Slate.Frequency", ClientEVOConfig.GetLightThrottleFrequency())
    elseif ClientEVOConfig.bEnableSlateThrottle or ClientEVOConfig.bEnableSlateGIThrottle then
      GameInstance:ExecuteCMD("Slate.Frequency", 30)
    else
      GameInstance:ExecuteCMD("Slate.Frequency", -1)
    end
  end
  if ClientEVOConfig.bEnableLightWidgetTickFrequency then
    GameInstance:ExecuteCMD("Slate.EnableWidgetTickFrequency", 1)
    GameInstance:ExecuteCMD("Slate.WidgetTickFrequency", ClientEVOConfig.GetLightThrottleFrequency())
  elseif ClientEVOConfig.bEnableWidgetTickFrequency then
    GameInstance:ExecuteCMD("Slate.EnableWidgetTickFrequency", 1)
    GameInstance:ExecuteCMD("Slate.WidgetTickFrequency", 30)
  else
    GameInstance:ExecuteCMD("Slate.EnableWidgetTickFrequency", 0)
  end
  if 8 <= fpsLevel then
    GameInstance:ExecuteCMD("s.PowerOptSepcial.LandScapeSeries.GrassUpdateInterval", 10)
    GameInstance:ExecuteCMD("s.ProcessAsyncLoadingRate", HDmpveRemote.HDmpveRemoteConfigGetInt("ProcessAsyncLoadingRate", -30) * 0.001)
  else
    GameInstance:ExecuteCMD("s.PowerOptSepcial.LandScapeSeries.GrassUpdateInterval", ClientEVOConfig.BackGrassUpdateIntervel)
    GameInstance:ExecuteCMD("s.ProcessAsyncLoadingRate", -0.003)
  end
  if 7 <= fpsLevel then
    if fpsLevel == 7 then
      GameInstance:ExecuteCMD("r.TextureStreamingReduceFrameCount", 3)
    elseif fpsLevel == 8 then
      GameInstance:ExecuteCMD("r.TextureStreamingReduceFrameCount", 4)
    end
  end
  Client.ResetAllSlateTickEveryFrame()
  if not PublishRegionMacros.IsBlueholeOperationRegion() then
    local TApmHelper = import("TApmHelper")
    local uSTExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
    local fps = uSTExtraBlueprintFunctionLibrary.GetConsoleVariableFloatValue("t.MaxFPS")
    TApmHelper.SetTragetFrameRate(fps)
  end
  local SetStreamingPoolSizeOnSetting = HDmpveRemote.HDmpveRemoteConfigGetInt("SetStreamingPoolSizeOnSetting", 0)
  if 0 < SetStreamingPoolSizeOnSetting then
    GameInstance:ExecuteCMD("r.Streaming.PoolSize", SetStreamingPoolSizeOnSetting)
    GameInstance:ExecuteCMD("r.Streaming.AdditionalPoolSize", 0)
  end
  Client.RefershAllManagedTickConfigWhenFPSChanged()
  local DevicePlatformNameMacros = require("client.slua.config.ClientMacros.DevicePlatformNameMacros")
  local platformName = Client.GetDevicePlatformName()
  if fpsLevel == 6 and platformName == DevicePlatformNameMacros.IOS then
    GameInstance:ExecuteCMD("Engine.GSleepSlackTimeThod", 0.0012)
    GameInstance:ExecuteCMD("Engine.GSleepTimeThod", 0.0012)
  end
  local OverrideJankCollectionTimeThresholdFromRemote = 0
  if 8 <= fpsLevel then
    OverrideJankCollectionTimeThresholdFromRemote = HDmpveRemote.HDmpveRemoteConfigGetInt("JankCollectionTimeThreshold_120FPS", 0)
  elseif 7 <= fpsLevel then
    OverrideJankCollectionTimeThresholdFromRemote = HDmpveRemote.HDmpveRemoteConfigGetInt("JankCollectionTimeThreshold_90FPS", 0)
  else
    OverrideJankCollectionTimeThresholdFromRemote = HDmpveRemote.HDmpveRemoteConfigGetInt("JankCollectionTimeThreshold", 0)
  end
  if 1 <= OverrideJankCollectionTimeThresholdFromRemote then
    GameInstance:ExecuteCMD("Jank.CollectionTimeThreshold", OverrideJankCollectionTimeThresholdFromRemote)
  else
    GameInstance:ExecuteCMD("Jank.CollectionTimeThreshold", ClientEVOConfig.DefaultJankCollectionTimeThresholdOnIni)
  end
  local JankSourceNumLimit = HDmpveRemote.HDmpveRemoteConfigGetInt("JankSourceNumLimit", 3)
  GameInstance:ExecuteCMD("Jank.SourceNumLimit", JankSourceNumLimit)
end

function ClientEVOConfig.ApplyGCIntervelFromMap(mapID)
  if not Client then
    return
  end
  local platformName = Client.GetDevicePlatformName()
  local DevicePlatformNameMacros = require("client.slua.config.ClientMacros.DevicePlatformNameMacros")
  local so_version = Client.GetAndroidSOVersion()
  if platformName ~= DevicePlatformNameMacros.Android or ClientEVOConfig.EnableGCSweepTimeModifiy_GCloud <= 0 or so_version == 32 then
    return
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  local TCDeviceLevel = Client.GetTCDeviceLevel()
  local MemorySize = Client.GetMemorySize()
  if mapID == 0 then
    if 5 <= MemorySize and 6 <= TCDeviceLevel and ClientEVOConfig.CloseGCWhitList[ClientEVOConfig.CurrentWorldName] then
      GameInstance:ExecuteCMD("gc.TimeBetweenPurgingPendingKillObjects", 900)
      log(bWriteLog and "[ClientEVOConfig] ApplyGCIntervelFromMap gc.TimeBetweenPurgingPendingKillObjects 900")
    end
  elseif mapID == 1 and 5 <= MemorySize and 7 <= TCDeviceLevel then
    GameInstance:ExecuteCMD("gc.TimeBetweenPurgingPendingKillObjects", 90)
    log(bWriteLog and "[ClientEVOConfig] ApplyGCIntervelFromMap gc.TimeBetweenPurgingPendingKillObjects 90")
  end
end

function ClientEVOConfig.IsCreativeMode()
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  if LogicUGC and (LogicUGC:IsUGCGameMod() or LogicUGC:IsUGCEditMod()) then
    return true
  end
  return false
end

function ClientEVOConfig.RevertGCIntervelFromMap(mapID)
  if not Client then
    return
  end
  log(bWriteLog and "[ClientEVOConfig] RevertGCIntervelFromMap mapid:" .. tostring(mapID))
  local platformName = Client.GetDevicePlatformName()
  local DevicePlatformNameMacros = require("client.slua.config.ClientMacros.DevicePlatformNameMacros")
  local so_version = Client.GetAndroidSOVersion()
  if platformName ~= DevicePlatformNameMacros.Android or ClientEVOConfig.EnableGCSweepTimeModifiy_GCloud <= 0 or so_version == 32 then
    return
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  local TCDeviceLevel = Client.GetTCDeviceLevel()
  local MemorySize = Client.GetMemorySize()
  if mapID == 0 then
    if 5 <= MemorySize and 6 <= TCDeviceLevel then
      GameInstance:ExecuteCMD("gc.TimeBetweenPurgingPendingKillObjects", 60)
      log(bWriteLog and "[ClientEVOConfig] RevertGCIntervelFromMap gc.TimeBetweenPurgingPendingKillObjects 60")
    end
  elseif mapID == 1 and 5 <= MemorySize and 7 <= TCDeviceLevel then
    GameInstance:ExecuteCMD("gc.TimeBetweenPurgingPendingKillObjects", 60)
    log(bWriteLog and "[ClientEVOConfig] RevertGCIntervelFromMap gc.TimeBetweenPurgingPendingKillObjects 60")
  end
end

return ClientEVOConfig
