local DevicePlatformNameMacros = require("client.slua.config.ClientMacros.DevicePlatformNameMacros")
local SECONDS_PER_DAY = 86400
local DEFAULT_EXPIRE_DAYS = 30
local DEFAULT_COUNT_DOWN = 5
local DEFAULT_TRIGGER_THIRD_CODE = -152
local LOGIN_RESULT_SERVER_ERROR = 211
local MSDK_CONFIG_DEFINE = {
  [DevicePlatformNameMacros.Android] = {
    {
      key = "IMSDK_FACEBOOK_LOGIN_USING_WEB",
      on = "true",
      off = "false"
    },
    {
      key = "IMSDK_FACEBOOK_USE_BROWSER_LOGIN",
      on = "true",
      off = "false"
    }
  },
  [DevicePlatformNameMacros.IOS] = {
    {
      key = "IMSDK_FACEBOOK_LOGIN_USING_WEB",
      on = "1",
      off = "0"
    },
    {
      key = "IMSDK_FACEBOOK_USE_SAFARI_LOGIN",
      on = "1",
      off = "0"
    }
  }
}
local LOC_ID = {
  Content = {
    [DevicePlatformNameMacros.IOS] = 75571,
    [DevicePlatformNameMacros.Android] = 75573
  },
  BtnOK = 75575,
  BtnOKCountDown = 75572,
  LinkText = 75574
}
local FALLBACK_TEXT = {
  Content = {
    [DevicePlatformNameMacros.IOS] = [[
Facebook login failed. Please log in again via the web. We apologize for any inconvenience. 
 {0}]],
    [DevicePlatformNameMacros.Android] = [[
Facebook login failed. Please log in again via the web after the game restarts. We apologize for any inconvenience. 
 {0}]],
    default = [[
Facebook login failed. Please log in again via the web. We apologize for any inconvenience. 
 {0}]]
  },
  BtnOK = "Continue in browser",
  BtnOKCountDown = "Continue in browser ({0}s)",
  LinkText = "Reason for authorization failure"
}
local CONTENT_LINK_DOMAIN_ID = 3366036
local CONTENT_LINK_STYLE = "AccountLink_Blue"
local ERROR_CODE_STYLE = "UGC_Gray"
local COUNT_DOWN_INTERVAL = 1
local COUNT_DOWN_WAIT_SHOW_MAX = 30
local logic_fb_web_login = {
  bLastAppliedWebLogin = nil,
  bCurLoginIsWeb = false,
  bForceWebOnce = false,
  confirmCountDown = nil
}

local function GetShowingMsgBox(content)
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  local msgBox = UIManager.GetUI(CommonMsgBoxMgr.GetCurrUIConfig())
  if msgBox and msgBox.msg == content then
    return msgBox
  end
  return nil
end

local function SetMsgBoxOKText(msgBox, text)
  if not msgBox or not msgBox.UIRoot then
    return
  end
  msgBox:SetText(msgBox.UIRoot.Text_OK or msgBox.UIRoot.Text_ok, text)
end

local function ResolveByPlatform(value)
  if type(value) ~= "table" then
    return value
  end
  local platformValue = value[Client.GetDevicePlatformName()]
  if platformValue == nil then
    platformValue = value.default
  end
  return platformValue
end

local function GetText(key)
  local id = ResolveByPlatform(LOC_ID[key])
  if id then
    local text = LocUtil.TryGetLocalizeResStr(id)
    if text and text ~= "" then
      return text
    end
  end
  return ResolveByPlatform(FALLBACK_TEXT[key])
end

local function GetPlayerPrefs()
  return require("client.logic.LogicPlayerPrefs.playerprefs")
end

local function GetNow()
  local TimeUtil = require("client.common.time_util")
  return TimeUtil.OSTime() or 0
end

function logic_fb_web_login:IsEnable()
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  local bDefault = PublishRegionMacros.IsGlobalOperationRegion()
  return HDmpveRemote.HDmpveRemoteConfigGetBool("FBWebLoginEnable", bDefault)
end

function logic_fb_web_login:GetExpireSeconds()
  local days = HDmpveRemote.HDmpveRemoteConfigGetInt("FBWebLoginRecordExpireDays", DEFAULT_EXPIRE_DAYS)
  days = tonumber(days) or DEFAULT_EXPIRE_DAYS
  return days * SECONDS_PER_DAY
end

function logic_fb_web_login:GetCountDown()
  local sec = HDmpveRemote.HDmpveRemoteConfigGetInt("FBWebLoginCountDown", DEFAULT_COUNT_DOWN)
  return tonumber(sec) or DEFAULT_COUNT_DOWN
end

function logic_fb_web_login:IsTriggerThirdCode(thirdCode)
  thirdCode = tonumber(thirdCode)
  if not thirdCode then
    return false
  end
  local strCodes = HDmpveRemote.HDmpveRemoteConfigGetString("FBWebLoginThirdCodes", "")
  if not strCodes or strCodes == "" or strCodes == "null" then
    return thirdCode == DEFAULT_TRIGGER_THIRD_CODE
  end
  local StringUtil = require("common.string_util")
  local splits = StringUtil.Split(strCodes, ",")
  for _, v in ipairs(splits) do
    if tonumber(v) == thirdCode then
      return true
    end
  end
  return false
end

function logic_fb_web_login:GetMSDKConfig(bEnableWeb)
  local platformName = Client.GetDevicePlatformName()
  local strRemote = HDmpveRemote.HDmpveRemoteConfigGetString("FBWebLoginMSDKConfig", "")
  if strRemote and strRemote ~= "" and strRemote ~= "null" then
    local ok, remoteTb = pcall(json.decode, strRemote)
    local platformTb = ok and type(remoteTb) == "table" and remoteTb[platformName] or nil
    local stateTb = type(platformTb) == "table" and platformTb[bEnableWeb and "on" or "off"] or nil
    if type(stateTb) == "table" and next(stateTb) then
      local config = {}
      for k, v in pairs(stateTb) do
        config[tostring(k)] = tostring(v)
      end
      return config
    end
    log_warning("logic_fb_web_login:GetMSDKConfig invalid FBWebLoginMSDKConfig: " .. tostring(strRemote))
  end
  local define = MSDK_CONFIG_DEFINE[platformName]
  if not define then
    return nil
  end
  local config = {}
  for _, item in ipairs(define) do
    config[item.key] = bEnableWeb and item.on or item.off
  end
  return config
end

function logic_fb_web_login:SaveRecord(thirdCode)
  local record = {
    time = GetNow(),
    thirdCode = thirdCode
  }
  log(bWriteLog and string.format("logic_fb_web_login:SaveRecord time=%s thirdCode=%s", tostring(record.time), tostring(thirdCode)))
  local PlayerPrefsSystem = GetPlayerPrefs()
  PlayerPrefsSystem.SaveTableToFile_N(record, PlayerPrefsSystem.ePlayerPrefsType.eFBWebLoginRecord)
end

function logic_fb_web_login:ClearRecord()
  local PlayerPrefsSystem = GetPlayerPrefs()
  PlayerPrefsSystem.SaveTableToFile_N({}, PlayerPrefsSystem.ePlayerPrefsType.eFBWebLoginRecord)
end

function logic_fb_web_login:IsRecordValid()
  local PlayerPrefsSystem = GetPlayerPrefs()
  local record = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eFBWebLoginRecord)
  if type(record) ~= "table" or not tonumber(record.time) then
    return false
  end
  local expireSeconds = self:GetExpireSeconds()
  if expireSeconds <= 0 then
    return false
  end
  local elapsed = GetNow() - tonumber(record.time)
  local bValid = 0 <= elapsed and expireSeconds > elapsed
  log(bWriteLog and string.format("logic_fb_web_login:IsRecordValid time=%s elapsed=%s expire=%s valid=%s", tostring(record.time), tostring(elapsed), tostring(expireSeconds), tostring(bValid)))
  if not bValid then
    self:ClearRecord()
  end
  return bValid
end

function logic_fb_web_login:ApplyWebLoginConfig(bEnableWeb)
  bEnableWeb = bEnableWeb and true or false
  if self.bLastAppliedWebLogin == bEnableWeb then
    return true
  end
  local config = self:GetMSDKConfig(bEnableWeb)
  if not config or not next(config) then
    log_warning("logic_fb_web_login:ApplyWebLoginConfig no config for platform: " .. tostring(Client.GetDevicePlatformName()))
    return false
  end
  local IMSDKHelper = import("IMSDKHelper")
  local IMSDKHelperInstance = IMSDKHelper and IMSDKHelper.GetInstance()
  if not IMSDKHelperInstance then
    log_warning("logic_fb_web_login:ApplyWebLoginConfig IMSDKHelper is nil")
    return false
  end
  log_tree("logic_fb_web_login:ApplyWebLoginConfig enableWeb=" .. tostring(bEnableWeb), config)
  IMSDKHelperInstance:SetMSDKConfig(config, false)
  self.bLastAppliedWebLogin = bEnableWeb
  return true
end

function logic_fb_web_login:BeforeIMSDKLogin(imsdkLoginChannelId)
  self.bCurLoginIsWeb = false
  local bForceWebOnce = self.bForceWebOnce
  self.bForceWebOnce = false
  if imsdkLoginChannelId ~= BP_ENUM_IMSDK_CHANNEL_FACEBOOK then
    return
  end
  if not self:IsEnable() then
    return
  end
  local bNeedWeb = bForceWebOnce or self:IsRecordValid()
  if self:ApplyWebLoginConfig(bNeedWeb) then
    self.bCurLoginIsWeb = bNeedWeb
  end
  log(bWriteLog and string.format("logic_fb_web_login:BeforeIMSDKLogin forceOnce=%s needWeb=%s bCurLoginIsWeb=%s", tostring(bForceWebOnce), tostring(bNeedWeb), tostring(self.bCurLoginIsWeb)))
end

local WEB_LOGIN_DELAY = 0.3

function logic_fb_web_login:StartWebLogin()
  log(bWriteLog and "logic_fb_web_login:StartWebLogin")
  if GameStatus.GetGameStatus() ~= GameStatus.Login then
    log_warning("logic_fb_web_login:StartWebLogin not in login status")
    return
  end
  if not self:ApplyWebLoginConfig(true) then
    log_warning("logic_fb_web_login:StartWebLogin apply web login config failed, abort")
    return
  end
  self.bForceWebOnce = true
  local bIsAndroid = Client.GetDevicePlatformName() == DevicePlatformNameMacros.Android
  local timer_ticker = require("common.time_ticker")
  timer_ticker.AddTimer(WEB_LOGIN_DELAY, function()
    if bIsAndroid then
      log(bWriteLog and "logic_fb_web_login:StartWebLogin Android, restart game to pick up new config")
      Client.RestartGame()
      return
    end
    if GameStatus.GetGameStatus() ~= GameStatus.Login then
      log_warning("logic_fb_web_login:StartWebLogin delayed callback not in login status")
      self.bForceWebOnce = false
      return
    end
    log(bWriteLog and "logic_fb_web_login:StartWebLogin delayed trigger SdkLogin")
    local login_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module)
    login_module:SdkLogin(BP_ENUM_PLAYFORM_BGBG)
  end)
end

function logic_fb_web_login:OpenCustomerService()
  local LogicCustomerService = require("client.slua.logic.CustomerService.LogicCustomerService")
  local sceneId = LogicCustomerService.E_EntranceType.FBWebLoginFail
  log(bWriteLog and "logic_fb_web_login:OpenCustomerService sceneId = " .. tostring(sceneId))
  LogicCustomerService.Open(sceneId)
end

function logic_fb_web_login:GetDisplayErrorCode(eventParam, eventParam2)
  local IMSDKHelper = import("IMSDKHelper")
  local sessionId = IMSDKHelper and IMSDKHelper:GetSessionId() or ""
  return string.format("[%s]-[%s]-%s", tostring(eventParam), tostring(eventParam2), tostring(sessionId))
end

function logic_fb_web_login:ShowWebLoginConfirm(eventParam, eventParam2)
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  local title = LocUtil.GetLocalizeResStr(101001)
  local errorCode = self:GetDisplayErrorCode(eventParam, eventParam2)
  errorCode = string.format("<%s>%s</>", ERROR_CODE_STYLE, errorCode)
  local content = LocUtil.GeneralFormat(GetText("Content"), errorCode)
  content = string.format([[
%s
<a id="HyperlinkDecorator" style="%s" url="%s">%s</>]], content, CONTENT_LINK_STYLE, FuncUtil.GetDomainByID(CONTENT_LINK_DOMAIN_ID), GetText("LinkText"))
  
  local function onOK()
    self:StopConfirmCountDown()
    self:StartWebLogin()
  end
  
  local btnOKNoCountDown = GetText("BtnOK")
  local btnOKCountDown = GetText("BtnOKCountDown")
  local countDown = math.floor(self:GetCountDown())
  local extraData = {
    showUIKey = "com_msg_box_5s",
    ContentHyperLinkHandler = function(MetaData, msgBox)
      self:OpenCustomerService()
      self:StopConfirmCountDown()
      SetMsgBoxOKText(msgBox, btnOKNoCountDown)
      return true
    end
  }
  local btnOK = 0 < countDown and LocUtil.GeneralFormat(btnOKCountDown, countDown) or btnOKNoCountDown
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_ONE, title, content, onOK, nil, btnOK, nil, extraData)
  if 0 < countDown then
    self:StartConfirmCountDown(content, countDown, btnOKCountDown, btnOKNoCountDown)
  end
end

function logic_fb_web_login:StartConfirmCountDown(content, countDown, btnOKCountDown, btnOKNoCountDown)
  self:StopConfirmCountDown()
  local cd = {
    remain = countDown,
    bShown = false,
    waitShowTime = 0
  }
  self.confirmCountDown = cd
  local timer_ticker = require("common.time_ticker")
  cd.timer = timer_ticker.AddTimerLoop(COUNT_DOWN_INTERVAL, function()
    if self.confirmCountDown ~= cd then
      return
    end
    local msgBox = GetShowingMsgBox(content)
    if not msgBox then
      cd.waitShowTime = cd.waitShowTime + COUNT_DOWN_INTERVAL
      if cd.bShown or cd.waitShowTime >= COUNT_DOWN_WAIT_SHOW_MAX then
        self:StopConfirmCountDown()
      end
      return
    end
    cd.bShown = true
    cd.remain = cd.remain - COUNT_DOWN_INTERVAL
    if cd.remain > 0 then
      SetMsgBoxOKText(msgBox, LocUtil.GeneralFormat(btnOKCountDown, cd.remain))
      return
    end
    log(bWriteLog and "logic_fb_web_login:StartConfirmCountDown count down finished, auto confirm")
    self:StopConfirmCountDown()
    SetMsgBoxOKText(msgBox, btnOKNoCountDown)
    msgBox:OnClickOK()
  end, -1, COUNT_DOWN_INTERVAL)
end

function logic_fb_web_login:StopConfirmCountDown()
  local cd = self.confirmCountDown
  self.confirmCountDown = nil
  if cd and cd.timer then
    require("common.time_ticker").RemoveTimer(cd.timer)
  end
end

function logic_fb_web_login:HandleLoginFail(eventParam, eventParam2)
  if eventParam ~= LOGIN_RESULT_SERVER_ERROR then
    return false
  end
  if not self:IsEnable() then
    return false
  end
  if not self:IsTriggerThirdCode(eventParam2) then
    return false
  end
  local login_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module)
  if not login_module or login_module.nLoginType ~= BP_ENUM_PLAYFORM_BGBG then
    return false
  end
  log(bWriteLog and string.format("logic_fb_web_login:HandleLoginFail eventParam=%s eventParam2=%s bCurLoginIsWeb=%s", tostring(eventParam), tostring(eventParam2), tostring(self.bCurLoginIsWeb)))
  self:SaveRecord(eventParam2)
  if self.bCurLoginIsWeb then
    return false
  end
  if GameStatus.GetGameStatus() ~= GameStatus.Login then
    return false
  end
  self:ShowWebLoginConfirm(eventParam, eventParam2)
  return true
end

return logic_fb_web_login
