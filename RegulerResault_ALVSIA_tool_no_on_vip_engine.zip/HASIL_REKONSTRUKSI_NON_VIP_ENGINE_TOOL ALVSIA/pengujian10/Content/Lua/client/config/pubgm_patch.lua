-- !!! DO NOT MODIFY THIS FILE. !!!
-- AUTO GENERATE BY pubgm_patch.py 2026-11-16 22:24:25
global_patch_make_time = "" ..
"Patch Version : 4.7.0.21773\n" ..
"Mode : TAPD\n" ..
"Branch : Release4.7.0\n" ..
"Git Engine : 85c8c9418653e0138b69c48c4eef0611996a4f12\n" ..
"Git Survive : ae80868ed5a9878a02d5e2eea09323191184f33d\n" ..
"Git Lua : 7db7c9193d9806164b3645c03ead860d98c9e6ab\n" ..
"SVN Xls : 1711140\n" ..
"P4 Content : 999296\n" ..
"BuildNo : #1\n" ..
"HostName : PUBGM-VPC68\n" ..
"Mfg. Date : 2026-11-16 22:24:25\n" ..
"Pipeline : #p-cc3b4324542f4168a9a0638d1266cb56\n"

global_patch_make_time_map = {
    ["Patch Version"] = "4.7.0.21773",
    ["Mode"] = "TAPD",
    ["Branch"] = "Release4.7.0",
    ["Git Engine"] = "85c8c9418653e0138b69c48c4eef0611996a4f12",
    ["Git Survive"] = "ae80868ed5a9878a02d5e2eea09323191184f33d",
    ["Git Lua"] = "7db7c9193d9806164b3645c03ead860d98c9e6ab",
    ["SVN Xls"] = "1711140",
    ["P4 Content"] = "999296",
    ["Pipeline"] =  "p-cc3b4324542f4168a9a0638d1266cb56",
    ["BuildNo"] =  "#1",
    ["HostName"] = "PUBGM-VPC68",
    ["Mfg. Date"] = "2026-11-16 22:24:25",
}

global_patch_tss = "5Jth62bqL2Mjmsev3CRgNw=="
