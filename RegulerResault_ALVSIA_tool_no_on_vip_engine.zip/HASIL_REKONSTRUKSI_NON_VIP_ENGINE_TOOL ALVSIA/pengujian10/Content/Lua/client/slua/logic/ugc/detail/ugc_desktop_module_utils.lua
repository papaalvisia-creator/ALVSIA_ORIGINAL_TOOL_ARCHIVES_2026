local UKismetSystemLibrary = import("KismetSystemLibrary")
local VersionUtil = require("client.common.version_util")
local ugc_desktop_module_utils = {
  modIDMap = {}
}
local WOW_DESKTOP_WIDGET_ADD_GUIDE_URL_FORMAT = "game://?module=100030?deeplink=igamesdk%%3A%%2F%%2Fmeemo%%2Fadd_widget_guide%%3F%%26type%%3D5%%26game_scene%%3D%s"
local WOW_DESKTOP_WIDGET_ADD_GUIDE_FIT_470_URL_FORMAT = "game://?module=100030?deeplink=igamesdk%%3A%%2F%%2Fmeemo%%2Fadd_widget_guide%%3F%%26type%%3D6%%26game_scene%%3D%s%%26needPerm%%3D1"
ugc_desktop_module_utils.EWoWDesktopWidgetGameScene = {
  MainPage = "WOWMainPage",
  Lobby = "WOWLobby"
}

function ugc_desktop_module_utils.GetModuleSubModuleConfig(modID)
  if modID and ugc_desktop_module_utils.modIDMap[modID] then
    printf(bWriteLog and "ugc_desktop_module_utils.GetModuleSubModuleConfig %s -> %s", tostring(modID), tostring(ugc_desktop_module_utils.modIDMap[modID]))
    modID = ugc_desktop_module_utils.modIDMap[modID]
  end
  return CDataTable.GetTableData("UGCDesktopModuleConfig", modID)
end

function ugc_desktop_module_utils.JumpToWoWDesktopWidgetAddGuide(gameScene)
  gameScene = gameScene or ugc_desktop_module_utils.EWoWDesktopWidgetGameScene.Lobby
  local urlFormat = WOW_DESKTOP_WIDGET_ADD_GUIDE_URL_FORMAT
  if UKismetSystemLibrary.GetGameBundleId() == "com.tencent.igfit" and VersionUtil.IsClientVersionEqual("4.7.0", 3) then
    urlFormat = WOW_DESKTOP_WIDGET_ADD_GUIDE_FIT_470_URL_FORMAT
  end
  GlobalData.JumpUrl(string.format(urlFormat, gameScene))
end

return ugc_desktop_module_utils
