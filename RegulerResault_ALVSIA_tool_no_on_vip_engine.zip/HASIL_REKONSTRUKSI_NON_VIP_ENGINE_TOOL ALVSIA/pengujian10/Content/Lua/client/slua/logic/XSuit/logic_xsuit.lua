local LogicXSuit = {
  baseInfo = {},
  upgradeInfo = {},
  workshopTabData = nil,
  unlockFeatureInfo = nil,
  switchLevel = nil,
  stateInfo = nil,
  levelAction = nil,
  FeatureSwitch = {},
  EliminationKingClothOverrideEnabled = nil,
  _FetchingEliminationKingOverride = false,
  _PendingElimOverrideRecheckOnLevel6 = false,
  condtion = {},
  gridExchangeData = {},
  itemInfoList = {},
  needShowRelicID = 0,
  needShowRelicUid = 0,
  relicInfoList = {},
  inviteActionMap = nil,
  actionPeriodMap = {},
  lastSendInviteTime = 0,
  openUpgrade = false,
  playerEquipItemID = 0,
  shareTimeList = {},
  stimulusCollectionQueue = {},
  stimulusCollectionShowing = false,
  stimulusCollectionShown = {},
  stimulusCollectionRetryHandle = nil,
  stimulusRecheckPeriods = {},
  currencyIconPath = nil,
  materialItemIDMap = {},
  unlockStateMatMap = {},
  needPlayActionMember = {},
  playedActionUidMap = {},
  bVersionInit = false,
  equip_data = {},
  activeBranchInfo = {},
  reddotData = {},
  MaterialCommon2Active = nil,
  XSuitWardrobeBranchData = {},
  UpgradeDiscount = {},
  collectInfo = {},
  task_conf_info = {},
  task_status_info = {},
  task_info = {
    week_id = 1,
    season_id = 1,
    week_info = {
      [1] = {start_time = 0, end_time = 0}
    },
    season_info = {
      [1] = {start_time = 0, end_time = 0}
    }
  }
}
local PufferConst = require("client.slua.logic.download.puffer_const")
local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
local LogicXSuitConfig = require("client.slua.logic.XSuit.logic_xsuit_config")
local xsuit_config_and_cache = require("client.slua.logic.XSuit.xsuit_config_and_cache")
local XSuitHandler = require("client.network.Protocol.XSuitHandler")
local ui_show_queue_config = require("client.common.uibase.ui_show_queue_config")
local maxFeatureCount = 5
local GiftTipSortWeightOffset = {Tarot = -0.2, SmallRP = -0.1}

function LogicXSuit.GetConfig(key)
  if key then
    return LogicXSuitConfig[key]
  end
end

function LogicXSuit.OnLogin(bReLogin)
  if not bReLogin or LogicXSuit.openUpgrade == false then
    LogicXSuit.openUpgrade = LobbySystem.CheckLobbyMenuOpen(BP_ENUM_LOBBY_MENU_XSUIT_WORK_SHOP, false)
    log(bWriteLog and "LogicXSuit.openUpgrade = " .. tostring(LogicXSuit.openUpgrade))
    XSuitHandler.send_get_rise_star_info_req()
    XSuitHandler.send_get_gold_dress_new_level_req()
    LogicXSuit.stateInfo = nil
    LogicXSuit.SendGetGoldDressStateReq()
    XSuitHandler.send_gold_dress_get_branch_switch_info_req()
    XSuitHandler.send_gold_dress_branch_personal_info_req()
    LogicXSuit.InitRedotData()
  end
end

function LogicXSuit.OnModePreSwitch(_, currentStatus)
  if not GameStatus.IsInLobbyOrMainCity() then
    LogicXSuit.needPlayActionMember = {}
  end
end

function LogicXSuit.InitWorkshopTabData()
  LogicXSuit.workshopTabData = {}
  local config = xsuit_config_and_cache.GetVersionArgConfig()
  local version = config.MAX_PERIOD or 1
  for i = 1, version do
    local info, bBranch, BranchId = LogicXSuit.GetBaseInfo(i)
    if not info then
      break
    end
    local uiCfg = LogicXSuit.GetUpgradeUIInfo(i)
    local scrollInfo = {
      period = i,
      imagePath = uiCfg and uiCfg.ItemImagePath
    }
    if bBranch and not BranchId then
      scrollInfo.branchList = {}
      for index = 0, #info do
        uiCfg = LogicXSuit.GetBranchUIInfo(i, index)
        local commonCfg = LogicXSuit.GetUpgradeUIInfoByBranchId(i, index)
        local _ = uiCfg and commonCfg and table.insert(scrollInfo.branchList, {
          period = i,
          imagePath = uiCfg.ItemImagePath,
          Branch = uiCfg.BranchId,
          BranchName = commonCfg.BranchName,
          subImagePath = commonCfg.BranchIconImage,
          subImagePath = commonCfg.BranchIconImage,
          branchCountIcon = commonCfg.BranchCountIcon,
          branchCountDesc = commonCfg.BranchCountDesc
        })
      end
    end
    table.insert(LogicXSuit.workshopTabData, scrollInfo)
  end
  table.sort(LogicXSuit.workshopTabData, function(a, b)
    return a.period > b.period
  end)
end

function LogicXSuit.InitXSuitBaseInfo(period)
  if LogicXSuit.baseInfo[period] then
    return
  end
  local cfg = CDataTable.GetTableByFilter("GoldenSuitUpgradeCfg", "Period", period)
  for _, j in pairs(cfg) do
    LogicXSuit._InitOneBaseInfo(j)
    LogicXSuit._InitOneUpgradeInfo(j)
  end
end

function LogicXSuit._InitOneUpgradeInfo(data)
  if LogicXSuit.upgradeInfo[data.Period] == nil then
    LogicXSuit.upgradeInfo[data.Period] = {}
  end
  if LogicXSuit.upgradeInfo[data.Period][data.BranchId] == nil then
    LogicXSuit.upgradeInfo[data.Period][data.BranchId] = {}
  end
  LogicXSuit.materialItemIDMap[data.MatID1] = true
  LogicXSuit.materialItemIDMap[data.MatID2] = true
  if data.SecondMatID > 0 and not LogicXSuit.unlockStateMatMap[data.SecondMatID] then
    LogicXSuit.unlockStateMatMap[data.SecondMatID] = data.Period
  end
  if 0 < data.ActiveID2 and not LogicXSuit.unlockStateMatMap[data.ActiveID2] then
    LogicXSuit.unlockStateMatMap[data.ActiveID2] = data.Period
  end
  if 0 < data.ActiveID1 and not LogicXSuit.unlockStateMatMap[data.ActiveID1] then
    LogicXSuit.unlockStateMatMap[data.ActiveID1] = data.Period
  end
  if 0 < data.BackID2 and not LogicXSuit.unlockStateMatMap[data.BackID2] then
    LogicXSuit.unlockStateMatMap[data.BackID2] = data.Period
  end
  if 0 < data.BackID1 and not LogicXSuit.unlockStateMatMap[data.BackID1] then
    LogicXSuit.unlockStateMatMap[data.BackID1] = data.Period
  end
  local info = {
    cfg = data,
    item_id = data.ItemID,
    tab_name_array = {
      data.SubTabID1,
      data.SubTabID2,
      data.SubTabID3,
      data.SubTabID4,
      data.SubTabID5
    },
    tab_desc_array = {
      data.TabDesc1,
      data.TabDesc2,
      data.TabDesc3,
      data.TabDesc4,
      data.TabDesc5
    },
    effect_id_array = {
      data.Effect1,
      data.Effect2,
      data.Effect3,
      data.Effect4,
      data.Effect5
    }
  }
  info.featureList = {}
  for i = 1, 5 do
    local featureId = data["SubTabID" .. i]
    if featureId and 0 < featureId then
      table.insert(info.featureList, {
        tabId = data["SubTabID" .. i],
        desc = data["TabDesc" .. i],
        effectId = data["Effect" .. i]
      })
    end
  end
  LogicXSuit.upgradeInfo[data.Period][data.BranchId][data.Star] = info
end

function LogicXSuit._InitOneBaseInfo(data)
  if LogicXSuit.baseInfo[data.Period] == nil then
    LogicXSuit.baseInfo[data.Period] = {}
  end
  if LogicXSuit.baseInfo[data.Period][data.BranchId] == nil then
    LogicXSuit.baseInfo[data.Period][data.BranchId] = {}
  end
  local info = LogicXSuit.baseInfo[data.Period][data.BranchId]
  if data.RelicID ~= 0 and data.RelicID ~= "" then
    info.relic_id = data.RelicID
  end
  if data.Star == 1 then
    info.item_id = data.ItemID
  end
  if info.max_level == nil or data.Star > info.max_level then
    info.max_level = data.Star
    info.max_item_id = data.ItemID
  end
  if data.ActID ~= 0 then
    info.act_id = data.ActID
  end
end

function LogicXSuit.InitXSuitItemList(itemId)
  if not next(LogicXSuit.itemInfoList) then
    local GoldenSuitUpgradeCfg = CDataTable.GetTable("GoldenSuitUpgradeCfg")
    for _, data in pairs(GoldenSuitUpgradeCfg) do
      LogicXSuit.itemInfoList[data.ItemID] = {
        period = data.Period,
        level = data.Star,
        BranchId = data.BranchId
      }
    end
  end
end

function LogicXSuit.InitRedotData()
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local redPointData = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eGoldenSuitLotteryRedPoint)
  log_tree(bWriteLog and "LogicXSuit.InitRedotData redPointData = ", redPointData)
  local config = xsuit_config_and_cache.GetVersionArgConfig()
  local maxPeriod = config.MAX_PERIOD or 16
  LogicXSuit.reddotData = {version = maxPeriod}
  if redPointData then
    if not redPointData.version or 16 > redPointData.version then
      redPointData.version = nil
      local branchId = 0
      for period, reddot in pairs(redPointData) do
        LogicXSuit.reddotData[period] = {
          [branchId] = {
            version = reddot.version
          },
          version = reddot.version
        }
        reddot.version = nil
        for key, value in pairs(reddot) do
          LogicXSuit.reddotData[period][branchId][key] = value
        end
      end
      LogicXSuit.SetReddotCache()
    else
      LogicXSuit.reddotData = redPointData
    end
  end
  log_tree(bWriteLog and "LogicXSuit.InitRedotData LogicXSuit.reddotData = ", LogicXSuit.reddotData)
end

function LogicXSuit.InitInviteAction()
  LogicXSuit.inviteActionMap = {}
  local cfg = CDataTable.GetTable("GoldenSuitMapCfg")
  local StringUtil = require("common.string_util")
  for _, j in pairs(cfg) do
    local inviteeActionIDStrList = StringUtil.Split(j.InviteeActionID, "|")
    local inviteeActionIDList = {}
    for _, v in pairs(inviteeActionIDStrList) do
      local inviteeActionID = tonumber(v)
      if inviteeActionID then
        table.insert(inviteeActionIDList, inviteeActionID)
        LogicXSuit.actionPeriodMap[inviteeActionID] = {
          Period = j.Period,
          BranchId = j.BranchId
        }
      end
    end
    LogicXSuit.inviteActionMap[j.InviterActionID] = inviteeActionIDList
    LogicXSuit.actionPeriodMap[j.InviterActionID] = {
      Period = j.Period,
      BranchId = j.BranchId
    }
  end
end

function LogicXSuit.GetWorkshopTabData()
  if not LogicXSuit.workshopTabData then
    LogicXSuit.InitWorkshopTabData()
  end
  local TableUtil = require("common.table_util")
  local newInfo = TableUtil.FastCopyTable(LogicXSuit.workshopTabData)
  local maxPeriod = LogicXSuit.GetMaxPeriod()
  for i = #newInfo, 1, -1 do
    local info = newInfo[i]
    if maxPeriod < info.period then
      table.remove(newInfo, i)
    elseif info.branchList then
      for j = #info.branchList, 1, -1 do
        local branchInfo = info.branchList[j]
        if not LogicXSuit.IsBranchOpen(info.period, branchInfo.Branch) then
          table.remove(info.branchList, j)
        end
      end
    end
  end
  return newInfo
end

function LogicXSuit.GetMaxPeriod()
  for i = #LogicXSuit.shareTimeList, 1, -1 do
    if LogicXSuit.IsBranchOpen(i, 0) then
      return i
    end
  end
  return 0
end

function LogicXSuit.GetReddotCacheByPeriod(period)
  return LogicXSuit.reddotData[period] and LogicXSuit.reddotData[period].version
end

function LogicXSuit.GetReddotCacheByBranchId(period, branchId)
  return LogicXSuit.reddotData[period] and LogicXSuit.reddotData[period][branchId] and LogicXSuit.reddotData[period][branchId].version
end

function LogicXSuit.GetReddotCacheByLevel(period, branchId, level)
  return LogicXSuit.reddotData[period] and LogicXSuit.reddotData[period][branchId] and LogicXSuit.reddotData[period][branchId][level] and LogicXSuit.reddotData[period][branchId][level].version
end

function LogicXSuit.GetReddotCacheByFeature(period, branchId, level, index)
  return LogicXSuit.reddotData[period] and LogicXSuit.reddotData[period][branchId] and LogicXSuit.reddotData[period][branchId][level] and LogicXSuit.reddotData[period][branchId][level][index] and LogicXSuit.reddotData[period][branchId][level][index].version
end

function LogicXSuit.GetActiveBranchIdByPeriod(period)
  local info = LogicXSuit.activeBranchInfo and LogicXSuit.activeBranchInfo[period]
  if not info then
    return nil
  end
  return info.branch_id
end

function LogicXSuit.GetActiveBranchInfoByPeriod(period)
  return LogicXSuit.activeBranchInfo[period]
end

LogicXSuit.MAX_ACTIVE_BRANCH_RESET_TIMES = 2

function LogicXSuit.GetActiveBranchResetTimes(period)
  local info = LogicXSuit.activeBranchInfo and LogicXSuit.activeBranchInfo[period]
  return info and info.reset_times or 0
end

function LogicXSuit.CanResetActiveBranch(period)
  return LogicXSuit.GetActiveBranchResetTimes(period) < LogicXSuit.MAX_ACTIVE_BRANCH_RESET_TIMES
end

function LogicXSuit.IsOtherBranchLevelBelowOne(period, excludeBranchId)
  local allBranchInfo = LogicXSuit.GetBaseInfo(period) or {}
  for branchId, _ in pairs(allBranchInfo) do
    if branchId ~= excludeBranchId then
      local level = LogicXSuit.GetLevelByPeriodSelf(period, branchId) or 0
      if 1 < level then
        return false
      end
    end
  end
  return true
end

function LogicXSuit.HasOtherBranchLevelBelowOne(period, excludeBranchId)
  local allBranchInfo = LogicXSuit.GetBaseInfo(period) or {}
  for branchId, _ in pairs(allBranchInfo) do
    if branchId ~= excludeBranchId then
      local level = LogicXSuit.GetLevelByPeriodSelf(period, branchId) or 0
      if level <= 1 then
        return true
      end
    end
  end
  return false
end

function LogicXSuit.GetUnlockedBranchIdListByPeriod(period)
  local periodInfo = LogicXSuit.shareTimeList[period]
  if periodInfo then
    local branchIdList = {}
    for i = 0, #periodInfo do
      local branchInfo = periodInfo[i]
      if branchInfo and branchInfo.unlock_flag then
        table.insert(branchIdList, i)
      end
    end
    return branchIdList
  end
end

function LogicXSuit.GetUpgradeBranchIdAndLevelByPeriod(period)
  local branchIdList = LogicXSuit.GetUnlockedBranchIdListByPeriod(period)
  for _, id in ipairs(branchIdList or {}) do
    local level = LogicXSuit.GetLevelByPeriodSelf(period, id)
    local upgradeInfo = LogicXSuit.GetUpgradeInfo(period, true, id)
    if 0 < level and level < #upgradeInfo then
      return id, level
    end
  end
end

function LogicXSuit.GetSuitItemIDByPeriod(period, branchId)
  if period then
    local info = LogicXSuit.GetBaseInfo(period, true, branchId)
    if info then
      return info.item_id, info.max_item_id
    end
  end
end

function LogicXSuit.GetPeriodByItemId(itemID)
  LogicXSuit.InitXSuitItemList(itemID)
  if LogicXSuit.itemInfoList[itemID] then
    return LogicXSuit.itemInfoList[itemID].period
  end
  return nil
end

function LogicXSuit.GetBranchByItemId(itemID)
  LogicXSuit.InitXSuitItemList(itemID)
  if LogicXSuit.itemInfoList[itemID] then
    return LogicXSuit.itemInfoList[itemID].BranchId
  end
  return nil
end

function LogicXSuit.GetLevelByItemId(itemID)
  LogicXSuit.InitXSuitItemList(itemID)
  if LogicXSuit.itemInfoList[itemID] then
    return LogicXSuit.itemInfoList[itemID].level
  end
  return nil
end

function LogicXSuit.GetItemIDByLevel(period, level, branchId)
  local cfgList = LogicXSuit.GetUpgradeInfo(tonumber(period), true, branchId)
  if cfgList and cfgList[level] then
    return cfgList[level].item_id
  end
end

function LogicXSuit.GetItemIDByPeriodLevel(period, level, branchId)
  LogicXSuit.InitXSuitBaseInfo(period)
  local info = LogicXSuit.upgradeInfo[period]
  return info[branchId][level].item_id
end

function LogicXSuit.GetLevelByPeriod(period, source, branch_id)
  branch_id = branch_id or 0
  local info = LogicXSuit.GetUpgradeInfo(period, true, branch_id)
  if info then
    local level = 0
    for i, data in pairs(info) do
      local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
      if wardrobe_data:GetHallDepotItemDataByResIDAndSource(data.item_id, source) ~= nil then
        level = i
      end
    end
    return level
  else
    return 0
  end
end

function LogicXSuit.GetLevelByPeriodSelf(period, branch_id)
  branch_id = branch_id or 0
  local periodInfo = LogicXSuit.shareTimeList and LogicXSuit.shareTimeList[period]
  local branchInfo = periodInfo and periodInfo[branch_id]
  return branchInfo and branchInfo.unlock_flag and branchInfo.current or 0
end

function LogicXSuit.GetItemIDByPeriod(period, source, branch_id)
  branch_id = branch_id or 0
  if not source then
    return LogicXSuit.GetItemIDByPeriodSelf(period, branch_id)
  end
  local level = LogicXSuit.GetLevelByPeriod(period, source, branch_id)
  if level then
    local upgradeInfo = LogicXSuit.GetUpgradeInfo(period, true, branch_id)
    local levelInfo = upgradeInfo and upgradeInfo[level]
    if levelInfo then
      return levelInfo.item_id
    end
  end
  return nil
end

function LogicXSuit.GetItemIDByPeriodSelf(period, branch_id)
  branch_id = branch_id or 0
  local periodInfo = LogicXSuit.shareTimeList and LogicXSuit.shareTimeList[period]
  local branchInfo = periodInfo and periodInfo[branch_id]
  if branchInfo and branchInfo.unlock_flag and branchInfo.current then
    return LogicXSuit.GetItemIDByLevel(period, branchInfo.current, branch_id)
  end
end

function LogicXSuit.GetShareTime(itemId)
  local period = LogicXSuit.GetPeriodByItemId(itemId)
  if not period then
    return nil
  end
  local branchId = LogicXSuit.GetBranchByItemId(itemId)
  local level = LogicXSuit.GetLevelByItemId(itemId)
  local data = LogicXSuit.shareTimeList[period] and LogicXSuit.shareTimeList[period][branchId]
  if data.unlock_flag and data.level_time and data.level_time[level] then
    return data.level_time[level]
  end
end

function LogicXSuit.GetBaseInfo(period_id, bBranch, _BranchId)
  if not period_id then
    return nil
  end
  LogicXSuit.InitXSuitBaseInfo(period_id)
  if LogicXSuit.baseInfo then
    local info = LogicXSuit.baseInfo[period_id]
    if not info then
      return nil
    end
    local TableUtil = require("common.table_util")
    local newInfo = TableUtil.FastCopyTable(info)
    if #newInfo == 0 then
      bBranch = true
      _BranchId = 0
    end
    local maxPeriod = LogicXSuit.GetMaxPeriod()
    if maxPeriod == #LogicXSuit.shareTimeList then
      return bBranch and info[_BranchId] or info, 0 < #info, _BranchId
    end
    for BranchId, realInfo in pairs(newInfo) do
      for i = realInfo.max_level, 1, -1 do
        if LogicXSuit.CheckShowByLevel(period_id, i, BranchId) then
          realInfo.max_level = i
          realInfo.max_item_id = LogicXSuit.upgradeInfo[period_id][BranchId][i].item_id
          break
        end
      end
    end
    return bBranch and newInfo[_BranchId] or newInfo, 0 < #newInfo, _BranchId
  else
    return nil
  end
end

function LogicXSuit.GetUpgradeInfo(period_id, bBranch, _BranchId)
  LogicXSuit.InitXSuitBaseInfo(period_id)
  local info = LogicXSuit.upgradeInfo[period_id]
  if not info then
    return {}, false, 0
  end
  local TableUtil = require("common.table_util")
  local newInfo = TableUtil.FastCopyTable(info)
  if #newInfo == 0 then
    bBranch = true
    _BranchId = 0
  end
  local maxPeriod = LogicXSuit.GetMaxPeriod()
  if maxPeriod == #LogicXSuit.shareTimeList then
    return bBranch and _BranchId and info[_BranchId] or info, 0 < #info, _BranchId
  end
  for BranchId, realInfo in pairs(newInfo) do
    for index = #realInfo, 1, -1 do
      if not LogicXSuit.CheckShowByLevel(period_id, index, BranchId) then
        table.remove(realInfo, index)
      else
        for featureIndex = maxFeatureCount, 1 do
          if info["SubTabID" .. featureIndex] and not LogicXSuit.CheckShowByLevelAndFeature(period_id, index, featureIndex, BranchId) then
            table.remove(realInfo[index], featureIndex)
          end
        end
      end
    end
  end
  return bBranch and newInfo[_BranchId] or newInfo, 0 < #newInfo, _BranchId
end

function LogicXSuit.GetUpgradeUIInfo(period_id)
  local cfg = CDataTable.GetTableDataByFilter("GoldenSuitUpgradeUICfg", "Period", period_id, "IsBranch", 0)
  return cfg
end

function LogicXSuit.GetBranchUIInfo(period, branch)
  return CDataTable.GetTableDataByFilter("GoldenSuitUpgradeUICfg", "Period", period, "IsBranch", 1, "BranchId", branch)
end

function LogicXSuit.GetUpgradeUIInfoByBranchId(period_id, BranchId)
  local cfg = CDataTable.GetTableDataByFilter("XSuitCommonBranch", "Period", period_id, "IsBranch", 1, "BranchId", BranchId)
  return cfg
end

function LogicXSuit.GetCollectUIInfo(period_id)
  local cfg = CDataTable.GetTableDataByFilter("XSuitCommonBranch", "Period", period_id, "IsBranch", 0)
  return cfg
end

function LogicXSuit.GetSelectBranchUIBPPath(period)
  if not period then
    return nil
  end
  local cfg = CDataTable.GetTableDataByFilter("XSuitCommonBranch", "Period", period, "IsBranch", 0)
  if not (cfg and cfg.SuitRoulettUIBP) or cfg.SuitRoulettUIBP == "" then
    local cfgs = CDataTable.GetTableByFilter("XSuitCommonBranch", "Period", period)
    for _, v in pairs(cfgs or {}) do
      if v.SuitRoulettUIBP and v.SuitRoulettUIBP ~= "" then
        cfg = v
        break
      end
    end
  end
  local bpPath = cfg and cfg.SuitRoulettUIBP
  if bpPath and bpPath ~= "" then
    return bpPath
  end
  return nil
end

function LogicXSuit.ShowSelectBranchUI(period, cancelCallback)
  local bpPath = LogicXSuit.GetSelectBranchUIBPPath(period)
  if bpPath then
    log(bWriteLog and string.format("LogicXSuit.ShowSelectBranchUI period:%s, bpPath:%s", tostring(period), tostring(bpPath)))
    UIManager.ShowUIWithBpPath(UIManager.UI_Config.XSuit_Select_Branch_UIBP, bpPath, period, cancelCallback)
  else
    log(bWriteLog and string.format("LogicXSuit.ShowSelectBranchUI no SuitRoulettUIBP, period:%s", tostring(period)))
    UIManager.ShowUI(UIManager.UI_Config.XSuit_Select_Branch_UIBP, period, cancelCallback)
  end
end

function LogicXSuit.ShowActiveBranchUpgradeConfirm(okCallback)
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_TWO, LocUtil.LocalizeResFormat(5077), LocUtil.GetLocalizeResStr(18141435), okCallback)
end

function LogicXSuit.GetShowRelicID(itemID)
  local level = LogicXSuit.GetLevelByItemId(itemID)
  if not level or level < 2 then
    return nil
  end
  local period = LogicXSuit.GetPeriodByItemId(itemID)
  if period then
    local branchId = LogicXSuit.GetBranchByItemId(itemID)
    local baseInfo = LogicXSuit.GetBaseInfo(period, true, branchId)
    if baseInfo then
      return baseInfo.relic_id
    end
  end
  return nil
end

function LogicXSuit.GetEnterActionByPeriod(period, state, branchId)
  branchId = branchId or 0
  local config = LogicXSuit.GetBranchMapData(period, branchId)
  if not config then
    return nil
  end
  local enterActionID
  if config.EnterActionID and config.EnterActionID ~= 0 then
    enterActionID = config.EnterActionID
  end
  local multi_state_manager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.multi_state_manager)
  enterActionID = multi_state_manager:ChangeEmoteByState(enterActionID, state)
  return enterActionID
end

function LogicXSuit.IsBattleEmotion(action_id)
  log(bWriteLog and "LogicXSuit.IsBattleEmotion " .. tostring(action_id))
  local config = CDataTable.GetTableDataByFilter("GoldenSuitMapCfg", "BattleActionID", action_id)
  return config and true or false, config and config.Period
end

function LogicXSuit.GetItemIDListByPeriod(period, branchId)
  branchId = branchId or 0
  local itemList = {}
  local multi_state_manager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.multi_state_manager)
  local datas = LogicXSuit.GetUpgradeInfo(period, true, branchId)
  for level, itemData in pairs(datas) do
    if type(itemData) == "table" and itemData.item_id then
      table.insert(itemList, itemData.item_id)
      local changeStateAction = multi_state_manager:GetStateChangeAction(itemData.item_id)
      if changeStateAction then
        for beforeCloth, action in pairs(changeStateAction) do
          table.insert(itemList, beforeCloth)
          table.insert(itemList, action)
        end
      end
    end
  end
  local config = LogicXSuit.GetBranchMapData(period, branchId)
  if config and config.BattleActionID and config.BattleActionID ~= 0 then
    table.insert(itemList, config.BattleActionID)
  end
  for _, itemData in pairs(datas) do
    if type(itemData) == "table" and itemData.item_id then
      local emoteConfig = CDataTable.GetTableDataByFilter("BornIslandShowEmoteCfg", "ItemID", itemData.item_id)
      if emoteConfig then
        if emoteConfig.EmotionID and emoteConfig.EmotionID ~= 0 then
          table.insert(itemList, emoteConfig.EmotionID)
        end
        if emoteConfig.PrepareEmotionID and emoteConfig.PrepareEmotionID ~= 0 then
          table.insert(itemList, emoteConfig.PrepareEmotionID)
        end
        break
      end
    end
  end
  return itemList
end

function LogicXSuit.GetActSuitMaxLevelByPeriod(period, branch_id)
  if not period then
    return nil
  end
  local info = LogicXSuit.GetUpgradeInfo(period, true, branch_id)
  return info and #info or 0
end

function LogicXSuit.BuildMaterialInfo(period, branchId, nextLevel, featureIndex, state, bGlide, bParachute)
  LogicXSuit.InitXSuitBaseInfo(period)
  local materialList, makeUpList, exchangeList = {}, {}, {}
  local bUpgrade, bNeedMakeUp, bCanMakeUp, needCurrency, bActive = true, false, true, 0, false
  if period and branchId and nextLevel and featureIndex then
    local list = LogicXSuit.GetUnlockFeatureMaterial(period, branchId, nextLevel, featureIndex)
    for index, material in pairs(list) do
      local _bUpgrade, _bNeedMakeUp, _bCanMakeUp, _needCurrency = LogicXSuit.AddMaterial(materialList, makeUpList, exchangeList, material.resid, material.count, material.timing_resid, nil, nil, nil, period, branchId)
      bUpgrade = _bUpgrade and bUpgrade
      bNeedMakeUp = _bNeedMakeUp or bNeedMakeUp
      bCanMakeUp = _bCanMakeUp and bCanMakeUp
      needCurrency = _needCurrency + needCurrency
    end
  elseif period and branchId and state then
    local multiCfg = xsuit_config_and_cache.GetMultiTypeUnlockConfigByPeriod(period)
    if not multiCfg then
      return {}
    end
    local unlockLevel = multiCfg.unlock_level
    local info = LogicXSuit.upgradeInfo[period][branchId][unlockLevel].cfg
    for i = 1, 2 do
      local comMatId = info["SecondMatID" .. i] or info.SecondMatID
      local needNum = info["SecondMatCount" .. i] or info.SecondMatCount
      local limitMatId = info["LimitMatID" .. i]
      if comMatId ~= info["MatID" .. i] then
        limitMatId = 0
      end
      if comMatId <= 0 then
        break
      end
      local _bUpgrade, _bNeedMakeUp, _bCanMakeUp, _needCurrency = LogicXSuit.AddMaterial(materialList, makeUpList, exchangeList, comMatId, needNum, limitMatId, nil, nil, nil, period, branchId)
      bUpgrade = _bUpgrade and bUpgrade
      bNeedMakeUp = _bNeedMakeUp or bNeedMakeUp
      bCanMakeUp = (_bUpgrade or _bCanMakeUp) and bCanMakeUp
      needCurrency = _needCurrency + needCurrency
    end
  elseif period and branchId and nextLevel and bGlide then
    local itemId = LogicXSuit.GetItemIDByLevel(period, nextLevel, branchId)
    local glideCfg = CDataTable.GetTableDataByFilter("XSuitGlideCfg", "XSuitID7", itemId)
    local upgradeInfo = LogicXSuit.upgradeInfo[period][branchId][2].cfg
    local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
    local judgeMaterialList = {}
    for slot = 1, 2 do
      local needNum = glideCfg["MatNum" .. slot] or 0
      if 0 < needNum then
        local backMatId = upgradeInfo["BackID" .. slot] or 0
        local backCount = 0 < backMatId and (wardrobe_data:GetHallDepotItemCountByResID(backMatId) or 0) or 0
        needNum = needNum - math.min(backCount, needNum)
        if 0 < needNum then
          local _bUpgrade, _bNeedMakeUp, _bCanMakeUp, _needCurrency = LogicXSuit.AddMaterial(judgeMaterialList, makeUpList, exchangeList, upgradeInfo["MatID" .. slot], needNum, upgradeInfo["LimitMatID" .. slot], nil, nil, nil, period, branchId)
          bUpgrade = _bUpgrade and bUpgrade
          bNeedMakeUp = _bNeedMakeUp or bNeedMakeUp
          bCanMakeUp = (_bUpgrade or _bCanMakeUp) and bCanMakeUp
          needCurrency = _needCurrency + needCurrency
        end
      end
    end
    materialList = LogicXSuit.BuildGlideMaterialList(upgradeInfo, glideCfg)
  elseif period and branchId and bParachute then
    local itemId = LogicXSuit.GetItemIDByLevel(period, 1, branchId)
    local parachuteCfg = CDataTable.GetTableData("XSuitParachuteCfg", itemId)
    if not parachuteCfg then
      return {}
    end
    local upgradeInfo = LogicXSuit.upgradeInfo[period][branchId][2].cfg
    local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
    local judgeMaterialList = {}
    for slot = 1, 2 do
      local needNum = parachuteCfg["MatNum" .. slot] or 0
      if 0 < needNum and parachuteCfg["MatID" .. slot] then
        local backMatId = upgradeInfo["BackID" .. slot] or 0
        local backCount = 0 < backMatId and (wardrobe_data:GetHallDepotItemCountByResID(backMatId) or 0) or 0
        needNum = needNum - math.min(backCount, needNum)
        if 0 < needNum then
          local _bUpgrade, _bNeedMakeUp, _bCanMakeUp, _needCurrency = LogicXSuit.AddMaterial(judgeMaterialList, makeUpList, exchangeList, parachuteCfg["MatID" .. slot], needNum, upgradeInfo["LimitMatID" .. slot], nil, nil, nil, period, branchId)
          bUpgrade = _bUpgrade and bUpgrade
          bNeedMakeUp = _bNeedMakeUp or bNeedMakeUp
          bCanMakeUp = (_bUpgrade or _bCanMakeUp) and bCanMakeUp
          needCurrency = _needCurrency + needCurrency
        end
      end
    end
    materialList = LogicXSuit.BuildParachuteMaterialList(upgradeInfo, parachuteCfg)
  elseif period and branchId and nextLevel then
    local levelInfo = LogicXSuit.upgradeInfo[period] and LogicXSuit.upgradeInfo[period][branchId] and LogicXSuit.upgradeInfo[period][branchId][nextLevel]
    if not levelInfo then
      return {}
    end
    local info = levelInfo.cfg
    local activeBranch = LogicXSuit.GetActiveBranchIdByPeriod(period)
    local discountData, bOpenActive = LogicXSuit.GetDiscountBranchAndDiscount(period)
    for i = 1, 2 do
      local comMatId = info["MatID" .. i]
      local needNum = info["MatNum" .. i]
      local limitMatId = info["LimitMatID" .. i]
      local activeId = activeBranch == branchId and info["ActiveID" .. i] or 0
      local activeNum = activeBranch == branchId and info["ActiveNum" .. i] or 0
      local backId = info["BackID" .. i]
      local exclusiveId = activeBranch == branchId and info["ExclusiveID" .. i] or 0
      local discountNum = 0
      if bOpenActive then
        for index, data in pairs(discountData) do
          if data.branchId == branchId and data.level == nextLevel - 1 then
            discountNum = i == 1 and data.main_discount or data.assistant_discount
            break
          end
        end
      end
      local _bUpgrade, _bNeedMakeUp, _bCanMakeUp, _needCurrency = LogicXSuit.AddMaterial(materialList, makeUpList, exchangeList, comMatId, needNum, limitMatId, activeId, activeNum, backId, period, branchId, discountNum, exclusiveId)
      bUpgrade = _bUpgrade and bUpgrade
      bNeedMakeUp = _bNeedMakeUp or bNeedMakeUp
      bCanMakeUp = (_bUpgrade or _bCanMakeUp) and bCanMakeUp
      needCurrency = _needCurrency + needCurrency
      bActive = activeId and 0 < activeId
    end
  else
    return {}
  end
  if 0 < needCurrency then
    local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
    local currencyCount = logic_xsuit_activity:GetDrawCurrencyCount()
    if currencyCount and needCurrency > currencyCount then
      bCanMakeUp = false
      bUpgrade = false
    end
  end
  return {
    bUpgrade = bUpgrade,
    bNeedMakeUp = bNeedMakeUp,
    bCanMakeUp = bCanMakeUp,
    materialList = materialList,
    makeUpList = makeUpList,
    exchangeList = exchangeList,
    needCurrency = needCurrency,
    bActive = bActive
  }
end

function LogicXSuit.BuildGlideMaterialList(upgradeInfo, glideCfg)
  local materialList = {}
  if not upgradeInfo or not glideCfg then
    return materialList
  end
  local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
  local remainNums = {}
  for slot = 1, 2 do
    remainNums[slot] = glideCfg["MatNum" .. slot] or 0
  end
  for slot = 1, 2 do
    local remainNum = remainNums[slot]
    local limitMatId = upgradeInfo["LimitMatID" .. slot] or 0
    local limitCount = 0 < remainNum and 0 < limitMatId and (wardrobe_data:GetHallDepotItemCountByResID(limitMatId, true) or 0) or 0
    if 0 < limitCount then
      local useCount = math.min(limitCount, remainNum)
      table.insert(materialList, {
        resID = limitMatId,
        count = limitCount,
        needCount = useCount,
        slot = slot,
        SourceJumpList = LogicXSuit.GetJumpInfoByItemID(limitMatId)
      })
      remainNums[slot] = remainNum - useCount
    end
  end
  for slot = 1, 2 do
    local remainNum = remainNums[slot]
    local backMatId = upgradeInfo["BackID" .. slot] or 0
    local backCount = 0 < remainNum and 0 < backMatId and (wardrobe_data:GetHallDepotItemCountByResID(backMatId) or 0) or 0
    if 0 < backCount then
      local useCount = math.min(backCount, remainNum)
      table.insert(materialList, {
        resID = backMatId,
        count = backCount,
        needCount = useCount,
        slot = slot,
        SourceJumpList = LogicXSuit.GetJumpInfoByItemID(backMatId)
      })
      remainNums[slot] = remainNum - useCount
    end
  end
  for slot = 1, 2 do
    local remainNum = remainNums[slot]
    local matId = upgradeInfo["MatID" .. slot] or 0
    if 0 < remainNum and 0 < matId then
      local matCount = wardrobe_data:GetHallDepotItemCountByResID(matId) or 0
      table.insert(materialList, {
        resID = matId,
        count = matCount,
        needCount = remainNum,
        slot = slot,
        SourceJumpList = LogicXSuit.GetJumpInfoByItemID(matId)
      })
    elseif 0 < remainNum then
      log_error(string.format("LogicXSuit.BuildGlideMaterialList no MatID%s, periodCfg missing", tostring(slot)))
    end
  end
  return materialList
end

function LogicXSuit.BuildParachuteMaterialList(upgradeInfo, parachuteCfg)
  local materialList = {}
  if not upgradeInfo or not parachuteCfg then
    return materialList
  end
  local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
  local remainNums = {}
  for slot = 1, 2 do
    remainNums[slot] = parachuteCfg["MatNum" .. slot] or 0
  end
  for slot = 1, 2 do
    local remainNum = remainNums[slot]
    local limitMatId = upgradeInfo["LimitMatID" .. slot] or 0
    local limitCount = 0 < remainNum and 0 < limitMatId and (wardrobe_data:GetHallDepotItemCountByResID(limitMatId, true) or 0) or 0
    if 0 < limitCount then
      local useCount = math.min(limitCount, remainNum)
      table.insert(materialList, {
        resID = limitMatId,
        count = limitCount,
        needCount = useCount,
        slot = slot,
        SourceJumpList = LogicXSuit.GetJumpInfoByItemID(limitMatId)
      })
      remainNums[slot] = remainNum - useCount
    end
  end
  for slot = 1, 2 do
    local remainNum = remainNums[slot]
    local backMatId = upgradeInfo["BackID" .. slot] or 0
    local backCount = 0 < remainNum and 0 < backMatId and (wardrobe_data:GetHallDepotItemCountByResID(backMatId) or 0) or 0
    if 0 < backCount then
      local useCount = math.min(backCount, remainNum)
      table.insert(materialList, {
        resID = backMatId,
        count = backCount,
        needCount = useCount,
        slot = slot,
        SourceJumpList = LogicXSuit.GetJumpInfoByItemID(backMatId)
      })
      remainNums[slot] = remainNum - useCount
    end
  end
  for slot = 1, 2 do
    local remainNum = remainNums[slot]
    local matId = parachuteCfg["MatID" .. slot] or 0
    if 0 < remainNum and 0 < matId then
      local matCount = wardrobe_data:GetHallDepotItemCountByResID(matId) or 0
      table.insert(materialList, {
        resID = matId,
        count = matCount,
        needCount = remainNum,
        slot = slot,
        SourceJumpList = LogicXSuit.GetJumpInfoByItemID(matId)
      })
    elseif 0 < remainNum then
      log_error(string.format("LogicXSuit.BuildParachuteMaterialList no MatID%s, parachuteCfg missing", tostring(slot)))
    end
  end
  return materialList
end

function LogicXSuit.CheckMaterialListEnough(materialList)
  if not materialList then
    return false
  end
  local slotInfo = {}
  for _, materia in ipairs(materialList) do
    if materia.slot then
      local info = slotInfo[materia.slot]
      if not info then
        info = {count = 0, needCount = 0}
        slotInfo[materia.slot] = info
      end
      info.count = info.count + (materia.count or 0)
      info.needCount = info.needCount + (materia.needCount or 0)
    elseif (materia.count or 0) < (materia.needCount or 0) then
      return false
    end
  end
  for _, info in pairs(slotInfo) do
    if info.count < info.needCount then
      return false
    end
  end
  return true
end

function LogicXSuit.AddMaterial(materialList, makeUpList, exchangeList, comMatId, needNum, limitMatId, activeId, activeNum, backId, period, branchId, discountNum, exclusiveId)
  local resId, needCount = activeId and 0 < activeId and activeId or comMatId, activeId and 0 < activeId and activeNum or needNum
  local haveCount = 0
  local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
  local wardrobeCount = wardrobe_data:GetHallDepotItemCountByResID(resId) or 0
  local originalNeedCount
  if discountNum and 0 < discountNum then
    originalNeedCount = needCount
    needCount = math.ceil(needCount * (100 - discountNum) / 100)
  end
  local bUpgrade, bNeedMakeUp, bCanMakeUp = false, false, false
  haveCount = haveCount + wardrobeCount
  local exclusiveCount = 0
  if activeId and 0 < activeId and exclusiveId and 0 < exclusiveId then
    exclusiveCount = wardrobe_data:GetHallDepotItemCountByResID(exclusiveId) or 0
    haveCount = haveCount + exclusiveCount
  end
  local sourceJumpList
  if activeId and 0 < activeId then
    sourceJumpList = {
      {
        text = LocUtil.GetLocalizeResStr(200000689),
        jumpFunction = function()
          LogicXSuit.OpenTrialTaskUI(period, branchId)
        end
      }
    }
  else
    sourceJumpList = LogicXSuit.GetJumpInfoByItemID(resId)
  end
  local materialInfo = {
    resID = resId,
    count = wardrobeCount + exclusiveCount,
    needCount = needCount,
    SourceJumpList = sourceJumpList,
    discount = originalNeedCount and discountNum
  }
  table.insert(materialList, materialInfo)
  if needCount <= haveCount then
    bUpgrade, bNeedMakeUp, bCanMakeUp = true, false, false
  end
  local common2ActiveNum = 1
  if activeId and 0 < activeId then
    common2ActiveNum = LogicXSuit.MaterialCommon2ActiveNum(comMatId)
  end
  local transformCount = 0
  local realExchangeCount = 0
  if activeId and 0 < activeId and resId ~= comMatId then
    wardrobeCount = wardrobe_data:GetHallDepotItemCountByResID(comMatId) or 0
    transformCount = wardrobeCount * common2ActiveNum
    realExchangeCount = math.ceil(needCount / common2ActiveNum) * common2ActiveNum
    if not bUpgrade and (not bNeedMakeUp or not bCanMakeUp) and needCount <= haveCount + transformCount and realExchangeCount <= haveCount + transformCount then
      table.insert(makeUpList, {
        resID = activeId,
        count = math.ceil((needCount - haveCount) / common2ActiveNum) * common2ActiveNum
      })
      bUpgrade, bNeedMakeUp, bCanMakeUp = true, true, true
    elseif not bUpgrade and (not bNeedMakeUp or not bCanMakeUp) then
      table.insert(makeUpList, {resID = activeId, count = transformCount})
    end
    haveCount = haveCount + transformCount
  end
  wardrobeCount = wardrobe_data:GetHallDepotItemCountByResID(limitMatId, true) or 0
  transformCount = wardrobeCount * common2ActiveNum
  if activeId and 0 < activeId then
    realExchangeCount = math.ceil(needCount / common2ActiveNum) * common2ActiveNum
    if not bUpgrade and (not bNeedMakeUp or not bCanMakeUp) and needCount <= haveCount + transformCount and realExchangeCount <= haveCount + transformCount then
      table.insert(makeUpList, {
        resID = activeId,
        count = math.ceil((needCount - haveCount) / common2ActiveNum) * common2ActiveNum
      })
      bUpgrade, bNeedMakeUp, bCanMakeUp = true, true, true
    elseif not bUpgrade and (not bNeedMakeUp or not bCanMakeUp) then
      table.insert(makeUpList, {resID = activeId, count = transformCount})
    end
    haveCount = haveCount + transformCount
  else
    materialInfo.count = materialInfo.count + wardrobeCount
    haveCount = haveCount + transformCount
    if needCount <= haveCount then
      bUpgrade, bNeedMakeUp, bCanMakeUp = true, false, false
    end
  end
  local upgradeInfo = LogicXSuit.upgradeInfo[period][branchId][2]
  local bHasBackCfg = upgradeInfo and upgradeInfo.cfg and 0 < (upgradeInfo.cfg.BackID1 or 0)
  if bHasBackCfg and backId and 0 < backId then
    wardrobeCount = wardrobe_data:GetHallDepotItemCountByResID(backId) or 0
    transformCount = wardrobeCount * common2ActiveNum
    if activeId and 0 < activeId then
      realExchangeCount = math.ceil(needCount / common2ActiveNum) * common2ActiveNum
      if not bUpgrade and (not bNeedMakeUp or not bCanMakeUp) and needCount <= haveCount + transformCount and realExchangeCount <= haveCount + transformCount then
        table.insert(makeUpList, {
          resID = activeId,
          count = math.ceil((needCount - haveCount) / common2ActiveNum) * common2ActiveNum
        })
        bUpgrade, bNeedMakeUp, bCanMakeUp = true, true, true
      elseif not bUpgrade and (not bNeedMakeUp or not bCanMakeUp) then
        table.insert(makeUpList, {resID = activeId, count = transformCount})
      end
      haveCount = haveCount + transformCount
    else
      materialInfo.count = materialInfo.count + wardrobeCount
      haveCount = haveCount + transformCount
      if needCount <= haveCount then
        bUpgrade, bNeedMakeUp, bCanMakeUp = true, false, false
      end
    end
  end
  if bUpgrade or bNeedMakeUp and bCanMakeUp then
    return bUpgrade, bNeedMakeUp, bCanMakeUp, 0
  end
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  local limitExchangeInfo = logic_xsuit_activity:GetExchangeDataByItemID(limitMatId)
  if not limitExchangeInfo then
    return false, true, false, 0
  end
  local currencyId = logic_xsuit_activity:GetDrawCurrencyID()
  local currencyCount = wardrobe_data:GetHallDepotItemCountByResID(currencyId, true) or 0
  needCount = needCount - haveCount
  local needCurrency = 0
  local discount = limitExchangeInfo.hasDiscount and limitExchangeInfo.drawDiscount
  if discount then
    local canExchangeCount = limitExchangeInfo.timeLimits - (limitExchangeInfo.hasExchangeCount or 0)
    transformCount = canExchangeCount * common2ActiveNum
    realExchangeCount = math.ceil(needCount / common2ActiveNum)
    if needCount <= transformCount then
      needCurrency = needCurrency + math.ceil(realExchangeCount * limitExchangeInfo.needItemNum * discount / 100)
      local _ = 0 < realExchangeCount and table.insert(exchangeList, {
        pos_id = limitExchangeInfo.pos,
        exchange_num = realExchangeCount
      })
      if currencyCount >= math.ceil(realExchangeCount * limitExchangeInfo.needItemNum * discount / 100) then
        return true, true, true, needCurrency
      else
        return false, true, false, needCurrency
      end
    else
      local _ = 0 < canExchangeCount and table.insert(exchangeList, {
        pos_id = limitExchangeInfo.pos,
        exchange_num = canExchangeCount
      })
      local price = math.ceil(canExchangeCount * limitExchangeInfo.needItemNum * discount / 100)
      currencyCount = currencyCount - price
      needCurrency = needCurrency + price
      needCount = needCount - transformCount
    end
  end
  local exchangeInfo = logic_xsuit_activity:GetExchangeDataByItemID(comMatId)
  if not exchangeInfo then
    return false, true, false, needCurrency
  end
  local canExchangeCount = exchangeInfo.timeLimits - (exchangeInfo.hasExchangeCount or 0)
  transformCount = canExchangeCount * common2ActiveNum
  realExchangeCount = math.ceil(needCount / common2ActiveNum)
  if transformCount then
    needCurrency = needCurrency + realExchangeCount * exchangeInfo.needItemNum
    local _ = 0 < realExchangeCount and table.insert(exchangeList, {
      pos_id = exchangeInfo.pos,
      exchange_num = realExchangeCount
    })
    if currencyCount >= realExchangeCount * exchangeInfo.needItemNum then
      return true, true, true, needCurrency
    else
      return false, true, false, needCurrency
    end
  else
    local _ = 0 < canExchangeCount and table.insert(exchangeList, {
      pos_id = limitExchangeInfo.pos,
      exchange_num = canExchangeCount
    })
    local price = canExchangeCount * limitExchangeInfo.needItemNum
    currencyCount = currencyCount - price
    needCurrency = needCurrency + price
    needCount = needCount - transformCount
  end
  return false, true, false, needCurrency
end

function LogicXSuit.GetJumpInfoByItemID(itemID)
  if not LogicXSuit.jumpList then
    LogicXSuit.jumpList = {}
  end
  if LogicXSuit.jumpList[itemID] then
    return LogicXSuit.jumpList[itemID]
  end
  local list = {}
  local ItemUpgradeMgr = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.ItemUpgradeModule)
  local itemJumpCfg = ItemUpgradeMgr:GetItemSourceJumpConfig(itemID)
  local jumpStr = itemJumpCfg and itemJumpCfg.JumpType or ""
  if jumpStr ~= "" then
    local JumpUtils = require("client.logic.store.jump_utils")
    local StringUtil = require("common.string_util")
    local jumpTypeList = StringUtil.Split(jumpStr, "|")
    for i, jType in ipairs(jumpTypeList) do
      local nJumpID = tonumber(jType)
      if nJumpID == JumpUtils.ENUM_JUMP_TYPE.Store and JumpUtils.FindJumpInfoAllByToModelId(itemID, JumpUtils.MODEL_ID_STORE) then
        table.insert(list, nJumpID)
      elseif nJumpID == JumpUtils.ENUM_JUMP_TYPE.Supply and JumpUtils.FindJumpInfoAllByToModelId(itemID, JumpUtils.MODEL_ID_SUPPLY) then
        table.insert(list, nJumpID)
      elseif nJumpID == JumpUtils.ENUM_JUMP_TYPE.JKStore and JumpUtils.FindJumpInfoAll(itemID) then
        table.insert(list, nJumpID)
      else
        local jumpCfg = CDataTable.GetTableData("JumpConfig", nJumpID)
        if jumpCfg and string.len(jumpCfg.JumpUrl) > 0 and LobbySystem.CheckUrlCanJump(jumpCfg.JumpUrl) then
          table.insert(list, nJumpID)
        end
      end
    end
  end
  LogicXSuit.jumpList[itemID] = list
  return list
end

function LogicXSuit.GetSuitMaterialJumpInfo(itemID)
  if not itemID then
    return nil
  end
  if not LogicXSuit.materialJumpInfoMap then
    local jumpInfoMap = {}
    
    local function GetOrCreate(id)
      local one = jumpInfoMap[id]
      if not one then
        one = {bGeneric = false, unlockList = nil}
        jumpInfoMap[id] = one
      end
      return one
    end
    
    local cfg = CDataTable.GetTable("GoldenSuitUpgradeCfg")
    for _, data in pairs(cfg or {}) do
      for _, field in ipairs({"MatID1", "MatID2"}) do
        local id = tonumber(data[field])
        if id and 0 < id then
          GetOrCreate(id).bGeneric = true
        end
      end
      for _, field in ipairs({
        "SecondMatID",
        "ActiveID2",
        "ActiveID1",
        "BackID2",
        "BackID1"
      }) do
        local id = tonumber(data[field])
        if id and 0 < id then
          local one = GetOrCreate(id)
          one.unlockList = one.unlockList or {}
          local bFound = false
          for _, exist in ipairs(one.unlockList) do
            if exist.period == data.Period and exist.branchId == data.BranchId then
              bFound = true
              break
            end
          end
          if not bFound then
            table.insert(one.unlockList, {
              period = data.Period,
              branchId = data.BranchId,
              star = data.Star
            })
          end
        end
      end
    end
    LogicXSuit.materialJumpInfoMap = jumpInfoMap
  end
  return LogicXSuit.materialJumpInfoMap[itemID]
end

function LogicXSuit.IsUnlockStateMaterial(itemID)
  if not itemID then
    return nil
  end
  if not LogicXSuit.unlockStateMatMap then
    return nil
  end
  return LogicXSuit.unlockStateMatMap[itemID]
end

function LogicXSuit.GetXSuitLocalizeResStr(id)
  local str = LocUtil.GetLocalizeResStr(id)
  if str then
    str = string.gsub(str, "%$%$", "\"")
  else
    str = ""
  end
  return str
end

function LogicXSuit.GetSwitchItemIDByItemID(itemID)
  local period = LogicXSuit.GetPeriodByItemId(itemID)
  local branchId = LogicXSuit.GetBranchByItemId(itemID)
  local switchLevel = LogicXSuit.GetSwitchLevelByPeriod(period, branchId)
  return LogicXSuit.GetSwitchItemByItemAndSwitchLevel(itemID, switchLevel)
end

function LogicXSuit.GetSwitchItemByItemAndSwitchLevel(itemID, switchLevel)
  log(bWriteLog and "LogicXSuit.GetSwitchItemByItemAndSwitchLevel, itemID = " .. tostring(itemID) .. "; switchLevel = " .. tostring(switchLevel))
  if LogicXSuit.IsXSuit(itemID) then
    local originalLevel = LogicXSuit.GetLevelByItemId(itemID)
    local period = LogicXSuit.GetPeriodByItemId(itemID)
    if switchLevel > originalLevel then
      log(bWriteLog and "LogicXSuit.GetSwitchItemByItemAndSwitchLevel: switchLevel > originalLevel")
      return itemID
    else
      local putOnLevel = originalLevel
      if switchLevel == 1 then
        if originalLevel == 1 then
          putOnLevel = 1
        else
          putOnLevel = 2
        end
      elseif switchLevel == 3 then
        if 5 <= originalLevel then
          putOnLevel = 5
        else
          putOnLevel = originalLevel
        end
      elseif switchLevel == 6 then
        putOnLevel = 6
      elseif switchLevel == 7 then
        putOnLevel = 7
      end
      log(bWriteLog and "LogicXSuit.GetSwitchItemByItemAndSwitchLevel: period = " .. tostring(period) .. "; putOnLevel = " .. tostring(putOnLevel))
      local branchId = LogicXSuit.GetBranchByItemId(itemID)
      return LogicXSuit.GetItemIDByLevel(period, putOnLevel, branchId)
    end
  else
    log(bWriteLog and "LogicXSuit.GetSwitchItemByItemAndSwitchLevel: not GoldenSuit")
    return itemID
  end
end

function LogicXSuit.GetItemShowID(InsID)
  local WardrobeData = require("client.slua.logic.wardrobe.wardrobe_data")
  local ShowItemID = WardrobeData:GetItemIDByInsID(InsID)
  local Source = WardrobeData:GetItemSource(InsID)
  if Source == EWardrobeDataSource.InheritWardrobe then
    ShowItemID = LogicXSuit.ChangeItemIDByMyselfState(ShowItemID, Source)
  else
    ShowItemID = LogicXSuit.GetSwitchItemIDByItemID(ShowItemID)
    ShowItemID = LogicXSuit.ChangeItemIDByMyselfState(ShowItemID, Source)
  end
  return ShowItemID
end

function LogicXSuit._GetSwitchLevelByItemID(itemID)
  local period = LogicXSuit.GetPeriodByItemId(itemID)
  if period then
    local branchId = LogicXSuit.GetBranchByItemId(itemID)
    return LogicXSuit.GetSwitchLevelByPeriod(period, branchId)
  end
  return nil
end

function LogicXSuit.GetSwitchLevelByInsID(InsID)
  local WardrobeData = require("client.slua.logic.wardrobe.wardrobe_data")
  local Source = WardrobeData:GetItemSource(InsID)
  local ItemID = WardrobeData:GetItemIDByInsID(InsID)
  if Source == EWardrobeDataSource.InheritWardrobe then
    return LogicXSuit.GetDefaultSwitchLevelByItemID(ItemID)
  else
    return LogicXSuit._GetSwitchLevelByItemID(ItemID)
  end
end

function LogicXSuit.GetDefaultSwitchLevelByItemID(itemID)
  local level = LogicXSuit.GetLevelByItemId(itemID)
  if level then
    local switchLevelList = LogicXSuit.GetConfig("switchLevelList")
    return switchLevelList[level]
  else
    return 0
  end
end

function LogicXSuit.GetSwitchLevelByPeriod(period, branch_id)
  local switchLevelList = LogicXSuit.GetConfig("switchLevelList")
  if not LogicXSuit.switchLevel then
    XSuitHandler.send_get_gold_dress_new_level_req()
    return switchLevelList[LogicXSuit.GetLevelByPeriodSelf(period, branch_id)]
  end
  local level = LogicXSuit.switchLevel[period] and LogicXSuit.switchLevel[period][branch_id]
  if level and 0 < level then
    return level
  else
    return switchLevelList[LogicXSuit.GetLevelByPeriodSelf(period, branch_id)]
  end
end

function LogicXSuit.GetPeriodOfCurrentlyWearing()
  local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
  local period, branchId
  local tRoleData = AvatarData.GetRoleWear()
  for _, v in pairs(tRoleData) do
    local itemInfo = wardrobe_data:GetHallDepotItemDataByInsID(v)
    if itemInfo and itemInfo.resID then
      period = LogicXSuit.GetPeriodByItemId(itemInfo.resID)
      branchId = LogicXSuit.GetBranchByItemId(itemInfo.resID)
      if period ~= nil then
        return period, itemInfo.resID, v, branchId
      end
    end
  end
  return nil, nil
end

function LogicXSuit.MaterialCommon2ActiveNum(itemId)
  if not LogicXSuit.MaterialCommon2Active then
    return 1
  end
  for _, v in pairs(LogicXSuit.MaterialCommon2Active) do
    if v.exchange_resid == itemId then
      return v.give_num
    end
  end
  return 1
end

function LogicXSuit.MaterialActive2CommonNum(itemId)
  if not LogicXSuit.MaterialCommon2Active then
    return itemId
  end
  return itemId, LogicXSuit.MaterialCommon2Active[itemId]
end

function LogicXSuit.GetNextBranchIdAndItemId(itemID)
  local period = LogicXSuit.GetPeriodByItemId(itemID)
  if not period then
    return
  end
  if not LogicXSuit.IsBranch(period) then
    return
  end
  local branchIdList = LogicXSuit.GetUnlockedBranchIdListByPeriod(period)
  if not branchIdList or #branchIdList <= 1 then
    return
  end
  local branchId = LogicXSuit.GetBranchByItemId(itemID)
  local nextBranchId
  for k, v in ipairs(branchIdList) do
    if v == branchId then
      local index = k + 1
      if index > #branchIdList then
        index = 1
      end
      nextBranchId = branchIdList[index]
      break
    end
  end
  return nextBranchId, LogicXSuit.GetItemIDByLevel(period, 1, nextBranchId), period, branchId
end

function LogicXSuit.GetWardrobeBranchByPeriod(period)
  return LogicXSuit.XSuitWardrobeBranchData[period] and LogicXSuit.XSuitWardrobeBranchData[period].branch_id
end

function LogicXSuit.GetWornXSuitPeriodAndBranch()
  local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
  local tRoleWear = AvatarData and AvatarData.GetRoleWear and AvatarData.GetRoleWear()
  for _, instId in pairs(tRoleWear or {}) do
    local data = wardrobe_data:GetHallDepotItemDataByInsID(instId)
    if data and data.resID and LogicXSuit.IsXSuit(data.resID) then
      local period = LogicXSuit.GetPeriodByItemId(data.resID)
      if period then
        return period, LogicXSuit.GetBranchByItemId(data.resID) or 0
      end
    end
  end
end

function LogicXSuit.GetSchemeIdByFeature(period, branchId, feature)
  return LogicXSuit.equip_data[period] and LogicXSuit.equip_data[period][branchId] and LogicXSuit.equip_data[period][branchId][feature]
end

function LogicXSuit.GetSchemeIdByBranch(period, branchId)
  return LogicXSuit.equip_data[period] and LogicXSuit.equip_data[period][branchId]
end

function LogicXSuit.GetDiscountBranchAndDiscount(period)
  local branchList = LogicXSuit.shareTimeList[period]
  if not (branchList and LogicXSuit.UpgradeDiscount) or not LogicXSuit.UpgradeDiscount[period] then
    return
  end
  local discountData = {}
  for branchId, v in pairs(branchList) do
    table.insert(discountData, {
      period = period,
      branchId = branchId,
      level = v.current or 0
    })
  end
  table.sort(discountData, function(a, b)
    if a.level == b.level then
      return a.branchId < b.branchId
    end
    return a.level > b.level
  end)
  for index, data in pairs(discountData) do
    local discount = LogicXSuit.UpgradeDiscount[period] and LogicXSuit.UpgradeDiscount[period][data.level]
    if discount then
      if index == 1 then
        data.main_discount = 0
        data.assistant_discount = 0
      elseif index == #discountData then
        if data.level == discountData[1].level then
          data.main_discount = 0
          data.assistant_discount = 0
        elseif data.level == discountData[2].level then
          data.main_discount = 100 - discount[1].main_discount
          data.assistant_discount = 100 - discount[1].assistant_discount
        else
          data.main_discount = 100 - discount[2].main_discount
          data.assistant_discount = 100 - discount[2].assistant_discount
        end
      elseif data.level == discountData[1].level then
        data.main_discount = 0
        data.assistant_discount = 0
      else
        data.main_discount = 100 - discount[1].main_discount
        data.assistant_discount = 100 - discount[1].assistant_discount
      end
    else
      data.main_discount = 0
      data.assistant_discount = 0
    end
  end
  local branchCfgList = CDataTable.GetTableByFilter("XSuitCommonBranch", "Period", period, "IsBranch", 1)
  local branchCfgMap = {}
  for _, cfg in pairs(branchCfgList) do
    if 0 <= cfg.BranchId and 2 >= cfg.BranchId then
      branchCfgMap[cfg.BranchId] = cfg
    end
  end
  for _, data in pairs(discountData) do
    local cfg = branchCfgMap[data.branchId]
    data.DiscountTexture = cfg and cfg.DiscountTexture
    data.CustomBg = cfg and cfg.CustomBg
  end
  local activeBranchId = LogicXSuit.GetActiveBranchIdByPeriod(period)
  return discountData, activeBranchId ~= nil
end

function LogicXSuit.GetUpgradeDiscountInfo(period)
  return LogicXSuit.UpgradeDiscount and LogicXSuit.UpgradeDiscount[period]
end

function LogicXSuit.GetBranchMapData(period, branchId)
  branchId = branchId or 0
  return CDataTable.GetTableDataByFilter("GoldenSuitMapCfg", "Period", period, "BranchId", branchId)
end

function LogicXSuit.GetTaskState(taskId, bWeek)
  if bWeek then
    local weekId = LogicXSuit.task_info.week_id
    local info = LogicXSuit.task_status_info and LogicXSuit.task_status_info.week_task
    return info and info[weekId] and info[weekId][taskId] or {}
  else
    return LogicXSuit.task_status_info and LogicXSuit.task_status_info.season_task and LogicXSuit.task_status_info.season_task[taskId] or {}
  end
end

function LogicXSuit.GetTaskConfig()
  local CommonItem_Const = require("client.slua.component.item.ItemUtils.CommonItem_Const")
  local weekId = LogicXSuit.task_info.week_id
  local weekTaskStatus = LogicXSuit.task_status_info and LogicXSuit.task_status_info.week_task and LogicXSuit.task_status_info.week_task[weekId] or {}
  local weekConfigs, realWeekConfigs = {}, {}
  local minTaskList = {}
  for taskId, stateData in pairs(weekTaskStatus) do
    local config = LogicXSuit.task_conf_info.week_task[taskId]
    if config then
      table.insert(realWeekConfigs, config)
      if not minTaskList[config.sys_category] then
        minTaskList[config.sys_category] = {}
      end
      if not minTaskList[config.sys_category][config.task_type] then
        minTaskList[config.sys_category][config.task_type] = config
      else
        local cacheCfg = minTaskList[config.sys_category][config.task_type]
        if cacheCfg.finish_value < config.finish_value then
          local state = LogicXSuit.GetTaskState(cacheCfg.task_id, true)
          if state.status == CommonItem_Const.Enum_ItemStatus.Got then
            minTaskList[config.sys_category][config.task_type] = config
          end
        else
          local state = LogicXSuit.GetTaskState(config.task_id, true)
          if state.status ~= CommonItem_Const.Enum_ItemStatus.Got then
            minTaskList[config.sys_category][config.task_type] = config
          end
        end
      end
    end
  end
  for sysId, taskTypeList in pairs(minTaskList) do
    for taskType, config in pairs(taskTypeList) do
      table.insert(weekConfigs, config)
    end
  end
  
  local function sortFunc(list, bWeek)
    table.sort(list, function(a, b)
      local stateA = LogicXSuit.GetTaskState(a.task_id, bWeek)
      local stateB = LogicXSuit.GetTaskState(b.task_id, bWeek)
      if stateA.status == stateB.status then
        return a.task_id < b.task_id
      else
        local bMaxA = stateA.finish_count and a.max_finish_count <= stateA.finish_count
        local bMaxB = stateB.finish_count and b.max_finish_count <= stateB.finish_count
        if bMaxA == bMaxB then
          if stateA.status == CommonItem_Const.Enum_ItemStatus.Done or stateB.status == CommonItem_Const.Enum_ItemStatus.Got then
            return true
          elseif stateB.status == CommonItem_Const.Enum_ItemStatus.Done or stateA.status == CommonItem_Const.Enum_ItemStatus.Got then
            return false
          else
            return a.task_id < b.task_id
          end
        else
          return bMaxB
        end
      end
    end)
  end
  
  local seasonConfigs, realSeasonConfigs = {}, {}
  minTaskList = {}
  for taskId, config in pairs(LogicXSuit.task_conf_info.season_task or {}) do
    table.insert(realSeasonConfigs, config)
    if not minTaskList[config.sys_category] then
      minTaskList[config.sys_category] = {}
    end
    if not minTaskList[config.sys_category][config.task_type] then
      minTaskList[config.sys_category][config.task_type] = config
    else
      local cacheCfg = minTaskList[config.sys_category][config.task_type]
      if cacheCfg.finish_value < config.finish_value then
        local state = LogicXSuit.GetTaskState(cacheCfg.task_id, false)
        if state.status == CommonItem_Const.Enum_ItemStatus.Got then
          minTaskList[config.sys_category][config.task_type] = config
        end
      else
        local state = LogicXSuit.GetTaskState(config.task_id, false)
        if state.status ~= CommonItem_Const.Enum_ItemStatus.Got then
          minTaskList[config.sys_category][config.task_type] = config
        end
      end
    end
  end
  for sysId, taskTypeList in pairs(minTaskList) do
    for taskType, config in pairs(taskTypeList) do
      table.insert(seasonConfigs, config)
    end
  end
  sortFunc(weekConfigs, true)
  sortFunc(seasonConfigs, false)
  return weekConfigs, seasonConfigs, realWeekConfigs, realSeasonConfigs
end

function LogicXSuit.GetTaskStartTime(bWeek)
  if bWeek then
    return LogicXSuit.task_info.week_info and LogicXSuit.task_info.week_info[LogicXSuit.task_info.week_id] and LogicXSuit.task_info.week_info[LogicXSuit.task_info.week_id].start_time or 0
  else
    return LogicXSuit.task_info.season_info and LogicXSuit.task_info.season_info[LogicXSuit.task_info.season_id] and LogicXSuit.task_info.season_info[LogicXSuit.task_info.season_id].start_time or 0
  end
end

function LogicXSuit.GetTaskEndTime(bWeek)
  if bWeek then
    return LogicXSuit.task_info.week_info and LogicXSuit.task_info.week_info[LogicXSuit.task_info.week_id] and LogicXSuit.task_info.week_info[LogicXSuit.task_info.week_id].end_time or 0
  else
    return LogicXSuit.task_info.season_info and LogicXSuit.task_info.season_info[LogicXSuit.task_info.season_id] and LogicXSuit.task_info.season_info[LogicXSuit.task_info.season_id].end_time or 0
  end
end

function LogicXSuit.GetTrialTaskTimeWindow()
  local taskStartTime = LogicXSuit.GetTaskStartTime(false) or 0
  local taskEndTime = LogicXSuit.GetTaskEndTime(false) or 0
  if taskStartTime <= 0 and taskEndTime <= 0 and LogicXSuit.task_info.season_id then
    log(bWriteLog and "LogicXSuit.GetTrialTaskTimeWindow task time is closed(start/end both 0)")
    return nil, nil
  end
  local startTime
  if 0 < taskStartTime and (not startTime or taskStartTime > startTime) then
    startTime = taskStartTime
  end
  local endTime
  if 0 < taskEndTime and (not endTime or taskEndTime < endTime) then
    endTime = taskEndTime
  end
  return startTime, endTime
end

function LogicXSuit.GetNextSeasonStartTime()
  local TimeUtil = require("client.common.time_util")
  local nowTime = TimeUtil.GetServerTimeInSec()
  local startTimeMap = {}
  for seasonId, cfg in pairs(LogicXSuit.task_info.season_info or {}) do
    local beginTime = cfg and cfg.begin_timestamp
    if beginTime and nowTime < beginTime then
      startTimeMap[seasonId] = beginTime
    end
  end
  local nextStartTime
  for _, beginTime in pairs(startTimeMap) do
    if not nextStartTime or beginTime < nextStartTime then
      nextStartTime = beginTime
    end
  end
  return nextStartTime
end

local function _ShowTrialTaskNotOpenNotice(bSilent)
  if bSilent then
    return
  end
  local nextStartTime = LogicXSuit.GetNextSeasonStartTime()
  if nextStartTime then
    local TimeUtil = require("client.common.time_util")
    ShowNotice(LocUtil.LocalizeResFormat(10120159, TimeUtil.FormatTime_YMDHM(nextStartTime, false)))
  else
    ShowNotice(118100002)
  end
end

function LogicXSuit.IsTrialTaskOpen()
  local startTime, endTime = LogicXSuit.GetTrialTaskTimeWindow()
  if not startTime or not endTime then
    return false
  end
  local TimeUtil = require("client.common.time_util")
  local nowTime = TimeUtil.GetServerTimeInSec()
  if startTime > nowTime or endTime < nowTime then
    return false
  end
  return true
end

function LogicXSuit.OpenTrialTaskUI(period, branchId, bSkipOpenWorkshop, bSilent)
  local TimeUtil = require("client.common.time_util")
  local nowTime = TimeUtil.GetServerTimeInSec()
  local startTime, endTime = LogicXSuit.GetTrialTaskTimeWindow()
  if not startTime then
    log(bWriteLog and string.format("LogicXSuit:OpenTrialTaskUI not open. taskStart=%s taskEnd=%s nextSeasonStart=%s", tostring(LogicXSuit.GetTaskStartTime(false)), tostring(LogicXSuit.GetTaskEndTime(false)), tostring(LogicXSuit.GetNextSeasonStartTime())))
    _ShowTrialTaskNotOpenNotice(bSilent)
    return false
  end
  if not endTime then
    log(bWriteLog and string.format("LogicXSuit:OpenTrialTaskUI end time is nil. nextSeasonStart=%s", tostring(LogicXSuit.GetNextSeasonStartTime())))
    _ShowTrialTaskNotOpenNotice(bSilent)
    return false
  end
  if nowTime < startTime then
    log(bWriteLog and string.format("LogicXSuit:OpenTrialTaskUI not start. now=%s start=%s end=%s", tostring(nowTime), tostring(startTime), tostring(endTime)))
    if not bSilent then
      ShowNotice(LocUtil.LocalizeResFormat(10120159, TimeUtil.FormatTime_YMDHM(startTime, false)))
    end
    return false
  end
  if nowTime > endTime then
    log(bWriteLog and string.format("LogicXSuit:OpenTrialTaskUI ended. now=%s start=%s end=%s taskEnd=%s", tostring(nowTime), tostring(startTime), tostring(endTime), tostring(LogicXSuit.GetTaskEndTime(false))))
    if not bSilent then
      ShowNotice(118100002)
    end
    return false
  end
  period = period or LogicXSuit.GetMaxPeriod()
  branchId = branchId or 0
  log(bWriteLog and string.format("LogicXSuit:OpenTrialTaskUI period:%s branchId:%s window=[%s,%s] skipOpenWorkshop:%s", tostring(period), tostring(branchId), tostring(startTime), tostring(endTime), tostring(bSkipOpenWorkshop)))
  if not bSkipOpenWorkshop then
    local workshopUI = UIManager.GetUI(UIManager.UI_Config.XSuit_Workshop_Main_UIBP)
    if not workshopUI or workshopUI._IsClosed then
      UIManager.ShowUI(UIManager.UI_Config.XSuit_Workshop_Main_UIBP, period, branchId)
    end
  end
  local time_ticker = require("common.time_ticker")
  time_ticker.AddTimerOnce(0, function()
    UIManager.ShowUI(UIManager.UI_Config.XSuit_GetMaterials_Main_UIBP, period, branchId, bSkipOpenWorkshop)
  end)
  return true
end

function LogicXSuit.GetTaskMaxFinishValue(bWeek)
  if bWeek then
    return LogicXSuit.task_info.week_info and LogicXSuit.task_info.week_info[LogicXSuit.task_info.week_id] and LogicXSuit.task_info.week_info[LogicXSuit.task_info.week_id].total_task or 0
  else
    return LogicXSuit.task_info.season_info and LogicXSuit.task_info.season_info[LogicXSuit.task_info.season_id] and LogicXSuit.task_info.season_info[LogicXSuit.task_info.season_id].total_task or 0
  end
end

function LogicXSuit.HasTrialTaskRewardCanGet(bWeek)
  local CommonItem_Const = require("client.slua.component.item.ItemUtils.CommonItem_Const")
  local taskConf = LogicXSuit.task_conf_info or {}
  local taskConfigs = bWeek and taskConf.week_task or taskConf.season_task or {}
  if not next(taskConfigs) then
    return false
  end
  local maxValue = LogicXSuit.GetTaskMaxFinishValue(bWeek)
  local curValue, bCanGet = 0, false
  for taskId, config in pairs(taskConfigs) do
    local stateData = LogicXSuit.GetTaskState(taskId, bWeek)
    if next(stateData) then
      if config.can_repeat_finish == 1 then
        local finishCount = stateData.finish_count or 0
        if config.max_finish_count and finishCount > config.max_finish_count then
          finishCount = config.max_finish_count
        end
        curValue = curValue + finishCount
      elseif stateData.status ~= CommonItem_Const.Enum_ItemStatus.Not then
        curValue = curValue + 1
      end
      if stateData.status == CommonItem_Const.Enum_ItemStatus.Done and maxValue >= curValue then
        bCanGet = true
      end
    end
  end
  return bCanGet
end

function LogicXSuit.GetBackMaterialList(period, branchId, level)
  local upgradeList = LogicXSuit.upgradeInfo[period][branchId]
  local materialLIst = {}
  for lv, datas in pairs(upgradeList) do
    if 1 < lv and lv <= level then
      local config = datas.cfg
      if not materialLIst[config.MatID1] then
        materialLIst[config.MatID1] = config.MatNum1
      else
        materialLIst[config.MatID1] = materialLIst[config.MatID1] + config.MatNum1
      end
      if not materialLIst[config.MatID2] then
        materialLIst[config.MatID2] = config.MatNum2
      else
        materialLIst[config.MatID2] = materialLIst[config.MatID2] + config.MatNum2
      end
    end
  end
  local backList = {}
  for id, num in pairs(materialLIst) do
    table.insert(backList, num)
  end
  return backList
end

function LogicXSuit.GetXSuitBannerList(period)
  if not period then
    return nil
  end
  local cfg = CDataTable.GetTableByFilter("XSuitBannerCfg", "Period", period)
  if not cfg then
    return nil
  end
  local resultList = {}
  for _, v in pairs(cfg) do
    table.insert(resultList, v)
  end
  return resultList
end

function LogicXSuit.GetXSuitChangeData(period, branchId, featureId)
  featureId = featureId or 1
  local customCfgList = CDataTable.GetTableByFilter("XSuitCustomScheme", "Period", period, "Branch", branchId, "FeatureID", featureId)
  local customDic = {}
  if customCfgList then
    for _, v in pairs(customCfgList) do
      if v.Quality then
        customDic[v.Quality] = v
      else
        log_error(string.format("LogicXSuit.GetXSuitChangeData XSuitCustomScheme.Quality is nil. period=%s, branchId=%s, featureId=%s, schemeID=%s", tostring(period), tostring(branchId), tostring(featureId), tostring(v.SchemeID)))
      end
    end
  end
  return customDic
end

function LogicXSuit.GetXSuitWorkshopCollectCfg(period, wFeatureID, branchLevel, branchId)
  if not period then
    return nil
  end
  local cfgList = CDataTable.GetTableByFilter("XSuitWorkshopCollect", "Period", period, "WFeatureID", wFeatureID, "BranchLevel", branchLevel, "BranchId", branchId)
  if cfgList then
    for _, cfg in pairs(cfgList) do
      return cfg
    end
  end
  return nil
end

function LogicXSuit.GetChangeColorLevel(period, branchId, schemeIndex)
  if not period then
    return nil
  end
  local collectTable = CDataTable.GetTable("XSuitWorkshopCollect")
  if not collectTable then
    return nil
  end
  local targetLevel
  for _, cfg in pairs(collectTable) do
    if cfg.Period == period and (cfg.BranchId or 0) == (branchId or 0) then
      local bHit = false
      if schemeIndex then
        bHit = 0 < (cfg[string.format("ItemID%d", schemeIndex)] or 0)
      else
        bHit = 0 < (cfg.ItemID2 or 0) or 0 < (cfg.ItemID3 or 0)
      end
      if bHit and (cfg.BranchLevel or 0) > (targetLevel or 0) then
        targetLevel = cfg.BranchLevel
      end
    end
  end
  if 0 < schemeIndex and targetLevel == 7 then
    targetLevel = 6
  end
  return targetLevel
end

local function PickWorkshopCollectCandidate(candidates, targetLevel)
  if not candidates or #candidates <= 0 then
    return nil
  end
  local target = tonumber(targetLevel) or 0
  local best
  if 0 < target then
    for _, one in ipairs(candidates) do
      if target >= one.level and (not best or one.level > best.level) then
        best = one
      end
    end
  end
  if not best then
    for _, one in ipairs(candidates) do
      if not best or one.level < best.level then
        best = one
      end
    end
  end
  return best
end

function LogicXSuit.GetWorkshopCollectCfgByItemId(colorItemId, period, branchId, targetLevel)
  if not colorItemId or colorItemId <= 0 then
    return nil
  end
  local collectTable = CDataTable.GetTable("XSuitWorkshopCollect")
  if not collectTable then
    return nil
  end
  local candidates = {}
  for _, cfg in pairs(collectTable) do
    if (not period or cfg.Period == period) and (branchId == nil or (cfg.BranchId or 0) == branchId) then
      for schemeIndex = 1, 3 do
        if (cfg[string.format("ItemID%d", schemeIndex)] or 0) == colorItemId then
          table.insert(candidates, {
            cfg = cfg,
            schemeIndex = schemeIndex,
            level = tonumber(cfg.BranchLevel) or 0
          })
          break
        end
      end
    end
  end
  local best = PickWorkshopCollectCandidate(candidates, targetLevel)
  if not best then
    return nil
  end
  log(bWriteLog and string.format("LogicXSuit.GetWorkshopCollectCfgByItemId itemId:%s period:%s branch:%s targetLevel:%s -> level:%s schemeIndex:%s", tostring(colorItemId), tostring(period), tostring(branchId), tostring(targetLevel), tostring(best.level), tostring(best.schemeIndex)))
  return best.cfg, best.schemeIndex
end

function LogicXSuit.GetWorkshopCollectCfgByFeatureId(featureId, period, branchId, targetLevel, colorItemId)
  if not featureId or featureId <= 0 then
    return nil
  end
  local collectTable = CDataTable.GetTable("XSuitWorkshopCollect")
  if not collectTable then
    return nil
  end
  local candidates = {}
  for _, cfg in pairs(collectTable) do
    if (cfg.CFeatureID or 0) == featureId and (not period or cfg.Period == period) and (branchId == nil or (cfg.BranchId or 0) == branchId) then
      local schemeIndex
      if colorItemId and 0 < colorItemId then
        for i = 1, 3 do
          if (cfg[string.format("ItemID%d", i)] or 0) == colorItemId then
            schemeIndex = i
            break
          end
        end
      end
      if not schemeIndex then
        for i = 1, 3 do
          if 0 < (cfg[string.format("ItemID%d", i)] or 0) then
            schemeIndex = i
            break
          end
        end
      end
      if schemeIndex then
        table.insert(candidates, {
          cfg = cfg,
          schemeIndex = schemeIndex,
          level = tonumber(cfg.BranchLevel) or 0
        })
      end
    end
  end
  local best = PickWorkshopCollectCandidate(candidates, targetLevel)
  if not best then
    return nil
  end
  log(bWriteLog and string.format("LogicXSuit.GetWorkshopCollectCfgByFeatureId featureId:%s period:%s branch:%s targetLevel:%s itemId:%s -> level:%s schemeIndex:%s", tostring(featureId), tostring(period), tostring(branchId), tostring(targetLevel), tostring(colorItemId), tostring(best.level), tostring(best.schemeIndex)))
  return best.cfg, best.schemeIndex
end

function LogicXSuit.GetWorkshopBaseAppearanceCfg(period, branchId, targetLevel)
  if not period then
    return nil
  end
  local collectTable = CDataTable.GetTable("XSuitWorkshopCollect")
  if not collectTable then
    return nil
  end
  local candidates = {}
  for _, cfg in pairs(collectTable) do
    if cfg.Period == period and (branchId == nil or (cfg.BranchId or 0) == branchId) and 0 < (cfg.ItemID1 or 0) then
      table.insert(candidates, {
        cfg = cfg,
        schemeIndex = 1,
        level = tonumber(cfg.BranchLevel) or 0
      })
    end
  end
  local best = PickWorkshopCollectCandidate(candidates, targetLevel)
  if not best then
    return nil
  end
  log(bWriteLog and string.format("LogicXSuit.GetWorkshopBaseAppearanceCfg period:%s branch:%s targetLevel:%s -> level:%s feature:%s schemeIndex:1", tostring(period), tostring(branchId), tostring(targetLevel), tostring(best.level), tostring(best.cfg.WFeatureID)))
  return best.cfg, best.schemeIndex
end

local UPGRADE_MAT_FIELDS = {
  "MatID1",
  "MatID2",
  "LimitMatID1",
  "LimitMatID2",
  "ActiveID1",
  "ActiveID2",
  "ExclusiveID1",
  "ExclusiveID2",
  "BackID1",
  "BackID2"
}
local LIMIT_MAT_FIELDS = {LimitMatID1 = true, LimitMatID2 = true}
local EXCLUSIVE_MAT_FIELDS = {ExclusiveID1 = true, ExclusiveID2 = true}

function LogicXSuit.GetCoinOwnCount(itemId)
  if not itemId or itemId <= 0 then
    return 0
  end
  local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
  return wardrobe_data:GetHallDepotItemCountByResID(itemId, true) or 0
end

function LogicXSuit.GetUpgradeUICoinInfo(period_id)
  if not period_id then
    return nil
  end
  
  local function PickCoinCfg(cfgList)
    local fallback
    for _, row in pairs(cfgList or {}) do
      if row.Star == 2 then
        return row
      end
      if not fallback and row.MatID1 and row.MatID1 > 0 then
        fallback = row
      end
    end
    return fallback
  end
  
  local cfg = PickCoinCfg(CDataTable.GetTableByFilter("GoldenSuitUpgradeCfg", "Period", period_id, "BranchId", 0))
  cfg = cfg or PickCoinCfg(CDataTable.GetTableByFilter("GoldenSuitUpgradeCfg", "Period", period_id))
  if not cfg then
    return nil
  end
  local coinInfo = {}
  for _, field in ipairs(UPGRADE_MAT_FIELDS) do
    local itemId = cfg[field]
    if itemId and 0 < itemId then
      local itemData = CDataTable.GetTableData("Item", itemId)
      if itemData then
        local bHideWhenEmpty = LIMIT_MAT_FIELDS[field] or EXCLUSIVE_MAT_FIELDS[field]
        if not bHideWhenEmpty or 0 < LogicXSuit.GetCoinOwnCount(itemId) then
          table.insert(coinInfo, {
            name = field,
            itemId = itemId,
            itemData = itemData
          })
        end
      else
        log_error(string.format("LogicXSuit.GetUpgradeUICoinInfo Item not found, period=%s, field=%s, itemId=%s", tostring(period_id), field, tostring(itemId)))
      end
    end
  end
  return coinInfo
end

function LogicXSuit.GetUpgradeCostList(period, branchId, level, bForceActive)
  local costList = {}
  if not period or branchId == nil or not level then
    return costList
  end
  LogicXSuit.InitXSuitBaseInfo(period)
  local periodInfo = LogicXSuit.upgradeInfo and LogicXSuit.upgradeInfo[period]
  local upgradeList = periodInfo and periodInfo[branchId]
  local datas = upgradeList and upgradeList[level]
  local info = datas and datas.cfg
  if not info then
    return costList
  end
  local bActive = bForceActive or LogicXSuit.GetActiveBranchIdByPeriod(period) == branchId
  local discountData, bOpenDiscount = LogicXSuit.GetDiscountBranchAndDiscount(period)
  for i = 1, 2 do
    local resID = info["MatID" .. i]
    local needCount = info["MatNum" .. i]
    local bUseActive = bActive and 0 < (info["ActiveID" .. i] or 0)
    if bUseActive then
      resID = info["ActiveID" .. i]
      needCount = info["ActiveNum" .. i]
    end
    if resID and 0 < resID and needCount and 0 < needCount then
      if bOpenDiscount and discountData then
        for _, data in pairs(discountData) do
          if data.branchId == branchId and data.level == level - 1 then
            local discountNum = i == 1 and data.main_discount or data.assistant_discount
            if discountNum and 0 < discountNum then
              needCount = math.ceil(needCount * (100 - discountNum) / 100)
            end
            break
          end
        end
      end
      local exclusiveId = bUseActive and (info["ExclusiveID" .. i] or 0) or 0
      table.insert(costList, {
        resID = resID,
        needCount = needCount,
        bActive = bUseActive,
        exclusiveId = exclusiveId
      })
    end
  end
  return costList
end

function LogicXSuit.IsBranchCanUpgrade(period, branchId, bIgnoreMaterial)
  if not period or period <= 0 or branchId == nil then
    return false
  end
  local periodInfo = LogicXSuit.upgradeInfo and LogicXSuit.upgradeInfo[period]
  if not periodInfo or not periodInfo[branchId] then
    return false
  end
  local curLevel = LogicXSuit.GetLevelByPeriodSelf(period, branchId) or 0
  local maxLevel = LogicXSuit.GetActSuitMaxLevelByPeriod(period, branchId) or 0
  if curLevel <= 0 or curLevel >= maxLevel then
    return false
  end
  if bIgnoreMaterial then
    return true
  end
  local materialInfo = LogicXSuit.BuildMaterialInfo(period, branchId, curLevel + 1)
  return materialInfo and materialInfo.bUpgrade and true or false
end

function LogicXSuit.GetUpgradeMaterialLackList(period, branchId)
  local lackList = {}
  local curLevel = LogicXSuit.GetLevelByPeriodSelf(period, branchId) or 0
  local maxLevel = LogicXSuit.GetActSuitMaxLevelByPeriod(period, branchId) or 0
  if curLevel <= 0 or curLevel >= maxLevel then
    return lackList
  end
  local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
  for _, cost in ipairs(LogicXSuit.GetUpgradeCostList(period, branchId, curLevel + 1)) do
    local haveCount = wardrobe_data:GetHallDepotItemCountByResID(cost.resID) or 0
    if cost.exclusiveId and 0 < cost.exclusiveId then
      haveCount = haveCount + (wardrobe_data:GetHallDepotItemCountByResID(cost.exclusiveId) or 0)
    end
    local lackCount = cost.needCount - haveCount
    if 0 < lackCount then
      table.insert(lackList, {
        resID = cost.resID,
        needCount = cost.needCount,
        haveCount = haveCount,
        lackCount = lackCount
      })
    end
  end
  return lackList
end

function LogicXSuit.GetNeedTaskCountByResID(resID, lackCount)
  if not (resID and lackCount) or lackCount <= 0 then
    return 0
  end
  local CommonItem_Const = require("client.slua.component.item.ItemUtils.CommonItem_Const")
  local rewardCountList = {}
  for _, bWeek in ipairs({true}) do
    local taskConfigs = bWeek and LogicXSuit.task_conf_info.week_task or LogicXSuit.task_conf_info.season_task or {}
    for taskId, config in pairs(taskConfigs) do
      local stateData = LogicXSuit.GetTaskState(taskId, bWeek)
      if stateData.status ~= CommonItem_Const.Enum_ItemStatus.Got then
        local times = 1
        if config.can_repeat_finish == 1 then
          local finished = stateData.finish_count or 0
          times = math.max((config.max_finish_count or 1) - finished, 0)
        end
        if 0 < times then
          local count = 0
          for _, reward in ipairs(config.reward_list or {}) do
            if reward.resid == resID then
              count = count + (reward.count or 0)
            end
          end
          if 0 < count then
            for _ = 1, times do
              table.insert(rewardCountList, count)
            end
          end
        end
      end
    end
  end
  table.sort(rewardCountList, function(a, b)
    return b < a
  end)
  local totalCount, usedTaskCount = 0, 0
  for _, count in ipairs(rewardCountList) do
    totalCount = totalCount + count
    usedTaskCount = usedTaskCount + 1
    if lackCount <= totalCount then
      return usedTaskCount
    end
  end
  return -1
end

function LogicXSuit.GetUpgradeNeedTaskCount(period, branchId)
  local lackList = LogicXSuit.GetUpgradeMaterialLackList(period, branchId)
  if #lackList <= 0 then
    return 0
  end
  local needTaskCount = 0
  for _, lack in ipairs(lackList) do
    local taskCount = LogicXSuit.GetNeedTaskCountByResID(lack.resID, lack.lackCount)
    if taskCount < 0 then
      return -1
    end
    needTaskCount = math.max(needTaskCount, taskCount)
  end
  return needTaskCount
end

function LogicXSuit.GetUpgradeCanLevelCount(period, branchId)
  local curLevel = LogicXSuit.GetLevelByPeriodSelf(period, branchId) or 0
  local maxLevel = LogicXSuit.GetActSuitMaxLevelByPeriod(period, branchId) or 0
  local baseLevel = 0 < curLevel and curLevel or 1
  if maxLevel <= baseLevel then
    return 0
  end
  local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
  local countMap = {}
  
  local function GetRestCount(resID)
    if countMap[resID] == nil then
      countMap[resID] = wardrobe_data:GetHallDepotItemCountByResID(resID) or 0
    end
    return countMap[resID]
  end
  
  local mergedExclusive = {}
  local levelCount = 0
  for level = baseLevel + 1, maxLevel do
    local costList = LogicXSuit.GetUpgradeCostList(period, branchId, level)
    if #costList <= 0 then
      break
    end
    for _, cost in ipairs(costList) do
      local exclusiveId = cost.exclusiveId
      if exclusiveId and 0 < exclusiveId and not mergedExclusive[exclusiveId] then
        mergedExclusive[exclusiveId] = true
        countMap[cost.resID] = GetRestCount(cost.resID) + (wardrobe_data:GetHallDepotItemCountByResID(exclusiveId) or 0)
      end
    end
    local bEnough = true
    for _, cost in ipairs(costList) do
      if GetRestCount(cost.resID) < cost.needCount then
        bEnough = false
        break
      end
    end
    if not bEnough then
      break
    end
    for _, cost in ipairs(costList) do
      countMap[cost.resID] = GetRestCount(cost.resID) - cost.needCount
    end
    levelCount = levelCount + 1
  end
  return levelCount
end

function LogicXSuit.GetUpgradeReachLevel(period, branchId)
  local curLevel = LogicXSuit.GetLevelByPeriodSelf(period, branchId) or 0
  local maxLevel = LogicXSuit.GetActSuitMaxLevelByPeriod(period, branchId) or 0
  if maxLevel <= 0 then
    return 0
  end
  local baseLevel = 0 < curLevel and curLevel or 1
  return math.min(baseLevel + LogicXSuit.GetUpgradeCanLevelCount(period, branchId), maxLevel)
end

function LogicXSuit.IsUpgradeMaterialEnough(period, branchId)
  if not period or branchId == nil then
    return false
  end
  local curLevel = LogicXSuit.GetLevelByPeriodSelf(period, branchId) or 0
  local startLevel = 0 < curLevel and curLevel or 1
  return startLevel < LogicXSuit.GetUpgradeReachLevel(period, branchId)
end

function LogicXSuit.SetXSuitCommonInfo(open, info, unlock_info, active_branch_info, Common2ActiveMaterial, UpgradeDiscount)
  log(bWriteLog and "LogicXSuit.SetXSuitCommonInfo open = " .. tostring(open) .. " || is : " .. tostring(open == 1))
  if info then
    LogicXSuit.shareTimeList = info
  else
    log(bWriteLog and "LogicXSuit.SetXSuitCommonInfo not info")
  end
  if unlock_info then
    LogicXSuit.unlockFeatureInfo = unlock_info
  else
    log(bWriteLog and "LogicXSuit.SetXSuitCommonInfo not unlock_info")
  end
  if active_branch_info then
    LogicXSuit.activeBranchInfo = active_branch_info
  else
    log(bWriteLog and "LogicXSuit.SetXSuitCommonInfo not active_branch_info")
  end
  if Common2ActiveMaterial then
    LogicXSuit.MaterialCommon2Active = Common2ActiveMaterial
  else
    log(bWriteLog and "LogicXSuit.SetXSuitCommonInfo not Common2ActiveMaterial")
  end
  if UpgradeDiscount then
    LogicXSuit.UpgradeDiscount = {}
    for period, datas in pairs(UpgradeDiscount) do
      LogicXSuit.UpgradeDiscount[period] = {}
      for discountLevel, discounts in pairs(datas) do
        for index, discount in pairs(discounts) do
          local levelInfo = discount.upgrade_list
          local realLevel = next(levelInfo)
          LogicXSuit.UpgradeDiscount[period][realLevel] = LogicXSuit.UpgradeDiscount[period][realLevel] or {}
          LogicXSuit.UpgradeDiscount[period][realLevel][discountLevel] = discount
          LogicXSuit.UpgradeDiscount[period][realLevel][discountLevel].level = realLevel
        end
      end
    end
  else
    log(bWriteLog and "LogicXSuit.SetXSuitCommonInfo not UpgradeDiscount")
  end
end

function LogicXSuit.SetXSuitLevel(cur_level, period, branch_id)
  if not (cur_level and period) or not branch_id then
    return
  end
  local branchInfo = LogicXSuit.shareTimeList[period] and LogicXSuit.shareTimeList[period][branch_id] or {}
  branchInfo.current = cur_level
  branchInfo.unlock_flag = true
  LogicXSuit.shareTimeList[period] = LogicXSuit.shareTimeList[period] or {}
  LogicXSuit.shareTimeList[period][branch_id] = branchInfo
end

function LogicXSuit.SetReddotCacheByPeriod(period, newVersion)
  LogicXSuit.reddotData[period] = LogicXSuit.reddotData[period] or {}
  LogicXSuit.reddotData[period].version = newVersion
  LogicXSuit.SetReddotCache()
end

function LogicXSuit.SetReddotCacheByBranchId(period, branchId, newVersion)
  LogicXSuit.reddotData[period] = LogicXSuit.reddotData[period] or {}
  LogicXSuit.reddotData[period][branchId] = LogicXSuit.reddotData[period][branchId] or {}
  LogicXSuit.reddotData[period][branchId].version = newVersion
  LogicXSuit.SetReddotCache()
end

function LogicXSuit.SetReddotCacheByLevel(period, branchId, level, newVersion)
  LogicXSuit.reddotData[period] = LogicXSuit.reddotData[period] or {}
  LogicXSuit.reddotData[period][branchId] = LogicXSuit.reddotData[period][branchId] or {}
  LogicXSuit.reddotData[period][branchId][level] = LogicXSuit.reddotData[period][branchId][level] or {}
  LogicXSuit.reddotData[period][branchId][level].version = newVersion
  LogicXSuit.SetReddotCache()
end

function LogicXSuit.SetReddotCacheByFeature(period, branchId, level, index, newVersion)
  LogicXSuit.reddotData[period] = LogicXSuit.reddotData[period] or {}
  LogicXSuit.reddotData[period][branchId] = LogicXSuit.reddotData[period][branchId] or {}
  LogicXSuit.reddotData[period][branchId][level] = LogicXSuit.reddotData[period][branchId][level] or {}
  LogicXSuit.reddotData[period][branchId][level][index] = LogicXSuit.reddotData[period][branchId][level][index] or {}
  LogicXSuit.reddotData[period][branchId][level][index].version = newVersion
  LogicXSuit.SetReddotCache()
end

function LogicXSuit.SetReddotCache()
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  PlayerPrefsSystem.SaveTableToFile_N(LogicXSuit.reddotData, PlayerPrefsSystem.ePlayerPrefsType.eGoldenSuitLotteryRedPoint)
end

function LogicXSuit.SetActiveBranchInfo(period, itemId, branchId, resetTimes)
  local oldInfo = LogicXSuit.activeBranchInfo[period]
  local newResetTimes = resetTimes
  if newResetTimes == nil then
    newResetTimes = oldInfo and oldInfo.reset_times or 0
  end
  LogicXSuit.activeBranchInfo[period] = {
    resid = itemId,
    branch_id = branchId,
    timestamp = oldInfo and oldInfo.timestamp,
    reset_times = newResetTimes
  }
end

function LogicXSuit.OnGetGoldDressNewLevelRsp(set_info)
  if set_info then
    LogicXSuit.switchLevel = set_info
  else
    local switchLevel = {}
    local config = xsuit_config_and_cache.GetVersionArgConfig()
    local maxPeriod = config.MAX_PERIOD or 1
    for i = 1, maxPeriod do
      switchLevel[i] = {}
      local allConfig, bBranch = LogicXSuit.GetBaseInfo(i)
      if bBranch then
        for BranchId, _ in pairs(allConfig) do
          switchLevel[i][BranchId] = LogicXSuit.GetLevelByPeriodSelf(i, BranchId)
        end
      else
        switchLevel[i][0] = LogicXSuit.GetLevelByPeriodSelf(i, 0)
      end
    end
    LogicXSuit.switchLevel = switchLevel
  end
  LogicXSuit.UpdateLobbyAvatar()
end

function LogicXSuit.SetSwitchLevelByPeriod(period, switchLevel, branch_id)
  branch_id = branch_id or 0
  local level = LogicXSuit.GetLevelByPeriodSelf(period, branch_id)
  if switchLevel > level or switchLevel <= 0 then
    return
  end
  local maxLevel = LogicXSuit.GetActSuitMaxLevelByPeriod(period, branch_id)
  if not maxLevel or switchLevel > maxLevel then
    return
  end
  if switchLevel ~= 1 and switchLevel ~= 3 and switchLevel ~= 6 and switchLevel ~= 7 then
    return
  end
  XSuitHandler.send_set_gold_dress_new_level_req(period, switchLevel, branch_id)
end

function LogicXSuit.OnSetGoldDressNewLevelRsp(period, switchLevel, branch_id)
  LogicXSuit.switchLevel[period] = LogicXSuit.switchLevel[period] or {}
  LogicXSuit.switchLevel[period][branch_id] = switchLevel
  local tlog_report_utils = require("client.slua.config.tlog.tlog_report_utils")
  local originalLevel = LogicXSuit.GetLevelByPeriodSelf(period, branch_id)
  if originalLevel == 7 and switchLevel < 7 then
    tlog_report_utils.ReportTLogEvent(TLogEventDefine.GoldenSuit_SwitchLevel_From_Seven)
  end
  if originalLevel == 6 and switchLevel < 6 then
    tlog_report_utils.ReportTLogEvent(TLogEventDefine.GoldenSuit_SwitchLevel_From_Six)
  end
  if 3 <= originalLevel and originalLevel < 6 and switchLevel == 1 then
    tlog_report_utils.ReportTLogEvent(TLogEventDefine.GoldenSuit_SwitchLevel_From_Three)
  end
  EventSystem:postEvent(EVENTTYPE_GOLDEN_SUIT, EVENTID_GOLDEN_SUIT_UPDATE_DRESS_LEVEL, branch_id)
  LogicXSuit.UpdateLobbyAvatar()
  local BasicDataAvatarWearInfo = ModuleManager.GetModule(ModuleManager.DataModuleConfig.BasicDataAvatarWearInfo)
  BasicDataAvatarWearInfo:GetOrReqData(DataMgr.roleData.uid, function(callUid, callInfo)
    EventSystem:postEvent(EVENTTYPE_RANK, EVENTID_WARZONE_UPDATE_AVATAR, callUid)
  end, {bForceReq = true}, Enum_AvatarShowSource.WardrobeLogic)
end

function LogicXSuit.SetWardrobeBranchByPeriod(period, data)
  LogicXSuit.XSuitWardrobeBranchData[period] = data
end

function LogicXSuit.SetWardrobeBranch(data)
  LogicXSuit.XSuitWardrobeBranchData = data
end

function LogicXSuit.SetSchemeIdCache(data)
  LogicXSuit.equip_data = data or {}
  LogicXSuit._SyncSelfXSuitSchemeToLobbyPawn()
end

function LogicXSuit.SetSchemeIdCacheByFeature(period, branchId, featureId, schemeId)
  LogicXSuit.equip_data[period] = LogicXSuit.equip_data[period] or {}
  LogicXSuit.equip_data[period][branchId] = LogicXSuit.equip_data[period][branchId] or {}
  LogicXSuit.equip_data[period][branchId][featureId] = schemeId
  LogicXSuit._SyncSelfXSuitSchemeToLobbyPawn()
end

function LogicXSuit.SetCollectInfo(info)
  LogicXSuit.collectInfo = info or {}
end

function LogicXSuit.SetCollectInfoByFeature(period, featureId)
  LogicXSuit.collectInfo[period] = LogicXSuit.collectInfo[period] or {}
  LogicXSuit.collectInfo[period][featureId] = 0
end

function LogicXSuit.SetTaskConfig(data)
  LogicXSuit.task_conf_info = data or {}
end

function LogicXSuit.SetTaskStatus(data)
  LogicXSuit.task_status_info = data or {}
end

function LogicXSuit.SetTaskWeekId(weekId, seasonId, bChangeOnline)
  if bChangeOnline and (weekId ~= LogicXSuit.task_info.week_id or seasonId ~= LogicXSuit.task_info.season_id) then
    EventSystem:postEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_MISSION_CONFIG_UPDATE)
  end
  LogicXSuit.task_info.week_id = weekId
  LogicXSuit.task_info.season_id = seasonId
end

function LogicXSuit.SetTaskTime(week_info, season_info)
  LogicXSuit.task_info.week_info = week_info
  LogicXSuit.task_info.season_info = season_info
end

function LogicXSuit.IsBranchOpen(period, branchId)
  local init_show_time = LogicXSuit.shareTimeList[period] and LogicXSuit.shareTimeList[period][branchId] and LogicXSuit.shareTimeList[period][branchId].init_show_time
  local TimeUtil = require("client.common.time_util")
  if init_show_time <= TimeUtil.GetServerTimeInSec() then
    return true
  end
  return false
end

function LogicXSuit.IsBranchUnlocked(period, branchId)
  return LogicXSuit.shareTimeList[period] and LogicXSuit.shareTimeList[period][branchId] and LogicXSuit.shareTimeList[period][branchId].unlock_flag
end

function LogicXSuit.IsGratingCardShown(period, branchId)
  if not period or not branchId then
    return false
  end
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local data = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eCheckShare)
  local info = data and data[string.format("XSuitGratingCard_%s_%s", tostring(period), tostring(branchId))]
  return (info and info.version) == Client.GetApplicationVersion()
end

function LogicXSuit.MarkGratingCardShown(period, branchId)
  if not period or not branchId then
    return
  end
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local eSaveType = PlayerPrefsSystem.ePlayerPrefsType.eCheckShare
  local data = PlayerPrefsSystem.LoadFileToTable_N(eSaveType)
  data = data or {}
  data[string.format("XSuitGratingCard_%s_%s", tostring(period), tostring(branchId))] = {
    version = Client.GetApplicationVersion()
  }
  PlayerPrefsSystem.SaveTableToFile_N(data, eSaveType)
end

function LogicXSuit.IsGunGratingCardShown(period)
  if not period then
    return false
  end
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local data = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eCheckShare)
  local info = data and data[string.format("XSuitGunGratingCard_%s", tostring(period))]
  return (info and info.version) == Client.GetApplicationVersion()
end

function LogicXSuit.MarkGunGratingCardShown(period)
  if not period then
    return
  end
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local eSaveType = PlayerPrefsSystem.ePlayerPrefsType.eCheckShare
  local data = PlayerPrefsSystem.LoadFileToTable_N(eSaveType)
  data = data or {}
  data[string.format("XSuitGunGratingCard_%s", tostring(period))] = {
    version = Client.GetApplicationVersion()
  }
  PlayerPrefsSystem.SaveTableToFile_N(data, eSaveType)
end

function LogicXSuit.IsBranch(period)
  local _, bBranch = LogicXSuit.GetBaseInfo(period)
  return bBranch
end

function LogicXSuit.CanShowUpgradeBtn(itemID)
  local level = LogicXSuit.GetLevelByItemId(itemID)
  local period = LogicXSuit.GetPeriodByItemId(itemID)
  local branchId = LogicXSuit.GetBranchByItemId(itemID)
  local info = LogicXSuit.GetBaseInfo(period, true, branchId)
  if level ~= nil and info ~= nil and level ~= info.max_level then
    return true
  else
    return false
  end
end

function LogicXSuit.SuitNeedUpgrading(period, branchId)
  local level = LogicXSuit.GetLevelByPeriodSelf(period, branchId)
  local maxLevel = LogicXSuit.GetActSuitMaxLevelByPeriod(period, branchId)
  return 0 < level and level < maxLevel
end

function LogicXSuit.CheckShowByLevel(period, level, BranchId)
  local maxPeriod = LogicXSuit.GetMaxPeriod()
  if not period or period > maxPeriod then
    return false
  end
  local redCfg = xsuit_config_and_cache.GetReddotWithWorkShopByPeriod(period, BranchId, level)
  local version = redCfg and redCfg.version or maxPeriod
  return maxPeriod >= version
end

function LogicXSuit.CheckShowByLevelAndFeature(period, level, feature, branchId)
  local maxPeriod = LogicXSuit.GetMaxPeriod()
  if not period or period > maxPeriod then
    return false
  end
  local redCfg = xsuit_config_and_cache.GetReddotWithWorkShopByPeriod(period, branchId, level, feature)
  local version = redCfg and redCfg.version or maxPeriod
  return maxPeriod >= version
end

function LogicXSuit.IsXSuit(itemID)
  LogicXSuit.InitXSuitItemList(itemID)
  return LogicXSuit.itemInfoList[itemID] ~= nil
end

function LogicXSuit.IsXSuitEmotion(itemID)
  local cfg = CDataTable.GetTableDataByFilter("GoldenSuitMapCfg", "BattleActionID", itemID)
  if cfg then
    return true
  end
  cfg = CDataTable.GetTableDataByFilter("GoldenSuitMapCfg", "InviterActionID", itemID)
  if cfg then
    return true
  end
  return false
end

function LogicXSuit.IsMuNaiYiBlockItem(itemID)
  if not itemID then
    return false
  end
  local config = CDataTable.GetTableData("MuNaiYiBlockCfg", itemID)
  return config ~= nil
end

function LogicXSuit.CheckHasSameGroupItem(resID)
  local period = LogicXSuit.GetPeriodByItemId(resID)
  if not period then
    return false
  end
  local branchId = LogicXSuit.GetBranchByItemId(resID)
  local branchInfo = LogicXSuit.shareTimeList[period] and LogicXSuit.shareTimeList[period][branchId]
  if branchInfo and branchInfo.unlock_flag and branchInfo.level_time and branchInfo.level_time[1] then
    return true, LogicXSuit.GetItemIDByLevel(period, 1, branchId)
  end
  return false
end

function LogicXSuit.CheckDownloadStatus(resID)
  log(bWriteLog and "LogicXSuit.CheckDownloadStatus resID: " .. tostring(resID) .. " " .. type(resID))
  if not _G.IsEditor and not PufferDownloader.PufferJsonDownloadReturn then
    return false
  end
  local period = LogicXSuit.GetPeriodByItemId(resID)
  if not period then
    return false
  end
  local branchId = LogicXSuit.GetBranchByItemId(resID)
  local downloadList = LogicXSuit.GetItemIDListByPeriod(period, branchId)
  local state = PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, downloadList)
  return state == PufferConst.ENUM_DownloadState.Done
end

function LogicXSuit.CheckSingleItemDownloadStatus(resID)
  local state = PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, {resID})
  if state ~= PufferConst.ENUM_DownloadState.Done then
    return false
  else
    return true
  end
end

function LogicXSuit.IsSpecialBranchBox(itemId)
  local boxCfg = CDataTable.GetTableData("XSuitBranchChest", itemId)
  return boxCfg
end

function LogicXSuit.CheckSpecialBranchBoxDownload(itemId)
  local boxCfg = CDataTable.GetTableData("XSuitBranchChest", itemId)
  if boxCfg then
    local list = {}
    table.insert(list, itemId)
    local StringUtil = require("common.string_util")
    local splitRet = StringUtil.Split(boxCfg.DependRes, "|")
    for _, v in pairs(splitRet) do
      if tonumber(v) then
        table.insert(list, tonumber(v))
      elseif StringUtil.Ends(tostring(v), ".mp4") then
        table.insert(list, DataMgr.GetVideoDownloadPath(v))
      else
        table.insert(list, v)
      end
    end
    local state = PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, list)
    if state ~= PufferConst.ENUM_DownloadState.Done then
      local PufferTlog = require("client.slua.logic.download.report.puffer_tlog")
      PufferManager.Download(PufferConst.ENUM_DownloadType.ODPAK, list, PufferTlog.Enum_TLog_From.Avatar, nil, {bFirst = true, bAutoDownload = false})
      return false
    else
      return true
    end
  end
  return false
end

local BranchBoxSelectUI = {
  ByPeriod = {
    [16] = "XSuit_Box_Select_UIBP_Special",
    [17] = "XSuit_Choose_4700_UIBP"
  },
  DefaultKey = "XSuit_Choose_4700_UIBP",
  FallbackKey = "XSuit_Box_Select_UIBP_Special"
}

function LogicXSuit.GetBranchBoxPeriod(itemId)
  if not itemId then
    return nil
  end
  local period = LogicXSuit.GetPeriodByItemId(itemId)
  if period then
    return period
  end
  local boxCfg = CDataTable.GetTableData("XSuitBranchChest", itemId)
  return boxCfg and boxCfg.Period
end

function LogicXSuit.GetBranchBoxSelectUIConfig(boxItemId)
  local period = LogicXSuit.GetBranchBoxPeriod(boxItemId)
  local keyName = BranchBoxSelectUI.ByPeriod[period] or BranchBoxSelectUI.DefaultKey
  local uiConfig = UIManager.GetConfigByKey(keyName) or UIManager.UI_Config[BranchBoxSelectUI.FallbackKey]
  if not uiConfig then
    log_error(string.format("LogicXSuit:GetBranchBoxSelectUIConfig no ui config, period:%s, keyName:%s", tostring(period), tostring(keyName)))
  end
  return uiConfig
end

function LogicXSuit.ShowBranchBoxSelect(boxItemId, callback, source, skipLoadScene)
  local uiConfig = LogicXSuit.GetBranchBoxSelectUIConfig(boxItemId)
  if not uiConfig then
    return
  end
  log(bWriteLog and string.format("LogicXSuit:ShowBranchBoxSelect period:%s, keyName:%s", tostring(LogicXSuit.GetBranchBoxPeriod(boxItemId)), tostring(uiConfig.keyName)))
  UIManager.ShowUI(uiConfig, boxItemId, callback, source, skipLoadScene)
end

function LogicXSuit.CloseBranchBoxSelect()
  local keyNames = {
    BranchBoxSelectUI.DefaultKey,
    BranchBoxSelectUI.FallbackKey
  }
  for _, key in pairs(BranchBoxSelectUI.ByPeriod) do
    table.insert(keyNames, key)
  end
  for _, key in ipairs(keyNames) do
    local uiConfig = UIManager.GetConfigByKey(key)
    if uiConfig then
      UIManager.CloseUI(uiConfig)
    end
  end
end

function LogicXSuit.IsItemCollected(period, itemId)
  return LogicXSuit.collectInfo and LogicXSuit.collectInfo[period] and LogicXSuit.collectInfo[period][itemId]
end

function LogicXSuit.IsGetAllXSuitByPeriod(period)
  if LogicXSuit.IsBranch(period) then
    local periodInfo = LogicXSuit.shareTimeList and LogicXSuit.shareTimeList[period]
    for branchId, branchInfo in pairs(periodInfo) do
      if not branchInfo.unlock_flag then
        return true, false
      end
    end
    return true, true
  else
    return false, LogicXSuit.IsBranchUnlocked(period, 0)
  end
end

function LogicXSuit.GetBranchMissionData(period)
  local StringUtil = require("common.string_util")
  local missionConfigs = CDataTable.GetTableByFilter("XSuitCollect", "Period", period)
  local missionList = {}
  local orbiterMission
  for _, config in pairs(missionConfigs) do
    local bBranch = config.IsBranch == 1
    local branchId = config.BranchId
    local conditions = {}
    local level_list = StringUtil.Split(config.BranchLevel, ";")
    for _, levelInfo in pairs(level_list or {}) do
      local info = StringUtil.Split(levelInfo, "=")
      conditions[tonumber(info[1])] = tonumber(info[2])
    end
    if bBranch then
      missionList[branchId] = missionList[branchId] or {}
      local mission = {
        conditions = conditions,
        branchId = branchId,
        period = config.Period,
        itemId = config.ItemID,
        missionBG = config.MissionBG
      }
      table.insert(missionList[branchId], mission)
      missionList[period] = missionList[period] or {}
      table.insert(missionList[period], mission)
    else
      orbiterMission = {
        conditions = conditions,
        period = config.Period,
        itemId = config.ItemID,
        missionBG = config.MissionBG
      }
    end
  end
  return missionList, orbiterMission
end

function LogicXSuit.GetBranchMissionItemData(period, itemId)
  local StringUtil = require("common.string_util")
  local missionConfigs = CDataTable.GetTableByFilter("XSuitCollect", "Period", period)
  local itemData
  for _, config in pairs(missionConfigs) do
    local bBranch = config.IsBranch == 1
    local branchId = config.BranchId
    local conditions = {}
    local level_list = StringUtil.Split(config.BranchLevel, ";")
    for _, levelInfo in pairs(level_list or {}) do
      local info = StringUtil.Split(levelInfo, "=")
      conditions[tonumber(info[1])] = tonumber(info[2])
    end
    if config.ItemID == itemId then
      itemData = {
        conditions = conditions,
        period = config.Period,
        itemId = config.ItemID,
        missionBG = config.MissionBG,
        titleDesc = config.TitleDesc
      }
      break
    end
  end
  return itemData
end

function LogicXSuit.ShowSendGiftUI(itemId, isFromExchange)
  local Logic_FriendGiftPopupShow = require("client.slua.logic.ItemGiveAndAsk.Logic_FriendGiftPopupShow")
  local Logic_ItemGiveAndAskConst = require("client.slua.logic.ItemGiveAndAsk.Logic_ItemGiveAndAskConst")
  local nGiveType = Logic_ItemGiveAndAskConst.Enum_GiveGiftType.XSuit
  Logic_FriendGiftPopupShow.ShowOnlyGiveFriendGift(nGiveType, itemId, nil, {bGiveXSuitFormExchange = isFromExchange})
end

function LogicXSuit.ShowGiftPacketUI(giftInfo, mailInfo)
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  if not LogicXSuit.CheckSpinDownloadState() then
    if not mailInfo then
      return
    end
    if logic_xsuit_activity:IsDrawActivityInfoNotFound() then
      if mailInfo.isFetched == false then
        local ShopGiftPacketLogic = require("client.logic.shop.logic_shop_gift_packet")
        ShopGiftPacketLogic.SendMarketGiftTakeReq(mailInfo.index)
      else
        ShowNotice(102036)
      end
    end
    return
  end
  local Config = require("client.slua.umg.lobby_activity.xsuit_spin.Config.XSuitSpinConfig")
  local GiftPacketCfg = Config.GiftPacket
  if not mailInfo then
    UIManager.ShowUIWithLuaAndBpPath(UIManager.UI_Config.MainUIWithoutLuaAndBpPathAsy, GiftPacketCfg.BaseLua, GiftPacketCfg.BPPath, giftInfo, mailInfo)
  else
    UIManager.ShowUI(UIManager.UI_Config.Xsuit_Gift_Confirm_UIBP, nil, function()
      UIManager.ShowUIWithLuaAndBpPath(UIManager.UI_Config.MainUIWithoutLuaAndBpPathAsy, GiftPacketCfg.BaseLua, GiftPacketCfg.BPPath, giftInfo, mailInfo)
    end)
  end
end

function LogicXSuit.CheckSpinDownloadState()
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  local actId = logic_xsuit_activity:GetDrawActivityID()
  if not actId then
    if not logic_xsuit_activity:IsDrawActivityInfoNotFound() then
      XSuitHandler.send_get_gold_dress_activity_req()
      ShowNotice(120164)
    end
    log(bWriteLog and "LogicXSuit.CheckSpinDownloadState false, not actId")
    return false
  end
  local state = PufferManager.GetStateByModuleIDActivityID(BP_ENUM_MODULE_XSUIT_SPIN)
  if state ~= PufferConst.ENUM_DownloadState.Done then
    log(bWriteLog and "LogicXSuit.CheckSpinDownloadState false, state = " .. tostring(state))
    return false
  end
  return true
end

function LogicXSuit.PopCommonTip(msglist)
  if not msglist or not next(msglist) then
    return
  end
  if IsWoWEditor then
    return
  end
  local uidlist = {}
  for i, v in ipairs(msglist) do
    table.insert(uidlist, v.uid)
  end
  
  local function cb()
    local logic_achievement_float_tip = require("client.slua.logic.achievement.logic_achievement_float_tip")
    if logic_achievement_float_tip.IslenthZeroNewAchievementList() then
      local logic_tarotcard_exchange_sendgift = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_tarotcard_exchange_sendgift)
      
      local function GetGiftTipPriority(msgInfo)
        if LogicXSuit.GetPeriodByItemId(msgInfo.item) or CDataTable.GetTableData("XSuitBranchChest", msgInfo.item) then
          return 1
        elseif logic_tarotcard_exchange_sendgift:CanPop(msgInfo.item) then
          return 2
        elseif msgInfo.bSmallRPCardGift then
          return 3
        end
        return 4
      end
      
      table.sort(msglist, function(a, b)
        return GetGiftTipPriority(a) < GetGiftTipPriority(b)
      end)
      for i, v in ipairs(msglist) do
        if LogicXSuit.GetPeriodByItemId(v.item) or CDataTable.GetTableData("XSuitBranchChest", v.item) then
          LogicXSuit.CheckXsuitAssert({
            PufferConst.EODPackID.XSuit
          }, function()
            UIManager.ShowUI(UIManager.UI_Config.XSuit_Mail_Gift_UIBP, v)
          end, nil, {bFirst = true, bAutoDownload = false})
        elseif logic_tarotcard_exchange_sendgift:CanPop(v.item) then
          local queueParam = ui_show_queue_config.GetParamTable(nil, nil, nil, GiftTipSortWeightOffset.Tarot)
          UIManager.ShowUI(UIManager.UI_Config.TarotCardGiftReceiveTips, v, queueParam)
        elseif v.bSmallRPCardGift then
          local queueParam = ui_show_queue_config.GetParamTable(nil, nil, nil, GiftTipSortWeightOffset.SmallRP)
          UIManager.ShowUI(UIManager.UI_Config.Common_Receive_UIBP, v, queueParam)
        else
          UIManager.ShowUI(UIManager.UI_Config.Common_Receive_UIBP, v)
        end
      end
    end
  end
  
  local logic_profile_get_wrap = require("client.slua.logic.user.profile.logic_profile_get_wrap")
  logic_profile_get_wrap.GetFriendProfiles(0, uidlist, cb)
end

function LogicXSuit.ClosePopTip()
  local ui = UIManager.GetUI(UIManager.UI_Config.Common_Receive_UIBP)
  if ui then
    UIManager.CloseUI(UIManager.UI_Config.Common_Receive_UIBP)
  end
end

function LogicXSuit.CreateXsuitShareConfig(period, branchId)
  local shareCfg = xsuit_config_and_cache.GetShareWithWorkshopByPeriod(period or 0, branchId)
  local config = {
    moduleName = "client.slua.umg.XSuit_Workshop.Page.XSuit_Share_Base_UIBP",
    path = shareCfg and shareCfg.path,
    isSingleton = false,
    asy = true,
    uiStat = {
      name = "\229\156\163\232\163\133-\229\136\134\228\186\171\231\149\140\233\157\162"
    },
    AndroidBackType = 2,
    keyName = string.format("golden_suit_share_base_%d", period or 0)
  }
  return config
end

function LogicXSuit.ShowGoldSuitShareUI(itemId, bReleaseMoment, closeFunc)
  local period = LogicXSuit.GetPeriodByItemId(itemId)
  local branchId = LogicXSuit.GetBranchByItemId(itemId)
  local baseCfg = LogicXSuit.CreateXsuitShareConfig(period, branchId)
  if bReleaseMoment then
    local logic_moment = require("client.slua.logic.moment.logic_moment")
    logic_moment.ShowMomentShare()
  else
    local Util = require("client.slua_ui_framework.util")
    local cfg = {
      campaign = "golden_suit",
      isOld = true,
      nItemId = itemId,
      share_type = ShareBtnTLogShareTypeDefine.HolyCostume,
      reasonStr = json.encode({
        uid = DataMgr.roleData.uid,
        itemId = itemId
      }),
      closeFunc = closeFunc
    }
    local ShareMgr = require("client.logic.share.share_logic")
    ShareMgr.ShareBtnReq(1, ShareBtnTLogShareTypeDefine.HolyCostume, nil, nil)
    Util.ShowShare(cfg, baseCfg, itemId)
  end
end

function LogicXSuit.CheckShareReady(itemId)
  local period = LogicXSuit.GetPeriodByItemId(itemId)
  if period then
    local branchId = LogicXSuit.GetBranchByItemId(itemId)
    local baseCfg = LogicXSuit.CreateXsuitShareConfig(period, branchId)
    local pak_util = require("client.common.pak_util")
    local isDownloaded = pak_util.IsPufferDownloaded(baseCfg.path)
    return isDownloaded, baseCfg.path
  end
  return true
end

function LogicXSuit.ShowUpgradeUI(period, branchId, itemId, state, featureIndex, schemeIndex, callFunc)
  local LogicFitVersionDownload = require("client.slua.logic.download.fit.logic_fitVersion_download")
  if LogicFitVersionDownload.IfNotFitLobbyResDownloadedShowWindow() then
    return
  end
  if not LogicXSuit.CheckWorkshopResAndShowPopup(function()
    if callFunc then
      callFunc()
    end
    LogicXSuit.ShowUpgradeUI(period, branchId, itemId, state, featureIndex, schemeIndex)
  end) then
    return false
  end
  if LogicXSuit.openUpgrade then
    if not period and not itemId then
      local xsuit_trial_reddot = require("client.slua.logic.XSuit.xsuit_trial_reddot")
      if xsuit_trial_reddot.IsRewardReddotShow() then
        log(bWriteLog and string.format("LogicXSuit:ShowUpgradeUI try jump to trial task ui. branchId=%s", tostring(branchId)))
        if LogicXSuit.OpenTrialTaskUI(LogicXSuit.GetMaxPeriod(), branchId or 0, nil, true) then
          return true
        end
      end
    end
    period = period or LogicXSuit.GetMaxPeriod()
    if not period or period <= 0 then
      log_error(string.format("LogicXSuit:ShowUpgradeUI invalid period:%s, itemId:%s", tostring(period), tostring(itemId)))
      if callFunc then
        callFunc()
      end
      return false
    end
    UIManager.ShowUI(UIManager.UI_Config.XSuit_Workshop_Main_UIBP, period, branchId, itemId, state, featureIndex, schemeIndex)
    if callFunc then
      callFunc()
    end
    return true
  else
    ShowNotice(120001)
    if callFunc then
      callFunc()
    end
    return false
  end
end

function LogicXSuit.ShowUpgradeUIFromURL()
  local isOpen = LogicXSuit.openUpgrade
  if not isOpen then
    ShowNotice(120001)
    return
  end
  local level_unlock_manager = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.level_unlock_manager)
  if not level_unlock_manager:IsFeatureUnlocked(level_unlock_manager.featureDef.workshop) then
    ShowNotice(level_unlock_manager:GetLockTip(level_unlock_manager.featureDef.workshop))
    return
  end
  LogicXSuit.ShowUpgradeUI()
end

function LogicXSuit.ShowCollectUI(period, itemId, branchId)
  period = period or LogicXSuit.GetMaxPeriod()
  if not period or period <= 0 then
    log_error("LogicXSuit.ShowCollectUI period is invalid, period=" .. tostring(period))
    return
  end
  local TAB_INDEX_COLLECT = 2
  branchId = branchId or LogicXSuit.GetActiveBranchIdByPeriod(period) or 0
  UIManager.ShowUI(UIManager.UI_Config.XSuit_Custom_UIBP, period, branchId, nil, TAB_INDEX_COLLECT, itemId)
end

function LogicXSuit.ShowUpgradeSuccessUI(curLevel, period, branch_id)
  local upgradeInfo = LogicXSuit.GetUpgradeInfo(period, true, branch_id)
  if not upgradeInfo or not upgradeInfo[curLevel] then
    return
  end
  local config = CDataTable.GetTableDataByFilter("XSuitCommonBranch", "Period", period, "IsBranch", 0)
  local audioID = LogicXSuit.GetUpgradeSuccessAudioID(period, branch_id, curLevel)
  local uiConfig = {
    keyName = "XSuit_Workshop_Upgrade_Success_UIBP",
    moduleName = "client.slua.umg.XSuit_Workshop.Popup.XSuit_Workshop_Upgrade_Success_UIBP",
    path = config and config.UpgradeSpecialShow ~= "" and config.UpgradeSpecialShow or "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/XSuit_Common_AscendStar_UIBP.XSuit_Common_AscendStar_UIBP",
    containerName = UIContainers.Top,
    asy = true,
    uiStat = {
      name = "\233\135\145\232\163\133-\229\141\135\230\152\159\230\136\144\229\138\159\231\149\140\233\157\162"
    }
  }
  local info = {
    item_id = upgradeInfo[curLevel].item_id,
    level = curLevel,
    max_level = LogicXSuit.GetActSuitMaxLevelByPeriod(period, branch_id),
    need_jump = upgradeInfo[curLevel].cfg.NeedJump,
    branch_id = branch_id,
    period = period,
    bSpecialShow = config and config.UpgradeSpecialShow ~= "",
    audioID = audioID
  }
  UIManager.ShowUI(uiConfig, info)
end

function LogicXSuit.GetUpgradeSuccessAudioID(period, branchId, level)
  local upgradeInfo = LogicXSuit.GetUpgradeInfo(period, true, branchId)
  local config = upgradeInfo and upgradeInfo[level] and upgradeInfo[level].cfg
  local audioID = config and config.UpgradeSuccessAudioId
  local normalAudioId = 4600356
  if not audioID or audioID <= 0 then
    log(bWriteLog and "LogicXSuit.GetUpgradeSuccessAudioID audioID is nil or <= 0")
    return normalAudioId
  end
  return audioID
end

function LogicXSuit:GetTaskRewardList()
  local list = {}
  for _, bWeek in ipairs({true, false}) do
    local taskConfigs = bWeek and LogicXSuit.task_conf_info.week_task or LogicXSuit.task_conf_info.season_task or {}
    local numMap = {}
    local idOrder = {}
    for _, config in pairs(taskConfigs) do
      for _, reward in ipairs(config.reward_list or {}) do
        local itemId = reward.resid
        if type(itemId) == "number" and 0 < itemId then
          if numMap[itemId] == nil then
            numMap[itemId] = 0
            table.insert(idOrder, itemId)
          end
          numMap[itemId] = numMap[itemId] + (reward.count or 0)
        end
      end
    end
    local itemId1, itemId2 = idOrder[1] or 0, idOrder[2] or 0
    table.insert(list, {
      itemid1 = itemId1,
      itemid2 = itemId2,
      title = bWeek and 18141488 or 200000708,
      num1 = numMap[itemId1] or 0,
      num2 = numMap[itemId2] or 0
    })
  end
  return list
end

local STIMULUS_ALL_BRANCH_KEY = "all"

local function ParseStimulusBranchLevel(branchLevel)
  local condition = {}
  if not branchLevel or branchLevel == "" then
    return condition
  end
  for one in string.gmatch(branchLevel, "[^;]+") do
    local branchId, level = string.match(one, "(%d+)%s*=%s*(%d+)")
    if branchId and level then
      condition[tonumber(branchId)] = tonumber(level)
    else
      log_error("LogicXSuit.ParseStimulusBranchLevel invalid BranchLevel: " .. tostring(one))
    end
  end
  return condition
end

function LogicXSuit.GetStimulusConditionMap(branchLevel)
  return ParseStimulusBranchLevel(branchLevel)
end

function LogicXSuit.GetStimulusBranchLevel(period, branchId, triggerBranchId, triggerLevel)
  local level = LogicXSuit.GetLevelByPeriodSelf(period, branchId) or 0
  if triggerLevel and 0 < triggerLevel and branchId == triggerBranchId then
    level = math.max(level, triggerLevel)
  end
  if level <= 0 then
    level = LogicXSuit.GetLevelByPeriod(period, nil, branchId) or 0
  end
  return level
end

function LogicXSuit.GetStimulusCollectionShownKey(period, index, branchId)
  return string.format("%s_%s_%s", tostring(period), tostring(index), tostring(branchId))
end

local function CalcStimulusRowState(period, cfg, triggerBranchId, triggerLevel)
  local state = {
    condition = ParseStimulusBranchLevel(cfg.BranchLevel),
    branchIds = {},
    curLevelMap = {},
    satisfied = {},
    satisfiedCount = 0,
    total = 0,
    isAllSatisfied = false
  }
  for condBranchId in pairs(state.condition) do
    table.insert(state.branchIds, condBranchId)
  end
  table.sort(state.branchIds)
  state.total = #state.branchIds
  for _, condBranchId in ipairs(state.branchIds) do
    local needLevel = state.condition[condBranchId]
    local curLevel = LogicXSuit.GetStimulusBranchLevel(period, condBranchId, triggerBranchId, triggerLevel)
    state.curLevelMap[condBranchId] = curLevel
    local bSatisfied
    if triggerBranchId and condBranchId == triggerBranchId then
      bSatisfied = curLevel == needLevel
    end
    state.satisfied[condBranchId] = bSatisfied
    if bSatisfied then
      state.satisfiedCount = state.satisfiedCount + 1
    end
  end
  state.isAllSatisfied = state.satisfiedCount >= state.total
  return state
end

function LogicXSuit.FindUnshownStimulusBranch(period, cfg, triggerBranchId, triggerLevel)
  local allKey = LogicXSuit.GetStimulusCollectionShownKey(period, cfg.Index, STIMULUS_ALL_BRANCH_KEY)
  if LogicXSuit.stimulusCollectionShown[allKey] then
    return nil
  end
  local state = CalcStimulusRowState(period, cfg, triggerBranchId, triggerLevel)
  if state.isAllSatisfied then
    LogicXSuit.stimulusCollectionShown[allKey] = true
    return nil
  end
  for _, condBranchId in ipairs(state.branchIds) do
    if state.satisfied[condBranchId] then
      local key = LogicXSuit.GetStimulusCollectionShownKey(period, cfg.Index, condBranchId)
      if not LogicXSuit.stimulusCollectionShown[key] then
        return condBranchId, state.condition[condBranchId], key
      end
    end
  end
end

function LogicXSuit.HasUnsatisfiedStimulusBranch(period, cfg)
  local branchLevelMap = cfg and LogicXSuit.GetStimulusConditionMap(cfg.BranchLevel)
  if not branchLevelMap or not next(branchLevelMap) then
    return true
  end
  for branchId, needLevel in pairs(branchLevelMap) do
    local curLevel = LogicXSuit.GetStimulusBranchLevel(period, branchId) or 0
    if needLevel > curLevel then
      return true
    end
  end
  return false
end

function LogicXSuit.CheckStimulusCollection(period, branchId, level)
  if not period or period <= 0 then
    return
  end
  local cfgList = CDataTable.GetTableByFilter("XSuitStimulusCollection", "Period", period)
  if not cfgList then
    return
  end
  local matchedList = {}
  local hitInfo = {}
  for _, cfg in pairs(cfgList) do
    if cfg.Index then
      local hitBranchId, hitLevel, key = LogicXSuit.FindUnshownStimulusBranch(period, cfg, branchId, level)
      if hitBranchId then
        LogicXSuit.stimulusCollectionShown[key] = true
        hitInfo[cfg] = {branchId = hitBranchId, level = hitLevel}
        table.insert(matchedList, cfg)
      end
    end
  end
  if #matchedList <= 0 then
    local detailList = {}
    for _, cfg in pairs(cfgList) do
      local state = CalcStimulusRowState(period, cfg, branchId, level)
      local oneRow = {}
      for _, condBranchId in ipairs(state.branchIds) do
        local shown = LogicXSuit.stimulusCollectionShown[LogicXSuit.GetStimulusCollectionShownKey(period, cfg.Index, condBranchId)]
        table.insert(oneRow, string.format("%s=%s/need%s%s", tostring(condBranchId), tostring(state.curLevelMap[condBranchId]), tostring(state.condition[condBranchId]), shown and "(shown)" or ""))
      end
      table.insert(detailList, string.format("idx%s(satisfied%s/%s%s)[%s]", tostring(cfg.Index), tostring(state.satisfiedCount), tostring(state.total), state.isAllSatisfied and "(all-satisfied,skip)" or "", table.concat(oneRow, ",")))
    end
    log(bWriteLog and string.format("LogicXSuit.CheckStimulusCollection no match. period=%s triggerBranch=%s triggerLevel=%s %s", tostring(period), tostring(branchId), tostring(level), table.concat(detailList, " ")))
    return
  end
  table.sort(matchedList, function(a, b)
    local weightA, weightB = a.weight or 0, b.weight or 0
    if weightA ~= weightB then
      return weightA < weightB
    end
    return (a.Index or 0) < (b.Index or 0)
  end)
  for _, cfg in ipairs(matchedList) do
    local hit = hitInfo[cfg] or {}
    table.insert(LogicXSuit.stimulusCollectionQueue, {
      period = period,
      branchId = hit.branchId or branchId or 0,
      level = hit.level or level,
      cfg = cfg,
      weight = cfg.weight or 0,
      index = cfg.Index or 0
    })
  end
  table.sort(LogicXSuit.stimulusCollectionQueue, function(a, b)
    if a.weight ~= b.weight then
      return a.weight < b.weight
    end
    if a.index ~= b.index then
      return a.index < b.index
    end
    return a.period < b.period
  end)
  LogicXSuit.TryShowStimulusCollection()
end

function LogicXSuit.CheckShowStimulusCollectionByItemId(itemId)
  if not itemId or itemId <= 0 then
    return
  end
  local period = LogicXSuit.GetPeriodByItemId(itemId)
  if not period then
    return
  end
  LogicXSuit.CheckStimulusCollection(period, LogicXSuit.GetBranchByItemId(itemId), LogicXSuit.GetLevelByItemId(itemId))
end

function LogicXSuit.OnGoldenSuitUpgradeSuccessShowStimulus(_, _, level, period, branchId)
  LogicXSuit.CheckStimulusCollection(period, branchId, level)
end

function LogicXSuit.MarkStimulusCollectionRecheck(period)
  if not period then
    return
  end
  LogicXSuit.stimulusRecheckPeriods[period] = true
end

function LogicXSuit.CheckStimulusCollectionOnStarInfoRefresh()
  if not next(LogicXSuit.stimulusRecheckPeriods) then
    return
  end
  local periods = LogicXSuit.stimulusRecheckPeriods
  LogicXSuit.stimulusRecheckPeriods = {}
  for period in pairs(periods) do
    LogicXSuit.CheckStimulusCollection(period)
  end
end

local GRATING_CARD_UI_KEYS = {
  "XSuit_Congratulations_Role",
  "XSuit_Congratulations_Gun"
}

function LogicXSuit.TryShowStimulusCollection()
  if LogicXSuit.stimulusCollectionShowing then
    return
  end
  while true do
    local head = LogicXSuit.stimulusCollectionQueue[1]
    if not head then
      return
    end
    if LogicXSuit.HasUnsatisfiedStimulusBranch(head.period, head.cfg) then
      break
    end
    log(bWriteLog and string.format("LogicXSuit.TryShowStimulusCollection drop satisfied row. period=%s index=%s", tostring(head.period), tostring(head.cfg and head.cfg.Index)))
    table.remove(LogicXSuit.stimulusCollectionQueue, 1)
  end
  local data = LogicXSuit.stimulusCollectionQueue[1]
  if not GameStatus or not GameStatus.IsInLobbyOrMainCity() then
    LogicXSuit.stimulusCollectionQueue = {}
    return
  end
  local drawShowUI = UIManager.GetUI(UIManager.UI_Config.XSuit_Get_UIBP)
  if drawShowUI and not drawShowUI:IsItemAnimFinished() then
    LogicXSuit.StartStimulusCollectionRetry()
    return
  end
  if UIManager.GetUIInstances().XSuit_Workshop_Upgrade_Success_UIBP then
    LogicXSuit.StartStimulusCollectionRetry()
    return
  end
  if UIManager.IsUIShow(UIManager.UI_Config.ItemGet_Root_UIBP) or UIManager.IsUIShow(UIManager.UI_Config.Common_ItemGet_UIBP) then
    LogicXSuit.StartStimulusCollectionRetry()
    return
  end
  local uiInstances = UIManager.GetUIInstances()
  for _, keyName in ipairs(GRATING_CARD_UI_KEYS) do
    if uiInstances[keyName] then
      LogicXSuit.StartStimulusCollectionRetry()
      return
    end
  end
  local stimulusUIKey = UIManager.UI_Config.XSuit_Stimulus_Collection_UIBP.keyName
  local existUI = UIManager.GetUIInstances()[stimulusUIKey]
  if existUI then
    if existUI:IsShow() then
      LogicXSuit.stimulusCollectionShowing = true
    else
      LogicXSuit.StartStimulusCollectionRetry()
    end
    return
  end
  LogicXSuit.stimulusCollectionShowing = true
  local ui = UIManager.ShowUI(UIManager.UI_Config.XSuit_Stimulus_Collection_UIBP, data.period, data.branchId, data.level, data.cfg)
  if not ui then
    log_error(string.format("LogicXSuit.TryShowStimulusCollection show failed. period=%s, index=%s", tostring(data.period), tostring(data.index)))
    LogicXSuit.stimulusCollectionShowing = false
  end
end

function LogicXSuit.OnStimulusCollectionClose()
  LogicXSuit.stimulusCollectionShowing = false
  table.remove(LogicXSuit.stimulusCollectionQueue, 1)
  LogicXSuit.TryShowStimulusCollection()
end

function LogicXSuit.OnItemGetFlowDone(_, _)
  LogicXSuit.TryShowStimulusCollection()
end

function LogicXSuit.StartStimulusCollectionRetry()
  if LogicXSuit.stimulusCollectionRetryHandle then
    return
  end
  local time_ticker = require("common.time_ticker")
  LogicXSuit.stimulusCollectionRetryHandle = time_ticker.AddTimerLoop(0.2, function()
    LogicXSuit.TryShowStimulusCollection()
    if LogicXSuit.stimulusCollectionShowing or #LogicXSuit.stimulusCollectionQueue <= 0 then
      LogicXSuit.StopStimulusCollectionRetry()
    end
  end, 0, 0.2)
end

function LogicXSuit.StopStimulusCollectionRetry()
  if not LogicXSuit.stimulusCollectionRetryHandle then
    return
  end
  local time_ticker = require("common.time_ticker")
  time_ticker.RemoveTimer(LogicXSuit.stimulusCollectionRetryHandle)
  LogicXSuit.stimulusCollectionRetryHandle = nil
end

function LogicXSuit.ShowUnlockStateSuccessUI(oldInfo, info)
  for period, data in pairs(info) do
    local oldData = oldInfo[period]
    for branchId, branchData in pairs(data) do
      local oldBranchData = oldData[branchId]
      for state, v in pairs(branchData.unlock_state) do
        local oldV = oldBranchData.unlock_state[state]
        if not oldV or v ~= oldV then
          local ItemGetModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.rare_item_get_module)
          ItemGetModule:ShowOneXSuit(period, state)
          return
        end
      end
    end
  end
end

function LogicXSuit.JumpToVideo(id)
  LogicXSuit.ShowUpgradeUI()
end

function LogicXSuit.SetLastSelectedBranch(period, branchId)
  if not LogicXSuit.lastSelectedBranch then
    LogicXSuit.InitLastSelectedBranch()
  end
  LogicXSuit.lastSelectedBranch[period] = branchId
end

function LogicXSuit.GetLastSelectedBranch(period)
  if not LogicXSuit.lastSelectedBranch then
    LogicXSuit.InitLastSelectedBranch()
  end
  return LogicXSuit.lastSelectedBranch[period]
end

function LogicXSuit.InitLastSelectedBranch()
  LogicXSuit.lastSelectedBranch = {}
end

function LogicXSuit.CheckHasEquipXSuitByAction(action_id)
  local TeamAvatarManager = require("client.logic.avatar.logic_team_avatar_manager")
  local data = LogicXSuit.actionPeriodMap[action_id]
  local info = LogicXSuit.GetUpgradeInfo(data.Period, true, data.BranchId or 0)
  if not info then
    return false, false
  end
  local avatar = TeamAvatarManager.GetMainAvatar()
  local multi_state_manager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.multi_state_manager)
  for i, info in pairs(info) do
    if avatar:HasEquiped(info.item_id) then
      return true, 1 < i
    end
    local allDisplayID = multi_state_manager:GetAllDisplayClothIDByOriginID(info.item_id)
    if allDisplayID then
      for _, disPlayID in pairs(allDisplayID) do
        if avatar:HasEquiped(disPlayID) then
          return true, 1 < i
        end
      end
    end
  end
  return false, false
end

function LogicXSuit.RefreshAllTeammateRelic()
  for uid, data in pairs(LogicXSuit.relicInfoList) do
    if data and data.status and data.wearID ~= 0 then
      local TeamAvatarManager = require("client.logic.avatar.logic_team_avatar_manager")
      TeamAvatarManager.PutonEquipment(uid, data.wearID)
    end
  end
end

function LogicXSuit.OnRelicStatusChange(uid, itemid, status)
  local TeamAvatarManager = require("client.logic.avatar.logic_team_avatar_manager")
  uid = tostring(uid)
  if not LogicXSuit.relicInfoList[uid] then
    LogicXSuit.relicInfoList[uid] = {status = false, wearID = 0}
  end
  local relicInfo = LogicXSuit.relicInfoList[uid]
  local oldStatus = relicInfo.status or false
  local afterStatus = status == 2 and itemid ~= 0
  if itemid == 0 then
    afterStatus = false
  end
  log(bWriteLog and "[Debug][Suit][Team] GetPlayerRelicStatus change uid = " .. tostring(uid) .. "|| oldStatus = " .. tostring(oldStatus) .. " || afterStatus = " .. tostring(afterStatus))
  local oldWearID = relicInfo.wearID
  relicInfo.status = afterStatus
  relicInfo.wearID = afterStatus and itemid or 0
  if oldStatus and not afterStatus then
    if itemid ~= 0 then
      TeamAvatarManager.PutoffEquipment(uid, itemid)
    end
    if oldWearID ~= 0 and oldWearID ~= itemid then
      TeamAvatarManager.PutoffEquipment(uid, oldWearID)
    end
    local logic_share_bag_team_util = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_share_bag_team_util)
    local selectSharedItems = logic_share_bag_team_util:GetLastSelectSharedItemsByUID(uid)
    logic_share_bag_team_util:UpdateTeamAvatar(uid, selectSharedItems, true)
    EventSystem:postEvent(EVENTTYPE_GOLDEN_SUIT, EVENTID_GOLDEN_SUIT_REFRESH_RELIC_STATUS)
    if uid == tostring(DataMgr.roleData.uid) then
      EventSystem:postEvent(EVENTTYPE_GOLDEN_SUIT, EVENTID_GOLDEN_SUIT_UPDATE_RELIC_STATUS, oldWearID, false)
    end
  elseif not oldStatus and afterStatus then
    TeamAvatarManager.PutonEquipment(uid, itemid)
    EventSystem:postEvent(EVENTTYPE_GOLDEN_SUIT, EVENTID_GOLDEN_SUIT_REFRESH_RELIC_STATUS)
    if uid == tostring(DataMgr.roleData.uid) then
      EventSystem:postEvent(EVENTTYPE_GOLDEN_SUIT, EVENTID_GOLDEN_SUIT_UPDATE_RELIC_STATUS, itemid, true)
    end
  elseif oldStatus and afterStatus then
    TeamAvatarManager.PutoffEquipment(uid, oldWearID)
    TeamAvatarManager.PutonEquipment(uid, itemid)
    EventSystem:postEvent(EVENTTYPE_GOLDEN_SUIT, EVENTID_GOLDEN_SUIT_REFRESH_RELIC_STATUS)
    if uid == tostring(DataMgr.roleData.uid) then
      EventSystem:postEvent(EVENTTYPE_GOLDEN_SUIT, EVENTID_GOLDEN_SUIT_UPDATE_RELIC_STATUS, itemid, true)
    end
  end
end

function LogicXSuit.CheckAndPlayEnterAction(AvatarUID)
  local actionID = LogicXSuit.GetNeedPlayActionID(AvatarUID)
  if actionID == nil then
    return false
  end
  log(bWriteLog and "LogicXSuit.CheckAndPlayEnterAction" .. actionID)
  LogicXSuit.SetPlayedActionUid(AvatarUID)
  local TeamAvatarManager = require("client.logic.avatar.logic_team_avatar_manager")
  TeamAvatarManager.StopAction(AvatarUID)
  local time_ticker = require("common.time_ticker")
  time_ticker.AddTimerOnce(0.01, function()
    log(bWriteLog and "CheckAndPlayEnterAction GoldenSuit actionID:" .. tostring(actionID))
    TeamAvatarManager.PlayAction(AvatarUID, actionID)
  end)
  return true
end

function LogicXSuit.GetNeedPlayActionID(uid)
  local numberUid = tonumber(uid)
  if numberUid and LogicXSuit.playedActionUidMap[numberUid] then
    return nil
  end
  local info = LogicXSuit.needPlayActionMember[tostring(uid)]
  if info and info.itemID and LogicXSuit.CheckSingleItemDownloadStatus(info.itemID) then
    return info.actionID
  end
  return nil
end

function LogicXSuit.RefreshPlayActionUidList(info)
  if not info or not info.members then
    return
  end
  for k, v in pairs(LogicXSuit.playedActionUidMap) do
    if not info.members[k] then
      LogicXSuit.playedActionUidMap[k] = false
    end
  end
end

function LogicXSuit.RefreshSharedRelicInfo(info)
  log(bWriteLog and "LogicXSuit.RefreshSharedRelicInfo")
  if not GameStatus.IsInLobbyOrMainCity() then
    return
  end
  local TeamUpNewSystem = require("client.slua.logic.teamup.logic_team_up")
  local team_info = info or TeamUpNewSystem.teamInfo
  if not team_info or not team_info.members then
    return
  end
  LogicXSuit.needShowRelicID = 0
  LogicXSuit.needShowRelicUid = 0
  LogicXSuit.playerEquipItemID = 0
  local needShowRating = 0
  local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
  for _, v in pairs(team_info.members) do
    local golden_suit_id = 0
    if v.uid == tonumber(DataMgr.roleData.uid) then
      local tRoleWear = AvatarData.GetRoleWear()
      for _, instId in ipairs(tRoleWear) do
        local data = wardrobe_data:GetHallDepotItemDataByInsID(instId)
        if data and data.resID and LogicXSuit.IsXSuit(data.resID) and wardrobe_data:GetItemSource(instId) ~= EWardrobeDataSource.InheritWardrobe and LogicXSuit.CheckHasEquipXSuit() then
          golden_suit_id = data.resID
          LogicXSuit.playerEquipItemID = golden_suit_id
          break
        end
      end
    elseif v.wear_ext and v.wear_ext[3] and v.wear_ext[3][1] and v.wear_ext[3][ENUM_AVATAR_DATA_TYPE.Source] ~= EWardrobeDataSource.InheritWardrobe then
      local multi_state_manager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.multi_state_manager)
      local OriginItemID = multi_state_manager:GetOriginClothIDAndState(v.wear_ext[3][1]) or v.wear_ext[3][1]
      if LogicXSuit.IsXSuit(OriginItemID) then
        golden_suit_id = OriginItemID
      end
    end
    local relicID = LogicXSuit.GetShowRelicID(golden_suit_id)
    if relicID and needShowRating < v.max_segment_rating then
      LogicXSuit.needShowRelicID = relicID
      LogicXSuit.needShowRelicUid = tostring(v.uid)
      needShowRating = v.max_segment_rating
    end
  end
  log(bWriteLog and string.format("[Debug][Suit][Team] LogicXSuit.RefreshSharedRelicInfo needShowRelicId: %d, needShowRelicUid: %d", LogicXSuit.needShowRelicID or 0, LogicXSuit.needShowRelicUid or 0))
  EventSystem:postEvent(EVENTTYPE_GOLDEN_SUIT, EVENTID_GOLDEN_SUIT_REFRESH_RELIC_STATUS)
end

function LogicXSuit.GetXSuitTeamupAction(member_info)
  if not member_info then
    return
  end
  local action_info = LogicXSuit.needPlayActionMember[tostring(member_info.uid)]
  if not action_info then
    return
  end
  return action_info.actionID
end

function LogicXSuit.SyncXSuitScheme(teamInfo)
  if teamInfo.members == nil then
    return false
  end
  for _, v in pairs(teamInfo.members) do
    if tostring(v.uid) ~= DataMgr.roleData.uid then
      LogicXSuit._SyncTeammateXSuitSchemeToLobbyPawn(v, v.gold_dress_set_info_all)
    end
  end
end

function LogicXSuit._GetLobbyPawnsByUid(uid)
  local pawnList = {}
  if not uid then
    return pawnList
  end
  local uidStr = tostring(uid)
  
  local function collectPawn(Avatar)
    if not Avatar then
      return
    end
    local LobbyPawn = Avatar:GetModel()
    if slua.isValid(LobbyPawn) and LobbyPawn.SetClothSchemeIDList then
      table.insert(pawnList, LobbyPawn)
    end
  end
  
  local TeamAvatarManager = require("client.logic.avatar.logic_team_avatar_manager")
  collectPawn(TeamAvatarManager.GetAvatarByUid(uidStr))
  local XMissionAvatarMgr = require("client.slua.logic.TxMission.logic_xmission_avatar_mgr")
  collectPawn(XMissionAvatarMgr.GetAvatarByUID(uidStr))
  return pawnList
end

function LogicXSuit.MergeTeammateGoldDressSetInfoAll(memberInfo, gold_dress_set_info_all)
  if not (memberInfo and gold_dress_set_info_all) or not gold_dress_set_info_all.set_info then
    return
  end
  memberInfo.gold_dress_set_info_all = memberInfo.gold_dress_set_info_all or {}
  local allInfo = memberInfo.gold_dress_set_info_all
  allInfo.set_info = allInfo.set_info or {}
  for period, branchData in pairs(gold_dress_set_info_all.set_info) do
    if branchData then
      allInfo.set_info[period] = allInfo.set_info[period] or {}
      for branchId, data in pairs(branchData) do
        allInfo.set_info[period][branchId] = data
      end
    end
  end
end

function LogicXSuit._SyncTeammateXSuitSchemeToLobbyPawn(v, gold_dress_set_info_all)
  if not v or not v.uid then
    return
  end
  local pawnList = LogicXSuit._GetLobbyPawnsByUid(v.uid)
  if #pawnList <= 0 then
    return
  end
  local schemeIDList = {}
  local setInfo = gold_dress_set_info_all and gold_dress_set_info_all.set_info
  if setInfo then
    for _, periodData in pairs(setInfo) do
      if periodData then
        for _, branchData in pairs(periodData) do
          if branchData and branchData.personal_equip_info then
            for _, schemeID in pairs(branchData.personal_equip_info) do
              if schemeID and 0 < schemeID then
                table.insert(schemeIDList, schemeID)
              end
            end
          end
        end
      end
    end
  end
  for _, LobbyPawn in ipairs(pawnList) do
    LobbyPawn:SetClothSchemeIDList(schemeIDList)
  end
end

function LogicXSuit.GetSelfSchemeIDList()
  local schemeIDList = {}
  local equip_data = LogicXSuit.equip_data or {}
  local period, branchId = LogicXSuit.GetWornXSuitPeriodAndBranch()
  if not period then
    return schemeIDList
  end
  local branchData = equip_data[period] and equip_data[period][branchId]
  for _, schemeID in pairs(branchData or {}) do
    if schemeID and 0 < schemeID then
      table.insert(schemeIDList, schemeID)
    end
  end
  return schemeIDList
end

function LogicXSuit.GetAllSchemeIDList()
  local schemeIDList = {}
  local equip_data = LogicXSuit.equip_data or {}
  for _, periodData in pairs(equip_data) do
    for _, branchData in pairs(periodData or {}) do
      for _, schemeID in pairs(branchData or {}) do
        if schemeID and 0 < schemeID then
          table.insert(schemeIDList, schemeID)
        end
      end
    end
  end
  return schemeIDList
end

function LogicXSuit._SyncSelfXSuitSchemeToLobbyPawn()
  log(bWriteLog and "LogicXSuit._SyncSelfXSuitSchemeToLobbyPawn")
  if not (DataMgr and DataMgr.roleData) or not DataMgr.roleData.uid then
    return
  end
  local pawnList = LogicXSuit._GetLobbyPawnsByUid(DataMgr.roleData.uid)
  if #pawnList <= 0 then
    return
  end
  local schemeIDList = LogicXSuit.GetSelfSchemeIDList()
  for _, LobbyPawn in ipairs(pawnList) do
    LobbyPawn:SetClothSchemeIDList(schemeIDList)
  end
end

function LogicXSuit.RefreshTeamInfo(info)
  if not GameStatus.IsInLobbyOrMainCity() then
    return
  end
  local team_info = info
  if team_info == nil then
    local TeamUpNewSystem = require("client.slua.logic.teamup.logic_team_up")
    team_info = TeamUpNewSystem.teamInfo
  end
  if not (team_info.members ~= nil and team_info.player_count) or team_info.player_count <= 1 then
    LogicXSuit.ClearPlayedActionUid()
  end
  if team_info.members == nil then
    return false
  end
  LogicXSuit.RefreshPlayActionUidList(info)
  LogicXSuit.needPlayActionMember = {}
  local team_member = 0
  local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
  for _, v in pairs(team_info.members) do
    local golden_suit_id = 0
    local golden_suit_source = EWardrobeDataSource.Wardrobe
    local unlockLevel
    local state = 0
    LogicXSuit.playerEquipItemID = 0
    if v.uid == tonumber(DataMgr.roleData.uid) then
      local tRoleWear = AvatarData.GetRoleWear()
      for _, instId in pairs(tRoleWear) do
        local data = wardrobe_data:GetHallDepotItemDataByInsID(instId)
        if data and data.resID and LogicXSuit.IsXSuit(data.resID) and LogicXSuit.CheckHasEquipXSuit() then
          golden_suit_source = wardrobe_data:GetItemSource(instId)
          local period = LogicXSuit.GetPeriodByItemId(data.resID)
          if period then
            golden_suit_id = data.resID
            local branch = LogicXSuit.GetBranchByItemId(data.resID) or 0
            if v.gold_dress_set_info and v.gold_dress_set_info.set_info and v.gold_dress_set_info.set_info[period] and v.gold_dress_set_info.set_info[period][branch] and golden_suit_source ~= EWardrobeDataSource.InheritWardrobe then
              golden_suit_id = LogicXSuit.GetSwitchItemByItemAndSwitchLevel(data.resID, v.gold_dress_set_info.set_info[period][branch])
            end
          end
          LogicXSuit.playerEquipItemID = golden_suit_id
          if period then
            unlockLevel = LogicXSuit.GetLevelByItemId(data.resID)
            state = LogicXSuit.GetCurStateByInsID(instId)
          end
          break
        end
      end
    elseif v.wear_ext and v.wear_ext[3] and v.wear_ext[3][1] then
      local period = LogicXSuit.GetPeriodByItemId(v.wear_ext[3][1])
      if period then
        local branch = LogicXSuit.GetBranchByItemId(v.wear_ext[3][1]) or 0
        unlockLevel = LogicXSuit.GetLevelByItemId(v.wear_ext[3][1])
        golden_suit_source = v.wear_ext[3][ENUM_AVATAR_DATA_TYPE.Source] or golden_suit_source
        golden_suit_id = v.wear_ext[3][ENUM_AVATAR_DATA_TYPE.ItemID]
        if golden_suit_source ~= EWardrobeDataSource.InheritWardrobe and v.gold_dress_set_info and v.gold_dress_set_info.set_info and v.gold_dress_set_info.set_info[period] and v.gold_dress_set_info.set_info[period][branch] then
          golden_suit_id = LogicXSuit.GetSwitchItemByItemAndSwitchLevel(v.wear_ext[3][1], v.gold_dress_set_info.set_info[period][branch])
        end
        if v.gold_dress_set_info_all and v.gold_dress_set_info_all.set_info and v.gold_dress_set_info_all.set_info[period] and v.gold_dress_set_info_all.set_info[period][branch] then
          state = v.gold_dress_set_info_all.set_info[period][branch].bicolor_state
        end
      end
    end
    local isOtherPlayer = tostring(v.uid) ~= DataMgr.roleData.uid
    local actionID = LogicXSuit.GetActionByItemId(golden_suit_id, isOtherPlayer, state, unlockLevel, v) or 0
    log(bWriteLog and "v.uid  = " .. tostring(v.uid) .. " || actionID = " .. tostring(actionID))
    if actionID and actionID ~= 0 then
      LogicXSuit.needPlayActionMember[tostring(v.uid)] = {actionID = actionID, itemID = golden_suit_id}
    end
    team_member = team_member + 1
  end
  LogicXSuit.RefreshSharedRelicInfo(info)
end

function LogicXSuit.CheckHasEquipXSuit(uid, tarAvatar, period)
  local TeamAvatarManager = require("client.logic.avatar.logic_team_avatar_manager")
  local avatar
  if tarAvatar then
    avatar = tarAvatar
  elseif uid ~= nil then
    avatar = TeamAvatarManager.GetAvatarByUid(uid)
  else
    avatar = TeamAvatarManager.GetMainAvatar()
  end
  if not avatar then
    return false
  end
  local multi_state_manager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.multi_state_manager)
  local equipmentsInfoList = avatar:GetEquipments()
  for k, v in pairs(equipmentsInfoList) do
    if v.itemID then
      if LogicXSuit.IsXSuit(v.itemID) then
        return true
      end
      local originCloth = multi_state_manager:GetOriginClothIDAndState(v.itemID)
      if originCloth and LogicXSuit.IsXSuit(originCloth) then
        return true
      end
    end
  end
  return false
end

function LogicXSuit.SetPlayedActionUid(uid)
  local numberUid = tonumber(uid)
  if numberUid then
    LogicXSuit.playedActionUidMap[numberUid] = true
  end
end

function LogicXSuit.ClearPlayedActionUid()
  LogicXSuit.playedActionUidMap = {}
end

function LogicXSuit.CheckNeedPutOnRelic(uid)
  log(bWriteLog and "[jonahwei][Suit][Team] CheckNeedPutOnRelic uid = " .. tostring(uid))
  local relicInfo = LogicXSuit.relicInfoList[uid]
  if relicInfo and relicInfo.status == true and relicInfo.wearID ~= 0 then
    return true, relicInfo.wearID
  end
  return false
end

function LogicXSuit.GetPlayerRelicStatus(uid)
  uid = tostring(uid)
  log(bWriteLog and "[Debug][Suit][Team] GetPlayerRelicStatus uid = " .. tostring(uid) .. "|| LogicXSuit.needShowUid = " .. tostring(LogicXSuit.needShowRelicUid) .. "|| relicInfoList[uid].status = " .. tostring(LogicXSuit.relicInfoList[uid] and LogicXSuit.relicInfoList[uid].status) .. " CheckHasEquipXSuit(): " .. tostring(LogicXSuit.CheckHasEquipXSuit()) .. " LogicXSuit.playerEquipItemID: " .. tostring(LogicXSuit.playerEquipItemID))
  if LogicXSuit.needShowRelicUid == tonumber(DataMgr.roleData.uid) or LogicXSuit.needShowRelicUid == 0 or LogicXSuit.CheckHasEquipXSuit() then
    return nil
  end
  if LogicXSuit.playerEquipItemID ~= 0 then
    return nil
  end
  local relicInfo = LogicXSuit.relicInfoList[uid]
  return relicInfo and relicInfo.status or false
end

function LogicXSuit.GetRelateItemBySchemeID(schemeID)
  if not schemeID or schemeID <= 0 then
    return nil
  end
  local row = CDataTable.GetTableDataByFilter("XSuitCustomScheme", "SchemeID", schemeID)
  if row and row.RelateItem and 0 < row.RelateItem then
    return row.RelateItem
  end
  return nil
end

function LogicXSuit.GetActionByItemId(itemID, isOtherPlayer, state, unlockLevel, v)
  local gold_dress_set_info_all = v.gold_dress_set_info_all
  local action_type_set_info = v.action_type_set_info
  local period = LogicXSuit.GetPeriodByItemId(itemID)
  if period ~= nil then
    local level = LogicXSuit.GetLevelByItemId(itemID)
    if level < 2 then
      return 0
    end
    local branchId = LogicXSuit.GetBranchByItemId(itemID)
    local cfg = LogicXSuit.GetBranchMapData(period, branchId)
    if not cfg then
      return 0
    end
    local low_action_id = cfg.LowTeamupActionID
    local XSuitSchemeFeatureType = require("GameLua.Activity.Commercialize.GamePlay.XSuit.XSuitSchemeFeatureType")
    local equipInfo = gold_dress_set_info_all and gold_dress_set_info_all.set_info and gold_dress_set_info_all.set_info[period] and gold_dress_set_info_all.set_info[period][branchId] and gold_dress_set_info_all.set_info[period][branchId].personal_equip_info
    local schemeID = equipInfo and equipInfo[XSuitSchemeFeatureType.TeamEnter2]
    if schemeID and 0 < schemeID then
      local schemeEmoteID = LogicXSuit.GetRelateItemBySchemeID(schemeID)
      if schemeEmoteID and 0 < schemeEmoteID then
        low_action_id = schemeEmoteID
      end
    end
    local UnLockFeatureType = require("GameLua.Activity.Commercialize.GamePlay.XSuit.UnLockFeatureType")
    local XSuitUtil = require("GameLua.Activity.Commercialize.GamePlay.XSuit.XSuitUtil")
    local isUnLockFeature, FeatureLevel, FeatureIndex = XSuitUtil:IsUnlockedFeature(period, branchId, UnLockFeatureType.TeamEnterAction2)
    if not isUnLockFeature or gold_dress_set_info_all and gold_dress_set_info_all.set_info and gold_dress_set_info_all.set_info[period] and gold_dress_set_info_all.set_info[period][branchId] and gold_dress_set_info_all.set_info[period][branchId].unlock_info and gold_dress_set_info_all.set_info[period][branchId].unlock_info[FeatureLevel] and gold_dress_set_info_all.set_info[period][branchId].unlock_info[FeatureLevel][FeatureIndex] and gold_dress_set_info_all.set_info[period][branchId].unlock_info[FeatureLevel][FeatureIndex].state == 1 then
    else
      low_action_id = 0
    end
    if level == 2 and 0 < low_action_id then
      return low_action_id
    end
    if level < 5 then
      local LowLevelEffect = require("GameLua.Activity.Commercialize.GamePlay.XSuit.LowLevelEffect")
      if not XSuitUtil:IsValidXSuitEffect(itemID, LowLevelEffect.TeamEnterAction5, unlockLevel) then
        return low_action_id
      end
    end
    if isOtherPlayer then
      if action_type_set_info and action_type_set_info.set_info and action_type_set_info.set_info[period] and action_type_set_info.set_info[period][branchId] and action_type_set_info.set_info[period][branchId] == 2 then
        return low_action_id
      end
      local otherActionId = cfg.OtherTeamupActionID
      if otherActionId and otherActionId ~= 0 then
        return otherActionId
      end
    else
      local levelAction = LogicXSuit.GetLevelAction(period, branchId)
      if levelAction == 2 then
        return low_action_id
      end
    end
    local action = cfg.TeamupActionID
    local multi_state_manager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.multi_state_manager)
    action = multi_state_manager:ChangeEmoteByState(action, state)
    return action
  end
  return nil
end

function LogicXSuit.IsNeedStopActionWhenPutOn(actionID)
  if not LogicXSuit.inviteActionMap then
    LogicXSuit.InitInviteAction()
  end
  for i, j in pairs(LogicXSuit.inviteActionMap) do
    if i == actionID then
      return true
    end
    for _, jj in pairs(j) do
      if jj == actionID then
        return true
      end
    end
  end
  return false
end

function LogicXSuit.IsInviteAction(action_id)
  if not action_id or action_id == 0 then
    return false
  end
  if not LogicXSuit.inviteActionMap then
    LogicXSuit.InitInviteAction()
  end
  return LogicXSuit.inviteActionMap[action_id] ~= nil
end

function LogicXSuit.GetInviteeActionList(action_id)
  if not LogicXSuit.inviteActionMap then
    LogicXSuit.InitInviteAction()
  end
  return LogicXSuit.inviteActionMap[action_id]
end

function LogicXSuit.CheckNeedSendInvite(inviter_action_id)
  log(bWriteLog and "CheckNeedSendInvite inviter_action_id = " .. tostring(inviter_action_id) .. " || value  = " .. tostring(LogicXSuit.inviteActionMap[inviter_action_id]))
  LogicXSuit.GetBaseInfo(1, true, 0)
  local TimeUtil = require("client.common.time_util")
  local time = TimeUtil.GetServerTimeInSec()
  if time - LogicXSuit.lastSendInviteTime <= 5.0 then
    log(bWriteLog and "CheckNeedSendInvite inviter_action_id is in CD ,cd = " .. tostring(time - LogicXSuit.lastSendInviteTime))
    return
  end
  LogicXSuit.lastSendInviteTime = time
  local inviteeActionIDs = LogicXSuit.inviteActionMap[inviter_action_id]
  if inviteeActionIDs ~= nil then
    XSuitHandler.send_change_emtion_action_req(inviter_action_id)
  end
end

function LogicXSuit.IsMatchAction(uid, actionID, suitID)
  if not (uid and actionID) or not suitID then
    return false
  end
  local actionInfo = LogicXSuit.needPlayActionMember[uid]
  if not actionInfo then
    return false
  end
  if actionInfo.itemID ~= suitID then
    return false
  end
  if actionInfo.actionID == actionID then
    return true
  end
  if actionInfo.actionID == 12219234 and actionID == 12219233 or actionInfo.actionID == 12219260 and actionID == 12219259 then
    return true
  end
  return false
end

function LogicXSuit.HasEliminationKingOverrideAvailable(ItemResID, CurItemLevel)
  if not (ItemResID and CurItemLevel) or CurItemLevel <= 0 then
    return false
  end
  local XSuitUtil = require("GameLua.Activity.Commercialize.GamePlay.XSuit.XSuitUtil")
  local Period = XSuitUtil:GetPeriodByItemId(ItemResID)
  if not Period or Period <= 0 then
    return false
  end
  local StateCfg = CDataTable.GetTableData("ClothingStateConfig", ItemResID)
  local SelfOriginClothID = StateCfg and StateCfg.OriginClothID or ItemResID
  local SelfState = StateCfg and StateCfg.State or 0
  local BattleEffectTable = CDataTable.GetTable("GoldClothBattleEffect")
  if not BattleEffectTable then
    return false
  end
  for CandidateID, CandidateCfg in pairs(BattleEffectTable) do
    if CandidateCfg.KingEliminationOverrideID and 0 < CandidateCfg.KingEliminationOverrideID then
      local CPeriod = XSuitUtil:GetPeriodByItemId(CandidateID)
      local CLevel = XSuitUtil:GetLevelByItemId(CandidateID) or 0
      if CPeriod == Period and CurItemLevel >= CLevel then
        local CCfg = CDataTable.GetTableData("ClothingStateConfig", CandidateID)
        local CandOrigin = CCfg and CCfg.OriginClothID or CandidateID
        local CandState = CCfg and CCfg.State or 0
        if CandOrigin == SelfOriginClothID and CandState == SelfState then
          return true
        end
      end
    end
  end
  return false
end

function LogicXSuit.GetEliminationKingClothOverrideEnabled()
  if LogicXSuit.EliminationKingClothOverrideEnabled == nil and not LogicXSuit._FetchingEliminationKingOverride then
    LogicXSuit._FetchingEliminationKingOverride = true
    XSuitHandler.send_gold_dress_get_eliminate_req()
  end
  return LogicXSuit.EliminationKingClothOverrideEnabled
end

function LogicXSuit.SetEliminationKingClothOverrideEnabled(flag)
  LogicXSuit.EliminationKingClothOverrideEnabled = flag == true and true or false
  LogicXSuit._FetchingEliminationKingOverride = false
  EventSystem:postEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_ELIMINATION_KING_OVERRIDE_UPDATE)
end

function LogicXSuit.ComputeEliminationKingOverrideDefault()
  local LogicEliminationKingEffect = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicEliminationKingEffect)
  local EquipedEffectId = LogicEliminationKingEffect and LogicEliminationKingEffect:GetCurEquipedEffectId() or nil
  return EquipedEffectId == nil or EquipedEffectId == 0
end

function LogicXSuit.IsEliminationKingOverrideFirstFetch()
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local data = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eXsuitEliminationKingOverrideInited)
  return data == nil or data.inited ~= true
end

function LogicXSuit.MarkEliminationKingOverrideInited()
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  PlayerPrefsSystem.SaveTableToFile_N({inited = true}, PlayerPrefsSystem.ePlayerPrefsType.eXsuitEliminationKingOverrideInited)
end

function LogicXSuit.HasAnyXSuitAtElimOverrideTier()
  if not LogicXSuit.shareTimeList then
    return false
  end
  for period, periodInfo in pairs(LogicXSuit.shareTimeList) do
    if type(periodInfo) == "table" then
      for branchId, branchInfo in pairs(periodInfo) do
        if type(branchInfo) == "table" and branchInfo.unlock_flag and (branchInfo.current or 0) >= 6 then
          local ItemResID = LogicXSuit.GetItemIDByLevel(period, 6, branchId)
          if ItemResID and LogicXSuit.HasEliminationKingOverrideAvailable(ItemResID, 6) then
            return true
          end
        end
      end
    end
  end
  return false
end

function LogicXSuit.SendGetGoldDressStateReq()
  log(bWriteLog and "LogicXSuit.SendGetGoldDressStateReq")
  XSuitHandler.send_get_gold_dress_state_req()
end

function LogicXSuit.OnGetGoldDressStateRsp(info, inherit_all_state_info)
  local LogicInheritWardrobe = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicInheritWardrobe)
  LogicInheritWardrobe:CacheXSuitStateInfo(inherit_all_state_info or {})
  if info or inherit_all_state_info then
    if LogicXSuit.stateInfo and info then
      LogicXSuit.ShowUnlockStateSuccessUI(LogicXSuit.stateInfo, info)
    end
    LogicXSuit.stateInfo = info or {}
    LogicXSuit.UpdateLobbyAvatar(true)
    EventSystem:postEvent(EVENTTYPE_GOLDEN_SUIT, EVENTID_GOLDEN_SUIT_UPDATE_DRESS_STATE)
    EventSystem:postEvent(EVENTTYPE_ROLEINFO, EVENTID_ROLEINFO_AVATAR_DATA_CHANGE)
  else
    log(bWriteLog and "LogicXSuit.OnGetGoldDressStateRsp miss info")
    LogicXSuit.stateInfo = {}
  end
end

function LogicXSuit.SendUnlockGoldDressStateReq(period, state, branchId)
  branchId = branchId or 0
  log(bWriteLog and "LogicXSuit.SendUnlockGoldDressStateReq")
  local itemID = LogicXSuit.GetItemIDByPeriodSelf(period, branchId)
  XSuitHandler.send_unlock_gold_dress_state_req(period, itemID, state, branchId)
end

function LogicXSuit.OnUnlockGoldDressStateRsp(info)
  if info then
    if LogicXSuit.stateInfo and info then
      LogicXSuit.ShowUnlockStateSuccessUI(LogicXSuit.stateInfo, info)
    end
    LogicXSuit.stateInfo = info
    LogicXSuit.UpdateLobbyAvatar()
    EventSystem:postEvent(EVENTTYPE_GOLDEN_SUIT, EVENTID_GOLDEN_SUIT_UNLOCK_STATE_SUCCESS)
  else
    log(bWriteLog and "LogicXSuit.OnUnlockGoldDressStateRsp miss info")
    LogicXSuit.stateInfo = {}
  end
end

function LogicXSuit.onRefreshGoldDressStateRsp(info)
  log_tree("LogicXSuit.onRefreshGoldDressStateRsp", info)
  if not LogicXSuit.stateInfo then
    LogicXSuit.stateInfo = {}
  end
  for k, v in pairs(info) do
    for branchId, data in pairs(v) do
      LogicXSuit.stateInfo[k] = LogicXSuit.stateInfo[k] or {}
      LogicXSuit.stateInfo[k][branchId] = data
      local ItemGetModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.rare_item_get_module)
      ItemGetModule:ShowOneXSuit(k, v.cur_state)
      EventSystem:postEvent(EVENTTYPE_GOLDEN_SUIT, EVENTID_GOLDEN_SUIT_UPDATE_DRESS_STATE, k)
    end
  end
end

function LogicXSuit.SendSetGoldDressStateReq(period, state, source, branch_id)
  branch_id = branch_id or 0
  log(bWriteLog and "LogicXSuit.SendSetGoldDressStateReq")
  XSuitHandler.send_set_gold_dress_state_req(period, state, source, branch_id)
end

function LogicXSuit.OnSetGoldDressStateRsp(info, source)
  if info then
    if source == EWardrobeDataSource.InheritWardrobe then
      local LogicInheritWardrobe = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicInheritWardrobe)
      for period, v in pairs(info) do
        for branchId, data in pairs(v) do
          LogicInheritWardrobe:ChangeXSuitStateInfo(period, branchId, data)
          EventSystem:postEvent(EVENTTYPE_GOLDEN_SUIT, EVENTID_GOLDEN_SUIT_UPDATE_DRESS_STATE, period)
        end
      end
    else
      for period, v in pairs(info) do
        for branchId, data in pairs(v) do
          LogicXSuit.stateInfo[period] = LogicXSuit.stateInfo[period] or {}
          LogicXSuit.stateInfo[period][branchId] = LogicXSuit.stateInfo[period][branchId] or {}
          LogicXSuit.stateInfo[period][branchId].cur_state = data.cur_state
          EventSystem:postEvent(EVENTTYPE_GOLDEN_SUIT, EVENTID_GOLDEN_SUIT_UPDATE_DRESS_STATE, period)
        end
      end
    end
    LogicXSuit.UpdateLobbyAvatar()
    local BasicDataAvatarWearInfo = ModuleManager.GetModule(ModuleManager.DataModuleConfig.BasicDataAvatarWearInfo)
    BasicDataAvatarWearInfo:GetOrReqData(DataMgr.roleData.uid, function(callUid, callInfo)
      EventSystem:postEvent(EVENTTYPE_RANK, EVENTID_WARZONE_UPDATE_AVATAR, callUid)
    end, {bForceReq = true}, Enum_AvatarShowSource.LogicXSuit)
  else
    log(bWriteLog and "LogicXSuit.OnSetGoldDressStateRsp miss info")
    LogicXSuit.stateInfo = {}
  end
end

function LogicXSuit.GetStateInfo(source)
  local stateInfo
  if source == EWardrobeDataSource.InheritWardrobe then
    local LogicInheritWardrobe = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicInheritWardrobe)
    stateInfo = LogicInheritWardrobe:GetXSuitStateInfo()
  else
    stateInfo = LogicXSuit.stateInfo
  end
  return stateInfo
end

function LogicXSuit.GetCurStateByPeriod(period, source)
  local stateInfo = LogicXSuit.GetStateInfo(source)
  if stateInfo and stateInfo[period] then
    return stateInfo[period][0].cur_state
  end
  return nil
end

function LogicXSuit.GetCurStateByItemID(itemID, source)
  LogicXSuit.InitXSuitItemList(itemID)
  if LogicXSuit.itemInfoList[itemID] then
    local period = LogicXSuit.itemInfoList[itemID].period
    return LogicXSuit.GetCurStateByPeriod(period, source)
  end
  return nil
end

function LogicXSuit.GetCurStateByInsID(InsID)
  local WardrobeData = require("client.slua.logic.wardrobe.wardrobe_data")
  local ItemData = WardrobeData:GetHallDepotItemDataByInsID(InsID)
  if not ItemData then
    log(bWriteLog and "LogicXSuit.GetCurStateByInsID not ItemData InsID:" .. tostring(InsID))
    return
  end
  local Source = WardrobeData:GetItemSource(InsID)
  return LogicXSuit.GetCurStateByItemID(ItemData.resID, Source)
end

function LogicXSuit.IsMultiStateCloth(itemID)
  log_warning(bWriteLog and "  LogicXSuit.IsMultiStateCloth. itemID: " .. tostring(itemID))
  local multi_state_manager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.multi_state_manager)
  return multi_state_manager:IsMultiStateCloth(itemID)
end

function LogicXSuit.ChangeItemIDByState(itemID, state)
  local multi_state_manager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.multi_state_manager)
  return multi_state_manager:ChangeClothByState(itemID, state)
end

function LogicXSuit.ChangeItemIDByMyselfState(itemID, source)
  LogicXSuit.InitXSuitItemList(itemID)
  if itemID and LogicXSuit.itemInfoList[itemID] then
    local period = LogicXSuit.itemInfoList[itemID].period
    local state = LogicXSuit.GetCurStateByPeriod(period, source)
    return LogicXSuit.ChangeItemIDByState(itemID, state)
  end
  return itemID
end

function LogicXSuit.GetXSuitItemIDByLevelAndState(itemID, level, state)
  if not itemID or not LogicXSuit.IsXSuit(itemID) then
    return itemID
  end
  LogicXSuit.InitXSuitItemList(itemID)
  local period = LogicXSuit.GetPeriodByItemId(itemID)
  if not period then
    return itemID
  end
  local targetLevelItemID = itemID
  if level and 0 < level then
    local branchId = LogicXSuit.GetBranchByItemId(itemID)
    targetLevelItemID = LogicXSuit.GetItemIDByLevel(period, level, branchId)
    if not targetLevelItemID then
      return itemID
    end
  end
  return LogicXSuit.ChangeItemIDByState(targetLevelItemID, state)
end

function LogicXSuit.ChangeItemIDByInsID(InsID)
  local WardrobeData = require("client.slua.logic.wardrobe.wardrobe_data")
  local Source = WardrobeData:GetItemSource(InsID)
  local itemID = WardrobeData:GetItemIDByInsID(InsID)
  return LogicXSuit.ChangeItemIDByMyselfState(itemID, Source)
end

function LogicXSuit.GetMyselfState(itemID)
  log(bWriteLog and "LogicXSuit.GetMyselfState itemID = " .. tostring(itemID))
  local state
  LogicXSuit.InitXSuitItemList(itemID)
  if itemID and LogicXSuit.itemInfoList[itemID] then
    local period = LogicXSuit.itemInfoList[itemID].period
    state = LogicXSuit.GetCurStateByPeriod(period, EWardrobeDataSource.Wardrobe)
    log(bWriteLog and "LogicXSuit.GetMyselfState state = " .. tostring(state))
  end
  return state
end

function LogicXSuit.CheckUnlockState(period, state, source)
  local stateInfo = LogicXSuit.GetStateInfo(source)
  if stateInfo and stateInfo[period] then
    return stateInfo[period][0].unlock_state[state] == 1
  end
  return false
end

function LogicXSuit.IsXSuitGlide(itemID)
  local NormalGlideID = LogicXSuit.GetNormalGlideID(itemID)
  local cfg = CDataTable.GetTableDataByFilter("XSuitGlideCfg", "GlideID", NormalGlideID)
  if not cfg then
    return false
  end
  return true
end

function LogicXSuit.GetLevel1XSuitID(NormalGlideID)
  local cfg = CDataTable.GetTableByFilter("XSuitGlideCfg", "GlideID", NormalGlideID)
  local res = {}
  for k, v in pairs(cfg or {}) do
    table.insert(res, v.XSuitID1)
  end
  return res
end

function LogicXSuit.GetLevel7XSuitID(NormalGlideID)
  local cfg = CDataTable.GetTableByFilter("XSuitGlideCfg", "GlideID", NormalGlideID)
  local res = {}
  for k, v in pairs(cfg or {}) do
    table.insert(res, v.XSuitID7)
  end
  return res
end

function LogicXSuit.GetAllSpecialGlideIDs(NormalGlideID)
  local cfgList = CDataTable.GetTableByFilter("XSuitGlideCfg", "GlideID", NormalGlideID)
  local result = {}
  for _, cfg in pairs(cfgList or {}) do
    if cfg.SpecialGlideID and cfg.SpecialGlideID > 0 then
      table.insert(result, cfg.SpecialGlideID)
    end
  end
  return result
end

function LogicXSuit.GetNormalGlideID(ItemID)
  local normalCfg = CDataTable.GetTableDataByFilter("XSuitGlideCfg", "GlideID", ItemID)
  if normalCfg then
    return normalCfg.GlideID
  end
  local specialCfg = CDataTable.GetTableDataByFilter("XSuitGlideCfg", "SpecialGlideID", ItemID)
  if specialCfg then
    return specialCfg.GlideID
  end
  return ItemID
end

function LogicXSuit.IsNormalGlideID(ItemID)
  local NormalGlideID = LogicXSuit.GetNormalGlideID(ItemID)
  if ItemID == NormalGlideID then
    return true
  end
  return false
end

function LogicXSuit.IsXSuitParachute(ItemID)
  local NormalParachuteID = LogicXSuit.GetNormalParachuteID(ItemID)
  local cfg = CDataTable.GetTableDataByFilter("XSuitParachuteCfg", "ParachuteID", NormalParachuteID)
  if not cfg then
    return false
  end
  return true
end

function LogicXSuit.GetLevel1XSuitParachuteID(NormalParachuteID)
  local cfg = CDataTable.GetTableByFilter("XSuitParachuteCfg", "ParachuteID", NormalParachuteID)
  local res = {}
  for k, v in pairs(cfg or {}) do
    table.insert(res, v.XSuitLv1ID)
  end
  return res
end

function LogicXSuit.GetLevel7XSuitParachuteID(NormalParachuteID)
  local cfg = CDataTable.GetTableByFilter("XSuitParachuteCfg", "ParachuteID", NormalParachuteID)
  local res = {}
  for k, v in pairs(cfg or {}) do
    table.insert(res, v.XSuitLv7ID)
  end
  return res
end

function LogicXSuit.GetAllSpecialParachuteIDs(NormalParachuteID)
  local cfgList = CDataTable.GetTableByFilter("XSuitParachuteCfg", "ParachuteID", NormalParachuteID)
  local result = {}
  for _, cfg in pairs(cfgList or {}) do
    if cfg.ExParachuteID and cfg.ExParachuteID > 0 then
      table.insert(result, cfg.ExParachuteID)
    end
  end
  return result
end

function LogicXSuit.GetNormalParachuteID(ItemID)
  local NormalCfg = CDataTable.GetTableDataByFilter("XSuitParachuteCfg", "ParachuteID", ItemID)
  if NormalCfg then
    return NormalCfg.ParachuteID
  end
  local SpecialCfg = CDataTable.GetTableDataByFilter("XSuitParachuteCfg", "ExParachuteID", ItemID)
  if SpecialCfg then
    return SpecialCfg.ParachuteID
  end
  return ItemID
end

function LogicXSuit.IsNormalParachuteID(ItemID)
  local NormalParachuteID = LogicXSuit.GetNormalParachuteID(ItemID)
  if ItemID == NormalParachuteID then
    return true
  end
  return false
end

function LogicXSuit.GetLevelAction(period, branchId)
  local default = 5
  if not LogicXSuit.levelAction then
    log(bWriteLog and "LogicXSuit.GetLevelAction not levelAction")
    XSuitHandler.send_gold_dress_get_level_action_req()
    return 5
  end
  return LogicXSuit.levelAction[period] and LogicXSuit.levelAction[period][branchId] or default
end

function LogicXSuit.GetFeatureSwitch(period, level, index, branchId)
  local info = LogicXSuit.FeatureSwitch
  if not (info and info[period] and info[period][branchId] and info[period][branchId][level]) or not info[period][branchId][level][index] then
    log(bWriteLog and "LogicXSuit.GetFeatureSwitch not FeatureSwitch")
    XSuitHandler.send_gold_dress_flag_operation_req(period, level, index, 2, nil, branchId)
    return 1
  end
  return info[period][branchId][level][index] or 1
end

function LogicXSuit.SetFeatureSwitch(info)
  LogicXSuit.FeatureSwitch = LogicXSuit.FeatureSwitch or {}
  LogicXSuit.FeatureSwitch[info.period_id] = LogicXSuit.FeatureSwitch[info.period_id] or {}
  LogicXSuit.FeatureSwitch[info.period_id][info.branch_id] = LogicXSuit.FeatureSwitch[info.period_id][info.branch_id] or {}
  LogicXSuit.FeatureSwitch[info.period_id][info.branch_id][info.level_id] = LogicXSuit.FeatureSwitch[info.period_id][info.branch_id][info.level_id] or {}
  LogicXSuit.FeatureSwitch[info.period_id][info.branch_id][info.level_id][info.index] = info.flag_value or 1
  local XSuitFeatureSwitchType = require("GameLua.Activity.Commercialize.GamePlay.XSuit.XSuitFeatureSwitchType")
  if info.index == XSuitFeatureSwitchType.RunAction then
    EventSystem:postEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_RUN_ACTION_UPDATE)
  elseif info.index == XSuitFeatureSwitchType.Orbiter then
    EventSystem:postEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_ORBITER_UPDATE)
  elseif info.index == XSuitFeatureSwitchType.Execute then
    EventSystem:postEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_EXECUTE_UPDATE)
  end
end

function LogicXSuit.HasUnlockFeature(period, branchId, level, index)
  if LogicXSuit.unlockFeatureInfo and LogicXSuit.unlockFeatureInfo[period] and LogicXSuit.unlockFeatureInfo[period][branchId] and LogicXSuit.unlockFeatureInfo[period][branchId][level] and LogicXSuit.unlockFeatureInfo[period][branchId][level][index] and LogicXSuit.unlockFeatureInfo[period][branchId][level][index] and LogicXSuit.unlockFeatureInfo[period][branchId][level][index].unlock_info_state.state == 1 then
    return true
  else
    return false
  end
end

function LogicXSuit.GetUnlockFeatureMaterial(period, branchId, level, index)
  if LogicXSuit.unlockFeatureInfo and LogicXSuit.unlockFeatureInfo[period] and LogicXSuit.unlockFeatureInfo[period][branchId] and LogicXSuit.unlockFeatureInfo[period][branchId][level] and LogicXSuit.unlockFeatureInfo[period][branchId][level][index] and LogicXSuit.unlockFeatureInfo[period][branchId][level][index] and LogicXSuit.unlockFeatureInfo[period][branchId][level][index].need_list then
    return LogicXSuit.unlockFeatureInfo[period][branchId][level][index].need_list
  else
    return {}
  end
end

function LogicXSuit.on_unlock_gold_dress_level_feature_rsp(period, branchId, level, index, gold_dress_set_info_all)
  log_tree("LogicXSuit.on_unlock_gold_dress_level_feature_rsp gold_dress_set_info_all", gold_dress_set_info_all)
  LogicXSuit.unlockFeatureInfo[period][branchId][level][index].unlock_info_state.state = gold_dress_set_info_all[period][branchId].unlock_info[level][index].state
  EventSystem:postEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_UNLOCK_FEATURE)
end

function LogicXSuit.draw_gold_dress_req(cost_times, currency_id, coupon_id, pool_id)
  XSuitHandler.send_draw_gold_dress_req(cost_times, currency_id, coupon_id and coupon_id ~= 0 and coupon_id or nil, pool_id)
  EventSystem:postEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_SPIN_SHOWORHIDE_MASK, true)
end

function LogicXSuit.UpdateLobbyAvatar(NeedPutOff)
  log(bWriteLog and "LogicXSuit.UpdateLobbyAvatar")
  local TeamAvatarManager = require("client.logic.avatar.logic_team_avatar_manager")
  local avatar = TeamAvatarManager.GetModel(DataMgr.roleData.uid)
  if avatar then
    local item, itemInsID
    local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
    local tRoleWear = AvatarData.GetRoleWear()
    for _, v in pairs(tRoleWear) do
      local itemInfo = wardrobe_data:GetHallDepotItemDataByInsID(v)
      if itemInfo and LogicXSuit.IsXSuit(itemInfo.resID) then
        item = itemInfo.resID
        itemInsID = itemInfo.insID
        break
      end
    end
    if item then
      local switchItem = LogicXSuit.GetItemShowID(itemInsID)
      if NeedPutOff then
        TeamAvatarManager.ChangeAvatarEquipment(DataMgr.roleData.uid, AvatarData.CreateAvatarCustom(item))
      end
      TeamAvatarManager.ChangeAvatarEquipment(DataMgr.roleData.uid, AvatarData.CreateAvatarCustom(switchItem), true)
    end
    LogicXSuit._SyncSelfXSuitSchemeToLobbyPawn()
  end
end

function LogicXSuit.ShowErrCode(err_code)
  if err_code == 100170001 then
    ShowNotice(10295)
  elseif err_code == 100170002 then
    ShowNotice(10296)
  elseif err_code == 100170003 then
    ShowNotice(10297)
  elseif err_code == 100170004 then
    ShowNotice(8262)
  elseif err_code == 100170005 then
    ShowNotice(9963)
  elseif err_code == 100170006 then
  elseif err_code == 100170007 then
    ShowNotice(10298)
  elseif err_code == 100170008 then
    ShowNotice(10299)
  elseif err_code == 100170126 then
    ShowNotice(995002)
  elseif err_code == 100170009 then
  elseif err_code == 100170010 then
  elseif err_code == 100170011 then
    local param0 = CDataTable.GetTableData("Item", 1521841).ItemName
    local str = LocUtil.LocalizeResFormat(10334, param0)
    ShowNotice(str)
  elseif err_code == 100170012 then
    ShowNotice(10299)
  elseif err_code == 100170013 then
    ShowNotice(10335)
  elseif err_code == 100170014 then
  elseif err_code == 100170015 then
    ShowNotice(9986)
  end
end

function LogicXSuit.CheckXsuitAssert(keyList, callback, from, extraData)
  log_tree("xcc LogicXSuit:CheckXsuitAssert keyList:", keyList)
  if not PufferManager.CheckAndDownload(PufferConst.ENUM_DownloadType.ODPACK, keyList, callback, from, extraData) and callback and type(callback) == "function" then
    callback()
  end
end

local CUSTOM_SCHEME_ICON_FIELDS = {
  "ItemSmallIcon",
  "ItemSmallIcon2",
  "ItemBigIcon",
  "ItemBigIcon2"
}

function LogicXSuit.GetCustomSchemeIconPathList()
  if LogicXSuit.customSchemeIconPathList then
    return LogicXSuit.customSchemeIconPathList
  end
  local iconPathList = {}
  local addedSet = {}
  local schemeTable = CDataTable.GetTable("XSuitCustomScheme")
  for _, schemeCfg in pairs(schemeTable or {}) do
    local itemID = schemeCfg.ItemID
    local itemCfg = itemID and 0 < itemID and CDataTable.GetTableData("Item", itemID)
    if itemCfg then
      for _, fieldName in ipairs(CUSTOM_SCHEME_ICON_FIELDS) do
        local iconPath = itemCfg[fieldName]
        if iconPath and iconPath ~= "" and not addedSet[iconPath] then
          addedSet[iconPath] = true
          table.insert(iconPathList, iconPath)
        end
      end
    end
  end
  local collectTable = CDataTable.GetTable("XSuitCollect")
  for _, schemeCfg in pairs(collectTable or {}) do
    local itemID = schemeCfg.ItemID
    local itemCfg = itemID and 0 < itemID and CDataTable.GetTableData("Item", itemID)
    if itemCfg then
      for _, fieldName in ipairs(CUSTOM_SCHEME_ICON_FIELDS) do
        local iconPath = itemCfg[fieldName]
        if iconPath and iconPath ~= "" and not addedSet[iconPath] then
          addedSet[iconPath] = true
          table.insert(iconPathList, iconPath)
        end
      end
    end
  end
  LogicXSuit.customSchemeIconPathList = iconPathList
  log(bWriteLog and "LogicXSuit.GetCustomSchemeIconPathList iconCount = " .. tostring(#iconPathList))
  return iconPathList
end

function LogicXSuit.GetWorkshopMixDownloadKeyList()
  local mixKeyList = {
    [PufferConst.ENUM_DownloadType.ODPACK] = {
      PufferConst.EODPackID.XSuit
    }
  }
  local iconPathList = LogicXSuit.GetCustomSchemeIconPathList()
  if next(iconPathList) then
    mixKeyList[PufferConst.ENUM_DownloadType.ODPAK] = iconPathList
  end
  return mixKeyList
end

function LogicXSuit.GetWorkshopResState()
  local state = PufferConst.ENUM_DownloadState.Done
  for downloadType, keyList in pairs(LogicXSuit.GetWorkshopMixDownloadKeyList()) do
    state = PufferManager.GetMixDownloadState(state, PufferManager.GetState(downloadType, keyList))
  end
  return state
end

function LogicXSuit.IsWorkshopResDownloaded()
  return LogicXSuit.GetWorkshopResState() == PufferConst.ENUM_DownloadState.Done
end

function LogicXSuit.GetWorkshopResRemainSizeMB()
  local remainSizeMB = 0
  for downloadType, keyList in pairs(LogicXSuit.GetWorkshopMixDownloadKeyList()) do
    local curSize, totalSize = PufferManager.GetSize(downloadType, keyList)
    local remain = totalSize - curSize
    if 0 < remain then
      if downloadType == PufferConst.ENUM_DownloadType.ODPACK then
        remainSizeMB = remainSizeMB + remain
      else
        remainSizeMB = remainSizeMB + remain / PufferConst.MB
      end
    end
  end
  return remainSizeMB
end

function LogicXSuit.DownloadWorkshopRes(from, callback, extraData)
  for downloadType, keyList in pairs(LogicXSuit.GetWorkshopMixDownloadKeyList()) do
    PufferManager.Download(downloadType, keyList, from, callback, extraData)
  end
end

function LogicXSuit.CheckAndDownloadWorkshopRes(from, callback, extraData)
  if LogicXSuit.IsWorkshopResDownloaded() then
    return false
  end
  if not PufferDownloader.PufferJsonDownloadReturn and not _G.IsEditor then
    ShowNotice(7421)
    return true
  end
  printf("LogicXSuit.CheckAndDownloadWorkshopRes start download. state:%s", LogicXSuit.GetWorkshopResState())
  LogicXSuit.DownloadWorkshopRes(from, callback, extraData)
  return true
end

function LogicXSuit.CheckWorkshopResAndShowPopup(okCallback)
  if LogicXSuit.IsWorkshopResDownloaded() then
    EventSystem:postEvent(EVENTTYPE_JUMP, EVENTID_JUMP_GAME_URL_DOWNLOAD_BREAK, false)
    return true
  end
  printf("LogicXSuit.CheckWorkshopResAndShowPopup res not ready. state:%s", LogicXSuit.GetWorkshopResState())
  EventSystem:postEvent(EVENTTYPE_JUMP, EVENTID_JUMP_GAME_URL_DOWNLOAD_BREAK, true)
  UIManager.ShowUI(UIManager.UI_Config.Common_DownloadPopup_UIBP, {
    tDownloadResList = LogicXSuit.GetWorkshopMixDownloadKeyList(),
    nDownloadType = PufferConst.ENUM_DownloadType.MIX,
    sDownloadTip = LocUtil.GetLocalizeResStr(180135),
    fCheckDownloadFinish = LogicXSuit.IsWorkshopResDownloaded,
    fOkCallback = okCallback
  })
  return false
end

function LogicXSuit.GetXSuitBranchChangeAction(period, fromBranch, toBranch)
  if not (period and fromBranch and toBranch) or fromBranch == toBranch then
    return nil, nil
  end
  local row = CDataTable.GetTableDataByFilter("XSuitBranchChangeActionConfig", "Period", period, "BeforeBranch", fromBranch, "AfterBranch", toBranch)
  if not row then
    return nil, nil
  end
  return row.ActionID, row.IsPlayAnimAfterTransform
end

function LogicXSuit.GetCurrentEquippedXSuitPeriodAndBranch(avatarLogic)
  if not avatarLogic then
    return nil, nil
  end
  local equipments = avatarLogic:GetEquipments()
  if not equipments then
    return nil, nil
  end
  local multi_state_manager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.multi_state_manager)
  for _, info in ipairs(equipments) do
    local displayID = info.itemID
    local originID = multi_state_manager:GetOriginClothIDAndState(displayID) or displayID
    if LogicXSuit.IsXSuit(originID) then
      return LogicXSuit.GetPeriodByItemId(originID), LogicXSuit.GetBranchByItemId(originID)
    end
  end
  return nil, nil
end

return LogicXSuit
