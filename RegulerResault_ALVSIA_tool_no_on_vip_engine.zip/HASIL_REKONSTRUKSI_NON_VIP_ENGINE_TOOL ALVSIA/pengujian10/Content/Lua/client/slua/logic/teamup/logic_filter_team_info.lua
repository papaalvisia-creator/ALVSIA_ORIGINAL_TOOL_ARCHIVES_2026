local logic_filter_team_info = {}
local C_WOWViewId = 20002
local Enum_CircleType = {
  SearchTime = 1,
  BatchSearchTime = 2,
  BatchSearchTimeAgain = 3
}
local CONST_REQUEST_INTERVAL_TIME = 3
local MAX_SHOW_TEAM_NUM = 10
local isOpenGM = false

function logic_filter_team_info:OnInitialize()
  logic_filter_team_info.__super.OnInitialize(self)
  self.teamFailedList = {}
  self.AllTeamList = {}
  self.realShowTeamList = {}
  self.curCircleIndex = Enum_CircleType.SearchTime
  self.nLastBatchSearchTeamTime = 0
end

function logic_filter_team_info:OnChangeToNoTeam()
  log(bWriteLog and "logic_filter_team_info:OnChangeToNoTeam")
  self:OnRefreshMyTeamInfo()
end

function logic_filter_team_info:OnCreateOrModifyPublishInfo()
  log(bWriteLog and "logic_filter_team_info:OnCreateOrModifyPublishInfo")
  local ConscribeHandler = require("client.network.Protocol.ConscribeHandler")
  ConscribeHandler.send_unregister_idle_player_req()
  self:OnRefreshMyTeamInfo()
end

function logic_filter_team_info:RegistEvents()
  self:AddCommonEvent(EVENTTYPE_TEAMUP, EVENTID_TEAM_PLATFORM_REFRESH_LIST, self.OnRefreshSearchList, self)
  self:AddCommonEvent(EVENTTYPE_TEAMUP, EVENTID_TEAMUP_BE_KICKED_OUT, self.OnRefreshMyTeamInfo, self)
  self:AddCommonEvent(EVENTTYPE_TEAMUP, EVENTID_TEAM_PLATFORM_RECRUIT_TIMEOUT, self.OnRefreshMyTeamInfo, self)
  self:AddCommonEvent(EVENTTYPE_TEAMUP, EVENTID_TEAM_PLATFORM_CANCEL, self.OnRefreshMyTeamInfo, self)
  self:AddCommonEvent(EVENTTYPE_TEAMUP, EVENTID_TEAM_PLATFORM_CLOSE_MY_TEAM, self.OnRefreshMyTeamInfo, self)
  self:AddCommonEvent(EVENTTYPE_TEAMUP, EVENTID_TEAM_PLATFORM_RECRUIT_MODIFY, self.OnRefreshMyTeamInfo, self)
  self:AddCommonEvent(EVENTTYPE_TEAMUP, EVENTID_CONSCRIBE_UPDATE_TEAM_UI, self.OnRefreshMyTeamInfo, self)
  self:AddCommonEvent(EVENTTYPE_TEAMUP, EVENTID_CONSCRIBE_UPDATE_TEAM, self.OnRefreshMyTeamInfo, self)
  self:AddCommonEvent(EVENTTYPE_TEAMUP, EVENTID_TEAM_PLATFORM_RECRUIT_PUBLISH, self.OnCreateOrModifyPublishInfo, self)
  self:AddCommonEvent(EVENTTYPE_TEAMUP, EVENTID_TEAMUP_CREATE_TEAM, self.OnCreateOrModifyPublishInfo, self)
  self:AddCommonEvent(EVENTTYPE_TEAMUP, EVENTID_TEAMUP_JOINT_TEAM_FAIL, self.OnJoinTeamFail, self)
  self:AddCommonEvent(EVENTTYPE_TEAMUP, EVENTID_TEAM_PLATFORM_CLEAR_CACHE_LIST, self.OnClearCacheData, self)
end

local function getGap(team)
  local total = tonumber(team.team_size) or 0
  local cur = 0
  for _, info in pairs(team.members or {}) do
    if info.uid then
      cur = cur + 1
    end
  end
  return math.max(total - cur, 0)
end

function logic_filter_team_info:OnRefreshMyTeamInfo()
  log(bWriteLog and "logic_filter_team_info:OnRefreshMyTeamInfo")
  local newTeamList = {}
  local myTeamID
  local isInChat = UIManager.IsUIShow(UIManager.UI_Config.ui_chat_main)
  if isInChat then
    local myTeamData = self:GetMyTeamData()
    myTeamID = myTeamData and myTeamData.id or nil
    if myTeamData then
      table.insert(newTeamList, myTeamData)
    end
  end
  for _, v in ipairs(self.realShowTeamList) do
    if v.id ~= myTeamID then
      table.insert(newTeamList, v)
    end
  end
  if isInChat then
    EventSystem:postEvent(EVENTTYPE_TEAMUP, EVENTID_TEAM_PLATFORM_LIST_DATA_READY, newTeamList)
  end
  EventSystem:postEvent(EVENTTYPE_TEAMUP, EVENTID_TEAM_PLATFORM_MY_TEAM_INFO_CHANGE)
end

function logic_filter_team_info:OpenGM()
  isOpenGM = not isOpenGM
end

function logic_filter_team_info:CheckIsGM()
  return isOpenGM
end

function logic_filter_team_info:GetMaxTeamNum()
  local TeamUpNewSystem = require("client.slua.logic.teamup.logic_team_up")
  local defaultTeamMaxNum = TeamUpNewSystem.GetDefaultMaxTeamNum()
  local teamMaxNum = defaultTeamMaxNum
  if self.option then
    teamMaxNum = self.option.nPlayerNum
  end
  return teamMaxNum
end

function logic_filter_team_info:CheckCanShowRecruit()
  local TeamPlatformSystem = require("client.slua.logic.teamup.logic_team_platform")
  local recruitInfo = TeamPlatformSystem.GetRecruitInfo()
  if not recruitInfo then
    return false, nil
  end
  local conscribe = recruitInfo.conscribe
  local hasRecruit = conscribe ~= nil and conscribe.view ~= C_WOWViewId
  printf("logic_filter_team_info:CheckCanShowRecruit hasRecruit:%s", tostring(hasRecruit))
  if hasRecruit then
    local tabID = conscribe.tab_id
    local logic_team_platform_new = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_team_platform_new)
    local isPeakRecruit = logic_team_platform_new:IsPeakTabID(tabID)
    local isInChat = UIManager.IsUIShow(UIManager.UI_Config.ui_chat_main)
    printf("logic_filter_team_info:CheckCanShowRecruit isPeakRecruit:%s isInChat:%s", tostring(isPeakRecruit), tostring(isInChat))
    if isInChat then
      local logic_chat_recruit_msg = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_chat_recruit_msg)
      local SelectTeamRecruitTabId = logic_chat_recruit_msg:GetSelectTeamRecruitTabId()
      local TeamPlatform_Macro = require("client.slua.logic.teamup.teamplatform_macro")
      local ChannelTab = TeamPlatform_Macro.ChannelTab
      if SelectTeamRecruitTabId == ChannelTab.Classic then
        hasRecruit = true
      elseif SelectTeamRecruitTabId == ChannelTab.Peak then
        hasRecruit = isPeakRecruit
      else
        hasRecruit = false
      end
    else
      local isPeakPlatform = logic_team_platform_new:IsInPeakPlatform()
      if isPeakPlatform and not isPeakRecruit then
        hasRecruit = false
      end
    end
  end
  return hasRecruit, conscribe
end

function logic_filter_team_info:GetMyTeamData()
  local hasRecruit, conscribe = self:CheckCanShowRecruit()
  if not hasRecruit then
    log_tree("logic_filter_team_info:GetMyTeamData no recruit")
    return nil
  end
  local TableUtil = require("common.table_util")
  local ConscribeCopy = TableUtil.CopyTable(conscribe)
  ConscribeCopy.lang = ConscribeCopy.first_match_lang
  local myTeamData = ConscribeCopy
  myTeamData.id = ConscribeCopy.team_id
  local logic_lobby_my_team = require("client.slua.logic.teamup.logic_lobby_my_team")
  local teamMember = logic_lobby_my_team.GetTeamMember()
  if not teamMember or teamMember and #teamMember == 0 then
    local TeamUpNewSystem = require("client.slua.logic.teamup.logic_team_up")
    TeamUpNewSystem.team_info_request()
    return nil
  end
  printf("logic_filter_team_info:GetMyTeamData memberNum:%s", tostring(#teamMember))
  local teamMemberList = {}
  myTeamData.members = teamMemberList
  if myTeamData.team_size > 4 then
    for k = 1, 8 do
      if teamMember[k] then
        teamMemberList[k] = teamMember[k]
      else
        teamMemberList[k] = {}
      end
    end
  else
    for k = 1, myTeamData.team_size do
      if teamMember[k] then
        teamMemberList[k] = teamMember[k]
      else
        teamMemberList[k] = {}
      end
    end
  end
  return myTeamData
end

function logic_filter_team_info:OnRefreshSearchList(_, __, data, isSearch, isCacheData)
  log("logic_filter_team_info:OnRefreshSearchList isSearch:" .. tostring(isSearch))
  log_tree("logic_filter_team_info:OnRefreshSearchList", data)
  if self.showTips and isSearch then
    self.showTips = nil
    ShowNotice(62399)
  end
  self.AllTeamList = data or {}
  local logic_team_platform_new = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_team_platform_new)
  self.filterOption = logic_team_platform_new:GetCurFilterOption()
  self:UpdateTeamListUI()
  EventSystem:postEvent(EVENTTYPE_TEAMUP, EVENTID_TEAM_PLATFORM_BEGIN_SEARCH_TEAM, false)
end

function logic_filter_team_info:UpdateTeamListUI()
  local newTeamList = {}
  for _, v in ipairs(self.AllTeamList) do
    local gap = getGap(v)
    if v.id and 0 < gap then
      if not self.teamFailedList[v.id] then
        table.insert(newTeamList, v)
      else
        log(bWriteLog and "logic_filter_team_info:UpdateTeamListUI self.teamFailedList[v.id]", v.id)
      end
    else
      log(bWriteLog and "logic_filter_team_info:UpdateTeamListUI team_size", v.id)
    end
  end
  self:SortTeamList(newTeamList)
  self.realShowTeamList = {}
  local showTeamList = {}
  log(bWriteLog and "logic_filter_team_info:UpdateTeamListUI self.AllTeamList", #self.AllTeamList, #newTeamList)
  local isInChat = UIManager.IsUIShow(UIManager.UI_Config.ui_chat_main)
  local myTeamData = isInChat and self:GetMyTeamData() or nil
  local myTeamID = myTeamData and myTeamData.id or nil
  local teamNum = math.min(isInChat and MAX_SHOW_TEAM_NUM + 1 or MAX_SHOW_TEAM_NUM, #newTeamList)
  for i = 1, teamNum do
    local team = newTeamList[i]
    if team.id ~= myTeamID then
      table.insert(self.realShowTeamList, team)
      table.insert(showTeamList, team)
    end
  end
  if myTeamData then
    table.insert(showTeamList, 1, myTeamData)
    if isOpenGM then
      for i = 1, 10 do
        table.insert(showTeamList, myTeamData)
      end
    end
  end
  log(bWriteLog and "logic_filter_team_info:UpdateTeamListUI #showTeamList", #showTeamList)
  EventSystem:postEvent(EVENTTYPE_TEAMUP, EVENTID_TEAM_PLATFORM_LIST_DATA_READY, showTeamList)
end

function logic_filter_team_info:OnJoinTeamFail(_, __, teamID)
  printf("logic_filter_team_info:OnJoinTeamFail teamID:%s", teamID)
  if not teamID then
    return
  end
  self.teamFailedList[teamID] = true
  self:UpdateTeamListUI()
end

function logic_filter_team_info:OnClearCacheData()
  log("logic_filter_team_info:OnClearCacheData")
  self.AllTeamList = {}
  self:UpdateTeamListUI()
end

function logic_filter_team_info:SortTeamList(newTeamList)
  if not newTeamList or #newTeamList == 0 then
    return
  end
  local logic_team_platform_new = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_team_platform_new)
  self.filterOption = logic_team_platform_new:GetCurFilterOption()
  local filter = self.filterOption
  local hasSelectFilterMap = filter.modeInfo and 0 < #filter.modeInfo
  local myZone = logic_team_platform_new:GetZoneID() or 0
  if not hasSelectFilterMap then
    table.sort(newTeamList, function(a, b)
      return (a.create_time or 0) > (b.create_time or 0)
    end)
  else
    table.sort(newTeamList, function(a, b)
      local gapA, gapB = getGap(a), getGap(b)
      if gapA ~= gapB then
        return gapA < gapB
      end
      local timeA, timeB = a.create_time or 0, b.create_time or 0
      if timeA ~= timeB then
        return timeA > timeB
      end
      local matchA = a.zone == myZone and 1 or 0
      local matchB = b.zone == myZone and 1 or 0
      return matchA > matchB
    end)
  end
end

function logic_filter_team_info:RemoveIdleTimer()
  if self.idleTimer then
    self:RemoveTimer(self.idleTimer)
    self.idleTimer = nil
  end
end

function logic_filter_team_info:UpdateCurCircleType()
  self.curCircleIndex = self.curCircleIndex + 1
  if self.curCircleIndex > Enum_CircleType.BatchSearchTimeAgain then
    self.curCircleIndex = Enum_CircleType.SearchTime
  end
end

function logic_filter_team_info:AddAutoReqTimer()
  log(bWriteLog and "logic_filter_team_info:AddAutoReqTimer")
  self:RemoveIdleTimer()
  self.curCircleIndex = Enum_CircleType.SearchTime
  local TeamPlatformSystem = require("client.slua.logic.teamup.logic_team_platform")
  local TimeUtil = require("client.common.time_util")
  self.idleTimer = self:AddTimer(0, function()
    while true do
      local now = TimeUtil.GetServerTimeInSec()
      local passTime = now - self.nLastBatchSearchTeamTime
      if passTime < 0 then
        printf("logic_filter_team_info:AddAutoReqTimer server time rollback, reset self timer, passTime:%s", tostring(passTime))
        self.nLastBatchSearchTeamTime = now
        passTime = 0
      end
      if self.curCircleIndex == Enum_CircleType.SearchTime then
        local reqPassTime = now - TeamPlatformSystem.nLastSearchTeamTime
        if reqPassTime < 0 then
          printf("logic_filter_team_info:AddAutoReqTimer server time rollback, reset search timer, reqPassTime:%s", tostring(reqPassTime))
          TeamPlatformSystem.nLastSearchTeamTime = now
          reqPassTime = 0
        end
        if passTime >= CONST_REQUEST_INTERVAL_TIME and reqPassTime >= CONST_REQUEST_INTERVAL_TIME then
          log(bWriteLog and "logic_filter_team_info:AddAutoReqTimer SearchTeamReal")
          self:SearchTeamReal(0)
          self:UpdateCurCircleType()
          self.nLastBatchSearchTeamTime = now
        end
      elseif passTime >= CONST_REQUEST_INTERVAL_TIME then
        log(bWriteLog and "logic_filter_team_info:AddAutoReqTimer RefreshListReq")
        self:RefreshListReq()
      end
      coroutine.yield(1.1)
    end
  end)
end

function logic_filter_team_info:RefreshListReq()
  log(bWriteLog and "logic_filter_team_info:RefreshListReq")
  if not self.AllTeamList or #self.AllTeamList <= 0 then
    self.curCircleIndex = Enum_CircleType.SearchTime
    return
  end
  local teamIDList = {}
  for _, v in ipairs(self.AllTeamList) do
    table.insert(teamIDList, v.id)
  end
  if #teamIDList == 0 then
    return
  end
  local TimeUtil = require("client.common.time_util")
  self.nLastBatchSearchTeamTime = TimeUtil.GetServerTimeInSec()
  local ConscribeHandler = require("client.network.Protocol.ConscribeHandler")
  ConscribeHandler.send_batch_get_team_conscribes_req(teamIDList)
  self:UpdateCurCircleType()
end

function logic_filter_team_info:SearchTeamReal(reason, isUseCache, showTips)
  log(bWriteLog and "logic_filter_team_info:SearchTeamReal", reason, isUseCache, showTips)
  if LobbySystem.isInMatch then
    ShowNotice(110017)
    return false
  end
  self.showTips = showTips
  local TeamPlatformSystem = require("client.slua.logic.teamup.logic_team_platform")
  TeamPlatformSystem.SearchTeam(reason, isUseCache)
  EventSystem:postEvent(EVENTTYPE_TEAMUP, EVENTID_TEAM_PLATFORM_BEGIN_SEARCH_TEAM, true)
  return true
end

local class = require("class")
local CModuleBase = require("client.module_framework.ModuleBase")
local Clogic_filter_team_info = class(CModuleBase, nil, logic_filter_team_info)
return Clogic_filter_team_info
