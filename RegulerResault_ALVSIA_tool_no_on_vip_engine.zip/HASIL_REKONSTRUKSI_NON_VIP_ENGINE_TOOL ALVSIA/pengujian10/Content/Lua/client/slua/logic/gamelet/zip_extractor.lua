local zip_extractor = {}
local sbyte = string.byte
local schar = string.char
local ssub = string.sub
local sformat = string.format
local tconcat = table.concat
local tunpack = table.unpack or unpack
local tmove = table.move
tmove = tmove or function(a1, f, e, t)
  for i = 0, e - f do
    a1[t + i] = a1[f + i]
  end
  return a1
end
local MAXBITS = 15
local LOOKUP_BITS = 10
local LOOKUP_SIZE = 1 << LOOKUP_BITS
local LOOKUP_MASK = LOOKUP_SIZE - 1
local REVERSE8 = {}
for i = 0, 255 do
  local r, v = 0, i
  for _ = 1, 8 do
    r = r << 1 | v & 1
    v = v >> 1
  end
  REVERSE8[i] = r
end

local function reverse_bits(value, bits)
  local r = REVERSE8[value & 255] << 8 | REVERSE8[value >> 8 & 255]
  return r >> 16 - bits
end

local WINDOW_SIZE = 32768
local FLUSH_SIZE = 262144
local FLUSH_LIMIT = FLUSH_SIZE + WINDOW_SIZE
local SIG_LOCAL = 67324752
local SIG_CENTRAL = 33639248
local SIG_EOCD = 101010256
local METHOD_STORED = 0
local METHOD_DEFLATE = 8
local LENBASE = {
  3,
  4,
  5,
  6,
  7,
  8,
  9,
  10,
  11,
  13,
  15,
  17,
  19,
  23,
  27,
  31,
  35,
  43,
  51,
  59,
  67,
  83,
  99,
  115,
  131,
  163,
  195,
  227,
  258
}
local LENEXTRA = {
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  0
}
local DISTBASE = {
  1,
  2,
  3,
  4,
  5,
  7,
  9,
  13,
  17,
  25,
  33,
  49,
  65,
  97,
  129,
  193,
  257,
  385,
  513,
  769,
  1025,
  1537,
  2049,
  3073,
  4097,
  6145,
  8193,
  12289,
  16385,
  24577
}
local DISTEXTRA = {
  0,
  0,
  0,
  0,
  1,
  1,
  2,
  2,
  3,
  3,
  4,
  4,
  5,
  5,
  6,
  6,
  7,
  7,
  8,
  8,
  9,
  9,
  10,
  10,
  11,
  11,
  12,
  12,
  13,
  13
}
local CLCIDX = {
  16,
  17,
  18,
  0,
  8,
  7,
  9,
  6,
  10,
  5,
  11,
  4,
  12,
  3,
  13,
  2,
  14,
  1,
  15
}

local function logf(fmt, ...)
  local ok, msg = pcall(sformat, fmt, ...)
  if not ok then
    msg = tostring(fmt)
  end
  if _G.log_format then
    _G.log_format(msg)
  else
    print(msg)
  end
end

local function u16(data, p)
  return sbyte(data, p) | sbyte(data, p + 1) << 8
end

local function u32(data, p)
  return sbyte(data, p) | sbyte(data, p + 1) << 8 | sbyte(data, p + 2) << 16 | sbyte(data, p + 3) << 24
end

local function bytes_to_string(bytes, from, to)
  local chunks = {}
  local chunkCount = 0
  local step = 4096
  local i = from
  while to >= i do
    local j = i + step - 1
    if to < j then
      j = to
    end
    chunkCount = chunkCount + 1
    chunks[chunkCount] = schar(tunpack(bytes, i, j))
    i = j + 1
  end
  return tconcat(chunks)
end

local function build_huffman(lengths, n)
  local count = {}
  for i = 0, MAXBITS do
    count[i] = 0
  end
  for i = 1, n do
    local l = lengths[i] or 0
    count[l] = count[l] + 1
  end
  local left = 1
  for len = 1, MAXBITS do
    left = (left << 1) - count[len]
    if left < 0 then
      return nil, "over-subscribed huffman code"
    end
  end
  local offs = {}
  offs[1] = 0
  for len = 1, MAXBITS - 1 do
    offs[len + 1] = offs[len] + count[len]
  end
  local symbol = {}
  for i = 1, n do
    local l = lengths[i] or 0
    if l ~= 0 then
      symbol[offs[l]] = i - 1
      offs[l] = offs[l] + 1
    end
  end
  local fast = {}
  local code, index = 0, 0
  for len = 1, LOOKUP_BITS do
    local cnt = count[len]
    for _ = 1, cnt do
      local sym = symbol[index]
      index = index + 1
      local rc = reverse_bits(code, len)
      local entry = sym << 4 | len
      for v = rc, LOOKUP_MASK, 1 << len do
        fast[v] = entry
      end
      code = code + 1
    end
    code = code << 1
  end
  return {
    count = count,
    symbol = symbol,
    fast = fast
  }
end

local FIXED_LIT, FIXED_DIST

local function get_fixed_tables()
  if not FIXED_LIT then
    local litLens = {}
    for i = 1, 144 do
      litLens[i] = 8
    end
    for i = 145, 256 do
      litLens[i] = 9
    end
    for i = 257, 280 do
      litLens[i] = 7
    end
    for i = 281, 288 do
      litLens[i] = 8
    end
    FIXED_LIT = build_huffman(litLens, 288)
    local distLens = {}
    for i = 1, 30 do
      distLens[i] = 5
    end
    FIXED_DIST = build_huffman(distLens, 30)
  end
  return FIXED_LIT, FIXED_DIST
end

local function inflate(data, startPos, yieldStep, sink, stepRef)
  local dataLen = #data
  local pos = startPos
  local bitbuf, bitcnt = 0, 0
  local out = {}
  local outlen = 0
  local flushedTotal = 0
  local sinceYield = 0
  
  local function getbits(need)
    if need == 0 then
      return 0
    end
    while need > bitcnt do
      if pos > dataLen then
        error("inflate: unexpected end of stream", 0)
      end
      bitbuf = bitbuf | sbyte(data, pos) << bitcnt
      pos = pos + 1
      bitcnt = bitcnt + 8
    end
    local v = bitbuf & (1 << need) - 1
    bitbuf = bitbuf >> need
    bitcnt = bitcnt - need
    return v
  end
  
  local function decode(h)
    while bitcnt < LOOKUP_BITS and pos <= dataLen do
      bitbuf = bitbuf | sbyte(data, pos) << bitcnt
      pos = pos + 1
      bitcnt = bitcnt + 8
    end
    local entry = h.fast[bitbuf & LOOKUP_MASK]
    if entry then
      local l = entry & 15
      if l <= bitcnt then
        bitbuf = bitbuf >> l
        bitcnt = bitcnt - l
        return entry >> 4
      end
    end
    local count, symbol = h.count, h.symbol
    local code, first, index = 0, 0, 0
    for len = 1, MAXBITS do
      if bitcnt < 1 then
        if pos > dataLen then
          error("inflate: unexpected end of stream", 0)
        end
        bitbuf = bitbuf | sbyte(data, pos) << bitcnt
        pos = pos + 1
        bitcnt = bitcnt + 8
      end
      code = code | bitbuf & 1
      bitbuf = bitbuf >> 1
      bitcnt = bitcnt - 1
      local cnt = count[len]
      if first > code - cnt then
        return symbol[index + (code - first)]
      end
      index = index + cnt
      first = first + cnt << 1
      code = code << 1
    end
    return nil
  end
  
  local function flush_if_needed()
    if outlen <= FLUSH_SIZE + WINDOW_SIZE then
      return
    end
    local keepFrom = outlen - WINDOW_SIZE + 1
    sink(bytes_to_string(out, 1, keepFrom - 1))
    flushedTotal = flushedTotal + keepFrom - 1
    local newOut = {}
    for i = 1, WINDOW_SIZE do
      newOut[i] = out[keepFrom + i - 1]
    end
    out = newOut
    outlen = WINDOW_SIZE
  end
  
  local function run_codes(litTable, distTable)
    while true do
      local sym = decode(litTable)
      if sym == nil then
        error("inflate: invalid literal/length code", 0)
      end
      if sym < 256 then
        outlen = outlen + 1
        out[outlen] = sym
      elseif sym == 256 then
        return
      else
        local idx = sym - 256
        if 29 < idx then
          error("inflate: invalid length code", 0)
        end
        local len = LENBASE[idx] + getbits(LENEXTRA[idx])
        local dsym = decode(distTable)
        if dsym == nil or 29 < dsym then
          error("inflate: invalid distance code", 0)
        end
        local dist = DISTBASE[dsym + 1] + getbits(DISTEXTRA[dsym + 1])
        if dist > outlen then
          error("inflate: distance too far back", 0)
        end
        local src = outlen - dist
        if len <= dist then
          tmove(out, src + 1, src + len, outlen + 1)
        else
          for i = 1, len do
            out[outlen + i] = out[src + i]
          end
        end
        outlen = outlen + len
      end
      if outlen > FLUSH_LIMIT then
        flush_if_needed()
      end
      if yieldStep then
        sinceYield = sinceYield + 1
        if sinceYield >= yieldStep then
          sinceYield = 0
          coroutine.yield()
          if stepRef then
            yieldStep = stepRef.value or yieldStep
          end
        end
      end
    end
  end
  
  local function read_dynamic_tables()
    local nlen = getbits(5) + 257
    local ndist = getbits(5) + 1
    local ncode = getbits(4) + 4
    if 286 < nlen or 30 < ndist then
      error("inflate: too many length or distance codes", 0)
    end
    local clcLens = {}
    for i = 1, 19 do
      clcLens[i] = 0
    end
    for i = 1, ncode do
      clcLens[CLCIDX[i] + 1] = getbits(3)
    end
    local clcTable, err = build_huffman(clcLens, 19)
    if not clcTable then
      error("inflate: " .. tostring(err), 0)
    end
    local total = nlen + ndist
    local allLens = {}
    local index = 0
    while total > index do
      local sym = decode(clcTable)
      if sym == nil then
        error("inflate: invalid code length code", 0)
      end
      if sym < 16 then
        index = index + 1
        allLens[index] = sym
      else
        local prevLen, repeatCnt = 0, 0
        if sym == 16 then
          if index == 0 then
            error("inflate: repeat with no previous length", 0)
          end
          prevLen = allLens[index]
          repeatCnt = 3 + getbits(2)
        elseif sym == 17 then
          repeatCnt = 3 + getbits(3)
        else
          repeatCnt = 11 + getbits(7)
        end
        if total < index + repeatCnt then
          error("inflate: too many lengths", 0)
        end
        for _ = 1, repeatCnt do
          index = index + 1
          allLens[index] = prevLen
        end
      end
    end
    local litLens = {}
    for i = 1, nlen do
      litLens[i] = allLens[i]
    end
    local distLens = {}
    for i = 1, ndist do
      distLens[i] = allLens[nlen + i]
    end
    local litTable, litErr = build_huffman(litLens, nlen)
    if not litTable then
      error("inflate: literal table, " .. tostring(litErr), 0)
    end
    local distTable, distErr = build_huffman(distLens, ndist)
    if not distTable then
      error("inflate: distance table, " .. tostring(distErr), 0)
    end
    return litTable, distTable
  end
  
  local function read_stored()
    bitbuf, bitcnt = 0, 0
    if pos + 3 > dataLen then
      error("inflate: incomplete stored block header", 0)
    end
    local len = u16(data, pos)
    local nlen = u16(data, pos + 2)
    if len ~ 65535 ~= nlen then
      error("inflate: stored block length mismatch", 0)
    end
    pos = pos + 4
    if pos + len - 1 > dataLen then
      error("inflate: incomplete stored block data", 0)
    end
    for i = 0, len - 1 do
      out[outlen + 1 + i] = sbyte(data, pos + i)
    end
    outlen = outlen + len
    pos = pos + len
    if outlen > FLUSH_LIMIT then
      flush_if_needed()
    end
  end
  
  local function main()
    local last
    repeat
      last = getbits(1)
      local btype = getbits(2)
      if btype == 0 then
        read_stored()
      elseif btype == 1 then
        local litTable, distTable = get_fixed_tables()
        run_codes(litTable, distTable)
      elseif btype == 2 then
        local litTable, distTable = read_dynamic_tables()
        run_codes(litTable, distTable)
      else
        error("inflate: invalid block type 3", 0)
      end
      if yieldStep then
        coroutine.yield()
      end
    until last == 1
    if 0 < outlen then
      sink(bytes_to_string(out, 1, outlen))
      flushedTotal = flushedTotal + outlen
      out = {}
      outlen = 0
    end
  end
  
  if yieldStep then
    main()
    return flushedTotal
  end
  local ok, err = pcall(main)
  if not ok then
    return nil, tostring(err)
  end
  return flushedTotal
end

local function find_eocd(data)
  local len = #data
  if len < 22 then
    return nil
  end
  local minPos = len - 65557
  if minPos < 1 then
    minPos = 1
  end
  for i = len - 21, minPos, -1 do
    if sbyte(data, i) == 80 and sbyte(data, i + 1) == 75 and sbyte(data, i + 2) == 5 and sbyte(data, i + 3) == 6 then
      return i
    end
  end
  return nil
end

local function parse_entries(data)
  local eocd = find_eocd(data)
  if not eocd then
    return nil, "end of central directory not found (not a zip file?)"
  end
  local total = u16(data, eocd + 10)
  local cdOffset = u32(data, eocd + 16)
  local pos = cdOffset + 1
  local dataLen = #data
  local entries = {}
  for _ = 1, total do
    if dataLen < pos + 45 then
      return nil, "central directory truncated"
    end
    if u32(data, pos) ~= SIG_CENTRAL then
      return nil, "bad central directory signature"
    end
    local nameLen = u16(data, pos + 28)
    local extraLen = u16(data, pos + 30)
    local commentLen = u16(data, pos + 32)
    entries[#entries + 1] = {
      name = ssub(data, pos + 46, pos + 46 + nameLen - 1),
      method = u16(data, pos + 10),
      crc32 = u32(data, pos + 16),
      compSize = u32(data, pos + 20),
      uncompSize = u32(data, pos + 24),
      localOffset = u32(data, pos + 42)
    }
    pos = pos + 46 + nameLen + extraLen + commentLen
  end
  return entries
end

local function locate_entry_data(data, entry)
  local pos = entry.localOffset + 1
  if pos + 29 > #data then
    return nil, "local header truncated"
  end
  if u32(data, pos) ~= SIG_LOCAL then
    return nil, "bad local header signature"
  end
  local nameLen = u16(data, pos + 26)
  local extraLen = u16(data, pos + 28)
  return pos + 30 + nameLen + extraLen
end

local function is_absolute(path)
  return path:sub(1, 1) == "/" or path:match("^%a:/") ~= nil
end

local function get_business_helper()
  if not _G.import then
    return nil
  end
  local ok, helper = pcall(_G.import, "BusinessHelper")
  if ok and helper and helper.GetMobileBasePath then
    return helper
  end
  return nil
end

local function to_physical_dir(dirPath)
  if not dirPath or dirPath == "" then
    return nil
  end
  local normalized = dirPath:gsub("\\", "/"):gsub("/+$", "")
  local helper = get_business_helper()
  if not helper then
    return normalized .. "/"
  end
  local dir = helper.GetMobileBasePath(normalized)
  if not (not is_absolute(normalized) and dir) or dir == "" then
    return normalized .. "/"
  end
  return dir:gsub("/+$", "") .. "/"
end

local function to_physical_path(path)
  if not path or path == "" then
    return nil
  end
  local normalized = path:gsub("\\", "/")
  if is_absolute(normalized) then
    return normalized
  end
  local parent, name = normalized:match("^(.*)/([^/]+)$")
  if not parent then
    return normalized
  end
  local dir = to_physical_dir(parent)
  if not dir then
    return normalized
  end
  return dir .. name
end

local function ensure_dir_exists(physDir)
  local helper = get_business_helper()
  if helper then
    helper.GetMobileBasePath(physDir)
  end
end

local function read_file(path)
  local physPath = to_physical_path(path)
  local f = io.open(physPath, "rb")
  if not f then
    return nil, sformat("cannot open %s (physical: %s)", tostring(path), tostring(physPath))
  end
  local data = f:read("*a")
  f:close()
  if not data then
    return nil, "read failed " .. tostring(physPath)
  end
  return data
end

local function open_dest(physPath)
  local f = io.open(physPath, "wb")
  if not f then
    local parent = physPath:match("^(.*)/[^/]+$")
    if parent then
      ensure_dir_exists(parent)
      f = io.open(physPath, "wb")
    end
  end
  return f
end

local function name_token(name)
  local h = 5381
  for i = 1, #name do
    h = (h * 33 + sbyte(name, i)) % 4294967296
  end
  return sformat("%08x", h)
end

local function tmp_path_of(physPath)
  local dir, base = physPath:match("^(.*/)([^/]+)$")
  if not dir then
    return "." .. name_token(physPath) .. ".tmp"
  end
  return dir .. "." .. name_token(base) .. ".tmp"
end

local function extract_entry_to_file(data, entry, physPath, yieldStep, stepRef)
  local dataPos, err = locate_entry_data(data, entry)
  if not dataPos then
    return nil, err
  end
  if entry.method ~= METHOD_STORED and entry.method ~= METHOD_DEFLATE then
    return nil, sformat("unsupported compression method %d", entry.method)
  end
  local tmpPath = tmp_path_of(physPath)
  local f = open_dest(tmpPath)
  if not f then
    return nil, sformat("cannot write %s (dir may not exist; creating dirs needs BusinessHelper)", tostring(tmpPath))
  end
  local written = 0
  if entry.method == METHOD_STORED then
    local endPos = dataPos + entry.compSize - 1
    if endPos > #data then
      f:close()
      os.remove(tmpPath)
      return nil, "stored entry data truncated"
    end
    local p = dataPos
    while endPos >= p do
      local q = p + FLUSH_SIZE - 1
      if endPos < q then
        q = endPos
      end
      f:write(ssub(data, p, q))
      written = written + q - p + 1
      p = q + 1
      if yieldStep then
        coroutine.yield()
      end
    end
  else
    local total, inflateErr = inflate(data, dataPos, yieldStep, function(chunk)
      f:write(chunk)
    end, stepRef)
    if not total then
      f:close()
      os.remove(tmpPath)
      return nil, inflateErr
    end
    written = total
  end
  local closed = f:close()
  if 0 < entry.uncompSize and written ~= entry.uncompSize then
    os.remove(tmpPath)
    return nil, sformat("size mismatch, expect %d got %d", entry.uncompSize, written)
  end
  if closed ~= true then
    os.remove(tmpPath)
    return nil, "close failed, data may be incomplete"
  end
  local moved, moveErr = os.rename(tmpPath, physPath)
  if not moved then
    os.remove(tmpPath)
    return nil, sformat("rename %s -> %s failed: %s", tostring(tmpPath), tostring(physPath), tostring(moveErr))
  end
  return written
end

local function is_dir_entry(entry)
  return entry.name == "" or entry.name:sub(-1) == "/" or entry.name:sub(-1) == "\\"
end

local function basename_of(name)
  return name:match("([^/\\]+)$") or name
end

local function make_dest_resolver(destDirRaw, flatten)
  local raw = destDirRaw:gsub("\\", "/"):gsub("/+$", "") .. "/"
  local physBase = to_physical_dir(raw)
  if not physBase then
    return nil
  end
  local subdirCache = {}
  return function(entry)
    local name = entry.name:gsub("\\", "/")
    if flatten then
      return physBase .. basename_of(name)
    end
    local subdir = name:match("^(.*)/[^/]+$")
    if not subdir or subdir == "" then
      return physBase .. name
    end
    local physSub = subdirCache[subdir]
    if not physSub then
      physSub = to_physical_dir(raw .. subdir)
      if not physSub then
        return nil
      end
      subdirCache[subdir] = physSub
    end
    return physSub .. basename_of(name)
  end, physBase
end

local function to_name_set(list)
  if not list then
    return nil
  end
  local set = {}
  for _, v in ipairs(list) do
    set[v] = true
  end
  return set
end

local function name_in_set(set, entry)
  if set[entry.name] then
    return true, entry.name
  end
  local base = basename_of(entry.name)
  if set[base] then
    return true, base
  end
  return false
end

local function make_filter(options)
  if type(options.filter) == "function" then
    return options.filter
  end
  
  local function make_set_filter(list, isInclude)
    local set = to_name_set(list)
    local matched = {}
    
    local function predicate(entry)
      local hit, key = name_in_set(set, entry)
      if hit then
        matched[key] = true
      end
      if isInclude then
        return hit
      end
      return not hit
    end
    
    local function warnUnmatched()
      for _, v in ipairs(list) do
        if not matched[v] then
          logf("zip_extractor: WARNING %s entry %q matched nothing in this zip, check the name", isInclude and "include" or "exclude", tostring(v))
        end
      end
    end
    
    return predicate, warnUnmatched
  end
  
  if options.include then
    return make_set_filter(options.include, true)
  end
  if options.exclude then
    return make_set_filter(options.exclude, false)
  end
  return nil
end

function zip_extractor.List(zipPath)
  local data, err = read_file(zipPath)
  if not data then
    return nil, err
  end
  return parse_entries(data)
end

function zip_extractor.ToPhysicalPath(path)
  return to_physical_path(path)
end

function zip_extractor.ToPhysicalDir(dirPath)
  return to_physical_dir(dirPath)
end

function zip_extractor.RemoveTempFor(physPath)
  if not physPath or physPath == "" then
    return false
  end
  local tmpPath = tmp_path_of(physPath)
  local f = io.open(tmpPath, "rb")
  if not f then
    return false
  end
  f:close()
  local ok = os.remove(tmpPath)
  logf("zip_extractor: removed leftover temp %s, ok=%s", tmpPath, tostring(ok))
  return ok == true
end

function zip_extractor.ExtractOne(zipPath, entryName, destPath)
  local data, err = read_file(zipPath)
  if not data then
    return false, err
  end
  local entries, parseErr = parse_entries(data)
  if not entries then
    return false, parseErr
  end
  local target
  for _, entry in ipairs(entries) do
    if entry.name == entryName or entry.name:match("([^/\\]+)$") == entryName then
      target = entry
      break
    end
  end
  if not target then
    return false, "entry not found: " .. tostring(entryName)
  end
  local physDest = to_physical_path(destPath)
  if not physDest then
    return false, "invalid destPath"
  end
  local written, decErr = extract_entry_to_file(data, target, physDest)
  if not written then
    return false, decErr
  end
  return true
end

local function select_entries(entries, filter, smallestFirst)
  local kept, skippedCount, savedBytes = {}, 0, 0
  for _, entry in ipairs(entries) do
    if not is_dir_entry(entry) then
      if filter and not filter(entry) then
        skippedCount = skippedCount + 1
        savedBytes = savedBytes + entry.uncompSize
        logf("zip_extractor: filtered out %s (%d bytes, saved)", entry.name, entry.uncompSize)
      else
        kept[#kept + 1] = entry
      end
    end
  end
  if smallestFirst ~= false then
    table.sort(kept, function(a, b)
      if a.uncompSize ~= b.uncompSize then
        return a.uncompSize < b.uncompSize
      end
      return tostring(a.name) < tostring(b.name)
    end)
  end
  return kept, skippedCount, savedBytes
end

function zip_extractor.ExtractAll(zipPath, destDir, options)
  options = options or {}
  local startClock = os.clock()
  local data, err = read_file(zipPath)
  if not data then
    return 0, 0, err
  end
  local entries, parseErr = parse_entries(data)
  if not entries then
    return 0, 0, parseErr
  end
  local resolveDest, physBase = make_dest_resolver(destDir, options.flatten)
  if not resolveDest then
    return 0, 0, "invalid destDir"
  end
  logf("zip_extractor: ExtractAll destDir(physical)=%s", tostring(physBase))
  local filter, warnUnmatched = make_filter(options)
  local okCount, totalCount = 0, 0
  local targets, skippedCount = select_entries(entries, filter, options.smallestFirst)
  for _, entry in ipairs(targets) do
    totalCount = totalCount + 1
    local destPath = resolveDest(entry)
    local skip = false
    if not destPath then
      skip = true
      logf("zip_extractor: cannot resolve dest dir for %s", entry.name)
    elseif options.skipExisting then
      local exist = io.open(destPath, "rb")
      if exist then
        exist:close()
        skip = true
        okCount = okCount + 1
        logf("zip_extractor: skip existing %s (%d bytes)", entry.name, entry.uncompSize)
      end
    end
    if not skip then
      local written, decErr = extract_entry_to_file(data, entry, destPath)
      if written then
        okCount = okCount + 1
        logf("zip_extractor: extracted %s -> %s (%d bytes)", entry.name, destPath, written)
      else
        logf("zip_extractor: extract failed %s, err=%s", entry.name, tostring(decErr))
      end
    end
  end
  if warnUnmatched then
    warnUnmatched()
  end
  logf("zip_extractor: ExtractAll done, zip=%s, ok=%d/%d, filtered=%d, cost=%.2fs", tostring(zipPath), okCount, totalCount, skippedCount, os.clock() - startClock)
  return okCount, totalCount
end

function zip_extractor.ExtractAllAsync(zipPath, destDir, options, onFinish)
  options = options or {}
  local yieldStep = options.yieldStep or 2000
  local stepRef = {value = yieldStep}
  local co = coroutine.create(function()
    local startClock = os.clock()
    local data, err = read_file(zipPath)
    if not data then
      return 0, 0, err
    end
    coroutine.yield()
    local entries, parseErr = parse_entries(data)
    if not entries then
      return 0, 0, parseErr
    end
    coroutine.yield()
    local resolveDest, physBase = make_dest_resolver(destDir, options.flatten)
    if not resolveDest then
      return 0, 0, "invalid destDir"
    end
    logf("zip_extractor: ExtractAllAsync destDir(physical)=%s", tostring(physBase))
    local filter, warnUnmatched = make_filter(options)
    local okCount, totalCount = 0, 0
    local targets, skippedCount, savedBytes = select_entries(entries, filter, options.smallestFirst)
    coroutine.yield()
    for _, entry in ipairs(targets) do
      totalCount = totalCount + 1
      local destPath = resolveDest(entry)
      local skip = false
      if not destPath then
        skip = true
        logf("zip_extractor: cannot resolve dest dir for %s", entry.name)
      elseif options.skipExisting then
        local exist = io.open(destPath, "rb")
        if exist then
          exist:close()
          skip = true
          okCount = okCount + 1
          logf("zip_extractor: skip existing %s (%d bytes)", entry.name, entry.uncompSize)
        end
      end
      if not skip then
        local written, decErr = extract_entry_to_file(data, entry, destPath, stepRef.value, stepRef)
        if written then
          okCount = okCount + 1
          logf("zip_extractor: extracted %s -> %s (%d bytes)", entry.name, destPath, written)
        else
          logf("zip_extractor: extract failed %s, err=%s", entry.name, tostring(decErr))
        end
        coroutine.yield()
      end
    end
    if warnUnmatched then
      warnUnmatched()
    end
    logf("zip_extractor: ExtractAllAsync done, zip=%s, ok=%d/%d, filtered=%d (%d bytes skipped), cost=%.2fs", tostring(zipPath), okCount, totalCount, skippedCount, savedBytes, os.clock() - startClock)
    return okCount, totalCount
  end)
  local finished = false
  return function()
    if finished then
      return true
    end
    local ok, a, b, c = coroutine.resume(co)
    if not ok then
      finished = true
      logf("zip_extractor: ExtractAllAsync error, %s", tostring(a))
      if onFinish then
        onFinish(0, 0, tostring(a))
      end
      return true
    end
    if coroutine.status(co) == "dead" then
      finished = true
      if onFinish then
        onFinish(a or 0, b or 0, c)
      end
      return true
    end
    return false
  end, stepRef
end

return zip_extractor
