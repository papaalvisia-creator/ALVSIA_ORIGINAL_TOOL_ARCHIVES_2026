local Logic_UGC_Res_Manager = {}
local PufferConst = require("client.slua.logic.download.puffer_const")
local PufferTlog = require("client.slua.logic.download.report.puffer_tlog")
local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
local PufferSwitch = require("client.slua.logic.download.puffer_switch")
local LogicPufferBundle = require("client.slua.logic.download.bundle.logic_puffer_bundle")
local PufferDeleteManager = require("client.slua.logic.download.delete.puffer_delete_manager")
local Config_UGC = require("client.slua.logic.ugc.config_ugc")
local TableUtil = require("common.table_util")
local UGCSchemaValidator = require("client.slua.logic.ugc.schema.ugc_schema_validator")
local UGCSchemaConfig = require("client.slua.logic.ugc.schema.ugc_schema_config")
local UGCLog = require("client.slua.logic.download.puffer.puffer_ugc_log")
local SchemaType = UGCSchemaConfig.EnumSchemaType
local WeakValidationOptions = {PreserveUnknownFields = true}
local table_pool = require("common.table_pool")
local tablePool = table_pool.Create()
local UGCMacros = require("client.slua.logic.ugc.ugc_macros")
Logic_UGC_Res_Manager.DownloaderType = UGCMacros.ENUM_DownloaderType
local DownloaderTypeName = {}
for name, val in pairs(UGCMacros.ENUM_DownloaderType) do
  DownloaderTypeName[val] = name
end
local defaultExtraParams = {bAutoDownload = false}
local UGCPackIDList = {
  PufferConst.EODPackID.WOW_20W,
  PufferConst.EODPackID.WOW_20W_2
}
local UGCPackIDSet = {}
for _, v in ipairs(UGCPackIDList) do
  UGCPackIDSet[v] = true
end

local function GetLobbyBinModule()
  local ScriptPackPreDownloadConfig = Config_UGC.ScriptPackPreDownload
  if not ScriptPackPreDownloadConfig or ScriptPackPreDownloadConfig.Enabled ~= true then
    return nil
  end
  local ModuleConfig = ModuleManager.LobbyModuleConfig.LogicUGCLobbyBin
  return ModuleConfig and ModuleManager.GetModule(ModuleConfig) or nil
end

local DownloadUIType = {
  RBottom = 1,
  LoadBtn = 2,
  TeamLoadBtn = 3,
  DetailLoadBtn = 4,
  LoadMapUI = 5,
  UGCLoadMapUI = 6,
  UpdateMod = 7,
  EditPubMod = 8,
  EditModBtn = 9,
  EditPubModMapMgmt = 10
}
Logic_UGC_Res_Manager.DownloadUIType = DownloadUIType
local TLogKey = {
  ClickDownload = "ClickDownload",
  ClickPause = "ClickPause",
  ClickContinue = "ClickContinue",
  LoadFinish = "LoadFinish",
  ReportWoWResSize = "ReportWoWResSize",
  DeleteMarkWoW = "DeleteMarkWoW",
  SureDeleteWoWRes = "SureDeleteWoWRes",
  InitDownload = "InitDownload",
  SilentDownload = "SilentDownload",
  AutoDownload = "AutoDownload",
  LobbyTopFloat = "LobbyTopFloat",
  DetailBtn = "DetailBtn",
  RemindPopup = "RemindPopup",
  LobbyFloat = "LobbyFloat",
  LightLoading = "LightLoading",
  DetailSelect = "DetailSelect"
}
Logic_UGC_Res_Manager.TLogKey = TLogKey

function Logic_UGC_Res_Manager:OnInitialize()
  Logic_UGC_Res_Manager.__super.OnInitialize(self)
  self.modResCaches = {}
  self.modStateCaches = {}
  self.UGCAssetConfig = CDataTable.GetTable("UGCAssetConfig") or {}
  self.UGCAssetConfigIDMap = {}
  self.AssetIDInPacks = {}
  for k, v in pairs(self.UGCAssetConfig) do
    local PackID = v.ResSeprateType
    if PackID and UGCPackIDSet[PackID] then
      if not self.AssetIDInPacks[PackID] then
        self.AssetIDInPacks[PackID] = {}
      end
      self.AssetIDInPacks[PackID][v.AssetID] = 1
    end
    if v.ID then
      self.UGCAssetConfigIDMap[v.ID] = v
    end
  end
  self.bOptimizeMapDownload = false
  self.bResListMinDepends = true
  self._trackingMods = {}
  self._dumpWatchList = {}
  self._batchSeq = 0
  self._batchPending = {}
  self._batchTipShown = {}
  self.reportedModStateCaches = {}
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  self.bIsFitVersion = PublishRegionMacros.IsFITVersion()
  log(bWriteLog and "Logic_UGC_Res_Manager:OnInitialize = " .. tostring(self.bResListMinDepends))
end

function Logic_UGC_Res_Manager:RegistEvents()
  Logic_UGC_Res_Manager.__super.RegistEvents(self)
  self:AddCommonEvent(EVENTTYPE_PUFFER, EVENTID_PUFFER_DOWNLOADFINISH, self._OnPufferDownloadFinish, self)
  self:AddCommonEvent(EVENTTYPE_DOWNLOAD, EVENTID_PUFFER_JSON_POSTPROCESS, self._OnPufferJsonPostProcess, self)
  self:AddCommonEvent(EVENTTYPE_PUFFER, EVENTID_PUFFER_PAUSEALLDOWNLOAD, self._OnPufferPauseAllDownload, self)
end

function Logic_UGC_Res_Manager:_OnPufferPauseAllDownload()
  self:_DumpUnfinishedWatchMods("queue_clear")
  local cacheInfos = self.modResCaches
  if not cacheInfos then
    return
  end
  for cacheKey, cacheInfo in pairs(cacheInfos) do
    if cacheInfo.state == PufferConst.ENUM_DownloadState.Download or cacheInfo.state == PufferConst.ENUM_DownloadState.Wait then
      cacheInfo.state = PufferConst.ENUM_DownloadState.Pause
      log(bWriteLog and string.format("Logic_UGC_Res_Manager:_OnPufferPauseAllDownload cacheKey:%s -> Pause", tostring(cacheKey)))
    end
  end
end

function Logic_UGC_Res_Manager:_AddDumpWatch(loaderType, modInfo)
  if not UGCLog.IsEnable() then
    return
  end
  if not modInfo or not modInfo.base then
    return
  end
  self._dumpWatchList = self._dumpWatchList or {}
  local Key = (DownloaderTypeName[loaderType] or tostring(loaderType)) .. "_" .. tostring(self:_GetCacheKeyByModInfo(modInfo, loaderType == self.DownloaderType.MyWork))
  local Watch = self._dumpWatchList[Key]
  if Watch then
    Watch.modInfo = modInfo
    return
  end
  self._dumpWatchList[Key] = {
    loaderType = loaderType,
    modInfo = modInfo,
    dumpedReasons = {}
  }
  self._stallTickCount = 0
  self._lastStallCheckSeq = self._pufferFinishSeq or 0
  self:_StartDownloadStallWatchdog()
end

function Logic_UGC_Res_Manager:_DumpUnfinishedWatchMods(sReason)
  if not (UGCLog.IsEnable() and self._dumpWatchList) or not next(self._dumpWatchList) then
    return
  end
  local ENUM = PufferConst.ENUM_DownloadState
  for key, watch in pairs(self._dumpWatchList) do
    local modInfo = watch.modInfo
    if not modInfo then
      self._dumpWatchList[key] = nil
    elseif self:GetResState(watch.loaderType, modInfo, true) == ENUM.Done then
      self._dumpWatchList[key] = nil
    elseif not watch.dumpedReasons[sReason] then
      local state = self:GetResState(watch.loaderType, modInfo)
      if state == ENUM.Done then
        self._dumpWatchList[key] = nil
      else
        watch.dumpedReasons[sReason] = true
        UGCLog.Log("mod download not finished. key=%s state=%s reason=%s, dumping missing list", tostring(key), UGCLog.StateName(state), tostring(sReason))
        self:DumpModMissing(modInfo, sReason, watch.loaderType)
      end
    end
  end
  if not next(self._dumpWatchList) then
    self:_StopDownloadStallWatchdog()
  end
end

function Logic_UGC_Res_Manager:_OnPufferDownloadFinish()
  self._pufferFinishSeq = (self._pufferFinishSeq or 0) + 1
  if not self._trackingMods then
    return
  end
  local completedMods = {}
  local expiredModIds = {}
  local LobbyBinModule = GetLobbyBinModule()
  for modId, trackingData in pairs(self._trackingMods) do
    local modInfo = trackingData.modInfo
    local bShouldDownloadLobbyBin = LobbyBinModule and LobbyBinModule:ShouldDownload(modInfo) or false
    local bModInfoValid = true
    if bShouldDownloadLobbyBin then
      bModInfoValid = UGCSchemaValidator.Validate(SchemaType.ModDownloadTrackingInfo, modInfo, WeakValidationOptions)
    end
    if not bModInfoValid then
      expiredModIds[modId] = trackingData
    else
      local state = self:GetResState(self.DownloaderType.ModCopy, modInfo)
      if state == PufferConst.ENUM_DownloadState.Done then
        completedMods[modId] = trackingData
      elseif state == PufferConst.ENUM_DownloadState.Error then
        UGCLog.Log("Logic_UGC_Res_Manager mod download reached Error terminal state. mod_id=%s, dumping missing list", tostring(modId))
        self:DumpModMissing(modInfo, "error_terminal", self.DownloaderType.ModCopy)
        expiredModIds[modId] = trackingData
      end
    end
  end
  for modId, trackingData in pairs(completedMods) do
    self._trackingMods[modId] = nil
    log(bWriteLog and "Logic_UGC_Res_Manager:_OnPufferDownloadFinish complete mod_id = " .. tostring(modId))
    local bLobbyBinFailed = LobbyBinModule and LobbyBinModule:ShouldDownload(trackingData.modInfo) and LobbyBinModule:IsDownloadFailed(trackingData.modInfo) or false
    EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_DOWNLOAD_RES_COMPLETE, modId)
    if trackingData.bShowTip then
      local batchId = trackingData.batchId
      if batchId and self._batchPending[batchId] then
        self._batchPending[batchId] = self._batchPending[batchId] - 1
        if not bLobbyBinFailed and not self._batchTipShown[batchId] then
          self._batchTipShown[batchId] = true
          self:_ShowDownloadCompleteTip(trackingData.modInfo)
        end
        if 0 >= self._batchPending[batchId] then
          self._batchPending[batchId] = nil
          self._batchTipShown[batchId] = nil
        end
      elseif not bLobbyBinFailed then
        self:_ShowDownloadCompleteTip(trackingData.modInfo)
      end
    end
  end
  for modId, trackingData in pairs(expiredModIds) do
    self._trackingMods[modId] = nil
    log(bWriteLog and "Logic_UGC_Res_Manager:_OnPufferDownloadFinish expired mod_id = " .. tostring(modId))
    local batchId = trackingData.batchId
    if batchId and self._batchPending[batchId] then
      self._batchPending[batchId] = self._batchPending[batchId] - 1
      if 0 >= self._batchPending[batchId] then
        self._batchPending[batchId] = nil
        self._batchTipShown[batchId] = nil
      end
    end
    local SelectModDecider = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider)
    if SelectModDecider then
      SelectModDecider:OnDownloadResTerminated(modId)
    end
  end
end

function Logic_UGC_Res_Manager:_ShowDownloadCompleteTip(modInfo)
  local DISPLAY_SECONDS = 10
  UIManager.ShowUI(UIManager.UI_Config.Common_RightBottom_Tip_Download_WOW, modInfo, DISPLAY_SECONDS)
end

function Logic_UGC_Res_Manager:ClearData()
  self.modResCaches = {}
  self.modStateCaches = {}
  self.localModList = nil
  self:_RemoveReportResTimer()
end

function Logic_UGC_Res_Manager:OnLogOut()
  self:_StopDownloadStallWatchdog()
  self._dumpWatchList = {}
  self._stallTickCount = 0
  self._lastStallCheckSeq = nil
  UGCLog.ResetSkipOnce()
  self._trackingMods = {}
  self._batchSeq = 0
  self._batchPending = {}
  self._batchTipShown = {}
  self.reportedModStateCaches = {}
  self.bLoginReady = false
  self.bPufferReady = false
  self.bHasReportedResBitmap = false
  self:_RemoveReportUGCResBitmapTimers()
  self:ClearData()
end

function Logic_UGC_Res_Manager:OnPreSwitchGameStatus(preState, nextState)
  print(bWriteLog and "Logic_UGC_Res_Manager:OnPreSwitchGameStatus")
  if nextState == GameStatus.Lobby and preState == GameStatus.Fighting then
    print(bWriteLog and "Logic_UGC_Res_Manager:OnPreSwitchGameStatus preState is fighting,next is lobby,  Clear Cache Infos")
    self:ClearCacheInfos()
  end
  if not IsWoWEditor and not IsEditor and nextState == GameStatus.Fighting and not self.bHasReportedResBitmap then
    self:_FlushReportUGCResBitmapImmediate("OnPreSwitchGameStatus->Fighting")
  end
  self:_RemoveReportResTimer()
end

function Logic_UGC_Res_Manager:OnPostSwitchGameStatus(preState, nextState)
  if IsWoWEditor or IsEditor then
    return
  end
  print(bWriteLog and "Logic_UGC_Res_Manager.OnPostSwitchGameStatus")
  if preState == GameStatus.Login and nextState == GameStatus.Lobby then
    self.bLoginReady = true
    self:_TryReportUGCResBitmap("OnLoginSuccess")
  end
end

function Logic_UGC_Res_Manager:_OnPufferJsonPostProcess()
  if IsWoWEditor or IsEditor then
    return
  end
  self.bPufferReady = true
  self:_TryReportUGCResBitmap("OnPufferJsonPostProcess")
end

local REPORT_UGC_RES_BITMAP_DELAY_SEC = 15
local REPORT_UGC_RES_BITMAP_STEP_BUDGET_MS = 30

function Logic_UGC_Res_Manager:_TryReportUGCResBitmap(sTrigger)
  if IsWoWEditor or IsEditor then
    return
  end
  if self.bHasReportedResBitmap then
    return
  end
  if not self.bLoginReady then
    print(bWriteLog and string.format("Logic_UGC_Res_Manager:_TryReportUGCResBitmap wait login, trigger=%s", tostring(sTrigger)))
    return
  end
  if not self.bPufferReady then
    local PufferDownloader = _G.PufferDownloader
    if not PufferDownloader or not PufferDownloader.PufferJsonDownloadReturn then
      print(bWriteLog and string.format("Logic_UGC_Res_Manager:_TryReportUGCResBitmap wait puffer, trigger=%s", tostring(sTrigger)))
      return
    end
    self.bPufferReady = true
  end
  print(bWriteLog and string.format("Logic_UGC_Res_Manager:_TryReportUGCResBitmap schedule, trigger=%s", tostring(sTrigger)))
  self:_ScheduleReportUGCResBitmap(sTrigger)
end

function Logic_UGC_Res_Manager:_ScheduleReportUGCResBitmap(sTrigger)
  if self.bHasReportedResBitmap then
    return
  end
  if self.ReportUGCResBitmapDelayTimer or self.StepReportUGCResBitmapTimer then
    return
  end
  print(bWriteLog and string.format("Logic_UGC_Res_Manager:_ScheduleReportUGCResBitmap delay=%ss trigger=%s", tostring(REPORT_UGC_RES_BITMAP_DELAY_SEC), tostring(sTrigger)))
  self.ReportUGCResBitmapDelayTimer = self:AddTimer(REPORT_UGC_RES_BITMAP_DELAY_SEC, function()
    self.ReportUGCResBitmapDelayTimer = nil
    self:_StartStepReportUGCResBitmap(sTrigger)
  end)
end

function Logic_UGC_Res_Manager:_StartStepReportUGCResBitmap(sTrigger)
  if self.bHasReportedResBitmap then
    return
  end
  if self.StepReportUGCResBitmapTimer then
    self:RemoveTimer(self.StepReportUGCResBitmapTimer)
    self.StepReportUGCResBitmapTimer = nil
  end
  local PufferUGCPakManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_ugcpak_manager)
  if not PufferUGCPakManager then
    print(bWriteLog and "Logic_UGC_Res_Manager:_StartStepReportUGCResBitmap skip: PufferUGCPakManager nil")
    return
  end
  if not self.UGCAssetConfigIDMap or next(self.UGCAssetConfigIDMap) == nil then
    print(bWriteLog and "Logic_UGC_Res_Manager:_StartStepReportUGCResBitmap skip: UGCAssetConfigIDMap empty")
    return
  end
  local AssetList = {}
  for _, cfg in pairs(self.UGCAssetConfigIDMap) do
    local assetID = cfg and cfg.AssetID
    if assetID and 0 < assetID then
      table.insert(AssetList, assetID)
    end
  end
  local ctx = {
    AssetList = AssetList,
    Index = 0,
    DownloadedMap = {},
    Total = 0,
    Done = 0,
    Trigger = sTrigger
  }
  self._ReportBitmapCtx = ctx
  local time_ticker = require("common.time_ticker")
  self.StepReportUGCResBitmapTimer = self:AddTimer(0, function()
    local StepStartTime = slua.getMiliseconds()
    local list = ctx.AssetList
    local count = #list
    local i = ctx.Index + 1
    while count >= i do
      if ctx.Aborted or self.bHasReportedResBitmap or self._ReportBitmapCtx ~= ctx then
        return
      end
      local puffer_ugcpak_manager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_ugcpak_manager)
      if not puffer_ugcpak_manager then
        self.StepReportUGCResBitmapTimer = nil
        self._ReportBitmapCtx = nil
        return
      end
      local assetID = list[i]
      ctx.Total = ctx.Total + 1
      if puffer_ugcpak_manager:GetStateByAssetID(assetID) == PufferConst.ENUM_DownloadState.Done then
        ctx.DownloadedMap[assetID] = true
        ctx.Done = ctx.Done + 1
      end
      ctx.Index = i
      i = i + 1
      local StepEndTime = slua.getMiliseconds()
      if StepEndTime - StepStartTime > REPORT_UGC_RES_BITMAP_STEP_BUDGET_MS and count >= i then
        print(bWriteLog and "Logic_UGC_Res_Manager getAssetState STEP before yield, index= ", ctx.Index)
        coroutine.yield(time_ticker.MINIMUM_STEP_TIME)
        print(bWriteLog and "Logic_UGC_Res_Manager getAssetState STEP after yield, index= ", ctx.Index, "aborted=", ctx.Aborted)
        StepStartTime = slua.getMiliseconds()
      end
    end
    self.StepReportUGCResBitmapTimer = nil
    self:_DoReportUGCResBitmap(ctx)
  end)
end

function Logic_UGC_Res_Manager:_FlushReportUGCResBitmapImmediate(sTrigger)
  if self.bHasReportedResBitmap then
    return
  end
  local bHasDelay = self.ReportUGCResBitmapDelayTimer ~= nil
  local bHasStep = self.StepReportUGCResBitmapTimer ~= nil
  if not bHasDelay and not bHasStep then
    return
  end
  print(bWriteLog and string.format("Logic_UGC_Res_Manager:_FlushReportUGCResBitmapImmediate flush, trigger=%s bDelay=%s bStep=%s", tostring(sTrigger), tostring(bHasDelay), tostring(bHasStep)))
  if self.ReportUGCResBitmapDelayTimer then
    self:RemoveTimer(self.ReportUGCResBitmapDelayTimer)
    self.ReportUGCResBitmapDelayTimer = nil
  end
  local PufferUGCPakManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_ugcpak_manager)
  if not PufferUGCPakManager then
    if self._ReportBitmapCtx then
      self._ReportBitmapCtx.Aborted = true
    end
    self.StepReportUGCResBitmapTimer = nil
    self._ReportBitmapCtx = nil
    return
  end
  if not self.UGCAssetConfigIDMap or next(self.UGCAssetConfigIDMap) == nil then
    if self._ReportBitmapCtx then
      self._ReportBitmapCtx.Aborted = true
    end
    self.StepReportUGCResBitmapTimer = nil
    self._ReportBitmapCtx = nil
    return
  end
  local ctx = self._ReportBitmapCtx
  if ctx then
    ctx.Aborted = true
  else
    local AssetList = {}
    for _, cfg in pairs(self.UGCAssetConfigIDMap) do
      local assetID = cfg and cfg.AssetID
      if assetID and 0 < assetID then
        table.insert(AssetList, assetID)
      end
    end
    ctx = {
      AssetList = AssetList,
      Index = 0,
      DownloadedMap = {},
      Total = 0,
      Done = 0,
      Trigger = sTrigger,
      Aborted = false
    }
  end
  local list = ctx.AssetList
  local count = #list
  for i = ctx.Index + 1, count do
    local assetID = list[i]
    ctx.Total = ctx.Total + 1
    if PufferUGCPakManager:GetStateByAssetID(assetID) == PufferConst.ENUM_DownloadState.Done then
      ctx.DownloadedMap[assetID] = true
      ctx.Done = ctx.Done + 1
    end
    ctx.Index = i
  end
  self.StepReportUGCResBitmapTimer = nil
  self._ReportBitmapCtx = nil
  self:_DoReportUGCResBitmap(ctx)
end

function Logic_UGC_Res_Manager:_RemoveReportUGCResBitmapTimers()
  if self.ReportUGCResBitmapDelayTimer then
    self:RemoveTimer(self.ReportUGCResBitmapDelayTimer)
    self.ReportUGCResBitmapDelayTimer = nil
  end
  if self._ReportBitmapCtx then
    self._ReportBitmapCtx.Aborted = true
  end
  self.StepReportUGCResBitmapTimer = nil
  self._ReportBitmapCtx = nil
end

function Logic_UGC_Res_Manager:_DoReportUGCResBitmap(ctx)
  if self.bHasReportedResBitmap then
    self._ReportBitmapCtx = nil
    return
  end
  if not ctx then
    return
  end
  local BitmapUtil = require("client.slua.logic.ugc.PrefabMall.Config.PrefabMallBitmapUtil")
  local bitmap_data = BitmapUtil.EncodeBitmap(ctx.DownloadedMap, "UGCAssetConfig") or {}
  local maxSlot = 0
  for k, _ in pairs(bitmap_data) do
    if k > maxSlot then
      maxSlot = k
    end
  end
  local bitmap_bit_count = maxSlot * 32
  print(bWriteLog and string.format("Logic_UGC_Res_Manager:_DoReportUGCResBitmap total=%d done=%d bit_count=%d trigger=%s", ctx.Total, ctx.Done, bitmap_bit_count or 0, tostring(ctx.Trigger)))
  local UGCHandler = require("client.network.Protocol.UGCHandler")
  UGCHandler.send_ugc_report_res_bitmap_req(bitmap_data, bitmap_bit_count)
  self.bHasReportedResBitmap = true
  self._ReportBitmapCtx = nil
end

function Logic_UGC_Res_Manager:OnModInfoBatchRsp(MetaList, ListType, Param)
  if not MetaList then
    return
  end
  local LogicUGCMatch = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch)
  local matchInfo = LogicUGCMatch:GetMatchInfo()
  if not (matchInfo and matchInfo.mod_id) or not MetaList[matchInfo.mod_id] then
    return
  end
  local ModInfo = MetaList[matchInfo.mod_id]
  local LogicUGCResManager = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager)
  LogicUGCResManager:Send_update_client_mod_info_ByModInfo(ModInfo.pub_mod_meta)
end

function Logic_UGC_Res_Manager:CheckMatchInfoChange()
  local LogicUGCMatch = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch)
  local matchInfo = LogicUGCMatch:GetMatchInfo()
  if matchInfo == nil then
    self:_RemoveReportResTimer()
  end
end

function Logic_UGC_Res_Manager:GetStateByModID(loaderType, modID)
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  local modeInfo = LogicUGC:GetModByAllCache(modID)
  if modeInfo then
    return self:GetResState(loaderType, modeInfo.pub_mod_meta)
  end
  return PufferConst.ENUM_DownloadState.Not
end

function Logic_UGC_Res_Manager:IsCompleteRes(loaderType, modInfo)
  local state = self:GetResState(loaderType, modInfo)
  return state == PufferConst.ENUM_DownloadState.Done
end

function Logic_UGC_Res_Manager:_TrackModDownload(modInfo, bSilent, batchId)
  if bSilent then
    return
  end
  local ModInfoView = modInfo
  local LobbyBinModule = GetLobbyBinModule()
  if LobbyBinModule and LobbyBinModule:ShouldDownload(modInfo) then
    local bModInfoValid
    bModInfoValid, ModInfoView = UGCSchemaValidator.Validate(SchemaType.ModDownloadTrackingInfo, modInfo, WeakValidationOptions)
    if not bModInfoValid then
      log(bWriteLog and "[UGCLobbyBin] Logic_UGC_Res_Manager:_TrackModDownload invalid modInfo")
      return
    end
  end
  if type(ModInfoView) ~= "table" or ModInfoView.mod_id == nil then
    return
  end
  local ModID = ModInfoView.mod_id
  local OldTrackingData = self._trackingMods[ModID]
  if OldTrackingData then
    OldTrackingData.modInfo = ModInfoView
    OldTrackingData.bShowTip = OldTrackingData.bShowTip or not bSilent
    OldTrackingData.batchId = OldTrackingData.batchId or batchId
    log(bWriteLog and "Logic_UGC_Res_Manager:_TrackModDownload re-tracking mod_id = " .. tostring(ModID) .. ", batchId = " .. tostring(OldTrackingData.batchId))
    return
  end
  local TrackingData = {
    modInfo = ModInfoView,
    bShowTip = not bSilent,
    batchId = batchId
  }
  self._trackingMods[ModID] = TrackingData
  if batchId and self._batchPending[batchId] then
    self._batchPending[batchId] = self._batchPending[batchId] + 1
  end
  log(bWriteLog and "Logic_UGC_Res_Manager:_TrackModDownload tracking mod_id = " .. tostring(ModID) .. ", batchId = " .. tostring(batchId))
end

local DOWNLOAD_STALL_CHECK_INTERVAL = 10
local DOWNLOAD_STALL_THRESHOLD = 3

function Logic_UGC_Res_Manager:_StartDownloadStallWatchdog()
  if self._stallWatchdogTimer then
    return
  end
  if not UGCLog.IsEnable() then
    return
  end
  self._stallWatchdogTimer = self:AddTimerLoop(DOWNLOAD_STALL_CHECK_INTERVAL, function()
    self:_CheckDownloadStall()
  end, TIMER_INFINITE, DOWNLOAD_STALL_CHECK_INTERVAL)
  UGCLog.Log("Logic_UGC_Res_Manager start download stall watchdog. interval=%ss threshold=%s times", tostring(DOWNLOAD_STALL_CHECK_INTERVAL), tostring(DOWNLOAD_STALL_THRESHOLD))
end

function Logic_UGC_Res_Manager:_StopDownloadStallWatchdog()
  if self._stallWatchdogTimer then
    self:RemoveTimer(self._stallWatchdogTimer)
    self._stallWatchdogTimer = nil
  end
end

function Logic_UGC_Res_Manager:_CheckDownloadStall()
  if not self._dumpWatchList or not next(self._dumpWatchList) then
    self:_StopDownloadStallWatchdog()
    return
  end
  local CurSeq = self._pufferFinishSeq or 0
  if CurSeq ~= self._lastStallCheckSeq then
    self._lastStallCheckSeq = CurSeq
    self._stallTickCount = 0
    return
  end
  self._stallTickCount = (self._stallTickCount or 0) + 1
  if self._stallTickCount ~= DOWNLOAD_STALL_THRESHOLD then
    return
  end
  local ENUM = PufferConst.ENUM_DownloadState
  for key, watch in pairs(self._dumpWatchList) do
    local modInfo = watch.modInfo
    if not modInfo then
      self._dumpWatchList[key] = nil
    elseif self:GetResState(watch.loaderType, modInfo) == ENUM.Done then
      self._dumpWatchList[key] = nil
    elseif not watch.dumpedReasons.stall then
      watch.dumpedReasons.stall = true
      UGCLog.Log("mod download stalled. key=%s no pak callback for %ss, dumping missing list", tostring(key), tostring(DOWNLOAD_STALL_CHECK_INTERVAL * DOWNLOAD_STALL_THRESHOLD))
      self:DumpModMissing(modInfo, "stall", watch.loaderType)
    end
  end
  if not next(self._dumpWatchList) then
    self:_StopDownloadStallWatchdog()
  end
end

function Logic_UGC_Res_Manager:OnLobbyBinDownloadFinish()
  self:_OnPufferDownloadFinish()
end

function Logic_UGC_Res_Manager:_NeedOtherRes(modInfo)
  local bNeedOtherRes = true
  local TemplateID = modInfo and modInfo.base and modInfo.base.template_id
  if TemplateID then
    local LogicUGCTemplate = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCTemplate)
    local bIsSkipDownload = LogicUGCTemplate:CheckIsSkipDownloadTemplate(TemplateID)
    bNeedOtherRes = not bIsSkipDownload
  end
  return bNeedOtherRes
end

function Logic_UGC_Res_Manager:GetResState(loaderType, modInfo, bWeakCalculate)
  local state = PufferConst.ENUM_DownloadState.Done
  if loaderType == self.DownloaderType.ModCopy then
    state = self:_GetUGCModResState(modInfo, bWeakCalculate)
  elseif loaderType == self.DownloaderType.MyWork then
    state = self:_GetUGCWorkResState(modInfo, bWeakCalculate)
  elseif loaderType == self.DownloaderType.Template then
    state = self:_GetUGCTemplateResState(modInfo)
  end
  local bNeedOtherRes = self:_NeedOtherRes(modInfo)
  if bNeedOtherRes then
    local bIsNewMeta = self:_IsNewMeta(modInfo)
    if bIsNewMeta then
      local LogicUGCAssetHub = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAssetHub)
      local AssetHubState = LogicUGCAssetHub:GetAssetState(loaderType, modInfo)
      state = PufferManager.GetMixDownloadState(state, AssetHubState)
    end
    if loaderType == self.DownloaderType.ModCopy then
      local LobbyBinModule = GetLobbyBinModule()
      if LobbyBinModule and LobbyBinModule:ShouldDownload(modInfo) then
        state = PufferManager.GetMixDownloadState(state, LobbyBinModule:GetResourceState(modInfo))
      end
    end
  end
  return state
end

function Logic_UGC_Res_Manager:CheckStorageEnough(DownloadSize)
  if IsEditor then
    return true
  end
  local FreeStorage = PufferDeleteManager.GetDeviceFreeSpace()
  local LeftStorage = FreeStorage - UGCMacros.GAME_NEED_MIN_STORAGE - DownloadSize
  if LeftStorage <= 0 then
    local LogicUGCAssetHub = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAssetHub)
    if 0 >= LogicUGCAssetHub:GetPublicStorage() then
      ShowNotice(33208)
      PufferDeleteManager.ShowDeleteUI(false)
    else
      LogicUGCAssetHub:ShowCleanPopup()
    end
    return false
  end
  return true
end

function Logic_UGC_Res_Manager:DownloadRes(loaderType, modInfo, bSkipCheck, bSilent, batchId)
  local ModIDForLog = modInfo and not modInfo.mod_id and modInfo.base and modInfo.base.slot
  UGCLog.Log("Logic_UGC_Res_Manager:DownloadRes loaderType=%s modID=%s bSkipCheck=%s bSilent=%s batchId=%s", tostring(loaderType), tostring(ModIDForLog), tostring(bSkipCheck), tostring(bSilent), tostring(batchId))
  if not bSkipCheck then
    if PufferSwitch.BanDownload then
      log(bWriteLog and "Logic_UGC_Res_Manager:DownloadRes ban download true")
      UGCLog.Skip("Logic_UGC_Res_Manager:DownloadRes", "ban_download", "modID=%s PufferSwitch.BanDownload=true", tostring(ModIDForLog))
      return false
    end
    if not PufferDownloader.InitSuccess then
      UGCLog.Skip("Logic_UGC_Res_Manager:DownloadRes", "puffer_not_init", "modID=%s PufferDownloader.InitSuccess=false, re-initialize triggered", tostring(ModIDForLog))
      PufferDownloader.ReInitializePuffer(false)
      return false
    end
    if not PufferDownloader.PufferJsonDownloadReturn then
      UGCLog.Skip("Logic_UGC_Res_Manager:DownloadRes", "puffer_json_not_ready", "modID=%s PufferFileList.json not returned yet, this download request is dropped", tostring(ModIDForLog))
      PufferDownloader.ReportPufferWarning()
      return false
    end
    local cSize, tSize = self:GetResSize(loaderType, modInfo)
    local unSize = tSize - cSize
    if not self:CheckStorageEnough(unSize) then
      log(bWriteLog and "Logic_UGC_Res_Manager:DownloadRes CheckStorageEnough false")
      UGCLog.Skip("Logic_UGC_Res_Manager:DownloadRes", "storage_not_enough", "modID=%s needSize=%.2fMB", tostring(ModIDForLog), unSize or 0)
      return false
    end
  end
  local Result = false
  local ModResResult
  if loaderType == self.DownloaderType.ModCopy then
    Result = self:_DownloadModRes(modInfo, bSilent, batchId)
    ModResResult = Result
  elseif loaderType == self.DownloaderType.MyWork then
    Result = self:_DownloadWorkRes(modInfo)
  elseif loaderType == self.DownloaderType.Template then
    Result = self:_DownloadTemplateRes(modInfo)
  end
  if Result == false then
    self:_AddDumpWatch(loaderType, modInfo)
  end
  local bNeedOtherRes = self:_NeedOtherRes(modInfo)
  if bNeedOtherRes then
    local bIsNewMeta = self:_IsNewMeta(modInfo)
    if bIsNewMeta then
      local LogicUGCAssetHub = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAssetHub)
      local bAutoClean, bBreak = LogicUGCAssetHub:AutoCleanStorage(loaderType, modInfo)
      if bAutoClean then
        local AssetHubResult = LogicUGCAssetHub:Download(loaderType, modInfo)
        if not AssetHubResult then
          Result = AssetHubResult
        end
      elseif bBreak then
        Result = false
      end
    end
    if loaderType == self.DownloaderType.ModCopy then
      local LobbyBinModule = GetLobbyBinModule()
      if LobbyBinModule and LobbyBinModule:ShouldDownload(modInfo) then
        local ScriptPackResourceState = LobbyBinModule:GetResourceState(modInfo)
        if ScriptPackResourceState ~= PufferConst.ENUM_DownloadState.Done and ModResResult == true and modInfo and modInfo.mod_id then
          self:_TrackModDownload(modInfo, bSilent, batchId)
        end
        if not LobbyBinModule:Download(modInfo) then
          Result = false
        end
      end
    end
  end
  return Result
end

function Logic_UGC_Res_Manager:PauseRes(loaderType, modInfo)
  if loaderType == self.DownloaderType.ModCopy then
    self:_PauseModRes(modInfo)
  elseif loaderType == self.DownloaderType.MyWork then
    self:_PauseWorkRes(modInfo)
  elseif loaderType == self.DownloaderType.Template then
    self:_PauseTemplateRes(modInfo)
  end
  local bNeedOtherRes = self:_NeedOtherRes(modInfo)
  if bNeedOtherRes then
    local bIsNewMeta = self:_IsNewMeta(modInfo)
    if bIsNewMeta then
      local LogicUGCAssetHub = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAssetHub)
      LogicUGCAssetHub:Pause(loaderType, modInfo)
    end
    if loaderType == self.DownloaderType.ModCopy then
      local LobbyBinModule = GetLobbyBinModule()
      if LobbyBinModule and LobbyBinModule:ShouldDownload(modInfo) then
        LobbyBinModule:Pause(modInfo)
      end
    end
  end
end

function Logic_UGC_Res_Manager:GetResSize(loaderType, modInfo)
  local cSize, tSize = 0, 0
  if loaderType == self.DownloaderType.ModCopy then
    cSize, tSize = self:_GetUGCModResSize(modInfo)
  elseif loaderType == self.DownloaderType.MyWork then
    cSize, tSize = self:_GetUGCWorkResSize(modInfo)
  elseif loaderType == self.DownloaderType.Template then
    cSize, tSize = self:_GetUGCTemplateResSize(modInfo)
  end
  local bNeedOtherRes = self:_NeedOtherRes(modInfo)
  if bNeedOtherRes then
    local bIsNewMeta = self:_IsNewMeta(modInfo)
    if bIsNewMeta then
      local LogicUGCAssetHub = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAssetHub)
      local cAssetHubSize, tAssetHubSize = LogicUGCAssetHub:GetAssetSize(loaderType, modInfo)
      tSize = tSize + tAssetHubSize
      cSize = cSize + cAssetHubSize
    end
    if loaderType == self.DownloaderType.ModCopy then
      local LobbyBinModule = GetLobbyBinModule()
      if LobbyBinModule and LobbyBinModule:ShouldDownload(modInfo) then
        local cScriptPackSize, tScriptPackSize = LobbyBinModule:GetDownloadSize(modInfo)
        tSize = tSize + tScriptPackSize
        cSize = cSize + cScriptPackSize
      end
    end
  end
  return cSize, tSize
end

function Logic_UGC_Res_Manager:BatchGetResState(LoaderType, ModList)
  local ResultState = PufferConst.ENUM_DownloadState.Done
  local ModLoaderType = LoaderType == self.DownloaderType.ModList and self.DownloaderType.ModCopy or self.DownloaderType.Template
  for k, v in pairs(ModList) do
    local State = self:GetResState(ModLoaderType, v)
    ResultState = PufferManager.GetMixDownloadState(ResultState, State)
  end
  return ResultState
end

function Logic_UGC_Res_Manager:BatchDownloadRes(LoaderType, ModList)
  if PufferSwitch.BanDownload then
    log(bWriteLog and "Logic_UGC_Res_Manager:BatchDownloadRes ban download true")
    return false
  end
  if not PufferDownloader.InitSuccess then
    PufferDownloader.ReInitializePuffer(false)
    return false
  end
  if not PufferDownloader.PufferJsonDownloadReturn then
    PufferDownloader.ReportPufferWarning()
    return false
  end
  local cSize, tSize = self:BatchGetResSize(LoaderType, ModList)
  local unSize = tSize - cSize
  if not self:CheckStorageEnough(unSize) then
    log(bWriteLog and "Logic_UGC_Res_Manager:BatchDownloadRes CheckStorageEnough false")
    return false
  end
  self._batchSeq = self._batchSeq + 1
  local batchId = "batch_" .. tostring(self._batchSeq)
  self._batchPending[batchId] = 0
  local bFinish = true
  local ModLoaderType = LoaderType == self.DownloaderType.ModList and self.DownloaderType.ModCopy or self.DownloaderType.Template
  for k, v in pairs(ModList) do
    if not self:DownloadRes(ModLoaderType, v, true, nil, batchId) then
      bFinish = false
    end
  end
  if self._batchPending[batchId] == 0 then
    self._batchPending[batchId] = nil
  end
  return bFinish
end

function Logic_UGC_Res_Manager:BatchPauseRes(LoaderType, ModList)
  local ModLoaderType = LoaderType == self.DownloaderType.ModList and self.DownloaderType.ModCopy or self.DownloaderType.Template
  for k, v in pairs(ModList) do
    self:PauseRes(ModLoaderType, v)
  end
end

function Logic_UGC_Res_Manager:BatchGetResSize(LoaderType, ModList)
  local cSize, tSize = 0, 0
  if LoaderType == self.DownloaderType.ModList then
    cSize, tSize = self:_GetUGCModListSize(ModList)
  elseif LoaderType == self.DownloaderType.TemplateList then
    cSize, tSize = self:_GetUGCTemplateListSize(ModList)
  end
  return cSize, tSize
end

function Logic_UGC_Res_Manager:GetPackListState(PackList, NeedEditRes)
  local State = LogicPufferBundle.GetPackListState(PackList, false)
  if NeedEditRes then
    local BasicMapState = PufferManager.GetState(PufferConst.ENUM_DownloadType.MAP, {
      PufferConst.UGC_BASIC_MAPKEY
    })
    State = PufferManager.GetMixDownloadState(State, BasicMapState)
    local EditorMapState = PufferManager.GetState(PufferConst.ENUM_DownloadType.MAP, {
      PufferConst.UGC_EDIT_MAPKEY
    })
    State = PufferManager.GetMixDownloadState(State, EditorMapState)
  end
  return State
end

function Logic_UGC_Res_Manager:DownloadPackList(PackList, NeedEditRes)
  LogicPufferBundle.DownloadPackList(PackList)
  if NeedEditRes then
    PufferManager.Download(PufferConst.ENUM_DownloadType.MAP, {
      PufferConst.UGC_BASIC_MAPKEY,
      PufferConst.UGC_EDIT_MAPKEY
    }, PufferTlog.Enum_TLog_From.UGC, nil, defaultExtraParams)
  end
end

function Logic_UGC_Res_Manager:PausePackList(PackList, NeedEditRes)
  LogicPufferBundle.StopDownloadPackList(PackList)
  if NeedEditRes then
    PufferManager.Pause(PufferConst.ENUM_DownloadType.MAP, {
      PufferConst.UGC_BASIC_MAPKEY
    })
    PufferManager.Pause(PufferConst.ENUM_DownloadType.MAP, {
      PufferConst.UGC_EDIT_MAPKEY
    })
  end
end

function Logic_UGC_Res_Manager:GetPackListSize(PackList, bNeedEditRes)
  local cSize, tSize = LogicPufferBundle.GetPackListSize(PackList)
  if bNeedEditRes then
    local cMapSize, tMapSize = self:_GetUGCBasicResSize()
    cSize = cSize + cMapSize
    tSize = tSize + tMapSize
    cMapSize, tMapSize = self:_GetUGCEditResSize()
    cSize = cSize + cMapSize
    tSize = tSize + tMapSize
  end
  return cSize, tSize
end

function Logic_UGC_Res_Manager:IsCompleteUGCTemplateResByTeam(TemplateId, CustomAssetList)
  local State = self:GetUGCBundleState()
  if State ~= PufferConst.ENUM_DownloadState.Done then
    log(bWriteLog and "Logic_UGC_Res_Manager:IsCompleteUGCTemplateResByTeam UGCBundle not download")
    return false
  end
  local MapKey = self:GetUGCMapKeyByTemplateId(TemplateId)
  State = PufferManager.GetState(PufferConst.ENUM_DownloadType.MAP, {MapKey})
  if State ~= PufferConst.ENUM_DownloadState.Done then
    log(bWriteLog and "Logic_UGC_Res_Manager:IsCompleteUGCTemplateResByTeam mapKey not download")
    return false
  end
  if CustomAssetList then
    local LogicUGCAssetHub = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAssetHub)
    State = LogicUGCAssetHub:GetAssetStateByList(CustomAssetList)
    if State ~= PufferConst.ENUM_DownloadState.Done then
      log(bWriteLog and "Logic_UGC_Res_Manager:IsCompleteUGCTemplateResByTeam CustomAssetList not download")
      return false
    end
  end
  return true
end

function Logic_UGC_Res_Manager:GetUGCTemplateResStateByTeam(TemplateId, CustomAssetList)
  local MapKey = self:GetUGCMapKeyByTemplateId(TemplateId)
  local State = PufferManager.GetState(PufferConst.ENUM_DownloadType.MAP, {MapKey})
  if State == PufferConst.ENUM_DownloadState.Done then
    State = self:GetUGCBundleState()
    if State == PufferConst.ENUM_DownloadState.Done and CustomAssetList then
      local LogicUGCAssetHub = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAssetHub)
      State = LogicUGCAssetHub:GetAssetStateByList(CustomAssetList)
    end
  end
  return State
end

function Logic_UGC_Res_Manager:DownloadTemplateResByTeam(TemplateId, CustomAssetList, CustomAssetDownloadSeq)
  local cacheKey = self:_GetCacheKeyByTemplateInfoID(TemplateId)
  local cacheInfo = self:GetUGCModCacheInfo(cacheKey)
  cacheInfo.state = PufferConst.ENUM_DownloadState.Download
  local MapKey = self:GetUGCMapKeyByTemplateId(TemplateId)
  local MapState = PufferManager.GetState(PufferConst.ENUM_DownloadType.MAP, {MapKey})
  if MapState ~= PufferConst.ENUM_DownloadState.Done then
    PufferManager.Download(PufferConst.ENUM_DownloadType.MAP, {MapKey}, PufferTlog.Enum_TLog_From.UGC, nil, defaultExtraParams)
    cacheInfo.mapKey = MapKey
    log(bWriteLog and "Logic_UGC_Res_Manager:GetUGCTemplateResStateByTeam MapKey not finish:" .. MapKey)
  end
  if self:GetUGCBundleState() ~= PufferConst.ENUM_DownloadState.Done then
    cacheInfo.bundleKey = PufferConst.UGC_BUNDLE_ID
    LogicPufferBundle.DownloadBundle(PufferConst.UGC_BUNDLE_ID)
    log(bWriteLog and "Logic_UGC_Res_Manager:GetUGCTemplateResStateByTeam bundle res not finish")
  end
  if CustomAssetList then
    local LogicUGCAssetHub = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAssetHub)
    if LogicUGCAssetHub:GetAssetStateByList(CustomAssetList) ~= PufferConst.ENUM_DownloadState.Done then
      LogicUGCAssetHub:DownloadList(CustomAssetList, CustomAssetDownloadSeq)
      log(bWriteLog and "Logic_UGC_Res_Manager:GetUGCTemplateResStateByTeam CustomAssetList not finish")
    end
  end
end

function Logic_UGC_Res_Manager:PauseTemplateResByTeam(TemplateId, CustomAssetList, CustomAssetDownloadSeq)
  local cacheKey = self:_GetCacheKeyByTemplateInfoID(TemplateId)
  local cacheInfo = self:GetUGCModCacheInfo(cacheKey)
  cacheInfo.state = PufferConst.ENUM_DownloadState.Pause
  local cacheInfos = self.modResCaches
  local ExistOtherMapKey = false
  if cacheInfo.mapKey then
    for mK, mV in pairs(cacheInfos) do
      if mV.state == PufferConst.ENUM_DownloadState.Download and mV.mapKey == cacheInfo.mapKey then
        ExistOtherMapKey = true
        break
      end
    end
    if not ExistOtherMapKey then
      PufferManager.Pause(PufferConst.ENUM_DownloadType.MAP, {
        cacheInfo.mapKey
      })
    end
  end
  local ExistBundle = false
  if cacheInfo.bundleKey then
    for mK, mV in pairs(cacheInfos) do
      if mV.state == PufferConst.ENUM_DownloadState.Download and mV.bundleKey then
        ExistBundle = true
        break
      end
    end
    if not ExistBundle then
      LogicPufferBundle.StopDownloadBundle(PufferConst.UGC_BUNDLE_ID)
    end
  end
  if CustomAssetList and CustomAssetDownloadSeq then
    local LogicUGCAssetHub = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAssetHub)
    LogicUGCAssetHub:PauseList(CustomAssetDownloadSeq)
  end
end

function Logic_UGC_Res_Manager:GetUGCTemplateResSizeByTeam(TemplateId, CustomAssetList)
  local MapKey = self:GetUGCMapKeyByTemplateId(TemplateId)
  local cSize, tSize = PufferManager.GetSize(PufferConst.ENUM_DownloadType.MAP, {MapKey})
  cSize = cSize / PufferConst.MB
  tSize = tSize / PufferConst.MB
  local bcSize, btSize = self:GetUGCBundleSize()
  cSize = cSize + bcSize
  tSize = tSize + btSize
  if CustomAssetList then
    local LogicUGCAssetHub = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAssetHub)
    local ccSize, ctSize = LogicUGCAssetHub:GetAssetSizeByList(CustomAssetList)
    return cSize + ccSize, tSize + ctSize, tSize - cSize, ctSize - ccSize
  else
    return cSize, tSize, tSize - cSize, 0
  end
end

function Logic_UGC_Res_Manager:GetUGCModInfoPakSizeAndNameList(modInfo, bMyWork, bNeedEditRes)
  if not modInfo or modInfo.base == nil or modInfo.base.template_id == nil then
    return 0, 0, {}
  end
  local pakList = {}
  local MinNotDoneSize = 0.005
  local mapKeyList = self:GetAllMapKeysByModInfo(modInfo)
  local excludeMapKey, AllAssetIDList, AllFeatureKeyList, AllResKeyList
  if bMyWork then
    AllAssetIDList, AllFeatureKeyList = self:_GetNotPublishModResList(modInfo)
  else
    AllAssetIDList, AllFeatureKeyList, AllResKeyList = self:GetAllResList(modInfo)
    excludeMapKey = self:GetExcludeMapKey(modInfo, AllAssetIDList)
  end
  local cSize, tSize = PufferManager.GetSize(PufferConst.ENUM_DownloadType.MAP, mapKeyList, nil, excludeMapKey, true)
  cSize = cSize / PufferConst.MB
  tSize = tSize / PufferConst.MB
  if mapKeyList and 0 < #mapKeyList then
    log(bWriteLog and string.format("Logic_UGC_Res_Manager:GetUGCModInfoPakSizeAndNameList mapKeyList count:%d, cSize:%.2f, tSize:%.2f", #mapKeyList, cSize, tSize))
    local PufferMapManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager)
    local mapCheckList = {}
    for _, mk in ipairs(mapKeyList) do
      if not mapCheckList[mk] then
        local mkCSize, mkTSize = PufferMapManager:GetSize(mk, nil, mapCheckList, excludeMapKey)
        mkCSize = mkCSize / PufferConst.MB
        mkTSize = mkTSize / PufferConst.MB
        local mapConfig = CDataTable.GetTableData("MapPakTable", mk)
        if mapConfig and MinNotDoneSize < mkTSize - mkCSize then
          table.insert(pakList, {
            pakName = mapConfig.name,
            cSize = mkCSize,
            tSize = mkTSize,
            pakId = 0
          })
        end
      end
    end
  else
    log(bWriteLog and "Logic_UGC_Res_Manager:GetUGCModInfoPakSizeAndNameList mapKeyList is empty")
  end
  local PufferODPakManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_manager)
  local cFeatureSize, tFeatureSize = PufferODPakManager:GetSizeByKeyList(PufferConst.ENUM_DownloadType.ODPAK, AllFeatureKeyList)
  cSize = cSize + cFeatureSize / PufferConst.MB
  tSize = tSize + tFeatureSize / PufferConst.MB
  local PufferUGCPakManager = self:_GetPufferUGCPakManager()
  local cAssetSize, tAssetSize, idpakSizeList = PufferUGCPakManager:GetSizeByKeyList(PufferConst.ENUM_DownloadType.UGCPAK, AllAssetIDList, true, true)
  cSize = cSize + cAssetSize / PufferConst.MB
  tSize = tSize + tAssetSize / PufferConst.MB
  if AllResKeyList and 0 < #AllResKeyList then
    local cResSize, tResSize = PufferManager.GetSize(PufferConst.ENUM_DownloadType.RES, AllResKeyList)
    cSize = cSize + cResSize / PufferConst.MB
    tSize = tSize + tResSize / PufferConst.MB
  end
  if idpakSizeList then
    for pakId, sizes in pairs(idpakSizeList) do
      local pakConfig = CDataTable.GetTableData("PakInfoTable", pakId)
      if pakConfig and MinNotDoneSize < sizes.tSize - sizes.cSize then
        local pakCsize = sizes.cSize / PufferConst.MB
        local pakTsize = sizes.tSize / PufferConst.MB
        table.insert(pakList, {
          pakName = pakConfig.PakName,
          cSize = pakCsize,
          tSize = pakTsize,
          pakId = pakId
        })
      end
    end
  end
  if bNeedEditRes then
    local cEditSize, tEditSize = self:_GetUGCEditResSize()
    cSize = cSize + cEditSize
    tSize = tSize + tEditSize
    if MinNotDoneSize < tEditSize - cEditSize then
      table.insert(pakList, {
        pakName = LocUtil.GetLocalizeResStr(99020001),
        cSize = cEditSize,
        tSize = tEditSize,
        pakId = 0
      })
    end
  end
  log_tree("Logic_UGC_Res_Manager:GetUGCModInfoPakSizeAndNameList pakList", pakList)
  return cSize, tSize, pakList
end

function Logic_UGC_Res_Manager:GetUGCMapKeyByTemplateId(templateId, mapID)
  local mapConfig = self:_GetUGCMapConfigByTemplateId(templateId, mapID)
  if mapConfig then
    return mapConfig.MapKey
  end
  return nil
end

function Logic_UGC_Res_Manager:GetAllMapKeysByModInfo(modInfo)
  local mapKeyList = {}
  local mapKeySet = {}
  if modInfo and modInfo.base and modInfo.base.template_id then
    local baseMapKey = self:GetUGCMapKeyByTemplateId(modInfo.base.template_id)
    if baseMapKey then
      mapKeySet[baseMapKey] = true
      table.insert(mapKeyList, baseMapKey)
    end
  end
  local allLevelRes = TableUtil.GetTableValue(modInfo, "setting", "all_level_res")
  if allLevelRes then
    for _, levelRes in pairs(allLevelRes) do
      if levelRes and levelRes.template_id then
        local levelMapKey = self:GetUGCMapKeyByTemplateId(levelRes.template_id)
        if levelMapKey and not mapKeySet[levelMapKey] then
          mapKeySet[levelMapKey] = true
          table.insert(mapKeyList, levelMapKey)
        end
      end
    end
  end
  return mapKeyList
end

function Logic_UGC_Res_Manager:GetUGCBundleSize(bIncludeMap)
  local cSize, tSize, pak_list = LogicPufferBundle.GetBundleSize(PufferConst.UGC_BUNDLE_ID)
  if not bIncludeMap then
    local BasicCSize, BasicTSize = self:_GetUGCBasicResSize()
    cSize = cSize - BasicCSize
    tSize = tSize - BasicTSize
    for i, v in pairs(pak_list) do
      if v.pakName == "pak_mix_wow_newbie" then
        v.cSize = v.cSize - BasicCSize
        v.tSize = v.tSize - BasicTSize
      end
    end
  end
  return cSize, tSize, pak_list
end

function Logic_UGC_Res_Manager:GetUGCBundleState()
  local State = LogicPufferBundle.GetBundleState(PufferConst.UGC_BUNDLE_ID)
  return State
end

function Logic_UGC_Res_Manager:DownloadUGCBundle()
  LogicPufferBundle.DownloadBundle(PufferConst.UGC_BUNDLE_ID)
end

function Logic_UGC_Res_Manager:PauseUGCBundle()
  LogicPufferBundle.StopDownloadBundle(PufferConst.UGC_BUNDLE_ID)
end

function Logic_UGC_Res_Manager:_GetCacheDepends(ModInfo, bMyWork)
  if not (ModInfo and ModInfo.base) or not ModInfo.setting then
    return nil, nil
  end
  local TemplateID = ModInfo.base.template_id
  local CacheKey = self:_GetCacheKeyByModInfo(ModInfo, bMyWork)
  if CacheKey then
    local CacheInfo = self:GetUGCModCacheInfo(CacheKey)
    if CacheInfo.version == ModInfo.base.verify_time and CacheInfo.depends then
      return CacheInfo.depends, CacheInfo.dependFeatures, CacheInfo.dependRes
    else
      if TemplateID then
        local LogicUGCTemplate = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCTemplate)
        local bIsSkipDownload = LogicUGCTemplate:CheckIsSkipDownloadTemplate(TemplateID)
        if bIsSkipDownload then
          CacheInfo.depends = {}
          CacheInfo.dependFeatures = {}
          CacheInfo.dependRes = {}
          return CacheInfo.depends, CacheInfo.dependFeatures, CacheInfo.dependRes
        end
      end
      local AssetIDList = self:GetDependIdsByIntMap(ModInfo.setting.res_list, TemplateID and Config_UGC.SkipForceDependTemplateIDs[TemplateID])
      local AssetParamList = self:GetDependAssetParamsByIntMap(ModInfo.setting.feature_id_list)
      local levelAssetIDList, levelAssetParamList = self:_GetAllLevelResDepends(ModInfo)
      if levelAssetIDList then
        local existAssetIDMap = {}
        for _, v in ipairs(AssetIDList) do
          existAssetIDMap[v] = true
        end
        for _, v in ipairs(levelAssetIDList) do
          if not existAssetIDMap[v] then
            existAssetIDMap[v] = true
            table.insert(AssetIDList, v)
          end
        end
      end
      if levelAssetParamList then
        local existParamMap = {}
        for _, v in ipairs(AssetParamList) do
          existParamMap[v] = true
        end
        for _, v in ipairs(levelAssetParamList) do
          if not existParamMap[v] then
            existParamMap[v] = true
            table.insert(AssetParamList, v)
          end
        end
      end
      CacheInfo.depends, CacheInfo.dependFeatures, CacheInfo.dependRes = self:_GetAssetIDAndFeatureList(ModInfo, AssetIDList, AssetParamList)
      CacheInfo.version = ModInfo.base.verify_time
      return CacheInfo.depends, CacheInfo.dependFeatures, CacheInfo.dependRes
    end
  end
  if TemplateID and Config_UGC.SkipForceDependTemplateIDs[TemplateID] then
    return nil, nil
  end
  return Config_UGC.ForceDependAssetIDList, nil
end

function Logic_UGC_Res_Manager:_GetAssetIDAndFeatureList(ModInfo, AssetIDList, AssetParamList)
  local AllAssetIDMap = {}
  local AllFeatureKeyMap = {}
  for k, v in pairs(AssetIDList) do
    AllAssetIDMap[v] = true
  end
  local bIsPublishMod = self:_IsPublishMod(ModInfo)
  local PufferUGCPakManager = self:_GetPufferUGCPakManager()
  for _, AssetID in pairs(AssetIDList) do
    local DependFeatureKeys = PufferUGCPakManager:GetNecessaryFeatureDepends(AssetID)
    for k, v in pairs(DependFeatureKeys) do
      AllFeatureKeyMap[v] = true
    end
  end
  if bIsPublishMod then
    local bIsNewMeta, MetaVersion = self:_IsNewMeta(ModInfo)
    if bIsNewMeta and AssetParamList then
      local DependFeatureKeysList, DependAssetIDList = self:_GetAssetParamDepends(AssetParamList)
      for k, v in pairs(DependAssetIDList) do
        AllAssetIDMap[v] = true
      end
      for k, v in pairs(DependFeatureKeysList) do
        AllFeatureKeyMap[v] = true
      end
    else
      for _, AssetID in pairs(AssetIDList) do
        local DependFeatureKeys, DependAssetIDs = PufferUGCPakManager:GetDepends(AssetID)
        for k, v in pairs(DependAssetIDs) do
          AllAssetIDMap[v] = true
        end
        for k, v in pairs(DependFeatureKeys) do
          AllFeatureKeyMap[v] = true
        end
      end
    end
    for Version, PatchInfo in pairs(Config_UGC.BeforeVersionPatchResList) do
      if MetaVersion < Version then
        for k, v in pairs(PatchInfo.AssetIDList) do
          AllAssetIDMap[v] = true
        end
        for k, v in pairs(PatchInfo.FeatureKeyList) do
          AllFeatureKeyMap[v] = true
        end
      end
    end
    local PatchInfo = Config_UGC.PatchResList[MetaVersion]
    if PatchInfo then
      for k, v in pairs(PatchInfo.AssetIDList) do
        AllAssetIDMap[v] = true
      end
      for k, v in pairs(PatchInfo.FeatureKeyList) do
        AllFeatureKeyMap[v] = true
      end
    end
  else
    for _, AssetID in pairs(AssetIDList) do
      local DependFeatureKeys, DependAssetIDs = PufferUGCPakManager:GetDepends(AssetID)
      for k, v in pairs(DependAssetIDs) do
        AllAssetIDMap[v] = true
      end
      for k, v in pairs(DependFeatureKeys) do
        AllFeatureKeyMap[v] = true
      end
    end
  end
  for AssetID, FeatureKeys in pairs(Config_UGC.AssetDependFeatureKey) do
    if AllAssetIDMap[AssetID] then
      for k, v in pairs(FeatureKeys) do
        AllFeatureKeyMap[v] = true
      end
    end
  end
  local AllResKeyMap = {}
  if self.bIsFitVersion then
    for AssetID, ResKeys in pairs(Config_UGC.AssetDependResKey) do
      if AllAssetIDMap[AssetID] then
        for k, v in pairs(ResKeys) do
          AllResKeyMap[v] = true
        end
      end
    end
  end
  local TemplateID = ModInfo.base and ModInfo.base.template_id
  if TemplateID and Config_UGC.SkipForceDependTemplateIDs[TemplateID] then
  else
    AllFeatureKeyMap.skill_SpecialWater = true
    AllFeatureKeyMap.Skill_IceRoad = true
  end
  local AllAssetIDList = {}
  local AllFeatureKeyList = {}
  local AllResKeyList
  for k, v in pairs(AllAssetIDMap) do
    table.insert(AllAssetIDList, k)
  end
  for k, v in pairs(AllFeatureKeyMap) do
    table.insert(AllFeatureKeyList, k)
  end
  if AllResKeyMap and next(AllResKeyMap) then
    AllResKeyList = {}
    for k, v in pairs(AllResKeyMap) do
      table.insert(AllResKeyList, k)
    end
  end
  return AllAssetIDList, AllFeatureKeyList, AllResKeyList
end

function Logic_UGC_Res_Manager:GetDependIdsByIntMap(resList, bSkipForceDepend)
  resList = resList or {}
  local bitList = {}
  local size = 32
  for k, v in pairs(resList) do
    if v and 0 < v then
      local margin = size * (k - 1)
      local tmpList = FuncUtil.Int2ByteList(v)
      if tmpList ~= nil then
        for bitKey, bitV in ipairs(tmpList) do
          bitV = bitV + margin
          table.insert(bitList, bitV)
        end
      end
    end
  end
  local idList = {}
  local expiredIdList = {}
  for k, v in ipairs(bitList) do
    local assertConfig = self.UGCAssetConfigIDMap[v]
    if assertConfig and assertConfig.AssetID then
      local CreativeExpiredAssetConfig = require("GameLua.Mod.BaseMod.GamePlay.Config.CreativeExpiredAssetConfig")
      local bExpired = CreativeExpiredAssetConfig.IsCurVersionExpired(assertConfig.AssetID)
      if not bExpired then
        table.insert(idList, assertConfig.AssetID)
      else
        table.insert(expiredIdList, assertConfig.AssetID)
      end
    end
  end
  if not bSkipForceDepend then
    for k, v in pairs(Config_UGC.ForceDependAssetIDList) do
      table.insert(idList, v)
    end
  end
  return idList, expiredIdList
end

function Logic_UGC_Res_Manager:Send_update_client_mod_info_ByModInfo(modInfo, isTick, bReportPauseState, lastState)
  local isLoaded = false
  if modInfo.mod_id then
    if self:GetResState(self.DownloaderType.ModCopy, modInfo) == PufferConst.ENUM_DownloadState.Done then
      isLoaded = true
    end
    log(bWriteLog and string.format("Logic_UGC_Res_Manager:Send_update_client_mod_info_ByModInfo --- is mod id:%s ,isLoaded:%s", tostring(modInfo.mod_id), tostring(isLoaded)))
  else
    if self:GetResState(self.DownloaderType.MyWork, modInfo) == PufferConst.ENUM_DownloadState.Done then
      isLoaded = true
    end
    log(bWriteLog and string.format("Logic_UGC_Res_Manager:Send_update_client_mod_info_ByModInfo --- is not mod templateid:%d ,,isLoaded:%s", modInfo.base.template_id, tostring(isLoaded)))
  end
  local report_mod_info = {}
  local modIdStr
  if modInfo.mod_id then
    modIdStr = modInfo.mod_id
  else
    modIdStr = tostring(modInfo.base.uid) .. "_" .. tostring(modInfo.base.slot)
  end
  local cur_state = 0
  local last_state = lastState or 0
  if isLoaded then
    report_mod_info[modIdStr] = 3
    cur_state = 3
    self:_RemoveReportResTimer()
    log(bWriteLog and string.format("Logic_UGC_Res_Manager:Send_update_client_mod_info_ByModInfo --- finish mod id:%s", modIdStr))
  else
    if bReportPauseState == nil or bReportPauseState == false then
      report_mod_info[modIdStr] = 1
      cur_state = 1
    else
      cur_state = self:GetResState(self.DownloaderType.ModCopy, modInfo)
      report_mod_info[modIdStr] = cur_state
    end
    log(bWriteLog and string.format("Logic_UGC_Res_Manager:Send_update_client_mod_info_ByModInfo --- unfinish mod id:%s", modIdStr))
  end
  local UGCModHandler = require("client.network.Protocol.UGCModHandler")
  if isTick == nil or isTick == false then
    UGCModHandler.send_update_client_mod_info(report_mod_info)
    self.reportedModStateCaches[modIdStr] = cur_state
    log(bWriteLog and "Logic_UGC_Res_Manager:Send_update_client_mod_info_ByModInfo ---")
  elseif isTick == true and (isLoaded == true or bReportPauseState == true and cur_state ~= last_state) then
    UGCModHandler.send_update_client_mod_info(report_mod_info)
    self.reportedModStateCaches[modIdStr] = cur_state
  end
  log(bWriteLog and "Logic_UGC_Res_Manager:Send_update_client_mod_info_ByModInfo cur_state = " .. cur_state .. " last_state = " .. last_state .. " bReportPauseState = " .. tostring(bReportPauseState))
  if isLoaded == false then
    self:_CheckReportResState(modInfo, bReportPauseState, cur_state)
  end
end

function Logic_UGC_Res_Manager:FlushReportResStateImmediate(modInfo)
  if modInfo == nil or self.reportTimer == nil then
    return false
  end
  log(bWriteLog and "Logic_UGC_Res_Manager:FlushReportResStateImmediate flush res state report")
  self:Send_update_client_mod_info_ByModInfo(modInfo, nil, self.bReportPauseState)
  return true
end

function Logic_UGC_Res_Manager:Send_update_client_mod_info_ByTeamRes(LeaderUid, State)
  if LeaderUid then
    local ReportModInfo = {}
    local ModIDStr = tostring(LeaderUid) .. "_0"
    ReportModInfo[ModIDStr] = State
    log(bWriteLog and string.format("Logic_UGC_Res_Manager:Send_update_client_mod_info_ByTeamRes --- State:%d, mod id:%s", State, ModIDStr))
    local UGCModHandler = require("client.network.Protocol.UGCModHandler")
    UGCModHandler.send_update_client_mod_info(ReportModInfo)
  else
    log(bWriteLog and "this leader's uid is nil")
  end
end

function Logic_UGC_Res_Manager:Send_update_client_mod_info_NewbieGuideTemplate(template_id)
  if not template_id then
    log(bWriteLog and "Logic_UGC_Res_Manager:Send_update_client_mod_info_NewbieGuideTemplate no template_id")
    return
  end
  local isLoaded = self:_IsCompleteUGCTemplateRes(template_id)
  local report_mod_info = {}
  local modIdStr = "novice_" .. tostring(template_id)
  if isLoaded then
    report_mod_info[modIdStr] = PufferConst.ENUM_DownloadState.Done
    log(bWriteLog and string.format("Logic_UGC_Res_Manager:Send_update_client_mod_info_NewbieGuideTemplate --- finish:%s", modIdStr))
  else
    log(bWriteLog and string.format("Logic_UGC_Res_Manager:Send_update_client_mod_info_NewbieGuideTemplate --- unfinish:%s", modIdStr))
    report_mod_info[modIdStr] = PufferConst.ENUM_DownloadState.Download
  end
  local UGCModHandler = require("client.network.Protocol.UGCModHandler")
  UGCModHandler.send_update_client_mod_info(report_mod_info)
end

function Logic_UGC_Res_Manager:CheckReportCurUGCModState()
  local LogicUGCMatch = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch)
  local MatchInfo = LogicUGCMatch:GetMatchInfo()
  if not MatchInfo then
    return
  end
  local ModID = MatchInfo.mod_id
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  if LogicUGC:GetModIsBan(ModID) then
    return
  end
  local ModInfoList = LogicUGC:BatchGetModInfo({ModID}, LogicUGC.C_ModListTypes.UgcMatch, nil, {bNotPostEvent = true})
  if ModInfoList and next(ModInfoList) then
    self:OnModInfoBatchRsp(ModInfoList, LogicUGC.C_ModListTypes.UgcMatch)
  end
end

function Logic_UGC_Res_Manager:ReportModStateIfLocalDone(modInfo)
  if not modInfo or not modInfo.mod_id then
    return false
  end
  if not self:IsCompleteRes(self.DownloaderType.ModCopy, modInfo) then
    return false
  end
  log(bWriteLog and string.format("Logic_UGC_Res_Manager:ReportModStateIfLocalDone mod id:%s", tostring(modInfo.mod_id)))
  self:Send_update_client_mod_info_ByModInfo(modInfo)
  return true
end

function Logic_UGC_Res_Manager:ReportModListStateIfLocalDone(modIDList)
  if not modIDList or #modIDList == 0 then
    return
  end
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  local report_mod_info = {}
  local nReportCount = 0
  for _, ModID in ipairs(modIDList) do
    local ModInfo = LogicUGC:GetModByAllCache(ModID)
    if ModInfo and ModInfo.pub_mod_meta then
      ModInfo = ModInfo.pub_mod_meta
    end
    if ModInfo and ModInfo.mod_id and self.reportedModStateCaches[ModInfo.mod_id] ~= PufferConst.ENUM_DownloadState.Done and self:IsCompleteRes(self.DownloaderType.ModCopy, ModInfo) then
      report_mod_info[ModInfo.mod_id] = PufferConst.ENUM_DownloadState.Done
      self.reportedModStateCaches[ModInfo.mod_id] = PufferConst.ENUM_DownloadState.Done
      nReportCount = nReportCount + 1
    end
  end
  if 0 < nReportCount then
    log(bWriteLog and string.format("Logic_UGC_Res_Manager:ReportModListStateIfLocalDone count:%d", nReportCount))
    local UGCModHandler = require("client.network.Protocol.UGCModHandler")
    UGCModHandler.send_update_client_mod_info(report_mod_info)
  end
end

function Logic_UGC_Res_Manager:GetUGCModCacheInfo(cacheKey)
  local cacheInfos = self.modResCaches
  local modCacheInfo = cacheInfos[cacheKey]
  if modCacheInfo == nil then
    modCacheInfo = {
      state = PufferConst.ENUM_DownloadState.Not
    }
    local state = self.modStateCaches[cacheKey]
    if state then
      modCacheInfo.state = state
    end
    cacheInfos[cacheKey] = modCacheInfo
  end
  return modCacheInfo
end

function Logic_UGC_Res_Manager:ClearCacheInfos()
  self.modResCaches = {}
  self.modStateCaches = {}
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  PlayerPrefsSystem.SaveTableToFile_N(self.modStateCaches, PlayerPrefsSystem.ePlayerPrefsType.eUGCCacheLoadState)
  EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_CACHE_CLEAR)
end

function Logic_UGC_Res_Manager:GetExcludeMapKey(modInfo, idList)
  local excludeMapKey = {}
  if not self.bOptimizeMapDownload then
    return excludeMapKey
  end
  if modInfo.mod_id and idList then
    local NeedDinosaurCore = false
    local NeedDestructible = true
    for k, v in pairs(idList) do
      if v == 987654321 then
        NeedDestructible = false
      end
      if v == 3101032 or v == 3101043 then
        NeedDinosaurCore = true
      end
    end
    if not NeedDestructible then
      excludeMapKey.map_creativedestructible = true
    end
    if not NeedDinosaurCore then
      excludeMapKey.map_dinosaurcore = true
    end
    printf(bWriteLog and "Logic_UGC_Res_Manager:GetExcludeMapKey mod_id = %d, NeedDinosaurCore = %s, NeedDestructible = %s", modInfo.mod_id, NeedDinosaurCore, NeedDestructible)
  end
  return excludeMapKey
end

function Logic_UGC_Res_Manager:SendTLogUIOperate(key, modInfo, TLogFrom, extraParams, force)
  local extra = {}
  local TimeUtil = require("client.common.time_util")
  local serverTime = TimeUtil.GetServerTimeInSec()
  local startTimeStr = TimeUtil.OSDate("!%Y-%m-%d %H:%M:%S", serverTime)
  extra.time = startTimeStr
  if TLogFrom then
    if extraParams then
      for k, v in pairs(extraParams) do
        extra[k] = v
      end
    end
    PufferTlog.SendTLog(TLogFrom, PufferTlog.Enum_TLog_Optype.UIOperate, key, extra, force)
    return
  end
  if modInfo then
    if modInfo.mod_id then
      extra.type = "mod"
      extra.id = modInfo.mod_id
    elseif modInfo.base and modInfo.base.slot then
      extra.type = "work"
      extra.id = modInfo.base.slot
    elseif modInfo.ID then
      extra.type = "template"
      extra.id = modInfo.ID
    end
    if modInfo.setting and modInfo.setting.name then
      extra.name = modInfo.setting.name
    elseif modInfo.DefaultCreateName then
      extra.name = modInfo.DefaultCreateName
    end
    if extraParams then
      for k, v in pairs(extraParams) do
        extra[k] = v
      end
    end
    PufferTlog.SendTLog(PufferTlog.Enum_TLog_From.UGCMode, PufferTlog.Enum_TLog_Optype.UIOperate, key, extra, force)
  end
end

function Logic_UGC_Res_Manager:SendTLogUGCResCenterOperate(key)
  local lastTime = self:_GetTlogLastTimeByKey(key)
  local TimeUtil = require("client.common.time_util")
  local curTime = TimeUtil.GetServerTimeInSec()
  local isSameDay = TimeUtil.IsSameDay(lastTime, curTime)
  if isSameDay ~= true then
    local extra = {}
    PufferTlog.SendTLog(PufferTlog.Enum_TLog_From.UGCMode, PufferTlog.Enum_TLog_Optype.UIOperate, key, extra)
    self:_SaveTlogTime(key)
  end
end

function Logic_UGC_Res_Manager:IsTemplate(ModInfo)
  if ModInfo.ResList then
    return true
  end
  return false
end

function Logic_UGC_Res_Manager:GetAllResList(ModInfo, bMyWork)
  local AllAssetIDList = {}
  local AllFeatureKeyList = {}
  local AllResKeyList = {}
  if self:IsTemplate(ModInfo) then
    local TemplateID = ModInfo.ID
    local IDList = self:GetDependIdsByIntMap(ModInfo.ResList, TemplateID and Config_UGC.SkipForceDependTemplateIDs[TemplateID])
    AllAssetIDList, AllFeatureKeyList, AllResKeyList = self:_GetAssetIDAndFeatureList(ModInfo, IDList)
  else
    AllAssetIDList, AllFeatureKeyList, AllResKeyList = self:_GetCacheDepends(ModInfo, bMyWork)
  end
  return AllAssetIDList, AllFeatureKeyList, AllResKeyList
end

function Logic_UGC_Res_Manager:GetModDownloadInfo(ModInfo, bAddAttachFile)
  local modVersion = self:_GetModVersion(ModInfo)
  print(bWriteLog and "Logic_UGC_Res_Manager:GetModDownloadInfo ModID:" .. tostring(ModInfo.mod_id) .. ",version:" .. tostring(modVersion))
  if bAddAttachFile then
    Client.AddAttachFileString("GetModDownloadInfo", true, "ModID:" .. tostring(ModInfo.mod_id) .. ",version:" .. tostring(modVersion))
  end
  local DebugInfo = ""
  local SplitChar = "|"
  if ModInfo.setting then
    local idList = self:GetDependIdsByIntMap(ModInfo.setting.res_list)
    local AssetParamList = self:GetDependAssetParamsByIntMap(ModInfo.setting.feature_id_list)
    local levelAssetIDList, levelAssetParamList = self:_GetAllLevelResDepends(ModInfo)
    if levelAssetIDList then
      local existIdMap = {}
      for _, v in ipairs(idList) do
        existIdMap[v] = true
      end
      for _, v in ipairs(levelAssetIDList) do
        if not existIdMap[v] then
          existIdMap[v] = true
          table.insert(idList, v)
        end
      end
    end
    if levelAssetParamList then
      local existParamMap = {}
      for _, v in ipairs(AssetParamList) do
        existParamMap[v] = true
      end
      for _, v in ipairs(levelAssetParamList) do
        if not existParamMap[v] then
          existParamMap[v] = true
          table.insert(AssetParamList, v)
        end
      end
    end
    if idList then
      DebugInfo = "res_list:("
      for k, v in pairs(idList) do
        DebugInfo = DebugInfo .. tostring(v) .. SplitChar
      end
    end
    DebugInfo = DebugInfo .. ")        "
    if AssetParamList then
      DebugInfo = DebugInfo .. "asset_param_list:("
      for k, v in pairs(AssetParamList) do
        DebugInfo = DebugInfo .. tostring(v) .. SplitChar
      end
      DebugInfo = DebugInfo .. ")        "
    end
  end
  DebugInfo = DebugInfo .. "FeatureKey State Begin:("
  local AllAssetIDList, AllFeatureKeyList, AllResKeyList = self:GetAllResList(ModInfo)
  local PufferODPakManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_manager)
  for k, v in pairs(AllFeatureKeyList) do
    local KeyList = tablePool:Get()
    KeyList[1] = v
    local state = PufferODPakManager:GetStateByKeyList(PufferConst.ENUM_DownloadType.ODPAK, KeyList)
    local info = "" .. tostring(v) .. ":" .. state
    DebugInfo = DebugInfo .. info .. SplitChar
    tablePool:Recycle(KeyList)
  end
  DebugInfo = DebugInfo .. ")       AssetID State Begin:("
  local PufferUGCPakManager = self:_GetPufferUGCPakManager()
  for k, v in pairs(AllAssetIDList) do
    local KeyList = tablePool:Get()
    KeyList[1] = v
    local state = PufferUGCPakManager:GetStateByKeyList(PufferConst.ENUM_DownloadType.UGCPAK, KeyList, true)
    local info = "" .. tostring(v) .. ":" .. state
    DebugInfo = DebugInfo .. info .. SplitChar
    tablePool:Recycle(KeyList)
  end
  if AllResKeyList and 0 < #AllResKeyList then
    DebugInfo = DebugInfo .. ")       Res State Begin:("
    for k, v in pairs(AllResKeyList) do
      local KeyList = tablePool:Get()
      KeyList[1] = v
      local state = PufferManager:GetState(PufferConst.ENUM_DownloadType.RES, KeyList, true)
      local info = "" .. tostring(v) .. ":" .. state
      DebugInfo = DebugInfo .. info .. SplitChar
      tablePool:Recycle(KeyList)
    end
  end
  DebugInfo = DebugInfo .. ")"
  print(bWriteLog and "Logic_UGC_Res_Manager:GetModDownloadInfo DebugInfo:" .. DebugInfo)
  if bAddAttachFile then
    Client.AddAttachFileString("GetModDownloadInfo", false, "DebugInfo:" .. DebugInfo)
  end
  return DebugInfo
end

function Logic_UGC_Res_Manager:_GetResListForDump(loaderType, modInfo)
  if loaderType == self.DownloaderType.MyWork then
    local AssetIDList, FeatureKeyList = self:_GetNotPublishModResList(modInfo)
    local MapKeyList = self:GetAllMapKeysByModInfo(modInfo) or {}
    local MergedMapKeys = {}
    for _, v in ipairs(MapKeyList) do
      MergedMapKeys[#MergedMapKeys + 1] = v
    end
    MergedMapKeys[#MergedMapKeys + 1] = PufferConst.UGC_EDIT_MAPKEY
    return AssetIDList or {}, FeatureKeyList or {}, MergedMapKeys, nil
  end
  local AssetIDList, FeatureKeyList = self:GetAllResList(modInfo)
  local MapKeyList = self:GetAllMapKeysByModInfo(modInfo) or {}
  local ExcludeMapKey = self:GetExcludeMapKey(modInfo, AssetIDList)
  return AssetIDList or {}, FeatureKeyList or {}, MapKeyList, ExcludeMapKey
end

function Logic_UGC_Res_Manager:DumpModMissing(modInfo, sReason, loaderType)
  if not UGCLog.IsEnable() then
    return true
  end
  if not modInfo or not modInfo.base then
    UGCLog.Dump("DumpModMissing invalid modInfo. reason=%s", tostring(sReason))
    return false
  end
  loaderType = loaderType or self.DownloaderType.ModCopy
  local ENUM = PufferConst.ENUM_DownloadState
  local ModID = modInfo.mod_id or tostring(modInfo.base.uid) .. "_" .. tostring(modInfo.base.slot)
  local bAllDone = true
  UGCLog.Dump("========== DumpModMissing BEGIN reason=%s loaderType=%s modID=%s templateID=%s verifyTime=%s ==========", tostring(sReason or "manual"), tostring(loaderType), tostring(ModID), tostring(modInfo.base.template_id), tostring(modInfo.base.verify_time))
  self:DumpDownloadEnv()
  local AllAssetIDList, AllFeatureKeyList, mapKeyList, excludeMapKey = self:_GetResListForDump(loaderType, modInfo)
  if loaderType == self.DownloaderType.MyWork then
    local TeamUpNewSystem = require("client.slua.logic.teamup.logic_team_up")
    if TeamUpNewSystem.IsInTeam() then
      local BundleState = LogicPufferBundle.GetBundleState(PufferConst.UGC_BUNDLE_ID)
      UGCLog.Dump("modID=%s in team: uses UGC_BUNDLE whole-bundle download. bundleID=%s state=%s", tostring(ModID), tostring(PufferConst.UGC_BUNDLE_ID), UGCLog.StateName(BundleState))
      if BundleState ~= ENUM.Done then
        bAllDone = false
      end
    end
  end
  local PufferMapManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager)
  for _, mapKey in ipairs(mapKeyList or {}) do
    local mapState = PufferManager.GetState(PufferConst.ENUM_DownloadType.MAP, {mapKey}, nil, nil, excludeMapKey)
    if mapState ~= ENUM.Done then
      bAllDone = false
      UGCLog.Dump("modID=%s MISS mapKey=%s state=%s", tostring(ModID), tostring(mapKey), UGCLog.StateName(mapState))
      if PufferMapManager then
        PufferMapManager:DumpMapMissing(mapKey, {}, {}, 0)
      end
    end
  end
  local PufferODPakManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_manager)
  local nFeatureMiss = PufferODPakManager:DumpFeatureListMissing(AllFeatureKeyList)
  if 0 < nFeatureMiss then
    bAllDone = false
  end
  local PufferUGCPakManager = self:_GetPufferUGCPakManager()
  local nAssetMiss = PufferUGCPakManager:DumpAssetListMissing(AllAssetIDList)
  if 0 < nAssetMiss then
    bAllDone = false
  end
  if self:_NeedOtherRes(modInfo) then
    if self:_IsNewMeta(modInfo) then
      local LogicUGCAssetHub = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAssetHub)
      local AssetHubState = LogicUGCAssetHub:GetAssetState(loaderType, modInfo)
      if AssetHubState ~= ENUM.Done then
        bAllDone = false
        UGCLog.Dump("modID=%s MISS AssetHub state=%s", tostring(ModID), UGCLog.StateName(AssetHubState))
      end
    end
    if loaderType == self.DownloaderType.ModCopy then
      local LobbyBinModule = GetLobbyBinModule()
      if LobbyBinModule and LobbyBinModule:ShouldDownload(modInfo) then
        local BinState = LobbyBinModule:GetResourceState(modInfo)
        if BinState ~= ENUM.Done then
          bAllDone = false
          UGCLog.Dump("modID=%s MISS LobbyBin state=%s failed=%s", tostring(ModID), UGCLog.StateName(BinState), tostring(LobbyBinModule:IsDownloadFailed(modInfo)))
        end
      end
    end
  end
  local cSize, tSize = self:GetResSize(loaderType, modInfo)
  UGCLog.Dump("========== DumpModMissing END reason=%s modID=%s allDone=%s featureMiss=%s assetMiss=%s size=%.2f/%.2fMB ==========", tostring(sReason or "manual"), tostring(ModID), tostring(bAllDone), tostring(nFeatureMiss), tostring(nAssetMiss), cSize or 0, tSize or 0)
  return bAllDone
end

function Logic_UGC_Res_Manager:DumpDownloadEnv()
  if not UGCLog.IsEnable() then
    return
  end
  local puffer_queue = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_queue)
  local nDownloading, nWait = 0, 0
  if puffer_queue then
    nDownloading = puffer_queue:GetDownloadingCnt() or 0
    nWait = UGCLog.Count(puffer_queue.waitTasks)
  end
  UGCLog.Dump("ENV puffer: InitSuccess=%s JsonReturn=%s BanDownload=%s BanAutoDownload=%s CanAutoDownload=%s BattleSwitch=%s", tostring(PufferDownloader and PufferDownloader.InitSuccess), tostring(PufferDownloader and PufferDownloader.PufferJsonDownloadReturn), tostring(PufferSwitch.BanDownload), tostring(PufferSwitch.BanAutoDownload), tostring(PufferSwitch.CanAutoDownload()), tostring(PufferDownloader and PufferDownloader.BattleDownloadSwitch))
  UGCLog.Dump("ENV queue: downloading=%s wait=%s netType=%s trackingMods=%s", tostring(nDownloading), tostring(nWait), tostring(Client and Client.GetNetWorkType and Client.GetNetWorkType()), tostring(UGCLog.Count(self._trackingMods)))
end

function Logic_UGC_Res_Manager:DumpModSummary(modInfo, sReason, loaderType)
  if not (UGCLog.IsEnable() and modInfo) or not modInfo.base then
    return 0, 0
  end
  loaderType = loaderType or self.DownloaderType.ModCopy
  local ENUM = PufferConst.ENUM_DownloadState
  local ModID = modInfo.mod_id or tostring(modInfo.base.uid) .. "_" .. tostring(modInfo.base.slot)
  local AllAssetIDList, AllFeatureKeyList = self:_GetResListForDump(loaderType, modInfo)
  local PufferODPakManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_manager)
  local PufferUGCPakManager = self:_GetPufferUGCPakManager()
  local nFeatureMiss = 0
  for _, key in pairs(AllFeatureKeyList or {}) do
    if PufferODPakManager:GetStateByKeyList(PufferConst.ENUM_DownloadType.ODPAK, {key}) ~= ENUM.Done then
      nFeatureMiss = nFeatureMiss + 1
    end
  end
  local nAssetMiss = 0
  for _, assetID in pairs(AllAssetIDList or {}) do
    if PufferUGCPakManager:GetStateByAssetID(assetID, true) ~= ENUM.Done then
      nAssetMiss = nAssetMiss + 1
    end
  end
  local cSize, tSize = self:GetResSize(loaderType, modInfo)
  UGCLog.Dump("SUMMARY reason=%s loaderType=%s modID=%s state=%s asset=%s/%s(miss) feature=%s/%s(miss) size=%.2f/%.2fMB", tostring(sReason or "manual"), tostring(loaderType), tostring(ModID), UGCLog.StateName(self:GetResState(loaderType, modInfo)), tostring(nAssetMiss), tostring(UGCLog.Count(AllAssetIDList)), tostring(nFeatureMiss), tostring(UGCLog.Count(AllFeatureKeyList)), cSize or 0, tSize or 0)
  return nAssetMiss, nFeatureMiss
end

function Logic_UGC_Res_Manager:DumpModMissingByModID(modID, loaderType)
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  local modeInfo = LogicUGC and LogicUGC:GetModByAllCache(modID)
  if not modeInfo or not modeInfo.pub_mod_meta then
    UGCLog.Dump("DumpModMissingByModID modID=%s not found in local mod cache", tostring(modID))
    return false
  end
  return self:DumpModMissing(modeInfo.pub_mod_meta, "manual", loaderType)
end

function Logic_UGC_Res_Manager:SetDownloadLogEnable(bEnable)
  UGCLog.SetEnable(bEnable)
end

function Logic_UGC_Res_Manager:SetDownloadLogVerbose(bEnable)
  UGCLog.SetVerbose(bEnable)
end

function Logic_UGC_Res_Manager:PrintAllFeatureKeys()
  local PufferUGCPakManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_ugcpak_manager)
  local Keys = PufferUGCPakManager.AllFeatureIDList
  if Keys then
    local PufferODPakManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_manager)
    for k, v in pairs(Keys) do
      local state = PufferODPakManager:GetStateByKeyList(PufferConst.ENUM_DownloadType.ODPAK, {v})
      local cSize, tSize = PufferODPakManager:GetSizeByKeyList(PufferConst.ENUM_DownloadType.ODPAK, {v})
      print(bWriteLog and "Logic_UGC_Res_Manager:PrintAllFeatureKeys FeatureKey:" .. tostring(v) .. ",state:" .. tostring(state) .. ",tSize:" .. tostring(tSize / PufferConst.MB))
    end
  end
end

function Logic_UGC_Res_Manager:_IsCompleteUGCModRes(modInfo)
  if not modInfo or modInfo.base == nil or modInfo.base.template_id == nil then
    log(bWriteLog and " Logic_UGC_Res_Manager:_IsCompleteUGCModRes: not modInfo or modInfo.base == nil or modInfo.base.template_id == nil")
    return false
  end
  local AllAssetIDList, AllFeatureKeyList, AllResKeyList = self:GetAllResList(modInfo)
  local excludeMapKey = self:GetExcludeMapKey(modInfo, AllAssetIDList)
  local mapKeyList = self:GetAllMapKeysByModInfo(modInfo)
  if not mapKeyList or #mapKeyList == 0 then
    log(bWriteLog and string.format(" Logic_UGC_Res_Manager:_IsCompleteUGCModRes: mapKeyList is empty, template_id:%d", modInfo.base.template_id))
  else
    local state = PufferManager.GetState(PufferConst.ENUM_DownloadType.MAP, mapKeyList, nil, nil, excludeMapKey)
    log(bWriteLog and string.format(" Logic_UGC_Res_Manager:_IsCompleteUGCModRes mapKeyList count:%d , state:%d", #mapKeyList, state))
    if state ~= PufferConst.ENUM_DownloadState.Done then
      return false
    end
  end
  local PufferODPakManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_manager)
  if PufferODPakManager:GetStateByKeyList(PufferConst.ENUM_DownloadType.ODPAK, AllFeatureKeyList) ~= PufferConst.ENUM_DownloadState.Done then
    print(bWriteLog and " Logic_UGC_Res_Manager:_IsCompleteUGCModRes:AllFeatureKeyList not done")
    if bWriteLog then
      for k, v in pairs(AllFeatureKeyList) do
        local featureState = PufferODPakManager:GetStateByKeyList(PufferConst.ENUM_DownloadType.ODPAK, {v})
        if featureState ~= PufferConst.ENUM_DownloadState.Done then
          print(bWriteLog and " Logic_UGC_Res_Manager:_IsCompleteUGCModRes feature:%s,State:%s", v, featureState)
        end
      end
    end
    return false
  end
  print(bWriteLog and " Logic_UGC_Res_Manager:_IsCompleteUGCModRes:AllFeatureKeyList done")
  local PufferUGCPakManager = self:_GetPufferUGCPakManager()
  local state = PufferUGCPakManager:GetStateByKeyList(PufferConst.ENUM_DownloadType.UGCPAK, AllAssetIDList, true)
  if state ~= PufferConst.ENUM_DownloadState.Done then
    print(bWriteLog and " Logic_UGC_Res_Manager:_IsCompleteUGCModRes:AllAssetIDList not done")
    if bWriteLog then
      for k, v in pairs(AllAssetIDList) do
        local assetState = PufferUGCPakManager:GetStateByKeyList(PufferConst.ENUM_DownloadType.UGCPAK, {v})
        if assetState ~= PufferConst.ENUM_DownloadState.Done then
          printf(bWriteLog and " Logic_UGC_Res_Manager:_IsCompleteUGCModRes asset:%s,State:%s", v, assetState)
        end
      end
    end
    return false
  end
  print(bWriteLog and " Logic_UGC_Res_Manager:_IsCompleteUGCModRes:AllAssetIDList done")
  if AllResKeyList and 0 < #AllResKeyList then
    state = PufferManager.GetState(PufferConst.ENUM_DownloadType.RES, AllResKeyList)
    if state ~= PufferConst.ENUM_DownloadState.Done then
      print(bWriteLog and " Logic_UGC_Res_Manager:_IsCompleteUGCModRes:AllResKeyList not done")
      if bWriteLog then
        for k, v in pairs(AllResKeyList) do
          local resState = PufferManager.GetState(PufferConst.ENUM_DownloadType.RES, {v})
          if resState ~= PufferConst.ENUM_DownloadState.Done then
            printf(bWriteLog and " Logic_UGC_Res_Manager:_IsCompleteUGCModRes res:%s,State:%s", v, resState)
          end
        end
      end
      return false
    end
    print(bWriteLog and " Logic_UGC_Res_Manager:_IsCompleteUGCModRes:AllResKeyList done")
  end
  return true
end

function Logic_UGC_Res_Manager:_GetUGCModResState(modInfo, bWeakCalculate)
  if not modInfo or modInfo.base == nil or modInfo.base.template_id == nil then
    return PufferConst.ENUM_DownloadState.Not
  end
  local modIdKey = self:_GetCacheKeyByModInfo(modInfo)
  local cacheInfo = self:GetUGCModCacheInfo(modIdKey)
  if bWeakCalculate then
    return cacheInfo.state
  end
  if cacheInfo.state ~= PufferConst.ENUM_DownloadState.Done then
    local isLoaded = self:_IsCompleteUGCModRes(modInfo)
    if isLoaded then
      cacheInfo.state = PufferConst.ENUM_DownloadState.Done
    end
  end
  return cacheInfo.state
end

function Logic_UGC_Res_Manager:_DownloadModRes(modInfo, bSilent, batchId)
  if not modInfo or modInfo.base == nil or modInfo.base.template_id == nil then
    return false
  end
  local cacheKey = self:_GetCacheKeyByModInfo(modInfo)
  if modInfo.mod_id then
    self:_AddModToLocal(modInfo.mod_id)
  end
  log(bWriteLog and string.format("Logic_UGC_Res_Manager:_DownloadModRes cacheKey = %s", cacheKey))
  local cacheInfo = self:GetUGCModCacheInfo(cacheKey)
  cacheInfo.state = PufferConst.ENUM_DownloadState.Download
  cacheInfo.version = modInfo.base.verify_time
  local AllAssetIDList, AllFeatureKeyList, AllResKeyList = self:GetAllResList(modInfo)
  if UGCLog.IsEnable() then
    UGCLog.Log("Logic_UGC_Res_Manager:_DownloadModRes modID=%s cacheKey=%s assetCount=%s featureCount=%s", tostring(modInfo.mod_id), tostring(cacheKey), tostring(UGCLog.Count(AllAssetIDList)), tostring(UGCLog.Count(AllFeatureKeyList)))
    UGCLog.Log("Logic_UGC_Res_Manager:_DownloadModRes modID=%s assetIDs=[%s]", tostring(modInfo.mod_id), UGCLog.ListToStr(AllAssetIDList))
    UGCLog.Log("Logic_UGC_Res_Manager:_DownloadModRes modID=%s featureKeys=[%s]", tostring(modInfo.mod_id), UGCLog.ListToStr(AllFeatureKeyList))
  end
  local excludeMapKey = self:GetExcludeMapKey(modInfo, AllAssetIDList)
  local mapKeyList = self:GetAllMapKeysByModInfo(modInfo)
  local stateExcludeMapKey = TableUtil.CopyTable(excludeMapKey)
  local mapState = PufferManager.GetState(PufferConst.ENUM_DownloadType.MAP, mapKeyList, nil, nil, stateExcludeMapKey)
  if mapState ~= PufferConst.ENUM_DownloadState.Done then
    log(bWriteLog and string.format("Logic_UGC_Res_Manager:_DownloadModRes download map keyList count:%d state:%d", #mapKeyList, mapState))
    cacheInfo.mapKey = mapKeyList[1]
    local extraData = {bAutoDownload = false}
    extraData.excludeMapKey = excludeMapKey
    PufferManager.Download(PufferConst.ENUM_DownloadType.MAP, mapKeyList, PufferTlog.Enum_TLog_From.UGC, nil, extraData)
  end
  local puffer_odpak_downloader = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_downloader)
  puffer_odpak_downloader:DownloadByKeyList(PufferConst.ENUM_DownloadType.ODPAK, AllFeatureKeyList, nil, nil, {bIsUGC = true})
  if bWriteLog then
    for k, v in pairs(AllFeatureKeyList) do
      printf("Logic_UGC_Res_Manager:_DownloadModRes FeatureKey:%s", v)
    end
  end
  local puffer_ugcpak_downloader = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_ugcpak_downloader)
  puffer_ugcpak_downloader:DownloadByKeyList(PufferConst.ENUM_DownloadType.UGCPAK, AllAssetIDList, nil, nil, {bMinDepends = true})
  if bWriteLog then
    for k, v in pairs(AllAssetIDList) do
      printf("Logic_UGC_Res_Manager:_DownloadModRes AssetID:%s", v)
    end
  end
  if AllResKeyList and 0 < #AllResKeyList then
    local puffer_res_downloader = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_res_downloader)
    puffer_res_downloader:DownloadByKeyList(PufferConst.ENUM_DownloadType.RES, AllResKeyList, nil, nil, {bIsUGC = true})
    if bWriteLog then
      for k, v in pairs(AllResKeyList) do
        printf("Logic_UGC_Res_Manager:_DownloadModRes Res:%s", v)
      end
    end
  end
  local isFinish = false
  if self:_IsCompleteUGCModRes(modInfo) then
    cacheInfo.state = PufferConst.ENUM_DownloadState.Done
    isFinish = true
  end
  self:_SendDownloadTLog(modInfo, "_DownloadModRes", mapState, mapKeyList[1], nil, AllAssetIDList)
  if not isFinish and modInfo.mod_id then
    self:_TrackModDownload(modInfo, bSilent, batchId)
  end
  return isFinish
end

function Logic_UGC_Res_Manager:_PauseModRes(modInfo)
  if not modInfo or modInfo.base == nil or modInfo.base.template_id == nil then
    return false
  end
  local cacheKey = self:_GetCacheKeyByModInfo(modInfo)
  log(bWriteLog and string.format("Logic_UGC_Res_Manager:_PauseModRes cacheKey = %s", cacheKey))
  local cacheInfo = self:GetUGCModCacheInfo(cacheKey)
  cacheInfo.state = PufferConst.ENUM_DownloadState.Pause
  local cacheInfos = self.modResCaches
  local mapKey = cacheInfo.mapKey
  local bExistOtherMapKey = false
  if mapKey then
    for mK, mV in pairs(cacheInfos) do
      if mV.state == PufferConst.ENUM_DownloadState.Download and (mV.mapKey == mapKey or mV.bundleKey) then
        bExistOtherMapKey = true
        break
      end
    end
    if not bExistOtherMapKey then
      log(bWriteLog and "Logic_UGC_Res_Manager:_PauseModRes bExistOtherMapKey == false")
      PufferManager.Pause(PufferConst.ENUM_DownloadType.MAP, {mapKey})
    end
  end
  local ownDepends = cacheInfo.depends
  local onlyDepends = {}
  if ownDepends and 0 < #ownDepends then
    local bExistTeamRes = false
    for dKey, dValue in pairs(ownDepends) do
      local bExistOtherDepends = false
      for curKey, curValue in pairs(cacheInfos) do
        if curValue.state == PufferConst.ENUM_DownloadState.Download and curValue.bundleKey then
          bExistTeamRes = true
          break
        end
        if curValue.state == PufferConst.ENUM_DownloadState.Download and curValue.depends then
          for otherDependsKey, otherDependsValue in pairs(curValue.depends) do
            if dValue == otherDependsValue then
              bExistOtherDepends = true
              break
            end
          end
        end
        if bExistOtherDepends then
          break
        end
      end
      if bExistTeamRes then
        break
      end
      if not bExistOtherDepends then
        table.insert(onlyDepends, dValue)
      end
    end
    if not bExistTeamRes and 0 < #onlyDepends then
      local extraData = {
        bMinDepends = self:_IsPublishMod(modInfo)
      }
      PufferManager.Pause(PufferConst.ENUM_DownloadType.UGCPAK, onlyDepends, nil, nil, extraData)
      if bWriteLog then
        log(bWriteLog and "Logic_UGC_Res_Manager:_PauseModRes onlyDepends start  bMinDepends:" .. tostring(extraData.bMinDepends))
        for _k, _v in pairs(onlyDepends) do
          log(bWriteLog and string.format("Logic_UGC_Res_Manager:_PauseModRes onlyDepends v:%s", tostring(_v)))
        end
        log(bWriteLog and "Logic_UGC_Res_Manager:_PauseModRes onlyDepends end")
      end
    end
  end
  local ownFeatureKeyList = cacheInfo.dependFeatures
  local onlyFeatureKeys = {}
  if ownFeatureKeyList and 0 < #ownFeatureKeyList then
    local bExistTeamRes = false
    for _, featureKey in pairs(ownFeatureKeyList) do
      if bExistTeamRes then
        break
      end
      local bExistOtherFeatureKey = false
      for _, curValue in pairs(cacheInfos) do
        if curValue.state == PufferConst.ENUM_DownloadState.Download and curValue.bundleKey then
          bExistTeamRes = true
          break
        end
        if curValue.state == PufferConst.ENUM_DownloadState.Download and curValue.dependFeatures then
          for _, otherFeatureKey in pairs(curValue.dependFeatures) do
            if featureKey == otherFeatureKey then
              bExistOtherFeatureKey = true
              break
            end
          end
        end
        if bExistOtherFeatureKey then
          break
        end
      end
      if not bExistOtherFeatureKey then
        table.insert(onlyFeatureKeys, featureKey)
      end
    end
    if not bExistTeamRes and 0 < #onlyFeatureKeys then
      local puffer_odpak_downloader = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_downloader)
      puffer_odpak_downloader:PauseByKeyList(PufferConst.ENUM_DownloadType.ODPAK, onlyFeatureKeys)
      if bWriteLog then
        log(bWriteLog and "Logic_UGC_Res_Manager:_PauseModRes onlyFeatureKeys start")
        for _, _v in pairs(onlyFeatureKeys) do
          log(bWriteLog and string.format("Logic_UGC_Res_Manager:_PauseModRes onlyFeatureKeys v:%s", tostring(_v)))
        end
        log(bWriteLog and "Logic_UGC_Res_Manager:_PauseModRes onlyFeatureKeys end")
      end
    end
  end
  self:_SendPauseTLog(modInfo, "PauseModRes", bExistOtherMapKey, mapKey, onlyDepends)
  return true
end

function Logic_UGC_Res_Manager:_GetUGCModResSize(modInfo)
  if not modInfo or modInfo.base == nil or modInfo.base.template_id == nil then
    return 0, 0
  end
  local mapKeyList = self:GetAllMapKeysByModInfo(modInfo)
  if modInfo.setting and modInfo.setting.name then
    log(bWriteLog and string.format("Logic_UGC_Res_Manager:_GetUGCModResSize start modName:%s", modInfo.setting.name))
  end
  local AllAssetIDList, AllFeatureKeyList, AllResKeyList = self:GetAllResList(modInfo)
  local excludeMapKey = self:GetExcludeMapKey(modInfo, AllAssetIDList)
  local cSize, tSize = PufferManager.GetSize(PufferConst.ENUM_DownloadType.MAP, mapKeyList, nil, excludeMapKey, true)
  cSize = cSize / PufferConst.MB
  tSize = tSize / PufferConst.MB
  log(bWriteLog and string.format("Logic_UGC_Res_Manager:_GetUGCModResSize mapKeyList count:%d, cSize:%.2f, tSize:%.2f", #mapKeyList, cSize, tSize))
  local PufferODPakManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_manager)
  local cFeatureSize, tFeatureSize = PufferODPakManager:GetSizeByKeyList(PufferConst.ENUM_DownloadType.ODPAK, AllFeatureKeyList)
  cSize = cSize + cFeatureSize / PufferConst.MB
  tSize = tSize + tFeatureSize / PufferConst.MB
  local PufferUGCPakManager = self:_GetPufferUGCPakManager()
  local cAssetSize, tAssetSize = PufferUGCPakManager:GetSizeByKeyList(PufferConst.ENUM_DownloadType.UGCPAK, AllAssetIDList, nil, true)
  cSize = cSize + cAssetSize / PufferConst.MB
  tSize = tSize + tAssetSize / PufferConst.MB
  if AllResKeyList and 0 < #AllResKeyList then
    local cResSize, tResSize = PufferManager.GetSize(PufferConst.ENUM_DownloadType.RES, AllResKeyList)
    cSize = cSize + cResSize / PufferConst.MB
    tSize = tSize + tResSize / PufferConst.MB
  end
  return cSize, tSize
end

function Logic_UGC_Res_Manager:_GetUGCModListSize(modList)
  local cSize, tSize = self:_GetUGCBasicResSize()
  local PufferMapManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager)
  local excludeMapKey = PufferMapManager:GetMapDepends(PufferConst.UGC_BASIC_MAPKEY)
  local MapKeyDic = {}
  local AssetIDDic = {}
  local FeatureKeyDic = {}
  local ResKeyDic = {}
  for k, v in pairs(modList) do
    local modMapKeyList = self:GetAllMapKeysByModInfo(v)
    for _, mk in ipairs(modMapKeyList) do
      MapKeyDic[mk] = true
    end
    local AssetIDList, FeatureKeyList, ResKeyList = self:GetAllResList(v)
    if AssetIDList then
      for kk, vv in pairs(AssetIDList) do
        AssetIDDic[vv] = true
      end
    end
    if FeatureKeyList then
      for kk, vv in pairs(FeatureKeyList) do
        FeatureKeyDic[vv] = true
      end
    end
    if ResKeyList then
      for kk, vv in pairs(ResKeyList) do
        ResKeyDic[vv] = true
      end
    end
  end
  local MapKeyList = TableUtil.GetKeys(MapKeyDic)
  local mcSize, mtSize = PufferManager.GetSize(PufferConst.ENUM_DownloadType.MAP, MapKeyList, false, excludeMapKey, true)
  cSize = cSize + mcSize / PufferConst.MB
  tSize = tSize + mtSize / PufferConst.MB
  local AllAssetIDList = TableUtil.GetKeys(AssetIDDic)
  local PufferUGCPakManager = self:_GetPufferUGCPakManager()
  local idcSize, idtSize = PufferUGCPakManager:GetSizeByKeyList(PufferConst.ENUM_DownloadType.UGCPAK, AllAssetIDList, nil, true)
  cSize = cSize + idcSize / PufferConst.MB
  tSize = tSize + idtSize / PufferConst.MB
  local AllFeatureKeyList = TableUtil.GetKeys(FeatureKeyDic)
  local PufferODPakManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_manager)
  local cFeatureSize, tFeatureSize = PufferODPakManager:GetSizeByKeyList(PufferConst.ENUM_DownloadType.ODPAK, AllFeatureKeyList)
  cSize = cSize + cFeatureSize / PufferConst.MB
  tSize = tSize + tFeatureSize / PufferConst.MB
  local AllResKeyList = TableUtil.GetKeys(ResKeyDic)
  if AllResKeyList and 0 < #AllResKeyList then
    local cResSize, tResSize = PufferManager.GetSize(PufferConst.ENUM_DownloadType.RES, AllResKeyList)
    cSize = cSize + cResSize / PufferConst.MB
    tSize = tSize + tResSize / PufferConst.MB
  end
  local LogicUGCAssetHub = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAssetHub)
  local cAssetHubSize, tAssetHubSize = LogicUGCAssetHub:GetModListAssetSize(modList)
  cSize = cSize + cAssetHubSize
  tSize = tSize + tAssetHubSize
  return cSize, tSize
end

function Logic_UGC_Res_Manager:_IsCompleteUGCWorkRes(modInfo)
  if not modInfo or modInfo.base == nil or modInfo.base.template_id == nil then
    log(bWriteLog and " Logic_UGC_Res_Manager:_IsCompleteUGCWorkRes: not modInfo or modInfo.base == nil or modInfo.base.template_id == nil")
    return false
  end
  local TeamUpNewSystem = require("client.slua.logic.teamup.logic_team_up")
  local isInTeam = TeamUpNewSystem.IsInTeam()
  if isInTeam then
    if LogicPufferBundle.GetBundleState(PufferConst.UGC_BUNDLE_ID) ~= PufferConst.ENUM_DownloadState.Done then
      log(bWriteLog and " Logic_UGC_Res_Manager:_IsCompleteUGCWorkRes: UGCBundle false")
      return false
    end
  else
    local AllAssetIDList, AllFeatureKeyList = self:_GetNotPublishModResList(modInfo)
    local PufferUGCPakManager = self:_GetPufferUGCPakManager()
    if PufferUGCPakManager:GetStateByKeyList(PufferConst.ENUM_DownloadType.UGCPAK, AllAssetIDList) ~= PufferConst.ENUM_DownloadState.Done then
      log(bWriteLog and string.format("Logic_UGC_Res_Manager:_IsCompleteUGCWorkRes: AllAssetIDList Not Done, template_id:%d", modInfo.base.template_id))
      return false
    end
    local puffer_odpak_manager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_manager)
    if puffer_odpak_manager:GetStateByKeyList(PufferConst.ENUM_DownloadType.ODPAK, AllFeatureKeyList) ~= PufferConst.ENUM_DownloadState.Done then
      log(bWriteLog and string.format("Logic_UGC_Res_Manager:_IsCompleteUGCWorkRes: AllFeatureKeyList Not Done, template_id:%d", modInfo.base.template_id))
      return false
    end
    if not IsWoWEditor and PufferManager.GetState(PufferConst.ENUM_DownloadType.MAP, {
      PufferConst.UGC_EDIT_MAPKEY
    }) ~= PufferConst.ENUM_DownloadState.Done then
      log(bWriteLog and string.format("Logic_UGC_Res_Manager:_IsCompleteUGCWorkRes: Editor Map Not Done, template_id:%d", modInfo.base.template_id))
      return false
    end
  end
  local mapKeyList = self:GetAllMapKeysByModInfo(modInfo)
  if not mapKeyList or #mapKeyList == 0 then
    log(bWriteLog and string.format(" Logic_UGC_Res_Manager:_IsCompleteUGCWorkRes: mapKeyList is empty, template_id:%d", modInfo.base.template_id))
  else
    local state = PufferManager.GetState(PufferConst.ENUM_DownloadType.MAP, mapKeyList)
    log(bWriteLog and string.format("Logic_UGC_Res_Manager:_IsCompleteUGCWorkRes mapKeyList count:%d ,state:%d", #mapKeyList, state))
    if state ~= PufferConst.ENUM_DownloadState.Done then
      return false
    end
  end
  return true
end

function Logic_UGC_Res_Manager:_GetUGCWorkResState(modInfo, bWeakCalculate)
  local cacheKey = self:_GetCacheKeyByModInfo(modInfo, true)
  local cacheInfo = self:GetUGCModCacheInfo(cacheKey)
  if bWeakCalculate then
    return cacheInfo.state
  end
  local isLoaded = self:_IsCompleteUGCWorkRes(modInfo)
  if isLoaded then
    cacheInfo.state = PufferConst.ENUM_DownloadState.Done
  elseif cacheInfo.state == PufferConst.ENUM_DownloadState.Done then
    cacheInfo.state = PufferConst.ENUM_DownloadState.Update
  end
  return cacheInfo.state
end

function Logic_UGC_Res_Manager:_DownloadWorkRes(modInfo)
  if not modInfo or modInfo.base == nil or modInfo.base.template_id == nil then
    return false
  end
  local cacheKey = self:_GetCacheKeyByModInfo(modInfo, true)
  log(bWriteLog and string.format("Logic_UGC_Res_Manager:_DownloadWorkRes cacheKey =%s", cacheKey))
  local cacheInfo = self:GetUGCModCacheInfo(cacheKey)
  cacheInfo.state = PufferConst.ENUM_DownloadState.Download
  local mapKeyList = self:GetAllMapKeysByModInfo(modInfo)
  local mapState = PufferManager.GetState(PufferConst.ENUM_DownloadType.MAP, mapKeyList)
  if mapState ~= PufferConst.ENUM_DownloadState.Done then
    PufferManager.Download(PufferConst.ENUM_DownloadType.MAP, mapKeyList, PufferTlog.Enum_TLog_From.UGC, nil, defaultExtraParams)
    cacheInfo.mapKey = mapKeyList[1]
    log(bWriteLog and string.format("Logic_UGC_Res_Manager:_DownloadWorkRes downloadMapKey count:%d ,state:%d", #mapKeyList, mapState))
  end
  local TeamUpNewSystem = require("client.slua.logic.teamup.logic_team_up")
  local isInTeam = TeamUpNewSystem.IsInTeam()
  if not isInTeam then
    local AllAssetIDList, AllFeatureKeyList = self:_GetNotPublishModResList(modInfo)
    cacheInfo.depends = AllAssetIDList
    cacheInfo.dependFeatures = AllFeatureKeyList
    local puffer_ugcpak_downloader = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_ugcpak_downloader)
    puffer_ugcpak_downloader:DownloadByKeyList(PufferConst.ENUM_DownloadType.UGCPAK, AllAssetIDList)
    local puffer_odpak_downloader = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_downloader)
    puffer_odpak_downloader:DownloadByKeyList(PufferConst.ENUM_DownloadType.ODPAK, AllFeatureKeyList)
    if PufferManager.GetState(PufferConst.ENUM_DownloadType.MAP, {
      PufferConst.UGC_EDIT_MAPKEY
    }) ~= PufferConst.ENUM_DownloadState.Done then
      PufferManager.Download(PufferConst.ENUM_DownloadType.MAP, {
        PufferConst.UGC_EDIT_MAPKEY
      }, PufferTlog.Enum_TLog_From.UGC, nil, defaultExtraParams)
    end
  else
    local bundleLoaded = true
    if LogicPufferBundle.GetBundleState(PufferConst.UGC_BUNDLE_ID) ~= PufferConst.ENUM_DownloadState.Done then
      log(bWriteLog and "Logic_UGC_Res_Manager:_DownloadWorkRes bundle need download")
      bundleLoaded = false
      cacheInfo.bundleKey = PufferConst.UGC_BUNDLE_ID
      LogicPufferBundle.DownloadBundle(PufferConst.UGC_BUNDLE_ID)
    else
      log(bWriteLog and "Logic_UGC_Res_Manager:_DownloadWorkRes bundle loaded")
    end
  end
  local isFinish = false
  if self:_IsCompleteUGCWorkRes(modInfo) then
    cacheInfo.state = PufferConst.ENUM_DownloadState.Done
    isFinish = true
  end
  return isFinish
end

function Logic_UGC_Res_Manager:_PauseWorkRes(modInfo)
  if not modInfo or modInfo.base == nil or modInfo.base.template_id == nil then
    return false
  end
  local cacheKey = self:_GetCacheKeyByModInfo(modInfo, true)
  log(bWriteLog and string.format("Logic_UGC_Res_Manager:_PauseWorkRes cacheKey = %s", cacheKey))
  local cacheInfo = self:GetUGCModCacheInfo(cacheKey)
  cacheInfo.state = PufferConst.ENUM_DownloadState.Pause
  local mapKey = cacheInfo.mapKey
  local bExistOtherMapKey = false
  if mapKey then
    for mK, mV in pairs(self.modResCaches) do
      if mV.state == PufferConst.ENUM_DownloadState.Download and (mV.mapKey == mapKey or mV.bundleKey) then
        bExistOtherMapKey = true
        break
      end
    end
    if not bExistOtherMapKey then
      PufferManager.Pause(PufferConst.ENUM_DownloadType.MAP, {mapKey})
    end
  end
  local TeamUpNewSystem = require("client.slua.logic.teamup.logic_team_up")
  local isInTeam = TeamUpNewSystem.IsInTeam()
  if not isInTeam then
    local cacheInfos = self.modResCaches
    local ownDepends = cacheInfo.depends
    local onlyDepends = {}
    if ownDepends and 0 < #ownDepends then
      local bExistTeamRes = false
      for dKey, dValue in pairs(ownDepends) do
        local bExistOtherDepends = false
        for curKey, curValue in pairs(cacheInfos) do
          if curValue.state == PufferConst.ENUM_DownloadState.Download and curValue.bundleKey then
            bExistTeamRes = true
            break
          end
          if curValue.state == PufferConst.ENUM_DownloadState.Download and curValue.depends then
            for otherDependsKey, otherDependsValue in pairs(curValue.depends) do
              if dValue == otherDependsValue then
                bExistOtherDepends = true
                break
              end
            end
          end
          if bExistOtherDepends == true then
            break
          end
        end
        if bExistTeamRes then
          break
        end
        if not bExistOtherDepends then
          table.insert(onlyDepends, dValue)
        end
      end
      if not bExistTeamRes and 0 < #onlyDepends then
        PufferManager.Pause(PufferConst.ENUM_DownloadType.UGCPAK, onlyDepends)
        if bWriteLog then
          log(bWriteLog and "Logic_UGC_Res_Manager:_PauseWorkRes onlyDepends start")
          for _k, _v in pairs(onlyDepends) do
            log(bWriteLog and string.format("Logic_UGC_Res_Manager:_PauseWorkRes onlyDepends v:%s", tostring(_v)))
          end
          log(bWriteLog and "Logic_UGC_Res_Manager:_PauseWorkRes onlyDepends end")
        end
      end
    end
    local ownFeatureKeyList = cacheInfo.dependFeatures
    local onlyFeatureKeys = {}
    if ownFeatureKeyList and 0 < #ownFeatureKeyList then
      local bExistTeamRes = false
      for _, featureKey in pairs(ownFeatureKeyList) do
        if bExistTeamRes then
          break
        end
        local bExistOtherFeatureKey = false
        for _, curValue in pairs(cacheInfos) do
          if curValue.state == PufferConst.ENUM_DownloadState.Download and curValue.bundleKey then
            bExistTeamRes = true
            break
          end
          if curValue.state == PufferConst.ENUM_DownloadState.Download and curValue.dependFeatures then
            for _, otherFeatureKey in pairs(curValue.dependFeatures) do
              if featureKey == otherFeatureKey then
                bExistOtherFeatureKey = true
                break
              end
            end
          end
          if bExistOtherFeatureKey then
            break
          end
        end
        if not bExistOtherFeatureKey then
          table.insert(onlyFeatureKeys, featureKey)
        end
      end
      if not bExistTeamRes and 0 < #onlyFeatureKeys then
        local puffer_odpak_downloader = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_downloader)
        puffer_odpak_downloader:PauseByKeyList(PufferConst.ENUM_DownloadType.ODPAK, onlyFeatureKeys)
        if bWriteLog then
          log(bWriteLog and "Logic_UGC_Res_Manager:_PauseWorkRes onlyFeatureKeys start")
          for _, _v in pairs(onlyFeatureKeys) do
            log(bWriteLog and string.format("Logic_UGC_Res_Manager:_PauseWorkRes onlyFeatureKeys v:%s", tostring(_v)))
          end
          log(bWriteLog and "Logic_UGC_Res_Manager:_PauseWorkRes onlyFeatureKeys end")
        end
      end
    end
    local bExistOther20W = false
    for mK, mV in pairs(self.modResCaches) do
      if mV.state == PufferConst.ENUM_DownloadState.Download and mV.packKey and mV.packKey == PufferConst.EODPackID.WOW_20W then
        bExistOther20W = true
        break
      end
    end
    if not bExistOther20W then
      LogicPufferBundle.StopDownloadPackList({
        PufferConst.EODPackID.WOW_20W
      })
      PufferManager.Pause(PufferConst.ENUM_DownloadType.MAP, {
        PufferConst.UGC_EDIT_MAPKEY
      })
      if bWriteLog then
        log(bWriteLog and "Logic_UGC_Res_Manager:_PauseWorkRes StopDownloadPackList WOW_20W  Pause UGC_EDIT_MAPKEY")
      end
    end
    return
  else
    local existOtherBundle = false
    for mK, mV in pairs(self.modResCaches) do
      if mV.state == PufferConst.ENUM_DownloadState.Download and mV.bundleKey then
        existOtherBundle = true
        break
      end
    end
    if existOtherBundle == false then
      LogicPufferBundle.StopDownloadBundle(PufferConst.UGC_BUNDLE_ID)
    end
    self:_SendPauseTLog(modInfo, "PauseWorkRes", bExistOtherMapKey, mapKey, nil, nil, existOtherBundle)
  end
  return true
end

function Logic_UGC_Res_Manager:_GetUGCWorkResSize(modInfo)
  if not modInfo or modInfo.base == nil or modInfo.base.template_id == nil then
    return 0, 0
  end
  local mapKeyList = self:GetAllMapKeysByModInfo(modInfo)
  local cSize, tSize = PufferManager.GetSize(PufferConst.ENUM_DownloadType.MAP, mapKeyList, nil, nil, true)
  cSize = cSize / PufferConst.MB
  tSize = tSize / PufferConst.MB
  local TeamUpNewSystem = require("client.slua.logic.teamup.logic_team_up")
  local isInTeam = TeamUpNewSystem.IsInTeam()
  if not isInTeam then
    local tempcSize, temptSize = PufferManager.GetSize(PufferConst.ENUM_DownloadType.MAP, {
      PufferConst.UGC_EDIT_MAPKEY
    })
    cSize = cSize + tempcSize / PufferConst.MB
    tSize = tSize + temptSize / PufferConst.MB
    local AllAssetIDList, AllFeatureKeyList = self:_GetNotPublishModResList(modInfo)
    local puffer_odpak_manager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_manager)
    tempcSize, temptSize = puffer_odpak_manager:GetSizeByKeyList(PufferConst.ENUM_DownloadType.ODPAK, AllFeatureKeyList)
    cSize = cSize + tempcSize / PufferConst.MB
    tSize = tSize + temptSize / PufferConst.MB
    local PufferUGCPakManager = self:_GetPufferUGCPakManager()
    tempcSize, temptSize = PufferUGCPakManager:GetSizeByKeyList(PufferConst.ENUM_DownloadType.UGCPAK, AllAssetIDList, nil, true)
    cSize = cSize + tempcSize / PufferConst.MB
    tSize = tSize + temptSize / PufferConst.MB
    return cSize, tSize
  else
    local bcSize, btSize = self:GetUGCBundleSize()
    cSize = cSize + bcSize
    tSize = tSize + btSize
    return cSize, tSize
  end
end

function Logic_UGC_Res_Manager:_IsCompleteUGCTemplateRes(templateId)
  local TemplateInfo = Config_UGC.GetTemplateConfigByID(templateId)
  if not TemplateInfo then
    return false
  end
  local State = self:_GetUGCTemplateResState(TemplateInfo)
  if State ~= PufferConst.ENUM_DownloadState.Done then
    return false
  end
  return true
end

function Logic_UGC_Res_Manager:_GetUGCTemplateResState(templateInfo)
  local mapKey = self:GetUGCMapKeyByTemplateId(templateInfo.ID, templateInfo.MapID)
  if mapKey == nil then
  else
    log(bWriteLog and string.format("Logic_UGC_Res_Manager:_GetUGCTemplateResState mapkey:%s", mapKey))
  end
  local state = PufferManager.GetState(PufferConst.ENUM_DownloadType.MAP, {mapKey})
  log(bWriteLog and string.format("Logic_UGC_Res_Manager:_GetUGCTemplateResState map State:%d", state))
  if state == PufferConst.ENUM_DownloadState.Done and not IsWoWEditor then
    state = PufferManager.GetState(PufferConst.ENUM_DownloadType.MAP, {
      PufferConst.UGC_EDIT_MAPKEY
    })
    log(bWriteLog and " Logic_UGC_Res_Manager:_GetUGCTemplateResState creative edit state : " .. state)
  end
  if state == PufferConst.ENUM_DownloadState.Done then
    local AllAssetIDList, AllFeatureKeyList = self:_GetNotPublishModResList(templateInfo)
    local PufferUGCPakManager = self:_GetPufferUGCPakManager()
    state = PufferUGCPakManager:GetStateByKeyList(PufferConst.ENUM_DownloadType.UGCPAK, AllAssetIDList)
    log(bWriteLog and string.format("Logic_UGC_Res_Manager:_GetUGCTemplateResState UGCPAK state:%d", state))
    if state == PufferConst.ENUM_DownloadState.Done then
      local PufferODPakManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_manager)
      state = PufferODPakManager:GetStateByKeyList(PufferConst.ENUM_DownloadType.ODPAK, AllFeatureKeyList)
      log(bWriteLog and string.format("Logic_UGC_Res_Manager:_GetUGCTemplateResState ODPAK state:%d", state))
    end
    if state ~= PufferConst.ENUM_DownloadState.Done and bWriteLog and AllAssetIDList then
      for k, v in pairs(AllAssetIDList) do
        local AssetState = PufferUGCPakManager:GetStateByKeyList(PufferConst.ENUM_DownloadType.UGCPAK, {v})
        if AssetState ~= PufferConst.ENUM_DownloadState.Done then
          printf("Logic_UGC_Res_Manager:_GetUGCTemplateResState AssetID:%s,State:%s", v, AssetState)
        end
      end
    end
  end
  if state ~= PufferConst.ENUM_DownloadState.Done then
    local cacheKey = self:_GetCacheKeyByTemplateInfoID(templateInfo.ID)
    local cacheInfo = self:GetUGCModCacheInfo(cacheKey)
    state = cacheInfo.state
    log(bWriteLog and string.format("Logic_UGC_Res_Manager:_GetUGCTemplateResState cache State:%d", state))
    if state == PufferConst.ENUM_DownloadState.Done then
      state = PufferConst.ENUM_DownloadState.Update
      cacheInfo.state = PufferConst.ENUM_DownloadState.Update
      log(bWriteLog and "Logic_UGC_Res_Manager:_GetUGCTemplateResState state is update")
    end
  end
  return state
end

function Logic_UGC_Res_Manager:_DownloadTemplateRes(templateInfo)
  local cacheKey = self:_GetCacheKeyByTemplateInfoID(templateInfo.ID)
  local mapKey = self:GetUGCMapKeyByTemplateId(templateInfo.ID, templateInfo.MapID)
  if mapKey then
    local isFinish = false
    local mapState
    local loadedBundle = true
    local idList
    local cacheInfo = self:GetUGCModCacheInfo(cacheKey)
    if self:_IsCompleteUGCTemplateRes(templateInfo.ID) then
      cacheInfo.state = PufferConst.ENUM_DownloadState.Done
      isFinish = true
      log(bWriteLog and string.format("Logic_UGC_Res_Manager:_DownloadTemplateRes res had finish , ID:%d", templateInfo.ID))
    else
      local AllAssetIDList, AllFeatureKeyList = self:_GetNotPublishModResList(templateInfo)
      idList = AllAssetIDList
      cacheInfo.depends = AllAssetIDList
      local PufferUGCPakManager = self:_GetPufferUGCPakManager()
      local idState = PufferUGCPakManager:GetStateByKeyList(PufferConst.ENUM_DownloadType.UGCPAK, AllAssetIDList)
      if idState ~= PufferConst.ENUM_DownloadState.Done then
        log(bWriteLog and string.format("Logic_UGC_Res_Manager:_DownloadTemplateRes download idListstate:%d", idState))
        PufferManager.Download(PufferConst.ENUM_DownloadType.UGCPAK, AllAssetIDList, PufferTlog.Enum_TLog_From.UGC, nil, defaultExtraParams)
      end
      local puffer_odpak_downloader = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_downloader)
      puffer_odpak_downloader:DownloadByKeyList(PufferConst.ENUM_DownloadType.ODPAK, AllFeatureKeyList)
      if PufferManager.GetState(PufferConst.ENUM_DownloadType.MAP, {
        PufferConst.UGC_EDIT_MAPKEY
      }) ~= PufferConst.ENUM_DownloadState.Done then
        log(bWriteLog and string.format("Logic_UGC_Res_Manager:_DownloadTemplateRes download creative edit"))
        PufferManager.Download(PufferConst.ENUM_DownloadType.MAP, {
          PufferConst.UGC_EDIT_MAPKEY
        }, PufferTlog.Enum_TLog_From.UGC, nil, defaultExtraParams)
      end
      mapState = PufferManager.GetState(PufferConst.ENUM_DownloadType.MAP, {mapKey})
      if mapState ~= PufferConst.ENUM_DownloadState.Done then
        PufferManager.Download(PufferConst.ENUM_DownloadType.MAP, {mapKey}, PufferTlog.Enum_TLog_From.UGC, nil, defaultExtraParams)
        cacheInfo.mapKey = mapKey
        log(bWriteLog and "Logic_UGC_Res_Manager:_DownloadTemplateRes mapkey not finish:" .. mapKey)
      end
      cacheInfo.state = PufferConst.ENUM_DownloadState.Download
      log(bWriteLog and string.format("Logic_UGC_Res_Manager:_DownloadTemplateRes res not finish , ID:%d", templateInfo.ID))
    end
    self:_SendDownloadTLog(templateInfo, "_DownloadTemplateRes", mapState, mapKey, nil, idList, nil, loadedBundle)
    return isFinish
  else
    log(bWriteLog and string.format("Logic_UGC_Res_Manager:_DownloadTemplateRes mapkey is nil , ID:%d", templateInfo.ID))
    return true
  end
end

function Logic_UGC_Res_Manager:_PauseTemplateRes(templateInfo)
  local cacheKey = self:_GetCacheKeyByTemplateInfoID(templateInfo.ID)
  if not cacheKey then
    return
  end
  local cacheInfo = self:GetUGCModCacheInfo(cacheKey)
  cacheInfo.state = PufferConst.ENUM_DownloadState.Pause
  local cacheInfos = self.modResCaches
  local bExistOtherMapKey = false
  if cacheInfo.mapKey then
    for mK, mV in pairs(cacheInfos) do
      if mV.state == PufferConst.ENUM_DownloadState.Download and mV.mapKey == cacheInfo.mapKey then
        bExistOtherMapKey = true
        break
      end
    end
    if not bExistOtherMapKey then
      PufferManager.Pause(PufferConst.ENUM_DownloadType.MAP, {
        cacheInfo.mapKey
      })
    end
  end
  local ownDepends = cacheInfo.depends
  local onlyDepends = {}
  if ownDepends and 0 < #ownDepends then
    local bExistTeamRes = false
    for dKey, dValue in pairs(ownDepends) do
      local bExistOtherDepends = false
      for curKey, curValue in pairs(cacheInfos) do
        if curValue.state == PufferConst.ENUM_DownloadState.Download and curValue.bundleKey then
          bExistTeamRes = true
          break
        end
        if curValue.state == PufferConst.ENUM_DownloadState.Download and curValue.depends then
          for otherDependsKey, otherDependsValue in pairs(curValue.depends) do
            if dValue == otherDependsValue then
              bExistOtherDepends = true
              break
            end
          end
        end
        if bExistOtherDepends then
          break
        end
      end
      if bExistTeamRes then
        break
      end
      if not bExistOtherDepends then
        table.insert(onlyDepends, dValue)
      end
    end
    if not bExistTeamRes and 0 < #onlyDepends then
      if bWriteLog then
        log(bWriteLog and "Logic_UGC_Res_Manager:_PauseTemplateRes onlyDepends start")
        for _k, _v in pairs(onlyDepends) do
          log(bWriteLog and string.format("Logic_UGC_Res_Manager:_PauseTemplateRes onlyDepends v:%s", tostring(_v)))
        end
        log(bWriteLog and "Logic_UGC_Res_Manager:_PauseTemplateRes onlyDepends end")
      end
      PufferManager.Pause(PufferConst.ENUM_DownloadType.UGCPAK, onlyDepends)
    end
  end
  local bExistOther20W = false
  for mK, mV in pairs(cacheInfos) do
    if mV.state == PufferConst.ENUM_DownloadState.Download and mV.packKey and mV.packKey == PufferConst.EODPackID.WOW_20W then
      bExistOther20W = true
      break
    end
  end
  if not bExistOther20W then
    LogicPufferBundle.StopDownloadPackList({
      PufferConst.EODPackID.WOW_20W
    })
    PufferManager.Pause(PufferConst.ENUM_DownloadType.MAP, {
      PufferConst.UGC_EDIT_MAPKEY
    })
  end
  self:_SendPauseTLog(templateInfo, "PauseTemplateRes", bExistOtherMapKey, cacheInfo.mapKey, onlyDepends, nil, nil)
end

function Logic_UGC_Res_Manager:_GetUGCTemplateResSize(templateInfo)
  local mapKey = self:GetUGCMapKeyByTemplateId(templateInfo.ID, templateInfo.MapID)
  local cSize, tSize = PufferManager.GetSize(PufferConst.ENUM_DownloadType.MAP, {mapKey})
  cSize = cSize / PufferConst.MB
  tSize = tSize / PufferConst.MB
  log(bWriteLog and string.format("Logic_UGC_Res_Manager:_GetUGCTemplateResSize mapkey:%s , cSize:%.2f ,tSize:%.2f", mapKey, cSize, tSize))
  local tempcSize, temptSize = PufferManager.GetSize(PufferConst.ENUM_DownloadType.MAP, {
    PufferConst.UGC_EDIT_MAPKEY
  })
  cSize = cSize + tempcSize / PufferConst.MB
  tSize = tSize + temptSize / PufferConst.MB
  local AllAssetIDList, AllFeatureKeyList = self:_GetNotPublishModResList(templateInfo)
  local puffer_odpak_manager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_manager)
  tempcSize, temptSize = puffer_odpak_manager:GetSizeByKeyList(PufferConst.ENUM_DownloadType.ODPAK, AllFeatureKeyList)
  cSize = cSize + tempcSize / PufferConst.MB
  tSize = tSize + temptSize / PufferConst.MB
  local PufferUGCPakManager = self:_GetPufferUGCPakManager()
  tempcSize, temptSize = PufferUGCPakManager:GetSizeByKeyList(PufferConst.ENUM_DownloadType.UGCPAK, AllAssetIDList, nil, true)
  cSize = cSize + tempcSize / PufferConst.MB
  tSize = tSize + temptSize / PufferConst.MB
  return cSize, tSize
end

function Logic_UGC_Res_Manager:_GetUGCMapConfigByTemplateId(templateId, mapID)
  if mapID == nil then
    local templateConfig = CDataTable.GetTableData("UGCTemplateConfig", templateId)
    if templateConfig == nil then
      return nil
    end
    mapID = templateConfig.MapID
  else
    print(bWriteLog and "Logic_UGC_Res_Manager:_GetUGCMapConfigByTemplateId  have MapID " .. tostring(mapID))
  end
  local mapConfig = CDataTable.GetTableData("Map", mapID)
  if mapConfig == nil then
    return nil
  end
  return mapConfig
end

function Logic_UGC_Res_Manager:_GetUGCTemplateListSize(TemplateList)
  local cSize, tSize = self:_GetUGCBasicResSize()
  local PufferMapManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager)
  local excludeMapKey = PufferMapManager:GetMapDepends(PufferConst.UGC_BASIC_MAPKEY)
  local mapKeyDic = {}
  local idDic = {}
  local FeatureKeyDic = {}
  for i, v in ipairs(TemplateList) do
    local mapKey = self:GetUGCMapKeyByTemplateId(v.ID)
    if mapKey then
      mapKeyDic[mapKey] = true
    end
    local AllAssetIDList, AllFeatureKeyList = self:_GetNotPublishModResList(v)
    if AllAssetIDList then
      for kk, vv in pairs(AllAssetIDList) do
        idDic[vv] = true
      end
    end
    if AllFeatureKeyList then
      for kk, vv in pairs(AllFeatureKeyList) do
        FeatureKeyDic[vv] = true
      end
    end
  end
  local mapKeyList = TableUtil.GetKeys(mapKeyDic)
  local mcSize, mtSize = PufferManager.GetSize(PufferConst.ENUM_DownloadType.MAP, mapKeyList, false, excludeMapKey, true)
  cSize = cSize + mcSize / PufferConst.MB
  tSize = tSize + mtSize / PufferConst.MB
  local idList = TableUtil.GetKeys(idDic)
  local PufferUGCPakManager = self:_GetPufferUGCPakManager()
  local idcSize, idtSize = PufferUGCPakManager:GetSizeByKeyList(PufferConst.ENUM_DownloadType.UGCPAK, idList, nil, true)
  cSize = cSize + idcSize / PufferConst.MB
  tSize = tSize + idtSize / PufferConst.MB
  local FeatureKeyList = TableUtil.GetKeys(FeatureKeyDic)
  local PufferODPakManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_manager)
  local cFeatureSize, tFeatureSize = PufferODPakManager:GetSizeByKeyList(PufferConst.ENUM_DownloadType.ODPAK, FeatureKeyList)
  cSize = cSize + cFeatureSize / PufferConst.MB
  tSize = tSize + tFeatureSize / PufferConst.MB
  local LogicUGCAssetHub = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAssetHub)
  local cAssetHubSize, tAssetHubSize = LogicUGCAssetHub:GetModListAssetSize(TemplateList)
  cSize = cSize + cAssetHubSize
  tSize = tSize + tAssetHubSize
  return cSize, tSize
end

function Logic_UGC_Res_Manager:_GetUGCBasicResSize()
  local cSize, tSize = PufferManager.GetSize(PufferConst.ENUM_DownloadType.MAP, {
    PufferConst.UGC_BASIC_MAPKEY
  })
  cSize = cSize / PufferConst.MB
  tSize = tSize / PufferConst.MB
  return cSize, tSize
end

function Logic_UGC_Res_Manager:_GetUGCEditResSize()
  local cSize, tSize = PufferManager.GetSize(PufferConst.ENUM_DownloadType.MAP, {
    PufferConst.UGC_EDIT_MAPKEY
  })
  cSize = cSize / PufferConst.MB
  tSize = tSize / PufferConst.MB
  return cSize, tSize
end

function Logic_UGC_Res_Manager:GetDependAssetParamsByIntMap(feature_id_list)
  feature_id_list = feature_id_list or {}
  local bitList = {}
  local size = 32
  for k, v in pairs(feature_id_list) do
    if v and 0 < v then
      local margin = size * (k - 1)
      local tmpList = FuncUtil.Int2ByteList(v)
      if tmpList ~= nil then
        for bitKey, bitV in ipairs(tmpList) do
          bitV = bitV + margin
          table.insert(bitList, bitV)
        end
      end
    end
  end
  local idList = {}
  for k, v in ipairs(bitList) do
    table.insert(idList, v)
  end
  return idList
end

function Logic_UGC_Res_Manager:_GetAllLevelResDepends(ModInfo)
  local allLevelRes = TableUtil.GetTableValue(ModInfo, "setting", "all_level_res")
  if not allLevelRes or not next(allLevelRes) then
    return nil, nil
  end
  local allAssetIDList = {}
  local allAssetParamList = {}
  for levelIdx, levelRes in pairs(allLevelRes) do
    if levelRes then
      if levelRes.res_list then
        local levelAssetIDList = self:GetDependIdsByIntMap(levelRes.res_list)
        if levelAssetIDList then
          for _, assetID in ipairs(levelAssetIDList) do
            table.insert(allAssetIDList, assetID)
          end
        end
      end
      if levelRes.feature_id_list then
        local levelAssetParamList = self:GetDependAssetParamsByIntMap(levelRes.feature_id_list)
        if levelAssetParamList then
          for _, param in ipairs(levelAssetParamList) do
            table.insert(allAssetParamList, param)
          end
        end
      end
    end
  end
  return allAssetIDList, allAssetParamList
end

function Logic_UGC_Res_Manager:_RemoveReportResTimer()
  if self.reportTimer then
    self:RemoveCommonEvent(EVENTTYPE_MATCH, EVENTID_MATCH_MODE_SELECT_CHANGE)
    local time_ticker = require("common.time_ticker")
    time_ticker.RemoveTimer(self.reportTimer)
    self.reportTimer = nil
    self.reportModInfo = nil
    self.bReportPauseState = nil
    self.state = nil
  end
end

function Logic_UGC_Res_Manager:_GetCacheKeyByModInfo(modInfo, bMyWork)
  local cacheKey
  if modInfo then
    if modInfo.mod_id then
      if bMyWork then
        cacheKey = modInfo.mod_id .. "_update"
      else
        cacheKey = modInfo.mod_id
      end
    elseif modInfo.base.uid and modInfo.base.slot then
      cacheKey = tostring(modInfo.base.uid) .. "_" .. tostring(modInfo.base.slot)
      if modInfo.base.save_type then
        cacheKey = cacheKey .. "_shot" .. tostring(modInfo.base.save_type) .. "_" .. tostring(modInfo.base.save_slot or 0)
      end
    elseif modInfo.base.template_id then
      cacheKey = modInfo.base.template_id .. "_no_id"
    end
  else
    cacheKey = "no_cachekey"
    log(bWriteLog and "Logic_UGC_Res_Manager:_GetCacheKeyByModInfo cachekey is :no_cachekey")
  end
  return cacheKey
end

function Logic_UGC_Res_Manager:_GetCacheKeyByTemplateInfoID(templateInfoID)
  local cacheKey
  local mapKey = self:GetUGCMapKeyByTemplateId(templateInfoID)
  if mapKey ~= nil then
    cacheKey = mapKey .. tostring(templateInfoID)
  else
    cacheKey = "no_templateKey"
  end
  return cacheKey
end

function Logic_UGC_Res_Manager:_IsPublishMod(modInfo)
  if not self.bResListMinDepends then
    return false
  end
  return modInfo.mod_id ~= nil
end

function Logic_UGC_Res_Manager:_GetPufferUGCPakManager()
  local PufferUGCPakManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_ugcpak_manager)
  return PufferUGCPakManager
end

function Logic_UGC_Res_Manager:_GetLocalModList()
  if self.localModList == nil then
    local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
    self.localModList = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eUGCCacheLocalMod)
    if self.localModList == nil then
      self.localModList = {}
    end
  end
  return self.localModList
end

function Logic_UGC_Res_Manager:_AddModToLocal(modId)
  local localModList = self:_GetLocalModList()
  for k, v in ipairs(localModList) do
    if v == modId then
      table.remove(localModList, k)
      break
    end
  end
  table.insert(localModList, 1, modId)
  local limit = 50
  local num = #localModList
  if limit < num then
    local surp = num - limit
    for i = 1, surp do
      table.remove(localModList, num - i + 1)
    end
  end
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  PlayerPrefsSystem.SaveTableToFile_N(localModList, PlayerPrefsSystem.ePlayerPrefsType.eUGCCacheLocalMod)
end

function Logic_UGC_Res_Manager:_SendDownloadTLog(modInfo, key, mapState, mapKey, idState, idList, basicLoaded, bundleLoaded)
  local tlogExtra = {}
  if modInfo then
    if modInfo.mod_id then
      tlogExtra.modid = modInfo.mod_id
    elseif modInfo.base and modInfo.base.slot then
      tlogExtra.slot = modInfo.base.slot
    elseif modInfo.id then
      tlogExtra.id = modInfo.ID
    end
    if modInfo.setting and modInfo.setting.name then
      tlogExtra.modname = modInfo.setting.name
    elseif modInfo.DefaultCreateName then
      tlogExtra.modname = modInfo.DefaultCreateName
    end
  end
  if mapState ~= PufferConst.ENUM_DownloadState.Done then
    tlogExtra.mapkey = mapKey
  end
  if idState ~= PufferConst.ENUM_DownloadState.Done then
    tlogExtra.idlist = idList
  end
  if basicLoaded == false then
    tlogExtra.basic = 1
  end
  if bundleLoaded == false then
    tlogExtra.bundle = 1
  end
  PufferTlog.SendTLog(PufferTlog.Enum_TLog_From.UGCDownload, PufferTlog.Enum_TLog_Optype.Start, key, tlogExtra)
end

function Logic_UGC_Res_Manager:_SendPauseTLog(modInfo, key, bExistOtherMapKey, mapKey, idList, existOtherBasic, existBundle)
  local tlogExtra = {}
  if modInfo then
    if modInfo.mod_id then
      tlogExtra.modid = modInfo.mod_id
    elseif modInfo.base and modInfo.base.slot then
      tlogExtra.slot = modInfo.base.slot
    elseif modInfo.id then
      tlogExtra.id = modInfo.ID
    end
    if modInfo.setting and modInfo.setting.name then
      tlogExtra.modname = modInfo.setting.name
    elseif modInfo.DefaultCreateName then
      tlogExtra.modname = modInfo.DefaultCreateName
    end
  end
  if bExistOtherMapKey and mapKey then
    tlogExtra.mapkey = mapKey
  end
  if idList and 0 < #idList then
    tlogExtra.idlist = idList
  end
  if existOtherBasic then
    tlogExtra.basic = 1
  end
  if existBundle then
    tlogExtra.bundle = 1
  end
  PufferTlog.SendTLog(PufferTlog.Enum_TLog_From.UGCPause, PufferTlog.Enum_TLog_Optype.Cancel, key, tlogExtra)
end

function Logic_UGC_Res_Manager:_GetTlogCacheTime()
  if self.existTimeCache == nil then
    local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
    local timeCache = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eUGCTLogTimeCacheKey)
    if timeCache == nil then
      timeCache = {}
    end
    self.existTimeCache = timeCache
  end
  return self.existTimeCache
end

function Logic_UGC_Res_Manager:_GetTlogLastTimeByKey(key)
  local timeCache = self:_GetTlogCacheTime()
  local lastTime = timeCache[key]
  if lastTime == nil then
    lastTime = 0
  end
  return lastTime
end

function Logic_UGC_Res_Manager:_CheckReportResState(modInfo, bReportPauseState, state)
  self.reportModInfo = modInfo
  self.bReportPauseState = bReportPauseState
  self.state = state
  if self.reportTimer == nil then
    self:AddCommonEvent(EVENTTYPE_MATCH, EVENTID_MATCH_MODE_SELECT_CHANGE, self.CheckMatchInfoChange, self)
    local time_ticker = require("common.time_ticker")
    self.reportTimer = time_ticker.AddTimerLoop(1, function()
      self:Send_update_client_mod_info_ByModInfo(self.reportModInfo, true, self.bReportPauseState, self.state)
      EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_NOTIFY_THEME_RES_INFO)
    end, TIMER_INFINITE, 1)
  end
end

function Logic_UGC_Res_Manager:_SaveTlogTime(key)
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local TimeUtil = require("client.common.time_util")
  local serverTime = TimeUtil.GetServerTimeInSec()
  local existTimeCache = self:_GetTlogCacheTime()
  existTimeCache[key] = serverTime
  PlayerPrefsSystem.SaveTableToFile_N(existTimeCache, PlayerPrefsSystem.ePlayerPrefsType.eUGCTLogTimeCacheKey)
end

function Logic_UGC_Res_Manager:_GetModVersion(ModInfo)
  if ModInfo and ModInfo.base then
    return ModInfo.base.version or 10000
  end
  return 10000
end

function Logic_UGC_Res_Manager:_IsNewMeta(ModInfo)
  if ModInfo and ModInfo.base and ModInfo.base.template_id and ModInfo.base.template_id == 59 then
    return true, 10019
  end
  local version = self:_GetModVersion(ModInfo)
  return version >= Config_UGC.MetaWithAssetParamVersion, version
end

function Logic_UGC_Res_Manager:_GetResTypeDepends(ResTypeList)
  if ResTypeList == nil then
    return {}, {}
  end
  local DependFeatureKeysMap = {}
  local DependAssetIDsMap = {}
  for k, ResType in pairs(ResTypeList) do
    local PufferUGCPakManager = self:_GetPufferUGCPakManager()
    local AllDependFeatureKeys = PufferUGCPakManager.AllResTypeFeatureMap[ResType]
    if AllDependFeatureKeys then
      for FeatureID, v in pairs(AllDependFeatureKeys) do
        DependFeatureKeysMap[FeatureID] = true
      end
    end
    local AllDependAssetID = PufferUGCPakManager.AllResTypeAssetIDMap[ResType]
    if AllDependAssetID then
      for AssetID, v in pairs(AllDependAssetID) do
        DependAssetIDsMap[AssetID] = true
      end
    end
  end
  local DependFeatureKeys = {}
  local DependAssetIDs = {}
  for k, v in pairs(DependFeatureKeysMap) do
    table.insert(DependFeatureKeys, k)
  end
  for k, v in pairs(DependAssetIDsMap) do
    table.insert(DependAssetIDs, k)
  end
  return DependFeatureKeys, DependAssetIDs
end

function Logic_UGC_Res_Manager:_GetAssetParamDepends(AssetParamList)
  local PufferUGCPakManager = self:_GetPufferUGCPakManager()
  local DependFeatureKeysMap = {}
  local DependAssetIDMap = {}
  for k, AssetParamID in pairs(AssetParamList) do
    local AssetParamInfo = PufferUGCPakManager.AllAssetParamsMap[AssetParamID]
    if AssetParamInfo then
      for k, v in pairs(AssetParamInfo.DependFeatureIDList) do
        DependFeatureKeysMap[v] = true
      end
      for k, v in pairs(AssetParamInfo.DependAssetIDList) do
        DependAssetIDMap[v] = true
      end
      if AssetParamID == 422 then
        local resTypeFeatureMap = PufferUGCPakManager.AllResTypeFeatureMap[3]
        if resTypeFeatureMap then
          for featureKey, _ in pairs(resTypeFeatureMap) do
            DependFeatureKeysMap[featureKey] = true
          end
        end
      end
    end
  end
  local DependFeatureKeysList = {}
  local DependAssetIDList = {}
  for k, v in pairs(DependFeatureKeysMap) do
    table.insert(DependFeatureKeysList, k)
  end
  for k, v in pairs(DependAssetIDMap) do
    table.insert(DependAssetIDList, k)
  end
  return DependFeatureKeysList, DependAssetIDList
end

function Logic_UGC_Res_Manager:_GetNotPublishModResList(ModInfo)
  local AllFeatureKeyMap = {}
  local AllAssetIDMap = {}
  local CacheInfo, CacheKey
  if self:IsTemplate(ModInfo) then
    CacheKey = self:_GetCacheKeyByTemplateInfoID(ModInfo.ID)
  else
    CacheKey = self:_GetCacheKeyByModInfo(ModInfo, true)
  end
  CacheInfo = self:GetUGCModCacheInfo(CacheKey)
  if CacheInfo and CacheInfo.AllAssetIDList and CacheInfo.AllFeatureKeyList then
    return CacheInfo.AllAssetIDList, CacheInfo.AllFeatureKeyList
  end
  local DependAssetIDList1, DependFeatureKeysList1 = self:GetAllResList(ModInfo, true)
  if DependAssetIDList1 then
    for k, v in pairs(DependAssetIDList1) do
      AllAssetIDMap[v] = true
    end
  end
  if DependFeatureKeysList1 then
    for k, v in pairs(DependFeatureKeysList1) do
      AllFeatureKeyMap[v] = true
    end
  end
  if not IsWoWEditor then
    for _, PackID in ipairs(UGCPackIDList) do
      local AssetIDInPack = self.AssetIDInPacks and self.AssetIDInPacks[PackID]
      if AssetIDInPack then
        for k, v in pairs(AssetIDInPack) do
          AllAssetIDMap[k] = true
        end
      end
    end
    local PufferUGCPakManager = self:_GetPufferUGCPakManager()
    if PufferUGCPakManager.PackFeatureList then
      for _, PackID in ipairs(UGCPackIDList) do
        local FeatureList = PufferUGCPakManager.PackFeatureList[PackID]
        if FeatureList then
          for k, v in pairs(FeatureList) do
            AllFeatureKeyMap[v] = true
          end
        end
      end
    end
    local DependFeatureKeysList3, DependAssetIDList3 = self:_GetResTypeDepends(Config_UGC.EditorTypeDependResType)
    if DependAssetIDList3 then
      for k, v in pairs(DependAssetIDList3) do
        AllAssetIDMap[v] = true
      end
    end
    if DependFeatureKeysList3 then
      for k, v in pairs(DependFeatureKeysList3) do
        AllFeatureKeyMap[v] = true
      end
    end
  end
  local AllFeatureKeyList = {}
  for k, v in pairs(AllFeatureKeyMap) do
    table.insert(AllFeatureKeyList, k)
  end
  local AllAssetIDList = {}
  for k, v in pairs(AllAssetIDMap) do
    table.insert(AllAssetIDList, k)
  end
  if CacheInfo then
    CacheInfo.AllAssetIDList = AllAssetIDList
    CacheInfo.AllFeatureKeyList = AllFeatureKeyList
  end
  return AllAssetIDList, AllFeatureKeyList
end

local class = require("class")
local CModuleBase = require("client.module_framework.ModuleBase")
local CResManager = class(CModuleBase, nil, Logic_UGC_Res_Manager)
return CResManager
