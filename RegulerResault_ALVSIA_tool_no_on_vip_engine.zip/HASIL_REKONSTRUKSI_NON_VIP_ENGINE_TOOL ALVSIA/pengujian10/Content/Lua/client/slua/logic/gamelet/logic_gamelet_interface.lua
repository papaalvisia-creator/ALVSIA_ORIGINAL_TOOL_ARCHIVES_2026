local logic_gamelet_interface = {}
local gamelet_define = require("client.slua.logic.gamelet.gamelet_define")
local gamelet_config = gamelet_define.GameletAppConfig
local Enum_GameletEnv = gamelet_define.Enum_GameletEnv
local Enum_IMSDKEnv = gamelet_define.Enum_IMSDKEnv
local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")

function logic_gamelet_interface:DefineAndResetData()
  self.nonage = 1
  self.gamelet_apps_info = {}
  self.AppType2AppId = {}
  self.has_inited = false
  self.OpenedAppId = ""
  self.GAMELET_SLOW_TICK_INTERVAL = 3600
  self.gamelet_in_slow_tick_status = false
  self.ViewCreatedHandleMap = {}
  self.ViewDestroyHandleMap = {}
  self.DisableReason = 0
  self.bOpenGamelet = false
end

function logic_gamelet_interface:OnInitialize()
  logic_gamelet_interface.__super.OnInitialize(self)
  local Gamelet, GameletSettings
  if self:gamelet_enable() then
    Gamelet = import("Gamelet")
    GameletSettings = import("GameletSettings")
  end
  if Gamelet then
    self.gamelet = Gamelet.Get()
  end
  if GameletSettings then
    self.gamelet_setting = GameletSettings.Get()
  end
end

function logic_gamelet_interface:OnPostSwitchGameStatus(preState, nextState)
  if nextState == GameStatus.Fighting and not GameStatus.IsInMainCity() then
    self.gamelet_in_slow_tick_status = true
    self:SetTickIntervalSec(self.GAMELET_SLOW_TICK_INTERVAL)
  else
    self.gamelet_in_slow_tick_status = false
    self:SetTickIntervalSec(0)
  end
end

function logic_gamelet_interface:gamelet_enable()
  log(bWriteLog and "logic_gamelet_interface:gamelet_enable.")
  local memorySize = Client.GetMemorySize()
  log(bWriteLog and "logic_gamelet_interface:gamelet_enable memory size:" .. tostring(memorySize))
  if memorySize <= 2 then
    local DisableMem2GGameletSDK = HDmpveRemote.HDmpveRemoteConfigGetBool("DisableMem2GGameletSDK", false)
    log(bWriteLog and "logic_gamelet_interface:gamelet_enable DisableMem2GGameletSDK:" .. tostring(DisableMem2GGameletSDK))
    if DisableMem2GGameletSDK then
      self.DisableReason = gamelet_define.DisableReason.LowMem
      log(bWriteLog and "logic_gamelet_interface:gamelet_enable disabled due to low memory")
      return false
    end
  end
  if PublishRegionMacros.IsBlueholeOperationRegion() then
    self.DisableReason = gamelet_define.DisableReason.RegionForbidden
    log(bWriteLog and "logic_gamelet_interface:gamelet_enable disabled due to BLUEHOLE region")
    return false
  end
  local DisableGameletSDK = HDmpveRemote.HDmpveRemoteConfigGetBool("DisableGameletSDK", false)
  log(bWriteLog and "logic_gamelet_interface:gamelet_enable DisableGameletSDK:" .. tostring(DisableGameletSDK))
  if DisableGameletSDK == true then
    self.DisableReason = gamelet_define.DisableReason.RemoteSwitchClosed
    log(bWriteLog and "logic_gamelet_interface:gamelet_enable disabled due to remote switch closed")
    return false
  end
  log(bWriteLog and "logic_gamelet_interface:gamelet_enable all checks passed, enabled")
  return true
end

function logic_gamelet_interface:RegistEvents()
  if self.gamelet_setting then
    self:AddControlEvent(self.gamelet_setting, "OnSDKMessage", self.OnSDKMessage, self)
    self:AddControlEvent(self.gamelet_setting, "OnRefreshUserdata", self.OnRefreshUserdata, self)
    self:AddControlEvent(self.gamelet_setting, "OnViewCreated", self.OnViewCreated, self)
    self:AddControlEvent(self.gamelet_setting, "OnViewAboutToDestroy", self.OnViewAboutToDestroy, self)
    self:AddControlEvent(self.gamelet_setting, "OnReportData", self.OnReportData, self)
    self:AddControlEvent(self.gamelet_setting, "OnCoreCodeLoad", self.OnCoreCodeLoad, self)
  end
end

function logic_gamelet_interface:OnLogin(bReLogin)
end

function logic_gamelet_interface:OnLoginGameLetImpl(bReLogin)
  if self.has_inited == false then
    if self.bGameletIniting then
      log(bWriteLog and "logic_gamelet_interface:OnLoginGameLetImpl: side-load so still preparing, skip duplicated init")
      return
    end
    self.bGameletIniting = true
    self:SetupPixLibrary(function()
      self.bGameletIniting = false
      self:InitializeGameletSDKAndRes()
      self:DelayOpenGamelet()
    end)
    return
  end
  self:DelayOpenGamelet()
end

function logic_gamelet_interface:InitializeGameletSDKAndRes()
  self:InitializeSDK()
  local curLanguage = Client.GetCurrentLanguage()
  local LanguageMacros = require("client.slua.config.ClientMacros.LanguageMacros")
  if curLanguage == LanguageMacros.MY then
    curLanguage = LanguageMacros.EN
  end
  if curLanguage == LanguageMacros.MY then
    self:SetFont("ZawgyiOneFont", "/Game/UMG/Font/ZawgyiOneFont.ZawgyiOneFont")
  else
    self:SetFont("TSLFont", "/Game/UMG/Font/TSLFont.TSLFont")
  end
  if not PublishRegionMacros.IsBlueholeOperationRegion() then
    local PixUIBPLibrary = import("PixUIBPLibrary")
    if PixUIBPLibrary and PixUIBPLibrary.PixUI_SetSupportTextShape then
      PixUIBPLibrary.PixUI_SetSupportTextShape(curLanguage ~= LanguageMacros.MY)
    end
  end
  self:InitializeGameletLog()
  Client.InitIOSNotchSize()
  self.has_inited = true
end

function logic_gamelet_interface:DelayOpenGamelet()
  local async = require("client.common.async")
  async.Run(function(co)
    async.AwaitEvent(co, 0.5, EVENTTYPE_GAMELET, EVENTID_GAMELET_DELAY_OPEN)
    self:Open()
  end)
end

function logic_gamelet_interface:OnLogOut()
  self:Close()
  local LogicGameletRedPoint = require("client.slua.logic.gamelet.LogicGameletRedPoint")
  LogicGameletRedPoint:OnLogOut()
end

function logic_gamelet_interface:OnPreSwitchGameStatus(preState, nextState)
  if GameStatus.IsPreSwitchEnterFightingFromLobbyOrMainCity(preState, nextState) then
    self:CloseApp()
  end
  local LogicGameletLayer = require("client.slua.logic.gamelet.LogicGameletLayer")
  LogicGameletLayer:DestroyData()
end

function logic_gamelet_interface:OnSDKMessage(msg)
  log(bWriteLog and string.format("logic_gamelet_interface:OnSDKMessage: %s", msg))
  local message = json.decode(msg)
  local GameletOnDemand = require("client.slua.logic.gamelet.GameletOnDemand")
  if GameletOnDemand:TryHandleSDKMessage(message) then
    return 0
  end
  local appId = message.appId
  local appType = self:get_app_type(appId) or message.appName
  local HostedProtoBridge = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.HostedProtoBridge)
  HostedProtoBridge:OnReceiveMessage(appType, tostring(appId), msg, message)
  return 0
end

function logic_gamelet_interface:OnRefreshUserdata()
  log(bWriteLog and "logic_gamelet_interface:OnRefreshUserdata")
  local user_data = self:get_current_user_data()
  self:RefreshUserdata(user_data)
  return 0
end

function logic_gamelet_interface:OnViewCreated(widget, app_info)
  log(bWriteLog and "logic_gamelet_interface:OnViewCreated app_info:" .. tostring(app_info))
  local AppInfo
  if app_info ~= nil and type(app_info) == "string" then
    AppInfo = json.decode(app_info)
  else
    AppInfo = {
      belongToApp = self.OpenedAppId,
      appPage = app_info and app_info.appPage
    }
  end
  log_tree("AppInfo:", AppInfo)
  local keyName = AppInfo.appPage .. AppInfo.belongToApp
  if self.ViewCreatedHandleMap[keyName] ~= nil then
    self.ViewCreatedHandleMap[keyName](widget, AppInfo)
  else
    if widget then
      local ui_depth_manager = require("client.common.uibase.ui_depth_manager")
      local depth = ui_depth_manager.ShowPandaUI(keyName)
      local game_frontend_hud = require("game_frontend_hud")
      game_frontend_hud.AddToContainer(UIContainers.Default, widget, depth)
    end
    if not UIManager.IsUIShow(UIManager.UI_Config.GameletSDK_UIBP) then
      UIManager.ShowUI(UIManager.UI_Config.GameletSDK_UIBP, AppInfo.belongToApp)
    end
  end
end

function logic_gamelet_interface:OnViewAboutToDestroy(widget, app_info)
  log(bWriteLog and "logic_gamelet_interface:OnViewAboutToDestroy")
  if widget then
    local game_frontend_hud = require("game_frontend_hud")
    game_frontend_hud.RemoveFromContainer(UIContainers.Default, widget)
  end
  local AppInfo
  if app_info ~= nil and type(app_info) == "string" then
    AppInfo = json.decode(app_info)
  else
    AppInfo = {
      belongToApp = self.OpenedAppId,
      appPage = app_info and app_info.appPage
    }
  end
  if AppInfo then
    local keyName = AppInfo.appPage .. AppInfo.belongToApp
    local ui_depth_manager = require("client.common.uibase.ui_depth_manager")
    ui_depth_manager.HidePandaUI(keyName)
    if self.ViewDestroyHandleMap[keyName] ~= nil then
      self.ViewDestroyHandleMap[keyName](widget, AppInfo)
    end
  end
  if self.gamelet_in_slow_tick_status == true then
    self:SetTickIntervalSec(self.GAMELET_SLOW_TICK_INTERVAL)
  end
end

function logic_gamelet_interface:OnReportData(event_name, data)
  log(bWriteLog and string.format("logic_gamelet_interface:OnReportData: %s, %s", event_name, data))
end

function logic_gamelet_interface:OnCoreCodeLoad()
  log(bWriteLog and "logic_gamelet_interface:OnCoreCodeLoad")
  local gameletCoreEmbedJS = string.format("%sTemplates/Data/Gamelet/Content/gameletcore_embedded.js", Client.ProjectContentDir())
  local fileData = Client.LoadFileToArrayByFullPath(gameletCoreEmbedJS)
  return true, fileData
end

function logic_gamelet_interface:InitializeSDK()
  log(bWriteLog and "logic_gamelet_interface:InitializeSDK")
  if self.gamelet == nil then
    return
  end
  local ret = self.gamelet:Initialize(self.gamelet_setting)
  log(bWriteLog and "logic_gamelet_interface:InitializeSDK result: " .. tostring(ret))
end

function logic_gamelet_interface:SetFont(font_name, font_path)
  log(bWriteLog and string.format("logic_gamelet_interface:SetFont: %s, %s", font_name, font_path))
  if self.gamelet == nil then
    return
  end
  self.gamelet:SetFont(font_name, font_path)
end

function logic_gamelet_interface:Open()
  log(bWriteLog and "logic_gamelet_interface:Open")
  if self.bOpenGamelet then
    log(bWriteLog and "logic_gamelet_interface:Open. already open")
    return
  end
  if self.gamelet == nil then
    log(bWriteLog and "logic_gamelet_interface:Open. gamelet is nil")
    return
  end
  self.bOpenGamelet = true
  self.gamelet_apps_info = {}
  local gamelet_env = self:get_env()
  local user_data = self:get_current_user_data()
  self.gamelet:Open(gamelet_env, user_data)
end

function logic_gamelet_interface:OpenApp(app_id, args_json)
  log(bWriteLog and "logic_gamelet_interface:OpenApp")
  if self.gamelet == nil then
    return -1
  end
  self:SetTickIntervalSec(0)
  self.OpenedAppId = app_id
  log(bWriteLog and string.format("logic_gamelet_interface:OpenApp args_json: %s", args_json))
  return self.gamelet:OpenApp(app_id, args_json)
end

function logic_gamelet_interface:AddViewCreatedHandle(keyName, handleFunc, ...)
  if self.ViewCreatedHandleMap[keyName] ~= nil then
    print(bWriteLog and "logic_gamelet_interface:AddViewCreatedHandle keyName already exist" .. tostring(keyName))
    return
  end
  print(bWriteLog and "logic_gamelet_interface:AddViewCreatedHandle keyName:" .. tostring(keyName))
  local common = require("client.slua_ui_framework.common")
  local args = table.pack(...)
  
  local function handle(...)
    return common.CallCombinationArgs(handleFunc, args, ...)
  end
  
  self.ViewCreatedHandleMap[keyName] = handle
end

function logic_gamelet_interface:RemoveViewCreatedHandle(keyName)
  if self.ViewCreatedHandleMap[keyName] ~= nil then
    print(bWriteLog and "logic_gamelet_interface:RemoveViewCreatedHandle keyName:" .. tostring(keyName))
    self.ViewCreatedHandleMap[keyName] = nil
  end
end

function logic_gamelet_interface:AddViewDestroyHandle(keyName, handleFunc, ...)
  if self.ViewDestroyHandleMap[keyName] ~= nil then
    print(bWriteLog and "logic_gamelet_interface:AddViewDestroyHandle keyName already exist" .. tostring(keyName))
    return
  end
  print(bWriteLog and "logic_gamelet_interface:AddViewDestroyHandle keyName:" .. tostring(keyName))
  local common = require("client.slua_ui_framework.common")
  local args = table.pack(...)
  
  local function handle(...)
    return common.CallCombinationArgs(handleFunc, args, ...)
  end
  
  self.ViewDestroyHandleMap[keyName] = handle
end

function logic_gamelet_interface:RemoveViewDestroyHandle(keyName)
  if self.ViewDestroyHandleMap[keyName] ~= nil then
    print(bWriteLog and "logic_gamelet_interface:RemoveViewCreatedHandle keyName:" .. tostring(keyName))
    self.ViewDestroyHandleMap[keyName] = nil
  end
end

function logic_gamelet_interface:SendMessageToApp(jsonStr, appId)
  log(bWriteLog and string.format("logic_gamelet_interface:SendMessageToApp: %s", jsonStr))
  if self.gamelet == nil then
    return
  end
  if not appId or appId == "" or appId == "nil" then
    log_error_format("logic_gamelet_interface:SendMessageToApp appId is nil, json is %s", jsonStr)
    return
  end
  self.gamelet:SendMessageToApp(appId, jsonStr)
end

function logic_gamelet_interface:RefreshUserdata(user_data)
  log(bWriteLog and "logic_gamelet_interface:RefreshUserdata")
  log_tree(bWriteLog and "logic_gamelet_interface:RefreshUserdata user_data", user_data)
  if self.gamelet == nil then
    return
  end
  self.gamelet:RefreshUserdata(user_data)
end

function logic_gamelet_interface:SetScriptExternalLoadDir(external_load_dir)
  log(bWriteLog and "logic_gamelet_interface:SetScriptExternalLoadDir")
  if self.gamelet == nil then
    return
  end
  self.gamelet:SetScriptExternalLoadDir(external_load_dir)
end

function logic_gamelet_interface:CloseApp()
  log(bWriteLog and "logic_gamelet_interface:CloseApp")
  if self.gamelet == nil then
    return
  end
  if self.OpenedAppId ~= nil and #self.OpenedAppId > 0 then
    self.gamelet:CloseApp(self.OpenedAppId)
    self.OpenedAppId = ""
  end
end

function logic_gamelet_interface:Close()
  log(bWriteLog and "logic_gamelet_interface:Close")
  if self.gamelet == nil then
    log(bWriteLog and "logic_gamelet_interface:Close. gamelet is nil")
    return
  end
  self.gamelet_apps_info = {}
  self.bOpenGamelet = false
  self.gamelet:Close()
  local HostedProtoBridge = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.HostedProtoBridge)
  local HostedConst = require("client.slua.logic.HostedProtoBridge.HostedConst")
  HostedProtoBridge:ClearStaticState(HostedConst.HostedType.Gamelet)
end

function logic_gamelet_interface:UnInitializeSDK()
  log(bWriteLog and "logic_gamelet_interface:UnInitializeSDK")
  if self.gamelet == nil then
    return
  end
  local GameletOnDemand = require("client.slua.logic.gamelet.GameletOnDemand")
  GameletOnDemand:Reset()
  self.gamelet:Deinitialize()
end

function logic_gamelet_interface:get_current_user_data()
  local DevicePlatformNameMacros = require("client.slua.config.ClientMacros.DevicePlatformNameMacros")
  local PandoraSystem = require("client.slua.logic.Pandora.pandora_system")
  local webModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.webModule)
  local itop_app_id = tostring(Client.GetITopGameId())
  local platfom_id = 1
  local strPlatform = Client.GetDevicePlatformName()
  if strPlatform == DevicePlatformNameMacros.IOS then
    platfom_id = 0
  elseif strPlatform == DevicePlatformNameMacros.Windows then
    platfom_id = 2
  end
  local HDmpve_channel_id = Client.GetLoginChannel(NetInterface)
  local account_type = PANDORA_PLAYFORM[HDmpve_channel_id]
  local area = tostring(PandoraSystem.GetAreaId())
  local openid, atk = self:get_author_data()
  local gameVersion = PandoraSystem.GetMainAppVersion()
  local language = webModule:GetCurrentLanguage()
  local LanguageMacros = require("client.slua.config.ClientMacros.LanguageMacros")
  if language == LanguageMacros.MY then
    language = LanguageMacros.EN
  end
  local country = FuncUtil.GetAccountRegionForBP()
  local UnbindMgr = require("client.slua.logic.unbind_account.logic_unbind")
  local imsdk_channel_id = UnbindMgr.GetChannelIdByLoginPlatform(HDmpve_channel_id)
  local intlsdk_param = string.format("channelid=%d&os=%d", imsdk_channel_id, platfom_id)
  local ticket = Client.GetWebViewTicket(NetInterface)
  local ZoneSystem = require("client.slua.logic.teamup.logic_zone")
  local sGameArea = ZoneSystem.GetChooseZone()
  local Enum_GameletExtCgiAttr1 = gamelet_define.Enum_GameletExtCgiAttr1
  local sAttr1 = Enum_GameletExtCgiAttr1.NormalPack
  if PublishRegionMacros.IsFITVersion() then
    sAttr1 = Enum_GameletExtCgiAttr1.SmallPack
  end
  local sExtCgiAttrsTab = {attr1 = sAttr1}
  local sExtCgiAttrsJson = json.encode(sExtCgiAttrsTab)
  local publishRegion = PublishRegionMacros.GetPackageType()
  if PublishRegionMacros.IsJapanOrKorea() then
    publishRegion = PublishRegionMacros.GetOperationRegion()
  end
  local GameletOnDemand = require("client.slua.logic.gamelet.GameletOnDemand")
  local Enum_OnDemandDownload_Enabled = gamelet_define.Enum_OnDemandDownload_Enabled
  local sEnableOnDemandDownload = GameletOnDemand.ShouldClientOptIn() and Enum_OnDemandDownload_Enabled.Enabled or Enum_OnDemandDownload_Enabled.Disabled
  local user_data = {
    sOpenId = openid,
    sAppId = itop_app_id,
    sRoleId = tostring(DataMgr.roleData.uid),
    sPlatID = tostring(platfom_id),
    sServerPlatID = tostring(platfom_id),
    sAccountType = account_type,
    sArea = area,
    sPartition = "1",
    sAccessToken = atk,
    sGameVer = gameVersion,
    sPayToken = "",
    sRegion = country,
    sLanguage = language,
    sChannelID = "",
    sLoginChannel = "",
    sIntlSdkParam = intlsdk_param,
    sServiceType = "pubgm",
    sExtend = "",
    sExtCgiAttrs = sExtCgiAttrsJson,
    publishRegion = publishRegion,
    sTicket = ticket,
    sRoleName = DataMgr.roleData.nickName,
    sHeadUrl = DataMgr.roleData.headIconUrl,
    sIp = Client.GetIpAddr(),
    sNetType = Client.GetNetWorkType(),
    sGameArea = sGameArea,
    nNonage = self.nonage,
    sCurrencyType = publishRegion,
    sEnableOnDemandDownload = sEnableOnDemandDownload
  }
  log_tree("logic_gamelet_interface:get_current_user_data return: ", user_data)
  return user_data
end

function logic_gamelet_interface:get_app_id(AppType)
  local strRegion = PublishRegionMacros.GetPackageType()
  local app_id = gamelet_config.AppIds[AppType][strRegion] or "0"
  log(bWriteLog and string.format("logic_gamelet_interface:get_app_id(%s) return: %s", AppType, app_id))
  return app_id
end

function logic_gamelet_interface:GetAppIdByShowEntrance(appType)
  if not appType then
    return nil
  end
  local appType = string.lower(appType)
  if not self.AppType2AppId[appType] then
    return nil
  end
  return self.AppType2AppId[appType]
end

function logic_gamelet_interface:get_app_type(appId)
  if not appId then
    return
  end
  local strRegion = PublishRegionMacros.GetPackageType()
  for appType, regionInfo in pairs(gamelet_config.AppIds) do
    local Id = regionInfo[strRegion]
    if appId == Id then
      return appType
    end
  end
end

function logic_gamelet_interface:get_author_data()
  local token = Client.GetToken(NetInterface) or ""
  if Client.IsEditor() then
    token = "mock-token-for-editor"
  end
  return tostring(DataMgr.roleData.openID or ""), token
end

function logic_gamelet_interface:get_env()
  local gamelet_env = Enum_GameletEnv.Product
  if PublishRegionMacros.IsCEOperationRegion() then
    gamelet_env = Enum_GameletEnv.Tyf_Product
    if Client.GetIMSDKEnv() == Enum_IMSDKEnv.Test or _G.IsEditor then
      gamelet_env = Enum_GameletEnv.Tyf_Test
    end
  elseif Client.GetIMSDKEnv() == Enum_IMSDKEnv.Test or _G.IsEditor then
    gamelet_env = Enum_GameletEnv.Test
  end
  return gamelet_env
end

function logic_gamelet_interface:SetGameletReady(appId, appType, bReady)
  local key = tostring(appId)
  appType = string.lower(appType)
  log_format("logic_gamelet_interface:SetGameletReady. appId=%s, appType=%s, bReady=%s ", tostring(appId), tostring(appType), tostring(bReady))
  self.AppType2AppId[appType] = appId
  self.gamelet_apps_info[key] = {ready = bReady, appType = appType}
end

function logic_gamelet_interface:IsInterfaceReady(app_id)
  if not app_id or not self.gamelet_apps_info[tostring(app_id)] then
    return false
  end
  return self.gamelet_apps_info[tostring(app_id)].ready == true
end

function logic_gamelet_interface:GetAppType(appId)
  if not appId or not self.gamelet_apps_info[tostring(appId)] then
    return nil
  end
  local info = self.gamelet_apps_info[tostring(appId)]
  return info.appType
end

function logic_gamelet_interface:SetTickIntervalSec(TickIntervalSec)
  log(bWriteLog and "logic_gamelet_interface:SetTickIntervalSec: " .. tostring(TickIntervalSec))
  if self.gamelet == nil then
    return
  end
  self.gamelet:SetTickIntervalSec(TickIntervalSec)
  if TickIntervalSec == 0 then
    local msg = {
      cmd = 100001,
      args = {ticks = 5}
    }
    self.gamelet:SendMessageToSdk(json.encode(msg))
  end
end

function logic_gamelet_interface:SetupPixLibrary(onDone)
  log(bWriteLog and "logic_gamelet_interface:SetupPixLibrary:")
  local finished = false
  
  local function finish()
    if finished then
      return
    end
    finished = true
    if onDone then
      onDone()
    end
  end
  
  if PublishRegionMacros.IsBlueholeOperationRegion() then
    finish()
    return
  end
  local BusinessHelper = import("BusinessHelper")
  local isAppFromStore = BusinessHelper.IsAppFromStore()
  local DevicePlatformNameMacros = require("client.slua.config.ClientMacros.DevicePlatformNameMacros")
  if Client.GetDevicePlatformName() == DevicePlatformNameMacros.Android and isAppFromStore then
    if Client.GetAndroidSOVersion() == 32 then
      log_format("logic_gamelet_interface:SetupPixLibrary: 32-bit process, no %s so in obb, skip side-load", tostring(self.SOS_ABI))
      finish()
      return
    end
    if self.bSideLoadSOChecked then
      self:ApplyPixLibraryPath(self:GetSoLoadDir())
      finish()
    else
      self.bSideLoadSOChecked = true
      self:EnsureSideLoadSOReady(function(soDir)
        self:ApplyPixLibraryPath(soDir)
        finish()
      end)
    end
  else
    finish()
  end
end

function logic_gamelet_interface:ApplyPixLibraryPath(so_path)
  if not so_path or so_path == "" then
    log_warning("logic_gamelet_interface:ApplyPixLibraryPath: empty so_path, skip")
    return
  end
  local basePath = so_path:gsub("\\", "/"):gsub("/+$", "")
  log_format("logic_gamelet_interface:ApplyPixLibraryPath: so_path=%s", basePath)
  local PandoraVideoBP = import("BP_PixVideoLibrary")
  if PandoraVideoBP then
    PandoraVideoBP.SetPixVideoLibraryPath(basePath)
  end
  local PixUIVideoBP = import("PixUIBPLibrary")
  if PixUIVideoBP then
    if PixUIVideoBP.PixUI_SetAndroidDyLibSearchEnvPath then
      PixUIVideoBP.PixUI_SetAndroidDyLibSearchEnvPath(basePath .. "/")
    else
      PixUIVideoBP.PixUI_SetDynamicLibraryPath(basePath .. "/")
    end
    PixUIVideoBP.PixUI_AddDynamicLibraryPath(basePath .. "/")
  end
end

logic_gamelet_interface.SIDE_LOAD_SO_NAMES = {
  "libPixFFmpeg.so",
  "libPixUI_PXPlugin.so",
  "libPixVideo.so",
  "libPixVideoCore.so",
  "libpixuiCurl.so"
}
logic_gamelet_interface.SIDE_LOAD_EXTRACT_TIMEOUT = 300
logic_gamelet_interface.SOS_EXTRACT_YIELD_STEP = 1200
logic_gamelet_interface.SOS_YIELD_STEP_MIN = 800
logic_gamelet_interface.SOS_YIELD_STEP_MAX = 6000
logic_gamelet_interface.SOS_FRAME_OVER_RATIO = 1.1
logic_gamelet_interface.SOS_FRAME_OVER_SLACK_MS = 1.5
logic_gamelet_interface.SOS_FRAME_SPIKE_MS = 300
logic_gamelet_interface.SOS_YIELD_DOWN_RATIO = 0.7
logic_gamelet_interface.SOS_YIELD_UP_RATIO = 1.08
logic_gamelet_interface.SOS_YIELD_CEIL_RATIO = 0.9
logic_gamelet_interface.SOS_YIELD_CEIL_RELAX_FRAMES = 90
logic_gamelet_interface.SOS_YIELD_CEIL_RELAX_RATIO = 1.15

local function NormalizeDir(dir)
  if not dir or dir == "" then
    return nil
  end
  dir = dir:gsub("\\", "/")
  if not dir:match("/$") then
    dir = dir .. "/"
  end
  return dir
end

local function AreSOsPresent(dir, names)
  dir = NormalizeDir(dir)
  if not dir then
    return false
  end
  local zip_extractor = require("client.slua.logic.gamelet.zip_extractor")
  for _, name in ipairs(names) do
    local physPath = zip_extractor.ToPhysicalPath(dir .. name)
    if not physPath then
      return false
    end
    local f = io.open(physPath, "rb")
    if not f then
      return false
    end
    f:close()
  end
  return true
end

logic_gamelet_interface.SOS_ABI = "arm64-v8a"
local SO_DIR_PROBE_NAME = ".px_probe.tmp"

local function IsDirWritable(physDir)
  local probe = physDir .. SO_DIR_PROBE_NAME
  local f = io.open(probe, "wb")
  if not f then
    return false
  end
  f:close()
  os.remove(probe)
  return true
end

local function GetVersionCode()
  if not Client.GetNativeVersion then
    return nil
  end
  local ok, ver = pcall(Client.GetNativeVersion)
  if not (ok and ver) or ver == "" then
    return nil
  end
  return ver:match("(%d+)%s*$")
end

function logic_gamelet_interface:GetSoLoadDir()
  if self.CachedSoLoadDir then
    return self.CachedSoLoadDir
  end
  local filesDir = Client.GetInternalFilesDir()
  if not filesDir or filesDir == "" then
    return nil
  end
  filesDir = NormalizeDir(filesDir)
  local code = GetVersionCode()
  if code then
    local obbLibDir = filesDir .. "obblib/" .. code .. "/" .. self.SOS_ABI .. "/"
    if IsDirWritable(obbLibDir) then
      log_format("logic_gamelet_interface:GetSoLoadDir: using obblib dir %s", obbLibDir)
      self.CachedSoLoadDir = obbLibDir
      return obbLibDir
    end
    log_warning(string.format("logic_gamelet_interface:GetSoLoadDir: %s not writable (dir missing? pure Lua cannot mkdir), fallback to %s", obbLibDir, filesDir))
  else
    log_warning(string.format("logic_gamelet_interface:GetSoLoadDir: cannot resolve versionCode, fallback to %s", filesDir))
  end
  self.CachedSoLoadDir = filesDir
  return filesDir
end

function logic_gamelet_interface:EnsureSideLoadSOReady(onReady)
  local finished = false
  local timeoutTimer
  
  local function finish(soDir)
    if finished then
      return
    end
    finished = true
    if timeoutTimer then
      local time_ticker = require("common.time_ticker")
      time_ticker.RemoveTimer(timeoutTimer)
      timeoutTimer = nil
    end
    if onReady then
      onReady(soDir)
    end
  end
  
  local destDir = self:GetSoLoadDir()
  if not destDir then
    log_warning("logic_gamelet_interface:EnsureSideLoadSOReady: GetInternalFilesDir empty, abort")
    finish(nil)
    return
  end
  self:CleanupLegacySosFiles(destDir)
  if AreSOsPresent(destDir, self.SIDE_LOAD_SO_NAMES) then
    log_format("logic_gamelet_interface:EnsureSideLoadSOReady: already present: %s", destDir)
    self:CleanupSosTemp(Client.ProjectSavedDir() .. self.SOS_ZIP_REL_PATH, destDir)
    finish(destDir)
    return
  end
  log_format("logic_gamelet_interface:EnsureSideLoadSOReady: need unzip from obb -> %s", destDir)
  local time_ticker = require("common.time_ticker")
  timeoutTimer = time_ticker.AddTimerOnce(self.SIDE_LOAD_EXTRACT_TIMEOUT, function()
    timeoutTimer = nil
    if finished then
      return
    end
    local present = AreSOsPresent(destDir, self.SIDE_LOAD_SO_NAMES)
    log_error(string.format("logic_gamelet_interface:EnsureSideLoadSOReady: extract timeout after %ds, present=%s, release gamelet init anyway", self.SIDE_LOAD_EXTRACT_TIMEOUT, tostring(present)))
    if present then
      finish(destDir)
    else
      finish(nil)
    end
  end)
  self:ExtractSosZipFromObb(function()
    if AreSOsPresent(destDir, self.SIDE_LOAD_SO_NAMES) then
      finish(destDir)
    else
      log_warning(string.format("logic_gamelet_interface:EnsureSideLoadSOReady: so still missing in %s after extract, skip setting library path", destDir))
      finish(nil)
    end
  end)
end

logic_gamelet_interface.SOS_ZIP_REL_PATH = "Temp/sos.zip"

function logic_gamelet_interface:CleanupLegacySosFiles(currentDestDir)
  local zip_extractor = require("client.slua.logic.gamelet.zip_extractor")
  local savedDir = Client.ProjectSavedDir()
  local legacyZip = zip_extractor.ToPhysicalPath(savedDir .. "sos.zip")
  if legacyZip and os.remove(legacyZip) then
    log_format("logic_gamelet_interface:CleanupLegacySosFiles: removed legacy zip %s", legacyZip)
  end
  local legacyStageDir
  for _, name in ipairs(self.SIDE_LOAD_SO_NAMES) do
    local physPath = zip_extractor.ToPhysicalPath(savedDir .. "sos/" .. name)
    if physPath then
      legacyStageDir = legacyStageDir or physPath:match("^(.*)/[^/]+$")
      if os.remove(physPath) then
        log_format("logic_gamelet_interface:CleanupLegacySosFiles: removed %s", physPath)
      end
      zip_extractor.RemoveTempFor(physPath)
    end
  end
  if legacyStageDir and os.remove(legacyStageDir) then
    log_format("logic_gamelet_interface:CleanupLegacySosFiles: removed legacy stage dir %s", legacyStageDir)
  end
  local filesDir = NormalizeDir(Client.GetInternalFilesDir())
  if filesDir and NormalizeDir(currentDestDir) ~= filesDir then
    for _, name in ipairs(self.SIDE_LOAD_SO_NAMES) do
      local stale = filesDir .. name
      if os.remove(stale) then
        log_format("logic_gamelet_interface:CleanupLegacySosFiles: removed stale so %s", stale)
      end
      zip_extractor.RemoveTempFor(stale)
    end
  end
end

function logic_gamelet_interface:CleanupSosTemp(zipPath, destDir)
  local zip_extractor = require("client.slua.logic.gamelet.zip_extractor")
  local physZip = zip_extractor.ToPhysicalPath(zipPath)
  if physZip and os.remove(physZip) then
    log_format("logic_gamelet_interface:CleanupSosTemp: removed zip %s", physZip)
  end
  destDir = NormalizeDir(destDir)
  if destDir then
    for _, name in ipairs(self.SIDE_LOAD_SO_NAMES) do
      local physPath = zip_extractor.ToPhysicalPath(destDir .. name)
      if physPath then
        zip_extractor.RemoveTempFor(physPath)
      end
    end
  end
end

function logic_gamelet_interface:ResetSosYieldState()
  self.SosFrameBaseMs = nil
  self.SosYieldCeil = nil
  self.SosSteadyFrames = 0
  self.SosYieldLogged = nil
end

function logic_gamelet_interface:AdaptSosYieldStep(stepRef, deltaTime)
  if not stepRef or type(deltaTime) ~= "number" or deltaTime <= 0 then
    return
  end
  local frameMs = deltaTime * 1000
  if frameMs > self.SOS_FRAME_SPIKE_MS then
    return
  end
  local base = self.SosFrameBaseMs
  if not base then
    self.SosFrameBaseMs = frameMs
    return
  end
  local cur = stepRef.value or self.SOS_EXTRACT_YIELD_STEP
  local nextStep
  if frameMs > base * self.SOS_FRAME_OVER_RATIO + self.SOS_FRAME_OVER_SLACK_MS then
    self.SosYieldCeil = cur
    self.SosSteadyFrames = 0
    nextStep = cur * self.SOS_YIELD_DOWN_RATIO
  else
    if frameMs < base then
      self.SosFrameBaseMs = base * 0.7 + frameMs * 0.3
    end
    local steady = (self.SosSteadyFrames or 0) + 1
    self.SosSteadyFrames = steady
    if self.SosYieldCeil and steady >= self.SOS_YIELD_CEIL_RELAX_FRAMES then
      self.SosYieldCeil = self.SosYieldCeil * self.SOS_YIELD_CEIL_RELAX_RATIO
      self.SosSteadyFrames = 0
    end
    nextStep = cur * self.SOS_YIELD_UP_RATIO
    local ceil = self.SosYieldCeil
    local limit = ceil and ceil * self.SOS_YIELD_CEIL_RATIO or self.SOS_YIELD_STEP_MAX
    if nextStep > limit then
      nextStep = limit
    end
  end
  nextStep = math.floor(nextStep + 0.5)
  if nextStep < self.SOS_YIELD_STEP_MIN then
    nextStep = self.SOS_YIELD_STEP_MIN
  elseif nextStep > self.SOS_YIELD_STEP_MAX then
    nextStep = self.SOS_YIELD_STEP_MAX
  end
  if nextStep == cur then
    return
  end
  stepRef.value = nextStep
  local logged = self.SosYieldLogged
  if not logged or nextStep >= logged * 1.5 or nextStep <= logged * 0.7 then
    self.SosYieldLogged = nextStep
    log_format("logic_gamelet_interface:AdaptSosYieldStep: yieldStep %d -> %d (frame=%.1fms, base=%.1fms, ceil=%s)", cur, nextStep, frameMs, self.SosFrameBaseMs, self.SosYieldCeil and string.format("%d", self.SosYieldCeil) or "none")
  end
end

function logic_gamelet_interface:ExtractSosZipFromObb(onDone)
  local finished = false
  
  local function finish()
    if finished then
      return
    end
    finished = true
    if onDone then
      onDone()
    end
  end
  
  local destDir = self:GetSoLoadDir()
  if not destDir then
    log_warning("logic_gamelet_interface:ExtractSosZipFromObb: GetInternalFilesDir empty, abort")
    finish()
    return
  end
  local srcPath = Client.ProjectContentDir() .. "libs/arm64-v8a/sos.zip"
  local zipPath = Client.ProjectSavedDir() .. self.SOS_ZIP_REL_PATH
  local bCopied = Client.CopyFile(srcPath, zipPath)
  log_format("logic_gamelet_interface:ExtractSosZipFromObb: copy from obb, src=%s, dest=%s, result=%s", tostring(srcPath), tostring(zipPath), tostring(bCopied))
  if not bCopied then
    finish()
    return
  end
  local zip_extractor = require("client.slua.logic.gamelet.zip_extractor")
  local entries, listErr = zip_extractor.List(zipPath)
  if not entries then
    log_format("logic_gamelet_interface:ExtractSosZipFromObb: list failed, err=%s", tostring(listErr))
    self:CleanupSosTemp(zipPath, destDir)
    finish()
    return
  end
  for _, entry in ipairs(entries) do
    log_format("logic_gamelet_interface:ExtractSosZipFromObb: entry=%s, method=%d, size=%d -> %d", tostring(entry.name), entry.method, entry.compSize, entry.uncompSize)
  end
  log_format("logic_gamelet_interface:ExtractSosZipFromObb: extracting %d so(s) to %s", #self.SIDE_LOAD_SO_NAMES, tostring(destDir))
  local wantCount = #self.SIDE_LOAD_SO_NAMES
  self:ResetSosYieldState()
  local step, stepRef = zip_extractor.ExtractAllAsync(zipPath, destDir, {
    flatten = true,
    skipExisting = true,
    yieldStep = self.SOS_EXTRACT_YIELD_STEP,
    include = self.SIDE_LOAD_SO_NAMES
  }, function(okCount, totalCount, err)
    log_format("logic_gamelet_interface:ExtractSosZipFromObb: finished, ok=%s/%s, destDir=%s, err=%s", tostring(okCount), tostring(totalCount), tostring(destDir), tostring(err))
    if okCount ~= wantCount then
      log_warning(string.format("logic_gamelet_interface:ExtractSosZipFromObb: expected %d files but got %d, check SIDE_LOAD_SO_NAMES against the entry= logs above", wantCount, okCount))
    end
    self:CleanupSosTemp(zipPath, destDir)
    finish()
  end)
  if type(step) ~= "function" then
    log_error("logic_gamelet_interface:ExtractSosZipFromObb: ExtractAllAsync returned no step, abort")
    self:CleanupSosTemp(zipPath, destDir)
    finish()
    return
  end
  local time_ticker = require("common.time_ticker")
  self.SosZipExtractTimer = time_ticker.AddTimerLoop(0, function(deltaTime)
    self:AdaptSosYieldStep(stepRef, deltaTime)
    if step() and self.SosZipExtractTimer then
      time_ticker.RemoveTimer(self.SosZipExtractTimer)
      self.SosZipExtractTimer = nil
    end
  end, -1, time_ticker.NEXT_FRAME)
  if not self.SosZipExtractTimer then
    log_error("logic_gamelet_interface:ExtractSosZipFromObb: cannot create ticker, abort")
    self:CleanupSosTemp(zipPath, destDir)
    finish()
  end
end

function logic_gamelet_interface:SetUserDataNonage(is_nonage)
  if is_nonage ~= self.nonage then
    self.nonage = is_nonage
    local user_data = self:get_current_user_data()
    if not user_data or type(user_data) == "boolean" then
      log_format(bWriteLog and "logic_gamelet_interface:SetUserDataNonage: user_data is nil")
      return
    end
    self:RefreshUserdata(user_data)
  end
end

function logic_gamelet_interface:InitializeGameletLog()
  local enable = false
  local IsDev = Client and Client.IsDevelopment()
  enable = enable or IsDev
  local GainCrashLogInfoBackground = HDmpveRemote.HDmpveRemoteConfigGetInt("GainCrashLogInfoBackground", 0)
  enable = enable or GainCrashLogInfoBackground ~= 0
  self:EnableLog(enable)
end

function logic_gamelet_interface:EnableLog(enable)
  print(string.format("logic_gamelet_interface:EnableLog, enable=%s", tostring(enable)))
  if self.gamelet then
    self.gamelet:EnableLog(enable)
  end
  if self.gamelet_setting then
    self.gamelet_setting.ForbiddenSyncServerLogConf = not enable
  end
end

local GameletModule = {
  [BP_ENUM_MODULE_HOSTED_WOW_BBS] = true,
  [BP_ENUM_MODULE_HOSTED_CS] = true,
  [BP_ENUM_MODULE_HOSTED_SAFETY_CENTER] = true,
  [BP_ENUM_MODULE_HOSTED_WIKI] = true,
  [BP_ENUM_MODULE_HOSTED_GAMELET_ACT] = true,
  [BP_ENUM_MODULE_HOSTED_CREATOR_BASE] = true,
  [BP_ENUM_MODULE_HOSTED_NATIONNALESPORTS_OFFICIAL] = true,
  [BP_ENUM_MODULE_HOSTED_NATIONNOLESPORTS_ENTERTAINMENT] = true
}

function logic_gamelet_interface:IsGameletModule(moduleId)
  return GameletModule[tonumber(moduleId)] == true
end

local class = require("class")
local CModuleBase = require("client.module_framework.ModuleBase")
local Clogic_gamelet_interface = class(CModuleBase, nil, logic_gamelet_interface)
return Clogic_gamelet_interface
