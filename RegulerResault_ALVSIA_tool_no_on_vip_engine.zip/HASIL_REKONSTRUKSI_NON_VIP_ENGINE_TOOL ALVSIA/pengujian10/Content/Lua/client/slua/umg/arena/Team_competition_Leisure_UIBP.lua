local Team_competition_Leisure_UIBP = {
  slotID = 0,
  featureType = 1,
  itemData = {},
  itemIndex = 0,
  itemID = 0,
  equipItemID = 0,
  canUnEquip = false,
  curItemWidget = nil,
  updateItemTimeLimitTimer = nil,
  InventoryDisplay = 1
}
local ArenaWeaponSystem = require("client.slua.logic.arena.logic_arena_weapon")
local ArenaCasualShopSystem = require("client.slua.logic.arena.logic_arena_casual_shop")
local PrepareSchemeSystem = require("client.slua.logic.prepareScheme.logic_prepare_scheme")
local equipBG = "/Game/UMG/Texture_200/Atlas/Common_New_Atlas/Frames/Common_Btn_Huangse_png.Common_Btn_Huangse_png"
local unEquipBG = "/Game/UMG/Texture_200/Atlas/Common_New_Atlas/Frames/Common_Btn_Lanse_png.Common_Btn_Lanse_png"
local gotoGetBG = "/Game/UMG/Texture_200/Atlas/Common_New_Atlas/Frames/Common_Btn_Lanse_png.Common_Btn_Lanse_png"
local canNotGetBG = "/Game/UMG/Texture_200/Atlas/Common_New_Atlas/Frames/Common_Btn_Huangse_png.Common_Btn_Huangse_png"
local equipID = 6299
local unEquipID = 8438
local gotoGetID = 6341
local canNotGetID = 6430
local buttonMainType = {
  UnEquip = 1,
  GoToGet = 2,
  Equip = 3,
  CanNotGet = 4
}

function Team_competition_Leisure_UIBP:ctor(_, slotID, featureType)
  self.slotID = slotID
  self.featureType = featureType
  if slotID then
    local slotInfo = PrepareSchemeSystem.GetFeatureInfoById(slotID)
    if slotInfo then
      self.itemID = slotInfo.item_id or 0
      self.equipItemID = slotInfo.item_id or 0
      self.canUnEquip = slotInfo.canUnEquip or false
    end
  end
  self.buttonMainType = buttonMainType.CanNotGet
  log(bWriteLog and string.format("Team_competition_Leisure_UIBP:ctor itemID=%d canUnEquip=%s", self.itemID, tostring(self.canUnEquip)))
end

function Team_competition_Leisure_UIBP:CreateKillInfo()
  if self.KillUI == nil then
    self.KillUI = self:CreateChildWindow(self.UIRoot.KillInfoRoot, UIManager.UI_Config.TDMKillInfo)
    if not self.KillUI then
      log_error("Team_competition_Leisure_UIBP:CreateKillInfo CreateChildWindow failed")
      return
    end
    self.KillUI:SetAutoSize(true)
    self.KillUI:SetAlignment(0.5, 0.5)
    self.KillUI:SetAnchors(0.5, 0.5, 0.5, 0.5)
    self.KillUI:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
end

function Team_competition_Leisure_UIBP:SetKillInfoUI()
  log(bWriteLog and "Team_competition_Leisure_UIBP:SetKillInfoUI")
  if self.KillTipsTimer then
    self:RemoveTimer(self.KillTipsTimer)
  end
  if not self.KillUI then
    return
  end
  if not self.featureType or self.featureType ~= 2 then
    self.KillUI:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    return
  end
  if not self.itemID then
    self.KillUI:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    return
  end
  local tipsData = {
    Type = 0,
    PlayerName = DataMgr.roleData.nickName,
    IconURL = DataMgr.roleData.headIconUrl,
    AvatarBoxId = DataMgr.roleData.cur_avatar_box_id,
    PlayerLevel = DataMgr.roleData.level,
    IsLeft = true,
    KillEffectItemID = self.itemID
  }
  self.KillTipsTimer = self:AddTimerLoop(0.1, function()
    self.KillUI:AddKillInfo(tipsData)
  end, TIMER_INFINITE, 5)
  self.KillUI:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
end

function Team_competition_Leisure_UIBP:OnInitialize()
  self.LoopScrollBox_0 = self:InitScrollBox(self.UIRoot.LoopScrollBox_0)
  local UIUtil = require("client.common.ui_util")
  UIUtil.SetAdaptation(self.UIRoot.root)
  EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_AVATAR_RESET_OPEN)
  ArenaCasualShopSystem.CasualShopVirtualItemReq()
  ArenaCasualShopSystem.EnterScene()
end

function Team_competition_Leisure_UIBP:RegistEvents()
  self:AddOnClickedEventByControl(self.UIRoot.Button_main, self.OnClickButton_main, self)
  self:AddOnClickedEventByControl(self.UIRoot.btn_close, self.OnClickbtn_close, self)
  self.LoopScrollBox_0:AddItemWidgetChildEvent("Button_Item", "OnClicked", self.OnItemClick, self)
  self.LoopScrollBox_0:SetRefreshItemCallback(self.UpdateItem, self)
  self:AddCommonEvent(EVENTTYPE_SEASON_CONFIG, EVENTID_GET_SHOP_CONFIG, self.OnCasualShopConfigGet, self)
  self:AddCommonEvent(EVENTTYPE_ARENA, EVENTID_ARENA_GET_CASUAL_SHOP_ITEM, self.OnCasualShopItemUpdate, self)
  self:AddCommonEvent(EVENTTYPE_ARENA, EVENTID_ARENA_UNEQUIP_SLOT, self.OnUnEquipSlot, self)
  self:AddCommonEvent(EVENTTYPE_APPLICATION_ACTIVE_STATE, EVENTID_APPLICATION_REACTIVATED_EX, self.OnApplicationReactived, self)
end

function Team_competition_Leisure_UIBP:OnPostInitialize()
  self:CreateKillInfo()
  self:SetWidgetVisible(self.UIRoot.TextBlock_Time, false)
  self:UpdateUI()
end

function Team_competition_Leisure_UIBP:OnClose()
  if self.KillUI then
    self.KillUI:Close()
    self.KillUI = nil
  end
  if self.updateItemTimeLimitTimer then
    self:RemoveTimer(self.updateItemTimeLimitTimer)
    self.updateItemTimeLimitTimer = nil
  end
  self:RemoveAllTimer()
  EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_AVATAR_RESET_CLOSE)
  ArenaCasualShopSystem.ExitScene()
end

function Team_competition_Leisure_UIBP:OnClickbtn_close()
  self:PlayAudio(sound_config.click_v1)
  self:CloseSelf()
end

function Team_competition_Leisure_UIBP:OnClickButton_main()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "Team_competition_Leisure_UIBP:OnClickButton_main", self.buttonMainType)
  if self.buttonMainType == buttonMainType.UnEquip then
    self:UnEquip()
  elseif self.buttonMainType == buttonMainType.GoToGet then
    self:GoToGet()
  elseif self.buttonMainType == buttonMainType.Equip then
    self:Equip()
  elseif self.buttonMainType == buttonMainType.CanNotGet then
    ShowNotice(6430)
  end
end

function Team_competition_Leisure_UIBP:Equip()
  if self.itemID > 0 then
    ArenaWeaponSystem.SendSetFeatureRequest(self.slotID, self.itemID)
    ArenaCasualShopSystem.CheckAndRemoveRedDot(self.itemID)
    self:CloseSelf()
  end
end

function Team_competition_Leisure_UIBP:GoToGet()
  local logic_arena_item = require("client.slua.logic.arena.logic_arena_item")
  logic_arena_item.GotoGetPage(self.itemID)
end

function Team_competition_Leisure_UIBP:UnEquip()
  ArenaWeaponSystem.SendSetFeatureRequest(self.slotID, 0)
  self:CloseSelf()
end

function Team_competition_Leisure_UIBP:OnItemClick(widget, index)
  log(bWriteLog and "Team_competition_Leisure_UIBP:OnItemClick index=" .. tostring(index))
  self:PlayAudio(sound_config.click_v1)
  local data = self.itemData[index]
  if not data then
    return
  end
  if self.curItemWidget then
    self.curItemWidget.Image_Select:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  self.itemIndex = index
  self.itemID = data.itemID
  self.curItemWidget = widget
  local DownloadTexture = require("client.slua_ui_framework.download_texture")
  if DownloadTexture.HasClickDownload(widget.Image_1) then
    DownloadTexture.TriggerClickDownload(widget.Image_1)
  end
  if data.itemID == self.equipItemID then
    widget.Image_Try:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  else
    widget.Image_Try:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  widget.Image_Select:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  widget.Image_Reddot:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  local itemCfg = CDataTable.GetTableData("Item", self.itemID)
  if itemCfg then
    self.UIRoot.TextBlock_2:SetText(itemCfg.ItemName)
  end
  self:UpdateMainButtonStatus(data)
  self:UpdateItemLimitTime()
  self:ShowItem(data.itemID)
  self:SetKillInfoUI()
end

function Team_competition_Leisure_UIBP:UpdateMainButtonStatus(data)
  if data.itemID == self.equipItemID then
    if self.canUnEquip then
      self:SetTexture(self.UIRoot.Image_bt_bg, unEquipBG)
      self.UIRoot.TextBlock_status:SetText(LocUtil.GetLocalizeResStr(unEquipID))
      self.buttonMainType = buttonMainType.UnEquip
    end
  elseif data.itemCount > 0 then
    self:SetTexture(self.UIRoot.Image_bt_bg, equipBG)
    self.UIRoot.TextBlock_status:SetText(LocUtil.GetLocalizeResStr(equipID))
    self.buttonMainType = buttonMainType.Equip
  else
    local logic_arena_item = require("client.slua.logic.arena.logic_arena_item")
    local type = logic_arena_item.WhereCanGetArenaItem(self.itemID)
    if type then
      self:SetTexture(self.UIRoot.Image_bt_bg, gotoGetBG)
      self.UIRoot.TextBlock_status:SetText(LocUtil.GetLocalizeResStr(gotoGetID))
      self.buttonMainType = buttonMainType.GoToGet
    else
      self:SetTexture(self.UIRoot.Image_bt_bg, canNotGetBG)
      self.UIRoot.TextBlock_status:SetText(LocUtil.GetLocalizeResStr(canNotGetID))
      self.buttonMainType = buttonMainType.CanNotGet
    end
  end
end

function Team_competition_Leisure_UIBP:UpdateItemLimitTime()
  local data = self.itemData[self.itemIndex]
  local TimeUtil = require("client.common.time_util")
  local nowTime = TimeUtil.GetServerTimeInSec()
  if data and data.expireTime and nowTime < data.expireTime then
    log(bWriteLog and "Team_competition_Leisure_UIBP:UpdateItemLimitTime data.expireTime=" .. tostring(data.expireTime))
    local remainTimeStr = self:GetExpireTimeStr(data.expireTime)
    self.UIRoot.TextBlock_Time:SetText(remainTimeStr)
    self:SetWidgetVisible(self.UIRoot.TextBlock_Time, true)
  else
    self:SetWidgetVisible(self.UIRoot.TextBlock_Time, false)
  end
end

function Team_competition_Leisure_UIBP:UpdateItem(widget, index)
  log(bWriteLog and "Team_competition_Leisure_UIBP:UpdateItem index=" .. tostring(index))
  if not slua.isValid(self.UIRoot) then
    return
  end
  local data = self.itemData[index]
  local UIUtil = require("client.common.ui_util")
  local iconPath, bHasAddKnownMissing = UIUtil.GetItemSmallIcon(data.itemID, widget.Image_1)
  local params = {bHasAddKnownMissing = bHasAddKnownMissing}
  self:SetTexture(widget.Image_1, iconPath, params)
  if data.itemCount > 0 then
    widget.CanvasPanel_1:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  else
    widget.HorizontalBox_0:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    widget.CanvasPanel_1:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  end
  local bHasRedDot = ArenaCasualShopSystem.IsNewItem(data.itemID)
  log(bWriteLog and string.format("Team_competition_Leisure_UIBP:UpdateItem itemId=%d hasRedDot=%s", data.itemID, tostring(bHasRedDot)))
  if bHasRedDot then
    widget.Image_Reddot:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  else
    widget.Image_Reddot:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  if self.itemID == data.itemID then
    widget.Image_Select:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    self.itemIndex = index
    self.curItemWidget = widget
    self:UpdateMainButtonStatus(data)
    if data.itemID == self.equipItemID then
      local TimeUtil = require("client.common.time_util")
      local bItemExpired = data.expireTime and data.expireTime < TimeUtil.GetServerTimeInSec()
      if data.itemCount == 0 or bItemExpired then
        log(bWriteLog and "Team_competition_Leisure_UIBP:UpdateItem itemID has expired!")
        ArenaWeaponSystem.SendSetFeatureRequest(self.slotID, 0)
        self:CloseSelf()
        return
      end
    end
    local itemCfg = CDataTable.GetTableData("Item", self.itemID)
    if itemCfg then
      self.UIRoot.TextBlock_2:SetText(itemCfg.ItemName)
    end
    self:ShowItem(data.itemID, true)
    self:SetKillInfoUI()
  else
    widget.Image_Select:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  if self.equipItemID == data.itemID then
    widget.Image_Try:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  else
    widget.Image_Try:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  local itemInfo = CDataTable.GetTableData("Item", data.itemID)
  if itemInfo.ValidTimes and itemInfo.ValidTimes ~= 0 then
    widget.TimePanel:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  else
    widget.TimePanel:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
end

function Team_competition_Leisure_UIBP:OnCasualShopConfigGet()
  self:UpdateUI()
end

function Team_competition_Leisure_UIBP:OnCasualShopItemUpdate()
  self:UpdateUI()
end

function Team_competition_Leisure_UIBP:OnUnEquipSlot(_, _, slotID)
  log(bWriteLog and string.format("Team_competition_Leisure_UIBP:OnUnEquipSlot slotID=%d, self.slotID=%d", slotID, self.slotID))
  if slotID ~= self.slotID then
    return
  end
  self.equipItemID = 0
  self:UpdateUI()
end

function Team_competition_Leisure_UIBP:OnApplicationReactived()
  log(bWriteLog and "Team_competition_Leisure_UIBP:OnApplicationReactived")
  self:UpdateUI()
end

function Team_competition_Leisure_UIBP:OnCasualItemExpire()
  log(bWriteLog and "Team_competition_Leisure_UIBP:OnCasualItemExpire")
  ArenaCasualShopSystem.CasualShopVirtualItemReq()
end

function Team_competition_Leisure_UIBP:UpdateUI()
  log(bWriteLog and "Team_competition_Leisure_UIBP:UpdateUI")
  self.UIRoot.Overlay_status:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  self.UIRoot.CanvasPanel_empty:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  self.UIRoot.TextBlock_2:SetText("")
  local logic_arena_item = require("client.slua.logic.arena.logic_arena_item")
  local itemCount = logic_arena_item.GetCasualShopItemList(self.featureType)
  log_tree("Team_competition_Leisure_UIBP:UpdateUI itemCount = ", itemCount)
  local itemList = ArenaCasualShopSystem.GetItemsByType(self.featureType) or {}
  log_tree("Team_competition_Leisure_UIBP:UpdateUI itemList = ", itemList)
  local itemExpireTime = {}
  local nowTime = os.time()
  for _, itemData in ipairs(itemList) do
    if itemData.expireTime then
      if nowTime < itemData.expireTime then
        itemCount[itemData.itemID] = itemData.itemCount or 0
        itemExpireTime[itemData.itemID] = itemData.expireTime
      end
    else
      itemCount[itemData.itemID] = itemData.itemCount or 0
    end
  end
  local ArenaCasualShopItem = CDataTable.GetTable("ArenaCasualShopItem")
  for _, itemCfg in pairs(ArenaCasualShopItem) do
    if itemCfg.InventoryDisplay == self.InventoryDisplay and itemCfg.ItemType == self.featureType then
      local hasContain = itemCount[itemCfg.ID]
      if not hasContain then
        log(bWriteLog and string.format("Team_competition_Leisure_UIBP:UpdateUI InventoryDisplay is 1", itemCfg.ItemID))
        itemCount[itemCfg.ID] = 0
      end
    end
  end
  self:RemoveAllTimer()
  self.itemData = {}
  local nextUpdateTime = -1
  for itemID, count in pairs(itemCount) do
    local expireTime = itemExpireTime[itemID]
    table.insert(self.itemData, {
      itemID = itemID,
      itemCount = count,
      expireTime = expireTime
    })
    if expireTime and nowTime < expireTime then
      if nextUpdateTime < 0 then
        nextUpdateTime = expireTime - nowTime
      else
        nextUpdateTime = math.min(nextUpdateTime, expireTime - nowTime)
      end
      log(bWriteLog and string.format("Team_competition_Leisure_UIBP:UpdateUI item[%d] will expire in %ds", itemID, expireTime - nowTime))
    end
  end
  if 0 < nextUpdateTime then
    log(bWriteLog and string.format("Team_competition_Leisure_UIBP:UpdateUI nextUpdateTime=%ds", nextUpdateTime))
    self:AddTimerOnce(nextUpdateTime, function()
      self:OnCasualItemExpire()
    end)
  end
  
  local function hasItem(data)
    if data.itemCount == 0 then
      return false
    end
    if data.expireTime and data.expireTime < nowTime then
      return false
    end
    return true
  end
  
  table.sort(self.itemData, function(a, b)
    if self.equipItemID == a.itemID then
      return true
    elseif self.equipItemID == b.itemID then
      return false
    end
    local AHasRedDot = ArenaCasualShopSystem.IsNewItem(a.itemID)
    local BHasRedDot = ArenaCasualShopSystem.IsNewItem(b.itemID)
    if AHasRedDot and not BHasRedDot then
      return true
    elseif not AHasRedDot and BHasRedDot then
      return false
    end
    if hasItem(a) and not hasItem(b) then
      return true
    elseif not hasItem(a) and hasItem(b) then
      return false
    end
    return a.itemID > b.itemID
  end)
  if #self.itemData > 0 then
    self.UIRoot.Overlay_status:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    self.UIRoot.CanvasPanel_empty:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    if not self.itemID or self.itemID == 0 then
      self.itemIndex = 1
      self.itemID = self.itemData[1].itemID
    end
  else
    self.UIRoot.Overlay_status:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    self.UIRoot.CanvasPanel_empty:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    self.UIRoot.TextBlock_2:SetText("")
  end
  log_tree("Team_competition_Leisure_UIBP:UpdateUI data=", self.itemData)
  self.LoopScrollBox_0:SetData(self.itemData)
  self:RestartItemExpireTimer()
  local logic_arena_item = require("client.slua.logic.arena.logic_arena_item")
  logic_arena_item.GetArenaAwards()
  logic_arena_item.GetSegmentCasualSeasonAwards()
end

function Team_competition_Leisure_UIBP:ShowItem(itemID, ignoreRedDot)
  log(bWriteLog and string.format("Team_competition_Leisure_UIBP:ShowItem itemID=%d, ignoreRedDot=%s", itemID, tostring(ignoreRedDot)))
  self.UIRoot.Panel_Download:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  
  local function OnDownloaded()
    log(bWriteLog and "Team_competition_Leisure_UIBP:ShowItem OnDownloaded itemID=" .. tostring(itemID))
    if not slua.isValid(self.UIRoot) then
      return
    end
    if itemID ~= self.itemID then
      return
    end
    ArenaCasualShopSystem.ShowItem(itemID)
  end
  
  if not ignoreRedDot then
    ArenaCasualShopSystem.CheckAndRemoveRedDot(itemID)
  end
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  local downloadState = PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, {itemID})
  printf("Team_competition_Leisure_UIBP:ShowItem itemID:%d downloadState:%s", itemID, downloadState)
  if downloadState == PufferConst.ENUM_DownloadState.Done then
    OnDownloaded()
  else
    ArenaCasualShopSystem.HideItem()
    local _tDownloadUICfg = {
      callback = OnDownloaded,
      hideMask = true,
      showSize = true,
      isInCenter = true,
      size = 60,
      textPos = FVector2D(0, 18)
    }
    local common_download_handler = require("client.slua.common.common_download_handler")
    common_download_handler.CreateDownloadUIReturnUIBase(PufferConst.ENUM_DownloadType.ODPAK, {itemID}, self, self.UIRoot.Panel_Download, _tDownloadUICfg)
    self.UIRoot.Panel_Download:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  end
end

function Team_competition_Leisure_UIBP:RestartItemExpireTimer()
  if self.updateItemTimeLimitTimer then
    self:RemoveTimer(self.updateItemTimeLimitTimer)
    self.updateItemTimeLimitTimer = nil
  end
  self.updateItemTimeLimitTimer = self:AddTimerLoop(0.0, function()
    if slua.isValid(self.UIRoot) then
      self:UpdateItemLimitTime()
    else
      self:RemoveTimer(self.updateItemTimeLimitTimer)
      self.updateItemTimeLimitTimer = nil
    end
  end, TIMER_INFINITE, 1.0)
end

function Team_competition_Leisure_UIBP:GetExpireTimeStr(expireTime)
  local TimeUtil = require("client.common.time_util")
  local deltaTime = expireTime - TimeUtil.GetServerTimeInSec()
  if deltaTime <= 0 then
    return LocUtil.LocalizeResFormat(9910111)
  end
  local days = math.floor(deltaTime / 86400)
  local hours = math.fmod(math.floor(deltaTime / 3600), 24)
  local mins = math.fmod(math.floor(deltaTime / 60), 60)
  if 1 <= days then
    return LocUtil.LocalizeResFormat("8783", tostring(days), tostring(hours))
  elseif 1 <= hours then
    return LocUtil.LocalizeResFormat("8784", tostring(hours))
  elseif mins == 0 then
    return LocUtil.LocalizeResFormat("8785", tostring(1))
  else
    return LocUtil.LocalizeResFormat("8785", tostring(mins))
  end
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CTeam_competition_Leisure_UIBP = class(ui_base, nil, Team_competition_Leisure_UIBP)
return CTeam_competition_Leisure_UIBP
