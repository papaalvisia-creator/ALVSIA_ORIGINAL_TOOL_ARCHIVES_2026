local UI_Item_Upgrade = {}
local ESlateVisibility = UEnums.ESlateVisibility
local UIUtil = require("client.common.ui_util")
local TimeUtil = require("client.common.time_util")
local ItemList = {}
local FirstRefreshTab = true
local C_SubTabSelectedBgPath = "/Game/UMG/Texture_200/Atlas/Lobby/Frames/Common_Tab_BG_Border_png.Common_Tab_BG_Border_png"
local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
local item_upgrade_ui_config = require("client.slua.umg.upgrade.item_upgrade_ui_config")
local Logic_DetailUtils = require("client.slua.logic.common.Logic_DetailUtils")

function UI_Item_Upgrade:ctor(ui, itemId, jumpbackArg)
  self.bHadSetMatListType = false
  self.tPageItemList = nil
  self:ProcessDefaultShowItemID(itemId)
  self.curSelectedWeaponType = nil
  self.curSelectedFirearmWeaponID = 0
  self.firearmFilterList = nil
  self.ComboBox_Firearm = nil
  self.FormIndex = 0
  self.ItemUpgradeTabCountMap = nil
  self.ClickDownloadItemID = nil
  self.isOnlyShowGot = false
  self.avatarInit = false
  self.isShowUpgradeEffect = false
  self.uObjCountDownTimer = nil
  self.CurSelectWeaponID = -1
  self.CurSelectWeaponData = nil
  self.EffectComponent = require("client.slua.umg.upgrade.UpgradeEffectComponent")(self)
  self.MaterialComp = nil
  self.NeedPlayRefreshShapeEffectAnim = false
  self.EffectList = {}
  self.MaterialFragmentComposeList = {}
  self.AutoComposeAndUpgrade = false
  self.bShowFragmentTip = true
  self.ItemUpgradeMgr = nil
  self.PendantWeaponRotation = nil
  self.FormData = {}
  self.curOpenTabType = nil
  self.curSelectSubIndex = 1
  self.bWeaponListInited = false
  self.reinitPreserveItemID = nil
  self.curKillFeatureType = nil
  self.KillCounterItem = nil
  self.AudioItem = nil
  self.bNotPlayEffectPanelAnim = false
  if jumpbackArg and (not itemId or itemId < 0) then
    self.jumpSubIndex = jumpbackArg.subTabIndex
    self.jumpTabIndex = jumpbackArg.tabIndex
    self.jumpFeatureId = jumpbackArg.jumpFeatureId
  end
  self.bJumpFromKillCounter = false
  if jumpbackArg and jumpbackArg.bJumpFromKillCounter then
    self.jumpEffectIndex = jumpbackArg.effectIndex
    self.jumpEffectSubIndex = jumpbackArg.SelectedSubIndex
  end
  self.UpgradeEffectIndex = -1
  self.SelectedSubIndex = 1
  self.bIsHideLimitTimeMaterialAct = false
  self.WeaponTimerMap = {}
  self.UpgradeWeaponInstIDReplaceMap = {}
  self._downloadPollTimers = {}
end

function UI_Item_Upgrade:OnInitialize()
  UI_Item_Upgrade.__super.OnInitialize(self)
  local logic_setting_graphics = require("client.slua.logic.setting.logic_setting_graphics")
  logic_setting_graphics.EnterEnhancedLobbyQuality()
  self.FormPanel = self.UIRoot.CanvasPanel_18
  self.FormList = self:InitScrollBox(self.UIRoot.LoopScrollBox_0)
  self.WeaponProgressBox = self.UIRoot.HorizontalBox_Left
  self.ExtendedLoopScrollBox_TabList = self:InitExtendedScrollBox(self.UIRoot.ExtendedLoopScrollBox_0)
  self.SubTabList = self:InitVerticalIconTab(self.UIRoot.Common_Tab_Vertical_LevelOne_Icon_UIBP_23)
  self.ScrollBoxWeapon = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_WeaponItem, "client.slua.umg.upgrade.item_upgrade_gunitem")
  self.ExtendedLoopScrollBox_Effect = self:InitExtendedScrollBox(self.UIRoot.ExtendedLoopScrollBox_1, {
    "client.slua.umg.upgrade.ItemUpgrade_Button_UIBP",
    "client.slua.umg.upgrade.ItemUpgrade_Button_Item_UIBP"
  })
  local EffectHelper = require("GameLua.Mod.Library.GamePlay.Avatar.Component.EffectProc.EffectHelper")
  EffectHelper.SetBlockLobbyUserTriggerFirstAutoApply(true)
  local logic_achievement_float_tip = require("client.slua.logic.achievement.logic_achievement_float_tip")
  logic_achievement_float_tip.BlockPopTip()
  local UIComponentModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule)
  self.KillCounterItem = UIComponentModule:InitWithParentComponent(self, UIComponentModule.Config.Common_KillCounter_Item, self.UIRoot.Common_KillCounter_UIBP)
  self.AudioItem = UIComponentModule:InitWithParentComponent(self, UIComponentModule.Config.ItemUpgrade_Audio_UIBP, self.UIRoot.ItemUpgrade_Audio_UIBP, self)
  self.UIRoot.ItemUpgrade_Audio_UIBP:SetWidgetVisibility(ESlateVisibility.Collapsed)
  self.UIRoot.Text_Explain:SetText("")
  local ItemUpgradeMaterialHelper = require("client.logic.ItemUpgrade.ItemUpgradeMaterialHelper")
  ItemUpgradeMaterialHelper.InitData()
  if not self.vng18IconUI then
    local UIUtil = require("client.common.ui_util")
    self.vng18IconUI = UIUtil.InitChildWindow18Logo(self, "CanvasPanelParent", 1, 0, -300, -20, 100)
  end
end

function UI_Item_Upgrade:OnPostInitialize()
  UI_Item_Upgrade.__super.OnPostInitialize(self)
  local LogicKillCounter = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicKillCounter)
  LogicKillCounter:send_get_accumulation_kill_info_req()
  local logic_weapon_pendant = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_weapon_pendant)
  if not logic_weapon_pendant.bGetEquipData then
    logic_weapon_pendant:GetAllEquipPendant()
  end
  self:CheckDefaultPendantPak()
  self:InitUI()
end

function UI_Item_Upgrade:RegistEvents()
  self:AddCommonEvent(EVENTTYPE_ITEM_UPGRADE, EVENTID_ITEM_UPGRADE_TIME_DATA_RSP, self.OnTimeDataInited, self)
  self:AddCommonEvent(EVENTTYPE_LOBBY, EVENTTYPE_CHECK_BACK_TO_VIEW, self.OnMallSystemClose, self)
  self:AddCommonEvent(EVENTTYPE_ITEM_UPGRADE, EVENTID_ITEM_UPGRADE_HIDE_UI, self.OnShowOrHideUpgradeUI, self)
  self:AddCommonEvent(EVENTTYPE_KEY_DESIGN_POINT, EVENTID_KEY_DESIGN_POINT_CLOSE, self.OnKDPUIClose, self)
  self:AddCommonEvent(EVENTTYPE_ITEM_UPGRADE, EVENTID_ITEM_UPGRADE_GET_REFIT_UNLOCK, self.OnGetRefitInfo, self)
  self:AddCommonEvent(EVENTTYPE_WEAPON_PENDANT, EVENTID_WEAPON_PENDANT_WEAR_UPDATE, self.UpdateWeaponPendantWear, self)
  self:AddCommonEvent(EVENTTYPE_ITEM_UPGRADE, EVENTID_ITEM_UPGRADE_UPGRADE_RSP, self.OnUpgradeRspCallBack, self)
  self:AddCommonEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_ITEM_COMPOSE, self.OnComposeResponse, self)
  self:AddCommonEvent(EVENTTYPE_VEHICLE_DIY, EVENTID_VEHICLE_DIY_DECAL_EXCHANGE, self.OnComposeResponse, self)
  self:AddCommonEvent(EVENTTYPE_LOBBY, EVNETID_ITEM_GET_DONE, self.OnItemGetDone, self)
  self:AddCommonEvent(EVENTTYPE_ITEM_UPGRADE, EVENTID_ITEM_UPGRADE_REFIT_SUCCESS, self.OnRefitRspCallBack, self)
  self:AddCommonEvent(EVENTTYPE_ITEM_UPGRADE, EVENTID_ITEM_UPGRADE_REFIT_UNLOCK_SUCCESS, self.OnReiftUnlockRspCallBack, self)
  self:AddCommonEvent(EVENTTYPE_WEAPON_KILLCOUNTER, EVENTID_WEAPON_KILLCOUNTER_INFO_RSP, self.OnKillCounterUpdate, self)
  self:AddCommonEvent(EVENTTYPE_WEAPON_KILLCOUNTER, EVENTID_WEAPON_KILLCOUNTER_EQUIP_UPDATE, self.OnKillCounterUpdate, self)
  self:AddCommonEvent(EVENTTYPE_PUFFER, EVENTID_CLICK_DOWNLOAD, self.OnItemClickDownload, self)
  self:AddCommonEvent(EVENTTYPE_PUFFER, EVENTID_PUFFER_DOWNLOADFINISH, self.UpdateOnSelectDownloaded, self)
  self:AddCommonEvent(EVENTTYPE_ITEM_UPGRADE, EVENTID_ITEM_UPGRADE_EXPLAIN_TEXT_UPDATED, self.OnUpdateExplainText, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_close, self.OnClickClose, self)
  self:AddOnClickedEventByControl(self.UIRoot.btnAvator1, self.OnClickSwitchModel, self)
  self:AddOnClickedEventByControl(self.UIRoot.btnAvator2, self.OnClickSwitchModel, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Upgrade, self.OnClickUpgrade, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Lock, self.OnClickUpgrade, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Go, self.OnClickGo, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_ShowTips, self.OnClickTips, self)
  self:AddOnClickedEventByControl(self.UIRoot.ButtonMask, self.OnClickCloseMaterialTips, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Skip, self.OnClickSkipMotion, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_KDP, self.OnClickShowDesignPoint, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Refit, self.OnClickButtonRefit, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Use, self.OnClickButtonUse, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_CantUse, self.OnClickButtonCantUse, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_SpecialAction, self.OnClickSpecialAction, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Introduce, self.OnClickButtonIntroduce, self)
  self:AddControlEventByControl(self.UIRoot.Store_Collection_Btn, "OnClickCollectItem", self.OnClickCollectBtn, self)
  self:AddCommonEvent(EVENTTYPE_STORE_DATA, EVENTID_STORE_COLLECT_DATA_UPDATED, self.RefreshCollect, self)
  self:AddCommonEvent(EVENTTYPE_STORE_DATA, EVENTID_STORE_COLLECT, self.RefreshCollect, self)
  self.FormList:AddItemWidgetChildEvent("Button_TitleTab", "OnClicked", self.OnClickFormItem, self)
  self.FormList:SetRefreshItemCallback(self.OnUpdateFormItem, self)
  self.ExtendedLoopScrollBox_TabList:SetRefreshItemCallback(self.OnRefreshTab, self)
  self.ExtendedLoopScrollBox_TabList:AddItemWidgetChildEvent("Button_Tab", "OnClicked", self.OnClickTab, self)
  self.SubTabList:AddOnTabRefreshCallback(self.OnRefreshSubTab, self)
  self.SubTabList:AddOnTabClickedCallback(self.OnClickSubTab, self)
  self.SubTabList:AddOnTabSelectedCallback(self.OnSelectSubTabFromIcon, self)
  self:AddOnClickedEventByControl(self.UIRoot.Btn_ToggleIsOnlyShowGot, self.ToggleIsOnlyShowGot, self)
  self:AddControlEventByControl(self.UIRoot.Common_KillCounter_UIBP.Button_0, "OnClicked", self.OnClickKillCounter, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Get_KillCounter, self.OnClickGetKillCounter, self)
end

function UI_Item_Upgrade:OnShow()
  UI_Item_Upgrade.__super.OnShow(self)
end

function UI_Item_Upgrade:OnHide()
  UI_Item_Upgrade.__super.OnHide(self)
  UIManager.CloseUI(UIManager.UI_Config.item_upgrade_effect)
end

function UI_Item_Upgrade:GetItemUpgradeMgr()
  return ModuleManager.GetModule(ModuleManager.CommonModuleConfig.ItemUpgradeModule)
end

function UI_Item_Upgrade:ProcessDefaultShowItemID(InItemID)
  if InItemID then
    self.defaultShowItemId = tonumber(InItemID)
  end
  if self.defaultShowItemId == nil then
    self.defaultShowItemId = -1
  elseif self:IsJumpRefitMaterial(self.defaultShowItemId) then
    local refit_group_id = self:GetItemUpgradeMgr():GetGroupIDByMaterialID(self.defaultShowItemId)
    self.defaultShowItemId = self:GetItemUpgradeMgr():GetCurItemIDOrFirstItemIDByGroupID(refit_group_id)
  else
    self.defaultShowItemId = self:GetItemUpgradeMgr():GetSameGroupItem(self.defaultShowItemId)
  end
end

function UI_Item_Upgrade:InitUI()
  self:PlayUserWidgetAnimation(self.UIRoot.FadeIn, 0.2, 1, 0, 1)
  self:SetSkipEmoteButtonVisibility(false)
  self:SetLevelUpgradeEffectShow(false)
  self.UIRoot.noDataFound:SetText(LocUtil.GetLocalizeResStr(81010))
  self.UIRoot.TextBlock_own:SetText(LocUtil.GetLocalizeResStr(6483))
  self.UIRoot.TextBlock_RefitButton1:SetText(LocUtil.GetLocalizeResStr(64255))
  self.UIRoot.TextBlock_RefitButton2:SetText(LocUtil.GetLocalizeResStr(64255))
  self.UIRoot.TextBlock_KillCounter:SetText(LocUtil.GetLocalizeResStr(77569))
  self.UIRoot.TextBlock_GetCounter:SetText(LocUtil.GetLocalizeResStr(7031))
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Get_KillCounter, false)
  self.UIRoot.CanvasPanel_39:SetWidgetVisibility(ESlateVisibility.SelfHitTestInvisible)
  self:RefreshOnlyShowGotCheckBox()
  self:InitModelDisplay()
  if not self:GetItemUpgradeMgr().itemRefitUnlockList then
    self:GetItemUpgradeMgr():send_upgrade_query_refit_req()
  else
    log(bWriteLog and "UI_Item_Upgrade:InitUI Has Refit already")
    self:GetItemUpgradeMgr():OnTimeDataRes()
  end
end

function UI_Item_Upgrade:CreateBottomUI()
  if not self.bottom_parts_ui then
    self.bottom_parts_ui = self:CreateChildWindow(self.UIRoot.CanvasPanel_UpgradeAccessorySkin, UIManager.UI_Config.item_upgrade_bottom)
  end
end

function UI_Item_Upgrade:OnGetRefitInfo(_, _, _)
  log(bWriteLog and "UI_Item_Upgrade:OnGetRefitInfo")
  self:GetItemUpgradeMgr():OnTimeDataRes()
end

function UI_Item_Upgrade:UpdateWeaponPendantWear(_, _, newIns, oldIns)
  log(bWriteLog and "UpdateWeaponPendantWear " .. tostring(newIns) .. "  old: " .. tostring(oldIns))
  if (not newIns or newIns == 0) and (not oldIns or oldIns == 0) then
    log(bWriteLog and "UpdateWeaponPendantWear, isn't put on or put off ")
    return
  end
  if self:IsWeaponModelView() then
    self:CacheRotationInPendant()
    local effectData = self:GetCurSelectEffectData()
    local subEffectType = self:GetItemUpgradeMgr().ENUM_MaxWeaponSubEffectType.WeaponPendant
    self.EffectComponent:PlayEffect(effectData.resID, effectData.effectID, subEffectType)
    self:RecoverPendantWeaponRotation()
  else
    local itemId = self.EffectList[self.ExtendedLoopScrollBox_Effect:GetSelectIndex()].resID
    local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
    ModelDisplayer.GetShowingAvatar():PutonEquipment(itemId, nil, {bIsUse = true})
  end
end

function UI_Item_Upgrade:CacheRotationInPendant()
  if not self:GetItemUpgradeMgr():GetIsInPendantEffect() then
    log(bWriteLog and "CacheRotationInPendant, isn't in pendant effect")
    return
  end
  if not self:IsWeaponModelView() then
    log(bWriteLog and "CacheRotationInPendant, isn't preview weapon model")
    return
  end
  local WeaponModelLogic = require("client.slua.logic.manager.WeaponModelLogic")
  local actor = WeaponModelLogic.GetProperWeaponShowActor()
  if actor then
    self.PendantWeaponRotation = actor:K2_GetActorRotation()
    log(bWriteLog and "CacheRotationInPendant")
  end
end

function UI_Item_Upgrade:RecoverPendantWeaponRotation()
  if not self:GetItemUpgradeMgr():GetIsInPendantEffect() then
    log(bWriteLog and "RecoverPendantWeaponRotation, isn't in pendant effect")
    return
  end
  if not self:IsWeaponModelView() then
    log(bWriteLog and "RecoverPendantWeaponRotation, isn't preview weapon model")
    return
  end
  if not self.PendantWeaponRotation then
    log(bWriteLog and "RecoverPendantWeaponRotation, rotation == nil")
    return
  end
  local WeaponModelLogic = require("client.slua.logic.manager.WeaponModelLogic")
  WeaponModelLogic.SetShowingActorRotation(0, 0, self.PendantWeaponRotation.Yaw)
  log(bWriteLog and "RecoverPendantWeaponRotation")
end

function UI_Item_Upgrade:CheckDefaultPendantPak()
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local PufferTlog = require("client.slua.logic.download.report.puffer_tlog")
  local idList = {418004001}
  local state = PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, idList)
  if state ~= PufferConst.ENUM_DownloadState.Done then
    log(bWriteLog and "[ItemUpgrade] Pendant isn't Download")
    
    local function DownloadSuccessCallback()
      log(bWriteLog and "[ItemUpgrade] Pendant Download Success")
      if self:GetItemUpgradeMgr():GetIsInPendantEffect() and self:GetItemUpgradeMgr():GetWeaponPendantID(self.CurSelectWeaponID, DataMgr.roleData.uid) == 418004001 then
        log(bWriteLog and "[ItemUpgrade] Pendant Download Success in pendant Effect")
        if self:IsWeaponModelView() then
          self:CacheRotationInPendant()
          local effectData = self:GetCurSelectEffectData()
          local subEffectType = self:GetItemUpgradeMgr().ENUM_MaxWeaponSubEffectType.WeaponPendant
          self.EffectComponent:PlayEffect(effectData.resID, effectData.effectID, subEffectType)
          self:RecoverPendantWeaponRotation()
        end
      end
    end
    
    local ExtraData = {
      bSkipPopUp = true,
      bFirst = true,
      bAutoDownload = false
    }
    PufferManager.Download(PufferConst.ENUM_DownloadType.ODPAK, idList, PufferTlog.Enum_TLog_From.Auto, DownloadSuccessCallback, ExtraData)
  else
    log(bWriteLog and "[ItemUpgrade] Pendant Download")
  end
end

function UI_Item_Upgrade:OnTimeDataInited()
  log(bWriteLog and "UI_Item_Upgrade:OnTimeDataInited 1")
  self:AddTimer(0.15, function()
    log(bWriteLog and "UI_Item_Upgrade:OnTimeDataInited 2")
    self:CacheSelectionForReinit()
    self:CreateBottomUI()
    self:InitWeaponSubTypeTab()
    self:InitFirearmFilterComboBox()
    self:GenerateWeaponItemListData()
    self.bWeaponListInited = true
    if not self:CheckWeaponItemIistEmpty() then
      return
    end
    coroutine.yield(0.25)
    local JumpUtils = require("client.logic.store.jump_utils")
    log(bWriteLog and "UI_Item_Upgrade:OnTimeDataInited RequestJumpMapInfo")
    JumpUtils.RequestJumpMapInfo()
  end)
end

function UI_Item_Upgrade:CacheSelectionForReinit()
  self.reinitPreserveItemID = nil
  if not self.bWeaponListInited then
    return
  end
  if self.jumpTabIndex or self.jumpSubIndex or self.defaultShowItemId and self.defaultShowItemId > 0 then
    return
  end
  local tabIndex = self.ExtendedLoopScrollBox_TabList and self.ExtendedLoopScrollBox_TabList:GetSelectIndex() or 0
  if not tabIndex or tabIndex <= 0 then
    return
  end
  self.jumpTabIndex = tabIndex
  self.jumpSubIndex = self.curSelectSubIndex
  if self.curOpenTabType == item_upgrade_ui_config.UITabType.ItemUpgradeUI and self.ScrollBoxWeapon then
    local curData = ItemList[self.ScrollBoxWeapon:GetSelectIndex()]
    if curData and curData.resID then
      self.reinitPreserveItemID = curData.resID
    end
  end
  printf("UI_Item_Upgrade:CacheSelectionForReinit tabIndex:%s, subIndex:%s, itemID:%s", tostring(tabIndex), tostring(self.curSelectSubIndex), tostring(self.reinitPreserveItemID))
end

function UI_Item_Upgrade:InitWeaponSubTypeTab()
  self:InitWeaponSubTypeTabData()
  self.curSelectedWeaponType = nil
  local tabList = item_upgrade_ui_config.TabListConfig or {}
  self.ExtendedLoopScrollBox_TabList:SetData(tabList)
  if 0 < #tabList then
    if self.jumpSubIndex then
      self.curSelectSubIndex = self.jumpSubIndex
      self.jumpSubIndex = nil
    end
    local tabIndex = 1
    if not self.jumpTabIndex or self.jumpTabIndex == 0 or self.jumpTabIndex > #tabList then
      tabIndex = 1
      self.curSelectSubIndex = 1
    else
      tabIndex = self.jumpTabIndex
    end
    if tabList[tabIndex] then
      self.curOpenTabType = tabList[tabIndex].TabType
      self.ExtendedLoopScrollBox_TabList:Select(tabIndex)
    end
    self.jumpTabIndex = nil
  end
end

function UI_Item_Upgrade:InitFirearmFilterComboBox()
  local comboRoot = self.UIRoot.Common_ComboBox_UIBP
  if not comboRoot then
    log(bWriteLog and "UI_Item_Upgrade:InitFirearmFilterComboBox no Common_ComboBox_UIBP widget, skip")
    return
  end
  comboRoot:SetWidgetVisibility(ESlateVisibility.SelfHitTestInvisible)
  self.ComboBox_Firearm = self:InitCommonComboBoxNew(comboRoot)
  self.ComboBox_Firearm:SetRefreshOptionCallback(self.OnRefreshFirearmFilterItem, self)
  self.ComboBox_Firearm:SetSelectOptionCallback(self.OnClickFirearmFilterItem, self)
  self.firearmFilterList = self:BuildFirearmFilterList()
  self.ComboBox_Firearm:SetData(self.firearmFilterList, 1, true)
end

function UI_Item_Upgrade:RefreshFirearmFilterComboBox()
  if not self.ComboBox_Firearm then
    return
  end
  self.firearmFilterList = self:BuildFirearmFilterList()
  local selectIndex = 1
  local curWeaponID = self.curSelectedFirearmWeaponID or 0
  for index, data in ipairs(self.firearmFilterList) do
    if data.weaponID == curWeaponID then
      selectIndex = index
      break
    end
  end
  self.curSelectedFirearmWeaponID = self.firearmFilterList[selectIndex] and self.firearmFilterList[selectIndex].weaponID or 0
  self.ComboBox_Firearm:SetData(self.firearmFilterList, selectIndex, true)
end

function UI_Item_Upgrade:OnRefreshFirearmFilterItem(widget, data, index)
  if not data then
    return
  end
  if widget.TextBlock_ItemName then
    widget.TextBlock_ItemName:SetText(data.text or "")
  end
end

function UI_Item_Upgrade:OnClickFirearmFilterItem(widget, data, index)
  self:PlayAudio(sound_config.click)
  if not data then
    return
  end
  self.curSelectedFirearmWeaponID = data.weaponID or 0
  if self.ComboBox_Firearm and self.ComboBox_Firearm.TextBlock_ItemName then
    self.ComboBox_Firearm.TextBlock_ItemName:SetText(data.text or "")
  end
  self:GenerateWeaponItemListData()
  self:UpdateItemList(1, false)
end

function UI_Item_Upgrade:InitWeaponSubTypeTabData()
  local tPageItemList = self:GetAllPageItemList()
  local bIsOpenAll = self:GetItemUpgradeMgr().openAll
  local tAllSubTypeCount = {}
  for _, tItemInfo in ipairs(tPageItemList) do
    if bIsOpenAll or self:GetItemUpgradeMgr():CheckIsValid(tItemInfo.GroupID) then
      local tItemBagData = self:GetItemInfo(tItemInfo)
      if tItemBagData and tItemBagData.count then
        local tItemCfg = CDataTable.GetTableData("Item", tItemInfo.ItemID)
        local nSubType = tItemCfg.ItemSubType
        tAllSubTypeCount[0] = (tAllSubTypeCount[0] or 0) + 1
        tAllSubTypeCount[nSubType] = (tAllSubTypeCount[nSubType] or 0) + 1
      end
    end
  end
  self.ItemUpgradeTabCountMap = {}
  for _, v in ipairs(item_upgrade_ui_config.ItemUpgradeTabListConfig) do
    self.ItemUpgradeTabCountMap[v.TabType] = tAllSubTypeCount[v.TabType] or 0
  end
end

function UI_Item_Upgrade:BuildFirearmFilterList()
  local pageItemList = self:GetAllPageItemList()
  local bIsOpenAll = self:GetItemUpgradeMgr().openAll
  local ItemUpgradeMgr = self:GetItemUpgradeMgr()
  local ArmorySystem = require("client.logic.armory.logic_armory")
  local weaponMap = {}
  local list = {}
  for _, itemInfo in ipairs(pageItemList) do
    if bIsOpenAll or ItemUpgradeMgr:CheckIsValid(itemInfo.GroupID) then
      local baseWeaponID = ArmorySystem.GetWeaponOriItemIdBySkinId(itemInfo.ItemID)
      if baseWeaponID and not weaponMap[baseWeaponID] then
        local descCfg = CDataTable.GetTableData("ArmoryDescConfig", baseWeaponID)
        local name = descCfg and descCfg.ArmorySimpleDesc or ""
        weaponMap[baseWeaponID] = true
        local weaponType = math.floor(baseWeaponID / 1000)
        if self.curSelectedWeaponType == 0 or weaponType == self.curSelectedWeaponType then
          list[#list + 1] = {
            text = name,
            weaponID = baseWeaponID,
            weaponType = weaponType
          }
        end
      end
    end
  end
  table.sort(list, function(a, b)
    return a.weaponType < b.weaponType
  end)
  table.sort(list, function(a, b)
    return a.weaponID < b.weaponID
  end)
  table.insert(list, 1, {
    text = LocUtil.GetLocalizeResStr(4462),
    weaponID = 0
  })
  return list
end

function UI_Item_Upgrade:OnUpdateFormItem(widget, index)
  local formItemData = self.FormList:GetItemData(index)
  local ItemUpgradeMgr = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.ItemUpgradeModule)
  if self._downloadPollTimers and self._downloadPollTimers[widget] then
    self:RemoveTimer(self._downloadPollTimers[widget])
    self._downloadPollTimers[widget] = nil
  end
  if formItemData and formItemData.groupID then
    local groupID = formItemData.groupID
    local itemID = 0
    if ItemUpgradeMgr:IsDualFormGroup(groupID) then
      itemID = ItemUpgradeMgr:GetMaxLevelItemByGroupID(groupID)
    else
      itemID = ItemUpgradeMgr:GetObtainedMaxLevelItemByGroupID(groupID)
    end
    if not itemID or itemID == 0 then
      log(bWriteLog and "UI_Item_Upgrade:OnUpdateFormItem, itemID invalid")
      return
    end
    local path, bHasAddKnownMissing = UIUtil.GetItemBigIcon(itemID, widget.Image_Weapon)
    local params = {bMatchSize = true, bHasAddKnownMissing = bHasAddKnownMissing}
    self:SetTexture(widget.Image_Weapon, path, params)
    UIUtil.CheckAndUpdateIconScale(itemID, path, widget.Image_Weapon, 1)
    local itemCfg = CDataTable.GetTableData("Item", itemID)
    if itemCfg and itemCfg.ItemBigIcon and itemCfg.ItemBigIcon ~= "" and itemCfg.ItemBigIcon ~= path then
      self._downloadPollTimers = self._downloadPollTimers or {}
      self._downloadPollTimers[widget] = self:AddTimerLoop(0.5, function()
        if UIUtil.HasIconDownloaded(itemCfg.ItemBigIcon) then
          self:SetTexture(widget.Image_Weapon, itemCfg.ItemBigIcon, {bMatchSize = true})
          widget.Image_Weapon:SetRenderScale(FVector2D(1.0, 1.0))
          widget.Image_Weapon:SetRenderAngle(0)
          if self._downloadPollTimers[widget] then
            self:RemoveTimer(self._downloadPollTimers[widget])
            self._downloadPollTimers[widget] = nil
          end
        end
      end, TIMER_INFINITE, 0.5)
    end
  end
  if self.FormIndex ~= index then
    widget.Image_Select1:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    widget.Image_Select2:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  else
    widget.Image_Select1:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    widget.Image_Select2:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  end
end

function UI_Item_Upgrade:OnClickFormItem(widget, index)
  self:PlayAudio(sound_config.click_v1)
  if index == self.FormList:GetSelectIndex() then
    return
  end
  self.SelectedSubIndex = 1
  self.FormIndex = index
  self.NeedPlayRefreshShapeEffectAnim = true
  self:DoClickWeaponItem(nil, index, self.ExtendedLoopScrollBox_Effect:GetSelectIndex(), true)
  self:AddTimer(0.1, function()
    self.NeedPlayRefreshShapeEffectAnim = false
  end)
end

function UI_Item_Upgrade:OnUpdateWeaponItem(widget, index)
  if self.WeaponTimerMap[widget] then
    local timer = self.WeaponTimerMap[widget]
    self.WeaponTimerMap[widget] = nil
    self:RemoveTimer(timer)
  end
  if not ItemList[index] then
    return
  end
  local data = ItemList[index]
  local cfg = UIUtil.GetItemCfg(data.resID)
  if not cfg then
    return
  end
  local ItemUpgradeMgr = self:GetItemUpgradeMgr()
  self:SetWidgetVisible(widget.CanvasPanel_Freeze, false)
  local tItemData = wardrobe_data:GetHallDepotItemDataByResIDAndTimeliness(ItemUpgradeMgr:GetCurrentStateItemID(data.resID), false)
  local LogicCardCollectionGun = require("client.slua.logic.card_collection.LogicCardCollectionGun")
  if not tItemData and LogicCardCollectionGun.IsCardCollectionGun(data.groupID) then
    tItemData = wardrobe_data:GetHallDepotItemDataByResIDAndTimeliness(ItemUpgradeMgr:GetCurrentStateItemID(data.resID), true)
  end
  if tItemData and tItemData.lock_cnt and tItemData.lock_cnt > 0 then
    self:SetWidgetVisible(widget.CanvasPanel_Freeze, true)
  end
  local quality = cfg.ItemQuality
  UIUtil.SetBgQuality(widget.ItemUpgrade_gun_item.Image_Quality, quality)
  local path, bHasAddKnownMissing = UIUtil.GetItemBigIcon(data.resID, widget.ItemUpgrade_gun_item.Image_Gun)
  local params = {bMatchSize = true, bHasAddKnownMissing = bHasAddKnownMissing}
  self:SetTexture(widget.ItemUpgrade_gun_item.Image_Gun, path, params)
  UIUtil.CheckAndUpdateIconScale(data.resID, path, widget.ItemUpgrade_gun_item.Image_Gun, 1)
  self:SetTexture(widget.Image_Sele, item_upgrade_ui_config.ItemSelectFramePath)
  widget.Image_Sele:SetWidgetVisibility(UIUtil.BoolToVisible(index == self.ScrollBoxWeapon:GetSelectIndex()))
  local isunlock = false
  if tItemData and tItemData.count and tItemData.lock_cnt then
    isunlock = 0 < tItemData.count or tItemData.lock_cnt > 0
  end
  if isunlock then
    local timeValid = tItemData and tItemData.expireTS and 0 < tItemData.expireTS or false
    if timeValid then
      widget.WidgetSwitcher_1:SetActiveWidgetIndex(1)
      widget.Mask:SetWidgetVisibility(ESlateVisibility.Collapsed)
      self:SetWidgetVisible(widget.WidgetSwitcher_1, true)
      self.WeaponTimerMap[widget] = self:AddTimerLoop(0, function()
        local CountDown = tItemData.expireTS - TimeUtil.GetServerTimeInSec()
        if 0 <= CountDown then
          local timeStr = TimeUtil.FormatCountDownTime_DH_or_HMS(CountDown, true)
          widget.TextBlock_LimitTime:SetText(timeStr)
        else
          local timer = self.WeaponTimerMap[widget]
          self.WeaponTimerMap[widget] = nil
          self:RemoveTimer(timer)
        end
      end, TIMER_INFINITE, 1)
    else
      widget.Mask:SetWidgetVisibility(ESlateVisibility.Collapsed)
      self:SetWidgetVisible(widget.WidgetSwitcher_1, false)
    end
  else
    widget.WidgetSwitcher_1:SetActiveWidgetIndex(0)
    widget.Mask:SetWidgetVisibility(ESlateVisibility.SelfHitTestInvisible)
    self:SetWidgetVisible(widget.WidgetSwitcher_1, true)
  end
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local common_download_handler = require("client.slua.common.common_download_handler")
  local Extra = {}
  local logic_weapon_pendant = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_weapon_pendant)
  if logic_weapon_pendant:CanSkinWithPendant(data.resID) then
    function Extra.callback()
      if self.CurSelectWeaponID and data and data.resID then
        log(bWriteLog and string.format("[Item_Upgrade] Download CurSelectWeaponID : %s ResID : %s", self.CurSelectWeaponID, data.resID))
        
        if self.CurSelectWeaponID == data.resID and ItemUpgradeMgr:GetIsInPendantEffect() then
          if self:IsWeaponModelView() then
            self:CacheRotationInPendant()
            local effectData = self:GetCurSelectEffectData()
            local subEffectType = ItemUpgradeMgr.ENUM_MaxWeaponSubEffectType.WeaponPendant
            if effectData then
              self.EffectComponent:PlayEffect(effectData.resID, effectData.effectID, subEffectType)
            end
            self:RecoverPendantWeaponRotation()
          else
            local itemId = self.EffectList[self.ExtendedLoopScrollBox_Effect:GetSelectIndex()].resID
            local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
            ModelDisplayer.GetShowingAvatar():PutonEquipment(itemId, nil, {bIsUse = true})
          end
        end
      end
    end
  end
  Extra.delayProgressUntilThreshold = true
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  local tItemList = {
    data.resID,
    cfg.ItemBigIcon
  }
  local size = 0
  local _, totalSize = PufferManager.GetSize(PufferConst.ENUM_DownloadType.ODPAK, tItemList)
  size = totalSize / PufferConst.MB
  Extra.showAlertSize = true
  
  function Extra.clickCallback(downloadData)
    if PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, downloadData) ~= PufferConst.ENUM_DownloadState.Done then
      self:OnItemClickDownload(nil, nil, downloadData)
    end
  end
  
  common_download_handler.CreateDownloadUIReturnUIBase(PufferConst.ENUM_DownloadType.ODPAK, tItemList, self, widget.Panel_Download, Extra)
  self:RefreshWeaponRed(widget, data)
end

function UI_Item_Upgrade:RefreshWeaponRed(widget, data)
  widget.Reddot_Anchor:UnBind()
  local GroupData = self:GetGroupRedData(data)
  if GroupData then
    widget.Reddot_Anchor:Bind(GroupData)
  end
end

function UI_Item_Upgrade:GetGroupRedData(data)
  local ResearchRedDot = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ResearchRedDot)
  local ExTabRedData = ResearchRedDot:GetNodeDataByTabType(self.curOpenTabType)
  if not ExTabRedData then
    return
  end
  local TabType = self.curSelectedWeaponType
  if TabType == 0 then
    TabType = data.subType
  end
  local TabRedData = ExTabRedData[TabType]
  if not TabRedData then
    return
  end
  if not TabRedData[data.groupID] then
    return
  end
  if data.refitPair and next(data.refitPair) then
    for i, refitInfo in ipairs(data.refitPair) do
      if TabRedData[refitInfo.groupID] then
        return TabRedData[refitInfo.groupID]
      end
    end
  else
    return TabRedData[data.groupID]
  end
end

function UI_Item_Upgrade:GetEffectRedData(effectLevel)
  local index = self.ScrollBoxWeapon:GetSelectIndex()
  local data = ItemList[index]
  if not data then
    return
  end
  local groupData, formIndex = self:GetGroupRedData(data)
  if not groupData then
    return
  end
  return groupData[effectLevel]
end

function UI_Item_Upgrade:GetSubEffectRedData(EffectLevel, SubEffectIndex)
  local EffectRedData = self:GetEffectRedData(EffectLevel)
  if not EffectRedData then
    return
  end
  return EffectRedData[SubEffectIndex]
end

function UI_Item_Upgrade:ClearWeaponRed()
  local index = self.ScrollBoxWeapon:GetSelectIndex()
  local data = ItemList[index]
  if not data then
    return
  end
  local GroupData = self:GetGroupRedData(data)
  if GroupData and GroupData.newCount > 0 and not GroupData.isDynamic then
    GroupData.newCount = GroupData.newCount - 1
    self:AddRedCache(0, 0)
  end
end

function UI_Item_Upgrade:ClearEffectRed(EffectLevel)
  local EffectRedData = self:GetEffectRedData(EffectLevel)
  if EffectRedData and EffectRedData.newCount > 0 and not EffectRedData.isDynamic then
    EffectRedData.newCount = EffectRedData.newCount - 1
    self:AddRedCache(EffectLevel, 0)
  end
end

function UI_Item_Upgrade:ClearSubEffectRed(EffectLevel, SubEffectIndex)
  local SubEffectRedData = self:GetSubEffectRedData(EffectLevel, SubEffectIndex)
  if SubEffectRedData and SubEffectRedData.newCount > 0 and not SubEffectRedData.isDynamic then
    SubEffectRedData.newCount = SubEffectRedData.newCount - 1
    self:AddRedCache(EffectLevel, SubEffectIndex)
  end
end

function UI_Item_Upgrade:AddRedCache(EffectLevel, SubEffectIndex)
  local index = self.ScrollBoxWeapon:GetSelectIndex()
  local data = ItemList[index]
  if not data then
    return
  end
  local ResearchRedDot = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ResearchRedDot)
  ResearchRedDot:ClearItemUpgradeRedDot(data.groupID, EffectLevel, SubEffectIndex)
end

function UI_Item_Upgrade:OnUpdateSubItem(widget, index, subIndex)
  local strBtn = LocUtil.GetLocalizeResStr("21244")
  widget.TextBlock_8:SetText(strBtn)
end

function UI_Item_Upgrade:OnClickWeaponItem(widget, index)
  self:PlayAudio(sound_config.click_v1)
  self:OnClickedWeaponItemDetail(widget, index)
  self:ClearWeaponRed()
end

function UI_Item_Upgrade:OnClickedWeaponItemDetail(widget, index, bForcedReset)
  self.ClickDownloadItemID = nil
  self.SelectedSubIndex = 1
  self.FormIndex = 1
  self.FormData = {}
  local lastSelectIndex = self.ScrollBoxWeapon:GetSelectIndex()
  if lastSelectIndex ~= index or bForcedReset then
    self.ScrollBoxWeapon:Select(index)
    self:ClearWeaponRed()
    self:DoClickWeaponItem()
  end
end

function UI_Item_Upgrade:GetEffectInfo(id)
  return CDataTable.GetTableData("ItemUpgradeEffectConfig", id)
end

function UI_Item_Upgrade:GetSelectWeaponItemData()
  local selectWeaponItemIndex = self.ScrollBoxWeapon:GetSelectIndex()
  local selectWeaponData = ItemList[selectWeaponItemIndex]
  if selectWeaponData then
    self.CurSelectWeaponData = selectWeaponData
    return selectWeaponData
  end
  return self.CurSelectWeaponData
end

function UI_Item_Upgrade:OnClickWeaponSubType(widget, index)
  log(bWriteLog and "[cw] UI_Item_Upgrade:OnClickWeaponSubType(widget, " .. tostring(index) .. ")  ")
  self:PlayAudio(sound_config.click_v1)
  local weaponType = 0
  if item_upgrade_ui_config.ItemUpgradeTabListConfig[index] and item_upgrade_ui_config.ItemUpgradeTabListConfig[index].TabType then
    weaponType = item_upgrade_ui_config.ItemUpgradeTabListConfig[index].TabType
  end
  self:SelectWeaponSubType(weaponType)
end

function UI_Item_Upgrade:OnUpdateWeaponSubType(widget, index)
  local tabData = self.SubTabList and self.SubTabList:GetTabData(index)
  if not tabData then
    return
  end
  local data = tabData._sourceData
  local weaponType = data.TabType
  local Num = self.ItemUpgradeTabCountMap[weaponType]
  widget.TextBlock_0:SetText(tostring(Num))
  if weaponType == self.curSelectedWeaponType then
    widget.WidgetSwitcher_0:SetActiveWidgetIndex(0)
  else
    widget.WidgetSwitcher_0:SetActiveWidgetIndex(1)
  end
end

function UI_Item_Upgrade:InitModelDisplay()
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  ModelDisplayer.Init(nil, nil, nil, true)
  
  local function GetUIRestricZoneFunc()
    local ScreenPixelSize = UIUtil.GetViewportSize()
    local DPI = UIUtil.GetViewportScale()
    local ScreenX = ScreenPixelSize.X / DPI
    local ScreenY = ScreenPixelSize.Y / DPI
    local ScaleSize1 = math.min(ScreenX / 1136, ScreenY / 640)
    return {
      L = 180 * ScaleSize1 * math.min(290.66 * ScaleSize1 * DPI / 271.4, 1.0538461538461539) - 30,
      R = 400 * ScaleSize1 - 30,
      U = 0,
      D = 0
    }
  end
  
  ModelDisplayer.RegistGetUIRestrictZoneFunc(GetUIRestricZoneFunc)
  ModelDisplayer.SwitchToModel()
end

function UI_Item_Upgrade:GetCurSelectEffectData()
  if #self.EffectList > 0 then
    return self.EffectList[self.ExtendedLoopScrollBox_Effect:GetSelectIndex()]
  end
  return nil
end

function UI_Item_Upgrade:GetItemInfo(tWeaponCfg)
  local tItemInfo = wardrobe_data:GetHallDepotItemDataByResIDAndTimeliness(self:GetItemUpgradeMgr():GetCurrentStateItemID(tWeaponCfg.ItemID), false)
  local bUseRefit = false
  if not tItemInfo and self:IsCanRefit(tWeaponCfg.GroupID) then
    tItemInfo = self:GetRefitItemID(tWeaponCfg.GroupID, tWeaponCfg.ItemID)
    bUseRefit = true
  end
  local LogicCardCollectionGun = require("client.slua.logic.card_collection.LogicCardCollectionGun")
  if not tItemInfo and LogicCardCollectionGun.IsCardCollectionGun(tWeaponCfg.GroupId) then
    tItemInfo = wardrobe_data:GetHallDepotItemDataByResIDAndTimeliness(self:GetItemUpgradeMgr():GetCurrentStateItemID(tWeaponCfg.ItemID), true)
  end
  return tItemInfo, bUseRefit
end

function UI_Item_Upgrade:CreateUpgradeItemData(cfg)
  local itemCfg = CDataTable.GetTableData("Item", cfg.ItemID)
  if itemCfg == nil then
    return {}
  end
  local refitPair, refitCfg
  if self:IsCanRefit(cfg.GroupID) then
    refitCfg = self:GetItemUpgradeMgr():GetRefitCfgData(cfg.GroupID)
    refitPair = {
      [1] = {
        groupID = cfg.GroupID
      },
      [2] = {
        groupID = refitCfg.refitGroupID
      }
    }
  end
  local itemInfo, bUseRefit = self:GetItemInfo(cfg)
  if itemInfo ~= nil then
    local useGroupID = cfg.GroupID
    if bUseRefit and refitCfg then
      useGroupID = refitCfg.refitGroupID
    end
    return {
      instID = itemInfo.insID,
      resID = itemInfo.resID,
      count = itemInfo.count,
      groupID = useGroupID,
      subType = itemCfg.ItemSubType,
      sortID = cfg.ID,
      refitPair = refitPair,
      itemName = itemCfg.ItemName or ""
    }
  else
    return {
      resID = cfg.ItemID,
      groupID = cfg.GroupID,
      subType = itemCfg.ItemSubType,
      sortID = cfg.ID,
      refitPair = refitPair,
      itemName = itemCfg.ItemName or ""
    }
  end
end

function UI_Item_Upgrade:GetAllPageItemList()
  if not self.tPageItemList then
    self.tPageItemList = self:GetItemUpgradeMgr():GetAllUpgradeItemsExceptPadora()
  end
  return self.tPageItemList
end

function UI_Item_Upgrade:RefreshOnlyShowGotCheckBox()
  self.UIRoot.Switcher_toggleIsOnlyShowGotState:SetActiveWidgetIndex(self.isOnlyShowGot and 1 or 0)
end

function UI_Item_Upgrade:ToggleIsOnlyShowGot()
  self:PlayAudio(sound_config.click_v1)
  self.isOnlyShowGot = not self.isOnlyShowGot
  self:RefreshOnlyShowGotCheckBox()
  self:GenerateWeaponItemListData()
  self:UpdateItemList(1, false)
end

function UI_Item_Upgrade:SelectWeaponSubType(weaponType)
  log(bWriteLog and "[cw] UI_Item_Upgrade:SelectWeaponSubType(" .. tostring(weaponType) .. ") ")
  local bSameType = weaponType == self.curSelectedWeaponType
  local preserveItemID
  if bSameType and self.ScrollBoxWeapon then
    local curData = ItemList[self.ScrollBoxWeapon:GetSelectIndex()]
    if curData and curData.resID then
      preserveItemID = curData.resID
    end
  end
  if not preserveItemID and self.reinitPreserveItemID then
    preserveItemID = self.reinitPreserveItemID
  end
  self.reinitPreserveItemID = nil
  if not bSameType then
    self.curSelectedFirearmWeaponID = 0
  end
  self.curSelectedWeaponType = weaponType
  self.SubTabList:RefreshAllTabItemShow()
  self:RefreshFirearmFilterComboBox()
  self:GenerateWeaponItemListData()
  local selectIndex = 1
  local bRefit = false
  if self.defaultShowItemId and 0 < self.defaultShowItemId then
    if self:IsJumpRefitItemID(self.defaultShowItemId) then
      selectIndex = self:GetRefitItemIndex(self.defaultShowItemId)
      bRefit = true
    else
      selectIndex = self:GetWeaponItemListIndexByNonRefitItemID(self.defaultShowItemId)
    end
    self.defaultShowItemId = nil
  elseif preserveItemID then
    selectIndex = self:GetWeaponItemListIndexByNonRefitItemID(preserveItemID)
  end
  self:UpdateItemList(selectIndex, bRefit)
end

function UI_Item_Upgrade:UpdateItemList(selectIndex, bRefit)
  log(bWriteLog and "[cw] UI_Item_Upgrade:UpdateItemList")
  if not self:CheckWeaponItemIistEmpty() then
    return
  end
  self.SelectedSubIndex = self.jumpEffectSubIndex or 1
  self.FormIndex = 1
  self.FormData = {}
  self.ScrollBoxWeapon:SetData(ItemList)
  self.ScrollBoxWeapon:Select(selectIndex)
  self:ClearWeaponRed()
  self:DoClickWeaponItem(bRefit, nil, self.jumpEffectIndex, nil, self.jumpEffectSubIndex)
  self.jumpEffectIndex = nil
  self.jumpEffectSubIndex = nil
  if 0 < #ItemList then
    self.ScrollBoxWeapon:ScrollToItem(selectIndex)
    return
  end
end

function UI_Item_Upgrade:CheckWeaponItemIistEmpty()
  if #ItemList == 0 then
    self.UIRoot.WeaponListSwitcher:SetActiveWidgetIndex(1)
    return false
  end
  self.UIRoot.WeaponListSwitcher:SetActiveWidgetIndex(0)
  return true
end

function UI_Item_Upgrade:GenerateWeaponItemListData()
  ItemList = {}
  self:FillWeaponList()
  self:SortWeaponList()
end

function UI_Item_Upgrade:FillWeaponList()
  local pageItemList = self:GetAllPageItemList()
  local bIsOpenAll = self:GetItemUpgradeMgr().openAll
  local weaponType = self.curSelectedWeaponType
  local firearmWeaponID = self.curSelectedFirearmWeaponID or 0
  local ItemUpgradeMgr = self:GetItemUpgradeMgr()
  local ArmorySystem = require("client.logic.armory.logic_armory")
  for i, itemInfo in ipairs(pageItemList) do
    if ItemUpgradeMgr:CheckIsValid(itemInfo.GroupID) or bIsOpenAll then
      local info = self:CreateUpgradeItemData(itemInfo)
      if info then
        if self.isOnlyShowGot and not info.count then
          info = nil
        end
        if weaponType and weaponType ~= 0 and info and weaponType ~= info.subType then
          info = nil
        end
        if firearmWeaponID ~= 0 and info then
          local baseWeaponID = ArmorySystem.GetWeaponOriItemIdBySkinId(itemInfo.ItemID)
          if baseWeaponID ~= firearmWeaponID then
            info = nil
          end
        end
      end
      if info then
        ItemList[#ItemList + 1] = info
      end
    end
  end
end

function UI_Item_Upgrade:SortWeaponList()
  table.sort(ItemList, function(a, b)
    return a.sortID > b.sortID
  end)
end

function UI_Item_Upgrade:UpdateWeaponShapeComp(bForceRefit, forceIndex)
  local selectWeaponData = self:GetSelectWeaponItemData()
  if not selectWeaponData then
    log(bWriteLog and "UI_Item_Upgrade:UpdateWeaponShapeComp error selectWeaponData nil")
    return
  end
  local refitPair = selectWeaponData.refitPair
  if bForceRefit and not refitPair then
    log(bWriteLog and "UI_Item_Upgrade:UpdateWeaponShapeComp error bForceRefit but refitPair nil")
    return
  end
  local ShapeCompSelectIndex = 1
  if refitPair then
    if selectWeaponData.groupID == refitPair[1].groupID then
      ShapeCompSelectIndex = 1
    else
      ShapeCompSelectIndex = 2
    end
  end
  if bForceRefit then
    ShapeCompSelectIndex = 2
  end
  if forceIndex then
    ShapeCompSelectIndex = forceIndex
  end
  local groupID = selectWeaponData.groupID
  if refitPair then
    groupID = refitPair[ShapeCompSelectIndex].groupID
  end
  self.CurSelectWeaponID = self:GetItemUpgradeMgr():GetObtainedMaxLevelItemByGroupID(groupID)
  if refitPair then
    self.FormIndex = ShapeCompSelectIndex
    self.FormData = refitPair
    if self.bottom_parts_ui then
      self.bottom_parts_ui:SetInDiffForm(self.FormIndex ~= 1, self.FormData[self.FormIndex].groupID)
    end
    self.FormList:SetData(self.FormData)
    self.FormList:Select(self.FormIndex)
    self.FormPanel:SetWidgetVisibility(ESlateVisibility.Visible)
    local tItemData = wardrobe_data:GetHallDepotItemDataByResIDAndTimeliness(self.CurSelectWeaponID, false)
    if tItemData and tItemData.lock_cnt and tItemData.lock_cnt > 0 then
      self:SetWidgetVisible(self.FormPanel, false)
    end
    self.WeaponProgressBox:SetWidgetVisibility(ESlateVisibility.Collapsed)
  else
    self.FormPanel:SetWidgetVisibility(ESlateVisibility.Collapsed)
    self.WeaponProgressBox:SetWidgetVisibility(ESlateVisibility.SelfHitTestInvisible)
  end
end

function UI_Item_Upgrade:FindDualFormProperShapeSelectIndex(nGroupID)
  local selectWeaponData = self:GetSelectWeaponItemData()
  local currentIndex = self.FormList:GetSelectIndex()
  if not selectWeaponData then
    log(bWriteLog and "UI_Item_Upgrade:UpdateWeaponShapeComp error selectWeaponData nil")
    return currentIndex
  end
  local refitPair = selectWeaponData.refitPair
  if not refitPair then
    return currentIndex
  end
  for resIndex = 1, #refitPair do
    if refitPair[resIndex].groupID == nGroupID then
      return resIndex
    end
  end
  return currentIndex
end

function UI_Item_Upgrade:UpdateEffectList(ForceSelectEffectIndex)
  self.EffectList = self:GetItemUpgradeMgr():GetItemUpgradeEffectList(self.CurSelectWeaponID)
  local defaultSelectEffectIndex = 1
  if ForceSelectEffectIndex == nil then
    if next(self.EffectList) and #self.EffectList > 0 then
      local CurItemEffectLevel = self:GetCurItemEffectLevel()
      local CurItemEffectMaxLevel = #self.EffectList
      if CurItemEffectLevel == CurItemEffectMaxLevel then
        defaultSelectEffectIndex = CurItemEffectMaxLevel
      else
        defaultSelectEffectIndex = CurItemEffectLevel + 1
      end
    end
  else
    defaultSelectEffectIndex = ForceSelectEffectIndex
  end
  self.ExtendedLoopScrollBox_Effect:SetData(self.EffectList)
  self.ExtendedLoopScrollBox_Effect:Select(defaultSelectEffectIndex)
  self:ClearEffectRed(defaultSelectEffectIndex)
  self.ExtendedLoopScrollBox_Effect:ScrollToCenter(defaultSelectEffectIndex)
end

local ENUM_STATUEBUTTON = {
  NONE = -1,
  UPGRADE = 0,
  LOCK = 1,
  GOGET = 2,
  REFIT = 3,
  USE = 4,
  REFITED = 5,
  CANTUSE = 6
}

local function _ResolveAlreadyHave(ctx)
  if ctx.bSelectEffectUnlocked then
    return ENUM_STATUEBUTTON.NONE
  end
  if ctx.bSelectEffectCanDirectUnlock then
    return ENUM_STATUEBUTTON.UPGRADE
  end
  return ENUM_STATUEBUTTON.LOCK
end

local function _ResolveDualFormUnlocked(ctx)
  if not ctx.bHasSelectGroup then
    return ENUM_STATUEBUTTON.USE
  end
  return _ResolveAlreadyHave(ctx)
end

local BUTTON_STATUS_RULES = {
  {
    name = "DualForm_LowerForm_Locked",
    match = function(c)
      return c.bIsDualForm and c.bSelFormIsLowerForm and c.selectEffectIndex >= c.nForkLevel and c.nFullUnlockLevel > 0 and c.nSelFormLevel < c.nFullUnlockLevel and c.nSelFormLevel >= c.nForkLevel and c.selectEffectIndex <= c.nSelFormLevel
    end,
    resolve = function(c)
      return ENUM_STATUEBUTTON.CANTUSE
    end
  },
  {
    name = "DualForm_FullUnlocked",
    match = function(c)
      return c.bIsDualForm and c.nFullUnlockLevel > 0 and c.nSelFormLevel >= c.nFullUnlockLevel
    end,
    resolve = _ResolveDualFormUnlocked
  },
  {
    name = "DualForm_Default",
    match = function(c)
      return c.bIsDualForm
    end,
    resolve = function(c)
      if c.nSelFormLevel == 0 and c.bSelectFirstEffect then
        return ENUM_STATUEBUTTON.GOGET
      end
      return _ResolveAlreadyHave(c)
    end
  },
  {
    name = "AnyShape_UnlockedRefit_NotUsed",
    match = function(c)
      return c.bSelectRefitPair and c.bSelectGroupUnlockRefit and not c.bHasSelectGroup
    end,
    resolve = function(_)
      return ENUM_STATUEBUTTON.USE
    end
  },
  {
    name = "AnyShape_UnlockedRefit_Used",
    match = function(c)
      return c.bSelectRefitPair and c.bSelectGroupUnlockRefit
    end,
    resolve = _ResolveAlreadyHave
  },
  {
    name = "RefitShape_LockedRefit_SwitchWeapon",
    match = function(c)
      return c.bSelectRefitPair and c.bSelectRefitShape and not c.bSelectGroupUnlockRefit and c.bIsSwitchWeapon
    end,
    resolve = function(_)
      return ENUM_STATUEBUTTON.GOGET
    end
  },
  {
    name = "RefitShape_LockedRefit_Refit",
    match = function(c)
      return c.bSelectRefitPair and c.bSelectRefitShape and not c.bSelectGroupUnlockRefit
    end,
    resolve = function(_)
      return ENUM_STATUEBUTTON.REFIT
    end
  },
  {
    name = "Fallback_OwnedOrGoGetOrLock",
    match = function(_)
      return true
    end,
    resolve = function(c)
      if c.bHasSelectGroup then
        return _ResolveAlreadyHave(c)
      end
      if c.bSelectFirstEffect then
        return ENUM_STATUEBUTTON.GOGET
      end
      return ENUM_STATUEBUTTON.LOCK
    end
  }
}

function UI_Item_Upgrade:_BuildButtonStatusContext(selectWeaponData, ItemUpgradeMgr, selectEffectIndex, curItemEffectLevel, nBaseGroupID)
  local bSelectRefitPair = selectWeaponData.refitPair ~= nil
  local bSelectRefitShape = bSelectRefitPair and self.FormList:GetSelectIndex() == 2
  local bSelectGroupUnlockRefit = bSelectRefitPair and (ItemUpgradeMgr:IsRefitUnlockComplete(nBaseGroupID, self.CurSelectWeaponID) or ItemUpgradeMgr:IsDualFormRefitUnlocked(nBaseGroupID))
  local bHasSelectGroup
  if bSelectRefitPair then
    local selectShapeIndex = self.FormList:GetSelectIndex()
    bHasSelectGroup = ItemUpgradeMgr:CheckHasGroup(selectWeaponData.refitPair[selectShapeIndex].groupID)
  else
    bHasSelectGroup = ItemUpgradeMgr:CheckHasGroup(selectWeaponData.groupID)
  end
  local bIsSwitchWeapon = bSelectRefitPair and ItemUpgradeMgr:IsSwitchStateWeapon(self.CurSelectWeaponID)
  local bIsDualForm = bSelectRefitPair and ItemUpgradeMgr:IsDualFormGroup(nBaseGroupID)
  local nForkLevel, nFullUnlockLevel = 0, 0
  local bSelFormIsLowerForm = false
  if bIsDualForm then
    nForkLevel = ItemUpgradeMgr:GetForkLevel(nBaseGroupID)
    nFullUnlockLevel = ItemUpgradeMgr:GetFullUnlockLevel(nBaseGroupID)
    local levels = ItemUpgradeMgr:GetDualFormLevels(nBaseGroupID)
    if levels then
      local lvSel = self.FormList:GetSelectIndex() == 2 and levels.lvY or levels.lvX
      local lvOther = self.FormList:GetSelectIndex() == 2 and levels.lvX or levels.lvY
      bSelFormIsLowerForm = lvSel < lvOther
    end
  end
  return {
    bSelectRefitPair = bSelectRefitPair,
    bSelectRefitShape = bSelectRefitShape,
    bSelectFirstEffect = selectEffectIndex == 1,
    bSelectEffectUnlocked = selectEffectIndex <= curItemEffectLevel,
    bSelectEffectCanDirectUnlock = curItemEffectLevel + 1 == selectEffectIndex,
    bHasSelectGroup = bHasSelectGroup,
    bSelectGroupUnlockRefit = bSelectGroupUnlockRefit,
    bIsSwitchWeapon = bIsSwitchWeapon,
    bIsDualForm = bIsDualForm,
    nSelFormLevel = curItemEffectLevel,
    nForkLevel = nForkLevel,
    nFullUnlockLevel = nFullUnlockLevel,
    bSelFormIsLowerForm = bSelFormIsLowerForm,
    selectEffectIndex = selectEffectIndex
  }
end

function UI_Item_Upgrade:_ResolveButtonStatus(ctx)
  for _, rule in ipairs(BUTTON_STATUS_RULES) do
    if rule.match(ctx) then
      log(bWriteLog and "_ResolveButtonStatus hit: " .. rule.name)
      return rule.resolve(ctx)
    end
  end
  return ENUM_STATUEBUTTON.NONE
end

function UI_Item_Upgrade:RefreshEffectBtnStatusAndMatComp()
  self.UIRoot.WidgetSwitcher_0:SetWidgetVisibility(ESlateVisibility.Visible)
  local selectWeaponData = self:GetSelectWeaponItemData()
  if not selectWeaponData then
    log(bWriteLog and "UI_Item_Upgrade:RefreshEffectBtnStatusAndMatComp error selectWeaponData nil")
    return
  end
  local selectEffectIndex = self.ExtendedLoopScrollBox_Effect:GetSelectIndex()
  local curSelectEffect = self:GetCurSelectEffectData()
  if not curSelectEffect then
    log(bWriteLog and "UI_Item_Upgrade:RefreshEffectBtnStatusAndMatComp error curSelectEffect nil")
    return
  end
  local curItemEffectLevel = self:GetCurItemEffectLevel()
  local nBaseGroupID
  if selectWeaponData.refitPair then
    nBaseGroupID = selectWeaponData.refitPair[1].groupID
  else
    nBaseGroupID = selectWeaponData.groupID
  end
  local ItemUpgradeMgr = self:GetItemUpgradeMgr()
  local ctx = self:_BuildButtonStatusContext(selectWeaponData, ItemUpgradeMgr, selectEffectIndex, curItemEffectLevel, nBaseGroupID)
  local buttonStatus = self:_ResolveButtonStatus(ctx)
  log(bWriteLog and string.format("UI_Item_Upgrade:RefreshEffectBtnStatusAndMatComp  buttonStatus=%s", tostring(buttonStatus)))
  if buttonStatus == ENUM_STATUEBUTTON.NONE then
    self.UIRoot.WidgetSwitcher_0:SetWidgetVisibility(ESlateVisibility.Collapsed)
  else
    self.UIRoot.WidgetSwitcher_0:SetWidgetVisibility(ESlateVisibility.Visible)
    self.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(buttonStatus)
    if buttonStatus == ENUM_STATUEBUTTON.CANTUSE then
    elseif buttonStatus == ENUM_STATUEBUTTON.REFIT then
      local costList = selectWeaponData.refitPair and ItemUpgradeMgr:GetRefitMaterialData(selectWeaponData.refitPair[1].groupID) or {}
      if not next(costList) then
        self.UIRoot.TextBlock_RefitButton1:SetWidgetVisibility(ESlateVisibility.Collapsed)
        self.UIRoot.Image_RefitButton1:SetWidgetVisibility(ESlateVisibility.Collapsed)
        self.UIRoot.TextBlock_RefitButton2:SetWidgetVisibility(ESlateVisibility.SelfHitTestInvisible)
        self.UIRoot.Image_RefitButton2:SetWidgetVisibility(ESlateVisibility.SelfHitTestInvisible)
        self.UIRoot.Button_Refit:SetIsEnabled(false)
      else
        self.UIRoot.TextBlock_RefitButton1:SetWidgetVisibility(ESlateVisibility.SelfHitTestInvisible)
        self.UIRoot.Image_RefitButton1:SetWidgetVisibility(ESlateVisibility.SelfHitTestInvisible)
        self.UIRoot.TextBlock_RefitButton2:SetWidgetVisibility(ESlateVisibility.Collapsed)
        self.UIRoot.Image_RefitButton2:SetWidgetVisibility(ESlateVisibility.Collapsed)
        self.UIRoot.Button_Refit:SetIsEnabled(true)
      end
    end
  end
  if buttonStatus == ENUM_STATUEBUTTON.NONE or buttonStatus == ENUM_STATUEBUTTON.GOGET or buttonStatus == ENUM_STATUEBUTTON.USE or buttonStatus == ENUM_STATUEBUTTON.CANTUSE then
    self:HideMaterialWidget()
    return
  end
  local ItemUpgradeMaterialHelper = require("client.logic.ItemUpgrade.ItemUpgradeMaterialHelper")
  if buttonStatus == ENUM_STATUEBUTTON.UPGRADE or buttonStatus == ENUM_STATUEBUTTON.LOCK then
    ItemUpgradeMaterialHelper.ConstructUpgradeMaterialList(curSelectEffect.resID)
  elseif buttonStatus == ENUM_STATUEBUTTON.REFIT and selectWeaponData.refitPair then
    ItemUpgradeMaterialHelper.ConstructRefitMaterialList(selectWeaponData.refitPair[2].groupID)
  end
  self:RefreshMaterial()
  local tItemData = wardrobe_data:GetHallDepotItemDataByResIDAndTimeliness(self.CurSelectWeaponID, false)
  if tItemData and tItemData.lock_cnt and tItemData.lock_cnt > 0 then
    local LogicCardCollectionGun = require("client.slua.logic.card_collection.LogicCardCollectionGun")
    if not LogicCardCollectionGun.IsCardCollectionGun(selectWeaponData.groupID) then
      self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_0, false)
    end
  end
  self.bIsHideLimitTimeMaterialAct = false
end

function UI_Item_Upgrade:RefreshMaterial()
  local curItemEffectLevel = self:GetCurItemEffectLevel()
  local selectEffectIndex = self.ExtendedLoopScrollBox_Effect:GetSelectIndex()
  local bSelectEffectCanDirectUnlock = curItemEffectLevel + 1 == selectEffectIndex
  log(bWriteLog and string.format("UI_Item_Upgrade:RefreshMaterial curItemEffectLevel : %s, selectIndex : %s, bUnlock : %s", curItemEffectLevel, selectEffectIndex, bSelectEffectCanDirectUnlock))
  local ItemUpgradeMaterialHelper = require("client.logic.ItemUpgrade.ItemUpgradeMaterialHelper")
  local MaterialList = ItemUpgradeMaterialHelper.GetMaterialList()
  local FragmentList = ItemUpgradeMaterialHelper.GetFragmentList()
  if not self.MaterialComp then
    self.MaterialComp = self:CreateChildWindow(self.UIRoot.CanvasPanel_30, UIManager.UI_Config.item_upgrade_material_component2, 1, MaterialList, FragmentList)
  else
    self.MaterialComp:SetMaterialData(MaterialList, FragmentList)
  end
  self.MaterialComp:SetWidgetVisibility(true)
end

function UI_Item_Upgrade:RefreshMaterialDiscountShow()
  if not self.UIRoot.HorizontalBox_LimitedDesc then
    return
  end
  log(bWriteLog and "UI_Item_Upgrade:RefreshMaterialDiscountShow ")
  self:SetWidgetVisible(self.UIRoot.HorizontalBox_LimitedDesc, false)
  if self.bIsHideLimitTimeMaterialAct then
    return
  end
  local TimeUtil = require("client.common.time_util")
  local tCurSelectEffect = self:GetCurSelectEffectData()
  if not tCurSelectEffect then
    return
  end
  local ItemUpgradeMaterialHelper = require("client.logic.ItemUpgrade.ItemUpgradeMaterialHelper")
  local bIsShowDisCountDownTime = ItemUpgradeMaterialHelper.CanShowDiscount()
  local _, sDisEndTime = self:GetItemUpgradeMgr():GetUpgradeDiscountTime(tCurSelectEffect.resID)
  if self.uObjCountDownTimer then
    self:RemoveTimer(self.uObjCountDownTimer)
    self.uObjCountDownTimer = nil
  end
  if bIsShowDisCountDownTime then
    self:SetWidgetVisible(self.UIRoot.HorizontalBox_LimitedDesc, true)
    self.UIRoot.TextBlock_BigAwardName:SetText(LocUtil.GetLocalizeResStr(7000016))
    local sTimeText
    
    local function fUpdateTime(nTime)
      if nTime <= 0 then
        if self.uObjCountDownTimer then
          self:RemoveTimer(self.uObjCountDownTimer)
          self.uObjCountDownTimer = nil
        end
        self:SetWidgetVisible(self.UIRoot.HorizontalBox_LimitedDesc, false)
        self:RefreshEffectBtnStatusAndMatComp()
        return
      end
      sTimeText = TimeUtil.FormatCountDownTime_DHM_or_HMS(nTime)
      self.UIRoot.TextBlock_ActTimeCD:SetText(sTimeText)
    end
    
    local nEndTime = TimeUtil.TimeStringToUnixstamp(sDisEndTime)
    local nCountDownTime = nEndTime - TimeUtil.GetServerTimeInSec()
    fUpdateTime(nCountDownTime)
    self.uObjCountDownTimer = self:AddTimerLoop(1, function()
      nCountDownTime = nEndTime - TimeUtil.GetServerTimeInSec()
      fUpdateTime(nCountDownTime)
    end, TIMER_INFINITE, 1)
  end
end

function UI_Item_Upgrade:UpdateChangeModelBtn()
  log(bWriteLog and "UI_Item_Upgrade:UpdateChangeModelBtn")
  local isShow = self.EffectComponent:NeedShowModelStateButtons()
  self.UIRoot.btnAvator1:SetWidgetVisibility(ESlateVisibility.Hidden)
  self.UIRoot.btnAvator2:SetWidgetVisibility(ESlateVisibility.Hidden)
  self.UIRoot.CanvasPanel_KDP:SetWidgetVisibility(ESlateVisibility.Hidden)
  if isShow then
    local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
    if ModelDisplayer.GetShowingStatus() == ModelDisplayer.Enum_Status.Avatar then
      self.UIRoot.btnAvator1:SetWidgetVisibility(ESlateVisibility.Visible)
    else
      local KeyDesignPointSystem = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.KeyDesignPointSystem)
      local NeedShowKDP = KeyDesignPointSystem:NeedShowKeyDesign(self.EffectComponent:GetCurShowWeaponID())
      if NeedShowKDP and not self.EffectComponent:IsShowingDualForm() then
        self.UIRoot.CanvasPanel_KDP:SetWidgetVisibility(ESlateVisibility.SelfHitTestInvisible)
      end
      self.UIRoot.btnAvator2:SetWidgetVisibility(ESlateVisibility.Visible)
    end
  end
end

function UI_Item_Upgrade:UpdateIntroduceButton()
  self.introduceContent = nil
  local selectWeaponData = self:GetSelectWeaponItemData()
  if not selectWeaponData or not self.UIRoot.CanvasPanel_Introduce then
    log(bWriteLog and "UI_Item_Upgrade:UpdateIntroduceButton not selectWeaponData or not self.UIRoot.CanvasPanel_Introduce")
    return
  end
  local LogicCardCollectionGun = require("client.slua.logic.card_collection.LogicCardCollectionGun")
  if not LogicCardCollectionGun.IsCardCollectionGun(selectWeaponData.groupID) then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Introduce, false)
    log(bWriteLog and "UI_Item_Upgrade:UpdateIntroduceButton not card collection gun")
    return
  end
  local contentConfig = CDataTable.GetTableData("EffectTips", selectWeaponData.resID)
  if not contentConfig then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Introduce, false)
    log(bWriteLog and "UI_Item_Upgrade:UpdateIntroduceButton not contentConfig")
    return
  end
  local gunNameParam = contentConfig.IntroduceGunName
  local gunNameList
  if contentConfig.IntroduceGunName and contentConfig.IntroduceGunName ~= "" then
    local effectTipsRows = CDataTable.GetTableByFilter("EffectTips", "IntroduceGunName", contentConfig.IntroduceGunName)
    if effectTipsRows then
      local gunIdList = {}
      for _, row in pairs(effectTipsRows) do
        if row.GunId then
          table.insert(gunIdList, row.GunId)
        end
      end
      if 0 < #gunIdList then
        gunNameList = CDataTable.GetTableRowFieldsByKeys("Item", gunIdList, {"ItemName"}, true)
      end
    end
  end
  self.introduceContent = LocUtil.LocalizeResFormat(contentConfig.IntroduceText, gunNameParam, gunNameList[1] and gunNameList[1].configs.ItemName, gunNameList[2] and gunNameList[2].configs.ItemName, gunNameList[3] and gunNameList[3].configs.ItemName, contentConfig.EndTime)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Introduce, true)
end

function UI_Item_Upgrade:DoClickWeaponItem(bForfeRefit, forceShapeIndex, forceEffectIndex, bClickSwichTab, forceSubEffectIndex)
  self:UpdateWeaponShapeComp(bForfeRefit, forceShapeIndex)
  self:UpdateEffectList(forceEffectIndex)
  self:AfterClickEffectItem(bClickSwichTab, forceSubEffectIndex)
  self:RefreshName()
  self:RefreshKillCounter()
  self:RequestWeaponCollectInfo()
  self:UpdateIntroduceButton()
end

function UI_Item_Upgrade:AfterClickEffectItem(bClickSwichTab, forceSubEffectIndex)
  self:RefreshSpecialAction()
  self:RefreshEffectBtnStatusAndMatComp()
  self:RefreshMaterialDiscountShow()
  local effectData = self:GetCurSelectEffectData()
  if not self.bottom_parts_ui then
    return
  end
  if not bClickSwichTab then
    local selectWeaponData = self:GetSelectWeaponItemData()
    if selectWeaponData then
      local resId = selectWeaponData.resID
      if selectWeaponData.refitPair then
        local refitPairData = selectWeaponData.refitPair[self.FormIndex]
        local groupID = selectWeaponData.groupID
        if groupID ~= refitPairData.groupID then
          resId = self:GetItemUpgradeMgr():GetRefitItemIDByGroupID(refitPairData.groupID, resId)
        end
      end
      self.bottom_parts_ui:SetFormDiff(#self.FormData > 1)
      self.bottom_parts_ui:UpdateCurWeaponInsId(self:GetCurSelectWeaponInstID())
      self.bottom_parts_ui:RefreshUI(resId, self.ExtendedLoopScrollBox_Effect:GetSelectIndex())
    end
    self.bottom_parts_ui:SetEffectClick(effectData)
  end
  if effectData ~= nil then
    self:CheckPendantListVisibility()
    self:GetEffectInfo(effectData.effectID)
    local subEffectType
    local itemData = self.ExtendedLoopScrollBox_Effect:GetItemData(self.ExtendedLoopScrollBox_Effect:GetSelectIndex())
    if itemData and itemData.subEffects then
      forceSubEffectIndex = forceSubEffectIndex or 1
      local effectTypeStr = "subEffect" .. tostring(forceSubEffectIndex) .. "Type"
      if itemData.subEffects[effectTypeStr] then
        subEffectType = itemData.subEffects[effectTypeStr]
      else
        subEffectType = itemData.subEffects.subEffect1Type
      end
    end
    self.EffectComponent:PlayEffect(effectData.resID, effectData.effectID, subEffectType)
  else
    log(bWriteLog and "[cw] effectCfg == nil ")
  end
  if bClickSwichTab then
    self.bottom_parts_ui:RePutOnAllEquipments()
  end
  if self:GetItemUpgradeMgr():GetIsInPendantEffect() then
    self.bottom_parts_ui:CalculatePendantViewRotation()
  end
  self:CloseAllTips()
end

function UI_Item_Upgrade:RefreshName()
  local itemCfg = CDataTable.GetTableData("Item", self.CurSelectWeaponID)
  if itemCfg then
    self.UIRoot.TextBlock_Shadow:SetText(itemCfg.ItemName)
    self.UIRoot.TextBlock_Name:SetText(itemCfg.ItemName)
    self.UIRoot.TextBlock_Name:SetWidgetVisibility(ESlateVisibility.SelfHitTestInvisible)
    self.UIRoot.TextBlock_0:SetWidgetVisibility(ESlateVisibility.Collapsed)
    local progressTest = LocUtil.LocalizeResFormat(48262, self:GetCurItemEffectLevel(), #self.EffectList)
    self.UIRoot.UTRichTextBlock_Progress:SetText(progressTest)
  end
end

function UI_Item_Upgrade:RequestWeaponCollectInfo()
  self.UIRoot.Store_Collection_Btn:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  local ItemUpgradeMgr = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.ItemUpgradeModule)
  local ItemCfg = ItemUpgradeMgr:GetUpgradeCfg(self.CurSelectWeaponID)
  if not ItemCfg or not ItemCfg.FavourateItemID then
    return
  end
  local itemID = ItemCfg.FavourateItemID
  local store_collect_data = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.store_collect_data)
  if store_collect_data:ExistedCollectData(itemID) then
    self:RefreshCollect()
  else
    local StoreHandler = require("client.network.Protocol.StoreHandler")
    StoreHandler.send_get_global_collect_data_by_itemlist_req({itemID})
  end
end

function UI_Item_Upgrade:RefreshCollect()
  local store_collect_data = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.store_collect_data)
  local ItemUpgradeMgr = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.ItemUpgradeModule)
  local ItemCfg = ItemUpgradeMgr:GetUpgradeCfg(self.CurSelectWeaponID)
  if not ItemCfg or not ItemCfg.FavourateItemID then
    return
  end
  local itemID = ItemCfg.FavourateItemID
  local collectCount = store_collect_data:GetCollectCountByItemID(itemID)
  log(bWriteLog and string.format("UI_Item_Upgrade:RefreshCollect collectCount=%s ", tostring(collectCount)))
  local bCollect = store_collect_data:IsCollectedByItemID(itemID)
  if IsEditor then
    self.UIRoot.Store_Collection_Btn:SetData(bCollect, 0)
    if bCollect then
      self.UIRoot.Store_Collection_Btn.TextBlock_1:SetText(collectCount)
    else
      self.UIRoot.Store_Collection_Btn.TextBlock_0:SetText(collectCount)
    end
  else
    self.UIRoot.Store_Collection_Btn:SetData(bCollect, collectCount)
  end
  self:SetCollectBtnIconColor(FLinearColor(1, 0.46, 0.02, 1))
  self.UIRoot.Store_Collection_Btn:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
end

function UI_Item_Upgrade:SetCollectBtnIconColor(linearColor)
  local collectBtn = self.UIRoot.Store_Collection_Btn
  if not collectBtn then
    return
  end
  local icon = collectBtn.Image_0
  if icon then
    local brush = slua.IndexReference(icon, "Brush"):clone()
    brush.TintColor = FSlateColor(linearColor)
    icon:SetBrush(brush)
    icon:SetColorAndOpacity(FLinearColor(1, 1, 1, 1))
  end
end

function UI_Item_Upgrade:OnClickCollectBtn()
  local ItemUpgradeMgr = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.ItemUpgradeModule)
  local ItemCfg = ItemUpgradeMgr:GetUpgradeCfg(self.CurSelectWeaponID)
  if not ItemCfg or not ItemCfg.FavourateItemID then
    return
  end
  local itemID = ItemCfg.FavourateItemID
  local store_collect_data = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.store_collect_data)
  local store_supply_manager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.store_supply_manager)
  if store_collect_data:IsCollectedByItemID(itemID) then
    store_supply_manager:cancel_market_collect_by_item_req(itemID)
  else
    store_supply_manager:add_market_collect_by_item_req(itemID, StoreConst.market_collect_source_lab)
  end
end

function UI_Item_Upgrade:CloseAllTips()
  if self.MaterialComp then
    self.MaterialComp.ReuseList_Material:RefreshAllItems()
  end
  self.UIRoot.Panel_Mask:SetWidgetVisibility(ESlateVisibility.Collapsed)
end

function UI_Item_Upgrade:OnClickSwitchModel()
  self:CacheRotationInPendant()
  self:PlayAudio(sound_config.click_v1)
  self.EffectComponent:OnSwitchModelStatus()
  self:RecoverPendantWeaponRotation()
end

function UI_Item_Upgrade:IsWeaponModelView()
  return self.UIRoot.btnAvator2:GetVisibility() == UEnums.ESlateVisibility.Visible
end

function UI_Item_Upgrade:OnClickUpgrade()
  self:PlayAudio(sound_config.click_v1)
  if not UIUtil.CanClickNow(UIUtil.ClickFrequencyLimit.UpgradeWeapon) then
    return
  end
  local SelectWeaponID = self:GetItemUpgradeMgr():GetCurrentStateItemID(self.CurSelectWeaponID)
  local cfg = self:GetItemUpgradeMgr():GetUpgradeCfg(SelectWeaponID)
  if not cfg then
    return
  end
  local LogicCardCollectionGun = require("client.slua.logic.card_collection.LogicCardCollectionGun")
  if LogicCardCollectionGun.IsCardCollectionGun(cfg.GroupID) then
    self:CardCollectionUpgradeProcess()
  else
    self:NormalUpgradeProcess(true)
  end
end

function UI_Item_Upgrade:CardCollectionUpgradeProcess()
  local CurItemEffectLevel = self:GetCurItemEffectLevel()
  log(bWriteLog and string.format("UI_Item_Upgrade:OnClickUpgradeDetail. CurItemEffectLevel:%s", tostring(CurItemEffectLevel)))
  if self.ExtendedLoopScrollBox_Effect:GetSelectIndex() ~= CurItemEffectLevel + 1 then
    ShowNotice(6340)
    return
  end
  local SelectWeaponID = self:GetItemUpgradeMgr():GetCurrentStateItemID(self.CurSelectWeaponID)
  local cfg = self:GetItemUpgradeMgr():GetUpgradeCfg(SelectWeaponID)
  if not cfg then
    log(bWriteLog and "UI_Item_Upgrade:OnClickUpgrade cfg = nil")
    return
  end
  local tCurSelectEffect = self:GetCurSelectEffectData()
  local sDisStartTime, sDisEndTime = self:GetItemUpgradeMgr():GetUpgradeDiscountTime(tCurSelectEffect.resID)
  local TimeUtil = require("client.common.time_util")
  local ItemUpgradeMaterialHelper = require("client.logic.ItemUpgrade.ItemUpgradeMaterialHelper")
  local MaterialList = ItemUpgradeMaterialHelper.GetMaterialList()
  local FragmentList = ItemUpgradeMaterialHelper.GetFragmentList()
  if not MaterialList then
    return
  end
  for _, info in pairs(MaterialList) do
    local bIsHasDiscount = false
    if sDisStartTime and sDisEndTime and TimeUtil.UnixTimeBetween(TimeUtil.TimeStringToUnixstamp(sDisStartTime), TimeUtil.TimeStringToUnixstamp(sDisEndTime)) == 0 and info.needCount > info.CostItemDisNum then
      bIsHasDiscount = true
    end
    local nCostNum = info.needCount
    if bIsHasDiscount then
      nCostNum = info.CostItemDisNum
    end
    if nCostNum > info.count then
      ShowNotice(6325)
      return
    end
  end
  local itemInfo = wardrobe_data:GetHallDepotItemDataByResIDAndTimeliness(SelectWeaponID, false)
  itemInfo = itemInfo or wardrobe_data:GetHallDepotItemDataByResIDAndTimeliness(SelectWeaponID, true)
  if not itemInfo then
    log(bWriteLog and "UI_Item_Upgrade:OnClickUpgradeDetail. itemInfo = nil")
    return
  end
  local paramsTb = {}
  for _, info in pairs(MaterialList) do
    local itemCfg = CDataTable.GetTableData("Item", info.resID)
    if itemCfg then
      table.insert(paramsTb, itemCfg.ItemName)
    end
    local num = info.needCount
    if 0 < info.CostItemDisNum and info.needCount > info.CostItemDisNum and TimeUtil.UnixTimeBetween(TimeUtil.TimeStringToUnixstamp(sDisStartTime), TimeUtil.TimeStringToUnixstamp(sDisEndTime)) == 0 then
      num = info.CostItemDisNum
    end
    table.insert(paramsTb, num)
  end
  local locId = 7000029
  if #MaterialList == 1 then
    locId = 7000033
  end
  local Content = LocUtil.LocalizeResFormat(locId, table.unpack(paramsTb))
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_FOUR, LocUtil.GetLocalizeResStr(101001), Content, function()
    if not self.UIRoot then
      return
    end
    self:GetItemUpgradeMgr():upgrade_item_req(itemInfo.insID or 0, cfg.GroupID, CurItemEffectLevel + 1, nil, nil)
  end)
end

local FORM_ID_A = 1
local FORM_ID_B = 2
local _g_LocalCacheFormUnlockPlayed = _g_LocalCacheFormUnlockPlayed or {}

function UI_Item_Upgrade:_IsFormUnlockPlayedLocal(groupID)
  if not groupID then
    return false
  end
  return _g_LocalCacheFormUnlockPlayed[groupID] == true
end

function UI_Item_Upgrade:_SetFormUnlockPlayedLocal(groupID)
  if not groupID then
    return
  end
  _g_LocalCacheFormUnlockPlayed[groupID] = true
end

function UI_Item_Upgrade:_TryPlayFormUnlockOnUpgradeRsp(instid, groupID, newLevel)
  if not (instid and groupID) or not newLevel then
    return
  end
  local ItemUpgradeMgr = self:GetItemUpgradeMgr()
  if not ItemUpgradeMgr:IsReachFullUnlockLevel(groupID, newLevel) then
    return
  end
  if self:_IsFormUnlockPlayedLocal(groupID) then
    return
  end
  self:_SetFormUnlockPlayedLocal(groupID)
  local levels = ItemUpgradeMgr:GetDualFormLevels(groupID)
  local formId
  if levels and levels.groupX and tonumber(groupID) == tonumber(levels.groupX) then
    formId = FORM_ID_A
  else
    formId = FORM_ID_B
  end
  log(bWriteLog and string.format("[UI_Item_Upgrade] _TryPlayFormUnlockOnUpgradeRsp: hit unlockAllLevel instid=%s groupID=%s newLevel=%s formId=%s", tostring(instid), tostring(groupID), tostring(newLevel), tostring(formId)))
  local WeaponFormUnlockPlayer = require("client.slua.umg.upgrade.dual_form.WeaponFormUnlockPlayer")
  WeaponFormUnlockPlayer.PlayFormUnlock(instid, formId, nil)
end

function UI_Item_Upgrade:_HandleDualFormRefitRsp(instid, res_id)
  if not instid or not res_id then
    return
  end
  local selectData = self:GetSelectWeaponItemData()
  if not selectData or not selectData.refitPair then
    return
  end
  local refitPair = selectData.refitPair
  local groupA = refitPair[1] and refitPair[1].groupID
  local groupB = refitPair[2] and refitPair[2].groupID
  local ItemUpgradeMgr = self:GetItemUpgradeMgr()
  local itemIdA = groupA and ItemUpgradeMgr:GetObtainedMaxLevelItemByGroupID(groupA)
  local itemIdB = groupB and ItemUpgradeMgr:GetObtainedMaxLevelItemByGroupID(groupB)
  if tostring(res_id) ~= tostring(itemIdA) and tostring(res_id) ~= tostring(itemIdB) then
    return
  end
  if self.FormList then
    self.FormList:SetData(self.FormData)
    if self.FormIndex then
      self.FormList:Select(self.FormIndex)
    end
  end
  if self.bottom_parts_ui and self.FormIndex and self.FormData then
    self.bottom_parts_ui:SetInDiffForm(self.FormIndex ~= 1, self.FormData[self.FormIndex] and self.FormData[self.FormIndex].groupID)
  end
  self:AddTimer(0.1, function()
    if not self.UIRoot then
      return
    end
    self.NeedPlayRefreshShapeEffectAnim = true
    if self.ExtendedLoopScrollBox_Effect then
      self.ExtendedLoopScrollBox_Effect:RefreshAllItems()
    end
    self:AddTimer(0.1, function()
      self.NeedPlayRefreshShapeEffectAnim = false
    end)
  end)
  log(bWriteLog and string.format("[UI_Item_Upgrade] _HandleDualFormRefitRsp: ActiveForm refresh done instid=%s res_id=%s FormIndex=%s", tostring(instid), tostring(res_id), tostring(self.FormIndex)))
end

function UI_Item_Upgrade:_IsAtForkLevel()
  if not self.CurSelectWeaponID then
    return false
  end
  local selectData = self:GetSelectWeaponItemData()
  if not selectData then
    return false
  end
  local refitPair = selectData.refitPair
  if not refitPair then
    return false
  end
  local groupA = refitPair[1] and refitPair[1].groupID
  if not groupA then
    return false
  end
  local ItemUpgradeMgr = self:GetItemUpgradeMgr()
  if not ItemUpgradeMgr:IsDualFormGroup(groupA) then
    return false
  end
  local levels = ItemUpgradeMgr:GetDualFormLevels(groupA)
  if not levels then
    return false
  end
  local curLevel = math.max(levels.lvX or 0, levels.lvY or 0)
  return ItemUpgradeMgr:IsAtForkLevel(groupA, curLevel)
end

function UI_Item_Upgrade:_ShowDualFormChoiceDialog(instid, itemId)
  local selectData = self:GetSelectWeaponItemData()
  if not selectData then
    return
  end
  local refitPair = selectData.refitPair
  if not refitPair then
    return
  end
  local defaultFocus = self.FormIndex == 2 and "B" or "A"
  local groupA = refitPair[1] and refitPair[1].groupID
  local groupB = refitPair[2] and refitPair[2].groupID
  local ItemUpgradeMgr = self:GetItemUpgradeMgr()
  local levels = ItemUpgradeMgr:GetDualFormLevels(groupA)
  local curLevel = levels and math.max(levels.lvX or 0, levels.lvY or 0) or 0
  local cfgA = ItemUpgradeMgr:GetConfigByGroupIDAndLevel(groupA, curLevel)
  local cfgB = ItemUpgradeMgr:GetConfigByGroupIDAndLevel(groupB, curLevel)
  local locItemNameA = cfgA and Logic_DetailUtils.GetItemName(cfgA.ItemID + 1) or ""
  local locItemNameB = cfgB and Logic_DetailUtils.GetItemName(cfgB.ItemID + 1) or ""
  local tParams = {
    itemId = itemId,
    instid = instid,
    formA = {
      id = FORM_ID_A,
      locItemName = locItemNameA,
      groupID = groupA
    },
    formB = {
      id = FORM_ID_B,
      locItemName = locItemNameB,
      groupID = groupB
    },
    defaultFocus = defaultFocus,
    effectComponent = self.EffectComponent
  }
  
  local function fOnConfirm(selectedFormId)
    local targetGroupID = selectedFormId == FORM_ID_B and groupB or groupA
    self:_OnFirstChosenFormConfirm(instid, selectedFormId, targetGroupID)
  end
  
  self:OnShowOrHideUpgradeUI(nil, nil, false)
  UIManager.ShowUI(UIManager.UI_Config.ItemUpgrade_Get_UIBP3, tParams, fOnConfirm)
end

function UI_Item_Upgrade:_OnFirstChosenFormConfirm(instid, selectedFormId, targetGroupID)
  if not (instid and selectedFormId) or not targetGroupID then
    log(bWriteLog and string.format("[UI_Item_Upgrade] _OnFirstChosenFormConfirm invalid args instid=%s selectedFormId=%s targetGroupID=%s", tostring(instid), tostring(selectedFormId), tostring(targetGroupID)))
    return
  end
  local ItemUpgradeMgr = self:GetItemUpgradeMgr()
  local levels = ItemUpgradeMgr:GetDualFormLevels(targetGroupID)
  if not levels then
    log(bWriteLog and string.format("[UI_Item_Upgrade] _OnFirstChosenFormConfirm GetDualFormLevels nil targetGroupID=%s", tostring(targetGroupID)))
    return
  end
  local targetLevel = math.max(levels.lvX or 0, levels.lvY or 0) + 1
  log(bWriteLog and string.format("[UI_Item_Upgrade] _OnFirstChosenFormConfirm send upgrade_item_req with form_choice instid=%s targetGroupID=%s targetLevel=%s selectedFormId=%s", tostring(instid), tostring(targetGroupID), tostring(targetLevel), tostring(selectedFormId)))
  self._pendingFirstChosenFormRefresh = true
  ItemUpgradeMgr:upgrade_item_req(instid, targetGroupID, targetLevel, nil, targetGroupID)
end

function UI_Item_Upgrade:NormalUpgradeProcess(bNeedConfirm)
  local CurItemEffectLevel = self:GetCurItemEffectLevel()
  log(bWriteLog and string.format("UI_Item_Upgrade:OnClickUpgradeDetail. CurItemEffectLevel:%s", tostring(CurItemEffectLevel)))
  if self.ExtendedLoopScrollBox_Effect:GetSelectIndex() ~= CurItemEffectLevel + 1 then
    ShowNotice(6340)
    return
  end
  local ItemUpgradeMgr = self:GetItemUpgradeMgr()
  local SelectWeaponID = ItemUpgradeMgr:GetCurrentStateItemID(self.CurSelectWeaponID)
  local cfg = ItemUpgradeMgr:GetUpgradeCfg(SelectWeaponID)
  if not cfg then
    log(bWriteLog and "UI_Item_Upgrade:OnClickUpgrade cfg = nil")
    return
  end
  local tCurSelectEffect = self:GetCurSelectEffectData()
  local sDisStartTime, sDisEndTime = ItemUpgradeMgr:GetUpgradeDiscountTime(tCurSelectEffect.resID)
  local TimeUtil = require("client.common.time_util")
  local ItemUpgradeMaterialHelper = require("client.logic.ItemUpgrade.ItemUpgradeMaterialHelper")
  local MaterialList = ItemUpgradeMaterialHelper.GetMaterialList()
  local FragmentList = ItemUpgradeMaterialHelper.GetFragmentList()
  if not MaterialList then
    return
  end
  self.MaterialFragmentComposeList = {}
  for _, info in pairs(MaterialList) do
    local bIsHasDiscount = false
    if sDisStartTime and sDisEndTime and TimeUtil.UnixTimeBetween(TimeUtil.TimeStringToUnixstamp(sDisStartTime), TimeUtil.TimeStringToUnixstamp(sDisEndTime)) == 0 and info.needCount > info.CostItemDisNum then
      bIsHasDiscount = true
    end
    local nCostNum = info.needCount
    if bIsHasDiscount then
      nCostNum = info.CostItemDisNum
    end
    if nCostNum > info.count then
      local HasFragment = ItemUpgradeMgr:HasFragment(tostring(info.resID))
      local fragData = FragmentList[tostring(info.resID)]
      local diffCount = nCostNum - info.count
      local bCanReplenish = fragData and diffCount <= fragData.count // fragData.perCostNum or false
      if HasFragment and bCanReplenish then
        table.insert(self.MaterialFragmentComposeList, {
          resID = fragData.resID,
          insID = fragData.insID,
          composeNum = diffCount,
          costNum = fragData.perCostNum * diffCount,
          gotItemID = fragData.composeItemID,
          IsCompose = fragData.IsCompose
        })
      else
        ShowNotice(6325)
        self.MaterialFragmentComposeList = {}
        return
      end
    end
  end
  if #self.MaterialFragmentComposeList > 0 then
    self:ComposeFragment()
    return
  end
  local itemInfo = wardrobe_data:GetHallDepotItemDataByResIDAndTimeliness(SelectWeaponID, false)
  if not itemInfo then
    local pairID = ItemUpgradeMgr:GetPairFormItemID(SelectWeaponID)
    if pairID then
      itemInfo = wardrobe_data:GetHallDepotItemDataByResIDAndTimeliness(pairID, false)
      SelectWeaponID = pairID
    end
  end
  log(bWriteLog and "[ljw] ItemResID " .. tostring(SelectWeaponID))
  if not itemInfo then
    log(bWriteLog and "UI_Item_Upgrade:OnClickUpgradeDetail. itemInfo = nil")
    return
  end
  if self:_IsAtForkLevel() then
    self:_ShowDualFormChoiceDialog(itemInfo.insID or 0, SelectWeaponID)
    return
  end
  if not bNeedConfirm then
    log(bWriteLog and "UI_Item_Upgrade:OnClickUpgradeDetail. bNeedConfirm = false, direct upgrade")
    ItemUpgradeMgr:upgrade_item_req(itemInfo.insID or 0, cfg.GroupID, CurItemEffectLevel + 1, nil, nil)
    return
  end
  local paramsTb = {}
  for _, info in pairs(MaterialList) do
    local itemCfg = CDataTable.GetTableData("Item", info.resID)
    if itemCfg then
      table.insert(paramsTb, itemCfg.ItemName)
    end
    local num = info.needCount
    if 0 < info.CostItemDisNum and info.needCount > info.CostItemDisNum and TimeUtil.UnixTimeBetween(TimeUtil.TimeStringToUnixstamp(sDisStartTime), TimeUtil.TimeStringToUnixstamp(sDisEndTime)) == 0 then
      num = info.CostItemDisNum
    end
    table.insert(paramsTb, num)
  end
  local locId = 7000029
  if #MaterialList == 1 then
    locId = 7000033
  end
  local Content = LocUtil.LocalizeResFormat(locId, table.unpack(paramsTb))
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_FOUR, LocUtil.GetLocalizeResStr(101001), Content, function()
    if not self.UIRoot then
      return
    end
    self:GetItemUpgradeMgr():upgrade_item_req(itemInfo.insID or 0, cfg.GroupID, CurItemEffectLevel + 1, nil, nil)
  end)
end

function UI_Item_Upgrade:ComposeFragment()
  if #self.MaterialFragmentComposeList > 0 then
    local composeInfo = table.remove(self.MaterialFragmentComposeList, 1)
    
    local function confirmFunc()
      self.AutoComposeAndUpgrade = true
      if composeInfo.IsCompose then
        local WardRobeHandler = require("client.network.Protocol.WardRobeHandler")
        WardRobeHandler.send_on_item_compose(tonumber(composeInfo.insID), composeInfo.composeNum)
      else
        local LogicVehicleDecalExchange = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicVehicleDecalExchange)
        LogicVehicleDecalExchange:ReqDecalExchange(composeInfo.gotItemID, composeInfo.composeNum, {
          [tonumber(composeInfo.insID)] = composeInfo.costNum
        })
      end
    end
    
    local function refuseFunc()
      self.AutoComposeAndUpgrade = false
      self.MaterialFragmentComposeList = {}
    end
    
    local itemCfg = CDataTable.GetTableData("Item", composeInfo.resID)
    local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
    local msgContent = LocUtil.LocalizeResFormat(64352, itemCfg.ItemName, math.floor(composeInfo.costNum))
    CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_FOUR, LocUtil.GetLocalizeResStr(5077), msgContent, confirmFunc, refuseFunc, nil, nil, {clickCloseCallback = refuseFunc})
  end
end

function UI_Item_Upgrade:OnComposeResponse(_, __)
  self:RefreshEffectBtnStatusAndMatComp()
end

function UI_Item_Upgrade:OnItemGetDone(_, __)
  if not self.AutoComposeAndUpgrade then
    return
  end
  self:RefreshEffectBtnStatusAndMatComp()
  local autoComposeLength = #self.MaterialFragmentComposeList
  if 0 < autoComposeLength then
    self:ComposeFragment()
  else
    self.AutoComposeAndUpgrade = false
    self:NormalUpgradeProcess(false)
  end
end

function UI_Item_Upgrade:OnClickGo()
  self:PlayAudio(sound_config.click_v1)
  local CurLv1Item = self:GetItemUpgradeMgr():GetLevel1ItemID(self.CurSelectWeaponID)
  local itemUpgradeJumpConfig = self:GetItemUpgradeMgr():GetItemSourceJumpConfig(CurLv1Item)
  if itemUpgradeJumpConfig == nil then
    ShowNotice(6430)
    return
  end
  local jumpStr = itemUpgradeJumpConfig.JumpType or ""
  if jumpStr ~= "" then
    local StringUtil = require("common.string_util")
    local jumpTypeList = StringUtil.Split(jumpStr, "|")
    for i, jType in ipairs(jumpTypeList) do
      local nJumpID = tonumber(jType)
      if GlobalData.CheckCanJumpByTypeID(self.CurSelectWeaponID, nJumpID) then
        GlobalData.JumpByTypeID(self.CurSelectWeaponID, nJumpID, BP_ENUM_MODULE_ITEM_UPGRADE)
        return
      end
    end
  end
  ShowNotice(6430)
end

function UI_Item_Upgrade:CheckPendantListVisibility()
  if not self.bottom_parts_ui then
    return
  end
  local effectData = self:GetCurSelectEffectData()
  
  local function CheckSubFeature(effectData)
    if effectData and effectData.subEffects and (effectData.subEffects.subEffect1Type == self:GetItemUpgradeMgr().ENUM_MaxWeaponSubEffectType.WeaponPendant and self.SelectedSubIndex == 1 or effectData.subEffects.subEffect2Type == self:GetItemUpgradeMgr().ENUM_MaxWeaponSubEffectType.WeaponPendant and self.SelectedSubIndex == 2 or effectData.subEffects.subEffect3Type == self:GetItemUpgradeMgr().ENUM_MaxWeaponSubEffectType.WeaponPendant and self.SelectedSubIndex == 3 or effectData.subEffects.subEffect4Type == self:GetItemUpgradeMgr().ENUM_MaxWeaponSubEffectType.WeaponPendant and self.SelectedSubIndex == 4) then
      self:GetItemUpgradeMgr():SetIsInPendantEffect(true)
      return true
    end
    self:GetItemUpgradeMgr():SetIsInPendantEffect(false)
    return false
  end
  
  if not CheckSubFeature(effectData) then
    self.bottom_parts_ui:DontSwitchIn(1)
  else
    local effectData = self.ExtendedLoopScrollBox_Effect:GetItemData(self.ExtendedLoopScrollBox_Effect:GetSelectIndex())
    if effectData and effectData.resID then
      self.bottom_parts_ui:SwitchIn(1, effectData.resID)
    end
  end
end

function UI_Item_Upgrade:CheckPartBottomVisibility(subEffectType)
  local effectData = self:GetCurSelectEffectData()
  if self.bottom_parts_ui then
    local bShowPartBottom = self.bottom_parts_ui:CanShowPartBottom(effectData, subEffectType)
    self.bottom_parts_ui:SetBottomVisible(bShowPartBottom)
  end
end

function UI_Item_Upgrade:_HandleDualFormOnUpgradeRsp(ItemUpgradeModule, ResID)
  local groupID = ItemUpgradeModule:GetGroupID(ResID)
  if not groupID or not ItemUpgradeModule:IsDualFormGroup(groupID) then
    return
  end
  local effectData = self:GetCurSelectEffectData()
  if not effectData or not effectData.resID then
    return
  end
  local effectResID = effectData.resID
  local effectGroupID = ItemUpgradeModule:GetGroupID(effectResID)
  local targetGroupID = groupID
  local bForceRefresh = false
  if ItemUpgradeModule:IsItemExactlyOnFullUnlockLevel(ResID) then
    bForceRefresh = true
    targetGroupID = ItemUpgradeModule:GetPairGroup(groupID)
    if targetGroupID ~= effectGroupID then
      self.CurSelectWeaponID = ItemUpgradeModule:GetPairFormItemID(effectResID)
    end
  end
  if effectGroupID ~= targetGroupID or bForceRefresh then
    self:OnClickFormItem(self.UIRoot, self:FindDualFormProperShapeSelectIndex(targetGroupID))
    log(bWriteLog and string.format("UI_Item_Upgrade:OnUpgradeRspCallBack Replace,  groupID=%s, effectGroupID=%s, NewResID=%s", groupID, effectGroupID, ResID))
  end
end

function UI_Item_Upgrade:OnUpgradeRspCallBack(eventType, eventID, ret)
  local ItemUpgradeModule = self:GetItemUpgradeMgr()
  if ret ~= nil then
    local instID = 0
    if type(ret) == "table" then
      instID = ret[1] or 0
    else
      instID = ret
    end
    local item = wardrobe_data:GetHallDepotItemDataByInsID(instID)
    if item ~= nil then
      log(bWriteLog and string.format("UI_Item_Upgrade:OnUpgradeRspCallBack item resID=%s", tostring(item.resID)))
      local ResID = ItemUpgradeModule:GetBaseItemID(item.resID)
      local oldInstID = type(ret) == "table" and ret[2] or nil
      local selectedWeaponIndex = self.ScrollBoxWeapon and self.ScrollBoxWeapon:GetSelectIndex()
      local selectedWeaponData = selectedWeaponIndex and ItemList[selectedWeaponIndex]
      local selectedWeaponInstID = selectedWeaponData and selectedWeaponData.instID
      if oldInstID then
        self:UpdateUpgradeWeaponInstID(oldInstID, instID, ResID)
      end
      self.tPageItemList = nil
      local bCanRefreshSelectedWeapon = selectedWeaponData ~= nil and (not oldInstID or tostring(selectedWeaponInstID) == tostring(oldInstID))
      if bCanRefreshSelectedWeapon then
        self.CurSelectWeaponID = ResID
        self:_HandleDualFormOnUpgradeRsp(ItemUpgradeModule, ResID)
        self.UpgradeEffectIndex = self:GetEffectIndexByResID(self.CurSelectWeaponID)
        self:CheckPlayUpgradeEffect()
        if not oldInstID then
          selectedWeaponData.instID = instID
          selectedWeaponData.resID = ResID
          local selectData = self.ScrollBoxWeapon:GetItemData(selectedWeaponIndex)
          if selectData then
            selectData.instID = instID
            selectData.resID = ResID
          end
        end
        self.ScrollBoxWeapon:RefreshItem(selectedWeaponIndex)
        self.FormList:RefreshAllItems()
        self.ExtendedLoopScrollBox_Effect:RefreshAllItems()
        self.bottom_parts_ui:UpdateCurWeaponInsId(instID)
        self.bottom_parts_ui:RefreshUI(self.CurSelectWeaponID, self.ExtendedLoopScrollBox_Effect:GetSelectIndex())
        self:RefreshEffectBtnStatusAndMatComp()
        self:RefreshMaterialDiscountShow()
        self:RefreshName()
        self:RefreshKillCounter()
        self.UpgradeEffectIndex = -1
        self:CheckPendantListVisibility()
        if self.AudioItem then
          self.AudioItem:UpdateDepotItem(self.CurSelectWeaponID, instID)
        end
      end
    else
      log(bWriteLog and "UI_Item_Upgrade:OnUpgradeRspCallBack. has no wardrobe data")
    end
    if self._pendingFirstChosenFormRefresh then
      self._pendingFirstChosenFormRefresh = false
      if self.EffectComponent then
        local effectData = self:GetCurSelectEffectData()
        if effectData then
          self.EffectComponent:PlayEffect(effectData.resID, effectData.effectID)
        end
      end
    end
    local SettingAccount = require("client.logic.setting.logic_setting_account")
    SettingAccount.ShowNotSafe(BP_ENUM_SWITCH_ACCOUNT_SAFE_TIP_UP_GUN)
  end
end

function UI_Item_Upgrade:OnRefitRspCallBack(eventID, eventType, error_code, instid, res_id)
  log(bWriteLog and "[bgp] OnRefitRspCallBack->error_code:" .. tostring(error_code))
  log(bWriteLog and "[bgp] OnRefitRspCallBack->instid:" .. tostring(instid))
  log(bWriteLog and "[bgp] OnRefitRspCallBack->res_id:" .. tostring(res_id))
  if not instid or not res_id then
    ShowNotice(error_code)
    return
  end
  self.tPageItemList = nil
  local selectedIndex = self.ScrollBoxWeapon:GetSelectIndex()
  local groupID = self:GetItemUpgradeMgr():GetRefitGroupID(res_id)
  ItemList[selectedIndex].instID = instid
  ItemList[selectedIndex].resID = res_id
  ItemList[selectedIndex].groupID = groupID
  local selectData = self.ScrollBoxWeapon:GetItemData(selectedIndex)
  if selectData then
    selectData.instID = instid
    selectData.resID = res_id
    selectData.groupID = groupID
  end
  self.ScrollBoxWeapon:RefreshItem(selectedIndex)
  self:AddTimer(0.1, function()
    self.ExtendedLoopScrollBox_Effect:RefreshAllItems()
    self:RefreshEffectBtnStatusAndMatComp()
    if self.bottom_parts_ui then
      self.bottom_parts_ui:UpdateCurWeaponInsId(instid)
    end
  end)
  self:_HandleDualFormRefitRsp(instid, res_id)
end

function UI_Item_Upgrade:ReplayCurrentEffect()
  local effectData = self:GetCurSelectEffectData()
  if not effectData then
    return
  end
  local subEffectType
  local itemData = self.ExtendedLoopScrollBox_Effect:GetItemData(self.ExtendedLoopScrollBox_Effect:GetSelectIndex())
  if itemData and itemData.subEffects then
    local SubIndex = self.SelectedSubIndex or 1
    local effectTypeStr = "subEffect" .. tostring(SubIndex) .. "Type"
    if itemData.subEffects[effectTypeStr] then
      subEffectType = itemData.subEffects[effectTypeStr]
    else
      subEffectType = itemData.subEffects.subEffect1Type
    end
  end
  self.EffectComponent:PlayEffect(effectData.resID, effectData.effectID, subEffectType)
end

function UI_Item_Upgrade:OnUpdateExplainText(_, __, bShow, text)
  self:UpdateExplainText(bShow, text)
end

function UI_Item_Upgrade:UpdateExplainText(bShow, text)
  if not (self.UIRoot and self.UIRoot.CanvasPanel_Explain) or not self.UIRoot.Text_Explain then
    return
  end
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Explain, bShow)
  self.UIRoot.Text_Explain:SetText(text or "")
end

function UI_Item_Upgrade:UpdateAudioItem(WeaponID, AudioType)
  self:UpdateExplainText(false)
  self.CurrentAudioWeaponID = WeaponID
  self.CurrentAudioType = AudioType
  if not self.AudioItem then
    return
  end
  if self.bottom_parts_ui and self.bottom_parts_ui:IsAccessorySkinPartListVisible() then
    self.AudioItem:CloseSettingPanel()
    self.AudioItem:SetWidgetVisibility(ESlateVisibility.Collapsed)
    return
  end
  if not AudioType then
    self.AudioItem:SetWidgetVisibility(ESlateVisibility.Collapsed)
    return
  end
  local instid = self:GetCurSelectWeaponInstID()
  self.AudioItem:UpdateUI(WeaponID, AudioType, instid)
  self:AddTimerOnce(0.5, function()
    self:CheckAudioItemNewbieGuide()
  end)
end

function UI_Item_Upgrade:RefreshAudioItemVisibilityForAccessorySkinPartList()
  if not self.AudioItem then
    return
  end
  if self.bottom_parts_ui and self.bottom_parts_ui:IsAccessorySkinPartListVisible() then
    self.AudioItem:CloseSettingPanel()
    self.AudioItem:SetWidgetVisibility(ESlateVisibility.Collapsed)
    return
  end
  if self.CurrentAudioWeaponID and self.CurrentAudioType then
    local instid = self:GetCurSelectWeaponInstID()
    self.AudioItem:UpdateUI(self.CurrentAudioWeaponID, self.CurrentAudioType, instid)
  end
end

function UI_Item_Upgrade:GetCurSelectWeaponInstID()
  if not ItemList or not self.ScrollBoxWeapon then
    return nil
  end
  local SelectIndex = self.ScrollBoxWeapon:GetSelectIndex()
  if ItemList[SelectIndex] then
    return self:GetCurrentWeaponInstID(ItemList[SelectIndex].instID)
  end
  return nil
end

function UI_Item_Upgrade:GetCurrentWeaponInstID(instID)
  local replaceMap = self.UpgradeWeaponInstIDReplaceMap
  while instID and replaceMap and replaceMap[tostring(instID)] do
    instID = replaceMap[tostring(instID)]
  end
  return instID
end

function UI_Item_Upgrade:UpdateUpgradeWeaponInstID(oldInstID, newInstID, resID)
  if not (oldInstID and newInstID) or tostring(oldInstID) == tostring(newInstID) then
    return
  end
  self.UpgradeWeaponInstIDReplaceMap = self.UpgradeWeaponInstIDReplaceMap or {}
  for instID, replaceInstID in pairs(self.UpgradeWeaponInstIDReplaceMap) do
    if tostring(replaceInstID) == tostring(oldInstID) then
      self.UpgradeWeaponInstIDReplaceMap[instID] = newInstID
    end
  end
  self.UpgradeWeaponInstIDReplaceMap[tostring(oldInstID)] = newInstID
  for index, itemData in ipairs(ItemList) do
    if tostring(itemData.instID) == tostring(oldInstID) then
      itemData.instID = newInstID
      itemData.resID = resID
      local scrollItemData = self.ScrollBoxWeapon and self.ScrollBoxWeapon:GetItemData(index)
      if scrollItemData and tostring(scrollItemData.instID) == tostring(oldInstID) then
        scrollItemData.instID = newInstID
        scrollItemData.resID = resID
      end
    end
  end
end

function UI_Item_Upgrade:CheckAudioItemNewbieGuide()
  if self.AudioItem:GetVisibility() == ESlateVisibility.Visible and self.AudioItem:HasSoundPanel() then
    local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
    local SaveData = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eItemUpgradeAudioGuide)
    if not SaveData or SaveData == 0 then
      self:ShowAudioItemNewbieGuide()
    end
  end
end

function UI_Item_Upgrade:ShowAudioItemNewbieGuide()
  log(bWriteLog and "UI_Item_Upgrade:ShowAudioItemNewbieGuide")
  if not self.ExtendedLoopScrollBox_Effect then
    return
  end
  local SelectEffectIndex = self.ExtendedLoopScrollBox_Effect:GetSelectIndex()
  local itemData = self.ExtendedLoopScrollBox_Effect:GetItemData(SelectEffectIndex)
  if itemData and itemData.subEffects then
    EventSystem:postEvent(EVENTTYPE_ITEM_UPGRADE, EVENTID_ITEM_UPGRADE_SKIN_AUDIO_GUIDE, SelectEffectIndex, self.SelectedSubIndex)
  else
    EventSystem:postEvent(EVENTTYPE_ITEM_UPGRADE, EVENTID_ITEM_UPGRADE_SKIN_AUDIO_GUIDE, SelectEffectIndex, -1)
  end
end

function UI_Item_Upgrade:PlayWeaponSkinAudio(AudioType, AudioPart)
  if self.AudioItem then
    return self.AudioItem:PlayWeaponSkinAudio(AudioType, AudioPart)
  end
  return nil
end

function UI_Item_Upgrade:OnShowOrHideUpgradeUI(_, __, show)
  local bIsDevelopment = Client.IsDevelopment()
  printf("UI_Item_Upgrade:OnShowOrHideUpgradeUI. show:%s, traceback:%s", tostring(show), bIsDevelopment and debug.traceback() or "")
  if show then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_3, true)
    self:SetSkipEmoteButtonVisibility(false)
    self:PlayUserWidgetAnimation(self.UIRoot.FadeIn, 0.6, 1, 0, 1.5)
  else
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_3, false)
  end
end

function UI_Item_Upgrade:SetSkipEmoteButtonVisibility(bVisible)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_8, bVisible)
end

function UI_Item_Upgrade:OnKDPUIClose(_, _)
  log(bWriteLog and "UI_Item_Upgrade:OnKDPUIClose")
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_3, true)
  self:PlayUserWidgetAnimation(self.UIRoot.FadeIn, 0, 1, 0, 1)
  self.KeyDesignPointUI = nil
end

function UI_Item_Upgrade:OnReiftUnlockRspCallBack(_, _, refit_info)
  log(bWriteLog and "UI_Item_Upgrade:OnReiftUnlockRspCallBack")
  self.ExtendedLoopScrollBox_Effect:RefreshAllItems()
  self:RefreshEffectBtnStatusAndMatComp()
  self:ShowCommonPanelByUnlock()
end

function UI_Item_Upgrade:ShowCommonPanelByUnlock()
  local arrayItemData = {}
  local itemCfg = CDataTable.GetTableData("Item", self.CurSelectWeaponID)
  table.insert(arrayItemData, {
    res_id = self.CurSelectWeaponID,
    count = 1,
    valid_hours = itemCfg.ValidTimes or 0
  })
  local Logic_CommonItemGet = require("client.slua.logic.common.CommonItemGet.Logic_CommonItemGet")
  Logic_CommonItemGet.ShowPanel_DefaultStyle(arrayItemData, false, false)
end

function UI_Item_Upgrade:CheckPlayUpgradeEffect()
  log(bWriteLog and string.format("UI_Item_Upgrade:CheckPlayUpgradeEffect. self.UpgradeEffectIndex:%s", tostring(self.UpgradeEffectIndex)))
  if self.UpgradeEffectIndex ~= -1 then
    self:SetLevelUpgradeEffectShow(true)
    self:PlayAudio("/Game/WwiseEvent/UI_hall/Play_UI_Upgrade_JieMian.Play_UI_Upgrade_JieMian")
  else
    self:SetLevelUpgradeEffectShow(false)
  end
end

function UI_Item_Upgrade:IsJumpRefitItemID(item_id)
  log(bWriteLog and "[bgp] IsJumpRefitItemID" .. tostring(item_id))
  self:GetItemUpgradeMgr():InitRefitCfgData()
  local cfg = self:GetItemUpgradeMgr():GetUpgradeCfg(item_id) or {}
  if self:GetItemUpgradeMgr().itemRefitInfo[cfg.GroupID or 0] then
    return true
  end
  return false
end

function UI_Item_Upgrade:GetRefitItemIndex(item_id)
  local refitItemIndex_temp = 1
  local GroupID = self:GetItemUpgradeMgr():GetRefitGroupID(self:GetItemUpgradeMgr():GetBaseItemID(item_id))
  self:GetItemUpgradeMgr():InitRefitCfgData()
  if self:GetItemUpgradeMgr().itemRefitInfo[GroupID] then
    local function GetIndex()
      for idx, v in ipairs(ItemList) do
        if v.groupID == GroupID or v.groupID == self:GetItemUpgradeMgr().refitGroupToOriginGroupMap[GroupID] then
          return idx
        end
      end
      return 1
    end
    
    refitItemIndex_temp = GetIndex()
  end
  return refitItemIndex_temp
end

function UI_Item_Upgrade:IsJumpRefitMaterial(item_id)
  local itemCfg = CDataTable.GetTableData("Item", item_id)
  if itemCfg and itemCfg.itemSubType == ENUM_ITEM_SUBTYPE.Automatic_Decomposition and self:GetItemUpgradeMgr():IsRefitMaterialByResID(item_id) then
    return true
  end
  return false
end

function UI_Item_Upgrade:IsWardrobeJump()
  local JumpUtils = require("client.logic.store.jump_utils")
  local chain = JumpUtils.jumpChain
  if chain and 0 < #chain then
    local scene = chain[#chain]
    local from = scene.from or ""
    local extra = scene.fromExtraInfo or ""
    if extra ~= "" and tostring(from) == tostring(BP_ENUM_MODULE_LOBBY) and tostring(extra) == tostring(JumpUtils.Enum_LOBBY_DETAIL.Wardrobe) then
      return true
    end
  end
  return false
end

function UI_Item_Upgrade:GetEffectIndexByResID(resID)
  for index, effect in ipairs(self.EffectList) do
    if effect.resID == resID then
      return index - 1
    end
  end
  return -1
end

function UI_Item_Upgrade:OnMallSystemClose(eventType, eventID, isClickClose)
end

function UI_Item_Upgrade:OnAndroidBack()
  if self.isShowUpgradeEffect == true then
    self:SetLevelUpgradeEffectShow(false)
    return
  end
  self:OnClickSkipMotion()
  self:CloseSelf()
end

function UI_Item_Upgrade:SetLevelUpgradeEffectShow(show)
  self.isShowUpgradeEffect = show
  if show then
    local info = self.EffectList[self.ExtendedLoopScrollBox_Effect:GetSelectIndex()]
    local cfg_info = self:GetEffectInfo(info.effectID)
    local cfg = self:GetItemUpgradeMgr():GetUpgradeCfg(self.CurSelectWeaponID) or {}
    
    local function btnCallBack()
      self:OnClicktLevelUpgradeMask()
    end
    
    UIManager.ShowUI(UIManager.UI_Config.item_upgrade_animation, cfg, self:GetCurItemEffectLevel(), cfg_info, btnCallBack)
  else
    local uiAnim = UIManager.GetUI(UIManager.UI_Config.item_upgrade_animation)
    if uiAnim and uiAnim:IsShow() then
      uiAnim:CloseSelf()
      return
    end
  end
end

function UI_Item_Upgrade:OnClickTips()
  self:PlayAudio(sound_config.click_v1)
  local title = ""
  local content = ""
  for i = 44431, 44439 do
    content = content .. LocUtil.GetLocalizeResStr(i)
  end
  content = content .. "\n" .. LocUtil.GetLocalizeResStr(64086)
  title = LocUtil.GetLocalizeResStr("6956")
  UIManager.ShowUI(UIManager.UI_Config.HelpTip, 0, title, content)
end

function UI_Item_Upgrade:OnClickCloseMaterialTips()
  self:PlayAudio(sound_config.close_v1)
  self:CloseAllTips()
end

function UI_Item_Upgrade:GetWeaponItemListIndexByNonRefitItemID(ItemID)
  local ItemUpgradeMgr = self:GetItemUpgradeMgr()
  
  local function GetItemIDIndex(item_id)
    for i, v in ipairs(ItemList) do
      if ItemUpgradeMgr:GetBaseItemID(v.resID) == ItemUpgradeMgr:GetBaseItemID(item_id) then
        return i
      end
    end
    return 1
  end
  
  local itemIndex_Jump = GetItemIDIndex(ItemID)
  if itemIndex_Jump ~= 1 then
    return itemIndex_Jump
  end
  local itemID = ItemUpgradeMgr:GetRefitItemIdByResID(ItemID)
  if itemID then
    return GetItemIDIndex(itemID)
  end
  return 1
end

function UI_Item_Upgrade:OnClickClose()
  self:PlayAudio(sound_config.close_v1)
  self:CloseSelf()
end

function UI_Item_Upgrade:OnClickButtonIntroduce()
  self:PlayAudio(sound_config.click_v1)
  if not self.introduceContent then
    return
  end
  local title = LocUtil.GetLocalizeResStr(88045)
  UIManager.ShowUI(UIManager.UI_Config.HelpTip, 0, title, self.introduceContent)
end

function UI_Item_Upgrade:OnClicktLevelUpgradeMask()
  self:PlayAudio(sound_config.click_v1)
  self:SetLevelUpgradeEffectShow(false)
end

function UI_Item_Upgrade:HideMaterialWidget()
  self.bIsHideLimitTimeMaterialAct = true
  if self.MaterialComp then
    self.MaterialComp:SetWidgetVisibility(false)
  end
  self.UIRoot.Panel_Mask:SetWidgetVisibility(ESlateVisibility.Collapsed)
end

function UI_Item_Upgrade:IsCanRefit(group_id)
  return self:GetItemUpgradeMgr():IsCanSetRefitCfgTableInfo(group_id)
end

function UI_Item_Upgrade:OnClickSkipMotion()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "[YY]OnClickSkipMotion==========" .. tostring(111111111))
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_3, true)
  self:SetSkipEmoteButtonVisibility(false)
  local isHighlightMoment = self.EffectComponent:IsHighlightMoment()
  if not isHighlightMoment then
    local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
    ModelDisplayer.ClearEmotionEndCallBack()
    ModelDisplayer.ClearEmotionStartCallBack()
  end
end

function UI_Item_Upgrade:OnClickShowDesignPoint()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "UI_Item_Upgrade OnClickShowDesignPoint")
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_3, false)
  local KeyDesignPointSystem = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.KeyDesignPointSystem)
  local NeedShowKDP = KeyDesignPointSystem:NeedShowKeyDesign(self.EffectComponent:GetCurShowWeaponID())
  if not NeedShowKDP then
    return
  end
  self.EffectComponent:InteruptCurEffect()
  self.KeyDesignPointUI = KeyDesignPointSystem:ShowWeaponKDPUIAsChild(self, "CanvasPanelParent", self.EffectComponent:GetCurShowWeaponID())
end

function UI_Item_Upgrade:OnClickButtonRefit()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "UI_Item_Upgrade OnClickButtonRefit")
  local selectWeaponData = self:GetSelectWeaponItemData()
  if not selectWeaponData then
    log(bWriteLog and "UI_Item_Upgrade:RefreshEffectBtnStatusAndMatComp error selectWeaponData nil")
    return
  end
  local baseGroupID = selectWeaponData.refitPair[1].groupID
  local baseItemID = self:GetItemUpgradeMgr():GetObtainedMaxLevelItemByGroupID(baseGroupID)
  local itemData = wardrobe_data:GetHallDepotItemDataByResIDAndTimeliness(baseItemID, false)
  if not itemData then
    ShowNotice(23803)
    return
  end
  local costList = self:GetItemUpgradeMgr():GetRefitMaterialData(baseGroupID)
  if not next(costList) then
    ShowNotice(23804)
    return
  end
  if costList then
    local ItemUpGradeHandler = require("client.network.Protocol.ItemUpGradeHandler")
    ItemUpGradeHandler.send_upgrade_unlock_refit_req(tonumber(itemData.insID), costList)
  end
end

function UI_Item_Upgrade:OnClickButtonUse()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "UI_Item_Upgrade OnClickButtonUse")
  local instID = self:GetCurSelectWeaponInstID()
  if instID == nil then
    log(bWriteLog and "UI_Item_Upgrade OnClickButtonUse error instance id nil")
    return
  end
  local ItemUpGradeHandler = require("client.network.Protocol.ItemUpGradeHandler")
  ItemUpGradeHandler.send_upgrade_refit_req(tonumber(instID))
end

function UI_Item_Upgrade:OnClickButtonCantUse()
  self:PlayAudio(sound_config.click_v1)
  ShowNotice(7000059)
end

function UI_Item_Upgrade:GetRefitItemID(group_id, res_id)
  local itemID = self:GetItemUpgradeMgr():ChangeItemIDByRefitGroupID(group_id)
  local resID = itemID or res_id
  return wardrobe_data:GetHallDepotItemDataByResIDAndTimeliness(resID, false)
end

function UI_Item_Upgrade:OnClose()
  local logic_setting_graphics = require("client.slua.logic.setting.logic_setting_graphics")
  logic_setting_graphics.ExitEnhancedLobbyQuality()
  self:GetItemUpgradeMgr():SetIsInPendantEffect(false)
  FirstRefreshTab = true
  self.UpgradeWeaponInstIDReplaceMap = nil
  if self.bottom_parts_ui then
    self.bottom_parts_ui:Close()
    self.bottom_parts_ui = nil
  end
  if self.MaterialComp then
    self.MaterialComp:Close()
    self.MaterialComp = nil
  end
  if self.uObjCountDownTimer then
    self:RemoveTimer(self.uObjCountDownTimer)
    self.uObjCountDownTimer = nil
  end
  if self._downloadPollTimers then
    for k, v in pairs(self._downloadPollTimers) do
      if v then
        self:RemoveTimer(v)
      end
      self._downloadPollTimers[k] = nil
    end
    self._downloadPollTimers = {}
  end
  self.ItemUpgradeMgr = nil
  self.EffectComponent:Destroy()
  local EffectHelper = require("GameLua.Mod.Library.GamePlay.Avatar.Component.EffectProc.EffectHelper")
  EffectHelper.SetBlockLobbyUserTriggerFirstAutoApply(false)
  UIManager.ShowUI(UIManager.UI_Config.FADE_UIBP)
  EventSystem:postEvent(EVENT_BLACK, EVENT_BLACK_GRADIENT)
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  ModelDisplayer.Destroy()
  local ItemUpgradeMaterialHelper = require("client.logic.ItemUpgrade.ItemUpgradeMaterialHelper")
  ItemUpgradeMaterialHelper.DestroyData()
  local logic_weapon_pendant = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_weapon_pendant)
  logic_weapon_pendant:ProcessInvalidPendant()
  local avatarWeaponResID = DataMgr.Weapon_Skin_ResID
  if avatarWeaponResID and logic_weapon_pendant:CanSkinWithPendant(avatarWeaponResID) then
    log(bWriteLog and "[itemUpgrade] Close the lab, notify the lobby avatar to update weapon pendant, CurWeaponID : " .. tostring(avatarWeaponResID))
    local groupId = self:GetItemUpgradeMgr():GetRefitGroupID(avatarWeaponResID)
    if groupId then
      log(bWriteLog and string.format("[itemUpgrade] Close Notify LobbyAvatar Update Pendant uid : %s groupId : %s", tostring(DataMgr.roleData.uid), tostring(groupId)))
      EventSystem:postEvent(EVENTTYPE_WEAPON_PENDANT, EVENTID_WEAPON_PENDANT_DATA_UPDATE, DataMgr.roleData.uid, groupId)
    end
  end
  local LogicLastKillEffecs = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicLastKillEffecs)
  LogicLastKillEffecs:ClearCacheData()
end

function UI_Item_Upgrade:Close()
  local logic_achievement_float_tip = require("client.slua.logic.achievement.logic_achievement_float_tip")
  logic_achievement_float_tip.UnblockPopTip()
  self.curSelectedWeaponType = nil
  UI_Item_Upgrade.__super.Close(self)
end

function UI_Item_Upgrade:GetDataForJumpBack()
  local jumpFeatureId
  if self.killFeatureSubUI and self.killFeatureSubUI.GetCurSelectFeatureId then
    jumpFeatureId = self.killFeatureSubUI:GetCurSelectFeatureId()
  end
  local SelectedSubIndex, effectIndex
  if self.bJumpFromKillCounter then
    SelectedSubIndex = self.SelectedSubIndex
    effectIndex = self.ExtendedLoopScrollBox_Effect:GetSelectIndex()
  end
  return {
    ctorData = {
      [1] = self.CurSelectWeaponID,
      [2] = {
        tabIndex = self.ExtendedLoopScrollBox_TabList and self.ExtendedLoopScrollBox_TabList:GetSelectIndex() or 1,
        subTabIndex = self.curSelectSubIndex,
        jumpFeatureId = jumpFeatureId,
        bJumpFromKillCounter = self.bJumpFromKillCounter,
        effectIndex = effectIndex,
        SelectedSubIndex = SelectedSubIndex
      }
    }
  }
end

function UI_Item_Upgrade:GetCurItemEffectLevel()
  local selectWeaponData = self:GetSelectWeaponItemData()
  if selectWeaponData then
    local Mgr = self:GetItemUpgradeMgr()
    local baseGroupID = selectWeaponData.groupID
    if Mgr:IsDualFormGroup(baseGroupID) then
      local levels = Mgr:GetDualFormLevels(baseGroupID)
      if levels then
        log(bWriteLog and "UI_Item_Upgrade:GetCurItemEffectLevel DualForm!")
        return math.max(levels.lvX, levels.lvY)
      end
    end
    if self.FormList:GetItemCount() == 0 or self.FormIndex == 1 then
      log(bWriteLog and "UI_Item_Upgrade:GetCurItemEffectLevel in the first Form or only one form!")
      return self:GetItemUpgradeMgr():GetLevelByGroupIDFull(selectWeaponData.groupID)
    else
      log(bWriteLog and "UI_Item_Upgrade:GetCurItemEffectLevel in the other form!")
      local groupId = self:GetItemUpgradeMgr():GetRefitWeaponGroupID(selectWeaponData.resID)
      if groupId then
        return self:GetItemUpgradeMgr():GetLevelByGroupIDFull(groupId)
      else
        return 0
      end
    end
  else
    return 0
  end
end

function UI_Item_Upgrade:GetSubTabData(tabType)
  if tabType == item_upgrade_ui_config.UITabType.ItemUpgradeUI then
    return item_upgrade_ui_config.ItemUpgradeTabListConfig
  elseif tabType == item_upgrade_ui_config.UITabType.KillFeature then
    return item_upgrade_ui_config.KillFeatureTabListConfig
  end
end

function UI_Item_Upgrade:OnRefreshTab(widget, index)
  log(bWriteLog and "UI_Item_Upgrade:OnRefreshTab index:" .. tostring(index))
  local data = self.ExtendedLoopScrollBox_TabList:GetItemData(index)
  if not data or not data.TabType then
    log(bWriteLog and "UI_Item_Upgrade:OnRefreshTab invalid data")
    return
  end
  self:SetWidgetVisible(widget.WidgetSwitcher_Arrow, false)
  self:SetWidgetVisible(widget.Image_2, false)
  self:SetTexture(widget.Image_tab2, data.UnSelectIconPath)
  self:SetTexture(widget.Image_tab, data.SelectIconPath)
  widget.WidgetSwitcher_2:SetActiveWidgetIndex(1)
  local selectIdx = self.ExtendedLoopScrollBox_TabList:GetSelectIndex()
  local bIsSelectedTab = index == selectIdx
  if not self._tTabSelectAnimState then
    self._tTabSelectAnimState = {}
  end
  local sAnimState = self._tTabSelectAnimState[widget]
  if bIsSelectedTab then
    if FirstRefreshTab then
      FirstRefreshTab = false
      widget:PlayUserWidgetAnimation(widget.Select_Fadein, 0, 1, 0, 1)
      self._tTabSelectAnimState[widget] = "fadein"
    elseif widget.Anim_Select and sAnimState ~= "selected" and sAnimState ~= "fadein" then
      widget:PlayUserWidgetAnimation(widget.Anim_Select, widget.Anim_Select:GetEndTime(), 1, 0, 1)
      self._tTabSelectAnimState[widget] = "selected"
      printf("UI_Item_Upgrade:OnRefreshTab jump select anim to end, index:%s, oldState:%s", tostring(index), tostring(sAnimState))
    end
    widget.WidgetSwitcher_0:SetActiveWidgetIndex(0)
    local subTabData = self:GetSubTabData(data.TabType) or {}
    log(bWriteLog and "UI_Item_Upgrade:OnRefreshTab SetSubData count:" .. tostring(#subTabData))
    if 0 < #subTabData then
      if self.curSelectSubIndex > #subTabData then
        self.curSelectSubIndex = 1
      end
      local iconTabs = {}
      for _, v in ipairs(subTabData) do
        iconTabs[#iconTabs + 1] = {
          activePath = v.UnSelectIconPath,
          inactivePath = v.UnSelectIconPath,
          selectedBgPath = C_SubTabSelectedBgPath,
          _sourceData = v
        }
      end
      self.SubTabList:SetTabs(iconTabs, self.curSelectSubIndex)
      local preserveSelection = data.TabType == item_upgrade_ui_config.UITabType.ItemUpgradeUI and self.curSelectedWeaponType == subTabData[self.curSelectSubIndex].TabType and self.CurSelectWeaponID and 0 < self.CurSelectWeaponID and (not self.defaultShowItemId or not (0 < self.defaultShowItemId))
      printf("UI_Item_Upgrade:OnRefreshTab preserveSelection:%s, tabType:%s, subIndex:%s, currentWeaponType:%s, weaponID:%s, jumpItemID:%s", tostring(preserveSelection), tostring(data.TabType), tostring(self.curSelectSubIndex), tostring(self.curSelectedWeaponType), tostring(self.CurSelectWeaponID), tostring(self.defaultShowItemId))
      if not preserveSelection then
        self:OnSelectSubTab(self.curSelectSubIndex)
      end
    end
  else
    widget.WidgetSwitcher_0:SetActiveWidgetIndex(1)
    local bAnimPlayed = sAnimState == "selected"
    if widget.Anim_Select and bAnimPlayed then
      widget:PlayUserWidgetAnimation(widget.Anim_Select, 0, 1, 1, 1)
      self._tTabSelectAnimState[widget] = "reverted"
    end
  end
  widget.Reddot_Anchor:UnBind()
  local ResearchRedDot = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ResearchRedDot)
  local redData = ResearchRedDot:GetNodeDataByTabType(data.TabType)
  if redData then
    widget.Reddot_Anchor:Bind(redData)
  end
end

function UI_Item_Upgrade:OnRefreshSubTab(widget, index)
  log(bWriteLog and "UI_Item_Upgrade:OnRefreshSubTab index:" .. tostring(index))
  local tabData = self.SubTabList:GetTabData(index)
  if not tabData then
    log(bWriteLog and "UI_Item_Upgrade:OnRefreshSubTab invalid data")
    return
  end
  local data = tabData._sourceData
  if self.curOpenTabType == item_upgrade_ui_config.UITabType.ItemUpgradeUI then
    self:OnUpdateWeaponSubType(widget, index)
  elseif self.curOpenTabType == item_upgrade_ui_config.UITabType.KillFeature then
  end
  widget.Reddot_Anchor:UnBind()
  local ResearchRedDot = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ResearchRedDot)
  local redData = ResearchRedDot:GetNodeDataByTabType(self.curOpenTabType)
  if not redData then
    return
  end
  local TabType = data.TabType
  if TabType == 0 then
    widget.Reddot_Anchor:Bind(redData)
  elseif redData[TabType] then
    widget.Reddot_Anchor:Bind(redData[TabType])
  end
end

function UI_Item_Upgrade:OnClickTab(widget, index)
  log(bWriteLog and "UI_Item_Upgrade:OnClickTab index:" .. tostring(index))
  self:PlayAudio(sound_config.click_v1)
  local data = self.ExtendedLoopScrollBox_TabList:GetItemData(index)
  if not data or not data.TabType then
    return
  end
  if data.TabType == self.curOpenTabType then
    log(bWriteLog and "UI_Item_Upgrade:OnClickTab same tab, ignore")
    return
  end
  self.curOpenTabType = data.TabType
  local curSelectIndex = self.ExtendedLoopScrollBox_TabList:GetSelectIndex()
  if index == curSelectIndex then
    log(bWriteLog and "UI_Item_Upgrade:OnClickTab UnFold")
    self.ExtendedLoopScrollBox_TabList:RefreshAllItems()
  else
    self:PlayUserWidgetAnimation(self.UIRoot.Anim_Select, 0, 1, 0, 1)
    widget:PlayUserWidgetAnimation(widget.Anim_Select, 0, 1, 0, 1)
    if not self._tTabSelectAnimState then
      self._tTabSelectAnimState = {}
    end
    self._tTabSelectAnimState[widget] = "selected"
    self.curSelectSubIndex = 1
    self.CurSelectWeaponID = -1
    self.curKillFeatureType = nil
    self.reinitPreserveItemID = nil
    self.ExtendedLoopScrollBox_TabList:Select(index)
  end
end

function UI_Item_Upgrade:OnClickSubTab(widget, index)
  log(bWriteLog and "UI_Item_Upgrade:OnClickSubTab index:" .. tostring(index))
  self:PlayAudio(sound_config.click_v1)
  if index == self.curSelectSubIndex then
    log(bWriteLog and "UI_Item_Upgrade:OnClickSubTab index == selectIdx")
    return
  end
  local tabData = self.SubTabList:GetTabData(index)
  if not tabData then
    return
  end
  local data = tabData._sourceData
  self.ClickDownloadItemID = nil
  self:OnSelectSubTab(index)
  local ResearchRedDot = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ResearchRedDot)
  local item_upgrade_ui_config = require("client.slua.umg.upgrade.item_upgrade_ui_config")
  local redData = ResearchRedDot:GetNodeDataByTabType(self.curOpenTabType)
  if redData and redData[data.TabType] then
    local gunRedData = redData[data.TabType]
    if gunRedData.instances then
      for i, _ in pairs(gunRedData.instances) do
        gunRedData.instances[i] = nil
      end
    end
  end
end

function UI_Item_Upgrade:OnSelectSubTabFromIcon(lastIndex, index, bIsFromClick)
  log(bWriteLog and "UI_Item_Upgrade:OnSelectSubTabFromIcon lastIndex:" .. tostring(lastIndex) .. " index:" .. tostring(index) .. " bIsFromClick:" .. tostring(bIsFromClick))
  if not bIsFromClick then
    self.curSelectSubIndex = index
  end
end

function UI_Item_Upgrade:OnSelectSubTab(index)
  log(bWriteLog and "UI_Item_Upgrade:OnSelectSubTab index:" .. tostring(index))
  self.curSelectSubIndex = index
  if self.curOpenTabType == item_upgrade_ui_config.UITabType.ItemUpgradeUI then
    self:UpdateUpgradeGunShow(true)
    local TabData = item_upgrade_ui_config.ItemUpgradeTabListConfig[index]
    local weaponType = TabData.TabType
    self:SelectWeaponSubType(weaponType)
  elseif self.curOpenTabType == item_upgrade_ui_config.UITabType.KillFeature then
    self:UpdateUpgradeGunShow(false)
    self:SelectKillFeatureSubTab(index)
    self:UpdateAudioItem()
  end
end

function UI_Item_Upgrade:SelectKillFeatureSubTab(subTabIndex)
  if not subTabIndex then
    return
  end
  local tabData = self.SubTabList and self.SubTabList:GetTabData(subTabIndex)
  local data = tabData and tabData._sourceData
  if not data or not data.TabType then
    return
  end
  self.curKillFeatureType = data.TabType
  if data.UIConfigKeyName and data.UIConfigKeyName ~= "" then
    self.killFeatureSubUI = self:CreateChildWindow(self.UIRoot.CanvasPanel_CollectRewards, UIManager.UI_Config[data.UIConfigKeyName], self.jumpFeatureId)
    self.jumpFeatureId = nil
  end
end

function UI_Item_Upgrade:UpdateUpgradeGunShow(bShow)
  bShow = bShow or false
  if not bShow then
    self.EffectComponent:HideAllModel()
  end
  if self.killFeatureSubUI then
    self.killFeatureSubUI:CloseSelf()
    self.killFeatureSubUI = nil
  end
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_gun_menu, bShow)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_4, bShow)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_0, bShow)
end

function UI_Item_Upgrade:RefreshKillCounter()
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_KillCounter, false)
  local LogicKillCounter = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicKillCounter)
  local originId = LogicKillCounter:GetWeaponIdBySkinId(self.CurSelectWeaponID)
  local curEquipedKillCounter = LogicKillCounter:GetMyEquipedKillCounterId(originId)
  if not curEquipedKillCounter then
    log(bWriteLog and "UI_Item_Upgrade:RefreshKillCounter no curEquipedKillCounter")
    return
  end
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_KillCounter, true)
  local LogicKillCounter = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicKillCounter)
  local killNum = LogicKillCounter:GetWeaponKillCountByUid(DataMgr.roleData.uid, originId)
  if self.KillCounterItem.SetKillCounterItemShowWithNum then
    self.KillCounterItem:SetKillCounterItemShowWithNum(curEquipedKillCounter, killNum, self.CurSelectWeaponID)
  end
end

function UI_Item_Upgrade:OnClickKillCounter()
  self:PlayAudio(sound_config.click_v1)
  local LogicKillCounter = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicKillCounter)
  local originId = LogicKillCounter:GetWeaponIdBySkinId(self.CurSelectWeaponID)
  local curEquipedKillCounter = LogicKillCounter:GetMyEquipedKillCounterId(originId)
  if not curEquipedKillCounter then
    log(bWriteLog and "UI_Item_Upgrade:OnClickKillCounter no curEquipedKillCounter")
    return
  end
  local itemCfg = CDataTable.GetTableData("Item", curEquipedKillCounter)
  if not itemCfg then
    log(bWriteLog and "UI_Item_Upgrade:OnClickKillCounter no itemCfg")
    return
  end
  local tipsParam = {
    widget = self.UIRoot.Common_KillCounter_UIBP.Button_0,
    title = itemCfg.ItemName,
    content = itemCfg.ItemDesc,
    offsetX = 0,
    offsetY = 55
  }
  UIManager.ShowUI(UIManager.UI_Config.Common_Other_Tips_UIBP, tipsParam)
end

function UI_Item_Upgrade:OnClickGetKillCounter()
  self:PlayAudio(sound_config.click_v1)
  local LogicKillCounter = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicKillCounter)
  local itemJumpUrl = LogicKillCounter:GetKillCounterItemJumpUrl(self.CurSelectWeaponID)
  if not itemJumpUrl then
    log(bWriteLog and "UI_Item_Upgrade:OnClickGetKillCounter itemJumpUrl is nil")
    return
  end
  self.bJumpFromKillCounter = true
  log(bWriteLog and "UI_Item_Upgrade:OnClickGetKillCounter itemJumpUrl:" .. itemJumpUrl)
  GlobalData.JumpUrl(itemJumpUrl)
end

function UI_Item_Upgrade:OnKillCounterUpdate()
  self:RefreshKillCounter()
  local curSelectEffectIndex = self.ExtendedLoopScrollBox_Effect:GetSelectIndex()
  if curSelectEffectIndex and 0 < curSelectEffectIndex then
    self.bNotPlayEffectPanelAnim = true
    self.ExtendedLoopScrollBox_Effect:RefreshItem(curSelectEffectIndex)
    self.bNotPlayEffectPanelAnim = false
  end
end

function UI_Item_Upgrade:OnClickSpecialAction()
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  if ModelDisplayer.GetShowingStatus() == ModelDisplayer.Enum_Status.Avatar then
    ModelDisplayer.Display(1108001062, true)
  else
    self:OnClickSwitchModel()
  end
  self.UIRoot.TextBlock_Guide:SetText(LocUtil.GetLocalizeResStr(82170))
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Tips, true)
end

function UI_Item_Upgrade:RefreshSpecialAction()
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Action, false)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Tips, false)
  local selectEffect = self.ExtendedLoopScrollBox_Effect:GetItemData(self.ExtendedLoopScrollBox_Effect:GetSelectIndex())
  if not selectEffect then
    return
  end
  if tostring(selectEffect.resID) ~= "1108001062" or selectEffect.effectID ~= 1 then
    return
  end
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Action, true)
end

function UI_Item_Upgrade:OnItemClickDownload(_, _, data, extraData)
  if not (data and type(data) == "table" and not (#data <= 0) and tonumber(data[1])) or 0 >= tonumber(data[1]) then
    return
  end
  local itemCfg = CDataTable.GetTableData("Item", tonumber(data[1]))
  if not itemCfg then
    return
  end
  log(bWriteLog and "UI_Item_Upgrade:OnItemClickDownload ItemID:" .. tostring(itemCfg.ItemID) .. ", ItemTyp:" .. tostring(itemCfg.ItemType) .. ", ItemSubType:" .. tostring(itemCfg.ItemSubType))
  self.ClickDownloadItemID = itemCfg.ItemID
end

function UI_Item_Upgrade:UpdateOnSelectDownloaded(_, _, eventData)
  local itemID = eventData.itemID
  if not itemID or tonumber(itemID) <= 0 then
    return
  end
  if not self.ClickDownloadItemID or self.ClickDownloadItemID == 0 or self.ClickDownloadItemID ~= itemID then
    return
  end
  local itemCfg = CDataTable.GetTableData("Item", itemID)
  if not itemCfg then
    return
  end
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  local state = PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, {
    itemCfg.itemID
  })
  if state ~= PufferConst.ENUM_DownloadState.Done then
    return
  end
  local list = self.ScrollBoxWeapon:GetSetData()
  for index, v in pairs(list) do
    if v.resID == itemID then
      local widget = self.ScrollBoxWeapon:GetIndexOfWidget(index)
      self:OnClickedWeaponItemDetail(widget, index, true)
      break
    end
  end
end

function UI_Item_Upgrade:_StartDualFormRotateSwitch(targetWeaponID, onFinish)
  if onFinish then
    onFinish()
  end
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CUI_Item_Upgrade = class(ui_base, nil, UI_Item_Upgrade)
return CUI_Item_Upgrade
