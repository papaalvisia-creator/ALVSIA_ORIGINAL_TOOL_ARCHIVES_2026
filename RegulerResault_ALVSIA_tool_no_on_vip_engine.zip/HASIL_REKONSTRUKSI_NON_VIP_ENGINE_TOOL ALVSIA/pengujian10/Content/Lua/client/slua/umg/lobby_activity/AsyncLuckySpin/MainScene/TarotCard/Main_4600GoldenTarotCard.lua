local Main_4600GoldenTarotCard = {}
local Trait = require("common.trait")
local CAsyncLuckySpinMainTarotCard = require("client.slua.umg.lobby_activity.AsyncLuckySpin.AsyncLuckySpinMainTarotCard")
local TarotCardDrawCardSystem = require("client.slua.logic.tarot_card.logic_tarotcard_drawcard")
local Traits = {
  require("client.slua.umg.lobby_activity.AsyncLuckySpin.Traits.TarotCard.JumpToPreview"),
  require("client.slua.umg.lobby_activity.AsyncLuckySpin.Traits.TarotCard.JumpToWeapon"),
  require("client.slua.umg.lobby_activity.AsyncLuckySpin.Traits.JumpAnimTwoStage"),
  require("client.slua.umg.lobby_activity.AsyncLuckySpin.Traits.JPKRRegionSpeciality"),
  require("client.slua.umg.lobby_activity.AsyncLuckySpin.Traits.RateDetail"),
  require("client.slua.umg.lobby_activity.AsyncLuckySpin.Traits.TarotCard.FeaturePreviewItem")
}
local Static = {
  Enum_AnimType = {
    Null = 1,
    OneDraw = 2,
    TenDraw = 3
  }
}
local CMain_4600GoldenTarotCard = Trait.TraitClass(CAsyncLuckySpinMainTarotCard, Static, Main_4600GoldenTarotCard, Traits)
local Config = require("client.slua.umg.lobby_activity.AsyncLuckySpin.Config.SpinConfig")

function Main_4600GoldenTarotCard:ctor(_, _)
end

function Main_4600GoldenTarotCard:InitializeConfigs()
  TarotCardDrawCardSystem.SetTarotcardBeOpen(true)
  self.Configs = {
    AnimationConfig = {
      EntryAnimation = "NewAnimation_out_in",
      LoopAnimation = "NewAnimation_loop",
      OutAnimation = "NewAnimation_out",
      DrawButtonAnimation = {
        DrawOne = "NewAnimation_Btn_OneDraw",
        DrawTen = "NewAnimation_Btn_TenDraw",
        DrawSpineTime = 1.5
      },
      Misc = {
        BackgroundOut = "Out",
        BackgroundLoop = "loop",
        BackgroundIn = "fadein"
      }
    },
    AudioConfig = {
      MainSceneEntry = "/Game/Arts_UI/GoldSpin/4600/ScorpiusFavor/WwiseEvent/Activity_GoldSpin_ScorpiusFavor_460/Play_Activity_GoldSpin_ScorpiusFavor_Enter.Play_Activity_GoldSpin_ScorpiusFavor_Enter",
      MainSceneLoopStop = "/Game/Arts_UI/GoldSpin/4600/ScorpiusFavor/WwiseEvent/Activity_GoldSpin_ScorpiusFavor_460/Stop_Activity_GoldSpin_ScorpiusFavor_Enter.Stop_Activity_GoldSpin_ScorpiusFavor_Enter",
      StartDrawOne = "/Game/Arts_UI/GoldSpin/4600/ScorpiusFavor/WwiseEvent/Activity_GoldSpin_ScorpiusFavor_460/Play_Activity_GoldSpin_ScorpiusFavor_Award.Play_Activity_GoldSpin_ScorpiusFavor_Award",
      StartDrawTen = "/Game/Arts_UI/GoldSpin/4600/ScorpiusFavor/WwiseEvent/Activity_GoldSpin_ScorpiusFavor_460/Play_Activity_GoldSpin_ScorpiusFavor_Award.Play_Activity_GoldSpin_ScorpiusFavor_Award",
      StopDrawOne = "/Game/Arts_UI/GoldSpin/4600/ScorpiusFavor/WwiseEvent/Activity_GoldSpin_ScorpiusFavor_460/Stop_Activity_GoldSpin_ScorpiusFavor_Award.Stop_Activity_GoldSpin_ScorpiusFavor_Award",
      StopDrawTen = "/Game/Arts_UI/GoldSpin/4600/ScorpiusFavor/WwiseEvent/Activity_GoldSpin_ScorpiusFavor_460/Stop_Activity_GoldSpin_ScorpiusFavor_Award.Stop_Activity_GoldSpin_ScorpiusFavor_Award",
      delayDraw = 0.5,
      Misc = {DrawOneEff = "", DrawTenEff = ""}
    },
    PoolConfig = {
      PoolBlueprintPath = "/Game/Arts_UI/GoldSpin/4600/ScorpiusFavor/ScorpiusFavor_Pool_UIBP.ScorpiusFavor_Pool_UIBP",
      PoolLuaPath = "client.slua.umg.lobby_activity.AsyncLuckySpin.Pool.TarotCard.Pool3200TarotCard",
      PoolBgAttachPanel = "CanvasPanel_PoolBg",
      PoolItemPrefix = "Item_0",
      PoolAttachPanel = "CP_Item",
      PoolAnimationConfig = {
        PoolShowAnimTen = "fadein",
        PoolShowAnimOne = "fadein_one",
        PoolLoopAnim = "loop"
      },
      PoolItemIconPath = {},
      QualityBgImages = {
        [8] = "/Game/Arts_UI/GoldSpin/4600/ScorpiusFavor/Atlas/Frames/ScorpiusFavor_Image_Quality_G_png_png.ScorpiusFavor_Image_Quality_G_png_png",
        [5] = "/Game/Arts_UI/GoldSpin/4600/ScorpiusFavor/Atlas/Frames/ScorpiusFavor_Image_Quality_P_png_png.ScorpiusFavor_Image_Quality_P_png_png",
        [6] = "/Game/Arts_UI/GoldSpin/4600/ScorpiusFavor/Atlas/Frames/ScorpiusFavor_Image_Quality_Pink_png_png.ScorpiusFavor_Image_Quality_Pink_png_png",
        [7] = "/Game/Arts_UI/GoldSpin/4600/ScorpiusFavor/Atlas/Frames/ScorpiusFavor_Image_Quality_R_png_png.ScorpiusFavor_Image_Quality_R_png_png"
      },
      Misc = {AutoClosePoolTimeOne = 3, AutoClosePoolTimeTen = 3},
      PoolBg = {
        PoolBgBlueprintPath = "/Game/Arts_UI/GoldSpin/4600/ScorpiusFavor/ScorpiusFavor_Pool_BG_UIBP.ScorpiusFavor_Pool_BG_UIBP",
        PoolBgLuaPath = "client.slua.umg.lobby_activity.AsyncLuckySpin.Pool.TarotCard.Pool3200TarotCardBg",
        AnimConfig = {PoolBgShow = "fadein", PoolBgShow1 = "fadein_one"}
      }
    },
    Misc = {
      BackgroundConfig = {
        AttachWidgetName = "CanvasPanel_BG",
        BackgroundWidgetBasicPath = "/Game/Arts_UI/GoldSpin/4600/ScorpiusFavor/ScorpiusFavor_BG_UIBP.ScorpiusFavor_BG_UIBP",
        Animation = {EntryAnimation = "Fadein", LoopAnimation = "Loop"}
      },
      ExchangeConfig = {
        ExchangeSpecialItemPos = {Full = true},
        Animation = {EntryAnimation = "Fadein", LoopAnimation = "Loop"}
      },
      DrawButtonAnimationConfig = {
        DrawOne = "NewAnimation_Bth_OneDraw",
        DrawTen = "NewAnimation_Bth_TenDraw"
      }
    },
    SpineEffect = {
      audioList = {
        [1] = {
          {voiceID = 311},
          {voiceID = 315},
          {voiceID = 317}
        },
        [2] = {
          {voiceID = 347},
          {voiceID = 357},
          {voiceID = 359}
        }
      }
    },
    JumpPreviewItem = {
      dirName = "FeaturePreviewItem",
      itemList = {
        [1] = 1408074,
        [2] = 1408075
      }
    },
    SpecialFeature = {
      dirName = "SpecialFeatureItem",
      itemList = {
        [1] = {
          itemID = 1408075,
          groupIDList = {1},
          name = 18141278,
          desc = 18141279,
          jumpExchangeExtra = {tabIndex = 2, selectItemID = 1408075}
        }
      }
    }
  }
  self.SwitchAudio = "/Game/Arts_UI/GoldSpin/4600/ScorpiusFavor/WwiseEvent/Activity_GoldSpin_ScorpiusFavor_460/Play_Activity_GoldSpin_ScorpiusFavor_OutfitChange.Play_Activity_GoldSpin_ScorpiusFavor_OutfitChange"
end

function Main_4600GoldenTarotCard:InitializeSpin()
  Main_4600GoldenTarotCard.__super.InitializeSpin(self)
  self.curFeatureType = 1
  self:AddTimerOnce(0.3, function()
    self:InitRateDetail()
    self.DrawCounter = self:RegisterComponent(Config.Components.TarotCardDrawCounter, self.UIRoot)
    self.CollectReward = self:RegisterComponent(Config.Components.TarotCardCollectReward, self.UIRoot)
    self:AddOnClickedEventByControl(self.UIRoot.Button_SwitchType, self.OnClicked_SwitchType, self)
    self:InitFeaturePreviewItem()
    self:RefreshSwitchType()
    self:AddTimerOnce(0.3, function()
      self:InitJumpToPreview()
      self:InitJumpToWeapon()
      self:InitJPKRRegionSpeciality()
    end)
    local LuckyCardModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule)
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_GoodLuckCard, false)
    if LuckyCardModule:IsShowCommonEntry(self.ActivityID) then
      self:SetWidgetVisible(self.UIRoot.CanvasPanel_GoodLuckCard, true)
      self:CreateChildWindow(self.UIRoot.CanvasPanel_GoodLuckCard, UIManager.UI_Config.Common_GoodLuck_Enter_UIBP, self.ActivityID)
    end
  end)
end

function Main_4600GoldenTarotCard:RegistSpecialAnimEvent()
  if self.BackgroundWidget and self.BackgroundWidget.OnPlayLoopAudio then
    self:AddControlEventByControl(self.BackgroundWidget, "OnPlayLoopAudio", self.OnPlayLoopAudio, self)
  end
  if self.BackgroundWidget and self.BackgroundWidget.OnShowFeature then
    self:AddControlEventByControl(self.BackgroundWidget, "OnShowFeature", self.OnShowFeature, self)
  end
  if self.BackgroundWidget and self.BackgroundWidget.OnHideFeature then
    self:AddControlEventByControl(self.BackgroundWidget, "OnHideFeature", self.OnHideFeature, self)
  end
end

function Main_4600GoldenTarotCard:OnShowFeature()
  log(bWriteLog and "[SY]Main_4600GoldenTarotCard:OnShowFeature.")
  self.curFeatureType = 2
  self:RefreshSwitchType()
  self:ChangeFeatureGroup(self.curFeatureType)
end

function Main_4600GoldenTarotCard:OnHideFeature()
  log(bWriteLog and "[SY]Main_4600GoldenTarotCard:OnHideFeature.")
  self.curFeatureType = 1
  self:RefreshSwitchType()
  self:ChangeFeatureGroup(self.curFeatureType)
end

function Main_4600GoldenTarotCard:OnPlayLoopAudio()
  self:PlayAudio(self.SwitchAudio)
end

function Main_4600GoldenTarotCard:OnClicked_SwitchType()
  self:PlayAudio(sound_config.click_v1)
  self:StopEffectSound()
  self.curFeatureType = self.curFeatureType == 1 and 2 or 1
  self:ChangeFeatureGroup(self.curFeatureType)
  self:RefreshSwitchType()
  self:PlaySwitchAnim()
  self:PlayAudio(self.SpecialAudio[self.curFeatureType])
  self:PlayAudio(self.SpecialAudioStop[self.curFeatureType == 1 and 2 or 1])
end

function Main_4600GoldenTarotCard:RefreshSwitchType()
  local index = self.curFeatureType == 1 and 0 or 1
  self.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(index)
  self.UIRoot.WidgetSwitcher_1:SetActiveWidgetIndex(index)
end

function Main_4600GoldenTarotCard:PlaySwitchAnim()
  self:PlayWidgetAnimation(self.UIRoot, self.UIRoot["SwitchType" .. self.curFeatureType], 0, 1, 0, 1)
  if self.BackgroundWidget then
    if self.BackgroundWidget.SetSwitch then
      self.BackgroundWidget:SetSwitch()
    end
    if self.BackgroundWidget.SwitchRoleAnimation then
      self.BackgroundWidget:SwitchRoleAnimation()
    end
    if self.BackgroundWidget.SwitchManAnimation then
      self.BackgroundWidget:SwitchManAnimation()
    end
  end
end

function Main_4600GoldenTarotCard:AfterPoolLoadCallback(Pool, isFirst)
  if not Pool then
    return
  end
  self.Pool = Pool
  self.Pool:InitPool_TarotCard(self, self.Configs.PoolConfig.PoolItemPrefix, {
    rewardPanelShowAnim = self.Configs.PoolConfig.PoolAnimationConfig.PoolShowAnim,
    rewardPanelShowAnimTen = self.Configs.PoolConfig.PoolAnimationConfig.PoolShowAnimTen,
    rewardPanelShowAnimOne = self.Configs.PoolConfig.PoolAnimationConfig.PoolShowAnimOne,
    rewardPanelLoopAnim = self.Configs.PoolConfig.PoolAnimationConfig.PoolLoopAnim
  }, nil, self.Configs.PoolConfig.PoolItemIconPath, self.Configs.PoolConfig.PoolItemIconPathFormat)
  self:InitJumpAnimTwoStage(self.Pool)
  if not isFirst then
    self:HideButtonMask()
  end
end

function Main_4600GoldenTarotCard:PlayDrawTenAnimation()
  self:SetAnimType(Static.Enum_AnimType.TenDraw)
  self:ReleasePool()
  self:AsyncLoadPool(self.Configs.PoolConfig.PoolBlueprintPath, self.Configs.PoolConfig.PoolLuaPath, function(Pool)
    self:AfterPoolLoadCallback(Pool)
    self:AddTimer(0, function()
      Main_4600GoldenTarotCard.__super.PlayDrawTenAnimation(self)
    end)
  end, "CP_Item")
end

function Main_4600GoldenTarotCard:PlayDrawOneAnimation()
  self:SetAnimType(Static.Enum_AnimType.OneDraw)
  self:ReleasePool()
  self:AsyncLoadPool(self.Configs.PoolConfig.PoolBlueprintPath, self.Configs.PoolConfig.PoolLuaPath, function(Pool)
    self:AfterPoolLoadCallback(Pool)
    self:AddTimer(0, function()
      Main_4600GoldenTarotCard.__super.PlayDrawOneAnimation(self)
    end)
  end, "CP_Item")
end

function Main_4600GoldenTarotCard:OnClose()
  TarotCardDrawCardSystem.SetTarotcardBeOpen(false)
end

return CMain_4600GoldenTarotCard
