local XSuit_Popup_Theme_Explain_Picture02_Item2_UIBP = {}
local LOC_KEY_TOTAL_GAIN = 18141487
local HARD_CODE_REWARD_COUNT = {
  {3200, 80},
  {1320, 60}
}
local HARD_CODE_REWARD_ITEMID = {2603027, 2603028}

function XSuit_Popup_Theme_Explain_Picture02_Item2_UIBP:OnRefresh()
  local data = self.data
  if not data then
    return
  end
  if self.UIRoot.TextBlock_1 then
    self.UIRoot.TextBlock_1:SetText(data.title and LocUtil.GetLocalizeResStr(data.title) or "")
  end
  if self.UIRoot.TextBlock_2 then
    self.UIRoot.TextBlock_2:SetText(LocUtil.GetLocalizeResStr(LOC_KEY_TOTAL_GAIN))
  end
  local hardCode = HARD_CODE_REWARD_COUNT[self.index or 1] or {}
  local itemId1 = data.itemid1 and data.itemid1 > 0 and data.itemid1 or HARD_CODE_REWARD_ITEMID[1]
  local itemId2 = data.itemid2 and 0 < data.itemid2 and data.itemid2 or HARD_CODE_REWARD_ITEMID[2]
  self:RefreshMaterialItem(self.UIRoot.Image_Icon_01, self.UIRoot.UTRichTextBlock_Count_01, itemId1, hardCode[1] or 0)
  self:RefreshMaterialItem(self.UIRoot.Image_Icon_02, self.UIRoot.UTRichTextBlock_Count_02, itemId2, hardCode[2] or 0)
end

function XSuit_Popup_Theme_Explain_Picture02_Item2_UIBP:RefreshMaterialItem(iconWidget, countWidget, resID, num)
  local itemId = type(resID) == "number" and 0 < resID and resID or 0
  if iconWidget then
    self:SetWidgetVisible(iconWidget, true)
    local UIUtil = require("client.common.ui_util")
    local iconPath, bHasAddKnownMissing = UIUtil.GetItemSmallIcon(resID, iconWidget)
    self:SetTexture(iconWidget, iconPath, {sync = false, bHasAddKnownMissing = bHasAddKnownMissing})
  end
  if countWidget then
    self:SetWidgetVisible(countWidget, true)
    countWidget:SetText(tostring(num or 0))
  end
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.component.scroll_box_child_base")
local CXSuit_Popup_Theme_Explain_Picture02_Item2_UIBP = class(ui_base, nil, XSuit_Popup_Theme_Explain_Picture02_Item2_UIBP)
return CXSuit_Popup_Theme_Explain_Picture02_Item2_UIBP
