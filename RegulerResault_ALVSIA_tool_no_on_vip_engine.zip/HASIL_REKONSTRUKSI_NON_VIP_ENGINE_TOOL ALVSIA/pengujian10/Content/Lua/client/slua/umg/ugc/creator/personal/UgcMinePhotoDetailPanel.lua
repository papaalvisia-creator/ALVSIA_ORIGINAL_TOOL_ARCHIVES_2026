local UI_UGC_Mine_Photo_Detail = {}
local Util_UGC = require("client.slua.logic.ugc.util_ugc")
local Config_UGC = require("client.slua.logic.ugc.config_ugc")

function UI_UGC_Mine_Photo_Detail:ctor(_, slot, index)
  self.slot = slot
  self.currentIndex = index
end

function UI_UGC_Mine_Photo_Detail:OnInitialize()
  UI_UGC_Mine_Photo_Detail.__super.OnInitialize(self)
end

function UI_UGC_Mine_Photo_Detail:RegistEvents()
  UI_UGC_Mine_Photo_Detail.__super.RegistEvents(self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Close, self.OnClickClose, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Delete, self.OnClickDelete, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Right, self.OnClickRight, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Left, self.OnClickLeft, self)
  self.UIRoot.Button_AI:SetBtnClick(self.OnClickAI, self)
  self.UIRoot.Button_Cover:SetBtnClick(self.OnClickCover, self)
end

function UI_UGC_Mine_Photo_Detail:OnPostInitialize()
  UI_UGC_Mine_Photo_Detail.__super.OnPostInitialize(self)
  self:PlayUserWidgetAnimation(self.UIRoot.Auto_Fadein, 0, 1, 0, 1)
  self:InitPanel()
end

function UI_UGC_Mine_Photo_Detail:OnClickClose()
  self:PlayAudio(sound_config.close_v1)
  self:CloseSelf()
end

function UI_UGC_Mine_Photo_Detail:OnClickDelete()
  self:PlayAudio(sound_config.close_v1)
  if self.currentIndex <= 0 and self.currentIndex > #self.pictureInfo then
    return
  end
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local realIndex = self.pictureInfo[self.currentIndex].index or 0
  LogicUGCCRUD:ReqDeleteModAlbum(self.slot, realIndex)
  self:CloseSelf()
end

function UI_UGC_Mine_Photo_Detail:ChangeAlbumIndex(index)
  if index < 1 then
    self.currentIndex = 1
  elseif index > #self.pictureInfo then
    self.currentIndex = #self.pictureInfo
  end
  self.currentIndex = index
  self:UpdateMark()
  self:UpdateArrow()
  self:UpdateImage()
end

function UI_UGC_Mine_Photo_Detail:OnClickLeft()
  self:PlayAudio(sound_config.click_v1)
  self:ChangeAlbumIndex(self.currentIndex - 1)
end

function UI_UGC_Mine_Photo_Detail:OnClickRight()
  self:PlayAudio(sound_config.click_v1)
  self:ChangeAlbumIndex(self.currentIndex + 1)
end

function UI_UGC_Mine_Photo_Detail:OnClickAI()
  if not LobbySystem.CheckOpen(BP_ENUM_UGC_AI_COVER_IMAGE_SWITCH) then
    return
  end
  self:PlayAudio(sound_config.click_v1)
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  if PublishRegionMacros.IsBlueholeOperationRegion() then
    ShowNotice(2008103)
    return
  end
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local modInfo = LogicUGCCRUD:GetModeBySlot(self.slot)
  UIManager.ShowUI(UIManager.UI_Config.UGC_EditAICoverImage_UIBP, modInfo, self.slot)
  local logic_ugc_WOWPass = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_WOWPass)
  local pass_id = logic_ugc_WOWPass:GetSeasonID() or -1
  local logic_ugc_ai_cover_image = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_ai_cover_image)
  local valid_id = logic_ugc_ai_cover_image:GetAssociateID(self.modInfo)
  local str = string.format("valid_id=%s&uid=%d&pass_id=%d", valid_id, tonumber(DataMgr.roleData.uid), pass_id)
  local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
  UGCTLogReport:ReportDelay(TLogEventDefine.UGC_AICover_Image_Click, 0, str)
end

function UI_UGC_Mine_Photo_Detail:OnClickCover()
  local pictureInfo = self.pictureInfo[self.currentIndex]
  if not pictureInfo then
    return
  end
  EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_SETCOVER, self.slot, pictureInfo.index)
  self:CloseSelf()
end

function UI_UGC_Mine_Photo_Detail:InitPanel()
  self:SetWidgetVisible(self.UIRoot.Button_AI, LobbySystem.CheckOpen(BP_ENUM_UGC_AI_COVER_IMAGE_SWITCH), true)
  local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
  local modInfo = LogicUGCCRUD:GetModeBySlot(self.slot)
  if not modInfo then
    return
  end
  local setting = modInfo.setting
  self.pictureInfo = {}
  for i = 1, #setting.album do
    local isViewPicture = false
    for _, picIndex in ipairs(setting.view_pic_list) do
      if i == picIndex then
        isViewPicture = true
      end
    end
    self.pictureInfo[i] = {
      isViewPicture = isViewPicture,
      isThumb = setting.thumb_index == i,
      urlInfo = setting.album[i],
      index = i
    }
  end
  table.sort(self.pictureInfo, function(a, b)
    local nWeight_A = a.isThumb and 3 or a.isViewPicture and 2 or 1
    local nWeight_B = b.isThumb and 3 or b.isViewPicture and 2 or 1
    if nWeight_A ~= nWeight_B then
      return nWeight_A > nWeight_B
    end
  end)
  self.UIRoot.TextBlock_Description:SetText(LocUtil.GetLocalizeResStr(87181))
  self.UIRoot.TextBlock_2:SetText(LocUtil.GetLocalizeResStr(29677))
  self.Button_AI = self.UIRoot.Button_AI
  self.Button_AI:SetBtnText(LocUtil.GetLocalizeResStr(4303050))
  self.Button_Cover = self.UIRoot.Button_Cover
  self.Button_Cover:SetBtnText(LocUtil.GetLocalizeResStr(4303063))
  self:UpdateMark()
  self:UpdateArrow()
  self:UpdateImage()
end

function UI_UGC_Mine_Photo_Detail:UpdateArrow()
  local hasLeft = self.pictureInfo[self.currentIndex - 1] ~= nil
  if hasLeft then
    self:WidgetVisible(self.UIRoot.Button_Left)
    self.UIRoot.WidgetSwitcher_2:SetActiveWidgetIndex(0)
  else
    self:WidgetHitInv(self.UIRoot.Button_Left)
    self.UIRoot.WidgetSwitcher_2:SetActiveWidgetIndex(1)
  end
  local hasRight = self.pictureInfo[self.currentIndex + 1] ~= nil
  if hasRight then
    self:WidgetVisible(self.UIRoot.Button_Right)
    self.UIRoot.WidgetSwitcher_1:SetActiveWidgetIndex(0)
  else
    self:WidgetHitInv(self.UIRoot.Button_Right)
    self.UIRoot.WidgetSwitcher_1:SetActiveWidgetIndex(1)
  end
end

function UI_UGC_Mine_Photo_Detail:UpdateBtnState()
end

function UI_UGC_Mine_Photo_Detail:UpdateImage()
  self.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(1)
  local urlInfo = self.pictureInfo[self.currentIndex].urlInfo
  local url = urlInfo.origin_url
  
  local function callback()
    self.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(0)
    local bCustom = urlInfo.custom_photo
    local CanvasPanel_WaterMark = self.UIRoot.CanvasPanel_WaterMark
    if CanvasPanel_WaterMark then
      CanvasPanel_WaterMark:SetWidgetVisibility(bCustom and UEnums.ESlateVisibility.SelfHitTestInvisible or UEnums.ESlateVisibility.Collapsed)
    end
  end
  
  Util_UGC.SetUGCImage(self, self.UIRoot.Image_Pic, url, true, callback, nil)
end

function UI_UGC_Mine_Photo_Detail:UpdateMark()
  local pictureInfo = self.pictureInfo[self.currentIndex]
  if not pictureInfo then
    return
  end
  local isThumb = pictureInfo.isThumb
  local isViewPicture = pictureInfo.isViewPicture
  local isAICoverImageOpen = LobbySystem.CheckOpen(BP_ENUM_UGC_AI_COVER_IMAGE_SWITCH)
  if isThumb then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Tag, true)
    self.UIRoot.WidgetSwitcher_Tag:SetActiveWidgetIndex(0)
    self:SetWidgetVisible(self.UIRoot.Button_AI, isAICoverImageOpen, true)
    self:SetWidgetVisible(self.UIRoot.Button_Cover, false, true)
  else
    if isViewPicture then
      self:SetWidgetVisible(self.UIRoot.CanvasPanel_Tag, true)
      self.UIRoot.WidgetSwitcher_Tag:SetActiveWidgetIndex(1)
    else
      self:SetWidgetVisible(self.UIRoot.CanvasPanel_Tag, false)
    end
    self:SetWidgetVisible(self.UIRoot.Button_AI, false, true)
    self:SetWidgetVisible(self.UIRoot.Button_Cover, true, true)
  end
end

function UI_UGC_Mine_Photo_Detail:GetDataForJumpBack()
  return {
    ctorData = {
      [1] = self.slot,
      [2] = self.currentIndex
    }
  }
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CUI_UGC_Mine_Photo_Detail = class(ui_base, nil, UI_UGC_Mine_Photo_Detail)
return CUI_UGC_Mine_Photo_Detail
