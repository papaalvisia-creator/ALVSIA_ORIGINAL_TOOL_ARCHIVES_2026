local UI_UGC_Mine_Photo_Picture_Item_New = {}

function UI_UGC_Mine_Photo_Picture_Item_New:ctor()
end

function UI_UGC_Mine_Photo_Picture_Item_New:RegistEvents()
  UI_UGC_Mine_Photo_Picture_Item_New.__super.RegistEvents(self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Select, self.OnClickButtonSelect, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_AI, self.OnClickButtonAI, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Top, self.OnClickButtonTop, self)
end

function UI_UGC_Mine_Photo_Picture_Item_New:OnPostInitialize()
  UI_UGC_Mine_Photo_Picture_Item_New.__super.OnPostInitialize(self)
  self.UIRoot.TextBlock_Select:SetText(LocUtil.GetLocalizeResStr(4303070))
end

function UI_UGC_Mine_Photo_Picture_Item_New:OnRefresh(albumInfo)
  self.albumInfo = albumInfo or nil
  local isAICoverImageOpen = LobbySystem.CheckOpen(BP_ENUM_UGC_AI_COVER_IMAGE_SWITCH)
  self:SetWidgetVisible(self.UIRoot.HorizontalBox_0, true)
  if albumInfo.isSelectMode then
    if albumInfo.isInGame then
      self:SetWidgetVisible(self.UIRoot.CanvasPanel_Selected, false)
    else
      self:SetWidgetVisible(self.UIRoot.CanvasPanel_Selected, albumInfo.isViewPicture)
    end
    self:SetWidgetVisible(self.UIRoot.Button_Top, false, true)
    self:SetWidgetVisible(self.UIRoot.Button_AI, false, true)
  else
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Selected, false)
    self:SetWidgetVisible(self.UIRoot.Button_Top, not albumInfo.isThumb, true)
    self:SetWidgetVisible(self.UIRoot.Button_AI, albumInfo.isThumb and isAICoverImageOpen, true)
  end
  if albumInfo.isThumb then
    self.UIRoot.WidgetSwitcher_Tag:SetActiveWidgetIndex(0)
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Tag, true)
  elseif albumInfo.isViewPicture then
    self.UIRoot.WidgetSwitcher_Tag:SetActiveWidgetIndex(1)
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Tag, true)
  else
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Tag, false)
  end
  if self.albumInfo ~= nil then
    self.UIRoot.WidgetSwitcher_Photo:SetActiveWidgetIndex(1)
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Tips, true)
    
    local function loadSuccessCallback()
      if not slua.isValid(self.UIRoot) then
        return
      end
      self.UIRoot.WidgetSwitcher_Photo:SetActiveWidgetIndex(0)
    end
    
    local image_download_mgr = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.image_download_mgr)
    local DiskCacheTypeEnum = image_download_mgr:GetDiskCacheTypeEnum()
    local Util_UGC = require("client.slua.logic.ugc.util_ugc")
    Util_UGC.SetUGCImage(self, self.UIRoot.Image_Photo, self.albumInfo.urlInfo.thumb_url, true, loadSuccessCallback, nil, DiskCacheTypeEnum.NeverDelete)
  else
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Tips, false)
  end
end

function UI_UGC_Mine_Photo_Picture_Item_New:OnClickButtonSelect()
  self:PlayAudio(sound_config.click_v1)
  if self.albumInfo.isInGame then
    EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_SELECTPHOTO, self.albumInfo.slot, self.albumInfo.index)
    return
  end
  if self.albumInfo.isSelectMode then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Selected, true)
    if self.albumInfo.isViewPicture then
      ShowNotice(4303053)
      return
    end
    EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_ADDCOVER, self.albumInfo.slot, self.albumInfo.index)
    return
  end
  EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_SELECTPHOTO, self.albumInfo.slot, self.index)
end

function UI_UGC_Mine_Photo_Picture_Item_New:OnClickButtonAI()
  if not LobbySystem.CheckOpen(BP_ENUM_UGC_AI_COVER_IMAGE_SWITCH) then
    return
  end
  self:PlayAudio(sound_config.click_v1)
  EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_OPENAIIMAGE, self.albumInfo.slot, self.albumInfo.index)
end

function UI_UGC_Mine_Photo_Picture_Item_New:OnClickButtonTop()
  self:PlayAudio(sound_config.click_v1)
  EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_SETCOVER, self.albumInfo.slot, self.albumInfo.index)
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.component.scroll_box_child_base")
return class(ui_base, nil, UI_UGC_Mine_Photo_Picture_Item_New)
