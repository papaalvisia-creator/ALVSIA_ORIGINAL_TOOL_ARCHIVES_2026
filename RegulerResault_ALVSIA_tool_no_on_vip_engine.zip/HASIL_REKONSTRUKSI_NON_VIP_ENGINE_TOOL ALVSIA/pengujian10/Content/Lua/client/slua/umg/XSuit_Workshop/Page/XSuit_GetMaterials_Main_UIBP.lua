local XSuit_GetMaterials_Main_UIBP = {}
local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
local CommonItem_Const = require("client.slua.component.item.ItemUtils.CommonItem_Const")

function XSuit_GetMaterials_Main_UIBP:ctor(_, period, branchId, bSkipOpenWorkshop)
  self.period = period
  self.branchId = branchId or 0
  self.bSkipOpenWorkshop = bSkipOpenWorkshop and true or false
end

function XSuit_GetMaterials_Main_UIBP:OnInitialize()
  self.selectPeriod = self.period or 0
  if self.UIRoot.TextBlock_Title then
    self.UIRoot.TextBlock_Title:SetText(LocUtil.GetLocalizeResStr(200000689))
  end
  self.loopScrollBox_Tabs = self:InitChildClassScrollBox(self.UIRoot.loopScrollBox_Tabs, "client.slua.umg.XSuit_Workshop.Item.XSuit_Side_Trials_Tab_Item_UIBP")
  self:SetTabData()
  self:HideUpgradeEffect()
end

function XSuit_GetMaterials_Main_UIBP:SetTabData()
  self.tabList = {}
  local configs = CDataTable.GetTableByFilter("XSuitCommonBranch", "IsBranch", 0)
  local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
  local maxPeriod = LogicXSuit.GetMaxPeriod()
  for _, config in pairs(configs or {}) do
    if config.Period and config.Period ~= 0 and maxPeriod >= config.Period then
      local tabData = {}
      for key, value in pairs(config) do
        tabData[key] = value
      end
      table.insert(self.tabList, tabData)
    end
  end
  table.sort(self.tabList, function(a, b)
    return (a.Period or 0) > (b.Period or 0)
  end)
  self:UpdateTabItemData()
  if self.loopScrollBox_Tabs then
    self.loopScrollBox_Tabs:SetData(self.tabList)
  end
end

function XSuit_GetMaterials_Main_UIBP:UpdateTabItemData()
  for _, data in ipairs(self.tabList or {}) do
    data.SpinRemainDays = self:GetSpinRemainDays(data.Period)
    data.bBranchSelected = self:IsPeriodBranchSelected(data.Period)
  end
end

function XSuit_GetMaterials_Main_UIBP:IsPeriodBranchSelected(period)
  if not period then
    return false
  end
  return LogicXSuit.GetActiveBranchIdByPeriod(period) ~= nil
end

function XSuit_GetMaterials_Main_UIBP:RefreshTabItemData()
  self:UpdateTabItemData()
  if self.loopScrollBox_Tabs then
    self.loopScrollBox_Tabs:RefreshAllItems()
  end
end

function XSuit_GetMaterials_Main_UIBP:GetSpinRemainDays(period)
  if not period then
    return 0
  end
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  if logic_xsuit_activity:GetCurrentPeriod() ~= period then
    return 0
  end
  local TimeUtil = require("client.common.time_util")
  local leftSec = (logic_xsuit_activity:GetDrawEndTime() or 0) - TimeUtil.GetServerTimeInSec()
  if leftSec <= 0 then
    return 0
  end
  return math.ceil(leftSec / 86400)
end

function XSuit_GetMaterials_Main_UIBP:GetTabIndexByPeriod(period)
  for index, data in ipairs(self.tabList or {}) do
    if data.Period == period then
      return index
    end
  end
  return nil
end

function XSuit_GetMaterials_Main_UIBP:SelectTabByPeriod(period)
  local tabList = self.tabList or {}
  if not self.loopScrollBox_Tabs or #tabList <= 0 then
    return
  end
  local index = period and self:GetTabIndexByPeriod(period) or nil
  index = index or 1
  self.selectPeriod = tabList[index].Period
  self.loopScrollBox_Tabs:Select(index)
  self.loopScrollBox_Tabs:ScrollToItem(index)
end

function XSuit_GetMaterials_Main_UIBP:GetTabBranchId(period)
  local activeBranchId = LogicXSuit.GetActiveBranchIdByPeriod(period)
  if activeBranchId ~= nil then
    return activeBranchId
  end
  return self.branchId or 0
end

function XSuit_GetMaterials_Main_UIBP:GetTabIconPath(period, branchId, tabData)
  if period and branchId ~= nil then
    local configs = CDataTable.GetTableByFilter("XSuitCommonBranch", "Period", period, "IsBranch", 1, "BranchId", branchId)
    for _, config in pairs(configs or {}) do
      if config.MissionTabIcon and config.MissionTabIcon ~= "" then
        return config.MissionTabIcon
      end
    end
  end
  if tabData and tabData.MissionTabIcon and tabData.MissionTabIcon ~= "" then
    return tabData.MissionTabIcon
  end
  return nil
end

function XSuit_GetMaterials_Main_UIBP:OnRefreshTabItem(widget, index, item)
  local data = item and item.data
  if not widget or not data then
    return
  end
  self:SetWidgetVisible(widget.Image_Select, data.Period == self.selectPeriod)
  local activeBranchId = LogicXSuit.GetActiveBranchIdByPeriod(data.Period)
  local branchId = self:GetTabBranchId(data.Period)
  if data.Period == self.selectPeriod then
    if activeBranchId then
      branchId = activeBranchId or branchId
    end
  else
    branchId = activeBranchId and activeBranchId or 0
  end
  local iconPath = self:GetTabIconPath(data.Period, branchId, data)
  if not iconPath then
    log(bWriteLog and string.format("XSuit_GetMaterials_Main_UIBP:OnRefreshTabItem no MissionTabIcon, period:%s, branch:%s", tostring(data.Period), tostring(branchId)))
    return
  end
  item:SetTexture(widget.Image_Bg, iconPath, {sync = false})
end

function XSuit_GetMaterials_Main_UIBP:OnSelectTabItem(index, itemData)
  if self._IsClosed or not self.UIRoot then
    return
  end
  local data = itemData and itemData
  if not data or data.Period == self.selectPeriod then
    return
  end
  local xsuit_trial_reddot = require("client.slua.logic.XSuit.xsuit_trial_reddot")
  xsuit_trial_reddot.MarkTabNewRead(self.selectPeriod)
  self.selectPeriod = data.Period
  self.loopScrollBox_Tabs:Select(index)
  self:RefreshTabItemData()
  self:InitMoneyComponent()
  self:ShowMissionPage()
end

function XSuit_GetMaterials_Main_UIBP:RegistEvents()
  self:AddOnClickedEventByControl(self.UIRoot.Button_Close, self.OnClickCloseBtn, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Help_02, self.OnButtonClick_Help, self)
  self:AddCommonEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_ACTIVE_BRANCH_UPDATE, self.OnActiveBranchUpdate, self)
  self:AddCommonEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_DRAW_ACTIVITY_UPDATE, self.OnDrawActivityUpdate, self)
end

function XSuit_GetMaterials_Main_UIBP:OnActiveBranchUpdate(_, _)
  if self._IsClosed or not self.UIRoot then
    return
  end
  self:RefreshTabItemData()
end

function XSuit_GetMaterials_Main_UIBP:OnDrawActivityUpdate(_, _)
  if self._IsClosed or not self.UIRoot then
    return
  end
  self:RefreshTabItemData()
end

function XSuit_GetMaterials_Main_UIBP:OnPostInitialize()
  self:SelectTabByPeriod(self.period)
  if not next(LogicXSuit.task_conf_info or {}) then
    local XSuitHandler = require("client.network.Protocol.XSuitHandler")
    XSuitHandler.send_gold_dress_task_info_req()
  end
  local xsuit_trial_reddot = require("client.slua.logic.XSuit.xsuit_trial_reddot")
  xsuit_trial_reddot.MarkNewReddotRead(self.selectPeriod)
  self:InitMoneyComponent()
  self:ShowMissionPage()
end

function XSuit_GetMaterials_Main_UIBP:GetMissionPageBP(period)
  local index = period and self:GetTabIndexByPeriod(period) or nil
  local data = index and self.tabList and self.tabList[index] or nil
  return data and data.MissionPageBP or nil
end

function XSuit_GetMaterials_Main_UIBP:ShowMissionPage()
  if self._IsClosed or not self.UIRoot then
    return
  end
  self:HideMissionPage(true)
  if self._IsClosed or not self.UIRoot then
    return
  end
  local pageBP = self:GetMissionPageBP(self.selectPeriod)
  if not pageBP or pageBP == "" then
    log(bWriteLog and string.format("XSuit_GetMaterials_Main_UIBP:ShowMissionPage no MissionPageBP, period=%s", tostring(self.selectPeriod)))
    return
  end
  local UIComponentModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule)
  local componentCfg = UIComponentModule.Config.XSuit_GetMaterials_Popup_UIBP
  if not componentCfg then
    log_error("XSuit_GetMaterials_Main_UIBP:ShowMissionPage no component cfg [XSuit_GetMaterials_Popup_UIBP]")
    return
  end
  self.MissionPageUI = self:CreateChildWindowWithLuaAndBpPath(self.UIRoot.Canvas_Panel_Main, UIManager.UI_Config.ChildUIWithoutLuaAndBpPath, componentCfg.LuaClassPath, pageBP, self.selectPeriod, self.branchId)
end

function XSuit_GetMaterials_Main_UIBP:HideMissionPage(bSkipNotifyParent)
  local pageUI = self.MissionPageUI
  self.MissionPageUI = nil
  if not pageUI then
    return
  end
  if bSkipNotifyParent then
    pageUI._bSkipNotifyParentClose = true
  end
  if not pageUI._IsClosed then
    pageUI:Close()
  end
end

function XSuit_GetMaterials_Main_UIBP:InitMoneyComponent()
  local coinIDList = {}
  local upgradeInfo = LogicXSuit.GetUpgradeInfo(self.selectPeriod, true, self.branchId)
  local config = upgradeInfo and upgradeInfo[2] and upgradeInfo[2].cfg
  if not config then
    log_error(string.format("XSuit_GetMaterials_Main_UIBP:InitMoneyComponent no upgrade cfg, period=%s branch=%s", tostring(self.selectPeriod), tostring(self.branchId)))
    self:RefreshCoinItems(coinIDList)
    return
  end
  if config.ActiveID2 > 0 and 0 < config.ActiveID1 then
    table.insert(coinIDList, config.ActiveID1)
    table.insert(coinIDList, config.ActiveID2)
  end
  local extraCountMap = {
    [config.ActiveID1] = config.ExclusiveID1,
    [config.ActiveID2] = config.ExclusiveID2
  }
  self:RefreshCoinItems(coinIDList, extraCountMap)
end

function XSuit_GetMaterials_Main_UIBP:GetCoinRoot()
  local coinRoot = self.UIRoot and self.UIRoot.HorizontalBox_CoinRoot
  if not coinRoot and self.UIRoot and self.UIRoot.GetWidgetFromName then
    coinRoot = self.UIRoot:GetWidgetFromName("HorizontalBox_CoinRoot")
  end
  if not coinRoot then
    return nil
  end
  return slua.isValid(coinRoot) and coinRoot or nil
end

function XSuit_GetMaterials_Main_UIBP:RefreshCoinItems(coinIDList, extraCountMap)
  coinIDList = coinIDList or {}
  local coinRoot = self:GetCoinRoot()
  if not coinRoot then
    log_error("XSuit_GetMaterials_Main_UIBP:RefreshCoinItems HorizontalBox_CoinRoot is nil")
    return
  end
  self.coinItems = self.coinItems or {}
  for index = 1, #coinIDList do
    if not self.coinItems[index] then
      self.coinItems[index] = self:CreateChildWindow(coinRoot, UIManager.UI_Config.StoreCoinItem)
    end
    local coinItem = self.coinItems[index]
    if coinItem then
      local coinId = coinIDList[index]
      local extraCountItemId = extraCountMap and extraCountMap[coinId] or nil
      coinItem:RefreshData(coinId, extraCountItemId)
      self:SetWidgetVisible(coinItem.UIRoot.Button_Jump, true, false)
    end
  end
  for index = #self.coinItems, #coinIDList + 1, -1 do
    self.coinItems[index]:Close()
    self.coinItems[index] = nil
  end
end

function XSuit_GetMaterials_Main_UIBP:GetWorkshopMainUI()
  local workshopUI = UIManager.GetUI(UIManager.UI_Config.XSuit_Workshop_Main_UIBP)
  if not workshopUI or workshopUI._IsClosed then
    return nil
  end
  return workshopUI
end

function XSuit_GetMaterials_Main_UIBP:OnButtonClick_Help()
  self:PlayAudio(sound_config.close_v1)
  local styleType, title, content = 1, LocUtil.LocalizeResFormat(200000689), LocUtil.LocalizeResFormat(200000817)
  UIManager.ShowUI(UIManager.UI_Config.HelpTip, 0, title, content)
end

function XSuit_GetMaterials_Main_UIBP:OnClickCloseBtn()
  self:PlayAudio(sound_config.click_v1)
  local period, branchId = self.selectPeriod, self.branchId
  local bSkipOpenWorkshop = self.bSkipOpenWorkshop
  local bWorkshopOpened = self:GetWorkshopMainUI() ~= nil
  self:CloseSelf()
  if not bWorkshopOpened and not bSkipOpenWorkshop then
    LogicXSuit.ShowUpgradeUI(period, branchId)
  end
end

function XSuit_GetMaterials_Main_UIBP:OnAndroidBack()
  self:OnClickCloseBtn()
end

function XSuit_GetMaterials_Main_UIBP:HideUpgradeEffect()
  self._bUpgradeEffectHidden = false
  local effectUI = UIManager.GetUI(UIManager.UI_Config.item_upgrade_effect)
  if not effectUI then
    return
  end
  local uiRoot = effectUI.UIRoot
  if uiRoot and uiRoot.IsVisible then
    local bOk, bVisible = pcall(uiRoot.IsVisible, uiRoot)
    if bOk and not bVisible then
      return
    end
  end
  effectUI:Hide()
  self._bUpgradeEffectHidden = true
  log(bWriteLog and "XSuit_GetMaterials_Main_UIBP:HideUpgradeEffect hide item_upgrade_effect")
end

function XSuit_GetMaterials_Main_UIBP:RestoreUpgradeEffect()
  if not self._bUpgradeEffectHidden then
    return
  end
  self._bUpgradeEffectHidden = false
  local effectUI = UIManager.GetUI(UIManager.UI_Config.item_upgrade_effect)
  if not effectUI then
    return
  end
  effectUI:SetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  log(bWriteLog and "XSuit_GetMaterials_Main_UIBP:RestoreUpgradeEffect restore item_upgrade_effect as SelfHitTestInvisible")
end

function XSuit_GetMaterials_Main_UIBP:OnClose()
  XSuit_GetMaterials_Main_UIBP.__super.OnClose(self)
  local xsuit_trial_reddot = require("client.slua.logic.XSuit.xsuit_trial_reddot")
  xsuit_trial_reddot.MarkTabNewRead(self.selectPeriod)
  for _, coinItem in pairs(self.coinItems or {}) do
    coinItem:Close()
  end
  self.coinItems = {}
  self:HideMissionPage(true)
  self:RestoreUpgradeEffect()
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CXSuit_GetMaterials_Main_UIBP = class(ui_base, nil, XSuit_GetMaterials_Main_UIBP)
return CXSuit_GetMaterials_Main_UIBP
