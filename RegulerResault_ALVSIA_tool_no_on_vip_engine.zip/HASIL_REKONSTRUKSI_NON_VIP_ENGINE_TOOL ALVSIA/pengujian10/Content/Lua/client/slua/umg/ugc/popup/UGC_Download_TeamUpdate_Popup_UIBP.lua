local UGC_Download_TeamUpdate_Popup_UIBP = {}
local SizeDiffThreshold = 0

function UGC_Download_TeamUpdate_Popup_UIBP:ctor()
end

function UGC_Download_TeamUpdate_Popup_UIBP:OnInitialize()
  UGC_Download_TeamUpdate_Popup_UIBP.__super.OnInitialize(self)
end

function UGC_Download_TeamUpdate_Popup_UIBP:RegistEvents()
  UGC_Download_TeamUpdate_Popup_UIBP.__super.RegistEvents(self)
end

function UGC_Download_TeamUpdate_Popup_UIBP:OnPostInitialize()
  UGC_Download_TeamUpdate_Popup_UIBP.__super.OnPostInitialize(self)
end

function UGC_Download_TeamUpdate_Popup_UIBP:OnClose()
end

function UGC_Download_TeamUpdate_Popup_UIBP:InitPakList()
  local ResManager = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager)
  local cSize, tSize = 0, 0
  local mapKeyList = ResManager:GetAllMapKeysByModInfo(self.modInfo)
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  local templateCSize, templateTSize = PufferManager.GetSize(PufferConst.ENUM_DownloadType.MAP, mapKeyList, nil, nil, true)
  cSize = cSize + templateCSize / PufferConst.MB
  tSize = tSize + templateTSize / PufferConst.MB
  local bundleCSize, bundleTSize, pakList = ResManager:GetUGCBundleSize()
  cSize = cSize + bundleCSize
  tSize = tSize + bundleTSize
  self.sizeToDownloadAll = tSize - cSize
  if self.sizeToDownloadAll < 0.1 then
    self.sizeToDownloadAll = 0.1
  end
  self.sizeToDownload = string.format("%.1f", self.sizeToDownloadAll)
  table.sort(pakList, function(a, b)
    local aPakId = a.pakId or 0
    local bPakId = b.pakId or 0
    return aPakId < bPakId
  end)
  local pakListTotalSize = 0
  for _, pakData in ipairs(pakList) do
    local paktSize = pakData.tSize or 0
    local pakcSize = pakData.cSize or 0
    pakListTotalSize = pakListTotalSize + (paktSize - pakcSize)
  end
  local diff = self.sizeToDownloadAll - pakListTotalSize
  if diff > SizeDiffThreshold then
    table.insert(pakList, {
      pakName = LocUtil.GetLocalizeResStr(65344),
      tSize = diff,
      cSize = 0,
      pakId = 0
    })
  end
  log(bWriteLog and "UGC_Download_Update_Popup_UIBP:InitPakList pakListTotalSize:" .. tostring(pakListTotalSize) .. " diff:" .. tostring(diff))
  self.pakList = pakList or {}
end

local class = require("class")
local UGC_Dowmload_Update_Popup_UIBP = require("client.slua.umg.ugc.popup.UGC_Dowmload_Update_Popup_UIBP")
local CUGC_Download_TeamUpdate_Popup_UIBP = class(UGC_Dowmload_Update_Popup_UIBP, nil, UGC_Download_TeamUpdate_Popup_UIBP)
return CUGC_Download_TeamUpdate_Popup_UIBP
