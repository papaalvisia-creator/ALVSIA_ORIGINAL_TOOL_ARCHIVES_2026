local XSuit_Active_Mission_UIBP = {}
local Traits = {
  require("client.slua.logic.XSuit.Traits.xsuit_money")
}
local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
local CommonItem_Const = require("client.slua.component.item.ItemUtils.CommonItem_Const")

function XSuit_Active_Mission_UIBP:ctor(_, period, branchId)
  self.Period = period
  self.branchId = branchId
end

function XSuit_Active_Mission_UIBP:OnInitialize()
  self.LoopScrollBox_Mission = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_Mission, "client.slua.umg.XSuit_Workshop.Item.XSuit_Active_Mission_Item")
end

function XSuit_Active_Mission_UIBP:RegistEvents()
  self:AddOnClickedEventByControl(self.UIRoot.Button_Close, self.OnButtonClick_Close, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Weekly, self.OnButtonClick_Mode, self, true)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Season, self.OnButtonClick_Mode, self, false)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Rule, self.OnButtonClick_Rule, self, false)
  self:AddCommonEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_MISSION_CONFIG_UPDATE, self.OnConfigsUpdate, self)
end

function XSuit_Active_Mission_UIBP:OnPostInitialize()
  self.branchConfig = LogicXSuit.GetUpgradeUIInfoByBranchId(self.Period, self.branchId)
  if not self.branchConfig then
    self:CloseSelf()
    return
  end
  self.UIRoot.TextBlock_4:SetText(LocUtil.GetLocalizeResStr(200000707))
  self.UIRoot.TextBlock_5:SetText(LocUtil.GetLocalizeResStr(200000707))
  self.UIRoot.TextBlock_6:SetText(LocUtil.GetLocalizeResStr(200000708))
  self.UIRoot.TextBlock_7:SetText(LocUtil.GetLocalizeResStr(200000708))
  self.UIRoot.TextBlock_Title:SetText(LocUtil.GetLocalizeResStr(self.branchConfig.MissionTitle))
  self:SetTexture(self.UIRoot.Image_Character, self.branchConfig.MissionCharacter, {sync = false})
  local upgradeInfo = LogicXSuit.GetUpgradeInfo(self.Period, true, self.branchId)
  local config = upgradeInfo[2].cfg
  self.coinExtraCountMap = {
    [config.ActiveID1] = config.ExclusiveID1,
    [config.ActiveID2] = config.ExclusiveID2
  }
  self:UpdateCurGroup({
    config.ActiveID1 > 0 and config.ActiveID1,
    config.ActiveID2 > 0 and config.ActiveID2
  })
  self.bWeek = true
  self.seasonMissionState = false
  self.weekMissionState = false
  self:SetMissionData()
  self:RefreshPage()
end

function XSuit_Active_Mission_UIBP:RefreshPage()
  self.UIRoot.WidgetSwitcher:SetActiveWidgetIndex(self.bWeek and 0 or 1)
  self.UIRoot.WidgetSwitcher_1:SetActiveWidgetIndex(self.bWeek and 1 or 0)
  local missionList = self.bWeek and self.weekMissionList or self.seasonMissionList
  for _, mission in ipairs(missionList) do
    mission.ItemBg = self.branchConfig.MissionItemBg
  end
  self:RefreshMissionDesc()
  self.LoopScrollBox_Mission:SetData(missionList)
  self.LoopScrollBox_Mission:Select(1)
  self.LoopScrollBox_Mission:ScrollToItem(1)
end

function XSuit_Active_Mission_UIBP:RefreshMissionDesc()
  local endTime = LogicXSuit.GetTaskEndTime(self.bWeek)
  local TimeUtil = require("client.common.time_util")
  if self.leftTimer then
    self:RemoveTimer(self.leftTimer)
    self.leftTimer = nil
  end
  local leftTime = endTime - TimeUtil.GetServerTimeInSec()
  self.UIRoot.TextBlock_Time:SetText(LocUtil.LocalizeResFormat(self.bWeek and 200000703 or 200000704, TimeUtil.FormatCountDownTime_D_or_HMS(leftTime, 1)))
  self.leftTimer = self:AddTimerLoop(0, function()
    local seasonEndTime = LogicXSuit.GetTaskEndTime(false)
    if seasonEndTime and 0 < seasonEndTime and 0 >= seasonEndTime - TimeUtil.GetServerTimeInSec() then
      self:RemoveTimer(self.leftTimer)
      self.leftTimer = nil
      ShowNotice(118100002)
      self:CloseSelf()
      return
    end
    leftTime = endTime - TimeUtil.GetServerTimeInSec()
    self.UIRoot.TextBlock_Time:SetText(LocUtil.LocalizeResFormat(self.bWeek and 200000703 or 200000704, TimeUtil.FormatCountDownTime_D_or_HMS(leftTime, 1)))
  end, 0, 1)
  local curValue, maxValue = 0, LogicXSuit.GetTaskMaxFinishValue(self.bWeek)
  local haveCanFinish = false
  for index, config in ipairs(self.bWeek and self.realWeekMissionList or self.realSeasonMissionList) do
    local stateData = LogicXSuit.GetTaskState(config.task_id, self.bWeek)
    if config.can_repeat_finish == 1 then
      curValue = curValue + (stateData.finish_count and (stateData.finish_count <= config.max_finish_count and stateData.finish_count or config.max_finish_count) or 0)
    elseif stateData.status ~= CommonItem_Const.Enum_ItemStatus.Not then
      curValue = curValue + 1
    end
    if stateData.status == CommonItem_Const.Enum_ItemStatus.Done and maxValue >= curValue then
      haveCanFinish = true
    end
  end
  self.UIRoot.TextBlock_Progress:SetText(LocUtil.LocalizeResFormat(self.bWeek and 200000705 or 200000706, maxValue < curValue and maxValue or curValue, maxValue))
  self.weekMissionState = maxValue <= curValue and self.bWeek and not haveCanFinish
  self.seasonMissionState = maxValue <= curValue and not self.bWeek and not haveCanFinish
end

function XSuit_Active_Mission_UIBP:SetMissionData()
  self.weekMissionList, self.seasonMissionList, self.realWeekMissionList, self.realSeasonMissionList = LogicXSuit.GetTaskConfig()
end

function XSuit_Active_Mission_UIBP:OnButtonClick_Mode(bWeek)
  self:PlayAudio(sound_config.click_v1)
  if self.bWeek == bWeek then
    return
  end
  self.bWeek = bWeek
  self:RefreshPage()
end

function XSuit_Active_Mission_UIBP:OnButtonClick_Close()
  self:PlayAudio(sound_config.click_v1)
  self:CloseSelf()
end

function XSuit_Active_Mission_UIBP:OnButtonClick_Rule()
  self:PlayAudio(sound_config.click_v1)
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  local styleType, title, msg = 1, LocUtil.LocalizeResFormat(200000687), LocUtil.LocalizeResFormat(200000817)
  CommonMsgBoxMgr.Show(styleType, title, msg, nil, nil, nil, nil, {
    showUIKey = "Com_MsgBox_Middle_Slua_UIBP"
  })
end

function XSuit_Active_Mission_UIBP:OnConfigsUpdate(_, _)
  self:SetMissionData()
  self:RefreshPage()
end

local ui_base = require("client.slua_ui_framework.base")
local Trait = require("common.trait")
local CXSuit_Active_Mission_UIBP = Trait.TraitClass(ui_base, nil, XSuit_Active_Mission_UIBP, Traits)
return CXSuit_Active_Mission_UIBP
