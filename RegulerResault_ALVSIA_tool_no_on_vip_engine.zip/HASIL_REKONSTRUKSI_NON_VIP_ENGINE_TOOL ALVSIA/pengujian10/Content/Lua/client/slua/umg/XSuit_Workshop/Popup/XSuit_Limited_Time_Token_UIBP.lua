local XSuit_Limited_Time_Token_UIBP = {}
local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")

function XSuit_Limited_Time_Token_UIBP:ctor(_, period, branchId, itemId)
  self.period = period and period or 0
  self.branchId = branchId and branchId or 0
  self.itemId = itemId
end

function XSuit_Limited_Time_Token_UIBP:RegistEvents()
  self:AddOnClickedEventByControl(self.UIRoot.Common_Popup_Medium_UIBP.close, self.OnButtonClick_Close, self)
end

function XSuit_Limited_Time_Token_UIBP:OnInitialize()
  self.coinInfoList = LogicXSuit.GetUpgradeUICoinInfo(self.period) or {}
  self.LoopScrollBox_ItemList = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_ItemList, "client.slua.umg.XSuit_Workshop.Item.XSuit_Limited_Time_Token_Item")
  self.LoopScrollBox_ItemList:SetData(self.coinInfoList)
end

function XSuit_Limited_Time_Token_UIBP:OnPostInitialize()
  self.UIRoot.UTRichTextBlock_Desc:SetText(LocUtil.GetLocalizeResStr(18141430))
  self.UIRoot.Common_Popup_Medium_UIBP.Title:SetText(LocUtil.GetLocalizeResStr(18141459))
  self:LocateCoinItem()
end

function XSuit_Limited_Time_Token_UIBP:LocateCoinItem()
  if not self.itemId or not self.coinInfoList then
    return
  end
  for index, coinInfo in ipairs(self.coinInfoList) do
    if coinInfo.itemId == self.itemId then
      self.LoopScrollBox_ItemList:Select(index)
      self.LoopScrollBox_ItemList:ScrollToItem(index)
      return
    end
  end
  log(bWriteLog and string.format("XSuit_Limited_Time_Token_UIBP:LocateCoinItem not found, period=%s, itemId=%s", tostring(self.period), tostring(self.itemId)))
end

function XSuit_Limited_Time_Token_UIBP:OnButtonClick_Close()
  self:PlayAudio(sound_config.click_v1)
  self:CloseSelf()
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CXSuit_Limited_Time_Token_UIBP = class(ui_base, nil, XSuit_Limited_Time_Token_UIBP)
return CXSuit_Limited_Time_Token_UIBP
