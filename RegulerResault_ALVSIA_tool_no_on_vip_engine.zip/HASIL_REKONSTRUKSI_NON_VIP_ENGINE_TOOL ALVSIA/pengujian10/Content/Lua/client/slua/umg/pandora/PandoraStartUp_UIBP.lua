local pandora_v2_adapter = require("client.slua.logic.Pandora.pandora_v2_adapter")
local pandora_v2_define = require("client.slua.logic.Pandora.pandara_v2_define")
local ActivityStatus = pandora_v2_define.ActivityStatus
local DEFAULT_BG = "/Game/Mod/Lobby/Split/NewActivity/UMG/Texture/Lobby_NoAtlas/NewActivty/NewActivty_Default_BG1.NewActivty_Default_BG1"
local PandoraStartUp_UIBP = {}
local ENUM_BUTTON_SLOT = {
  Not = 0,
  Downloading = 1,
  Done = 2
}
local PROGRESS_POLL_INTERVAL = 0.5

function PandoraStartUp_UIBP:ctor(_, data, isNotice, originParams)
  self._tActData = data
  self._bIsNotice = isNotice
  self._originParams = originParams or {}
  self._activityName = nil
  self._nProgressTimer = nil
  self._bDownloading = false
  self._startUpOkCallback = data and data.startUpOkCallback
  self._originUIKeyName = data and data.originUIKeyName
  self._fullScreen = data and data.fullScreen
  self._nPercent = 0
  self._nBGDownloadIndex = nil
  self._bNotFromActivityCenter = data and data.notFromActivityCenter
  if self._bNotFromActivityCenter then
    local pandora_utils = require("client.slua.logic.Pandora.pandora_utils")
    self._activityName = pandora_utils.GetActNameByPandoraActId(data.pandoraActId)
  else
    self._activityName = nil
    local url = data and data.ImgLink
    if url and url ~= "" then
      self._activityName = pandora_v2_adapter:ResolveActivityName(url)
    end
  end
end

function PandoraStartUp_UIBP:RegistEvents()
  PandoraStartUp_UIBP.__super.RegistEvents(self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Download, self.OnDownloadButtonClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Enter, self.OnEnterButtonClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.close, self.OnCloseButtonClick, self)
end

function PandoraStartUp_UIBP:OnPostInitialize()
  self:SetWidgetVisible(self.UIRoot.close, self._fullScreen, true)
  if self._fullScreen then
    self:SetWidgetVisible(self.UIRoot.Image_BG, true, false)
    self:_SetActivityBGImage()
  else
    self:SetWidgetVisible(self.UIRoot.Image_BG, false, false)
  end
  PandoraStartUp_UIBP.__super.OnPostInitialize(self)
  self.UIRoot.TextBlock_111:SetText(LocUtil.GetLocalizeResStr(7420))
  self.UIRoot.TextBlock_2:SetText(LocUtil.GetLocalizeResStr(4995))
  self:SetWidgetVisible(self.UIRoot.Image_xiaobao, true, false)
  self:RefreshButtonShow()
end

function PandoraStartUp_UIBP:OnClose()
  self:_StopProgressPolling()
  if self._nBGDownloadIndex and self._nBGDownloadIndex > 0 then
    self:CancelImageDownloadByIndex(self._nBGDownloadIndex)
    self._nBGDownloadIndex = nil
  end
  if self.UIRoot and self.UIRoot.Image_BG then
    self.UIRoot.Image_BG:SetBrushFromTexture(nil, false)
  end
  PandoraStartUp_UIBP.__super.OnClose(self)
end

function PandoraStartUp_UIBP:OnDownloadButtonClick()
  self:PlayAudio(sound_config.click)
  if self._bDownloading then
    log(bWriteLog and "PandoraStartUp_UIBP:OnDownloadButtonClick. already downloading, ignore")
    return
  end
  self:_StartDownload()
end

function PandoraStartUp_UIBP:OnEnterButtonClick()
  self:PlayAudio(sound_config.click)
  if self._startUpOkCallback and type(self._startUpOkCallback) == "function" then
    self._startUpOkCallback()
    self:CloseSelf()
    return
  end
  if not self._bNotFromActivityCenter then
    local parentUI = self:GetParentUI()
    local bCanRemount = parentUI ~= nil and parentUI.ShowCurActUI ~= nil
    log(bWriteLog and string.format("[PandoraStartUp] PandoraStartUp_UIBP:OnEnterButtonClick. activity=%s canRemount=%s", tostring(self._activityName), tostring(bCanRemount)))
    if bCanRemount then
      local UIKeyName = self._originUIKeyName or "PandoraContainer_UIBP"
      parentUI:ShowCurActUI(UIKeyName, self._tActData, self._bIsNotice, self._originParams, true)
      return
    end
  end
  self:CloseSelf()
end

function PandoraStartUp_UIBP:OnCloseButtonClick()
  self:PlayAudio(sound_config.click)
  self:CloseSelf()
end

function PandoraStartUp_UIBP:_StartDownload()
  local activityName = self._activityName
  if not activityName or activityName == "" then
    log_error("PandoraStartUp_UIBP:_StartDownload. activityName is empty")
    return
  end
  self._bDownloading = true
  self._nPercent = 0
  self:_ShowDownloading(0)
  self:_StartProgressPolling()
  pandora_v2_adapter:UpdateActivityAndLoad(activityName, function(statusJson)
    if not slua.isValid(self.UIRoot) then
      return
    end
    local nPercent = self:_ParsePercent(statusJson)
    if nPercent then
      self._nPercent = nPercent
      self:_ShowDownloading(self._nPercent)
    end
  end, function(bSuccess, errMsg)
    if not slua.isValid(self.UIRoot) then
      return
    end
    if bSuccess then
      self:_OnDownloadFinished()
      return
    end
    log(bWriteLog and string.format("PandoraStartUp_UIBP:_StartDownload. failed activity=%s err=%s", tostring(activityName), tostring(errMsg)))
    self:_OnDownloadFailed()
  end)
end

function PandoraStartUp_UIBP:_OnDownloadFinished()
  log(bWriteLog and "PandoraStartUp_UIBP:_OnDownloadFinished")
  self._bDownloading = false
  self:_StopProgressPolling()
  self:_ShowEnterButton()
end

function PandoraStartUp_UIBP:_OnDownloadFailed()
  self._bDownloading = false
  self:_StopProgressPolling()
  self:_ShowDownloadButton()
end

function PandoraStartUp_UIBP:_StartProgressPolling()
  self:_StopProgressPolling()
  self._nProgressTimer = self:AddTimerLoop(PROGRESS_POLL_INTERVAL, function()
    self:_PollProgress()
  end, 0, PROGRESS_POLL_INTERVAL)
end

function PandoraStartUp_UIBP:_StopProgressPolling()
  if self._nProgressTimer then
    self:RemoveTimer(self._nProgressTimer)
    self._nProgressTimer = nil
  end
end

function PandoraStartUp_UIBP:_PollProgress()
  if not slua.isValid(self.UIRoot) then
    self:_StopProgressPolling()
    return
  end
  local nStatus, nPercent = self:_QueryActivityStatus()
  if nStatus == ActivityStatus.Mounted then
    self:_OnDownloadFinished()
    return
  end
  if nStatus == ActivityStatus.UpdateFailed or nStatus == ActivityStatus.MountFailed then
    self:_OnDownloadFailed()
    return
  end
  if nPercent and nPercent >= (self._nPercent or 0) then
    self._nPercent = nPercent
  end
  self:_ShowDownloading(self._nPercent)
end

function PandoraStartUp_UIBP:_GetPandoraActData()
  local data = self._tActData
  if not data then
    return nil
  end
  if data.ImgUrl then
    return data
  end
  local pandoraActId = tonumber(data.pandoraActId)
  if not pandoraActId or pandoraActId == 0 then
    return nil
  end
  local pandoraSystem = require("client.slua.logic.Pandora.pandora_system")
  local activityId = pandoraSystem.pandora2Id[pandoraActId]
  if not activityId then
    printf("[PandoraStartUp] PandoraStartUp_UIBP:_GetPandoraActData. actId:%s not mapped yet", tostring(pandoraActId))
    return nil
  end
  log(bWriteLog and string.format("[PandoraStartUp] PandoraStartUp_UIBP:_GetPandoraActData. activityId:%s pandoraActId:%s", tostring(activityId), tostring(pandoraActId)))
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  return ActivityNewSystem.GetActivityByID(activityId)
end

function PandoraStartUp_UIBP:_SetActivityBGImage()
  local Image_BG = self.UIRoot and self.UIRoot.Image_BG
  if not Image_BG then
    log_error("PandoraStartUp_UIBP:_SetActivityBGImage. Image_BG is nil")
    return
  end
  local actData = self:_GetPandoraActData()
  log_tree("PandoraStartUp_UIBP:_SetActivityBGImage. actData:", actData)
  printf("PandoraStartUp_UIBP:_SetActivityBGImage. pandoraActId:%s hasActData:%s imgUrl:%s type:%s", tostring(self._tActData and self._tActData.pandoraActId), tostring(actData ~= nil), tostring(actData and actData.ImgUrl), tostring(actData and actData.Type))
  local sUrl = actData and actData.ImgUrl or ""
  local ActivityUtil = require("client.slua.logic.activity.ActivityUtil")
  local sDefaultBg = ActivityUtil.GetDefaultBg(actData, nil) or DEFAULT_BG
  Image_BG:SetColorAndOpacity(FLinearColor(1, 1, 1, 1))
  if not sUrl or sUrl == "" then
    log(bWriteLog and "[PandoraStartUp] PandoraStartUp_UIBP:_SetActivityBGImage. no ImgUrl, use default bg")
    self:SetTexture(Image_BG, sDefaultBg, {bMatchSize = true})
    return
  end
  printf("[PandoraStartUp] PandoraStartUp_UIBP:_SetActivityBGImage. url:%s", tostring(sUrl))
  local params = {
    needLocalize = true,
    bMatchSize = true,
    onDownloadFail = function(downloadUrl)
      printf("PandoraStartUp_UIBP:_SetActivityBGImage. download fail url:%s", tostring(downloadUrl))
      if slua.isValid(self.UIRoot) then
        self:SetTexture(self.UIRoot.Image_BG, sDefaultBg, {bMatchSize = true})
      end
    end
  }
  local nIndex = self:SetTexture(Image_BG, sUrl, params)
  if nIndex and 0 < nIndex then
    self._nBGDownloadIndex = nIndex
  end
end

function PandoraStartUp_UIBP:_QueryActivityStatus()
  local activityName = self._activityName
  if not activityName or activityName == "" then
    return nil, nil
  end
  local raw = pandora_v2_adapter:GetActivityStatus(activityName)
  return self:_ParseStatus(raw)
end

function PandoraStartUp_UIBP:_ParseStatus(raw)
  local data = raw
  if type(raw) == "string" then
    local ok
    ok, data = pcall(json.decode, raw)
    if not ok then
      data = nil
    end
  end
  if type(data) ~= "table" then
    return nil, nil
  end
  return data.status, self:_CalcPercent(data)
end

function PandoraStartUp_UIBP:_CalcPercent(data)
  if type(data) ~= "table" then
    return nil
  end
  local nDirect = data.percent or data.downloadProgress or data.ratio
  if type(data.progress) == "number" and not nDirect then
    nDirect = data.progress
  end
  nDirect = self:_NormalizePercent(nDirect)
  if nDirect then
    return nDirect
  end
  local nBytes = self:_PercentByCount(data.downloadedBytes, data.totalBytes)
  if nBytes then
    return nBytes
  end
  if type(data.dependencies) == "table" then
    local nGot, nTotal = 0, 0
    for _, tDep in pairs(data.dependencies) do
      if type(tDep) == "table" then
        local nDepTotal = tonumber(tDep.totalBytes) or 0
        if 0 < nDepTotal then
          nGot = nGot + (tonumber(tDep.downloadedBytes) or 0)
          nTotal = nTotal + nDepTotal
        end
      end
    end
    local nDepPercent = self:_PercentByCount(nGot, nTotal)
    if nDepPercent then
      return nDepPercent
    end
  end
  return self:_PercentByCount(data.updatedCount, data.totalCount)
end

function PandoraStartUp_UIBP:_PercentByCount(nCurrent, nTotal)
  nCurrent = tonumber(nCurrent)
  nTotal = tonumber(nTotal)
  if not (nCurrent and nTotal) or nTotal <= 0 then
    return nil
  end
  return self:_NormalizePercent(nCurrent / nTotal)
end

function PandoraStartUp_UIBP:_ParsePercent(statusJson)
  local _, nPercent = self:_ParseStatus(statusJson)
  return nPercent
end

function PandoraStartUp_UIBP:_NormalizePercent(percent)
  if type(percent) ~= "number" then
    return nil
  end
  if 1 < percent then
    percent = percent / 100
  end
  if percent < 0 then
    return 0
  end
  if 1 < percent then
    return 1
  end
  return percent
end

function PandoraStartUp_UIBP:RefreshButtonShow()
  local activityName = self._activityName
  if not activityName or activityName == "" then
    log_error("PandoraStartUp_UIBP:RefreshButtonShow. activityName is empty")
    self:_ShowDownloadButton()
    return
  end
  local nStatus = self:_QueryActivityStatus()
  log(bWriteLog and string.format("[PandoraStartUp] PandoraStartUp_UIBP:RefreshButtonShow. activity=%s status=%s", tostring(activityName), tostring(nStatus)))
  if nStatus == ActivityStatus.Mounted then
    self:_ShowEnterButton()
  elseif nStatus == ActivityStatus.Updating then
    self._bDownloading = true
    self:_ShowDownloading(self._nPercent)
    self:_StartProgressPolling()
  else
    self:_ShowDownloadButton()
  end
end

function PandoraStartUp_UIBP:_ShowDownloadButton()
  self.UIRoot.WidgetSwitcher_1:SetActiveWidgetIndex(ENUM_BUTTON_SLOT.Not)
end

function PandoraStartUp_UIBP:_ShowDownloading(nPercent)
  nPercent = nPercent or 0
  local node_root = self.UIRoot
  node_root.WidgetSwitcher_1:SetActiveWidgetIndex(ENUM_BUTTON_SLOT.Downloading)
  node_root.ProgressBar_0:SetPercent(nPercent)
  node_root.TextBlock_137:SetText(string.format("%d%%", math.floor(nPercent * 100)))
end

function PandoraStartUp_UIBP:_ShowEnterButton()
  self.UIRoot.WidgetSwitcher_1:SetActiveWidgetIndex(ENUM_BUTTON_SLOT.Done)
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CPandoraStartUp_UIBP = class(ui_base, nil, PandoraStartUp_UIBP)
return CPandoraStartUp_UIBP
