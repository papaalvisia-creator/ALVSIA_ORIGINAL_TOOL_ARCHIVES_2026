local XSuit_GetMaterials_Popup_UIBP = {}
local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
local CommonItem_Const = require("client.slua.component.item.ItemUtils.CommonItem_Const")
local ButtonStyleConfig = require("client.slua.component.button.Common_Button_Style_Config")
local XSuitHandler = require("client.network.Protocol.XSuitHandler")
local TRIAL_BUTTON_DIM_OPACITY = 0.5
local FIRST_ENTER_PREFS_PREFIX = "FirstEnterTask_"
local DESC_LOC_KEY = {
  bOwnEnough = 18141442,
  bOwnNeedTask = 18141441,
  bOwnMaxLevel = 18141443,
  bNotOwnDrawing = 18141446,
  bNotOwnDrawingWithFeature = 18141447,
  bNotOwnDrawingOneStar = 18141448,
  bNotOwnNoDrawing = 18141449,
  bNotOwnNoWay = 18141450,
  costText = 8500184,
  costNeed = 18141494,
  trialBtnText = 9983,
  trialBtnGetSuit = 27156,
  trialBtnGoGet = 18141444,
  trialBtnSelectBranch = 18141433,
  notSelectBranch = 99010131
}

function XSuit_GetMaterials_Popup_UIBP:ctor(_, period, branchId)
  self.period = period
  self.branchId = branchId or 0
  self.bWeek = true
end

function XSuit_GetMaterials_Popup_UIBP:OnInitialize()
  local SeasonSystem = require("client.logic.season.logic_season")
  SeasonSystem.Enter()
  itemModuleName = "client.slua.umg.XSuit_Workshop.Item.XSuit_GetMaterials_Item_UIBP"
  if self.UIRoot.LoopScrollBox_Mission then
    self.LoopScrollBox_Mission = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_Mission, itemModuleName)
  end
  if self.UIRoot.LoopScrollBox_Task_Item then
    self.LoopScrollBox_Task_Item = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_Task_Item, itemModuleName)
  end
end

function XSuit_GetMaterials_Popup_UIBP:RegistEvents()
  if self.UIRoot.Button_Weekly then
    self:AddOnClickedEventByControl(self.UIRoot.Button_Weekly, self.OnButtonClick_Mode, self, true)
  end
  if self.UIRoot.Button_Season then
    self:AddOnClickedEventByControl(self.UIRoot.Button_Season, self.OnButtonClick_Mode, self, false)
  end
  self:AddCommonEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_MISSION_CONFIG_UPDATE, self.OnConfigsUpdate, self)
  if self.UIRoot.Lua_Common_Button_Trial_Description then
    self.UIRoot.Lua_Common_Button_Trial_Description:SetBtnClick(self.OnClickTrialButton, self)
  end
  self:AddCommonEvent(EVENTTYPE_GOLDEN_SUIT, EVENTID_GOLDEN_SUIT_UPGRADE_SUCCESS, self.OnUpgradeSuccess, self)
  self:AddCommonEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_ACTIVE_BRANCH_UPDATE, self.OnActiveBranchUpdate, self)
end

function XSuit_GetMaterials_Popup_UIBP:OnConfigsUpdate(_, _)
  if self._IsClosed or not self.UIRoot then
    return
  end
  self:SetMissionData()
  self:RefreshPage()
end

function XSuit_GetMaterials_Popup_UIBP:OnPostInitialize()
  self.UIRoot.TextBlock_4:SetText(LocUtil.GetLocalizeResStr(200000707))
  self.UIRoot.TextBlock_5:SetText(LocUtil.GetLocalizeResStr(200000707))
  self.UIRoot.TextBlock_6:SetText(LocUtil.GetLocalizeResStr(200000708))
  self.UIRoot.TextBlock_7:SetText(LocUtil.GetLocalizeResStr(200000708))
  if self.UIRoot.UTRichTextBlock_Tips_Desc then
    self.UIRoot.UTRichTextBlock_Tips_Desc:SetText(LocUtil.GetLocalizeResStr(18141438))
  end
  self.branchConfig = LogicXSuit.GetUpgradeUIInfoByBranchId(self.period, self.branchId)
  self.characterImagePath = nil
  self:InitTrialDescriptionButton()
  self:SetMissionData()
  self:RefreshPage()
  self:TryShowFirstEnterSlapUI()
end

local FIRST_ENTER_SHOWN_PREFS_KEY = "FirstEnterTask_Shown"
local FIRST_ENTER_LEGACY_MAX_PERIOD = 30

local function _GetAccountKey()
  local roleData = DataMgr and DataMgr.roleData
  if not roleData then
    return nil
  end
  local accountId = roleData.openID
  if not accountId or accountId == "" then
    accountId = roleData.uid
  end
  if accountId and accountId ~= "" and accountId ~= 0 then
    return tostring(accountId)
  end
  return nil
end

local function _GetFirstEnterPrefsKey(accountId)
  return FIRST_ENTER_SHOWN_PREFS_KEY .. "_" .. tostring(accountId)
end

local function _HasShownFirstEnterSlapUI(data, accountId)
  if data[_GetFirstEnterPrefsKey(accountId)] then
    return true
  end
  for periodId = 1, FIRST_ENTER_LEGACY_MAX_PERIOD do
    if data[FIRST_ENTER_PREFS_PREFIX .. tostring(periodId) .. "_" .. tostring(accountId)] then
      return true
    end
  end
  return false
end

function XSuit_GetMaterials_Popup_UIBP:TryShowFirstEnterSlapUI()
  if not self.period or self.period ~= 17 then
    return
  end
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local prefsType = PlayerPrefsSystem.ePlayerPrefsType.eXsuitGuide
  local data = PlayerPrefsSystem.LoadFileToTable_N(prefsType) or {}
  local uiConfig = UIManager.UI_Config.XSuit_Popup_Theme_Explain_4700_UIBP
  if not uiConfig then
    log_error("XSuit_GetMaterials_Popup_UIBP:TryShowFirstEnterSlapUI no ui config [XSuit_Popup_Theme_Explain_4700_UIBP]")
    return
  end
  local accountId = _GetAccountKey()
  if not accountId then
    log_error("XSuit_GetMaterials_Popup_UIBP:TryShowFirstEnterSlapUI no account id, skip. period:" .. tostring(self.period))
    return
  end
  if _HasShownFirstEnterSlapUI(data, accountId) then
    log(bWriteLog and "XSuit_GetMaterials_Popup_UIBP:TryShowFirstEnterSlapUI already shown. account:" .. tostring(accountId))
    return
  end
  local prefsKey = _GetFirstEnterPrefsKey(accountId)
  data[prefsKey] = true
  PlayerPrefsSystem.SaveTableToFile_N(data, prefsType)
  log(bWriteLog and "XSuit_GetMaterials_Popup_UIBP:TryShowFirstEnterSlapUI show. key:" .. tostring(prefsKey) .. " period:" .. tostring(self.period) .. " branchId:" .. tostring(self.branchId))
  UIManager.ShowUI(UIManager.UI_Config.XSuit_Popup_Theme_Explain_4700_UIBP, nil, nil, self.period, self.branchId)
end

function XSuit_GetMaterials_Popup_UIBP:InitTrialDescriptionButton()
  local trialButton = self.UIRoot.Lua_Common_Button_Trial_Description
  if not trialButton then
    return
  end
  trialButton:SetBtnStyle(ButtonStyleConfig.ENUM_BTN_TYPE.Lv1Rec)
  self:RefreshTrialButtonText()
end

function XSuit_GetMaterials_Popup_UIBP:IsBranchMaxLevel(branchId, curLevel)
  if branchId == nil then
    return false
  end
  curLevel = curLevel or LogicXSuit.GetLevelByPeriodSelf(self.period, branchId) or 0
  if curLevel <= 0 then
    return false
  end
  local maxLevel = LogicXSuit.GetActSuitMaxLevelByPeriod(self.period, branchId) or 0
  if 0 < maxLevel and curLevel >= maxLevel then
    return true
  end
  local periodInfo = LogicXSuit.upgradeInfo and LogicXSuit.upgradeInfo[self.period]
  local branchInfo = periodInfo and periodInfo[branchId]
  return branchInfo ~= nil and branchInfo[curLevel + 1] == nil
end

function XSuit_GetMaterials_Popup_UIBP:IsUpgradeEnoughWithMakeUp(branchId)
  if branchId == nil then
    return false
  end
  local curLevel = LogicXSuit.GetLevelByPeriodSelf(self.period, branchId) or 0
  local startLevel = 0 < curLevel and curLevel or 1
  if self:IsBranchMaxLevel(branchId, curLevel) then
    return false
  end
  local materialInfo = LogicXSuit.BuildMaterialInfo(self.period, branchId, startLevel + 1)
  return materialInfo and materialInfo.bUpgrade and true or false
end

function XSuit_GetMaterials_Popup_UIBP:RefreshTrialButtonText()
  local trialButton = self.UIRoot.Lua_Common_Button_Trial_Description
  if not trialButton then
    return
  end
  local locKey = DESC_LOC_KEY.trialBtnSelectBranch
  local opacity = 1
  local branchId = LogicXSuit.GetActiveBranchIdByPeriod(self.period)
  if branchId ~= nil then
    local curLevel = LogicXSuit.GetLevelByPeriodSelf(self.period, branchId) or 0
    locKey = DESC_LOC_KEY.trialBtnText
    if curLevel <= 0 then
      locKey = DESC_LOC_KEY.trialBtnGetSuit
      if not self:CheckXSuitSpinJumpable(false) then
        opacity = TRIAL_BUTTON_DIM_OPACITY
      end
    elseif self:IsBranchMaxLevel(branchId, curLevel) then
      locKey = DESC_LOC_KEY.trialBtnGoGet
    elseif not self:IsUpgradeEnoughWithMakeUp(branchId) then
      opacity = TRIAL_BUTTON_DIM_OPACITY
    end
  end
  trialButton:SetBtnText(LocUtil.GetLocalizeResStr(locKey))
  trialButton:SetBtnOpacity(opacity)
end

function XSuit_GetMaterials_Popup_UIBP:OnClickTrialButton()
  local branchId = LogicXSuit.GetActiveBranchIdByPeriod(self.period)
  if branchId == nil then
    self:PlayAudio(sound_config.click_v1)
    LogicXSuit.ShowSelectBranchUI(self.period)
    return
  end
  local curLevel = LogicXSuit.GetLevelByPeriodSelf(self.period, branchId) or 0
  if curLevel <= 0 or self:IsBranchMaxLevel(branchId, curLevel) then
    if not self:CheckXSuitSpinJumpable(true) then
      return
    end
    self:PlayAudio(sound_config.click_v1)
    self:JumpToXSuitSpin()
    return
  end
  if not self:IsUpgradeEnoughWithMakeUp(branchId) then
    return
  end
  local UIUtil = require("client.common.ui_util")
  if not UIUtil.CanClickNow(UIUtil.ClickFrequencyLimit.XSuit_Workshop_Upgrade_Component) then
    return
  end
  self:PlayAudio(sound_config.click_v1)
  if branchId == LogicXSuit.GetActiveBranchIdByPeriod(self.period) and curLevel <= 1 then
    LogicXSuit.ShowActiveBranchUpgradeConfirm(function()
      self:UpgradeByCommonMaterial(branchId)
    end)
    return
  end
  self:UpgradeByCommonMaterial(branchId)
end

function XSuit_GetMaterials_Popup_UIBP:CheckXSuitSpinJumpable(isShowNotice)
  local xsuit_config_and_cache = require("client.slua.logic.XSuit.xsuit_config_and_cache")
  if not self.period or not xsuit_config_and_cache.GetNowPoolConfigByPeriod(self.period) then
    log(bWriteLog and string.format("XSuit_GetMaterials_Popup_UIBP:CheckXSuitSpinJumpable no pool config, period:%s", tostring(self.period)))
    if isShowNotice then
      ShowNotice(8262)
    end
    return false
  end
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local info = ActivityNewSystem.GetActivityInfoByModuleID(BP_ENUM_MODULE_XSUIT_SPIN)
  if not info then
    if isShowNotice then
      ShowNotice(7809)
    end
    return false
  end
  local TimeUtil = require("client.common.time_util")
  local serverTime = TimeUtil.GetServerTimeInSec()
  local nStartTime = info.StartTimeUTC or info.StartTime or 0
  local nEndTime = info.EndTimeUTC or info.EndTime
  if not nEndTime or serverTime > nEndTime then
    if isShowNotice then
      ShowNotice(8262)
    end
    return false
  end
  if 0 < nStartTime and serverTime < nStartTime then
    if isShowNotice then
      ShowNotice(120106)
    end
    return false
  end
  return true
end

function XSuit_GetMaterials_Popup_UIBP:UpgradeByCommonMaterial(branchId)
  local curLevel = LogicXSuit.GetLevelByPeriodSelf(self.period, branchId) or 0
  local nextLevel = (0 < curLevel and curLevel or 1) + 1
  local materialInfo = LogicXSuit.BuildMaterialInfo(self.period, branchId, nextLevel)
  if not (materialInfo and next(materialInfo)) or not materialInfo.bUpgrade then
    ShowNotice(9009)
    return
  end
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  local styleType, title, msg, clickOkCallback, extraData = 2, LocUtil.LocalizeResFormat(5077), nil, nil, {}
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  if materialInfo.bNeedMakeUp then
    if materialInfo.bCanMakeUp then
      if 0 < materialInfo.needCurrency then
        local costCurrency = CDataTable.GetTableData("Item", logic_xsuit_activity:GetDrawCurrencyID() or 1703269)
        extraData.explain = LocUtil.LocalizeResFormat(200000370, costCurrency.ItemName)
        msg = LocUtil.LocalizeResFormat(200000240, materialInfo.needCurrency)
        
        function clickOkCallback()
          XSuitHandler.send_do_onshot_exchange_by_activity_id_req(logic_xsuit_activity:GetExchangeActivityID(), materialInfo.exchangeList)
        end
        
        CommonMsgBoxMgr.Show(styleType, title, msg, clickOkCallback, nil, nil, nil, extraData)
      else
        local itemID = LogicXSuit.GetItemIDByLevel(self.period, nextLevel, branchId)
        if not itemID then
          log_error(string.format("XSuit_GetMaterials_Popup_UIBP:UpgradeByCommonMaterial no itemID. period=%s, level=%s, branch=%s", tostring(self.period), tostring(nextLevel), tostring(branchId)))
          return
        end
        UIManager.ShowUI(UIManager.UI_Config.XSuit_Active_Exchange_UIBP, materialInfo.makeUpList, itemID, function()
          if materialInfo.needCurrency <= 0 then
            return
          end
          local costCurrency = CDataTable.GetTableData("Item", logic_xsuit_activity:GetDrawCurrencyID() or 1703269)
          extraData.explain = LocUtil.LocalizeResFormat(200000370, costCurrency.ItemName)
          msg = LocUtil.LocalizeResFormat(200000240, materialInfo.needCurrency)
          
          function clickOkCallback()
            XSuitHandler.send_do_onshot_exchange_by_activity_id_req(logic_xsuit_activity:GetExchangeActivityID(), materialInfo.exchangeList)
          end
          
          CommonMsgBoxMgr.Show(styleType, title, msg, clickOkCallback, nil, nil, nil, extraData)
        end)
      end
    else
      ShowNotice(9009)
    end
  else
    local mainMaterial, assistMaterial = materialInfo.materialList[1], materialInfo.materialList[2]
    msg = LocUtil.LocalizeResFormat(200000810, mainMaterial and mainMaterial.needCount or 0, assistMaterial and assistMaterial.needCount or 0)
    
    function clickOkCallback()
      local needUpgradeID = LogicXSuit.GetItemIDByPeriodSelf(self.period, branchId)
      XSuitHandler.send_rise_star_req(self.period, needUpgradeID, branchId)
    end
    
    CommonMsgBoxMgr.Show(styleType, title, msg, clickOkCallback, nil, nil, nil, extraData)
  end
end

function XSuit_GetMaterials_Popup_UIBP:JumpToXSuitSpin()
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local info = ActivityNewSystem.GetActivityInfoByModuleID(BP_ENUM_MODULE_XSUIT_SPIN)
  if not info then
    ShowNotice(7809)
    return
  end
  local TimeUtil = require("client.common.time_util")
  if TimeUtil.GetServerTimeInSec() > info.EndTimeUTC then
    ShowNotice(8262)
    return
  end
  GlobalData.JumpUrl("game://?module=" .. tostring(BP_ENUM_MODULE_XSUIT_SPIN))
  self:CloseSelf()
end

function XSuit_GetMaterials_Popup_UIBP:OnUpgradeSuccess(_, _, curLevel, period, branchId)
  if self._IsClosed or not self.UIRoot then
    return
  end
  self:RefreshPage()
end

function XSuit_GetMaterials_Popup_UIBP:OnActiveBranchUpdate(_, _)
  if self._IsClosed or not self.UIRoot then
    return
  end
  self:RefreshPage()
end

function XSuit_GetMaterials_Popup_UIBP:SetMissionData()
  self.weekMissionList, self.seasonMissionList, self.realWeekMissionList, self.realSeasonMissionList = LogicXSuit.GetTaskConfig()
end

function XSuit_GetMaterials_Popup_UIBP:OnClose()
  XSuit_GetMaterials_Popup_UIBP.__super.OnClose(self)
  if self.leftTimer then
    self:RemoveTimer(self.leftTimer)
    self.leftTimer = nil
  end
  local parentUI = self:GetParentUI()
  if not (not self._bSkipNotifyParentClose and not self._bNotifyParentClose and parentUI) or parentUI._IsClosed then
    return
  end
  self._bNotifyParentClose = true
  parentUI:CloseSelf()
end

function XSuit_GetMaterials_Popup_UIBP:OnButtonClick_Mode(bWeek)
  self:PlayAudio(sound_config.click_v1)
  if self.bWeek == bWeek then
    return
  end
  self.bWeek = bWeek
  self:RefreshPage()
end

function XSuit_GetMaterials_Popup_UIBP:RefreshPage()
  if self.UIRoot.WidgetSwitcher then
    self.UIRoot.WidgetSwitcher:SetActiveWidgetIndex(self.bWeek and 0 or 1)
  end
  if self.UIRoot.WidgetSwitcher_1 then
    self.UIRoot.WidgetSwitcher_1:SetActiveWidgetIndex(self.bWeek and 1 or 0)
  end
  self:RefreshMissionDesc()
  self:RefreshMissionProgress()
  self:RefreshMissionList()
  self:RefreshBranchInfo()
  self:RefreshCharacterImage()
  self:RefreshDescriptionText()
  self:HideDecorationImages()
end

local CHARACTER_IMAGE_DIR = "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/4700/NoAtlas/Ascend/"
local CHARACTER_IMAGE_NAME_ALL = "Img_4700_Xsuit_AscendStar_Role_All"

function XSuit_GetMaterials_Popup_UIBP:_GetCharacterImagePath(period, branchId)
  local periodCfg
  if not branchId then
    periodCfg = CDataTable.GetTableDataByFilter("XSuitCommonBranch", "Period", period, "IsBranch", 0)
  else
    periodCfg = CDataTable.GetTableDataByFilter("XSuitCommonBranch", "Period", period, "BranchId", branchId, "IsBranch", 1)
  end
  if periodCfg and periodCfg.MissionRoleImage then
    return periodCfg.MissionRoleImage
  end
  return ""
end

function XSuit_GetMaterials_Popup_UIBP:RefreshCharacterImage()
  if not self.UIRoot or not self.UIRoot.Image_Character then
    return
  end
  local branchId = LogicXSuit.GetActiveBranchIdByPeriod(self.period)
  local path = self:_GetCharacterImagePath(self.period, branchId)
  if self.characterImagePath == path then
    return
  end
  self.characterImagePath = path
  self:SetTexture(self.UIRoot.Image_Character, path)
  log(bWriteLog and "XSuit_GetMaterials_Popup_UIBP:RefreshCharacterImage period:" .. tostring(self.period) .. " branchId:" .. tostring(branchId) .. " path:" .. tostring(path))
end

function XSuit_GetMaterials_Popup_UIBP:HideDecorationImages()
  if not self.UIRoot then
    return
  end
  self:SetWidgetVisible(self.UIRoot.SizeBox_Icon1, false)
  self:SetWidgetVisible(self.UIRoot.SizeBox_Icon2, false)
end

function XSuit_GetMaterials_Popup_UIBP:RefreshMissionList()
  local bReachLimit = self.bWeek and self.weekMissionState or not self.bWeek and self.seasonMissionState
  local missionList = {}
  if not bReachLimit then
    missionList = self.bWeek and self.weekMissionList or self.seasonMissionList or {}
  end
  if self.UIRoot.UTRichTextBlock_WeekTask_Desc then
    self:SetWidgetVisible(self.UIRoot.UTRichTextBlock_WeekTask_Desc, not bReachLimit, false)
  end
  if self.UIRoot.Image_Line1 then
    self:SetWidgetVisible(self.UIRoot.Image_Line1, not bReachLimit, false)
  end
  if self.UIRoot.WidgetSwitcher_Loop then
    self.UIRoot.Text_Desc:SetText(self.bWeek and LocUtil.LocalizeResFormat(18141439) or LocUtil.LocalizeResFormat(18141440))
    self.UIRoot.WidgetSwitcher_Loop:SetActiveWidgetIndex(bReachLimit and 1 or 0)
  end
  local itemBg = self.branchConfig and self.branchConfig.MissionItemBg
  for _, mission in ipairs(missionList) do
    mission.ItemBg = itemBg
  end
  local loopScrollBox = self.LoopScrollBox_Task_Item or self.LoopScrollBox_Mission
  if not loopScrollBox then
    return
  end
  loopScrollBox:SetData(missionList)
  if 0 < #missionList then
    loopScrollBox:Select(1)
    loopScrollBox:ScrollToItem(1)
  end
end

function XSuit_GetMaterials_Popup_UIBP:RefreshMissionProgress()
  if not self.realWeekMissionList and not self.realSeasonMissionList then
    self:SetMissionData()
  end
  local curValue, maxValue = 0, LogicXSuit.GetTaskMaxFinishValue(self.bWeek)
  local haveCanFinish = false
  local missionList = self.bWeek and self.realWeekMissionList or self.realSeasonMissionList
  for _, config in ipairs(missionList or {}) do
    local stateData = LogicXSuit.GetTaskState(config.task_id, self.bWeek)
    if config.can_repeat_finish == 1 then
      curValue = curValue + (stateData.finish_count and (stateData.finish_count <= config.max_finish_count and stateData.finish_count or config.max_finish_count) or 0)
    elseif stateData.status ~= CommonItem_Const.Enum_ItemStatus.Not then
      curValue = curValue + 1
    end
    if stateData.status == CommonItem_Const.Enum_ItemStatus.Done and maxValue >= curValue then
      haveCanFinish = true
    end
  end
  local bReachLimit = 0 < maxValue and maxValue <= curValue and not haveCanFinish
  self.weekMissionState = bReachLimit and self.bWeek
  self.seasonMissionState = bReachLimit and not self.bWeek
  local descText = LocUtil.LocalizeResFormat(self.bWeek and 200000705 or 200000706, maxValue < curValue and maxValue or curValue, maxValue)
  local descTextBlock = self.UIRoot.UTRichTextBlock_WeekTask_Desc or self.UIRoot.TextBlock_Progress
  if descTextBlock then
    descTextBlock:SetText(descText)
  end
end

function XSuit_GetMaterials_Popup_UIBP:RefreshBranchInfo()
  local branchId = LogicXSuit.GetActiveBranchIdByPeriod(self.period)
  local completionText, branchName = "", ""
  local bOwnSuit = true
  local bHasBranch = false
  local config = branchId ~= nil and self:GetBranchConfig(branchId) or nil
  if config then
    bHasBranch = true
    local curLevel = LogicXSuit.GetLevelByPeriodSelf(self.period, branchId) or 0
    local maxLevel = LogicXSuit.GetActSuitMaxLevelByPeriod(self.period, branchId) or 0
    bOwnSuit = 0 < curLevel
    if bOwnSuit then
      completionText = LocUtil.LocalizeResFormat(18141397, curLevel, math.max(maxLevel, curLevel))
    else
      completionText = LocUtil.GetLocalizeResStr(90080)
    end
    if config.BranchName then
      branchName = LocUtil.GetLocalizeResStr(config.BranchName)
    end
  else
    completionText = ""
    branchName = DESC_LOC_KEY.notSelectBranch and LocUtil.GetLocalizeResStr(DESC_LOC_KEY.notSelectBranch) or ""
  end
  if self.UIRoot.UTRichTextBlock_Completion then
    self.UIRoot.UTRichTextBlock_Completion:SetText(completionText)
  end
  if self.UIRoot.AutoScrollText_Side_Chapter then
    self.UIRoot.AutoScrollText_Side_Chapter:SetText(branchName)
  end
  if self.UIRoot.Image_Star then
    self:SetWidgetVisible(self.UIRoot.Image_Star, bHasBranch and bOwnSuit)
  end
end

function XSuit_GetMaterials_Popup_UIBP:IsXSuitDrawingOpen()
  local TimeUtil = require("client.common.time_util")
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  local endTime = logic_xsuit_activity:GetDrawEndTime()
  return endTime and endTime > TimeUtil.GetServerTimeInSec() and true or false
end

function XSuit_GetMaterials_Popup_UIBP:GetReachLevelCandidateBranches()
  local branchIdList = LogicXSuit.GetUnlockedBranchIdListByPeriod(self.period)
  if branchIdList and 0 < #branchIdList then
    return branchIdList
  end
  LogicXSuit.InitXSuitBaseInfo(self.period)
  local periodInfo = LogicXSuit.upgradeInfo and LogicXSuit.upgradeInfo[self.period]
  local list = {}
  for branchId, _ in pairs(periodInfo or {}) do
    table.insert(list, branchId)
  end
  table.sort(list)
  if #list <= 0 then
    list = {0}
  end
  return list
end

function XSuit_GetMaterials_Popup_UIBP:GetAnyBranchReachLevel()
  local branchIdList = LogicXSuit.GetUnlockedBranchIdListByPeriod(self.period) or {}
  if #branchIdList <= 0 then
    return LogicXSuit.GetUpgradeReachLevel(self.period, 0) or 0
  end
  local reachLevel = 0
  for _, branchId in ipairs(branchIdList) do
    reachLevel = math.max(reachLevel, LogicXSuit.GetUpgradeReachLevel(self.period, branchId) or 0)
  end
  return reachLevel
end

function XSuit_GetMaterials_Popup_UIBP:GetBranchReachLevelWithMakeUp(branchId, bForceActive)
  if branchId == nil then
    return 0, false
  end
  local maxLevel = LogicXSuit.GetActSuitMaxLevelByPeriod(self.period, branchId) or 0
  if maxLevel <= 0 then
    return 0, false
  end
  local curLevel = LogicXSuit.GetLevelByPeriodSelf(self.period, branchId) or 0
  local baseLevel = 0 < curLevel and curLevel or 1
  local reachLevel = baseLevel
  local bUsedMakeUpOnFirstStep = false
  LogicXSuit.InitXSuitBaseInfo(self.period)
  local periodInfo = LogicXSuit.upgradeInfo and LogicXSuit.upgradeInfo[self.period]
  local branchInfo = periodInfo and periodInfo[branchId]
  if not branchInfo then
    return reachLevel, false
  end
  local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
  local usedCount = {}
  
  local function GetRest(resID)
    if not resID or resID <= 0 then
      return 0
    end
    local total = wardrobe_data:GetHallDepotItemCountByResID(resID) or 0
    return math.max(total - (usedCount[resID] or 0), 0)
  end
  
  for nextLevel = baseLevel + 1, maxLevel do
    local levelInfo = branchInfo[nextLevel]
    local cfg = levelInfo and levelInfo.cfg
    local costList = LogicXSuit.GetUpgradeCostList(self.period, branchId, nextLevel, bForceActive)
    if not (cfg and costList) or #costList <= 0 then
      break
    end
    local pendingUseList = {}
    local bEnough = true
    for _, cost in ipairs(costList) do
      local slot = (cfg.ActiveID1 == cost.resID or cfg.MatID1 == cost.resID) and 1 or 2
      local comMatId = cfg["MatID" .. slot] or 0
      local limitMatId = cfg["LimitMatID" .. slot] or 0
      local backMatId = cfg["BackID" .. slot] or 0
      local ratio = 1
      if cost.bActive then
        ratio = LogicXSuit.MaterialCommon2ActiveNum(comMatId) or 1
        if ratio <= 0 then
          ratio = 1
        end
      end
      local need = cost.needCount or 0
      if 0 < need then
        local realNeed = cost.bActive and math.ceil(need / ratio) * ratio or need
        local restMain = math.min(GetRest(cost.resID), realNeed)
        local lack = realNeed - restMain
        local subUseList = {}
        for _, makeUpId in ipairs({
          comMatId,
          limitMatId,
          backMatId
        }) do
          if lack <= 0 then
            break
          end
          if makeUpId and 0 < makeUpId and makeUpId ~= cost.resID then
            local restMakeUp = GetRest(makeUpId)
            if 0 < restMakeUp then
              local useMakeUp = math.min(restMakeUp, math.ceil(lack / ratio))
              table.insert(subUseList, {resID = makeUpId, count = useMakeUp})
              lack = lack - useMakeUp * ratio
            end
          end
        end
        if 0 < lack then
          bEnough = false
          break
        end
        if 0 < restMain then
          table.insert(pendingUseList, {
            resID = cost.resID,
            count = restMain
          })
        end
        for _, subUse in ipairs(subUseList) do
          table.insert(pendingUseList, subUse)
        end
        if 0 < #subUseList and nextLevel == baseLevel + 1 then
          bUsedMakeUpOnFirstStep = true
        end
      end
    end
    if not bEnough then
      break
    end
    for _, pendingUse in ipairs(pendingUseList) do
      local resID = pendingUse.resID
      if resID and 0 < resID and 0 < pendingUse.count then
        usedCount[resID] = (usedCount[resID] or 0) + pendingUse.count
      end
    end
    reachLevel = nextLevel
  end
  return reachLevel, bUsedMakeUpOnFirstStep
end

function XSuit_GetMaterials_Popup_UIBP:GetAnyBranchReachLevelWithMakeUp()
  local branchIdList = self:GetReachLevelCandidateBranches()
  local reachLevel, strictReachLevel, bMakeUpOnFirstStep = 0, 0, false
  for _, branchId in ipairs(branchIdList) do
    local level = LogicXSuit.GetUpgradeReachLevel(self.period, branchId) or 0
    strictReachLevel = math.max(strictReachLevel, level)
    local levelActive, bMakeUpActive = self:GetBranchReachLevelWithMakeUp(branchId, true)
    local levelNormal, bMakeUpNormal = self:GetBranchReachLevelWithMakeUp(branchId, false)
    level = math.max(level, levelActive, levelNormal)
    if 2 <= levelActive and bMakeUpActive or 2 <= levelNormal and bMakeUpNormal then
      bMakeUpOnFirstStep = true
    end
    reachLevel = math.max(reachLevel, level)
  end
  return reachLevel, strictReachLevel, bMakeUpOnFirstStep
end

function XSuit_GetMaterials_Popup_UIBP:GetUnlockFeatureNameByLevel(branchId, level)
  if branchId == nil or not level then
    return ""
  end
  LogicXSuit.InitXSuitBaseInfo(self.period)
  local periodInfo = LogicXSuit.upgradeInfo and LogicXSuit.upgradeInfo[self.period]
  local branchInfo = periodInfo and periodInfo[branchId]
  local levelInfo = branchInfo and branchInfo[level]
  local featureList = levelInfo and levelInfo.featureList
  if not featureList or #featureList <= 0 then
    local TabName = ""
    if levelInfo and levelInfo.cfg and levelInfo.cfg.TabID then
      TabName = LocUtil.GetLocalizeResStr(levelInfo.cfg.TabID)
    end
    return TabName
  end
  local preFeatureIdSet = {}
  local preLevelInfo = 1 < level and branchInfo[level - 1]
  for _, feature in ipairs(preLevelInfo and preLevelInfo.featureList or {}) do
    if feature.tabId and 0 < feature.tabId then
      preFeatureIdSet[feature.tabId] = true
    end
  end
  local nameList, newNameList = {}, {}
  for _, feature in ipairs(featureList) do
    if feature.tabId and 0 < feature.tabId then
      local featureName = LocUtil.GetLocalizeResStr(feature.tabId)
      table.insert(nameList, featureName)
      if not preFeatureIdSet[feature.tabId] then
        table.insert(newNameList, featureName)
      end
    end
  end
  return table.concat(0 < #newNameList and newNameList or nameList, "\227\128\129")
end

function XSuit_GetMaterials_Popup_UIBP:GetDescTextOrDefault(locKey, ...)
  local text = LocUtil.LocalizeResFormat(locKey, ...)
  if not text or text == "" then
    text = LocUtil.GetLocalizeResStr(DESC_LOC_KEY.bNotOwnDrawingOneStar)
  end
  return text or ""
end

function XSuit_GetMaterials_Popup_UIBP:RefreshDescriptionText()
  local descTextBlock = self.UIRoot.UTRichTextBlock_Description_Text
  if not descTextBlock then
    return
  end
  local descText = ""
  local branchId = LogicXSuit.GetActiveBranchIdByPeriod(self.period)
  local bMaterialEnough = false
  if branchId ~= nil then
    local curLevel = LogicXSuit.GetLevelByPeriodSelf(self.period, branchId) or 0
    local strictReachLevel = LogicXSuit.GetUpgradeReachLevel(self.period, branchId) or 0
    local reachLevel = strictReachLevel
    local startLevel = 0 < curLevel and curLevel or 1
    local makeUpLevel = self:GetBranchReachLevelWithMakeUp(branchId)
    reachLevel = math.max(reachLevel, makeUpLevel or 0)
    bMaterialEnough = startLevel < reachLevel
    if not bMaterialEnough and self:IsUpgradeEnoughWithMakeUp(branchId) then
      bMaterialEnough = true
      if startLevel >= reachLevel then
        reachLevel = startLevel + 1
      end
    end
    local bMakeUpOnly = bMaterialEnough and strictReachLevel <= startLevel
    if 0 < curLevel then
      if self:IsBranchMaxLevel(branchId, curLevel) then
        descText = LocUtil.GetLocalizeResStr(DESC_LOC_KEY.bOwnMaxLevel)
      elseif bMaterialEnough then
        descText = LocUtil.LocalizeResFormat(DESC_LOC_KEY.bOwnEnough, reachLevel)
      else
        local taskCount = LogicXSuit.GetUpgradeNeedTaskCount(self.period, branchId)
        if 0 < taskCount then
          descText = LocUtil.LocalizeResFormat(DESC_LOC_KEY.bOwnNeedTask, taskCount)
        end
      end
    elseif self:CheckXSuitSpinJumpable(false) then
      if bMaterialEnough and 1 < reachLevel and not bMakeUpOnly then
        local featureName = self:GetUnlockFeatureNameByLevel(branchId, reachLevel)
        descText = self:GetDescTextOrDefault(DESC_LOC_KEY.bNotOwnDrawingWithFeature, reachLevel, featureName)
      else
        descText = LocUtil.GetLocalizeResStr(DESC_LOC_KEY.bNotOwnDrawingOneStar)
      end
    elseif bMaterialEnough and not bMakeUpOnly then
      descText = self:GetDescTextOrDefault(DESC_LOC_KEY.bNotOwnNoWay, reachLevel)
    else
      descText = LocUtil.GetLocalizeResStr(DESC_LOC_KEY.bNotOwnDrawingOneStar)
    end
  else
    local reachLevel, strictReachLevel, bMakeUpOnFirstStep = self:GetAnyBranchReachLevelWithMakeUp()
    local bMakeUpOnly = 2 <= reachLevel and (strictReachLevel < 2 or bMakeUpOnFirstStep)
    if 2 <= reachLevel and not bMakeUpOnly then
      local locKey = self:CheckXSuitSpinJumpable(false) and DESC_LOC_KEY.bNotOwnNoDrawing or DESC_LOC_KEY.bNotOwnNoWay
      descText = self:GetDescTextOrDefault(locKey, reachLevel)
    else
      descText = LocUtil.GetLocalizeResStr(DESC_LOC_KEY.bNotOwnDrawingOneStar)
    end
  end
  if descText and descText ~= "" then
  else
    descText = LocUtil.GetLocalizeResStr(DESC_LOC_KEY.bNotOwnDrawingOneStar)
  end
  descTextBlock:SetText(descText)
  self:RefreshUpgradeCostShow(branchId, bMaterialEnough)
  self:RefreshTrialButtonText()
end

function XSuit_GetMaterials_Popup_UIBP:RefreshUpgradeCostShow(branchId, bMaterialEnough)
  local uiRoot = self.UIRoot
  local buttonText = uiRoot.UTRichTextBlock_Button_Text_01
  local iconList = {
    uiRoot.Image_Icon_01,
    uiRoot.Image_Icon_02
  }
  local countList = {
    uiRoot.UTRichTextBlock_Count_01,
    uiRoot.UTRichTextBlock_Count_02
  }
  local curLevel = branchId ~= nil and (LogicXSuit.GetLevelByPeriodSelf(self.period, branchId) or 0) or 0
  if curLevel <= 0 then
    if buttonText then
      self:SetWidgetVisible(buttonText, false)
    end
    if uiRoot.Image_Mask then
      self:SetWidgetVisible(uiRoot.Image_Mask, false)
    end
    for index = 1, 2 do
      if iconList[index] then
        self:SetWidgetVisible(iconList[index], false)
      end
      if countList[index] then
        self:SetWidgetVisible(countList[index], false)
      end
    end
    return
  end
  local showList = {}
  if branchId ~= nil then
    if bMaterialEnough then
      local nextLevel = curLevel + 1
      for _, cost in ipairs(LogicXSuit.GetUpgradeCostList(self.period, branchId, nextLevel)) do
        table.insert(showList, {
          resID = cost.resID,
          count = cost.needCount
        })
      end
    else
      for _, lack in ipairs(LogicXSuit.GetUpgradeMaterialLackList(self.period, branchId)) do
        table.insert(showList, {
          resID = lack.resID,
          count = lack.lackCount
        })
      end
    end
  end
  local bShowCost = bMaterialEnough or 0 < #showList
  local bShowLack = not bMaterialEnough and 0 < #showList and uiRoot.Image_Mask ~= nil
  local bShowItem = bShowCost or bShowLack
  if buttonText then
    self:SetWidgetVisible(buttonText, bShowCost)
    if bShowCost then
      local tipText = bMaterialEnough and DESC_LOC_KEY.costText or DESC_LOC_KEY.costNeed
      buttonText:SetText(LocUtil.GetLocalizeResStr(tipText))
    end
  end
  if uiRoot.Image_Mask then
    self:SetWidgetVisible(uiRoot.Image_Mask, bShowItem)
  end
  local UIUtil = require("client.common.ui_util")
  for index = 1, 2 do
    local item = bShowItem and showList[index] or nil
    local iconWidget, countWidget = iconList[index], countList[index]
    if iconWidget then
      self:SetWidgetVisible(iconWidget, item ~= nil)
      if item then
        local iconPath, bHasAddKnownMissing = UIUtil.GetItemSmallIcon(item.resID, iconWidget)
        self:SetTexture(iconWidget, iconPath, {sync = false, bHasAddKnownMissing = bHasAddKnownMissing})
      end
    end
    if countWidget then
      self:SetWidgetVisible(countWidget, item ~= nil)
      if item then
        countWidget:SetText(tostring(item.count))
      end
    end
  end
end

function XSuit_GetMaterials_Popup_UIBP:GetBranchConfig(branchId)
  local configs = CDataTable.GetTableByFilter("XSuitCommonBranch", "Period", self.period, "IsBranch", 1)
  for _, config in pairs(configs or {}) do
    if config.BranchId == branchId then
      return config
    end
  end
  return nil
end

function XSuit_GetMaterials_Popup_UIBP:RefreshMissionDesc()
  local TimeUtil = require("client.common.time_util")
  if self.leftTimer then
    self:RemoveTimer(self.leftTimer)
    self.leftTimer = nil
  end
  local endTime = LogicXSuit.GetTaskEndTime(self.bWeek)
  local leftTime = endTime - TimeUtil.GetServerTimeInSec()
  self:RefreshTimeTips(leftTime)
  self.leftTimer = self:AddTimerLoop(0, function()
    leftTime = endTime - TimeUtil.GetServerTimeInSec()
    self:RefreshTimeTips(leftTime)
  end, 0, 1)
end

function XSuit_GetMaterials_Popup_UIBP:RefreshTimeTips(leftTime)
  local TimeUtil = require("client.common.time_util")
  local text = LocUtil.LocalizeResFormat(self.bWeek and 200000703 or 200000704, TimeUtil.FormatCountDownTime_D_or_HMS(leftTime, 1))
  local tipsTextBlock = self.UIRoot.TextBlock_Tips or self.UIRoot.TextBlock_Time
  if tipsTextBlock then
    tipsTextBlock:SetText(text)
  end
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CXSuit_GetMaterials_Popup_UIBP = class(ui_base, nil, XSuit_GetMaterials_Popup_UIBP)
return CXSuit_GetMaterials_Popup_UIBP
