local Lobby_ExpandMatching_Popup_UIBP = {}
local Enum_Plan = {General = 0, African = 1}

function Lobby_ExpandMatching_Popup_UIBP:ctor(_, data)
  log_tree("Lobby_ExpandMatching_Popup_UIBP:ctor data:", data)
  self.data = data
  self.curSelectIndex = 2
  self.isCheck = false
  self.planType = data and data.plan_type
end

function Lobby_ExpandMatching_Popup_UIBP:OnInitialize()
  self.Common_Popup_Medium_UIBP = self:InitCommonPopup(self.UIRoot.Common_Popup_Medium_UIBP)
  self.Common_ComboBox_UIBP = self:InitCommonComboBoxNew(self.UIRoot.Common_ComboBox_UIBP)
  local extra = {
    helpInfo = {
      titleText = LocUtil.GetLocalizeResStr(86001),
      contentText = LocUtil.GetLocalizeResStr(86002)
    }
  }
  self.Common_Popup_Medium_UIBP:SetData(self, LocUtil.GetLocalizeResStr(86000), extra)
  self.UIRoot.CheckBox_0:SetCheckedState(0)
end

function Lobby_ExpandMatching_Popup_UIBP:RegistEvents()
  self:AddOnClickedEventByControl(self.UIRoot.Button_Confirm, self.OnClickButton_Confirm, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Cross, self.OnClickButton_Cross, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Local, self.OnClickButton_Local, self)
  self:AddOnCheckStateChangedEventByControl(self.UIRoot.CheckBox_0, self.OnCheckBoxChange, self)
  self.Common_ComboBox_UIBP:SetSelectOptionCallback(self.OnComboBoxSelect, self)
end

function Lobby_ExpandMatching_Popup_UIBP:OnPostInitialize()
  local time = 15
  self:AddTimerLoop(0, function()
    if time <= 0 then
      self:CloseSelf()
      return
    end
    self.UIRoot.TextBlock_Btn:SetText(LocUtil.LocalizeResFormat(86003, time))
    time = time - 1
  end, TIMER_INFINITE, 1)
  self:UpdateUI()
end

function Lobby_ExpandMatching_Popup_UIBP:OnClose()
  local BasicDataTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.BasicDataTLogReport)
  if self.curSelectIndex == 2 then
    ShowNotice(76510)
    local TeamupHandler = require("client.network.Protocol.TeamupHandler")
    if self.planType and self.planType ~= Enum_Plan.African then
      TeamupHandler.send_report_cross_shadow_req(false)
    else
      TeamupHandler.send_change_cross_shadow_req(false, self.isCheck, self.isCheck and 3 or 0)
    end
    BasicDataTLogReport:ReportImmediate(TLogEventDefine.Team_Cross_Match_Click, 1, self.isCheck and 1 or 0)
  elseif self.curSelectIndex == 1 then
    local day = 0
    if self.comboBoxIndex == 2 then
      day = 1
    elseif self.comboBoxIndex == 3 then
      day = 3
    end
    local TeamupHandler = require("client.network.Protocol.TeamupHandler")
    if self.planType and self.planType ~= Enum_Plan.African then
      TeamupHandler.send_report_cross_shadow_req(true)
    else
      TeamupHandler.send_change_cross_shadow_req(true, self.comboBoxIndex ~= 1, day)
    end
    BasicDataTLogReport:ReportImmediate(TLogEventDefine.Team_Cross_Match_Click, 0, self.comboBoxIndex ~= 1 and 1 or 0, self.comboBoxIndex)
    if day == 0 then
      local logic_team_zone_ping = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_team_zone_ping)
      logic_team_zone_ping:SetReOpenCrossTimer(self.data)
    end
  end
end

function Lobby_ExpandMatching_Popup_UIBP:OnCheckBoxChange(isCheck)
  self:PlayAudio(sound_config.click_v1)
  self.isCheck = isCheck
end

function Lobby_ExpandMatching_Popup_UIBP:OnClickButton_Local()
  self:PlayAudio(sound_config.click_v1)
  self.curSelectIndex = 1
  self:RefreshSelectState()
end

function Lobby_ExpandMatching_Popup_UIBP:OnClickButton_Cross()
  self:PlayAudio(sound_config.click_v1)
  self.curSelectIndex = 2
  self:RefreshSelectState()
end

function Lobby_ExpandMatching_Popup_UIBP:OnClickButton_Confirm()
  self:PlayAudio(sound_config.click_v1)
  self:CloseSelf()
end

function Lobby_ExpandMatching_Popup_UIBP:OnComboBoxSelect(widget, data, index)
  self:PlayAudio(sound_config.subTab_v1)
  log(bWriteLog and "Xmission_Souvenirs_Edit_UIBP_New:OnComboBoxSelect index = " .. tostring(index) .. " sortType = " .. tostring(data.sortType))
  self.comboBoxIndex = index
end

function Lobby_ExpandMatching_Popup_UIBP:UpdateUI()
  log(bWriteLog and "Lobby_ExpandMatching_Popup_UIBP:UpdateUI")
  local planCfg = CDataTable.GetTableData("CrossMatchPlan", self.data.plan_type)
  if planCfg then
    self.UIRoot.TextBlock_Desc:SetText(LocUtil.GetLocalizeResStr(planCfg.DescLocId))
  else
    self.UIRoot.TextBlock_Desc:SetText(LocUtil.GetLocalizeResStr(588517))
  end
  self.UIRoot.TextBlock_Local:SetText(LocUtil.GetLocalizeResStr(588518))
  self.UIRoot.TextBlock_LocalDesc:SetText(LocUtil.GetLocalizeResStr(588519))
  self.UIRoot.TextBlock_Cross:SetText(LocUtil.GetLocalizeResStr(588520))
  self.UIRoot.TextBlock_CrossDesc:SetText(LocUtil.LocalizeResFormat(588521, self.data.add_ping))
  self.UIRoot.TextBlock_CheckBox:SetText(LocUtil.LocalizeResFormat(86012, 3))
  self.UIRoot.TextBlock_Tips:SetText(LocUtil.GetLocalizeResStr(588522))
  self:RefreshSelectState()
  self:InitComboBox()
  local bAfricanPlan = self.planType == Enum_Plan.African
  self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_0, bAfricanPlan)
  self:SetWidgetVisible(self.UIRoot.TextBlock_Tips, not bAfricanPlan)
end

function Lobby_ExpandMatching_Popup_UIBP:RefreshSelectState()
  if self.curSelectIndex == 1 then
    self:SetWidgetVisible(self.UIRoot.Common_selected_UIBP_Local, true)
    self:SetWidgetVisible(self.UIRoot.Common_selected_UIBP_Cross, false)
    self.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(1)
  elseif self.curSelectIndex == 2 then
    self:SetWidgetVisible(self.UIRoot.Common_selected_UIBP_Local, false)
    self:SetWidgetVisible(self.UIRoot.Common_selected_UIBP_Cross, true)
    self.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(0)
  end
end

function Lobby_ExpandMatching_Popup_UIBP:InitComboBox()
  log(bWriteLog and "Xmission_Souvenirs_Edit_UIBP_New:InitComboBox")
  local logic_team_zone_ping = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_team_zone_ping)
  local comboBoxList = {
    [1] = {
      text = LocUtil.LocalizeResFormat(86010, logic_team_zone_ping:GetCrossNextShowCD()),
      sortType = 1
    },
    [2] = {
      text = LocUtil.LocalizeResFormat(86011, 1),
      sortType = 2
    },
    [3] = {
      text = LocUtil.LocalizeResFormat(86011, 3),
      sortType = 3
    }
  }
  self.Common_ComboBox_UIBP:SetData(comboBoxList, 1)
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
return class(ui_base, nil, Lobby_ExpandMatching_Popup_UIBP)
