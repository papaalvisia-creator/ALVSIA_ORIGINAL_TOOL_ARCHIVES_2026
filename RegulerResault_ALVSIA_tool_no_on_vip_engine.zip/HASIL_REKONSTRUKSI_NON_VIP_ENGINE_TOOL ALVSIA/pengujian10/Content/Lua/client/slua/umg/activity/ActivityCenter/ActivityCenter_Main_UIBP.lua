local ActivityCenter_Main_UIBP = {}
local ActivityUtil = require("client.slua.logic.activity.ActivityUtil")
local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
local ActivityMacros = require("client.slua.logic.activity.RedPoint.ActivityMacros")
local AreaGroupSystem = require("client.slua.logic.activity.commom_activity_center.logic_area_group")
local UIUtil = require("client.common.ui_util")
local gem_report_utils = require("client.logic.store.gem_report_utils")
local tlog_report_utils = require("client.slua.config.tlog.tlog_report_utils")
local JumpSourceMacros = require("client.slua.config.ClientMacros.JumpSourceMacros")
local StringUtil = require("common.string_util")
local JumpUtils = require("client.logic.store.jump_utils")
local pairs = _ENV.pairs
local ipairs = _ENV.ipairs
local C_ActPageUI = ActivityMacros.ActPageUI
local sLoadingPath = "/Game/Mod/Lobby/Split/NewActivity/UMG/Texture/Lobby_NoAtlas/NewActivty/NewActivty_Affiche_BG.NewActivty_Affiche_BG"
local GAMELET_READY_QUERY_TIMEOUT = 3
local T_NeedReReqActData = {
  [ActivityType.ACTIVITY_CENTER_KR_PROGRESS] = 1,
  [ActivityType.BUY_UPASS_ACTIVITY] = 1
}

function ActivityCenter_Main_UIBP:ctor(_, extraData)
  local logic_cost_collector = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_cost_collector)
  logic_cost_collector:MarkIsolatedEventStart(logic_cost_collector.ISOLATED_EVENT_NAMES.OpenActivityUI)
  self.CurActUI = nil
  self.DisplayScene = extraData and extraData.DisplayScene or ActivityDisplayScene.Default
  self.ExtraData = extraData or {}
  self.OriginParams = extraData and extraData.OriginParams or nil
  self.FirstEnter = true
  self.IsEmpty = false
  self.TabList = {}
  self.ActTabList = {}
  self.CurrentTab = 0
  self.CurrentTabIndex = 0
  self.CurrentActID = 0
  self.CurrentActIndex = 0
  self.CurrentPageKey = ""
  self.NeedShowMask = false
  self.BGImageDownloadIndex = nil
  log_tree("ActivityCenter_Main_UIBP:ctor extraData = ", extraData)
  if self.DisplayScene == ActivityDisplayScene.Default then
    ActivityUtil.PreloadBHAd()
  end
end

local hook
if IsEditor then
  function hook(obj, funcKey, printfunc)
    printfunc = printfunc or print
    
    local func = obj[funcKey]
    obj[funcKey] = function(self, ...)
      print(bWriteLog and "[hook]", printfunc(...))
      func(self, ...)
    end
  end
end

function ActivityCenter_Main_UIBP:OnInitialize()
  self.TabScroll = self:InitVerticalIconTab(self.UIRoot.Common_Tab_Vertical_LevelOne_Icon_UIBP, true)
  self.TabScroll:SetItemClickCDType(UIUtil.ClickFrequencyLimit.ActivitySwitch)
  self.ActivityScroll = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_Tab, "client.slua.umg.activity.ActivityCenter.ActivityCenter_ActTab_UIBP")
  local _ = hook and hook(self.TabScroll, "SetTabs", function(list)
    local Linq = require("common.Linq")
    return "ActivitySwitchType:" .. Linq.FromTable(list):Select(function(_, v)
      return v.nType
    end):Concat(",")
  end)
  local _ = hook and hook(self.ActivityScroll, "SetData", function(list)
    local Linq = require("common.Linq")
    return "ActId:" .. Linq.FromTable(list):Select(function(_, v)
      return v.nActID
    end):Concat(",")
  end)
  local logic_activity_recharge_mgr = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_activity_recharge_mgr)
  logic_activity_recharge_mgr:send_get_refund_black_act_list_req()
  if not self.vng18IconUI then
    local UIUtil = require("client.common.ui_util")
    self.vng18IconUI = UIUtil.InitChildWindow18Logo(self, "CanvasPanel_Main", 0.55, 0, 0, -20, 100)
  end
  self:BatchPandoraRedPoint()
end

function ActivityCenter_Main_UIBP:RegistEvents()
  self:AddOnClickedEventByControl(self.UIRoot.Button_Close, self.OnClickedClose, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Calendar, self.OnClickedCalendar, self)
  self:AddOnClickedEventByControl(self.UIRoot.Common_System_Customer_Entrance_UIBP.Button_0, self.OnClickedCustomService, self)
  self.TabScroll:AddOnTabClickedCallback(self.OnClickedTab, self)
  self.TabScroll:AddOnTabRefreshCallback(self.OnRefreshTab, self)
  self:AddCommonEvent(EVENTTYPE_ACTIVITY, EVENTID_ACTIVITY_CENTER_DATA_DIRTY, self.OnActivityCenterDataDirty, self)
  self:AddCommonEvent(EVENTTYPE_ACTIVITY, EVENTID_ACTIVITY_SWITCH_TAB_CONFIG_UPDATE, self.OnSwitchTabConfigUpdated, self)
  self:AddCommonEvent(EVENTTYPE_ACTIVITY, EVENTID_ACTIVITY_REFRESH_CHANGEBG_IMAGE, self.OnRefreshChangeBGImage, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_SELECT_MOD, self.OnUGCSelectMod, self)
end

function ActivityCenter_Main_UIBP:OnPostInitialize()
  self:RefreshConst()
  self:RefreshData()
  self:RebuildRedDot()
  self:RefreshDynamic()
  self:DoEnterSomething()
end

function ActivityCenter_Main_UIBP:OnClose()
  local PHomeStoreProxy = require("client.slua.logic.homestore.PHomeStoreProxy")
  if not PHomeStoreProxy.isShowingPHomeMain then
    UIUtil.ShowLobbyCamera(true)
  end
  if self.DisplayScene == ActivityDisplayScene.Default then
    ActivityUtil.ShowBHAdOrNot()
  end
  EventSystem:postEvent(EVENTTYPE_CARD_COLLECTION, EVENTID_CARDCOLLECTION_QUERY_COMPENSATE_LOBBY)
end

function ActivityCenter_Main_UIBP:GetDataForJumpBack()
  local package_preview_panel = UIManager.GetUI(UIManager.UI_Config.package_preview_panel)
  local common_use_items = UIManager.GetUI(UIManager.UI_Config.common_use_items)
  return {
    ctorData = {
      {
        actId = self.CurrentActID,
        DisplayScene = self.DisplayScene
      }
    },
    uiData = {
      actID = self.CurrentActID,
      package_preview_panel = package_preview_panel and package_preview_panel:GetDataForJumpBack() or nil,
      common_use_items = common_use_items and common_use_items:GetDataForJumpBack() or nil
    }
  }
end

function ActivityCenter_Main_UIBP:OnClickedClose()
  log(bWriteLog and "ActivityCenter_Main_UIBP:OnClickedClose.")
  self:PlayAudio(sound_config.click_v1)
  self:CloseSelf()
end

function ActivityCenter_Main_UIBP:OnClickedCalendar()
  log(bWriteLog and "ActivityCenter_Main_UIBP:OnClickedCalendar.")
  self:PlayAudio(sound_config.click_v1)
  local actData = ActivityNewSystem.GetActivityByType(ActivityType.ACTIVITY_CALENDAR)
  if not actData then
    self:SetWidgetVisible(self.UIRoot.Button_Calendar, false, true)
    return
  end
  local url = StringUtil.AppendUrlParam(actData.ImgLink, JumpSourceMacros.URL_KEY, JumpSourceMacros.JumpSource.ActivityCenter)
  GlobalData.JumpUrl(url)
end

function ActivityCenter_Main_UIBP:RefreshCalendarEntry()
  local actData = ActivityNewSystem.GetActivityByType(ActivityType.ACTIVITY_CALENDAR)
  if not actData then
    self:SetWidgetVisible(self.UIRoot.Button_Calendar, false, true)
    return
  end
  local Ready = ActivityNewSystem.IsGameletReadyByJumpUrl(actData.ImgLink)
  self:SetWidgetVisible(self.UIRoot.Button_Calendar, Ready, true)
end

function ActivityCenter_Main_UIBP:OnClickedCustomService()
  log(bWriteLog and "ActivityCenter_Main_UIBP:OnClickedCustomService. ")
  self:PlayAudio(sound_config.click_v1)
  self.UIRoot.Reddot_Anchor_Item01:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  local BasicDataTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.BasicDataTLogReport)
  BasicDataTLogReport:ReportImmediate(TLogEventDefine.LobbySettingHelp, 0)
  local SettingSystem = require("client.logic.setting.logic_setting")
  local LogicCustomerService = require("client.slua.logic.CustomerService.LogicCustomerService")
  SettingSystem.OpenService(LogicCustomerService.E_EntranceType.Events)
end

function ActivityCenter_Main_UIBP:OnClickedTab(widget, index)
  log_format("ActivityCenter_Main_UIBP:OnClickedTab. widget=%s, index=%s", tostring(widget), tostring(index))
  self:PlayAudio(sound_config.click_v1)
  local TabData = self.TabScroll:GetTabData(index)
  if not TabData then
    return
  end
  if self.CurrentTabIndex == index then
    return
  end
  self.CurrentTab = TabData.nType
  self.CurrentTabIndex = index
  self.CurrentActIndex = 1
  if TabData.nType == ActivitySwitchType.Xmission then
    local LogicTxMissionDownload = require("client.slua.logic.TxMission.logic_xmission_download")
    local PufferMapManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager)
    if LogicTxMissionDownload.GetTPlanMapDownloadState(LogicTxMissionDownload.BASE_MAP_KEY) then
      PufferMapManager:MountMapPak(LogicTxMissionDownload.BASE_MAP_KEY)
      log(bWriteLog and "ActivityCenter_Main_UIBP:OnClickedTab - MountMapPak for Xmission base map")
    end
  end
  local ActivityCenterModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ActivityCenterModule)
  local Proxy = ActivityCenterModule:GetDataProxy(self.DisplayScene)
  self.ActTabList = Proxy:GetTabListBySwitchType(self.CurrentTab)
  self.CurrentActID = self.ActTabList[1].nActID
  self.TabScroll:SelectTab(index, true)
  self:RefreshActivityScroll()
  self:RefreshActUI()
  gem_report_utils.ReportBtnClickEvent(gem_report_utils.SubEventName_ActivityCenterSwitch, tostring(self.CurrentTab))
  local TLogReasonStr = json.encode({
    event_name = gem_report_utils.SubEventName_ActivityCenterSwitch,
    activity_type = self.CurrentTab
  })
  tlog_report_utils.ReportTLogEvent(TLogEventDefine.ActivityCenterSwitch, 0, TLogReasonStr)
end

function ActivityCenter_Main_UIBP:OnClickedActTab(widget, index)
  log_format("ActivityCenter_Main_UIBP:OnClickedActTab. widget=%s, index=%s ", tostring(widget), tostring(index))
  self:PlayAudio(sound_config.click_v1)
  if not UIUtil.CanClickNow(UIUtil.ClickFrequencyLimit.ActivitySwitch) then
    return
  end
  if self.CurrentActIndex == index then
    return
  end
  local ActTabData = self.ActivityScroll:GetItemData(index)
  self.CurrentActIndex = index
  self.CurrentActID = ActTabData.nActID
  log_format("ActivityCenter_Main_UIBP:OnClickedActTab. CurrentActIndex=%s, CurrentActID=%s ", tostring(self.CurrentActIndex), tostring(self.CurrentActID))
  self.ActivityScroll:Select(index)
  self:RefreshActUI()
  gem_report_utils.ReportBtnClickEvent(gem_report_utils.SubEventName_ActivityCenterTab, tostring(self.CurrentActID))
  local TLogReasonStr = json.encode({
    event_name = gem_report_utils.SubEventName_ActivityCenterTab,
    activity_id = self.CurrentActID
  })
  tlog_report_utils.ReportTLogEvent(TLogEventDefine.ActivityCenterTab, 0, TLogReasonStr)
end

function ActivityCenter_Main_UIBP:OnActivityCenterDataDirty()
  log(bWriteLog and "ActivityCenter_Main_UIBP:OnActivityCenterDataDirty - received data dirty event, trigger full refresh")
  self:RefreshData()
  self:RefreshDynamic(true)
end

function ActivityCenter_Main_UIBP:OnSwitchTabConfigUpdated()
  log(bWriteLog and "ActivityCenter_Main_UIBP:OnSwitchTabConfigUpdated - tab icon config changed, refresh icons only")
  if self.IsEmpty or #self.TabList == 0 then
    return
  end
  self:_ApplyTabIcons()
  self.TabScroll:RefreshAllTabItemShow(self.TabList)
end

function ActivityCenter_Main_UIBP:OnUGCSelectMod()
  self:CloseCurActUI()
  self:CloseSelf()
end

function ActivityCenter_Main_UIBP:RefreshConst()
  self.UIRoot.TextBlock_Empty:SetText(LocUtil.GetLocalizeResStr(260124))
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  if PublishRegionMacros.IsBlueholeOperationRegion() then
    self.UIRoot.TextBlock_0:SetText(LocUtil.GetLocalizeResStr(66311))
    self:WidgetHidden(self.UIRoot.CanvasPanel_24)
  else
    self.UIRoot.TextBlock_0:SetText(LocUtil.GetLocalizeResStr(8103))
    self:WidgetSelfHit(self.UIRoot.CanvasPanel_24)
    self:SetWidgetVisible(self.UIRoot.Reddot_Anchor_Item01, LobbySystem.roleData.customer_service_reddot)
  end
end

function ActivityCenter_Main_UIBP:_ResetToEmpty()
  self.IsEmpty = true
  self.TabList = {}
  self.ActTabList = {}
  self.CurrentTab = 0
  self.CurrentTabIndex = 0
  self.CurrentActID = 0
  self.CurrentActIndex = 0
  self.CurrentPageKey = ""
end

function ActivityCenter_Main_UIBP:_FindTabIndex(switchType)
  for index, tabInfo in ipairs(self.TabList) do
    if tabInfo.nType == switchType then
      return index
    end
  end
  return 0
end

function ActivityCenter_Main_UIBP:_ApplySelectionByActTabInfo(Proxy, actTabInfo)
  self.CurrentActID = actTabInfo.nActID
  self.CurrentTab = actTabInfo.nSwitchType
  self.CurrentTabIndex = self:_FindTabIndex(self.CurrentTab)
  self.CurrentActIndex = Proxy:GetTabIndexByActID(self.CurrentActID, self.CurrentTab)
end

function ActivityCenter_Main_UIBP:_ApplySelectionToFirst(Proxy)
  local firstSwitchType = self.TabList[1].nType
  local firstActTab = Proxy:GetFirstTabInfoBySwitchType(firstSwitchType)
  self:_ApplySelectionByActTabInfo(Proxy, firstActTab)
end

function ActivityCenter_Main_UIBP:_ApplyTabIcons()
  if #self.TabList == 0 then
    return
  end
  local ActivityMacros = require("client.slua.logic.activity.RedPoint.ActivityMacros")
  local C_SwitchIcon = ActivityMacros.ActTabIcon
  local C_SwitchIcon_Selected = ActivityMacros.ActTabSelIcon
  local ActivityCenterTabModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ActivityCenterTabModule)
  for _, tabInfo in ipairs(self.TabList) do
    local switchType = tabInfo.nType
    local NormalPath = C_SwitchIcon[switchType] or ""
    local SelectedPath = C_SwitchIcon_Selected[switchType] or ""
    if ActivityCenterTabModule and ActivityCenterTabModule:ExistTabConfig(switchType) then
      NormalPath = ActivityCenterTabModule:GetActCenterTabNormalPath(switchType)
      SelectedPath = ActivityCenterTabModule:GetActCenterTabSelectedPath(switchType)
    end
    tabInfo.inactivePath = NormalPath
    tabInfo.activePath = SelectedPath
  end
end

function ActivityCenter_Main_UIBP:RefreshData()
  log_format("ActivityCenter_Main_UIBP:RefreshData - enter. FirstEnter=%s, DisplayScene=%s, CurrentTab=%s, CurrentActID=%s", tostring(self.FirstEnter), tostring(self.DisplayScene), tostring(self.CurrentTab), tostring(self.CurrentActID))
  local ActivityCenterModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ActivityCenterModule)
  ActivityCenterModule:BuildDisplaySceneData(self.DisplayScene)
  local Proxy = ActivityCenterModule:GetDataProxy(self.DisplayScene)
  if not Proxy or not Proxy:HasAnyData() then
    log(bWriteLog and "ActivityCenter_Main_UIBP:RefreshData - empty state (no proxy or no data), reset to empty")
    self:_ResetToEmpty()
    self.FirstEnter = false
    return
  end
  self.TabList = Proxy:GetSwitchTypeList()
  if #self.TabList == 0 then
    log(bWriteLog and "ActivityCenter_Main_UIBP:RefreshData - empty state (TabList is empty), reset to empty")
    self:_ResetToEmpty()
    self.FirstEnter = false
    return
  end
  self.IsEmpty = false
  self:_ApplyTabIcons()
  log_format("ActivityCenter_Main_UIBP:RefreshData - TabList built, tab count=%s", tostring(#self.TabList))
  local targetActTabInfo
  if self.FirstEnter then
    local JumpActID = self.ExtraData.actId
    if JumpActID then
      targetActTabInfo = Proxy:GetActTabInfo(JumpActID)
      if not targetActTabInfo then
        local resolvedId = self:ResolveJumpActId(JumpActID)
        if resolvedId and resolvedId ~= JumpActID then
          targetActTabInfo = Proxy:GetActTabInfo(resolvedId)
          log_format("ActivityCenter_Main_UIBP:RefreshData - first enter, JumpActID=%s resolved to=%s, hit=%s", tostring(JumpActID), tostring(resolvedId), tostring(targetActTabInfo ~= nil))
        end
      end
      if targetActTabInfo then
        log_format("ActivityCenter_Main_UIBP:RefreshData - first enter, try JumpActID=%s, hit=%s", tostring(JumpActID), tostring(true))
      end
    end
    if not targetActTabInfo then
      local JumpTabID = self.ExtraData.tabId
      if JumpTabID then
        targetActTabInfo = Proxy:GetFirstTabInfoBySwitchType(JumpTabID)
        log_format("ActivityCenter_Main_UIBP:RefreshData - first enter, try JumpTabID=%s, hit=%s", tostring(JumpTabID), tostring(targetActTabInfo ~= nil))
      end
    end
  else
    targetActTabInfo = Proxy:GetActTabInfo(self.CurrentActID)
    log_format("ActivityCenter_Main_UIBP:RefreshData - non-first refresh, keep CurrentActID=%s, still valid=%s", tostring(self.CurrentActID), tostring(targetActTabInfo ~= nil))
    if not targetActTabInfo and self.CurrentTab ~= 0 then
      targetActTabInfo = Proxy:GetFirstTabInfoBySwitchType(self.CurrentTab)
      log_format("ActivityCenter_Main_UIBP:RefreshData - current act invalid, fallback to first act of CurrentTab=%s, hit=%s", tostring(self.CurrentTab), tostring(targetActTabInfo ~= nil))
    end
  end
  if targetActTabInfo then
    self:_ApplySelectionByActTabInfo(Proxy, targetActTabInfo)
  else
    log(bWriteLog and "ActivityCenter_Main_UIBP:RefreshData - no target hit, fallback to first tab and first act")
    self:_ApplySelectionToFirst(Proxy)
  end
  self.ActTabList = Proxy:GetTabListBySwitchType(self.CurrentTab)
  log_format("ActivityCenter_Main_UIBP:RefreshData - result. CurrentTab=%s, CurrentTabIndex=%s, CurrentActID=%s, CurrentActIndex=%s, ActTabList size=%s", tostring(self.CurrentTab), tostring(self.CurrentTabIndex), tostring(self.CurrentActID), tostring(self.CurrentActIndex), tostring(#self.ActTabList))
  self.FirstEnter = false
end

function ActivityCenter_Main_UIBP:RefreshDynamic(isDirty)
  self:RefreshEmptyStatus()
  self:RefreshTabScroll()
  self:RefreshActivityScroll()
  self:RefreshActUI(isDirty)
  self:RefreshCalendarEntry()
end

function ActivityCenter_Main_UIBP:RefreshEmptyStatus()
  if self.IsEmpty then
    self:CloseCurActUI()
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Empty, true)
    self:SetWidgetVisible(self.UIRoot.Border_SwitchAndTab, false)
    self:SetWidgetVisible(self.UIRoot.Image_Background, false)
    self:SetWidgetVisible(self.UIRoot.Image_SplitLine, false)
  else
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Empty, false)
    self:SetWidgetVisible(self.UIRoot.Border_SwitchAndTab, true)
    self:SetWidgetVisible(self.UIRoot.Image_SplitLine, true)
  end
end

function ActivityCenter_Main_UIBP:RefreshTabScroll()
  self.TabScroll:SetTabs(self.TabList, self.CurrentTabIndex)
end

function ActivityCenter_Main_UIBP:RefreshActivityScroll()
  self.ActivityScroll:SetData(self.ActTabList)
  self.ActivityScroll:Select(self.CurrentActIndex)
end

function ActivityCenter_Main_UIBP:RefreshActUI(isDirty)
  self._gameletReadyCheckSerial = (self._gameletReadyCheckSerial or 0) + 1
  local gameletReadyCheckSerial = self._gameletReadyCheckSerial
  local actTabInfo = self.ActivityScroll:GetItemData(self.CurrentActIndex)
  if not actTabInfo then
    return
  end
  self:RefreshRightTopItemShow(actTabInfo)
  local originParams = self.OriginParams
  self.OriginParams = nil
  local ActivityCenterModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ActivityCenterModule)
  local UIKeyName, data, IsNotice
  if actTabInfo.eSource == ActivityMacros.ActTabInfoSource.Activity then
    data = ActivityCenterModule:GetActivitySourceData(self.CurrentActID)
    self.CurrentPageKey = ActivityCenterModule:GetActPageType(data)
  elseif actTabInfo.eSource == ActivityMacros.ActTabInfoSource.Extra then
    local tConfigData = ActivityCenterModule:GetExtraSourceData(self.CurrentActID)
    self.CurrentPageKey = tConfigData.cfg.showType
    data = tConfigData.data
  elseif actTabInfo.eSource == ActivityMacros.ActTabInfoSource.Notice then
    data = ActivityCenterModule:GetNoticeSourceData(self.CurrentActID)
    self.CurrentPageKey = ActivityUtil.GetNoticePageType(data)
    IsNotice = true
  end
  UIKeyName = C_ActPageUI[self.CurrentPageKey]
  local ActivityRedDot = require("client.slua.logic.activity.RedPoint.ActivityRedDot")
  ActivityRedDot.MarkEnterRedDot(self.CurrentActID)
  UIKeyName = self:RefreshPandoraStartUpUI(data, UIKeyName)
  if UIKeyName == "GameletContainer_UIBP" and data and data.ImgLink and data.ImgLink ~= "" then
    self:RefreshGameletStartUpUI(data, IsNotice, originParams, isDirty, gameletReadyCheckSerial)
    return
  end
  self:RefreshBackgroundImage(data, IsNotice)
  self:ShowCurActUI(UIKeyName, data, IsNotice, originParams, isDirty)
end

function ActivityCenter_Main_UIBP:RefreshPandoraStartUpUI(data, UIKeyName)
  local imgLink = data and data.ImgLink or ""
  if not JumpUtils.IsPanDoraJumpUrl(imgLink) then
    return UIKeyName
  end
  local pandora_v2_adapter = require("client.slua.logic.Pandora.pandora_v2_adapter")
  local bResReady, activityName = pandora_v2_adapter:IsJumpResReady(imgLink)
  if not bResReady then
    log(bWriteLog and string.format("[PandoraStartUp] ActivityCenter_Main_UIBP:RefreshPandoraStartUpUI. res not ready, switch PandoraContainer_UIBP -> PandoraStartUp_UIBP actId=%s activity=%s imgLink=%s", tostring(self.CurrentActID), tostring(activityName), tostring(imgLink)))
    data.originUIKeyName = UIKeyName
    data.fullScreen = false
    UIKeyName = "PandoraStartUp_UIBP"
  end
  return UIKeyName
end

function ActivityCenter_Main_UIBP:RefreshGameletStartUpUI(data, isNotice, originParams, isDirty, gameletReadyCheckSerial)
  local params = StringUtil.ParseURLParams(data.ImgLink)
  local appId = tostring(params and params.appId or "")
  if appId == "" or appId == "0" then
    log(bWriteLog and "ActivityCenter_Main_UIBP:RefreshGameletStartUpUI. invalid appId, use container")
    self:RefreshBackgroundImage(data, isNotice)
    self:ShowCurActUI("GameletContainer_UIBP", data, isNotice, originParams, isDirty)
    return
  end
  local GameletOnDemand = require("client.slua.logic.gamelet.GameletOnDemand")
  local activityData = data
  local activityIsNotice = isNotice
  local activityOriginParams = originParams
  local bQueryFinished = false
  local bFallbackShown = false
  local nQueryTimeoutTimer
  
  local function IsCurrentQuery()
    return slua.isValid(self.UIRoot) and gameletReadyCheckSerial == self._gameletReadyCheckSerial
  end
  
  local function ShowGameletContainer()
    self:ShowCurActUI("GameletContainer_UIBP", activityData, activityIsNotice, activityOriginParams, isDirty)
  end
  
  self:RefreshBackgroundImage(activityData, activityIsNotice)
  self:CloseCurActUI()
  nQueryTimeoutTimer = self:AddTimerOnce(GAMELET_READY_QUERY_TIMEOUT, function()
    nQueryTimeoutTimer = nil
    if bQueryFinished or not IsCurrentQuery() then
      return
    end
    bFallbackShown = true
    log(bWriteLog and string.format("ActivityCenter_Main_UIBP:RefreshGameletStartUpUI. query timeout, fallback appId=%s", appId))
    ShowGameletContainer()
  end)
  GameletOnDemand:IsAppReady(appId, function(bReady, item)
    if bQueryFinished or not IsCurrentQuery() then
      return
    end
    bQueryFinished = true
    if nQueryTimeoutTimer then
      self:RemoveTimer(nQueryTimeoutTimer)
      nQueryTimeoutTimer = nil
    end
    log(bWriteLog and string.format("ActivityCenter_Main_UIBP:RefreshActUI. Gamelet appId=%s ready=%s state=%s", appId, tostring(bReady), tostring(item and item.state)))
    if bReady then
      local gameletInterface = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_gamelet_interface)
      if GameletOnDemand:IsEnabled() and (not gameletInterface or not gameletInterface:IsInterfaceReady(appId)) then
        GameletOnDemand:RequestAppLoad({appId})
      end
      if not bFallbackShown then
        ShowGameletContainer()
      end
      return
    end
    self:ShowCurActUI("GameletEmbeddedStartUp_UIBP", {
      appId = appId,
      bFromActivityCenter = true,
      bIsGameletApp = false,
      bEmbedded = true,
      actData = activityData,
      isNotice = activityIsNotice,
      originParams = activityOriginParams
    }, false, nil, bFallbackShown or isDirty)
  end)
end

function ActivityCenter_Main_UIBP:RefreshBackgroundImage(data, isNotice)
  self:WidgetHidden(self.UIRoot.Activty_Load_Item)
  if self.CurrentPageKey == "Activty_Page2_UIBP_New" or self.CurrentPageKey == "Activity_EntrySet_UIBP" or self.CurrentPageKey == "Activity_Image_UIBP" then
    self:SetWidgetVisible(self.UIRoot.Image_Mask, false)
    self.NeedShowMask = false
  else
    self.NeedShowMask = true
  end
  if not data then
    return
  end
  if data and data.Type == ActivityType.ACTIVITY_CALENDAR or self.CurrentPageKey == "PassworRedEnvelope_UIBP" or self.CurrentPageKey == "Activty_Page2_UIBP_New" then
    self.UIRoot.Image_Background:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    return
  else
    self.UIRoot.Image_Background:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  end
  local url = ""
  if isNotice then
    url = data.EventCenter
  elseif data.Type == ActivityType.NOTICE_INFO then
    url = data.Detail
  else
    url = data.ImgUrl
  end
  local sDefaultBg = ActivityUtil.GetDefaultBg(data, self.CurrentTab)
  local bEnableRegionalizationImageDownload = data.back_int_value == ActivityBackUpIntType.RegionCDN
  self:_DownloadBackgroundImageByUrl(url, sDefaultBg, bEnableRegionalizationImageDownload)
end

function ActivityCenter_Main_UIBP:_DownloadBackgroundImageByUrl(url, sDefaultBg, bEnableRegionalizationImageDownload)
  self:SetTexture(self.UIRoot.Image_Background, sDefaultBg)
  if self.BGImageDownloadIndex and self.BGImageDownloadIndex > 0 then
    self:CancelImageDownloadByIndex(self.BGImageDownloadIndex)
    self.BGImageDownloadIndex = nil
  end
  if url and url ~= "" then
    local util = require("client.slua_ui_framework.util")
    url = util.GetUrlByLanguage(url)
    if util.IsOnlineImageUrl(url) then
      self.UIRoot.Activty_Load_Item:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      self.UIRoot.Activty_Load_Item:PlayUserWidgetAnimation(self.UIRoot.Activty_Load_Item.Anima_Loading, 0, 0, 0, 1)
      log(bWriteLog and string.format("ActivityCenter_Main_UIBP:_DownloadBackgroundImageByUrl. url=%s", url))
      self:SetTexture(self.UIRoot.Image_Background, sLoadingPath)
      local params = {}
      params.needLocalize = true
      params.bEnableRegionalizationImageDownload = bEnableRegionalizationImageDownload
      
      function params.onDownloadSuccess(texture, downloadUrl)
        self:DownloadBackgroundImageSuccess(texture)
      end
      
      function params.onDownloadFail(downloadUrl)
        log(bWriteLog and string.format("ActivityCenter_Main_UIBP:_DownloadBackgroundImageByUrl. download fail, url=%s", downloadUrl))
        self:DownloadBackgroundImageFailed(sDefaultBg)
      end
      
      local ImageIndex = self:SetTexture(self.UIRoot.Image_Background, url, params)
      if ImageIndex and 0 < ImageIndex then
        self.BGImageDownloadIndex = ImageIndex
      end
    elseif string.find(url, "/Game/") then
      self:SetTexture(self.UIRoot.Image_Background, url)
      if self.NeedShowMask then
        self:SetWidgetVisible(self.UIRoot.Image_Mask, true)
      end
    end
  elseif self.NeedShowMask then
    self:SetWidgetVisible(self.UIRoot.Image_Mask, true)
  end
end

function ActivityCenter_Main_UIBP:OnRefreshChangeBGImage(_, _, imagePath, _)
  if not slua.isValid(self.UIRoot) then
    return
  end
  if self.UIRoot.Image_Background:GetVisibility() == UEnums.ESlateVisibility.Collapsed then
    return
  end
  local data
  if self.CurrentActID then
    local ActivityCenterModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ActivityCenterModule)
    data = ActivityCenterModule:GetActivitySourceData(self.CurrentActID)
  end
  local sDefaultBg = data and ActivityUtil.GetDefaultBg(data, self.CurrentTab) or sLoadingPath
  self:_DownloadBackgroundImageByUrl(imagePath, sDefaultBg, false)
end

function ActivityCenter_Main_UIBP:OnRefreshTab(widget, index)
  if not widget or not index then
    return
  end
  local tabInfo = self.TabList[index]
  if not tabInfo or not tabInfo.nType then
    return
  end
  local ActivityRedDot = require("client.slua.logic.activity.RedPoint.ActivityRedDot")
  local systemName = ActivityRedDot.DisplayScene2SystemName(self.DisplayScene)
  local redPoint = ActivityRedDot.GetRedDotData(systemName, tabInfo.nType, 0)
  if redPoint and widget.Reddot_Anchor then
    widget.Reddot_Anchor:Bind(redPoint)
  end
end

function ActivityCenter_Main_UIBP:RefreshRightTopItemShow(tTabData)
  local node_root = self.UIRoot
  local ESlateVisibility = UEnums.ESlateVisibility
  local nMaxCount = 2
  if not (tTabData and tTabData.tShowCoin) or nMaxCount < #tTabData.tShowCoin then
    node_root.HorizontalBox_Coin:SetWidgetVisibility(ESlateVisibility.Collapsed)
    return
  end
  for i = 1, nMaxCount do
    local itemIdRaw = tTabData.tShowCoin[i]
    if itemIdRaw then
      local nItemId = tonumber(itemIdRaw)
      local sItemCfgPath = nItemId and UIUtil.GetItemSmallIcon(nItemId) or nil
      if sItemCfgPath and sItemCfgPath ~= "" then
        self:SetTexture(node_root["Image_Coin_" .. i], sItemCfgPath)
        node_root["Text_CoinCount_" .. i]:SetText(self:GetItemCount(nItemId))
        node_root["Canvas_Coin_" .. i]:SetWidgetVisibility(ESlateVisibility.SelfHitTestInvisible)
      else
        node_root["Canvas_Coin_" .. i]:SetWidgetVisibility(ESlateVisibility.Collapsed)
      end
    else
      node_root["Canvas_Coin_" .. i]:SetWidgetVisibility(ESlateVisibility.Collapsed)
    end
  end
  node_root.HorizontalBox_Coin:SetWidgetVisibility(ESlateVisibility.SelfHitTestInvisible)
end

function ActivityCenter_Main_UIBP:GetItemCount(nItemId)
  local nCount = 0
  local coinCfg = require("client.slua.config.coinCfg")
  if coinCfg[nItemId] then
    nCount = DataMgr[coinCfg[nItemId]]
  else
    local WardrobeData = require("client.slua.logic.wardrobe.wardrobe_data")
    nCount = WardrobeData:GetHallDepotItemCountByResID(nItemId)
  end
  return FuncUtil.Conv_Int64ToText(nCount or 0)
end

function ActivityCenter_Main_UIBP:BatchPandoraRedPoint()
  self:AddTimerOnce(0, function()
    local ret = {
      type = "EnterActivityCenter",
      content = ""
    }
    local HostedProtoBridge = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.HostedProtoBridge)
    HostedProtoBridge:SendToAllHosted(ret)
  end)
end

function ActivityCenter_Main_UIBP:ShowCurActUI(UIKeyName, data, isNotice, originParams, isDirty)
  if not UIKeyName then
    return
  end
  self:CloseCurActUI()
  self.CurActUI = self:CreateChildWindow(self.UIRoot.CanvasPanel_Content, UIManager.UI_Config[UIKeyName], data, isNotice, originParams)
  if not isDirty then
    if gem_report_utils.SubEventName_ActivityCenterActivityOpen then
      gem_report_utils.ReportBtnClickEvent(gem_report_utils.SubEventName_ActivityCenterActivityOpen, tostring(self.CurrentActID))
    end
    local TLogReasonStr = json.encode({
      event_name = gem_report_utils.SubEventName_ActivityCenterActivityOpen,
      activity_id = self.CurrentActID
    })
    tlog_report_utils.ReportTLogEvent(TLogEventDefine.ActivityCenterOpenActivity, 0, TLogReasonStr)
  end
end

function ActivityCenter_Main_UIBP:CloseCurActUI()
  if self.CurActUI then
    self.CurActUI:CloseSelf()
    self.CurActUI = nil
  end
end

function ActivityCenter_Main_UIBP:DownloadBackgroundImageSuccess(texture)
  if slua.isValid(self.UIRoot) then
    local loadingItem = self.UIRoot.Activty_Load_Item
    loadingItem:StopAnimation(loadingItem.Anima_Loading)
    loadingItem:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    if self.NeedShowMask then
      self:SetWidgetVisible(self.UIRoot.Image_Mask, true)
    end
    self.BGImageDownloadIndex = nil
  end
end

function ActivityCenter_Main_UIBP:DownloadBackgroundImageFailed(sDefaultBg)
  if slua.isValid(self.UIRoot) then
    local loadingItem = self.UIRoot.Activty_Load_Item
    loadingItem:StopAnimation(loadingItem.Anima_Loading)
    self:WidgetCollapse(loadingItem)
    self:SetTexture(self.UIRoot.Image_Background, sDefaultBg)
    if self.NeedShowMask then
      self:SetWidgetVisible(self.UIRoot.Image_Mask, true)
    end
    self.BGImageDownloadIndex = nil
  end
end

function ActivityCenter_Main_UIBP:GetDisplayScene()
  return self.DisplayScene
end

function ActivityCenter_Main_UIBP:RebuildRedDot()
  local ActivityRedDot = require("client.slua.logic.activity.RedPoint.ActivityRedDot")
  local reddot_manager = require("client.slua.logic.reddot.reddot_manager")
  local SystemName = ActivityRedDot.DisplayScene2SystemName(self.DisplayScene)
  reddot_manager:OnSystemShow(self, SystemName)
  ActivityRedDot.BuildSceneFull(self.DisplayScene)
end

function ActivityCenter_Main_UIBP:JumpBack(uiData)
  if not uiData then
    return
  end
  if uiData.actID then
    self:JumpTo({
      id = uiData.actID
    })
  end
  if uiData.common_use_items then
    local ctorData = uiData.common_use_items.ctorData
    if ctorData and ctorData[1] then
      UIManager.ShowUI(UIManager.UI_Config.common_use_items, ctorData[1], table.unpack(ctorData[2] or {}))
    end
  end
  if uiData.package_preview_panel then
    local ctorData = uiData.package_preview_panel.ctorData
    if ctorData and ctorData[1] then
      UIManager.ShowUI(UIManager.UI_Config.package_preview_panel, ctorData[1], ctorData[2])
    end
  end
end

function ActivityCenter_Main_UIBP:ResolveJumpActId(actId)
  if not actId then
    return nil
  end
  local SubAct201 = ActivityNewSystem.GetSubAct201()
  if SubAct201 and SubAct201[actId] then
    return SubAct201[actId]
  end
  local fatherId = AreaGroupSystem.GetFatherIDBySubID(actId)
  if fatherId then
    return fatherId
  end
  return actId
end

function ActivityCenter_Main_UIBP:JumpTo(vars)
  if not vars then
    log(bWriteLog and "ActivityCenter_Main_UIBP:JumpTo - vars is nil, ignore")
    return false
  end
  if self.IsEmpty or #self.TabList == 0 then
    log(bWriteLog and "ActivityCenter_Main_UIBP:JumpTo - empty state, cannot jump")
    return false
  end
  local ActivityCenterModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ActivityCenterModule)
  local Proxy = ActivityCenterModule and ActivityCenterModule:GetDataProxy(self.DisplayScene)
  if not Proxy then
    log(bWriteLog and "ActivityCenter_Main_UIBP:JumpTo - proxy not ready, cannot jump")
    return false
  end
  local targetActTabInfo
  if vars.id then
    local jumpActId = tonumber(vars.id)
    if jumpActId then
      targetActTabInfo = Proxy:GetActTabInfo(jumpActId)
      if not targetActTabInfo then
        local resolvedId = self:ResolveJumpActId(jumpActId)
        if resolvedId and resolvedId ~= jumpActId then
          targetActTabInfo = Proxy:GetActTabInfo(resolvedId)
          log_format("ActivityCenter_Main_UIBP:JumpTo - try actId=%s, resolved to=%s, hit=%s", tostring(jumpActId), tostring(resolvedId), tostring(targetActTabInfo ~= nil))
        end
      end
      if targetActTabInfo then
        log_format("ActivityCenter_Main_UIBP:JumpTo - try actId=%s, hit=%s", tostring(jumpActId), tostring(true))
      end
    end
  end
  if not targetActTabInfo and vars.tab then
    local jumpTabId = tonumber(vars.tab)
    if jumpTabId then
      targetActTabInfo = Proxy:GetFirstTabInfoBySwitchType(jumpTabId)
      log_format("ActivityCenter_Main_UIBP:JumpTo - try tabId=%s, hit=%s", tostring(jumpTabId), tostring(targetActTabInfo ~= nil))
    end
  end
  if not targetActTabInfo then
    log(bWriteLog and "ActivityCenter_Main_UIBP:JumpTo - no target hit")
    return false
  end
  self.OriginParams = vars
  self:_ApplySelectionByActTabInfo(Proxy, targetActTabInfo)
  self.ActTabList = Proxy:GetTabListBySwitchType(self.CurrentTab)
  self.TabScroll:SelectTab(self.CurrentTabIndex, true)
  self:RefreshActivityScroll()
  self:RefreshActUI()
  log_format("ActivityCenter_Main_UIBP:JumpTo - success. CurrentTab=%s, CurrentTabIndex=%s, CurrentActID=%s, CurrentActIndex=%s", tostring(self.CurrentTab), tostring(self.CurrentTabIndex), tostring(self.CurrentActID), tostring(self.CurrentActIndex))
  return true
end

function ActivityCenter_Main_UIBP:DoEnterSomething()
  local UpassHandle = require("client.network.Protocol.UpassHandle")
  UpassHandle.send_limited_time_task_sync_req(true)
  UIUtil.ShowLobbyCamera(false)
  self:AddTimerLoop(10, function()
    for actType, _ in pairs(T_NeedReReqActData) do
      local act = ActivityNewSystem.GetActivityByType(actType)
      if act then
        log_format("ActivityCenter_Main_UIBP:T_NeedReReqActData - re-request act, type=%s, id=%s", tostring(actType), tostring(act.ID))
        local ActivityHandler = require("client.network.Protocol.ActivityHandler")
        ActivityHandler.send_get_activity_one_req(act.ID)
      end
    end
  end, TIMER_INFINITE, 180)
  local logic_cost_collector = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_cost_collector)
  logic_cost_collector:MarkIsolatedEventEnd(logic_cost_collector.ISOLATED_EVENT_NAMES.OpenActivityUI)
end

local class = require("class")
local UIBase = require("client.slua_ui_framework.base")
local CActivityCenter_Main_UIBP = class(UIBase, nil, ActivityCenter_Main_UIBP)
return CActivityCenter_Main_UIBP
