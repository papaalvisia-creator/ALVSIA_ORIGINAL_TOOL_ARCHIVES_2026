local LogicXTask = require("client.slua.logic.TxMission.xmission_task.logic_xmission_task")
local LogicXTaskBrief = require("client.slua.logic.TxMission.xmission_task.logic_xmission_task_brief")
local LogicXTaskDetail = require("client.slua.logic.TxMission.xmission_task.logic_xmission_task_detail")
local LogicTxMissionMain = require("client.slua.logic.TxMission.logic_xmission_main")
local XTaskData = require("client.slua.logic.TxMission.xmission_task.xmission_task_data")
local UI_XMission_Task_List = {}
local C_StatusColorAccept = 0
local C_StatusColorClaim = 1
local C_StatusColorProgress = 2
local C_SwitcherList = 0
local C_SwitcherEmpty = 1

function UI_XMission_Task_List:ctor()
end

function UI_XMission_Task_List:OnInitialize()
  UI_XMission_Task_List.__super.OnInitialize(self)
end

function UI_XMission_Task_List:RegistEvents()
  UI_XMission_Task_List.__super.RegistEvents(self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_task, self.OnClickTask, self)
  self:AddCommonEvent(EVENTTYPE_TPLANPVE_NORMAL, EVENTID_TPLANPVE_TASK_ALL_UPDATE, self.RefreshAll, self)
  self:AddCommonEvent(EVENTTYPE_TPLANPVE_NORMAL, EVENTID_TPLANPVE_TASK_ONE_UPDATE, self.RefreshAll, self)
end

function UI_XMission_Task_List:OnPostInitialize()
  self:RefreshAll()
end

function UI_XMission_Task_List:UpdateUI()
  self:RefreshAll()
end

function UI_XMission_Task_List:RefreshAll()
  self:RefreshTaskList()
end

function UI_XMission_Task_List:RefreshTaskList()
  local logic_tplanpve_task = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_tplanpve_task)
  local tasks, reddot, actionHasAvailable, seasonHasAvailable = logic_tplanpve_task:GetTaskViewList()
  log_tree(bWriteLog and "UI_XMission_Task_List:RefreshTaskList tasks", tasks)
  local actionTask = tasks[1]
  local seasonTask = tasks[2]
  self:_FillRow(1, actionTask)
  self:_FillRow(2, seasonTask)
  local hasAvailable = actionHasAvailable or seasonHasAvailable
  self.actionHasAvailable = actionHasAvailable
  if self.UIRoot.WidgetSwitcher_Task then
    local bHasTask = actionTask ~= nil or seasonTask ~= nil
    self.UIRoot.WidgetSwitcher_Task:SetActiveWidgetIndex(bHasTask and C_SwitcherList or C_SwitcherEmpty)
  end
  local ModReddotSystem = require("GameLua.Mod.Library.Client.ModReddotSystem")
  local redPointType = ModReddotSystem.ERedDotStyle.GIFT
  self.UIRoot.Reddot_Anchor_Task:ShowRedPointByPath(redPointType)
  self:SetWidgetVisible(self.UIRoot.Reddot_Anchor_Task, hasAvailable)
  self:SetWidgetVisible(self.UIRoot.SizeBox_RedDot, reddot and not hasAvailable)
end

function UI_XMission_Task_List:_IsSeasonTaskUnlocked()
  local prestigeLevel = LogicTxMissionMain.GetPrestigeLevel() or 0
  for _, task in ipairs(LogicXTaskDetail.branchTaskCache or {}) do
    if self:_CanShowTask(task, prestigeLevel) then
      return true
    end
  end
  return false
end

function UI_XMission_Task_List:_CanShowTask(task, prestigeLevel)
  if not task then
    return false
  end
  local status = task.status
  if status == XTaskData.const_received then
    return false
  end
  if status == XTaskData.const_not_unlocked then
    return prestigeLevel >= tonumber(task.prestige or 0)
  end
  return status == XTaskData.const_processing or status == XTaskData.const_available or status == XTaskData.const_cangive
end

function UI_XMission_Task_List:_PickOne(taskList)
  local prestigeLevel = LogicTxMissionMain.GetPrestigeLevel() or 0
  local candidates = {}
  for _, task in ipairs(taskList or {}) do
    if self:_CanShowTask(task, prestigeLevel) then
      table.insert(candidates, task)
    end
  end
  table.sort(candidates, LogicXTaskDetail.sortTask)
  return candidates[1]
end

function UI_XMission_Task_List:_GetStatusUI(status)
  if status == XTaskData.const_available or status == XTaskData.const_cangive then
    return 6161, C_StatusColorClaim
  end
  if status == XTaskData.const_processing then
    return 4001, C_StatusColorProgress
  end
  return 8880381, C_StatusColorAccept
end

function UI_XMission_Task_List:_FillRow(index, task)
  local box = self.UIRoot[string.format("HorizontalBox_Task0%d", index)]
  local nameWidget = self.UIRoot[string.format("TextBlock_Name0%d", index)]
  local statusWidget = self.UIRoot[string.format("TextBlock_Status0%d", index)]
  if not box then
    return
  end
  if not task then
    self:SetWidgetVisible(box, false)
    return
  end
  self:SetWidgetVisible(box, true)
  if nameWidget then
    nameWidget:SetText(task.task_name or "")
  end
  if statusWidget then
    local locId, colorIndex = self:_GetStatusUI(task.status)
    local statusText = LocUtil.GetLocalizeResStr(locId) or ""
    statusWidget:SetText(string.format("(%s)", statusText))
    if statusWidget.SetActiveColorIndex then
      statusWidget:SetActiveColorIndex(colorIndex)
    end
  end
end

function UI_XMission_Task_List:OnClickTask()
  self:PlayAudio(sound_config.TPlan_Task_Enter)
  local logic_xmission_system_newbie_guide = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_system_newbie_guide)
  local logic_tplanpve_task_marco = require("GameLua.Mod.Lobby.Split.TPlanPVE.logic.Task.logic_tplanpve_task_marco")
  if logic_xmission_system_newbie_guide then
    local lineId, step, style = logic_xmission_system_newbie_guide:GetCurrentGuide()
    log(bWriteLog and string.format("UI_XMission_Task_List:OnClickTask lineId %s, step %s, style %s", lineId, step, style))
    if lineId == "Mission" and step == 2 and style == 1 then
      UIManager.ShowUI(UIManager.UI_Config.TPlanX_Task_QuestSystem_UIBP, {
        from = "lobby_newbie"
      }, logic_tplanpve_task_marco.TaskType.Action)
      return
    end
  end
  UIManager.ShowUI(UIManager.UI_Config.TPlanX_Task_QuestSystem_UIBP, {from = "lobby"}, self.actionHasAvailable and logic_tplanpve_task_marco.TaskType.Action or logic_tplanpve_task_marco.TaskType.Season)
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CUI_XMission_Task_List = class(ui_base, nil, UI_XMission_Task_List)
return CUI_XMission_Task_List
