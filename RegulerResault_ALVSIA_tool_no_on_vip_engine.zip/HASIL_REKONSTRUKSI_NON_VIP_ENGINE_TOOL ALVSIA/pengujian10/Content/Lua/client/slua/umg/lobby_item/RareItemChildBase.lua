local RareItemChildBase = {}
local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
local UIUtil = require("client.common.ui_util")
local ItemMacros = require("client.slua.config.ClientMacros.ItemMacros")

function RareItemChildBase:RegistEvents()
  RareItemChildBase.__super.RegistEvents(self)
  if self.UIRoot.Button_Use then
    self:AddOnClickedEventByControl(self.UIRoot.Button_Use, self.OnBtnUseClick, self)
  end
  if self.UIRoot.Button_5 then
    self:AddOnClickedEventByControl(self.UIRoot.Button_5, self.OnBtnUseClick, self)
  end
  if self.UIRoot.Button_4 then
    self:AddOnClickedEventByControl(self.UIRoot.Button_4, self.OnSharePicBtnClick, self)
  end
  if self.UIRoot.Button_3 then
    self:AddOnClickedEventByControl(self.UIRoot.Button_3, self.OnButton_CancelClick, self)
  end
  self:AddControlEventByControl(self.UIRoot.Anim_Fadein, "OnAnimationFinished", self.OnAnimationFinished, self)
end

function RareItemChildBase:OnPostInitialize()
  RareItemChildBase.__super.OnPostInitialize(self)
  self:RefreshItemName()
  self:PlayAnim()
  self:SetShareWidget()
  self:UpdateShareBtn()
end

function RareItemChildBase:SetShareWidget()
end

function RareItemChildBase:RefreshItemName()
  local ItemGetModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.rare_item_get_module)
  self.item = ItemGetModule:GetCurItem()
  log(bWriteLog and "  : RareItemChildBase RefreshItemName itemId: " .. tostring(self.item.res_id))
  self.itemTb = CDataTable.GetTableData("Item", self.item.res_id)
  if self.UIRoot.TextBlock_itemName then
    self.UIRoot.TextBlock_itemName:SetText(self.itemTb.ItemName)
    local rareCfg = CDataTable.GetTableData("RareItemCfg", self.item.res_id)
    self.wordColor = rareCfg.TColor_af
    self:SetWordColor(self.UIRoot.TextBlock_itemName)
  end
end

function RareItemChildBase:SetWordColor(widget)
  local color = self.wordColor
  if color and color:Num() > 0 then
    widget:SetColorAndOpacity(FSlateColor(FLinearColor(color:Get(0), color:Get(1), color:Get(2), color:Get(3))))
  else
    widget:SetColorAndOpacity(FSlateColor(FLinearColor(1, 1, 1, 1)))
  end
end

function RareItemChildBase:UpdateShareBtn()
  local ItemGetModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.rare_item_get_module)
  local root = self.UIRoot
  local bBox = ItemGetModule:BShowUse(self.itemTb.itemType)
  local bBoxtemp = ItemGetModule:BShowUseXSuit(self.item)
  if self.shareWidgetName then
    self:SetWidgetVisible(root[self.shareWidgetName], bBoxtemp, true)
  end
  if root.Overlay_Use then
    self:SetWidgetVisible(root.Overlay_Use, bBox, true)
  end
  if root.Button_Use then
    self:SetWidgetVisible(root.Button_Use, bBox, true)
  end
end

function RareItemChildBase:OnBtnUseClick()
  log(bWriteLog and "  : RareItemChildBase:OnBtnUseClick")
  local data = wardrobe_data:GetHallDepotItemDataByResID(self.item.res_id)
  if data then
    UIUtil.OpenUseItemUI(data.insID)
  end
end

function RareItemChildBase:OnButton_CancelClick()
  self:PlayAudio(sound_config.click)
  EventSystem:postEvent(EVENTTYPE_RARE_ITEM_GET, EVENTTYPE_RARE_REMOVE_ONE)
end

function RareItemChildBase:OnSharePicBtnClick()
  self:PlayAudio(sound_config.click)
  self:Share()
end

function RareItemChildBase:Share()
  local ItemGetModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.rare_item_get_module)
  local itemId = self.item.res_id
  local logic_xmission_souvenirs = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_souvenirs)
  if logic_xmission_souvenirs:IsSouvenirsItem(itemId) then
    self:ShareSouvenirs(itemId)
  else
    ItemGetModule:ShowShare(itemId, self.item)
  end
end

function RareItemChildBase:ShareSouvenirs(itemId)
  log(bWriteLog and " ShareSouvenirs :" .. tostring(itemId))
  local logic_xmission_souvenirs = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_souvenirs)
  logic_xmission_souvenirs:ShareItem(itemId)
end

function RareItemChildBase:OnClickGoEquipment()
  self:PlayAudio(sound_config.click)
  local ItemGetModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.rare_item_get_module)
  local itemTb = self.itemTb
  if itemTb.ItemType == ENUM_ITEM_TYPE.Voice_Pack or itemTb.ItemType == ENUM_ITEM_TYPE.Music then
    local WardrobeLogic = require("client.slua.logic.wardrobe.logic_wardrobe_new")
    local WardrobeMacro = require("client.slua.umg.Wardrobe.wardrobe_macro")
    WardrobeLogic:Enter(WardrobeMacro.ENUM_WardrobePageTypeId.ENUM_WardrobePageType_Parachute, WardrobeMacro.ENUM_WardrobeSubTabString.ENUM_WardrobeSubTabString_quickmessage, {
      clearJumpChainWhenChangeTab = true,
      actorItemID = self.showitemdata.res_id
    })
    ItemGetModule:ClearData()
  end
end

function RareItemChildBase:OnAnimationFinished()
  log(bWriteLog and "  : RareItemChildBase:OnAnimationFinished")
  local root = self.UIRoot
  if root.Anim_Loop then
    root:PlayUserWidgetAnimation(root.Anim_Loop, 0, 0, 0, 1)
  end
end

function RareItemChildBase:PlayAnim()
  log(bWriteLog and "  : RareItemChildBase:PlayAnim")
  local root = self.UIRoot
  if root.Anim_Fadein then
    root:PlayUserWidgetAnimation(root.Anim_Fadein, 0, 1, 0, 1)
  end
end

local quality2Index = {
  [ItemMacros.QUALITY_RED] = 0,
  [ItemMacros.QUALITY_PINK] = 1,
  [ItemMacros.QUALITY_PURPLE] = 2,
  [ItemMacros.QUALITY_GOLDEN] = 3,
  [ItemMacros.QUALITY_TGOLDEN] = 3,
  [ItemMacros.QUALITY_Grey] = 4
}

function RareItemChildBase:SetNameBg()
  log(bWriteLog and "  : self.itemTb.ItemQuality: " .. tostring(self.itemTb.ItemQuality))
  local bgIndex = quality2Index[self.itemTb.ItemQuality]
  if bgIndex then
    self.UIRoot.WidgetSwitcher_NameBg:SetActiveWidgetIndex(bgIndex)
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_NameBg, true)
  else
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_NameBg, false)
  end
end

function RareItemChildBase:UpdateOneLevel(widgetData, needSetTexture)
  local root = self.UIRoot
  root[widgetData.nickName]:SetText(self.item.ItemName or self.itemTb.ItemName)
  local imageWidget
  self.nSwitcherIndex = 0
  local itemType = self.itemTb.ItemType
  local ModelDisplayTypeHelper = require("client.logic.avatar.ModelDisplayTypeHelper")
  if itemType == ENUM_ITEM_TYPE.Extra then
    self.nSwitcherIndex = 0
    imageWidget = root[widgetData.good]
  elseif ModelDisplayTypeHelper.IsVehicle(self.itemTb.ItemType) then
    self.nSwitcherIndex = 1
    imageWidget = root[widgetData.car]
  elseif self.itemTb.ItemType == ENUM_ITEM_TYPE.Weapon then
    self.nSwitcherIndex = 2
    imageWidget = root[widgetData.gun]
  else
    log(bWriteLog and "  : itemType: " .. tostring(itemType))
    self.nSwitcherIndex = 3
    imageWidget = root[widgetData.other]
  end
  root[widgetData.switcher]:SetActiveWidgetIndex(self.nSwitcherIndex)
  self:SetNameBg()
  local ItemGetModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.rare_item_get_module)
  local propagation = self.UIRoot.TextBlock_1
  local delayTime = 2
  if propagation then
    delayTime = 0
    self:SetWidgetVisible(propagation, true)
  end
  local panel, drawNum, desc = ItemGetModule:ShowRankTitle(self.item, self, propagation, delayTime, 288)
  self:PlayUserWidgetAnimation(self.UIRoot.Anim_On, 0, 1, 0, 1)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_SpecialCorner, panel ~= nil)
  self.UIRoot.TextBlock_DrawCount:SetText(LocUtil.LocalizeResFormat(desc, drawNum))
  if not needSetTexture then
    return
  end
  if self.sPath and self.sPath ~= "" then
    local DefaultIcon = UIUtil.GetDefaultIcon(self.item.res_id)
    self:SetTexture(imageWidget, self.sPath, {defaultIcon = DefaultIcon})
  else
    local path, bHasAddKnownMissing = UIUtil.GetPreview(self.item.res_id, imageWidget)
    log(bWriteLog and "  : imageWidget: " .. tostring(imageWidget))
    local params = {bMatchSize = true, bHasAddKnownMissing = bHasAddKnownMissing}
    self:SetTexture(imageWidget, path, params)
  end
end

function RareItemChildBase:UpdateNum()
  local rare_item_cfg = require("client.slua.logic.common.CommonItemGet.rare_item_cfg")
  local Quality2ItemLocalIdS = rare_item_cfg.Quality2ItemLocalIdS
  local Quality2GunLocalIdS = rare_item_cfg.Quality2GunLocalIdS
  local Quality2LineColor = rare_item_cfg.Quality2LineColor
  local ItemGetModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.rare_item_get_module)
  local item = ItemGetModule:GetCurItem()
  local itemId = item.res_id
  local _itemData = CDataTable.GetTableData("Item", itemId)
  local ItemUpgradeMgr = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.ItemUpgradeModule)
  local isUpdateGun = ItemUpgradeMgr:IsUpdateGun(itemId)
  local quality = _itemData.ItemQuality
  local which = ItemGetModule:WhichNumber(itemId, quality, isUpdateGun)
  local resId = Quality2ItemLocalIdS[quality] or 4016
  if isUpdateGun then
    resId = Quality2GunLocalIdS[quality] or 18918
  end
  self.UIRoot.TextBlock_Which:SetText(LocUtil.LocalizeResFormat(resId, which))
  self:SetWordColor(self.UIRoot.TextBlock_Which)
  self:SetWidgetVisible(self.UIRoot.TextBlock_Which, 0 < which)
  if self.UIRoot.Image_Quality then
    self.UIRoot.Image_Quality:SetColorAndOpacity(Quality2LineColor[quality])
  end
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CRareItemChildBase = class(ui_base, nil, RareItemChildBase)
return CRareItemChildBase
