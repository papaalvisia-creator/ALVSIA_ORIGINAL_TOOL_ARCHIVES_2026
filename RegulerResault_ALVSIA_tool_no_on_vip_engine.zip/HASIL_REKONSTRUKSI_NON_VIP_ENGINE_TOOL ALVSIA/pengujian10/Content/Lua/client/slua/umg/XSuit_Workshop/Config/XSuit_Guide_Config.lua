local XSuit_Guide_Config = {
  [17] = {
    guideConfig = {
      Workshop = {
        [1] = {
          TitleID = 200000792,
          BPPath = "/Game/UMG/UI_BP/Common/Popup/Theme/Item/Common_Popup_Theme_Explain_Picture10_Item_UIBP.Common_Popup_Theme_Explain_Picture10_Item_UIBP",
          RefreshFun = function(node_root)
            if not node_root then
              return
            end
            local Util = require("client.slua_ui_framework.util")
            Util.SetTexture(node_root.Image_01, "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Texture/Guide/Img_4700_Xsuit_Wheel_Guide_01.Img_4700_Xsuit_Wheel_Guide_01", {sync = false})
            node_root.CanvasPanel_5:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
            node_root.Text_Pic_1:SetText(LocUtil.LocalizeResFormat(200000802))
          end
        }
      },
      Spin = {
        [1] = {
          TitleID = 200000799,
          BPPath = "/Game/UMG/UI_BP/Common/Popup/Theme/Item/Common_Popup_Theme_Explain_Picture10_Item_UIBP.Common_Popup_Theme_Explain_Picture10_Item_UIBP",
          RefreshFun = function(node_root)
            if not node_root then
              return
            end
            local Util = require("client.slua_ui_framework.util")
            Util.SetTexture(node_root.Image_01, "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Texture/Guide/Img_4700_Xsuit_Wheel_Guide_01.Img_4700_Xsuit_Wheel_Guide_01", {sync = false})
            node_root.CanvasPanel_5:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
            node_root.Text_Pic_1:SetText(LocUtil.LocalizeResFormat(200000802))
          end
        },
        [2] = {
          TitleID = 200000799,
          BPPath = "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Popup/XSuit_Popup_Theme_Explain_Picture02_Item_UIBP.XSuit_Popup_Theme_Explain_Picture02_Item_UIBP",
          RefreshFun = function(node_root, cfg, parentUI)
            if not node_root then
              return
            end
            local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
            local Util = require("client.slua_ui_framework.util")
            if node_root.TextBlock_Title1 then
              node_root.TextBlock_Title1:SetText(LocUtil.GetLocalizeResStr(18141485))
            end
            if node_root.TextBlock_Title2 then
              node_root.TextBlock_Title2:SetText(LocUtil.GetLocalizeResStr(18141486))
            end
            if node_root.Text_Pic_1 then
              node_root.Text_Pic_1:SetText(LocUtil.GetLocalizeResStr(18141436))
            end
            if node_root.Text_Pic_2 then
              node_root.Text_Pic_2:SetText(LocUtil.GetLocalizeResStr(18141437))
            end
            if parentUI and node_root.LoopScrollBox_Item_UIBP then
              parentUI._pageCaches = parentUI._pageCaches or {}
              local scrollBox = parentUI._pageCaches.scrollBox
              local bNeedCreate = not scrollBox or scrollBox.UIRoot ~= node_root.LoopScrollBox_Item_UIBP or not slua.isValid(scrollBox.UIRoot)
              if bNeedCreate then
                scrollBox = parentUI:InitChildClassScrollBox(node_root.LoopScrollBox_Item_UIBP, "client.slua.umg.XSuit_Workshop.Item.XSuit_Popup_Theme_Explain_Picture02_Item2_UIBP")
                parentUI._pageCaches.scrollBox = scrollBox
              end
              if scrollBox then
                local list = LogicXSuit.GetTaskRewardList and LogicXSuit.GetTaskRewardList() or {}
                scrollBox:SetData(list)
              end
            end
          end
        }
      },
      Material = {
        [1] = {
          TitleID = 200000821,
          BPPath = "/Game/UMG/UI_BP/Common/Popup/Theme/Item/Common_Popup_Theme_Explain_Picture02_Item_UIBP.Common_Popup_Theme_Explain_Picture02_Item_UIBP",
          RefreshFun = function(node_root)
            if not node_root then
              return
            end
            local Util = require("client.slua_ui_framework.util")
            Util.SetTexture(node_root.Image_Pic_1, "/Game/UMG/Texture_200/Lobby_NoAtlas/XSuit/XSuit_Upgrade_Image_01.XSuit_Upgrade_Image_01", {sync = false})
            Util.SetTexture(node_root.Image_Pic_2, "/Game/UMG/Texture_200/Lobby_NoAtlas/XSuit/XSuit_Upgrade_Image_02.XSuit_Upgrade_Image_02", {sync = false})
            node_root.Text_Pic_1:SetText(LocUtil.GetLocalizeResStr(200000823))
            node_root.Text_Pic_2:SetText(LocUtil.GetLocalizeResStr(200000824))
            node_root.Text_Desc:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
          end
        }
      }
    }
  },
  [16] = {
    guideConfig = {
      Workshop = {
        [1] = {
          TitleID = 200000792,
          BPPath = "/Game/UMG/UI_BP/Common/Popup/Theme/Item/Common_Popup_Theme_Explain_Picture02_Item_UIBP.Common_Popup_Theme_Explain_Picture02_Item_UIBP",
          RefreshFun = function(node_root)
            if not node_root then
              return
            end
            local Util = require("client.slua_ui_framework.util")
            Util.SetTexture(node_root.Image_Pic_1, "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Texture/Guide/XSuit_Druid_Image_Guide_01.XSuit_Druid_Image_Guide_01", {sync = false})
            Util.SetTexture(node_root.Image_Pic_2, "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Texture/Guide/XSuit_Druid_Image_Guide_02.XSuit_Druid_Image_Guide_02", {sync = false})
            node_root.Text_Pic_1:SetText(LocUtil.GetLocalizeResStr(200000793))
            node_root.Text_Pic_2:SetText(LocUtil.GetLocalizeResStr(200000794))
            node_root.Text_Desc:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
          end
        },
        [2] = {
          TitleID = 200000792,
          BPPath = "/Game/UMG/UI_BP/Common/Popup/Theme/Item/Common_Popup_Theme_Explain_Picture02_Item_UIBP.Common_Popup_Theme_Explain_Picture02_Item_UIBP",
          RefreshFun = function(node_root)
            if not node_root then
              return
            end
            local Util = require("client.slua_ui_framework.util")
            Util.SetTexture(node_root.Image_Pic_1, "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Texture/Guide/XSuit_Druid_Image_Guide_03.XSuit_Druid_Image_Guide_03", {sync = false})
            Util.SetTexture(node_root.Image_Pic_2, "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Texture/Guide/XSuit_Druid_Image_Guide_04.XSuit_Druid_Image_Guide_04", {sync = false})
            node_root.Text_Pic_1:SetText(LocUtil.GetLocalizeResStr(200000795))
            node_root.Text_Pic_2:SetText(LocUtil.GetLocalizeResStr(200000796))
            node_root.Text_Desc:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
          end
        },
        [3] = {
          TitleID = 200000792,
          BPPath = "/Game/UMG/UI_BP/Common/Popup/Theme/Item/Common_Popup_Theme_Explain_Picture02_Item_UIBP.Common_Popup_Theme_Explain_Picture02_Item_UIBP",
          RefreshFun = function(node_root)
            if not node_root then
              return
            end
            local Util = require("client.slua_ui_framework.util")
            Util.SetTexture(node_root.Image_Pic_1, "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Texture/Guide/XSuit_Druid_Image_Guide_05.XSuit_Druid_Image_Guide_05", {sync = false})
            Util.SetTexture(node_root.Image_Pic_2, "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Texture/Guide/XSuit_Druid_Image_Guide_06.XSuit_Druid_Image_Guide_06", {sync = false})
            node_root.Text_Pic_1:SetText(LocUtil.GetLocalizeResStr(200000797))
            node_root.Text_Pic_2:SetText(LocUtil.GetLocalizeResStr(200000798))
            node_root.Text_Desc:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
            node_root.Text_Desc:SetText("")
          end
        }
      },
      Spin = {
        [1] = {
          TitleID = 200000799,
          BPPath = "/Game/UMG/UI_BP/Common/Popup/Theme/Item/Common_Popup_Theme_Explain_Picture02_Item_UIBP.Common_Popup_Theme_Explain_Picture02_Item_UIBP",
          RefreshFun = function(node_root)
            if not node_root then
              return
            end
            local Util = require("client.slua_ui_framework.util")
            Util.SetTexture(node_root.Image_Pic_1, "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Texture/Guide/XSuit_Druid_Image_Guide_01.XSuit_Druid_Image_Guide_01", {sync = false})
            Util.SetTexture(node_root.Image_Pic_2, "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Texture/Guide/XSuit_Druid_Image_Guide_08.XSuit_Druid_Image_Guide_08", {sync = false})
            node_root.Text_Pic_1:SetText(LocUtil.GetLocalizeResStr(200000800))
            node_root.Text_Pic_2:SetText(LocUtil.GetLocalizeResStr(200000801))
            node_root.Text_Desc:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
          end
        },
        [2] = {
          TitleID = 200000799,
          BPPath = "/Game/UMG/UI_BP/Common/Popup/Theme/Item/Common_Popup_Theme_Explain_Picture10_Item_UIBP.Common_Popup_Theme_Explain_Picture10_Item_UIBP",
          RefreshFun = function(node_root)
            if not node_root then
              return
            end
            local Util = require("client.slua_ui_framework.util")
            Util.SetTexture(node_root.Image_01, "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Texture/Guide/XSuit_Druid_Image_Guide_09.XSuit_Druid_Image_Guide_09", {sync = false})
            node_root.CanvasPanel_5:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
            node_root.Text_Pic_1:SetText(LocUtil.LocalizeResFormat(200000802))
          end
        }
      },
      Material = {
        [1] = {
          TitleID = 200000821,
          BPPath = "/Game/UMG/UI_BP/Common/Popup/Theme/Item/Common_Popup_Theme_Explain_Picture02_Item_UIBP.Common_Popup_Theme_Explain_Picture02_Item_UIBP",
          RefreshFun = function(node_root)
            if not node_root then
              return
            end
            local Util = require("client.slua_ui_framework.util")
            Util.SetTexture(node_root.Image_Pic_1, "/Game/UMG/Texture_200/Lobby_NoAtlas/XSuit/XSuit_Upgrade_Image_01.XSuit_Upgrade_Image_01", {sync = false})
            Util.SetTexture(node_root.Image_Pic_2, "/Game/UMG/Texture_200/Lobby_NoAtlas/XSuit/XSuit_Upgrade_Image_02.XSuit_Upgrade_Image_02", {sync = false})
            node_root.Text_Pic_1:SetText(LocUtil.GetLocalizeResStr(200000823))
            node_root.Text_Pic_2:SetText(LocUtil.GetLocalizeResStr(200000824))
            node_root.Text_Desc:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
          end
        }
      }
    }
  }
}
local DEFAULT_POPUP_BP_PATH = "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Popup/XSuit_Popup_WorkShop_Explain_4700_UIBP.XSuit_Popup_WorkShop_Explain_4700_UIBP"

function XSuit_Guide_Config.ShowGuide(source, bShow, reOpen)
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
  local maxPeriod = LogicXSuit.GetMaxPeriod()
  if maxPeriod < 16 then
    return
  end
  if not bShow then
    local data = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eXsuitGuide) or {}
    if data and data.branchGuide and data.branchGuide[source] then
      return
    end
    local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
    local videoCfg = logic_xsuit_activity:GetXSuitVideoCfg()
    if videoCfg and videoCfg.video ~= nil and videoCfg.video ~= "" then
      local videoData = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eGoldenSuitLotteryVideoAutoPlay) or {}
      if not videoData or not videoData.havePlay then
        return
      end
      local uiInstance = UIManager.GetUI(UIManager.UI_Config.video_player_system)
      if uiInstance and uiInstance.bShowing and not reOpen then
        return
      end
    end
  end
  local XSuitWorkshopTabData = LogicXSuit.GetWorkshopTabData()
  local needShowGuide, period = false
  for index, data in pairs(XSuitWorkshopTabData) do
    if data.branchList then
      local activeBranchId = LogicXSuit.GetActiveBranchIdByPeriod(data.period)
      if not activeBranchId then
        period = data.period
        needShowGuide = true
        break
      end
    end
  end
  local periodIndex = maxPeriod or 16
  local guideConfig = {}
  local periodCfg = XSuit_Guide_Config and XSuit_Guide_Config[periodIndex]
  if periodCfg and periodCfg.guideConfig then
    guideConfig = periodCfg.guideConfig
  end
  local baseConfig = UIManager.UI_Config.XSuit_Popup_Reward_Base
  if not baseConfig then
    log_error("XSuit_Guide_Config.ShowGuide XSuit_Popup_Reward_Base config is nil")
    return
  end
  local bpPath = baseConfig.path
  if periodIndex <= 16 then
    bpPath = "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Popup/XSuit_Popup_Theme_Explain_UIBP.XSuit_Popup_Theme_Explain_UIBP"
  end
  bpPath = bpPath or DEFAULT_POPUP_BP_PATH
  local popupConfig = {}
  for k, v in pairs(baseConfig) do
    popupConfig[k] = v
  end
  popupConfig.path = bpPath
  local showExperience
  local activeBranchId = LogicXSuit.GetActiveBranchIdByPeriod(maxPeriod)
  if activeBranchId ~= nil then
    showExperience = false
  end
  UIManager.ShowUI(popupConfig, nil, guideConfig[source], function(closeSeason)
    if closeSeason == "Experience" and needShowGuide and period then
      LogicXSuit.ShowSelectBranchUI(period)
    end
    if not bShow then
      local data = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eXsuitGuide) or {}
      data.branchGuide = data.branchGuide or {}
      data.branchGuide[source] = true
      PlayerPrefsSystem.SaveTableToFile_N(data, PlayerPrefsSystem.ePlayerPrefsType.eXsuitGuide)
    end
  end, showExperience, true, {
    bShowStudyBtn = needShowGuide,
    StudyText = LocUtil.GetLocalizeResStr(8600043),
    ExperienceText = needShowGuide and LocUtil.GetLocalizeResStr(200000734),
    bShowSlideBar = true,
    bShowSliderPoint = periodIndex <= 16,
    SlideBarPath = "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Item/XSuit_Popup_Theme_Explain_Item_UIBP.XSuit_Popup_Theme_Explain_Item_UIBP"
  })
end

function XSuit_Guide_Config.ShowMaterialGuide(source)
  local LogicFitVersionDownload = require("client.slua.logic.download.fit.logic_fitVersion_download")
  if not LogicFitVersionDownload.IsFitLobbyResDownloaded() then
    log(bWriteLog and "XSuit_Guide_Config.ShowMaterialGuide - FitLobbyRes not downloaded")
    return
  end
  local showType = "Material"
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local data = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eXsuitGuide) or {}
  if data and data.branchGuide and data.branchGuide[showType] then
    local _ = source == "XSuit" and XSuit_Guide_Config.ShowGuide("Workshop")
    return
  end
end

return XSuit_Guide_Config
