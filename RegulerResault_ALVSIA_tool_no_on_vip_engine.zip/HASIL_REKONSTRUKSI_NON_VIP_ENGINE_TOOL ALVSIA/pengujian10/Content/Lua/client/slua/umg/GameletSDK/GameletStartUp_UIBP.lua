local GameletOnDemand = require("client.slua.logic.gamelet.GameletOnDemand")
local gamelet_define = require("client.slua.logic.gamelet.gamelet_define")
local Enum_AppReadyState = gamelet_define.Enum_AppReadyState
local GameletStartUp_UIBP = {}
local ENUM_BUTTON_SLOT = {
  Not = 0,
  Downloading = 1,
  Done = 2
}
local PROGRESS_POLL_INTERVAL = 0.5

function GameletStartUp_UIBP:ctor(_, tShowData)
  self._tShowData = tShowData or {}
  self._nProgressTimer = nil
  self._bDownloading = false
end

function GameletStartUp_UIBP:RegistEvents()
  GameletStartUp_UIBP.__super.RegistEvents(self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Download, self.OnDownloadButtonClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Enter, self.OnEnterButtonClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.close, self.OnCloseButtonClick, self)
end

function GameletStartUp_UIBP:OnPostInitialize()
  GameletStartUp_UIBP.__super.OnPostInitialize(self)
  local bEmbedded = self._tShowData and self._tShowData.bEmbedded or false
  local bIsGameletApp = self._tShowData and self._tShowData.bIsGameletApp or false
  local bIsGameletActivity = self._tShowData and self._tShowData.bIsGameletActivity or false
  self:SetWidgetVisible(self.UIRoot.close, not bEmbedded, true)
  self:SetWidgetVisible(self.UIRoot.Image_BG, bIsGameletApp or bIsGameletActivity, false)
  if bIsGameletApp or bIsGameletActivity then
    self:_SetStartUpImage()
  end
  self.UIRoot.TextBlock_111:SetText(LocUtil.GetLocalizeResStr(7420))
  self.UIRoot.TextBlock_2:SetText(LocUtil.GetLocalizeResStr(4995))
  self:SetWidgetVisible(self.UIRoot.Image_xiaobao, true, false)
  self:RefreshButtonShow()
end

function GameletStartUp_UIBP:OnClose()
  self:_StopProgressPolling()
  if self.UIRoot and self.UIRoot.Image_BG then
    self.UIRoot.Image_BG:SetBrushFromTexture(nil, false)
  end
  GameletStartUp_UIBP.__super.OnClose(self)
end

function GameletStartUp_UIBP:OnDownloadButtonClick()
  self:PlayAudio(sound_config.click)
  if self._bDownloading then
    log(bWriteLog and "GameletStartUp_UIBP:OnDownloadButtonClick. already downloading, ignore")
    return
  end
  self:_StartDownload()
end

function GameletStartUp_UIBP:OnEnterButtonClick()
  self:PlayAudio(sound_config.click)
  if self._tShowData.bFromActivityCenter then
    local parentUI = self:GetParentUI()
    if parentUI and parentUI.ShowCurActUI then
      parentUI:ShowCurActUI("GameletContainer_UIBP", self._tShowData.actData, self._tShowData.isNotice, self._tShowData.originParams, true)
      return
    end
    self:CloseSelf()
    return
  end
  local fOkCallback = self._tShowData.fOkCallback
  if fOkCallback then
    fOkCallback()
  end
  self:CloseSelf()
end

function GameletStartUp_UIBP:OnCloseButtonClick()
  self:PlayAudio(sound_config.click)
  self:CloseSelf()
end

function GameletStartUp_UIBP:_StartDownload()
  local sAppId = self:_GetAppId()
  if sAppId == "" then
    log_error("GameletStartUp_UIBP:_StartDownload. appId is empty")
    return
  end
  self._bDownloading = true
  GameletOnDemand:MarkDownloadBegin(sAppId)
  local tProgress = GameletOnDemand:GetDownloadProgress(sAppId)
  self:_ShowDownloading(tProgress and tProgress.percent or 0)
  self:_StartProgressPolling()
  GameletOnDemand:EnsureReady(sAppId, function()
    if not slua.isValid(self.UIRoot) then
      return
    end
    self:_OnDownloadFinished()
  end, function(errCode, resName)
    if not slua.isValid(self.UIRoot) then
      return
    end
    printf("GameletStartUp_UIBP:_StartDownload. failed appId:%s errCode:%s resName:%s", tostring(sAppId), tostring(errCode), tostring(resName))
    self:_OnDownloadFailed()
  end)
end

function GameletStartUp_UIBP:_OnDownloadFinished()
  log(bWriteLog and "GameletStartUp_UIBP:_OnDownloadFinished")
  self._bDownloading = false
  self:_StopProgressPolling()
  self:_ShowEnterButton()
end

function GameletStartUp_UIBP:_OnDownloadFailed()
  self._bDownloading = false
  self:_StopProgressPolling()
  self:_ShowDownloadButton()
end

function GameletStartUp_UIBP:_StartProgressPolling()
  self:_StopProgressPolling()
  self._nProgressTimer = self:AddTimerLoop(PROGRESS_POLL_INTERVAL, function()
    self:_PollProgress()
  end, 0, PROGRESS_POLL_INTERVAL)
end

function GameletStartUp_UIBP:_StopProgressPolling()
  if self._nProgressTimer then
    self:RemoveTimer(self._nProgressTimer)
    self._nProgressTimer = nil
  end
end

function GameletStartUp_UIBP:_PollProgress()
  if not slua.isValid(self.UIRoot) then
    self:_StopProgressPolling()
    return
  end
  local tProgress = GameletOnDemand:GetDownloadProgress(self:_GetAppId())
  if tProgress and tProgress.state == Enum_AppReadyState.Ready then
    self:_OnDownloadFinished()
    return
  end
  self:_ShowDownloading(tProgress and tProgress.percent or 0)
end

function GameletStartUp_UIBP:_GetAppId()
  local tShowData = self._tShowData or {}
  local appId = tShowData.appId
  appId = tostring(appId or "")
  return appId
end

function GameletStartUp_UIBP:_SetStartUpImage()
  local Image_BG = self.UIRoot and self.UIRoot.Image_BG
  if not Image_BG then
    log_error("GameletStartUp_UIBP:_SetStartUpImage. Image_BG is nil")
    return
  end
  local sAppId = self:_GetAppId()
  local bIsGameletActivity = self._tShowData and self._tShowData.bIsGameletActivity or false
  local sUrl
  if bIsGameletActivity then
    local LogicGameletRedPoint = require("client.slua.logic.gamelet.LogicGameletRedPoint")
    local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
    local nActId = LogicGameletRedPoint:GetActIdByAppId(sAppId)
    local tActData = nActId and ActivityNewSystem.GetActivityByID(nActId)
    sUrl = tActData and tActData.ImgUrl or nil
    printf("GameletStartUp_UIBP:_SetStartUpImage. activity appId:%s actId:%s", tostring(sAppId), tostring(nActId))
  else
    local tStartUpImage = gamelet_define.GameletAppStartUpImage
    sUrl = sAppId ~= "" and tStartUpImage and tStartUpImage[sAppId] or nil
  end
  if not sUrl or sUrl == "" then
    printf("GameletStartUp_UIBP:_SetStartUpImage. no image config, appId:%s isActivity:%s", tostring(sAppId), tostring(bIsGameletActivity))
    return
  end
  local util = require("client.slua_ui_framework.util")
  sUrl = util.GetUrlByLanguage(sUrl)
  printf("GameletStartUp_UIBP:_SetStartUpImage. appId:%s url:%s", sAppId, sUrl)
  Image_BG:SetColorAndOpacity(FLinearColor(1, 1, 1, 1))
  self:SetTexture(Image_BG, sUrl, {bMatchSize = true, enableCDNCompress = true})
end

function GameletStartUp_UIBP:RefreshButtonShow()
  local sAppId = self:_GetAppId()
  if sAppId == "" then
    log_error("GameletStartUp_UIBP:RefreshButtonShow. appId is empty, show enter button")
    self:_ShowEnterButton()
    return
  end
  self:_ShowDownloadButton()
  GameletOnDemand:IsAppReady(sAppId, function(bReady, tItem)
    if not slua.isValid(self.UIRoot) then
      return
    end
    local nState = tItem and tItem.state
    printf("GameletStartUp_UIBP:RefreshButtonShow. appId:%s ready:%s state:%s", tostring(sAppId), tostring(bReady), tostring(nState))
    if bReady then
      self:_ShowEnterButton()
    elseif nState == Enum_AppReadyState.Downloading then
      self:_StartDownload()
    end
  end)
end

function GameletStartUp_UIBP:_ShowDownloadButton()
  self.UIRoot.WidgetSwitcher_1:SetActiveWidgetIndex(ENUM_BUTTON_SLOT.Not)
end

function GameletStartUp_UIBP:_ShowDownloading(nPercent)
  nPercent = nPercent or 0
  local node_root = self.UIRoot
  node_root.WidgetSwitcher_1:SetActiveWidgetIndex(ENUM_BUTTON_SLOT.Downloading)
  node_root.ProgressBar_0:SetPercent(nPercent)
  node_root.TextBlock_137:SetText(string.format("%d%%", math.floor(nPercent * 100)))
end

function GameletStartUp_UIBP:_ShowEnterButton()
  self.UIRoot.WidgetSwitcher_1:SetActiveWidgetIndex(ENUM_BUTTON_SLOT.Done)
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CGameletStartUp_UIBP = class(ui_base, nil, GameletStartUp_UIBP)
return CGameletStartUp_UIBP
