local TPlanX_Task_QuestSystem_UIBP = {}

function TPlanX_Task_QuestSystem_UIBP:ctor(_, jumpInfo, task_type, task_id)
  local logic_tplanpve_task_marco = require("GameLua.Mod.Lobby.Split.TPlanPVE.logic.Task.logic_tplanpve_task_marco")
  self.jumpInfo = jumpInfo
  self.task_type = task_type or logic_tplanpve_task_marco.TaskType.Season
  self.task_id = task_id or 0
  local tlog_report_utils = require("client.slua.config.tlog.tlog_report_utils")
  tlog_report_utils.ReportTLogEvent(TLogEventDefine.TPlanLobbyTaskEnterClick, self.task_id, jumpInfo and jumpInfo.from)
  self.select_index_table = {
    [logic_tplanpve_task_marco.TaskType.Season] = {0, 0},
    [logic_tplanpve_task_marco.TaskType.Action] = 0
  }
  self.task_data = nil
  self.expend_index = nil
end

function TPlanX_Task_QuestSystem_UIBP:OnInitialize()
  self.LoopScrollBox_Reward = self:InitScrollBox(self.UIRoot.LoopScrollBox_Reward)
  self.LoopScrollBox_SubTask = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_SubTask, "GameLua.Mod.TPlanX.EvoBase.Client.UI.Task.Item.TPlanX_Task_QuestSystem_Item01_UIBP")
  self.LoopScrollBox_ActionTask = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_ActionTask, "GameLua.Mod.TPlanX.EvoBase.Client.UI.Task.Item.TPlanX_Task_QuestSystem01_Item_UIBP")
  local luaItem = "GameLua.Mod.TPlanX.EvoBase.Client.UI.Task.Item.TPlanX_Task_QuestSystem_Item_UIBP"
  local luaSubItem = "GameLua.Mod.TPlanX.EvoBase.Client.UI.Task.Item.TPlanX_Task_QuestSystem01_Item_UIBP"
  self.ExtendedLoopScrollBox_SeasonTask = self:InitExtendedScrollBox(self.UIRoot.ExtendedLoopScrollBox_SeasonTask, {luaItem, luaSubItem})
end

function TPlanX_Task_QuestSystem_UIBP:RegistEvents()
  self.LoopScrollBox_Reward:SetRefreshItemCallback(self.OnRefreshPropItem, self)
  self:AddOnClickedEventByControl(self.UIRoot.Btn_Accept, self.OnClickBtn_Accept, self)
  self:AddOnClickedEventByControl(self.UIRoot.Btn_Go, self.OnClickBtn_Go, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Switch, self.OnClickButton_Switch, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Close, self.OnClickButton_Close, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_More, self.OnClickButton_More, self)
  self:AddCommonEvent(EVENTTYPE_TPLANPVE_NORMAL, EVENTID_TPLANPVE_TASK_ALL_UPDATE, self.InitTaskSelect, self)
  self:AddCommonEvent(EVENTTYPE_TPLANPVE_NORMAL, EVENTID_TPLANPVE_TASK_ONE_UPDATE, self.UpdateOneTask, self)
end

function TPlanX_Task_QuestSystem_UIBP:OnPostInitialize()
  self.UIRoot.SwitchLeftTitle1:SetText(LocUtil.GetLocalizeResStr(8600087))
  self.UIRoot.SwitchRightTitle1:SetText(LocUtil.GetLocalizeResStr(28150909))
  self.UIRoot.UTRichTextBlock_Content:SetText("")
  self.UIRoot.SwitchLeftTitle0:SetText(LocUtil.GetLocalizeResStr(28150908))
  local logic_tplanpve_task = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_tplanpve_task)
  logic_tplanpve_task:send_tplanx_task_sync_all_req()
end

function TPlanX_Task_QuestSystem_UIBP:OnClose()
end

function TPlanX_Task_QuestSystem_UIBP:OnClickButton_More()
  self:PlayAudio(sound_config.click_v1)
  UIManager.ShowUI(UIManager.UI_Config.HelpTip, 0, LocUtil.GetLocalizeResStr(35130), LocUtil.GetLocalizeResStr(47088235))
end

function TPlanX_Task_QuestSystem_UIBP:OnClickButton_Close()
  self:PlayAudio(sound_config.click_v1)
  self:CloseSelf()
end

function TPlanX_Task_QuestSystem_UIBP:OnClickButton_Switch()
  self:PlayAudio(sound_config.click_v1)
  local logic_tplanpve_task_marco = require("GameLua.Mod.Lobby.Split.TPlanPVE.logic.Task.logic_tplanpve_task_marco")
  local switch = self.task_type
  if switch == logic_tplanpve_task_marco.TaskType.Season then
    switch = logic_tplanpve_task_marco.TaskType.Action
  else
    switch = logic_tplanpve_task_marco.TaskType.Season
  end
  if switch == logic_tplanpve_task_marco.TaskType.Season then
    local logic_tplanpve_task = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_tplanpve_task)
    if not logic_tplanpve_task:IsOpenSeasonTask() then
      local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
      local extraData = {
        showUIKey = "xmission_com_msg_box_2"
      }
      
      local function okCallback()
        GlobalData.JumpUrl("game://?module=1009915")
      end
      
      CommonMsgBoxMgr.ShowTPlan(3, LocUtil.GetLocalizeResStr(28150966), LocUtil.GetLocalizeResStr(28150967), okCallback, nil, LocUtil.GetLocalizeResStr(28150969), nil, extraData)
      return
    end
  end
  self:SelectTaskType(switch)
  if switch == logic_tplanpve_task_marco.TaskType.Season then
    self:SelectSeasonIndex(self:GetDefaultSeasonIndex(), nil, true)
  else
    self:SelectActionIndex(1, true)
  end
end

function TPlanX_Task_QuestSystem_UIBP:OnClickBtn_Go()
  self:PlayAudio(sound_config.TPlan_Task_GiveUp)
  if not self.task_data or not self.task_data.task_id then
    return
  end
  local task_id = self.task_data.task_id
  local logic_tplanpve_task = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_tplanpve_task)
  logic_tplanpve_task:GiveUpTask(task_id)
end

function TPlanX_Task_QuestSystem_UIBP:OnClickBtn_Accept()
  if not self.task_data or not self.task_data.task_id then
    return
  end
  local logic_tplanpve_task = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_tplanpve_task)
  local status = self.task_data.status
  local logic_tplanpve_task_marco = require("GameLua.Mod.Lobby.Split.TPlanPVE.logic.Task.logic_tplanpve_task_marco")
  if status == logic_tplanpve_task_marco.TaskStatus.NotUnlocked then
    self:PlayAudio(sound_config.TPlan_Task_Accept)
    logic_tplanpve_task:send_tplanx_task_accept_req(self.task_data.task_id)
  elseif status == logic_tplanpve_task_marco.TaskStatus.Available then
    self:PlayAudio(sound_config.click_v1)
    logic_tplanpve_task:send_tplanx_task_take_award_req(self.task_data.task_id)
  end
end

function TPlanX_Task_QuestSystem_UIBP:OnRefreshPropItem(widget, index)
  local data = self.LoopScrollBox_Reward:GetItemData(index)
  local CommonItem_Const = require("client.slua.component.item.ItemUtils.CommonItem_Const")
  local logic_tplanpve_task_marco = require("GameLua.Mod.Lobby.Split.TPlanPVE.logic.Task.logic_tplanpve_task_marco")
  local status = CommonItem_Const.Enum_ItemStatus.Not
  local task_status = self.task_data.status
  if task_status == logic_tplanpve_task_marco.TaskStatus.Available then
    status = CommonItem_Const.Enum_ItemStatus.Done
  elseif task_status == logic_tplanpve_task_marco.TaskStatus.Received then
    status = CommonItem_Const.Enum_ItemStatus.Got
  end
  if not data.award_score then
    widget:InitView(data.awardId, data.awardNum, data.awardHours, {bIsShowTip = true})
    widget:SetAwardState(status)
  else
    widget:InitView(0, data.award_score, 0)
    widget:SetIconFromPath("/Game/Arts/UI/TableIcons/ItemIcon/Item/Icon_PVE_SeasonPoints_128.Icon_PVE_SeasonPoints_128")
    local UIUtil = require("client.common.ui_util")
    local QualityPath = UIUtil.GetBgQualityPath(7)
    widget:SetQualityBg(QualityPath)
    widget:SetAwardState(status)
  end
  if task_status == logic_tplanpve_task_marco.TaskStatus.Processing then
    widget:SetIsLock(false)
  end
end

function TPlanX_Task_QuestSystem_UIBP:UpdateOneTask(_, __, task_id)
  local logic_tplanpve_task_marco = require("GameLua.Mod.Lobby.Split.TPlanPVE.logic.Task.logic_tplanpve_task_marco")
  if self.task_type == logic_tplanpve_task_marco.TaskType.Season then
    self:RefreshSeasonTasks(task_id)
  else
    self:RefreshActionTasks(task_id)
  end
end

function TPlanX_Task_QuestSystem_UIBP:InitTaskSelect()
  local logic_tplanpve_task_marco = require("GameLua.Mod.Lobby.Split.TPlanPVE.logic.Task.logic_tplanpve_task_marco")
  self:UpdateLockSeasonTask()
  if not self.bSeasonOpen and self.task_type == logic_tplanpve_task_marco.TaskType.Season then
    self.task_type = logic_tplanpve_task_marco.TaskType.Action
  end
  self:SelectTaskType(self.task_type)
  if self.task_id and self.task_id ~= 0 then
    if self.task_type == logic_tplanpve_task_marco.TaskType.Season then
      self:RefreshSeasonTasks(self.task_id)
    else
      self:RefreshActionTasks(self.task_id)
    end
    return
  end
  if self.task_type == logic_tplanpve_task_marco.TaskType.Season then
    self:SelectSeasonIndex(self:GetDefaultSeasonIndex(), nil, true)
  elseif self.task_type == logic_tplanpve_task_marco.TaskType.Action then
    self:SelectActionIndex(1, true)
  end
end

function TPlanX_Task_QuestSystem_UIBP:SelectTaskType(task_type)
  local logic_tplanpve_task_marco = require("GameLua.Mod.Lobby.Split.TPlanPVE.logic.Task.logic_tplanpve_task_marco")
  self.task_type = task_type
  self.UIRoot.WidgetSwitcher_Switch:SetActiveWidgetIndex(task_type == logic_tplanpve_task_marco.TaskType.Season and 0 or 1)
  self.UIRoot.WidgetSwitcher_Task:SetActiveWidgetIndex(task_type == logic_tplanpve_task_marco.TaskType.Season and 0 or 1)
  if task_type == logic_tplanpve_task_marco.TaskType.Season then
    self:RefreshSeasonTasks()
  else
    self:RefreshActionTasks()
  end
end

function TPlanX_Task_QuestSystem_UIBP:RefreshActionTasks(task_id)
  local logic_tplanpve_task = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_tplanpve_task)
  local logic_tplanpve_task_marco = require("GameLua.Mod.Lobby.Split.TPlanPVE.logic.Task.logic_tplanpve_task_marco")
  local task_list = logic_tplanpve_task:GetTaskData(logic_tplanpve_task_marco.TaskType.Action)
  log_tree("TPlanX_Task_QuestSystem_UIBP:RefreshActionTasks task_list", task_list)
  local list = {}
  for index, value in ipairs(task_list or {}) do
    if value.status ~= logic_tplanpve_task_marco.TaskStatus.Locked then
      table.insert(list, value)
    end
  end
  self.LoopScrollBox_ActionTask:SetData(list)
  if task_id then
    local index
    for i, value in ipairs(list) do
      if value.task_id == task_id then
        index = i
        break
      end
    end
    if index == nil then
      return
    end
    self:SelectActionIndex(index, true)
  end
end

function TPlanX_Task_QuestSystem_UIBP:RefreshSeasonTasks(task_id)
  local logic_tplanpve_task = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_tplanpve_task)
  local logic_tplanpve_task_marco = require("GameLua.Mod.Lobby.Split.TPlanPVE.logic.Task.logic_tplanpve_task_marco")
  local task_list = logic_tplanpve_task:GetTaskData(logic_tplanpve_task_marco.TaskType.Season)
  log_tree("TPlanX_Task_QuestSystem_UIBP:RefreshSeasonTasks task_list", task_list)
  if not task_list or #task_list == 0 then
    self:SelectTaskType(logic_tplanpve_task_marco.TaskType.Action)
    self:SelectActionIndex(1, true)
    return
  end
  for index, value in ipairs(task_list) do
    if value.phase_index and value.phase_index ~= 0 then
      self.seasonIndex = index
      break
    end
  end
  self.ExtendedLoopScrollBox_SeasonTask:SetData(task_list)
  self.defaultSeasonIndex = nil
  for index, value in ipairs(task_list) do
    if self.defaultSeasonIndex then
      break
    end
    if index ~= 1 and value.phasse_task_list then
      for i, task in ipairs(value.phasse_task_list) do
        if task.status ~= logic_tplanpve_task_marco.TaskStatus.Received then
          self.defaultSeasonIndex = index
          break
        end
      end
    end
  end
  self.defaultSeasonIndex = self.defaultSeasonIndex or 1
  if task_id then
    local index, subIndex
    for i, value in ipairs(task_list) do
      if value.task_id == task_id then
        index = i
        break
      end
      if value.phasse_task_list then
        for j, task in ipairs(value.phasse_task_list) do
          if task.task_id == task_id then
            index = i
            subIndex = j
            break
          end
        end
      end
    end
    if index == nil then
      return
    end
    self:SelectSeasonIndex(index, subIndex, true)
  end
end

function TPlanX_Task_QuestSystem_UIBP:UpdateTaskUI(task_data)
  log_tree("TPlanX_Task_QuestSystem_UIBP:UpdateTaskUI task_data", task_data)
  if not task_data then
    task_data = self.task_data
    if not task_data then
      return
    end
  end
  self.task_data = task_data
  local logic_tplanpve_task_marco = require("GameLua.Mod.Lobby.Split.TPlanPVE.logic.Task.logic_tplanpve_task_marco")
  self.UIRoot.WidgetSwitcher_TaskTag:SetActiveWidgetIndex(task_data.task_nature - 1)
  self.UIRoot.Text_TaskTitle:SetText(task_data.task_name)
  local isDamage = task_data.taskDescription and task_data.taskDescription ~= ""
  self.UIRoot.UTRichTextBlock_Content:SetText(task_data.taskDescription)
  self:SetWidgetVisible(self.UIRoot.UTRichTextBlock_Content, isDamage)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Warning, task_data.round_policy ~= 1)
  if task_data.round_policy == 2 then
    self.UIRoot.Text_Injunction:SetText(LocUtil.GetLocalizeResStr(28150912))
  elseif task_data.round_policy == 3 then
    self.UIRoot.Text_Injunction:SetText(LocUtil.GetLocalizeResStr(28150968))
  end
  self:SetWidgetVisible(self.UIRoot.Btn_Go, task_data.status == logic_tplanpve_task_marco.TaskStatus.Processing and task_data.auto_accept ~= 1, true)
  self.LoopScrollBox_SubTask:SetData(task_data.sub_task_list)
  self.LoopScrollBox_Reward:SetData(task_data.awardData)
  self.UIRoot.WidgetSwitcherExt_Status:SetActiveWidgetIndex(task_data.status)
  local statusKeys = {
    [logic_tplanpve_task_marco.TaskStatus.Locked] = 90089,
    [logic_tplanpve_task_marco.TaskStatus.NotUnlocked] = 28150963,
    [logic_tplanpve_task_marco.TaskStatus.Processing] = 8880380,
    [logic_tplanpve_task_marco.TaskStatus.Available] = 6174,
    [logic_tplanpve_task_marco.TaskStatus.Received] = 87091
  }
  if statusKeys[task_data.status] then
    self.UIRoot.TextBlock_TaskButton:SetText(LocUtil.GetLocalizeResStr(statusKeys[task_data.status]))
  end
end

function TPlanX_Task_QuestSystem_UIBP:SelectSeasonIndex(index, subIndex, switch)
  local logic_tplanpve_task_marco = require("GameLua.Mod.Lobby.Split.TPlanPVE.logic.Task.logic_tplanpve_task_marco")
  local oldIndex = self.select_index_table[logic_tplanpve_task_marco.TaskType.Season][1]
  index = index or oldIndex
  local oldSubIndex = self.select_index_table[logic_tplanpve_task_marco.TaskType.Season][2]
  local task_ex_data = self.ExtendedLoopScrollBox_SeasonTask:GetItemData(index)
  if not task_ex_data then
    return
  end
  self.ExtendedLoopScrollBox_SeasonTask:Select(index)
  if not switch and index == oldIndex then
    if task_ex_data.phase_index then
      if not subIndex then
        self:ExpendIndex(index)
      elseif subIndex ~= oldSubIndex then
        self.select_index_table[logic_tplanpve_task_marco.TaskType.Season][2] = subIndex
        self.ExtendedLoopScrollBox_SeasonTask:SelectSub(subIndex)
        local task_info = task_ex_data.phasse_task_list[subIndex]
        self:UpdateTaskUI(task_info)
      end
    end
    return
  end
  local selectSubIndex = subIndex or 1
  self.select_index_table[logic_tplanpve_task_marco.TaskType.Season][1] = index
  self.select_index_table[logic_tplanpve_task_marco.TaskType.Season][2] = selectSubIndex
  self:ExpendIndex(index, true)
  self.ExtendedLoopScrollBox_SeasonTask:RefreshItem(oldIndex)
  local task_info = task_ex_data.phasse_task_list and task_ex_data.phasse_task_list[selectSubIndex] or task_ex_data
  self:UpdateTaskUI(task_info)
end

function TPlanX_Task_QuestSystem_UIBP:SelectActionIndex(index, switch)
  local logic_tplanpve_task_marco = require("GameLua.Mod.Lobby.Split.TPlanPVE.logic.Task.logic_tplanpve_task_marco")
  if not switch and self.select_index_table[logic_tplanpve_task_marco.TaskType.Action] == index then
    return
  end
  self.select_index_table[logic_tplanpve_task_marco.TaskType.Action] = index
  self.LoopScrollBox_ActionTask:Select(index)
  local task_data = self.LoopScrollBox_ActionTask:GetItemData(index)
  self:UpdateTaskUI(task_data)
end

function TPlanX_Task_QuestSystem_UIBP:ExpendIndex(index, expend)
  if not index then
    return
  end
  local task_ex_data = self.ExtendedLoopScrollBox_SeasonTask:GetItemData(index)
  if not task_ex_data then
    return
  end
  local isExpend = expend or self.expend_index ~= index
  self.expend_index = isExpend and index or nil
  if isExpend and task_ex_data.phase_index then
    local logic_tplanpve_task_marco = require("GameLua.Mod.Lobby.Split.TPlanPVE.logic.Task.logic_tplanpve_task_marco")
    self.ExtendedLoopScrollBox_SeasonTask:SetSubData(index, task_ex_data.phasse_task_list)
    self.ExtendedLoopScrollBox_SeasonTask:SelectSub(self.select_index_table[logic_tplanpve_task_marco.TaskType.Season][2])
  else
    self.ExtendedLoopScrollBox_SeasonTask:SetSubData(index)
  end
  self.ExtendedLoopScrollBox_SeasonTask:RefreshItem(index)
end

function TPlanX_Task_QuestSystem_UIBP:GetSeasonIsExpend(index)
  return self.expend_index == index
end

function TPlanX_Task_QuestSystem_UIBP:GetDefaultSeasonIndex()
  return self.defaultSeasonIndex or 1
end

function TPlanX_Task_QuestSystem_UIBP:UpdateLockSeasonTask()
  local logic_tplanpve_task = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_tplanpve_task)
  self.bSeasonOpen = logic_tplanpve_task:IsOpenSeasonTask()
  self:SetWidgetVisible(self.UIRoot.SizeBox_9, not self.bSeasonOpen)
end

function TPlanX_Task_QuestSystem_UIBP:GetSelectIndex(taskType)
  local data = self.select_index_table[taskType]
  if type(data) == "number" then
    return data
  end
  return data[2]
end

function TPlanX_Task_QuestSystem_UIBP:GetSeasonIndex()
  return self.seasonIndex
end

function TPlanX_Task_QuestSystem_UIBP:GetTaskData()
  return self.task_data
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
return class(ui_base, nil, TPlanX_Task_QuestSystem_UIBP)
