local NewCameraConfig = require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieConfig")
local NewCameraTLogReport = require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfie_TLog_Report")
local NewCamera_Photo_Bottom_Suit_UIBP = {}

function NewCamera_Photo_Bottom_Suit_UIBP:OnInitialize()
end

function NewCamera_Photo_Bottom_Suit_UIBP:RegistEvents()
  self.LoopScrollBox_Suit = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_Suit, "GameLua.Mod.Library.Client.Photo.Items.NewCamera_Photo_Suit_Item_UIBP")
end

function NewCamera_Photo_Bottom_Suit_UIBP:OnPostInitialize()
  self:_SaveOriginIndex()
  self:_BuildSuitList()
end

function NewCamera_Photo_Bottom_Suit_UIBP:OnShow()
end

function NewCamera_Photo_Bottom_Suit_UIBP:OnHide()
end

function NewCamera_Photo_Bottom_Suit_UIBP:OnClose()
end

function NewCamera_Photo_Bottom_Suit_UIBP:_OnClickSuitListItem(index)
  local itemData = self.LoopScrollBox_Suit:GetItemData(index)
  if not itemData then
    return
  end
  local isTheSame = self._currentSuitIndex == index
  if isTheSame then
    itemData = nil
    self._currentSuitIndex = self._saveOriginIndex
    self.LoopScrollBox_Suit:Deselect()
  else
    self._currentSuitIndex = index
    self.LoopScrollBox_Suit:Select(index)
  end
  local PhotoGrapherSubSystem = SubsystemMgr:Get("PhotoGrapherSubSystem")
  if not PhotoGrapherSubSystem then
    log(bWriteLog and "NewCamera_Photo_Bottom_Suit_UIBP:_OnClickSuitListItem cannot get PhotoGrapherSubSystem")
    return
  end
  local suitStates = PhotoGrapherSubSystem:GetAllWearState()
  local rawIndex = index - 1
  printf("NewCamera_Photo_Bottom_Suit_UIBP:_OnClickSuitListItem uiIndex:%s rawIndex:%s hasUnLock:%s", index, rawIndex, tostring(suitStates[rawIndex]))
  if not suitStates[rawIndex] then
    ShowNotice(48384)
    return
  end
  self:UpdateSuitName(self._currentSuitIndex, itemData)
  local bSuccess = PhotoGrapherSubSystem:RequestChangeWearInPhoto(rawIndex)
  if bSuccess then
    NewCameraTLogReport.ReportFeature(NewCameraTLogReport.EFeatureIDs.SuitChange, self._currentSuitIndex)
  end
end

function NewCamera_Photo_Bottom_Suit_UIBP:_SaveOriginIndex()
  local PhotoGrapherSubSystem = SubsystemMgr:Get("PhotoGrapherSubSystem")
  if not PhotoGrapherSubSystem then
    return
  end
  local curSuitIndex = PhotoGrapherSubSystem:GetCurWearIndex()
  if curSuitIndex then
    self._saveOriginIndex = curSuitIndex
  end
end

function NewCamera_Photo_Bottom_Suit_UIBP:_BuildSuitList()
  local PhotoGrapherSubSystem = SubsystemMgr:Get("PhotoGrapherSubSystem")
  if not PhotoGrapherSubSystem then
    return
  end
  local suitStates = PhotoGrapherSubSystem:GetAllWearState()
  local curSuitIndex = self._saveOriginIndex
  local targetIndex
  self.listData = {}
  for i = 1, NewCameraConfig.CMaxSuitCount do
    local rawIndex = i - 1
    local item = {
      hasUnLock = suitStates[rawIndex],
      isRP = i == NewCameraConfig.CRPSuitIndex,
      onClickCallback = function(index)
        self:_OnClickSuitListItem(index)
      end
    }
    table.insert(self.listData, item)
    printf("NewCamera_Photo_Bottom_Suit_UIBP:_BuildSuitList uiIndex:%s rawIndex:%s hasUnLock:%s isRP:%s", i, rawIndex, tostring(item.hasUnLock), tostring(item.isRP))
    if rawIndex == curSuitIndex then
      targetIndex = i
    end
  end
  self.LoopScrollBox_Suit:SetData(self.listData)
  if targetIndex then
    self._currentSuitIndex = targetIndex
    self.LoopScrollBox_Suit:Select(targetIndex)
  end
  self:UpdateSuitName(targetIndex, self.listData[targetIndex])
end

function NewCamera_Photo_Bottom_Suit_UIBP:UpdateSuitName(index, data)
  local showStr
  if data then
    local str = LocUtil.GetLocalizeResStr(4481)
    local postfix = data.isRP and LocUtil.GetLocalizeResStr(29902) or tostring(index)
    showStr = str .. postfix
  end
  local hasSelectedIndex = data ~= nil
  if hasSelectedIndex then
    self.UIRoot.TextBlock_Suit:SetText(showStr)
  end
  self:SetWidgetVisible(self.UIRoot.TextBlock_Suit, hasSelectedIndex)
  self:SetWidgetVisible(self.UIRoot.TextBlock_SuitDefault, not hasSelectedIndex)
end

function NewCamera_Photo_Bottom_Suit_UIBP:Reset()
  if not self:_GetResetOriginIndex() then
    return
  end
  self:ResetToDefaultSelect()
  self:ResetRoleSuit()
end

function NewCamera_Photo_Bottom_Suit_UIBP:_GetResetOriginIndex()
  local PhotoGrapherSubSystem = SubsystemMgr:Get("PhotoGrapherSubSystem")
  if PhotoGrapherSubSystem and PhotoGrapherSubSystem.GetPhotoWearOriginIndex then
    local originIndex = PhotoGrapherSubSystem:GetPhotoWearOriginIndex()
    if originIndex ~= nil and 0 <= originIndex then
      return originIndex
    end
  end
  return self._saveOriginIndex
end

function NewCamera_Photo_Bottom_Suit_UIBP:ResetToDefaultSelect()
  local curSuitIndex = self:_GetResetOriginIndex()
  if not curSuitIndex then
    return
  end
  local targetIndex
  for k, v in pairs(self.listData) do
    if k - 1 == curSuitIndex then
      targetIndex = k
    end
  end
  if targetIndex then
    self._currentSuitIndex = targetIndex
    self.LoopScrollBox_Suit:Select(targetIndex)
  else
    self._currentSuitIndex = nil
    self.LoopScrollBox_Suit:Deselect()
  end
end

function NewCamera_Photo_Bottom_Suit_UIBP:ResetRoleSuit()
  local originIndex = self:_GetResetOriginIndex()
  if not originIndex then
    return
  end
  local PhotoGrapherSubSystem = SubsystemMgr:Get("PhotoGrapherSubSystem")
  if not PhotoGrapherSubSystem then
    log(bWriteLog and "NewCamera_Photo_Bottom_Suit_UIBP:_OnClickSuitListItem cannot get PhotoGrapherSubSystem")
    return
  end
  local itemData
  if self._currentSuitIndex then
    itemData = self.listData[self._currentSuitIndex]
  end
  self:UpdateSuitName(self._currentSuitIndex, itemData)
  PhotoGrapherSubSystem:RequestChangeWearInPhoto(originIndex)
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CNewCamera_Photo_Bottom_Suit_UIBP = class(ui_base, nil, NewCamera_Photo_Bottom_Suit_UIBP)
return CNewCamera_Photo_Bottom_Suit_UIBP
