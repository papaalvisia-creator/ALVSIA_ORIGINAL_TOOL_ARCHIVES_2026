local ERenderStyle = import("ERenderStyle")
local EPawnState = import("EPawnState")
local NewCamera_IngameSelfieConfig = {}
NewCamera_IngameSelfieConfig.CameraMode = {Fixed = 1, Move = 2}
local CameraMode = NewCamera_IngameSelfieConfig.CameraMode
NewCamera_IngameSelfieConfig.EWeatherType = {
  Sunny = 1,
  Sunset = 2,
  Night = 3
}
local EWeatherType = NewCamera_IngameSelfieConfig.EWeatherType
NewCamera_IngameSelfieConfig.EEmotionPlayState = {
  NotPlay = 0,
  Pause = 1,
  Playing = 2
}
NewCamera_IngameSelfieConfig.EFocusAlgorithm = {
  Linear = 1,
  Physics = 2,
  Hybrid = 3
}
NewCamera_IngameSelfieConfig.EFillLightDir = {
  None = 0,
  Up = 1,
  Down = 2,
  Left = 3,
  Right = 4
}
local EFillLightDir = NewCamera_IngameSelfieConfig.EFillLightDir
NewCamera_IngameSelfieConfig.EPostProcessSettingMode = {Camera = 1, Volume = 2}
NewCamera_IngameSelfieConfig.EParamConfigKey = {
  CameraMoveSpeed = "CameraMoveSpeed",
  RoleRotationSpeed = "RoleRotationSpeed",
  FreeViewRotateSpeed = "FreeViewRotateSpeed",
  FocusAutoTickRate = "FocusAutoTickRate",
  ZoomChangePinchRate = "ZoomChangePinchRate",
  ZoomChangePinchThreshold = "ZoomChangePinchThreshold",
  SceneEffectCD = "SceneEffectCD",
  HeadAimYaw = "HeadAimYaw",
  HeadAimPitch = "HeadAimPitch",
  FilterTemplateNum = "FilterTemplateNum",
  SequenceTemplateNum = "SequenceTemplateNum",
  SuitChangeCD = "SuitChangeCD"
}
NewCamera_IngameSelfieConfig.ESliderConfigKey = {
  UITransparent = "UITransparent",
  FocalLength = "FocalLength",
  Aperture = "Aperture",
  CameraTilt = "CameraTilt",
  FilterIntensity = "FilterIntensity",
  Brightness = "Brightness",
  Contrast = "Contrast",
  Saturation = "Saturation",
  WhiteBalance = "WhiteBalance",
  FillLightIntensity = "FillLightIntensity",
  Shadow = "Shadow",
  Bloom = "Bloom"
}
local ESliderConfigKey = NewCamera_IngameSelfieConfig.ESliderConfigKey
NewCamera_IngameSelfieConfig.ESchemeType = {Record = 1, Filter = 2}
local ESchemeType = NewCamera_IngameSelfieConfig.ESchemeType
NewCamera_IngameSelfieConfig.EDroneControlType = {FreeMove = 1, LockTarget = 2}
NewCamera_IngameSelfieConfig.ERecordPlayState = {
  NotPlay = 0,
  Pause = 1,
  Playing = 2
}
NewCamera_IngameSelfieConfig.ECameraRecordFilterType = {
  All = 1,
  Official = 2,
  Custom = 3
}
local ECameraRecordFilterType = NewCamera_IngameSelfieConfig.ECameraRecordFilterType
NewCamera_IngameSelfieConfig.CDefaultCameraMode = CameraMode.Fixed
NewCamera_IngameSelfieConfig.CEntryWaitingTimeout = 2
NewCamera_IngameSelfieConfig.CPhotoEditClickMinInterval = 2000
NewCamera_IngameSelfieConfig.CPostProcessCVarRestoreDelay = 0.1
NewCamera_IngameSelfieConfig.CSocketOffsetZ = -70
NewCamera_IngameSelfieConfig.CCameraResetDuration = 0.5
NewCamera_IngameSelfieConfig.CCameraResetPitchOffset = -10
NewCamera_IngameSelfieConfig.CCameraResetYaw = 180
NewCamera_IngameSelfieConfig.CDefaultZoom = 1.0
NewCamera_IngameSelfieConfig.CPanBaseRange = {150, 100}
NewCamera_IngameSelfieConfig.CPanTraceLookAhead = 40
NewCamera_IngameSelfieConfig.CMaxSuitCount = 4
NewCamera_IngameSelfieConfig.CRPSuitIndex = 4
NewCamera_IngameSelfieConfig.CEffectTickRate = {0.1, 0.05}
NewCamera_IngameSelfieConfig.CSuitChangeCDTickRate = {0.1, 0.05}
NewCamera_IngameSelfieConfig.CFocusFollowTolerance = 10
NewCamera_IngameSelfieConfig.CDOFKBlur = 50
NewCamera_IngameSelfieConfig.CDOFFocalRegion = 500
NewCamera_IngameSelfieConfig.CDOFNearTransition = 1500
NewCamera_IngameSelfieConfig.CDOFFarTransition = 2000
NewCamera_IngameSelfieConfig.CDOFBlurMax = 40
NewCamera_IngameSelfieConfig.CDOFNoBlurAperture = 16
NewCamera_IngameSelfieConfig.CDOFScale = 1
NewCamera_IngameSelfieConfig.CDOFMaxTraceDistance = 100000
NewCamera_IngameSelfieConfig.CDOFDefaultFocusDistance = 220
NewCamera_IngameSelfieConfig.CFOVClampMin = 5
NewCamera_IngameSelfieConfig.CFOVClampMax = 120
NewCamera_IngameSelfieConfig.CSensorHeightMM = 24
NewCamera_IngameSelfieConfig.CRoleLightBlueprintPath = "/Game/Mod/EvoBase/BluePrints/Actor/BP_NewCamera_RoleLight.BP_NewCamera_RoleLight"
NewCamera_IngameSelfieConfig.CDefaultToneMapping = {
  Slope = 0.88,
  Shoulder = 0.26,
  BlackClip = 0,
  WhiteClip = 0.04
}
NewCamera_IngameSelfieConfig.CDefaultEmotionSpeed = 1
NewCamera_IngameSelfieConfig.CEmoteNoRateBlacklist = {}
NewCamera_IngameSelfieConfig.CEmoteNoPauseBlacklist = {}
NewCamera_IngameSelfieConfig.CEmoteNoSeekBlacklist = {
  [12220336] = true,
  [22080003] = true,
  [22080002] = true
}
NewCamera_IngameSelfieConfig.CAutoHideUIShowEntryTime = 3
NewCamera_IngameSelfieConfig.CDefaultFillLightDirection = NewCamera_IngameSelfieConfig.EFillLightDir.None
NewCamera_IngameSelfieConfig.CCustomSelfiePPVTag = "NewCameraSelfieCustomPPV"
NewCamera_IngameSelfieConfig.CCustomSelfiePPVLabel = "PostProcessVolume_NewCamera"
NewCamera_IngameSelfieConfig.CCustomSelfiePPVPriority = 1000.0
NewCamera_IngameSelfieConfig.CCameraDefaultArmLength = 220
NewCamera_IngameSelfieConfig.CMaxEmotionSlot = 12
NewCamera_IngameSelfieConfig.CMaxSeqPhotoCount = 10
NewCamera_IngameSelfieConfig.CParamKey_FillLightDirection = "FillLightDirection"
NewCamera_IngameSelfieConfig.CCustomFilterTemplateImgPath_LeftList = "/Game/Mod/EvoBase/Textures/NoAtlas/Photo_Image_Bg_Default_FilterTemplate_02.Photo_Image_Bg_Default_FilterTemplate_02"
NewCamera_IngameSelfieConfig.CCustomFilterTemplateImgPath_MainPage = "/Game/Mod/EvoBase/Textures/NoAtlas/Photo_Image_Bg_Default_FilterTemplate_01.Photo_Image_Bg_Default_FilterTemplate_01"
NewCamera_IngameSelfieConfig.CCustomFilterTemplateNameLength = 32
NewCamera_IngameSelfieConfig.SConfig_Selfie_Slider = {
  key = "",
  title = 0,
  min = 0,
  max = 0,
  default = 0,
  step = 0
}
NewCamera_IngameSelfieConfig.SCamera_Record = {
  id = 0,
  recordID = 0,
  name = "",
  duration = 0,
  keyframes = {}
}
NewCamera_IngameSelfieConfig.SCamera_Record_MontionData = {
  duration = 0,
  keyframes = {}
}
NewCamera_IngameSelfieConfig.SCamera_Record_Keyframe = {
  time = 0,
  focalLength = 0,
  position = {
    x = 0,
    y = 0,
    z = 0
  },
  rotation = {
    pitch = 0,
    yaw = 0,
    roll = 0
  }
}
NewCamera_IngameSelfieConfig.SFilter_Template = {
  id = nil,
  name = "",
  params = {}
}
NewCamera_IngameSelfieConfig.SFilter_Template_Config = {
  getFunc = nil,
  setFunc = nil,
  getParamFunc = nil,
  setParamFunc = nil,
  getDefaultValueFunc = nil,
  resetFunc = nil
}
NewCamera_IngameSelfieConfig.WeatherConfig = {
  [EWeatherType.Sunny] = {
    value = 0,
    icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Sun_png.Photo_Icon_Sun_png",
    lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Sun_Select_png.Photo_Icon_Sun_Select_png"
  },
  [EWeatherType.Sunset] = {
    value = 0.5,
    icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Sunrise_png.Photo_Icon_Sunrise_png",
    lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Sunrise_Select_png.Photo_Icon_Sunrise_Select_png"
  },
  [EWeatherType.Night] = {
    value = 1,
    icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Moon_png.Photo_Icon_Moon_png",
    lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Moon_Select_png.Photo_Icon_Moon_Select_png"
  }
}
NewCamera_IngameSelfieConfig.EmotionSpeedConfig = {
  0.5,
  1,
  1.5,
  2,
  3
}
NewCamera_IngameSelfieConfig.RenderStyleConfig = {
  [ERenderStyle.CLASSIC] = {
    ID = ERenderStyle.CLASSIC,
    Name = 468890207,
    ShowImg = "/Game/UMG/Texture/Lobby_NoAtlas/Setting_icon_biaozhun.Setting_icon_biaozhun"
  },
  [ERenderStyle.COLOURFUL] = {
    ID = ERenderStyle.COLOURFUL,
    Name = 468890208,
    ShowImg = "/Game/UMG/Texture/Lobby_NoAtlas/Setting_icon_xianyan.Setting_icon_xianyan"
  },
  [ERenderStyle.REALISTIC] = {
    ID = ERenderStyle.REALISTIC,
    Name = 468890209,
    ShowImg = "/Game/UMG/Texture/Lobby_NoAtlas/Setting_icon_xieshi.Setting_icon_xieshi"
  },
  [ERenderStyle.SOFT] = {
    ID = ERenderStyle.SOFT,
    Name = 468890210,
    ShowImg = "/Game/UMG/Texture/Lobby_NoAtlas/Setting_icon_rouhe.Setting_icon_rouhe"
  },
  [ERenderStyle.MOVIE] = {
    ID = ERenderStyle.MOVIE,
    Name = 468890211,
    ShowImg = "/Game/UMG/Texture/Lobby_NoAtlas/Setting_icon_dianying.Setting_icon_dianying"
  }
}
NewCamera_IngameSelfieConfig.FillLightDirConfig = {
  [EFillLightDir.None] = {name = 6653},
  [EFillLightDir.Up] = {name = 468890212},
  [EFillLightDir.Down] = {name = 468890213},
  [EFillLightDir.Left] = {name = 468890214},
  [EFillLightDir.Right] = {name = 468890215}
}
NewCamera_IngameSelfieConfig.ProtocolErrorCodeMap = {
  [100380001] = 468890222,
  [100380002] = 468890223,
  [100380003] = 44791,
  [100380004] = 468890225,
  [100380005] = 468890226,
  [100380006] = 468890227,
  [100380007] = 468890228,
  [100380008] = 468890229,
  [100380009] = 468890230,
  [100380010] = 468890231,
  [100380011] = 111348
}
NewCamera_IngameSelfieConfig.IgnoreEmoteConfig = {
  [12219241] = true,
  [12219243] = true,
  [12219359] = true,
  [12219360] = true,
  [12219440] = true,
  [12219601] = true,
  [12220038] = true,
  [12220100] = true,
  [12220101] = true,
  [12220102] = true,
  [12220349] = true,
  [12220370] = true,
  [12220501] = true
}
NewCamera_IngameSelfieConfig.AutoExitSelfieByPlayerState = {
  [EPawnState.LeanOutVehicle] = true,
  [EPawnState.DriveVehicle] = true,
  [EPawnState.InVehicle] = true
}
NewCamera_IngameSelfieConfig.NeedRefreshOriginParamByPlayerState = {
  [EPawnState.DriveVehicle] = true,
  [EPawnState.InVehicle] = true
}
local EHeroID = UEnums.HeroID
NewCamera_IngameSelfieConfig.FocusViewOnlyLockActorHeroIDs = {
  [EHeroID.Pet] = true
}
NewCamera_IngameSelfieConfig.CDronePawnPath = "/Game/Mod/EvoBase/BluePrints/Actor/BP_NewCamera_FreeViewPawn.BP_NewCamera_FreeViewPawn"
NewCamera_IngameSelfieConfig.CDroneViewBlendTime = 0.3
NewCamera_IngameSelfieConfig.CDroneHeightRange = {Min = -500, Max = 5000}
NewCamera_IngameSelfieConfig.CDroneDefaultArmLength = 300
NewCamera_IngameSelfieConfig.CDroneDragYawDegPerPixel = 0.3
NewCamera_IngameSelfieConfig.CDroneDragPitchDegPerPixel = 0.3
NewCamera_IngameSelfieConfig.CDroneMoveSpeed = 600
NewCamera_IngameSelfieConfig.CDroneHeightSpeed = 200
NewCamera_IngameSelfieConfig.CDronePitchLimitDeg = 89
NewCamera_IngameSelfieConfig.CDroneTiltSpeed = 45
NewCamera_IngameSelfieConfig.CDroneJoyStickRotateSpeed = 50
NewCamera_IngameSelfieConfig.CDroneRecordDuration = 30
NewCamera_IngameSelfieConfig.CDroneRecordFrameInterval = 0.1
NewCamera_IngameSelfieConfig.CDroneRecordRotDebug = false
NewCamera_IngameSelfieConfig.CDroneRecordCountDown = {
  "3",
  "2",
  "1",
  468890216
}
NewCamera_IngameSelfieConfig.CDroneLockArmLengthRange = {Min = 100, Max = 1000}
NewCamera_IngameSelfieConfig.CDroneFreeArmLength = 0
NewCamera_IngameSelfieConfig.CDroneArmLengthSpeed = 500
NewCamera_IngameSelfieConfig.CDefaultDroneArmLength = 500
NewCamera_IngameSelfieConfig.CCameraRecordMountOffset = {
  x = 0,
  y = 0,
  z = -88
}
NewCamera_IngameSelfieConfig.CCameraRecordMountRotation = {
  pitch = 0,
  yaw = -90,
  roll = 0
}
NewCamera_IngameSelfieConfig.CCameraRecordTemplateID = 80001
NewCamera_IngameSelfieConfig.CCameraRecordNameLength = 32
NewCamera_IngameSelfieConfig.CCameraRecordSchemeMaxSize = 8192
NewCamera_IngameSelfieConfig.CCameraRecordCompressPosTolerance = 10
NewCamera_IngameSelfieConfig.CCameraRecordCompressRotTolerance = 2
NewCamera_IngameSelfieConfig.CCameraRecordCompressFocalTolerance = 0.5
NewCamera_IngameSelfieConfig.CCameraRecordMaxRotStepDeg = 90
NewCamera_IngameSelfieConfig.CCameraRecordSchemeMaxCount = 5
NewCamera_IngameSelfieConfig.CCameraRecordNoticeID = {
  Save = 9826,
  Delete = 46033,
  NameChange = 530014,
  Replace = 88230
}
NewCamera_IngameSelfieConfig.CCameraRecordFilterConfig = {
  [ECameraRecordFilterType.All] = {comboText = 468890217},
  [ECameraRecordFilterType.Official] = {comboText = 468890218, sectionTitle = 468890218},
  [ECameraRecordFilterType.Custom] = {comboText = 880060394, sectionTitle = 880060394}
}
return NewCamera_IngameSelfieConfig
