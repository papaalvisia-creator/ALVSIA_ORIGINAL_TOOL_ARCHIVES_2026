local NewCameraConfig = require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieConfig")
local bEnableSuitChangeCD = true

local function IsSuitCDEnabled()
  return bEnableSuitChangeCD
end

local suitLastChangeTime = 0
local suitCDDuration = 0
local suitCDTickRate, suitCDTimer

local function ClearSuitCDTimer()
  if suitCDTimer then
    Game:ClearTimer(suitCDTimer)
    suitCDTimer = nil
  end
end

local function IsSuitInCD()
  if not IsSuitCDEnabled() then
    return false
  end
  return 0 < suitCDDuration and Game:GetCurTimeMilliseconds() - suitLastChangeTime < suitCDDuration
end

local function GetSuitCDRemainTime()
  return suitCDDuration - (Game:GetCurTimeMilliseconds() - suitLastChangeTime)
end

local function StartSuitCDTimer()
  ClearSuitCDTimer()
  if not suitCDTickRate then
    local level = Client.GetExactDeviceLevel()
    suitCDTickRate = NewCameraConfig.CSuitChangeCDTickRate[level <= 0 and 1 or 2]
  end
  suitCDTimer = Game:SetTimer(suitCDTickRate, true, function()
    local curRemainTime = GetSuitCDRemainTime()
    if curRemainTime <= 0 then
      EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_SET_SUIT_CD_SHOW, false)
      ClearSuitCDTimer()
      return
    end
    EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_REFRESH_SUIT_CD_COUNT, curRemainTime)
  end)
end

local function StartSuitChangeCD(changeCD)
  changeCD = changeCD or 1
  suitCDDuration = changeCD * 1000
  suitLastChangeTime = Game:GetCurTimeMilliseconds()
  ClearSuitCDTimer()
  EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_SET_SUIT_CD_SHOW, true)
  EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_REFRESH_SUIT_CD_COUNT, suitCDDuration)
  StartSuitCDTimer()
end

local NewCamera_Photo_Suit_Item_UIBP = {}

function NewCamera_Photo_Suit_Item_UIBP:OnInitialize()
  self.changeCD = 1
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if IngameSelfieSubsystem then
    self.changeCD = IngameSelfieSubsystem:GetParamConfigValue(NewCameraConfig.EParamConfigKey.SuitChangeCD, nil, 1)
  end
end

function NewCamera_Photo_Suit_Item_UIBP:RegistEvents()
  self:AddOnClickedEventByControl(self.UIRoot.Button_Suit, self.OnClickButton_Suit, self)
  if not IsSuitCDEnabled() then
    return
  end
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_SET_SUIT_CD_SHOW, self.OnSettingSuitCDShow, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_REFRESH_SUIT_CD_COUNT, self.OnRefreshSuitCDCount, self)
end

function NewCamera_Photo_Suit_Item_UIBP:OnClose()
  ClearSuitCDTimer()
end

function NewCamera_Photo_Suit_Item_UIBP:OnClickButton_Suit()
  self:PlayAudio(sound_config.click_v1)
  if not self.hasUnLock then
    ShowNotice(48384)
    return
  end
  if IsSuitInCD() then
    local remainTime = GetSuitCDRemainTime()
    log(bWriteLog and "NewCamera_Photo_Suit_Item_UIBP:OnClickButton_Suit suit still in CD, remainTime = " .. tostring(remainTime))
    ShowNotice(LocUtil.LocalizeResFormat(26016, math.ceil(remainTime / 1000)))
    return
  end
  if self.onClickCallback then
    self.onClickCallback(self.index)
  end
  if IsSuitCDEnabled() then
    StartSuitChangeCD(self.changeCD)
  end
end

function NewCamera_Photo_Suit_Item_UIBP:OnSettingSuitCDShow(_, _, bShow)
  self:SetWidgetVisible(self.UIRoot.Image_CDTime, bShow)
  self:SetWidgetVisible(self.UIRoot.TextBlock_Time, bShow)
end

function NewCamera_Photo_Suit_Item_UIBP:OnRefreshSuitCDCount(_, _, curRemainTime)
  if self.UIRoot.Image_CDTime then
    local dynamicMat = self.UIRoot.Image_CDTime:GetDynamicMaterial()
    if slua.isValid(dynamicMat) then
      local totalTime = 0 < suitCDDuration and suitCDDuration or 1000
      dynamicMat:SetScalarParameterValue("Mask_Percent", curRemainTime / totalTime)
    end
  end
  if self.UIRoot.TextBlock_Time then
    self.UIRoot.TextBlock_Time:SetText(string.format("%.0f", curRemainTime / 1000))
  end
end

function NewCamera_Photo_Suit_Item_UIBP:OnRefresh(data, selectedIndex)
  self.hasUnLock = data.hasUnLock
  local isRP = data.isRP
  self.onClickCallback = data.onClickCallback
  local numStr = isRP and LocUtil.GetLocalizeResStr(29902) or self.index
  self.UIRoot.TextBlock_Num1:SetText(numStr)
  self.UIRoot.TextBlock_Num2:SetText(numStr)
  self.UIRoot.TextBlock_Num3:SetText(numStr)
  local switchIndex = 0
  if selectedIndex and selectedIndex == self.index then
    switchIndex = 1
  else
    switchIndex = self.hasUnLock and 0 or 2
  end
  self.UIRoot.WidgetSwitcher_SuitState:SetActiveWidgetIndex(switchIndex)
  self:_RefreshCDState()
end

function NewCamera_Photo_Suit_Item_UIBP:_RefreshCDState()
  if not IsSuitCDEnabled() then
    return
  end
  local bInCD = IsSuitInCD()
  self:SetWidgetVisible(self.UIRoot.Image_CDTime, bInCD)
  self:SetWidgetVisible(self.UIRoot.TextBlock_Time, bInCD)
  if not bInCD then
    return
  end
  if not suitCDTimer then
    StartSuitCDTimer()
  end
  self:OnRefreshSuitCDCount(nil, nil, GetSuitCDRemainTime())
end

local class = require("class")
local scroll_box_child_base = require("client.slua_ui_framework.component.scroll_box_child_base")
local CNewCamera_Photo_Suit_Item_UIBP = class(scroll_box_child_base, nil, NewCamera_Photo_Suit_Item_UIBP)
return CNewCamera_Photo_Suit_Item_UIBP
