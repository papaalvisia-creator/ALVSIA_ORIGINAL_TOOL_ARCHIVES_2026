local TableUtil = require("common.table_util")
local NewCamera_CameraRecordCompress = {}
local DEFAULT_POS_TOLERANCE = 2
local DEFAULT_ROT_TOLERANCE = 0.5
local DEFAULT_MAX_ROT_STEP = 90
local DEFAULT_FOCAL_TOLERANCE = 0.5
local DECIMALS = 2

local function _Round(value, decimals)
  if type(value) ~= "number" then
    return 0
  end
  decimals = decimals or DECIMALS
  local mult = 10 ^ decimals
  local rounded = math.floor(math.abs(value) * mult + 0.5) / mult
  return value < 0 and -rounded or rounded
end

local function _AngleDelta(a, b)
  local d = a - b
  while 180 < d do
    d = d - 360
  end
  while d <= -180 do
    d = d + 360
  end
  return d
end

local function _PointSegmentDistance(px, py, pz, ax, ay, az, bx, by, bz)
  local dx, dy, dz = bx - ax, by - ay, bz - az
  local lenSq = dx * dx + dy * dy + dz * dz
  if lenSq <= 0 then
    local ex, ey, ez = px - ax, py - ay, pz - az
    return math.sqrt(ex * ex + ey * ey + ez * ez)
  end
  local t = ((px - ax) * dx + (py - ay) * dy + (pz - az) * dz) / lenSq
  t = math.max(0, math.min(1, t))
  local cx, cy, cz = ax + t * dx, ay + t * dy, az + t * dz
  local ex, ey, ez = px - cx, py - cy, pz - cz
  return math.sqrt(ex * ex + ey * ey + ez * ez)
end

local function _PosError(frames, i, j, k)
  local p, a, b = frames[i], frames[j], frames[k]
  return _PointSegmentDistance(p._posX, p._posY, p._posZ, a._posX, a._posY, a._posZ, b._posX, b._posY, b._posZ)
end

local function _RotError(frames, i, j, k)
  local p, a, b = frames[i], frames[j], frames[k]
  local ratio = 0 < k - j and (i - j) / (k - j) or 0
  local dp = math.abs(_AngleDelta(p._pitch, a._pitch + (b._pitch - a._pitch) * ratio))
  local dy = math.abs(_AngleDelta(p._yaw, a._yaw + (b._yaw - a._yaw) * ratio))
  local dr = math.abs(_AngleDelta(p._roll, a._roll + (b._roll - a._roll) * ratio))
  return math.max(dp, dy, dr)
end

local function _FocalError(frames, i, j, k)
  local p, a, b = frames[i], frames[j], frames[k]
  local ratio = 0 < k - j and (i - j) / (k - j) or 0
  local expect = a._focal + (b._focal - a._focal) * ratio
  return math.abs(p._focal - expect)
end

local function _DouglasPeucker(frames, j, k, tolerance, errorFunc, keepSet)
  if k <= j + 1 then
    return
  end
  local stack = {
    {j, k}
  }
  while 0 < #stack do
    local seg = table.remove(stack)
    local sj, sk = seg[1], seg[2]
    if sk > sj + 1 then
      local maxErr, maxIdx = -1, sj
      for i = sj + 1, sk - 1 do
        local err = errorFunc(frames, i, sj, sk)
        if maxErr < err then
          maxErr, maxIdx = err, i
        end
      end
      if tolerance < maxErr then
        keepSet[maxIdx] = true
        table.insert(stack, {sj, maxIdx})
        table.insert(stack, {maxIdx, sk})
      end
    end
  end
end

local function _UnwrapAngles(frames)
  local first = frames[1]
  local prevP, prevY, prevR = first._pitch, first._yaw, first._roll
  for i = 2, #frames do
    local f = frames[i]
    local cp = f._pitch
    while 180 < cp - prevP do
      cp = cp - 360
    end
    while cp - prevP < -180 do
      cp = cp + 360
    end
    f._pitch = cp
    prevP = cp
    local cy = f._yaw
    while 180 < cy - prevY do
      cy = cy - 360
    end
    while cy - prevY < -180 do
      cy = cy + 360
    end
    f._yaw = cy
    prevY = cy
    local cr = f._roll
    while 180 < cr - prevR do
      cr = cr - 360
    end
    while cr - prevR < -180 do
      cr = cr + 360
    end
    f._roll = cr
    prevR = cr
  end
end

function NewCamera_CameraRecordCompress.Compress(keyframes, options)
  if type(keyframes) ~= "table" or #keyframes <= 2 then
    return TableUtil.CopyTable(keyframes or {})
  end
  options = options or {}
  local posTol = options.posTolerance or DEFAULT_POS_TOLERANCE
  local rotTol = options.rotTolerance or DEFAULT_ROT_TOLERANCE
  local focalTol = options.focalTolerance or DEFAULT_FOCAL_TOLERANCE
  local maxRotStep = options.maxRotStepDeg or DEFAULT_MAX_ROT_STEP
  local frames = {}
  for i, kf in ipairs(keyframes) do
    local pos = kf.position or {}
    local rot = kf.rotation or {}
    frames[i] = {
      _src = kf,
      _posX = pos.x or 0,
      _posY = pos.y or 0,
      _posZ = pos.z or 0,
      _pitch = rot.pitch or 0,
      _yaw = rot.yaw or 0,
      _roll = rot.roll or 0,
      _focal = kf.focalLength or 0
    }
  end
  _UnwrapAngles(frames)
  local keepSet = {
    [1] = true,
    [#frames] = true
  }
  _DouglasPeucker(frames, 1, #frames, posTol, _PosError, keepSet)
  _DouglasPeucker(frames, 1, #frames, rotTol, _RotError, keepSet)
  _DouglasPeucker(frames, 1, #frames, focalTol, _FocalError, keepSet)
  local kept = {}
  for i = 1, #frames do
    if keepSet[i] then
      table.insert(kept, i)
    end
  end
  for idx = #kept, 2, -1 do
    local i, j = kept[idx - 1], kept[idx]
    if 1 < j - i then
      local a, b = frames[i], frames[j]
      local maxDelta = math.max(math.abs(b._pitch - a._pitch), math.abs(b._yaw - a._yaw), math.abs(b._roll - a._roll))
      local steps = math.ceil(maxDelta / maxRotStep)
      if 1 < steps then
        for k = 1, steps - 1 do
          local inner = i + math.floor((j - i) * k / steps + 0.5)
          if i < inner and j > inner then
            keepSet[inner] = true
          end
        end
      end
    end
  end
  local result = {}
  for i = 1, #frames do
    if keepSet[i] then
      table.insert(result, TableUtil.CopyTable(frames[i]._src))
    end
  end
  log(bWriteLog and string.format("NewCamera_CameraRecordCompress:Compress %d -> %d frames (posTol=%s rotTol=%s focalTol=%s maxRotStep=%s)", #keyframes, #result, posTol, rotTol, focalTol, maxRotStep))
  return result
end

function NewCamera_CameraRecordCompress.CompressToFit(keyframes, roundFunc, limit, baseOptions)
  if type(keyframes) ~= "table" or type(roundFunc) ~= "function" then
    return keyframes or {}, 0, false
  end
  baseOptions = baseOptions or {}
  local basePos = baseOptions.posTolerance or DEFAULT_POS_TOLERANCE
  local baseRot = baseOptions.rotTolerance or DEFAULT_ROT_TOLERANCE
  local baseFocal = baseOptions.focalTolerance or DEFAULT_FOCAL_TOLERANCE
  local baseMaxRotStep = baseOptions.maxRotStepDeg or DEFAULT_MAX_ROT_STEP
  local bestFrames, bestSize
  local TOLERANCE_STEPS = {
    2,
    4,
    8,
    16,
    32
  }
  for _, scale in ipairs(TOLERANCE_STEPS) do
    local frames = NewCamera_CameraRecordCompress.Compress(keyframes, {
      posTolerance = basePos * scale,
      rotTolerance = baseRot * scale,
      focalTolerance = baseFocal * scale,
      maxRotStepDeg = baseMaxRotStep
    })
    frames = NewCamera_CameraRecordCompress.RoundValues(frames)
    local size = roundFunc(frames) or 0
    bestFrames, bestSize = frames, size
    if limit >= size then
      log(bWriteLog and string.format("NewCamera_CameraRecordCompress:CompressToFit ok scale=%s frames=%d size=%d limit=%d", scale, #frames, size, limit))
      return frames, size, true
    end
  end
  log_warning(bWriteLog and string.format("NewCamera_CameraRecordCompress:CompressToFit failed, still over limit size=%d limit=%d frames=%d", bestSize or 0, limit, bestFrames and #bestFrames or 0))
  return bestFrames or keyframes, bestSize or 0, false
end

function NewCamera_CameraRecordCompress.RoundValues(keyframes, decimals)
  if type(keyframes) ~= "table" then
    return {}
  end
  decimals = decimals or DECIMALS
  local result = {}
  for i, kf in ipairs(keyframes) do
    local pos = kf.position or {}
    local rot = kf.rotation or {}
    result[i] = {
      time = _Round(kf.time, decimals),
      position = {
        x = _Round(pos.x, decimals),
        y = _Round(pos.y, decimals),
        z = _Round(pos.z, decimals)
      },
      rotation = {
        pitch = _Round(rot.pitch, decimals),
        yaw = _Round(rot.yaw, decimals),
        roll = _Round(rot.roll, decimals)
      },
      focalLength = _Round(kf.focalLength, decimals)
    }
  end
  return result
end

local ROW_FIELDS = 8

local function _RowToKeyframe(row)
  if type(row) ~= "table" or #row < ROW_FIELDS then
    return nil
  end
  local nums = {}
  for i = 1, ROW_FIELDS do
    nums[i] = tonumber(row[i]) or 0
  end
  return {
    time = nums[1],
    position = {
      x = nums[2],
      y = nums[3],
      z = nums[4]
    },
    rotation = {
      pitch = nums[5],
      yaw = nums[6],
      roll = nums[7]
    },
    focalLength = nums[8]
  }
end

function NewCamera_CameraRecordCompress.Decode(motionStr)
  if type(motionStr) ~= "string" or motionStr == "" then
    log_warning(bWriteLog and "NewCamera_CameraRecordCompress:Decode motionStr is empty")
    return nil
  end
  local raw = json.decode(motionStr)
  if type(raw) ~= "table" then
    log_warning(bWriteLog and "NewCamera_CameraRecordCompress:Decode json decode failed")
    return nil
  end
  local duration = tonumber(raw.duration) or 0
  local keyframes = {}
  if type(raw.k) == "table" then
    for _, row in ipairs(raw.k) do
      local kf = _RowToKeyframe(row)
      if kf then
        table.insert(keyframes, kf)
      end
    end
  elseif type(raw.keyframes) == "table" then
    for _, kf in ipairs(raw.keyframes) do
      if type(kf) == "table" then
        local pos = kf.position or {}
        local rot = kf.rotation or {}
        table.insert(keyframes, {
          time = tonumber(kf.time) or 0,
          position = {
            x = tonumber(pos.x) or 0,
            y = tonumber(pos.y) or 0,
            z = tonumber(pos.z) or 0
          },
          rotation = {
            pitch = tonumber(rot.pitch) or 0,
            yaw = tonumber(rot.yaw) or 0,
            roll = tonumber(rot.roll) or 0
          },
          focalLength = tonumber(kf.focalLength) or tonumber(kf.fov) or 0
        })
      end
    end
  else
    log_warning(bWriteLog and "NewCamera_CameraRecordCompress:Decode no keyframes found")
    return nil
  end
  log(bWriteLog and string.format("NewCamera_CameraRecordCompress:Decode ok, duration=%s keyframes=%d", duration, #keyframes))
  return {duration = duration, keyframes = keyframes}
end

return NewCamera_CameraRecordCompress
