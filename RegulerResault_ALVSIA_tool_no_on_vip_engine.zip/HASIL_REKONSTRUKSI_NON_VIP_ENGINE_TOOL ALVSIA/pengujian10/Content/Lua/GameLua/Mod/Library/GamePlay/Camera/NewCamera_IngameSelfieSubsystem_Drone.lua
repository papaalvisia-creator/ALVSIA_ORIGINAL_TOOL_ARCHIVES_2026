local NewCameraConfig = require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieConfig")
local ESchemeType = NewCameraConfig.ESchemeType
local TableUtil = require("common.table_util")
local NewCamera_CameraRecordCompress = require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_CameraRecordCompress")
local NewCameraUtil = require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieUtil")
local NewCameraTLogReport = require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfie_TLog_Report")
local GameplayData = require("GameLua.GameCore.Data.GameplayData")
local KismetMathLibrary = import("KismetMathLibrary")
local UKismetMathLibrary = KismetMathLibrary
local GameplayStatics = import("GameplayStatics")
local NewCameraTest = require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieTest")

local function _AngleDelta(a, b)
  local d = a - b
  while 180 < d do
    d = d - 360
  end
  while d <= -180 do
    d = d + 360
  end
  return d
end

local NewCamera_IngameSelfieSubsystem_Drone = {}

function NewCamera_IngameSelfieSubsystem_Drone:ctor_Drone()
  self.dronePawn = nil
  self._droneArmLength = 0
  self._droneBaseFocalLength = nil
  self._droneControlMode = NewCameraConfig.EDroneControlType.FreeMove
  self._dronePrevViewTarget = nil
  self._dronePrevVehicle = nil
  self._lastLockJoystickTime = nil
  self._droneYawOwner = nil
  self._unbindMoveDelegateTimer = nil
  self._unbindMoveDelegateElapsed = 0
  self._dronePinchThresholdCount = 0
  self.bDronePinning = false
  self._cameraRecordData = {}
  self._curRecordData = nil
  self.bIsRecordingDrone = false
  self._droneRecordStartTime = 0
  self._droneRecordFrameCount = 0
  self._lastRecordPos = nil
  self._lastRecordRot = nil
  self._recUnwrapRot = nil
  self._lastRecordFocalLength = nil
  self._pendingCameraRecordOp = nil
end

function NewCamera_IngameSelfieSubsystem_Drone:StartDroneControl()
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:StartDroneControl")
  self:SetDroneControlMode(NewCameraConfig.EDroneControlType.FreeMove)
  self._lastLockJoystickTime = nil
  self._droneYawOwner = nil
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerController) then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:StartDroneControl playerController invalid")
    return
  end
  local playerCharacter = GameplayData.GetPlayerCharacter()
  if not slua.isValid(playerCharacter) then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:StartDroneControl playerCharacter invalid")
    return
  end
  if slua.isValid(self.dronePawn) then
    self.dronePawn:K2_DestroyActor()
    self.dronePawn = nil
  end
  local pawnClass = slua.loadClass(NewCameraConfig.CDronePawnPath)
  if not slua.isValid(pawnClass) then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:StartDroneControl failed to load pawn class")
    return
  end
  local spawnLoc = playerCharacter:K2_GetActorLocation()
  local spawnRot = playerCharacter:K2_GetActorRotation()
  if slua.isValid(playerCharacter.Camera) then
    local charCamLoc = playerCharacter.Camera:K2_GetComponentLocation()
    local charCamRot = playerCharacter.Camera:K2_GetComponentRotation()
    if charCamLoc and charCamRot then
      spawnLoc = charCamLoc
      spawnRot = charCamRot
    end
  end
  self.dronePawn = CGameWorld:SpawnActor(pawnClass, spawnLoc, nil, nil)
  if not slua.isValid(self.dronePawn) then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:StartDroneControl SpawnActor failed")
    return
  end
  self.dronePawn:K2_SetActorRotation(FRotator(spawnRot.Pitch, spawnRot.Yaw, spawnRot.Roll), false)
  if slua.isValid(playerCharacter.Camera) then
    local charFov = playerCharacter.Camera.FieldOfView
    printf("DroneStart fovAlignCheck charFov=%s hasSetFunc=%s", tostring(charFov), tostring(self.dronePawn.SetCameraFOV ~= nil))
    if charFov and 0 < charFov then
      self.dronePawn:SetCameraFOV(charFov)
    end
  else
    printf("DroneStart fovAlignCheck camera invalid")
  end
  do
    local pcCam = playerController.PlayerCameraManager
    local p = self.dronePawn:K2_GetActorLocation()
    local c = self.dronePawn:GetCameraWorldLocation()
    local dRot = self.dronePawn:GetCameraWorldRotation()
    printf("DroneStart expect=(%.1f,%.1f,%.1f) actorAfterSpawn=(%.1f,%.1f,%.1f) camAfterSpawn=(%.1f,%.1f,%.1f)", spawnLoc.X, spawnLoc.Y, spawnLoc.Z, p and p.X or 0, p and p.Y or 0, p and p.Z or 0, c and c.X or 0, c and c.Y or 0, c and c.Z or 0)
    printf("DroneStart rotCharCam=(%.1f,%.1f,%.1f) rotDroneCam=(%.1f,%.1f,%.1f) fovCharCam=%.2f fovDroneCam=%.2f pcCamRot=(%.1f,%.1f,%.1f) pcCamFov=%.2f", spawnRot.Pitch, spawnRot.Yaw, spawnRot.Roll, dRot and dRot.Pitch or 0, dRot and dRot.Yaw or 0, dRot and dRot.Roll or 0, playerCharacter.Camera and playerCharacter.Camera.FieldOfView or -1, self.dronePawn:GetCamera() and self.dronePawn:GetCamera().FieldOfView or -1, pcCam and pcCam:GetCameraRotation().Pitch or 0, pcCam and pcCam:GetCameraRotation().Yaw or 0, pcCam and pcCam:GetCameraRotation().Roll or 0, pcCam and pcCam:GetFOVAngle() or -1)
  end
  self.dronePawn:SetHeightRange(NewCameraConfig.CDroneHeightRange.Min, NewCameraConfig.CDroneHeightRange.Max)
  self._dronePinchThresholdCount = 0
  self.bDronePinning = false
  self._dronePinchRate = self:GetParamConfigValue(NewCameraConfig.EParamConfigKey.ZoomChangePinchRate, 1, 1)
  self._dronePinchThreshold = self:GetParamConfigValue(NewCameraConfig.EParamConfigKey.ZoomChangePinchThreshold, 1, 0.15)
  self:_ApplyDroneArmLength(NewCameraConfig.CDroneFreeArmLength, true)
  do
    local p = self.dronePawn:K2_GetActorLocation()
    local c = self.dronePawn:GetCameraWorldLocation()
    local arm = self.dronePawn:GetTargetArmLength()
    printf("DroneStart afterArmZero actor=(%.1f,%.1f,%.1f) cam=(%.1f,%.1f,%.1f) armLength=%.2f", p and p.X or 0, p and p.Y or 0, p and p.Z or 0, c and c.X or 0, c and c.Y or 0, c and c.Z or 0, arm or -1)
  end
  self.dronePawn:SetInitialTransform()
  self._droneBaseFocalLength = self.dronePawn:GetCameraFocalLength()
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:StartDroneControl baseFocalLength = " .. tostring(self._droneBaseFocalLength))
  self:CacheDronePrevViewTarget()
  playerController:SetViewTargetWithBlend(self.dronePawn, NewCameraConfig.CDroneViewBlendTime, 0, 0, false)
  self:AddControlEvent(playerController, "MoveForwardDelegate", function(rate)
    if slua.isValid(self.dronePawn) then
      self.dronePawn:SetMoveInput(rate, self.dronePawn.moveRightRate or 0)
    end
  end)
  self:AddControlEvent(playerController, "MoveRightDelegate", function(rate)
    if slua.isValid(self.dronePawn) then
      self.dronePawn:SetMoveInput(self.dronePawn.moveForwardRate or 0, rate)
    end
  end)
  self:DisableTouchInput("Drone")
  self.bInDroneMode = true
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:StartDroneControl done")
  EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_START_CONTROL_DRONE)
end

function NewCamera_IngameSelfieSubsystem_Drone:StopDroneControl()
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:StopDroneControl")
  NewCameraTest.DumpMoveResidue("droneStopBeforeClean")
  self.bInDroneMode = false
  self:SetDroneControlMode(NewCameraConfig.EDroneControlType.FreeMove)
  self:StopDroneMove()
  NewCameraUtil.ClearPendingMoveInputResidue()
  self._droneYawOwner = nil
  local playerController = GameplayData.GetPlayerController()
  if slua.isValid(playerController) then
    self:_UnbindMoveDelegateAfterAxisCleared()
    self:RestoreDroneViewTarget()
    self:EnableTouchInput("Drone")
  end
  if slua.isValid(self.dronePawn) then
    self.dronePawn:StopHeightMove()
    self.dronePawn:SetMoveInput(0, 0)
    self.dronePawn:K2_DestroyActor()
    self.dronePawn = nil
  end
  NewCameraTest.DumpMoveResidue("droneStop")
  NewCameraTest.DumpMoveResidueAfterExit(self)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:StopDroneControl done")
  EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_STOP_CONTROL_DRONE)
end

function NewCamera_IngameSelfieSubsystem_Drone:StartDroneExitInputTrace()
end

function NewCamera_IngameSelfieSubsystem_Drone:CacheDronePrevViewTarget()
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerController) then
    return
  end
  self._dronePrevViewTarget = playerController:GetViewTarget()
  self._dronePrevVehicle = NewCameraUtil.GetCurrentVehicle()
  printf("NewCamera_IngameSelfieSubsystem_Drone:CacheDronePrevViewTarget prevViewTarget:%s, prevVehicle:%s", tostring(self._dronePrevViewTarget), tostring(self._dronePrevVehicle))
end

function NewCamera_IngameSelfieSubsystem_Drone:RestoreDroneViewTarget()
  local prevViewTarget = self._dronePrevViewTarget
  local prevVehicle = self._dronePrevVehicle
  self._dronePrevViewTarget = nil
  self._dronePrevVehicle = nil
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerController) then
    return nil
  end
  local playerCharacter = GameplayData.GetPlayerCharacter()
  local curVehicle = NewCameraUtil.GetCurrentVehicle()
  local bPrevViewTargetStale = not slua.isValid(prevViewTarget) or prevVehicle ~= nil and prevVehicle ~= curVehicle
  local targetViewTarget = prevViewTarget
  if bPrevViewTargetStale then
    targetViewTarget = playerCharacter
  end
  if not slua.isValid(targetViewTarget) then
    targetViewTarget = playerCharacter
  end
  if slua.isValid(targetViewTarget) then
    playerController:SetViewTargetWithBlend(targetViewTarget, NewCameraConfig.CDroneViewBlendTime, 0, 0, false)
  end
  printf("NewCamera_IngameSelfieSubsystem_Drone:RestoreDroneViewTarget prevViewTarget:%s, prevVehicle:%s, curVehicle:%s, restoreViewTarget:%s", tostring(prevViewTarget), tostring(prevVehicle), tostring(curVehicle), tostring(targetViewTarget))
  return targetViewTarget
end

function NewCamera_IngameSelfieSubsystem_Drone:StartDroneUp()
  if not slua.isValid(self.dronePawn) then
    return
  end
  self.dronePawn:SetAddHeightState(true)
end

function NewCamera_IngameSelfieSubsystem_Drone:StopDroneUp()
  if not slua.isValid(self.dronePawn) then
    return
  end
  self.dronePawn:SetAddHeightState(false)
end

function NewCamera_IngameSelfieSubsystem_Drone:StartDroneDown()
  if not slua.isValid(self.dronePawn) then
    return
  end
  self.dronePawn:SetSubHeightState(true)
end

function NewCamera_IngameSelfieSubsystem_Drone:StopDroneDown()
  if not slua.isValid(self.dronePawn) then
    return
  end
  self.dronePawn:SetSubHeightState(false)
end

function NewCamera_IngameSelfieSubsystem_Drone:SetDroneHeightRate(rate)
  if not slua.isValid(self.dronePawn) then
    return
  end
  self.dronePawn:SetHeightRate(rate or 0)
end

function NewCamera_IngameSelfieSubsystem_Drone:SetDroneTiltRate(rate)
  if not slua.isValid(self.dronePawn) then
    return
  end
  self.dronePawn:SetTiltRate(rate or 0)
end

function NewCamera_IngameSelfieSubsystem_Drone:ResetDroneTilt()
  if not slua.isValid(self.dronePawn) then
    return
  end
  self.dronePawn:ResetTilt()
end

function NewCamera_IngameSelfieSubsystem_Drone:ResetDronePosition()
  if not slua.isValid(self.dronePawn) then
    return
  end
  if self:IsDroneLockMode() then
    local playerCharacter = GameplayData.GetPlayerCharacter()
    local initCamPos = self.dronePawn:GetInitialCameraLocation()
    if slua.isValid(playerCharacter) and initCamPos then
      self.dronePawn:ApplyPivotAndCameraPos(playerCharacter:K2_GetActorLocation(), initCamPos, true)
      log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:ResetDronePosition lock mode done")
      return
    end
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:ResetDronePosition lock mode fallback")
  end
  self.dronePawn:ResetPosition()
end

function NewCamera_IngameSelfieSubsystem_Drone:GetDroneControlMode()
  return self._droneControlMode or NewCameraConfig.EDroneControlType.FreeMove
end

function NewCamera_IngameSelfieSubsystem_Drone:IsDroneLockMode()
  return self:GetDroneControlMode() == NewCameraConfig.EDroneControlType.LockTarget
end

function NewCamera_IngameSelfieSubsystem_Drone:SetDroneControlMode(mode)
  if not slua.isValid(self.dronePawn) then
    return
  end
  if mode == self._droneControlMode then
    return
  end
  local playerCharacter = GameplayData.GetPlayerCharacter()
  if not slua.isValid(playerCharacter) then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:SetDroneControlMode playerCharacter invalid")
    return
  end
  local camPos = self.dronePawn:GetCameraWorldLocation()
  local camRotBefore = self.dronePawn:GetCameraWorldRotation()
  if not camPos then
    return
  end
  self._droneControlMode = mode
  self.dronePawn:SetLockMode(mode == NewCameraConfig.EDroneControlType.LockTarget)
  if mode == NewCameraConfig.EDroneControlType.LockTarget then
    self.dronePawn:SetArmLengthAdaptive(false)
    local charPos = playerCharacter:K2_GetActorLocation()
    self.dronePawn:ApplyPivotAndCameraPos(charPos, camPos, true)
    self._droneArmLength = self.dronePawn:GetTargetArmLength() or NewCameraConfig.CDroneLockArmLengthRange.Min
    local afterPos = self.dronePawn:GetCameraWorldLocation()
    local afterRot = self.dronePawn:GetCameraWorldRotation()
    local aimDeltaZ = camPos.Z - charPos.Z
    printf("NewCamera_IngameSelfieSubsystem_Drone:SetDroneControlMode -> LockTarget camPosBefore=(%.1f,%.1f,%.1f) camPosAfter=(%.1f,%.1f,%.1f) rotBefore=(%.1f,%.1f,%.1f) rotAfter=(%.1f,%.1f,%.1f) aimPointZ=%.1f camZ=%.1f deltaZ=%.1f", camPos.X, camPos.Y, camPos.Z, afterPos and afterPos.X or 0, afterPos and afterPos.Y or 0, afterPos and afterPos.Z or 0, camRotBefore and camRotBefore.Pitch or 0, camRotBefore and camRotBefore.Yaw or 0, camRotBefore and camRotBefore.Roll or 0, afterRot and afterRot.Pitch or 0, afterRot and afterRot.Yaw or 0, afterRot and afterRot.Roll or 0, charPos.Z, camPos.Z, aimDeltaZ)
  else
    local charPos = playerCharacter:K2_GetActorLocation()
    local lookRot = UKismetMathLibrary.FindLookAtRotation(camPos, charPos)
    self.dronePawn:K2_SetActorLocation(camPos, false, nil, false)
    self.dronePawn:K2_SetActorRotation(lookRot, false)
    self:_ApplyDroneArmLength(NewCameraConfig.CDroneFreeArmLength, true)
    self.dronePawn:SetArmLengthAdaptive(true)
    local camera = self.dronePawn:GetCamera()
    if slua.isValid(camera) then
      local camRot = camera.RelativeRotation
      camera:K2_SetRelativeRotation(FRotator(0, 0, camRot.Roll), false, nil, false)
    end
    local afterPos = self.dronePawn:GetCameraWorldLocation()
    local afterRot = self.dronePawn:GetCameraWorldRotation()
    printf("NewCamera_IngameSelfieSubsystem_Drone:SetDroneControlMode -> FreeMove camPosBefore=(%.1f,%.1f,%.1f) camPosAfter=(%.1f,%.1f,%.1f) rotBefore=(%.1f,%.1f,%.1f) rotAfter=(%.1f,%.1f,%.1f)", camPos.X, camPos.Y, camPos.Z, afterPos and afterPos.X or 0, afterPos and afterPos.Y or 0, afterPos and afterPos.Z or 0, camRotBefore and camRotBefore.Pitch or 0, camRotBefore and camRotBefore.Yaw or 0, camRotBefore and camRotBefore.Roll or 0, afterRot and afterRot.Pitch or 0, afterRot and afterRot.Yaw or 0, afterRot and afterRot.Roll or 0)
  end
end

function NewCamera_IngameSelfieSubsystem_Drone:ResetDroneRotation()
  if not slua.isValid(self.dronePawn) then
    return
  end
  if self:IsDroneLockMode() then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:ResetDroneRotation skip in lock mode")
    return
  end
  self.dronePawn:ResetRotation()
end

function NewCamera_IngameSelfieSubsystem_Drone:SetDroneFOVRatio(ratio)
  if not slua.isValid(self.dronePawn) then
    return
  end
  local baseFocal = self._droneBaseFocalLength
  if not baseFocal or baseFocal <= 0 then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:SetDroneFOVRatio no base focal length")
    return
  end
  if not ratio or ratio <= 0 then
    return
  end
  local focal = baseFocal / ratio
  self.dronePawn:SetCameraFocalLength(focal)
end

function NewCamera_IngameSelfieSubsystem_Drone:GetDroneBaseFocalLength()
  return self._droneBaseFocalLength
end

function NewCamera_IngameSelfieSubsystem_Drone:RotateDroneView(yawDelta, pitchDelta)
  if not slua.isValid(self.dronePawn) then
    return
  end
  self.dronePawn:AddDroneRotation(yawDelta, pitchDelta)
end

function NewCamera_IngameSelfieSubsystem_Drone:OnLockModeJoystickInput(input)
  if not input or not slua.isValid(self.dronePawn) then
    return
  end
  local now = GameplayStatics.GetTimeSeconds(CGameWorld) or 0
  local dt = now - (self._lastLockJoystickTime or now)
  self._lastLockJoystickTime = now
  dt = math.max(0, math.min(dt, 0.1))
  if dt <= 0 then
    return
  end
  local rateX = input.X or 0
  rateX = rateX * -1
  local rateY = input.Y or 0
  if rateX ~= 0 and self:CanApplyDroneYaw("left") then
    self:RotateDroneView(rateX * NewCameraConfig.CDroneJoyStickRotateSpeed * dt, 0)
  end
  if rateY ~= 0 then
    self.dronePawn:_ApplyLockArmLengthDelta(rateY * NewCameraConfig.CDroneArmLengthSpeed * dt)
  end
end

function NewCamera_IngameSelfieSubsystem_Drone:ResetLockJoystickTimeBase()
  self._lastLockJoystickTime = nil
end

function NewCamera_IngameSelfieSubsystem_Drone:ClaimDroneYawOwner(owner)
  self._droneYawOwner = owner
end

function NewCamera_IngameSelfieSubsystem_Drone:ReleaseDroneYawOwner(owner)
  if self._droneYawOwner == owner then
    self._droneYawOwner = nil
  end
end

function NewCamera_IngameSelfieSubsystem_Drone:CanApplyDroneYaw(owner)
  return self._droneYawOwner == nil or self._droneYawOwner == owner
end

function NewCamera_IngameSelfieSubsystem_Drone:StopDroneMove()
  if slua.isValid(self.dronePawn) then
    self.dronePawn:SetMoveInput(0, 0)
  end
  local UCircleMoveUserWidget = import("CircleMoveUserWidget")
  if UCircleMoveUserWidget and UCircleMoveUserWidget.InjectLeftStickAxis then
    UCircleMoveUserWidget.InjectLeftStickAxis(FVector2D(0, 0))
  end
end

local DroneUnbindCheckInterval = 0.02
local DroneUnbindMaxSeconds = 0.25

function NewCamera_IngameSelfieSubsystem_Drone:_GetInjectedAxisMagnitude()
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerController) or not playerController.GetInputAnalogKeyState then
    return 0
  end
  if not self._axisKeyCache then
    self._axisKeyCache = import("/Script/InputCore.Key")()
  end
  local maxAbs = 0
  for _, keyName in ipairs({
    "Gamepad_LeftStick_Right",
    "Gamepad_LeftStick_Up"
  }) do
    self._axisKeyCache.KeyName = keyName
    local value = playerController:GetInputAnalogKeyState(self._axisKeyCache)
    if value then
      maxAbs = math.max(maxAbs, math.abs(value))
    end
  end
  return maxAbs
end

function NewCamera_IngameSelfieSubsystem_Drone:_UnbindMoveDelegateAfterAxisCleared()
  if self._unbindMoveDelegateTimer then
    self:RemoveGameTimer(self._unbindMoveDelegateTimer)
    self._unbindMoveDelegateTimer = nil
  end
  self._unbindMoveDelegateElapsed = 0
  
  local function FinishUnbind()
    self:RemoveGameTimer(self._unbindMoveDelegateTimer)
    self._unbindMoveDelegateTimer = nil
    if self.bInDroneMode then
      printf("NewCameraDrone [MoveResidueDbg] unbindMoveDelegate skipped, back in drone mode")
      return
    end
    local playerController = GameplayData.GetPlayerController()
    if slua.isValid(playerController) then
      self:RemoveControlEvent(playerController, "MoveForwardDelegate")
      self:RemoveControlEvent(playerController, "MoveRightDelegate")
      self:TryBanPlayerMoveDelegate()
    end
    NewCameraUtil.ClearPendingMoveInputResidue()
    printf("NewCameraDrone [MoveResidueDbg] unbindMoveDelegate done, axisMagnitude:%.3f, elapsed:%.2f", self:_GetInjectedAxisMagnitude(), self._unbindMoveDelegateElapsed)
  end
  
  self._unbindMoveDelegateTimer = self:AddGameTimer(DroneUnbindCheckInterval, true, function()
    self._unbindMoveDelegateElapsed = (self._unbindMoveDelegateElapsed or 0) + DroneUnbindCheckInterval
    NewCameraUtil.ClearPendingMoveInputResidue()
    if self:_GetInjectedAxisMagnitude() <= 0.001 then
      FinishUnbind()
      return
    end
    if self._unbindMoveDelegateElapsed >= DroneUnbindMaxSeconds then
      FinishUnbind()
    end
  end)
end

function NewCamera_IngameSelfieSubsystem_Drone:PinchDroneArm(scaleDelta)
  if not slua.isValid(self.dronePawn) then
    return
  end
  local realScale = scaleDelta - 1
  self._dronePinchThresholdCount = self._dronePinchThresholdCount + math.abs(realScale)
  if self._dronePinchThresholdCount < (self._dronePinchThreshold or 0.15) then
    return
  end
  self:AddDroneArmLength(realScale * (self._dronePinchRate or 1))
end

function NewCamera_IngameSelfieSubsystem_Drone:PinchDroneArmEnd()
  self._dronePinchThresholdCount = 0
end

function NewCamera_IngameSelfieSubsystem_Drone:AddDroneArmLength(delta)
  if not slua.isValid(self.dronePawn) then
    return
  end
  local range = NewCameraConfig.CDroneLockArmLengthRange
  local newArm = (self._droneArmLength or range.Min) + (delta or 0)
  self:_ApplyDroneArmLength(newArm)
end

function NewCamera_IngameSelfieSubsystem_Drone:SetDroneArmLength(armLength)
  if not slua.isValid(self.dronePawn) then
    return
  end
  self:_ApplyDroneArmLength(armLength or 0)
end

function NewCamera_IngameSelfieSubsystem_Drone:GetDroneArmLength()
  return self._droneArmLength or NewCameraConfig.CDroneLockArmLengthRange.Min
end

function NewCamera_IngameSelfieSubsystem_Drone:_ApplyDroneArmLength(newArm, bForce)
  if not slua.isValid(self.dronePawn) then
    return
  end
  if self:IsDroneLockMode() then
    local range = NewCameraConfig.CDroneLockArmLengthRange
    newArm = math.max(range.Min, math.min(range.Max, newArm))
  else
    newArm = NewCameraConfig.CDroneFreeArmLength
  end
  if not bForce and math.abs(newArm - (self._droneArmLength or -1)) < 0.01 then
    return
  end
  self._droneArmLength = newArm
  self.dronePawn:SetTargetArmLength(newArm)
  EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_DRONE_ARM_CHANGED, newArm)
end

function NewCamera_IngameSelfieSubsystem_Drone:IsInDroneMode()
  return self.bInDroneMode == true
end

function NewCamera_IngameSelfieSubsystem_Drone:GetCameraRecordList()
  return self._cameraRecordData
end

function NewCamera_IngameSelfieSubsystem_Drone:GetCameraRecordByIndex(index)
  return self._cameraRecordData[index]
end

function NewCamera_IngameSelfieSubsystem_Drone:StartCameraRecord()
  local recordData = TableUtil.FastCopyTable(NewCameraConfig.SCamera_Record)
  recordData.id = NewCameraConfig.CCameraRecordTemplateID
  recordData.keyframes = {}
  self._curRecordData = recordData
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:StartCameraRecord done")
end

function NewCamera_IngameSelfieSubsystem_Drone:StartDroneRecord()
  if self.bIsRecordingDrone then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:StartDroneRecord already recording")
    return
  end
  self:StartCameraRecord()
  self.bIsRecordingDrone = true
  NewCameraTLogReport.ReportDroneRecordStart()
  self._droneRecordStartTime = GameplayStatics.GetTimeSeconds(CGameWorld)
  self._droneRecordFrameCount = 0
  self._lastRecordPos = nil
  self._lastRecordRot = nil
  self._recUnwrapRot = nil
  self._lastRecordFocalLength = nil
  self:AddDroneRecordFrame(true)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:StartDroneRecord done")
end

function NewCamera_IngameSelfieSubsystem_Drone:AddDroneRecordFrame(bForceWriteAll)
  if not self.bIsRecordingDrone or not self._curRecordData then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:AddDroneRecordFrame not recording")
    return
  end
  if not slua.isValid(self.dronePawn) then
    return
  end
  local time = GameplayStatics.GetTimeSeconds(CGameWorld) - self._droneRecordStartTime
  local bForceWrite = bForceWriteAll or self._droneRecordFrameCount == 0
  local camera = self.dronePawn:GetCamera()
  if not slua.isValid(camera) then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:AddDroneRecordFrame camera invalid")
    return
  end
  local worldPos = camera:K2_GetComponentLocation()
  local worldRot = camera:K2_GetComponentRotation()
  local relPos, relRot = self:_WorldToMountLocal(worldPos, worldRot)
  local recRot = self:_UnwrapRecordRot(relRot)
  local keyframe = self:_GetRecordKeyframe(time)
  if not keyframe then
    return
  end
  keyframe.time = time
  local bWrotePos = false
  local bWroteRot = false
  local bWroteFocalLength = false
  if bForceWrite or not self._lastRecordPos then
    keyframe.position = relPos
    bWrotePos = true
  elseif relPos.x ~= self._lastRecordPos.x or relPos.y ~= self._lastRecordPos.y or relPos.z ~= self._lastRecordPos.z then
    keyframe.position = relPos
    bWrotePos = true
  end
  if bForceWrite or not self._lastRecordRot then
    keyframe.rotation = recRot
    bWroteRot = true
  elseif recRot.pitch ~= self._lastRecordRot.pitch or recRot.yaw ~= self._lastRecordRot.yaw or recRot.roll ~= self._lastRecordRot.roll then
    keyframe.rotation = recRot
    bWroteRot = true
  end
  local focalLength = camera.CurrentFocalLength or 0
  if bForceWrite or not self._lastRecordFocalLength then
    keyframe.focalLength = focalLength
    bWroteFocalLength = true
  elseif focalLength ~= self._lastRecordFocalLength then
    keyframe.focalLength = focalLength
    bWroteFocalLength = true
  end
  if bWrotePos then
    self._lastRecordPos = {
      x = relPos.x,
      y = relPos.y,
      z = relPos.z
    }
  end
  if bWroteRot then
    self._lastRecordRot = {
      pitch = recRot.pitch,
      yaw = recRot.yaw,
      roll = recRot.roll
    }
  end
  if bWroteFocalLength then
    self._lastRecordFocalLength = focalLength
  end
  self._droneRecordFrameCount = self._droneRecordFrameCount + 1
  if NewCameraConfig.CDroneRecordRotDebug then
    printf("NewCamera_IngameSelfieSubsystem_Drone:AddDroneRecordFrame time=%.2f tiltRate=%.2f worldRot=(%.2f,%.2f,%.2f) relRot=(%.2f,%.2f,%.2f) writeRot=(%.2f,%.2f,%.2f) wroteRot=%s", time, self.dronePawn and (self.dronePawn.tiltRate or 0) or 0, worldRot.Pitch, worldRot.Yaw, worldRot.Roll, relRot.pitch, relRot.yaw, relRot.roll, recRot.pitch, recRot.yaw, recRot.roll, tostring(bWroteRot))
  end
end

function NewCamera_IngameSelfieSubsystem_Drone:FinishDroneRecord()
  if not self.bIsRecordingDrone or not self._curRecordData then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:FinishDroneRecord not recording")
    return nil
  end
  self:AddDroneRecordFrame(true)
  local duration = GameplayStatics.GetTimeSeconds(CGameWorld) - self._droneRecordStartTime
  self._curRecordData.duration = duration
  local rawFrames = self._curRecordData.keyframes
  local compressed = NewCamera_CameraRecordCompress.Compress(rawFrames, {
    posTolerance = NewCameraConfig.CCameraRecordCompressPosTolerance,
    rotTolerance = NewCameraConfig.CCameraRecordCompressRotTolerance,
    focalTolerance = NewCameraConfig.CCameraRecordCompressFocalTolerance,
    maxRotStepDeg = NewCameraConfig.CCameraRecordMaxRotStepDeg
  })
  self._curRecordData.keyframes = NewCamera_CameraRecordCompress.RoundValues(compressed)
  local newStr = self:EncodeCameraRecordMotion(self._curRecordData)
  local newSize = newStr and #newStr or 0
  log(bWriteLog and string.format("NewCamera_IngameSelfieSubsystem_Drone:FinishDroneRecord compress keyframes %d->%d size=%d", #rawFrames, #self._curRecordData.keyframes, newSize))
  NewCameraTLogReport.ReportDroneRecordFinish(duration, #rawFrames, newSize / 1024)
  self.bIsRecordingDrone = false
  self._lastRecordPos = nil
  self._lastRecordRot = nil
  self._recUnwrapRot = nil
  self._lastRecordFocalLength = nil
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:FinishDroneRecord done duration=" .. tostring(duration))
  UIManager.ShowUI(UIManager.UI_Config_InGame.NewCamera_Photo_CameraRecord_Preview_UIBP, self._curRecordData)
  self._curRecordData = nil
end

function NewCamera_IngameSelfieSubsystem_Drone:CancelDroneRecord()
  if not self.bIsRecordingDrone then
    return false
  end
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:CancelDroneRecord")
  self.bIsRecordingDrone = false
  self._curRecordData = nil
  self._lastRecordPos = nil
  self._lastRecordRot = nil
  self._recUnwrapRot = nil
  self._lastRecordFocalLength = nil
  return true
end

function NewCamera_IngameSelfieSubsystem_Drone:PlayCameraRecord(templateID, recordData)
  if not templateID then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:PlayCameraRecord templateID is nil")
    return
  end
  if self:IsInDroneMode() then
    self:StopDroneControl()
  end
  self:StartSmartCamera(true, templateID, {recordData = recordData})
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:PlayCameraRecord done")
end

function NewCamera_IngameSelfieSubsystem_Drone:PauseCameraRecordPreview()
  local player = self:GetCameraRecordSequencePlayer()
  if not slua.isValid(player) then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:PauseCameraRecordPreview player invalid")
    return
  end
  local bPauseOk, pauseErr = pcall(function()
    player:Pause()
  end)
  if not bPauseOk then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:PauseCameraRecordPreview pause failed err=" .. tostring(pauseErr))
  end
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:PauseCameraRecordPreview done")
end

function NewCamera_IngameSelfieSubsystem_Drone:ResumeCameraRecordPreview()
  local player = self:GetCameraRecordSequencePlayer()
  if not slua.isValid(player) then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:ResumeCameraRecordPreview player invalid")
    return
  end
  local bPlayOk, playErr = pcall(function()
    player:Play()
  end)
  if not bPlayOk then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:ResumeCameraRecordPreview play failed err=" .. tostring(playErr))
  end
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:ResumeCameraRecordPreview done")
end

function NewCamera_IngameSelfieSubsystem_Drone:StopCameraRecordPreview()
  local PhotoGrapherSubSystem = SubsystemMgr:Get("PhotoGrapherSubSystem")
  if not PhotoGrapherSubSystem then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:StopCameraRecordPreview PhotoGrapherSubSystem nil")
    return
  end
  PhotoGrapherSubSystem:StopSmartCamera()
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:StopCameraRecordPreview done")
end

function NewCamera_IngameSelfieSubsystem_Drone:GetCameraRecordSequencePlayer()
  local PhotoGrapherSubSystem = SubsystemMgr:Get("PhotoGrapherSubSystem")
  if not PhotoGrapherSubSystem then
    return nil
  end
  local modifier = PhotoGrapherSubSystem:GetPhotographerCameraModifier()
  if not slua.isValid(modifier) then
    return nil
  end
  local seqActor = modifier.CamMasterSeuqenceActor
  if not slua.isValid(seqActor) then
    return nil
  end
  local player = seqActor.SequencePlayer
  if not slua.isValid(player) then
    return nil
  end
  return player
end

function NewCamera_IngameSelfieSubsystem_Drone:ReenterDroneForRecord()
  if self:IsInDroneMode() then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:ReenterDroneForRecord already in drone mode")
    return
  end
  self:StartDroneControl()
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:ReenterDroneForRecord done")
end

function NewCamera_IngameSelfieSubsystem_Drone:PreSaveCameraRecord(recordData)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:PreSaveCameraRecord")
  UIManager.ShowUI(UIManager.UI_Config_InGame.NewCamera_Photo_CameraRecord_Save_UIBP, recordData)
end

function NewCamera_IngameSelfieSubsystem_Drone:GetCameraRecordMotionSize(motionStr)
  local size = type(motionStr) == "string" and #motionStr or 0
  local limit = NewCameraConfig.CCameraRecordSchemeMaxSize
  return size, limit, size > limit
end

function NewCamera_IngameSelfieSubsystem_Drone:EncodeCameraRecordMotion(recordData)
  if not recordData then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:EncodeCameraRecordMotion recordData is nil")
    return nil
  end
  local rows = {}
  for i, kf in ipairs(recordData.keyframes or {}) do
    local pos = kf.position or {}
    local rot = kf.rotation or {}
    rows[i] = {
      kf.time or 0,
      pos.x or 0,
      pos.y or 0,
      pos.z or 0,
      rot.pitch or 0,
      rot.yaw or 0,
      rot.roll or 0,
      kf.focalLength or 0
    }
  end
  local saveStruct = {
    duration = recordData.duration or 0,
    k = rows
  }
  return json.encode(saveStruct)
end

function NewCamera_IngameSelfieSubsystem_Drone:GetCameraRecordSchemeMaxNum()
  return NewCameraConfig.CCameraRecordSchemeMaxCount
end

function NewCamera_IngameSelfieSubsystem_Drone:TrySaveCameraRecord(name, recordData)
  local len = #self._cameraRecordData
  local maxNum = self:GetCameraRecordSchemeMaxNum()
  if len < maxNum then
    self:SaveCameraRecord(name, recordData, nil)
    return
  end
  UIManager.ShowUI(UIManager.UI_Config_InGame.NewCamera_Photo_CameraRecord_UIBP, {name = name, recordData = recordData})
end

function NewCamera_IngameSelfieSubsystem_Drone:SaveCameraRecord(name, recordData, replaceID)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:SaveCameraRecord replaceID=" .. tostring(replaceID))
  if not recordData then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:SaveCameraRecord recordData is nil")
    return
  end
  local montionStr = self:EncodeCameraRecordMotion(recordData)
  if not montionStr then
    return
  end
  local size, limit, bOverLimit = self:GetCameraRecordMotionSize(montionStr)
  if bOverLimit then
    log_warning(bWriteLog and string.format("NewCamera_IngameSelfieSubsystem_Drone:SaveCameraRecord over limit size=%d limit=%d, try downgrade", size, limit))
    local frames, newSize, bOK = NewCamera_CameraRecordCompress.CompressToFit(recordData.keyframes, function(kfs)
      local s = self:EncodeCameraRecordMotion({
        duration = recordData.duration,
        keyframes = kfs
      })
      return s and #s or 0
    end, limit, {
      posTolerance = NewCameraConfig.CCameraRecordCompressPosTolerance,
      rotTolerance = NewCameraConfig.CCameraRecordCompressRotTolerance,
      focalTolerance = NewCameraConfig.CCameraRecordCompressFocalTolerance,
      maxRotStepDeg = NewCameraConfig.CCameraRecordMaxRotStepDeg
    })
    if not bOK then
      ShowNotice(468890240)
      log_warning(bWriteLog and string.format("NewCamera_IngameSelfieSubsystem_Drone:SaveCameraRecord rejected, size=%d limit=%d frames=%d", newSize, limit, frames and #frames or 0))
      return
    end
    recordData.keyframes = frames
    montionStr = self:EncodeCameraRecordMotion(recordData)
    size = newSize
    log(bWriteLog and string.format("NewCamera_IngameSelfieSubsystem_Drone:SaveCameraRecord downgraded ok size=%d limit=%d frames=%d", size, limit, #frames))
  else
    log(bWriteLog and string.format("NewCamera_IngameSelfieSubsystem_Drone:SaveCameraRecord motionStr size=%d limit=%d", size, limit))
  end
  if not self:CheckRecCameraWriteInterval() then
    return
  end
  NewCameraTLogReport.ReportDroneTemplateSave(name, recordData.duration, #recordData.keyframes, size / 1024)
  local IngameSelfieHandler = require("client.network.Protocol.IngameSelfieHandler")
  if replaceID then
    self._pendingCameraRecordOp = {context = "replace", schemeID = replaceID}
    self:MarkPendingSchemeRecord()
    IngameSelfieHandler.send_update_rec_camera_scheme_req(ESchemeType.Record, replaceID, name, montionStr)
  else
    self._pendingCameraRecordOp = {context = "save"}
    self:MarkPendingSchemeRecord()
    IngameSelfieHandler.send_save_rec_camera_scheme_req(ESchemeType.Record, name, montionStr)
  end
end

function NewCamera_IngameSelfieSubsystem_Drone:OnPreDeleteCameraRecord(idList)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:OnPreDeleteCameraRecord count=" .. tostring(idList and #idList or 0))
  if not idList or #idList == 0 then
    return
  end
  if not self:CheckRecCameraWriteInterval() then
    return
  end
  if #idList == 1 then
    NewCameraTLogReport.ReportDroneTemplateDelete(idList[1])
  else
    NewCameraTLogReport.ReportDroneTemplateBatchDelete(idList)
  end
  self._pendingCameraRecordOp = {context = "delete"}
  self:MarkPendingSchemeRecord()
  local IngameSelfieHandler = require("client.network.Protocol.IngameSelfieHandler")
  IngameSelfieHandler.send_delete_rec_camera_scheme_req(ESchemeType.Record, idList)
end

function NewCamera_IngameSelfieSubsystem_Drone:ChangeCameraRecordName(schemeID, name)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:ChangeCameraRecordName schemeID=" .. tostring(schemeID))
  if not (schemeID and name) or name == "" then
    return
  end
  if not self:CheckRecCameraWriteInterval() then
    return
  end
  local oldTemplate = self:_FindCameraRecordTemplate(schemeID)
  local oldName = oldTemplate and oldTemplate.name or ""
  if oldName == name then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:ChangeCameraRecordName name not changed")
    return
  end
  NewCameraTLogReport.ReportDroneTemplateChangeName(schemeID, oldTemplate and oldTemplate.name or "", name)
  self._pendingCameraRecordOp = {context = "update", schemeID = schemeID}
  self:MarkPendingSchemeRecord()
  local IngameSelfieHandler = require("client.network.Protocol.IngameSelfieHandler")
  IngameSelfieHandler.send_update_rec_camera_scheme_req(ESchemeType.Record, schemeID, name, nil)
end

function NewCamera_IngameSelfieSubsystem_Drone:RequestCameraRecordList()
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:RequestCameraRecordList")
  self._pendingCameraRecordOp = {context = "get"}
  self:MarkPendingSchemeRecord()
  local IngameSelfieHandler = require("client.network.Protocol.IngameSelfieHandler")
  IngameSelfieHandler.send_get_rec_camera_scheme_req(ESchemeType.Record)
end

function NewCamera_IngameSelfieSubsystem_Drone:_RebuildCameraRecordTemplateData(schemes)
  local list = {}
  if not schemes then
    self._cameraRecordData = list
    return
  end
  for _, scheme in pairs(schemes) do
    if scheme and scheme.id then
      local decoded = scheme.motion_data and NewCamera_CameraRecordCompress.Decode(scheme.motion_data) or nil
      local recordData = TableUtil.FastCopyTable(NewCameraConfig.SCamera_Record)
      recordData.id = NewCameraConfig.CCameraRecordTemplateID
      recordData.recordID = scheme.id
      recordData.name = scheme.name or ""
      recordData.duration = decoded and decoded.duration or 0
      recordData.keyframes = decoded and decoded.keyframes or {}
      table.insert(list, recordData)
    end
  end
  self._cameraRecordData = list
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:_RebuildCameraRecordTemplateData count=" .. tostring(#list))
end

function NewCamera_IngameSelfieSubsystem_Drone:_FindCameraRecordTemplate(schemeID)
  for _, v in ipairs(self._cameraRecordData or {}) do
    if v.recordID == schemeID then
      return v
    end
  end
  return nil
end

function NewCamera_IngameSelfieSubsystem_Drone:OnCameraRecordSchemeSaveRsp(err_code, scheme_id, all_schemes)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:OnCameraRecordSchemeSaveRsp err_code=" .. tostring(err_code))
  self._pendingCameraRecordOp = nil
  if err_code and 0 < err_code then
    NewCameraUtil.HandleProtocolError(err_code)
    return
  end
  self:_RebuildCameraRecordTemplateData(all_schemes)
  ShowNotice(NewCameraConfig.CCameraRecordNoticeID.Save)
  EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_ON_CAMERA_RECORD_SAVE, scheme_id)
end

function NewCamera_IngameSelfieSubsystem_Drone:OnCameraRecordSchemeUpdateRsp(err_code, all_schemes)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:OnCameraRecordSchemeUpdateRsp err_code=" .. tostring(err_code))
  local pending = self._pendingCameraRecordOp
  self._pendingCameraRecordOp = nil
  if err_code and 0 < err_code then
    NewCameraUtil.HandleProtocolError(err_code)
    return
  end
  self:_RebuildCameraRecordTemplateData(all_schemes)
  if pending and pending.context == "replace" then
    ShowNotice(NewCameraConfig.CCameraRecordNoticeID.Replace)
    EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_ON_CAMERA_RECORD_SAVE, pending.schemeID)
  else
    ShowNotice(NewCameraConfig.CCameraRecordNoticeID.NameChange)
    EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_ON_CAMERA_RECORD_NAME_CHANGE, pending and pending.schemeID)
  end
end

function NewCamera_IngameSelfieSubsystem_Drone:OnCameraRecordSchemeDeleteRsp(err_code, all_schemes)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:OnCameraRecordSchemeDeleteRsp err_code=" .. tostring(err_code))
  self._pendingCameraRecordOp = nil
  if err_code and 0 < err_code then
    NewCameraUtil.HandleProtocolError(err_code)
    return
  end
  self:_RebuildCameraRecordTemplateData(all_schemes)
  ShowNotice(NewCameraConfig.CCameraRecordNoticeID.Delete)
  EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_ON_CAMERA_RECORD_DELETE)
end

function NewCamera_IngameSelfieSubsystem_Drone:OnCameraRecordSchemeGetRsp(err_code, schemes)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem_Drone:OnCameraRecordSchemeGetRsp err_code=" .. tostring(err_code))
  self._pendingCameraRecordOp = nil
  if err_code and 0 < err_code then
    NewCameraUtil.HandleProtocolError(err_code)
    return
  end
  self:_RebuildCameraRecordTemplateData(schemes)
end

function NewCamera_IngameSelfieSubsystem_Drone:_WorldToMountLocal(worldPos, worldRot)
  local playerCharacter = GameplayData.GetPlayerCharacter()
  if not slua.isValid(playerCharacter) then
    return {
      x = worldPos.X,
      y = worldPos.Y,
      z = worldPos.Z
    }, {
      pitch = worldRot.Pitch,
      yaw = worldRot.Yaw,
      roll = worldRot.Roll
    }
  end
  local mountOffset = NewCameraConfig.CCameraRecordMountOffset
  local mountRot = NewCameraConfig.CCameraRecordMountRotation
  local actorTransform = playerCharacter:GetTransform()
  local actorLocalPos = KismetMathLibrary.InverseTransformLocation(actorTransform, worldPos)
  local mountLocalTransform = KismetMathLibrary.MakeTransform(FVector(mountOffset.x, mountOffset.y, mountOffset.z), FRotator(mountRot.pitch, mountRot.yaw, mountRot.roll), FVector(1, 1, 1))
  local relPosVec = KismetMathLibrary.InverseTransformLocation(mountLocalTransform, actorLocalPos)
  local charRot = playerCharacter:K2_GetActorRotation()
  local charMountRot = KismetMathLibrary.ComposeRotators(charRot, FRotator(mountRot.pitch, mountRot.yaw, mountRot.roll))
  local keyRot = FRotator(worldRot.Roll, worldRot.Pitch, worldRot.Yaw - charMountRot.Yaw)
  return {
    x = relPosVec.X,
    y = relPosVec.Y,
    z = relPosVec.Z
  }, {
    pitch = keyRot.Pitch,
    yaw = keyRot.Yaw,
    roll = keyRot.Roll
  }
end

function NewCamera_IngameSelfieSubsystem_Drone:_UnwrapRecordRot(relRot)
  local prev = self._recUnwrapRot
  if not prev then
    self._recUnwrapRot = {
      pitch = relRot.pitch,
      yaw = relRot.yaw,
      roll = relRot.roll
    }
    return relRot
  end
  local cur = {
    pitch = prev.pitch + _AngleDelta(relRot.pitch, prev.pitch),
    yaw = prev.yaw + _AngleDelta(relRot.yaw, prev.yaw),
    roll = prev.roll + _AngleDelta(relRot.roll, prev.roll)
  }
  self._recUnwrapRot = cur
  return cur
end

function NewCamera_IngameSelfieSubsystem_Drone:_GetRecordKeyframe(time)
  if not self._curRecordData then
    return nil
  end
  for _, keyframe in ipairs(self._curRecordData.keyframes) do
    if keyframe.time == time then
      return keyframe
    end
  end
  local keyframe = TableUtil.FastCopyTable(NewCameraConfig.SCamera_Record_Keyframe)
  keyframe.time = time
  table.insert(self._curRecordData.keyframes, keyframe)
  return keyframe
end

function NewCamera_IngameSelfieSubsystem_Drone:RecordLocation(time, location)
  local keyframe = self:_GetRecordKeyframe(time)
  if not keyframe then
    return
  end
  keyframe.position = {
    x = location.X,
    y = location.Y,
    z = location.Z
  }
end

function NewCamera_IngameSelfieSubsystem_Drone:RecordRotation(time, rotation)
  local keyframe = self:_GetRecordKeyframe(time)
  if not keyframe then
    return
  end
  keyframe.rotation = {
    pitch = rotation.Pitch,
    yaw = rotation.Yaw,
    roll = rotation.Roll
  }
end

function NewCamera_IngameSelfieSubsystem_Drone:RecordFocalLength(time, focalLength)
  local keyframe = self:_GetRecordKeyframe(time)
  if not keyframe then
    return
  end
  keyframe.focalLength = focalLength
end

return NewCamera_IngameSelfieSubsystem_Drone
