local ExecuteSeqActor = {}

function ExecuteSeqActor:ctor()
  ExecuteSeqActor.__super.ctor(self)
  self.bBeginPlayReady = false
  self.bInitailizeReady = false
  self.bPlayed = false
end

function ExecuteSeqActor:ReceiveBeginPlay()
  ExecuteSeqActor.__super.ReceiveBeginPlay(self)
  self.bBeginPlayReady = true
  print(bWriteLog and "ExecuteSeqActor:ReceiveBeginPlay")
  self:_TryPlay()
end

function ExecuteSeqActor:ReceiveInitailizePlayer()
  ExecuteSeqActor.__super.ReceiveInitailizePlayer(self)
  self.bInitailizeReady = true
  print(bWriteLog and "ExecuteSeqActor:ReceiveInitailizePlayer")
  self:_TryPlay()
end

function ExecuteSeqActor:_TryPlay()
  if self.bPlayed then
    return
  end
  if not self.bBeginPlayReady or not self.bInitailizeReady then
    return
  end
  self.bPlayed = true
  if self.UpdateTrackBindingData then
    self:UpdateTrackBindingData()
  end
  print(bWriteLog and "ExecuteSeqActor:_TryPlay -> Play(0)")
  self:Play(0)
end

function ExecuteSeqActor:ReceiveOnFinished()
  ExecuteSeqActor.__super.ReceiveOnFinished(self)
  print(bWriteLog and "ExecuteSeqActor:ReceiveOnFinished")
  self:_NotifyOwner("OnSeqActorFinished")
end

function ExecuteSeqActor:ReceiveOnStop()
  ExecuteSeqActor.__super.ReceiveOnStop(self)
  print(bWriteLog and "ExecuteSeqActor:ReceiveOnStop")
  self:_NotifyOwner("OnSeqActorStopped")
end

function ExecuteSeqActor:_NotifyOwner(FuncName)
  local uOwner = self:GetOwner()
  if not slua.isValid(uOwner) then
    return
  end
  if uOwner[FuncName] then
    uOwner[FuncName](uOwner)
  end
end

local CLONE_SLOT_ANIM_SLOT_NAME = "DefaultSlot"
local CLONE_SLOT_ANIM_BLEND_TIME = 0.1

function ExecuteSeqActor:PlayCloneSlotAnim(sSlotType, sAnimPath)
  if not sAnimPath or sAnimPath == "" then
    log(bWriteLog and "ExecuteSeqActor:PlayCloneSlotAnim empty AnimPath")
    return
  end
  local nSlotID = tonumber(sSlotType)
  if not nSlotID then
    log_warning(bWriteLog and string.format("ExecuteSeqActor:PlayCloneSlotAnim invalid SlotType:%s", tostring(sSlotType)))
    return
  end
  local Req = {
    SlotID = nSlotID,
    AnimPath = sAnimPath,
    AnchorSeqPos = self:_GetSequencePosition()
  }
  self:AsyncLoadAsset(sAnimPath, function(uAnimAsset)
    if not slua.isValid(self.Object) then
      return
    end
    if not slua.isValid(uAnimAsset) then
      log_error(bWriteLog and string.format("ExecuteSeqActor:PlayCloneSlotAnim async load failed:%s", sAnimPath))
      return
    end
    Req.AnimAsset = uAnimAsset
    if self:_TryPlayCloneSlotAnim(Req) then
      return
    end
    self.PendingCloneSlotAnims = self.PendingCloneSlotAnims or {}
    self.PendingCloneSlotAnims[nSlotID] = Req
    self:_StartPendingSlotAnimRetryTimer()
    printf("ExecuteSeqActor:PlayCloneSlotAnim SlotID:%d asset ready, mesh pending", nSlotID)
  end)
end

function ExecuteSeqActor:_StartPendingSlotAnimRetryTimer()
  if self.PendingSlotAnimRetryTimer then
    return
  end
  self.PendingSlotAnimRetryCount = 0
  self.PendingSlotAnimRetryTimer = self:AddGameTimer(0.1, true, function()
    self.PendingSlotAnimRetryCount = self.PendingSlotAnimRetryCount + 1
    self:_FlushPendingCloneSlotAnims()
    if not self.PendingCloneSlotAnims or next(self.PendingCloneSlotAnims) == nil or self.PendingSlotAnimRetryCount >= 30 then
      self:_StopPendingSlotAnimRetryTimer()
    end
  end)
end

function ExecuteSeqActor:_StopPendingSlotAnimRetryTimer()
  if self.PendingSlotAnimRetryTimer then
    self:RemoveGameTimer(self.PendingSlotAnimRetryTimer)
    self.PendingSlotAnimRetryTimer = nil
  end
end

function ExecuteSeqActor:_GetSequencePosition()
  if slua.isValid(self.SequencePlayer) then
    return self.SequencePlayer:GetPlaybackPosition() or 0
  end
  return 0
end

function ExecuteSeqActor:_GetExecutorClone()
  local uBizActor = self:GetOwner()
  if not slua.isValid(uBizActor) then
    return nil
  end
  return uBizActor.ExecutorClone
end

function ExecuteSeqActor:_TryPlayCloneSlotAnim(Req)
  local uClonePawn = self:_GetExecutorClone()
  if not slua.isValid(uClonePawn) then
    return true
  end
  local uAvatarComp = uClonePawn.CharacterAvatarComp2_BP
  if not slua.isValid(uAvatarComp) then
    return false
  end
  local uMeshComp = uAvatarComp:GetMeshCompBySlotID(Req.SlotID)
  if not slua.isValid(uMeshComp) then
    return false
  end
  local uAnimInstance = uMeshComp:GetAnimInstance()
  if not slua.isValid(uAnimInstance) then
    return false
  end
  local uAnimAsset = Req.AnimAsset
  if not slua.isValid(uAnimAsset) then
    return false
  end
  pcall(function()
    uAnimInstance:StopSlotAnimation(0.0, CLONE_SLOT_ANIM_SLOT_NAME)
    uAnimInstance:Montage_Stop(0.0)
  end)
  local fStartPos = self:_GetSequencePosition() - Req.AnchorSeqPos
  if fStartPos < 0 then
    fStartPos = 0
  end
  local fLength = 0
  pcall(function()
    fLength = uAnimAsset:GetPlayLength() or 0
  end)
  if 0 < fLength and fStartPos > fLength then
    fStartPos = fLength
  end
  local bPlayed, uMontage = pcall(function()
    return uAnimInstance:PlaySlotAnimationAsDynamicMontage(uAnimAsset, CLONE_SLOT_ANIM_SLOT_NAME, CLONE_SLOT_ANIM_BLEND_TIME, CLONE_SLOT_ANIM_BLEND_TIME, 1.0, 1, -1.0, fStartPos)
  end)
  if bPlayed and slua.isValid(uMontage) then
    printf("ExecuteSeqActor:_TryPlayCloneSlotAnim SlotID:%d StartPos:%s Anim:%s", Req.SlotID, tostring(fStartPos), Req.AnimPath)
    self:_MarkCloneSlotAnimPlaying(Req)
    return true
  end
  local EMontagePlayReturnType = import("EMontagePlayReturnType")
  local bOk, fMontageLength = pcall(function()
    return uAnimInstance:Montage_Play(uAnimAsset, 1.0, EMontagePlayReturnType.MontageLength, fStartPos)
  end)
  if bOk and 0 < (fMontageLength or 0) then
    printf("ExecuteSeqActor:_TryPlayCloneSlotAnim Montage SlotID:%d StartPos:%s Anim:%s", Req.SlotID, tostring(fStartPos), Req.AnimPath)
    self:_MarkCloneSlotAnimPlaying(Req)
    return true
  end
  return true
end

function ExecuteSeqActor:_FlushPendingCloneSlotAnims()
  local Pending = self.PendingCloneSlotAnims
  if not Pending or next(Pending) == nil then
    return
  end
  local Remain = {}
  for nSlotID, Req in pairs(Pending) do
    if not self:_TryPlayCloneSlotAnim(Req) then
      Remain[nSlotID] = Req
    end
  end
  self.PendingCloneSlotAnims = Remain
end

function ExecuteSeqActor:_MarkCloneSlotAnimPlaying(Req)
  self.PlayingCloneSlotAnims = self.PlayingCloneSlotAnims or {}
  self.PlayingCloneSlotAnims[Req.SlotID] = Req
  self:_BindExecutorAvatarRefreshEvent()
end

function ExecuteSeqActor:_BindExecutorAvatarRefreshEvent()
  if self.bExecutorAvatarRefreshEventBound then
    return
  end
  local uClonePawn = self:_GetExecutorClone()
  if not slua.isValid(uClonePawn) then
    return
  end
  local uAvatarComp = uClonePawn.CharacterAvatarComp2_BP
  if not slua.isValid(uAvatarComp) then
    return
  end
  self.bExecutorAvatarRefreshEventBound = true
  self:AddControlEvent(uAvatarComp, "OnAvatarAllMeshLoaded", self._OnExecutorAvatarRefreshed, self)
end

function ExecuteSeqActor:_OnExecutorAvatarRefreshed()
  local Playing = self.PlayingCloneSlotAnims
  if not Playing or next(Playing) == nil then
    return
  end
  local fSeqPos = self:_GetSequencePosition()
  printf("ExecuteSeqActor:_OnExecutorAvatarRefreshed seq:%s", tostring(fSeqPos))
  for nSlotID, Req in pairs(Playing) do
    local fLength = 0
    if slua.isValid(Req.AnimAsset) then
      pcall(function()
        fLength = Req.AnimAsset:GetPlayLength() or 0
      end)
    end
    if 0 < fLength and fLength < fSeqPos - Req.AnchorSeqPos then
      Playing[nSlotID] = nil
    elseif not self:_TryPlayCloneSlotAnim(Req) then
      self.PendingCloneSlotAnims = self.PendingCloneSlotAnims or {}
      self.PendingCloneSlotAnims[nSlotID] = Req
      self:_StartPendingSlotAnimRetryTimer()
    end
  end
end

local class = require("class")
local object = require("GameLua.Mod.Library.GamePlay.Actor.UAELevelSequenceActor")
local CExecuteSeqActor = class(object, nil, ExecuteSeqActor)
return CExecuteSeqActor
