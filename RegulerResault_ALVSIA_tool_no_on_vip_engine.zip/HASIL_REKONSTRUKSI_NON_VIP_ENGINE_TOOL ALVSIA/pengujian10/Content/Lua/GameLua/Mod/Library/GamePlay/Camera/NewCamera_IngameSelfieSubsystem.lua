local NewCamera_IngameSelfieSubsystem = {}
local NewCameraConfig = require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieConfig")
local NewCamera_Photo_UIConfig = require("GameLua.Mod.Library.Client.Photo.NewCamera_Photo_UIConfig")
local NewCameraUtil = require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieUtil")
local NewCameraTest = require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieTest")
local NewCameraTLogReport = require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfie_TLog_Report")
local ShowHideUIFlag = require("GameLua.Mod.BaseMod.Client.Config.ShowHideUIFlag")
local GameplayData = require("GameLua.GameCore.Data.GameplayData")
local ETouchIndex = import("ETouchIndex")
local EPawnState = import("EPawnState")
local KismetSystemLibrary = import("KismetSystemLibrary")
local UIUtil = require("client.common.ui_util")
local InGameUITools = require("GameLua.Mod.BaseMod.Common.UI.InGameUITools")

local function RunSelfieStep(stepName, fn)
  local bOk, err = xpcall(fn, debug.traceback)
  if not bOk then
    log_error(bWriteLog and "NewCamera_IngameSelfieSubsystem:RunSelfieStep step failed, step=" .. tostring(stepName) .. ", err=" .. tostring(err))
  end
  return bOk
end

local vectorParamList = {
  "X",
  "Y",
  "Z"
}
local rotatorParamList = {
  "Pitch",
  "Yaw",
  "Roll"
}

local function getContainerParamLog(container, paramNames)
  if not container then
    return "nil"
  end
  local result = "["
  local len = #paramNames
  for index, keyName in pairs(paramNames) do
    local keyValue = container[keyName]
    result = result .. keyValue
    if index ~= len then
      result = result .. ", "
    end
  end
  result = result .. "]"
  return result
end

function NewCamera_IngameSelfieSubsystem:ctor()
  self.isInNewCamera = false
  self.entryWaitingTimer = nil
  self.curCameraMode = nil
  self.curZoom = nil
  self.isSwitchedHDRPlus = false
  self._pendingEnterHDRSwitch = false
  self.isAgreeSwitchHDRPlus = false
  self.isInSmartCamera = false
  self.stayTimeCount = 0
  self.stayTimeCountTimer = nil
  self.totalPhotoCount = 0
  self._savedCameraComp = nil
  self.touchInputHideQueue = {}
  self._touchInputRetryTimer = nil
  self.originArmLength = nil
  self.originSocketOffset = nil
  self.savedInitialArmLength = nil
  self.savedBaseRelativeRotation = nil
  self.bInDroneMode = false
  self.savedRenderQuality = nil
  self.savedRenderStyle = nil
  self.savedWeatherValue = nil
  self._lastPhotoEditClickTime = 0
  self:ctor_Drone()
  self:ctor_Emotion()
  self:ctor_Components()
  self:ctor_PostProcess()
  self:ctor_Light()
  self:ctor_XLSConfig()
  self:ctor_Net()
end

function NewCamera_IngameSelfieSubsystem:OnInit()
  NewCamera_IngameSelfieSubsystem.__super.OnInit(self)
  self:AddCommonEvent(EVENTTYPE_INGAME, EVENTID_INGAME_CONTROLLER_BEGINPLAY_FINISH, self.OnControllerBeginPlayFinish, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_INGAME_ENTER_SMART_CAMERA, self.OnEnterSmartCamera, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_INGAME_PHOTOGRAPHER_SEQ_FINISH, self.OnCameraSeqFinish, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_UI, EVENTID_NEW_EXPANDPANEL_MUTEX, self.OnExpandPanelMutex, self)
  self:AddCommonEvent(EVENTTYPE_INGAME, EVENTID_INGAME_ON_BATTLE_RESULT, self.OnBattleResult, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_ON_REFRESH_PARACHUTE_UI_STATE, self.OnRefreshParachuteUIState, self)
  GameplayData.AddSelfPlayerCharacterEventWithCondition(self, "StateEnterHandler", {
    state = {
      EPawnState.DriveVehicle,
      EPawnState.Swim,
      EPawnState.Diving,
      EPawnState.InVehicle,
      EPawnState.LeanOutVehicle
    }
  }, self.StateEnterHandler, self)
  GameplayData.AddSelfPlayerCharacterEventWithCondition(self, "StateLeaveHandler", {
    state = {
      EPawnState.DriveVehicle,
      EPawnState.InVehicle
    }
  }, self.StateLeaveHandler, self)
  self:AddCommonEvent(EVENTTYPE_OLD_WIDGET, EVENTID_PRE_CLOSE_ALL_UI, self.OnPreCloseAllUI, self)
end

function NewCamera_IngameSelfieSubsystem:OnRelease()
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:OnRelease close photo entrance")
  self:_HidePhotoEntrance()
  NewCamera_IngameSelfieSubsystem.__super.OnRelease(self)
end

function NewCamera_IngameSelfieSubsystem:GetCurPhotoMainUIConfig()
  return UIManager.UI_Config_InGame.NewCamera_Photo_UIBP
end

function NewCamera_IngameSelfieSubsystem:EnterSelfie(enterParam)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:EnterSelfie")
  local canIn = NewCamera_IngameSelfieSubsystem.__super.EnterSelfie(self)
  if not canIn then
    return false
  end
  self._enterParam = enterParam
  NewCameraTest.DumpSwimHeightEnter()
  self:_SwitchToThirdPersonBeforeEnter()
  self:SaveOriginalCameraParams()
  self._pendingEnterHDRSwitch = self:CheckNeedSwitchHDRPlusForEntry()
  if self._pendingEnterHDRSwitch then
    local enterMaskConfig = UIManager.UI_Config_InGame.NewCamera_Photo_EnterMask_UIBP
    if enterMaskConfig then
      log(bWriteLog and "NewCamera_IngameSelfieSubsystem:EnterSelfie hold HDR+ switch until EnterMask fadein finished")
      UIManager.ShowUI(enterMaskConfig)
    else
      log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:EnterSelfie EnterMask config missing, switch HDR+ immediately")
      self._pendingEnterHDRSwitch = false
      self:TryEnterHDRMode()
    end
  else
    self:TryEnterHDRMode()
  end
  logic_connection_waiting:Show(0, false)
  self.entryWaitingTimer = self:AddTimerOnce(NewCameraConfig.CEntryWaitingTimeout, function()
    printf("NewCamera_IngameSelfieSubsystem:EnterSelfie entryWaitingTimer fired, isSwitchedHDRPlus:%s, pendingEnterHDRSwitch:%s", tostring(self.isSwitchedHDRPlus), tostring(self._pendingEnterHDRSwitch))
    logic_connection_waiting:Hide(0)
    self.entryWaitingTimer = nil
    self:RestoreRenderSettings()
    self:RequestExitPhotoGrapherOnEnterTimeout()
    self:_RestoreEnterPerspective(false)
    EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_ENTER_SELFIE_MODE_TIMEOUT)
  end)
  return true
end

function NewCamera_IngameSelfieSubsystem:RequestExitPhotoGrapherOnEnterTimeout()
  self.bSuppressResetCameraToFacePlayer = nil
  local playerState = GameplayData.GetPlayerState()
  if not slua.isValid(playerState) then
    return
  end
  if playerState.PhotoGrapherFeature then
    print(bWriteLog and "NewCamera_IngameSelfieSubsystem:RequestExitPhotoGrapherOnEnterTimeout")
    playerState.PhotoGrapherFeature:ExitPhotoGrapher()
  end
end

function NewCamera_IngameSelfieSubsystem:OnEnterSelfie()
  logic_connection_waiting:Hide(0)
  if self.entryWaitingTimer then
    self:RemoveTimer(self.entryWaitingTimer)
    self.entryWaitingTimer = nil
  end
  if not self:_ValidateEnterAfterDSResponse() then
    return
  end
  RunSelfieStep("CheckNeedPlayEntrySequence", function()
    self._needPlayEntrySequence = self:CheckNeedPlayEntrySequence()
  end)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:OnEnterSelfie")
  RunSelfieStep("super.OnEnterSelfie", function()
    NewCamera_IngameSelfieSubsystem.__super.OnEnterSelfie(self)
  end)
  self.bIsFPPbeforeSelfie = self._bEnteredWithFPP == true
  self.isInNewCamera = true
  self.totalPhotoCount = 0
  RunSelfieStep("StartStayTimer", function()
    self:StartStayTimer()
  end)
  RunSelfieStep("_CatchUpHDRPlusSwitch", function()
    self:_CatchUpHDRPlusSwitch()
  end)
  RunSelfieStep("postEnterSelfieEvent", function()
    EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_ENTER_SELFIE_MODE)
  end)
  RunSelfieStep("SetPlayerDefaultIdleState", function()
    self:SetPlayerDefaultIdleState()
  end)
  RunSelfieStep("_EnableCameraPostProcess", function()
    self:_EnableCameraPostProcess()
  end)
  RunSelfieStep("_SetSelfCVarEnable", function()
    self:_SetSelfCVarEnable(true)
  end)
  RunSelfieStep("SetSelfieFreeCameraParams", function()
    self:SetSelfieFreeCameraParams(true)
  end)
  RunSelfieStep("SwitchCameraMode", function()
    self:SwitchCameraMode(NewCameraConfig.CDefaultCameraMode)
  end)
  RunSelfieStep("ToggleMainControlUIVisibility", function()
    self:ToggleMainControlUIVisibility(false)
  end)
  RunSelfieStep("_SetPetRandomAnimDisable", function()
    self:_SetPetRandomAnimDisable(true)
  end)
  RunSelfieStep("RefreshTouchInputEnable", function()
    self:RefreshTouchInputEnable()
  end)
  RunSelfieStep("ResetPawnVisible", function()
    self:ResetPawnVisible(true)
  end)
  RunSelfieStep("EnableEmoteDurationRecord", function()
    self:EnableEmoteDurationRecord()
  end)
  RunSelfieStep("ApplyHeadRotOffset", function()
    self:ApplyHeadRotOffset(0, 0)
  end)
  RunSelfieStep("_ReportEnterTlog", function()
    self:_ReportEnterTlog()
  end)
  RunSelfieStep("RequestCustomFilterTemplateList", function()
    self:RequestCustomFilterTemplateList()
  end)
  self._needPlayEntrySequence = false
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:OnEnterSelfie all steps done")
end

function NewCamera_IngameSelfieSubsystem:_ValidateEnterAfterDSResponse()
  local notice = self:CheckCanEnterSystem()
  if not notice then
    return true
  end
  log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:_ValidateEnterAfterDSResponse CheckCanEnterSystem failed after DS response, notice:" .. tostring(notice))
  local PhotoGrapherSubSystem = SubsystemMgr:Get("PhotoGrapherSubSystem")
  if PhotoGrapherSubSystem then
    PhotoGrapherSubSystem:ChangePhotoGrapherOpenState(false)
  end
  ShowNotice(notice)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:_ValidateEnterAfterDSResponse rollback render settings, isSwitchedHDRPlus:" .. tostring(self.isSwitchedHDRPlus) .. ", pendingEnterHDRSwitch:" .. tostring(self._pendingEnterHDRSwitch))
  self:RestoreRenderSettings()
  self:_RestoreEnterPerspective(false)
  EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_ENTER_SELFIE_MODE_TIMEOUT)
  return false
end

function NewCamera_IngameSelfieSubsystem:_SwitchToThirdPersonBeforeEnter()
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:_SwitchToThirdPersonBeforeEnter")
  local playerCharacter = GameplayData.GetPlayerCharacter()
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerCharacter) or not slua.isValid(playerController) then
    return
  end
  local EPlayerCameraMode = import("EPlayerCameraMode")
  local bWasFPP = playerCharacter.IsFPP == true or EPlayerCameraMode and playerController.CurCameraMode == EPlayerCameraMode.PCM_FPP
  self._bEnteredWithFPP = bWasFPP
  printf("NewCamera_IngameSelfieSubsystem:_SwitchToThirdPersonBeforeEnter, bWasFPP:%s", bWasFPP)
  if not bWasFPP then
    return
  end
  playerCharacter.bForceChangePersonPerspective = true
  playerCharacter:SetCurrentPersonPerspective(false, false)
  playerCharacter:LocalSwitchPersonPerspective(false, true, true)
end

function NewCamera_IngameSelfieSubsystem:_ScheduleRestorePersonPerspective(character, pc, bIgnoreEnteredFPP)
  NewCamera_IngameSelfieSubsystem.__super._ScheduleRestorePersonPerspective(self, character, pc, true)
end

function NewCamera_IngameSelfieSubsystem:_RestoreEnterPerspective(bDeferred)
  printf("NewCamera_IngameSelfieSubsystem:_RestoreEnterPerspective, bDeferred:%s, bEnteredWithFPP:%s", bDeferred, self._bEnteredWithFPP)
  if not self._bEnteredWithFPP then
    return
  end
  self._bEnteredWithFPP = nil
  self.bIsFPPbeforeSelfie = false
  
  local function Apply()
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:_RestoreEnterPerspective - delay. bIsFPPBeforeSelfie:" .. tostring(self.bIsFPPBeforeSelfie))
    if self.bIsFPPbeforeSelfie then
      return
    end
    local playerCharacter = GameplayData.GetPlayerCharacter()
    if not slua.isValid(playerCharacter) then
      return
    end
    playerCharacter:SetCurrentPersonPerspective(true, true)
    playerCharacter:LocalSwitchPersonPerspective(true, true, true)
    playerCharacter.bForceChangePersonPerspective = false
  end
  
  if bDeferred then
    self:AddGameTimer(0, false, Apply)
  else
    Apply()
  end
end

function NewCamera_IngameSelfieSubsystem:ExitSelfieFromDamage()
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:ExitSelfieFromDamage")
  self:ExitSelfie(NewCameraTLogReport.EExitReason.Hit)
end

function NewCamera_IngameSelfieSubsystem:SetSelfieFreeCameraParams(bEnable)
  local selfiePC = GameplayData.GetPlayerController()
  if not slua.isValid(selfiePC) then
    return
  end
  if selfiePC.SetResetStartPosOnTouchEnd then
    selfiePC:SetResetStartPosOnTouchEnd(bEnable)
  end
  if selfiePC.SetDisableVehicleRotationLagOnFreeCam then
    selfiePC:SetDisableVehicleRotationLagOnFreeCam(bEnable)
  end
end

function NewCamera_IngameSelfieSubsystem:ExitSelfie(reason, notCloseMainUI)
  printf("NewCamera_IngameSelfieSubsystem:ExitSelfie, reason:%s, notCloseMainUI:%s", reason, notCloseMainUI)
  if self.bIsIngameSelfieMode == false then
    print(bWriteLog and "NewCamera_IngameSelfieSubsystem:ExitSelfie already exited")
    return
  end
  reason = reason or NewCameraTLogReport.EExitReason.Abnormal
  RunSelfieStep("RestorePhotoWearOnExit", function()
    self:RestorePhotoWearOnExit()
  end)
  RunSelfieStep("super.ExitSelfie", function()
    NewCamera_IngameSelfieSubsystem.__super.ExitSelfie(self, notCloseMainUI)
  end)
  self.isInNewCamera = false
  RunSelfieStep("DisableEmoteDurationRecord", function()
    self:DisableEmoteDurationRecord()
  end)
  if self.bInDroneMode then
    RunSelfieStep("StopDroneControl", function()
      self:StopDroneControl()
    end)
  end
  RunSelfieStep("_SetSelfCVarEnable", function()
    self:_SetSelfCVarEnable(false)
  end)
  RunSelfieStep("SetSelfieFreeCameraParams", function()
    self:SetSelfieFreeCameraParams(false)
  end)
  RunSelfieStep("SetSelectedFilterID", function()
    self:SetSelectedFilterID(nil)
  end)
  RunSelfieStep("ChangeFilter", function()
    self:ChangeFilter()
  end)
  RunSelfieStep("RestoreCameraState", function()
    self:RestoreCameraState()
  end)
  RunSelfieStep("ResetCharacterMeshRotation", function()
    self:ResetCharacterMeshRotation()
  end)
  RunSelfieStep("RestorePetVisibility", function()
    self:RestorePetVisibility()
  end)
  RunSelfieStep("RestoreNPCVisibility", function()
    self:RestoreNPCVisibility()
  end)
  RunSelfieStep("StopEmotion", function()
    self:StopEmotion()
  end)
  RunSelfieStep("RestoreHeadRotOffset", function()
    self:RestoreHeadRotOffset()
  end)
  RunSelfieStep("DestroyRoleLight", function()
    self:DestroyRoleLight()
  end)
  RunSelfieStep("_SetPetRandomAnimDisable", function()
    self:_SetPetRandomAnimDisable(false)
  end)
  RunSelfieStep("ToggleMainControlUIVisibility", function()
    self:ToggleMainControlUIVisibility(true)
  end)
  RunSelfieStep("ReshowTouchInput", function()
    self:ReshowTouchInput()
  end)
  RunSelfieStep("ResetPawnVisible", function()
    self:ResetPawnVisible()
  end)
  RunSelfieStep("RestoreWeather", function()
    self:RestoreWeather()
  end)
  RunSelfieStep("InterruptAutoSprint", function()
    NewCameraUtil.InterruptAutoSprint()
  end)
  RunSelfieStep("postExitSelfieEvent", function()
    EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_EXIT_SELFIE_MODE)
  end)
  RunSelfieStep("postReshowSwimPanel", function()
    EventSystem:postEvent(EVENTTYPE_INGAME, EVENTID_RESHOW_SWIM_PANEL_UI_ROOT)
  end)
  self.curCameraMode = nil
  RunSelfieStep("ResetPanRange", function()
    self:ResetPanRange()
  end)
  self.savedInitialArmLength = nil
  self.savedBaseRelativeRotation = nil
  self.curZoom = nil
  self._bManualFocus = nil
  RunSelfieStep("ClearCameraParams", function()
    self:ClearCameraParams()
  end)
  self.isAgreeSwitchHDRPlus = false
  RunSelfieStep("RestorePlayerIdleState", function()
    self:RestorePlayerIdleState()
  end)
  RunSelfieStep("ClearStayTimer", function()
    self:ClearStayTimer()
  end)
  RunSelfieStep("RestoreEnterPerspective", function()
    self:_RestoreEnterPerspective(true)
  end)
  RunSelfieStep("_ReportExitTLog", function()
    self:_ReportExitTLog(reason)
  end)
  self.bIsIngameSelfieMode = false
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:ExitSelfie all steps done")
  NewCameraTest.DumpSwimHeightExit(self)
end

function NewCamera_IngameSelfieSubsystem:RestorePhotoWearOnExit()
  local PhotoGrapherSubSystem = SubsystemMgr:Get("PhotoGrapherSubSystem")
  if not PhotoGrapherSubSystem or not PhotoGrapherSubSystem.TryRestorePhotoWearOnExit then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:RestorePhotoWearOnExit PhotoGrapherSubSystem not ready")
    return
  end
  PhotoGrapherSubSystem:TryRestorePhotoWearOnExit()
end

function NewCamera_IngameSelfieSubsystem:ToggleMainControlUIVisibility(bVisible)
  EventSystem:postEvent(EVENTTYPE_INGAME, EVENTID_SHOW_HIDE_UI_WITH_FLAG, ShowHideUIFlag.bEnterNewCameraSelfie, not bVisible)
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerController) then
    return
  end
  if bVisible then
    playerController:LuaShowJoystickWidgetWithTag("NewCamera_IngameSelfie")
  else
    playerController:LuaHideJoystickWidgetWithTag("NewCamera_IngameSelfie")
  end
  NewCamera_IngameSelfieSubsystem.__super.ToggleMainControlUIVisibility(self, bVisible, true)
end

function NewCamera_IngameSelfieSubsystem:SwitchCameraMode(mode)
  if mode ~= NewCameraConfig.CameraMode.Fixed and mode ~= NewCameraConfig.CameraMode.Move then
    return
  end
  if self.curCameraMode == mode then
    return
  end
  self.curCameraMode = mode
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:SwitchCameraMode")
  local CameraMode = NewCameraConfig.CameraMode
  if mode == CameraMode.Fixed then
    self:EnterFixedMode()
  elseif mode == CameraMode.Move then
    self:EnterMoveMode()
  end
  EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_MODE_CHANGED, mode)
end

function NewCamera_IngameSelfieSubsystem:EnterFixedMode()
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerController) then
    return
  end
  self:AddControlEvent(playerController, "MoveForwardDelegate", function()
  end, self)
  self:AddControlEvent(playerController, "MoveRightDelegate", function()
  end, self)
  self:AddTimer(0, function()
    coroutine.yield(0)
    self:ResetCameraToFacePlayer()
  end)
  self:ApplyZoomToCamera(self.curZoom or NewCameraConfig.CDefaultZoom)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:EnterFixedMode done")
end

function NewCamera_IngameSelfieSubsystem:EnterMoveMode()
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerController) then
    return
  end
  self:ResetCharacterMeshRotation()
  playerController:ExitFreeCamera(true)
  self:RemoveControlEvent(playerController, "MoveForwardDelegate")
  self:RemoveControlEvent(playerController, "MoveRightDelegate")
  local targetSocketOffset = self:GetTargetSocketOffset()
  if targetSocketOffset then
    self:_WriteSocketOffsetToSpringArm(targetSocketOffset)
  end
  self:ApplyZoomToCamera(self.curZoom or NewCameraConfig.CDefaultZoom)
  self:SetFocusLock(true)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:EnterMoveMode done")
end

function NewCamera_IngameSelfieSubsystem:GetCameraMode()
  return self.curCameraMode
end

function NewCamera_IngameSelfieSubsystem:RestoreCameraState()
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerController) then
    return
  end
  playerController:ExitFreeCamera(true)
  self:RemoveControlEvent(playerController, "MoveForwardDelegate")
  self:RemoveControlEvent(playerController, "MoveRightDelegate")
  if self.savedInitialArmLength then
    local PhotoGrapherSubSystem = SubsystemMgr:Get("PhotoGrapherSubSystem")
    if PhotoGrapherSubSystem and PhotoGrapherSubSystem.SetTargetArmLenth then
      if self:CheckNeedResetToOriginSpringArmLength() then
        PhotoGrapherSubSystem:RefreshCacheTargetArmLenth(self.savedInitialArmLength)
      end
      PhotoGrapherSubSystem:ResumeSpringArmLength()
    end
    self.savedInitialArmLength = nil
    self.originArmLength = nil
  end
  local targetSocketOffset = self:GetTargetSocketOffset()
  if targetSocketOffset then
    self:_WriteSocketOffsetToSpringArm(targetSocketOffset)
    self.savedInitialSocketOffset = nil
    self.originSocketOffset = nil
  end
  if self.savedFOV then
    local savedCamera = self._savedCameraComp
    if slua.isValid(savedCamera) then
      savedCamera:SetFieldOfView(self.savedFOV)
      if self.savedAspectRatio then
        savedCamera:SetAspectRatio(self.savedAspectRatio)
      end
      if self.savedConstrainAspectRatio ~= nil then
        savedCamera:SetConstraintAspectRatio(self.savedConstrainAspectRatio)
      end
    end
    self.savedFOV = nil
    self.savedAspectRatio = nil
    self.savedConstrainAspectRatio = nil
  end
  if self.savedCameraRelativeRotation then
    local savedCamera = self._savedCameraComp
    if slua.isValid(savedCamera) then
      savedCamera:K2_SetRelativeRotation(self.savedCameraRelativeRotation, false, nil, false)
    end
    self.savedCameraRelativeRotation = nil
  end
  self._savedCameraComp = nil
  self:_CleanupCameraPostProcess()
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:RestoreCameraState done")
end

function NewCamera_IngameSelfieSubsystem:SaveOriginalCameraParams()
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerController) then
    return
  end
  local uSpringArm = playerController:GetTargetedSpringArm()
  if slua.isValid(uSpringArm) then
    local originSocketOffset = uSpringArm.SocketOffset
    self.originSocketOffset = FVector(originSocketOffset.X, originSocketOffset.Y, originSocketOffset.Z)
    self.originArmLength = uSpringArm.TargetArmLength
    local PhotoGrapherSubSystem = SubsystemMgr:Get("PhotoGrapherSubSystem")
    local playerCharacterForSeatCheck = GameplayData.GetPlayerCharacter()
    if PhotoGrapherSubSystem and PhotoGrapherSubSystem.CheckIsDriver and slua.isValid(playerCharacterForSeatCheck) and self:IsInVehicle() and not PhotoGrapherSubSystem:CheckIsDriver(playerCharacterForSeatCheck) then
      local inVehicleCameraData = uSpringArm.InVehicleCameraData
      if inVehicleCameraData and inVehicleCameraData.SpringArmLength and inVehicleCameraData.SpringArmLength >= 0 then
        self.originArmLength = inVehicleCameraData.SpringArmLength
      end
    end
  end
  local playerCharacter = GameplayData.GetPlayerCharacter()
  local savedCamera = NewCameraUtil.GetCamera()
  if slua.isValid(savedCamera) then
    self._savedCameraComp = savedCamera
    self.savedFOV = savedCamera.FieldOfView
    self.savedAspectRatio = savedCamera.AspectRatio
    self.savedConstrainAspectRatio = savedCamera.bConstrainAspectRatio
    local camRot = savedCamera.RelativeRotation
    self.savedCameraRelativeRotation = FRotator(camRot.Pitch, camRot.Yaw, camRot.Roll)
  end
  if slua.isValid(playerCharacter) and slua.isValid(playerCharacter.Camera) then
    local TPPSpringArmParam = playerCharacter.TPPSpringArmParam
    self.savedInitialArmLength = TPPSpringArmParam and TPPSpringArmParam.TargetArmALength or NewCameraConfig.CCameraDefaultArmLength
    local charSocketOffset = TPPSpringArmParam and TPPSpringArmParam.SocketOffset
    if charSocketOffset then
      self.savedInitialSocketOffset = FVector(charSocketOffset.X, charSocketOffset.Y, charSocketOffset.Z)
    end
  end
  local logic_setting_graphics = require("client.slua.logic.setting.logic_setting_graphics")
  local RenderSettings = logic_setting_graphics.GetRenderSettingsApplying()
  self.savedRenderStyle = RenderSettings and RenderSettings.RenderStyleSetting
  self.savedRenderQuality = RenderSettings and RenderSettings.RenderQualitySetting
  local IngameSelfieWeatherSubsystem = SubsystemMgr:Get("IngameSelfieWeatherSubsystem")
  if IngameSelfieWeatherSubsystem then
    IngameSelfieWeatherSubsystem:InitWeather()
    self.savedWeatherValue = IngameSelfieWeatherSubsystem.InitValue
  end
  if slua.isValid(playerCharacter) and slua.isValid(playerCharacter.Mesh) then
    local meshRot = playerCharacter.Mesh.RelativeRotation
    self.savedBaseRelativeRotation = FRotator(meshRot.Pitch, meshRot.Yaw, meshRot.Roll)
  end
  local list = {
    savedInitialSocketOffset = getContainerParamLog(self.savedInitialSocketOffset, vectorParamList),
    originSocketOffset = getContainerParamLog(self.originSocketOffset, vectorParamList),
    savedFOV = self.savedFOV,
    savedAspectRatio = self.savedAspectRatio,
    savedConstrainAspectRatio = self.savedConstrainAspectRatio,
    savedCameraRelativeRotation = getContainerParamLog(self.savedCameraRelativeRotation, rotatorParamList),
    savedInitialArmLength = self.savedInitialArmLength,
    originArmLength = self.originArmLength,
    savedRenderStyle = self.savedRenderStyle,
    savedRenderQuality = self.savedRenderQuality,
    savedBaseRelativeRotation = getContainerParamLog(self.savedBaseRelativeRotation, rotatorParamList)
  }
  log_tree("NewCamera_IngameSelfieSubsystem:SaveOriginalCameraParams - list = ", list)
end

function NewCamera_IngameSelfieSubsystem:RefreshSaveOriginalCameraParams(state)
  if not NewCameraConfig.NeedRefreshOriginParamByPlayerState[state] then
    printf("NewCamera_IngameSelfieSubsystem:RefreshSaveOriginalCameraParams - not need to refresh. state = %s", state)
    return
  end
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerController) then
    return
  end
  local uSpringArm = playerController:GetTargetedSpringArm()
  if slua.isValid(uSpringArm) then
    local originSocketOffset = uSpringArm.SocketOffset
    self.originSocketOffset = FVector(originSocketOffset.X, originSocketOffset.Y, originSocketOffset.Z)
    self.originArmLength = uSpringArm.TargetArmLength
  end
end

function NewCamera_IngameSelfieSubsystem:ResetCameraToFacePlayer()
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:ResetCameraToFacePlayer")
  if self._needPlayEntrySequence then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:ResetCameraToFacePlayer CheckDefaultTemplateID")
    return
  end
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerController) then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:ResetCameraToFacePlayer not playerController")
    return
  end
  local playerCharacter = GameplayData.GetPlayerCharacter()
  if not slua.isValid(playerCharacter) then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:ResetCameraToFacePlayer not playerCharacter")
    return
  end
  if not NewCameraUtil.IsInPhotoGrapherMode() then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:ResetCameraToFacePlayer not IsInPhotoGrapherMode")
    return
  end
  playerController:StartFreeCamera(ETouchIndex.Touch1)
  self:TryBanPlayerMoveDelegate()
  if not self:CheckCanFaceToPlayer() then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:ResetCameraToFacePlayer IsInwInteractiveState")
    return
  end
  NewCameraUtil.InterruptAutoSprint()
  local uSpringArm = playerController:GetTargetedSpringArm()
  if slua.isValid(uSpringArm) then
    self:_WriteSocketOffsetToSpringArm(FVector(0, 0, NewCameraConfig.CSocketOffsetZ))
    local targetRot = NewCameraUtil.GetFacePlayerTargetRot(uSpringArm, playerCharacter, playerController)
    local duration = uSpringArm.DelayRotationBackLagEnabled and NewCameraConfig.CCameraResetDuration or 0
    NewCameraUtil.SetSpringArmFreeCamRot(uSpringArm, targetRot, duration)
  end
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:ResetCameraToFacePlayer done")
end

function NewCamera_IngameSelfieSubsystem:TryBanPlayerMoveDelegate()
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerController) then
    return
  end
  if self.curCameraMode ~= NewCameraConfig.CameraMode.Fixed then
    return
  end
  self:AddControlEvent(playerController, "MoveForwardDelegate", function()
  end, self)
  self:AddControlEvent(playerController, "MoveRightDelegate", function()
  end, self)
end

function NewCamera_IngameSelfieSubsystem:SetPlayerDefaultIdleState()
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:SetPlayerDefaultIdleState")
  self:_CancelHeldThrowable()
  if self._needPlayEntrySequence then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:SetPlayerDefaultIdleState has default template id")
    return
  end
  if self:CheckIsPlayerInInteractiveState() then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:SetPlayerDefaultIdleState player is in interactive state")
    return
  end
  local playerController = GameplayData.GetPlayerController()
  local playerCharacter = playerController:GetPlayerCharacterSafety()
  if slua.isValid(playerCharacter) then
    local playEmoteComponent = playerCharacter:GetPlayEmoteComponent()
    if Game:IsValid(playEmoteComponent) then
      local emoteIndex = playEmoteComponent:GetCurrentEmoteID()
      if emoteIndex and 0 < emoteIndex then
        playerCharacter:LocalInteruptPlayEmote(emoteIndex)
      end
    end
  end
end

function NewCamera_IngameSelfieSubsystem:_CancelHeldThrowable()
  local playerCharacter = GameplayData.GetPlayerCharacter()
  if not slua.isValid(playerCharacter) then
    return
  end
  if not playerCharacter:HasState(EPawnState.HoldGrenade) then
    return
  end
  printf("NewCamera_IngameSelfieSubsystem:_CancelHeldThrowable [HoldGrenadeDbg] hold grenade detected, interrupt throw")
  local OperateSubsystem = SubsystemMgr:Get("OperateSubsystem")
  if OperateSubsystem and OperateSubsystem.InterruptThrow then
    OperateSubsystem:InterruptThrow()
  else
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:_CancelHeldThrowable OperateSubsystem invalid")
  end
end

function NewCamera_IngameSelfieSubsystem:RestorePlayerIdleState()
  self:RestoreEmoteWeapon()
end

function NewCamera_IngameSelfieSubsystem:OnButton_PhotoEditClick()
  local curTime = Game:GetCurTimeMilliseconds()
  local clickInterval = curTime - (self._lastPhotoEditClickTime or 0)
  if clickInterval < NewCameraConfig.CPhotoEditClickMinInterval then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:OnButton_PhotoEditClick too fast, interval = " .. tostring(clickInterval))
    ShowNotice(7108)
    return
  end
  self._lastPhotoEditClickTime = curTime
  local notice = self:CheckCanEnterSystem()
  if notice then
    ShowNotice(notice)
    return
  end
  self:CloseUIBeforeEnterSelfie()
  
  local function callback()
    NewCamera_IngameSelfieSubsystem.__super.OnButton_PhotoEditClick(self)
  end
  
  self:CheckAndAskCanSwitchToHDR(callback)
end

function NewCamera_IngameSelfieSubsystem:CloseUIBeforeEnterSelfie()
  local QuickExpressionDecalUI = UIManager.GetUI(UIManager.UI_Config_InGame.QuickExpressionDecalUI)
  if QuickExpressionDecalUI then
    QuickExpressionDecalUI:CloseCommonPart()
  end
  if UIManager.UI_Config_InGame.WatchGameInGamePlayerInfo then
    local WatchGameInGamePlayerInfo = UIManager.GetUI(UIManager.UI_Config_InGame.WatchGameInGamePlayerInfo)
    if WatchGameInGamePlayerInfo and WatchGameInGamePlayerInfo.OnClickCloseButton then
      WatchGameInGamePlayerInfo:OnClickCloseButton()
    end
  end
end

function NewCamera_IngameSelfieSubsystem:ResetPawnVisible(bEnter)
  local PhotoGrapherSubSystem = SubsystemMgr:Get("PhotoGrapherSubSystem")
  if PhotoGrapherSubSystem then
    local needHideEnemy = false
    if bEnter then
      needHideEnemy = self:GetDefaultNeedHideEnemy()
    end
    PhotoGrapherSubSystem:SetPawnVisible(false, false, needHideEnemy, true)
  end
end

function NewCamera_IngameSelfieSubsystem:RestoreWeather()
  if self.savedWeatherValue then
    local IngameSelfieWeatherSubsystem = SubsystemMgr:Get("IngameSelfieWeatherSubsystem")
    if IngameSelfieWeatherSubsystem then
      IngameSelfieWeatherSubsystem:SetValue(self.savedWeatherValue)
    end
  end
end

function NewCamera_IngameSelfieSubsystem:_ShowPhotoEntrance()
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:_ShowPhotoEntrance")
  if not self:CheckCanShowPhotoEntrance() then
    return
  end
  if UIManager.UI_Config_InGame.Camera_Photo_Entrance_UIBP == nil then
    return
  end
  local Camera_Photo_Entrance_UIBP = UIManager.GetUI(UIManager.UI_Config_InGame.Camera_Photo_Entrance_UIBP)
  if not Camera_Photo_Entrance_UIBP then
    UIManager.ShowUI(UIManager.UI_Config_InGame.Camera_Photo_Entrance_UIBP)
  end
end

function NewCamera_IngameSelfieSubsystem:OnPreCloseAllUI()
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:OnPreCloseAllUI close photo entrance")
  self:_HidePhotoEntrance()
end

function NewCamera_IngameSelfieSubsystem:_HidePhotoEntrance()
  local photoEntranceConfig = UIManager.UI_Config_InGame.Camera_Photo_Entrance_UIBP
  if photoEntranceConfig == nil then
    log_warning(bWriteLog and "[WARN] NewCamera_IngameSelfieSubsystem:_HidePhotoEntrance skip, config is nil")
    return
  end
  local photoEntranceUI = UIManager.GetUI(photoEntranceConfig)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:_HidePhotoEntrance hasUI = " .. tostring(photoEntranceUI ~= nil))
  if not photoEntranceUI then
    return
  end
  UIManager.CloseUI(photoEntranceConfig)
end

function NewCamera_IngameSelfieSubsystem:EnterSelfieWithSmartCamera(nTemplateID, state)
  printf("NewCamera_IngameSelfieSubsystem:EnterSelfieWithSmartCamera - state:%s", state)
  self:SetExternalPhotoUIDisplayState(state or NewCamera_Photo_UIConfig.EPhotoUIDisplayState.Simple)
  self:SetTemplateID(nTemplateID)
  self:EnterSelfie()
end

function NewCamera_IngameSelfieSubsystem:EnterSelfieWithSequenceCamera(nTemplateID, tSequenceConfig)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:EnterSelfieWithSequenceCamera")
  self:SetExternalPhotoUIDisplayState(NewCamera_Photo_UIConfig.EPhotoUIDisplayState.Simple)
  self:SetSequenceConfig(nTemplateID, tSequenceConfig)
  self:EnterSelfie()
end

function NewCamera_IngameSelfieSubsystem:CheckNeedPlayEntrySequence()
  if self:CheckDefaultTemplateID() then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckNeedPlayEntrySequence CheckDefaultTemplateID true")
    return true
  end
  if self.nTemplateID and self.nTemplateID > 0 then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckNeedPlayEntrySequence nTemplateID > 0")
    return true
  end
  if self._enterParam and self._enterParam.highlightVehicle then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckNeedPlayEntrySequence highlightVehicle true")
    return true
  end
  return false
end

function NewCamera_IngameSelfieSubsystem:CloseOtherUI()
  NewCamera_IngameSelfieSubsystem.__super.CloseOtherUI(self)
  local list = {
    UIManager.UI_Config_InGame.NewCamera_Photo_FilterTemplate_UIBP,
    UIManager.UI_Config_InGame.NewCamera_Photo_FilterTemplate_Detail_UIBP,
    UIManager.UI_Config_InGame.NewCamera_Photo_CameraRecord_UIBP,
    UIManager.UI_Config_InGame.NewCamera_Photo_CameraRecord_Preview_UIBP,
    UIManager.UI_Config_InGame.NewCamera_Photo_CameraRecord_Save_UIBP
  }
  for _, uiConfig in ipairs(list) do
    if uiConfig and UIManager.GetUI(uiConfig) then
      UIManager.CloseUI(uiConfig)
    end
  end
end

function NewCamera_IngameSelfieSubsystem:OnControllerBeginPlayFinish()
  self:_ShowPhotoEntrance()
end

function NewCamera_IngameSelfieSubsystem:OnEnterSmartCamera()
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:OnEnterSmartCamera")
  self.isInSmartCamera = true
  self:AddTimerOnce(0.1, function()
    self:_CopyCurrentPostProcessToSmartCamera()
  end)
end

function NewCamera_IngameSelfieSubsystem:OnCameraSeqFinish()
  if not self.isInSmartCamera then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:OnCameraSeqFinish not in smart camera")
    return
  end
  self.isInSmartCamera = false
  if not NewCameraUtil.IsInPhotoGrapherMode() then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:OnCameraSeqFinish not in photographer mode")
    return
  end
  if self.curCameraMode == NewCameraConfig.CameraMode.Move then
    self:EnterMoveMode()
  elseif self.curCameraMode == NewCameraConfig.CameraMode.Fixed then
    self:EnterFixedMode()
  end
end

function NewCamera_IngameSelfieSubsystem:OnExpandPanelMutex()
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:OnExpandPanelMutex")
  self._isExpandPanelMutex = true
end

function NewCamera_IngameSelfieSubsystem:OnBattleResult()
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:OnBattleResult")
  self:ExitSelfie(NewCameraTLogReport.EExitReason.SwitchScene)
end

function NewCamera_IngameSelfieSubsystem:StateEnterHandler(state)
  if not self.bIsIngameSelfieMode then
    return
  end
  if NewCameraConfig.AutoExitSelfieByPlayerState[state] then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:StateEnterHandler AutoExitSelfieByPlayerState. state = " .. tostring(state))
    self:RefreshSaveOriginalCameraParams(state)
    self:ExitSelfie(NewCameraTLogReport.EExitReason.Abnormal)
    return
  end
  self:StopEmotion()
  EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_ON_PLAYER_ENTER_SPECIAL_STATE)
end

function NewCamera_IngameSelfieSubsystem:OnRefreshParachuteUIState()
  if not self.bIsIngameSelfieMode then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:OnRefreshParachuteUIState. selfie mode already exited")
    return
  end
  self:AddGameTimer(0, false, function()
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:OnRefreshParachuteUIState. delay exit selfie")
    self:ExitSelfie(NewCameraTLogReport.EExitReason.Abnormal)
  end)
end

function NewCamera_IngameSelfieSubsystem:StateLeaveHandler(state)
  if not self.bIsIngameSelfieMode then
    return
  end
  if NewCameraConfig.AutoExitSelfieByPlayerState[state] then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:StateLeaveHandler AutoExitSelfieByPlayerState. state = " .. tostring(state))
    self:RefreshSaveOriginalCameraParams(state)
    self:ExitSelfie(NewCameraTLogReport.EExitReason.Abnormal)
  end
end

function NewCamera_IngameSelfieSubsystem:CanExitFreeCamera()
  if not self.isInNewCamera then
    return true
  end
  if self.curCameraMode ~= NewCameraConfig.CameraMode.Fixed then
    return true
  end
  return false
end

function NewCamera_IngameSelfieSubsystem:EnableTouchInput(key)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:EnableTouchInput - " .. key)
  self.touchInputHideQueue[key] = nil
  self:RefreshTouchInputEnable()
end

function NewCamera_IngameSelfieSubsystem:DisableTouchInput(key)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:DisableTouchInput - " .. key)
  self.touchInputHideQueue[key] = true
  self:RefreshTouchInputEnable()
end

function NewCamera_IngameSelfieSubsystem:RefreshTouchInputEnable()
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerController) then
    printf("NewCamera_IngameSelfieSubsystem:RefreshTouchInputEnable PlayerController invalid, scheduleRetry:%s", tostring(self._touchInputRetryTimer == nil))
    if not self._touchInputRetryTimer then
      self._touchInputRetryTimer = self:AddGameTimer(0.3, false, function()
        self._touchInputRetryTimer = nil
        self:RefreshTouchInputEnable()
      end)
    end
    return
  end
  local enable = not self.touchInputHideQueue or not next(self.touchInputHideQueue)
  playerController.bCanGetTouchInput = enable
  printf("NewCamera_IngameSelfieSubsystem:RefreshTouchInputEnable applied, enable:%s, hasQueuedKey:%s", tostring(enable), tostring(next(self.touchInputHideQueue or {}) ~= nil))
  log_tree("NewCamera_IngameSelfieSubsystem:RefreshTouchInputEnable - touchInputHideQueue = ", self.touchInputHideQueue)
end

function NewCamera_IngameSelfieSubsystem:ReshowTouchInput()
  printf("NewCamera_IngameSelfieSubsystem:ReshowTouchInput called, hadQueuedKeyBefore:%s", tostring(self.touchInputHideQueue ~= nil and next(self.touchInputHideQueue) ~= nil))
  self.touchInputHideQueue = {}
  self:RefreshTouchInputEnable()
end

function NewCamera_IngameSelfieSubsystem:CheckAndAskCanSwitchToHDR(callback)
  local needSwitchToHDR = NewCameraUtil.CheckNeedSwitchToHDR()
  if not needSwitchToHDR then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckAndAskCanSwitchToHDR not need switch to HDR")
    callback()
    return
  end
  local titleStr = LocUtil.GetLocalizeResStr(5077)
  local msgStr = LocUtil.GetLocalizeResStr(468890163)
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  CommonMsgBoxMgr.Show(2, titleStr, msgStr, function()
    self.isAgreeSwitchHDRPlus = true
    callback()
  end, function()
    self.isAgreeSwitchHDRPlus = false
    callback()
  end, nil, nil, {
    autoCloseTime = 10,
    hideAutoCloseRemainTime = true,
    autoCloseWithoutCallback = true
  })
end

function NewCamera_IngameSelfieSubsystem:CheckNeedSwitchHDRPlusForEntry()
  if not self.isAgreeSwitchHDRPlus then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckNeedSwitchHDRPlusForEntry not agree switch HDR+")
    return false
  end
  return NewCameraUtil.CheckNeedSwitchToHDR() == true
end

function NewCamera_IngameSelfieSubsystem:OnEnterMaskFadeInFinished()
  printf("NewCamera_IngameSelfieSubsystem:OnEnterMaskFadeInFinished pendingHDRSwitch:%s, isSwitchedHDRPlus:%s", tostring(self._pendingEnterHDRSwitch), tostring(self.isSwitchedHDRPlus))
  if not self._pendingEnterHDRSwitch then
    return
  end
  self._pendingEnterHDRSwitch = false
  self:TryEnterHDRMode()
end

function NewCamera_IngameSelfieSubsystem:_CatchUpHDRPlusSwitch()
  printf("NewCamera_IngameSelfieSubsystem:_CatchUpHDRPlusSwitch enter, isSwitchedHDRPlus:%s, pendingEnterHDRSwitch:%s, hasSavedRenderQuality:%s", tostring(self.isSwitchedHDRPlus), tostring(self._pendingEnterHDRSwitch), tostring(self.savedRenderQuality ~= nil))
  if self.isSwitchedHDRPlus then
    return
  end
  if self._pendingEnterHDRSwitch then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:_CatchUpHDRPlusSwitch pending HDR+ switch not fired by fadein, fallback now")
    self._pendingEnterHDRSwitch = false
  end
  if self:CheckNeedSwitchHDRPlusForEntry() then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:_CatchUpHDRPlusSwitch need HDR+ but not switched, catch up now")
  end
  self:TryEnterHDRMode()
end

function NewCamera_IngameSelfieSubsystem:_NotifyHDRPlusSwitched()
  local mainUIConfig = self:GetCurPhotoMainUIConfig()
  local mainUI = mainUIConfig and UIManager.GetUI(mainUIConfig) or nil
  printf("NewCamera_IngameSelfieSubsystem:_NotifyHDRPlusSwitched mainUIExist:%s, isSwitchedHDRPlus:%s", tostring(mainUI ~= nil), tostring(self.isSwitchedHDRPlus))
  if mainUI and mainUI.RefreshHDRSwitchState then
    mainUI:RefreshHDRSwitchState()
  end
end

function NewCamera_IngameSelfieSubsystem:TryEnterHDRMode()
  local ERenderQuality = import("ERenderQuality")
  if not ERenderQuality then
    return false
  end
  local GraphicHelperUtil = require("client.slua.umg.NewSetting.GraphicsNew.GraphicHelperUtil")
  local HDR_PLUS = ERenderQuality.HIGHDEFINITIONPLUS
  local needSwitchToHDR = NewCameraUtil.CheckNeedSwitchToHDR()
  local curQuality = GraphicHelperUtil.GetCurrentSceneRenderQuality()
  log_format("TryEnterHDRMode - isAgreeSwitchHDRPlus:%s needSwitchToHDR:%s curQuality:%s HDR_PLUS:%s", self.isAgreeSwitchHDRPlus, needSwitchToHDR, curQuality, HDR_PLUS)
  if not needSwitchToHDR then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:TryEnterHDRMode not need switch to HDR")
    if curQuality and HDR_PLUS <= curQuality then
      self.isSwitchedHDRPlus = true
      self:_NotifyHDRPlusSwitched()
    end
    return false
  end
  if not self.isAgreeSwitchHDRPlus then
    log_warning(bWriteLog and "NewCamera_IngameSelfieSubsystem:TryEnterHDRMode not agree switch HDR")
    return false
  end
  if self.savedRenderQuality == nil then
    local logic_setting_graphics = require("client.slua.logic.setting.logic_setting_graphics")
    local RenderSettings = logic_setting_graphics.GetRenderSettingsApplying()
    self.savedRenderStyle = RenderSettings and RenderSettings.RenderStyleSetting
    self.savedRenderQuality = RenderSettings and RenderSettings.RenderQualitySetting
    printf("NewCamera_IngameSelfieSubsystem:TryEnterHDRMode missing render snapshot before switch, recaptured quality:%s, style:%s", tostring(self.savedRenderQuality), tostring(self.savedRenderStyle))
  end
  self:_UpdateRenderSetting(HDR_PLUS)
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:TryEnterHDRMode switched to HDR+, saved curQuality=" .. tostring(curQuality))
  self.isSwitchedHDRPlus = true
  self:_NotifyHDRPlusSwitched()
  return true
end

function NewCamera_IngameSelfieSubsystem:_UpdateRenderSetting(quality, style)
  local gameInstance = slua_GameFrontendHUD:GetGameInstance()
  if not slua.isValid(gameInstance) then
    return
  end
  local logic_setting_graphics = require("client.slua.logic.setting.logic_setting_graphics")
  local RenderSettings = logic_setting_graphics.GetRenderSettingsApplying()
  local RenderStyle = style or RenderSettings and RenderSettings.RenderStyleSetting or nil
  local RenderQuality = quality or RenderSettings and RenderSettings.RenderQualitySetting or nil
  local RenderMSAA = RenderSettings and RenderSettings.RenderMSAASetting or nil
  local MSAAValue = RenderSettings and RenderSettings.RenderMSAAValue or nil
  logic_setting_graphics.SetQuality(gameInstance, RenderQuality, RenderStyle, RenderMSAA, MSAAValue)
end

function NewCamera_IngameSelfieSubsystem:RestoreRenderSettings()
  printf("NewCamera_IngameSelfieSubsystem:RestoreRenderSettings enter, savedRenderQuality:%s, savedRenderStyle:%s, hadValidSnapshot:%s", tostring(self.savedRenderQuality), tostring(self.savedRenderStyle), tostring(self.savedRenderQuality ~= nil))
  self:_UpdateRenderSetting(self.savedRenderQuality, self.savedRenderStyle)
  self.savedRenderQuality = nil
  self.savedRenderStyle = nil
  self.isSwitchedHDRPlus = nil
  self._pendingEnterHDRSwitch = false
end

function NewCamera_IngameSelfieSubsystem:GetIsSwitchedHDRPlus()
  return self.isSwitchedHDRPlus
end

function NewCamera_IngameSelfieSubsystem:_SetSelfCVarEnable(enabled)
  self:_SetTargetCVarEnable("r.MobileNumDynamicPointLights", 4, enabled)
  self:_SetTargetCVarEnable("r.Mobile.EnableMovableSpotlights", 1, enabled)
end

function NewCamera_IngameSelfieSubsystem:_SetTargetCVarEnable(keyName, targetValue, enabled)
  local gameInstance = UIUtil.GetGameInstance()
  if not slua.isValid(gameInstance) or not gameInstance.ExecuteCMD then
    return
  end
  local cmdKey = string.format("%s", keyName)
  local saveField = string.format("_savedCVar_%s", keyName)
  local settingValue
  if enabled then
    if self[saveField] == nil then
      self[saveField] = KismetSystemLibrary.GetConsoleVariableIntValue(cmdKey)
    end
    settingValue = targetValue
  elseif self[saveField] then
    settingValue = self[saveField]
  end
  if settingValue then
    gameInstance:ExecuteCMD(cmdKey, tostring(settingValue))
    log_format("NewCamera_IngameSelfieSubsystem:_SetTargetCVarEnable set %s to %d", cmdKey, settingValue)
  end
  if not enabled then
    self[saveField] = nil
  end
end

function NewCamera_IngameSelfieSubsystem:_GetParam(key, defaultVal)
  if not self._cameraParams then
    self._cameraParams = {}
  end
  local val = self._cameraParams[key]
  if val == nil then
    val = defaultVal
    self._cameraParams[key] = val
  end
  printf("NewCamera_IngameSelfieSubsystem:_GetParam - %s = %s", key, val)
  return val
end

function NewCamera_IngameSelfieSubsystem:_SetParam(key, val)
  printf("NewCamera_IngameSelfieSubsystem:_SetParam - %s = %s", key, val)
  if not self._cameraParams then
    self._cameraParams = {}
  end
  self._cameraParams[key] = val
end

function NewCamera_IngameSelfieSubsystem:GetCameraParamsSnapshot()
  if not self._cameraParams then
    return {}
  end
  local snapshot = {}
  for k, v in pairs(self._cameraParams) do
    snapshot[k] = v
  end
  return snapshot
end

function NewCamera_IngameSelfieSubsystem:RestoreCameraParamsFromSnapshot(snapshot)
  if not snapshot then
    return
  end
  self._cameraParams = {}
  for k, v in pairs(snapshot) do
    self._cameraParams[k] = v
  end
end

function NewCamera_IngameSelfieSubsystem:ClearCameraParams()
  self._cameraParams = nil
end

function NewCamera_IngameSelfieSubsystem:CheckIsPlayerInInteractiveState()
  local uPS = GameplayData.GetPlayerState()
  if not slua.isValid(uPS) then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckIsPlayerInInteractiveState playerState is invalid")
    return false
  end
  if uPS.IsInteractiveStateIdle and not uPS:IsInteractiveStateIdle() then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckIsPlayerInInteractiveState not IsInteractiveStateIdle")
    return true
  end
  if uPS.IsInTransportState and uPS:IsInTransportState() then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckIsPlayerInInteractiveState IsInTransportState")
    return true
  end
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckIsPlayerInInteractiveState false")
  return false
end

function NewCamera_IngameSelfieSubsystem:IsInSmartCamera()
  return self.isInSmartCamera
end

function NewCamera_IngameSelfieSubsystem:GetSavedWeatherValue()
  return self.savedWeatherValue
end

function NewCamera_IngameSelfieSubsystem:CheckCanFaceToPlayer()
  if self.bSuppressResetCameraToFacePlayer then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckCanFaceToPlayer suppressed by external scene")
    return false
  end
  if self:CheckIsPlayerInInteractiveState() then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckCanFaceToPlayer - in interactive state")
    return false
  end
  if self:IsInVehicle() then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckCanFaceToPlayer - in vehicle")
    return false
  end
  if self:IsOnCableCar() then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckCanFaceToPlayer - on cable car")
    return false
  end
  if NewCameraUtil.IsInRoleSwitchState() then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckCanFaceToPlayer - in role switch")
    return false
  end
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckCanFaceToPlayer - can face to player")
  return true
end

function NewCamera_IngameSelfieSubsystem:IsOnCableCar()
  local playerCharacter = GameplayData.GetPlayerCharacter()
  if not slua.isValid(playerCharacter) then
    return false
  end
  local characterMovement = playerCharacter.STCharacterMovement
  if not slua.isValid(characterMovement) then
    return false
  end
  local currentFloor = characterMovement.CurrentFloor
  if not currentFloor or not currentFloor.bBlockingHit then
    return false
  end
  local groundActor = currentFloor.HitResult.Actor
  if not slua.isValid(groundActor) then
    return false
  end
  local CableCarClass = slua.loadClass("/Game/Mod/BRMod/BluePrints/Actor/BP_CableCar.BP_CableCar")
  return slua.isValid(CableCarClass) and Game:IsClassOf(groundActor, CableCarClass)
end

function NewCamera_IngameSelfieSubsystem:CheckUseRoleSocketOffset()
  if self:IsInVehicle() then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckUseRoleSocketOffset - in vehicle")
    return false
  end
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckUseRoleSocketOffset - use role socket offset")
  return true
end

function NewCamera_IngameSelfieSubsystem:IsInVehicle()
  local PlayerCharacter = GameplayData.GetPlayerCharacter()
  if slua.isValid(PlayerCharacter) then
    local isInVehicle = PlayerCharacter:HasState(EPawnState.InVehicle) or PlayerCharacter:HasState(EPawnState.DriveVehicle)
    return isInVehicle
  end
  return false
end

function NewCamera_IngameSelfieSubsystem:GetDefaultNeedHideEnemy()
  return true
end

function NewCamera_IngameSelfieSubsystem:CheckNeedResetToOriginSpringArmLength()
  if self:CheckIsPlayerInInteractiveState() then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckNeedResetToOriginSpringArmLength - in interactive state")
    return false
  end
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckNeedResetToOriginSpringArmLength - need reset")
  return true
end

function NewCamera_IngameSelfieSubsystem:GetTargetArmLength()
  local armLength = self.savedInitialArmLength
  if not self:CheckCanFaceToPlayer() then
    armLength = self.originArmLength
  end
  armLength = armLength or NewCameraConfig.CCameraDefaultArmLength
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:GetTargetArmLength - return arm length: " .. armLength)
  return armLength
end

function NewCamera_IngameSelfieSubsystem:GetTargetSocketOffset()
  local socketOffset = self.savedInitialSocketOffset
  if not self:CheckUseRoleSocketOffset() then
    socketOffset = self.originSocketOffset
  end
  printf("NewCamera_IngameSelfieSubsystem:GetTargetSocketOffset - return socket offset: %s", getContainerParamLog(socketOffset, vectorParamList))
  return socketOffset
end

function NewCamera_IngameSelfieSubsystem:_WriteSocketOffsetToSpringArm(targetSocketOffset)
  local bUseRoleSocketOffset = self:CheckUseRoleSocketOffset()
  local uSpringArmForLog, charSpringArmForLog
  local playerControllerForLog = GameplayData.GetPlayerController()
  if slua.isValid(playerControllerForLog) then
    uSpringArmForLog = playerControllerForLog:GetTargetedSpringArm()
  end
  local charForLog = GameplayData.GetPlayerCharacter()
  if slua.isValid(charForLog) then
    charSpringArmForLog = charForLog.SpringArmComp
  end
  printf("NewCamera_IngameSelfieSubsystem:_WriteSocketOffsetToSpringArm bUseRoleSocketOffset:%s, offset:(%s,%s,%s), targeted:%s, springArmComp:%s, same:%s", tostring(bUseRoleSocketOffset), tostring(targetSocketOffset.X), tostring(targetSocketOffset.Y), tostring(targetSocketOffset.Z), tostring(uSpringArmForLog), tostring(charSpringArmForLog), tostring(uSpringArmForLog ~= nil and uSpringArmForLog == charSpringArmForLog))
  if bUseRoleSocketOffset then
    local PhotoGrapherSubSystem = SubsystemMgr:Get("PhotoGrapherSubSystem")
    local playerCharacter = GameplayData.GetPlayerCharacter()
    if PhotoGrapherSubSystem and PhotoGrapherSubSystem.SetCharacterSocketOffset and slua.isValid(playerCharacter) then
      PhotoGrapherSubSystem:SetCharacterSocketOffset(targetSocketOffset, playerCharacter)
    end
    return
  end
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerController) then
    return
  end
  local uSpringArm = playerController:GetTargetedSpringArm()
  if slua.isValid(uSpringArm) then
    uSpringArm.SocketOffset = targetSocketOffset
  end
end

function NewCamera_IngameSelfieSubsystem:CheckCanShowPhotoEntrance()
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerController) then
    return false
  end
  if playerController:IsObserver() or playerController:IsSpectator() then
    log(bWriteLog and "NewCamera_IngameSelfieSubsystem:CheckCanShowPhotoEntrance, playerController is observer or spectator")
    return false
  end
  return true
end

function NewCamera_IngameSelfieSubsystem:_ReportEnterTlog()
  local source = self:GetTLogEntrySource()
  NewCameraTLogReport.ReportEnterSelfie(source, NewCameraTLogReport.EModeType.Camera)
end

function NewCamera_IngameSelfieSubsystem:_ReportExitTLog(reason)
  reason = reason or NewCameraTLogReport.EExitReason.Abnormal
  local source = self:GetTLogEntrySource()
  NewCameraTLogReport.ReportExitSelfie(source, NewCameraTLogReport.EModeType.Camera, self.stayTime, self.totalPhotoCount, reason)
end

function NewCamera_IngameSelfieSubsystem:GetTLogEntrySource()
  return NewCameraTLogReport.EEnterSource.InBattle
end

function NewCamera_IngameSelfieSubsystem:StartStayTimer()
  self:ClearStayTimer()
  self.stayTime = 0
  self.stayTimeCountTimer = self:AddTimerLoop(1, function()
    self.stayTime = self.stayTime + 1
  end, TIMER_INFINITE, 1)
end

function NewCamera_IngameSelfieSubsystem:ClearStayTimer()
  if self.stayTimeCountTimer then
    self:RemoveTimer(self.stayTimeCountTimer)
    self.stayTimeCountTimer = nil
  end
end

function NewCamera_IngameSelfieSubsystem:OpenNewCameraPhotoUI()
  log(bWriteLog and "NewCamera_IngameSelfieSubsystem:OpenNewCameraPhotoUI")
  local moment_macro = require("client.slua.logic.moment.moment_macro")
  local ENUM_ALBUM_PHOTO_TAB_TYPE = moment_macro.ENUM_ALBUM_PHOTO_TAB_TYPE
  local params = {
    openSource = NewCameraTLogReport.EPhotoOpenSourceType.Photo,
    photoCombobox = ENUM_ALBUM_PHOTO_TAB_TYPE.All
  }
  UIManager.ShowUI(UIManager.UI_Config.UI_Moment_Main_UIBP, params)
end

local class = require("class")
local IngameSelfieSubsystem = require("GameLua.Mod.Library.GamePlay.Camera.IngameSelfieSubsystem")
local MergePatialTool = require("GameLua.Mod.SocialIsland.GamePlay.MergePatialTool")
MergePatialTool.Mixin(IngameSelfieSubsystem, NewCamera_IngameSelfieSubsystem, require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieSubsystem_DurationCache"))
MergePatialTool.Mixin(IngameSelfieSubsystem, NewCamera_IngameSelfieSubsystem, require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieSubsystem_Drone"))
MergePatialTool.Mixin(IngameSelfieSubsystem, NewCamera_IngameSelfieSubsystem, require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieSubsystem_Emotion"))
MergePatialTool.Mixin(IngameSelfieSubsystem, NewCamera_IngameSelfieSubsystem, require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieSubsystem_BaseSettings"))
MergePatialTool.Mixin(IngameSelfieSubsystem, NewCamera_IngameSelfieSubsystem, require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieSubsystem_Components"))
MergePatialTool.Mixin(IngameSelfieSubsystem, NewCamera_IngameSelfieSubsystem, require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieSubsystem_PostProcess"))
MergePatialTool.Mixin(IngameSelfieSubsystem, NewCamera_IngameSelfieSubsystem, require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieSubsystem_Net"))
MergePatialTool.Mixin(IngameSelfieSubsystem, NewCamera_IngameSelfieSubsystem, require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieSubsystem_Light"))
MergePatialTool.Mixin(IngameSelfieSubsystem, NewCamera_IngameSelfieSubsystem, require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieSubsystem_XLSConfig"))
return class(IngameSelfieSubsystem, nil, NewCamera_IngameSelfieSubsystem)
