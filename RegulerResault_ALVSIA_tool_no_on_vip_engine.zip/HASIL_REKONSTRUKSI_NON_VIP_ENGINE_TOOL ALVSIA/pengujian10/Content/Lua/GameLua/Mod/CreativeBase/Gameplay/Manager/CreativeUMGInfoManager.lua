local CreativeUMGInfoManager = {}
local BinaryAssetTool = require("GameLua.Mod.CreativeBase.BinaryData.BinaryAssetTool")
local PBUtility = require("GameLua.Mod.CreativeBase.BinaryData.CreativeModePbUtility")
local CreativeUMGUploadDefine = require("GameLua.Mod.CreativeBase.Gameplay.Config.CreativeCustomUI.CreativeUMGUploadDefine")
local CustomUIDefine = require("GameLua.Mod.CreativeBase.Client.CreativeCustomUI.CustomUIDefine")
local CreativeBinaryDataVersionConfig = require("GameLua.Mod.CreativeBase.BinaryData.Config.CreativeBinaryDataVersionConfig")
local Utility = require("GameLua.Mod.CreativeBase.Gameplay.Meta.CreativeModeUtility")
local TableUtil = require("common.table_util")
_G.EnableUMGInfoManager = true

function CreativeUMGInfoManager:ctor()
  self._UMGInfoTreeMap = {}
  self.bLoadIntermediateDataSuc = false
  self._PendingUMGImportTaskMap = {}
  self._UMGImportSyncIdToTaskMap = {}
  self.bClientUMGInfoTreePrebuilt = false
end

function CreativeUMGInfoManager:ManagerInitializeCompleteInit()
  self:AddCommonEvent(EVENTTYPE_CREATIVE, EVENTID_UMGINFO_SYNC_COMPLETE, self._OnUMGInfoSyncComplete, self)
  if self:IsUMGInfoSyncComplete() then
    self:_OnUMGInfoSyncComplete()
  end
end

function CreativeUMGInfoManager:_OnUMGInfoSyncComplete()
  if self._bUMGInfoSyncCompleteHandled then
    return
  end
  self._bUMGInfoSyncCompleteHandled = true
  local TreeCount = 0
  for _ in pairs(self._UMGInfoTreeMap) do
    TreeCount = TreeCount + 1
  end
  print("[UMGInfoSyncComplete] CreativeUMGInfoManager:_OnUMGInfoSyncComplete HasAuthority:" .. tostring(self:HasAuthority()) .. " TreeCount:" .. tostring(TreeCount))
end

function CreativeUMGInfoManager:OnReceivePostUMGInfoAdd(DataID, Content)
  self:_ParseUMGInfoTree(DataID, Content)
  self:_CheckUMGImportSyncComplete(DataID)
  self:_BroadcastUMGInfoMapChanged(DataID, "add")
end

function CreativeUMGInfoManager:OnReceivePostUMGInfoChange(DataID, Content)
  self:_ParseUMGInfoTree(DataID, Content)
  self:_CheckUMGImportSyncComplete(DataID)
  self:_BroadcastUMGInfoMapChanged(DataID, "change")
end

function CreativeUMGInfoManager:OnReceivePreUMGInfoRemove(DataID)
  self._UMGInfoTreeMap[DataID] = nil
  self:_BroadcastUMGInfoMapChanged(DataID, "remove")
end

function CreativeUMGInfoManager:_BroadcastUMGInfoMapChanged(DataID, Action)
  if EVENTID_UMGINFO_MAP_CHANGED then
    EventSystem:postEvent(EVENTTYPE_CREATIVE, EVENTID_UMGINFO_MAP_CHANGED, DataID, Action)
  end
end

function CreativeUMGInfoManager:_ParseUMGInfoTree(DataID, Content)
  if Content == nil then
    return
  end
  local BinaryData = BinaryAssetTool.UnPackBinaryAsset(Content)
  if BinaryData == nil or BinaryData.InstanceTree == nil then
    return
  end
  self._UMGInfoTreeMap[DataID] = BinaryData.InstanceTree
end

function CreativeUMGInfoManager:PackUMGInfoTree(InstanceTree)
  if InstanceTree == nil then
    return nil
  end
  return BinaryAssetTool.PackBinaryAsset({InstanceTree = InstanceTree})
end

function CreativeUMGInfoManager:ReceiveOnGameStateBeginPlay()
  if self:HasAuthority() and _G.EnableUMGInfoManager then
    self:AddCommonEvent(EVENTTYPE_INGAME_CREATIVE_MODE, EVENTID_INTERMEDIATE_DATA_LOADED, self._OnIntermediateDataLoaded, self)
    self:AddCommonEvent(EVENTTYPE_INGAME_CREATIVE_MODE, EVENTID_CLASSIFY_BINARY_DATA_LOADED, self._OnClassifyIntermediateDataLoaded, self)
    self:_OnIntermediateDataLoaded()
  end
end

function CreativeUMGInfoManager:_OnClassifyIntermediateDataLoaded(_, _, flagSet, BinData)
  print(bWriteLog and "CreativeUMGInfoManager:_OnClassifyIntermediateDataLoaded")
  if flagSet == nil or next(flagSet) == nil then
    return
  end
  local needUpdate = flagSet.all == true or flagSet.customui == true
  if not needUpdate then
    print(bWriteLog and "CreativeUMGInfoManager:_OnClassifyIntermediateDataLoaded skipped by flagSet (no customui/all)")
    return
  end
  local NewUMGInfoMap = BinData and BinData.UMGInfoMap or nil
  if NewUMGInfoMap == nil then
    local BinaryDataMgr = GetBinaryDataManager()
    local LoadedBinaryData = BinaryDataMgr ~= nil and BinaryDataMgr:GetLoadedBinaryData() or nil
    self:_MigrateUMGInfoFromInstanceTree(LoadedBinaryData)
    NewUMGInfoMap = LoadedBinaryData and LoadedBinaryData.UMGInfoMap or nil
  else
  end
  NewUMGInfoMap = NewUMGInfoMap or {}
  local NewKeySet = {}
  for UMGInfoID, _ in pairs(NewUMGInfoMap) do
    local KeyNum = tonumber(UMGInfoID)
    if KeyNum ~= nil then
      NewKeySet[KeyNum] = true
    end
  end
  local ToRemove = {}
  for ExistKey, _ in pairs(self._UMGInfoTreeMap) do
    local ExistKeyNum = tonumber(ExistKey) or ExistKey
    if not NewKeySet[ExistKeyNum] then
      ToRemove[#ToRemove + 1] = ExistKey
    end
  end
  local RemovedCount = 0
  for _, Key in ipairs(ToRemove) do
    self:RemoveUMGInfo(Key)
    RemovedCount = RemovedCount + 1
  end
  local AddedCount = 0
  for UMGInfoID, DataContent in pairs(NewUMGInfoMap) do
    local KeyNum = tonumber(UMGInfoID) or UMGInfoID
    self:AddUMGInfo(KeyNum, DataContent)
    AddedCount = AddedCount + 1
  end
  self.bLoadIntermediateDataSuc = true
  self:UpdateModBinUMGInfoCount()
  print(bWriteLog and string.format("CreativeUMGInfoManager:_OnClassifyIntermediateDataLoaded done, Removed:%d Added:%d", RemovedCount, AddedCount))
end

function CreativeUMGInfoManager:_OnIntermediateDataLoaded()
  local BinaryDataMgr = GetBinaryDataManager()
  local LoadedBinaryData
  if BinaryDataMgr ~= nil then
    LoadedBinaryData = BinaryDataMgr:GetLoadedBinaryData()
  end
  if LoadedBinaryData == nil then
    return
  end
  self:_MigrateUMGInfoFromInstanceTree(LoadedBinaryData)
  local LoadedUMGInfoMap = LoadedBinaryData.UMGInfoMap
  if LoadedUMGInfoMap ~= nil then
    for UMGInfoID, DataContent in pairs(LoadedUMGInfoMap) do
      self:AddUMGInfo(UMGInfoID, DataContent)
    end
  end
  self.bLoadIntermediateDataSuc = true
  self:UpdateModBinUMGInfoCount()
end

function CreativeUMGInfoManager:_MigrateUMGInfoFromInstanceTree(LoadedBinaryData)
  if not self:HasAuthority() then
    return
  end
  local ECreativeModeGameType = import("ECreativeModeGameType")
  if not (CGameState and slua.isValid(CGameState)) or CGameState:GetCurrentGameType() ~= ECreativeModeGameType.CreativeModeGameType_Editor then
    return
  end
  local InstanceTree = LoadedBinaryData and LoadedBinaryData.InstanceTree
  if not InstanceTree then
    return
  end
  if LoadedBinaryData.UMGInfoMap and next(LoadedBinaryData.UMGInfoMap) then
    return
  end
  local CanvasIds = {}
  for Id, Instance in pairs(InstanceTree) do
    if Instance and Instance.UMGCanvasInfo then
      if Instance.CustomUIBase then
        Instance.UMGCanvasInfo = nil
      else
        CanvasIds[#CanvasIds + 1] = Id
      end
    end
  end
  if #CanvasIds == 0 then
    return
  end
  self:_ReconcileCanvasOwnershipBeforeMigrate(InstanceTree)
  local InstanceMgr = self:GetInstanceManager()
  LoadedBinaryData.UMGInfoMap = {}
  for _, CanvasId in ipairs(CanvasIds) do
    self:_MigrateOneCanvas(CanvasId, InstanceTree, LoadedBinaryData.UMGInfoMap)
  end
  self:_ClearAllUINodes(InstanceTree, InstanceMgr)
end

function CreativeUMGInfoManager:_ClearAllUINodes(InstanceTree, InstanceMgr)
  local RemovedCount = 0
  local ToRemove = {}
  for Id, Instance in pairs(InstanceTree) do
    if Instance and (Instance.UMGCanvasInfo or Instance.CustomUIBase) then
      ToRemove[#ToRemove + 1] = Id
    end
  end
  for _, Id in ipairs(ToRemove) do
    InstanceTree[Id] = nil
    if InstanceMgr and InstanceMgr:GetInstance(Id) then
      InstanceMgr:TryRemoveInstance(Id)
    end
    RemovedCount = RemovedCount + 1
  end
  print(bWriteLog and "CreativeUMGInfoManager:_ClearAllUINodes RemovedCount:" .. tostring(RemovedCount))
end

function CreativeUMGInfoManager:_ReconcileCanvasOwnershipBeforeMigrate(InstanceTree)
  if not InstanceTree then
    return 0
  end
  local ByStr = {}
  local KeyOf = {}
  for InstanceKey, Instance in pairs(InstanceTree) do
    if Instance then
      local KeyStr = tostring(InstanceKey)
      ByStr[KeyStr] = Instance
      KeyOf[KeyStr] = InstanceKey
      local FieldStr = Instance.InstanceId and tostring(Instance.InstanceId) or nil
      if FieldStr and not ByStr[FieldStr] then
        ByStr[FieldStr] = Instance
        KeyOf[FieldStr] = InstanceKey
      end
    end
  end
  
  local function ReadChildren(Instance)
    local ObjectGroup = Instance and Instance.ObjectGroup or nil
    local Children = ObjectGroup and ObjectGroup.Children or nil
    if not Children then
      return {}
    end
    return Children.overrides or Children
  end
  
  local CanvasList = {}
  for IdStr, Instance in pairs(ByStr) do
    if Instance.UMGCanvasInfo and not Instance.CustomUIBase then
      CanvasList[#CanvasList + 1] = {IdStr = IdStr, Instance = Instance}
    end
  end
  if #CanvasList == 0 then
    return 0
  end
  table.sort(CanvasList, function(a, b)
    local bADefault = a.Instance.UMGCanvasInfo.CanvasType == 1
    local bBDefault = b.Instance.UMGCanvasInfo.CanvasType == 1
    if bADefault ~= bBDefault then
      return bADefault
    end
    return a.IdStr < b.IdStr
  end)
  local ParentOf = {}
  for IdStr, Instance in pairs(ByStr) do
    if Instance.CustomUIBase or Instance.UMGCanvasInfo then
      local Children = ReadChildren(Instance)
      for _, ChildId in ipairs(Children) do
        ParentOf[tostring(ChildId)] = IdStr
      end
    end
  end
  local Visited = {}
  local PhysicalSet = {}
  local OwnerParent = {}
  
  local function CollectSubtree(RootIdStr, TargetSet)
    local Stack = {RootIdStr}
    while 0 < #Stack do
      local CurStr = table.remove(Stack)
      local Inst = ByStr[CurStr]
      if Inst then
        local Children = ReadChildren(Inst)
        for _, ChildId in ipairs(Children) do
          local ChildStr = tostring(ChildId)
          local ChildInst = ByStr[ChildStr]
          if ChildInst and ChildInst.CustomUIBase and not Visited[ChildStr] then
            Visited[ChildStr] = true
            OwnerParent[ChildStr] = Inst
            TargetSet[ChildStr] = true
            Stack[#Stack + 1] = ChildStr
          end
        end
      end
    end
  end
  
  for _, CanvasInfo in ipairs(CanvasList) do
    PhysicalSet[CanvasInfo.IdStr] = {}
    CollectSubtree(CanvasInfo.IdStr, PhysicalSet[CanvasInfo.IdStr])
  end
  local OrphanRoots = {}
  for IdStr, Instance in pairs(ByStr) do
    if Instance.CustomUIBase and not Visited[IdStr] then
      local Cur = IdStr
      local Guard = 0
      local Walked = {
        [IdStr] = true
      }
      while Guard < 100 do
        Guard = Guard + 1
        local ParentStr = ParentOf[Cur]
        if not (ParentStr and ByStr[ParentStr]) or Visited[ParentStr] then
          break
        end
        local ParentInst = ByStr[ParentStr]
        if not ParentInst.CustomUIBase or Walked[ParentStr] then
          break
        end
        Walked[ParentStr] = true
        Cur = ParentStr
      end
      OrphanRoots[Cur] = true
    end
  end
  local FixOrphanCount = 0
  for RootStr in pairs(OrphanRoots) do
    local TargetCanvas
    for _, CanvasInfo in ipairs(CanvasList) do
      local AllWidgets = CanvasInfo.Instance.UMGCanvasInfo.AllWidgets
      if AllWidgets and AllWidgets.overrides then
        AllWidgets = AllWidgets.overrides
      end
      if type(AllWidgets) == "table" then
        for _, WId in ipairs(AllWidgets) do
          if tostring(WId) == RootStr then
            TargetCanvas = CanvasInfo
            break
          end
        end
      end
      if TargetCanvas then
        break
      end
    end
    if not TargetCanvas then
      local FieldCanvasId = ByStr[RootStr].CustomUIBase.CanvasID
      if FieldCanvasId then
        local FieldStr = tostring(FieldCanvasId)
        for _, CanvasInfo in ipairs(CanvasList) do
          if CanvasInfo.IdStr == FieldStr then
            TargetCanvas = CanvasInfo
            break
          end
        end
      end
    end
    TargetCanvas = TargetCanvas or CanvasList[1]
    local OldChildren = ReadChildren(TargetCanvas.Instance)
    local bAlreadyIn = false
    for _, ChildId in ipairs(OldChildren) do
      if tostring(ChildId) == RootStr then
        bAlreadyIn = true
        break
      end
    end
    if not bAlreadyIn then
      local NewChildren = {}
      for Index = 1, #OldChildren do
        NewChildren[Index] = OldChildren[Index]
      end
      NewChildren[#NewChildren + 1] = KeyOf[RootStr]
      if not TargetCanvas.Instance.ObjectGroup then
        TargetCanvas.Instance.ObjectGroup = {}
      end
      TargetCanvas.Instance.ObjectGroup.Children = {overrides = NewChildren}
    end
    ParentOf[RootStr] = TargetCanvas.IdStr
    OwnerParent[RootStr] = TargetCanvas.Instance
    Visited[RootStr] = true
    PhysicalSet[TargetCanvas.IdStr][RootStr] = true
    CollectSubtree(RootStr, PhysicalSet[TargetCanvas.IdStr])
    FixOrphanCount = FixOrphanCount + 1
  end
  local ParentRefFixList = {}
  for InstanceKey, Instance in pairs(InstanceTree) do
    if Instance and (Instance.CustomUIBase or Instance.UMGCanvasInfo) then
      local OldChildren = ReadChildren(Instance)
      if 0 < #OldChildren then
        local NewChildren = {}
        local SeenChild = {}
        local bChanged = false
        for _, ChildId in ipairs(OldChildren) do
          local ChildStr = tostring(ChildId)
          local ChildInst = ByStr[ChildStr]
          local bKeep = ChildInst ~= nil and not SeenChild[ChildStr] and (not ChildInst.CustomUIBase or OwnerParent[ChildStr] == Instance)
          if bKeep then
            SeenChild[ChildStr] = true
            NewChildren[#NewChildren + 1] = ChildId
          else
            bChanged = true
          end
        end
        if bChanged then
          ParentRefFixList[#ParentRefFixList + 1] = {Key = InstanceKey, NewChildren = NewChildren}
        end
      end
    end
  end
  for _, Fix in ipairs(ParentRefFixList) do
    local Instance = InstanceTree[Fix.Key]
    Instance.ObjectGroup.Children = {
      overrides = Fix.NewChildren
    }
  end
  local FixParentRefCount = #ParentRefFixList
  local FixCanvasIdCount = 0
  for _, CanvasInfo in ipairs(CanvasList) do
    for WidgetStr in pairs(PhysicalSet[CanvasInfo.IdStr]) do
      local CustomUIBase = ByStr[WidgetStr].CustomUIBase
      if CanvasInfo.IdStr ~= tostring(CustomUIBase.CanvasID or "") then
        CustomUIBase.CanvasID = CanvasInfo.IdStr
        FixCanvasIdCount = FixCanvasIdCount + 1
      end
    end
  end
  local FixAllWidgetsCount = 0
  for _, CanvasInfo in ipairs(CanvasList) do
    local Set = PhysicalSet[CanvasInfo.IdStr]
    local AllWidgets = CanvasInfo.Instance.UMGCanvasInfo.AllWidgets
    if AllWidgets and AllWidgets.overrides then
      AllWidgets = AllWidgets.overrides
    end
    local OldList = type(AllWidgets) == "table" and AllWidgets or {}
    local NewList = {}
    local SeenSet = {}
    local DropOrDupCount = 0
    for _, WId in ipairs(OldList) do
      local Key = tostring(WId)
      if Set[Key] and not SeenSet[Key] then
        SeenSet[Key] = true
        NewList[#NewList + 1] = WId
      else
        DropOrDupCount = DropOrDupCount + 1
      end
    end
    local Newcomers = {}
    for WidgetStr in pairs(Set) do
      if not SeenSet[WidgetStr] then
        Newcomers[#Newcomers + 1] = WidgetStr
      end
    end
    if 0 < DropOrDupCount or 0 < #Newcomers then
      table.sort(Newcomers, function(a, b)
        local LayerA = tonumber(ByStr[a].CustomUIBase and ByStr[a].CustomUIBase.Layer) or 0
        local LayerB = tonumber(ByStr[b].CustomUIBase and ByStr[b].CustomUIBase.Layer) or 0
        if LayerA ~= LayerB then
          return LayerA < LayerB
        end
        return a < b
      end)
      for _, WidgetStr in ipairs(Newcomers) do
        NewList[#NewList + 1] = WidgetStr
      end
      CanvasInfo.Instance.UMGCanvasInfo.AllWidgets = {overrides = NewList}
      FixAllWidgetsCount = FixAllWidgetsCount + 1
    end
  end
  local TotalFix = FixOrphanCount + FixParentRefCount + FixCanvasIdCount + FixAllWidgetsCount
  if 0 < TotalFix then
    print(string.format("CreativeUMGInfoManager:_ReconcileCanvasOwnershipBeforeMigrate fixed: OrphanAttach=%d ParentRef=%d CanvasID=%d AllWidgetsCanvas=%d", FixOrphanCount, FixParentRefCount, FixCanvasIdCount, FixAllWidgetsCount))
  end
  return TotalFix
end

function CreativeUMGInfoManager:_MigrateOneCanvas(CanvasId, InstanceTree, UMGInfoMap)
  print(bWriteLog and "CreativeUMGInfoManager:_MigrateOneCanvas", CanvasId)
  local Canvas = InstanceTree[CanvasId]
  if not Canvas or not Canvas.UMGCanvasInfo then
    return
  end
  local Key = tonumber(Canvas.UMGCanvasInfo.CDOInstanceID) or tonumber(CanvasId)
  if not Key then
    return
  end
  local AllWidgets = Canvas.UMGCanvasInfo.AllWidgets
  if AllWidgets and AllWidgets.overrides then
    AllWidgets = AllWidgets.overrides
  end
  local SubTree = {
    [CanvasId] = Canvas
  }
  local ValidWidgets = {}
  if type(AllWidgets) == "table" then
    for _, WidgetId in ipairs(AllWidgets) do
      local Widget = InstanceTree[WidgetId]
      if Widget and Widget.CustomUIBase then
        SubTree[WidgetId] = Widget
        ValidWidgets[#ValidWidgets + 1] = WidgetId
      end
    end
  end
  Canvas.UMGCanvasInfo.AllWidgets = {overrides = ValidWidgets}
  local Bytes = self:PackUMGInfoTree(SubTree)
  if Bytes then
    UMGInfoMap[Key] = Bytes
    print(bWriteLog and "CreativeUMGInfoManager:_MigrateOneCanvas UMGInfoMap Move Success", Key)
  end
end

function CreativeUMGInfoManager:GetSaveDataTree()
  local UMGInfoMap = {}
  for UMGInfoID, _ in pairs(self._UMGInfoTreeMap) do
    local DataContent = ""
    local bGetSuc = false
    bGetSuc, DataContent = self:GetUMGInfoContent(UMGInfoID, DataContent)
    if bGetSuc then
      UMGInfoMap[UMGInfoID] = DataContent
    end
  end
  return UMGInfoMap
end

function CreativeUMGInfoManager:HasAnyUMGInfo()
  return self._UMGInfoTreeMap ~= nil and next(self._UMGInfoTreeMap) ~= nil
end

function CreativeUMGInfoManager:UpdateNeedCustomUIDownloadParam()
  local GameParameterManager = GetGameParameterManager and GetGameParameterManager() or nil
  if GameParameterManager == nil then
    print(bWriteLog and "CreativeUMGInfoManager:UpdateNeedCustomUIDownloadParam GameParameterManager is nil, skip")
    return
  end
  local bNeedDownload = self:HasAnyUMGInfo()
  GameParameterManager:SetOneGameParameters("bNeedCustomUIDownload", bNeedDownload)
  print(bWriteLog and "CreativeUMGInfoManager:UpdateNeedCustomUIDownloadParam bNeedDownload:" .. tostring(bNeedDownload))
end

function CreativeUMGInfoManager:CollectDependsFromUMGInfoMap(BinData)
  local UMGInfoMap = BinData.UMGInfoMap
  if UMGInfoMap == nil or next(UMGInfoMap) == nil then
    return nil, nil
  end
  local InstanceMgr = self:GetInstanceManager()
  if InstanceMgr == nil then
    print(bWriteLog and "CreativeUMGInfoManager:CollectDependsFromUMGInfoMap InstanceMgr is nil, skip")
    return nil, nil
  end
  local AssetMgr = GetAssetManager and GetAssetManager() or nil
  local SubSystem = SubsystemMgr and SubsystemMgr:Get("CreativeGameFeatureSubSystem") or nil
  if SubSystem == nil then
    print(bWriteLog and "CreativeUMGInfoManager:CollectDependsFromUMGInfoMap SubSystem is nil, skip")
    return nil, nil
  end
  local AssetIDs, ResIDMap
  local CollectedCount = 0
  for _, DataContent in pairs(UMGInfoMap) do
    if DataContent then
      local Success, BinaryData = xpcall(BinaryAssetTool.UnPackBinaryAsset, PBUtility.UGCPbErrorMessageHandler, DataContent)
      if Success and BinaryData and BinaryData.InstanceTree then
        for _, Instance in pairs(BinaryData.InstanceTree) do
          local TmpResMap = {}
          SubSystem:CollectAssetIDs(Instance, InstanceMgr, AssetMgr, TmpResMap)
          for AssetID, _ in pairs(TmpResMap) do
            AssetIDs = AssetIDs or {}
            AssetIDs[#AssetIDs + 1] = AssetID
          end
          local AssetConfig = AssetMgr and AssetMgr:GetAsset(Instance.AssetId) or nil
          if AssetConfig and AssetConfig.CollectDependConfig and AssetConfig.CollectDependConfig.CollectDependResIDs then
            local DependIDs = AssetConfig.CollectDependConfig.CollectDependResIDs(Instance, InstanceMgr, AssetConfig)
            if DependIDs then
              ResIDMap = ResIDMap or {}
              for ResType, ResList in pairs(DependIDs) do
                ResIDMap[ResType] = ResIDMap[ResType] or {}
                for _, ResID in pairs(ResList) do
                  table.insert(ResIDMap[ResType], ResID)
                end
              end
            end
          end
          CollectedCount = CollectedCount + 1
        end
      end
    end
  end
  print(bWriteLog and "[SaveModCost]CreativeUMGInfoManager:CollectDependsFromUMGInfoMap UMGInfoCount:" .. tostring(CollectedCount))
  return AssetIDs, ResIDMap
end

function CreativeUMGInfoManager:ExportUMGData(CanvasIDs)
  local TreeMap = self:GetAllUMGInfoTree() or {}
  local KeyList = {}
  if CanvasIDs and 0 < #CanvasIDs then
    KeyList = CanvasIDs
  else
    for Key, _ in pairs(TreeMap) do
      KeyList[#KeyList + 1] = Key
    end
  end
  local ExportInstanceTree = {}
  local CanvasCount = 0
  for _, Key in ipairs(KeyList) do
    local SubTree = TreeMap[Key]
    if SubTree then
      for InstId, Inst in pairs(SubTree) do
        if Inst then
          ExportInstanceTree[InstId] = Utility:DeepCopy(Inst)
        end
      end
      CanvasCount = CanvasCount + 1
    end
  end
  if CanvasCount == 0 then
    print(bWriteLog and "CreativeUMGInfoManager:ExportUMGData no canvas exported")
    return nil, nil
  end
  local PackGameParameter
  local CreativeModeTalentSubSystem = SubsystemMgr and SubsystemMgr:Get("CreativeModeTalentSubSystem") or nil
  if CreativeModeTalentSubSystem then
    for _, Inst in pairs(ExportInstanceTree) do
      if Inst and Inst.CustomUITalentNode then
        if PackGameParameter == nil then
          PackGameParameter = {
            TalentNodeArray = {
              Value = {}
            }
          }
        end
        local TalentNode = CreativeModeTalentSubSystem:GetTalentNodeByTalentNodeID(Inst.CustomUITalentNode.TalentID)
        if TalentNode then
          table.insert(PackGameParameter.TalentNodeArray.Value, TalentNode)
        end
      end
    end
  end
  local BinaryDataTable = {
    InstanceTree = ExportInstanceTree,
    BinaryVersion = CreativeBinaryDataVersionConfig.CurVersion
  }
  if PackGameParameter then
    BinaryDataTable.GameParameterData = {
      ["1"] = PackGameParameter
    }
  end
  local Buffer = BinaryAssetTool.PackBinaryAsset(BinaryDataTable)
  print(bWriteLog and string.format("CreativeUMGInfoManager:ExportUMGData CanvasCount:%d NodeCount:%d BufferLen:%s", CanvasCount, TableUtil.CountTable(ExportInstanceTree), tostring(Buffer and #Buffer or 0)))
  return BinaryDataTable, Buffer
end

function CreativeUMGInfoManager:UploadUMGData(Name, Desc, CanvasIDs, Callback)
  local EUploadUMGErrorCode = CreativeUMGUploadDefine.EUploadUMGErrorCode
  if not (Name and Name ~= "" and Desc) or Desc == "" then
    if Callback then
      Callback(EUploadUMGErrorCode.INVALID_NAME_OR_DESC)
    end
    return
  end
  local StringUtil = require("common.string_util")
  local CreativeModePrefabMallTextUtils = require("client.slua.umg.ugc.lobby.UGCPrefabMall.CreativeModePrefabMallTextUtils")
  local NameLen = StringUtil.GetCharactersLength(Name, 2)
  local DescLen = StringUtil.GetCharactersLength(Desc, 2)
  if NameLen > CreativeModePrefabMallTextUtils.MaxNameLen or DescLen > CreativeModePrefabMallTextUtils.MaxDescLen then
    print(bWriteLog and string.format("CreativeUMGInfoManager:UploadUMGData name/desc over limit, NameLen:%d DescLen:%d", NameLen, DescLen))
    if Callback then
      Callback(EUploadUMGErrorCode.INVALID_NAME_OR_DESC)
    end
    return
  end
  local BinaryDataTable, Buffer = self:ExportUMGData(CanvasIDs)
  if BinaryDataTable == nil or Buffer == nil then
    if Callback then
      Callback(EUploadUMGErrorCode.INVALID_UMG_DATA)
    end
    return
  end
  if #Buffer > CreativeUMGUploadDefine.MAX_UPLOAD_UMG_BIN_SIZE then
    print(bWriteLog and string.format("CreativeUMGInfoManager:UploadUMGData bin size %d exceeds limit %d", #Buffer, CreativeUMGUploadDefine.MAX_UPLOAD_UMG_BIN_SIZE))
    if Callback then
      Callback(EUploadUMGErrorCode.SIZE_EXCEED_LIMIT)
    end
    return
  end
  local CustomAssetDefine = require("common.CustomAsset.CustomAssetDefine")
  local logic_ugc_prefab_mall_private = require("client.slua.logic.ugc.PrefabMall.logic_ugc_prefab_mall_private")
  local SAVE_ERROR_CODE = logic_ugc_prefab_mall_private.SAVE_ERROR_CODE
  local ExtraData = {show_error_tips = true}
  logic_ugc_prefab_mall_private:SaveToMyPrivate(Name, nil, Desc, BinaryDataTable, CustomAssetDefine.ENUM_PREFAB_TYPE.CUSTOMUI, ExtraData, function(ErrorCode, MetaInfo)
    if ErrorCode == 0 then
      print(bWriteLog and "CreativeUMGInfoManager:UploadUMGData success, Name=" .. tostring(Name))
      if Callback then
        Callback(EUploadUMGErrorCode.SUCCESS)
      end
    elseif ErrorCode == SAVE_ERROR_CODE.RES_TIME_OUT or ErrorCode == SAVE_ERROR_CODE.ICON_TIME_OUT then
      if Callback then
        Callback(EUploadUMGErrorCode.UPLOAD_TIMEOUT)
      end
    elseif Callback then
      Callback(EUploadUMGErrorCode.OTHER)
    end
  end)
end

function CreativeUMGInfoManager:ImportUMGData(BinaryDataBuffer, Callback, ResourceName)
  local EImportUMGErrorCode = CreativeUMGUploadDefine.EImportUMGErrorCode
  if not _G.EnableUMGInfoManager then
    if Callback then
      Callback(nil, EImportUMGErrorCode.OTHER, nil)
    end
    return nil
  end
  if not Client then
    if Callback then
      Callback(nil, EImportUMGErrorCode.OTHER, nil)
    end
    return nil
  end
  if BinaryDataBuffer == nil or BinaryDataBuffer == "" then
    if Callback then
      Callback(nil, EImportUMGErrorCode.INVALID_UMG_DATA, nil)
    end
    return nil
  end
  return self:_ImportUMGData(BinaryDataBuffer, Callback, ResourceName)
end

function CreativeUMGInfoManager:_ImportUMGData(BinaryDataBuffer, Callback, ResourceName)
  local EImportUMGErrorCode = CreativeUMGUploadDefine.EImportUMGErrorCode
  local callOk, BinDataTable = xpcall(PBUtility.PbBufferUnPackToBinary, PBUtility.UGCPbErrorMessageHandler, BinaryDataBuffer)
  if not callOk or BinDataTable == nil then
    if Callback then
      Callback(nil, EImportUMGErrorCode.INVALID_UMG_DATA, nil)
    end
    return nil
  end
  local CanvasList, ErrCode = self:_NormalizeResToCanvasList(BinDataTable, ResourceName)
  if CanvasList == nil or #CanvasList == 0 then
    if Callback then
      Callback(nil, ErrCode or EImportUMGErrorCode.INVALID_UMG_DATA, nil)
    end
    return nil
  end
  local InstanceMgr = GetInstanceManager()
  if InstanceMgr == nil then
    if Callback then
      Callback(nil, EImportUMGErrorCode.OTHER, nil)
    end
    return nil
  end
  local PreCreatedKeys = {}
  local NormalizedMap = {}
  for _, Entry in ipairs(CanvasList) do
    local NewKey = InstanceMgr:GenerateUID()
    local Bytes = self:PackUMGInfoTree(Entry.SubTree)
    if Bytes then
      NormalizedMap[NewKey] = Bytes
      PreCreatedKeys[#PreCreatedKeys + 1] = NewKey
    end
  end
  if not next(NormalizedMap) then
    if Callback then
      Callback(nil, EImportUMGErrorCode.INVALID_UMG_DATA, nil)
    end
    return nil
  end
  local Bytes = PBUtility.BinaryPackToPbBuffer({UMGInfoMap = NormalizedMap})
  if Bytes == nil or Bytes == "" then
    if Callback then
      Callback(nil, EImportUMGErrorCode.INVALID_UMG_DATA, nil)
    end
    return nil
  end
  local GameplayData = require("GameLua.GameCore.Data.GameplayData")
  local uPlayerCtrl = GameplayData and GameplayData.GetPlayerController()
  if not slua.isValid(uPlayerCtrl) or not uPlayerCtrl.CreativeModeCustomUIFeature then
    if Callback then
      Callback(nil, EImportUMGErrorCode.OTHER, nil)
    end
    return nil
  end
  uPlayerCtrl.CreativeModeCustomUIFeature:RequestImportUMGInfoMap(Bytes, function(ImportErrorCode, AllNewKeys)
    if ImportErrorCode ~= EImportUMGErrorCode.SUCCESS or AllNewKeys == nil or #AllNewKeys == 0 then
      if Callback then
        Callback(nil, ImportErrorCode, AllNewKeys)
      end
      return
    end
    self:_RegisterPendingUMGImportTask(AllNewKeys, Callback)
  end)
  return PreCreatedKeys
end

function CreativeUMGInfoManager:_NormalizeResToCanvasList(BinDataTable, ResourceName)
  local EImportUMGErrorCode = CreativeUMGUploadDefine.EImportUMGErrorCode
  local InstanceMgr = GetInstanceManager()
  if InstanceMgr == nil then
    return nil, EImportUMGErrorCode.OTHER
  end
  local ResInstanceTree = BinDataTable.InstanceTree
  if ResInstanceTree == nil or not next(ResInstanceTree) then
    return nil, EImportUMGErrorCode.INVALID_UMG_DATA
  end
  local CanvasIds = {}
  local bHasWidget = false
  for Id, Inst in pairs(ResInstanceTree) do
    if Inst then
      if Inst.UMGCanvasInfo then
        if Inst.CustomUIBase then
          Inst.UMGCanvasInfo = nil
          bHasWidget = true
        else
          CanvasIds[#CanvasIds + 1] = Id
        end
      elseif Inst.CustomUIBase then
        bHasWidget = true
      end
    end
  end
  local CanvasList = {}
  if 0 < #CanvasIds then
    for _, CanvasId in ipairs(CanvasIds) do
      local Canvas = ResInstanceTree[CanvasId]
      local SubTree = {
        [CanvasId] = Canvas
      }
      local AllWidgets = InstanceMgr:GetObjectValue(nil, "UMGCanvasInfo.AllWidgets", Canvas)
      local ValidWidgets = {}
      if type(AllWidgets) == "table" then
        for _, WidgetId in ipairs(AllWidgets) do
          local Widget = ResInstanceTree[tonumber(WidgetId)] or ResInstanceTree[WidgetId]
          if Widget and Widget.CustomUIBase then
            SubTree[tonumber(WidgetId) or WidgetId] = Widget
            ValidWidgets[#ValidWidgets + 1] = WidgetId
          end
        end
      end
      Canvas.UMGCanvasInfo.AllWidgets = {overrides = ValidWidgets}
      CanvasList[#CanvasList + 1] = {SubTree = SubTree}
    end
  elseif bHasWidget then
    local Entry = self:_SynthesizeCanvasShell(ResInstanceTree, ResourceName)
    if Entry then
      CanvasList[#CanvasList + 1] = Entry
    end
  end
  if #CanvasList == 0 then
    return nil, EImportUMGErrorCode.INVALID_UMG_DATA
  end
  return CanvasList
end

function CreativeUMGInfoManager:_SynthesizeCanvasShell(ResInstanceTree, ResourceName)
  local InstanceMgr = GetInstanceManager()
  local AssetManager = GetAssetManager and GetAssetManager() or nil
  if InstanceMgr == nil or AssetManager == nil or AssetManager.GetDefaultUMGInfoAssetId == nil then
    print(bWriteLog and "CreativeUMGInfoManager:_SynthesizeCanvasShell InstanceMgr/AssetManager missing")
    return nil
  end
  local AssetId = AssetManager:GetDefaultUMGInfoAssetId()
  if AssetId == nil then
    print(bWriteLog and "CreativeUMGInfoManager:_SynthesizeCanvasShell GetDefaultUMGInfoAssetId nil")
    return nil
  end
  local ChildToParentMap = {}
  for _, Inst in pairs(ResInstanceTree) do
    local Children = InstanceMgr:GetObjectValue(nil, "ObjectGroup.Children", Inst)
    if Children then
      for _, ChildId in ipairs(Children) do
        ChildToParentMap[ChildId] = true
      end
    end
  end
  local NewCanvasId = InstanceMgr:GenerateUID()
  local SubTree = {}
  local RootIds = {}
  local AllWidgetIds = {}
  for InstId, Inst in pairs(ResInstanceTree) do
    if Inst.CustomUIBase then
      SubTree[InstId] = Inst
      AllWidgetIds[#AllWidgetIds + 1] = tostring(InstId)
      if not ChildToParentMap[InstId] and not ChildToParentMap[tostring(InstId)] then
        RootIds[#RootIds + 1] = tostring(InstId)
      end
    end
  end
  local CanvasNode = {
    AssetId = AssetId,
    UMGCanvasInfo = {
      CanvasName = ResourceName and ResourceName ~= "" and ResourceName or "Default",
      CanvasType = CustomUIDefine.UMGCanvasType.Dynamic,
      CanvasWidth = 916,
      CanvasHeight = 515,
      SortOrder = 0,
      AllWidgets = {overrides = AllWidgetIds},
      CDOInstanceID = tostring(NewCanvasId),
      Visible = true
    },
    ObjectGroup = {
      Children = {overrides = RootIds}
    }
  }
  SubTree[NewCanvasId] = CanvasNode
  return {SubTree = SubTree}
end

function CreativeUMGInfoManager:_RegisterPendingUMGImportTask(AllNewKeys, Callback)
  local EImportUMGErrorCode = CreativeUMGUploadDefine.EImportUMGErrorCode
  local FirstNewKey = AllNewKeys[1]
  local PendingIds = {}
  for _, Key in ipairs(AllNewKeys) do
    if self._UMGInfoTreeMap[Key] == nil then
      PendingIds[Key] = true
    end
  end
  if not next(PendingIds) then
    print(bWriteLog and "CreativeUMGInfoManager:_RegisterPendingUMGImportTask all synced, FirstNewKey:" .. tostring(FirstNewKey))
    if Callback then
      Callback(FirstNewKey, EImportUMGErrorCode.SUCCESS, AllNewKeys)
    end
    return
  end
  print(bWriteLog and "CreativeUMGInfoManager:_RegisterPendingUMGImportTask FirstNewKey:" .. tostring(FirstNewKey) .. " PendingCount:" .. tostring(TableUtil.CountTable(PendingIds)))
  local TimeoutHandle = self:AddGameTimer(15, false, function()
    local TaskInfo = self._PendingUMGImportTaskMap[FirstNewKey]
    if TaskInfo then
      for Key, _ in pairs(TaskInfo.PendingIds) do
        self._UMGImportSyncIdToTaskMap[Key] = nil
      end
      self._PendingUMGImportTaskMap[FirstNewKey] = nil
      if TaskInfo.Callback then
        TaskInfo.Callback(FirstNewKey, EImportUMGErrorCode.TIMEOUT, TaskInfo.AllNewKeys)
      end
    end
  end)
  self._PendingUMGImportTaskMap[FirstNewKey] = {
    PendingIds = PendingIds,
    AllNewKeys = AllNewKeys,
    Callback = Callback,
    TimeoutHandle = TimeoutHandle
  }
  for Key, _ in pairs(PendingIds) do
    self._UMGImportSyncIdToTaskMap[Key] = FirstNewKey
  end
end

function CreativeUMGInfoManager:_CheckUMGImportSyncComplete(DataID)
  if self._UMGInfoTreeMap[DataID] == nil then
    return
  end
  local TaskKey = self._UMGImportSyncIdToTaskMap[DataID]
  if TaskKey == nil then
    return
  end
  self._UMGImportSyncIdToTaskMap[DataID] = nil
  local TaskInfo = self._PendingUMGImportTaskMap[TaskKey]
  if TaskInfo == nil then
    return
  end
  TaskInfo.PendingIds[DataID] = nil
  if not next(TaskInfo.PendingIds) then
    print(bWriteLog and "CreativeUMGInfoManager:_CheckUMGImportSyncComplete all synced, TaskKey:" .. tostring(TaskKey))
    if TaskInfo.TimeoutHandle then
      self:RemoveGameTimer(TaskInfo.TimeoutHandle)
      TaskInfo.TimeoutHandle = nil
    end
    self._PendingUMGImportTaskMap[TaskKey] = nil
    if TaskInfo.Callback then
      TaskInfo.Callback(TaskKey, CreativeUMGUploadDefine.EImportUMGErrorCode.SUCCESS, TaskInfo.AllNewKeys)
    end
  end
end

function CreativeUMGInfoManager:_GetCanvasNodeOfSubTree(SubTree)
  for InstId, Inst in pairs(SubTree) do
    if Inst and Inst.UMGCanvasInfo and not Inst.CustomUIBase then
      return Inst, InstId
    end
  end
  return nil, nil
end

function CreativeUMGInfoManager:_ImportUMGInfoOnDS(CanvasSubTreeMap)
  local EImportUMGErrorCode = CreativeUMGUploadDefine.EImportUMGErrorCode
  if CanvasSubTreeMap == nil or not next(CanvasSubTreeMap) then
    return {}, EImportUMGErrorCode.INVALID_UMG_DATA
  end
  local Ctx = {MaxLayer = 0, bHasDefaultCanvas = false}
  local ExistingCanvasCount = 0
  local ExistingWidgetCount = 0
  for _, SubTree in pairs(self._UMGInfoTreeMap) do
    for _, Inst in pairs(SubTree) do
      if Inst then
        if Inst.UMGCanvasInfo and not Inst.CustomUIBase then
          ExistingCanvasCount = ExistingCanvasCount + 1
          if (tonumber(Inst.UMGCanvasInfo.CanvasType) or 0) == 1 then
            Ctx.bHasDefaultCanvas = true
          end
        elseif Inst.CustomUIBase then
          ExistingWidgetCount = ExistingWidgetCount + 1
          local Layer = tonumber(Inst.CustomUIBase.Layer) or 0
          if Layer > Ctx.MaxLayer then
            Ctx.MaxLayer = Layer
          end
        end
      end
    end
  end
  local SortedCanvases = {}
  local ImportWidgetCount = 0
  for Key, SubTree in pairs(CanvasSubTreeMap) do
    Key = tonumber(Key)
    if Key then
      local CanvasNode = self:_GetCanvasNodeOfSubTree(SubTree)
      if CanvasNode then
        SortedCanvases[#SortedCanvases + 1] = {
          Key = Key,
          SubTree = SubTree,
          SortOrder = tonumber(CanvasNode.UMGCanvasInfo.SortOrder) or 0
        }
      end
      for _, Inst in pairs(SubTree) do
        if Inst and Inst.CustomUIBase then
          ImportWidgetCount = ImportWidgetCount + 1
        end
      end
    end
  end
  table.sort(SortedCanvases, function(a, b)
    if a.SortOrder ~= b.SortOrder then
      return a.SortOrder < b.SortOrder
    end
    return tostring(a.Key) < tostring(b.Key)
  end)
  local ImportCanvasCount = #SortedCanvases
  if ImportCanvasCount == 0 then
    return {}, EImportUMGErrorCode.INVALID_UMG_DATA
  end
  local MaxUICount = CustomUIDefine.MaxUICount or 300
  if MaxUICount < ExistingCanvasCount + ImportCanvasCount then
    print(bWriteLog and string.format("CreativeUMGInfoManager:_ImportUMGInfoOnDS canvas limit, cur:%d import:%d max:%d", ExistingCanvasCount, ImportCanvasCount, MaxUICount))
    return {}, EImportUMGErrorCode.CANVAS_COUNT_EXCEED_LIMIT
  end
  if MaxUICount < ExistingWidgetCount + ImportWidgetCount then
    print(bWriteLog and string.format("CreativeUMGInfoManager:_ImportUMGInfoOnDS widget limit, cur:%d import:%d max:%d", ExistingWidgetCount, ImportWidgetCount, MaxUICount))
    return {}, EImportUMGErrorCode.WIDGET_COUNT_EXCEED_LIMIT
  end
  local AllNewKeys = {}
  for _, Entry in ipairs(SortedCanvases) do
    local NewKey = self:_ImportOneCanvasOnDS(Entry.SubTree, Entry.Key, Ctx)
    if NewKey then
      AllNewKeys[#AllNewKeys + 1] = NewKey
    end
  end
  print(bWriteLog and string.format("CreativeUMGInfoManager:_ImportUMGInfoOnDS done, canvas:%d widget:%d", #AllNewKeys, ImportWidgetCount))
  return AllNewKeys, EImportUMGErrorCode.SUCCESS
end

function CreativeUMGInfoManager:_ImportOneCanvasOnDS(SubTree, PreGenKey, Ctx)
  local InstanceMgr = GetInstanceManager()
  if InstanceMgr == nil then
    return nil
  end
  local CanvasNode, CanvasId = self:_GetCanvasNodeOfSubTree(SubTree)
  if CanvasNode == nil or CanvasId == nil then
    return nil
  end
  local NewKey = PreGenKey
  if self._UMGInfoTreeMap[NewKey] ~= nil then
    NewKey = InstanceMgr:GenerateUID()
    print(bWriteLog and string.format("CreativeUMGInfoManager:_ImportOneCanvasOnDS key collision, %s -> %s", tostring(PreGenKey), tostring(NewKey)))
  end
  local IDMap = {}
  for InstId, _ in pairs(SubTree) do
    local NewId = InstanceMgr:GenerateUID()
    IDMap[tostring(InstId)] = tostring(NewId)
  end
  IDMap[tostring(CanvasId)] = tostring(NewKey)
  local NewSubTree = {}
  local WidgetEntries = {}
  for InstId, Inst in pairs(SubTree) do
    local NewInst = Utility:DeepCopy(Inst)
    local NewIdStr = IDMap[tostring(InstId)]
    if NewInst.CustomUIBase then
      NewInst.CustomUIBase.CDOInstanceID = NewIdStr
      NewInst.CustomUIBase.CanvasID = tostring(NewKey)
      WidgetEntries[#WidgetEntries + 1] = {
        NewId = NewIdStr,
        Inst = NewInst,
        OrigLayer = tonumber(NewInst.CustomUIBase.Layer) or 0
      }
    end
    if NewInst.UMGCanvasInfo and not NewInst.CustomUIBase then
      NewInst.UMGCanvasInfo.CDOInstanceID = tostring(NewKey)
    end
    local Children = InstanceMgr:GetObjectValue(nil, "ObjectGroup.Children", NewInst)
    if Children then
      for i = 1, #Children do
        local Mapped = IDMap[Children[i]]
        if Mapped then
          Children[i] = Mapped
        end
      end
    end
    if NewInst.UMGCanvasInfo then
      local AllWidgets = InstanceMgr:GetObjectValue(nil, "UMGCanvasInfo.AllWidgets", NewInst)
      if AllWidgets then
        for i = 1, #AllWidgets do
          local Mapped = IDMap[AllWidgets[i]]
          if Mapped then
            AllWidgets[i] = Mapped
          end
        end
      end
    end
    NewSubTree[tonumber(NewIdStr)] = NewInst
  end
  table.sort(WidgetEntries, function(a, b)
    if a.OrigLayer ~= b.OrigLayer then
      return a.OrigLayer < b.OrigLayer
    end
    return a.NewId < b.NewId
  end)
  for _, Entry in ipairs(WidgetEntries) do
    Ctx.MaxLayer = Ctx.MaxLayer + 1
    Entry.Inst.CustomUIBase.Layer = Ctx.MaxLayer
  end
  local NewCanvas = NewSubTree[NewKey]
  local CanvasInfo = NewCanvas and NewCanvas.UMGCanvasInfo or nil
  if CanvasInfo == nil then
    return nil
  end
  if CanvasInfo.CanvasName == nil or CanvasInfo.CanvasName == "" then
    CanvasInfo.CanvasName = "Default"
  end
  if (tonumber(CanvasInfo.CanvasType) or 0) == CustomUIDefine.UMGCanvasType.Dynamic then
    CanvasInfo.SortOrder = 0
  end
  if (tonumber(CanvasInfo.CanvasType) or 0) == 1 then
    if Ctx.bHasDefaultCanvas then
      CanvasInfo.CanvasType = 2
      print(bWriteLog and "CreativeUMGInfoManager:_ImportOneCanvasOnDS demote Default canvas to Game:" .. tostring(NewKey))
    else
      Ctx.bHasDefaultCanvas = true
    end
  end
  if (tonumber(CanvasInfo.CanvasType) or 0) == CustomUIDefine.UMGCanvasType.Dynamic then
    CanvasInfo.EditModeVisible = false
  end
  local Bytes = self:PackUMGInfoTree(NewSubTree)
  if Bytes == nil then
    print(bWriteLog and "CreativeUMGInfoManager:_ImportOneCanvasOnDS pack failed, NewKey:" .. tostring(NewKey))
    return nil
  end
  self:AddUMGInfo(NewKey, Bytes)
  return NewKey
end

function CreativeUMGInfoManager:GetUMGInfoTree(UMGInfoID)
  return self._UMGInfoTreeMap[UMGInfoID]
end

function CreativeUMGInfoManager:GetAllUMGInfoTree()
  return self._UMGInfoTreeMap
end

function CreativeUMGInfoManager:GetCanvasRootWidgetIds(CanvasId)
  local SubTree = self._UMGInfoTreeMap[CanvasId] or self._UMGInfoTreeMap[tonumber(CanvasId)]
  if type(SubTree) ~= "table" then
    return {}
  end
  local CanvasNode = SubTree[CanvasId] or SubTree[tonumber(CanvasId)] or SubTree[tostring(CanvasId)]
  if type(CanvasNode) ~= "table" then
    return {}
  end
  local ObjectGroup = CanvasNode.ObjectGroup
  local ChildrenRaw = type(ObjectGroup) == "table" and ObjectGroup.Children or nil
  local ChildrenList
  if type(ChildrenRaw) == "table" then
    ChildrenList = type(ChildrenRaw.overrides) == "table" and ChildrenRaw.overrides or ChildrenRaw
  end
  if type(ChildrenList) == "table" and 0 < #ChildrenList then
    local Result = {}
    for Index = 1, #ChildrenList do
      Result[Index] = ChildrenList[Index]
    end
    return Result
  end
  local AllWidgetsRaw = CanvasNode.UMGCanvasInfo and CanvasNode.UMGCanvasInfo.AllWidgets or nil
  local WidgetIds
  if type(AllWidgetsRaw) == "table" then
    WidgetIds = type(AllWidgetsRaw.overrides) == "table" and AllWidgetsRaw.overrides or AllWidgetsRaw
  end
  if type(WidgetIds) ~= "table" or #WidgetIds == 0 then
    return {}
  end
  local WidgetSet = {}
  local ChildSet = {}
  for Index = 1, #WidgetIds do
    WidgetSet[tostring(WidgetIds[Index])] = true
  end
  for Index = 1, #WidgetIds do
    local WidgetId = WidgetIds[Index]
    local Widget = SubTree[WidgetId] or SubTree[tonumber(WidgetId)] or SubTree[tostring(WidgetId)]
    local WidgetGroup = Widget and Widget.ObjectGroup or nil
    local WidgetChildrenRaw = type(WidgetGroup) == "table" and WidgetGroup.Children or nil
    if type(WidgetChildrenRaw) == "table" then
      local List = type(WidgetChildrenRaw.overrides) == "table" and WidgetChildrenRaw.overrides or WidgetChildrenRaw
      for ChildIndex = 1, #List do
        local ChildKey = tostring(List[ChildIndex])
        if WidgetSet[ChildKey] == true then
          ChildSet[ChildKey] = true
        end
      end
    end
  end
  local Result = {}
  for Index = 1, #WidgetIds do
    local WidgetId = WidgetIds[Index]
    if ChildSet[tostring(WidgetId)] ~= true then
      Result[#Result + 1] = WidgetId
    end
  end
  return Result
end

function CreativeUMGInfoManager:GetAllGameUMGInfoTree()
  local Result = {}
  for Key, SubTree in pairs(self._UMGInfoTreeMap) do
    if SubTree then
      local CanvasNode = self:_GetCanvasNodeOfSubTree(SubTree)
      local CanvasType = CanvasNode and CanvasNode.UMGCanvasInfo and CanvasNode.UMGCanvasInfo.CanvasType or nil
      if (tonumber(CanvasType) or 0) ~= CustomUIDefine.UMGCanvasType.Dynamic then
        Result[Key] = SubTree
      end
    end
  end
  return Result
end

function CreativeUMGInfoManager:DecodeUpgradedUMGInfoTrees(UMGInfoMap)
  local AllTree = {}
  local DecodedCount, FailedCount = 0, 0
  if type(UMGInfoMap) ~= "table" then
    return AllTree, 0, 0
  end
  for RawKey, Content in pairs(UMGInfoMap) do
    local bOK, BinaryData = pcall(BinaryAssetTool.UnPackBinaryAsset, Content)
    if bOK and BinaryData and BinaryData.InstanceTree then
      DecodedCount = DecodedCount + 1
      AllTree[tonumber(RawKey) or RawKey] = BinaryData.InstanceTree
    else
      FailedCount = FailedCount + 1
      print(bWriteLog and string.format("CreativeUMGInfoManager:DecodeUpgradedUMGInfoTrees decode failed, key:%s error:%s", tostring(RawKey), tostring(bOK and "no_instance_tree" or BinaryData)))
    end
  end
  return AllTree, DecodedCount, FailedCount
end

function CreativeUMGInfoManager:ReportClientUIPreloadResultToGEM(ModID, Reason)
  local bUtilsOK, ReportUtils = pcall(require, "client.slua.logic.ugc.ugc_gem_report_utils")
  if not bUtilsOK or not ReportUtils then
    print("[ClientUIPreload] GEM report skipped: ugc_gem_report_utils unavailable")
    return
  end
  ReportUtils.Report(ReportUtils.EnumMessageType.ClientUIPreloadResult, ModID, {
    reason = tostring(Reason)
  })
end

function CreativeUMGInfoManager:IsCustomUIDownloadNeededFromLobbyMeta(ModID)
  local LogicUGCConfig = ModuleManager and ModuleManager.LobbyModuleConfig and ModuleManager.LobbyModuleConfig.LogicUGC
  local LogicUGC = LogicUGCConfig and ModuleManager and ModuleManager.GetModule(LogicUGCConfig) or nil
  local ModInfo = LogicUGC and LogicUGC.GetModByAllCache and LogicUGC:GetModByAllCache(ModID) or nil
  local Setting = ModInfo and ModInfo.pub_mod_meta and ModInfo.pub_mod_meta.setting
  return type(Setting) == "table" and Setting.need_customui_download == true
end

function CreativeUMGInfoManager:PrebuildClientUMGInfoTreeFromLobbyBinCache()
  if self:HasAuthority() then
    return false
  end
  if self.bClientUMGInfoTreePrebuilt then
    return false
  end
  self.bClientUMGInfoTreePrebuilt = true
  if not slua.isValid(CGameState) then
    print(bWriteLog and "CreativeUMGInfoManager:PrebuildClientUMGInfoTreeFromLobbyBinCache skip, GameState invalid")
    return true
  end
  local ModID = tonumber(CGameState.GetMainModID and CGameState:GetMainModID() or nil)
  if not ModID or ModID <= 0 then
    print(bWriteLog and "CreativeUMGInfoManager:PrebuildClientUMGInfoTreeFromLobbyBinCache invalid ModID " .. tostring(ModID))
    self:ReportClientUIPreloadResultToGEM(ModID, "invalid_mod_id")
    return true
  end
  if not self:IsCustomUIDownloadNeededFromLobbyMeta(ModID) then
    print(bWriteLog and "CreativeUMGInfoManager:PrebuildClientUMGInfoTreeFromLobbyBinCache skip, need_customui_download not set")
    return true
  end
  local LobbyBinModuleConfig = ModuleManager and ModuleManager.LobbyModuleConfig and ModuleManager.LobbyModuleConfig.LogicUGCLobbyBin
  local LobbyBinModule = LobbyBinModuleConfig and ModuleManager and ModuleManager.GetModule(LobbyBinModuleConfig) or nil
  if not LobbyBinModule then
    print(bWriteLog and "CreativeUMGInfoManager:PrebuildClientUMGInfoTreeFromLobbyBinCache LobbyBinModule nil")
    self:ReportClientUIPreloadResultToGEM(ModID, "lobby_bin_module_nil")
    return true
  end
  local FileInfo, FileInfoError = LobbyBinModule:GetLobbyBinFileInfo(ModID)
  if not FileInfo then
    print(bWriteLog and "CreativeUMGInfoManager:PrebuildClientUMGInfoTreeFromLobbyBinCache get file info failed " .. tostring(FileInfoError))
    self:ReportClientUIPreloadResultToGEM(ModID, "lobby_bin_file_info_failed_" .. tostring(FileInfoError or "unknown"))
    return true
  end
  if FileInfo.BinaryVersion < 10022 then
    print(bWriteLog and "CreativeUMGInfoManager:PrebuildClientUMGInfoTreeFromLobbyBinCache old version " .. tostring(FileInfo.BinaryVersion))
    self:ReportClientUIPreloadResultToGEM(ModID, "old_binary_version_" .. tostring(FileInfo.BinaryVersion))
    return true
  end
  local LobbyBinConfig = require("client.slua.logic.ugc.lobby_bin_config")
  local UMGInfoMap, _, UMGInfoError = LobbyBinModule:GetLobbyBinRawData(ModID, LobbyBinConfig.EnumField.UMGInfoMap)
  if UMGInfoError then
    print(bWriteLog and "CreativeUMGInfoManager:PrebuildClientUMGInfoTreeFromLobbyBinCache read UMGInfoMap failed " .. tostring(UMGInfoError))
    self:ReportClientUIPreloadResultToGEM(ModID, "umginfomap_read_failed_" .. tostring(UMGInfoError))
    return true
  end
  local AllTree = {}
  local UMGInfoRawCount = 0
  local Decoded, Failed = 0, 0
  if type(UMGInfoMap) == "table" then
    for _ in pairs(UMGInfoMap) do
      UMGInfoRawCount = UMGInfoRawCount + 1
    end
    if 0 < UMGInfoRawCount then
      AllTree, Decoded, Failed = self:DecodeUpgradedUMGInfoTrees(UMGInfoMap)
      if Decoded == 0 then
        self:ReportClientUIPreloadResultToGEM(ModID, "umginfomap_decode_all_failed_" .. tostring(UMGInfoRawCount))
      elseif 0 < Failed then
        self:ReportClientUIPreloadResultToGEM(ModID, "umginfomap_decode_failed_" .. tostring(Failed) .. "_" .. tostring(UMGInfoRawCount))
      end
    end
  end
  for Key, SubTree in pairs(AllTree) do
    if self._UMGInfoTreeMap[Key] == nil then
      self._UMGInfoTreeMap[Key] = SubTree
    end
  end
  local bNoCanvasDirty = false
  if next(AllTree) ~= nil then
    local CanvasCount = 0
    for _, SubTree in pairs(AllTree) do
      if self:_GetCanvasNodeOfSubTree(SubTree) then
        CanvasCount = CanvasCount + 1
      end
    end
    if CanvasCount == 0 then
      bNoCanvasDirty = true
      self:ReportClientUIPreloadResultToGEM(ModID, "no_canvas_in_umginfomap_tree")
    end
  end
  if 0 < UMGInfoRawCount and Failed == 0 and not bNoCanvasDirty then
    self:ReportClientUIPreloadResultToGEM(ModID, "ok")
  end
  return true
end

function CreativeUMGInfoManager:SetAllUMGInfoTree(TreeMap)
  self._UMGInfoTreeMap = TreeMap or {}
end

local class = require("class")
local CManagerBase = require("GameLua.Mod.CreativeBase.Gameplay.Manager.CreativeManagerBase")
local CCreativeUMGInfoManager = class(CManagerBase, nil, CreativeUMGInfoManager)
return CCreativeUMGInfoManager
