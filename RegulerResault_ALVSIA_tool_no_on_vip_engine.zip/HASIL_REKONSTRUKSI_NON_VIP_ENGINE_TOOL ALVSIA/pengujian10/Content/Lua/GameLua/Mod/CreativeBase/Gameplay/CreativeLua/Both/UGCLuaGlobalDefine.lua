local UGCLuaGlobalDefine = {}
UGCLuaGlobalDefine.USE_AST_BIN = true
UGCLuaGlobalDefine.ASYNC_LOAD_AST_BIN = false
UGCLuaGlobalDefine.ASYNC_LOAD_AST_BIN_SIZE = 512.0
UGCLuaGlobalDefine.USE_REUSE_BLOCKYLUA_WIDGET = false
UGCLuaGlobalDefine.USE_CALL_LOADFINISH = true
UGCLuaGlobalDefine.USE_CACHE_GRAPH_DATA_OBJECT = true
UGCLuaGlobalDefine.GlobalFollowerID = -10000
UGCLuaGlobalDefine.CodeDataPatchFailErrorCode = 3
UGCLuaGlobalDefine.CodeDataTextFailErrorCode = 10
UGCLuaGlobalDefine.CodeDataPushTimeroutErrorCode = 103
UGCLuaGlobalDefine.CodeDataNotInEditModeErrorCode = 104
UGCLuaGlobalDefine.SearchHistoryMaxCount = 10
UGCLuaGlobalDefine.Enum_Operator = {
  ["<"] = 0,
  ["<="] = 1,
  [">"] = 2,
  [">="] = 3,
  ["=="] = 4,
  ["~="] = 5,
  ["+"] = 6,
  ["-"] = 7,
  ["*"] = 8,
  ["/"] = 9
}

function UGCLuaGlobalDefine.ExecuteCondition(a, b, op)
  if op == UGCLuaGlobalDefine.Enum_Operator["<"] then
    return a < b
  elseif op == UGCLuaGlobalDefine.Enum_Operator["<="] then
    return a <= b
  elseif op == UGCLuaGlobalDefine.Enum_Operator[">"] then
    return b < a
  elseif op == UGCLuaGlobalDefine.Enum_Operator[">="] then
    return b <= a
  elseif op == UGCLuaGlobalDefine.Enum_Operator["=="] then
    return a == b
  elseif op == UGCLuaGlobalDefine.Enum_Operator["~="] then
    return a ~= b
  else
    return false
  end
end

UGCLuaGlobalDefine.Enum_Operator_FVector = {
  ["+"] = 1,
  ["-"] = 2,
  ["*"] = 3,
  ["/"] = 4
}
UGCLuaGlobalDefine.Enum_MaterialColorType = {
  White = 0,
  Yellow = 1,
  Red = 2,
  Blue = 3,
  Cyan = 4,
  Green = 5
}
UGCLuaGlobalDefine.Enum_ModelSizeType = {
  Min = 0,
  Mid = 1,
  Max = 2
}
UGCLuaGlobalDefine.Enum_Operator_Integer = {
  ["+"] = 1,
  ["-"] = 2,
  ["*"] = 3,
  ["/"] = 4,
  ["%"] = 5,
  ["^"] = 6
}
UGCLuaGlobalDefine.Enum_Operator_Real = {
  ["+"] = 1,
  ["-"] = 2,
  ["*"] = 3,
  ["/"] = 4,
  ["%"] = 5,
  ["^"] = 6
}
UGCLuaGlobalDefine.Enum_VectorAxis = {
  X = 0,
  Y = 1,
  Z = 2
}
UGCLuaGlobalDefine.Enum_VectorWorldDir = {
  Forward = 0,
  Backward = 1,
  Up = 2,
  Down = 3,
  Left = 4,
  Right = 5
}
UGCLuaGlobalDefine.Enum_CollisionEnabled = {
  NoCollision = 0,
  QueryOnly = 1,
  PhysicsOnly = 2,
  QueryAndPhysics = 3,
  TriggerOnly = 4,
  QueryAndTrigger = 5
}
UGCLuaGlobalDefine.InCollisionProfileName = {
  NoCollision = "NoCollision",
  BlockAll = "BlockAll",
  OverlapAll = "OverlapAll",
  BlockAllDynamic = "BlockAllDynamic",
  OverlapAllDynamic = "OverlapAllDynamic",
  IgnoreOnlyPawn = "IgnoreOnlyPawn",
  OverlapOnlyPawn = "OverlapOnlyPawn",
  Pawn = "Pawn",
  Spectator = "Spectator",
  CharacterMesh = "CharacterMesh",
  PhysicsActor = "PhysicsActor",
  Destructible = "Destructible",
  InvisibleWall = "InvisibleWall",
  InvisibleWallDynamic = "InvisibleWallDynamic",
  Trigger = "Trigger",
  Ragdoll = "Ragdoll",
  Vehicle = "Vehicle",
  UI = "UI",
  PlayerTrigger = "PlayerTrigger",
  PhysicalTrigger = "PhysicalTrigger",
  PhysicalTriggerOnly = "PhysicalTriggerOnly",
  Bullet = "Bullet",
  PickUpTriggerBox = "PickUpTriggerBox",
  PropMesh = "PropMesh",
  PickUpTrigger = "PickUpTrigger",
  WireMesh = "WireMesh",
  StepsQueryOnly = "StepsQueryOnly",
  Smoke = "Smoke",
  Pet = "Pet",
  BlockAISight = "BlockAISight",
  CreaturesVehicle = "CreaturesVehicle",
  CharacterTriggerForVehicle = "CharacterTriggerForVehicle",
  Water = "Water",
  WaterPlane = "WaterPlane",
  NoWaterArea = "NoWaterArea",
  BioVehicleMesh = "BioVehicleMesh",
  InvisibleBlockPawnVehicle = "InvisibleBlockPawnVehicle",
  OnlyCollideStatic = "OnlyCollideStatic"
}
UGCLuaGlobalDefine.InCollisionProfileNameValueToEnum = {
  [0] = UGCLuaGlobalDefine.InCollisionProfileName.NoCollision,
  [1] = UGCLuaGlobalDefine.InCollisionProfileName.BlockAll,
  [2] = UGCLuaGlobalDefine.InCollisionProfileName.OverlapAll,
  [3] = UGCLuaGlobalDefine.InCollisionProfileName.BlockAllDynamic,
  [4] = UGCLuaGlobalDefine.InCollisionProfileName.OverlapAllDynamic,
  [5] = UGCLuaGlobalDefine.InCollisionProfileName.IgnoreOnlyPawn,
  [6] = UGCLuaGlobalDefine.InCollisionProfileName.OverlapOnlyPawn,
  [7] = UGCLuaGlobalDefine.InCollisionProfileName.Pawn,
  [8] = UGCLuaGlobalDefine.InCollisionProfileName.Spectator,
  [9] = UGCLuaGlobalDefine.InCollisionProfileName.CharacterMesh,
  [10] = UGCLuaGlobalDefine.InCollisionProfileName.PhysicsActor,
  [11] = UGCLuaGlobalDefine.InCollisionProfileName.Destructible,
  [12] = UGCLuaGlobalDefine.InCollisionProfileName.InvisibleWall,
  [13] = UGCLuaGlobalDefine.InCollisionProfileName.InvisibleWallDynamic,
  [14] = UGCLuaGlobalDefine.InCollisionProfileName.Trigger,
  [15] = UGCLuaGlobalDefine.InCollisionProfileName.Ragdoll,
  [16] = UGCLuaGlobalDefine.InCollisionProfileName.Vehicle,
  [17] = UGCLuaGlobalDefine.InCollisionProfileName.UI,
  [18] = UGCLuaGlobalDefine.InCollisionProfileName.PlayerTrigger,
  [19] = UGCLuaGlobalDefine.InCollisionProfileName.PhysicalTrigger,
  [20] = UGCLuaGlobalDefine.InCollisionProfileName.PhysicalTriggerOnly,
  [21] = UGCLuaGlobalDefine.InCollisionProfileName.Bullet,
  [22] = UGCLuaGlobalDefine.InCollisionProfileName.PickUpTriggerBox,
  [23] = UGCLuaGlobalDefine.InCollisionProfileName.PropMesh,
  [24] = UGCLuaGlobalDefine.InCollisionProfileName.PickUpTrigger,
  [25] = UGCLuaGlobalDefine.InCollisionProfileName.WireMesh,
  [26] = UGCLuaGlobalDefine.InCollisionProfileName.StepsQueryOnly,
  [27] = UGCLuaGlobalDefine.InCollisionProfileName.Smoke,
  [28] = UGCLuaGlobalDefine.InCollisionProfileName.Pet,
  [29] = UGCLuaGlobalDefine.InCollisionProfileName.BlockAISight,
  [30] = UGCLuaGlobalDefine.InCollisionProfileName.CreaturesVehicle,
  [31] = UGCLuaGlobalDefine.InCollisionProfileName.CharacterTriggerForVehicle,
  [32] = UGCLuaGlobalDefine.InCollisionProfileName.Water,
  [33] = UGCLuaGlobalDefine.InCollisionProfileName.WaterPlane,
  [34] = UGCLuaGlobalDefine.InCollisionProfileName.NoWaterArea,
  [35] = UGCLuaGlobalDefine.InCollisionProfileName.BioVehicleMesh,
  [36] = UGCLuaGlobalDefine.InCollisionProfileName.InvisibleBlockPawnVehicle,
  [37] = UGCLuaGlobalDefine.InCollisionProfileName.OnlyCollideStatic
}
UGCLuaGlobalDefine.InCollisionProfileNameToKey = {}
for k, v in pairs(UGCLuaGlobalDefine.InCollisionProfileNameValueToEnum) do
  UGCLuaGlobalDefine.InCollisionProfileNameToKey[v] = k
end
UGCLuaGlobalDefine.Enum_NeedPossessAI = {
  Disabled = 0,
  PlacedInWorld = 1,
  Spawned = 2,
  PlacedInWorldOrSpawned = 3
}
UGCLuaGlobalDefine.Enum_UGCGameObjType = {
  Player = 0,
  Instance = 1,
  Pickup = 2,
  TriggerArea = 3
}
UGCLuaGlobalDefine.Enum_GameProcessType = {
  GameMatchPrepare = 1,
  UGCGameInitialize = 2,
  EnterGameProcess = 3,
  EnterANewRound = 10,
  RoundReadyPre = 20,
  RoundReady = 21,
  RoundFighting = 30,
  RoundFinish = 40,
  GameFinish = 50
}
UGCLuaGlobalDefine.Enum_OutcomeType = {
  Win = 0,
  Lose = 1,
  Draw = 2
}
UGCLuaGlobalDefine.Enum_UGCLuaPawnState = {
  Move = 0,
  Sprint = 1,
  ProneMove = 2,
  Stand = 3,
  Crouch = 4,
  Prone = 5,
  Jump = 6,
  GunFire = 7,
  GunReload = 8,
  GunADS = 9,
  Picth = 10,
  SwitchWeapon = 11,
  Pick = 12,
  MeleeAttack = 13,
  HoldGrenade = 14,
  Save = 15,
  UseConsumables = 16,
  Dying = 17,
  Dead = 18,
  DriveVehicle = 19,
  InVehicle = 20,
  LeanOutVehicle = 21,
  Swim = 22,
  InParachute = 23,
  Vault = 24,
  InPlane = 25,
  GunOBOReload = 26,
  SwitchPP = 27,
  PlayEmote = 28,
  HoldShield = 29,
  Imprisonment = 30,
  StunBurnNag = 31,
  Skill = 32,
  DetectPaintDecal = 33,
  Revival = 34,
  AirAttackLocator = 35,
  ControlUnmannedVehicle = 36,
  Shoveling = 37,
  RemoteControlVehicle = 38,
  Build = 39,
  GunFillGas = 40,
  Shoulder = 41,
  Variation = 42,
  CarryBack = 43,
  BeCarriedBack = 44,
  Dizziness = 45,
  Knock = 46,
  InZipline = 47,
  StairsMove = 48,
  InActivityActor = 49,
  DriveMovePlatForm = 50,
  Slide = 51,
  WeaponAccPrepare = 52,
  Arrest = 53,
  AirBorne = 54,
  SplineMove = 55,
  MovableEmote = 56,
  PassiveVariation = 57,
  ControlDrone = 58,
  Restricted = 59,
  FlyingArmor = 60,
  Diving = 61,
  ShapeShifting = 62,
  NoneState = 256,
  CrouchMove = 257,
  InAir = 259,
  Falling = 258
}
UGCLuaGlobalDefine.Enum_GameplayButtonType = {
  Attack = 1,
  SwitchGun = 2,
  Direction = 3,
  Prone = 4,
  Jump = 5,
  Rescue = 6,
  Carry = 7,
  Crouch = 8,
  Skill = 9,
  Throw = 10
}
UGCLuaGlobalDefine.GameplayButtonTypeNameID = {
  [UGCLuaGlobalDefine.Enum_GameplayButtonType.Attack] = 202605221,
  [UGCLuaGlobalDefine.Enum_GameplayButtonType.SwitchGun] = 202605223,
  [UGCLuaGlobalDefine.Enum_GameplayButtonType.Prone] = 202605224,
  [UGCLuaGlobalDefine.Enum_GameplayButtonType.Jump] = 202605225,
  [UGCLuaGlobalDefine.Enum_GameplayButtonType.Rescue] = 202605226,
  [UGCLuaGlobalDefine.Enum_GameplayButtonType.Carry] = 202605227,
  [UGCLuaGlobalDefine.Enum_GameplayButtonType.Crouch] = 202605228,
  [UGCLuaGlobalDefine.Enum_GameplayButtonType.Skill] = 202605229,
  [UGCLuaGlobalDefine.Enum_GameplayButtonType.Throw] = 202605222
}
UGCLuaGlobalDefine.Enum_ForbiddenPawnState = {
  ForbiddenMove = 1,
  ForbbiddenJump = 2,
  ForbbiddenCrouch = 3,
  ForbbiddenProne = 4,
  ForbbiddenSprint = 5,
  ForbbiddenAttack = 6,
  ForbbiddenViewControll = 7,
  ForbbiddenPickItem = 8,
  ForbbiddenUseItem = 9,
  ForbbiddenGetOnVehicle = 10,
  ForbbiddenGetOutVehicle = 11
}
UGCLuaGlobalDefine.Enum_UGCLuaDamageType = {
  InvalidDamageType = 0,
  ShootDamage = 1,
  STPointDamage = 3,
  CustomRadiusDamage = 4,
  PoisonDamage = 13,
  DrowningDamage = 14,
  FallingDamage = 15,
  MeleeDamage = 16,
  GrenadeRadiusDamage = 17,
  BurningDamage = 18,
  AirAttackDamage = 19,
  VehicleDamage = 20,
  VehicleExplodeRadiusDamage = 21,
  LastBreathWithoutRescue = 22,
  WinnerFakeDeath = 23,
  SkillDamage = 24,
  PoisonFogDamage = 25,
  GasolineCanExplosion = 26,
  ZombieDamage = 27,
  LowTemperatureDamage = 28,
  TopFiveGaveUpDamage = 29,
  Resurrection = 30,
  TyrantMonsterStonedDamage = 31,
  RPGExplosionDamage = 32,
  CartridgeExplosionDamage = 33,
  DotDamage = 34
}
UGCLuaGlobalDefine.Enum_RoundingMethod = {
  floor = 1,
  ceil = 2,
  round = 3
}
UGCLuaGlobalDefine.Enum_BinaryCmpOpType = {max = 1, min = 2}
UGCLuaGlobalDefine.Enum_LogBaseType = {E = 1, TEN = 2}
UGCLuaGlobalDefine.Enum_UGCLuaAIPawnAttrType = {
  Hp = 1,
  TakeDamageScale = 2,
  DamageScale = 3,
  SpeedRate = 4,
  JumpZVelocity = 5
}
UGCLuaGlobalDefine.Enum_BlockyLuaTLogType = {
  MonsterLevel = "MonsterLevel"
}
UGCLuaGlobalDefine.Enum_PresetType = {
  CreativeAsset = "CreativeAsset",
  ItemPreset = "ItemPreset",
  Item = "Item",
  CreativeInstance = "CreativeInstance",
  Vehicle = "Vehicle",
  VehiclePreset = "VehiclePreset",
  Player = "Player",
  Monster = "Monster",
  MonsterPreset = "MonsterPreset",
  BuffPreset = "BuffPreset",
  ArmedAIPreset = "ArmedAIPreset",
  ArmedAI = "ArmedAI",
  Skill = "Skill",
  SkillPreset = "SkillPreset",
  TriggerArea = "TriggerArea",
  MarkPoint = "MarkPoint",
  PickUpInstance = "PickUpInstance",
  PickupPreset = "PickupPreset",
  DropGroupPreset = "DropGroupPreset",
  ProjectilePreset = "CreativeProjectilePreset",
  TreasurePreset = "TreasurePreset",
  UObject = "UObject"
}
UGCLuaGlobalDefine.Enum_LuaVMFatalStateType = {
  VMFatal_None = "None",
  VMFatal_OOM = "OOM",
  VMFatal_StackOverflow = "Stack Overflow",
  VMFatal_Other = "Other",
  ENVLuaVMFatal_OOM = "ENVLuaVMOOM",
  ENVLuaVMFatal_Other = "ENVLuaVMOther",
  ENVLuaVMFatal_ExecTimeout = "ENVLuaVMExecTimeout"
}
UGCLuaGlobalDefine.EnvLuaFatalStateTypeMap = {
  [UGCLuaGlobalDefine.Enum_LuaVMFatalStateType.ENVLuaVMFatal_OOM] = true,
  [UGCLuaGlobalDefine.Enum_LuaVMFatalStateType.ENVLuaVMFatal_Other] = true,
  [UGCLuaGlobalDefine.Enum_LuaVMFatalStateType.ENVLuaVMFatal_ExecTimeout] = true
}
UGCLuaGlobalDefine.Enum_EntityType = {
  Invalid = 0,
  Timer = 1,
  Trigger = 2,
  TriggerGroup = 3,
  Component = 4,
  ComponentPreset = 5,
  LightComponent = 6,
  LightComponentPreset = 7,
  Region = 8,
  GameplayDevice = 9,
  GameplayDevicePreset = 10,
  PlayerState = 11,
  ArmedAICharacter = 12,
  MonsterCharacter = 13,
  PlayerPreset = 14,
  PlayerCharacterPreset = 15,
  ArmedAI = 16,
  ArmedAIPreset = 17,
  Monster = 18,
  MonsterPreset = 19,
  SkillPreset = 20,
  BuffPreset = 21,
  WeaponPreset = 22,
  WeatherPreset = 23,
  Item = 24,
  ItemPreset = 25,
  Vehicle = 26,
  VehiclePreset = 27,
  Effect = 28,
  EffectPreset = 29,
  Sound = 30,
  SoundPreset = 31,
  LogicObject = 32,
  LogicObjectPreset = 33,
  TriggerArea = 34,
  TriggerAreaPreset = 35,
  Marker = 36,
  Pickup = 37,
  PickupPreset = 38,
  ContestedItem = 39,
  ContestedItemPreset = 40,
  BankProduct = 41,
  BuildingInstance = 42,
  Skill = 43,
  Projectile = 44,
  ActorSkill = 45,
  Empower = 46,
  DropGroupPreset = 47,
  TreasurePreset = 48,
  UObject = 49,
  __MAX = 50
}
UGCLuaGlobalDefine.EMovementMode = {
  MOVE_None = 0,
  MOVE_Walking = 1,
  MOVE_NavWalking = 2,
  MOVE_Falling = 3,
  MOVE_Swimming = 4,
  MOVE_Flying = 5,
  MOVE_Custom = 6
}
UGCLuaGlobalDefine.bBlueHoleVersionEnable = true
UGCLuaGlobalDefine.bShowLoadResFailed = false

function UGCLuaGlobalDefine.GetBlockyluaEnable()
  local bEnable = true
  local GamePlayTools = require("GameLua.Mod.BaseMod.Common.GamePlayTools")
  if GamePlayTools.IsBlueHoleVersion() and not UGCLuaGlobalDefine.bBlueHoleVersionEnable then
    print(bWriteLog and "UGCLuaGlobalDefine.GetBlockyluaEnable IsBlueHoleVersion")
    bEnable = false
  end
  print(bWriteLog and "UGCLuaGlobalDefine.GetBlockyluaEnable bEnable:" .. tostring(bEnable))
  return bEnable
end

UGCLuaGlobalDefine.DropGroupOptType = {Add = 0, Remove = 1}
UGCLuaGlobalDefine.GMRunCustomLuaModKey = {}
UGCLuaGlobalDefine.Enum_UGCLuaSurviveWeaponPropSlot = {
  SWPS_None = 0,
  SWPS_MainShootWeapon1 = 1,
  SWPS_MainShootWeapon2 = 2,
  SWPS_SubShootWeapon = 3,
  SWPS_MeleeWeapon = 4,
  SWPS_HandProp = 5,
  SWPS_TempSpecialWeapon = 6,
  SWPS_ShiftGrenadeWeapon = 7,
  SWPS_VehicleWeapon = 8,
  SWPS_Max = 9
}
UGCLuaGlobalDefine.Enum_UGCLuaWeaponPropertyName = {
  AccessoriesVRecoilFactor = 1,
  AccessoriesRecoveryFactor = 2,
  AccessoriesHRecoilFactor = 3,
  AnimationKick = 4,
  RecoilKick = 5,
  RecoilKickADS = 6,
  FireAnimationRate = 7,
  ShotGunVerticalSpread = 8,
  ShotGunHorizontalSpread = 9,
  GameDeviationFactor = 10,
  GameDeviationAccuracy = 11,
  AccessoriesDeviationFactor = 12,
  PreFireTime = 13,
  PreFireAnimScale = 14,
  PostFireTime = 15,
  PostReloadTime = 16,
  ShootInterval = 17,
  BurstShootInterval = 18,
  ReloadTime = 19,
  ReloadTimeTactical = 20,
  ReloadTimeMagOut = 21,
  ReloadTimeMagIn = 22,
  ReloadDurationStart = 23,
  ReloadDurationLoop = 24,
  ReloadRate = 25,
  WeaponAimInTime = 26,
  WeaponAimPitchRate = 27,
  WeaponAimYawRate = 28,
  GameMotionPitchRate = 30,
  GameMotionYawRate = 31,
  SensitiveFirePitchRate = 32,
  SensitiveFireYawRate = 33,
  BaseImpactDamage = 34,
  WeaponHitPartCoffHead = 35,
  WeaponHitPartCoffHand = 36,
  WeaponHitPartCoffFoot = 37,
  WeaponHitPartCoffBody = 38,
  WeaponHitPartCoffLimbs = 39,
  VehicleDamageScale = 40,
  RangeModifier = 41,
  ReferenceDistance = 42,
  IgnoreRangeAttenuatDis = 43,
  ForegripParam = 44,
  MagParam = 45,
  ReloadAnimSlot = 46,
  MaxBulletNumInOneClip = 47,
  ExtendMaxBulletNumInOneClip = 48,
  WeaponBodyLength = 49,
  BulletRange = 50,
  BulletFireSpeed = 51,
  ExtraHitPerformScale = 52
}
UGCLuaGlobalDefine.LuaCodeTypeEnum = {
  Global = 0,
  AssetPreset = 1,
  SkillPreset = 2,
  MonsterPreset = 3,
  ArmedAIPreset = 4,
  GlobalMonsterPreset = 5,
  GlobalArmedAIPreset = 6,
  ShopPropPreset = 7,
  ShopPropPresetInGlobal = 8
}
UGCLuaGlobalDefine.UseCustomVarLuaCodeType = {
  [UGCLuaGlobalDefine.LuaCodeTypeEnum.Global] = false,
  [UGCLuaGlobalDefine.LuaCodeTypeEnum.AssetPreset] = true,
  [UGCLuaGlobalDefine.LuaCodeTypeEnum.SkillPreset] = false,
  [UGCLuaGlobalDefine.LuaCodeTypeEnum.MonsterPreset] = false,
  [UGCLuaGlobalDefine.LuaCodeTypeEnum.ArmedAIPreset] = false,
  [UGCLuaGlobalDefine.LuaCodeTypeEnum.GlobalMonsterPreset] = false,
  [UGCLuaGlobalDefine.LuaCodeTypeEnum.GlobalArmedAIPreset] = false,
  [UGCLuaGlobalDefine.LuaCodeTypeEnum.ShopPropPreset] = false
}
UGCLuaGlobalDefine.GLOBAL_CODEUID = 1
UGCLuaGlobalDefine.VARIABLE_CODEUID = 2
UGCLuaGlobalDefine.GLOBAL_EDITORLUA_CODEUID = 3
UGCLuaGlobalDefine.TEMPLATE_CODEUID = 4
UGCLuaGlobalDefine.GLOBAL_MONSTER_CODEUID = 5
UGCLuaGlobalDefine.GLOBAL_ARMEDAI_CODEUID = 6
UGCLuaGlobalDefine.GLOBAL_CODEUID_BACKUP = 7
UGCLuaGlobalDefine.VARIABLE_CODEUID_BACKUP = 8
UGCLuaGlobalDefine.GLOBAL_ALL_CODEUID_LIST = {
  UGCLuaGlobalDefine.GLOBAL_CODEUID,
  UGCLuaGlobalDefine.GLOBAL_MONSTER_CODEUID,
  UGCLuaGlobalDefine.GLOBAL_ARMEDAI_CODEUID
}
UGCLuaGlobalDefine.GlobalTypeCodeUIDArray = {
  UGCLuaGlobalDefine.GLOBAL_CODEUID,
  UGCLuaGlobalDefine.VARIABLE_CODEUID
}
UGCLuaGlobalDefine.Enum_TaskStatus = {
  None = 0,
  Pending = 1,
  InProgress = 2,
  PendingAcclaim = 3,
  Success = 4,
  Fail = 5
}
UGCLuaGlobalDefine.Enum_SelectorDeviceIconType = {
  Default = 0,
  Red = 1,
  Orange = 2,
  Yellow = 3,
  Green = 4,
  BlueGreen = 5,
  Blue = 6,
  Purple = 7
}
UGCLuaGlobalDefine.Enum_SelectorDeviceTextColorType = {
  White = 0,
  Red = 1,
  Orange = 2,
  Yellow = 3,
  Green = 4,
  BlueGreen = 5,
  Blue = 6,
  Purple = 7
}
UGCLuaGlobalDefine.Enum_CustomRank = {
  Rank1 = 1,
  Rank2 = 2,
  Rank3 = 3,
  Rank4 = 4,
  Rank5 = 5
}
UGCLuaGlobalDefine.Enum_TouchIndex = {
  Touch1 = 0,
  Touch2 = 1,
  Touch3 = 2,
  Touch4 = 3,
  Touch5 = 4,
  Touch6 = 5,
  Touch7 = 6,
  Touch8 = 7,
  Touch9 = 8,
  Touch10 = 9
}
UGCLuaGlobalDefine.Enum_CameraMode = {
  CM_FirstPerson = 0,
  CM_ThirdPerson = 1,
  CM_Free = 2
}
UGCLuaGlobalDefine.CAMERA_VALUE_MAX_CM = 100000
UGCLuaGlobalDefine.Enum_PathFollowingResult = {
  Success = 0,
  Blocked = 1,
  OffPath = 2,
  Aborted = 3,
  Invalid = 5
}
UGCLuaGlobalDefine.Enum_PathFollowingRequestResult = {
  Failed = 0,
  AlreadyAtGoal = 1,
  RequestSuccessful = 2
}
UGCLuaGlobalDefine.Enum_PathFollowingStatus = {
  Idle = 0,
  Waiting = 1,
  Paused = 2,
  Moving = 3
}
UGCLuaGlobalDefine.Enum_CanBeCharacterBase = {
  ECB_No = 0,
  ECB_Yes = 1,
  ECB_Owner = 2
}
UGCLuaGlobalDefine.Enum_CharacterBoneName = {
  pelvis = "pelvis",
  spine_01 = "spine_01",
  spine_02 = "spine_02",
  spine_03 = "spine_03",
  neck_01 = "neck_01",
  head = "head",
  upperarm_l = "upperarm_l",
  lowerarm_l = "lowerarm_l",
  hand_l = "hand_l",
  thumb_01_l = "thumb_01_l",
  thumb_02_l = "thumb_02_l",
  thumb_03_l = "thumb_03_l",
  index_01_l = "index_01_l",
  index_02_l = "index_02_l",
  index_03_l = "index_03_l",
  middle_01_l = "middle_01_l",
  middle_02_l = "middle_02_l",
  middle_03_l = "middle_03_l",
  ring_01_l = "ring_01_l",
  ring_02_l = "ring_02_l",
  ring_03_l = "ring_03_l",
  pinky_01_l = "pinky_01_l",
  pinky_02_l = "pinky_02_l",
  pinky_03_l = "pinky_03_l",
  upperarm_r = "upperarm_r",
  lowerarm_r = "lowerarm_r",
  hand_r = "hand_r",
  thumb_01_r = "thumb_01_r",
  thumb_02_r = "thumb_02_r",
  thumb_03_r = "thumb_03_r",
  index_01_r = "index_01_r",
  index_02_r = "index_02_r",
  index_03_r = "index_03_r",
  middle_01_r = "middle_01_r",
  middle_02_r = "middle_02_r",
  middle_03_r = "middle_03_r",
  ring_01_r = "ring_01_r",
  ring_02_r = "ring_02_r",
  ring_03_r = "ring_03_r",
  pinky_01_r = "pinky_01_r",
  pinky_02_r = "pinky_02_r",
  pinky_03_r = "pinky_03_r",
  thigh_l = "thigh_l",
  calf_l = "calf_l",
  foot_l = "foot_l",
  ball_l = "ball_l",
  thigh_r = "thigh_r",
  calf_r = "calf_r",
  foot_r = "foot_r",
  ball_r = "ball_r"
}
UGCLuaGlobalDefine.Enum_CharacterSocketName = {
  WeaponSocket_1 = "WeaponSocket_1",
  Throw_Socket = "Throw_Socket",
  hand_rSocket = "hand_rSocket",
  hand_lSocket = "hand_lSocket",
  item_lSocket = "item_lSocket",
  item_lSocket_0 = "item_lSocket_0",
  item_rSocket_2035 = "item_rSocket_2035",
  Mag = "Mag",
  Mag_R = "Mag_R",
  WeaponPointShield = "WeaponPointShield",
  interactSocket_r = "interactSocket_r",
  SpikeTrap_Socket = "SpikeTrap_Socket",
  MeleeWeapon = "MeleeWeapon",
  MainWeaponBackSocketL = "MainWeaponBackSocketL",
  MainWeaponBackSocketR = "MainWeaponBackSocketR",
  MainWeaponBackSocketL_NoBag = "MainWeaponBackSocketL_NoBag",
  MainWeaponBackSocketR_NoBag = "MainWeaponBackSocketR_NoBag",
  SubWeaponBackSocket = "SubWeaponBackSocket",
  HelmetSocket = "HelmetSocket",
  FaceSocket = "FaceSocket",
  BeardSocket = "BeardSocket",
  FirstPersonCameraPoint = "FirstPersonCameraPoint",
  FPPSocket = "FPPSocket",
  FPSAPistolSocket = "FPSAPistolSocket",
  FPSARifleSocket = "FPSARifleSocket",
  neck_01Socket = "neck_01Socket",
  Parachute_Socket = "Parachute_Socket",
  BackpackPetScoket = "BackpackPetScoket",
  Pendant_Socket = "Pendant_Socket",
  Ring = "Ring",
  ClothSocket = "ClothSocket",
  DriverVehMesh = "DriverVehMesh",
  Skill_Device_Socket = "Skill_Device_Socket",
  VH_HitBoxSocket = "VH_HitBoxSocket",
  NearDead_HitBoxSocket = "NearDead_HitBoxSocket",
  calf_lSocket = "calf_lSocket",
  calf_rSocket = "calf_rSocket",
  calf_lSocket_Effect = "calf_lSocket_Effect",
  calf_rSocket_Effect = "calf_rSocket_Effect",
  upperarm_lSocket = "upperarm_lSocket",
  UpperArmSocket_R = "UpperArmSocket_R",
  LeftWaistSocket = "LeftWaistSocket",
  foot_lSocket = "foot_lSocket",
  foot_rSocket = "foot_rSocket",
  spine_03Socket = "spine_03Socket",
  RootSocket = "RootSocket",
  RootSocket_0 = "RootSocket_0",
  RootSocket_1 = "RootSocket_1",
  RootSocket_02 = "RootSocket_02"
}
UGCLuaGlobalDefine.Enum_NeedStartVMState = {
  NotCheck = 0,
  NeedStartVM = 1,
  NotNeedStartVM = 2
}
return UGCLuaGlobalDefine
