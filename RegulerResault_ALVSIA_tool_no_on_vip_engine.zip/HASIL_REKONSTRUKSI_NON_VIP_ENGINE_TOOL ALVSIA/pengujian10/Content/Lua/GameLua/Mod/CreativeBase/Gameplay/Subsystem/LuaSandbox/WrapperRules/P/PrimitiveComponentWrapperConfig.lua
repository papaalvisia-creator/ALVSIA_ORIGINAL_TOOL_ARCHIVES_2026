local UserdataConfig = require("GameLua.ExtraModule.Generic.Capability.Sandbox.Security.LuaSandboxUserdataConfig")
local BaseConfig = require("GameLua.ExtraModule.Generic.Capability.Sandbox.Security.SandboxSecurityConfig")
local WrapperRuleUtility = require("GameLua.Mod.CreativeBase.Gameplay.Subsystem.LuaSandbox.WrapperRules.WrapperRuleUtility")
local ACCESS_MODE = UserdataConfig.ACCESS_MODE
local API_CATEGORY = UserdataConfig.API_CATEGORY
local API_TAG = UserdataConfig.API_TAG
local PrimitiveComponentWrapperRules = {}
PrimitiveComponentWrapperRules.WRAPPER_RULES = {
  WoWPrimitiveComponentBase = {
    __example = "GameLua.Dev.SandBoxAPIExamplarCode.WoWPrimitiveComponentBaseExample",
    __source_classes = {
      "PrimitiveComponent"
    },
    __extends = "WoWSceneComponentBase",
    __description = "A PrimitiveComponent owns collision geometry and may participate in scene queries, overlap/hit events, " .. "and rigid-body simulation. Collision settings, overlap generation, and physics simulation are independent controls: " .. "configure all controls required by the intended behavior. Positions use cm, linear velocities use cm/s, " .. "and angular velocities exposed here use degrees/s.",
    __category = API_CATEGORY.L2_SELECTED_CLASS,
    __tag = API_TAG.L2_COMPONENTS,
    __realms = {
      [BaseConfig.SandboxRealm.Client] = true,
      [BaseConfig.SandboxRealm.Server] = true
    },
    fields = {
      bGenerateOverlapEvents = {
        mode = ACCESS_MODE.READ_WRITE,
        type = "boolean",
        description = "Enable maintenance of overlap state and Begin/EndOverlap events for this component. " .. "Both components must enable this flag, use QueryOnly or QueryAndPhysics collision, and resolve their channel responses to Overlap. " .. "This flag does not perform an immediate world query, and registering a callback does not configure collision."
      },
      OnComponentBeginOverlap = {
        mode = ACCESS_MODE.READ_ONLY,
        type = "function(OverlappedComponent:WoWPrimitiveComponentBase, OtherActor:WoWActorBase, OtherComp:WoWPrimitiveComponentBase, OtherBodyIndex:integer, bFromSweep:boolean, SweepResult:FHitResult)",
        description = "Register through AddEnvControlEvent to handle a newly tracked overlap. OverlappedComponent is this component; " .. "OtherActor and OtherComp identify the other object; OtherBodyIndex identifies its body. bFromSweep is true when swept movement " .. "created the overlap, in which case SweepResult contains useful contact data. Registration alone does not configure collision."
      },
      OnComponentEndOverlap = {
        mode = ACCESS_MODE.READ_ONLY,
        type = "function(OverlappedComponent:WoWPrimitiveComponentBase, OtherActor:WoWActorBase, OtherComp:WoWPrimitiveComponentBase, OtherBodyIndex:integer)",
        description = "Register through AddEnvControlEvent to handle the end of a previously tracked overlap. " .. "The parameters identify this component, the other Actor/component, and the other body's index. " .. "Disabling collision, overlap generation, or changing responses can also end an existing overlap."
      },
      OnComponentHit = {
        mode = ACCESS_MODE.READ_ONLY,
        type = "function(HitComponent:WoWPrimitiveComponentBase, OtherActor:WoWActorBase, OtherComp:WoWPrimitiveComponentBase, NormalImpulse:FVector, Hit:FHitResult)",
        description = "Register through AddEnvControlEvent to handle blocking contact from swept movement, Character movement, or physics simulation. " .. "This requires a Block response rather than Overlap. Physics-simulation contacts additionally require Simulation Generates Hit Events; " .. "swept blocking hits do not. NormalImpulse is normally zero for swept hits and populated for simulated-body contacts."
      },
      CanCharacterStepUpOn = {
        mode = ACCESS_MODE.READ_WRITE,
        type = "CanBeCharacterBase",
        realms = {
          [BaseConfig.SandboxRealm.Client] = true,
          [BaseConfig.SandboxRealm.Server] = true
        },
        description = "Whether Characters may step up onto this component or use it as their movement base. " .. "ECB_No blocks stepping up and makes standing Characters slide off; ECB_Yes allows both; " .. "ECB_Owner defers to the owning Actor. This property is NOT replicated and is used by client-predicted " .. "Character movement, so set the same value on both Server and every Client; otherwise movement corrections " .. "(rubber-banding) occur."
      }
    },
    methods = {
      SetCollisionEnabled = {
        mode = ACCESS_MODE.METHOD,
        description = "Choose which collision systems use this component. NoCollision disables queries and physics collision; " .. "QueryOnly supports traces, sweeps, and overlaps; PhysicsOnly supports rigid-body collision but not queries; " .. "QueryAndPhysics supports both. Changing the mode may begin or end tracked overlaps. " .. "Client calls are local; Server uses the creative setter when available so the state can replicate.",
        description_fields = {
          {
            name = "NewType",
            type = "CollisionEnabled",
            description = "NoCollision, QueryOnly, PhysicsOnly, or QueryAndPhysics. Traces and overlap events require a query-capable mode."
          }
        },
        override = function(self, NewCollisionEnabledType)
          print(bWriteLog and "WoWPrimitiveComponentBase:SetCollisionEnabled NewCollisionEnabledType:" .. tostring(NewCollisionEnabledType))
          if Client then
            self:SetCollisionEnabled(NewCollisionEnabledType)
            return
          end
          if self.CreativeSetCollisionEnabled ~= nil then
            self:CreativeSetCollisionEnabled(NewCollisionEnabledType)
          else
            self:SetCollisionEnabled(NewCollisionEnabledType)
          end
        end
      },
      SetCollisionResponseToChannel = {
        mode = ACCESS_MODE.METHOD,
        description = "Set how this component responds to objects of one collision channel. Unreal combines both objects' settings: " .. "Ignore on either side suppresses contact, Block requires both sides to Block, and the remaining Block/Overlap combinations resolve to Overlap. " .. "Overlap events also require query collision and bGenerateOverlapEvents on both components. This native setter is local to the executing realm.",
        description_fields = {
          {
            name = "Channel",
            type = "ECollisionChannel",
            description = "Object channel to configure, such as ECC_Pawn; this is the other object's ObjectType."
          },
          {
            name = "NewResponse",
            type = "ECollisionResponse",
            description = "ECR_Ignore, ECR_Overlap, or ECR_Block."
          }
        }
      },
      GetCollisionResponseToChannel = {
        mode = ACCESS_MODE.METHOD,
        description = "Read this component's configured response to one object channel. This does not query the world or calculate " .. "the final interaction with a particular component, because that result also depends on the other component's response.",
        description_fields = {
          {
            name = "Channel",
            type = "ECollisionChannel",
            description = "Object channel whose configured response will be read."
          }
        },
        return_fields = {
          {
            name = "Response",
            type = "ECollisionResponse",
            description = "Configured ECR_Ignore, ECR_Overlap, or ECR_Block response."
          }
        }
      },
      GetCollisionObjectType = {
        mode = ACCESS_MODE.METHOD,
        description = "Return this component's object channel. Other components use this value to select their response to this component. " .. "This reads collision configuration and does not perform a scene query.",
        return_fields = {
          {
            name = "ObjectType",
            type = "ECollisionChannel",
            description = "Current object channel, such as ECC_WorldDynamic or ECC_Pawn."
          }
        }
      },
      SetSimulatePhysics = {
        mode = ACCESS_MODE.METHOD,
        description = "Enable or disable rigid-body simulation. The component needs a valid physics body; physical contacts also require " .. "physics-capable collision. Enabling simulation on a simple attached body detaches it, while disabling simulation does not reattach it. " .. "Client calls are local; Server uses DSSetSimulatePhysics when available so supported creative components can replicate the state.",
        description_fields = {
          {
            name = "bSimulate",
            type = "boolean",
            description = "True to make the body dynamic under physics; false to stop simulation and return transform control to gameplay code."
          }
        },
        override = function(self, bSimulate)
          print(bWriteLog and "WoWPrimitiveComponentBase:SetSimulatePhysics bSimulate:" .. tostring(bSimulate))
          if Client then
            self:SetSimulatePhysics(bSimulate)
            return
          end
          if self.DSSetSimulatePhysics ~= nil then
            self:DSSetSimulatePhysics(bSimulate)
          else
            self:SetSimulatePhysics(bSimulate)
          end
        end
      },
      AddForce = {
        mode = ACCESS_MODE.METHOD,
        description = "Apply a world-space force to one rigid body. Call every frame while the force should act; do not multiply Force by DeltaTime. " .. "The target body must simulate physics. This call executes only in the current realm and does not itself send an RPC.",
        description_fields = {
          {
            name = "Force",
            type = "FVector",
            description = "World-space force vector; with default Unreal units, values represent kg*cm/s^2."
          },
          {
            name = "BoneName",
            type = "string",
            description = "Optional SkeletalMesh body name; use \"None\" or omit it for the root body."
          },
          {
            name = "bAccelChange",
            type = "boolean",
            description = "Optional. True treats Force as acceleration so mass has no effect; defaults to false."
          }
        }
      },
      AddImpulse = {
        mode = ACCESS_MODE.METHOD,
        description = "Apply a one-time world-space impulse to one rigid body, for example a jump, recoil, or impact. " .. "Call once per event rather than every frame. The target body must simulate physics. " .. "This call executes only in the current realm and does not itself send an RPC.",
        description_fields = {
          {
            name = "Impulse",
            type = "FVector",
            description = "World-space impulse vector; with default Unreal units, values represent kg*cm/s."
          },
          {
            name = "BoneName",
            type = "string",
            description = "Optional SkeletalMesh body name; use \"None\" or omit it for the root body."
          },
          {
            name = "bVelChange",
            type = "boolean",
            description = "Optional. True treats Impulse as a direct velocity change so mass has no effect; defaults to false."
          }
        }
      },
      AddRadialImpulse = {
        mode = ACCESS_MODE.METHOD,
        description = "Apply a one-time outward impulse from a world-space origin to this component's simulated body or bodies inside Radius. " .. "Use for explosion-like effects and call once per event. This does not search for or affect other components in the world. " .. "The call executes only in the current realm.",
        description_fields = {
          {
            name = "Origin",
            type = "FVector",
            description = "World-space center of the radial impulse, in cm."
          },
          {
            name = "Radius",
            type = "number",
            description = "Maximum effect radius in cm; bodies outside it receive no impulse."
          },
          {
            name = "Strength",
            type = "number",
            description = "Impulse strength at the origin, interpreted according to bVelChange."
          },
          {
            name = "Falloff",
            type = "ERadialImpulseFalloff",
            description = "RIF_Constant for equal strength inside Radius, or RIF_Linear to decrease strength with distance."
          },
          {
            name = "bVelChange",
            type = "boolean",
            description = "Optional. True applies Strength as a mass-independent velocity change; defaults to false."
          }
        }
      },
      SetPhysicsLinearVelocity = {
        mode = ACCESS_MODE.METHOD,
        description = "Replace the root rigid body's world-space linear velocity. Prefer AddForce or AddImpulse for physically driven motion. " .. "This sandbox override clamps each X/Y/Z component independently to [0, 20000] cm/s, so it cannot set negative velocity. " .. "It always uses bAddToCurrent=false and BoneName=None.",
        description_fields = {
          {
            name = "NewVel",
            type = "FVector",
            description = "Requested world-space velocity in cm/s; each component is clamped independently to [0, 20000]."
          }
        },
        override = function(self, NewVel)
          print(bWriteLog and "WoWPrimitiveComponentBase:SetPhysicsLinearVelocity NewVel:" .. tostring(NewVel))
          if not self or not slua.isValid(self) then
            return
          end
          local _NewVel = WrapperRuleUtility.VectorClamp(NewVel, 0, 20000)
          self:SetPhysicsLinearVelocity(_NewVel, false, "None")
        end
      },
      GetPhysicsLinearVelocity = {
        mode = ACCESS_MODE.METHOD,
        description = "Return one rigid body's current world-space linear velocity. This reads physics state and does not predict future movement.",
        description_fields = {
          {
            name = "BoneName",
            type = "string",
            description = "Optional SkeletalMesh body name; use \"None\" or omit it for the root body."
          }
        },
        return_fields = {
          {
            name = "Velocity",
            type = "FVector",
            description = "World-space linear velocity in cm/s; zero when no matching body is available."
          }
        }
      },
      SetPhysicsAngularVelocityInDegrees = {
        mode = ACCESS_MODE.METHOD,
        description = "Set one rigid body's world-space angular velocity. By default this replaces the current velocity; " .. "set bAddToCurrent=true to add to it. Prefer torque or angular impulse for physically driven rotation. " .. "The target body must simulate physics.",
        description_fields = {
          {
            name = "NewAngVel",
            type = "FVector",
            description = "Angular velocity around the world X/Y/Z axes, in degrees/s."
          },
          {
            name = "bAddToCurrent",
            type = "boolean",
            description = "Optional. True adds NewAngVel to the current velocity; false replaces it. Defaults to false."
          },
          {
            name = "BoneName",
            type = "string",
            description = "Optional SkeletalMesh body name; use \"None\" or omit it for the root body."
          }
        }
      },
      GetPhysicsAngularVelocityInDegrees = {
        mode = ACCESS_MODE.METHOD,
        description = "Return one rigid body's current world-space angular velocity in degrees per second.",
        description_fields = {
          {
            name = "BoneName",
            type = "string",
            description = "Optional SkeletalMesh body name; use \"None\" or omit it for the root body."
          }
        },
        return_fields = {
          {
            name = "AngularVelocity",
            type = "FVector",
            description = "Angular velocity around the world X/Y/Z axes, in degrees/s."
          }
        }
      },
      AddForceAtLocation = {
        mode = ACCESS_MODE.METHOD,
        description = "Apply a world-space force at a world-space point on one rigid body. Call every frame while the force should act; " .. "do not multiply Force by DeltaTime. Applying the force away from the center of mass also creates torque. " .. "The target body must simulate physics.",
        description_fields = {
          {
            name = "Force",
            type = "FVector",
            description = "World-space force vector; with default Unreal units, values represent kg*cm/s^2."
          },
          {
            name = "Location",
            type = "FVector",
            description = "World-space application point in cm; this determines the torque generated by the force."
          },
          {
            name = "BoneName",
            type = "string",
            description = "Optional SkeletalMesh body name; use \"None\" or omit it for the root body."
          }
        }
      },
      GetOverlappingActors = {
        mode = ACCESS_MODE.METHOD,
        description = "Return the unique Actors represented by this component's currently tracked overlaps. " .. "This reads maintained overlap state rather than performing a fresh geometry query, so results depend on query collision, " .. "bGenerateOverlapEvents on both sides, compatible channel responses, and prior overlap updates.",
        return_fields = {
          {
            name = "Actors",
            type = "WoWActorBase[]",
            description = "Unique currently overlapping Actors; an Actor appears once even when several owned components overlap. Empty when none are tracked."
          }
        }
      },
      GetOverlappingComponents = {
        mode = ACCESS_MODE.METHOD,
        description = "Return the unique PrimitiveComponents in this component's currently tracked overlaps. " .. "This is not a fresh world query and does not discover contacts for which overlap generation was disabled.",
        return_fields = {
          {
            name = "Components",
            type = "WoWPrimitiveComponentBase[]",
            description = "Unique currently overlapping PrimitiveComponents; empty when none are tracked."
          }
        }
      },
      IsOverlappingActor = {
        mode = ACCESS_MODE.METHOD,
        description = "Check whether maintained overlap state contains at least one component owned by Other. " .. "This does not perform a new collision query, so false can also mean overlap generation or collision responses were not configured.",
        description_fields = {
          {
            name = "Other",
            type = "WoWActorBase",
            description = "Actor whose owned components will be checked in the tracked overlap set."
          }
        },
        return_fields = {
          {
            name = "Result",
            type = "boolean",
            description = "True when at least one active overlap with a component owned by Other is tracked."
          }
        }
      },
      SetCollisionProfileName = {
        mode = ACCESS_MODE.METHOD,
        description = "Apply an existing project collision profile. The profile replaces collision-enabled mode, object type, " .. "and all per-channel responses, so call per-channel setters afterwards when custom overrides are needed. " .. "Applying a profile may begin or end tracked overlaps. Client calls are local; " .. "Server uses the creative setter when available so the state can replicate.",
        description_fields = {
          {
            name = "InCollisionProfileName",
            type = "InCollisionProfileName",
            description = "Name of a collision profile defined by the project, mapped through InCollisionProfileName."
          }
        },
        override = function(self, InCollisionProfileName)
          print(bWriteLog and "WoWPrimitiveComponentBase:SetCollisionProfileName InCollisionProfileName:" .. tostring(InCollisionProfileName))
          if not self or not slua.isValid(self) then
            return
          end
          if Client then
            self:SetCollisionProfileName(InCollisionProfileName)
            return
          end
          if self.CreativeSetCollisionEnabled ~= nil then
            self:CreativeSetCollisionProfileName(InCollisionProfileName)
          else
            self:SetCollisionProfileName(InCollisionProfileName)
          end
        end
      },
      GetCollisionProfileName = {
        mode = ACCESS_MODE.METHOD,
        description = "Return the collision profile name stored on this component. This reads configuration and performs no world query. " .. "Later per-channel changes may make the effective settings differ from the original profile preset.",
        return_fields = {
          {
            name = "ProfileName",
            type = "string",
            description = "Stored profile name; effective per-channel settings may have been changed afterwards."
          }
        }
      },
      AddIgnoreComponent = {
        mode = ACCESS_MODE.METHOD,
        description = "Add one component to this component's movement-ignore list. It is skipped when this component performs swept movement " .. "and updates movement overlaps; this does not disable physics-simulation contact or unrelated traces. " .. "The relationship is directional, so the other component may need a matching entry when it also moves. " .. "Client changes are local; Server uses the creative replicated setter when available.",
        description_fields = {
          {
            name = "InComponent",
            type = "PrimitiveComponent",
            description = "Valid PrimitiveComponent to ignore when this component performs movement queries."
          }
        },
        override = function(self, InComponent)
          print(bWriteLog and "WoWPrimitiveComponentBase:AddIgnoreComponent InComponent:" .. tostring(InComponent))
          if not self or not slua.isValid(self) then
            return
          end
          if not slua.isValid(InComponent) then
            return
          end
          if Client then
            if self.MoveIgnoreComponents == nil then
              return
            end
            self.MoveIgnoreComponents:Add(InComponent)
            return
          end
          if self.CreativeAddIgnoreComponent ~= nil then
            self:CreativeAddIgnoreComponent(InComponent)
          else
            if self.MoveIgnoreComponents == nil then
              return
            end
            self.MoveIgnoreComponents:Add(InComponent)
          end
        end
      },
      RemoveIgnoreComponent = {
        mode = ACCESS_MODE.METHOD,
        description = "Remove the first matching component from this component's movement-ignore list, restoring normal movement-query handling. " .. "This does not change collision channels or simulated-physics contacts. Because AddIgnoreComponent permits duplicates, " .. "repeated additions may require repeated removals. Client changes are local; " .. "Server uses the creative replicated setter when available.",
        description_fields = {
          {
            name = "InComponent",
            type = "PrimitiveComponent",
            description = "Valid PrimitiveComponent whose movement-ignore entry will be removed."
          }
        },
        override = function(self, InComponent)
          print(bWriteLog and "WoWPrimitiveComponentBase:RemoveIgnoreComponent InComponent:" .. tostring(InComponent))
          if not self or not slua.isValid(self) then
            return
          end
          if not slua.isValid(InComponent) then
            return
          end
          if Client then
            if self.MoveIgnoreComponents == nil then
              return
            end
            for i = 0, self.MoveIgnoreComponents:Num() - 1 do
              if self.MoveIgnoreComponents:Get(i) == InComponent then
                self.MoveIgnoreComponents:Remove(i)
                break
              end
            end
            return
          end
          if self.CreativeRemoveIgnoreComponent ~= nil then
            self:CreativeRemoveIgnoreComponent(InComponent)
          else
            if self.MoveIgnoreComponents == nil then
              return
            end
            for i = 0, self.MoveIgnoreComponents:Num() - 1 do
              if self.MoveIgnoreComponents:Get(i) == InComponent then
                self.MoveIgnoreComponents:Remove(i)
                break
              end
            end
          end
        end
      },
      AddIgnoreActor = {
        mode = ACCESS_MODE.METHOD,
        description = "Add an Actor to this component's movement-ignore list. All components owned by that Actor are skipped when this component " .. "performs swept movement and updates movement overlaps. This does not globally disable collision, simulated-physics contact, " .. "or unrelated traces, and the relationship is directional. Client changes are local; " .. "Server uses the creative replicated setter when available.",
        description_fields = {
          {
            name = "InActor",
            type = "WoWActorBase",
            description = "Valid Actor whose owned components should be ignored by this component's movement queries."
          }
        },
        override = function(self, InActor)
          print(bWriteLog and "WoWPrimitiveComponentBase:AddIgnoreActor InActor:" .. tostring(InActor))
          if not self or not slua.isValid(self) then
            return
          end
          if not slua.isValid(InActor) then
            return
          end
          if Client then
            if self.MoveIgnoreActors == nil then
              return
            end
            self.MoveIgnoreActors:Add(InActor)
            return
          end
          if self.CreativeAddIgnoreActor ~= nil then
            self:CreativeAddIgnoreActor(InActor)
          else
            if self.MoveIgnoreActors == nil then
              return
            end
            self.MoveIgnoreActors:Add(InActor)
          end
        end
      },
      RemoveIgnoreActor = {
        mode = ACCESS_MODE.METHOD,
        description = "Remove the first matching Actor from this component's movement-ignore list, restoring normal movement-query handling " .. "against its components. This does not modify collision channels or simulated-physics contacts. " .. "Repeated additions may require repeated removals. Client changes are local; " .. "Server uses the creative replicated setter when available.",
        description_fields = {
          {
            name = "InActor",
            type = "WoWActorBase",
            description = "Valid Actor whose movement-ignore entry will be removed."
          }
        },
        override = function(self, InActor)
          print(bWriteLog and "WoWPrimitiveComponentBase:RemoveIgnoreActor InActor:" .. tostring(InActor))
          if not self or not slua.isValid(self) then
            return
          end
          if not slua.isValid(InActor) then
            return
          end
          if Client then
            if self.MoveIgnoreActors == nil then
              return
            end
            for i = 0, self.MoveIgnoreActors:Num() - 1 do
              if self.MoveIgnoreActors:Get(i) == InActor then
                self.MoveIgnoreActors:Remove(i)
                break
              end
            end
            return
          end
          if self.CreativeRemoveIgnoreActor ~= nil then
            self:CreativeRemoveIgnoreActor(InActor)
          else
            if self.MoveIgnoreActors == nil then
              return
            end
            for i = 0, self.MoveIgnoreActors:Num() - 1 do
              if self.MoveIgnoreActors:Get(i) == InActor then
                self.MoveIgnoreActors:Remove(i)
                break
              end
            end
          end
        end
      }
    }
  }
}
return PrimitiveComponentWrapperRules
