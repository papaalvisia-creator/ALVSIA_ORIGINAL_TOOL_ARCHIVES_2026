local ModeSelection_Mine_Long_Item_UIBP = {}
local ModeSelection_Common_Item_Base_UIBP = require("GameLua.Mod.Lobby.Split.ModeSelection470.umg.Main.Item.Sub.ModeSelection_Common_Item_Base_UIBP")
local LOCK_REASON_EXT = ModeSelection_Common_Item_Base_UIBP.LOCK_REASON_EXT

function ModeSelection_Mine_Long_Item_UIBP:RefreshRatingProtectData()
  self.isShowRatingProtect = false
  self:_SetRatingProtectVisible(false)
end

function ModeSelection_Mine_Long_Item_UIBP:_RefreshUGCLoadingCover()
  self:_ApplyUGCLoadingCoverPlaceholder()
end

local function IsTimeLimitedLock(item, data)
  if type(data) ~= "table" or not LOCK_REASON_EXT then
    return false
  end
  local bLocked, lockReason = item:_IsViewLocked(data)
  if not bLocked then
    return false
  end
  return lockReason == LOCK_REASON_EXT.TimeCountdown or lockReason == LOCK_REASON_EXT.TimeEnded
end

function ModeSelection_Mine_Long_Item_UIBP:UpdateFlagBgState(data)
  local state = ModeSelection_Mine_Long_Item_UIBP.__super.UpdateFlagBgState(self, data)
  local bSuppress = state == self.FlagBgState.Long.Peak
  if not bSuppress and state == self.FlagBgState.Long.Locked then
    bSuppress = IsTimeLimitedLock(self, data)
  end
  if not bSuppress then
    return state
  end
  self:_SetFlagBgState(self.FlagBgState.Long.Normal)
  return self.FlagBgState.Long.Normal
end

function ModeSelection_Mine_Long_Item_UIBP:_RefreshLockText(data)
  local bSuppress
  if self:_IsPeakView(data) then
    bSuppress = not self:_IsViewLocked(data, true)
  else
    bSuppress = IsTimeLimitedLock(self, data)
  end
  if not bSuppress then
    ModeSelection_Mine_Long_Item_UIBP.__super._RefreshLockText(self, data)
    return
  end
  self:_StopLockTextTimer()
  if self.UIRoot and self.UIRoot.TextBlock_4 then
    self:SetWidgetVisible(self.UIRoot.TextBlock_4, false)
  end
end

local class = require("class")
local card_base = require("GameLua.Mod.Lobby.Split.ModeSelection470.umg.Main.Item.Sub.ModeSelection_Common_Long_Item_UIBP")
return class(card_base, nil, ModeSelection_Mine_Long_Item_UIBP)
