local ActiveExchange_Shop_Preview_UIBP = {}
local CDN_TABLE_NAME = "SeasonRewardCDN"
local CDN_IMAGE_SIZE = 1024

local function GetCDNUrl(itemId)
  local CDNCfg = CDataTable.GetTableData(CDN_TABLE_NAME, itemId)
  if not CDNCfg then
    return nil
  end
  local version = "global"
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  if GlobalData.IsJapanOrKorea() then
    version = "JK"
  elseif PublishRegionMacros.IsBlueholeOperationRegion() then
    version = "blue"
  end
  local url = CDNCfg["ImageUrl_" .. version]
  if not url or url == "" then
    url = CDNCfg.ImageUrl_global
  end
  log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:GetImageUrl url = " .. tostring(url))
  return url
end

local function ApplyCDNBrushSize(image)
  if not slua.isValid(image) then
    return
  end
  local size = FVector2D(CDN_IMAGE_SIZE, CDN_IMAGE_SIZE)
  local BrushRef = slua.IndexReference(image, "Brush")
  if not BrushRef then
    return
  end
  local BrushClone = BrushRef:clone()
  BrushClone.ImageSize = size
  image:SetBrush(BrushClone)
  local slot = image.Slot
  if slot then
    slot:SetSize(size)
    slot:SetAutoSize(true)
  end
end

function ActiveExchange_Shop_Preview_UIBP:OnInitialize()
  self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_4, false)
end

function ActiveExchange_Shop_Preview_UIBP:RegistEvents()
  self:AddOnClickedEventByControl(self.UIRoot.Button_HideUI, self.OnClickButton_HideUI, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_ShowUI, self.OnClickButton_ShowUI, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Play, self.OnClickButton_Play, self)
  self:AddCommonEvent(EVENTTYPE_SETTING, EVENTID_VIEWPORT_SIZE_CHANGED, self.OnScreenRatioChanged, self)
  self:AddCommonEvent(EVENTTYPE_PUFFER, EVENTID_PUFFER_DOWNLOADFINISH, self.OnDownloadFinish, self)
end

function ActiveExchange_Shop_Preview_UIBP:ClearGiftAni()
  local giftAniUI = self.giftAniUI
  self.giftAniUI = nil
  if not giftAniUI or giftAniUI._IsClosed then
    return
  end
  if giftAniUI.StopAnimation then
    giftAniUI:StopAnimation()
  end
  giftAniUI:Close()
end

function ActiveExchange_Shop_Preview_UIBP:ShowGiftLoop(itemId)
  local logic_send_gift = require("client.slua.logic.gift.logic_send_gift")
  local giftInfo = logic_send_gift.GetGiftDataByResID(itemId)
  local giftAni = giftInfo and giftInfo.GiftAni
  if not giftAni or giftAni == "" then
    log(bWriteLog and string.format("ActiveExchange_Shop_Preview_UIBP:ShowGiftLoop no GiftAni itemId=%s", tostring(itemId)))
    return
  end
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  local state = PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, {giftAni})
  if state ~= PufferConst.ENUM_DownloadState.Done then
    log(bWriteLog and string.format("ActiveExchange_Shop_Preview_UIBP:ShowGiftLoop pak not ready itemId=%s state=%s", tostring(itemId), tostring(state)))
    self:ShowGiftDownloadUI(itemId, giftAni)
    return
  end
  if not self.UIRoot.CanvasPanel_Left then
    log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:ShowGiftLoop CanvasPanel_Left is nil")
    return
  end
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Left, true)
  local previewItemId = itemId
  self.giftAniUI = self:CreateChildWindowWithBpPath(self.UIRoot.CanvasPanel_Left, UIManager.UI_Config.roleinfo_send_gift_ani, giftAni, function(aniUI)
    if not aniUI or aniUI._IsClosed or self.giftAniUI ~= aniUI or self.itemId ~= previewItemId then
      return
    end
    aniUI:LoopAnimation()
  end)
  if not self.giftAniUI or not slua.isValid(self.giftAniUI.UIRoot) then
    log(bWriteLog and string.format("ActiveExchange_Shop_Preview_UIBP:ShowGiftLoop create failed itemId=%s", tostring(itemId)))
    self:ClearGiftAni()
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Left, false)
    return
  end
  local aniRoot = self.giftAniUI.UIRoot
  local util = require("client.slua_ui_framework.util")
  util.SetAnchors(aniRoot, 0.5, 0.5, 0.5, 0.5)
  util.SetAlignment(aniRoot, 0.5, 0.5)
  if aniRoot.Slot and aniRoot.Slot.SetPosition then
    aniRoot.Slot:SetPosition(FVector2D(0, 0))
  end
  if aniRoot.Slot and aniRoot.Slot.SetAutoSize then
    aniRoot.Slot:SetAutoSize(true)
  end
  self.giftAniUI:LoopAnimation()
  log(bWriteLog and string.format("ActiveExchange_Shop_Preview_UIBP:ShowGiftLoop itemId=%s", tostring(itemId)))
end

function ActiveExchange_Shop_Preview_UIBP:HidePreviewDisplay()
  self:ClearGiftAni()
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  ModelDisplayer.Hide("Segment")
  if not self.UIRoot then
    return
  end
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_TitleOrFrame, false)
  self:SetWidgetVisible(self.UIRoot.CDNImage, false)
  self:SetWidgetVisible(self.UIRoot.Image_5, false)
  self:SetWidgetVisible(self.UIRoot.Button_HideUI, false, true)
  self:SetWidgetVisible(self.UIRoot.Button_ShowUI, false, true)
  self:SetWidgetVisible(self.UIRoot.Button_Play, false, true)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Left, false, false)
end

function ActiveExchange_Shop_Preview_UIBP:UpdatePreview(itemId)
  log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:UpdatePreview itemId:" .. tostring(itemId))
  if not self.UIRoot then
    log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:UpdatePreview UIRoot is nil")
    return
  end
  self:ClearCurrentEffect()
  self:ClearGiftAni()
  if self.UIRoot.CanvasPanel_Preview then
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_4, false)
    if self.child_1 ~= nil then
      self.child_1:Close()
      self.child_1 = nil
    end
    if self.child_2 ~= nil then
      self.child_2:Close()
      self.child_2 = nil
    end
  end
  if itemId == nil then
    self:HidePreviewDisplay()
    return
  end
  local itemCfg = CDataTable.GetTableData("Item", itemId)
  if not itemCfg then
    log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:UpdatePreview no itemCfg, itemId:" .. tostring(itemId))
    self:HidePreviewDisplay()
    self.itemId = itemId
    return
  end
  log_tree("ActiveExchange_Shop_Preview_UIBP:UpdatePreview itemCfg:", itemCfg)
  self.itemId = itemId
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_TitleOrFrame, false)
  self:SetWidgetVisible(self.UIRoot.CDNImage, false)
  self:SetWidgetVisible(self.UIRoot.Image_5, false)
  self:SetWidgetVisible(self.UIRoot.Button_HideUI, false, true)
  self:SetWidgetVisible(self.UIRoot.Button_ShowUI, false, true)
  self:SetWidgetVisible(self.UIRoot.Button_Play, false, true)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Left, false, false)
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local ModelDisplayTypeHelper = require("client.logic.avatar.ModelDisplayTypeHelper")
  ModelDisplayer.Show()
  if itemCfg.ItemType == ENUM_ITEM_TYPE.Achievement_Title then
    ModelDisplayer.Restore("Segment")
    self:UpdateAlias()
  elseif itemCfg.ItemType == ENUM_ITEM_TYPE.Famous_Brand then
    ModelDisplayer.Restore("Segment")
    self:UpdateFrame()
  elseif itemCfg.ItemType == ENUM_ITEM_TYPE.Extra and itemCfg.ItemSubType == 422 then
    ModelDisplayer.Restore("Segment")
    local config = CDataTable.GetTableDataByFilter("TeamupEntryParticleConfig", "ItemID", itemId)
    if config then
      self:PlayPeakGameGodEffect(config)
    else
      self:PlayGodEffect()
    end
  elseif itemCfg.ItemType == ENUM_ITEM_TYPE.Personalization and itemCfg.ItemSubType == ENUM_ITEM_SUBTYPE.PersonalOpening then
    ModelDisplayer.Hide("Segment")
    self:SetWidgetVisible(self.UIRoot.Button_HideUI, true, true)
    local cfg = CDataTable.GetTableData("PersonalOpeningCfg", itemCfg.itemID)
    if not cfg or cfg.BPPath == "" then
      log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:UpdatePreview not PersonalOpeningCfg, itemId:" .. tostring(itemCfg.itemID))
      return
    end
    local logic_roleinfo_personalization_util = require("client.logic.roleinfo.logic_roleinfo_personalization_util")
    local extraData = {
      bPlayOnce = true,
      animationTimeWhenFinish = tonumber(cfg.AnimationTimeWhenFinish) or 1,
      soundID = cfg.SoundID
    }
    self.openingUI = logic_roleinfo_personalization_util.AddEffectSkinByCreateChildWindow(self, cfg.BPPath, "CanvasPanel_FullScreen", "fadein", extraData)
    if not self.openingUI then
      self:AddDownloadResPath(cfg.BPPath)
    end
  elseif itemCfg.ItemType == 613 then
    ModelDisplayer.Hide("Segment")
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_4, true)
    self.UIRoot.WidgetSwitcher_4:SetActiveWidgetIndex(0)
    local displayItemId = itemCfg.itemID
    local itemDisplayFallbackLogic = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.item_display_fallback_logic)
    if itemDisplayFallbackLogic:IsSmallPackageResourceMissing(displayItemId) then
      local logic_roleInfo_nicknameframe = require("client.slua.logic.roleInfo.logic_roleInfo_nicknameframe")
      displayItemId = logic_roleInfo_nicknameframe:GetShowDataListGetDefaultID()
    end
    local cfg = CDataTable.GetTableData("NicknameEffectCfg", displayItemId)
    if cfg then
      local logic_roleinfo_personalization_util = require("client.logic.roleinfo.logic_roleinfo_personalization_util")
      self.child_1 = logic_roleinfo_personalization_util.AddEffectSkinByCreateChildWindow(self, cfg.BPPath, "CanvasPanel_Effect_2", "Anim_In")
      self.child_2 = logic_roleinfo_personalization_util.AddEffectSkinByCreateChildWindow(self, cfg.BPPath, "CanvasPanel_Effect_1", "Anim_In")
      if not self.child_1 then
        self:AddDownloadResPath(cfg.BPPath)
      end
    else
      log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:UpdatePreview no NicknameEffectCfg, itemId:" .. tostring(itemId))
    end
    local logic_profile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
    local profile = logic_profile:GetLocalProfile(tonumber(DataMgr.roleData.uid))
    if not profile then
      if self.UIRoot.UTRichTextBlock_0 then
        self.UIRoot.UTRichTextBlock_0:SetText("")
      end
      log(bWriteLog and "[BaseItem:UpdatePlayerInfo] nil profile")
      return nil
    end
    if self.UIRoot.Common_Avatar_BP_C_0 then
      self.UIRoot.UTRichTextBlock_0:SetText(profile.nickName)
      self.UIRoot.Common_Avatar_BP_C_0:InitView(1, profile.uid, profile.picUrl, profile.sex, profile.cur_avatar_box_id, profile.level, false, "")
      self.UIRoot.Common_Avatar_BP_C_0:SetButtonEnabled(false)
      self.UIRoot.Common_RankIntegralLevel_Style_Small_UIBP_C_0:SetRankInteral(FuncUtil.GetCurMaxSegementLevel(profile.segment_info))
      self.UIRoot.Common_Gender_UIBP:LoadIcon(profile.uid)
      local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
      if not PublishRegionMacros.IsBlueholeOperationRegion() then
        self:SetWidgetVisible(self.UIRoot.Image_flag, true)
        local UIUtil = require("client.common.ui_util")
        UIUtil.UpdateNationImage(self.UIRoot.Image_flag, profile.nation)
      else
        self:SetWidgetVisible(self.UIRoot.Image_flag, false)
      end
    end
  elseif itemCfg.ItemType == 614 then
    ModelDisplayer.Hide("Segment")
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_4, true)
    self.UIRoot.WidgetSwitcher_4:SetActiveWidgetIndex(2)
    local displayItemId = itemCfg.itemID
    local itemDisplayFallbackLogic = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.item_display_fallback_logic)
    if itemDisplayFallbackLogic:IsSmallPackageResourceMissing(displayItemId) then
      local logic_roleInfo_chatframe = require("client.slua.logic.roleInfo.logic_roleInfo_chatframe")
      displayItemId = logic_roleInfo_chatframe:GetDefaultID()
    end
    local cfg = CDataTable.GetTableData("ChatEffectCfg", displayItemId)
    if cfg then
      self.child_1 = self:CreateChildWindowWithBpPath(self.UIRoot.CanvasPanel_Effect, nil, cfg.BPPath)
      if self.child_1 and slua.isValid(self.child_1.UIRoot) then
        self.child_1:PlayUserWidgetAnimation(self.child_1.UIRoot.Loop, 0, 0, 0, 1)
      end
    else
      log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:UpdatePreview no ChatEffectCfg, itemId:" .. tostring(itemId))
    end
    self.UIRoot.WidgetSwitcher_Effect:SetActiveWidgetIndex(1)
    local logic_profile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
    local profile = logic_profile:GetLocalProfile(tonumber(DataMgr.roleData.uid))
    if not profile then
      if self.UIRoot.Text_Name then
        self.UIRoot.Text_Name:SetText("")
      end
      log(bWriteLog and "[BaseItem:UpdatePlayerInfo] nil profile")
      return nil
    end
    if self.UIRoot.Common_Avatar_BP then
      self.UIRoot.Text_Name:SetText(profile.nickName)
      self.UIRoot.Common_Avatar_BP:InitView(1, profile.uid, profile.picUrl, profile.sex, profile.cur_avatar_box_id, profile.level, false, "")
      self.UIRoot.Common_Avatar_BP:SetButtonEnabled(false)
    end
  elseif itemCfg.ItemType == 619 then
    ModelDisplayer.Restore("Segment")
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_4, true)
    self.UIRoot.WidgetSwitcher_4:SetActiveWidgetIndex(1)
    local NicknameColorManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.NicknameColorManager)
    self.UIRoot.NameTexBlock_1:SetColorAndOpacity(NicknameColorManager:GetColorByPlanID(itemCfg.itemID))
    self.UIRoot.NameTexBlock_1:SetText(DataMgr.roleData.nickName)
    self.UIRoot.Common_Collect_Level_DynamicLoading_UIBP:InitCollectBadge(DataMgr.roleData.uid, DataMgr.roleData.brief_collect_data)
  elseif itemCfg.ItemType == 20 then
    self.UIRoot.WidgetSwitcher_4:SetActiveWidgetIndex(3)
    ModelDisplayer.Hide("Segment")
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_4, true)
    local itemDisplayFallbackLogic = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.item_display_fallback_logic)
    if itemDisplayFallbackLogic and itemDisplayFallbackLogic:IsSmallPackageResourceMissing(itemId) then
      log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:UpdatePreview HeadIcon small-package pak missing, trigger download, itemId:%s", tostring(itemId))
      local headshot_module = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.headshot_module)
      local dynamicIcon = headshot_module:GetFrameDynamicIconByID(itemCfg.itemID)
      if dynamicIcon ~= "" then
        self:AddDownloadResPath(dynamicIcon)
      end
    end
    local logic_profile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
    local profile = logic_profile:GetLocalProfile(tonumber(DataMgr.roleData.uid))
    if not profile then
      if self.UIRoot.UTRichTextBlock_1 then
        self.UIRoot.UTRichTextBlock_1:SetText("")
      end
      log(bWriteLog and "[BaseItem:UpdatePlayerInfo] nil profile")
      return nil
    end
    if self.UIRoot.Common_Avatar_BP_C_1 then
      self.UIRoot.UTRichTextBlock_1:SetText(profile.nickName)
      self.UIRoot.Common_Avatar_BP_C_1.frameLevel = nil
      self.UIRoot.Common_Avatar_BP_C_1:InitView(1, profile.uid, profile.picUrl, profile.sex, itemCfg.itemID, profile.level, false, "")
      self.UIRoot.Common_Avatar_BP_C_1:SetButtonEnabled(false)
    end
    if self.UIRoot.Common_Avatar_BP_0 then
      self.UIRoot.UTRichTextBlock_1:SetText(profile.nickName)
      self.UIRoot.Common_Avatar_BP_0.frameLevel = nil
      self.UIRoot.Common_Avatar_BP_0:InitView(1, profile.uid, profile.picUrl, profile.sex, itemCfg.itemID, profile.level, false, "")
      self.UIRoot.Common_Avatar_BP_0:SetButtonEnabled(false)
    end
    self.UIRoot.Common_RankIntegralLevel_Style_Small_UIBP_C_1:SetRankInteral(FuncUtil.GetCurMaxSegementLevel(profile.segment_info))
    self.UIRoot.Common_Gender_UIBP_C_0:LoadIcon(profile.uid)
    local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
    if not PublishRegionMacros.IsBlueholeOperationRegion() then
      self:SetWidgetVisible(self.UIRoot.Image_6, true)
      local UIUtil = require("client.common.ui_util")
      UIUtil.UpdateNationImage(self.UIRoot.Image_6, profile.nation)
    else
      self:SetWidgetVisible(self.UIRoot.Image_6, false)
    end
  elseif itemCfg.ItemSubType == ENUM_ITEM_SUBTYPE.MVPAction then
    ModelDisplayer.Restore("Segment")
    self:SetWidgetVisible(self.UIRoot.Button_Play, true, true)
  elseif itemCfg.ItemSubType == ENUM_ITEM_SUBTYPE.MVPPosition or itemCfg.ItemSubType == ENUM_ITEM_SUBTYPE.Action then
    local itemDisplayFallbackLogic = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.item_display_fallback_logic)
    if itemDisplayFallbackLogic and itemDisplayFallbackLogic:IsSmallPackageResourceMissing(itemId) then
      self:ShowOtherDownloadUI(itemId)
    end
    ModelDisplayer.Restore("Segment")
    local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
    local avatar = ModelDisplayer.GetShowingAvatar()
    if avatar then
      avatar:PlayAction(itemId)
    end
  elseif itemCfg.ItemSubType == ENUM_ITEM_SUBTYPE.MVPIcon then
    ModelDisplayer.Hide("Segment")
    self:UpdateMVPIcon()
  elseif itemCfg.ItemType == ENUM_ITEM_TYPE.HeadIcon then
    self.UIRoot.WidgetSwitcher_4:SetActiveWidgetIndex(3)
    ModelDisplayer.Hide("Segment")
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_4, true)
    local itemDisplayFallbackLogic = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.item_display_fallback_logic)
    if itemDisplayFallbackLogic and itemDisplayFallbackLogic:IsSmallPackageResourceMissing(itemId) then
      log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:UpdatePreview HeadIcon small-package pak missing, trigger download, itemId:%s", tostring(itemId))
      local headshot_module = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.headshot_module)
      local dynamicIcon = headshot_module:GetDynamicIconByID(itemCfg.itemID)
      if dynamicIcon ~= "" then
        self:AddDownloadResPath(dynamicIcon)
      end
    end
    local logic_profile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
    local profile = logic_profile:GetLocalProfile(tonumber(DataMgr.roleData.uid))
    if not profile then
      if self.UIRoot.UTRichTextBlock_1 then
        self.UIRoot.UTRichTextBlock_1:SetText("")
      end
      log(bWriteLog and "[BaseItem:UpdatePlayerInfo] nil profile")
      return nil
    end
    if self.UIRoot.Common_Avatar_BP_C_1 then
      self.UIRoot.UTRichTextBlock_1:SetText(profile.nickName)
      self.UIRoot.Common_Avatar_BP_C_1.iconURL = nil
      self.UIRoot.Common_Avatar_BP_C_1:InitView(1, profile.uid, itemCfg.itemID, profile.sex, nil, profile.level, true, "", true)
      self.UIRoot.Common_Avatar_BP_C_1:SetButtonEnabled(false)
    end
    if self.UIRoot.Common_Avatar_BP_0 then
      self.UIRoot.UTRichTextBlock_1:SetText(profile.nickName)
      self.UIRoot.Common_Avatar_BP_0.iconURL = nil
      self.UIRoot.Common_Avatar_BP_0:InitView(1, profile.uid, itemCfg.itemID, profile.sex, nil, profile.level, false, "", true)
      self.UIRoot.Common_Avatar_BP_0:SetButtonEnabled(false)
    end
    self.UIRoot.Common_RankIntegralLevel_Style_Small_UIBP_C_1:SetRankInteral(FuncUtil.GetCurMaxSegementLevel(profile.segment_info))
    self.UIRoot.Common_Gender_UIBP_C_0:LoadIcon(profile.uid)
    local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
    if not PublishRegionMacros.IsBlueholeOperationRegion() then
      self:SetWidgetVisible(self.UIRoot.Image_6, true)
      local UIUtil = require("client.common.ui_util")
      UIUtil.UpdateNationImage(self.UIRoot.Image_6, profile.nation)
    else
      self:SetWidgetVisible(self.UIRoot.Image_6, false)
    end
  elseif itemCfg.ItemType == ENUM_ITEM_TYPE.Backpack and (itemCfg.ItemSubType == ENUM_ITEM_SUBTYPE.Backpack or itemCfg.ItemSubType == ENUM_ITEM_SUBTYPE.Helmet_NoLevel) then
    ModelDisplayer.Restore("Segment")
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_4, false)
    local itemDisplayFallbackLogic = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.item_display_fallback_logic)
    if itemDisplayFallbackLogic and itemDisplayFallbackLogic:IsSmallPackageResourceMissing(itemId) then
      self:ShowModelDownloadUI(itemId)
    end
  elseif itemCfg.ItemType == ENUM_ITEM_TYPE.CarteFrame then
    local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
    if PublishRegionMacros.IsBlueholeOperationRegion() then
      self:SetWidgetVisible(self.UIRoot.Image_9, false)
    end
    self.UIRoot.WidgetSwitcher_4:SetActiveWidgetIndex(4)
    ModelDisplayer.Hide("Segment")
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_4, true)
    self:SetInformationCard()
  elseif ModelDisplayTypeHelper.IsGift(itemCfg.ItemType, itemCfg.ItemSubType) then
    ModelDisplayer.Hide()
    self:ShowGiftLoop(itemId)
  else
    local imageUrl = GetCDNUrl(itemId)
    if imageUrl then
      self:SetWidgetVisible(self.UIRoot.Image_5, true)
      self:SetTexture(self.UIRoot.Image_5, itemCfg.ItemBigIcon)
      ModelDisplayer.Hide()
    else
      self:UpdateModel()
    end
  end
end

function ActiveExchange_Shop_Preview_UIBP:HandlePakDownloaded(pakName)
  self:UpdatePreview(self.itemId)
end

function ActiveExchange_Shop_Preview_UIBP:OnClose()
  self:ClearGiftAni()
  self:HidePeakGameUIEffect()
  self:SwitchUIVisible(true)
  ActiveExchange_Shop_Preview_UIBP.__super.OnClose(self)
end

function ActiveExchange_Shop_Preview_UIBP:UpdateAlias()
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_TitleOrFrame, true)
  self.UIRoot.WidgetSwitcher_TitleOrFrame:SetActiveWidgetIndex(0)
  local AliasCfg = CDataTable.GetTableData("AliasCfg", self.itemId)
  if not AliasCfg then
    return
  end
  self.UIRoot.Title_UIBP:SetAliasInfo(self.itemId, AliasCfg.AliasName or "", "", 0, 0)
end

function ActiveExchange_Shop_Preview_UIBP:UpdateFrame()
  local frameConfig = CDataTable.GetTableData("NameFrame", self.itemId)
  if not frameConfig then
    return
  end
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_TitleOrFrame, true)
  self.UIRoot.WidgetSwitcher_TitleOrFrame:SetActiveWidgetIndex(1)
  local UIUtil = require("client.common.ui_util")
  local DefaultIcon = UIUtil.GetDefaultIcon(self.itemId)
  self:SetTexture(self.UIRoot.Image_Frame, frameConfig.Icon, {sync = false, defaultIcon = DefaultIcon})
  if frameConfig.Season > 0 then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_FrameSeason, true)
    self.UIRoot.TextBlock_FrameSeason:SetText(string.format("S%d", frameConfig.Season))
  else
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_FrameSeason, false)
  end
  local SeasonSystem = require("client.logic.season.logic_season")
  local bestSegment = SeasonSystem.GetBestSegment()
  self.UIRoot.Common_RankIntegralLevel_Style_Small_UIBP:SetRankInteral(bestSegment, nil)
  UIUtil.UpdateNationImage(self.UIRoot.Image_Nation, DataMgr.roleData.nation)
  self.UIRoot.TextBlock_PlayerName:SetText(DataMgr.roleData.nickName)
end

function ActiveExchange_Shop_Preview_UIBP:PlayPeakGameGodEffect(cfg)
  if not cfg then
    log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:PlayPeakGameGodEffect. cfg is nil")
    return
  end
  log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:PlayPeakGameGodEffect.")
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local avatar = ModelDisplayer.GetShowingAvatar()
  if avatar then
    self:HidePeakGameUIEffect()
    
    local function showEffectFunc()
      local ItemID = self.itemId
      local cfg1 = CDataTable.GetTableDataByFilter("TeamupEntryParticleConfig", "ItemID", ItemID)
      avatar:PlayAction(cfg1.ItemID, {})
    end
    
    local EmoteBPTable = CDataTable.GetTableData("EmoteBPTable", cfg.ItemID)
    local path = EmoteBPTable and EmoteBPTable.Path
    local PufferConst = require("client.slua.logic.download.puffer_const")
    local common_download_handler = require("client.slua.common.common_download_handler")
    local extra = {
      showGray = true,
      hideMask = true,
      showSize = true,
      pos = FVector2D(0, -20),
      size = 60,
      callback = showEffectFunc,
      callback_no_need_down = showEffectFunc
    }
    common_download_handler.CreateDownloadUIReturnUIBase(PufferConst.ENUM_DownloadType.ODPAK, {path}, self, self.UIRoot.CanvasPanel_Download, extra)
  else
    log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:PlayPeakGameGodEffect. no ShowingAvatar")
  end
end

function ActiveExchange_Shop_Preview_UIBP:ClearCurrentEffect()
  self:HidePeakGameUIEffect()
  self:ClearOpeningEffect()
  self:StopSeasonGodEffect()
end

function ActiveExchange_Shop_Preview_UIBP:StopSeasonGodEffect()
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local avatar = ModelDisplayer.GetShowingAvatar()
  if avatar and avatar.StopGodEffect then
    avatar:StopGodEffect()
  end
end

function ActiveExchange_Shop_Preview_UIBP:HidePeakGameUIEffect()
  local common_download_handler = require("client.slua.common.common_download_handler")
  common_download_handler:CloseDownloadUI(self, self.UIRoot.CanvasPanel_Download)
  self.downloadOver = false
  if self.PeakGameUIEffect and self.PeakGameUIEffect:IsShow() then
    self.PeakGameUIEffect:CloseSelf()
  end
  self.PeakGameUIEffect = nil
end

function ActiveExchange_Shop_Preview_UIBP:ClearOpeningEffect()
  if self.openingUI then
    self.openingUI:Close()
    self.openingUI = nil
  end
end

function ActiveExchange_Shop_Preview_UIBP:SwitchUIVisible(bVisible)
  log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:SwitchUIVisible bVisible:" .. tostring(bVisible))
  if not slua.isValid(self.UIRoot) then
    log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:SwitchUIVisible UIRoot is invalid")
    return
  end
  self:SetWidgetVisible(self.UIRoot.Button_ShowUI, not bVisible, true)
  local parentUI = self:GetParentUI()
  if parentUI and parentUI.UIRoot then
    parentUI:SetWidgetVisible(parentUI.UIRoot.CanvasPanel_Attach, bVisible)
    parentUI:SetWidgetVisible(parentUI.UIRoot.CanvasPanel_Right, bVisible)
  end
end

function ActiveExchange_Shop_Preview_UIBP:PlayGodEffect()
  local effectConfig = CDataTable.GetTableData("SeasonGodEffect", self.itemId)
  if not effectConfig then
    log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:PlayGodEffect no effectConfig, itemId:" .. tostring(self.itemId))
    return
  end
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local avatar = ModelDisplayer.GetShowingAvatar()
  if avatar then
    avatar:PlayAction(2202401)
    avatar:PlayGodEffect(effectConfig.EffectID)
  else
    log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:PlayGodEffect no ShowingAvatar")
  end
end

function ActiveExchange_Shop_Preview_UIBP:UpdateModel()
  local itemId = self.itemId
  local itemCfg = CDataTable.GetTableData("Item", itemId)
  if not itemCfg then
    return
  end
  if not self.downloadOver then
    local pak_util = require("client.common.pak_util")
    if pak_util and pak_util.IsRelatedPakExistByItemID and not pak_util.IsRelatedPakExistByItemID(itemId) then
      self.downloadOver = false
      self:ShowModelDownloadUI(itemId)
    end
  end
  local type = itemCfg.ItemType
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local ModelDisplayTypeHelper = require("client.logic.avatar.ModelDisplayTypeHelper")
  ModelDisplayer.SetNeedAutoRotate(false)
  if ModelDisplayTypeHelper.IsWeapon(type) then
    local extraData = {}
    if self.downloadOver and UIManager.IsUIShow(UIManager.UI_Config.ActiveExchange_Shop_UIBP) then
      extraData.forceDisplay = true
      ModelDisplayer.SetNeedAutoRotate(true)
    end
    ModelDisplayer.Display(itemId, true, extraData)
    ModelDisplayer.SwitchToModel()
    self.downloadOver = false
  else
    if not ModelDisplayTypeHelper.IsRealClothes(itemCfg.ItemType, itemCfg.ItemSubType) then
      ModelDisplayer.Restore("Segment")
    end
    ModelDisplayer.Display(itemId, true)
  end
end

function ActiveExchange_Shop_Preview_UIBP:ShowModelDownloadUI(itemId)
  log_format(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:ShowModelDownloadUI itemId=%s", tostring(itemId))
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  ModelDisplayer.Hide("Segment")
  
  local function downloadFinishFunc()
    if self.itemId ~= itemId then
      log_format(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:ShowModelDownloadUI callback itemId mismatch, cur=%s trigger=%s", tostring(self.itemId), tostring(itemId))
      return
    end
    self.downloadOver = true
    self:UpdateModel()
  end
  
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local common_download_handler = require("client.slua.common.common_download_handler")
  local extra = {
    showGray = true,
    hideMask = true,
    showSize = true,
    pos = FVector2D(0, -20),
    size = 60,
    callback = downloadFinishFunc,
    callback_no_need_down = downloadFinishFunc
  }
  common_download_handler.CreateDownloadUIReturnUIBase(PufferConst.ENUM_DownloadType.ODPAK, {itemId}, self, self.UIRoot.CanvasPanel_Download, extra)
end

function ActiveExchange_Shop_Preview_UIBP:ShowGiftDownloadUI(itemId, giftAni)
  if not self.UIRoot or not self.UIRoot.CanvasPanel_Download then
    log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:ShowGiftDownloadUI CanvasPanel_Download is nil")
    return
  end
  
  local function downloadFinishFunc()
    if not self.UIRoot or self.itemId ~= itemId then
      log(bWriteLog and string.format("ActiveExchange_Shop_Preview_UIBP:ShowGiftDownloadUI callback skip cur=%s trigger=%s", tostring(self.itemId), tostring(itemId)))
      return
    end
    self:UpdatePreview(self.itemId)
  end
  
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local common_download_handler = require("client.slua.common.common_download_handler")
  local extra = {
    showGray = true,
    hideMask = true,
    showSize = true,
    pos = FVector2D(0, -20),
    size = 60,
    callback = downloadFinishFunc
  }
  common_download_handler.CreateDownloadUIReturnUIBase(PufferConst.ENUM_DownloadType.ODPAK, {giftAni}, self, self.UIRoot.CanvasPanel_Download, extra)
  log(bWriteLog and string.format("ActiveExchange_Shop_Preview_UIBP:ShowGiftDownloadUI itemId=%s", tostring(itemId)))
end

function ActiveExchange_Shop_Preview_UIBP:ShowOtherDownloadUI(itemId)
  log_format(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:ShowOtherDownloadUI itemId=%s", tostring(itemId))
  
  local function downloadFinishFunc()
    if self.itemId ~= itemId then
      log_format(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:ShowOtherDownloadUI callback itemId mismatch, cur=%s trigger=%s", tostring(self.itemId), tostring(itemId))
      return
    end
    log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:ShowOtherDownloadUI download finished, refresh preview, itemId:", tostring(itemId))
    self:UpdatePreview(self.itemId)
  end
  
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local common_download_handler = require("client.slua.common.common_download_handler")
  local extra = {
    showGray = true,
    hideMask = true,
    showSize = true,
    pos = FVector2D(0, -20),
    size = 60,
    callback = downloadFinishFunc,
    callback_no_need_down = downloadFinishFunc
  }
  common_download_handler.CreateDownloadUIReturnUIBase(PufferConst.ENUM_DownloadType.ODPAK, {itemId}, self, self.UIRoot.CanvasPanel_Download, extra)
end

function ActiveExchange_Shop_Preview_UIBP:OnClickButton_HideUI()
  self:PlayAudio(sound_config.click_v1)
  self:SwitchUIVisible(false)
end

function ActiveExchange_Shop_Preview_UIBP:OnClickButton_ShowUI()
  self:PlayAudio(sound_config.click_v1)
  self:SwitchUIVisible(true)
end

function ActiveExchange_Shop_Preview_UIBP:OnClickButton_Play()
  self:PlayAudio(sound_config.click_v1)
  
  local function start_callback()
    self:SwitchUIVisible(false)
    self:SetWidgetVisible(self.UIRoot.Button_Play, false, true)
    self:SetWidgetVisible(self.UIRoot.Button_ShowUI, false, true)
  end
  
  local function end_callback()
    self:SwitchUIVisible(true)
    self:SetWidgetVisible(self.UIRoot.Button_Play, true, true)
  end
  
  local logic_mvp_motion = require("client.slua.logic.mvp_motion.logic_mvp_motion")
  logic_mvp_motion.Play_MVP_Motion(self.itemId, start_callback, end_callback)
end

function ActiveExchange_Shop_Preview_UIBP:OnScreenRatioChanged(_, _)
  local logic_mvp_motion = require("client.slua.logic.mvp_motion.logic_mvp_motion")
  logic_mvp_motion.Stop_Mvp_Motion(self.itemId)
end

function ActiveExchange_Shop_Preview_UIBP:UpdateMVPIcon()
  log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:UpdateMVPIcon")
  self:CloseMVPIcon()
  local ImprintConfig = CDataTable.GetTableData("MVPImprintTable", self.itemId)
  if not ImprintConfig then
    return
  end
  local PreviewPath = ImprintConfig.PreviewPath
  log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:UpdateMVPIcon PreviewPath:" .. tostring(PreviewPath))
  if PreviewPath == nil or PreviewPath == "" then
    return
  end
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Left, true, false)
  self.preview = self:CreateChildWindowWithBpPath(self.UIRoot.CanvasPanel_Left, nil, PreviewPath)
  if not self.preview or not slua.isValid(self.preview.UIRoot) then
    log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:UpdateMVPIcon preview is invalid")
    return
  end
  self.preview:PlayAnimation("Anim_in", 0, 1, 0, 1)
end

function ActiveExchange_Shop_Preview_UIBP:CloseMVPIcon()
  log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:CloseMVPIcon self.preview = " .. tostring(self.preview))
  if self.preview then
    self.preview:Close()
    self.preview = nil
  end
end

function ActiveExchange_Shop_Preview_UIBP:UpdateInformationCard(titleTab)
  log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:UpdateInformationCard titleTab = " .. tostring(titleTab))
  self.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(titleTab)
end

function ActiveExchange_Shop_Preview_UIBP:SetInformationCard()
  log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:SetInformationCard self.itemId = " .. tostring(self.itemId))
  local displayItemId = self.itemId
  local itemDisplayFallbackLogic = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.item_display_fallback_logic)
  if itemDisplayFallbackLogic:IsSmallPackageResourceMissing(displayItemId) then
    local logic_roleinfo_carte_frame = require("client.slua.logic.roleInfo.logic_roleinfo_carte_frame")
    displayItemId = logic_roleinfo_carte_frame:GetDefaultSkinID()
  end
  local RawCarteFrameConfig = CDataTable.GetTableData("CarteFrameConfig", displayItemId)
  if not RawCarteFrameConfig then
    log(bWriteLog and "[logic_roleinfo_carte_frame] nil RawCarteFrameConfig")
    return
  end
  local itemData = {
    config = RawCarteFrameConfig,
    bLock = true,
    bRed = false,
    expire_ts = 0
  }
  self:UpdatePlayerInfo()
  self:UpdateInfoPageCarteFrame(itemData)
  self:UpdateMainPageCarteFrame(itemData.config.SkinID, itemData)
end

function ActiveExchange_Shop_Preview_UIBP:UpdatePlayerInfo()
  local LobbySocialSystem = require("client.slua.logic.lobby.Left.logic_lobby_social")
  local profile = LobbySocialSystem.GetProfileByUID(DataMgr.roleData.uid)
  if not profile then
    return
  end
  log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:UpdatePlayerInfo")
  self.UIRoot.Common_Avatar_BP_C_145:InitView(1, profile.uid, profile.picUrl, profile.sex, profile.cur_avatar_box_id, profile.level, false, "")
  self.UIRoot.Common_Avatar_BP_C_145:SetButtonEnabled(false)
  self.UIRoot.Common_Avatar_BP_C_2:InitView(1, profile.uid, profile.picUrl, profile.sex, profile.cur_avatar_box_id, profile.level, false, "")
  self.UIRoot.Common_Avatar_BP_C_2:SetButtonEnabled(false)
  self.UIRoot.Common_RankIntegralLevel_Style_Small_UIBP_C_2:SetRankInteral(FuncUtil.GetCurMaxSegementLevel(profile.segment_info))
  self:HandleNationFlag(self.nationImageComp, profile.nation)
  self.UIRoot.UTRichTextBlock_2:SetText(profile.nickName or "")
  self.UIRoot.TextBlock_1:SetText(profile.nickName or "")
  self.UIRoot.Common_Gender_UIBP_C_1:LoadIcon(profile.uid)
  self.UIRoot.TextBlock_PlayerID:SetText(profile.uid or "")
  if profile.social_card and self.UIRoot.Common_Gender_UIBP then
    self.UIRoot.Common_Gender_UIBP:LoadIcon(profile.uid)
  end
  local UIUtil = require("client.common.ui_util")
  local UnknowPassUtil = require("client.slua.logic.unknow_pass.logic_unknowpass_util")
  local upass_is_buy, upass_is_show, upass_keep_buy, upass_cur_value, pass_type = UnknowPassUtil.ParseUpassInfo(profile.upass)
  self.UIRoot.UnknowPass_ContinuousBuy_BP:SetTypeData(0, upass_keep_buy, upass_is_buy == 1, 1, upass_cur_value, pass_type or 0)
  self.UIRoot.PassBig:SetWidgetVisibility(UIUtil.BoolToVisible(upass_is_show ~= 0))
  self.UIRoot.TextBlock_upass_level:SetText(profile.upass.level or 1)
  self.UIRoot.Text_Upvote:SetText(profile.upvote or 0)
  local logic_team_evaluation_view = require("client.slua.logic.team_evaluation.logic_team_evaluation_view")
  logic_team_evaluation_view.RefreshEvaluationEntrance(profile.uid, self.UIRoot)
  if showUid == DataMgr.roleData.uid then
    self.UIRoot.TextBlock_12:SetText(LocUtil.LocalizeResFormat(601, profile.level or 1))
  else
    self.UIRoot.TextBlock_12:SetText(LocUtil.LocalizeResFormat(42632, profile.level or 1))
  end
  local corps_summary = LobbySocialSystem.CacheCorpsSummary[profile.corps_id] or nil
  if 0 < profile.corps_id and not corps_summary then
    local ChatMenuSystem = require("client.slua.logic.lobby_chat.logic_chat_menu")
    ChatMenuSystem.get_corps_summary_req(profile.corps_id, tonumber(profile.uid))
  end
  self:SetCorpsInfo(nil, nil, corps_summary)
  if self.UIRoot.Pround_Level_Icon_UIBP then
    self.UIRoot.Pround_Level_Icon_UIBP:SetData(profile.uid)
  end
  local RoleInfoPopularitySystem = require("client.slua.logic.person_space.logic_roleinfo_popularity")
  local popularityLevel = RoleInfoPopularitySystem.GetPopularityLevelByExp(profile.total_devote)
  if self.UIRoot.Popularity_Level_Icon_UIBP then
    self.UIRoot.Popularity_Level_Icon_UIBP:SetData(popularityLevel)
  end
end

function ActiveExchange_Shop_Preview_UIBP:SetCorpsInfo(_, __, corps_summary)
  log(bWriteLog and "[ActiveExchange_Shop_Preview_UIBP:SetCorpsInfo] SetCorpsInfo")
  if not self.UIRoot then
    return
  end
  if not corps_summary or not corps_summary.name then
    log(bWriteLog and "[ActiveExchange_Shop_Preview_UIBP:SetCorpsInfo] nil corps_summary")
    self:UpdateCorpsInfo(false, LocUtil.GetLocalizeResStr(5085))
    return
  end
  self:UpdateCorpsInfo(true, corps_summary.name)
end

function ActiveExchange_Shop_Preview_UIBP:UpdateCorpsInfo(visible, corpsName)
  self:SetWidgetVisible(self.UIRoot.Image_icon_juntuan, visible)
  self:SetWidgetVisible(self.UIRoot.Image_icon_juntuan02, visible)
  corpsName = corpsName or ""
  self.UIRoot.txt_juntuan:SetText(corpsName)
  self.UIRoot.txt_juntuan02:SetText(corpsName)
end

function ActiveExchange_Shop_Preview_UIBP:HandleNationFlag(comp, nation)
  if comp then
    local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
    if not PublishRegionMacros.IsBlueholeOperationRegion() then
      self:SetWidgetVisible(comp, true)
      local UIUtil = require("client.common.ui_util")
      UIUtil.UpdateNationImage(comp, nation)
    else
      self:SetWidgetVisible(comp, false)
    end
  end
end

function ActiveExchange_Shop_Preview_UIBP:UpdateInfoPageCarteFrame(item_data)
  log(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:UpdateInfoPageCarteFrame")
  if not item_data then
    return
  end
  local effect_bp_path = item_data.config.EffectBP
  local bLoopAnim = item_data.config.bLoopAnim
  local extraData = {}
  local anim = bLoopAnim and "Auto_Loop"
  if item_data.config.Level == 1 then
  end
  if item_data.config.Level == 3 then
    extraData.bEnableGyroscope = true
  end
  local child = self:AddEffectSkinByCreateChildWindow(effect_bp_path, "GridPanel_1", anim, extraData)
  if child then
    self.UIRoot.WidgetSwitcher_5:SetActiveWidgetIndex(1)
  else
    self.UIRoot.WidgetSwitcher_5:SetActiveWidgetIndex(0)
  end
  local skin_path = item_data.config.SkinPath
  local pak_util = require("client.common.pak_util")
  if skin_path and skin_path ~= "" and pak_util.IsPufferDownloaded(skin_path) then
    self:SetTexture(self.UIRoot.Image_bg02, skin_path)
  else
    self:AddDownloadResPath(skin_path)
  end
end

function ActiveExchange_Shop_Preview_UIBP:UpdateMainPageCarteFrame(frameIndex, item_data)
  if frameIndex then
    local logic_roleinfo_carte_frame = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame)
    local skin_info = logic_roleinfo_carte_frame:GetSkinPath(frameIndex)
    if skin_info.BPType == 1 and skin_info.EffectBP and skin_info.EffectBP ~= "" then
      local fullExtraData = {}
      if item_data and item_data.config.Level == 3 then
        fullExtraData.bEnableGyroscope = true
      end
      local fullChild = self:AddEffectSkinByCreateChildWindow(skin_info.EffectBP, "GridPanel_GoldenBg", skin_info.bLoopAnim and "Auto_Loop" or nil, fullExtraData)
      if fullChild then
        self:SetWidgetVisible(self.UIRoot.GridPanel_GoldenBg, true)
      else
        self:SetWidgetVisible(self.UIRoot.GridPanel_GoldenBg, false)
      end
      self.UIRoot.WidgetSwitcher_BG:SetActiveWidgetIndex(0)
      self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_BG, false)
      return
    end
    self:ClearFullFrameEffectSkin()
    self:SetWidgetVisible(self.UIRoot.GridPanel_GoldenBg, false)
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_BG, true)
    local extraData = {}
    local anim = skin_info.bLoopAnim and "Auto_Loop"
    if item_data.config.Level == 1 then
    end
    if item_data and item_data.config.Level == 3 then
      extraData.bEnableGyroscope = true
    end
    local child = self:AddEffectSkinByCreateChildWindow(skin_info.RoleInfoEffectBP, "BG_Effect", anim, extraData)
    if child then
      self.UIRoot.WidgetSwitcher_BG:SetActiveWidgetIndex(1)
    else
      self.UIRoot.WidgetSwitcher_BG:SetActiveWidgetIndex(0)
    end
  else
    self:ClearFullFrameEffectSkin()
    self:SetWidgetVisible(self.UIRoot.GridPanel_GoldenBg, false)
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_BG, true)
    self.UIRoot.WidgetSwitcher_BG:SetActiveWidgetIndex(0)
  end
end

function ActiveExchange_Shop_Preview_UIBP:ClearFullFrameEffectSkin()
  if self.effectRoots and self.effectRoots.GridPanel_GoldenBg then
    self.effectRoots.GridPanel_GoldenBg:Close()
    self.effectRoots.GridPanel_GoldenBg = nil
  end
end

function ActiveExchange_Shop_Preview_UIBP:AddEffectSkinByCreateChildWindow(bgPath, parentPanel, aniName, extraData)
  local logic_roleinfo_personalization_util = require("client.logic.roleinfo.logic_roleinfo_personalization_util")
  local child = logic_roleinfo_personalization_util.AddEffectSkinByCreateChildWindow(self, bgPath, parentPanel, aniName, extraData)
  if child == nil then
    self:AddDownloadResPath(bgPath)
  end
  return child
end

function ActiveExchange_Shop_Preview_UIBP:AddDownloadResPath(path)
  log_format(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:AddDownloadResPath. path=%s", path)
  if path == nil or path == "" then
    return
  end
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  local pakName = PufferManager.GetPakName(path)
  self.downloadPakNames = self.downloadPakNames or {}
  if pakName ~= "" then
    self.downloadPakNames[pakName] = true
  end
end

function ActiveExchange_Shop_Preview_UIBP:OnDownloadFinish(_, _, eventData)
  if eventData == nil then
    return
  end
  local pakName = eventData.pakName
  if pakName == nil then
    return
  end
  self.downloadPakNames = self.downloadPakNames or {}
  if not self.downloadPakNames[pakName] then
    return
  end
  log_format(bWriteLog and "ActiveExchange_Shop_Preview_UIBP:OnDownloadFinish. after pakName=%s", pakName)
  self:HandlePakDownloaded(pakName)
end

local class = require("class")
local ui_base = require("client.slua.umg.roleInfoNew.Personalization_Base_Preview_UIBP")
local CActiveExchange_Shop_Preview_UIBP = class(ui_base, nil, ActiveExchange_Shop_Preview_UIBP)
return CActiveExchange_Shop_Preview_UIBP
