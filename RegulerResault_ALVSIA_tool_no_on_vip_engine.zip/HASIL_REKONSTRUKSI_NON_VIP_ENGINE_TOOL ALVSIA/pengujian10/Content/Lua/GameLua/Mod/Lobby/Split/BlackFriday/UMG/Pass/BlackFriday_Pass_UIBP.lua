local BlackFriday_Pass_UIBP = {}
local BlackFridayMacros = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.BlackFridayMacros")
local ActType = BlackFridayMacros.ActivityType
local ItemMacros = require("client.slua.config.ClientMacros.ItemMacros")
local Traits = {
  require("GameLua.Mod.Lobby.Split.BlackFriday.UMG.Trait.EventRules"),
  require("GameLua.Mod.Lobby.Split.BlackFriday.UMG.Trait.ActivityTime"),
  require("GameLua.Mod.Lobby.Split.BlackFriday.UMG.Trait.ActivityTitle")
}
local Trait = require("common.trait")
local ui_base = require("client.slua_ui_framework.base")
local CBlackFriday_Pass_UIBP = Trait.TraitClass(ui_base, nil, BlackFriday_Pass_UIBP, Traits)
local Enum_Task = {
  Daily = 0,
  Limit = 1,
  Cost = 2
}

function BlackFriday_Pass_UIBP:ctor(_)
  self.ActType = ActType.Pass
  self.Info = nil
  self.curBigAwardID = 0
  self.ShowCount = 5
  self.ScrollIndexStart = 1
  self.ScrollIndexEnd = 6
  self.PreviewLevel = 0
  self.curSelectTaskIndex = 0
  self.costTabList = nil
  self.limitTabList = nil
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  self.AnimData = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eBlackFridayPassAnim) or {}
end

function BlackFriday_Pass_UIBP:OnInitialize()
  self.LoopScrollBox_Exclusive = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_Exclusive, "GameLua.Mod.Lobby.Split.BlackFriday.UMG.Pass.Item.BlackFriday_Pass_GoldSpin_Item_UIBP")
  self.TaskScroll = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_PointQuest, "GameLua.Mod.Lobby.Split.BlackFriday.UMG.Pass.Item.BlackFriday_Pass_PointQuest_Item_UIBP")
  self.ProgressScroll = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_1, "GameLua.Mod.Lobby.Split.BlackFriday.UMG.Pass.Item.BlackFriday_Pass_Reward_Item_UIBP")
end

function BlackFriday_Pass_UIBP:RegistEvents()
  self:AddOnClickedEventByControl(self.UIRoot.Button_ExtraAward, self.OnClickedExtraAward, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_0, self.OnClickedAwardPreview, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_ExtraAwardTip, self.OpenExtraTips, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Tips, self.CloseExtraTips, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_PointsQuest, self.OnSelectTaskList, self, Enum_Task.Daily)
  self:AddOnClickedEventByControl(self.UIRoot.Button_SpecialOffer, self.OnSelectTaskList, self, Enum_Task.Cost)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Exclusive, self.OnSelectTaskList, self, Enum_Task.Limit)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Unlock, self.OnClickJumpCard, self)
  self:AddOnAnimationFinishedEvent("Anim_Update", self.SetAdvanceAwardUpdate, self)
  self:AddOnAnimationStartedEvent("Anim_Fadein", self.TryPlaySlide, self)
  self:AddCommonEvent(EVENTTYPE_ACTIVITY_BLACK_FRIDAY, EVENTID_ACTIVITY_BLACK_FRIDAY_PASS_INFO_UPDATED, self.OnPassInfoUpdated, self)
  self:AddCommonEvent(EVENTTYPE_ACTIVITY_BLACK_FRIDAY, EVENTID_ACTIVITY_BLACK_FRIDAY_PASS_AWARD_UPDATED, self.OnAwardUpdated, self)
  self:AddCommonEvent(EVENTTYPE_ACTIVITY_BLACK_FRIDAY, EVENTID_ACTIVITY_BLACK_FRIDAY_PASS_EXTRA_AWARD_UPDATED, self.OnExtraAwardUpdated, self)
  self:AddCommonEvent(EVENTTYPE_DATA_MGR, EVNETID_DATAMGR_ACTIVITY_CHANGE, self.OnActivityDataChanged, self)
  self:AddCommonEvent(EVENTTYPE_DATA_MGR, EVNETID_DATAMGR_ALL_ACTIVITY_CHANGE, self.OnAllActDataChanged, self)
  self:AddCommonEvent(EVENTTYPE_ACTIVITY_BLACK_FRIDAY, EVENTID_ACTIVITY_BLACK_FRIDAY_PASS_UI_VISIBILITY_UPDATED, self.OnPassUIVisibilityUpdated, self)
  self:AddCommonEvent(EVENTTYPE_ACTIVITY_BLACK_FRIDAY, EVENTID_ACTIVITY_BLACK_FRIDAY_PASS_UI_REDUPDATE, self.OnUIRedUpdate, self)
end

function BlackFriday_Pass_UIBP:OnPostInitialize()
  self.UIRoot.TextBlock_Title:SetText(LocUtil.GetLocalizeResStr(187201))
  self.UIRoot.TextBlock_Free:SetText(LocUtil.GetLocalizeResStr(187208))
  self.UIRoot.TextBlock_Premium:SetText(LocUtil.GetLocalizeResStr(187209))
  self.UIRoot.UTRichTextBlock__UnlockDesc:SetText(LocUtil.GetLocalizeResStr(187210))
  self.UIRoot.TextBlock_5:SetText(LocUtil.GetLocalizeResStr(187212))
  self.UIRoot.UTRichTextBlock_Tips:SetText(LocUtil.GetLocalizeResStr(187247))
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Tips, false)
  self:OnPassUIVisibilityUpdated(nil, nil, true)
  self:RefreshConst()
  self:GetOrReqData()
  self:SetAdvanceAwardUpdate()
  local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
  local gem_report_utils = require("client.logic.store.gem_report_utils")
  BlackFridayPassModule:ReportTLog(gem_report_utils.SubEvent_CyberPass001)
end

function BlackFriday_Pass_UIBP:OnAndroidBack()
  return false
end

function BlackFriday_Pass_UIBP:OnClickedExtraAward()
  self:PlayAudio(sound_config.click_v1)
  local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
  local Count = BlackFridayPassModule:GetExtraAwardCount()
  if Count == 0 then
    local boxId = BlackFridayPassModule:GetExtraAwardItemID()
    local BlackFridayPopupUtil = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.BlackFridayPopupUtil")
    BlackFridayPopupUtil.Push({
      Func = LobbySystem.PlayItemPreviewAnimation,
      Params = {boxId, false}
    }, true)
  else
    local BlackFridayHandler = require("client.network.Protocol.BlackFridayHandler")
    BlackFridayHandler.send_black_friday_get_pass_extra_chest_req()
  end
end

function BlackFriday_Pass_UIBP:OnClickedJKPro()
  self:PlayAudio(sound_config.click)
  local BlackFridayPopupUtil = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.BlackFridayPopupUtil")
  BlackFridayPopupUtil.Push({
    UIConfig = UIManager.UI_Config.BlackFriday_Pass_Probability_UIBP
  }, true)
end

function BlackFriday_Pass_UIBP:OnClickedExtraAwardHelp()
  self:PlayAudio(sound_config.click_v1)
  self:SetWidgetVisible(self.UIRoot.Button_TipsClose, true, true)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_PointTips, true)
end

function BlackFriday_Pass_UIBP:OnClickedCloseExtraAwardTips()
  self:PlayAudio(sound_config.click_v1)
  self:SetWidgetVisible(self.UIRoot.Button_TipsClose, false, true)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_PointTips, false)
end

function BlackFriday_Pass_UIBP:OnClickedAwardPreview()
  self:PlayAudio(sound_config.click_v1)
  local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
  BlackFridayPassModule:PreviewBigAward(self.curBigAwardID, self.PreviewLevel)
  local gem_report_utils = require("client.logic.store.gem_report_utils")
  BlackFridayPassModule:ReportTLog(gem_report_utils.SubEvent_CyberPass007, {
    level = self.PreviewLevel
  })
end

function BlackFriday_Pass_UIBP:OnClickJumpCard()
  local LuckyCardModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule)
  local haveCard = LuckyCardModule:HasLuckyCard()
  if haveCard then
    return
  end
  self:PlayAudio(sound_config.click_v1)
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_TWO, LocUtil.GetLocalizeResStr(187245), LocUtil.GetLocalizeResStr(187251), function()
    GlobalData.JumpUrl("game://?module=1006014&type=" .. BlackFridayMacros.ActivityType.LuckyCard)
    local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
    local gem_report_utils = require("client.logic.store.gem_report_utils")
    BlackFridayPassModule:ReportTLog(gem_report_utils.SubEvent_CyberPass015)
  end, nil, LocUtil.GetLocalizeResStr(27840), LocUtil.GetLocalizeResStr(19945))
  local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
  local gem_report_utils = require("client.logic.store.gem_report_utils")
  BlackFridayPassModule:ReportTLog(gem_report_utils.SubEvent_CyberPass014)
end

function BlackFriday_Pass_UIBP:OpenExtraTips()
  self:PlayAudio(sound_config.click_v1)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Tips, true)
end

function BlackFriday_Pass_UIBP:CloseExtraTips()
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Tips, false)
end

function BlackFriday_Pass_UIBP:InitBannerTaskList()
  if not self.Info then
    return
  end
  local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
  if not self.limitTabList then
    self.limitTabList = BlackFridayPassModule:GetLimitTabList()
  end
  if not self.costTabList then
    self.costTabList = BlackFridayPassModule:GetCostTabList()
  end
end

function BlackFriday_Pass_UIBP:OnPassInfoUpdated()
  self:AddTimerOnce(0, function()
    local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
    self.Info = BlackFridayPassModule:GetPassInfo()
    if not self.Info then
      return
    end
    self:RefreshTaskList()
    self:InitBannerTaskList()
    self:RefreshTaskSwitch()
    self:RefreshBottom()
    self:RefreshAllTabRedDot()
    local itemSize = self.UIRoot.LoopScrollBox_1.ItemSize
    local ViewSize = self.ProgressScroll:GetViewSize()
    local canShowCount = math.max(0, ViewSize.X // itemSize)
    log(bWriteLog and "[SY]BlackFriday_Pass_UIBP:FindDoneReward.canShowCount:" .. tostring(canShowCount))
    self.ShowCount = canShowCount
    self:FindDoneReward(true)
  end)
  local LuckyCardModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule)
  local haveCard = LuckyCardModule:HasLuckyCard()
  if not self.AnimData.isPlayEntry and haveCard then
    self:PlayUserWidgetAnimation(self.UIRoot.Anim_Update, 0, 1, 0, 1)
    local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
    self.AnimData.isPlayEntry = true
    PlayerPrefsSystem.SaveTableToFile_N(self.AnimData, PlayerPrefsSystem.ePlayerPrefsType.eBlackFridayPassAnim)
  end
end

function BlackFriday_Pass_UIBP:SetAdvanceAwardUpdate()
  local LuckyCardModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule)
  local haveCard = LuckyCardModule:HasLuckyCard()
  if not self.AnimData.isPlayEntry and haveCard then
    self.UIRoot.WidgetSwitcherExt_Lock:SetActiveWidgetIndex(0)
    return
  end
  self.UIRoot.WidgetSwitcherExt_Lock:SetActiveWidgetIndex(haveCard and 1 or 0)
end

function BlackFriday_Pass_UIBP:TryPlaySlide()
  if not self.AnimData.isPlaySlide then
    self:AddTimer(0.5, function()
      self:PlayUserWidgetAnimation(self.UIRoot.Anim_Slide, 0, 1, 0, 1)
      self.AnimData.isPlaySlide = true
      local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
      PlayerPrefsSystem.SaveTableToFile_N(self.AnimData, PlayerPrefsSystem.ePlayerPrefsType.eBlackFridayPassAnim)
    end)
  end
end

function BlackFriday_Pass_UIBP:OnAwardUpdated(_, __, AwardInfo)
  self:FindDoneReward()
end

function BlackFriday_Pass_UIBP:OnExtraAwardUpdated()
  self:RefreshExtraAward()
end

function BlackFriday_Pass_UIBP:OnActivityDataChanged(_, __, changeList)
  local needRefreshBottom = false
  local needRefreshTaskList = false
  local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
  local typeList = changeList.typeList
  if typeList and typeList[ActivityType.BlackFriday_Pass] then
    needRefreshBottom = true
  end
  local idList = changeList.idList
  if idList then
    for id, _ in pairs(idList) do
      if BlackFridayPassModule:IsPassActId(id) then
        needRefreshTaskList = true
        needRefreshBottom = true
        break
      end
    end
  end
  if needRefreshTaskList then
    self:RefreshDailyTaskList()
    self:RefreshDailyTaskRed()
  end
  if needRefreshBottom then
    self:RefreshBannerTask()
    self:RefreshBannerTabRedDot()
    self:RefreshBottom()
  end
end

function BlackFriday_Pass_UIBP:RefreshAllTabRedDot()
  self:RefreshDailyTaskRed()
  self:RefreshBannerTabRedDot()
end

function BlackFriday_Pass_UIBP:RefreshDailyTaskRed()
  log(bWriteLog and "[SY]BlackFriday_Pass_UIBP:RefreshDailyTaskRed.")
  local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
  local actData = BlackFridayPassModule:GetDailyActData()
  local isShowReward = false
  if actData then
    for i, task in pairs(actData.List) do
      if task.Status == ActivityProgressStatus.Done then
        isShowReward = true
        break
      end
    end
    self.UIRoot.Reddot_Anchor_1:ShowRedPointByPath(BlackFridayPassModule.RedEnumPath.Reward)
  end
  self:SetWidgetVisible(self.UIRoot.Reddot_Anchor_1, isShowReward)
end

function BlackFriday_Pass_UIBP:RefreshBannerTabRedDot()
  log(bWriteLog and "[SY]BlackFriday_Pass_UIBP:RefreshBannerTabRedDot.")
  local isNew = false
  local isShowReward = false
  local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
  local limitTaskData = BlackFridayPassModule:GetLimitTaskData()
  if limitTaskData and limitTaskData.task_list then
    for i, v in pairs(limitTaskData.task_list) do
      if v.status == ActivityProgressStatus.Done and BlackFridayPassModule:GetLimitTabInfoByModuleID(v.module_id) ~= nil then
        isShowReward = true
        break
      end
    end
  end
  local limitTabList = self.limitTabList
  if limitTabList then
    for i, v in ipairs(limitTabList) do
      if BlackFridayPassModule:GetModuleTabNewRedData(v.module_id) then
        isNew = true
      end
    end
  end
  if isShowReward then
    self.UIRoot.Reddot_Anchor_2:ShowRedPointByPath(BlackFridayPassModule.RedEnumPath.Reward)
  elseif isNew then
    self.UIRoot.Reddot_Anchor_2:ShowRedPointByPath(BlackFridayPassModule.RedEnumPath.New)
  end
  self:SetWidgetVisible(self.UIRoot.Reddot_Anchor_2, isShowReward or isNew)
  isShowReward = false
  isNew = false
  local costData = BlackFridayPassModule:GetCostTaskData()
  if costData and costData.task_list then
    for i, v in pairs(costData.task_list) do
      if v.status == ActivityProgressStatus.Done and BlackFridayPassModule:GetCostTabInfoByModuleID(v.module_id) ~= nil then
        isShowReward = true
        break
      end
    end
  end
  local costTabList = self.costTabList
  if costTabList then
    for i, v in ipairs(costTabList) do
      if BlackFridayPassModule:GetModuleTabNewRedData(v.module_id) then
        isNew = true
      end
    end
  end
  if isShowReward then
    self.UIRoot.Reddot_Anchor_3:ShowRedPointByPath(BlackFridayPassModule.RedEnumPath.Reward)
  elseif isNew then
    self.UIRoot.Reddot_Anchor_3:ShowRedPointByPath(BlackFridayPassModule.RedEnumPath.New)
  end
  self:SetWidgetVisible(self.UIRoot.Reddot_Anchor_3, isShowReward or isNew)
end

function BlackFriday_Pass_UIBP:OnAllActDataChanged()
  log(bWriteLog and "[SY]BlackFriday_Pass_UIBP:OnAllActDataChanged.")
  self:RefreshAllTabRedDot()
  self:RefreshDailyTaskList()
  self:RefreshBannerTask()
end

function BlackFriday_Pass_UIBP:OnPassUIVisibilityUpdated(_, __, show)
  if show then
    self:PlayUserWidgetAnimation(self.UIRoot.Anim_Fadein, 0, 1, 0, 1)
  else
    self:PlayUserWidgetAnimation(self.UIRoot.Anim_Fadeout, 0, 1, 0, 1)
  end
end

function BlackFriday_Pass_UIBP:OnUIRedUpdate()
  log(bWriteLog and "[SY]BlackFriday_Pass_UIBP:OnUIRedUpdate.")
  self:RefreshAllTabRedDot()
end

function BlackFriday_Pass_UIBP:RefreshConst()
  self.UIRoot.TextBlock_ExtraAwardTip:SetText(LocUtil.GetLocalizeResStr(187213))
  self.UIRoot.UTRichTextBlock_Desc:SetText(LocUtil.GetLocalizeResStr(187205))
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  local bJK = PublishRegionMacros.IsJapanOrKorea()
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_JK_Prob, bJK)
  if bJK then
  end
  self.UIRoot.TextBlock_ExtraAwardNum:SetText(LocUtil.LocalizeResFormat(187214, 0))
  self.UIRoot.UTRichTextBlock_ExtraAwardProgress:SetText(LocUtil.LocalizeResFormat(187215, 0, 0))
  self:InitTrait()
end

function BlackFriday_Pass_UIBP:OnSelectTaskList(index, test, test2)
  self.curSelectTaskIndex = index
  self:RefreshTaskSwitch()
  self:RefreshTaskList()
  local isCost = self.curSelectTaskIndex == Enum_Task.Cost
  local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
  local isHaveNotStartEvent = BlackFridayPassModule:GetIsHaveNotStartEvent()
  self:SetWidgetVisible(self.UIRoot.TextBlock_0, isHaveNotStartEvent and isCost)
  local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
  local gem_report_utils = require("client.logic.store.gem_report_utils")
  BlackFridayPassModule:ReportTLog(gem_report_utils.SubEvent_CyberPass002, {tabID = index})
end

function BlackFriday_Pass_UIBP:RefreshTaskSwitch()
  self.UIRoot.WidgetSwitcherExt_TabSelected:SetActiveWidgetIndex(self.curSelectTaskIndex)
end

function BlackFriday_Pass_UIBP:RefreshTaskList()
  local isLimit = self.curSelectTaskIndex == Enum_Task.Limit or self.curSelectTaskIndex == Enum_Task.Cost
  if isLimit then
    self:RefreshBannerTask()
  else
    self:RefreshDailyTaskList()
  end
  self.UIRoot.WidgetSwitcher_Content:SetActiveWidgetIndex(isLimit and 1 or 0)
end

function BlackFriday_Pass_UIBP:RefreshDailyTaskList()
  local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
  local actData = BlackFridayPassModule:GetDailyActData()
  if not actData then
    return
  end
  local ActivityUtil = require("client.slua.logic.activity.ActivityUtil")
  ActivityUtil.SortTask(actData.List, actData.Type)
  self.TaskScroll:SetData(actData.List)
end

function BlackFriday_Pass_UIBP:RefreshBannerTask()
  local data
  if self.curSelectTaskIndex == Enum_Task.Cost then
    data = self.costTabList
  elseif self.curSelectTaskIndex == Enum_Task.Limit then
    data = self.limitTabList
  end
  if data and next(data) then
    self.LoopScrollBox_Exclusive:SetData(data)
  end
end

function BlackFriday_Pass_UIBP:RefreshBottom()
  self:RefreshScore()
  self:RefreshProgress()
  self:RefreshExtraAward()
end

function BlackFriday_Pass_UIBP:RefreshScore()
  local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
  local CyberScore = BlackFridayPassModule:GetCyberScore()
  self.UIRoot.UTRichTextBlock_Score:SetText(LocUtil.LocalizeResFormat(187207, CyberScore))
  self.UIRoot.UTRichTextBlock_OwnScore:SetText(LocUtil.LocalizeResFormat(187206, CyberScore))
end

function BlackFriday_Pass_UIBP:RefreshProgress(IsRefreshAll)
  local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
  local ProgressList = BlackFridayPassModule:GetProgressList()
  self.ProgressScroll:SetData(ProgressList)
end

function BlackFriday_Pass_UIBP:RefreshExtraAward()
  local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
  local ExtraAwardCount = BlackFridayPassModule:GetExtraAwardCount()
  self.UIRoot.TextBlock_ExtraAwardNum:SetText(LocUtil.LocalizeResFormat(187214, ExtraAwardCount))
  local flowScore, PerScore = BlackFridayPassModule:GetCyberScoreRatio()
  self.UIRoot.UTRichTextBlock_ExtraAwardProgress:SetText(LocUtil.LocalizeResFormat(187215, flowScore, PerScore))
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_ExtraRewardGet, 0 < ExtraAwardCount)
end

local QualityBG = {
  [ItemMacros.QUALITY_GREEN] = "/Game/Mod/Lobby/Split/BlackFriday/Pass/NoAtlas/BlackFriday_Pass_Image_Reward_Quality01.BlackFriday_Pass_Image_Reward_Quality01",
  [ItemMacros.QUALITY_BLUE] = "/Game/Mod/Lobby/Split/BlackFriday/Pass/NoAtlas/BlackFriday_Pass_Image_Reward_Quality02.BlackFriday_Pass_Image_Reward_Quality02",
  [ItemMacros.QUALITY_PURPLE] = "/Game/Mod/Lobby/Split/BlackFriday/Pass/NoAtlas/BlackFriday_Pass_Image_Reward_Quality03.BlackFriday_Pass_Image_Reward_Quality03",
  [ItemMacros.QUALITY_PINK] = "/Game/Mod/Lobby/Split/BlackFriday/Pass/NoAtlas/BlackFriday_Pass_Image_Reward_Quality04.BlackFriday_Pass_Image_Reward_Quality04",
  [ItemMacros.QUALITY_RED] = "/Game/Mod/Lobby/Split/BlackFriday/Pass/NoAtlas/BlackFriday_Pass_Image_Reward_Quality05.BlackFriday_Pass_Image_Reward_Quality05"
}

function BlackFriday_Pass_UIBP:FindDoneReward(firstScroll)
  local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
  local ProgressList = BlackFridayPassModule:GetProgressList()
  if not ProgressList or #ProgressList == 0 then
    return
  end
  local doneRewardIndexList = {}
  local leftMostIndex, leftGet
  local hasAward = false
  for index, info in ipairs(ProgressList) do
    local status, advanced = BlackFridayPassModule:GetScoreLevelStatus(info.scoreLevel)
    if status == ActivityProgressStatus.Done or advanced == ActivityProgressStatus.Done then
      doneRewardIndexList[index] = #info.originInfo.item_list
      hasAward = true
      if not leftMostIndex then
        leftMostIndex = index
      end
    elseif firstScroll and (status == ActivityProgressStatus.Get or advanced == ActivityProgressStatus.Get) then
      leftGet = index
    end
  end
  if not hasAward and leftGet then
    self.ProgressScroll:ScrollToItem(leftGet)
  end
  local beginIndex = self.ProgressScroll:GetBeginItemIndex() + 1
  local itemSize = self.UIRoot.LoopScrollBox_1.ItemSize
  local ViewSize = self.ProgressScroll:GetViewSize()
  local canShowCount = math.max(0, ViewSize.X // itemSize - 2)
  local endIndex = beginIndex + canShowCount
  local hasRewardInView = false
  for i = beginIndex, endIndex do
    if doneRewardIndexList[i] then
      log(bWriteLog and string.format("BlackFriday_Pass_UIBP:FindDoneReward. rewardIndex:%s ", tostring(i)))
      hasRewardInView = true
      break
    end
  end
  if hasRewardInView then
    return
  end
  if leftMostIndex and 1 <= leftMostIndex and leftMostIndex <= #ProgressList then
    self.ProgressScroll:ScrollToItem(leftMostIndex)
  end
end

function BlackFriday_Pass_UIBP:UpdateScrollPreview(index)
  if index < self.ScrollIndexStart then
    self.ScrollIndexStart = index
    self.ScrollIndexEnd = self.ScrollIndexStart + self.ShowCount + 1
  end
  if index > self.ScrollIndexEnd then
    self.ScrollIndexEnd = index
    self.ScrollIndexStart = self.ScrollIndexEnd - self.ShowCount - 1
  end
  local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
  local bigRewardPreviewMap = BlackFridayPassModule:GetBigRewardPreviewMap()
  local itemData = self.ProgressScroll:GetItemData(self.ScrollIndexEnd - 1)
  self.ProgressScroll:GetItemCount()
  local score = itemData.scoreLevel
  log(bWriteLog and "[SY]BlackFriday_Pass_UIBP:UpdateScrollPreview." .. score)
  local minScore
  for _, v in pairs(bigRewardPreviewMap) do
    if score <= v.scoreLevel and self.bIsRefreshSpecialPreview then
      local temp = minScore or v.scoreLevel
      minScore = math.min(temp, v.scoreLevel)
    end
  end
  if minScore and self.PreviewLevel ~= minScore then
    log(bWriteLog and "[SY]BlackFriday_Pass_UIBP:UpdateScrollPreview.minScore" .. minScore)
    self.PreviewLevel = minScore
    self:SetBigPrize()
  end
end

function BlackFriday_Pass_UIBP:SetBigPrize()
  local BlackFridayPassModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayPassModule)
  local bigRewardPreviewMap = BlackFridayPassModule:GetBigRewardPreviewMap()
  local previewData = bigRewardPreviewMap[self.PreviewLevel]
  local rewardData = previewData.advanceNumberList[1] or previewData.normalItemList[1]
  local cfg = CDataTable.GetTableData("BlackFridayPassBigPrizeIconCfg", previewData.scoreLevel)
  if cfg then
    self:SetTexture(self.UIRoot.Image_BigPrize, cfg.icon)
  end
  self.UIRoot.UTRichTextBlock_AwardPreviewNumber:SetText(LocUtil.LocalizeResFormat(187211, previewData.scoreLevel))
end

function BlackFriday_Pass_UIBP:OnScrollPreviewSelect(index)
  self.bIsRefreshSpecialPreview = true
  self:UpdateScrollPreview(index)
  self.bIsRefreshSpecialPreview = false
end

function BlackFriday_Pass_UIBP:GetOrReqData()
  local BlackFridayHandler = require("client.network.Protocol.BlackFridayHandler")
  BlackFridayHandler.send_black_friday_get_pass_info_req()
end

function BlackFriday_Pass_UIBP:InitTrait()
  self:InitEventRules()
  self:InitActivityTime()
  self:InitActivityTitle()
end

function BlackFriday_Pass_UIBP:GetActTime()
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local actData = ActivityNewSystem.GetActivityByType(ActivityType.BlackFriday_Pass)
  if not actData then
    return 0, 0
  end
  return actData.StartTime, actData.EndTime
end

function BlackFriday_Pass_UIBP:GetCurSelectTab()
  return self.curSelectTaskIndex
end

function BlackFriday_Pass_UIBP:ShowTaskUI(index)
  local tabData
  if self.curSelectTaskIndex == Enum_Task.Cost then
    tabData = self.costTabList
  elseif self.curSelectTaskIndex == Enum_Task.Limit then
    tabData = self.limitTabList
  end
  if not tabData then
    return
  end
  UIManager.ShowUI(UIManager.UI_Config.BlackFriday_Pass_Popup_UIBP, tabData, index, self.curSelectTaskIndex)
end

return CBlackFriday_Pass_UIBP
