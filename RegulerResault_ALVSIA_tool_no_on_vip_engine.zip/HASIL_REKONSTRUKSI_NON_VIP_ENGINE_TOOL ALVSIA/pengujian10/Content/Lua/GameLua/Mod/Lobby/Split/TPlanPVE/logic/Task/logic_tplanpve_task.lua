local logic_tplanpve_task_marco = require("GameLua.Mod.Lobby.Split.TPlanPVE.logic.Task.logic_tplanpve_task_marco")
local logic_tplanpve_task = {}
local SeasonItemId = 3001215
local taskTables = {
  [logic_tplanpve_task_marco.TaskType.Action] = {
    TableName = "TplanxActionTaskTable",
    AchieveItemId = 3001216
  },
  [logic_tplanpve_task_marco.TaskType.Season] = {
    TableName = "TplanxSeasonTaskTable",
    AchieveItemId = 3001217
  }
}
local TaskConditionType = {
  [1] = 2,
  [3] = 3,
  [4] = 1,
  [5] = 1
}
local TaskDescHandler = {
  [1] = {
    Handler = function(para)
      local itemData = CDataTable.GetTableData("Item", para)
      return itemData and itemData.ItemName or ""
    end
  },
  [2] = {
    Handler = function(para)
      local XMissionTeamUpSystem = require("client.slua.logic.TxMission.logic_xmission_team")
      local mapName, modeName = XMissionTeamUpSystem.GetModeShowInfo(para)
      local strModel = LocUtil.LocalizeResFormat(7545, mapName, modeName)
      return strModel
    end
  },
  [3] = {
    Handler = function(para)
      local cfg = CDataTable.GetTableData("TplanXMonsterTable", para)
      local strModel = cfg and cfg.MonsterName or ""
      return strModel
    end
  }
}
local StatusSortWeight = {
  [logic_tplanpve_task_marco.TaskStatus.Available] = 1,
  [logic_tplanpve_task_marco.TaskStatus.Processing] = 2,
  [logic_tplanpve_task_marco.TaskStatus.NotUnlocked] = 3,
  [logic_tplanpve_task_marco.TaskStatus.Received] = 4,
  [logic_tplanpve_task_marco.TaskStatus.Locked] = 5
}

function logic_tplanpve_task:DefineAndResetData()
  self.taskTabData = {}
  self.taskTypeList = {}
  self.taskTypeTable = {}
  self.subTaskDescCache = {}
  self.task_data = {}
  self.reddot_data = {}
  self.taskItemTable = {}
end

function logic_tplanpve_task:GiveUpTask(task_id)
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  local extraData = {
    showUIKey = "xmission_com_msg_box_2"
  }
  
  local function okCallback()
    self:send_tplanx_task_giveup_req(task_id)
  end
  
  CommonMsgBoxMgr.ShowTPlan(4, LocUtil.GetLocalizeResStr(28150966), LocUtil.GetLocalizeResStr(28150965), okCallback, nil, nil, nil, extraData)
end

function logic_tplanpve_task:InitTaskData()
  for key, value in pairs(taskTables) do
    self:_InitTaskList(key)
    self:_UpdateTaskList(key)
  end
  EventSystem:postEvent(EVENTTYPE_TPLANPVE_NORMAL, EVENTID_TPLANPVE_TASK_ALL_UPDATE)
end

function logic_tplanpve_task:GetSeasonTaskScore()
  return self.task_data.season_score or 0
end

function logic_tplanpve_task:GetTaskDataByID(id)
  for _, value in pairs(self.taskTypeTable) do
    if value[id] then
      return value[id]
    end
    for _, item in pairs(value) do
      if item.phase_index and item.phase_index ~= 0 and item.phasse_task_table[id] then
        return item.phasse_task_table[id]
      end
    end
  end
  return nil
end

function logic_tplanpve_task:GetIsTaskMarkItem(itemId)
  for index, value in pairs(self.taskItemTable) do
    if value[itemId] then
      return true
    end
  end
  return false
end

function logic_tplanpve_task:GetTaskData(type)
  return self.taskTypeList[type]
end

function logic_tplanpve_task:GetTaskSourceData(taskType)
  return self.task_data[taskType]
end

function logic_tplanpve_task:IsOpenSeasonTask()
  local LogicTxMissionMain = require("client.slua.logic.TxMission.logic_xmission_main")
  local level = LogicTxMissionMain.prestige_level
  return 10 <= level
end

function logic_tplanpve_task:GetTaskViewList()
  local actionTask, actionReddot, actionHasAvailable = self:ParserTaskData(logic_tplanpve_task_marco.TaskType.Action)
  local seasonTask, seasonReddot, seasonHasAvailable = self:ParserTaskData(logic_tplanpve_task_marco.TaskType.Season)
  return {actionTask, seasonTask}, seasonReddot or actionReddot, actionHasAvailable, seasonHasAvailable
end

function logic_tplanpve_task:GetAllReceivedTaskList()
  local list = {}
  for _, value in pairs(self.taskTypeTable) do
    for _, item in pairs(value) do
      if item.phase_index and item.phase_index ~= 0 then
        for _, sub_task in ipairs(item.phasse_task_list or {}) do
          if sub_task.status == logic_tplanpve_task_marco.TaskStatus.Processing then
            table.insert(list, sub_task)
          end
        end
      elseif item.status == logic_tplanpve_task_marco.TaskStatus.Processing then
        table.insert(list, item)
      end
    end
  end
  return list
end

function logic_tplanpve_task:OpenGoToAchPop(AchID)
  if not AchID or AchID == 0 then
    return
  end
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  local extraData = {
    showUIKey = "xmission_com_msg_box_2"
  }
  
  local function okCallback()
    ShowNotice(47088237)
  end
  
  CommonMsgBoxMgr.ShowTPlan(4, LocUtil.GetLocalizeResStr(28150966), LocUtil.GetLocalizeResStr(47088237), okCallback, nil, nil, nil, extraData)
end

function logic_tplanpve_task:ParserTaskData(taskType)
  if taskType == logic_tplanpve_task_marco.TaskType.Season and not self:IsOpenSeasonTask() then
    return nil, false, false
  end
  local task_data
  local reddot = false
  local hasAvailable = false
  
  local function CheckTask(value)
    if not hasAvailable and value.status == logic_tplanpve_task_marco.TaskStatus.Available then
      hasAvailable = true
      log(bWriteLog and "logic_tplanpve_task:ParserTaskData hasAvailable by task_id = " .. tostring(value.task_id))
    end
    if not reddot and value.status == logic_tplanpve_task_marco.TaskStatus.NotUnlocked then
      reddot = true
      log(bWriteLog and "logic_tplanpve_task:ParserTaskData reddot by task_id = " .. tostring(value.task_id))
    end
    if taskType == logic_tplanpve_task_marco.TaskType.Season and value.achieve_id ~= 0 and value.status ~= logic_tplanpve_task_marco.TaskStatus.Available then
      return
    end
    if value.status ~= logic_tplanpve_task_marco.TaskStatus.Received and value.status ~= logic_tplanpve_task_marco.TaskStatus.Locked and (not task_data or self:sortTask(value, task_data)) then
      task_data = value
    end
  end
  
  for _, value in ipairs(self.taskTypeList[taskType] or {}) do
    if value.phase_index and value.phase_index ~= 0 then
      for _, sub_task in ipairs(value.phasse_task_list or {}) do
        CheckTask(sub_task)
      end
    else
      CheckTask(value)
    end
  end
  return task_data, reddot, hasAvailable
end

function logic_tplanpve_task:SubmitProp(task_id, sub_task_data)
  local itemId = 0
  for _, cond in ipairs(sub_task_data.cond_list) do
    if cond.cond_type == 4 then
      itemId = cond.cond_value
      break
    end
  end
  if itemId == 0 then
    log(bWriteLog and "logic_tplanpve_task:SubmitProp itemId == 0")
    return
  end
  local tExchangeData = {
    type = 1,
    itemId = itemId,
    title = LocUtil.GetLocalizeResStr(66881)
  }
  local xMission_Wardrobe_Data = require("client.slua.logic.TxMission.warpre.xmission_wardrobe_data")
  local itemInfo = xMission_Wardrobe_Data.GetItemByItemID(itemId)
  local have_count = itemInfo and itemInfo.item_num or 0
  if have_count == 0 then
    local itemCfg = CDataTable.GetTableData("Item", itemId)
    ShowNotice(LocUtil.LocalizeResFormat(11106, itemCfg.ItemName))
    return
  end
  local maxCount = sub_task_data.finish_value - sub_task_data.cur_progress
  local tExtraData = {
    maxAddCount = math.min(maxCount, have_count),
    fExchangeCallback = function(tExchangeData, nExchangeCount)
      local tlog_report_utils = require("client.slua.config.tlog.tlog_report_utils")
      local TLogReasonStr = json.encode({
        task_id = task_id,
        child_id = sub_task_data.sub_task_id,
        count = nExchangeCount
      })
      tlog_report_utils.ReportTLogEvent(TLogEventDefine.TPlanLobbyTaskPropSubmit, task_id, TLogReasonStr)
      local itemList = xMission_Wardrobe_Data.GetItemListByItemID(itemId)
      local total = nExchangeCount
      for index, value in ipairs(itemList) do
        if total <= value.item_num then
          self:send_tplanx_task_hand_in_req(task_id, sub_task_data.sub_task_id, value.inst_id, total)
          break
        else
          self:send_tplanx_task_hand_in_req(task_id, sub_task_data.sub_task_id, value.inst_id, value.item_num)
          total = total - value.item_num
        end
      end
    end,
    tButton1Key = 74130,
    tButton2Key = 66881
  }
  UIManager.ShowUI(UIManager.UI_Config.XMission_Exchange_UIBP, tExchangeData, tExtraData)
end

function logic_tplanpve_task:GetTaskRawData(task_id, category)
  if not task_id then
    return nil
  end
  if category then
    local list = self.task_data[category]
    return list and list[task_id] or nil
  end
  for _, list in pairs(self.task_data or {}) do
    local one = list and list[task_id]
    if one then
      return one
    end
  end
  return nil
end

function logic_tplanpve_task:GetTaskStatus(task_id, category)
  local one = self:GetTaskRawData(task_id, category)
  return one and one[logic_tplanpve_task_marco.TaskData.Status] or nil
end

function logic_tplanpve_task:IsTaskFinished(task_id, category)
  local status = self:GetTaskStatus(task_id, category)
  if not status then
    return false
  end
  return status == logic_tplanpve_task_marco.TaskStatus.Available or status == logic_tplanpve_task_marco.TaskStatus.Received
end

function logic_tplanpve_task:send_tplanx_task_sync_all_req()
  local TplanxTaskHandler = require("client.network.Protocol.TplanxTaskHandler")
  TplanxTaskHandler.send_tplanx_task_sync_all_req()
end

function logic_tplanpve_task:on_tplanx_task_sync_all(data)
  self.task_data = data
  self:InitTaskData()
end

function logic_tplanpve_task:on_tplanx_task_sync_one(category, task_id, one_task_data)
  self.task_data[category] = self.task_data[category] or {}
  self.task_data[category][task_id] = one_task_data
  self:_UpdateTask(category, task_id, one_task_data)
  self:_UpdateTaskList(category)
  EventSystem:postEvent(EVENTTYPE_TPLANPVE_NORMAL, EVENTID_TPLANPVE_TASK_ONE_UPDATE, task_id)
end

function logic_tplanpve_task:send_tplanx_task_take_award_req(task_id)
  local TplanxTaskHandler = require("client.network.Protocol.TplanxTaskHandler")
  TplanxTaskHandler.send_tplanx_task_take_award_req(task_id)
end

function logic_tplanpve_task:on_tplanx_task_take_award_rsp(task_id, award_list, season_score)
  local Logic_CommonItemGet = require("client.slua.logic.common.CommonItemGet.Logic_CommonItemGet")
  local showList = award_list
  local task_data = self:GetTaskDataByID(task_id)
  
  local function addAward(id, count)
    if not id or id == 0 then
      return
    end
    local item = {
      res_id = id,
      count = count or 0
    }
    table.insert(showList, item)
  end
  
  if task_data then
    addAward(task_data.award_score and task_data.award_score ~= 0 and SeasonItemId or 0, task_data.award_score or 0)
    addAward(task_data.achieve_id and task_data.achieve_id ~= 0 and taskTables[task_data.taskType].AchieveItemId or 0, 0)
    if task_data.achieve_id and task_data.achieve_id ~= 0 then
      ShowNotice(47088237)
    end
  end
  Logic_CommonItemGet.ShowPanel_DefaultStyle(showList)
  local time_ticker = require("common.time_ticker")
  time_ticker.AddTimerOnce(0.1, function()
    self.task_data.season_score = season_score
    self:InitTaskData()
    EventSystem:postEvent(EVENTTYPE_TPLANPVE_NORMAL, EVENTID_TPLANPVE_TASK_ONE_UPDATE, task_id)
  end)
end

function logic_tplanpve_task:send_tplanx_task_accept_req(task_id)
  local TplanxTaskHandler = require("client.network.Protocol.TplanxTaskHandler")
  TplanxTaskHandler.send_tplanx_task_accept_req(task_id)
end

function logic_tplanpve_task:on_tplanx_task_accept_rsp(task_id)
end

function logic_tplanpve_task:send_tplanx_task_giveup_req(task_id)
  local TplanxTaskHandler = require("client.network.Protocol.TplanxTaskHandler")
  TplanxTaskHandler.send_tplanx_task_giveup_req(task_id)
end

function logic_tplanpve_task:on_tplanx_task_giveup_rsp(task_id)
end

function logic_tplanpve_task:send_tplanx_task_hand_in_req(task_id, sub_task_id, inst_id, num)
  local TplanxTaskHandler = require("client.network.Protocol.TplanxTaskHandler")
  TplanxTaskHandler.send_tplanx_task_hand_in_req(task_id, sub_task_id, inst_id, num)
end

function logic_tplanpve_task:on_tplanx_task_hand_in_rsp(task_id, sub_task_id, take)
end

function logic_tplanpve_task:_InitTaskList(taskType)
  self.taskTypeTable[taskType] = {}
  local data_table = self:GetTaskSourceData(taskType)
  for task_id, task_data in pairs(data_table or {}) do
    self:_UpdateTask(taskType, task_id, task_data)
  end
end

function logic_tplanpve_task:_UpdateTask(taskType, task_id, task_data)
  local task_table = self.taskTypeTable[taskType]
  if not task_table then
    task_table = {}
    self.taskTypeTable[taskType] = task_table
  end
  local status = task_data.status or logic_tplanpve_task_marco.TaskStatus.NotUnlocked
  local CommonItem_Const = require("client.slua.component.item.ItemUtils.CommonItem_Const")
  local cfg = CDataTable.GetTableData(taskTables[taskType].TableName, task_id)
  if cfg then
    if cfg.season_index and cfg.season_index ~= 0 then
      local logic_xmission_season = require("client.slua.logic.TxMission.season.logic_xmission_season")
      local seasonId = logic_xmission_season.GetCurTXSeasonID()
      if seasonId < cfg.season_index then
        log(bWriteLog and "logic_tplanpve_task:_UpdateTask seasonId: %d, cfg.season_index: %d", seasonId, cfg.season_index)
        return
      end
    end
    local season_score = self:GetSeasonTaskScore()
    if cfg.precond_score and 0 < cfg.precond_score and season_score < cfg.precond_score then
      status = logic_tplanpve_task_marco.TaskStatus.Locked
      log(bWriteLog and string.format("logic_tplanpve_task:_UpdateTask task_id:%s locked by precond_score: %d, season_score: %d", task_id, cfg.precond_score, season_score))
    end
    local tableIndex = task_id
    local isPhase = cfg.phase_id and cfg.phase_id ~= 0
    if isPhase then
      tableIndex = cfg.phase_id
    end
    local isNew = false
    if not task_table[tableIndex] then
      if isPhase then
        task_table[tableIndex] = {
          phase_index = tableIndex,
          phasse_task_table = {}
        }
      end
      isNew = true
    elseif isPhase and not task_table[tableIndex].phasse_task_table[task_id] then
      isNew = true
    end
    if isNew then
      local sub_task_list = self:GetChildTaskListData(cfg, task_data)
      local get_achieve_id = cfg.achieve_id and cfg.achieve_id ~= 0 and taskTables[taskType].AchieveItemId or 0
      local awards = self:SplitAwardList(cfg.awards, CommonItem_Const.Enum_ItemStatus.Not, cfg.award_score, get_achieve_id)
      local task_info = {
        task_id = cfg.task_id,
        task_name = cfg.task_name,
        taskType = taskType,
        season_index = cfg.season_index or 0,
        taskDescription = self:GetTaskDesc(cfg),
        awardData = awards,
        sub_task_list = sub_task_list,
        status = status,
        achieve_id = cfg.achieve_id or 0,
        task_nature = cfg.task_nature or 3,
        phase_id = cfg.phase_id or 0,
        order = cfg.order,
        round_policy = cfg.round_policy,
        precond_score = cfg.precond_score or 0,
        precond_task = cfg.precond_task,
        award_score = cfg.award_score,
        auto_accept = cfg.auto_accept or 0
      }
      if isPhase then
        task_table[tableIndex].phasse_task_table[task_id] = task_info
      else
        task_table[tableIndex] = task_info
      end
    else
      local audio_util = require("client.common.audio_util")
      local task_info = task_table[tableIndex]
      if isPhase then
        task_info = task_table[tableIndex].phasse_task_table[task_id]
      end
      if task_info.achieve_id ~= 0 and task_info.status == logic_tplanpve_task_marco.TaskStatus.Available and status == logic_tplanpve_task_marco.TaskStatus.Available then
        audio_util.PlayAudio(sound_config.TPlan_Task_GetAchievemnt)
      end
      task_info.status = status
      for key, value in ipairs(task_info.sub_task_list) do
        local cur_progress = task_data.sub_tasks and task_data.sub_tasks[value.sub_task_id] or 0
        if cur_progress > value.cur_progress and cur_progress >= value.finish_value then
          audio_util.PlayAudio(sound_config.TPlan_Task_Complete)
        end
        value.cur_progress = cur_progress
      end
    end
  else
    log(bWriteLog and "logic_tplanpve_task:_UpdateTask cfg is nil by id = " .. tostring(task_id))
  end
end

function logic_tplanpve_task:GetChildTaskListData(taskCfg, task_data)
  local result = {}
  local StringUtil = require("common.string_util")
  local child_taskid_list = StringUtil.SplitToNum(taskCfg.sub_id_str, "|")
  for index, value in ipairs(child_taskid_list) do
    local cfg = CDataTable.GetTableData("TplanxSubTaskTable", value)
    if cfg then
      local cur_progress = task_data.sub_tasks and task_data.sub_tasks[value] or 0
      result[index] = {
        sub_task_id = cfg.sub_task_id,
        sub_task_name = cfg.sub_task_name,
        target_type = cfg.target_type,
        finish_type = cfg.finish_type,
        finish_value = cfg.finish_value,
        sub_award = cfg.sub_award,
        finish_show_progress = cfg.finish_show_progress,
        cur_progress = cur_progress,
        task_desc = self:GetSubTaskDesc(cfg),
        can_track = cfg.can_track or 0,
        jump_url = cfg.jump_url or "",
        cond_type_1 = cfg.cond_type_1,
        cond_value_1 = cfg.cond_value_1,
        cond_type_4 = cfg.cond_type_1,
        cond_value_4 = cfg.cond_value_1,
        cond_list = {
          {
            cond_type = cfg.cond_type_2,
            cond_value = cfg.cond_value_2
          },
          {
            cond_type = cfg.cond_type_3,
            cond_value = cfg.cond_value_3
          }
        },
        task_nature = taskCfg.task_nature or 3
      }
    else
      log(bWriteLog and "logic_tplanpve_task:GetChildTaskListData cfg is nil by id = " .. tostring(value))
      return
    end
  end
  return result
end

function logic_tplanpve_task:GetTaskDesc(cfg)
  return cfg.task_desc
end

function logic_tplanpve_task:GetSubTaskDesc(cfg)
  if self.subTaskDescCache[cfg.sub_task_id] then
    return self.subTaskDescCache[cfg.sub_task_id]
  end
  local StringUtil = require("common.string_util")
  local hightlightSwitch = StringUtil.SplitToNum(cfg.highlight_policy, "|")
  local paras = {}
  for i = 1, 4 do
    local paraType = cfg["cond_type_" .. i] or 0
    if paraType == 0 then
      break
    end
    local para = cfg["cond_value_" .. i] or 0
    local str = tostring(para)
    if TaskConditionType[paraType] and TaskDescHandler[TaskConditionType[paraType]] then
      str = TaskDescHandler[TaskConditionType[paraType]].Handler(para)
    end
    if hightlightSwitch[i] == 1 then
      str = "<Lobby_Font07>" .. str .. "</>"
    end
    table.insert(paras, str)
  end
  self.subTaskDescCache[cfg.sub_task_id] = LocUtil.LocalizeResFormatByStr(cfg.task_desc, table.unpack(paras))
  return self.subTaskDescCache[cfg.sub_task_id]
end

function logic_tplanpve_task:_UpdateTaskList(taskType)
  self.taskItemTable[taskType] = {}
  self.taskTypeList[taskType] = {}
  log(bWriteLog and "logic_tplanpve_task:_UpdateTaskList taskType = " .. tostring(taskType))
  log_tree("logic_tplanpve_task:_UpdateTaskList self.taskTypeTable = ", self.taskTypeTable[taskType])
  for index, value in pairs(self.taskTypeTable[taskType] or {}) do
    if value.phase_index and value.phase_index ~= 0 then
      value.phasse_task_list = {}
      for key, task_info in pairs(value.phasse_task_table or {}) do
        self:_UpdatePreTask(taskType, task_info)
        table.insert(value.phasse_task_list, task_info)
      end
      table.sort(value.phasse_task_list, function(a, b)
        return self:sortTask(a, b)
      end)
    else
      self:_UpdatePreTask(taskType, value)
    end
    table.insert(self.taskTypeList[taskType], value)
  end
  log_tree("logic_tplanpve_task:_UpdateTaskList self.taskItemTable = ", self.taskItemTable)
  table.sort(self.taskTypeList[taskType], function(a, b)
    return self:sortTask(a, b)
  end)
end

function logic_tplanpve_task:_UpdatePreTask(taskType, value)
  if value.precond_task and value.precond_task ~= 0 and value.status == logic_tplanpve_task_marco.TaskStatus.NotUnlocked then
    local precond_task = self.task_data[taskType] and self.task_data[taskType][value.precond_task] or nil
    if not precond_task or precond_task.status ~= logic_tplanpve_task_marco.TaskStatus.Received then
      value.status = logic_tplanpve_task_marco.TaskStatus.Locked
      log(bWriteLog and string.format("logic_tplanpve_task:_UpdatePreTask task_id:%s locked by precond_task %s", value.task_id, tostring(value.precond_task)))
    end
  end
  if value.status == logic_tplanpve_task_marco.TaskStatus.Processing then
    for index, sub_value in ipairs(value.sub_task_list) do
      if sub_value.target_type == 21 and sub_value.cur_progress < sub_value.finish_value then
        local itemId = 0
        for _, cond in ipairs(sub_value.cond_list) do
          if cond.cond_type == 4 then
            itemId = cond.cond_value
            break
          end
        end
        self.taskItemTable[taskType][itemId] = true
      end
    end
  end
end

function logic_tplanpve_task:GetShowNumAndSum(type)
  local branchShowNum = 0
  local sum = 0
  local list = self:GetTaskData(type)
  for _, info in ipairs(list) do
    local status = info[logic_tplanpve_task_marco.TaskData.Status] or logic_tplanpve_task_marco.TaskStatus.NotUnlocked
    if status ~= logic_tplanpve_task_marco.TaskStatus.NotUnlocked then
      branchShowNum = branchShowNum + 1
    end
    sum = sum + 1
  end
  return branchShowNum, sum
end

function logic_tplanpve_task:SplitAwardList(para, status, award_score, achieve_id)
  local StringUtil = require("common.string_util")
  local strList = StringUtil.Split(para, "|")
  local list = {}
  
  local function addAward(id, count, time)
    local item = {
      awardId = id,
      awardNum = count or 0,
      awardHours = time or 0,
      awardStatus = status
    }
    table.insert(list, item)
  end
  
  for index, value in ipairs(strList) do
    local paras = StringUtil.SplitToNum(value, ";")
    addAward(paras[1], paras[2], paras[3])
  end
  if award_score and award_score ~= 0 then
    addAward(SeasonItemId, award_score)
  end
  if achieve_id and achieve_id ~= 0 then
    addAward(achieve_id, 1)
  end
  return list
end

function logic_tplanpve_task:sortTask(a, b)
  local hasPhaseA = a.phase_index ~= nil and a.phase_index ~= 0
  local hasPhaseB = b.phase_index ~= nil and b.phase_index ~= 0
  if hasPhaseA ~= hasPhaseB then
    return not hasPhaseA
  end
  if hasPhaseA then
    return a.phase_index < b.phase_index
  end
  local weightA = StatusSortWeight[a.status] or 99
  local weightB = StatusSortWeight[b.status] or 99
  if weightA ~= weightB then
    return weightA < weightB
  end
  return (a.order or 0) < (b.order or 0)
end

local class = require("class")
local CModuleBase = require("client.module_framework.ModuleBase")
local Clogic_tplanpve_task = class(CModuleBase, nil, logic_tplanpve_task)
return Clogic_tplanpve_task
