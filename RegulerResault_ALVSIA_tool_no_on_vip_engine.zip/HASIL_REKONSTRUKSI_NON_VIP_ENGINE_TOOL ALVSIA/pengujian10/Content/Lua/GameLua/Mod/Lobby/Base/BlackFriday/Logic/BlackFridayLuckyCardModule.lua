local BlackFridayLuckyCardModule = {
  EnumUpdateReason = {
    CardBuy = "buy",
    TakeReward = "take_reward",
    TakeAllReward = "take_all_reward"
  }
}
local BlackFridayLuckyCardConfig = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.BlackFridayLuckyCardConfig")
local BlackFridayLuckyCardDisplayConfig = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.BlackFridayLuckyCardDisplayConfig")
local BlackFridayLuckyCardBenefitState = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.BlackFridayLuckyCardBenefitState")
local familycenter_macro = require("client.slua.logic.familycenter.familycenter_macro")
local LOAD_STATE = {
  Unloaded = "Unloaded",
  Loading = "Loading",
  Ready = "Ready",
  Failed = "Failed"
}
local ERROR_CODE = BlackFridayLuckyCardConfig.ErrorCode
local STALE_VIEW_ERROR_CODE = BlackFridayLuckyCardConfig.StaleViewErrorCode
local LUCKY_CARD_PRIVILEGE_TYPE_ID = BlackFridayLuckyCardConfig.PrivilegeId.LuckyCard
local REWARD_TYPE_OPEN = BlackFridayLuckyCardConfig.RewardType.Open
local REWARD_TYPE_DAILY = BlackFridayLuckyCardConfig.RewardType.Daily
local REWARD_STATUS_CAN_RECEIVE = BlackFridayLuckyCardConfig.RewardStatus.CanReceive
local REWARD_STATUS_RECEIVED = BlackFridayLuckyCardConfig.RewardStatus.Received
local BENEFIT_SOURCE_TYPE = BlackFridayLuckyCardConfig.BenefitSourceType
local REQUEST_TIMEOUT_SECONDS = 15
local RETRY_DELAY_SECONDS = 1
local MAX_AUTO_RETRY_COUNT = 1
BlackFridayLuckyCardModule.LoadState = LOAD_STATE
BlackFridayLuckyCardModule.BenefitUsageKey = BlackFridayLuckyCardConfig.BenefitUsageKey
BlackFridayLuckyCardModule.SourceState = BlackFridayLuckyCardConfig.SourceState
BlackFridayLuckyCardModule.BenefitKind = BlackFridayLuckyCardConfig.BenefitKind
BlackFridayLuckyCardModule.BenefitSourceType = BENEFIT_SOURCE_TYPE

local function SafeCallback(callback, ...)
  if type(callback) ~= "function" then
    return false
  end
  local success, err = pcall(callback, ...)
  if not success then
    log_error("BlackFridayLuckyCardModule callback failed: " .. tostring(err))
  end
  return success
end

local function GetPrivilegeTypeId(view)
  return view and tonumber(view.privilege_id or view.privilege_type_id)
end

function BlackFridayLuckyCardModule:DefineAndResetData()
  self._LoadState = LOAD_STATE.Unloaded
  self._Views = {}
  self._ViewMap = {}
  self._LuckyCardData = nil
  self._Waiters = {}
  self._LastError = nil
  self._DataRevision = 0
  self._QueryStartRevision = 0
  self._AutoRetryCount = 0
  self._QueryTimeoutTimer = nil
  self._RetryTimer = nil
  self._BuyRequest = nil
  self._RewardRequest = nil
  self._EntryComplianceAllowed = nil
  self._BuyRewardPresentation = nil
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  self.entryAnimRecord = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eBlackFridayCardEnterAnim) or {}
end

function BlackFridayLuckyCardModule:OnInitialize()
  self:EnsureReady()
end

function BlackFridayLuckyCardModule:RegistEvents()
  self:AddCommonEvent(EVENTTYPE_NEXTDAY, EVENTID_NEXTDAY_ZERO, self.OnNextDayZero, self)
  local logic_familycenter = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_familycenter)
  self._EntryComplianceAllowed = self:CanShowLuckyCardEntry()
  self:BindLuaObjEvent(logic_familycenter, "OnStatusUpdated", function()
    self:OnComplianceStatusUpdated()
  end)
end

function BlackFridayLuckyCardModule:OnComplianceStatusUpdated()
  local allowed = self:CanShowLuckyCardEntry()
  if self._EntryComplianceAllowed == allowed then
    return
  end
  self._EntryComplianceAllowed = allowed
  EventSystem:postEvent(EVENTTYPE_ACTIVITY_BLACK_FRIDAY, EVENTID_ACTIVITY_BLACK_FRIDAY_LUCKY_CARD_ENTRY_UPDATE)
end

function BlackFridayLuckyCardModule:OnLogin(bReLogin)
  if bReLogin then
    self:EnsureReady(nil, true)
  end
end

function BlackFridayLuckyCardModule:OnPostSwitchGameStatus(preState, nextState)
  if GameStatus.IsPostSwitchEnterLobbyOrMainCityFromFighting(preState, nextState) then
    self:OnComplianceStatusUpdated()
    self:EnsureReady(nil, true)
  end
end

function BlackFridayLuckyCardModule:OnNextDayZero()
  self:EnsureReady(nil, true)
end

function BlackFridayLuckyCardModule:OnLogOut()
  self:ResetData()
end

function BlackFridayLuckyCardModule:OnDestroy()
  self:ResetData()
end

function BlackFridayLuckyCardModule:_CancelOperationTimer(request)
  if request and request.timeoutTimer then
    self:RemoveTimer(request.timeoutTimer)
    request.timeoutTimer = nil
  end
end

function BlackFridayLuckyCardModule:_CancelPendingOperations()
  self:_CancelOperationTimer(self._BuyRequest)
  self:_CancelOperationTimer(self._RewardRequest)
  self._BuyRequest = nil
  self._RewardRequest = nil
end

function BlackFridayLuckyCardModule:_CancelQueryTimers()
  if self._QueryTimeoutTimer then
    self:RemoveTimer(self._QueryTimeoutTimer)
    self._QueryTimeoutTimer = nil
  end
  if self._RetryTimer then
    self:RemoveTimer(self._RetryTimer)
    self._RetryTimer = nil
  end
end

function BlackFridayLuckyCardModule:_NotifyUpdated(reason)
  local BlackFridayRedDotModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayRedDotModule)
  local BlackFridayMacros = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.BlackFridayMacros")
  local nActType = BlackFridayMacros.ActivityType.LuckyCard
  local bTreeReady = BlackFridayRedDotModule:GetRedDotData() ~= nil
  if bTreeReady then
    BlackFridayRedDotModule:UpdateDirectRedDot(nActType)
  end
  local tRedDot = BlackFridayRedDotModule:GetActRedDot(nActType)
  printf("BlackFridayLuckyCardModule:_NotifyUpdated sync main tab red dot, reason:%s, treeReady:%s, redDotType:%s, newCount:%s", tostring(reason), tostring(bTreeReady), tostring(tRedDot and tRedDot.redDotType), tostring(tRedDot and tRedDot.newCount))
  EventSystem:postEvent(EVENTTYPE_ACTIVITY_BLACK_FRIDAY, EVENTID_ACTIVITY_BLACK_FRIDAY_LUCKY_CARD_DATA_UPDATE, reason, self._Views)
end

function BlackFridayLuckyCardModule:_FlushWaiters(success, errCode)
  local waiters = self._Waiters
  self._Waiters = {}
  for _, callback in ipairs(waiters) do
    SafeCallback(callback, success, self._Views, errCode)
  end
end

function BlackFridayLuckyCardModule:_ReplaceViews(views)
  self._Views = type(views) == "table" and views or {}
  self._ViewMap = {}
  for _, view in pairs(self._Views) do
    local privilegeTypeId = GetPrivilegeTypeId(view)
    if privilegeTypeId then
      self._ViewMap[privilegeTypeId] = view
    end
  end
  self._LuckyCardData = self._ViewMap[LUCKY_CARD_PRIVILEGE_TYPE_ID]
end

function BlackFridayLuckyCardModule:_ApplyView(view, reason)
  local privilegeTypeId = GetPrivilegeTypeId(view)
  if not privilegeTypeId then
    return false
  end
  local oldView = self._ViewMap[privilegeTypeId]
  self._ViewMap[privilegeTypeId] = view
  if oldView then
    for index, item in ipairs(self._Views) do
      if GetPrivilegeTypeId(item) == privilegeTypeId then
        self._Views[index] = view
        break
      end
    end
  else
    table.insert(self._Views, view)
    table.sort(self._Views, function(a, b)
      return (GetPrivilegeTypeId(a) or 0) < (GetPrivilegeTypeId(b) or 0)
    end)
  end
  self._LuckyCardData = self._ViewMap[LUCKY_CARD_PRIVILEGE_TYPE_ID]
  self._DataRevision = self._DataRevision + 1
  self._LoadState = LOAD_STATE.Ready
  self._LastError = nil
  self:_NotifyUpdated(reason)
  return true
end

function BlackFridayLuckyCardModule:_BeginQuery(isRetry)
  self._LoadState = LOAD_STATE.Loading
  self._LastError = nil
  self._QueryStartRevision = self._DataRevision
  if not isRetry then
    self._AutoRetryCount = 0
  end
  local CommercialPrivilegeHandler = require("client.network.Protocol.CommercialPrivilegeHandler")
  CommercialPrivilegeHandler.send_get_commercial_privilege_info_req()
  self._QueryTimeoutTimer = self:AddTimerOnce(REQUEST_TIMEOUT_SECONDS, function()
    self._QueryTimeoutTimer = nil
    if self._LoadState == LOAD_STATE.Loading then
      self:_HandleQueryFailed("timeout")
    end
  end)
end

function BlackFridayLuckyCardModule:_HandleQueryFailed(errCode)
  self:_CancelQueryTimers()
  self._LoadState = LOAD_STATE.Failed
  self._LastError = errCode
  self:_FlushWaiters(false, errCode)
  if self._AutoRetryCount < MAX_AUTO_RETRY_COUNT then
    self._AutoRetryCount = self._AutoRetryCount + 1
    self._RetryTimer = self:AddTimerOnce(RETRY_DELAY_SECONDS, function()
      self._RetryTimer = nil
      if self._LoadState == LOAD_STATE.Failed then
        self:_BeginQuery(true)
      end
    end)
  end
end

function BlackFridayLuckyCardModule:ShowErrorTips(res)
  res = tonumber(res)
  if not res or res == 0 then
    return
  end
  if res == ERROR_CODE.Buying then
    return
  end
  local sText = LocUtil.GetLocalizeResStr(res)
  if sText ~= "" then
    ShowNotice(sText)
  else
    ShowNotice(res)
  end
end

function BlackFridayLuckyCardModule:_HandleOperationFailed(res)
  if STALE_VIEW_ERROR_CODE[tonumber(res)] then
    self:EnsureReady(nil, true)
  end
  self:ShowErrorTips(res)
end

function BlackFridayLuckyCardModule:EnsureReady(callback, force)
  if self._LoadState == LOAD_STATE.Ready and not force then
    SafeCallback(callback, true, self._Views, nil)
    return true
  end
  if callback then
    table.insert(self._Waiters, callback)
  end
  if self._LoadState == LOAD_STATE.Loading then
    return false
  end
  self:_CancelQueryTimers()
  self:_BeginQuery(false)
  return false
end

function BlackFridayLuckyCardModule:HandlePrivilegeInfo(res, views)
  local luckyCardView
  for _, view in pairs(type(views) == "table" and views or {}) do
    if GetPrivilegeTypeId(view) == LUCKY_CARD_PRIVILEGE_TYPE_ID then
      luckyCardView = view
      break
    end
  end
  if bWriteLog then
    log_tree("BlackFridayLuckyCardModule:HandlePrivilegeInfo - views = ", views)
    if json and json.encode then
      log("BlackFridayLuckyCardModule:HandlePrivilegeInfo - views json=" .. json.encode(views or {}))
    end
  end
  log(bWriteLog and string.format("BlackFridayLuckyCardModule:HandlePrivilegeInfo - res=%s view_found=%s has_privilege=%s", tostring(res), tostring(luckyCardView ~= nil), tostring(luckyCardView ~= nil and luckyCardView.has_privilege == true)))
  self:_CancelQueryTimers()
  if res ~= 0 then
    self:_HandleQueryFailed(res)
    return
  end
  local queryIsCurrent = self._QueryStartRevision == self._DataRevision
  if queryIsCurrent then
    self:_ReplaceViews(views)
  end
  self._LoadState = LOAD_STATE.Ready
  self._LastError = nil
  self._AutoRetryCount = 0
  if queryIsCurrent then
    self:_NotifyUpdated("query")
  end
  self:_FlushWaiters(true, nil)
end

function BlackFridayLuckyCardModule:GetLoadState()
  return self._LoadState
end

function BlackFridayLuckyCardModule:IsReady()
  return self._LoadState == LOAD_STATE.Ready
end

function BlackFridayLuckyCardModule:GetLastError()
  return self._LastError
end

function BlackFridayLuckyCardModule:GetSnapshot()
  return self._Views
end

function BlackFridayLuckyCardModule:GetPrivilegeView(privilegeTypeId)
  return self._ViewMap[tonumber(privilegeTypeId)]
end

function BlackFridayLuckyCardModule:HasPrivilege(privilegeTypeId)
  local view = self:GetPrivilegeView(privilegeTypeId)
  return view ~= nil and view.has_privilege == true
end

function BlackFridayLuckyCardModule:HasLuckyCard()
  return self:HasPrivilege(LUCKY_CARD_PRIVILEGE_TYPE_ID)
end

function BlackFridayLuckyCardModule:CanShowLuckyCardEntry()
  local logic_familycenter = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_familycenter)
  local cached = logic_familycenter:GetCachedResult(familycenter_macro.ENUM_SCENE.TREASURE_CHEST)
  return cached ~= nil and cached.pass == true
end

function BlackFridayLuckyCardModule:GetBenefits(privilegeTypeId)
  local view = self:GetPrivilegeView(privilegeTypeId or LUCKY_CARD_PRIVILEGE_TYPE_ID)
  return view and view.benefits or nil
end

function BlackFridayLuckyCardModule:GetBenefit(benefitId, privilegeTypeId)
  for _, benefit in pairs(self:GetBenefits(privilegeTypeId) or {}) do
    if tonumber(benefit.privilege_benefit_id) == tonumber(benefitId) then
      return benefit
    end
  end
  return nil
end

function BlackFridayLuckyCardModule:GetBenefitByKind(benefitKind, privilegeTypeId)
  for _, benefit in pairs(self:GetBenefits(privilegeTypeId) or {}) do
    if tonumber(benefit.privilege_benefit_type) == tonumber(benefitKind) then
      return benefit
    end
  end
  return nil
end

function BlackFridayLuckyCardModule:GetBenefitUseStateByKind(benefitKind, usageKey, businessState, privilegeId)
  privilegeId = tonumber(privilegeId) or LUCKY_CARD_PRIVILEGE_TYPE_ID
  local tBenefit = self:GetBenefitByKind(benefitKind, privilegeId)
  local tView = self:GetPrivilegeView(privilegeId)
  return BlackFridayLuckyCardBenefitState.Resolve({
    ready = self:IsReady(),
    view = tView,
    sourceType = BENEFIT_SOURCE_TYPE.Benefit,
    sourceId = tBenefit and tBenefit.privilege_benefit_id or nil,
    usageKey = usageKey,
    privilegeId = privilegeId,
    sourceData = tBenefit,
    businessState = businessState
  })
end

function BlackFridayLuckyCardModule:GetBenefitUseState(benefitId, usageKey, businessState, privilegeId)
  benefitId = tonumber(benefitId)
  privilegeId = tonumber(privilegeId) or LUCKY_CARD_PRIVILEGE_TYPE_ID
  local tView = self:GetPrivilegeView(privilegeId)
  return BlackFridayLuckyCardBenefitState.Resolve({
    ready = self:IsReady(),
    view = tView,
    sourceType = BENEFIT_SOURCE_TYPE.Benefit,
    sourceId = benefitId,
    usageKey = usageKey,
    privilegeId = privilegeId,
    sourceData = self:GetBenefit(benefitId, privilegeId),
    businessState = businessState
  })
end

function BlackFridayLuckyCardModule:GetRewardTypeBySourceType(sourceType)
  sourceType = tonumber(sourceType)
  if sourceType == BENEFIT_SOURCE_TYPE.OpenReward then
    return REWARD_TYPE_OPEN
  elseif sourceType == BENEFIT_SOURCE_TYPE.DailyReward then
    return REWARD_TYPE_DAILY
  end
  return nil
end

function BlackFridayLuckyCardModule:GetRelationState(relation, usageKey, businessState, privilegeId)
  privilegeId = tonumber(privilegeId) or LUCKY_CARD_PRIVILEGE_TYPE_ID
  local nSourceType = relation and tonumber(relation.SourceType)
  local nSourceId = relation and tonumber(relation.SourceID)
  if nSourceType == BENEFIT_SOURCE_TYPE.Benefit then
    return self:GetBenefitUseState(nSourceId, usageKey, businessState, privilegeId)
  end
  local nRewardType = self:GetRewardTypeBySourceType(nSourceType)
  return BlackFridayLuckyCardBenefitState.Resolve({
    ready = self:IsReady(),
    view = self:GetPrivilegeView(privilegeId),
    sourceType = nSourceType,
    sourceId = nSourceId,
    privilegeId = privilegeId,
    sourceData = nRewardType and self:GetReward(nRewardType, nSourceId, privilegeId) or nil
  })
end

function BlackFridayLuckyCardModule:GetRewards(rewardType, privilegeTypeId)
  local view = self:GetPrivilegeView(privilegeTypeId or LUCKY_CARD_PRIVILEGE_TYPE_ID)
  if not view then
    return nil
  end
  rewardType = tonumber(rewardType)
  if rewardType == REWARD_TYPE_OPEN then
    return view.open_rewards
  elseif rewardType == REWARD_TYPE_DAILY then
    return view.daily_rewards
  end
  return nil
end

function BlackFridayLuckyCardModule:GetRawReward(rewardType, rewardId, privilegeTypeId)
  for _, reward in pairs(self:GetRewards(rewardType, privilegeTypeId) or {}) do
    if tonumber(reward.id) == tonumber(rewardId) then
      return reward
    end
  end
  return nil
end

function BlackFridayLuckyCardModule:GetReward(rewardType, rewardId, privilegeTypeId)
  privilegeTypeId = privilegeTypeId or LUCKY_CARD_PRIVILEGE_TYPE_ID
  local rewardIds = BlackFridayLuckyCardDisplayConfig.GetRewardSourceIds(rewardType, rewardId, privilegeTypeId)
  local reward = self:GetRawReward(rewardType, rewardId, privilegeTypeId)
  if not reward or #rewardIds <= 1 then
    return reward
  end
  local mergedReward = {}
  for key, value in pairs(reward) do
    mergedReward[key] = value
  end
  mergedReward.reward_items = {}
  mergedReward.status = REWARD_STATUS_RECEIVED
  for _, id in ipairs(rewardIds) do
    local source = self:GetRawReward(rewardType, id, privilegeTypeId)
    if not source then
      return nil
    end
    table.insert(mergedReward.reward_items, source)
    local status = tonumber(source.status)
    if status == REWARD_STATUS_CAN_RECEIVE then
      mergedReward.status = REWARD_STATUS_CAN_RECEIVE
    elseif status ~= REWARD_STATUS_RECEIVED and mergedReward.status ~= REWARD_STATUS_CAN_RECEIVE then
      mergedReward.status = 0
    end
  end
  return mergedReward
end

function BlackFridayLuckyCardModule:HasClaimableRewardForCard(cardId, privilegeTypeId)
  privilegeTypeId = tonumber(privilegeTypeId) or LUCKY_CARD_PRIVILEGE_TYPE_ID
  if not self:IsReady() or not self:HasPrivilege(privilegeTypeId) then
    return false
  end
  local tCard = BlackFridayLuckyCardDisplayConfig.GetActivityCard(cardId)
  if not tCard or tonumber(tCard.PrivilegeTypeID) ~= privilegeTypeId or not BlackFridayLuckyCardDisplayConfig.IsActivityCardVisible(tCard) then
    return false
  end
  for _, tRelation in ipairs(BlackFridayLuckyCardDisplayConfig.GetBenefitRelationsByCard(tCard.CardID)) do
    local nRewardType = self:GetRewardTypeBySourceType(tRelation.SourceType)
    local tReward = nRewardType and self:GetReward(nRewardType, tRelation.SourceID, privilegeTypeId)
    if tReward and tonumber(tReward.status) == REWARD_STATUS_CAN_RECEIVE then
      return true
    end
  end
  return false
end

function BlackFridayLuckyCardModule:HasClaimableRewardForGroup(groupId, privilegeTypeId)
  privilegeTypeId = tonumber(privilegeTypeId) or LUCKY_CARD_PRIVILEGE_TYPE_ID
  if not self:IsReady() or not self:HasPrivilege(privilegeTypeId) then
    return false
  end
  groupId = tonumber(groupId) or 0
  local tCards = BlackFridayLuckyCardDisplayConfig.GetActivityCardsByGroup(groupId, privilegeTypeId)
  for _, tCard in ipairs(tCards) do
    local tRelations = BlackFridayLuckyCardDisplayConfig.GetBenefitRelationsByCard(tCard.CardID)
    for _, tRelation in ipairs(tRelations) do
      if groupId == 0 or tonumber(tRelation.GroupID) == groupId then
        local nSourceType = tonumber(tRelation.SourceType)
        local nRewardType
        if nSourceType == BENEFIT_SOURCE_TYPE.OpenReward then
          nRewardType = REWARD_TYPE_OPEN
        elseif nSourceType == BENEFIT_SOURCE_TYPE.DailyReward then
          nRewardType = REWARD_TYPE_DAILY
        end
        local tReward = nRewardType and self:GetReward(nRewardType, tRelation.SourceID, privilegeTypeId)
        if tReward and tonumber(tReward.status) == REWARD_STATUS_CAN_RECEIVE then
          return true
        end
      end
    end
  end
  return false
end

function BlackFridayLuckyCardModule:HasAnyAward()
  local bHasAward = self:HasClaimableRewardForGroup(0)
  printf("BlackFridayLuckyCardModule:HasAnyAward check main tab reward, ready:%s, owned:%s, hasAward:%s", tostring(self:IsReady()), tostring(self:HasLuckyCard()), tostring(bHasAward))
  return bHasAward
end

function BlackFridayLuckyCardModule:HasData()
  return self._LuckyCardData ~= nil
end

function BlackFridayLuckyCardModule:GetData()
  return self._LuckyCardData
end

function BlackFridayLuckyCardModule:BuyPrivilege(privilegeTypeId, callback)
  privilegeTypeId = tonumber(privilegeTypeId)
  if not privilegeTypeId or self._BuyRequest then
    return false
  end
  local request = {privilegeTypeId = privilegeTypeId, callback = callback}
  self._BuyRequest = request
  local CommercialPrivilegeHandler = require("client.network.Protocol.CommercialPrivilegeHandler")
  CommercialPrivilegeHandler.send_buy_commercial_privilege_req(privilegeTypeId)
  request.timeoutTimer = self:AddTimerOnce(REQUEST_TIMEOUT_SECONDS, function()
    request.timeoutTimer = nil
    if self._BuyRequest == request then
      self._BuyRequest = nil
      SafeCallback(request.callback, false, "timeout", nil, nil)
    end
  end)
  return true
end

function BlackFridayLuckyCardModule:BuyLuckyCard(callback)
  return self:BuyPrivilege(LUCKY_CARD_PRIVILEGE_TYPE_ID, callback)
end

function BlackFridayLuckyCardModule:HandleBuyResult(res, privilegeTypeId, awardList, view)
  if bWriteLog then
    log_tree("BlackFridayLuckyCardModule:HandleBuyResult - awardList = ", awardList)
    log_tree("BlackFridayLuckyCardModule:HandleBuyResult - view = ", view)
    if json and json.encode then
      log("BlackFridayLuckyCardModule:HandleBuyResult - json=" .. json.encode({
        award_list = awardList or {},
        view = view
      }))
    end
  end
  log(bWriteLog and string.format("BlackFridayLuckyCardModule:HandleBuyResult - res=%s privilegeTypeId=%s", tostring(res), tostring(privilegeTypeId)))
  privilegeTypeId = tonumber(privilegeTypeId)
  local request = self._BuyRequest
  local callback
  local matchesRequest = request and (request.privilegeTypeId == privilegeTypeId or res ~= 0 and privilegeTypeId == nil)
  if matchesRequest then
    callback = request.callback
    self:_CancelOperationTimer(request)
    self._BuyRequest = nil
  end
  local onRewardClosed
  if res == 0 and privilegeTypeId == LUCKY_CARD_PRIVILEGE_TYPE_ID and type(callback) == "function" and type(awardList) == "table" and next(awardList) then
    local presentation = {}
    self._BuyRewardPresentation = presentation
    
    function onRewardClosed()
      if self._BuyRewardPresentation ~= presentation then
        return
      end
      self._BuyRewardPresentation = nil
      EventSystem:postEvent(EVENTTYPE_ACTIVITY_BLACK_FRIDAY, EVENTID_ACTIVITY_BLACK_FRIDAY_LUCKY_CARD_ENTRY_UPDATE)
    end
  end
  if res == 0 then
    self:_ApplyView(view, self.EnumUpdateReason.CardBuy)
  else
    self:_HandleOperationFailed(res)
  end
  local bCallbackSuccess = SafeCallback(callback, res == 0, res, awardList, view, onRewardClosed)
  if not bCallbackSuccess and onRewardClosed then
    onRewardClosed()
  end
end

function BlackFridayLuckyCardModule:TakeReward(privilegeTypeId, rewardType, rewardId, callback)
  privilegeTypeId = tonumber(privilegeTypeId)
  rewardType = tonumber(rewardType)
  rewardId = tonumber(rewardId)
  if not (privilegeTypeId and rewardType and rewardId) or self._RewardRequest then
    return false
  end
  self._RewardRequest = {
    privilegeTypeId = privilegeTypeId,
    rewardType = rewardType,
    rewardId = rewardId,
    isTakeAll = false,
    callback = callback
  }
  local request = self._RewardRequest
  local CommercialPrivilegeHandler = require("client.network.Protocol.CommercialPrivilegeHandler")
  CommercialPrivilegeHandler.send_take_commercial_privilege_reward_req(privilegeTypeId, rewardType, rewardId)
  request.timeoutTimer = self:AddTimerOnce(REQUEST_TIMEOUT_SECONDS, function()
    request.timeoutTimer = nil
    if self._RewardRequest == request then
      self._RewardRequest = nil
      SafeCallback(request.callback, false, "timeout", nil, nil)
    end
  end)
  return true
end

function BlackFridayLuckyCardModule:TakeLuckyCardReward(rewardType, rewardId, callback)
  local rewardIds = BlackFridayLuckyCardDisplayConfig.GetRewardSourceIds(rewardType, rewardId, LUCKY_CARD_PRIVILEGE_TYPE_ID)
  if #rewardIds <= 1 then
    return self:TakeReward(LUCKY_CARD_PRIVILEGE_TYPE_ID, rewardType, rewardId, callback)
  end
  if not self:GetReward(rewardType, rewardId) then
    return false
  end
  local claimableIds = {}
  for _, id in ipairs(rewardIds) do
    local reward = self:GetRawReward(rewardType, id)
    if reward and tonumber(reward.status) == REWARD_STATUS_CAN_RECEIVE then
      table.insert(claimableIds, id)
    end
  end
  return self:TakeRewards(LUCKY_CARD_PRIVILEGE_TYPE_ID, rewardType, claimableIds, callback)
end

function BlackFridayLuckyCardModule:TakeRewards(privilegeTypeId, rewardType, rewardIds, callback)
  privilegeTypeId = tonumber(privilegeTypeId)
  rewardType = tonumber(rewardType)
  if not (privilegeTypeId and rewardType) or type(rewardIds) ~= "table" or #rewardIds < 1 or 2 < #rewardIds or self._RewardRequest then
    return false
  end
  local ids, seen = {}, {}
  for _, id in ipairs(rewardIds) do
    id = tonumber(id)
    if not id or id <= 0 or seen[id] then
      return false
    end
    seen[id] = true
    table.insert(ids, id)
  end
  if #ids == 1 then
    return self:TakeReward(privilegeTypeId, rewardType, ids[1], callback)
  end
  local request = {
    privilegeTypeId = privilegeTypeId,
    rewardType = rewardType,
    rewardIds = ids,
    isBatch = true,
    callback = callback
  }
  self._RewardRequest = request
  local handler = require("client.network.Protocol.CommercialPrivilegeHandler")
  handler.send_batch_take_commercial_privilege_reward_req(privilegeTypeId, rewardType, ids)
  request.timeoutTimer = self:AddTimerOnce(REQUEST_TIMEOUT_SECONDS, function()
    request.timeoutTimer = nil
    if self._RewardRequest == request then
      self._RewardRequest = nil
      SafeCallback(request.callback, false, "timeout", nil, nil)
    end
  end)
  return true
end

function BlackFridayLuckyCardModule:HandleTakeRewardResult(res, rewardType, rewardId, awardList, view)
  if bWriteLog then
    log_tree("BlackFridayLuckyCardModule:HandleTakeRewardResult - awardList = ", awardList)
    log_tree("BlackFridayLuckyCardModule:HandleTakeRewardResult - view = ", view)
    if json and json.encode then
      log("BlackFridayLuckyCardModule:HandleTakeRewardResult - json=" .. json.encode({
        award_list = awardList or {},
        view = view
      }))
    end
  end
  log(bWriteLog and string.format("BlackFridayLuckyCardModule:HandleTakeRewardResult - res=%s rewardType=%s rewardId=%s", tostring(res), tostring(rewardType), tostring(rewardId)))
  local request = self._RewardRequest
  local callback
  local matchesRequest = request and not request.isTakeAll and not request.isBatch and (request.rewardType == tonumber(rewardType) and request.rewardId == tonumber(rewardId) or res ~= 0 and rewardType == nil and rewardId == nil)
  if matchesRequest then
    callback = request.callback
    self:_CancelOperationTimer(request)
    self._RewardRequest = nil
  end
  if res == 0 then
    self:_ApplyView(view, "reward")
  else
    self:_HandleOperationFailed(res)
  end
  SafeCallback(callback, res == 0, res, awardList, view)
end

function BlackFridayLuckyCardModule:HandleBatchTakeRewardResult(res, rewardType, rewardIds, awardList, view)
  local request = self._RewardRequest
  local callback
  local matchesRequest = request and request.isBatch and res ~= 0 and rewardType == nil and rewardIds == nil
  if request and request.isBatch and request.rewardType == tonumber(rewardType) and type(rewardIds) == "table" and #rewardIds == #request.rewardIds then
    local expectedIds = {}
    for _, id in ipairs(request.rewardIds) do
      expectedIds[id] = true
    end
    matchesRequest = true
    for _, id in ipairs(rewardIds) do
      id = tonumber(id)
      if not id or not expectedIds[id] then
        matchesRequest = false
        break
      end
      expectedIds[id] = nil
    end
  end
  if matchesRequest then
    callback = request.callback
    self:_CancelOperationTimer(request)
    self._RewardRequest = nil
  end
  if res == 0 then
    self:_ApplyView(view, self.EnumUpdateReason.TakeReward)
  else
    self:_HandleOperationFailed(res)
  end
  SafeCallback(callback, res == 0, res, awardList, view)
end

function BlackFridayLuckyCardModule:TakeAllRewards(privilegeTypeId, callback)
  privilegeTypeId = tonumber(privilegeTypeId)
  if not privilegeTypeId or self._RewardRequest then
    return false
  end
  self._RewardRequest = {
    privilegeTypeId = privilegeTypeId,
    isTakeAll = true,
    callback = callback
  }
  local request = self._RewardRequest
  local CommercialPrivilegeHandler = require("client.network.Protocol.CommercialPrivilegeHandler")
  CommercialPrivilegeHandler.send_take_all_commercial_privilege_reward_req(privilegeTypeId)
  request.timeoutTimer = self:AddTimerOnce(REQUEST_TIMEOUT_SECONDS, function()
    request.timeoutTimer = nil
    if self._RewardRequest == request then
      self._RewardRequest = nil
      SafeCallback(request.callback, false, "timeout", nil, nil)
    end
  end)
  return true
end

function BlackFridayLuckyCardModule:TakeAllLuckyCardRewards(callback)
  return self:TakeAllRewards(LUCKY_CARD_PRIVILEGE_TYPE_ID, callback)
end

function BlackFridayLuckyCardModule:HandleTakeAllRewardResult(res, awardList, view)
  if bWriteLog then
    log_tree("BlackFridayLuckyCardModule:HandleTakeAllRewardResult - awardList = ", awardList)
    log_tree("BlackFridayLuckyCardModule:HandleTakeAllRewardResult - view = ", view)
  end
  log(bWriteLog and string.format("BlackFridayLuckyCardModule:HandleTakeAllRewardResult - res=%s", tostring(res)))
  local request = self._RewardRequest
  local callback
  if request and request.isTakeAll then
    callback = request.callback
    self:_CancelOperationTimer(request)
    self._RewardRequest = nil
  end
  if res == 0 then
    self:_ApplyView(view, self.EnumUpdateReason.TakeAllReward)
  else
    self:_HandleOperationFailed(res)
  end
  SafeCallback(callback, res == 0, res, awardList, view)
end

function BlackFridayLuckyCardModule:ResetData()
  self:_CancelQueryTimers()
  self:_CancelPendingOperations()
  self:DefineAndResetData()
end

function BlackFridayLuckyCardModule:ReportTLog(SubEventName, extraParma)
  local gem_report_utils = require("client.logic.store.gem_report_utils")
  local tlog_report_utils = require("client.slua.config.tlog.tlog_report_utils")
  local reason = extraParma or {}
  reason.event_name = SubEventName
  local TLogReasonStr = json.encode(reason)
  log(bWriteLog and "[SY]BlackFridayLuckyCardModule:ReportTLog." .. SubEventName .. "Reason =" .. TLogReasonStr)
  gem_report_utils.ReportBtnClickEvent(SubEventName, TLogReasonStr)
  tlog_report_utils.ReportTLogEvent(TLogEventDefine.BlackFriday_Click, 0, TLogReasonStr)
end

function BlackFridayLuckyCardModule:IsShowCommonEntry(activityID, cardID)
  local BlackFridayMacros = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.BlackFridayMacros")
  local BlackFridayMainModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayMainModule)
  local ActType = BlackFridayMacros.ActivityType
  local result = BlackFridayMainModule:GetActivityConfig(ActType.LuckyCard)
  if not result or not next(result) then
    return false
  end
  local allCardConfig
  cardID = tonumber(cardID)
  if cardID then
    allCardConfig = BlackFridayLuckyCardDisplayConfig.GetActivityCard(cardID)
  else
    allCardConfig = BlackFridayLuckyCardDisplayConfig.GetActivityCardByActivityID(activityID)
  end
  if allCardConfig then
    return BlackFridayLuckyCardDisplayConfig.GetActivityCardTimeState(allCardConfig) ~= BlackFridayLuckyCardDisplayConfig.CardTimeState.Upcoming
  end
  return false
end

function BlackFridayLuckyCardModule:IsBuyRewardPresentationPending()
  return self._BuyRewardPresentation ~= nil
end

function BlackFridayLuckyCardModule:IsCommonEntryAnimCanShow(activityID)
  return not self:IsBuyRewardPresentationPending() and self:HasLuckyCard() and not self.entryAnimRecord[activityID]
end

function BlackFridayLuckyCardModule:SaveAnimCanShowRecord(activityID)
  self.entryAnimRecord[activityID] = true
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  PlayerPrefsSystem.SaveTableToFile_N(self.entryAnimRecord, PlayerPrefsSystem.ePlayerPrefsType.eBlackFridayCardEnterAnim)
end

local class = require("class")
local CModuleBase = require("client.module_framework.ModuleBase")
local CBlackFridayLuckyCardModule = class(CModuleBase, nil, BlackFridayLuckyCardModule)
return CBlackFridayLuckyCardModule
