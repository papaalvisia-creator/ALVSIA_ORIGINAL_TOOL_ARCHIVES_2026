local BlackFridayPassModule = {
  RedEnumPath = {
    New = "/Game/UMG/UI_Logic/Reddot/Reddot_Anchor_Item05.Reddot_Anchor_Item05",
    Reward = "/Game/UMG/UI_Logic/Reddot/Reddot_Anchor_Item03.Reddot_Anchor_Item03"
  },
  Enum_Task = {
    Daily = 0,
    Limit = 1,
    Cost = 2
  }
}

function BlackFridayPassModule:RegistEvents()
  self:AddCommonEvent(EVENTTYPE_DATA_MGR, EVNETID_DATAMGR_ACTIVITY_CHANGE, self.OnActivityDataChanged, self)
  self:AddCommonEvent(EVENTTYPE_NEXTDAY, EVENTID_NEXTDAY_ZERO, self.OnNextDayUpdate, self)
end

function BlackFridayPassModule:OnActivityDataChanged(_, __, changeList)
  local isNeedRefreshRed = false
  local typeList = changeList.typeList
  if typeList and typeList[ActivityType.BlackFriday_Pass] then
    isNeedRefreshRed = true
  end
  local idList = changeList.idList
  if idList then
    for id, _ in pairs(idList) do
      if self:IsPassActId(id) then
        isNeedRefreshRed = true
        break
      end
    end
  end
  if isNeedRefreshRed then
    local BlackFridayMacros = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.BlackFridayMacros")
    local BlackFridayRedDotModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayRedDotModule)
    BlackFridayRedDotModule:UpdateDirectRedDot(BlackFridayMacros.ActivityType.Pass)
  end
end

function BlackFridayPassModule:OnNextDayUpdate()
  self:CheckAndSendActivity()
end

function BlackFridayPassModule:DefineAndResetData()
  self.Info = nil
  self.ExtraAwardItemID = nil
  self.PerExtraAwardScore = nil
  self.ProgressList = nil
  self.BigRewardPreviewList = nil
  self.BigRewardPreviewMap = nil
  self.CostTabInfo = nil
  self.LimitTabInfo = nil
  self.ActIdMap = nil
  self.ActIdList = nil
  self.BigAwardIndex = nil
  self.BigAwardItemID = nil
  self.JKProbList = nil
  self.JKBonusProbList = nil
  self.isCheckNewRed = nil
  self.isHaveNotStartEvent = false
end

function BlackFridayPassModule:HandlePresetData(presetData)
  self.ExtraAwardItemID = presetData.ext_score_drop_id
  self.PerExtraAwardScore = presetData.ext_per_score
  if not self.ActIdMap then
    self.ActIdMap = {}
  end
  if not self.ActIdList then
    self.ActIdList = {}
  end
  for i = 1, 4 do
    local name = "black_friday_pass_act_father_id_" .. i
    local actId = presetData[name]
    if actId then
      self.ActIdMap[actId] = true
      table.insert(self.ActIdList, actId)
    end
  end
  self:CheckAndSendActivity()
end

function BlackFridayPassModule:CheckAndSendActivity()
  local BlackFridayMacros = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.BlackFridayMacros")
  local BlackFridayMainModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayMainModule)
  local ActType = BlackFridayMacros.ActivityType
  local tabData, index = BlackFridayMainModule:GetActivityConfig(ActType.Pass)
  if tabData then
    local BlackFridayHandler = require("client.network.Protocol.BlackFridayHandler")
    BlackFridayHandler.send_black_friday_get_pass_info_req()
  end
end

function BlackFridayPassModule:DestroyPassInfo()
end

function BlackFridayPassModule:PreviewBigAward(defaultItemID, ScoreLevel)
  local ItemID = defaultItemID
  UIManager.ShowUI(UIManager.UI_Config.BlackFriday_Pass_Award_UIBP, ItemID, ScoreLevel)
end

function BlackFridayPassModule:GetPassInfo()
  return self.Info
end

function BlackFridayPassModule:GetDailyActData()
  local actData
  if not self.ActIdList then
    return actData
  end
  for _, actId in ipairs(self.ActIdList) do
    local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
    actData = ActivityNewSystem.GetActivityByID(actId)
    if actData then
      break
    end
  end
  return actData
end

function BlackFridayPassModule:GetRewarData()
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local actData = ActivityNewSystem.GetActivityByType(ActivityType.BlackFriday_Pass)
  if not actData then
    return {}, {}
  end
  local TableUtil = require("common.table_util")
  local otherData = TableUtil.GetTableValue(actData, "other")
  return otherData and otherData.reward_status_list or {}, otherData and otherData.advance_reward_status_list or {}
end

function BlackFridayPassModule:GetCostTaskData()
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local actData = ActivityNewSystem.GetActivityByType(ActivityType.BlackFriday_Pass)
  if not actData then
    return {}
  end
  local TableUtil = require("common.table_util")
  local otherData = TableUtil.GetTableValue(actData, "other")
  return otherData and otherData.cost_effective_module_task_info or {}
end

function BlackFridayPassModule:GetCostTaskDataByTaskID(taskID)
  local data = self:GetCostTaskData()
  if data and data.task_list and data.task_list[taskID] then
    return data.task_list[taskID]
  end
end

function BlackFridayPassModule:GetCostTabData()
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local actData = ActivityNewSystem.GetActivityByType(ActivityType.BlackFriday_Pass)
  if not actData then
    return {}
  end
  local TableUtil = require("common.table_util")
  local otherData = TableUtil.GetTableValue(actData, "other")
  return otherData and otherData.cost_effective_module_conf_info or {}
end

function BlackFridayPassModule:GetCostTabInfoByModuleID(moduleID)
  local tabInfo = self:GetCostTabInfo()
  if tabInfo and tabInfo[moduleID] then
    return tabInfo[moduleID]
  end
end

function BlackFridayPassModule:GetCostTabList()
  if not self.CostTabInfo or not next(self.CostTabInfo) then
    return
  end
  return self:_CreateTabList(self.CostTabInfo, self.Enum_Task.Cost)
end

function BlackFridayPassModule:IsHaveCostModule(moduleID)
  if not self.CostTabInfo or not next(self.CostTabInfo) then
    return false
  end
  return self.CostTabInfo[moduleID] ~= nil
end

function BlackFridayPassModule:GetLimitTaskData()
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local actData = ActivityNewSystem.GetActivityByType(ActivityType.BlackFriday_Pass)
  if not actData then
    return {}
  end
  local TableUtil = require("common.table_util")
  local otherData = TableUtil.GetTableValue(actData, "other")
  return otherData and otherData.limit_module_task_info or {}
end

function BlackFridayPassModule:GetLimitTaskDataByTaskID(taskID)
  local data = self:GetLimitTaskData()
  if data and data.task_list and data.task_list[taskID] then
    return data.task_list[taskID]
  end
end

function BlackFridayPassModule:GetLimitTabData()
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local actData = ActivityNewSystem.GetActivityByType(ActivityType.BlackFriday_Pass)
  if not actData then
    return {}
  end
  local TableUtil = require("common.table_util")
  local otherData = TableUtil.GetTableValue(actData, "other")
  return otherData and otherData.limit_module_conf_info or {}
end

function BlackFridayPassModule:GetLimitTabInfoByModuleID(moduleID)
  local tabInfo = self:GetLimitTabInfo()
  if tabInfo and tabInfo[moduleID] then
    return tabInfo[moduleID]
  end
end

function BlackFridayPassModule:GetLimitTabInfo()
  if not self.Info then
    return false
  end
  return self.LimitTabInfo
end

function BlackFridayPassModule:GetLimitTabList()
  if not self.LimitTabInfo or not next(self.LimitTabInfo) then
    return
  end
  return self:_CreateTabList(self.LimitTabInfo, self.Enum_Task.Limit)
end

function BlackFridayPassModule:GetCostTabInfo()
  if not self.Info then
    return false
  end
  return self.CostTabInfo
end

function BlackFridayPassModule:GetModuleScoreInfo(moduleID)
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local actData = ActivityNewSystem.GetActivityByType(ActivityType.BlackFriday_Pass)
  if not actData then
    return {}
  end
  local TableUtil = require("common.table_util")
  local module_score_info = TableUtil.GetTableValue(actData, "other", "module_score_info")
  return module_score_info and module_score_info[moduleID] or 0
end

function BlackFridayPassModule:_CreateTabList(tabInfo, module_type)
  if not tabInfo or not next(tabInfo) then
    return {}
  end
  local tabList = {}
  local moduleRedType = {}
  local time_util = require("client.common.time_util")
  local curTime = time_util.GetServerTimeInSec()
  for i, info in pairs(tabInfo) do
    table.insert(tabList, info)
    local isHaveReward, isAllDone
    isHaveReward, isAllDone = self:CheckTaskModeHaveReward(info.module_id, module_type, true)
    local isNew = self:GetModuleTabNewRedData(info.module_id)
    local isExpire = curTime >= info.endTime
    moduleRedType[info.module_id] = {
      isNew = isNew,
      isHaveReward = isHaveReward,
      isExpire = isExpire,
      isAllDone = isAllDone
    }
  end
  self:SaveAllTabNewRedData()
  table.sort(tabList, function(a, b)
    local redDataA = moduleRedType[a.module_id]
    local redDataB = moduleRedType[b.module_id]
    if redDataA.isHaveReward ~= redDataB.isHaveReward then
      return redDataA.isHaveReward
    end
    if redDataA.isNew ~= redDataB.isNew then
      return redDataA.isNew
    end
    if (redDataA.isAllDone or redDataA.isExpire) ~= (redDataB.isAllDone or redDataB.isExpire) then
      return redDataB.isAllDone or redDataB.isExpire
    end
    return a.tabInfo.sort_weight < b.tabInfo.sort_weight
  end)
  return tabList
end

function BlackFridayPassModule:GetCyberScore()
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local actData = ActivityNewSystem.GetActivityByType(ActivityType.BlackFriday_Pass)
  if not actData then
    return 0
  end
  local TableUtil = require("common.table_util")
  local otherData = TableUtil.GetTableValue(actData, "other")
  return otherData and otherData.current_score or 0
end

function BlackFridayPassModule:GetNextBigAwardIndex(index)
  local progressList = self:GetProgressList()
  if not progressList or not next(progressList) then
    return 0
  end
  index = index or 1
  for i = index, #progressList do
    local info = progressList[i]
    if info.originInfo.is_big_reward == 1 then
      self.BigAwardIndex = i
    end
  end
  return self.BigAwardIndex or 0
end

function BlackFridayPassModule:GetBigAwardItemID(index)
end

function BlackFridayPassModule:GetExtraAwardItemID()
  return self.ExtraAwardItemID
end

function BlackFridayPassModule:GetExtraAwardCount()
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local actData = ActivityNewSystem.GetActivityByType(ActivityType.BlackFriday_Pass)
  if not actData then
    return 0
  end
  local TableUtil = require("common.table_util")
  local otherData = TableUtil.GetTableValue(actData, "other")
  return otherData and otherData.extra_chest_num or 0
end

function BlackFridayPassModule:GetModuleHaveActList()
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local actData = ActivityNewSystem.GetActivityByType(ActivityType.BlackFriday_Pass)
  if not actData then
    return {}
  end
  local TableUtil = require("common.table_util")
  local otherData = TableUtil.GetTableValue(actData, "other", "module_act_list") or {}
  return otherData
end

function BlackFridayPassModule:GetCyberScoreRatio()
  if not self.ProgressList then
    return 0, self.PerExtraAwardScore
  end
  local cyberScore = self:GetCyberScore()
  local LastNode = self.ProgressList[#self.ProgressList]
  local lowerScore = LastNode.scoreLevel
  if cyberScore < lowerScore then
    return 0, self.PerExtraAwardScore
  end
  local flowScore = (cyberScore - lowerScore) % self.PerExtraAwardScore
  return flowScore, self.PerExtraAwardScore
end

function BlackFridayPassModule:GetProgressList()
  return self.ProgressList
end

function BlackFridayPassModule:GetBigRewardPreviewMap()
  return self.BigRewardPreviewMap
end

function BlackFridayPassModule:GetIsHaveNotStartEvent()
  return self.isHaveNotStartEvent
end

function BlackFridayPassModule:HandleProgressList()
  if not self.Info then
    return
  end
  self.ProgressList = {}
  self.BigRewardPreviewMap = {}
  local commonReward = self.Info.score_level_reward_list
  local advanceReward = self.Info.score_advance_level_reward_list
  if not commonReward or not next(commonReward) then
    return
  end
  for scoreLevel, rewardInfo in pairs(commonReward) do
    local advanceRewardInfo = advanceReward[scoreLevel]
    table.insert(self.ProgressList, {
      scoreLevel = scoreLevel,
      originInfo = rewardInfo,
      advanceInfo = advanceReward[scoreLevel]
    })
    if rewardInfo.is_big_reward == 1 or advanceRewardInfo and advanceRewardInfo.is_big_reward == 1 then
      self.BigRewardPreviewMap[scoreLevel] = {
        scoreLevel = scoreLevel,
        normalItemList = rewardInfo.item_list,
        advanceNumberList = advanceRewardInfo and advanceRewardInfo.item_list
      }
    end
  end
  table.sort(self.ProgressList, function(a, b)
    return a.scoreLevel < b.scoreLevel
  end)
  local length = #self.ProgressList
  for index, progressInfo in ipairs(self.ProgressList) do
    if index < length then
      progressInfo.nextScoreLevel = self.ProgressList[index + 1].scoreLevel
    else
      progressInfo.nextScoreLevel = progressInfo.scoreLevel + self.PerExtraAwardScore
    end
    if 1 < index then
      progressInfo.lastScoreLevel = self.ProgressList[index - 1].scoreLevel
    else
      progressInfo.lastScoreLevel = 0
    end
  end
end

function BlackFridayPassModule:HandleTaskTab()
  if not self.Info then
    return
  end
  local costInfo = self.Info.cost_effective_module_conf_info
  local costTask = self.Info.cost_effective_task_info
  local limitInfo = self.Info.limit_module_conf_info
  local limitTask = self.Info.limit_task_info
  self.isHaveNotStartEvent = false
  self.CostTabInfo = self:_CreateTabInfo(costInfo, costTask, true)
  self.LimitTabInfo = self:_CreateTabInfo(limitInfo, limitTask)
end

function BlackFridayPassModule:IsJapanOrKoreaThreeStarPackage()
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  local AOSSHOPMacros = require("client.slua.config.ClientMacros.AOSSHOPMacros")
  local nAOSSHOP = Client.GetAOSSHOP()
  if nAOSSHOP == AOSSHOPMacros.Samsung and PublishRegionMacros.IsJapanOrKorea() then
    return true
  end
  return false
end

function BlackFridayPassModule:IsSamsung()
  local AOSSHOPMacros = require("client.slua.config.ClientMacros.AOSSHOPMacros")
  local nAOSSHOP = Client.GetAOSSHOP()
  return nAOSSHOP == AOSSHOPMacros.Samsung
end

function BlackFridayPassModule:_CreateTabInfo(moduleConfig, taskConfig, isCost)
  local TabInfo = {}
  for moduleID, v in pairs(moduleConfig) do
    local TimeUtil = require("client.common.time_util")
    local startTime = TimeUtil.TimeStringToUnixstamp(v.start_time)
    local endTime = TimeUtil.TimeStringToUnixstamp(v.end_time)
    TabInfo[moduleID] = {
      tabInfo = v,
      module_id = moduleID,
      startTime = startTime,
      endTime = endTime
    }
  end
  for taskID, taskData in pairs(taskConfig) do
    taskData.task_id = taskID
    local tabInfo = TabInfo[taskData.module_id]
    if tabInfo then
      if not tabInfo.taskMap then
        tabInfo.taskMap = {}
      end
      tabInfo.taskMap[taskID] = taskData
    end
  end
  local time_util = require("client.common.time_util")
  local StringUtil = require("common.string_util")
  local curTime = time_util.GetServerTimeInSec()
  local needRemoveTab = {}
  local moduleActList = self:GetModuleHaveActList()
  local isJpSamsung = self:IsJapanOrKoreaThreeStarPackage()
  local isSamsung = self:IsSamsung()
  for id, tabInfo in pairs(TabInfo) do
    local isHaveActivity = true
    local isNotStart = curTime < tabInfo.startTime
    local isEnd = curTime > tabInfo.endTime
    if isNotStart then
      if isCost then
        self.isHaveNotStartEvent = true
      end
      isHaveActivity = false
    elseif isJpSamsung and tabInfo.tabInfo.is_prime_flag then
      isHaveActivity = false
    elseif isSamsung and tabInfo.tabInfo.is_samsung_block and tabInfo.tabInfo.is_samsung_block > 0 then
      isHaveActivity = false
    elseif tabInfo.taskMap and next(tabInfo.taskMap) then
      local moduleActData = moduleActList[tabInfo.module_id]
      for _, taskInfo in pairs(tabInfo.taskMap) do
        if taskInfo.finish_type == 1 or taskInfo.finish_type == 2 then
          local urlList = StringUtil.Split(taskInfo.jump_url, "|")
          if urlList and 1 < #urlList then
            local isUrlHaveActivity = false
            for _, v in pairs(urlList) do
              local webModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.webModule)
              local tempUrl = webModule:URLDecode(v)
              tempUrl = GlobalData.PreprocessUrl(tempUrl)
              local params = StringUtil.ParseURLParams(tempUrl)
              if params.activityid and params.activityid ~= "" then
                local activityID = tonumber(params.activityid)
                if activityID and moduleActData and moduleActData[activityID] then
                  isUrlHaveActivity = true
                  break
                end
              end
            end
            if isUrlHaveActivity then
              isHaveActivity = true
              break
            else
              isHaveActivity = false
            end
          end
        end
      end
    else
      log(bWriteLog and "[SY]BlackFridayPassModule:_CreateTabInfo.taskMap is empty")
      log_tree("TabInfo Data", tabInfo)
    end
    if not isHaveActivity then
      table.insert(needRemoveTab, id)
    end
  end
  if next(needRemoveTab) then
    for i, v in pairs(needRemoveTab) do
      TabInfo[v] = nil
    end
  end
  return TabInfo
end

function BlackFridayPassModule:HandleJKBonusProp()
  if not self.ProgressList or not next(self.ProgressList) then
    return
  end
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  if not PublishRegionMacros.IsJapanOrKorea() then
    return
  end
  self.JKBonusProbList = {}
  local ItemInfo
  for _, progressInfo in ipairs(self.ProgressList) do
    if progressInfo.originInfo.has_bonus == true then
      ItemInfo = progressInfo
      break
    end
  end
  if not ItemInfo then
    return
  end
  for times, weight in pairs(ItemInfo.originInfo.bonus_factor) do
    table.insert(self.JKBonusProbList, {times = times, weight = weight})
  end
  table.sort(self.JKBonusProbList, function(a, b)
    return a.times < b.times
  end)
end

function BlackFridayPassModule:GetScoreLevelStatus(scoreLevel)
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local actData = ActivityNewSystem.GetActivityByType(ActivityType.BlackFriday_Pass)
  if not actData then
    return 0
  end
  local TableUtil = require("common.table_util")
  local otherData = TableUtil.GetTableValue(actData, "other")
  local statusInfo = TableUtil.GetTableValue(otherData, "reward_status_list", scoreLevel)
  local advanceStatusInfo = TableUtil.GetTableValue(otherData, "advance_reward_status_list", scoreLevel)
  return statusInfo and statusInfo.status or 0, advanceStatusInfo and advanceStatusInfo.status or 0
end

function BlackFridayPassModule:IsScoreLevelBigReward(scoreLevel)
  if not self.Info then
    return false
  end
  local normal = self.Info.score_level_reward_list[scoreLevel]
  local advance = self.Info.score_advance_level_reward_list[scoreLevel]
  return normal and normal.is_big_reward == 1 or advance and advance.is_big_reward == 1
end

function BlackFridayPassModule:GetAdvanceScoreLevelStatus(scoreLevel)
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local actData = ActivityNewSystem.GetActivityByType(ActivityType.BlackFriday_Pass)
  if not actData then
    return 0
  end
  local TableUtil = require("common.table_util")
  local otherData = TableUtil.GetTableValue(actData, "other")
  local statusInfo = otherData.advance_reward_status_list[scoreLevel]
  return statusInfo and statusInfo.status or 0
end

function BlackFridayPassModule:IsAdvanceScoreLevelBigReward(scoreLevel)
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local actData = ActivityNewSystem.GetActivityByType(ActivityType.BlackFriday_Pass)
  if not actData then
    return false
  end
  local TableUtil = require("common.table_util")
  local otherData = TableUtil.GetTableValue(actData, "other")
  local statusInfo = otherData.advance_reward_status_list[scoreLevel]
  return statusInfo and statusInfo.is_big_reward == 1
end

function BlackFridayPassModule:IsPassActId(actId)
  if not self.ActIdMap then
    return false
  end
  return self.ActIdMap[actId]
end

function BlackFridayPassModule:DestroyJKBigAwardProp()
  self.JKProbList = nil
  self.BigAwardItemID = nil
end

function BlackFridayPassModule:GetJKBigAwardPropList()
  return self.JKProbList
end

function BlackFridayPassModule:GetOrReqJKBigAwardProp()
  if not self.JKProbList then
    local ChestId = self:GetExtraAwardItemID()
    local BasicDataProbabilityTable = require("client.slua.data.BasicData.BasicDataRealtimeProbabilityTable")
    BasicDataProbabilityTable:OnSendReqMsg(ChestId, BasicDataProbabilityTable.moduleType.black_friday_pass_chest)
  else
    EventSystem:postEvent(EVENTTYPE_ACTIVITY_BLACK_FRIDAY, EVENTID_ACTIVITY_BLACK_FRIDAY_PASS_JK_PROP_UPDATED)
  end
end

function BlackFridayPassModule:GetJKBonusProbList()
  return self.JKBonusProbList
end

function BlackFridayPassModule:GetBigAwardRecord(scoreLevel)
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local actData = ActivityNewSystem.GetActivityByType(ActivityType.BlackFriday_Pass)
  if not actData then
    return nil
  end
  local TableUtil = require("common.table_util")
  local otherData = TableUtil.GetTableValue(actData, "other")
  if not otherData or not otherData.award_record then
    return nil
  end
  return otherData.award_record[scoreLevel]
end

function BlackFridayPassModule:IsPassExtraBox(itemId)
  if not itemId then
    return false
  end
  return itemId == 1529913 or itemId == 1529915 or itemId == 1529848
end

function BlackFridayPassModule:on_black_friday_get_pass_info_rsp(err_code, info)
  log(bWriteLog and "[SY]BlackFridayPassModule:on_black_friday_get_pass_info_rsp.")
  self.Info = info
  if not self.isCheckNewRed then
    local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
    local data = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eBlackFridayPassReddotRecord) or {}
    self.isCheckNewRed = data
  end
  self:HandleProgressList()
  self:HandleTaskTab()
  self:UpdatePassRedDot()
  EventSystem:postEvent(EVENTTYPE_ACTIVITY_BLACK_FRIDAY, EVENTID_ACTIVITY_BLACK_FRIDAY_PASS_INFO_UPDATED)
end

function BlackFridayPassModule:on_black_friday_get_score_reward_rsp(err_code, info)
  local BlackFridayPopupUtil = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.BlackFridayPopupUtil")
  local Logic_CommonItemGet = require("client.slua.logic.common.CommonItemGet.Logic_CommonItemGet")
  Logic_CommonItemGet.ShowPanel_DefaultStyle(info.item_list)
  EventSystem:postEvent(EVENTTYPE_ACTIVITY_BLACK_FRIDAY, EVENTID_ACTIVITY_BLACK_FRIDAY_PASS_AWARD_UPDATED, info)
  self:UpdatePassRedDot()
end

function BlackFridayPassModule:on_black_friday_get_pass_extra_chest_rsp(err_code, info)
  local BlackFridayPopupUtil = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.BlackFridayPopupUtil")
  local Logic_CommonItemGet = require("client.slua.logic.common.CommonItemGet.Logic_CommonItemGet")
  Logic_CommonItemGet.ShowPanel_DefaultStyle(info.item_list)
  EventSystem:postEvent(EVENTTYPE_ACTIVITY_BLACK_FRIDAY, EVENTID_ACTIVITY_BLACK_FRIDAY_PASS_EXTRA_AWARD_UPDATED)
  self:UpdatePassRedDot()
end

function BlackFridayPassModule:OnTakeActAward(item_list)
  local Logic_CommonItemGet = require("client.slua.logic.common.CommonItemGet.Logic_CommonItemGet")
  local BlackFridayPopupUtil = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.BlackFridayPopupUtil")
  Logic_CommonItemGet.ShowPanel_DefaultStyle(item_list)
  self:UpdatePassRedDot()
end

function BlackFridayPassModule:on_get_realtime_probability_rsp(probability_list, chest_id, module_type, sub_module_type)
  self.JKProbList = probability_list
  EventSystem:postEvent(EVENTTYPE_ACTIVITY_BLACK_FRIDAY, EVENTID_ACTIVITY_BLACK_FRIDAY_PASS_JK_PROP_UPDATED)
end

function BlackFridayPassModule:on_black_friday_get_pass_task_reward_rsp(ret_info)
  local Logic_CommonItemGet = require("client.slua.logic.common.CommonItemGet.Logic_CommonItemGet")
  Logic_CommonItemGet.ShowPanel_DefaultStyle(ret_info.item_list)
  self:UpdatePassRedDot()
  EventSystem:postEvent(EVENTTYPE_ACTIVITY_BLACK_FRIDAY, EVENTID_ACTIVITY_BLACK_FRIDAY_LIMIT_TASK_GET)
end

function BlackFridayPassModule:HasAnyAward()
  local extraAwardCount = self:GetExtraAwardCount()
  if 0 < extraAwardCount then
    return true
  end
  if not self.ActIdMap then
    return false
  end
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  for actId, _ in pairs(self.ActIdMap) do
    local actData = ActivityNewSystem.GetActivityByID(actId)
    if actData then
      for _, subActivity in ipairs(actData.List) do
        if subActivity.Status == ActivityProgressStatus.Done then
          return true
        end
      end
    end
  end
  local actData = ActivityNewSystem.GetActivityByType(ActivityType.BlackFriday_Pass)
  if not actData then
    return false
  end
  local TableUtil = require("common.table_util")
  local otherData = TableUtil.GetTableValue(actData, "other")
  local reward_status_list = otherData.reward_status_list
  if not reward_status_list then
    return false
  end
  if reward_status_list then
    for _, statusInfo in pairs(reward_status_list) do
      if statusInfo.status == ActivityProgressStatus.Done then
        return true
      end
    end
  end
  local LuckyCardModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule)
  if LuckyCardModule:HasLuckyCard() then
    local advance_reward_status_list = otherData.advance_reward_status_list
    if advance_reward_status_list then
      for _, statusInfo in pairs(advance_reward_status_list) do
        if statusInfo.status == ActivityProgressStatus.Done then
          return true
        end
      end
    end
  end
  local limit_module_task_info = otherData.limit_module_task_info
  if limit_module_task_info and next(limit_module_task_info.task_list) then
    for _, statusInfo in pairs(limit_module_task_info.task_list) do
      if statusInfo.status == ActivityProgressStatus.Done and self:GetLimitTabInfoByModuleID(statusInfo.module_id) ~= nil then
        return true
      end
    end
  end
  local cost_effective_module_task_info = otherData.cost_effective_module_task_info
  if cost_effective_module_task_info then
    for _, statusInfo in pairs(cost_effective_module_task_info.task_list) do
      if statusInfo.status == ActivityProgressStatus.Done and self:GetCostTabInfoByModuleID(statusInfo.module_id) ~= nil then
        return true
      end
    end
  end
  return false
end

function BlackFridayPassModule:CheckTaskModeHaveReward(module_id, tabType, dontSaveRed)
  local tabInfo
  if tabType == self.Enum_Task.Cost then
    tabInfo = self:GetCostTabInfoByModuleID(module_id)
  elseif tabType == self.Enum_Task.Limit then
    tabInfo = self:GetLimitTabInfoByModuleID(module_id)
  end
  local isHaveReward = false
  local isAllDone = true
  local index = 0
  if tabInfo and tabInfo.taskMap and next(tabInfo.taskMap) then
    for _, task in pairs(tabInfo.taskMap) do
      local taskData
      if tabType == self.Enum_Task.Cost then
        taskData = BlackFridayPassModule:GetCostTaskDataByTaskID(task.task_id)
      elseif tabType == self.Enum_Task.Limit then
        taskData = BlackFridayPassModule:GetLimitTaskDataByTaskID(task.task_id)
      end
      if taskData then
        if taskData.status == ActivityProgressStatus.Done then
          isHaveReward = true
          isAllDone = false
          index = index + 1
        elseif taskData.status ~= ActivityProgressStatus.Get then
          isAllDone = false
          index = index + 1
        end
      else
        isAllDone = false
      end
    end
  end
  if not dontSaveRed and (isAllDone or isHaveReward) then
    self:SaveModuleTabNewRedData(module_id)
  end
  return isHaveReward, isAllDone, index
end

function BlackFridayPassModule:UpdatePassRedDot()
  local BlackFridayMacros = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.BlackFridayMacros")
  local BlackFridayRedDotModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayRedDotModule)
  BlackFridayRedDotModule:UpdateDirectRedDot(BlackFridayMacros.ActivityType.Pass)
end

function BlackFridayPassModule:GetModuleTabNewRedData(module_id)
  return self.isCheckNewRed[module_id] == nil or self.isCheckNewRed[module_id] == false
end

function BlackFridayPassModule:SaveAllTabNewRedData()
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  PlayerPrefsSystem.SaveTableToFile_N(self.isCheckNewRed, PlayerPrefsSystem.ePlayerPrefsType.eBlackFridayPassReddotRecord)
  BlackFridayPassModule:UpdatePassRedDot()
end

function BlackFridayPassModule:SaveModuleTabNewRedData(module_id)
  if not self.isCheckNewRed[module_id] then
    self.isCheckNewRed[module_id] = true
    local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
    PlayerPrefsSystem.SaveTableToFile_N(self.isCheckNewRed, PlayerPrefsSystem.ePlayerPrefsType.eBlackFridayPassReddotRecord)
    EventSystem:postEvent(EVENTTYPE_ACTIVITY_BLACK_FRIDAY, EVENTID_ACTIVITY_BLACK_FRIDAY_PASS_UI_REDUPDATE)
    BlackFridayPassModule:UpdatePassRedDot()
  end
end

function BlackFridayPassModule:ReportTLog(SubEventName, extraParma)
  local gem_report_utils = require("client.logic.store.gem_report_utils")
  local tlog_report_utils = require("client.slua.config.tlog.tlog_report_utils")
  local reason = extraParma or {}
  reason.event_name = SubEventName
  reason.point = BlackFridayPassModule:GetCyberScore()
  local TLogReasonStr = json.encode(reason)
  log(bWriteLog and "[SY]BlackFridayPassModule:ReportTLog." .. SubEventName .. "Reason =" .. TLogReasonStr)
  gem_report_utils.ReportBtnClickEvent(SubEventName, TLogReasonStr)
  tlog_report_utils.ReportTLogEvent(TLogEventDefine.BlackFriday_Click, 0, TLogReasonStr)
end

local class = require("class")
local CModuleBase = require("client.module_framework.ModuleBase")
local CBlackFridayPassModule = class(CModuleBase, nil, BlackFridayPassModule)
return CBlackFridayPassModule
