local ModeSelection_Sideber_Leaderboard_UIBP = {}
local RankConfig = require("client.slua.logic.rank.rank_config")
local RankSystem = require("client.slua.logic.rank.logic_rank")
local RankDataMgr = RankSystem.RankDataMgr
local RankNetHandler = RankSystem.RankNetHandler
local RankSelectEnum = RankConfig.RankSelectEnum
local RegionEnum = RankConfig.RegionEnum
local MemberEnum = RankConfig.MemberEnum
local mode_selection_category_utils = require("GameLua.Mod.Lobby.Split.ModeSelection470.logic.mode_selection_category_utils")
local Category = mode_selection_category_utils.Category
local player_info = require("GameLua.Mod.Lobby.Split.ModeSelection470.logic.mode_selection470_sideber_player_info")
local RANK_TOP3_IMAGE = {
  [1] = "/Game/UMG/Texture/Atlas/RankUI/Frames/Rank_Index_1_png.Rank_Index_1_png",
  [2] = "/Game/UMG/Texture/Atlas/RankUI/Frames/Rank_Index_2_png.Rank_Index_2_png",
  [3] = "/Game/UMG/Texture/Atlas/RankUI/Frames/Rank_Index_3_png.Rank_Index_3_png"
}
local RANK_TAB_CONFIG = {
  {
    locID = 102100,
    tpp = RankSelectEnum.sum,
    fpp = RankSelectEnum.fpp_sum
  },
  {
    locID = 102101,
    tpp = RankSelectEnum.win,
    fpp = RankSelectEnum.fpp_win
  },
  {
    locID = 102102,
    tpp = RankSelectEnum.beat,
    fpp = RankSelectEnum.fpp_beat
  },
  {
    locID = 102103,
    tpp = RankSelectEnum.total,
    fpp = RankSelectEnum.fpp_total
  }
}
local PEAK_RANK_TAB_CONFIG = {
  {
    locID = 102100,
    rankType = RankSelectEnum.peak
  },
  {
    locID = 615,
    rankType = RankSelectEnum.peakgame_kd
  },
  {
    locID = 613,
    rankType = RankSelectEnum.peakgame_win
  }
}
local LOC_ID_NO_RANK = 102127
local SWITCHER_INDEX_DEFAULT = 0
local SWITCHER_INDEX_SELECTED = 1
local SWITCHER_STATUS_LIST = 0
local SWITCHER_STATUS_EMPTY = 1

function ModeSelection_Sideber_Leaderboard_UIBP:ctor(_, data)
  self.data = data
  self._bPeak = mode_selection_category_utils.IsCategory(data, Category.Peak)
  self._rankTabConfig = self._bPeak and PEAK_RANK_TAB_CONFIG or RANK_TAB_CONFIG
  self._rankTabIndex = 1
  self._regionType = RegionEnum.friend
  self._teamCnt = 4
  self._isFpp = false
  self._bInitDone = false
  self._bFirstShow = true
end

function ModeSelection_Sideber_Leaderboard_UIBP:OnInitialize()
  self.LoopScrollBox_Ranking = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_Ranking, "GameLua.Mod.Lobby.Split.ModeSelection470.umg.Sideber.Item.ModeSelection_Sideber_Leaderboard_Item_UIBP")
  self.Common_ComboBox_RankType = self:InitCommonComboBoxNew(self.UIRoot.Common_ComboBox_WoW)
  self:SetWidgetVisible(self.Common_ComboBox_RankType, true)
  self.UIRoot.WidgetSwitcherExt_Status:SetActiveWidgetIndex(SWITCHER_STATUS_LIST)
  player_info.InitWidgets(self)
end

function ModeSelection_Sideber_Leaderboard_UIBP:RegistEvents()
  self:AddOnClickedEventByControl(self.UIRoot.Button_Add, self.OnClickButton_Add, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Area, self.OnClickButton_Area, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Friend, self.OnClickButton_Friend, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Detail, self.OnClickButton_Detail, self)
  self.Common_ComboBox_RankType:SetRefreshOptionCallback(self.OnRefreshComboBox_RankType, self)
  self.Common_ComboBox_RankType:SetSelectOptionCallback(self.OnSelectComboBox_RankType, self)
  self:AddCommonEvent(EVENTTYPE_RANK, EVENTID_RANK_UPDATE_LIST, self.RankEventHandler, self)
  self:AddCommonEvent(EVENTTYPE_RANK, EVENTID_RANK_UPDATE_SELF, self.RankEventHandler, self)
  self:AddCommonEvent(EVENTTYPE_RANK, EVENTID_RANK_UPDATE_ITEM, self.RankEventHandler, self)
end

function ModeSelection_Sideber_Leaderboard_UIBP:OnPostInitialize()
  self:_InitComboBoxOptions()
  self:_ApplySwitcherTextOverrides()
  self:_RefreshTeamInfo()
  self:_RefreshRegionToggle()
  self._bInitDone = true
  self:UpdateUI()
end

function ModeSelection_Sideber_Leaderboard_UIBP:OnShow()
  if self._bFirstShow then
    self._bFirstShow = false
    return
  end
  self:UpdateUI()
end

function ModeSelection_Sideber_Leaderboard_UIBP:OnClose()
  player_info.ClearNicknameFrame(self)
  if self._pendingScrollTimer then
    self:RemoveTimer(self._pendingScrollTimer)
    self._pendingScrollTimer = nil
  end
  self._pendingScrollOffset = nil
end

function ModeSelection_Sideber_Leaderboard_UIBP:OnClickButton_Friend()
  self:PlayAudio(sound_config.click_v1)
  self:_SwitchRegion(RegionEnum.friend)
end

function ModeSelection_Sideber_Leaderboard_UIBP:OnClickButton_Area()
  self:PlayAudio(sound_config.click_v1)
  self:_SwitchRegion(RegionEnum.all)
end

function ModeSelection_Sideber_Leaderboard_UIBP:OnClickButton_Add()
  self:PlayAudio(sound_config.click_v1)
  UIManager.ShowUI(UIManager.UI_Config.friend_new_search)
end

function ModeSelection_Sideber_Leaderboard_UIBP:OnClickButton_Detail()
  self:PlayAudio(sound_config.click_v1)
  self:_JumpToRankUI()
end

function ModeSelection_Sideber_Leaderboard_UIBP:OnRefreshComboBox_RankType(Widget, Data, Index)
  if not Data then
    log_warning("ModeSelection_Sideber_Leaderboard_UIBP:OnRefreshComboBox_RankType invalid data, index:" .. tostring(Index))
    return
  end
  Widget.TextBlock_ItemName:SetText(Data.text or "")
end

function ModeSelection_Sideber_Leaderboard_UIBP:OnSelectComboBox_RankType(Widget, Data, Index)
  self:PlayAudio(sound_config.click_v1)
  if not Data then
    log_warning("ModeSelection_Sideber_Leaderboard_UIBP:OnSelectComboBox_RankType invalid data, index:" .. tostring(Index))
    return
  end
  if self._rankTabIndex == Index then
    return
  end
  printf("ModeSelection_Sideber_Leaderboard_UIBP:OnSelectComboBox_RankType index:%s", tostring(Index))
  self._rankTabIndex = Index
  self:_RequestRankData()
end

function ModeSelection_Sideber_Leaderboard_UIBP:OnFilterInfoChanged(filterInfo)
  if not filterInfo then
    return
  end
  local teamCnt = filterInfo.teamNum
  local isFpp = filterInfo.perspective == mode_selection_category_utils.Perspective.FPP
  printf("ModeSelection_Sideber_Leaderboard_UIBP:OnFilterInfoChanged teamNum:%s, perspective:%s", tostring(teamCnt), tostring(filterInfo.perspective))
  local changed = teamCnt ~= self._teamCnt or isFpp ~= self._isFpp
  if not self.UIRoot then
    if teamCnt then
      self._teamCnt = teamCnt
    end
    self._isFpp = isFpp
    return
  end
  self:SetTeamPerspective(teamCnt, isFpp)
  if changed and self:IsShow() then
    self:_RequestRankData()
  end
end

function ModeSelection_Sideber_Leaderboard_UIBP:GetJumpRestoreState()
  local scrollOffset
  if self.LoopScrollBox_Ranking and self.LoopScrollBox_Ranking.GetItemOffset then
    scrollOffset = self.LoopScrollBox_Ranking:GetItemOffset()
  end
  return {
    regionType = self._regionType,
    rankTabIndex = self._rankTabIndex,
    scrollOffset = scrollOffset
  }
end

function ModeSelection_Sideber_Leaderboard_UIBP:ApplyJumpRestoreState(state)
  if not state then
    return
  end
  printf("ModeSelection_Sideber_Leaderboard_UIBP:ApplyJumpRestoreState region:%s, rankTabIndex:%s, bInitDone:%s", tostring(state.regionType), tostring(state.rankTabIndex), tostring(self._bInitDone))
  self._regionType = state.regionType or self._regionType
  self._rankTabIndex = state.rankTabIndex or self._rankTabIndex
  if state.scrollOffset and state.scrollOffset > 0 then
    self._pendingScrollOffset = state.scrollOffset
  end
  if not self._bInitDone or not self.UIRoot then
    return
  end
  self:_InitComboBoxOptions()
  self:_RefreshRegionToggle()
  self:UpdateUI()
end

function ModeSelection_Sideber_Leaderboard_UIBP:_InitComboBoxOptions()
  local comboData = {}
  for _, cfg in ipairs(self._rankTabConfig) do
    comboData[#comboData + 1] = {
      text = LocUtil.LocalizeResFormat(cfg.locID)
    }
  end
  self.Common_ComboBox_RankType:SetData(comboData, self._rankTabIndex, true)
end

function ModeSelection_Sideber_Leaderboard_UIBP:RankEventHandler(eventType, eventID, vars)
  if eventType ~= EVENTTYPE_RANK then
    return
  end
  log(bWriteLog and "ModeSelection_Sideber_Leaderboard_UIBP:RankEventHandler", eventID)
  if eventID == EVENTID_RANK_UPDATE_LIST then
    self:_RefreshList()
    RankNetHandler.QueryRankRoleInfoByScroll(1)
  elseif eventID == EVENTID_RANK_UPDATE_SELF then
    self:_RefreshSelfPanel()
  elseif eventID == EVENTID_RANK_UPDATE_ITEM and vars then
    self:_RefreshListItem(vars)
  end
end

function ModeSelection_Sideber_Leaderboard_UIBP:UpdateUI()
  log(bWriteLog and "ModeSelection_Sideber_Leaderboard_UIBP:UpdateUI")
  self:_RequestRankData()
end

function ModeSelection_Sideber_Leaderboard_UIBP:SetTeamPerspective(teamCnt, isFpp)
  if teamCnt then
    self._teamCnt = teamCnt
  end
  if isFpp ~= nil then
    self._isFpp = isFpp and true or false
  end
  printf("ModeSelection_Sideber_Leaderboard_UIBP:SetTeamPerspective teamCnt:%s, isFpp:%s", tostring(self._teamCnt), tostring(self._isFpp))
  self:_RefreshTeamInfo()
end

function ModeSelection_Sideber_Leaderboard_UIBP:_JumpToRankUI()
  local tabCfg = self._rankTabConfig[self._rankTabIndex]
  if not tabCfg then
    log_warning("ModeSelection_Sideber_Leaderboard_UIBP:_JumpToRankUI invalid tab index:" .. tostring(self._rankTabIndex))
    return
  end
  local rankType = self._bPeak and tabCfg.rankType or self._isFpp and tabCfg.fpp or tabCfg.tpp
  printf("ModeSelection_Sideber_Leaderboard_UIBP:_JumpToRankUI rankType:%s, bPeak:%s, tabIndex:%s", tostring(rankType), tostring(self._bPeak), tostring(self._rankTabIndex))
  RankSystem.EventEnterRank(rankType)
end

function ModeSelection_Sideber_Leaderboard_UIBP:_RequestRankData()
  if not self._bInitDone then
    return
  end
  local tabCfg = self._rankTabConfig[self._rankTabIndex]
  if not tabCfg then
    log_warning("ModeSelection_Sideber_Leaderboard_UIBP:_RequestRankData invalid tab index:" .. tostring(self._rankTabIndex))
    return
  end
  local rankType = self._bPeak and tabCfg.rankType or self._isFpp and tabCfg.fpp or tabCfg.tpp
  local memberType = MemberEnum.team
  if self._teamCnt == 1 then
    memberType = MemberEnum.single
  elseif self._teamCnt == 2 then
    memberType = MemberEnum.double
  end
  if rankType == RankSelectEnum.peakgame_win and self._regionType ~= RegionEnum.all then
    self._regionType = RegionEnum.all
    self:_RefreshRegionToggle()
  end
  printf("ModeSelection_Sideber_Leaderboard_UIBP:_RequestRankData rankType:%s, memberType:%s, region:%s", tostring(rankType), tostring(memberType), tostring(self._regionType))
  RankDataMgr.SetRankSelectType(rankType)
  RankDataMgr.SetRankSelectMemberType(memberType)
  RankDataMgr.SetRankPeriodType(RankConfig.PeriodEnum.total)
  RankDataMgr.SetRankRegionType(self._regionType)
  RankDataMgr.SetRankZoneId()
  RankNetHandler.ReqFetchRankData()
  self:_RefreshList()
end

function ModeSelection_Sideber_Leaderboard_UIBP:_SwitchRegion(region)
  if self._regionType == region then
    return
  end
  printf("ModeSelection_Sideber_Leaderboard_UIBP:_SwitchRegion region:%s", tostring(region))
  self._regionType = region
  self:_RefreshRegionToggle()
  self:_RequestRankData()
end

function ModeSelection_Sideber_Leaderboard_UIBP:_ApplySwitcherTextOverrides()
  local overrideList = {
    {
      switcher = self.UIRoot.WidgetSwitcherExt_Friend,
      widget = self.UIRoot.Text_Friend,
      text = LocUtil.LocalizeResFormat(102124),
      indexes = {SWITCHER_INDEX_DEFAULT, SWITCHER_INDEX_SELECTED},
      tag = "Friend"
    },
    {
      switcher = self.UIRoot.WidgetSwitcherExt_Area,
      widget = self.UIRoot.TextBlock_Area,
      text = LocUtil.LocalizeResFormat(102123),
      indexes = {SWITCHER_INDEX_DEFAULT, SWITCHER_INDEX_SELECTED},
      tag = "Area"
    },
    {
      switcher = self.UIRoot.WidgetSwitcherExt_Status,
      widget = self.UIRoot.TextBlock_Empty,
      text = LocUtil.GetLocalizeResStr(4791),
      indexes = {SWITCHER_STATUS_LIST, SWITCHER_STATUS_EMPTY},
      tag = "Empty"
    }
  }
  for _, cfg in ipairs(overrideList) do
    for _, index in ipairs(cfg.indexes) do
      local bOk = cfg.switcher:SetOverrideText(index, cfg.widget, "Text", cfg.text)
      printf("ModeSelection_Sideber_Leaderboard_UIBP:_ApplySwitcherTextOverrides tag:%s, index:%s, ok:%s", cfg.tag, index, bOk)
      if not bOk then
        log_warning("ModeSelection_Sideber_Leaderboard_UIBP:_ApplySwitcherTextOverrides failed, tag:" .. cfg.tag .. ", index:" .. tostring(index))
      end
    end
  end
end

function ModeSelection_Sideber_Leaderboard_UIBP:_RefreshRegionToggle()
  local bFriend = self._regionType == RegionEnum.friend
  printf("ModeSelection_Sideber_Leaderboard_UIBP:_RefreshRegionToggle bFriend:%s", bFriend)
  self.UIRoot.WidgetSwitcherExt_Friend:SetActiveWidgetIndex(bFriend and SWITCHER_INDEX_SELECTED or SWITCHER_INDEX_DEFAULT)
  self.UIRoot.WidgetSwitcherExt_Area:SetActiveWidgetIndex(bFriend and SWITCHER_INDEX_DEFAULT or SWITCHER_INDEX_SELECTED)
end

function ModeSelection_Sideber_Leaderboard_UIBP:_RefreshTeamInfo()
  self.UIRoot.TextBlock_TeamCnt:SetText(tostring(self._teamCnt))
  local Perspective = mode_selection_category_utils.Perspective
  self.UIRoot.Text_PerspectiveType:SetText(LocUtil.LocalizeResFormat(self._isFpp and Perspective.FPP or Perspective.TPP))
end

function ModeSelection_Sideber_Leaderboard_UIBP:_RefreshList()
  local list = RankDataMgr.ParseRankViewData() or {}
  printf("ModeSelection_Sideber_Leaderboard_UIBP:_RefreshList count:%s, region:%s", #list, tostring(self._regionType))
  self.LoopScrollBox_Ranking:SetData(list)
  self:_ConsumePendingScrollOffset()
  local bEmpty = self._regionType == RegionEnum.friend and #list <= 1
  self.UIRoot.WidgetSwitcherExt_Status:SetActiveWidgetIndex(bEmpty and SWITCHER_STATUS_EMPTY or SWITCHER_STATUS_LIST)
  self:_RefreshSelfPanel()
end

function ModeSelection_Sideber_Leaderboard_UIBP:_ConsumePendingScrollOffset()
  if not self._pendingScrollOffset then
    return
  end
  local list = self.LoopScrollBox_Ranking:GetSetData()
  if type(list) ~= "table" or #list <= 0 then
    return
  end
  if self._pendingScrollTimer then
    self:RemoveTimer(self._pendingScrollTimer)
  end
  self._pendingScrollTimer = self:AddTimer(0.25, function()
    self._pendingScrollTimer = nil
    local offset = self._pendingScrollOffset
    if not offset or not self.LoopScrollBox_Ranking then
      return
    end
    self._pendingScrollOffset = nil
    printf("ModeSelection_Sideber_Leaderboard_UIBP: restore scroll offset:%s", tostring(offset))
    self.LoopScrollBox_Ranking:SetItemOffset(offset)
  end)
end

function ModeSelection_Sideber_Leaderboard_UIBP:_RefreshListItem(rankItem)
  local tempList = self.LoopScrollBox_Ranking:GetSetData()
  if type(tempList) ~= "table" then
    return
  end
  for i, v in ipairs(tempList) do
    if tostring(v.uid) == tostring(rankItem.uid) then
      self.LoopScrollBox_Ranking:RefreshItem(i, v)
      return
    end
  end
end

function ModeSelection_Sideber_Leaderboard_UIBP:_RefreshSelfPanel()
  local info = RankDataMgr.GetRankInfoSelf()
  if not info then
    printf("ModeSelection_Sideber_Leaderboard_UIBP:_RefreshSelfPanel skip no self info")
    return
  end
  local no = tonumber(info.no) or 0
  local showRankImage = 0 < no and no < 4
  self:SetWidgetVisible(self.UIRoot.Image_Rank, showRankImage)
  self:SetWidgetVisible(self.UIRoot.TextBlockNoRank, not showRankImage)
  if showRankImage then
    self:SetTexture(self.UIRoot.Image_Rank, RANK_TOP3_IMAGE[no])
  elseif 0 < no then
    self.UIRoot.TextBlockNoRank:SetText(tostring(no))
  else
    self.UIRoot.TextBlockNoRank:SetText(LocUtil.LocalizeResFormat(LOC_ID_NO_RANK))
  end
  local extraPara = {
    collectPara = {
      collectData = info.collect_data,
      showCollectTips = false
    }
  }
  self.UIRoot.Common_Avatar_BP:InitView(1, DataMgr.roleData.uid, info.url, info.gender, info.cur_avatar_box_id, info.level, false, "", nil, extraPara)
  player_info.RefreshNameStyle(self, DataMgr.roleData.uid, info.name)
  local rankSelectType = RankDataMgr.GetRankSelectType()
  local score = tonumber(info.score) or 0
  local showScore = score
  if rankSelectType ~= RankConfig.RankSelectEnum.peakgame_kd and rankSelectType ~= RankConfig.RankSelectEnum.peakgame_win then
    showScore = math.floor(score + 0.5)
  end
  printf("ModeSelection_Sideber_Leaderboard_UIBP:_RefreshSelfPanel rankType:%s, rawScore:%s, showScore:%s", rankSelectType, score, showScore)
  self.UIRoot.TextBlock_Score02:SetText(tostring(showScore))
  local upass = DataMgr.roleData.upass
  player_info.RefreshGender(self, DataMgr.roleData.uid, info.new_sex)
  player_info.RefreshLightBoard(self, DataMgr.roleData.uid, info.light_board_info or DataMgr.roleData.light_board_info)
  player_info.RefreshNicknameFrame(self, info.friend_nickname_skin)
  player_info.RefreshUnknowPass(self, upass, upass and upass.switch and upass.switch.ui)
  player_info.RefreshSegment(self, self._bPeak, DataMgr.roleData.uid, info and tonumber(info.segment))
  player_info.RefreshNation(self, info.nation)
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
return class(ui_base, nil, ModeSelection_Sideber_Leaderboard_UIBP)
