local ModeSelection_Common_Item_Base_UIBP = {}
local slua_isValid = slua.isValid
local mode_selection_multi_util = require("GameLua.Mod.Lobby.Split.ModeSelection470.logic.mode_selection_multi_util")
local PufferConst = require("client.slua.logic.download.puffer_const")
local E_DownloadState = PufferConst.ENUM_DownloadState
local PufferTlog = require("client.slua.logic.download.report.puffer_tlog")
local WidgetSwitcherExt_FlagBg_Enum = {Rank = 3, Multi = 6}
ModeSelection_Common_Item_Base_UIBP.WidgetSwitcherExt_FlagBg_Enum = WidgetSwitcherExt_FlagBg_Enum
local FLAG_BG_STATE = {
  High = {Locked = 0, Normal = 1},
  Long = {
    Locked = 0,
    Multi = 2,
    Normal = 3,
    Peak = 6,
    UGC = 7
  },
  Short = {
    Locked = 0,
    Multi = 2,
    Normal = 6,
    UGC = 9
  },
  Grow = {
    Normal = 3,
    Video = 4,
    Done = 5
  },
  FriendHotBig = {
    Normal = 6,
    Online = 7,
    UGC = 9
  }
}
ModeSelection_Common_Item_Base_UIBP.FlagBgState = FLAG_BG_STATE
local FLAG_BG_VALID_STATE = {}
for _, stateMap in pairs(FLAG_BG_STATE) do
  for _, state in pairs(stateMap) do
    FLAG_BG_VALID_STATE[state] = true
  end
end
local LOCK_TEXT_ID = {
  LevelUnlock = 6573,
  Segment = 5588153,
  PeakSegment = 5588154,
  TimeCountdown = 7462,
  TimeEnded = 5588156
}
local LOCK_REASON_EXT = {TimeCountdown = 101, TimeEnded = 102}

function ModeSelection_Common_Item_Base_UIBP:ctor()
  self.isMultiMode = false
  self.WidgetSwitcherExt_FlagBg_Enum = WidgetSwitcherExt_FlagBg_Enum
  self.FlagBgState = FLAG_BG_STATE
  self.curFlagBgState = nil
  self._lockTextTimer = nil
end

function ModeSelection_Common_Item_Base_UIBP:OnInitialize()
end

function ModeSelection_Common_Item_Base_UIBP:RegistEvents()
  if self.UIRoot.Button_Mode then
    self:AddOnClickedEventByControl(self.UIRoot.Button_Mode, self.OnModeItemClicked, self)
  end
  if self.UIRoot.Button_YellowText then
    self:AddOnClickedEventByControl(self.UIRoot.Button_YellowText, self.OnButton_RatingProtectClick, self)
  end
  self:AddCommonEvent(EVENTTYPE_ACTIVITY, EVENTID_RATING_PROTECT_ACTIVITY_GET_CONFIG, self.RefreshRatingProtectData, self)
  self:AddCommonEvent(EVENTTYPE_DATA_MGR, EVNETID_DATAMGR_ACTIVITY_CHANGE, self.OnRefreshRatingProtectAct, self)
  self:AddCommonEvent(EVENTTYPE_MATCH, EVENTID_MATCH_MODE_SELECT_MAP, self.OnMatchModeSelectMap, self)
end

function ModeSelection_Common_Item_Base_UIBP:OnClose()
  self:_StopLockTextTimer()
  self:_RemoveDownloadWidget()
  self.isShowRatingProtect = nil
  self.resolveGroupSet = nil
end

function ModeSelection_Common_Item_Base_UIBP:OnModeItemClicked(...)
  local swipeGuideUI = UIManager.GetUI(UIManager.UI_Config.ModeSelection_Guide_SwipeGuide_UIBP)
  if swipeGuideUI then
    swipeGuideUI:CloseSelf()
  end
  return self:OnClickButton_Mode(...)
end

function ModeSelection_Common_Item_Base_UIBP:OnClickButton_Mode()
  self:PlayAudio(sound_config.click_v1)
  self:_ClearNewFlag()
  local tlogUtil = require("GameLua.Mod.Lobby.Split.ModeSelection470.util.ModeSelectionTLogUtil")
  local data = tlogUtil.ClickCard(self)
  if not data then
    return
  end
  local view_id = data.id
  local logic_newbie_mode_selection = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_newbie_mode_selection)
  if logic_newbie_mode_selection:IsNewbieView(view_id) then
    if data.modeTLogContext then
      local modeTLog = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_tlog)
      modeTLog:ReportSelection(data.modeTLogContext, {view_id})
    end
    local logic_mode_selection = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection)
    logic_mode_selection:SetSelectView(view_id, logic_mode_selection:GetFilterInfo())
    return
  end
  if tonumber(data.mod_id) and tonumber(data.mod_id) > 0 then
    local logicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
    local raw = data.pub_mod_meta or data.setting and data or logicUGC:GetModByAllCache(data.mod_id)
    local meta = raw and (raw.pub_mod_meta or raw)
    if meta then
      local configUGC = require("client.slua.logic.ugc.config_ugc")
      UIManager.ShowUI(UIManager.UI_Config.UGC_ModDetail_Main, nil, meta, {
        sourceModule = configUGC.Source_Open_Detail.UGCMain,
        bFromModeSelection = true
      })
    end
  elseif self.isMultiMode then
    UIManager.ShowUI(UIManager.UI_Config.ModeSelection_Sideber_Main_RandomMap_UIBP, self.data, {
      selectViewIDs = self.selectViewIDs
    })
  else
    UIManager.ShowUI(UIManager.UI_Config.ModeSelection_Sideber_Main_UIBP, self.data)
  end
end

function ModeSelection_Common_Item_Base_UIBP:OnMatchModeSelectMap(_, _, newViewIDs, oldViewIDs)
  if self.isMultiMode then
    local bInGroup = false
    for _, viewID in pairs(newViewIDs or {}) do
      if self.resolveGroupSet and self.resolveGroupSet[viewID] then
        bInGroup = true
        break
      end
    end
    if not bInGroup then
      return
    end
    self.selectViewIDs = newViewIDs
    self:_ClassicMultiUpdateDisplay()
    self:_SetDownloadData(self.data)
  end
end

function ModeSelection_Common_Item_Base_UIBP:_GetDownloadMapKeys(data)
  if type(data) ~= "table" then
    return {}, nil
  end
  local logic_mode_selection = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection)
  local logic_mode_map_download = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_map_download)
  local categoryUtils = require("GameLua.Mod.Lobby.Split.ModeSelection470.logic.mode_selection_category_utils")
  if categoryUtils.GetArenaSubKind(data) == categoryUtils.ArenaSubKind.Rank and data.group_view_v2 and next(data.group_view_v2) then
    local mapKeyList, mapKeySet = {}, {}
    for _, groupView in pairs(data.group_view_v2) do
      local viewInfo = logic_mode_selection:GetSubviewInfoBySubviewID(groupView.view_id)
      local keys = logic_mode_map_download:GetMapKeyListByViewData(viewInfo)
      for _, mapKey in ipairs(keys or {}) do
        if not mapKeySet[mapKey] then
          mapKeySet[mapKey] = true
          mapKeyList[#mapKeyList + 1] = mapKey
        end
      end
    end
    return mapKeyList, data.view_id or data.id, true
  end
  if self.isMultiMode and self.selectViewIDs and next(self.selectViewIDs) then
    local viewID = self.selectViewIDs[1]
    local viewInfo = logic_mode_selection:GetSubviewInfoBySubviewID(viewID)
    if viewInfo then
      return logic_mode_map_download:GetMapKeyListByViewData(viewInfo) or {}, viewID
    end
  end
  local viewID = data.view_id or data.id
  local viewInfo = viewID and logic_mode_selection:GetSubviewInfoBySubviewID(viewID) or data
  if viewInfo then
    return logic_mode_map_download:GetMapKeyListByViewData(viewInfo) or {}, viewID
  end
  return {}, nil
end

function ModeSelection_Common_Item_Base_UIBP:_OnDownloadMapFinish()
  log(bWriteLog and "ModeSelection_Common_Item_Base_UIBP:_OnDownloadMapFinish")
  self:_RemoveDownloadWidget()
  if self.data then
    self:OnRefresh(self.data, self.slotIndex)
  end
end

function ModeSelection_Common_Item_Base_UIBP:_SetDownloadAreaVisible(bShow)
  if not self.UIRoot then
    return
  end
  local sizeBox = self.UIRoot.SizeBox_Download
  if sizeBox then
    self:SetWidgetVisible(sizeBox, bShow)
  end
  local canvasPanel = self.UIRoot.CanvasPanel_Download
  if canvasPanel then
    canvasPanel:SetWidgetVisibility(bShow and UEnums.ESlateVisibility.SelfHitTestInvisible or UEnums.ESlateVisibility.Collapsed)
  end
end

function ModeSelection_Common_Item_Base_UIBP:_RemoveDownloadWidget()
  if self.downloader then
    self.downloader:Close()
    self.downloader = nil
  end
  if self._childUI_ModeSelection_Common_Download then
    self._childUI_ModeSelection_Common_Download:Close()
    self._childUI_ModeSelection_Common_Download = nil
  end
  self:_SetDownloadAreaVisible(false)
end

function ModeSelection_Common_Item_Base_UIBP:_SetDownloadData(data)
  if type(data) == "table" and data.mod_id and not data.view_id then
    self:_SetDownloadAreaVisible(false)
    return
  end
  if not self.UIRoot or not self.UIRoot.CanvasPanel_Download then
    self:_SetDownloadAreaVisible(false)
    return
  end
  local mapKeyList, viewID, downloadGroup = self:_GetDownloadMapKeys(data)
  self.mapKeyList = mapKeyList
  if not mapKeyList or not next(mapKeyList) then
    self:_RemoveDownloadWidget()
    return
  end
  local logic_mode_map_download = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_map_download)
  local downloadStatus = logic_mode_map_download:GetMapListState(mapKeyList)
  if downloadStatus == E_DownloadState.Done then
    self:_RemoveDownloadWidget()
    return
  end
  local PufferSwitch = require("client.slua.logic.download.puffer_switch")
  if PufferSwitch.BanDownload then
    self:_RemoveDownloadWidget()
    return
  end
  self:_SetDownloadAreaVisible(true)
  local downloader = self._childUI_ModeSelection_Common_Download
  if not downloader then
    downloader = self:CreateChildWindow(self.UIRoot.CanvasPanel_Download, UIManager.UI_Config.ModeSelection_Common_Download_UIBP)
    self._childUI_ModeSelection_Common_Download = downloader
  end
  if not downloader then
    self:_RemoveDownloadWidget()
    return
  end
  self.downloader = downloader
  
  local function doneCallback()
    self:_OnDownloadMapFinish()
  end
  
  downloader:SetData(mapKeyList[1], doneCallback, nil, PufferTlog.Enum_TLog_From.ModeSelect, downloadGroup and mapKeyList or nil)
  downloader:SetVisibilityInner(true)
end

function ModeSelection_Common_Item_Base_UIBP:UpdateFlagBgState(data)
  return nil
end

function ModeSelection_Common_Item_Base_UIBP:_GetDescriptionTextIndex(data)
  return 0
end

function ModeSelection_Common_Item_Base_UIBP:_SetFlagBgState(state)
  if state == nil or not FLAG_BG_VALID_STATE[state] then
    log(bWriteLog and "ModeSelection_Common_Item_Base_UIBP:_SetFlagBgState invalid state:" .. tostring(state))
    return false
  end
  if not self.UIRoot or not self.UIRoot.WidgetSwitcherExt_FlagBg then
    return false
  end
  if self.curFlagBgState == state then
    return true
  end
  self.curFlagBgState = state
  self.UIRoot.WidgetSwitcherExt_FlagBg:SetActiveWidgetIndex(state)
  return true
end

function ModeSelection_Common_Item_Base_UIBP:_ResetFlagBgState()
  self.curFlagBgState = nil
end

function ModeSelection_Common_Item_Base_UIBP:_IsViewLocked(data, qualificationOnly)
  if type(data) ~= "table" then
    return false
  end
  local helper = require("GameLua.Mod.Lobby.Split.ModeSelection470.logic.mode_selection470_sideber_helper")
  local macros = require("GameLua.Mod.Lobby.Split.ModeSelection470.logic.mode_selection470_macros")
  local category_utils = require("GameLua.Mod.Lobby.Split.ModeSelection470.logic.mode_selection_category_utils")
  local category = category_utils.GetCategory(data)
  local lockReason, lockLevel = helper.IsStartButtonLocked(data, category, false, nil)
  if lockReason ~= nil and lockReason ~= macros.ENUM_START_LOCK_REASON.None then
    return true, lockReason, lockLevel
  end
  if qualificationOnly then
    return false
  end
  if mode_selection_multi_util.IsTdmMultiGroupView(data) then
    local logic_mode_selection = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection)
    local hasSubview = false
    local nearestLeftSecond
    for _, groupView in pairs(data.group_view_v2 or {}) do
      local subViewData = groupView.view_id and logic_mode_selection:GetSubviewInfoBySubviewID(groupView.view_id)
      if subViewData then
        hasSubview = true
        local isOpen, _, leftSecond = logic_mode_selection:GetTimeLimitStr(subViewData)
        if isOpen then
          return false
        end
        if leftSecond and 0 < leftSecond and (not nearestLeftSecond or nearestLeftSecond > leftSecond) then
          nearestLeftSecond = leftSecond
        end
      end
    end
    if hasSubview then
      if nearestLeftSecond then
        return true, LOCK_REASON_EXT.TimeCountdown, nearestLeftSecond
      end
      return true, LOCK_REASON_EXT.TimeEnded, nil
    end
  end
  local ok, state, leftSecond = pcall(helper.ResolveStartButtonState, data, category, false, data.id, nil)
  if not ok then
    printf("ModeSelection_Common_Item_Base_UIBP:_IsViewLocked view:%s error:%s", tostring(data.id), tostring(state))
    return false
  end
  if state == macros.ENUM_START_BUTTON_STATE.Countdown_3 then
    return true, LOCK_REASON_EXT.TimeCountdown, leftSecond
  elseif state == macros.ENUM_START_BUTTON_STATE.Ended_4 then
    return true, LOCK_REASON_EXT.TimeEnded, nil
  end
  return false
end

function ModeSelection_Common_Item_Base_UIBP:_BuildLockText(lockReason, lockExtra)
  if not lockReason then
    return ""
  end
  local macros = require("GameLua.Mod.Lobby.Split.ModeSelection470.logic.mode_selection470_macros")
  local LOCK_REASON = macros.ENUM_START_LOCK_REASON
  if lockReason == LOCK_REASON.Level then
    if not lockExtra then
      return ""
    end
    return LocUtil.LocalizeResFormat(LOCK_TEXT_ID.LevelUnlock, lockExtra)
  elseif lockReason == LOCK_REASON.Segment then
    return LocUtil.LocalizeResFormat(LOCK_TEXT_ID.Segment)
  elseif lockReason == LOCK_REASON.PeakSegment then
    return LocUtil.LocalizeResFormat(LOCK_TEXT_ID.PeakSegment)
  elseif lockReason == LOCK_REASON_EXT.TimeCountdown then
    local TimeUtil = require("client.common.time_util")
    local leftSecond = math.max(lockExtra or 0, 0)
    return LocUtil.LocalizeResFormat(LOCK_TEXT_ID.TimeCountdown, TimeUtil.GetTimeLengthStr(leftSecond, true))
  elseif lockReason == LOCK_REASON_EXT.TimeEnded then
    return LocUtil.LocalizeResFormat(LOCK_TEXT_ID.TimeEnded)
  end
  return ""
end

function ModeSelection_Common_Item_Base_UIBP:_RefreshLockText(data)
  self:_StopLockTextTimer()
  local textBlock = self.UIRoot and self.UIRoot.TextBlock_4
  if not textBlock then
    return
  end
  local bLocked, lockReason, lockExtra = self:_IsViewLocked(data)
  if not bLocked then
    textBlock:SetText("")
    self:SetWidgetVisible(textBlock, false)
    return
  end
  local text = self:_BuildLockText(lockReason, lockExtra)
  if text == nil or text == "" then
    textBlock:SetText("")
    self:SetWidgetVisible(textBlock, false)
    return
  end
  textBlock:SetText(text)
  self:SetWidgetVisible(textBlock, true)
  if lockReason == LOCK_REASON_EXT.TimeCountdown then
    self:_StartLockTextTimer(data)
  end
end

function ModeSelection_Common_Item_Base_UIBP:_StartLockTextTimer(data)
  self:_StopLockTextTimer()
  local handle
  handle = self:AddTimerOnce(1, function()
    if self._lockTextTimer ~= handle then
      return
    end
    self._lockTextTimer = nil
    if not (self.data == data and self.UIRoot) or not slua_isValid(self.UIRoot) then
      return
    end
    local previousState = self.curFlagBgState
    self:UpdateFlagBgState(data)
    if self.curFlagBgState ~= previousState then
      self:OnRefresh(data, self.slotIndex)
    else
      self:_RefreshLockText(data)
    end
  end)
  self._lockTextTimer = handle
end

function ModeSelection_Common_Item_Base_UIBP:_StopLockTextTimer()
  if self._lockTextTimer then
    self:RemoveTimer(self._lockTextTimer)
    self._lockTextTimer = nil
  end
end

function ModeSelection_Common_Item_Base_UIBP:_IsPeakView(data)
  if type(data) ~= "table" then
    return false
  end
  local category_utils = require("GameLua.Mod.Lobby.Split.ModeSelection470.logic.mode_selection_category_utils")
  return category_utils.IsCategory(data, category_utils.Category.Peak)
end

local function GetViewLocalizedText(id)
  local idType = type(id)
  if idType == "number" then
    if id <= 0 or id % 1 ~= 0 then
      return nil
    end
  elseif idType == "string" then
    if id == "" or id == "0" then
      return nil
    end
  else
    return nil
  end
  local text = LocUtil.GetLocalizeResStr(id)
  return text ~= "" and text or nil
end

function ModeSelection_Common_Item_Base_UIBP:OnRefresh(data, slotIndex)
  self:_StopLockTextTimer()
  if not data or not self.UIRoot then
    return
  end
  self.slotIndex = slotIndex
  self:_ResetFlagBgState()
  self.data = data
  if self.UIRoot.TextBlock_Name then
    local name = GetViewLocalizedText(data.title_v2) or GetViewLocalizedText(data.lobby_name) or ""
    self.UIRoot.TextBlock_Name:SetText(name)
  end
  if self.UIRoot.TextBlock_NameList then
    local subName = GetViewLocalizedText(data.aux_name) or ""
    self.UIRoot.TextBlock_NameList:SetText(subName)
  end
  if self.UIRoot.WidgetSwitcher_DescriptionText then
    self.UIRoot.WidgetSwitcher_DescriptionText:SetActiveWidgetIndex(self:_GetDescriptionTextIndex(data))
  end
  if self.UIRoot.Image_BG then
    self:SetTexture(self.UIRoot.Image_BG, data.general_view, {bMatchSize = true, needLocalize = true})
  end
  self.isMultiMode = false
  if mode_selection_multi_util.IsMultiGroupView(data) then
    if mode_selection_multi_util.IsClassicMultiGroupView(data) then
      self.isMultiMode = true
      self:UpdateClassicMultiUI()
    else
      local modeBgPath = data.general_multi_view
      if modeBgPath and modeBgPath ~= "" and self.UIRoot.Image_BG then
        self:SetTexture(self.UIRoot.Image_BG, modeBgPath, {bMatchSize = true, needLocalize = true})
      end
    end
  end
  self:SetWidgetVisible(self.UIRoot.Image_BG, true)
  self:UpdateFlagBgState(data)
  self:_RefreshLockText(data)
  self:_RefreshNewFlag(data)
  self:_RefreshTags(data)
  self:_RefreshBadge(data)
  self:RefreshRatingProtectData()
  self:_SetDownloadData(data)
  self:_RefreshSocialPlay(data)
end

function ModeSelection_Common_Item_Base_UIBP:_RefreshSocialPlay(data)
  local panel = self.UIRoot.CanvasPanel_SelfRecommendation
  if not panel then
    return
  end
  local payloads = data and data.payloads
  local socialPlay = payloads and payloads.social_play
  if not socialPlay then
    self:SetWidgetVisible(panel, false)
    return
  end
  self:SetWidgetVisible(panel, true)
  local uids = socialPlay.uids or {}
  local totalCount = socialPlay.total_count or #uids
  if self.UIRoot.TextBlock_6 then
    self.UIRoot.TextBlock_6:SetText(tostring(totalCount))
  end
  local avatarWidgets = {
    self.UIRoot.Common_Avatar_BP_C_107,
    self.UIRoot.Common_Avatar_BP_C_244
  }
  for i, avatarWidget in ipairs(avatarWidgets) do
    if avatarWidget then
      local uid = uids[i]
      if uid then
        self:SetWidgetVisible(avatarWidget, true)
        local logic_profile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
        local profile = logic_profile and logic_profile:GetLocalProfile(tonumber(uid) or uid) or nil
        avatarWidget:InitView(1, tonumber(uid) or uid, profile and profile.picUrl or "", 0, profile and profile.cur_avatar_box_id, profile and profile.level or 0, false, "")
      else
        self:SetWidgetVisible(avatarWidget, false)
      end
    end
  end
end

function ModeSelection_Common_Item_Base_UIBP:_RefreshTags(data)
  local tagWidget = self.UIRoot.ModeSelection_Common_Tab_Button_Item_UIBP
  if not tagWidget then
    return
  end
  local subtitle = GetViewLocalizedText(data and data.subtitle_v2) or ""
  local bShowSubtitle = subtitle:find("%S") ~= nil
  if tagWidget.TextBlock_Name then
    tagWidget.TextBlock_Name:SetText(bShowSubtitle and subtitle or "")
  end
  self:SetWidgetVisible(tagWidget, bShowSubtitle)
end

function ModeSelection_Common_Item_Base_UIBP:_RefreshBadge(data)
  local imageBadge = self.UIRoot and self.UIRoot.Image_Badge
  local CanvasPanel_Badge = self.UIRoot and self.UIRoot.CanvasPanel_Badge
  if not imageBadge or not CanvasPanel_Badge then
    return
  end
  local resPath
  local tagIndex = type(data) == "table" and data.tag_v2 or nil
  if tagIndex and tagIndex ~= 0 then
    local cfg = CDataTable.GetSplitTableData("Lobby", "ModeSelection", "view_new_tag_index2res", tagIndex)
    resPath = cfg and cfg.Res
  end
  if resPath and resPath ~= "" then
    self:SetTexture(imageBadge, resPath, {needLocalize = true})
    self:SetWidgetVisible(imageBadge, true)
    self:SetWidgetVisible(CanvasPanel_Badge, true)
  else
    self:SetWidgetVisible(imageBadge, false)
    self:SetWidgetVisible(CanvasPanel_Badge, false)
  end
end

function ModeSelection_Common_Item_Base_UIBP:OnCardRelease()
  self:_StopLockTextTimer()
  self:_RemoveDownloadWidget()
end

function ModeSelection_Common_Item_Base_UIBP:HideAllTag()
  log(bWriteLog and "ModeSelection_Common_Item_Base_UIBP:HideAllTag")
  self:SetWidgetVisible(self.UIRoot.ModeSelection_Common_Tab_Button_Item_UIBP, false)
end

function ModeSelection_Common_Item_Base_UIBP:UpdateClassicMultiUI()
  if not self.data then
    return
  end
  local isRank = mode_selection_multi_util.GetMainUIIsRank()
  local groupView, rankedGroupView, unrankedGroupView = mode_selection_multi_util.BuildMultiGroupView(self.data)
  self.groupView = groupView
  local resolveGroupView = isRank and rankedGroupView or unrankedGroupView
  if not resolveGroupView or not next(resolveGroupView) then
    resolveGroupView = {}
  end
  self.resolveGroupSet = {}
  for _, viewInfo in pairs(resolveGroupView) do
    self.resolveGroupSet[viewInfo.view_id] = true
  end
  local groupViewId = resolveGroupView[1] and resolveGroupView[1].view_id
  self.selectViewIDs, self.mapDownloadInfoDict = mode_selection_multi_util.ResolveSelectViews(resolveGroupView, groupViewId)
  self:_ClassicMultiUpdateDisplay()
end

function ModeSelection_Common_Item_Base_UIBP:_ClassicMultiUpdateDisplay()
  local selectViewIDs = self.selectViewIDs
  if selectViewIDs and next(selectViewIDs) then
    local nameText = ""
    local selectMapNum = #selectViewIDs
    local viewInfo = mode_selection_multi_util.GetTopSelectedViewInfo(selectViewIDs, self.groupView)
    if 1 < selectMapNum then
      nameText = LocUtil.LocalizeResFormat(588125, selectMapNum)
    else
      nameText = LocUtil.LocalizeResFormat(588124, LocUtil.GetLocalizeResStr(viewInfo.title_v2))
    end
    if self.UIRoot.Image_BG then
      self:SetTexture(self.UIRoot.Image_BG, viewInfo.general_view, {bMatchSize = true, needLocalize = true})
    end
    if self.UIRoot.TextBlock_Name then
      self.UIRoot.TextBlock_Name:SetText(nameText)
    end
  end
end

function ModeSelection_Common_Item_Base_UIBP:OnButton_RatingProtectClick()
  self:PlayAudio(sound_config.click)
  local data = self.data
  if not self:_IsRatingProtectView(data) then
    return
  end
  local viewId = data.view_id or data.id
  local LogicRatingProtectActivity = require("client.slua.logic.activity.rating_protect_activity.logic_rating_protect_activity")
  local ifShowRatingProtectBanner, activityId = LogicRatingProtectActivity.CheckModeHasRatingProtectActivity(viewId)
  if not ifShowRatingProtectBanner then
    return
  end
  local remainNum = LogicRatingProtectActivity.GetRatingProtectRemainNumber(activityId)
  local startTime, endTime = LogicRatingProtectActivity.GetRatingProtectActivityTimeById(activityId)
  local TimeUtil = require("client.common.time_util")
  local time = TimeUtil.FormatTime_timeFrame(startTime, endTime, false, true)
  local UIUtil = require("client.common.ui_util")
  local tipPos = UIUtil.GetWidgetViewportPos(self.UIRoot.Button_YellowText)
  local helpTipsUI = UIManager.ShowUI(UIManager.UI_Config.Common_HelpTips_UIBP)
  if helpTipsUI then
    helpTipsUI:ShowPanelStrWithPos(LocUtil.LocalizeFormatConcatenation(52019, remainNum, time), tipPos.X - 50, tipPos.Y - 15, true, true)
  end
end

function ModeSelection_Common_Item_Base_UIBP:_IsRatingProtectView(data)
  if type(data) ~= "table" then
    return false
  end
  if mode_selection_multi_util.IsMultiGroupView(data) then
    return false
  end
  if not data.view_id and data.mod_id then
    return false
  end
  if data.is_ranked ~= 1 then
    return false
  end
  if self:_IsPeakView(data) then
    return false
  end
  return true
end

function ModeSelection_Common_Item_Base_UIBP:_SetRatingProtectVisible(bVisible)
  if not self.UIRoot then
    return
  end
  local panel = self.UIRoot.CanvasPanel_Text
  if not panel or not slua_isValid(panel) then
    return
  end
  self:SetWidgetVisible(panel, bVisible and true or false)
end

function ModeSelection_Common_Item_Base_UIBP:OnRefreshRatingProtectAct()
  log(bWriteLog and "ModeSelection_Common_Item_Base_UIBP:OnRefreshRatingProtectAct Data is change")
  self:RefreshRatingProtectData()
end

function ModeSelection_Common_Item_Base_UIBP:RefreshRatingProtectData()
  if not self.UIRoot or not slua_isValid(self.UIRoot) then
    log(bWriteLog and "ModeSelection_Common_Item_Base_UIBP:RefreshRatingProtectData uiroot is invalid!")
    return
  end
  local data = self.data
  if not self:_IsRatingProtectView(data) then
    log(bWriteLog and "ModeSelection_Common_Item_Base_UIBP:RefreshRatingProtectData is not ranked or is peak")
    self.isShowRatingProtect = false
    self:_SetRatingProtectVisible(false)
    return
  end
  local viewId = data.view_id or data.id
  local LogicRatingProtectActivity = require("client.slua.logic.activity.rating_protect_activity.logic_rating_protect_activity")
  local ifShowRatingProtectBanner, activityId = LogicRatingProtectActivity.CheckModeHasRatingProtectActivity(viewId)
  self.isShowRatingProtect = ifShowRatingProtectBanner
  self:_SetRatingProtectVisible(ifShowRatingProtectBanner and true or false)
  if not ifShowRatingProtectBanner then
    log(bWriteLog and "ModeSelection_Common_Item_Base_UIBP:RefreshRatingProtectData not show")
    return
  end
  local textBlock = self.UIRoot.TextBlock_0
  if not textBlock or not slua_isValid(textBlock) then
    return
  end
  local actData = LogicRatingProtectActivity.GetRatingProtectActivityDataById(activityId)
  local key = 52014
  if LogicRatingProtectActivity.IsReturnRatingProtectAct(actData) then
    key = 52021
  end
  local remainNum = LogicRatingProtectActivity.GetRatingProtectRemainNumber(activityId)
  textBlock:SetText(LocUtil.LocalizeResFormat(key, remainNum))
end

function ModeSelection_Common_Item_Base_UIBP:_RefreshNewFlag(data)
end

function ModeSelection_Common_Item_Base_UIBP:_ClearNewFlag()
end

ModeSelection_Common_Item_Base_UIBP.LOCK_REASON_EXT = LOCK_REASON_EXT
local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
return class(ui_base, nil, ModeSelection_Common_Item_Base_UIBP)
