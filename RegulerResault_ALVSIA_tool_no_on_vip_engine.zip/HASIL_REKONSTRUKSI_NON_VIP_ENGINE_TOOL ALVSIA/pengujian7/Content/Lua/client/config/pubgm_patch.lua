-- !!! DO NOT MODIFY THIS FILE. !!!
-- AUTO GENERATE BY pubgm_patch.py 2026-11-14 19:53:09
global_patch_make_time = "" ..
"Patch Version : 4.7.0.21770\n" ..
"Mode : TAPD\n" ..
"Branch : Release4.7.0\n" ..
"Git Engine : 85c8c9418653e0138b69c48c4eef0611996a4f12\n" ..
"Git Survive : ae80868ed5a9878a02d5e2eea09323191184f33d\n" ..
"Git Lua : 0a7d802d5c685940dad04d66c038bd95a34fa2d6\n" ..
"SVN Xls : 1709519\n" ..
"P4 Content : 998125\n" ..
"BuildNo : #1\n" ..
"HostName : VPC36\n" ..
"Mfg. Date : 2026-11-14 19:53:09\n" ..
"Pipeline : #p-449984fb7f47431997aaff667cbc648e\n"

global_patch_make_time_map = {
    ["Patch Version"] = "4.7.0.21770",
    ["Mode"] = "TAPD",
    ["Branch"] = "Release4.7.0",
    ["Git Engine"] = "85c8c9418653e0138b69c48c4eef0611996a4f12",
    ["Git Survive"] = "ae80868ed5a9878a02d5e2eea09323191184f33d",
    ["Git Lua"] = "0a7d802d5c685940dad04d66c038bd95a34fa2d6",
    ["SVN Xls"] = "1709519",
    ["P4 Content"] = "998125",
    ["Pipeline"] =  "p-449984fb7f47431997aaff667cbc648e",
    ["BuildNo"] =  "#1",
    ["HostName"] = "VPC36",
    ["Mfg. Date"] = "2026-11-14 19:53:09",
}

global_patch_tss = "FAmDdh61WP0Cazpbq4U1Eg=="
