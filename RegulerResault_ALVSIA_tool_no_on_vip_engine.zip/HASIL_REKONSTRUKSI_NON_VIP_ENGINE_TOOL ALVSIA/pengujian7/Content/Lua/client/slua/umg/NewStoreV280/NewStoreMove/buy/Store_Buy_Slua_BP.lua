local Store_Buy_Slua_BP = {}
local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
local StoreUtils = require("client.slua.logic.store.utils.store_utils")

function Store_Buy_Slua_BP:ctor(selfType, shopInfo, buyInfo, selectedMoneyType, extraData)
  self.shopInfo = shopInfo
  self.buyInfo = buyInfo
  self.selectedMoneyType = selectedMoneyType
  self.currentDisCount = 0
  self.couponDiscountNum = 0
  self.bNeedShowNoValidCoupon = extraData and extraData.bNeedShowNoValidCoupon or false
  log(bWriteLog and "[store] Store_Buy_Slua_BP:ctor bNeedShowNoValidCoupon: " .. tostring(self.bNeedShowNoValidCoupon))
end

function Store_Buy_Slua_BP:OnInitialize()
  Store_Buy_Slua_BP.__super.OnInitialize(self)
  self.selectTypeIndex = 1
  self.selectPriceIndex = 1
  self.Store_Box_Item_UIBP_5 = self.UIRoot.Store_Box_Item_UIBP_5
  self.Image_106 = self.UIRoot.Image_106
  self.Image_8 = self.UIRoot.Image_8
  self.MoneyBlock = self.UIRoot.MoneyBlock
  self.BPSwitcher = self.UIRoot.BPSwitcher
  self.Btn_BP = self.UIRoot.Btn_BP
  self.Image_0 = self.UIRoot.Image_0
  self.Image_5 = self.UIRoot.Image_5
  self.UCSwitcher = self.UIRoot.UCSwitcher
  self.Btn_UC = self.UIRoot.Btn_UC
  self.Image_6 = self.UIRoot.Image_6
  self.Image_51 = self.UIRoot.Image_51
  self.SFSwitcher = self.UIRoot.SFSwitcher
  self.Btn_SF = self.UIRoot.Btn_SF
  self.Image_3 = self.UIRoot.Image_3
  self.Image_1 = self.UIRoot.Image_1
  self.GoldChipSwitcher = self.UIRoot.GoldChipSwitcher
  self.Button_0 = self.UIRoot.Button_0
  self.Image_7 = self.UIRoot.Image_7
  self.Image_9 = self.UIRoot.Image_9
  self.VIPDiscount = self.UIRoot.VIPDiscount
  self.UTRichTextBlock_0 = self.UIRoot.UTRichTextBlock_0
  self.Image_2 = self.UIRoot.Image_2
  self.WidgetSwitcher_1 = self.UIRoot.WidgetSwitcher_1
  self.Button_Buy = self.UIRoot.Button_Buy
  self.ScaleBox_8 = self.UIRoot.ScaleBox_8
  self.MoneyIcon = self.UIRoot.MoneyIcon
  self.PriceText = self.UIRoot.PriceText
  self.Button_DY_gj = self.UIRoot.Button_DY_gj
  self.Button_DY = self.UIRoot.Button_DY
  self.WidgetSwitcher_0 = self.UIRoot.WidgetSwitcher_0
  self.Image_4 = self.UIRoot.Image_4
  self.LoopScrollGrid_1 = self:InitScrollBox(self.UIRoot.LoopScrollGrid_1)
  self.Store_Buy_item_BP = self.UIRoot.Store_Buy_item_BP
  self.Store_Buy_item_BP_0 = self.UIRoot.Store_Buy_item_BP_0
  self.Store_Buy_item_BP_1 = self.UIRoot.Store_Buy_item_BP_1
  self.CouponDiscount = self.UIRoot.CouponDiscount
  self.ScaleBox_Coupon = self.UIRoot.ScaleBox_Coupon
  self.TextBlock_NoValidCoupon = self.UIRoot.TextBlock_NoValidCoupon
  self.Common_Popup_Medium_UIBP = self:InitCommonPopup(self.UIRoot.Common_Popup_Medium_UIBP)
  self.Common_Popup_Medium_UIBP:SetData(self, LocUtil.GetLocalizeResStr(43327))
end

function Store_Buy_Slua_BP:RegistEvents()
  Store_Buy_Slua_BP.__super.RegistEvents(self)
  self:AddOnClickedEventByControl(self.UIRoot.Btn_BP, self.OnBtn_BPClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.Btn_UC, self.OnBtn_UCClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.Btn_SF, self.OnBtn_SFClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_4, self.OnBtn_BattleClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_2, self.OnBtn_DiamondClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_0, self.OnButton_0Click, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Buy, self.OnButton_BuyClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_DY_gj, self.OnButton_DY_gjClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_DY, self.OnButton_DYClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Common, self.OnButton_CommonClick, self)
  self.LoopScrollGrid_1:SetRefreshItemCallback(self.OnRefreshLoopScrollGrid_1Item, self)
  self.LoopScrollGrid_1:AddItemWidgetChildEvent("Button_0", "OnClicked", self.OnClickLoopScrollGrid_1Item, self)
  self:AddCommonEvent(EVENTTYPE_COUPON, EVENTID_COUPON_CHANGE_PRICE, self.RefreshCoupon, self)
  self:AddCommonEvent(EVENTTYPE_COUPON, EVENTID_COUPON_VALID_LIST_CHANGE, self.UpdateNoCouponTips, self)
  self:AddControlEventByControl(self.UIRoot.TextBlock_UC_Explain, "OnHyperlinkClicked", self.OnPolicyHyperLinkClicked, self)
end

function Store_Buy_Slua_BP:OnPostInitialize()
  Store_Buy_Slua_BP.__super.OnPostInitialize(self)
  self:InitData()
  self:UpdateUI()
  local priceItem = self.buyUIInfo.priceListMap[self.selectTypeIndex]
  self:HandleCoupon(priceItem.priceList[self.selectPriceIndex])
  self:ShowSubscibeActEntrance()
end

function Store_Buy_Slua_BP:InitData()
  local store_buy_utils = require("client.slua.umg.NewStoreV280.NewStoreMove.buy.store_buy_utils")
  local buyUIInfo = store_buy_utils.GetBuyUIInfo(self.shopInfo, self.buyInfo)
  self.buyUIInfo = buyUIInfo
  self:FilterEveryDayZeroUC(self.buyUIInfo)
  if not buyUIInfo then
    log(bWriteLog and "Store_Buy_Slua_BP:InitData buyUIInfo nil")
    return
  end
  self.currentCouponId = 0
  self.currentDisCount = 0
  self:SelectMoneyType(self.selectedMoneyType)
end

function Store_Buy_Slua_BP:FilterEveryDayZeroUC(buyUIInfo)
  if not buyUIInfo or not next(buyUIInfo) then
    return
  end
  if not buyUIInfo.priceListMap or not next(buyUIInfo.priceListMap) then
    return
  end
  for _, v in pairs(buyUIInfo.priceListMap) do
    if v.moneyType == 2 and #v.priceList > 0 then
      local bZeroUCBuy = true
      local priceList = {}
      for key, price in pairs(v.priceList) do
        if 0 < price then
          bZeroUCBuy = false
        end
        if key == 1 then
          priceList[key] = price
        end
      end
      if bZeroUCBuy then
        v.priceList = priceList
      end
    end
  end
end

function Store_Buy_Slua_BP:UpdateUI()
  local buyUIInfo = self.buyUIInfo
  local itemId = buyUIInfo.shopInfo.item_id
  local itemCfg = CDataTable.GetTableData("Item", itemId)
  if not itemCfg then
    return
  end
  self.Store_Box_Item_UIBP_5.Name:SetText(itemCfg.ItemName)
  local UIUtil = require("client.common.ui_util")
  if itemCfg.ItemQuality == 0 then
    self.Store_Box_Item_UIBP_5.Label:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    self.Store_Box_Item_UIBP_5.Image_quality:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  else
    self:SetWidgetVisible(self.Store_Box_Item_UIBP_5.Label, false)
    self.Store_Box_Item_UIBP_5.Image_quality:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    local bgQuality = UIUtil.GetBgQualityPath(itemCfg.ItemQuality)
    self:SetTexture(self.Store_Box_Item_UIBP_5.Image_quality, bgQuality)
  end
  local iconPath, bHasAddKnownMissing = UIUtil.GetItemSmallIcon(itemId, self.Store_Box_Item_UIBP_5.Item)
  local params = {bHasAddKnownMissing = bHasAddKnownMissing}
  self:SetTexture(self.Store_Box_Item_UIBP_5.Item, iconPath, params)
  if itemCfg.SpecialIcon == "" then
    self.Store_Box_Item_UIBP_5.Logo:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  else
    self.Store_Box_Item_UIBP_5.Logo:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    local params = {sync = true, bMatchSize = true}
    self:SetTexture(self.Store_Box_Item_UIBP_5.Logo, itemCfg.SpecialIcon, params)
  end
  UIUtil.SetItemCoBrandedVisibility(itemId, self.Store_Box_Item_UIBP_5)
  local priceItem = buyUIInfo.priceListMap[self.selectTypeIndex]
  if not priceItem then
    return
  end
  local priceList = priceItem.priceList
  self.LoopScrollGrid_1:SetData(priceList)
  local switcherList = {
    self.BPSwitcher,
    self.SFSwitcher,
    self.UCSwitcher,
    self.UIRoot.WidgetSwitcher_2,
    self.UIRoot.WidgetSwitcher_0,
    self.GoldChipSwitcher
  }
  local typeMap = {
    0,
    1,
    2,
    3,
    6,
    103
  }
  local TableUtil = require("common.table_util")
  local moneyTypeNum = TableUtil.CountTable(buyUIInfo.moneyTypeMap)
  if moneyTypeNum <= 1 then
    for i = 1, #switcherList do
      switcherList[i]:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    end
  else
    for i = 1, #switcherList do
      if buyUIInfo.moneyTypeMap[typeMap[i]] then
        switcherList[i]:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
        if priceItem.moneyType == typeMap[i] then
          switcherList[i]:SetActiveWidgetIndex(1)
        else
          switcherList[i]:SetActiveWidgetIndex(0)
        end
      else
        switcherList[i]:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
    end
  end
  local buyBtnIndex = 0
  if priceItem.moneyType == 0 and priceItem.isVipItem then
    if self.shopInfo and self.shopInfo.is_vip_item and self.shopInfo.is_vip_item == StoreConst.vip_type_mode_both_prime then
      local SubscribeCarnivalSystem = require("client.slua.logic.subscribe.logic_subscribe_carnival_activity")
      if SubscribeCarnivalSystem.IsActivityOpen() and SubscribeCarnivalSystem.IsBothPrime() then
        buyBtnIndex = 0
      else
        buyBtnIndex = 3
      end
    elseif 2 >= self.selectPriceIndex then
      if 0 < buyUIInfo.curSubscribeStatus then
        buyBtnIndex = 0
      else
        buyBtnIndex = 2
      end
    elseif 2 <= buyUIInfo.curSubscribeStatus then
      buyBtnIndex = 0
    else
      buyBtnIndex = 1
    end
  else
    buyBtnIndex = 0
  end
  self.WidgetSwitcher_1:SetActiveWidgetIndex(buyBtnIndex)
  if priceItem.moneyType == 2 then
    self.ScaleBox_Coupon:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  else
    self.ScaleBox_Coupon:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  local curDiscountLimit = StoreConst.buy_info[self.shopInfo.id] and StoreConst.buy_info[self.shopInfo.id].daily_buy_cnt or 0
  if self.shopInfo.discountLimit and self.shopInfo.disCountPrice and self.shopInfo.discountDisplay and curDiscountLimit < self.shopInfo.discountLimit then
    priceItem.priceList[self.selectPriceIndex] = self.shopInfo.disCountPrice
  end
  local curPrice = priceItem.priceList[self.selectPriceIndex]
  if priceItem.moneyType == 0 then
    curPrice = self:GetSubscribeDiscountPrice(curPrice)
  end
  if buyUIInfo.isShowCoupon and priceItem.moneyType == 2 then
    curPrice = priceItem.priceList[self.selectPriceIndex] - self.currentDisCount
  end
  if curPrice < 0 then
    curPrice = 0
  end
  self.PriceText:SetText(tostring(curPrice))
  local store_buy_utils = require("client.slua.umg.NewStoreV280.NewStoreMove.buy.store_buy_utils")
  local myMoney = store_buy_utils.GetMyMoneyByType(priceItem.moneyType)
  if curPrice > myMoney then
    local slatecolor_6 = FSlateColor(FLinearColor(1.0, 0.0, 0.0, 1.0))
    self.PriceText:SetColorAndOpacity(slatecolor_6)
  else
    local slatecolor_9 = FSlateColor(FLinearColor(0.0, 0.0, 0.0, 1.0))
    self.PriceText:SetColorAndOpacity(slatecolor_9)
  end
  self:SetTexture(self.MoneyIcon, (StoreUtils.GetPriceIconByCurrency(priceItem.moneyType)))
end

function Store_Buy_Slua_BP:SelectMoneyType(moneyType)
  for k, v in pairs(self.buyUIInfo.priceListMap) do
    if v.moneyType == moneyType then
      self.selectTypeIndex = k
      break
    end
  end
end

function Store_Buy_Slua_BP:OnBtn_BPClick()
  self:PlayAudio(sound_config.click_v1)
  self:SelectMoneyType(0)
  self:UpdateUI()
end

function Store_Buy_Slua_BP:OnBtn_UCClick()
  self:PlayAudio(sound_config.click_v1)
  self:SelectMoneyType(2)
  local priceItem = self.buyUIInfo.priceListMap[self.selectTypeIndex]
  if priceItem.moneyType == 2 then
    EventSystem:postEvent(EVENTTYPE_COUPON, EVENTID_COUPON_PRICE_CHANGE, priceItem.priceList[self.selectPriceIndex])
  end
  self:UpdateUI()
end

function Store_Buy_Slua_BP:OnBtn_SFClick()
  self:PlayAudio(sound_config.click_v1)
  self:SelectMoneyType(1)
  self:UpdateUI()
end

function Store_Buy_Slua_BP:OnBtn_BattleClick()
  self:PlayAudio(sound_config.click_v1)
  self:SelectMoneyType(3)
  self:UpdateUI()
end

function Store_Buy_Slua_BP:OnBtn_DiamondClick()
  self:PlayAudio(sound_config.click_v1)
  self:SelectMoneyType(6)
  self:UpdateUI()
end

function Store_Buy_Slua_BP:OnButton_0Click()
  self:PlayAudio(sound_config.click_v1)
  self:SelectMoneyType(103)
  self:UpdateUI()
end

function Store_Buy_Slua_BP:OnButton_BuyClick()
  self:PlayAudio(sound_config.click_v1)
  if self.buyUIInfo.limitCount < 1 then
    if self.buyUIInfo.limitType == 1 then
      ShowNotice(4350)
    elseif self.buyUIInfo.limitType == 2 then
      ShowNotice(4351)
    elseif self.buyUIInfo.limitType == 3 then
      ShowNotice(4352)
    end
    return
  end
  local priceItem = self.buyUIInfo.priceListMap[self.selectTypeIndex]
  if not priceItem then
    return
  end
  local curPrice = priceItem.priceList[self.selectPriceIndex]
  if priceItem.moneyType == 0 then
    curPrice = self:GetSubscribeDiscountPrice(curPrice)
  end
  if self.isShowCoupon and priceItem.moneyType == 2 then
    curPrice = priceItem.priceList[self.selectPriceIndex] - self.currentDisCount
  end
  local PriceList = {
    {
      Type = priceItem.moneyType,
      Price = curPrice,
      Num = 1
    }
  }
  
  local function callback(data)
    local store_supply_manager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.store_supply_manager)
    store_supply_manager:buy_market_by_id_req(data)
  end
  
  local function comfirmPopup()
    local store_buy_utils = require("client.slua.umg.NewStoreV280.NewStoreMove.buy.store_buy_utils")
    local curPriceItem = self.buyUIInfo.priceListMap[self.selectTypeIndex]
    local couponId = curPriceItem and curPriceItem.moneyType == StoreConst.label_price_type_uc and self.currentCouponId or 0
    local data = store_buy_utils.GetBuyRequestData(self.buyUIInfo, self.selectTypeIndex, self.selectPriceIndex, couponId)
    data[StoreConst.label_buy_param_client_price] = self.buyUIInfo.priceListMap[self.selectTypeIndex].priceList[self.selectPriceIndex]
    local priceData = self.LoopScrollGrid_1:GetSetData()
    if 1 < #priceData then
      local itemCfg = CDataTable.GetTableData("Item", self.buyUIInfo.shopInfo.item_id)
      local limitTime = store_buy_utils.GetValidTimeByHour(data[StoreConst.label_buy_param_valid_hours], self.buyUIInfo.shopInfo.item_id)
      CommonMsgBoxMgr.Show(2, LocUtil.GetLocalizeResStr(5077), LocUtil.LocalizeResFormat(7000040, itemCfg.ItemName, limitTime), function()
        callback(data)
      end, nil, nil, {
        showUIKey = "com_msg_small_box_slua",
        isShowCheckBox = false
      })
    else
      callback(data)
    end
  end
  
  local checkMoney
  if self.currentDisCount > 0 then
    checkMoney = StoreUtils.CheckMoney(comfirmPopup, PriceList, self.currentDisCount)
  else
    checkMoney = StoreUtils.CheckMoney(comfirmPopup, PriceList)
  end
  self:CloseSelf()
end

function Store_Buy_Slua_BP:OnButton_DY_gjClick()
  self:PlayAudio(sound_config.click_v1)
  local store_buy_utils = require("client.slua.umg.NewStoreV280.NewStoreMove.buy.store_buy_utils")
  store_buy_utils.JumpToSubscribe(UIManager.UI_Config.Store_Buy_Slua_BP)
end

function Store_Buy_Slua_BP:OnButton_DYClick()
  self:PlayAudio(sound_config.click_v1)
  local store_buy_utils = require("client.slua.umg.NewStoreV280.NewStoreMove.buy.store_buy_utils")
  store_buy_utils.JumpToSubscribe(UIManager.UI_Config.Store_Buy_Slua_BP)
end

function Store_Buy_Slua_BP:OnButton_CommonClick()
  self:PlayAudio(sound_config.click_v1)
  local ui_subscribe_carnival_main = UIManager.GetUI(UIManager.UI_Config.ui_subscribe_carnival_main)
  if ui_subscribe_carnival_main and ui_subscribe_carnival_main:IsShow() then
    self:CloseSelf()
    return
  end
  local store_buy_utils = require("client.slua.umg.NewStoreV280.NewStoreMove.buy.store_buy_utils")
  store_buy_utils.JumpToSubscribe(UIManager.UI_Config.Store_Buy_Slua_BP, true)
end

function Store_Buy_Slua_BP:OnPolicyHyperLinkClicked()
  GlobalData.JumpUrl("game://?module=" .. tostring(BP_ENUM_MODULE_LOGINUSERPROTOCOL))
end

function Store_Buy_Slua_BP:OnRefreshLoopScrollGrid_1Item(widget, index)
  local priceItem = self.buyUIInfo.priceListMap[self.selectTypeIndex]
  if not priceItem then
    return
  end
  local priceList = priceItem.priceList
  if not priceList then
    return
  end
  local price = priceList[index]
  if not price then
    return
  end
  local curPrice = price
  if priceItem.moneyType == 0 then
    curPrice = self:GetSubscribeDiscountPrice(curPrice)
  end
  if self.buyUIInfo.isShowCoupon and priceItem.moneyType == 2 then
    local CouponSystem = require("client.slua.logic.coupon.logic_coupon")
    local IsReachLimitPrice = CouponSystem.IsReachLimitPrice(price)
    if IsReachLimitPrice then
      curPrice = price - self.couponDiscountNum
      if curPrice < 0 then
        curPrice = 0
      end
    end
  end
  local bSelected = index == self.selectPriceIndex
  local bShowVip = false
  if priceItem.moneyType == 0 and priceItem.isVipItem then
    bShowVip = true
  end
  local vipIndex = index - 1
  if self.shopInfo and self.shopInfo.is_vip_item and self.shopInfo.is_vip_item == StoreConst.vip_type_mode_both_prime then
    vipIndex = 3
  end
  if bSelected then
    self:SetUSPolicyText(priceItem.moneyType)
  end
  widget:InitPriceItem(priceItem.moneyType, curPrice, price, priceItem.validTimeList[index], bSelected, bShowVip, vipIndex)
end

function Store_Buy_Slua_BP:SetUSPolicyText(moneyType)
  local isUS = DataMgr.CheckIsNeedUSAPolicy()
  local CoinMacro = require("client.slua.config.ClientMacros.CoinMacro")
  local isPriceTypeUC = moneyType == StoreConst.label_price_type_uc or moneyType == CoinMacro.Uc
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_UC_Explain, isUS and isPriceTypeUC)
  if isUS then
    self.UIRoot.TextBlock_UC_Explain:SetText(LocUtil.GetLocalizeResStr(300001))
  end
end

function Store_Buy_Slua_BP:GetSubscribeDiscountPrice(price)
  if not price then
    return
  end
  if self.shopInfo and self.shopInfo.is_vip_item and (self.shopInfo.is_vip_item == StoreConst.vip_type_mode_primeplus or self.shopInfo.is_vip_item == StoreConst.vip_type_mode_prime) then
    local SubscribeCarnivalSystem = require("client.slua.logic.subscribe.logic_subscribe_carnival_activity")
    if SubscribeCarnivalSystem.IsActivityOpen() and SubscribeCarnivalSystem.IsBothPrime() then
      local discount_rate = SubscribeCarnivalSystem.GetBPExchangeDiscount()
      if discount_rate and 0 < discount_rate then
        return math.floor(price * (1 - discount_rate))
      end
    end
  end
  return price
end

function Store_Buy_Slua_BP:ShowSubscibeActEntrance()
  self.UIRoot.CanvasPanel_Discount:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  if self.shopInfo and self.shopInfo.is_vip_item and (self.shopInfo.is_vip_item == StoreConst.vip_type_mode_primeplus or self.shopInfo.is_vip_item == StoreConst.vip_type_mode_prime) then
    local SubscribeCarnivalSystem = require("client.slua.logic.subscribe.logic_subscribe_carnival_activity")
    if SubscribeCarnivalSystem.IsActivityOpen() and not SubscribeCarnivalSystem.IsBothPrime() then
      local child = SubscribeCarnivalSystem.CreateDisountItem(self, "CanvasPanel_Discount", function()
        self:OnButton_CommonClick()
      end)
      self.UIRoot.CanvasPanel_Discount:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    end
  end
end

function Store_Buy_Slua_BP:OnClickLoopScrollGrid_1Item(widget, index)
  self:PlayAudio(sound_config.click_v1)
  self.selectPriceIndex = index
  local priceItem = self.buyUIInfo.priceListMap[self.selectTypeIndex]
  if priceItem.moneyType == 2 then
    EventSystem:postEvent(EVENTTYPE_COUPON, EVENTID_COUPON_PRICE_CHANGE, priceItem.priceList[self.selectPriceIndex])
  end
  self:UpdateUI()
end

function Store_Buy_Slua_BP:RefreshCoupon()
  local CouponSystem = require("client.slua.logic.coupon.logic_coupon")
  local cur_coupon_itemid = CouponSystem.GetCurShowingCouponItemId()
  if not cur_coupon_itemid or cur_coupon_itemid == 0 then
    self.currentDisCount = 0
    self.currentCouponId = 0
    self:UpdateUI()
    return
  end
  local cur_coupon_info = CouponSystem.GetCouponInfoByItemId(cur_coupon_itemid)
  if not cur_coupon_info then
    log(bWriteLog and "cur_coupon_info == nil")
    return
  end
  log_tree("cur_coupon_info", cur_coupon_info)
  self.couponDiscountNum = cur_coupon_info.value
  if CouponSystem.IsLimitCoupon(cur_coupon_itemid) then
    local priceItem = self.buyUIInfo.priceListMap[self.selectTypeIndex]
    local curPrice = priceItem.priceList[self.selectPriceIndex]
    local IsReachLimitPrice = CouponSystem.IsReachLimitPrice(curPrice)
    if IsReachLimitPrice then
      self.currentDisCount = cur_coupon_info.value
      self.currentCouponId = cur_coupon_itemid
    else
      self.currentDisCount = 0
      self.currentCouponId = 0
    end
  else
    self.currentDisCount = cur_coupon_info.value
    self.currentCouponId = cur_coupon_itemid
  end
  self:UpdateUI()
end

function Store_Buy_Slua_BP:HandleCoupon(price)
  local comboBox
  local ShopCouponSystem = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_coupon_shop)
  local store_buy_utils = require("client.slua.umg.NewStoreV280.NewStoreMove.buy.store_buy_utils")
  local buyUIInfo = store_buy_utils.GetBuyUIInfo(self.shopInfo, self.buyInfo)
  if ShopCouponSystem.CurShopTab == StoreConst.Page_New_ID_Cloth then
    comboBox = self:CreateChildWindow(self.UIRoot.ScaleBox_Coupon, UIManager.UI_Config.ui_coupon_combobox, 1, nil, price, buyUIInfo.shopInfo.id)
  elseif StoreUtils.IsDirectBuyTab(ShopCouponSystem.CurShopTab) then
    comboBox = self:CreateChildWindow(self.UIRoot.ScaleBox_Coupon, UIManager.UI_Config.ui_coupon_combobox, 2, nil, price, buyUIInfo.shopInfo.id)
  elseif self.shopInfo.discountLimit and self.shopInfo.disCountPrice and self.shopInfo.discountDisplay then
    local nScene = ShopCouponSystem:GetCurShopScene()
    if nScene then
      comboBox = self:CreateChildWindow(self.UIRoot.ScaleBox_Coupon, UIManager.UI_Config.ui_coupon_combobox, nScene, nil, price, buyUIInfo.shopInfo.id)
    end
  end
end

function Store_Buy_Slua_BP:UpdateNoCouponTips(_, __, bHaveCopuon)
  log(bWriteLog and "[store] Store_Buy_Slua_BP:UpdateNoCouponTips")
  self.TextBlock_NoValidCoupon:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  if bHaveCopuon then
    return
  end
  if not self.bNeedShowNoValidCoupon then
    return
  end
  local priceItem = self.buyUIInfo.priceListMap[self.selectTypeIndex]
  if not priceItem then
    return
  end
  if priceItem.moneyType ~= 2 then
    return
  end
  self.TextBlock_NoValidCoupon:SetText(LocUtil.GetLocalizeResStr(43929))
  self.TextBlock_NoValidCoupon:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CStore_Buy_Slua_BP = class(ui_base, nil, Store_Buy_Slua_BP)
return CStore_Buy_Slua_BP
