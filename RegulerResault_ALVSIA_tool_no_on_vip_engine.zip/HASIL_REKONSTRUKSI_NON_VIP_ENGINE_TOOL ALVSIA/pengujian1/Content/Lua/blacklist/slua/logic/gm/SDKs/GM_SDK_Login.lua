local GM_SDK_Login = {
  {
    strButtonName = "GC Init",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local StoreGame = require("client.slua.logic.app_store.logic_store_game_interface")
      StoreGame:Init()
      gmUI:SetTips("Done")
    end
  },
  {
    strButtonName = "GC Login",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local StoreGame = require("client.slua.logic.app_store.logic_store_game_interface")
      local ret = StoreGame:AuthenticateLocalPlayer()
      gmUI:SetTips(" AuthenticateLocalPlayer done with ret: " .. tostring(ret))
    end
  },
  {
    strButtonName = "GC ReportAchievement",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local StoreGame = require("client.slua.logic.app_store.logic_store_game_interface")
      local ret = StoreGame:ReportAchievement("aaa", 20)
      gmUI:SetTips("ReportAchievement Done with ret: " .. tostring(ret))
    end
  },
  {
    strButtonName = "GP Login Manual",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local StoreGame = require("client.slua.logic.app_store.logic_store_game_interface")
      StoreGame:LoginGPManual()
      gmUI:SetTips(" LoginGPManual done with ret: ")
    end
  },
  {
    strButtonName = "GP UnlockGPAchievement",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local StoreGame = require("client.slua.logic.app_store.logic_store_game_interface")
      local ret = StoreGame:UnlockGPAchievement("CgkIzqKm6e0ZEAIQAw")
      gmUI:SetTips("ReportAchievement Done with ret: " .. tostring(ret))
    end
  },
  {
    strButtonName = "GP IncreaseGPAchievement",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local StoreGame = require("client.slua.logic.app_store.logic_store_game_interface")
      local ret = StoreGame:IncreaseGPAchievement("aaa", 20)
      gmUI:SetTips("ReportAchievement Done with ret: " .. tostring(ret))
    end
  },
  {
    strButtonName = "GP PGSRequestServerAuthCode",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local StoreGame = require("client.slua.logic.app_store.logic_store_game_interface")
      StoreGame:PGSRequestServerAuthCode()
      gmUI:SetTips("PGSRequestServerAuthCode Done with ret: ")
    end
  },
  {
    strButtonName = "RecoverGuest",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local IMSDKHelper = import("IMSDKHelper")
      local ret = IMSDKHelper.RecoverGuest("e57f02df1b523cf4a08a568084317eb8")
      if ret == true then
        gmUI:SetTips("set success")
        local login_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module)
        login_module:sendLogout()
      else
        gmUI:SetTips("set failed")
      end
    end
  },
  {
    strButtonName = "\230\163\128\230\159\165\231\187\145\229\174\154",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local IMSDKHelper = import("IMSDKHelper")
      local IMSDKHelperInstance = IMSDKHelper.GetInstance()
      if IMSDKHelperInstance:IsAlreadyBindUnifiedAccount() == true then
        gmUI:SetTips("Has bind")
      else
        gmUI:SetTips("Not bind")
      end
    end
  },
  {
    strButtonName = "\230\137\139\230\156\186\233\170\140\232\175\129\231\160\129",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local parameter = gmUI:GetCmd()
      if parameter ~= nil then
        local account = parameter
        local tLoginType = 2
        local areaCode = "86"
        local languageCode = "en_US"
        local codeType = 0
        local IMSDKHelper = import("IMSDKHelper")
        local IMSDKHelperInstance = IMSDKHelper.GetInstance()
        IMSDKHelperInstance:RequestVerifyCode(account, tLoginType, codeType, areaCode, languageCode, "")
        gmUI:SetTips("Done")
      else
        gmUI:SetTips("Command line is nil")
      end
    end
  },
  {
    strButtonName = "\233\130\174\231\174\177\233\170\140\232\175\129\231\160\129",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local parameter = gmUI:GetCmd()
      if parameter ~= nil then
        local account = parameter
        local tLoginType = 1
        local areaCode = "86"
        local languageCode = "en_US"
        local codeType = 0
        local IMSDKHelper = import("IMSDKHelper")
        local IMSDKHelperInstance = IMSDKHelper.GetInstance()
        IMSDKHelperInstance:RequestVerifyCode(account, tLoginType, codeType, areaCode, languageCode, "")
        gmUI:SetTips("Done")
      else
        gmUI:SetTips("Command line is nil")
      end
    end
  },
  {
    strButtonName = "\231\187\145\229\174\154",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local inputVerifyCode = gmUI:GetCmd()
      if inputVerifyCode ~= nil then
        local info = {}
        info.actionType = "register"
        info.account = "wilson61x@gmail.com"
        info.accountType = 1
        info.password = "1022061X"
        info.verifyCode = inputVerifyCode
        info.areaCode = "86"
        info.langType = "en_US"
        local extraJson = json.encode(info)
        local IMSDKHelper = import("IMSDKHelper")
        local IMSDKHelperInstance = IMSDKHelper.GetInstance()
        IMSDKHelperInstance:BindUnifiedAccount(extraJson)
        gmUI:SetTips("Done")
      else
        gmUI:SetTips("Command line is nil")
      end
    end
  },
  {
    strButtonName = "\229\188\185\231\153\187\229\189\149\233\130\174\231\174\177\230\182\136\230\129\175",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      ShowNotice(16194)
    end
  },
  {
    strButtonName = "tiktok\231\153\187\229\189\149\230\181\139\232\175\149",
    searchName = "",
    tips = "\228\188\154\230\152\190\231\164\186tiktok\231\153\187\229\189\149\239\188\140\230\157\128\232\191\155\231\168\139\229\164\177\230\149\136",
    fHandle = function(gmUI)
      local login_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module)
      login_module:SetGmLoginChannel("tiktok")
    end
  },
  {
    strButtonName = "whatsapp\231\153\187\229\189\149\230\181\139\232\175\149",
    searchName = "",
    tips = "\228\188\154\230\152\190\231\164\186whatsapp\231\153\187\229\189\149\239\188\140\230\157\128\232\191\155\231\168\139\229\164\177\230\149\136",
    fHandle = function(gmUI)
      local login_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module)
      login_module:SetGmLoginChannel("whatsapp")
    end
  },
  {
    strButtonName = "MSDK::GetChannelLoginResult",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local IMSDKHelper = import("IMSDKHelper")
      local ret = IMSDKHelper.GetInstance():GetChannelLoginResult()
      log("GetChannelLoginResult: " .. ret)
      gmUI:SetTips("Done:" .. tostring(ret))
    end
  },
  {
    strButtonName = "MSDK::GetAllQRCodeLoginResults",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local IMSDKHelper = import("IMSDKHelper")
      local ret = IMSDKHelper.GetInstance():GetAllQRCodeLoginResults()
      log("GetAllQRCodeLoginResults: " .. ret)
      gmUI:SetTips(" GetAllQRCodeLoginResults Done:" .. tostring(ret))
    end
  },
  {
    strButtonName = "MSDK::GetIMSDKClientApiParams",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local IMSDKHelper = import("IMSDKHelper")
      local ret = IMSDKHelper.GetInstance():GetIMSDKClientApiParams()
      local BusinessHelper = import("BusinessHelper")
      local afterDecode = BusinessHelper.Base64Decode(ret)
      log("base64: " .. ret)
      log("base64decode: " .. afterDecode)
      gmUI:SetTips("GetIMSDKClientApiParams Done:" .. tostring(ret))
    end
  },
  {
    strButtonName = "\231\155\145\229\144\172\231\187\145\229\174\154\228\186\139\228\187\182",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      EventSystem:registEvent(EVENTTYPE_BIND_INTL, EVENTID_INTL_BIND_NEED_SVR_PROCESSS, function(_, _, loginRet)
        log("EVENTID_INTL_BIND_NEED_SVR_PROCESSS callback")
        local SDKMacros = require("client.slua.config.ClientMacros.SDKMacros")
        if loginRet.imsdkRetCode == SDKMacros.IMSDKErrorCode.BIND_CMD_NEED_PROCESS_BY_SVR then
          local ret = loginRet.imsdkRetMsg
          local base64 = require("client.slua.logic.lobby_watermark.base64")
          local LoginVerifyHandler = require("client.network.Protocol.LoginVerifyHandler")
          local clientBase64Str = string.gsub(ret, "-", "+")
          clientBase64Str = string.gsub(clientBase64Str, "_", "/")
          local afterDecode = base64.DecodeBase64(clientBase64Str)
          if afterDecode.bind_params ~= nil then
            local bind_channel = afterDecode.bind_params.iBindChannel
            LoginVerifyHandler.send_account_social_bind_req(bind_channel, ret)
          elseif afterDecode.sacc_params ~= nil then
            LoginVerifyHandler.send_account_bind_sacc_req(ret, afterDecode.sacc_params.account, afterDecode.sacc_params.account_type, afterDecode.sacc_params.verify_code, afterDecode.sacc_params.area_code)
          else
            log("Donothing with bind result json: " .. afterDecode)
          end
        end
      end)
      gmUI:SetTips("GetIMSDKClientApiParams Done:")
    end
  },
  {
    strButtonName = "\232\142\183\229\143\150iMSDK\228\184\138\230\172\161\231\153\187\229\189\149\232\191\148\229\155\158\231\187\147\230\158\156",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local IMSDKHelper = import("IMSDKHelper")
      local ret = IMSDKHelper.GetInstance():GetLastLoginResultJson()
      log(ret)
      gmUI:SetTips("GetIMSDKClientApiParams Done:" .. tostring(ret))
    end
  },
  {
    strButtonName = "\230\181\139\232\175\149BindSuccess",
    searchName = "",
    cmd = "\230\181\139\232\175\149BindSuccess",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local IMSDKHelper = import("IMSDKHelper")
      local IMSDKHelperInstance = IMSDKHelper.GetInstance()
      local json_data = {
        code = 1,
        desc = "SUCCESS",
        iOpenid = "136665993577768",
        sInnerToken = "42164d1e1c0a71bb6522fb23371098d1",
        iGuid = "433731433156022",
        iChannel = 42,
        iGameId = 1320,
        sChannelId = "19650347879862",
        iExpireTime = 1719458453,
        sUserName = "accself_19650347879862",
        sBirthdate = "",
        iGender = 0,
        sPictureUrl = "",
        firstLoginTag = 0,
        iAccountType = 1,
        retExtraJson = "{\"iStatus\":1}",
        iKeepGuestTag = 0
      }
      IMSDKHelperInstance:UpdateIMSDKBindResult(json.encode(json_data))
      gmUI:SetTips("\230\181\139\232\175\149BindSuccess Done")
    end
  },
  {
    strButtonName = "QRCode Init",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local IMSDKQRCodeSystem = require("client.logic.login.logic_imsdk_qrcode")
      IMSDKQRCodeSystem:RegistEvents()
      gmUI:SetTips("Done")
    end
  },
  {
    strButtonName = "GenQRCode",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local IMSDKQRCodeSystem = require("client.logic.login.logic_imsdk_qrcode")
      IMSDKQRCodeSystem:GenerateQRCode()
      gmUI:SetTips("Done")
    end
  },
  {
    strButtonName = "InvalidateQRCode",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local IMSDKQRCodeSystem = require("client.logic.login.logic_imsdk_qrcode")
      IMSDKQRCodeSystem:InvalidateQRCode()
      gmUI:SetTips("Done")
    end
  },
  {
    strButtonName = "\230\137\147\229\188\128-\228\184\141\230\184\133\231\144\134\230\156\172\229\156\176\231\153\187\229\189\149\230\128\129",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local gameInstance = slua.getGameInstance()
      gameInstance:ExecuteCMD("gm.SkipClearIMSDKLoginResult", "true")
      gameInstance:ExecuteCMD("gm.GSkipClearLoginChannel", "true")
      gmUI:SetTips("Done")
    end
  },
  {
    strButtonName = "\229\133\179\233\151\173-\228\184\141\230\184\133\231\144\134\230\156\172\229\156\176\231\153\187\229\189\149\230\128\129",
    searchName = "",
    cmd = "x",
    tips = "Press OK button",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local gameInstance = slua.getGameInstance()
      gameInstance:ExecuteCMD("gm.SkipClearIMSDKLoginResult", "false")
      gameInstance:ExecuteCMD("gm.GSkipClearLoginChannel", "false")
      gmUI:SetTips("Done")
    end
  },
  {
    strButtonName = "\232\174\190\231\189\174\228\184\138\230\172\161\231\153\187\229\189\149\230\184\160\233\129\147",
    searchName = "SetIMSDKChannelID",
    cmd = "SetIMSDKChannelID 42",
    tips = "\229\143\130\230\149\176: channelId(\230\149\176\229\173\151)",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local channelId = cmdArgsTable and tonumber(cmdArgsTable[1])
      if not channelId then
        gmUI:SetTips("\232\175\183\232\190\147\229\133\165channelId, \228\190\139: 31")
        return
      end
      local IMSDKHelper = import("IMSDKHelper")
      local IMSDKHelperInstance = IMSDKHelper.GetInstance()
      IMSDKHelperInstance:SaveLastIMSDKChannelID(channelId)
      gmUI:SetTips("SaveLastIMSDKChannelID: " .. tostring(channelId))
    end
  },
  {
    strButtonName = "\230\159\165\232\175\162\230\156\128\232\191\145\231\153\187\229\189\149\230\184\160\233\129\147",
    searchName = "GetLastLoginChannels",
    cmd = "GetLastLoginChannels",
    tips = "\229\143\130\230\149\176(\229\143\175\233\128\137)\239\188\154did ugid\239\188\140\228\184\141\229\161\171\233\187\152\232\174\164\231\148\168\230\156\172\230\156\186did\229\146\140XID | \231\187\147\230\158\156\229\156\168Tips\229\146\140\230\151\165\229\191\151\233\135\140",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local did = cmdArgsTable and cmdArgsTable[1]
      local ugid = cmdArgsTable and cmdArgsTable[2] or ""
      if did == nil or did == "" then
        did = Client.GetPhoneDeviceID()
      end
      if did == "-" then
        did = ""
      end
      if ugid == "" then
        local DeviceOSInfo = require("client.logic.data.data_device_os")
        local xid = DeviceOSInfo.GetXID()
        if type(xid) == "string" and #xid == 64 then
          ugid = xid
        end
      end
      if (did == nil or did == "") and ugid == "" then
        gmUI:SetTips("did \229\146\140 ugid \228\184\141\232\131\189\229\144\140\230\151\182\228\184\186\231\169\186")
        return
      end
      local IMSDKHelper = import("IMSDKHelper")
      local IMSDKHelperInstance = IMSDKHelper.GetInstance()
      IMSDKHelperInstance.OnGetLastLoginChannelsDelegate:Clear()
      IMSDKHelperInstance.OnGetLastLoginChannelsDelegate:Add(function(retJson)
        log("GM GetLastLoginChannels ret: " .. tostring(retJson))
        local ret = json.decode(retJson)
        if ret == nil then
          gmUI:SetTips("\229\155\158\232\176\131\231\187\147\230\158\156\232\167\163\230\158\144\229\164\177\232\180\165: " .. tostring(retJson))
          return
        end
        local SDKMacros = require("client.slua.config.ClientMacros.SDKMacros")
        if ret.imsdkRetCode ~= SDKMacros.IMSDKErrorCode.SUCCESS then
          gmUI:SetTips(string.format("\230\159\165\232\175\162\229\164\177\232\180\165 imsdkRetCode=%s, msg=%s", tostring(ret.imsdkRetCode), tostring(ret.imsdkRetMsg)))
          return
        end
        local extra = ret.retExtraJson and ret.retExtraJson ~= "" and json.decode(ret.retExtraJson) or nil
        local channelList = extra and extra.aChannelList or {}
        local tipsList = {}
        for _, channelInfo in ipairs(channelList) do
          table.insert(tipsList, string.format("[iChannel=%s, sNickName=%s]", tostring(channelInfo.iChannel), tostring(channelInfo.sNickName)))
        end
        local tips = string.format("iTimestamp=%s, count=%d %s", tostring(extra and extra.iTimestamp), #channelList, table.concat(tipsList, " "))
        log("GM GetLastLoginChannels parsed: " .. tips)
        gmUI:SetTips(tips)
      end)
      IMSDKHelperInstance:GetLastLoginChannels(did, ugid)
      gmUI:SetTips(string.format("\229\183\178\229\143\145\232\181\183\230\159\165\232\175\162, did=%s, ugid=%s, \231\173\137\229\190\133\229\155\158\232\176\131...", tostring(did), tostring(ugid)))
    end
  },
  {
    strButtonName = "\230\168\161\230\139\159\231\153\187\229\189\149\229\164\177\232\180\165\233\148\153\232\175\175\231\160\129",
    searchName = "login_error",
    cmd = "gm_simulate_login_error 4",
    tips = "\229\143\130\230\149\176\239\188\154\228\184\128\231\186\167\233\148\153\232\175\175\231\160\129 \228\186\140\231\186\167\233\148\153\232\175\175\231\160\129",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local eventParam = cmdArgsTable[1] and tonumber(cmdArgsTable[1])
      local eventParam2 = cmdArgsTable[2] and tonumber(cmdArgsTable[2])
      gmUI:SetTips(string.format("\230\168\161\230\139\159 ep=%s, ep2=%s", eventParam, eventParam2))
      NetUtil.OnNetworkEvent(2, eventParam, eventParam2, true)
    end
  },
  {
    strButtonName = "\230\168\161\230\139\159\231\153\187\229\189\149\229\164\177\232\180\165\233\148\153\232\175\175\231\160\129(itop\230\150\176)",
    searchName = "test_login_err_code",
    cmd = "test_login_err_code 9999 0 Android VK",
    tips = "\230\181\139\232\175\149 LoginErrorCodeConfig \233\133\141\232\161\168\229\133\168\233\147\190\232\183\175 | \229\143\130\230\149\176: EventParam EventParam2 System LoginChannel",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local logic_login_event = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_login_event)
      local ep = cmdArgsTable[1] and tonumber(cmdArgsTable[1])
      local ep2 = cmdArgsTable[2] and tonumber(cmdArgsTable[2])
      local sys = cmdArgsTable[3] or ""
      local chn = cmdArgsTable[4] or ""
      if not ep or not ep2 then
        gmUI:SetTips("test_login_err_code <EventParam> <EventParam2> [System] [LoginChannel]")
        return
      end
      local mockErrorCode = string.format("[%d]-[%d]-%s-%s", ep, ep2 or -1, sys, chn)
      gmUI:SetTips(string.format("mockErrorCode: %s", mockErrorCode))
      logic_login_event:ShowLoginFailNotice("test_notice", nil, ep, ep2, mockErrorCode)
    end
  },
  {
    strButtonName = "\230\139\137\232\181\183\231\171\175\229\164\150\231\153\187\229\189\149",
    searchName = "LaunchWebLogin",
    cmd = "gm_launch_web_login https://itopcdn.igamecj.com/web/test/sample/index.html 123321",
    tips = "\229\143\130\230\149\176\239\188\154url appId\239\188\140\231\169\186\230\160\188\229\136\134\233\154\148",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local url = cmdArgsTable and cmdArgsTable[1]
      local appId = cmdArgsTable and cmdArgsTable[2]
      if not url or not appId then
        gmUI:SetTips("please input url and appId, e.g.: https://xxx.com appid123")
        return
      end
      local logic_account_protect_setting = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_account_protect_setting)
      logic_account_protect_setting:LaunchWebLogin(url, appId)
      gmUI:SetTips("LaunchWebLogin url=" .. tostring(url) .. " appId=" .. tostring(appId))
    end
  },
  {
    strButtonName = "[\230\181\139]\229\176\143\229\140\133fb\229\165\189\229\143\139\229\144\140\231\142\169-\230\139\137\232\181\183\230\142\136\230\157\131",
    searchName = "LaunchLoginAutho",
    tips = "\232\176\131\231\148\168 logic_friend_spk_fb:LaunchLoginAutho \230\139\137\232\181\183\230\181\143\232\167\136\229\153\168\230\142\136\230\157\131",
    fHandle = function(gmUI)
      local logic_friend_spk_fb = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_spk_fb)
      logic_friend_spk_fb:ForceValid(true)
      logic_friend_spk_fb:LaunchLoginAutho()
      gmUI:SetTips("LaunchLoginAutho Done, isInProgress=" .. tostring(logic_friend_spk_fb.isInProgress))
    end
  },
  {
    strButtonName = "[\230\181\139]\229\176\143\229\140\133fb\229\165\189\229\143\139\229\144\140\231\142\169-\229\143\150\230\182\136\229\188\186\229\136\182\229\144\175\231\148\168",
    searchName = "SpkFbForceValid",
    tips = "\229\133\179\233\151\173 logic_friend_spk_fb \231\154\132\229\188\186\229\136\182\229\144\175\231\148\168\230\160\135\232\174\176",
    fHandle = function(gmUI)
      local logic_friend_spk_fb = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_spk_fb)
      logic_friend_spk_fb:ForceValid(false)
      gmUI:SetTips("ForceValid = false")
    end
  },
  {
    strButtonName = "[\230\181\139]FB\231\153\187\229\189\149\229\188\130\229\184\184\232\189\172\231\189\145\233\161\181\231\153\187\229\189\149",
    searchName = "FBWebLogin",
    cmd = "gm_fb_web_login -152",
    tips = "\230\168\161\230\139\159FB\231\153\187\229\189\149\230\156\141\229\138\161\229\153\168\233\148\153\232\175\175(211)+\230\140\135\229\174\154thirdCode\239\188\140\232\181\176\229\174\140\230\149\180\229\188\185\230\161\134->\231\189\145\233\161\181\231\153\187\229\189\149\233\147\190\232\183\175 | \229\143\130\230\149\176: thirdCode(\233\187\152\232\174\164-152)",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local thirdCode = cmdArgsTable and cmdArgsTable[1] and tonumber(cmdArgsTable[1])
      thirdCode = thirdCode or -152
      local login_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module)
      login_module.nLoginType = BP_ENUM_PLAYFORM_BGBG
      login_module:SetLoginAble(true)
      local logic_fb_web_login = require("client.logic.login.logic_fb_web_login")
      logic_fb_web_login.bCurLoginIsWeb = false
      local bHandled = logic_fb_web_login:HandleLoginFail(211, thirdCode)
      gmUI:SetTips(string.format("HandleLoginFail(211, %s) handled=%s", tostring(thirdCode), tostring(bHandled)))
    end
  },
  {
    strButtonName = "[\230\181\139]FB\231\189\145\233\161\181\231\153\187\229\189\149\232\174\176\229\189\149-\230\159\165\231\156\139",
    searchName = "FBWebLoginRecordDump",
    tips = "\230\137\147\229\141\176\230\156\172\229\156\176FB\231\189\145\233\161\181\231\153\187\229\189\149\232\174\176\229\189\149\229\143\138\230\152\175\229\144\166\229\156\168\230\156\137\230\149\136\230\156\159\229\134\133",
    fHandle = function(gmUI)
      local logic_fb_web_login = require("client.logic.login.logic_fb_web_login")
      local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
      local record = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eFBWebLoginRecord)
      local saveTime = type(record) == "table" and record.time or nil
      gmUI:SetTips(string.format("time=%s thirdCode=%s valid=%s expireDays=%s enable=%s", tostring(saveTime), tostring(type(record) == "table" and record.thirdCode or nil), tostring(logic_fb_web_login:IsRecordValid()), tostring(logic_fb_web_login:GetExpireSeconds() / 86400), tostring(logic_fb_web_login:IsEnable())))
    end
  },
  {
    strButtonName = "[\230\181\139]FB\231\189\145\233\161\181\231\153\187\229\189\149\232\174\176\229\189\149-\230\184\133\233\153\164",
    searchName = "FBWebLoginRecordClear",
    tips = "\230\184\133\233\153\164\230\156\172\229\156\176\232\174\176\229\189\149\239\188\140\229\185\182\230\138\138IMSDK\231\154\132FB\231\153\187\229\189\149\230\150\185\229\188\143\229\144\140\230\173\165\229\134\153\229\155\158\229\142\159\231\148\159(config.db\230\152\175\230\140\129\228\185\133\229\140\150\231\154\132\239\188\140\229\191\133\233\161\187\230\152\190\229\188\143\229\134\153OFF)",
    fHandle = function(gmUI)
      local logic_fb_web_login = require("client.logic.login.logic_fb_web_login")
      logic_fb_web_login:ClearRecord()
      logic_fb_web_login.bCurLoginIsWeb = false
      logic_fb_web_login.bForceWebOnce = false
      local bOK = logic_fb_web_login:ApplyWebLoginConfig(false)
      gmUI:SetTips("FB web login record cleared, config reset to native = " .. tostring(bOK))
    end
  }
}
return GM_SDK_Login
