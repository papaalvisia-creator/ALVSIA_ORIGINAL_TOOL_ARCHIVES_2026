local logic_login_event = {}
local normalEvent = {
  [9999] = 1,
  [211] = 1
}
local eventParam2ToErrorCode = {
  [2002] = 18010163,
  [2500] = 18010164,
  [2515] = 18010161,
  [2516] = 18010170,
  [2517] = 18010170,
  [2518] = 18010169
}
local BBindBeforeLogin = HDmpveRemote.HDmpveRemoteConfigGetBool("BBindBeforeLogin", false)

function logic_login_event:DefineAndResetData()
end

function logic_login_event:OnInitialize()
end

function logic_login_event:RegistEvents()
end

function logic_login_event:OnLogin(bReLogin)
end

function logic_login_event:OnLogOut()
end

function logic_login_event:OnPreSwitchGameStatus(preState, nextState)
end

function logic_login_event:OnPostSwitchGameStatus(preState, nextState)
end

local channelNeedUrlTb = {
  [41] = 1,
  [42] = 1,
  [2] = 1,
  [46] = 1
}

function logic_login_event:HandleLoginResult(eventParam, eventParam2)
  local normalRes = eventParam2ToErrorCode[eventParam2]
  local IMSDKSystem = require("client.logic.login.logic_imsdk")
  local SDKMacros = require("client.slua.config.ClientMacros.SDKMacros")
  local IMSDKServerError = SDKMacros.IMSDKServerErrorCode
  local DevicePlatformNameMacros = require("client.slua.config.ClientMacros.DevicePlatformNameMacros")
  IMSDKSystem.StopIMSDKTimer()
  NetUtil.noRefreshLogout = false
  local SettingAccount = require("client.logic.setting.logic_setting_account")
  SettingAccount.SetunifiedAccountLogging(false)
  local SVPNSystem = require("client.slua.logic.gamemaster.logic_svpn")
  SVPNSystem.OnIMSDKLoginResult(eventParam)
  local logic_http_dns = require("client.slua.logic.httpdns.logic_http_dns")
  logic_http_dns:OnMSDKLogin()
  local logic_imsdk_interface = require("client.logic.login.logic_imsdk_interface")
  logic_imsdk_interface:OnMSDKLogin()
  local login_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module)
  local curStatus = GameStatus.GetGameStatus()
  if eventParam ~= 0 then
    login_module:ShowButtonsAfterLoginFailed()
    if eventParam ~= 106 and eventParam ~= 611 and eventParam ~= 701 and eventParam ~= 2 then
      NetUtil.LogoutNoRefresh()
    end
    EventSystem:postEvent(EVENTTYPE_LOGIN, EVENTID_LOGIN_FAIL_NETUTIL)
    local logic_fb_web_login = require("client.logic.login.logic_fb_web_login")
    if logic_fb_web_login:HandleLoginFail(eventParam, eventParam2) then
      return
    end
  end
  if eventParam == 0 then
    log(bWriteLog and "logic_login_event:HandleLoginResult login ok")
    login_module:ClearLoginCountAndTime()
    EventSystem:postEvent(EVENTTYPE_LOGIN, EVENTID_LOGIN_SUCCESS_NETUTIL)
    local logic_cloud_game = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_cloud_game)
    logic_cloud_game:SendMessageToCloudGame(logic_cloud_game.ProtocolName.SDKLoginSuccess)
    
    local function UpdateEndCallBack()
      log(bWriteLog and "UpdateEndCallBack")
      local channel = Client.GetLoginChannel(NetInterface)
      log(bWriteLog and "UpdateEndCallBack authorization login ok, channel = " .. tostring(channel))
      if channel == BP_ENUM_PLAYFORM_UnifiedAccountByiTOP then
        local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
        if login_module.phoneMailType ~= 0 then
          local tb = {
            unified_type = login_module.phoneMailType
          }
          log(bWriteLog and "UpdateEndCallBack save unified_type = " .. tostring(tb.unified_type))
          PlayerPrefsSystem.SaveTableToFile_N(tb, PlayerPrefsSystem.ePlayerPrefsType.eMailPhoneLoginType)
        end
      end
      if globalConfig.IsDirectConnect() == false and globalConfig.isSupervision == false then
        log(bWriteLog and "UpdateEndCallBack hideAuthorizationUI")
        local serverName = Client.GetUEPUBGMServerName()
        log(bWriteLog and "UpdateEndCallBack serverName: " .. tostring(serverName))
        if Client.IsUEPUBGM() and serverName ~= "" then
          login_module:LoginByCp(serverName)
        else
          login_module:Transition(login_module.ELoginFSMEvent.Event_LTCS)
          if channel == BP_ENUM_PLAYFORM_WX and curStatus == GameStatus.Login then
            ShowNotice(101709, true)
          end
        end
      else
        log(bWriteLog and "UpdateEndCallBack Connect to Gate Directly")
        login_module:ConnectToGate()
      end
    end
    
    local version_up_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.version_up_module)
    log(bWriteLog and "logic_login_event:HandleLoginResult, alreadyGrayUpdate = " .. tostring(version_up_module.bAlreadyGrayUpdate))
    if not version_up_module.bAlreadyGrayUpdate then
      version_up_module:StartGrayUpdate(UpdateEndCallBack)
    else
      UpdateEndCallBack()
    end
    NetUtil.needInitCentauriWhenLogin = true
  elseif eventParam == 3 then
    log(bWriteLog and "logic_login_event:HandleLoginResult auth fail need retry")
    self:ShowLoginFailNotice(LocUtil.GetLocalizeResStr(101713), nil, eventParam, eventParam2)
  elseif eventParam == 106 then
    log(bWriteLog and "logic_login_event:HandleLoginResult auth fail for user cancel")
    self:ShowLoginFailNotice(LocUtil.GetLocalizeResStr(101711), nil, eventParam, eventParam2)
  elseif eventParam == 701 then
    if curStatus == GameStatus.Login then
      self:ShowLoginFailNotice(LocUtil.GetLocalizeResStr(4188), nil, eventParam, eventParam2)
    end
  elseif eventParam == 1001 or eventParam == 1002 then
    log(bWriteLog and "logic_login_event:HandleLoginResult QuickLogin Fail eventParam:" .. tostring(eventParam))
  elseif (eventParam == 211 or eventParam == 9999) and eventParam2 == 2146 then
    if curStatus == GameStatus.Login then
      local LogicCustomerService = require("client.slua.logic.CustomerService.LogicCustomerService")
      self:ShowLoginFailNotice(LocUtil.GetLocalizeResStr(778877), {
        urlHandle = function()
          LogicCustomerService.HelpshiftShowFAQsWithInfo()
        end
      }, eventParam, eventParam2)
    end
  elseif normalEvent[eventParam] and normalRes then
    self:ShowLoginFailNotice(LocUtil.GetLocalizeResStr(normalRes or 778877), nil, eventParam, eventParam2)
  elseif (eventParam == 211 or eventParam == 9999) and eventParam2 == IMSDKServerError.CHANNEL_OPENID_BANED then
    local IMSDKHelper = import("IMSDKHelper")
    local loginRetJson = IMSDKHelper.GetInstance():GetLastLoginResultJson()
    local loginRet = json.decode(loginRetJson)
    if loginRet.thirdRetCode == IMSDKServerError.CHANNEL_OPENID_BANED then
      local thridMsgJson = loginRet.thirdRetMsg
      local thridMsg = json.decode(thridMsgJson)
      local openid = thridMsg.iOpenid
      local channel = thridMsg.iChannel
      local msg = thridMsg.msg
      local bandEndTime = thridMsg.iBanEnd
      login_module:ShowFreezePopupUI(openid, channel, bandEndTime)
    end
  elseif 9999 <= eventParam and eventParam <= 100000 then
    login_module:UpdateLoginCountAndTime()
    if curStatus == GameStatus.Login then
      self:ShowLoginFailNotice(NetUtil.GetSDKErrorNotice(eventParam, eventParam2), nil, eventParam, eventParam2)
    end
  elseif eventParam == 611 then
    local client_imsdk_eventparam = require("client.logic.ClientEntry.client_imsdk_eventparam")
    local channel = Client.GetLoginChannel(NetInterface)
    log(bWriteLog and "logic_login_event:HandleLoginResult login failed eventParam:" .. tostring(eventParam) .. " channel:" .. tostring(channel))
    if client_imsdk_eventparam.channel2ItopErrorCodeTable[channel] and not channelNeedUrlTb[channel] then
      local data = {
        ItopErrorCode = client_imsdk_eventparam.channel2ItopErrorCodeTable[channel],
        eventParam2 = eventParam2,
        channel = channel
      }
      UIManager.ShowUI(UIManager.UI_Config.Protection_UIBP, data)
      return
    else
      login_module:UpdateLoginCountAndTime()
      self:ShowLoginFailNotice(NetUtil.GetSDKErrorNotice(eventParam, eventParam2), nil, eventParam, eventParam2)
    end
  else
    log(bWriteLog and "logic_login_event:HandleLoginResult login failed eventParam:" .. tostring(eventParam))
    if eventParam ~= -1 and eventParam ~= 6 and eventParam ~= 7 and eventParam ~= 106 and eventParam ~= 107 and eventParam ~= 109 and eventParam ~= 200 then
      if curStatus ~= GameStatus.Login then
        return
      end
      login_module:UpdateLoginCountAndTime()
      self:ShowLoginFailNotice(NetUtil.GetSDKErrorNotice(eventParam, eventParam2), nil, eventParam, eventParam2)
      return
    end
    login_module:UpdateLoginCountAndTime()
    login_module:ShowLoginUI()
    if eventParam == 7 and DevicePlatformNameMacros.IsPC() then
      ShowNotice(101710)
    end
  end
end

function logic_login_event:ShowLoginFailNotice(notice, extraParams, eventParam, eventParam2, _mockErrorCode)
  local TimeUtil = require("client.common.time_util")
  local IMSDKHelper = import("IMSDKHelper")
  local errorCode = _mockErrorCode
  if not errorCode or errorCode == "" then
    errorCode = IMSDKHelper:GetDisplayLoginErrorCode()
  end
  if not errorCode or errorCode == "" then
    errorCode = string.format("(%s,%s)", tostring(eventParam or "?"), tostring(eventParam2 or "?"))
  end
  local nEventParam, nEventParam2, strSystem, strLoginChannel
  if errorCode and errorCode ~= "" then
    nEventParam, nEventParam2, strSystem, strLoginChannel = errorCode:match("%[(.+)%]%-%[(.+)%]%-(.+)%-(.+)$")
  end
  local matchedNotice = self:MatchLoginErrorCodeConfig(tonumber(nEventParam) or eventParam, tonumber(nEventParam2) or eventParam2, strSystem or "", strLoginChannel or "")
  if matchedNotice then
    notice = matchedNotice
  end
  local fullNotice = LocUtil.LocalizeResFormat(89291, notice, LocUtil.LocalizeResFormat(76933, errorCode), TimeUtil.GetServerTimeInSec(), IMSDKHelper:GetSessionId())
  local title = LocUtil.GetLocalizeResStr(101001)
  local channel = Client.GetLoginChannel(NetInterface)
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  if BBindBeforeLogin and PublishRegionMacros.IsGlobalOperationRegion() and channelNeedUrlTb[channel] then
    extraParams = {
      urlTips = LocUtil.GetLocalizeResStr(180163),
      urlHandle = function()
        log(bWriteLog and "ShowLoginFailNotice.  jump h5")
        local CSJumpModule = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.CSJumpModule)
        CSJumpModule:BindBeforeLogin(eventParam, eventParam2)
      end
    }
  end
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  if extraParams then
    CommonMsgBoxMgr.Show(1, title, fullNotice, nil, nil, nil, nil, extraParams)
  else
    CommonMsgBoxMgr.Show(1, title, fullNotice)
  end
end

function logic_login_event:MatchLoginErrorCodeConfig(eventParam, eventParam2, system, loginChannel)
  if not (eventParam and eventParam2 and loginChannel) or not system then
    return nil
  end
  local row = CDataTable.GetTableDataByFilter("LoginErrorCodeConfig", "EventParam", eventParam, "EventParam2", eventParam2, "System", string.lower(system), "LoginChannel", string.lower(loginChannel))
  if row and row.TextID and row.TextID ~= 0 then
    return LocUtil.GetLocalizeResStr(row.TextID)
  end
  return nil
end

local class = require("class")
local CModuleBase = require("client.module_framework.ModuleBase")
local CLogicLoginEvent = class(CModuleBase, nil, logic_login_event)
return CLogicLoginEvent
