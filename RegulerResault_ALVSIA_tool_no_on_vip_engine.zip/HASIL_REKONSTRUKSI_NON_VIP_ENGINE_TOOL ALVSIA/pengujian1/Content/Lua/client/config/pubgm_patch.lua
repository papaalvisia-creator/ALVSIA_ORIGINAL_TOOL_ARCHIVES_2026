-- !!! DO NOT MODIFY THIS FILE. !!!
-- AUTO GENERATE BY pubgm_patch.py 2026-11-12 20:01:59
global_patch_make_time = "" ..
"Patch Version : 4.7.0.21760\n" ..
"Mode : TAPD\n" ..
"Branch : Release4.7.0\n" ..
"Git Engine : 85c8c9418653e0138b69c48c4eef0611996a4f12\n" ..
"Git Survive : d7b5922c211ca8dc08b58d2e93b6619f80084750\n" ..
"Git Lua : e98663256e8c653f26d159e4f00786a6fe493717\n" ..
"SVN Xls : 1707498\n" ..
"P4 Content : 997158\n" ..
"BuildNo : #1\n" ..
"HostName : PUBGM-VPC68\n" ..
"Mfg. Date : 2026-11-12 20:01:59\n" ..
"Pipeline : #p-cc3b4324542f4168a9a0638d1266cb56\n"

global_patch_make_time_map = {
    ["Patch Version"] = "4.7.0.21760",
    ["Mode"] = "TAPD",
    ["Branch"] = "Release4.7.0",
    ["Git Engine"] = "85c8c9418653e0138b69c48c4eef0611996a4f12",
    ["Git Survive"] = "d7b5922c211ca8dc08b58d2e93b6619f80084750",
    ["Git Lua"] = "e98663256e8c653f26d159e4f00786a6fe493717",
    ["SVN Xls"] = "1707498",
    ["P4 Content"] = "997158",
    ["Pipeline"] =  "p-cc3b4324542f4168a9a0638d1266cb56",
    ["BuildNo"] =  "#1",
    ["HostName"] = "PUBGM-VPC68",
    ["Mfg. Date"] = "2026-11-12 20:01:59",
}

global_patch_tss = "H65BFlEcyB3/eBm7WC/MHw=="
