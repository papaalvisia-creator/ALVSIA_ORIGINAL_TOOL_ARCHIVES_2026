local logic_familycenter = {}

local function FCLog(methodName, formatText, ...)
  if not bWriteLog then
    return
  end
  local message = "[logic_familycenter] " .. tostring(methodName)
  if formatText and formatText ~= "" then
    message = message .. " " .. string.format(formatText, ...)
  end
  log(message)
end

local logOnceCache = {}

local function FCLogOnce(methodName, formatText, ...)
  local message = formatText
  if select("#", ...) > 0 then
    message = string.format(formatText, ...)
  end
  local key = tostring(methodName) .. "|" .. tostring(formatText)
  if logOnceCache[key] == message then
    return
  end
  logOnceCache[key] = message
  FCLog(methodName, "%s", message)
end

local function FCLogTree(methodName, label, value)
  if not bWriteLog then
    return
  end
  local prefix = string.format("[logic_familycenter] %s %s", tostring(methodName), tostring(label))
  if value == nil then
    log(prefix .. "nil")
    return
  end
  log_tree(prefix, value)
end

local familycenter_macro = require("client.slua.logic.familycenter.familycenter_macro")
local Scene = familycenter_macro.ENUM_SCENE
local Result = familycenter_macro.ENUM_RESULT
local SCENE_FIELD_MAP = familycenter_macro.SCENE_FIELD_MAP
local SWITCH_ONLY_SCENES = {
  [Scene.TREASURE_CHEST] = true,
  [Scene.OVERUSE_LIMIT] = true,
  [Scene.CREATOR] = true,
  [Scene.MINOR_PRIVACY_OFF] = true
}
local MINOR_BLOCK_RESULT_BY_SCENE = {
  [Scene.TREASURE_CHEST] = Result.MINOR_CHEST_BLOCKED,
  [Scene.CREATOR] = Result.MINOR_CREATOR_BLOCKED,
  [Scene.OVERUSE_LIMIT] = Result.MINOR_OVERUSE_BLOCKED
}
local PopupType = familycenter_macro.ENUM_POPUP_TYPE
local FAMILYCENTER_PRODUCTION_BASE_URL = "https://familycenter.levelinfinite.com"
local FAMILYCENTER_TEST_BASE_URL = "https://familycenter-test.levelinfinite.com"
local RAW_STATUS_FETCH_TIMEOUT_SECONDS = 3
local NEW_FLOW_FETCH_TIMEOUT_SECONDS = 3
local COMPLIANCE_FLAGS_FETCH_TIMEOUT_SECONDS = 3
local LOC_ID_MINOR_SERVICE_BLOCKED_TIP = 200009003
local LOC_ID_CHEST_IP_BLOCKED_TIP = 75606
local CHEST_IP_HARD_BLOCK_COUNTRIES = {BR = true}
local SDK_UNAVAILABLE_FAIL_CLOSED_IP_COUNTRIES = {BR = true}
local SDK_FIELD_MAP = {
  adultStatus = "adult_check_status",
  adultStatusExpiration = "adult_check_status_expiration",
  adultCheckStatusExpiration = "adult_check_status_expiration",
  needAdultVerification = "need_adult_verification",
  adultVerificationStatus = "adult_verification_status",
  needParentAdultVerification = "need_parent_adult_verification",
  parentAdultVerificationStatus = "parent_adult_verification_status",
  realnameAuthType = "realname_auth_type",
  realNameAuthType = "realname_auth_type",
  adultVerificationType = "adult_verification_type",
  parentAdultVerificationType = "parent_adult_verification_type",
  needVoiceControlInGame = "need_voice_control_ingame",
  voiceControlStatus = "voice_control_status",
  needLBSControl = "need_lbs_control",
  needLBSControlInGame = "need_lbs_control_ingame",
  lBSControlStatus = "lbs_control_status",
  needUserPayment = "need_user_payment",
  userPaymentStatus = "user_payment_status",
  needUserDataUsedForAI = "need_user_data_used_for_ai",
  userDataUsedForAIStatus = "user_data_used_for_ai_status",
  needPersonalReco = "need_personal_reco",
  personalRecoStatus = "personal_reco_status",
  needShareUserData = "need_share_user_data",
  shareUserDataStatus = "share_user_data_status",
  needUseSocialFunction = "need_use_social_function",
  useSocialFunctionStatus = "use_social_function_status",
  needParticipateSurvey = "need_participate_survey",
  participateSurveyStatus = "participate_survey_status",
  needReceiveMarketingEmail = "need_receive_marketing_email",
  receiveMarketingEmailStatus = "receive_marketing_email_status",
  parentCertificateStatus = "parent_certificate_status",
  parentCertificateStatusExpiration = "parent_certificate_status_expiration",
  needParentControl = "need_parent_control",
  eUUserAgreeStatus = "eu_user_agree_status",
  euUserAgreeStatus = "eu_user_agree_status",
  EUUserAgreeStatus = "eu_user_agree_status",
  needRealnameVerification = "need_realname_verification",
  needRealNameVerification = "need_realname_verification",
  realnameAuthStatus = "realname_auth_status",
  realNameAuthStatus = "realname_auth_status",
  needRealnameAuth = "need_realname_auth",
  needRealNameAuth = "need_realname_auth",
  adultCheckStatusTs = "adult_check_status_ts",
  adultCheckStatusTS = "adult_check_status_ts",
  statusTs = "status_ts",
  statusTS = "status_ts",
  tS = "status_ts",
  pcStatusTs = "pc_status_ts",
  pcStatusTS = "pc_status_ts",
  playerEmail = "player_email",
  birthday = "birthday",
  certificateType = "certificate_type",
  adultAge = "adult_age",
  gameGrade = "game_grade",
  region = "region",
  email = "email",
  timeLimitEnable = "time_limit_enable",
  weekdayTimeLimit = "weekday_time_limit",
  weekdayTimeStart = "weekday_time_start",
  weekdayTimeEnd = "weekday_time_end",
  timeLimitTimeZone = "time_zone"
}

local function ConvertSdkStatus(sdkData)
  if not sdkData then
    return nil
  end
  local out = {}
  for k, v in pairs(sdkData) do
    out[SDK_FIELD_MAP[k] or k] = v
  end
  return out
end

local FAMILYCENTER_BACKEND_FIELD_WHITELIST = {
  adult_check_status = true,
  adult_check_status_expiration = true,
  need_adult_verification = true,
  adult_verification_status = true,
  region = true,
  email = true,
  need_voice_control_ingame = true,
  voice_control_status = true,
  need_lbs_control = true,
  need_lbs_control_ingame = true,
  lbs_control_status = true,
  need_user_payment = true,
  user_payment_status = true,
  need_user_data_used_for_ai = true,
  user_data_used_for_ai_status = true,
  need_personal_reco = true,
  personal_reco_status = true,
  need_share_user_data = true,
  share_user_data_status = true,
  need_use_social_function = true,
  use_social_function_status = true,
  need_participate_survey = true,
  participate_survey_status = true,
  need_receive_marketing_email = true,
  receive_marketing_email_status = true,
  parent_certificate_status = true,
  parent_certificate_status_expiration = true,
  need_parent_control = true,
  need_parent_adult_verification = true,
  parent_adult_verification_status = true,
  eu_user_agree_status = true,
  need_realname_verification = true,
  realname_auth_status = true,
  need_realname_auth = true,
  adult_check_status_ts = true,
  status_ts = true,
  pc_status_ts = true,
  player_email = true,
  birthday = true,
  certificate_type = true,
  adult_age = true,
  game_grade = true,
  time_limit_enable = true,
  weekday_time_limit = true,
  weekday_time_start = true,
  weekday_time_end = true,
  time_zone = true
}

local function CopyBackendWhitelistedStatus(rawData)
  if not rawData then
    return nil
  end
  local out = {}
  local count = 0
  for k, v in pairs(rawData) do
    if FAMILYCENTER_BACKEND_FIELD_WHITELIST[k] then
      out[k] = v
      count = count + 1
    end
  end
  if count == 0 then
    return nil
  end
  return out
end

local CERT_DECISION_FIELDS = {
  "adult_check_status",
  "parent_certificate_status"
}

local function IsCertDecisionChanged(prev, cur)
  for i = 1, #CERT_DECISION_FIELDS do
    local field = CERT_DECISION_FIELDS[i]
    local before = prev and tonumber(prev[field]) or 0
    local after = cur and tonumber(cur[field]) or 0
    if before ~= after then
      return true
    end
  end
  return false
end

local CountryComplianceSwitchFieldMap = {
  [familycenter_macro.ENUM_COUNTRY_COMPLIANCE_SWITCH.OLD_PLAYER_CERT] = "OldPlayerCert",
  [familycenter_macro.ENUM_COUNTRY_COMPLIANCE_SWITCH.ALLOW_TO_SKIP] = "AllowSkip",
  [familycenter_macro.ENUM_COUNTRY_COMPLIANCE_SWITCH.BLOCK_MINOR_ENTER] = "BlockMinorEnter"
}

local function BuildEditorBypassResult(scene)
  return {
    scene = scene,
    result = Result.UNCERTIFIED_PASS,
    pass = true,
    tipText = "",
    rawData = nil,
    editorBypass = true
  }
end

local function BuildSceneNotClosedResult(scene)
  return {
    scene = scene,
    result = Result.MINOR_NO_AUTH_PASS,
    pass = true,
    tipText = "",
    rawData = nil,
    sceneNotClosed = true
  }
end

local function RawStatusEqual(a, b)
  if a == b then
    return true
  end
  if not a or not b then
    return false
  end
  local n = 0
  for k, v in pairs(a) do
    if b[k] ~= v then
      return false
    end
    n = n + 1
  end
  local m = 0
  for _ in pairs(b) do
    m = m + 1
  end
  return n == m
end

local REPORT_DEDUPE_EXCLUDE = {
  status_ts = true,
  tS = true,
  methodId = true,
  retCode = true,
  thirdCode = true,
  thirdMsg = true,
  retMsg = true,
  extraJson = true,
  adult_check_status_ts = true,
  adult_verification_complete_ts = true,
  parent_certificate_complete_ts = true,
  parent_adult_verification_complete_ts = true,
  realname_auth_complete_ts = true,
  adultVerificationCompleteTS = true,
  parentCertificateCompleteTS = true,
  parentAdultVerificationCompleteTS = true,
  realnameAuthCompleteTS = true
}

local function BuildReportSnapshot(data)
  if not data then
    return nil
  end
  local snap = {}
  for k, v in pairs(data) do
    if not REPORT_DEDUPE_EXCLUDE[k] then
      snap[k] = v
    end
  end
  return snap
end

local function IsAdultCheckStatusValid(rawData)
  local adultCheck = rawData and tonumber(rawData.adult_check_status)
  local adultCheckExpiration = rawData and tonumber(rawData.adult_check_status_expiration)
  local TimeUtil = require("client.common.time_util")
  local currentTimestamp = tonumber(TimeUtil.GetServerTimeInSec())
  FCLog("IsAdultCheckStatusValid", "enter adultCheck=%s parentCertStat=%s expiration=%s currentTimestamp=%s", tostring(adultCheck), rawData and tostring(tonumber(rawData.parent_certificate_status)) or "nil", tostring(adultCheckExpiration), tostring(currentTimestamp))
  if adultCheck == 1 then
    FCLog("IsAdultCheckStatusValid", "branch=adult_exempted expiration_ignored=true")
    return true, adultCheckExpiration, currentTimestamp
  end
  if adultCheck == -1 and rawData and tonumber(rawData.parent_certificate_status) == 1 then
    FCLog("IsAdultCheckStatusValid", "branch=certified_minor_exempted expirationBypassed=%s currentTimestamp=%s", tostring(adultCheckExpiration), tostring(currentTimestamp))
    return true, adultCheckExpiration, currentTimestamp
  end
  local isValid = adultCheck == -1 and adultCheckExpiration ~= nil and currentTimestamp ~= nil and adultCheckExpiration >= currentTimestamp
  FCLog("IsAdultCheckStatusValid", "branch=expiration_validated isValid=%s expiration=%s currentTimestamp=%s", tostring(isValid), tostring(adultCheckExpiration), tostring(currentTimestamp))
  return isValid, adultCheckExpiration, currentTimestamp
end

local function IsCertificationComplete(rawData)
  if not rawData then
    return false
  end
  local adultCheck = tonumber(rawData.adult_check_status)
  if adultCheck ~= 1 and adultCheck ~= -1 then
    return false
  end
  local needAdult = tonumber(rawData.need_adult_verification)
  local needParentAdult = tonumber(rawData.need_parent_adult_verification)
  local complete
  if needAdult == 1 or needParentAdult == 1 then
    local logic_compliance = require("client.slua.logic.gdpr.logic_compliance")
    if logic_compliance.IsComplianceRegionBrazil(rawData.region) then
      if adultCheck == 1 and needAdult == 1 then
        complete = tonumber(rawData.adult_verification_status) == 1
      elseif adultCheck == -1 and needParentAdult == 1 then
        complete = tonumber(rawData.parent_adult_verification_status) == 1
      end
    end
  end
  if complete == nil then
    complete = adultCheck == 1 or tonumber(rawData.parent_certificate_status) == 1
  end
  FCLog("IsCertificationComplete", "result=%s adultCheck=%s needAdult=%s adultVerifStat=%s needParentAdult=%s parentAdultVerifStat=%s parentCertStat=%s region=%s", tostring(complete), tostring(adultCheck), tostring(rawData.need_adult_verification), tostring(rawData.adult_verification_status), tostring(rawData.need_parent_adult_verification), tostring(rawData.parent_adult_verification_status), tostring(rawData.parent_certificate_status), tostring(rawData.region))
  return complete
end

local function IsMinorStatusExpired(rawData)
  local adultCheck = rawData and tonumber(rawData.adult_check_status)
  if adultCheck ~= -1 then
    FCLog("IsMinorStatusExpired", "result=false reason=not_minor adultCheck=%s", tostring(adultCheck))
    return false
  end
  local parentCertStat = tonumber(rawData.parent_certificate_status)
  if parentCertStat == 1 then
    FCLog("IsMinorStatusExpired", "result=false reason=parent_certificate_exempted")
    return false
  end
  local expiration = tonumber(rawData.adult_check_status_expiration)
  if expiration == nil or expiration <= 0 then
    FCLog("IsMinorStatusExpired", "result=false reason=no_expiration expiration=%s", tostring(rawData.adult_check_status_expiration))
    return false
  end
  local TimeUtil = require("client.common.time_util")
  local currentTimestamp = tonumber(TimeUtil.GetServerTimeInSec())
  local expired = currentTimestamp ~= nil and expiration < currentTimestamp
  FCLog("IsMinorStatusExpired", "expired=%s adultCheck=%s parentCertStat=%s expiration=%s currentTimestamp=%s", tostring(expired), tostring(adultCheck), tostring(parentCertStat), tostring(expiration), tostring(currentTimestamp))
  return expired
end

local function HasSceneStatusFields(rawData, scene)
  if not rawData then
    return false
  end
  local fields = SCENE_FIELD_MAP[scene]
  return fields ~= nil and rawData[fields.need] ~= nil and rawData[fields.status] ~= nil
end

local function IsEmptyRawStatus(rawData)
  if not rawData then
    return true
  end
  local adultCheck = tonumber(rawData.adult_check_status)
  if adultCheck ~= nil and adultCheck ~= 0 then
    return false
  end
  for key, value in pairs(rawData) do
    if type(key) == "string" and (string.find(key, "^need_") or string.find(key, "_status$")) then
      local sceneValue = tonumber(value)
      if sceneValue ~= nil and sceneValue ~= 0 then
        return false
      end
    end
  end
  
  local function IsTextEmpty(value)
    return value == nil or tostring(value) == ""
  end
  
  local function IsNumberEmpty(value)
    local num = tonumber(value)
    return num == nil or num == 0
  end
  
  local certType = tonumber(rawData.certificate_type)
  return IsTextEmpty(rawData.region) and IsTextEmpty(rawData.email) and IsNumberEmpty(rawData.adult_age) and IsNumberEmpty(rawData.adult_check_status_ts) and IsNumberEmpty(rawData.adult_check_status_expiration) and IsNumberEmpty(rawData.parent_certificate_status) and (certType == nil or certType == -1)
end

local function IsAdultPass(rawData)
  if not rawData then
    return false
  end
  local logic_compliance = require("client.slua.logic.gdpr.logic_compliance")
  local pass = logic_compliance.IsAdultCertified(rawData)
  FCLog("IsAdultPass", "result=%s adultCheck=%s needAdultVerif=%s adultVerifStat=%s region=%s", tostring(pass), tostring(rawData.adult_check_status), tostring(rawData.need_adult_verification), tostring(rawData.adult_verification_status), tostring(rawData.region))
  return pass
end

local LEGACY_MINOR_CERT_STATUS = {
  Init = 0,
  Process = 1,
  Finish = 2
}

local function GetLegacyMinorCertStatus(rawData, certificationStarted, forceFinish)
  if forceFinish then
    return LEGACY_MINOR_CERT_STATUS.Finish
  end
  if certificationStarted and not rawData then
    return LEGACY_MINOR_CERT_STATUS.Process
  end
  if not rawData then
    return nil
  end
  local adultCheck = tonumber(rawData.adult_check_status)
  local isAdultCheckValid = IsAdultCheckStatusValid(rawData)
  local needAdultVerification = tonumber(rawData.need_adult_verification)
  local adultVerificationStatus = tonumber(rawData.adult_verification_status)
  local parentCertificateStatus = tonumber(rawData.parent_certificate_status)
  if isAdultCheckValid and IsCertificationComplete(rawData) then
    return LEGACY_MINOR_CERT_STATUS.Finish
  end
  if isAdultCheckValid and adultCheck == -1 then
    return LEGACY_MINOR_CERT_STATUS.Process
  end
  if adultVerificationStatus == 10 or parentCertificateStatus == 10 or parentCertificateStatus == -1 then
    return LEGACY_MINOR_CERT_STATUS.Process
  end
  if certificationStarted then
    return LEGACY_MINOR_CERT_STATUS.Process
  end
  return LEGACY_MINOR_CERT_STATUS.Init
end

local function GetLegacyUserType(rawData, allowAdultReport)
  if not rawData or not rawData.region then
    FCLog("GetLegacyUserType", "result=nil reason=region_missing")
    return nil
  end
  local compliance_util = require("client.slua.logic.gdpr.compliance_util")
  local gdpr_config = require("client.slua.logic.gdpr.gdpr_config")
  local isEEA
  if tonumber(rawData.region) ~= nil then
    isEEA = compliance_util.CheckIsEEAByRegion(rawData.region)
  else
    isEEA = compliance_util.CheckIsEEA(rawData.region)
  end
  FCLog("GetLegacyUserType", "region=%s isEEA=%s", tostring(rawData.region), tostring(isEEA))
  local adultCheck = tonumber(rawData.adult_check_status)
  local needAdultVerification = tonumber(rawData.need_adult_verification)
  local adultVerificationStatus = tonumber(rawData.adult_verification_status)
  if isEEA then
    local parentCert = tonumber(rawData.parent_certificate_status)
    if allowAdultReport == true and adultCheck == 1 and IsAdultCheckStatusValid(rawData) and (needAdultVerification == 0 or adultVerificationStatus == 1) then
      return gdpr_config.EUserType.EUGDPR_EU_ADULT
    end
    if adultCheck == -1 and parentCert == 1 then
      return gdpr_config.EUserType.EUGDPR_EU_PARENT_AGREE
    end
    FCLog("GetLegacyUserType", "result=nil reason=no_report_unconfirmed_state adultCheck=%s parentCert=%s needAdultVerif=%s adultVerifStat=%s allowAdultReport=%s", tostring(adultCheck), tostring(parentCert), tostring(needAdultVerification), tostring(adultVerificationStatus), tostring(allowAdultReport))
    return nil
  end
  FCLog("GetLegacyUserType", "result=nil reason=non_eea_no_report region=%s adultCheck=%s", tostring(rawData.region), tostring(adultCheck))
  return nil
end

local user_type_rank = (function()
  local gdpr_config = require("client.slua.logic.gdpr.gdpr_config")
  local EUserType = gdpr_config.EUserType
  return {
    [EUserType.EUGDPR_EU_PERSON] = 1,
    [EUserType.EUGDPR_EU_PARENT_WAIT] = 2,
    [EUserType.EUGDPR_EU_PARENT_NOT_AGREE] = 3,
    [EUserType.EUGDPR_EU_PARENT_AGREE] = 4,
    [EUserType.EUGDPR_EU_ADULT] = 5
  }
end)()

local function IsUserTypeDowngrade(current, target)
  if target == nil then
    return false
  end
  local currentRank = user_type_rank[tonumber(current) or current] or 0
  local targetRank = user_type_rank[tonumber(target) or target] or 0
  return currentRank > targetRank
end

local function SyncRegisterCountry(rawData)
  if not rawData then
    FCLog("SyncRegisterCountry", "result=skip reason=raw_data_nil")
    return
  end
  local region = rawData and rawData.region
  if region == nil or tostring(region) == "" then
    FCLog("SyncRegisterCountry", "result=skip reason=region_empty")
    return
  end
  local compliance_util = require("client.slua.logic.gdpr.compliance_util")
  local registerCountry
  local numericRegion = tonumber(region)
  if numericRegion and 0 < numericRegion then
    registerCountry = compliance_util.GetRegionCodeByRegion(region)
  elseif not numericRegion then
    registerCountry = tostring(region)
  else
    FCLog("SyncRegisterCountry", "result=skip reason=invalid_numeric_region region=%s", tostring(region))
    return
  end
  if registerCountry and registerCountry ~= "" then
    FuncUtil.RegisterCountry = registerCountry
    FCLog("SyncRegisterCountry", "result=set region=%s registerCountry=%s", tostring(region), tostring(registerCountry))
  else
    FCLog("SyncRegisterCountry", "result=skip reason=unresolved_region region=%s", tostring(region))
  end
end

local function ApplyLegacyGdprLocalState(rawData, options)
  options = options or {}
  local logic_compliance = require("client.slua.logic.gdpr.logic_compliance")
  local owner = options.owner
  local status = GetLegacyMinorCertStatus(rawData, options.certificationStarted == true, options.forceFinish == true)
  if options.forceFinish == true and status == nil then
    status = logic_compliance.Enum_Minor_Cert_Status and logic_compliance.Enum_Minor_Cert_Status.Finish or LEGACY_MINOR_CERT_STATUS.Finish
  end
  if not rawData and status == nil then
    FCLog("ApplyLegacyGdprLocalState", "result=skip reason=raw_data_nil")
    return nil
  end
  local region = rawData and rawData.region
  if region ~= nil and tostring(region) ~= "" then
    logic_compliance.sCountry = tostring(region)
  end
  if status ~= nil and DataMgr and tonumber(DataMgr.minor_cert_status) == 2 and tonumber(status) ~= 2 then
    FCLog("ApplyLegacyGdprLocalState", "minorCertStatus=skip reason=downgrade_forbidden current=%s target=%s", tostring(DataMgr.minor_cert_status), tostring(status))
    status = nil
  end
  if status ~= nil then
    local oldStatus = DataMgr and DataMgr.minor_cert_status or nil
    if DataMgr then
      DataMgr.minor_cert_status = status
    end
    FCLog("ApplyLegacyGdprLocalState", "minorCertStatus before=%s after=%s", tostring(oldStatus), tostring(status))
    local alreadyReported = owner and owner.lastLegacyMinorCertReportStatus == status
    local shouldReport = options.sendMinorReport == true and status ~= 0 and (options.forceReport == true or oldStatus ~= status or owner and owner.lastLegacyMinorCertReportStatus == nil) and not alreadyReported
    if shouldReport then
      local EUGDPRHandler = require("client.network.Protocol.EUGDPRHandler")
      if type(EUGDPRHandler.send_minor_cert_report_req) == "function" then
        EUGDPRHandler.send_minor_cert_report_req(status)
      else
        FCLog("ApplyLegacyGdprLocalState", "protocol=minor_cert_report_req skipped reason=handler_missing")
      end
      if owner then
        owner.lastLegacyMinorCertReportStatus = status
      end
      FCLog("ApplyLegacyGdprLocalState", "protocol=minor_cert_report_req target=%s", tostring(status))
    end
  end
  local adultCheck = rawData and tonumber(rawData.adult_check_status)
  if adultCheck == 1 and IsAdultCheckStatusValid(rawData) then
    local GdprSystem = require("client.slua.logic.gdpr.logic_gdpr")
    GdprSystem.SetEUGDPR_IsAdult(true)
  elseif adultCheck == -1 or adultCheck == -2 then
    local GdprSystem = require("client.slua.logic.gdpr.logic_gdpr")
    GdprSystem.SetEUGDPR_IsAdult(false)
  end
  if options.sendUserType == true then
    local targetUserType = GetLegacyUserType(rawData, options.allowAdultReport == true)
    local currentUserType = DataMgr and DataMgr.roleData and DataMgr.roleData.eugdpr and DataMgr.roleData.eugdpr.user_type
    if IsUserTypeDowngrade(currentUserType, targetUserType) then
      FCLog("ApplyLegacyGdprLocalState", "eugdprUpdateType=skip reason=downgrade_forbidden target=%s current=%s", tostring(targetUserType), tostring(currentUserType))
    elseif targetUserType ~= nil and targetUserType ~= currentUserType then
      local logic_eugdpr = require("client.logic.countryarea.logic_eugdpr")
      if type(logic_eugdpr.SendStateToServer) == "function" then
        logic_eugdpr.SendStateToServer(targetUserType)
        FCLog("ApplyLegacyGdprLocalState", "protocol=eugdpr_update_type_req target=%s current=%s", tostring(targetUserType), tostring(currentUserType))
      else
        FCLog("ApplyLegacyGdprLocalState", "protocol=eugdpr_update_type_req skipped reason=handler_missing")
      end
    else
      FCLog("ApplyLegacyGdprLocalState", "eugdprUpdateType=skip target=%s current=%s", tostring(targetUserType), tostring(currentUserType))
    end
  end
  if options.setCertState == true and (status == LEGACY_MINOR_CERT_STATUS.Process or status == LEGACY_MINOR_CERT_STATUS.Finish) then
    logic_compliance.certState = status
    FCLog("ApplyLegacyGdprLocalState", "certState=%s", tostring(status))
  elseif options.setCertState == true and status == LEGACY_MINOR_CERT_STATUS.Init then
    FCLog("ApplyLegacyGdprLocalState", "certState=unchanged reason=minor_cert_init")
  end
  return status
end

local function MarkLegacyAgeGateStarted(owner, rawData)
  local logic_compliance = require("client.slua.logic.gdpr.logic_compliance")
  ApplyLegacyGdprLocalState(rawData, {
    certificationStarted = true,
    sendMinorReport = true,
    setCertState = logic_compliance.bInRegistrationFlow == true,
    owner = owner
  })
  if not rawData or not rawData.region then
    FCLog("MarkLegacyAgeGateStarted", "agegateProtocol=false reason=region_missing")
    return
  end
  local compliance_util = require("client.slua.logic.gdpr.compliance_util")
  local isEEA
  if tonumber(rawData.region) ~= nil then
    isEEA = compliance_util.CheckIsEEAByRegion(rawData.region)
  else
    isEEA = compliance_util.CheckIsEEA(rawData.region)
  end
  if isEEA and DataMgr and DataMgr.roleData and DataMgr.roleData.eugdpr and not DataMgr.roleData.eugdpr.is_agegate then
    local EUGDPRHandler = require("client.network.Protocol.EUGDPRHandler")
    EUGDPRHandler.send_eugdpr_update_agegate_req(true)
    FCLog("MarkLegacyAgeGateStarted", "protocol=eugdpr_update_agegate_req target=true")
  else
    FCLog("MarkLegacyAgeGateStarted", "agegateProtocol=false isEEA=%s", tostring(isEEA))
  end
end

function logic_familycenter:DefineAndResetData()
  FCLog("DefineAndResetData", "enter")
  self.syncedBaseInfo = nil
  self.hasComplianceFootprint = nil
  self:_BumpLegacyExemptCache()
  self.footprintFetching = false
  self:_ResetComplianceFlagsState()
  self.lastRawStatus = nil
  self.consumedScenes = {}
  self.switchConfig = nil
  self.countryComplianceSwitchConfig = nil
  self.grayScaleEnabled = nil
  self.bIsPC = false
  self.mockRawStatus = nil
  self.mockNoResponse = false
  self.lastReportedStatus = nil
  self.lastLegacyMinorCertReportStatus = nil
  self.legacyAgeGateStarted = false
  self.gmWeekdayTimeLimitOverride = nil
  self.gmWeekdayTimeLimitOverrideLoaded = false
  self.pendingQueries = {}
  self.newFlowEndCallback = nil
  self.newFlowSkipReport = false
  self.newFlowReportedTypes = {}
  self.pendingRawStatusFetch = nil
  self.pendingNewFlowReentry = nil
  self.newFlowWaitTimer = nil
  self.rawStatusFetchSequence = 0
  self.rawStatusFetchTimer = nil
  self.lastUnavailableNoticeFetchId = nil
  self.rawStatusFetchFailed = false
  self.complianceGatePassed = false
  self.bAgeGatePending = false
  self.ageGateAppReactivated = false
  self.ageGatePendingCallback = nil
  self.bForceLogout = false
  self.persistGrayScale = nil
  self.persistIpRegion = nil
  self.originIpRegion = nil
  self.localTestPersistLoaded = false
  self:_LoadLocalTestPersist()
  logOnceCache = {}
  self.cachedGrayScale = nil
  self.legacyExemptCacheVersion = nil
  self.legacyExemptCacheUsed = nil
  self.legacyExemptCacheValue = nil
  self.bAutoCertPopupShown = false
  FCLog("DefineAndResetData", "result=reset")
end

function logic_familycenter:IsLegacyPlayerExempt()
  if self.bForceLogout then
    return false
  end
  local version = self.legacyExemptCacheVersion
  if version ~= nil and self.legacyExemptCacheUsed == version then
    return self.legacyExemptCacheValue == true
  end
  local value = self:_CalcLegacyPlayerExempt()
  self.legacyExemptCacheUsed = self.legacyExemptCacheVersion
  self.legacyExemptCacheValue = value
  return value
end

function logic_familycenter:_BumpLegacyExemptCache()
  self.legacyExemptCacheVersion = (self.legacyExemptCacheVersion or 0) + 1
end

function logic_familycenter:_CalcLegacyPlayerExempt()
  if self.bForceLogout or not self.syncedBaseInfo then
    FCLogOnce("IsLegacyPlayerExempt", "result=false reason=guard hasSync=%s", tostring(self.syncedBaseInfo ~= nil))
    return false
  end
  local logic_compliance = require("client.slua.logic.gdpr.logic_compliance")
  if logic_compliance.IsInRegistrationFlow() then
    FCLogOnce("IsLegacyPlayerExempt", "result=false reason=registering shared_judge")
    return false
  end
  local serverCertStatus = tonumber(DataMgr and DataMgr.minor_cert_status)
  if serverCertStatus ~= 2 then
    FCLogOnce("IsLegacyPlayerExempt", "result=false reason=not_certified serverStatus=%s", tostring(serverCertStatus))
    return false
  end
  if self:_IsCountryComplianceSwitchOn(familycenter_macro.ENUM_COUNTRY_COMPLIANCE_SWITCH.OLD_PLAYER_CERT, self:_GetSwitchCountries()) then
    FCLogOnce("IsLegacyPlayerExempt", "result=false reason=old_player_cert_required")
    return false
  end
  if self:IsInGrayScale() and self.hasComplianceFootprint ~= false then
    FCLogOnce("IsLegacyPlayerExempt", "result=false reason=footprint hasFootprint=%s", tostring(self.hasComplianceFootprint))
    return false
  end
  FCLogOnce("IsLegacyPlayerExempt", "result=true reason=legacy_exempt")
  return true
end

function logic_familycenter:EnsureComplianceFootprint()
  if self.bForceLogout or self.hasComplianceFootprint ~= nil or self.footprintFetching then
    return
  end
  if not self:IsInGrayScale() then
    return
  end
  self.footprintFetching = true
  FCLog("EnsureComplianceFootprint", "enter")
  local FamilyCenterHandler = require("client.network.Protocol.FamilyCenterHandler")
  
  local function OnFootprintResult(err_code, data)
    self.footprintFetching = false
    if err_code ~= 0 then
      FCLog("EnsureComplianceFootprint", "result=unknown reason=server_failed errCode=%s", tostring(err_code))
      self:_DrainNewFlowReentry()
      return
    end
    self.hasComplianceFootprint = data ~= nil
    self:_BumpLegacyExemptCache()
    FCLog("EnsureComplianceFootprint", "result=done hasFootprint=%s updateTs=%s", tostring(self.hasComplianceFootprint), tostring(data and data.update_ts))
    self:_RefreshHistoryResults()
    local bDrained = self.pendingNewFlowReentry ~= nil
    self:_DrainNewFlowReentry()
    if not bDrained and self:IsLegacyPlayerExempt() and self.newFlowEndCallback then
      FCLog("EnsureComplianceFootprint", "result=reentry BeginNewFlow reason=legacy_exempt")
      self:BeginNewFlow(self.newFlowEndCallback)
    end
  end
  
  local function OnFootprintRejected(reason)
    self.footprintFetching = false
    FCLog("EnsureComplianceFootprint", "result=unknown reason=rejected reason=%s", tostring(reason))
    self:_DrainNewFlowReentry()
  end
  
  FamilyCenterHandler.send_fetch_familycenter_status_req():Then(OnFootprintResult, OnFootprintRejected)
end

function logic_familycenter:SetComplianceFootprint(hasFootprint)
  self.hasComplianceFootprint = hasFootprint
  self:_BumpLegacyExemptCache()
  self:_RefreshHistoryResults()
  FCLog("SetComplianceFootprint", "hasFootprint=%s", tostring(hasFootprint))
end

local complianceFlagListeners = {}

function logic_familycenter:RegisterComplianceFlagListener(owner, flagId, fn)
  if type(fn) ~= "function" then
    return
  end
  complianceFlagListeners[owner] = {flagId = flagId, fn = fn}
  FCLog("RegisterComplianceFlagListener", "owner=%s flagId=%s", tostring(owner), tostring(flagId))
end

function logic_familycenter:GetComplianceFlag(flagId)
  local flags = self.complianceFlags
  local value = flags and flags[flagId]
  FCLog("GetComplianceFlag", "flagId=%s value=%s", tostring(flagId), tostring(value))
  return value
end

function logic_familycenter:_ResetComplianceFlagsState()
  self.complianceFlags = nil
  self.complianceFlagsFetching = false
  self.complianceFlagsRequestedKeys = nil
  self.complianceFlagsWaiters = nil
  if self.complianceFlagsFetchTimer then
    self:RemoveTimer(self.complianceFlagsFetchTimer)
    self.complianceFlagsFetchTimer = nil
  end
end

function logic_familycenter:_DispatchComplianceFlagsFetch(ok, reason)
  if self.complianceFlagsFetchTimer then
    self:RemoveTimer(self.complianceFlagsFetchTimer)
    self.complianceFlagsFetchTimer = nil
  end
  local waiters = self.complianceFlagsWaiters
  self.complianceFlagsWaiters = nil
  if not waiters then
    return
  end
  FCLog("FetchComplianceFlags", "done ok=%s reason=%s waiters=%s", tostring(ok), tostring(reason), tostring(#waiters))
  for _, cb in ipairs(waiters) do
    local called, err = pcall(cb, ok, reason)
    if not called then
      FCLog("FetchComplianceFlags", "waiter_failed err=%s", tostring(err))
    end
  end
end

function logic_familycenter:FetchComplianceFlags(flagKeys, onDone)
  if onDone then
    self.complianceFlagsWaiters = self.complianceFlagsWaiters or {}
    self.complianceFlagsWaiters[#self.complianceFlagsWaiters + 1] = onDone
  end
  if self.bForceLogout then
    FCLog("FetchComplianceFlags", "result=skip reason=force_logout")
    self:_DispatchComplianceFlagsFetch(false, "force_logout")
    return
  end
  if not self:IsInGrayScale() then
    FCLog("FetchComplianceFlags", "result=skip reason=not_gray")
    self:_DispatchComplianceFlagsFetch(false, "not_gray")
    return
  end
  if self.complianceFlagsFetching then
    FCLog("FetchComplianceFlags", "result=join_in_flight waiters=%s", tostring(#(self.complianceFlagsWaiters or {})))
    return
  end
  local macroFlags = familycenter_macro.ENUM_COMPLIANCE_FLAG or {}
  local keys = flagKeys or {
    macroFlags.SILENT_CLOSE_SWITCHES or 2
  }
  self.complianceFlagsFetching = true
  self.complianceFlagsRequestedKeys = keys
  FCLog("FetchComplianceFlags", "enter keys=%s", table.concat(keys, ","))
  self.complianceFlagsFetchTimer = self:AddTimerOnce(COMPLIANCE_FLAGS_FETCH_TIMEOUT_SECONDS, function()
    self.complianceFlagsFetchTimer = nil
    if not self.complianceFlagsFetching then
      return
    end
    self.complianceFlagsFetching = false
    FCLog("FetchComplianceFlags", "result=timeout")
    self:_DispatchComplianceFlagsFetch(false, "timeout")
  end)
  local FamilyCenterHandler = require("client.network.Protocol.FamilyCenterHandler")
  FamilyCenterHandler.send_get_compliance_flags_req(keys)
end

function logic_familycenter:ReportComplianceFlag(flagId, value)
  if self.bForceLogout then
    return
  end
  if self.complianceFlags == nil then
    self.complianceFlags = {}
  end
  if self.complianceFlags[flagId] == value then
    FCLog("ReportComplianceFlag", "result=skip reason=unchanged flagId=%s value=%s", tostring(flagId), tostring(value))
    return
  end
  self.complianceFlags[flagId] = value
  FCLog("ReportComplianceFlag", "flagId=%s value=%s", tostring(flagId), tostring(value))
  local FamilyCenterHandler = require("client.network.Protocol.FamilyCenterHandler")
  FamilyCenterHandler.send_set_compliance_flags_req({
    [flagId] = value
  })
end

function logic_familycenter:OnComplianceFlagsRsp(err_code, result)
  self.complianceFlagsFetching = false
  if err_code ~= 0 then
    FCLog("OnComplianceFlagsRsp", "result=unknown reason=server_failed errCode=%s", tostring(err_code))
    self:_DispatchComplianceFlagsFetch(false, "server_failed")
    return
  end
  if self.complianceFlags == nil then
    self.complianceFlags = {}
  end
  local requested = self.complianceFlagsRequestedKeys
  self.complianceFlagsRequestedKeys = nil
  local changed = {}
  for key, rawValue in pairs(result or {}) do
    local flagId = tonumber(key)
    if flagId then
      local value = tonumber(rawValue)
      if value == nil then
        value = rawValue and 1 or 0
      end
      if self.complianceFlags[flagId] ~= value then
        self.complianceFlags[flagId] = value
        changed[#changed + 1] = flagId
        FCLog("OnComplianceFlagsRsp", "flagId=%s value=%s", tostring(flagId), tostring(value))
      end
    end
  end
  if requested then
    for _, flagId in ipairs(requested) do
      if self.complianceFlags[flagId] == nil then
        self.complianceFlags[flagId] = 0
        changed[#changed + 1] = flagId
        FCLog("OnComplianceFlagsRsp", "flagId=%s value=0 reason=absent_in_rsp", tostring(flagId))
      end
    end
  end
  if #changed == 0 then
    FCLog("OnComplianceFlagsRsp", "result=done changed=0")
    self:_DispatchComplianceFlagsFetch(true, "ok")
    return
  end
  for _, flagId in ipairs(changed) do
    for owner, listener in pairs(complianceFlagListeners) do
      if listener.flagId == flagId then
        local ok, err = pcall(listener.fn, flagId, self.complianceFlags[flagId])
        if not ok then
          FCLog("OnComplianceFlagsRsp", "listener_failed owner=%s err=%s", tostring(owner), tostring(err))
        end
      end
    end
  end
  FCLog("OnComplianceFlagsRsp", "result=done changed=%s", tostring(#changed))
  self:_DispatchComplianceFlagsFetch(true, "ok")
end

function logic_familycenter:SetComplianceFlagForTest(flagId, value)
  if value == nil then
    if self.complianceFlags then
      self.complianceFlags[flagId] = nil
    end
  else
    if self.complianceFlags == nil then
      self.complianceFlags = {}
    end
    self.complianceFlags[flagId] = value
  end
  FCLog("SetComplianceFlagForTest", "flagId=%s value=%s", tostring(flagId), tostring(value))
end

local function BuildLegacyExemptResult(scene)
  return {
    scene = scene,
    result = Result.EXEMPT,
    pass = true,
    tipText = ""
  }
end

function logic_familycenter:_RefreshHistoryResults()
  local scenes = {}
  for scene in pairs(self.consumedScenes) do
    scenes[#scenes + 1] = scene
  end
  for _, scene in ipairs(scenes) do
    self:_DoQuery(scene)
  end
end

function logic_familycenter:OnSyncBaseInfo(baseInfo)
  if self.bForceLogout or type(baseInfo) ~= "table" then
    return
  end
  self.syncedBaseInfo = baseInfo
  self.cachedGrayScale = nil
  self:_BumpLegacyExemptCache()
  self:_RefreshHistoryResults()
  if self:IsLegacyPlayerExempt() and self.newFlowEndCallback then
    self:BeginNewFlow(self.newFlowEndCallback)
  end
end

function logic_familycenter:GetCachedRawStatus()
  FCLog("GetCachedRawStatus", "result hasCache=%s", tostring(self.lastRawStatus ~= nil))
  FCLogTree("GetCachedRawStatus", "rawData=", self.lastRawStatus)
  return self.lastRawStatus
end

function logic_familycenter:_CommitRawStatus(rawData, prevRawStatus)
  local prev = prevRawStatus or self.lastRawStatus
  if rawData ~= nil and IsEmptyRawStatus(rawData) and prev ~= nil and not IsEmptyRawStatus(prev) then
    self.lastRawStatus = prev
    self.rawStatusFetchFailed = false
    FCLog("_CommitRawStatus", "result=reject_empty_payload keepPrev=true prevAdultCheck=%s", tostring(prev.adult_check_status))
    self:_DrainNewFlowReentry()
    return false, prev
  end
  self.lastRawStatus = rawData
  self.rawStatusFetchFailed = rawData == nil
  self:_DrainNewFlowReentry()
  self:_BroadcastConsumedSwitchOnlyScenes(prev)
  return true, rawData
end

function logic_familycenter:_BroadcastConsumedSwitchOnlyScenes(prevRawData)
  if self.bForceLogout then
    return
  end
  local scenes = {}
  for scene in pairs(self.consumedScenes) do
    if SWITCH_ONLY_SCENES[scene] then
      scenes[#scenes + 1] = scene
    end
  end
  if #scenes == 0 then
    FCLog("BroadcastSwitchOnly", "result=skip reason=no_consumed_switch_only_scene")
    return
  end
  local rawData = self.lastRawStatus
  if rawData == nil then
    if not (self.rawStatusFetchFailed and self:IsInGrayScale()) or self:IsSdkUnavailableFailClosed() then
      FCLog("BroadcastSwitchOnly", "result=skip reason=raw_status_unavailable_fail_closed")
      return
    end
    for _, scene in ipairs(scenes) do
      local unavailable = self:_BuildUnavailableResult(scene, "raw_status_unavailable", nil, true)
      FCLog("BroadcastSwitchOnly", "scene=%s pass=true reason=raw_status_unavailable", tostring(scene))
      self:LuaBroadcast("OnStatusUpdated", scene, unavailable)
    end
    return
  end
  if IsEmptyRawStatus(rawData) then
    return
  end
  if prevRawData ~= nil and RawStatusEqual(prevRawData, rawData) then
    FCLog("BroadcastSwitchOnly", "result=skip reason=unchanged")
    return
  end
  for _, scene in ipairs(scenes) do
    local result = self:_BuildSceneResult(scene, rawData)
    FCLog("BroadcastSwitchOnly", "scene=%s pass=%s result=%s adultCheck=%s", tostring(scene), tostring(result.pass), tostring(result.result), tostring(rawData.adult_check_status))
    self:LuaBroadcast("OnStatusUpdated", scene, result)
  end
end

function logic_familycenter:_DrainNewFlowReentry()
  local reentry = self.pendingNewFlowReentry
  if not reentry then
    return
  end
  self.pendingNewFlowReentry = nil
  if self.bForceLogout then
    FCLog("_DrainNewFlowReentry", "result=skip reason=force_logout")
    return
  end
  FCLog("_DrainNewFlowReentry", "result=reenter reason=deferred_begin_new_flow")
  self:BeginNewFlow(reentry.flowEndCallback, reentry.flowEndForbiddenCallback)
end

function logic_familycenter:_ClearNewFlowWaitTimer()
  if self.newFlowWaitTimer then
    self:RemoveTimer(self.newFlowWaitTimer)
    self.newFlowWaitTimer = nil
  end
end

function logic_familycenter:GetCachedResult(scene)
  FCLog("GetCachedResult", "enter scene=%s", tostring(scene))
  if self.bForceLogout then
    return nil
  end
  self.consumedScenes[scene] = true
  if self:IsChestBlockedByIpCountry(scene) then
    FCLog("GetCachedResult", "result=blocked reason=chest_ip_country scene=%s", tostring(scene))
    return self:_BuildSceneResult(scene, self.lastRawStatus)
  end
  if self:IsLegacyPlayerExempt() then
    return BuildLegacyExemptResult(scene)
  end
  if self:ShouldBypassInEditor() then
    local result = BuildEditorBypassResult(scene)
    FCLog("GetCachedResult", "result=pass reason=editor scene=%s", tostring(scene))
    FCLogTree("GetCachedResult", "cachedResult=", result)
    return result
  end
  if not self:IsInGrayScale() then
    local result = BuildEditorBypassResult(scene)
    result.editorBypass = nil
    result.notGray = true
    FCLog("GetCachedResult", "result=pass reason=not_gray scene=%s", tostring(scene))
    return result
  end
  if not self:IsSceneClosed(scene) then
    local notClosed = BuildSceneNotClosedResult(scene)
    FCLog("GetCachedResult", "result=pass reason=scene_not_closed scene=%s", tostring(scene))
    FCLogTree("GetCachedResult", "cachedResult=", notClosed)
    return notClosed
  end
  local result
  local adultPass = IsAdultPass(self.lastRawStatus)
  if not result and SWITCH_ONLY_SCENES[scene] and self.lastRawStatus then
    result = self:_BuildSceneResult(scene, self.lastRawStatus)
    FCLog("GetCachedResult", "result=derived_swittonly scene=%s", tostring(scene))
  end
  if not result and (HasSceneStatusFields(self.lastRawStatus, scene) or adultPass) then
    result = self:_BuildSceneResult(scene, self.lastRawStatus)
    FCLog("GetCachedResult", "result=derived_from_raw_status scene=%s adultPass=%s", tostring(scene), tostring(adultPass))
  else
    FCLog("GetCachedResult", "result=no_derivation adultPass=%s", tostring(adultPass))
  end
  if not result and self.rawStatusFetchFailed and self.lastRawStatus == nil and not self:IsSdkUnavailableFailClosed() then
    result = self:_BuildUnavailableResult(scene, "raw_status_unavailable", nil, true)
    FCLog("GetCachedResult", "result=pass reason=raw_status_unavailable scene=%s", tostring(scene))
  end
  FCLogTree("GetCachedResult", "cachedResult=", result)
  return result
end

function logic_familycenter:IsAgeGateCertificationComplete()
  local rawData = self.lastRawStatus
  if not rawData then
    FCLog("IsAgeGateCertificationComplete", "result=false reason=raw_status_missing")
    return false
  end
  local adultCheck = rawData.adult_check_status
  local isAdultCheckValid, adultCheckExpiration, currentTimestamp = IsAdultCheckStatusValid(rawData)
  if not isAdultCheckValid then
    FCLog("IsAgeGateCertificationComplete", "result=false reason=adult_status_invalid_or_expired adultCheck=%s expiration=%s currentTimestamp=%s", tostring(adultCheck), tostring(adultCheckExpiration), tostring(currentTimestamp))
    return false
  end
  local needAdultVerification = rawData.need_adult_verification
  local adultVerificationStatus = rawData.adult_verification_status
  local parentCertificateStatus = rawData.parent_certificate_status
  local result = IsCertificationComplete(rawData)
  FCLog("IsAgeGateCertificationComplete", "result=%s adultCheck=%s expiration=%s currentTimestamp=%s needAdultVerification=%s adultVerificationStatus=%s parentCertificateStatus=%s", tostring(result), tostring(adultCheck), tostring(adultCheckExpiration), tostring(currentTimestamp), tostring(needAdultVerification), tostring(adultVerificationStatus), tostring(parentCertificateStatus))
  return result
end

local function GetGMTimeLimitPlayerPrefs()
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local fileType = PlayerPrefsSystem.ePlayerPrefsType and PlayerPrefsSystem.ePlayerPrefsType.eFamilyCenterGMTimeLimitOverride
  if not fileType then
    FCLog("GetGMTimeLimitPlayerPrefs", "result=nil reason=config_missing")
    return nil, nil
  end
  return PlayerPrefsSystem, fileType
end

local function LoadGMWeekdayTimeLimitOverride()
  local PlayerPrefsSystem, fileType = GetGMTimeLimitPlayerPrefs()
  if not PlayerPrefsSystem then
    return nil
  end
  local savedValue = PlayerPrefsSystem.LoadFileToTable_N(fileType)
  local value = tonumber(savedValue)
  if not value or value < 0 or 1440 < value or value % 1 ~= 0 then
    FCLog("LoadGMWeekdayTimeLimitOverride", "result=nil savedValue=%s", tostring(savedValue))
    return nil
  end
  FCLog("LoadGMWeekdayTimeLimitOverride", "result=loaded value=%s", tostring(value))
  return value
end

local function SaveGMWeekdayTimeLimitOverride(value)
  local PlayerPrefsSystem, fileType = GetGMTimeLimitPlayerPrefs()
  if not PlayerPrefsSystem then
    return false
  end
  PlayerPrefsSystem.SaveTableToFile_N(value == nil and {} or value, fileType)
  return true
end

function logic_familycenter:SetGMWeekdayTimeLimitOverride(minutes)
  if minutes == nil then
    if not SaveGMWeekdayTimeLimitOverride(nil) then
      FCLog("SetGMWeekdayTimeLimitOverride", "result=failed reason=prefs_unavailable")
      return false
    end
    self.gmWeekdayTimeLimitOverride = nil
    self.gmWeekdayTimeLimitOverrideLoaded = true
    FCLog("SetGMWeekdayTimeLimitOverride", "result=cleared")
    return true
  end
  local value = tonumber(minutes)
  if not value or value < 0 or 1440 < value or value % 1 ~= 0 then
    FCLog("SetGMWeekdayTimeLimitOverride", "result=rejected value=%s", tostring(minutes))
    return false
  end
  if not SaveGMWeekdayTimeLimitOverride(value) then
    FCLog("SetGMWeekdayTimeLimitOverride", "result=failed reason=prefs_unavailable")
    return false
  end
  self.gmWeekdayTimeLimitOverride = value
  self.gmWeekdayTimeLimitOverrideLoaded = true
  FCLog("SetGMWeekdayTimeLimitOverride", "result=set value=%s", tostring(value))
  return true
end

function logic_familycenter:ReportStatusToServer(rawData)
  FCLogTree("ReportStatusToServer", "rawData=", rawData)
  if not rawData then
    FCLog("ReportStatusToServer", "result=skip reason=raw_data_nil")
    return
  end
  local msg = CopyBackendWhitelistedStatus(rawData)
  if not msg then
    FCLog("ReportStatusToServer", "result=skip reason=backend_msg_empty")
    return
  end
  if not self.gmWeekdayTimeLimitOverrideLoaded then
    self.gmWeekdayTimeLimitOverride = LoadGMWeekdayTimeLimitOverride()
    self.gmWeekdayTimeLimitOverrideLoaded = true
  end
  if self.gmWeekdayTimeLimitOverride ~= nil then
    msg.weekday_time_limit = self.gmWeekdayTimeLimitOverride
    FCLog("ReportStatusToServer", "gmOverride weekdayTimeLimit=%s", tostring(self.gmWeekdayTimeLimitOverride))
  end
  local FamilyCenterHandler = require("client.network.Protocol.FamilyCenterHandler")
  FamilyCenterHandler.send_report_familycenter_status_req(msg)
  FCLog("ReportStatusToServer", "result=dispatched")
end

function logic_familycenter:FetchRawStatus(callback)
  FCLog("FetchRawStatus", "enter callback=%s bIsPC=%s hasMock=%s", tostring(callback), tostring(self.bIsPC), tostring(self.mockRawStatus ~= nil))
  if self.mockNoResponse then
    FCLog("FetchRawStatus", "result=pending reason=gm_no_response")
    return
  end
  if self.mockRawStatus ~= nil then
    FCLog("FetchRawStatus", "result source=mock")
    FCLogTree("FetchRawStatus", "rawData=", self.mockRawStatus)
    callback(self.mockRawStatus)
    return
  end
  if self.bIsPC then
    FCLog("FetchRawStatus", "dispatch source=server")
    self:FetchStatusFromServer(callback)
  else
    FCLog("FetchRawStatus", "dispatch source=sdk")
    self:FetchStatusFromSDK(callback)
  end
end

function logic_familycenter:FetchStatusFromSDK(callback)
  FCLog("FetchStatusFromSDK", "enter callback=%s", tostring(callback))
  local logic_compliance = require("client.slua.logic.gdpr.logic_compliance")
  if not logic_compliance.IsEntryOpen() then
    FCLog("FetchStatusFromSDK", "result=nil reason=compliance_entry_closed")
    callback(nil)
    return
  end
  logic_compliance.SDKQueryUserStatus(function(sdkData)
    FCLog("FetchStatusFromSDK", "callback hasSdkData=%s retCode=%s", tostring(sdkData ~= nil), tostring(sdkData and sdkData.retCode))
    FCLogTree("FetchStatusFromSDK", "sdkData=", sdkData)
    if not sdkData or sdkData.retCode ~= 0 then
      FCLog("FetchStatusFromSDK", "result=nil reason=sdk_failed retCode=%s", tostring(sdkData and sdkData.retCode))
      callback(nil)
      return
    end
    local rawData = ConvertSdkStatus(sdkData)
    FCLogTree("FetchStatusFromSDK", "result rawData=", rawData)
    callback(rawData)
  end)
end

function logic_familycenter:FetchStatusFromServer(callback)
  FCLog("FetchStatusFromServer", "enter callback=%s", tostring(callback))
  local FamilyCenterHandler = require("client.network.Protocol.FamilyCenterHandler")
  FamilyCenterHandler.send_fetch_familycenter_status_req():Then(function(err_code, data)
    FCLog("FetchStatusFromServer", "callback errCode=%s hasData=%s", tostring(err_code), tostring(data ~= nil))
    FCLogTree("FetchStatusFromServer", "data=", data)
    if err_code ~= 0 then
      FCLog("FetchStatusFromServer", "result=nil reason=server_failed errCode=%s", tostring(err_code))
      callback(nil)
      return
    end
    FCLog("FetchStatusFromServer", "result=success")
    callback(data)
  end, function(reason)
    FCLog("FetchStatusFromServer", "result=nil reason=rejected reason=%s", tostring(reason))
    callback(nil)
  end)
end

local function ParseLogTreeValue(valueText)
  if valueText == "" then
    return ""
  end
  if valueText == "true" then
    return true
  end
  if valueText == "false" then
    return false
  end
  if valueText == "{}" then
    return {}
  end
  local quoted = valueText:match("^\"(.*)\"$")
  if quoted ~= nil then
    return quoted
  end
  local numberValue = tonumber(valueText)
  if numberValue ~= nil then
    return numberValue
  end
  return valueText
end

function logic_familycenter:ParseLogTreeStatus(text)
  FCLog("ParseLogTreeStatus", "enter textLength=%s", tostring(type(text) == "string" and #text or nil))
  if type(text) ~= "string" or text == "" then
    FCLog("ParseLogTreeStatus", "result=nil reason=empty_content")
    return nil, 0, "empty_content"
  end
  local sdkData = {}
  local fieldCount = 0
  for line in text:gmatch("[^\r\n]+") do
    local body = line:match("^%s*\226\148\156\226\148\128%s*(.*)$") or line:match("^%s*\226\148\148\226\148\128%s*(.*)$")
    local key, valueText
    if body then
      key, valueText = body:match("^([%a_][%w_]*):%s*(.-)%s*$")
    end
    if key then
      sdkData[key] = ParseLogTreeValue(valueText)
      fieldCount = fieldCount + 1
    end
  end
  if fieldCount == 0 then
    FCLog("ParseLogTreeStatus", "result=nil reason=no_fields")
    return nil, 0, "no_fields"
  end
  local rawData = ConvertSdkStatus(sdkData)
  FCLog("ParseLogTreeStatus", "result=success fieldCount=%d", fieldCount)
  FCLogTree("ParseLogTreeStatus", "rawData=", rawData)
  return rawData, fieldCount, nil
end

function logic_familycenter:SetMockStatus(rawData)
  FCLog("SetMockStatus", "enter hasRawData=%s", tostring(rawData ~= nil))
  FCLogTree("SetMockStatus", "rawData=", rawData)
  self.mockRawStatus = rawData
  self.mockNoResponse = false
  if _G.IsEditor then
    self.lastRawStatus = rawData
  else
    self.lastRawStatus = nil
  end
  self.rawStatusFetchFailed = false
  if self.rawStatusFetchTimer then
    self:RemoveTimer(self.rawStatusFetchTimer)
    self.rawStatusFetchTimer = nil
  end
  self.pendingQueries = {}
  self.pendingRawStatusFetch = nil
  FCLog("SetMockStatus", "result mockEnabled=%s editorSimulation=%s cacheCleared=true", tostring(rawData ~= nil), tostring(self:IsEditorSimulationEnabled()))
end

function logic_familycenter:SetMockNoResponse(enabled)
  FCLog("SetMockNoResponse", "enter enabled=%s", tostring(enabled))
  self.mockNoResponse = enabled == true
  if _G.IsEditor then
    if self.mockNoResponse then
    end
    self.lastRawStatus = self.mockRawStatus
  else
    self.lastRawStatus = nil
  end
  self.rawStatusFetchFailed = false
  if self.rawStatusFetchTimer then
    self:RemoveTimer(self.rawStatusFetchTimer)
    self.rawStatusFetchTimer = nil
  end
  self.pendingQueries = {}
  self.pendingRawStatusFetch = nil
  FCLog("SetMockNoResponse", "result enabled=%s editorSimulation=%s cacheCleared=true", tostring(self.mockNoResponse), tostring(self:IsEditorSimulationEnabled()))
end

function logic_familycenter:IsEditorSimulationEnabled()
  local enabled = _G.IsEditor == true and (self.mockRawStatus ~= nil or self.mockNoResponse == true)
  FCLog("IsEditorSimulationEnabled", "result=%s", tostring(enabled))
  return enabled
end

function logic_familycenter:ShouldBypassInEditor()
  local bypass = _G.IsEditor == true and not self:IsEditorSimulationEnabled()
  FCLog("ShouldBypassInEditor", "result=%s", tostring(bypass))
  return bypass
end

function logic_familycenter:IsChestBlockedByIpCountry(scene)
  if scene ~= Scene.TREASURE_CHEST then
    return false
  end
  if self:ShouldBypassInEditor() then
    return false
  end
  local logic_compliance = require("client.slua.logic.gdpr.logic_compliance")
  if not logic_compliance.IsBrazilChestIpBlockEnabled() then
    FCLogOnce("IsChestBlockedByIpCountry", "result=false reason=remote_switch_off")
    return false
  end
  if not self:IsInGrayScale() then
    return false
  end
  local country = self:_GetIpCountryCode()
  local blocked = country ~= nil and CHEST_IP_HARD_BLOCK_COUNTRIES[string.upper(country)] == true
  FCLogOnce("IsChestBlockedByIpCountry", "result=%s country=%s", tostring(blocked), tostring(country))
  return blocked
end

function logic_familycenter:IsSdkUnavailableFailClosed()
  local country = self:_GetIpCountryCode()
  local blocked = country ~= nil and SDK_UNAVAILABLE_FAIL_CLOSED_IP_COUNTRIES[string.upper(country)] == true
  FCLogOnce("IsSdkUnavailableFailClosed", "result=%s country=%s", tostring(blocked), tostring(country))
  return blocked
end

function logic_familycenter:JudgeStatus(rawData, scene)
  FCLog("JudgeStatus", "enter scene=%s hasRawData=%s", tostring(scene), tostring(rawData ~= nil))
  FCLogTree("JudgeStatus", "rawData=", rawData)
  if self:IsChestBlockedByIpCountry(scene) then
    FCLog("JudgeStatus", "result=%s pass=false reason=chest_ip_country_blocked", tostring(Result.CHEST_IP_BLOCKED))
    return Result.CHEST_IP_BLOCKED, false
  end
  if self:IsLegacyPlayerExempt() then
    return Result.EXEMPT, true
  end
  if self:IsComplianceCountryInScope(rawData and rawData.region) == false then
    FCLog("JudgeStatus", "result=%s pass=true reason=compliance_country_out_of_scope scene=%s region=%s", tostring(Result.OUT_OF_SCOPE), tostring(scene), tostring(rawData and rawData.region))
    return Result.OUT_OF_SCOPE, true
  end
  if not rawData then
    FCLog("JudgeStatus", "result=%s pass=true reason=no_compliance_data scene=%s", tostring(Result.OUT_OF_SCOPE), tostring(scene))
    return Result.OUT_OF_SCOPE, true
  end
  local adultCheck = rawData.adult_check_status
  local needAdultVerif = rawData.need_adult_verification
  local adultVerifStat = rawData.adult_verification_status
  if adultCheck == 1 then
    local logic_compliance = require("client.slua.logic.gdpr.logic_compliance")
    if logic_compliance.IsAdultCertified(rawData) then
      FCLog("JudgeStatus", "result=%s pass=true reason=adult", tostring(Result.ADULT))
      return Result.ADULT, true
    end
    FCLog("JudgeStatus", "adult_face_pending adultCheck=1, fallthrough to uncertified")
  end
  if SWITCH_ONLY_SCENES[scene] then
    local countries = self:_GetSwitchCountries()
    if adultCheck == -1 or adultCheck == -2 then
      local blocked2 = self:_IsSwitchBlocked(2, countries, scene)
      local minorCertified = adultCheck == -1 and IsCertificationComplete(rawData)
      FCLog("JudgeStatus", "swittonly_minor_tier scene=%s adultCheck=%s minorCertified=%s parentCertStat=%s", tostring(scene), tostring(adultCheck), tostring(minorCertified), tostring(rawData.parent_certificate_status))
      if blocked2 then
        local blockedResult
        if minorCertified or adultCheck == -2 then
          blockedResult = MINOR_BLOCK_RESULT_BY_SCENE[scene] or Result.MINOR_NO_AUTH_BLOCK
        else
          blockedResult = Result.UNCERTIFIED_BLOCK
        end
        FCLog("JudgeStatus", "result=%s pass=false reason=swittonly_minor_switch_on scene=%s minorCertified=%s", tostring(blockedResult), tostring(scene), tostring(minorCertified))
        return blockedResult, false
      end
      FCLog("JudgeStatus", "result=%s pass=true reason=swittonly_minor_switch_off scene=%s", tostring(Result.MINOR_NO_AUTH_PASS), tostring(scene))
      return Result.MINOR_NO_AUTH_PASS, true
    end
    local blocked1 = self:_IsSwitchBlocked(1, countries, scene)
    if blocked1 then
      FCLog("JudgeStatus", "result=%s pass=false reason=swittonly_uncertified_switch_on scene=%s", tostring(Result.UNCERTIFIED_BLOCK), tostring(scene))
      return Result.UNCERTIFIED_BLOCK, false
    end
    FCLog("JudgeStatus", "result=%s pass=true reason=swittonly_uncertified_switch_off scene=%s", tostring(Result.UNCERTIFIED_PASS), tostring(scene))
    return Result.UNCERTIFIED_PASS, true
  end
  if IsMinorStatusExpired(rawData) then
    if self:IsSceneClosed(scene) then
      FCLog("JudgeStatus", "result=%s pass=false reason=minor_status_expired_scene_closed scene=%s", tostring(Result.UNCERTIFIED_BLOCK), tostring(scene))
      return Result.UNCERTIFIED_BLOCK, false
    end
    FCLog("JudgeStatus", "result=%s pass=true reason=minor_status_expired_scene_not_closed scene=%s", tostring(Result.UNCERTIFIED_PASS), tostring(scene))
    return Result.UNCERTIFIED_PASS, true
  end
  local fields = SCENE_FIELD_MAP[scene]
  local needField = fields and rawData[fields.need] or 0
  local statusFld = fields and rawData[fields.status] or nil
  if adultCheck == -1 and needField == 1 and statusFld == 1 then
    FCLog("JudgeStatus", "result=%s pass=true reason=minor_approved", tostring(Result.MINOR_APPROVED))
    return Result.MINOR_APPROVED, true
  end
  local countries = self:_GetSwitchCountries()
  local blocked1 = self:_IsSwitchBlocked(1, countries, scene)
  local blocked2 = self:_IsSwitchBlocked(2, countries, scene)
  if adultCheck == -1 and needField == 1 and statusFld ~= 1 then
    local parentCertStat = tonumber(rawData.parent_certificate_status)
    if parentCertStat == 0 or parentCertStat == 10 then
      if not blocked1 and not blocked2 then
        FCLog("JudgeStatus", "result=%s pass=true reason=minor_cert_pending_not_closed parentCertStat=%s", tostring(Result.UNCERTIFIED_PASS), tostring(parentCertStat))
        return Result.UNCERTIFIED_PASS, true
      end
      FCLog("JudgeStatus", "result=%s pass=false reason=minor_cert_pending parentCertStat=%s", tostring(Result.UNCERTIFIED_BLOCK), tostring(parentCertStat))
      return Result.UNCERTIFIED_BLOCK, false
    end
    if not blocked1 and not blocked2 then
      FCLog("JudgeStatus", "result=%s pass=true reason=minor_denied_not_closed", tostring(Result.MINOR_NO_AUTH_PASS))
      return Result.MINOR_NO_AUTH_PASS, true
    end
    FCLog("JudgeStatus", "result=%s pass=false reason=minor_denied", tostring(Result.MINOR_DENIED))
    return Result.MINOR_DENIED, false
  end
  if adultCheck ~= 1 and needField == 0 then
    if blocked2 then
      FCLog("JudgeStatus", "result=%s pass=false reason=minor_no_auth_switch_on", tostring(Result.MINOR_NO_AUTH_BLOCK))
      return Result.MINOR_NO_AUTH_BLOCK, false
    end
    FCLog("JudgeStatus", "result=%s pass=true reason=minor_no_auth_switch_off", tostring(Result.MINOR_NO_AUTH_PASS))
    return Result.MINOR_NO_AUTH_PASS, true
  end
  if blocked1 then
    FCLog("JudgeStatus", "result=%s pass=false reason=uncertified_switch_on", tostring(Result.UNCERTIFIED_BLOCK))
    return Result.UNCERTIFIED_BLOCK, false
  end
  FCLog("JudgeStatus", "result=%s pass=true reason=uncertified_switch_off", tostring(Result.UNCERTIFIED_PASS))
  return Result.UNCERTIFIED_PASS, true
end

function logic_familycenter:BuildTipText(resultEnum, rawData)
  FCLog("BuildTipText", "enter resultEnum=%s hasRawData=%s", tostring(resultEnum), tostring(rawData ~= nil))
  FCLogTree("BuildTipText", "rawData=", rawData)
  if resultEnum == Result.MINOR_DENIED or resultEnum == Result.MINOR_NO_AUTH_BLOCK then
    local email = rawData and rawData.email or ""
    local text = LocUtil.GetLocalizeResStr(75540)
    if email ~= "" then
      text = text .. "\n" .. LocUtil.LocalizeResFormat(75541, email)
    end
    FCLog("BuildTipText", "resultEnum=%s text=%s", tostring(resultEnum), tostring(text))
    return text
  elseif resultEnum == Result.UNCERTIFIED_BLOCK then
    FCLog("BuildTipText", "resultEnum=%s reason=uncertified_block", tostring(resultEnum))
    return LocUtil.GetLocalizeResStr(75543)
  elseif resultEnum == Result.MINOR_CHEST_BLOCKED or resultEnum == Result.MINOR_CREATOR_BLOCKED or resultEnum == Result.MINOR_OVERUSE_BLOCKED then
    FCLog("BuildTipText", "resultEnum=%s reason=minor_service_blocked", tostring(resultEnum))
    return LocUtil.GetLocalizeResStr(LOC_ID_MINOR_SERVICE_BLOCKED_TIP)
  elseif resultEnum == Result.CHEST_IP_BLOCKED then
    FCLog("BuildTipText", "resultEnum=%s reason=chest_ip_country_blocked", tostring(resultEnum))
    return LocUtil.GetLocalizeResStr(LOC_ID_CHEST_IP_BLOCKED_TIP)
  end
  FCLog("BuildTipText", "resultEnum=%s text=empty", tostring(resultEnum))
  return ""
end

function logic_familycenter:_BuildSceneResult(scene, rawData)
  local resultEnum, pass = self:JudgeStatus(rawData, scene)
  return {
    scene = scene,
    result = resultEnum,
    pass = pass,
    tipText = pass and "" or self:BuildTipText(resultEnum, rawData),
    rawData = rawData
  }
end

function logic_familycenter:_BuildUnavailableResult(scene, reason, fetchId, pass)
  local passed = pass == true
  return {
    result = passed and Result.OUT_OF_SCOPE or Result.DATA_UNAVAILABLE,
    pass = passed,
    scene = scene,
    tipText = "",
    rawData = nil,
    unavailable = true,
    reason = reason,
    fetchId = fetchId
  }
end

function logic_familycenter:_DoQuery(scene, callback)
  FCLog("_DoQuery", "enter scene=%s callback=%s", tostring(scene), tostring(callback))
  if self.bForceLogout then
    return
  end
  self.consumedScenes[scene] = true
  local pending = self.pendingQueries[scene]
  if not pending then
    self.pendingQueries[scene] = {
      callbacks = {}
    }
  end
  if callback then
    table.insert(self.pendingQueries[scene].callbacks, callback)
  end
  if pending and not self:IsLegacyPlayerExempt() then
    return
  end
  
  local function DispatchScene(targetScene, result)
    if self.bForceLogout then
      return
    end
    if self:IsLegacyPlayerExempt() and not self:IsChestBlockedByIpCountry(targetScene) then
      result = BuildLegacyExemptResult(targetScene)
    end
    FCLogTree("_DoQuery", "result=", result)
    local pending = self.pendingQueries[targetScene]
    self.pendingQueries[targetScene] = nil
    self:LuaBroadcast("OnStatusUpdated", targetScene, result)
    if pending then
      FCLog("_DoQuery", "dispatch callbacks scene=%s callbackCount=%s", tostring(targetScene), tostring(#pending.callbacks))
      for _, cb in ipairs(pending.callbacks) do
        cb(result)
      end
    end
  end
  
  local function CompleteScene(targetScene, rawData)
    DispatchScene(targetScene, self:_BuildSceneResult(targetScene, rawData))
  end
  
  local function CompleteUnavailable(targetScene, reason, fetchId)
    DispatchScene(targetScene, self:_BuildUnavailableResult(targetScene, reason, fetchId))
  end
  
  if self:IsLegacyPlayerExempt() and not self:IsChestBlockedByIpCountry(scene) then
    DispatchScene(scene, BuildLegacyExemptResult(scene))
    return
  end
  if self:IsChestBlockedByIpCountry(scene) then
    FCLog("_DoQuery", "result=chest_ip_country_blocked scene=%s", tostring(scene))
    CompleteScene(scene, self.lastRawStatus)
    return
  end
  if not self:IsSceneClosed(scene) then
    FCLog("_DoQuery", "result=scene_not_closed scene=%s", tostring(scene))
    DispatchScene(scene, BuildSceneNotClosedResult(scene))
    return
  end
  if SWITCH_ONLY_SCENES[scene] and self.lastRawStatus then
    FCLog("_DoQuery", "result=swittonly_derived scene=%s", tostring(scene))
    CompleteScene(scene, self.lastRawStatus)
    return
  end
  local adultPass = IsAdultPass(self.lastRawStatus)
  if HasSceneStatusFields(self.lastRawStatus, scene) or adultPass then
    FCLog("_DoQuery", "result=cache_hit scene=%s adultPass=%s", tostring(scene), tostring(adultPass))
    CompleteScene(scene, self.lastRawStatus)
    return
  end
  if self.pendingRawStatusFetch then
    FCLog("_DoQuery", "result=queued_shared_fetch scene=%s", tostring(scene))
    return
  end
  self.rawStatusFetchSequence = self.rawStatusFetchSequence + 1
  local fetchId = self.rawStatusFetchSequence
  local fetchContext = {id = fetchId}
  self.pendingRawStatusFetch = fetchContext
  self.rawStatusFetchTimer = self:AddTimerOnce(RAW_STATUS_FETCH_TIMEOUT_SECONDS, function()
    if self.bForceLogout then
      FCLog("_DoQuery", "result=skip reason=force_logout fetchId=%s", tostring(fetchId))
      return
    end
    if self.pendingRawStatusFetch ~= fetchContext then
      FCLog("_DoQuery", "result=skip reason=stale_timeout fetchId=%s", tostring(fetchId))
      return
    end
    self.pendingRawStatusFetch = nil
    self.rawStatusFetchTimer = nil
    FCLog("_DoQuery", "result=timeout fetchId=%s", tostring(fetchId))
    local pendingScenes = {}
    for pendingScene in pairs(self.pendingQueries) do
      table.insert(pendingScenes, pendingScene)
    end
    local failClosed = not self:IsInGrayScale() or self:IsSdkUnavailableFailClosed()
    self.rawStatusFetchFailed = not failClosed
    for _, pendingScene in ipairs(pendingScenes) do
      if failClosed then
        CompleteUnavailable(pendingScene, "query_timeout", fetchId)
      else
        DispatchScene(pendingScene, self:_BuildUnavailableResult(pendingScene, "query_timeout", fetchId, true))
      end
    end
  end)
  FCLog("_DoQuery", "dispatch=FetchRawStatus scene=%s reason=cache_missing_fields fetchId=%s", tostring(scene), tostring(fetchId))
  self:FetchRawStatus(function(rawData)
    if self.bForceLogout then
      FCLog("_DoQuery", "result=skip reason=force_logout fetchId=%s", tostring(fetchId))
      return
    end
    if self.pendingRawStatusFetch ~= fetchContext then
      FCLog("_DoQuery", "result=skip reason=stale_callback fetchId=%s", tostring(fetchId))
      return
    end
    FCLog("_DoQuery", "callback hasRawData=%s", tostring(rawData ~= nil))
    FCLogTree("_DoQuery", "rawData=", rawData)
    self.pendingRawStatusFetch = nil
    if self.rawStatusFetchTimer then
      self:RemoveTimer(self.rawStatusFetchTimer)
      self.rawStatusFetchTimer = nil
    end
    local accepted, effectiveRawData = self:_CommitRawStatus(rawData)
    if not accepted then
      FCLog("_DoQuery", "result=keep_prev reason=empty_payload fetchId=%s", tostring(fetchId))
    end
    rawData = effectiveRawData
    local reportData = CopyBackendWhitelistedStatus(rawData)
    if reportData and not self.bIsPC and not RawStatusEqual(BuildReportSnapshot(reportData), self.lastReportedStatus) then
      self.lastReportedStatus = BuildReportSnapshot(reportData)
      FCLog("_DoQuery", "reportStatus=true")
      self:ReportStatusToServer(rawData)
    else
      FCLog("_DoQuery", "reportStatus=false bIsPC=%s", tostring(self.bIsPC))
    end
    local pendingScenes = {}
    for pendingScene in pairs(self.pendingQueries) do
      table.insert(pendingScenes, pendingScene)
    end
    for _, pendingScene in ipairs(pendingScenes) do
      CompleteScene(pendingScene, rawData)
    end
  end)
end

function logic_familycenter:QueryComplianceStatus(scene, callback)
  FCLog("QueryComplianceStatus", "enter scene=%s callback=%s", tostring(scene), tostring(callback))
  FCLog("QueryComplianceStatus", "dispatch=_DoQuery")
  self:_DoQuery(scene, callback)
end

function logic_familycenter:RunWithCompliance(scene, handlers)
  handlers = handlers or {}
  FCLog("RunWithCompliance", "enter scene=%s hasPass=%s hasLegacy=%s hasBlocked=%s hasUnavailable=%s", tostring(scene), tostring(type(handlers.onPass) == "function"), tostring(type(handlers.onLegacy) == "function"), tostring(type(handlers.onBlocked) == "function"), tostring(type(handlers.onUnavailable) == "function"))
  if self.bForceLogout then
    FCLog("RunWithCompliance", "result=skip reason=force_logout scene=%s", tostring(scene))
    return true
  end
  self.consumedScenes[scene] = true
  self:EnsureComplianceFootprint()
  if self:IsLegacyPlayerExempt() and not self:IsChestBlockedByIpCountry(scene) then
    if type(handlers.onPass) == "function" then
      handlers.onPass(BuildLegacyExemptResult(scene))
    end
    return true
  end
  if self:ShouldBypassInEditor() then
    local result = BuildEditorBypassResult(scene)
    FCLog("RunWithCompliance", "result=pass reason=editor scene=%s", tostring(scene))
    if type(handlers.onPass) == "function" then
      handlers.onPass(result)
    end
    return true
  end
  if not self:IsInGrayScale() then
    if type(handlers.onLegacy) == "function" then
      handlers.onLegacy()
    else
      FCLog("RunWithCompliance", "result=legacy_unhandled scene=%s", tostring(scene))
    end
    return false
  end
  if not self:IsSceneClosed(scene) and not self:IsChestBlockedByIpCountry(scene) then
    FCLog("RunWithCompliance", "result=pass reason=scene_not_closed scene=%s", tostring(scene))
    if type(handlers.onPass) == "function" then
      handlers.onPass(BuildSceneNotClosedResult(scene))
    else
      FCLog("RunWithCompliance", "result=skip scene=%s reason=missing_on_pass", tostring(scene))
    end
    return true
  end
  self:QueryComplianceStatus(scene, function(result)
    if result and result.pass then
      if type(handlers.onPass) == "function" then
        handlers.onPass(result)
      else
        FCLog("RunWithCompliance", "result=skip scene=%s reason=missing_on_pass", tostring(scene))
      end
      return
    end
    if result and result.unavailable then
      local handledUnavailable = false
      if type(handlers.onUnavailable) == "function" then
        handledUnavailable = handlers.onUnavailable(result) == true
      end
      if not handledUnavailable then
        self:HandleComplianceUnavailable(result)
      end
      return
    end
    local handled = false
    if type(handlers.onBlocked) == "function" then
      handled = handlers.onBlocked(result) == true
    end
    if not handled then
      self:HandleComplianceBlocked(result)
    end
  end)
  return true
end

function logic_familycenter:_GetIpCountryCode()
  FCLog("_GetIpCountryCode", "enter")
  if self.persistIpRegion ~= nil or self.originIpRegion ~= nil then
    self:_ApplyIpRegionOverride()
  end
  local login_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module)
  local ipRegion = login_module and login_module.sIpRegion
  if not ipRegion or ipRegion == "" then
    FCLog("_GetIpCountryCode", "result=nil reason=missing_ip_region")
    return nil
  end
  FCLog("_GetIpCountryCode", "result=%s", tostring(ipRegion))
  return tostring(ipRegion)
end

function logic_familycenter:_GetGameCountryCode()
  local regionData = DataMgr and DataMgr.RegionData
  local gameCountry = regionData and regionData.region
  if not gameCountry or gameCountry == "" then
    FCLog("_GetGameCountryCode", "result=nil reason=region_empty")
    return nil
  end
  FCLog("_GetGameCountryCode", "result=%s", tostring(gameCountry))
  return tostring(gameCountry)
end

function logic_familycenter:_GetSwitchCountries()
  local countries = {}
  local seen = {}
  
  local function append(country)
    if country and country ~= "" and not seen[country] then
      seen[country] = true
      table.insert(countries, country)
    end
  end
  
  append(self:_GetIpCountryCode())
  append(self:_GetGameCountryCode())
  FCLog("_GetSwitchCountries", "result=%s", table.concat(countries, ","))
  return countries
end

function logic_familycenter:GetComplianceCountryCode(region)
  local regionNum = tonumber(region)
  if not regionNum or regionNum <= 0 then
    FCLog("GetComplianceCountryCode", "result=nil reason=region_invalid region=%s", tostring(region))
    return nil
  end
  local compliance_util = require("client.slua.logic.gdpr.compliance_util")
  local reverseLookup = compliance_util and compliance_util.GetRegionCodeByRegion
  if type(reverseLookup) ~= "function" then
    FCLog("GetComplianceCountryCode", "result=nil reason=reverse_lookup_unavailable region=%s", tostring(region))
    return nil
  end
  local countryCode = reverseLookup(regionNum)
  FCLog("GetComplianceCountryCode", "result=%s region=%s", tostring(countryCode), tostring(region))
  return countryCode
end

function logic_familycenter:IsComplianceCountryInScope(region)
  local countryCode = self:GetComplianceCountryCode(region)
  if not countryCode then
    FCLog("IsComplianceCountryInScope", "result=nil reason=country_unresolved region=%s", tostring(region))
    return nil
  end
  local regionConfig = CDataTable.GetTableDataByFilter("RegionConfig", "RegionCode", countryCode)
  if not regionConfig then
    FCLog("IsComplianceCountryInScope", "result=nil reason=region_config_missing country=%s", tostring(countryCode))
    return nil
  end
  local useFamilyCenter = tonumber(regionConfig.UseFamilyCenter)
  local inScope = useFamilyCenter == 1
  FCLog("IsComplianceCountryInScope", "result=%s country=%s useFamilyCenter=%s", tostring(inScope), tostring(countryCode), tostring(useFamilyCenter))
  return inScope
end

function logic_familycenter:_IsSwitchBlocked(switchNum, countries, scene)
  for _, country in ipairs(countries) do
    if self:GetSwitch(switchNum, country, scene) then
      return true
    end
  end
  return false
end

function logic_familycenter:_IsCountryComplianceSwitchOn(num, countries)
  for _, country in ipairs(countries) do
    if self:GetCountryComplianceSwitch(num, country) then
      return true
    end
  end
  return false
end

function logic_familycenter:IsSceneClosed(scene)
  local countries = self:_GetSwitchCountries()
  local closed = self:_IsSwitchBlocked(1, countries, scene) or self:_IsSwitchBlocked(2, countries, scene)
  FCLog("IsSceneClosed", "result=%s scene=%s countries=%s", tostring(closed), tostring(scene), table.concat(countries, ","))
  return closed
end

function logic_familycenter:GetSwitch(switchNum, country, scene)
  FCLog("GetSwitch", "enter switchNum=%s country=%s scene=%s", tostring(switchNum), tostring(country), tostring(scene))
  if not country then
    FCLog("GetSwitch", "result=false source=default reason=country_nil")
    return false
  end
  if self.switchConfig then
    local key = switchNum == 1 and "switch1" or "switch2"
    local countryCfg = self.switchConfig[key] and self.switchConfig[key][country]
    local result = countryCfg and countryCfg[scene] == true or false
    FCLog("GetSwitch", "result=%s source=override key=%s", tostring(result), tostring(key))
    return result
  end
  local cfg = CDataTable.GetTableData("FamilyCenterSwitchConfig", country)
  if not cfg then
    FCLog("GetSwitch", "result=false source=default reason=config_missing")
    return false
  end
  local fieldKey = switchNum == 1 and "Switch1" or "Switch2"
  local s = cfg[fieldKey] or ""
  for part in string.gmatch(s, "%d+") do
    if tonumber(part) == scene then
      FCLog("GetSwitch", "result=true source=config field=%s", tostring(fieldKey))
      return true
    end
  end
  FCLog("GetSwitch", "result=false source=config field=%s reason=scene_missing", tostring(fieldKey))
  return false
end

function logic_familycenter:SetSwitch(switchNum, country, scene, enable)
  FCLog("SetSwitch", "enter switchNum=%s country=%s scene=%s enable=%s", tostring(switchNum), tostring(country), tostring(scene), tostring(enable))
  if not country or not scene then
    FCLog("SetSwitch", "result=skip reason=invalid_country_or_scene")
    return
  end
  if not self.switchConfig then
    self.switchConfig = {
      switch1 = {},
      switch2 = {}
    }
  end
  local key = switchNum == 1 and "switch1" or "switch2"
  if not self.switchConfig[key][country] then
    self.switchConfig[key][country] = {}
  end
  self.switchConfig[key][country][scene] = enable == true
  FCLog("SetSwitch", "result=updated key=%s enabled=%s", tostring(key), tostring(enable == true))
end

function logic_familycenter:ClearSwitchConfig()
  FCLog("ClearSwitchConfig", "enter")
  self.switchConfig = nil
  FCLog("ClearSwitchConfig", "result=cleared")
end

function logic_familycenter:UpdateSwitchConfig(config)
  FCLog("UpdateSwitchConfig", "enter")
  FCLogTree("UpdateSwitchConfig", "config=", config)
  self.switchConfig = config
  FCLog("UpdateSwitchConfig", "result=updated hasConfig=%s", tostring(config ~= nil))
end

function logic_familycenter:GetCountryComplianceSwitch(num, country)
  FCLog("GetCountryComplianceSwitch", "enter num=%s country=%s", tostring(num), tostring(country))
  local defaultVal = false
  if not country or country == "" then
    FCLog("GetCountryComplianceSwitch", "result=%s source=default reason=country_empty", tostring(defaultVal))
    return defaultVal
  end
  if self.countryComplianceSwitchConfig then
    local countryCfg = self.countryComplianceSwitchConfig[country]
    if countryCfg then
      local field = CountryComplianceSwitchFieldMap[num]
      if field and countryCfg[field] ~= nil then
        local result = countryCfg[field] == true or countryCfg[field] == 1
        FCLog("GetCountryComplianceSwitch", "result=%s source=override field=%s", tostring(result), tostring(field))
        return result
      end
    end
  end
  local cfg = CDataTable.GetTableData("FamilyCenterSwitchConfig", country)
  if not cfg then
    FCLog("GetCountryComplianceSwitch", "result=%s source=default reason=config_missing", tostring(defaultVal))
    return defaultVal
  end
  local field = CountryComplianceSwitchFieldMap[num]
  if not field then
    FCLog("GetCountryComplianceSwitch", "result=%s source=default reason=field_missing", tostring(defaultVal))
    return defaultVal
  end
  local val = cfg[field]
  if val == nil then
    FCLog("GetCountryComplianceSwitch", "result=%s source=default reason=value_nil field=%s", tostring(defaultVal), tostring(field))
    return defaultVal
  end
  local result = val == 1 or val == true
  FCLog("GetCountryComplianceSwitch", "result=%s source=config field=%s rawValue=%s", tostring(result), tostring(field), tostring(val))
  return result
end

function logic_familycenter:SetCountryComplianceSwitch(num, country, enable)
  FCLog("SetCountryComplianceSwitch", "enter num=%s country=%s enable=%s", tostring(num), tostring(country), tostring(enable))
  if not country or country == "" then
    FCLog("SetCountryComplianceSwitch", "result=skip reason=country_empty")
    return
  end
  if not self.countryComplianceSwitchConfig then
    self.countryComplianceSwitchConfig = {}
  end
  if not self.countryComplianceSwitchConfig[country] then
    self.countryComplianceSwitchConfig[country] = {}
  end
  local field = CountryComplianceSwitchFieldMap[num]
  if not field then
    FCLog("SetCountryComplianceSwitch", "result=skip reason=field_missing")
    return
  end
  self.countryComplianceSwitchConfig[country][field] = enable == true
  FCLog("SetCountryComplianceSwitch", "result=updated field=%s enabled=%s", tostring(field), tostring(enable == true))
end

function logic_familycenter:ClearCountryComplianceSwitchConfig()
  FCLog("ClearCountryComplianceSwitchConfig", "enter")
  self.countryComplianceSwitchConfig = nil
  FCLog("ClearCountryComplianceSwitchConfig", "result=cleared")
end

local function IsPlatformPC()
  if IsWoWEditor or Client.IsWindows() then
    return true
  end
  return false
end

function logic_familycenter:OnInitialize()
  FCLog("OnInitialize", "enter")
  self.bIsPC = IsPlatformPC()
  FCLog("OnInitialize", "result bIsPC=%s", tostring(self.bIsPC))
end

function logic_familycenter:RegistEvents()
  FCLog("RegistEvents", "enter")
  ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_minor_privacy_off)
  self:AddCommonEvent(EVENTTYPE_NETWORK, EVENTID_LOBBY_SERVER_CONNECT_SUCCESS, self.OnLobbyServerConnected, self)
  self:AddCommonEvent(EVENTTYPE_APPLICATION_ACTIVE_STATE, EVENTID_APPLICATION_REACTIVATED, self.OnApplicationReactivated, self)
  self:AddCommonEvent(EVENTTYPE_APPLICATION_ACTIVE_STATE, EVENTID_APPLICATION_REACTIVATED_EX, self.OnApplicationReactivated, self)
  FCLog("RegistEvents", "result=minor_privacy_off_loaded")
end

function logic_familycenter:OnApplicationReactivated()
  if not self.bAgeGatePending or self.bForceLogout then
    return
  end
  self.ageGateAppReactivated = true
  FCLog("OnApplicationReactivated", "ageGatePending=true, wait network ready")
end

function logic_familycenter:OnLobbyServerConnected()
  if not self.bAgeGatePending or not self.ageGateAppReactivated then
    return
  end
  if self.bForceLogout then
    return
  end
  local cb = self.ageGatePendingCallback
  self.bAgeGatePending = false
  self.ageGateAppReactivated = false
  self.ageGatePendingCallback = nil
  FCLog("OnLobbyServerConnected", "ageGatePending=true appReactivated=true, recheck compliance")
  local recheckDone = false
  local recheckTimer = self:AddTimerOnce(5, function()
    recheckTimer = nil
    if self.bForceLogout or recheckDone then
      return
    end
    recheckDone = true
    FCLog("OnLobbyServerConnected", "recheck result=timeout, treat as incomplete")
    if cb then
      cb(nil, true)
    end
  end)
  self:RefreshStatusAfterSdkCallback(function(rawData)
    if self.bForceLogout or recheckDone then
      return
    end
    recheckDone = true
    if recheckTimer then
      self:RemoveTimer(recheckTimer)
      recheckTimer = nil
    end
    local completed = rawData ~= nil and IsCertificationComplete(rawData)
    FCLog("OnLobbyServerConnected", "recheck completed=%s hasRawData=%s", tostring(completed), tostring(rawData ~= nil))
    if cb then
      cb(rawData, not completed)
    end
  end)
end

function logic_familycenter:OnLogin(bReLogin)
  FCLog("OnLogin", "enter bReLogin=%s", tostring(bReLogin))
  if bReLogin then
    FCLog("OnLogin", "bReLogin=true keepAllState")
    return
  end
  local preserveEditorMock = self:IsEditorSimulationEnabled()
  self.lastRawStatus = not (not preserveEditorMock or self.mockNoResponse) and self.mockRawStatus or nil
  self.lastReportedStatus = nil
  self.lastLegacyMinorCertReportStatus = nil
  self.legacyAgeGateStarted = false
  if not preserveEditorMock then
    self.mockRawStatus = nil
    self.mockNoResponse = false
  end
  if self.rawStatusFetchTimer then
    self:RemoveTimer(self.rawStatusFetchTimer)
    self.rawStatusFetchTimer = nil
  end
  self.pendingRawStatusFetch = nil
  self.pendingNewFlowReentry = nil
  self:_ClearNewFlowWaitTimer()
  self.rawStatusFetchFailed = false
  self.pendingQueries = {}
  self.hasComplianceFootprint = nil
  self:_BumpLegacyExemptCache()
  self.footprintFetching = false
  self:_ResetComplianceFlagsState()
  ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_minor_privacy_off):Cancel()
  FCLog("OnLogin", "firstLogin cacheCleared=true editorMockPreserved=%s", tostring(preserveEditorMock))
  self:EnsureComplianceFootprint()
  self:FetchComplianceFlags()
  ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_minor_privacy_off):TryStart()
end

function logic_familycenter:OnLogOut()
  FCLog("OnLogOut", "enter")
  self.bForceLogout = true
  self.syncedBaseInfo = nil
  self.consumedScenes = {}
  ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_minor_privacy_off):Cancel()
  self.lastRawStatus = nil
  self.mockRawStatus = nil
  self.mockNoResponse = false
  if self.rawStatusFetchTimer then
    self:RemoveTimer(self.rawStatusFetchTimer)
    self.rawStatusFetchTimer = nil
  end
  self.pendingRawStatusFetch = nil
  self.pendingNewFlowReentry = nil
  self:_ClearNewFlowWaitTimer()
  self.rawStatusFetchFailed = false
  self.pendingQueries = {}
  self.lastLegacyMinorCertReportStatus = nil
  self.legacyAgeGateStarted = false
  self.bAgeGatePending = false
  self.ageGateAppReactivated = false
  self.ageGatePendingCallback = nil
  self.hasComplianceFootprint = nil
  self:_BumpLegacyExemptCache()
  self.footprintFetching = false
  self:_ResetComplianceFlagsState()
  FCLog("OnLogOut", "result=cache_cleared")
end

function logic_familycenter:OnPreSwitchGameStatus(preState, nextState)
  FCLog("OnPreSwitchGameStatus", "enter preState=%s nextState=%s", tostring(preState), tostring(nextState))
  FCLog("OnPreSwitchGameStatus", "result=noop")
end

local function GetFamilyCenterWebviewBaseUrl(baseUrl)
  if type(baseUrl) == "string" and baseUrl ~= "" then
    return baseUrl
  end
  local BusinessHelper = import("BusinessHelper")
  if BusinessHelper.GetIMSDKEnv() == 0 then
    return FAMILYCENTER_TEST_BASE_URL
  end
  return FAMILYCENTER_PRODUCTION_BASE_URL
end

function logic_familycenter:ShouldBlockGameEntry()
  FCLog("ShouldBlockGameEntry", "enter gray=%s complianceGatePassed=%s", tostring(self.grayScaleEnabled), tostring(self.complianceGatePassed))
  if self:ShouldBypassInEditor() then
    FCLog("ShouldBlockGameEntry", "result=false reason=editor_bypass")
    return false
  end
  local logic_compliance = require("client.slua.logic.gdpr.logic_compliance")
  if logic_compliance.bInRegistrationFlow and self:IsRegisterLegacySDK() then
    FCLog("ShouldBlockGameEntry", "result=false reason=legacy_sdk_in_register")
    return false
  end
  if not self:IsInGrayScale() then
    FCLog("ShouldBlockGameEntry", "result=false reason=not_gray")
    return false
  end
  if self.complianceGatePassed then
    FCLog("ShouldBlockGameEntry", "result=false reason=flow_passed")
    return false
  end
  FCLog("ShouldBlockGameEntry", "result=true reason=flow_not_passed")
  ShowNotice(200009003)
  return true
end

function logic_familycenter:RequestAgeGate(opts, callback)
  FCLog("RequestAgeGate", "enter callback=%s", tostring(callback))
  FCLogTree("RequestAgeGate", "opts=", opts)
  opts = opts or {}
  if self.bIsPC then
    FCLog("RequestAgeGate", "result=nil reason=pc_not_supported")
    if callback then
      callback(nil)
    end
    return
  end
  local logic_compliance = require("client.slua.logic.gdpr.logic_compliance")
  local bAgeGateCanOpen = logic_compliance.IsEntryOpen() and logic_compliance.sdkInstance ~= nil
  local baseUrl = GetFamilyCenterWebviewBaseUrl(opts.baseUrl)
  local paramJson = opts.paramJson or ""
  local extraJson = opts.extraJson or ""
  self.legacyAgeGateStarted = true
  MarkLegacyAgeGateStarted(self, self.lastRawStatus)
  local reportComplete = opts.skipCompleteReport ~= true
  local wasCompleteBefore = reportComplete and self:IsAgeGateCertificationComplete()
  local callNonRegister = opts.skipCompleteReport ~= true
  FCLog("RequestAgeGate", "dispatch=SDKOpenAgeGate baseUrl=%s paramJson=%s extraJson=%s", tostring(baseUrl), tostring(paramJson), tostring(extraJson))
  local maskTimer
  
  local function clearWaitingMask(reason)
    if maskTimer then
      self:RemoveTimer(maskTimer)
      maskTimer = nil
    end
    logic_connection_waiting:Hide(0)
    FCLog("RequestAgeGate", "waitingMask=hide reason=%s", tostring(reason))
  end
  
  if bAgeGateCanOpen then
    self:ReportNewFlowEvent({
      IsComplete = false,
      rawData = self.lastRawStatus,
      NonRegister = callNonRegister
    })
    logic_connection_waiting:Show(0, true)
    FCLog("RequestAgeGate", "waitingMask=show")
    maskTimer = self:AddTimerOnce(10, function()
      maskTimer = nil
      clearWaitingMask("mask_timeout")
    end)
  end
  if bAgeGateCanOpen then
    self.bAgeGatePending = true
    self.ageGateAppReactivated = false
    self.ageGatePendingCallback = callback
  end
  logic_compliance.SDKOpenAgeGate(baseUrl, paramJson, extraJson, function(_sdkData)
    if self.bForceLogout then
      FCLog("RequestAgeGate", "callback result=skip reason=force_logout")
      return
    end
    if bAgeGateCanOpen then
      clearWaitingMask("sdk_callback")
    end
    FCLog("RequestAgeGate", "callback")
    self.bAgeGatePending = false
    self.ageGateAppReactivated = false
    self.ageGatePendingCallback = nil
    FCLogTree("RequestAgeGate", "sdkData=", _sdkData)
    local sdkExtraJson = _sdkData and _sdkData.extraJson
    local canceled = sdkExtraJson == nil or type(sdkExtraJson) == "string" and not string.find(sdkExtraJson, "\"state\"") or type(sdkExtraJson) == "table" and sdkExtraJson.state == nil
    local denied = false
    local granted = false
    if type(sdkExtraJson) == "string" then
      denied = string.find(sdkExtraJson, "\"DENIED\"") ~= nil
      granted = string.find(sdkExtraJson, "\"GRANTED\"") ~= nil
    elseif type(sdkExtraJson) == "table" then
      denied = sdkExtraJson.state == "DENIED"
      granted = sdkExtraJson.state == "GRANTED"
    end
    FCLog("RequestAgeGate", "canceled=%s denied=%s granted=%s extraJson=%s", tostring(canceled), tostring(denied), tostring(granted), tostring(sdkExtraJson))
    if canceled then
      local recheckDone = false
      local recheckTimer = self:AddTimerOnce(3, function()
        recheckTimer = nil
        if recheckDone or self.bForceLogout then
          return
        end
        recheckDone = true
        FCLog("RequestAgeGate", "canceledRecheck result=timeout, treat as incomplete")
        if callback then
          callback(nil, true)
        end
      end)
      self:RefreshStatusAfterSdkCallback(function(rawData)
        if recheckDone or self.bForceLogout then
          return
        end
        recheckDone = true
        if recheckTimer then
          self:RemoveTimer(recheckTimer)
          recheckTimer = nil
        end
        local completed = rawData ~= nil and IsCertificationComplete(rawData)
        FCLog("RequestAgeGate", "canceledRecheck completed=%s hasRawData=%s", tostring(completed), tostring(rawData ~= nil))
        if callback then
          callback(rawData, not completed)
        end
      end)
      return
    end
    self:RefreshStatusAfterSdkCallback(function(rawData)
      if reportComplete and granted and not wasCompleteBefore then
        self:ReportManualCertComplete(rawData)
      end
      if callback then
        callback(rawData, canceled, granted)
      end
    end)
  end)
end

function logic_familycenter:RefreshStatusAfterSdkCallback(callback)
  FCLog("RefreshStatusAfterSdkCallback", "enter callback=%s", tostring(callback))
  if self.bForceLogout then
    FCLog("RefreshStatusAfterSdkCallback", "result=skip reason=force_logout")
    return
  end
  local prevRawStatus = self.lastRawStatus
  self.lastRawStatus = nil
  self.rawStatusFetchFailed = false
  self.lastReportedStatus = nil
  self.pendingRawStatusFetch = nil
  FCLog("RefreshStatusAfterSdkCallback", "cacheCleared=true")
  self:FetchRawStatus(function(rawData)
    FCLog("RefreshStatusAfterSdkCallback", "callback hasRawData=%s", tostring(rawData ~= nil))
    FCLogTree("RefreshStatusAfterSdkCallback", "rawData=", rawData)
    local accepted, effectiveRawData = self:_CommitRawStatus(rawData, prevRawStatus)
    if not accepted then
      FCLog("RefreshStatusAfterSdkCallback", "result=keep_prev reason=empty_payload")
    end
    rawData = effectiveRawData
    local logic_compliance = require("client.slua.logic.gdpr.logic_compliance")
    ApplyLegacyGdprLocalState(rawData, {
      certificationStarted = self.legacyAgeGateStarted,
      sendMinorReport = self.legacyAgeGateStarted,
      sendUserType = true,
      allowAdultReport = true,
      setCertState = logic_compliance.bInRegistrationFlow == true,
      owner = self
    })
    local reportData = CopyBackendWhitelistedStatus(rawData)
    local bExemptNoCertChange = reportData ~= nil and self:IsLegacyPlayerExempt() and not IsCertDecisionChanged(prevRawStatus, rawData)
    if reportData and not self.bIsPC and not bExemptNoCertChange and not RawStatusEqual(BuildReportSnapshot(reportData), self.lastReportedStatus) then
      self.lastReportedStatus = BuildReportSnapshot(reportData)
      FCLog("RefreshStatusAfterSdkCallback", "reportStatus=true")
      self:ReportStatusToServer(rawData)
    else
      FCLog("RefreshStatusAfterSdkCallback", "reportStatus=false bIsPC=%s exemptNoCertChange=%s", tostring(self.bIsPC), tostring(bExemptNoCertChange))
    end
    if callback then
      FCLog("RefreshStatusAfterSdkCallback", "dispatch callback=%s", tostring(callback))
      callback(rawData)
    else
      FCLog("RefreshStatusAfterSdkCallback", "dispatch callback=nil")
    end
    self.legacyAgeGateStarted = false
  end)
end

function logic_familycenter:ShowPopup(popupType, opts)
  FCLog("ShowPopup", "enter popupType=%s", tostring(popupType))
  FCLogTree("ShowPopup", "opts=", opts)
  opts = opts or {}
  if popupType == PopupType.FAMILYCENTER_REAUTH then
    FCLog("ShowPopup", "dispatch=ShowFamilyCenterReAuthPopup")
    self:ShowFamilyCenterReAuthPopup(opts.parentEmail, opts.onClose)
  elseif popupType == PopupType.RECERTIFY then
    FCLog("ShowPopup", "dispatch=ShowReCertifyPopup")
    self:ShowReCertifyPopup(opts.onContinue, opts.onClose)
  elseif popupType == PopupType.PC_CERTIFY then
    FCLog("ShowPopup", "dispatch=ShowPCCertifyPopup")
    self:ShowPCCertifyPopup(opts.onClose)
  elseif popupType == PopupType.CERTIFY_INCOMPLETE then
    FCLog("ShowPopup", "dispatch=ShowCertifyIncompletePopup")
    self:ShowCertifyIncompletePopup(opts.countries or opts.country, opts.onCertifyPass, opts.onSkip, opts.onForceLogout)
  elseif popupType == PopupType.CHEST_BLOCKED or popupType == PopupType.MINOR_SERVICE_BLOCKED then
    FCLog("ShowPopup", "dispatch=ShowMinorServiceBlockedPopup popupType=%s", tostring(popupType))
    self:ShowMinorServiceBlockedPopup(opts.onClose)
  elseif popupType == PopupType.CHEST_IP_BLOCKED then
    FCLog("ShowPopup", "dispatch=ShowMinorServiceBlockedPopup reason=chest_ip_country")
    self:ShowMinorServiceBlockedPopup(opts.onClose, LOC_ID_CHEST_IP_BLOCKED_TIP)
  else
    FCLog("ShowPopup", "result=skip reason=unknown_popup_type popupType=%s", tostring(popupType))
  end
end

function logic_familycenter:ShowMinorServiceBlockedPopup(onClose, tipLocId)
  FCLog("ShowMinorServiceBlockedPopup", "enter onClose=%s tipLocId=%s", tostring(onClose), tostring(tipLocId))
  tipLocId = tipLocId or LOC_ID_MINOR_SERVICE_BLOCKED_TIP
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  
  local function callback()
    FCLog("ShowMinorServiceBlockedPopup", "callback=close")
    if onClose then
      onClose()
    end
  end
  
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_ONE, LocUtil.GetLocalizeResStr(75549), LocUtil.GetLocalizeResStr(tipLocId), callback, nil, LocUtil.GetLocalizeResStr(75542), nil, {androidCallback = callback})
  FCLog("ShowMinorServiceBlockedPopup", "result=shown")
end

function logic_familycenter:ShowFamilyCenterReAuthPopup(parentEmail, onClose)
  FCLog("ShowFamilyCenterReAuthPopup", "enter parentEmail=%s onClose=%s", tostring(parentEmail), tostring(onClose))
  
  local function onCertify()
    FCLog("ShowFamilyCenterReAuthPopup", "callback=certify")
    self:RequestAgeGate(nil, function(rawData, canceled, granted)
      FCLog("ShowFamilyCenterReAuthPopup", "ageGate callback hasRawData=%s canceled=%s granted=%s", tostring(rawData ~= nil), tostring(canceled), tostring(granted))
      FCLogTree("ShowFamilyCenterReAuthPopup", "rawData=", rawData)
      if onClose then
        onClose()
      end
    end)
  end
  
  UIManager.ShowUI(UIManager.UI_Config.AgeGate_Popup9_UIBP, parentEmail, onClose, onCertify)
  FCLog("ShowFamilyCenterReAuthPopup", "result=shown")
end

local function FinalizeAndLogout(module, onForceLogout)
  if module then
    module.bForceLogout = true
  end
  if onForceLogout then
    local callSuccess, callError = xpcall(onForceLogout, function(errorMessage)
      return debug.traceback(tostring(errorMessage), 2)
    end)
    if not callSuccess then
      local reportMessage = string.format("[logic_familycenter] finalization failed: %s", tostring(callError))
      FCLog("FinalizeAndLogout", "finalization_error=%s", tostring(callError))
      if type(log_error) == "function" then
        local reportSuccess, reportError = pcall(log_error, reportMessage)
        if not reportSuccess then
          FCLog("FinalizeAndLogout", "report_error_failed err=%s", tostring(reportError))
        end
      end
    end
  end
  local login_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module)
  login_module:sendLogout()
  logic_connection_waiting:Hide(0)
  login_module:backLogin()
end

local function OnceGuard()
  local fired = false
  return function(fn)
    return function()
      if fired then
        FCLog("OnceGuard", "callback=ignored reason=already_fired")
        return
      end
      fired = true
      if fn then
        fn()
      end
    end
  end
end

function logic_familycenter:IsAllowSkipCertification()
  local countries = self:_GetSwitchCountries()
  local allowSkip = self:_IsCountryComplianceSwitchOn(familycenter_macro.ENUM_COUNTRY_COMPLIANCE_SWITCH.ALLOW_TO_SKIP, countries)
  FCLogOnce("IsAllowSkipCertification", "result=%s countries=%s", tostring(allowSkip), table.concat(countries or {}, ","))
  return allowSkip
end

function logic_familycenter:ShowReCertifyPopup(onContinue, onClose)
  FCLog("ShowReCertifyPopup", "enter onContinue=%s onClose=%s", tostring(onContinue), tostring(onClose))
  if self.bIsPC then
    FCLog("ShowReCertifyPopup", "result=pc_dispatch reason=pc_no_sdk")
    self:ShowPCCertifyPopup(onClose)
    return
  end
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  local countries = self:_GetSwitchCountries()
  local allowSkip = self:_IsCountryComplianceSwitchOn(familycenter_macro.ENUM_COUNTRY_COMPLIANCE_SWITCH.ALLOW_TO_SKIP, countries)
  FCLog("ShowReCertifyPopup", "allowSkip=%s countries=%s", tostring(allowSkip), table.concat(countries, ","))
  local title = LocUtil.GetLocalizeResStr(75549)
  local content = LocUtil.GetLocalizeResStr(75543)
  local Once = OnceGuard()
  
  local function doCertify()
    FCLog("ShowReCertifyPopup", "callback=continue")
    self:RequestAgeGate(nil, function(_rawData)
      FCLog("ShowReCertifyPopup", "ageGate callback hasRawData=%s", tostring(_rawData ~= nil))
      FCLogTree("ShowReCertifyPopup", "rawData=", _rawData)
      if onContinue then
        onContinue()
      end
    end)
  end
  
  if allowSkip then
    CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_TWO, title, content, Once(doCertify), Once(function()
      FCLog("ShowReCertifyPopup", "callback=close")
      if onClose then
        onClose()
      end
    end), LocUtil.GetLocalizeResStr(75544), LocUtil.GetLocalizeResStr(75545))
    FCLog("ShowReCertifyPopup", "result=shown mode=allowSkip")
  else
    CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_TWO, title, content, Once(doCertify), Once(function()
      FCLog("ShowReCertifyPopup", "callback=close_logout")
      assert(type(FinalizeAndLogout) == "function", "FinalizeAndLogout must be defined before ShowReCertifyPopup")
      FinalizeAndLogout(self, nil)
    end), LocUtil.GetLocalizeResStr(75544), LocUtil.GetLocalizeResStr(75545), {
      androidCallback = function()
        FCLog("ShowReCertifyPopup", "androidBack=blocked")
        return true
      end
    })
    FCLog("ShowReCertifyPopup", "result=shown mode=must_certify_close_logout")
  end
end

function logic_familycenter:ShowPCCertifyPopup(onClose)
  FCLog("ShowPCCertifyPopup", "enter onClose=%s", tostring(onClose))
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_ONE, LocUtil.GetLocalizeResStr(75549), LocUtil.GetLocalizeResStr(75546), function()
    FCLog("ShowPCCertifyPopup", "callback=close")
    if onClose then
      onClose()
    end
  end, nil, LocUtil.GetLocalizeResStr(75545))
  FCLog("ShowPCCertifyPopup", "result=shown")
end

function logic_familycenter:ShowCertifyFailedThenLogout(onForceLogout, msg)
  FCLog("ShowCertifyFailedThenLogout", "enter onForceLogout=%s msg=%s", tostring(onForceLogout), tostring(msg))
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  local content = msg or LocUtil.GetLocalizeResStr(75547)
  
  local function callback()
    FCLog("ShowCertifyFailedThenLogout", "callback=confirm_logout")
    FinalizeAndLogout(self, onForceLogout)
  end
  
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_ONE, LocUtil.GetLocalizeResStr(75549), content, callback, nil, LocUtil.GetLocalizeResStr(75542), nil, {androidCallback = callback})
  FCLog("ShowCertifyFailedThenLogout", "result=shown")
end

function logic_familycenter:ShowCertifyIncompletePopup(countries, onCertifyPass, onSkip, onForceLogout)
  if type(countries) == "string" then
    countries = {countries}
  end
  countries = countries or {}
  local countriesText = table.concat(countries, ",")
  FCLog("ShowCertifyIncompletePopup", "enter countries=%s onCertifyPass=%s onSkip=%s onForceLogout=%s", countriesText, tostring(onCertifyPass), tostring(onSkip), tostring(onForceLogout))
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  local allowSkip = self:_IsCountryComplianceSwitchOn(familycenter_macro.ENUM_COUNTRY_COMPLIANCE_SWITCH.ALLOW_TO_SKIP, countries)
  FCLog("ShowCertifyIncompletePopup", "allowSkip=%s", tostring(allowSkip))
  local title = LocUtil.GetLocalizeResStr(75547)
  local content = LocUtil.GetLocalizeResStr(75548)
  
  local function showIncompleteThenRetry(reason)
    FCLog("ShowCertifyIncompletePopup", "dispatch=retry reason=%s", tostring(reason))
    self:ShowCertifyIncompletePopup(countries, onCertifyPass, onSkip, onForceLogout)
  end
  
  local Once = OnceGuard()
  
  local function doCertify()
    FCLog("ShowCertifyIncompletePopup", "callback=continue_certify")
    self:RequestAgeGate({skipCompleteReport = true}, function(rawData, canceled)
      FCLog("ShowCertifyIncompletePopup", "ageGate callback hasRawData=%s canceled=%s", tostring(rawData ~= nil), tostring(canceled))
      FCLogTree("ShowCertifyIncompletePopup", "rawData=", rawData)
      if canceled then
        FCLog("ShowCertifyIncompletePopup", "result=retry reason=webview_canceled")
        showIncompleteThenRetry("webview_canceled")
        return
      end
      if not rawData then
        FCLog("ShowCertifyIncompletePopup", "result=blocked reason=raw_data_nil")
        showIncompleteThenRetry("raw_data_nil")
        return
      end
      local adultCheck = rawData.adult_check_status
      local isAdultCheckValid, adultCheckExpiration, currentTimestamp = IsAdultCheckStatusValid(rawData)
      if not isAdultCheckValid then
        FCLog("ShowCertifyIncompletePopup", "result=blocked reason=adult_status_invalid_or_expired expiration=%s currentTimestamp=%s", tostring(adultCheckExpiration), tostring(currentTimestamp))
        showIncompleteThenRetry("adult_status_invalid_or_expired")
        return
      end
      local certificationComplete = IsCertificationComplete(rawData)
      local isAdultPass = adultCheck == 1 and certificationComplete
      local isMinorCertified = adultCheck == -1 and certificationComplete
      if isAdultPass then
        FCLog("ShowCertifyIncompletePopup", "result=pass reason=adult")
        if onCertifyPass then
          onCertifyPass()
        end
      elseif isMinorCertified then
        local certCountries = self:_GetSwitchCountries()
        if self:_IsCountryComplianceSwitchOn(familycenter_macro.ENUM_COUNTRY_COMPLIANCE_SWITCH.BLOCK_MINOR_ENTER, certCountries) then
          FCLog("ShowCertifyIncompletePopup", "result=blocked reason=minor_block_switch_on")
          self:ShowCertifyFailedThenLogout(onForceLogout, LocUtil.GetLocalizeResStr(87843))
        else
          FCLog("ShowCertifyIncompletePopup", "result=pass reason=minor_block_switch_off")
          if onCertifyPass then
            onCertifyPass()
          end
        end
      else
        FCLog("ShowCertifyIncompletePopup", "result=blocked reason=certification_incomplete")
        showIncompleteThenRetry("certification_incomplete")
      end
    end)
  end
  
  if allowSkip then
    CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_TWO, title, content, Once(doCertify), Once(function()
      if self.bForceLogout then
        return
      end
      FCLog("ShowCertifyIncompletePopup", "callback=skip no_report")
      if onSkip then
        onSkip()
      end
    end), LocUtil.GetLocalizeResStr(75544), LocUtil.GetLocalizeResStr(75545))
    FCLog("ShowCertifyIncompletePopup", "result=shown mode=allowSkip")
    self.bAutoCertPopupShown = true
  else
    CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_TWO, title, content, Once(doCertify), Once(function()
      FCLog("ShowCertifyIncompletePopup", "callback=close_logout")
      FinalizeAndLogout(self, onForceLogout)
    end), LocUtil.GetLocalizeResStr(75544), LocUtil.GetLocalizeResStr(75545), {
      androidCallback = function()
        FCLog("ShowCertifyIncompletePopup", "androidBack=blocked")
        return true
      end
    })
    FCLog("ShowCertifyIncompletePopup", "result=shown mode=must_certify_close_logout")
    self.bAutoCertPopupShown = true
  end
end

function logic_familycenter:IsInGrayScale()
  if self.cachedGrayScale ~= nil then
    return self.cachedGrayScale
  end
  local value = self:_CalcGrayScale()
  local countries = self:_GetSwitchCountries()
  if countries and 0 < #countries then
    self.cachedGrayScale = value
  end
  return value
end

function logic_familycenter:_CalcGrayScale()
  FCLogOnce("IsInGrayScale", "enter grayScaleEnabled=%s", tostring(self.grayScaleEnabled))
  if self.persistGrayScale ~= nil then
    FCLogOnce("IsInGrayScale", "result=%s reason=persist_prefs", tostring(self.persistGrayScale))
    return self.persistGrayScale
  end
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  if not PublishRegionMacros.IsGlobalOperationRegion() then
    FCLogOnce("IsInGrayScale", "result=false reason=not_global_version")
    return false
  end
  local bFamilyCenterSwitch = HDmpveRemote ~= nil and HDmpveRemote.HDmpveRemoteConfigGetInt ~= nil and 0 < HDmpveRemote.HDmpveRemoteConfigGetInt("FamilyCenterSwitch", 0)
  if not bFamilyCenterSwitch then
    FCLogOnce("IsInGrayScale", "result=false reason=master_switch_off")
    return false
  end
  if self.grayScaleEnabled ~= nil then
    FCLogOnce("IsInGrayScale", "result=%s reason=gm_override", tostring(self.grayScaleEnabled))
    return self.grayScaleEnabled
  end
  local logic_familycenter_fit = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_familycenter_fit)
  if logic_familycenter_fit:ShouldSkipGrayScale() then
    FCLogOnce("IsInGrayScale", "result=false reason=fit_grace_period_force_country")
    return false
  end
  local countries = self:_GetSwitchCountries()
  for _, country in ipairs(countries) do
    local regionConfig = CDataTable.GetTableDataByFilter("RegionConfig", "RegionCode", country)
    if regionConfig and regionConfig.UseFamilyCenter == 1 then
      FCLog("IsInGrayScale", "result=true reason=region_enabled country=%s countries=%s", tostring(country), table.concat(countries, ","))
      return true
    end
    FCLog("IsInGrayScale", "candidate=%s regionConfig=%s useFamilyCenter=%s", tostring(country), tostring(regionConfig ~= nil), tostring(regionConfig and regionConfig.UseFamilyCenter))
  end
  FCLog("IsInGrayScale", "result=false reason=region_disabled countries=%s", table.concat(countries, ","))
  return false
end

local LEGACY_SDK_HARD_EXCLUDE_REGION = {CA = true, BR = true}

function logic_familycenter:IsRegisterLegacySDK()
  local countries = self:_GetSwitchCountries()
  if not countries or #countries == 0 then
    FCLogOnce("IsRegisterLegacySDK", "result=false reason=missing_country")
    return false
  end
  for _, country in ipairs(countries) do
    if LEGACY_SDK_HARD_EXCLUDE_REGION[country] then
      FCLogOnce("IsRegisterLegacySDK", "result=false reason=hard_exclude country=%s", tostring(country))
      return false
    end
  end
  for _, country in ipairs(countries) do
    local regionConfig = CDataTable.GetTableDataByFilter("RegionConfig", "RegionCode", country)
    if regionConfig and tonumber(regionConfig.UseLegacySDKInRegister) == 1 then
      FCLogOnce("IsRegisterLegacySDK", "result=true country=%s useLegacySDKInRegister=1", tostring(country))
      return true
    end
  end
  FCLogOnce("IsRegisterLegacySDK", "result=false reason=region_disabled countries=%s", table.concat(countries, ","))
  return false
end

function logic_familycenter:SetGrayScale(enabled)
  FCLog("SetGrayScale", "enter enabled=%s", tostring(enabled))
  if enabled == nil then
    self.grayScaleEnabled = nil
  else
    self.grayScaleEnabled = enabled == true
  end
  self.cachedGrayScale = nil
  FCLog("SetGrayScale", "result grayScaleEnabled=%s", tostring(self.grayScaleEnabled))
end

function logic_familycenter:HasAutoCertPopupShown()
  return self.bAutoCertPopupShown == true
end

local function GetLocalTestPrefsConfig()
  local ok, cfg = pcall(require, "client.slua.config.PlayerPrefsConfig")
  if ok and cfg then
    return cfg.eFamilyCenterLocalTest
  end
  return nil
end

local function GetLogicPlayerPrefs()
  local ok, mod = pcall(require, "client.logic.LogicPlayerPrefs.LogicPlayerPrefs")
  if ok and mod then
    return mod
  end
  return nil
end

function logic_familycenter:_LoadLocalTestPersist()
  if self.localTestPersistLoaded then
    return
  end
  self.localTestPersistLoaded = true
  local cfg = GetLocalTestPrefsConfig()
  local prefs = GetLogicPlayerPrefs()
  if not cfg or not prefs then
    FCLog("LoadLocalTestPersist", "result=skip reason=no_prefs")
    return
  end
  local data = prefs.LoadFileToData_N(cfg) or {}
  if data.grayScale == "1" or data.grayScale == "0" then
    self.persistGrayScale = data.grayScale == "1"
  end
  if type(data.ipRegion) == "string" and data.ipRegion ~= "" then
    self.persistIpRegion = data.ipRegion
  end
  FCLog("LoadLocalTestPersist", "grayScale=%s ipRegion=%s", tostring(self.persistGrayScale), tostring(self.persistIpRegion))
end

function logic_familycenter:_SaveLocalTestPersist(field, value)
  local cfg = GetLocalTestPrefsConfig()
  local prefs = GetLogicPlayerPrefs()
  if not cfg or not prefs then
    return false
  end
  local data = prefs.LoadFileToData_N(cfg) or {}
  data[field] = value
  prefs.SaveDataToFile_N(data, cfg)
  self.localTestPersistLoaded = true
  return true
end

function logic_familycenter:_ApplyIpRegionOverride()
  local login_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module)
  if not login_module then
    return nil
  end
  local target = self.persistIpRegion
  local bChanged = false
  if target ~= nil then
    if login_module.sIpRegion ~= target then
      if self.originIpRegion == nil then
        self.originIpRegion = login_module.sIpRegion
      end
      login_module.sIpRegion = target
      bChanged = true
      FCLog("ApplyIpRegionOverride", "apply=%s origin=%s", tostring(target), tostring(self.originIpRegion))
    end
  elseif self.originIpRegion ~= nil then
    if login_module.sIpRegion ~= self.originIpRegion then
      login_module.sIpRegion = self.originIpRegion
      bChanged = true
      FCLog("ApplyIpRegionOverride", "restore=%s", tostring(self.originIpRegion))
    end
    self.originIpRegion = nil
  end
  if bChanged then
    self.cachedGrayScale = nil
  end
  return login_module.sIpRegion
end

function logic_familycenter:SetGrayScalePersist(enabled)
  local value
  if enabled ~= nil then
    value = enabled and "1" or "0"
  end
  local writeOk = self:_SaveLocalTestPersist("grayScale", value)
  self.persistGrayScale = enabled
  self.cachedGrayScale = nil
  self.grayScaleEnabled = enabled
  FCLog("SetGrayScalePersist", "enabled=%s writeOk=%s storage=LogicPlayerPrefs", tostring(enabled), tostring(writeOk))
end

function logic_familycenter:SetIpRegionPersist(country)
  local value
  if country ~= nil and tostring(country) ~= "" then
    value = tostring(country)
  end
  local writeOk = self:_SaveLocalTestPersist("ipRegion", value)
  self.persistIpRegion = value
  self.localTestPersistLoaded = true
  local applied = self:_ApplyIpRegionOverride()
  FCLog("SetIpRegionPersist", "region=%s writeOk=%s applied=%s", tostring(value), tostring(writeOk), tostring(applied))
end

function logic_familycenter:BeginNewFlow(flowEndCallback, flowEndForbiddenCallback)
  FCLog("BeginNewFlow", "enter flowEndCallback=%s flowEndForbiddenCallback=%s", tostring(flowEndCallback), tostring(flowEndForbiddenCallback))
  if self.bForceLogout then
    return
  end
  self:_ClearNewFlowWaitTimer()
  local pendingCallback = flowEndCallback
  
  function flowEndCallback()
    local callback = pendingCallback
    pendingCallback = nil
    if type(callback) == "function" then
      callback()
    end
  end
  
  local function PassLegacyPlayer()
    if not self:IsLegacyPlayerExempt() then
      return false
    end
    self.complianceGatePassed = true
    self.newFlowEndCallback = nil
    if type(flowEndCallback) == "function" then
      flowEndCallback()
    end
    return true
  end
  
  if PassLegacyPlayer() then
    return
  end
  if self:ShouldBypassInEditor() then
    FCLog("BeginNewFlow", "result=pass reason=editor")
    if type(flowEndCallback) == "function" then
      flowEndCallback()
    end
    return
  end
  local logic_compliance = require("client.slua.logic.gdpr.logic_compliance")
  self.newFlowEndCallback = flowEndCallback
  self.legacyAgeGateStarted = false
  
  local function OnRawStatus(rawData)
    self:_ClearNewFlowWaitTimer()
    if self.bForceLogout or PassLegacyPlayer() then
      return
    end
    FCLog("BeginNewFlow", "callback hasRawData=%s bIsPC=%s", tostring(rawData ~= nil), tostring(self.bIsPC))
    FCLogTree("BeginNewFlow", "rawData=", rawData)
    local accepted, effectiveRawData = self:_CommitRawStatus(rawData)
    if not accepted then
      FCLog("BeginNewFlow", "result=keep_prev reason=empty_payload")
    end
    rawData = effectiveRawData
    self.newFlowSkipReport = not logic_compliance.bInRegistrationFlow and IsAdultPass(rawData)
    FCLog("BeginNewFlow", "newFlowSkipReport=%s", tostring(self.newFlowSkipReport))
    SyncRegisterCountry(rawData)
    ApplyLegacyGdprLocalState(rawData, {setCertState = false, owner = self})
    local reportData = CopyBackendWhitelistedStatus(rawData)
    if reportData and not self.bIsPC and not RawStatusEqual(BuildReportSnapshot(reportData), self.lastReportedStatus) then
      self.lastReportedStatus = BuildReportSnapshot(reportData)
      FCLog("BeginNewFlow", "reportStatus=true")
      self:ReportStatusToServer(rawData)
    else
      FCLog("BeginNewFlow", "reportStatus=false bIsPC=%s", tostring(self.bIsPC))
    end
    local country = self:_GetIpCountryCode()
    local countries = self:_GetSwitchCountries()
    if not rawData then
      if not self:IsSdkUnavailableFailClosed() then
        FCLog("BeginNewFlow", "result=pass reason=sdk_unavailable platform=%s country=%s", self.bIsPC and "pc" or "mobile", tostring(country))
        self:EndNewFlow(true, logic_compliance.AUTH_FLOW_REGISTER_COMPLIANCE_TYPE.AUTH_SKIPPED, true)
        return
      end
      if self.bIsPC then
        FCLog("BeginNewFlow", "branch=raw_data_nil fail_closed_ip=true platform=pc country=%s", tostring(country))
        self:ShowPopup(PopupType.PC_CERTIFY, {
          onClose = function()
            FCLog("BeginNewFlow", "callback=pc_certify_close country=%s", tostring(country))
            self:EndNewFlow(true, logic_compliance.AUTH_FLOW_REGISTER_COMPLIANCE_TYPE.AUTH_SKIPPED)
          end
        })
      else
        FCLog("BeginNewFlow", "branch=raw_data_nil fail_closed_ip=true platform=mobile country=%s", tostring(country))
        self:ShowCertifyIncompletePopup(countries, function()
          self:EndNewFlow(true, logic_compliance.AUTH_FLOW_REGISTER_COMPLIANCE_TYPE.SDK_SUCCESS_CALLBACK)
        end, function()
          self:EndNewFlow(true, logic_compliance.AUTH_FLOW_REGISTER_COMPLIANCE_TYPE.AUTH_SKIPPED)
        end, function()
          self:EndNewFlow(false)
        end)
      end
      return
    end
    local adultCheck = rawData.adult_check_status
    local needAdultVerif = rawData.need_adult_verification
    local isAdultCheckValid, adultCheckExpiration, currentTimestamp = IsAdultCheckStatusValid(rawData)
    if not isAdultCheckValid then
      FCLog("BeginNewFlow", "branch=adult_status_invalid_or_expired expiration=%s currentTimestamp=%s country=%s", tostring(adultCheckExpiration), tostring(currentTimestamp), tostring(country))
    end
    if isAdultCheckValid and adultCheck == 1 and IsCertificationComplete(rawData) then
      FCLog("BeginNewFlow", "result=pass reason=adult country=%s", tostring(country))
      local certNotRequired = needAdultVerif == 0
      self:EndNewFlow(true, logic_compliance.AUTH_FLOW_REGISTER_COMPLIANCE_TYPE.NO_NEED_COMPLY, not certNotRequired)
      return
    end
    if isAdultCheckValid and adultCheck == -1 and IsCertificationComplete(rawData) then
      if self:_IsCountryComplianceSwitchOn(familycenter_macro.ENUM_COUNTRY_COMPLIANCE_SWITCH.BLOCK_MINOR_ENTER, countries) then
        if self.bIsPC then
          FCLog("BeginNewFlow", "result=pass reason=minor_certified_block_switch_on_pc_bypass country=%s", tostring(country))
          self:EndNewFlow(true, logic_compliance.AUTH_FLOW_REGISTER_COMPLIANCE_TYPE.SDK_SUCCESS_CALLBACK)
        else
          FCLog("BeginNewFlow", "result=blocked reason=minor_certified_block_switch_on country=%s", tostring(country))
          self:ShowCertifyFailedThenLogout(nil, LocUtil.GetLocalizeResStr(87843))
        end
      else
        FCLog("BeginNewFlow", "result=pass reason=minor_certified_block_switch_off country=%s", tostring(country))
        self:EndNewFlow(true, logic_compliance.AUTH_FLOW_REGISTER_COMPLIANCE_TYPE.SDK_SUCCESS_CALLBACK, true)
      end
      return
    end
    if self.bIsPC then
      FCLog("BeginNewFlow", "branch=certification_required platform=pc country=%s", tostring(country))
      self:ShowPopup(PopupType.PC_CERTIFY, {
        onClose = function()
          FCLog("BeginNewFlow", "callback=pc_certify_close platform=pc")
          self:EndNewFlow(true, logic_compliance.AUTH_FLOW_REGISTER_COMPLIANCE_TYPE.AUTH_SKIPPED)
        end
      })
    else
      FCLog("BeginNewFlow", "branch=certification_required platform=mobile country=%s", tostring(country))
      self:ShowCertifyIncompletePopup(countries, function()
        self:EndNewFlow(true, logic_compliance.AUTH_FLOW_REGISTER_COMPLIANCE_TYPE.SDK_SUCCESS_CALLBACK)
      end, function()
        self:EndNewFlow(true, logic_compliance.AUTH_FLOW_REGISTER_COMPLIANCE_TYPE.AUTH_SKIPPED)
      end, function()
        self:EndNewFlow(false)
      end)
    end
  end
  
  if self.footprintFetching and self.hasComplianceFootprint == nil then
    self.pendingNewFlowReentry = {flowEndCallback = flowEndCallback, flowEndForbiddenCallback = flowEndForbiddenCallback}
    FCLog("BeginNewFlow", "result=defer reason=pending_compliance_footprint")
    return
  end
  if self.lastRawStatus ~= nil then
    FCLog("BeginNewFlow", "result=reuse_last_raw_status")
    OnRawStatus(self.lastRawStatus)
    return
  end
  if self.pendingRawStatusFetch then
    self.pendingNewFlowReentry = {flowEndCallback = flowEndCallback, flowEndForbiddenCallback = flowEndForbiddenCallback}
    self:_ClearNewFlowWaitTimer()
    self.newFlowWaitTimer = self:AddTimerOnce(NEW_FLOW_FETCH_TIMEOUT_SECONDS, function()
      self.newFlowWaitTimer = nil
      if self.bForceLogout or not self.pendingNewFlowReentry then
        return
      end
      self.pendingNewFlowReentry = nil
      FCLog("BeginNewFlow", "result=timeout reason=pending_raw_status_fetch timeout=%s", tostring(NEW_FLOW_FETCH_TIMEOUT_SECONDS))
      OnRawStatus(nil)
    end)
    FCLog("BeginNewFlow", "result=defer reason=pending_raw_status_fetch")
    return
  end
  local newFlowFetchDone = false
  self:_ClearNewFlowWaitTimer()
  self.newFlowWaitTimer = self:AddTimerOnce(NEW_FLOW_FETCH_TIMEOUT_SECONDS, function()
    self.newFlowWaitTimer = nil
    if newFlowFetchDone or self.bForceLogout then
      return
    end
    newFlowFetchDone = true
    FCLog("BeginNewFlow", "result=timeout reason=raw_status_fetch timeout=%s", tostring(NEW_FLOW_FETCH_TIMEOUT_SECONDS))
    OnRawStatus(nil)
  end)
  self:FetchRawStatus(function(rawData)
    if newFlowFetchDone then
      return
    end
    newFlowFetchDone = true
    OnRawStatus(rawData)
  end)
end

function logic_familycenter:EndNewFlow(pass, registerComplianceType, skipCompleteReport)
  FCLog("EndNewFlow", "enter pass=%s registerComplianceType=%s skipCompleteReport=%s", tostring(pass), tostring(registerComplianceType), tostring(skipCompleteReport))
  self:_ClearNewFlowWaitTimer()
  if pass then
    local logic_compliance = require("client.slua.logic.gdpr.logic_compliance")
    if registerComplianceType == logic_compliance.AUTH_FLOW_REGISTER_COMPLIANCE_TYPE.AUTH_SKIPPED then
      FCLog("EndNewFlow", "branch=skipped state_unchanged minorCertStatus=%s", tostring(DataMgr and DataMgr.minor_cert_status))
    else
      ApplyLegacyGdprLocalState(self.lastRawStatus, {
        forceFinish = true,
        sendMinorReport = true,
        forceReport = true,
        sendUserType = true,
        allowAdultReport = registerComplianceType == logic_compliance.AUTH_FLOW_REGISTER_COMPLIANCE_TYPE.SDK_SUCCESS_CALLBACK,
        setCertState = logic_compliance.bInRegistrationFlow == true,
        owner = self
      })
    end
    if skipCompleteReport then
      FCLog("EndNewFlow", "skipCompleteReport=true reason=no_auth_action_this_session")
    else
      self:ReportNewFlowEvent({
        IsComplete = true,
        RegisterComplianceType = registerComplianceType or logic_compliance.AUTH_FLOW_REGISTER_COMPLIANCE_TYPE.SDK_SUCCESS_CALLBACK
      })
    end
    FCLog("EndNewFlow", "result=pass registerComplianceType=%s", tostring(registerComplianceType))
    self.complianceGatePassed = true
    if self.newFlowEndCallback then
      FCLog("EndNewFlow", "dispatch callback=%s", tostring(self.newFlowEndCallback))
      self.newFlowEndCallback()
    else
      FCLog("EndNewFlow", "dispatch callback=nil")
    end
  else
    FCLog("EndNewFlow", "result=blocked reason=force_logout_pending")
  end
end

function logic_familycenter:ReportNewFlowEvent(params)
  FCLog("ReportNewFlowEvent", "enter")
  FCLogTree("ReportNewFlowEvent", "params=", params)
  params = params or {}
  if self.bIsPC then
    FCLog("ReportNewFlowEvent", "result=skip reason=platform_pc")
    return
  end
  local logic_compliance = require("client.slua.logic.gdpr.logic_compliance")
  if type(params.IsComplete) ~= "boolean" then
    FCLog("ReportNewFlowEvent", "result=skip reason=invalid_is_complete")
    return
  end
  if self.newFlowSkipReport == true then
    FCLog("ReportNewFlowEvent", "result=skip reason=adult_existing_user isComplete=%s", tostring(params.IsComplete))
    return
  end
  if params.IsComplete and type(params.RegisterComplianceType) ~= "number" then
    FCLog("ReportNewFlowEvent", "result=skip reason=missing_register_compliance_type")
    return
  end
  local noNeedComplyType = logic_compliance.AUTH_FLOW_REGISTER_COMPLIANCE_TYPE.NO_NEED_COMPLY
  if params.IsComplete and params.RegisterComplianceType == noNeedComplyType then
    if self.newFlowReportedTypes[noNeedComplyType] then
      FCLog("ReportNewFlowEvent", "result=skip reason=duplicate_no_need_comply")
      return
    end
    self.newFlowReportedTypes[noNeedComplyType] = true
  end
  local inRegistration = params.NonRegister ~= true and logic_compliance.bInRegistrationFlow
  local eventStep
  if inRegistration then
    eventStep = params.IsComplete and familycenter_macro.ENUM_NEW_FLOW_EVENT_STEP.COMPLETE_REGISTER or familycenter_macro.ENUM_NEW_FLOW_EVENT_STEP.CALL_API_REGISTER
  else
    eventStep = params.IsComplete and familycenter_macro.ENUM_NEW_FLOW_EVENT_STEP.COMPLETE_NON_REGISTER or familycenter_macro.ENUM_NEW_FLOW_EVENT_STEP.CALL_API_NON_REGISTER
  end
  local rawData = params.rawData or self.lastRawStatus
  local ageGroupResult = 0
  local adultCheckStatus = rawData and rawData.adult_check_status
  if adultCheckStatus == 1 then
    ageGroupResult = 1
  elseif adultCheckStatus == -1 or adultCheckStatus == -2 then
    ageGroupResult = 2
  end
  local authBranch = type(params.AuthBranch) == "number" and params.AuthBranch or rawData and type(rawData.auth_branch) == "number" and rawData.auth_branch or 0
  local msg = {
    EventStep = eventStep,
    Region = rawData and rawData.region and tostring(rawData.region) or "",
    AgeGroupResult = ageGroupResult,
    AuthBranch = authBranch,
    ParentEmail = rawData and type(rawData.email) == "string" and rawData.email or "",
    RegisterComplianceType = params.RegisterComplianceType or 0
  }
  if rawData and rawData.realname_auth_type ~= nil then
    msg.realname_auth_type = rawData.realname_auth_type
  end
  if rawData and rawData.adult_verification_type ~= nil then
    msg.adult_verification_type = rawData.adult_verification_type
  end
  if rawData and rawData.parent_adult_verification_type ~= nil then
    msg.parent_adult_verification_type = rawData.parent_adult_verification_type
  end
  FCLog("ReportNewFlowEvent", "dispatch eventStep=%s ageGroupResult=%s authBranch=%s registerComplianceType=%s", tostring(msg.EventStep), tostring(msg.AgeGroupResult), tostring(msg.AuthBranch), tostring(msg.RegisterComplianceType))
  FCLogTree("ReportNewFlowEvent", "msg=", msg)
  local FamilyCenterHandler = require("client.network.Protocol.FamilyCenterHandler")
  FamilyCenterHandler.send_report_minor_compliance_auth_flow_new_req(msg)
  FCLog("ReportNewFlowEvent", "result=dispatched")
end

function logic_familycenter:ReportManualCertComplete(rawData)
  FCLog("ReportManualCertComplete", "enter hasRawData=%s", tostring(rawData ~= nil))
  local logic_compliance = require("client.slua.logic.gdpr.logic_compliance")
  self:ReportNewFlowEvent({
    IsComplete = true,
    RegisterComplianceType = logic_compliance.AUTH_FLOW_REGISTER_COMPLIANCE_TYPE.SDK_SUCCESS_CALLBACK,
    rawData = rawData,
    NonRegister = true
  })
end

function logic_familycenter:AddStatusUpdateListener(listener, handler)
  FCLog("AddStatusUpdateListener", "enter listener=%s handler=%s", tostring(listener), tostring(handler))
  if listener and handler and listener.BindLuaObjEvent then
    listener:BindLuaObjEvent(self, "OnStatusUpdated", handler, listener)
  else
    self:BindLuaObjEvent(listener, "OnStatusUpdated", handler, listener)
  end
  FCLog("AddStatusUpdateListener", "result=bound")
end

function logic_familycenter:RemoveStatusUpdateListener(listener)
  FCLog("RemoveStatusUpdateListener", "enter listener=%s", tostring(listener))
  if listener and listener.UnBindLuaObjEvent then
    listener:UnBindLuaObjEvent(self, "OnStatusUpdated")
  else
    self:UnBindLuaObjEvent(listener, "OnStatusUpdated")
  end
  FCLog("RemoveStatusUpdateListener", "result=unbound")
end

function logic_familycenter:HandleComplianceBlocked(result)
  FCLog("HandleComplianceBlocked", "enter")
  FCLogTree("HandleComplianceBlocked", "result=", result)
  local POPUP = familycenter_macro.ENUM_POPUP_TYPE
  local RESULT = familycenter_macro.ENUM_RESULT
  local resultEnum = result and result.result
  if self.bForceLogout then
    FCLog("HandleComplianceBlocked", "result=skip reason=force_logout")
    return
  end
  if resultEnum == RESULT.CHEST_IP_BLOCKED then
    FCLog("HandleComplianceBlocked", "dispatch popup=CHEST_IP_BLOCKED")
    self:ShowPopup(POPUP.CHEST_IP_BLOCKED)
    return
  end
  if self:IsLegacyPlayerExempt() then
    FCLog("HandleComplianceBlocked", "result=skip reason=legacy_exempt")
    return
  end
  FCLog("HandleComplianceBlocked", "resultEnum=%s scene=%s bIsPC=%s", tostring(resultEnum), tostring(result and result.scene), tostring(self.bIsPC))
  if resultEnum == RESULT.MINOR_CHEST_BLOCKED or resultEnum == RESULT.MINOR_CREATOR_BLOCKED or resultEnum == RESULT.MINOR_OVERUSE_BLOCKED then
    FCLog("HandleComplianceBlocked", "dispatch popup=MINOR_SERVICE_BLOCKED")
    self:ShowPopup(POPUP.MINOR_SERVICE_BLOCKED)
    return
  end
  if self.bIsPC then
    self:ShowPopup(POPUP.PC_CERTIFY)
    return
  end
  local adultCheck = tonumber(result.rawData and result.rawData.adult_check_status)
  local isMinorBlocked = adultCheck == -1 or adultCheck == -2
  if resultEnum == RESULT.MINOR_DENIED or resultEnum == RESULT.MINOR_NO_AUTH_BLOCK and isMinorBlocked then
    FCLog("HandleComplianceBlocked", "dispatch popup=FAMILYCENTER_REAUTH resultEnum=%s adultCheck=%s", tostring(resultEnum), tostring(adultCheck))
    self:ShowPopup(POPUP.FAMILYCENTER_REAUTH, {
      parentEmail = result.rawData and result.rawData.email,
      onClose = function()
      end
    })
  elseif resultEnum == RESULT.MINOR_NO_AUTH_BLOCK or resultEnum == RESULT.UNCERTIFIED_BLOCK then
    FCLog("HandleComplianceBlocked", "dispatch popup=RECERTIFY resultEnum=%s adultCheck=%s", tostring(resultEnum), tostring(adultCheck))
    self:ShowPopup(POPUP.RECERTIFY)
  else
    FCLog("HandleComplianceBlocked", "result=skip reason=no_matched_popup resultEnum=%s", tostring(resultEnum))
  end
end

function logic_familycenter:HandleComplianceUnavailable(result)
  if self.bForceLogout or self:IsLegacyPlayerExempt() then
    FCLog("HandleComplianceUnavailable", "result=skip reason=force_logout_or_legacy_exempt")
    return
  end
  local fetchId = result and result.fetchId
  if fetchId and self.lastUnavailableNoticeFetchId == fetchId then
    FCLog("HandleComplianceUnavailable", "result=skip reason=already_notified fetchId=%s", tostring(fetchId))
    return
  end
  if fetchId then
    self.lastUnavailableNoticeFetchId = fetchId
  end
  FCLog("HandleComplianceUnavailable", "dispatch=ShowNotice reason=%s fetchId=%s", tostring(result and result.reason), tostring(fetchId))
  ShowNotice(120164)
end

local class = require("class")
local CModuleBase = require("client.module_framework.ModuleBase")
local Clogic_familycenter = class(CModuleBase, nil, logic_familycenter)
return Clogic_familycenter
