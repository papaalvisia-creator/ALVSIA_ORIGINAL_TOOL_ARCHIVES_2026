local AvatarDownload = {}
local Trait = require("common.trait")
local TAvatarDownload = Trait(Trait.TraitPrototype, nil, AvatarDownload)

local function AppendWowPreviewKeys(nItemId, tList)
  local logic_ugc_wowpass_award = require("client.slua.logic.ugc.WowPass.logic_ugc_wowpass_award")
  local sBpPath = logic_ugc_wowpass_award.GetItemBPPath(nItemId)
  if sBpPath and sBpPath ~= "" then
    table.insert(tList, sBpPath)
  end
  local tHomePageData = CDataTable.GetTableData("Dress_HomePageConfig", nItemId)
  if tHomePageData then
    if tHomePageData.InfoCardBluprint and tHomePageData.InfoCardBluprint ~= "" then
      table.insert(tList, tHomePageData.InfoCardBluprint)
    end
    if tHomePageData.InfoCardBluprintAni and tHomePageData.InfoCardBluprintAni ~= "" then
      table.insert(tList, tHomePageData.InfoCardBluprintAni)
    end
  end
end

local function AppendIconKeys(nItemId, tList)
  local uObj_itemCfg = CDataTable.GetTableData("Item", nItemId)
  if not uObj_itemCfg then
    return
  end
  local tIconPaths = {
    uObj_itemCfg.ItemSmallIcon,
    uObj_itemCfg.ItemSmallIcon2,
    uObj_itemCfg.ItemBigIcon,
    uObj_itemCfg.ItemBigIcon2
  }
  for _, sIconPath in ipairs(tIconPaths) do
    if sIconPath and sIconPath ~= "" then
      table.insert(tList, sIconPath)
    end
  end
end

local function AppendUGCInventoryDependKeys(nItemId, tList)
  local logic_ugc_inventory = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_inventory)
  if not logic_ugc_inventory or not nItemId then
    return
  end
  local TabID = logic_ugc_inventory:GetTabIDDigits(nItemId)
  local SubTabID = logic_ugc_inventory:GetSubTabIDDigits(nItemId)
  if not (TabID and not (TabID <= 0) and SubTabID) or SubTabID <= 0 then
    return
  end
  local UGC_Inventory = require("client.slua.logic.ugc.ugc_Inventory")
  local tabIndex = logic_ugc_inventory:FindTabIndexByTabId(TabID)
  local subTabIndex = logic_ugc_inventory:FindSubTabIndexBySubTabId(tabIndex, SubTabID)
  if not tabIndex or not subTabIndex then
    return
  end
  local inventoryTabData = UGC_Inventory.InventoryList[tabIndex]
  if not inventoryTabData or not inventoryTabData[subTabIndex] then
    return
  end
  local Data = CDataTable.GetTableData(inventoryTabData[subTabIndex].DataName, nItemId)
  local DownData = logic_ugc_inventory:GetDownloadList(Data)
  if DownData and next(DownData) then
    for _, v in pairs(DownData) do
      if v and v ~= 0 then
        table.insert(tList, v)
      end
    end
  end
end

local function GetPreviewAreaCenterOffset(SceneType)
  local ConstAvatarDislay = require("client.slua.traits.DetailComponent.AvatarDisplay.ConstAvatarDislay")
  local zone = SceneType and ConstAvatarDislay.UIRestrictZone[SceneType]
  if not zone then
    return nil
  end
  local centerX = zone.Left + (zone.ScreenX - zone.Left - zone.Right) * 0.5
  local centerY = zone.Up + (zone.ScreenY - zone.Up - zone.Down) * 0.5
  local offsetX = centerX - zone.ScreenX * 0.5
  local offsetY = centerY - zone.ScreenY * 0.5
  log_format("AvatarDownload:GetPreviewAreaCenterOffset. SceneType=%s, offset=(%s,%s)", tostring(SceneType), tostring(offsetX), tostring(offsetY))
  return FVector2D(offsetX, offsetY)
end

function AvatarDownload:UpdateAvatarDownload(ItemID, ItemType, DetailData)
  if not (ItemID and ItemType) or ItemID <= 0 or ItemType <= 0 then
    return
  end
  if self.bForbidDownloadPanel then
    self:HideDownloadPanel()
    return
  end
  local common_download_handler = require("client.slua.common.common_download_handler")
  local PufferTlog = require("client.slua.logic.download.report.puffer_tlog")
  local params = {
    showGray = true,
    hideMask = true,
    showSize = true,
    pos = FVector2D(64, -40),
    size = 60,
    from = PufferTlog.Enum_TLog_From.DetailAvatar
  }
  if DetailData and DetailData.bDownloadIconInCenter then
    params.isInCenter = true
    params.pos = DetailData.downloadIconPos or GetPreviewAreaCenterOffset(self.SceneType)
    params.size = DetailData.downloadIconSize or params.size
    params.offsetRoot = DetailData.bOffsetCenterDownloadRoot == true
  end
  local list = {ItemID}
  AppendWowPreviewKeys(ItemID, list)
  AppendUGCInventoryDependKeys(ItemID, list)
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  local isFitVersion = PublishRegionMacros.IsFITVersion()
  if isFitVersion then
    local ItemCfg = CDataTable.GetTableData("Item", ItemID)
    if ItemCfg and ItemCfg.ItemSubType == ENUM_ITEM_SUBTYPE.BrandTemplate then
      local ShowBrandConst = require("client.slua.logic.showbrand.ShowBrandConst")
      if ItemID ~= ShowBrandConst.GeneralEmoteId then
        table.insert(list, ShowBrandConst.GeneralEmoteId)
      end
    end
  end
  local ModelDisplayTypeHelper = require("client.logic.avatar.ModelDisplayTypeHelper")
  if ModelDisplayTypeHelper.IsPetType(ItemType) then
    local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
    for _, v in pairs(logic_pet:GetDownloadList(ItemID)) do
      table.insert(list, v)
    end
  end
  local party_item_cfg = CDataTable.GetTableData("Item", ItemID)
  if party_item_cfg and ModelDisplayTypeHelper.IsPartyEffect(party_item_cfg.ItemType, party_item_cfg.ItemSubType) then
    local party_cfg = CDataTable.GetTableDataByFilter("TeamupEntryParticleConfig", "ItemID", ItemID)
    if party_cfg and party_cfg.ItemID and party_cfg.ItemID ~= 0 then
      table.insert(list, party_cfg.ItemID)
      table.insert(list, party_cfg.AudioPath)
      table.insert(list, party_cfg.EffectPath)
    end
  end
  local LadderCarDetailConfig = require("client.slua.logic.lobby_activity.LadderCarDetailConfig")
  if LadderCarDetailConfig.IsRareCar(ItemID) then
    log(bWriteLog and "AvatarDownload:UpdateAvatarDownload is rare car " .. tostring(ItemID))
    local LadderDrawSystem = require("client.slua.logic.lobby_activity.logic_ladder_draw")
    local config = LadderDrawSystem.GetUIConfig(LadderDrawSystem.defaultShowingUIKey)
    params.enableAutoDownloadMultipleItems = true
    local keyList = {
      config.material_translucent_path,
      config.mesh_path,
      config.material_path,
      config.car_suit_path,
      config.special_car_id
    }
    if config.material_translucent_path2 and config.mesh_path2 and config.material_path2 and config.car_suit_path2 and config.special_car_id2 then
      table.insert(keyList, config.material_translucent_path2)
      table.insert(keyList, config.mesh_path2)
      table.insert(keyList, config.material_path2)
      table.insert(keyList, config.car_suit_path2)
      table.insert(keyList, config.special_car_id2)
    end
    for _, v in ipairs(keyList) do
      table.insert(list, v)
    end
  end
  local PufferSwitch = require("client.slua.logic.download.puffer_switch")
  if not PufferSwitch.CanAutoDownload() and DetailData and DetailData.bIsShowAskTips then
    local PufferConst = require("client.slua.logic.download.puffer_const")
    local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
    local _, size = PufferManager.GetSize(PufferConst.ENUM_DownloadType.ODPAK, list)
    size = size / PufferConst.MB
    log(bWriteLog and "AvatarDownload:UpdateAvatarDownload size is " .. tostring(size))
    if 10 <= size then
      params.askTips = DetailData.sAskTips or LocUtil.GetLocalizeResStr(12060003)
      params.callbackAskConfirm = DetailData.callbackAskConfirm
      params.callbackAskCancel = DetailData.callbackAskCancel
      params.clickCallback = DetailData.clickCallback
    end
  end
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local state = PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, list)
  if state ~= PufferConst.ENUM_DownloadState.Done then
    self.UIRoot.CP_Avatar_Download:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    common_download_handler.CreateDownloadUIReturnUIBase(PufferConst.ENUM_DownloadType.ODPAK, list, self, self.UIRoot.CP_Avatar_Download, params)
    local downloadParent = self.UIRoot.CP_Avatar_Download:GetParent()
    local downloadSlot = slua.isValid(downloadParent) and downloadParent.Slot
    if downloadSlot and downloadSlot.GetZOrder and downloadSlot.SetZOrder then
      downloadSlot:SetZOrder(math.max(downloadSlot:GetZOrder(), 1))
    else
      log_format("AvatarDownload:UpdateAvatarDownload cannot set download parent ZOrder. ItemID=%s", tostring(ItemID))
    end
  else
    self.UIRoot.CP_Avatar_Download:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
end

function AvatarDownload:HideDownloadPanel()
  if not self.UIRoot or not self.UIRoot.CP_Avatar_Download then
    return
  end
  self.UIRoot.CP_Avatar_Download:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
end

function AvatarDownload:SetDownloadPanelVisible(bShow, itemID, detailData)
  self.bForbidDownloadPanel = not bShow
  if not bShow then
    self:HideDownloadPanel()
    return
  end
  local curItemID = itemID or self.ItemID
  if curItemID and 0 < curItemID then
    local itemCfg = CDataTable.GetTableData("Item", curItemID)
    if itemCfg then
      self:UpdateAvatarDownload(itemCfg.ItemID, itemCfg.ItemType, detailData or self.DetailData)
    end
  end
end

return TAvatarDownload
