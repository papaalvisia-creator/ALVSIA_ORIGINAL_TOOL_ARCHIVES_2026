local MainCity_Lobby_Main_Match_Entry_UIBP = require("client.slua.umg.MainCity.Main.Match.Match_Entry_Data")
local SHRINK = 0
local EXPAND = 1
local ENUM_MatchPanelState = {
  Collapsed = 0,
  LTOnly = 1,
  LTExpanded = 2,
  NormalExpand = 3
}

function MainCity_Lobby_Main_Match_Entry_UIBP:UpdateMatchStyle_internal()
  local MatchSystem = require("client.slua.logic.match.logic_match")
  if not MatchSystem.is_sync_match_process then
    log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:UpdateMatchStyle_internal is_sync_match_process is false")
    return
  end
  local isConnecting = MatchSystem.isConnecting
  if not isConnecting then
    log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP.UpdateMatchStyle_internal network is disconnected")
    return
  end
  log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:UpdateMatchStyle_internal")
  local match_progress_update = require("client.slua.umg.MainCity.Main.Match.match_progress_update")
  local root = self.UIRoot
  local WidgetSwitcher_Progress = root.WidgetSwitcher_Progress
  local progressText = root.UTRichTextBlock_2
  local matchText = root.TextBlock_Matching_New
  local estimateTimeText = root.UTRichTextBlock_3
  local estimateTimePanel = root.CanvasPanel_49
  if MatchSystem.ShowProgress then
    if MatchSystem.will_success then
      WidgetSwitcher_Progress:SetActiveWidgetIndex(1)
      local uObj_font = matchText.Font
      uObj_font.Size = match_progress_update.MatchSoonFontSize
      matchText:SetFont(uObj_font)
      matchText:SetText(LocUtil.GetLocalizeResStr(8075917))
      matchText:SetColorAndOpacity(match_progress_update.yellow)
    else
      WidgetSwitcher_Progress:SetActiveWidgetIndex(0)
      local processStr = match_progress_update.GetProgress()
      if processStr then
        progressText:SetText(processStr)
      end
      local nEstimateTime = MatchSystem.nEstimateTime or 0
      if 0 < nEstimateTime then
        estimateTimePanel:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
        local TimeUtil = require("client.common.time_util")
        local estimateTimeStr = TimeUtil.FormatCountDownTime_DH_or_HMS_or_MS(MatchSystem.nEstimateTime)
        estimateTimeText:SetText(estimateTimeStr)
      else
        estimateTimePanel:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
    end
  else
    WidgetSwitcher_Progress:SetActiveWidgetIndex(1)
    local uObj_font = matchText.Font
    uObj_font.Size = match_progress_update.MatchFontSize
    matchText:SetFont(uObj_font)
    matchText:SetText(LocUtil.GetLocalizeResStr(7502))
    matchText:SetColorAndOpacity(match_progress_update.black)
  end
end

function MainCity_Lobby_Main_Match_Entry_UIBP:InitMatchStyle()
  log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:InitMatchStyle")
  local WidgetSwitcher_Matching = self.UIRoot.WidgetSwitcher_Matching
  local MatchSystem = require("client.slua.logic.match.logic_match")
  if MatchSystem.is_sync_match_process then
    WidgetSwitcher_Matching:SetActiveWidgetIndex(1)
  else
    WidgetSwitcher_Matching:SetActiveWidgetIndex(0)
  end
end

function MainCity_Lobby_Main_Match_Entry_UIBP:RefreshTeamReadyNum()
  local TeamUpNewSystem = require("client.slua.logic.teamup.logic_team_up")
  local readyCount, totalCount = TeamUpNewSystem.GetTeamReadyInfo()
  self.UIRoot.WidgetSwitcher_State:SetActiveWidgetIndex(5)
  self.UIRoot.TextBlock_Num:SetText(LocUtil.LocalizeResFormat(805947, readyCount, totalCount))
end

function MainCity_Lobby_Main_Match_Entry_UIBP:CheckMemberMatchRestrict()
  local LogicTxMissionMain = require("client.slua.logic.TxMission.logic_xmission_main")
  if LogicTxMissionMain.IsInXMission(true) then
    log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:CheckMemberMatchRestrict IsXmission return true")
    return false
  end
  local logic_mode_selection = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection)
  log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:CheckMemberMatchRestrict hasSelectTxMission" .. tostring(logic_mode_selection.hasSelectTxMission))
  if logic_mode_selection and logic_mode_selection.hasSelectTxMission then
    log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:CheckMemberMatchRestrict hasSelectTxMission return true")
    return false
  end
  local bMapNotDownloaded = self:GetSelfResDownloadState()
  local bSegmentLimit = false
  local logic_team_match_state = require("client.slua.logic.teamup.logic_team_match_state")
  local TeamUpNewSystem = require("client.slua.logic.teamup.logic_team_up")
  local selfUID = TeamUpNewSystem.GetSelfUID()
  if logic_team_match_state:IsSegmentLimit(selfUID) then
    bSegmentLimit = true
  end
  self.bMemberUGCDownloadRequired = false
  if bMapNotDownloaded or bSegmentLimit then
    local MemberDownloadEntry = require("client.slua.logic.ugc.ugc_member_download_entry")
    local bCanClickUGCDownload = not bSegmentLimit and MemberDownloadEntry.IsUGCSingleWorkResIncomplete()
    self.bMemberUGCDownloadRequired = bCanClickUGCDownload
    self.UIRoot.WidgetSwitcher_State:SetActiveWidgetIndex(1)
    self.UIRoot.TextBlock_Readying:SetText(LocUtil.GetLocalizeResStr(7501))
    self:SetWidgetVisible(self.UIRoot.Button_Entry, true, bCanClickUGCDownload)
    local MatchSystem = require("client.slua.logic.match.logic_match")
    if MatchSystem.nMatchStatus == ENUM_MatchStatus.Ready then
      self:CancelReady()
    end
    log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:CheckMemberMatchRestrict restrict found, mapNotDownloaded=" .. tostring(bMapNotDownloaded) .. " segmentLimit=" .. tostring(bSegmentLimit))
    return true
  end
  return false
end

function MainCity_Lobby_Main_Match_Entry_UIBP:_TryHandleMemberUGCDownloadEntry()
  if not self.bMemberUGCDownloadRequired then
    return false
  end
  local MemberDownloadEntry = require("client.slua.logic.ugc.ugc_member_download_entry")
  local E_ACTION = MemberDownloadEntry.E_ACTION
  local Action, ModInfo, Status = MemberDownloadEntry.DecideMemberClickAction()
  if Action == E_ACTION.NONE then
    self.bMemberUGCDownloadRequired = false
    return false
  end
  if Action == E_ACTION.NOTICE_ONLY then
    ShowNotice(MemberDownloadEntry.LOC_DOWNLOADING)
    log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:_TryHandleMemberUGCDownloadEntry downloading, notice only")
    return true
  end
  if Action == E_ACTION.CHECKING then
    ShowNotice(MemberDownloadEntry.HandleChecking(ModInfo, Status))
    log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:_TryHandleMemberUGCDownloadEntry checking resource")
    return true
  end
  if Action == E_ACTION.SILENT then
    if MemberDownloadEntry.StartSilentDownload(ModInfo, Status) then
      self:_MarkAutoReadyAfterMemberDownload(ModInfo)
      ShowNotice(MemberDownloadEntry.LOC_DOWNLOADING)
      log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:_TryHandleMemberUGCDownloadEntry silent download")
      return true
    end
    local ViewUtil = require("client.slua.logic.ugc.ugc_download_view_util")
    ShowNotice(ViewUtil.LOC.RETRY)
    return true
  end
  self:_MarkAutoReadyAfterMemberDownload(ModInfo)
  MemberDownloadEntry.ShowDownloadPopup(function()
    self:_ClearAutoReadyAfterMemberDownload()
  end)
  log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:_TryHandleMemberUGCDownloadEntry show download notice")
  return true
end

function MainCity_Lobby_Main_Match_Entry_UIBP:_MarkAutoReadyAfterMemberDownload(ModInfo)
  self.bAutoReadyAfterMemberDownload = true
  self.nAutoReadyMemberModID = ModInfo and ModInfo.mod_id or nil
end

function MainCity_Lobby_Main_Match_Entry_UIBP:_ClearAutoReadyAfterMemberDownload()
  self.bAutoReadyAfterMemberDownload = false
  self.nAutoReadyMemberModID = nil
end

function MainCity_Lobby_Main_Match_Entry_UIBP:_AutoReadyAfterMemberDownload(modID)
  if not self.bAutoReadyAfterMemberDownload then
    return false
  end
  if modID and self.nAutoReadyMemberModID and self.nAutoReadyMemberModID ~= modID then
    return false
  end
  local MemberDownloadEntry = require("client.slua.logic.ugc.ugc_member_download_entry")
  local bReady, bAbort = MemberDownloadEntry.CanAutoReady(modID)
  if bAbort then
    self:_ClearAutoReadyAfterMemberDownload()
    return false
  end
  if not bReady then
    return false
  end
  self:_ClearAutoReadyAfterMemberDownload()
  self.bMemberUGCDownloadRequired = false
  self:ReadyMatch()
  log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:_AutoReadyAfterMemberDownload auto ready")
  return true
end

function MainCity_Lobby_Main_Match_Entry_UIBP:OnUGCDownloadResComplete(_, _, modID)
  if self:_AutoReadyAfterMemberDownload(modID) then
    return
  end
  self:UpdateStartButton()
  self:CheckAbnormalStatusShow()
end

function MainCity_Lobby_Main_Match_Entry_UIBP:OnUGCResStatusChanged(_, _, modID)
  if self:_AutoReadyAfterMemberDownload(modID) then
    return
  end
  if not self.bAutoReadyAfterMemberDownload then
    return
  end
  local LogicUGCMatch = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch)
  local ModInfo = LogicUGCMatch and LogicUGCMatch:GetUgcMatchModInfo()
  if not ModInfo or modID and ModInfo.mod_id ~= modID then
    return
  end
  local SelectModDecider = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider)
  local Status = SelectModDecider:GetModDownloadStatus(ModInfo)
  local PufferConst = require("client.slua.logic.download.puffer_const")
  if Status.resState == PufferConst.ENUM_DownloadState.Error or Status.resState == PufferConst.ENUM_DownloadState.Pause then
    self:_ClearAutoReadyAfterMemberDownload()
    log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:OnUGCResStatusChanged download error or pause, drop auto ready")
  end
end

function MainCity_Lobby_Main_Match_Entry_UIBP:UpdateMentorPrematchState(_, _, updateStatus)
  log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:UpdateMentorPrematchState updateStatus = " .. tostring(updateStatus))
  if updateStatus then
  else
    local MatchSystem = require("client.slua.logic.match.logic_match")
    local status = MatchSystem.nMatchStatus
    local MentorSystem = require("client.slua.logic.mentor.logic_mentor")
    printf("MainCity_Lobby_Main_Match_Entry_UIBP:UpdateMentorPrematchState status = %s, mentor_prematch_state = %s, mentor_prematch_state_time = %s", status, MentorSystem.mentor_prematch_state, MentorSystem.mentor_prematch_state_time)
    if (status == ENUM_MatchStatus.Ready or status == ENUM_MatchStatus.Not) and MentorSystem.mentor_prematch_state then
      local root = self.UIRoot
      local TimeUtil = require("client.common.time_util")
      local timeStr = TimeUtil.FormatCountDownTime_DH_or_HMS_or_MS(MentorSystem.mentor_prematch_state_time)
      root.TextBlock_MatchingTime:SetText(timeStr)
    end
  end
end

function MainCity_Lobby_Main_Match_Entry_UIBP:UpdateStartButton()
  local root = self.UIRoot
  root.TextBlock_14:SetText(LocUtil.LocalizeResFormat(68193))
  root.TextBlock_Readying:SetText(LocUtil.GetLocalizeResStr(7503))
  root.Text_State:SetText(LocUtil.GetLocalizeResStr(7501))
  log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:UpdateStartButton")
  self:SetWidgetVisible(self.UIRoot.Button_Entry, true, true)
  local MatchSystem = require("client.slua.logic.match.logic_match")
  local status = MatchSystem.nMatchStatus
  log(bWriteLog and string.format("MainCity_Lobby_Main_Match_Entry_UIBP:UpdateStartButton MatchSystem.nMatchStatus = %s", MatchSystem.nMatchStatus))
  local UGCPlayHallRoom = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom)
  if UGCPlayHallRoom and UGCPlayHallRoom:GetRoomInfo() then
    log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:UpdateStartButton InitUGCPlayHallRoomShow")
    self:InitUGCPlayHallRoomShow()
    return
  else
    if self.ugcPlayHallTimer then
      self:RemoveTimer(self.ugcPlayHallTimer)
      self.ugcPlayHallTimer = nil
    end
    if UGCPlayHallRoom:CheckPendingMatchState() and not self:RefreshUGCMatchPendingShow() then
      return
    end
  end
  if status ~= ENUM_MatchStatus.Matching then
    local match_progress_update = require("client.slua.umg.MainCity.Main.Match.match_progress_update")
    match_progress_update.ClearProgressInfo()
    self.hasInit = false
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_highLeveTips, false, false)
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Anim, false)
    self:SetLTMatchPanelVisible(false)
    self:SetWidgetVisible(self.UIRoot.Border_0, false)
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_Top, false)
  end
  if status == ENUM_MatchStatus.Matching then
    self:InitMatchStyle()
  else
    self.UIRoot.WidgetSwitcher_Matching:SetActiveWidgetIndex(0)
  end
  if UGCPlayHallRoom:IsSystemOpen() then
    local LogicUGCMatch = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch)
    local ModID = tonumber(LogicUGCMatch:GetMatchModID())
    local HotStatCache = UGCPlayHallRoom:GetModHotStatByID(ModID)
    log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:UpdateStartButton InitModHotStatShow", ModID)
    self:InitModHotStatShow(HotStatCache)
  end
  local TeamUpNewSystem = require("client.slua.logic.teamup.logic_team_up")
  if status == ENUM_MatchStatus.Ready then
    local MentorSystem = require("client.slua.logic.mentor.logic_mentor")
    if MentorSystem.mentor_team_waiting then
      self.UIRoot.WidgetSwitcher_State:SetActiveWidgetIndex(0)
      self.UIRoot.Text_State:SetText(LocUtil.LocalizeResFormat(8982, MentorSystem.mentor_team_waiting_time))
    elseif TeamUpNewSystem.IsTeamLeader() then
      if TeamUpNewSystem.GetTeamNum() > 1 and not TeamUpNewSystem.IsEverybodyReady() then
        self:RefreshTeamReadyNum()
      else
        self.UIRoot.WidgetSwitcher_State:SetActiveWidgetIndex(3)
      end
    elseif not self:CheckMemberMatchRestrict() then
      self.UIRoot.WidgetSwitcher_State:SetActiveWidgetIndex(1)
      self.UIRoot.TextBlock_Readying:SetText(LocUtil.GetLocalizeResStr(7503))
    end
  elseif status == ENUM_MatchStatus.Matching then
    self.UIRoot.WidgetSwitcher_State:SetActiveWidgetIndex(2)
  elseif status == ENUM_MatchStatus.Success then
    self.UIRoot.WidgetSwitcher_State:SetActiveWidgetIndex(0)
    self.UIRoot.Text_State:SetText(LocUtil.GetLocalizeResStr(7504))
  elseif TeamUpNewSystem.IsTeamLeader() then
    if TeamUpNewSystem.GetTeamNum() > 1 and not TeamUpNewSystem.IsEverybodyReady() then
      self:RefreshTeamReadyNum()
    elseif self:IsFreeInOutState() then
      self.UIRoot.WidgetSwitcher_State:SetActiveWidgetIndex(6)
      self.UIRoot.TextBlock_JoinGame:SetText(LocUtil.GetLocalizeResStr(78430))
    else
      self.UIRoot.WidgetSwitcher_State:SetActiveWidgetIndex(3)
    end
    log(bWriteLog and "[DeanJYT] UI_Match_Entry:UpdateStatus IsTeamLeader")
    self:SetLTMatchPanelVisible(false)
    self:SetWidgetVisible(self.UIRoot.Border_0, false)
    EventSystem:postEvent(EVENTTYPE_SKILL_SELECTION, EVENTID_SKILL_SELECTION_MODE_OTHER_TIPS_HIDE)
  elseif not self:CheckMemberMatchRestrict() then
    self.UIRoot.WidgetSwitcher_State:SetActiveWidgetIndex(0)
    log(bWriteLog and "[DeanJYT] UI_Match_Entry:UpdateStatus NOT IsTeamLeader")
    self.UIRoot.Text_State:SetText(LocUtil.GetLocalizeResStr(7501))
  end
  if status == ENUM_MatchStatus.Matching then
    self.UIRoot.ScaleBox_EstimateTime:SetWidgetVisibility(UEnums.ESlateVisibility.Hidden)
    local MatchModeMgrSystem = require("client.slua.logic.match.logic_mode_mgr")
    if MatchModeMgrSystem.bIsMatchingSocialIsland then
      self.UIRoot.TextBlock_Matching:SetText(LocUtil.GetLocalizeResStr(10123))
    else
      self.UIRoot.TextBlock_Matching:SetText(LocUtil.GetLocalizeResStr(7502))
      if self.UIRoot.TextBlock_Matching_New then
        self.UIRoot.TextBlock_Matching_New:SetText(LocUtil.GetLocalizeResStr(7502))
      end
    end
    local LogicMatchEntry = require("client.slua.logic.lobby.Mid.logic_match_entry")
    LogicMatchEntry.CalculateMatchDisplay()
    self:ProcessEnterMatch()
    self:OnUpdateMatching()
    local UIUtil = require("client.common.ui_util")
    self.UIRoot.Panel_laodaixin:SetWidgetVisibility(UIUtil.BoolToVisible(LobbySystem.isMentorMatch, true))
  else
    local MentorSystem = require("client.slua.logic.mentor.logic_mentor")
    if (status == ENUM_MatchStatus.Ready or status == ENUM_MatchStatus.Not) and MentorSystem.mentor_prematch_state then
      self.UIRoot.WidgetSwitcher_State:SetActiveWidgetIndex(2)
      self.UIRoot.ScaleBox_EstimateTime:SetWidgetVisibility(UEnums.ESlateVisibility.Hidden)
      local TimeUtil = require("client.common.time_util")
      local timeStr = TimeUtil.FormatCountDownTime_DH_or_HMS_or_MS(MentorSystem.mentor_prematch_state_time)
      self.UIRoot.TextBlock_MatchingTime:SetText(timeStr)
      self.UIRoot.TextBlock_Matching:SetText(LocUtil.LocalizeResFormat(10464))
      self.UIRoot.Panel_laodaixin:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    end
  end
  if self.preMatchState and self.preMatchState == ENUM_MatchStatus.Matching then
    self:ProcessLeaveMatching()
  end
  self.preMatchState = status
  if MatchSystem.bIsSwitchServerShowed or 0 < MatchSystem.nSwitchServerTime then
  end
  self:CheckCrossMatchUIShow()
  self:SetEnterMetroTxMissionDesc()
end

function MainCity_Lobby_Main_Match_Entry_UIBP:ProcessEnterMatch(display)
  local MatchSystem = require("client.slua.logic.match.logic_match")
  if MatchSystem.nMatchStatus ~= ENUM_MatchStatus.Matching then
    return
  end
  local LogicUGCMatch = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch)
  if tonumber(LogicUGCMatch:GetMatchModID()) > 0 then
    return
  end
  local LogicUGCMulti = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMulti)
  if LogicUGCMulti.bIsBundleMatch then
    return
  end
  local LogicMatchEntry = require("client.slua.logic.lobby.Mid.logic_match_entry")
  if display or LogicMatchEntry.HasMatchInfoToDisplay() then
  end
end

function MainCity_Lobby_Main_Match_Entry_UIBP:ProcessLeaveMatching()
  local MatchSystem = require("client.slua.logic.match.logic_match")
  if MatchSystem.nMatchStatus ~= ENUM_MatchStatus.Matching then
    if self.LTMatchAnimTimer then
      local time_ticker = require("common.time_ticker")
      time_ticker.RemoveTimer(self.LTMatchAnimTimer)
      self.LTMatchAnimTimer = nil
    end
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_Top, false)
    self:SetWidgetVisible(self.UIRoot.Border_0, false)
    self:SetLTMatchPanelVisible(false)
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_highLeveTips, false)
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Anim, false)
    self.MathInfoState = SHRINK
    self.bDebugTimersSet = false
    self.bHighLevelTipsShown = false
    self.bLTOnlyArrowHintSet = false
    self.bAnimTips01Played = false
    self.nMatchPanelState = ENUM_MatchPanelState.Collapsed
    self.bTeammatesMatched = false
  end
end

function MainCity_Lobby_Main_Match_Entry_UIBP:ExpandMatchInfo()
  local LogicUGCMatch = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch)
  if tonumber(LogicUGCMatch:GetMatchModID()) > 0 then
    log(bWriteLog and string.format("MainCity_Lobby_Main_Match_Entry_UIBP:Driven return1"))
    return
  end
  if LogicUGCMatch:IsCreativeWoW() then
    log(bWriteLog and string.format("MainCity_Lobby_Main_Match_Entry_UIBP:Driven return2"))
    return
  end
  if not self.MathInfoState or self.MathInfoState == SHRINK then
    self:Driven(EXPAND)
  end
end

function MainCity_Lobby_Main_Match_Entry_UIBP:ShrinkMatchInfo()
  if not self.MathInfoState or self.MathInfoState == EXPAND then
    self:Driven(SHRINK)
  end
end

function MainCity_Lobby_Main_Match_Entry_UIBP:Driven(state)
  self.MathInfoState = state
  if state == EXPAND then
    self.UIRoot.WidgetSwitcher_Top:SetActiveWidgetIndex(1)
    self.UIRoot.Image_13:SetRenderAngle(180)
  else
    self.UIRoot.WidgetSwitcher_Top:SetActiveWidgetIndex(0)
    self.UIRoot.Image_13:SetRenderAngle(0)
  end
  log(bWriteLog and string.format("MainCity_Lobby_Main_Match_Entry_UIBP:Driven state = %s", state))
  local logic_long_time_match = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_long_time_match)
  if logic_long_time_match:GetIsShowLTMatch() then
    if state == EXPAND then
      if not self.UIRoot.GridPanel_LTMatch:IsVisible() then
        self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_Top, true)
        self:SetLTMatchPanelVisible(true)
        self:SetWidgetVisible(self.UIRoot.Border_0, true)
        self:PlayUserWidgetAnimation(self.UIRoot.Animation_MatchingGuide, 0, 1, 1, 1)
        self:SetWidgetVisible(self.UIRoot.CanvasPanel_highLeveTips, false)
        local LogicModeMatchProgress = require("client.slua.logic.mode_selection.LogicModeMatchProgress")
        local canShowHL = LogicModeMatchProgress.CanShowHighLevelMatchTips()
        if not canShowHL then
          self.MathInfoState = EXPAND
          self.UIRoot.Image_16:SetRenderAngle(270)
          self.UIRoot.WidgetSwitcher_Top:SetActiveWidgetIndex(1)
        else
          self.MathInfoState = SHRINK
          self.UIRoot.WidgetSwitcher_Top:SetActiveWidgetIndex(0)
          self.UIRoot.Image_13:SetRenderAngle(0)
        end
      else
        self:SetWidgetVisible(self.UIRoot.Border_0, true)
        local LogicModeMatchProgress = require("client.slua.logic.mode_selection.LogicModeMatchProgress")
        local canShowHL = LogicModeMatchProgress.CanShowHighLevelMatchTips()
        if not canShowHL then
          log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:Driven EXPAND - no sub-panel data, shrink directly")
          self.UIRoot.Image_13:SetRenderAngle(270)
          self:Driven(SHRINK)
          return
        end
        self:SetWidgetVisible(self.UIRoot.CanvasPanel_highLeveTips, canShowHL)
        self:UpdateMatchingTime()
        self.nMatchPanelState = ENUM_MatchPanelState.LTExpanded
        self.bLTOnlyArrowHintSet = true
      end
    elseif self.nMatchPanelState == ENUM_MatchPanelState.LTExpanded then
      self:SetWidgetVisible(self.UIRoot.CanvasPanel_highLeveTips, false)
      self.nMatchPanelState = ENUM_MatchPanelState.LTOnly
      self.bHighLevelTipsShown = false
      self.MathInfoState = EXPAND
      self.UIRoot.WidgetSwitcher_Top:SetActiveWidgetIndex(1)
      self.UIRoot.Image_13:SetRenderAngle(180)
    else
      self:SetLTMatchPanelVisible(false)
      self:SetWidgetVisible(self.UIRoot.Border_0, false)
    end
  else
    if state == EXPAND then
      self.bAnimTips01Played = false
      self.bLTOnlyArrowHintSet = true
      local LogicMatchEntry = require("client.slua.logic.lobby.Mid.logic_match_entry")
      local hasTeammateMatch = LogicMatchEntry.IsShowTeammateMatch()
      local LogicModeMatchProgress = require("client.slua.logic.mode_selection.LogicModeMatchProgress")
      local hasHighLevelTips = LogicModeMatchProgress.CanShowHighLevelMatchTips()
      if hasTeammateMatch or hasHighLevelTips then
        self:SetLTMatchPanelVisible(true)
        self:SetWidgetVisible(self.UIRoot.CanvasPanel_highLeveTips, hasHighLevelTips)
        if (hasHighLevelTips or hasTeammateMatch) and not self.bAnimTips01Played then
          self.bAnimTips01Played = true
          self:SetWidgetVisible(self.UIRoot.CanvasPanel_Anim, true)
          self:PlayUserWidgetAnimation(self.UIRoot.Anim_Tips01, 0, 1, 1, 1)
        end
      else
        self.MathInfoState = SHRINK
        self.UIRoot.WidgetSwitcher_Top:SetActiveWidgetIndex(0)
        self.UIRoot.Image_13:SetRenderAngle(0)
        return
      end
    else
      self:SetWidgetVisible(self.UIRoot.CanvasPanel_highLeveTips, false)
      self:SetWidgetVisible(self.UIRoot.CanvasPanel_Anim, false)
      self:SetLTMatchPanelVisible(false)
    end
    local anim = self.UIRoot.Animation_ShrinkAndExpansion
    self:PlayUserWidgetAnimation(anim, 0, 1, state, 1)
  end
  local LobbyMidMessageUIBP, LobbyExtraTeamUIBP
  local lobbyMain = UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP)
  if lobbyMain then
    LobbyMidMessageUIBP = lobbyMain:GetChildUI(UIManager.UI_Config.Lobby_Mid_Message_UIBP)
    LobbyExtraTeamUIBP = lobbyMain:GetChildUI(UIManager.UI_Config.team_extra_main)
  end
  if self.tipsUI then
    state = SHRINK
  end
  if state == EXPAND then
    if LobbyMidMessageUIBP then
      LobbyMidMessageUIBP:HideVerticalButtonList()
    end
    if LobbyExtraTeamUIBP then
      LobbyExtraTeamUIBP:Collapsed()
    end
    self:SetWidgetVisible(self.UIRoot.HorizontalBox_MatchInfo, true)
  else
    if LobbyMidMessageUIBP then
      LobbyMidMessageUIBP:ShowVerticalButtonList()
    end
    if LobbyExtraTeamUIBP then
      LobbyExtraTeamUIBP:SelfHitTestInvisible()
    end
    self:SetWidgetVisible(self.UIRoot.HorizontalBox_MatchInfo, false)
  end
end

function MainCity_Lobby_Main_Match_Entry_UIBP:OnUpdateMatching()
  log(bWriteLog and "UI_Match_Entry:OnUpdateMatching")
  self:UpdateMatchingTime()
  self:RefreshFindingTeammates()
  self:ReqLTMatch()
end

function MainCity_Lobby_Main_Match_Entry_UIBP:RefreshFindingTeammates()
  if not self.UIRoot or not self.UIRoot.WidgetSwitcher_State then
    return
  end
  local MatchSystem = require("client.slua.logic.match.logic_match")
  if MatchSystem.nMatchStatus ~= ENUM_MatchStatus.Matching then
    return
  end
  local LogicUGCMatch = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch)
  local LogicUGCMulti = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMulti)
  if tonumber(LogicUGCMatch:GetMatchModID()) > 0 or LogicUGCMulti.bIsBundleMatch then
    return
  end
  local widgetSwitcher = self.UIRoot.WidgetSwitcher_State
  local logic_mode_selection = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection)
  local filterInfo = logic_mode_selection:GetFilterInfo()
  local teamNum = filterInfo.teamNum or 4
  local logic_mode_asymmertric = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_asymmertric)
  if logic_mode_asymmertric:GetHasSelectedCamp() and logic_mode_asymmertric:GetCampForMatch() == 1 then
    teamNum = 1
  end
  local LogicMatchEntry = require("client.slua.logic.lobby.Mid.logic_match_entry")
  local bShowTeammateMatch = LogicMatchEntry.IsShowTeammateMatch()
  local matchedNum = math.min(LogicMatchEntry.GetTeammateMatchNum(), teamNum)
  local bFinding = bShowTeammateMatch and teamNum > matchedNum and not self.bTeammatesMatched
  if bShowTeammateMatch and teamNum <= matchedNum then
    self.bTeammatesMatched = true
  end
  local TimeUtil = require("client.common.time_util")
  local timeStr = TimeUtil.FormatCountDownTime_DH_or_HMS_or_MS(MatchSystem.nMatchingTime or 0, true)
  if bFinding then
    widgetSwitcher:SetActiveWidgetIndex(8)
    if self.UIRoot.TextBlock_FindingTeammatesNum then
      self.UIRoot.TextBlock_FindingTeammatesNum:SetText(LocUtil.LocalizeResFormat(35014, matchedNum, teamNum))
    end
    if self.UIRoot.TextBlock_FindingTeammatesTime then
      self.UIRoot.TextBlock_FindingTeammatesTime:SetText(timeStr)
    end
  elseif MatchSystem.waitLine and MatchSystem.waitLine.nPos and 0 < MatchSystem.waitLine.nPos then
    widgetSwitcher:SetActiveWidgetIndex(10)
    if self.UIRoot.TextBlock_InQueue then
      local nPos = MatchSystem.waitLine.nPos
      local posStr = nPos < 100 and "100+" or tostring(nPos)
      self.UIRoot.TextBlock_InQueue:SetText(LocUtil.LocalizeResFormat(6382, posStr))
    end
    if self.UIRoot.TextBlock_InQueueTime then
      self.UIRoot.TextBlock_InQueueTime:SetText(timeStr)
    end
  else
    widgetSwitcher:SetActiveWidgetIndex(2)
  end
end

function MainCity_Lobby_Main_Match_Entry_UIBP:UpdateMatchingTime()
  log(bWriteLog and "UI_Match_Entry:UpdateMatchingTime")
  local MatchSystem = require("client.slua.logic.match.logic_match")
  local matchingTime = MatchSystem.nMatchingTime
  local estimateTime = MatchSystem.nEstimateTime
  if not self.UIRoot then
    return
  end
  self:UpdateMatchStyle_internal()
  local LogicModeMatchProgress = require("client.slua.logic.mode_selection.LogicModeMatchProgress")
  local canShow, tipsLocID = LogicModeMatchProgress.CanShowHighLevelMatchTips()
  self.UIRoot.UTRichTextBlock_highLevelTips:SetText(LocUtil.GetLocalizeResStr(tipsLocID))
  local logic_long_time_match = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_long_time_match)
  if not logic_long_time_match:GetIsShowLTMatch() or self.nMatchPanelState == ENUM_MatchPanelState.LTExpanded then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_highLeveTips, canShow, false)
  end
  if canShow and not self.bHighLevelTipsShown then
    self.bHighLevelTipsShown = true
    log(bWriteLog and string.format("MainCity_Lobby_Main_Match_Entry_UIBP:UpdateMatchingTime highLevel first show, nMatchPanelState=%s, isLTMatch=%s", tostring(self.nMatchPanelState), tostring(logic_long_time_match:GetIsShowLTMatch())))
    if not logic_long_time_match:GetIsShowLTMatch() then
      log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:UpdateMatchingTime highLevel non-LTMatch, expand")
      self:SetLTMatchPanelVisible(true)
      self:SetWidgetVisible(self.UIRoot.CanvasPanel_highLeveTips, true)
      self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_Top, true)
      if not self.bAnimTips01Played then
        self.bAnimTips01Played = true
        self:SetWidgetVisible(self.UIRoot.CanvasPanel_Anim, true)
        self:PlayUserWidgetAnimation(self.UIRoot.Anim_Tips01, 0, 1, 1, 1)
      end
      self:ExpandMatchInfo()
    elseif self.nMatchPanelState ~= ENUM_MatchPanelState.LTExpanded and not self.bLTOnlyArrowHintSet then
      self.bLTOnlyArrowHintSet = true
      log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:UpdateMatchingTime highLevel LTOnly, set arrow hint")
      self.MathInfoState = SHRINK
      self.UIRoot.WidgetSwitcher_Top:SetActiveWidgetIndex(0)
      self.UIRoot.Image_13:SetRenderAngle(0)
    end
  end
  local TimeUtil = require("client.common.time_util")
  local timeStr = TimeUtil.FormatCountDownTime_DH_or_HMS_or_MS(matchingTime, true)
  local root = self.UIRoot
  root.TextBlock_MatchingTime:SetText(timeStr)
  if root.TextBlock_10 then
    root.TextBlock_10:SetText(timeStr)
  end
  local cfg = self:GetEstimateTimeCfg(estimateTime)
  if cfg then
    if matchingTime >= cfg.WaitShowEstimateTime1 then
      root.ScaleBox_EstimateTime:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      local estimateTimeStr
      if matchingTime >= cfg.WaitShowEstimateTime2 and 0 < cfg.WaitTips2 then
        estimateTimeStr = LocUtil.GetLocalizeResStr(cfg.WaitTips2)
      elseif 0 < cfg.WaitTips1 then
        estimateTimeStr = LocUtil.GetLocalizeResStr(cfg.WaitTips1)
      else
        estimateTimeStr = TimeUtil.FormatCountDownTime_DH_or_HMS_or_MS(estimateTime)
        estimateTimeStr = LocUtil.LocalizeResFormat(35013, estimateTimeStr)
      end
      root.UTRichTextBlock_RemainingTime:SetText(estimateTimeStr)
      self:SetWidgetVisible(root.UTRichTextBlock_RemainingTime, true)
    else
      root.UTRichTextBlock_RemainingTime:SetText("")
      self:SetWidgetVisible(root.UTRichTextBlock_RemainingTime, false)
    end
    if 0 < estimateTime then
      local almost_match_time = CDataTable.GetTableData("CancelMatchParams", "almost_match_time").Value
      if almost_match_time >= estimateTime - matchingTime then
        local almost_match_key = CDataTable.GetTableData("CancelMatchParams", "almost_match_key").Value
        local str = LocUtil.GetLocalizeResStr(almost_match_key)
        root.ScaleBox_EstimateTime:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
        root.UTRichTextBlock_RemainingTime:SetText(str)
        self:SetWidgetVisible(root.UTRichTextBlock_RemainingTime, true)
      end
      local match_show_wait_time = CDataTable.GetTableData("CancelMatchParams", "match_show_wait_time").Value
      if match_show_wait_time <= matchingTime - (estimateTime - cfg.WaitShowEstimateTime1) then
        local match_show_wait_key = CDataTable.GetTableData("CancelMatchParams", "match_show_wait_key").Value
        local str = LocUtil.GetLocalizeResStr(match_show_wait_key)
        root.ScaleBox_EstimateTime:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
        root.UTRichTextBlock_RemainingTime:SetText(str)
        self:SetWidgetVisible(root.UTRichTextBlock_RemainingTime, true)
      end
    end
  end
  local TeamUpNewSystem = require("client.slua.logic.teamup.logic_team_up")
  if TeamUpNewSystem.IsTeamLeader() and not MatchSystem.bIsSwitchServerShowed and self:IsNeedCrossSever(matchingTime) then
    local state = MatchSystem.GetCrossMatchState()
    if state == 1 then
      MatchSystem.bIsSwitchServerShowed = true
      UIManager.ShowUI(UIManager.UI_Config.Cross_Server_Popup)
    end
  end
end

function MainCity_Lobby_Main_Match_Entry_UIBP:IsNeedCrossSever(nMatchTime)
  log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:IsNeedCrossSever nMatchTime = " .. tostring(nMatchTime))
  local MatchSystem = require("client.slua.logic.match.logic_match")
  if DataMgr.JPKRMatchServerOn and 0 < nMatchTime and 0 < MatchSystem.nSwitchServerTime and nMatchTime % MatchSystem.nSwitchServerTime == 0 then
    log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:IsNeedCrossSever true")
    return true
  end
  return false
end

function MainCity_Lobby_Main_Match_Entry_UIBP:GetEstimateTimeCfg(estimateTime)
  log(bWriteLog and "UI_Match_Entry:IsNeedCrossSever estimateTime = " .. tostring(estimateTime))
  for i, v in pairs(CDataTable.GetTable("EstimateTimeTable")) do
    if estimateTime <= 0 and v.EstimateTimeMin == -1 then
      return v
    end
    if estimateTime >= v.EstimateTimeMin and estimateTime <= v.EstimateTimeMax then
      return v
    end
  end
  return nil
end

function MainCity_Lobby_Main_Match_Entry_UIBP:OnClickButton_Entry()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:OnClickEntry")
  local logic_familycenter = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_familycenter)
  if logic_familycenter:ShouldBlockGameEntry() then
    log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:OnClickButton_Entry blocked by familycenter compliance flow")
    return
  end
  local TeamUpNewSystem = require("client.slua.logic.teamup.logic_team_up")
  if TeamUpNewSystem.IsTeamLeader() and TeamUpNewSystem.GetTeamNum() > 1 and not TeamUpNewSystem.IsEverybodyReady() then
    ShowNotice(111013)
    return
  end
  local logic_mode_selection = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection)
  local matchMode, viewID, viewIDs = logic_mode_selection:GetCurSelectInfo()
  local viewInfo = logic_mode_selection:GetSubviewInfoBySubviewID(viewID)
  local config_arena = require("client.slua.logic.arena.config_arena")
  if logic_mode_selection.hasSelectTxMission then
    log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:OnClickEntry hasSelectTxMission")
    self:GotoTxMissionLobby()
    return
  end
  local growthprojectMgrB = require("client.slua.logic.growth_project.logic_growth_project_b")
  local MatchSystem = require("client.slua.logic.match.logic_match")
  local status = MatchSystem.nMatchStatus
  log(bWriteLog and "[qintong]:growthprojectMgrB.CanntClickMatch status =" .. tostring(status) .. "  " .. tostring(growthprojectMgrB.CanntClickMatch))
  growthprojectMgrB.StartMatchTimer()
  growthprojectMgrB.OnClickMatchEntry()
  local BasicDataTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.BasicDataTLogReport)
  local Lobby_Main_Control = require("client.slua.logic.lobby.Main.Lobby_Main_Control")
  BasicDataTLogReport:ReportDelay(Lobby_Main_Control.curPage == ENUM_LobbyPageType.Mid and TLogEventDefine.SelectModeStart1 or TLogEventDefine.SelectModeStart2)
  local UGCPlayHallRoom = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom)
  if UGCPlayHallRoom:GetRoomInfo() then
    EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_SHOW_PLAY_HALL_ROOM_UI, "MainCity")
    return
  elseif UGCPlayHallRoom:CheckPendingMatchState() then
    return
  end
  local LogicUGCMatch = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch)
  local ugcMatchInfo = LogicUGCMatch:HasUGCMatchInfo()
  local logic_season_guide_manager = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_guide_manager)
  if ugcMatchInfo then
    logic_season_guide_manager:RecordClassicRank(false)
  else
    logic_season_guide_manager:RecordClassicRank(logic_mode_selection:IsClassicRankMode(matchMode))
  end
  local MainCityUIDefine = require("client.slua.config.tlog.MainCityUITriggertLog")
  MainCityUIDefine.ReportTLogEvent(MainCityUIDefine.UIEnum.start_game, string.format("{matching=[%s]}", status))
  if status == ENUM_MatchStatus.Matching and growthprojectMgrB.CanntClickMatch then
    return
  end
  local UIUtil = require("client.common.ui_util")
  if not UIUtil.CanClickNow(UIUtil.ClickFrequencyLimit.ActivitySwitch) then
    return
  end
  if ugcMatchInfo then
    if self:_TryHandleMemberUGCDownloadEntry() then
      return
    end
    self:OnClickEntryForUGC(status)
    return
  end
  if viewInfo and viewInfo.menu_id == config_arena.ModeMenuId and status ~= ENUM_MatchStatus.Matching then
    local ArenaSystem = require("client.slua.logic.arena.logic_arena")
    if not ArenaSystem.IsInArenaSeason() then
      ShowNotice(108108)
      return
    end
  end
  self:CheckEntry()
end

function MainCity_Lobby_Main_Match_Entry_UIBP:GotoTxMissionLobby()
  log(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:GotoTxMissionLobby")
  local logic_mode_selection_for_umg = require("client.slua.logic.mode_selection.logic_mode_selection_for_umg")
  logic_mode_selection_for_umg.GotoTxMissionLobby()
end

function MainCity_Lobby_Main_Match_Entry_UIBP:OnClickEntryForUGC(status)
  print(bWriteLog and "MainCity_Lobby_Main_Match_Entry_UIBP:OnClickEntryForUGC")
  if status == ENUM_MatchStatus.Not then
    local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
    
    local function FinishCallback()
      self:CheckEntry()
    end
    
    if LogicUGC:ShowAutoTranslateCheckWindow(FinishCallback) == false then
      self:CheckEntry()
    end
  else
    self:CheckEntry()
  end
end

function MainCity_Lobby_Main_Match_Entry_UIBP:CheckEntry()
  log(bWriteLog and "UI_Match_Entry:CheckEntry")
  local MatchSystem = require("client.slua.logic.match.logic_match")
  local status = MatchSystem.nMatchStatus
  if status == ENUM_MatchStatus.Not or status == ENUM_MatchStatus.Ready then
    MatchSystem.RecordDsVersion()
    if PufferDownloader.CheckAllMapPak(self, self.OnCheckAllMapPakResult) then
      self:OnClickEntryInternal()
    end
    return
  end
  self:OnClickEntryInternal()
end

function MainCity_Lobby_Main_Match_Entry_UIBP:OnCheckAllMapPakResult(bOK)
  log(bWriteLog and "UI_Match_Entry:OnCheckAllMapPakResult bOK = " .. tostring(bOK))
  if bOK then
    self:OnClickEntryInternal()
  end
end

function MainCity_Lobby_Main_Match_Entry_UIBP:OnClickEntryInternal()
  log(bWriteLog and "UI_Match_Entry:OnClickEntryInternal")
  local MatchModeMgrSystem = require("client.slua.logic.match.logic_mode_mgr")
  local MatchSystem = require("client.slua.logic.match.logic_match")
  local TeamUpNewSystem = require("client.slua.logic.teamup.logic_team_up")
  if MatchSystem.bShowWeakGuide then
    MatchSystem.bShowWeakGuide = false
    DataMgr.team_up_has_weak_guide = true
  end
  MatchModeMgrSystem.bIsMatchingTrainMode = false
  MatchModeMgrSystem.bIsMatchingSocialIsland = false
  local status = MatchSystem.nMatchStatus
  log(bWriteLog and "[  status" .. tostring(status))
  if status == ENUM_MatchStatus.Not then
    local MentorSystem = require("client.slua.logic.mentor.logic_mentor")
    if MentorSystem.mentor_prematch_state then
      MentorSystem.send_mentor_prematch_cancel_req()
      return
    end
    if MentorSystem.IsMentorOpen() and MentorSystem.identity == 2 and MentorSystem.waiting_status == 1 then
      local common_save_game = require("client.logic.LogicPlayerPrefs.common_save_game")
      if not common_save_game.GetSaveData(common_save_game.Configs.Mentor_StartGame_Tips) then
        local title = LocUtil.LocalizeResFormat("101001")
        local tip = LocUtil.LocalizeResFormat("9206")
        local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
        CommonMsgBoxMgr.Show(2, title, tip, function()
          self:OnClickEntryInternal()
        end)
        common_save_game.SaveData(common_save_game.Configs.Mentor_StartGame_Tips)
        return
      end
    end
    if TeamUpNewSystem.IsTeamLeader() then
      self:StartMatch()
    else
      self:ReadyMatch()
    end
  elseif status == ENUM_MatchStatus.Ready then
    local MentorSystem = require("client.slua.logic.mentor.logic_mentor")
    if MentorSystem.mentor_prematch_state then
      MentorSystem.send_mentor_prematch_cancel_req()
      return
    end
    if TeamUpNewSystem.IsTeamLeader() then
      self:StartMatch()
    else
      self:CancelReady()
      self:PlayAudio(sound_config.new_cancelStartGameBtn)
      return
    end
  elseif status == ENUM_MatchStatus.Matching then
    self:PlayAudio(sound_config.new_cancelStartGameBtn)
    local logic_long_time_match = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_long_time_match)
    if logic_long_time_match:IsShowLTMatchCancelTips() then
      self:ShowLTMatchCancelTips()
      return
    end
    local logic_multi_select_match = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_multi_select_match)
    if logic_multi_select_match:CheckGuideWhenCancelMatch() then
      logic_multi_select_match:ShowGuideWhenCancelMatch()
      return
    end
    self:CancelMatch()
    return
  elseif status == ENUM_MatchStatus.Success then
    if TeamUpNewSystem.IsTeamLeader() then
      self:StartMatch()
    else
      self:ReadyMatch()
    end
  end
  self:PlayAudio(sound_config.new_startGameBtn)
end

function MainCity_Lobby_Main_Match_Entry_UIBP:StartMatch(isForce)
  local logic_return_perfect_game = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_perfect_game)
  if logic_return_perfect_game:TryInterceptAIDescConsent(nil, function()
    self:StartMatch(isForce)
  end) then
    return
  end
  local MatchModeMgrSystem = require("client.slua.logic.match.logic_mode_mgr")
  log(bWriteLog and "[edward][match_entry] UI_Match_Entry:StartMatch")
  local TournamentsManager = require("client.slua.logic.tournament.TournamentsManager")
  if TournamentsManager.LobbyMatchCheck() then
    log(bWriteLog and "[edward][match_entry] UI_Match_Entry:StartMatch, Return by TournamentsManager")
    return
  end
  gem_report_utils.ReportBtnClickEvent(gem_report_utils.SubEventName_MatchStartGame)
  local tlog_report_utils = require("client.slua.config.tlog.tlog_report_utils")
  local logic_mode_selection = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection)
  local modeId, viewId, viewIds = logic_mode_selection:GetCurSelectInfo()
  local strViewInfo = tostring(modeId or 0) .. ";" .. tostring(viewId or 0) .. ";"
  if viewIds and next(viewIds) then
    for _, v in pairs(viewIds) do
      if v ~= nil then
        strViewInfo = strViewInfo .. tostring(v) .. ","
      end
    end
  end
  tlog_report_utils.ReportTLogEvent(TLogEventDefine.MatchStartGame, 0, strViewInfo)
  local logic_return_tlog_report = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_tlog_report)
  logic_return_tlog_report:ReportReturnTLogEvent(TLogEventDefine.MatchStartGame, 0, strViewInfo)
  local LogicTeamUpSideBar = require("client.slua.logic.lobby.logic_teamup_side_bar")
  LogicTeamUpSideBar.CloseTeamUpSideBar()
  self:RemoveAllTimer()
  local TeamUpNewSystem = require("client.slua.logic.teamup.logic_team_up")
  
  local function StartMatchCallback()
    local newbieGuideManager = require("client.logic.newbie_manager.newbie_guide_manager")
    if newbieGuideManager.NeedPopModTip() then
      local teamNum = TeamUpNewSystem.GetTeamNum()
      if 1 < teamNum then
        log(bWriteLog and "[boteliu][match_entry] UI_Match_Entry:StartMatchCallback, teamNum > 1")
        newbieGuideManager.SetModTip()
      else
        log(bWriteLog and "[boteliu][match_entry] UI_Match_Entry:StartMatchCallback, show mod tip")
        newbieGuideManager.ShowModTip(StartMatchCallback)
        return
      end
    end
    local MatchSystem = require("client.slua.logic.match.logic_match")
    log(bWriteLog and "[edward][match_entry] StartMatchCallback, \229\188\128\229\167\139\229\140\185\233\133\141")
    MatchSystem.bShowMatchTimeoutNotice = false
    MatchSystem.SetSameLanguageMatchTimeOut(false)
    BattleResult.IgnoreDSError = false
    local LogicUGCMatch = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch)
    local LogicUGCMulti = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMulti)
    if LogicUGCMatch:HasUGCMatchInfo() then
      local editMatchInfo = LogicUGCMatch:GetEditMatchInfo()
      if editMatchInfo then
        local bInTeam = TeamUpNewSystem.IsInTeam()
        local LogicUGCCRUD = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD)
        if bInTeam then
          LogicUGCCRUD:EnterTeamCreate(editMatchInfo.slot, editMatchInfo.base.template_id)
        else
          LogicUGCCRUD:ReqStartEditGame(editMatchInfo.slot, true)
        end
      else
        LogicUGCMatch:ReqStartGame("MainCity")
      end
    elseif LogicUGCMulti.bIsBundleMatch then
      LogicUGCMulti:StartMatch()
    else
      LobbySystem.on_start_match_req()
    end
    local corp_fight = require("client.slua.logic.corps.logic_corps_fight")
    if corp_fight.CheckShowFightBeginTip(MatchModeMgrSystem.nSelectMatchID) then
      corp_fight.ShowTipUI(LocUtil.GetLocalizeResStr(23763))
    end
  end
  
  if TeamUpNewSystem.IsInOneMoreGameTeam() then
    local title = LocUtil.GetLocalizeResStr(101001)
    local msg = LocUtil.GetLocalizeResStr(8028)
    local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
    CommonMsgBoxMgr.Show(2, title, msg, StartMatchCallback)
    return
  end
  local ZoneSystem = require("client.slua.logic.teamup.logic_zone")
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  local bIsBLUEHOLE = PublishRegionMacros.IsBlueholeOperationRegion()
  log(bWriteLog and "UI_Match_Entry:StartMatch bIsBLUEHOLE = " .. tostring(bIsBLUEHOLE))
  if not ZoneSystem.nChooseZoneID or ZoneSystem.nChooseZoneID == 0 then
    if GlobalData.IsJapanOrKorea() then
      ZoneSystem.on_select_zone_req(6)
      StartMatchCallback()
    elseif bIsBLUEHOLE then
      ZoneSystem.on_select_zone_req(3)
      StartMatchCallback()
    else
      local function ShowZoneOption()
        UIManager.ShowUI(UIManager.UI_Config.Setting_ChangeServer, function()
        end)
      end
      
      local title = LocUtil.GetLocalizeResStr(101001)
      local msg = LocUtil.GetLocalizeResStr(7568)
      local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
      CommonMsgBoxMgr.Show(2, title, msg, ShowZoneOption)
    end
    return
  end
  local logic_zone_delay = require("client.slua.logic.match.logic_zone_delay")
  local isChoosingZoneAccess = logic_zone_delay.IsChoosingZoneAccess()
  local isMatchVersion = Client.IsMatchVersion()
  if isChoosingZoneAccess or isForce or bIsBLUEHOLE or isMatchVersion then
    StartMatchCallback()
  else
    logic_zone_delay.ShowDelayTips(StartMatchCallback)
  end
end

function MainCity_Lobby_Main_Match_Entry_UIBP:IsFreeInOutState()
  local LogicUGCMatch = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch)
  return LogicUGCMatch:IsFreeInOutMatch()
end

function MainCity_Lobby_Main_Match_Entry_UIBP:CancelMatch()
  log(bWriteLog and "[edward][match_entry] UI_Match_Entry:CancelMatch")
  LobbySystem.on_match_cancel_req()
end

function MainCity_Lobby_Main_Match_Entry_UIBP:ReadyMatch()
  log(bWriteLog and "[edward][match_entry] UI_Match_Entry:ReadyMatch")
  local reqStatus = ENUM_MatchStatus.Ready
  log(bWriteLog and "request switch my status to : " .. reqStatus)
  local TeamupHandler = require("client.network.Protocol.TeamupHandler")
  local DeviceOSInfo = require("client.logic.data.data_device_os")
  DeviceOSInfo.getDeviceOSInfo()
  TeamupHandler.send_team_change_member_status_request(reqStatus, DeviceOSInfo.InfoList)
end

function MainCity_Lobby_Main_Match_Entry_UIBP:CancelReady()
  log(bWriteLog and "[edward][match_entry] UI_Match_Entry:CancelReady")
  local reqStatus = ENUM_MatchStatus.Not
  log(bWriteLog and "request switch my status to : " .. reqStatus)
  local TeamupHandler = require("client.network.Protocol.TeamupHandler")
  local DeviceOSInfo = require("client.logic.data.data_device_os")
  DeviceOSInfo.getDeviceOSInfo()
  TeamupHandler.send_team_change_member_status_request(reqStatus, DeviceOSInfo.InfoList)
end
