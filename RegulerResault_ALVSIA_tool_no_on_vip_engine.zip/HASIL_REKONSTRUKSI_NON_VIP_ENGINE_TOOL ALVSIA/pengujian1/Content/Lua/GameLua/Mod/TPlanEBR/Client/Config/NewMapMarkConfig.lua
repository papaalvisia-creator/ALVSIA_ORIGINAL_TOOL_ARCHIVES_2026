local NewMapMarkConfig = {
  [1037] = {
    UIPath = "/Game/Mod/TPlanEBR/BluePrints/UI/ActorMark/MapMark_FleePoint_UIBP.MapMark_FleePoint_UIBP_C",
    bIsIcon = false,
    ZOrder = -6,
    bOBShow = true,
    NavigatorMarkPath = "/Game/Mod/TPlanEBR/BluePrints/UI/ActorMark/NavigatorFleeMark_UIBP.NavigatorFleeMark_UIBP",
    NavigatorMarkIsIcon = false
  },
  [1040] = {
    UIPath = "/Game/Mod/TPlanEBR/Arts/UI/Atlas/Frames/TPlanEBR_Image_Container_png.TPlanEBR_Image_Container_png",
    bIsIcon = true,
    Size = FVector2D(15, 15),
    bIsControlByLegend = true,
    bIsUpdateSize = false,
    bOBShow = true,
    LegendTags = "",
    LegendIconPath = "/Game/Mod/TPlanBase/Textures/Atlas/Frames/TPlanEBR_Image_Container_png.TPlanEBR_Image_Container_png",
    LegendTextID = 74103,
    ZOrder = 1
  },
  [1041] = {
    UIPath = "/Game/Mod/TPlanEBR/Arts/UI/Atlas/Frames/TPlanEBR_Dropbox_03_png.TPlanEBR_Dropbox_03_png",
    bIsIcon = true,
    Size = FVector2D(30, 30),
    bIsUpdateSize = false,
    bOBShow = true
  },
  [1042] = {
    UIPath = "/Game/Mod/TPlanEBR/Arts/UI/Atlas/Frames/TPlanEBR_Dropbox_02_png.TPlanEBR_Dropbox_02_png",
    bIsIcon = true,
    Size = FVector2D(30, 30),
    bIsUpdateSize = false,
    bOBShow = true
  },
  [1043] = {
    UIPath = "/Game/Mod/TPlanEBR/Arts/UI/Atlas/Frames/TPlanEBR_Dropbox_01_png.TPlanEBR_Dropbox_01_png",
    bIsIcon = true,
    Size = FVector2D(40, 40),
    bIsUpdateSize = false,
    bOBShow = true
  }
}
return NewMapMarkConfig
