local WolfBag = {}
local SingleBackpackComp = import("/Script/ShadowTrackerExtra.SingleBackpackComp")
local EGroupBackpackScheme = import("EGroupBackpackScheme")
local UIUtil = require("client.common.ui_util")
local WolfConfig = require("GameLua.ExtraModule.MLAI.Gameplay.Wolf.Config.WolfConfig")
local CommonItem_Utils = require("client.slua.component.item.ItemUtils.CommonItem_Utils")
local IngameTipsTools = require("GameLua.Mod.BaseMod.Common.UI.InGameTipsTools")
local GameplayData = require("GameLua.GameCore.Data.GameplayData")
local nTipsID = WolfConfig.Backpack.ItemOverTips
local ESlateVisibility = UEnums.ESlateVisibility
local EBackPackDragOrigin = UEnums.EBackPackDragOrigin
local TEAMMATE_INDEX_ICON_FORMAT = "/Game/Arts/UI/Atlas/BattleUI/NewAtlas/Frames/ZD_Icon_Tips_Teammate_0%d_png.ZD_Icon_Tips_Teammate_0%d_png"
local SWITCHER_INDEX_EXPANDED = 1
local SWITCHER_INDEX_COLLAPSED = 0

function WolfBag:OnInitialize()
  WolfBag.__super.OnInitialize(self)
  self.tItemDatas = {}
  self.ID2Cap = {}
  self.ItemList = self:InitChildClassScrollBox(self.UIRoot.LoopScrollGrid_0, "GameLua.ExtraModule.MLAI.Client.UI.Wolf.WolfBagItem")
  self:SetExpanded(true)
end

function WolfBag:RegistEvents()
  WolfBag.__super.RegistEvents(self)
  self:AddUIMessageEvent("UIMsg_GroupBackpackCompUpdate", self.UpdateWolfBag, self)
  self:AddUIMessageEvent("UIMsg_ExitGroupBackpackCompMsg", self.HideWolfBag, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_VEHICLE_BACKPACK, EVENTID_VEHICLE_SINGLE_BACKPACK_ITEM_ADD, self.OnWolfBagItemAdd, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_VEHICLE_BACKPACK, EVENTID_VEHICLE_SINGLE_BACKPACK_ITEM_UPDATE, self.OnWolfBagItemUpdate, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_VEHICLE_BACKPACK, EVENTID_VEHICLE_SINGLE_BACKPACK_ITEM_REMOVE, self.OnWolfBagItemRemove, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_BACKPACK, EVENTID_BACKPACK_ON_ITEM_DELETE_PANEL_CONFIRM, self.HandleClickDeleteConfirm, self)
  self:AddControlEventByControl(self.UIRoot.Button_0, "OnClicked", self.OnClickedButton, self)
end

local function GetSingleBackpackComp()
  local uPlayerController = GameplayData.GetPlayerController()
  if not slua.isValid(uPlayerController) then
    return nil
  end
  return uPlayerController:GetComponentByClass(SingleBackpackComp)
end

local function IsWolfBagActive()
  local uSBP = GetSingleBackpackComp()
  return slua.isValid(uSBP) and uSBP.scheme == EGroupBackpackScheme.AIMirrorScheme and uSBP.capacity > 0
end

function WolfBag:OnPostInitialize()
  if self.UIRoot.TextBlock_0 then
    self.UIRoot.TextBlock_0:SetText(LocUtil.GetLocalizeResStr(4701425))
  end
  if self.UIRoot.CanvasPanel_1 and self.UIRoot.CanvasPanel_1.Slot then
    self.UIRoot.CanvasPanel_1.Slot:SetPosition(FVector2D(-70, -25))
  end
  UIManager.HideUI(UIManager.UI_Config_InGame.VehicleBackpack)
  self:UpdateWolfBag()
end

function WolfBag:IsExpanded()
  local uContent = self.UIRoot and self.UIRoot.VerticalBox_1
  if uContent then
    return uContent:GetVisibility() ~= ESlateVisibility.Collapsed
  end
  return true
end

function WolfBag:SetExpanded(bExpanded)
  local nVisibility = bExpanded and ESlateVisibility.SelfHitTestInvisible or ESlateVisibility.Collapsed
  local uContent = self.UIRoot and self.UIRoot.VerticalBox_1
  if uContent then
    uContent:SetVisibility(nVisibility)
  end
  local uSizeBox = self.UIRoot and self.UIRoot.SizeBox_2
  if uSizeBox then
    uSizeBox:SetVisibility(nVisibility)
  end
  local uSwitcher = self.UIRoot and self.UIRoot.WidgetSwitcher_0
  if uSwitcher then
    uSwitcher:SetActiveWidgetIndex(bExpanded and SWITCHER_INDEX_EXPANDED or SWITCHER_INDEX_COLLAPSED)
  end
end

function WolfBag:OnClickedButton()
  local bIsExpanded = self:IsExpanded()
  self:SetExpanded(not bIsExpanded)
  print(bWriteLog and string.format("WolfBag:OnClickedButton0 expanded=%s", tostring(bIsExpanded)))
end

function WolfBag:UpdateWolfBag()
  local uSBP = GetSingleBackpackComp()
  if not slua.isValid(uSBP) or uSBP.scheme ~= EGroupBackpackScheme.AIMirrorScheme or uSBP.capacity <= 0 then
    self.UIRoot:SetWidgetVisibility(ESlateVisibility.Collapsed)
    return
  end
  self.UIRoot:SetWidgetVisibility(ESlateVisibility.SelfHitTestInvisible)
  self.capacity = uSBP.capacity
  self.tItemDatas = {}
  local tDataList = uSBP.itemList and uSBP.itemList.ItemDataList
  if tDataList then
    for _, ArrayElement in pairs(tDataList) do
      local ItemData = ArrayElement.ItemData
      if ItemData and 0 < ItemData.Count and ItemData.ID then
        local ItemID = ItemData.ID.TypeSpecificID
        if ItemID and CDataTable.GetTableData("Item", ItemID) then
          if ItemData.clone then
            ItemData = ItemData:clone()
          end
          table.insert(self.tItemDatas, {data = ItemData})
        end
      end
    end
  end
  if self.ItemList then
    self.ItemList:SetDataWithoutSelect(self.tItemDatas)
  end
  self:RefreshCapacityText()
  self:UpdateTeammateIndex(uSBP)
end

function WolfBag:GetItemDatas()
  if self.ItemList then
    return self.ItemList:GetSetData() or self.tItemDatas
  end
  return self.tItemDatas
end

function WolfBag:FindItemIndex(ItemData)
  if not ItemData or not ItemData.ID then
    return 0
  end
  for nIndex, tItem in ipairs(self:GetItemDatas()) do
    local data = tItem.data
    if data and data.ID and data.ID.TypeSpecificID == ItemData.ID.TypeSpecificID and data.InstanceID == ItemData.InstanceID then
      return nIndex
    end
  end
  return 0
end

function WolfBag:RefreshCapacityText()
  if not self.capacity or self.capacity <= 0 then
    local uSBP = GetSingleBackpackComp()
    if not slua.isValid(uSBP) then
      return
    end
    self.capacity = uSBP.capacity
  end
  if not self.capacity or self.capacity <= 0 then
    return
  end
  local curCapacity = 0
  for _, tItem in ipairs(self:GetItemDatas()) do
    if tItem.data and tItem.data.ID then
      curCapacity = curCapacity + self:GetItemCapacity(tItem.data.ID, tItem.data.Count)
    end
  end
  local uCapText = self.UIRoot.TextBlock_1
  if uCapText then
    uCapText:SetText(FuncUtil.GetFormatText(" ({0}/{1}) ", math.floor(curCapacity + 0.5), math.ceil(self.capacity)))
  end
end

function WolfBag:UpdateTeammateIndex(uSBP)
  local uImage = self.UIRoot.Image_1
  if not uImage then
    return
  end
  local nMasterPlayerKey = uSBP.MasterPlayerKey or 0
  nMasterPlayerKey = nMasterPlayerKey & 4294967295
  if nMasterPlayerKey == 0 then
    return
  end
  local uPlayerState = GameplayData.GetPlayerState()
  if not slua.isValid(uPlayerState) then
    return
  end
  local tTeammates = uPlayerState:GetTeamMatePlayerStateList({}, false)
  local nBelongIndex = 0
  local nCount = 0
  if tTeammates then
    for _, uTeammatePS in pairs(tTeammates) do
      if slua.isValid(uTeammatePS) then
        nCount = nCount + 1
        if uTeammatePS.PlayerKey == nMasterPlayerKey then
          nBelongIndex = nCount
          break
        end
      end
    end
  end
  if 1 <= nBelongIndex and nBelongIndex <= 4 then
    self:SetTexture(uImage, string.format(TEAMMATE_INDEX_ICON_FORMAT, nBelongIndex, nBelongIndex))
    uImage:SetWidgetVisibility(ESlateVisibility.SelfHitTestInvisible)
  end
end

function WolfBag:GetItemCapacity(defineID, count)
  local TypeSpecificID = defineID.TypeSpecificID
  if self.ID2Cap[TypeSpecificID] ~= nil then
    return count * self.ID2Cap[TypeSpecificID]
  else
    local ItemTable = CDataTable.GetTableData("Item", TypeSpecificID)
    if ItemTable then
      local nUnitWeight = ItemTable.UnitWeight_f or 0
      self.ID2Cap[TypeSpecificID] = nUnitWeight
      return count * nUnitWeight
    end
  end
  return 0
end

function WolfBag:HideWolfBag()
  self:Collapsed()
end

function WolfBag:OnWolfBagItemAdd(_, __, ItemData)
  print(bWriteLog and "WolfBag:OnWolfBagItemAdd TypeSpecificID:" .. tostring(ItemData.ID.TypeSpecificID) .. " InstanceID:" .. tostring(ItemData.InstanceID) .. " Count:" .. tostring(ItemData.Count))
  if not IsWolfBagActive() or not self.ItemList then
    return
  end
  if ItemData.clone then
    ItemData = ItemData:clone()
  end
  local nIndex = self:FindItemIndex(ItemData)
  if 0 < nIndex then
    self.ItemList:RefreshItem(nIndex, {data = ItemData})
  else
    self.ItemList:InsertItem(#self:GetItemDatas() + 1, {data = ItemData})
  end
  self:RefreshCapacityText()
end

function WolfBag:OnWolfBagItemUpdate(_, __, ItemData)
  print(bWriteLog and "WolfBag:OnWolfBagItemUpdate TypeSpecificID:" .. tostring(ItemData.ID.TypeSpecificID) .. " InstanceID:" .. tostring(ItemData.InstanceID) .. " Count:" .. tostring(ItemData.Count))
  if not IsWolfBagActive() or not self.ItemList then
    return
  end
  if ItemData.clone then
    ItemData = ItemData:clone()
  end
  local nIndex = self:FindItemIndex(ItemData)
  if 0 < nIndex then
    self.ItemList:RefreshItem(nIndex, {data = ItemData})
  else
    self.ItemList:InsertItem(#self:GetItemDatas() + 1, {data = ItemData})
  end
  self:RefreshCapacityText()
end

function WolfBag:OnWolfBagItemRemove(_, __, ItemData)
  print(bWriteLog and "WolfBag:OnWolfBagItemRemove TypeSpecificID:" .. tostring(ItemData.ID.TypeSpecificID) .. " InstanceID:" .. tostring(ItemData.InstanceID) .. " Count:" .. tostring(ItemData.Count))
  if not IsWolfBagActive() or not self.ItemList then
    return
  end
  local nIndex = self:FindItemIndex(ItemData)
  if 0 < nIndex then
    self.ItemList:RemoveItem(nIndex)
    self:RefreshCapacityText()
  end
end

function WolfBag:OnItemDragDrop(ItemData, DragItemOrigin, Location)
  if not self.UIRoot or self.UIRoot:GetVisibility() ~= ESlateVisibility.SelfHitTestInvisible then
    return false
  end
  local DetectWidget = self.UIRoot.CanvasPanel_1
  if not DetectWidget then
    return false
  end
  if UIUtil.IsLocalpositionInBorder(Location, DetectWidget) then
    if DragItemOrigin == EBackPackDragOrigin.FromWolf then
      return true
    end
    self:AddWolfItem(ItemData)
    return true
  end
  return false
end

function WolfBag:PickToBackpack(Item, DragItemOrigin)
  if DragItemOrigin == EBackPackDragOrigin.FromWolf then
    local uSBP = GetSingleBackpackComp()
    if slua.isValid(uSBP) then
      uSBP:RemoveGroupItem(Item.DefineID)
      return true
    end
  end
  return false
end

function WolfBag:AddWolfItem(ItemBeDragged)
  local uPlayerController = GameplayData.GetPlayerController()
  if not (slua.isValid(uPlayerController) and ItemBeDragged) or not ItemBeDragged.DefineID then
    return
  end
  if ItemBeDragged.Count == 1 then
    self:HandleClickDeleteConfirm(nil, nil, ItemBeDragged, UEnums.DropItem.ToMercenaryAI, ItemBeDragged.Count)
  elseif UIManager.UI_Config_InGame.BackpackDeleteControl then
    UIManager.ShowUI(UIManager.UI_Config_InGame.BackpackDeleteControl, ItemBeDragged, UEnums.DropItem.ToMercenaryAI, 20304, 20306)
  end
end

function WolfBag:HandleClickDeleteConfirm(EventType, EventID, Stuff, DropTarget, ThrowCount)
  if not (DropTarget and DropTarget == UEnums.DropItem.ToMercenaryAI and ThrowCount) or ThrowCount <= 0 then
    return
  end
  local uSBP = GetSingleBackpackComp()
  if not slua.isValid(uSBP) then
    return
  end
  local ItemAttr = CDataTable.GetTableData("ItemAttrs", Stuff.DefineID.TypeSpecificID)
  if ItemAttr and ItemAttr.CannotManualDrop then
    print(bWriteLog and "WolfBag:HandleClickDeleteConfirm - CannotManualDrop " .. tostring(Stuff.DefineID.TypeSpecificID))
    IngameTipsTools.BattleGeneralTip(nTipsID)
    return
  end
  local ItemID = Stuff.DefineID
  if ItemID and ItemID.Type == 1 then
    local nTipsID = WolfConfig.Backpack and WolfConfig.Backpack.BlockedPickupTips
    if nTipsID and 0 < nTipsID then
      IngameTipsTools.BattleGeneralTip(nTipsID)
    end
    return
  end
  uSBP:AddGroupItem(Stuff.DefineID, ThrowCount, Stuff.AdditionalData)
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
return class(ui_base, nil, WolfBag)
