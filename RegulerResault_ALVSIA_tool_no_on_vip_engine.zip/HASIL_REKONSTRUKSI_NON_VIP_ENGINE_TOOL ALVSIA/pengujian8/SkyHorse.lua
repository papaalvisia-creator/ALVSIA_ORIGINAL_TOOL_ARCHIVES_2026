;({
  ServerRPC = {},
  ClientRPC = {},
  MulticastRPC = {},
  ["GetVehicleControlUIConfig"] = function(_ARG_0_)
    do
      do return {
        CommonUIGroup = {
          (U1(58, 41, 187, 29, 94, 177, 13, 179, 236, 251, 187, 60, 63, 102, 47, 45, 208))
        },
        DriverUIGroup = {
          (U1(43, 43, 173, 3, 84, 171, 23, 181, 195, 241, 150, 39, 35, 125, 49, 23, 245, 39, 251, 36, 180, 135, 97, 171, 208, 242, 160))
        },
        VehicleMode = 3,
        VModeKey = import((U1(44, 17, 150, 16, 73, 183, 12, 183, 249, 241, 189, 33, 46, 101, 38, 44, 224, 2, 215))).VT_CustomVehicle4
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUIConfig"] = function(_ARG_0_)
    do
      do return {
        SkyHorseControlUI = {
          moduleName = table.concat({
            U1(46, 35, 175, 48, 125, 182, 31, 248, 226, 251, 177, 102, 1, 96, 33, 10, 248, 0, 203, 75, 134, 146, 99, 131, 239, 232, 164, 33, 115, 79, 54, 0, 224, 1, 206, 16, 255, 176, 117, 143),
            U1(33, 45, 176, 38, 84, 237, 45, 189, 214, 220, 186, 58, 62, 108, 0, 23, 247, 6, 192, 10, 173, 166, 71)
          }),
          path = table.concat({
            U1(70, 5, 163, 56, 84, 236, 50, 191, 205, 230, 180, 58, 52, 38, 17, 29, 234, 93, 228, 0, 169, 154, 109, 138, 218, 247, 234, 11, 54, 96, 27, 7, 251, 17, 199, 90, 132, 170, 49, 165),
            U1(2, 59, 138, 58, 67, 176, 27, 149, 192, 250, 161, 58, 34, 101, 22, 49, 183, 33, 217, 28, 137, 156, 124, 149, 218, 199, 170, 54, 41, 107, 60, 4, 220, 43)
          }),
          isMainUI = false,
          isSingleton = true,
          zOrder = 0,
          asy = true,
          closeOnHide = false,
          uiStat = {
            name = U1(33, 45, 176, 38, 84, 128, 17, 184, 219, 230, 186, 36, 24, 64)
          },
          AndroidBackType = require((table.concat({
            U1(10, 46, 171, 48, 95, 183, 80, 165, 195, 225, 180, 102, 46, 102, 45, 30, 240, 21, 156, 38, 173, 154, 107, 136, 203, 201, 164, 59, 47, 118, 32, 70, 204, 35, 204, 17, 163, 140, 119, 146),
            U1(43, 35, 161, 62, 101, 186, 14, 179)
          }))).Ban
        }
      } end
      do return end
      _ARG_0_ = _ENV[176]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PostConstruct"] = function(_ARG_0_)
    do
      __super._PostConstruct(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ctor"] = function(_ARG_0_)
    do
      _ARG_0_.fFlyEnergy = MaxFlyEnergy
      _ARG_0_.bFlyEnergyExhaustedLock = false
      _ARG_0_.nExhaustedRecoverDelayTimer = nil
      _ARG_0_.uRepCreator = nil
      _ARG_0_.bMarkRecycling = false
      _ARG_0_.bInPOIArea = false
      _ARG_0_.uPOIRider = nil
      _ARG_0_.fClientSpawnAnimTime = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLifetimeReplicatedProps"] = function(_ARG_0_)
    do
      do return {
        {
          U1(15, 4, 174, 44, 116, 173, 27, 164, 200, 237),
          import((U1(44, 14, 171, 51, 84, 183, 23, 187, 202, 215, 186, 38, 41, 96, 55, 17, 246, 28))).COND_None,
          UEnums.EPropertyClass.Float
        },
        {
          U1(28, 16, 167, 37, 114, 177, 27, 183, 219, 251, 167),
          import((U1(44, 14, 171, 51, 84, 183, 23, 187, 202, 215, 186, 38, 41, 96, 55, 17, 246, 28))).COND_None,
          UEnums.EPropertyClass.Object
        },
        {
          U1(11, 15, 163, 39, 90, 145, 27, 181, 214, 247, 185, 33, 35, 110),
          import((U1(44, 14, 171, 51, 84, 183, 23, 187, 202, 215, 186, 38, 41, 96, 55, 17, 246, 28))).COND_None,
          UEnums.EPropertyClass.Bool
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveBeginPlay"] = function(_ARG_0_)
    do
      __super.ReceiveBeginPlay(_ARG_0_)
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 144, 107, 143, 201, 225, 135, 61, 58, 112, 61, 56, 229, 3, 219, 85, 244, 144, 62, 191),
        U2(26, 1, 174, 60, 84, 173, 10, 236, 138, 231, 245, 14, 33, 112, 6, 22, 252, 0, 213, 28, 251, 214, 125)
      }), U1.Game:GetObjName(_ARG_0_.Object), U1.tostring(U1.Client ~= nil), U1.tostring(_ARG_0_:GetFlyEnergy())))
      _ARG_0_.bMarkRecycling = false
      _ARG_0_:AddControlEvent(_ARG_0_, U2(36, 45, 180, 48, 92, 166, 16, 162, 226, 251, 177, 45, 14, 97, 34, 22, 254, 23, 214, 33, 164, 159, 107, 129, 222, 240, 160), _ARG_0_.HandleOnMovementModeChanged, _ARG_0_)
      if not U1.Client then
        _ARG_0_:RefreshFlyEnergyTimer()
      end
      U1.Game:AdjustSkinnedMinLODForPerformance(_ARG_0_.Mesh, 2, 1, 1)
      _ARG_0_:AddControlEvent(_ARG_0_, U2(38, 44, 142, 58, 82, 162, 18, 128, 198, 241, 162, 24, 33, 104, 58, 29, 235, 63, 221, 16, 175, 135, 77, 142, 222, 234, 162, 61, 57), _ARG_0_.HandleLocalViewPlayerMountChanged, _ARG_0_)
      if U1.Client and U1.slua.isValid(_ARG_0_.Mesh) then
        _ARG_0_.Mesh:SetForceSyncCreatePSO(true)
        U1.print(U1.bWriteLog and U1.table.concat({
          U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 144, 107, 143, 201, 225, 135, 61, 58, 112, 61, 56, 229, 3, 219, 85, 130, 134, 106, 176),
          U2(6, 48, 161, 48, 98, 186, 16, 181, 236, 230, 176, 41, 57, 108, 19, 43, 214)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnOpenPawnCollision"] = function(_ARG_0_)
    do
      if not Client or not slua.isValid(_ARG_0_.Mesh) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveEndPlay"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 144, 107, 143, 201, 225, 128, 54, 57, 73, 63, 9, 240, 66, 135, 6, 241, 177, 123, 151),
        U1(26, 45, 172, 111, 20, 176)
      }), Game:GetObjName(_ARG_0_.Object), tostring(_ARG_1_)))
      _ARG_0_:StopRecycleCheckTimer()
      _ARG_0_:StopFlyEnergyCostTimer()
      _ARG_0_:StopFlyEnergyRecoverTimer()
      _ARG_0_:StopExhaustedRecoverDelayTimer()
      _ARG_0_:StopForceDestroyTimer()
      _ARG_0_:UnbindPOIRider()
      _ARG_0_:RestoreLocalCirclePainAdaptive(nil, (U1(44, 44, 166, 5, 93, 162, 7)))
      U2.__super.ReceiveEndPlay(_ARG_0_, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatAttached"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      __super.HandleSeatAttached(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
      if U1.Client then
        return
      end
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 45, 160, 157, 106, 138, 218, 215, 160, 57, 41, 88, 39, 28, 232, 1, 202, 16, 181, 195, 93, 158),
        U2(8, 48, 163, 54, 69, 166, 12, 236, 138, 231, 245, 27, 40, 104, 55, 44, 224, 2, 215, 95, 228, 128, 46, 181, 218, 229, 177, 17, 51, 125, 54, 16, 179, 71, 209)
      }), U1.Game:GetObjName(_ARG_1_), U1.tostring(_ARG_2_), U1.tostring(_ARG_3_)))
      if _ARG_2_ ~= U3.ESeatType_DriversSeat then
        return
      end
      _ARG_0_:BindPOIRider(_ARG_1_)
      if not U1.slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
        return
      end
      if _ARG_0_:GetBioVehicleMovement():IsFlying() then
        return
      end
      if _ARG_0_:GetBioVehicleMovement():IsSwimming() then
        return
      end
      if not _ARG_0_:IsAirborne() then
        return
      end
      if not _ARG_0_:CanEnterFlying() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsDrivingSeatType"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_1_ == ESeatType_DriversSeat end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopDriftOnDriverLeave"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.TryStopDrift then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 156, 126, 162, 205, 237, 163, 44, 18, 119, 23, 26, 224, 20, 199, 7, 157, 134, 127, 128),
          U1(12, 98, 176, 48, 69, 239, 94, 130, 221, 237, 134, 60, 34, 121, 7, 10, 240, 20, 198, 69, 175, 156, 122, 198, 217, 235, 176, 54, 57, 55, 115, 58, 236, 3, 209, 26, 191, 217, 59, 133)
        }), tostring(_ARG_2_)))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      __super.HandleSeatChanged(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 45, 160, 157, 106, 138, 218, 215, 160, 57, 41, 90, 59, 9, 231, 5, 199, 17, 241, 160, 118, 151),
        U2(27, 35, 161, 33, 84, 177, 68, 243, 220, 180, 153, 41, 62, 125, 16, 29, 248, 6, 230, 28, 177, 150, 52, 195, 204, 169, 251, 22, 56, 110, 0, 13, 232, 22, 246, 12, 161, 134, 36, 211),
        U2(26, 98, 142, 52, 66, 183, 45, 179, 206, 224, 156, 38, 41, 108, 59, 66, 188, 1, 159, 91, 143, 150, 121, 181, 218, 229, 177, 17, 51, 125, 54, 16, 179, 71, 209)
      }), U1.Game:GetObjName(_ARG_1_), U1.tostring(_ARG_2_), U1.tostring(_ARG_4_), U1.tostring(_ARG_3_), U1.tostring(_ARG_5_)))
      if _ARG_2_ == U3.ESeatType_DriversSeat then
        _ARG_0_:StopDriftOnDriverLeave(_ARG_1_, (U2(58, 39, 163, 33, 114, 171, 31, 184, 200, 241, 177)))
      end
      if not U1.Client and _ARG_4_ == U3.ESeatType_DriversSeat then
        _ARG_0_:BindPOIRider(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      __super.ClientHandleEnterVehicle(_ARG_0_, _ARG_1_, _ARG_2_)
      if U1.slua.isValid(_ARG_1_) then
        _ARG_0_:EnableLocalCirclePainAdaptive(_ARG_1_, (U2(44, 44, 182, 48, 67, 149, 27, 190, 198, 247, 185, 45)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      __super.ClientHandleExitVehicle(_ARG_0_, _ARG_1_, _ARG_2_)
      if U1.slua.isValid(_ARG_1_) then
        _ARG_0_:RestoreLocalCirclePainAdaptive(_ARG_1_, (U2(44, 58, 171, 33, 103, 166, 22, 191, 204, 248, 176)))
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleChangeVehicleSeat"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      __super.ClientHandleChangeVehicleSeat(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
      if U1.slua.isValid(_ARG_1_) then
        _ARG_0_:EnableLocalCirclePainAdaptive(_ARG_1_, (U2(42, 42, 163, 59, 86, 166, 40, 179, 199, 253, 182, 36, 40, 90, 38, 25, 237)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCirclePainAdaptive"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid((import((U1(58, 33, 176, 48, 84, 173, 63, 166, 223, 241, 180, 58, 44, 103, 32, 29, 202, 6, 211, 17, 168, 144, 125))).GetScreenAppearanceManager(_ARG_1_))) then
        return nil
      end
      if not slua.isValid((import((U1(58, 33, 176, 48, 84, 173, 63, 166, 223, 241, 180, 58, 44, 103, 32, 29, 202, 6, 211, 17, 168, 144, 125))).GetScreenAppearanceManager(_ARG_1_):FindAppearanceByName(_ARG_1_, U2))) then
        return nil
      end
      import((U1(58, 33, 176, 48, 84, 173, 63, 166, 223, 241, 180, 58, 44, 103, 32, 29, 202, 6, 211, 17, 168, 144, 125))).GetScreenAppearanceManager(_ARG_1_):FindAppearanceByName(_ARG_1_, U2).bEnableAdaptive = _ARG_2_
      do return import((U1(58, 33, 176, 48, 84, 173, 63, 166, 223, 241, 180, 58, 44, 103, 32, 29, 202, 6, 211, 17, 168, 144, 125))).GetScreenAppearanceManager(_ARG_1_):FindAppearanceByName(_ARG_1_, U2).bEnableAdaptive end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnableLocalCirclePainAdaptive"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.tCirclePainAdaptiveCache then
        return
      end
      if not _ARG_1_:IsLocallyControlled() then
        return
      end
      if not slua.isValid(_ARG_1_.GetPlayerControllerSafety and _ARG_1_:GetPlayerControllerSafety()) then
        return
      end
      _ARG_0_.tCirclePainAdaptiveCache = {
        uCharacter = _ARG_1_,
        uPlayerController = _ARG_1_.GetPlayerControllerSafety and _ARG_1_:GetPlayerControllerSafety(),
        bOldValue = nil
      }
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyLocalCirclePainAdaptive"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.tCirclePainAdaptiveCache or not slua.isValid(_ARG_0_.tCirclePainAdaptiveCache.uPlayerController) then
        return
      end
      if _ARG_0_:SetCirclePainAdaptive(_ARG_0_.tCirclePainAdaptiveCache.uPlayerController, true) ~= nil and _ARG_0_.tCirclePainAdaptiveCache.bOldValue == nil then
        _ARG_0_.tCirclePainAdaptiveCache.bOldValue = _ARG_0_:SetCirclePainAdaptive(_ARG_0_.tCirclePainAdaptiveCache.uPlayerController, true)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleLocalPlayerInOutBlueCircleChanged"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 45, 160, 157, 106, 138, 218, 200, 170, 59, 60, 117, 3, 4, 232, 27, 199, 7, 152, 141, 81, 131),
        U1(29, 0, 174, 32, 84, 128, 23, 164, 204, 248, 176, 11, 37, 104, 45, 31, 252, 22, 146, 7, 136, 128, 65, 147, 203, 198, 169, 45, 56, 90, 58, 26, 234, 14, 199, 79, 244, 144)
      }), tostring(_ARG_1_)))
      if not _ARG_1_ then
        return
      end
      _ARG_0_:ApplyLocalCirclePainAdaptive((U1(44, 44, 182, 48, 67, 129, 18, 163, 202, 215, 188, 58, 46, 101, 38)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RestoreLocalCirclePainAdaptive"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.tCirclePainAdaptiveCache then
        return
      end
      if slua.isValid(_ARG_1_) and _ARG_1_ ~= _ARG_0_.tCirclePainAdaptiveCache.uCharacter then
        return
      end
      _ARG_0_.tCirclePainAdaptiveCache = nil
      if not slua.isValid(_ARG_0_.tCirclePainAdaptiveCache.uPlayerController) then
        return
      end
      if _ARG_0_.tCirclePainAdaptiveCache.bOldValue == nil then
        return
      end
      do return end
      _ARG_2_ = _ENV[171]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatDetached"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      __super.HandleSeatDetached(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
      if _ARG_0_:IsDrivingSeatType(_ARG_2_) then
        _ARG_0_:StopDriftOnDriverLeave(_ARG_1_, (U1(58, 39, 163, 33, 117, 166, 10, 183, 204, 252, 176, 44)))
      end
      if U2.Client then
        return
      end
      if not U2.slua.isValid(_ARG_1_) then
        return
      end
      U2.print(U2.bWriteLog and U2.string.format(U2.table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 45, 160, 157, 106, 138, 218, 215, 160, 57, 41, 93, 54, 28, 232, 1, 202, 16, 181, 195, 93, 158),
        U1(8, 48, 163, 54, 69, 166, 12, 236, 138, 231, 245, 27, 40, 104, 55, 44, 224, 2, 215, 95, 228, 128, 46, 181, 218, 229, 177, 17, 51, 125, 54, 16, 179, 71, 209)
      }), U2.Game:GetObjName(_ARG_1_), U2.tostring(_ARG_2_), U2.tostring(_ARG_3_)))
      if _ARG_0_.uPOIRider and _ARG_0_.uPOIRider == _ARG_1_ then
      end
      if not _ARG_0_:IsFlyingMode() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1[237]
    end
  end,
  ["HandleLocalViewPlayerMountChanged"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
        Game:AdjustSkinnedMinLODForPerformance(_ARG_0_.Mesh, 1, 1, 0)
      else
        Game:AdjustSkinnedMinLODForPerformance(_ARG_0_.Mesh, 2, 1, 1)
      end
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 45, 160, 157, 106, 138, 218, 200, 170, 59, 60, 117, 5, 1, 236, 21, 242, 25, 176, 154, 123, 132),
        U1(36, 45, 183, 59, 69, 128, 22, 183, 193, 243, 176, 44, 109, 70, 33, 18, 163, 87, 193, 69, 136, 128, 67, 137, 202, 234, 177, 61, 57, 35, 118, 27)
      }), Game:GetObjName(_ARG_0_.Object), tostring(_ARG_1_)))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BindPOIRider"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_0_.uPOIRider and slua.isValid(_ARG_0_.uPOIRider) and _ARG_0_.uPOIRider == _ARG_1_ then
        _ARG_0_:RefreshPOIState()
        return
      end
      _ARG_0_:UnbindPOIRider()
      _ARG_0_.uPOIRider = _ARG_1_
      _ARG_0_:AddControlEventWithCondition(_ARG_1_, U1(38, 44, 131, 33, 69, 177, 61, 190, 206, 250, 178, 45, 8, 127, 38, 22, 237, 54, 215, 9, 164, 148, 111, 146, 218), {
        AttrName = {
          (U1(40, 48, 167, 52, 120, 135))
        }
      }, _ARG_0_.OnPOIRiderAttrChange, _ARG_0_)
      print(bWriteLog and string.format(U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 39, 168, 157, 106, 182, 240, 205, 151, 49, 57, 124, 33, 72, 219, 11, 198, 16, 163, 217, 59, 133), Game:GetObjName(_ARG_1_)))
      _ARG_0_:RefreshPOIState()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UnbindPOIRider"] = function(_ARG_0_)
    do
      if _ARG_0_.uPOIRider and slua.isValid(_ARG_0_.uPOIRider) then
        _ARG_0_:RemoveControlEvent(_ARG_0_.uPOIRider, (U1(38, 44, 131, 33, 69, 177, 61, 190, 206, 250, 178, 45, 8, 127, 38, 22, 237, 54, 215, 9, 164, 148, 111, 146, 218)))
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 48, 175, 145, 103, 136, 219, 212, 138, 17, 15, 112, 55, 13, 251, 66, 240, 28, 181, 134, 108, 204),
          U1(76, 49)
        }), Game:GetObjName(_ARG_0_.uPOIRider)))
      end
      _ARG_0_.uPOIRider = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[138]
    end
  end,
  ["OnPOIRiderAttrChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid(_ARG_1_) or _ARG_0_.uPOIRider ~= _ARG_1_ then
        return
      end
      if _ARG_2_ ~= U1(40, 48, 167, 52, 120, 135) then
        return
      end
      _ARG_0_:RefreshPOIState()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPOIRiderAreaID"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.uPOIRider) then
        return nil
      end
      if not _ARG_0_.uPOIRider.GetAttrValue then
        return nil
      end
      if not _ARG_0_.uPOIRider:GetAttrValue((U1(40, 48, 167, 52, 120, 135))) then
        return nil
      end
      do return math.floor(_ARG_0_.uPOIRider:GetAttrValue((U1(40, 48, 167, 52, 120, 135))) + 0.5) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPOIState"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_:GetPOIRiderAreaID() == nil then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPOIAreaID"] = function(_ARG_0_, _ARG_1_)
    do
      if U1.type(POIAreaID) ~= U2(29, 35, 160, 57, 84) then
        return _ARG_1_ == POIAreaID
      end
      goto lbl_27
      if _ARG_1_ == 160 then
        return true
      end
      ::lbl_27::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetInPOIArea"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if _ARG_0_.bInPOIArea == _ARG_1_ then
        return
      end
      _ARG_0_.bInPOIArea = _ARG_1_
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 164, 135, 71, 136, 239, 203, 140, 25, 47, 124, 50, 72, 235, 43, 204, 37, 158, 170, 36, 211),
        U1(26)
      }), tostring(_ARG_1_)))
      if not slua.isValid((_ARG_0_:GetBioVehicleMovement())) or not _ARG_0_:GetBioVehicleMovement().SetMovementDataType then
        return
      end
      if _ARG_1_ and _ARG_0_:GetBioVehicleMovement():SetMovementDataType(_ARG_1_ and U2.POI or U2.Normal) then
      end
      do return end
      _ARG_1_ = U1.Normal
      _ARG_0_ = _ENV[249]
    end
  end,
  ["ReportEnterPOITLog"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_0_.uPOIRider) or not _ARG_0_.uPOIRider.GetPlayerStateSafety then
        return
      end
      if not slua.isValid((_ARG_0_.uPOIRider:GetPlayerStateSafety())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddNoHurtBuff"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return false
      end
      if not _ARG_1_:AddBuffBySkill(U1.NoHurtBuffSkillID, 1, nil, 1) then
        print(bWriteLog and string.format(table.concat({
          U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 36, 165, 151, 64, 137, 247, 241, 183, 44, 31, 108, 53, 14, 169, 4, 195, 28, 189, 134, 122, 218),
          U2(73, 17, 169, 60, 93, 175, 55, 146, 149, 177, 166, 104, 14, 97, 34, 10, 248, 17, 198, 0, 179, 201, 43, 149)
        }), tostring(U1.NoHurtBuffSkillID), Game:GetObjName(_ARG_1_)))
        return false
      end
      print(bWriteLog and string.format(table.concat({
        U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 36, 165, 151, 64, 137, 247, 241, 183, 44, 31, 108, 53, 14, 169, 17, 215, 22, 178, 134, 109, 133),
        U2(69, 98, 145, 62, 88, 175, 18, 159, 235, 174, 240, 59, 109, 74, 43, 25, 235, 19, 209, 17, 164, 129, 52, 195, 204)
      }), tostring(U1.NoHurtBuffSkillID), Game:GetObjName(_ARG_1_)))
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLeaveVehicleVelocityModifier"] = function(_ARG_0_)
    do
      if _ARG_0_:IsFlyingMode() then
        return 0
      end
      do return _ARG_0_.Super:GetLeaveVehicleVelocityModifier() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearCharacterVelocity"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not Game:IsValid(_ARG_1_.STCharacterMovement) then
        return
      end
      _ARG_1_.STCharacterMovement.Velocity = FVector(0, 0, 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCharacterFalling"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return false
      end
      if not Game:IsValid(_ARG_1_.STCharacterMovement) then
        return false
      end
      do return _ARG_1_.STCharacterMovement:IsFalling() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnMovementModeChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
        return
      end
      if not slua.isValid(_ARG_0_.CapsuleComponent) then
        return
      end
      if _ARG_0_:GetBioVehicleMovement().MovementMode == U2.MOVE_Flying and _ARG_0_:IsBlockedByFlyingCapsule() then
        return
      end
      if _ARG_0_:GetBioVehicleMovement().MovementMode == U2.MOVE_Flying then
      end
      if math.abs(_ARG_0_.CapsuleComponent:GetUnscaledCapsuleRadius() - U3.FlyingCapsuleRadius) < 0.01 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsAirborne"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Object) then
        return false
      end
      if not U3.LineTraceSingle(_ARG_0_.Object, _ARG_0_:K2_GetActorLocation(), _ARG_0_:K2_GetActorLocation() - FVector(0, 0, U1.AirborneTraceLength), 6, false, slua.Array(UEnums.EPropertyClass.Object, (import((U2(70, 17, 161, 39, 88, 179, 10, 249, 234, 250, 178, 33, 35, 108, 109, 57, 250, 6, 221, 23))))), 0, import((U2(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true) then
        return true
      end
      do return _ARG_0_:K2_GetActorLocation().Z - U3.LineTraceSingle(_ARG_0_.Object, _ARG_0_:K2_GetActorLocation(), _ARG_0_:K2_GetActorLocation() - FVector(0, 0, U1.AirborneTraceLength), 6, false, slua.Array(UEnums.EPropertyClass.Object, (import((U2(70, 17, 161, 39, 88, 179, 10, 249, 234, 250, 178, 33, 35, 108, 109, 57, 250, 6, 221, 23))))), 0, import((U2(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true).Location.Z > U1.AirborneGroundDistThreshold end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanEnterFlying"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Object) then
        return true
      end
      if not _ARG_0_:CanFlyByEnergy() then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 38, 160, 157, 75, 136, 203, 225, 183, 30, 49, 96, 58, 6, 238, 66, 196, 20, 189, 144, 123, 218),
          U1(73, 44, 173, 117, 87, 175, 7, 246, 202, 250, 176, 58, 42, 112, 109, 88, 188, 1)
        }), Game:GetObjName(_ARG_0_.Object)))
        _ARG_0_:ShowFlyEnergyNotEnoughTips()
        return false
      end
      if _ARG_0_:IsBlockedByFlyingCapsule() then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 38, 160, 157, 75, 136, 203, 225, 183, 30, 49, 96, 58, 6, 238, 66, 196, 20, 189, 144, 123, 218),
          U1(73, 33, 163, 37, 66, 182, 18, 179, 143, 251, 163, 45, 63, 101, 34, 8, 233, 23, 214, 73, 225, 214, 125)
        }), Game:GetObjName(_ARG_0_.Object)))
        _ARG_0_:ShowFlyingBlockedTips()
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBlockedOverhead"] = function(_ARG_0_)
    do
      if (FlyingHeadroomTraceLength or 0) <= 0 then
        return false
      end
      if not U2.LineTraceMultiForObjects(_ARG_0_.Object, _ARG_0_:K2_GetActorLocation(), _ARG_0_:K2_GetActorLocation() + U1.FVector(0, 0, _ARG_0_.CapsuleComponent:GetScaledCapsuleHalfHeight() + (FlyingHeadroomTraceLength or 0)), _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, nil, true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0) or U2.LineTraceMultiForObjects(_ARG_0_.Object, _ARG_0_:K2_GetActorLocation(), _ARG_0_:K2_GetActorLocation() + U1.FVector(0, 0, _ARG_0_.CapsuleComponent:GetScaledCapsuleHalfHeight() + (FlyingHeadroomTraceLength or 0)), _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, nil, true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0) == nil then
        return false
      end
      goto lbl_195
      if _ARG_0_:IsFlyingBlockComponent(_ARG_0_:BuildSpaceCheckIgnoreActors().Component) then
        return true
      end
      ::lbl_195::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[52]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowFlyingBlockedTips"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not U1.FlyingBlockedTipsID then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowFlyEnergyNotEnoughTips"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not U1.FlyEnergyNotEnoughTipsID then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BuildSpaceCheckIgnoreActors"] = function(_ARG_0_)
    do
      if slua.isValid((_ARG_0_:GetVehicleSeats())) and _ARG_0_:GetVehicleSeats().SeatOccupiers then
        goto lbl_59
        ::lbl_59::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return (slua.Array(UEnums.EPropertyClass.Object, (import((U1(70, 17, 161, 39, 88, 179, 10, 249, 234, 250, 178, 33, 35, 108, 109, 57, 250, 6, 221, 23)))))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSpaceCheckObjectTypes"] = function(_ARG_0_)
    do
      do return {
        Game:ConvertToObjectType(U1.ECC_WorldStatic),
        Game:ConvertToObjectType(U1.ECC_WorldDynamic),
        Game:ConvertToObjectType(U1.ECC_Vehicle)
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsIgnorableBlockActor"] = function(_ARG_0_, _ARG_1_)
    do
      do return import((U1(62, 35, 182, 48, 67, 144, 9, 191, 194, 213, 182, 60, 34, 123))) ~= nil and Game:IsClassOf(_ARG_1_, (import((U1(62, 35, 182, 48, 67, 144, 9, 191, 194, 213, 182, 60, 34, 123))))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsComponentBlockingHorse"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return false
      end
      if not slua.isValid(_ARG_0_.CapsuleComponent) then
        return true
      end
      if _ARG_1_:GetCollisionResponseToChannel(_ARG_0_.CapsuleComponent:GetCollisionObjectType()) ~= import((U1(44, 1, 173, 57, 93, 170, 13, 191, 192, 250, 135, 45, 62, 121, 44, 22, 234, 23))).ECR_Block or _ARG_0_.CapsuleComponent:GetCollisionResponseToChannel(_ARG_1_:GetCollisionObjectType()) ~= import((U1(44, 1, 173, 57, 93, 170, 13, 191, 192, 250, 135, 45, 62, 121, 44, 22, 234, 23))).ECR_Block then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsFlyingBlockComponent"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return false
      end
      if slua.isValid((_ARG_1_:GetOwner())) and _ARG_0_:IsIgnorableBlockActor((_ARG_1_:GetOwner())) then
        return false
      end
      do return _ARG_0_:IsComponentBlockingHorse(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBlockedByFlyingCapsule"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.CapsuleComponent) then
        return false
      end
      if U1.FlyingCapsuleRadius <= 0 or _ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight() <= 0 then
        return false
      end
      if not U2.CapsuleOverlapComponents(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), U1.FlyingCapsuleRadius, _ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight(), _ARG_0_:GetSpaceCheckObjectTypes(), nil, _ARG_0_:BuildSpaceCheckIgnoreActors(), nil) or U2.CapsuleOverlapComponents(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), U1.FlyingCapsuleRadius, _ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight(), _ARG_0_:GetSpaceCheckObjectTypes(), nil, _ARG_0_:BuildSpaceCheckIgnoreActors(), nil) == nil then
        return false
      end
      goto lbl_139
      if _ARG_0_:IsFlyingBlockComponent(nil) then
        return true
      end
      ::lbl_139::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsDisplaceCheckDebugDrawEnabled"] = function(_ARG_0_)
    do
      do return DisplaceCheckDebugDraw == true or U1._G.IsEditor == true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DrawDisplaceCheckTraceDebug"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_:IsDisplaceCheckDebugDrawEnabled() then
        return
      end
      if not import((U1(58, 22, 135, 45, 69, 177, 31, 145, 206, 249, 176, 56, 33, 104, 58, 43, 237, 19, 198, 12, 162, 128))) or not import((U1(58, 22, 135, 45, 69, 177, 31, 145, 206, 249, 176, 56, 33, 104, 58, 43, 237, 19, 198, 12, 162, 128))).ClientDrawDebugLine then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DrawDisplaceCheckCapsuleDebug"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_0_:IsDisplaceCheckDebugDrawEnabled() then
        return
      end
      if not import((U1(58, 22, 135, 45, 69, 177, 31, 145, 206, 249, 176, 56, 33, 104, 58, 43, 237, 19, 198, 12, 162, 128))) or not import((U1(58, 22, 135, 45, 69, 177, 31, 145, 206, 249, 176, 56, 33, 104, 58, 43, 237, 19, 198, 12, 162, 128))).ClientDrawDebugCapsule then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HasSpaceForDisplaceAnim"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_3_ = _ARG_3_ or _ENV(33, 35, 177, 6, 65, 162, 29, 179, 233, 251, 167, 12, 36, 122, 51, 20, 248, 17, 215, 36, 175, 154, 99)
      if not (U1.slua.isValid(_ARG_0_.Object) and _ARG_2_) or _ARG_2_ <= 0 then
        return true
      end
      if not U1.slua.isValid(_ARG_0_.CapsuleComponent) then
        return true
      end
      if 0 >= _ARG_0_.CapsuleComponent:GetUnscaledCapsuleRadius() or 0 >= _ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight() then
        return true
      end
      if not _ARG_1_ then
      end
      if U4.LineTraceSingleForObjects(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), _ARG_0_.CapsuleComponent:K2_GetComponentLocation() + U3.GetForwardVector(U1.FRotator(0, _ARG_0_:K2_GetActorRotation().Yaw, 0)) * -1 * _ARG_2_, _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, U1.import((_ENV(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0) then
        if not U1.slua.isValid(U4.LineTraceSingleForObjects(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), _ARG_0_.CapsuleComponent:K2_GetComponentLocation() + U3.GetForwardVector(U1.FRotator(0, _ARG_0_:K2_GetActorRotation().Yaw, 0)) * -1 * _ARG_2_, _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, U1.import((_ENV(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0) and U4.LineTraceSingleForObjects(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), _ARG_0_.CapsuleComponent:K2_GetComponentLocation() + U3.GetForwardVector(U1.FRotator(0, _ARG_0_:K2_GetActorRotation().Yaw, 0)) * -1 * _ARG_2_, _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, U1.import((_ENV(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0).Actor or nil) or not _ARG_0_:IsIgnorableBlockActor(U4.LineTraceSingleForObjects(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), _ARG_0_.CapsuleComponent:K2_GetComponentLocation() + U3.GetForwardVector(U1.FRotator(0, _ARG_0_:K2_GetActorRotation().Yaw, 0)) * -1 * _ARG_2_, _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, U1.import((_ENV(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0) and U4.LineTraceSingleForObjects(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), _ARG_0_.CapsuleComponent:K2_GetComponentLocation() + U3.GetForwardVector(U1.FRotator(0, _ARG_0_:K2_GetActorRotation().Yaw, 0)) * -1 * _ARG_2_, _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, U1.import((_ENV(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0).Actor or nil) then
          return false
        end
      end
      if U4.CapsuleOverlapActors(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation() + U3.GetForwardVector(U1.FRotator(0, _ARG_0_:K2_GetActorRotation().Yaw, 0)) * -1 * _ARG_2_, _ARG_0_.CapsuleComponent:GetUnscaledCapsuleRadius() * (U2.DisplaceCheckCapsuleScale or 0.5), _ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight() * (U2.DisplaceCheckCapsuleScale or 0.5), _ARG_0_:GetSpaceCheckObjectTypes(), nil, _ARG_0_:BuildSpaceCheckIgnoreActors(), (U1.slua.Array(U1.UEnums.EPropertyClass.Object, (U1.import((_ENV(70, 17, 161, 39, 88, 179, 10, 249, 234, 250, 178, 33, 35, 108, 109, 57, 250, 6, 221, 23))))))) then
        goto lbl_660
        if U1.slua.isValid(_ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight() * (U2.DisplaceCheckCapsuleScale or 0.5)) and _ARG_0_:IsIgnorableBlockActor(_ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight() * (U2.DisplaceCheckCapsuleScale or 0.5)) then
        elseif U1.slua.isValid(_ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight() * (U2.DisplaceCheckCapsuleScale or 0.5)) then
          return false
        end
        ::lbl_660::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[16]
    end
  end,
  ["GetFlyEnergy"] = function(_ARG_0_)
    do
      do return _ARG_0_.fFlyEnergy or 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanFlyByEnergy"] = function(_ARG_0_)
    do
      do return _ARG_0_:GetFlyEnergy() > 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HasEnoughDashEnergy"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
      end
      do return U1.math.max(0, (DashEnergyCost or 0) - (DashEnergyNetTolerance or 0)) <= _ARG_0_:GetFlyEnergy() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CostDashEnergy"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if (U1.DashEnergyCost or 0) <= 0 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanAuthorityStartCurveMove"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return true
      end
      if _ARG_1_ ~= U1.Dash then
        return true
      end
      if not _ARG_0_:HasEnoughDashEnergy(true) then
        print(bWriteLog and string.format(table.concat({
          U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 38, 160, 157, 79, 147, 203, 236, 170, 42, 52, 109, 42, 59, 253, 3, 208, 1, 146, 150, 108, 128),
          U2(12, 15, 173, 35, 84, 227, 12, 179, 197, 241, 182, 60, 109, 77, 34, 11, 241, 94, 146, 0, 175, 150, 124, 129, 198, 164, 171, 55, 41, 57, 54, 6, 230, 23, 197, 29, 255, 195, 88, 154),
          U2(16, 7, 172, 48, 67, 164, 7, 236, 138, 231, 245, 11, 34, 122, 55, 66, 188, 1, 146, 49, 174, 159, 107, 148, 222, 234, 166, 61, 103, 60, 32)
        }), tostring(_ARG_0_:GetFlyEnergy()), tostring(U3.DashEnergyCost), tostring(U3.DashEnergyNetTolerance)))
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnAuthorityCurveMoveStart"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if _ARG_1_ == U1.Dash then
        _ARG_0_:CostDashEnergy()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnCurveMoveRejected"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 45, 160, 157, 106, 138, 218, 203, 171, 27, 40, 107, 37, 13, 196, 13, 212, 16, 131, 134, 116, 147),
        U1(10, 54, 167, 49, 17, 128, 11, 164, 217, 241, 129, 49, 61, 108, 121, 93, 234, 82, 224, 0, 171, 150, 109, 146, 218, 224, 135, 33, 18, 110, 61, 13, 251, 88, 135, 6, 241, 165, 114, 143),
        U1(44, 44, 167, 39, 86, 186, 68, 243, 220)
      }), tostring(_ARG_1_), tostring(_ARG_2_), tostring(_ARG_0_:GetFlyEnergy())))
      if _ARG_1_ == U2.Dash and _ARG_2_ and not _ARG_0_:HasEnoughDashEnergy(false) then
        _ARG_0_:ShowDashEnergyNotEnoughTips()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowDashEnergyNotEnoughTips"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not U1.DashEnergyNotEnoughTipsID then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleHPRatio"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetVehicleCommon())) then
        return U2.MaxHPRatio
      end
      if not _ARG_0_:GetVehicleCommon():GetVehicleHPMax() or _ARG_0_:GetVehicleCommon():GetVehicleHPMax() <= 0 then
        return U2.MaxHPRatio
      end
      do return math.max(0, math.min(U2.MaxHPRatio, (_ARG_0_:GetVehicleCommon():GetVehicleHP() or 0) / _ARG_0_:GetVehicleCommon():GetVehicleHPMax())) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleHPByRatio"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid((_ARG_0_:GetVehicleCommon())) then
        return
      end
      if not _ARG_0_:GetVehicleCommon():GetVehicleHPMax() or _ARG_0_:GetVehicleCommon():GetVehicleHPMax() <= 0 then
        return
      end
      _ARG_1_ = math.max(0, math.min(U2.MaxHPRatio, _ARG_1_ or U2.MaxHPRatio))
      return
    end
  end,
  ["GetMaxFlyEnergy"] = function(_ARG_0_)
    do
      do return MaxFlyEnergy end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetFlyEnergyPercent"] = function(_ARG_0_)
    do
      if MaxFlyEnergy <= 0 then
        return 0
      end
      do return U1.math.max(0, U1.math.min(1, _ARG_0_:GetFlyEnergy() / MaxFlyEnergy)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsFlyEnergyFull"] = function(_ARG_0_)
    do
      do return _ARG_0_:GetFlyEnergy() >= MaxFlyEnergy end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsFlyingMode"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
        return false
      end
      do return _ARG_0_:GetBioVehicleMovement().MovementMode == U1.MOVE_Flying end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsWalkingMode"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
        return false
      end
      do return _ARG_0_:GetBioVehicleMovement().MovementMode == U1.MOVE_Walking end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsExhaustedRecoverMode"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
        return false
      end
      do return _ARG_0_:GetBioVehicleMovement().MovementMode == U1.MOVE_Walking or _ARG_0_:GetBioVehicleMovement().MovementMode == U1.MOVE_Swimming end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HasPassenger"] = function(_ARG_0_)
    do
      if not _ARG_0_.GetVehicleSeats then
        return false
      end
      if not slua.isValid((_ARG_0_:GetVehicleSeats())) or not _ARG_0_:GetVehicleSeats().GetInUseSeatNum then
        return false
      end
      do return 0 < (_ARG_0_:GetVehicleSeats():GetInUseSeatNum() or 0) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshFlyEnergyTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_:IsFlyingMode() then
      elseif _ARG_0_.bFlyEnergyExhaustedLock then
        if _ARG_0_:IsExhaustedRecoverMode() then
        else
        end
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartExhaustedRecoverDelayTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.nExhaustedRecoverDelayTimer then
        return
      end
      if (U1.FlyEnergyExhaustedRecoverDelay or 0) <= 0 then
        return
      end
      _ARG_0_.nExhaustedRecoverDelayTimer = _ARG_0_:AddGameTimer(U1.FlyEnergyExhaustedRecoverDelay or 0, false, function()
        nExhaustedRecoverDelayTimer = nil
        _ENV:OnExhaustedRecoverDelayFinished()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopExhaustedRecoverDelayTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.nExhaustedRecoverDelayTimer then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 156, 126, 163, 199, 236, 164, 45, 46, 109, 54, 12, 219, 7, 193, 26, 167, 134, 108, 178),
          U1(12, 46, 163, 44, 101, 170, 19, 179, 221)
        }))))
        _ARG_0_:RemoveGameTimer(_ARG_0_.nExhaustedRecoverDelayTimer)
        _ARG_0_.nExhaustedRecoverDelayTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnExhaustedRecoverDelayFinished"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if not _ARG_0_:IsExhaustedRecoverMode() then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 42, 175, 182, 118, 142, 222, 241, 182, 44, 56, 125, 1, 13, 234, 13, 212, 16, 163, 167, 123, 154),
          U1(8, 59, 132, 60, 95, 170, 13, 190, 202, 240, 245, 58, 40, 125, 111, 88, 247, 29, 198, 69, 182, 146, 98, 141, 214, 234, 162, 120, 50, 107, 115, 27, 254, 11, 207, 24, 184, 141, 121)
        }))))
        return
      end
      print(bWriteLog and string.format((table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 42, 175, 182, 118, 142, 222, 241, 182, 44, 56, 125, 1, 13, 234, 13, 212, 16, 163, 167, 123, 154),
        U1(8, 59, 132, 60, 95, 170, 13, 190, 202, 240, 245, 61, 35, 101, 44, 27, 242, 82, 215, 11, 164, 129, 105, 159, 159, 246, 160, 59, 50, 111, 54, 26)
      }))))
      _ARG_0_.bFlyEnergyExhaustedLock = false
      _ARG_0_:RefreshFlyEnergyTimer()
      return
    end
  end,
  ["StartFlyEnergyCostTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.nFlyEnergyCostTimer then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 232, 188, 29, 51, 124, 33, 15, 240, 33, 205, 6, 165, 183, 119, 155),
          U1(12, 48, 226, 39, 84, 183, 82, 246, 219, 253, 184, 45, 63, 41, 34, 20, 235, 23, 211, 1, 184, 211, 107, 158, 214, 247, 177)
        }))))
        return
      end
      if _ARG_0_:GetFlyEnergy() <= 0 then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 232, 188, 29, 51, 124, 33, 15, 240, 33, 205, 6, 165, 183, 119, 155),
          U1(12, 48, 226, 48, 95, 166, 12, 177, 214, 180, 188, 59, 109, 108, 46, 8, 237, 11, 158, 69, 164, 139, 103, 146, 159, 226, 169, 33, 52, 119, 52)
        }))))
        _ARG_0_:OnFlyEnergyExhausted()
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 232, 188, 29, 51, 124, 33, 15, 240, 33, 205, 6, 165, 183, 119, 155),
        U1(12, 48, 226, 28, 95, 183, 27, 164, 217, 245, 185, 114, 104, 122, 99, 59, 246, 1, 198, 51, 160, 159, 123, 131, 133, 161, 182, 120, 27, 117, 42, 45, 231, 7, 208, 18, 168, 217, 59, 133)
      }), tostring(U2.FlyEnergyCostTimeInterval), tostring(U2.FlyEnergyCostValue), tostring(_ARG_0_:GetFlyEnergy())))
      _ARG_0_.nFlyEnergyCostTimer = _ARG_0_:AddGameTimer(U2.FlyEnergyCostTimeInterval, true, function()
        _ENV:UpdateFlyEnergyCost()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopFlyEnergyCostTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.nFlyEnergyCostTimer then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 156, 126, 160, 211, 253, 128, 54, 56, 107, 52, 17, 202, 13, 209, 1, 133, 138, 115, 147),
          U1(27, 98, 132, 57, 72, 134, 16, 179, 221, 243, 172, 114, 104, 122)
        }), tostring(_ARG_0_:GetFlyEnergy())))
        _ARG_0_:RemoveGameTimer(_ARG_0_.nFlyEnergyCostTimer)
        _ARG_0_.nFlyEnergyCostTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateFlyEnergyCost"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if not _ARG_0_:IsFlyingMode() then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 48, 177, 151, 111, 146, 218, 194, 169, 33, 24, 119, 54, 26, 238, 27, 225, 26, 162, 151, 62, 152),
          U1(6, 54, 226, 51, 93, 186, 23, 184, 200, 184, 245, 58, 40, 111, 49, 29, 234, 26, 146, 17, 168, 158, 107, 148)
        }))))
        _ARG_0_:RefreshFlyEnergyTimer()
        return
      end
      if slua.isValid((_ARG_0_:GetBioVehicleMovement())) and _ARG_0_:GetBioVehicleMovement():IsCurveMoving() then
        return
      end
      if 0 >= math.max(0, _ARG_0_:GetFlyEnergy() - U2.FlyEnergyCostValue) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartFlyEnergyRecoverTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.nFlyEnergyRecoverTimer then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 232, 188, 29, 51, 124, 33, 15, 240, 48, 199, 22, 190, 149, 123, 132),
          U1(61, 43, 175, 48, 67, 227, 12, 179, 219, 184, 245, 60, 36, 100, 38, 10, 185, 19, 222, 23, 164, 146, 106, 159, 159, 225, 189, 49, 46, 109)
        }))))
        return
      end
      if _ARG_0_:IsFlyEnergyFull() then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 232, 188, 29, 51, 124, 33, 15, 240, 48, 199, 22, 190, 149, 123, 132),
          U1(61, 43, 175, 48, 67, 227, 12, 179, 219, 184, 245, 45, 35, 108, 49, 31, 224, 82, 219, 22, 225, 149, 123, 138, 211)
        }))))
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 232, 188, 29, 51, 124, 33, 15, 240, 48, 199, 22, 190, 149, 123, 132),
        U1(61, 43, 175, 48, 67, 227, 55, 184, 219, 241, 167, 62, 44, 101, 121, 93, 234, 82, 224, 0, 162, 156, 120, 131, 205, 210, 164, 52, 40, 124, 105, 77, 250, 66, 228, 25, 168, 166, 112, 147),
        U1(27, 37, 187, 111, 20, 176)
      }), tostring(U2.FlyEnergyRecoverTimeInterval), tostring(U2.FlyEnergyRecoverValue), tostring(_ARG_0_:GetFlyEnergy())))
      _ARG_0_.nFlyEnergyRecoverTimer = _ARG_0_:AddGameTimer(U2.FlyEnergyRecoverTimeInterval, true, function()
        _ENV:UpdateFlyEnergyRecover()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopFlyEnergyRecoverTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.nFlyEnergyRecoverTimer then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 156, 126, 160, 211, 253, 128, 54, 56, 107, 52, 17, 219, 7, 193, 26, 167, 134, 108, 162),
          U1(0, 47, 167, 39, 17, 133, 18, 175, 234, 250, 176, 58, 42, 112, 121, 93, 234)
        }), tostring(_ARG_0_:GetFlyEnergy())))
        _ARG_0_:RemoveGameTimer(_ARG_0_.nFlyEnergyRecoverTimer)
        _ARG_0_.nFlyEnergyRecoverTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateFlyEnergyRecover"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_:IsFlyingMode() then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 48, 177, 151, 111, 146, 218, 194, 169, 33, 24, 119, 54, 26, 238, 27, 240, 16, 178, 140, 104, 147),
          U1(27, 98, 171, 38, 17, 165, 18, 175, 198, 250, 178, 100, 109, 123, 38, 30, 235, 23, 193, 13, 225, 135, 103, 139, 218, 246)
        }))))
        _ARG_0_:RefreshFlyEnergyTimer()
        return
      end
      if math.min(U2.MaxFlyEnergy, _ARG_0_:GetFlyEnergy() + U2.FlyEnergyRecoverValue) >= U2.MaxFlyEnergy then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetFlyEnergy"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if _ARG_0_.fFlyEnergy == _ARG_1_ then
        return
      end
      _ARG_0_.fFlyEnergy = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnFlyEnergyExhausted"] = function(_ARG_0_)
    do
      if _ARG_0_.bExitingFlyEnergy then
        return
      end
      _ARG_0_.bExitingFlyEnergy = true
      _ARG_0_.bFlyEnergyExhaustedLock = true
      _ARG_0_:StopExhaustedRecoverDelayTimer()
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 42, 175, 181, 98, 159, 250, 234, 160, 42, 58, 96, 22, 16, 225, 3, 215, 6, 165, 134, 122, 214),
        U1(47, 46, 187, 16, 95, 166, 12, 177, 214, 174, 240, 59)
      }), tostring(_ARG_0_:GetFlyEnergy())))
      _ARG_0_.bExitingFlyEnergy = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartRecycleCheckTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 237, 225, 166, 33, 62, 117, 54, 43, 225, 7, 193, 30, 133, 138, 115, 147),
        U1(27, 98, 139, 59, 69, 166, 12, 160, 206, 248, 239, 109, 62)
      }), tostring(U2.RecycleCheckInterval)))
      _ARG_0_:StopRecycleCheckTimer()
      _ARG_0_.nRecycleCheckTimer = _ARG_0_:AddGameTimer(U2.RecycleCheckInterval, true, function()
        _ENV:CheckRecycleCondition()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopRecycleCheckTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.nRecycleCheckTimer then
        print(bWriteLog and string.format((U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 156, 126, 180, 218, 231, 188, 59, 49, 124, 16, 0, 236, 1, 201, 33, 184, 142, 123, 132))))
        _ARG_0_:RemoveGameTimer(_ARG_0_.nRecycleCheckTimer)
        _ARG_0_.nRecycleCheckTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckRecycleCondition"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if not Game:IsValid(_ARG_0_.Object) then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 38, 169, 150, 109, 141, 237, 225, 166, 33, 62, 117, 54, 43, 230, 12, 198, 28, 165, 138, 113, 152),
          U1(73, 48, 167, 33, 29, 227, 23, 184, 217, 245, 185, 33, 41, 41, 44, 26, 243, 23, 209, 17)
        }))))
        _ARG_0_:StopRecycleCheckTimer()
        return
      end
      if _ARG_0_.bMarkRecycling then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 38, 169, 150, 109, 141, 237, 225, 166, 33, 62, 117, 54, 43, 230, 12, 198, 28, 165, 138, 113, 152),
          U1(73, 48, 167, 33, 29, 227, 31, 186, 221, 241, 180, 44, 52, 41, 49, 29, 250, 11, 209, 9, 168, 157, 105)
        }))))
        _ARG_0_:StopRecycleCheckTimer()
        return
      end
      if not Game:IsValid(_ARG_0_.CreatedByCharacter) then
      elseif _ARG_0_.CreatedByCharacter.IsAlive and not _ARG_0_.CreatedByCharacter:IsAlive() then
      elseif FVector.Distance(_ARG_0_:K2_GetActorLocation(), _ARG_0_.CreatedByCharacter:K2_GetActorLocation()) > U2.MaxDistToCreator then
      end
      if string.format(table.concat({
        U1(29, 45, 173, 117, 87, 162, 12, 246, 201, 230, 186, 37, 109, 106, 49, 29, 248, 6, 221, 23, 237, 211, 74, 143, 204, 240, 164, 54, 62, 124, 105, 77, 167, 83, 196, 85, 156, 130, 102, 204),
        U1(76, 108, 243, 51)
      }), FVector.Distance(_ARG_0_:K2_GetActorLocation(), _ARG_0_.CreatedByCharacter:K2_GetActorLocation()), U2.MaxDistToCreator) == nil then
        return
      end
      if true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowRecycleTips"] = function(_ARG_0_, _ARG_1_)
    do
      if Client or not _ARG_1_ then
        return
      end
      if not Game:IsValid((_ARG_0_:GetSkyHorseCreator())) or not _ARG_0_:GetSkyHorseCreator().PlayerKey then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecycleSkyHorse"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 144, 119, 133, 211, 225, 150, 51, 36, 81, 60, 26, 250, 7, 130, 80, 162, 195, 93, 132),
        U1(12, 35, 182, 48, 85, 129, 7, 149, 199, 245, 167, 41, 46, 125, 38, 10, 163, 87, 193)
      }), _ARG_0_.Object, Game:GetObjName(_ARG_0_.CreatedByCharacter)))
      if _ARG_0_.bMarkRecycling then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 144, 119, 133, 211, 225, 150, 51, 36, 81, 60, 26, 250, 7, 130, 28, 162, 195, 76, 147),
          U1(10, 59, 161, 57, 88, 173, 25, 247)
        }))))
        return
      end
      _ARG_0_:StopRecycleCheckTimer()
      if not _ARG_0_ or not Game:IsValid(_ARG_0_.Object) then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 144, 119, 133, 211, 225, 150, 51, 36, 81, 60, 26, 250, 7, 130, 28, 191, 149, 127, 154),
          U1(0, 38, 226, 58, 83, 169, 27, 181, 219)
        }))))
        return
      end
      _ARG_0_:SetEnterDistanceSq(0.0)
      if _ARG_0_.ForceExitCharacters then
        _ARG_0_:ForceExitCharacters(true)
      end
      if _ARG_0_:GetSummonFeature() then
      else
      end
      _ARG_0_.bMarkRecycling = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MulticastRPC_EnterRecycleState"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 40, 180, 159, 122, 143, 220, 229, 182, 44, 15, 73, 16, 55, 204, 12, 214, 16, 163, 177, 123, 149),
        U1(16, 33, 174, 48, 98, 183, 31, 162, 202, 180, 240, 59, 109, 107, 10, 22, 201, 30, 211, 6, 164, 178, 96, 143, 210, 190, 224, 43)
      }), Game:GetObjName(_ARG_0_.Object), tostring(_ARG_1_)))
      if Client then
        if _ARG_0_.BpRecycle then
          _ARG_0_:BpRecycle()
        end
      end
      if slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
      else
      end
      if slua.isValid((_ARG_0_:K2_GetRootComponent())) and _ARG_0_:K2_GetRootComponent().SetCollisionProfileName then
      else
      end
      if slua.isValid(_ARG_0_.HeadCapsuleComponent) and _ARG_0_.HeadCapsuleComponent.SetCollisionProfileName then
      else
      end
      if slua.isValid(_ARG_0_.Mesh) and _ARG_0_.Mesh.SetCollisionProfileName then
        _ARG_0_.bEnableCollisionOptimization = false
      else
      end
      do return end
      _ARG_1_ = U1[47]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PickDisplaceOrInPlaceAnim"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_3_ then
        return _ARG_1_
      end
      if not _ARG_2_ or _ARG_2_ == _ENV() then
        U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
          _ENV(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 53, 168, 144, 101, 162, 214, 247, 181, 52, 60, 122, 54, 39, 251, 43, 204, 37, 189, 130, 125, 147),
          _ENV(40, 44, 171, 56, 17, 230, 13, 246, 198, 250, 248, 56, 33, 104, 32, 29, 185, 19, 220, 12, 172, 211, 64, 169, 235, 164, 166, 55, 51, 127, 58, 15, 252, 16, 199, 17, 253, 195, 120, 151),
          _ENV(5, 46, 160, 52, 82, 168, 94, 162, 192, 180, 177, 33, 62, 121, 47, 25, 250, 23, 146, 4, 175, 154, 99)
        }), U1.tostring(_ARG_4_)))
        return _ARG_1_
      end
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        _ENV(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 53, 168, 144, 101, 162, 214, 247, 181, 52, 60, 122, 54, 39, 251, 43, 204, 37, 189, 130, 125, 147),
        _ENV(40, 44, 171, 56, 17, 230, 13, 246, 218, 231, 176, 104, 36, 103, 110, 8, 245, 19, 209, 0, 225, 146, 96, 143, 210, 190, 224, 43)
      }), U1.tostring(_ARG_4_), _ARG_2_))
      do return _ARG_2_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MulticastRPC_PlaySpawnAnim"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if Client then
        _ARG_0_.fClientSpawnAnimTime = U1.GetTimeSeconds(_ARG_0_.Object)
      end
      if _ARG_1_ then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlaySummonerSpawnMontage"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_2_) then
        _ARG_2_ = _ARG_0_:GetSkyHorseCreator()
      end
      if not slua.isValid(_ARG_2_) or not _ARG_2_.PlayAnimMontage then
        print(bWriteLog and table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 53, 173, 146, 119, 181, 202, 233, 168, 55, 51, 124, 33, 59, 249, 3, 213, 27, 156, 140, 112, 130),
          U1(8, 37, 167, 117, 67, 166, 10, 250, 143, 253, 187, 62, 44, 101, 42, 28, 185, 33, 199, 8, 172, 156, 96, 131, 205)
        }))
        return
      end
      if not (_ARG_1_ and U2.SummonerSpawnMontage_Air or U2.SummonerSpawnMontage_Ground) or (_ARG_1_ and U2.SummonerSpawnMontage_Air or U2.SummonerSpawnMontage_Ground) == U1() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayAnimAssetOnMesh"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_2_ = _ARG_2_ or _ENV(57, 46, 163, 44, 112, 173, 23, 187, 238, 231, 166, 45, 57, 70, 45, 53, 252, 1, 218)
      if not _ARG_1_ or _ARG_1_ == _ENV() then
        U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
          _ENV(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 64, 178, 211, 124, 131, 203, 168, 229, 54, 50, 57, 50, 6, 224, 15, 130, 22, 190, 141, 120, 159),
          _ENV(14, 55, 176, 48, 85)
        }), _ARG_2_))
        return
      end
      if not U1.slua.isValid(_ARG_0_.Mesh) then
        return
      end
      if not U1.slua.isValid(_ARG_0_.Mesh:GetAnimInstance()) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartForceDestroyTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.nForceDestroyTimer then
        return
      end
      _ARG_0_.nForceDestroyTimer = _ARG_0_:AddGameTimer(U1.RecycleForceDestroyDelay, false, function()
        nForceDestroyTimer = nil
        if not _ENV or not U1.Game:IsValid(Object) then
          return
        end
        U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
          U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 235, 183, 59, 56, 93, 54, 27, 253, 16, 205, 12, 133, 138, 115, 147),
          U2(27, 98, 164, 58, 67, 160, 27, 246, 203, 241, 166, 60, 63, 102, 58, 88, 188, 1)
        }), U1.Game:GetObjName(Object)))
        _ENV:K2_DestroyActor()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopForceDestroyTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.nForceDestroyTimer then
        _ARG_0_:RemoveGameTimer(_ARG_0_.nForceDestroyTimer)
        _ARG_0_.nForceDestroyTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSummonFeature"] = function(_ARG_0_)
    do
      if not Game:IsValid((_ARG_0_:GetSkyHorseCreator())) then
        return nil
      end
      do return _ARG_0_:GetSkyHorseCreator().SkyHorseSummonFeature end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaHandleVehicleHealthDestroy"] = function(_ARG_0_)
    do
      __super.LuaHandleVehicleHealthDestroy(_ARG_0_)
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 41, 180, 146, 70, 135, 209, 224, 169, 61, 11, 124, 59, 1, 234, 14, 199, 61, 180, 130, 114, 130),
        U2(1, 6, 167, 38, 69, 177, 17, 175, 143, 177, 166, 104, 14, 123, 38, 25, 237, 23, 214, 39, 184, 176, 102, 135, 205, 229, 166, 44, 56, 107, 105, 77, 250)
      }), U1.Game:GetObjName(_ARG_0_.Object), U1.Game:GetObjName(_ARG_0_.CreatedByCharacter)))
      if U1.Client then
        _ARG_0_:BpRecycle()
        return
      end
      if _ARG_0_.bMarkRecycling then
        U1.print(U1.bWriteLog and U1.string.format((U1.table.concat({
          U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 41, 180, 146, 70, 135, 209, 224, 169, 61, 11, 124, 59, 1, 234, 14, 199, 61, 180, 130, 114, 130),
          U2(1, 6, 167, 38, 69, 177, 17, 175, 143, 230, 176, 60, 97, 41, 34, 20, 235, 23, 211, 1, 184, 211, 124, 131, 220, 253, 166, 52, 52, 119, 52)
        }))))
        return
      end
      _ARG_0_.bMarkRecycling = true
      _ARG_0_:StopRecycleCheckTimer()
      _ARG_0_:StopFlyEnergyCostTimer()
      _ARG_0_:StopFlyEnergyRecoverTimer()
      _ARG_0_:StopExhaustedRecoverDelayTimer()
      _ARG_0_:DoSummonSkillCoolDown(_ARG_0_:GetSkyHorseCreator(), U3.DeadCDTime)
      if _ARG_0_:GetSummonFeature() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DoSummonSkillCoolDown"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      if not Game:IsValid(_ARG_1_) or not Game:IsValid(_ARG_1_.SkillManager) then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 33, 174, 160, 123, 139, 210, 235, 171, 11, 54, 112, 63, 4, 202, 13, 205, 25, 149, 140, 105, 152),
          U1(73, 48, 167, 33, 29, 227, 23, 184, 217, 245, 185, 33, 41, 41, 0, 16, 248, 0, 211, 6, 181, 150, 124, 198, 208, 246, 229, 11, 54, 112, 63, 4, 196, 3, 204, 20, 182, 134, 108, 216),
          U1(73, 1, 170, 52, 67, 162, 29, 162, 202, 230, 239, 109, 62)
        }), Game:GetObjName(_ARG_1_)))
        return
      end
      _ARG_2_ = _ARG_2_ or U2.RecycleCDTime
      if Game:IsValid(_ARG_0_.ItemHandle) and _ARG_0_.ItemHandle.SkillID and 0 < _ARG_0_.ItemHandle.SkillID then
      end
      if not _ARG_0_.ItemHandle.SkillID or 0 >= _ARG_0_.ItemHandle.SkillID then
        return
      end
      do return end
      _ARG_2_ = U1[120]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegisterSkyHorseOwner"] = function(_ARG_0_, _ARG_1_)
    do
      if Game:IsValid(_ARG_1_) then
        _ARG_0_.ItemHandle = _ARG_1_
        _ARG_0_.ItemInstanceID = _ARG_1_.DefineID.InstanceID
        if not Client then
          _ARG_0_.CreatedByCharacter = _ARG_1_.OwningCharacter
          _ARG_0_.uRepCreator = _ARG_0_.CreatedByCharacter
          _ARG_1_:SetUsing(false)
          if _ARG_0_:GetSummonFeature() then
          else
          end
        end
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 148, 103, 149, 203, 225, 183, 11, 54, 96, 27, 7, 251, 17, 199, 58, 166, 141, 123, 132),
          U1(73, 11, 182, 48, 92, 138, 16, 165, 219, 245, 187, 43, 40, 64, 7, 66, 188, 1, 146, 38, 179, 150, 111, 146, 218, 224, 135, 33, 30, 113, 50, 26, 232, 1, 214, 16, 163, 217, 59, 133)
        }), tostring(_ARG_0_.ItemInstanceID), Game:GetObjName(_ARG_0_.CreatedByCharacter)))
      else
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 148, 103, 149, 203, 225, 183, 11, 54, 96, 27, 7, 251, 17, 199, 58, 166, 141, 123, 132),
          U1(73, 48, 167, 33, 29, 227, 23, 184, 217, 245, 185, 33, 41, 41, 10, 12, 252, 31, 250, 4, 175, 151, 98, 131)
        }))))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSkyHorseCreator"] = function(_ARG_0_)
    do
      if not Client and Game:IsValid(_ARG_0_.CreatedByCharacter) then
        return _ARG_0_.CreatedByCharacter
      end
      do return _ARG_0_.uRepCreator end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDoubleClick_DriveLeft"] = function(_ARG_0_)
    do
      if _ARG_0_.TryStartDrift then
        _ARG_0_:TryStartDrift()
        _ARG_0_.VehicleSpringArm:ResetFreeCamera()
        _ARG_0_.VehicleSpringArm:ResetSmartCamera()
      end
      print(bWriteLog and string.format((table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 42, 175, 183, 97, 147, 221, 232, 160, 27, 49, 112, 48, 3, 214, 38, 208, 28, 167, 134, 82, 147),
        U1(15, 54)
      }))))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDoubleClick_DriveRight"] = function(_ARG_0_)
    do
      if _ARG_0_.TryStartDrift then
        _ARG_0_:TryStartDrift()
        _ARG_0_.VehicleSpringArm:ResetFreeCamera()
        _ARG_0_.VehicleSpringArm:ResetSmartCamera()
      end
      print(bWriteLog and string.format((table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 42, 175, 183, 97, 147, 221, 232, 160, 27, 49, 112, 48, 3, 214, 38, 208, 28, 167, 134, 76, 159),
        U1(14, 42, 182)
      }))))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDoubleClick_Land"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanCurveMove"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
        return false
      end
      if _ARG_0_:GetBioVehicleMovement():IsCurveMoving() then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanRecoverHP"] = function(_ARG_0_)
    do
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInSpawnForbidJumpTime"] = function(_ARG_0_)
    do
      if not Client then
        return false
      end
      if not _ARG_0_.fClientSpawnAnimTime then
        return false
      end
      if (U1.SpawnForbidJumpDuration or 0) <= 0 then
        return false
      end
      do return (U1.SpawnForbidJumpDuration or 0) > U2.GetTimeSeconds(_ARG_0_.Object) - _ARG_0_.fClientSpawnAnimTime end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsJumpSkillForbidden"] = function(_ARG_0_)
    do
      if _ARG_0_:IsInSpawnForbidJumpTime() then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 44, 178, 185, 123, 139, 207, 215, 174, 49, 49, 117, 21, 7, 251, 0, 203, 17, 181, 134, 112, 214),
          U1(29, 48, 183, 48, 29, 227, 23, 184, 143, 231, 165, 41, 58, 103, 99, 30, 246, 0, 208, 12, 165, 211, 100, 147, 210, 244, 229, 44, 52, 116, 54, 70, 169, 33, 206, 28, 180, 141, 106, 165),
          U1(25, 35, 181, 59, 112, 173, 23, 187, 251, 253, 184, 45, 119, 44, 48)
        }), tostring(_ARG_0_.fClientSpawnAnimTime)))
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}).MulticastRPC.MulticastRPC_EnterRecycleState = {
  Reliable = true,
  Params = {
    UEnums.EPropertyClass.Bool
  }
}
;({
  ServerRPC = {},
  ClientRPC = {},
  MulticastRPC = {},
  ["GetVehicleControlUIConfig"] = function(_ARG_0_)
    do
      do return {
        CommonUIGroup = {
          (U1(58, 41, 187, 29, 94, 177, 13, 179, 236, 251, 187, 60, 63, 102, 47, 45, 208))
        },
        DriverUIGroup = {
          (U1(43, 43, 173, 3, 84, 171, 23, 181, 195, 241, 150, 39, 35, 125, 49, 23, 245, 39, 251, 36, 180, 135, 97, 171, 208, 242, 160))
        },
        VehicleMode = 3,
        VModeKey = import((U1(44, 17, 150, 16, 73, 183, 12, 183, 249, 241, 189, 33, 46, 101, 38, 44, 224, 2, 215))).VT_CustomVehicle4
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUIConfig"] = function(_ARG_0_)
    do
      do return {
        SkyHorseControlUI = {
          moduleName = table.concat({
            U1(46, 35, 175, 48, 125, 182, 31, 248, 226, 251, 177, 102, 1, 96, 33, 10, 248, 0, 203, 75, 134, 146, 99, 131, 239, 232, 164, 33, 115, 79, 54, 0, 224, 1, 206, 16, 255, 176, 117, 143),
            U1(33, 45, 176, 38, 84, 237, 45, 189, 214, 220, 186, 58, 62, 108, 0, 23, 247, 6, 192, 10, 173, 166, 71)
          }),
          path = table.concat({
            U1(70, 5, 163, 56, 84, 236, 50, 191, 205, 230, 180, 58, 52, 38, 17, 29, 234, 93, 228, 0, 169, 154, 109, 138, 218, 247, 234, 11, 54, 96, 27, 7, 251, 17, 199, 90, 132, 170, 49, 165),
            U1(2, 59, 138, 58, 67, 176, 27, 149, 192, 250, 161, 58, 34, 101, 22, 49, 183, 33, 217, 28, 137, 156, 124, 149, 218, 199, 170, 54, 41, 107, 60, 4, 220, 43)
          }),
          isMainUI = false,
          isSingleton = true,
          zOrder = 0,
          asy = true,
          closeOnHide = false,
          uiStat = {
            name = U1(33, 45, 176, 38, 84, 128, 17, 184, 219, 230, 186, 36, 24, 64)
          },
          AndroidBackType = require((table.concat({
            U1(10, 46, 171, 48, 95, 183, 80, 165, 195, 225, 180, 102, 46, 102, 45, 30, 240, 21, 156, 38, 173, 154, 107, 136, 203, 201, 164, 59, 47, 118, 32, 70, 204, 35, 204, 17, 163, 140, 119, 146),
            U1(43, 35, 161, 62, 101, 186, 14, 179)
          }))).Ban
        }
      } end
      do return end
      _ARG_0_ = _ENV[176]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PostConstruct"] = function(_ARG_0_)
    do
      __super._PostConstruct(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ctor"] = function(_ARG_0_)
    do
      _ARG_0_.fFlyEnergy = MaxFlyEnergy
      _ARG_0_.bFlyEnergyExhaustedLock = false
      _ARG_0_.nExhaustedRecoverDelayTimer = nil
      _ARG_0_.uRepCreator = nil
      _ARG_0_.bMarkRecycling = false
      _ARG_0_.bInPOIArea = false
      _ARG_0_.uPOIRider = nil
      _ARG_0_.fClientSpawnAnimTime = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLifetimeReplicatedProps"] = function(_ARG_0_)
    do
      do return {
        {
          U1(15, 4, 174, 44, 116, 173, 27, 164, 200, 237),
          import((U1(44, 14, 171, 51, 84, 183, 23, 187, 202, 215, 186, 38, 41, 96, 55, 17, 246, 28))).COND_None,
          UEnums.EPropertyClass.Float
        },
        {
          U1(28, 16, 167, 37, 114, 177, 27, 183, 219, 251, 167),
          import((U1(44, 14, 171, 51, 84, 183, 23, 187, 202, 215, 186, 38, 41, 96, 55, 17, 246, 28))).COND_None,
          UEnums.EPropertyClass.Object
        },
        {
          U1(11, 15, 163, 39, 90, 145, 27, 181, 214, 247, 185, 33, 35, 110),
          import((U1(44, 14, 171, 51, 84, 183, 23, 187, 202, 215, 186, 38, 41, 96, 55, 17, 246, 28))).COND_None,
          UEnums.EPropertyClass.Bool
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveBeginPlay"] = function(_ARG_0_)
    do
      __super.ReceiveBeginPlay(_ARG_0_)
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 144, 107, 143, 201, 225, 135, 61, 58, 112, 61, 56, 229, 3, 219, 85, 244, 144, 62, 191),
        U2(26, 1, 174, 60, 84, 173, 10, 236, 138, 231, 245, 14, 33, 112, 6, 22, 252, 0, 213, 28, 251, 214, 125)
      }), U1.Game:GetObjName(_ARG_0_.Object), U1.tostring(U1.Client ~= nil), U1.tostring(_ARG_0_:GetFlyEnergy())))
      _ARG_0_.bMarkRecycling = false
      _ARG_0_:AddControlEvent(_ARG_0_, U2(36, 45, 180, 48, 92, 166, 16, 162, 226, 251, 177, 45, 14, 97, 34, 22, 254, 23, 214, 33, 164, 159, 107, 129, 222, 240, 160), _ARG_0_.HandleOnMovementModeChanged, _ARG_0_)
      if not U1.Client then
        _ARG_0_:RefreshFlyEnergyTimer()
      end
      U1.Game:AdjustSkinnedMinLODForPerformance(_ARG_0_.Mesh, 2, 1, 1)
      _ARG_0_:AddControlEvent(_ARG_0_, U2(38, 44, 142, 58, 82, 162, 18, 128, 198, 241, 162, 24, 33, 104, 58, 29, 235, 63, 221, 16, 175, 135, 77, 142, 222, 234, 162, 61, 57), _ARG_0_.HandleLocalViewPlayerMountChanged, _ARG_0_)
      if U1.Client and U1.slua.isValid(_ARG_0_.Mesh) then
        _ARG_0_.Mesh:SetForceSyncCreatePSO(true)
        U1.print(U1.bWriteLog and U1.table.concat({
          U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 144, 107, 143, 201, 225, 135, 61, 58, 112, 61, 56, 229, 3, 219, 85, 130, 134, 106, 176),
          U2(6, 48, 161, 48, 98, 186, 16, 181, 236, 230, 176, 41, 57, 108, 19, 43, 214)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnOpenPawnCollision"] = function(_ARG_0_)
    do
      if not Client or not slua.isValid(_ARG_0_.Mesh) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveEndPlay"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 144, 107, 143, 201, 225, 128, 54, 57, 73, 63, 9, 240, 66, 135, 6, 241, 177, 123, 151),
        U1(26, 45, 172, 111, 20, 176)
      }), Game:GetObjName(_ARG_0_.Object), tostring(_ARG_1_)))
      _ARG_0_:StopRecycleCheckTimer()
      _ARG_0_:StopFlyEnergyCostTimer()
      _ARG_0_:StopFlyEnergyRecoverTimer()
      _ARG_0_:StopExhaustedRecoverDelayTimer()
      _ARG_0_:StopForceDestroyTimer()
      _ARG_0_:UnbindPOIRider()
      _ARG_0_:RestoreLocalCirclePainAdaptive(nil, (U1(44, 44, 166, 5, 93, 162, 7)))
      U2.__super.ReceiveEndPlay(_ARG_0_, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatAttached"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      __super.HandleSeatAttached(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
      if U1.Client then
        return
      end
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 45, 160, 157, 106, 138, 218, 215, 160, 57, 41, 88, 39, 28, 232, 1, 202, 16, 181, 195, 93, 158),
        U2(8, 48, 163, 54, 69, 166, 12, 236, 138, 231, 245, 27, 40, 104, 55, 44, 224, 2, 215, 95, 228, 128, 46, 181, 218, 229, 177, 17, 51, 125, 54, 16, 179, 71, 209)
      }), U1.Game:GetObjName(_ARG_1_), U1.tostring(_ARG_2_), U1.tostring(_ARG_3_)))
      if _ARG_2_ ~= U3.ESeatType_DriversSeat then
        return
      end
      _ARG_0_:BindPOIRider(_ARG_1_)
      if not U1.slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
        return
      end
      if _ARG_0_:GetBioVehicleMovement():IsFlying() then
        return
      end
      if _ARG_0_:GetBioVehicleMovement():IsSwimming() then
        return
      end
      if not _ARG_0_:IsAirborne() then
        return
      end
      if not _ARG_0_:CanEnterFlying() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsDrivingSeatType"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_1_ == ESeatType_DriversSeat end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopDriftOnDriverLeave"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.TryStopDrift then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 156, 126, 162, 205, 237, 163, 44, 18, 119, 23, 26, 224, 20, 199, 7, 157, 134, 127, 128),
          U1(12, 98, 176, 48, 69, 239, 94, 130, 221, 237, 134, 60, 34, 121, 7, 10, 240, 20, 198, 69, 175, 156, 122, 198, 217, 235, 176, 54, 57, 55, 115, 58, 236, 3, 209, 26, 191, 217, 59, 133)
        }), tostring(_ARG_2_)))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      __super.HandleSeatChanged(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 45, 160, 157, 106, 138, 218, 215, 160, 57, 41, 90, 59, 9, 231, 5, 199, 17, 241, 160, 118, 151),
        U2(27, 35, 161, 33, 84, 177, 68, 243, 220, 180, 153, 41, 62, 125, 16, 29, 248, 6, 230, 28, 177, 150, 52, 195, 204, 169, 251, 22, 56, 110, 0, 13, 232, 22, 246, 12, 161, 134, 36, 211),
        U2(26, 98, 142, 52, 66, 183, 45, 179, 206, 224, 156, 38, 41, 108, 59, 66, 188, 1, 159, 91, 143, 150, 121, 181, 218, 229, 177, 17, 51, 125, 54, 16, 179, 71, 209)
      }), U1.Game:GetObjName(_ARG_1_), U1.tostring(_ARG_2_), U1.tostring(_ARG_4_), U1.tostring(_ARG_3_), U1.tostring(_ARG_5_)))
      if _ARG_2_ == U3.ESeatType_DriversSeat then
        _ARG_0_:StopDriftOnDriverLeave(_ARG_1_, (U2(58, 39, 163, 33, 114, 171, 31, 184, 200, 241, 177)))
      end
      if not U1.Client and _ARG_4_ == U3.ESeatType_DriversSeat then
        _ARG_0_:BindPOIRider(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      __super.ClientHandleEnterVehicle(_ARG_0_, _ARG_1_, _ARG_2_)
      if U1.slua.isValid(_ARG_1_) then
        _ARG_0_:EnableLocalCirclePainAdaptive(_ARG_1_, (U2(44, 44, 182, 48, 67, 149, 27, 190, 198, 247, 185, 45)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      __super.ClientHandleExitVehicle(_ARG_0_, _ARG_1_, _ARG_2_)
      if U1.slua.isValid(_ARG_1_) then
        _ARG_0_:RestoreLocalCirclePainAdaptive(_ARG_1_, (U2(44, 58, 171, 33, 103, 166, 22, 191, 204, 248, 176)))
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleChangeVehicleSeat"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      __super.ClientHandleChangeVehicleSeat(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
      if U1.slua.isValid(_ARG_1_) then
        _ARG_0_:EnableLocalCirclePainAdaptive(_ARG_1_, (U2(42, 42, 163, 59, 86, 166, 40, 179, 199, 253, 182, 36, 40, 90, 38, 25, 237)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCirclePainAdaptive"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid((import((U1(58, 33, 176, 48, 84, 173, 63, 166, 223, 241, 180, 58, 44, 103, 32, 29, 202, 6, 211, 17, 168, 144, 125))).GetScreenAppearanceManager(_ARG_1_))) then
        return nil
      end
      if not slua.isValid((import((U1(58, 33, 176, 48, 84, 173, 63, 166, 223, 241, 180, 58, 44, 103, 32, 29, 202, 6, 211, 17, 168, 144, 125))).GetScreenAppearanceManager(_ARG_1_):FindAppearanceByName(_ARG_1_, U2))) then
        return nil
      end
      import((U1(58, 33, 176, 48, 84, 173, 63, 166, 223, 241, 180, 58, 44, 103, 32, 29, 202, 6, 211, 17, 168, 144, 125))).GetScreenAppearanceManager(_ARG_1_):FindAppearanceByName(_ARG_1_, U2).bEnableAdaptive = _ARG_2_
      do return import((U1(58, 33, 176, 48, 84, 173, 63, 166, 223, 241, 180, 58, 44, 103, 32, 29, 202, 6, 211, 17, 168, 144, 125))).GetScreenAppearanceManager(_ARG_1_):FindAppearanceByName(_ARG_1_, U2).bEnableAdaptive end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnableLocalCirclePainAdaptive"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.tCirclePainAdaptiveCache then
        return
      end
      if not _ARG_1_:IsLocallyControlled() then
        return
      end
      if not slua.isValid(_ARG_1_.GetPlayerControllerSafety and _ARG_1_:GetPlayerControllerSafety()) then
        return
      end
      _ARG_0_.tCirclePainAdaptiveCache = {
        uCharacter = _ARG_1_,
        uPlayerController = _ARG_1_.GetPlayerControllerSafety and _ARG_1_:GetPlayerControllerSafety(),
        bOldValue = nil
      }
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyLocalCirclePainAdaptive"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.tCirclePainAdaptiveCache or not slua.isValid(_ARG_0_.tCirclePainAdaptiveCache.uPlayerController) then
        return
      end
      if _ARG_0_:SetCirclePainAdaptive(_ARG_0_.tCirclePainAdaptiveCache.uPlayerController, true) ~= nil and _ARG_0_.tCirclePainAdaptiveCache.bOldValue == nil then
        _ARG_0_.tCirclePainAdaptiveCache.bOldValue = _ARG_0_:SetCirclePainAdaptive(_ARG_0_.tCirclePainAdaptiveCache.uPlayerController, true)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleLocalPlayerInOutBlueCircleChanged"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 45, 160, 157, 106, 138, 218, 200, 170, 59, 60, 117, 3, 4, 232, 27, 199, 7, 152, 141, 81, 131),
        U1(29, 0, 174, 32, 84, 128, 23, 164, 204, 248, 176, 11, 37, 104, 45, 31, 252, 22, 146, 7, 136, 128, 65, 147, 203, 198, 169, 45, 56, 90, 58, 26, 234, 14, 199, 79, 244, 144)
      }), tostring(_ARG_1_)))
      if not _ARG_1_ then
        return
      end
      _ARG_0_:ApplyLocalCirclePainAdaptive((U1(44, 44, 182, 48, 67, 129, 18, 163, 202, 215, 188, 58, 46, 101, 38)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RestoreLocalCirclePainAdaptive"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.tCirclePainAdaptiveCache then
        return
      end
      if slua.isValid(_ARG_1_) and _ARG_1_ ~= _ARG_0_.tCirclePainAdaptiveCache.uCharacter then
        return
      end
      _ARG_0_.tCirclePainAdaptiveCache = nil
      if not slua.isValid(_ARG_0_.tCirclePainAdaptiveCache.uPlayerController) then
        return
      end
      if _ARG_0_.tCirclePainAdaptiveCache.bOldValue == nil then
        return
      end
      do return end
      _ARG_2_ = _ENV[171]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatDetached"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      __super.HandleSeatDetached(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
      if _ARG_0_:IsDrivingSeatType(_ARG_2_) then
        _ARG_0_:StopDriftOnDriverLeave(_ARG_1_, (U1(58, 39, 163, 33, 117, 166, 10, 183, 204, 252, 176, 44)))
      end
      if U2.Client then
        return
      end
      if not U2.slua.isValid(_ARG_1_) then
        return
      end
      U2.print(U2.bWriteLog and U2.string.format(U2.table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 45, 160, 157, 106, 138, 218, 215, 160, 57, 41, 93, 54, 28, 232, 1, 202, 16, 181, 195, 93, 158),
        U1(8, 48, 163, 54, 69, 166, 12, 236, 138, 231, 245, 27, 40, 104, 55, 44, 224, 2, 215, 95, 228, 128, 46, 181, 218, 229, 177, 17, 51, 125, 54, 16, 179, 71, 209)
      }), U2.Game:GetObjName(_ARG_1_), U2.tostring(_ARG_2_), U2.tostring(_ARG_3_)))
      if _ARG_0_.uPOIRider and _ARG_0_.uPOIRider == _ARG_1_ then
      end
      if not _ARG_0_:IsFlyingMode() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1[237]
    end
  end,
  ["HandleLocalViewPlayerMountChanged"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
        Game:AdjustSkinnedMinLODForPerformance(_ARG_0_.Mesh, 1, 1, 0)
      else
        Game:AdjustSkinnedMinLODForPerformance(_ARG_0_.Mesh, 2, 1, 1)
      end
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 45, 160, 157, 106, 138, 218, 200, 170, 59, 60, 117, 5, 1, 236, 21, 242, 25, 176, 154, 123, 132),
        U1(36, 45, 183, 59, 69, 128, 22, 183, 193, 243, 176, 44, 109, 70, 33, 18, 163, 87, 193, 69, 136, 128, 67, 137, 202, 234, 177, 61, 57, 35, 118, 27)
      }), Game:GetObjName(_ARG_0_.Object), tostring(_ARG_1_)))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BindPOIRider"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_0_.uPOIRider and slua.isValid(_ARG_0_.uPOIRider) and _ARG_0_.uPOIRider == _ARG_1_ then
        _ARG_0_:RefreshPOIState()
        return
      end
      _ARG_0_:UnbindPOIRider()
      _ARG_0_.uPOIRider = _ARG_1_
      _ARG_0_:AddControlEventWithCondition(_ARG_1_, U1(38, 44, 131, 33, 69, 177, 61, 190, 206, 250, 178, 45, 8, 127, 38, 22, 237, 54, 215, 9, 164, 148, 111, 146, 218), {
        AttrName = {
          (U1(40, 48, 167, 52, 120, 135))
        }
      }, _ARG_0_.OnPOIRiderAttrChange, _ARG_0_)
      print(bWriteLog and string.format(U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 39, 168, 157, 106, 182, 240, 205, 151, 49, 57, 124, 33, 72, 219, 11, 198, 16, 163, 217, 59, 133), Game:GetObjName(_ARG_1_)))
      _ARG_0_:RefreshPOIState()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UnbindPOIRider"] = function(_ARG_0_)
    do
      if _ARG_0_.uPOIRider and slua.isValid(_ARG_0_.uPOIRider) then
        _ARG_0_:RemoveControlEvent(_ARG_0_.uPOIRider, (U1(38, 44, 131, 33, 69, 177, 61, 190, 206, 250, 178, 45, 8, 127, 38, 22, 237, 54, 215, 9, 164, 148, 111, 146, 218)))
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 48, 175, 145, 103, 136, 219, 212, 138, 17, 15, 112, 55, 13, 251, 66, 240, 28, 181, 134, 108, 204),
          U1(76, 49)
        }), Game:GetObjName(_ARG_0_.uPOIRider)))
      end
      _ARG_0_.uPOIRider = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[138]
    end
  end,
  ["OnPOIRiderAttrChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid(_ARG_1_) or _ARG_0_.uPOIRider ~= _ARG_1_ then
        return
      end
      if _ARG_2_ ~= U1(40, 48, 167, 52, 120, 135) then
        return
      end
      _ARG_0_:RefreshPOIState()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPOIRiderAreaID"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.uPOIRider) then
        return nil
      end
      if not _ARG_0_.uPOIRider.GetAttrValue then
        return nil
      end
      if not _ARG_0_.uPOIRider:GetAttrValue((U1(40, 48, 167, 52, 120, 135))) then
        return nil
      end
      do return math.floor(_ARG_0_.uPOIRider:GetAttrValue((U1(40, 48, 167, 52, 120, 135))) + 0.5) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPOIState"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_:GetPOIRiderAreaID() == nil then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPOIAreaID"] = function(_ARG_0_, _ARG_1_)
    do
      if U1.type(POIAreaID) ~= U2(29, 35, 160, 57, 84) then
        return _ARG_1_ == POIAreaID
      end
      goto lbl_27
      if _ARG_1_ == 160 then
        return true
      end
      ::lbl_27::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetInPOIArea"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if _ARG_0_.bInPOIArea == _ARG_1_ then
        return
      end
      _ARG_0_.bInPOIArea = _ARG_1_
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 164, 135, 71, 136, 239, 203, 140, 25, 47, 124, 50, 72, 235, 43, 204, 37, 158, 170, 36, 211),
        U1(26)
      }), tostring(_ARG_1_)))
      if not slua.isValid((_ARG_0_:GetBioVehicleMovement())) or not _ARG_0_:GetBioVehicleMovement().SetMovementDataType then
        return
      end
      if _ARG_1_ and _ARG_0_:GetBioVehicleMovement():SetMovementDataType(_ARG_1_ and U2.POI or U2.Normal) then
      end
      do return end
      _ARG_1_ = U1.Normal
      _ARG_0_ = _ENV[249]
    end
  end,
  ["ReportEnterPOITLog"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_0_.uPOIRider) or not _ARG_0_.uPOIRider.GetPlayerStateSafety then
        return
      end
      if not slua.isValid((_ARG_0_.uPOIRider:GetPlayerStateSafety())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddNoHurtBuff"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return false
      end
      if not _ARG_1_:AddBuffBySkill(U1.NoHurtBuffSkillID, 1, nil, 1) then
        print(bWriteLog and string.format(table.concat({
          U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 36, 165, 151, 64, 137, 247, 241, 183, 44, 31, 108, 53, 14, 169, 4, 195, 28, 189, 134, 122, 218),
          U2(73, 17, 169, 60, 93, 175, 55, 146, 149, 177, 166, 104, 14, 97, 34, 10, 248, 17, 198, 0, 179, 201, 43, 149)
        }), tostring(U1.NoHurtBuffSkillID), Game:GetObjName(_ARG_1_)))
        return false
      end
      print(bWriteLog and string.format(table.concat({
        U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 36, 165, 151, 64, 137, 247, 241, 183, 44, 31, 108, 53, 14, 169, 17, 215, 22, 178, 134, 109, 133),
        U2(69, 98, 145, 62, 88, 175, 18, 159, 235, 174, 240, 59, 109, 74, 43, 25, 235, 19, 209, 17, 164, 129, 52, 195, 204)
      }), tostring(U1.NoHurtBuffSkillID), Game:GetObjName(_ARG_1_)))
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLeaveVehicleVelocityModifier"] = function(_ARG_0_)
    do
      if _ARG_0_:IsFlyingMode() then
        return 0
      end
      do return _ARG_0_.Super:GetLeaveVehicleVelocityModifier() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearCharacterVelocity"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not Game:IsValid(_ARG_1_.STCharacterMovement) then
        return
      end
      _ARG_1_.STCharacterMovement.Velocity = FVector(0, 0, 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCharacterFalling"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return false
      end
      if not Game:IsValid(_ARG_1_.STCharacterMovement) then
        return false
      end
      do return _ARG_1_.STCharacterMovement:IsFalling() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnMovementModeChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
        return
      end
      if not slua.isValid(_ARG_0_.CapsuleComponent) then
        return
      end
      if _ARG_0_:GetBioVehicleMovement().MovementMode == U2.MOVE_Flying and _ARG_0_:IsBlockedByFlyingCapsule() then
        return
      end
      if _ARG_0_:GetBioVehicleMovement().MovementMode == U2.MOVE_Flying then
      end
      if math.abs(_ARG_0_.CapsuleComponent:GetUnscaledCapsuleRadius() - U3.FlyingCapsuleRadius) < 0.01 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsAirborne"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Object) then
        return false
      end
      if not U3.LineTraceSingle(_ARG_0_.Object, _ARG_0_:K2_GetActorLocation(), _ARG_0_:K2_GetActorLocation() - FVector(0, 0, U1.AirborneTraceLength), 6, false, slua.Array(UEnums.EPropertyClass.Object, (import((U2(70, 17, 161, 39, 88, 179, 10, 249, 234, 250, 178, 33, 35, 108, 109, 57, 250, 6, 221, 23))))), 0, import((U2(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true) then
        return true
      end
      do return _ARG_0_:K2_GetActorLocation().Z - U3.LineTraceSingle(_ARG_0_.Object, _ARG_0_:K2_GetActorLocation(), _ARG_0_:K2_GetActorLocation() - FVector(0, 0, U1.AirborneTraceLength), 6, false, slua.Array(UEnums.EPropertyClass.Object, (import((U2(70, 17, 161, 39, 88, 179, 10, 249, 234, 250, 178, 33, 35, 108, 109, 57, 250, 6, 221, 23))))), 0, import((U2(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true).Location.Z > U1.AirborneGroundDistThreshold end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanEnterFlying"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Object) then
        return true
      end
      if not _ARG_0_:CanFlyByEnergy() then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 38, 160, 157, 75, 136, 203, 225, 183, 30, 49, 96, 58, 6, 238, 66, 196, 20, 189, 144, 123, 218),
          U1(73, 44, 173, 117, 87, 175, 7, 246, 202, 250, 176, 58, 42, 112, 109, 88, 188, 1)
        }), Game:GetObjName(_ARG_0_.Object)))
        _ARG_0_:ShowFlyEnergyNotEnoughTips()
        return false
      end
      if _ARG_0_:IsBlockedByFlyingCapsule() then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 38, 160, 157, 75, 136, 203, 225, 183, 30, 49, 96, 58, 6, 238, 66, 196, 20, 189, 144, 123, 218),
          U1(73, 33, 163, 37, 66, 182, 18, 179, 143, 251, 163, 45, 63, 101, 34, 8, 233, 23, 214, 73, 225, 214, 125)
        }), Game:GetObjName(_ARG_0_.Object)))
        _ARG_0_:ShowFlyingBlockedTips()
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBlockedOverhead"] = function(_ARG_0_)
    do
      if (FlyingHeadroomTraceLength or 0) <= 0 then
        return false
      end
      if not U2.LineTraceMultiForObjects(_ARG_0_.Object, _ARG_0_:K2_GetActorLocation(), _ARG_0_:K2_GetActorLocation() + U1.FVector(0, 0, _ARG_0_.CapsuleComponent:GetScaledCapsuleHalfHeight() + (FlyingHeadroomTraceLength or 0)), _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, nil, true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0) or U2.LineTraceMultiForObjects(_ARG_0_.Object, _ARG_0_:K2_GetActorLocation(), _ARG_0_:K2_GetActorLocation() + U1.FVector(0, 0, _ARG_0_.CapsuleComponent:GetScaledCapsuleHalfHeight() + (FlyingHeadroomTraceLength or 0)), _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, nil, true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0) == nil then
        return false
      end
      goto lbl_195
      if _ARG_0_:IsFlyingBlockComponent(_ARG_0_:BuildSpaceCheckIgnoreActors().Component) then
        return true
      end
      ::lbl_195::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[52]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowFlyingBlockedTips"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not U1.FlyingBlockedTipsID then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowFlyEnergyNotEnoughTips"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not U1.FlyEnergyNotEnoughTipsID then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BuildSpaceCheckIgnoreActors"] = function(_ARG_0_)
    do
      if slua.isValid((_ARG_0_:GetVehicleSeats())) and _ARG_0_:GetVehicleSeats().SeatOccupiers then
        goto lbl_59
        ::lbl_59::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return (slua.Array(UEnums.EPropertyClass.Object, (import((U1(70, 17, 161, 39, 88, 179, 10, 249, 234, 250, 178, 33, 35, 108, 109, 57, 250, 6, 221, 23)))))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSpaceCheckObjectTypes"] = function(_ARG_0_)
    do
      do return {
        Game:ConvertToObjectType(U1.ECC_WorldStatic),
        Game:ConvertToObjectType(U1.ECC_WorldDynamic),
        Game:ConvertToObjectType(U1.ECC_Vehicle)
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsIgnorableBlockActor"] = function(_ARG_0_, _ARG_1_)
    do
      do return import((U1(62, 35, 182, 48, 67, 144, 9, 191, 194, 213, 182, 60, 34, 123))) ~= nil and Game:IsClassOf(_ARG_1_, (import((U1(62, 35, 182, 48, 67, 144, 9, 191, 194, 213, 182, 60, 34, 123))))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsComponentBlockingHorse"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return false
      end
      if not slua.isValid(_ARG_0_.CapsuleComponent) then
        return true
      end
      if _ARG_1_:GetCollisionResponseToChannel(_ARG_0_.CapsuleComponent:GetCollisionObjectType()) ~= import((U1(44, 1, 173, 57, 93, 170, 13, 191, 192, 250, 135, 45, 62, 121, 44, 22, 234, 23))).ECR_Block or _ARG_0_.CapsuleComponent:GetCollisionResponseToChannel(_ARG_1_:GetCollisionObjectType()) ~= import((U1(44, 1, 173, 57, 93, 170, 13, 191, 192, 250, 135, 45, 62, 121, 44, 22, 234, 23))).ECR_Block then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsFlyingBlockComponent"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return false
      end
      if slua.isValid((_ARG_1_:GetOwner())) and _ARG_0_:IsIgnorableBlockActor((_ARG_1_:GetOwner())) then
        return false
      end
      do return _ARG_0_:IsComponentBlockingHorse(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBlockedByFlyingCapsule"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.CapsuleComponent) then
        return false
      end
      if U1.FlyingCapsuleRadius <= 0 or _ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight() <= 0 then
        return false
      end
      if not U2.CapsuleOverlapComponents(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), U1.FlyingCapsuleRadius, _ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight(), _ARG_0_:GetSpaceCheckObjectTypes(), nil, _ARG_0_:BuildSpaceCheckIgnoreActors(), nil) or U2.CapsuleOverlapComponents(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), U1.FlyingCapsuleRadius, _ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight(), _ARG_0_:GetSpaceCheckObjectTypes(), nil, _ARG_0_:BuildSpaceCheckIgnoreActors(), nil) == nil then
        return false
      end
      goto lbl_139
      if _ARG_0_:IsFlyingBlockComponent(nil) then
        return true
      end
      ::lbl_139::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsDisplaceCheckDebugDrawEnabled"] = function(_ARG_0_)
    do
      do return DisplaceCheckDebugDraw == true or U1._G.IsEditor == true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DrawDisplaceCheckTraceDebug"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_:IsDisplaceCheckDebugDrawEnabled() then
        return
      end
      if not import((U1(58, 22, 135, 45, 69, 177, 31, 145, 206, 249, 176, 56, 33, 104, 58, 43, 237, 19, 198, 12, 162, 128))) or not import((U1(58, 22, 135, 45, 69, 177, 31, 145, 206, 249, 176, 56, 33, 104, 58, 43, 237, 19, 198, 12, 162, 128))).ClientDrawDebugLine then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DrawDisplaceCheckCapsuleDebug"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_0_:IsDisplaceCheckDebugDrawEnabled() then
        return
      end
      if not import((U1(58, 22, 135, 45, 69, 177, 31, 145, 206, 249, 176, 56, 33, 104, 58, 43, 237, 19, 198, 12, 162, 128))) or not import((U1(58, 22, 135, 45, 69, 177, 31, 145, 206, 249, 176, 56, 33, 104, 58, 43, 237, 19, 198, 12, 162, 128))).ClientDrawDebugCapsule then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HasSpaceForDisplaceAnim"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_3_ = _ARG_3_ or _ENV(33, 35, 177, 6, 65, 162, 29, 179, 233, 251, 167, 12, 36, 122, 51, 20, 248, 17, 215, 36, 175, 154, 99)
      if not (U1.slua.isValid(_ARG_0_.Object) and _ARG_2_) or _ARG_2_ <= 0 then
        return true
      end
      if not U1.slua.isValid(_ARG_0_.CapsuleComponent) then
        return true
      end
      if 0 >= _ARG_0_.CapsuleComponent:GetUnscaledCapsuleRadius() or 0 >= _ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight() then
        return true
      end
      if not _ARG_1_ then
      end
      if U4.LineTraceSingleForObjects(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), _ARG_0_.CapsuleComponent:K2_GetComponentLocation() + U3.GetForwardVector(U1.FRotator(0, _ARG_0_:K2_GetActorRotation().Yaw, 0)) * -1 * _ARG_2_, _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, U1.import((_ENV(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0) then
        if not U1.slua.isValid(U4.LineTraceSingleForObjects(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), _ARG_0_.CapsuleComponent:K2_GetComponentLocation() + U3.GetForwardVector(U1.FRotator(0, _ARG_0_:K2_GetActorRotation().Yaw, 0)) * -1 * _ARG_2_, _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, U1.import((_ENV(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0) and U4.LineTraceSingleForObjects(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), _ARG_0_.CapsuleComponent:K2_GetComponentLocation() + U3.GetForwardVector(U1.FRotator(0, _ARG_0_:K2_GetActorRotation().Yaw, 0)) * -1 * _ARG_2_, _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, U1.import((_ENV(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0).Actor or nil) or not _ARG_0_:IsIgnorableBlockActor(U4.LineTraceSingleForObjects(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), _ARG_0_.CapsuleComponent:K2_GetComponentLocation() + U3.GetForwardVector(U1.FRotator(0, _ARG_0_:K2_GetActorRotation().Yaw, 0)) * -1 * _ARG_2_, _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, U1.import((_ENV(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0) and U4.LineTraceSingleForObjects(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), _ARG_0_.CapsuleComponent:K2_GetComponentLocation() + U3.GetForwardVector(U1.FRotator(0, _ARG_0_:K2_GetActorRotation().Yaw, 0)) * -1 * _ARG_2_, _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, U1.import((_ENV(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0).Actor or nil) then
          return false
        end
      end
      if U4.CapsuleOverlapActors(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation() + U3.GetForwardVector(U1.FRotator(0, _ARG_0_:K2_GetActorRotation().Yaw, 0)) * -1 * _ARG_2_, _ARG_0_.CapsuleComponent:GetUnscaledCapsuleRadius() * (U2.DisplaceCheckCapsuleScale or 0.5), _ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight() * (U2.DisplaceCheckCapsuleScale or 0.5), _ARG_0_:GetSpaceCheckObjectTypes(), nil, _ARG_0_:BuildSpaceCheckIgnoreActors(), (U1.slua.Array(U1.UEnums.EPropertyClass.Object, (U1.import((_ENV(70, 17, 161, 39, 88, 179, 10, 249, 234, 250, 178, 33, 35, 108, 109, 57, 250, 6, 221, 23))))))) then
        goto lbl_660
        if U1.slua.isValid(_ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight() * (U2.DisplaceCheckCapsuleScale or 0.5)) and _ARG_0_:IsIgnorableBlockActor(_ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight() * (U2.DisplaceCheckCapsuleScale or 0.5)) then
        elseif U1.slua.isValid(_ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight() * (U2.DisplaceCheckCapsuleScale or 0.5)) then
          return false
        end
        ::lbl_660::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[16]
    end
  end,
  ["GetFlyEnergy"] = function(_ARG_0_)
    do
      do return _ARG_0_.fFlyEnergy or 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanFlyByEnergy"] = function(_ARG_0_)
    do
      do return _ARG_0_:GetFlyEnergy() > 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HasEnoughDashEnergy"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
      end
      do return U1.math.max(0, (DashEnergyCost or 0) - (DashEnergyNetTolerance or 0)) <= _ARG_0_:GetFlyEnergy() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CostDashEnergy"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if (U1.DashEnergyCost or 0) <= 0 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanAuthorityStartCurveMove"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return true
      end
      if _ARG_1_ ~= U1.Dash then
        return true
      end
      if not _ARG_0_:HasEnoughDashEnergy(true) then
        print(bWriteLog and string.format(table.concat({
          U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 38, 160, 157, 79, 147, 203, 236, 170, 42, 52, 109, 42, 59, 253, 3, 208, 1, 146, 150, 108, 128),
          U2(12, 15, 173, 35, 84, 227, 12, 179, 197, 241, 182, 60, 109, 77, 34, 11, 241, 94, 146, 0, 175, 150, 124, 129, 198, 164, 171, 55, 41, 57, 54, 6, 230, 23, 197, 29, 255, 195, 88, 154),
          U2(16, 7, 172, 48, 67, 164, 7, 236, 138, 231, 245, 11, 34, 122, 55, 66, 188, 1, 146, 49, 174, 159, 107, 148, 222, 234, 166, 61, 103, 60, 32)
        }), tostring(_ARG_0_:GetFlyEnergy()), tostring(U3.DashEnergyCost), tostring(U3.DashEnergyNetTolerance)))
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnAuthorityCurveMoveStart"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if _ARG_1_ == U1.Dash then
        _ARG_0_:CostDashEnergy()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnCurveMoveRejected"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 45, 160, 157, 106, 138, 218, 203, 171, 27, 40, 107, 37, 13, 196, 13, 212, 16, 131, 134, 116, 147),
        U1(10, 54, 167, 49, 17, 128, 11, 164, 217, 241, 129, 49, 61, 108, 121, 93, 234, 82, 224, 0, 171, 150, 109, 146, 218, 224, 135, 33, 18, 110, 61, 13, 251, 88, 135, 6, 241, 165, 114, 143),
        U1(44, 44, 167, 39, 86, 186, 68, 243, 220)
      }), tostring(_ARG_1_), tostring(_ARG_2_), tostring(_ARG_0_:GetFlyEnergy())))
      if _ARG_1_ == U2.Dash and _ARG_2_ and not _ARG_0_:HasEnoughDashEnergy(false) then
        _ARG_0_:ShowDashEnergyNotEnoughTips()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowDashEnergyNotEnoughTips"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not U1.DashEnergyNotEnoughTipsID then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleHPRatio"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetVehicleCommon())) then
        return U2.MaxHPRatio
      end
      if not _ARG_0_:GetVehicleCommon():GetVehicleHPMax() or _ARG_0_:GetVehicleCommon():GetVehicleHPMax() <= 0 then
        return U2.MaxHPRatio
      end
      do return math.max(0, math.min(U2.MaxHPRatio, (_ARG_0_:GetVehicleCommon():GetVehicleHP() or 0) / _ARG_0_:GetVehicleCommon():GetVehicleHPMax())) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleHPByRatio"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid((_ARG_0_:GetVehicleCommon())) then
        return
      end
      if not _ARG_0_:GetVehicleCommon():GetVehicleHPMax() or _ARG_0_:GetVehicleCommon():GetVehicleHPMax() <= 0 then
        return
      end
      _ARG_1_ = math.max(0, math.min(U2.MaxHPRatio, _ARG_1_ or U2.MaxHPRatio))
      return
    end
  end,
  ["GetMaxFlyEnergy"] = function(_ARG_0_)
    do
      do return MaxFlyEnergy end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetFlyEnergyPercent"] = function(_ARG_0_)
    do
      if MaxFlyEnergy <= 0 then
        return 0
      end
      do return U1.math.max(0, U1.math.min(1, _ARG_0_:GetFlyEnergy() / MaxFlyEnergy)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsFlyEnergyFull"] = function(_ARG_0_)
    do
      do return _ARG_0_:GetFlyEnergy() >= MaxFlyEnergy end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsFlyingMode"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
        return false
      end
      do return _ARG_0_:GetBioVehicleMovement().MovementMode == U1.MOVE_Flying end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsWalkingMode"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
        return false
      end
      do return _ARG_0_:GetBioVehicleMovement().MovementMode == U1.MOVE_Walking end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsExhaustedRecoverMode"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
        return false
      end
      do return _ARG_0_:GetBioVehicleMovement().MovementMode == U1.MOVE_Walking or _ARG_0_:GetBioVehicleMovement().MovementMode == U1.MOVE_Swimming end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HasPassenger"] = function(_ARG_0_)
    do
      if not _ARG_0_.GetVehicleSeats then
        return false
      end
      if not slua.isValid((_ARG_0_:GetVehicleSeats())) or not _ARG_0_:GetVehicleSeats().GetInUseSeatNum then
        return false
      end
      do return 0 < (_ARG_0_:GetVehicleSeats():GetInUseSeatNum() or 0) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshFlyEnergyTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_:IsFlyingMode() then
      elseif _ARG_0_.bFlyEnergyExhaustedLock then
        if _ARG_0_:IsExhaustedRecoverMode() then
        else
        end
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartExhaustedRecoverDelayTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.nExhaustedRecoverDelayTimer then
        return
      end
      if (U1.FlyEnergyExhaustedRecoverDelay or 0) <= 0 then
        return
      end
      _ARG_0_.nExhaustedRecoverDelayTimer = _ARG_0_:AddGameTimer(U1.FlyEnergyExhaustedRecoverDelay or 0, false, function()
        nExhaustedRecoverDelayTimer = nil
        _ENV:OnExhaustedRecoverDelayFinished()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopExhaustedRecoverDelayTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.nExhaustedRecoverDelayTimer then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 156, 126, 163, 199, 236, 164, 45, 46, 109, 54, 12, 219, 7, 193, 26, 167, 134, 108, 178),
          U1(12, 46, 163, 44, 101, 170, 19, 179, 221)
        }))))
        _ARG_0_:RemoveGameTimer(_ARG_0_.nExhaustedRecoverDelayTimer)
        _ARG_0_.nExhaustedRecoverDelayTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnExhaustedRecoverDelayFinished"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if not _ARG_0_:IsExhaustedRecoverMode() then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 42, 175, 182, 118, 142, 222, 241, 182, 44, 56, 125, 1, 13, 234, 13, 212, 16, 163, 167, 123, 154),
          U1(8, 59, 132, 60, 95, 170, 13, 190, 202, 240, 245, 58, 40, 125, 111, 88, 247, 29, 198, 69, 182, 146, 98, 141, 214, 234, 162, 120, 50, 107, 115, 27, 254, 11, 207, 24, 184, 141, 121)
        }))))
        return
      end
      print(bWriteLog and string.format((table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 42, 175, 182, 118, 142, 222, 241, 182, 44, 56, 125, 1, 13, 234, 13, 212, 16, 163, 167, 123, 154),
        U1(8, 59, 132, 60, 95, 170, 13, 190, 202, 240, 245, 61, 35, 101, 44, 27, 242, 82, 215, 11, 164, 129, 105, 159, 159, 246, 160, 59, 50, 111, 54, 26)
      }))))
      _ARG_0_.bFlyEnergyExhaustedLock = false
      _ARG_0_:RefreshFlyEnergyTimer()
      return
    end
  end,
  ["StartFlyEnergyCostTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.nFlyEnergyCostTimer then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 232, 188, 29, 51, 124, 33, 15, 240, 33, 205, 6, 165, 183, 119, 155),
          U1(12, 48, 226, 39, 84, 183, 82, 246, 219, 253, 184, 45, 63, 41, 34, 20, 235, 23, 211, 1, 184, 211, 107, 158, 214, 247, 177)
        }))))
        return
      end
      if _ARG_0_:GetFlyEnergy() <= 0 then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 232, 188, 29, 51, 124, 33, 15, 240, 33, 205, 6, 165, 183, 119, 155),
          U1(12, 48, 226, 48, 95, 166, 12, 177, 214, 180, 188, 59, 109, 108, 46, 8, 237, 11, 158, 69, 164, 139, 103, 146, 159, 226, 169, 33, 52, 119, 52)
        }))))
        _ARG_0_:OnFlyEnergyExhausted()
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 232, 188, 29, 51, 124, 33, 15, 240, 33, 205, 6, 165, 183, 119, 155),
        U1(12, 48, 226, 28, 95, 183, 27, 164, 217, 245, 185, 114, 104, 122, 99, 59, 246, 1, 198, 51, 160, 159, 123, 131, 133, 161, 182, 120, 27, 117, 42, 45, 231, 7, 208, 18, 168, 217, 59, 133)
      }), tostring(U2.FlyEnergyCostTimeInterval), tostring(U2.FlyEnergyCostValue), tostring(_ARG_0_:GetFlyEnergy())))
      _ARG_0_.nFlyEnergyCostTimer = _ARG_0_:AddGameTimer(U2.FlyEnergyCostTimeInterval, true, function()
        _ENV:UpdateFlyEnergyCost()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopFlyEnergyCostTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.nFlyEnergyCostTimer then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 156, 126, 160, 211, 253, 128, 54, 56, 107, 52, 17, 202, 13, 209, 1, 133, 138, 115, 147),
          U1(27, 98, 132, 57, 72, 134, 16, 179, 221, 243, 172, 114, 104, 122)
        }), tostring(_ARG_0_:GetFlyEnergy())))
        _ARG_0_:RemoveGameTimer(_ARG_0_.nFlyEnergyCostTimer)
        _ARG_0_.nFlyEnergyCostTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateFlyEnergyCost"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if not _ARG_0_:IsFlyingMode() then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 48, 177, 151, 111, 146, 218, 194, 169, 33, 24, 119, 54, 26, 238, 27, 225, 26, 162, 151, 62, 152),
          U1(6, 54, 226, 51, 93, 186, 23, 184, 200, 184, 245, 58, 40, 111, 49, 29, 234, 26, 146, 17, 168, 158, 107, 148)
        }))))
        _ARG_0_:RefreshFlyEnergyTimer()
        return
      end
      if slua.isValid((_ARG_0_:GetBioVehicleMovement())) and _ARG_0_:GetBioVehicleMovement():IsCurveMoving() then
        return
      end
      if 0 >= math.max(0, _ARG_0_:GetFlyEnergy() - U2.FlyEnergyCostValue) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartFlyEnergyRecoverTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.nFlyEnergyRecoverTimer then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 232, 188, 29, 51, 124, 33, 15, 240, 48, 199, 22, 190, 149, 123, 132),
          U1(61, 43, 175, 48, 67, 227, 12, 179, 219, 184, 245, 60, 36, 100, 38, 10, 185, 19, 222, 23, 164, 146, 106, 159, 159, 225, 189, 49, 46, 109)
        }))))
        return
      end
      if _ARG_0_:IsFlyEnergyFull() then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 232, 188, 29, 51, 124, 33, 15, 240, 48, 199, 22, 190, 149, 123, 132),
          U1(61, 43, 175, 48, 67, 227, 12, 179, 219, 184, 245, 45, 35, 108, 49, 31, 224, 82, 219, 22, 225, 149, 123, 138, 211)
        }))))
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 232, 188, 29, 51, 124, 33, 15, 240, 48, 199, 22, 190, 149, 123, 132),
        U1(61, 43, 175, 48, 67, 227, 55, 184, 219, 241, 167, 62, 44, 101, 121, 93, 234, 82, 224, 0, 162, 156, 120, 131, 205, 210, 164, 52, 40, 124, 105, 77, 250, 66, 228, 25, 168, 166, 112, 147),
        U1(27, 37, 187, 111, 20, 176)
      }), tostring(U2.FlyEnergyRecoverTimeInterval), tostring(U2.FlyEnergyRecoverValue), tostring(_ARG_0_:GetFlyEnergy())))
      _ARG_0_.nFlyEnergyRecoverTimer = _ARG_0_:AddGameTimer(U2.FlyEnergyRecoverTimeInterval, true, function()
        _ENV:UpdateFlyEnergyRecover()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopFlyEnergyRecoverTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.nFlyEnergyRecoverTimer then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 156, 126, 160, 211, 253, 128, 54, 56, 107, 52, 17, 219, 7, 193, 26, 167, 134, 108, 162),
          U1(0, 47, 167, 39, 17, 133, 18, 175, 234, 250, 176, 58, 42, 112, 121, 93, 234)
        }), tostring(_ARG_0_:GetFlyEnergy())))
        _ARG_0_:RemoveGameTimer(_ARG_0_.nFlyEnergyRecoverTimer)
        _ARG_0_.nFlyEnergyRecoverTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateFlyEnergyRecover"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_:IsFlyingMode() then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 48, 177, 151, 111, 146, 218, 194, 169, 33, 24, 119, 54, 26, 238, 27, 240, 16, 178, 140, 104, 147),
          U1(27, 98, 171, 38, 17, 165, 18, 175, 198, 250, 178, 100, 109, 123, 38, 30, 235, 23, 193, 13, 225, 135, 103, 139, 218, 246)
        }))))
        _ARG_0_:RefreshFlyEnergyTimer()
        return
      end
      if math.min(U2.MaxFlyEnergy, _ARG_0_:GetFlyEnergy() + U2.FlyEnergyRecoverValue) >= U2.MaxFlyEnergy then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetFlyEnergy"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if _ARG_0_.fFlyEnergy == _ARG_1_ then
        return
      end
      _ARG_0_.fFlyEnergy = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnFlyEnergyExhausted"] = function(_ARG_0_)
    do
      if _ARG_0_.bExitingFlyEnergy then
        return
      end
      _ARG_0_.bExitingFlyEnergy = true
      _ARG_0_.bFlyEnergyExhaustedLock = true
      _ARG_0_:StopExhaustedRecoverDelayTimer()
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 42, 175, 181, 98, 159, 250, 234, 160, 42, 58, 96, 22, 16, 225, 3, 215, 6, 165, 134, 122, 214),
        U1(47, 46, 187, 16, 95, 166, 12, 177, 214, 174, 240, 59)
      }), tostring(_ARG_0_:GetFlyEnergy())))
      _ARG_0_.bExitingFlyEnergy = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartRecycleCheckTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 237, 225, 166, 33, 62, 117, 54, 43, 225, 7, 193, 30, 133, 138, 115, 147),
        U1(27, 98, 139, 59, 69, 166, 12, 160, 206, 248, 239, 109, 62)
      }), tostring(U2.RecycleCheckInterval)))
      _ARG_0_:StopRecycleCheckTimer()
      _ARG_0_.nRecycleCheckTimer = _ARG_0_:AddGameTimer(U2.RecycleCheckInterval, true, function()
        _ENV:CheckRecycleCondition()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopRecycleCheckTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.nRecycleCheckTimer then
        print(bWriteLog and string.format((U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 156, 126, 180, 218, 231, 188, 59, 49, 124, 16, 0, 236, 1, 201, 33, 184, 142, 123, 132))))
        _ARG_0_:RemoveGameTimer(_ARG_0_.nRecycleCheckTimer)
        _ARG_0_.nRecycleCheckTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckRecycleCondition"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if not Game:IsValid(_ARG_0_.Object) then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 38, 169, 150, 109, 141, 237, 225, 166, 33, 62, 117, 54, 43, 230, 12, 198, 28, 165, 138, 113, 152),
          U1(73, 48, 167, 33, 29, 227, 23, 184, 217, 245, 185, 33, 41, 41, 44, 26, 243, 23, 209, 17)
        }))))
        _ARG_0_:StopRecycleCheckTimer()
        return
      end
      if _ARG_0_.bMarkRecycling then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 38, 169, 150, 109, 141, 237, 225, 166, 33, 62, 117, 54, 43, 230, 12, 198, 28, 165, 138, 113, 152),
          U1(73, 48, 167, 33, 29, 227, 31, 186, 221, 241, 180, 44, 52, 41, 49, 29, 250, 11, 209, 9, 168, 157, 105)
        }))))
        _ARG_0_:StopRecycleCheckTimer()
        return
      end
      if not Game:IsValid(_ARG_0_.CreatedByCharacter) then
      elseif _ARG_0_.CreatedByCharacter.IsAlive and not _ARG_0_.CreatedByCharacter:IsAlive() then
      elseif FVector.Distance(_ARG_0_:K2_GetActorLocation(), _ARG_0_.CreatedByCharacter:K2_GetActorLocation()) > U2.MaxDistToCreator then
      end
      if string.format(table.concat({
        U1(29, 45, 173, 117, 87, 162, 12, 246, 201, 230, 186, 37, 109, 106, 49, 29, 248, 6, 221, 23, 237, 211, 74, 143, 204, 240, 164, 54, 62, 124, 105, 77, 167, 83, 196, 85, 156, 130, 102, 204),
        U1(76, 108, 243, 51)
      }), FVector.Distance(_ARG_0_:K2_GetActorLocation(), _ARG_0_.CreatedByCharacter:K2_GetActorLocation()), U2.MaxDistToCreator) == nil then
        return
      end
      if true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowRecycleTips"] = function(_ARG_0_, _ARG_1_)
    do
      if Client or not _ARG_1_ then
        return
      end
      if not Game:IsValid((_ARG_0_:GetSkyHorseCreator())) or not _ARG_0_:GetSkyHorseCreator().PlayerKey then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecycleSkyHorse"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 144, 119, 133, 211, 225, 150, 51, 36, 81, 60, 26, 250, 7, 130, 80, 162, 195, 93, 132),
        U1(12, 35, 182, 48, 85, 129, 7, 149, 199, 245, 167, 41, 46, 125, 38, 10, 163, 87, 193)
      }), _ARG_0_.Object, Game:GetObjName(_ARG_0_.CreatedByCharacter)))
      if _ARG_0_.bMarkRecycling then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 144, 119, 133, 211, 225, 150, 51, 36, 81, 60, 26, 250, 7, 130, 28, 162, 195, 76, 147),
          U1(10, 59, 161, 57, 88, 173, 25, 247)
        }))))
        return
      end
      _ARG_0_:StopRecycleCheckTimer()
      if not _ARG_0_ or not Game:IsValid(_ARG_0_.Object) then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 144, 119, 133, 211, 225, 150, 51, 36, 81, 60, 26, 250, 7, 130, 28, 191, 149, 127, 154),
          U1(0, 38, 226, 58, 83, 169, 27, 181, 219)
        }))))
        return
      end
      _ARG_0_:SetEnterDistanceSq(0.0)
      if _ARG_0_.ForceExitCharacters then
        _ARG_0_:ForceExitCharacters(true)
      end
      if _ARG_0_:GetSummonFeature() then
      else
      end
      _ARG_0_.bMarkRecycling = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MulticastRPC_EnterRecycleState"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 40, 180, 159, 122, 143, 220, 229, 182, 44, 15, 73, 16, 55, 204, 12, 214, 16, 163, 177, 123, 149),
        U1(16, 33, 174, 48, 98, 183, 31, 162, 202, 180, 240, 59, 109, 107, 10, 22, 201, 30, 211, 6, 164, 178, 96, 143, 210, 190, 224, 43)
      }), Game:GetObjName(_ARG_0_.Object), tostring(_ARG_1_)))
      if Client then
        if _ARG_0_.BpRecycle then
          _ARG_0_:BpRecycle()
        end
      end
      if slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
      else
      end
      if slua.isValid((_ARG_0_:K2_GetRootComponent())) and _ARG_0_:K2_GetRootComponent().SetCollisionProfileName then
      else
      end
      if slua.isValid(_ARG_0_.HeadCapsuleComponent) and _ARG_0_.HeadCapsuleComponent.SetCollisionProfileName then
      else
      end
      if slua.isValid(_ARG_0_.Mesh) and _ARG_0_.Mesh.SetCollisionProfileName then
        _ARG_0_.bEnableCollisionOptimization = false
      else
      end
      do return end
      _ARG_1_ = U1[47]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PickDisplaceOrInPlaceAnim"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_3_ then
        return _ARG_1_
      end
      if not _ARG_2_ or _ARG_2_ == _ENV() then
        U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
          _ENV(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 53, 168, 144, 101, 162, 214, 247, 181, 52, 60, 122, 54, 39, 251, 43, 204, 37, 189, 130, 125, 147),
          _ENV(40, 44, 171, 56, 17, 230, 13, 246, 198, 250, 248, 56, 33, 104, 32, 29, 185, 19, 220, 12, 172, 211, 64, 169, 235, 164, 166, 55, 51, 127, 58, 15, 252, 16, 199, 17, 253, 195, 120, 151),
          _ENV(5, 46, 160, 52, 82, 168, 94, 162, 192, 180, 177, 33, 62, 121, 47, 25, 250, 23, 146, 4, 175, 154, 99)
        }), U1.tostring(_ARG_4_)))
        return _ARG_1_
      end
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        _ENV(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 53, 168, 144, 101, 162, 214, 247, 181, 52, 60, 122, 54, 39, 251, 43, 204, 37, 189, 130, 125, 147),
        _ENV(40, 44, 171, 56, 17, 230, 13, 246, 218, 231, 176, 104, 36, 103, 110, 8, 245, 19, 209, 0, 225, 146, 96, 143, 210, 190, 224, 43)
      }), U1.tostring(_ARG_4_), _ARG_2_))
      do return _ARG_2_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MulticastRPC_PlaySpawnAnim"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if Client then
        _ARG_0_.fClientSpawnAnimTime = U1.GetTimeSeconds(_ARG_0_.Object)
      end
      if _ARG_1_ then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlaySummonerSpawnMontage"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_2_) then
        _ARG_2_ = _ARG_0_:GetSkyHorseCreator()
      end
      if not slua.isValid(_ARG_2_) or not _ARG_2_.PlayAnimMontage then
        print(bWriteLog and table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 53, 173, 146, 119, 181, 202, 233, 168, 55, 51, 124, 33, 59, 249, 3, 213, 27, 156, 140, 112, 130),
          U1(8, 37, 167, 117, 67, 166, 10, 250, 143, 253, 187, 62, 44, 101, 42, 28, 185, 33, 199, 8, 172, 156, 96, 131, 205)
        }))
        return
      end
      if not (_ARG_1_ and U2.SummonerSpawnMontage_Air or U2.SummonerSpawnMontage_Ground) or (_ARG_1_ and U2.SummonerSpawnMontage_Air or U2.SummonerSpawnMontage_Ground) == U1() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayAnimAssetOnMesh"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_2_ = _ARG_2_ or _ENV(57, 46, 163, 44, 112, 173, 23, 187, 238, 231, 166, 45, 57, 70, 45, 53, 252, 1, 218)
      if not _ARG_1_ or _ARG_1_ == _ENV() then
        U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
          _ENV(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 64, 178, 211, 124, 131, 203, 168, 229, 54, 50, 57, 50, 6, 224, 15, 130, 22, 190, 141, 120, 159),
          _ENV(14, 55, 176, 48, 85)
        }), _ARG_2_))
        return
      end
      if not U1.slua.isValid(_ARG_0_.Mesh) then
        return
      end
      if not U1.slua.isValid(_ARG_0_.Mesh:GetAnimInstance()) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartForceDestroyTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.nForceDestroyTimer then
        return
      end
      _ARG_0_.nForceDestroyTimer = _ARG_0_:AddGameTimer(U1.RecycleForceDestroyDelay, false, function()
        nForceDestroyTimer = nil
        if not _ENV or not U1.Game:IsValid(Object) then
          return
        end
        U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
          U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 235, 183, 59, 56, 93, 54, 27, 253, 16, 205, 12, 133, 138, 115, 147),
          U2(27, 98, 164, 58, 67, 160, 27, 246, 203, 241, 166, 60, 63, 102, 58, 88, 188, 1)
        }), U1.Game:GetObjName(Object)))
        _ENV:K2_DestroyActor()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopForceDestroyTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.nForceDestroyTimer then
        _ARG_0_:RemoveGameTimer(_ARG_0_.nForceDestroyTimer)
        _ARG_0_.nForceDestroyTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSummonFeature"] = function(_ARG_0_)
    do
      if not Game:IsValid((_ARG_0_:GetSkyHorseCreator())) then
        return nil
      end
      do return _ARG_0_:GetSkyHorseCreator().SkyHorseSummonFeature end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaHandleVehicleHealthDestroy"] = function(_ARG_0_)
    do
      __super.LuaHandleVehicleHealthDestroy(_ARG_0_)
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 41, 180, 146, 70, 135, 209, 224, 169, 61, 11, 124, 59, 1, 234, 14, 199, 61, 180, 130, 114, 130),
        U2(1, 6, 167, 38, 69, 177, 17, 175, 143, 177, 166, 104, 14, 123, 38, 25, 237, 23, 214, 39, 184, 176, 102, 135, 205, 229, 166, 44, 56, 107, 105, 77, 250)
      }), U1.Game:GetObjName(_ARG_0_.Object), U1.Game:GetObjName(_ARG_0_.CreatedByCharacter)))
      if U1.Client then
        _ARG_0_:BpRecycle()
        return
      end
      if _ARG_0_.bMarkRecycling then
        U1.print(U1.bWriteLog and U1.string.format((U1.table.concat({
          U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 41, 180, 146, 70, 135, 209, 224, 169, 61, 11, 124, 59, 1, 234, 14, 199, 61, 180, 130, 114, 130),
          U2(1, 6, 167, 38, 69, 177, 17, 175, 143, 230, 176, 60, 97, 41, 34, 20, 235, 23, 211, 1, 184, 211, 124, 131, 220, 253, 166, 52, 52, 119, 52)
        }))))
        return
      end
      _ARG_0_.bMarkRecycling = true
      _ARG_0_:StopRecycleCheckTimer()
      _ARG_0_:StopFlyEnergyCostTimer()
      _ARG_0_:StopFlyEnergyRecoverTimer()
      _ARG_0_:StopExhaustedRecoverDelayTimer()
      _ARG_0_:DoSummonSkillCoolDown(_ARG_0_:GetSkyHorseCreator(), U3.DeadCDTime)
      if _ARG_0_:GetSummonFeature() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DoSummonSkillCoolDown"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      if not Game:IsValid(_ARG_1_) or not Game:IsValid(_ARG_1_.SkillManager) then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 33, 174, 160, 123, 139, 210, 235, 171, 11, 54, 112, 63, 4, 202, 13, 205, 25, 149, 140, 105, 152),
          U1(73, 48, 167, 33, 29, 227, 23, 184, 217, 245, 185, 33, 41, 41, 0, 16, 248, 0, 211, 6, 181, 150, 124, 198, 208, 246, 229, 11, 54, 112, 63, 4, 196, 3, 204, 20, 182, 134, 108, 216),
          U1(73, 1, 170, 52, 67, 162, 29, 162, 202, 230, 239, 109, 62)
        }), Game:GetObjName(_ARG_1_)))
        return
      end
      _ARG_2_ = _ARG_2_ or U2.RecycleCDTime
      if Game:IsValid(_ARG_0_.ItemHandle) and _ARG_0_.ItemHandle.SkillID and 0 < _ARG_0_.ItemHandle.SkillID then
      end
      if not _ARG_0_.ItemHandle.SkillID or 0 >= _ARG_0_.ItemHandle.SkillID then
        return
      end
      do return end
      _ARG_2_ = U1[120]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegisterSkyHorseOwner"] = function(_ARG_0_, _ARG_1_)
    do
      if Game:IsValid(_ARG_1_) then
        _ARG_0_.ItemHandle = _ARG_1_
        _ARG_0_.ItemInstanceID = _ARG_1_.DefineID.InstanceID
        if not Client then
          _ARG_0_.CreatedByCharacter = _ARG_1_.OwningCharacter
          _ARG_0_.uRepCreator = _ARG_0_.CreatedByCharacter
          _ARG_1_:SetUsing(false)
          if _ARG_0_:GetSummonFeature() then
          else
          end
        end
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 148, 103, 149, 203, 225, 183, 11, 54, 96, 27, 7, 251, 17, 199, 58, 166, 141, 123, 132),
          U1(73, 11, 182, 48, 92, 138, 16, 165, 219, 245, 187, 43, 40, 64, 7, 66, 188, 1, 146, 38, 179, 150, 111, 146, 218, 224, 135, 33, 30, 113, 50, 26, 232, 1, 214, 16, 163, 217, 59, 133)
        }), tostring(_ARG_0_.ItemInstanceID), Game:GetObjName(_ARG_0_.CreatedByCharacter)))
      else
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 148, 103, 149, 203, 225, 183, 11, 54, 96, 27, 7, 251, 17, 199, 58, 166, 141, 123, 132),
          U1(73, 48, 167, 33, 29, 227, 23, 184, 217, 245, 185, 33, 41, 41, 10, 12, 252, 31, 250, 4, 175, 151, 98, 131)
        }))))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSkyHorseCreator"] = function(_ARG_0_)
    do
      if not Client and Game:IsValid(_ARG_0_.CreatedByCharacter) then
        return _ARG_0_.CreatedByCharacter
      end
      do return _ARG_0_.uRepCreator end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDoubleClick_DriveLeft"] = function(_ARG_0_)
    do
      if _ARG_0_.TryStartDrift then
        _ARG_0_:TryStartDrift()
        _ARG_0_.VehicleSpringArm:ResetFreeCamera()
        _ARG_0_.VehicleSpringArm:ResetSmartCamera()
      end
      print(bWriteLog and string.format((table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 42, 175, 183, 97, 147, 221, 232, 160, 27, 49, 112, 48, 3, 214, 38, 208, 28, 167, 134, 82, 147),
        U1(15, 54)
      }))))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDoubleClick_DriveRight"] = function(_ARG_0_)
    do
      if _ARG_0_.TryStartDrift then
        _ARG_0_:TryStartDrift()
        _ARG_0_.VehicleSpringArm:ResetFreeCamera()
        _ARG_0_.VehicleSpringArm:ResetSmartCamera()
      end
      print(bWriteLog and string.format((table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 42, 175, 183, 97, 147, 221, 232, 160, 27, 49, 112, 48, 3, 214, 38, 208, 28, 167, 134, 76, 159),
        U1(14, 42, 182)
      }))))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDoubleClick_Land"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanCurveMove"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
        return false
      end
      if _ARG_0_:GetBioVehicleMovement():IsCurveMoving() then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanRecoverHP"] = function(_ARG_0_)
    do
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInSpawnForbidJumpTime"] = function(_ARG_0_)
    do
      if not Client then
        return false
      end
      if not _ARG_0_.fClientSpawnAnimTime then
        return false
      end
      if (U1.SpawnForbidJumpDuration or 0) <= 0 then
        return false
      end
      do return (U1.SpawnForbidJumpDuration or 0) > U2.GetTimeSeconds(_ARG_0_.Object) - _ARG_0_.fClientSpawnAnimTime end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsJumpSkillForbidden"] = function(_ARG_0_)
    do
      if _ARG_0_:IsInSpawnForbidJumpTime() then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 44, 178, 185, 123, 139, 207, 215, 174, 49, 49, 117, 21, 7, 251, 0, 203, 17, 181, 134, 112, 214),
          U1(29, 48, 183, 48, 29, 227, 23, 184, 143, 231, 165, 41, 58, 103, 99, 30, 246, 0, 208, 12, 165, 211, 100, 147, 210, 244, 229, 44, 52, 116, 54, 70, 169, 33, 206, 28, 180, 141, 106, 165),
          U1(25, 35, 181, 59, 112, 173, 23, 187, 251, 253, 184, 45, 119, 44, 48)
        }), tostring(_ARG_0_.fClientSpawnAnimTime)))
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}).MulticastRPC.MulticastRPC_PlaySpawnAnim = {
  Reliable = true,
  Params = {
    UEnums.EPropertyClass.Bool,
    import(((function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(70, 17, 161, 39, 88, 179, 10, 249, 234, 250, 178, 33, 35, 108, 109, 57, 250, 6, 221, 23))),
    UEnums.EPropertyClass.Bool,
    UEnums.EPropertyClass.Bool
  }
}
do return require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(10, 45, 175, 55, 88, 173, 27, 137, 204, 248, 180, 59, 62))).DeclareFeature(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(10, 46, 163, 38, 66)))(require((table.concat({
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(46, 35, 175, 48, 125, 182, 31, 248, 226, 251, 177, 102, 1, 96, 33, 10, 248, 0, 203, 75, 134, 146, 99, 131, 239, 232, 164, 33, 115, 79, 54, 0, 224, 1, 206, 16, 255, 171, 113, 132),
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(26, 39, 236, 29, 94, 177, 13, 179, 249, 241, 189, 33, 46, 101, 38)
}))), nil, {
  ServerRPC = {},
  ClientRPC = {},
  MulticastRPC = {},
  ["GetVehicleControlUIConfig"] = function(_ARG_0_)
    do
      do return {
        CommonUIGroup = {
          (U1(58, 41, 187, 29, 94, 177, 13, 179, 236, 251, 187, 60, 63, 102, 47, 45, 208))
        },
        DriverUIGroup = {
          (U1(43, 43, 173, 3, 84, 171, 23, 181, 195, 241, 150, 39, 35, 125, 49, 23, 245, 39, 251, 36, 180, 135, 97, 171, 208, 242, 160))
        },
        VehicleMode = 3,
        VModeKey = import((U1(44, 17, 150, 16, 73, 183, 12, 183, 249, 241, 189, 33, 46, 101, 38, 44, 224, 2, 215))).VT_CustomVehicle4
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUIConfig"] = function(_ARG_0_)
    do
      do return {
        SkyHorseControlUI = {
          moduleName = table.concat({
            U1(46, 35, 175, 48, 125, 182, 31, 248, 226, 251, 177, 102, 1, 96, 33, 10, 248, 0, 203, 75, 134, 146, 99, 131, 239, 232, 164, 33, 115, 79, 54, 0, 224, 1, 206, 16, 255, 176, 117, 143),
            U1(33, 45, 176, 38, 84, 237, 45, 189, 214, 220, 186, 58, 62, 108, 0, 23, 247, 6, 192, 10, 173, 166, 71)
          }),
          path = table.concat({
            U1(70, 5, 163, 56, 84, 236, 50, 191, 205, 230, 180, 58, 52, 38, 17, 29, 234, 93, 228, 0, 169, 154, 109, 138, 218, 247, 234, 11, 54, 96, 27, 7, 251, 17, 199, 90, 132, 170, 49, 165),
            U1(2, 59, 138, 58, 67, 176, 27, 149, 192, 250, 161, 58, 34, 101, 22, 49, 183, 33, 217, 28, 137, 156, 124, 149, 218, 199, 170, 54, 41, 107, 60, 4, 220, 43)
          }),
          isMainUI = false,
          isSingleton = true,
          zOrder = 0,
          asy = true,
          closeOnHide = false,
          uiStat = {
            name = U1(33, 45, 176, 38, 84, 128, 17, 184, 219, 230, 186, 36, 24, 64)
          },
          AndroidBackType = require((table.concat({
            U1(10, 46, 171, 48, 95, 183, 80, 165, 195, 225, 180, 102, 46, 102, 45, 30, 240, 21, 156, 38, 173, 154, 107, 136, 203, 201, 164, 59, 47, 118, 32, 70, 204, 35, 204, 17, 163, 140, 119, 146),
            U1(43, 35, 161, 62, 101, 186, 14, 179)
          }))).Ban
        }
      } end
      do return end
      _ARG_0_ = _ENV[176]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PostConstruct"] = function(_ARG_0_)
    do
      __super._PostConstruct(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ctor"] = function(_ARG_0_)
    do
      _ARG_0_.fFlyEnergy = MaxFlyEnergy
      _ARG_0_.bFlyEnergyExhaustedLock = false
      _ARG_0_.nExhaustedRecoverDelayTimer = nil
      _ARG_0_.uRepCreator = nil
      _ARG_0_.bMarkRecycling = false
      _ARG_0_.bInPOIArea = false
      _ARG_0_.uPOIRider = nil
      _ARG_0_.fClientSpawnAnimTime = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLifetimeReplicatedProps"] = function(_ARG_0_)
    do
      do return {
        {
          U1(15, 4, 174, 44, 116, 173, 27, 164, 200, 237),
          import((U1(44, 14, 171, 51, 84, 183, 23, 187, 202, 215, 186, 38, 41, 96, 55, 17, 246, 28))).COND_None,
          UEnums.EPropertyClass.Float
        },
        {
          U1(28, 16, 167, 37, 114, 177, 27, 183, 219, 251, 167),
          import((U1(44, 14, 171, 51, 84, 183, 23, 187, 202, 215, 186, 38, 41, 96, 55, 17, 246, 28))).COND_None,
          UEnums.EPropertyClass.Object
        },
        {
          U1(11, 15, 163, 39, 90, 145, 27, 181, 214, 247, 185, 33, 35, 110),
          import((U1(44, 14, 171, 51, 84, 183, 23, 187, 202, 215, 186, 38, 41, 96, 55, 17, 246, 28))).COND_None,
          UEnums.EPropertyClass.Bool
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveBeginPlay"] = function(_ARG_0_)
    do
      __super.ReceiveBeginPlay(_ARG_0_)
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 144, 107, 143, 201, 225, 135, 61, 58, 112, 61, 56, 229, 3, 219, 85, 244, 144, 62, 191),
        U2(26, 1, 174, 60, 84, 173, 10, 236, 138, 231, 245, 14, 33, 112, 6, 22, 252, 0, 213, 28, 251, 214, 125)
      }), U1.Game:GetObjName(_ARG_0_.Object), U1.tostring(U1.Client ~= nil), U1.tostring(_ARG_0_:GetFlyEnergy())))
      _ARG_0_.bMarkRecycling = false
      _ARG_0_:AddControlEvent(_ARG_0_, U2(36, 45, 180, 48, 92, 166, 16, 162, 226, 251, 177, 45, 14, 97, 34, 22, 254, 23, 214, 33, 164, 159, 107, 129, 222, 240, 160), _ARG_0_.HandleOnMovementModeChanged, _ARG_0_)
      if not U1.Client then
        _ARG_0_:RefreshFlyEnergyTimer()
      end
      U1.Game:AdjustSkinnedMinLODForPerformance(_ARG_0_.Mesh, 2, 1, 1)
      _ARG_0_:AddControlEvent(_ARG_0_, U2(38, 44, 142, 58, 82, 162, 18, 128, 198, 241, 162, 24, 33, 104, 58, 29, 235, 63, 221, 16, 175, 135, 77, 142, 222, 234, 162, 61, 57), _ARG_0_.HandleLocalViewPlayerMountChanged, _ARG_0_)
      if U1.Client and U1.slua.isValid(_ARG_0_.Mesh) then
        _ARG_0_.Mesh:SetForceSyncCreatePSO(true)
        U1.print(U1.bWriteLog and U1.table.concat({
          U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 144, 107, 143, 201, 225, 135, 61, 58, 112, 61, 56, 229, 3, 219, 85, 130, 134, 106, 176),
          U2(6, 48, 161, 48, 98, 186, 16, 181, 236, 230, 176, 41, 57, 108, 19, 43, 214)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnOpenPawnCollision"] = function(_ARG_0_)
    do
      if not Client or not slua.isValid(_ARG_0_.Mesh) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveEndPlay"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 144, 107, 143, 201, 225, 128, 54, 57, 73, 63, 9, 240, 66, 135, 6, 241, 177, 123, 151),
        U1(26, 45, 172, 111, 20, 176)
      }), Game:GetObjName(_ARG_0_.Object), tostring(_ARG_1_)))
      _ARG_0_:StopRecycleCheckTimer()
      _ARG_0_:StopFlyEnergyCostTimer()
      _ARG_0_:StopFlyEnergyRecoverTimer()
      _ARG_0_:StopExhaustedRecoverDelayTimer()
      _ARG_0_:StopForceDestroyTimer()
      _ARG_0_:UnbindPOIRider()
      _ARG_0_:RestoreLocalCirclePainAdaptive(nil, (U1(44, 44, 166, 5, 93, 162, 7)))
      U2.__super.ReceiveEndPlay(_ARG_0_, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatAttached"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      __super.HandleSeatAttached(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
      if U1.Client then
        return
      end
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 45, 160, 157, 106, 138, 218, 215, 160, 57, 41, 88, 39, 28, 232, 1, 202, 16, 181, 195, 93, 158),
        U2(8, 48, 163, 54, 69, 166, 12, 236, 138, 231, 245, 27, 40, 104, 55, 44, 224, 2, 215, 95, 228, 128, 46, 181, 218, 229, 177, 17, 51, 125, 54, 16, 179, 71, 209)
      }), U1.Game:GetObjName(_ARG_1_), U1.tostring(_ARG_2_), U1.tostring(_ARG_3_)))
      if _ARG_2_ ~= U3.ESeatType_DriversSeat then
        return
      end
      _ARG_0_:BindPOIRider(_ARG_1_)
      if not U1.slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
        return
      end
      if _ARG_0_:GetBioVehicleMovement():IsFlying() then
        return
      end
      if _ARG_0_:GetBioVehicleMovement():IsSwimming() then
        return
      end
      if not _ARG_0_:IsAirborne() then
        return
      end
      if not _ARG_0_:CanEnterFlying() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsDrivingSeatType"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_1_ == ESeatType_DriversSeat end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopDriftOnDriverLeave"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.TryStopDrift then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 156, 126, 162, 205, 237, 163, 44, 18, 119, 23, 26, 224, 20, 199, 7, 157, 134, 127, 128),
          U1(12, 98, 176, 48, 69, 239, 94, 130, 221, 237, 134, 60, 34, 121, 7, 10, 240, 20, 198, 69, 175, 156, 122, 198, 217, 235, 176, 54, 57, 55, 115, 58, 236, 3, 209, 26, 191, 217, 59, 133)
        }), tostring(_ARG_2_)))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      __super.HandleSeatChanged(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 45, 160, 157, 106, 138, 218, 215, 160, 57, 41, 90, 59, 9, 231, 5, 199, 17, 241, 160, 118, 151),
        U2(27, 35, 161, 33, 84, 177, 68, 243, 220, 180, 153, 41, 62, 125, 16, 29, 248, 6, 230, 28, 177, 150, 52, 195, 204, 169, 251, 22, 56, 110, 0, 13, 232, 22, 246, 12, 161, 134, 36, 211),
        U2(26, 98, 142, 52, 66, 183, 45, 179, 206, 224, 156, 38, 41, 108, 59, 66, 188, 1, 159, 91, 143, 150, 121, 181, 218, 229, 177, 17, 51, 125, 54, 16, 179, 71, 209)
      }), U1.Game:GetObjName(_ARG_1_), U1.tostring(_ARG_2_), U1.tostring(_ARG_4_), U1.tostring(_ARG_3_), U1.tostring(_ARG_5_)))
      if _ARG_2_ == U3.ESeatType_DriversSeat then
        _ARG_0_:StopDriftOnDriverLeave(_ARG_1_, (U2(58, 39, 163, 33, 114, 171, 31, 184, 200, 241, 177)))
      end
      if not U1.Client and _ARG_4_ == U3.ESeatType_DriversSeat then
        _ARG_0_:BindPOIRider(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      __super.ClientHandleEnterVehicle(_ARG_0_, _ARG_1_, _ARG_2_)
      if U1.slua.isValid(_ARG_1_) then
        _ARG_0_:EnableLocalCirclePainAdaptive(_ARG_1_, (U2(44, 44, 182, 48, 67, 149, 27, 190, 198, 247, 185, 45)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      __super.ClientHandleExitVehicle(_ARG_0_, _ARG_1_, _ARG_2_)
      if U1.slua.isValid(_ARG_1_) then
        _ARG_0_:RestoreLocalCirclePainAdaptive(_ARG_1_, (U2(44, 58, 171, 33, 103, 166, 22, 191, 204, 248, 176)))
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleChangeVehicleSeat"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      __super.ClientHandleChangeVehicleSeat(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
      if U1.slua.isValid(_ARG_1_) then
        _ARG_0_:EnableLocalCirclePainAdaptive(_ARG_1_, (U2(42, 42, 163, 59, 86, 166, 40, 179, 199, 253, 182, 36, 40, 90, 38, 25, 237)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCirclePainAdaptive"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid((import((U1(58, 33, 176, 48, 84, 173, 63, 166, 223, 241, 180, 58, 44, 103, 32, 29, 202, 6, 211, 17, 168, 144, 125))).GetScreenAppearanceManager(_ARG_1_))) then
        return nil
      end
      if not slua.isValid((import((U1(58, 33, 176, 48, 84, 173, 63, 166, 223, 241, 180, 58, 44, 103, 32, 29, 202, 6, 211, 17, 168, 144, 125))).GetScreenAppearanceManager(_ARG_1_):FindAppearanceByName(_ARG_1_, U2))) then
        return nil
      end
      import((U1(58, 33, 176, 48, 84, 173, 63, 166, 223, 241, 180, 58, 44, 103, 32, 29, 202, 6, 211, 17, 168, 144, 125))).GetScreenAppearanceManager(_ARG_1_):FindAppearanceByName(_ARG_1_, U2).bEnableAdaptive = _ARG_2_
      do return import((U1(58, 33, 176, 48, 84, 173, 63, 166, 223, 241, 180, 58, 44, 103, 32, 29, 202, 6, 211, 17, 168, 144, 125))).GetScreenAppearanceManager(_ARG_1_):FindAppearanceByName(_ARG_1_, U2).bEnableAdaptive end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnableLocalCirclePainAdaptive"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.tCirclePainAdaptiveCache then
        return
      end
      if not _ARG_1_:IsLocallyControlled() then
        return
      end
      if not slua.isValid(_ARG_1_.GetPlayerControllerSafety and _ARG_1_:GetPlayerControllerSafety()) then
        return
      end
      _ARG_0_.tCirclePainAdaptiveCache = {
        uCharacter = _ARG_1_,
        uPlayerController = _ARG_1_.GetPlayerControllerSafety and _ARG_1_:GetPlayerControllerSafety(),
        bOldValue = nil
      }
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyLocalCirclePainAdaptive"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.tCirclePainAdaptiveCache or not slua.isValid(_ARG_0_.tCirclePainAdaptiveCache.uPlayerController) then
        return
      end
      if _ARG_0_:SetCirclePainAdaptive(_ARG_0_.tCirclePainAdaptiveCache.uPlayerController, true) ~= nil and _ARG_0_.tCirclePainAdaptiveCache.bOldValue == nil then
        _ARG_0_.tCirclePainAdaptiveCache.bOldValue = _ARG_0_:SetCirclePainAdaptive(_ARG_0_.tCirclePainAdaptiveCache.uPlayerController, true)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleLocalPlayerInOutBlueCircleChanged"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 45, 160, 157, 106, 138, 218, 200, 170, 59, 60, 117, 3, 4, 232, 27, 199, 7, 152, 141, 81, 131),
        U1(29, 0, 174, 32, 84, 128, 23, 164, 204, 248, 176, 11, 37, 104, 45, 31, 252, 22, 146, 7, 136, 128, 65, 147, 203, 198, 169, 45, 56, 90, 58, 26, 234, 14, 199, 79, 244, 144)
      }), tostring(_ARG_1_)))
      if not _ARG_1_ then
        return
      end
      _ARG_0_:ApplyLocalCirclePainAdaptive((U1(44, 44, 182, 48, 67, 129, 18, 163, 202, 215, 188, 58, 46, 101, 38)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RestoreLocalCirclePainAdaptive"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.tCirclePainAdaptiveCache then
        return
      end
      if slua.isValid(_ARG_1_) and _ARG_1_ ~= _ARG_0_.tCirclePainAdaptiveCache.uCharacter then
        return
      end
      _ARG_0_.tCirclePainAdaptiveCache = nil
      if not slua.isValid(_ARG_0_.tCirclePainAdaptiveCache.uPlayerController) then
        return
      end
      if _ARG_0_.tCirclePainAdaptiveCache.bOldValue == nil then
        return
      end
      do return end
      _ARG_2_ = _ENV[171]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatDetached"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      __super.HandleSeatDetached(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
      if _ARG_0_:IsDrivingSeatType(_ARG_2_) then
        _ARG_0_:StopDriftOnDriverLeave(_ARG_1_, (U1(58, 39, 163, 33, 117, 166, 10, 183, 204, 252, 176, 44)))
      end
      if U2.Client then
        return
      end
      if not U2.slua.isValid(_ARG_1_) then
        return
      end
      U2.print(U2.bWriteLog and U2.string.format(U2.table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 45, 160, 157, 106, 138, 218, 215, 160, 57, 41, 93, 54, 28, 232, 1, 202, 16, 181, 195, 93, 158),
        U1(8, 48, 163, 54, 69, 166, 12, 236, 138, 231, 245, 27, 40, 104, 55, 44, 224, 2, 215, 95, 228, 128, 46, 181, 218, 229, 177, 17, 51, 125, 54, 16, 179, 71, 209)
      }), U2.Game:GetObjName(_ARG_1_), U2.tostring(_ARG_2_), U2.tostring(_ARG_3_)))
      if _ARG_0_.uPOIRider and _ARG_0_.uPOIRider == _ARG_1_ then
      end
      if not _ARG_0_:IsFlyingMode() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1[237]
    end
  end,
  ["HandleLocalViewPlayerMountChanged"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
        Game:AdjustSkinnedMinLODForPerformance(_ARG_0_.Mesh, 1, 1, 0)
      else
        Game:AdjustSkinnedMinLODForPerformance(_ARG_0_.Mesh, 2, 1, 1)
      end
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 45, 160, 157, 106, 138, 218, 200, 170, 59, 60, 117, 5, 1, 236, 21, 242, 25, 176, 154, 123, 132),
        U1(36, 45, 183, 59, 69, 128, 22, 183, 193, 243, 176, 44, 109, 70, 33, 18, 163, 87, 193, 69, 136, 128, 67, 137, 202, 234, 177, 61, 57, 35, 118, 27)
      }), Game:GetObjName(_ARG_0_.Object), tostring(_ARG_1_)))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BindPOIRider"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_0_.uPOIRider and slua.isValid(_ARG_0_.uPOIRider) and _ARG_0_.uPOIRider == _ARG_1_ then
        _ARG_0_:RefreshPOIState()
        return
      end
      _ARG_0_:UnbindPOIRider()
      _ARG_0_.uPOIRider = _ARG_1_
      _ARG_0_:AddControlEventWithCondition(_ARG_1_, U1(38, 44, 131, 33, 69, 177, 61, 190, 206, 250, 178, 45, 8, 127, 38, 22, 237, 54, 215, 9, 164, 148, 111, 146, 218), {
        AttrName = {
          (U1(40, 48, 167, 52, 120, 135))
        }
      }, _ARG_0_.OnPOIRiderAttrChange, _ARG_0_)
      print(bWriteLog and string.format(U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 39, 168, 157, 106, 182, 240, 205, 151, 49, 57, 124, 33, 72, 219, 11, 198, 16, 163, 217, 59, 133), Game:GetObjName(_ARG_1_)))
      _ARG_0_:RefreshPOIState()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UnbindPOIRider"] = function(_ARG_0_)
    do
      if _ARG_0_.uPOIRider and slua.isValid(_ARG_0_.uPOIRider) then
        _ARG_0_:RemoveControlEvent(_ARG_0_.uPOIRider, (U1(38, 44, 131, 33, 69, 177, 61, 190, 206, 250, 178, 45, 8, 127, 38, 22, 237, 54, 215, 9, 164, 148, 111, 146, 218)))
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 48, 175, 145, 103, 136, 219, 212, 138, 17, 15, 112, 55, 13, 251, 66, 240, 28, 181, 134, 108, 204),
          U1(76, 49)
        }), Game:GetObjName(_ARG_0_.uPOIRider)))
      end
      _ARG_0_.uPOIRider = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[138]
    end
  end,
  ["OnPOIRiderAttrChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid(_ARG_1_) or _ARG_0_.uPOIRider ~= _ARG_1_ then
        return
      end
      if _ARG_2_ ~= U1(40, 48, 167, 52, 120, 135) then
        return
      end
      _ARG_0_:RefreshPOIState()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPOIRiderAreaID"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.uPOIRider) then
        return nil
      end
      if not _ARG_0_.uPOIRider.GetAttrValue then
        return nil
      end
      if not _ARG_0_.uPOIRider:GetAttrValue((U1(40, 48, 167, 52, 120, 135))) then
        return nil
      end
      do return math.floor(_ARG_0_.uPOIRider:GetAttrValue((U1(40, 48, 167, 52, 120, 135))) + 0.5) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPOIState"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_:GetPOIRiderAreaID() == nil then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPOIAreaID"] = function(_ARG_0_, _ARG_1_)
    do
      if U1.type(POIAreaID) ~= U2(29, 35, 160, 57, 84) then
        return _ARG_1_ == POIAreaID
      end
      goto lbl_27
      if _ARG_1_ == 160 then
        return true
      end
      ::lbl_27::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetInPOIArea"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if _ARG_0_.bInPOIArea == _ARG_1_ then
        return
      end
      _ARG_0_.bInPOIArea = _ARG_1_
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 164, 135, 71, 136, 239, 203, 140, 25, 47, 124, 50, 72, 235, 43, 204, 37, 158, 170, 36, 211),
        U1(26)
      }), tostring(_ARG_1_)))
      if not slua.isValid((_ARG_0_:GetBioVehicleMovement())) or not _ARG_0_:GetBioVehicleMovement().SetMovementDataType then
        return
      end
      if _ARG_1_ and _ARG_0_:GetBioVehicleMovement():SetMovementDataType(_ARG_1_ and U2.POI or U2.Normal) then
      end
      do return end
      _ARG_1_ = U1.Normal
      _ARG_0_ = _ENV[249]
    end
  end,
  ["ReportEnterPOITLog"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_0_.uPOIRider) or not _ARG_0_.uPOIRider.GetPlayerStateSafety then
        return
      end
      if not slua.isValid((_ARG_0_.uPOIRider:GetPlayerStateSafety())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddNoHurtBuff"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return false
      end
      if not _ARG_1_:AddBuffBySkill(U1.NoHurtBuffSkillID, 1, nil, 1) then
        print(bWriteLog and string.format(table.concat({
          U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 36, 165, 151, 64, 137, 247, 241, 183, 44, 31, 108, 53, 14, 169, 4, 195, 28, 189, 134, 122, 218),
          U2(73, 17, 169, 60, 93, 175, 55, 146, 149, 177, 166, 104, 14, 97, 34, 10, 248, 17, 198, 0, 179, 201, 43, 149)
        }), tostring(U1.NoHurtBuffSkillID), Game:GetObjName(_ARG_1_)))
        return false
      end
      print(bWriteLog and string.format(table.concat({
        U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 36, 165, 151, 64, 137, 247, 241, 183, 44, 31, 108, 53, 14, 169, 17, 215, 22, 178, 134, 109, 133),
        U2(69, 98, 145, 62, 88, 175, 18, 159, 235, 174, 240, 59, 109, 74, 43, 25, 235, 19, 209, 17, 164, 129, 52, 195, 204)
      }), tostring(U1.NoHurtBuffSkillID), Game:GetObjName(_ARG_1_)))
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLeaveVehicleVelocityModifier"] = function(_ARG_0_)
    do
      if _ARG_0_:IsFlyingMode() then
        return 0
      end
      do return _ARG_0_.Super:GetLeaveVehicleVelocityModifier() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearCharacterVelocity"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not Game:IsValid(_ARG_1_.STCharacterMovement) then
        return
      end
      _ARG_1_.STCharacterMovement.Velocity = FVector(0, 0, 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCharacterFalling"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return false
      end
      if not Game:IsValid(_ARG_1_.STCharacterMovement) then
        return false
      end
      do return _ARG_1_.STCharacterMovement:IsFalling() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnMovementModeChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
        return
      end
      if not slua.isValid(_ARG_0_.CapsuleComponent) then
        return
      end
      if _ARG_0_:GetBioVehicleMovement().MovementMode == U2.MOVE_Flying and _ARG_0_:IsBlockedByFlyingCapsule() then
        return
      end
      if _ARG_0_:GetBioVehicleMovement().MovementMode == U2.MOVE_Flying then
      end
      if math.abs(_ARG_0_.CapsuleComponent:GetUnscaledCapsuleRadius() - U3.FlyingCapsuleRadius) < 0.01 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsAirborne"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Object) then
        return false
      end
      if not U3.LineTraceSingle(_ARG_0_.Object, _ARG_0_:K2_GetActorLocation(), _ARG_0_:K2_GetActorLocation() - FVector(0, 0, U1.AirborneTraceLength), 6, false, slua.Array(UEnums.EPropertyClass.Object, (import((U2(70, 17, 161, 39, 88, 179, 10, 249, 234, 250, 178, 33, 35, 108, 109, 57, 250, 6, 221, 23))))), 0, import((U2(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true) then
        return true
      end
      do return _ARG_0_:K2_GetActorLocation().Z - U3.LineTraceSingle(_ARG_0_.Object, _ARG_0_:K2_GetActorLocation(), _ARG_0_:K2_GetActorLocation() - FVector(0, 0, U1.AirborneTraceLength), 6, false, slua.Array(UEnums.EPropertyClass.Object, (import((U2(70, 17, 161, 39, 88, 179, 10, 249, 234, 250, 178, 33, 35, 108, 109, 57, 250, 6, 221, 23))))), 0, import((U2(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true).Location.Z > U1.AirborneGroundDistThreshold end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanEnterFlying"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Object) then
        return true
      end
      if not _ARG_0_:CanFlyByEnergy() then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 38, 160, 157, 75, 136, 203, 225, 183, 30, 49, 96, 58, 6, 238, 66, 196, 20, 189, 144, 123, 218),
          U1(73, 44, 173, 117, 87, 175, 7, 246, 202, 250, 176, 58, 42, 112, 109, 88, 188, 1)
        }), Game:GetObjName(_ARG_0_.Object)))
        _ARG_0_:ShowFlyEnergyNotEnoughTips()
        return false
      end
      if _ARG_0_:IsBlockedByFlyingCapsule() then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 38, 160, 157, 75, 136, 203, 225, 183, 30, 49, 96, 58, 6, 238, 66, 196, 20, 189, 144, 123, 218),
          U1(73, 33, 163, 37, 66, 182, 18, 179, 143, 251, 163, 45, 63, 101, 34, 8, 233, 23, 214, 73, 225, 214, 125)
        }), Game:GetObjName(_ARG_0_.Object)))
        _ARG_0_:ShowFlyingBlockedTips()
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBlockedOverhead"] = function(_ARG_0_)
    do
      if (FlyingHeadroomTraceLength or 0) <= 0 then
        return false
      end
      if not U2.LineTraceMultiForObjects(_ARG_0_.Object, _ARG_0_:K2_GetActorLocation(), _ARG_0_:K2_GetActorLocation() + U1.FVector(0, 0, _ARG_0_.CapsuleComponent:GetScaledCapsuleHalfHeight() + (FlyingHeadroomTraceLength or 0)), _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, nil, true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0) or U2.LineTraceMultiForObjects(_ARG_0_.Object, _ARG_0_:K2_GetActorLocation(), _ARG_0_:K2_GetActorLocation() + U1.FVector(0, 0, _ARG_0_.CapsuleComponent:GetScaledCapsuleHalfHeight() + (FlyingHeadroomTraceLength or 0)), _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, nil, true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0) == nil then
        return false
      end
      goto lbl_195
      if _ARG_0_:IsFlyingBlockComponent(_ARG_0_:BuildSpaceCheckIgnoreActors().Component) then
        return true
      end
      ::lbl_195::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[52]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowFlyingBlockedTips"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not U1.FlyingBlockedTipsID then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowFlyEnergyNotEnoughTips"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not U1.FlyEnergyNotEnoughTipsID then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BuildSpaceCheckIgnoreActors"] = function(_ARG_0_)
    do
      if slua.isValid((_ARG_0_:GetVehicleSeats())) and _ARG_0_:GetVehicleSeats().SeatOccupiers then
        goto lbl_59
        ::lbl_59::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return (slua.Array(UEnums.EPropertyClass.Object, (import((U1(70, 17, 161, 39, 88, 179, 10, 249, 234, 250, 178, 33, 35, 108, 109, 57, 250, 6, 221, 23)))))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSpaceCheckObjectTypes"] = function(_ARG_0_)
    do
      do return {
        Game:ConvertToObjectType(U1.ECC_WorldStatic),
        Game:ConvertToObjectType(U1.ECC_WorldDynamic),
        Game:ConvertToObjectType(U1.ECC_Vehicle)
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsIgnorableBlockActor"] = function(_ARG_0_, _ARG_1_)
    do
      do return import((U1(62, 35, 182, 48, 67, 144, 9, 191, 194, 213, 182, 60, 34, 123))) ~= nil and Game:IsClassOf(_ARG_1_, (import((U1(62, 35, 182, 48, 67, 144, 9, 191, 194, 213, 182, 60, 34, 123))))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsComponentBlockingHorse"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return false
      end
      if not slua.isValid(_ARG_0_.CapsuleComponent) then
        return true
      end
      if _ARG_1_:GetCollisionResponseToChannel(_ARG_0_.CapsuleComponent:GetCollisionObjectType()) ~= import((U1(44, 1, 173, 57, 93, 170, 13, 191, 192, 250, 135, 45, 62, 121, 44, 22, 234, 23))).ECR_Block or _ARG_0_.CapsuleComponent:GetCollisionResponseToChannel(_ARG_1_:GetCollisionObjectType()) ~= import((U1(44, 1, 173, 57, 93, 170, 13, 191, 192, 250, 135, 45, 62, 121, 44, 22, 234, 23))).ECR_Block then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsFlyingBlockComponent"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return false
      end
      if slua.isValid((_ARG_1_:GetOwner())) and _ARG_0_:IsIgnorableBlockActor((_ARG_1_:GetOwner())) then
        return false
      end
      do return _ARG_0_:IsComponentBlockingHorse(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBlockedByFlyingCapsule"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.CapsuleComponent) then
        return false
      end
      if U1.FlyingCapsuleRadius <= 0 or _ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight() <= 0 then
        return false
      end
      if not U2.CapsuleOverlapComponents(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), U1.FlyingCapsuleRadius, _ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight(), _ARG_0_:GetSpaceCheckObjectTypes(), nil, _ARG_0_:BuildSpaceCheckIgnoreActors(), nil) or U2.CapsuleOverlapComponents(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), U1.FlyingCapsuleRadius, _ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight(), _ARG_0_:GetSpaceCheckObjectTypes(), nil, _ARG_0_:BuildSpaceCheckIgnoreActors(), nil) == nil then
        return false
      end
      goto lbl_139
      if _ARG_0_:IsFlyingBlockComponent(nil) then
        return true
      end
      ::lbl_139::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsDisplaceCheckDebugDrawEnabled"] = function(_ARG_0_)
    do
      do return DisplaceCheckDebugDraw == true or U1._G.IsEditor == true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DrawDisplaceCheckTraceDebug"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_:IsDisplaceCheckDebugDrawEnabled() then
        return
      end
      if not import((U1(58, 22, 135, 45, 69, 177, 31, 145, 206, 249, 176, 56, 33, 104, 58, 43, 237, 19, 198, 12, 162, 128))) or not import((U1(58, 22, 135, 45, 69, 177, 31, 145, 206, 249, 176, 56, 33, 104, 58, 43, 237, 19, 198, 12, 162, 128))).ClientDrawDebugLine then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DrawDisplaceCheckCapsuleDebug"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_0_:IsDisplaceCheckDebugDrawEnabled() then
        return
      end
      if not import((U1(58, 22, 135, 45, 69, 177, 31, 145, 206, 249, 176, 56, 33, 104, 58, 43, 237, 19, 198, 12, 162, 128))) or not import((U1(58, 22, 135, 45, 69, 177, 31, 145, 206, 249, 176, 56, 33, 104, 58, 43, 237, 19, 198, 12, 162, 128))).ClientDrawDebugCapsule then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HasSpaceForDisplaceAnim"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_3_ = _ARG_3_ or _ENV(33, 35, 177, 6, 65, 162, 29, 179, 233, 251, 167, 12, 36, 122, 51, 20, 248, 17, 215, 36, 175, 154, 99)
      if not (U1.slua.isValid(_ARG_0_.Object) and _ARG_2_) or _ARG_2_ <= 0 then
        return true
      end
      if not U1.slua.isValid(_ARG_0_.CapsuleComponent) then
        return true
      end
      if 0 >= _ARG_0_.CapsuleComponent:GetUnscaledCapsuleRadius() or 0 >= _ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight() then
        return true
      end
      if not _ARG_1_ then
      end
      if U4.LineTraceSingleForObjects(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), _ARG_0_.CapsuleComponent:K2_GetComponentLocation() + U3.GetForwardVector(U1.FRotator(0, _ARG_0_:K2_GetActorRotation().Yaw, 0)) * -1 * _ARG_2_, _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, U1.import((_ENV(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0) then
        if not U1.slua.isValid(U4.LineTraceSingleForObjects(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), _ARG_0_.CapsuleComponent:K2_GetComponentLocation() + U3.GetForwardVector(U1.FRotator(0, _ARG_0_:K2_GetActorRotation().Yaw, 0)) * -1 * _ARG_2_, _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, U1.import((_ENV(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0) and U4.LineTraceSingleForObjects(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), _ARG_0_.CapsuleComponent:K2_GetComponentLocation() + U3.GetForwardVector(U1.FRotator(0, _ARG_0_:K2_GetActorRotation().Yaw, 0)) * -1 * _ARG_2_, _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, U1.import((_ENV(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0).Actor or nil) or not _ARG_0_:IsIgnorableBlockActor(U4.LineTraceSingleForObjects(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), _ARG_0_.CapsuleComponent:K2_GetComponentLocation() + U3.GetForwardVector(U1.FRotator(0, _ARG_0_:K2_GetActorRotation().Yaw, 0)) * -1 * _ARG_2_, _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, U1.import((_ENV(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0) and U4.LineTraceSingleForObjects(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation(), _ARG_0_.CapsuleComponent:K2_GetComponentLocation() + U3.GetForwardVector(U1.FRotator(0, _ARG_0_:K2_GetActorRotation().Yaw, 0)) * -1 * _ARG_2_, _ARG_0_:GetSpaceCheckObjectTypes(), false, _ARG_0_:BuildSpaceCheckIgnoreActors(), 0, U1.import((_ENV(33, 43, 182, 7, 84, 176, 11, 186, 219)))(), true, U1.FLinearColor.Red, U1.FLinearColor.Green, 0).Actor or nil) then
          return false
        end
      end
      if U4.CapsuleOverlapActors(_ARG_0_.Object, _ARG_0_.CapsuleComponent:K2_GetComponentLocation() + U3.GetForwardVector(U1.FRotator(0, _ARG_0_:K2_GetActorRotation().Yaw, 0)) * -1 * _ARG_2_, _ARG_0_.CapsuleComponent:GetUnscaledCapsuleRadius() * (U2.DisplaceCheckCapsuleScale or 0.5), _ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight() * (U2.DisplaceCheckCapsuleScale or 0.5), _ARG_0_:GetSpaceCheckObjectTypes(), nil, _ARG_0_:BuildSpaceCheckIgnoreActors(), (U1.slua.Array(U1.UEnums.EPropertyClass.Object, (U1.import((_ENV(70, 17, 161, 39, 88, 179, 10, 249, 234, 250, 178, 33, 35, 108, 109, 57, 250, 6, 221, 23))))))) then
        goto lbl_660
        if U1.slua.isValid(_ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight() * (U2.DisplaceCheckCapsuleScale or 0.5)) and _ARG_0_:IsIgnorableBlockActor(_ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight() * (U2.DisplaceCheckCapsuleScale or 0.5)) then
        elseif U1.slua.isValid(_ARG_0_.CapsuleComponent:GetUnscaledCapsuleHalfHeight() * (U2.DisplaceCheckCapsuleScale or 0.5)) then
          return false
        end
        ::lbl_660::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[16]
    end
  end,
  ["GetFlyEnergy"] = function(_ARG_0_)
    do
      do return _ARG_0_.fFlyEnergy or 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanFlyByEnergy"] = function(_ARG_0_)
    do
      do return _ARG_0_:GetFlyEnergy() > 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HasEnoughDashEnergy"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
      end
      do return U1.math.max(0, (DashEnergyCost or 0) - (DashEnergyNetTolerance or 0)) <= _ARG_0_:GetFlyEnergy() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CostDashEnergy"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if (U1.DashEnergyCost or 0) <= 0 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanAuthorityStartCurveMove"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return true
      end
      if _ARG_1_ ~= U1.Dash then
        return true
      end
      if not _ARG_0_:HasEnoughDashEnergy(true) then
        print(bWriteLog and string.format(table.concat({
          U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 38, 160, 157, 79, 147, 203, 236, 170, 42, 52, 109, 42, 59, 253, 3, 208, 1, 146, 150, 108, 128),
          U2(12, 15, 173, 35, 84, 227, 12, 179, 197, 241, 182, 60, 109, 77, 34, 11, 241, 94, 146, 0, 175, 150, 124, 129, 198, 164, 171, 55, 41, 57, 54, 6, 230, 23, 197, 29, 255, 195, 88, 154),
          U2(16, 7, 172, 48, 67, 164, 7, 236, 138, 231, 245, 11, 34, 122, 55, 66, 188, 1, 146, 49, 174, 159, 107, 148, 222, 234, 166, 61, 103, 60, 32)
        }), tostring(_ARG_0_:GetFlyEnergy()), tostring(U3.DashEnergyCost), tostring(U3.DashEnergyNetTolerance)))
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnAuthorityCurveMoveStart"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if _ARG_1_ == U1.Dash then
        _ARG_0_:CostDashEnergy()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnCurveMoveRejected"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 45, 160, 157, 106, 138, 218, 203, 171, 27, 40, 107, 37, 13, 196, 13, 212, 16, 131, 134, 116, 147),
        U1(10, 54, 167, 49, 17, 128, 11, 164, 217, 241, 129, 49, 61, 108, 121, 93, 234, 82, 224, 0, 171, 150, 109, 146, 218, 224, 135, 33, 18, 110, 61, 13, 251, 88, 135, 6, 241, 165, 114, 143),
        U1(44, 44, 167, 39, 86, 186, 68, 243, 220)
      }), tostring(_ARG_1_), tostring(_ARG_2_), tostring(_ARG_0_:GetFlyEnergy())))
      if _ARG_1_ == U2.Dash and _ARG_2_ and not _ARG_0_:HasEnoughDashEnergy(false) then
        _ARG_0_:ShowDashEnergyNotEnoughTips()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowDashEnergyNotEnoughTips"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not U1.DashEnergyNotEnoughTipsID then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleHPRatio"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetVehicleCommon())) then
        return U2.MaxHPRatio
      end
      if not _ARG_0_:GetVehicleCommon():GetVehicleHPMax() or _ARG_0_:GetVehicleCommon():GetVehicleHPMax() <= 0 then
        return U2.MaxHPRatio
      end
      do return math.max(0, math.min(U2.MaxHPRatio, (_ARG_0_:GetVehicleCommon():GetVehicleHP() or 0) / _ARG_0_:GetVehicleCommon():GetVehicleHPMax())) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleHPByRatio"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid((_ARG_0_:GetVehicleCommon())) then
        return
      end
      if not _ARG_0_:GetVehicleCommon():GetVehicleHPMax() or _ARG_0_:GetVehicleCommon():GetVehicleHPMax() <= 0 then
        return
      end
      _ARG_1_ = math.max(0, math.min(U2.MaxHPRatio, _ARG_1_ or U2.MaxHPRatio))
      return
    end
  end,
  ["GetMaxFlyEnergy"] = function(_ARG_0_)
    do
      do return MaxFlyEnergy end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetFlyEnergyPercent"] = function(_ARG_0_)
    do
      if MaxFlyEnergy <= 0 then
        return 0
      end
      do return U1.math.max(0, U1.math.min(1, _ARG_0_:GetFlyEnergy() / MaxFlyEnergy)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsFlyEnergyFull"] = function(_ARG_0_)
    do
      do return _ARG_0_:GetFlyEnergy() >= MaxFlyEnergy end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsFlyingMode"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
        return false
      end
      do return _ARG_0_:GetBioVehicleMovement().MovementMode == U1.MOVE_Flying end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsWalkingMode"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
        return false
      end
      do return _ARG_0_:GetBioVehicleMovement().MovementMode == U1.MOVE_Walking end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsExhaustedRecoverMode"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
        return false
      end
      do return _ARG_0_:GetBioVehicleMovement().MovementMode == U1.MOVE_Walking or _ARG_0_:GetBioVehicleMovement().MovementMode == U1.MOVE_Swimming end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HasPassenger"] = function(_ARG_0_)
    do
      if not _ARG_0_.GetVehicleSeats then
        return false
      end
      if not slua.isValid((_ARG_0_:GetVehicleSeats())) or not _ARG_0_:GetVehicleSeats().GetInUseSeatNum then
        return false
      end
      do return 0 < (_ARG_0_:GetVehicleSeats():GetInUseSeatNum() or 0) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshFlyEnergyTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_:IsFlyingMode() then
      elseif _ARG_0_.bFlyEnergyExhaustedLock then
        if _ARG_0_:IsExhaustedRecoverMode() then
        else
        end
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartExhaustedRecoverDelayTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.nExhaustedRecoverDelayTimer then
        return
      end
      if (U1.FlyEnergyExhaustedRecoverDelay or 0) <= 0 then
        return
      end
      _ARG_0_.nExhaustedRecoverDelayTimer = _ARG_0_:AddGameTimer(U1.FlyEnergyExhaustedRecoverDelay or 0, false, function()
        nExhaustedRecoverDelayTimer = nil
        _ENV:OnExhaustedRecoverDelayFinished()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopExhaustedRecoverDelayTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.nExhaustedRecoverDelayTimer then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 156, 126, 163, 199, 236, 164, 45, 46, 109, 54, 12, 219, 7, 193, 26, 167, 134, 108, 178),
          U1(12, 46, 163, 44, 101, 170, 19, 179, 221)
        }))))
        _ARG_0_:RemoveGameTimer(_ARG_0_.nExhaustedRecoverDelayTimer)
        _ARG_0_.nExhaustedRecoverDelayTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnExhaustedRecoverDelayFinished"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if not _ARG_0_:IsExhaustedRecoverMode() then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 42, 175, 182, 118, 142, 222, 241, 182, 44, 56, 125, 1, 13, 234, 13, 212, 16, 163, 167, 123, 154),
          U1(8, 59, 132, 60, 95, 170, 13, 190, 202, 240, 245, 58, 40, 125, 111, 88, 247, 29, 198, 69, 182, 146, 98, 141, 214, 234, 162, 120, 50, 107, 115, 27, 254, 11, 207, 24, 184, 141, 121)
        }))))
        return
      end
      print(bWriteLog and string.format((table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 42, 175, 182, 118, 142, 222, 241, 182, 44, 56, 125, 1, 13, 234, 13, 212, 16, 163, 167, 123, 154),
        U1(8, 59, 132, 60, 95, 170, 13, 190, 202, 240, 245, 61, 35, 101, 44, 27, 242, 82, 215, 11, 164, 129, 105, 159, 159, 246, 160, 59, 50, 111, 54, 26)
      }))))
      _ARG_0_.bFlyEnergyExhaustedLock = false
      _ARG_0_:RefreshFlyEnergyTimer()
      return
    end
  end,
  ["StartFlyEnergyCostTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.nFlyEnergyCostTimer then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 232, 188, 29, 51, 124, 33, 15, 240, 33, 205, 6, 165, 183, 119, 155),
          U1(12, 48, 226, 39, 84, 183, 82, 246, 219, 253, 184, 45, 63, 41, 34, 20, 235, 23, 211, 1, 184, 211, 107, 158, 214, 247, 177)
        }))))
        return
      end
      if _ARG_0_:GetFlyEnergy() <= 0 then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 232, 188, 29, 51, 124, 33, 15, 240, 33, 205, 6, 165, 183, 119, 155),
          U1(12, 48, 226, 48, 95, 166, 12, 177, 214, 180, 188, 59, 109, 108, 46, 8, 237, 11, 158, 69, 164, 139, 103, 146, 159, 226, 169, 33, 52, 119, 52)
        }))))
        _ARG_0_:OnFlyEnergyExhausted()
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 232, 188, 29, 51, 124, 33, 15, 240, 33, 205, 6, 165, 183, 119, 155),
        U1(12, 48, 226, 28, 95, 183, 27, 164, 217, 245, 185, 114, 104, 122, 99, 59, 246, 1, 198, 51, 160, 159, 123, 131, 133, 161, 182, 120, 27, 117, 42, 45, 231, 7, 208, 18, 168, 217, 59, 133)
      }), tostring(U2.FlyEnergyCostTimeInterval), tostring(U2.FlyEnergyCostValue), tostring(_ARG_0_:GetFlyEnergy())))
      _ARG_0_.nFlyEnergyCostTimer = _ARG_0_:AddGameTimer(U2.FlyEnergyCostTimeInterval, true, function()
        _ENV:UpdateFlyEnergyCost()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopFlyEnergyCostTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.nFlyEnergyCostTimer then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 156, 126, 160, 211, 253, 128, 54, 56, 107, 52, 17, 202, 13, 209, 1, 133, 138, 115, 147),
          U1(27, 98, 132, 57, 72, 134, 16, 179, 221, 243, 172, 114, 104, 122)
        }), tostring(_ARG_0_:GetFlyEnergy())))
        _ARG_0_:RemoveGameTimer(_ARG_0_.nFlyEnergyCostTimer)
        _ARG_0_.nFlyEnergyCostTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateFlyEnergyCost"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if not _ARG_0_:IsFlyingMode() then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 48, 177, 151, 111, 146, 218, 194, 169, 33, 24, 119, 54, 26, 238, 27, 225, 26, 162, 151, 62, 152),
          U1(6, 54, 226, 51, 93, 186, 23, 184, 200, 184, 245, 58, 40, 111, 49, 29, 234, 26, 146, 17, 168, 158, 107, 148)
        }))))
        _ARG_0_:RefreshFlyEnergyTimer()
        return
      end
      if slua.isValid((_ARG_0_:GetBioVehicleMovement())) and _ARG_0_:GetBioVehicleMovement():IsCurveMoving() then
        return
      end
      if 0 >= math.max(0, _ARG_0_:GetFlyEnergy() - U2.FlyEnergyCostValue) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartFlyEnergyRecoverTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.nFlyEnergyRecoverTimer then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 232, 188, 29, 51, 124, 33, 15, 240, 48, 199, 22, 190, 149, 123, 132),
          U1(61, 43, 175, 48, 67, 227, 12, 179, 219, 184, 245, 60, 36, 100, 38, 10, 185, 19, 222, 23, 164, 146, 106, 159, 159, 225, 189, 49, 46, 109)
        }))))
        return
      end
      if _ARG_0_:IsFlyEnergyFull() then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 232, 188, 29, 51, 124, 33, 15, 240, 48, 199, 22, 190, 149, 123, 132),
          U1(61, 43, 175, 48, 67, 227, 12, 179, 219, 184, 245, 45, 35, 108, 49, 31, 224, 82, 219, 22, 225, 149, 123, 138, 211)
        }))))
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 232, 188, 29, 51, 124, 33, 15, 240, 48, 199, 22, 190, 149, 123, 132),
        U1(61, 43, 175, 48, 67, 227, 55, 184, 219, 241, 167, 62, 44, 101, 121, 93, 234, 82, 224, 0, 162, 156, 120, 131, 205, 210, 164, 52, 40, 124, 105, 77, 250, 66, 228, 25, 168, 166, 112, 147),
        U1(27, 37, 187, 111, 20, 176)
      }), tostring(U2.FlyEnergyRecoverTimeInterval), tostring(U2.FlyEnergyRecoverValue), tostring(_ARG_0_:GetFlyEnergy())))
      _ARG_0_.nFlyEnergyRecoverTimer = _ARG_0_:AddGameTimer(U2.FlyEnergyRecoverTimeInterval, true, function()
        _ENV:UpdateFlyEnergyRecover()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopFlyEnergyRecoverTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.nFlyEnergyRecoverTimer then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 156, 126, 160, 211, 253, 128, 54, 56, 107, 52, 17, 219, 7, 193, 26, 167, 134, 108, 162),
          U1(0, 47, 167, 39, 17, 133, 18, 175, 234, 250, 176, 58, 42, 112, 121, 93, 234)
        }), tostring(_ARG_0_:GetFlyEnergy())))
        _ARG_0_:RemoveGameTimer(_ARG_0_.nFlyEnergyRecoverTimer)
        _ARG_0_.nFlyEnergyRecoverTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateFlyEnergyRecover"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_:IsFlyingMode() then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 48, 177, 151, 111, 146, 218, 194, 169, 33, 24, 119, 54, 26, 238, 27, 240, 16, 178, 140, 104, 147),
          U1(27, 98, 171, 38, 17, 165, 18, 175, 198, 250, 178, 100, 109, 123, 38, 30, 235, 23, 193, 13, 225, 135, 103, 139, 218, 246)
        }))))
        _ARG_0_:RefreshFlyEnergyTimer()
        return
      end
      if math.min(U2.MaxFlyEnergy, _ARG_0_:GetFlyEnergy() + U2.FlyEnergyRecoverValue) >= U2.MaxFlyEnergy then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetFlyEnergy"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if _ARG_0_.fFlyEnergy == _ARG_1_ then
        return
      end
      _ARG_0_.fFlyEnergy = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnFlyEnergyExhausted"] = function(_ARG_0_)
    do
      if _ARG_0_.bExitingFlyEnergy then
        return
      end
      _ARG_0_.bExitingFlyEnergy = true
      _ARG_0_.bFlyEnergyExhaustedLock = true
      _ARG_0_:StopExhaustedRecoverDelayTimer()
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 42, 175, 181, 98, 159, 250, 234, 160, 42, 58, 96, 22, 16, 225, 3, 215, 6, 165, 134, 122, 214),
        U1(47, 46, 187, 16, 95, 166, 12, 177, 214, 174, 240, 59)
      }), tostring(_ARG_0_:GetFlyEnergy())))
      _ARG_0_.bExitingFlyEnergy = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartRecycleCheckTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 237, 225, 166, 33, 62, 117, 54, 43, 225, 7, 193, 30, 133, 138, 115, 147),
        U1(27, 98, 139, 59, 69, 166, 12, 160, 206, 248, 239, 109, 62)
      }), tostring(U2.RecycleCheckInterval)))
      _ARG_0_:StopRecycleCheckTimer()
      _ARG_0_.nRecycleCheckTimer = _ARG_0_:AddGameTimer(U2.RecycleCheckInterval, true, function()
        _ENV:CheckRecycleCondition()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopRecycleCheckTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.nRecycleCheckTimer then
        print(bWriteLog and string.format((U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 156, 126, 180, 218, 231, 188, 59, 49, 124, 16, 0, 236, 1, 201, 33, 184, 142, 123, 132))))
        _ARG_0_:RemoveGameTimer(_ARG_0_.nRecycleCheckTimer)
        _ARG_0_.nRecycleCheckTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckRecycleCondition"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if not Game:IsValid(_ARG_0_.Object) then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 38, 169, 150, 109, 141, 237, 225, 166, 33, 62, 117, 54, 43, 230, 12, 198, 28, 165, 138, 113, 152),
          U1(73, 48, 167, 33, 29, 227, 23, 184, 217, 245, 185, 33, 41, 41, 44, 26, 243, 23, 209, 17)
        }))))
        _ARG_0_:StopRecycleCheckTimer()
        return
      end
      if _ARG_0_.bMarkRecycling then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 38, 169, 150, 109, 141, 237, 225, 166, 33, 62, 117, 54, 43, 230, 12, 198, 28, 165, 138, 113, 152),
          U1(73, 48, 167, 33, 29, 227, 31, 186, 221, 241, 180, 44, 52, 41, 49, 29, 250, 11, 209, 9, 168, 157, 105)
        }))))
        _ARG_0_:StopRecycleCheckTimer()
        return
      end
      if not Game:IsValid(_ARG_0_.CreatedByCharacter) then
      elseif _ARG_0_.CreatedByCharacter.IsAlive and not _ARG_0_.CreatedByCharacter:IsAlive() then
      elseif FVector.Distance(_ARG_0_:K2_GetActorLocation(), _ARG_0_.CreatedByCharacter:K2_GetActorLocation()) > U2.MaxDistToCreator then
      end
      if string.format(table.concat({
        U1(29, 45, 173, 117, 87, 162, 12, 246, 201, 230, 186, 37, 109, 106, 49, 29, 248, 6, 221, 23, 237, 211, 74, 143, 204, 240, 164, 54, 62, 124, 105, 77, 167, 83, 196, 85, 156, 130, 102, 204),
        U1(76, 108, 243, 51)
      }), FVector.Distance(_ARG_0_:K2_GetActorLocation(), _ARG_0_.CreatedByCharacter:K2_GetActorLocation()), U2.MaxDistToCreator) == nil then
        return
      end
      if true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowRecycleTips"] = function(_ARG_0_, _ARG_1_)
    do
      if Client or not _ARG_1_ then
        return
      end
      if not Game:IsValid((_ARG_0_:GetSkyHorseCreator())) or not _ARG_0_:GetSkyHorseCreator().PlayerKey then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecycleSkyHorse"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 144, 119, 133, 211, 225, 150, 51, 36, 81, 60, 26, 250, 7, 130, 80, 162, 195, 93, 132),
        U1(12, 35, 182, 48, 85, 129, 7, 149, 199, 245, 167, 41, 46, 125, 38, 10, 163, 87, 193)
      }), _ARG_0_.Object, Game:GetObjName(_ARG_0_.CreatedByCharacter)))
      if _ARG_0_.bMarkRecycling then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 144, 119, 133, 211, 225, 150, 51, 36, 81, 60, 26, 250, 7, 130, 28, 162, 195, 76, 147),
          U1(10, 59, 161, 57, 88, 173, 25, 247)
        }))))
        return
      end
      _ARG_0_:StopRecycleCheckTimer()
      if not _ARG_0_ or not Game:IsValid(_ARG_0_.Object) then
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 144, 119, 133, 211, 225, 150, 51, 36, 81, 60, 26, 250, 7, 130, 28, 191, 149, 127, 154),
          U1(0, 38, 226, 58, 83, 169, 27, 181, 219)
        }))))
        return
      end
      _ARG_0_:SetEnterDistanceSq(0.0)
      if _ARG_0_.ForceExitCharacters then
        _ARG_0_:ForceExitCharacters(true)
      end
      if _ARG_0_:GetSummonFeature() then
      else
      end
      _ARG_0_.bMarkRecycling = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MulticastRPC_EnterRecycleState"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 40, 180, 159, 122, 143, 220, 229, 182, 44, 15, 73, 16, 55, 204, 12, 214, 16, 163, 177, 123, 149),
        U1(16, 33, 174, 48, 98, 183, 31, 162, 202, 180, 240, 59, 109, 107, 10, 22, 201, 30, 211, 6, 164, 178, 96, 143, 210, 190, 224, 43)
      }), Game:GetObjName(_ARG_0_.Object), tostring(_ARG_1_)))
      if Client then
        if _ARG_0_.BpRecycle then
          _ARG_0_:BpRecycle()
        end
      end
      if slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
      else
      end
      if slua.isValid((_ARG_0_:K2_GetRootComponent())) and _ARG_0_:K2_GetRootComponent().SetCollisionProfileName then
      else
      end
      if slua.isValid(_ARG_0_.HeadCapsuleComponent) and _ARG_0_.HeadCapsuleComponent.SetCollisionProfileName then
      else
      end
      if slua.isValid(_ARG_0_.Mesh) and _ARG_0_.Mesh.SetCollisionProfileName then
        _ARG_0_.bEnableCollisionOptimization = false
      else
      end
      do return end
      _ARG_1_ = U1[47]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PickDisplaceOrInPlaceAnim"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_3_ then
        return _ARG_1_
      end
      if not _ARG_2_ or _ARG_2_ == _ENV() then
        U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
          _ENV(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 53, 168, 144, 101, 162, 214, 247, 181, 52, 60, 122, 54, 39, 251, 43, 204, 37, 189, 130, 125, 147),
          _ENV(40, 44, 171, 56, 17, 230, 13, 246, 198, 250, 248, 56, 33, 104, 32, 29, 185, 19, 220, 12, 172, 211, 64, 169, 235, 164, 166, 55, 51, 127, 58, 15, 252, 16, 199, 17, 253, 195, 120, 151),
          _ENV(5, 46, 160, 52, 82, 168, 94, 162, 192, 180, 177, 33, 62, 121, 47, 25, 250, 23, 146, 4, 175, 154, 99)
        }), U1.tostring(_ARG_4_)))
        return _ARG_1_
      end
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        _ENV(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 53, 168, 144, 101, 162, 214, 247, 181, 52, 60, 122, 54, 39, 251, 43, 204, 37, 189, 130, 125, 147),
        _ENV(40, 44, 171, 56, 17, 230, 13, 246, 218, 231, 176, 104, 36, 103, 110, 8, 245, 19, 209, 0, 225, 146, 96, 143, 210, 190, 224, 43)
      }), U1.tostring(_ARG_4_), _ARG_2_))
      do return _ARG_2_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MulticastRPC_PlaySpawnAnim"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if Client then
        _ARG_0_.fClientSpawnAnimTime = U1.GetTimeSeconds(_ARG_0_.Object)
      end
      if _ARG_1_ then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlaySummonerSpawnMontage"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_2_) then
        _ARG_2_ = _ARG_0_:GetSkyHorseCreator()
      end
      if not slua.isValid(_ARG_2_) or not _ARG_2_.PlayAnimMontage then
        print(bWriteLog and table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 53, 173, 146, 119, 181, 202, 233, 168, 55, 51, 124, 33, 59, 249, 3, 213, 27, 156, 140, 112, 130),
          U1(8, 37, 167, 117, 67, 166, 10, 250, 143, 253, 187, 62, 44, 101, 42, 28, 185, 33, 199, 8, 172, 156, 96, 131, 205)
        }))
        return
      end
      if not (_ARG_1_ and U2.SummonerSpawnMontage_Air or U2.SummonerSpawnMontage_Ground) or (_ARG_1_ and U2.SummonerSpawnMontage_Air or U2.SummonerSpawnMontage_Ground) == U1() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayAnimAssetOnMesh"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_2_ = _ARG_2_ or _ENV(57, 46, 163, 44, 112, 173, 23, 187, 238, 231, 166, 45, 57, 70, 45, 53, 252, 1, 218)
      if not _ARG_1_ or _ARG_1_ == _ENV() then
        U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
          _ENV(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 64, 178, 211, 124, 131, 203, 168, 229, 54, 50, 57, 50, 6, 224, 15, 130, 22, 190, 141, 120, 159),
          _ENV(14, 55, 176, 48, 85)
        }), _ARG_2_))
        return
      end
      if not U1.slua.isValid(_ARG_0_.Mesh) then
        return
      end
      if not U1.slua.isValid(_ARG_0_.Mesh:GetAnimInstance()) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartForceDestroyTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.nForceDestroyTimer then
        return
      end
      _ARG_0_.nForceDestroyTimer = _ARG_0_:AddGameTimer(U1.RecycleForceDestroyDelay, false, function()
        nForceDestroyTimer = nil
        if not _ENV or not U1.Game:IsValid(Object) then
          return
        end
        U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
          U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 54, 181, 146, 124, 146, 249, 235, 183, 59, 56, 93, 54, 27, 253, 16, 205, 12, 133, 138, 115, 147),
          U2(27, 98, 164, 58, 67, 160, 27, 246, 203, 241, 166, 60, 63, 102, 58, 88, 188, 1)
        }), U1.Game:GetObjName(Object)))
        _ENV:K2_DestroyActor()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopForceDestroyTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.nForceDestroyTimer then
        _ARG_0_:RemoveGameTimer(_ARG_0_.nForceDestroyTimer)
        _ARG_0_.nForceDestroyTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSummonFeature"] = function(_ARG_0_)
    do
      if not Game:IsValid((_ARG_0_:GetSkyHorseCreator())) then
        return nil
      end
      do return _ARG_0_:GetSkyHorseCreator().SkyHorseSummonFeature end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaHandleVehicleHealthDestroy"] = function(_ARG_0_)
    do
      __super.LuaHandleVehicleHealthDestroy(_ARG_0_)
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 41, 180, 146, 70, 135, 209, 224, 169, 61, 11, 124, 59, 1, 234, 14, 199, 61, 180, 130, 114, 130),
        U2(1, 6, 167, 38, 69, 177, 17, 175, 143, 177, 166, 104, 14, 123, 38, 25, 237, 23, 214, 39, 184, 176, 102, 135, 205, 229, 166, 44, 56, 107, 105, 77, 250)
      }), U1.Game:GetObjName(_ARG_0_.Object), U1.Game:GetObjName(_ARG_0_.CreatedByCharacter)))
      if U1.Client then
        _ARG_0_:BpRecycle()
        return
      end
      if _ARG_0_.bMarkRecycling then
        U1.print(U1.bWriteLog and U1.string.format((U1.table.concat({
          U2(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 41, 180, 146, 70, 135, 209, 224, 169, 61, 11, 124, 59, 1, 234, 14, 199, 61, 180, 130, 114, 130),
          U2(1, 6, 167, 38, 69, 177, 17, 175, 143, 230, 176, 60, 97, 41, 34, 20, 235, 23, 211, 1, 184, 211, 124, 131, 220, 253, 166, 52, 52, 119, 52)
        }))))
        return
      end
      _ARG_0_.bMarkRecycling = true
      _ARG_0_:StopRecycleCheckTimer()
      _ARG_0_:StopFlyEnergyCostTimer()
      _ARG_0_:StopFlyEnergyRecoverTimer()
      _ARG_0_:StopExhaustedRecoverDelayTimer()
      _ARG_0_:DoSummonSkillCoolDown(_ARG_0_:GetSkyHorseCreator(), U3.DeadCDTime)
      if _ARG_0_:GetSummonFeature() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DoSummonSkillCoolDown"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      if not Game:IsValid(_ARG_1_) or not Game:IsValid(_ARG_1_.SkillManager) then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 33, 174, 160, 123, 139, 210, 235, 171, 11, 54, 112, 63, 4, 202, 13, 205, 25, 149, 140, 105, 152),
          U1(73, 48, 167, 33, 29, 227, 23, 184, 217, 245, 185, 33, 41, 41, 0, 16, 248, 0, 211, 6, 181, 150, 124, 198, 208, 246, 229, 11, 54, 112, 63, 4, 196, 3, 204, 20, 182, 134, 108, 216),
          U1(73, 1, 170, 52, 67, 162, 29, 162, 202, 230, 239, 109, 62)
        }), Game:GetObjName(_ARG_1_)))
        return
      end
      _ARG_2_ = _ARG_2_ or U2.RecycleCDTime
      if Game:IsValid(_ARG_0_.ItemHandle) and _ARG_0_.ItemHandle.SkillID and 0 < _ARG_0_.ItemHandle.SkillID then
      end
      if not _ARG_0_.ItemHandle.SkillID or 0 >= _ARG_0_.ItemHandle.SkillID then
        return
      end
      do return end
      _ARG_2_ = U1[120]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegisterSkyHorseOwner"] = function(_ARG_0_, _ARG_1_)
    do
      if Game:IsValid(_ARG_1_) then
        _ARG_0_.ItemHandle = _ARG_1_
        _ARG_0_.ItemInstanceID = _ARG_1_.DefineID.InstanceID
        if not Client then
          _ARG_0_.CreatedByCharacter = _ARG_1_.OwningCharacter
          _ARG_0_.uRepCreator = _ARG_0_.CreatedByCharacter
          _ARG_1_:SetUsing(false)
          if _ARG_0_:GetSummonFeature() then
          else
          end
        end
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 148, 103, 149, 203, 225, 183, 11, 54, 96, 27, 7, 251, 17, 199, 58, 166, 141, 123, 132),
          U1(73, 11, 182, 48, 92, 138, 16, 165, 219, 245, 187, 43, 40, 64, 7, 66, 188, 1, 146, 38, 179, 150, 111, 146, 218, 224, 135, 33, 30, 113, 50, 26, 232, 1, 214, 16, 163, 217, 59, 133)
        }), tostring(_ARG_0_.ItemInstanceID), Game:GetObjName(_ARG_0_.CreatedByCharacter)))
      else
        print(bWriteLog and string.format((table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 55, 164, 148, 103, 149, 203, 225, 183, 11, 54, 96, 27, 7, 251, 17, 199, 58, 166, 141, 123, 132),
          U1(73, 48, 167, 33, 29, 227, 23, 184, 217, 245, 185, 33, 41, 41, 10, 12, 252, 31, 250, 4, 175, 151, 98, 131)
        }))))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSkyHorseCreator"] = function(_ARG_0_)
    do
      if not Client and Game:IsValid(_ARG_0_.CreatedByCharacter) then
        return _ARG_0_.CreatedByCharacter
      end
      do return _ARG_0_.uRepCreator end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDoubleClick_DriveLeft"] = function(_ARG_0_)
    do
      if _ARG_0_.TryStartDrift then
        _ARG_0_:TryStartDrift()
        _ARG_0_.VehicleSpringArm:ResetFreeCamera()
        _ARG_0_.VehicleSpringArm:ResetSmartCamera()
      end
      print(bWriteLog and string.format((table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 42, 175, 183, 97, 147, 221, 232, 160, 27, 49, 112, 48, 3, 214, 38, 208, 28, 167, 134, 82, 147),
        U1(15, 54)
      }))))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDoubleClick_DriveRight"] = function(_ARG_0_)
    do
      if _ARG_0_.TryStartDrift then
        _ARG_0_:TryStartDrift()
        _ARG_0_.VehicleSpringArm:ResetFreeCamera()
        _ARG_0_.VehicleSpringArm:ResetSmartCamera()
      end
      print(bWriteLog and string.format((table.concat({
        U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 42, 175, 183, 97, 147, 221, 232, 160, 27, 49, 112, 48, 3, 214, 38, 208, 28, 167, 134, 76, 159),
        U1(14, 42, 182)
      }))))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDoubleClick_Land"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanCurveMove"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetBioVehicleMovement())) then
        return false
      end
      if _ARG_0_:GetBioVehicleMovement():IsCurveMoving() then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanRecoverHP"] = function(_ARG_0_)
    do
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInSpawnForbidJumpTime"] = function(_ARG_0_)
    do
      if not Client then
        return false
      end
      if not _ARG_0_.fClientSpawnAnimTime then
        return false
      end
      if (U1.SpawnForbidJumpDuration or 0) <= 0 then
        return false
      end
      do return (U1.SpawnForbidJumpDuration or 0) > U2.GetTimeSeconds(_ARG_0_.Object) - _ARG_0_.fClientSpawnAnimTime end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsJumpSkillForbidden"] = function(_ARG_0_)
    do
      if _ARG_0_:IsInSpawnForbidJumpTime() then
        print(bWriteLog and string.format(table.concat({
          U1(50, 17, 169, 44, 121, 172, 12, 165, 202, 201, 134, 35, 52, 65, 44, 10, 234, 23, 136, 44, 178, 185, 123, 139, 207, 215, 174, 49, 49, 117, 21, 7, 251, 0, 203, 17, 181, 134, 112, 214),
          U1(29, 48, 183, 48, 29, 227, 23, 184, 143, 231, 165, 41, 58, 103, 99, 30, 246, 0, 208, 12, 165, 211, 100, 147, 210, 244, 229, 44, 52, 116, 54, 70, 169, 33, 206, 28, 180, 141, 106, 165),
          U1(25, 35, 181, 59, 112, 173, 23, 187, 251, 253, 184, 45, 119, 44, 48)
        }), tostring(_ARG_0_.fClientSpawnAnimTime)))
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}), {
  {
    SkyHorseDash = table.concat({
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(46, 35, 175, 48, 125, 182, 31, 248, 226, 251, 177, 102, 1, 96, 33, 10, 248, 0, 203, 75, 134, 146, 99, 131, 239, 232, 164, 33, 115, 79, 54, 0, 224, 1, 206, 16, 255, 176, 117, 143),
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(33, 45, 176, 38, 84, 237, 45, 189, 214, 220, 186, 58, 62, 108, 7, 25, 234, 26)
    })
  }
}, ((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(58, 41, 187, 29, 94, 177, 13, 179))) end
return
