do return require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(26, 31, 84, 172, 52)))(require((table.concat({
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(62, 18, 88, 186, 11, 12, 249, 157, 99, 194, 62, 132, 189, 3, 152, 124, 167, 14, 42, 139, 194, 37, 141, 173, 103, 198, 33, 130, 151, 15, 142, 108, 244, 125, 6, 138, 197, 42, 129, 224),
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(13, 22, 88, 157, 38, 10, 253)
}))), nil, {
  ["_PostConstruct"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInit"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 167, 237, 125, 221, 42, 133))
      _ARG_0_.ShootingUISpecialLayer = {
        U1(58, 6, 70, 171, 40, 20, 203, 216, 77, 207, 63, 173, 159, 21, 143, 107),
        U1(58, 18, 91, 169, 38, 10, 200, 210, 74, 198, 63, 190, 189, 25, 153, 109, 230, 46, 18, 138, 214, 57, 135, 237, 97, 250),
        U1(58, 6, 70, 171, 40, 20, 241, 201, 65, 252, 7, 137, 140, 3, 157, 73, 229, 54, 54),
        U1(58, 6, 70, 171, 40, 20, 203, 219, 75, 204, 39, 179, 155, 8),
        U1(45, 27, 71, 176, 48, 45, 241, 222, 65, 234, 61, 135, 145),
        U1(49, 26, 70, 171, 40, 11, 241, 208, 69, 207, 29, 132, 137, 31),
        U1(49, 26, 70, 171, 40, 11, 241, 208, 69, 207, 29, 132, 137, 31, 169, 120, 231, 53, 36, 156, 231, 40, 134, 230, 88),
        (U1(55, 22, 66, 189, 46, 28, 223, 198, 77, 199, 54, 162, 159, 2, 156, 120, 250))
      }
      _ARG_0_.UIContainerDynamicWidget = {
        table.concat({
          U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 37, 129, 230, 90, 199, 109, 189, 135, 23, 159, 39, 208, 61, 50, 158, 202, 60, 180, 250),
          U1(18, 22, 96, 150, 5, 41)
        }),
        table.concat({
          U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 37, 129, 230, 90, 199, 109, 189, 135, 23, 159, 39, 208, 61, 50, 158, 202, 60, 179, 250),
          U1(21, 31, 124, 188, 40, 23, 205, 250, 102, 243)
        }),
        table.concat({
          U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 178, 5, 136, 107, 232, 49, 60, 193, 244, 37, 129, 230, 90, 199, 109, 188, 135, 18, 147, 93, 239, 125, 24, 150, 201, 48, 172, 229),
          U1(59, 18, 91, 177, 34, 11, 204, 218, 84, 208, 6, 168)
        }),
        table.concat({
          U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 37, 129, 230, 90, 199, 109, 184, 128, 59, 155, 100, 252, 6, 28, 209, 240, 60, 153, 248),
          U1(55, 22, 65, 168, 40, 11, 243, 250, 71, 204, 61)
        }),
        table.concat({
          U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 37, 129, 230, 90, 199, 109, 186, 135, 16, 150, 64, 247, 53, 58, 171, 206, 41, 139, 189),
          U1(50, 26, 89, 179, 14, 23, 254, 220, 109, 215, 54, 140)
        }),
        table.concat({
          U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 37, 129, 230, 90, 199, 109, 186, 135, 16, 150, 64, 247, 53, 58, 171, 206, 41, 139, 189),
          U1(53, 22, 83, 171, 12, 16, 244, 223, 109, 205, 53, 142, 183, 24, 143, 116)
        }),
        table.concat({
          U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 178, 5, 136, 107, 232, 49, 60, 193, 244, 37, 129, 230, 90, 199, 109, 180, 130, 25, 140, 104, 237, 60, 39, 209, 226, 53, 157, 229),
          U1(24, 7, 90, 173, 21, 28, 233, 198, 65, 208, 39, 180, 183)
        }),
        (table.concat({
          U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 178, 5, 136, 107, 232, 49, 60, 193, 244, 37, 129, 230, 90, 199, 109, 180, 130, 25, 140, 104, 237, 60, 39, 209, 226, 53, 157, 229),
          U1(24, 7, 90, 173, 10, 24, 241, 221, 113, 234)
        }))
      }
      _ARG_0_.ExcludedUIName = {
        SingleTrain_Target_Item_UIBP_C = true,
        DanceTogether_UIBP_C = true,
        PlanPH_Party_Dance_Status_UIBP_C = true
      }
      if Client then
        _ARG_0_.TopLevelUIList = {
          UIManager.UI_Config_InGame.GameOverCountDown_UIBP,
          UIManager.UI_Config_InGame.MVPStatueMainRT,
          UIManager.UI_Config_InGame.CrossbowChangeBulletUI,
          UIManager.UI_Config_InGame.StoneGateInteractiveUI,
          UIManager.UI_Config_InGame.SingleReviveCountUI,
          UIManager.UI_Config_InGame.TeammateReviveStateIcon,
          UIManager.UI_Config_InGame.KingKongEffect
        }
        _ARG_0_._photoWearOriginIndex = nil
        _ARG_0_._photoWearPendingTargets = {}
        _ARG_0_._photoWearRestoreRetried = false
        _ARG_0_._photoWearSessionEnded = false
        U2.AddSelfPlayerControllerEvent(_ARG_0_, U1(54, 29, 101, 179, 38, 0, 253, 193, 103, 203, 50, 143, 153, 9, 189, 124, 232, 49, 44, 129, 208, 13, 135, 237, 81), _ARG_0_.OnPlayerChangeWearingDoneForPhoto, _ARG_0_)
      end
      _ARG_0_.PawnStateDisable = {
        U3.GunADS,
        U3.Dying,
        U3.Dead,
        U3.SwitchPP,
        U3.Skill,
        U3.InPlane,
        U3.InParachute,
        U3.Variation,
        U3.FlyVariation,
        U3.CarryBack,
        U3.BeCarriedBack,
        U3.AirAttackLocator,
        U3.ControlUnmannedVehicle,
        U3.RemoteControlVehicle,
        U3.InActivityActor,
        U3.DriveMovePlatForm,
        U3.Build,
        U3.Fishing,
        U3.InZipline,
        U3.Arrest
      }
      _ARG_0_.MinCameraLenth = 220
      _ARG_0_.MaxCameraLenth = 2000
      _ARG_0_.CacheTargetArmLenth = -1
      _ARG_0_.CacheVehicleTargetArmLenth = -1
      _ARG_0_.CahceJoyStickopacity = -1
      _ARG_0_.AttrName = U1(60, 30, 90, 171, 34, 41, 244, 210, 93, 241, 50, 149, 155)
      _ARG_0_:AddCommonEvent(EVENTTYPE_PLAYEREVENT_CHARACTER, EVENTID_PLAYEREVENT_SMARTCAMERA_INIT, _ARG_0_.OnSmartCameraAdd, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_PLAYEREVENT_CHARACTER, EVENTID_PLAYEREVENT_SMARTCAMERA_END, _ARG_0_.OnSmartCameraRemove, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_APPLICATION_ACTIVE_STATE, EVENTID_APPLICATION_REACTIVATED_EX, _ARG_0_.OnSmartCamerainterrupt, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_APPLICATION_ACTIVE_STATE, EVENTID_APPLICATION_DEACTIVATED_EX, _ARG_0_.OnSmartCamerainterrupt, _ARG_0_)
      _ARG_0_.bIsPhotoGrapherMode = false
      _ARG_0_.bHideAllPets = false
      _ARG_0_.EmoteIDList = {}
      _ARG_0_.CurrentTemplateType = U4.Player
      _ARG_0_.bIsSkySphereOn = false
      _ARG_0_.LastPlayRate = 1
      _ARG_0_.EmotePlayRateLimit = 0.001
      _ARG_0_.NeedRportTimes = {
        U5.PhotographerOptype.TakePhoto
      }
      _ARG_0_.UseRecord = {}
      _ARG_0_.TransparentTime = 5
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_DataDefine"] = function(_ARG_0_)
    do
      do return {TemplateID = -1} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUIShow"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid((require((table.concat({
        U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
        U1(22, 31, 70)
      }))).GetMainControlPanelTochButton())) then
        return
      end
      if not SubsystemMgr:Get((U1(45, 1, 84, 177, 52, 9, 249, 193, 65, 205, 39, 180, 183, 33, 133, 125, 236, 16, 48, 141, 196, 48, 155, 247, 81, 222))) then
        return
      end
      goto lbl_348
      if _ARG_3_ and 84 == _ARG_3_.moduleName and _ARG_3_.path then
        if string.find(_ARG_3_.path, (U1(92, 93))) then
        end
        if string.sub(_ARG_3_.path, string.find(_ARG_3_.path, (U1(92, 93))) + 1) then
          if slua.isValid((require((table.concat({
            U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
            U1(22, 31, 70)
          }))).GetMainControlPanelTochButton():GetParent())) then
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        end
      end
      ::lbl_348::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_WriteCameraRecordData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_2_ then
        printf((table.concat({
          U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 183, 212, 70, 218, 55, 148, 173, 29, 151, 108, 235, 50, 7, 154, 196, 54, 138, 247),
          U1(61, 18, 65, 190, 103, 34, 202, 214, 71, 204, 33, 133, 186, 14, 141, 68, 169, 5, 4, 166, 251, 115, 200, 241, 81, 208, 44, 131, 138, 56, 155, 125, 248, 115, 60, 140, 135, 55, 145, 255)
        })))
        return false
      end
      if not import((U1(58, 18, 88, 186, 53, 24, 202, 214, 71, 204, 33, 133, 173, 9, 155, 108, 236, 45, 38, 138, 255, 44, 132, 243, 81, 193))) then
        return false
      end
      if not import((U1(58, 18, 88, 186, 53, 24, 202, 214, 71, 204, 33, 133, 173, 9, 155, 108, 236, 45, 38, 138, 255, 44, 132, 243, 81, 193))).CreateCameraRecordSessionFromSequence(_ARG_1_) then
        return false
      end
      if import((U1(58, 18, 88, 186, 53, 24, 202, 214, 71, 204, 33, 133, 173, 9, 155, 108, 236, 45, 38, 138, 255, 44, 132, 243, 81, 193))).CreateCameraRecordSessionFromSequence(_ARG_1_).FixSpawnTrack then
      else
      end
      if import((U1(58, 18, 88, 186, 53, 24, 202, 214, 71, 204, 33, 133, 173, 9, 155, 108, 236, 45, 38, 138, 255, 44, 132, 243, 81, 193))).CreateCameraRecordSessionFromSequence(_ARG_1_).ExtendCameraCutToPlaybackRange then
      else
      end
      if not _ARG_2_.keyframes then
        return false
      end
      goto lbl_1062
      if nil == nil then
      end
      if U1(61, 18, 65, 190, 103, 34, 202, 214, 71, 204, 33, 133, 186, 14, 141, 68, 169, 5, 4, 166, 251, 115, 200, 237, 91, 147, 40, 148, 151, 26, 136, 104, 244, 54, 38).focalLength ~= nil then
      end
      if true then
      end
      ::lbl_1062::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if import((U1(58, 18, 88, 186, 53, 24, 202, 214, 71, 204, 33, 133, 173, 9, 155, 108, 236, 45, 38, 138, 255, 44, 132, 243, 81, 193))).CreateCameraRecordSessionFromSequence(_ARG_1_).ForceTemplateRefresh then
      else
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartSmartCamera"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_:CheckIsInForbiddenForSmartCamera() then
        log_warning(bWriteLog and table.concat({
          U1(55, 22, 66, 156, 38, 20, 253, 193, 69, 252, 26, 143, 153, 13, 135, 124, 218, 38, 41, 137, 222, 44, 187, 246, 86, 192, 58, 130, 154, 25, 151, 86, 219, 50, 38, 154, 244, 60, 140, 231),
          U1(16, 29, 82, 172, 125, 42, 236, 210, 86, 215, 0, 140, 159, 30, 158, 90, 232, 46, 32, 157, 214, 105, 197, 163, 119, 219, 38, 146, 133, 53, 137, 64, 247, 21, 58, 141, 197, 48, 156, 247),
          U1(28, 29, 115, 176, 53, 42, 245, 210, 86, 215, 16, 128, 147, 9, 152, 120)
        }))
        return
      end
      if not slua.isValid((U2.GetPlayerController())) then
        return
      end
      if _ARG_0_:GetPhotographerCameraModifier() then
      end
      if CDataTable.GetTableData(U1(58, 18, 88, 146, 38, 10, 236, 214, 86), _ARG_1_) and CDataTable.GetTableData(U1(58, 18, 88, 146, 38, 10, 236, 214, 86), _ARG_1_).TemplateType == U3.Pet then
        _ARG_0_.CurrentTemplateType = U3.Pet
        if not slua.isValid((require((table.concat({
          U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
          U1(22, 31, 70)
        }))).GetMainControlPanelTochButton())) then
          return
        end
      end
      if CDataTable.GetTableData(U1(58, 18, 88, 146, 38, 10, 236, 214, 86), _ARG_1_) and CDataTable.GetTableData(U1(58, 18, 88, 146, 38, 10, 236, 214, 86), _ARG_1_).TemplateType == U3.CameraRecord then
        _ARG_0_.CurrentTemplateType = U3.CameraRecord
        _ARG_0_.CameraRecordPendingData = _ARG_2_ and _ARG_2_.recordData
      end
      if _ARG_2_ then
        if _ARG_2_.StartTime and 0 < _ARG_2_.StartTime then
          import((U1(52, 28, 67, 182, 34, 42, 251, 214, 74, 198, 0, 132, 143, 25, 143, 119, 234, 38, 21, 131, 214, 48, 138, 226, 87, 216, 16, 148, 154, 8, 147, 103, 254, 32)))().StartTime = _ARG_2_.StartTime
        end
        if _ARG_2_.PlayRate and 0 < _ARG_2_.PlayRate then
          import((U1(52, 28, 67, 182, 34, 42, 251, 214, 74, 198, 0, 132, 143, 25, 143, 119, 234, 38, 21, 131, 214, 48, 138, 226, 87, 216, 16, 148, 154, 8, 147, 103, 254, 32)))().PlayRate = _ARG_2_.PlayRate
        else
        end
      end
      if _ARG_0_:GetPhotographerCameraModifier() then
      else
        _ARG_0_.uSmartCameraModifier = U4.InviteSmartPhotographer(U2.GetPlayerController(), _ARG_0_.uSmartCameraModifierClass)
      end
      _ARG_0_.bNewCameraEmoteDirectPlay = (_ARG_2_ and _ARG_2_.NewCameraEmoteDirectPlay) == true
      _ARG_0_:GetSuperData().TemplateID = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1.UEnums
    end
  end,
  ["StopSmartCamera"] = function(_ARG_0_)
    do
      if _ARG_0_:GetPhotographerCameraModifier() then
      end
      _ARG_0_:GetSuperData().TemplateID = -1
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayEmoteBegin"] = function(_ARG_0_)
    do
      if _ARG_0_.CurrentTemplateType == Player or _ARG_0_.CurrentTemplateType == CameraRecord then
        _ARG_0_:TryPlayNextEmote()
      elseif _ARG_0_.CurrentTemplateType == Pet then
        if not U2.slua.isValid((U1.GetPlayerCharacter())) then
          return
        end
        if not U2.slua.isValid(U1.GetPlayerCharacter().PetComponent_BP) or not U2.slua.isValid(U1.GetPlayerCharacter().PetComponent_BP.PetPawn) then
          return
        end
        _ARG_0_.CurrentPetPawn = U1.GetPlayerCharacter().PetComponent_BP.PetPawn
      end
      U2.print(U2.bWriteLog and U2.table.concat({
        U3(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 167, 237, 100, 223, 34, 136, 171, 17, 149, 125, 252, 17, 48, 152, 206, 55, 216, 224),
        U3(12, 16, 86, 186, 52, 10, 253, 215)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[167]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideMainControlPanelUI"] = function(_ARG_0_)
    do
      if not slua.isValid((require((table.concat({
        U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
        U1(22, 31, 70)
      }))).GetMainControlPanelTochButton())) then
        return
      end
      if not SubsystemMgr:Get((U1(45, 1, 84, 177, 52, 9, 249, 193, 65, 205, 39, 180, 183, 33, 133, 125, 236, 16, 48, 141, 196, 48, 155, 247, 81, 222))) then
        return
      end
      if not slua.isValid((require((table.concat({
        U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
        U1(22, 31, 70)
      }))).GetShootingUIPanel())) then
        return
      end
      goto lbl_226
      ::lbl_226::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if slua.isValid((require((table.concat({
        U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
        U1(22, 31, 70)
      }))).GetMainControlPanelTochButton():GetParent())) then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if slua.isValid(require((table.concat({
        U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
        U1(22, 31, 70)
      }))).GetShootingUIPanel().SkillLayer) then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.TopLevelUIList then
        goto lbl_399
        if require((table.concat({
          U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
          U1(22, 31, 70)
        }))).GetMainControlPanelTochButton():GetParent():GetChildAt(178 - 1) and UIManager.IsUIShow((require((table.concat({
          U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
          U1(22, 31, 70)
        }))).GetMainControlPanelTochButton():GetParent():GetChildAt(178 - 1))) and UIManager.GetUI((require((table.concat({
          U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
          U1(22, 31, 70)
        }))).GetMainControlPanelTochButton():GetParent():GetChildAt(178 - 1))) then
        end
        ::lbl_399::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if UIManager.GetUI(UIManager.UI_Config_InGame.BattlePopTips) then
      end
      do return end
      _ARG_0_ = _ENV[4]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnterNoUIMode"] = function(_ARG_0_)
    do
      if _ARG_0_.bIsPhotoGrapherMode then
        return
      end
      if not slua.isValid((U2.GetPlayerController())) then
        return
      end
      _ARG_0_.CahceJoyStickopacity = U2.GetPlayerController():GetJoyStickOpacity()
      _ARG_0_.uSmartCameraModifierClass = slua.loadClass(_ARG_0_:GetSmartPhotographerClassPath())
      _ARG_0_.uSmartCameraModifier = U3.InviteSmartPhotographer(U2.GetPlayerController(), _ARG_0_.uSmartCameraModifierClass)
      if not slua.isValid((U2.GetPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      _ARG_0_:GetSuperData().TemplateID = -1
      _ARG_0_.bIsPhotoGrapherMode = true
      U2.GetPlayerController():GetPlayerCharacterSafety().bIsHideCrossHairType = true
      U2.GetPlayerController().bForceHideConcentric = true
      if _ARG_0_.FadeOutTimer then
        _ARG_0_.FadeOutTimer = nil
      end
      _ARG_0_.FadeOutTimer = _ARG_0_:AddGameTimer(_ARG_0_.TransparentTime, false, function()
        _ENV:OperationUIFadeOut()
        return
      end)
      if _ARG_0_.screenInput then
        _ARG_0_.screenInput = nil
      end
      _ARG_0_.screenInput = import((U1(42, 16, 71, 186, 34, 23, 209, 221, 84, 214, 39)))((require((U1(26, 31, 92, 186, 41, 13, 182, 208, 75, 206, 62, 142, 144, 66, 159, 112, 214, 54, 49, 134, 219))).GetGameInstance()))
      if U2.GetPlayerController().bPCInputSwitcher == true then
        _ARG_0_.HasChangedPCInputSwitcher = true
        U2.GetPlayerController().bPCInputSwitcher = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowMainControlPanelUI"] = function(_ARG_0_)
    do
      if not slua.isValid((require((table.concat({
        U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
        U1(22, 31, 70)
      }))).GetMainControlPanelTochButton())) then
        return
      end
      if not slua.isValid((U2.GetPlayerController())) then
        return
      end
      if not SubsystemMgr:Get((U1(45, 1, 84, 177, 52, 9, 249, 193, 65, 205, 39, 180, 183, 33, 133, 125, 236, 16, 48, 141, 196, 48, 155, 247, 81, 222))) then
        return
      end
      if not slua.isValid((require((table.concat({
        U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
        U1(22, 31, 70)
      }))).GetShootingUIPanel())) then
        return
      end
      goto lbl_212
      ::lbl_212::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if slua.isValid((require((table.concat({
        U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
        U1(22, 31, 70)
      }))).GetMainControlPanelTochButton():GetParent())) then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if slua.isValid(require((table.concat({
        U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
        U1(22, 31, 70)
      }))).GetShootingUIPanel().SkillLayer) then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.TopLevelUIList then
        goto lbl_385
        if require((table.concat({
          U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
          U1(22, 31, 70)
        }))).GetMainControlPanelTochButton():GetParent():GetChildAt(178 - 1) and UIManager.IsUIShow((require((table.concat({
          U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
          U1(22, 31, 70)
        }))).GetMainControlPanelTochButton():GetParent():GetChildAt(178 - 1))) and UIManager.GetUI((require((table.concat({
          U1(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
          U1(22, 31, 70)
        }))).GetMainControlPanelTochButton():GetParent():GetChildAt(178 - 1))) then
        end
        ::lbl_385::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LeaveNoUIMode"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 164, 230, 85, 197, 38, 191, 129, 41, 179, 68, 246, 55, 48))
      if not _ARG_0_.bIsPhotoGrapherMode then
        return
      end
      if not slua.isValid((U2.GetPlayerController())) then
        return
      end
      if not _ARG_0_:GetPhotographerCameraModifier() then
        return
      end
      if not slua.isValid((U2.GetPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      _ARG_0_:GetSuperData().TemplateID = -1
      if UIManager.GetUI(UIManager.UI_Config_InGame.BattlePopTips) then
      end
      _ARG_0_.bIsPhotoGrapherMode = false
      _ARG_0_.CacheZoomValue = nil
      U2.GetPlayerController():GetPlayerCharacterSafety().bIsHideCrossHairType = false
      U2.GetPlayerController().bForceHideConcentric = false
      if _ARG_0_.CahceJoyStickopacity > 0 then
        _ARG_0_.CahceJoyStickopacity = -1
      end
      if _ARG_0_.screenInput then
        _ARG_0_.screenInput = nil
      end
      if U2.GetPlayerController().bPCInputSwitcher ~= nil and _ARG_0_.HasChangedPCInputSwitcher == true then
        _ARG_0_.HasChangedPCInputSwitcher = nil
        U2.GetPlayerController().bPCInputSwitcher = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[88]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckPawnStates"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return false
      end
      if not U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) then
        return false
      end
      if not _ARG_0_.PawnStateDisable then
        return false
      end
      goto lbl_37
      if GetPlayerController():GetPlayerCharacterSafety():Hasstate(nil) then
        return false
      end
      ::lbl_37::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if (GetPlayerController():GetPlayerCharacterSafety():Hasstate(U3.DriveVehicle) or GetPlayerController():GetPlayerCharacterSafety():Hasstate(U3.InVehicle)) and not (U1.SubsystemMgr:Get((U2(49, 26, 82, 183, 43, 16, 255, 219, 80, 238, 60, 140, 155, 2, 158, 74, 252, 33, 54, 150, 196, 61, 141, 238))) and U1.SubsystemMgr:Get((U2(49, 26, 82, 183, 43, 16, 255, 219, 80, 238, 60, 140, 155, 2, 158, 74, 252, 33, 54, 150, 196, 61, 141, 238))).bPlayingVehicleHighlight) then
        if not _ARG_0_:CheckVehicleDSSwitch() then
          return false
        end
        if _ARG_0_:CheckIsInForbiddenVehicle() then
          return false
        end
      end
      if GetPlayerController():GetPlayerCharacterSafety():IsOnFireBalloon() then
        return false
      end
      if GetPlayerController():GetPlayerCharacterSafety().LifterControl and GetPlayerController():GetPlayerCharacterSafety().LifterControl:IsUsingLifter() then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsInSameTeam"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return require((U1(26, 31, 92, 186, 41, 13, 182, 192, 72, 214, 50, 207, 146, 3, 141, 112, 234, 109, 49, 138, 214, 36, 157, 243, 26, 223, 44, 150, 135, 31, 165, 125, 252, 50, 56, 160, 210, 41))).GetMemberInfo(_ARG_2_.PlayerUID) ~= nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoveEvent"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      if not U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CharacterStateStateEnterHandler"] = function(_ARG_0_, _ARG_1_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      if not U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      if not _ARG_0_.PawnStateDisable then
        return
      end
      goto lbl_107
      if GetPlayerController():GetPlayerCharacterSafety():Hasstate(nil) then
        if U1.SubsystemMgr:Get((U2(48, 29, 82, 190, 42, 28, 203, 214, 72, 197, 58, 132, 173, 25, 136, 106, 240, 48, 49, 138, 218))) then
        end
        if U1.SubsystemMgr:Get((U2(58, 1, 80, 190, 51, 16, 238, 214, 105, 204, 55, 132, 183, 2, 141, 120, 228, 38, 22, 138, 219, 47, 129, 230, 103, 198, 33, 130, 151, 15, 142, 108, 244))) then
        end
        return
      end
      ::lbl_107::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetEmoteArray"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.EmoteIDList = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCharacterPlayNextEmote"] = function(_ARG_0_)
    do
      if #_ARG_0_.EmoteIDList > 0 then
        _ARG_0_:DisUseWeapon()
      end
      _ARG_0_:PlayNextEmote()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DisUseWeapon"] = function(_ARG_0_)
    do
      if not slua.isValid((U2.GetPlayerController())) then
        return
      end
      if not (slua.isValid((U2.GetPlayerController():GetPlayerCharacterSafety())) and U2.GetPlayerController():GetPlayerCharacterSafety().OnPlayEmote) or not U2.GetPlayerController():GetPlayerCharacterSafety():GetWeaponManager() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UseWeapon"] = function(_ARG_0_)
    do
      if not _ARG_0_.LastWeaponSlot then
        return
      end
      print(bWriteLog and U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 189, 240, 81, 228, 38, 144, 158, 19, 148), _ARG_0_.LastWeaponSlot)
      if not slua.isValid((U2.GetPlayerController())) then
        return
      end
      if not (slua.isValid((U2.GetPlayerController():GetPlayerCharacterSafety())) and U2.GetPlayerController():GetPlayerCharacterSafety().OnPlayEmote) or not U2.GetPlayerController():GetPlayerCharacterSafety():GetWeaponManager() then
        return
      end
      if slua.isValid((U2.GetPlayerController():GetPlayerCharacterSafety():GetWeaponManager())) and _ARG_0_.LastWeaponSlot ~= import((U1(60, 32, 64, 173, 49, 16, 238, 214, 115, 198, 50, 145, 145, 2, 186, 107, 230, 51, 22, 131, 216, 61))).SWPS_None then
        _ARG_0_.LastWeaponSlot = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryPlayNextEmote"] = function(_ARG_0_)
    do
      if #_ARG_0_.EmoteIDList <= 0 then
        return
      end
      _ARG_0_.LastWeaponSlot = nil
      if not slua.isValid((U2.GetPlayerController())) then
        return
      end
      if not slua.isValid((U2.GetPlayerController():GetPlayerCharacterSafety())) or not U2.GetPlayerController():GetPlayerCharacterSafety().OnPlayEmote then
        return
      end
      if U2.GetPlayerController():GetPlayerCharacterSafety():GetWeaponManager() and U2.GetPlayerController():GetPlayerCharacterSafety():GetWeaponManager():GetCurrentUsingPropSlot() ~= import((U1(60, 32, 64, 173, 49, 16, 238, 214, 115, 198, 50, 145, 145, 2, 186, 107, 230, 51, 22, 131, 216, 61))).SWPS_None then
        _ARG_0_.LastWeaponSlot = U2.GetPlayerController():GetPlayerCharacterSafety():GetWeaponManager():GetCurrentUsingPropSlot()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayNextEmote"] = function(_ARG_0_)
    do
      if #_ARG_0_.EmoteIDList <= 0 then
        _ARG_0_:UseWeapon()
        return
      end
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      if not U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) or not GetPlayerController():GetPlayerCharacterSafety().OnPlayEmote then
        return
      end
      if not _ARG_0_.bNewCameraEmoteDirectPlay and U1.SubsystemMgr:Get((U2(60, 30, 90, 171, 34, 42, 237, 209, 119, 218, 32, 149, 155, 1))) then
      end
      if not U1.SubsystemMgr:Get((U2(60, 30, 90, 171, 34, 42, 237, 209, 119, 218, 32, 149, 155, 1))):TryPlayMovableEmote(_ARG_0_.EmoteIDList[1], (GetPlayerController():GetPlayerCharacterSafety())) then
      end
      GetPlayerController():GetPlayerCharacterSafety().IsHandedWeaponBeforePlayEmote = false
      _ARG_0_.LastEmoteID = _ARG_0_.EmoteIDList[1]
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTargetArmLenthWithZoom"] = function(_ARG_0_, _ARG_1_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      if not U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      if not U1.slua.isValid(GetPlayerController():GetPlayerCharacterSafety().SpringArmComp) then
        return
      end
      if U1.slua.isValid((_ARG_0_:GetCurrentVehicle())) then
        if _ARG_0_:CheckIsDriver((GetPlayerController():GetPlayerCharacterSafety())) then
          if 0 > _ARG_0_.CacheVehicleTargetArmLenth then
            if _ARG_0_:GetCurrentVehicle():GetVehicleSpringArm() then
            end
          else
          end
        else
        end
      elseif 0 > _ARG_0_.CacheTargetArmLenth then
        if GetPlayerController():GetPlayerCharacterSafety().SpringArmComp then
        end
      else
      end
      _ARG_0_.CacheZoomValue = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurrentVehicle"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return nil
      end
      if not U1.slua.isValid((GetPlayerController():GetVehicleUserComp())) then
        return nil
      end
      do return GetPlayerController():GetVehicleUserComp():GetVehicle() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTargetArmLenth"] = function(_ARG_0_, _ARG_1_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      if not U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      if U1.slua.isValid((_ARG_0_:GetCurrentVehicle())) and _ARG_0_:CheckIsDriver((GetPlayerController():GetPlayerCharacterSafety())) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsDriver"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.NextSeatType then
        return _ARG_0_.NextSeatType == ESeatType_DriversSeat
      end
      do return U1.IsDriver(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCharacterTargetArmLenth"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_2_.SpringArmComp then
        if _ARG_0_.CacheTargetArmLenth < 0 then
          _ARG_0_:RefreshCacheTargetArmLenth(_ARG_2_.SpringArmComp.TargetArmLength)
        end
        _ARG_2_.SpringArmComp.bForceUseTargetArmLength = true
        _ARG_2_.SpringArmComp.TargetArmLength = _ARG_1_
        if _ARG_3_ then
          _ARG_2_.SpringArmComp.bForceUseTargetArmLength = false
        end
        print(bWriteLog and table.concat({
          U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 187, 230, 64, 240, 43, 144, 156, 29, 153, 125, 252, 33, 1, 158, 213, 62, 157, 231),
          U1(56, 1, 88, 147, 34, 23, 236, 219)
        }), _ARG_2_.SpringArmComp:GetCameraTargetArmLength(), _ARG_2_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCharacterSocketOffset"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not (slua.isValid(_ARG_2_) and _ARG_2_.SpringArmComp) or not _ARG_1_ then
        printf(table.concat({
          U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 187, 230, 64, 240, 43, 144, 156, 29, 153, 125, 252, 33, 6, 144, 196, 50, 157, 231),
          U1(54, 21, 83, 172, 34, 13, 184, 192, 79, 202, 35, 205, 222, 25, 186, 117, 232, 58, 32, 157, 231, 40, 159, 237, 20, 197, 34, 157, 135, 24, 192, 44, 234, 127, 117, 151, 198, 42, 171, 227),
          U1(11, 26, 91, 184, 6, 11, 245, 240, 75, 206, 35, 219, 219, 31, 198, 57, 198, 37, 35, 156, 210, 61, 210, 166, 71)
        }), slua.isValid(_ARG_2_), _ARG_2_ and _ARG_2_.SpringArmComp ~= nil, tostring(_ARG_1_))
        return
      end
      _ARG_2_.SpringArmComp.SocketOffset = _ARG_1_
      printf(table.concat({
        U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 187, 230, 64, 240, 43, 144, 156, 29, 153, 125, 252, 33, 6, 144, 196, 50, 157, 231),
        U1(54, 21, 83, 172, 34, 13, 184, 210, 84, 211, 63, 136, 155, 8, 198, 57, 198, 37, 35, 156, 210, 61, 210, 171, 17, 192, 111, 212, 157, 80, 223, 122, 176)
      }), _ARG_1_.X, _ARG_1_.Y, _ARG_1_.Z)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[186]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshCacheTargetArmLenth"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or _ARG_1_ < 0 then
        return
      end
      printf(table.concat({
        U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 186, 230, 82, 193, 38, 130, 134, 63, 155, 106, 241, 54, 1, 158, 213, 62, 157, 231),
        U1(56, 1, 88, 147, 34, 23, 236, 219, 4, 142, 115, 162, 159, 15, 130, 124, 221, 34, 55, 136, 210, 61, 169, 241, 89, 255, 38, 159, 154, 20, 218, 52, 185, 118, 38, 211, 135, 47, 153, 255),
        U1(12, 22, 21, 226, 103, 92, 235)
      }), _ARG_0_.CacheTargetArmLenth, _ARG_1_)
      _ARG_0_.CacheTargetArmLenth = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleTargetArmLenth"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 187, 230, 64, 229, 38, 153, 135, 31, 150, 108, 205, 50, 39, 152, 194, 45, 185, 225),
        U1(20, 63, 80, 177, 51, 17)
      }), _ARG_1_)
      if not slua.isValid(_ARG_2_) then
        return
      end
      if _ARG_2_:GetVehicleSpringArm() then
        if _ARG_0_.CacheVehicleTargetArmLenth < 0 then
          _ARG_0_.CacheVehicleTargetArmLenth = _ARG_2_:GetVehicleSpringArm().TargetArmLength
        end
        import((U1(58, 18, 88, 186, 53, 24, 215, 213, 66, 208, 54, 149, 186, 13, 158, 120)))().SpringArmLength = _ARG_1_
        import((U1(58, 18, 88, 186, 53, 24, 215, 213, 66, 208, 54, 149, 186, 13, 158, 120)))().BeginInterpSpeed = 1000
        import((U1(58, 18, 88, 186, 53, 24, 215, 213, 66, 208, 54, 149, 186, 13, 158, 120)))().EndInterpSpeed = 1000
        _ARG_2_:GetVehicleSpringArm().TargetArmLength = _ARG_1_
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetVehicleSpringArm"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 186, 230, 71, 214, 55, 167, 139, 20, 147, 106, 245, 54, 6, 143, 213, 48, 150, 244),
        U1(56, 1, 88)
      }))
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_1_:GetVehicleSpringArm() then
        _ARG_1_:GetVehicleSpringArm().TargetArmLength = _ARG_0_.CacheVehicleTargetArmLenth
        _ARG_0_.CacheVehicleTargetArmLenth = -1
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetNewSpringArmLength"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if 0.4 < _ARG_2_ then
        return _ARG_1_ + (_ARG_2_ - 0.4) * 800
      else
        return (3 * _ARG_2_ - 0.2) * _ARG_1_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResumeSpringArmLength"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      if not U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      if _ARG_0_.CacheTargetArmLenth and _ARG_0_.CacheTargetArmLenth > 0 then
        _ARG_0_.CacheTargetArmLenth = -1
      end
      if U1.slua.isValid((_ARG_0_:GetCurrentVehicle())) and _ARG_0_.CacheVehicleTargetArmLenth and 0 < _ARG_0_.CacheVehicleTargetArmLenth then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OperationUIFadeIn"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 167, 243, 81, 193, 34, 133, 135, 19, 148, 92, 208, 21, 52, 155, 194, 16, 150))
      if not slua.isValid((U2.GetPlayerController())) then
        return
      end
      if not _ARG_0_:GetPhotographerCameraModifier() then
        return
      end
      if not _ARG_0_.bIsPhotoGrapherMode then
        return
      end
      if _ARG_0_.FadeOutTimer then
        _ARG_0_.FadeOutTimer = nil
      elseif UIManager.GetUI(UIManager.UI_Config_InGame.Ingame_Photo_UIBP) then
      end
      if not _ARG_0_.bIsPhotoGrapherMode then
        return
      end
      _ARG_0_.FadeOutTimer = _ARG_0_:AddGameTimer(_ARG_0_.TransparentTime, false, function()
        _ENV:OperationUIFadeOut()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OperationUIFadeOut"] = function(_ARG_0_)
    do
      if not _ARG_0_.bIsPhotoGrapherMode then
        return
      end
      if _ARG_0_.FadeOutTimer then
        _ARG_0_:RemoveGameTimer(_ARG_0_.FadeOutTimer)
        _ARG_0_.FadeOutTimer = nil
      end
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      if not _ARG_0_:GetPhotographerCameraModifier() then
        return
      end
      if not U1.SubsystemMgr:Get((U2(48, 29, 82, 190, 42, 28, 203, 214, 72, 197, 58, 132, 173, 25, 136, 106, 240, 48, 49, 138, 218))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetAllUIOpacity"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.bIsPhotoGrapherMode then
        return
      end
      if _ARG_1_ < 0 or 1 < _ARG_1_ then
        return
      end
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      if not U1.slua.isValid((U1.require((U1.table.concat({
        U2(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
        U2(22, 31, 70)
      }))).GetMainControlPanelTochButton())) then
        return
      end
      if _ARG_2_ then
      end
      if U1.slua_GameFrontendHUD:GetUserSettings().NoUIOpacity then
        U1.slua_GameFrontendHUD:GetUserSettings().NoUIOpacity = _ARG_1_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAllUIOpacity"] = function(_ARG_0_)
    do
      if slua_GameFrontendHUD:GetUserSettings().NoUIOpacity then
        return slua_GameFrontendHUD:GetUserSettings().NoUIOpacity
      end
      do return 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPhotographerCameraModifier"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      _ARG_0_.uSmartCameraModifierClass = U1.slua.loadClass(_ARG_0_:GetSmartPhotographerClassPath())
      do return (GetPlayerController().PlayerCameraManager:FindCameraModifierByClass(_ARG_0_.uSmartCameraModifierClass)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetGMPhotographerCameraModifier"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      do return (U2.InviteSmartPhotographer(GetPlayerController(), (U1.slua.loadClass(_ARG_0_:GetSmartPhotographerClassPath())))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSmartPhotographerClassPath"] = function(_ARG_0_)
    do
      do return _ENV end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSmartCameraCineCamera"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetPhotographerCameraModifier())) then
        return
      end
      if not slua.isValid((_ARG_0_:GetPhotographerCameraModifier():GetViewTarget())) then
        return
      end
      if not _ARG_0_:GetPhotographerCameraModifier():GetViewTarget().ActorLabel or _ARG_0_:GetPhotographerCameraModifier():GetViewTarget().ActorLabel ~= U1(59, 35, 21, 156, 38, 20, 184, 254, 69, 208, 39, 132, 140) then
        return
      end
      do return _ARG_0_:GetPhotographerCameraModifier():GetViewTarget().Camera end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSmartCameraAdd"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 167, 237, 103, 222, 34, 131, 154, 63, 155, 100, 252, 33, 52, 190, 195, 61))
      if not slua.isValid(_ARG_3_) then
        return
      end
      print(bWriteLog and U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 167, 237, 103, 222, 34, 131, 154, 63, 155, 100, 252, 33, 52, 190, 195, 61, 201, 162))
      if not slua.isValid((_ARG_3_:GetOwningPlayerController())) then
        return
      end
      if not slua.isValid((_ARG_3_:GetOwningPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      _ARG_0_.bIsPhotoGrapherMode = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSmartCameraRemove"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and table.concat({
        U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 167, 237, 103, 222, 34, 131, 154, 63, 155, 100, 252, 33, 52, 173, 194, 52, 151, 229),
        U1(28)
      }))
      if not slua.isValid(_ARG_3_) then
        return
      end
      if not slua.isValid((_ARG_3_:GetOwningPlayerController())) then
        return
      end
      if not slua.isValid((_ARG_3_:GetOwningPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      _ARG_0_.bIsPhotoGrapherMode = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSmartCameraDamageInterrupt"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      print(bWriteLog and table.concat({
        U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 167, 237, 103, 222, 34, 131, 154, 63, 155, 100, 252, 33, 52, 187, 198, 52, 153, 244),
        U1(28, 58, 91, 171, 34, 11, 234, 198, 84, 215)
      }))
      if 0 < _ARG_1_ then
        if SubsystemMgr:Get((U1(48, 29, 82, 190, 42, 28, 203, 214, 72, 197, 58, 132, 173, 25, 136, 106, 240, 48, 49, 138, 218))) and SubsystemMgr:Get((U1(48, 29, 82, 190, 42, 28, 203, 214, 72, 197, 58, 132, 173, 25, 136, 106, 240, 48, 49, 138, 218))):CheckIgnoreDamageTypes(_ARG_5_) then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSmartCamerainterrupt"] = function(_ARG_0_)
    do
      if UIManager.IsUIShow(UIManager.UI_Config_InGame.NewCamera_Photo_Share_UIBP) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CreateGreenSkySphere"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      if not U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      if not U1.SubsystemMgr:Get((U2(46, 22, 84, 171, 47, 28, 234, 224, 81, 193, 32, 152, 141, 24, 143, 116))) then
        return
      end
      if not U1.slua.isValid((U1.slua_GameFrontendHUD:GetWorld())) then
        return
      end
      if U1.slua.isValid((U1.SubsystemMgr:Get((U2(46, 22, 84, 171, 47, 28, 234, 224, 81, 193, 32, 152, 141, 24, 143, 116))):GetSkySphere((U1.slua_GameFrontendHUD:GetWorld())))) then
        if GetGameState() and (GetGameState().GameModeType == U1.import((U2(60, 52, 84, 178, 34, 52, 247, 215, 65, 247, 42, 145, 155))).ESocialIsland or GetGameState().GameModeType == U1.import((U2(60, 52, 84, 178, 34, 52, 247, 215, 65, 247, 42, 145, 155))).EPlanPHGameMode) then
        end
        U1.FVector(59907, 67435, 253).Z = GetPlayerController():GetPlayerCharacterSafety():K2_GetActorLocation().Z
      else
      end
      if not U1.slua.isValid(U1.CGameWorld) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DelSkySphere"] = function(_ARG_0_)
    do
      if slua.isValid(_ARG_0_.uGreenSphereActor) then
        slua.removeRef(_ARG_0_.uGreenSphereActor)
        _ARG_0_.uGreenSphereActor:K2_DestroyActor()
        _ARG_0_.uGreenSphereActor = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SwitchSkySphere"] = function(_ARG_0_, _ARG_1_)
    do
      if slua.isValid(_ARG_0_.uGreenSphereActor) then
        _ARG_0_.uGreenSphereActor:SetActorHiddenInGame(not _ARG_1_)
        _ARG_0_.bIsSkySphereOn = _ARG_1_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSkySphereOn"] = function(_ARG_0_)
    do
      do return _ARG_0_.bIsSkySphereOn end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHideAllPawn"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:GetPhotographerCameraModifier() then
        return
      end
      _ARG_0_:GetPhotographerCameraModifier().bHideAll = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ForceRefreshNextHide"] = function(_ARG_0_)
    do
      if not _ARG_0_:GetPhotographerCameraModifier() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPawnVisible"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_0_:GetPhotographerCameraModifier() then
        return
      end
      _ARG_0_:GetPhotographerCameraModifier().bHideSelf = _ARG_1_
      _ARG_0_:GetPhotographerCameraModifier().bHideInteract = _ARG_1_
      _ARG_0_:GetPhotographerCameraModifier().bHideTeammate = _ARG_2_
      _ARG_0_:GetPhotographerCameraModifier().bHideEnemy = _ARG_3_
      if _ARG_4_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMyPawnVisible"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 187, 230, 64, 254, 58, 161, 143, 11, 148, 95, 240, 32, 60, 157, 203, 60), _ARG_1_)
      if not _ARG_0_:GetPhotographerCameraModifier() then
        return
      end
      _ARG_0_:GetPhotographerCameraModifier().bHideSelf = _ARG_1_
      _ARG_0_:GetPhotographerCameraModifier().bHideInteract = _ARG_1_
      if _ARG_2_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTeamPawnVisible"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 187, 230, 64, 231, 38, 144, 131, 44, 155, 126, 247, 5, 60, 140, 206, 59, 148, 246), _ARG_1_)
      if not _ARG_0_:GetPhotographerCameraModifier() then
        return
      end
      _ARG_0_:GetPhotographerCameraModifier().bHideTeammate = _ARG_1_
      if _ARG_2_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPetVisible"] = function(_ARG_0_, _ARG_1_)
    do
      printf(table.concat({
        U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 187, 230, 64, 227, 38, 133, 184, 21, 137, 96, 251, 63, 48, 223, 197, 10, 144, 252),
        U1(12, 31, 81, 151, 46, 29, 253, 137, 1, 208)
      }), tostring(_ARG_1_))
      _ARG_0_.bHideAllPets = _ARG_1_ == true
      if not slua.isValid((_ARG_0_:GetPhotographerCameraModifier())) then
        return
      end
      _ARG_0_:GetPhotographerCameraModifier().bHideAllPets = _ARG_0_.bHideAllPets
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEnterVehicle"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.NextSeatType = _ARG_1_
      if _ARG_0_.CacheZoomValue then
        _ARG_0_:SetTargetArmLenthWithZoom(_ARG_0_.CacheZoomValue)
      end
      _ARG_0_.NextSeatType = nil
      if _ARG_0_:CheckIsInForbiddenVehicle() and SubsystemMgr:Get((U1(48, 29, 82, 190, 42, 28, 203, 214, 72, 197, 58, 132, 173, 25, 136, 106, 240, 48, 49, 138, 218))) then
      end
      _ARG_0_:StopSmartCamera()
      _ARG_0_:ReportPhotographerOp(U2.PhotographerOptype.UseInVehicle)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDetachedFromVehicle"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.bIsPhotoGrapherMode then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not slua.isValid((U1.GetPlayerController())) then
        return
      end
      if not slua.isValid((U1.GetPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      if _ARG_0_.CacheVehicleTargetArmLenth and _ARG_0_.CacheVehicleTargetArmLenth > 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnChangedVehicleSeat"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.bIsPhotoGrapherMode then
        return
      end
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      if not U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      _ARG_0_.NextSeatType = _ARG_1_
      if U1.slua.isValid((_ARG_0_:GetCurrentVehicle())) and _ARG_0_.CacheVehicleTargetArmLenth and _ARG_0_.CacheVehicleTargetArmLenth > 0 then
      end
      _ARG_0_.NextSeatType = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetModifyData"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      if not U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      if _ARG_0_.CacheTargetArmLenth and _ARG_0_.CacheTargetArmLenth > 0 then
        _ARG_0_.CacheTargetArmLenth = -1
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLuaTrackEvent"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 167, 237, 120, 198, 34, 165, 156, 29, 153, 98, 220, 37, 48, 145, 211), _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSequenceLoaded"] = function(_ARG_0_, _ARG_1_)
    do
      printf(table.concat({
        U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 167, 237, 103, 214, 50, 132, 139, 18, 153, 108, 213, 60, 52, 155, 194, 61, 216, 200),
        U1(43, 22, 86, 176, 53, 29, 220, 209, 67, 254, 115, 164, 176, 56, 175, 75, 169, 23, 32, 130, 199, 37, 137, 247, 81, 231, 58, 129, 139, 70, 223, 122, 181, 115, 38, 154, 214, 15, 153, 255),
        U1(16, 23, 15, 250, 52, 85, 184, 219, 69, 208, 3, 132, 144, 8, 131, 119, 238, 7, 36, 155, 214, 115, 205, 240)
      }), tostring(_ARG_0_.CurrentTemplateType), tostring(slua.isValid(_ARG_1_)), tostring(_ARG_0_.CameraRecordPendingData ~= nil))
      if _ARG_0_.CurrentTemplateType ~= U2.CameraRecord then
        printf((table.concat({
          U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 167, 237, 103, 214, 50, 132, 139, 18, 153, 108, 213, 60, 52, 155, 194, 61, 216, 200),
          U1(43, 22, 86, 176, 53, 29, 220, 209, 67, 254, 115, 178, 181, 37, 186, 35, 169, 23, 32, 130, 199, 37, 137, 247, 81, 231, 58, 129, 139, 92, 147, 122, 185, 61, 58, 139, 135, 26, 153, 254),
          U1(28, 1, 84, 141, 34, 26, 247, 193, 64)
        })))
        return
      end
      if not _ARG_0_.CameraRecordPendingData then
        return
      end
      _ARG_0_.CameraRecordPendingData = nil
      if not slua.isValid(_ARG_1_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCamereSeqBegin"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetPhotographerCameraModifier())) then
        return
      end
      if not slua.isValid(_ARG_0_:GetPhotographerCameraModifier().CamMasterSeuqenceActor) then
        return
      end
      if not slua.isValid(_ARG_0_:GetPhotographerCameraModifier().CamMasterSeuqenceActor.SequencePlayer) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCamereSeqFinish"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      if not U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      if U1.SubsystemMgr:Get((U2(52, 48, 116, 188, 51, 16, 247, 221, 119, 214, 49, 146, 135, 31, 158, 124, 228))) and not U1.SubsystemMgr:Get((U2(52, 48, 116, 188, 51, 16, 247, 221, 119, 214, 49, 146, 135, 31, 158, 124, 228))):CheckCanExitFreeCamera() then
      end
      if false and U1.SubsystemMgr:Get((U2(48, 29, 82, 190, 42, 28, 203, 214, 72, 197, 58, 132, 173, 25, 136, 106, 240, 48, 49, 138, 218))) and U1.SubsystemMgr:Get((U2(48, 29, 82, 190, 42, 28, 203, 214, 72, 197, 58, 132, 173, 25, 136, 106, 240, 48, 49, 138, 218))).isInNewCamera then
      end
      if false then
      end
      if not U1.slua.isValid((U1.require((U1.table.concat({
        U2(62, 18, 88, 186, 11, 12, 249, 157, 105, 204, 55, 207, 188, 13, 153, 124, 196, 44, 33, 193, 244, 38, 133, 238, 91, 221, 109, 164, 167, 82, 179, 103, 222, 50, 56, 154, 242, 16, 172, 252),
        U2(22, 31, 70)
      }))).GetMainControlPanelTochButton())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[214]
    end
  end,
  ["ModifyPetOpen"] = function(_ARG_0_, _ARG_1_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      if not U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPetOpen"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      if not U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      do return U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.SettingModule):GetOptionValue((U2(54, 3, 80, 177, 10, 0, 200, 214, 80))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAllWearState"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {
        [nil - 1] = not GetPlayerController().InitialAllWear:Get(nil - 1).IsLocked
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurWearIndex"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return -1
      end
      do return GetPlayerController().RolewearIndex end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RequestChangeWearInPhoto"] = function(_ARG_0_, _ARG_1_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      do return (GetPlayerController():RequestChangeWearInPhoto(_ARG_1_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_TrackPhotoWearRequest"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_._photoWearPendingTargets then
        _ARG_0_._photoWearPendingTargets = {}
      end
      if _ARG_0_._photoWearOriginIndex == nil and _ARG_0_:GetCurWearIndex() and _ARG_0_:GetCurWearIndex() >= 0 then
        _ARG_0_._photoWearOriginIndex = _ARG_0_:GetCurWearIndex()
        _ARG_0_._photoWearRestoreRetried = false
      end
      _ARG_0_._photoWearPendingTargets[_ARG_1_] = (_ARG_0_._photoWearPendingTargets[_ARG_1_] or 0) + 1
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPhotoWearOriginIndex"] = function(_ARG_0_)
    do
      do return _ARG_0_._photoWearOriginIndex end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryRestorePhotoWearOnExit"] = function(_ARG_0_)
    do
      if _ARG_0_._photoWearOriginIndex == nil or _ARG_0_._photoWearOriginIndex < 0 then
        return false
      end
      if not (_ARG_0_._photoWearPendingTargets ~= nil and next(_ARG_0_._photoWearPendingTargets) ~= nil) and _ARG_0_:GetCurWearIndex() == _ARG_0_._photoWearOriginIndex then
        return false
      end
      do return (_ARG_0_:RequestChangeWearInPhoto(_ARG_0_._photoWearOriginIndex)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetPhotoWearTracking"] = function(_ARG_0_)
    do
      _ARG_0_._photoWearOriginIndex = nil
      _ARG_0_._photoWearPendingTargets = {}
      _ARG_0_._photoWearRestoreRetried = false
      _ARG_0_._photoWearSessionEnded = false
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPhotoWearSessionEnded"] = function(_ARG_0_)
    do
      _ARG_0_._photoWearSessionEnded = true
      _ARG_0_:AddTimerOnce(10, function()
        if _photoWearSessionEnded then
          _ENV:ResetPhotoWearTracking()
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPhotoModeActive"] = function(_ARG_0_)
    do
      if U1.slua.isValid((GetPlayerState())) and GetPlayerState().PhotoGrapherFeature then
        return GetPlayerState().PhotoGrapherFeature.bPhotoGrapherOpenState == true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayerChangeWearingDoneForPhoto"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_1_ == nil or _ARG_0_._photoWearOriginIndex == nil then
        return
      end
      if (_ARG_0_._photoWearPendingTargets and _ARG_0_._photoWearPendingTargets[_ARG_1_] or 0) <= 0 then
        return
      end
      if (_ARG_0_._photoWearPendingTargets and _ARG_0_._photoWearPendingTargets[_ARG_1_] or 0) <= 1 then
        _ARG_0_._photoWearPendingTargets[_ARG_1_] = nil
      else
        _ARG_0_._photoWearPendingTargets[_ARG_1_] = (_ARG_0_._photoWearPendingTargets and _ARG_0_._photoWearPendingTargets[_ARG_1_] or 0) - 1
      end
      if not _ARG_0_._photoWearSessionEnded or _ARG_0_:IsPhotoModeActive() then
        return
      end
      if _ARG_1_ == _ARG_0_._photoWearOriginIndex then
        return
      end
      if not _ARG_0_._photoWearRestoreRetried then
        if _ARG_0_:RequestChangeWearInPhoto(_ARG_0_._photoWearOriginIndex) then
          _ARG_0_._photoWearRestoreRetried = true
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPetState"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      if not U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      do return not GetPlayerController():GetPlayerCharacterSafety().PetComponent_BP.PetPawn.bHidden end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ModifyEmotePlayRate"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.PendingEmoteRate = _ARG_1_
      if not slua.isValid((U1.GetPlayerController())) then
        return
      end
      if not slua.isValid((U1.GetPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      if U1.GetPlayerController():GetPlayerCharacterSafety():GetAttrValue(_ARG_0_.AttrName) == math.ceil(math.max(_ARG_1_, _ARG_0_.EmotePlayRateLimit) * 10000) then
        return
      end
      if not slua.isValid((U1.GetPlayerState())) or not U1.GetPlayerState().PhotoGrapherFeature then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ApplyRoleEmoteRateDirectly"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not slua.isValid((_ARG_1_:GetPlayEmoteComponent())) or not _ARG_1_:GetPlayEmoteComponent().RequestSetEmoteMontagePlayRate then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRoleEmoteStartedPlay"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if (_ARG_0_.PendingEmoteRate or 1) <= 1 then
        return
      end
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ApplyPetActionRate"] = function(_ARG_0_, _ARG_1_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      if not U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) or not U1.slua.isValid(GetPlayerController():GetPlayerCharacterSafety().PetComponent_BP) then
        return
      end
      goto lbl_51
      ::lbl_51::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EmotePlayRateChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.LastPlayRate = _ARG_2_ / 10000.0, _ARG_0_.LastPlayRate or 1.0
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_1_:GetPlayEmoteComponent() == nil then
        return
      end
      if _ARG_1_:GetPlayEmoteComponent():IsPlayingEmotes() ~= true then
        return
      end
      if _ARG_1_:GetEmoteHandle((_ARG_1_:GetPlayEmoteComponent():GetCurrentEmoteId())) then
        goto lbl_131
        if U1(13, 22, 21, 143, 43, 24, 225, 246, 73, 204, 39, 132, 189, 3, 135, 105, 169, 42, 54, 207, 217, 32, 132) then
        end
        ::lbl_131::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_1_.Mesh:GetSubAnimInstances() and _ARG_1_.Mesh:GetSubAnimInstances().Num then
        _ARG_0_ = _ARG_0_
        if slua.isValid((_ARG_1_.Mesh:GetSubAnimInstances():Get(U1(13, 22, 21, 143, 43, 24, 225, 246, 73, 204, 39, 132, 189, 3, 135, 105, 169, 42, 54, 207, 217, 32, 132) - 1))) and slua.isValid((_ARG_1_.Mesh:GetSubAnimInstances():Get(U1(13, 22, 21, 143, 43, 24, 225, 246, 73, 204, 39, 132, 189, 3, 135, 105, 169, 42, 54, 207, 217, 32, 132) - 1):GetCurrentActiveMontage())) then
          _ARG_1_:GetPlayEmoteComponent().EmoteAnimLastTime = _ARG_1_:GetPlayEmoteComponent().EmoteAnimLastTime * (_ARG_0_.LastPlayRate or 1.0) / (_ARG_2_ / 10000.0)
          return
        end
        _ARG_0_ = _ARG_0_
      end
      if slua.isValid((_ARG_1_.Mesh:GetAnimInstance())) and slua.isValid((_ARG_1_.Mesh:GetAnimInstance():GetCurrentActiveMontage())) then
        _ARG_1_:GetPlayEmoteComponent().EmoteAnimLastTime = _ARG_1_:GetPlayEmoteComponent().EmoteAnimLastTime * (_ARG_0_.LastPlayRate or 1.0) / (_ARG_2_ / 10000.0)
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayeEffect"] = function(_ARG_0_, _ARG_1_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      if not U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) then
        return
      end
      if U3.EffectConfig[_ARG_1_].EffectPath == nil then
        return
      end
      if U3.EffectConfig[_ARG_1_].bIsLevelSequence then
        if not U1.slua.isValid(GetPlayerController():GetPlayerCharacterSafety().Mesh) then
          return
        end
        U1.FRotator(0, 0, 0).Yaw = U3.EffectConfig[_ARG_1_].RelativeRotation.Yaw + GetPlayerController():GetPlayerCharacterSafety():K2_GetActorRotation().Yaw
        _ARG_0_.SequenceActor = U1.Game:PlayLevelSequence(GetPlayerController():GetPlayerCharacterSafety(), U3.EffectConfig[_ARG_1_].EffectPath, U1.import((U2(50, 26, 70, 178, 34, 13, 213, 210, 80, 203, 31, 136, 156, 30, 139, 107, 240))).MakeTransform(GetPlayerController():GetPlayerCharacterSafety().Mesh:K2_GetComponentLocation() + GetPlayerController():GetPlayerCharacterSafety():K2_GetActorRotation():RotateVector(U3.EffectConfig[_ARG_1_].RelativeLocation), U1.FRotator(0, 0, 0), U1.FVector(1, 1, 1)), U1.table.concat({
          U2(86, 52, 84, 178, 34, 86, 213, 220, 64, 140, 22, 151, 145, 46, 139, 106, 236, 108, 7, 131, 194, 44, 184, 241, 93, 221, 55, 130, 193, 61, 153, 125, 246, 33, 122, 189, 247, 6, 173, 210),
          U2(60, 63, 80, 169, 34, 21, 203, 214, 85, 214, 54, 143, 157, 9, 171, 122, 253, 44, 55, 193, 245, 25, 183, 214, 117, 246, 15, 148, 152, 25, 150, 90, 252, 34, 32, 154, 201, 58, 157, 210),
          U2(26, 7, 90, 173, 24, 58)
        }), true, nil)
      else
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangePhotoGrapherOpenState"] = function(_ARG_0_, _ARG_1_)
    do
      if not U1.slua.isValid((GetPlayerState())) or not GetPlayerState().PhotoGrapherFeature then
        return
      end
      if GetPlayerState().PhotoGrapherFeature.bPhotoGrapherOpenState == _ARG_1_ then
        return
      end
      if _ARG_1_ == true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsSpecialPet"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return false
      end
      if not U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) or not U1.slua.isValid(GetPlayerController():GetPlayerCharacterSafety().PetComponent_BP) then
        return false
      end
      if U1.require((U2(26, 28, 88, 178, 40, 23, 182, 199, 69, 193, 63, 132, 161, 25, 158, 112, 229))).IsInTable(U3.SpecialPetID, GetPlayerController():GetPlayerCharacterSafety().PetComponent_BP.PetInfo.PetId) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayPetFeature"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerState())) or not GetPlayerState().PhotoGrapherFeature then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReportPhotographerOp"] = function(_ARG_0_, _ARG_1_)
    do
      if not U1.slua.isValid((GetPlayerState())) or not GetPlayerState().PhotoGrapherFeature then
        return
      end
      if U2.Find(_ARG_0_.UseRecord, _ARG_1_) ~= -1 then
        if U2.Find(_ARG_0_.NeedRportTimes, _ARG_1_) == -1 then
          return
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckBasicSkillButtonState"] = function(_ARG_0_, _ARG_1_)
    do
      if require((U1(26, 28, 88, 178, 40, 23, 182, 199, 69, 193, 63, 132, 161, 25, 158, 112, 229))).IsInTable(U2.BasicSkillButtonType.Vehicle, _ARG_1_) then
        if not _ARG_0_:CheckVehicleDSSwitch() then
          return false
        end
        return true
      elseif require((U1(26, 28, 88, 178, 40, 23, 182, 199, 69, 193, 63, 132, 161, 25, 158, 112, 229))).IsInTable(U2.BasicSkillButtonType.Other, _ARG_1_) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckVehicleDSSwitch"] = function(_ARG_0_)
    do
      if CGame:IsEditor() then
        print(bWriteLog and table.concat({
          U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 171, 235, 81, 208, 40, 167, 139, 20, 147, 106, 245, 54, 17, 172, 244, 46, 145, 231),
          U1(26, 27, 25, 255, 14, 10, 221, 215, 77, 215, 60, 147)
        }))
        return true
      end
      if U2.GetGameState() and U2.GetGameState():CheckDSSwitchOpen(U3) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsInVehicle"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return false
      end
      if not U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) then
        return false
      end
      if not U1.slua.isValid((_ARG_0_:GetCurrentVehicle())) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsInForbiddenVehicle"] = function(_ARG_0_)
    do
      if not _ARG_0_:CheckVehicleDSSwitch() then
        print(bWriteLog and table.concat({
          U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 171, 235, 81, 208, 40, 184, 157, 53, 148, 79, 246, 33, 55, 150, 195, 61, 157, 253),
          U1(47, 22, 93, 182, 36, 21, 253, 159, 4, 209, 54, 149, 139, 30, 132, 57, 239, 34, 41, 156, 210)
        }))
        return true
      end
      if not slua.isValid((U2.GetPlayerController())) then
        return true
      end
      if slua.isValid((_ARG_0_:GetCurrentVehicle())) and _ARG_0_:GetCurrentVehicle().VehicleShapeType and require((U1(26, 28, 88, 178, 40, 23, 182, 199, 69, 193, 63, 132, 161, 25, 158, 112, 229))).IsInTable(U3.ForbiddenVehicleType, _ARG_0_:GetCurrentVehicle().VehicleShapeType) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsInForbiddenForSmartCamera"] = function(_ARG_0_)
    do
      if not _ARG_0_:CheckVehicleDSSwitch() then
        print(bWriteLog and table.concat({
          U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 171, 235, 81, 208, 40, 184, 157, 53, 148, 79, 246, 33, 55, 150, 195, 61, 157, 253),
          U1(63, 28, 71, 140, 42, 24, 234, 199, 103, 194, 62, 132, 140, 13, 198, 57, 251, 38, 49, 154, 197, 39, 200, 229, 85, 223, 48, 148)
        }))
        return true
      end
      if not slua.isValid((U2.GetPlayerController())) then
        return true
      end
      if slua.isValid((_ARG_0_:GetCurrentVehicle())) and _ARG_0_:GetCurrentVehicle().VehicleShapeType and U3.IsInTable(U4.ForbiddenVehicleTypeForSmartCamera, _ARG_0_:GetCurrentVehicle().VehicleShapeType) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEmotePlayEnd"] = function(_ARG_0_)
    do
      if slua.isValid(_ARG_0_.CurrentPetPawn) then
        _ARG_0_:RemoveControlEvent(_ARG_0_.CurrentPetPawn, (U1(54, 29, 101, 186, 51, 60, 245, 220, 80, 198, 1, 132, 159, 8, 147, 77, 230, 19, 41, 142, 206, 7, 141, 251, 64)))
        _ARG_0_.CurrentPetPawn = nil
      end
      _ARG_0_.CurrentTemplateType = U2.Player
      _ARG_0_.EmoteIDList = {}
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayNextPetEmote"] = function(_ARG_0_)
    do
      if #_ARG_0_.EmoteIDList <= 0 then
        _ARG_0_:OnEmotePlayEnd()
        return
      end
      if not U1.slua.isValid((GetPlayerController())) then
        return
      end
      _ARG_0_.LastEmoteID = _ARG_0_.EmoteIDList[1], GetPlayerController():PlaySpecifiedPetAnimation(_ARG_0_.EmoteIDList[1])
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DestoryLevelSequence"] = function(_ARG_0_)
    do
      if slua.isValid(_ARG_0_.SequenceActor) then
        _ARG_0_.SequenceActor:K2_DestroyActor()
        _ARG_0_.SequenceActor = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPetActionList"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 175, 230, 64, 227, 38, 133, 175, 31, 142, 96, 246, 61, 25, 150, 212, 45))
      if not slua.isValid((U2.GetPlayerController())) then
        return {}
      end
      if not slua.isValid((U2.GetPlayerController():GetPlayerCharacterSafety())) or not slua.isValid(U2.GetPlayerController():GetPlayerCharacterSafety().PetComponent_BP) then
        return {}
      end
      if U2.GetPlayerController().IsInPetSpectator and U2.GetPlayerController():IsInPetSpectator() and U2.GetPlayerController().InitialPetInfo then
      else
      end
      if not (U2.GetPlayerController():GetPlayerCharacterSafety().PetComponent_BP.PetPawn.PetLevelInfo.PetId and not (U2.GetPlayerController():GetPlayerCharacterSafety().PetComponent_BP.PetPawn.PetLevelInfo.PetId <= 0) and U2.GetPlayerController():GetPlayerCharacterSafety().PetComponent_BP.PetPawn.PetLevelInfo.PetLevel) or U2.GetPlayerController():GetPlayerCharacterSafety().PetComponent_BP.PetPawn.PetLevelInfo.PetLevel <= 0 or not _ARG_0_:GetPetState() then
        return {}
      end
      goto lbl_384
      if (not ((178).CanPlayInBattle ~= 1 and ((178).CanPlayInBattle ~= 2 or true)) or (178).CanPlayInBattle == 3 and true) and _ARG_0_:IsPetAvatarRequirementMatch((require((U1(26, 28, 88, 178, 40, 23, 182, 192, 80, 209, 58, 143, 153, 51, 159, 109, 224, 47))).Split((178).DependingClothesID, (U1(5))))) then
      end
      ::lbl_384::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if #{} <= 0 then
        return {}
      end
      if not CDataTable.GetTableData(U1(41, 22, 65, 147, 34, 15, 253, 223, 112, 194, 49, 141, 155), 10000 * U2.GetPlayerController():GetPlayerCharacterSafety().PetComponent_BP.PetPawn.PetLevelInfo.PetId + U2.GetPlayerController():GetPlayerCharacterSafety().PetComponent_BP.PetPawn.PetLevelInfo.PetLevel) then
        return {}
      end
      goto lbl_579
      ::lbl_579::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetFeatureMark"] = function(_ARG_0_)
    do
      if not SubsystemMgr:Get((U1(48, 29, 82, 190, 42, 28, 203, 214, 72, 197, 58, 132, 169, 9, 139, 109, 225, 38, 55, 188, 194, 43, 155, 250, 71, 199, 38, 156))) then
        return
      end
      goto lbl_55
      ::lbl_55::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return 0 | 1 << 190 - 1 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnWeaponFireShot"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and U1(41, 27, 90, 171, 40, 62, 234, 210, 84, 203, 54, 147, 173, 25, 136, 74, 240, 48, 49, 138, 218, 115, 167, 237, 99, 214, 34, 129, 129, 18, 188, 96, 235, 54, 6, 151, 200, 45))
      if not _ARG_0_.bIsPhotoGrapherMode then
        return
      end
      if not slua.isValid((U2.GetPlayerController())) then
        return false
      end
      if not slua.isValid((U2.GetPlayerController():GetPlayerCharacterSafety())) then
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPetAvatarRequirementMatch"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return true
      end
      if slua_GameFrontendHUD:GetPlayerController():GetCurrentPetInfo() and slua_GameFrontendHUD:GetPlayerController():GetCurrentPetInfo().PetAvatarList then
        goto lbl_45
        goto lbl_43
        if tostring(nil) == nil then
          return true
        end
        ::lbl_43::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        ::lbl_45::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsCamTemplateShouldShow"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not _ARG_1_.DisplayModList_a then
        return true
      end
      if _ARG_1_.DisplayModList_a:Num() <= 0 then
        return true
      end
      goto lbl_65
      if require((U1(62, 18, 88, 186, 11, 12, 249, 157, 99, 194, 62, 132, 189, 3, 152, 124, 167, 14, 36, 134, 217, 103, 175, 226, 89, 214, 14, 144, 135, 18, 185, 102, 247, 53, 60, 152))).GetModeID() == 11 then
        return true
      end
      ::lbl_65::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = U1[247]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}) end
return
