local NewCamera_Photo_UIBP = {}
local NewCameraConfig = require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieConfig")
local CameraMode = NewCameraConfig.CameraMode
local NewCamera_Photo_UIConfig = require("GameLua.Mod.Library.Client.Photo.NewCamera_Photo_UIConfig")
local ESystem = NewCamera_Photo_UIConfig.ESystem
local EMainSysListType = NewCamera_Photo_UIConfig.EMainSysListType
local EHideUIType = NewCamera_Photo_UIConfig.EHideUIType
local HideUIGroup = NewCamera_Photo_UIConfig.HideUIGroup
local HideUIWidgetConfig = NewCamera_Photo_UIConfig.HideUIWidgetConfig
local CJoystickHideCheckNodes = NewCamera_Photo_UIConfig.CJoystickHideCheckNodes
local EPhotoUIDisplayState = NewCamera_Photo_UIConfig.EPhotoUIDisplayState
local StateToHideUIType = NewCamera_Photo_UIConfig.StateToHideUIType
local NewCameraUtil = require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfieUtil")
local GameplayData = require("GameLua.GameCore.Data.GameplayData")
local NewCameraTLogReport = require("GameLua.Mod.Library.GamePlay.Camera.NewCamera_IngameSelfie_TLog_Report")
local EPawnState = import("EPawnState")
local logic_emote = require("GameLua.Mod.Library.GamePlay.Avatar.Emote.logic_emote")
local time_ticker = require("common.time_ticker")

function NewCamera_Photo_UIBP:ctor(selfType, bAutoStartSmartCamera, ExternalPhotoUIDisplayState)
  self._curMainSysID = nil
  self._curSubSysID = nil
  self._curReplaceableSubSysID = nil
  self._curReplaceableSubSysPanel = nil
  self._sysPanels = {}
  self._curEmotionCategoryID = nil
  self._curEmoteID = nil
  self._emoteListByCategory = {}
  self._emoteToCategory = {}
  self._bEmotionDataInited = false
  self._forceShowReferenceLine = false
  self._pendingSpecificZoom = nil
  self._isPendingExitClose = false
  self._exitFailsafeTimer = nil
  self._zoomPinchVisibilityCheckTimer = nil
  self._bPinchDisabledByHideGroup = false
  local externalPhotoUIDisplayState
  if type(ExternalPhotoUIDisplayState) == "number" and ExternalPhotoUIDisplayState ~= EPhotoUIDisplayState.None then
    externalPhotoUIDisplayState = ExternalPhotoUIDisplayState
  end
  self._externalPhotoUIDisplayState = externalPhotoUIDisplayState
end

function NewCamera_Photo_UIBP:OnInitialize()
  self:_InitSystemConfig()
  self:_InitComponents()
  self:_InitHDRSwitch()
  self:_InitPinchEvent()
  self:_InitChangeWeatherSign()
  self:InitHideUIGroup(HideUIGroup, HideUIWidgetConfig)
  self.LoopScrollBox_SubSystem = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_SubSystem, "GameLua.Mod.Library.Client.Photo.Items.NewCamera_Photo_Icon_Item_UIBP")
  self.LoopScrollBox_Filter = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_Filter, "GameLua.Mod.Library.Client.Photo.Items.NewCamera_Photo_Filter_Item_UIBP")
  self.LoopScrollBox_EmotionList_Alpha = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_EmotionList_Alpha, "GameLua.Mod.Library.Client.Photo.Items.NewCamera_Photo_Emotion_Item_UIBP")
  self.LoopScrollBox_EmotionList_Beta = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_EmotionList_Beta, "GameLua.Mod.Library.Client.Photo.Items.NewCamera_Photo_Emotion_Item_UIBP")
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_RightParent, false)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_EmotionList_Beta, false)
  self:SetWidgetVisible(self.UIRoot.Border_HideUI, false)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_FixedModeControl, false)
  self:SetWidgetVisible(self.UIRoot.Button_SaveToFilterTemplate, self._isInHDR, true)
  self:SetWidgetVisible(self.UIRoot.SizeBox_FilterSetting, self._isInHDR)
  self:SetWidgetVisible(self.UIRoot.Button_Drone, true, true)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_DroneControl, false)
  self.UIRoot.Button_Exit:SetIsEnabled(true)
  local emotionStr = LocUtil.GetLocalizeResStr(46186)
  self.UIRoot.TextBlock_Button_Emotion:SetText(emotionStr)
  self.UIRoot.TextBlock_Button_Emotion2:SetText(emotionStr)
end

function NewCamera_Photo_UIBP:RegistEvents()
  self:AddOnClickedEventByControl(self.UIRoot.Button_Exit, self.OnButton_ExitClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Camera, self.OnButton_CameraClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Reset, self.OnButton_ResetClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_FixedMode, self.OnButton_FixedModeClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_MoveMode, self.OnButton_MoveModeClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_HideUI, self.OnButton_HideUIClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_ShowUI, self.OnButton_ShowUIClick, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_CameraSetting, self.OnClickSubSystem, self, ESystem.CameraSetting)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Suit, self.OnClickSubSystem, self, ESystem.Suit)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Album, self.OnClickButton_Album, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_CameraBaseSetting, self.OnClickMainSystem, self, ESystem.CameraBaseSetting)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Emotion, self.OnClickMainSystem, self, ESystem.Emotion)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Graphics, self.OnClickMainSystem, self, ESystem.Graphics)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Filter, self.OnClickMainSystem, self, ESystem.Filter)
  self:AddOnClickedEventByControl(self.UIRoot.Button_ActionSequence, self.OnClickButton_ActionSequence, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_EmotionSelected, self.OnClickReplaceableSubSystem, self, ESystem.EmotionSub)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Drone, self.OnClickButton_Drone, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_SaveToFilterTemplate, self.OnClickButton_SaveToFilterTemplate, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_FilterSetting, self.OnClickButton_FilterSetting, self)
  self:AddControlEventByControl(self.UIRoot.Border_HideUI, "OnMouseButtonDownEvent", self.OnTouchDownBorder_HideUI, self)
  self:AddControlEventByControl(self.UIRoot.Border_HideUI, "OnMouseMoveEvent", self.OnTouchMoveBorder_HideUI, self)
  self:AddControlEventByControl(self.UIRoot.Border_HideUI, "OnMouseButtonUpEvent", self.OnTouchUpBorder_HideUI, self)
  self:AddControlEventByControl(self.UIRoot.Fadeout, "OnAnimationFinished", self.OnAnimFadeoutFinished, self)
  self:AddControlEventByControl(self.UIRoot.Anim_Switch_mode, "OnAnimationFinished", self.OnAnim_Switch_modeFinished, self)
  self:AddControlEventByControl(self.UIRoot.Fadeout_Hide, "OnAnimationFinished", self.OnFadeout_HideFinished, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_MODE_CHANGED, self.OnCameraModeChanged, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_UI_TRANSPARENT_CHANGED, self.OnUITransparentChanged, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_SET_REFERENCE_LINE_SHOW, self.OnRefreshReferenceLineShow, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_INGAME_ENTER_SMART_CAMERA, self.OnEnterSmartCamera, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_INGAME_PHOTOGRAPHER_SEQ_FINISH, self.OnCameraSeqFinish, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_INGAME_START_CAMERA_SCREENSHOT, self.OnCameraScreenShotBegin, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_INGAME_END_CAMERA_SCREENSHOT, self.OnCameraScreenShotEnd, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_CLOSE_CURRENT_SUBSYSTEM, self.OnCloseCurrentSubsystem, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_CLOSE_CURRENT_REPLACEABLE_PANEL, self.OnCloseCurrentReplaceablePanel, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_EMOTE_SELECTED, self.OnEmoteSelected, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_START_CONTROL_DRONE, self.OnStartControlDrone, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_STOP_CONTROL_DRONE, self.OnStopControlDrone, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_START_PAN_CAMERA, self.OnStartPanCamera, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_STOP_PAN_CAMERA, self.OnStopPanCamera, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_START_ROLE_ROTATION, self.OnStartRoleRotation, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_STOP_ROLE_ROTATION, self.OnStopRoleRotation, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_START_ZOOM_DRAG, self.OnStartZoomDrag, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_STOP_ZOOM_DRAG, self.OnStopZoomDrag, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_START_HEAD_AIM_DRAG, self.OnStartHeadAimDrag, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_STOP_HEAD_AIM_DRAG, self.OnStopHeadAimDrag, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_ON_PLAYER_ENTER_SPECIAL_STATE, self.OnPlayerEnterSpecialState, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_FOCUS_LOCK_STATE_CHANGED, self.OnFocusLockStateChanged, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_FILTER_CHANGED, self.OnFilterChanged, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_CLOSE_EMOTION, self.OnCloseEmotion, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_ON_FILTER_TEMPLATE_SAVE, self.OnFilterTemplateSave, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_ON_FILTER_TEMPLATE_NAME_CHANGE, self.OnFilterTemplateNameChange, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_ON_FILTER_TEMPLATE_DELETE, self.OnFilterTemplateDelete, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_ON_ENTER_RECORD_PREVIEW, self.OnEnterRecordPreview, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_ON_EXIT_RECORD_PREVIEW, self.OnExitRecordPreview, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_ON_PLAY_ACTION_SEQUENCE, self.OnPlayActionSequence, self)
  self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_NEW_CAMERA_ON_END_ACTION_SEQUENCE, self.OnEndActionSequence, self)
  if EVENTID_PLANPH_ONREP_INTERACTIVCE_STATE then
    self:AddCommonEvent(EVENTTYPE_PLANPH_NORMAL, EVENTID_PLANPH_ONREP_INTERACTIVCE_STATE, self.OnRepInteractiveState, self)
  end
  GameplayData.AddSelfPlayerCharacterEventWithCondition(self, "StateEnterHandler", {
    state = {
      EPawnState.Swim,
      EPawnState.Move
    }
  }, self.StateEnterHandler, self)
  GameplayData.AddSelfPlayerCharacterEventWithCondition(self, "StateLeaveHandler", {
    state = {
      EPawnState.Swim,
      EPawnState.Move
    }
  }, self.StateLeaveHandler, self)
  self:RegistCrouch()
  self:RegistJump()
  self:RegistEventsProne()
  self:RegistSwim()
  self:RegistAutoSprint()
  self:RegistCustomJoystick(self.UIRoot.NewCamera_Photo_MoveJoystick_UIBP)
end

function NewCamera_Photo_UIBP:_InitPinchEvent()
  self:AddTimerOnce(0, function()
    self:_EnablePinch(true)
    self:AddControlEventByControl(self.UIRoot, "OnPinch", self.OnPinchEvent, self)
    self:AddControlEventByControl(self.UIRoot, "OnRelease", self.OnPinchReleaseEvent, self)
  end)
end

function NewCamera_Photo_UIBP:_InitChangeWeatherSign()
  local IngameSelfieWeatherSubsystem = SubsystemMgr:Get("IngameSelfieWeatherSubsystem")
  local isSupportWeather = false
  if IngameSelfieWeatherSubsystem then
    isSupportWeather = IngameSelfieWeatherSubsystem:IsSupportChangingWeather()
  end
  self.bIsSupportChangeWeather = isSupportWeather
  log(bWriteLog and "NewCamera_Photo_UIBP:_InitChangeWeatherSign - bIsSupportChangeWeather = " .. tostring(isSupportWeather))
end

function NewCamera_Photo_UIBP:OnPostInitialize()
  local mode = self:_GetCameraMode()
  self:_HideSystemByHDR()
  self:_RefreshCameraModeUI(mode)
  self:_RefreshUITransparent()
  self:_RefreshReferenceLineShow()
  self:_RefreshEmotionSelectedShow()
  self:_RefreshMoveControlShow()
  self:_RefreshUIShowByInteractiveState()
  self:_RefreshUIShowByPlayerState()
  self:_RefreshUIShowByVehicleState()
  self:_ApplyPhotoUIDisplayState(self:_ResolvePhotoUIDisplayState())
  self:_StartFrameLoadComponents()
  self:PlayUserWidgetAnimation(self.UIRoot.Fadein, 0, 1, 0, 1)
  self:AddTimerOnce(0, function()
    EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_INGAME_SELFIE_UI_INIT_COMPLETE)
  end)
end

function NewCamera_Photo_UIBP:OnConstruct(...)
  if not self._isPendingExitClose then
    return
  end
  self._isPendingExitClose = false
  if self._exitFailsafeTimer then
    self:RemoveTimer(self._exitFailsafeTimer)
    self._exitFailsafeTimer = nil
  end
  self.UIRoot.Button_Exit:SetIsEnabled(true)
  self:PlayUserWidgetAnimation(self.UIRoot.Fadein, 0, 1, 0, 1)
end

function NewCamera_Photo_UIBP:OnClose()
  log(bWriteLog and "NewCamera_Photo_UIBP:OnClose")
  self:ClearHideUIGroup()
  self:StopJoyStick()
  if self._zoomPinchVisibilityCheckTimer then
    self:RemoveTimer(self._zoomPinchVisibilityCheckTimer)
    self._zoomPinchVisibilityCheckTimer = nil
  end
  local ActionSequenceData = require("GameLua.Mod.Library.Client.Photo.Items.NewCamera_Photo_ActionSequence_Data")
  ActionSequenceData.Reset()
end

function NewCamera_Photo_UIBP:OnAndroidBack()
end

function NewCamera_Photo_UIBP:OnButton_ExitClick()
  self:PlayAudio(sound_config.close)
  log(bWriteLog and "NewCamera_Photo_UIBP:OnButton_ExitClick")
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if not IngameSelfieSubsystem then
    log(bWriteLog and "NewCamera_Photo_UIBP:OnButton_ExitClick cannot get IngameSelfieSubsystem")
    return
  end
  IngameSelfieSubsystem:ExitSelfie(NewCameraTLogReport.EExitReason.Active)
end

function NewCamera_Photo_UIBP:_CloseAfterExitFadeout()
  if not self._isPendingExitClose then
    return
  end
  self._isPendingExitClose = false
  self:CloseSelf()
end

function NewCamera_Photo_UIBP:OnButton_CameraClick()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "NewCamera_Photo_UIBP:OnButton_CameraClick")
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if not IngameSelfieSubsystem then
    log(bWriteLog and "NewCamera_Photo_UIBP:OnButton_CameraClick cannot get IngameSelfieSubsystem")
    return
  end
  IngameSelfieSubsystem:StartCameraScreenShot()
end

function NewCamera_Photo_UIBP:OnButton_ResetClick()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "NewCamera_Photo_UIBP:OnButton_ResetClick")
  self:_ResetAll()
  NewCameraTLogReport.ReportFeature(NewCameraTLogReport.EFeatureIDs.Reset, 1)
end

function NewCamera_Photo_UIBP:OnButton_FixedModeClick()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "NewCamera_Photo_UIBP:OnButton_FixedModeClick")
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if not IngameSelfieSubsystem then
    return
  end
  IngameSelfieSubsystem:SwitchCameraMode(CameraMode.Fixed)
  NewCameraTLogReport.ReportFeature(NewCameraTLogReport.EFeatureIDs.ModeSwitch, CameraMode.Fixed)
  self:PlayUserWidgetAnimation(self.UIRoot.Anim_Switch_mode, 0, 1, 1, 1)
end

function NewCamera_Photo_UIBP:OnButton_MoveModeClick()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "NewCamera_Photo_UIBP:OnButton_MoveModeClick")
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if not IngameSelfieSubsystem then
    return
  end
  IngameSelfieSubsystem:SwitchCameraMode(CameraMode.Move)
  NewCameraTLogReport.ReportFeature(NewCameraTLogReport.EFeatureIDs.ModeSwitch, CameraMode.Move)
  self:PlayUserWidgetAnimation(self.UIRoot.Anim_Switch_mode, 0, 1, 0, 1)
end

function NewCamera_Photo_UIBP:OnButton_HideUIClick()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "NewCamera_Photo_UIBP:OnButton_HideUIClick")
  self:SetWidgetVisible(self.UIRoot.Border_HideUI, true, true)
  self:_RefreshHideButtonShow(false)
  self:_StartAutoHideUIShowEntryTimer()
  self:StopJoyStick()
  NewCameraTLogReport.ReportFeature(NewCameraTLogReport.EFeatureIDs.HideInterface, 1)
  self:PlayUserWidgetAnimation(self.UIRoot.Fadeout_Hide, 0, 1, 0, 1)
end

function NewCamera_Photo_UIBP:OnButton_ShowUIClick()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "NewCamera_Photo_UIBP:OnButton_ShowUIClick")
  self:SetWidgetVisible(self.UIRoot.Border_HideUI, false)
  self:_RefreshMainCameraUI(true)
  self:_RefreshHideButtonShow(true)
  NewCameraTLogReport.ReportFeature(NewCameraTLogReport.EFeatureIDs.HideInterface, 0)
  self:PlayUserWidgetAnimation(self.UIRoot.Fadeout_Hide, 0, 1, 1, 1)
end

function NewCamera_Photo_UIBP:OnClickButton_Album()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "NewCamera_Photo_UIBP:OnClickButton_Album")
  local LGameStatus = GameStatus
  if LGameStatus.IsPHomeMode() then
    local moment_macro = require("client.slua.logic.moment.moment_macro")
    local ENUM_ALBUM_PHOTO_TAB_TYPE = moment_macro.ENUM_ALBUM_PHOTO_TAB_TYPE
    local params = {
      openSource = NewCameraTLogReport.EPhotoOpenSourceType.Home,
      photoCombobox = ENUM_ALBUM_PHOTO_TAB_TYPE.HomeAlbum
    }
    UIManager.ShowUI(UIManager.UI_Config.UI_Moment_Main_UIBP, params)
    return
  end
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if IngameSelfieSubsystem then
    IngameSelfieSubsystem:OpenNewCameraPhotoUI()
  end
end

function NewCamera_Photo_UIBP:OnClickButton_ActionSequence()
  self:PlayAudio(sound_config.tab_v1)
  if self:_IsLeadingPartyDance() then
    ShowNotice(66372)
    return
  end
  if self._curMainSysID == ESystem.ActionSequence then
    self:_OnClickMainSystem(ESystem.ActionSequence)
    return
  end
  self:_OnClickMainSystem(ESystem.ActionSequence)
  self:_OnClickSubSystem(ESystem.ActionSequenceSub)
end

function NewCamera_Photo_UIBP:OnClickMainSystem(sysID)
  self:PlayAudio(sound_config.tab_v1)
  self:_OnClickMainSystem(sysID)
end

function NewCamera_Photo_UIBP:OnClickSubSystem(sysID)
  self:PlayAudio(sound_config.subTab_v1)
  self:_OnClickSubSystem(sysID)
end

function NewCamera_Photo_UIBP:_IsLeadingPartyDance()
  local uGS = CGameState
  if not uGS or not uGS.GetDanceLeadInfo then
    return false
  end
  local leadInfo = uGS:GetDanceLeadInfo()
  if not leadInfo or not leadInfo.bOccupied then
    return false
  end
  local uMyChar = GameplayData.GetPlayerCharacter()
  if not slua.isValid(uMyChar) then
    return false
  end
  return leadInfo.PlayerUID == tostring(uMyChar.PlayerUID)
end

function NewCamera_Photo_UIBP:OnClickReplaceableSubSystem(sysID)
  self:PlayAudio(sound_config.click_v1)
  self:_OnClickReplaceableSubSystem(sysID)
end

function NewCamera_Photo_UIBP:OnClickButton_Drone()
  self:PlayAudio(sound_config.click_v1)
  local droneControlComp = self:_EnsureDroneControlComp()
  if not droneControlComp then
    log_error(bWriteLog and "[ERROR] NewCamera_Photo_UIBP:OnClickButton_Drone mount drone control panel failed")
    return
  end
  NewCameraTLogReport.ReportDroneEntry(NewCameraTLogReport.EDroneEntrySource.TopBar)
  droneControlComp:StartDroneControl()
end

function NewCamera_Photo_UIBP:OnClickButton_SaveToFilterTemplate()
  self:PlayAudio(sound_config.click_v1)
  NewCameraTLogReport.ReportFilterTemplateEntry(NewCameraTLogReport.EFilterTemplateEntryType.MainUI)
  UIManager.ShowUI(UIManager.UI_Config_InGame.NewCamera_Photo_FilterTemplate_Detail_UIBP, true)
end

function NewCamera_Photo_UIBP:OnClickButton_FilterSetting()
  self:PlayAudio(sound_config.click_v1)
  UIManager.ShowUI(UIManager.UI_Config_InGame.NewCamera_Photo_FilterTemplate_UIBP)
end

function NewCamera_Photo_UIBP:OnTouchDownBorder_HideUI()
  self:_ReShowUIShowEntry()
end

function NewCamera_Photo_UIBP:OnTouchMoveBorder_HideUI()
end

function NewCamera_Photo_UIBP:OnTouchUpBorder_HideUI()
  self:_StartAutoHideUIShowEntryTimer()
end

function NewCamera_Photo_UIBP:OnAnimFadeoutFinished()
  if self._exitFailsafeTimer then
    self:RemoveTimer(self._exitFailsafeTimer)
    self._exitFailsafeTimer = nil
  end
  self:_CloseAfterExitFadeout()
end

function NewCamera_Photo_UIBP:OnAnim_Switch_modeFinished()
  if self:_GetCameraMode() == CameraMode.Fixed then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_FixedModeControl, false)
  end
end

function NewCamera_Photo_UIBP:OnFadeout_HideFinished()
  if self._autoHideUIShowEntryTimer ~= nil then
    self:_RefreshMainCameraUI(false)
  end
end

function NewCamera_Photo_UIBP:_IsInDroneMode()
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if IngameSelfieSubsystem and IngameSelfieSubsystem.IsInDroneMode then
    return IngameSelfieSubsystem:IsInDroneMode()
  end
  return false
end

function NewCamera_Photo_UIBP:OnPinchEvent(ScaleDelta)
  log_format("NewCamera_Photo_UIBP:OnPinchEvent - ScaleDelta: %s", ScaleDelta)
  if not self.zoomChangeComp then
    return
  end
  self.zoomChangeComp:OnPinchEvent(ScaleDelta)
end

function NewCamera_Photo_UIBP:OnPinchReleaseEvent()
  log(bWriteLog and "NewCamera_Photo_UIBP:OnPinchReleaseEvent")
  if not self.zoomChangeComp then
    return
  end
  self.zoomChangeComp:OnPinchReleaseEvent()
end

function NewCamera_Photo_UIBP:_OnClickSubSystemListItem(index)
  log_format("NewCamera_Photo_UIBP:_OnClickSubSystemListItem - index: %s", index)
  local itemData = self.LoopScrollBox_SubSystem:GetItemData(index)
  if not itemData then
    return
  end
  local sysID = itemData.sysID
  local isCurrent = self._curSubSysID == sysID
  if isCurrent then
    self.LoopScrollBox_SubSystem:Deselect()
  else
    self.LoopScrollBox_SubSystem:Select(index)
  end
  self:_OnClickSubSystem(sysID)
end

function NewCamera_Photo_UIBP:_OnClickEmotionAlphaListItem(index)
  local itemData = self.LoopScrollBox_EmotionList_Alpha:GetItemData(index)
  if not itemData then
    return
  end
  local categoryID = itemData.categoryID
  local isCurrent = self._curEmotionCategoryID == categoryID
  if isCurrent then
    self.LoopScrollBox_EmotionList_Alpha:Deselect()
    self._curEmotionCategoryID = nil
  else
    self.LoopScrollBox_EmotionList_Alpha:Select(index)
    self._curEmotionCategoryID = categoryID
  end
  local hasSelectedCategory = self._curEmotionCategoryID ~= nil
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_EmotionList_Beta, hasSelectedCategory)
  self:_BuildEmotionBetaList()
end

function NewCamera_Photo_UIBP:_OnClickEmotionBetaListItem(index)
  local itemData = self.LoopScrollBox_EmotionList_Beta:GetItemData(index)
  if not itemData then
    return
  end
  if not NewCameraUtil.CheckCanPlayEmote() then
    ShowNotice(30121)
    return
  end
  local emoteID = itemData.emoteID
  if not NewCameraUtil.GetIsEmoteExist(emoteID) then
    ShowNotice(27679)
    return
  end
  local bEmoteIsBan, TipsID = logic_emote.CheckEmoteIsBan(emoteID)
  if bEmoteIsBan then
    if TipsID then
      ShowNotice(TipsID)
    end
    return
  end
  self.LoopScrollBox_EmotionList_Beta:Select(index)
  self._curEmoteID = emoteID
  self._curEmotionCategoryID = itemData.categoryID
  if self._curSubSysID ~= ESystem.EmotionSub then
    self:_OnClickSubSystem(ESystem.EmotionSub)
  end
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if IngameSelfieSubsystem then
    IngameSelfieSubsystem:SetEmoteSelection(itemData.categoryID, itemData.emoteID)
  end
end

function NewCamera_Photo_UIBP:_OnClickFilterListItem(index)
  log_format("NewCamera_Photo_UIBP:_OnClickFilterListItem - index: %s", index)
  local itemData = self.LoopScrollBox_Filter:GetItemData(index)
  if not itemData then
    return
  end
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  local curFilterID = IngameSelfieSubsystem:GetSelectedFilterID()
  local config = itemData.config
  local isCurrent = curFilterID == config.ID
  local isCurrentSub = self._curSubSysID == ESystem.FilterSub
  local changeFilterID
  if isCurrent and self._isInHDR then
    self.LoopScrollBox_Filter:Deselect()
    curFilterID = nil
    IngameSelfieSubsystem:SetSelectedFilterID(nil)
    if isCurrentSub then
      self:_CloseCurrentSubSystem()
    end
  else
    self.LoopScrollBox_Filter:Select(index)
    if not isCurrentSub then
      self:_OnClickSubSystem(ESystem.FilterSub)
    end
    changeFilterID = config.ID
    curFilterID = changeFilterID
  end
  IngameSelfieSubsystem:SetSelectedFilterID(curFilterID)
  IngameSelfieSubsystem:ChangeFilter(curFilterID, config)
  NewCameraTLogReport.ReportFeature(NewCameraTLogReport.EFeatureIDs.FilterID, curFilterID)
end

function NewCamera_Photo_UIBP:OnCameraModeChanged(eventType, eventID, mode)
  log_format("NewCamera_Photo_UIBP:OnCameraModeChanged - mode: %s", mode)
  self:_RefreshCameraModeUI(mode)
end

function NewCamera_Photo_UIBP:OnUITransparentChanged()
  log(bWriteLog and "NewCamera_Photo_UIBP:OnUITransparentChanged")
  self:_RefreshUITransparent()
end

function NewCamera_Photo_UIBP:OnRefreshReferenceLineShow()
  log(bWriteLog and "NewCamera_Photo_UIBP:OnRefreshReferenceLineShow")
  self:_RefreshReferenceLineShow()
end

function NewCamera_Photo_UIBP:OnEnterSmartCamera()
  log(bWriteLog and "NewCamera_Photo_UIBP:OnEnterSmartCamera")
  self:_OnClickHideUIGroup(EHideUIType.SmartCamera, false)
  self:_RefreshFreeViewShow()
  self:_RefreshHeadAimShow()
end

function NewCamera_Photo_UIBP:OnCameraSeqFinish()
  log(bWriteLog and "NewCamera_Photo_UIBP:OnCameraSeqFinish")
  local PhotoGrapherSubSystem = SubsystemMgr:Get("PhotoGrapherSubSystem")
  if not PhotoGrapherSubSystem then
    return
  end
  if not PhotoGrapherSubSystem.bIsPhotoGrapherMode then
    log_warning(bWriteLog and "NewCamera_Photo_UIBP:OnCameraSeqFinish not in photographer mode")
    return
  end
  self:_OnClickHideUIGroup(EHideUIType.SmartCamera, true)
  self:_RefreshFreeViewShow()
  self:_RefreshHeadAimShow()
end

function NewCamera_Photo_UIBP:OnCameraScreenShotBegin()
  log(bWriteLog and "NewCamera_Photo_UIBP:OnCameraScreenShotBegin")
  self:_OnClickHideUIGroup(EHideUIType.Photoing, false)
  self:StopJoyStick()
end

function NewCamera_Photo_UIBP:OnCameraScreenShotEnd()
  log(bWriteLog and "NewCamera_Photo_UIBP:OnCameraScreenShotEnd")
  self:_OnClickHideUIGroup(EHideUIType.Photoing, true)
end

function NewCamera_Photo_UIBP:OnCloseCurrentSubsystem()
  log(bWriteLog and "NewCamera_Photo_UIBP:OnCloseCurrentSubsystem")
  self:_CloseCurrentSubSystem()
end

function NewCamera_Photo_UIBP:OnCloseCurrentReplaceablePanel(_, _, bReturnPreSubSystem)
  log(bWriteLog and "NewCamera_Photo_UIBP:OnCloseCurrentReplaceablePanel")
  self:_CloseCurrentReplaceablePanel(bReturnPreSubSystem)
end

function NewCamera_Photo_UIBP:OnEmoteSelected()
  log(bWriteLog and "NewCamera_Photo_UIBP:OnEmoteSelected")
  self:_RefreshEmotionSelectedIcon()
end

function NewCamera_Photo_UIBP:OnStartControlDrone()
  log(bWriteLog and "NewCamera_Photo_UIBP:OnStartControlDrone")
  local droneControlComp = self:_EnsureDroneControlComp()
  self:_OnClickHideUIGroup(EHideUIType.Drone, false)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_DroneControl, true)
  if droneControlComp then
    droneControlComp:Show()
  else
    log_error(bWriteLog and "[ERROR] NewCamera_Photo_UIBP:OnStartControlDrone mount drone control panel failed")
  end
end

function NewCamera_Photo_UIBP:OnStopControlDrone()
  self:_OnClickHideUIGroup(EHideUIType.Drone, true)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_DroneControl, false)
  if not self.droneControlComp then
    log(bWriteLog and "NewCamera_Photo_UIBP:OnStopControlDrone droneControlComp not mounted")
    return
  end
  if self.droneControlComp.InterruptRecording then
    self.droneControlComp:InterruptRecording()
  end
  self.droneControlComp:Hide()
end

function NewCamera_Photo_UIBP:OnStartPanCamera()
  self._forceShowReferenceLine = true
  self:_RefreshReferenceLineShow()
  self:_OnClickHideUIGroup(EHideUIType.CameraPanDrag, false)
end

function NewCamera_Photo_UIBP:OnStopPanCamera()
  self._forceShowReferenceLine = false
  self:_RefreshReferenceLineShow()
  self:_OnClickHideUIGroup(EHideUIType.CameraPanDrag, true)
end

function NewCamera_Photo_UIBP:OnStartRoleRotation()
  self:_OnClickHideUIGroup(EHideUIType.RoleRotateDrag, false)
end

function NewCamera_Photo_UIBP:OnStopRoleRotation()
  self:_OnClickHideUIGroup(EHideUIType.RoleRotateDrag, true)
end

function NewCamera_Photo_UIBP:OnStartZoomDrag()
  self:_OnClickHideUIGroup(EHideUIType.ZoomDrag, false)
end

function NewCamera_Photo_UIBP:OnStopZoomDrag()
  self:_OnClickHideUIGroup(EHideUIType.ZoomDrag, true)
end

function NewCamera_Photo_UIBP:OnStartHeadAimDrag()
  self:_OnClickHideUIGroup(EHideUIType.HeadAimDrag, false)
end

function NewCamera_Photo_UIBP:OnStopHeadAimDrag()
  self:_OnClickHideUIGroup(EHideUIType.HeadAimDrag, true)
end

function NewCamera_Photo_UIBP:OnPlayerEnterSpecialState()
  if self._curSubSysID == ESystem.EmotionSub then
    self:_CloseCurrentSubSystem()
  end
  self:_CloseCurrentReplaceablePanel()
  self:_RefreshEmotionSelectedShow()
end

function NewCamera_Photo_UIBP:OnFocusLockStateChanged()
  self:_RefreshFreeViewShow()
  self:_RefreshHeadAimShow()
end

function NewCamera_Photo_UIBP:OnFilterChanged()
  if not self._isInHDR then
    return
  end
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if not IngameSelfieSubsystem then
    log(bWriteLog and "NewCamera_Photo_UIBP:OnButton_ResetClick cannot get IngameSelfieSubsystem")
    return
  end
  local currentConfig = IngameSelfieSubsystem:GetCurrentFilterConfig()
  if not currentConfig then
    self:OnResetFilter()
  end
end

function NewCamera_Photo_UIBP:OnCloseEmotion()
  self._curEmoteID = nil
  self:_CloseCurrentReplaceablePanel()
  self:_RefreshEmotionSelectedShow()
  self.LoopScrollBox_EmotionList_Beta:Deselect()
end

function NewCamera_Photo_UIBP:OnFilterTemplateSave()
  if self._curMainSysID == ESystem.Filter then
    self:_BuildFilterList()
  end
end

function NewCamera_Photo_UIBP:OnFilterTemplateNameChange()
  if self._curMainSysID == ESystem.Filter then
    self:_BuildFilterList()
  end
end

function NewCamera_Photo_UIBP:OnFilterTemplateDelete()
  if self._curMainSysID == ESystem.Filter then
    self:_BuildFilterList()
  end
end

function NewCamera_Photo_UIBP:OnEnterRecordPreview()
  self:_OnClickHideUIGroup(EHideUIType.RecordPreview, false)
end

function NewCamera_Photo_UIBP:OnExitRecordPreview()
  self:_OnClickHideUIGroup(EHideUIType.RecordPreview, true)
end

function NewCamera_Photo_UIBP:OnPlayActionSequence()
  self:_OnClickHideUIGroup(EHideUIType.PlayActionSequence, false)
end

function NewCamera_Photo_UIBP:OnEndActionSequence()
  self:_OnClickHideUIGroup(EHideUIType.PlayActionSequence, true)
end

function NewCamera_Photo_UIBP:OnRepInteractiveState()
  self:_RefreshUIShowByInteractiveState()
end

function NewCamera_Photo_UIBP:StateEnterHandler(state)
  if state == EPawnState.Swim then
    self:_StateSwimEnterHandler()
  elseif state == EPawnState.Move then
    self:_StateMoveEnterHandler()
  end
end

function NewCamera_Photo_UIBP:_StateSwimEnterHandler()
  self:_RefreshMoveControlShow(true)
end

function NewCamera_Photo_UIBP:_StateMoveEnterHandler()
  self:_OnClickHideUIGroup(EHideUIType.RoleMove, false)
end

function NewCamera_Photo_UIBP:StateLeaveHandler(state)
  if state == EPawnState.Swim then
    self:_StateSwimLeaveHandler()
  elseif state == EPawnState.Move then
    self:_StateMoveLeaveHandler()
  end
end

function NewCamera_Photo_UIBP:_StateSwimLeaveHandler()
  self:_RefreshMoveControlShow(false)
end

function NewCamera_Photo_UIBP:_StateMoveLeaveHandler()
  self:_OnClickHideUIGroup(EHideUIType.RoleMove, true)
end

function NewCamera_Photo_UIBP:_InitSystemConfig()
  self._sysConfig = NewCamera_Photo_UIConfig.GetSystemConfig()
  self._subToMain = {}
  for sysID, v in pairs(self._sysConfig) do
    self:_SetSystemWidgetShow(sysID, false)
    local sysList = v.sysList
    if sysList then
      for k, subID in pairs(sysList) do
        self._subToMain[subID] = sysID
      end
    end
  end
end

function NewCamera_Photo_UIBP:_InitEmotionData()
  if self._bEmotionDataInited then
    return
  end
  local EEmotionCategory = NewCamera_Photo_UIConfig.EEmotionCategory
  local playerController = GameplayData.GetPlayerController()
  self._emoteListByCategory = {}
  self._emoteToCategory = {}
  if not slua.isValid(playerController) then
    return
  end
  
  local function addToMap(emoteID, categoryID, hasLock)
    if not emoteID or self._emoteToCategory[emoteID] then
      return
    end
    self._emoteToCategory[emoteID] = categoryID
    local list = self._emoteListByCategory[categoryID]
    if not list then
      list = {}
      self._emoteListByCategory[categoryID] = list
    end
    table.insert(list, {
      id = emoteID,
      hasLock = hasLock or false
    })
  end
  
  local QuickExpressionUtils = require("GameLua.Mod.BaseMod.Client.Emote.QuickExpressionUtils")
  local tShowEmoteList = QuickExpressionUtils.GetShowExpressionList()
  if GameStatus.IsInMainCity() then
    local MainCity_GamePlay_Tools = require("GameLua.Mod.MainCity.Tools.MainCity_GamePlay_Tools")
    tShowEmoteList = MainCity_GamePlay_Tools.GetExpressionItems()
  end
  if tShowEmoteList then
    for _, data in pairs(tShowEmoteList) do
      local emoteID = data.DefineID and data.DefineID.TypeSpecificID
      if emoteID then
        if NewCameraConfig.IgnoreEmoteConfig[emoteID] then
          printf("NewCamera_Photo_UIBP:_InitEmotionData skip highlight emote, emoteID:%s", tostring(emoteID))
        elseif NewCameraUtil.CheckIsHighlightMomentEmote(emoteID) then
          printf("NewCamera_Photo_UIBP:_InitEmotionData skip ignore emote, emoteID:%s", tostring(emoteID))
        elseif logic_emote.CheckIsDanceTogetherEmote(emoteID) then
          printf("NewCamera_Photo_UIBP:_InitEmotionData skip dance together emote, emoteID:%s", tostring(emoteID))
        else
          addToMap(data.DefineID.TypeSpecificID, EEmotionCategory.Emote)
        end
      end
    end
  end
  local petID, petSkinID
  local playerCharacter = playerController:GetPlayerCharacterSafety()
  if slua.isValid(playerCharacter) and slua.isValid(playerCharacter.PetComponent_BP) then
    if slua.isValid(playerCharacter.PetComponent_BP.PetPawn) and playerCharacter.PetComponent_BP.PetPawn.PetLevelInfo then
      petID = playerCharacter.PetComponent_BP.PetPawn.PetLevelInfo.PetId
      petSkinID = playerCharacter.PetComponent_BP.PetPawn:GetCurrentSkin()
    end
    if not petID and playerCharacter.PetComponent_BP.PetInfo then
      petID = playerCharacter.PetComponent_BP.PetInfo.PetId
    end
  end
  local bShowMiniTv = false
  local SettingModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.SettingModule)
  if SettingModule then
    bShowMiniTv = SettingModule:GetOptionValue("ShowMiniTvInFighting")
  end
  local MiniTvUtil = require("GameLua.Mod.BRMod.Gameplay.Actor.Pet.MiniTvUtil")
  local miniTvType = playerCharacter and playerCharacter.GetMiniTvType and playerCharacter:GetMiniTvType() or nil
  local bIsMiniTvStandalone = miniTvType == MiniTvUtil.ENUM_MINITV_TYPE.Standalone
  local bCanAddMiniTv = bIsMiniTvStandalone and bShowMiniTv
  local PET_ID_MINI_TV = 50000
  local bCanAddPet = petID and 0 < petID
  if bCanAddPet or bCanAddMiniTv then
    for _, v in pairs(CDataTable.GetTable("PetActionTable")) do
      if v.PetActionID and v.CanPlayInBattle ~= 0 and v.CanPlayInBattle ~= 3 then
        local isCurrentSkin = true
        if v.DependingClothesID and v.DependingClothesID ~= "" then
          isCurrentSkin = tonumber(v.DependingClothesID) == petSkinID
        end
        if bCanAddPet and petID == v.PetID and isCurrentSkin then
          local hasLock = not NewCameraUtil.IsPetEmoteUnlocked(v.PetActionID, playerCharacter, false)
          addToMap(v.PetActionID, EEmotionCategory.Pet, hasLock)
        elseif bCanAddMiniTv and PET_ID_MINI_TV == v.PetID then
          local hasLock = not NewCameraUtil.IsPetEmoteUnlocked(v.PetActionID, playerCharacter, true)
          addToMap(v.PetActionID, EEmotionCategory.MiniTv, hasLock)
        end
      end
    end
  end
  if playerController.PlayEmoteFeature and playerController.PlayEmoteFeature.CollectionEmoteMap then
    for emoteID, _ in pairs(playerController.PlayEmoteFeature.CollectionEmoteMap) do
      addToMap(emoteID, EEmotionCategory.Collection)
    end
  end
  local logic_emote = require("GameLua.Mod.Library.GamePlay.Avatar.Emote.logic_emote")
  local flauntList = logic_emote.GetFlauntEmote()
  if flauntList then
    for _, emoteID in ipairs(flauntList) do
      addToMap(emoteID, EEmotionCategory.Flaunt)
    end
  end
  for _, list in pairs(self._emoteListByCategory) do
    table.sort(list, function(a, b)
      if a.hasLock ~= b.hasLock then
        return not a.hasLock
      end
      return a.id < b.id
    end)
  end
  self._bEmotionDataInited = true
  log_tree("NewCamera_Photo_UIBP:_InitEmotionData - _emoteListByCategory = ", self._emoteListByCategory)
  log_tree("NewCamera_Photo_UIBP:_InitEmotionData - _emoteToCategory = ", self._emoteToCategory)
end

function NewCamera_Photo_UIBP:_InitHDRSwitch()
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if not IngameSelfieSubsystem then
    log(bWriteLog and "NewCamera_Photo_UIBP:OnButton_ResetClick cannot get IngameSelfieSubsystem")
    return
  end
  self._isInHDR = IngameSelfieSubsystem:GetIsSwitchedHDRPlus()
end

function NewCamera_Photo_UIBP:RefreshHDRSwitchState()
  local bOldInHDR = self._isInHDR
  self:_InitHDRSwitch()
  printf("NewCamera_Photo_UIBP:RefreshHDRSwitchState oldInHDR:%s, newInHDR:%s, curMainSysID:%s", tostring(bOldInHDR), tostring(self._isInHDR), tostring(self._curMainSysID))
  if not self.UIRoot or not self._sysConfig then
    log_warning(bWriteLog and "NewCamera_Photo_UIBP:RefreshHDRSwitchState UI not ready, sync HDR state only")
    return
  end
  if bOldInHDR == self._isInHDR then
    return
  end
  self:SetWidgetVisible(self.UIRoot.Button_SaveToFilterTemplate, self._isInHDR, true)
  self:SetWidgetVisible(self.UIRoot.SizeBox_FilterSetting, self._isInHDR)
  self:_HideSystemByHDR()
  if self._curMainSysID and self._sysConfig then
    local config = self._sysConfig[self._curMainSysID]
    if config then
      self:_BuildMainSystemList(config)
    end
  end
end

function NewCamera_Photo_UIBP:_RefreshCameraModeUI(mode)
  local bFixed = mode == CameraMode.Fixed
  local index = bFixed and 1 or 0
  self.UIRoot.WidgetSwitcher_ModeSwitch:SetActiveWidgetIndex(index)
  if self.UIRoot.CanvasPanel_FixedMode then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_FixedMode, bFixed)
  end
  if self.freeViewComp then
    self.freeViewComp:SetBanLock(not bFixed)
  end
  local bMove = mode == CameraMode.Move
  if bMove then
    if self.UIRoot.CanvasPanel_FixedModeControl then
      self:SetWidgetVisible(self.UIRoot.CanvasPanel_FixedModeControl, true)
    end
    self:_RefreshMoveModeActionButtons()
  else
    self:StopJoyStick()
  end
  self:_RefreshFreeViewShow()
  self:_RefreshHeadAimShow()
end

function NewCamera_Photo_UIBP:_RefreshMoveModeActionButtons()
  local playerCharacter = GameplayData.GetPlayerCharacter()
  if slua.isValid(playerCharacter) then
    local ESTEPoseState = import("ESTEPoseState")
    local poseState = playerCharacter.PoseState
    local status = 0
    if poseState == ESTEPoseState.Crouch or poseState == ESTEPoseState.CrouchSprint then
      status = 1
    elseif poseState == ESTEPoseState.Prone or poseState == ESTEPoseState.Crawl then
      status = 2
    end
    self:RefreshButtonStatus(status)
  end
  self:RefreshJumpBtnIcon()
end

function NewCamera_Photo_UIBP:RefreshJumpBtnIcon()
  if not slua.isValid(self.UIRoot) then
    return
  end
  local bCanVault = self:CheckCanVault()
  local iconBrush
  if bCanVault then
    iconBrush = self.bIsPressingJumpBtn and self.UIRoot.Vault_HighLightIcon or self.UIRoot.Vault_NormalIcon
    if slua.isValid(self.UIRoot.lightcircle_Img) then
      self.UIRoot.lightcircle_Img:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    end
  else
    iconBrush = self.bIsPressingJumpBtn and self.UIRoot.Jump_HighLightIcon or self.UIRoot.Jump_NormalIcon
    if slua.isValid(self.UIRoot.lightcircle_Img) then
      self.UIRoot.lightcircle_Img:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    end
  end
  if iconBrush and slua.isValid(self.UIRoot.Image_JumpIcon) then
    self.UIRoot.Image_JumpIcon:SetBrush(iconBrush)
  end
end

function NewCamera_Photo_UIBP:_RefreshMainCameraUI(bShow)
  log(bWriteLog and "NewCamera_Photo_UIBP:RefreshMainCameraUI - bShow = " .. tostring(bShow))
  self:_OnClickHideUIGroup(EHideUIType.HideAll, bShow)
  if bShow then
    self:_ClearAutoHideUIShowEntryTimer()
  end
end

function NewCamera_Photo_UIBP:_RefreshHideButtonShow(bShow)
  if self.UIRoot.WidgetSwitcher_HideUI then
    self.UIRoot.WidgetSwitcher_HideUI:SetActiveWidgetIndex(bShow and 0 or 1)
  end
end

function NewCamera_Photo_UIBP:_RefreshUITransparent()
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if not IngameSelfieSubsystem then
    return
  end
  local transparent = IngameSelfieSubsystem:GetUITransparent()
  self.UIRoot.Border_Transparent:SetContentColorAndOpacity(FLinearColor(1, 1, 1, transparent))
end

function NewCamera_Photo_UIBP:_ResetAll()
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if not IngameSelfieSubsystem then
    log(bWriteLog and "NewCamera_Photo_UIBP:OnButton_ResetClick cannot get IngameSelfieSubsystem")
    return
  end
  local mode = self:_GetCameraMode()
  if mode == CameraMode.Fixed then
    IngameSelfieSubsystem:ResetCameraToFacePlayer()
  end
  for k, v in pairs(self._compList) do
    if v and v.Reset then
      v:Reset()
    end
  end
  for k, v in pairs(self._sysPanels) do
    if v and v.Reset then
      v:Reset()
    end
  end
  self:_CloseCurrentSubSystem()
  self:_CloseCurrentMainSystem()
  self:_CloseCurrentReplaceablePanel()
  self:_RefreshEmotionSelectedShow()
  self._curEmotionCategoryID = nil
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_EmotionList_Beta, false)
  if not self._isInHDR then
    IngameSelfieSubsystem:ChangeFilter()
    IngameSelfieSubsystem:SetSelectedFilterID(nil)
  end
end

function NewCamera_Photo_UIBP:_RefreshReferenceLineShow()
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if not IngameSelfieSubsystem then
    log(bWriteLog and "NewCamera_Photo_UIBP:OnButton_ResetClick cannot get IngameSelfieSubsystem")
    return
  end
  local bShowLine = IngameSelfieSubsystem:GetReferenceLineVisibility()
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_ReferenceLine, bShowLine or self._forceShowReferenceLine)
end

function NewCamera_Photo_UIBP:_HideSystemByHDR()
  for k, v in pairs(self._sysConfig) do
    local widgetName = v.widgetName
    if v.needHDR and widgetName then
      local findName = "CanvasPanel_" .. widgetName
      self:SetWidgetVisible(self.UIRoot[findName], self._isInHDR)
    end
  end
end

function NewCamera_Photo_UIBP:_ResetUIWidgetShow()
end

function NewCamera_Photo_UIBP:_RefreshFreeViewShow()
  local mode = self:_GetCameraMode()
  local isLock = self:_IsFocusLock()
  local canShow = mode == CameraMode.Move or not isLock
  local bShow = self:GetWidgetCanShowWithHideData("CanvasPanel_FreeView")
  log_format("NewCamera_Photo_UIBP:_SetFreeViewShow bShow:%s, canShow:%s", bShow, canShow)
  local isShow = bShow and canShow
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_FreeView, isShow)
  if not isShow and self.freeViewComp then
    self.freeViewComp:Reset()
  end
end

function NewCamera_Photo_UIBP:_RefreshHeadAimShow()
  local mode = self:_GetCameraMode()
  local isLock = self:_IsFocusLock()
  local canShow = mode == CameraMode.Fixed and isLock
  local bShow = self:GetWidgetCanShowWithHideData("CanvasPanel_HeadAim")
  local isShow = bShow and canShow
  log_format("NewCamera_Photo_UIBP:_SetHeadAimShow bShow:%s, canShow:%s, isShow:%s", bShow, canShow, isShow)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_HeadAim, isShow)
  if not isShow and self.headAimComp then
    self.headAimComp:Reset()
  end
end

function NewCamera_Photo_UIBP:_RefreshEmotionSelectedShow()
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if not IngameSelfieSubsystem then
    return
  end
  local curEmoteInfo = IngameSelfieSubsystem:GetCurEmoteInfo()
  local hasEmotion = curEmoteInfo.emoteID ~= nil
  local isConflictByOtherSubSystem = self._curSubSysID == ESystem.EmotionSub or self._curSubSysID == ESystem.ActionSequence
  local isReplaceEmotionSystemShow = self._curReplaceableSubSysID == ESystem.EmotionSub and self._curReplaceableSubSysPanel:IsShow()
  log_format("NewCamera_Photo_UIBP:_RefreshEmotionSelectedShow hasEmotion:%s, isConflictByOtherSubSystem:%s, isReplaceEmotionSystemShow:%s", hasEmotion, isConflictByOtherSubSystem, isReplaceEmotionSystemShow)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_EmotionSelected, hasEmotion and not isConflictByOtherSubSystem and not isReplaceEmotionSystemShow)
end

function NewCamera_Photo_UIBP:_RefreshEmotionSelectedIcon()
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if not IngameSelfieSubsystem then
    return
  end
  local curEmoteInfo = IngameSelfieSubsystem:GetCurEmoteInfo()
  if curEmoteInfo.emoteID then
    local iconPath = NewCameraUtil.GetEmoteIconPath(curEmoteInfo.categoryID, curEmoteInfo.emoteID)
    self:SetTexture(self.UIRoot.Image_EmoteSelected, iconPath)
  end
end

function NewCamera_Photo_UIBP:_RefreshMoveControlShow(bSwimmingOverride)
  local PlayerCharacter = GameplayData.GetPlayerCharacter()
  if not slua.isValid(PlayerCharacter) then
    return
  end
  local isSwimming = bSwimmingOverride
  if isSwimming == nil then
    isSwimming = PlayerCharacter:HasState(EPawnState.Swim)
  end
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Swim, isSwimming)
  self:_OnClickHideUIGroup(EHideUIType.Swim, not isSwimming)
  if isSwimming then
    self:RefreshSwimSprint()
  else
    self:StopSprintCoolDown()
  end
end

function NewCamera_Photo_UIBP:_GetCameraMode()
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  local mode = NewCameraConfig.CDefaultCameraMode
  if IngameSelfieSubsystem and IngameSelfieSubsystem.GetCameraMode then
    local curMode = IngameSelfieSubsystem:GetCameraMode()
    if curMode then
      mode = curMode
    end
  end
  return mode
end

function NewCamera_Photo_UIBP:_IsFocusLock()
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if not IngameSelfieSubsystem then
    return false
  end
  return IngameSelfieSubsystem:GetFocusLock()
end

function NewCamera_Photo_UIBP:_RefreshUIShowByInteractiveState()
  local isPlayerInInteractiveState = false
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if IngameSelfieSubsystem and IngameSelfieSubsystem:CheckIsPlayerInInteractiveState() then
    isPlayerInInteractiveState = true
  end
  local canShow = not isPlayerInInteractiveState
  self:_OnClickHideUIGroup(EHideUIType.Interactive, canShow)
  self.UIRoot.Button_MoveMode:SetIsEnabled(canShow)
end

function NewCamera_Photo_UIBP:_RefreshUIShowByPlayerState()
  local PlayerCharacter = GameplayData.GetPlayerCharacter()
  for state, uiType in pairs(NewCamera_Photo_UIConfig.PlayerStateToHideUIType) do
    local canShow = not PlayerCharacter:HasState(state)
    self:_OnClickHideUIGroup(uiType, canShow)
  end
end

function NewCamera_Photo_UIBP:_RefreshUIShowByVehicleState()
  local isPlayerInVehicleState = false
  local PlayerCharacter = GameplayData.GetPlayerCharacter()
  local uiType = EHideUIType.DriveVehicle
  if PlayerCharacter:HasState(EPawnState.DriveVehicle) then
    isPlayerInVehicleState = true
  elseif PlayerCharacter:HasState(EPawnState.InVehicle) then
    isPlayerInVehicleState = true
    uiType = EHideUIType.InVehicle
  end
  local canShow = not isPlayerInVehicleState
  self:_OnClickHideUIGroup(uiType, canShow)
end

function NewCamera_Photo_UIBP:OnResetFilter()
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  IngameSelfieSubsystem:SetSelectedFilterID(nil)
  self.LoopScrollBox_Filter:Deselect()
  if self._curSubSysID == ESystem.FilterSub then
    self:_CloseCurrentSubSystem()
  end
end

function NewCamera_Photo_UIBP:StopJoyStick(bForceReleaseCapture)
  self:StopCustomJoystick(bForceReleaseCapture)
end

function NewCamera_Photo_UIBP:OnCustomJoystickTouchStart()
  log(bWriteLog and "NewCamera_Photo_UIBP:OnCustomJoystickTouchStart")
  if not self.freeViewComp then
    return
  end
  self.freeViewComp:OnMoveJoystickTouchStart()
end

function NewCamera_Photo_UIBP:OnCustomJoystickActive()
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerController) or not playerController.bAutoSprint then
    return
  end
  if self.OnSprintStateInterrupt then
    self:OnSprintStateInterrupt()
  end
end

function NewCamera_Photo_UIBP:OnCustomJoystickTouchEnd()
  log(bWriteLog and "NewCamera_Photo_UIBP:OnCustomJoystickTouchEnd")
  if not self.freeViewComp then
    return
  end
  self.freeViewComp:OnMoveJoystickTouchEnd()
end

function NewCamera_Photo_UIBP:_EnablePinch(enabled)
  log(bWriteLog and "NewCamera_Photo_UIBP:_EnablePinch - enabled = " .. tostring(enabled))
  local visibility = enabled and UEnums.ESlateVisibility.Visible or UEnums.ESlateVisibility.SelfHitTestInvisible
  self.UIRoot:SetWidgetVisibility(visibility)
  self.UIRoot:SetPinchEnabled(enabled)
end

function NewCamera_Photo_UIBP:_OnClickHideUIGroup(group, isShow)
  if not isShow and self:IsHideGroupHidingAnyNode(group, CJoystickHideCheckNodes) and self:IsCustomJoystickDragging() then
    log(bWriteLog and "NewCamera_Photo_UIBP:_OnClickHideUIGroup stop joystick before hiding, group = " .. tostring(group))
    self:StopJoyStick(false)
  end
  self:_RefreshHideUIGroupShow(group, isShow)
  self:_TryLoadDeferredComponents()
  if self._zoomPinchVisibilityCheckTimer then
    self:RemoveTimer(self._zoomPinchVisibilityCheckTimer)
  end
  self._zoomPinchVisibilityCheckTimer = self:AddTimerOnce(0.1, function()
    self._zoomPinchVisibilityCheckTimer = nil
    self:_RefreshPinchEnableByZoomVisibility()
  end)
end

function NewCamera_Photo_UIBP:_IsZoomPinchTargetVisible()
  local zoomParent = self.UIRoot.CanvasPanel_ZoomParent
  if slua.isValid(zoomParent) and not zoomParent:IsVisible() then
    return false
  end
  local mainPanel = self.UIRoot.CanvasPanel_Main
  if slua.isValid(mainPanel) and not mainPanel:IsVisible() then
    return false
  end
  return true
end

function NewCamera_Photo_UIBP:_RefreshPinchEnableByZoomVisibility()
  local bShouldDisable = not self:_IsZoomPinchTargetVisible()
  if bShouldDisable == self._bPinchDisabledByHideGroup then
    return
  end
  self._bPinchDisabledByHideGroup = bShouldDisable
  self:_EnablePinch(not bShouldDisable)
end

function NewCamera_Photo_UIBP:_ApplyPhotoUIDisplayState(EState)
  log(bWriteLog and "NewCamera_Photo_UIBP:_ApplyPhotoUIDisplayState - EState = " .. tostring(EState))
  if not EState or not StateToHideUIType[EState] then
    return
  end
  local preState = self._curPhotoUIDisplayState
  self._curPhotoUIDisplayState = EState
  local hideUIType = StateToHideUIType[EState]
  self:_OnClickHideUIGroup(hideUIType, false)
  if preState and EState == EPhotoUIDisplayState.None then
    local resetUIType = StateToHideUIType[preState]
    self:_OnClickHideUIGroup(resetUIType, true)
  end
end

function NewCamera_Photo_UIBP:_InitComponents()
  self._compList = {}
  self._compLoadCursor = 0
  self._deferredCompLoads = {}
  self._deferredCompLoadTimer = nil
  self._compLoadConfig = NewCamera_Photo_UIConfig.GetComponentLoadConfig()
end

function NewCamera_Photo_UIBP:_StartFrameLoadComponents()
  if self._compLoadTimer then
    return
  end
  self._compLoadTimer = self:AddTimerLoop(0, function()
    self:_LoadNextComponent()
  end, #self._compLoadConfig.frameLoadList, time_ticker.NEXT_FRAME)
end

function NewCamera_Photo_UIBP:_LoadNextComponent()
  if not slua.isValid(self.UIRoot) then
    return
  end
  local index = self._compLoadCursor + 1
  local loadConfig = self._compLoadConfig.frameLoadList[index]
  if not loadConfig then
    return
  end
  self._compLoadCursor = index
  if not self:_IsComponentNeeded(loadConfig) then
    self._deferredCompLoads[#self._deferredCompLoads + 1] = loadConfig
    log_format("NewCamera_Photo_UIBP:_LoadNextComponent defer hidden component: %s", tostring(loadConfig.fieldName))
    return
  end
  self:_CreateComponent(loadConfig)
end

function NewCamera_Photo_UIBP:_IsComponentNeeded(loadConfig)
  local hideCheckNodes = loadConfig.hideCheckNodes
  if hideCheckNodes then
    for _, nodeName in ipairs(hideCheckNodes) do
      if not self:GetWidgetCanShowWithHideData(nodeName) then
        return false
      end
    end
  end
  return true
end

function NewCamera_Photo_UIBP:_TryLoadDeferredComponents()
  if not self._deferredCompLoads or next(self._deferredCompLoads) == nil then
    return
  end
  if self._deferredCompLoadTimer then
    return
  end
  self._deferredCompLoadTimer = self:AddTimerOnce(0, function()
    self._deferredCompLoadTimer = nil
    self:_LoadDeferredComponents()
  end)
end

function NewCamera_Photo_UIBP:_LoadDeferredComponents()
  if not slua.isValid(self.UIRoot) then
    return
  end
  local remainList = {}
  for _, loadConfig in ipairs(self._deferredCompLoads) do
    if self:_IsComponentNeeded(loadConfig) then
      log_format("NewCamera_Photo_UIBP:_LoadDeferredComponents load component: %s", tostring(loadConfig.fieldName))
      self:_CreateComponent(loadConfig)
    else
      remainList[#remainList + 1] = loadConfig
    end
  end
  self._deferredCompLoads = remainList
end

function NewCamera_Photo_UIBP:_CreateComponent(loadConfig)
  if not slua.isValid(self.UIRoot) then
    return nil
  end
  local uiConfig = loadConfig.uiConfig
  if not uiConfig then
    log_error(bWriteLog and "[ERROR] NewCamera_Photo_UIBP:_CreateComponent uiConfig is nil, field = " .. tostring(loadConfig.fieldName))
    return nil
  end
  local mountPanel = self.UIRoot[loadConfig.mountName]
  if not slua.isValid(mountPanel) then
    log_error(bWriteLog and "[ERROR] NewCamera_Photo_UIBP:_CreateComponent mount panel not found = " .. tostring(loadConfig.mountName))
    return nil
  end
  local comp
  if loadConfig.args then
    comp = self:CreateChildWindow(mountPanel, uiConfig, loadConfig.args)
  else
    comp = self:CreateChildWindow(mountPanel, uiConfig)
  end
  if not comp then
    log_error(bWriteLog and "[ERROR] NewCamera_Photo_UIBP:_CreateComponent create failed, field = " .. tostring(loadConfig.fieldName))
    return nil
  end
  self[loadConfig.fieldName] = comp
  self._compList[#self._compList + 1] = comp
  log_format("NewCamera_Photo_UIBP:_CreateComponent field: %s, mount: %s", loadConfig.fieldName, loadConfig.mountName)
  self:_ApplyComponentStateOnLoaded(loadConfig.fieldName)
  return comp
end

function NewCamera_Photo_UIBP:_EnsureDroneControlComp()
  if self.droneControlComp then
    return self.droneControlComp
  end
  log(bWriteLog and "NewCamera_Photo_UIBP:_EnsureDroneControlComp mount drone control panel on demand")
  return self:_CreateComponent(self._compLoadConfig.lazyLoadList.droneControl)
end

function NewCamera_Photo_UIBP:_ApplyComponentStateOnLoaded(fieldName)
  if fieldName == "zoomChangeComp" then
    if self._pendingSpecificZoom ~= nil then
      local pendingZoom = self._pendingSpecificZoom
      self._pendingSpecificZoom = nil
      self.zoomChangeComp:SetSpecificZoom(pendingZoom)
    end
  elseif fieldName == "freeViewComp" then
    self.freeViewComp:SetBanLock(self:_GetCameraMode() ~= CameraMode.Fixed)
    self:_RefreshFreeViewShow()
  elseif fieldName == "headAimComp" then
    self:_RefreshHeadAimShow()
  elseif fieldName == "droneControlComp" and self:_IsInDroneMode() then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_DroneControl, true)
    self.droneControlComp:Show()
  end
end

function NewCamera_Photo_UIBP:SetExternalPhotoUIDisplayState(State)
  log(bWriteLog and "NewCamera_Photo_UIBP:SetExternalPhotoUIDisplayState - State = " .. tostring(State))
  if State then
    self._externalPhotoUIDisplayState = State
  end
end

function NewCamera_Photo_UIBP:_ResolvePhotoUIDisplayState()
  local HighlightMomentSubsystem = SubsystemMgr:Get("HighlightMomentSubsystem")
  if HighlightMomentSubsystem then
    local bIsPlaying, bIsInTransition = HighlightMomentSubsystem:IsInPlayingState()
    if bIsPlaying then
      if bIsInTransition then
        return EPhotoUIDisplayState.SceneShowTransition
      end
      return EPhotoUIDisplayState.HighlightMode
    end
  end
  if self._externalPhotoUIDisplayState then
    return self._externalPhotoUIDisplayState
  end
  return EPhotoUIDisplayState.None
end

function NewCamera_Photo_UIBP:RefreshPhotoUIDisplayState()
  local TargetState = self:_ResolvePhotoUIDisplayState()
  if self._curPhotoUIDisplayState == TargetState then
    return
  end
  log(bWriteLog and "NewCamera_Photo_UIBP:RefreshPhotoUIDisplayState from:" .. tostring(self._curPhotoUIDisplayState) .. " to:" .. tostring(TargetState))
  self:_ApplyPhotoUIDisplayState(TargetState)
end

function NewCamera_Photo_UIBP:UseSmartCamera(emoteList, templateID, tSequenceSetting)
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if not IngameSelfieSubsystem then
    return
  end
  local PhotoGrapherSubSystem = SubsystemMgr:Get("PhotoGrapherSubSystem")
  if not PhotoGrapherSubSystem then
    return
  end
  PhotoGrapherSubSystem:StopSmartCamera()
  PhotoGrapherSubSystem:SetEmoteArray(emoteList)
  IngameSelfieSubsystem:StartSmartCamera(true, templateID, tSequenceSetting)
end

function NewCamera_Photo_UIBP:OnTransparentPanel(bIsTransparent)
  log(bWriteLog and "NewCamera_Photo_UIBP:OnTransparentPanel - bIsTransparent = " .. tostring(bIsTransparent))
end

function NewCamera_Photo_UIBP:SetSpecificZoom(nValue)
  if not self.zoomChangeComp then
    self._pendingSpecificZoom = nValue
    log(bWriteLog and "NewCamera_Photo_UIBP:SetSpecificZoom pending - nValue = " .. tostring(nValue))
    return
  end
  self.zoomChangeComp:SetSpecificZoom(nValue)
end

function NewCamera_Photo_UIBP:SetSpecificWeather(value)
  if self._curSubSysID ~= ESystem.CameraSetting then
    return
  end
  local panel = self._sysPanels[ESystem.CameraSetting]
  if panel then
    panel:SetSpecificWeather(value)
  end
end

function NewCamera_Photo_UIBP:HideInteractIgnoreUI()
  self:_OnClickHideUIGroup(EHideUIType.Interactive, false)
end

function NewCamera_Photo_UIBP:_StartAutoHideUIShowEntryTimer()
  log(bWriteLog and "NewCamera_Photo_UIBP:_StartAutoHideUIShowEntryTimer")
  self:_ClearAutoHideUIShowEntryTimer()
  self._autoHideUIShowEntryTimer = self:AddTimerOnce(NewCameraConfig.CAutoHideUIShowEntryTime, function()
    log(bWriteLog and "NewCamera_Photo_UIBP:_StartAutoHideUIShowEntryTimer timer callback")
    self:_AutoHideUIShowEntry()
  end)
end

function NewCamera_Photo_UIBP:_ClearAutoHideUIShowEntryTimer()
  log(bWriteLog and "NewCamera_Photo_UIBP:_ClearAutoHideUIShowEntryTimer")
  if not self._autoHideUIShowEntryTimer then
    return
  end
  self:RemoveTimer(self._autoHideUIShowEntryTimer)
  self._autoHideUIShowEntryTimer = nil
end

function NewCamera_Photo_UIBP:_AutoHideUIShowEntry()
  self:_ClearAutoHideUIShowEntryTimer()
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_HideUI, false)
end

function NewCamera_Photo_UIBP:_ReShowUIShowEntry()
  self:_ClearAutoHideUIShowEntryTimer()
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_HideUI, true)
end

function NewCamera_Photo_UIBP:_CloseCurrentMainSystem()
  log(bWriteLog and "NewCamera_Photo_UIBP:_CloseCurrentMainSystem")
  if not self._curMainSysID then
    log(bWriteLog and "NewCamera_Photo_UIBP:_CloseCurrentMainSystem _curMainSysID is nil")
    return
  end
  self.LoopScrollBox_SubSystem:SetData({})
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_RightParent, false)
  self:_SetSystemWidgetShow(self._curMainSysID, false)
  if self._curSubSysID then
    local isMySubSys = self._subToMain[self._curSubSysID] == self._curMainSysID
    if isMySubSys then
      self:_CloseCurrentSubSystem()
    end
  end
  self._curMainSysID = nil
end

function NewCamera_Photo_UIBP:_OnClickMainSystem(sysID)
  local config = self._sysConfig[sysID]
  if not config then
    log_warning(bWriteLog and "NewCamera_Photo_UIBP:_OnClickMainSystem cannot get config for sysID = " .. tostring(sysID))
    return
  end
  if self._curMainSysID then
    self:_SetSystemWidgetShow(self._curMainSysID, false)
  end
  if self._curMainSysID == sysID then
    self:_CloseCurrentMainSystem()
    return
  end
  local isChangeMain = self._curMainSysID and self._curMainSysID ~= sysID
  if isChangeMain and self._curSubSysID and self._subToMain[self._curSubSysID] then
    self:_CloseCurrentSubSystem()
  end
  local hasList = config.listType ~= nil
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_RightParent, hasList)
  if hasList then
    self.UIRoot.WidgetSwitcher_RightPanel:SetActiveWidgetIndex(config.listType)
  end
  self:_SetSystemWidgetShow(sysID, true)
  self._curMainSysID = sysID
  self:_BuildMainSystemList(config)
end

function NewCamera_Photo_UIBP:_BuildMainSystemList(sysConfig)
  if sysConfig.listType == EMainSysListType.SystemList then
    self:_BuildSubSystemList(sysConfig)
  elseif sysConfig.listType == EMainSysListType.EmotionList then
    self:_BuildEmotionAlphaList()
  elseif sysConfig.listType == EMainSysListType.FilterList then
    self:_BuildFilterList()
  end
end

function NewCamera_Photo_UIBP:_BuildSubSystemList(sysConfig)
  local data = {}
  for _, v in ipairs(sysConfig.sysList) do
    local config = self._sysConfig[v]
    local canAdd = true
    if config.needHDR then
      canAdd = self._isInHDR
    end
    if canAdd then
      local item = {}
      item.sysID = v
      item.sysConfig = config
      
      function item.onClickCallback(i)
        self:_OnClickSubSystemListItem(i)
      end
      
      table.insert(data, item)
    end
  end
  self.LoopScrollBox_SubSystem:SetData(data)
end

function NewCamera_Photo_UIBP:_BuildEmotionAlphaList()
  self:_InitEmotionData()
  local alphaConfig = NewCamera_Photo_UIConfig.EmotionCategoryConfig
  local data = {}
  for emotionCategoryID, config in pairs(alphaConfig) do
    local list = self._emoteListByCategory[emotionCategoryID]
    if list and next(list) then
      local item = {}
      item.categoryID = emotionCategoryID
      item.config = config
      
      function item.onClickCallback(index)
        self:_OnClickEmotionAlphaListItem(index)
      end
      
      item.notShowSelect = true
      table.insert(data, item)
    end
  end
  table.sort(data, function(a, b)
    return a.categoryID < b.categoryID
  end)
  self.LoopScrollBox_EmotionList_Alpha:SetData(data)
  local targetCategoryID
  if self._curEmoteID then
    targetCategoryID = self._emoteToCategory[self._curEmoteID]
  elseif self._curEmotionCategoryID then
    targetCategoryID = self._curEmotionCategoryID
  end
  if targetCategoryID then
    local index
    for i, v in ipairs(data) do
      if v.categoryID == targetCategoryID then
        index = i
        break
      end
    end
    if index then
      self._curEmotionCategoryID = nil
      self:_OnClickEmotionAlphaListItem(index)
    end
  end
end

function NewCamera_Photo_UIBP:_BuildEmotionBetaList()
  self:_InitEmotionData()
  local categoryID = self._curEmotionCategoryID
  if not categoryID then
    self.LoopScrollBox_EmotionList_Beta:SetData({})
    return
  end
  local emoteList = self._emoteListByCategory[categoryID]
  if not emoteList or #emoteList == 0 then
    self.LoopScrollBox_EmotionList_Beta:SetData({})
    return
  end
  local data = {}
  local defaultIndex
  local maxLen = math.max(#emoteList, NewCameraConfig.CMaxEmotionSlot)
  for i = 1, maxLen do
    local emoteData = emoteList[i]
    local item = {}
    item.isEmpty = emoteData == nil
    if emoteData then
      item.emoteID = emoteData.id
      item.categoryID = categoryID
      item.bLocked = emoteData.hasLock
      item.notShowSelect = true
      
      function item.onClickCallback(index)
        self:_OnClickEmotionBetaListItem(index)
      end
      
      if emoteData.id == self._curEmoteID then
        defaultIndex = i
      end
    end
    table.insert(data, item)
  end
  self.LoopScrollBox_EmotionList_Beta:SetData(data)
  if defaultIndex then
    self.LoopScrollBox_EmotionList_Beta:Select(defaultIndex)
    if self._curSubSysID ~= ESystem.EmotionSub then
      self:_OnClickSubSystem(ESystem.EmotionSub)
    end
  end
end

function NewCamera_Photo_UIBP:_BuildFilterList()
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if not IngameSelfieSubsystem then
    return
  end
  local data = {}
  if self._isInHDR then
    local customList = IngameSelfieSubsystem:GetCustomFilterTemplateList()
    for k, v in pairs(customList) do
      local templateData = v
      local item = {}
      local config = NewCameraUtil.GetFilterTemplateConfig(templateData)
      item.config = config
      
      function item.onClickCallback(index)
        self:_OnClickFilterListItem(index)
      end
      
      table.insert(data, item)
    end
  end
  local list = IngameSelfieSubsystem:GetFilterList()
  for i, v in ipairs(list) do
    local item = {}
    item.config = v
    
    function item.onClickCallback(index)
      self:_OnClickFilterListItem(index)
    end
    
    table.insert(data, item)
  end
  self.LoopScrollBox_Filter:SetData(data)
  self:_SetFilterDefaultSelected(data)
end

function NewCamera_Photo_UIBP:_SetFilterDefaultSelected(list)
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if not IngameSelfieSubsystem then
    return
  end
  local targetID = IngameSelfieSubsystem:GetSelectedFilterID()
  if not targetID and not self._isInHDR then
    targetID = IngameSelfieSubsystem:GetSavedRenderStyle()
  end
  if not targetID then
    return
  end
  local defaultIndex
  for i, v in ipairs(list) do
    if v.config.ID == targetID then
      defaultIndex = i
      break
    end
  end
  if defaultIndex then
    IngameSelfieSubsystem:SetSelectedFilterID(nil)
    self:_OnClickFilterListItem(defaultIndex)
  end
end

function NewCamera_Photo_UIBP:_CloseCurrentSubSystem()
  log(bWriteLog and "NewCamera_Photo_UIBP:_CloseCurrentSubSystem")
  if not self._curSubSysID then
    return
  end
  local config = self._sysConfig[self._curSubSysID]
  if not config then
    log_warning(bWriteLog and "NewCamera_Photo_UIBP:_CloseCurrentSubSystem cannot get config for sysID = " .. tostring(self._curSubSysID))
    return
  end
  self:_SetSystemWidgetShow(self._curSubSysID, false)
  self:_CloseSubSystem(self._curSubSysID)
  self._curSubSysID = nil
  self:_OnSubSystemChange()
end

function NewCamera_Photo_UIBP:_OnClickSubSystem(sysID)
  log(bWriteLog and "NewCamera_Photo_UIBP:OpenSubSystem - sysID = " .. tostring(sysID))
  local config = self._sysConfig[sysID]
  if not config then
    log_warning(bWriteLog and "NewCamera_Photo_UIBP:OpenSubSystem cannot get config for sysID = " .. tostring(sysID))
    return
  end
  if not self._subToMain[sysID] then
    self:_CloseCurrentMainSystem()
  end
  if not config.uiConfig then
    return
  end
  local canCreate = true
  if config.needHDR then
    canCreate = self._isInHDR
  end
  if canCreate then
    self:_CreateSubSystemUI(sysID)
  else
    self:_CloseCurrentSubSystem()
  end
  self:_SetSystemWidgetShow(self._curSubSysID, false)
  if self._curSubSysID and self._curSubSysID == sysID then
    self._curSubSysID = nil
  else
    self._curSubSysID = sysID
    self:_SetSystemWidgetShow(sysID, true)
    self:_HideCurrentReplaceablePanel()
  end
  self:_OnSubSystemChange()
end

function NewCamera_Photo_UIBP:_OnSubSystemChange()
  self:_RefreshEmotionSelectedShow()
end

function NewCamera_Photo_UIBP:_RefreshSubSystemWidget(sysID)
  if self._curSubSysID == sysID then
    self:_SetSystemWidgetShow(self._curSubSysID, false)
    return
  end
  self:_SetSystemWidgetShow(sysID, true)
end

function NewCamera_Photo_UIBP:_SetSystemWidgetShow(sysID, isShow)
  if not sysID then
    return
  end
  local sysConfig = self._sysConfig[sysID]
  local widgetName = sysConfig.widgetName
  if not widgetName then
    return
  end
  local switcher = self.UIRoot["WidgetSwitcher_" .. widgetName]
  if not switcher then
    return
  end
  switcher:SetActiveWidgetIndex(isShow and 1 or 0)
end

function NewCamera_Photo_UIBP:_CreateSubSystemUI(sysID)
  log(bWriteLog and "NewCamera_Photo_UIBP:CreateSubSystemUI - sysID = " .. tostring(sysID))
  self:_CloseSubSystem(self._curSubSysID)
  if self._curSubSysID and self._curSubSysID == sysID then
    log_warning(bWriteLog and "NewCamera_Photo_UIBP:CreateSubSystemUI has already open")
    return
  end
  local sysConfig = self._sysConfig[sysID]
  local uiConfig = sysConfig.uiConfig
  if uiConfig and not self._sysPanels[sysID] then
    local panel = self:CreateChildWindow(self.UIRoot.CanvasPanel_BottomParent, uiConfig)
    self._sysPanels[sysID] = panel
  end
  local panel = self._sysPanels[sysID]
  if panel then
    panel:SelfHitTestInvisible()
  end
end

function NewCamera_Photo_UIBP:_CloseSubSystem(sysID)
  log(bWriteLog and "NewCamera_Photo_UIBP:CloseSubSystem - sysID = " .. tostring(sysID))
  local config = self._sysConfig[sysID]
  if not config then
    log_warning(bWriteLog and "NewCamera_Photo_UIBP:CloseSubSystem cannot get config for sysID = " .. tostring(sysID))
    return
  end
  if config.uiConfig then
    self:_HideSubSystemUI(sysID)
    return
  end
end

function NewCamera_Photo_UIBP:_HideSubSystemUI(sysID)
  log(bWriteLog and "NewCamera_Photo_UIBP:CloseSubSystemUI")
  if sysID and self._sysPanels[sysID] then
    self._sysPanels[sysID]:Hide()
  end
end

function NewCamera_Photo_UIBP:_ShowSubSystemUI(sysID)
  log(bWriteLog and "NewCamera_Photo_UIBP:ShowSubSystemUI")
  if sysID and self._sysPanels[sysID] then
    self._sysPanels[sysID]:SelfHitTestInvisible()
  end
end

function NewCamera_Photo_UIBP:_OnClickReplaceableSubSystem(sysID)
  if self._curSubSysID then
    self:_HideSubSystemUI(self._curSubSysID)
  end
  if self._curReplaceableSubSysID and self._curReplaceableSubSysID == sysID and self._curReplaceableSubSysPanel then
    self._curReplaceableSubSysPanel:SelfHitTestInvisible()
    self:_OnReplaceableSubSystemChange()
    return
  end
  if self._curReplaceableSubSysPanel then
    self._curReplaceableSubSysPanel:Close()
    self._curReplaceableSubSysPanel = nil
  end
  self._curReplaceableSubSysID = sysID
  local sysConfig = self._sysConfig[self._curReplaceableSubSysID]
  local uiConfig = sysConfig.uiConfig
  if not uiConfig then
    return
  end
  local panel = self:CreateChildWindow(self.UIRoot.CanvasPanel_BottomParent, uiConfig, true)
  self._curReplaceableSubSysPanel = panel
  self:_OnReplaceableSubSystemChange()
end

function NewCamera_Photo_UIBP:_CloseCurrentReplaceablePanel(bReturnPreSubSystem)
  self:_HideCurrentReplaceablePanel()
  self:_OnReplaceableSubSystemChange()
  if not self._curSubSysID then
    return
  end
  if bReturnPreSubSystem then
    self:_ShowSubSystemUI(self._curSubSysID)
  else
    self:_CloseCurrentMainSystem()
  end
end

function NewCamera_Photo_UIBP:_HideCurrentReplaceablePanel()
  if self._curReplaceableSubSysPanel then
    self._curReplaceableSubSysPanel:Hide()
  end
end

function NewCamera_Photo_UIBP:_OnReplaceableSubSystemChange()
  self:_RefreshEmotionSelectedShow()
end

local Trait = require("common.trait")
local ui_base = require("client.slua_ui_framework.base")
local Operation_Crouch = require("client.slua.umg.operation.Operation_Crouch")
local Operation_Jump = require("client.slua.umg.operation.Operation_Jump")
local Operation_Prone = require("client.slua.umg.operation.Operation_Prone")
local Operation_Swim = require("client.slua.umg.operation.Operation_Swim")
local Operation_AutoSprint = require("client.slua.umg.operation.Operation_AutoSprint")
local Operation_CustomJoystick = require("client.slua.umg.operation.Operation_CustomJoystick")
local Component_HideUIGroup = require("client.slua.umg.common.Component_HideUIGroup")
local Traits = {
  Operation_Crouch,
  Operation_Jump,
  Operation_Prone,
  Operation_Swim,
  Operation_AutoSprint,
  Operation_CustomJoystick,
  Component_HideUIGroup
}
local CNewCamera_Photo_UIBP = Trait.TraitClass(ui_base, nil, NewCamera_Photo_UIBP, Traits)
return CNewCamera_Photo_UIBP
