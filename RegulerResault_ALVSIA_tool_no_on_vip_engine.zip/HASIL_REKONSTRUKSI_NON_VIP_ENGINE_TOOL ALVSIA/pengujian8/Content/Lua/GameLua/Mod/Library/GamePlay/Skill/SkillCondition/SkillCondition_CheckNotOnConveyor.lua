local SkillCondition_CheckNotOnConveyor = {
  sObjectName = "SkillCondition_CheckNotOnConveyor"
}
local GameplayStatics = import("GameplayStatics")
local ActorClass = import("/Script/Engine.Actor")
local SplineClass = import("SplineComponent")
local ConveyorClass = import("/Script/ShadowTrackerExtra.Conveyor")
local DEFAULT_CONVEYOR_RANGE = 2000

function SkillCondition_CheckNotOnConveyor:ctor(selfType)
  print(bWriteLog and "SkillCondition_CheckNotOnConveyor:ctor", selfType)
end

function SkillCondition_CheckNotOnConveyor:GetTargetActor()
  local sTargetKey = self.TargetKey
  if sTargetKey and sTargetKey ~= "" then
    local uTarget = self:GetValueAsWeakObject(sTargetKey)
    if not slua.isValid(uTarget) then
      uTarget = self:GetValueAsObject(sTargetKey)
    end
    return uTarget
  end
  return self:GetOwnerPawn()
end

function SkillCondition_CheckNotOnConveyor:IsOnConveyor(uActor)
  if not slua.isValid(uActor) then
    return false
  end
  if uActor.CheckBaseIsConveyor and uActor:CheckBaseIsConveyor() then
    return true
  end
  return self:IsInsideConveyorVolume(uActor)
end

function SkillCondition_CheckNotOnConveyor:IsInsideConveyorVolume(uActor)
  if not slua.isValid(uActor) then
    return false
  end
  local Loc = uActor:K2_GetActorLocation()
  local nRange = tonumber(self.ConveyorRange) or DEFAULT_CONVEYOR_RANGE
  local Conveyors = GameplayStatics.GetAllActorsOfClass(CGameWorld, ConveyorClass, slua.Array(UEnums.EPropertyClass.Object, ActorClass))
  if not Conveyors then
    return false
  end
  for i = 0, Conveyors:Num() - 1 do
    local uConveyor = Conveyors:Get(i)
    if slua.isValid(uConveyor) then
      local Splines = uConveyor:GetComponentsByClass(SplineClass)
      for j = 0, Splines:Num() - 1 do
        local uSpline = Splines:Get(j)
        if slua.isValid(uSpline) then
          local Closest = uSpline:FindLocationClosestToWorldLocation(Loc, 1)
          if nRange >= FVector.Dist(Loc, Closest) then
            return true
          end
        end
      end
    end
  end
  return false
end

function SkillCondition_CheckNotOnConveyor:ShowFailTips()
  local uOwnerPawn = self:GetOwnerPawn()
  if not Game:IsValid(uOwnerPawn) then
    return
  end
  local nFailShowTipMsgID = tonumber(self.FailShowTipMsgID) or 0
  if 0 < nFailShowTipMsgID then
    local uPlayerController = uOwnerPawn:GetControllerSafety()
    if Game:IsValid(uPlayerController) and uPlayerController.DisplayGameTipWithMsgID then
      uPlayerController:DisplayGameTipWithMsgID(nFailShowTipMsgID)
    end
    return
  end
  local nFailShowTipID = tonumber(self.FailShowTipID) or 0
  if 0 < nFailShowTipID and uOwnerPawn.PlayerKey then
    Game:UIShowTips(uOwnerPawn.PlayerKey, nFailShowTipID)
  end
end

function SkillCondition_CheckNotOnConveyor:LuaIsConditionOK()
  print(bWriteLog and string.format("%s:LuaIsConditionOK", self.sObjectName))
  local uPawn = self:GetTargetActor()
  if self:IsOnConveyor(uPawn) then
    self:ShowFailTips()
    print(bWriteLog and string.format("%s:LuaIsConditionOK false, on conveyor. Target:%s", self.sObjectName, Game:GetObjName(uPawn)))
    return false
  end
  return true
end

function SkillCondition_CheckNotOnConveyor:LuaResetCondition()
  print(bWriteLog and string.format("%s:LuaResetCondition", self.sObjectName))
end

local class = require("class")
local CObjectBase = require("GameLua.Mod.BaseMod.Common.Core.ObjectBase")
local CSkillCondition_CheckNotOnConveyor = class(CObjectBase, nil, SkillCondition_CheckNotOnConveyor)
return CSkillCondition_CheckNotOnConveyor
