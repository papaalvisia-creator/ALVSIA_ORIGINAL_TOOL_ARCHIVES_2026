local EPawnState = import("EPawnState")
local NewCamera_Photo_UIConfig = {}
NewCamera_Photo_UIConfig.ESystem = {
  CameraSetting = 1,
  Drone = 2,
  CameraBaseSetting = 3,
  Emotion = 4,
  Graphics = 5,
  Filter = 6,
  ActionSequence = 7,
  FocalLength = 8,
  FocusLock = 9,
  Aperture = 10,
  Template = 11,
  CameraTilt = 12,
  VisibilitySetting = 13,
  Brightness = 14,
  Contrast = 15,
  Saturation = 16,
  WhiteBalance = 17,
  LightSetting = 18,
  Shadow = 19,
  Bloom = 20,
  EmotionSub = 21,
  FilterSub = 22,
  Suit = 23,
  ActionSequenceSub = 24
}
local ESystem = NewCamera_Photo_UIConfig.ESystem
NewCamera_Photo_UIConfig.EMainSysListType = {
  SystemList = 0,
  EmotionList = 1,
  FilterList = 2
}
local EMainSysListType = NewCamera_Photo_UIConfig.EMainSysListType
NewCamera_Photo_UIConfig.EEmotionCategory = {
  Emote = 1,
  Pet = 2,
  Flaunt = 3,
  Collection = 4,
  MiniTv = 5
}
local EEmotionCategory = NewCamera_Photo_UIConfig.EEmotionCategory
NewCamera_Photo_UIConfig.EHideUIType = {
  HideAll = "HideAll",
  CameraPanDrag = "CameraPanDrag",
  RoleRotateDrag = "RoleRotateDrag",
  HeadAimDrag = "HeadAimDrag",
  ZoomDrag = "ZoomDrag",
  SmartCamera = "SmartCamera",
  Drone = "Drone",
  RoleMove = "RoleMove",
  Photoing = "Photoing",
  Interactive = "Interactive",
  Swim = "Swim",
  DriveVehicle = "DriveVehicle",
  InVehicle = "InVehicle",
  HighlightMode = "HighlightMode",
  SceneShowTransition = "SceneShowTransition",
  ShowSpot = "ShowSpot",
  Simple = "Simple",
  RecordPreview = "RecordPreview",
  PlayActionSequence = "PlayActionSequence",
  FlowerWing = "FlowerWing"
}
local EHideUIType = NewCamera_Photo_UIConfig.EHideUIType
NewCamera_Photo_UIConfig.EPhotoUIDisplayState = {
  None = 0,
  HighlightMode = 1,
  SceneShowTransition = 2,
  ShowSpot = 3,
  Simple = 4
}
local EPhotoUIDisplayState = NewCamera_Photo_UIConfig.EPhotoUIDisplayState
NewCamera_Photo_UIConfig.EFilterTemplateControlType = {
  None = 0,
  BatchDelete = 1,
  Replace = 2
}
NewCamera_Photo_UIConfig.ECameraRecordControlType = {
  None = 0,
  BatchDelete = 1,
  Replace = 2
}
NewCamera_Photo_UIConfig.EmotionCategoryConfig = {
  [EEmotionCategory.Emote] = {
    icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Clap_png.Photo_Icon_Clap_png",
    lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Clap_Select_png.Photo_Icon_Clap_Select_png"
  },
  [EEmotionCategory.Pet] = {
    icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Pet02_png.Photo_Icon_Pet02_png",
    lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Pet02_Select_png.Photo_Icon_Pet02_Select_png"
  },
  [EEmotionCategory.Flaunt] = {
    icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Gift_png.Photo_Icon_Gift_png",
    lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Gift_Select_png.Photo_Icon_Gift_Select_png"
  },
  [EEmotionCategory.Collection] = {
    icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Key_png.Photo_Icon_Key_png",
    lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Key_Select_png.Photo_Icon_Key_Select_png"
  },
  [EEmotionCategory.MiniTv] = {
    icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Robot_png.Photo_Icon_Robot_png",
    lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Robot_Select_png.Photo_Icon_Robot_Select_png"
  }
}

function NewCamera_Photo_UIConfig.GetSystemConfig()
  local config = {
    [ESystem.CameraSetting] = {
      widgetName = "CameraSetting",
      uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Bottom_CameraSetting_UIBP
    },
    [ESystem.Drone] = {widgetName = "Drone"},
    [ESystem.CameraBaseSetting] = {
      widgetName = "CameraBaseSetting",
      listType = EMainSysListType.SystemList,
      sysList = {
        ESystem.FocusLock,
        ESystem.CameraTilt,
        ESystem.FocalLength,
        ESystem.Aperture,
        ESystem.VisibilitySetting,
        ESystem.Template
      }
    },
    [ESystem.Emotion] = {
      widgetName = "Emotion",
      listType = EMainSysListType.EmotionList,
      sysList = {
        ESystem.EmotionSub
      }
    },
    [ESystem.Graphics] = {
      widgetName = "Graphics",
      listType = EMainSysListType.SystemList,
      sysList = {
        ESystem.Brightness,
        ESystem.Contrast,
        ESystem.Saturation,
        ESystem.WhiteBalance,
        ESystem.LightSetting,
        ESystem.Shadow,
        ESystem.Bloom
      }
    },
    [ESystem.Filter] = {
      widgetName = "Filter",
      listType = EMainSysListType.FilterList,
      sysList = {
        ESystem.FilterSub
      }
    },
    [ESystem.ActionSequence] = {
      widgetName = "ActionSequence",
      sysList = {
        ESystem.ActionSequenceSub
      }
    },
    [ESystem.FocalLength] = {
      uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Bottom_FocalLength_UIBP,
      needHDR = true,
      icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_FocalLength_png.Photo_Icon_FocalLength_png",
      lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_FocalLength_Select_png.Photo_Icon_FocalLength_Select_png"
    },
    [ESystem.FocusLock] = {
      uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Bottom_FocusLock_UIBP,
      icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_LockSetting_png.Photo_Icon_LockSetting_png",
      lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_LockSetting_Select_png.Photo_Icon_LockSetting_Select_png"
    },
    [ESystem.Aperture] = {
      uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Bottom_Aperture_UIBP,
      needHDR = true,
      icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Aperture_png.Photo_Icon_Aperture_png",
      lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Aperture_Select_png.Photo_Icon_Aperture_Select_png"
    },
    [ESystem.Template] = {
      uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Bottom_Template_UIBP,
      icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_PhotoTemplate_png.Photo_Icon_PhotoTemplate_png",
      lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_PhotoTemplate_Select_png.Photo_Icon_PhotoTemplate_Select_png"
    },
    [ESystem.CameraTilt] = {
      uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Bottom_CameraTilt_UIBP,
      icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_TiltShot_png.Photo_Icon_TiltShot_png",
      lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_TiltShot_Select_png.Photo_Icon_TiltShot_Select_png"
    },
    [ESystem.VisibilitySetting] = {
      uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Bottom_VisibilitySetting_UIBP,
      icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Visibility_png.Photo_Icon_Visibility_png",
      lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Visibility_Select_png.Photo_Icon_Visibility_Select_png"
    },
    [ESystem.Brightness] = {
      uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Bottom_Brightness_UIBP,
      needHDR = true,
      icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Filter01_png.Photo_Icon_Filter01_png",
      lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Filter01_Select_png.Photo_Icon_Filter01_Select_png"
    },
    [ESystem.Contrast] = {
      uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Bottom_Contrast_UIBP,
      needHDR = true,
      icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Filter02_png.Photo_Icon_Filter02_png",
      lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Filter02_Select_png.Photo_Icon_Filter02_Select_png"
    },
    [ESystem.Saturation] = {
      uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Bottom_Saturation_UIBP,
      needHDR = true,
      icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Filter03_png.Photo_Icon_Filter03_png",
      lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Filter03_Select_png.Photo_Icon_Filter03_Select_png"
    },
    [ESystem.WhiteBalance] = {
      uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Bottom_WhiteBalance_UIBP,
      needHDR = true,
      icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Filter04_png.Photo_Icon_Filter04_png",
      lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Filter04_Select_png.Photo_Icon_Filter04_Select_png"
    },
    [ESystem.LightSetting] = {
      uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Bottom_LightSetting_UIBP,
      icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Filter05_png.Photo_Icon_Filter05_png",
      lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Filter05_Select_png.Photo_Icon_Filter05_Select_png"
    },
    [ESystem.Shadow] = {
      uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Bottom_Shadow_UIBP,
      needHDR = true,
      icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Filter06_png.Photo_Icon_Filter06_png",
      lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Filter06_Select_png.Photo_Icon_Filter06_Select_png"
    },
    [ESystem.Bloom] = {
      uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Bottom_Bloom_UIBP,
      needHDR = true,
      icon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Filter07_png.Photo_Icon_Filter07_png",
      lightIcon = "/Game/Mod/EvoBase/Atlas/NewPhoto/Frames/Photo_Icon_Filter07_Select_png.Photo_Icon_Filter07_Select_png"
    },
    [ESystem.EmotionSub] = {
      uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Bottom_Emotion_UIBP
    },
    [ESystem.FilterSub] = {
      uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Bottom_Filter_UIBP,
      needHDR = true
    },
    [ESystem.Suit] = {
      uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Bottom_Suit_UIBP,
      widgetName = "Suit"
    },
    [ESystem.ActionSequenceSub] = {
      uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Bottom_ActionSequence_UIBP
    }
  }
  return config
end

function NewCamera_Photo_UIConfig.GetComponentLoadConfig()
  local config = {
    frameLoadList = {
      {
        fieldName = "zoomChangeComp",
        uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_ZoomChange_UIBP,
        mountName = "CanvasPanel_Zoom",
        hideCheckNodes = {
          "CanvasPanel_ZoomParent",
          "CanvasPanel_Main"
        }
      },
      {
        fieldName = "cameraMoveComp",
        uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_CameraMove_UIBP,
        mountName = "SizeBox_CameraMoveHandle",
        hideCheckNodes = {
          "CanvasPanel_CameraMove",
          "CanvasPanel_Main"
        }
      },
      {
        fieldName = "roleRotationComp",
        uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_RoleRotation_UIBP,
        mountName = "SizeBox_RoleRotationHandle",
        hideCheckNodes = {
          "CanvasPanel_RoleRotation",
          "CanvasPanel_Main"
        },
        args = {dragMode = 1}
      },
      {
        fieldName = "freeViewComp",
        uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_FreeView_UIBP,
        mountName = "CanvasPanel_FreeView",
        hideCheckNodes = {
          "CanvasPanel_FreeView",
          "CanvasPanel_Control",
          "CanvasPanel_Main"
        }
      },
      {
        fieldName = "focusViewComp",
        uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_FocusView_UIBP,
        mountName = "CanvasPanel_FocusView",
        hideCheckNodes = {
          "CanvasPanel_FocusView",
          "CanvasPanel_Main"
        }
      },
      {
        fieldName = "headAimComp",
        uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_HeadAim_UIBP,
        mountName = "CanvasPanel_HeadAim",
        hideCheckNodes = {
          "CanvasPanel_HeadAimParent",
          "CanvasPanel_Main"
        }
      }
    },
    lazyLoadList = {
      droneControl = {
        fieldName = "droneControlComp",
        uiConfig = UIManager.UI_Config_InGame.NewCamera_Photo_Drone_Control_UIBP,
        mountName = "CanvasPanel_DroneControl"
      }
    }
  }
  return config
end

NewCamera_Photo_UIConfig.HideUIGroup = {
  [EHideUIType.HideAll] = {
    "CanvasPanel_Control",
    "CanvasPanel_Exit",
    "CanvasPanel_Camera",
    "CanvasPanel_FocusView",
    "CanvasPanel_Mode",
    "CanvasPanel_ZoomParent",
    "CanvasPanel_HeadAimParent"
  },
  [EHideUIType.CameraPanDrag] = {
    "CanvasPanel_Control",
    "CanvasPanel_Exit",
    "CanvasPanel_Camera",
    "CanvasPanel_FocusView",
    "CanvasPanel_RoleRotation",
    "CanvasPanel_HideUI",
    "CanvasPanel_ZoomParent",
    "CanvasPanel_HeadAimParent"
  },
  [EHideUIType.RoleRotateDrag] = {
    "CanvasPanel_Control",
    "CanvasPanel_Exit",
    "CanvasPanel_Camera",
    "CanvasPanel_FocusView",
    "CanvasPanel_CameraMove",
    "CanvasPanel_HideUI",
    "CanvasPanel_ZoomParent",
    "CanvasPanel_HeadAimParent"
  },
  [EHideUIType.HeadAimDrag] = {
    "CanvasPanel_Control",
    "CanvasPanel_Exit",
    "CanvasPanel_Camera",
    "CanvasPanel_FocusView",
    "CanvasPanel_Mode",
    "CanvasPanel_HideUI",
    "CanvasPanel_ZoomParent"
  },
  [EHideUIType.ZoomDrag] = {
    "CanvasPanel_Control",
    "CanvasPanel_Exit",
    "CanvasPanel_Camera",
    "CanvasPanel_Mode",
    "CanvasPanel_HideUI",
    "CanvasPanel_HeadAimParent"
  },
  [EHideUIType.SmartCamera] = {
    "CanvasPanel_ZoomParent",
    "CanvasPanel_CameraMove",
    "CanvasPanel_FreeView",
    "CanvasPanel_Drone"
  },
  [EHideUIType.Drone] = {
    "CanvasPanel_Control",
    "CanvasPanel_HideUI",
    "CanvasPanel_FocusView",
    "CanvasPanel_Mode",
    "CanvasPanel_ZoomParent",
    "CanvasPanel_HeadAimParent",
    "CanvasPanel_HeadAimParent",
    "CanvasPanel_Exit",
    "CanvasPanel_Camera"
  },
  [EHideUIType.RoleMove] = {
    "CanvasPanel_ZoomParent"
  },
  [EHideUIType.Photoing] = {"UIRoot"},
  [EHideUIType.Interactive] = {
    "CanvasPanel_HeadAimParent",
    "CanvasPanel_JPC",
    "CanvasPanel_RoleRotation",
    "CanvasPanel_AutoSprint"
  },
  [EHideUIType.Swim] = {
    "CanvasPanel_JPC",
    "CanvasPanel_HeadAimParent"
  },
  [EHideUIType.DriveVehicle] = {
    "CanvasPanel_JPC",
    "CanvasPanel_HeadAimParent",
    "CanvasPanel_AutoSprint",
    "CanvasPanel_RoleRotation"
  },
  [EHideUIType.InVehicle] = {
    "CanvasPanel_JPC",
    "CanvasPanel_HeadAimParent",
    "CanvasPanel_AutoSprint",
    "CanvasPanel_RoleRotation",
    "NewCamera_Photo_MoveJoystick_UIBP"
  },
  [EHideUIType.Simple] = {
    "CanvasPanel_Control",
    "CanvasPanel_HideUI",
    "CanvasPanel_FocusView",
    "CanvasPanel_Mode",
    "CanvasPanel_ZoomParent",
    "CanvasPanel_HeadAimParent"
  },
  [EHideUIType.ShowSpot] = {
    "CanvasPanel_HeadAimParent",
    "CanvasPanel_RoleRotation",
    "CanvasPanel_CameraBaseSetting",
    "CanvasPanel_Emotion",
    "CanvasPanel_Graphics",
    "CanvasPanel_Filter",
    "CanvasPanel_ActionSequence",
    "CanvasPanel_Drone",
    "CanvasPanel_Reset",
    "CanvasPanel_Suit",
    "CanvasPanel_Album",
    "CanvasPanel_HideUI_Spacer",
    "CanvasPanel_ModeSwitch"
  },
  [EHideUIType.RecordPreview] = {
    "CanvasPanel_Control",
    "CanvasPanel_HideUI",
    "CanvasPanel_FocusView",
    "CanvasPanel_Mode",
    "CanvasPanel_ZoomParent",
    "CanvasPanel_HeadAimParent",
    "CanvasPanel_HeadAimParent",
    "CanvasPanel_Exit",
    "CanvasPanel_Camera"
  },
  [EHideUIType.PlayActionSequence] = {
    "CanvasPanel_Control",
    "CanvasPanel_HideUI",
    "CanvasPanel_FocusView",
    "CanvasPanel_Mode",
    "CanvasPanel_ZoomParent",
    "CanvasPanel_HeadAimParent",
    "CanvasPanel_HeadAimParent",
    "CanvasPanel_Exit",
    "CanvasPanel_Camera"
  },
  [EHideUIType.FlowerWing] = {
    "CanvasPanel_JPC",
    "CanvasPanel_RoleRotation"
  }
}
NewCamera_Photo_UIConfig.HideUIWidgetConfig = {
  NewCamera_Photo_MoveJoystick_UIBP = {isButton = true}
}
NewCamera_Photo_UIConfig.CJoystickHideCheckNodes = {
  "UIRoot",
  "NewCamera_Photo_MoveJoystick_UIBP",
  "CanvasPanel_Control",
  "CanvasPanel_Main"
}
NewCamera_Photo_UIConfig.StateToHideUIType = {
  [EPhotoUIDisplayState.HighlightMode] = EHideUIType.Simple,
  [EPhotoUIDisplayState.SceneShowTransition] = EHideUIType.Simple,
  [EPhotoUIDisplayState.ShowSpot] = EHideUIType.ShowSpot,
  [EPhotoUIDisplayState.Simple] = EHideUIType.Simple
}
NewCamera_Photo_UIConfig.PlayerStateToHideUIType = {
  [EPawnState.FlowerWing] = EHideUIType.FlowerWing
}
return NewCamera_Photo_UIConfig
