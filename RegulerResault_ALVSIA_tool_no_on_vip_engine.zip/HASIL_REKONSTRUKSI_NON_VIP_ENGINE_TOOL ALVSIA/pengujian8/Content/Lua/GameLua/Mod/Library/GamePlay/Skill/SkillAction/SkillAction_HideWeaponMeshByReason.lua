local EDIYEntityHiddenReason = import("/Script/ShadowTrackerExtra.EDIYEntityHiddenReason")
local AvatarUtil = require("GameLua.Mod.Library.GamePlay.Avatar.AvatarUtil")
local GUN_MASTER_SLOT = 7
local LOG_TAG = "[HideWeaponMeshByReason]"

local function LogWarn(Format, ...)
  log_warning(string.format(Format, ...))
end

local SkillAction_HideWeaponMeshByReason = {
  sObjectName = "SkillAction_HideWeaponMeshByReason",
  Visibility = false,
  bResetOnUndo = true,
  bOperateAllWeapon = false,
  HiddenReason = EDIYEntityHiddenReason.Hidden_WeaponEffect,
  FilterTableField = ""
}

function SkillAction_HideWeaponMeshByReason:ctor()
  self.ProcessedWeaponAvatarComponents = {}
end

function SkillAction_HideWeaponMeshByReason:GetProcessedComponents()
  if not self.ProcessedWeaponAvatarComponents then
    self.ProcessedWeaponAvatarComponents = {}
  end
  return self.ProcessedWeaponAvatarComponents
end

function SkillAction_HideWeaponMeshByReason:GetStateDesc()
  local Count = 0
  for _ in pairs(self:GetProcessedComponents()) do
    Count = Count + 1
  end
  local OwnerPawn = self:GetOwnerPawn()
  local PlayerKey = slua.isValid(OwnerPawn) and OwnerPawn.PlayerKey or 0
  return string.format("PlayerKey=%s Reason=%s Visibility=%s AllWeapon=%s ResetOnUndo=%s Filter=%s Processed=%d", tostring(PlayerKey), tostring(self.HiddenReason), tostring(self.Visibility), tostring(self.bOperateAllWeapon), tostring(self.bResetOnUndo), tostring(self.FilterTableField), Count)
end

function SkillAction_HideWeaponMeshByReason:GetWeaponManager()
  local OwnerPawn = self:GetOwnerPawn()
  if not slua.isValid(OwnerPawn) then
    LogWarn("%s GetWeaponManager invalid OwnerPawn", LOG_TAG)
    return nil
  end
  local WeaponManager = OwnerPawn:GetWeaponManager()
  if not slua.isValid(WeaponManager) then
    LogWarn("%s GetWeaponManager invalid WeaponManager", LOG_TAG)
    return nil
  end
  return WeaponManager
end

function SkillAction_HideWeaponMeshByReason:ApplyAvatarEntityVisibility(WeaponAvatarComponent, SlotID, AvatarEntity, bIsVisible)
  if not slua.isValid(WeaponAvatarComponent) or not slua.isValid(AvatarEntity) then
    LogWarn("%s ApplyAvatarEntityVisibility skip invalid comp/entity", LOG_TAG)
    return 0
  end
  AvatarEntity:SetAvatarVisibilityByReason(WeaponAvatarComponent, bIsVisible, self.HiddenReason)
  AvatarEntity:SetAvatarEntityParticleVisibility(bIsVisible)
  local FXList = AvatarUtil.GetAttachedFXComponents(WeaponAvatarComponent:GetMeshCompBySlotID(SlotID))
  for _, FX in ipairs(FXList) do
    FX:SetVisibility(bIsVisible, false)
  end
  return #FXList
end

function SkillAction_HideWeaponMeshByReason:ApplyWeaponAvatarEntities(WeaponAvatarComponent, bIsVisible, bRecordComponent)
  if not slua.isValid(WeaponAvatarComponent) then
    LogWarn("%s ApplyWeaponAvatarEntities skip invalid WeaponAvatarComponent", LOG_TAG)
    return
  end
  if not self:IsValidFilterByTableField(WeaponAvatarComponent) then
    printf("%s ApplyWeaponAvatarEntities filtered out Comp=%s", LOG_TAG, tostring(WeaponAvatarComponent))
    return
  end
  if bRecordComponent then
    local ProcessedComponents = self:GetProcessedComponents()
    if ProcessedComponents[WeaponAvatarComponent] then
      printf("%s ApplyWeaponAvatarEntities skip already processed Comp=%s", LOG_TAG, tostring(WeaponAvatarComponent))
      return
    end
    ProcessedComponents[WeaponAvatarComponent] = true
  end
  local AvatarEntityMap = WeaponAvatarComponent.AvatarEntityMap
  if not AvatarEntityMap then
    LogWarn("%s ApplyWeaponAvatarEntities no AvatarEntityMap Comp=%s", LOG_TAG, tostring(WeaponAvatarComponent))
    return
  end
  local EntityCount, FXCount = 0, 0
  for SlotID, AvatarEntity in pairs(AvatarEntityMap) do
    FXCount = FXCount + self:ApplyAvatarEntityVisibility(WeaponAvatarComponent, SlotID, AvatarEntity, bIsVisible)
    EntityCount = EntityCount + 1
  end
  printf("%s ApplyWeaponAvatarEntities Comp=%s Visible=%s Record=%s Entities=%d FX=%d", LOG_TAG, tostring(WeaponAvatarComponent), tostring(bIsVisible), tostring(bRecordComponent), EntityCount, FXCount)
end

function SkillAction_HideWeaponMeshByReason:ApplyWeaponAvatarEntitiesWithSlaveWeapon(Weapon, bIsVisible)
  if not slua.isValid(Weapon) then
    LogWarn("%s ApplyWithSlaveWeapon skip invalid Weapon", LOG_TAG)
    return false
  end
  self:ApplyWeaponAvatarEntities(Weapon.WeaponAvatarComponent, bIsVisible, true)
  local SlaveWeapon = Weapon.SlaveWeapon
  if slua.isValid(SlaveWeapon) then
    printf("%s ApplyWithSlaveWeapon has SlaveWeapon", LOG_TAG)
    self:ApplyWeaponAvatarEntities(SlaveWeapon.WeaponAvatarComponent, bIsVisible, true)
  end
end

function SkillAction_HideWeaponMeshByReason:GetVisibility()
  return self.Visibility == true
end

function SkillAction_HideWeaponMeshByReason:ShouldResetOnUndo()
  return self.bResetOnUndo ~= false
end

function SkillAction_HideWeaponMeshByReason:SetAvatarVisibility(bIsVisible)
  if not Client or self.HiddenReason == nil then
    printf("%s SetAvatarVisibility skip Client=%s Reason=%s", LOG_TAG, tostring(Client), tostring(self.HiddenReason))
    return
  end
  printf("%s SetAvatarVisibility Visible=%s %s", LOG_TAG, tostring(bIsVisible), self:GetStateDesc())
  for WeaponAvatarComponent, _ in pairs(self:GetProcessedComponents()) do
    self:ApplyWeaponAvatarEntities(WeaponAvatarComponent, bIsVisible, false)
  end
end

function SkillAction_HideWeaponMeshByReason:IsValidFilterByTableField(WeaponAvatarComponent)
  if self.HiddenReason ~= EDIYEntityHiddenReason.Hidden_WeaponCheck then
    return true
  end
  if not self.FilterTableField or self.FilterTableField == "" then
    return true
  end
  local AvatarID = WeaponAvatarComponent:GetEquippedItemDefineID(GUN_MASTER_SLOT).TypeSpecificID
  local AvatarItemConfig = CDataTable.GetTableData("Item", AvatarID)
  if not AvatarItemConfig then
    LogWarn("%s Filter: no Item config AvatarID=%s", LOG_TAG, tostring(AvatarID))
    return false
  end
  local WeaponAttrConfigRow = CDataTable.GetTableData("WeaponAttrBPTable", AvatarItemConfig.BPID)
  if not WeaponAttrConfigRow then
    LogWarn("%s Filter: no WeaponAttrBPTable row AvatarID=%s BPID=%s", LOG_TAG, tostring(AvatarID), tostring(AvatarItemConfig.BPID))
    return false
  end
  local bPass = WeaponAttrConfigRow[self.FilterTableField] == true
  printf("%s Filter: AvatarID=%s BPID=%s Field=%s Pass=%s", LOG_TAG, tostring(AvatarID), tostring(AvatarItemConfig.BPID), self.FilterTableField, tostring(bPass))
  return bPass
end

function SkillAction_HideWeaponMeshByReason:LuaRealDoAction()
  if not Client then
    return false
  end
  printf("%s LuaRealDoAction begin %s", LOG_TAG, self:GetStateDesc())
  if next(self:GetProcessedComponents()) then
    printf("%s LuaRealDoAction restore previous processed components", LOG_TAG)
    self:SetAvatarVisibility(true)
  end
  self.ProcessedWeaponAvatarComponents = {}
  if not self.HiddenReason then
    LogWarn("%s LuaRealDoAction abort: HiddenReason is nil", LOG_TAG)
    return false
  end
  local WeaponManager = self:GetWeaponManager()
  if not slua.isValid(WeaponManager) then
    return false
  end
  local Visibility = self:GetVisibility()
  if self.bOperateAllWeapon == true then
    local WeaponList = WeaponManager:GetAllInventoryWeaponList(true)
    if not WeaponList then
      LogWarn("%s LuaRealDoAction abort: WeaponList is nil", LOG_TAG)
      return false
    end
    printf("%s LuaRealDoAction all weapons Num=%d", LOG_TAG, WeaponList:Num())
    for Index = 0, WeaponList:Num() - 1 do
      local Weapon = WeaponList:Get(Index)
      self:ApplyWeaponAvatarEntitiesWithSlaveWeapon(Weapon, Visibility)
    end
    printf("%s LuaRealDoAction end %s", LOG_TAG, self:GetStateDesc())
    return true
  end
  local CurrentWeapon = WeaponManager:GetCurrentUsingWeapon()
  if not slua.isValid(CurrentWeapon) then
    LogWarn("%s LuaRealDoAction current weapon invalid", LOG_TAG)
  end
  local CurrentWeaponAvatarComponent = slua.isValid(CurrentWeapon) and CurrentWeapon.WeaponAvatarComponent
  self:ApplyWeaponAvatarEntities(CurrentWeaponAvatarComponent, Visibility, true)
  printf("%s LuaRealDoAction end %s", LOG_TAG, self:GetStateDesc())
  return true
end

function SkillAction_HideWeaponMeshByReason:LuaResetAction()
  printf("%s LuaResetAction %s", LOG_TAG, self:GetStateDesc())
  self:SetAvatarVisibility(true)
end

function SkillAction_HideWeaponMeshByReason:LuaUndoAction()
  printf("%s LuaUndoAction %s", LOG_TAG, self:GetStateDesc())
  if self:ShouldResetOnUndo() then
    self:LuaResetAction()
  end
  self.ProcessedWeaponAvatarComponents = {}
  SkillAction_HideWeaponMeshByReason.__super.LuaUndoAction(self)
end

local class = require("GameLua.GameCore.Module.Skill.SkillLua.noctor_class")
local CSkillActionBase = require("GameLua.GameCore.Module.Skill.SkillLua.SkillActionBase")
local CSkillAction_HideWeaponMeshByReason = class(CSkillActionBase, nil, SkillAction_HideWeaponMeshByReason)
return CSkillAction_HideWeaponMeshByReason
