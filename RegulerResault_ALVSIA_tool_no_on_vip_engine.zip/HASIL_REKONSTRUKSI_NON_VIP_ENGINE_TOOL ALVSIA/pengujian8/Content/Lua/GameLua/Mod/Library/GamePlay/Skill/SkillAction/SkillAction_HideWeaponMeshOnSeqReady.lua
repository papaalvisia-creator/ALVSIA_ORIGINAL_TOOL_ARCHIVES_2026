local EDIYEntityHiddenReason = import("/Script/ShadowTrackerExtra.EDIYEntityHiddenReason")
local WAIT_TIMEOUT = 5
local SkillAction_HideWeaponMeshOnSeqReady = {
  sObjectName = "SkillAction_HideWeaponMeshOnSeqReady",
  HiddenReason = EDIYEntityHiddenReason.Hidden_WeaponCheck,
  FilterTableField = "CheckWeaponSkillHideOriginWeapon"
}

function SkillAction_HideWeaponMeshOnSeqReady:IsSequenceReady()
  local OwnerPawn = self:GetOwnerPawn()
  if not slua.isValid(OwnerPawn) or not OwnerPawn.GetCurrentLevelSequenceActor then
    return false
  end
  local SequenceActor = OwnerPawn:GetCurrentLevelSequenceActor()
  return slua.isValid(SequenceActor) and slua.isValid(SequenceActor.SequencePlayer)
end

function SkillAction_HideWeaponMeshOnSeqReady:LuaRealDoAction()
  if not Client then
    return false
  end
  self.WaitElapsed = nil
  if self:IsSequenceReady() then
    return SkillAction_HideWeaponMeshOnSeqReady.__super.LuaRealDoAction(self)
  end
  self.WaitElapsed = 0
  return true
end

function SkillAction_HideWeaponMeshOnSeqReady:LuaUpdateAction(InDeltaTime)
  local Elapsed = self.WaitElapsed
  if not Elapsed then
    return
  end
  if self:IsSequenceReady() then
    self.WaitElapsed = nil
    SkillAction_HideWeaponMeshOnSeqReady.__super.LuaRealDoAction(self)
    return
  end
  Elapsed = Elapsed + (InDeltaTime or 0)
  if Elapsed >= WAIT_TIMEOUT then
    self.WaitElapsed = nil
    log_warning(string.format("[HideWeaponMeshOnSeqReady] wait sequence timeout %.1fs %s", Elapsed, self:GetStateDesc()))
    return
  end
  self.WaitElapsed = Elapsed
end

function SkillAction_HideWeaponMeshOnSeqReady:LuaResetAction()
  self.WaitElapsed = nil
  SkillAction_HideWeaponMeshOnSeqReady.__super.LuaResetAction(self)
end

function SkillAction_HideWeaponMeshOnSeqReady:LuaUndoAction()
  self.WaitElapsed = nil
  SkillAction_HideWeaponMeshOnSeqReady.__super.LuaUndoAction(self)
end

local class = require("GameLua.GameCore.Module.Skill.SkillLua.noctor_class")
local CSkillAction_HideWeaponMeshByReason = require("GameLua.Mod.Library.GamePlay.Skill.SkillAction.SkillAction_HideWeaponMeshByReason")
local CSkillAction_HideWeaponMeshOnSeqReady = class(CSkillAction_HideWeaponMeshByReason, nil, SkillAction_HideWeaponMeshOnSeqReady)
return CSkillAction_HideWeaponMeshOnSeqReady
