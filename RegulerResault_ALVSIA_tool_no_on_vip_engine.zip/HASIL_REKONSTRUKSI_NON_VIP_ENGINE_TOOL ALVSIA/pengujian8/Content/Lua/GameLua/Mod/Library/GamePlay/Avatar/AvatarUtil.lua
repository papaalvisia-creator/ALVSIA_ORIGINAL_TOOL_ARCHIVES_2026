local AvatarUtil = {
  CacheUnderWearMap = {},
  GM_GrenadeAvatarTest = nil,
  CacheVoiceParamMap = nil
}
local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
local tonumber = _ENV.tonumber
local tostring = _ENV.tostring
local string = _ENV.string
local GUN_MASTER_SLOT = 7

function AvatarUtil.GetGrenadeKillBindGunID(CurWeaponID, GrenadeID)
  local Cfg = CDataTable.GetTableData("GrenadeKillGunBindMap", GrenadeID)
  if not Cfg then
    return 0
  end
  for k, v in pairs(Cfg.GunIDList_a) do
    if v == CurWeaponID then
      return CurWeaponID
    end
  end
  return 0
end

function AvatarUtil.NeedDoubleCheck(ItemID)
  if CDataTable.GetTableData("UseIntBeforeDownload", ItemID) then
    return false
  end
  local UIUtil = require("client.common.ui_util")
  local itemCfg = UIUtil.GetItemCfg(ItemID)
  if not (itemCfg and itemCfg.ItemType) or not itemCfg.ItemSubType then
    return false
  end
  if itemCfg.ItemType == ENUM_ITEM_TYPE.Extra and (itemCfg.ItemSubType <= ENUM_ITEM_SUBTYPE.Theme_Play or itemCfg.ItemSubType <= ENUM_ITEM_SUBTYPE.Glider_Slot_415 and itemCfg.ItemSubType >= ENUM_ITEM_SUBTYPE.Glider_Slot_413) or itemCfg.ItemType == ENUM_ITEM_TYPE.Backpack and itemCfg.ItemSubType == ENUM_ITEM_SUBTYPE.Helmet then
    return true
  end
  return false
end

function AvatarUtil.DoubleCheckIsDownLoadFinish(resID, pakName)
  log(bWriteLog and "AvatarUtil.DoubleCheckIsDownLoadFinish resID" .. tostring(resID) .. " pakName " .. tostring(pakName))
  local PufferConst = require("client.slua.logic.download.puffer_const")
  if not pakName or pakName == "" then
    return true
  end
  local filePath = Client.ProjectSavedDir() .. PufferConst.PAKS_RELATIVE_DIR .. pakName
  if Client.IsFileExistsWithOutPakCheck(filePath) then
    return true
  end
  log(bWriteLog and "AvatarUtil.DoubleCheckIsDownLoadFinish filePath not in Device " .. tostring(filePath))
  local PufferODPakManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_manager)
  PufferODPakManager:ResetStateByItemID(resID)
  return false
end

function AvatarUtil.GetAvatarHandlePath(resID)
  local UBackpackUtils = import("BackpackUtils")
  local ItemDefineID = UBackpackUtils.GetItemDefineIDByItemID(resID)
  return UBackpackUtils.GetBattleItemHandlePath(ItemDefineID, true, false)
end

function AvatarUtil.GetGlideType(ItemID)
  local GlideTypeConfig = CDataTable.GetTableData("GlideTypeConfig", ItemID)
  if not GlideTypeConfig then
    if Client and Client.IsDevelopment() then
      local itemCfg = CDataTable.GetTableData("Item", ItemID)
      if itemCfg and itemCfg.ItemSubType ~= ENUM_ITEM_SUBTYPE.Glider_Slot_415 then
        ShowDevNotice("###\233\163\158\232\161\140\229\153\168\233\133\141\231\189\174\232\161\168->\233\163\158\232\161\140\229\153\168\229\136\134\231\177\187\239\188\140\230\178\161\230\156\137\233\133\141\231\189\174\239\188\140\233\133\141\228\184\128\228\184\139")
      end
    end
    return -1
  end
  return GlideTypeConfig.TypeID
end

function AvatarUtil.GetGlideCameraSetting(ItemID)
  local itemCfg = CDataTable.GetTableData("Item", ItemID)
  if not itemCfg then
    return
  end
  if itemCfg.ItemSubType == ENUM_ITEM_SUBTYPE.SpecialParachute then
    local ParachuteCameraSetting = CDataTable.GetTableData("ParachuteCameraSetting", ItemID)
    return ParachuteCameraSetting
  end
  local TypeID = AvatarUtil.GetGlideType(ItemID)
  if TypeID < 0 then
    return
  end
  local GlideCameraSetting = CDataTable.GetTableData("GlideCameraSetting", TypeID)
  return GlideCameraSetting
end

function AvatarUtil.IsUnderWearItem(ItemID)
  local UIUtil = require("client.common.ui_util")
  local itemCfg = UIUtil.GetItemCfg(ItemID)
  if not itemCfg then
    return false
  end
  if itemCfg.ItemSubType == ENUM_ITEM_SUBTYPE.UnderCloth or itemCfg.ItemSubType == ENUM_ITEM_SUBTYPE.UnderPants then
    return true
  end
  return false
end

function AvatarUtil.ConvertUnderWearID(ItemID, Color)
  if not Color or Color <= 0 then
    return ItemID
  end
  if AvatarUtil.CacheUnderWearMap[ItemID] and AvatarUtil.CacheUnderWearMap[ItemID][Color] then
    return AvatarUtil.CacheUnderWearMap[ItemID][Color]
  end
  local TableData = CDataTable.GetTableDataByFilter("AvatarInit", "ColorID", Color, "BodyID", ItemID)
  if not TableData then
    return ItemID
  end
  AvatarUtil.CacheUnderWearMap[ItemID] = AvatarUtil.CacheUnderWearMap[ItemID] or {}
  AvatarUtil.CacheUnderWearMap[ItemID][Color] = TableData.UnderWearID
  return TableData.UnderWearID
end

function AvatarUtil.IsXSuitItem(ItemID)
  local AvatarCommon = require("client.slua.logic.avatar.avatar_common")
  return AvatarCommon.IsXSuit(ItemID)
end

function AvatarUtil.GetCharacterWearingXSuitItem(uPlayerCharacter)
  if slua.isValid(uPlayerCharacter) and slua.isValid(uPlayerCharacter.CharacterAvatarComp2_BP) then
    return uPlayerCharacter.CharacterAvatarComp2_BP.XSuitItemID
  end
  return 0
end

function AvatarUtil.IsGoldenSuitItem(ItemID)
  local AvatarCommon = require("client.slua.logic.avatar.avatar_common")
  return AvatarCommon.IsGoldenSuit(ItemID)
end

function AvatarUtil.GetCharacterWearingGoldenSuitItem(uPlayerCharacter)
  if slua.isValid(uPlayerCharacter) and slua.isValid(uPlayerCharacter.CharacterAvatarComp2_BP) then
    return uPlayerCharacter.CharacterAvatarComp2_BP.GoldenSuitItemID
  end
  return 0
end

function AvatarUtil.IsEnableGoldenSuitPerformance(uPlayerCharacter)
  if not slua.isValid(uPlayerCharacter) then
    return false
  end
  if _G.IsEditor then
    return true
  end
  local ServerPlayerDataMgr = require("Server.Data.ServerPlayerDataMgr")
  local UID = Game:GetPlayerUID(uPlayerCharacter)
  local PlayerInfo = ServerPlayerDataMgr.GetPlayerInfo(UID)
  if not PlayerInfo or not PlayerInfo.ext_attr then
    print(bWriteLog and string.format("AvatarUtil.IsEnableGoldenSuitPerformance UID = %s, PlayerInfo or PlayerInfo.ext_attr is not valid", UID))
    return false
  end
  print(bWriteLog and string.format("AvatarUtil.IsEnableGoldenSuitPerformance UID = %s, PlayerInfo.ext_attr[63] = %s", UID, PlayerInfo.ext_attr[63]))
  return PlayerInfo.ext_attr[63] == nil or PlayerInfo.ext_attr[63] == 1
end

function AvatarUtil.GetThrowWeaponProtoItemID_Old(ItemDefineID, Outer)
  local ProtoItemID = AvatarUtil.GetThrowWeaponProtoItemID(ItemDefineID.TypeSpecificID)
  if ProtoItemID < 0 then
    local UBackpackUtils = import("BackpackUtils")
    local GrenadeHandle = UBackpackUtils.CreateBattleItemHandle(ItemDefineID, Outer, false)
    local BackpackGrenadeAvatarHandle = import("BackpackGrenadeAvatarHandle")
    if slua.isValid(GrenadeHandle) and Game:IsClassOf(GrenadeHandle, BackpackGrenadeAvatarHandle) then
      ProtoItemID = GrenadeHandle.ParentID.TypeSpecificID
    end
    if 0 < ProtoItemID then
      local ReportPlatformCrashKit = require("client.slua.logic.report.ReportPlatformCrashKit")
      ReportPlatformCrashKit:ForceSend("GetThrowWeaponProtoItemID:Faild ItemID:" .. tostring(ItemDefineID.TypeSpecificID))
    end
  end
  return ProtoItemID
end

function AvatarUtil.GetThrowWeaponProtoItemID(AvatarID)
  local itemCfg = CDataTable.GetTableData("Item", AvatarID)
  if not itemCfg then
    return -1
  end
  if itemCfg.ItemSubType == 612 then
    return 60200400
  elseif itemCfg.ItemSubType == 613 then
    return 60200200
  elseif itemCfg.ItemSubType == 614 then
    return 60200100
  elseif itemCfg.ItemSubType == 615 then
    return 60200300
  end
  return -1
end

function AvatarUtil.IsBornIsland()
  local GameplayData = require("GameLua.GameCore.Data.GameplayData")
  local uGameState = GameplayData.GetGameState()
  if Game:IsValid(uGameState) and uGameState:GetGameModeState() == "ReadyState" then
    return true
  end
  return false
end

function AvatarUtil.IsItemHasFeature(ItemID, FeatureType)
  local ItemCfg = CDataTable.GetTableData("FeaturesItems", ItemID)
  if ItemCfg then
    local StringUtil = require("common.string_util")
    local features = StringUtil.Split(ItemCfg.Features, ";")
    for _, featureID in ipairs(features) do
      local featureCfg = CDataTable.GetTableData("FeaturesConfig", tonumber(featureID))
      if featureCfg and featureCfg.FeatureType == FeatureType then
        return true
      end
    end
  end
  return false
end

function AvatarUtil.GetWeaponAvatarBPIdByWeapon(uWeapon)
  if not uWeapon or not uWeapon.WeaponAvatarComponent then
    return -1
  end
  local WeaponAvatarID = uWeapon.WeaponAvatarComponent:GetEquippedItemDefineID(GUN_MASTER_SLOT).TypeSpecificID
  if WeaponAvatarID <= 0 then
    print(bWriteLog and string.format("[Error][AvatarUtil]GetWeaponAvatarBPIdByWeapon failed, fallback to ItemID.WeaponAvatarID = %s", WeaponAvatarID))
    WeaponAvatarID = uWeapon:GetItemDefineID().TypeSpecificID
  end
  if WeaponAvatarID <= 0 then
    print(bWriteLog and string.format("[Error][AvatarUtil]GetWeaponAvatarBPIdByWeapon failed, no ItemID exist!WeaponAvatarID = %s", WeaponAvatarID))
    return -1
  end
  local UAvatarUtils = import("AvatarUtils")
  return UAvatarUtils.GetBPIDByResID(WeaponAvatarID)
end

function AvatarUtil.IsWeaponAvatarFeatureSwitchOn(flag, featureSwitchType, bCheckSelfOnly)
  if not flag then
    return true
  end
  local GetControllingFeatureMask = require("client.logic.data.feature_control_mask")
  local selfBit = 1 << featureSwitchType
  local checkMask
  if bCheckSelfOnly then
    checkMask = selfBit
  else
    checkMask = selfBit | GetControllingFeatureMask(featureSwitchType)
  end
  return flag & checkMask == 0
end

function AvatarUtil._EnsureVoiceParamCache()
  if AvatarUtil.CacheVoiceParamMap then
    return
  end
  AvatarUtil.CacheVoiceParamMap = {}
  local AudioParamCfgs = CDataTable.GetTable("WeaponSkinVoiceParamCfg")
  if not AudioParamCfgs then
    return
  end
  local StringUtil = require("common.string_util")
  for _, Cfg in pairs(AudioParamCfgs) do
    if Cfg.RTPCKey and Cfg.RTPCKey ~= "" then
      local RTPCKeyList = {}
      local SplitResult = StringUtil.Split(Cfg.RTPCKey, ";")
      for _, Key in pairs(SplitResult) do
        if Key and Key ~= "" then
          table.insert(RTPCKeyList, Key)
        end
      end
      AvatarUtil.CacheVoiceParamMap[Cfg.AudioType] = {
        RTPCKeyList = RTPCKeyList,
        MinVolume = Cfg.MinVolume,
        MaxVolume = Cfg.MaxVolume,
        AudioType = Cfg.AudioType
      }
    end
  end
end

function AvatarUtil.GetWeaponSkinVoiceParamCache()
  AvatarUtil._EnsureVoiceParamCache()
  return AvatarUtil.CacheVoiceParamMap
end

function AvatarUtil.GetWeaponSkinVoiceParamByAudioType(AudioType)
  AvatarUtil._EnsureVoiceParamCache()
  return AvatarUtil.CacheVoiceParamMap[AudioType]
end

local UNDOWNLOADED_CLOTHES_REPLACE_CFG_NAME = "UnDownloadedClothesReplaceCfg"
local UNDOWNLOADED_CLOTHES_DYE_CFG_NAME = "UnDownloadedClothesDyeCfg"

local function GetUnDownloadedClothesReplaceIDs(Key, Cfg)
  if type(Cfg) ~= "table" and type(Cfg) ~= "userdata" then
    return
  end
  local ItemID = tonumber(Cfg.ItemID or Key)
  local ReplaceItemID = tonumber(Cfg.ReplaceItemID)
  if ItemID and 0 < ItemID and ReplaceItemID and 0 < ReplaceItemID and ItemID ~= ReplaceItemID then
    return ItemID, ReplaceItemID
  end
end

local function NormalizeUnDownloadedClothesDyeColor(HexColor)
  local Hex = tostring(HexColor or ""):gsub("#", ""):upper()
  return Hex:match("^%x%x%x%x%x%x$") and Hex or nil
end

local function GetUnDownloadedClothesCfg(ItemID)
  if not ItemID then
    return nil
  end
  local Cfg = CDataTable.GetTableData(UNDOWNLOADED_CLOTHES_REPLACE_CFG_NAME, ItemID)
  local _, ReplaceItemID = GetUnDownloadedClothesReplaceIDs(ItemID, Cfg)
  if ReplaceItemID then
    local HandlePath = AvatarUtil.GetAvatarHandlePath(ReplaceItemID)
    local pak_util = require("client.common.pak_util")
    local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
    local PufferConst = require("client.slua.logic.download.puffer_const")
    if HandlePath and HandlePath ~= "" and pak_util.IsPufferDownloaded(HandlePath) and PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, {ReplaceItemID}) == PufferConst.ENUM_DownloadState.Done then
      return Cfg, false
    end
  end
  Cfg = CDataTable.GetTableData(UNDOWNLOADED_CLOTHES_DYE_CFG_NAME, ItemID)
  local SourceItemID
  SourceItemID, ReplaceItemID = GetUnDownloadedClothesReplaceIDs(ItemID, Cfg)
  if not ReplaceItemID then
    return nil
  end
  local PrimaryColorHex = NormalizeUnDownloadedClothesDyeColor(Cfg.PrimaryColorHex)
  local SecondaryColorHex = NormalizeUnDownloadedClothesDyeColor(Cfg.SecondaryColorHex) or PrimaryColorHex
  local AccentColorHex = NormalizeUnDownloadedClothesDyeColor(Cfg.AccentColorHex) or PrimaryColorHex
  if PrimaryColorHex and SecondaryColorHex and AccentColorHex then
    return {
      ItemID = SourceItemID,
      ReplaceItemID = ReplaceItemID,
      PrimaryColorHex = PrimaryColorHex,
      SecondaryColorHex = SecondaryColorHex,
      AccentColorHex = AccentColorHex,
      Remark = Cfg.Remark
    }, true
  end
  print(string.format("AvatarUtil.GetUnDownloadedClothesCfg invalid dye config Key:%s ItemID:%s ReplaceItemID:%s " .. "PrimaryColorHex:%s SecondaryColorHex:%s AccentColorHex:%s", tostring(ItemID), tostring(SourceItemID), tostring(ReplaceItemID), tostring(Cfg.PrimaryColorHex), tostring(Cfg.SecondaryColorHex), tostring(Cfg.AccentColorHex)))
end

function AvatarUtil.GetUnDownloadedClothesDyeCfgByReplaceItemID(itemId, sourceItemId)
  if not HDmpveRemote.HDmpveRemoteConfigGetBool("EnableUnDownloadedClothesReplaceDye", true) then
    return nil
  end
  local _, Cfg, bDyeCfg = AvatarUtil.GetUnDownloadedClothesReplaceItemID(sourceItemId)
  if bDyeCfg and Cfg.ReplaceItemID == tonumber(itemId) then
    return Cfg
  end
end

function AvatarUtil.GetUnDownloadedClothesReplaceItemID(itemId)
  local ItemID = tonumber(itemId)
  if not ItemID then
    return nil
  end
  local Cfg, bDyeCfg = GetUnDownloadedClothesCfg(ItemID)
  if Cfg then
    return tonumber(Cfg.ReplaceItemID), Cfg, bDyeCfg
  end
  local DefaultItemID
  local ItemCfg = CDataTable.GetTableData("Item", ItemID)
  if ItemCfg and ItemCfg.ItemType == ENUM_ITEM_TYPE.Extra then
    if ItemCfg.ItemSubType == ENUM_ITEM_SUBTYPE.Pants_Slot then
      DefaultItemID = 1404191
    elseif ItemCfg.ItemSubType == ENUM_ITEM_SUBTYPE.Package_Slot then
      local wardrobe_macro = require("client.slua.umg.Wardrobe.wardrobe_macro")
      if ItemCfg.WardrobeTab == wardrobe_macro.ENUM_WardrobeSubTabString.ENUM_WardrobeSubTabString_clothes then
        DefaultItemID = 1404411
      elseif ItemCfg.WardrobeTab == wardrobe_macro.ENUM_WardrobeSubTabString.ENUM_WardrobeSubTabString_suit then
        DefaultItemID = 1407720
      end
    end
  end
  Cfg, bDyeCfg = GetUnDownloadedClothesCfg(DefaultItemID)
  return Cfg and tonumber(Cfg.ReplaceItemID) or nil, Cfg, bDyeCfg
end

local SkipReplaceItemIDs = {
  [1406936] = true
}

function AvatarUtil.ShouldReplaceItemWhenNotDownloaded(itemId, key)
  if not HDmpveRemote.HDmpveRemoteConfigGetBool("EnableUnDownloadedClothesReplaceDye", true) then
    return false
  end
  if not key or key == 0 or key == "" or key == "0" then
    return false
  end
  if tostring(key) == tostring(DataMgr.roleData.uid) then
    return false
  end
  if not PublishRegionMacros.IsFITVersion() or SkipReplaceItemIDs[tonumber(itemId)] then
    return false
  end
  local itemCfg = CDataTable.GetTableData("Item", itemId)
  if not itemCfg then
    return false
  end
  local ModelDisplayTypeHelper = require("client.logic.avatar.ModelDisplayTypeHelper")
  local bIsPants = itemCfg.ItemType == ENUM_ITEM_TYPE.Extra and itemCfg.ItemSubType == ENUM_ITEM_SUBTYPE.Pants_Slot
  if not ModelDisplayTypeHelper.IsClothingSet(itemCfg.ItemType, itemCfg.ItemSubType) and not bIsPants then
    return false
  end
  if not AvatarUtil.GetUnDownloadedClothesReplaceItemID(itemId) then
    return false
  end
  local HandlePath = AvatarUtil.GetAvatarHandlePath(itemId)
  local pak_util = require("client.common.pak_util")
  return not pak_util.IsPufferDownloaded(HandlePath)
end

local EditorDefaultID = 503107

function AvatarUtil.GetDisplayItemIDWhenNotDownloaded(itemId, key)
  if IsEditor then
    local model_util = require("client.common.model_util")
    local handlePath = model_util.GetPath("Avatar", itemId, false, false)
    if not handlePath or handlePath == "" then
      return itemId
    end
    local packagePath = handlePath:match("^[^%.]+")
    if not Client.DoesPackageExist(packagePath) then
      return EditorDefaultID
    end
  end
  if not AvatarUtil.ShouldReplaceItemWhenNotDownloaded(itemId, key) then
    return itemId
  end
  local ReplaceItemID = AvatarUtil.GetUnDownloadedClothesReplaceItemID(itemId)
  log(bWriteLog and string.format("AvatarUtil.GetDisplayItemIDWhenNotDownloaded configured replace. ItemID:%s ReplaceItemID:%s", tostring(itemId), tostring(ReplaceItemID)))
  return ReplaceItemID
end

local FXSystemComponentClass

function AvatarUtil.GetAttachedFXComponents(MeshComp)
  local FXList = {}
  if not slua.isValid(MeshComp) then
    return FXList
  end
  FXSystemComponentClass = FXSystemComponentClass or import("/Script/Engine.FXSystemComponent")
  local Children = MeshComp:GetChildrenComponents(false, nil)
  for _, Child in pairs(Children) do
    if slua.isValid(Child) and Game:IsClassOf(Child, FXSystemComponentClass) then
      FXList[#FXList + 1] = Child
    end
  end
  return FXList
end

return AvatarUtil
