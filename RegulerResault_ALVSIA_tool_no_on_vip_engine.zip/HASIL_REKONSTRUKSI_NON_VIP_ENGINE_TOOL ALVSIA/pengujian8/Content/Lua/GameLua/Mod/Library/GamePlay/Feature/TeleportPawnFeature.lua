;({
  ServerRPC = {},
  ClientRPC = {},
  ["_PostConstruct"] = function(_ARG_0_)
    do
      __super._PostConstruct(_ARG_0_)
      _ARG_0_.LuaDelegate = U1.LuaDelegate()
      _ARG_0_.bPreTeleportHiddenOnOthers = false
      _ARG_0_.PreTeleportDamageBlocked = false
      _ARG_0_.PreTeleportAllowedDamageTypes = nil
      _ARG_0_.PreTeleportDamageBlockExpireAt = 0
      _ARG_0_.bPreTeleportDamageEventBound = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLifetimeReplicatedProps"] = function(_ARG_0_)
    do
      do return {
        {
          U2(6, 74, 146, 55, 126, 34, 152, 41, 179, 6, 6, 206, 5, 235, 115, 237, 241, 68, 223, 12, 149, 3, 236, 25, 161, 10),
          U1.import((U2(33, 86, 137, 52, 79, 51, 157, 33, 166, 42, 27, 212, 41, 235, 99, 224, 251, 68))).COND_None,
          U1.UEnums.EPropertyClass.Bool
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveBeginPlay"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format((U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 18, 231, 25, 186, 15, 1, 232, 56, 245, 110, 247, 212, 86, 225, 11))))
      U2.__super.ReceiveBeginPlay(_ARG_0_)
      if not _ARG_0_.Owner then
        return
      end
      if not slua.isValid(_ARG_0_.Owner.Object) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckPreload"] = function(_ARG_0_)
    do
      if not _ARG_0_.Owner then
        return
      end
      if not _ARG_0_.Owner:IsLocallyControlled() and not _ARG_0_.Owner:IsLocalViewed() then
        return
      end
      if _ARG_0_.PreloadAssets then
        return
      end
      _ARG_0_.PreloadAssets = {}
      if U2.GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229))) then
        goto lbl_155
        ::lbl_155::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveEndPlay"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.LuaDelegate then
        _ARG_0_.LuaDelegate:Dispose()
      end
      if Client then
        _ARG_0_:StopPreTeleportSequence(true)
        _ARG_0_:_RestorePreTeleportPawnVisibility()
        _ARG_0_:_RestorePreTeleportMovement()
        _ARG_0_:_ReleasePreTeleportLevelHold()
        _ARG_0_:_RestorePreTeleportHiddenOnThisClient()
        _ARG_0_.PreloadAssets = nil
        _ARG_0_:TryRemoveNamedGameTimer((U1(32, 127, 140, 51, 83, 4, 152, 35, 176, 12, 56, 213, 44, 230, 126, 231, 243, 111, 246, 4, 191, 20, 240, 41, 154, 45, 13, 199, 56, 224)))
      else
        _ARG_0_:TryRemoveNamedGameTimer((U1(52, 127, 142, 54, 67, 41, 147, 28, 177, 12, 32, 223, 33, 231, 103, 230, 230, 94, 196, 11, 183, 18, 246)))
        _ARG_0_.PendingPreTeleport = nil
        _ARG_0_:_SetPendingTeleportMovementFrozen(_ARG_0_.Owner and _ARG_0_.Owner.Object, false)
        _ARG_0_:_ReleasePreTeleportServerShowState()
      end
      U2.__super.ReceiveEndPlay(_ARG_0_, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoteTeleportPawnByTable"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_1_.BornPos and #_ARG_1_.BornPos > 0 then
        if 10 < _ARG_2_ then
          print(bWriteLog and table.concat({
            U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 18, 233, 19, 167, 28, 48, 207, 49, 247, 119, 246, 246, 78, 208, 19, 189, 9, 214, 21),
            U1(48, 123, 130, 62, 79, 107, 212, 24, 166, 5, 17, 202, 34, 240, 99, 217, 245, 93, 254, 66, 151, 24, 246, 25, 243, 45, 12, 203, 51, 178, 115, 252, 234, 0, 160)
          }) .. tostring(_ARG_0_.Owner.PlayerKey))
          return
        end
        if not _ARG_0_:RemoteTeleportPawn(_ARG_1_.BornPos[math.random(1, #_ARG_1_.BornPos)].Location, _ARG_1_.BornPos[math.random(1, #_ARG_1_.BornPos)].Roatation, _ARG_3_, _ARG_4_) then
          _ARG_2_ = _ARG_2_ + 1
        end
      end
      do return end
      _ARG_1_ = U1.tostring
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoteTeleportPawn"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not Client and _ARG_0_.Owner then
        if Game:TeleportPawn(_ARG_0_.Owner.Object, _ARG_1_, _ARG_2_, false, true, false, false, _ARG_3_, _ARG_4_) then
          if _ARG_3_ == import((U1(33, 78, 133, 62, 79, 55, 155, 62, 183, 57, 21, 205, 35, 214, 110, 249, 241))).ParachuteTeleport then
          elseif _ARG_3_ == import((U1(33, 78, 133, 62, 79, 55, 155, 62, 183, 57, 21, 205, 35, 214, 110, 249, 241))).RemoteTeleport then
          end
          if _ARG_4_ and _ARG_0_:GetConfig(_ARG_4_) and _ARG_0_:GetConfig(_ARG_4_).GameTLogId and SubsystemMgr:Get((U1(32, 73, 163, 61, 71, 42, 155, 34, 151, 37, 27, 221, 30, 247, 117, 250, 237, 89, 228, 7, 183))) then
          end
        end
        return (Game:TeleportPawn(_ARG_0_.Owner.Object, _ARG_1_, _ARG_2_, false, true, false, false, _ARG_3_, _ARG_4_))
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1[252]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInTeleportState"] = function(_ARG_0_)
    do
      if _ARG_0_.PreTeleportActiveSeqConfig ~= nil or _ARG_0_.PreTeleportSeqActor ~= nil or _ARG_0_.LoadingEffectReason ~= nil or _ARG_0_.PreTeleportLevelHeld == true then
      end
      do return _ARG_0_.PreTeleportActiveSeqConfig ~= nil or _ARG_0_.PreTeleportSeqActor ~= nil or _ARG_0_.LoadingEffectReason ~= nil or _ARG_0_.PreTeleportLevelHeld == true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPawnAttached"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return false
      end
      if not slua.isValid((_ARG_0_.Owner and _ARG_0_.Owner.Object).RootComponent) then
        return false
      end
      do return slua.isValid((_ARG_0_.Owner and _ARG_0_.Owner.Object).RootComponent:GetAttachParent()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPawnOnVehicle"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return false
      end
      do return (_ARG_0_.Owner and _ARG_0_.Owner.Object):HasState(U1.InVehicle) or (_ARG_0_.Owner and _ARG_0_.Owner.Object):HasState(U1.DriveVehicle) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoteTeleport"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_0_:IsPawnOnVehicle() then
        print(bWriteLog and string.format(table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 18, 233, 19, 167, 28, 48, 207, 49, 247, 119, 246, 246, 78, 160, 0, 175, 1, 225, 31),
          U1(1, 126, 204, 114, 90, 38, 131, 34, 227, 6, 26, 154, 59, 231, 127, 224, 247, 70, 245, 78, 250, 39, 232, 29, 170, 28, 22, 225, 56, 235, 39, 164, 164, 31, 243, 94, 234, 36, 251, 2),
          U1(2, 115, 135, 27, 78, 103, 201, 108, 230, 26)
        }), tostring(_ARG_0_.Owner.PlayerKey), tostring(_ARG_3_)))
        return false
      end
      if _ARG_0_:IsPawnAttached() then
        return false
      end
      if _ARG_0_:_TryDeferTeleportForPreSequence(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport, _ARG_4_) then
        return true, (_ARG_0_:_TryCancelCarryBackForTeleport(_ARG_3_))
      end
      if not _ARG_0_:InternalTeleport(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport) then
        return (_ARG_0_:InternalTeleport(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport))
      end
      do return _ARG_0_:InternalTeleport(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport), (_ARG_0_:_TryCancelCarryBackForTeleport(_ARG_3_)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_TryCancelCarryBackForTeleport"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return nil
      end
      if not _ARG_0_:GetConfig(_ARG_1_) or _ARG_0_:GetConfig(_ARG_1_).CancelCarryBackOnTeleport ~= true then
        return nil
      end
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) or not (_ARG_0_.Owner and _ARG_0_.Owner.Object).IsInCarryBackState then
        return nil
      end
      if (_ARG_0_.Owner and _ARG_0_.Owner.Object):IsInCarryBackState() then
      elseif (_ARG_0_.Owner and _ARG_0_.Owner.Object):IsInBeCarriedBackState() then
        if slua.isValid(((_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCarryBackCharacter())) then
        end
      else
        return nil
      end
      do return slua.isValid(((_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCarryBackCharacter())) and (_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCarryBackCharacter() or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_TryDeferTeleportForPreSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if Client then
        return false
      end
      if type(_ARG_0_:GetConfig(_ARG_3_) and _ARG_0_:GetConfig(_ARG_3_).SequenceOnPreTeleport) ~= U1(16, 123, 130, 62, 79) then
        return false
      end
      if not slua.isValid(_ARG_0_.Owner.Object) or _ARG_0_.Owner.bEnsure or not Game:IsPlayer(_ARG_0_.Owner.Object) then
        return false
      end
      if not slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
        return false
      end
      if _ARG_0_.PendingPreTeleport then
        return true
      end
      _ARG_0_.PendingPreTeleportSerial = (_ARG_0_.PendingPreTeleportSerial or 0) + 1
      _ARG_0_.PendingPreTeleport = {
        Location = _ARG_1_,
        Rotation = _ARG_2_,
        ConfigId = _ARG_3_,
        Type = _ARG_4_,
        Serial = _ARG_0_.PendingPreTeleportSerial,
        bStarted = false
      }
      _ARG_0_.PendingPreTeleportTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_3_) and _ARG_0_:GetConfig(_ARG_3_).SequenceOnPreTeleport, (U1(55, 127, 146, 36, 79, 53, 163, 45, 170, 29, 32, 211, 32, 231, 120, 252, 224))), false, function()
        PendingPreTeleportTimer = nil
        _ENV:_ExecutePendingPreTeleport(U1, (U2(48, 115, 141, 55, 69, 50, 128)))
        return
      end)
      if (_ARG_0_:GetConfig(_ARG_3_) and _ARG_0_:GetConfig(_ARG_3_).SequenceOnPreTeleport).DisableMovementDuringSequence == true then
      end
      if _ARG_5_ then
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetPreTeleportSeqConfigValue"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return type(_ARG_1_) == U1(16, 123, 130, 62, 79) and tonumber(_ARG_1_[_ARG_2_]) or nil or tonumber(U2[_ARG_2_]) or 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnClientPreTeleportSeqStarted"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.PendingPreTeleport or _ARG_0_.PendingPreTeleport.Serial ~= _ARG_1_ then
        return
      end
      if _ARG_0_.PendingPreTeleport.bStarted then
        return
      end
      _ARG_0_.PendingPreTeleport.bStarted = true
      if type(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport) == U1(16, 123, 130, 62, 79) and (_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport).HidePawnOnOtherClientsDuringSequence == true then
        _ARG_0_.bPreTeleportHiddenOnOthers = true
      end
      if 0 >= _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) then
      end
      if 0 >= _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) - _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(48, 127, 140, 55, 90, 40, 134, 56, 130, 1, 17, 219, 41, 214, 126, 228, 241))) then
        return
      end
      _ARG_0_.PendingPreTeleportTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) - _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(48, 127, 140, 55, 90, 40, 134, 56, 130, 1, 17, 219, 41, 214, 126, 228, 241))), false, function()
        PendingPreTeleportTimer = nil
        _ENV:_ExecutePendingPreTeleport(U1, (U2(37, 114, 133, 51, 78, 8, 146, 31, 166, 24, 1, 223, 35, 225, 114, 204, 250, 78)))
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[84]
    end
  end,
  ["_OnClientPreTeleportSeqSkipped"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.PendingPreTeleport or _ARG_0_.PendingPreTeleport.Serial ~= _ARG_1_ then
        return
      end
      if _ARG_0_.PendingPreTeleport.bStarted then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ExecutePendingPreTeleport"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.PendingPreTeleport or _ARG_0_.PendingPreTeleport.Serial ~= _ARG_1_ then
        return
      end
      _ARG_0_.PendingPreTeleport = nil
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if _ARG_0_.Owner.bDead == true then
        return
      end
      if not _ARG_0_:InternalTeleport(_ARG_0_.PendingPreTeleport.Location, _ARG_0_.PendingPreTeleport.Rotation, _ARG_0_.PendingPreTeleport.ConfigId, _ARG_0_.PendingPreTeleport.Type) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CancelPendingPreTeleport"] = function(_ARG_0_, _ARG_1_)
    do
      if Client or not _ARG_0_.PendingPreTeleport then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 52, 229, 18, 176, 28, 8, 250, 56, 252, 99, 240, 234, 93, 208, 0, 175, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 103, 164, 32, 162, 16, 17, 200, 6, 231, 110, 169, 169, 10, 181, 17, 246, 87, 215, 25, 161, 16, 5, 198, 125, 175, 39, 188, 247, 22, 160, 32, 175, 6, 231, 3),
        U1(10, 58, 221, 114, 15, 52)
      }), tostring(_ARG_0_.Owner and _ARG_0_.Owner.PlayerKey), tostring(_ARG_0_.PendingPreTeleport.Serial), tostring(_ARG_1_)))
      _ARG_0_.PendingPreTeleport = nil
      _ARG_0_:TryRemoveNamedGameTimer((U1(52, 127, 142, 54, 67, 41, 147, 28, 177, 12, 32, 223, 33, 231, 103, 230, 230, 94, 196, 11, 183, 18, 246)))
      _ARG_0_:_SetPendingTeleportMovementFrozen(_ARG_0_.Owner and _ARG_0_.Owner.Object, false)
      _ARG_0_:_ReleasePreTeleportServerShowState()
      _ARG_0_:RPC_Client_NotifyTeleportFailed()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnOwnerDeath"] = function(_ARG_0_)
    do
      if not Client then
        if not _ARG_0_.PendingPreTeleport then
          return
        end
        if type(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport) == U1(16, 123, 130, 62, 79) and (_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport).CancelTeleportOnDeath == true then
        end
        return
      end
      if type(_ARG_0_.PreTeleportActiveSeqConfig) ~= U1(16, 123, 130, 62, 79) or _ARG_0_.PreTeleportActiveSeqConfig.CancelTeleportOnDeath ~= true then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPendingTeleportMovementFrozen"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      if _ARG_2_ then
        if not slua.isValid(_ARG_1_ and _ARG_1_.STCharacterMovement) or _ARG_0_.PendingTeleportMovementMode ~= nil then
          return
        end
        _ARG_0_.PendingTeleportMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).MovementMode
        _ARG_0_.PendingTeleportCustomMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).CustomMovementMode
        _ARG_0_.PendingTeleportMovementActive = (_ARG_1_ and _ARG_1_.STCharacterMovement):IsActive()
        _ARG_0_.PendingTeleportMovementTickEnabled = (_ARG_1_ and _ARG_1_.STCharacterMovement):IsComponentTickEnabled()
        if _ARG_0_.PendingTeleportMovementMode == U1 then
          _ARG_0_.PendingTeleportMovementMode = U2
          _ARG_0_.PendingTeleportCustomMovementMode = 0
          _ARG_0_.PendingTeleportMovementActive = true
          _ARG_0_.PendingTeleportMovementTickEnabled = true
        end
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          _ARG_0_.PendingTeleportMoveableSaved = (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).bMoveable
        end
        _ARG_0_.PendingTeleportMovementGuardTimer = _ARG_0_:AddGameTimer(0.1, true, function()
          if PendingTeleportMovementMode == nil then
            return
          end
          if not U1.slua.isValid(U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil) then
            return
          end
          if (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil):IsActive() or (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil):IsComponentTickEnabled() or (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil).MovementMode ~= U2 then
          end
          return
        end)
        return
      end
      if _ARG_0_.PendingTeleportMovementMode == nil then
        return
      end
      _ARG_0_.PendingTeleportMovementMode = nil
      _ARG_0_.PendingTeleportCustomMovementMode = nil
      _ARG_0_.PendingTeleportMovementActive = nil
      _ARG_0_.PendingTeleportMovementTickEnabled = nil
      if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) and _ARG_0_.PendingTeleportMoveableSaved ~= nil then
        _ARG_0_.PendingTeleportMoveableSaved = nil
      end
      if slua.isValid(_ARG_1_ and _ARG_1_.STCharacterMovement) then
        if _ARG_1_.bDead ~= true then
        end
        if _ARG_0_.PendingTeleportMovementActive == false then
        end
      end
      do return end
      _ARG_0_ = _ENV[87]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ResolvePreTeleportForbiddenStates"] = function(_ARG_0_, _ARG_1_)
    do
      if (type(_ARG_1_) == U1(16, 123, 130, 62, 79) and _ARG_1_.ForbiddenPawnStatesDuringSequence or nil) == true then
      end
      if type(U2) ~= U1(16, 123, 130, 62, 79) then
        return nil
      end
      goto lbl_158
      if type(62) == U1(23, 110, 146, 59, 68, 32) then
      end
      if U3[62] ~= nil and U3[62] ~= U3.Dying and U3[62] ~= U3.Dead then
      else
      end
      ::lbl_158::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportPawnStatesDisabled"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ then
        if _ARG_0_.PreTeleportDisabledPawnStates or not slua.isValid(_ARG_1_) then
          return
        end
        if not _ARG_0_:_ResolvePreTeleportForbiddenStates(_ARG_2_) or #_ARG_0_:_ResolvePreTeleportForbiddenStates(_ARG_2_) == 0 then
          return
        end
        goto lbl_41
        ::lbl_41::
        _ARG_0_ = _ARG_0_
        _ARG_0_.PreTeleportDisabledPawnStates, _ARG_0_ = {}, _ARG_0_
        return
      end
      _ARG_0_.PreTeleportDisabledPawnStates = nil
      if not _ARG_0_.PreTeleportDisabledPawnStates or not slua.isValid(_ARG_1_) then
        return
      end
      goto lbl_154
      ::lbl_154::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CancelPreTeleportHoldGrenade"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) or not _ARG_1_:HasState(U1.HoldGrenade) then
        return
      end
      print(bWriteLog and table.concat({
        U2(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 52, 229, 18, 176, 28, 8, 250, 47, 247, 83, 252, 232, 95, 240, 29, 184, 19, 220, 3),
        U2(8, 126, 167, 32, 79, 41, 149, 40, 166)
      }))
      if Client then
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          ;(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).TouchEndTriggerSkillID = -1
        end
      end
      _ARG_1_:TriggerCustomEvent(U3.PlayerRequestCancel, -1)
      if Client then
        EventSystem:postEvent(EVENTTYPE_INGAME_SHOOTINGUI_PANEL, EVENTID_ON_THROW_CANCEL_BUTTON_CLICK)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportGrenadePredictLine"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if not _ARG_0_.Owner.IsLocallyControlled or not _ARG_0_.Owner:IsLocallyControlled() then
        return
      end
      if not slua.isValid(((_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCurrentWeapon())) or not (_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCurrentWeapon().EnableWeaponPredictLine then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PreparePreTeleportLocomotion"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_.DisableMovementDuringSequence == true and _ARG_2_.StopAllSkillsOnSequence == true and slua.isValid((_ARG_1_:GetPlayerControllerSafety())) and (_ARG_1_:GetPlayerControllerSafety():GetCurrentStateType() == import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteJump or _ARG_1_:GetPlayerControllerSafety():GetCurrentStateType() == import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteOpen) then
        if not Client and _ARG_1_:GetPlayerControllerSafety():GetCurrentStateType() == import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteOpen and _ARG_1_:GetPlayerControllerSafety().GetStateMachineCompent and slua.isValid((_ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent())) and _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState and _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill == true then
          _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill = false
        end
        if Client then
        else
        end
        if slua.isValid(_ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState) and _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill == true then
          _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill = true
        end
      end
      if _ARG_2_.StopAllSkillsOnSequence == true then
        if Client then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ApplyPreTeleportServerShowState"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not (not Client and slua.isValid(_ARG_1_)) or type(_ARG_2_) ~= U1(16, 123, 130, 62, 79) then
        return
      end
      _ARG_0_:_ReleasePreTeleportServerShowState()
      _ARG_0_:_PreparePreTeleportLocomotion(_ARG_1_, _ARG_2_)
      if _ARG_2_.ExitScopeOnSequence == true then
        _ARG_1_:ScopeInterrupt(U2.Normal)
      end
      _ARG_0_:_SetPreTeleportPawnStatesDisabled(_ARG_1_, _ARG_2_, true)
      _ARG_0_:_AddPreTeleportDamageBlock(_ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ResolvePreTeleportAllowedDamageTypes"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_.AllowedDamageTypesDuringSequence) ~= U1(16, 123, 130, 62, 79) then
      end
      goto lbl_193
      if type(62) == U1(10, 111, 141, 48, 79, 53) and 62 or type(62) == U1(23, 110, 146, 59, 68, 32) and import((U1(33, 94, 129, 63, 75, 32, 145, 24, 186, 25, 17)))[62] or nil then
      else
      end
      ::lbl_193::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {
        [type(62) == U1(10, 111, 141, 48, 79, 53) and 62 or type(62) == U1(23, 110, 146, 59, 68, 32) and import((U1(33, 94, 129, 63, 75, 32, 145, 24, 186, 25, 17)))[62] or nil] = true
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetPreTeleportDamageBlockMaxDuration"] = function(_ARG_0_, _ARG_1_)
    do
      if (U1.type(_ARG_1_) == _ENV(16, 123, 130, 62, 79) and U1.tonumber(_ARG_1_.DamageBlockMaxDuration) or nil) and 0 < (U1.type(_ARG_1_) == _ENV(16, 123, 130, 62, 79) and U1.tonumber(_ARG_1_.DamageBlockMaxDuration) or nil) then
        return U1.type(_ARG_1_) == _ENV(16, 123, 130, 62, 79) and U1.tonumber(_ARG_1_.DamageBlockMaxDuration) or nil
      end
      do return _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(55, 127, 146, 36, 79, 53, 163, 45, 170, 29, 32, 211, 32, 231, 120, 252, 224))) + _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) + _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 9, 227, 122, 232, 243, 79, 210, 14, 181, 20, 239, 52, 188, 21, 0, 254, 52, 255, 98))) + 10 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_AddPreTeleportDamageBlock"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) or _ARG_1_.BlockDamageDuringSequence ~= true then
        return
      end
      _ARG_0_:_RemovePreTeleportDamageBlock()
      _ARG_0_.PreTeleportAllowedDamageTypes = _ARG_0_:_ResolvePreTeleportAllowedDamageTypes(_ARG_1_)
      _ARG_0_.PreTeleportDamageBlocked = true
      _ARG_0_.PreTeleportDamageBlockExpireAt = (slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) and U2.GetRealTimeSeconds(_ARG_0_.Owner and _ARG_0_.Owner.Object) or 0) + _ARG_0_:_GetPreTeleportDamageBlockMaxDuration(_ARG_1_)
      _ARG_0_.PreTeleportDamageBlockSafetyTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportDamageBlockMaxDuration(_ARG_1_), false, function()
        PreTeleportDamageBlockSafetyTimer = nil
        if PreTeleportDamageBlocked then
          U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
            U2(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 54, 224, 24, 131, 11, 1, 254, 56, 254, 98, 233, 235, 72, 244, 54, 171, 10, 245, 11),
            U2(1, 88, 140, 61, 73, 44, 212, 63, 162, 15, 17, 206, 52, 162, 99, 224, 249, 79, 255, 23, 174, 87, 161, 15, 243, 10, 72, 138, 59, 253, 117, 250, 225, 26, 242, 23, 166, 2, 245, 31),
            U2(1, 54, 192, 2, 70, 38, 141, 41, 177, 34, 17, 195, 109, 191, 55, 172, 231)
          }), U1.tostring(U3), U1.tostring(Owner and Owner.PlayerKey)))
          _ENV:_RemovePreTeleportDamageBlock()
        end
        return
      end)
      if not _ARG_0_.bPreTeleportDamageEventBound then
        _ARG_0_.bPreTeleportDamageEventBound = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RemovePreTeleportDamageBlock"] = function(_ARG_0_)
    do
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 254, 44, 239, 118, 238, 241, 104, 252, 13, 185, 28, 208, 21, 190, 28, 22)))
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 254, 44, 239, 118, 238, 241, 104, 252, 13, 185, 28, 215, 29, 181, 28, 16, 211, 9, 251, 106, 252, 246)))
      _ARG_0_.PreTeleportDamageBlockSafetyTimer = nil
      _ARG_0_.PreTeleportDamageBlockExpireAt = 0
      if not _ARG_0_.PreTeleportDamageBlocked then
        return
      end
      _ARG_0_.PreTeleportDamageBlocked = false
      _ARG_0_.PreTeleportAllowedDamageTypes = nil
      if _ARG_0_.bPreTeleportDamageEventBound then
        _ARG_0_.bPreTeleportDamageEventBound = false
        _ARG_0_:RemoveCommonEvent(U1.EVENTTYPE_INGAME_NORMAL, U1.EVENTID_PRE_TAKE_DAMAGE)
      end
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        _ENV(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 37, 225, 17, 188, 15, 1, 250, 47, 247, 83, 252, 232, 95, 240, 29, 184, 19, 208, 13),
        _ENV(9, 123, 135, 55, 104, 43, 155, 47, 168, 73, 36, 214, 44, 251, 114, 251, 223, 79, 233, 66, 231, 87, 161, 15)
      }), U1.tostring(_ARG_0_.Owner and _ARG_0_.Owner.PlayerKey)))
      return
    end
  end,
  ["HandlePreTeleportPreTakeDamage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not (not Client and _ARG_0_.PreTeleportDamageBlocked) or not slua.isValid(_ARG_3_) then
        return
      end
      if not slua.isValid(_ARG_3_.Target) then
        return
      end
      if not (_ARG_3_.Target.PlayerKey and _ARG_0_.Owner) or _ARG_3_.Target.PlayerKey ~= _ARG_0_.Owner.PlayerKey then
        return
      end
      if slua.isValid(_ARG_0_.Owner.Object) and _ARG_0_.PreTeleportDamageBlockExpireAt > 0 and U1.GetRealTimeSeconds(_ARG_0_.Owner.Object) > _ARG_0_.PreTeleportDamageBlockExpireAt then
        return
      end
      if _ARG_0_.PreTeleportAllowedDamageTypes and _ARG_0_.PreTeleportAllowedDamageTypes[_ARG_3_.DamageType] then
        return
      end
      _ARG_3_.Damage = 0
      do return end
      _ARG_1_ = _ENV[12]
    end
  end,
  ["_ScheduleReleasePreTeleportServerShowState"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if _ARG_0_.PreTeleportDamageBlocked then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 9, 227, 122, 232, 243, 79, 210, 14, 181, 20, 239, 52, 188, 21, 0, 254, 52, 255, 98))) then
          _ARG_0_.PreTeleportDamageBlockTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 9, 227, 122, 232, 243, 79, 210, 14, 181, 20, 239, 52, 188, 21, 0, 254, 52, 255, 98))), false, function()
            PreTeleportDamageBlockTimer = nil
            _ENV:_RemovePreTeleportDamageBlock()
            return
          end)
        else
        end
      end
      if _ARG_0_.bPreTeleportHiddenOnOthers then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(55, 114, 143, 37, 122, 38, 131, 34, 140, 7, 59, 206, 37, 231, 101, 250, 208, 79, 252, 3, 163))) then
          _ARG_0_.PreTeleportShowOnOthersTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(55, 114, 143, 37, 122, 38, 131, 34, 140, 7, 59, 206, 37, 231, 101, 250, 208, 79, 252, 3, 163))), false, function()
            PreTeleportShowOnOthersTimer = nil
            bPreTeleportHiddenOnOthers = false
            return
          end)
        else
          _ARG_0_.bPreTeleportHiddenOnOthers = false
        end
      end
      if _ARG_0_.PreTeleportDisabledPawnStates then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 30, 246, 118, 253, 241, 98, 255, 14, 190, 35, 237, 17, 182))) then
          _ARG_0_.PreTeleportStateRestoreTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 30, 246, 118, 253, 241, 98, 255, 14, 190, 35, 237, 17, 182))), false, function()
            PreTeleportStateRestoreTimer = nil
            _ENV:_SetPreTeleportPawnStatesDisabled(Owner and Owner.Object, nil, false)
            return
          end)
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ReleasePreTeleportServerShowState"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      _ARG_0_:TryRemoveNamedGameTimer((U1(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 233, 37, 237, 96, 198, 250, 101, 228, 10, 191, 5, 247, 40, 186, 20, 1, 216)))
      _ARG_0_:TryRemoveNamedGameTimer((U1(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 233, 57, 227, 99, 236, 198, 79, 227, 22, 181, 5, 225, 40, 186, 20, 1, 216)))
      if _ARG_0_.bPreTeleportHiddenOnOthers then
        _ARG_0_.bPreTeleportHiddenOnOthers = false
      end
      _ARG_0_:_SetPreTeleportPawnStatesDisabled(_ARG_0_.Owner and _ARG_0_.Owner.Object, nil, false)
      _ARG_0_:_RemovePreTeleportDamageBlock()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_bPreTeleportHiddenOnOthers"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if _ARG_0_.bPreTeleportHiddenOnOthers == true and not _ARG_0_:IsLocal() then
        if not _ARG_0_.PreTeleportHiddenOnThisClient then
          _ARG_0_.PreTeleportHiddenOnThisClient = true
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportHiddenOnThisClient"] = function(_ARG_0_)
    do
      if not _ARG_0_.PreTeleportHiddenOnThisClient then
        return
      end
      _ARG_0_.PreTeleportHiddenOnThisClient = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Server_ReportPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 128, 28, 22, 220, 56, 224, 88, 203, 225, 74, 239, 0, 190, 55, 230, 9),
        U1(48, 127, 140, 55, 90, 40, 134, 56, 144, 12, 5, 207, 40, 236, 116, 236, 180, 122, 252, 3, 163, 18, 246, 55, 182, 0, 68, 151, 125, 183, 116, 181, 164, 104, 229, 2, 165, 21, 224, 56),
        U1(29, 106, 133, 114, 23, 103, 209, 63, 239, 73, 39, 223, 63, 235, 118, 229, 180, 23, 176, 71, 169)
      }), tostring(_ARG_0_.Owner.PlayerKey), tostring(_ARG_1_), tostring(_ARG_2_)))
      if _ARG_1_ == U2.Started then
        _ARG_0_:_OnClientPreTeleportSeqStarted(_ARG_2_)
      elseif _ARG_1_ == U2.Skipped then
        _ARG_0_:_OnClientPreTeleportSeqSkipped(_ARG_2_)
      else
        print(bWriteLog and string.format(table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 128, 28, 22, 220, 56, 224, 88, 203, 225, 74, 239, 0, 190, 55, 230, 9),
          U1(48, 127, 140, 55, 90, 40, 134, 56, 144, 12, 5, 207, 40, 236, 116, 236, 180, 88, 245, 8, 191, 20, 240, 25, 183, 85, 68, 223, 51, 249, 105, 246, 243, 84, 160, 32, 175, 23, 251, 30),
          U1(16, 78, 153, 34, 79, 103, 201, 108, 230, 26)
        }), tostring(_ARG_1_)))
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Client_PlayPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_, _ARG_9_, _ARG_10_, _ARG_11_, _ARG_12_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 144, 21, 13, 207, 51, 230, 88, 201, 232, 91, 249, 34, 184, 2, 192, 9),
        U1(8, 127, 144, 61, 88, 51, 167, 41, 178, 28, 17, 212, 46, 231, 55, 202, 251, 68, 246, 11, 189, 62, 224, 92, 238, 89, 65, 217, 113, 178, 84, 252, 246, 83, 225, 30, 234, 90, 180, 73),
        U1(23, 54, 192, 26, 75, 52, 164, 32, 162, 16, 32, 200, 44, 236, 100, 239, 251, 88, 253, 66, 231, 87, 161, 15, 255, 89, 48, 203, 47, 245, 98, 237, 200, 85, 227, 82, 247, 71, 188, 73),
        U1(23, 54, 192, 119, 89, 107, 212, 105, 176, 64)
      }), tostring(_ARG_1_), tostring(_ARG_2_), tostring(_ARG_3_), tostring(_ARG_10_), tostring(_ARG_11_), tostring(_ARG_12_)))
      if _ARG_3_ == 1 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShouldSkipPreTeleportSequence"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) or _ARG_1_.SkipOnLowDevice ~= true then
        return false
      end
      do return require((U1(7, 117, 141, 63, 69, 41, 218, 8, 166, 31, 29, 217, 40, 215, 99, 224, 248, 89))).GetDeviceLevel() ~= nil and require((U1(7, 117, 141, 63, 69, 41, 218, 8, 166, 31, 29, 217, 40, 215, 99, 224, 248, 89))).GetDeviceLevel() <= require((U1(7, 117, 141, 63, 69, 41, 218, 8, 166, 31, 29, 217, 40, 215, 99, 224, 248, 89))).ENum_DeviceLevel.Low end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InternalTeleport"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      print(bWriteLog and table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 147, 25, 240, 25, 161, 23, 5, 198, 9, 247, 107, 252, 244, 85, 242, 6, 234, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 4, 155, 34, 165, 0, 19, 243, 41, 162)
      }) .. tostring(_ARG_3_))
      if not _ARG_0_:CheckPawn(_ARG_0_.Owner.Object) then
        return false
      end
      if _ARG_0_:IsPawnOnVehicle() then
        return false
      end
      if _ARG_0_:IterateTargetLocation(_ARG_1_, function(_ARG_0_)
        do
          if _ENV and U1:LineTraceHit(U2, _ARG_0_) then
            return false, U3.LineTrace
          end
          if U4.Game:TeleportPawn(U5, _ARG_0_, U6, false, true, false, false, U7, U8) then
            return true
          else
            return false, U3.TeleportPawn
          end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end) then
        _ARG_0_.LocationBeforeTeleport = _ARG_0_.Owner:K2_GetActorLocation()
        if _ARG_0_.Config and _ARG_0_.Config.ParachuteTeleport == true then
        else
        end
        if _ARG_0_.Owner.Object.PlayerUID then
        end
      else
      end
      do return (_ARG_0_:IterateTargetLocation(_ARG_1_, function(_ARG_0_)
        do
          if _ENV and U1:LineTraceHit(U2, _ARG_0_) then
            return false, U3.LineTrace
          end
          if U4.Game:TeleportPawn(U5, _ARG_0_, U6, false, true, false, false, U7, U8) then
            return true
          else
            return false, U3.TeleportPawn
          end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckPawn"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return false
      end
      if not slua.isValid(_ARG_1_) then
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 31, 225, 31, 184, 41, 5, 221, 51, 178, 114, 201, 229, 77, 238, 82, 163, 20, 180, 2),
          U1(11, 110, 192, 36, 75, 43, 157, 40)
        }))))
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLineTraceEnabled"] = function(_ARG_0_, _ARG_1_)
    do
      if not (_ARG_1_ and _ARG_1_.TestLocation) or _ARG_1_.TestLocation.LineTraceEnabled == nil then
        return true
      end
      do return _ARG_1_.TestLocation.LineTraceEnabled end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IterateTargetLocation"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_(_ARG_1_) then
        return true
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_2_(_ARG_1_ + FVector(U2[U1(10, 58, 172, 61, 73, 38, 128, 37, 172, 7, 84, 135, 109, 167, 100, 165, 180, 108, 241, 11, 182, 18, 224, 46, 182, 24, 23, 197, 51, 178, 58, 185, 161, 73)].X * _ARG_1_:ToString(), U2[U1(10, 58, 172, 61, 73, 38, 128, 37, 172, 7, 84, 135, 109, 167, 100, 165, 180, 108, 241, 11, 182, 18, 224, 46, 182, 24, 23, 197, 51, 178, 58, 185, 161, 73)].Y * _ARG_1_:ToString(), U1(10, 58, 172, 61, 73, 38, 128, 37, 172, 7, 84, 135, 109, 167, 100, 165, 180, 108, 241, 11, 182, 18, 224, 46, 182, 24, 23, 197, 51, 178, 58, 185, 161, 73)) * (_ARG_0_.Config and _ARG_0_.Config.TestLocation and _ARG_0_.Config.TestLocation.OffsetValue or 100)) then
        return true
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LineTraceHit"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.TraceActorsToIgnore then
        _ARG_0_.TraceActorsToIgnore = slua.Array(UEnums.EPropertyClass.Object, (import((U1(75, 73, 131, 32, 67, 55, 128, 99, 134, 7, 19, 211, 35, 231, 57, 200, 247, 94, 255, 16)))))
      end
      do return import((U1(47, 115, 147, 63, 79, 51, 167, 53, 176, 29, 17, 215, 1, 235, 117, 251, 245, 88, 233))).LineTraceSingle(_ARG_0_.Owner.Object, _ARG_1_, _ARG_2_, 0, true, _ARG_0_.TraceActorsToIgnore, import((U1(33, 94, 146, 51, 93, 3, 145, 46, 182, 14, 32, 200, 44, 225, 114))).None, import((U1(75, 73, 131, 32, 67, 55, 128, 99, 134, 7, 19, 211, 35, 231, 57, 193, 253, 94, 194, 7, 169, 2, 232, 8)))(), true, FLinearColor.Red, FLinearColor.Green, 1) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ForceHolsterBeforeParachuteJump"] = function(_ARG_0_, _ARG_1_)
    do
      if Client or not slua.isValid(_ARG_1_) then
        return
      end
      if not slua.isValid(_ARG_1_.GetWeaponManager and _ARG_1_:GetWeaponManager()) then
        return
      end
      if (_ARG_1_.GetWeaponManager and _ARG_1_:GetWeaponManager()).bIsSwitching == true then
      end
      if (_ARG_1_.GetWeaponManager and _ARG_1_:GetWeaponManager()):GetCurrentUsingPropSlot() ~= import((U1(33, 73, 149, 32, 92, 46, 130, 41, 148, 12, 21, 202, 34, 236, 71, 251, 251, 90, 195, 14, 181, 3))).SWPS_None then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ParachuteJump"] = function(_ARG_0_)
    do
      if _ARG_0_.Owner then
        print(bWriteLog and U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 138, 22, 246, 29, 176, 17, 17, 222, 56, 216, 114, 244, 244, 26, 211, 6, 171, 21, 224))
        _ARG_0_:_ForceHolsterBeforeParachuteJump(_ARG_0_.Owner.Object)
        if slua.isValid((_ARG_0_.Owner:GetControllerSafety())) then
          if not _ARG_0_.Owner:GetEnsure() then
            if _ARG_0_.Owner:GetControllerSafety():GetCurrentStateType() ~= import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteJump and _ARG_0_.Owner:GetControllerSafety():GetCurrentStateType() ~= import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteOpen then
              if _ARG_0_.Config and _ARG_0_.Config.OpenParachuteAfterTeleport == true then
              else
              end
            end
          else
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreTeleport"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      _ARG_0_.Config = _ARG_0_:GetConfig(_ARG_1_)
      if _ARG_0_.Config and _ARG_0_.Config.StopAllSkillsOnTeleport == true then
      end
      if _ARG_0_.Owner.PoseState == U3.Crouch or _ARG_0_.Owner.PoseState == U3.Prone then
      end
      if _ARG_0_.Owner.PoseState == U3.GunADS then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetConfig"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229))) then
        return
      end
      if not GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_] then
        return
      end
      if GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_].HideAllUI == nil then
        GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_].HideAllUI = true
      end
      do return GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostTeleport"] = function(_ARG_0_)
    do
      _ARG_0_:CheckTLog()
      _ARG_0_:StartWaitingClientLoading()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckTLog"] = function(_ARG_0_)
    do
      if not _ARG_0_.Config then
        return
      end
      if not SubsystemMgr:Get((U1(32, 73, 163, 61, 71, 42, 155, 34, 151, 37, 27, 221, 30, 247, 117, 250, 237, 89, 228, 7, 183))) then
        return
      end
      if _ARG_0_.Config.GameTLogId and _ARG_0_.Config.GameTLogId ~= 0 then
      end
      if _ARG_0_.Config.PlayerTLogId and _ARG_0_.Config.PlayerTLogId ~= 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientTeleportStartCallback"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not (_ARG_1_ and _ARG_0_.Owner) or not Client then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientTeleportCallback"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not (_ARG_1_ and _ARG_0_.Owner) or not Client then
        return
      end
      _ARG_0_.Config = _ARG_0_:GetConfig(_ARG_5_)
      if not _ARG_0_.Config then
        return
      end
      if _ARG_0_.PreTeleportPawnDrivenByShow == true and _ARG_0_.PreTeleportShowFinished ~= true then
      else
      end
      _ARG_0_.PreTeleportClientLanded = true
      if _ARG_0_:CheckLoading(_ARG_2_, _ARG_0_.Config) then
      else
      end
      if _ARG_0_.Config and _ARG_0_.Config.AudioOnPreTeleport then
        if _ARG_0_.Config.AudioOnPreTeleport2D then
          if _ARG_0_:IsAutonomousProxy() then
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = _ENV[245]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetPreTeleportSequencePaths"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) then
        return nil, nil, nil
      end
      if not _ARG_1_.LevelSequenceActorPath or _ARG_1_.LevelSequenceActorPath == U1() then
      end
      if _ARG_1_.BindPlayerPawnName and _ARG_1_.BindPlayerPawnName ~= U1() and _ARG_1_.BindLocalPlayerPawn ~= true and (not _ARG_1_.ShowPawnActorPath or _ARG_1_.ShowPawnActorPath == U1()) then
      end
      do return _ARG_1_.LevelSequencePath, U2.LevelSequenceActorPath, U2.ShowPawnActorPath end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not Client or not _ARG_0_:IsLocal() then
        return false
      end
      if not (_ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) and _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) ~= U1() and _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_)) or _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) == U1() then
        return false
      end
      if _ARG_1_.BindPlayerPawnName and _ARG_1_.BindPlayerPawnName ~= U1() and _ARG_1_.BindLocalPlayerPawn ~= true and (not _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) or _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) == U1()) then
        return false
      end
      _ARG_0_.PreTeleportSeqOnFailed = _ARG_2_
      _ARG_0_.PreTeleportSeqOnStarted = _ARG_3_
      if _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) then
      end
      _ARG_0_.PreTeleportSeqLoadHandle = _ARG_0_:AsyncLoadAssetArray({
        _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_)
      }, function()
        PreTeleportSeqLoadHandle = nil
        if not (U1 == PreTeleportSeqSerial and Owner) or not U2.slua.isValid(Owner.Object) then
          return
        end
        if U3 then
          if not _ENV:_SpawnPreTeleportShowPawn(U3, U4, U1, function()
            _ENV:_StartPreTeleportSequence(U1, U2, U3, U4, U5, U6)
            return
          end) then
          end
        else
          _ENV:_StartPreTeleportSequence(U5, U6, U7, U1, nil, nil)
        end
        return
      end)
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_NotifyPreTeleportSeqFailed"] = function(_ARG_0_)
    do
      _ARG_0_.PreTeleportSeqOnStarted = nil
      _ARG_0_.PreTeleportSeqOnFailed = nil
      if _ARG_0_.PreTeleportSeqOnFailed then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_NotifyPreTeleportSeqStarted"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 57, 235, 8, 186, 31, 29, 250, 47, 247, 83, 252, 232, 95, 240, 29, 184, 19, 199, 9),
        U1(21, 73, 148, 51, 88, 51, 145, 40, 227, 58, 0, 219, 63, 246, 71, 229, 245, 83)
      }))
      _ARG_0_.PreTeleportSeqOnStarted = nil
      _ARG_0_.PreTeleportSeqOnFailed = nil
      if _ARG_0_.PreTeleportSeqOnStarted then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SpawnPreTeleportShowPawn"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not slua.loadClass(_ARG_1_) or not slua.isValid(CGameWorld) then
        return false
      end
      if not _ARG_0_.Owner or not slua.isValid(_ARG_0_.Owner.Object) then
        return false
      end
      if not slua.isValid((CGameWorld:SpawnActor(slua.loadClass(_ARG_1_), _ARG_0_.Owner:K2_GetActorLocation(), _ARG_0_.Owner:K2_GetActorRotation(), nil))) then
        return false
      end
      if not slua.isValid(CGameWorld:SpawnActor(slua.loadClass(_ARG_1_), _ARG_0_.Owner:K2_GetActorLocation(), _ARG_0_.Owner:K2_GetActorRotation(), nil).CharacterAvatarComp2_BP) then
        return false
      end
      _ARG_0_.PreTeleportShowPawn = CGameWorld:SpawnActor(slua.loadClass(_ARG_1_), _ARG_0_.Owner:K2_GetActorLocation(), _ARG_0_.Owner:K2_GetActorRotation(), nil)
      _ARG_0_.PreTeleportSeqAvatarTimer = _ARG_0_:AddGameTimer(U2.AvatarLoadTimeout, false, function()
        PreTeleportSeqAvatarTimer = nil
        U1.print(U1.bWriteLog and U1.table.concat({
          U2(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 36, 244, 29, 164, 23, 52, 216, 56, 198, 98, 245, 225, 74, 239, 0, 190, 52, 252, 3),
          U2(19, 74, 129, 37, 68, 103, 149, 58, 162, 29, 21, 200, 109, 238, 120, 232, 240, 10, 228, 11, 183, 18, 235, 9, 167, 85, 68, 218, 49, 243, 126, 185, 229, 84, 249, 5, 171, 30)
        }))
        U3()
        return
      end)
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_StartPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if _ARG_1_.BindPlayerPawnName then
        if _ARG_1_.BindLocalPlayerPawn == true then
          _ARG_0_.PreTeleportPawnDrivenByShow = true
        else
        end
      end
      if _ARG_1_.DisablePlayerPawnSpawnTrack == true and _ARG_1_.BindPlayerPawnName and _ARG_1_.BindPlayerPawnName ~= U1() then
      end
      if not slua.isValid((Game:PlayLevelSequence(_ARG_0_.Owner and _ARG_0_.Owner.Object, _ARG_2_, _ARG_5_ or import((U1(47, 115, 147, 63, 79, 51, 185, 45, 183, 1, 56, 211, 47, 240, 118, 251, 237))).MakeTransform(_ARG_1_.Location or FVector(0, 0, 0), _ARG_1_.Rotation or FRotator(0, 0, 0), FVector(1, 1, 1)), _ARG_3_, true, {
        [_ARG_1_.BindPlayerPawnName] = _ARG_0_.PreTeleportShowPawn
      }, _ARG_0_.Owner and _ARG_0_.Owner.Object, {
        _ARG_1_.BindPlayerPawnName
      }))) then
        return
      end
      _ARG_0_.PreTeleportSeqActor = Game:PlayLevelSequence(_ARG_0_.Owner and _ARG_0_.Owner.Object, _ARG_2_, _ARG_5_ or import((U1(47, 115, 147, 63, 79, 51, 185, 45, 183, 1, 56, 211, 47, 240, 118, 251, 237))).MakeTransform(_ARG_1_.Location or FVector(0, 0, 0), _ARG_1_.Rotation or FRotator(0, 0, 0), FVector(1, 1, 1)), _ARG_3_, true, {
        [_ARG_1_.BindPlayerPawnName] = _ARG_0_.PreTeleportShowPawn
      }, _ARG_0_.Owner and _ARG_0_.Owner.Object, {
        _ARG_1_.BindPlayerPawnName
      })
      do return end
      _ARG_2_ = _ENV[161]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnPreTeleportSequenceEnd"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ ~= _ARG_0_.PreTeleportSeqSerial then
        return
      end
      print(bWriteLog and table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 56, 234, 44, 161, 28, 48, 207, 49, 247, 119, 246, 246, 78, 211, 23, 187, 18, 241, 2),
        U1(7, 127, 165, 60, 78)
      }))
      _ARG_0_.PreTeleportSeqActor = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopPreTeleportSequence"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
        _ARG_0_.PreTeleportSeqOnFailed = nil
      end
      _ARG_0_.PreTeleportSeqOnStarted = nil
      _ARG_0_.PreTeleportPawnDrivenByShow = nil
      _ARG_0_.PreTeleportSeqSerial = (_ARG_0_.PreTeleportSeqSerial or 0) + 1
      if _ARG_0_.PreTeleportSeqLoadHandle then
        _ARG_0_:CancelAsyncLoad(_ARG_0_.PreTeleportSeqLoadHandle)
        _ARG_0_.PreTeleportSeqLoadHandle = nil
      end
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 233, 40, 243, 86, 255, 245, 94, 241, 16, 142, 30, 233, 25, 161)))
      _ARG_0_.PreTeleportSeqActor = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnPreTeleportSeqPlayStarted"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 142, 30, 233, 25, 161)))
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 158, 18, 232, 29, 170, 45, 13, 199, 56, 224)))
      _ARG_0_:_ReleasePreTeleportLevelHold()
      _ARG_0_.PreTeleportShowFinished = nil
      _ARG_0_.PreTeleportClientLanded = nil
      if _ARG_1_.HoldStreamingAtTarget == true and _ARG_3_ then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(44, 117, 140, 54, 121, 51, 134, 41, 162, 4, 29, 212, 42, 195, 99, 221, 245, 88, 247, 7, 174, 51, 225, 16, 178, 0))) then
          _ARG_0_.PreTeleportLevelHoldDelayTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(44, 117, 140, 54, 121, 51, 134, 41, 162, 4, 29, 212, 42, 195, 99, 221, 245, 88, 247, 7, 174, 51, 225, 16, 178, 0))), false, function()
            PreTeleportLevelHoldDelayTimer = nil
            _ENV:_ArmPreTeleportLevelHold(U1, U2)
            return
          end)
        else
        end
      end
      if _ARG_1_.HidePlayerPawnDuringSequence == true and U1.slua.isValid(_ARG_2_) then
        _ARG_0_.PreTeleportPawnHidden = true
        _ARG_0_:SetPlayerCharacterHiddenInGame(_ARG_2_, true)
      end
      if _ARG_1_.BindLocalPlayerPawn == true and U1.slua.isValid(_ARG_2_) then
        _ARG_0_:_SetPreTeleportControllerRotationDisabled(_ARG_2_, true)
      end
      if _ARG_1_.DisableMovementDuringSequence == true and U1.slua.isValid(_ARG_2_) then
        _ARG_0_:_DetachBeCarriedBackForSequence(_ARG_2_)
        _ARG_0_:_SetPreTeleportMovementDisabled(_ARG_2_, true)
        _ARG_0_:_SetPreTeleportMoveInputIgnored(true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ArmPreTeleportLevelHold"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.PreTeleportLevelHeld or _ARG_0_.PreTeleportShowFinished or _ARG_0_.PreTeleportClientLanded then
        return
      end
      if _ARG_2_ ~= nil and _ARG_2_ ~= _ARG_0_.PreTeleportSeqSerial then
        return
      end
      if not SubsystemMgr:Get((U1(40, 127, 150, 55, 70, 20, 128, 62, 166, 8, 25, 211, 35, 229, 90, 238, 230))) then
        return
      end
      _ARG_0_.PreTeleportLevelHeld = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[1]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_DetachBeCarriedBackForSequence"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_1_.IsInBeCarriedBackState or not _ARG_1_:IsInBeCarriedBackState() then
        return
      end
      if slua.isValid(_ARG_1_.GetCarryBackComp and _ARG_1_:GetCarryBackComp() or nil) and (_ARG_1_.GetCarryBackComp and _ARG_1_:GetCarryBackComp() or nil).StopBeCarriedBack then
        if not _ARG_1_:IsInBeCarriedBackState() then
          return
        end
      end
      if not slua.isValid(_ARG_1_.RootComponent) or not slua.isValid(_ARG_1_.RootComponent:GetAttachParent()) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportMovementDisabled"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_ and _ARG_1_.STCharacterMovement) then
        return
      end
      if _ARG_2_ then
        if _ARG_0_.PreTeleportMovementMode ~= nil then
          return
        end
        _ARG_0_.PreTeleportMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).MovementMode
        _ARG_0_.PreTeleportCustomMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).CustomMovementMode
        _ARG_0_.PreTeleportMovementTickEnabled = (_ARG_1_ and _ARG_1_.STCharacterMovement):IsComponentTickEnabled()
        if _ARG_0_.PreTeleportMovementMode == U1 then
          _ARG_0_.PreTeleportMovementMode = U2
          _ARG_0_.PreTeleportCustomMovementMode = 0
          _ARG_0_.PreTeleportMovementTickEnabled = true
        end
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          _ARG_0_.PreTeleportMoveableSaved = (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).bMoveable
        end
        _ARG_0_.PreTeleportMovementGuardTimer = _ARG_0_:AddGameTimer(0.1, true, function()
          if PreTeleportMovementMode == nil then
            return
          end
          if not U1.slua.isValid(U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil) then
            return
          end
          if (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil):IsComponentTickEnabled() or (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil).MovementMode ~= U2 then
          end
          return
        end)
      else
        _ARG_0_.PreTeleportMovementMode = nil
        _ARG_0_.PreTeleportCustomMovementMode = nil
        _ARG_0_.PreTeleportMovementTickEnabled = nil
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) and _ARG_0_.PreTeleportMoveableSaved ~= nil then
          _ARG_0_.PreTeleportMoveableSaved = nil
        end
        if _ARG_0_.PreTeleportMovementMode ~= nil then
          if _ARG_1_.bDead ~= true then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnOwnerExitState"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not Client or _ARG_2_ ~= U1.BeCarriedBack or _ARG_0_.PreTeleportMovementMode == nil then
        return
      end
      if not slua.isValid(slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) and (_ARG_0_.Owner and _ARG_0_.Owner.Object).STCharacterMovement or nil) then
        return
      end
      if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
        if _ARG_0_.PreTeleportMoveableSaved == nil then
          _ARG_0_.PreTeleportMoveableSaved = (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).bMoveable
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1[88]
    end
  end,
  ["_SetPreTeleportControllerRotationDisabled"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_2_ then
        if _ARG_0_.PreTeleportControllerRotationSaved then
          return
        end
        _ARG_0_.PreTeleportControllerRotationSaved = {
          Yaw = _ARG_1_.bUseControllerRotationYaw,
          Pitch = _ARG_1_.bUseControllerRotationPitch,
          Roll = _ARG_1_.bUseControllerRotationRoll
        }
        _ARG_1_.bUseControllerRotationYaw = false
        _ARG_1_.bUseControllerRotationPitch = false
        _ARG_1_.bUseControllerRotationRoll = false
        print(bWriteLog and table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 36, 225, 8, 131, 11, 1, 254, 56, 254, 98, 233, 235, 72, 244, 49, 165, 9, 224, 30),
          U1(11, 118, 140, 55, 88, 21, 155, 56, 162, 29, 29, 213, 35, 198, 126, 250, 245, 72, 252, 7, 190, 87, 224, 21, 160, 24, 6, 198, 56, 246)
        }))
      else
        if not _ARG_0_.PreTeleportControllerRotationSaved then
          return
        end
        _ARG_0_.PreTeleportControllerRotationSaved = nil
        _ARG_1_.bUseControllerRotationYaw = _ARG_0_.PreTeleportControllerRotationSaved.Yaw
        _ARG_1_.bUseControllerRotationPitch = _ARG_0_.PreTeleportControllerRotationSaved.Pitch
        _ARG_1_.bUseControllerRotationRoll = _ARG_0_.PreTeleportControllerRotationSaved.Roll
        if _ARG_1_:K2_GetActorRotation().Pitch ~= 0 or _ARG_1_:K2_GetActorRotation().Roll ~= 0 then
        end
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) and (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()):GetControlRotation().Roll ~= 0 then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ApplyPreTeleportClientShowState"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client or type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) then
        return
      end
      _ARG_0_.PreTeleportActiveSeqConfig = _ARG_1_
      if not _ARG_0_.Owner then
        return
      end
      if not slua.isValid(_ARG_0_.Owner.Object) then
        return
      end
      if not _ARG_0_.Owner:IsLocallyControlled() then
        return
      end
      if _ARG_1_.ExitScopeOnSequence == true then
      end
      if _ARG_1_.ForceTPPDuringSequence == true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportClientShowState"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      _ARG_0_.PreTeleportActiveSeqConfig = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportForceTPP"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ then
        if _ARG_0_.PreTeleportForceTPPApplied or not slua.isValid(_ARG_1_) then
          return
        end
        _ARG_0_.PreTeleportForceTPPApplied = true
        if _ARG_1_:GetIsFPP() then
          _ARG_1_.bForceChangePersonPerspective = true
          _ARG_0_.PreTeleportChangedPP = true
        end
        _ARG_0_.PreTeleportSwitchPPWasDisabled = _ARG_1_:IsPawnStateDisabled(U1.SwitchPP)
        return
      end
      if not _ARG_0_.PreTeleportForceTPPApplied then
        return
      end
      _ARG_0_.PreTeleportForceTPPApplied = nil
      _ARG_0_.PreTeleportChangedPP = nil
      _ARG_0_.PreTeleportSwitchPPWasDisabled = nil
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_0_.PreTeleportSwitchPPWasDisabled then
      end
      if _ARG_0_.PreTeleportChangedPP then
        if _ARG_1_.bDead ~= true then
        end
        _ARG_1_.bForceChangePersonPerspective = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportMoveInputIgnored"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      if _ARG_1_ then
        if _ARG_0_.PreTeleportMoveInputIgnored then
          return
        end
        if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          return
        end
        _ARG_0_.PreTeleportMoveInputPC, _ARG_0_.PreTeleportMoveInputIgnored = _ARG_0_.Owner and _ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety(), true
      else
        if not _ARG_0_.PreTeleportMoveInputIgnored then
          return
        end
        _ARG_0_.PreTeleportMoveInputIgnored = nil
        _ARG_0_.PreTeleportMoveInputPC = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportMovement"] = function(_ARG_0_)
    do
      _ARG_0_:_SetPreTeleportMoveInputIgnored(false)
      if _ARG_0_.PreTeleportMovementMode == nil then
        return
      end
      if slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
      else
        _ARG_0_.PreTeleportMovementMode = nil
        _ARG_0_.PreTeleportCustomMovementMode = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_StopPreTeleportSeqShowHandling"] = function(_ARG_0_)
    do
      _ARG_0_.PreTeleportShowFinished = true
      _ARG_0_.PreTeleportPawnDrivenByShow = nil
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 158, 18, 232, 29, 170, 45, 13, 199, 56, 224)))
      _ARG_0_:_RestorePreTeleportPawnVisibility()
      _ARG_0_:_RestorePreTeleportMovement()
      _ARG_0_:_SetPreTeleportControllerRotationDisabled(_ARG_0_.Owner and _ARG_0_.Owner.Object, false)
      _ARG_0_:_RestorePreTeleportClientShowState()
      if not _ARG_0_.PreTeleportLevelHeld then
        return
      end
      if _ARG_0_.PreTeleportClientLanded then
        _ARG_0_:_ReleasePreTeleportLevelHold()
        return
      end
      if not _ARG_0_.PreTeleportLevelHoldTimer then
        _ARG_0_.PreTeleportLevelHoldTimer = _ARG_0_:AddGameTimer(U1.HoldReleaseTimeout, false, function()
          PreTeleportLevelHoldTimer = nil
          _ENV:_ReleasePreTeleportLevelHold()
          return
        end)
        U2.print(U2.bWriteLog and U2.table.concat({
          _ENV(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 36, 240, 19, 163, 41, 22, 207, 9, 247, 107, 252, 244, 85, 242, 6, 153, 2, 229, 63),
          _ENV(12, 117, 151, 26, 75, 41, 144, 32, 170, 7, 19, 154, 58, 227, 126, 253, 180, 76, 255, 16, 250, 27, 229, 18, 183, 16, 10, 205, 125, 240, 98, 255, 235, 72, 229, 82, 184, 2, 248, 9),
          _ENV(5, 105, 137, 60, 77, 103, 156, 35, 175, 13)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ReleasePreTeleportLevelHold"] = function(_ARG_0_)
    do
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 158, 18, 232, 29, 170, 45, 13, 199, 56, 224)))
      if not _ARG_0_.PreTeleportLevelHeld then
        return
      end
      _ARG_0_.PreTeleportLevelHeld = nil
      _ARG_0_.PreTeleportShowFinished = nil
      _ARG_0_.PreTeleportClientLanded = nil
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 142, 30, 233, 25, 161)))
      if U1.SubsystemMgr:Get((_ENV(40, 127, 150, 55, 70, 20, 128, 62, 166, 8, 25, 211, 35, 229, 90, 238, 230))) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[147]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportPawnVisibility"] = function(_ARG_0_)
    do
      if not _ARG_0_.PreTeleportPawnHidden then
        return
      end
      _ARG_0_.PreTeleportPawnHidden = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_DestroyPreTeleportShowPawn"] = function(_ARG_0_)
    do
      _ARG_0_.PreTeleportShowPawn = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSimulatedAndNotSpectating"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_1_:IsSimulated() and not (U1.slua.isValid((GetPlayerController())) and GetPlayerController():IsInSpectating()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPlayerCharacterHiddenInGame"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ then
        _ARG_1_:SetActorHiddenInGame(true)
      elseif not _ARG_1_.CharacterHide or not _ARG_1_.CharacterHide.bCharacterHideIngame then
        _ARG_1_:SetActorHiddenInGame(false)
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 137, 18, 240, 44, 191, 24, 29, 207, 47, 209, 111, 248, 246, 91, 227, 6, 175, 21, 220, 5),
        U1(0, 126, 133, 60, 99, 41, 179, 45, 174, 12, 84, 159, 62, 162, 63, 172, 231, 3)
      }), _ARG_2_, _ARG_1_:ToString()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckLoading"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.Owner:IsAutonomousProxy() then
      elseif Client and slua.isValid((U1.GetPlayerController())) and U1.GetPlayerController():IsSpectator() and slua.isValid(U1.GetPlayerController():GetCurPlayerCharacter()) and U1.GetPlayerController():GetCurPlayerCharacter().PlayerKey == _ARG_0_.Owner.PlayerKey then
      end
      if not (SubsystemMgr:Get((U2(40, 127, 150, 55, 70, 20, 128, 62, 166, 8, 25, 211, 35, 229, 90, 238, 230))) and true) or _ARG_2_.NotShowLoading then
        return false
      end
      if _ARG_2_ and _ARG_2_.SkipLoadingUI == true then
      end
      if _ARG_0_.LoadingEffectReason == nil then
      end
      do return true end
      do return end
      _ARG_1_ = U1[147]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartWaitingClientLoading"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 137, 3, 229, 14, 167, 46, 5, 195, 41, 251, 105, 254, 199, 86, 233, 23, 164, 19, 216, 3),
        U1(5, 126, 137, 60, 77, 103, 209, 63)
      }), _ARG_0_.Owner:ToString()))
      _ARG_0_.WaitingClientLoadingTimer = _ARG_0_:AddGameTimer(U2, false, function()
        print(bWriteLog and string.format(table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 137, 3, 229, 14, 167, 46, 5, 195, 41, 251, 105, 254, 199, 86, 233, 23, 164, 19, 216, 3),
          U1(5, 126, 137, 60, 77, 103, 163, 45, 170, 29, 29, 212, 42, 193, 123, 224, 241, 68, 228, 46, 181, 22, 224, 21, 189, 30, 48, 195, 48, 247, 117, 185, 240, 83, 237, 23, 165, 18, 224, 76),
          U1(65, 105)
        }), U2.Owner:ToString()))
        U2:OnReceiveClientTeleportLoadingFinish()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLevelStreamingLoadEnd"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 200, 25, 165, 28, 8, 249, 41, 224, 98, 248, 233, 83, 238, 21, 134, 8, 245, 8),
        U1(33, 116, 132, 114, 15, 52)
      }), _ARG_3_))
      _ARG_0_:RemoveCommonEvent(EVENTTYPE_LEVELSTREAMING, EVENTID_LEVELSTREAMING_LOAD_END)
      if _ARG_0_.Config then
        _ARG_0_:OnClientLanded()
      end
      _ARG_0_:RPC_Server_NotifyTeleportLoadingFinish()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Server_NotifyTeleportLoadingFinish"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 128, 28, 22, 220, 56, 224, 88, 215, 235, 78, 233, 20, 179, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 11, 155, 45, 167, 0, 26, 221, 11, 235, 121, 224, 231, 66, 176, 71, 169)
      }), _ARG_0_.Owner:ToString()))
      _ARG_0_:OnReceiveClientTeleportLoadingFinish()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnReceiveClientTeleportLoadingFinish"] = function(_ARG_0_)
    do
      if not _ARG_0_.WaitingClientLoadingTimer then
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 214, 25, 176, 28, 13, 220, 56, 209, 107, 240, 225, 84, 244, 38, 175, 11, 241, 28),
          U1(11, 104, 148, 30, 69, 38, 144, 37, 173, 14, 50, 211, 35, 235, 100, 225, 180, 68, 255, 66, 141, 22, 237, 8, 186, 23, 3, 233, 49, 251, 98, 247, 240, 118, 239, 19, 174, 14, 250, 11),
          U1(48, 115, 141, 55, 88, 107, 212, 62, 166, 29, 1, 200, 35)
        }))))
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 214, 25, 176, 28, 13, 220, 56, 209, 107, 240, 225, 84, 244, 38, 175, 11, 241, 28),
        U1(11, 104, 148, 30, 69, 38, 144, 37, 173, 14, 50, 211, 35, 235, 100, 225, 180, 15, 227)
      }), _ARG_0_.Owner:ToString()))
      _ARG_0_:TryRemoveNamedGameTimer((U1(51, 123, 137, 38, 67, 41, 147, 15, 175, 0, 17, 212, 57, 206, 120, 232, 240, 67, 254, 5, 142, 30, 233, 25, 161)))
      _ARG_0_.LuaDelegate:Broadcast(U2, _ARG_0_.Owner)
      _ARG_0_.LuaDelegate:Remove(U2)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ListenOnClientTeleportLoadingFinished"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.LuaDelegate:Add(_ENV, _ARG_1_, _ARG_2_)
      do return _ARG_0_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientPreCheckLoadingEffect"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 27, 237, 25, 189, 13, 52, 216, 56, 209, 111, 252, 231, 81, 204, 29, 171, 3, 253, 2),
        U1(3, 95, 134, 52, 79, 36, 128, 108, 230, 26)
      }), _ARG_1_))
      if _ARG_0_.MarkTeleportFailed then
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 27, 237, 25, 189, 13, 52, 216, 56, 209, 111, 252, 231, 81, 204, 29, 171, 3, 253, 2),
          U1(3, 95, 134, 52, 79, 36, 128, 108, 169, 28, 7, 206, 109, 207, 118, 251, 255, 126, 245, 14, 191, 7, 235, 14, 167, 63, 5, 195, 49, 247, 99, 181, 164, 72, 229, 6, 191, 21, 250)
        }))))
        return
      end
      if _ARG_0_.LoadingEffectReason == nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckLoadingEffect"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:IsLocal() then
        return
      end
      if not _ARG_1_ or not _ARG_1_.LoadingEffect then
        return
      end
      if not _ARG_1_.LoadingEffect.Type or not _ARG_1_.LoadingEffect.Param then
        return
      end
      _ARG_0_.LoadingEffectReason = _ARG_2_
      if _ARG_1_.LoadingEffect.Type == U1(55, 121, 146, 55, 79, 41, 177, 42, 165, 12, 23, 206) then
        if slua.isValid((slua.loadObject(_ARG_1_.LoadingEffect.Param .. U1(59, 89)))) then
          _ARG_0_.LoadingEffectObject = import((U1(55, 121, 146, 55, 79, 41, 181, 60, 179, 12, 21, 200, 44, 236, 116, 236, 199, 94, 241, 22, 179, 20, 247))).PlayDynamicScreenAppearance(_ARG_0_.Owner.Object, _ARG_0_.Owner.Object, import((U1(55, 78, 165, 42, 94, 53, 149, 11, 162, 4, 17, 202, 33, 227, 110, 218, 224, 75, 228, 11, 185, 4))).GetClassDefaultObject((slua.loadObject(_ARG_1_.LoadingEffect.Param .. U1(59, 89)))).AppearanceName, (slua.loadObject(_ARG_1_.LoadingEffect.Param .. U1(59, 89))))
        end
      elseif _ARG_1_.LoadingEffect.Type == U1(49, 83) and UIManager.UI_Config_InGame[_ARG_1_.LoadingEffect.Param] then
        _ARG_0_.LoadingEffectObject = UIManager.ShowUI(UIManager.UI_Config_InGame[_ARG_1_.LoadingEffect.Param])
      end
      if _ARG_0_.LoadingEffectObject then
        _ARG_0_.StartLoadingEffectTime = U3.GetRealTimeSeconds(_ARG_0_.Owner.Object)
        _ARG_0_.LoadingEffectObjectTimeoutTimer = _ARG_0_:AddGameTimer(U2, false, function()
          print(bWriteLog and string.format((table.concat({
            U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 31, 225, 31, 184, 53, 11, 203, 57, 251, 105, 254, 193, 92, 230, 23, 169, 19, 180, 24),
            U1(13, 119, 133, 61, 95, 51)
          }))))
          U2:TryDestroyLoadingEffect()
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[61]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientLanded"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 199, 16, 186, 28, 10, 222, 17, 243, 105, 253, 225, 94))
      if not (_ARG_0_.Config and Client) or not _ARG_0_.Owner then
        return
      end
      if slua.isValid((_ARG_0_.Owner:GetControllerSafety())) and not _ARG_0_.Owner.bEnsure then
        _ARG_0_.Owner:GetControllerSafety().bAutoSprint = false
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryDestroyLoadingEffect"] = function(_ARG_0_)
    do
      if not _ARG_0_:IsLocal() then
        return
      end
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(40, 117, 129, 54, 67, 41, 147, 9, 165, 15, 17, 217, 57, 205, 117, 227, 241, 73, 228, 54, 179, 26, 225, 19, 166, 13, 48, 195, 48, 247, 117)))
      if _ARG_0_.Config and _ARG_0_.Config.LoadingEffect and _ARG_0_.Config.LoadingEffect.NoDestroy then
        _ARG_0_:ClearLoadingEffectObject()
      elseif _ARG_0_.LoadingEffectObject then
        if _ARG_0_.LoadingEffectObject.End and not _ARG_0_.LoadingEffectObject.bHasClosed then
        elseif _ARG_0_.LoadingEffectObject.SetLifeSpan then
          if _ARG_0_.StartLoadingEffectTime and 1 > U1.GetRealTimeSeconds(_ARG_0_.Owner.Object) - _ARG_0_.StartLoadingEffectTime then
          else
          end
        else
        end
      end
      _ARG_0_.LoadingEffectReason = nil
      if _ARG_0_.Config and _ARG_0_.Config.HideAllUI then
        _ARG_0_:TryRemoveNamedGameTimer((_ENV(44, 115, 132, 55, 107, 43, 152, 25, 138, 61, 29, 215, 40, 237, 98, 253, 192, 67, 253, 7, 168)))
        _ARG_0_.HideAllUITimeoutTimer = _ARG_0_:AddGameTimer(2, false, function()
          print(bWriteLog and string.format((table.concat({
            U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 142, 5, 253, 56, 182, 10, 16, 216, 50, 235, 75, 246, 229, 94, 233, 28, 173, 34, 242, 10),
            U1(1, 121, 148, 114, 98, 46, 144, 41, 130, 5, 24, 239, 4, 214, 126, 228, 241, 69, 229, 22)
          }))))
          EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_EXIT_TEAM_SHOW)
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearLoadingEffectObject"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format((table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 27, 225, 29, 161, 53, 11, 203, 57, 251, 105, 254, 193, 92, 230, 23, 169, 19, 219, 14),
        U1(14, 127, 131, 38)
      }))))
      if _ARG_0_.Config and _ARG_0_.Config.AudioOnPreTeleportLoop and _ARG_0_.AudioOnPreTeleportID then
        _ARG_0_.AudioOnPreTeleportID = nil
      end
      _ARG_0_.LoadingEffectObject = nil
      _ARG_0_:CheckHideAllUI(false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckHideAllUI"] = function(_ARG_0_, _ARG_1_)
    do
      if not (Client and _ARG_0_:IsLocal() and _ARG_0_.Config) or not _ARG_0_.Config.HideAllUI then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 31, 225, 31, 184, 49, 13, 206, 56, 211, 107, 245, 209, 115, 160, 16, 130, 14, 240, 9),
        U1(68, 39, 192, 119, 89)
      }), _ARG_1_))
      if _ARG_1_ then
        EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_ENTER_TEAM_SHOW)
      else
        EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_EXIT_TEAM_SHOW)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Client_NotifyTeleportFailed"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 144, 21, 13, 207, 51, 230, 88, 215, 235, 78, 233, 20, 179, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 1, 149, 37, 175, 12, 16, 150, 109, 206, 120, 232, 240, 67, 254, 5, 159, 17, 226, 25, 176, 13, 54, 207, 60, 225, 104, 247, 164, 7, 160, 87, 185)
      }), _ARG_0_.LoadingEffectReason))
      _ARG_0_:StopPreTeleportSequence(true)
      _ARG_0_:_ReleasePreTeleportLevelHold()
      _ARG_0_:TryDestroyLoadingEffect()
      _ARG_0_.MarkTeleportFailed = true
      _ARG_0_:AddGameTimer(0.1, false, function()
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 144, 21, 13, 207, 51, 230, 88, 215, 235, 78, 233, 20, 179, 51, 241, 0),
          U1(1, 106, 143, 32, 94, 1, 149, 37, 175, 12, 16, 150, 109, 207, 118, 251, 255, 126, 245, 14, 191, 7, 235, 14, 167, 63, 5, 195, 49, 247, 99, 185, 185, 26, 238, 27, 166)
        }))))
        U2.MarkTeleportFailed = nil
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsLocal"] = function(_ARG_0_)
    do
      if not _ARG_0_.Owner then
        return false
      end
      do return (not _ARG_0_.Owner.IsLocallyControlled or not _ARG_0_.Owner:IsLocallyControlled()) and _ARG_0_.Owner.IsLocalViewed and _ARG_0_.Owner:IsLocalViewed() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}).ServerRPC.RPC_Server_ReportPreTeleportSequence = {
  Reliable = true,
  Params = {
    UEnums.EPropertyClass.Int,
    UEnums.EPropertyClass.Int
  }
}
;({
  ServerRPC = {},
  ClientRPC = {},
  ["_PostConstruct"] = function(_ARG_0_)
    do
      __super._PostConstruct(_ARG_0_)
      _ARG_0_.LuaDelegate = U1.LuaDelegate()
      _ARG_0_.bPreTeleportHiddenOnOthers = false
      _ARG_0_.PreTeleportDamageBlocked = false
      _ARG_0_.PreTeleportAllowedDamageTypes = nil
      _ARG_0_.PreTeleportDamageBlockExpireAt = 0
      _ARG_0_.bPreTeleportDamageEventBound = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLifetimeReplicatedProps"] = function(_ARG_0_)
    do
      do return {
        {
          U2(6, 74, 146, 55, 126, 34, 152, 41, 179, 6, 6, 206, 5, 235, 115, 237, 241, 68, 223, 12, 149, 3, 236, 25, 161, 10),
          U1.import((U2(33, 86, 137, 52, 79, 51, 157, 33, 166, 42, 27, 212, 41, 235, 99, 224, 251, 68))).COND_None,
          U1.UEnums.EPropertyClass.Bool
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveBeginPlay"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format((U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 18, 231, 25, 186, 15, 1, 232, 56, 245, 110, 247, 212, 86, 225, 11))))
      U2.__super.ReceiveBeginPlay(_ARG_0_)
      if not _ARG_0_.Owner then
        return
      end
      if not slua.isValid(_ARG_0_.Owner.Object) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckPreload"] = function(_ARG_0_)
    do
      if not _ARG_0_.Owner then
        return
      end
      if not _ARG_0_.Owner:IsLocallyControlled() and not _ARG_0_.Owner:IsLocalViewed() then
        return
      end
      if _ARG_0_.PreloadAssets then
        return
      end
      _ARG_0_.PreloadAssets = {}
      if U2.GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229))) then
        goto lbl_155
        ::lbl_155::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveEndPlay"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.LuaDelegate then
        _ARG_0_.LuaDelegate:Dispose()
      end
      if Client then
        _ARG_0_:StopPreTeleportSequence(true)
        _ARG_0_:_RestorePreTeleportPawnVisibility()
        _ARG_0_:_RestorePreTeleportMovement()
        _ARG_0_:_ReleasePreTeleportLevelHold()
        _ARG_0_:_RestorePreTeleportHiddenOnThisClient()
        _ARG_0_.PreloadAssets = nil
        _ARG_0_:TryRemoveNamedGameTimer((U1(32, 127, 140, 51, 83, 4, 152, 35, 176, 12, 56, 213, 44, 230, 126, 231, 243, 111, 246, 4, 191, 20, 240, 41, 154, 45, 13, 199, 56, 224)))
      else
        _ARG_0_:TryRemoveNamedGameTimer((U1(52, 127, 142, 54, 67, 41, 147, 28, 177, 12, 32, 223, 33, 231, 103, 230, 230, 94, 196, 11, 183, 18, 246)))
        _ARG_0_.PendingPreTeleport = nil
        _ARG_0_:_SetPendingTeleportMovementFrozen(_ARG_0_.Owner and _ARG_0_.Owner.Object, false)
        _ARG_0_:_ReleasePreTeleportServerShowState()
      end
      U2.__super.ReceiveEndPlay(_ARG_0_, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoteTeleportPawnByTable"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_1_.BornPos and #_ARG_1_.BornPos > 0 then
        if 10 < _ARG_2_ then
          print(bWriteLog and table.concat({
            U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 18, 233, 19, 167, 28, 48, 207, 49, 247, 119, 246, 246, 78, 208, 19, 189, 9, 214, 21),
            U1(48, 123, 130, 62, 79, 107, 212, 24, 166, 5, 17, 202, 34, 240, 99, 217, 245, 93, 254, 66, 151, 24, 246, 25, 243, 45, 12, 203, 51, 178, 115, 252, 234, 0, 160)
          }) .. tostring(_ARG_0_.Owner.PlayerKey))
          return
        end
        if not _ARG_0_:RemoteTeleportPawn(_ARG_1_.BornPos[math.random(1, #_ARG_1_.BornPos)].Location, _ARG_1_.BornPos[math.random(1, #_ARG_1_.BornPos)].Roatation, _ARG_3_, _ARG_4_) then
          _ARG_2_ = _ARG_2_ + 1
        end
      end
      do return end
      _ARG_1_ = U1.tostring
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoteTeleportPawn"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not Client and _ARG_0_.Owner then
        if Game:TeleportPawn(_ARG_0_.Owner.Object, _ARG_1_, _ARG_2_, false, true, false, false, _ARG_3_, _ARG_4_) then
          if _ARG_3_ == import((U1(33, 78, 133, 62, 79, 55, 155, 62, 183, 57, 21, 205, 35, 214, 110, 249, 241))).ParachuteTeleport then
          elseif _ARG_3_ == import((U1(33, 78, 133, 62, 79, 55, 155, 62, 183, 57, 21, 205, 35, 214, 110, 249, 241))).RemoteTeleport then
          end
          if _ARG_4_ and _ARG_0_:GetConfig(_ARG_4_) and _ARG_0_:GetConfig(_ARG_4_).GameTLogId and SubsystemMgr:Get((U1(32, 73, 163, 61, 71, 42, 155, 34, 151, 37, 27, 221, 30, 247, 117, 250, 237, 89, 228, 7, 183))) then
          end
        end
        return (Game:TeleportPawn(_ARG_0_.Owner.Object, _ARG_1_, _ARG_2_, false, true, false, false, _ARG_3_, _ARG_4_))
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1[252]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInTeleportState"] = function(_ARG_0_)
    do
      if _ARG_0_.PreTeleportActiveSeqConfig ~= nil or _ARG_0_.PreTeleportSeqActor ~= nil or _ARG_0_.LoadingEffectReason ~= nil or _ARG_0_.PreTeleportLevelHeld == true then
      end
      do return _ARG_0_.PreTeleportActiveSeqConfig ~= nil or _ARG_0_.PreTeleportSeqActor ~= nil or _ARG_0_.LoadingEffectReason ~= nil or _ARG_0_.PreTeleportLevelHeld == true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPawnAttached"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return false
      end
      if not slua.isValid((_ARG_0_.Owner and _ARG_0_.Owner.Object).RootComponent) then
        return false
      end
      do return slua.isValid((_ARG_0_.Owner and _ARG_0_.Owner.Object).RootComponent:GetAttachParent()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPawnOnVehicle"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return false
      end
      do return (_ARG_0_.Owner and _ARG_0_.Owner.Object):HasState(U1.InVehicle) or (_ARG_0_.Owner and _ARG_0_.Owner.Object):HasState(U1.DriveVehicle) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoteTeleport"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_0_:IsPawnOnVehicle() then
        print(bWriteLog and string.format(table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 18, 233, 19, 167, 28, 48, 207, 49, 247, 119, 246, 246, 78, 160, 0, 175, 1, 225, 31),
          U1(1, 126, 204, 114, 90, 38, 131, 34, 227, 6, 26, 154, 59, 231, 127, 224, 247, 70, 245, 78, 250, 39, 232, 29, 170, 28, 22, 225, 56, 235, 39, 164, 164, 31, 243, 94, 234, 36, 251, 2),
          U1(2, 115, 135, 27, 78, 103, 201, 108, 230, 26)
        }), tostring(_ARG_0_.Owner.PlayerKey), tostring(_ARG_3_)))
        return false
      end
      if _ARG_0_:IsPawnAttached() then
        return false
      end
      if _ARG_0_:_TryDeferTeleportForPreSequence(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport, _ARG_4_) then
        return true, (_ARG_0_:_TryCancelCarryBackForTeleport(_ARG_3_))
      end
      if not _ARG_0_:InternalTeleport(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport) then
        return (_ARG_0_:InternalTeleport(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport))
      end
      do return _ARG_0_:InternalTeleport(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport), (_ARG_0_:_TryCancelCarryBackForTeleport(_ARG_3_)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_TryCancelCarryBackForTeleport"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return nil
      end
      if not _ARG_0_:GetConfig(_ARG_1_) or _ARG_0_:GetConfig(_ARG_1_).CancelCarryBackOnTeleport ~= true then
        return nil
      end
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) or not (_ARG_0_.Owner and _ARG_0_.Owner.Object).IsInCarryBackState then
        return nil
      end
      if (_ARG_0_.Owner and _ARG_0_.Owner.Object):IsInCarryBackState() then
      elseif (_ARG_0_.Owner and _ARG_0_.Owner.Object):IsInBeCarriedBackState() then
        if slua.isValid(((_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCarryBackCharacter())) then
        end
      else
        return nil
      end
      do return slua.isValid(((_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCarryBackCharacter())) and (_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCarryBackCharacter() or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_TryDeferTeleportForPreSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if Client then
        return false
      end
      if type(_ARG_0_:GetConfig(_ARG_3_) and _ARG_0_:GetConfig(_ARG_3_).SequenceOnPreTeleport) ~= U1(16, 123, 130, 62, 79) then
        return false
      end
      if not slua.isValid(_ARG_0_.Owner.Object) or _ARG_0_.Owner.bEnsure or not Game:IsPlayer(_ARG_0_.Owner.Object) then
        return false
      end
      if not slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
        return false
      end
      if _ARG_0_.PendingPreTeleport then
        return true
      end
      _ARG_0_.PendingPreTeleportSerial = (_ARG_0_.PendingPreTeleportSerial or 0) + 1
      _ARG_0_.PendingPreTeleport = {
        Location = _ARG_1_,
        Rotation = _ARG_2_,
        ConfigId = _ARG_3_,
        Type = _ARG_4_,
        Serial = _ARG_0_.PendingPreTeleportSerial,
        bStarted = false
      }
      _ARG_0_.PendingPreTeleportTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_3_) and _ARG_0_:GetConfig(_ARG_3_).SequenceOnPreTeleport, (U1(55, 127, 146, 36, 79, 53, 163, 45, 170, 29, 32, 211, 32, 231, 120, 252, 224))), false, function()
        PendingPreTeleportTimer = nil
        _ENV:_ExecutePendingPreTeleport(U1, (U2(48, 115, 141, 55, 69, 50, 128)))
        return
      end)
      if (_ARG_0_:GetConfig(_ARG_3_) and _ARG_0_:GetConfig(_ARG_3_).SequenceOnPreTeleport).DisableMovementDuringSequence == true then
      end
      if _ARG_5_ then
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetPreTeleportSeqConfigValue"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return type(_ARG_1_) == U1(16, 123, 130, 62, 79) and tonumber(_ARG_1_[_ARG_2_]) or nil or tonumber(U2[_ARG_2_]) or 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnClientPreTeleportSeqStarted"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.PendingPreTeleport or _ARG_0_.PendingPreTeleport.Serial ~= _ARG_1_ then
        return
      end
      if _ARG_0_.PendingPreTeleport.bStarted then
        return
      end
      _ARG_0_.PendingPreTeleport.bStarted = true
      if type(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport) == U1(16, 123, 130, 62, 79) and (_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport).HidePawnOnOtherClientsDuringSequence == true then
        _ARG_0_.bPreTeleportHiddenOnOthers = true
      end
      if 0 >= _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) then
      end
      if 0 >= _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) - _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(48, 127, 140, 55, 90, 40, 134, 56, 130, 1, 17, 219, 41, 214, 126, 228, 241))) then
        return
      end
      _ARG_0_.PendingPreTeleportTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) - _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(48, 127, 140, 55, 90, 40, 134, 56, 130, 1, 17, 219, 41, 214, 126, 228, 241))), false, function()
        PendingPreTeleportTimer = nil
        _ENV:_ExecutePendingPreTeleport(U1, (U2(37, 114, 133, 51, 78, 8, 146, 31, 166, 24, 1, 223, 35, 225, 114, 204, 250, 78)))
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[84]
    end
  end,
  ["_OnClientPreTeleportSeqSkipped"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.PendingPreTeleport or _ARG_0_.PendingPreTeleport.Serial ~= _ARG_1_ then
        return
      end
      if _ARG_0_.PendingPreTeleport.bStarted then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ExecutePendingPreTeleport"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.PendingPreTeleport or _ARG_0_.PendingPreTeleport.Serial ~= _ARG_1_ then
        return
      end
      _ARG_0_.PendingPreTeleport = nil
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if _ARG_0_.Owner.bDead == true then
        return
      end
      if not _ARG_0_:InternalTeleport(_ARG_0_.PendingPreTeleport.Location, _ARG_0_.PendingPreTeleport.Rotation, _ARG_0_.PendingPreTeleport.ConfigId, _ARG_0_.PendingPreTeleport.Type) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CancelPendingPreTeleport"] = function(_ARG_0_, _ARG_1_)
    do
      if Client or not _ARG_0_.PendingPreTeleport then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 52, 229, 18, 176, 28, 8, 250, 56, 252, 99, 240, 234, 93, 208, 0, 175, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 103, 164, 32, 162, 16, 17, 200, 6, 231, 110, 169, 169, 10, 181, 17, 246, 87, 215, 25, 161, 16, 5, 198, 125, 175, 39, 188, 247, 22, 160, 32, 175, 6, 231, 3),
        U1(10, 58, 221, 114, 15, 52)
      }), tostring(_ARG_0_.Owner and _ARG_0_.Owner.PlayerKey), tostring(_ARG_0_.PendingPreTeleport.Serial), tostring(_ARG_1_)))
      _ARG_0_.PendingPreTeleport = nil
      _ARG_0_:TryRemoveNamedGameTimer((U1(52, 127, 142, 54, 67, 41, 147, 28, 177, 12, 32, 223, 33, 231, 103, 230, 230, 94, 196, 11, 183, 18, 246)))
      _ARG_0_:_SetPendingTeleportMovementFrozen(_ARG_0_.Owner and _ARG_0_.Owner.Object, false)
      _ARG_0_:_ReleasePreTeleportServerShowState()
      _ARG_0_:RPC_Client_NotifyTeleportFailed()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnOwnerDeath"] = function(_ARG_0_)
    do
      if not Client then
        if not _ARG_0_.PendingPreTeleport then
          return
        end
        if type(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport) == U1(16, 123, 130, 62, 79) and (_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport).CancelTeleportOnDeath == true then
        end
        return
      end
      if type(_ARG_0_.PreTeleportActiveSeqConfig) ~= U1(16, 123, 130, 62, 79) or _ARG_0_.PreTeleportActiveSeqConfig.CancelTeleportOnDeath ~= true then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPendingTeleportMovementFrozen"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      if _ARG_2_ then
        if not slua.isValid(_ARG_1_ and _ARG_1_.STCharacterMovement) or _ARG_0_.PendingTeleportMovementMode ~= nil then
          return
        end
        _ARG_0_.PendingTeleportMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).MovementMode
        _ARG_0_.PendingTeleportCustomMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).CustomMovementMode
        _ARG_0_.PendingTeleportMovementActive = (_ARG_1_ and _ARG_1_.STCharacterMovement):IsActive()
        _ARG_0_.PendingTeleportMovementTickEnabled = (_ARG_1_ and _ARG_1_.STCharacterMovement):IsComponentTickEnabled()
        if _ARG_0_.PendingTeleportMovementMode == U1 then
          _ARG_0_.PendingTeleportMovementMode = U2
          _ARG_0_.PendingTeleportCustomMovementMode = 0
          _ARG_0_.PendingTeleportMovementActive = true
          _ARG_0_.PendingTeleportMovementTickEnabled = true
        end
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          _ARG_0_.PendingTeleportMoveableSaved = (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).bMoveable
        end
        _ARG_0_.PendingTeleportMovementGuardTimer = _ARG_0_:AddGameTimer(0.1, true, function()
          if PendingTeleportMovementMode == nil then
            return
          end
          if not U1.slua.isValid(U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil) then
            return
          end
          if (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil):IsActive() or (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil):IsComponentTickEnabled() or (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil).MovementMode ~= U2 then
          end
          return
        end)
        return
      end
      if _ARG_0_.PendingTeleportMovementMode == nil then
        return
      end
      _ARG_0_.PendingTeleportMovementMode = nil
      _ARG_0_.PendingTeleportCustomMovementMode = nil
      _ARG_0_.PendingTeleportMovementActive = nil
      _ARG_0_.PendingTeleportMovementTickEnabled = nil
      if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) and _ARG_0_.PendingTeleportMoveableSaved ~= nil then
        _ARG_0_.PendingTeleportMoveableSaved = nil
      end
      if slua.isValid(_ARG_1_ and _ARG_1_.STCharacterMovement) then
        if _ARG_1_.bDead ~= true then
        end
        if _ARG_0_.PendingTeleportMovementActive == false then
        end
      end
      do return end
      _ARG_0_ = _ENV[87]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ResolvePreTeleportForbiddenStates"] = function(_ARG_0_, _ARG_1_)
    do
      if (type(_ARG_1_) == U1(16, 123, 130, 62, 79) and _ARG_1_.ForbiddenPawnStatesDuringSequence or nil) == true then
      end
      if type(U2) ~= U1(16, 123, 130, 62, 79) then
        return nil
      end
      goto lbl_158
      if type(62) == U1(23, 110, 146, 59, 68, 32) then
      end
      if U3[62] ~= nil and U3[62] ~= U3.Dying and U3[62] ~= U3.Dead then
      else
      end
      ::lbl_158::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportPawnStatesDisabled"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ then
        if _ARG_0_.PreTeleportDisabledPawnStates or not slua.isValid(_ARG_1_) then
          return
        end
        if not _ARG_0_:_ResolvePreTeleportForbiddenStates(_ARG_2_) or #_ARG_0_:_ResolvePreTeleportForbiddenStates(_ARG_2_) == 0 then
          return
        end
        goto lbl_41
        ::lbl_41::
        _ARG_0_ = _ARG_0_
        _ARG_0_.PreTeleportDisabledPawnStates, _ARG_0_ = {}, _ARG_0_
        return
      end
      _ARG_0_.PreTeleportDisabledPawnStates = nil
      if not _ARG_0_.PreTeleportDisabledPawnStates or not slua.isValid(_ARG_1_) then
        return
      end
      goto lbl_154
      ::lbl_154::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CancelPreTeleportHoldGrenade"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) or not _ARG_1_:HasState(U1.HoldGrenade) then
        return
      end
      print(bWriteLog and table.concat({
        U2(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 52, 229, 18, 176, 28, 8, 250, 47, 247, 83, 252, 232, 95, 240, 29, 184, 19, 220, 3),
        U2(8, 126, 167, 32, 79, 41, 149, 40, 166)
      }))
      if Client then
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          ;(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).TouchEndTriggerSkillID = -1
        end
      end
      _ARG_1_:TriggerCustomEvent(U3.PlayerRequestCancel, -1)
      if Client then
        EventSystem:postEvent(EVENTTYPE_INGAME_SHOOTINGUI_PANEL, EVENTID_ON_THROW_CANCEL_BUTTON_CLICK)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportGrenadePredictLine"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if not _ARG_0_.Owner.IsLocallyControlled or not _ARG_0_.Owner:IsLocallyControlled() then
        return
      end
      if not slua.isValid(((_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCurrentWeapon())) or not (_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCurrentWeapon().EnableWeaponPredictLine then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PreparePreTeleportLocomotion"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_.DisableMovementDuringSequence == true and _ARG_2_.StopAllSkillsOnSequence == true and slua.isValid((_ARG_1_:GetPlayerControllerSafety())) and (_ARG_1_:GetPlayerControllerSafety():GetCurrentStateType() == import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteJump or _ARG_1_:GetPlayerControllerSafety():GetCurrentStateType() == import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteOpen) then
        if not Client and _ARG_1_:GetPlayerControllerSafety():GetCurrentStateType() == import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteOpen and _ARG_1_:GetPlayerControllerSafety().GetStateMachineCompent and slua.isValid((_ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent())) and _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState and _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill == true then
          _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill = false
        end
        if Client then
        else
        end
        if slua.isValid(_ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState) and _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill == true then
          _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill = true
        end
      end
      if _ARG_2_.StopAllSkillsOnSequence == true then
        if Client then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ApplyPreTeleportServerShowState"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not (not Client and slua.isValid(_ARG_1_)) or type(_ARG_2_) ~= U1(16, 123, 130, 62, 79) then
        return
      end
      _ARG_0_:_ReleasePreTeleportServerShowState()
      _ARG_0_:_PreparePreTeleportLocomotion(_ARG_1_, _ARG_2_)
      if _ARG_2_.ExitScopeOnSequence == true then
        _ARG_1_:ScopeInterrupt(U2.Normal)
      end
      _ARG_0_:_SetPreTeleportPawnStatesDisabled(_ARG_1_, _ARG_2_, true)
      _ARG_0_:_AddPreTeleportDamageBlock(_ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ResolvePreTeleportAllowedDamageTypes"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_.AllowedDamageTypesDuringSequence) ~= U1(16, 123, 130, 62, 79) then
      end
      goto lbl_193
      if type(62) == U1(10, 111, 141, 48, 79, 53) and 62 or type(62) == U1(23, 110, 146, 59, 68, 32) and import((U1(33, 94, 129, 63, 75, 32, 145, 24, 186, 25, 17)))[62] or nil then
      else
      end
      ::lbl_193::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {
        [type(62) == U1(10, 111, 141, 48, 79, 53) and 62 or type(62) == U1(23, 110, 146, 59, 68, 32) and import((U1(33, 94, 129, 63, 75, 32, 145, 24, 186, 25, 17)))[62] or nil] = true
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetPreTeleportDamageBlockMaxDuration"] = function(_ARG_0_, _ARG_1_)
    do
      if (U1.type(_ARG_1_) == _ENV(16, 123, 130, 62, 79) and U1.tonumber(_ARG_1_.DamageBlockMaxDuration) or nil) and 0 < (U1.type(_ARG_1_) == _ENV(16, 123, 130, 62, 79) and U1.tonumber(_ARG_1_.DamageBlockMaxDuration) or nil) then
        return U1.type(_ARG_1_) == _ENV(16, 123, 130, 62, 79) and U1.tonumber(_ARG_1_.DamageBlockMaxDuration) or nil
      end
      do return _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(55, 127, 146, 36, 79, 53, 163, 45, 170, 29, 32, 211, 32, 231, 120, 252, 224))) + _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) + _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 9, 227, 122, 232, 243, 79, 210, 14, 181, 20, 239, 52, 188, 21, 0, 254, 52, 255, 98))) + 10 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_AddPreTeleportDamageBlock"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) or _ARG_1_.BlockDamageDuringSequence ~= true then
        return
      end
      _ARG_0_:_RemovePreTeleportDamageBlock()
      _ARG_0_.PreTeleportAllowedDamageTypes = _ARG_0_:_ResolvePreTeleportAllowedDamageTypes(_ARG_1_)
      _ARG_0_.PreTeleportDamageBlocked = true
      _ARG_0_.PreTeleportDamageBlockExpireAt = (slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) and U2.GetRealTimeSeconds(_ARG_0_.Owner and _ARG_0_.Owner.Object) or 0) + _ARG_0_:_GetPreTeleportDamageBlockMaxDuration(_ARG_1_)
      _ARG_0_.PreTeleportDamageBlockSafetyTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportDamageBlockMaxDuration(_ARG_1_), false, function()
        PreTeleportDamageBlockSafetyTimer = nil
        if PreTeleportDamageBlocked then
          U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
            U2(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 54, 224, 24, 131, 11, 1, 254, 56, 254, 98, 233, 235, 72, 244, 54, 171, 10, 245, 11),
            U2(1, 88, 140, 61, 73, 44, 212, 63, 162, 15, 17, 206, 52, 162, 99, 224, 249, 79, 255, 23, 174, 87, 161, 15, 243, 10, 72, 138, 59, 253, 117, 250, 225, 26, 242, 23, 166, 2, 245, 31),
            U2(1, 54, 192, 2, 70, 38, 141, 41, 177, 34, 17, 195, 109, 191, 55, 172, 231)
          }), U1.tostring(U3), U1.tostring(Owner and Owner.PlayerKey)))
          _ENV:_RemovePreTeleportDamageBlock()
        end
        return
      end)
      if not _ARG_0_.bPreTeleportDamageEventBound then
        _ARG_0_.bPreTeleportDamageEventBound = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RemovePreTeleportDamageBlock"] = function(_ARG_0_)
    do
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 254, 44, 239, 118, 238, 241, 104, 252, 13, 185, 28, 208, 21, 190, 28, 22)))
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 254, 44, 239, 118, 238, 241, 104, 252, 13, 185, 28, 215, 29, 181, 28, 16, 211, 9, 251, 106, 252, 246)))
      _ARG_0_.PreTeleportDamageBlockSafetyTimer = nil
      _ARG_0_.PreTeleportDamageBlockExpireAt = 0
      if not _ARG_0_.PreTeleportDamageBlocked then
        return
      end
      _ARG_0_.PreTeleportDamageBlocked = false
      _ARG_0_.PreTeleportAllowedDamageTypes = nil
      if _ARG_0_.bPreTeleportDamageEventBound then
        _ARG_0_.bPreTeleportDamageEventBound = false
        _ARG_0_:RemoveCommonEvent(U1.EVENTTYPE_INGAME_NORMAL, U1.EVENTID_PRE_TAKE_DAMAGE)
      end
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        _ENV(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 37, 225, 17, 188, 15, 1, 250, 47, 247, 83, 252, 232, 95, 240, 29, 184, 19, 208, 13),
        _ENV(9, 123, 135, 55, 104, 43, 155, 47, 168, 73, 36, 214, 44, 251, 114, 251, 223, 79, 233, 66, 231, 87, 161, 15)
      }), U1.tostring(_ARG_0_.Owner and _ARG_0_.Owner.PlayerKey)))
      return
    end
  end,
  ["HandlePreTeleportPreTakeDamage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not (not Client and _ARG_0_.PreTeleportDamageBlocked) or not slua.isValid(_ARG_3_) then
        return
      end
      if not slua.isValid(_ARG_3_.Target) then
        return
      end
      if not (_ARG_3_.Target.PlayerKey and _ARG_0_.Owner) or _ARG_3_.Target.PlayerKey ~= _ARG_0_.Owner.PlayerKey then
        return
      end
      if slua.isValid(_ARG_0_.Owner.Object) and _ARG_0_.PreTeleportDamageBlockExpireAt > 0 and U1.GetRealTimeSeconds(_ARG_0_.Owner.Object) > _ARG_0_.PreTeleportDamageBlockExpireAt then
        return
      end
      if _ARG_0_.PreTeleportAllowedDamageTypes and _ARG_0_.PreTeleportAllowedDamageTypes[_ARG_3_.DamageType] then
        return
      end
      _ARG_3_.Damage = 0
      do return end
      _ARG_1_ = _ENV[12]
    end
  end,
  ["_ScheduleReleasePreTeleportServerShowState"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if _ARG_0_.PreTeleportDamageBlocked then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 9, 227, 122, 232, 243, 79, 210, 14, 181, 20, 239, 52, 188, 21, 0, 254, 52, 255, 98))) then
          _ARG_0_.PreTeleportDamageBlockTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 9, 227, 122, 232, 243, 79, 210, 14, 181, 20, 239, 52, 188, 21, 0, 254, 52, 255, 98))), false, function()
            PreTeleportDamageBlockTimer = nil
            _ENV:_RemovePreTeleportDamageBlock()
            return
          end)
        else
        end
      end
      if _ARG_0_.bPreTeleportHiddenOnOthers then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(55, 114, 143, 37, 122, 38, 131, 34, 140, 7, 59, 206, 37, 231, 101, 250, 208, 79, 252, 3, 163))) then
          _ARG_0_.PreTeleportShowOnOthersTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(55, 114, 143, 37, 122, 38, 131, 34, 140, 7, 59, 206, 37, 231, 101, 250, 208, 79, 252, 3, 163))), false, function()
            PreTeleportShowOnOthersTimer = nil
            bPreTeleportHiddenOnOthers = false
            return
          end)
        else
          _ARG_0_.bPreTeleportHiddenOnOthers = false
        end
      end
      if _ARG_0_.PreTeleportDisabledPawnStates then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 30, 246, 118, 253, 241, 98, 255, 14, 190, 35, 237, 17, 182))) then
          _ARG_0_.PreTeleportStateRestoreTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 30, 246, 118, 253, 241, 98, 255, 14, 190, 35, 237, 17, 182))), false, function()
            PreTeleportStateRestoreTimer = nil
            _ENV:_SetPreTeleportPawnStatesDisabled(Owner and Owner.Object, nil, false)
            return
          end)
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ReleasePreTeleportServerShowState"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      _ARG_0_:TryRemoveNamedGameTimer((U1(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 233, 37, 237, 96, 198, 250, 101, 228, 10, 191, 5, 247, 40, 186, 20, 1, 216)))
      _ARG_0_:TryRemoveNamedGameTimer((U1(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 233, 57, 227, 99, 236, 198, 79, 227, 22, 181, 5, 225, 40, 186, 20, 1, 216)))
      if _ARG_0_.bPreTeleportHiddenOnOthers then
        _ARG_0_.bPreTeleportHiddenOnOthers = false
      end
      _ARG_0_:_SetPreTeleportPawnStatesDisabled(_ARG_0_.Owner and _ARG_0_.Owner.Object, nil, false)
      _ARG_0_:_RemovePreTeleportDamageBlock()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_bPreTeleportHiddenOnOthers"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if _ARG_0_.bPreTeleportHiddenOnOthers == true and not _ARG_0_:IsLocal() then
        if not _ARG_0_.PreTeleportHiddenOnThisClient then
          _ARG_0_.PreTeleportHiddenOnThisClient = true
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportHiddenOnThisClient"] = function(_ARG_0_)
    do
      if not _ARG_0_.PreTeleportHiddenOnThisClient then
        return
      end
      _ARG_0_.PreTeleportHiddenOnThisClient = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Server_ReportPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 128, 28, 22, 220, 56, 224, 88, 203, 225, 74, 239, 0, 190, 55, 230, 9),
        U1(48, 127, 140, 55, 90, 40, 134, 56, 144, 12, 5, 207, 40, 236, 116, 236, 180, 122, 252, 3, 163, 18, 246, 55, 182, 0, 68, 151, 125, 183, 116, 181, 164, 104, 229, 2, 165, 21, 224, 56),
        U1(29, 106, 133, 114, 23, 103, 209, 63, 239, 73, 39, 223, 63, 235, 118, 229, 180, 23, 176, 71, 169)
      }), tostring(_ARG_0_.Owner.PlayerKey), tostring(_ARG_1_), tostring(_ARG_2_)))
      if _ARG_1_ == U2.Started then
        _ARG_0_:_OnClientPreTeleportSeqStarted(_ARG_2_)
      elseif _ARG_1_ == U2.Skipped then
        _ARG_0_:_OnClientPreTeleportSeqSkipped(_ARG_2_)
      else
        print(bWriteLog and string.format(table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 128, 28, 22, 220, 56, 224, 88, 203, 225, 74, 239, 0, 190, 55, 230, 9),
          U1(48, 127, 140, 55, 90, 40, 134, 56, 144, 12, 5, 207, 40, 236, 116, 236, 180, 88, 245, 8, 191, 20, 240, 25, 183, 85, 68, 223, 51, 249, 105, 246, 243, 84, 160, 32, 175, 23, 251, 30),
          U1(16, 78, 153, 34, 79, 103, 201, 108, 230, 26)
        }), tostring(_ARG_1_)))
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Client_PlayPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_, _ARG_9_, _ARG_10_, _ARG_11_, _ARG_12_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 144, 21, 13, 207, 51, 230, 88, 201, 232, 91, 249, 34, 184, 2, 192, 9),
        U1(8, 127, 144, 61, 88, 51, 167, 41, 178, 28, 17, 212, 46, 231, 55, 202, 251, 68, 246, 11, 189, 62, 224, 92, 238, 89, 65, 217, 113, 178, 84, 252, 246, 83, 225, 30, 234, 90, 180, 73),
        U1(23, 54, 192, 26, 75, 52, 164, 32, 162, 16, 32, 200, 44, 236, 100, 239, 251, 88, 253, 66, 231, 87, 161, 15, 255, 89, 48, 203, 47, 245, 98, 237, 200, 85, 227, 82, 247, 71, 188, 73),
        U1(23, 54, 192, 119, 89, 107, 212, 105, 176, 64)
      }), tostring(_ARG_1_), tostring(_ARG_2_), tostring(_ARG_3_), tostring(_ARG_10_), tostring(_ARG_11_), tostring(_ARG_12_)))
      if _ARG_3_ == 1 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShouldSkipPreTeleportSequence"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) or _ARG_1_.SkipOnLowDevice ~= true then
        return false
      end
      do return require((U1(7, 117, 141, 63, 69, 41, 218, 8, 166, 31, 29, 217, 40, 215, 99, 224, 248, 89))).GetDeviceLevel() ~= nil and require((U1(7, 117, 141, 63, 69, 41, 218, 8, 166, 31, 29, 217, 40, 215, 99, 224, 248, 89))).GetDeviceLevel() <= require((U1(7, 117, 141, 63, 69, 41, 218, 8, 166, 31, 29, 217, 40, 215, 99, 224, 248, 89))).ENum_DeviceLevel.Low end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InternalTeleport"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      print(bWriteLog and table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 147, 25, 240, 25, 161, 23, 5, 198, 9, 247, 107, 252, 244, 85, 242, 6, 234, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 4, 155, 34, 165, 0, 19, 243, 41, 162)
      }) .. tostring(_ARG_3_))
      if not _ARG_0_:CheckPawn(_ARG_0_.Owner.Object) then
        return false
      end
      if _ARG_0_:IsPawnOnVehicle() then
        return false
      end
      if _ARG_0_:IterateTargetLocation(_ARG_1_, function(_ARG_0_)
        do
          if _ENV and U1:LineTraceHit(U2, _ARG_0_) then
            return false, U3.LineTrace
          end
          if U4.Game:TeleportPawn(U5, _ARG_0_, U6, false, true, false, false, U7, U8) then
            return true
          else
            return false, U3.TeleportPawn
          end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end) then
        _ARG_0_.LocationBeforeTeleport = _ARG_0_.Owner:K2_GetActorLocation()
        if _ARG_0_.Config and _ARG_0_.Config.ParachuteTeleport == true then
        else
        end
        if _ARG_0_.Owner.Object.PlayerUID then
        end
      else
      end
      do return (_ARG_0_:IterateTargetLocation(_ARG_1_, function(_ARG_0_)
        do
          if _ENV and U1:LineTraceHit(U2, _ARG_0_) then
            return false, U3.LineTrace
          end
          if U4.Game:TeleportPawn(U5, _ARG_0_, U6, false, true, false, false, U7, U8) then
            return true
          else
            return false, U3.TeleportPawn
          end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckPawn"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return false
      end
      if not slua.isValid(_ARG_1_) then
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 31, 225, 31, 184, 41, 5, 221, 51, 178, 114, 201, 229, 77, 238, 82, 163, 20, 180, 2),
          U1(11, 110, 192, 36, 75, 43, 157, 40)
        }))))
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLineTraceEnabled"] = function(_ARG_0_, _ARG_1_)
    do
      if not (_ARG_1_ and _ARG_1_.TestLocation) or _ARG_1_.TestLocation.LineTraceEnabled == nil then
        return true
      end
      do return _ARG_1_.TestLocation.LineTraceEnabled end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IterateTargetLocation"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_(_ARG_1_) then
        return true
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_2_(_ARG_1_ + FVector(U2[U1(10, 58, 172, 61, 73, 38, 128, 37, 172, 7, 84, 135, 109, 167, 100, 165, 180, 108, 241, 11, 182, 18, 224, 46, 182, 24, 23, 197, 51, 178, 58, 185, 161, 73)].X * _ARG_1_:ToString(), U2[U1(10, 58, 172, 61, 73, 38, 128, 37, 172, 7, 84, 135, 109, 167, 100, 165, 180, 108, 241, 11, 182, 18, 224, 46, 182, 24, 23, 197, 51, 178, 58, 185, 161, 73)].Y * _ARG_1_:ToString(), U1(10, 58, 172, 61, 73, 38, 128, 37, 172, 7, 84, 135, 109, 167, 100, 165, 180, 108, 241, 11, 182, 18, 224, 46, 182, 24, 23, 197, 51, 178, 58, 185, 161, 73)) * (_ARG_0_.Config and _ARG_0_.Config.TestLocation and _ARG_0_.Config.TestLocation.OffsetValue or 100)) then
        return true
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LineTraceHit"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.TraceActorsToIgnore then
        _ARG_0_.TraceActorsToIgnore = slua.Array(UEnums.EPropertyClass.Object, (import((U1(75, 73, 131, 32, 67, 55, 128, 99, 134, 7, 19, 211, 35, 231, 57, 200, 247, 94, 255, 16)))))
      end
      do return import((U1(47, 115, 147, 63, 79, 51, 167, 53, 176, 29, 17, 215, 1, 235, 117, 251, 245, 88, 233))).LineTraceSingle(_ARG_0_.Owner.Object, _ARG_1_, _ARG_2_, 0, true, _ARG_0_.TraceActorsToIgnore, import((U1(33, 94, 146, 51, 93, 3, 145, 46, 182, 14, 32, 200, 44, 225, 114))).None, import((U1(75, 73, 131, 32, 67, 55, 128, 99, 134, 7, 19, 211, 35, 231, 57, 193, 253, 94, 194, 7, 169, 2, 232, 8)))(), true, FLinearColor.Red, FLinearColor.Green, 1) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ForceHolsterBeforeParachuteJump"] = function(_ARG_0_, _ARG_1_)
    do
      if Client or not slua.isValid(_ARG_1_) then
        return
      end
      if not slua.isValid(_ARG_1_.GetWeaponManager and _ARG_1_:GetWeaponManager()) then
        return
      end
      if (_ARG_1_.GetWeaponManager and _ARG_1_:GetWeaponManager()).bIsSwitching == true then
      end
      if (_ARG_1_.GetWeaponManager and _ARG_1_:GetWeaponManager()):GetCurrentUsingPropSlot() ~= import((U1(33, 73, 149, 32, 92, 46, 130, 41, 148, 12, 21, 202, 34, 236, 71, 251, 251, 90, 195, 14, 181, 3))).SWPS_None then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ParachuteJump"] = function(_ARG_0_)
    do
      if _ARG_0_.Owner then
        print(bWriteLog and U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 138, 22, 246, 29, 176, 17, 17, 222, 56, 216, 114, 244, 244, 26, 211, 6, 171, 21, 224))
        _ARG_0_:_ForceHolsterBeforeParachuteJump(_ARG_0_.Owner.Object)
        if slua.isValid((_ARG_0_.Owner:GetControllerSafety())) then
          if not _ARG_0_.Owner:GetEnsure() then
            if _ARG_0_.Owner:GetControllerSafety():GetCurrentStateType() ~= import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteJump and _ARG_0_.Owner:GetControllerSafety():GetCurrentStateType() ~= import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteOpen then
              if _ARG_0_.Config and _ARG_0_.Config.OpenParachuteAfterTeleport == true then
              else
              end
            end
          else
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreTeleport"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      _ARG_0_.Config = _ARG_0_:GetConfig(_ARG_1_)
      if _ARG_0_.Config and _ARG_0_.Config.StopAllSkillsOnTeleport == true then
      end
      if _ARG_0_.Owner.PoseState == U3.Crouch or _ARG_0_.Owner.PoseState == U3.Prone then
      end
      if _ARG_0_.Owner.PoseState == U3.GunADS then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetConfig"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229))) then
        return
      end
      if not GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_] then
        return
      end
      if GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_].HideAllUI == nil then
        GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_].HideAllUI = true
      end
      do return GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostTeleport"] = function(_ARG_0_)
    do
      _ARG_0_:CheckTLog()
      _ARG_0_:StartWaitingClientLoading()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckTLog"] = function(_ARG_0_)
    do
      if not _ARG_0_.Config then
        return
      end
      if not SubsystemMgr:Get((U1(32, 73, 163, 61, 71, 42, 155, 34, 151, 37, 27, 221, 30, 247, 117, 250, 237, 89, 228, 7, 183))) then
        return
      end
      if _ARG_0_.Config.GameTLogId and _ARG_0_.Config.GameTLogId ~= 0 then
      end
      if _ARG_0_.Config.PlayerTLogId and _ARG_0_.Config.PlayerTLogId ~= 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientTeleportStartCallback"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not (_ARG_1_ and _ARG_0_.Owner) or not Client then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientTeleportCallback"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not (_ARG_1_ and _ARG_0_.Owner) or not Client then
        return
      end
      _ARG_0_.Config = _ARG_0_:GetConfig(_ARG_5_)
      if not _ARG_0_.Config then
        return
      end
      if _ARG_0_.PreTeleportPawnDrivenByShow == true and _ARG_0_.PreTeleportShowFinished ~= true then
      else
      end
      _ARG_0_.PreTeleportClientLanded = true
      if _ARG_0_:CheckLoading(_ARG_2_, _ARG_0_.Config) then
      else
      end
      if _ARG_0_.Config and _ARG_0_.Config.AudioOnPreTeleport then
        if _ARG_0_.Config.AudioOnPreTeleport2D then
          if _ARG_0_:IsAutonomousProxy() then
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = _ENV[245]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetPreTeleportSequencePaths"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) then
        return nil, nil, nil
      end
      if not _ARG_1_.LevelSequenceActorPath or _ARG_1_.LevelSequenceActorPath == U1() then
      end
      if _ARG_1_.BindPlayerPawnName and _ARG_1_.BindPlayerPawnName ~= U1() and _ARG_1_.BindLocalPlayerPawn ~= true and (not _ARG_1_.ShowPawnActorPath or _ARG_1_.ShowPawnActorPath == U1()) then
      end
      do return _ARG_1_.LevelSequencePath, U2.LevelSequenceActorPath, U2.ShowPawnActorPath end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not Client or not _ARG_0_:IsLocal() then
        return false
      end
      if not (_ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) and _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) ~= U1() and _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_)) or _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) == U1() then
        return false
      end
      if _ARG_1_.BindPlayerPawnName and _ARG_1_.BindPlayerPawnName ~= U1() and _ARG_1_.BindLocalPlayerPawn ~= true and (not _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) or _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) == U1()) then
        return false
      end
      _ARG_0_.PreTeleportSeqOnFailed = _ARG_2_
      _ARG_0_.PreTeleportSeqOnStarted = _ARG_3_
      if _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) then
      end
      _ARG_0_.PreTeleportSeqLoadHandle = _ARG_0_:AsyncLoadAssetArray({
        _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_)
      }, function()
        PreTeleportSeqLoadHandle = nil
        if not (U1 == PreTeleportSeqSerial and Owner) or not U2.slua.isValid(Owner.Object) then
          return
        end
        if U3 then
          if not _ENV:_SpawnPreTeleportShowPawn(U3, U4, U1, function()
            _ENV:_StartPreTeleportSequence(U1, U2, U3, U4, U5, U6)
            return
          end) then
          end
        else
          _ENV:_StartPreTeleportSequence(U5, U6, U7, U1, nil, nil)
        end
        return
      end)
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_NotifyPreTeleportSeqFailed"] = function(_ARG_0_)
    do
      _ARG_0_.PreTeleportSeqOnStarted = nil
      _ARG_0_.PreTeleportSeqOnFailed = nil
      if _ARG_0_.PreTeleportSeqOnFailed then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_NotifyPreTeleportSeqStarted"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 57, 235, 8, 186, 31, 29, 250, 47, 247, 83, 252, 232, 95, 240, 29, 184, 19, 199, 9),
        U1(21, 73, 148, 51, 88, 51, 145, 40, 227, 58, 0, 219, 63, 246, 71, 229, 245, 83)
      }))
      _ARG_0_.PreTeleportSeqOnStarted = nil
      _ARG_0_.PreTeleportSeqOnFailed = nil
      if _ARG_0_.PreTeleportSeqOnStarted then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SpawnPreTeleportShowPawn"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not slua.loadClass(_ARG_1_) or not slua.isValid(CGameWorld) then
        return false
      end
      if not _ARG_0_.Owner or not slua.isValid(_ARG_0_.Owner.Object) then
        return false
      end
      if not slua.isValid((CGameWorld:SpawnActor(slua.loadClass(_ARG_1_), _ARG_0_.Owner:K2_GetActorLocation(), _ARG_0_.Owner:K2_GetActorRotation(), nil))) then
        return false
      end
      if not slua.isValid(CGameWorld:SpawnActor(slua.loadClass(_ARG_1_), _ARG_0_.Owner:K2_GetActorLocation(), _ARG_0_.Owner:K2_GetActorRotation(), nil).CharacterAvatarComp2_BP) then
        return false
      end
      _ARG_0_.PreTeleportShowPawn = CGameWorld:SpawnActor(slua.loadClass(_ARG_1_), _ARG_0_.Owner:K2_GetActorLocation(), _ARG_0_.Owner:K2_GetActorRotation(), nil)
      _ARG_0_.PreTeleportSeqAvatarTimer = _ARG_0_:AddGameTimer(U2.AvatarLoadTimeout, false, function()
        PreTeleportSeqAvatarTimer = nil
        U1.print(U1.bWriteLog and U1.table.concat({
          U2(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 36, 244, 29, 164, 23, 52, 216, 56, 198, 98, 245, 225, 74, 239, 0, 190, 52, 252, 3),
          U2(19, 74, 129, 37, 68, 103, 149, 58, 162, 29, 21, 200, 109, 238, 120, 232, 240, 10, 228, 11, 183, 18, 235, 9, 167, 85, 68, 218, 49, 243, 126, 185, 229, 84, 249, 5, 171, 30)
        }))
        U3()
        return
      end)
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_StartPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if _ARG_1_.BindPlayerPawnName then
        if _ARG_1_.BindLocalPlayerPawn == true then
          _ARG_0_.PreTeleportPawnDrivenByShow = true
        else
        end
      end
      if _ARG_1_.DisablePlayerPawnSpawnTrack == true and _ARG_1_.BindPlayerPawnName and _ARG_1_.BindPlayerPawnName ~= U1() then
      end
      if not slua.isValid((Game:PlayLevelSequence(_ARG_0_.Owner and _ARG_0_.Owner.Object, _ARG_2_, _ARG_5_ or import((U1(47, 115, 147, 63, 79, 51, 185, 45, 183, 1, 56, 211, 47, 240, 118, 251, 237))).MakeTransform(_ARG_1_.Location or FVector(0, 0, 0), _ARG_1_.Rotation or FRotator(0, 0, 0), FVector(1, 1, 1)), _ARG_3_, true, {
        [_ARG_1_.BindPlayerPawnName] = _ARG_0_.PreTeleportShowPawn
      }, _ARG_0_.Owner and _ARG_0_.Owner.Object, {
        _ARG_1_.BindPlayerPawnName
      }))) then
        return
      end
      _ARG_0_.PreTeleportSeqActor = Game:PlayLevelSequence(_ARG_0_.Owner and _ARG_0_.Owner.Object, _ARG_2_, _ARG_5_ or import((U1(47, 115, 147, 63, 79, 51, 185, 45, 183, 1, 56, 211, 47, 240, 118, 251, 237))).MakeTransform(_ARG_1_.Location or FVector(0, 0, 0), _ARG_1_.Rotation or FRotator(0, 0, 0), FVector(1, 1, 1)), _ARG_3_, true, {
        [_ARG_1_.BindPlayerPawnName] = _ARG_0_.PreTeleportShowPawn
      }, _ARG_0_.Owner and _ARG_0_.Owner.Object, {
        _ARG_1_.BindPlayerPawnName
      })
      do return end
      _ARG_2_ = _ENV[161]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnPreTeleportSequenceEnd"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ ~= _ARG_0_.PreTeleportSeqSerial then
        return
      end
      print(bWriteLog and table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 56, 234, 44, 161, 28, 48, 207, 49, 247, 119, 246, 246, 78, 211, 23, 187, 18, 241, 2),
        U1(7, 127, 165, 60, 78)
      }))
      _ARG_0_.PreTeleportSeqActor = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopPreTeleportSequence"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
        _ARG_0_.PreTeleportSeqOnFailed = nil
      end
      _ARG_0_.PreTeleportSeqOnStarted = nil
      _ARG_0_.PreTeleportPawnDrivenByShow = nil
      _ARG_0_.PreTeleportSeqSerial = (_ARG_0_.PreTeleportSeqSerial or 0) + 1
      if _ARG_0_.PreTeleportSeqLoadHandle then
        _ARG_0_:CancelAsyncLoad(_ARG_0_.PreTeleportSeqLoadHandle)
        _ARG_0_.PreTeleportSeqLoadHandle = nil
      end
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 233, 40, 243, 86, 255, 245, 94, 241, 16, 142, 30, 233, 25, 161)))
      _ARG_0_.PreTeleportSeqActor = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnPreTeleportSeqPlayStarted"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 142, 30, 233, 25, 161)))
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 158, 18, 232, 29, 170, 45, 13, 199, 56, 224)))
      _ARG_0_:_ReleasePreTeleportLevelHold()
      _ARG_0_.PreTeleportShowFinished = nil
      _ARG_0_.PreTeleportClientLanded = nil
      if _ARG_1_.HoldStreamingAtTarget == true and _ARG_3_ then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(44, 117, 140, 54, 121, 51, 134, 41, 162, 4, 29, 212, 42, 195, 99, 221, 245, 88, 247, 7, 174, 51, 225, 16, 178, 0))) then
          _ARG_0_.PreTeleportLevelHoldDelayTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(44, 117, 140, 54, 121, 51, 134, 41, 162, 4, 29, 212, 42, 195, 99, 221, 245, 88, 247, 7, 174, 51, 225, 16, 178, 0))), false, function()
            PreTeleportLevelHoldDelayTimer = nil
            _ENV:_ArmPreTeleportLevelHold(U1, U2)
            return
          end)
        else
        end
      end
      if _ARG_1_.HidePlayerPawnDuringSequence == true and U1.slua.isValid(_ARG_2_) then
        _ARG_0_.PreTeleportPawnHidden = true
        _ARG_0_:SetPlayerCharacterHiddenInGame(_ARG_2_, true)
      end
      if _ARG_1_.BindLocalPlayerPawn == true and U1.slua.isValid(_ARG_2_) then
        _ARG_0_:_SetPreTeleportControllerRotationDisabled(_ARG_2_, true)
      end
      if _ARG_1_.DisableMovementDuringSequence == true and U1.slua.isValid(_ARG_2_) then
        _ARG_0_:_DetachBeCarriedBackForSequence(_ARG_2_)
        _ARG_0_:_SetPreTeleportMovementDisabled(_ARG_2_, true)
        _ARG_0_:_SetPreTeleportMoveInputIgnored(true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ArmPreTeleportLevelHold"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.PreTeleportLevelHeld or _ARG_0_.PreTeleportShowFinished or _ARG_0_.PreTeleportClientLanded then
        return
      end
      if _ARG_2_ ~= nil and _ARG_2_ ~= _ARG_0_.PreTeleportSeqSerial then
        return
      end
      if not SubsystemMgr:Get((U1(40, 127, 150, 55, 70, 20, 128, 62, 166, 8, 25, 211, 35, 229, 90, 238, 230))) then
        return
      end
      _ARG_0_.PreTeleportLevelHeld = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[1]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_DetachBeCarriedBackForSequence"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_1_.IsInBeCarriedBackState or not _ARG_1_:IsInBeCarriedBackState() then
        return
      end
      if slua.isValid(_ARG_1_.GetCarryBackComp and _ARG_1_:GetCarryBackComp() or nil) and (_ARG_1_.GetCarryBackComp and _ARG_1_:GetCarryBackComp() or nil).StopBeCarriedBack then
        if not _ARG_1_:IsInBeCarriedBackState() then
          return
        end
      end
      if not slua.isValid(_ARG_1_.RootComponent) or not slua.isValid(_ARG_1_.RootComponent:GetAttachParent()) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportMovementDisabled"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_ and _ARG_1_.STCharacterMovement) then
        return
      end
      if _ARG_2_ then
        if _ARG_0_.PreTeleportMovementMode ~= nil then
          return
        end
        _ARG_0_.PreTeleportMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).MovementMode
        _ARG_0_.PreTeleportCustomMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).CustomMovementMode
        _ARG_0_.PreTeleportMovementTickEnabled = (_ARG_1_ and _ARG_1_.STCharacterMovement):IsComponentTickEnabled()
        if _ARG_0_.PreTeleportMovementMode == U1 then
          _ARG_0_.PreTeleportMovementMode = U2
          _ARG_0_.PreTeleportCustomMovementMode = 0
          _ARG_0_.PreTeleportMovementTickEnabled = true
        end
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          _ARG_0_.PreTeleportMoveableSaved = (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).bMoveable
        end
        _ARG_0_.PreTeleportMovementGuardTimer = _ARG_0_:AddGameTimer(0.1, true, function()
          if PreTeleportMovementMode == nil then
            return
          end
          if not U1.slua.isValid(U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil) then
            return
          end
          if (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil):IsComponentTickEnabled() or (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil).MovementMode ~= U2 then
          end
          return
        end)
      else
        _ARG_0_.PreTeleportMovementMode = nil
        _ARG_0_.PreTeleportCustomMovementMode = nil
        _ARG_0_.PreTeleportMovementTickEnabled = nil
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) and _ARG_0_.PreTeleportMoveableSaved ~= nil then
          _ARG_0_.PreTeleportMoveableSaved = nil
        end
        if _ARG_0_.PreTeleportMovementMode ~= nil then
          if _ARG_1_.bDead ~= true then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnOwnerExitState"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not Client or _ARG_2_ ~= U1.BeCarriedBack or _ARG_0_.PreTeleportMovementMode == nil then
        return
      end
      if not slua.isValid(slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) and (_ARG_0_.Owner and _ARG_0_.Owner.Object).STCharacterMovement or nil) then
        return
      end
      if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
        if _ARG_0_.PreTeleportMoveableSaved == nil then
          _ARG_0_.PreTeleportMoveableSaved = (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).bMoveable
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1[88]
    end
  end,
  ["_SetPreTeleportControllerRotationDisabled"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_2_ then
        if _ARG_0_.PreTeleportControllerRotationSaved then
          return
        end
        _ARG_0_.PreTeleportControllerRotationSaved = {
          Yaw = _ARG_1_.bUseControllerRotationYaw,
          Pitch = _ARG_1_.bUseControllerRotationPitch,
          Roll = _ARG_1_.bUseControllerRotationRoll
        }
        _ARG_1_.bUseControllerRotationYaw = false
        _ARG_1_.bUseControllerRotationPitch = false
        _ARG_1_.bUseControllerRotationRoll = false
        print(bWriteLog and table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 36, 225, 8, 131, 11, 1, 254, 56, 254, 98, 233, 235, 72, 244, 49, 165, 9, 224, 30),
          U1(11, 118, 140, 55, 88, 21, 155, 56, 162, 29, 29, 213, 35, 198, 126, 250, 245, 72, 252, 7, 190, 87, 224, 21, 160, 24, 6, 198, 56, 246)
        }))
      else
        if not _ARG_0_.PreTeleportControllerRotationSaved then
          return
        end
        _ARG_0_.PreTeleportControllerRotationSaved = nil
        _ARG_1_.bUseControllerRotationYaw = _ARG_0_.PreTeleportControllerRotationSaved.Yaw
        _ARG_1_.bUseControllerRotationPitch = _ARG_0_.PreTeleportControllerRotationSaved.Pitch
        _ARG_1_.bUseControllerRotationRoll = _ARG_0_.PreTeleportControllerRotationSaved.Roll
        if _ARG_1_:K2_GetActorRotation().Pitch ~= 0 or _ARG_1_:K2_GetActorRotation().Roll ~= 0 then
        end
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) and (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()):GetControlRotation().Roll ~= 0 then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ApplyPreTeleportClientShowState"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client or type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) then
        return
      end
      _ARG_0_.PreTeleportActiveSeqConfig = _ARG_1_
      if not _ARG_0_.Owner then
        return
      end
      if not slua.isValid(_ARG_0_.Owner.Object) then
        return
      end
      if not _ARG_0_.Owner:IsLocallyControlled() then
        return
      end
      if _ARG_1_.ExitScopeOnSequence == true then
      end
      if _ARG_1_.ForceTPPDuringSequence == true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportClientShowState"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      _ARG_0_.PreTeleportActiveSeqConfig = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportForceTPP"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ then
        if _ARG_0_.PreTeleportForceTPPApplied or not slua.isValid(_ARG_1_) then
          return
        end
        _ARG_0_.PreTeleportForceTPPApplied = true
        if _ARG_1_:GetIsFPP() then
          _ARG_1_.bForceChangePersonPerspective = true
          _ARG_0_.PreTeleportChangedPP = true
        end
        _ARG_0_.PreTeleportSwitchPPWasDisabled = _ARG_1_:IsPawnStateDisabled(U1.SwitchPP)
        return
      end
      if not _ARG_0_.PreTeleportForceTPPApplied then
        return
      end
      _ARG_0_.PreTeleportForceTPPApplied = nil
      _ARG_0_.PreTeleportChangedPP = nil
      _ARG_0_.PreTeleportSwitchPPWasDisabled = nil
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_0_.PreTeleportSwitchPPWasDisabled then
      end
      if _ARG_0_.PreTeleportChangedPP then
        if _ARG_1_.bDead ~= true then
        end
        _ARG_1_.bForceChangePersonPerspective = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportMoveInputIgnored"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      if _ARG_1_ then
        if _ARG_0_.PreTeleportMoveInputIgnored then
          return
        end
        if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          return
        end
        _ARG_0_.PreTeleportMoveInputPC, _ARG_0_.PreTeleportMoveInputIgnored = _ARG_0_.Owner and _ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety(), true
      else
        if not _ARG_0_.PreTeleportMoveInputIgnored then
          return
        end
        _ARG_0_.PreTeleportMoveInputIgnored = nil
        _ARG_0_.PreTeleportMoveInputPC = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportMovement"] = function(_ARG_0_)
    do
      _ARG_0_:_SetPreTeleportMoveInputIgnored(false)
      if _ARG_0_.PreTeleportMovementMode == nil then
        return
      end
      if slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
      else
        _ARG_0_.PreTeleportMovementMode = nil
        _ARG_0_.PreTeleportCustomMovementMode = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_StopPreTeleportSeqShowHandling"] = function(_ARG_0_)
    do
      _ARG_0_.PreTeleportShowFinished = true
      _ARG_0_.PreTeleportPawnDrivenByShow = nil
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 158, 18, 232, 29, 170, 45, 13, 199, 56, 224)))
      _ARG_0_:_RestorePreTeleportPawnVisibility()
      _ARG_0_:_RestorePreTeleportMovement()
      _ARG_0_:_SetPreTeleportControllerRotationDisabled(_ARG_0_.Owner and _ARG_0_.Owner.Object, false)
      _ARG_0_:_RestorePreTeleportClientShowState()
      if not _ARG_0_.PreTeleportLevelHeld then
        return
      end
      if _ARG_0_.PreTeleportClientLanded then
        _ARG_0_:_ReleasePreTeleportLevelHold()
        return
      end
      if not _ARG_0_.PreTeleportLevelHoldTimer then
        _ARG_0_.PreTeleportLevelHoldTimer = _ARG_0_:AddGameTimer(U1.HoldReleaseTimeout, false, function()
          PreTeleportLevelHoldTimer = nil
          _ENV:_ReleasePreTeleportLevelHold()
          return
        end)
        U2.print(U2.bWriteLog and U2.table.concat({
          _ENV(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 36, 240, 19, 163, 41, 22, 207, 9, 247, 107, 252, 244, 85, 242, 6, 153, 2, 229, 63),
          _ENV(12, 117, 151, 26, 75, 41, 144, 32, 170, 7, 19, 154, 58, 227, 126, 253, 180, 76, 255, 16, 250, 27, 229, 18, 183, 16, 10, 205, 125, 240, 98, 255, 235, 72, 229, 82, 184, 2, 248, 9),
          _ENV(5, 105, 137, 60, 77, 103, 156, 35, 175, 13)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ReleasePreTeleportLevelHold"] = function(_ARG_0_)
    do
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 158, 18, 232, 29, 170, 45, 13, 199, 56, 224)))
      if not _ARG_0_.PreTeleportLevelHeld then
        return
      end
      _ARG_0_.PreTeleportLevelHeld = nil
      _ARG_0_.PreTeleportShowFinished = nil
      _ARG_0_.PreTeleportClientLanded = nil
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 142, 30, 233, 25, 161)))
      if U1.SubsystemMgr:Get((_ENV(40, 127, 150, 55, 70, 20, 128, 62, 166, 8, 25, 211, 35, 229, 90, 238, 230))) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[147]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportPawnVisibility"] = function(_ARG_0_)
    do
      if not _ARG_0_.PreTeleportPawnHidden then
        return
      end
      _ARG_0_.PreTeleportPawnHidden = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_DestroyPreTeleportShowPawn"] = function(_ARG_0_)
    do
      _ARG_0_.PreTeleportShowPawn = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSimulatedAndNotSpectating"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_1_:IsSimulated() and not (U1.slua.isValid((GetPlayerController())) and GetPlayerController():IsInSpectating()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPlayerCharacterHiddenInGame"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ then
        _ARG_1_:SetActorHiddenInGame(true)
      elseif not _ARG_1_.CharacterHide or not _ARG_1_.CharacterHide.bCharacterHideIngame then
        _ARG_1_:SetActorHiddenInGame(false)
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 137, 18, 240, 44, 191, 24, 29, 207, 47, 209, 111, 248, 246, 91, 227, 6, 175, 21, 220, 5),
        U1(0, 126, 133, 60, 99, 41, 179, 45, 174, 12, 84, 159, 62, 162, 63, 172, 231, 3)
      }), _ARG_2_, _ARG_1_:ToString()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckLoading"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.Owner:IsAutonomousProxy() then
      elseif Client and slua.isValid((U1.GetPlayerController())) and U1.GetPlayerController():IsSpectator() and slua.isValid(U1.GetPlayerController():GetCurPlayerCharacter()) and U1.GetPlayerController():GetCurPlayerCharacter().PlayerKey == _ARG_0_.Owner.PlayerKey then
      end
      if not (SubsystemMgr:Get((U2(40, 127, 150, 55, 70, 20, 128, 62, 166, 8, 25, 211, 35, 229, 90, 238, 230))) and true) or _ARG_2_.NotShowLoading then
        return false
      end
      if _ARG_2_ and _ARG_2_.SkipLoadingUI == true then
      end
      if _ARG_0_.LoadingEffectReason == nil then
      end
      do return true end
      do return end
      _ARG_1_ = U1[147]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartWaitingClientLoading"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 137, 3, 229, 14, 167, 46, 5, 195, 41, 251, 105, 254, 199, 86, 233, 23, 164, 19, 216, 3),
        U1(5, 126, 137, 60, 77, 103, 209, 63)
      }), _ARG_0_.Owner:ToString()))
      _ARG_0_.WaitingClientLoadingTimer = _ARG_0_:AddGameTimer(U2, false, function()
        print(bWriteLog and string.format(table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 137, 3, 229, 14, 167, 46, 5, 195, 41, 251, 105, 254, 199, 86, 233, 23, 164, 19, 216, 3),
          U1(5, 126, 137, 60, 77, 103, 163, 45, 170, 29, 29, 212, 42, 193, 123, 224, 241, 68, 228, 46, 181, 22, 224, 21, 189, 30, 48, 195, 48, 247, 117, 185, 240, 83, 237, 23, 165, 18, 224, 76),
          U1(65, 105)
        }), U2.Owner:ToString()))
        U2:OnReceiveClientTeleportLoadingFinish()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLevelStreamingLoadEnd"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 200, 25, 165, 28, 8, 249, 41, 224, 98, 248, 233, 83, 238, 21, 134, 8, 245, 8),
        U1(33, 116, 132, 114, 15, 52)
      }), _ARG_3_))
      _ARG_0_:RemoveCommonEvent(EVENTTYPE_LEVELSTREAMING, EVENTID_LEVELSTREAMING_LOAD_END)
      if _ARG_0_.Config then
        _ARG_0_:OnClientLanded()
      end
      _ARG_0_:RPC_Server_NotifyTeleportLoadingFinish()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Server_NotifyTeleportLoadingFinish"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 128, 28, 22, 220, 56, 224, 88, 215, 235, 78, 233, 20, 179, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 11, 155, 45, 167, 0, 26, 221, 11, 235, 121, 224, 231, 66, 176, 71, 169)
      }), _ARG_0_.Owner:ToString()))
      _ARG_0_:OnReceiveClientTeleportLoadingFinish()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnReceiveClientTeleportLoadingFinish"] = function(_ARG_0_)
    do
      if not _ARG_0_.WaitingClientLoadingTimer then
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 214, 25, 176, 28, 13, 220, 56, 209, 107, 240, 225, 84, 244, 38, 175, 11, 241, 28),
          U1(11, 104, 148, 30, 69, 38, 144, 37, 173, 14, 50, 211, 35, 235, 100, 225, 180, 68, 255, 66, 141, 22, 237, 8, 186, 23, 3, 233, 49, 251, 98, 247, 240, 118, 239, 19, 174, 14, 250, 11),
          U1(48, 115, 141, 55, 88, 107, 212, 62, 166, 29, 1, 200, 35)
        }))))
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 214, 25, 176, 28, 13, 220, 56, 209, 107, 240, 225, 84, 244, 38, 175, 11, 241, 28),
        U1(11, 104, 148, 30, 69, 38, 144, 37, 173, 14, 50, 211, 35, 235, 100, 225, 180, 15, 227)
      }), _ARG_0_.Owner:ToString()))
      _ARG_0_:TryRemoveNamedGameTimer((U1(51, 123, 137, 38, 67, 41, 147, 15, 175, 0, 17, 212, 57, 206, 120, 232, 240, 67, 254, 5, 142, 30, 233, 25, 161)))
      _ARG_0_.LuaDelegate:Broadcast(U2, _ARG_0_.Owner)
      _ARG_0_.LuaDelegate:Remove(U2)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ListenOnClientTeleportLoadingFinished"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.LuaDelegate:Add(_ENV, _ARG_1_, _ARG_2_)
      do return _ARG_0_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientPreCheckLoadingEffect"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 27, 237, 25, 189, 13, 52, 216, 56, 209, 111, 252, 231, 81, 204, 29, 171, 3, 253, 2),
        U1(3, 95, 134, 52, 79, 36, 128, 108, 230, 26)
      }), _ARG_1_))
      if _ARG_0_.MarkTeleportFailed then
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 27, 237, 25, 189, 13, 52, 216, 56, 209, 111, 252, 231, 81, 204, 29, 171, 3, 253, 2),
          U1(3, 95, 134, 52, 79, 36, 128, 108, 169, 28, 7, 206, 109, 207, 118, 251, 255, 126, 245, 14, 191, 7, 235, 14, 167, 63, 5, 195, 49, 247, 99, 181, 164, 72, 229, 6, 191, 21, 250)
        }))))
        return
      end
      if _ARG_0_.LoadingEffectReason == nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckLoadingEffect"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:IsLocal() then
        return
      end
      if not _ARG_1_ or not _ARG_1_.LoadingEffect then
        return
      end
      if not _ARG_1_.LoadingEffect.Type or not _ARG_1_.LoadingEffect.Param then
        return
      end
      _ARG_0_.LoadingEffectReason = _ARG_2_
      if _ARG_1_.LoadingEffect.Type == U1(55, 121, 146, 55, 79, 41, 177, 42, 165, 12, 23, 206) then
        if slua.isValid((slua.loadObject(_ARG_1_.LoadingEffect.Param .. U1(59, 89)))) then
          _ARG_0_.LoadingEffectObject = import((U1(55, 121, 146, 55, 79, 41, 181, 60, 179, 12, 21, 200, 44, 236, 116, 236, 199, 94, 241, 22, 179, 20, 247))).PlayDynamicScreenAppearance(_ARG_0_.Owner.Object, _ARG_0_.Owner.Object, import((U1(55, 78, 165, 42, 94, 53, 149, 11, 162, 4, 17, 202, 33, 227, 110, 218, 224, 75, 228, 11, 185, 4))).GetClassDefaultObject((slua.loadObject(_ARG_1_.LoadingEffect.Param .. U1(59, 89)))).AppearanceName, (slua.loadObject(_ARG_1_.LoadingEffect.Param .. U1(59, 89))))
        end
      elseif _ARG_1_.LoadingEffect.Type == U1(49, 83) and UIManager.UI_Config_InGame[_ARG_1_.LoadingEffect.Param] then
        _ARG_0_.LoadingEffectObject = UIManager.ShowUI(UIManager.UI_Config_InGame[_ARG_1_.LoadingEffect.Param])
      end
      if _ARG_0_.LoadingEffectObject then
        _ARG_0_.StartLoadingEffectTime = U3.GetRealTimeSeconds(_ARG_0_.Owner.Object)
        _ARG_0_.LoadingEffectObjectTimeoutTimer = _ARG_0_:AddGameTimer(U2, false, function()
          print(bWriteLog and string.format((table.concat({
            U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 31, 225, 31, 184, 53, 11, 203, 57, 251, 105, 254, 193, 92, 230, 23, 169, 19, 180, 24),
            U1(13, 119, 133, 61, 95, 51)
          }))))
          U2:TryDestroyLoadingEffect()
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[61]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientLanded"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 199, 16, 186, 28, 10, 222, 17, 243, 105, 253, 225, 94))
      if not (_ARG_0_.Config and Client) or not _ARG_0_.Owner then
        return
      end
      if slua.isValid((_ARG_0_.Owner:GetControllerSafety())) and not _ARG_0_.Owner.bEnsure then
        _ARG_0_.Owner:GetControllerSafety().bAutoSprint = false
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryDestroyLoadingEffect"] = function(_ARG_0_)
    do
      if not _ARG_0_:IsLocal() then
        return
      end
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(40, 117, 129, 54, 67, 41, 147, 9, 165, 15, 17, 217, 57, 205, 117, 227, 241, 73, 228, 54, 179, 26, 225, 19, 166, 13, 48, 195, 48, 247, 117)))
      if _ARG_0_.Config and _ARG_0_.Config.LoadingEffect and _ARG_0_.Config.LoadingEffect.NoDestroy then
        _ARG_0_:ClearLoadingEffectObject()
      elseif _ARG_0_.LoadingEffectObject then
        if _ARG_0_.LoadingEffectObject.End and not _ARG_0_.LoadingEffectObject.bHasClosed then
        elseif _ARG_0_.LoadingEffectObject.SetLifeSpan then
          if _ARG_0_.StartLoadingEffectTime and 1 > U1.GetRealTimeSeconds(_ARG_0_.Owner.Object) - _ARG_0_.StartLoadingEffectTime then
          else
          end
        else
        end
      end
      _ARG_0_.LoadingEffectReason = nil
      if _ARG_0_.Config and _ARG_0_.Config.HideAllUI then
        _ARG_0_:TryRemoveNamedGameTimer((_ENV(44, 115, 132, 55, 107, 43, 152, 25, 138, 61, 29, 215, 40, 237, 98, 253, 192, 67, 253, 7, 168)))
        _ARG_0_.HideAllUITimeoutTimer = _ARG_0_:AddGameTimer(2, false, function()
          print(bWriteLog and string.format((table.concat({
            U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 142, 5, 253, 56, 182, 10, 16, 216, 50, 235, 75, 246, 229, 94, 233, 28, 173, 34, 242, 10),
            U1(1, 121, 148, 114, 98, 46, 144, 41, 130, 5, 24, 239, 4, 214, 126, 228, 241, 69, 229, 22)
          }))))
          EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_EXIT_TEAM_SHOW)
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearLoadingEffectObject"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format((table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 27, 225, 29, 161, 53, 11, 203, 57, 251, 105, 254, 193, 92, 230, 23, 169, 19, 219, 14),
        U1(14, 127, 131, 38)
      }))))
      if _ARG_0_.Config and _ARG_0_.Config.AudioOnPreTeleportLoop and _ARG_0_.AudioOnPreTeleportID then
        _ARG_0_.AudioOnPreTeleportID = nil
      end
      _ARG_0_.LoadingEffectObject = nil
      _ARG_0_:CheckHideAllUI(false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckHideAllUI"] = function(_ARG_0_, _ARG_1_)
    do
      if not (Client and _ARG_0_:IsLocal() and _ARG_0_.Config) or not _ARG_0_.Config.HideAllUI then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 31, 225, 31, 184, 49, 13, 206, 56, 211, 107, 245, 209, 115, 160, 16, 130, 14, 240, 9),
        U1(68, 39, 192, 119, 89)
      }), _ARG_1_))
      if _ARG_1_ then
        EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_ENTER_TEAM_SHOW)
      else
        EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_EXIT_TEAM_SHOW)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Client_NotifyTeleportFailed"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 144, 21, 13, 207, 51, 230, 88, 215, 235, 78, 233, 20, 179, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 1, 149, 37, 175, 12, 16, 150, 109, 206, 120, 232, 240, 67, 254, 5, 159, 17, 226, 25, 176, 13, 54, 207, 60, 225, 104, 247, 164, 7, 160, 87, 185)
      }), _ARG_0_.LoadingEffectReason))
      _ARG_0_:StopPreTeleportSequence(true)
      _ARG_0_:_ReleasePreTeleportLevelHold()
      _ARG_0_:TryDestroyLoadingEffect()
      _ARG_0_.MarkTeleportFailed = true
      _ARG_0_:AddGameTimer(0.1, false, function()
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 144, 21, 13, 207, 51, 230, 88, 215, 235, 78, 233, 20, 179, 51, 241, 0),
          U1(1, 106, 143, 32, 94, 1, 149, 37, 175, 12, 16, 150, 109, 207, 118, 251, 255, 126, 245, 14, 191, 7, 235, 14, 167, 63, 5, 195, 49, 247, 99, 185, 185, 26, 238, 27, 166)
        }))))
        U2.MarkTeleportFailed = nil
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsLocal"] = function(_ARG_0_)
    do
      if not _ARG_0_.Owner then
        return false
      end
      do return (not _ARG_0_.Owner.IsLocallyControlled or not _ARG_0_.Owner:IsLocallyControlled()) and _ARG_0_.Owner.IsLocalViewed and _ARG_0_.Owner:IsLocalViewed() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}).ClientRPC.RPC_Client_PlayPreTeleportSequence = {
  Reliable = true,
  Params = {
    UEnums.EPropertyClass.Int,
    UEnums.EPropertyClass.Int,
    UEnums.EPropertyClass.Int,
    UEnums.EPropertyClass.Float,
    UEnums.EPropertyClass.Float,
    UEnums.EPropertyClass.Float,
    UEnums.EPropertyClass.Float,
    UEnums.EPropertyClass.Float,
    UEnums.EPropertyClass.Float,
    UEnums.EPropertyClass.Float,
    UEnums.EPropertyClass.Float,
    UEnums.EPropertyClass.Float
  }
}
;({
  ServerRPC = {},
  ClientRPC = {},
  ["_PostConstruct"] = function(_ARG_0_)
    do
      __super._PostConstruct(_ARG_0_)
      _ARG_0_.LuaDelegate = U1.LuaDelegate()
      _ARG_0_.bPreTeleportHiddenOnOthers = false
      _ARG_0_.PreTeleportDamageBlocked = false
      _ARG_0_.PreTeleportAllowedDamageTypes = nil
      _ARG_0_.PreTeleportDamageBlockExpireAt = 0
      _ARG_0_.bPreTeleportDamageEventBound = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLifetimeReplicatedProps"] = function(_ARG_0_)
    do
      do return {
        {
          U2(6, 74, 146, 55, 126, 34, 152, 41, 179, 6, 6, 206, 5, 235, 115, 237, 241, 68, 223, 12, 149, 3, 236, 25, 161, 10),
          U1.import((U2(33, 86, 137, 52, 79, 51, 157, 33, 166, 42, 27, 212, 41, 235, 99, 224, 251, 68))).COND_None,
          U1.UEnums.EPropertyClass.Bool
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveBeginPlay"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format((U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 18, 231, 25, 186, 15, 1, 232, 56, 245, 110, 247, 212, 86, 225, 11))))
      U2.__super.ReceiveBeginPlay(_ARG_0_)
      if not _ARG_0_.Owner then
        return
      end
      if not slua.isValid(_ARG_0_.Owner.Object) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckPreload"] = function(_ARG_0_)
    do
      if not _ARG_0_.Owner then
        return
      end
      if not _ARG_0_.Owner:IsLocallyControlled() and not _ARG_0_.Owner:IsLocalViewed() then
        return
      end
      if _ARG_0_.PreloadAssets then
        return
      end
      _ARG_0_.PreloadAssets = {}
      if U2.GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229))) then
        goto lbl_155
        ::lbl_155::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveEndPlay"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.LuaDelegate then
        _ARG_0_.LuaDelegate:Dispose()
      end
      if Client then
        _ARG_0_:StopPreTeleportSequence(true)
        _ARG_0_:_RestorePreTeleportPawnVisibility()
        _ARG_0_:_RestorePreTeleportMovement()
        _ARG_0_:_ReleasePreTeleportLevelHold()
        _ARG_0_:_RestorePreTeleportHiddenOnThisClient()
        _ARG_0_.PreloadAssets = nil
        _ARG_0_:TryRemoveNamedGameTimer((U1(32, 127, 140, 51, 83, 4, 152, 35, 176, 12, 56, 213, 44, 230, 126, 231, 243, 111, 246, 4, 191, 20, 240, 41, 154, 45, 13, 199, 56, 224)))
      else
        _ARG_0_:TryRemoveNamedGameTimer((U1(52, 127, 142, 54, 67, 41, 147, 28, 177, 12, 32, 223, 33, 231, 103, 230, 230, 94, 196, 11, 183, 18, 246)))
        _ARG_0_.PendingPreTeleport = nil
        _ARG_0_:_SetPendingTeleportMovementFrozen(_ARG_0_.Owner and _ARG_0_.Owner.Object, false)
        _ARG_0_:_ReleasePreTeleportServerShowState()
      end
      U2.__super.ReceiveEndPlay(_ARG_0_, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoteTeleportPawnByTable"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_1_.BornPos and #_ARG_1_.BornPos > 0 then
        if 10 < _ARG_2_ then
          print(bWriteLog and table.concat({
            U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 18, 233, 19, 167, 28, 48, 207, 49, 247, 119, 246, 246, 78, 208, 19, 189, 9, 214, 21),
            U1(48, 123, 130, 62, 79, 107, 212, 24, 166, 5, 17, 202, 34, 240, 99, 217, 245, 93, 254, 66, 151, 24, 246, 25, 243, 45, 12, 203, 51, 178, 115, 252, 234, 0, 160)
          }) .. tostring(_ARG_0_.Owner.PlayerKey))
          return
        end
        if not _ARG_0_:RemoteTeleportPawn(_ARG_1_.BornPos[math.random(1, #_ARG_1_.BornPos)].Location, _ARG_1_.BornPos[math.random(1, #_ARG_1_.BornPos)].Roatation, _ARG_3_, _ARG_4_) then
          _ARG_2_ = _ARG_2_ + 1
        end
      end
      do return end
      _ARG_1_ = U1.tostring
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoteTeleportPawn"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not Client and _ARG_0_.Owner then
        if Game:TeleportPawn(_ARG_0_.Owner.Object, _ARG_1_, _ARG_2_, false, true, false, false, _ARG_3_, _ARG_4_) then
          if _ARG_3_ == import((U1(33, 78, 133, 62, 79, 55, 155, 62, 183, 57, 21, 205, 35, 214, 110, 249, 241))).ParachuteTeleport then
          elseif _ARG_3_ == import((U1(33, 78, 133, 62, 79, 55, 155, 62, 183, 57, 21, 205, 35, 214, 110, 249, 241))).RemoteTeleport then
          end
          if _ARG_4_ and _ARG_0_:GetConfig(_ARG_4_) and _ARG_0_:GetConfig(_ARG_4_).GameTLogId and SubsystemMgr:Get((U1(32, 73, 163, 61, 71, 42, 155, 34, 151, 37, 27, 221, 30, 247, 117, 250, 237, 89, 228, 7, 183))) then
          end
        end
        return (Game:TeleportPawn(_ARG_0_.Owner.Object, _ARG_1_, _ARG_2_, false, true, false, false, _ARG_3_, _ARG_4_))
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1[252]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInTeleportState"] = function(_ARG_0_)
    do
      if _ARG_0_.PreTeleportActiveSeqConfig ~= nil or _ARG_0_.PreTeleportSeqActor ~= nil or _ARG_0_.LoadingEffectReason ~= nil or _ARG_0_.PreTeleportLevelHeld == true then
      end
      do return _ARG_0_.PreTeleportActiveSeqConfig ~= nil or _ARG_0_.PreTeleportSeqActor ~= nil or _ARG_0_.LoadingEffectReason ~= nil or _ARG_0_.PreTeleportLevelHeld == true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPawnAttached"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return false
      end
      if not slua.isValid((_ARG_0_.Owner and _ARG_0_.Owner.Object).RootComponent) then
        return false
      end
      do return slua.isValid((_ARG_0_.Owner and _ARG_0_.Owner.Object).RootComponent:GetAttachParent()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPawnOnVehicle"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return false
      end
      do return (_ARG_0_.Owner and _ARG_0_.Owner.Object):HasState(U1.InVehicle) or (_ARG_0_.Owner and _ARG_0_.Owner.Object):HasState(U1.DriveVehicle) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoteTeleport"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_0_:IsPawnOnVehicle() then
        print(bWriteLog and string.format(table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 18, 233, 19, 167, 28, 48, 207, 49, 247, 119, 246, 246, 78, 160, 0, 175, 1, 225, 31),
          U1(1, 126, 204, 114, 90, 38, 131, 34, 227, 6, 26, 154, 59, 231, 127, 224, 247, 70, 245, 78, 250, 39, 232, 29, 170, 28, 22, 225, 56, 235, 39, 164, 164, 31, 243, 94, 234, 36, 251, 2),
          U1(2, 115, 135, 27, 78, 103, 201, 108, 230, 26)
        }), tostring(_ARG_0_.Owner.PlayerKey), tostring(_ARG_3_)))
        return false
      end
      if _ARG_0_:IsPawnAttached() then
        return false
      end
      if _ARG_0_:_TryDeferTeleportForPreSequence(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport, _ARG_4_) then
        return true, (_ARG_0_:_TryCancelCarryBackForTeleport(_ARG_3_))
      end
      if not _ARG_0_:InternalTeleport(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport) then
        return (_ARG_0_:InternalTeleport(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport))
      end
      do return _ARG_0_:InternalTeleport(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport), (_ARG_0_:_TryCancelCarryBackForTeleport(_ARG_3_)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_TryCancelCarryBackForTeleport"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return nil
      end
      if not _ARG_0_:GetConfig(_ARG_1_) or _ARG_0_:GetConfig(_ARG_1_).CancelCarryBackOnTeleport ~= true then
        return nil
      end
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) or not (_ARG_0_.Owner and _ARG_0_.Owner.Object).IsInCarryBackState then
        return nil
      end
      if (_ARG_0_.Owner and _ARG_0_.Owner.Object):IsInCarryBackState() then
      elseif (_ARG_0_.Owner and _ARG_0_.Owner.Object):IsInBeCarriedBackState() then
        if slua.isValid(((_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCarryBackCharacter())) then
        end
      else
        return nil
      end
      do return slua.isValid(((_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCarryBackCharacter())) and (_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCarryBackCharacter() or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_TryDeferTeleportForPreSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if Client then
        return false
      end
      if type(_ARG_0_:GetConfig(_ARG_3_) and _ARG_0_:GetConfig(_ARG_3_).SequenceOnPreTeleport) ~= U1(16, 123, 130, 62, 79) then
        return false
      end
      if not slua.isValid(_ARG_0_.Owner.Object) or _ARG_0_.Owner.bEnsure or not Game:IsPlayer(_ARG_0_.Owner.Object) then
        return false
      end
      if not slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
        return false
      end
      if _ARG_0_.PendingPreTeleport then
        return true
      end
      _ARG_0_.PendingPreTeleportSerial = (_ARG_0_.PendingPreTeleportSerial or 0) + 1
      _ARG_0_.PendingPreTeleport = {
        Location = _ARG_1_,
        Rotation = _ARG_2_,
        ConfigId = _ARG_3_,
        Type = _ARG_4_,
        Serial = _ARG_0_.PendingPreTeleportSerial,
        bStarted = false
      }
      _ARG_0_.PendingPreTeleportTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_3_) and _ARG_0_:GetConfig(_ARG_3_).SequenceOnPreTeleport, (U1(55, 127, 146, 36, 79, 53, 163, 45, 170, 29, 32, 211, 32, 231, 120, 252, 224))), false, function()
        PendingPreTeleportTimer = nil
        _ENV:_ExecutePendingPreTeleport(U1, (U2(48, 115, 141, 55, 69, 50, 128)))
        return
      end)
      if (_ARG_0_:GetConfig(_ARG_3_) and _ARG_0_:GetConfig(_ARG_3_).SequenceOnPreTeleport).DisableMovementDuringSequence == true then
      end
      if _ARG_5_ then
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetPreTeleportSeqConfigValue"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return type(_ARG_1_) == U1(16, 123, 130, 62, 79) and tonumber(_ARG_1_[_ARG_2_]) or nil or tonumber(U2[_ARG_2_]) or 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnClientPreTeleportSeqStarted"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.PendingPreTeleport or _ARG_0_.PendingPreTeleport.Serial ~= _ARG_1_ then
        return
      end
      if _ARG_0_.PendingPreTeleport.bStarted then
        return
      end
      _ARG_0_.PendingPreTeleport.bStarted = true
      if type(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport) == U1(16, 123, 130, 62, 79) and (_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport).HidePawnOnOtherClientsDuringSequence == true then
        _ARG_0_.bPreTeleportHiddenOnOthers = true
      end
      if 0 >= _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) then
      end
      if 0 >= _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) - _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(48, 127, 140, 55, 90, 40, 134, 56, 130, 1, 17, 219, 41, 214, 126, 228, 241))) then
        return
      end
      _ARG_0_.PendingPreTeleportTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) - _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(48, 127, 140, 55, 90, 40, 134, 56, 130, 1, 17, 219, 41, 214, 126, 228, 241))), false, function()
        PendingPreTeleportTimer = nil
        _ENV:_ExecutePendingPreTeleport(U1, (U2(37, 114, 133, 51, 78, 8, 146, 31, 166, 24, 1, 223, 35, 225, 114, 204, 250, 78)))
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[84]
    end
  end,
  ["_OnClientPreTeleportSeqSkipped"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.PendingPreTeleport or _ARG_0_.PendingPreTeleport.Serial ~= _ARG_1_ then
        return
      end
      if _ARG_0_.PendingPreTeleport.bStarted then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ExecutePendingPreTeleport"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.PendingPreTeleport or _ARG_0_.PendingPreTeleport.Serial ~= _ARG_1_ then
        return
      end
      _ARG_0_.PendingPreTeleport = nil
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if _ARG_0_.Owner.bDead == true then
        return
      end
      if not _ARG_0_:InternalTeleport(_ARG_0_.PendingPreTeleport.Location, _ARG_0_.PendingPreTeleport.Rotation, _ARG_0_.PendingPreTeleport.ConfigId, _ARG_0_.PendingPreTeleport.Type) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CancelPendingPreTeleport"] = function(_ARG_0_, _ARG_1_)
    do
      if Client or not _ARG_0_.PendingPreTeleport then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 52, 229, 18, 176, 28, 8, 250, 56, 252, 99, 240, 234, 93, 208, 0, 175, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 103, 164, 32, 162, 16, 17, 200, 6, 231, 110, 169, 169, 10, 181, 17, 246, 87, 215, 25, 161, 16, 5, 198, 125, 175, 39, 188, 247, 22, 160, 32, 175, 6, 231, 3),
        U1(10, 58, 221, 114, 15, 52)
      }), tostring(_ARG_0_.Owner and _ARG_0_.Owner.PlayerKey), tostring(_ARG_0_.PendingPreTeleport.Serial), tostring(_ARG_1_)))
      _ARG_0_.PendingPreTeleport = nil
      _ARG_0_:TryRemoveNamedGameTimer((U1(52, 127, 142, 54, 67, 41, 147, 28, 177, 12, 32, 223, 33, 231, 103, 230, 230, 94, 196, 11, 183, 18, 246)))
      _ARG_0_:_SetPendingTeleportMovementFrozen(_ARG_0_.Owner and _ARG_0_.Owner.Object, false)
      _ARG_0_:_ReleasePreTeleportServerShowState()
      _ARG_0_:RPC_Client_NotifyTeleportFailed()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnOwnerDeath"] = function(_ARG_0_)
    do
      if not Client then
        if not _ARG_0_.PendingPreTeleport then
          return
        end
        if type(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport) == U1(16, 123, 130, 62, 79) and (_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport).CancelTeleportOnDeath == true then
        end
        return
      end
      if type(_ARG_0_.PreTeleportActiveSeqConfig) ~= U1(16, 123, 130, 62, 79) or _ARG_0_.PreTeleportActiveSeqConfig.CancelTeleportOnDeath ~= true then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPendingTeleportMovementFrozen"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      if _ARG_2_ then
        if not slua.isValid(_ARG_1_ and _ARG_1_.STCharacterMovement) or _ARG_0_.PendingTeleportMovementMode ~= nil then
          return
        end
        _ARG_0_.PendingTeleportMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).MovementMode
        _ARG_0_.PendingTeleportCustomMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).CustomMovementMode
        _ARG_0_.PendingTeleportMovementActive = (_ARG_1_ and _ARG_1_.STCharacterMovement):IsActive()
        _ARG_0_.PendingTeleportMovementTickEnabled = (_ARG_1_ and _ARG_1_.STCharacterMovement):IsComponentTickEnabled()
        if _ARG_0_.PendingTeleportMovementMode == U1 then
          _ARG_0_.PendingTeleportMovementMode = U2
          _ARG_0_.PendingTeleportCustomMovementMode = 0
          _ARG_0_.PendingTeleportMovementActive = true
          _ARG_0_.PendingTeleportMovementTickEnabled = true
        end
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          _ARG_0_.PendingTeleportMoveableSaved = (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).bMoveable
        end
        _ARG_0_.PendingTeleportMovementGuardTimer = _ARG_0_:AddGameTimer(0.1, true, function()
          if PendingTeleportMovementMode == nil then
            return
          end
          if not U1.slua.isValid(U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil) then
            return
          end
          if (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil):IsActive() or (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil):IsComponentTickEnabled() or (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil).MovementMode ~= U2 then
          end
          return
        end)
        return
      end
      if _ARG_0_.PendingTeleportMovementMode == nil then
        return
      end
      _ARG_0_.PendingTeleportMovementMode = nil
      _ARG_0_.PendingTeleportCustomMovementMode = nil
      _ARG_0_.PendingTeleportMovementActive = nil
      _ARG_0_.PendingTeleportMovementTickEnabled = nil
      if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) and _ARG_0_.PendingTeleportMoveableSaved ~= nil then
        _ARG_0_.PendingTeleportMoveableSaved = nil
      end
      if slua.isValid(_ARG_1_ and _ARG_1_.STCharacterMovement) then
        if _ARG_1_.bDead ~= true then
        end
        if _ARG_0_.PendingTeleportMovementActive == false then
        end
      end
      do return end
      _ARG_0_ = _ENV[87]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ResolvePreTeleportForbiddenStates"] = function(_ARG_0_, _ARG_1_)
    do
      if (type(_ARG_1_) == U1(16, 123, 130, 62, 79) and _ARG_1_.ForbiddenPawnStatesDuringSequence or nil) == true then
      end
      if type(U2) ~= U1(16, 123, 130, 62, 79) then
        return nil
      end
      goto lbl_158
      if type(62) == U1(23, 110, 146, 59, 68, 32) then
      end
      if U3[62] ~= nil and U3[62] ~= U3.Dying and U3[62] ~= U3.Dead then
      else
      end
      ::lbl_158::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportPawnStatesDisabled"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ then
        if _ARG_0_.PreTeleportDisabledPawnStates or not slua.isValid(_ARG_1_) then
          return
        end
        if not _ARG_0_:_ResolvePreTeleportForbiddenStates(_ARG_2_) or #_ARG_0_:_ResolvePreTeleportForbiddenStates(_ARG_2_) == 0 then
          return
        end
        goto lbl_41
        ::lbl_41::
        _ARG_0_ = _ARG_0_
        _ARG_0_.PreTeleportDisabledPawnStates, _ARG_0_ = {}, _ARG_0_
        return
      end
      _ARG_0_.PreTeleportDisabledPawnStates = nil
      if not _ARG_0_.PreTeleportDisabledPawnStates or not slua.isValid(_ARG_1_) then
        return
      end
      goto lbl_154
      ::lbl_154::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CancelPreTeleportHoldGrenade"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) or not _ARG_1_:HasState(U1.HoldGrenade) then
        return
      end
      print(bWriteLog and table.concat({
        U2(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 52, 229, 18, 176, 28, 8, 250, 47, 247, 83, 252, 232, 95, 240, 29, 184, 19, 220, 3),
        U2(8, 126, 167, 32, 79, 41, 149, 40, 166)
      }))
      if Client then
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          ;(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).TouchEndTriggerSkillID = -1
        end
      end
      _ARG_1_:TriggerCustomEvent(U3.PlayerRequestCancel, -1)
      if Client then
        EventSystem:postEvent(EVENTTYPE_INGAME_SHOOTINGUI_PANEL, EVENTID_ON_THROW_CANCEL_BUTTON_CLICK)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportGrenadePredictLine"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if not _ARG_0_.Owner.IsLocallyControlled or not _ARG_0_.Owner:IsLocallyControlled() then
        return
      end
      if not slua.isValid(((_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCurrentWeapon())) or not (_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCurrentWeapon().EnableWeaponPredictLine then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PreparePreTeleportLocomotion"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_.DisableMovementDuringSequence == true and _ARG_2_.StopAllSkillsOnSequence == true and slua.isValid((_ARG_1_:GetPlayerControllerSafety())) and (_ARG_1_:GetPlayerControllerSafety():GetCurrentStateType() == import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteJump or _ARG_1_:GetPlayerControllerSafety():GetCurrentStateType() == import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteOpen) then
        if not Client and _ARG_1_:GetPlayerControllerSafety():GetCurrentStateType() == import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteOpen and _ARG_1_:GetPlayerControllerSafety().GetStateMachineCompent and slua.isValid((_ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent())) and _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState and _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill == true then
          _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill = false
        end
        if Client then
        else
        end
        if slua.isValid(_ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState) and _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill == true then
          _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill = true
        end
      end
      if _ARG_2_.StopAllSkillsOnSequence == true then
        if Client then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ApplyPreTeleportServerShowState"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not (not Client and slua.isValid(_ARG_1_)) or type(_ARG_2_) ~= U1(16, 123, 130, 62, 79) then
        return
      end
      _ARG_0_:_ReleasePreTeleportServerShowState()
      _ARG_0_:_PreparePreTeleportLocomotion(_ARG_1_, _ARG_2_)
      if _ARG_2_.ExitScopeOnSequence == true then
        _ARG_1_:ScopeInterrupt(U2.Normal)
      end
      _ARG_0_:_SetPreTeleportPawnStatesDisabled(_ARG_1_, _ARG_2_, true)
      _ARG_0_:_AddPreTeleportDamageBlock(_ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ResolvePreTeleportAllowedDamageTypes"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_.AllowedDamageTypesDuringSequence) ~= U1(16, 123, 130, 62, 79) then
      end
      goto lbl_193
      if type(62) == U1(10, 111, 141, 48, 79, 53) and 62 or type(62) == U1(23, 110, 146, 59, 68, 32) and import((U1(33, 94, 129, 63, 75, 32, 145, 24, 186, 25, 17)))[62] or nil then
      else
      end
      ::lbl_193::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {
        [type(62) == U1(10, 111, 141, 48, 79, 53) and 62 or type(62) == U1(23, 110, 146, 59, 68, 32) and import((U1(33, 94, 129, 63, 75, 32, 145, 24, 186, 25, 17)))[62] or nil] = true
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetPreTeleportDamageBlockMaxDuration"] = function(_ARG_0_, _ARG_1_)
    do
      if (U1.type(_ARG_1_) == _ENV(16, 123, 130, 62, 79) and U1.tonumber(_ARG_1_.DamageBlockMaxDuration) or nil) and 0 < (U1.type(_ARG_1_) == _ENV(16, 123, 130, 62, 79) and U1.tonumber(_ARG_1_.DamageBlockMaxDuration) or nil) then
        return U1.type(_ARG_1_) == _ENV(16, 123, 130, 62, 79) and U1.tonumber(_ARG_1_.DamageBlockMaxDuration) or nil
      end
      do return _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(55, 127, 146, 36, 79, 53, 163, 45, 170, 29, 32, 211, 32, 231, 120, 252, 224))) + _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) + _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 9, 227, 122, 232, 243, 79, 210, 14, 181, 20, 239, 52, 188, 21, 0, 254, 52, 255, 98))) + 10 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_AddPreTeleportDamageBlock"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) or _ARG_1_.BlockDamageDuringSequence ~= true then
        return
      end
      _ARG_0_:_RemovePreTeleportDamageBlock()
      _ARG_0_.PreTeleportAllowedDamageTypes = _ARG_0_:_ResolvePreTeleportAllowedDamageTypes(_ARG_1_)
      _ARG_0_.PreTeleportDamageBlocked = true
      _ARG_0_.PreTeleportDamageBlockExpireAt = (slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) and U2.GetRealTimeSeconds(_ARG_0_.Owner and _ARG_0_.Owner.Object) or 0) + _ARG_0_:_GetPreTeleportDamageBlockMaxDuration(_ARG_1_)
      _ARG_0_.PreTeleportDamageBlockSafetyTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportDamageBlockMaxDuration(_ARG_1_), false, function()
        PreTeleportDamageBlockSafetyTimer = nil
        if PreTeleportDamageBlocked then
          U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
            U2(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 54, 224, 24, 131, 11, 1, 254, 56, 254, 98, 233, 235, 72, 244, 54, 171, 10, 245, 11),
            U2(1, 88, 140, 61, 73, 44, 212, 63, 162, 15, 17, 206, 52, 162, 99, 224, 249, 79, 255, 23, 174, 87, 161, 15, 243, 10, 72, 138, 59, 253, 117, 250, 225, 26, 242, 23, 166, 2, 245, 31),
            U2(1, 54, 192, 2, 70, 38, 141, 41, 177, 34, 17, 195, 109, 191, 55, 172, 231)
          }), U1.tostring(U3), U1.tostring(Owner and Owner.PlayerKey)))
          _ENV:_RemovePreTeleportDamageBlock()
        end
        return
      end)
      if not _ARG_0_.bPreTeleportDamageEventBound then
        _ARG_0_.bPreTeleportDamageEventBound = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RemovePreTeleportDamageBlock"] = function(_ARG_0_)
    do
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 254, 44, 239, 118, 238, 241, 104, 252, 13, 185, 28, 208, 21, 190, 28, 22)))
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 254, 44, 239, 118, 238, 241, 104, 252, 13, 185, 28, 215, 29, 181, 28, 16, 211, 9, 251, 106, 252, 246)))
      _ARG_0_.PreTeleportDamageBlockSafetyTimer = nil
      _ARG_0_.PreTeleportDamageBlockExpireAt = 0
      if not _ARG_0_.PreTeleportDamageBlocked then
        return
      end
      _ARG_0_.PreTeleportDamageBlocked = false
      _ARG_0_.PreTeleportAllowedDamageTypes = nil
      if _ARG_0_.bPreTeleportDamageEventBound then
        _ARG_0_.bPreTeleportDamageEventBound = false
        _ARG_0_:RemoveCommonEvent(U1.EVENTTYPE_INGAME_NORMAL, U1.EVENTID_PRE_TAKE_DAMAGE)
      end
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        _ENV(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 37, 225, 17, 188, 15, 1, 250, 47, 247, 83, 252, 232, 95, 240, 29, 184, 19, 208, 13),
        _ENV(9, 123, 135, 55, 104, 43, 155, 47, 168, 73, 36, 214, 44, 251, 114, 251, 223, 79, 233, 66, 231, 87, 161, 15)
      }), U1.tostring(_ARG_0_.Owner and _ARG_0_.Owner.PlayerKey)))
      return
    end
  end,
  ["HandlePreTeleportPreTakeDamage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not (not Client and _ARG_0_.PreTeleportDamageBlocked) or not slua.isValid(_ARG_3_) then
        return
      end
      if not slua.isValid(_ARG_3_.Target) then
        return
      end
      if not (_ARG_3_.Target.PlayerKey and _ARG_0_.Owner) or _ARG_3_.Target.PlayerKey ~= _ARG_0_.Owner.PlayerKey then
        return
      end
      if slua.isValid(_ARG_0_.Owner.Object) and _ARG_0_.PreTeleportDamageBlockExpireAt > 0 and U1.GetRealTimeSeconds(_ARG_0_.Owner.Object) > _ARG_0_.PreTeleportDamageBlockExpireAt then
        return
      end
      if _ARG_0_.PreTeleportAllowedDamageTypes and _ARG_0_.PreTeleportAllowedDamageTypes[_ARG_3_.DamageType] then
        return
      end
      _ARG_3_.Damage = 0
      do return end
      _ARG_1_ = _ENV[12]
    end
  end,
  ["_ScheduleReleasePreTeleportServerShowState"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if _ARG_0_.PreTeleportDamageBlocked then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 9, 227, 122, 232, 243, 79, 210, 14, 181, 20, 239, 52, 188, 21, 0, 254, 52, 255, 98))) then
          _ARG_0_.PreTeleportDamageBlockTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 9, 227, 122, 232, 243, 79, 210, 14, 181, 20, 239, 52, 188, 21, 0, 254, 52, 255, 98))), false, function()
            PreTeleportDamageBlockTimer = nil
            _ENV:_RemovePreTeleportDamageBlock()
            return
          end)
        else
        end
      end
      if _ARG_0_.bPreTeleportHiddenOnOthers then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(55, 114, 143, 37, 122, 38, 131, 34, 140, 7, 59, 206, 37, 231, 101, 250, 208, 79, 252, 3, 163))) then
          _ARG_0_.PreTeleportShowOnOthersTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(55, 114, 143, 37, 122, 38, 131, 34, 140, 7, 59, 206, 37, 231, 101, 250, 208, 79, 252, 3, 163))), false, function()
            PreTeleportShowOnOthersTimer = nil
            bPreTeleportHiddenOnOthers = false
            return
          end)
        else
          _ARG_0_.bPreTeleportHiddenOnOthers = false
        end
      end
      if _ARG_0_.PreTeleportDisabledPawnStates then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 30, 246, 118, 253, 241, 98, 255, 14, 190, 35, 237, 17, 182))) then
          _ARG_0_.PreTeleportStateRestoreTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 30, 246, 118, 253, 241, 98, 255, 14, 190, 35, 237, 17, 182))), false, function()
            PreTeleportStateRestoreTimer = nil
            _ENV:_SetPreTeleportPawnStatesDisabled(Owner and Owner.Object, nil, false)
            return
          end)
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ReleasePreTeleportServerShowState"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      _ARG_0_:TryRemoveNamedGameTimer((U1(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 233, 37, 237, 96, 198, 250, 101, 228, 10, 191, 5, 247, 40, 186, 20, 1, 216)))
      _ARG_0_:TryRemoveNamedGameTimer((U1(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 233, 57, 227, 99, 236, 198, 79, 227, 22, 181, 5, 225, 40, 186, 20, 1, 216)))
      if _ARG_0_.bPreTeleportHiddenOnOthers then
        _ARG_0_.bPreTeleportHiddenOnOthers = false
      end
      _ARG_0_:_SetPreTeleportPawnStatesDisabled(_ARG_0_.Owner and _ARG_0_.Owner.Object, nil, false)
      _ARG_0_:_RemovePreTeleportDamageBlock()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_bPreTeleportHiddenOnOthers"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if _ARG_0_.bPreTeleportHiddenOnOthers == true and not _ARG_0_:IsLocal() then
        if not _ARG_0_.PreTeleportHiddenOnThisClient then
          _ARG_0_.PreTeleportHiddenOnThisClient = true
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportHiddenOnThisClient"] = function(_ARG_0_)
    do
      if not _ARG_0_.PreTeleportHiddenOnThisClient then
        return
      end
      _ARG_0_.PreTeleportHiddenOnThisClient = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Server_ReportPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 128, 28, 22, 220, 56, 224, 88, 203, 225, 74, 239, 0, 190, 55, 230, 9),
        U1(48, 127, 140, 55, 90, 40, 134, 56, 144, 12, 5, 207, 40, 236, 116, 236, 180, 122, 252, 3, 163, 18, 246, 55, 182, 0, 68, 151, 125, 183, 116, 181, 164, 104, 229, 2, 165, 21, 224, 56),
        U1(29, 106, 133, 114, 23, 103, 209, 63, 239, 73, 39, 223, 63, 235, 118, 229, 180, 23, 176, 71, 169)
      }), tostring(_ARG_0_.Owner.PlayerKey), tostring(_ARG_1_), tostring(_ARG_2_)))
      if _ARG_1_ == U2.Started then
        _ARG_0_:_OnClientPreTeleportSeqStarted(_ARG_2_)
      elseif _ARG_1_ == U2.Skipped then
        _ARG_0_:_OnClientPreTeleportSeqSkipped(_ARG_2_)
      else
        print(bWriteLog and string.format(table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 128, 28, 22, 220, 56, 224, 88, 203, 225, 74, 239, 0, 190, 55, 230, 9),
          U1(48, 127, 140, 55, 90, 40, 134, 56, 144, 12, 5, 207, 40, 236, 116, 236, 180, 88, 245, 8, 191, 20, 240, 25, 183, 85, 68, 223, 51, 249, 105, 246, 243, 84, 160, 32, 175, 23, 251, 30),
          U1(16, 78, 153, 34, 79, 103, 201, 108, 230, 26)
        }), tostring(_ARG_1_)))
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Client_PlayPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_, _ARG_9_, _ARG_10_, _ARG_11_, _ARG_12_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 144, 21, 13, 207, 51, 230, 88, 201, 232, 91, 249, 34, 184, 2, 192, 9),
        U1(8, 127, 144, 61, 88, 51, 167, 41, 178, 28, 17, 212, 46, 231, 55, 202, 251, 68, 246, 11, 189, 62, 224, 92, 238, 89, 65, 217, 113, 178, 84, 252, 246, 83, 225, 30, 234, 90, 180, 73),
        U1(23, 54, 192, 26, 75, 52, 164, 32, 162, 16, 32, 200, 44, 236, 100, 239, 251, 88, 253, 66, 231, 87, 161, 15, 255, 89, 48, 203, 47, 245, 98, 237, 200, 85, 227, 82, 247, 71, 188, 73),
        U1(23, 54, 192, 119, 89, 107, 212, 105, 176, 64)
      }), tostring(_ARG_1_), tostring(_ARG_2_), tostring(_ARG_3_), tostring(_ARG_10_), tostring(_ARG_11_), tostring(_ARG_12_)))
      if _ARG_3_ == 1 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShouldSkipPreTeleportSequence"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) or _ARG_1_.SkipOnLowDevice ~= true then
        return false
      end
      do return require((U1(7, 117, 141, 63, 69, 41, 218, 8, 166, 31, 29, 217, 40, 215, 99, 224, 248, 89))).GetDeviceLevel() ~= nil and require((U1(7, 117, 141, 63, 69, 41, 218, 8, 166, 31, 29, 217, 40, 215, 99, 224, 248, 89))).GetDeviceLevel() <= require((U1(7, 117, 141, 63, 69, 41, 218, 8, 166, 31, 29, 217, 40, 215, 99, 224, 248, 89))).ENum_DeviceLevel.Low end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InternalTeleport"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      print(bWriteLog and table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 147, 25, 240, 25, 161, 23, 5, 198, 9, 247, 107, 252, 244, 85, 242, 6, 234, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 4, 155, 34, 165, 0, 19, 243, 41, 162)
      }) .. tostring(_ARG_3_))
      if not _ARG_0_:CheckPawn(_ARG_0_.Owner.Object) then
        return false
      end
      if _ARG_0_:IsPawnOnVehicle() then
        return false
      end
      if _ARG_0_:IterateTargetLocation(_ARG_1_, function(_ARG_0_)
        do
          if _ENV and U1:LineTraceHit(U2, _ARG_0_) then
            return false, U3.LineTrace
          end
          if U4.Game:TeleportPawn(U5, _ARG_0_, U6, false, true, false, false, U7, U8) then
            return true
          else
            return false, U3.TeleportPawn
          end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end) then
        _ARG_0_.LocationBeforeTeleport = _ARG_0_.Owner:K2_GetActorLocation()
        if _ARG_0_.Config and _ARG_0_.Config.ParachuteTeleport == true then
        else
        end
        if _ARG_0_.Owner.Object.PlayerUID then
        end
      else
      end
      do return (_ARG_0_:IterateTargetLocation(_ARG_1_, function(_ARG_0_)
        do
          if _ENV and U1:LineTraceHit(U2, _ARG_0_) then
            return false, U3.LineTrace
          end
          if U4.Game:TeleportPawn(U5, _ARG_0_, U6, false, true, false, false, U7, U8) then
            return true
          else
            return false, U3.TeleportPawn
          end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckPawn"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return false
      end
      if not slua.isValid(_ARG_1_) then
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 31, 225, 31, 184, 41, 5, 221, 51, 178, 114, 201, 229, 77, 238, 82, 163, 20, 180, 2),
          U1(11, 110, 192, 36, 75, 43, 157, 40)
        }))))
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLineTraceEnabled"] = function(_ARG_0_, _ARG_1_)
    do
      if not (_ARG_1_ and _ARG_1_.TestLocation) or _ARG_1_.TestLocation.LineTraceEnabled == nil then
        return true
      end
      do return _ARG_1_.TestLocation.LineTraceEnabled end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IterateTargetLocation"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_(_ARG_1_) then
        return true
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_2_(_ARG_1_ + FVector(U2[U1(10, 58, 172, 61, 73, 38, 128, 37, 172, 7, 84, 135, 109, 167, 100, 165, 180, 108, 241, 11, 182, 18, 224, 46, 182, 24, 23, 197, 51, 178, 58, 185, 161, 73)].X * _ARG_1_:ToString(), U2[U1(10, 58, 172, 61, 73, 38, 128, 37, 172, 7, 84, 135, 109, 167, 100, 165, 180, 108, 241, 11, 182, 18, 224, 46, 182, 24, 23, 197, 51, 178, 58, 185, 161, 73)].Y * _ARG_1_:ToString(), U1(10, 58, 172, 61, 73, 38, 128, 37, 172, 7, 84, 135, 109, 167, 100, 165, 180, 108, 241, 11, 182, 18, 224, 46, 182, 24, 23, 197, 51, 178, 58, 185, 161, 73)) * (_ARG_0_.Config and _ARG_0_.Config.TestLocation and _ARG_0_.Config.TestLocation.OffsetValue or 100)) then
        return true
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LineTraceHit"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.TraceActorsToIgnore then
        _ARG_0_.TraceActorsToIgnore = slua.Array(UEnums.EPropertyClass.Object, (import((U1(75, 73, 131, 32, 67, 55, 128, 99, 134, 7, 19, 211, 35, 231, 57, 200, 247, 94, 255, 16)))))
      end
      do return import((U1(47, 115, 147, 63, 79, 51, 167, 53, 176, 29, 17, 215, 1, 235, 117, 251, 245, 88, 233))).LineTraceSingle(_ARG_0_.Owner.Object, _ARG_1_, _ARG_2_, 0, true, _ARG_0_.TraceActorsToIgnore, import((U1(33, 94, 146, 51, 93, 3, 145, 46, 182, 14, 32, 200, 44, 225, 114))).None, import((U1(75, 73, 131, 32, 67, 55, 128, 99, 134, 7, 19, 211, 35, 231, 57, 193, 253, 94, 194, 7, 169, 2, 232, 8)))(), true, FLinearColor.Red, FLinearColor.Green, 1) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ForceHolsterBeforeParachuteJump"] = function(_ARG_0_, _ARG_1_)
    do
      if Client or not slua.isValid(_ARG_1_) then
        return
      end
      if not slua.isValid(_ARG_1_.GetWeaponManager and _ARG_1_:GetWeaponManager()) then
        return
      end
      if (_ARG_1_.GetWeaponManager and _ARG_1_:GetWeaponManager()).bIsSwitching == true then
      end
      if (_ARG_1_.GetWeaponManager and _ARG_1_:GetWeaponManager()):GetCurrentUsingPropSlot() ~= import((U1(33, 73, 149, 32, 92, 46, 130, 41, 148, 12, 21, 202, 34, 236, 71, 251, 251, 90, 195, 14, 181, 3))).SWPS_None then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ParachuteJump"] = function(_ARG_0_)
    do
      if _ARG_0_.Owner then
        print(bWriteLog and U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 138, 22, 246, 29, 176, 17, 17, 222, 56, 216, 114, 244, 244, 26, 211, 6, 171, 21, 224))
        _ARG_0_:_ForceHolsterBeforeParachuteJump(_ARG_0_.Owner.Object)
        if slua.isValid((_ARG_0_.Owner:GetControllerSafety())) then
          if not _ARG_0_.Owner:GetEnsure() then
            if _ARG_0_.Owner:GetControllerSafety():GetCurrentStateType() ~= import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteJump and _ARG_0_.Owner:GetControllerSafety():GetCurrentStateType() ~= import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteOpen then
              if _ARG_0_.Config and _ARG_0_.Config.OpenParachuteAfterTeleport == true then
              else
              end
            end
          else
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreTeleport"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      _ARG_0_.Config = _ARG_0_:GetConfig(_ARG_1_)
      if _ARG_0_.Config and _ARG_0_.Config.StopAllSkillsOnTeleport == true then
      end
      if _ARG_0_.Owner.PoseState == U3.Crouch or _ARG_0_.Owner.PoseState == U3.Prone then
      end
      if _ARG_0_.Owner.PoseState == U3.GunADS then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetConfig"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229))) then
        return
      end
      if not GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_] then
        return
      end
      if GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_].HideAllUI == nil then
        GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_].HideAllUI = true
      end
      do return GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostTeleport"] = function(_ARG_0_)
    do
      _ARG_0_:CheckTLog()
      _ARG_0_:StartWaitingClientLoading()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckTLog"] = function(_ARG_0_)
    do
      if not _ARG_0_.Config then
        return
      end
      if not SubsystemMgr:Get((U1(32, 73, 163, 61, 71, 42, 155, 34, 151, 37, 27, 221, 30, 247, 117, 250, 237, 89, 228, 7, 183))) then
        return
      end
      if _ARG_0_.Config.GameTLogId and _ARG_0_.Config.GameTLogId ~= 0 then
      end
      if _ARG_0_.Config.PlayerTLogId and _ARG_0_.Config.PlayerTLogId ~= 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientTeleportStartCallback"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not (_ARG_1_ and _ARG_0_.Owner) or not Client then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientTeleportCallback"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not (_ARG_1_ and _ARG_0_.Owner) or not Client then
        return
      end
      _ARG_0_.Config = _ARG_0_:GetConfig(_ARG_5_)
      if not _ARG_0_.Config then
        return
      end
      if _ARG_0_.PreTeleportPawnDrivenByShow == true and _ARG_0_.PreTeleportShowFinished ~= true then
      else
      end
      _ARG_0_.PreTeleportClientLanded = true
      if _ARG_0_:CheckLoading(_ARG_2_, _ARG_0_.Config) then
      else
      end
      if _ARG_0_.Config and _ARG_0_.Config.AudioOnPreTeleport then
        if _ARG_0_.Config.AudioOnPreTeleport2D then
          if _ARG_0_:IsAutonomousProxy() then
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = _ENV[245]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetPreTeleportSequencePaths"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) then
        return nil, nil, nil
      end
      if not _ARG_1_.LevelSequenceActorPath or _ARG_1_.LevelSequenceActorPath == U1() then
      end
      if _ARG_1_.BindPlayerPawnName and _ARG_1_.BindPlayerPawnName ~= U1() and _ARG_1_.BindLocalPlayerPawn ~= true and (not _ARG_1_.ShowPawnActorPath or _ARG_1_.ShowPawnActorPath == U1()) then
      end
      do return _ARG_1_.LevelSequencePath, U2.LevelSequenceActorPath, U2.ShowPawnActorPath end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not Client or not _ARG_0_:IsLocal() then
        return false
      end
      if not (_ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) and _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) ~= U1() and _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_)) or _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) == U1() then
        return false
      end
      if _ARG_1_.BindPlayerPawnName and _ARG_1_.BindPlayerPawnName ~= U1() and _ARG_1_.BindLocalPlayerPawn ~= true and (not _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) or _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) == U1()) then
        return false
      end
      _ARG_0_.PreTeleportSeqOnFailed = _ARG_2_
      _ARG_0_.PreTeleportSeqOnStarted = _ARG_3_
      if _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) then
      end
      _ARG_0_.PreTeleportSeqLoadHandle = _ARG_0_:AsyncLoadAssetArray({
        _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_)
      }, function()
        PreTeleportSeqLoadHandle = nil
        if not (U1 == PreTeleportSeqSerial and Owner) or not U2.slua.isValid(Owner.Object) then
          return
        end
        if U3 then
          if not _ENV:_SpawnPreTeleportShowPawn(U3, U4, U1, function()
            _ENV:_StartPreTeleportSequence(U1, U2, U3, U4, U5, U6)
            return
          end) then
          end
        else
          _ENV:_StartPreTeleportSequence(U5, U6, U7, U1, nil, nil)
        end
        return
      end)
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_NotifyPreTeleportSeqFailed"] = function(_ARG_0_)
    do
      _ARG_0_.PreTeleportSeqOnStarted = nil
      _ARG_0_.PreTeleportSeqOnFailed = nil
      if _ARG_0_.PreTeleportSeqOnFailed then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_NotifyPreTeleportSeqStarted"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 57, 235, 8, 186, 31, 29, 250, 47, 247, 83, 252, 232, 95, 240, 29, 184, 19, 199, 9),
        U1(21, 73, 148, 51, 88, 51, 145, 40, 227, 58, 0, 219, 63, 246, 71, 229, 245, 83)
      }))
      _ARG_0_.PreTeleportSeqOnStarted = nil
      _ARG_0_.PreTeleportSeqOnFailed = nil
      if _ARG_0_.PreTeleportSeqOnStarted then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SpawnPreTeleportShowPawn"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not slua.loadClass(_ARG_1_) or not slua.isValid(CGameWorld) then
        return false
      end
      if not _ARG_0_.Owner or not slua.isValid(_ARG_0_.Owner.Object) then
        return false
      end
      if not slua.isValid((CGameWorld:SpawnActor(slua.loadClass(_ARG_1_), _ARG_0_.Owner:K2_GetActorLocation(), _ARG_0_.Owner:K2_GetActorRotation(), nil))) then
        return false
      end
      if not slua.isValid(CGameWorld:SpawnActor(slua.loadClass(_ARG_1_), _ARG_0_.Owner:K2_GetActorLocation(), _ARG_0_.Owner:K2_GetActorRotation(), nil).CharacterAvatarComp2_BP) then
        return false
      end
      _ARG_0_.PreTeleportShowPawn = CGameWorld:SpawnActor(slua.loadClass(_ARG_1_), _ARG_0_.Owner:K2_GetActorLocation(), _ARG_0_.Owner:K2_GetActorRotation(), nil)
      _ARG_0_.PreTeleportSeqAvatarTimer = _ARG_0_:AddGameTimer(U2.AvatarLoadTimeout, false, function()
        PreTeleportSeqAvatarTimer = nil
        U1.print(U1.bWriteLog and U1.table.concat({
          U2(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 36, 244, 29, 164, 23, 52, 216, 56, 198, 98, 245, 225, 74, 239, 0, 190, 52, 252, 3),
          U2(19, 74, 129, 37, 68, 103, 149, 58, 162, 29, 21, 200, 109, 238, 120, 232, 240, 10, 228, 11, 183, 18, 235, 9, 167, 85, 68, 218, 49, 243, 126, 185, 229, 84, 249, 5, 171, 30)
        }))
        U3()
        return
      end)
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_StartPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if _ARG_1_.BindPlayerPawnName then
        if _ARG_1_.BindLocalPlayerPawn == true then
          _ARG_0_.PreTeleportPawnDrivenByShow = true
        else
        end
      end
      if _ARG_1_.DisablePlayerPawnSpawnTrack == true and _ARG_1_.BindPlayerPawnName and _ARG_1_.BindPlayerPawnName ~= U1() then
      end
      if not slua.isValid((Game:PlayLevelSequence(_ARG_0_.Owner and _ARG_0_.Owner.Object, _ARG_2_, _ARG_5_ or import((U1(47, 115, 147, 63, 79, 51, 185, 45, 183, 1, 56, 211, 47, 240, 118, 251, 237))).MakeTransform(_ARG_1_.Location or FVector(0, 0, 0), _ARG_1_.Rotation or FRotator(0, 0, 0), FVector(1, 1, 1)), _ARG_3_, true, {
        [_ARG_1_.BindPlayerPawnName] = _ARG_0_.PreTeleportShowPawn
      }, _ARG_0_.Owner and _ARG_0_.Owner.Object, {
        _ARG_1_.BindPlayerPawnName
      }))) then
        return
      end
      _ARG_0_.PreTeleportSeqActor = Game:PlayLevelSequence(_ARG_0_.Owner and _ARG_0_.Owner.Object, _ARG_2_, _ARG_5_ or import((U1(47, 115, 147, 63, 79, 51, 185, 45, 183, 1, 56, 211, 47, 240, 118, 251, 237))).MakeTransform(_ARG_1_.Location or FVector(0, 0, 0), _ARG_1_.Rotation or FRotator(0, 0, 0), FVector(1, 1, 1)), _ARG_3_, true, {
        [_ARG_1_.BindPlayerPawnName] = _ARG_0_.PreTeleportShowPawn
      }, _ARG_0_.Owner and _ARG_0_.Owner.Object, {
        _ARG_1_.BindPlayerPawnName
      })
      do return end
      _ARG_2_ = _ENV[161]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnPreTeleportSequenceEnd"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ ~= _ARG_0_.PreTeleportSeqSerial then
        return
      end
      print(bWriteLog and table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 56, 234, 44, 161, 28, 48, 207, 49, 247, 119, 246, 246, 78, 211, 23, 187, 18, 241, 2),
        U1(7, 127, 165, 60, 78)
      }))
      _ARG_0_.PreTeleportSeqActor = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopPreTeleportSequence"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
        _ARG_0_.PreTeleportSeqOnFailed = nil
      end
      _ARG_0_.PreTeleportSeqOnStarted = nil
      _ARG_0_.PreTeleportPawnDrivenByShow = nil
      _ARG_0_.PreTeleportSeqSerial = (_ARG_0_.PreTeleportSeqSerial or 0) + 1
      if _ARG_0_.PreTeleportSeqLoadHandle then
        _ARG_0_:CancelAsyncLoad(_ARG_0_.PreTeleportSeqLoadHandle)
        _ARG_0_.PreTeleportSeqLoadHandle = nil
      end
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 233, 40, 243, 86, 255, 245, 94, 241, 16, 142, 30, 233, 25, 161)))
      _ARG_0_.PreTeleportSeqActor = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnPreTeleportSeqPlayStarted"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 142, 30, 233, 25, 161)))
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 158, 18, 232, 29, 170, 45, 13, 199, 56, 224)))
      _ARG_0_:_ReleasePreTeleportLevelHold()
      _ARG_0_.PreTeleportShowFinished = nil
      _ARG_0_.PreTeleportClientLanded = nil
      if _ARG_1_.HoldStreamingAtTarget == true and _ARG_3_ then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(44, 117, 140, 54, 121, 51, 134, 41, 162, 4, 29, 212, 42, 195, 99, 221, 245, 88, 247, 7, 174, 51, 225, 16, 178, 0))) then
          _ARG_0_.PreTeleportLevelHoldDelayTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(44, 117, 140, 54, 121, 51, 134, 41, 162, 4, 29, 212, 42, 195, 99, 221, 245, 88, 247, 7, 174, 51, 225, 16, 178, 0))), false, function()
            PreTeleportLevelHoldDelayTimer = nil
            _ENV:_ArmPreTeleportLevelHold(U1, U2)
            return
          end)
        else
        end
      end
      if _ARG_1_.HidePlayerPawnDuringSequence == true and U1.slua.isValid(_ARG_2_) then
        _ARG_0_.PreTeleportPawnHidden = true
        _ARG_0_:SetPlayerCharacterHiddenInGame(_ARG_2_, true)
      end
      if _ARG_1_.BindLocalPlayerPawn == true and U1.slua.isValid(_ARG_2_) then
        _ARG_0_:_SetPreTeleportControllerRotationDisabled(_ARG_2_, true)
      end
      if _ARG_1_.DisableMovementDuringSequence == true and U1.slua.isValid(_ARG_2_) then
        _ARG_0_:_DetachBeCarriedBackForSequence(_ARG_2_)
        _ARG_0_:_SetPreTeleportMovementDisabled(_ARG_2_, true)
        _ARG_0_:_SetPreTeleportMoveInputIgnored(true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ArmPreTeleportLevelHold"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.PreTeleportLevelHeld or _ARG_0_.PreTeleportShowFinished or _ARG_0_.PreTeleportClientLanded then
        return
      end
      if _ARG_2_ ~= nil and _ARG_2_ ~= _ARG_0_.PreTeleportSeqSerial then
        return
      end
      if not SubsystemMgr:Get((U1(40, 127, 150, 55, 70, 20, 128, 62, 166, 8, 25, 211, 35, 229, 90, 238, 230))) then
        return
      end
      _ARG_0_.PreTeleportLevelHeld = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[1]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_DetachBeCarriedBackForSequence"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_1_.IsInBeCarriedBackState or not _ARG_1_:IsInBeCarriedBackState() then
        return
      end
      if slua.isValid(_ARG_1_.GetCarryBackComp and _ARG_1_:GetCarryBackComp() or nil) and (_ARG_1_.GetCarryBackComp and _ARG_1_:GetCarryBackComp() or nil).StopBeCarriedBack then
        if not _ARG_1_:IsInBeCarriedBackState() then
          return
        end
      end
      if not slua.isValid(_ARG_1_.RootComponent) or not slua.isValid(_ARG_1_.RootComponent:GetAttachParent()) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportMovementDisabled"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_ and _ARG_1_.STCharacterMovement) then
        return
      end
      if _ARG_2_ then
        if _ARG_0_.PreTeleportMovementMode ~= nil then
          return
        end
        _ARG_0_.PreTeleportMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).MovementMode
        _ARG_0_.PreTeleportCustomMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).CustomMovementMode
        _ARG_0_.PreTeleportMovementTickEnabled = (_ARG_1_ and _ARG_1_.STCharacterMovement):IsComponentTickEnabled()
        if _ARG_0_.PreTeleportMovementMode == U1 then
          _ARG_0_.PreTeleportMovementMode = U2
          _ARG_0_.PreTeleportCustomMovementMode = 0
          _ARG_0_.PreTeleportMovementTickEnabled = true
        end
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          _ARG_0_.PreTeleportMoveableSaved = (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).bMoveable
        end
        _ARG_0_.PreTeleportMovementGuardTimer = _ARG_0_:AddGameTimer(0.1, true, function()
          if PreTeleportMovementMode == nil then
            return
          end
          if not U1.slua.isValid(U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil) then
            return
          end
          if (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil):IsComponentTickEnabled() or (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil).MovementMode ~= U2 then
          end
          return
        end)
      else
        _ARG_0_.PreTeleportMovementMode = nil
        _ARG_0_.PreTeleportCustomMovementMode = nil
        _ARG_0_.PreTeleportMovementTickEnabled = nil
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) and _ARG_0_.PreTeleportMoveableSaved ~= nil then
          _ARG_0_.PreTeleportMoveableSaved = nil
        end
        if _ARG_0_.PreTeleportMovementMode ~= nil then
          if _ARG_1_.bDead ~= true then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnOwnerExitState"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not Client or _ARG_2_ ~= U1.BeCarriedBack or _ARG_0_.PreTeleportMovementMode == nil then
        return
      end
      if not slua.isValid(slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) and (_ARG_0_.Owner and _ARG_0_.Owner.Object).STCharacterMovement or nil) then
        return
      end
      if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
        if _ARG_0_.PreTeleportMoveableSaved == nil then
          _ARG_0_.PreTeleportMoveableSaved = (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).bMoveable
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1[88]
    end
  end,
  ["_SetPreTeleportControllerRotationDisabled"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_2_ then
        if _ARG_0_.PreTeleportControllerRotationSaved then
          return
        end
        _ARG_0_.PreTeleportControllerRotationSaved = {
          Yaw = _ARG_1_.bUseControllerRotationYaw,
          Pitch = _ARG_1_.bUseControllerRotationPitch,
          Roll = _ARG_1_.bUseControllerRotationRoll
        }
        _ARG_1_.bUseControllerRotationYaw = false
        _ARG_1_.bUseControllerRotationPitch = false
        _ARG_1_.bUseControllerRotationRoll = false
        print(bWriteLog and table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 36, 225, 8, 131, 11, 1, 254, 56, 254, 98, 233, 235, 72, 244, 49, 165, 9, 224, 30),
          U1(11, 118, 140, 55, 88, 21, 155, 56, 162, 29, 29, 213, 35, 198, 126, 250, 245, 72, 252, 7, 190, 87, 224, 21, 160, 24, 6, 198, 56, 246)
        }))
      else
        if not _ARG_0_.PreTeleportControllerRotationSaved then
          return
        end
        _ARG_0_.PreTeleportControllerRotationSaved = nil
        _ARG_1_.bUseControllerRotationYaw = _ARG_0_.PreTeleportControllerRotationSaved.Yaw
        _ARG_1_.bUseControllerRotationPitch = _ARG_0_.PreTeleportControllerRotationSaved.Pitch
        _ARG_1_.bUseControllerRotationRoll = _ARG_0_.PreTeleportControllerRotationSaved.Roll
        if _ARG_1_:K2_GetActorRotation().Pitch ~= 0 or _ARG_1_:K2_GetActorRotation().Roll ~= 0 then
        end
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) and (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()):GetControlRotation().Roll ~= 0 then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ApplyPreTeleportClientShowState"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client or type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) then
        return
      end
      _ARG_0_.PreTeleportActiveSeqConfig = _ARG_1_
      if not _ARG_0_.Owner then
        return
      end
      if not slua.isValid(_ARG_0_.Owner.Object) then
        return
      end
      if not _ARG_0_.Owner:IsLocallyControlled() then
        return
      end
      if _ARG_1_.ExitScopeOnSequence == true then
      end
      if _ARG_1_.ForceTPPDuringSequence == true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportClientShowState"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      _ARG_0_.PreTeleportActiveSeqConfig = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportForceTPP"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ then
        if _ARG_0_.PreTeleportForceTPPApplied or not slua.isValid(_ARG_1_) then
          return
        end
        _ARG_0_.PreTeleportForceTPPApplied = true
        if _ARG_1_:GetIsFPP() then
          _ARG_1_.bForceChangePersonPerspective = true
          _ARG_0_.PreTeleportChangedPP = true
        end
        _ARG_0_.PreTeleportSwitchPPWasDisabled = _ARG_1_:IsPawnStateDisabled(U1.SwitchPP)
        return
      end
      if not _ARG_0_.PreTeleportForceTPPApplied then
        return
      end
      _ARG_0_.PreTeleportForceTPPApplied = nil
      _ARG_0_.PreTeleportChangedPP = nil
      _ARG_0_.PreTeleportSwitchPPWasDisabled = nil
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_0_.PreTeleportSwitchPPWasDisabled then
      end
      if _ARG_0_.PreTeleportChangedPP then
        if _ARG_1_.bDead ~= true then
        end
        _ARG_1_.bForceChangePersonPerspective = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportMoveInputIgnored"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      if _ARG_1_ then
        if _ARG_0_.PreTeleportMoveInputIgnored then
          return
        end
        if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          return
        end
        _ARG_0_.PreTeleportMoveInputPC, _ARG_0_.PreTeleportMoveInputIgnored = _ARG_0_.Owner and _ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety(), true
      else
        if not _ARG_0_.PreTeleportMoveInputIgnored then
          return
        end
        _ARG_0_.PreTeleportMoveInputIgnored = nil
        _ARG_0_.PreTeleportMoveInputPC = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportMovement"] = function(_ARG_0_)
    do
      _ARG_0_:_SetPreTeleportMoveInputIgnored(false)
      if _ARG_0_.PreTeleportMovementMode == nil then
        return
      end
      if slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
      else
        _ARG_0_.PreTeleportMovementMode = nil
        _ARG_0_.PreTeleportCustomMovementMode = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_StopPreTeleportSeqShowHandling"] = function(_ARG_0_)
    do
      _ARG_0_.PreTeleportShowFinished = true
      _ARG_0_.PreTeleportPawnDrivenByShow = nil
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 158, 18, 232, 29, 170, 45, 13, 199, 56, 224)))
      _ARG_0_:_RestorePreTeleportPawnVisibility()
      _ARG_0_:_RestorePreTeleportMovement()
      _ARG_0_:_SetPreTeleportControllerRotationDisabled(_ARG_0_.Owner and _ARG_0_.Owner.Object, false)
      _ARG_0_:_RestorePreTeleportClientShowState()
      if not _ARG_0_.PreTeleportLevelHeld then
        return
      end
      if _ARG_0_.PreTeleportClientLanded then
        _ARG_0_:_ReleasePreTeleportLevelHold()
        return
      end
      if not _ARG_0_.PreTeleportLevelHoldTimer then
        _ARG_0_.PreTeleportLevelHoldTimer = _ARG_0_:AddGameTimer(U1.HoldReleaseTimeout, false, function()
          PreTeleportLevelHoldTimer = nil
          _ENV:_ReleasePreTeleportLevelHold()
          return
        end)
        U2.print(U2.bWriteLog and U2.table.concat({
          _ENV(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 36, 240, 19, 163, 41, 22, 207, 9, 247, 107, 252, 244, 85, 242, 6, 153, 2, 229, 63),
          _ENV(12, 117, 151, 26, 75, 41, 144, 32, 170, 7, 19, 154, 58, 227, 126, 253, 180, 76, 255, 16, 250, 27, 229, 18, 183, 16, 10, 205, 125, 240, 98, 255, 235, 72, 229, 82, 184, 2, 248, 9),
          _ENV(5, 105, 137, 60, 77, 103, 156, 35, 175, 13)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ReleasePreTeleportLevelHold"] = function(_ARG_0_)
    do
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 158, 18, 232, 29, 170, 45, 13, 199, 56, 224)))
      if not _ARG_0_.PreTeleportLevelHeld then
        return
      end
      _ARG_0_.PreTeleportLevelHeld = nil
      _ARG_0_.PreTeleportShowFinished = nil
      _ARG_0_.PreTeleportClientLanded = nil
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 142, 30, 233, 25, 161)))
      if U1.SubsystemMgr:Get((_ENV(40, 127, 150, 55, 70, 20, 128, 62, 166, 8, 25, 211, 35, 229, 90, 238, 230))) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[147]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportPawnVisibility"] = function(_ARG_0_)
    do
      if not _ARG_0_.PreTeleportPawnHidden then
        return
      end
      _ARG_0_.PreTeleportPawnHidden = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_DestroyPreTeleportShowPawn"] = function(_ARG_0_)
    do
      _ARG_0_.PreTeleportShowPawn = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSimulatedAndNotSpectating"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_1_:IsSimulated() and not (U1.slua.isValid((GetPlayerController())) and GetPlayerController():IsInSpectating()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPlayerCharacterHiddenInGame"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ then
        _ARG_1_:SetActorHiddenInGame(true)
      elseif not _ARG_1_.CharacterHide or not _ARG_1_.CharacterHide.bCharacterHideIngame then
        _ARG_1_:SetActorHiddenInGame(false)
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 137, 18, 240, 44, 191, 24, 29, 207, 47, 209, 111, 248, 246, 91, 227, 6, 175, 21, 220, 5),
        U1(0, 126, 133, 60, 99, 41, 179, 45, 174, 12, 84, 159, 62, 162, 63, 172, 231, 3)
      }), _ARG_2_, _ARG_1_:ToString()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckLoading"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.Owner:IsAutonomousProxy() then
      elseif Client and slua.isValid((U1.GetPlayerController())) and U1.GetPlayerController():IsSpectator() and slua.isValid(U1.GetPlayerController():GetCurPlayerCharacter()) and U1.GetPlayerController():GetCurPlayerCharacter().PlayerKey == _ARG_0_.Owner.PlayerKey then
      end
      if not (SubsystemMgr:Get((U2(40, 127, 150, 55, 70, 20, 128, 62, 166, 8, 25, 211, 35, 229, 90, 238, 230))) and true) or _ARG_2_.NotShowLoading then
        return false
      end
      if _ARG_2_ and _ARG_2_.SkipLoadingUI == true then
      end
      if _ARG_0_.LoadingEffectReason == nil then
      end
      do return true end
      do return end
      _ARG_1_ = U1[147]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartWaitingClientLoading"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 137, 3, 229, 14, 167, 46, 5, 195, 41, 251, 105, 254, 199, 86, 233, 23, 164, 19, 216, 3),
        U1(5, 126, 137, 60, 77, 103, 209, 63)
      }), _ARG_0_.Owner:ToString()))
      _ARG_0_.WaitingClientLoadingTimer = _ARG_0_:AddGameTimer(U2, false, function()
        print(bWriteLog and string.format(table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 137, 3, 229, 14, 167, 46, 5, 195, 41, 251, 105, 254, 199, 86, 233, 23, 164, 19, 216, 3),
          U1(5, 126, 137, 60, 77, 103, 163, 45, 170, 29, 29, 212, 42, 193, 123, 224, 241, 68, 228, 46, 181, 22, 224, 21, 189, 30, 48, 195, 48, 247, 117, 185, 240, 83, 237, 23, 165, 18, 224, 76),
          U1(65, 105)
        }), U2.Owner:ToString()))
        U2:OnReceiveClientTeleportLoadingFinish()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLevelStreamingLoadEnd"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 200, 25, 165, 28, 8, 249, 41, 224, 98, 248, 233, 83, 238, 21, 134, 8, 245, 8),
        U1(33, 116, 132, 114, 15, 52)
      }), _ARG_3_))
      _ARG_0_:RemoveCommonEvent(EVENTTYPE_LEVELSTREAMING, EVENTID_LEVELSTREAMING_LOAD_END)
      if _ARG_0_.Config then
        _ARG_0_:OnClientLanded()
      end
      _ARG_0_:RPC_Server_NotifyTeleportLoadingFinish()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Server_NotifyTeleportLoadingFinish"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 128, 28, 22, 220, 56, 224, 88, 215, 235, 78, 233, 20, 179, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 11, 155, 45, 167, 0, 26, 221, 11, 235, 121, 224, 231, 66, 176, 71, 169)
      }), _ARG_0_.Owner:ToString()))
      _ARG_0_:OnReceiveClientTeleportLoadingFinish()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnReceiveClientTeleportLoadingFinish"] = function(_ARG_0_)
    do
      if not _ARG_0_.WaitingClientLoadingTimer then
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 214, 25, 176, 28, 13, 220, 56, 209, 107, 240, 225, 84, 244, 38, 175, 11, 241, 28),
          U1(11, 104, 148, 30, 69, 38, 144, 37, 173, 14, 50, 211, 35, 235, 100, 225, 180, 68, 255, 66, 141, 22, 237, 8, 186, 23, 3, 233, 49, 251, 98, 247, 240, 118, 239, 19, 174, 14, 250, 11),
          U1(48, 115, 141, 55, 88, 107, 212, 62, 166, 29, 1, 200, 35)
        }))))
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 214, 25, 176, 28, 13, 220, 56, 209, 107, 240, 225, 84, 244, 38, 175, 11, 241, 28),
        U1(11, 104, 148, 30, 69, 38, 144, 37, 173, 14, 50, 211, 35, 235, 100, 225, 180, 15, 227)
      }), _ARG_0_.Owner:ToString()))
      _ARG_0_:TryRemoveNamedGameTimer((U1(51, 123, 137, 38, 67, 41, 147, 15, 175, 0, 17, 212, 57, 206, 120, 232, 240, 67, 254, 5, 142, 30, 233, 25, 161)))
      _ARG_0_.LuaDelegate:Broadcast(U2, _ARG_0_.Owner)
      _ARG_0_.LuaDelegate:Remove(U2)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ListenOnClientTeleportLoadingFinished"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.LuaDelegate:Add(_ENV, _ARG_1_, _ARG_2_)
      do return _ARG_0_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientPreCheckLoadingEffect"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 27, 237, 25, 189, 13, 52, 216, 56, 209, 111, 252, 231, 81, 204, 29, 171, 3, 253, 2),
        U1(3, 95, 134, 52, 79, 36, 128, 108, 230, 26)
      }), _ARG_1_))
      if _ARG_0_.MarkTeleportFailed then
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 27, 237, 25, 189, 13, 52, 216, 56, 209, 111, 252, 231, 81, 204, 29, 171, 3, 253, 2),
          U1(3, 95, 134, 52, 79, 36, 128, 108, 169, 28, 7, 206, 109, 207, 118, 251, 255, 126, 245, 14, 191, 7, 235, 14, 167, 63, 5, 195, 49, 247, 99, 181, 164, 72, 229, 6, 191, 21, 250)
        }))))
        return
      end
      if _ARG_0_.LoadingEffectReason == nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckLoadingEffect"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:IsLocal() then
        return
      end
      if not _ARG_1_ or not _ARG_1_.LoadingEffect then
        return
      end
      if not _ARG_1_.LoadingEffect.Type or not _ARG_1_.LoadingEffect.Param then
        return
      end
      _ARG_0_.LoadingEffectReason = _ARG_2_
      if _ARG_1_.LoadingEffect.Type == U1(55, 121, 146, 55, 79, 41, 177, 42, 165, 12, 23, 206) then
        if slua.isValid((slua.loadObject(_ARG_1_.LoadingEffect.Param .. U1(59, 89)))) then
          _ARG_0_.LoadingEffectObject = import((U1(55, 121, 146, 55, 79, 41, 181, 60, 179, 12, 21, 200, 44, 236, 116, 236, 199, 94, 241, 22, 179, 20, 247))).PlayDynamicScreenAppearance(_ARG_0_.Owner.Object, _ARG_0_.Owner.Object, import((U1(55, 78, 165, 42, 94, 53, 149, 11, 162, 4, 17, 202, 33, 227, 110, 218, 224, 75, 228, 11, 185, 4))).GetClassDefaultObject((slua.loadObject(_ARG_1_.LoadingEffect.Param .. U1(59, 89)))).AppearanceName, (slua.loadObject(_ARG_1_.LoadingEffect.Param .. U1(59, 89))))
        end
      elseif _ARG_1_.LoadingEffect.Type == U1(49, 83) and UIManager.UI_Config_InGame[_ARG_1_.LoadingEffect.Param] then
        _ARG_0_.LoadingEffectObject = UIManager.ShowUI(UIManager.UI_Config_InGame[_ARG_1_.LoadingEffect.Param])
      end
      if _ARG_0_.LoadingEffectObject then
        _ARG_0_.StartLoadingEffectTime = U3.GetRealTimeSeconds(_ARG_0_.Owner.Object)
        _ARG_0_.LoadingEffectObjectTimeoutTimer = _ARG_0_:AddGameTimer(U2, false, function()
          print(bWriteLog and string.format((table.concat({
            U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 31, 225, 31, 184, 53, 11, 203, 57, 251, 105, 254, 193, 92, 230, 23, 169, 19, 180, 24),
            U1(13, 119, 133, 61, 95, 51)
          }))))
          U2:TryDestroyLoadingEffect()
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[61]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientLanded"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 199, 16, 186, 28, 10, 222, 17, 243, 105, 253, 225, 94))
      if not (_ARG_0_.Config and Client) or not _ARG_0_.Owner then
        return
      end
      if slua.isValid((_ARG_0_.Owner:GetControllerSafety())) and not _ARG_0_.Owner.bEnsure then
        _ARG_0_.Owner:GetControllerSafety().bAutoSprint = false
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryDestroyLoadingEffect"] = function(_ARG_0_)
    do
      if not _ARG_0_:IsLocal() then
        return
      end
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(40, 117, 129, 54, 67, 41, 147, 9, 165, 15, 17, 217, 57, 205, 117, 227, 241, 73, 228, 54, 179, 26, 225, 19, 166, 13, 48, 195, 48, 247, 117)))
      if _ARG_0_.Config and _ARG_0_.Config.LoadingEffect and _ARG_0_.Config.LoadingEffect.NoDestroy then
        _ARG_0_:ClearLoadingEffectObject()
      elseif _ARG_0_.LoadingEffectObject then
        if _ARG_0_.LoadingEffectObject.End and not _ARG_0_.LoadingEffectObject.bHasClosed then
        elseif _ARG_0_.LoadingEffectObject.SetLifeSpan then
          if _ARG_0_.StartLoadingEffectTime and 1 > U1.GetRealTimeSeconds(_ARG_0_.Owner.Object) - _ARG_0_.StartLoadingEffectTime then
          else
          end
        else
        end
      end
      _ARG_0_.LoadingEffectReason = nil
      if _ARG_0_.Config and _ARG_0_.Config.HideAllUI then
        _ARG_0_:TryRemoveNamedGameTimer((_ENV(44, 115, 132, 55, 107, 43, 152, 25, 138, 61, 29, 215, 40, 237, 98, 253, 192, 67, 253, 7, 168)))
        _ARG_0_.HideAllUITimeoutTimer = _ARG_0_:AddGameTimer(2, false, function()
          print(bWriteLog and string.format((table.concat({
            U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 142, 5, 253, 56, 182, 10, 16, 216, 50, 235, 75, 246, 229, 94, 233, 28, 173, 34, 242, 10),
            U1(1, 121, 148, 114, 98, 46, 144, 41, 130, 5, 24, 239, 4, 214, 126, 228, 241, 69, 229, 22)
          }))))
          EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_EXIT_TEAM_SHOW)
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearLoadingEffectObject"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format((table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 27, 225, 29, 161, 53, 11, 203, 57, 251, 105, 254, 193, 92, 230, 23, 169, 19, 219, 14),
        U1(14, 127, 131, 38)
      }))))
      if _ARG_0_.Config and _ARG_0_.Config.AudioOnPreTeleportLoop and _ARG_0_.AudioOnPreTeleportID then
        _ARG_0_.AudioOnPreTeleportID = nil
      end
      _ARG_0_.LoadingEffectObject = nil
      _ARG_0_:CheckHideAllUI(false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckHideAllUI"] = function(_ARG_0_, _ARG_1_)
    do
      if not (Client and _ARG_0_:IsLocal() and _ARG_0_.Config) or not _ARG_0_.Config.HideAllUI then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 31, 225, 31, 184, 49, 13, 206, 56, 211, 107, 245, 209, 115, 160, 16, 130, 14, 240, 9),
        U1(68, 39, 192, 119, 89)
      }), _ARG_1_))
      if _ARG_1_ then
        EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_ENTER_TEAM_SHOW)
      else
        EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_EXIT_TEAM_SHOW)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Client_NotifyTeleportFailed"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 144, 21, 13, 207, 51, 230, 88, 215, 235, 78, 233, 20, 179, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 1, 149, 37, 175, 12, 16, 150, 109, 206, 120, 232, 240, 67, 254, 5, 159, 17, 226, 25, 176, 13, 54, 207, 60, 225, 104, 247, 164, 7, 160, 87, 185)
      }), _ARG_0_.LoadingEffectReason))
      _ARG_0_:StopPreTeleportSequence(true)
      _ARG_0_:_ReleasePreTeleportLevelHold()
      _ARG_0_:TryDestroyLoadingEffect()
      _ARG_0_.MarkTeleportFailed = true
      _ARG_0_:AddGameTimer(0.1, false, function()
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 144, 21, 13, 207, 51, 230, 88, 215, 235, 78, 233, 20, 179, 51, 241, 0),
          U1(1, 106, 143, 32, 94, 1, 149, 37, 175, 12, 16, 150, 109, 207, 118, 251, 255, 126, 245, 14, 191, 7, 235, 14, 167, 63, 5, 195, 49, 247, 99, 185, 185, 26, 238, 27, 166)
        }))))
        U2.MarkTeleportFailed = nil
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsLocal"] = function(_ARG_0_)
    do
      if not _ARG_0_.Owner then
        return false
      end
      do return (not _ARG_0_.Owner.IsLocallyControlled or not _ARG_0_.Owner:IsLocallyControlled()) and _ARG_0_.Owner.IsLocalViewed and _ARG_0_.Owner:IsLocalViewed() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}).ServerRPC.RPC_Server_NotifyTeleportLoadingFinish = {
  Reliable = true,
  Params = {}
}
;({
  ServerRPC = {},
  ClientRPC = {},
  ["_PostConstruct"] = function(_ARG_0_)
    do
      __super._PostConstruct(_ARG_0_)
      _ARG_0_.LuaDelegate = U1.LuaDelegate()
      _ARG_0_.bPreTeleportHiddenOnOthers = false
      _ARG_0_.PreTeleportDamageBlocked = false
      _ARG_0_.PreTeleportAllowedDamageTypes = nil
      _ARG_0_.PreTeleportDamageBlockExpireAt = 0
      _ARG_0_.bPreTeleportDamageEventBound = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLifetimeReplicatedProps"] = function(_ARG_0_)
    do
      do return {
        {
          U2(6, 74, 146, 55, 126, 34, 152, 41, 179, 6, 6, 206, 5, 235, 115, 237, 241, 68, 223, 12, 149, 3, 236, 25, 161, 10),
          U1.import((U2(33, 86, 137, 52, 79, 51, 157, 33, 166, 42, 27, 212, 41, 235, 99, 224, 251, 68))).COND_None,
          U1.UEnums.EPropertyClass.Bool
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveBeginPlay"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format((U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 18, 231, 25, 186, 15, 1, 232, 56, 245, 110, 247, 212, 86, 225, 11))))
      U2.__super.ReceiveBeginPlay(_ARG_0_)
      if not _ARG_0_.Owner then
        return
      end
      if not slua.isValid(_ARG_0_.Owner.Object) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckPreload"] = function(_ARG_0_)
    do
      if not _ARG_0_.Owner then
        return
      end
      if not _ARG_0_.Owner:IsLocallyControlled() and not _ARG_0_.Owner:IsLocalViewed() then
        return
      end
      if _ARG_0_.PreloadAssets then
        return
      end
      _ARG_0_.PreloadAssets = {}
      if U2.GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229))) then
        goto lbl_155
        ::lbl_155::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveEndPlay"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.LuaDelegate then
        _ARG_0_.LuaDelegate:Dispose()
      end
      if Client then
        _ARG_0_:StopPreTeleportSequence(true)
        _ARG_0_:_RestorePreTeleportPawnVisibility()
        _ARG_0_:_RestorePreTeleportMovement()
        _ARG_0_:_ReleasePreTeleportLevelHold()
        _ARG_0_:_RestorePreTeleportHiddenOnThisClient()
        _ARG_0_.PreloadAssets = nil
        _ARG_0_:TryRemoveNamedGameTimer((U1(32, 127, 140, 51, 83, 4, 152, 35, 176, 12, 56, 213, 44, 230, 126, 231, 243, 111, 246, 4, 191, 20, 240, 41, 154, 45, 13, 199, 56, 224)))
      else
        _ARG_0_:TryRemoveNamedGameTimer((U1(52, 127, 142, 54, 67, 41, 147, 28, 177, 12, 32, 223, 33, 231, 103, 230, 230, 94, 196, 11, 183, 18, 246)))
        _ARG_0_.PendingPreTeleport = nil
        _ARG_0_:_SetPendingTeleportMovementFrozen(_ARG_0_.Owner and _ARG_0_.Owner.Object, false)
        _ARG_0_:_ReleasePreTeleportServerShowState()
      end
      U2.__super.ReceiveEndPlay(_ARG_0_, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoteTeleportPawnByTable"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_1_.BornPos and #_ARG_1_.BornPos > 0 then
        if 10 < _ARG_2_ then
          print(bWriteLog and table.concat({
            U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 18, 233, 19, 167, 28, 48, 207, 49, 247, 119, 246, 246, 78, 208, 19, 189, 9, 214, 21),
            U1(48, 123, 130, 62, 79, 107, 212, 24, 166, 5, 17, 202, 34, 240, 99, 217, 245, 93, 254, 66, 151, 24, 246, 25, 243, 45, 12, 203, 51, 178, 115, 252, 234, 0, 160)
          }) .. tostring(_ARG_0_.Owner.PlayerKey))
          return
        end
        if not _ARG_0_:RemoteTeleportPawn(_ARG_1_.BornPos[math.random(1, #_ARG_1_.BornPos)].Location, _ARG_1_.BornPos[math.random(1, #_ARG_1_.BornPos)].Roatation, _ARG_3_, _ARG_4_) then
          _ARG_2_ = _ARG_2_ + 1
        end
      end
      do return end
      _ARG_1_ = U1.tostring
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoteTeleportPawn"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not Client and _ARG_0_.Owner then
        if Game:TeleportPawn(_ARG_0_.Owner.Object, _ARG_1_, _ARG_2_, false, true, false, false, _ARG_3_, _ARG_4_) then
          if _ARG_3_ == import((U1(33, 78, 133, 62, 79, 55, 155, 62, 183, 57, 21, 205, 35, 214, 110, 249, 241))).ParachuteTeleport then
          elseif _ARG_3_ == import((U1(33, 78, 133, 62, 79, 55, 155, 62, 183, 57, 21, 205, 35, 214, 110, 249, 241))).RemoteTeleport then
          end
          if _ARG_4_ and _ARG_0_:GetConfig(_ARG_4_) and _ARG_0_:GetConfig(_ARG_4_).GameTLogId and SubsystemMgr:Get((U1(32, 73, 163, 61, 71, 42, 155, 34, 151, 37, 27, 221, 30, 247, 117, 250, 237, 89, 228, 7, 183))) then
          end
        end
        return (Game:TeleportPawn(_ARG_0_.Owner.Object, _ARG_1_, _ARG_2_, false, true, false, false, _ARG_3_, _ARG_4_))
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1[252]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInTeleportState"] = function(_ARG_0_)
    do
      if _ARG_0_.PreTeleportActiveSeqConfig ~= nil or _ARG_0_.PreTeleportSeqActor ~= nil or _ARG_0_.LoadingEffectReason ~= nil or _ARG_0_.PreTeleportLevelHeld == true then
      end
      do return _ARG_0_.PreTeleportActiveSeqConfig ~= nil or _ARG_0_.PreTeleportSeqActor ~= nil or _ARG_0_.LoadingEffectReason ~= nil or _ARG_0_.PreTeleportLevelHeld == true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPawnAttached"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return false
      end
      if not slua.isValid((_ARG_0_.Owner and _ARG_0_.Owner.Object).RootComponent) then
        return false
      end
      do return slua.isValid((_ARG_0_.Owner and _ARG_0_.Owner.Object).RootComponent:GetAttachParent()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPawnOnVehicle"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return false
      end
      do return (_ARG_0_.Owner and _ARG_0_.Owner.Object):HasState(U1.InVehicle) or (_ARG_0_.Owner and _ARG_0_.Owner.Object):HasState(U1.DriveVehicle) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoteTeleport"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_0_:IsPawnOnVehicle() then
        print(bWriteLog and string.format(table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 18, 233, 19, 167, 28, 48, 207, 49, 247, 119, 246, 246, 78, 160, 0, 175, 1, 225, 31),
          U1(1, 126, 204, 114, 90, 38, 131, 34, 227, 6, 26, 154, 59, 231, 127, 224, 247, 70, 245, 78, 250, 39, 232, 29, 170, 28, 22, 225, 56, 235, 39, 164, 164, 31, 243, 94, 234, 36, 251, 2),
          U1(2, 115, 135, 27, 78, 103, 201, 108, 230, 26)
        }), tostring(_ARG_0_.Owner.PlayerKey), tostring(_ARG_3_)))
        return false
      end
      if _ARG_0_:IsPawnAttached() then
        return false
      end
      if _ARG_0_:_TryDeferTeleportForPreSequence(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport, _ARG_4_) then
        return true, (_ARG_0_:_TryCancelCarryBackForTeleport(_ARG_3_))
      end
      if not _ARG_0_:InternalTeleport(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport) then
        return (_ARG_0_:InternalTeleport(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport))
      end
      do return _ARG_0_:InternalTeleport(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport), (_ARG_0_:_TryCancelCarryBackForTeleport(_ARG_3_)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_TryCancelCarryBackForTeleport"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return nil
      end
      if not _ARG_0_:GetConfig(_ARG_1_) or _ARG_0_:GetConfig(_ARG_1_).CancelCarryBackOnTeleport ~= true then
        return nil
      end
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) or not (_ARG_0_.Owner and _ARG_0_.Owner.Object).IsInCarryBackState then
        return nil
      end
      if (_ARG_0_.Owner and _ARG_0_.Owner.Object):IsInCarryBackState() then
      elseif (_ARG_0_.Owner and _ARG_0_.Owner.Object):IsInBeCarriedBackState() then
        if slua.isValid(((_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCarryBackCharacter())) then
        end
      else
        return nil
      end
      do return slua.isValid(((_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCarryBackCharacter())) and (_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCarryBackCharacter() or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_TryDeferTeleportForPreSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if Client then
        return false
      end
      if type(_ARG_0_:GetConfig(_ARG_3_) and _ARG_0_:GetConfig(_ARG_3_).SequenceOnPreTeleport) ~= U1(16, 123, 130, 62, 79) then
        return false
      end
      if not slua.isValid(_ARG_0_.Owner.Object) or _ARG_0_.Owner.bEnsure or not Game:IsPlayer(_ARG_0_.Owner.Object) then
        return false
      end
      if not slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
        return false
      end
      if _ARG_0_.PendingPreTeleport then
        return true
      end
      _ARG_0_.PendingPreTeleportSerial = (_ARG_0_.PendingPreTeleportSerial or 0) + 1
      _ARG_0_.PendingPreTeleport = {
        Location = _ARG_1_,
        Rotation = _ARG_2_,
        ConfigId = _ARG_3_,
        Type = _ARG_4_,
        Serial = _ARG_0_.PendingPreTeleportSerial,
        bStarted = false
      }
      _ARG_0_.PendingPreTeleportTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_3_) and _ARG_0_:GetConfig(_ARG_3_).SequenceOnPreTeleport, (U1(55, 127, 146, 36, 79, 53, 163, 45, 170, 29, 32, 211, 32, 231, 120, 252, 224))), false, function()
        PendingPreTeleportTimer = nil
        _ENV:_ExecutePendingPreTeleport(U1, (U2(48, 115, 141, 55, 69, 50, 128)))
        return
      end)
      if (_ARG_0_:GetConfig(_ARG_3_) and _ARG_0_:GetConfig(_ARG_3_).SequenceOnPreTeleport).DisableMovementDuringSequence == true then
      end
      if _ARG_5_ then
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetPreTeleportSeqConfigValue"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return type(_ARG_1_) == U1(16, 123, 130, 62, 79) and tonumber(_ARG_1_[_ARG_2_]) or nil or tonumber(U2[_ARG_2_]) or 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnClientPreTeleportSeqStarted"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.PendingPreTeleport or _ARG_0_.PendingPreTeleport.Serial ~= _ARG_1_ then
        return
      end
      if _ARG_0_.PendingPreTeleport.bStarted then
        return
      end
      _ARG_0_.PendingPreTeleport.bStarted = true
      if type(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport) == U1(16, 123, 130, 62, 79) and (_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport).HidePawnOnOtherClientsDuringSequence == true then
        _ARG_0_.bPreTeleportHiddenOnOthers = true
      end
      if 0 >= _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) then
      end
      if 0 >= _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) - _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(48, 127, 140, 55, 90, 40, 134, 56, 130, 1, 17, 219, 41, 214, 126, 228, 241))) then
        return
      end
      _ARG_0_.PendingPreTeleportTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) - _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(48, 127, 140, 55, 90, 40, 134, 56, 130, 1, 17, 219, 41, 214, 126, 228, 241))), false, function()
        PendingPreTeleportTimer = nil
        _ENV:_ExecutePendingPreTeleport(U1, (U2(37, 114, 133, 51, 78, 8, 146, 31, 166, 24, 1, 223, 35, 225, 114, 204, 250, 78)))
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[84]
    end
  end,
  ["_OnClientPreTeleportSeqSkipped"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.PendingPreTeleport or _ARG_0_.PendingPreTeleport.Serial ~= _ARG_1_ then
        return
      end
      if _ARG_0_.PendingPreTeleport.bStarted then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ExecutePendingPreTeleport"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.PendingPreTeleport or _ARG_0_.PendingPreTeleport.Serial ~= _ARG_1_ then
        return
      end
      _ARG_0_.PendingPreTeleport = nil
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if _ARG_0_.Owner.bDead == true then
        return
      end
      if not _ARG_0_:InternalTeleport(_ARG_0_.PendingPreTeleport.Location, _ARG_0_.PendingPreTeleport.Rotation, _ARG_0_.PendingPreTeleport.ConfigId, _ARG_0_.PendingPreTeleport.Type) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CancelPendingPreTeleport"] = function(_ARG_0_, _ARG_1_)
    do
      if Client or not _ARG_0_.PendingPreTeleport then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 52, 229, 18, 176, 28, 8, 250, 56, 252, 99, 240, 234, 93, 208, 0, 175, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 103, 164, 32, 162, 16, 17, 200, 6, 231, 110, 169, 169, 10, 181, 17, 246, 87, 215, 25, 161, 16, 5, 198, 125, 175, 39, 188, 247, 22, 160, 32, 175, 6, 231, 3),
        U1(10, 58, 221, 114, 15, 52)
      }), tostring(_ARG_0_.Owner and _ARG_0_.Owner.PlayerKey), tostring(_ARG_0_.PendingPreTeleport.Serial), tostring(_ARG_1_)))
      _ARG_0_.PendingPreTeleport = nil
      _ARG_0_:TryRemoveNamedGameTimer((U1(52, 127, 142, 54, 67, 41, 147, 28, 177, 12, 32, 223, 33, 231, 103, 230, 230, 94, 196, 11, 183, 18, 246)))
      _ARG_0_:_SetPendingTeleportMovementFrozen(_ARG_0_.Owner and _ARG_0_.Owner.Object, false)
      _ARG_0_:_ReleasePreTeleportServerShowState()
      _ARG_0_:RPC_Client_NotifyTeleportFailed()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnOwnerDeath"] = function(_ARG_0_)
    do
      if not Client then
        if not _ARG_0_.PendingPreTeleport then
          return
        end
        if type(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport) == U1(16, 123, 130, 62, 79) and (_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport).CancelTeleportOnDeath == true then
        end
        return
      end
      if type(_ARG_0_.PreTeleportActiveSeqConfig) ~= U1(16, 123, 130, 62, 79) or _ARG_0_.PreTeleportActiveSeqConfig.CancelTeleportOnDeath ~= true then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPendingTeleportMovementFrozen"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      if _ARG_2_ then
        if not slua.isValid(_ARG_1_ and _ARG_1_.STCharacterMovement) or _ARG_0_.PendingTeleportMovementMode ~= nil then
          return
        end
        _ARG_0_.PendingTeleportMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).MovementMode
        _ARG_0_.PendingTeleportCustomMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).CustomMovementMode
        _ARG_0_.PendingTeleportMovementActive = (_ARG_1_ and _ARG_1_.STCharacterMovement):IsActive()
        _ARG_0_.PendingTeleportMovementTickEnabled = (_ARG_1_ and _ARG_1_.STCharacterMovement):IsComponentTickEnabled()
        if _ARG_0_.PendingTeleportMovementMode == U1 then
          _ARG_0_.PendingTeleportMovementMode = U2
          _ARG_0_.PendingTeleportCustomMovementMode = 0
          _ARG_0_.PendingTeleportMovementActive = true
          _ARG_0_.PendingTeleportMovementTickEnabled = true
        end
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          _ARG_0_.PendingTeleportMoveableSaved = (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).bMoveable
        end
        _ARG_0_.PendingTeleportMovementGuardTimer = _ARG_0_:AddGameTimer(0.1, true, function()
          if PendingTeleportMovementMode == nil then
            return
          end
          if not U1.slua.isValid(U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil) then
            return
          end
          if (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil):IsActive() or (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil):IsComponentTickEnabled() or (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil).MovementMode ~= U2 then
          end
          return
        end)
        return
      end
      if _ARG_0_.PendingTeleportMovementMode == nil then
        return
      end
      _ARG_0_.PendingTeleportMovementMode = nil
      _ARG_0_.PendingTeleportCustomMovementMode = nil
      _ARG_0_.PendingTeleportMovementActive = nil
      _ARG_0_.PendingTeleportMovementTickEnabled = nil
      if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) and _ARG_0_.PendingTeleportMoveableSaved ~= nil then
        _ARG_0_.PendingTeleportMoveableSaved = nil
      end
      if slua.isValid(_ARG_1_ and _ARG_1_.STCharacterMovement) then
        if _ARG_1_.bDead ~= true then
        end
        if _ARG_0_.PendingTeleportMovementActive == false then
        end
      end
      do return end
      _ARG_0_ = _ENV[87]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ResolvePreTeleportForbiddenStates"] = function(_ARG_0_, _ARG_1_)
    do
      if (type(_ARG_1_) == U1(16, 123, 130, 62, 79) and _ARG_1_.ForbiddenPawnStatesDuringSequence or nil) == true then
      end
      if type(U2) ~= U1(16, 123, 130, 62, 79) then
        return nil
      end
      goto lbl_158
      if type(62) == U1(23, 110, 146, 59, 68, 32) then
      end
      if U3[62] ~= nil and U3[62] ~= U3.Dying and U3[62] ~= U3.Dead then
      else
      end
      ::lbl_158::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportPawnStatesDisabled"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ then
        if _ARG_0_.PreTeleportDisabledPawnStates or not slua.isValid(_ARG_1_) then
          return
        end
        if not _ARG_0_:_ResolvePreTeleportForbiddenStates(_ARG_2_) or #_ARG_0_:_ResolvePreTeleportForbiddenStates(_ARG_2_) == 0 then
          return
        end
        goto lbl_41
        ::lbl_41::
        _ARG_0_ = _ARG_0_
        _ARG_0_.PreTeleportDisabledPawnStates, _ARG_0_ = {}, _ARG_0_
        return
      end
      _ARG_0_.PreTeleportDisabledPawnStates = nil
      if not _ARG_0_.PreTeleportDisabledPawnStates or not slua.isValid(_ARG_1_) then
        return
      end
      goto lbl_154
      ::lbl_154::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CancelPreTeleportHoldGrenade"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) or not _ARG_1_:HasState(U1.HoldGrenade) then
        return
      end
      print(bWriteLog and table.concat({
        U2(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 52, 229, 18, 176, 28, 8, 250, 47, 247, 83, 252, 232, 95, 240, 29, 184, 19, 220, 3),
        U2(8, 126, 167, 32, 79, 41, 149, 40, 166)
      }))
      if Client then
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          ;(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).TouchEndTriggerSkillID = -1
        end
      end
      _ARG_1_:TriggerCustomEvent(U3.PlayerRequestCancel, -1)
      if Client then
        EventSystem:postEvent(EVENTTYPE_INGAME_SHOOTINGUI_PANEL, EVENTID_ON_THROW_CANCEL_BUTTON_CLICK)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportGrenadePredictLine"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if not _ARG_0_.Owner.IsLocallyControlled or not _ARG_0_.Owner:IsLocallyControlled() then
        return
      end
      if not slua.isValid(((_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCurrentWeapon())) or not (_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCurrentWeapon().EnableWeaponPredictLine then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PreparePreTeleportLocomotion"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_.DisableMovementDuringSequence == true and _ARG_2_.StopAllSkillsOnSequence == true and slua.isValid((_ARG_1_:GetPlayerControllerSafety())) and (_ARG_1_:GetPlayerControllerSafety():GetCurrentStateType() == import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteJump or _ARG_1_:GetPlayerControllerSafety():GetCurrentStateType() == import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteOpen) then
        if not Client and _ARG_1_:GetPlayerControllerSafety():GetCurrentStateType() == import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteOpen and _ARG_1_:GetPlayerControllerSafety().GetStateMachineCompent and slua.isValid((_ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent())) and _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState and _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill == true then
          _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill = false
        end
        if Client then
        else
        end
        if slua.isValid(_ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState) and _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill == true then
          _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill = true
        end
      end
      if _ARG_2_.StopAllSkillsOnSequence == true then
        if Client then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ApplyPreTeleportServerShowState"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not (not Client and slua.isValid(_ARG_1_)) or type(_ARG_2_) ~= U1(16, 123, 130, 62, 79) then
        return
      end
      _ARG_0_:_ReleasePreTeleportServerShowState()
      _ARG_0_:_PreparePreTeleportLocomotion(_ARG_1_, _ARG_2_)
      if _ARG_2_.ExitScopeOnSequence == true then
        _ARG_1_:ScopeInterrupt(U2.Normal)
      end
      _ARG_0_:_SetPreTeleportPawnStatesDisabled(_ARG_1_, _ARG_2_, true)
      _ARG_0_:_AddPreTeleportDamageBlock(_ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ResolvePreTeleportAllowedDamageTypes"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_.AllowedDamageTypesDuringSequence) ~= U1(16, 123, 130, 62, 79) then
      end
      goto lbl_193
      if type(62) == U1(10, 111, 141, 48, 79, 53) and 62 or type(62) == U1(23, 110, 146, 59, 68, 32) and import((U1(33, 94, 129, 63, 75, 32, 145, 24, 186, 25, 17)))[62] or nil then
      else
      end
      ::lbl_193::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {
        [type(62) == U1(10, 111, 141, 48, 79, 53) and 62 or type(62) == U1(23, 110, 146, 59, 68, 32) and import((U1(33, 94, 129, 63, 75, 32, 145, 24, 186, 25, 17)))[62] or nil] = true
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetPreTeleportDamageBlockMaxDuration"] = function(_ARG_0_, _ARG_1_)
    do
      if (U1.type(_ARG_1_) == _ENV(16, 123, 130, 62, 79) and U1.tonumber(_ARG_1_.DamageBlockMaxDuration) or nil) and 0 < (U1.type(_ARG_1_) == _ENV(16, 123, 130, 62, 79) and U1.tonumber(_ARG_1_.DamageBlockMaxDuration) or nil) then
        return U1.type(_ARG_1_) == _ENV(16, 123, 130, 62, 79) and U1.tonumber(_ARG_1_.DamageBlockMaxDuration) or nil
      end
      do return _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(55, 127, 146, 36, 79, 53, 163, 45, 170, 29, 32, 211, 32, 231, 120, 252, 224))) + _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) + _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 9, 227, 122, 232, 243, 79, 210, 14, 181, 20, 239, 52, 188, 21, 0, 254, 52, 255, 98))) + 10 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_AddPreTeleportDamageBlock"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) or _ARG_1_.BlockDamageDuringSequence ~= true then
        return
      end
      _ARG_0_:_RemovePreTeleportDamageBlock()
      _ARG_0_.PreTeleportAllowedDamageTypes = _ARG_0_:_ResolvePreTeleportAllowedDamageTypes(_ARG_1_)
      _ARG_0_.PreTeleportDamageBlocked = true
      _ARG_0_.PreTeleportDamageBlockExpireAt = (slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) and U2.GetRealTimeSeconds(_ARG_0_.Owner and _ARG_0_.Owner.Object) or 0) + _ARG_0_:_GetPreTeleportDamageBlockMaxDuration(_ARG_1_)
      _ARG_0_.PreTeleportDamageBlockSafetyTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportDamageBlockMaxDuration(_ARG_1_), false, function()
        PreTeleportDamageBlockSafetyTimer = nil
        if PreTeleportDamageBlocked then
          U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
            U2(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 54, 224, 24, 131, 11, 1, 254, 56, 254, 98, 233, 235, 72, 244, 54, 171, 10, 245, 11),
            U2(1, 88, 140, 61, 73, 44, 212, 63, 162, 15, 17, 206, 52, 162, 99, 224, 249, 79, 255, 23, 174, 87, 161, 15, 243, 10, 72, 138, 59, 253, 117, 250, 225, 26, 242, 23, 166, 2, 245, 31),
            U2(1, 54, 192, 2, 70, 38, 141, 41, 177, 34, 17, 195, 109, 191, 55, 172, 231)
          }), U1.tostring(U3), U1.tostring(Owner and Owner.PlayerKey)))
          _ENV:_RemovePreTeleportDamageBlock()
        end
        return
      end)
      if not _ARG_0_.bPreTeleportDamageEventBound then
        _ARG_0_.bPreTeleportDamageEventBound = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RemovePreTeleportDamageBlock"] = function(_ARG_0_)
    do
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 254, 44, 239, 118, 238, 241, 104, 252, 13, 185, 28, 208, 21, 190, 28, 22)))
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 254, 44, 239, 118, 238, 241, 104, 252, 13, 185, 28, 215, 29, 181, 28, 16, 211, 9, 251, 106, 252, 246)))
      _ARG_0_.PreTeleportDamageBlockSafetyTimer = nil
      _ARG_0_.PreTeleportDamageBlockExpireAt = 0
      if not _ARG_0_.PreTeleportDamageBlocked then
        return
      end
      _ARG_0_.PreTeleportDamageBlocked = false
      _ARG_0_.PreTeleportAllowedDamageTypes = nil
      if _ARG_0_.bPreTeleportDamageEventBound then
        _ARG_0_.bPreTeleportDamageEventBound = false
        _ARG_0_:RemoveCommonEvent(U1.EVENTTYPE_INGAME_NORMAL, U1.EVENTID_PRE_TAKE_DAMAGE)
      end
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        _ENV(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 37, 225, 17, 188, 15, 1, 250, 47, 247, 83, 252, 232, 95, 240, 29, 184, 19, 208, 13),
        _ENV(9, 123, 135, 55, 104, 43, 155, 47, 168, 73, 36, 214, 44, 251, 114, 251, 223, 79, 233, 66, 231, 87, 161, 15)
      }), U1.tostring(_ARG_0_.Owner and _ARG_0_.Owner.PlayerKey)))
      return
    end
  end,
  ["HandlePreTeleportPreTakeDamage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not (not Client and _ARG_0_.PreTeleportDamageBlocked) or not slua.isValid(_ARG_3_) then
        return
      end
      if not slua.isValid(_ARG_3_.Target) then
        return
      end
      if not (_ARG_3_.Target.PlayerKey and _ARG_0_.Owner) or _ARG_3_.Target.PlayerKey ~= _ARG_0_.Owner.PlayerKey then
        return
      end
      if slua.isValid(_ARG_0_.Owner.Object) and _ARG_0_.PreTeleportDamageBlockExpireAt > 0 and U1.GetRealTimeSeconds(_ARG_0_.Owner.Object) > _ARG_0_.PreTeleportDamageBlockExpireAt then
        return
      end
      if _ARG_0_.PreTeleportAllowedDamageTypes and _ARG_0_.PreTeleportAllowedDamageTypes[_ARG_3_.DamageType] then
        return
      end
      _ARG_3_.Damage = 0
      do return end
      _ARG_1_ = _ENV[12]
    end
  end,
  ["_ScheduleReleasePreTeleportServerShowState"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if _ARG_0_.PreTeleportDamageBlocked then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 9, 227, 122, 232, 243, 79, 210, 14, 181, 20, 239, 52, 188, 21, 0, 254, 52, 255, 98))) then
          _ARG_0_.PreTeleportDamageBlockTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 9, 227, 122, 232, 243, 79, 210, 14, 181, 20, 239, 52, 188, 21, 0, 254, 52, 255, 98))), false, function()
            PreTeleportDamageBlockTimer = nil
            _ENV:_RemovePreTeleportDamageBlock()
            return
          end)
        else
        end
      end
      if _ARG_0_.bPreTeleportHiddenOnOthers then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(55, 114, 143, 37, 122, 38, 131, 34, 140, 7, 59, 206, 37, 231, 101, 250, 208, 79, 252, 3, 163))) then
          _ARG_0_.PreTeleportShowOnOthersTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(55, 114, 143, 37, 122, 38, 131, 34, 140, 7, 59, 206, 37, 231, 101, 250, 208, 79, 252, 3, 163))), false, function()
            PreTeleportShowOnOthersTimer = nil
            bPreTeleportHiddenOnOthers = false
            return
          end)
        else
          _ARG_0_.bPreTeleportHiddenOnOthers = false
        end
      end
      if _ARG_0_.PreTeleportDisabledPawnStates then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 30, 246, 118, 253, 241, 98, 255, 14, 190, 35, 237, 17, 182))) then
          _ARG_0_.PreTeleportStateRestoreTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 30, 246, 118, 253, 241, 98, 255, 14, 190, 35, 237, 17, 182))), false, function()
            PreTeleportStateRestoreTimer = nil
            _ENV:_SetPreTeleportPawnStatesDisabled(Owner and Owner.Object, nil, false)
            return
          end)
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ReleasePreTeleportServerShowState"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      _ARG_0_:TryRemoveNamedGameTimer((U1(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 233, 37, 237, 96, 198, 250, 101, 228, 10, 191, 5, 247, 40, 186, 20, 1, 216)))
      _ARG_0_:TryRemoveNamedGameTimer((U1(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 233, 57, 227, 99, 236, 198, 79, 227, 22, 181, 5, 225, 40, 186, 20, 1, 216)))
      if _ARG_0_.bPreTeleportHiddenOnOthers then
        _ARG_0_.bPreTeleportHiddenOnOthers = false
      end
      _ARG_0_:_SetPreTeleportPawnStatesDisabled(_ARG_0_.Owner and _ARG_0_.Owner.Object, nil, false)
      _ARG_0_:_RemovePreTeleportDamageBlock()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_bPreTeleportHiddenOnOthers"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if _ARG_0_.bPreTeleportHiddenOnOthers == true and not _ARG_0_:IsLocal() then
        if not _ARG_0_.PreTeleportHiddenOnThisClient then
          _ARG_0_.PreTeleportHiddenOnThisClient = true
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportHiddenOnThisClient"] = function(_ARG_0_)
    do
      if not _ARG_0_.PreTeleportHiddenOnThisClient then
        return
      end
      _ARG_0_.PreTeleportHiddenOnThisClient = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Server_ReportPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 128, 28, 22, 220, 56, 224, 88, 203, 225, 74, 239, 0, 190, 55, 230, 9),
        U1(48, 127, 140, 55, 90, 40, 134, 56, 144, 12, 5, 207, 40, 236, 116, 236, 180, 122, 252, 3, 163, 18, 246, 55, 182, 0, 68, 151, 125, 183, 116, 181, 164, 104, 229, 2, 165, 21, 224, 56),
        U1(29, 106, 133, 114, 23, 103, 209, 63, 239, 73, 39, 223, 63, 235, 118, 229, 180, 23, 176, 71, 169)
      }), tostring(_ARG_0_.Owner.PlayerKey), tostring(_ARG_1_), tostring(_ARG_2_)))
      if _ARG_1_ == U2.Started then
        _ARG_0_:_OnClientPreTeleportSeqStarted(_ARG_2_)
      elseif _ARG_1_ == U2.Skipped then
        _ARG_0_:_OnClientPreTeleportSeqSkipped(_ARG_2_)
      else
        print(bWriteLog and string.format(table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 128, 28, 22, 220, 56, 224, 88, 203, 225, 74, 239, 0, 190, 55, 230, 9),
          U1(48, 127, 140, 55, 90, 40, 134, 56, 144, 12, 5, 207, 40, 236, 116, 236, 180, 88, 245, 8, 191, 20, 240, 25, 183, 85, 68, 223, 51, 249, 105, 246, 243, 84, 160, 32, 175, 23, 251, 30),
          U1(16, 78, 153, 34, 79, 103, 201, 108, 230, 26)
        }), tostring(_ARG_1_)))
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Client_PlayPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_, _ARG_9_, _ARG_10_, _ARG_11_, _ARG_12_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 144, 21, 13, 207, 51, 230, 88, 201, 232, 91, 249, 34, 184, 2, 192, 9),
        U1(8, 127, 144, 61, 88, 51, 167, 41, 178, 28, 17, 212, 46, 231, 55, 202, 251, 68, 246, 11, 189, 62, 224, 92, 238, 89, 65, 217, 113, 178, 84, 252, 246, 83, 225, 30, 234, 90, 180, 73),
        U1(23, 54, 192, 26, 75, 52, 164, 32, 162, 16, 32, 200, 44, 236, 100, 239, 251, 88, 253, 66, 231, 87, 161, 15, 255, 89, 48, 203, 47, 245, 98, 237, 200, 85, 227, 82, 247, 71, 188, 73),
        U1(23, 54, 192, 119, 89, 107, 212, 105, 176, 64)
      }), tostring(_ARG_1_), tostring(_ARG_2_), tostring(_ARG_3_), tostring(_ARG_10_), tostring(_ARG_11_), tostring(_ARG_12_)))
      if _ARG_3_ == 1 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShouldSkipPreTeleportSequence"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) or _ARG_1_.SkipOnLowDevice ~= true then
        return false
      end
      do return require((U1(7, 117, 141, 63, 69, 41, 218, 8, 166, 31, 29, 217, 40, 215, 99, 224, 248, 89))).GetDeviceLevel() ~= nil and require((U1(7, 117, 141, 63, 69, 41, 218, 8, 166, 31, 29, 217, 40, 215, 99, 224, 248, 89))).GetDeviceLevel() <= require((U1(7, 117, 141, 63, 69, 41, 218, 8, 166, 31, 29, 217, 40, 215, 99, 224, 248, 89))).ENum_DeviceLevel.Low end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InternalTeleport"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      print(bWriteLog and table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 147, 25, 240, 25, 161, 23, 5, 198, 9, 247, 107, 252, 244, 85, 242, 6, 234, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 4, 155, 34, 165, 0, 19, 243, 41, 162)
      }) .. tostring(_ARG_3_))
      if not _ARG_0_:CheckPawn(_ARG_0_.Owner.Object) then
        return false
      end
      if _ARG_0_:IsPawnOnVehicle() then
        return false
      end
      if _ARG_0_:IterateTargetLocation(_ARG_1_, function(_ARG_0_)
        do
          if _ENV and U1:LineTraceHit(U2, _ARG_0_) then
            return false, U3.LineTrace
          end
          if U4.Game:TeleportPawn(U5, _ARG_0_, U6, false, true, false, false, U7, U8) then
            return true
          else
            return false, U3.TeleportPawn
          end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end) then
        _ARG_0_.LocationBeforeTeleport = _ARG_0_.Owner:K2_GetActorLocation()
        if _ARG_0_.Config and _ARG_0_.Config.ParachuteTeleport == true then
        else
        end
        if _ARG_0_.Owner.Object.PlayerUID then
        end
      else
      end
      do return (_ARG_0_:IterateTargetLocation(_ARG_1_, function(_ARG_0_)
        do
          if _ENV and U1:LineTraceHit(U2, _ARG_0_) then
            return false, U3.LineTrace
          end
          if U4.Game:TeleportPawn(U5, _ARG_0_, U6, false, true, false, false, U7, U8) then
            return true
          else
            return false, U3.TeleportPawn
          end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckPawn"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return false
      end
      if not slua.isValid(_ARG_1_) then
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 31, 225, 31, 184, 41, 5, 221, 51, 178, 114, 201, 229, 77, 238, 82, 163, 20, 180, 2),
          U1(11, 110, 192, 36, 75, 43, 157, 40)
        }))))
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLineTraceEnabled"] = function(_ARG_0_, _ARG_1_)
    do
      if not (_ARG_1_ and _ARG_1_.TestLocation) or _ARG_1_.TestLocation.LineTraceEnabled == nil then
        return true
      end
      do return _ARG_1_.TestLocation.LineTraceEnabled end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IterateTargetLocation"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_(_ARG_1_) then
        return true
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_2_(_ARG_1_ + FVector(U2[U1(10, 58, 172, 61, 73, 38, 128, 37, 172, 7, 84, 135, 109, 167, 100, 165, 180, 108, 241, 11, 182, 18, 224, 46, 182, 24, 23, 197, 51, 178, 58, 185, 161, 73)].X * _ARG_1_:ToString(), U2[U1(10, 58, 172, 61, 73, 38, 128, 37, 172, 7, 84, 135, 109, 167, 100, 165, 180, 108, 241, 11, 182, 18, 224, 46, 182, 24, 23, 197, 51, 178, 58, 185, 161, 73)].Y * _ARG_1_:ToString(), U1(10, 58, 172, 61, 73, 38, 128, 37, 172, 7, 84, 135, 109, 167, 100, 165, 180, 108, 241, 11, 182, 18, 224, 46, 182, 24, 23, 197, 51, 178, 58, 185, 161, 73)) * (_ARG_0_.Config and _ARG_0_.Config.TestLocation and _ARG_0_.Config.TestLocation.OffsetValue or 100)) then
        return true
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LineTraceHit"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.TraceActorsToIgnore then
        _ARG_0_.TraceActorsToIgnore = slua.Array(UEnums.EPropertyClass.Object, (import((U1(75, 73, 131, 32, 67, 55, 128, 99, 134, 7, 19, 211, 35, 231, 57, 200, 247, 94, 255, 16)))))
      end
      do return import((U1(47, 115, 147, 63, 79, 51, 167, 53, 176, 29, 17, 215, 1, 235, 117, 251, 245, 88, 233))).LineTraceSingle(_ARG_0_.Owner.Object, _ARG_1_, _ARG_2_, 0, true, _ARG_0_.TraceActorsToIgnore, import((U1(33, 94, 146, 51, 93, 3, 145, 46, 182, 14, 32, 200, 44, 225, 114))).None, import((U1(75, 73, 131, 32, 67, 55, 128, 99, 134, 7, 19, 211, 35, 231, 57, 193, 253, 94, 194, 7, 169, 2, 232, 8)))(), true, FLinearColor.Red, FLinearColor.Green, 1) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ForceHolsterBeforeParachuteJump"] = function(_ARG_0_, _ARG_1_)
    do
      if Client or not slua.isValid(_ARG_1_) then
        return
      end
      if not slua.isValid(_ARG_1_.GetWeaponManager and _ARG_1_:GetWeaponManager()) then
        return
      end
      if (_ARG_1_.GetWeaponManager and _ARG_1_:GetWeaponManager()).bIsSwitching == true then
      end
      if (_ARG_1_.GetWeaponManager and _ARG_1_:GetWeaponManager()):GetCurrentUsingPropSlot() ~= import((U1(33, 73, 149, 32, 92, 46, 130, 41, 148, 12, 21, 202, 34, 236, 71, 251, 251, 90, 195, 14, 181, 3))).SWPS_None then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ParachuteJump"] = function(_ARG_0_)
    do
      if _ARG_0_.Owner then
        print(bWriteLog and U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 138, 22, 246, 29, 176, 17, 17, 222, 56, 216, 114, 244, 244, 26, 211, 6, 171, 21, 224))
        _ARG_0_:_ForceHolsterBeforeParachuteJump(_ARG_0_.Owner.Object)
        if slua.isValid((_ARG_0_.Owner:GetControllerSafety())) then
          if not _ARG_0_.Owner:GetEnsure() then
            if _ARG_0_.Owner:GetControllerSafety():GetCurrentStateType() ~= import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteJump and _ARG_0_.Owner:GetControllerSafety():GetCurrentStateType() ~= import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteOpen then
              if _ARG_0_.Config and _ARG_0_.Config.OpenParachuteAfterTeleport == true then
              else
              end
            end
          else
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreTeleport"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      _ARG_0_.Config = _ARG_0_:GetConfig(_ARG_1_)
      if _ARG_0_.Config and _ARG_0_.Config.StopAllSkillsOnTeleport == true then
      end
      if _ARG_0_.Owner.PoseState == U3.Crouch or _ARG_0_.Owner.PoseState == U3.Prone then
      end
      if _ARG_0_.Owner.PoseState == U3.GunADS then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetConfig"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229))) then
        return
      end
      if not GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_] then
        return
      end
      if GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_].HideAllUI == nil then
        GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_].HideAllUI = true
      end
      do return GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostTeleport"] = function(_ARG_0_)
    do
      _ARG_0_:CheckTLog()
      _ARG_0_:StartWaitingClientLoading()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckTLog"] = function(_ARG_0_)
    do
      if not _ARG_0_.Config then
        return
      end
      if not SubsystemMgr:Get((U1(32, 73, 163, 61, 71, 42, 155, 34, 151, 37, 27, 221, 30, 247, 117, 250, 237, 89, 228, 7, 183))) then
        return
      end
      if _ARG_0_.Config.GameTLogId and _ARG_0_.Config.GameTLogId ~= 0 then
      end
      if _ARG_0_.Config.PlayerTLogId and _ARG_0_.Config.PlayerTLogId ~= 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientTeleportStartCallback"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not (_ARG_1_ and _ARG_0_.Owner) or not Client then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientTeleportCallback"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not (_ARG_1_ and _ARG_0_.Owner) or not Client then
        return
      end
      _ARG_0_.Config = _ARG_0_:GetConfig(_ARG_5_)
      if not _ARG_0_.Config then
        return
      end
      if _ARG_0_.PreTeleportPawnDrivenByShow == true and _ARG_0_.PreTeleportShowFinished ~= true then
      else
      end
      _ARG_0_.PreTeleportClientLanded = true
      if _ARG_0_:CheckLoading(_ARG_2_, _ARG_0_.Config) then
      else
      end
      if _ARG_0_.Config and _ARG_0_.Config.AudioOnPreTeleport then
        if _ARG_0_.Config.AudioOnPreTeleport2D then
          if _ARG_0_:IsAutonomousProxy() then
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = _ENV[245]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetPreTeleportSequencePaths"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) then
        return nil, nil, nil
      end
      if not _ARG_1_.LevelSequenceActorPath or _ARG_1_.LevelSequenceActorPath == U1() then
      end
      if _ARG_1_.BindPlayerPawnName and _ARG_1_.BindPlayerPawnName ~= U1() and _ARG_1_.BindLocalPlayerPawn ~= true and (not _ARG_1_.ShowPawnActorPath or _ARG_1_.ShowPawnActorPath == U1()) then
      end
      do return _ARG_1_.LevelSequencePath, U2.LevelSequenceActorPath, U2.ShowPawnActorPath end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not Client or not _ARG_0_:IsLocal() then
        return false
      end
      if not (_ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) and _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) ~= U1() and _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_)) or _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) == U1() then
        return false
      end
      if _ARG_1_.BindPlayerPawnName and _ARG_1_.BindPlayerPawnName ~= U1() and _ARG_1_.BindLocalPlayerPawn ~= true and (not _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) or _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) == U1()) then
        return false
      end
      _ARG_0_.PreTeleportSeqOnFailed = _ARG_2_
      _ARG_0_.PreTeleportSeqOnStarted = _ARG_3_
      if _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) then
      end
      _ARG_0_.PreTeleportSeqLoadHandle = _ARG_0_:AsyncLoadAssetArray({
        _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_)
      }, function()
        PreTeleportSeqLoadHandle = nil
        if not (U1 == PreTeleportSeqSerial and Owner) or not U2.slua.isValid(Owner.Object) then
          return
        end
        if U3 then
          if not _ENV:_SpawnPreTeleportShowPawn(U3, U4, U1, function()
            _ENV:_StartPreTeleportSequence(U1, U2, U3, U4, U5, U6)
            return
          end) then
          end
        else
          _ENV:_StartPreTeleportSequence(U5, U6, U7, U1, nil, nil)
        end
        return
      end)
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_NotifyPreTeleportSeqFailed"] = function(_ARG_0_)
    do
      _ARG_0_.PreTeleportSeqOnStarted = nil
      _ARG_0_.PreTeleportSeqOnFailed = nil
      if _ARG_0_.PreTeleportSeqOnFailed then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_NotifyPreTeleportSeqStarted"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 57, 235, 8, 186, 31, 29, 250, 47, 247, 83, 252, 232, 95, 240, 29, 184, 19, 199, 9),
        U1(21, 73, 148, 51, 88, 51, 145, 40, 227, 58, 0, 219, 63, 246, 71, 229, 245, 83)
      }))
      _ARG_0_.PreTeleportSeqOnStarted = nil
      _ARG_0_.PreTeleportSeqOnFailed = nil
      if _ARG_0_.PreTeleportSeqOnStarted then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SpawnPreTeleportShowPawn"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not slua.loadClass(_ARG_1_) or not slua.isValid(CGameWorld) then
        return false
      end
      if not _ARG_0_.Owner or not slua.isValid(_ARG_0_.Owner.Object) then
        return false
      end
      if not slua.isValid((CGameWorld:SpawnActor(slua.loadClass(_ARG_1_), _ARG_0_.Owner:K2_GetActorLocation(), _ARG_0_.Owner:K2_GetActorRotation(), nil))) then
        return false
      end
      if not slua.isValid(CGameWorld:SpawnActor(slua.loadClass(_ARG_1_), _ARG_0_.Owner:K2_GetActorLocation(), _ARG_0_.Owner:K2_GetActorRotation(), nil).CharacterAvatarComp2_BP) then
        return false
      end
      _ARG_0_.PreTeleportShowPawn = CGameWorld:SpawnActor(slua.loadClass(_ARG_1_), _ARG_0_.Owner:K2_GetActorLocation(), _ARG_0_.Owner:K2_GetActorRotation(), nil)
      _ARG_0_.PreTeleportSeqAvatarTimer = _ARG_0_:AddGameTimer(U2.AvatarLoadTimeout, false, function()
        PreTeleportSeqAvatarTimer = nil
        U1.print(U1.bWriteLog and U1.table.concat({
          U2(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 36, 244, 29, 164, 23, 52, 216, 56, 198, 98, 245, 225, 74, 239, 0, 190, 52, 252, 3),
          U2(19, 74, 129, 37, 68, 103, 149, 58, 162, 29, 21, 200, 109, 238, 120, 232, 240, 10, 228, 11, 183, 18, 235, 9, 167, 85, 68, 218, 49, 243, 126, 185, 229, 84, 249, 5, 171, 30)
        }))
        U3()
        return
      end)
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_StartPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if _ARG_1_.BindPlayerPawnName then
        if _ARG_1_.BindLocalPlayerPawn == true then
          _ARG_0_.PreTeleportPawnDrivenByShow = true
        else
        end
      end
      if _ARG_1_.DisablePlayerPawnSpawnTrack == true and _ARG_1_.BindPlayerPawnName and _ARG_1_.BindPlayerPawnName ~= U1() then
      end
      if not slua.isValid((Game:PlayLevelSequence(_ARG_0_.Owner and _ARG_0_.Owner.Object, _ARG_2_, _ARG_5_ or import((U1(47, 115, 147, 63, 79, 51, 185, 45, 183, 1, 56, 211, 47, 240, 118, 251, 237))).MakeTransform(_ARG_1_.Location or FVector(0, 0, 0), _ARG_1_.Rotation or FRotator(0, 0, 0), FVector(1, 1, 1)), _ARG_3_, true, {
        [_ARG_1_.BindPlayerPawnName] = _ARG_0_.PreTeleportShowPawn
      }, _ARG_0_.Owner and _ARG_0_.Owner.Object, {
        _ARG_1_.BindPlayerPawnName
      }))) then
        return
      end
      _ARG_0_.PreTeleportSeqActor = Game:PlayLevelSequence(_ARG_0_.Owner and _ARG_0_.Owner.Object, _ARG_2_, _ARG_5_ or import((U1(47, 115, 147, 63, 79, 51, 185, 45, 183, 1, 56, 211, 47, 240, 118, 251, 237))).MakeTransform(_ARG_1_.Location or FVector(0, 0, 0), _ARG_1_.Rotation or FRotator(0, 0, 0), FVector(1, 1, 1)), _ARG_3_, true, {
        [_ARG_1_.BindPlayerPawnName] = _ARG_0_.PreTeleportShowPawn
      }, _ARG_0_.Owner and _ARG_0_.Owner.Object, {
        _ARG_1_.BindPlayerPawnName
      })
      do return end
      _ARG_2_ = _ENV[161]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnPreTeleportSequenceEnd"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ ~= _ARG_0_.PreTeleportSeqSerial then
        return
      end
      print(bWriteLog and table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 56, 234, 44, 161, 28, 48, 207, 49, 247, 119, 246, 246, 78, 211, 23, 187, 18, 241, 2),
        U1(7, 127, 165, 60, 78)
      }))
      _ARG_0_.PreTeleportSeqActor = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopPreTeleportSequence"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
        _ARG_0_.PreTeleportSeqOnFailed = nil
      end
      _ARG_0_.PreTeleportSeqOnStarted = nil
      _ARG_0_.PreTeleportPawnDrivenByShow = nil
      _ARG_0_.PreTeleportSeqSerial = (_ARG_0_.PreTeleportSeqSerial or 0) + 1
      if _ARG_0_.PreTeleportSeqLoadHandle then
        _ARG_0_:CancelAsyncLoad(_ARG_0_.PreTeleportSeqLoadHandle)
        _ARG_0_.PreTeleportSeqLoadHandle = nil
      end
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 233, 40, 243, 86, 255, 245, 94, 241, 16, 142, 30, 233, 25, 161)))
      _ARG_0_.PreTeleportSeqActor = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnPreTeleportSeqPlayStarted"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 142, 30, 233, 25, 161)))
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 158, 18, 232, 29, 170, 45, 13, 199, 56, 224)))
      _ARG_0_:_ReleasePreTeleportLevelHold()
      _ARG_0_.PreTeleportShowFinished = nil
      _ARG_0_.PreTeleportClientLanded = nil
      if _ARG_1_.HoldStreamingAtTarget == true and _ARG_3_ then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(44, 117, 140, 54, 121, 51, 134, 41, 162, 4, 29, 212, 42, 195, 99, 221, 245, 88, 247, 7, 174, 51, 225, 16, 178, 0))) then
          _ARG_0_.PreTeleportLevelHoldDelayTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(44, 117, 140, 54, 121, 51, 134, 41, 162, 4, 29, 212, 42, 195, 99, 221, 245, 88, 247, 7, 174, 51, 225, 16, 178, 0))), false, function()
            PreTeleportLevelHoldDelayTimer = nil
            _ENV:_ArmPreTeleportLevelHold(U1, U2)
            return
          end)
        else
        end
      end
      if _ARG_1_.HidePlayerPawnDuringSequence == true and U1.slua.isValid(_ARG_2_) then
        _ARG_0_.PreTeleportPawnHidden = true
        _ARG_0_:SetPlayerCharacterHiddenInGame(_ARG_2_, true)
      end
      if _ARG_1_.BindLocalPlayerPawn == true and U1.slua.isValid(_ARG_2_) then
        _ARG_0_:_SetPreTeleportControllerRotationDisabled(_ARG_2_, true)
      end
      if _ARG_1_.DisableMovementDuringSequence == true and U1.slua.isValid(_ARG_2_) then
        _ARG_0_:_DetachBeCarriedBackForSequence(_ARG_2_)
        _ARG_0_:_SetPreTeleportMovementDisabled(_ARG_2_, true)
        _ARG_0_:_SetPreTeleportMoveInputIgnored(true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ArmPreTeleportLevelHold"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.PreTeleportLevelHeld or _ARG_0_.PreTeleportShowFinished or _ARG_0_.PreTeleportClientLanded then
        return
      end
      if _ARG_2_ ~= nil and _ARG_2_ ~= _ARG_0_.PreTeleportSeqSerial then
        return
      end
      if not SubsystemMgr:Get((U1(40, 127, 150, 55, 70, 20, 128, 62, 166, 8, 25, 211, 35, 229, 90, 238, 230))) then
        return
      end
      _ARG_0_.PreTeleportLevelHeld = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[1]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_DetachBeCarriedBackForSequence"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_1_.IsInBeCarriedBackState or not _ARG_1_:IsInBeCarriedBackState() then
        return
      end
      if slua.isValid(_ARG_1_.GetCarryBackComp and _ARG_1_:GetCarryBackComp() or nil) and (_ARG_1_.GetCarryBackComp and _ARG_1_:GetCarryBackComp() or nil).StopBeCarriedBack then
        if not _ARG_1_:IsInBeCarriedBackState() then
          return
        end
      end
      if not slua.isValid(_ARG_1_.RootComponent) or not slua.isValid(_ARG_1_.RootComponent:GetAttachParent()) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportMovementDisabled"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_ and _ARG_1_.STCharacterMovement) then
        return
      end
      if _ARG_2_ then
        if _ARG_0_.PreTeleportMovementMode ~= nil then
          return
        end
        _ARG_0_.PreTeleportMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).MovementMode
        _ARG_0_.PreTeleportCustomMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).CustomMovementMode
        _ARG_0_.PreTeleportMovementTickEnabled = (_ARG_1_ and _ARG_1_.STCharacterMovement):IsComponentTickEnabled()
        if _ARG_0_.PreTeleportMovementMode == U1 then
          _ARG_0_.PreTeleportMovementMode = U2
          _ARG_0_.PreTeleportCustomMovementMode = 0
          _ARG_0_.PreTeleportMovementTickEnabled = true
        end
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          _ARG_0_.PreTeleportMoveableSaved = (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).bMoveable
        end
        _ARG_0_.PreTeleportMovementGuardTimer = _ARG_0_:AddGameTimer(0.1, true, function()
          if PreTeleportMovementMode == nil then
            return
          end
          if not U1.slua.isValid(U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil) then
            return
          end
          if (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil):IsComponentTickEnabled() or (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil).MovementMode ~= U2 then
          end
          return
        end)
      else
        _ARG_0_.PreTeleportMovementMode = nil
        _ARG_0_.PreTeleportCustomMovementMode = nil
        _ARG_0_.PreTeleportMovementTickEnabled = nil
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) and _ARG_0_.PreTeleportMoveableSaved ~= nil then
          _ARG_0_.PreTeleportMoveableSaved = nil
        end
        if _ARG_0_.PreTeleportMovementMode ~= nil then
          if _ARG_1_.bDead ~= true then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnOwnerExitState"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not Client or _ARG_2_ ~= U1.BeCarriedBack or _ARG_0_.PreTeleportMovementMode == nil then
        return
      end
      if not slua.isValid(slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) and (_ARG_0_.Owner and _ARG_0_.Owner.Object).STCharacterMovement or nil) then
        return
      end
      if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
        if _ARG_0_.PreTeleportMoveableSaved == nil then
          _ARG_0_.PreTeleportMoveableSaved = (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).bMoveable
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1[88]
    end
  end,
  ["_SetPreTeleportControllerRotationDisabled"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_2_ then
        if _ARG_0_.PreTeleportControllerRotationSaved then
          return
        end
        _ARG_0_.PreTeleportControllerRotationSaved = {
          Yaw = _ARG_1_.bUseControllerRotationYaw,
          Pitch = _ARG_1_.bUseControllerRotationPitch,
          Roll = _ARG_1_.bUseControllerRotationRoll
        }
        _ARG_1_.bUseControllerRotationYaw = false
        _ARG_1_.bUseControllerRotationPitch = false
        _ARG_1_.bUseControllerRotationRoll = false
        print(bWriteLog and table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 36, 225, 8, 131, 11, 1, 254, 56, 254, 98, 233, 235, 72, 244, 49, 165, 9, 224, 30),
          U1(11, 118, 140, 55, 88, 21, 155, 56, 162, 29, 29, 213, 35, 198, 126, 250, 245, 72, 252, 7, 190, 87, 224, 21, 160, 24, 6, 198, 56, 246)
        }))
      else
        if not _ARG_0_.PreTeleportControllerRotationSaved then
          return
        end
        _ARG_0_.PreTeleportControllerRotationSaved = nil
        _ARG_1_.bUseControllerRotationYaw = _ARG_0_.PreTeleportControllerRotationSaved.Yaw
        _ARG_1_.bUseControllerRotationPitch = _ARG_0_.PreTeleportControllerRotationSaved.Pitch
        _ARG_1_.bUseControllerRotationRoll = _ARG_0_.PreTeleportControllerRotationSaved.Roll
        if _ARG_1_:K2_GetActorRotation().Pitch ~= 0 or _ARG_1_:K2_GetActorRotation().Roll ~= 0 then
        end
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) and (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()):GetControlRotation().Roll ~= 0 then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ApplyPreTeleportClientShowState"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client or type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) then
        return
      end
      _ARG_0_.PreTeleportActiveSeqConfig = _ARG_1_
      if not _ARG_0_.Owner then
        return
      end
      if not slua.isValid(_ARG_0_.Owner.Object) then
        return
      end
      if not _ARG_0_.Owner:IsLocallyControlled() then
        return
      end
      if _ARG_1_.ExitScopeOnSequence == true then
      end
      if _ARG_1_.ForceTPPDuringSequence == true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportClientShowState"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      _ARG_0_.PreTeleportActiveSeqConfig = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportForceTPP"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ then
        if _ARG_0_.PreTeleportForceTPPApplied or not slua.isValid(_ARG_1_) then
          return
        end
        _ARG_0_.PreTeleportForceTPPApplied = true
        if _ARG_1_:GetIsFPP() then
          _ARG_1_.bForceChangePersonPerspective = true
          _ARG_0_.PreTeleportChangedPP = true
        end
        _ARG_0_.PreTeleportSwitchPPWasDisabled = _ARG_1_:IsPawnStateDisabled(U1.SwitchPP)
        return
      end
      if not _ARG_0_.PreTeleportForceTPPApplied then
        return
      end
      _ARG_0_.PreTeleportForceTPPApplied = nil
      _ARG_0_.PreTeleportChangedPP = nil
      _ARG_0_.PreTeleportSwitchPPWasDisabled = nil
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_0_.PreTeleportSwitchPPWasDisabled then
      end
      if _ARG_0_.PreTeleportChangedPP then
        if _ARG_1_.bDead ~= true then
        end
        _ARG_1_.bForceChangePersonPerspective = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportMoveInputIgnored"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      if _ARG_1_ then
        if _ARG_0_.PreTeleportMoveInputIgnored then
          return
        end
        if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          return
        end
        _ARG_0_.PreTeleportMoveInputPC, _ARG_0_.PreTeleportMoveInputIgnored = _ARG_0_.Owner and _ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety(), true
      else
        if not _ARG_0_.PreTeleportMoveInputIgnored then
          return
        end
        _ARG_0_.PreTeleportMoveInputIgnored = nil
        _ARG_0_.PreTeleportMoveInputPC = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportMovement"] = function(_ARG_0_)
    do
      _ARG_0_:_SetPreTeleportMoveInputIgnored(false)
      if _ARG_0_.PreTeleportMovementMode == nil then
        return
      end
      if slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
      else
        _ARG_0_.PreTeleportMovementMode = nil
        _ARG_0_.PreTeleportCustomMovementMode = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_StopPreTeleportSeqShowHandling"] = function(_ARG_0_)
    do
      _ARG_0_.PreTeleportShowFinished = true
      _ARG_0_.PreTeleportPawnDrivenByShow = nil
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 158, 18, 232, 29, 170, 45, 13, 199, 56, 224)))
      _ARG_0_:_RestorePreTeleportPawnVisibility()
      _ARG_0_:_RestorePreTeleportMovement()
      _ARG_0_:_SetPreTeleportControllerRotationDisabled(_ARG_0_.Owner and _ARG_0_.Owner.Object, false)
      _ARG_0_:_RestorePreTeleportClientShowState()
      if not _ARG_0_.PreTeleportLevelHeld then
        return
      end
      if _ARG_0_.PreTeleportClientLanded then
        _ARG_0_:_ReleasePreTeleportLevelHold()
        return
      end
      if not _ARG_0_.PreTeleportLevelHoldTimer then
        _ARG_0_.PreTeleportLevelHoldTimer = _ARG_0_:AddGameTimer(U1.HoldReleaseTimeout, false, function()
          PreTeleportLevelHoldTimer = nil
          _ENV:_ReleasePreTeleportLevelHold()
          return
        end)
        U2.print(U2.bWriteLog and U2.table.concat({
          _ENV(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 36, 240, 19, 163, 41, 22, 207, 9, 247, 107, 252, 244, 85, 242, 6, 153, 2, 229, 63),
          _ENV(12, 117, 151, 26, 75, 41, 144, 32, 170, 7, 19, 154, 58, 227, 126, 253, 180, 76, 255, 16, 250, 27, 229, 18, 183, 16, 10, 205, 125, 240, 98, 255, 235, 72, 229, 82, 184, 2, 248, 9),
          _ENV(5, 105, 137, 60, 77, 103, 156, 35, 175, 13)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ReleasePreTeleportLevelHold"] = function(_ARG_0_)
    do
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 158, 18, 232, 29, 170, 45, 13, 199, 56, 224)))
      if not _ARG_0_.PreTeleportLevelHeld then
        return
      end
      _ARG_0_.PreTeleportLevelHeld = nil
      _ARG_0_.PreTeleportShowFinished = nil
      _ARG_0_.PreTeleportClientLanded = nil
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 142, 30, 233, 25, 161)))
      if U1.SubsystemMgr:Get((_ENV(40, 127, 150, 55, 70, 20, 128, 62, 166, 8, 25, 211, 35, 229, 90, 238, 230))) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[147]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportPawnVisibility"] = function(_ARG_0_)
    do
      if not _ARG_0_.PreTeleportPawnHidden then
        return
      end
      _ARG_0_.PreTeleportPawnHidden = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_DestroyPreTeleportShowPawn"] = function(_ARG_0_)
    do
      _ARG_0_.PreTeleportShowPawn = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSimulatedAndNotSpectating"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_1_:IsSimulated() and not (U1.slua.isValid((GetPlayerController())) and GetPlayerController():IsInSpectating()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPlayerCharacterHiddenInGame"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ then
        _ARG_1_:SetActorHiddenInGame(true)
      elseif not _ARG_1_.CharacterHide or not _ARG_1_.CharacterHide.bCharacterHideIngame then
        _ARG_1_:SetActorHiddenInGame(false)
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 137, 18, 240, 44, 191, 24, 29, 207, 47, 209, 111, 248, 246, 91, 227, 6, 175, 21, 220, 5),
        U1(0, 126, 133, 60, 99, 41, 179, 45, 174, 12, 84, 159, 62, 162, 63, 172, 231, 3)
      }), _ARG_2_, _ARG_1_:ToString()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckLoading"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.Owner:IsAutonomousProxy() then
      elseif Client and slua.isValid((U1.GetPlayerController())) and U1.GetPlayerController():IsSpectator() and slua.isValid(U1.GetPlayerController():GetCurPlayerCharacter()) and U1.GetPlayerController():GetCurPlayerCharacter().PlayerKey == _ARG_0_.Owner.PlayerKey then
      end
      if not (SubsystemMgr:Get((U2(40, 127, 150, 55, 70, 20, 128, 62, 166, 8, 25, 211, 35, 229, 90, 238, 230))) and true) or _ARG_2_.NotShowLoading then
        return false
      end
      if _ARG_2_ and _ARG_2_.SkipLoadingUI == true then
      end
      if _ARG_0_.LoadingEffectReason == nil then
      end
      do return true end
      do return end
      _ARG_1_ = U1[147]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartWaitingClientLoading"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 137, 3, 229, 14, 167, 46, 5, 195, 41, 251, 105, 254, 199, 86, 233, 23, 164, 19, 216, 3),
        U1(5, 126, 137, 60, 77, 103, 209, 63)
      }), _ARG_0_.Owner:ToString()))
      _ARG_0_.WaitingClientLoadingTimer = _ARG_0_:AddGameTimer(U2, false, function()
        print(bWriteLog and string.format(table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 137, 3, 229, 14, 167, 46, 5, 195, 41, 251, 105, 254, 199, 86, 233, 23, 164, 19, 216, 3),
          U1(5, 126, 137, 60, 77, 103, 163, 45, 170, 29, 29, 212, 42, 193, 123, 224, 241, 68, 228, 46, 181, 22, 224, 21, 189, 30, 48, 195, 48, 247, 117, 185, 240, 83, 237, 23, 165, 18, 224, 76),
          U1(65, 105)
        }), U2.Owner:ToString()))
        U2:OnReceiveClientTeleportLoadingFinish()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLevelStreamingLoadEnd"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 200, 25, 165, 28, 8, 249, 41, 224, 98, 248, 233, 83, 238, 21, 134, 8, 245, 8),
        U1(33, 116, 132, 114, 15, 52)
      }), _ARG_3_))
      _ARG_0_:RemoveCommonEvent(EVENTTYPE_LEVELSTREAMING, EVENTID_LEVELSTREAMING_LOAD_END)
      if _ARG_0_.Config then
        _ARG_0_:OnClientLanded()
      end
      _ARG_0_:RPC_Server_NotifyTeleportLoadingFinish()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Server_NotifyTeleportLoadingFinish"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 128, 28, 22, 220, 56, 224, 88, 215, 235, 78, 233, 20, 179, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 11, 155, 45, 167, 0, 26, 221, 11, 235, 121, 224, 231, 66, 176, 71, 169)
      }), _ARG_0_.Owner:ToString()))
      _ARG_0_:OnReceiveClientTeleportLoadingFinish()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnReceiveClientTeleportLoadingFinish"] = function(_ARG_0_)
    do
      if not _ARG_0_.WaitingClientLoadingTimer then
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 214, 25, 176, 28, 13, 220, 56, 209, 107, 240, 225, 84, 244, 38, 175, 11, 241, 28),
          U1(11, 104, 148, 30, 69, 38, 144, 37, 173, 14, 50, 211, 35, 235, 100, 225, 180, 68, 255, 66, 141, 22, 237, 8, 186, 23, 3, 233, 49, 251, 98, 247, 240, 118, 239, 19, 174, 14, 250, 11),
          U1(48, 115, 141, 55, 88, 107, 212, 62, 166, 29, 1, 200, 35)
        }))))
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 214, 25, 176, 28, 13, 220, 56, 209, 107, 240, 225, 84, 244, 38, 175, 11, 241, 28),
        U1(11, 104, 148, 30, 69, 38, 144, 37, 173, 14, 50, 211, 35, 235, 100, 225, 180, 15, 227)
      }), _ARG_0_.Owner:ToString()))
      _ARG_0_:TryRemoveNamedGameTimer((U1(51, 123, 137, 38, 67, 41, 147, 15, 175, 0, 17, 212, 57, 206, 120, 232, 240, 67, 254, 5, 142, 30, 233, 25, 161)))
      _ARG_0_.LuaDelegate:Broadcast(U2, _ARG_0_.Owner)
      _ARG_0_.LuaDelegate:Remove(U2)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ListenOnClientTeleportLoadingFinished"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.LuaDelegate:Add(_ENV, _ARG_1_, _ARG_2_)
      do return _ARG_0_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientPreCheckLoadingEffect"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 27, 237, 25, 189, 13, 52, 216, 56, 209, 111, 252, 231, 81, 204, 29, 171, 3, 253, 2),
        U1(3, 95, 134, 52, 79, 36, 128, 108, 230, 26)
      }), _ARG_1_))
      if _ARG_0_.MarkTeleportFailed then
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 27, 237, 25, 189, 13, 52, 216, 56, 209, 111, 252, 231, 81, 204, 29, 171, 3, 253, 2),
          U1(3, 95, 134, 52, 79, 36, 128, 108, 169, 28, 7, 206, 109, 207, 118, 251, 255, 126, 245, 14, 191, 7, 235, 14, 167, 63, 5, 195, 49, 247, 99, 181, 164, 72, 229, 6, 191, 21, 250)
        }))))
        return
      end
      if _ARG_0_.LoadingEffectReason == nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckLoadingEffect"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:IsLocal() then
        return
      end
      if not _ARG_1_ or not _ARG_1_.LoadingEffect then
        return
      end
      if not _ARG_1_.LoadingEffect.Type or not _ARG_1_.LoadingEffect.Param then
        return
      end
      _ARG_0_.LoadingEffectReason = _ARG_2_
      if _ARG_1_.LoadingEffect.Type == U1(55, 121, 146, 55, 79, 41, 177, 42, 165, 12, 23, 206) then
        if slua.isValid((slua.loadObject(_ARG_1_.LoadingEffect.Param .. U1(59, 89)))) then
          _ARG_0_.LoadingEffectObject = import((U1(55, 121, 146, 55, 79, 41, 181, 60, 179, 12, 21, 200, 44, 236, 116, 236, 199, 94, 241, 22, 179, 20, 247))).PlayDynamicScreenAppearance(_ARG_0_.Owner.Object, _ARG_0_.Owner.Object, import((U1(55, 78, 165, 42, 94, 53, 149, 11, 162, 4, 17, 202, 33, 227, 110, 218, 224, 75, 228, 11, 185, 4))).GetClassDefaultObject((slua.loadObject(_ARG_1_.LoadingEffect.Param .. U1(59, 89)))).AppearanceName, (slua.loadObject(_ARG_1_.LoadingEffect.Param .. U1(59, 89))))
        end
      elseif _ARG_1_.LoadingEffect.Type == U1(49, 83) and UIManager.UI_Config_InGame[_ARG_1_.LoadingEffect.Param] then
        _ARG_0_.LoadingEffectObject = UIManager.ShowUI(UIManager.UI_Config_InGame[_ARG_1_.LoadingEffect.Param])
      end
      if _ARG_0_.LoadingEffectObject then
        _ARG_0_.StartLoadingEffectTime = U3.GetRealTimeSeconds(_ARG_0_.Owner.Object)
        _ARG_0_.LoadingEffectObjectTimeoutTimer = _ARG_0_:AddGameTimer(U2, false, function()
          print(bWriteLog and string.format((table.concat({
            U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 31, 225, 31, 184, 53, 11, 203, 57, 251, 105, 254, 193, 92, 230, 23, 169, 19, 180, 24),
            U1(13, 119, 133, 61, 95, 51)
          }))))
          U2:TryDestroyLoadingEffect()
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[61]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientLanded"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 199, 16, 186, 28, 10, 222, 17, 243, 105, 253, 225, 94))
      if not (_ARG_0_.Config and Client) or not _ARG_0_.Owner then
        return
      end
      if slua.isValid((_ARG_0_.Owner:GetControllerSafety())) and not _ARG_0_.Owner.bEnsure then
        _ARG_0_.Owner:GetControllerSafety().bAutoSprint = false
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryDestroyLoadingEffect"] = function(_ARG_0_)
    do
      if not _ARG_0_:IsLocal() then
        return
      end
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(40, 117, 129, 54, 67, 41, 147, 9, 165, 15, 17, 217, 57, 205, 117, 227, 241, 73, 228, 54, 179, 26, 225, 19, 166, 13, 48, 195, 48, 247, 117)))
      if _ARG_0_.Config and _ARG_0_.Config.LoadingEffect and _ARG_0_.Config.LoadingEffect.NoDestroy then
        _ARG_0_:ClearLoadingEffectObject()
      elseif _ARG_0_.LoadingEffectObject then
        if _ARG_0_.LoadingEffectObject.End and not _ARG_0_.LoadingEffectObject.bHasClosed then
        elseif _ARG_0_.LoadingEffectObject.SetLifeSpan then
          if _ARG_0_.StartLoadingEffectTime and 1 > U1.GetRealTimeSeconds(_ARG_0_.Owner.Object) - _ARG_0_.StartLoadingEffectTime then
          else
          end
        else
        end
      end
      _ARG_0_.LoadingEffectReason = nil
      if _ARG_0_.Config and _ARG_0_.Config.HideAllUI then
        _ARG_0_:TryRemoveNamedGameTimer((_ENV(44, 115, 132, 55, 107, 43, 152, 25, 138, 61, 29, 215, 40, 237, 98, 253, 192, 67, 253, 7, 168)))
        _ARG_0_.HideAllUITimeoutTimer = _ARG_0_:AddGameTimer(2, false, function()
          print(bWriteLog and string.format((table.concat({
            U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 142, 5, 253, 56, 182, 10, 16, 216, 50, 235, 75, 246, 229, 94, 233, 28, 173, 34, 242, 10),
            U1(1, 121, 148, 114, 98, 46, 144, 41, 130, 5, 24, 239, 4, 214, 126, 228, 241, 69, 229, 22)
          }))))
          EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_EXIT_TEAM_SHOW)
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearLoadingEffectObject"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format((table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 27, 225, 29, 161, 53, 11, 203, 57, 251, 105, 254, 193, 92, 230, 23, 169, 19, 219, 14),
        U1(14, 127, 131, 38)
      }))))
      if _ARG_0_.Config and _ARG_0_.Config.AudioOnPreTeleportLoop and _ARG_0_.AudioOnPreTeleportID then
        _ARG_0_.AudioOnPreTeleportID = nil
      end
      _ARG_0_.LoadingEffectObject = nil
      _ARG_0_:CheckHideAllUI(false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckHideAllUI"] = function(_ARG_0_, _ARG_1_)
    do
      if not (Client and _ARG_0_:IsLocal() and _ARG_0_.Config) or not _ARG_0_.Config.HideAllUI then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 31, 225, 31, 184, 49, 13, 206, 56, 211, 107, 245, 209, 115, 160, 16, 130, 14, 240, 9),
        U1(68, 39, 192, 119, 89)
      }), _ARG_1_))
      if _ARG_1_ then
        EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_ENTER_TEAM_SHOW)
      else
        EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_EXIT_TEAM_SHOW)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Client_NotifyTeleportFailed"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 144, 21, 13, 207, 51, 230, 88, 215, 235, 78, 233, 20, 179, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 1, 149, 37, 175, 12, 16, 150, 109, 206, 120, 232, 240, 67, 254, 5, 159, 17, 226, 25, 176, 13, 54, 207, 60, 225, 104, 247, 164, 7, 160, 87, 185)
      }), _ARG_0_.LoadingEffectReason))
      _ARG_0_:StopPreTeleportSequence(true)
      _ARG_0_:_ReleasePreTeleportLevelHold()
      _ARG_0_:TryDestroyLoadingEffect()
      _ARG_0_.MarkTeleportFailed = true
      _ARG_0_:AddGameTimer(0.1, false, function()
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 144, 21, 13, 207, 51, 230, 88, 215, 235, 78, 233, 20, 179, 51, 241, 0),
          U1(1, 106, 143, 32, 94, 1, 149, 37, 175, 12, 16, 150, 109, 207, 118, 251, 255, 126, 245, 14, 191, 7, 235, 14, 167, 63, 5, 195, 49, 247, 99, 185, 185, 26, 238, 27, 166)
        }))))
        U2.MarkTeleportFailed = nil
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsLocal"] = function(_ARG_0_)
    do
      if not _ARG_0_.Owner then
        return false
      end
      do return (not _ARG_0_.Owner.IsLocallyControlled or not _ARG_0_.Owner:IsLocallyControlled()) and _ARG_0_.Owner.IsLocalViewed and _ARG_0_.Owner:IsLocalViewed() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}).ClientRPC.RPC_Client_NotifyTeleportFailed = {
  Reliable = true,
  Params = {}
}
do return require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(7, 117, 141, 48, 67, 41, 145, 19, 160, 5, 21, 201, 62))).SetFeatureDynamic((require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(7, 118, 129, 33, 89)))(require((table.concat({
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(35, 123, 141, 55, 102, 50, 149, 98, 142, 6, 16, 148, 15, 227, 100, 236, 217, 69, 244, 76, 157, 22, 233, 25, 131, 21, 5, 211, 115, 212, 98, 248, 240, 79, 242, 23, 228, 36, 251, 1),
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(9, 117, 142, 124, 108, 34, 149, 56, 182, 27, 17, 248, 44, 241, 114)
}))), nil, {
  ServerRPC = {},
  ClientRPC = {},
  ["_PostConstruct"] = function(_ARG_0_)
    do
      __super._PostConstruct(_ARG_0_)
      _ARG_0_.LuaDelegate = U1.LuaDelegate()
      _ARG_0_.bPreTeleportHiddenOnOthers = false
      _ARG_0_.PreTeleportDamageBlocked = false
      _ARG_0_.PreTeleportAllowedDamageTypes = nil
      _ARG_0_.PreTeleportDamageBlockExpireAt = 0
      _ARG_0_.bPreTeleportDamageEventBound = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLifetimeReplicatedProps"] = function(_ARG_0_)
    do
      do return {
        {
          U2(6, 74, 146, 55, 126, 34, 152, 41, 179, 6, 6, 206, 5, 235, 115, 237, 241, 68, 223, 12, 149, 3, 236, 25, 161, 10),
          U1.import((U2(33, 86, 137, 52, 79, 51, 157, 33, 166, 42, 27, 212, 41, 235, 99, 224, 251, 68))).COND_None,
          U1.UEnums.EPropertyClass.Bool
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveBeginPlay"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format((U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 18, 231, 25, 186, 15, 1, 232, 56, 245, 110, 247, 212, 86, 225, 11))))
      U2.__super.ReceiveBeginPlay(_ARG_0_)
      if not _ARG_0_.Owner then
        return
      end
      if not slua.isValid(_ARG_0_.Owner.Object) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckPreload"] = function(_ARG_0_)
    do
      if not _ARG_0_.Owner then
        return
      end
      if not _ARG_0_.Owner:IsLocallyControlled() and not _ARG_0_.Owner:IsLocalViewed() then
        return
      end
      if _ARG_0_.PreloadAssets then
        return
      end
      _ARG_0_.PreloadAssets = {}
      if U2.GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229))) then
        goto lbl_155
        ::lbl_155::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveEndPlay"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.LuaDelegate then
        _ARG_0_.LuaDelegate:Dispose()
      end
      if Client then
        _ARG_0_:StopPreTeleportSequence(true)
        _ARG_0_:_RestorePreTeleportPawnVisibility()
        _ARG_0_:_RestorePreTeleportMovement()
        _ARG_0_:_ReleasePreTeleportLevelHold()
        _ARG_0_:_RestorePreTeleportHiddenOnThisClient()
        _ARG_0_.PreloadAssets = nil
        _ARG_0_:TryRemoveNamedGameTimer((U1(32, 127, 140, 51, 83, 4, 152, 35, 176, 12, 56, 213, 44, 230, 126, 231, 243, 111, 246, 4, 191, 20, 240, 41, 154, 45, 13, 199, 56, 224)))
      else
        _ARG_0_:TryRemoveNamedGameTimer((U1(52, 127, 142, 54, 67, 41, 147, 28, 177, 12, 32, 223, 33, 231, 103, 230, 230, 94, 196, 11, 183, 18, 246)))
        _ARG_0_.PendingPreTeleport = nil
        _ARG_0_:_SetPendingTeleportMovementFrozen(_ARG_0_.Owner and _ARG_0_.Owner.Object, false)
        _ARG_0_:_ReleasePreTeleportServerShowState()
      end
      U2.__super.ReceiveEndPlay(_ARG_0_, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoteTeleportPawnByTable"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_1_.BornPos and #_ARG_1_.BornPos > 0 then
        if 10 < _ARG_2_ then
          print(bWriteLog and table.concat({
            U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 18, 233, 19, 167, 28, 48, 207, 49, 247, 119, 246, 246, 78, 208, 19, 189, 9, 214, 21),
            U1(48, 123, 130, 62, 79, 107, 212, 24, 166, 5, 17, 202, 34, 240, 99, 217, 245, 93, 254, 66, 151, 24, 246, 25, 243, 45, 12, 203, 51, 178, 115, 252, 234, 0, 160)
          }) .. tostring(_ARG_0_.Owner.PlayerKey))
          return
        end
        if not _ARG_0_:RemoteTeleportPawn(_ARG_1_.BornPos[math.random(1, #_ARG_1_.BornPos)].Location, _ARG_1_.BornPos[math.random(1, #_ARG_1_.BornPos)].Roatation, _ARG_3_, _ARG_4_) then
          _ARG_2_ = _ARG_2_ + 1
        end
      end
      do return end
      _ARG_1_ = U1.tostring
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoteTeleportPawn"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not Client and _ARG_0_.Owner then
        if Game:TeleportPawn(_ARG_0_.Owner.Object, _ARG_1_, _ARG_2_, false, true, false, false, _ARG_3_, _ARG_4_) then
          if _ARG_3_ == import((U1(33, 78, 133, 62, 79, 55, 155, 62, 183, 57, 21, 205, 35, 214, 110, 249, 241))).ParachuteTeleport then
          elseif _ARG_3_ == import((U1(33, 78, 133, 62, 79, 55, 155, 62, 183, 57, 21, 205, 35, 214, 110, 249, 241))).RemoteTeleport then
          end
          if _ARG_4_ and _ARG_0_:GetConfig(_ARG_4_) and _ARG_0_:GetConfig(_ARG_4_).GameTLogId and SubsystemMgr:Get((U1(32, 73, 163, 61, 71, 42, 155, 34, 151, 37, 27, 221, 30, 247, 117, 250, 237, 89, 228, 7, 183))) then
          end
        end
        return (Game:TeleportPawn(_ARG_0_.Owner.Object, _ARG_1_, _ARG_2_, false, true, false, false, _ARG_3_, _ARG_4_))
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1[252]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInTeleportState"] = function(_ARG_0_)
    do
      if _ARG_0_.PreTeleportActiveSeqConfig ~= nil or _ARG_0_.PreTeleportSeqActor ~= nil or _ARG_0_.LoadingEffectReason ~= nil or _ARG_0_.PreTeleportLevelHeld == true then
      end
      do return _ARG_0_.PreTeleportActiveSeqConfig ~= nil or _ARG_0_.PreTeleportSeqActor ~= nil or _ARG_0_.LoadingEffectReason ~= nil or _ARG_0_.PreTeleportLevelHeld == true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPawnAttached"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return false
      end
      if not slua.isValid((_ARG_0_.Owner and _ARG_0_.Owner.Object).RootComponent) then
        return false
      end
      do return slua.isValid((_ARG_0_.Owner and _ARG_0_.Owner.Object).RootComponent:GetAttachParent()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPawnOnVehicle"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return false
      end
      do return (_ARG_0_.Owner and _ARG_0_.Owner.Object):HasState(U1.InVehicle) or (_ARG_0_.Owner and _ARG_0_.Owner.Object):HasState(U1.DriveVehicle) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoteTeleport"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_0_:IsPawnOnVehicle() then
        print(bWriteLog and string.format(table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 18, 233, 19, 167, 28, 48, 207, 49, 247, 119, 246, 246, 78, 160, 0, 175, 1, 225, 31),
          U1(1, 126, 204, 114, 90, 38, 131, 34, 227, 6, 26, 154, 59, 231, 127, 224, 247, 70, 245, 78, 250, 39, 232, 29, 170, 28, 22, 225, 56, 235, 39, 164, 164, 31, 243, 94, 234, 36, 251, 2),
          U1(2, 115, 135, 27, 78, 103, 201, 108, 230, 26)
        }), tostring(_ARG_0_.Owner.PlayerKey), tostring(_ARG_3_)))
        return false
      end
      if _ARG_0_:IsPawnAttached() then
        return false
      end
      if _ARG_0_:_TryDeferTeleportForPreSequence(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport, _ARG_4_) then
        return true, (_ARG_0_:_TryCancelCarryBackForTeleport(_ARG_3_))
      end
      if not _ARG_0_:InternalTeleport(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport) then
        return (_ARG_0_:InternalTeleport(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport))
      end
      do return _ARG_0_:InternalTeleport(_ARG_1_, _ARG_2_, _ARG_3_, U2.RemoteTeleport), (_ARG_0_:_TryCancelCarryBackForTeleport(_ARG_3_)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_TryCancelCarryBackForTeleport"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return nil
      end
      if not _ARG_0_:GetConfig(_ARG_1_) or _ARG_0_:GetConfig(_ARG_1_).CancelCarryBackOnTeleport ~= true then
        return nil
      end
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) or not (_ARG_0_.Owner and _ARG_0_.Owner.Object).IsInCarryBackState then
        return nil
      end
      if (_ARG_0_.Owner and _ARG_0_.Owner.Object):IsInCarryBackState() then
      elseif (_ARG_0_.Owner and _ARG_0_.Owner.Object):IsInBeCarriedBackState() then
        if slua.isValid(((_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCarryBackCharacter())) then
        end
      else
        return nil
      end
      do return slua.isValid(((_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCarryBackCharacter())) and (_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCarryBackCharacter() or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_TryDeferTeleportForPreSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if Client then
        return false
      end
      if type(_ARG_0_:GetConfig(_ARG_3_) and _ARG_0_:GetConfig(_ARG_3_).SequenceOnPreTeleport) ~= U1(16, 123, 130, 62, 79) then
        return false
      end
      if not slua.isValid(_ARG_0_.Owner.Object) or _ARG_0_.Owner.bEnsure or not Game:IsPlayer(_ARG_0_.Owner.Object) then
        return false
      end
      if not slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
        return false
      end
      if _ARG_0_.PendingPreTeleport then
        return true
      end
      _ARG_0_.PendingPreTeleportSerial = (_ARG_0_.PendingPreTeleportSerial or 0) + 1
      _ARG_0_.PendingPreTeleport = {
        Location = _ARG_1_,
        Rotation = _ARG_2_,
        ConfigId = _ARG_3_,
        Type = _ARG_4_,
        Serial = _ARG_0_.PendingPreTeleportSerial,
        bStarted = false
      }
      _ARG_0_.PendingPreTeleportTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_3_) and _ARG_0_:GetConfig(_ARG_3_).SequenceOnPreTeleport, (U1(55, 127, 146, 36, 79, 53, 163, 45, 170, 29, 32, 211, 32, 231, 120, 252, 224))), false, function()
        PendingPreTeleportTimer = nil
        _ENV:_ExecutePendingPreTeleport(U1, (U2(48, 115, 141, 55, 69, 50, 128)))
        return
      end)
      if (_ARG_0_:GetConfig(_ARG_3_) and _ARG_0_:GetConfig(_ARG_3_).SequenceOnPreTeleport).DisableMovementDuringSequence == true then
      end
      if _ARG_5_ then
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetPreTeleportSeqConfigValue"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return type(_ARG_1_) == U1(16, 123, 130, 62, 79) and tonumber(_ARG_1_[_ARG_2_]) or nil or tonumber(U2[_ARG_2_]) or 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnClientPreTeleportSeqStarted"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.PendingPreTeleport or _ARG_0_.PendingPreTeleport.Serial ~= _ARG_1_ then
        return
      end
      if _ARG_0_.PendingPreTeleport.bStarted then
        return
      end
      _ARG_0_.PendingPreTeleport.bStarted = true
      if type(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport) == U1(16, 123, 130, 62, 79) and (_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport).HidePawnOnOtherClientsDuringSequence == true then
        _ARG_0_.bPreTeleportHiddenOnOthers = true
      end
      if 0 >= _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) then
      end
      if 0 >= _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) - _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(48, 127, 140, 55, 90, 40, 134, 56, 130, 1, 17, 219, 41, 214, 126, 228, 241))) then
        return
      end
      _ARG_0_.PendingPreTeleportTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) - _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport, (U1(48, 127, 140, 55, 90, 40, 134, 56, 130, 1, 17, 219, 41, 214, 126, 228, 241))), false, function()
        PendingPreTeleportTimer = nil
        _ENV:_ExecutePendingPreTeleport(U1, (U2(37, 114, 133, 51, 78, 8, 146, 31, 166, 24, 1, 223, 35, 225, 114, 204, 250, 78)))
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[84]
    end
  end,
  ["_OnClientPreTeleportSeqSkipped"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.PendingPreTeleport or _ARG_0_.PendingPreTeleport.Serial ~= _ARG_1_ then
        return
      end
      if _ARG_0_.PendingPreTeleport.bStarted then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ExecutePendingPreTeleport"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.PendingPreTeleport or _ARG_0_.PendingPreTeleport.Serial ~= _ARG_1_ then
        return
      end
      _ARG_0_.PendingPreTeleport = nil
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if _ARG_0_.Owner.bDead == true then
        return
      end
      if not _ARG_0_:InternalTeleport(_ARG_0_.PendingPreTeleport.Location, _ARG_0_.PendingPreTeleport.Rotation, _ARG_0_.PendingPreTeleport.ConfigId, _ARG_0_.PendingPreTeleport.Type) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CancelPendingPreTeleport"] = function(_ARG_0_, _ARG_1_)
    do
      if Client or not _ARG_0_.PendingPreTeleport then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 52, 229, 18, 176, 28, 8, 250, 56, 252, 99, 240, 234, 93, 208, 0, 175, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 103, 164, 32, 162, 16, 17, 200, 6, 231, 110, 169, 169, 10, 181, 17, 246, 87, 215, 25, 161, 16, 5, 198, 125, 175, 39, 188, 247, 22, 160, 32, 175, 6, 231, 3),
        U1(10, 58, 221, 114, 15, 52)
      }), tostring(_ARG_0_.Owner and _ARG_0_.Owner.PlayerKey), tostring(_ARG_0_.PendingPreTeleport.Serial), tostring(_ARG_1_)))
      _ARG_0_.PendingPreTeleport = nil
      _ARG_0_:TryRemoveNamedGameTimer((U1(52, 127, 142, 54, 67, 41, 147, 28, 177, 12, 32, 223, 33, 231, 103, 230, 230, 94, 196, 11, 183, 18, 246)))
      _ARG_0_:_SetPendingTeleportMovementFrozen(_ARG_0_.Owner and _ARG_0_.Owner.Object, false)
      _ARG_0_:_ReleasePreTeleportServerShowState()
      _ARG_0_:RPC_Client_NotifyTeleportFailed()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnOwnerDeath"] = function(_ARG_0_)
    do
      if not Client then
        if not _ARG_0_.PendingPreTeleport then
          return
        end
        if type(_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport) == U1(16, 123, 130, 62, 79) and (_ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId) and _ARG_0_:GetConfig(_ARG_0_.PendingPreTeleport.ConfigId).SequenceOnPreTeleport).CancelTeleportOnDeath == true then
        end
        return
      end
      if type(_ARG_0_.PreTeleportActiveSeqConfig) ~= U1(16, 123, 130, 62, 79) or _ARG_0_.PreTeleportActiveSeqConfig.CancelTeleportOnDeath ~= true then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPendingTeleportMovementFrozen"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      if _ARG_2_ then
        if not slua.isValid(_ARG_1_ and _ARG_1_.STCharacterMovement) or _ARG_0_.PendingTeleportMovementMode ~= nil then
          return
        end
        _ARG_0_.PendingTeleportMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).MovementMode
        _ARG_0_.PendingTeleportCustomMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).CustomMovementMode
        _ARG_0_.PendingTeleportMovementActive = (_ARG_1_ and _ARG_1_.STCharacterMovement):IsActive()
        _ARG_0_.PendingTeleportMovementTickEnabled = (_ARG_1_ and _ARG_1_.STCharacterMovement):IsComponentTickEnabled()
        if _ARG_0_.PendingTeleportMovementMode == U1 then
          _ARG_0_.PendingTeleportMovementMode = U2
          _ARG_0_.PendingTeleportCustomMovementMode = 0
          _ARG_0_.PendingTeleportMovementActive = true
          _ARG_0_.PendingTeleportMovementTickEnabled = true
        end
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          _ARG_0_.PendingTeleportMoveableSaved = (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).bMoveable
        end
        _ARG_0_.PendingTeleportMovementGuardTimer = _ARG_0_:AddGameTimer(0.1, true, function()
          if PendingTeleportMovementMode == nil then
            return
          end
          if not U1.slua.isValid(U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil) then
            return
          end
          if (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil):IsActive() or (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil):IsComponentTickEnabled() or (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil).MovementMode ~= U2 then
          end
          return
        end)
        return
      end
      if _ARG_0_.PendingTeleportMovementMode == nil then
        return
      end
      _ARG_0_.PendingTeleportMovementMode = nil
      _ARG_0_.PendingTeleportCustomMovementMode = nil
      _ARG_0_.PendingTeleportMovementActive = nil
      _ARG_0_.PendingTeleportMovementTickEnabled = nil
      if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) and _ARG_0_.PendingTeleportMoveableSaved ~= nil then
        _ARG_0_.PendingTeleportMoveableSaved = nil
      end
      if slua.isValid(_ARG_1_ and _ARG_1_.STCharacterMovement) then
        if _ARG_1_.bDead ~= true then
        end
        if _ARG_0_.PendingTeleportMovementActive == false then
        end
      end
      do return end
      _ARG_0_ = _ENV[87]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ResolvePreTeleportForbiddenStates"] = function(_ARG_0_, _ARG_1_)
    do
      if (type(_ARG_1_) == U1(16, 123, 130, 62, 79) and _ARG_1_.ForbiddenPawnStatesDuringSequence or nil) == true then
      end
      if type(U2) ~= U1(16, 123, 130, 62, 79) then
        return nil
      end
      goto lbl_158
      if type(62) == U1(23, 110, 146, 59, 68, 32) then
      end
      if U3[62] ~= nil and U3[62] ~= U3.Dying and U3[62] ~= U3.Dead then
      else
      end
      ::lbl_158::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportPawnStatesDisabled"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ then
        if _ARG_0_.PreTeleportDisabledPawnStates or not slua.isValid(_ARG_1_) then
          return
        end
        if not _ARG_0_:_ResolvePreTeleportForbiddenStates(_ARG_2_) or #_ARG_0_:_ResolvePreTeleportForbiddenStates(_ARG_2_) == 0 then
          return
        end
        goto lbl_41
        ::lbl_41::
        _ARG_0_ = _ARG_0_
        _ARG_0_.PreTeleportDisabledPawnStates, _ARG_0_ = {}, _ARG_0_
        return
      end
      _ARG_0_.PreTeleportDisabledPawnStates = nil
      if not _ARG_0_.PreTeleportDisabledPawnStates or not slua.isValid(_ARG_1_) then
        return
      end
      goto lbl_154
      ::lbl_154::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CancelPreTeleportHoldGrenade"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) or not _ARG_1_:HasState(U1.HoldGrenade) then
        return
      end
      print(bWriteLog and table.concat({
        U2(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 52, 229, 18, 176, 28, 8, 250, 47, 247, 83, 252, 232, 95, 240, 29, 184, 19, 220, 3),
        U2(8, 126, 167, 32, 79, 41, 149, 40, 166)
      }))
      if Client then
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          ;(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).TouchEndTriggerSkillID = -1
        end
      end
      _ARG_1_:TriggerCustomEvent(U3.PlayerRequestCancel, -1)
      if Client then
        EventSystem:postEvent(EVENTTYPE_INGAME_SHOOTINGUI_PANEL, EVENTID_ON_THROW_CANCEL_BUTTON_CLICK)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportGrenadePredictLine"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if not _ARG_0_.Owner.IsLocallyControlled or not _ARG_0_.Owner:IsLocallyControlled() then
        return
      end
      if not slua.isValid(((_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCurrentWeapon())) or not (_ARG_0_.Owner and _ARG_0_.Owner.Object):GetCurrentWeapon().EnableWeaponPredictLine then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PreparePreTeleportLocomotion"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_.DisableMovementDuringSequence == true and _ARG_2_.StopAllSkillsOnSequence == true and slua.isValid((_ARG_1_:GetPlayerControllerSafety())) and (_ARG_1_:GetPlayerControllerSafety():GetCurrentStateType() == import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteJump or _ARG_1_:GetPlayerControllerSafety():GetCurrentStateType() == import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteOpen) then
        if not Client and _ARG_1_:GetPlayerControllerSafety():GetCurrentStateType() == import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteOpen and _ARG_1_:GetPlayerControllerSafety().GetStateMachineCompent and slua.isValid((_ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent())) and _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState and _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill == true then
          _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill = false
        end
        if Client then
        else
        end
        if slua.isValid(_ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState) and _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill == true then
          _ARG_1_:GetPlayerControllerSafety():GetStateMachineCompent().CurrentState.bShouldTriggerLandingSkill = true
        end
      end
      if _ARG_2_.StopAllSkillsOnSequence == true then
        if Client then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ApplyPreTeleportServerShowState"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not (not Client and slua.isValid(_ARG_1_)) or type(_ARG_2_) ~= U1(16, 123, 130, 62, 79) then
        return
      end
      _ARG_0_:_ReleasePreTeleportServerShowState()
      _ARG_0_:_PreparePreTeleportLocomotion(_ARG_1_, _ARG_2_)
      if _ARG_2_.ExitScopeOnSequence == true then
        _ARG_1_:ScopeInterrupt(U2.Normal)
      end
      _ARG_0_:_SetPreTeleportPawnStatesDisabled(_ARG_1_, _ARG_2_, true)
      _ARG_0_:_AddPreTeleportDamageBlock(_ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ResolvePreTeleportAllowedDamageTypes"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_.AllowedDamageTypesDuringSequence) ~= U1(16, 123, 130, 62, 79) then
      end
      goto lbl_193
      if type(62) == U1(10, 111, 141, 48, 79, 53) and 62 or type(62) == U1(23, 110, 146, 59, 68, 32) and import((U1(33, 94, 129, 63, 75, 32, 145, 24, 186, 25, 17)))[62] or nil then
      else
      end
      ::lbl_193::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {
        [type(62) == U1(10, 111, 141, 48, 79, 53) and 62 or type(62) == U1(23, 110, 146, 59, 68, 32) and import((U1(33, 94, 129, 63, 75, 32, 145, 24, 186, 25, 17)))[62] or nil] = true
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetPreTeleportDamageBlockMaxDuration"] = function(_ARG_0_, _ARG_1_)
    do
      if (U1.type(_ARG_1_) == _ENV(16, 123, 130, 62, 79) and U1.tonumber(_ARG_1_.DamageBlockMaxDuration) or nil) and 0 < (U1.type(_ARG_1_) == _ENV(16, 123, 130, 62, 79) and U1.tonumber(_ARG_1_.DamageBlockMaxDuration) or nil) then
        return U1.type(_ARG_1_) == _ENV(16, 123, 130, 62, 79) and U1.tonumber(_ARG_1_.DamageBlockMaxDuration) or nil
      end
      do return _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(55, 127, 146, 36, 79, 53, 163, 45, 170, 29, 32, 211, 32, 231, 120, 252, 224))) + _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(55, 127, 145, 39, 79, 41, 151, 41, 143, 12, 26, 221, 57, 234))) + _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 9, 227, 122, 232, 243, 79, 210, 14, 181, 20, 239, 52, 188, 21, 0, 254, 52, 255, 98))) + 10 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_AddPreTeleportDamageBlock"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) or _ARG_1_.BlockDamageDuringSequence ~= true then
        return
      end
      _ARG_0_:_RemovePreTeleportDamageBlock()
      _ARG_0_.PreTeleportAllowedDamageTypes = _ARG_0_:_ResolvePreTeleportAllowedDamageTypes(_ARG_1_)
      _ARG_0_.PreTeleportDamageBlocked = true
      _ARG_0_.PreTeleportDamageBlockExpireAt = (slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) and U2.GetRealTimeSeconds(_ARG_0_.Owner and _ARG_0_.Owner.Object) or 0) + _ARG_0_:_GetPreTeleportDamageBlockMaxDuration(_ARG_1_)
      _ARG_0_.PreTeleportDamageBlockSafetyTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportDamageBlockMaxDuration(_ARG_1_), false, function()
        PreTeleportDamageBlockSafetyTimer = nil
        if PreTeleportDamageBlocked then
          U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
            U2(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 54, 224, 24, 131, 11, 1, 254, 56, 254, 98, 233, 235, 72, 244, 54, 171, 10, 245, 11),
            U2(1, 88, 140, 61, 73, 44, 212, 63, 162, 15, 17, 206, 52, 162, 99, 224, 249, 79, 255, 23, 174, 87, 161, 15, 243, 10, 72, 138, 59, 253, 117, 250, 225, 26, 242, 23, 166, 2, 245, 31),
            U2(1, 54, 192, 2, 70, 38, 141, 41, 177, 34, 17, 195, 109, 191, 55, 172, 231)
          }), U1.tostring(U3), U1.tostring(Owner and Owner.PlayerKey)))
          _ENV:_RemovePreTeleportDamageBlock()
        end
        return
      end)
      if not _ARG_0_.bPreTeleportDamageEventBound then
        _ARG_0_.bPreTeleportDamageEventBound = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RemovePreTeleportDamageBlock"] = function(_ARG_0_)
    do
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 254, 44, 239, 118, 238, 241, 104, 252, 13, 185, 28, 208, 21, 190, 28, 22)))
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 254, 44, 239, 118, 238, 241, 104, 252, 13, 185, 28, 215, 29, 181, 28, 16, 211, 9, 251, 106, 252, 246)))
      _ARG_0_.PreTeleportDamageBlockSafetyTimer = nil
      _ARG_0_.PreTeleportDamageBlockExpireAt = 0
      if not _ARG_0_.PreTeleportDamageBlocked then
        return
      end
      _ARG_0_.PreTeleportDamageBlocked = false
      _ARG_0_.PreTeleportAllowedDamageTypes = nil
      if _ARG_0_.bPreTeleportDamageEventBound then
        _ARG_0_.bPreTeleportDamageEventBound = false
        _ARG_0_:RemoveCommonEvent(U1.EVENTTYPE_INGAME_NORMAL, U1.EVENTID_PRE_TAKE_DAMAGE)
      end
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        _ENV(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 37, 225, 17, 188, 15, 1, 250, 47, 247, 83, 252, 232, 95, 240, 29, 184, 19, 208, 13),
        _ENV(9, 123, 135, 55, 104, 43, 155, 47, 168, 73, 36, 214, 44, 251, 114, 251, 223, 79, 233, 66, 231, 87, 161, 15)
      }), U1.tostring(_ARG_0_.Owner and _ARG_0_.Owner.PlayerKey)))
      return
    end
  end,
  ["HandlePreTeleportPreTakeDamage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not (not Client and _ARG_0_.PreTeleportDamageBlocked) or not slua.isValid(_ARG_3_) then
        return
      end
      if not slua.isValid(_ARG_3_.Target) then
        return
      end
      if not (_ARG_3_.Target.PlayerKey and _ARG_0_.Owner) or _ARG_3_.Target.PlayerKey ~= _ARG_0_.Owner.PlayerKey then
        return
      end
      if slua.isValid(_ARG_0_.Owner.Object) and _ARG_0_.PreTeleportDamageBlockExpireAt > 0 and U1.GetRealTimeSeconds(_ARG_0_.Owner.Object) > _ARG_0_.PreTeleportDamageBlockExpireAt then
        return
      end
      if _ARG_0_.PreTeleportAllowedDamageTypes and _ARG_0_.PreTeleportAllowedDamageTypes[_ARG_3_.DamageType] then
        return
      end
      _ARG_3_.Damage = 0
      do return end
      _ARG_1_ = _ENV[12]
    end
  end,
  ["_ScheduleReleasePreTeleportServerShowState"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if _ARG_0_.PreTeleportDamageBlocked then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 9, 227, 122, 232, 243, 79, 210, 14, 181, 20, 239, 52, 188, 21, 0, 254, 52, 255, 98))) then
          _ARG_0_.PreTeleportDamageBlockTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 9, 227, 122, 232, 243, 79, 210, 14, 181, 20, 239, 52, 188, 21, 0, 254, 52, 255, 98))), false, function()
            PreTeleportDamageBlockTimer = nil
            _ENV:_RemovePreTeleportDamageBlock()
            return
          end)
        else
        end
      end
      if _ARG_0_.bPreTeleportHiddenOnOthers then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(55, 114, 143, 37, 122, 38, 131, 34, 140, 7, 59, 206, 37, 231, 101, 250, 208, 79, 252, 3, 163))) then
          _ARG_0_.PreTeleportShowOnOthersTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(55, 114, 143, 37, 122, 38, 131, 34, 140, 7, 59, 206, 37, 231, 101, 250, 208, 79, 252, 3, 163))), false, function()
            PreTeleportShowOnOthersTimer = nil
            bPreTeleportHiddenOnOthers = false
            return
          end)
        else
          _ARG_0_.bPreTeleportHiddenOnOthers = false
        end
      end
      if _ARG_0_.PreTeleportDisabledPawnStates then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 30, 246, 118, 253, 241, 98, 255, 14, 190, 35, 237, 17, 182))) then
          _ARG_0_.PreTeleportStateRestoreTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (U1(52, 117, 147, 38, 126, 34, 152, 41, 179, 6, 6, 206, 30, 246, 118, 253, 241, 98, 255, 14, 190, 35, 237, 17, 182))), false, function()
            PreTeleportStateRestoreTimer = nil
            _ENV:_SetPreTeleportPawnStatesDisabled(Owner and Owner.Object, nil, false)
            return
          end)
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ReleasePreTeleportServerShowState"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      _ARG_0_:TryRemoveNamedGameTimer((U1(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 233, 37, 237, 96, 198, 250, 101, 228, 10, 191, 5, 247, 40, 186, 20, 1, 216)))
      _ARG_0_:TryRemoveNamedGameTimer((U1(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 233, 57, 227, 99, 236, 198, 79, 227, 22, 181, 5, 225, 40, 186, 20, 1, 216)))
      if _ARG_0_.bPreTeleportHiddenOnOthers then
        _ARG_0_.bPreTeleportHiddenOnOthers = false
      end
      _ARG_0_:_SetPreTeleportPawnStatesDisabled(_ARG_0_.Owner and _ARG_0_.Owner.Object, nil, false)
      _ARG_0_:_RemovePreTeleportDamageBlock()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_bPreTeleportHiddenOnOthers"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if _ARG_0_.bPreTeleportHiddenOnOthers == true and not _ARG_0_:IsLocal() then
        if not _ARG_0_.PreTeleportHiddenOnThisClient then
          _ARG_0_.PreTeleportHiddenOnThisClient = true
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportHiddenOnThisClient"] = function(_ARG_0_)
    do
      if not _ARG_0_.PreTeleportHiddenOnThisClient then
        return
      end
      _ARG_0_.PreTeleportHiddenOnThisClient = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Server_ReportPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 128, 28, 22, 220, 56, 224, 88, 203, 225, 74, 239, 0, 190, 55, 230, 9),
        U1(48, 127, 140, 55, 90, 40, 134, 56, 144, 12, 5, 207, 40, 236, 116, 236, 180, 122, 252, 3, 163, 18, 246, 55, 182, 0, 68, 151, 125, 183, 116, 181, 164, 104, 229, 2, 165, 21, 224, 56),
        U1(29, 106, 133, 114, 23, 103, 209, 63, 239, 73, 39, 223, 63, 235, 118, 229, 180, 23, 176, 71, 169)
      }), tostring(_ARG_0_.Owner.PlayerKey), tostring(_ARG_1_), tostring(_ARG_2_)))
      if _ARG_1_ == U2.Started then
        _ARG_0_:_OnClientPreTeleportSeqStarted(_ARG_2_)
      elseif _ARG_1_ == U2.Skipped then
        _ARG_0_:_OnClientPreTeleportSeqSkipped(_ARG_2_)
      else
        print(bWriteLog and string.format(table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 128, 28, 22, 220, 56, 224, 88, 203, 225, 74, 239, 0, 190, 55, 230, 9),
          U1(48, 127, 140, 55, 90, 40, 134, 56, 144, 12, 5, 207, 40, 236, 116, 236, 180, 88, 245, 8, 191, 20, 240, 25, 183, 85, 68, 223, 51, 249, 105, 246, 243, 84, 160, 32, 175, 23, 251, 30),
          U1(16, 78, 153, 34, 79, 103, 201, 108, 230, 26)
        }), tostring(_ARG_1_)))
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Client_PlayPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_, _ARG_9_, _ARG_10_, _ARG_11_, _ARG_12_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 144, 21, 13, 207, 51, 230, 88, 201, 232, 91, 249, 34, 184, 2, 192, 9),
        U1(8, 127, 144, 61, 88, 51, 167, 41, 178, 28, 17, 212, 46, 231, 55, 202, 251, 68, 246, 11, 189, 62, 224, 92, 238, 89, 65, 217, 113, 178, 84, 252, 246, 83, 225, 30, 234, 90, 180, 73),
        U1(23, 54, 192, 26, 75, 52, 164, 32, 162, 16, 32, 200, 44, 236, 100, 239, 251, 88, 253, 66, 231, 87, 161, 15, 255, 89, 48, 203, 47, 245, 98, 237, 200, 85, 227, 82, 247, 71, 188, 73),
        U1(23, 54, 192, 119, 89, 107, 212, 105, 176, 64)
      }), tostring(_ARG_1_), tostring(_ARG_2_), tostring(_ARG_3_), tostring(_ARG_10_), tostring(_ARG_11_), tostring(_ARG_12_)))
      if _ARG_3_ == 1 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShouldSkipPreTeleportSequence"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) or _ARG_1_.SkipOnLowDevice ~= true then
        return false
      end
      do return require((U1(7, 117, 141, 63, 69, 41, 218, 8, 166, 31, 29, 217, 40, 215, 99, 224, 248, 89))).GetDeviceLevel() ~= nil and require((U1(7, 117, 141, 63, 69, 41, 218, 8, 166, 31, 29, 217, 40, 215, 99, 224, 248, 89))).GetDeviceLevel() <= require((U1(7, 117, 141, 63, 69, 41, 218, 8, 166, 31, 29, 217, 40, 215, 99, 224, 248, 89))).ENum_DeviceLevel.Low end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InternalTeleport"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      print(bWriteLog and table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 147, 25, 240, 25, 161, 23, 5, 198, 9, 247, 107, 252, 244, 85, 242, 6, 234, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 4, 155, 34, 165, 0, 19, 243, 41, 162)
      }) .. tostring(_ARG_3_))
      if not _ARG_0_:CheckPawn(_ARG_0_.Owner.Object) then
        return false
      end
      if _ARG_0_:IsPawnOnVehicle() then
        return false
      end
      if _ARG_0_:IterateTargetLocation(_ARG_1_, function(_ARG_0_)
        do
          if _ENV and U1:LineTraceHit(U2, _ARG_0_) then
            return false, U3.LineTrace
          end
          if U4.Game:TeleportPawn(U5, _ARG_0_, U6, false, true, false, false, U7, U8) then
            return true
          else
            return false, U3.TeleportPawn
          end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end) then
        _ARG_0_.LocationBeforeTeleport = _ARG_0_.Owner:K2_GetActorLocation()
        if _ARG_0_.Config and _ARG_0_.Config.ParachuteTeleport == true then
        else
        end
        if _ARG_0_.Owner.Object.PlayerUID then
        end
      else
      end
      do return (_ARG_0_:IterateTargetLocation(_ARG_1_, function(_ARG_0_)
        do
          if _ENV and U1:LineTraceHit(U2, _ARG_0_) then
            return false, U3.LineTrace
          end
          if U4.Game:TeleportPawn(U5, _ARG_0_, U6, false, true, false, false, U7, U8) then
            return true
          else
            return false, U3.TeleportPawn
          end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckPawn"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return false
      end
      if not slua.isValid(_ARG_1_) then
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 31, 225, 31, 184, 41, 5, 221, 51, 178, 114, 201, 229, 77, 238, 82, 163, 20, 180, 2),
          U1(11, 110, 192, 36, 75, 43, 157, 40)
        }))))
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLineTraceEnabled"] = function(_ARG_0_, _ARG_1_)
    do
      if not (_ARG_1_ and _ARG_1_.TestLocation) or _ARG_1_.TestLocation.LineTraceEnabled == nil then
        return true
      end
      do return _ARG_1_.TestLocation.LineTraceEnabled end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IterateTargetLocation"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_(_ARG_1_) then
        return true
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_2_(_ARG_1_ + FVector(U2[U1(10, 58, 172, 61, 73, 38, 128, 37, 172, 7, 84, 135, 109, 167, 100, 165, 180, 108, 241, 11, 182, 18, 224, 46, 182, 24, 23, 197, 51, 178, 58, 185, 161, 73)].X * _ARG_1_:ToString(), U2[U1(10, 58, 172, 61, 73, 38, 128, 37, 172, 7, 84, 135, 109, 167, 100, 165, 180, 108, 241, 11, 182, 18, 224, 46, 182, 24, 23, 197, 51, 178, 58, 185, 161, 73)].Y * _ARG_1_:ToString(), U1(10, 58, 172, 61, 73, 38, 128, 37, 172, 7, 84, 135, 109, 167, 100, 165, 180, 108, 241, 11, 182, 18, 224, 46, 182, 24, 23, 197, 51, 178, 58, 185, 161, 73)) * (_ARG_0_.Config and _ARG_0_.Config.TestLocation and _ARG_0_.Config.TestLocation.OffsetValue or 100)) then
        return true
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LineTraceHit"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.TraceActorsToIgnore then
        _ARG_0_.TraceActorsToIgnore = slua.Array(UEnums.EPropertyClass.Object, (import((U1(75, 73, 131, 32, 67, 55, 128, 99, 134, 7, 19, 211, 35, 231, 57, 200, 247, 94, 255, 16)))))
      end
      do return import((U1(47, 115, 147, 63, 79, 51, 167, 53, 176, 29, 17, 215, 1, 235, 117, 251, 245, 88, 233))).LineTraceSingle(_ARG_0_.Owner.Object, _ARG_1_, _ARG_2_, 0, true, _ARG_0_.TraceActorsToIgnore, import((U1(33, 94, 146, 51, 93, 3, 145, 46, 182, 14, 32, 200, 44, 225, 114))).None, import((U1(75, 73, 131, 32, 67, 55, 128, 99, 134, 7, 19, 211, 35, 231, 57, 193, 253, 94, 194, 7, 169, 2, 232, 8)))(), true, FLinearColor.Red, FLinearColor.Green, 1) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ForceHolsterBeforeParachuteJump"] = function(_ARG_0_, _ARG_1_)
    do
      if Client or not slua.isValid(_ARG_1_) then
        return
      end
      if not slua.isValid(_ARG_1_.GetWeaponManager and _ARG_1_:GetWeaponManager()) then
        return
      end
      if (_ARG_1_.GetWeaponManager and _ARG_1_:GetWeaponManager()).bIsSwitching == true then
      end
      if (_ARG_1_.GetWeaponManager and _ARG_1_:GetWeaponManager()):GetCurrentUsingPropSlot() ~= import((U1(33, 73, 149, 32, 92, 46, 130, 41, 148, 12, 21, 202, 34, 236, 71, 251, 251, 90, 195, 14, 181, 3))).SWPS_None then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ParachuteJump"] = function(_ARG_0_)
    do
      if _ARG_0_.Owner then
        print(bWriteLog and U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 138, 22, 246, 29, 176, 17, 17, 222, 56, 216, 114, 244, 244, 26, 211, 6, 171, 21, 224))
        _ARG_0_:_ForceHolsterBeforeParachuteJump(_ARG_0_.Owner.Object)
        if slua.isValid((_ARG_0_.Owner:GetControllerSafety())) then
          if not _ARG_0_.Owner:GetEnsure() then
            if _ARG_0_.Owner:GetControllerSafety():GetCurrentStateType() ~= import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteJump and _ARG_0_.Owner:GetControllerSafety():GetCurrentStateType() ~= import((U1(33, 73, 148, 51, 94, 34, 160, 53, 179, 12))).State_ParachuteOpen then
              if _ARG_0_.Config and _ARG_0_.Config.OpenParachuteAfterTeleport == true then
              else
              end
            end
          else
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreTeleport"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      _ARG_0_.Config = _ARG_0_:GetConfig(_ARG_1_)
      if _ARG_0_.Config and _ARG_0_.Config.StopAllSkillsOnTeleport == true then
      end
      if _ARG_0_.Owner.PoseState == U3.Crouch or _ARG_0_.Owner.PoseState == U3.Prone then
      end
      if _ARG_0_.Owner.PoseState == U3.GunADS then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetConfig"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229))) then
        return
      end
      if not GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_] then
        return
      end
      if GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_].HideAllUI == nil then
        GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_].HideAllUI = true
      end
      do return GetCurrentConfig((U1(48, 127, 140, 55, 90, 40, 134, 56, 128, 6, 26, 220, 36, 229)))[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostTeleport"] = function(_ARG_0_)
    do
      _ARG_0_:CheckTLog()
      _ARG_0_:StartWaitingClientLoading()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckTLog"] = function(_ARG_0_)
    do
      if not _ARG_0_.Config then
        return
      end
      if not SubsystemMgr:Get((U1(32, 73, 163, 61, 71, 42, 155, 34, 151, 37, 27, 221, 30, 247, 117, 250, 237, 89, 228, 7, 183))) then
        return
      end
      if _ARG_0_.Config.GameTLogId and _ARG_0_.Config.GameTLogId ~= 0 then
      end
      if _ARG_0_.Config.PlayerTLogId and _ARG_0_.Config.PlayerTLogId ~= 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientTeleportStartCallback"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not (_ARG_1_ and _ARG_0_.Owner) or not Client then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientTeleportCallback"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not (_ARG_1_ and _ARG_0_.Owner) or not Client then
        return
      end
      _ARG_0_.Config = _ARG_0_:GetConfig(_ARG_5_)
      if not _ARG_0_.Config then
        return
      end
      if _ARG_0_.PreTeleportPawnDrivenByShow == true and _ARG_0_.PreTeleportShowFinished ~= true then
      else
      end
      _ARG_0_.PreTeleportClientLanded = true
      if _ARG_0_:CheckLoading(_ARG_2_, _ARG_0_.Config) then
      else
      end
      if _ARG_0_.Config and _ARG_0_.Config.AudioOnPreTeleport then
        if _ARG_0_.Config.AudioOnPreTeleport2D then
          if _ARG_0_:IsAutonomousProxy() then
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = _ENV[245]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetPreTeleportSequencePaths"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) then
        return nil, nil, nil
      end
      if not _ARG_1_.LevelSequenceActorPath or _ARG_1_.LevelSequenceActorPath == U1() then
      end
      if _ARG_1_.BindPlayerPawnName and _ARG_1_.BindPlayerPawnName ~= U1() and _ARG_1_.BindLocalPlayerPawn ~= true and (not _ARG_1_.ShowPawnActorPath or _ARG_1_.ShowPawnActorPath == U1()) then
      end
      do return _ARG_1_.LevelSequencePath, U2.LevelSequenceActorPath, U2.ShowPawnActorPath end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not Client or not _ARG_0_:IsLocal() then
        return false
      end
      if not (_ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) and _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) ~= U1() and _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_)) or _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) == U1() then
        return false
      end
      if _ARG_1_.BindPlayerPawnName and _ARG_1_.BindPlayerPawnName ~= U1() and _ARG_1_.BindLocalPlayerPawn ~= true and (not _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) or _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) == U1()) then
        return false
      end
      _ARG_0_.PreTeleportSeqOnFailed = _ARG_2_
      _ARG_0_.PreTeleportSeqOnStarted = _ARG_3_
      if _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_) then
      end
      _ARG_0_.PreTeleportSeqLoadHandle = _ARG_0_:AsyncLoadAssetArray({
        _ARG_0_:_GetPreTeleportSequencePaths(_ARG_1_)
      }, function()
        PreTeleportSeqLoadHandle = nil
        if not (U1 == PreTeleportSeqSerial and Owner) or not U2.slua.isValid(Owner.Object) then
          return
        end
        if U3 then
          if not _ENV:_SpawnPreTeleportShowPawn(U3, U4, U1, function()
            _ENV:_StartPreTeleportSequence(U1, U2, U3, U4, U5, U6)
            return
          end) then
          end
        else
          _ENV:_StartPreTeleportSequence(U5, U6, U7, U1, nil, nil)
        end
        return
      end)
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_NotifyPreTeleportSeqFailed"] = function(_ARG_0_)
    do
      _ARG_0_.PreTeleportSeqOnStarted = nil
      _ARG_0_.PreTeleportSeqOnFailed = nil
      if _ARG_0_.PreTeleportSeqOnFailed then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_NotifyPreTeleportSeqStarted"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 57, 235, 8, 186, 31, 29, 250, 47, 247, 83, 252, 232, 95, 240, 29, 184, 19, 199, 9),
        U1(21, 73, 148, 51, 88, 51, 145, 40, 227, 58, 0, 219, 63, 246, 71, 229, 245, 83)
      }))
      _ARG_0_.PreTeleportSeqOnStarted = nil
      _ARG_0_.PreTeleportSeqOnFailed = nil
      if _ARG_0_.PreTeleportSeqOnStarted then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SpawnPreTeleportShowPawn"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not slua.loadClass(_ARG_1_) or not slua.isValid(CGameWorld) then
        return false
      end
      if not _ARG_0_.Owner or not slua.isValid(_ARG_0_.Owner.Object) then
        return false
      end
      if not slua.isValid((CGameWorld:SpawnActor(slua.loadClass(_ARG_1_), _ARG_0_.Owner:K2_GetActorLocation(), _ARG_0_.Owner:K2_GetActorRotation(), nil))) then
        return false
      end
      if not slua.isValid(CGameWorld:SpawnActor(slua.loadClass(_ARG_1_), _ARG_0_.Owner:K2_GetActorLocation(), _ARG_0_.Owner:K2_GetActorRotation(), nil).CharacterAvatarComp2_BP) then
        return false
      end
      _ARG_0_.PreTeleportShowPawn = CGameWorld:SpawnActor(slua.loadClass(_ARG_1_), _ARG_0_.Owner:K2_GetActorLocation(), _ARG_0_.Owner:K2_GetActorRotation(), nil)
      _ARG_0_.PreTeleportSeqAvatarTimer = _ARG_0_:AddGameTimer(U2.AvatarLoadTimeout, false, function()
        PreTeleportSeqAvatarTimer = nil
        U1.print(U1.bWriteLog and U1.table.concat({
          U2(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 36, 244, 29, 164, 23, 52, 216, 56, 198, 98, 245, 225, 74, 239, 0, 190, 52, 252, 3),
          U2(19, 74, 129, 37, 68, 103, 149, 58, 162, 29, 21, 200, 109, 238, 120, 232, 240, 10, 228, 11, 183, 18, 235, 9, 167, 85, 68, 218, 49, 243, 126, 185, 229, 84, 249, 5, 171, 30)
        }))
        U3()
        return
      end)
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_StartPreTeleportSequence"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
        return
      end
      if _ARG_1_.BindPlayerPawnName then
        if _ARG_1_.BindLocalPlayerPawn == true then
          _ARG_0_.PreTeleportPawnDrivenByShow = true
        else
        end
      end
      if _ARG_1_.DisablePlayerPawnSpawnTrack == true and _ARG_1_.BindPlayerPawnName and _ARG_1_.BindPlayerPawnName ~= U1() then
      end
      if not slua.isValid((Game:PlayLevelSequence(_ARG_0_.Owner and _ARG_0_.Owner.Object, _ARG_2_, _ARG_5_ or import((U1(47, 115, 147, 63, 79, 51, 185, 45, 183, 1, 56, 211, 47, 240, 118, 251, 237))).MakeTransform(_ARG_1_.Location or FVector(0, 0, 0), _ARG_1_.Rotation or FRotator(0, 0, 0), FVector(1, 1, 1)), _ARG_3_, true, {
        [_ARG_1_.BindPlayerPawnName] = _ARG_0_.PreTeleportShowPawn
      }, _ARG_0_.Owner and _ARG_0_.Owner.Object, {
        _ARG_1_.BindPlayerPawnName
      }))) then
        return
      end
      _ARG_0_.PreTeleportSeqActor = Game:PlayLevelSequence(_ARG_0_.Owner and _ARG_0_.Owner.Object, _ARG_2_, _ARG_5_ or import((U1(47, 115, 147, 63, 79, 51, 185, 45, 183, 1, 56, 211, 47, 240, 118, 251, 237))).MakeTransform(_ARG_1_.Location or FVector(0, 0, 0), _ARG_1_.Rotation or FRotator(0, 0, 0), FVector(1, 1, 1)), _ARG_3_, true, {
        [_ARG_1_.BindPlayerPawnName] = _ARG_0_.PreTeleportShowPawn
      }, _ARG_0_.Owner and _ARG_0_.Owner.Object, {
        _ARG_1_.BindPlayerPawnName
      })
      do return end
      _ARG_2_ = _ENV[161]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnPreTeleportSequenceEnd"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ ~= _ARG_0_.PreTeleportSeqSerial then
        return
      end
      print(bWriteLog and table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 56, 234, 44, 161, 28, 48, 207, 49, 247, 119, 246, 246, 78, 211, 23, 187, 18, 241, 2),
        U1(7, 127, 165, 60, 78)
      }))
      _ARG_0_.PreTeleportSeqActor = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopPreTeleportSequence"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
        _ARG_0_.PreTeleportSeqOnFailed = nil
      end
      _ARG_0_.PreTeleportSeqOnStarted = nil
      _ARG_0_.PreTeleportPawnDrivenByShow = nil
      _ARG_0_.PreTeleportSeqSerial = (_ARG_0_.PreTeleportSeqSerial or 0) + 1
      if _ARG_0_.PreTeleportSeqLoadHandle then
        _ARG_0_:CancelAsyncLoad(_ARG_0_.PreTeleportSeqLoadHandle)
        _ARG_0_.PreTeleportSeqLoadHandle = nil
      end
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 233, 40, 243, 86, 255, 245, 94, 241, 16, 142, 30, 233, 25, 161)))
      _ARG_0_.PreTeleportSeqActor = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnPreTeleportSeqPlayStarted"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 142, 30, 233, 25, 161)))
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 158, 18, 232, 29, 170, 45, 13, 199, 56, 224)))
      _ARG_0_:_ReleasePreTeleportLevelHold()
      _ARG_0_.PreTeleportShowFinished = nil
      _ARG_0_.PreTeleportClientLanded = nil
      if _ARG_1_.HoldStreamingAtTarget == true and _ARG_3_ then
        if 0 < _ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(44, 117, 140, 54, 121, 51, 134, 41, 162, 4, 29, 212, 42, 195, 99, 221, 245, 88, 247, 7, 174, 51, 225, 16, 178, 0))) then
          _ARG_0_.PreTeleportLevelHoldDelayTimer = _ARG_0_:AddGameTimer(_ARG_0_:_GetPreTeleportSeqConfigValue(_ARG_1_, (_ENV(44, 117, 140, 54, 121, 51, 134, 41, 162, 4, 29, 212, 42, 195, 99, 221, 245, 88, 247, 7, 174, 51, 225, 16, 178, 0))), false, function()
            PreTeleportLevelHoldDelayTimer = nil
            _ENV:_ArmPreTeleportLevelHold(U1, U2)
            return
          end)
        else
        end
      end
      if _ARG_1_.HidePlayerPawnDuringSequence == true and U1.slua.isValid(_ARG_2_) then
        _ARG_0_.PreTeleportPawnHidden = true
        _ARG_0_:SetPlayerCharacterHiddenInGame(_ARG_2_, true)
      end
      if _ARG_1_.BindLocalPlayerPawn == true and U1.slua.isValid(_ARG_2_) then
        _ARG_0_:_SetPreTeleportControllerRotationDisabled(_ARG_2_, true)
      end
      if _ARG_1_.DisableMovementDuringSequence == true and U1.slua.isValid(_ARG_2_) then
        _ARG_0_:_DetachBeCarriedBackForSequence(_ARG_2_)
        _ARG_0_:_SetPreTeleportMovementDisabled(_ARG_2_, true)
        _ARG_0_:_SetPreTeleportMoveInputIgnored(true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ArmPreTeleportLevelHold"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.PreTeleportLevelHeld or _ARG_0_.PreTeleportShowFinished or _ARG_0_.PreTeleportClientLanded then
        return
      end
      if _ARG_2_ ~= nil and _ARG_2_ ~= _ARG_0_.PreTeleportSeqSerial then
        return
      end
      if not SubsystemMgr:Get((U1(40, 127, 150, 55, 70, 20, 128, 62, 166, 8, 25, 211, 35, 229, 90, 238, 230))) then
        return
      end
      _ARG_0_.PreTeleportLevelHeld = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[1]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_DetachBeCarriedBackForSequence"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_1_.IsInBeCarriedBackState or not _ARG_1_:IsInBeCarriedBackState() then
        return
      end
      if slua.isValid(_ARG_1_.GetCarryBackComp and _ARG_1_:GetCarryBackComp() or nil) and (_ARG_1_.GetCarryBackComp and _ARG_1_:GetCarryBackComp() or nil).StopBeCarriedBack then
        if not _ARG_1_:IsInBeCarriedBackState() then
          return
        end
      end
      if not slua.isValid(_ARG_1_.RootComponent) or not slua.isValid(_ARG_1_.RootComponent:GetAttachParent()) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportMovementDisabled"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_ and _ARG_1_.STCharacterMovement) then
        return
      end
      if _ARG_2_ then
        if _ARG_0_.PreTeleportMovementMode ~= nil then
          return
        end
        _ARG_0_.PreTeleportMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).MovementMode
        _ARG_0_.PreTeleportCustomMovementMode = (_ARG_1_ and _ARG_1_.STCharacterMovement).CustomMovementMode
        _ARG_0_.PreTeleportMovementTickEnabled = (_ARG_1_ and _ARG_1_.STCharacterMovement):IsComponentTickEnabled()
        if _ARG_0_.PreTeleportMovementMode == U1 then
          _ARG_0_.PreTeleportMovementMode = U2
          _ARG_0_.PreTeleportCustomMovementMode = 0
          _ARG_0_.PreTeleportMovementTickEnabled = true
        end
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          _ARG_0_.PreTeleportMoveableSaved = (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).bMoveable
        end
        _ARG_0_.PreTeleportMovementGuardTimer = _ARG_0_:AddGameTimer(0.1, true, function()
          if PreTeleportMovementMode == nil then
            return
          end
          if not U1.slua.isValid(U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil) then
            return
          end
          if (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil):IsComponentTickEnabled() or (U1.slua.isValid(Owner and Owner.Object) and (Owner and Owner.Object).STCharacterMovement or nil).MovementMode ~= U2 then
          end
          return
        end)
      else
        _ARG_0_.PreTeleportMovementMode = nil
        _ARG_0_.PreTeleportCustomMovementMode = nil
        _ARG_0_.PreTeleportMovementTickEnabled = nil
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) and _ARG_0_.PreTeleportMoveableSaved ~= nil then
          _ARG_0_.PreTeleportMoveableSaved = nil
        end
        if _ARG_0_.PreTeleportMovementMode ~= nil then
          if _ARG_1_.bDead ~= true then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnOwnerExitState"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not Client or _ARG_2_ ~= U1.BeCarriedBack or _ARG_0_.PreTeleportMovementMode == nil then
        return
      end
      if not slua.isValid(slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) and (_ARG_0_.Owner and _ARG_0_.Owner.Object).STCharacterMovement or nil) then
        return
      end
      if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
        if _ARG_0_.PreTeleportMoveableSaved == nil then
          _ARG_0_.PreTeleportMoveableSaved = (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()).bMoveable
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1[88]
    end
  end,
  ["_SetPreTeleportControllerRotationDisabled"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_2_ then
        if _ARG_0_.PreTeleportControllerRotationSaved then
          return
        end
        _ARG_0_.PreTeleportControllerRotationSaved = {
          Yaw = _ARG_1_.bUseControllerRotationYaw,
          Pitch = _ARG_1_.bUseControllerRotationPitch,
          Roll = _ARG_1_.bUseControllerRotationRoll
        }
        _ARG_1_.bUseControllerRotationYaw = false
        _ARG_1_.bUseControllerRotationPitch = false
        _ARG_1_.bUseControllerRotationRoll = false
        print(bWriteLog and table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 36, 225, 8, 131, 11, 1, 254, 56, 254, 98, 233, 235, 72, 244, 49, 165, 9, 224, 30),
          U1(11, 118, 140, 55, 88, 21, 155, 56, 162, 29, 29, 213, 35, 198, 126, 250, 245, 72, 252, 7, 190, 87, 224, 21, 160, 24, 6, 198, 56, 246)
        }))
      else
        if not _ARG_0_.PreTeleportControllerRotationSaved then
          return
        end
        _ARG_0_.PreTeleportControllerRotationSaved = nil
        _ARG_1_.bUseControllerRotationYaw = _ARG_0_.PreTeleportControllerRotationSaved.Yaw
        _ARG_1_.bUseControllerRotationPitch = _ARG_0_.PreTeleportControllerRotationSaved.Pitch
        _ARG_1_.bUseControllerRotationRoll = _ARG_0_.PreTeleportControllerRotationSaved.Roll
        if _ARG_1_:K2_GetActorRotation().Pitch ~= 0 or _ARG_1_:K2_GetActorRotation().Roll ~= 0 then
        end
        if slua.isValid(_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) and (_ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()):GetControlRotation().Roll ~= 0 then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ApplyPreTeleportClientShowState"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client or type(_ARG_1_) ~= U1(16, 123, 130, 62, 79) then
        return
      end
      _ARG_0_.PreTeleportActiveSeqConfig = _ARG_1_
      if not _ARG_0_.Owner then
        return
      end
      if not slua.isValid(_ARG_0_.Owner.Object) then
        return
      end
      if not _ARG_0_.Owner:IsLocallyControlled() then
        return
      end
      if _ARG_1_.ExitScopeOnSequence == true then
      end
      if _ARG_1_.ForceTPPDuringSequence == true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportClientShowState"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      _ARG_0_.PreTeleportActiveSeqConfig = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportForceTPP"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ then
        if _ARG_0_.PreTeleportForceTPPApplied or not slua.isValid(_ARG_1_) then
          return
        end
        _ARG_0_.PreTeleportForceTPPApplied = true
        if _ARG_1_:GetIsFPP() then
          _ARG_1_.bForceChangePersonPerspective = true
          _ARG_0_.PreTeleportChangedPP = true
        end
        _ARG_0_.PreTeleportSwitchPPWasDisabled = _ARG_1_:IsPawnStateDisabled(U1.SwitchPP)
        return
      end
      if not _ARG_0_.PreTeleportForceTPPApplied then
        return
      end
      _ARG_0_.PreTeleportForceTPPApplied = nil
      _ARG_0_.PreTeleportChangedPP = nil
      _ARG_0_.PreTeleportSwitchPPWasDisabled = nil
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_0_.PreTeleportSwitchPPWasDisabled then
      end
      if _ARG_0_.PreTeleportChangedPP then
        if _ARG_1_.bDead ~= true then
        end
        _ARG_1_.bForceChangePersonPerspective = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPreTeleportMoveInputIgnored"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      if _ARG_1_ then
        if _ARG_0_.PreTeleportMoveInputIgnored then
          return
        end
        if not slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety()) then
          return
        end
        _ARG_0_.PreTeleportMoveInputPC, _ARG_0_.PreTeleportMoveInputIgnored = _ARG_0_.Owner and _ARG_0_.Owner.GetPlayerControllerSafety and _ARG_0_.Owner:GetPlayerControllerSafety(), true
      else
        if not _ARG_0_.PreTeleportMoveInputIgnored then
          return
        end
        _ARG_0_.PreTeleportMoveInputIgnored = nil
        _ARG_0_.PreTeleportMoveInputPC = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportMovement"] = function(_ARG_0_)
    do
      _ARG_0_:_SetPreTeleportMoveInputIgnored(false)
      if _ARG_0_.PreTeleportMovementMode == nil then
        return
      end
      if slua.isValid(_ARG_0_.Owner and _ARG_0_.Owner.Object) then
      else
        _ARG_0_.PreTeleportMovementMode = nil
        _ARG_0_.PreTeleportCustomMovementMode = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_StopPreTeleportSeqShowHandling"] = function(_ARG_0_)
    do
      _ARG_0_.PreTeleportShowFinished = true
      _ARG_0_.PreTeleportPawnDrivenByShow = nil
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 158, 18, 232, 29, 170, 45, 13, 199, 56, 224)))
      _ARG_0_:_RestorePreTeleportPawnVisibility()
      _ARG_0_:_RestorePreTeleportMovement()
      _ARG_0_:_SetPreTeleportControllerRotationDisabled(_ARG_0_.Owner and _ARG_0_.Owner.Object, false)
      _ARG_0_:_RestorePreTeleportClientShowState()
      if not _ARG_0_.PreTeleportLevelHeld then
        return
      end
      if _ARG_0_.PreTeleportClientLanded then
        _ARG_0_:_ReleasePreTeleportLevelHold()
        return
      end
      if not _ARG_0_.PreTeleportLevelHoldTimer then
        _ARG_0_.PreTeleportLevelHoldTimer = _ARG_0_:AddGameTimer(U1.HoldReleaseTimeout, false, function()
          PreTeleportLevelHoldTimer = nil
          _ENV:_ReleasePreTeleportLevelHold()
          return
        end)
        U2.print(U2.bWriteLog and U2.table.concat({
          _ENV(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 133, 36, 240, 19, 163, 41, 22, 207, 9, 247, 107, 252, 244, 85, 242, 6, 153, 2, 229, 63),
          _ENV(12, 117, 151, 26, 75, 41, 144, 32, 170, 7, 19, 154, 58, 227, 126, 253, 180, 76, 255, 16, 250, 27, 229, 18, 183, 16, 10, 205, 125, 240, 98, 255, 235, 72, 229, 82, 184, 2, 248, 9),
          _ENV(5, 105, 137, 60, 77, 103, 156, 35, 175, 13)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ReleasePreTeleportLevelHold"] = function(_ARG_0_)
    do
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 158, 18, 232, 29, 170, 45, 13, 199, 56, 224)))
      if not _ARG_0_.PreTeleportLevelHeld then
        return
      end
      _ARG_0_.PreTeleportLevelHeld = nil
      _ARG_0_.PreTeleportShowFinished = nil
      _ARG_0_.PreTeleportClientLanded = nil
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(52, 104, 133, 6, 79, 43, 145, 60, 172, 27, 0, 246, 40, 244, 114, 229, 220, 69, 252, 6, 142, 30, 233, 25, 161)))
      if U1.SubsystemMgr:Get((_ENV(40, 127, 150, 55, 70, 20, 128, 62, 166, 8, 25, 211, 35, 229, 90, 238, 230))) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[147]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RestorePreTeleportPawnVisibility"] = function(_ARG_0_)
    do
      if not _ARG_0_.PreTeleportPawnHidden then
        return
      end
      _ARG_0_.PreTeleportPawnHidden = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_DestroyPreTeleportShowPawn"] = function(_ARG_0_)
    do
      _ARG_0_.PreTeleportShowPawn = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSimulatedAndNotSpectating"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_1_:IsSimulated() and not (U1.slua.isValid((GetPlayerController())) and GetPlayerController():IsInSpectating()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPlayerCharacterHiddenInGame"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ then
        _ARG_1_:SetActorHiddenInGame(true)
      elseif not _ARG_1_.CharacterHide or not _ARG_1_.CharacterHide.bCharacterHideIngame then
        _ARG_1_:SetActorHiddenInGame(false)
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 137, 18, 240, 44, 191, 24, 29, 207, 47, 209, 111, 248, 246, 91, 227, 6, 175, 21, 220, 5),
        U1(0, 126, 133, 60, 99, 41, 179, 45, 174, 12, 84, 159, 62, 162, 63, 172, 231, 3)
      }), _ARG_2_, _ARG_1_:ToString()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckLoading"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.Owner:IsAutonomousProxy() then
      elseif Client and slua.isValid((U1.GetPlayerController())) and U1.GetPlayerController():IsSpectator() and slua.isValid(U1.GetPlayerController():GetCurPlayerCharacter()) and U1.GetPlayerController():GetCurPlayerCharacter().PlayerKey == _ARG_0_.Owner.PlayerKey then
      end
      if not (SubsystemMgr:Get((U2(40, 127, 150, 55, 70, 20, 128, 62, 166, 8, 25, 211, 35, 229, 90, 238, 230))) and true) or _ARG_2_.NotShowLoading then
        return false
      end
      if _ARG_2_ and _ARG_2_.SkipLoadingUI == true then
      end
      if _ARG_0_.LoadingEffectReason == nil then
      end
      do return true end
      do return end
      _ARG_1_ = U1[147]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartWaitingClientLoading"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 137, 3, 229, 14, 167, 46, 5, 195, 41, 251, 105, 254, 199, 86, 233, 23, 164, 19, 216, 3),
        U1(5, 126, 137, 60, 77, 103, 209, 63)
      }), _ARG_0_.Owner:ToString()))
      _ARG_0_.WaitingClientLoadingTimer = _ARG_0_:AddGameTimer(U2, false, function()
        print(bWriteLog and string.format(table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 137, 3, 229, 14, 167, 46, 5, 195, 41, 251, 105, 254, 199, 86, 233, 23, 164, 19, 216, 3),
          U1(5, 126, 137, 60, 77, 103, 163, 45, 170, 29, 29, 212, 42, 193, 123, 224, 241, 68, 228, 46, 181, 22, 224, 21, 189, 30, 48, 195, 48, 247, 117, 185, 240, 83, 237, 23, 165, 18, 224, 76),
          U1(65, 105)
        }), U2.Owner:ToString()))
        U2:OnReceiveClientTeleportLoadingFinish()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLevelStreamingLoadEnd"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 200, 25, 165, 28, 8, 249, 41, 224, 98, 248, 233, 83, 238, 21, 134, 8, 245, 8),
        U1(33, 116, 132, 114, 15, 52)
      }), _ARG_3_))
      _ARG_0_:RemoveCommonEvent(EVENTTYPE_LEVELSTREAMING, EVENTID_LEVELSTREAMING_LOAD_END)
      if _ARG_0_.Config then
        _ARG_0_:OnClientLanded()
      end
      _ARG_0_:RPC_Server_NotifyTeleportLoadingFinish()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Server_NotifyTeleportLoadingFinish"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 128, 28, 22, 220, 56, 224, 88, 215, 235, 78, 233, 20, 179, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 11, 155, 45, 167, 0, 26, 221, 11, 235, 121, 224, 231, 66, 176, 71, 169)
      }), _ARG_0_.Owner:ToString()))
      _ARG_0_:OnReceiveClientTeleportLoadingFinish()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnReceiveClientTeleportLoadingFinish"] = function(_ARG_0_)
    do
      if not _ARG_0_.WaitingClientLoadingTimer then
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 214, 25, 176, 28, 13, 220, 56, 209, 107, 240, 225, 84, 244, 38, 175, 11, 241, 28),
          U1(11, 104, 148, 30, 69, 38, 144, 37, 173, 14, 50, 211, 35, 235, 100, 225, 180, 68, 255, 66, 141, 22, 237, 8, 186, 23, 3, 233, 49, 251, 98, 247, 240, 118, 239, 19, 174, 14, 250, 11),
          U1(48, 115, 141, 55, 88, 107, 212, 62, 166, 29, 1, 200, 35)
        }))))
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 214, 25, 176, 28, 13, 220, 56, 209, 107, 240, 225, 84, 244, 38, 175, 11, 241, 28),
        U1(11, 104, 148, 30, 69, 38, 144, 37, 173, 14, 50, 211, 35, 235, 100, 225, 180, 15, 227)
      }), _ARG_0_.Owner:ToString()))
      _ARG_0_:TryRemoveNamedGameTimer((U1(51, 123, 137, 38, 67, 41, 147, 15, 175, 0, 17, 212, 57, 206, 120, 232, 240, 67, 254, 5, 142, 30, 233, 25, 161)))
      _ARG_0_.LuaDelegate:Broadcast(U2, _ARG_0_.Owner)
      _ARG_0_.LuaDelegate:Remove(U2)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ListenOnClientTeleportLoadingFinished"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.LuaDelegate:Add(_ENV, _ARG_1_, _ARG_2_)
      do return _ARG_0_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientPreCheckLoadingEffect"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 27, 237, 25, 189, 13, 52, 216, 56, 209, 111, 252, 231, 81, 204, 29, 171, 3, 253, 2),
        U1(3, 95, 134, 52, 79, 36, 128, 108, 230, 26)
      }), _ARG_1_))
      if _ARG_0_.MarkTeleportFailed then
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 27, 237, 25, 189, 13, 52, 216, 56, 209, 111, 252, 231, 81, 204, 29, 171, 3, 253, 2),
          U1(3, 95, 134, 52, 79, 36, 128, 108, 169, 28, 7, 206, 109, 207, 118, 251, 255, 126, 245, 14, 191, 7, 235, 14, 167, 63, 5, 195, 49, 247, 99, 181, 164, 72, 229, 6, 191, 21, 250)
        }))))
        return
      end
      if _ARG_0_.LoadingEffectReason == nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckLoadingEffect"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:IsLocal() then
        return
      end
      if not _ARG_1_ or not _ARG_1_.LoadingEffect then
        return
      end
      if not _ARG_1_.LoadingEffect.Type or not _ARG_1_.LoadingEffect.Param then
        return
      end
      _ARG_0_.LoadingEffectReason = _ARG_2_
      if _ARG_1_.LoadingEffect.Type == U1(55, 121, 146, 55, 79, 41, 177, 42, 165, 12, 23, 206) then
        if slua.isValid((slua.loadObject(_ARG_1_.LoadingEffect.Param .. U1(59, 89)))) then
          _ARG_0_.LoadingEffectObject = import((U1(55, 121, 146, 55, 79, 41, 181, 60, 179, 12, 21, 200, 44, 236, 116, 236, 199, 94, 241, 22, 179, 20, 247))).PlayDynamicScreenAppearance(_ARG_0_.Owner.Object, _ARG_0_.Owner.Object, import((U1(55, 78, 165, 42, 94, 53, 149, 11, 162, 4, 17, 202, 33, 227, 110, 218, 224, 75, 228, 11, 185, 4))).GetClassDefaultObject((slua.loadObject(_ARG_1_.LoadingEffect.Param .. U1(59, 89)))).AppearanceName, (slua.loadObject(_ARG_1_.LoadingEffect.Param .. U1(59, 89))))
        end
      elseif _ARG_1_.LoadingEffect.Type == U1(49, 83) and UIManager.UI_Config_InGame[_ARG_1_.LoadingEffect.Param] then
        _ARG_0_.LoadingEffectObject = UIManager.ShowUI(UIManager.UI_Config_InGame[_ARG_1_.LoadingEffect.Param])
      end
      if _ARG_0_.LoadingEffectObject then
        _ARG_0_.StartLoadingEffectTime = U3.GetRealTimeSeconds(_ARG_0_.Owner.Object)
        _ARG_0_.LoadingEffectObjectTimeoutTimer = _ARG_0_:AddGameTimer(U2, false, function()
          print(bWriteLog and string.format((table.concat({
            U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 31, 225, 31, 184, 53, 11, 203, 57, 251, 105, 254, 193, 92, 230, 23, 169, 19, 180, 24),
            U1(13, 119, 133, 61, 95, 51)
          }))))
          U2:TryDestroyLoadingEffect()
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[61]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientLanded"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 149, 25, 199, 16, 186, 28, 10, 222, 17, 243, 105, 253, 225, 94))
      if not (_ARG_0_.Config and Client) or not _ARG_0_.Owner then
        return
      end
      if slua.isValid((_ARG_0_.Owner:GetControllerSafety())) and not _ARG_0_.Owner.bEnsure then
        _ARG_0_.Owner:GetControllerSafety().bAutoSprint = false
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryDestroyLoadingEffect"] = function(_ARG_0_)
    do
      if not _ARG_0_:IsLocal() then
        return
      end
      _ARG_0_:TryRemoveNamedGameTimer((_ENV(40, 117, 129, 54, 67, 41, 147, 9, 165, 15, 17, 217, 57, 205, 117, 227, 241, 73, 228, 54, 179, 26, 225, 19, 166, 13, 48, 195, 48, 247, 117)))
      if _ARG_0_.Config and _ARG_0_.Config.LoadingEffect and _ARG_0_.Config.LoadingEffect.NoDestroy then
        _ARG_0_:ClearLoadingEffectObject()
      elseif _ARG_0_.LoadingEffectObject then
        if _ARG_0_.LoadingEffectObject.End and not _ARG_0_.LoadingEffectObject.bHasClosed then
        elseif _ARG_0_.LoadingEffectObject.SetLifeSpan then
          if _ARG_0_.StartLoadingEffectTime and 1 > U1.GetRealTimeSeconds(_ARG_0_.Owner.Object) - _ARG_0_.StartLoadingEffectTime then
          else
          end
        else
        end
      end
      _ARG_0_.LoadingEffectReason = nil
      if _ARG_0_.Config and _ARG_0_.Config.HideAllUI then
        _ARG_0_:TryRemoveNamedGameTimer((_ENV(44, 115, 132, 55, 107, 43, 152, 25, 138, 61, 29, 215, 40, 237, 98, 253, 192, 67, 253, 7, 168)))
        _ARG_0_.HideAllUITimeoutTimer = _ARG_0_:AddGameTimer(2, false, function()
          print(bWriteLog and string.format((table.concat({
            U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 142, 5, 253, 56, 182, 10, 16, 216, 50, 235, 75, 246, 229, 94, 233, 28, 173, 34, 242, 10),
            U1(1, 121, 148, 114, 98, 46, 144, 41, 130, 5, 24, 239, 4, 214, 126, 228, 241, 69, 229, 22)
          }))))
          EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_EXIT_TEAM_SHOW)
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearLoadingEffectObject"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format((table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 27, 225, 29, 161, 53, 11, 203, 57, 251, 105, 254, 193, 92, 230, 23, 169, 19, 219, 14),
        U1(14, 127, 131, 38)
      }))))
      if _ARG_0_.Config and _ARG_0_.Config.AudioOnPreTeleportLoop and _ARG_0_.AudioOnPreTeleportID then
        _ARG_0_.AudioOnPreTeleportID = nil
      end
      _ARG_0_.LoadingEffectObject = nil
      _ARG_0_:CheckHideAllUI(false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckHideAllUI"] = function(_ARG_0_, _ARG_1_)
    do
      if not (Client and _ARG_0_:IsLocal() and _ARG_0_.Config) or not _ARG_0_.Config.HideAllUI then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 153, 31, 225, 31, 184, 49, 13, 206, 56, 211, 107, 245, 209, 115, 160, 16, 130, 14, 240, 9),
        U1(68, 39, 192, 119, 89)
      }), _ARG_1_))
      if _ARG_1_ then
        EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_ENTER_TEAM_SHOW)
      else
        EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_EXIT_TEAM_SHOW)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RPC_Client_NotifyTeleportFailed"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 144, 21, 13, 207, 51, 230, 88, 215, 235, 78, 233, 20, 179, 51, 241, 0),
        U1(1, 106, 143, 32, 94, 1, 149, 37, 175, 12, 16, 150, 109, 206, 120, 232, 240, 67, 254, 5, 159, 17, 226, 25, 176, 13, 54, 207, 60, 225, 104, 247, 164, 7, 160, 87, 185)
      }), _ARG_0_.LoadingEffectReason))
      _ARG_0_:StopPreTeleportSequence(true)
      _ARG_0_:_ReleasePreTeleportLevelHold()
      _ARG_0_:TryDestroyLoadingEffect()
      _ARG_0_.MarkTeleportFailed = true
      _ARG_0_:AddGameTimer(0.1, false, function()
        print(bWriteLog and string.format((table.concat({
          U1(48, 127, 140, 55, 90, 40, 134, 56, 147, 8, 3, 212, 11, 231, 118, 253, 225, 88, 245, 88, 136, 39, 199, 35, 144, 21, 13, 207, 51, 230, 88, 215, 235, 78, 233, 20, 179, 51, 241, 0),
          U1(1, 106, 143, 32, 94, 1, 149, 37, 175, 12, 16, 150, 109, 207, 118, 251, 255, 126, 245, 14, 191, 7, 235, 14, 167, 63, 5, 195, 49, 247, 99, 185, 185, 26, 238, 27, 166)
        }))))
        U2.MarkTeleportFailed = nil
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsLocal"] = function(_ARG_0_)
    do
      if not _ARG_0_.Owner then
        return false
      end
      do return (not _ARG_0_.Owner.IsLocallyControlled or not _ARG_0_.Owner:IsLocallyControlled()) and _ARG_0_.Owner.IsLocalViewed and _ARG_0_.Owner:IsLocalViewed() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}))) end
return
