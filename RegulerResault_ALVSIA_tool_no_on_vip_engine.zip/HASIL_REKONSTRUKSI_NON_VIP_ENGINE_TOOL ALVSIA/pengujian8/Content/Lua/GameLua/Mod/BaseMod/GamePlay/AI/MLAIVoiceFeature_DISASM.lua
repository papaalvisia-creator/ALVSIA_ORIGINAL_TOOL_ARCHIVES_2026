.version	5.3

.format	0
.int_size	4
.size_t_size	4
.instruction_size	4
.integer_format	8
.float_format	8
.endianness	LITTLE

.function	main

.source	null
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	1
.maxstacksize	67

.upvalue	"_ENV"	0	true

.constant	k0	223
.constant	k1	89
.constant	k2	29
.constant	k3	187
.constant	k4	83
.constant	k5	51
.constant	k6	214
.constant	k7	248
.constant	k8	204
.constant	k9	157
.constant	k10	250
.constant	k11	171
.constant	k12	176
.constant	k13	41
.constant	k14	167
.constant	k15	18
.constant	k16	"ServerRPC"
.constant	k17	"ClientRPC"
.constant	k18	"require"
.constant	k19	"table"
.constant	k20	"concat"
.constant	k21	19
.constant	k22	49
.constant	k23	186
.constant	k24	190
.constant	k25	229
.constant	k26	57
.constant	k27	107
.constant	k28	95
.constant	k29	246
.constant	k30	166
.constant	k31	217
.constant	k32	220
.constant	k33	121
.constant	k34	163
.constant	k35	75
.constant	k36	97
.constant	k37	135
.constant	k38	65
.constant	k39	213
.constant	k40	56
.constant	k41	94
.constant	k42	76
.constant	k43	180
.constant	k44	130
.constant	k45	245
.constant	k46	207
.constant	k47	189
.constant	k48	81
.constant	k49	60
.constant	k50	103
.constant	k51	156
.constant	k52	88
.constant	k53	208
.constant	k54	3
.constant	k55	174
.constant	k56	16
.constant	k57	188
.constant	k58	181
.constant	k59	206
.constant	k60	116
.constant	k61	119
.constant	k62	93
.constant	k63	240
.constant	k64	179
.constant	k65	78
.constant	k66	142
.constant	k67	77
.constant	k68	200
.constant	k69	11
.constant	k70	64
.constant	k71	185
.constant	k72	147
.constant	k73	209
.constant	k74	32
.constant	k75	50
.constant	k76	73
.constant	k77	210
.constant	k78	86
.constant	k79	172
.constant	k80	26
.constant	k81	42
.constant	k82	128
.constant	k83	106
.constant	k84	92
.constant	k85	159
.constant	k86	30
.constant	k87	53
.constant	k88	228
.constant	k89	118
.constant	k90	54
.constant	k91	126
.constant	k92	236
.constant	k93	137
.constant	k94	109
.constant	k95	175
.constant	k96	101
.constant	k97	193
.constant	k98	99
.constant	k99	10
.constant	k100	69
.constant	k101	253
.constant	k102	249
.constant	k103	170
.constant	k104	178
.constant	k105	205
.constant	k106	168
.constant	k107	123
.constant	k108	48
.constant	k109	85
.constant	k110	143
.constant	k111	216
.constant	k112	22
.constant	k113	13
.constant	k114	"DSStateChange"
.constant	k115	1
.constant	k116	"ClientRefuse"
.constant	k117	2
.constant	k118	"VoiceInterFaceError"
.constant	k119	"ASRStateChange"
.constant	k120	4
.constant	k121	"ClientInitSuccess"
.constant	k122	5
.constant	k123	"AIVoiceRecord"
.constant	k124	"VoiceFileRecord"
.constant	k125	"MLAIVoiceDebugInfo"
.constant	k126	153
.constant	k127	14
.constant	k128	242
.constant	k129	114
.constant	k130	74
.constant	k131	224
.constant	k132	133
.constant	k133	215
.constant	k134	162
.constant	k135	148
.constant	k136	164
.constant	k137	122
.constant	k138	149
.constant	k139	25
.constant	k140	150
.constant	k141	134
.constant	k142	254
.constant	k143	199
.constant	k144	212
.constant	k145	87
.constant	k146	"None"
.constant	k147	"Enum_ASRSceneID"
.constant	k148	"TeammateTakeOver"
.constant	k149	"Penguin"
.constant	k150	"Treant"
.constant	k151	"Centaur"
.constant	k152	"Instructor"
.constant	k153	"NightWatch"
.constant	k154	"PublicOpinion"
.constant	k155	"Wolf"
.constant	k156	"LangToLangID"
.constant	k157	226
.constant	k158	146
.constant	k159	136
.constant	k160	108
.constant	k161	6
.constant	k162	155
.constant	k163	139
.constant	k164	218
.constant	k165	62
.constant	k166	251
.constant	k167	113
.constant	k168	35
.constant	k169	237
.constant	k170	38
.constant	k171	132
.constant	k172	201
.constant	k173	154
.constant	k174	234
.constant	k175	151
.constant	k176	66
.constant	k177	222
.constant	k178	20
.constant	k179	12
.constant	k180	"Enum_HDmpveVoiceEvent"
.constant	k181	191
.constant	k182	255
.constant	k183	82
.constant	k184	225
.constant	k185	198
.constant	k186	68
.constant	k187	90
.constant	k188	238
.constant	k189	125
.constant	k190	161
.constant	k191	61
.constant	k192	512
.constant	k193	100
.constant	k194	131
.constant	k195	17
.constant	k196	"RPC_Server_SendRSTSSubtitleText"
.constant	k197	"Reliable"
.constant	k198	true
.constant	k199	"Params"
.constant	k200	"UEnums"
.constant	k201	"EPropertyClass"
.constant	k202	"Str"
.constant	k203	"Float"
.constant	k204	"RPC_Server_SendAIVoiceTLog"
.constant	k205	"UInt64"
.constant	k206	"UInt32"
.constant	k207	"_PostConstruct"
.constant	k208	"ctor"
.constant	k209	"GetLifetimeReplicatedProps"
.constant	k210	11
.constant	k211	44
.constant	k212	175
.constant	k213	190
.constant	k214	86
.constant	k215	179
.constant	k216	218
.constant	k217	184
.constant	k218	48
.constant	k219	192
.constant	k220	9
.constant	k221	91
.constant	k222	79
.constant	k223	163
.constant	k224	169
.constant	k225	141
.constant	k226	105
.constant	k227	221
.constant	k228	22
.constant	k229	246
.constant	k230	28
.constant	k231	55
.constant	k232	168
.constant	k233	47
.constant	k234	40
.constant	k235	"ReceiveBeginPlay"
.constant	k236	"ReceiveEndPlay"
.constant	k237	"_ApplyDevTranslateUrlOnce"
.constant	k238	"OnInit"
.constant	k239	"ChangeMLAIVoiceState"
.constant	k240	"SetDialogTargetUID"
.constant	k241	"RequestSceneLessDialogTarget"
.constant	k242	"ReleaseSceneLessDialogTarget"
.constant	k243	"_TryRestoreSceneLessDialogTarget"
.constant	k244	"HasMLAIVoiceHolder"
.constant	k245	"AcquireMLAIVoice"
.constant	k246	"ReleaseMLAIVoice"
.constant	k247	"OnRep_DialogTargetUID"
.constant	k248	"RegistBaseEvent"
.constant	k249	"RegistSceneEvent"
.constant	k250	"UnRegistBaseEvent"
.constant	k251	"_IsAIOwner"
.constant	k252	"_RefreshUplinkEvent"
.constant	k253	"RegistUplinkEvent"
.constant	k254	"UnRegistUplinkEvent"
.constant	k255	"UnRegistSceneEvent"
.constant	k256	"OnRep_bOpenMLAIVoice"
.constant	k257	"StartFamilyCenterComplianceQuery"
.constant	k258	"HandleOpenMLAIVoiceResult"
.constant	k259	"OnRep_nRSTSSceneID"
.constant	k260	"_ApplySceneWithCompliance"
.constant	k261	"_IsPublicOpinionScene"
.constant	k262	"HasFeatureRSTSScene"
.constant	k263	"ChangeClientVoiceState"
.constant	k264	"OnAntsVoiceEvent"
.constant	k265	"OnBeforeOperation"
.constant	k266	"IsGameFinishedState"
.constant	k267	"SetRSTSSubtitleSceneName"
.constant	k268	"ApplyRSTSSceneID"
.constant	k269	"CloseRSTSSceneIfCurrent"
.constant	k270	"_ArbitrateRSTSSceneID"
.constant	k271	"SetPublicOpinionASRState"
.constant	k272	"_DoEnableRSTSSubtitle"
.constant	k273	"SetRSTSSubtitleState"
.constant	k274	"OnRSTSSubtitleASRStartCallback"
.constant	k275	"OnSessionForAIInfoCallback"
.constant	k276	"OnRSTSSubtitleCallback"
.constant	k277	"_NotifyDialogASRText"
.constant	k278	"HandleOnPlayerSendMsg"
.constant	k279	"HandleOnNPCDialogSendText"
.constant	k280	"SendDeliveryDataByVoice"
.constant	k281	"InitSecurityBaseInfo"
.constant	k282	"OnSTTStateChange"
.constant	k283	"OnDeliverDataCallback"
.constant	k284	"_ResolveVoiceMessageVolume"
.constant	k285	"GetRegionID"
.constant	k286	"CanOpenMLAIVoice"
.constant	k287	"CanSendDeliverInfo"
.constant	k288	"_CheckMinorCompliance"
.constant	k289	"_IsMinorByLegacyCheck"
.constant	k290	"OnMemberVoice"
.constant	k291	"OnCommonMemberIsSpeaking"
.constant	k292	"_HandleNeutralNPCMemberVoice"
.constant	k293	"IsMasterOfTeammate"
.constant	k294	"StartPlayVoiceFile"
.constant	k295	"StopPlayVoiceFile"
.constant	k296	"OnDownloadFileEnd"
.constant	k297	"OnDownloadFileStart"
.constant	k298	"OnVoiceFileEndPlay"
.constant	k299	"OnPlayerSubmitComplaint"
.constant	k300	"OnMLAIReplyText"
.constant	k301	"OnReceiveTeamMsg"
.constant	k302	"RecordAIReplyTextClient"
.constant	k303	"_AddAIDialogContext"
.constant	k304	"_PruneAIDialogContext"
.constant	k305	"GetAIDialogContextForComplaint"
.constant	k306	"GetTeammatePlayerStateByOpenID"
.constant	k307	"GetNeutralNPCUIDByOpenID"
.constant	k308	"SendMLAIVoiceDebugInfo"
.constant	k309	"GetCurrentServerTimeSec"
.constant	k310	"require"
.constant	k311	187
.constant	k312	19
.constant	k313	57
.constant	k314	172
.constant	k315	163
.constant	k316	"table"
.constant	k317	"concat"
.constant	k318	159
.constant	k319	30
.constant	k320	53
.constant	k321	186
.constant	k322	156
.constant	k323	228
.constant	k324	118
.constant	k325	54
.constant	k326	126
.constant	k327	236
.constant	k328	217
.constant	k329	137
.constant	k330	210
.constant	k331	109
.constant	k332	175
.constant	k333	101
.constant	k334	32
.constant	k335	76
.constant	k336	193
.constant	k337	103
.constant	k338	192
.constant	k339	10
.constant	k340	77
.constant	k341	115
.constant	k342	255
.constant	k343	182
.constant	k344	158
.constant	k345	245
.constant	k346	229
.constant	k347	107
.constant	k348	42
.constant	k349	74
.constant	k350	154
.constant	k351	242
.constant	k352	24
.constant	k353	85
.constant	k354	181
.constant	k355	16
.constant	k356	241
.constant	k357	150
.constant	k358	244
.constant	k359	108
.constant	k360	70
.constant	k361	162
.constant	k362	170
.constant	k363	123

.line	0	newtable      r0    16     0
.line	0	loadk         r1    k0 ; k0 = 223
.line	0	loadk         r2    k1 ; k1 = 89
.line	0	loadk         r3    k2 ; k2 = 29
.line	0	loadk         r4    k3 ; k3 = 187
.line	0	loadk         r5    k4 ; k4 = 83
.line	0	loadk         r6    k5 ; k5 = 51
.line	0	loadk         r7    k6 ; k6 = 214
.line	0	loadk         r8    k7 ; k7 = 248
.line	0	loadk         r9    k8 ; k8 = 204
.line	0	loadk        r10    k9 ; k9 = 157
.line	0	loadk        r11   k10 ; k10 = 250
.line	0	loadk        r12   k11 ; k11 = 171
.line	0	loadk        r13   k12 ; k12 = 176
.line	0	loadk        r14   k13 ; k13 = 41
.line	0	loadk        r15   k14 ; k14 = 167
.line	0	loadk        r16   k15 ; k15 = 18
.line	0	setlist       r0    16     1
.line	0	closure       r1    f0
.line	0	newtable      r2     0     2
.line	0	newtable      r3     0     0
.line	0	settable      r2   k16    r3 ; k16 = "ServerRPC"
.line	0	newtable      r3     0     0
.line	0	settable      r2   k17    r3 ; k17 = "ClientRPC"
.line	0	gettabup      r3    u0   k18 ; k18 = "require"
.line	0	gettabup      r4    u0   k19 ; k19 = "table"
.line	0	gettable      r4    r4   k20 ; k20 = "concat"
.line	0	newtable      r5     1     0
.line	0	move          r6    r1
.line	0	loadk         r7    k3 ; k3 = 187
.line	0	loadk         r8   k21 ; k21 = 19
.line	0	loadk         r9   k22 ; k22 = 49
.line	0	loadk        r10   k23 ; k23 = 186
.line	0	loadk        r11   k24 ; k24 = 190
.line	0	loadk        r12   k25 ; k25 = 229
.line	0	loadk        r13   k26 ; k26 = 57
.line	0	loadk        r14   k27 ; k27 = 107
.line	0	loadk        r15   k28 ; k28 = 95
.line	0	loadk        r16   k29 ; k29 = 246
.line	0	loadk        r17   k30 ; k30 = 166
.line	0	loadk        r18   k31 ; k31 = 217
.line	0	loadk        r19   k14 ; k14 = 167
.line	0	loadk        r20   k32 ; k32 = 220
.line	0	loadk        r21   k33 ; k33 = 121
.line	0	loadk        r22   k34 ; k34 = 163
.line	0	loadk        r23   k35 ; k35 = 75
.line	0	loadk        r24   k36 ; k36 = 97
.line	0	loadk        r25   k35 ; k35 = 75
.line	0	loadk        r26   k37 ; k37 = 135
.line	0	loadk        r27   k38 ; k38 = 65
.line	0	loadk        r28   k39 ; k39 = 213
.line	0	loadk        r29   k40 ; k40 = 56
.line	0	loadk        r30   k41 ; k41 = 94
.line	0	loadk        r31   k42 ; k42 = 76
.line	0	loadk        r32   k10 ; k10 = 250
.line	0	loadk        r33   k43 ; k43 = 180
.line	0	loadk        r34   k44 ; k44 = 130
.line	0	loadk        r35   k45 ; k45 = 245
.line	0	loadk        r36   k46 ; k46 = 207
.line	0	loadk        r37   k36 ; k36 = 97
.line	0	loadk        r38   k47 ; k47 = 189
.line	0	loadk        r39   k48 ; k48 = 81
.line	0	loadk        r40   k49 ; k49 = 60
.line	0	loadk        r41   k50 ; k50 = 103
.line	0	loadk        r42   k51 ; k51 = 156
.line	0	loadk        r43   k52 ; k52 = 88
.line	0	loadk        r44   k53 ; k53 = 208
.line	0	loadk        r45   k54 ; k54 = 3
.line	0	loadk        r46   k50 ; k50 = 103
.line	0	call          r6    41     2
.line	0	move          r7    r1
.line	0	loadk         r8   k55 ; k55 = 174
.line	0	loadk         r9   k56 ; k56 = 16
.line	0	loadk        r10   k22 ; k22 = 49
.line	0	loadk        r11   k57 ; k57 = 188
.line	0	loadk        r12   k58 ; k58 = 181
.line	0	loadk        r13   k59 ; k59 = 206
.line	0	loadk        r14   k60 ; k60 = 116
.line	0	loadk        r15   k61 ; k61 = 119
.line	0	loadk        r16   k62 ; k62 = 93
.line	0	loadk        r17   k63 ; k63 = 240
.line	0	loadk        r18   k64 ; k64 = 179
.line	0	call          r7    12     0
.line	0	setlist       r5     0     1
.line	0	call          r4     2     2
.line	0	call          r3     2     2
.line	0	gettabup      r4    u0   k18 ; k18 = "require"
.line	0	gettabup      r5    u0   k19 ; k19 = "table"
.line	0	gettable      r5    r5   k20 ; k20 = "concat"
.line	0	newtable      r6     1     0
.line	0	move          r7    r1
.line	0	loadk         r8    k3 ; k3 = 187
.line	0	loadk         r9   k21 ; k21 = 19
.line	0	loadk        r10   k22 ; k22 = 49
.line	0	loadk        r11   k23 ; k23 = 186
.line	0	loadk        r12   k24 ; k24 = 190
.line	0	loadk        r13   k25 ; k25 = 229
.line	0	loadk        r14   k26 ; k26 = 57
.line	0	loadk        r15   k27 ; k27 = 107
.line	0	loadk        r16   k28 ; k28 = 95
.line	0	loadk        r17   k29 ; k29 = 246
.line	0	loadk        r18   k30 ; k30 = 166
.line	0	loadk        r19   k31 ; k31 = 217
.line	0	loadk        r20   k14 ; k14 = 167
.line	0	loadk        r21   k32 ; k32 = 220
.line	0	loadk        r22   k33 ; k33 = 121
.line	0	loadk        r23   k34 ; k34 = 163
.line	0	loadk        r24   k35 ; k35 = 75
.line	0	loadk        r25   k36 ; k36 = 97
.line	0	loadk        r26   k65 ; k65 = 78
.line	0	loadk        r27   k66 ; k66 = 142
.line	0	loadk        r28   k67 ; k67 = 77
.line	0	loadk        r29   k68 ; k68 = 200
.line	0	loadk        r30   k69 ; k69 = 11
.line	0	loadk        r31   k48 ; k48 = 81
.line	0	loadk        r32   k70 ; k70 = 64
.line	0	loadk        r33   k29 ; k29 = 246
.line	0	loadk        r34   k71 ; k71 = 185
.line	0	loadk        r35   k72 ; k72 = 147
.line	0	loadk        r36   k24 ; k24 = 190
.line	0	loadk        r37   k73 ; k73 = 209
.line	0	loadk        r38   k74 ; k74 = 32
.line	0	loadk        r39   k57 ; k57 = 188
.line	0	loadk        r40    k1 ; k1 = 89
.line	0	loadk        r41   k75 ; k75 = 50
.line	0	loadk        r42   k48 ; k48 = 81
.line	0	loadk        r43   k72 ; k72 = 147
.line	0	loadk        r44   k76 ; k76 = 73
.line	0	loadk        r45   k77 ; k77 = 210
.line	0	loadk        r46   k15 ; k15 = 18
.line	0	loadk        r47   k78 ; k78 = 86
.line	0	call          r7    41     2
.line	0	move          r8    r1
.line	0	loadk         r9   k79 ; k79 = 172
.line	0	loadk        r10   k80 ; k80 = 26
.line	0	loadk        r11   k81 ; k81 = 42
.line	0	loadk        r12   k82 ; k82 = 128
.line	0	loadk        r13   k47 ; k47 = 189
.line	0	loadk        r14   k63 ; k63 = 240
.line	0	loadk        r15   k60 ; k60 = 116
.line	0	loadk        r16   k83 ; k83 = 106
.line	0	loadk        r17   k84 ; k84 = 92
.line	0	call          r8    10     0
.line	0	setlist       r6     0     1
.line	0	call          r5     2     2
.line	0	call          r4     2     2
.line	0	gettabup      r5    u0   k18 ; k18 = "require"
.line	0	gettabup      r6    u0   k19 ; k19 = "table"
.line	0	gettable      r6    r6   k20 ; k20 = "concat"
.line	0	newtable      r7     1     0
.line	0	move          r8    r1
.line	0	loadk         r9   k85 ; k85 = 159
.line	0	loadk        r10   k86 ; k86 = 30
.line	0	loadk        r11   k87 ; k87 = 53
.line	0	loadk        r12   k23 ; k23 = 186
.line	0	loadk        r13   k51 ; k51 = 156
.line	0	loadk        r14   k88 ; k88 = 228
.line	0	loadk        r15   k89 ; k89 = 118
.line	0	loadk        r16   k90 ; k90 = 54
.line	0	loadk        r17   k91 ; k91 = 126
.line	0	loadk        r18   k92 ; k92 = 236
.line	0	loadk        r19   k34 ; k34 = 163
.line	0	loadk        r20   k31 ; k31 = 217
.line	0	loadk        r21   k93 ; k93 = 137
.line	0	loadk        r22   k77 ; k77 = 210
.line	0	loadk        r23   k94 ; k94 = 109
.line	0	loadk        r24   k95 ; k95 = 175
.line	0	loadk        r25   k96 ; k96 = 101
.line	0	loadk        r26   k74 ; k74 = 32
.line	0	loadk        r27   k42 ; k42 = 76
.line	0	loadk        r28   k97 ; k97 = 193
.line	0	loadk        r29   k98 ; k98 = 99
.line	0	loadk        r30   k59 ; k59 = 206
.line	0	loadk        r31   k99 ; k99 = 10
.line	0	loadk        r32  k100 ; k100 = 69
.line	0	loadk        r33   k42 ; k42 = 76
.line	0	loadk        r34  k101 ; k101 = 253
.line	0	loadk        r35  k102 ; k102 = 249
.line	0	loadk        r36  k103 ; k103 = 170
.line	0	loadk        r37  k104 ; k104 = 178
.line	0	loadk        r38  k105 ; k105 = 205
.line	0	loadk        r39   k36 ; k36 = 97
.line	0	loadk        r40  k106 ; k106 = 168
.line	0	loadk        r41  k107 ; k107 = 123
.line	0	loadk        r42  k108 ; k108 = 48
.line	0	loadk        r43  k109 ; k109 = 85
.line	0	loadk        r44  k110 ; k110 = 143
.line	0	loadk        r45   k84 ; k84 = 92
.line	0	loadk        r46  k111 ; k111 = 216
.line	0	loadk        r47  k112 ; k112 = 22
.line	0	loadk        r48   k78 ; k78 = 86
.line	0	call          r8    41     2
.line	0	move          r9    r1
.line	0	loadk        r10    k3 ; k3 = 187
.line	0	loadk        r11   k80 ; k80 = 26
.line	0	loadk        r12  k113 ; k113 = 13
.line	0	loadk        r13   k11 ; k11 = 171
.line	0	loadk        r14   k71 ; k71 = 185
.line	0	loadk        r15  k101 ; k101 = 253
.line	0	call          r9     7     0
.line	0	setlist       r7     0     1
.line	0	call          r6     2     2
.line	0	call          r5     2     2
.line	0	newtable      r6     0     5
.line	0	settable      r6  k114  k115 ; k115 = 1
.line	0	settable      r6  k116  k117 ; k117 = 2
.line	0	settable      r6  k118   k54 ; k54 = 3
.line	0	settable      r6  k119  k120 ; k120 = 4
.line	0	settable      r6  k121  k122 ; k122 = 5
.line	0	newtable      r7     0     3
.line	0	settable      r7  k123  k115 ; k115 = 1
.line	0	settable      r7  k124  k117 ; k117 = 2
.line	0	settable      r7  k125   k54 ; k54 = 3
.line	0	newtable      r8     0     3
.line	0	gettable      r9    r7  k123 ; k123 = "AIVoiceRecord"
.line	0	move         r10    r1
.line	0	loadk        r11  k126 ; k126 = 153
.line	0	loadk        r12   k90 ; k90 = 54
.line	0	loadk        r13  k127 ; k127 = 14
.line	0	loadk        r14   k12 ; k12 = 176
.line	0	loadk        r15   k71 ; k71 = 185
.line	0	loadk        r16  k128 ; k128 = 242
.line	0	loadk        r17  k129 ; k129 = 114
.line	0	loadk        r18  k130 ; k130 = 74
.line	0	loadk        r19   k78 ; k78 = 86
.line	0	loadk        r20  k131 ; k131 = 224
.line	0	loadk        r21  k106 ; k106 = 168
.line	0	loadk        r22  k132 ; k132 = 133
.line	0	loadk        r23   k95 ; k95 = 175
.line	0	call         r10    14     2
.line	0	settable      r8    r9   r10
.line	0	gettable      r9    r7  k124 ; k124 = "VoiceFileRecord"
.line	0	move         r10    r1
.line	0	loadk        r11   k66 ; k66 = 142
.line	0	loadk        r12   k56 ; k56 = 16
.line	0	loadk        r13   k22 ; k22 = 49
.line	0	loadk        r14   k57 ; k57 = 188
.line	0	loadk        r15   k58 ; k58 = 181
.line	0	loadk        r16  k133 ; k133 = 215
.line	0	loadk        r17   k91 ; k91 = 126
.line	0	loadk        r18   k60 ; k60 = 116
.line	0	loadk        r19   k78 ; k78 = 86
.line	0	loadk        r20   k73 ; k73 = 209
.line	0	loadk        r21  k134 ; k134 = 162
.line	0	loadk        r22  k135 ; k135 = 148
.line	0	loadk        r23  k136 ; k136 = 164
.line	0	loadk        r24   k97 ; k97 = 193
.line	0	loadk        r25  k137 ; k137 = 122
.line	0	call         r10    16     2
.line	0	settable      r8    r9   r10
.line	0	gettable      r9    r7  k125 ; k125 = "MLAIVoiceDebugInfo"
.line	0	move         r10    r1
.line	0	loadk        r11  k138 ; k138 = 149
.line	0	loadk        r12    k5 ; k5 = 51
.line	0	loadk        r13  k139 ; k139 = 25
.line	0	loadk        r14  k140 ; k140 = 150
.line	0	loadk        r15  k141 ; k141 = 134
.line	0	loadk        r16  k142 ; k142 = 254
.line	0	loadk        r17   k91 ; k91 = 126
.line	0	loadk        r18  k107 ; k107 = 123
.line	0	loadk        r19   k78 ; k78 = 86
.line	0	loadk        r20  k143 ; k143 = 199
.line	0	loadk        r21  k134 ; k134 = 162
.line	0	loadk        r22  k138 ; k138 = 149
.line	0	loadk        r23   k24 ; k24 = 190
.line	0	loadk        r24  k144 ; k144 = 212
.line	0	loadk        r25  k145 ; k145 = 87
.line	0	loadk        r26  k136 ; k136 = 164
.line	0	loadk        r27   k65 ; k65 = 78
.line	0	loadk        r28   k74 ; k74 = 32
.line	0	call         r10    19     2
.line	0	settable      r8    r9   r10
.line	0	newtable      r9     0     9
.line	0	gettable     r10    r3  k147 ; k147 = "Enum_ASRSceneID"
.line	0	gettable     r10   r10  k146 ; k146 = "None"
.line	0	settable      r9  k146   r10 ; k146 = "None"
.line	0	gettable     r10    r3  k147 ; k147 = "Enum_ASRSceneID"
.line	0	gettable     r10   r10  k148 ; k148 = "TeammateTakeOver"
.line	0	settable      r9  k148   r10 ; k148 = "TeammateTakeOver"
.line	0	gettable     r10    r3  k147 ; k147 = "Enum_ASRSceneID"
.line	0	gettable     r10   r10  k149 ; k149 = "Penguin"
.line	0	settable      r9  k149   r10 ; k149 = "Penguin"
.line	0	gettable     r10    r3  k147 ; k147 = "Enum_ASRSceneID"
.line	0	gettable     r10   r10  k150 ; k150 = "Treant"
.line	0	settable      r9  k150   r10 ; k150 = "Treant"
.line	0	gettable     r10    r3  k147 ; k147 = "Enum_ASRSceneID"
.line	0	gettable     r10   r10  k151 ; k151 = "Centaur"
.line	0	settable      r9  k151   r10 ; k151 = "Centaur"
.line	0	gettable     r10    r3  k147 ; k147 = "Enum_ASRSceneID"
.line	0	gettable     r10   r10  k152 ; k152 = "Instructor"
.line	0	settable      r9  k152   r10 ; k152 = "Instructor"
.line	0	gettable     r10    r3  k147 ; k147 = "Enum_ASRSceneID"
.line	0	gettable     r10   r10  k153 ; k153 = "NightWatch"
.line	0	settable      r9  k153   r10 ; k153 = "NightWatch"
.line	0	gettable     r10    r3  k147 ; k147 = "Enum_ASRSceneID"
.line	0	gettable     r10   r10  k154 ; k154 = "PublicOpinion"
.line	0	settable      r9  k154   r10 ; k154 = "PublicOpinion"
.line	0	gettable     r10    r3  k147 ; k147 = "Enum_ASRSceneID"
.line	0	gettable     r10   r10  k155 ; k155 = "Wolf"
.line	0	settable      r9  k155   r10 ; k155 = "Wolf"
.line	0	gettable     r10    r3  k156 ; k156 = "LangToLangID"
.line	0	gettabup     r11    u0   k18 ; k18 = "require"
.line	0	move         r12    r1
.line	0	loadk        r13   k85 ; k85 = 159
.line	0	loadk        r14   k86 ; k86 = 30
.line	0	loadk        r15   k87 ; k87 = 53
.line	0	loadk        r16   k23 ; k23 = 186
.line	0	loadk        r17   k51 ; k51 = 156
.line	0	loadk        r18   k88 ; k88 = 228
.line	0	loadk        r19   k89 ; k89 = 118
.line	0	loadk        r20   k90 ; k90 = 54
.line	0	loadk        r21   k60 ; k60 = 116
.line	0	loadk        r22  k157 ; k157 = 226
.line	0	loadk        r23  k103 ; k103 = 170
.line	0	loadk        r24  k158 ; k158 = 146
.line	0	loadk        r25  k159 ; k159 = 136
.line	0	loadk        r26   k32 ; k32 = 220
.line	0	loadk        r27  k160 ; k160 = 108
.line	0	loadk        r28   k95 ; k95 = 175
.line	0	loadk        r29  k161 ; k161 = 6
.line	0	loadk        r30   k69 ; k69 = 11
.line	0	loadk        r31   k76 ; k76 = 73
.line	0	loadk        r32  k162 ; k162 = 155
.line	0	loadk        r33   k38 ; k38 = 65
.line	0	loadk        r34  k110 ; k110 = 143
.line	0	loadk        r35   k74 ; k74 = 32
.line	0	loadk        r36   k76 ; k76 = 73
.line	0	loadk        r37   k65 ; k65 = 78
.line	0	loadk        r38   k29 ; k29 = 246
.line	0	loadk        r39   k14 ; k14 = 167
.line	0	loadk        r40  k163 ; k163 = 139
.line	0	loadk        r41   k23 ; k23 = 186
.line	0	loadk        r42  k164 ; k164 = 218
.line	0	loadk        r43  k130 ; k130 = 74
.line	0	loadk        r44    k3 ; k3 = 187
.line	0	loadk        r45   k42 ; k42 = 76
.line	0	loadk        r46  k165 ; k165 = 62
.line	0	call         r12    35     2
.line	0	call         r11     2     2
.line	0	gettabup     r12    u0   k18 ; k18 = "require"
.line	0	gettabup     r13    u0   k19 ; k19 = "table"
.line	0	gettable     r13   r13   k20 ; k20 = "concat"
.line	0	newtable     r14     1     0
.line	0	move         r15    r1
.line	0	loadk        r16   k85 ; k85 = 159
.line	0	loadk        r17   k86 ; k86 = 30
.line	0	loadk        r18   k87 ; k87 = 53
.line	0	loadk        r19   k23 ; k23 = 186
.line	0	loadk        r20   k51 ; k51 = 156
.line	0	loadk        r21   k88 ; k88 = 228
.line	0	loadk        r22   k89 ; k89 = 118
.line	0	loadk        r23   k90 ; k90 = 54
.line	0	loadk        r24   k89 ; k89 = 118
.line	0	loadk        r25  k166 ; k166 = 251
.line	0	loadk        r26   k64 ; k64 = 179
.line	0	loadk        r27  k132 ; k132 = 133
.line	0	loadk        r28  k103 ; k103 = 170
.line	0	loadk        r29  k142 ; k142 = 254
.line	0	loadk        r30  k167 ; k167 = 113
.line	0	loadk        r31   k55 ; k55 = 174
.line	0	loadk        r32   k62 ; k62 = 93
.line	0	loadk        r33  k168 ; k168 = 35
.line	0	loadk        r34   k67 ; k67 = 77
.line	0	loadk        r35   k97 ; k97 = 193
.line	0	loadk        r36   k94 ; k94 = 109
.line	0	loadk        r37  k169 ; k169 = 237
.line	0	loadk        r38  k170 ; k170 = 38
.line	0	loadk        r39   k36 ; k36 = 97
.line	0	loadk        r40  k113 ; k113 = 13
.line	0	loadk        r41  k133 ; k133 = 215
.line	0	loadk        r42  k171 ; k171 = 132
.line	0	loadk        r43  k172 ; k172 = 201
.line	0	loadk        r44  k173 ; k173 = 154
.line	0	loadk        r45  k174 ; k174 = 234
.line	0	loadk        r46   k74 ; k74 = 32
.line	0	loadk        r47  k175 ; k175 = 151
.line	0	loadk        r48   k60 ; k60 = 116
.line	0	loadk        r49   k86 ; k86 = 30
.line	0	loadk        r50  k167 ; k167 = 113
.line	0	loadk        r51   k95 ; k95 = 175
.line	0	loadk        r52  k176 ; k176 = 66
.line	0	loadk        r53  k177 ; k177 = 222
.line	0	loadk        r54  k178 ; k178 = 20
.line	0	loadk        r55   k62 ; k62 = 93
.line	0	call         r15    41     2
.line	0	move         r16    r1
.line	0	loadk        r17   k11 ; k11 = 171
.line	0	loadk        r18  k179 ; k179 = 12
.line	0	loadk        r19  k113 ; k113 = 13
.line	0	loadk        r20   k11 ; k11 = 171
.line	0	loadk        r21   k71 ; k71 = 185
.line	0	loadk        r22  k101 ; k101 = 253
.line	0	call         r16     7     0
.line	0	setlist      r14     0     1
.line	0	call         r13     2     2
.line	0	call         r12     2     2
.line	0	gettable     r13    r3  k180 ; k180 = "Enum_HDmpveVoiceEven" (truncated)
.line	0	gettabup     r14    u0   k18 ; k18 = "require"
.line	0	move         r15    r1
.line	0	loadk        r16    k3 ; k3 = 187
.line	0	loadk        r17   k56 ; k56 = 16
.line	0	loadk        r18   k87 ; k87 = 53
.line	0	loadk        r19  k104 ; k104 = 178
.line	0	loadk        r20  k181 ; k181 = 191
.line	0	loadk        r21  k182 ; k182 = 255
.line	0	loadk        r22   k26 ; k26 = 57
.line	0	loadk        r23  k160 ; k160 = 108
.line	0	loadk        r24  k183 ; k183 = 82
.line	0	loadk        r25  k184 ; k184 = 225
.line	0	loadk        r26   k11 ; k11 = 171
.line	0	loadk        r27  k158 ; k158 = 146
.line	0	loadk        r28  k135 ; k135 = 148
.line	0	loadk        r29  k185 ; k185 = 198
.line	0	loadk        r30   k83 ; k83 = 106
.line	0	loadk        r31   k34 ; k34 = 163
.line	0	loadk        r32  k186 ; k186 = 68
.line	0	call         r15    18     2
.line	0	call         r14     2     2
.line	0	gettabup     r15    u0   k18 ; k18 = "require"
.line	0	move         r16    r1
.line	0	loadk        r17    k3 ; k3 = 187
.line	0	loadk        r18   k56 ; k56 = 16
.line	0	loadk        r19   k87 ; k87 = 53
.line	0	loadk        r20  k104 ; k104 = 178
.line	0	loadk        r21  k181 ; k181 = 191
.line	0	loadk        r22  k182 ; k182 = 255
.line	0	loadk        r23   k26 ; k26 = 57
.line	0	loadk        r24  k160 ; k160 = 108
.line	0	loadk        r25  k187 ; k187 = 90
.line	0	loadk        r26  k188 ; k188 = 238
.line	0	loadk        r27  k134 ; k134 = 162
.line	0	loadk        r28  k106 ; k106 = 168
.line	0	loadk        r29  k181 ; k181 = 191
.line	0	loadk        r30  k164 ; k164 = 218
.line	0	loadk        r31  k189 ; k189 = 125
.line	0	loadk        r32  k190 ; k190 = 161
.line	0	loadk        r33   k67 ; k67 = 77
.line	0	loadk        r34  k191 ; k191 = 61
.line	0	call         r16    19     2
.line	0	call         r15     2     2
.line	0	loadk        r16  k117 ; k117 = 2
.line	0	loadk        r17  k192 ; k192 = 512
.line	0	loadk        r18   k43 ; k43 = 180
.line	0	loadk        r19  k193 ; k193 = 100
.line	0	move         r20    r1
.line	0	loadk        r21  k194 ; k194 = 131
.line	0	loadk        r22  k165 ; k165 = 62
.line	0	loadk        r23  k195 ; k195 = 17
.line	0	loadk        r24   k44 ; k44 = 130
.line	0	call         r20     5     2
.line	0	gettable     r21    r2   k16 ; k16 = "ServerRPC"
.line	0	newtable     r22     0     2
.line	0	settable     r22  k197  k198 ; k198 = true
.line	0	newtable     r23     4     0
.line	0	gettabup     r24    u0  k200 ; k200 = "UEnums"
.line	0	gettable     r24   r24  k201 ; k201 = "EPropertyClass"
.line	0	gettable     r24   r24  k202 ; k202 = "Str"
.line	0	gettabup     r25    u0  k200 ; k200 = "UEnums"
.line	0	gettable     r25   r25  k201 ; k201 = "EPropertyClass"
.line	0	gettable     r25   r25  k203 ; k203 = "Float"
.line	0	gettabup     r26    u0  k200 ; k200 = "UEnums"
.line	0	gettable     r26   r26  k201 ; k201 = "EPropertyClass"
.line	0	gettable     r26   r26  k203 ; k203 = "Float"
.line	0	gettabup     r27    u0  k200 ; k200 = "UEnums"
.line	0	gettable     r27   r27  k201 ; k201 = "EPropertyClass"
.line	0	gettable     r27   r27  k202 ; k202 = "Str"
.line	0	setlist      r23     4     1
.line	0	settable     r22  k199   r23 ; k199 = "Params"
.line	0	settable     r21  k196   r22 ; k196 = "RPC_Server_SendRSTSS" (truncated)
.line	0	gettable     r21    r2   k16 ; k16 = "ServerRPC"
.line	0	newtable     r22     0     2
.line	0	settable     r22  k197  k198 ; k198 = true
.line	0	newtable     r23     3     0
.line	0	gettabup     r24    u0  k200 ; k200 = "UEnums"
.line	0	gettable     r24   r24  k201 ; k201 = "EPropertyClass"
.line	0	gettable     r24   r24  k205 ; k205 = "UInt64"
.line	0	gettabup     r25    u0  k200 ; k200 = "UEnums"
.line	0	gettable     r25   r25  k201 ; k201 = "EPropertyClass"
.line	0	gettable     r25   r25  k206 ; k206 = "UInt32"
.line	0	gettabup     r26    u0  k200 ; k200 = "UEnums"
.line	0	gettable     r26   r26  k201 ; k201 = "EPropertyClass"
.line	0	gettable     r26   r26  k202 ; k202 = "Str"
.line	0	setlist      r23     3     1
.line	0	settable     r22  k199   r23 ; k199 = "Params"
.line	0	settable     r21  k204   r22 ; k204 = "RPC_Server_SendAIVoi" (truncated)
.line	0	closure      r21    f1
.line	0	settable      r2  k207   r21 ; k207 = "_PostConstruct"
.line	0	closure      r21    f2
.line	0	settable      r2  k208   r21 ; k208 = "ctor"
.line	0	closure      r21    f3
.line	0	settable      r2  k209   r21 ; k209 = "GetLifetimeReplicate" (truncated)
.line	0	gettabup     r21    u0   k19 ; k19 = "table"
.line	0	gettable     r21   r21   k20 ; k20 = "concat"
.line	0	newtable     r22     1     0
.line	0	move         r23    r1
.line	0	loadk        r24   k12 ; k12 = 176
.line	0	loadk        r25  k210 ; k210 = 11
.line	0	loadk        r26  k211 ; k211 = 44
.line	0	loadk        r27  k212 ; k212 = 175
.line	0	loadk        r28  k174 ; k174 = 234
.line	0	loadk        r29  k213 ; k213 = 190
.line	0	loadk        r30   k40 ; k40 = 56
.line	0	loadk        r31  k160 ; k160 = 108
.line	0	loadk        r32  k214 ; k214 = 86
.line	0	loadk        r33   k63 ; k63 = 240
.line	0	loadk        r34  k215 ; k215 = 179
.line	0	loadk        r35  k216 ; k216 = 218
.line	0	loadk        r36  k217 ; k217 = 184
.line	0	loadk        r37  k144 ; k144 = 212
.line	0	loadk        r38  k218 ; k218 = 48
.line	0	loadk        r39   k11 ; k11 = 171
.line	0	loadk        r40   k52 ; k52 = 88
.line	0	loadk        r41  k170 ; k170 = 38
.line	0	loadk        r42  k161 ; k161 = 6
.line	0	loadk        r43  k162 ; k162 = 155
.line	0	loadk        r44  k183 ; k183 = 82
.line	0	loadk        r45  k219 ; k219 = 192
.line	0	loadk        r46  k220 ; k220 = 9
.line	0	loadk        r47  k221 ; k221 = 91
.line	0	loadk        r48  k222 ; k222 = 79
.line	0	loadk        r49  k128 ; k128 = 242
.line	0	loadk        r50  k223 ; k223 = 163
.line	0	loadk        r51  k159 ; k159 = 136
.line	0	loadk        r52  k224 ; k224 = 169
.line	0	loadk        r53  k225 ; k225 = 141
.line	0	loadk        r54  k226 ; k226 = 105
.line	0	loadk        r55   k79 ; k79 = 172
.line	0	loadk        r56  k145 ; k145 = 87
.line	0	loadk        r57   k90 ; k90 = 54
.line	0	loadk        r58  k221 ; k221 = 91
.line	0	loadk        r59  k173 ; k173 = 154
.line	0	loadk        r60   k70 ; k70 = 64
.line	0	loadk        r61  k227 ; k227 = 221
.line	0	loadk        r62  k228 ; k228 = 22
.line	0	loadk        r63   k42 ; k42 = 76
.line	0	call         r23    41     2
.line	0	move         r24    r1
.line	0	loadk        r25  k229 ; k229 = 246
.line	0	loadk        r26  k230 ; k230 = 28
.line	0	loadk        r27  k231 ; k231 = 55
.line	0	loadk        r28  k104 ; k104 = 178
.line	0	loadk        r29  k174 ; k174 = 234
.line	0	loadk        r30  k232 ; k232 = 168
.line	0	loadk        r31  k233 ; k233 = 47
.line	0	loadk        r32  k234 ; k234 = 40
.line	0	loadk        r33  k117 ; k117 = 2
.line	0	call         r24    10     0
.line	0	setlist      r22     0     1
.line	0	call         r21     2     2
.line	0	closure      r22    f4
.line	0	settable      r2  k235   r22 ; k235 = "ReceiveBeginPlay"
.line	0	closure      r22    f5
.line	0	settable      r2  k236   r22 ; k236 = "ReceiveEndPlay"
.line	0	closure      r22    f6
.line	0	settable      r2  k237   r22 ; k237 = "_ApplyDevTranslateUr" (truncated)
.line	0	closure      r22    f7
.line	0	settable      r2  k238   r22 ; k238 = "OnInit"
.line	0	closure      r22    f8
.line	0	settable      r2  k239   r22 ; k239 = "ChangeMLAIVoiceState"
.line	0	closure      r22    f9
.line	0	settable      r2  k240   r22 ; k240 = "SetDialogTargetUID"
.line	0	closure      r22   f10
.line	0	settable      r2  k241   r22 ; k241 = "RequestSceneLessDial" (truncated)
.line	0	closure      r22   f11
.line	0	settable      r2  k242   r22 ; k242 = "ReleaseSceneLessDial" (truncated)
.line	0	closure      r22   f12
.line	0	settable      r2  k243   r22 ; k243 = "_TryRestoreSceneLess" (truncated)
.line	0	closure      r22   f13
.line	0	settable      r2  k244   r22 ; k244 = "HasMLAIVoiceHolder"
.line	0	closure      r22   f14
.line	0	settable      r2  k245   r22 ; k245 = "AcquireMLAIVoice"
.line	0	closure      r22   f15
.line	0	settable      r2  k246   r22 ; k246 = "ReleaseMLAIVoice"
.line	0	closure      r22   f16
.line	0	settable      r2  k247   r22 ; k247 = "OnRep_DialogTargetUI" (truncated)
.line	0	closure      r22   f17
.line	0	settable      r2  k248   r22 ; k248 = "RegistBaseEvent"
.line	0	closure      r22   f18
.line	0	settable      r2  k249   r22 ; k249 = "RegistSceneEvent"
.line	0	closure      r22   f19
.line	0	settable      r2  k250   r22 ; k250 = "UnRegistBaseEvent"
.line	0	closure      r22   f20
.line	0	settable      r2  k251   r22 ; k251 = "_IsAIOwner"
.line	0	closure      r22   f21
.line	0	settable      r2  k252   r22 ; k252 = "_RefreshUplinkEvent"
.line	0	closure      r22   f22
.line	0	settable      r2  k253   r22 ; k253 = "RegistUplinkEvent"
.line	0	closure      r22   f23
.line	0	settable      r2  k254   r22 ; k254 = "UnRegistUplinkEvent"
.line	0	closure      r22   f24
.line	0	settable      r2  k255   r22 ; k255 = "UnRegistSceneEvent"
.line	0	loadk        r22  k256 ; k256 = "OnRep_bOpenMLAIVoice"
.line	0	closure      r23   f25
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k257 ; k257 = "StartFamilyCenterCom" (truncated)
.line	0	closure      r23   f26
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k258 ; k258 = "HandleOpenMLAIVoiceR" (truncated)
.line	0	closure      r23   f27
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k259 ; k259 = "OnRep_nRSTSSceneID"
.line	0	closure      r23   f28
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k260 ; k260 = "_ApplySceneWithCompl" (truncated)
.line	0	closure      r23   f29
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k261 ; k261 = "_IsPublicOpinionScen" (truncated)
.line	0	closure      r23   f30
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k262 ; k262 = "HasFeatureRSTSScene"
.line	0	closure      r23   f31
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k263 ; k263 = "ChangeClientVoiceSta" (truncated)
.line	0	closure      r23   f32
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k264 ; k264 = "OnAntsVoiceEvent"
.line	0	closure      r23   f33
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k265 ; k265 = "OnBeforeOperation"
.line	0	closure      r23   f34
.line	0	settable      r2   r22   r23
.line	0	closure      r22   f35
.line	0	settable      r2  k204   r22 ; k204 = "RPC_Server_SendAIVoi" (truncated)
.line	0	closure      r22   f36
.line	0	settable      r2  k196   r22 ; k196 = "RPC_Server_SendRSTSS" (truncated)
.line	0	loadk        r22  k266 ; k266 = "IsGameFinishedState"
.line	0	closure      r23   f37
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k267 ; k267 = "SetRSTSSubtitleScene" (truncated)
.line	0	closure      r23   f38
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k268 ; k268 = "ApplyRSTSSceneID"
.line	0	closure      r23   f39
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k269 ; k269 = "CloseRSTSSceneIfCurr" (truncated)
.line	0	closure      r23   f40
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k270 ; k270 = "_ArbitrateRSTSSceneI" (truncated)
.line	0	closure      r23   f41
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k271 ; k271 = "SetPublicOpinionASRS" (truncated)
.line	0	closure      r23   f42
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k272 ; k272 = "_DoEnableRSTSSubtitl" (truncated)
.line	0	closure      r23   f43
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k273 ; k273 = "SetRSTSSubtitleState"
.line	0	closure      r23   f44
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k274 ; k274 = "OnRSTSSubtitleASRSta" (truncated)
.line	0	closure      r23   f45
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k275 ; k275 = "OnSessionForAIInfoCa" (truncated)
.line	0	closure      r23   f46
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k276 ; k276 = "OnRSTSSubtitleCallba" (truncated)
.line	0	closure      r23   f47
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k277 ; k277 = "_NotifyDialogASRText"
.line	0	closure      r23   f48
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k278 ; k278 = "HandleOnPlayerSendMs" (truncated)
.line	0	closure      r23   f49
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k279 ; k279 = "HandleOnNPCDialogSen" (truncated)
.line	0	closure      r23   f50
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k280 ; k280 = "SendDeliveryDataByVo" (truncated)
.line	0	closure      r23   f51
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k281 ; k281 = "InitSecurityBaseInfo"
.line	0	closure      r23   f52
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k282 ; k282 = "OnSTTStateChange"
.line	0	closure      r23   f53
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k283 ; k283 = "OnDeliverDataCallbac" (truncated)
.line	0	closure      r23   f54
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k284 ; k284 = "_ResolveVoiceMessage" (truncated)
.line	0	closure      r23   f55
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k285 ; k285 = "GetRegionID"
.line	0	closure      r23   f56
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k286 ; k286 = "CanOpenMLAIVoice"
.line	0	closure      r23   f57
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k287 ; k287 = "CanSendDeliverInfo"
.line	0	closure      r23   f58
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k288 ; k288 = "_CheckMinorComplianc" (truncated)
.line	0	closure      r23   f59
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k289 ; k289 = "_IsMinorByLegacyChec" (truncated)
.line	0	closure      r23   f60
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k290 ; k290 = "OnMemberVoice"
.line	0	closure      r23   f61
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k291 ; k291 = "OnCommonMemberIsSpea" (truncated)
.line	0	closure      r23   f62
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k292 ; k292 = "_HandleNeutralNPCMem" (truncated)
.line	0	closure      r23   f63
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k293 ; k293 = "IsMasterOfTeammate"
.line	0	closure      r23   f64
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k294 ; k294 = "StartPlayVoiceFile"
.line	0	closure      r23   f65
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k295 ; k295 = "StopPlayVoiceFile"
.line	0	closure      r23   f66
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k296 ; k296 = "OnDownloadFileEnd"
.line	0	closure      r23   f67
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k297 ; k297 = "OnDownloadFileStart"
.line	0	closure      r23   f68
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k298 ; k298 = "OnVoiceFileEndPlay"
.line	0	closure      r23   f69
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k299 ; k299 = "OnPlayerSubmitCompla" (truncated)
.line	0	closure      r23   f70
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k300 ; k300 = "OnMLAIReplyText"
.line	0	closure      r23   f71
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k301 ; k301 = "OnReceiveTeamMsg"
.line	0	closure      r23   f72
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k302 ; k302 = "RecordAIReplyTextCli" (truncated)
.line	0	closure      r23   f73
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k303 ; k303 = "_AddAIDialogContext"
.line	0	closure      r23   f74
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k304 ; k304 = "_PruneAIDialogContex" (truncated)
.line	0	closure      r23   f75
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k305 ; k305 = "GetAIDialogContextFo" (truncated)
.line	0	closure      r23   f76
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k306 ; k306 = "GetTeammatePlayerSta" (truncated)
.line	0	closure      r23   f77
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k307 ; k307 = "GetNeutralNPCUIDByOp" (truncated)
.line	0	closure      r23   f78
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k308 ; k308 = "SendMLAIVoiceDebugIn" (truncated)
.line	0	closure      r23   f79
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k309 ; k309 = "GetCurrentServerTime" (truncated)
.line	0	closure      r23   f80
.line	0	settable      r2   r22   r23
.line	0	loadk        r22  k310 ; k310 = "require"
.line	0	gettabup     r22    u0   r22
.line	0	move         r23    r1
.line	0	loadk        r24  k311 ; k311 = 187
.line	0	loadk        r25  k312 ; k312 = 19
.line	0	loadk        r26  k313 ; k313 = 57
.line	0	loadk        r27  k314 ; k314 = 172
.line	0	loadk        r28  k315 ; k315 = 163
.line	0	call         r23     6     2
.line	0	call         r22     2     2
.line	0	loadk        r23  k310 ; k310 = "require"
.line	0	gettabup     r23    u0   r23
.line	0	loadk        r24  k316 ; k316 = "table"
.line	0	gettabup     r24    u0   r24
.line	0	loadk        r25  k317 ; k317 = "concat"
.line	0	gettable     r24   r24   r25
.line	0	newtable     r25     1     0
.line	0	move         r26    r1
.line	0	loadk        r27  k318 ; k318 = 159
.line	0	loadk        r28  k319 ; k319 = 30
.line	0	loadk        r29  k320 ; k320 = 53
.line	0	loadk        r30  k321 ; k321 = 186
.line	0	loadk        r31  k322 ; k322 = 156
.line	0	loadk        r32  k323 ; k323 = 228
.line	0	loadk        r33  k324 ; k324 = 118
.line	0	loadk        r34  k325 ; k325 = 54
.line	0	loadk        r35  k326 ; k326 = 126
.line	0	loadk        r36  k327 ; k327 = 236
.line	0	loadk        r37  k315 ; k315 = 163
.line	0	loadk        r38  k328 ; k328 = 217
.line	0	loadk        r39  k329 ; k329 = 137
.line	0	loadk        r40  k330 ; k330 = 210
.line	0	loadk        r41  k331 ; k331 = 109
.line	0	loadk        r42  k332 ; k332 = 175
.line	0	loadk        r43  k333 ; k333 = 101
.line	0	loadk        r44  k334 ; k334 = 32
.line	0	loadk        r45  k335 ; k335 = 76
.line	0	loadk        r46  k336 ; k336 = 193
.line	0	loadk        r47  k337 ; k337 = 103
.line	0	loadk        r48  k338 ; k338 = 192
.line	0	loadk        r49  k339 ; k339 = 10
.line	0	loadk        r50  k340 ; k340 = 77
.line	0	loadk        r51  k341 ; k341 = 115
.line	0	loadk        r52  k342 ; k342 = 255
.line	0	loadk        r53  k343 ; k343 = 182
.line	0	loadk        r54  k344 ; k344 = 158
.line	0	loadk        r55  k345 ; k345 = 245
.line	0	loadk        r56  k346 ; k346 = 229
.line	0	loadk        r57  k347 ; k347 = 107
.line	0	loadk        r58  k311 ; k311 = 187
.line	0	loadk        r59  k335 ; k335 = 76
.line	0	loadk        r60  k348 ; k348 = 42
.line	0	loadk        r61  k349 ; k349 = 74
.line	0	loadk        r62  k350 ; k350 = 154
.line	0	loadk        r63  k319 ; k319 = 30
.line	0	loadk        r64  k351 ; k351 = 242
.line	0	loadk        r65  k352 ; k352 = 24
.line	0	loadk        r66  k353 ; k353 = 85
.line	0	call         r26    41     2
.line	0	move         r27    r1
.line	0	loadk        r28  k354 ; k354 = 181
.line	0	loadk        r29  k355 ; k355 = 16
.line	0	loadk        r30  k325 ; k325 = 54
.line	0	loadk        r31  k356 ; k356 = 241
.line	0	loadk        r32  k357 ; k357 = 150
.line	0	loadk        r33  k358 ; k358 = 244
.line	0	loadk        r34  k324 ; k324 = 118
.line	0	loadk        r35  k359 ; k359 = 108
.line	0	loadk        r36  k360 ; k360 = 70
.line	0	loadk        r37  k356 ; k356 = 241
.line	0	loadk        r38  k361 ; k361 = 162
.line	0	loadk        r39  k354 ; k354 = 181
.line	0	loadk        r40  k362 ; k362 = 170
.line	0	loadk        r41  k338 ; k338 = 192
.line	0	loadk        r42  k363 ; k363 = 123
.line	0	call         r27    16     0
.line	0	setlist      r25     0     1
.line	0	call         r24     2     2
.line	0	call         r23     2     2
.line	0	move         r24   r22
.line	0	move         r25   r23
.line	0	loadnil      r26     0
.line	0	move         r27    r2
.line	0	call         r24     4     2
.line	0	return       r24     2
.line	0	return        r0     1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f0

.source	null
.linedefined	2
.lastlinedefined	9
.numparams	0
.is_vararg	1
.maxstacksize	9

.upvalue	"_ENV"	0	false
.upvalue	"U1"	0	true

.constant	k0	1
.constant	k1	"string"
.constant	k2	"char"
.constant	k3	16
.constant	k4	31
.constant	k5	7
.constant	k6	256
.constant	k7	"table"
.constant	k8	"concat"

.line	2	newtable      r0     0     0
.line	2	vararg        r1     0
.line	2	setlist       r0     0     1
.line	2	newtable      r1     0     0
.line	2	loadk         r2    k0 ; k0 = 1
.line	2	len           r3    r0
.line	2	loadk         r4    k0 ; k0 = 1
.line	2	move          r0    r0
.line	2	gettabup      r6    u0    k1 ; k1 = "string"
.line	2	gettable      r6    r6    k2 ; k2 = "char"
.line	2	gettable      r7    r0    r5
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mod           r8    r8    k3 ; k3 = 16
.line	2	add           r8    r8    k0 ; k0 = 1
.line	2	gettabup      r8    u1    r8
.line	2	bxor          r7    r7    r8
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mul           r8    r8    k4 ; k4 = 31
.line	2	add           r8    r8    k5 ; k5 = 7
.line	2	mod           r8    r8    k6 ; k6 = 256
.line	2	bxor          r7    r7    r8
.line	2	mod           r7    r7    k6 ; k6 = 256
.line	2	call          r6     2     2
.line	2	settable      r1    r5    r6
.line	2	move          r0    r0
.line	2	gettabup      r2    u0    k7 ; k7 = "table"
.line	2	gettable      r2    r2    k8 ; k8 = "concat"
.line	2	move          r3    r1
.line	2	tailcall      r2     2
.line	2	return        r2     0
.line	2	return        r0     1
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	return        r0     1

.function	main/f1

.source	null
.linedefined	88
.lastlinedefined	89
.numparams	1
.is_vararg	0
.maxstacksize	2

.line	88	return        r0     1
.line	88	move          r0    r0
.line	88	move          r0    r0
.line	88	return        r0     1

.function	main/f2

.source	null
.linedefined	91
.lastlinedefined	103
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	"bOpenMLAIVoice"
.constant	k1	false
.constant	k2	"nRSTSSceneID"
.constant	k3	0
.constant	k4	"EnabledRSTSSceneID"
.constant	k5	"bPublicOpinionASRDesired"
.constant	k6	"DialogTargetUID"
.constant	k7	"SceneLessDialogTargetUID"
.constant	k8	"MLAIVoiceHolders"
.constant	k9	"VoiceFileDownloadRecord"
.constant	k10	"ASRRecord"
.constant	k11	"MemberVoiceRecod"
.constant	k12	"AIDialogContextRecord"

.line	91	settable      r0    k0    k1 ; k1 = false
.line	91	settable      r0    k2    k3 ; k3 = 0
.line	91	settable      r0    k4    k3 ; k3 = 0
.line	91	settable      r0    k5    k1 ; k1 = false
.line	91	settable      r0    k6    k3 ; k3 = 0
.line	91	settable      r0    k7    k3 ; k3 = 0
.line	91	newtable      r1     0     0
.line	91	settable      r0    k8    r1 ; k8 = "MLAIVoiceHolders"
.line	91	newtable      r1     0     0
.line	91	settable      r0    k9    r1 ; k9 = "VoiceFileDownloadRec" (truncated)
.line	91	newtable      r1     0     0
.line	91	settable      r0   k10    r1 ; k10 = "ASRRecord"
.line	91	newtable      r1     0     0
.line	91	settable      r0   k11    r1 ; k11 = "MemberVoiceRecod"
.line	91	newtable      r1     0     0
.line	91	settable      r0   k12    r1 ; k12 = "AIDialogContextRecor" (truncated)
.line	91	return        r0     1
.line	91	move          r0    r0
.line	91	move          r0    r0
.line	91	move          r0    r0
.line	91	return        r0     1

.function	main/f3

.source	null
.linedefined	105
.lastlinedefined	124
.numparams	1
.is_vararg	0
.maxstacksize	22

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"import"
.constant	k1	157
.constant	k2	51
.constant	k3	49
.constant	k4	185
.constant	k5	181
.constant	k6	229
.constant	k7	126
.constant	k8	117
.constant	k9	86
.constant	k10	192
.constant	k11	168
.constant	k12	153
.constant	k13	175
.constant	k14	218
.constant	k15	106
.constant	k16	163
.constant	k17	71
.constant	k18	33
.constant	k19	186
.constant	k20	48
.constant	k21	40
.constant	k22	190
.constant	k23	220
.constant	k24	91
.constant	k25	89
.constant	k26	122
.constant	k27	213
.constant	k28	158
.constant	k29	214
.constant	k30	"COND_None"
.constant	k31	"UEnums"
.constant	k32	"EPropertyClass"
.constant	k33	"Bool"
.constant	k34	182
.constant	k35	45
.constant	k36	11
.constant	k37	139
.constant	k38	131
.constant	k39	194
.constant	k40	116
.constant	k41	125
.constant	k42	93
.constant	k43	230
.constant	k44	142
.constant	k45	179
.constant	k46	"Int"
.constant	k47	156
.constant	k48	22
.constant	k49	57
.constant	k50	191
.constant	k51	246
.constant	k52	67
.constant	k53	121
.constant	k54	65
.constant	k55	228
.constant	k56	162
.constant	k57	250
.constant	k58	90
.constant	k59	"UInt64"

.line	105	gettabup      r1    u0    k0 ; k0 = "import"
.line	105	getupval      r2    u1
.line	105	loadk         r3    k1 ; k1 = 157
.line	105	loadk         r4    k2 ; k2 = 51
.line	105	loadk         r5    k3 ; k3 = 49
.line	105	loadk         r6    k4 ; k4 = 185
.line	105	loadk         r7    k5 ; k5 = 181
.line	105	loadk         r8    k6 ; k6 = 229
.line	105	loadk         r9    k7 ; k7 = 126
.line	105	loadk        r10    k8 ; k8 = 117
.line	105	loadk        r11    k9 ; k9 = 86
.line	105	loadk        r12   k10 ; k10 = 192
.line	105	loadk        r13   k11 ; k11 = 168
.line	105	loadk        r14   k12 ; k12 = 153
.line	105	loadk        r15   k13 ; k13 = 175
.line	105	loadk        r16   k14 ; k14 = 218
.line	105	loadk        r17   k15 ; k15 = 106
.line	105	loadk        r18   k16 ; k16 = 163
.line	105	loadk        r19   k17 ; k17 = 71
.line	105	loadk        r20   k18 ; k18 = 33
.line	105	call          r2    19     2
.line	105	call          r1     2     2
.line	105	newtable      r2     3     0
.line	105	newtable      r3     3     0
.line	105	getupval      r4    u1
.line	105	loadk         r5   k19 ; k19 = 186
.line	105	loadk         r6   k20 ; k20 = 48
.line	105	loadk         r7   k21 ; k21 = 40
.line	105	loadk         r8   k19 ; k19 = 186
.line	105	loadk         r9   k22 ; k22 = 190
.line	105	loadk        r10   k23 ; k23 = 220
.line	105	loadk        r11   k24 ; k24 = 91
.line	105	loadk        r12   k25 ; k25 = 89
.line	105	loadk        r13   k26 ; k26 = 122
.line	105	loadk        r14   k27 ; k27 = 213
.line	105	loadk        r15   k11 ; k11 = 168
.line	105	loadk        r16   k28 ; k28 = 158
.line	105	loadk        r17   k11 ; k11 = 168
.line	105	loadk        r18   k29 ; k29 = 214
.line	105	call          r4    15     2
.line	105	gettable      r5    r1   k30 ; k30 = "COND_None"
.line	105	gettabup      r6    u0   k31 ; k31 = "UEnums"
.line	105	gettable      r6    r6   k32 ; k32 = "EPropertyClass"
.line	105	gettable      r6    r6   k33 ; k33 = "Bool"
.line	105	setlist       r3     3     1
.line	105	newtable      r4     3     0
.line	105	getupval      r5    u1
.line	105	loadk         r6   k34 ; k34 = 182
.line	105	loadk         r7   k35 ; k35 = 45
.line	105	loadk         r8   k36 ; k36 = 11
.line	105	loadk         r9   k37 ; k37 = 139
.line	105	loadk        r10   k38 ; k38 = 131
.line	105	loadk        r11   k39 ; k39 = 194
.line	105	loadk        r12   k40 ; k40 = 116
.line	105	loadk        r13   k41 ; k41 = 125
.line	105	loadk        r14   k42 ; k42 = 93
.line	105	loadk        r15   k43 ; k43 = 230
.line	105	loadk        r16   k44 ; k44 = 142
.line	105	loadk        r17   k45 ; k45 = 179
.line	105	call          r5    13     2
.line	105	gettable      r6    r1   k30 ; k30 = "COND_None"
.line	105	gettabup      r7    u0   k31 ; k31 = "UEnums"
.line	105	gettable      r7    r7   k32 ; k32 = "EPropertyClass"
.line	105	gettable      r7    r7   k46 ; k46 = "Int"
.line	105	setlist       r4     3     1
.line	105	newtable      r5     3     0
.line	105	getupval      r6    u1
.line	105	loadk         r7   k47 ; k47 = 156
.line	105	loadk         r8   k48 ; k48 = 22
.line	105	loadk         r9   k49 ; k49 = 57
.line	105	loadk        r10   k45 ; k45 = 179
.line	105	loadk        r11   k50 ; k50 = 191
.line	105	loadk        r12   k51 ; k51 = 246
.line	105	loadk        r13   k52 ; k52 = 67
.line	105	loadk        r14   k53 ; k53 = 121
.line	105	loadk        r15   k54 ; k54 = 65
.line	105	loadk        r16   k55 ; k55 = 228
.line	105	loadk        r17   k56 ; k56 = 162
.line	105	loadk        r18   k38 ; k38 = 131
.line	105	loadk        r19   k28 ; k28 = 158
.line	105	loadk        r20   k57 ; k57 = 250
.line	105	loadk        r21   k58 ; k58 = 90
.line	105	call          r6    16     2
.line	105	gettable      r7    r1   k30 ; k30 = "COND_None"
.line	105	gettabup      r8    u0   k31 ; k31 = "UEnums"
.line	105	gettable      r8    r8   k32 ; k32 = "EPropertyClass"
.line	105	gettable      r8    r8   k59 ; k59 = "UInt64"
.line	105	setlist       r5     3     1
.line	105	setlist       r2     3     1
.line	105	return        r2     2
.line	105	return        r0     1
.line	105	move          r0    r0
.line	105	return        r0     1

.function	main/f4

.source	null
.linedefined	128
.lastlinedefined	130
.numparams	1
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	2	true

.constant	k0	"__super"
.constant	k1	"ReceiveBeginPlay"

.line	128	gettabup      r1    u0    k0 ; k0 = "__super"
.line	128	gettable      r1    r1    k1 ; k1 = "ReceiveBeginPlay"
.line	128	move          r2    r0
.line	128	call          r1     2     1
.line	128	return        r0     1
.line	128	move          r0    r0
.line	128	move          r0    r0
.line	128	move          r0    r0
.line	128	move          r0    r0
.line	128	return        r0     1

.function	main/f5

.source	null
.linedefined	132
.lastlinedefined	147
.numparams	2
.is_vararg	0
.maxstacksize	41

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	2	true

.constant	k0	"bFamilyCenterQueryPending"
.constant	k1	false
.constant	k2	"FamilyCenterQuerySeq"
.constant	k3	0
.constant	k4	1
.constant	k5	"Client"
.constant	k6	"AntsVoiceInterface"
.constant	k7	"GetMicState"
.constant	k8	"SetRSTSSubtitleState"
.constant	k9	157
.constant	k10	17
.constant	k11	60
.constant	k12	143
.constant	k13	188
.constant	k14	240
.constant	k15	110
.constant	k16	"require"
.constant	k17	187
.constant	k18	19
.constant	k19	49
.constant	k20	186
.constant	k21	190
.constant	k22	229
.constant	k23	57
.constant	k24	117
.constant	k25	92
.constant	k26	231
.constant	k27	178
.constant	k28	155
.constant	k29	174
.constant	k30	236
.constant	k31	120
.constant	k32	184
.constant	k33	73
.constant	k34	34
.constant	k35	77
.constant	k36	152
.constant	k37	79
.constant	k38	211
.constant	k39	12
.constant	k40	6
.constant	k41	252
.constant	k42	179
.constant	k43	146
.constant	k44	183
.constant	k45	198
.constant	k46	67
.constant	k47	86
.constant	k48	62
.constant	k49	95
.constant	k50	154
.constant	k51	66
.constant	k52	"GetModule"
.constant	k53	"CommonModuleConfig"
.constant	k54	"logic_chat_voice"
.constant	k55	"TryStopPlayRecordVoice"
.constant	k56	"UnRegistSceneEvent"
.constant	k57	"UnRegistUplinkEvent"
.constant	k58	"UnRegistBaseEvent"
.constant	k59	"__super"
.constant	k60	"ReceiveEndPlay"

.line	132	settable      r0    k0    k1 ; k1 = false
.line	132	gettable      r2    r0    k2 ; k2 = "FamilyCenterQuerySeq"
.line	132	test          r2     1
.line	132	jmp            0    l6
.line	132	loadk         r2    k3 ; k3 = 0
.label	l6
.line	132	add           r2    r2    k4 ; k4 = 1
.line	132	settable      r0    k2    r2 ; k2 = "FamilyCenterQuerySeq"
.line	132	gettabup      r2    u0    k5 ; k5 = "Client"
.line	132	test          r2     0
.line	132	jmp            0   l78
.line	132	gettable      r2    r0    k6 ; k6 = "AntsVoiceInterface"
.line	132	test          r2     0
.line	132	jmp            0   l78
.line	132	gettable      r2    r0    k6 ; k6 = "AntsVoiceInterface"
.line	132	self          r2    r2    k7 ; k7 = "GetMicState"
.line	132	call          r2     2     2
.line	132	test          r2     0
.line	132	jmp            0   l31
.line	132	self          r2    r0    k8 ; k8 = "SetRSTSSubtitleState"
.line	132	loadk         r4    k3 ; k3 = 0
.line	132	getupval      r5    u1
.line	132	loadk         r6    k9 ; k9 = 157
.line	132	loadk         r7   k10 ; k10 = 17
.line	132	loadk         r8   k11 ; k11 = 60
.line	132	loadk         r9   k12 ; k12 = 143
.line	132	loadk        r10   k13 ; k13 = 188
.line	132	loadk        r11   k14 ; k14 = 240
.line	132	loadk        r12   k15 ; k15 = 110
.line	132	call          r5     8     2
.line	132	call          r2     4     1
.label	l31
.line	132	gettabup      r2    u0   k16 ; k16 = "require"
.line	132	getupval      r3    u1
.line	132	loadk         r4   k17 ; k17 = 187
.line	132	loadk         r5   k18 ; k18 = 19
.line	132	loadk         r6   k19 ; k19 = 49
.line	132	loadk         r7   k20 ; k20 = 186
.line	132	loadk         r8   k21 ; k21 = 190
.line	132	loadk         r9   k22 ; k22 = 229
.line	132	loadk        r10   k23 ; k23 = 57
.line	132	loadk        r11   k24 ; k24 = 117
.line	132	loadk        r12   k25 ; k25 = 92
.line	132	loadk        r13   k26 ; k26 = 231
.line	132	loadk        r14   k27 ; k27 = 178
.line	132	loadk        r15   k28 ; k28 = 155
.line	132	loadk        r16   k29 ; k29 = 174
.line	132	loadk        r17   k30 ; k30 = 236
.line	132	loadk        r18   k31 ; k31 = 120
.line	132	loadk        r19   k32 ; k32 = 184
.line	132	loadk        r20   k33 ; k33 = 73
.line	132	loadk        r21   k34 ; k34 = 34
.line	132	loadk        r22   k35 ; k35 = 77
.line	132	loadk        r23   k36 ; k36 = 152
.line	132	loadk        r24   k37 ; k37 = 79
.line	132	loadk        r25   k38 ; k38 = 211
.line	132	loadk        r26   k39 ; k39 = 12
.line	132	loadk        r27   k40 ; k40 = 6
.line	132	loadk        r28   k15 ; k15 = 110
.line	132	loadk        r29   k41 ; k41 = 252
.line	132	loadk        r30   k42 ; k42 = 179
.line	132	loadk        r31   k43 ; k43 = 146
.line	132	loadk        r32   k44 ; k44 = 183
.line	132	loadk        r33   k45 ; k45 = 198
.line	132	loadk        r34   k46 ; k46 = 67
.line	132	loadk        r35   k17 ; k17 = 187
.line	132	loadk        r36   k47 ; k47 = 86
.line	132	loadk        r37   k48 ; k48 = 62
.line	132	loadk        r38   k49 ; k49 = 95
.line	132	loadk        r39   k50 ; k50 = 154
.line	132	loadk        r40   k51 ; k51 = 66
.line	132	call          r3    38     2
.line	132	call          r2     2     2
.line	132	gettable      r3    r2   k52 ; k52 = "GetModule"
.line	132	gettable      r4    r2   k53 ; k53 = "CommonModuleConfig"
.line	132	gettable      r4    r4   k54 ; k54 = "logic_chat_voice"
.line	132	call          r3     2     2
.line	132	self          r4    r3   k55 ; k55 = "TryStopPlayRecordVoi" (truncated)
.line	132	call          r4     2     1
.label	l78
.line	132	self          r2    r0   k56 ; k56 = "UnRegistSceneEvent"
.line	132	call          r2     2     1
.line	132	self          r2    r0   k57 ; k57 = "UnRegistUplinkEvent"
.line	132	call          r2     2     1
.line	132	self          r2    r0   k58 ; k58 = "UnRegistBaseEvent"
.line	132	call          r2     2     1
.line	132	gettabup      r2    u2   k59 ; k59 = "__super"
.line	132	gettable      r2    r2   k60 ; k60 = "ReceiveEndPlay"
.line	132	move          r3    r0
.line	132	move          r4    r1
.line	132	call          r2     3     1
.line	132	return        r0     1
.line	132	move          r0    r0
.line	132	move          r0    r0
.line	132	move          r0    r0
.line	132	move          r0    r0
.line	132	return        r0     1

.function	main/f6

.source	null
.linedefined	149
.lastlinedefined	164
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	21	true

.constant	k0	"_bDevTranslateUrlSet"
.constant	k1	"Client"
.constant	k2	"IsDevelopment"
.constant	k3	"slua"
.constant	k4	"isValid"
.constant	k5	"AntsVoiceInterface"
.constant	k6	"slua_GameFrontendHUD"
.constant	k7	"GetVoiceSDKInterface"
.constant	k8	"print"
.constant	k9	"bWriteLog"
.constant	k10	"table"
.constant	k11	"concat"
.constant	k12	149
.constant	k13	51
.constant	k14	25
.constant	k15	150
.constant	k16	134
.constant	k17	254
.constant	k18	126
.constant	k19	123
.constant	k20	86
.constant	k21	197
.constant	k22	162
.constant	k23	191
.constant	k24	198
.constant	k25	108
.constant	k26	175
.constant	k27	18
.constant	k28	16
.constant	k29	105
.constant	k30	159
.constant	k31	80
.constant	k32	205
.constant	k33	30
.constant	k34	70
.constant	k35	229
.constant	k36	131
.constant	k37	186
.constant	k38	125
.constant	k39	182
.constant	k40	89
.constant	k41	43
.constant	k42	93
.constant	k43	170
.constant	k44	66
.constant	k45	221
.constant	k46	56
.constant	k47	187
.constant	k48	26
.constant	k49	120
.constant	k50	242
.constant	k51	240
.constant	k52	199
.constant	k53	113
.constant	k54	230
.constant	k55	231
.constant	k56	164
.constant	k57	143
.constant	k58	248
.constant	k59	62
.constant	k60	163
.constant	k61	59
.constant	k62	77
.constant	k63	157
.constant	k64	192
.constant	k65	4
.constant	k66	3
.constant	k67	250
.constant	k68	185
.constant	k69	145
.constant	k70	207
.constant	k71	103
.constant	k72	190
.constant	k73	true
.constant	k74	"SetServerUrl"
.constant	k75	1
.constant	k76	"string"
.constant	k77	"format"
.constant	k78	194
.constant	k79	114
.constant	k80	96
.constant	k81	181
.constant	k82	129
.constant	k83	174
.constant	k84	193
.constant	k85	75
.constant	k86	184
.constant	k87	68
.constant	k88	195
.constant	k89	0
.constant	k90	132
.constant	k91	20

.line	149	gettable      r1    r0    k0 ; k0 = "_bDevTranslateUrlSet"
.line	149	test          r1     0
.line	149	jmp            0    l5
.line	149	return        r0     1
.label	l5
.line	149	gettabup      r1    u0    k1 ; k1 = "Client"
.line	149	gettable      r1    r1    k2 ; k2 = "IsDevelopment"
.line	149	call          r1     1     2
.line	149	test          r1     1
.line	149	jmp            0   l11
.line	149	return        r0     1
.label	l11
.line	149	gettabup      r1    u0    k3 ; k3 = "slua"
.line	149	gettable      r1    r1    k4 ; k4 = "isValid"
.line	149	gettable      r2    r0    k5 ; k5 = "AntsVoiceInterface"
.line	149	call          r1     2     2
.line	149	test          r1     0
.line	149	jmp            0   l20
.line	149	gettable      r1    r0    k5 ; k5 = "AntsVoiceInterface"
.line	149	test          r1     1
.line	149	jmp            0   l29
.label	l20
.line	149	gettabup      r1    u0    k6 ; k6 = "slua_GameFrontendHUD"
.line	149	test          r1     0
.line	149	jmp            0   l28
.line	149	gettabup      r1    u0    k6 ; k6 = "slua_GameFrontendHUD"
.line	149	self          r1    r1    k7 ; k7 = "GetVoiceSDKInterface"
.line	149	call          r1     2     2
.line	149	test          r1     1
.line	149	jmp            0   l29
.label	l28
.line	149	loadnil       r1     0
.label	l29
.line	149	gettabup      r2    u0    k3 ; k3 = "slua"
.line	149	gettable      r2    r2    k4 ; k4 = "isValid"
.line	149	move          r3    r1
.line	149	call          r2     2     2
.line	149	test          r2     1
.line	149	jmp            0  l122
.line	149	gettabup      r2    u0    k8 ; k8 = "print"
.line	149	gettabup      r3    u0    k9 ; k9 = "bWriteLog"
.line	149	test          r3     0
.line	149	jmp            0  l120
.line	149	gettabup      r3    u0   k10 ; k10 = "table"
.line	149	gettable      r3    r3   k11 ; k11 = "concat"
.line	149	newtable      r4     1     0
.line	149	getupval      r5    u1
.line	149	loadk         r6   k12 ; k12 = 149
.line	149	loadk         r7   k13 ; k13 = 51
.line	149	loadk         r8   k14 ; k14 = 25
.line	149	loadk         r9   k15 ; k15 = 150
.line	149	loadk        r10   k16 ; k16 = 134
.line	149	loadk        r11   k17 ; k17 = 254
.line	149	loadk        r12   k18 ; k18 = 126
.line	149	loadk        r13   k19 ; k19 = 123
.line	149	loadk        r14   k20 ; k20 = 86
.line	149	loadk        r15   k21 ; k21 = 197
.line	149	loadk        r16   k22 ; k22 = 162
.line	149	loadk        r17   k15 ; k15 = 150
.line	149	loadk        r18   k23 ; k23 = 191
.line	149	loadk        r19   k24 ; k24 = 198
.line	149	loadk        r20   k25 ; k25 = 108
.line	149	loadk        r21   k26 ; k26 = 175
.line	149	loadk        r22   k27 ; k27 = 18
.line	149	loadk        r23   k28 ; k28 = 16
.line	149	loadk        r24   k29 ; k29 = 105
.line	149	loadk        r25   k30 ; k30 = 159
.line	149	loadk        r26   k31 ; k31 = 80
.line	149	loadk        r27   k32 ; k32 = 205
.line	149	loadk        r28   k33 ; k33 = 30
.line	149	loadk        r29   k25 ; k25 = 108
.line	149	loadk        r30   k34 ; k34 = 70
.line	149	loadk        r31   k35 ; k35 = 229
.line	149	loadk        r32   k36 ; k36 = 131
.line	149	loadk        r33   k12 ; k12 = 149
.line	149	loadk        r34   k37 ; k37 = 186
.line	149	loadk        r35   k32 ; k32 = 205
.line	149	loadk        r36   k38 ; k38 = 125
.line	149	loadk        r37   k39 ; k39 = 182
.line	149	loadk        r38   k40 ; k40 = 89
.line	149	loadk        r39   k41 ; k41 = 43
.line	149	loadk        r40   k42 ; k42 = 93
.line	149	loadk        r41   k43 ; k43 = 170
.line	149	loadk        r42   k44 ; k44 = 66
.line	149	loadk        r43   k45 ; k45 = 221
.line	149	loadk        r44   k46 ; k46 = 56
.line	149	loadk        r45   k20 ; k20 = 86
.line	149	call          r5    41     2
.line	149	getupval      r6    u1
.line	149	loadk         r7   k47 ; k47 = 187
.line	149	loadk         r8   k48 ; k48 = 26
.line	149	loadk         r9   k49 ; k49 = 120
.line	149	loadk        r10   k50 ; k50 = 242
.line	149	loadk        r11   k51 ; k51 = 240
.line	149	loadk        r12   k52 ; k52 = 199
.line	149	loadk        r13   k49 ; k49 = 120
.line	149	loadk        r14   k53 ; k53 = 113
.line	149	loadk        r15   k31 ; k31 = 80
.line	149	loadk        r16   k54 ; k54 = 230
.line	149	loadk        r17   k55 ; k55 = 231
.line	149	loadk        r18   k56 ; k56 = 164
.line	149	loadk        r19   k57 ; k57 = 143
.line	149	loadk        r20   k58 ; k58 = 248
.line	149	loadk        r21   k59 ; k59 = 62
.line	149	loadk        r22   k60 ; k60 = 163
.line	149	loadk        r23   k34 ; k34 = 70
.line	149	loadk        r24   k61 ; k61 = 59
.line	149	loadk        r25   k62 ; k62 = 77
.line	149	loadk        r26   k63 ; k63 = 157
.line	149	loadk        r27   k34 ; k34 = 70
.line	149	loadk        r28   k64 ; k64 = 192
.line	149	loadk        r29   k65 ; k65 = 4
.line	149	loadk        r30   k62 ; k62 = 77
.line	149	loadk        r31   k66 ; k66 = 3
.line	149	loadk        r32   k67 ; k67 = 250
.line	149	loadk        r33   k68 ; k68 = 185
.line	149	loadk        r34   k69 ; k69 = 145
.line	149	loadk        r35   k37 ; k37 = 186
.line	149	loadk        r36   k70 ; k70 = 207
.line	149	loadk        r37   k71 ; k71 = 103
.line	149	loadk        r38   k72 ; k72 = 190
.line	149	call          r6    33     0
.line	149	setlist       r4     0     1
.line	149	call          r3     2     2
.label	l120
.line	149	call          r2     2     1
.line	149	return        r0     1
.label	l122
.line	149	settable      r0    k0   k73 ; k73 = true
.line	149	self          r2    r1   k74 ; k74 = "SetServerUrl"
.line	149	loadk         r4   k75 ; k75 = 1
.line	149	getupval      r5    u2
.line	149	call          r2     4     1
.line	149	gettabup      r2    u0    k8 ; k8 = "print"
.line	149	gettabup      r3    u0    k9 ; k9 = "bWriteLog"
.line	149	test          r3     0
.line	149	jmp            0  l208
.line	149	gettabup      r3    u0   k76 ; k76 = "string"
.line	149	gettable      r3    r3   k77 ; k77 = "format"
.line	149	gettabup      r4    u0   k10 ; k10 = "table"
.line	149	gettable      r4    r4   k11 ; k11 = "concat"
.line	149	newtable      r5     1     0
.line	149	getupval      r6    u1
.line	149	loadk         r7   k12 ; k12 = 149
.line	149	loadk         r8   k13 ; k13 = 51
.line	149	loadk         r9   k14 ; k14 = 25
.line	149	loadk        r10   k15 ; k15 = 150
.line	149	loadk        r11   k16 ; k16 = 134
.line	149	loadk        r12   k17 ; k17 = 254
.line	149	loadk        r13   k18 ; k18 = 126
.line	149	loadk        r14   k19 ; k19 = 123
.line	149	loadk        r15   k20 ; k20 = 86
.line	149	loadk        r16   k21 ; k21 = 197
.line	149	loadk        r17   k22 ; k22 = 162
.line	149	loadk        r18   k15 ; k15 = 150
.line	149	loadk        r19   k23 ; k23 = 191
.line	149	loadk        r20   k24 ; k24 = 198
.line	149	loadk        r21   k25 ; k25 = 108
.line	149	loadk        r22   k26 ; k26 = 175
.line	149	loadk        r23   k27 ; k27 = 18
.line	149	loadk        r24   k28 ; k28 = 16
.line	149	loadk        r25   k29 ; k29 = 105
.line	149	loadk        r26   k30 ; k30 = 159
.line	149	loadk        r27   k31 ; k31 = 80
.line	149	loadk        r28   k32 ; k32 = 205
.line	149	loadk        r29   k33 ; k33 = 30
.line	149	loadk        r30   k25 ; k25 = 108
.line	149	loadk        r31   k34 ; k34 = 70
.line	149	loadk        r32   k35 ; k35 = 229
.line	149	loadk        r33   k36 ; k36 = 131
.line	149	loadk        r34   k12 ; k12 = 149
.line	149	loadk        r35   k37 ; k37 = 186
.line	149	loadk        r36   k32 ; k32 = 205
.line	149	loadk        r37   k38 ; k38 = 125
.line	149	loadk        r38   k39 ; k39 = 182
.line	149	loadk        r39   k40 ; k40 = 89
.line	149	loadk        r40   k41 ; k41 = 43
.line	149	loadk        r41   k42 ; k42 = 93
.line	149	loadk        r42   k43 ; k43 = 170
.line	149	loadk        r43   k44 ; k44 = 66
.line	149	loadk        r44   k45 ; k45 = 221
.line	149	loadk        r45   k46 ; k46 = 56
.line	149	loadk        r46   k20 ; k20 = 86
.line	149	call          r6    41     2
.line	149	getupval      r7    u1
.line	149	loadk         r8   k47 ; k47 = 187
.line	149	loadk         r9   k48 ; k48 = 26
.line	149	loadk        r10   k49 ; k49 = 120
.line	149	loadk        r11   k50 ; k50 = 242
.line	149	loadk        r12   k51 ; k51 = 240
.line	149	loadk        r13   k78 ; k78 = 194
.line	149	loadk        r14   k79 ; k79 = 114
.line	149	loadk        r15   k25 ; k25 = 108
.line	149	loadk        r16   k80 ; k80 = 96
.line	149	loadk        r17   k54 ; k54 = 230
.line	149	loadk        r18   k81 ; k81 = 181
.line	149	loadk        r19   k82 ; k82 = 129
.line	149	loadk        r20   k83 ; k83 = 174
.line	149	loadk        r21   k84 ; k84 = 193
.line	149	loadk        r22   k85 ; k85 = 75
.line	149	loadk        r23   k86 ; k86 = 184
.line	149	loadk        r24   k87 ; k87 = 68
.line	149	loadk        r25   k71 ; k71 = 103
.line	149	loadk        r26   k14 ; k14 = 25
.line	149	loadk        r27   k88 ; k88 = 195
.line	149	loadk        r28   k89 ; k89 = 0
.line	149	loadk        r29   k90 ; k90 = 132
.line	149	loadk        r30   k91 ; k91 = 20
.line	149	loadk        r31   k75 ; k75 = 1
.line	149	call          r7    25     0
.line	149	setlist       r5     0     1
.line	149	call          r4     2     2
.line	149	getupval      r5    u2
.line	149	call          r3     3     2
.label	l208
.line	149	call          r2     2     1
.line	149	return        r0     1
.line	149	move          r0    r0
.line	149	move          r0    r0
.line	149	move          r0    r0
.line	149	return        r0     1

.function	main/f7

.source	null
.linedefined	166
.lastlinedefined	197
.numparams	1
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	11	true
.upvalue	"U2"	1	true
.upvalue	"U3"	10	true
.upvalue	"U4"	6	true

.constant	k0	"Client"
.constant	k1	"bHasInit"
.constant	k2	"bShowRSTSSubtitleText"
.constant	k3	false
.constant	k4	"bSpeechToTextState"
.constant	k5	"bComplaint"
.constant	k6	"AntsVoiceInterface"
.constant	k7	"slua_GameFrontendHUD"
.constant	k8	"GetVoiceSDKInterface"
.constant	k9	"slua"
.constant	k10	"isValid"
.constant	k11	"GetPlayerController"
.constant	k12	"print"
.constant	k13	"bWriteLog"
.constant	k14	"table"
.constant	k15	"concat"
.constant	k16	149
.constant	k17	51
.constant	k18	25
.constant	k19	150
.constant	k20	134
.constant	k21	254
.constant	k22	126
.constant	k23	123
.constant	k24	86
.constant	k25	197
.constant	k26	162
.constant	k27	191
.constant	k28	198
.constant	k29	108
.constant	k30	175
.constant	k31	18
.constant	k32	0
.constant	k33	70
.constant	k34	166
.constant	k35	78
.constant	k36	200
.constant	k37	19
.constant	k38	8
.constant	k39	115
.constant	k40	255
.constant	k41	182
.constant	k42	158
.constant	k43	190
.constant	k44	209
.constant	k45	77
.constant	k46	181
.constant	k47	43
.constant	k48	74
.constant	k49	144
.constant	k50	92
.constant	k51	221
.constant	k52	248
.constant	k53	22
.constant	k54	"GetChatComponent"
.constant	k55	23
.constant	k56	"GetFirstLanguage"
.constant	k57	"name"
.constant	k58	208
.constant	k59	224
.constant	k60	97
.constant	k61	183
.constant	k62	72
.constant	k63	48
.constant	k64	154
.constant	k65	94
.constant	k66	87
.constant	k67	81
.constant	k68	171
.constant	k69	95
.constant	k70	54
.constant	k71	188
.constant	k72	"LangID"
.constant	k73	"string"
.constant	k74	"format"
.constant	k75	111
.constant	k76	242
.constant	k77	185
.constant	k78	128
.constant	k79	146
.constant	k80	231
.constant	k81	75
.constant	k82	24
.constant	k83	89
.constant	k84	195
.constant	k85	4
.constant	k86	76
.constant	k87	148
.constant	k88	30
.constant	k89	184
.constant	k90	237
.constant	k91	180
.constant	k92	100
.constant	k93	"tostring"
.constant	k94	true
.constant	k95	"InitSecurityBaseInfo"
.constant	k96	"AddCommonEvent"
.constant	k97	"EVENTTYPE_COMPLAINT"
.constant	k98	"EVENTID_SUBMIT_COMPLAINT"
.constant	k99	"OnPlayerSubmitComplaint"
.constant	k100	"EVENTTYPE_INGAME"
.constant	k101	"EVENTID_INGAME_MLAI_REPLY_TEXT"
.constant	k102	"OnMLAIReplyText"
.constant	k103	"EVENTID_INGAME_RECEIVE_TEAM_MSG"
.constant	k104	"OnReceiveTeamMsg"
.constant	k105	"SendMLAIVoiceDebugInfo"
.constant	k106	"ClientInitSuccess"
.constant	k107	145
.constant	k108	17
.constant	k109	49
.constant	k110	"VoiceInterFaceError"

.line	166	gettabup      r1    u0    k0 ; k0 = "Client"
.line	166	test          r1     0
.line	166	jmp            0  l281
.line	166	gettable      r1    r0    k1 ; k1 = "bHasInit"
.line	166	test          r1     1
.line	166	jmp            0  l281
.line	166	settable      r0    k2    k3 ; k3 = false
.line	166	settable      r0    k4    k3 ; k3 = false
.line	166	settable      r0    k5    k3 ; k3 = false
.line	166	gettabup      r1    u0    k7 ; k7 = "slua_GameFrontendHUD"
.line	166	self          r1    r1    k8 ; k8 = "GetVoiceSDKInterface"
.line	166	call          r1     2     2
.line	166	settable      r0    k6    r1 ; k6 = "AntsVoiceInterface"
.line	166	gettabup      r1    u0    k9 ; k9 = "slua"
.line	166	gettable      r1    r1   k10 ; k10 = "isValid"
.line	166	gettable      r2    r0    k6 ; k6 = "AntsVoiceInterface"
.line	166	call          r1     2     2
.line	166	test          r1     0
.line	166	jmp            0  l272
.line	166	gettabup      r1    u1   k11 ; k11 = "GetPlayerController"
.line	166	call          r1     1     2
.line	166	gettabup      r2    u0    k9 ; k9 = "slua"
.line	166	gettable      r2    r2   k10 ; k10 = "isValid"
.line	166	move          r3    r1
.line	166	call          r2     2     2
.line	166	test          r2     1
.line	166	jmp            0   l90
.line	166	gettabup      r2    u0   k12 ; k12 = "print"
.line	166	gettabup      r3    u0   k13 ; k13 = "bWriteLog"
.line	166	test          r3     0
.line	166	jmp            0   l88
.line	166	gettabup      r3    u0   k14 ; k14 = "table"
.line	166	gettable      r3    r3   k15 ; k15 = "concat"
.line	166	newtable      r4     1     0
.line	166	getupval      r5    u2
.line	166	loadk         r6   k16 ; k16 = 149
.line	166	loadk         r7   k17 ; k17 = 51
.line	166	loadk         r8   k18 ; k18 = 25
.line	166	loadk         r9   k19 ; k19 = 150
.line	166	loadk        r10   k20 ; k20 = 134
.line	166	loadk        r11   k21 ; k21 = 254
.line	166	loadk        r12   k22 ; k22 = 126
.line	166	loadk        r13   k23 ; k23 = 123
.line	166	loadk        r14   k24 ; k24 = 86
.line	166	loadk        r15   k25 ; k25 = 197
.line	166	loadk        r16   k26 ; k26 = 162
.line	166	loadk        r17   k19 ; k19 = 150
.line	166	loadk        r18   k27 ; k27 = 191
.line	166	loadk        r19   k28 ; k28 = 198
.line	166	loadk        r20   k29 ; k29 = 108
.line	166	loadk        r21   k30 ; k30 = 175
.line	166	loadk        r22   k31 ; k31 = 18
.line	166	loadk        r23   k32 ; k32 = 0
.line	166	loadk        r24   k33 ; k33 = 70
.line	166	loadk        r25   k34 ; k34 = 166
.line	166	loadk        r26   k35 ; k35 = 78
.line	166	loadk        r27   k36 ; k36 = 200
.line	166	loadk        r28   k37 ; k37 = 19
.line	166	loadk        r29   k38 ; k38 = 8
.line	166	loadk        r30   k39 ; k39 = 115
.line	166	loadk        r31   k40 ; k40 = 255
.line	166	loadk        r32   k41 ; k41 = 182
.line	166	loadk        r33   k42 ; k42 = 158
.line	166	loadk        r34   k43 ; k43 = 190
.line	166	loadk        r35   k44 ; k44 = 209
.line	166	loadk        r36   k45 ; k45 = 77
.line	166	loadk        r37   k46 ; k46 = 181
.line	166	loadk        r38   k24 ; k24 = 86
.line	166	loadk        r39   k47 ; k47 = 43
.line	166	loadk        r40   k48 ; k48 = 74
.line	166	loadk        r41   k49 ; k49 = 144
.line	166	loadk        r42   k50 ; k50 = 92
.line	166	loadk        r43   k51 ; k51 = 221
.line	166	loadk        r44   k31 ; k31 = 18
.line	166	loadk        r45   k48 ; k48 = 74
.line	166	call          r5    41     2
.line	166	getupval      r6    u2
.line	166	loadk         r7   k52 ; k52 = 248
.line	166	loadk         r8   k53 ; k53 = 22
.line	166	loadk         r9   k47 ; k47 = 43
.line	166	loadk        r10   k40 ; k40 = 255
.line	166	loadk        r11   k43 ; k43 = 190
.line	166	loadk        r12   k52 ; k52 = 248
.line	166	loadk        r13   k23 ; k23 = 123
.line	166	call          r6     8     0
.line	166	setlist       r4     0     1
.line	166	call          r3     2     2
.label	l88
.line	166	call          r2     2     1
.line	166	return        r0     1
.label	l90
.line	166	self          r2    r1   k54 ; k54 = "GetChatComponent"
.line	166	call          r2     2     2
.line	166	getupval      r3    u2
.line	166	loadk         r4   k26 ; k26 = 162
.line	166	loadk         r5   k55 ; k55 = 23
.line	166	call          r3     3     2
.line	166	gettabup      r4    u0    k9 ; k9 = "slua"
.line	166	gettable      r4    r4   k10 ; k10 = "isValid"
.line	166	move          r5    r2
.line	166	call          r4     2     2
.line	166	test          r4     0
.line	166	jmp            0  l106
.line	166	self          r4    r2   k56 ; k56 = "GetFirstLanguage"
.line	166	call          r4     2     2
.line	166	gettable      r3    r4   k57 ; k57 = "name"
.line	166	jmp            0  l165
.label	l106
.line	166	gettabup      r4    u0   k12 ; k12 = "print"
.line	166	gettabup      r5    u0   k13 ; k13 = "bWriteLog"
.line	166	test          r5     0
.line	166	jmp            0  l164
.line	166	gettabup      r5    u0   k14 ; k14 = "table"
.line	166	gettable      r5    r5   k15 ; k15 = "concat"
.line	166	newtable      r6     1     0
.line	166	getupval      r7    u2
.line	166	loadk         r8   k16 ; k16 = 149
.line	166	loadk         r9   k17 ; k17 = 51
.line	166	loadk        r10   k18 ; k18 = 25
.line	166	loadk        r11   k19 ; k19 = 150
.line	166	loadk        r12   k20 ; k20 = 134
.line	166	loadk        r13   k21 ; k21 = 254
.line	166	loadk        r14   k22 ; k22 = 126
.line	166	loadk        r15   k23 ; k23 = 123
.line	166	loadk        r16   k24 ; k24 = 86
.line	166	loadk        r17   k25 ; k25 = 197
.line	166	loadk        r18   k26 ; k26 = 162
.line	166	loadk        r19   k19 ; k19 = 150
.line	166	loadk        r20   k27 ; k27 = 191
.line	166	loadk        r21   k28 ; k28 = 198
.line	166	loadk        r22   k29 ; k29 = 108
.line	166	loadk        r23   k30 ; k30 = 175
.line	166	loadk        r24   k31 ; k31 = 18
.line	166	loadk        r25   k32 ; k32 = 0
.line	166	loadk        r26   k33 ; k33 = 70
.line	166	loadk        r27   k34 ; k34 = 166
.line	166	loadk        r28   k35 ; k35 = 78
.line	166	loadk        r29   k36 ; k36 = 200
.line	166	loadk        r30   k37 ; k37 = 19
.line	166	loadk        r31   k38 ; k38 = 8
.line	166	loadk        r32   k24 ; k24 = 86
.line	166	loadk        r33   k58 ; k58 = 208
.line	166	loadk        r34   k27 ; k27 = 191
.line	166	loadk        r35   k20 ; k20 = 134
.line	166	loadk        r36   k30 ; k30 = 175
.line	166	loadk        r37   k59 ; k59 = 224
.line	166	loadk        r38   k60 ; k60 = 97
.line	166	loadk        r39   k61 ; k61 = 183
.line	166	loadk        r40   k62 ; k62 = 72
.line	166	loadk        r41   k63 ; k63 = 48
.line	166	loadk        r42   k24 ; k24 = 86
.line	166	loadk        r43   k64 ; k64 = 154
.line	166	loadk        r44   k65 ; k65 = 94
.line	166	loadk        r45   k25 ; k25 = 197
.line	166	loadk        r46   k66 ; k66 = 87
.line	166	loadk        r47   k67 ; k67 = 81
.line	166	call          r7    41     2
.line	166	getupval      r8    u2
.line	166	loadk         r9   k68 ; k68 = 171
.line	166	loadk        r10   k69 ; k69 = 95
.line	166	loadk        r11   k70 ; k70 = 54
.line	166	loadk        r12   k41 ; k41 = 182
.line	166	loadk        r13   k71 ; k71 = 188
.line	166	call          r8     6     0
.line	166	setlist       r6     0     1
.line	166	call          r5     2     2
.label	l164
.line	166	call          r4     2     1
.label	l165
.line	166	gettabup      r4    u3    r3
.line	166	test          r4     1
.line	166	jmp            0  l169
.line	166	loadk         r4   k32 ; k32 = 0
.label	l169
.line	166	settable      r0   k72    r4 ; k72 = "LangID"
.line	166	gettabup      r4    u0   k12 ; k12 = "print"
.line	166	gettabup      r5    u0   k13 ; k13 = "bWriteLog"
.line	166	test          r5     0
.line	166	jmp            0  l239
.line	166	gettabup      r5    u0   k73 ; k73 = "string"
.line	166	gettable      r5    r5   k74 ; k74 = "format"
.line	166	gettabup      r6    u0   k14 ; k14 = "table"
.line	166	gettable      r6    r6   k15 ; k15 = "concat"
.line	166	newtable      r7     1     0
.line	166	getupval      r8    u2
.line	166	loadk         r9   k16 ; k16 = 149
.line	166	loadk        r10   k17 ; k17 = 51
.line	166	loadk        r11   k18 ; k18 = 25
.line	166	loadk        r12   k19 ; k19 = 150
.line	166	loadk        r13   k20 ; k20 = 134
.line	166	loadk        r14   k21 ; k21 = 254
.line	166	loadk        r15   k22 ; k22 = 126
.line	166	loadk        r16   k23 ; k23 = 123
.line	166	loadk        r17   k24 ; k24 = 86
.line	166	loadk        r18   k25 ; k25 = 197
.line	166	loadk        r19   k26 ; k26 = 162
.line	166	loadk        r20   k19 ; k19 = 150
.line	166	loadk        r21   k27 ; k27 = 191
.line	166	loadk        r22   k28 ; k28 = 198
.line	166	loadk        r23   k29 ; k29 = 108
.line	166	loadk        r24   k30 ; k30 = 175
.line	166	loadk        r25   k31 ; k31 = 18
.line	166	loadk        r26   k32 ; k32 = 0
.line	166	loadk        r27   k33 ; k33 = 70
.line	166	loadk        r28   k34 ; k34 = 166
.line	166	loadk        r29   k35 ; k35 = 78
.line	166	loadk        r30   k36 ; k36 = 200
.line	166	loadk        r31   k37 ; k37 = 19
.line	166	loadk        r32   k38 ; k38 = 8
.line	166	loadk        r33   k75 ; k75 = 111
.line	166	loadk        r34   k76 ; k76 = 242
.line	166	loadk        r35   k77 ; k77 = 185
.line	166	loadk        r36   k78 ; k78 = 128
.line	166	loadk        r37   k79 ; k79 = 146
.line	166	loadk        r38   k80 ; k80 = 231
.line	166	loadk        r39   k17 ; k17 = 51
.line	166	loadk        r40   k40 ; k40 = 255
.line	166	loadk        r41   k81 ; k81 = 75
.line	166	loadk        r42   k39 ; k39 = 115
.line	166	loadk        r43   k82 ; k82 = 24
.line	166	loadk        r44   k77 ; k77 = 185
.line	166	loadk        r45   k83 ; k83 = 89
.line	166	loadk        r46   k84 ; k84 = 195
.line	166	loadk        r47   k85 ; k85 = 4
.line	166	loadk        r48   k86 ; k86 = 76
.line	166	call          r8    41     2
.line	166	getupval      r9    u2
.line	166	loadk        r10   k87 ; k87 = 148
.line	166	loadk        r11   k88 ; k88 = 30
.line	166	loadk        r12   k70 ; k70 = 54
.line	166	loadk        r13   k89 ; k89 = 184
.line	166	loadk        r14   k90 ; k90 = 237
.line	166	loadk        r15   k91 ; k91 = 180
.line	166	loadk        r16   k92 ; k92 = 100
.line	166	call          r9     8     0
.line	166	setlist       r7     0     1
.line	166	call          r6     2     2
.line	166	gettabup      r7    u0   k93 ; k93 = "tostring"
.line	166	gettable      r8    r0   k72 ; k72 = "LangID"
.line	166	call          r7     2     2
.line	166	gettabup      r8    u0   k93 ; k93 = "tostring"
.line	166	move          r9    r3
.line	166	call          r8     2     0
.line	166	call          r5     0     2
.label	l239
.line	166	call          r4     2     1
.line	166	settable      r0    k1   k94 ; k94 = true
.line	166	self          r4    r0   k95 ; k95 = "InitSecurityBaseInfo"
.line	166	move          r6    r1
.line	166	call          r4     3     1
.line	166	self          r4    r0   k96 ; k96 = "AddCommonEvent"
.line	166	gettabup      r6    u0   k97 ; k97 = "EVENTTYPE_COMPLAINT"
.line	166	gettabup      r7    u0   k98 ; k98 = "EVENTID_SUBMIT_COMPL" (truncated)
.line	166	gettable      r8    r0   k99 ; k99 = "OnPlayerSubmitCompla" (truncated)
.line	166	move          r9    r0
.line	166	call          r4     6     1
.line	166	self          r4    r0   k96 ; k96 = "AddCommonEvent"
.line	166	gettabup      r6    u0  k100 ; k100 = "EVENTTYPE_INGAME"
.line	166	gettabup      r7    u0  k101 ; k101 = "EVENTID_INGAME_MLAI_" (truncated)
.line	166	gettable      r8    r0  k102 ; k102 = "OnMLAIReplyText"
.line	166	move          r9    r0
.line	166	call          r4     6     1
.line	166	self          r4    r0   k96 ; k96 = "AddCommonEvent"
.line	166	gettabup      r6    u0  k100 ; k100 = "EVENTTYPE_INGAME"
.line	166	gettabup      r7    u0  k103 ; k103 = "EVENTID_INGAME_RECEI" (truncated)
.line	166	gettable      r8    r0  k104 ; k104 = "OnReceiveTeamMsg"
.line	166	move          r9    r0
.line	166	call          r4     6     1
.line	166	self          r4    r0  k105 ; k105 = "SendMLAIVoiceDebugIn" (truncated)
.line	166	gettabup      r6    u4  k106 ; k106 = "ClientInitSuccess"
.line	166	getupval      r7    u2
.line	166	loadk         r8  k107 ; k107 = 145
.line	166	loadk         r9  k108 ; k108 = 17
.line	166	loadk        r10  k109 ; k109 = 49
.line	166	loadk        r11   k68 ; k68 = 171
.line	166	call          r7     5     2
.line	166	call          r4     4     1
.line	166	jmp            0  l281
.label	l272
.line	166	self          r1    r0  k105 ; k105 = "SendMLAIVoiceDebugIn" (truncated)
.line	166	gettabup      r3    u4  k110 ; k110 = "VoiceInterFaceError"
.line	166	getupval      r4    u2
.line	166	loadk         r5  k107 ; k107 = 145
.line	166	loadk         r6  k108 ; k108 = 17
.line	166	loadk         r7  k109 ; k109 = 49
.line	166	loadk         r8   k68 ; k68 = 171
.line	166	call          r4     5     2
.line	166	call          r1     4     1
.label	l281
.line	166	return        r0     1
.line	166	move          r0    r0
.line	166	gettabup      r2    u0   k39 ; k39 = 115
.line	166	move          r0    r0
.line	166	move          r0    r0
.line	166	return        r0     1

.function	main/f8

.source	null
.linedefined	199
.lastlinedefined	217
.numparams	2
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	6	true
.upvalue	"U3"	3	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	12
.constant	k23	64
.constant	k24	142
.constant	k25	78
.constant	k26	2
.constant	k27	101
.constant	k28	111
.constant	k29	210
.constant	k30	158
.constant	k31	177
.constant	k32	180
.constant	k33	202
.constant	k34	109
.constant	k35	107
.constant	k36	43
.constant	k37	89
.constant	k38	139
.constant	k39	85
.constant	k40	157
.constant	k41	87
.constant	k42	90
.constant	k43	151
.constant	k44	15
.constant	k45	61
.constant	k46	237
.constant	k47	100
.constant	k48	"tostring"
.constant	k49	"SendMLAIVoiceDebugInfo"
.constant	k50	"DSStateChange"
.constant	k51	"Client"
.constant	k52	"SetDialogTargetUID"
.constant	k53	0
.constant	k54	155
.constant	k55	23
.constant	k56	57
.constant	k57	183
.constant	k58	244
.constant	k59	84
.constant	k60	114
.constant	k61	145
.constant	k62	152
.constant	k63	208
.constant	k64	153
.constant	k65	92
.constant	k66	46
.constant	k67	138
.constant	k68	226
.constant	k69	11
.constant	k70	71
.constant	k71	80
.constant	k72	246
.constant	k73	"bPublicOpinionASRDesired"
.constant	k74	104
.constant	k75	173
.constant	k76	29
.constant	k77	52
.constant	k78	182
.constant	k79	179
.constant	k80	222
.constant	k81	103
.constant	k82	113
.constant	k83	93
.constant	k84	234
.constant	k85	168
.constant	k86	235
.constant	k87	242
.constant	k88	77
.constant	k89	8
.constant	k90	156
.constant	k91	73
.constant	k92	211
.constant	k93	76
.constant	k94	188
.constant	k95	130
.constant	k96	190
.constant	k97	172
.constant	k98	54
.constant	k99	91
.constant	k100	154
.constant	k101	16
.constant	k102	7
.constant	k103	95
.constant	k104	121
.constant	k105	239
.constant	k106	165
.constant	k107	216
.constant	k108	62
.constant	k109	185
.constant	k110	75
.constant	k111	42
.constant	k112	70
.constant	k113	129
.constant	k114	40
.constant	k115	68
.constant	k116	192
.constant	k117	181
.constant	k118	255
.constant	k119	"nRSTSSceneID"
.constant	k120	"Enum_ASRSceneID"
.constant	k121	"PublicOpinion"
.constant	k122	"bOpenMLAIVoice"
.constant	k123	true
.constant	k124	"_TryRestoreSceneLessDialogTarget"
.constant	k125	241
.constant	k126	74
.constant	k127	79
.constant	k128	250
.constant	k129	171
.constant	k130	96
.constant	k131	49
.constant	k132	24
.constant	k133	81
.constant	k134	221
.constant	k135	27
.constant	k136	28
.constant	k137	"ApplyRSTSSceneID"

.line	199	gettabup      r2    u0    k0 ; k0 = "print"
.line	199	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	199	test          r3     0
.line	199	jmp            0   l67
.line	199	gettabup      r3    u0    k2 ; k2 = "string"
.line	199	gettable      r3    r3    k3 ; k3 = "format"
.line	199	gettabup      r4    u0    k4 ; k4 = "table"
.line	199	gettable      r4    r4    k5 ; k5 = "concat"
.line	199	newtable      r5     1     0
.line	199	getupval      r6    u1
.line	199	loadk         r7    k6 ; k6 = 149
.line	199	loadk         r8    k7 ; k7 = 51
.line	199	loadk         r9    k8 ; k8 = 25
.line	199	loadk        r10    k9 ; k9 = 150
.line	199	loadk        r11   k10 ; k10 = 134
.line	199	loadk        r12   k11 ; k11 = 254
.line	199	loadk        r13   k12 ; k12 = 126
.line	199	loadk        r14   k13 ; k13 = 123
.line	199	loadk        r15   k14 ; k14 = 86
.line	199	loadk        r16   k15 ; k15 = 197
.line	199	loadk        r17   k16 ; k16 = 162
.line	199	loadk        r18    k9 ; k9 = 150
.line	199	loadk        r19   k17 ; k17 = 191
.line	199	loadk        r20   k18 ; k18 = 198
.line	199	loadk        r21   k19 ; k19 = 108
.line	199	loadk        r22   k20 ; k20 = 175
.line	199	loadk        r23   k21 ; k21 = 18
.line	199	loadk        r24   k22 ; k22 = 12
.line	199	loadk        r25   k23 ; k23 = 64
.line	199	loadk        r26   k24 ; k24 = 142
.line	199	loadk        r27   k25 ; k25 = 78
.line	199	loadk        r28   k18 ; k18 = 198
.line	199	loadk        r29   k26 ; k26 = 2
.line	199	loadk        r30   k27 ; k27 = 101
.line	199	loadk        r31   k28 ; k28 = 111
.line	199	loadk        r32   k29 ; k29 = 210
.line	199	loadk        r33   k30 ; k30 = 158
.line	199	loadk        r34   k31 ; k31 = 177
.line	199	loadk        r35   k32 ; k32 = 180
.line	199	loadk        r36   k33 ; k33 = 202
.line	199	loadk        r37   k34 ; k34 = 109
.line	199	loadk        r38   k17 ; k17 = 191
.line	199	loadk        r39   k35 ; k35 = 107
.line	199	loadk        r40   k36 ; k36 = 43
.line	199	loadk        r41   k37 ; k37 = 89
.line	199	loadk        r42   k38 ; k38 = 139
.line	199	loadk        r43   k39 ; k39 = 85
.line	199	loadk        r44   k40 ; k40 = 157
.line	199	loadk        r45   k41 ; k41 = 87
.line	199	loadk        r46   k42 ; k42 = 90
.line	199	call          r6    41     2
.line	199	getupval      r7    u1
.line	199	loadk         r8   k43 ; k43 = 151
.line	199	loadk         r9   k44 ; k44 = 15
.line	199	loadk        r10   k45 ; k45 = 61
.line	199	loadk        r11   k31 ; k31 = 177
.line	199	loadk        r12   k46 ; k46 = 237
.line	199	loadk        r13   k32 ; k32 = 180
.line	199	loadk        r14   k47 ; k47 = 100
.line	199	call          r7     8     0
.line	199	setlist       r5     0     1
.line	199	call          r4     2     2
.line	199	gettabup      r5    u0   k48 ; k48 = "tostring"
.line	199	move          r6    r1
.line	199	call          r5     2     0
.line	199	call          r3     0     2
.label	l67
.line	199	call          r2     2     1
.line	199	self          r2    r0   k49 ; k49 = "SendMLAIVoiceDebugIn" (truncated)
.line	199	gettabup      r4    u2   k50 ; k50 = "DSStateChange"
.line	199	gettabup      r5    u0   k48 ; k48 = "tostring"
.line	199	move          r6    r1
.line	199	call          r5     2     0
.line	199	call          r2     0     1
.line	199	gettabup      r2    u0   k51 ; k51 = "Client"
.line	199	test          r2     1
.line	199	jmp            0  l110
.line	199	test          r1     1
.line	199	jmp            0  l110
.line	199	self          r2    r0   k52 ; k52 = "SetDialogTargetUID"
.line	199	loadk         r4   k53 ; k53 = 0
.line	199	getupval      r5    u1
.line	199	loadk         r6   k54 ; k54 = 155
.line	199	loadk         r7   k55 ; k55 = 23
.line	199	loadk         r8   k56 ; k56 = 57
.line	199	loadk         r9   k31 ; k31 = 177
.line	199	loadk        r10   k57 ; k57 = 183
.line	199	loadk        r11   k58 ; k58 = 244
.line	199	loadk        r12   k42 ; k42 = 90
.line	199	loadk        r13   k59 ; k59 = 84
.line	199	loadk        r14   k60 ; k60 = 114
.line	199	loadk        r15   k33 ; k33 = 202
.line	199	loadk        r16   k61 ; k61 = 145
.line	199	loadk        r17   k62 ; k62 = 152
.line	199	loadk        r18   k16 ; k16 = 162
.line	199	loadk        r19   k63 ; k63 = 208
.line	199	loadk        r20   k13 ; k13 = 123
.line	199	loadk        r21   k64 ; k64 = 153
.line	199	loadk        r22   k65 ; k65 = 92
.line	199	loadk        r23   k66 ; k66 = 46
.line	199	loadk        r24   k65 ; k65 = 92
.line	199	loadk        r25   k67 ; k67 = 138
.line	199	loadk        r26   k53 ; k53 = 0
.line	199	loadk        r27   k68 ; k68 = 226
.line	199	loadk        r28   k69 ; k69 = 11
.line	199	loadk        r29   k70 ; k70 = 71
.line	199	loadk        r30   k71 ; k71 = 80
.line	199	loadk        r31   k72 ; k72 = 246
.line	199	call          r5    27     2
.line	199	call          r2     4     1
.label	l110
.line	199	gettabup      r2    u0   k51 ; k51 = "Client"
.line	199	test          r2     1
.line	199	jmp            0  l312
.line	199	test          r1     1
.line	199	jmp            0  l312
.line	199	gettable      r2    r0   k73 ; k73 = "bPublicOpinionASRDes" (truncated)
.line	199	test          r2     0
.line	199	jmp            0  l312
.line	199	gettabup      r2    u0    k0 ; k0 = "print"
.line	199	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	199	test          r3     0
.line	199	jmp            0  l252
.line	199	gettabup      r3    u0    k2 ; k2 = "string"
.line	199	gettable      r3    r3    k3 ; k3 = "format"
.line	199	gettabup      r4    u0    k4 ; k4 = "table"
.line	199	gettable      r4    r4    k5 ; k5 = "concat"
.line	199	newtable      r5     2     0
.line	199	getupval      r6    u1
.line	199	loadk         r7    k6 ; k6 = 149
.line	199	loadk         r8    k7 ; k7 = 51
.line	199	loadk         r9    k8 ; k8 = 25
.line	199	loadk        r10    k9 ; k9 = 150
.line	199	loadk        r11   k10 ; k10 = 134
.line	199	loadk        r12   k11 ; k11 = 254
.line	199	loadk        r13   k12 ; k12 = 126
.line	199	loadk        r14   k13 ; k13 = 123
.line	199	loadk        r15   k14 ; k14 = 86
.line	199	loadk        r16   k15 ; k15 = 197
.line	199	loadk        r17   k16 ; k16 = 162
.line	199	loadk        r18    k9 ; k9 = 150
.line	199	loadk        r19   k17 ; k17 = 191
.line	199	loadk        r20   k18 ; k18 = 198
.line	199	loadk        r21   k19 ; k19 = 108
.line	199	loadk        r22   k20 ; k20 = 175
.line	199	loadk        r23   k21 ; k21 = 18
.line	199	loadk        r24   k22 ; k22 = 12
.line	199	loadk        r25   k23 ; k23 = 64
.line	199	loadk        r26   k24 ; k24 = 142
.line	199	loadk        r27   k25 ; k25 = 78
.line	199	loadk        r28   k18 ; k18 = 198
.line	199	loadk        r29   k26 ; k26 = 2
.line	199	loadk        r30   k27 ; k27 = 101
.line	199	loadk        r31   k28 ; k28 = 111
.line	199	loadk        r32   k29 ; k29 = 210
.line	199	loadk        r33   k30 ; k30 = 158
.line	199	loadk        r34   k31 ; k31 = 177
.line	199	loadk        r35   k32 ; k32 = 180
.line	199	loadk        r36   k33 ; k33 = 202
.line	199	loadk        r37   k34 ; k34 = 109
.line	199	loadk        r38   k17 ; k17 = 191
.line	199	loadk        r39   k35 ; k35 = 107
.line	199	loadk        r40   k36 ; k36 = 43
.line	199	loadk        r41   k37 ; k37 = 89
.line	199	loadk        r42   k38 ; k38 = 139
.line	199	loadk        r43   k39 ; k39 = 85
.line	199	loadk        r44   k40 ; k40 = 157
.line	199	loadk        r45   k41 ; k41 = 87
.line	199	loadk        r46   k74 ; k74 = 104
.line	199	call          r6    41     2
.line	199	getupval      r7    u1
.line	199	loadk         r8   k75 ; k75 = 173
.line	199	loadk         r9   k76 ; k76 = 29
.line	199	loadk        r10   k77 ; k77 = 52
.line	199	loadk        r11   k78 ; k78 = 182
.line	199	loadk        r12   k79 ; k79 = 179
.line	199	loadk        r13   k80 ; k80 = 222
.line	199	loadk        r14   k81 ; k81 = 103
.line	199	loadk        r15   k82 ; k82 = 113
.line	199	loadk        r16   k83 ; k83 = 93
.line	199	loadk        r17   k84 ; k84 = 234
.line	199	loadk        r18   k85 ; k85 = 168
.line	199	loadk        r19   k64 ; k64 = 153
.line	199	loadk        r20   k86 ; k86 = 235
.line	199	loadk        r21   k87 ; k87 = 242
.line	199	loadk        r22   k88 ; k88 = 77
.line	199	loadk        r23   k62 ; k62 = 152
.line	199	loadk        r24   k89 ; k89 = 8
.line	199	loadk        r25   k36 ; k36 = 43
.line	199	loadk        r26   k88 ; k88 = 77
.line	199	loadk        r27   k90 ; k90 = 156
.line	199	loadk        r28   k91 ; k91 = 73
.line	199	loadk        r29   k92 ; k92 = 211
.line	199	loadk        r30   k26 ; k26 = 2
.line	199	loadk        r31   k93 ; k93 = 76
.line	199	loadk        r32   k44 ; k44 = 15
.line	199	loadk        r33   k79 ; k79 = 179
.line	199	loadk        r34   k94 ; k94 = 188
.line	199	loadk        r35   k95 ; k95 = 130
.line	199	loadk        r36   k96 ; k96 = 190
.line	199	loadk        r37   k92 ; k92 = 211
.line	199	loadk        r38   k66 ; k66 = 46
.line	199	loadk        r39   k97 ; k97 = 172
.line	199	loadk        r40   k41 ; k41 = 87
.line	199	loadk        r41   k98 ; k98 = 54
.line	199	loadk        r42   k99 ; k99 = 91
.line	199	loadk        r43  k100 ; k100 = 154
.line	199	loadk        r44  k101 ; k101 = 16
.line	199	loadk        r45   k80 ; k80 = 222
.line	199	loadk        r46  k102 ; k102 = 7
.line	199	loadk        r47   k83 ; k83 = 93
.line	199	call          r7    41     2
.line	199	getupval      r8    u1
.line	199	loadk         r9   k78 ; k78 = 182
.line	199	loadk        r10  k103 ; k103 = 95
.line	199	loadk        r11   k56 ; k56 = 57
.line	199	loadk        r12   k31 ; k31 = 177
.line	199	loadk        r13   k32 ; k32 = 180
.line	199	loadk        r14   k31 ; k31 = 177
.line	199	loadk        r15   k82 ; k82 = 113
.line	199	loadk        r16  k104 ; k104 = 121
.line	199	loadk        r17  k103 ; k103 = 95
.line	199	loadk        r18  k105 ; k105 = 239
.line	199	loadk        r19  k106 ; k106 = 165
.line	199	loadk        r20    k9 ; k9 = 150
.line	199	loadk        r21   k85 ; k85 = 168
.line	199	loadk        r22  k107 ; k107 = 216
.line	199	loadk        r23  k108 ; k108 = 62
.line	199	loadk        r24  k109 ; k109 = 185
.line	199	loadk        r25  k110 ; k110 = 75
.line	199	loadk        r26  k111 ; k111 = 42
.line	199	loadk        r27  k112 ; k112 = 70
.line	199	loadk        r28   k67 ; k67 = 138
.line	199	loadk        r29   k22 ; k22 = 12
.line	199	loadk        r30  k113 ; k113 = 129
.line	199	loadk        r31  k114 ; k114 = 40
.line	199	loadk        r32  k115 ; k115 = 68
.line	199	loadk        r33   k70 ; k70 = 71
.line	199	loadk        r34  k116 ; k116 = 192
.line	199	loadk        r35   k32 ; k32 = 180
.line	199	loadk        r36   k95 ; k95 = 130
.line	199	loadk        r37  k117 ; k117 = 181
.line	199	loadk        r38   k18 ; k18 = 198
.line	199	loadk        r39   k77 ; k77 = 52
.line	199	loadk        r40  k118 ; k118 = 255
.line	199	loadk        r41  k110 ; k110 = 75
.line	199	call          r8    34     0
.line	199	setlist       r5     0     1
.line	199	call          r4     2     2
.line	199	gettabup      r5    u0   k48 ; k48 = "tostring"
.line	199	gettable      r6    r0  k119 ; k119 = "nRSTSSceneID"
.line	199	call          r5     2     0
.line	199	call          r3     0     2
.label	l252
.line	199	call          r2     2     1
.line	199	gettabup      r2    u3  k120 ; k120 = "Enum_ASRSceneID"
.line	199	gettable      r2    r2  k121 ; k121 = "PublicOpinion"
.line	199	settable      r0  k119    r2 ; k119 = "nRSTSSceneID"
.line	199	settable      r0  k122  k123 ; k123 = true
.line	199	self          r2    r0  k124 ; k124 = "_TryRestoreSceneLess" (truncated)
.line	199	gettabup      r4    u0    k4 ; k4 = "table"
.line	199	gettable      r4    r4    k5 ; k5 = "concat"
.line	199	newtable      r5     1     0
.line	199	getupval      r6    u1
.line	199	loadk         r7   k54 ; k54 = 155
.line	199	loadk         r8   k55 ; k55 = 23
.line	199	loadk         r9   k56 ; k56 = 57
.line	199	loadk        r10   k31 ; k31 = 177
.line	199	loadk        r11   k57 ; k57 = 183
.line	199	loadk        r12   k58 ; k58 = 244
.line	199	loadk        r13   k42 ; k42 = 90
.line	199	loadk        r14   k59 ; k59 = 84
.line	199	loadk        r15   k60 ; k60 = 114
.line	199	loadk        r16   k33 ; k33 = 202
.line	199	loadk        r17   k61 ; k61 = 145
.line	199	loadk        r18   k62 ; k62 = 152
.line	199	loadk        r19   k16 ; k16 = 162
.line	199	loadk        r20   k63 ; k63 = 208
.line	199	loadk        r21   k13 ; k13 = 123
.line	199	loadk        r22   k64 ; k64 = 153
.line	199	loadk        r23   k65 ; k65 = 92
.line	199	loadk        r24   k66 ; k66 = 46
.line	199	loadk        r25   k65 ; k65 = 92
.line	199	loadk        r26   k67 ; k67 = 138
.line	199	loadk        r27   k53 ; k53 = 0
.line	199	loadk        r28  k125 ; k125 = 241
.line	199	loadk        r29   k21 ; k21 = 18
.line	199	loadk        r30  k126 ; k126 = 74
.line	199	loadk        r31  k127 ; k127 = 79
.line	199	loadk        r32  k128 ; k128 = 250
.line	199	loadk        r33   k32 ; k32 = 180
.line	199	loadk        r34   k85 ; k85 = 168
.line	199	loadk        r35  k129 ; k129 = 171
.line	199	loadk        r36   k33 ; k33 = 202
.line	199	loadk        r37  k130 ; k130 = 96
.line	199	loadk        r38   k79 ; k79 = 179
.line	199	loadk        r39   k41 ; k41 = 87
.line	199	loadk        r40  k131 ; k131 = 49
.line	199	loadk        r41  k132 ; k132 = 24
.line	199	loadk        r42  k109 ; k109 = 185
.line	199	loadk        r43  k133 ; k133 = 81
.line	199	loadk        r44  k134 ; k134 = 221
.line	199	loadk        r45  k135 ; k135 = 27
.line	199	loadk        r46   k42 ; k42 = 90
.line	199	call          r6    41     2
.line	199	getupval      r7    u1
.line	199	loadk         r8  k109 ; k109 = 185
.line	199	loadk         r9  k136 ; k136 = 28
.line	199	loadk        r10    k7 ; k7 = 51
.line	199	call          r7     4     0
.line	199	setlist       r5     0     1
.line	199	call          r4     2     2
.line	199	call          r2     3     1
.line	199	return        r0     1
.label	l312
.line	199	settable      r0  k122    r1 ; k122 = "bOpenMLAIVoice"
.line	199	gettabup      r2    u0   k51 ; k51 = "Client"
.line	199	test          r2     1
.line	199	jmp            0  l355
.line	199	test          r1     1
.line	199	jmp            0  l355
.line	199	gettable      r2    r0  k119 ; k119 = "nRSTSSceneID"
.line	199	test          r2     1
.line	199	jmp            0  l322
.line	199	loadk         r2   k53 ; k53 = 0
.label	l322
.line	199	lt             0   k53    r2 ; k53 = 0
.line	199	jmp            0  l355
.line	199	self          r2    r0  k137 ; k137 = "ApplyRSTSSceneID"
.line	199	loadk         r4   k53 ; k53 = 0
.line	199	getupval      r5    u1
.line	199	loadk         r6   k54 ; k54 = 155
.line	199	loadk         r7   k55 ; k55 = 23
.line	199	loadk         r8   k56 ; k56 = 57
.line	199	loadk         r9   k31 ; k31 = 177
.line	199	loadk        r10   k57 ; k57 = 183
.line	199	loadk        r11   k58 ; k58 = 244
.line	199	loadk        r12   k42 ; k42 = 90
.line	199	loadk        r13   k59 ; k59 = 84
.line	199	loadk        r14   k60 ; k60 = 114
.line	199	loadk        r15   k33 ; k33 = 202
.line	199	loadk        r16   k61 ; k61 = 145
.line	199	loadk        r17   k62 ; k62 = 152
.line	199	loadk        r18   k16 ; k16 = 162
.line	199	loadk        r19   k63 ; k63 = 208
.line	199	loadk        r20   k13 ; k13 = 123
.line	199	loadk        r21   k64 ; k64 = 153
.line	199	loadk        r22   k65 ; k65 = 92
.line	199	loadk        r23   k66 ; k66 = 46
.line	199	loadk        r24   k65 ; k65 = 92
.line	199	loadk        r25   k67 ; k67 = 138
.line	199	loadk        r26   k53 ; k53 = 0
.line	199	loadk        r27   k68 ; k68 = 226
.line	199	loadk        r28   k69 ; k69 = 11
.line	199	loadk        r29   k70 ; k70 = 71
.line	199	loadk        r30   k71 ; k71 = 80
.line	199	loadk        r31   k72 ; k72 = 246
.line	199	call          r5    27     2
.line	199	call          r2     4     1
.label	l355
.line	199	return        r0     1
.line	199	return        r0     1
.line	199	move          r0    r0
.line	199	return        r0     1

.function	main/f9

.source	null
.linedefined	219
.lastlinedefined	232
.numparams	3
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"tonumber"
.constant	k2	0
.constant	k3	"DialogTargetUID"
.constant	k4	"print"
.constant	k5	"bWriteLog"
.constant	k6	"string"
.constant	k7	"format"
.constant	k8	"table"
.constant	k9	"concat"
.constant	k10	149
.constant	k11	51
.constant	k12	25
.constant	k13	150
.constant	k14	134
.constant	k15	254
.constant	k16	126
.constant	k17	123
.constant	k18	86
.constant	k19	197
.constant	k20	162
.constant	k21	191
.constant	k22	198
.constant	k23	108
.constant	k24	175
.constant	k25	18
.constant	k26	28
.constant	k27	77
.constant	k28	155
.constant	k29	100
.constant	k30	200
.constant	k31	6
.constant	k32	68
.constant	k33	76
.constant	k34	244
.constant	k35	131
.constant	k36	169
.constant	k37	196
.constant	k38	107
.constant	k39	174
.constant	k40	109
.constant	k41	22
.constant	k42	124
.constant	k43	211
.constant	k44	16
.constant	k45	148
.constant	k46	4
.constant	k47	24
.constant	k48	245
.constant	k49	65
.constant	k50	120
.constant	k51	250
.constant	k52	163
.constant	k53	189
.constant	k54	55
.constant	k55	93
.constant	k56	75
.constant	k57	247
.constant	k58	181
.constant	k59	241
.constant	k60	"tostring"
.constant	k61	"_TryRestoreSceneLessDialogTarget"

.line	219	gettabup      r3    u0    k0 ; k0 = "Client"
.line	219	test          r3     0
.line	219	jmp            0    l5
.line	219	return        r0     1
.label	l5
.line	219	gettabup      r3    u0    k1 ; k1 = "tonumber"
.line	219	move          r4    r1
.line	219	call          r3     2     2
.line	219	testset       r1    r3     1
.line	219	jmp            0   l11
.line	219	loadk         r1    k2 ; k2 = 0
.label	l11
.line	219	gettable      r3    r0    k3 ; k3 = "DialogTargetUID"
.line	219	eq             0    r3    r1
.line	219	jmp            0   l15
.line	219	return        r0     1
.label	l15
.line	219	gettabup      r3    u0    k4 ; k4 = "print"
.line	219	gettabup      r4    u0    k5 ; k5 = "bWriteLog"
.line	219	test          r4     0
.line	219	jmp            0   l95
.line	219	gettabup      r4    u0    k6 ; k6 = "string"
.line	219	gettable      r4    r4    k7 ; k7 = "format"
.line	219	gettabup      r5    u0    k8 ; k8 = "table"
.line	219	gettable      r5    r5    k9 ; k9 = "concat"
.line	219	newtable      r6     1     0
.line	219	getupval      r7    u1
.line	219	loadk         r8   k10 ; k10 = 149
.line	219	loadk         r9   k11 ; k11 = 51
.line	219	loadk        r10   k12 ; k12 = 25
.line	219	loadk        r11   k13 ; k13 = 150
.line	219	loadk        r12   k14 ; k14 = 134
.line	219	loadk        r13   k15 ; k15 = 254
.line	219	loadk        r14   k16 ; k16 = 126
.line	219	loadk        r15   k17 ; k17 = 123
.line	219	loadk        r16   k18 ; k18 = 86
.line	219	loadk        r17   k19 ; k19 = 197
.line	219	loadk        r18   k20 ; k20 = 162
.line	219	loadk        r19   k13 ; k13 = 150
.line	219	loadk        r20   k21 ; k21 = 191
.line	219	loadk        r21   k22 ; k22 = 198
.line	219	loadk        r22   k23 ; k23 = 108
.line	219	loadk        r23   k24 ; k24 = 175
.line	219	loadk        r24   k25 ; k25 = 18
.line	219	loadk        r25   k26 ; k26 = 28
.line	219	loadk        r26   k27 ; k27 = 77
.line	219	loadk        r27   k28 ; k28 = 155
.line	219	loadk        r28   k29 ; k29 = 100
.line	219	loadk        r29   k30 ; k30 = 200
.line	219	loadk        r30   k31 ; k31 = 6
.line	219	loadk        r31   k32 ; k32 = 68
.line	219	loadk        r32   k33 ; k33 = 76
.line	219	loadk        r33   k34 ; k34 = 244
.line	219	loadk        r34   k35 ; k35 = 131
.line	219	loadk        r35   k14 ; k14 = 134
.line	219	loadk        r36   k36 ; k36 = 169
.line	219	loadk        r37   k37 ; k37 = 196
.line	219	loadk        r38   k38 ; k38 = 107
.line	219	loadk        r39   k39 ; k39 = 174
.line	219	loadk        r40   k40 ; k40 = 109
.line	219	loadk        r41   k41 ; k41 = 22
.line	219	loadk        r42   k42 ; k42 = 124
.line	219	loadk        r43   k43 ; k43 = 211
.line	219	loadk        r44   k44 ; k44 = 16
.line	219	loadk        r45   k45 ; k45 = 148
.line	219	loadk        r46   k46 ; k46 = 4
.line	219	loadk        r47   k47 ; k47 = 24
.line	219	call          r7    41     2
.line	219	getupval      r8    u1
.line	219	loadk         r9   k48 ; k48 = 245
.line	219	loadk        r10   k49 ; k49 = 65
.line	219	loadk        r11   k50 ; k50 = 120
.line	219	loadk        r12   k51 ; k51 = 250
.line	219	loadk        r13   k52 ; k52 = 163
.line	219	loadk        r14   k53 ; k53 = 189
.line	219	loadk        r15   k54 ; k54 = 55
.line	219	loadk        r16   k55 ; k55 = 93
.line	219	loadk        r17   k56 ; k56 = 75
.line	219	loadk        r18   k57 ; k57 = 247
.line	219	loadk        r19   k58 ; k58 = 181
.line	219	loadk        r20   k13 ; k13 = 150
.line	219	loadk        r21   k59 ; k59 = 241
.line	219	loadk        r22   k13 ; k13 = 150
.line	219	loadk        r23   k40 ; k40 = 109
.line	219	call          r8    16     0
.line	219	setlist       r6     0     1
.line	219	call          r5     2     2
.line	219	gettabup      r6    u0   k60 ; k60 = "tostring"
.line	219	gettable      r7    r0    k3 ; k3 = "DialogTargetUID"
.line	219	call          r6     2     2
.line	219	gettabup      r7    u0   k60 ; k60 = "tostring"
.line	219	move          r8    r1
.line	219	call          r7     2     2
.line	219	gettabup      r8    u0   k60 ; k60 = "tostring"
.line	219	move          r9    r2
.line	219	call          r8     2     0
.line	219	call          r4     0     2
.label	l95
.line	219	call          r3     2     1
.line	219	settable      r0    k3    r1 ; k3 = "DialogTargetUID"
.line	219	eq             0    r1    k2 ; k2 = 0
.line	219	jmp            0  l102
.line	219	self          r3    r0   k61 ; k61 = "_TryRestoreSceneLess" (truncated)
.line	219	move          r5    r2
.line	219	call          r3     3     1
.label	l102
.line	219	return        r0     1
.line	219	move          r0    r0
.line	219	move          r0    r0
.line	219	return        r0     1

.function	main/f10

.source	null
.linedefined	234
.lastlinedefined	248
.numparams	3
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"tonumber"
.constant	k2	0
.constant	k3	"SceneLessDialogTargetUID"
.constant	k4	"HasFeatureRSTSScene"
.constant	k5	"print"
.constant	k6	"bWriteLog"
.constant	k7	"string"
.constant	k8	"format"
.constant	k9	"table"
.constant	k10	"concat"
.constant	k11	149
.constant	k12	51
.constant	k13	25
.constant	k14	150
.constant	k15	134
.constant	k16	254
.constant	k17	126
.constant	k18	123
.constant	k19	86
.constant	k20	197
.constant	k21	162
.constant	k22	191
.constant	k23	198
.constant	k24	108
.constant	k25	175
.constant	k26	18
.constant	k27	29
.constant	k28	77
.constant	k29	158
.constant	k30	85
.constant	k31	196
.constant	k32	20
.constant	k33	92
.constant	k34	112
.constant	k35	240
.constant	k36	178
.constant	k37	137
.constant	k38	190
.constant	k39	239
.constant	k40	107
.constant	k41	169
.constant	k42	75
.constant	k43	27
.constant	k44	81
.constant	k45	222
.constant	k46	16
.constant	k47	185
.constant	k48	13
.constant	k49	63
.constant	k50	186
.constant	k51	164
.constant	k52	177
.constant	k53	103
.constant	k54	125
.constant	k55	93
.constant	k56	231
.constant	k57	174
.constant	k58	153
.constant	k59	172
.constant	k60	159
.constant	k61	62
.constant	k62	46
.constant	k63	154
.constant	k64	82
.constant	k65	71
.constant	k66	91
.constant	k67	64
.constant	k68	246
.constant	k69	130
.constant	k70	251
.constant	k71	194
.constant	k72	109
.constant	k73	41
.constant	k74	211
.constant	k75	226
.constant	k76	182
.constant	k77	26
.constant	k78	17
.constant	k79	155
.constant	k80	237
.constant	k81	180
.constant	k82	100
.constant	k83	52
.constant	k84	19
.constant	k85	142
.constant	k86	247
.constant	k87	35
.constant	k88	99
.constant	k89	8
.constant	k90	170
.constant	k91	88
.constant	k92	213
.constant	k93	21
.constant	k94	73
.constant	k95	"tostring"
.constant	k96	"nRSTSSceneID"
.constant	k97	"SetDialogTargetUID"

.line	234	gettabup      r3    u0    k0 ; k0 = "Client"
.line	234	test          r3     0
.line	234	jmp            0    l5
.line	234	return        r0     1
.label	l5
.line	234	gettabup      r3    u0    k1 ; k1 = "tonumber"
.line	234	move          r4    r1
.line	234	call          r3     2     2
.line	234	testset       r1    r3     1
.line	234	jmp            0   l11
.line	234	loadk         r1    k2 ; k2 = 0
.label	l11
.line	234	le             0    r1    k2 ; k2 = 0
.line	234	jmp            0   l14
.line	234	return        r0     1
.label	l14
.line	234	settable      r0    k3    r1 ; k3 = "SceneLessDialogTarge" (truncated)
.line	234	self          r3    r0    k4 ; k4 = "HasFeatureRSTSScene"
.line	234	call          r3     2     2
.line	234	test          r3     0
.line	234	jmp            0  l155
.line	234	gettabup      r3    u0    k5 ; k5 = "print"
.line	234	gettabup      r4    u0    k6 ; k6 = "bWriteLog"
.line	234	test          r4     0
.line	234	jmp            0  l153
.line	234	gettabup      r4    u0    k7 ; k7 = "string"
.line	234	gettable      r4    r4    k8 ; k8 = "format"
.line	234	gettabup      r5    u0    k9 ; k9 = "table"
.line	234	gettable      r5    r5   k10 ; k10 = "concat"
.line	234	newtable      r6     2     0
.line	234	getupval      r7    u1
.line	234	loadk         r8   k11 ; k11 = 149
.line	234	loadk         r9   k12 ; k12 = 51
.line	234	loadk        r10   k13 ; k13 = 25
.line	234	loadk        r11   k14 ; k14 = 150
.line	234	loadk        r12   k15 ; k15 = 134
.line	234	loadk        r13   k16 ; k16 = 254
.line	234	loadk        r14   k17 ; k17 = 126
.line	234	loadk        r15   k18 ; k18 = 123
.line	234	loadk        r16   k19 ; k19 = 86
.line	234	loadk        r17   k20 ; k20 = 197
.line	234	loadk        r18   k21 ; k21 = 162
.line	234	loadk        r19   k14 ; k14 = 150
.line	234	loadk        r20   k22 ; k22 = 191
.line	234	loadk        r21   k23 ; k23 = 198
.line	234	loadk        r22   k24 ; k24 = 108
.line	234	loadk        r23   k25 ; k25 = 175
.line	234	loadk        r24   k26 ; k26 = 18
.line	234	loadk        r25   k27 ; k27 = 29
.line	234	loadk        r26   k28 ; k28 = 77
.line	234	loadk        r27   k29 ; k29 = 158
.line	234	loadk        r28   k30 ; k30 = 85
.line	234	loadk        r29   k31 ; k31 = 196
.line	234	loadk        r30   k32 ; k32 = 20
.line	234	loadk        r31   k33 ; k33 = 92
.line	234	loadk        r32   k34 ; k34 = 112
.line	234	loadk        r33   k35 ; k35 = 240
.line	234	loadk        r34   k36 ; k36 = 178
.line	234	loadk        r35   k37 ; k37 = 137
.line	234	loadk        r36   k38 ; k38 = 190
.line	234	loadk        r37   k39 ; k39 = 239
.line	234	loadk        r38   k40 ; k40 = 107
.line	234	loadk        r39   k41 ; k41 = 169
.line	234	loadk        r40   k42 ; k42 = 75
.line	234	loadk        r41   k43 ; k43 = 27
.line	234	loadk        r42   k44 ; k44 = 81
.line	234	loadk        r43   k29 ; k29 = 158
.line	234	loadk        r44   k33 ; k33 = 92
.line	234	loadk        r45   k45 ; k45 = 222
.line	234	loadk        r46   k46 ; k46 = 16
.line	234	loadk        r47   k24 ; k24 = 108
.line	234	call          r7    41     2
.line	234	getupval      r8    u1
.line	234	loadk         r9   k47 ; k47 = 185
.line	234	loadk        r10   k48 ; k48 = 13
.line	234	loadk        r11   k49 ; k49 = 63
.line	234	loadk        r12   k50 ; k50 = 186
.line	234	loadk        r13   k51 ; k51 = 164
.line	234	loadk        r14   k52 ; k52 = 177
.line	234	loadk        r15   k53 ; k53 = 103
.line	234	loadk        r16   k54 ; k54 = 125
.line	234	loadk        r17   k55 ; k55 = 93
.line	234	loadk        r18   k56 ; k56 = 231
.line	234	loadk        r19   k57 ; k57 = 174
.line	234	loadk        r20   k58 ; k58 = 153
.line	234	loadk        r21   k59 ; k59 = 172
.line	234	loadk        r22   k60 ; k60 = 159
.line	234	loadk        r23   k61 ; k61 = 62
.line	234	loadk        r24   k59 ; k59 = 172
.line	234	loadk        r25   k28 ; k28 = 77
.line	234	loadk        r26   k62 ; k62 = 46
.line	234	loadk        r27   k33 ; k33 = 92
.line	234	loadk        r28   k63 ; k63 = 154
.line	234	loadk        r29   k64 ; k64 = 82
.line	234	loadk        r30   k31 ; k31 = 196
.line	234	loadk        r31   k65 ; k65 = 71
.line	234	loadk        r32   k66 ; k66 = 91
.line	234	loadk        r33   k67 ; k67 = 64
.line	234	loadk        r34   k68 ; k68 = 246
.line	234	loadk        r35   k47 ; k47 = 185
.line	234	loadk        r36   k69 ; k69 = 130
.line	234	loadk        r37   k70 ; k70 = 251
.line	234	loadk        r38   k71 ; k71 = 194
.line	234	loadk        r39   k72 ; k72 = 109
.line	234	loadk        r40   k57 ; k57 = 174
.line	234	loadk        r41   k44 ; k44 = 81
.line	234	loadk        r42   k73 ; k73 = 41
.line	234	loadk        r43   k55 ; k55 = 93
.line	234	loadk        r44   k74 ; k74 = 211
.line	234	loadk        r45   k46 ; k46 = 16
.line	234	loadk        r46   k75 ; k75 = 226
.line	234	loadk        r47   k32 ; k32 = 20
.line	234	loadk        r48   k55 ; k55 = 93
.line	234	call          r8    41     2
.line	234	getupval      r9    u1
.line	234	loadk        r10   k76 ; k76 = 182
.line	234	loadk        r11   k77 ; k77 = 26
.line	234	loadk        r12   k78 ; k78 = 17
.line	234	loadk        r13   k79 ; k79 = 155
.line	234	loadk        r14   k80 ; k80 = 237
.line	234	loadk        r15   k81 ; k81 = 180
.line	234	loadk        r16   k82 ; k82 = 100
.line	234	loadk        r17   k83 ; k83 = 52
.line	234	loadk        r18   k84 ; k84 = 19
.line	234	loadk        r19   k71 ; k71 = 194
.line	234	loadk        r20   k85 ; k85 = 142
.line	234	loadk        r21   k21 ; k21 = 162
.line	234	loadk        r22   k69 ; k69 = 130
.line	234	loadk        r23   k86 ; k86 = 247
.line	234	loadk        r24   k87 ; k87 = 35
.line	234	loadk        r25   k39 ; k39 = 239
.line	234	loadk        r26   k66 ; k66 = 91
.line	234	loadk        r27   k88 ; k88 = 99
.line	234	loadk        r28   k89 ; k89 = 8
.line	234	loadk        r29   k90 ; k90 = 170
.line	234	loadk        r30   k91 ; k91 = 88
.line	234	loadk        r31   k92 ; k92 = 213
.line	234	loadk        r32   k93 ; k93 = 21
.line	234	loadk        r33   k94 ; k94 = 73
.line	234	loadk        r34   k13 ; k13 = 25
.line	234	loadk        r35   k76 ; k76 = 182
.line	234	loadk        r36   k51 ; k51 = 164
.line	234	call          r9    28     0
.line	234	setlist       r6     0     1
.line	234	call          r5     2     2
.line	234	gettabup      r6    u0   k95 ; k95 = "tostring"
.line	234	gettable      r7    r0   k96 ; k96 = "nRSTSSceneID"
.line	234	call          r6     2     2
.line	234	gettabup      r7    u0   k95 ; k95 = "tostring"
.line	234	move          r8    r1
.line	234	call          r7     2     2
.line	234	gettabup      r8    u0   k95 ; k95 = "tostring"
.line	234	move          r9    r2
.line	234	call          r8     2     0
.line	234	call          r4     0     2
.label	l153
.line	234	call          r3     2     1
.line	234	return        r0     1
.label	l155
.line	234	self          r3    r0   k97 ; k97 = "SetDialogTargetUID"
.line	234	move          r5    r1
.line	234	move          r6    r2
.line	234	call          r3     4     1
.line	234	return        r0     1
.line	234	move          r0    r0
.line	234	move          r0    r0
.line	234	return        r0     1

.function	main/f11

.source	null
.linedefined	250
.lastlinedefined	264
.numparams	3
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	0	false

.constant	k0	"Client"
.constant	k1	"tonumber"
.constant	k2	0
.constant	k3	"SceneLessDialogTargetUID"
.constant	k4	"DialogTargetUID"
.constant	k5	"SetDialogTargetUID"

.line	250	gettabup      r3    u0    k0 ; k0 = "Client"
.line	250	test          r3     0
.line	250	jmp            0    l5
.line	250	return        r0     1
.label	l5
.line	250	gettabup      r3    u0    k1 ; k1 = "tonumber"
.line	250	move          r4    r1
.line	250	call          r3     2     2
.line	250	testset       r1    r3     1
.line	250	jmp            0   l11
.line	250	loadk         r1    k2 ; k2 = 0
.label	l11
.line	250	le             0    r1    k2 ; k2 = 0
.line	250	jmp            0   l14
.line	250	return        r0     1
.label	l14
.line	250	gettable      r3    r0    k3 ; k3 = "SceneLessDialogTarge" (truncated)
.line	250	eq             0    r3    r1
.line	250	jmp            0   l18
.line	250	settable      r0    k3    k2 ; k2 = 0
.label	l18
.line	250	gettabup      r3    u0    k1 ; k1 = "tonumber"
.line	250	gettable      r4    r0    k4 ; k4 = "DialogTargetUID"
.line	250	call          r3     2     2
.line	250	test          r3     1
.line	250	jmp            0   l24
.line	250	loadk         r3    k2 ; k2 = 0
.label	l24
.line	250	eq             0    r3    r1
.line	250	jmp            0   l30
.line	250	self          r3    r0    k5 ; k5 = "SetDialogTargetUID"
.line	250	loadk         r5    k2 ; k2 = 0
.line	250	move          r6    r2
.line	250	call          r3     4     1
.label	l30
.line	250	return        r0     1
.line	250	move          r0    r0
.line	250	move          r0    r0
.line	250	return        r0     1

.function	main/f12

.source	null
.linedefined	266
.lastlinedefined	276
.numparams	2
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"tonumber"
.constant	k2	"SceneLessDialogTargetUID"
.constant	k3	0
.constant	k4	"DialogTargetUID"
.constant	k5	"HasFeatureRSTSScene"
.constant	k6	"print"
.constant	k7	"bWriteLog"
.constant	k8	"string"
.constant	k9	"format"
.constant	k10	"table"
.constant	k11	"concat"
.constant	k12	149
.constant	k13	51
.constant	k14	25
.constant	k15	150
.constant	k16	134
.constant	k17	254
.constant	k18	126
.constant	k19	123
.constant	k20	86
.constant	k21	197
.constant	k22	162
.constant	k23	191
.constant	k24	198
.constant	k25	108
.constant	k26	175
.constant	k27	18
.constant	k28	16
.constant	k29	124
.constant	k30	157
.constant	k31	89
.constant	k32	243
.constant	k33	2
.constant	k34	91
.constant	k35	87
.constant	k36	252
.constant	k37	165
.constant	k38	130
.constant	k39	136
.constant	k40	192
.constant	k41	107
.constant	k42	180
.constant	k43	93
.constant	k44	19
.constant	k45	140
.constant	k46	67
.constant	k47	245
.constant	k48	30
.constant	k49	63
.constant	k50	139
.constant	k51	177
.constant	k52	227
.constant	k53	112
.constant	k54	125
.constant	k55	71
.constant	k56	163
.constant	k57	181
.constant	k58	146
.constant	k59	184
.constant	k60	199
.constant	k61	113
.constant	k62	77
.constant	k63	111
.constant	k64	105
.constant	k65	166
.constant	k66	117
.constant	k67	232
.constant	k68	35
.constant	k69	21
.constant	k70	6
.constant	k71	224
.constant	k72	251
.constant	k73	158
.constant	k74	219
.constant	k75	122
.constant	k76	168
.constant	k77	101
.constant	k78	29
.constant	k79	"tostring"
.constant	k80	"SetDialogTargetUID"
.constant	k81	28
.constant	k82	61
.constant	k83	221
.constant	k84	114
.constant	k85	64

.line	266	gettabup      r2    u0    k0 ; k0 = "Client"
.line	266	test          r2     0
.line	266	jmp            0    l5
.line	266	return        r0     1
.label	l5
.line	266	gettabup      r2    u0    k1 ; k1 = "tonumber"
.line	266	gettable      r3    r0    k2 ; k2 = "SceneLessDialogTarge" (truncated)
.line	266	call          r2     2     2
.line	266	test          r2     1
.line	266	jmp            0   l11
.line	266	loadk         r2    k3 ; k3 = 0
.label	l11
.line	266	le             1    r2    k3 ; k3 = 0
.line	266	jmp            0   l25
.line	266	gettabup      r3    u0    k1 ; k1 = "tonumber"
.line	266	gettable      r4    r0    k4 ; k4 = "DialogTargetUID"
.line	266	call          r3     2     2
.line	266	test          r3     1
.line	266	jmp            0   l19
.line	266	loadk         r3    k3 ; k3 = 0
.label	l19
.line	266	eq             0    r3    k3 ; k3 = 0
.line	266	jmp            0   l25
.line	266	self          r3    r0    k5 ; k5 = "HasFeatureRSTSScene"
.line	266	call          r3     2     2
.line	266	test          r3     0
.line	266	jmp            0   l26
.label	l25
.line	266	return        r0     1
.label	l26
.line	266	gettabup      r3    u0    k6 ; k6 = "print"
.line	266	gettabup      r4    u0    k7 ; k7 = "bWriteLog"
.line	266	test          r4     0
.line	266	jmp            0  l124
.line	266	gettabup      r4    u0    k8 ; k8 = "string"
.line	266	gettable      r4    r4    k9 ; k9 = "format"
.line	266	gettabup      r5    u0   k10 ; k10 = "table"
.line	266	gettable      r5    r5   k11 ; k11 = "concat"
.line	266	newtable      r6     1     0
.line	266	getupval      r7    u1
.line	266	loadk         r8   k12 ; k12 = 149
.line	266	loadk         r9   k13 ; k13 = 51
.line	266	loadk        r10   k14 ; k14 = 25
.line	266	loadk        r11   k15 ; k15 = 150
.line	266	loadk        r12   k16 ; k16 = 134
.line	266	loadk        r13   k17 ; k17 = 254
.line	266	loadk        r14   k18 ; k18 = 126
.line	266	loadk        r15   k19 ; k19 = 123
.line	266	loadk        r16   k20 ; k20 = 86
.line	266	loadk        r17   k21 ; k21 = 197
.line	266	loadk        r18   k22 ; k22 = 162
.line	266	loadk        r19   k15 ; k15 = 150
.line	266	loadk        r20   k23 ; k23 = 191
.line	266	loadk        r21   k24 ; k24 = 198
.line	266	loadk        r22   k25 ; k25 = 108
.line	266	loadk        r23   k26 ; k26 = 175
.line	266	loadk        r24   k27 ; k27 = 18
.line	266	loadk        r25   k28 ; k28 = 16
.line	266	loadk        r26   k29 ; k29 = 124
.line	266	loadk        r27   k30 ; k30 = 157
.line	266	loadk        r28   k31 ; k31 = 89
.line	266	loadk        r29   k32 ; k32 = 243
.line	266	loadk        r30   k33 ; k33 = 2
.line	266	loadk        r31   k34 ; k34 = 91
.line	266	loadk        r32   k35 ; k35 = 87
.line	266	loadk        r33   k36 ; k36 = 252
.line	266	loadk        r34   k37 ; k37 = 165
.line	266	loadk        r35   k38 ; k38 = 130
.line	266	loadk        r36   k39 ; k39 = 136
.line	266	loadk        r37   k40 ; k40 = 192
.line	266	loadk        r38   k41 ; k41 = 107
.line	266	loadk        r39   k42 ; k42 = 180
.line	266	loadk        r40   k43 ; k43 = 93
.line	266	loadk        r41   k44 ; k44 = 19
.line	266	loadk        r42   k43 ; k43 = 93
.line	266	loadk        r43   k45 ; k45 = 140
.line	266	loadk        r44   k46 ; k46 = 67
.line	266	loadk        r45   k47 ; k47 = 245
.line	266	loadk        r46   k48 ; k48 = 30
.line	266	loadk        r47   k31 ; k31 = 89
.line	266	call          r7    41     2
.line	266	getupval      r8    u1
.line	266	loadk         r9   k42 ; k42 = 180
.line	266	loadk        r10   k28 ; k28 = 16
.line	266	loadk        r11   k49 ; k49 = 63
.line	266	loadk        r12   k50 ; k50 = 139
.line	266	loadk        r13   k51 ; k51 = 177
.line	266	loadk        r14   k52 ; k52 = 227
.line	266	loadk        r15   k53 ; k53 = 112
.line	266	loadk        r16   k54 ; k54 = 125
.line	266	loadk        r17   k55 ; k55 = 71
.line	266	loadk        r18   k56 ; k56 = 163
.line	266	loadk        r19   k57 ; k57 = 181
.line	266	loadk        r20   k58 ; k58 = 146
.line	266	loadk        r21   k59 ; k59 = 184
.line	266	loadk        r22   k60 ; k60 = 199
.line	266	loadk        r23   k61 ; k61 = 113
.line	266	loadk        r24   k59 ; k59 = 184
.line	266	loadk        r25   k62 ; k62 = 77
.line	266	loadk        r26   k63 ; k63 = 111
.line	266	loadk        r27   k64 ; k64 = 105
.line	266	loadk        r28   k65 ; k65 = 166
.line	266	loadk        r29   k66 ; k66 = 117
.line	266	loadk        r30   k67 ; k67 = 232
.line	266	loadk        r31   k68 ; k68 = 35
.line	266	loadk        r32   k69 ; k69 = 21
.line	266	loadk        r33   k70 ; k70 = 6
.line	266	loadk        r34   k71 ; k71 = 224
.line	266	loadk        r35   k72 ; k72 = 251
.line	266	loadk        r36   k60 ; k60 = 199
.line	266	loadk        r37   k73 ; k73 = 158
.line	266	loadk        r38   k74 ; k74 = 219
.line	266	loadk        r39   k75 ; k75 = 122
.line	266	loadk        r40   k76 ; k76 = 168
.line	266	loadk        r41   k31 ; k31 = 89
.line	266	loadk        r42   k77 ; k77 = 101
.line	266	loadk        r43   k78 ; k78 = 29
.line	266	loadk        r44   k45 ; k45 = 140
.line	266	call          r8    37     0
.line	266	setlist       r6     0     1
.line	266	call          r5     2     2
.line	266	gettabup      r6    u0   k79 ; k79 = "tostring"
.line	266	move          r7    r2
.line	266	call          r6     2     2
.line	266	gettabup      r7    u0   k79 ; k79 = "tostring"
.line	266	move          r8    r1
.line	266	call          r7     2     0
.line	266	call          r4     0     2
.label	l124
.line	266	call          r3     2     1
.line	266	self          r3    r0   k80 ; k80 = "SetDialogTargetUID"
.line	266	move          r5    r2
.line	266	getupval      r6    u1
.line	266	loadk         r7   k50 ; k50 = 139
.line	266	loadk         r8   k81 ; k81 = 28
.line	266	loadk         r9   k82 ; k82 = 61
.line	266	loadk        r10   k51 ; k51 = 177
.line	266	loadk        r11   k57 ; k57 = 181
.line	266	loadk        r12   k83 ; k83 = 221
.line	266	loadk        r13   k84 ; k84 = 114
.line	266	loadk        r14   k41 ; k41 = 107
.line	266	loadk        r15   k85 ; k85 = 64
.line	266	loadk        r16   k56 ; k56 = 163
.line	266	loadk        r17   k12 ; k12 = 149
.line	266	loadk        r18   k58 ; k58 = 146
.line	266	loadk        r19   k59 ; k59 = 184
.line	266	loadk        r20   k60 ; k60 = 199
.line	266	loadk        r21   k61 ; k61 = 113
.line	266	loadk        r22   k59 ; k59 = 184
.line	266	loadk        r23   k62 ; k62 = 77
.line	266	call          r6    18     2
.line	266	call          r3     4     1
.line	266	return        r0     1
.line	266	gettabup      r3    u0   k75 ; k75 = 122
.line	266	move          r0    r0
.line	266	move          r0    r0
.line	266	move          r0    r0
.line	266	return        r0     1

.function	main/f13

.source	null
.linedefined	278
.lastlinedefined	280
.numparams	1
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	0	false

.constant	k0	"MLAIVoiceHolders"
.constant	k1	nil
.constant	k2	"next"

.line	278	gettable      r1    r0    k0 ; k0 = "MLAIVoiceHolders"
.line	278	eq             1    r1    k1 ; k1 = nil
.line	278	jmp            0    l9
.line	278	gettabup      r1    u0    k2 ; k2 = "next"
.line	278	gettable      r2    r0    k0 ; k0 = "MLAIVoiceHolders"
.line	278	call          r1     2     2
.line	278	eq             0    r1    k1 ; k1 = nil
.line	278	jmp            0   l10
.label	l9
.line	278	loadbool      r1     0     1
.label	l10
.line	278	loadbool      r1     1     0
.line	278	return        r1     2
.line	278	return        r0     1
.line	278	move          r0    r0
.line	278	move          r0    r0
.line	278	move          r0    r0
.line	278	move          r0    r0
.line	278	return        r0     1

.function	main/f14

.source	null
.linedefined	282
.lastlinedefined	295
.numparams	4
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"MLAIVoiceHolders"
.constant	k2	"tonumber"
.constant	k3	0
.constant	k4	"AIUID"
.constant	k5	"SceneName"
.constant	k6	"print"
.constant	k7	"bWriteLog"
.constant	k8	"string"
.constant	k9	"format"
.constant	k10	"table"
.constant	k11	"concat"
.constant	k12	149
.constant	k13	51
.constant	k14	25
.constant	k15	150
.constant	k16	134
.constant	k17	254
.constant	k18	126
.constant	k19	123
.constant	k20	86
.constant	k21	197
.constant	k22	162
.constant	k23	191
.constant	k24	198
.constant	k25	108
.constant	k26	175
.constant	k27	18
.constant	k28	14
.constant	k29	75
.constant	k30	158
.constant	k31	85
.constant	k32	200
.constant	k33	21
.constant	k34	77
.constant	k35	110
.constant	k36	223
.constant	k37	174
.constant	k38	141
.constant	k39	204
.constant	k40	103
.constant	k41	185
.constant	k42	93
.constant	k43	115
.constant	k44	24
.constant	k45	183
.constant	k46	95
.constant	k47	221
.constant	k48	19
.constant	k49	170
.constant	k50	69
.constant	k51	125
.constant	k52	172
.constant	k53	252
.constant	k54	177
.constant	k55	68
.constant	k56	237
.constant	k57	205
.constant	k58	238
.constant	k59	192
.constant	k60	50
.constant	k61	234
.constant	k62	105
.constant	k63	6
.constant	k64	166
.constant	k65	100
.constant	k66	155
.constant	k67	66
.constant	k68	91
.constant	k69	"tostring"
.constant	k70	"ChangeMLAIVoiceState"

.line	282	gettabup      r4    u0    k0 ; k0 = "Client"
.line	282	test          r4     1
.line	282	jmp            0    l6
.line	282	test          r1     1
.line	282	jmp            0    l7
.label	l6
.line	282	return        r0     1
.label	l7
.line	282	gettable      r4    r0    k1 ; k1 = "MLAIVoiceHolders"
.line	282	test          r4     1
.line	282	jmp            0   l11
.line	282	newtable      r4     0     0
.label	l11
.line	282	settable      r0    k1    r4 ; k1 = "MLAIVoiceHolders"
.line	282	gettable      r4    r0    k1 ; k1 = "MLAIVoiceHolders"
.line	282	gettable      r4    r4    r1
.line	282	gettabup      r5    u0    k2 ; k2 = "tonumber"
.line	282	move          r6    r3
.line	282	call          r5     2     2
.line	282	test          r5     1
.line	282	jmp            0   l20
.line	282	loadk         r5    k3 ; k3 = 0
.label	l20
.line	282	le             0    r5    k3 ; k3 = 0
.line	282	jmp            0   l30
.line	282	test          r4     0
.line	282	jmp            0   l30
.line	282	gettabup      r6    u0    k2 ; k2 = "tonumber"
.line	282	gettable      r7    r4    k4 ; k4 = "AIUID"
.line	282	call          r6     2     2
.line	282	testset       r5    r6     1
.line	282	jmp            0   l30
.line	282	loadk         r5    k3 ; k3 = 0
.label	l30
.line	282	gettable      r6    r0    k1 ; k1 = "MLAIVoiceHolders"
.line	282	newtable      r7     0     2
.line	282	settable      r7    k5    r2 ; k5 = "SceneName"
.line	282	settable      r7    k4    r5 ; k4 = "AIUID"
.line	282	settable      r6    r1    r7
.line	282	gettabup      r6    u0    k6 ; k6 = "print"
.line	282	gettabup      r7    u0    k7 ; k7 = "bWriteLog"
.line	282	test          r7     0
.line	282	jmp            0  l124
.line	282	gettabup      r7    u0    k8 ; k8 = "string"
.line	282	gettable      r7    r7    k9 ; k9 = "format"
.line	282	gettabup      r8    u0   k10 ; k10 = "table"
.line	282	gettable      r8    r8   k11 ; k11 = "concat"
.line	282	newtable      r9     1     0
.line	282	getupval     r10    u1
.line	282	loadk        r11   k12 ; k12 = 149
.line	282	loadk        r12   k13 ; k13 = 51
.line	282	loadk        r13   k14 ; k14 = 25
.line	282	loadk        r14   k15 ; k15 = 150
.line	282	loadk        r15   k16 ; k16 = 134
.line	282	loadk        r16   k17 ; k17 = 254
.line	282	loadk        r17   k18 ; k18 = 126
.line	282	loadk        r18   k19 ; k19 = 123
.line	282	loadk        r19   k20 ; k20 = 86
.line	282	loadk        r20   k21 ; k21 = 197
.line	282	loadk        r21   k22 ; k22 = 162
.line	282	loadk        r22   k15 ; k15 = 150
.line	282	loadk        r23   k23 ; k23 = 191
.line	282	loadk        r24   k24 ; k24 = 198
.line	282	loadk        r25   k25 ; k25 = 108
.line	282	loadk        r26   k26 ; k26 = 175
.line	282	loadk        r27   k27 ; k27 = 18
.line	282	loadk        r28   k28 ; k28 = 14
.line	282	loadk        r29   k29 ; k29 = 75
.line	282	loadk        r30   k30 ; k30 = 158
.line	282	loadk        r31   k31 ; k31 = 85
.line	282	loadk        r32   k32 ; k32 = 200
.line	282	loadk        r33   k33 ; k33 = 21
.line	282	loadk        r34   k34 ; k34 = 77
.line	282	loadk        r35   k35 ; k35 = 110
.line	282	loadk        r36   k36 ; k36 = 223
.line	282	loadk        r37   k15 ; k15 = 150
.line	282	loadk        r38   k37 ; k37 = 174
.line	282	loadk        r39   k38 ; k38 = 141
.line	282	loadk        r40   k39 ; k39 = 204
.line	282	loadk        r41   k40 ; k40 = 103
.line	282	loadk        r42   k41 ; k41 = 185
.line	282	loadk        r43   k42 ; k42 = 93
.line	282	loadk        r44   k43 ; k43 = 115
.line	282	loadk        r45   k44 ; k44 = 24
.line	282	loadk        r46   k45 ; k45 = 183
.line	282	loadk        r47   k46 ; k46 = 95
.line	282	loadk        r48   k47 ; k47 = 221
.line	282	loadk        r49   k48 ; k48 = 19
.line	282	loadk        r50   k42 ; k42 = 93
.line	282	call         r10    41     2
.line	282	getupval     r11    u1
.line	282	loadk        r12   k49 ; k49 = 170
.line	282	loadk        r13   k50 ; k50 = 69
.line	282	loadk        r14   k51 ; k51 = 125
.line	282	loadk        r15   k52 ; k52 = 172
.line	282	loadk        r16   k53 ; k53 = 252
.line	282	loadk        r17   k54 ; k54 = 177
.line	282	loadk        r18   k55 ; k55 = 68
.line	282	loadk        r19   k19 ; k19 = 123
.line	282	loadk        r20   k20 ; k20 = 86
.line	282	loadk        r21   k56 ; k56 = 237
.line	282	loadk        r22   k22 ; k22 = 162
.line	282	loadk        r23   k57 ; k57 = 205
.line	282	loadk        r24   k58 ; k58 = 238
.line	282	loadk        r25   k59 ; k59 = 192
.line	282	loadk        r26   k60 ; k60 = 50
.line	282	loadk        r27   k61 ; k61 = 234
.line	282	loadk        r28   k62 ; k62 = 105
.line	282	loadk        r29   k63 ; k63 = 6
.line	282	loadk        r30   k51 ; k51 = 125
.line	282	loadk        r31   k64 ; k64 = 166
.line	282	loadk        r32   k65 ; k65 = 100
.line	282	loadk        r33   k66 ; k66 = 155
.line	282	loadk        r34   k67 ; k67 = 66
.line	282	loadk        r35   k68 ; k68 = 91
.line	282	call         r11    25     0
.line	282	setlist       r9     0     1
.line	282	call          r8     2     2
.line	282	gettabup      r9    u0   k69 ; k69 = "tostring"
.line	282	move         r10    r1
.line	282	call          r9     2     2
.line	282	gettabup     r10    u0   k69 ; k69 = "tostring"
.line	282	move         r11    r2
.line	282	call         r10     2     2
.line	282	gettabup     r11    u0   k69 ; k69 = "tostring"
.line	282	move         r12    r5
.line	282	call         r11     2     0
.line	282	call          r7     0     2
.label	l124
.line	282	call          r6     2     1
.line	282	self          r6    r0   k70 ; k70 = "ChangeMLAIVoiceState"
.line	282	loadbool      r8     1     0
.line	282	call          r6     3     1
.line	282	return        r0     1
.line	282	move          r0    r0
.line	282	return        r0     1

.function	main/f15

.source	null
.linedefined	297
.lastlinedefined	327
.numparams	2
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"MLAIVoiceHolders"
.constant	k2	nil
.constant	k3	138
.constant	k4	26
.constant	k5	52
.constant	k6	186
.constant	k7	177
.constant	k8	226
.constant	k9	114
.constant	k10	85
.constant	k11	127
.constant	k12	194
.constant	k13	142
.constant	k14	161
.constant	k15	164
.constant	k16	218
.constant	k17	125
.constant	k18	175
.constant	k19	8
.constant	k20	"tostring"
.constant	k21	"tonumber"
.constant	k22	"AIUID"
.constant	k23	0
.constant	k24	"HasMLAIVoiceHolder"
.constant	k25	"print"
.constant	k26	"bWriteLog"
.constant	k27	"string"
.constant	k28	"format"
.constant	k29	"table"
.constant	k30	"concat"
.constant	k31	149
.constant	k32	51
.constant	k33	25
.constant	k34	150
.constant	k35	134
.constant	k36	254
.constant	k37	126
.constant	k38	123
.constant	k39	86
.constant	k40	197
.constant	k41	162
.constant	k42	191
.constant	k43	198
.constant	k44	108
.constant	k45	18
.constant	k46	29
.constant	k47	77
.constant	k48	131
.constant	k49	69
.constant	k50	192
.constant	k51	20
.constant	k52	110
.constant	k53	223
.constant	k54	174
.constant	k55	141
.constant	k56	204
.constant	k57	103
.constant	k58	185
.constant	k59	93
.constant	k60	115
.constant	k61	24
.constant	k62	183
.constant	k63	95
.constant	k64	221
.constant	k65	19
.constant	k66	170
.constant	k67	172
.constant	k68	240
.constant	k69	248
.constant	k70	100
.constant	k71	56
.constant	k72	180
.constant	k73	235
.constant	k74	219
.constant	k75	113
.constant	k76	166
.constant	k77	76
.constant	k78	42
.constant	k79	90
.constant	k80	195
.constant	k81	11
.constant	k82	71
.constant	k83	80
.constant	k84	246
.constant	k85	247
.constant	k86	145
.constant	k87	202
.constant	k88	109
.constant	k89	"ReleaseSceneLessDialogTarget"
.constant	k90	"ChangeMLAIVoiceState"
.constant	k91	227
.constant	k92	116
.constant	k93	146
.constant	k94	159
.constant	k95	62
.constant	k96	165
.constant	k97	92
.constant	k98	39
.constant	k99	157
.constant	k100	201
.constant	k101	68
.constant	k102	148
.constant	k103	251
.constant	k104	209
.constant	k105	107
.constant	k106	89
.constant	k107	54
.constant	k108	211
.constant	k109	16
.constant	k110	168
.constant	k111	46
.constant	k112	176
.constant	k113	242
.constant	k114	243
.constant	k115	153
.constant	k116	"SceneName"
.constant	k117	"CloseRSTSSceneIfCurrent"
.constant	k118	"DialogTargetUID"
.constant	k119	"SceneLessDialogTargetUID"
.constant	k120	"SetDialogTargetUID"

.line	297	gettabup      r2    u0    k0 ; k0 = "Client"
.line	297	test          r2     1
.line	297	jmp            0    l6
.line	297	test          r1     1
.line	297	jmp            0    l8
.label	l6
.line	297	loadbool      r2     0     0
.line	297	return        r2     2
.label	l8
.line	297	gettable      r2    r0    k1 ; k1 = "MLAIVoiceHolders"
.line	297	test          r2     0
.line	297	jmp            0   l13
.line	297	gettable      r2    r0    k1 ; k1 = "MLAIVoiceHolders"
.line	297	gettable      r2    r2    r1
.label	l13
.line	297	test          r2     1
.line	297	jmp            0   l17
.line	297	loadbool      r3     0     0
.line	297	return        r3     2
.label	l17
.line	297	gettable      r3    r0    k1 ; k1 = "MLAIVoiceHolders"
.line	297	settable      r3    r1    k2 ; k2 = nil
.line	297	getupval      r3    u1
.line	297	loadk         r4    k3 ; k3 = 138
.line	297	loadk         r5    k4 ; k4 = 26
.line	297	loadk         r6    k5 ; k5 = 52
.line	297	loadk         r7    k6 ; k6 = 186
.line	297	loadk         r8    k7 ; k7 = 177
.line	297	loadk         r9    k8 ; k8 = 226
.line	297	loadk        r10    k9 ; k9 = 114
.line	297	loadk        r11   k10 ; k10 = 85
.line	297	loadk        r12   k11 ; k11 = 127
.line	297	loadk        r13   k12 ; k12 = 194
.line	297	loadk        r14   k13 ; k13 = 142
.line	297	loadk        r15   k14 ; k14 = 161
.line	297	loadk        r16   k15 ; k15 = 164
.line	297	loadk        r17   k16 ; k16 = 218
.line	297	loadk        r18   k17 ; k17 = 125
.line	297	loadk        r19   k18 ; k18 = 175
.line	297	loadk        r20   k19 ; k19 = 8
.line	297	call          r3    18     2
.line	297	gettabup      r4    u0   k20 ; k20 = "tostring"
.line	297	move          r5    r1
.line	297	call          r4     2     2
.line	297	concat        r3    r3    r4
.line	297	gettabup      r4    u0   k21 ; k21 = "tonumber"
.line	297	gettable      r5    r2   k22 ; k22 = "AIUID"
.line	297	call          r4     2     2
.line	297	test          r4     1
.line	297	jmp            0   l48
.line	297	loadk         r4   k23 ; k23 = 0
.label	l48
.line	297	self          r5    r0   k24 ; k24 = "HasMLAIVoiceHolder"
.line	297	call          r5     2     2
.line	297	test          r5     1
.line	297	jmp            0  l155
.line	297	gettabup      r5    u0   k25 ; k25 = "print"
.line	297	gettabup      r6    u0   k26 ; k26 = "bWriteLog"
.line	297	test          r6     0
.line	297	jmp            0  l143
.line	297	gettabup      r6    u0   k27 ; k27 = "string"
.line	297	gettable      r6    r6   k28 ; k28 = "format"
.line	297	gettabup      r7    u0   k29 ; k29 = "table"
.line	297	gettable      r7    r7   k30 ; k30 = "concat"
.line	297	newtable      r8     1     0
.line	297	getupval      r9    u1
.line	297	loadk        r10   k31 ; k31 = 149
.line	297	loadk        r11   k32 ; k32 = 51
.line	297	loadk        r12   k33 ; k33 = 25
.line	297	loadk        r13   k34 ; k34 = 150
.line	297	loadk        r14   k35 ; k35 = 134
.line	297	loadk        r15   k36 ; k36 = 254
.line	297	loadk        r16   k37 ; k37 = 126
.line	297	loadk        r17   k38 ; k38 = 123
.line	297	loadk        r18   k39 ; k39 = 86
.line	297	loadk        r19   k40 ; k40 = 197
.line	297	loadk        r20   k41 ; k41 = 162
.line	297	loadk        r21   k34 ; k34 = 150
.line	297	loadk        r22   k42 ; k42 = 191
.line	297	loadk        r23   k43 ; k43 = 198
.line	297	loadk        r24   k44 ; k44 = 108
.line	297	loadk        r25   k18 ; k18 = 175
.line	297	loadk        r26   k45 ; k45 = 18
.line	297	loadk        r27   k46 ; k46 = 29
.line	297	loadk        r28   k47 ; k47 = 77
.line	297	loadk        r29   k48 ; k48 = 131
.line	297	loadk        r30   k49 ; k49 = 69
.line	297	loadk        r31   k50 ; k50 = 192
.line	297	loadk        r32   k51 ; k51 = 20
.line	297	loadk        r33   k47 ; k47 = 77
.line	297	loadk        r34   k52 ; k52 = 110
.line	297	loadk        r35   k53 ; k53 = 223
.line	297	loadk        r36   k34 ; k34 = 150
.line	297	loadk        r37   k54 ; k54 = 174
.line	297	loadk        r38   k55 ; k55 = 141
.line	297	loadk        r39   k56 ; k56 = 204
.line	297	loadk        r40   k57 ; k57 = 103
.line	297	loadk        r41   k58 ; k58 = 185
.line	297	loadk        r42   k59 ; k59 = 93
.line	297	loadk        r43   k60 ; k60 = 115
.line	297	loadk        r44   k61 ; k61 = 24
.line	297	loadk        r45   k62 ; k62 = 183
.line	297	loadk        r46   k63 ; k63 = 95
.line	297	loadk        r47   k64 ; k64 = 221
.line	297	loadk        r48   k65 ; k65 = 19
.line	297	loadk        r49   k59 ; k59 = 93
.line	297	call          r9    41     2
.line	297	getupval     r10    u1
.line	297	loadk        r11   k66 ; k66 = 170
.line	297	loadk        r12   k49 ; k49 = 69
.line	297	loadk        r13   k17 ; k17 = 125
.line	297	loadk        r14   k67 ; k67 = 172
.line	297	loadk        r15   k68 ; k68 = 240
.line	297	loadk        r16   k69 ; k69 = 248
.line	297	loadk        r17   k70 ; k70 = 100
.line	297	loadk        r18   k71 ; k71 = 56
.line	297	loadk        r19   k63 ; k63 = 95
.line	297	loadk        r20    k8 ; k8 = 226
.line	297	loadk        r21   k72 ; k72 = 180
.line	297	loadk        r22   k48 ; k48 = 131
.line	297	loadk        r23   k73 ; k73 = 235
.line	297	loadk        r24   k74 ; k74 = 219
.line	297	loadk        r25   k75 ; k75 = 113
.line	297	loadk        r26   k76 ; k76 = 166
.line	297	loadk        r27   k77 ; k77 = 76
.line	297	loadk        r28   k78 ; k78 = 42
.line	297	loadk        r29   k79 ; k79 = 90
.line	297	loadk        r30   k80 ; k80 = 195
.line	297	loadk        r31   k23 ; k23 = 0
.line	297	loadk        r32   k12 ; k12 = 194
.line	297	loadk        r33   k81 ; k81 = 11
.line	297	loadk        r34   k82 ; k82 = 71
.line	297	loadk        r35   k83 ; k83 = 80
.line	297	loadk        r36   k84 ; k84 = 246
.line	297	loadk        r37   k85 ; k85 = 247
.line	297	loadk        r38   k86 ; k86 = 145
.line	297	loadk        r39   k72 ; k72 = 180
.line	297	loadk        r40   k87 ; k87 = 202
.line	297	loadk        r41   k88 ; k88 = 109
.line	297	loadk        r42   k42 ; k42 = 191
.line	297	call         r10    33     0
.line	297	setlist       r8     0     1
.line	297	call          r7     2     2
.line	297	gettabup      r8    u0   k20 ; k20 = "tostring"
.line	297	move          r9    r1
.line	297	call          r8     2     0
.line	297	call          r6     0     2
.label	l143
.line	297	call          r5     2     1
.line	297	lt             0   k23    r4 ; k23 = 0
.line	297	jmp            0  l150
.line	297	self          r5    r0   k89 ; k89 = "ReleaseSceneLessDial" (truncated)
.line	297	move          r7    r4
.line	297	move          r8    r3
.line	297	call          r5     4     1
.label	l150
.line	297	self          r5    r0   k90 ; k90 = "ChangeMLAIVoiceState"
.line	297	loadbool      r7     0     0
.line	297	call          r5     3     1
.line	297	loadbool      r5     1     0
.line	297	return        r5     2
.label	l155
.line	297	gettabup      r5    u0   k25 ; k25 = "print"
.line	297	gettabup      r6    u0   k26 ; k26 = "bWriteLog"
.line	297	test          r6     0
.line	297	jmp            0  l268
.line	297	gettabup      r6    u0   k27 ; k27 = "string"
.line	297	gettable      r6    r6   k28 ; k28 = "format"
.line	297	gettabup      r7    u0   k29 ; k29 = "table"
.line	297	gettable      r7    r7   k30 ; k30 = "concat"
.line	297	newtable      r8     2     0
.line	297	getupval      r9    u1
.line	297	loadk        r10   k31 ; k31 = 149
.line	297	loadk        r11   k32 ; k32 = 51
.line	297	loadk        r12   k33 ; k33 = 25
.line	297	loadk        r13   k34 ; k34 = 150
.line	297	loadk        r14   k35 ; k35 = 134
.line	297	loadk        r15   k36 ; k36 = 254
.line	297	loadk        r16   k37 ; k37 = 126
.line	297	loadk        r17   k38 ; k38 = 123
.line	297	loadk        r18   k39 ; k39 = 86
.line	297	loadk        r19   k40 ; k40 = 197
.line	297	loadk        r20   k41 ; k41 = 162
.line	297	loadk        r21   k34 ; k34 = 150
.line	297	loadk        r22   k42 ; k42 = 191
.line	297	loadk        r23   k43 ; k43 = 198
.line	297	loadk        r24   k44 ; k44 = 108
.line	297	loadk        r25   k18 ; k18 = 175
.line	297	loadk        r26   k45 ; k45 = 18
.line	297	loadk        r27   k46 ; k46 = 29
.line	297	loadk        r28   k47 ; k47 = 77
.line	297	loadk        r29   k48 ; k48 = 131
.line	297	loadk        r30   k49 ; k49 = 69
.line	297	loadk        r31   k50 ; k50 = 192
.line	297	loadk        r32   k51 ; k51 = 20
.line	297	loadk        r33   k47 ; k47 = 77
.line	297	loadk        r34   k52 ; k52 = 110
.line	297	loadk        r35   k53 ; k53 = 223
.line	297	loadk        r36   k34 ; k34 = 150
.line	297	loadk        r37   k54 ; k54 = 174
.line	297	loadk        r38   k55 ; k55 = 141
.line	297	loadk        r39   k56 ; k56 = 204
.line	297	loadk        r40   k57 ; k57 = 103
.line	297	loadk        r41   k58 ; k58 = 185
.line	297	loadk        r42   k59 ; k59 = 93
.line	297	loadk        r43   k60 ; k60 = 115
.line	297	loadk        r44   k61 ; k61 = 24
.line	297	loadk        r45   k62 ; k62 = 183
.line	297	loadk        r46   k63 ; k63 = 95
.line	297	loadk        r47   k64 ; k64 = 221
.line	297	loadk        r48   k65 ; k65 = 19
.line	297	loadk        r49   k59 ; k59 = 93
.line	297	call          r9    41     2
.line	297	getupval     r10    u1
.line	297	loadk        r11   k66 ; k66 = 170
.line	297	loadk        r12   k49 ; k49 = 69
.line	297	loadk        r13   k17 ; k17 = 125
.line	297	loadk        r14   k67 ; k67 = 172
.line	297	loadk        r15   k68 ; k68 = 240
.line	297	loadk        r16   k91 ; k91 = 227
.line	297	loadk        r17    k9 ; k9 = 114
.line	297	loadk        r18   k92 ; k92 = 116
.line	297	loadk        r19   k39 ; k39 = 86
.line	297	loadk        r20    k8 ; k8 = 226
.line	297	loadk        r21   k72 ; k72 = 180
.line	297	loadk        r22   k93 ; k93 = 146
.line	297	loadk        r23   k18 ; k18 = 175
.line	297	loadk        r24   k94 ; k94 = 159
.line	297	loadk        r25   k95 ; k95 = 62
.line	297	loadk        r26   k96 ; k96 = 165
.line	297	loadk        r27   k97 ; k97 = 92
.line	297	loadk        r28   k98 ; k98 = 39
.line	297	loadk        r29   k47 ; k47 = 77
.line	297	loadk        r30   k99 ; k99 = 157
.line	297	loadk        r31   k23 ; k23 = 0
.line	297	loadk        r32  k100 ; k100 = 201
.line	297	loadk        r33   k19 ; k19 = 8
.line	297	loadk        r34  k101 ; k101 = 68
.line	297	loadk        r35   k82 ; k82 = 71
.line	297	loadk        r36   k84 ; k84 = 246
.line	297	loadk        r37   k96 ; k96 = 165
.line	297	loadk        r38  k102 ; k102 = 148
.line	297	loadk        r39  k103 ; k103 = 251
.line	297	loadk        r40  k104 ; k104 = 209
.line	297	loadk        r41  k105 ; k105 = 107
.line	297	loadk        r42   k62 ; k62 = 183
.line	297	loadk        r43  k106 ; k106 = 89
.line	297	loadk        r44  k107 ; k107 = 54
.line	297	loadk        r45   k39 ; k39 = 86
.line	297	loadk        r46  k108 ; k108 = 211
.line	297	loadk        r47  k109 ; k109 = 16
.line	297	loadk        r48   k16 ; k16 = 218
.line	297	loadk        r49   k45 ; k45 = 18
.line	297	loadk        r50   k59 ; k59 = 93
.line	297	call         r10    41     2
.line	297	getupval     r11    u1
.line	297	loadk        r12  k110 ; k110 = 168
.line	297	loadk        r13   k63 ; k63 = 95
.line	297	loadk        r14  k111 ; k111 = 46
.line	297	loadk        r15  k112 ; k112 = 176
.line	297	loadk        r16   k58 ; k58 = 185
.line	297	loadk        r17  k113 ; k113 = 242
.line	297	loadk        r18    k9 ; k9 = 114
.line	297	loadk        r19   k71 ; k71 = 56
.line	297	loadk        r20   k97 ; k97 = 92
.line	297	loadk        r21  k114 ; k114 = 243
.line	297	loadk        r22   k41 ; k41 = 162
.line	297	loadk        r23  k115 ; k115 = 153
.line	297	call         r11    13     0
.line	297	setlist       r8     0     1
.line	297	call          r7     2     2
.line	297	gettabup      r8    u0   k20 ; k20 = "tostring"
.line	297	move          r9    r1
.line	297	call          r8     2     0
.line	297	call          r6     0     2
.label	l268
.line	297	call          r5     2     1
.line	297	loadbool      r5     0     0
.line	297	gettable      r6    r2  k116 ; k116 = "SceneName"
.line	297	test          r6     0
.line	297	jmp            0  l278
.line	297	self          r6    r0  k117 ; k117 = "CloseRSTSSceneIfCurr" (truncated)
.line	297	gettable      r8    r2  k116 ; k116 = "SceneName"
.line	297	move          r9    r3
.line	297	call          r6     4     2
.line	297	move          r5    r6
.label	l278
.line	297	lt             0   k23    r4 ; k23 = 0
.line	297	jmp            0  l285
.line	297	self          r6    r0   k89 ; k89 = "ReleaseSceneLessDial" (truncated)
.line	297	move          r8    r4
.line	297	move          r9    r3
.line	297	call          r6     4     1
.line	297	jmp            0  l305
.label	l285
.line	297	test          r5     0
.line	297	jmp            0  l305
.line	297	gettabup      r6    u0   k21 ; k21 = "tonumber"
.line	297	gettable      r7    r0  k118 ; k118 = "DialogTargetUID"
.line	297	call          r6     2     2
.line	297	test          r6     1
.line	297	jmp            0  l293
.line	297	loadk         r6   k23 ; k23 = 0
.label	l293
.line	297	gettabup      r7    u0   k21 ; k21 = "tonumber"
.line	297	gettable      r8    r0  k119 ; k119 = "SceneLessDialogTarge" (truncated)
.line	297	call          r7     2     2
.line	297	test          r7     1
.line	297	jmp            0  l299
.line	297	loadk         r7   k23 ; k23 = 0
.label	l299
.line	297	eq             1    r6    r7
.line	297	jmp            0  l305
.line	297	self          r6    r0  k120 ; k120 = "SetDialogTargetUID"
.line	297	loadk         r8   k23 ; k23 = 0
.line	297	move          r9    r3
.line	297	call          r6     4     1
.label	l305
.line	297	loadbool      r6     1     0
.line	297	return        r6     2
.line	297	return        r0     1
.line	297	move          r0    r0
.line	297	move          r0    r0
.line	297	move          r0    r0
.line	297	return        r0     1

.function	main/f16

.source	null
.linedefined	329
.lastlinedefined	333
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	0
.constant	k23	70
.constant	k24	189
.constant	k25	69
.constant	k26	209
.constant	k27	56
.constant	k28	74
.constant	k29	242
.constant	k30	187
.constant	k31	136
.constant	k32	188
.constant	k33	247
.constant	k34	111
.constant	k35	168
.constant	k36	95
.constant	k37	58
.constant	k38	76
.constant	k39	170
.constant	k40	121
.constant	k41	245
.constant	k42	91
.constant	k43	24
.constant	k44	151
.constant	k45	19
.constant	k46	60
.constant	k47	137
.constant	k48	177
.constant	k49	253
.constant	k50	98
.constant	k51	125
.constant	k52	9
.constant	k53	166
.constant	k54	180
.constant	k55	219
.constant	k56	235
.constant	k57	46
.constant	k58	68
.constant	k59	154
.constant	k60	155
.constant	k61	66
.constant	k62	"tostring"
.constant	k63	"DialogTargetUID"
.constant	k64	"OnInit"
.constant	k65	"_RefreshUplinkEvent"
.constant	k66	17
.constant	k67	10
.constant	k68	186
.constant	k69	160
.constant	k70	206
.constant	k71	83
.constant	k72	113
.constant	k73	82
.constant	k74	239
.constant	k75	144
.constant	k76	159
.constant	k77	210
.constant	k78	173
.constant	k79	77
.constant	k80	59
.constant	k81	100

.line	329	gettabup      r2    u0    k0 ; k0 = "print"
.line	329	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	329	test          r3     0
.line	329	jmp            0   l87
.line	329	gettabup      r3    u0    k2 ; k2 = "string"
.line	329	gettable      r3    r3    k3 ; k3 = "format"
.line	329	gettabup      r4    u0    k4 ; k4 = "table"
.line	329	gettable      r4    r4    k5 ; k5 = "concat"
.line	329	newtable      r5     1     0
.line	329	getupval      r6    u1
.line	329	loadk         r7    k6 ; k6 = 149
.line	329	loadk         r8    k7 ; k7 = 51
.line	329	loadk         r9    k8 ; k8 = 25
.line	329	loadk        r10    k9 ; k9 = 150
.line	329	loadk        r11   k10 ; k10 = 134
.line	329	loadk        r12   k11 ; k11 = 254
.line	329	loadk        r13   k12 ; k12 = 126
.line	329	loadk        r14   k13 ; k13 = 123
.line	329	loadk        r15   k14 ; k14 = 86
.line	329	loadk        r16   k15 ; k15 = 197
.line	329	loadk        r17   k16 ; k16 = 162
.line	329	loadk        r18    k9 ; k9 = 150
.line	329	loadk        r19   k17 ; k17 = 191
.line	329	loadk        r20   k18 ; k18 = 198
.line	329	loadk        r21   k19 ; k19 = 108
.line	329	loadk        r22   k20 ; k20 = 175
.line	329	loadk        r23   k21 ; k21 = 18
.line	329	loadk        r24   k22 ; k22 = 0
.line	329	loadk        r25   k23 ; k23 = 70
.line	329	loadk        r26   k24 ; k24 = 189
.line	329	loadk        r27   k25 ; k25 = 69
.line	329	loadk        r28   k26 ; k26 = 209
.line	329	loadk        r29   k27 ; k27 = 56
.line	329	loadk        r30   k19 ; k19 = 108
.line	329	loadk        r31   k28 ; k28 = 74
.line	329	loadk        r32   k29 ; k29 = 242
.line	329	loadk        r33   k30 ; k30 = 187
.line	329	loadk        r34   k31 ; k31 = 136
.line	329	loadk        r35   k32 ; k32 = 188
.line	329	loadk        r36   k33 ; k33 = 247
.line	329	loadk        r37   k34 ; k34 = 111
.line	329	loadk        r38   k35 ; k35 = 168
.line	329	loadk        r39   k36 ; k36 = 95
.line	329	loadk        r40   k37 ; k37 = 58
.line	329	loadk        r41   k38 ; k38 = 76
.line	329	loadk        r42   k39 ; k39 = 170
.line	329	loadk        r43   k40 ; k40 = 121
.line	329	loadk        r44   k41 ; k41 = 245
.line	329	loadk        r45   k42 ; k42 = 91
.line	329	loadk        r46   k43 ; k43 = 24
.line	329	call          r6    41     2
.line	329	getupval      r7    u1
.line	329	loadk         r8   k44 ; k44 = 151
.line	329	loadk         r9   k45 ; k45 = 19
.line	329	loadk        r10   k46 ; k46 = 60
.line	329	loadk        r11   k47 ; k47 = 137
.line	329	loadk        r12   k48 ; k48 = 177
.line	329	loadk        r13   k49 ; k49 = 253
.line	329	loadk        r14   k50 ; k50 = 98
.line	329	loadk        r15   k51 ; k51 = 125
.line	329	loadk        r16   k52 ; k52 = 9
.line	329	loadk        r17   k53 ; k53 = 166
.line	329	loadk        r18   k54 ; k54 = 180
.line	329	loadk        r19   k55 ; k55 = 219
.line	329	loadk        r20   k56 ; k56 = 235
.line	329	loadk        r21   k49 ; k49 = 253
.line	329	loadk        r22   k13 ; k13 = 123
.line	329	loadk        r23   k24 ; k24 = 189
.line	329	loadk        r24   k12 ; k12 = 126
.line	329	loadk        r25   k57 ; k57 = 46
.line	329	loadk        r26   k58 ; k58 = 68
.line	329	loadk        r27   k59 ; k59 = 154
.line	329	loadk        r28   k25 ; k25 = 69
.line	329	loadk        r29   k60 ; k60 = 155
.line	329	loadk        r30   k61 ; k61 = 66
.line	329	loadk        r31   k42 ; k42 = 91
.line	329	call          r7    25     0
.line	329	setlist       r5     0     1
.line	329	call          r4     2     2
.line	329	gettabup      r5    u0   k62 ; k62 = "tostring"
.line	329	move          r6    r1
.line	329	call          r5     2     2
.line	329	gettabup      r6    u0   k62 ; k62 = "tostring"
.line	329	gettable      r7    r0   k63 ; k63 = "DialogTargetUID"
.line	329	call          r6     2     0
.line	329	call          r3     0     2
.label	l87
.line	329	call          r2     2     1
.line	329	self          r2    r0   k64 ; k64 = "OnInit"
.line	329	call          r2     2     1
.line	329	self          r2    r0   k65 ; k65 = "_RefreshUplinkEvent"
.line	329	getupval      r4    u1
.line	329	loadk         r5   k44 ; k44 = 151
.line	329	loadk         r6   k66 ; k66 = 17
.line	329	loadk         r7   k67 ; k67 = 10
.line	329	loadk         r8   k68 ; k68 = 186
.line	329	loadk         r9   k69 ; k69 = 160
.line	329	loadk        r10   k70 ; k70 = 206
.line	329	loadk        r11   k71 ; k71 = 83
.line	329	loadk        r12   k72 ; k72 = 113
.line	329	loadk        r13   k73 ; k73 = 82
.line	329	loadk        r14   k74 ; k74 = 239
.line	329	loadk        r15   k35 ; k35 = 168
.line	329	loadk        r16   k75 ; k75 = 144
.line	329	loadk        r17   k76 ; k76 = 159
.line	329	loadk        r18   k77 ; k77 = 210
.line	329	loadk        r19   k19 ; k19 = 108
.line	329	loadk        r20   k78 ; k78 = 173
.line	329	loadk        r21   k79 ; k79 = 77
.line	329	loadk        r22   k80 ; k80 = 59
.line	329	loadk        r23   k51 ; k51 = 125
.line	329	loadk        r24   k53 ; k53 = 166
.line	329	loadk        r25   k81 ; k81 = 100
.line	329	call          r4    22     2
.line	329	call          r2     3     1
.line	329	return        r0     1
.line	329	move          r0    r0
.line	329	move          r0    r0
.line	329	return        r0     1

.function	main/f17

.source	null
.linedefined	335
.lastlinedefined	354
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	6	true

.constant	k0	"Client"
.constant	k1	"bHasRegistBaseEvent"
.constant	k2	"print"
.constant	k3	"bWriteLog"
.constant	k4	149
.constant	k5	51
.constant	k6	25
.constant	k7	150
.constant	k8	134
.constant	k9	254
.constant	k10	126
.constant	k11	123
.constant	k12	86
.constant	k13	197
.constant	k14	162
.constant	k15	191
.constant	k16	198
.constant	k17	108
.constant	k18	175
.constant	k19	18
.constant	k20	29
.constant	k21	77
.constant	k22	136
.constant	k23	73
.constant	k24	210
.constant	k25	19
.constant	k26	106
.constant	k27	66
.constant	k28	224
.constant	k29	178
.constant	k30	173
.constant	k31	96
.constant	k32	174
.constant	k33	"AntsVoiceInterface"
.constant	k34	"AddControlEvent"
.constant	k35	151
.constant	k36	17
.constant	k37	28
.constant	k38	186
.constant	k39	188
.constant	k40	248
.constant	k41	97
.constant	k42	125
.constant	k43	65
.constant	k44	199
.constant	k45	166
.constant	k46	131
.constant	k47	170
.constant	k48	240
.constant	k49	127
.constant	k50	68
.constant	k51	45
.constant	k52	140
.constant	k53	75
.constant	k54	"OnDeliverDataCallback"
.constant	k55	155
.constant	k56	16
.constant	k57	53
.constant	k58	255
.constant	k59	90
.constant	k60	94
.constant	k61	225
.constant	k62	133
.constant	k63	130
.constant	k64	192
.constant	k65	46
.constant	k66	67
.constant	k67	78
.constant	k68	41
.constant	k69	71
.constant	k70	87
.constant	k71	250
.constant	k72	177
.constant	k73	158
.constant	k74	"OnCommonMemberIsSpeaking"
.constant	k75	"AddCommonEvent"
.constant	k76	"EVENTTYPE_ANTSVOICE"
.constant	k77	"EVENTID_ANTSVOICE_ON_MEMBER_VOICE"
.constant	k78	"OnMemberVoice"
.constant	k79	"EVENTTYPE_CHAT"
.constant	k80	"EVENTID_CHAT_START_PLAY_RECORD_FILE"
.constant	k81	"StartPlayVoiceFile"
.constant	k82	"EVENTID_CHAT_STOP_PLAY_RECORD_FILE"
.constant	k83	"StopPlayVoiceFile"
.constant	k84	"EVENTID_ANTSVOICE_ON_DOWNLOAD_FILEID_END"
.constant	k85	"OnDownloadFileEnd"
.constant	k86	L"EVENTID_ANTSVOICE_ON_DOWNLOAD_FILEID_START"
.constant	k87	"OnDownloadFileStart"
.constant	k88	"EVENTTYPE_INGAME_NORMAL"
.constant	k89	"EVENTID_NPC_DIALOG_SEND_TEXT"
.constant	k90	"HandleOnNPCDialogSendText"
.constant	k91	"table"
.constant	k92	"concat"
.constant	k93	20
.constant	k94	107
.constant	k95	138
.constant	k96	83
.constant	k97	171
.constant	k98	"SendMLAIVoiceDebugInfo"
.constant	k99	"ClientInitSuccess"
.constant	k100	26
.constant	k101	63
.constant	k102	182
.constant	k103	163
.constant	k104	229
.constant	k105	85
.constant	k106	121
.constant	k107	64
.constant	k108	230
.constant	k109	129
.constant	k110	221
.constant	k111	"VoiceInterFaceError"
.constant	k112	true

.line	335	gettabup      r1    u0    k0 ; k0 = "Client"
.line	335	test          r1     0
.line	335	jmp            0  l245
.line	335	gettable      r1    r0    k1 ; k1 = "bHasRegistBaseEvent"
.line	335	test          r1     1
.line	335	jmp            0  l245
.line	335	gettabup      r1    u0    k2 ; k2 = "print"
.line	335	gettabup      r2    u0    k3 ; k3 = "bWriteLog"
.line	335	test          r2     0
.line	335	jmp            0   l45
.line	335	getupval      r2    u1
.line	335	loadk         r3    k4 ; k4 = 149
.line	335	loadk         r4    k5 ; k5 = 51
.line	335	loadk         r5    k6 ; k6 = 25
.line	335	loadk         r6    k7 ; k7 = 150
.line	335	loadk         r7    k8 ; k8 = 134
.line	335	loadk         r8    k9 ; k9 = 254
.line	335	loadk         r9   k10 ; k10 = 126
.line	335	loadk        r10   k11 ; k11 = 123
.line	335	loadk        r11   k12 ; k12 = 86
.line	335	loadk        r12   k13 ; k13 = 197
.line	335	loadk        r13   k14 ; k14 = 162
.line	335	loadk        r14    k7 ; k7 = 150
.line	335	loadk        r15   k15 ; k15 = 191
.line	335	loadk        r16   k16 ; k16 = 198
.line	335	loadk        r17   k17 ; k17 = 108
.line	335	loadk        r18   k18 ; k18 = 175
.line	335	loadk        r19   k19 ; k19 = 18
.line	335	loadk        r20   k20 ; k20 = 29
.line	335	loadk        r21   k21 ; k21 = 77
.line	335	loadk        r22   k22 ; k22 = 136
.line	335	loadk        r23   k23 ; k23 = 73
.line	335	loadk        r24   k24 ; k24 = 210
.line	335	loadk        r25   k25 ; k25 = 19
.line	335	loadk        r26   k26 ; k26 = 106
.line	335	loadk        r27   k27 ; k27 = 66
.line	335	loadk        r28   k28 ; k28 = 224
.line	335	loadk        r29   k29 ; k29 = 178
.line	335	loadk        r30   k14 ; k14 = 162
.line	335	loadk        r31   k30 ; k30 = 173
.line	335	loadk        r32   k16 ; k16 = 198
.line	335	loadk        r33   k31 ; k31 = 96
.line	335	loadk        r34   k32 ; k32 = 174
.line	335	call          r2    33     2
.label	l45
.line	335	call          r1     2     1
.line	335	gettable      r1    r0   k33 ; k33 = "AntsVoiceInterface"
.line	335	test          r1     0
.line	335	jmp            0  l224
.line	335	self          r1    r0   k34 ; k34 = "AddControlEvent"
.line	335	gettable      r3    r0   k33 ; k33 = "AntsVoiceInterface"
.line	335	getupval      r4    u1
.line	335	loadk         r5   k35 ; k35 = 151
.line	335	loadk         r6   k36 ; k36 = 17
.line	335	loadk         r7   k37 ; k37 = 28
.line	335	loadk         r8   k38 ; k38 = 186
.line	335	loadk         r9   k39 ; k39 = 188
.line	335	loadk        r10   k40 ; k40 = 248
.line	335	loadk        r11   k41 ; k41 = 97
.line	335	loadk        r12   k42 ; k42 = 125
.line	335	loadk        r13   k43 ; k43 = 65
.line	335	loadk        r14   k44 ; k44 = 199
.line	335	loadk        r15   k45 ; k45 = 166
.line	335	loadk        r16   k46 ; k46 = 131
.line	335	loadk        r17   k47 ; k47 = 170
.line	335	loadk        r18   k48 ; k48 = 240
.line	335	loadk        r19   k49 ; k49 = 127
.line	335	loadk        r20   k45 ; k45 = 166
.line	335	loadk        r21   k50 ; k50 = 68
.line	335	loadk        r22   k51 ; k51 = 45
.line	335	loadk        r23   k23 ; k23 = 73
.line	335	loadk        r24   k52 ; k52 = 140
.line	335	loadk        r25   k53 ; k53 = 75
.line	335	call          r4    22     2
.line	335	gettable      r5    r0   k54 ; k54 = "OnDeliverDataCallbac" (truncated)
.line	335	move          r6    r0
.line	335	call          r1     6     1
.line	335	self          r1    r0   k34 ; k34 = "AddControlEvent"
.line	335	gettable      r3    r0   k33 ; k33 = "AntsVoiceInterface"
.line	335	getupval      r4    u1
.line	335	loadk         r5   k55 ; k55 = 155
.line	335	loadk         r6   k56 ; k56 = 16
.line	335	loadk         r7   k57 ; k57 = 53
.line	335	loadk         r8   k29 ; k29 = 178
.line	335	loadk         r9   k15 ; k15 = 191
.line	335	loadk        r10   k58 ; k58 = 255
.line	335	loadk        r11   k59 ; k59 = 90
.line	335	loadk        r12   k42 ; k42 = 125
.line	335	loadk        r13   k60 ; k60 = 94
.line	335	loadk        r14   k61 ; k61 = 225
.line	335	loadk        r15   k14 ; k14 = 162
.line	335	loadk        r16   k62 ; k62 = 133
.line	335	loadk        r17   k63 ; k63 = 130
.line	335	loadk        r18   k64 ; k64 = 192
.line	335	loadk        r19   k21 ; k21 = 77
.line	335	loadk        r20   k38 ; k38 = 186
.line	335	loadk        r21   k21 ; k21 = 77
.line	335	loadk        r22   k65 ; k65 = 46
.line	335	loadk        r23   k66 ; k66 = 67
.line	335	loadk        r24    k8 ; k8 = 134
.line	335	loadk        r25   k67 ; k67 = 78
.line	335	loadk        r26   k16 ; k16 = 198
.line	335	loadk        r27   k68 ; k68 = 41
.line	335	loadk        r28   k69 ; k69 = 71
.line	335	loadk        r29   k70 ; k70 = 87
.line	335	loadk        r30   k71 ; k71 = 250
.line	335	loadk        r31   k72 ; k72 = 177
.line	335	loadk        r32   k73 ; k73 = 158
.line	335	call          r4    29     2
.line	335	gettable      r5    r0   k74 ; k74 = "OnCommonMemberIsSpea" (truncated)
.line	335	move          r6    r0
.line	335	call          r1     6     1
.line	335	self          r1    r0   k75 ; k75 = "AddCommonEvent"
.line	335	gettabup      r3    u0   k76 ; k76 = "EVENTTYPE_ANTSVOICE"
.line	335	gettabup      r4    u0   k77 ; k77 = "EVENTID_ANTSVOICE_ON" (truncated)
.line	335	gettable      r5    r0   k78 ; k78 = "OnMemberVoice"
.line	335	move          r6    r0
.line	335	call          r1     6     1
.line	335	self          r1    r0   k75 ; k75 = "AddCommonEvent"
.line	335	gettabup      r3    u0   k79 ; k79 = "EVENTTYPE_CHAT"
.line	335	gettabup      r4    u0   k80 ; k80 = "EVENTID_CHAT_START_P" (truncated)
.line	335	gettable      r5    r0   k81 ; k81 = "StartPlayVoiceFile"
.line	335	move          r6    r0
.line	335	call          r1     6     1
.line	335	self          r1    r0   k75 ; k75 = "AddCommonEvent"
.line	335	gettabup      r3    u0   k79 ; k79 = "EVENTTYPE_CHAT"
.line	335	gettabup      r4    u0   k82 ; k82 = "EVENTID_CHAT_STOP_PL" (truncated)
.line	335	gettable      r5    r0   k83 ; k83 = "StopPlayVoiceFile"
.line	335	move          r6    r0
.line	335	call          r1     6     1
.line	335	self          r1    r0   k75 ; k75 = "AddCommonEvent"
.line	335	gettabup      r3    u0   k76 ; k76 = "EVENTTYPE_ANTSVOICE"
.line	335	gettabup      r4    u0   k84 ; k84 = "EVENTID_ANTSVOICE_ON" (truncated)
.line	335	gettable      r5    r0   k85 ; k85 = "OnDownloadFileEnd"
.line	335	move          r6    r0
.line	335	call          r1     6     1
.line	335	self          r1    r0   k75 ; k75 = "AddCommonEvent"
.line	335	gettabup      r3    u0   k76 ; k76 = "EVENTTYPE_ANTSVOICE"
.line	335	gettabup      r4    u0   k86 ; k86 = L"EVENTID_ANTSVOICE_ON" (truncated)
.line	335	gettable      r5    r0   k87 ; k87 = "OnDownloadFileStart"
.line	335	move          r6    r0
.line	335	call          r1     6     1
.line	335	self          r1    r0   k75 ; k75 = "AddCommonEvent"
.line	335	gettabup      r3    u0   k88 ; k88 = "EVENTTYPE_INGAME_NOR" (truncated)
.line	335	gettabup      r4    u0   k89 ; k89 = "EVENTID_NPC_DIALOG_S" (truncated)
.line	335	gettable      r5    r0   k90 ; k90 = "HandleOnNPCDialogSen" (truncated)
.line	335	move          r6    r0
.line	335	call          r1     6     1
.line	335	gettabup      r1    u0    k2 ; k2 = "print"
.line	335	gettabup      r2    u0    k3 ; k3 = "bWriteLog"
.line	335	test          r2     0
.line	335	jmp            0  l202
.line	335	gettabup      r2    u0   k91 ; k91 = "table"
.line	335	gettable      r2    r2   k92 ; k92 = "concat"
.line	335	newtable      r3     1     0
.line	335	getupval      r4    u1
.line	335	loadk         r5    k4 ; k4 = 149
.line	335	loadk         r6    k5 ; k5 = 51
.line	335	loadk         r7    k6 ; k6 = 25
.line	335	loadk         r8    k7 ; k7 = 150
.line	335	loadk         r9    k8 ; k8 = 134
.line	335	loadk        r10    k9 ; k9 = 254
.line	335	loadk        r11   k10 ; k10 = 126
.line	335	loadk        r12   k11 ; k11 = 123
.line	335	loadk        r13   k12 ; k12 = 86
.line	335	loadk        r14   k13 ; k13 = 197
.line	335	loadk        r15   k14 ; k14 = 162
.line	335	loadk        r16    k7 ; k7 = 150
.line	335	loadk        r17   k15 ; k15 = 191
.line	335	loadk        r18   k16 ; k16 = 198
.line	335	loadk        r19   k17 ; k17 = 108
.line	335	loadk        r20   k18 ; k18 = 175
.line	335	loadk        r21   k19 ; k19 = 18
.line	335	loadk        r22   k20 ; k20 = 29
.line	335	loadk        r23   k21 ; k21 = 77
.line	335	loadk        r24   k22 ; k22 = 136
.line	335	loadk        r25   k23 ; k23 = 73
.line	335	loadk        r26   k24 ; k24 = 210
.line	335	loadk        r27   k25 ; k25 = 19
.line	335	loadk        r28   k26 ; k26 = 106
.line	335	loadk        r29   k27 ; k27 = 66
.line	335	loadk        r30   k28 ; k28 = 224
.line	335	loadk        r31   k29 ; k29 = 178
.line	335	loadk        r32   k14 ; k14 = 162
.line	335	loadk        r33   k30 ; k30 = 173
.line	335	loadk        r34   k16 ; k16 = 198
.line	335	loadk        r35   k31 ; k31 = 96
.line	335	loadk        r36   k32 ; k32 = 174
.line	335	loadk        r37   k93 ; k93 = 20
.line	335	loadk        r38   k49 ; k49 = 127
.line	335	loadk        r39   k94 ; k94 = 107
.line	335	loadk        r40   k95 ; k95 = 138
.line	335	loadk        r41   k96 ; k96 = 83
.line	335	loadk        r42   k24 ; k24 = 210
.line	335	loadk        r43   k19 ; k19 = 18
.line	335	loadk        r44   k53 ; k53 = 75
.line	335	call          r4    41     2
.line	335	getupval      r5    u1
.line	335	loadk         r6   k97 ; k97 = 171
.line	335	call          r5     2     0
.line	335	setlist       r3     0     1
.line	335	call          r2     2     2
.label	l202
.line	335	call          r1     2     1
.line	335	self          r1    r0   k98 ; k98 = "SendMLAIVoiceDebugIn" (truncated)
.line	335	gettabup      r3    u2   k99 ; k99 = "ClientInitSuccess"
.line	335	getupval      r4    u1
.line	335	loadk         r5   k95 ; k95 = 138
.line	335	loadk         r6  k100 ; k100 = 26
.line	335	loadk         r7  k101 ; k101 = 63
.line	335	loadk         r8  k102 ; k102 = 182
.line	335	loadk         r9  k103 ; k103 = 163
.line	335	loadk        r10  k104 ; k104 = 229
.line	335	loadk        r11  k105 ; k105 = 85
.line	335	loadk        r12  k106 ; k106 = 121
.line	335	loadk        r13  k107 ; k107 = 64
.line	335	loadk        r14  k108 ; k108 = 230
.line	335	loadk        r15   k63 ; k63 = 130
.line	335	loadk        r16  k109 ; k109 = 129
.line	335	loadk        r17   k32 ; k32 = 174
.line	335	loadk        r18  k110 ; k110 = 221
.line	335	loadk        r19   k26 ; k26 = 106
.line	335	call          r4    16     2
.line	335	call          r1     4     1
.line	335	jmp            0  l244
.label	l224
.line	335	self          r1    r0   k98 ; k98 = "SendMLAIVoiceDebugIn" (truncated)
.line	335	gettabup      r3    u2  k111 ; k111 = "VoiceInterFaceError"
.line	335	getupval      r4    u1
.line	335	loadk         r5   k95 ; k95 = 138
.line	335	loadk         r6  k100 ; k100 = 26
.line	335	loadk         r7  k101 ; k101 = 63
.line	335	loadk         r8  k102 ; k102 = 182
.line	335	loadk         r9  k103 ; k103 = 163
.line	335	loadk        r10  k104 ; k104 = 229
.line	335	loadk        r11  k105 ; k105 = 85
.line	335	loadk        r12  k106 ; k106 = 121
.line	335	loadk        r13  k107 ; k107 = 64
.line	335	loadk        r14  k108 ; k108 = 230
.line	335	loadk        r15   k63 ; k63 = 130
.line	335	loadk        r16  k109 ; k109 = 129
.line	335	loadk        r17   k32 ; k32 = 174
.line	335	loadk        r18  k110 ; k110 = 221
.line	335	loadk        r19   k26 ; k26 = 106
.line	335	call          r4    16     2
.line	335	call          r1     4     1
.label	l244
.line	335	settable      r0    k1  k112 ; k112 = true
.label	l245
.line	335	return        r0     1
.line	335	move          r0    r0
.line	335	return        r0     1

.function	main/f18

.source	null
.linedefined	356
.lastlinedefined	372
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	6	true

.constant	k0	"Client"
.constant	k1	"bHasRegistSceneEvent"
.constant	k2	"print"
.constant	k3	"bWriteLog"
.constant	k4	149
.constant	k5	51
.constant	k6	25
.constant	k7	150
.constant	k8	134
.constant	k9	254
.constant	k10	126
.constant	k11	123
.constant	k12	86
.constant	k13	197
.constant	k14	162
.constant	k15	191
.constant	k16	198
.constant	k17	108
.constant	k18	175
.constant	k19	18
.constant	k20	29
.constant	k21	77
.constant	k22	136
.constant	k23	73
.constant	k24	210
.constant	k25	19
.constant	k26	64
.constant	k27	246
.constant	k28	185
.constant	k29	130
.constant	k30	158
.constant	k31	213
.constant	k32	107
.constant	k33	180
.constant	k34	76
.constant	k35	"AntsVoiceInterface"
.constant	k36	"AddControlEvent"
.constant	k37	151
.constant	k38	17
.constant	k39	11
.constant	k40	186
.constant	k41	163
.constant	k42	226
.constant	k43	119
.constant	k44	93
.constant	k45	168
.constant	k46	133
.constant	k47	138
.constant	k48	250
.constant	k49	87
.constant	k50	164
.constant	k51	78
.constant	k52	32
.constant	k53	142
.constant	k54	205
.constant	k55	5
.constant	k56	248
.constant	k57	"OnSessionForAIInfoCallback"
.constant	k58	154
.constant	k59	26
.constant	k60	62
.constant	k61	176
.constant	k62	244
.constant	k63	88
.constant	k64	104
.constant	k65	241
.constant	k66	166
.constant	k67	131
.constant	k68	220
.constant	k69	112
.constant	k70	"OnBeforeOperation"
.constant	k71	14
.constant	k72	242
.constant	k73	114
.constant	k74	75
.constant	k75	200
.constant	k76	129
.constant	k77	174
.constant	k78	221
.constant	k79	106
.constant	k80	"OnAntsVoiceEvent"
.constant	k81	10
.constant	k82	140
.constant	k83	132
.constant	k84	194
.constant	k85	68
.constant	k86	109
.constant	k87	81
.constant	k88	247
.constant	k89	167
.constant	k90	214
.constant	k91	171
.constant	k92	35
.constant	k93	74
.constant	k94	67
.constant	k95	202
.constant	k96	"OnRSTSSubtitleCallback"
.constant	k97	95
.constant	k98	153
.constant	k99	122
.constant	k100	28
.constant	k101	92
.constant	k102	82
.constant	k103	36
.constant	k104	79
.constant	k105	255
.constant	k106	181
.constant	k107	184
.constant	k108	"OnRSTSSubtitleASRStartCallback"
.constant	k109	"AddCommonEvent"
.constant	k110	"EVENTTYPE_INGAME"
.constant	k111	"EVENTID_INGAME_CHANGE_STT_STATE"
.constant	k112	"OnSTTStateChange"
.constant	k113	"table"
.constant	k114	"concat"
.constant	k115	115
.constant	k116	24
.constant	k117	172
.constant	k118	69
.constant	k119	20
.constant	k120	12
.constant	k121	"SendMLAIVoiceDebugInfo"
.constant	k122	"VoiceInterFaceError"
.constant	k123	63
.constant	k124	182
.constant	k125	229
.constant	k126	237
.constant	k127	178
.constant	k128	189
.constant	k129	190
.constant	k130	true

.line	356	gettabup      r1    u0    k0 ; k0 = "Client"
.line	356	test          r1     0
.line	356	jmp            0  l278
.line	356	gettable      r1    r0    k1 ; k1 = "bHasRegistSceneEvent"
.line	356	test          r1     1
.line	356	jmp            0  l278
.line	356	gettabup      r1    u0    k2 ; k2 = "print"
.line	356	gettabup      r2    u0    k3 ; k3 = "bWriteLog"
.line	356	test          r2     0
.line	356	jmp            0   l46
.line	356	getupval      r2    u1
.line	356	loadk         r3    k4 ; k4 = 149
.line	356	loadk         r4    k5 ; k5 = 51
.line	356	loadk         r5    k6 ; k6 = 25
.line	356	loadk         r6    k7 ; k7 = 150
.line	356	loadk         r7    k8 ; k8 = 134
.line	356	loadk         r8    k9 ; k9 = 254
.line	356	loadk         r9   k10 ; k10 = 126
.line	356	loadk        r10   k11 ; k11 = 123
.line	356	loadk        r11   k12 ; k12 = 86
.line	356	loadk        r12   k13 ; k13 = 197
.line	356	loadk        r13   k14 ; k14 = 162
.line	356	loadk        r14    k7 ; k7 = 150
.line	356	loadk        r15   k15 ; k15 = 191
.line	356	loadk        r16   k16 ; k16 = 198
.line	356	loadk        r17   k17 ; k17 = 108
.line	356	loadk        r18   k18 ; k18 = 175
.line	356	loadk        r19   k19 ; k19 = 18
.line	356	loadk        r20   k20 ; k20 = 29
.line	356	loadk        r21   k21 ; k21 = 77
.line	356	loadk        r22   k22 ; k22 = 136
.line	356	loadk        r23   k23 ; k23 = 73
.line	356	loadk        r24   k24 ; k24 = 210
.line	356	loadk        r25   k25 ; k25 = 19
.line	356	loadk        r26   k11 ; k11 = 123
.line	356	loadk        r27   k26 ; k26 = 64
.line	356	loadk        r28   k27 ; k27 = 246
.line	356	loadk        r29   k28 ; k28 = 185
.line	356	loadk        r30   k29 ; k29 = 130
.line	356	loadk        r31   k30 ; k30 = 158
.line	356	loadk        r32   k31 ; k31 = 213
.line	356	loadk        r33   k32 ; k32 = 107
.line	356	loadk        r34   k33 ; k33 = 180
.line	356	loadk        r35   k34 ; k34 = 76
.line	356	call          r2    34     2
.label	l46
.line	356	call          r1     2     1
.line	356	gettable      r1    r0   k35 ; k35 = "AntsVoiceInterface"
.line	356	test          r1     0
.line	356	jmp            0  l256
.line	356	self          r1    r0   k36 ; k36 = "AddControlEvent"
.line	356	gettable      r3    r0   k35 ; k35 = "AntsVoiceInterface"
.line	356	getupval      r4    u1
.line	356	loadk         r5   k37 ; k37 = 151
.line	356	loadk         r6   k38 ; k38 = 17
.line	356	loadk         r7   k39 ; k39 = 11
.line	356	loadk         r8   k40 ; k40 = 186
.line	356	loadk         r9   k41 ; k41 = 163
.line	356	loadk        r10   k42 ; k42 = 226
.line	356	loadk        r11   k10 ; k10 = 126
.line	356	loadk        r12   k43 ; k43 = 119
.line	356	loadk        r13   k44 ; k44 = 93
.line	356	loadk        r14   k13 ; k13 = 197
.line	356	loadk        r15   k45 ; k45 = 168
.line	356	loadk        r16   k46 ; k46 = 133
.line	356	loadk        r17   k47 ; k47 = 138
.line	356	loadk        r18   k48 ; k48 = 250
.line	356	loadk        r19   k49 ; k49 = 87
.line	356	loadk        r20   k50 ; k50 = 164
.line	356	loadk        r21   k51 ; k51 = 78
.line	356	loadk        r22   k52 ; k52 = 32
.line	356	loadk        r23   k32 ; k32 = 107
.line	356	loadk        r24   k53 ; k53 = 142
.line	356	loadk        r25   k34 ; k34 = 76
.line	356	loadk        r26   k54 ; k54 = 205
.line	356	loadk        r27   k55 ; k55 = 5
.line	356	loadk        r28   k23 ; k23 = 73
.line	356	loadk        r29   k26 ; k26 = 64
.line	356	loadk        r30   k56 ; k56 = 248
.line	356	call          r4    27     2
.line	356	gettable      r5    r0   k57 ; k57 = "OnSessionForAIInfoCa" (truncated)
.line	356	move          r6    r0
.line	356	call          r1     6     1
.line	356	self          r1    r0   k36 ; k36 = "AddControlEvent"
.line	356	gettable      r3    r0   k35 ; k35 = "AntsVoiceInterface"
.line	356	getupval      r4    u1
.line	356	loadk         r5   k58 ; k58 = 154
.line	356	loadk         r6   k59 ; k59 = 26
.line	356	loadk         r7   k60 ; k60 = 62
.line	356	loadk         r8   k61 ; k61 = 176
.line	356	loadk         r9   k14 ; k14 = 162
.line	356	loadk        r10   k62 ; k62 = 244
.line	356	loadk        r11   k63 ; k63 = 88
.line	356	loadk        r12   k64 ; k64 = 104
.line	356	loadk        r13   k12 ; k12 = 86
.line	356	loadk        r14   k65 ; k65 = 241
.line	356	loadk        r15   k66 ; k66 = 166
.line	356	loadk        r16   k67 ; k67 = 131
.line	356	loadk        r17   k14 ; k14 = 162
.line	356	loadk        r18   k68 ; k68 = 220
.line	356	loadk        r19   k69 ; k69 = 112
.line	356	call          r4    16     2
.line	356	gettable      r5    r0   k70 ; k70 = "OnBeforeOperation"
.line	356	move          r6    r0
.line	356	call          r1     6     1
.line	356	self          r1    r0   k36 ; k36 = "AddControlEvent"
.line	356	gettable      r3    r0   k35 ; k35 = "AntsVoiceInterface"
.line	356	getupval      r4    u1
.line	356	loadk         r5   k37 ; k37 = 151
.line	356	loadk         r6   k38 ; k38 = 17
.line	356	loadk         r7   k71 ; k71 = 14
.line	356	loadk         r8   k61 ; k61 = 176
.line	356	loadk         r9   k28 ; k28 = 185
.line	356	loadk        r10   k72 ; k72 = 242
.line	356	loadk        r11   k73 ; k73 = 114
.line	356	loadk        r12   k74 ; k74 = 75
.line	356	loadk        r13   k43 ; k43 = 119
.line	356	loadk        r14   k75 ; k75 = 200
.line	356	loadk        r15   k29 ; k29 = 130
.line	356	loadk        r16   k76 ; k76 = 129
.line	356	loadk        r17   k77 ; k77 = 174
.line	356	loadk        r18   k78 ; k78 = 221
.line	356	loadk        r19   k79 ; k79 = 106
.line	356	call          r4    16     2
.line	356	gettable      r5    r0   k80 ; k80 = "OnAntsVoiceEvent"
.line	356	move          r6    r0
.line	356	call          r1     6     1
.line	356	self          r1    r0   k36 ; k36 = "AddControlEvent"
.line	356	gettable      r3    r0   k35 ; k35 = "AntsVoiceInterface"
.line	356	getupval      r4    u1
.line	356	loadk         r5   k37 ; k37 = 151
.line	356	loadk         r6   k38 ; k38 = 17
.line	356	loadk         r7   k81 ; k81 = 10
.line	356	loadk         r8   k82 ; k82 = 140
.line	356	loadk         r9   k83 ; k83 = 132
.line	356	loadk        r10   k84 ; k84 = 194
.line	356	loadk        r11   k85 ; k85 = 68
.line	356	loadk        r12   k86 ; k86 = 109
.line	356	loadk        r13   k87 ; k87 = 81
.line	356	loadk        r14   k88 ; k88 = 247
.line	356	loadk        r15   k77 ; k77 = 174
.line	356	loadk        r16   k67 ; k67 = 131
.line	356	loadk        r17   k89 ; k89 = 167
.line	356	loadk        r18   k90 ; k90 = 214
.line	356	loadk        r19   k44 ; k44 = 93
.line	356	loadk        r20   k91 ; k91 = 171
.line	356	loadk        r21   k85 ; k85 = 68
.line	356	loadk        r22   k92 ; k92 = 35
.line	356	loadk        r23   k93 ; k93 = 74
.line	356	loadk        r24   k53 ; k53 = 142
.line	356	loadk        r25   k94 ; k94 = 67
.line	356	loadk        r26   k95 ; k95 = 202
.line	356	call          r4    23     2
.line	356	gettable      r5    r0   k96 ; k96 = "OnRSTSSubtitleCallba" (truncated)
.line	356	move          r6    r0
.line	356	call          r1     6     1
.line	356	self          r1    r0   k36 ; k36 = "AddControlEvent"
.line	356	gettable      r3    r0   k35 ; k35 = "AntsVoiceInterface"
.line	356	getupval      r4    u1
.line	356	loadk         r5   k37 ; k37 = 151
.line	356	loadk         r6   k38 ; k38 = 17
.line	356	loadk         r7   k81 ; k81 = 10
.line	356	loadk         r8   k82 ; k82 = 140
.line	356	loadk         r9   k83 ; k83 = 132
.line	356	loadk        r10   k84 ; k84 = 194
.line	356	loadk        r11   k85 ; k85 = 68
.line	356	loadk        r12   k86 ; k86 = 109
.line	356	loadk        r13   k87 ; k87 = 81
.line	356	loadk        r14   k88 ; k88 = 247
.line	356	loadk        r15   k77 ; k77 = 174
.line	356	loadk        r16   k67 ; k67 = 131
.line	356	loadk        r17   k89 ; k89 = 167
.line	356	loadk        r18   k90 ; k90 = 214
.line	356	loadk        r19   k97 ; k97 = 95
.line	356	loadk        r20   k98 ; k98 = 153
.line	356	loadk        r21   k99 ; k99 = 122
.line	356	loadk        r22  k100 ; k100 = 28
.line	356	loadk        r23  k101 ; k101 = 92
.line	356	loadk        r24   k53 ; k53 = 142
.line	356	loadk        r25  k102 ; k102 = 82
.line	356	loadk        r26   k31 ; k31 = 213
.line	356	loadk        r27  k103 ; k103 = 36
.line	356	loadk        r28   k23 ; k23 = 73
.line	356	loadk        r29  k104 ; k104 = 79
.line	356	loadk        r30  k105 ; k105 = 255
.line	356	loadk        r31  k106 ; k106 = 181
.line	356	loadk        r32    k8 ; k8 = 134
.line	356	loadk        r33  k107 ; k107 = 184
.line	356	loadk        r34   k75 ; k75 = 200
.line	356	call          r4    31     2
.line	356	gettable      r5    r0  k108 ; k108 = "OnRSTSSubtitleASRSta" (truncated)
.line	356	move          r6    r0
.line	356	call          r1     6     1
.line	356	self          r1    r0  k109 ; k109 = "AddCommonEvent"
.line	356	gettabup      r3    u0  k110 ; k110 = "EVENTTYPE_INGAME"
.line	356	gettabup      r4    u0  k111 ; k111 = "EVENTID_INGAME_CHANG" (truncated)
.line	356	gettable      r5    r0  k112 ; k112 = "OnSTTStateChange"
.line	356	move          r6    r0
.line	356	call          r1     6     1
.line	356	gettabup      r1    u0    k2 ; k2 = "print"
.line	356	gettabup      r2    u0    k3 ; k3 = "bWriteLog"
.line	356	test          r2     0
.line	356	jmp            0  l254
.line	356	gettabup      r2    u0  k113 ; k113 = "table"
.line	356	gettable      r2    r2  k114 ; k114 = "concat"
.line	356	newtable      r3     1     0
.line	356	getupval      r4    u1
.line	356	loadk         r5    k4 ; k4 = 149
.line	356	loadk         r6    k5 ; k5 = 51
.line	356	loadk         r7    k6 ; k6 = 25
.line	356	loadk         r8    k7 ; k7 = 150
.line	356	loadk         r9    k8 ; k8 = 134
.line	356	loadk        r10    k9 ; k9 = 254
.line	356	loadk        r11   k10 ; k10 = 126
.line	356	loadk        r12   k11 ; k11 = 123
.line	356	loadk        r13   k12 ; k12 = 86
.line	356	loadk        r14   k13 ; k13 = 197
.line	356	loadk        r15   k14 ; k14 = 162
.line	356	loadk        r16    k7 ; k7 = 150
.line	356	loadk        r17   k15 ; k15 = 191
.line	356	loadk        r18   k16 ; k16 = 198
.line	356	loadk        r19   k17 ; k17 = 108
.line	356	loadk        r20   k18 ; k18 = 175
.line	356	loadk        r21   k19 ; k19 = 18
.line	356	loadk        r22   k20 ; k20 = 29
.line	356	loadk        r23   k21 ; k21 = 77
.line	356	loadk        r24   k22 ; k22 = 136
.line	356	loadk        r25   k23 ; k23 = 73
.line	356	loadk        r26   k24 ; k24 = 210
.line	356	loadk        r27   k25 ; k25 = 19
.line	356	loadk        r28   k11 ; k11 = 123
.line	356	loadk        r29   k26 ; k26 = 64
.line	356	loadk        r30   k27 ; k27 = 246
.line	356	loadk        r31   k28 ; k28 = 185
.line	356	loadk        r32   k29 ; k29 = 130
.line	356	loadk        r33   k30 ; k30 = 158
.line	356	loadk        r34   k31 ; k31 = 213
.line	356	loadk        r35   k32 ; k32 = 107
.line	356	loadk        r36   k33 ; k33 = 180
.line	356	loadk        r37   k34 ; k34 = 76
.line	356	loadk        r38  k115 ; k115 = 115
.line	356	loadk        r39  k116 ; k116 = 24
.line	356	loadk        r40  k117 ; k117 = 172
.line	356	loadk        r41  k118 ; k118 = 69
.line	356	loadk        r42   k24 ; k24 = 210
.line	356	loadk        r43  k119 ; k119 = 20
.line	356	loadk        r44   k44 ; k44 = 93
.line	356	call          r4    41     2
.line	356	getupval      r5    u1
.line	356	loadk         r6   k91 ; k91 = 171
.line	356	loadk         r7  k120 ; k120 = 12
.line	356	call          r5     3     0
.line	356	setlist       r3     0     1
.line	356	call          r2     2     2
.label	l254
.line	356	call          r1     2     1
.line	356	jmp            0  l277
.label	l256
.line	356	self          r1    r0  k121 ; k121 = "SendMLAIVoiceDebugIn" (truncated)
.line	356	gettabup      r3    u2  k122 ; k122 = "VoiceInterFaceError"
.line	356	getupval      r4    u1
.line	356	loadk         r5   k47 ; k47 = 138
.line	356	loadk         r6   k59 ; k59 = 26
.line	356	loadk         r7  k123 ; k123 = 63
.line	356	loadk         r8  k124 ; k124 = 182
.line	356	loadk         r9   k41 ; k41 = 163
.line	356	loadk        r10  k125 ; k125 = 229
.line	356	loadk        r11   k85 ; k85 = 68
.line	356	loadk        r12   k11 ; k11 = 123
.line	356	loadk        r13   k12 ; k12 = 86
.line	356	loadk        r14  k126 ; k126 = 237
.line	356	loadk        r15   k14 ; k14 = 162
.line	356	loadk        r16  k127 ; k127 = 178
.line	356	loadk        r17  k128 ; k128 = 189
.line	356	loadk        r18   k90 ; k90 = 214
.line	356	loadk        r19   k69 ; k69 = 112
.line	356	loadk        r20  k129 ; k129 = 190
.line	356	call          r4    17     2
.line	356	call          r1     4     1
.label	l277
.line	356	settable      r0    k1  k130 ; k130 = true
.label	l278
.line	356	return        r0     1
.line	356	move          r0    r0
.line	356	move          r0    r0
.line	356	return        r0     1

.function	main/f19

.source	null
.linedefined	374
.lastlinedefined	389
.numparams	1
.is_vararg	0
.maxstacksize	37

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"bHasRegistBaseEvent"
.constant	k2	"print"
.constant	k3	"bWriteLog"
.constant	k4	149
.constant	k5	51
.constant	k6	25
.constant	k7	150
.constant	k8	134
.constant	k9	254
.constant	k10	126
.constant	k11	123
.constant	k12	86
.constant	k13	197
.constant	k14	162
.constant	k15	191
.constant	k16	198
.constant	k17	108
.constant	k18	175
.constant	k19	18
.constant	k20	26
.constant	k21	70
.constant	k22	189
.constant	k23	69
.constant	k24	14
.constant	k25	91
.constant	k26	87
.constant	k27	209
.constant	k28	182
.constant	k29	148
.constant	k30	190
.constant	k31	230
.constant	k32	120
.constant	k33	43
.constant	k34	"AntsVoiceInterface"
.constant	k35	"RemoveControlEvent"
.constant	k36	151
.constant	k37	17
.constant	k38	28
.constant	k39	186
.constant	k40	188
.constant	k41	248
.constant	k42	97
.constant	k43	125
.constant	k44	65
.constant	k45	199
.constant	k46	166
.constant	k47	131
.constant	k48	170
.constant	k49	240
.constant	k50	127
.constant	k51	68
.constant	k52	45
.constant	k53	73
.constant	k54	140
.constant	k55	75
.constant	k56	155
.constant	k57	16
.constant	k58	53
.constant	k59	178
.constant	k60	255
.constant	k61	90
.constant	k62	94
.constant	k63	225
.constant	k64	133
.constant	k65	130
.constant	k66	192
.constant	k67	77
.constant	k68	46
.constant	k69	67
.constant	k70	78
.constant	k71	41
.constant	k72	71
.constant	k73	250
.constant	k74	177
.constant	k75	158
.constant	k76	"RemoveCommonEvent"
.constant	k77	"EVENTTYPE_ANTSVOICE"
.constant	k78	"EVENTID_ANTSVOICE_ON_MEMBER_VOICE"
.constant	k79	"EVENTTYPE_CHAT"
.constant	k80	"EVENTID_CHAT_START_PLAY_RECORD_FILE"
.constant	k81	"EVENTID_CHAT_STOP_PLAY_RECORD_FILE"
.constant	k82	"EVENTID_ANTSVOICE_ON_DOWNLOAD_FILEID_END"
.constant	k83	L"EVENTID_ANTSVOICE_ON_DOWNLOAD_FILEID_START"
.constant	k84	"EVENTTYPE_INGAME_NORMAL"
.constant	k85	"EVENTID_NPC_DIALOG_SEND_TEXT"
.constant	k86	nil

.line	374	gettabup      r1    u0    k0 ; k0 = "Client"
.line	374	test          r1     0
.line	374	jmp            0  l135
.line	374	gettable      r1    r0    k1 ; k1 = "bHasRegistBaseEvent"
.line	374	test          r1     0
.line	374	jmp            0  l135
.line	374	gettabup      r1    u0    k2 ; k2 = "print"
.line	374	gettabup      r2    u0    k3 ; k3 = "bWriteLog"
.line	374	test          r2     0
.line	374	jmp            0   l47
.line	374	getupval      r2    u1
.line	374	loadk         r3    k4 ; k4 = 149
.line	374	loadk         r4    k5 ; k5 = 51
.line	374	loadk         r5    k6 ; k6 = 25
.line	374	loadk         r6    k7 ; k7 = 150
.line	374	loadk         r7    k8 ; k8 = 134
.line	374	loadk         r8    k9 ; k9 = 254
.line	374	loadk         r9   k10 ; k10 = 126
.line	374	loadk        r10   k11 ; k11 = 123
.line	374	loadk        r11   k12 ; k12 = 86
.line	374	loadk        r12   k13 ; k13 = 197
.line	374	loadk        r13   k14 ; k14 = 162
.line	374	loadk        r14    k7 ; k7 = 150
.line	374	loadk        r15   k15 ; k15 = 191
.line	374	loadk        r16   k16 ; k16 = 198
.line	374	loadk        r17   k17 ; k17 = 108
.line	374	loadk        r18   k18 ; k18 = 175
.line	374	loadk        r19   k19 ; k19 = 18
.line	374	loadk        r20   k20 ; k20 = 26
.line	374	loadk        r21   k21 ; k21 = 70
.line	374	loadk        r22   k22 ; k22 = 189
.line	374	loadk        r23   k23 ; k23 = 69
.line	374	loadk        r24   k16 ; k16 = 198
.line	374	loadk        r25   k24 ; k24 = 14
.line	374	loadk        r26   k25 ; k25 = 91
.line	374	loadk        r27   k26 ; k26 = 87
.line	374	loadk        r28   k27 ; k27 = 209
.line	374	loadk        r29   k28 ; k28 = 182
.line	374	loadk        r30   k29 ; k29 = 148
.line	374	loadk        r31   k30 ; k30 = 190
.line	374	loadk        r32   k31 ; k31 = 230
.line	374	loadk        r33   k32 ; k32 = 120
.line	374	loadk        r34   k15 ; k15 = 191
.line	374	loadk        r35   k12 ; k12 = 86
.line	374	loadk        r36   k33 ; k33 = 43
.line	374	call          r2    35     2
.label	l47
.line	374	call          r1     2     1
.line	374	gettable      r1    r0   k34 ; k34 = "AntsVoiceInterface"
.line	374	test          r1     0
.line	374	jmp            0  l134
.line	374	self          r1    r0   k35 ; k35 = "RemoveControlEvent"
.line	374	gettable      r3    r0   k34 ; k34 = "AntsVoiceInterface"
.line	374	getupval      r4    u1
.line	374	loadk         r5   k36 ; k36 = 151
.line	374	loadk         r6   k37 ; k37 = 17
.line	374	loadk         r7   k38 ; k38 = 28
.line	374	loadk         r8   k39 ; k39 = 186
.line	374	loadk         r9   k40 ; k40 = 188
.line	374	loadk        r10   k41 ; k41 = 248
.line	374	loadk        r11   k42 ; k42 = 97
.line	374	loadk        r12   k43 ; k43 = 125
.line	374	loadk        r13   k44 ; k44 = 65
.line	374	loadk        r14   k45 ; k45 = 199
.line	374	loadk        r15   k46 ; k46 = 166
.line	374	loadk        r16   k47 ; k47 = 131
.line	374	loadk        r17   k48 ; k48 = 170
.line	374	loadk        r18   k49 ; k49 = 240
.line	374	loadk        r19   k50 ; k50 = 127
.line	374	loadk        r20   k46 ; k46 = 166
.line	374	loadk        r21   k51 ; k51 = 68
.line	374	loadk        r22   k52 ; k52 = 45
.line	374	loadk        r23   k53 ; k53 = 73
.line	374	loadk        r24   k54 ; k54 = 140
.line	374	loadk        r25   k55 ; k55 = 75
.line	374	call          r4    22     2
.line	374	call          r1     4     1
.line	374	self          r1    r0   k35 ; k35 = "RemoveControlEvent"
.line	374	gettable      r3    r0   k34 ; k34 = "AntsVoiceInterface"
.line	374	getupval      r4    u1
.line	374	loadk         r5   k56 ; k56 = 155
.line	374	loadk         r6   k57 ; k57 = 16
.line	374	loadk         r7   k58 ; k58 = 53
.line	374	loadk         r8   k59 ; k59 = 178
.line	374	loadk         r9   k15 ; k15 = 191
.line	374	loadk        r10   k60 ; k60 = 255
.line	374	loadk        r11   k61 ; k61 = 90
.line	374	loadk        r12   k43 ; k43 = 125
.line	374	loadk        r13   k62 ; k62 = 94
.line	374	loadk        r14   k63 ; k63 = 225
.line	374	loadk        r15   k14 ; k14 = 162
.line	374	loadk        r16   k64 ; k64 = 133
.line	374	loadk        r17   k65 ; k65 = 130
.line	374	loadk        r18   k66 ; k66 = 192
.line	374	loadk        r19   k67 ; k67 = 77
.line	374	loadk        r20   k39 ; k39 = 186
.line	374	loadk        r21   k67 ; k67 = 77
.line	374	loadk        r22   k68 ; k68 = 46
.line	374	loadk        r23   k69 ; k69 = 67
.line	374	loadk        r24    k8 ; k8 = 134
.line	374	loadk        r25   k70 ; k70 = 78
.line	374	loadk        r26   k16 ; k16 = 198
.line	374	loadk        r27   k71 ; k71 = 41
.line	374	loadk        r28   k72 ; k72 = 71
.line	374	loadk        r29   k26 ; k26 = 87
.line	374	loadk        r30   k73 ; k73 = 250
.line	374	loadk        r31   k74 ; k74 = 177
.line	374	loadk        r32   k75 ; k75 = 158
.line	374	call          r4    29     2
.line	374	call          r1     4     1
.line	374	self          r1    r0   k76 ; k76 = "RemoveCommonEvent"
.line	374	gettabup      r3    u0   k77 ; k77 = "EVENTTYPE_ANTSVOICE"
.line	374	gettabup      r4    u0   k78 ; k78 = "EVENTID_ANTSVOICE_ON" (truncated)
.line	374	call          r1     4     1
.line	374	self          r1    r0   k76 ; k76 = "RemoveCommonEvent"
.line	374	gettabup      r3    u0   k79 ; k79 = "EVENTTYPE_CHAT"
.line	374	gettabup      r4    u0   k80 ; k80 = "EVENTID_CHAT_START_P" (truncated)
.line	374	call          r1     4     1
.line	374	self          r1    r0   k76 ; k76 = "RemoveCommonEvent"
.line	374	gettabup      r3    u0   k79 ; k79 = "EVENTTYPE_CHAT"
.line	374	gettabup      r4    u0   k81 ; k81 = "EVENTID_CHAT_STOP_PL" (truncated)
.line	374	call          r1     4     1
.line	374	self          r1    r0   k76 ; k76 = "RemoveCommonEvent"
.line	374	gettabup      r3    u0   k77 ; k77 = "EVENTTYPE_ANTSVOICE"
.line	374	gettabup      r4    u0   k82 ; k82 = "EVENTID_ANTSVOICE_ON" (truncated)
.line	374	call          r1     4     1
.line	374	self          r1    r0   k76 ; k76 = "RemoveCommonEvent"
.line	374	gettabup      r3    u0   k77 ; k77 = "EVENTTYPE_ANTSVOICE"
.line	374	gettabup      r4    u0   k83 ; k83 = L"EVENTID_ANTSVOICE_ON" (truncated)
.line	374	call          r1     4     1
.line	374	self          r1    r0   k76 ; k76 = "RemoveCommonEvent"
.line	374	gettabup      r3    u0   k84 ; k84 = "EVENTTYPE_INGAME_NOR" (truncated)
.line	374	gettabup      r4    u0   k85 ; k85 = "EVENTID_NPC_DIALOG_S" (truncated)
.line	374	call          r1     4     1
.label	l134
.line	374	settable      r0    k1   k86 ; k86 = nil
.label	l135
.line	374	return        r0     1
.line	374	move          r0    r0
.line	374	move          r0    r0
.line	374	return        r0     1

.function	main/f20

.source	null
.linedefined	391
.lastlinedefined	393
.numparams	1
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	0	false

.constant	k0	"bOpenMLAIVoice"
.constant	k1	true
.constant	k2	0
.constant	k3	"tonumber"
.constant	k4	"DialogTargetUID"

.line	391	gettable      r1    r0    k0 ; k0 = "bOpenMLAIVoice"
.line	391	eq             0    r1    k1 ; k1 = true
.line	391	jmp            0   l12
.line	391	gettabup      r1    u0    k3 ; k3 = "tonumber"
.line	391	gettable      r2    r0    k4 ; k4 = "DialogTargetUID"
.line	391	call          r1     2     2
.line	391	test          r1     1
.line	391	jmp            0   l10
.line	391	loadk         r1    k2 ; k2 = 0
.label	l10
.line	391	lt             1    k2    r1 ; k2 = 0
.line	391	jmp            0   l13
.label	l12
.line	391	loadbool      r1     0     1
.label	l13
.line	391	loadbool      r1     1     0
.line	391	return        r1     2
.line	391	return        r0     1
.line	391	move          r0    r0
.line	391	move          r0    r0
.line	391	return        r0     1

.function	main/f21

.source	null
.linedefined	395
.lastlinedefined	406
.numparams	2
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"_IsAIOwner"
.constant	k2	"print"
.constant	k3	"bWriteLog"
.constant	k4	"string"
.constant	k5	"format"
.constant	k6	"table"
.constant	k7	"concat"
.constant	k8	149
.constant	k9	51
.constant	k10	25
.constant	k11	150
.constant	k12	134
.constant	k13	254
.constant	k14	126
.constant	k15	123
.constant	k16	86
.constant	k17	197
.constant	k18	162
.constant	k19	191
.constant	k20	198
.constant	k21	108
.constant	k22	175
.constant	k23	18
.constant	k24	16
.constant	k25	122
.constant	k26	138
.constant	k27	70
.constant	k28	211
.constant	k29	2
.constant	k30	91
.constant	k31	75
.constant	k32	167
.constant	k33	139
.constant	k34	178
.constant	k35	205
.constant	k36	101
.constant	k37	159
.constant	k38	78
.constant	k39	58
.constant	k40	28
.constant	k41	145
.constant	k42	21
.constant	k43	119
.constant	k44	17
.constant	k45	61
.constant	k46	173
.constant	k47	234
.constant	k48	180
.constant	k49	100
.constant	k50	52
.constant	k51	19
.constant	k52	199
.constant	k53	174
.constant	k54	220
.constant	k55	121
.constant	k56	158
.constant	k57	73
.constant	k58	79
.constant	k59	84
.constant	k60	244
.constant	k61	46
.constant	k62	182
.constant	k63	164
.constant	k64	203
.constant	k65	251
.constant	k66	230
.constant	k67	118
.constant	k68	74
.constant	k69	62
.constant	k70	218
.constant	k71	67
.constant	k72	"tostring"
.constant	k73	"DialogTargetUID"
.constant	k74	"RegistUplinkEvent"
.constant	k75	"UnRegistUplinkEvent"

.line	395	gettabup      r2    u0    k0 ; k0 = "Client"
.line	395	test          r2     1
.line	395	jmp            0    l5
.line	395	return        r0     1
.label	l5
.line	395	self          r2    r0    k1 ; k1 = "_IsAIOwner"
.line	395	call          r2     2     2
.line	395	gettabup      r3    u0    k2 ; k2 = "print"
.line	395	gettabup      r4    u0    k3 ; k3 = "bWriteLog"
.line	395	test          r4     0
.line	395	jmp            0  l109
.line	395	gettabup      r4    u0    k4 ; k4 = "string"
.line	395	gettable      r4    r4    k5 ; k5 = "format"
.line	395	gettabup      r5    u0    k6 ; k6 = "table"
.line	395	gettable      r5    r5    k7 ; k7 = "concat"
.line	395	newtable      r6     1     0
.line	395	getupval      r7    u1
.line	395	loadk         r8    k8 ; k8 = 149
.line	395	loadk         r9    k9 ; k9 = 51
.line	395	loadk        r10   k10 ; k10 = 25
.line	395	loadk        r11   k11 ; k11 = 150
.line	395	loadk        r12   k12 ; k12 = 134
.line	395	loadk        r13   k13 ; k13 = 254
.line	395	loadk        r14   k14 ; k14 = 126
.line	395	loadk        r15   k15 ; k15 = 123
.line	395	loadk        r16   k16 ; k16 = 86
.line	395	loadk        r17   k17 ; k17 = 197
.line	395	loadk        r18   k18 ; k18 = 162
.line	395	loadk        r19   k11 ; k11 = 150
.line	395	loadk        r20   k19 ; k19 = 191
.line	395	loadk        r21   k20 ; k20 = 198
.line	395	loadk        r22   k21 ; k21 = 108
.line	395	loadk        r23   k22 ; k22 = 175
.line	395	loadk        r24   k23 ; k23 = 18
.line	395	loadk        r25   k24 ; k24 = 16
.line	395	loadk        r26   k25 ; k25 = 122
.line	395	loadk        r27   k26 ; k26 = 138
.line	395	loadk        r28   k27 ; k27 = 70
.line	395	loadk        r29   k28 ; k28 = 211
.line	395	loadk        r30   k29 ; k29 = 2
.line	395	loadk        r31   k30 ; k30 = 91
.line	395	loadk        r32   k31 ; k31 = 75
.line	395	loadk        r33   k20 ; k20 = 198
.line	395	loadk        r34   k32 ; k32 = 167
.line	395	loadk        r35   k33 ; k33 = 139
.line	395	loadk        r36   k34 ; k34 = 178
.line	395	loadk        r37   k35 ; k35 = 205
.line	395	loadk        r38   k36 ; k36 = 101
.line	395	loadk        r39   k37 ; k37 = 159
.line	395	loadk        r40   k38 ; k38 = 78
.line	395	loadk        r41   k39 ; k39 = 58
.line	395	loadk        r42   k16 ; k16 = 86
.line	395	loadk        r43   k33 ; k33 = 139
.line	395	loadk        r44   k40 ; k40 = 28
.line	395	loadk        r45   k41 ; k41 = 145
.line	395	loadk        r46   k42 ; k42 = 21
.line	395	loadk        r47   k43 ; k43 = 119
.line	395	call          r7    41     2
.line	395	getupval      r8    u1
.line	395	loadk         r9   k22 ; k22 = 175
.line	395	loadk        r10   k44 ; k44 = 17
.line	395	loadk        r11   k45 ; k45 = 61
.line	395	loadk        r12   k46 ; k46 = 173
.line	395	loadk        r13   k47 ; k47 = 234
.line	395	loadk        r14   k48 ; k48 = 180
.line	395	loadk        r15   k49 ; k49 = 100
.line	395	loadk        r16   k50 ; k50 = 52
.line	395	loadk        r17   k51 ; k51 = 19
.line	395	loadk        r18   k52 ; k52 = 199
.line	395	loadk        r19   k53 ; k53 = 174
.line	395	loadk        r20   k11 ; k11 = 150
.line	395	loadk        r21   k32 ; k32 = 167
.line	395	loadk        r22   k54 ; k54 = 220
.line	395	loadk        r23   k55 ; k55 = 121
.line	395	loadk        r24   k56 ; k56 = 158
.line	395	loadk        r25   k57 ; k57 = 73
.line	395	loadk        r26   k45 ; k45 = 61
.line	395	loadk        r27   k58 ; k58 = 79
.line	395	loadk        r28   k26 ; k26 = 138
.line	395	loadk        r29   k59 ; k59 = 84
.line	395	loadk        r30   k60 ; k60 = 244
.line	395	loadk        r31   k61 ; k61 = 46
.line	395	loadk        r32   k21 ; k21 = 108
.line	395	loadk        r33   k10 ; k10 = 25
.line	395	loadk        r34   k62 ; k62 = 182
.line	395	loadk        r35   k63 ; k63 = 164
.line	395	loadk        r36   k64 ; k64 = 203
.line	395	loadk        r37   k65 ; k65 = 251
.line	395	loadk        r38   k66 ; k66 = 230
.line	395	loadk        r39   k67 ; k67 = 118
.line	395	loadk        r40   k53 ; k53 = 174
.line	395	loadk        r41   k68 ; k68 = 74
.line	395	loadk        r42   k69 ; k69 = 62
.line	395	loadk        r43   k29 ; k29 = 2
.line	395	loadk        r44   k70 ; k70 = 218
.line	395	loadk        r45   k71 ; k71 = 67
.line	395	call          r8    38     0
.line	395	setlist       r6     0     1
.line	395	call          r5     2     2
.line	395	gettabup      r6    u0   k72 ; k72 = "tostring"
.line	395	move          r7    r2
.line	395	call          r6     2     2
.line	395	gettabup      r7    u0   k72 ; k72 = "tostring"
.line	395	gettable      r8    r0   k73 ; k73 = "DialogTargetUID"
.line	395	call          r7     2     2
.line	395	gettabup      r8    u0   k72 ; k72 = "tostring"
.line	395	move          r9    r1
.line	395	call          r8     2     0
.line	395	call          r4     0     2
.label	l109
.line	395	call          r3     2     1
.line	395	test          r2     0
.line	395	jmp            0  l115
.line	395	self          r3    r0   k74 ; k74 = "RegistUplinkEvent"
.line	395	call          r3     2     1
.line	395	jmp            0  l117
.label	l115
.line	395	self          r3    r0   k75 ; k75 = "UnRegistUplinkEvent"
.line	395	call          r3     2     1
.label	l117
.line	395	return        r0     1
.line	395	move          r0    r0
.line	395	return        r0     1

.function	main/f22

.source	null
.linedefined	408
.lastlinedefined	418
.numparams	1
.is_vararg	0
.maxstacksize	37

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"bHasRegistUplinkEvent"
.constant	k2	"print"
.constant	k3	"bWriteLog"
.constant	k4	149
.constant	k5	51
.constant	k6	25
.constant	k7	150
.constant	k8	134
.constant	k9	254
.constant	k10	126
.constant	k11	123
.constant	k12	86
.constant	k13	197
.constant	k14	162
.constant	k15	191
.constant	k16	198
.constant	k17	108
.constant	k18	175
.constant	k19	18
.constant	k20	29
.constant	k21	77
.constant	k22	136
.constant	k23	73
.constant	k24	210
.constant	k25	19
.constant	k26	125
.constant	k27	83
.constant	k28	255
.constant	k29	190
.constant	k30	137
.constant	k31	176
.constant	k32	230
.constant	k33	120
.constant	k34	43
.constant	k35	"Owner"
.constant	k36	"Object"
.constant	k37	"slua"
.constant	k38	"isValid"
.constant	k39	"GetChatComponent"
.constant	k40	"BindLuaObjEvent"
.constant	k41	151
.constant	k42	17
.constant	k43	11
.constant	k44	186
.constant	k45	245
.constant	k46	90
.constant	k47	64
.constant	k48	240
.constant	k49	166
.constant	k50	144
.constant	k51	174
.constant	k52	"HandleOnPlayerSendMsg"
.constant	k53	true

.line	408	gettabup      r1    u0    k0 ; k0 = "Client"
.line	408	test          r1     0
.line	408	jmp            0    l7
.line	408	gettable      r1    r0    k1 ; k1 = "bHasRegistUplinkEven" (truncated)
.line	408	test          r1     0
.line	408	jmp            0    l8
.label	l7
.line	408	return        r0     1
.label	l8
.line	408	gettabup      r1    u0    k2 ; k2 = "print"
.line	408	gettabup      r2    u0    k3 ; k3 = "bWriteLog"
.line	408	test          r2     0
.line	408	jmp            0   l48
.line	408	getupval      r2    u1
.line	408	loadk         r3    k4 ; k4 = 149
.line	408	loadk         r4    k5 ; k5 = 51
.line	408	loadk         r5    k6 ; k6 = 25
.line	408	loadk         r6    k7 ; k7 = 150
.line	408	loadk         r7    k8 ; k8 = 134
.line	408	loadk         r8    k9 ; k9 = 254
.line	408	loadk         r9   k10 ; k10 = 126
.line	408	loadk        r10   k11 ; k11 = 123
.line	408	loadk        r11   k12 ; k12 = 86
.line	408	loadk        r12   k13 ; k13 = 197
.line	408	loadk        r13   k14 ; k14 = 162
.line	408	loadk        r14    k7 ; k7 = 150
.line	408	loadk        r15   k15 ; k15 = 191
.line	408	loadk        r16   k16 ; k16 = 198
.line	408	loadk        r17   k17 ; k17 = 108
.line	408	loadk        r18   k18 ; k18 = 175
.line	408	loadk        r19   k19 ; k19 = 18
.line	408	loadk        r20   k20 ; k20 = 29
.line	408	loadk        r21   k21 ; k21 = 77
.line	408	loadk        r22   k22 ; k22 = 136
.line	408	loadk        r23   k23 ; k23 = 73
.line	408	loadk        r24   k24 ; k24 = 210
.line	408	loadk        r25   k25 ; k25 = 19
.line	408	loadk        r26   k26 ; k26 = 125
.line	408	loadk        r27   k27 ; k27 = 83
.line	408	loadk        r28   k28 ; k28 = 255
.line	408	loadk        r29   k29 ; k29 = 190
.line	408	loadk        r30   k30 ; k30 = 137
.line	408	loadk        r31   k31 ; k31 = 176
.line	408	loadk        r32   k32 ; k32 = 230
.line	408	loadk        r33   k33 ; k33 = 120
.line	408	loadk        r34   k15 ; k15 = 191
.line	408	loadk        r35   k12 ; k12 = 86
.line	408	loadk        r36   k34 ; k34 = 43
.line	408	call          r2    35     2
.label	l48
.line	408	call          r1     2     1
.line	408	gettable      r1    r0   k35 ; k35 = "Owner"
.line	408	gettable      r1    r1   k36 ; k36 = "Object"
.line	408	gettabup      r2    u0   k37 ; k37 = "slua"
.line	408	gettable      r2    r2   k38 ; k38 = "isValid"
.line	408	move          r3    r1
.line	408	call          r2     2     2
.line	408	test          r2     0
.line	408	jmp            0   l85
.line	408	gettabup      r2    u0   k37 ; k37 = "slua"
.line	408	gettable      r2    r2   k38 ; k38 = "isValid"
.line	408	self          r3    r1   k39 ; k39 = "GetChatComponent"
.line	408	call          r3     2     0
.line	408	call          r2     0     2
.line	408	test          r2     0
.line	408	jmp            0   l85
.line	408	self          r2    r0   k40 ; k40 = "BindLuaObjEvent"
.line	408	self          r4    r1   k39 ; k39 = "GetChatComponent"
.line	408	call          r4     2     2
.line	408	getupval      r5    u1
.line	408	loadk         r6   k41 ; k41 = 151
.line	408	loadk         r7   k42 ; k42 = 17
.line	408	loadk         r8   k43 ; k43 = 11
.line	408	loadk         r9   k44 ; k44 = 186
.line	408	loadk        r10   k29 ; k29 = 190
.line	408	loadk        r11   k45 ; k45 = 245
.line	408	loadk        r12   k46 ; k46 = 90
.line	408	loadk        r13   k26 ; k26 = 125
.line	408	loadk        r14   k47 ; k47 = 64
.line	408	loadk        r15   k48 ; k48 = 240
.line	408	loadk        r16   k49 ; k49 = 166
.line	408	loadk        r17   k50 ; k50 = 144
.line	408	loadk        r18   k51 ; k51 = 174
.line	408	call          r5    14     2
.line	408	gettable      r6    r0   k52 ; k52 = "HandleOnPlayerSendMs" (truncated)
.line	408	move          r7    r0
.line	408	call          r2     6     1
.label	l85
.line	408	settable      r0    k1   k53 ; k53 = true
.line	408	return        r0     1
.line	408	move          r0    r0
.line	408	return        r0     1

.function	main/f23

.source	null
.linedefined	420
.lastlinedefined	430
.numparams	1
.is_vararg	0
.maxstacksize	39

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"bHasRegistUplinkEvent"
.constant	k2	"print"
.constant	k3	"bWriteLog"
.constant	k4	149
.constant	k5	51
.constant	k6	25
.constant	k7	150
.constant	k8	134
.constant	k9	254
.constant	k10	126
.constant	k11	123
.constant	k12	86
.constant	k13	197
.constant	k14	162
.constant	k15	191
.constant	k16	198
.constant	k17	108
.constant	k18	175
.constant	k19	18
.constant	k20	26
.constant	k21	70
.constant	k22	189
.constant	k23	69
.constant	k24	14
.constant	k25	91
.constant	k26	87
.constant	k27	167
.constant	k28	139
.constant	k29	178
.constant	k30	205
.constant	k31	101
.constant	k32	159
.constant	k33	78
.constant	k34	58
.constant	k35	"Owner"
.constant	k36	"Object"
.constant	k37	"slua"
.constant	k38	"isValid"
.constant	k39	"GetChatComponent"
.constant	k40	"UnBindLuaObjEvent"
.constant	k41	151
.constant	k42	17
.constant	k43	11
.constant	k44	186
.constant	k45	190
.constant	k46	245
.constant	k47	90
.constant	k48	125
.constant	k49	64
.constant	k50	240
.constant	k51	166
.constant	k52	144
.constant	k53	174
.constant	k54	nil

.line	420	gettabup      r1    u0    k0 ; k0 = "Client"
.line	420	test          r1     0
.line	420	jmp            0    l7
.line	420	gettable      r1    r0    k1 ; k1 = "bHasRegistUplinkEven" (truncated)
.line	420	test          r1     1
.line	420	jmp            0    l8
.label	l7
.line	420	return        r0     1
.label	l8
.line	420	gettabup      r1    u0    k2 ; k2 = "print"
.line	420	gettabup      r2    u0    k3 ; k3 = "bWriteLog"
.line	420	test          r2     0
.line	420	jmp            0   l50
.line	420	getupval      r2    u1
.line	420	loadk         r3    k4 ; k4 = 149
.line	420	loadk         r4    k5 ; k5 = 51
.line	420	loadk         r5    k6 ; k6 = 25
.line	420	loadk         r6    k7 ; k7 = 150
.line	420	loadk         r7    k8 ; k8 = 134
.line	420	loadk         r8    k9 ; k9 = 254
.line	420	loadk         r9   k10 ; k10 = 126
.line	420	loadk        r10   k11 ; k11 = 123
.line	420	loadk        r11   k12 ; k12 = 86
.line	420	loadk        r12   k13 ; k13 = 197
.line	420	loadk        r13   k14 ; k14 = 162
.line	420	loadk        r14    k7 ; k7 = 150
.line	420	loadk        r15   k15 ; k15 = 191
.line	420	loadk        r16   k16 ; k16 = 198
.line	420	loadk        r17   k17 ; k17 = 108
.line	420	loadk        r18   k18 ; k18 = 175
.line	420	loadk        r19   k19 ; k19 = 18
.line	420	loadk        r20   k20 ; k20 = 26
.line	420	loadk        r21   k21 ; k21 = 70
.line	420	loadk        r22   k22 ; k22 = 189
.line	420	loadk        r23   k23 ; k23 = 69
.line	420	loadk        r24   k16 ; k16 = 198
.line	420	loadk        r25   k24 ; k24 = 14
.line	420	loadk        r26   k25 ; k25 = 91
.line	420	loadk        r27   k26 ; k26 = 87
.line	420	loadk        r28   k16 ; k16 = 198
.line	420	loadk        r29   k27 ; k27 = 167
.line	420	loadk        r30   k28 ; k28 = 139
.line	420	loadk        r31   k29 ; k29 = 178
.line	420	loadk        r32   k30 ; k30 = 205
.line	420	loadk        r33   k31 ; k31 = 101
.line	420	loadk        r34   k32 ; k32 = 159
.line	420	loadk        r35   k33 ; k33 = 78
.line	420	loadk        r36   k34 ; k34 = 58
.line	420	loadk        r37   k12 ; k12 = 86
.line	420	loadk        r38   k28 ; k28 = 139
.line	420	call          r2    37     2
.label	l50
.line	420	call          r1     2     1
.line	420	gettable      r1    r0   k35 ; k35 = "Owner"
.line	420	gettable      r1    r1   k36 ; k36 = "Object"
.line	420	gettabup      r2    u0   k37 ; k37 = "slua"
.line	420	gettable      r2    r2   k38 ; k38 = "isValid"
.line	420	move          r3    r1
.line	420	call          r2     2     2
.line	420	test          r2     0
.line	420	jmp            0   l85
.line	420	gettabup      r2    u0   k37 ; k37 = "slua"
.line	420	gettable      r2    r2   k38 ; k38 = "isValid"
.line	420	self          r3    r1   k39 ; k39 = "GetChatComponent"
.line	420	call          r3     2     0
.line	420	call          r2     0     2
.line	420	test          r2     0
.line	420	jmp            0   l85
.line	420	self          r2    r0   k40 ; k40 = "UnBindLuaObjEvent"
.line	420	self          r4    r1   k39 ; k39 = "GetChatComponent"
.line	420	call          r4     2     2
.line	420	getupval      r5    u1
.line	420	loadk         r6   k41 ; k41 = 151
.line	420	loadk         r7   k42 ; k42 = 17
.line	420	loadk         r8   k43 ; k43 = 11
.line	420	loadk         r9   k44 ; k44 = 186
.line	420	loadk        r10   k45 ; k45 = 190
.line	420	loadk        r11   k46 ; k46 = 245
.line	420	loadk        r12   k47 ; k47 = 90
.line	420	loadk        r13   k48 ; k48 = 125
.line	420	loadk        r14   k49 ; k49 = 64
.line	420	loadk        r15   k50 ; k50 = 240
.line	420	loadk        r16   k51 ; k51 = 166
.line	420	loadk        r17   k52 ; k52 = 144
.line	420	loadk        r18   k53 ; k53 = 174
.line	420	call          r5    14     2
.line	420	call          r2     4     1
.label	l85
.line	420	settable      r0    k1   k54 ; k54 = nil
.line	420	return        r0     1
.line	420	move          r0    r0
.line	420	move          r0    r0
.line	420	move          r0    r0
.line	420	move          r0    r0
.line	420	return        r0     1

.function	main/f24

.source	null
.linedefined	432
.lastlinedefined	445
.numparams	1
.is_vararg	0
.maxstacksize	38

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"bHasRegistSceneEvent"
.constant	k2	"print"
.constant	k3	"bWriteLog"
.constant	k4	149
.constant	k5	51
.constant	k6	25
.constant	k7	150
.constant	k8	134
.constant	k9	254
.constant	k10	126
.constant	k11	123
.constant	k12	86
.constant	k13	197
.constant	k14	162
.constant	k15	191
.constant	k16	198
.constant	k17	108
.constant	k18	175
.constant	k19	18
.constant	k20	26
.constant	k21	70
.constant	k22	189
.constant	k23	69
.constant	k24	14
.constant	k25	91
.constant	k26	87
.constant	k27	192
.constant	k28	180
.constant	k29	130
.constant	k30	181
.constant	k31	75
.constant	k32	172
.constant	k33	93
.constant	k34	49
.constant	k35	76
.constant	k36	"AntsVoiceInterface"
.constant	k37	"RemoveControlEvent"
.constant	k38	151
.constant	k39	17
.constant	k40	11
.constant	k41	186
.constant	k42	163
.constant	k43	226
.constant	k44	119
.constant	k45	168
.constant	k46	133
.constant	k47	138
.constant	k48	250
.constant	k49	164
.constant	k50	78
.constant	k51	32
.constant	k52	107
.constant	k53	142
.constant	k54	205
.constant	k55	5
.constant	k56	73
.constant	k57	64
.constant	k58	248
.constant	k59	154
.constant	k60	62
.constant	k61	176
.constant	k62	244
.constant	k63	88
.constant	k64	104
.constant	k65	241
.constant	k66	166
.constant	k67	131
.constant	k68	220
.constant	k69	112
.constant	k70	185
.constant	k71	242
.constant	k72	114
.constant	k73	200
.constant	k74	129
.constant	k75	174
.constant	k76	221
.constant	k77	106
.constant	k78	10
.constant	k79	140
.constant	k80	132
.constant	k81	194
.constant	k82	68
.constant	k83	109
.constant	k84	81
.constant	k85	247
.constant	k86	167
.constant	k87	214
.constant	k88	171
.constant	k89	35
.constant	k90	74
.constant	k91	67
.constant	k92	202
.constant	k93	95
.constant	k94	153
.constant	k95	122
.constant	k96	28
.constant	k97	92
.constant	k98	82
.constant	k99	213
.constant	k100	36
.constant	k101	79
.constant	k102	255
.constant	k103	184
.constant	k104	"RemoveCommonEvent"
.constant	k105	"EVENTTYPE_INGAME"
.constant	k106	"EVENTID_INGAME_CHANGE_STT_STATE"
.constant	k107	nil

.line	432	gettabup      r1    u0    k0 ; k0 = "Client"
.line	432	test          r1     0
.line	432	jmp            0  l190
.line	432	gettable      r1    r0    k1 ; k1 = "bHasRegistSceneEvent"
.line	432	test          r1     0
.line	432	jmp            0  l190
.line	432	gettabup      r1    u0    k2 ; k2 = "print"
.line	432	gettabup      r2    u0    k3 ; k3 = "bWriteLog"
.line	432	test          r2     0
.line	432	jmp            0   l48
.line	432	getupval      r2    u1
.line	432	loadk         r3    k4 ; k4 = 149
.line	432	loadk         r4    k5 ; k5 = 51
.line	432	loadk         r5    k6 ; k6 = 25
.line	432	loadk         r6    k7 ; k7 = 150
.line	432	loadk         r7    k8 ; k8 = 134
.line	432	loadk         r8    k9 ; k9 = 254
.line	432	loadk         r9   k10 ; k10 = 126
.line	432	loadk        r10   k11 ; k11 = 123
.line	432	loadk        r11   k12 ; k12 = 86
.line	432	loadk        r12   k13 ; k13 = 197
.line	432	loadk        r13   k14 ; k14 = 162
.line	432	loadk        r14    k7 ; k7 = 150
.line	432	loadk        r15   k15 ; k15 = 191
.line	432	loadk        r16   k16 ; k16 = 198
.line	432	loadk        r17   k17 ; k17 = 108
.line	432	loadk        r18   k18 ; k18 = 175
.line	432	loadk        r19   k19 ; k19 = 18
.line	432	loadk        r20   k20 ; k20 = 26
.line	432	loadk        r21   k21 ; k21 = 70
.line	432	loadk        r22   k22 ; k22 = 189
.line	432	loadk        r23   k23 ; k23 = 69
.line	432	loadk        r24   k16 ; k16 = 198
.line	432	loadk        r25   k24 ; k24 = 14
.line	432	loadk        r26   k25 ; k25 = 91
.line	432	loadk        r27   k26 ; k26 = 87
.line	432	loadk        r28   k27 ; k27 = 192
.line	432	loadk        r29   k28 ; k28 = 180
.line	432	loadk        r30   k29 ; k29 = 130
.line	432	loadk        r31   k30 ; k30 = 181
.line	432	loadk        r32   k16 ; k16 = 198
.line	432	loadk        r33   k31 ; k31 = 75
.line	432	loadk        r34   k32 ; k32 = 172
.line	432	loadk        r35   k33 ; k33 = 93
.line	432	loadk        r36   k34 ; k34 = 49
.line	432	loadk        r37   k35 ; k35 = 76
.line	432	call          r2    36     2
.label	l48
.line	432	call          r1     2     1
.line	432	gettable      r1    r0   k36 ; k36 = "AntsVoiceInterface"
.line	432	test          r1     0
.line	432	jmp            0  l189
.line	432	self          r1    r0   k37 ; k37 = "RemoveControlEvent"
.line	432	gettable      r3    r0   k36 ; k36 = "AntsVoiceInterface"
.line	432	getupval      r4    u1
.line	432	loadk         r5   k38 ; k38 = 151
.line	432	loadk         r6   k39 ; k39 = 17
.line	432	loadk         r7   k40 ; k40 = 11
.line	432	loadk         r8   k41 ; k41 = 186
.line	432	loadk         r9   k42 ; k42 = 163
.line	432	loadk        r10   k43 ; k43 = 226
.line	432	loadk        r11   k10 ; k10 = 126
.line	432	loadk        r12   k44 ; k44 = 119
.line	432	loadk        r13   k33 ; k33 = 93
.line	432	loadk        r14   k13 ; k13 = 197
.line	432	loadk        r15   k45 ; k45 = 168
.line	432	loadk        r16   k46 ; k46 = 133
.line	432	loadk        r17   k47 ; k47 = 138
.line	432	loadk        r18   k48 ; k48 = 250
.line	432	loadk        r19   k26 ; k26 = 87
.line	432	loadk        r20   k49 ; k49 = 164
.line	432	loadk        r21   k50 ; k50 = 78
.line	432	loadk        r22   k51 ; k51 = 32
.line	432	loadk        r23   k52 ; k52 = 107
.line	432	loadk        r24   k53 ; k53 = 142
.line	432	loadk        r25   k35 ; k35 = 76
.line	432	loadk        r26   k54 ; k54 = 205
.line	432	loadk        r27   k55 ; k55 = 5
.line	432	loadk        r28   k56 ; k56 = 73
.line	432	loadk        r29   k57 ; k57 = 64
.line	432	loadk        r30   k58 ; k58 = 248
.line	432	call          r4    27     2
.line	432	call          r1     4     1
.line	432	self          r1    r0   k37 ; k37 = "RemoveControlEvent"
.line	432	gettable      r3    r0   k36 ; k36 = "AntsVoiceInterface"
.line	432	getupval      r4    u1
.line	432	loadk         r5   k59 ; k59 = 154
.line	432	loadk         r6   k20 ; k20 = 26
.line	432	loadk         r7   k60 ; k60 = 62
.line	432	loadk         r8   k61 ; k61 = 176
.line	432	loadk         r9   k14 ; k14 = 162
.line	432	loadk        r10   k62 ; k62 = 244
.line	432	loadk        r11   k63 ; k63 = 88
.line	432	loadk        r12   k64 ; k64 = 104
.line	432	loadk        r13   k12 ; k12 = 86
.line	432	loadk        r14   k65 ; k65 = 241
.line	432	loadk        r15   k66 ; k66 = 166
.line	432	loadk        r16   k67 ; k67 = 131
.line	432	loadk        r17   k14 ; k14 = 162
.line	432	loadk        r18   k68 ; k68 = 220
.line	432	loadk        r19   k69 ; k69 = 112
.line	432	call          r4    16     2
.line	432	call          r1     4     1
.line	432	self          r1    r0   k37 ; k37 = "RemoveControlEvent"
.line	432	gettable      r3    r0   k36 ; k36 = "AntsVoiceInterface"
.line	432	getupval      r4    u1
.line	432	loadk         r5   k38 ; k38 = 151
.line	432	loadk         r6   k39 ; k39 = 17
.line	432	loadk         r7   k24 ; k24 = 14
.line	432	loadk         r8   k61 ; k61 = 176
.line	432	loadk         r9   k70 ; k70 = 185
.line	432	loadk        r10   k71 ; k71 = 242
.line	432	loadk        r11   k72 ; k72 = 114
.line	432	loadk        r12   k31 ; k31 = 75
.line	432	loadk        r13   k44 ; k44 = 119
.line	432	loadk        r14   k73 ; k73 = 200
.line	432	loadk        r15   k29 ; k29 = 130
.line	432	loadk        r16   k74 ; k74 = 129
.line	432	loadk        r17   k75 ; k75 = 174
.line	432	loadk        r18   k76 ; k76 = 221
.line	432	loadk        r19   k77 ; k77 = 106
.line	432	call          r4    16     2
.line	432	call          r1     4     1
.line	432	self          r1    r0   k37 ; k37 = "RemoveControlEvent"
.line	432	gettable      r3    r0   k36 ; k36 = "AntsVoiceInterface"
.line	432	getupval      r4    u1
.line	432	loadk         r5   k38 ; k38 = 151
.line	432	loadk         r6   k39 ; k39 = 17
.line	432	loadk         r7   k78 ; k78 = 10
.line	432	loadk         r8   k79 ; k79 = 140
.line	432	loadk         r9   k80 ; k80 = 132
.line	432	loadk        r10   k81 ; k81 = 194
.line	432	loadk        r11   k82 ; k82 = 68
.line	432	loadk        r12   k83 ; k83 = 109
.line	432	loadk        r13   k84 ; k84 = 81
.line	432	loadk        r14   k85 ; k85 = 247
.line	432	loadk        r15   k75 ; k75 = 174
.line	432	loadk        r16   k67 ; k67 = 131
.line	432	loadk        r17   k86 ; k86 = 167
.line	432	loadk        r18   k87 ; k87 = 214
.line	432	loadk        r19   k33 ; k33 = 93
.line	432	loadk        r20   k88 ; k88 = 171
.line	432	loadk        r21   k82 ; k82 = 68
.line	432	loadk        r22   k89 ; k89 = 35
.line	432	loadk        r23   k90 ; k90 = 74
.line	432	loadk        r24   k53 ; k53 = 142
.line	432	loadk        r25   k91 ; k91 = 67
.line	432	loadk        r26   k92 ; k92 = 202
.line	432	call          r4    23     2
.line	432	call          r1     4     1
.line	432	self          r1    r0   k37 ; k37 = "RemoveControlEvent"
.line	432	gettable      r3    r0   k36 ; k36 = "AntsVoiceInterface"
.line	432	getupval      r4    u1
.line	432	loadk         r5   k38 ; k38 = 151
.line	432	loadk         r6   k39 ; k39 = 17
.line	432	loadk         r7   k78 ; k78 = 10
.line	432	loadk         r8   k79 ; k79 = 140
.line	432	loadk         r9   k80 ; k80 = 132
.line	432	loadk        r10   k81 ; k81 = 194
.line	432	loadk        r11   k82 ; k82 = 68
.line	432	loadk        r12   k83 ; k83 = 109
.line	432	loadk        r13   k84 ; k84 = 81
.line	432	loadk        r14   k85 ; k85 = 247
.line	432	loadk        r15   k75 ; k75 = 174
.line	432	loadk        r16   k67 ; k67 = 131
.line	432	loadk        r17   k86 ; k86 = 167
.line	432	loadk        r18   k87 ; k87 = 214
.line	432	loadk        r19   k93 ; k93 = 95
.line	432	loadk        r20   k94 ; k94 = 153
.line	432	loadk        r21   k95 ; k95 = 122
.line	432	loadk        r22   k96 ; k96 = 28
.line	432	loadk        r23   k97 ; k97 = 92
.line	432	loadk        r24   k53 ; k53 = 142
.line	432	loadk        r25   k98 ; k98 = 82
.line	432	loadk        r26   k99 ; k99 = 213
.line	432	loadk        r27  k100 ; k100 = 36
.line	432	loadk        r28   k56 ; k56 = 73
.line	432	loadk        r29  k101 ; k101 = 79
.line	432	loadk        r30  k102 ; k102 = 255
.line	432	loadk        r31   k30 ; k30 = 181
.line	432	loadk        r32    k8 ; k8 = 134
.line	432	loadk        r33  k103 ; k103 = 184
.line	432	loadk        r34   k73 ; k73 = 200
.line	432	call          r4    31     2
.line	432	call          r1     4     1
.line	432	self          r1    r0  k104 ; k104 = "RemoveCommonEvent"
.line	432	gettabup      r3    u0  k105 ; k105 = "EVENTTYPE_INGAME"
.line	432	gettabup      r4    u0  k106 ; k106 = "EVENTID_INGAME_CHANG" (truncated)
.line	432	call          r1     4     1
.label	l189
.line	432	settable      r0    k1  k107 ; k107 = nil
.label	l190
.line	432	return        r0     1
.line	432	move          r0    r0
.line	432	return        r0     1

.function	main/f25

.source	null
.linedefined	447
.lastlinedefined	465
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	0
.constant	k23	70
.constant	k24	189
.constant	k25	69
.constant	k26	209
.constant	k27	56
.constant	k28	74
.constant	k29	227
.constant	k30	178
.constant	k31	137
.constant	k32	239
.constant	k33	79
.constant	k34	147
.constant	k35	110
.constant	k36	48
.constant	k37	81
.constant	k38	156
.constant	k39	85
.constant	k40	157
.constant	k41	87
.constant	k42	119
.constant	k43	180
.constant	k44	27
.constant	k45	14
.constant	k46	190
.constant	k47	188
.constant	k48	228
.constant	k49	114
.constant	k50	34
.constant	k51	22
.constant	k52	240
.constant	k53	235
.constant	k54	215
.constant	k55	133
.constant	k56	214
.constant	k57	105
.constant	k58	73
.constant	k59	35
.constant	k60	93
.constant	k61	138
.constant	k62	26
.constant	k63	132
.constant	k64	20
.constant	k65	"tostring"
.constant	k66	"bOpenMLAIVoice"
.constant	k67	"OnInit"
.constant	k68	"bFamilyCenterQueryPending"
.constant	k69	false
.constant	k70	"FamilyCenterQuerySeq"
.constant	k71	1
.constant	k72	"_bLegacyFallbackPass"
.constant	k73	nil
.constant	k74	"UnRegistSceneEvent"
.constant	k75	"UnRegistUplinkEvent"
.constant	k76	"UnRegistBaseEvent"
.constant	k77	"_ApplyDevTranslateUrlOnce"
.constant	k78	"RegistBaseEvent"
.constant	k79	"_RefreshUplinkEvent"
.constant	k80	151
.constant	k81	17
.constant	k82	10
.constant	k83	186
.constant	k84	160
.constant	k85	206
.constant	k86	117
.constant	k87	67
.constant	k88	230
.constant	k89	169
.constant	k90	135
.constant	k91	242
.constant	k92	71
.constant	k93	38
.constant	k94	75
.constant	k95	"nRSTSSceneID"
.constant	k96	"_ApplySceneWithCompliance"
.constant	k97	6
.constant	k98	72
.constant	k99	245
.constant	k100	139
.constant	k101	183

.line	447	gettabup      r2    u0    k0 ; k0 = "print"
.line	447	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	447	test          r3     0
.line	447	jmp            0   l86
.line	447	gettabup      r3    u0    k2 ; k2 = "string"
.line	447	gettable      r3    r3    k3 ; k3 = "format"
.line	447	gettabup      r4    u0    k4 ; k4 = "table"
.line	447	gettable      r4    r4    k5 ; k5 = "concat"
.line	447	newtable      r5     1     0
.line	447	getupval      r6    u1
.line	447	loadk         r7    k6 ; k6 = 149
.line	447	loadk         r8    k7 ; k7 = 51
.line	447	loadk         r9    k8 ; k8 = 25
.line	447	loadk        r10    k9 ; k9 = 150
.line	447	loadk        r11   k10 ; k10 = 134
.line	447	loadk        r12   k11 ; k11 = 254
.line	447	loadk        r13   k12 ; k12 = 126
.line	447	loadk        r14   k13 ; k13 = 123
.line	447	loadk        r15   k14 ; k14 = 86
.line	447	loadk        r16   k15 ; k15 = 197
.line	447	loadk        r17   k16 ; k16 = 162
.line	447	loadk        r18    k9 ; k9 = 150
.line	447	loadk        r19   k17 ; k17 = 191
.line	447	loadk        r20   k18 ; k18 = 198
.line	447	loadk        r21   k19 ; k19 = 108
.line	447	loadk        r22   k20 ; k20 = 175
.line	447	loadk        r23   k21 ; k21 = 18
.line	447	loadk        r24   k22 ; k22 = 0
.line	447	loadk        r25   k23 ; k23 = 70
.line	447	loadk        r26   k24 ; k24 = 189
.line	447	loadk        r27   k25 ; k25 = 69
.line	447	loadk        r28   k26 ; k26 = 209
.line	447	loadk        r29   k27 ; k27 = 56
.line	447	loadk        r30   k28 ; k28 = 74
.line	447	loadk        r31   k19 ; k19 = 108
.line	447	loadk        r32   k29 ; k29 = 227
.line	447	loadk        r33   k30 ; k30 = 178
.line	447	loadk        r34   k31 ; k31 = 137
.line	447	loadk        r35    k9 ; k9 = 150
.line	447	loadk        r36   k32 ; k32 = 239
.line	447	loadk        r37   k33 ; k33 = 79
.line	447	loadk        r38   k34 ; k34 = 147
.line	447	loadk        r39   k35 ; k35 = 110
.line	447	loadk        r40   k36 ; k36 = 48
.line	447	loadk        r41   k37 ; k37 = 81
.line	447	loadk        r42   k38 ; k38 = 156
.line	447	loadk        r43   k39 ; k39 = 85
.line	447	loadk        r44   k40 ; k40 = 157
.line	447	loadk        r45   k41 ; k41 = 87
.line	447	loadk        r46   k42 ; k42 = 119
.line	447	call          r6    41     2
.line	447	getupval      r7    u1
.line	447	loadk         r8   k43 ; k43 = 180
.line	447	loadk         r9   k44 ; k44 = 27
.line	447	loadk        r10   k45 ; k45 = 14
.line	447	loadk        r11   k46 ; k46 = 190
.line	447	loadk        r12   k47 ; k47 = 188
.line	447	loadk        r13   k48 ; k48 = 228
.line	447	loadk        r14   k49 ; k49 = 114
.line	447	loadk        r15   k50 ; k50 = 34
.line	447	loadk        r16   k51 ; k51 = 22
.line	447	loadk        r17   k52 ; k52 = 240
.line	447	loadk        r18   k53 ; k53 = 235
.line	447	loadk        r19   k54 ; k54 = 215
.line	447	loadk        r20   k55 ; k55 = 133
.line	447	loadk        r21   k56 ; k56 = 214
.line	447	loadk        r22   k57 ; k57 = 105
.line	447	loadk        r23   k38 ; k38 = 156
.line	447	loadk        r24   k58 ; k58 = 73
.line	447	loadk        r25   k59 ; k59 = 35
.line	447	loadk        r26   k60 ; k60 = 93
.line	447	loadk        r27   k61 ; k61 = 138
.line	447	loadk        r28   k62 ; k62 = 26
.line	447	loadk        r29   k63 ; k63 = 132
.line	447	loadk        r30   k64 ; k64 = 20
.line	447	call          r7    24     0
.line	447	setlist       r5     0     1
.line	447	call          r4     2     2
.line	447	gettabup      r5    u0   k65 ; k65 = "tostring"
.line	447	move          r6    r1
.line	447	call          r5     2     2
.line	447	gettabup      r6    u0   k65 ; k65 = "tostring"
.line	447	gettable      r7    r0   k66 ; k66 = "bOpenMLAIVoice"
.line	447	call          r6     2     0
.line	447	call          r3     0     2
.label	l86
.line	447	call          r2     2     1
.line	447	self          r2    r0   k67 ; k67 = "OnInit"
.line	447	call          r2     2     1
.line	447	settable      r0   k68   k69 ; k69 = false
.line	447	gettable      r2    r0   k70 ; k70 = "FamilyCenterQuerySeq"
.line	447	test          r2     1
.line	447	jmp            0   l94
.line	447	loadk         r2   k22 ; k22 = 0
.label	l94
.line	447	add           r2    r2   k71 ; k71 = 1
.line	447	settable      r0   k70    r2 ; k70 = "FamilyCenterQuerySeq"
.line	447	settable      r0   k72   k73 ; k73 = nil
.line	447	gettable      r2    r0   k66 ; k66 = "bOpenMLAIVoice"
.line	447	test          r2     1
.line	447	jmp            0  l107
.line	447	self          r2    r0   k74 ; k74 = "UnRegistSceneEvent"
.line	447	call          r2     2     1
.line	447	self          r2    r0   k75 ; k75 = "UnRegistUplinkEvent"
.line	447	call          r2     2     1
.line	447	self          r2    r0   k76 ; k76 = "UnRegistBaseEvent"
.line	447	call          r2     2     1
.line	447	return        r0     1
.label	l107
.line	447	self          r2    r0   k77 ; k77 = "_ApplyDevTranslateUr" (truncated)
.line	447	call          r2     2     1
.line	447	self          r2    r0   k78 ; k78 = "RegistBaseEvent"
.line	447	call          r2     2     1
.line	447	self          r2    r0   k79 ; k79 = "_RefreshUplinkEvent"
.line	447	getupval      r4    u1
.line	447	loadk         r5   k80 ; k80 = 151
.line	447	loadk         r6   k81 ; k81 = 17
.line	447	loadk         r7   k82 ; k82 = 10
.line	447	loadk         r8   k83 ; k83 = 186
.line	447	loadk         r9   k84 ; k84 = 160
.line	447	loadk        r10   k85 ; k85 = 206
.line	447	loadk        r11   k86 ; k86 = 117
.line	447	loadk        r12   k41 ; k41 = 87
.line	447	loadk        r13   k87 ; k87 = 67
.line	447	loadk        r14   k88 ; k88 = 230
.line	447	loadk        r15   k89 ; k89 = 169
.line	447	loadk        r16   k83 ; k83 = 186
.line	447	loadk        r17   k90 ; k90 = 135
.line	447	loadk        r18   k91 ; k91 = 242
.line	447	loadk        r19   k41 ; k41 = 87
.line	447	loadk        r20   k38 ; k38 = 156
.line	447	loadk        r21   k92 ; k92 = 71
.line	447	loadk        r22   k93 ; k93 = 38
.line	447	loadk        r23   k94 ; k94 = 75
.line	447	loadk        r24   k61 ; k61 = 138
.line	447	call          r4    21     2
.line	447	call          r2     3     1
.line	447	gettable      r2    r0   k95 ; k95 = "nRSTSSceneID"
.line	447	test          r2     1
.line	447	jmp            0  l139
.line	447	loadk         r2   k22 ; k22 = 0
.label	l139
.line	447	lt             0   k22    r2 ; k22 = 0
.line	447	jmp            0  l175
.line	447	self          r2    r0   k96 ; k96 = "_ApplySceneWithCompl" (truncated)
.line	447	gettable      r4    r0   k95 ; k95 = "nRSTSSceneID"
.line	447	getupval      r5    u1
.line	447	loadk         r6   k80 ; k80 = 151
.line	447	loadk         r7   k81 ; k81 = 17
.line	447	loadk         r8   k82 ; k82 = 10
.line	447	loadk         r9   k83 ; k83 = 186
.line	447	loadk        r10   k84 ; k84 = 160
.line	447	loadk        r11   k85 ; k85 = 206
.line	447	loadk        r12   k86 ; k86 = 117
.line	447	loadk        r13   k41 ; k41 = 87
.line	447	loadk        r14   k87 ; k87 = 67
.line	447	loadk        r15   k88 ; k88 = 230
.line	447	loadk        r16   k89 ; k89 = 169
.line	447	loadk        r17   k83 ; k83 = 186
.line	447	loadk        r18   k90 ; k90 = 135
.line	447	loadk        r19   k91 ; k91 = 242
.line	447	loadk        r20   k41 ; k41 = 87
.line	447	loadk        r21   k38 ; k38 = 156
.line	447	loadk        r22   k92 ; k92 = 71
.line	447	loadk        r23   k93 ; k93 = 38
.line	447	loadk        r24   k94 ; k94 = 75
.line	447	loadk        r25   k61 ; k61 = 138
.line	447	loadk        r26   k22 ; k22 = 0
.line	447	loadk        r27   k29 ; k29 = 227
.line	447	loadk        r28   k97 ; k97 = 6
.line	447	loadk        r29   k94 ; k94 = 75
.line	447	loadk        r30   k98 ; k98 = 72
.line	447	loadk        r31   k99 ; k99 = 245
.line	447	loadk        r32   k46 ; k46 = 190
.line	447	loadk        r33  k100 ; k100 = 139
.line	447	loadk        r34  k101 ; k101 = 183
.line	447	call          r5    30     2
.line	447	call          r2     4     1
.label	l175
.line	447	return        r0     1
.line	447	move          r0    r0
.line	447	move          r0    r0
.line	447	move          r0    r0
.line	447	return        r0     1

.function	main/f26

.source	null
.linedefined	467
.lastlinedefined	550
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	5	true
.upvalue	"U3"	4	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	28
.constant	k23	92
.constant	k24	142
.constant	k25	82
.constant	k26	213
.constant	k27	33
.constant	k28	73
.constant	k29	78
.constant	k30	250
.constant	k31	187
.constant	k32	158
.constant	k33	152
.constant	k34	96
.constant	k35	174
.constant	k36	93
.constant	k37	45
.constant	k38	144
.constant	k39	193
.constant	k40	27
.constant	k41	81
.constant	k42	185
.constant	k43	17
.constant	k44	59
.constant	k45	186
.constant	k46	129
.constant	k47	228
.constant	k48	114
.constant	k49	106
.constant	k50	74
.constant	k51	231
.constant	k52	178
.constant	k53	179
.constant	k54	199
.constant	k55	171
.constant	k56	91
.constant	k57	"tostring"
.constant	k58	"bFamilyCenterQueryPending"
.constant	k59	true
.constant	k60	"FamilyCenterQuerySeq"
.constant	k61	"TryRunDebugMock"
.constant	k62	"bFamilyCenterQueryPending"
.constant	k63	false
.constant	k64	"require"
.constant	k65	187
.constant	k66	19
.constant	k67	49
.constant	k68	186
.constant	k69	190
.constant	k70	229
.constant	k71	57
.constant	k72	117
.constant	k73	92
.constant	k74	231
.constant	k75	178
.constant	k76	155
.constant	k77	174
.constant	k78	236
.constant	k79	120
.constant	k80	184
.constant	k81	73
.constant	k82	34
.constant	k83	77
.constant	k84	152
.constant	k85	79
.constant	k86	211
.constant	k87	12
.constant	k88	6
.constant	k89	110
.constant	k90	252
.constant	k91	179
.constant	k92	146
.constant	k93	183
.constant	k94	198
.constant	k95	67
.constant	k96	86
.constant	k97	62
.constant	k98	95
.constant	k99	154
.constant	k100	66
.constant	k101	"GetModule"
.constant	k102	"CommonModuleConfig"
.constant	k103	"logic_familycenter"
.constant	k104	"FamilyCenterQuerySeq"
.constant	k105	"RunWithCompliance"
.constant	k106	"ENUM_SCENE"
.constant	k107	"AI"
.constant	k108	"onPass"
.constant	k109	"onLegacy"
.constant	k110	"onUnavailable"
.constant	k111	"onBlocked"
.constant	k112	"bFamilyCenterQueryPending"
.constant	k113	false

.line	467	gettabup      r2    u0    k0 ; k0 = "print"
.line	467	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	467	test          r3     0
.line	467	jmp            0   l79
.line	467	gettabup      r3    u0    k2 ; k2 = "string"
.line	467	gettable      r3    r3    k3 ; k3 = "format"
.line	467	gettabup      r4    u0    k4 ; k4 = "table"
.line	467	gettable      r4    r4    k5 ; k5 = "concat"
.line	467	newtable      r5     1     0
.line	467	getupval      r6    u1
.line	467	loadk         r7    k6 ; k6 = 149
.line	467	loadk         r8    k7 ; k7 = 51
.line	467	loadk         r9    k8 ; k8 = 25
.line	467	loadk        r10    k9 ; k9 = 150
.line	467	loadk        r11   k10 ; k10 = 134
.line	467	loadk        r12   k11 ; k11 = 254
.line	467	loadk        r13   k12 ; k12 = 126
.line	467	loadk        r14   k13 ; k13 = 123
.line	467	loadk        r15   k14 ; k14 = 86
.line	467	loadk        r16   k15 ; k15 = 197
.line	467	loadk        r17   k16 ; k16 = 162
.line	467	loadk        r18    k9 ; k9 = 150
.line	467	loadk        r19   k17 ; k17 = 191
.line	467	loadk        r20   k18 ; k18 = 198
.line	467	loadk        r21   k19 ; k19 = 108
.line	467	loadk        r22   k20 ; k20 = 175
.line	467	loadk        r23   k21 ; k21 = 18
.line	467	loadk        r24   k22 ; k22 = 28
.line	467	loadk        r25   k23 ; k23 = 92
.line	467	loadk        r26   k24 ; k24 = 142
.line	467	loadk        r27   k25 ; k25 = 82
.line	467	loadk        r28   k26 ; k26 = 213
.line	467	loadk        r29   k27 ; k27 = 33
.line	467	loadk        r30   k28 ; k28 = 73
.line	467	loadk        r31   k29 ; k29 = 78
.line	467	loadk        r32   k30 ; k30 = 250
.line	467	loadk        r33   k31 ; k31 = 187
.line	467	loadk        r34   k32 ; k32 = 158
.line	467	loadk        r35   k33 ; k33 = 152
.line	467	loadk        r36   k18 ; k18 = 198
.line	467	loadk        r37   k34 ; k34 = 96
.line	467	loadk        r38   k35 ; k35 = 174
.line	467	loadk        r39   k36 ; k36 = 93
.line	467	loadk        r40   k37 ; k37 = 45
.line	467	loadk        r41   k13 ; k13 = 123
.line	467	loadk        r42   k38 ; k38 = 144
.line	467	loadk        r43   k36 ; k36 = 93
.line	467	loadk        r44   k39 ; k39 = 193
.line	467	loadk        r45   k40 ; k40 = 27
.line	467	loadk        r46   k41 ; k41 = 81
.line	467	call          r6    41     2
.line	467	getupval      r7    u1
.line	467	loadk         r8   k42 ; k42 = 185
.line	467	loadk         r9   k43 ; k43 = 17
.line	467	loadk        r10   k44 ; k44 = 59
.line	467	loadk        r11   k45 ; k45 = 186
.line	467	loadk        r12   k46 ; k46 = 129
.line	467	loadk        r13   k47 ; k47 = 228
.line	467	loadk        r14   k48 ; k48 = 114
.line	467	loadk        r15   k49 ; k49 = 106
.line	467	loadk        r16   k50 ; k50 = 74
.line	467	loadk        r17   k20 ; k20 = 175
.line	467	loadk        r18   k51 ; k51 = 231
.line	467	loadk        r19   k52 ; k52 = 178
.line	467	loadk        r20   k53 ; k53 = 179
.line	467	loadk        r21   k54 ; k54 = 199
.line	467	loadk        r22   k19 ; k19 = 108
.line	467	loadk        r23   k55 ; k55 = 171
.line	467	loadk        r24   k21 ; k21 = 18
.line	467	loadk        r25   k49 ; k49 = 106
.line	467	loadk        r26   k56 ; k56 = 91
.line	467	call          r7    20     0
.line	467	setlist       r5     0     1
.line	467	call          r4     2     2
.line	467	gettabup      r5    u0   k57 ; k57 = "tostring"
.line	467	move          r6    r1
.line	467	call          r5     2     0
.line	467	call          r3     0     2
.label	l79
.line	467	call          r2     2     1
.line	467	settable      r0   k58   k59 ; k59 = true
.line	467	gettable      r2    r0   k60 ; k60 = "FamilyCenterQuerySeq"
.line	467	gettabup      r3    u2   k61 ; k61 = "TryRunDebugMock"
.line	467	closure       r4    f0
.line	467	call          r3     2     2
.line	467	test          r3     0
.line	467	jmp            0   l89
.line	467	loadbool      r4     1     0
.line	467	return        r4     2
.label	l89
.line	467	settable      r0   k62   k63 ; k63 = false
.line	467	jmp            3   l91
.label	l91
.line	467	gettabup      r2    u0   k64 ; k64 = "require"
.line	467	getupval      r3    u1
.line	467	loadk         r4   k65 ; k65 = 187
.line	467	loadk         r5   k66 ; k66 = 19
.line	467	loadk         r6   k67 ; k67 = 49
.line	467	loadk         r7   k68 ; k68 = 186
.line	467	loadk         r8   k69 ; k69 = 190
.line	467	loadk         r9   k70 ; k70 = 229
.line	467	loadk        r10   k71 ; k71 = 57
.line	467	loadk        r11   k72 ; k72 = 117
.line	467	loadk        r12   k73 ; k73 = 92
.line	467	loadk        r13   k74 ; k74 = 231
.line	467	loadk        r14   k75 ; k75 = 178
.line	467	loadk        r15   k76 ; k76 = 155
.line	467	loadk        r16   k77 ; k77 = 174
.line	467	loadk        r17   k78 ; k78 = 236
.line	467	loadk        r18   k79 ; k79 = 120
.line	467	loadk        r19   k80 ; k80 = 184
.line	467	loadk        r20   k81 ; k81 = 73
.line	467	loadk        r21   k82 ; k82 = 34
.line	467	loadk        r22   k83 ; k83 = 77
.line	467	loadk        r23   k84 ; k84 = 152
.line	467	loadk        r24   k85 ; k85 = 79
.line	467	loadk        r25   k86 ; k86 = 211
.line	467	loadk        r26   k87 ; k87 = 12
.line	467	loadk        r27   k88 ; k88 = 6
.line	467	loadk        r28   k89 ; k89 = 110
.line	467	loadk        r29   k90 ; k90 = 252
.line	467	loadk        r30   k91 ; k91 = 179
.line	467	loadk        r31   k92 ; k92 = 146
.line	467	loadk        r32   k93 ; k93 = 183
.line	467	loadk        r33   k94 ; k94 = 198
.line	467	loadk        r34   k95 ; k95 = 67
.line	467	loadk        r35   k65 ; k65 = 187
.line	467	loadk        r36   k96 ; k96 = 86
.line	467	loadk        r37   k97 ; k97 = 62
.line	467	loadk        r38   k98 ; k98 = 95
.line	467	loadk        r39   k99 ; k99 = 154
.line	467	loadk        r40  k100 ; k100 = 66
.line	467	call          r3    38     2
.line	467	call          r2     2     2
.line	467	gettable      r3    r2  k101 ; k101 = "GetModule"
.line	467	gettable      r4    r2  k102 ; k102 = "CommonModuleConfig"
.line	467	gettable      r4    r4  k103 ; k103 = "logic_familycenter"
.line	467	call          r3     2     2
.line	467	test          r3     1
.line	467	jmp            0  l140
.line	467	loadbool      r4     0     0
.line	467	return        r4     2
.label	l140
.line	467	settable      r0   k62   k59 ; k59 = true
.line	467	gettable      r4    r0  k104 ; k104 = "FamilyCenterQuerySeq"
.line	467	loadbool      r5     0     0
.line	467	self          r6    r3  k105 ; k105 = "RunWithCompliance"
.line	467	gettabup      r8    u3  k106 ; k106 = "ENUM_SCENE"
.line	467	gettable      r8    r8  k107 ; k107 = "AI"
.line	467	newtable      r9     0     4
.line	467	closure      r10    f1
.line	467	settable      r9  k108   r10 ; k108 = "onPass"
.line	467	closure      r10    f2
.line	467	settable      r9  k109   r10 ; k109 = "onLegacy"
.line	467	closure      r10    f3
.line	467	settable      r9  k110   r10 ; k110 = "onUnavailable"
.line	467	closure      r10    f4
.line	467	settable      r9  k111   r10 ; k111 = "onBlocked"
.line	467	call          r6     4     2
.line	467	test          r6     1
.line	467	jmp            0  l159
.line	467	settable      r0  k112  k113 ; k113 = false
.label	l159
.line	467	testset       r7    r6     1
.line	467	jmp            0  l162
.line	467	move          r7    r5
.label	l162
.line	467	return        r7     2
.line	467	return        r0     1
.line	467	move          r0    r0
.line	467	return        r0     1

.function	main/f26/f0

.source	null
.linedefined	472
.lastlinedefined	489
.numparams	2
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	true
.upvalue	"U1"	2	true
.upvalue	"U2"	0	false
.upvalue	"U3"	1	false

.constant	k0	"bFamilyCenterQueryPending"
.constant	k1	"FamilyCenterQuerySeq"
.constant	k2	false
.constant	k3	"HandleOpenMLAIVoiceResult"
.constant	k4	"pass"
.constant	k5	"print"
.constant	k6	"table"
.constant	k7	"concat"
.constant	k8	149
.constant	k9	51
.constant	k10	25
.constant	k11	150
.constant	k12	134
.constant	k13	254
.constant	k14	126
.constant	k15	123
.constant	k16	86
.constant	k17	197
.constant	k18	162
.constant	k19	191
.constant	k20	198
.constant	k21	108
.constant	k22	175
.constant	k23	8
.constant	k24	34
.constant	k25	71
.constant	k26	140
.constant	k27	75
.constant	k28	129
.constant	k29	5
.constant	k30	68
.constant	k31	76
.constant	k32	240
.constant	k33	188
.constant	k34	130
.constant	k35	143
.constant	k36	46
.constant	k37	190
.constant	k38	81
.constant	k39	44
.constant	k40	72
.constant	k41	158
.constant	k42	210
.constant	k43	31
.constant	k44	24
.constant	k45	144
.constant	k46	30
.constant	k47	54
.constant	k48	187
.constant	k49	244
.constant	k50	84
.constant	k51	119
.constant	k52	94
.constant	k53	243
.constant	k54	171
.constant	k55	170
.constant	k56	221
.constant	k57	125
.constant	k58	106
.constant	k59	35
.constant	k60	196
.constant	k61	3
.constant	k62	"require"
.constant	k63	19
.constant	k64	49
.constant	k65	186
.constant	k66	229
.constant	k67	57
.constant	k68	117
.constant	k69	92
.constant	k70	231
.constant	k71	178
.constant	k72	155
.constant	k73	174
.constant	k74	236
.constant	k75	120
.constant	k76	184
.constant	k77	73
.constant	k78	77
.constant	k79	152
.constant	k80	79
.constant	k81	211
.constant	k82	12
.constant	k83	6
.constant	k84	110
.constant	k85	252
.constant	k86	179
.constant	k87	146
.constant	k88	183
.constant	k89	67
.constant	k90	62
.constant	k91	95
.constant	k92	154
.constant	k93	66
.constant	k94	"GetModule"
.constant	k95	"CommonModuleConfig"
.constant	k96	"logic_familycenter"
.constant	k97	"HandleComplianceBlocked"
.constant	k98	89
.constant	k99	147
.constant	k100	85
.constant	k101	242
.constant	k102	168
.constant	k103	114
.constant	k104	90
.constant	k105	164
.constant	k106	156
.constant	k107	215
.constant	k108	33
.constant	k109	182
.constant	k110	87
.constant	k111	56
.constant	k112	111
.constant	k113	22
.constant	k114	177
.constant	k115	181
.constant	k116	255
.constant	k117	99
.constant	k118	65
.constant	k119	163
.constant	k120	133
.constant	k121	235
.constant	k122	251
.constant	k123	127
.constant	k124	172
.constant	k125	204
.constant	k126	23
.constant	k127	74
.constant	k128	185
.constant	k129	132
.constant	k130	225
.constant	k131	98
.constant	k132	91
.constant	k133	52
.constant	k134	93
.constant	k135	16
.constant	k136	220

.line	472	gettabup      r2    u0    k0 ; k0 = "bFamilyCenterQueryPe" (truncated)
.line	472	test          r2     0
.line	472	jmp            0    l8
.line	472	getupval      r2    u1
.line	472	gettabup      r3    u0    k1 ; k1 = "FamilyCenterQuerySeq"
.line	472	eq             1    r2    r3
.line	472	jmp            0    l9
.label	l8
.line	472	return        r0     1
.label	l9
.line	472	settabup      u0    k0    k2 ; k2 = false
.line	472	getupval      r2    u0
.line	472	self          r2    r2    k3 ; k3 = "HandleOpenMLAIVoiceR" (truncated)
.line	472	move          r4    r1
.line	472	call          r2     3     1
.line	472	test          r1     0
.line	472	jmp            0   l19
.line	472	gettable      r2    r1    k4 ; k4 = "pass"
.line	472	test          r2     1
.line	472	jmp            0  l314
.label	l19
.line	472	gettabup      r2    u2    k5 ; k5 = "print"
.line	472	gettabup      r3    u2    k6 ; k6 = "table"
.line	472	gettable      r3    r3    k7 ; k7 = "concat"
.line	472	newtable      r4     1     0
.line	472	getupval      r5    u3
.line	472	loadk         r6    k8 ; k8 = 149
.line	472	loadk         r7    k9 ; k9 = 51
.line	472	loadk         r8   k10 ; k10 = 25
.line	472	loadk         r9   k11 ; k11 = 150
.line	472	loadk        r10   k12 ; k12 = 134
.line	472	loadk        r11   k13 ; k13 = 254
.line	472	loadk        r12   k14 ; k14 = 126
.line	472	loadk        r13   k15 ; k15 = 123
.line	472	loadk        r14   k16 ; k16 = 86
.line	472	loadk        r15   k17 ; k17 = 197
.line	472	loadk        r16   k18 ; k18 = 162
.line	472	loadk        r17   k11 ; k11 = 150
.line	472	loadk        r18   k19 ; k19 = 191
.line	472	loadk        r19   k20 ; k20 = 198
.line	472	loadk        r20   k21 ; k21 = 108
.line	472	loadk        r21   k22 ; k22 = 175
.line	472	loadk        r22   k23 ; k23 = 8
.line	472	loadk        r23   k24 ; k24 = 34
.line	472	loadk        r24   k25 ; k25 = 71
.line	472	loadk        r25   k26 ; k26 = 140
.line	472	loadk        r26   k27 ; k27 = 75
.line	472	loadk        r27   k28 ; k28 = 129
.line	472	loadk        r28   k29 ; k29 = 5
.line	472	loadk        r29   k30 ; k30 = 68
.line	472	loadk        r30   k31 ; k31 = 76
.line	472	loadk        r31   k32 ; k32 = 240
.line	472	loadk        r32   k33 ; k33 = 188
.line	472	loadk        r33   k34 ; k34 = 130
.line	472	loadk        r34   k19 ; k19 = 191
.line	472	loadk        r35   k35 ; k35 = 143
.line	472	loadk        r36   k36 ; k36 = 46
.line	472	loadk        r37   k37 ; k37 = 190
.line	472	loadk        r38   k38 ; k38 = 81
.line	472	loadk        r39   k39 ; k39 = 44
.line	472	loadk        r40   k40 ; k40 = 72
.line	472	loadk        r41   k41 ; k41 = 158
.line	472	loadk        r42   k30 ; k30 = 68
.line	472	loadk        r43   k42 ; k42 = 210
.line	472	loadk        r44   k43 ; k43 = 31
.line	472	loadk        r45   k44 ; k44 = 24
.line	472	call          r5    41     2
.line	472	getupval      r6    u3
.line	472	loadk         r7   k45 ; k45 = 144
.line	472	loadk         r8   k46 ; k46 = 30
.line	472	loadk         r9   k47 ; k47 = 54
.line	472	loadk        r10   k48 ; k48 = 187
.line	472	loadk        r11   k33 ; k33 = 188
.line	472	loadk        r12   k49 ; k49 = 244
.line	472	loadk        r13   k50 ; k50 = 84
.line	472	loadk        r14   k51 ; k51 = 119
.line	472	loadk        r15   k52 ; k52 = 94
.line	472	loadk        r16   k53 ; k53 = 243
.line	472	loadk        r17   k54 ; k54 = 171
.line	472	loadk        r18   k41 ; k41 = 158
.line	472	loadk        r19   k55 ; k55 = 170
.line	472	loadk        r20   k56 ; k56 = 221
.line	472	loadk        r21   k57 ; k57 = 125
.line	472	loadk        r22   k22 ; k22 = 175
.line	472	loadk        r23   k58 ; k58 = 106
.line	472	loadk        r24   k59 ; k59 = 35
.line	472	loadk        r25   k25 ; k25 = 71
.line	472	loadk        r26   k26 ; k26 = 140
.line	472	loadk        r27   k27 ; k27 = 75
.line	472	loadk        r28   k60 ; k60 = 196
.line	472	loadk        r29   k61 ; k61 = 3
.line	472	call          r6    24     0
.line	472	setlist       r4     0     1
.line	472	call          r3     2     2
.line	472	call          r2     2     1
.line	472	gettabup      r2    u2   k62 ; k62 = "require"
.line	472	getupval      r3    u3
.line	472	loadk         r4   k48 ; k48 = 187
.line	472	loadk         r5   k63 ; k63 = 19
.line	472	loadk         r6   k64 ; k64 = 49
.line	472	loadk         r7   k65 ; k65 = 186
.line	472	loadk         r8   k37 ; k37 = 190
.line	472	loadk         r9   k66 ; k66 = 229
.line	472	loadk        r10   k67 ; k67 = 57
.line	472	loadk        r11   k68 ; k68 = 117
.line	472	loadk        r12   k69 ; k69 = 92
.line	472	loadk        r13   k70 ; k70 = 231
.line	472	loadk        r14   k71 ; k71 = 178
.line	472	loadk        r15   k72 ; k72 = 155
.line	472	loadk        r16   k73 ; k73 = 174
.line	472	loadk        r17   k74 ; k74 = 236
.line	472	loadk        r18   k75 ; k75 = 120
.line	472	loadk        r19   k76 ; k76 = 184
.line	472	loadk        r20   k77 ; k77 = 73
.line	472	loadk        r21   k24 ; k24 = 34
.line	472	loadk        r22   k78 ; k78 = 77
.line	472	loadk        r23   k79 ; k79 = 152
.line	472	loadk        r24   k80 ; k80 = 79
.line	472	loadk        r25   k81 ; k81 = 211
.line	472	loadk        r26   k82 ; k82 = 12
.line	472	loadk        r27   k83 ; k83 = 6
.line	472	loadk        r28   k84 ; k84 = 110
.line	472	loadk        r29   k85 ; k85 = 252
.line	472	loadk        r30   k86 ; k86 = 179
.line	472	loadk        r31   k87 ; k87 = 146
.line	472	loadk        r32   k88 ; k88 = 183
.line	472	loadk        r33   k20 ; k20 = 198
.line	472	loadk        r34   k89 ; k89 = 67
.line	472	loadk        r35   k48 ; k48 = 187
.line	472	loadk        r36   k16 ; k16 = 86
.line	472	loadk        r37   k90 ; k90 = 62
.line	472	loadk        r38   k91 ; k91 = 95
.line	472	loadk        r39   k92 ; k92 = 154
.line	472	loadk        r40   k93 ; k93 = 66
.line	472	call          r3    38     2
.line	472	call          r2     2     2
.line	472	gettable      r3    r2   k94 ; k94 = "GetModule"
.line	472	gettable      r4    r2   k95 ; k95 = "CommonModuleConfig"
.line	472	gettable      r4    r4   k96 ; k96 = "logic_familycenter"
.line	472	call          r3     2     2
.line	472	test          r3     0
.line	472	jmp            0  l217
.line	472	gettable      r4    r3   k97 ; k97 = "HandleComplianceBloc" (truncated)
.line	472	test          r4     0
.line	472	jmp            0  l217
.line	472	self          r4    r3   k97 ; k97 = "HandleComplianceBloc" (truncated)
.line	472	move          r6    r1
.line	472	call          r4     3     1
.line	472	gettabup      r4    u2    k5 ; k5 = "print"
.line	472	gettabup      r5    u2    k6 ; k6 = "table"
.line	472	gettable      r5    r5    k7 ; k7 = "concat"
.line	472	newtable      r6     1     0
.line	472	getupval      r7    u3
.line	472	loadk         r8    k8 ; k8 = 149
.line	472	loadk         r9    k9 ; k9 = 51
.line	472	loadk        r10   k10 ; k10 = 25
.line	472	loadk        r11   k11 ; k11 = 150
.line	472	loadk        r12   k12 ; k12 = 134
.line	472	loadk        r13   k13 ; k13 = 254
.line	472	loadk        r14   k14 ; k14 = 126
.line	472	loadk        r15   k15 ; k15 = 123
.line	472	loadk        r16   k16 ; k16 = 86
.line	472	loadk        r17   k17 ; k17 = 197
.line	472	loadk        r18   k18 ; k18 = 162
.line	472	loadk        r19   k11 ; k11 = 150
.line	472	loadk        r20   k19 ; k19 = 191
.line	472	loadk        r21   k20 ; k20 = 198
.line	472	loadk        r22   k21 ; k21 = 108
.line	472	loadk        r23   k22 ; k22 = 175
.line	472	loadk        r24   k23 ; k23 = 8
.line	472	loadk        r25   k24 ; k24 = 34
.line	472	loadk        r26   k25 ; k25 = 71
.line	472	loadk        r27   k26 ; k26 = 140
.line	472	loadk        r28   k27 ; k27 = 75
.line	472	loadk        r29   k28 ; k28 = 129
.line	472	loadk        r30   k29 ; k29 = 5
.line	472	loadk        r31   k30 ; k30 = 68
.line	472	loadk        r32   k31 ; k31 = 76
.line	472	loadk        r33   k32 ; k32 = 240
.line	472	loadk        r34   k33 ; k33 = 188
.line	472	loadk        r35   k34 ; k34 = 130
.line	472	loadk        r36   k19 ; k19 = 191
.line	472	loadk        r37   k35 ; k35 = 143
.line	472	loadk        r38   k36 ; k36 = 46
.line	472	loadk        r39   k87 ; k87 = 146
.line	472	loadk        r40   k98 ; k98 = 89
.line	472	loadk        r41   k64 ; k64 = 49
.line	472	loadk        r42   k69 ; k69 = 92
.line	472	loadk        r43   k99 ; k99 = 147
.line	472	loadk        r44  k100 ; k100 = 85
.line	472	loadk        r45  k101 ; k101 = 242
.line	472	loadk        r46   k44 ; k44 = 24
.line	472	loadk        r47  k100 ; k100 = 85
.line	472	call          r7    41     2
.line	472	getupval      r8    u3
.line	472	loadk         r9  k102 ; k102 = 168
.line	472	loadk        r10   k63 ; k63 = 19
.line	472	loadk        r11   k64 ; k64 = 49
.line	472	loadk        r12   k37 ; k37 = 190
.line	472	loadk        r13   k37 ; k37 = 190
.line	472	loadk        r14  k101 ; k101 = 242
.line	472	loadk        r15  k103 ; k103 = 114
.line	472	loadk        r16  k104 ; k104 = 90
.line	472	loadk        r17   k91 ; k91 = 95
.line	472	loadk        r18   k74 ; k74 = 236
.line	472	loadk        r19  k105 ; k105 = 164
.line	472	loadk        r20  k106 ; k106 = 156
.line	472	loadk        r21   k73 ; k73 = 174
.line	472	loadk        r22  k107 ; k107 = 215
.line	472	loadk        r23   k90 ; k90 = 62
.line	472	loadk        r24   k73 ; k73 = 174
.line	472	loadk        r25   k25 ; k25 = 71
.line	472	loadk        r26  k108 ; k108 = 33
.line	472	loadk        r27   k78 ; k78 = 77
.line	472	call          r8    20     0
.line	472	setlist       r6     0     1
.line	472	call          r5     2     2
.line	472	call          r4     2     1
.line	472	jmp            0  l314
.label	l217
.line	472	gettabup      r4    u2    k5 ; k5 = "print"
.line	472	gettabup      r5    u2    k6 ; k6 = "table"
.line	472	gettable      r5    r5    k7 ; k7 = "concat"
.line	472	newtable      r6     2     0
.line	472	getupval      r7    u3
.line	472	loadk         r8    k8 ; k8 = 149
.line	472	loadk         r9    k9 ; k9 = 51
.line	472	loadk        r10   k10 ; k10 = 25
.line	472	loadk        r11   k11 ; k11 = 150
.line	472	loadk        r12   k12 ; k12 = 134
.line	472	loadk        r13   k13 ; k13 = 254
.line	472	loadk        r14   k14 ; k14 = 126
.line	472	loadk        r15   k15 ; k15 = 123
.line	472	loadk        r16   k16 ; k16 = 86
.line	472	loadk        r17   k17 ; k17 = 197
.line	472	loadk        r18   k18 ; k18 = 162
.line	472	loadk        r19   k11 ; k11 = 150
.line	472	loadk        r20   k19 ; k19 = 191
.line	472	loadk        r21   k20 ; k20 = 198
.line	472	loadk        r22   k21 ; k21 = 108
.line	472	loadk        r23   k22 ; k22 = 175
.line	472	loadk        r24   k23 ; k23 = 8
.line	472	loadk        r25   k24 ; k24 = 34
.line	472	loadk        r26   k25 ; k25 = 71
.line	472	loadk        r27   k26 ; k26 = 140
.line	472	loadk        r28   k27 ; k27 = 75
.line	472	loadk        r29   k28 ; k28 = 129
.line	472	loadk        r30   k29 ; k29 = 5
.line	472	loadk        r31   k30 ; k30 = 68
.line	472	loadk        r32   k31 ; k31 = 76
.line	472	loadk        r33   k32 ; k32 = 240
.line	472	loadk        r34   k33 ; k33 = 188
.line	472	loadk        r35   k34 ; k34 = 130
.line	472	loadk        r36   k19 ; k19 = 191
.line	472	loadk        r37   k35 ; k35 = 143
.line	472	loadk        r38   k36 ; k36 = 46
.line	472	loadk        r39  k109 ; k109 = 182
.line	472	loadk        r40  k110 ; k110 = 87
.line	472	loadk        r41  k111 ; k111 = 56
.line	472	loadk        r42   k38 ; k38 = 81
.line	472	loadk        r43  k106 ; k106 = 156
.line	472	loadk        r44  k112 ; k112 = 111
.line	472	loadk        r45  k107 ; k107 = 215
.line	472	loadk        r46  k113 ; k113 = 22
.line	472	loadk        r47  k100 ; k100 = 85
.line	472	call          r7    41     2
.line	472	getupval      r8    u3
.line	472	loadk         r9  k114 ; k114 = 177
.line	472	loadk        r10   k63 ; k63 = 19
.line	472	loadk        r11  k108 ; k108 = 33
.line	472	loadk        r12   k33 ; k33 = 188
.line	472	loadk        r13  k115 ; k115 = 181
.line	472	loadk        r14  k116 ; k116 = 255
.line	472	loadk        r15  k117 ; k117 = 99
.line	472	loadk        r16   k57 ; k57 = 125
.line	472	loadk        r17  k118 ; k118 = 65
.line	472	loadk        r18  k119 ; k119 = 163
.line	472	loadk        r19  k102 ; k102 = 168
.line	472	loadk        r20  k120 ; k120 = 133
.line	472	loadk        r21  k121 ; k121 = 235
.line	472	loadk        r22  k122 ; k122 = 251
.line	472	loadk        r23  k123 ; k123 = 127
.line	472	loadk        r24  k105 ; k105 = 164
.line	472	loadk        r25   k31 ; k31 = 76
.line	472	loadk        r26   k59 ; k59 = 35
.line	472	loadk        r27   k78 ; k78 = 77
.line	472	loadk        r28  k124 ; k124 = 172
.line	472	loadk        r29   k80 ; k80 = 79
.line	472	loadk        r30  k125 ; k125 = 204
.line	472	loadk        r31  k126 ; k126 = 23
.line	472	loadk        r32   k30 ; k30 = 68
.line	472	loadk        r33  k127 ; k127 = 74
.line	472	loadk        r34  k101 ; k101 = 242
.line	472	loadk        r35  k128 ; k128 = 185
.line	472	loadk        r36  k129 ; k129 = 132
.line	472	loadk        r37   k37 ; k37 = 190
.line	472	loadk        r38  k130 ; k130 = 225
.line	472	loadk        r39  k131 ; k131 = 98
.line	472	loadk        r40  k115 ; k115 = 181
.line	472	loadk        r41  k132 ; k132 = 91
.line	472	loadk        r42  k133 ; k133 = 52
.line	472	loadk        r43  k134 ; k134 = 93
.line	472	loadk        r44   k72 ; k72 = 155
.line	472	loadk        r45  k135 ; k135 = 16
.line	472	loadk        r46  k136 ; k136 = 220
.line	472	loadk        r47   k46 ; k46 = 30
.line	472	loadk        r48   k27 ; k27 = 75
.line	472	call          r8    41     2
.line	472	getupval      r9    u3
.line	472	loadk        r10   k54 ; k54 = 171
.line	472	loadk        r11  k113 ; k113 = 22
.line	472	loadk        r12   k47 ; k47 = 54
.line	472	loadk        r13   k76 ; k76 = 184
.line	472	call          r9     5     0
.line	472	setlist       r6     0     1
.line	472	call          r5     2     2
.line	472	call          r4     2     1
.label	l314
.line	472	return        r0     1
.line	472	move          r0    r0
.line	472	move          r0    r0
.line	472	move          r0    r0
.line	472	return        r0     1

.function	main/f26/f1

.source	null
.linedefined	504
.lastlinedefined	511
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	0	true
.upvalue	"U3"	4	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	28
.constant	k23	92
.constant	k24	142
.constant	k25	82
.constant	k26	213
.constant	k27	33
.constant	k28	73
.constant	k29	78
.constant	k30	250
.constant	k31	187
.constant	k32	158
.constant	k33	152
.constant	k34	96
.constant	k35	174
.constant	k36	93
.constant	k37	45
.constant	k38	144
.constant	k39	193
.constant	k40	27
.constant	k41	81
.constant	k42	185
.constant	k43	17
.constant	k44	59
.constant	k45	186
.constant	k46	129
.constant	k47	228
.constant	k48	114
.constant	k49	106
.constant	k50	74
.constant	k51	163
.constant	k52	183
.constant	k53	184
.constant	k54	192
.constant	k55	50
.constant	k56	234
.constant	k57	90
.constant	k58	42
.constant	k59	91
.constant	k60	154
.constant	k61	76
.constant	k62	13
.constant	k63	80
.constant	k64	"tostring"
.constant	k65	"result"
.constant	k66	"bFamilyCenterQueryPending"
.constant	k67	"FamilyCenterQuerySeq"
.constant	k68	false
.constant	k69	"HandleOpenMLAIVoiceResult"

.line	504	gettabup      r1    u0    k0 ; k0 = "print"
.line	504	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	504	test          r2     0
.line	504	jmp            0   l87
.line	504	gettabup      r2    u0    k2 ; k2 = "string"
.line	504	gettable      r2    r2    k3 ; k3 = "format"
.line	504	gettabup      r3    u0    k4 ; k4 = "table"
.line	504	gettable      r3    r3    k5 ; k5 = "concat"
.line	504	newtable      r4     1     0
.line	504	getupval      r5    u1
.line	504	loadk         r6    k6 ; k6 = 149
.line	504	loadk         r7    k7 ; k7 = 51
.line	504	loadk         r8    k8 ; k8 = 25
.line	504	loadk         r9    k9 ; k9 = 150
.line	504	loadk        r10   k10 ; k10 = 134
.line	504	loadk        r11   k11 ; k11 = 254
.line	504	loadk        r12   k12 ; k12 = 126
.line	504	loadk        r13   k13 ; k13 = 123
.line	504	loadk        r14   k14 ; k14 = 86
.line	504	loadk        r15   k15 ; k15 = 197
.line	504	loadk        r16   k16 ; k16 = 162
.line	504	loadk        r17    k9 ; k9 = 150
.line	504	loadk        r18   k17 ; k17 = 191
.line	504	loadk        r19   k18 ; k18 = 198
.line	504	loadk        r20   k19 ; k19 = 108
.line	504	loadk        r21   k20 ; k20 = 175
.line	504	loadk        r22   k21 ; k21 = 18
.line	504	loadk        r23   k22 ; k22 = 28
.line	504	loadk        r24   k23 ; k23 = 92
.line	504	loadk        r25   k24 ; k24 = 142
.line	504	loadk        r26   k25 ; k25 = 82
.line	504	loadk        r27   k26 ; k26 = 213
.line	504	loadk        r28   k27 ; k27 = 33
.line	504	loadk        r29   k28 ; k28 = 73
.line	504	loadk        r30   k29 ; k29 = 78
.line	504	loadk        r31   k30 ; k30 = 250
.line	504	loadk        r32   k31 ; k31 = 187
.line	504	loadk        r33   k32 ; k32 = 158
.line	504	loadk        r34   k33 ; k33 = 152
.line	504	loadk        r35   k18 ; k18 = 198
.line	504	loadk        r36   k34 ; k34 = 96
.line	504	loadk        r37   k35 ; k35 = 174
.line	504	loadk        r38   k36 ; k36 = 93
.line	504	loadk        r39   k37 ; k37 = 45
.line	504	loadk        r40   k13 ; k13 = 123
.line	504	loadk        r41   k38 ; k38 = 144
.line	504	loadk        r42   k36 ; k36 = 93
.line	504	loadk        r43   k39 ; k39 = 193
.line	504	loadk        r44   k40 ; k40 = 27
.line	504	loadk        r45   k41 ; k41 = 81
.line	504	call          r5    41     2
.line	504	getupval      r6    u1
.line	504	loadk         r7   k42 ; k42 = 185
.line	504	loadk         r8   k43 ; k43 = 17
.line	504	loadk         r9   k44 ; k44 = 59
.line	504	loadk        r10   k45 ; k45 = 186
.line	504	loadk        r11   k46 ; k46 = 129
.line	504	loadk        r12   k47 ; k47 = 228
.line	504	loadk        r13   k48 ; k48 = 114
.line	504	loadk        r14   k49 ; k49 = 106
.line	504	loadk        r15   k50 ; k50 = 74
.line	504	loadk        r16   k51 ; k51 = 163
.line	504	loadk        r17   k52 ; k52 = 183
.line	504	loadk        r18    k9 ; k9 = 150
.line	504	loadk        r19   k53 ; k53 = 184
.line	504	loadk        r20   k54 ; k54 = 192
.line	504	loadk        r21   k55 ; k55 = 50
.line	504	loadk        r22   k56 ; k56 = 234
.line	504	loadk        r23   k57 ; k57 = 90
.line	504	loadk        r24   k58 ; k58 = 42
.line	504	loadk        r25   k59 ; k59 = 91
.line	504	loadk        r26   k60 ; k60 = 154
.line	504	loadk        r27   k61 ; k61 = 76
.line	504	loadk        r28   k26 ; k26 = 213
.line	504	loadk        r29   k36 ; k36 = 93
.line	504	loadk        r30   k62 ; k62 = 13
.line	504	loadk        r31   k63 ; k63 = 80
.line	504	call          r6    26     0
.line	504	setlist       r4     0     1
.line	504	call          r3     2     2
.line	504	gettabup      r4    u0   k64 ; k64 = "tostring"
.line	504	testset       r5    r0     0
.line	504	jmp            0   l85
.line	504	gettable      r5    r0   k65 ; k65 = "result"
.label	l85
.line	504	call          r4     2     0
.line	504	call          r2     0     2
.label	l87
.line	504	call          r1     2     1
.line	504	gettabup      r1    u2   k66 ; k66 = "bFamilyCenterQueryPe" (truncated)
.line	504	test          r1     0
.line	504	jmp            0   l95
.line	504	getupval      r1    u3
.line	504	gettabup      r2    u2   k67 ; k67 = "FamilyCenterQuerySeq"
.line	504	eq             1    r1    r2
.line	504	jmp            0   l96
.label	l95
.line	504	return        r0     1
.label	l96
.line	504	settabup      u2   k66   k68 ; k68 = false
.line	504	getupval      r1    u2
.line	504	self          r1    r1   k69 ; k69 = "HandleOpenMLAIVoiceR" (truncated)
.line	504	move          r3    r0
.line	504	call          r1     3     1
.line	504	return        r0     1
.line	504	move          r0    r0
.line	504	move          r0    r0
.line	504	move          r0    r0
.line	504	move          r0    r0
.line	504	return        r0     1

.function	main/f26/f2

.source	null
.linedefined	512
.lastlinedefined	523
.numparams	0
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	0	true
.upvalue	"U3"	4	true
.upvalue	"U4"	5	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	149
.constant	k5	51
.constant	k6	25
.constant	k7	150
.constant	k8	134
.constant	k9	254
.constant	k10	126
.constant	k11	123
.constant	k12	86
.constant	k13	197
.constant	k14	162
.constant	k15	191
.constant	k16	198
.constant	k17	108
.constant	k18	175
.constant	k19	18
.constant	k20	28
.constant	k21	92
.constant	k22	142
.constant	k23	82
.constant	k24	213
.constant	k25	33
.constant	k26	73
.constant	k27	78
.constant	k28	250
.constant	k29	187
.constant	k30	158
.constant	k31	152
.constant	k32	96
.constant	k33	174
.constant	k34	93
.constant	k35	45
.constant	k36	144
.constant	k37	193
.constant	k38	27
.constant	k39	81
.constant	k40	185
.constant	k41	17
.constant	k42	59
.constant	k43	186
.constant	k44	129
.constant	k45	228
.constant	k46	114
.constant	k47	106
.constant	k48	74
.constant	k49	163
.constant	k50	171
.constant	k51	146
.constant	k52	172
.constant	k53	210
.constant	k54	125
.constant	k55	179
.constant	k56	4
.constant	k57	111
.constant	k58	76
.constant	k59	205
.constant	k60	5
.constant	k61	64
.constant	k62	248
.constant	k63	247
.constant	k64	147
.constant	k65	180
.constant	k66	131
.constant	k67	75
.constant	k68	54
.constant	k69	91
.constant	k70	223
.constant	k71	212
.constant	k72	16
.constant	k73	89
.constant	k74	6
.constant	k75	120
.constant	k76	178
.constant	k77	255
.constant	k78	19
.constant	k79	224
.constant	k80	168
.constant	k81	216
.constant	k82	"bFamilyCenterQueryPending"
.constant	k83	"FamilyCenterQuerySeq"
.constant	k84	false
.constant	k85	"_bLegacyFallbackPass"
.constant	k86	"_IsMinorByLegacyCheck"
.constant	k87	"HandleOpenMLAIVoiceResult"
.constant	k88	"pass"

.line	512	gettabup      r0    u0    k0 ; k0 = "print"
.line	512	gettabup      r1    u0    k1 ; k1 = "bWriteLog"
.line	512	test          r1     0
.line	512	jmp            0  l110
.line	512	gettabup      r1    u0    k2 ; k2 = "table"
.line	512	gettable      r1    r1    k3 ; k3 = "concat"
.line	512	newtable      r2     2     0
.line	512	getupval      r3    u1
.line	512	loadk         r4    k4 ; k4 = 149
.line	512	loadk         r5    k5 ; k5 = 51
.line	512	loadk         r6    k6 ; k6 = 25
.line	512	loadk         r7    k7 ; k7 = 150
.line	512	loadk         r8    k8 ; k8 = 134
.line	512	loadk         r9    k9 ; k9 = 254
.line	512	loadk        r10   k10 ; k10 = 126
.line	512	loadk        r11   k11 ; k11 = 123
.line	512	loadk        r12   k12 ; k12 = 86
.line	512	loadk        r13   k13 ; k13 = 197
.line	512	loadk        r14   k14 ; k14 = 162
.line	512	loadk        r15    k7 ; k7 = 150
.line	512	loadk        r16   k15 ; k15 = 191
.line	512	loadk        r17   k16 ; k16 = 198
.line	512	loadk        r18   k17 ; k17 = 108
.line	512	loadk        r19   k18 ; k18 = 175
.line	512	loadk        r20   k19 ; k19 = 18
.line	512	loadk        r21   k20 ; k20 = 28
.line	512	loadk        r22   k21 ; k21 = 92
.line	512	loadk        r23   k22 ; k22 = 142
.line	512	loadk        r24   k23 ; k23 = 82
.line	512	loadk        r25   k24 ; k24 = 213
.line	512	loadk        r26   k25 ; k25 = 33
.line	512	loadk        r27   k26 ; k26 = 73
.line	512	loadk        r28   k27 ; k27 = 78
.line	512	loadk        r29   k28 ; k28 = 250
.line	512	loadk        r30   k29 ; k29 = 187
.line	512	loadk        r31   k30 ; k30 = 158
.line	512	loadk        r32   k31 ; k31 = 152
.line	512	loadk        r33   k16 ; k16 = 198
.line	512	loadk        r34   k32 ; k32 = 96
.line	512	loadk        r35   k33 ; k33 = 174
.line	512	loadk        r36   k34 ; k34 = 93
.line	512	loadk        r37   k35 ; k35 = 45
.line	512	loadk        r38   k11 ; k11 = 123
.line	512	loadk        r39   k36 ; k36 = 144
.line	512	loadk        r40   k34 ; k34 = 93
.line	512	loadk        r41   k37 ; k37 = 193
.line	512	loadk        r42   k38 ; k38 = 27
.line	512	loadk        r43   k39 ; k39 = 81
.line	512	call          r3    41     2
.line	512	getupval      r4    u1
.line	512	loadk         r5   k40 ; k40 = 185
.line	512	loadk         r6   k41 ; k41 = 17
.line	512	loadk         r7   k42 ; k42 = 59
.line	512	loadk         r8   k43 ; k43 = 186
.line	512	loadk         r9   k44 ; k44 = 129
.line	512	loadk        r10   k45 ; k45 = 228
.line	512	loadk        r11   k46 ; k46 = 114
.line	512	loadk        r12   k47 ; k47 = 106
.line	512	loadk        r13   k48 ; k48 = 74
.line	512	loadk        r14   k49 ; k49 = 163
.line	512	loadk        r15   k50 ; k50 = 171
.line	512	loadk        r16   k51 ; k51 = 146
.line	512	loadk        r17   k52 ; k52 = 172
.line	512	loadk        r18   k53 ; k53 = 210
.line	512	loadk        r19   k54 ; k54 = 125
.line	512	loadk        r20   k55 ; k55 = 179
.line	512	loadk        r21   k56 ; k56 = 4
.line	512	loadk        r22   k57 ; k57 = 111
.line	512	loadk        r23   k27 ; k27 = 78
.line	512	loadk        r24   k22 ; k22 = 142
.line	512	loadk        r25   k58 ; k58 = 76
.line	512	loadk        r26   k59 ; k59 = 205
.line	512	loadk        r27   k60 ; k60 = 5
.line	512	loadk        r28   k26 ; k26 = 73
.line	512	loadk        r29   k61 ; k61 = 64
.line	512	loadk        r30   k62 ; k62 = 248
.line	512	loadk        r31   k63 ; k63 = 247
.line	512	loadk        r32   k64 ; k64 = 147
.line	512	loadk        r33   k65 ; k65 = 180
.line	512	loadk        r34   k66 ; k66 = 131
.line	512	loadk        r35   k17 ; k17 = 108
.line	512	loadk        r36   k29 ; k29 = 187
.line	512	loadk        r37   k67 ; k67 = 75
.line	512	loadk        r38   k68 ; k68 = 54
.line	512	loadk        r39   k69 ; k69 = 91
.line	512	loadk        r40   k70 ; k70 = 223
.line	512	loadk        r41   k21 ; k21 = 92
.line	512	loadk        r42   k71 ; k71 = 212
.line	512	loadk        r43   k72 ; k72 = 16
.line	512	loadk        r44   k73 ; k73 = 89
.line	512	call          r4    41     2
.line	512	getupval      r5    u1
.line	512	loadk         r6   k29 ; k29 = 187
.line	512	loadk         r7   k74 ; k74 = 6
.line	512	loadk         r8   k75 ; k75 = 120
.line	512	loadk         r9   k76 ; k76 = 178
.line	512	loadk        r10   k40 ; k40 = 185
.line	512	loadk        r11   k77 ; k77 = 255
.line	512	loadk        r12   k75 ; k75 = 120
.line	512	loadk        r13   k47 ; k47 = 106
.line	512	loadk        r14   k78 ; k78 = 19
.line	512	loadk        r15   k79 ; k79 = 224
.line	512	loadk        r16   k18 ; k18 = 175
.line	512	loadk        r17   k51 ; k51 = 146
.line	512	loadk        r18   k80 ; k80 = 168
.line	512	loadk        r19   k81 ; k81 = 216
.line	512	call          r5    15     0
.line	512	setlist       r2     0     1
.line	512	call          r1     2     2
.label	l110
.line	512	call          r0     2     1
.line	512	gettabup      r0    u2   k82 ; k82 = "bFamilyCenterQueryPe" (truncated)
.line	512	test          r0     0
.line	512	jmp            0  l118
.line	512	getupval      r0    u3
.line	512	gettabup      r1    u2   k83 ; k83 = "FamilyCenterQuerySeq"
.line	512	eq             1    r0    r1
.line	512	jmp            0  l119
.label	l118
.line	512	return        r0     1
.label	l119
.line	512	settabup      u2   k82   k84 ; k84 = false
.line	512	loadbool      r0     1     0
.line	512	setupval      r0    u4
.line	512	getupval      r0    u2
.line	512	self          r0    r0   k86 ; k86 = "_IsMinorByLegacyChec" (truncated)
.line	512	call          r0     2     2
.line	512	not           r0    r0
.line	512	settabup      u2   k85    r0 ; k85 = "_bLegacyFallbackPass"
.line	512	getupval      r0    u2
.line	512	self          r0    r0   k87 ; k87 = "HandleOpenMLAIVoiceR" (truncated)
.line	512	newtable      r2     0     1
.line	512	gettabup      r3    u2   k85 ; k85 = "_bLegacyFallbackPass"
.line	512	settable      r2   k88    r3 ; k88 = "pass"
.line	512	call          r0     3     1
.line	512	return        r0     1
.line	512	move          r0    r0
.line	512	move          r0    r0
.line	512	move          r0    r0
.line	512	return        r0     1

.function	main/f26/f3

.source	null
.linedefined	524
.lastlinedefined	535
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	0	true
.upvalue	"U3"	4	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	28
.constant	k23	92
.constant	k24	142
.constant	k25	82
.constant	k26	213
.constant	k27	33
.constant	k28	73
.constant	k29	78
.constant	k30	250
.constant	k31	187
.constant	k32	158
.constant	k33	152
.constant	k34	96
.constant	k35	174
.constant	k36	93
.constant	k37	45
.constant	k38	144
.constant	k39	193
.constant	k40	27
.constant	k41	81
.constant	k42	185
.constant	k43	17
.constant	k44	59
.constant	k45	186
.constant	k46	129
.constant	k47	228
.constant	k48	114
.constant	k49	106
.constant	k50	74
.constant	k51	163
.constant	k52	178
.constant	k53	153
.constant	k54	170
.constant	k55	127
.constant	k56	68
.constant	k57	46
.constant	k58	131
.constant	k59	69
.constant	k60	141
.constant	k61	71
.constant	k62	90
.constant	k63	70
.constant	k64	224
.constant	k65	139
.constant	k66	43
.constant	k67	169
.constant	k68	20
.constant	k69	94
.constant	k70	221
.constant	k71	21
.constant	k72	89
.constant	k73	120
.constant	k74	171
.constant	k75	177
.constant	k76	117
.constant	k77	121
.constant	k78	64
.constant	k79	234
.constant	k80	164
.constant	k81	215
.constant	k82	167
.constant	k83	214
.constant	k84	75
.constant	k85	54
.constant	k86	8
.constant	k87	130
.constant	k88	207
.constant	k89	3
.constant	k90	240
.constant	k91	184
.constant	k92	200
.constant	k93	"tostring"
.constant	k94	"result"
.constant	k95	"bFamilyCenterQueryPending"
.constant	k96	"FamilyCenterQuerySeq"
.constant	k97	false
.constant	k98	"_bLegacyFallbackPass"
.constant	k99	"_IsMinorByLegacyCheck"
.constant	k100	"HandleOpenMLAIVoiceResult"
.constant	k101	"pass"

.line	524	gettabup      r1    u0    k0 ; k0 = "print"
.line	524	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	524	test          r2     0
.line	524	jmp            0  l134
.line	524	gettabup      r2    u0    k2 ; k2 = "string"
.line	524	gettable      r2    r2    k3 ; k3 = "format"
.line	524	gettabup      r3    u0    k4 ; k4 = "table"
.line	524	gettable      r3    r3    k5 ; k5 = "concat"
.line	524	newtable      r4     2     0
.line	524	getupval      r5    u1
.line	524	loadk         r6    k6 ; k6 = 149
.line	524	loadk         r7    k7 ; k7 = 51
.line	524	loadk         r8    k8 ; k8 = 25
.line	524	loadk         r9    k9 ; k9 = 150
.line	524	loadk        r10   k10 ; k10 = 134
.line	524	loadk        r11   k11 ; k11 = 254
.line	524	loadk        r12   k12 ; k12 = 126
.line	524	loadk        r13   k13 ; k13 = 123
.line	524	loadk        r14   k14 ; k14 = 86
.line	524	loadk        r15   k15 ; k15 = 197
.line	524	loadk        r16   k16 ; k16 = 162
.line	524	loadk        r17    k9 ; k9 = 150
.line	524	loadk        r18   k17 ; k17 = 191
.line	524	loadk        r19   k18 ; k18 = 198
.line	524	loadk        r20   k19 ; k19 = 108
.line	524	loadk        r21   k20 ; k20 = 175
.line	524	loadk        r22   k21 ; k21 = 18
.line	524	loadk        r23   k22 ; k22 = 28
.line	524	loadk        r24   k23 ; k23 = 92
.line	524	loadk        r25   k24 ; k24 = 142
.line	524	loadk        r26   k25 ; k25 = 82
.line	524	loadk        r27   k26 ; k26 = 213
.line	524	loadk        r28   k27 ; k27 = 33
.line	524	loadk        r29   k28 ; k28 = 73
.line	524	loadk        r30   k29 ; k29 = 78
.line	524	loadk        r31   k30 ; k30 = 250
.line	524	loadk        r32   k31 ; k31 = 187
.line	524	loadk        r33   k32 ; k32 = 158
.line	524	loadk        r34   k33 ; k33 = 152
.line	524	loadk        r35   k18 ; k18 = 198
.line	524	loadk        r36   k34 ; k34 = 96
.line	524	loadk        r37   k35 ; k35 = 174
.line	524	loadk        r38   k36 ; k36 = 93
.line	524	loadk        r39   k37 ; k37 = 45
.line	524	loadk        r40   k13 ; k13 = 123
.line	524	loadk        r41   k38 ; k38 = 144
.line	524	loadk        r42   k36 ; k36 = 93
.line	524	loadk        r43   k39 ; k39 = 193
.line	524	loadk        r44   k40 ; k40 = 27
.line	524	loadk        r45   k41 ; k41 = 81
.line	524	call          r5    41     2
.line	524	getupval      r6    u1
.line	524	loadk         r7   k42 ; k42 = 185
.line	524	loadk         r8   k43 ; k43 = 17
.line	524	loadk         r9   k44 ; k44 = 59
.line	524	loadk        r10   k45 ; k45 = 186
.line	524	loadk        r11   k46 ; k46 = 129
.line	524	loadk        r12   k47 ; k47 = 228
.line	524	loadk        r13   k48 ; k48 = 114
.line	524	loadk        r14   k49 ; k49 = 106
.line	524	loadk        r15   k50 ; k50 = 74
.line	524	loadk        r16   k51 ; k51 = 163
.line	524	loadk        r17   k52 ; k52 = 178
.line	524	loadk        r18   k53 ; k53 = 153
.line	524	loadk        r19   k54 ; k54 = 170
.line	524	loadk        r20   k15 ; k15 = 197
.line	524	loadk        r21   k55 ; k55 = 127
.line	524	loadk        r22   k51 ; k51 = 163
.line	524	loadk        r23   k56 ; k56 = 68
.line	524	loadk        r24   k57 ; k57 = 46
.line	524	loadk        r25   k50 ; k50 = 74
.line	524	loadk        r26   k58 ; k58 = 131
.line	524	loadk        r27   k59 ; k59 = 69
.line	524	loadk        r28   k60 ; k60 = 141
.line	524	loadk        r29   k61 ; k61 = 71
.line	524	loadk        r30   k62 ; k62 = 90
.line	524	loadk        r31   k63 ; k63 = 70
.line	524	loadk        r32   k64 ; k64 = 224
.line	524	loadk        r33   k16 ; k16 = 162
.line	524	loadk        r34   k65 ; k65 = 139
.line	524	loadk        r35   k20 ; k20 = 175
.line	524	loadk        r36   k53 ; k53 = 153
.line	524	loadk        r37   k66 ; k66 = 43
.line	524	loadk        r38   k67 ; k67 = 169
.line	524	loadk        r39   k68 ; k68 = 20
.line	524	loadk        r40   k55 ; k55 = 127
.line	524	loadk        r41   k69 ; k69 = 94
.line	524	loadk        r42   k32 ; k32 = 158
.line	524	loadk        r43   k23 ; k23 = 92
.line	524	loadk        r44   k70 ; k70 = 221
.line	524	loadk        r45   k71 ; k71 = 21
.line	524	loadk        r46   k72 ; k72 = 89
.line	524	call          r6    41     2
.line	524	getupval      r7    u1
.line	524	loadk         r8   k31 ; k31 = 187
.line	524	loadk         r9   k68 ; k68 = 20
.line	524	loadk        r10   k73 ; k73 = 120
.line	524	loadk        r11   k74 ; k74 = 171
.line	524	loadk        r12   k17 ; k17 = 191
.line	524	loadk        r13   k75 ; k75 = 177
.line	524	loadk        r14   k76 ; k76 = 117
.line	524	loadk        r15   k77 ; k77 = 121
.line	524	loadk        r16   k78 ; k78 = 64
.line	524	loadk        r17   k79 ; k79 = 234
.line	524	loadk        r18   k80 ; k80 = 164
.line	524	loadk        r19   k81 ; k81 = 215
.line	524	loadk        r20   k82 ; k82 = 167
.line	524	loadk        r21   k83 ; k83 = 214
.line	524	loadk        r22   k77 ; k77 = 121
.line	524	loadk        r23   k74 ; k74 = 171
.line	524	loadk        r24   k84 ; k84 = 75
.line	524	loadk        r25   k85 ; k85 = 54
.line	524	loadk        r26   k86 ; k86 = 8
.line	524	loadk        r27   k87 ; k87 = 130
.line	524	loadk        r28   k28 ; k28 = 73
.line	524	loadk        r29   k88 ; k88 = 207
.line	524	loadk        r30   k86 ; k86 = 8
.line	524	loadk        r31   k62 ; k62 = 90
.line	524	loadk        r32   k89 ; k89 = 3
.line	524	loadk        r33   k90 ; k90 = 240
.line	524	loadk        r34   k17 ; k17 = 191
.line	524	loadk        r35   k87 ; k87 = 130
.line	524	loadk        r36   k91 ; k91 = 184
.line	524	loadk        r37   k92 ; k92 = 200
.line	524	call          r7    31     0
.line	524	setlist       r4     0     1
.line	524	call          r3     2     2
.line	524	gettabup      r4    u0   k93 ; k93 = "tostring"
.line	524	testset       r5    r0     0
.line	524	jmp            0  l132
.line	524	gettable      r5    r0   k94 ; k94 = "result"
.label	l132
.line	524	call          r4     2     0
.line	524	call          r2     0     2
.label	l134
.line	524	call          r1     2     1
.line	524	gettabup      r1    u2   k95 ; k95 = "bFamilyCenterQueryPe" (truncated)
.line	524	test          r1     0
.line	524	jmp            0  l142
.line	524	getupval      r1    u3
.line	524	gettabup      r2    u2   k96 ; k96 = "FamilyCenterQuerySeq"
.line	524	eq             1    r1    r2
.line	524	jmp            0  l144
.label	l142
.line	524	loadbool      r1     1     0
.line	524	return        r1     2
.label	l144
.line	524	settabup      u2   k95   k97 ; k97 = false
.line	524	getupval      r1    u2
.line	524	self          r1    r1   k99 ; k99 = "_IsMinorByLegacyChec" (truncated)
.line	524	call          r1     2     2
.line	524	not           r1    r1
.line	524	settabup      u2   k98    r1 ; k98 = "_bLegacyFallbackPass"
.line	524	getupval      r1    u2
.line	524	self          r1    r1  k100 ; k100 = "HandleOpenMLAIVoiceR" (truncated)
.line	524	newtable      r3     0     1
.line	524	gettabup      r4    u2   k98 ; k98 = "_bLegacyFallbackPass"
.line	524	settable      r3  k101    r4 ; k101 = "pass"
.line	524	call          r1     3     1
.line	524	loadbool      r1     1     0
.line	524	return        r1     2
.line	524	return        r0     1
.line	524	move          r0    r0
.line	524	move          r0    r0
.line	524	move          r0    r0
.line	524	return        r0     1

.function	main/f26/f4

.source	null
.linedefined	536
.lastlinedefined	544
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	0	true
.upvalue	"U3"	4	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	28
.constant	k23	92
.constant	k24	142
.constant	k25	82
.constant	k26	213
.constant	k27	33
.constant	k28	73
.constant	k29	78
.constant	k30	250
.constant	k31	187
.constant	k32	158
.constant	k33	152
.constant	k34	96
.constant	k35	174
.constant	k36	93
.constant	k37	45
.constant	k38	144
.constant	k39	193
.constant	k40	27
.constant	k41	81
.constant	k42	185
.constant	k43	17
.constant	k44	59
.constant	k45	186
.constant	k46	129
.constant	k47	228
.constant	k48	114
.constant	k49	106
.constant	k50	74
.constant	k51	163
.constant	k52	165
.constant	k53	155
.constant	k54	164
.constant	k55	208
.constant	k56	117
.constant	k57	76
.constant	k58	99
.constant	k59	8
.constant	k60	157
.constant	k61	69
.constant	k62	210
.constant	k63	68
.constant	k64	87
.constant	k65	169
.constant	k66	242
.constant	k67	148
.constant	k68	"tostring"
.constant	k69	"result"
.constant	k70	"bFamilyCenterQueryPending"
.constant	k71	"FamilyCenterQuerySeq"
.constant	k72	false
.constant	k73	"HandleOpenMLAIVoiceResult"

.line	536	gettabup      r1    u0    k0 ; k0 = "print"
.line	536	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	536	test          r2     0
.line	536	jmp            0   l90
.line	536	gettabup      r2    u0    k2 ; k2 = "string"
.line	536	gettable      r2    r2    k3 ; k3 = "format"
.line	536	gettabup      r3    u0    k4 ; k4 = "table"
.line	536	gettable      r3    r3    k5 ; k5 = "concat"
.line	536	newtable      r4     1     0
.line	536	getupval      r5    u1
.line	536	loadk         r6    k6 ; k6 = 149
.line	536	loadk         r7    k7 ; k7 = 51
.line	536	loadk         r8    k8 ; k8 = 25
.line	536	loadk         r9    k9 ; k9 = 150
.line	536	loadk        r10   k10 ; k10 = 134
.line	536	loadk        r11   k11 ; k11 = 254
.line	536	loadk        r12   k12 ; k12 = 126
.line	536	loadk        r13   k13 ; k13 = 123
.line	536	loadk        r14   k14 ; k14 = 86
.line	536	loadk        r15   k15 ; k15 = 197
.line	536	loadk        r16   k16 ; k16 = 162
.line	536	loadk        r17    k9 ; k9 = 150
.line	536	loadk        r18   k17 ; k17 = 191
.line	536	loadk        r19   k18 ; k18 = 198
.line	536	loadk        r20   k19 ; k19 = 108
.line	536	loadk        r21   k20 ; k20 = 175
.line	536	loadk        r22   k21 ; k21 = 18
.line	536	loadk        r23   k22 ; k22 = 28
.line	536	loadk        r24   k23 ; k23 = 92
.line	536	loadk        r25   k24 ; k24 = 142
.line	536	loadk        r26   k25 ; k25 = 82
.line	536	loadk        r27   k26 ; k26 = 213
.line	536	loadk        r28   k27 ; k27 = 33
.line	536	loadk        r29   k28 ; k28 = 73
.line	536	loadk        r30   k29 ; k29 = 78
.line	536	loadk        r31   k30 ; k30 = 250
.line	536	loadk        r32   k31 ; k31 = 187
.line	536	loadk        r33   k32 ; k32 = 158
.line	536	loadk        r34   k33 ; k33 = 152
.line	536	loadk        r35   k18 ; k18 = 198
.line	536	loadk        r36   k34 ; k34 = 96
.line	536	loadk        r37   k35 ; k35 = 174
.line	536	loadk        r38   k36 ; k36 = 93
.line	536	loadk        r39   k37 ; k37 = 45
.line	536	loadk        r40   k13 ; k13 = 123
.line	536	loadk        r41   k38 ; k38 = 144
.line	536	loadk        r42   k36 ; k36 = 93
.line	536	loadk        r43   k39 ; k39 = 193
.line	536	loadk        r44   k40 ; k40 = 27
.line	536	loadk        r45   k41 ; k41 = 81
.line	536	call          r5    41     2
.line	536	getupval      r6    u1
.line	536	loadk         r7   k42 ; k42 = 185
.line	536	loadk         r8   k43 ; k43 = 17
.line	536	loadk         r9   k44 ; k44 = 59
.line	536	loadk        r10   k45 ; k45 = 186
.line	536	loadk        r11   k46 ; k46 = 129
.line	536	loadk        r12   k47 ; k47 = 228
.line	536	loadk        r13   k48 ; k48 = 114
.line	536	loadk        r14   k49 ; k49 = 106
.line	536	loadk        r15   k50 ; k50 = 74
.line	536	loadk        r16   k51 ; k51 = 163
.line	536	loadk        r17   k52 ; k52 = 165
.line	536	loadk        r18   k53 ; k53 = 155
.line	536	loadk        r19   k54 ; k54 = 164
.line	536	loadk        r20   k55 ; k55 = 208
.line	536	loadk        r21   k56 ; k56 = 117
.line	536	loadk        r22   k20 ; k20 = 175
.line	536	loadk        r23   k57 ; k57 = 76
.line	536	loadk        r24   k58 ; k58 = 99
.line	536	loadk        r25   k59 ; k59 = 8
.line	536	loadk        r26   k60 ; k60 = 157
.line	536	loadk        r27   k61 ; k61 = 69
.line	536	loadk        r28   k62 ; k62 = 210
.line	536	loadk        r29   k21 ; k21 = 18
.line	536	loadk        r30   k63 ; k63 = 68
.line	536	loadk        r31   k64 ; k64 = 87
.line	536	loadk        r32   k65 ; k65 = 169
.line	536	loadk        r33   k66 ; k66 = 242
.line	536	loadk        r34   k67 ; k67 = 148
.line	536	call          r6    29     0
.line	536	setlist       r4     0     1
.line	536	call          r3     2     2
.line	536	gettabup      r4    u0   k68 ; k68 = "tostring"
.line	536	testset       r5    r0     0
.line	536	jmp            0   l88
.line	536	gettable      r5    r0   k69 ; k69 = "result"
.label	l88
.line	536	call          r4     2     0
.line	536	call          r2     0     2
.label	l90
.line	536	call          r1     2     1
.line	536	gettabup      r1    u2   k70 ; k70 = "bFamilyCenterQueryPe" (truncated)
.line	536	test          r1     0
.line	536	jmp            0   l98
.line	536	getupval      r1    u3
.line	536	gettabup      r2    u2   k71 ; k71 = "FamilyCenterQuerySeq"
.line	536	eq             1    r1    r2
.line	536	jmp            0  l100
.label	l98
.line	536	loadbool      r1     1     0
.line	536	return        r1     2
.label	l100
.line	536	settabup      u2   k70   k72 ; k72 = false
.line	536	getupval      r1    u2
.line	536	self          r1    r1   k73 ; k73 = "HandleOpenMLAIVoiceR" (truncated)
.line	536	move          r3    r0
.line	536	call          r1     3     1
.line	536	loadbool      r1     0     0
.line	536	return        r1     2
.line	536	return        r0     1
.line	536	move          r0    r0
.line	536	move          r0    r0
.line	536	return        r0     1

.function	main/f27

.source	null
.linedefined	552
.lastlinedefined	577
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	6	true

.constant	k0	"bOpenMLAIVoice"
.constant	k1	true
.constant	k2	"_IsPublicOpinionScene"
.constant	k3	"RegistSceneEvent"
.constant	k4	"ChangeClientVoiceState"
.constant	k5	"nRSTSSceneID"
.constant	k6	0
.constant	k7	"pass"
.constant	k8	nil
.constant	k9	"_CheckMinorCompliance"
.constant	k10	"EventSystem"
.constant	k11	"postEvent"
.constant	k12	"EVENTTYPE_ANTSVOICE"
.constant	k13	"EVENTID_ANTSVOICE_CANNOT_OPEN"
.constant	k14	"print"
.constant	k15	"bWriteLog"
.constant	k16	"table"
.constant	k17	"concat"
.constant	k18	149
.constant	k19	51
.constant	k20	25
.constant	k21	150
.constant	k22	134
.constant	k23	254
.constant	k24	126
.constant	k25	123
.constant	k26	86
.constant	k27	197
.constant	k28	162
.constant	k29	191
.constant	k30	198
.constant	k31	108
.constant	k32	175
.constant	k33	18
.constant	k34	7
.constant	k35	73
.constant	k36	129
.constant	k37	68
.constant	k38	205
.constant	k39	2
.constant	k40	103
.constant	k41	83
.constant	k42	246
.constant	k43	185
.constant	k44	170
.constant	k45	151
.constant	k46	226
.constant	k47	71
.constant	k48	140
.constant	k49	87
.constant	k50	54
.constant	k51	91
.constant	k52	154
.constant	k53	98
.constant	k54	212
.constant	k55	4
.constant	k56	77
.constant	k57	180
.constant	k58	11
.constant	k59	116
.constant	k60	255
.constant	k61	179
.constant	k62	240
.constant	k63	121
.constant	k64	56
.constant	k65	93
.constant	k66	236
.constant	k67	215
.constant	k68	164
.constant	k69	195
.constant	k70	8
.constant	k71	100
.constant	k72	174
.constant	k73	105
.constant	k74	247
.constant	k75	65
.constant	k76	64
.constant	k77	"SendMLAIVoiceDebugInfo"
.constant	k78	"ClientRefuse"
.constant	k79	16
.constant	k80	190
.constant	k81	183
.constant	k82	244

.line	552	gettable      r2    r0    k0 ; k0 = "bOpenMLAIVoice"
.line	552	eq             1    r2    k1 ; k1 = true
.line	552	jmp            0    l5
.line	552	return        r0     1
.label	l5
.line	552	self          r2    r0    k2 ; k2 = "_IsPublicOpinionScen" (truncated)
.line	552	call          r2     2     2
.line	552	test          r2     0
.line	552	jmp            0   l15
.line	552	self          r2    r0    k3 ; k3 = "RegistSceneEvent"
.line	552	call          r2     2     1
.line	552	self          r2    r0    k4 ; k4 = "ChangeClientVoiceSta" (truncated)
.line	552	gettable      r4    r0    k5 ; k5 = "nRSTSSceneID"
.line	552	call          r2     3     1
.line	552	return        r0     1
.label	l15
.line	552	gettable      r2    r0    k5 ; k5 = "nRSTSSceneID"
.line	552	test          r2     1
.line	552	jmp            0   l19
.line	552	loadk         r2    k6 ; k6 = 0
.label	l19
.line	552	le             0    r2    k6 ; k6 = 0
.line	552	jmp            0   l22
.line	552	return        r0     1
.label	l22
.line	552	testset       r2    r1     0
.line	552	jmp            0   l29
.line	552	gettable      r2    r1    k7 ; k7 = "pass"
.line	552	eq             1    r2    k1 ; k1 = true
.line	552	jmp            0   l28
.line	552	loadbool      r2     0     1
.label	l28
.line	552	loadbool      r2     1     0
.label	l29
.line	552	eq             0    r1    k8 ; k8 = nil
.line	552	jmp            0   l34
.line	552	self          r3    r0    k9 ; k9 = "_CheckMinorComplianc" (truncated)
.line	552	call          r3     2     2
.line	552	move          r2    r3
.label	l34
.line	552	test          r2     1
.line	552	jmp            0  l136
.line	552	self          r3    r0    k4 ; k4 = "ChangeClientVoiceSta" (truncated)
.line	552	loadk         r5    k6 ; k6 = 0
.line	552	call          r3     3     1
.line	552	gettabup      r3    u0   k10 ; k10 = "EventSystem"
.line	552	self          r3    r3   k11 ; k11 = "postEvent"
.line	552	gettabup      r5    u0   k12 ; k12 = "EVENTTYPE_ANTSVOICE"
.line	552	gettabup      r6    u0   k13 ; k13 = "EVENTID_ANTSVOICE_CA" (truncated)
.line	552	call          r3     4     1
.line	552	gettabup      r3    u0   k14 ; k14 = "print"
.line	552	gettabup      r4    u0   k15 ; k15 = "bWriteLog"
.line	552	test          r4     0
.line	552	jmp            0  l123
.line	552	gettabup      r4    u0   k16 ; k16 = "table"
.line	552	gettable      r4    r4   k17 ; k17 = "concat"
.line	552	newtable      r5     1     0
.line	552	getupval      r6    u1
.line	552	loadk         r7   k18 ; k18 = 149
.line	552	loadk         r8   k19 ; k19 = 51
.line	552	loadk         r9   k20 ; k20 = 25
.line	552	loadk        r10   k21 ; k21 = 150
.line	552	loadk        r11   k22 ; k22 = 134
.line	552	loadk        r12   k23 ; k23 = 254
.line	552	loadk        r13   k24 ; k24 = 126
.line	552	loadk        r14   k25 ; k25 = 123
.line	552	loadk        r15   k26 ; k26 = 86
.line	552	loadk        r16   k27 ; k27 = 197
.line	552	loadk        r17   k28 ; k28 = 162
.line	552	loadk        r18   k21 ; k21 = 150
.line	552	loadk        r19   k29 ; k29 = 191
.line	552	loadk        r20   k30 ; k30 = 198
.line	552	loadk        r21   k31 ; k31 = 108
.line	552	loadk        r22   k32 ; k32 = 175
.line	552	loadk        r23   k33 ; k33 = 18
.line	552	loadk        r24   k34 ; k34 = 7
.line	552	loadk        r25   k35 ; k35 = 73
.line	552	loadk        r26   k36 ; k36 = 129
.line	552	loadk        r27   k37 ; k37 = 68
.line	552	loadk        r28   k38 ; k38 = 205
.line	552	loadk        r29   k39 ; k39 = 2
.line	552	loadk        r30   k40 ; k40 = 103
.line	552	loadk        r31   k41 ; k41 = 83
.line	552	loadk        r32   k42 ; k42 = 246
.line	552	loadk        r33   k43 ; k43 = 185
.line	552	loadk        r34   k44 ; k44 = 170
.line	552	loadk        r35   k45 ; k45 = 151
.line	552	loadk        r36   k46 ; k46 = 226
.line	552	loadk        r37   k47 ; k47 = 71
.line	552	loadk        r38   k48 ; k48 = 140
.line	552	loadk        r39   k49 ; k49 = 87
.line	552	loadk        r40   k50 ; k50 = 54
.line	552	loadk        r41   k51 ; k51 = 91
.line	552	loadk        r42   k52 ; k52 = 154
.line	552	loadk        r43   k53 ; k53 = 98
.line	552	loadk        r44   k54 ; k54 = 212
.line	552	loadk        r45   k55 ; k55 = 4
.line	552	loadk        r46   k56 ; k56 = 77
.line	552	call          r6    41     2
.line	552	getupval      r7    u1
.line	552	loadk         r8   k57 ; k57 = 180
.line	552	loadk         r9   k58 ; k58 = 11
.line	552	loadk        r10   k59 ; k59 = 116
.line	552	loadk        r11   k60 ; k60 = 255
.line	552	loadk        r12   k61 ; k61 = 179
.line	552	loadk        r13   k62 ; k62 = 240
.line	552	loadk        r14   k63 ; k63 = 121
.line	552	loadk        r15   k64 ; k64 = 56
.line	552	loadk        r16   k65 ; k65 = 93
.line	552	loadk        r17   k66 ; k66 = 236
.line	552	loadk        r18   k61 ; k61 = 179
.line	552	loadk        r19   k67 ; k67 = 215
.line	552	loadk        r20   k68 ; k68 = 164
.line	552	loadk        r21   k69 ; k69 = 195
.line	552	loadk        r22   k25 ; k25 = 123
.line	552	loadk        r23   k68 ; k68 = 164
.line	552	loadk        r24   k70 ; k70 = 8
.line	552	loadk        r25   k39 ; k39 = 2
.line	552	loadk        r26   k71 ; k71 = 100
.line	552	loadk        r27   k72 ; k72 = 174
.line	552	loadk        r28   k73 ; k73 = 105
.line	552	loadk        r29   k74 ; k74 = 247
.line	552	loadk        r30   k70 ; k70 = 8
.line	552	loadk        r31   k75 ; k75 = 65
.line	552	loadk        r32   k76 ; k76 = 64
.line	552	loadk        r33   k42 ; k42 = 246
.line	552	call          r7    27     0
.line	552	setlist       r5     0     1
.line	552	call          r4     2     2
.label	l123
.line	552	call          r3     2     1
.line	552	self          r3    r0   k77 ; k77 = "SendMLAIVoiceDebugIn" (truncated)
.line	552	gettabup      r5    u2   k78 ; k78 = "ClientRefuse"
.line	552	getupval      r6    u1
.line	552	loadk         r7   k21 ; k21 = 150
.line	552	loadk         r8   k79 ; k79 = 16
.line	552	loadk         r9   k50 ; k50 = 54
.line	552	loadk        r10   k80 ; k80 = 190
.line	552	loadk        r11   k81 ; k81 = 183
.line	552	loadk        r12   k82 ; k82 = 244
.line	552	call          r6     7     2
.line	552	call          r3     4     1
.line	552	return        r0     1
.label	l136
.line	552	self          r3    r0    k3 ; k3 = "RegistSceneEvent"
.line	552	call          r3     2     1
.line	552	self          r3    r0    k4 ; k4 = "ChangeClientVoiceSta" (truncated)
.line	552	gettable      r5    r0    k5 ; k5 = "nRSTSSceneID"
.line	552	call          r3     3     1
.line	552	return        r0     1
.line	552	move          r0    r0
.line	552	return        r0     1

.function	main/f28

.source	null
.linedefined	579
.lastlinedefined	586
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	0
.constant	k23	70
.constant	k24	189
.constant	k25	69
.constant	k26	209
.constant	k27	56
.constant	k28	113
.constant	k29	192
.constant	k30	131
.constant	k31	180
.constant	k32	136
.constant	k33	107
.constant	k34	93
.constant	k35	22
.constant	k36	124
.constant	k37	211
.constant	k38	16
.constant	k39	27
.constant	k40	92
.constant	k41	142
.constant	k42	30
.constant	k43	52
.constant	k44	170
.constant	k45	181
.constant	k46	171
.constant	k47	50
.constant	k48	31
.constant	k49	163
.constant	k50	137
.constant	k51	146
.constant	k52	188
.constant	k53	229
.constant	k54	127
.constant	k55	166
.constant	k56	42
.constant	k57	202
.constant	k58	83
.constant	k59	"tostring"
.constant	k60	"nRSTSSceneID"
.constant	k61	"bFamilyCenterQueryPending"
.constant	k62	223
.constant	k63	208
.constant	k64	26
.constant	k65	81
.constant	k66	6
.constant	k67	59
.constant	k68	186
.constant	k69	190
.constant	k70	114
.constant	k71	106
.constant	k72	19
.constant	k73	242
.constant	k74	178
.constant	k75	185
.constant	k76	62
.constant	k77	77
.constant	k78	33
.constant	k79	76
.constant	k80	78
.constant	k81	75
.constant	k82	8
.constant	k83	80
.constant	k84	248
.constant	k85	151
.constant	k86	"_ApplySceneWithCompliance"
.constant	k87	17
.constant	k88	10
.constant	k89	160
.constant	k90	206
.constant	k91	121
.constant	k92	74
.constant	k93	96
.constant	k94	215
.constant	k95	148
.constant	k96	164
.constant	k97	168
.constant	k98	214
.constant	k99	112
.constant	k100	97
.constant	k101	11

.line	579	gettabup      r2    u0    k0 ; k0 = "print"
.line	579	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	579	test          r3     0
.line	579	jmp            0   l84
.line	579	gettabup      r3    u0    k2 ; k2 = "string"
.line	579	gettable      r3    r3    k3 ; k3 = "format"
.line	579	gettabup      r4    u0    k4 ; k4 = "table"
.line	579	gettable      r4    r4    k5 ; k5 = "concat"
.line	579	newtable      r5     1     0
.line	579	getupval      r6    u1
.line	579	loadk         r7    k6 ; k6 = 149
.line	579	loadk         r8    k7 ; k7 = 51
.line	579	loadk         r9    k8 ; k8 = 25
.line	579	loadk        r10    k9 ; k9 = 150
.line	579	loadk        r11   k10 ; k10 = 134
.line	579	loadk        r12   k11 ; k11 = 254
.line	579	loadk        r13   k12 ; k12 = 126
.line	579	loadk        r14   k13 ; k13 = 123
.line	579	loadk        r15   k14 ; k14 = 86
.line	579	loadk        r16   k15 ; k15 = 197
.line	579	loadk        r17   k16 ; k16 = 162
.line	579	loadk        r18    k9 ; k9 = 150
.line	579	loadk        r19   k17 ; k17 = 191
.line	579	loadk        r20   k18 ; k18 = 198
.line	579	loadk        r21   k19 ; k19 = 108
.line	579	loadk        r22   k20 ; k20 = 175
.line	579	loadk        r23   k21 ; k21 = 18
.line	579	loadk        r24   k22 ; k22 = 0
.line	579	loadk        r25   k23 ; k23 = 70
.line	579	loadk        r26   k24 ; k24 = 189
.line	579	loadk        r27   k25 ; k25 = 69
.line	579	loadk        r28   k26 ; k26 = 209
.line	579	loadk        r29   k27 ; k27 = 56
.line	579	loadk        r30   k23 ; k23 = 70
.line	579	loadk        r31   k28 ; k28 = 113
.line	579	loadk        r32   k29 ; k29 = 192
.line	579	loadk        r33   k30 ; k30 = 131
.line	579	loadk        r34   k31 ; k31 = 180
.line	579	loadk        r35   k32 ; k32 = 136
.line	579	loadk        r36   k29 ; k29 = 192
.line	579	loadk        r37   k33 ; k33 = 107
.line	579	loadk        r38   k31 ; k31 = 180
.line	579	loadk        r39   k34 ; k34 = 93
.line	579	loadk        r40   k35 ; k35 = 22
.line	579	loadk        r41   k36 ; k36 = 124
.line	579	loadk        r42   k37 ; k37 = 211
.line	579	loadk        r43   k38 ; k38 = 16
.line	579	loadk        r44   k11 ; k11 = 254
.line	579	loadk        r45   k39 ; k39 = 27
.line	579	loadk        r46   k40 ; k40 = 92
.line	579	call          r6    41     2
.line	579	getupval      r7    u1
.line	579	loadk         r8   k41 ; k41 = 142
.line	579	loadk         r9   k42 ; k42 = 30
.line	579	loadk        r10   k43 ; k43 = 52
.line	579	loadk        r11   k44 ; k44 = 170
.line	579	loadk        r12   k45 ; k45 = 181
.line	579	loadk        r13   k46 ; k46 = 171
.line	579	loadk        r14   k47 ; k47 = 50
.line	579	loadk        r15   k33 ; k33 = 107
.line	579	loadk        r16   k48 ; k48 = 31
.line	579	loadk        r17   k49 ; k49 = 163
.line	579	loadk        r18   k50 ; k50 = 137
.line	579	loadk        r19   k51 ; k51 = 146
.line	579	loadk        r20   k52 ; k52 = 188
.line	579	loadk        r21   k53 ; k53 = 229
.line	579	loadk        r22   k54 ; k54 = 127
.line	579	loadk        r23   k55 ; k55 = 166
.line	579	loadk        r24   k34 ; k34 = 93
.line	579	loadk        r25   k56 ; k56 = 42
.line	579	loadk        r26   k21 ; k21 = 18
.line	579	loadk        r27   k57 ; k57 = 202
.line	579	loadk        r28   k58 ; k58 = 83
.line	579	call          r7    22     0
.line	579	setlist       r5     0     1
.line	579	call          r4     2     2
.line	579	gettabup      r5    u0   k59 ; k59 = "tostring"
.line	579	move          r6    r1
.line	579	call          r5     2     2
.line	579	gettabup      r6    u0   k59 ; k59 = "tostring"
.line	579	gettable      r7    r0   k60 ; k60 = "nRSTSSceneID"
.line	579	call          r6     2     0
.line	579	call          r3     0     2
.label	l84
.line	579	call          r2     2     1
.line	579	gettable      r2    r0   k61 ; k61 = "bFamilyCenterQueryPe" (truncated)
.line	579	test          r2     0
.line	579	jmp            0  l171
.line	579	gettabup      r2    u0    k0 ; k0 = "print"
.line	579	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	579	test          r3     0
.line	579	jmp            0  l169
.line	579	gettabup      r3    u0    k4 ; k4 = "table"
.line	579	gettable      r3    r3    k5 ; k5 = "concat"
.line	579	newtable      r4     1     0
.line	579	getupval      r5    u1
.line	579	loadk         r6    k6 ; k6 = 149
.line	579	loadk         r7    k7 ; k7 = 51
.line	579	loadk         r8    k8 ; k8 = 25
.line	579	loadk         r9    k9 ; k9 = 150
.line	579	loadk        r10   k10 ; k10 = 134
.line	579	loadk        r11   k11 ; k11 = 254
.line	579	loadk        r12   k12 ; k12 = 126
.line	579	loadk        r13   k13 ; k13 = 123
.line	579	loadk        r14   k14 ; k14 = 86
.line	579	loadk        r15   k15 ; k15 = 197
.line	579	loadk        r16   k16 ; k16 = 162
.line	579	loadk        r17    k9 ; k9 = 150
.line	579	loadk        r18   k17 ; k17 = 191
.line	579	loadk        r19   k18 ; k18 = 198
.line	579	loadk        r20   k19 ; k19 = 108
.line	579	loadk        r21   k20 ; k20 = 175
.line	579	loadk        r22   k21 ; k21 = 18
.line	579	loadk        r23   k22 ; k22 = 0
.line	579	loadk        r24   k23 ; k23 = 70
.line	579	loadk        r25   k24 ; k24 = 189
.line	579	loadk        r26   k25 ; k25 = 69
.line	579	loadk        r27   k26 ; k26 = 209
.line	579	loadk        r28   k27 ; k27 = 56
.line	579	loadk        r29   k23 ; k23 = 70
.line	579	loadk        r30   k28 ; k28 = 113
.line	579	loadk        r31   k29 ; k29 = 192
.line	579	loadk        r32   k30 ; k30 = 131
.line	579	loadk        r33   k31 ; k31 = 180
.line	579	loadk        r34   k32 ; k32 = 136
.line	579	loadk        r35   k29 ; k29 = 192
.line	579	loadk        r36   k33 ; k33 = 107
.line	579	loadk        r37   k31 ; k31 = 180
.line	579	loadk        r38   k34 ; k34 = 93
.line	579	loadk        r39   k35 ; k35 = 22
.line	579	loadk        r40   k36 ; k36 = 124
.line	579	loadk        r41   k62 ; k62 = 223
.line	579	loadk        r42   k14 ; k14 = 86
.line	579	loadk        r43   k63 ; k63 = 208
.line	579	loadk        r44   k64 ; k64 = 26
.line	579	loadk        r45   k65 ; k65 = 81
.line	579	call          r5    41     2
.line	579	getupval      r6    u1
.line	579	loadk         r7   k31 ; k31 = 180
.line	579	loadk         r8   k66 ; k66 = 6
.line	579	loadk         r9   k67 ; k67 = 59
.line	579	loadk        r10   k68 ; k68 = 186
.line	579	loadk        r11   k69 ; k69 = 190
.line	579	loadk        r12   k53 ; k53 = 229
.line	579	loadk        r13   k70 ; k70 = 114
.line	579	loadk        r14   k71 ; k71 = 106
.line	579	loadk        r15   k72 ; k72 = 19
.line	579	loadk        r16   k73 ; k73 = 242
.line	579	loadk        r17   k74 ; k74 = 178
.line	579	loadk        r18   k51 ; k51 = 146
.line	579	loadk        r19   k75 ; k75 = 185
.line	579	loadk        r20   k57 ; k57 = 202
.line	579	loadk        r21   k76 ; k76 = 62
.line	579	loadk        r22   k68 ; k68 = 186
.line	579	loadk        r23   k77 ; k77 = 77
.line	579	loadk        r24   k78 ; k78 = 33
.line	579	loadk        r25   k79 ; k79 = 76
.line	579	loadk        r26   k10 ; k10 = 134
.line	579	loadk        r27   k80 ; k80 = 78
.line	579	loadk        r28   k18 ; k18 = 198
.line	579	loadk        r29   k81 ; k81 = 75
.line	579	loadk        r30   k82 ; k82 = 8
.line	579	loadk        r31   k83 ; k83 = 80
.line	579	loadk        r32   k84 ; k84 = 248
.line	579	loadk        r33   k69 ; k69 = 190
.line	579	loadk        r34   k85 ; k85 = 151
.line	579	call          r6    29     0
.line	579	setlist       r4     0     1
.line	579	call          r3     2     2
.label	l169
.line	579	call          r2     2     1
.line	579	return        r0     1
.label	l171
.line	579	self          r2    r0   k86 ; k86 = "_ApplySceneWithCompl" (truncated)
.line	579	gettable      r4    r0   k60 ; k60 = "nRSTSSceneID"
.line	579	getupval      r5    u1
.line	579	loadk         r6   k85 ; k85 = 151
.line	579	loadk         r7   k87 ; k87 = 17
.line	579	loadk         r8   k88 ; k88 = 10
.line	579	loadk         r9   k68 ; k68 = 186
.line	579	loadk        r10   k89 ; k89 = 160
.line	579	loadk        r11   k90 ; k90 = 206
.line	579	loadk        r12   k91 ; k91 = 121
.line	579	loadk        r13   k92 ; k92 = 74
.line	579	loadk        r14   k93 ; k93 = 96
.line	579	loadk        r15   k94 ; k94 = 215
.line	579	loadk        r16   k95 ; k95 = 148
.line	579	loadk        r17   k96 ; k96 = 164
.line	579	loadk        r18   k97 ; k97 = 168
.line	579	loadk        r19   k98 ; k98 = 214
.line	579	loadk        r20   k99 ; k99 = 112
.line	579	loadk        r21   k20 ; k20 = 175
.line	579	loadk        r22  k100 ; k100 = 97
.line	579	loadk        r23  k101 ; k101 = 11
.line	579	call          r5    19     2
.line	579	call          r2     4     1
.line	579	return        r0     1
.line	579	gettabup      r3    u0   k66 ; k66 = 6
.line	579	return        r0     1

.function	main/f29

.source	null
.linedefined	588
.lastlinedefined	613
.numparams	3
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	false
.upvalue	"U1"	3	true

.constant	k0	"Client"
.constant	k1	"bOpenMLAIVoice"
.constant	k2	true
.constant	k3	0
.constant	k4	"EnabledRSTSSceneID"
.constant	k5	"ChangeClientVoiceState"
.constant	k6	"UnRegistSceneEvent"
.constant	k7	"Enum_ASRSceneID"
.constant	k8	"PublicOpinion"
.constant	k9	"RegistSceneEvent"
.constant	k10	"StartFamilyCenterComplianceQuery"
.constant	k11	"HandleOpenMLAIVoiceResult"

.line	588	gettabup      r3    u0    k0 ; k0 = "Client"
.line	588	test          r3     1
.line	588	jmp            0    l5
.line	588	return        r0     1
.label	l5
.line	588	gettable      r3    r0    k1 ; k1 = "bOpenMLAIVoice"
.line	588	eq             1    r3    k2 ; k2 = true
.line	588	jmp            0   l18
.line	588	gettable      r3    r0    k4 ; k4 = "EnabledRSTSSceneID"
.line	588	test          r3     1
.line	588	jmp            0   l12
.line	588	loadk         r3    k3 ; k3 = 0
.label	l12
.line	588	lt             0    k3    r3 ; k3 = 0
.line	588	jmp            0   l17
.line	588	self          r3    r0    k5 ; k5 = "ChangeClientVoiceSta" (truncated)
.line	588	loadk         r5    k3 ; k3 = 0
.line	588	call          r3     3     1
.label	l17
.line	588	return        r0     1
.label	l18
.line	588	test          r1     1
.line	588	jmp            0   l21
.line	588	loadk         r1    k3 ; k3 = 0
.label	l21
.line	588	le             0    r1    k3 ; k3 = 0
.line	588	jmp            0   l29
.line	588	self          r3    r0    k6 ; k6 = "UnRegistSceneEvent"
.line	588	call          r3     2     1
.line	588	self          r3    r0    k5 ; k5 = "ChangeClientVoiceSta" (truncated)
.line	588	loadk         r5    k3 ; k3 = 0
.line	588	call          r3     3     1
.line	588	return        r0     1
.label	l29
.line	588	gettabup      r3    u1    k7 ; k7 = "Enum_ASRSceneID"
.line	588	gettable      r3    r3    k8 ; k8 = "PublicOpinion"
.line	588	eq             0    r1    r3
.line	588	jmp            0   l39
.line	588	self          r3    r0    k9 ; k9 = "RegistSceneEvent"
.line	588	call          r3     2     1
.line	588	self          r3    r0    k5 ; k5 = "ChangeClientVoiceSta" (truncated)
.line	588	move          r5    r1
.line	588	call          r3     3     1
.line	588	return        r0     1
.label	l39
.line	588	self          r3    r0   k10 ; k10 = "StartFamilyCenterCom" (truncated)
.line	588	move          r5    r2
.line	588	call          r3     3     2
.line	588	test          r3     0
.line	588	jmp            0   l45
.line	588	return        r0     1
.label	l45
.line	588	self          r3    r0   k11 ; k11 = "HandleOpenMLAIVoiceR" (truncated)
.line	588	loadnil       r5     0
.line	588	call          r3     3     1
.line	588	return        r0     1
.line	588	move          r0    r0
.line	588	move          r0    r0
.line	588	move          r0    r0
.line	588	return        r0     1

.function	main/f30

.source	null
.linedefined	615
.lastlinedefined	617
.numparams	1
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	3	true

.constant	k0	"nRSTSSceneID"
.constant	k1	0
.constant	k2	"Enum_ASRSceneID"
.constant	k3	"PublicOpinion"

.line	615	gettable      r1    r0    k0 ; k0 = "nRSTSSceneID"
.line	615	test          r1     1
.line	615	jmp            0    l5
.line	615	loadk         r1    k1 ; k1 = 0
.label	l5
.line	615	gettabup      r2    u0    k2 ; k2 = "Enum_ASRSceneID"
.line	615	gettable      r2    r2    k3 ; k3 = "PublicOpinion"
.line	615	eq             1    r1    r2
.line	615	jmp            0   l10
.line	615	loadbool      r1     0     1
.label	l10
.line	615	loadbool      r1     1     0
.line	615	return        r1     2
.line	615	return        r0     1
.line	615	move          r0    r0
.line	615	move          r0    r0
.line	615	return        r0     1

.function	main/f31

.source	null
.linedefined	619
.lastlinedefined	622
.numparams	1
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	3	true

.constant	k0	"nRSTSSceneID"
.constant	k1	0
.constant	k2	"Enum_ASRSceneID"
.constant	k3	"PublicOpinion"

.line	619	gettable      r1    r0    k0 ; k0 = "nRSTSSceneID"
.line	619	test          r1     1
.line	619	jmp            0    l5
.line	619	loadk         r1    k1 ; k1 = 0
.label	l5
.line	619	lt             0    k1    r1 ; k1 = 0
.line	619	jmp            0   l11
.line	619	gettabup      r2    u0    k2 ; k2 = "Enum_ASRSceneID"
.line	619	gettable      r2    r2    k3 ; k3 = "PublicOpinion"
.line	619	eq             0    r1    r2
.line	619	jmp            0   l12
.label	l11
.line	619	loadbool      r2     0     1
.label	l12
.line	619	loadbool      r2     1     0
.line	619	return        r2     2
.line	619	return        r0     1
.line	619	move          r0    r0
.line	619	move          r0    r0
.line	619	move          r0    r0
.line	619	move          r0    r0
.line	619	return        r0     1

.function	main/f32

.source	null
.linedefined	624
.lastlinedefined	639
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"print"
.constant	k2	"bWriteLog"
.constant	k3	"string"
.constant	k4	"format"
.constant	k5	"table"
.constant	k6	"concat"
.constant	k7	149
.constant	k8	51
.constant	k9	25
.constant	k10	150
.constant	k11	134
.constant	k12	254
.constant	k13	126
.constant	k14	123
.constant	k15	86
.constant	k16	197
.constant	k17	162
.constant	k18	191
.constant	k19	198
.constant	k20	108
.constant	k21	175
.constant	k22	18
.constant	k23	12
.constant	k24	64
.constant	k25	142
.constant	k26	78
.constant	k27	2
.constant	k28	107
.constant	k29	79
.constant	k30	250
.constant	k31	178
.constant	k32	137
.constant	k33	240
.constant	k34	122
.constant	k35	187
.constant	k36	76
.constant	k37	58
.constant	k38	20
.constant	k39	223
.constant	k40	94
.constant	k41	226
.constant	k42	93
.constant	k43	182
.constant	k44	26
.constant	k45	17
.constant	k46	155
.constant	k47	237
.constant	k48	180
.constant	k49	100
.constant	k50	"tostring"
.constant	k51	0
.constant	k52	"CanOpenMLAIVoice"
.constant	k53	"AntsVoiceInterface"
.constant	k54	"GetMicState"
.constant	k55	1
.constant	k56	"SetRSTSSubtitleState"
.constant	k57	145
.constant	k58	49
.constant	k59	171
.constant	k60	222
.constant	k61	103
.constant	k62	125
.constant	k63	206
.constant	k64	174
.constant	k65	148
.constant	k66	113
.constant	k67	3
.constant	k68	75
.constant	k69	16
.constant	k70	188
.constant	k71	181
.constant	k72	216
.constant	k73	121
.constant	k74	241
.constant	k75	161
.constant	k76	168
.constant	k77	214
.constant	k78	62
.constant	k79	163
.constant	k80	91
.constant	k81	111
.constant	k82	70

.line	624	gettabup      r2    u0    k0 ; k0 = "Client"
.line	624	test          r2     0
.line	624	jmp            0  l206
.line	624	gettabup      r2    u0    k1 ; k1 = "print"
.line	624	gettabup      r3    u0    k2 ; k2 = "bWriteLog"
.line	624	test          r3     0
.line	624	jmp            0   l70
.line	624	gettabup      r3    u0    k3 ; k3 = "string"
.line	624	gettable      r3    r3    k4 ; k4 = "format"
.line	624	gettabup      r4    u0    k5 ; k5 = "table"
.line	624	gettable      r4    r4    k6 ; k6 = "concat"
.line	624	newtable      r5     1     0
.line	624	getupval      r6    u1
.line	624	loadk         r7    k7 ; k7 = 149
.line	624	loadk         r8    k8 ; k8 = 51
.line	624	loadk         r9    k9 ; k9 = 25
.line	624	loadk        r10   k10 ; k10 = 150
.line	624	loadk        r11   k11 ; k11 = 134
.line	624	loadk        r12   k12 ; k12 = 254
.line	624	loadk        r13   k13 ; k13 = 126
.line	624	loadk        r14   k14 ; k14 = 123
.line	624	loadk        r15   k15 ; k15 = 86
.line	624	loadk        r16   k16 ; k16 = 197
.line	624	loadk        r17   k17 ; k17 = 162
.line	624	loadk        r18   k10 ; k10 = 150
.line	624	loadk        r19   k18 ; k18 = 191
.line	624	loadk        r20   k19 ; k19 = 198
.line	624	loadk        r21   k20 ; k20 = 108
.line	624	loadk        r22   k21 ; k21 = 175
.line	624	loadk        r23   k22 ; k22 = 18
.line	624	loadk        r24   k23 ; k23 = 12
.line	624	loadk        r25   k24 ; k24 = 64
.line	624	loadk        r26   k25 ; k25 = 142
.line	624	loadk        r27   k26 ; k26 = 78
.line	624	loadk        r28   k19 ; k19 = 198
.line	624	loadk        r29   k27 ; k27 = 2
.line	624	loadk        r30   k28 ; k28 = 107
.line	624	loadk        r31   k29 ; k29 = 79
.line	624	loadk        r32   k30 ; k30 = 250
.line	624	loadk        r33   k31 ; k31 = 178
.line	624	loadk        r34   k32 ; k32 = 137
.line	624	loadk        r35   k21 ; k21 = 175
.line	624	loadk        r36   k33 ; k33 = 240
.line	624	loadk        r37   k34 ; k34 = 122
.line	624	loadk        r38   k35 ; k35 = 187
.line	624	loadk        r39   k36 ; k36 = 76
.line	624	loadk        r40   k37 ; k37 = 58
.line	624	loadk        r41   k38 ; k38 = 20
.line	624	loadk        r42   k39 ; k39 = 223
.line	624	loadk        r43   k40 ; k40 = 94
.line	624	loadk        r44   k41 ; k41 = 226
.line	624	loadk        r45   k38 ; k38 = 20
.line	624	loadk        r46   k42 ; k42 = 93
.line	624	call          r6    41     2
.line	624	getupval      r7    u1
.line	624	loadk         r8   k43 ; k43 = 182
.line	624	loadk         r9   k44 ; k44 = 26
.line	624	loadk        r10   k45 ; k45 = 17
.line	624	loadk        r11   k46 ; k46 = 155
.line	624	loadk        r12   k47 ; k47 = 237
.line	624	loadk        r13   k48 ; k48 = 180
.line	624	loadk        r14   k49 ; k49 = 100
.line	624	call          r7     8     0
.line	624	setlist       r5     0     1
.line	624	call          r4     2     2
.line	624	gettabup      r5    u0   k50 ; k50 = "tostring"
.line	624	move          r6    r1
.line	624	call          r5     2     0
.line	624	call          r3     0     2
.label	l70
.line	624	call          r2     2     1
.line	624	test          r1     0
.line	624	jmp            0  l181
.line	624	lt             0   k51    r1 ; k51 = 0
.line	624	jmp            0  l181
.line	624	self          r2    r0   k52 ; k52 = "CanOpenMLAIVoice"
.line	624	call          r2     2     2
.line	624	test          r2     0
.line	624	jmp            0  l181
.line	624	gettable      r2    r0   k53 ; k53 = "AntsVoiceInterface"
.line	624	test          r2     0
.line	624	jmp            0  l105
.line	624	gettable      r2    r0   k53 ; k53 = "AntsVoiceInterface"
.line	624	self          r2    r2   k54 ; k54 = "GetMicState"
.line	624	call          r2     2     2
.line	624	eq             0    r2   k55 ; k55 = 1
.line	624	jmp            0  l206
.line	624	self          r2    r0   k56 ; k56 = "SetRSTSSubtitleState"
.line	624	move          r4    r1
.line	624	getupval      r5    u1
.line	624	loadk         r6   k57 ; k57 = 145
.line	624	loadk         r7   k45 ; k45 = 17
.line	624	loadk         r8   k58 ; k58 = 49
.line	624	loadk         r9   k59 ; k59 = 171
.line	624	loadk        r10   k33 ; k33 = 240
.line	624	loadk        r11   k60 ; k60 = 222
.line	624	loadk        r12   k61 ; k61 = 103
.line	624	loadk        r13   k62 ; k62 = 125
.line	624	loadk        r14   k42 ; k42 = 93
.line	624	loadk        r15   k63 ; k63 = 206
.line	624	loadk        r16   k64 ; k64 = 174
.line	624	loadk        r17   k65 ; k65 = 148
.line	624	call          r5    13     2
.line	624	call          r2     4     1
.line	624	jmp            0  l206
.label	l105
.line	624	gettabup      r2    u0    k1 ; k1 = "print"
.line	624	gettabup      r3    u0    k2 ; k2 = "bWriteLog"
.line	624	test          r3     0
.line	624	jmp            0  l179
.line	624	gettabup      r3    u0    k5 ; k5 = "table"
.line	624	gettable      r3    r3    k6 ; k6 = "concat"
.line	624	newtable      r4     1     0
.line	624	getupval      r5    u1
.line	624	loadk         r6    k7 ; k7 = 149
.line	624	loadk         r7    k8 ; k8 = 51
.line	624	loadk         r8    k9 ; k9 = 25
.line	624	loadk         r9   k10 ; k10 = 150
.line	624	loadk        r10   k11 ; k11 = 134
.line	624	loadk        r11   k12 ; k12 = 254
.line	624	loadk        r12   k13 ; k13 = 126
.line	624	loadk        r13   k14 ; k14 = 123
.line	624	loadk        r14   k15 ; k15 = 86
.line	624	loadk        r15   k16 ; k16 = 197
.line	624	loadk        r16   k17 ; k17 = 162
.line	624	loadk        r17   k10 ; k10 = 150
.line	624	loadk        r18   k18 ; k18 = 191
.line	624	loadk        r19   k19 ; k19 = 198
.line	624	loadk        r20   k20 ; k20 = 108
.line	624	loadk        r21   k21 ; k21 = 175
.line	624	loadk        r22   k22 ; k22 = 18
.line	624	loadk        r23   k23 ; k23 = 12
.line	624	loadk        r24   k24 ; k24 = 64
.line	624	loadk        r25   k25 ; k25 = 142
.line	624	loadk        r26   k26 ; k26 = 78
.line	624	loadk        r27   k19 ; k19 = 198
.line	624	loadk        r28   k27 ; k27 = 2
.line	624	loadk        r29   k28 ; k28 = 107
.line	624	loadk        r30   k29 ; k29 = 79
.line	624	loadk        r31   k30 ; k30 = 250
.line	624	loadk        r32   k31 ; k31 = 178
.line	624	loadk        r33   k32 ; k32 = 137
.line	624	loadk        r34   k21 ; k21 = 175
.line	624	loadk        r35   k33 ; k33 = 240
.line	624	loadk        r36   k34 ; k34 = 122
.line	624	loadk        r37   k35 ; k35 = 187
.line	624	loadk        r38   k36 ; k36 = 76
.line	624	loadk        r39   k37 ; k37 = 58
.line	624	loadk        r40   k38 ; k38 = 20
.line	624	loadk        r41   k39 ; k39 = 223
.line	624	loadk        r42   k66 ; k66 = 113
.line	624	loadk        r43   k39 ; k39 = 223
.line	624	loadk        r44   k67 ; k67 = 3
.line	624	loadk        r45   k68 ; k68 = 75
.line	624	call          r5    41     2
.line	624	getupval      r6    u1
.line	624	loadk         r7   k25 ; k25 = 142
.line	624	loadk         r8   k69 ; k69 = 16
.line	624	loadk         r9   k58 ; k58 = 49
.line	624	loadk        r10   k70 ; k70 = 188
.line	624	loadk        r11   k71 ; k71 = 181
.line	624	loadk        r12   k72 ; k72 = 216
.line	624	loadk        r13   k73 ; k73 = 121
.line	624	loadk        r14   k20 ; k20 = 108
.line	624	loadk        r15   k15 ; k15 = 86
.line	624	loadk        r16   k74 ; k74 = 241
.line	624	loadk        r17   k75 ; k75 = 161
.line	624	loadk        r18   k10 ; k10 = 150
.line	624	loadk        r19   k76 ; k76 = 168
.line	624	loadk        r20   k77 ; k77 = 214
.line	624	loadk        r21   k78 ; k78 = 62
.line	624	loadk        r22   k79 ; k79 = 163
.line	624	loadk        r23   k80 ; k80 = 91
.line	624	loadk        r24   k81 ; k81 = 111
.line	624	loadk        r25   k82 ; k82 = 70
.line	624	loadk        r26   k11 ; k11 = 134
.line	624	loadk        r27   k36 ; k36 = 76
.line	624	call          r6    22     0
.line	624	setlist       r4     0     1
.line	624	call          r3     2     2
.label	l179
.line	624	call          r2     2     1
.line	624	jmp            0  l206
.label	l181
.line	624	gettable      r2    r0   k53 ; k53 = "AntsVoiceInterface"
.line	624	test          r2     0
.line	624	jmp            0  l206
.line	624	gettable      r2    r0   k53 ; k53 = "AntsVoiceInterface"
.line	624	self          r2    r2   k54 ; k54 = "GetMicState"
.line	624	call          r2     2     2
.line	624	eq             0    r2   k55 ; k55 = 1
.line	624	jmp            0  l206
.line	624	self          r2    r0   k56 ; k56 = "SetRSTSSubtitleState"
.line	624	loadk         r4   k51 ; k51 = 0
.line	624	getupval      r5    u1
.line	624	loadk         r6   k57 ; k57 = 145
.line	624	loadk         r7   k45 ; k45 = 17
.line	624	loadk         r8   k58 ; k58 = 49
.line	624	loadk         r9   k59 ; k59 = 171
.line	624	loadk        r10   k33 ; k33 = 240
.line	624	loadk        r11   k60 ; k60 = 222
.line	624	loadk        r12   k61 ; k61 = 103
.line	624	loadk        r13   k62 ; k62 = 125
.line	624	loadk        r14   k42 ; k42 = 93
.line	624	loadk        r15   k63 ; k63 = 206
.line	624	loadk        r16   k64 ; k64 = 174
.line	624	loadk        r17   k65 ; k65 = 148
.line	624	call          r5    13     2
.line	624	call          r2     4     1
.label	l206
.line	624	return        r0     1
.line	624	move          r0    r0
.line	624	move          r0    r0
.line	624	move          r0    r0
.line	624	move          r0    r0
.line	624	return        r0     1

.function	main/f33

.source	null
.linedefined	641
.lastlinedefined	649
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	13	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	0
.constant	k23	70
.constant	k24	174
.constant	k25	78
.constant	k26	213
.constant	k27	20
.constant	k28	76
.constant	k29	250
.constant	k30	180
.constant	k31	130
.constant	k32	158
.constant	k33	107
.constant	k34	115
.constant	k35	24
.constant	k36	156
.constant	k37	95
.constant	k38	2
.constant	k39	248
.constant	k40	90
.constant	k41	43
.constant	k42	"bSpeechToTextState"
.constant	k43	true
.constant	k44	"GV_EVENT_MIC_STATE_OPEN_SUCC"
.constant	k45	"SetRSTSSubtitleState"
.constant	k46	"nRSTSSceneID"
.constant	k47	151
.constant	k48	15
.constant	k49	61
.constant	k50	177
.constant	k51	157
.constant	k52	116

.line	641	gettabup      r2    u0    k0 ; k0 = "print"
.line	641	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	641	test          r3     0
.line	641	jmp            0   l61
.line	641	gettabup      r3    u0    k2 ; k2 = "string"
.line	641	gettable      r3    r3    k3 ; k3 = "format"
.line	641	gettabup      r4    u0    k4 ; k4 = "table"
.line	641	gettable      r4    r4    k5 ; k5 = "concat"
.line	641	newtable      r5     1     0
.line	641	getupval      r6    u1
.line	641	loadk         r7    k6 ; k6 = 149
.line	641	loadk         r8    k7 ; k7 = 51
.line	641	loadk         r9    k8 ; k8 = 25
.line	641	loadk        r10    k9 ; k9 = 150
.line	641	loadk        r11   k10 ; k10 = 134
.line	641	loadk        r12   k11 ; k11 = 254
.line	641	loadk        r13   k12 ; k12 = 126
.line	641	loadk        r14   k13 ; k13 = 123
.line	641	loadk        r15   k14 ; k14 = 86
.line	641	loadk        r16   k15 ; k15 = 197
.line	641	loadk        r17   k16 ; k16 = 162
.line	641	loadk        r18    k9 ; k9 = 150
.line	641	loadk        r19   k17 ; k17 = 191
.line	641	loadk        r20   k18 ; k18 = 198
.line	641	loadk        r21   k19 ; k19 = 108
.line	641	loadk        r22   k20 ; k20 = 175
.line	641	loadk        r23   k21 ; k21 = 18
.line	641	loadk        r24   k22 ; k22 = 0
.line	641	loadk        r25   k23 ; k23 = 70
.line	641	loadk        r26   k24 ; k24 = 174
.line	641	loadk        r27   k25 ; k25 = 78
.line	641	loadk        r28   k26 ; k26 = 213
.line	641	loadk        r29   k27 ; k27 = 20
.line	641	loadk        r30   k12 ; k12 = 126
.line	641	loadk        r31   k28 ; k28 = 76
.line	641	loadk        r32   k29 ; k29 = 250
.line	641	loadk        r33   k30 ; k30 = 180
.line	641	loadk        r34   k31 ; k31 = 130
.line	641	loadk        r35   k32 ; k32 = 158
.line	641	loadk        r36   k26 ; k26 = 213
.line	641	loadk        r37   k33 ; k33 = 107
.line	641	loadk        r38   k30 ; k30 = 180
.line	641	loadk        r39   k28 ; k28 = 76
.line	641	loadk        r40   k34 ; k34 = 115
.line	641	loadk        r41   k35 ; k35 = 24
.line	641	loadk        r42   k36 ; k36 = 156
.line	641	loadk        r43   k37 ; k37 = 95
.line	641	loadk        r44   k26 ; k26 = 213
.line	641	loadk        r45   k21 ; k21 = 18
.line	641	loadk        r46   k38 ; k38 = 2
.line	641	call          r6    41     2
.line	641	getupval      r7    u1
.line	641	loadk         r8   k39 ; k39 = 248
.line	641	loadk         r9   k40 ; k40 = 90
.line	641	loadk        r10   k41 ; k41 = 43
.line	641	call          r7     4     0
.line	641	setlist       r5     0     1
.line	641	call          r4     2     2
.line	641	move          r5    r1
.line	641	call          r3     3     2
.label	l61
.line	641	call          r2     2     1
.line	641	gettable      r2    r0   k42 ; k42 = "bSpeechToTextState"
.line	641	eq             0    r2   k43 ; k43 = true
.line	641	jmp            0   l66
.line	641	return        r0     1
.label	l66
.line	641	gettabup      r2    u2   k44 ; k44 = "GV_EVENT_MIC_STATE_O" (truncated)
.line	641	eq             0    r1    r2
.line	641	jmp            0   l81
.line	641	self          r2    r0   k45 ; k45 = "SetRSTSSubtitleState"
.line	641	gettable      r4    r0   k46 ; k46 = "nRSTSSceneID"
.line	641	getupval      r5    u1
.line	641	loadk         r6   k47 ; k47 = 151
.line	641	loadk         r7   k48 ; k48 = 15
.line	641	loadk         r8   k49 ; k49 = 61
.line	641	loadk         r9   k50 ; k50 = 177
.line	641	loadk        r10   k51 ; k51 = 157
.line	641	loadk        r11   k39 ; k39 = 248
.line	641	loadk        r12   k52 ; k52 = 116
.line	641	call          r5     8     2
.line	641	call          r2     4     1
.label	l81
.line	641	return        r0     1
.line	641	gettabup      r1    u1   k45 ; k45 = "SetRSTSSubtitleState"
.line	641	move          r0    r0
.line	641	move          r0    r0
.line	641	return        r0     1

.function	main/f34

.source	null
.linedefined	651
.lastlinedefined	659
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	0
.constant	k23	70
.constant	k24	173
.constant	k25	69
.constant	k26	199
.constant	k27	8
.constant	k28	90
.constant	k29	220
.constant	k30	167
.constant	k31	130
.constant	k32	169
.constant	k33	194
.constant	k34	122
.constant	k35	179
.constant	k36	87
.constant	k37	49
.constant	k38	20
.constant	k39	223
.constant	k40	67
.constant	k41	22
.constant	k42	76
.constant	k43	189
.constant	k44	120
.constant	k45	250
.constant	k46	163
.constant	k47	"tostring"
.constant	k48	"bSpeechToTextState"
.constant	k49	true
.constant	k50	"SetRSTSSubtitleState"
.constant	k51	155
.constant	k52	19
.constant	k53	55
.constant	k54	172
.constant	k55	181
.constant	k56	177
.constant	k57	113
.constant	k58	80

.line	651	gettabup      r2    u0    k0 ; k0 = "print"
.line	651	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	651	test          r3     0
.line	651	jmp            0   l65
.line	651	gettabup      r3    u0    k2 ; k2 = "string"
.line	651	gettable      r3    r3    k3 ; k3 = "format"
.line	651	gettabup      r4    u0    k4 ; k4 = "table"
.line	651	gettable      r4    r4    k5 ; k5 = "concat"
.line	651	newtable      r5     1     0
.line	651	getupval      r6    u1
.line	651	loadk         r7    k6 ; k6 = 149
.line	651	loadk         r8    k7 ; k7 = 51
.line	651	loadk         r9    k8 ; k8 = 25
.line	651	loadk        r10    k9 ; k9 = 150
.line	651	loadk        r11   k10 ; k10 = 134
.line	651	loadk        r12   k11 ; k11 = 254
.line	651	loadk        r13   k12 ; k12 = 126
.line	651	loadk        r14   k13 ; k13 = 123
.line	651	loadk        r15   k14 ; k14 = 86
.line	651	loadk        r16   k15 ; k15 = 197
.line	651	loadk        r17   k16 ; k16 = 162
.line	651	loadk        r18    k9 ; k9 = 150
.line	651	loadk        r19   k17 ; k17 = 191
.line	651	loadk        r20   k18 ; k18 = 198
.line	651	loadk        r21   k19 ; k19 = 108
.line	651	loadk        r22   k20 ; k20 = 175
.line	651	loadk        r23   k21 ; k21 = 18
.line	651	loadk        r24   k22 ; k22 = 0
.line	651	loadk        r25   k23 ; k23 = 70
.line	651	loadk        r26   k24 ; k24 = 173
.line	651	loadk        r27   k25 ; k25 = 69
.line	651	loadk        r28   k26 ; k26 = 199
.line	651	loadk        r29   k27 ; k27 = 8
.line	651	loadk        r30   k28 ; k28 = 90
.line	651	loadk        r31   k23 ; k23 = 70
.line	651	loadk        r32   k29 ; k29 = 220
.line	651	loadk        r33   k30 ; k30 = 167
.line	651	loadk        r34   k31 ; k31 = 130
.line	651	loadk        r35   k32 ; k32 = 169
.line	651	loadk        r36   k33 ; k33 = 194
.line	651	loadk        r37   k34 ; k34 = 122
.line	651	loadk        r38   k35 ; k35 = 179
.line	651	loadk        r39   k36 ; k36 = 87
.line	651	loadk        r40   k37 ; k37 = 49
.line	651	loadk        r41   k38 ; k38 = 20
.line	651	loadk        r42   k39 ; k39 = 223
.line	651	loadk        r43   k40 ; k40 = 67
.line	651	loadk        r44   k15 ; k15 = 197
.line	651	loadk        r45   k41 ; k41 = 22
.line	651	loadk        r46   k42 ; k42 = 76
.line	651	call          r6    41     2
.line	651	getupval      r7    u1
.line	651	loadk         r8   k43 ; k43 = 189
.line	651	loadk         r9   k25 ; k25 = 69
.line	651	loadk        r10   k44 ; k44 = 120
.line	651	loadk        r11   k45 ; k45 = 250
.line	651	loadk        r12   k46 ; k46 = 163
.line	651	call          r7     6     0
.line	651	setlist       r5     0     1
.line	651	call          r4     2     2
.line	651	gettabup      r5    u0   k47 ; k47 = "tostring"
.line	651	move          r6    r1
.line	651	call          r5     2     0
.line	651	call          r3     0     2
.label	l65
.line	651	call          r2     2     1
.line	651	gettable      r2    r0   k48 ; k48 = "bSpeechToTextState"
.line	651	eq             0    r2   k49 ; k49 = true
.line	651	jmp            0   l70
.line	651	return        r0     1
.label	l70
.line	651	test          r1     1
.line	651	jmp            0   l86
.line	651	self          r2    r0   k50 ; k50 = "SetRSTSSubtitleState"
.line	651	loadk         r4   k22 ; k22 = 0
.line	651	getupval      r5    u1
.line	651	loadk         r6   k51 ; k51 = 155
.line	651	loadk         r7   k52 ; k52 = 19
.line	651	loadk         r8   k53 ; k53 = 55
.line	651	loadk         r9   k54 ; k54 = 172
.line	651	loadk        r10   k55 ; k55 = 181
.line	651	loadk        r11   k56 ; k56 = 177
.line	651	loadk        r12   k28 ; k28 = 90
.line	651	loadk        r13   k57 ; k57 = 113
.line	651	loadk        r14   k58 ; k58 = 80
.line	651	call          r5    10     2
.line	651	call          r2     4     1
.label	l86
.line	651	return        r0     1
.line	651	move          r0    r0
.line	651	return        r0     1

.function	main/f35

.source	null
.linedefined	661
.lastlinedefined	674
.numparams	4
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	29
.constant	k23	120
.constant	k24	172
.constant	k25	127
.constant	k26	242
.constant	k27	2
.constant	k28	90
.constant	k29	85
.constant	k30	246
.constant	k31	165
.constant	k32	184
.constant	k33	136
.constant	k34	96
.constant	k35	190
.constant	k36	121
.constant	k37	22
.constant	k38	110
.constant	k39	144
.constant	k40	89
.constant	k41	210
.constant	k42	148
.constant	k43	16
.constant	k44	63
.constant	k45	243
.constant	k46	240
.constant	k47	255
.constant	k48	66
.constant	k49	81
.constant	k50	119
.constant	k51	185
.constant	k52	226
.constant	k53	132
.constant	k54	231
.constant	k55	147
.constant	k56	112
.constant	k57	158
.constant	k58	100
.constant	k59	32
.constant	k60	79
.constant	k61	166
.constant	k62	155
.constant	k63	91
.constant	k64	15
.constant	k65	179
.constant	k66	164
.constant	k67	151
.constant	k68	204
.constant	k69	105
.constant	k70	57
.constant	k71	87
.constant	k72	21
.constant	k73	194
.constant	k74	"tostring"
.constant	k75	"Client"
.constant	k76	"NetUtil"
.constant	k77	"IsGameFinishedState"
.constant	k78	"math"
.constant	k79	"tointeger"
.constant	k80	0
.constant	k81	131
.constant	k82	26
.constant	k83	42
.constant	k84	173
.constant	k85	227
.constant	k86	74
.constant	k87	56
.constant	k88	207
.constant	k89	157
.constant	k90	220
.constant	k91	169
.constant	k92	77
.constant	k93	9
.constant	k94	142
.constant	k95	84
.constant	k96	212
.constant	k97	193
.constant	k98	135
.constant	k99	107
.constant	k100	168
.constant	k101	78
.constant	k102	58
.constant	k103	160
.constant	k104	99
.constant	k105	92
.constant	k106	153
.constant	k107	54
.constant	k108	14
.constant	k109	176
.constant	k110	114
.constant	k111	76
.constant	k112	236
.constant	k113	219
.constant	k114	235
.constant	k115	218
.constant	k116	188
.constant	k117	73
.constant	k118	35
.constant	k119	65
.constant	k120	139
.constant	k121	245
.constant	k122	43
.constant	k123	71
.constant	k124	68
.constant	k125	221
.constant	k126	208
.constant	k127	34
.constant	k128	250
.constant	k129	10
.constant	k130	113
.constant	k131	187
.constant	k132	4
.constant	k133	20
.constant	k134	248
.constant	k135	27
.constant	k136	177
.constant	k137	101
.constant	k138	125
.constant	k139	67
.constant	k140	181
.constant	k141	"SendPacket"
.constant	k142	170
.constant	k143	40
.constant	k144	229
.constant	k145	72
.constant	k146	238
.constant	k147	152

.line	661	gettabup      r4    u0    k0 ; k0 = "print"
.line	661	gettabup      r5    u0    k1 ; k1 = "bWriteLog"
.line	661	test          r5     0
.line	661	jmp            0  l104
.line	661	gettabup      r5    u0    k2 ; k2 = "string"
.line	661	gettable      r5    r5    k3 ; k3 = "format"
.line	661	gettabup      r6    u0    k4 ; k4 = "table"
.line	661	gettable      r6    r6    k5 ; k5 = "concat"
.line	661	newtable      r7     1     0
.line	661	getupval      r8    u1
.line	661	loadk         r9    k6 ; k6 = 149
.line	661	loadk        r10    k7 ; k7 = 51
.line	661	loadk        r11    k8 ; k8 = 25
.line	661	loadk        r12    k9 ; k9 = 150
.line	661	loadk        r13   k10 ; k10 = 134
.line	661	loadk        r14   k11 ; k11 = 254
.line	661	loadk        r15   k12 ; k12 = 126
.line	661	loadk        r16   k13 ; k13 = 123
.line	661	loadk        r17   k14 ; k14 = 86
.line	661	loadk        r18   k15 ; k15 = 197
.line	661	loadk        r19   k16 ; k16 = 162
.line	661	loadk        r20    k9 ; k9 = 150
.line	661	loadk        r21   k17 ; k17 = 191
.line	661	loadk        r22   k18 ; k18 = 198
.line	661	loadk        r23   k19 ; k19 = 108
.line	661	loadk        r24   k20 ; k20 = 175
.line	661	loadk        r25   k21 ; k21 = 18
.line	661	loadk        r26   k22 ; k22 = 29
.line	661	loadk        r27   k23 ; k23 = 120
.line	661	loadk        r28   k24 ; k24 = 172
.line	661	loadk        r29   k25 ; k25 = 127
.line	661	loadk        r30   k26 ; k26 = 242
.line	661	loadk        r31   k27 ; k27 = 2
.line	661	loadk        r32   k28 ; k28 = 90
.line	661	loadk        r33   k29 ; k29 = 85
.line	661	loadk        r34   k30 ; k30 = 246
.line	661	loadk        r35   k31 ; k31 = 165
.line	661	loadk        r36   k32 ; k32 = 184
.line	661	loadk        r37   k33 ; k33 = 136
.line	661	loadk        r38   k18 ; k18 = 198
.line	661	loadk        r39   k34 ; k34 = 96
.line	661	loadk        r40   k35 ; k35 = 190
.line	661	loadk        r41   k36 ; k36 = 121
.line	661	loadk        r42   k37 ; k37 = 22
.line	661	loadk        r43   k38 ; k38 = 110
.line	661	loadk        r44   k39 ; k39 = 144
.line	661	loadk        r45   k40 ; k40 = 89
.line	661	loadk        r46   k41 ; k41 = 210
.line	661	loadk        r47   k21 ; k21 = 18
.line	661	loadk        r48   k19 ; k19 = 108
.line	661	call          r8    41     2
.line	661	getupval      r9    u1
.line	661	loadk        r10   k42 ; k42 = 148
.line	661	loadk        r11   k43 ; k43 = 16
.line	661	loadk        r12   k44 ; k44 = 63
.line	661	loadk        r13   k45 ; k45 = 243
.line	661	loadk        r14   k46 ; k46 = 240
.line	661	loadk        r15   k47 ; k47 = 255
.line	661	loadk        r16   k48 ; k48 = 66
.line	661	loadk        r17   k49 ; k49 = 81
.line	661	loadk        r18   k50 ; k50 = 119
.line	661	loadk        r19   k51 ; k51 = 185
.line	661	loadk        r20   k52 ; k52 = 226
.line	661	loadk        r21   k53 ; k53 = 132
.line	661	loadk        r22   k54 ; k54 = 231
.line	661	loadk        r23   k55 ; k55 = 147
.line	661	loadk        r24   k56 ; k56 = 112
.line	661	loadk        r25   k57 ; k57 = 158
.line	661	loadk        r26   k58 ; k58 = 100
.line	661	loadk        r27   k59 ; k59 = 32
.line	661	loadk        r28   k60 ; k60 = 79
.line	661	loadk        r29   k61 ; k61 = 166
.line	661	loadk        r30   k58 ; k58 = 100
.line	661	loadk        r31   k62 ; k62 = 155
.line	661	loadk        r32   k48 ; k48 = 66
.line	661	loadk        r33   k63 ; k63 = 91
.line	661	loadk        r34   k64 ; k64 = 15
.line	661	loadk        r35   k65 ; k65 = 179
.line	661	loadk        r36   k66 ; k66 = 164
.line	661	loadk        r37   k65 ; k65 = 179
.line	661	loadk        r38   k67 ; k67 = 151
.line	661	loadk        r39   k68 ; k68 = 204
.line	661	loadk        r40   k69 ; k69 = 105
.line	661	loadk        r41   k55 ; k55 = 147
.line	661	loadk        r42   k14 ; k14 = 86
.line	661	loadk        r43   k70 ; k70 = 57
.line	661	loadk        r44   k71 ; k71 = 87
.line	661	loadk        r45   k15 ; k15 = 197
.line	661	loadk        r46   k72 ; k72 = 21
.line	661	loadk        r47   k73 ; k73 = 194
.line	661	call          r9    39     0
.line	661	setlist       r7     0     1
.line	661	call          r6     2     2
.line	661	gettabup      r7    u0   k74 ; k74 = "tostring"
.line	661	move          r8    r1
.line	661	call          r7     2     2
.line	661	gettabup      r8    u0   k74 ; k74 = "tostring"
.line	661	move          r9    r2
.line	661	call          r8     2     2
.line	661	gettabup      r9    u0   k74 ; k74 = "tostring"
.line	661	move         r10    r3
.line	661	call          r9     2     0
.line	661	call          r5     0     2
.label	l104
.line	661	call          r4     2     1
.line	661	gettabup      r4    u0   k75 ; k75 = "Client"
.line	661	test          r4     1
.line	661	jmp            0  l270
.line	661	gettabup      r4    u0   k76 ; k76 = "NetUtil"
.line	661	test          r4     0
.line	661	jmp            0  l270
.line	661	self          r4    r0   k77 ; k77 = "IsGameFinishedState"
.line	661	call          r4     2     2
.line	661	test          r4     0
.line	661	jmp            0  l116
.line	661	return        r0     1
.label	l116
.line	661	gettabup      r4    u0   k78 ; k78 = "math"
.line	661	gettable      r4    r4   k79 ; k79 = "tointeger"
.line	661	move          r5    r2
.line	661	call          r4     2     2
.line	661	test          r4     1
.line	661	jmp            0  l123
.line	661	loadk         r4   k80 ; k80 = 0
.label	l123
.line	661	gettabup      r4    u2    r4
.line	661	test          r4     1
.line	661	jmp            0  l244
.line	661	gettabup      r5    u0    k0 ; k0 = "print"
.line	661	gettabup      r6    u0    k1 ; k1 = "bWriteLog"
.line	661	test          r6     0
.line	661	jmp            0  l242
.line	661	gettabup      r6    u0    k2 ; k2 = "string"
.line	661	gettable      r6    r6    k3 ; k3 = "format"
.line	661	gettabup      r7    u0    k4 ; k4 = "table"
.line	661	gettable      r7    r7    k5 ; k5 = "concat"
.line	661	newtable      r8     2     0
.line	661	getupval      r9    u1
.line	661	loadk        r10   k81 ; k81 = 131
.line	661	loadk        r11   k82 ; k82 = 26
.line	661	loadk        r12   k83 ; k83 = 42
.line	661	loadk        r13   k84 ; k84 = 173
.line	661	loadk        r14   k17 ; k17 = 191
.line	661	loadk        r15   k85 ; k85 = 227
.line	661	loadk        r16   k86 ; k86 = 74
.line	661	loadk        r17   k87 ; k87 = 56
.line	661	loadk        r18   k12 ; k12 = 126
.line	661	loadk        r19   k88 ; k88 = 207
.line	661	loadk        r20   k10 ; k10 = 134
.line	661	loadk        r21   k35 ; k35 = 190
.line	661	loadk        r22   k89 ; k89 = 157
.line	661	loadk        r23   k90 ; k90 = 220
.line	661	loadk        r24   k50 ; k50 = 119
.line	661	loadk        r25   k91 ; k91 = 169
.line	661	loadk        r26   k92 ; k92 = 77
.line	661	loadk        r27   k93 ; k93 = 9
.line	661	loadk        r28   k92 ; k92 = 77
.line	661	loadk        r29   k94 ; k94 = 142
.line	661	loadk        r30   k95 ; k95 = 84
.line	661	loadk        r31   k96 ; k96 = 212
.line	661	loadk        r32   k72 ; k72 = 21
.line	661	loadk        r33   k92 ; k92 = 77
.line	661	loadk        r34    k8 ; k8 = 25
.line	661	loadk        r35   k97 ; k97 = 193
.line	661	loadk        r36   k98 ; k98 = 135
.line	661	loadk        r37   k66 ; k66 = 164
.line	661	loadk        r38   k53 ; k53 = 132
.line	661	loadk        r39   k46 ; k46 = 240
.line	661	loadk        r40   k99 ; k99 = 107
.line	661	loadk        r41  k100 ; k100 = 168
.line	661	loadk        r42  k101 ; k101 = 78
.line	661	loadk        r43  k102 ; k102 = 58
.line	661	loadk        r44   k86 ; k86 = 74
.line	661	loadk        r45  k103 ; k103 = 160
.line	661	loadk        r46  k104 ; k104 = 99
.line	661	loadk        r47   k96 ; k96 = 212
.line	661	loadk        r48    k8 ; k8 = 25
.line	661	loadk        r49  k105 ; k105 = 92
.line	661	call          r9    41     2
.line	661	getupval     r10    u1
.line	661	loadk        r11  k106 ; k106 = 153
.line	661	loadk        r12  k107 ; k107 = 54
.line	661	loadk        r13  k108 ; k108 = 14
.line	661	loadk        r14  k109 ; k109 = 176
.line	661	loadk        r15   k51 ; k51 = 185
.line	661	loadk        r16   k26 ; k26 = 242
.line	661	loadk        r17  k110 ; k110 = 114
.line	661	loadk        r18  k111 ; k111 = 76
.line	661	loadk        r19   k25 ; k25 = 127
.line	661	loadk        r20  k112 ; k112 = 236
.line	661	loadk        r21  k103 ; k103 = 160
.line	661	loadk        r22  k113 ; k113 = 219
.line	661	loadk        r23  k114 ; k114 = 235
.line	661	loadk        r24  k115 ; k115 = 218
.line	661	loadk        r25   k56 ; k56 = 112
.line	661	loadk        r26  k116 ; k116 = 188
.line	661	loadk        r27  k117 ; k117 = 73
.line	661	loadk        r28  k118 ; k118 = 35
.line	661	loadk        r29  k119 ; k119 = 65
.line	661	loadk        r30  k120 ; k120 = 139
.line	661	loadk        r31   k80 ; k80 = 0
.line	661	loadk        r32  k121 ; k121 = 245
.line	661	loadk        r33  k122 ; k122 = 43
.line	661	loadk        r34  k123 ; k123 = 71
.line	661	loadk        r35  k124 ; k124 = 68
.line	661	loadk        r36  k115 ; k115 = 218
.line	661	loadk        r37   k55 ; k55 = 147
.line	661	loadk        r38  k125 ; k125 = 221
.line	661	loadk        r39   k11 ; k11 = 254
.line	661	loadk        r40  k126 ; k126 = 208
.line	661	loadk        r41  k127 ; k127 = 34
.line	661	loadk        r42  k128 ; k128 = 250
.line	661	loadk        r43   k14 ; k14 = 86
.line	661	loadk        r44  k129 ; k129 = 10
.line	661	loadk        r45  k130 ; k130 = 113
.line	661	loadk        r46  k131 ; k131 = 187
.line	661	loadk        r47  k129 ; k129 = 10
.line	661	loadk        r48   k42 ; k42 = 148
.line	661	loadk        r49  k132 ; k132 = 4
.line	661	loadk        r50  k133 ; k133 = 20
.line	661	call         r10    41     2
.line	661	getupval     r11    u1
.line	661	loadk        r12  k134 ; k134 = 248
.line	661	loadk        r13  k135 ; k135 = 27
.line	661	loadk        r14   k83 ; k83 = 42
.line	661	loadk        r15  k109 ; k109 = 176
.line	661	loadk        r16  k103 ; k103 = 160
.line	661	loadk        r17  k136 ; k136 = 177
.line	661	loadk        r18  k137 ; k137 = 101
.line	661	loadk        r19  k138 ; k138 = 125
.line	661	loadk        r20  k139 ; k139 = 67
.line	661	loadk        r21  k112 ; k112 = 236
.line	661	loadk        r22  k140 ; k140 = 181
.line	661	loadk        r23   k81 ; k81 = 131
.line	661	call         r11    13     0
.line	661	setlist       r8     0     1
.line	661	call          r7     2     2
.line	661	gettabup      r8    u0   k74 ; k74 = "tostring"
.line	661	move          r9    r2
.line	661	call          r8     2     2
.line	661	gettabup      r9    u0   k74 ; k74 = "tostring"
.line	661	move         r10    r1
.line	661	call          r9     2     0
.line	661	call          r6     0     2
.label	l242
.line	661	call          r5     2     1
.line	661	return        r0     1
.label	l244
.line	661	gettabup      r5    u0   k76 ; k76 = "NetUtil"
.line	661	gettable      r5    r5  k141 ; k141 = "SendPacket"
.line	661	getupval      r6    u1
.line	661	loadk         r7  k142 ; k142 = 170
.line	661	loadk         r8   k82 ; k82 = 26
.line	661	loadk         r9  k143 ; k143 = 40
.line	661	loadk        r10  k109 ; k109 = 176
.line	661	loadk        r11   k16 ; k16 = 162
.line	661	loadk        r12  k144 ; k144 = 229
.line	661	loadk        r13  k145 ; k145 = 72
.line	661	loadk        r14   k13 ; k13 = 123
.line	661	loadk        r15  k105 ; k105 = 92
.line	661	loadk        r16  k146 ; k146 = 238
.line	661	loadk        r17  k142 ; k142 = 170
.line	661	loadk        r18  k147 ; k147 = 152
.line	661	loadk        r19   k31 ; k31 = 165
.line	661	loadk        r20  k112 ; k112 = 236
.line	661	loadk        r21   k50 ; k50 = 119
.line	661	loadk        r22   k66 ; k66 = 164
.line	661	loadk        r23  k101 ; k101 = 78
.line	661	loadk        r24   k59 ; k59 = 32
.line	661	call          r6    19     2
.line	661	move          r7    r4
.line	661	move          r8    r1
.line	661	move          r9    r3
.line	661	call          r5     5     1
.label	l270
.line	661	return        r0     1
.line	661	move          r0    r0
.line	661	move          r0    r0
.line	661	move          r0    r0
.line	661	return        r0     1

.function	main/f36

.source	null
.linedefined	676
.lastlinedefined	687
.numparams	5
.is_vararg	0
.maxstacksize	52

.upvalue	"_ENV"	0	false
.upvalue	"U1"	12	true
.upvalue	"U2"	1	true

.constant	k0	"Client"
.constant	k1	"nRSTSSceneID"
.constant	k2	0
.constant	k3	"SendStringOnlyReplay"
.constant	k4	"Owner"
.constant	k5	"Object"
.constant	k6	"string"
.constant	k7	"format"
.constant	k8	253
.constant	k9	12
.constant	k10	36
.constant	k11	250
.constant	k12	163
.constant	k13	237
.constant	k14	50
.constant	k15	107
.constant	k16	79
.constant	k17	166
.constant	k18	180
.constant	k19	139
.constant	k20	238
.constant	k21	192
.constant	k22	81
.constant	k23	104
.constant	k24	185
.constant	k25	"tostring"
.constant	k26	"print"
.constant	k27	"bWriteLog"
.constant	k28	"table"
.constant	k29	"concat"
.constant	k30	149
.constant	k31	51
.constant	k32	25
.constant	k33	150
.constant	k34	134
.constant	k35	254
.constant	k36	126
.constant	k37	123
.constant	k38	86
.constant	k39	197
.constant	k40	162
.constant	k41	191
.constant	k42	198
.constant	k43	108
.constant	k44	175
.constant	k45	18
.constant	k46	29
.constant	k47	120
.constant	k48	172
.constant	k49	127
.constant	k50	242
.constant	k51	2
.constant	k52	90
.constant	k53	85
.constant	k54	246
.constant	k55	165
.constant	k56	184
.constant	k57	136
.constant	k58	96
.constant	k59	190
.constant	k60	106
.constant	k61	99
.constant	k62	196
.constant	k63	21
.constant	k64	76
.constant	k65	177
.constant	k66	11
.constant	k67	52
.constant	k68	186
.constant	k69	132
.constant	k70	244
.constant	k71	111
.constant	k72	31
.constant	k73	142
.constant	k74	153
.constant	k75	173
.constant	k76	220
.constant	k77	239
.constant	k78	91
.constant	k79	"IsGameFinishedState"
.constant	k80	"NetUtil"
.constant	k81	"SendPacket"
.constant	k82	170
.constant	k83	26
.constant	k84	40
.constant	k85	176
.constant	k86	229
.constant	k87	72
.constant	k88	92
.constant	k89	152
.constant	k90	236
.constant	k91	119
.constant	k92	164
.constant	k93	78
.constant	k94	32
.constant	k95	19
.constant	k96	57
.constant	k97	181
.constant	k98	227
.constant	k99	75
.constant	k100	97
.constant	k101	209
.constant	k102	148
.constant	k103	193
.constant	k104	122
.constant	k105	"UID"

.line	676	gettabup      r5    u0    k0 ; k0 = "Client"
.line	676	test          r5     1
.line	676	jmp            0  l182
.line	676	gettable      r5    r0    k1 ; k1 = "nRSTSSceneID"
.line	676	test          r5     1
.line	676	jmp            0    l8
.line	676	loadk         r5    k2 ; k2 = 0
.label	l8
.line	676	getupval      r6    u1
.line	676	self          r6    r6    k3 ; k3 = "SendStringOnlyReplay"
.line	676	gettable      r8    r0    k4 ; k4 = "Owner"
.line	676	gettable      r8    r8    k5 ; k5 = "Object"
.line	676	move          r9    r1
.line	676	call          r6     4     1
.line	676	gettabup      r6    u0    k6 ; k6 = "string"
.line	676	gettable      r6    r6    k7 ; k7 = "format"
.line	676	getupval      r7    u2
.line	676	loadk         r8    k8 ; k8 = 253
.line	676	loadk         r9    k9 ; k9 = 12
.line	676	loadk        r10   k10 ; k10 = 36
.line	676	loadk        r11   k11 ; k11 = 250
.line	676	loadk        r12   k12 ; k12 = 163
.line	676	loadk        r13   k13 ; k13 = 237
.line	676	loadk        r14   k14 ; k14 = 50
.line	676	loadk        r15   k15 ; k15 = 107
.line	676	loadk        r16   k16 ; k16 = 79
.line	676	loadk        r17   k17 ; k17 = 166
.line	676	loadk        r18   k18 ; k18 = 180
.line	676	loadk        r19   k19 ; k19 = 139
.line	676	loadk        r20   k20 ; k20 = 238
.line	676	loadk        r21   k21 ; k21 = 192
.line	676	call          r7    15     2
.line	676	move          r8    r4
.line	676	gettabup      r9    u0    k6 ; k6 = "string"
.line	676	gettable      r9    r9    k7 ; k7 = "format"
.line	676	getupval     r10    u2
.line	676	loadk        r11    k8 ; k8 = 253
.line	676	loadk        r12   k22 ; k22 = 81
.line	676	loadk        r13   k23 ; k23 = 104
.line	676	loadk        r14   k24 ; k24 = 185
.line	676	call         r10     5     2
.line	676	move         r11    r2
.line	676	call          r9     3     2
.line	676	gettabup     r10    u0    k6 ; k6 = "string"
.line	676	gettable     r10   r10    k7 ; k7 = "format"
.line	676	getupval     r11    u2
.line	676	loadk        r12    k8 ; k8 = 253
.line	676	loadk        r13   k22 ; k22 = 81
.line	676	loadk        r14   k23 ; k23 = 104
.line	676	loadk        r15   k24 ; k24 = 185
.line	676	call         r11     5     2
.line	676	move         r12    r3
.line	676	call         r10     3     2
.line	676	move         r11    r1
.line	676	gettabup     r12    u0   k25 ; k25 = "tostring"
.line	676	move         r13    r5
.line	676	call         r12     2     0
.line	676	call          r6     0     2
.line	676	gettabup      r7    u0   k26 ; k26 = "print"
.line	676	gettabup      r8    u0   k27 ; k27 = "bWriteLog"
.line	676	test          r8     0
.line	676	jmp            0  l132
.line	676	gettabup      r8    u0    k6 ; k6 = "string"
.line	676	gettable      r8    r8    k7 ; k7 = "format"
.line	676	gettabup      r9    u0   k28 ; k28 = "table"
.line	676	gettable      r9    r9   k29 ; k29 = "concat"
.line	676	newtable     r10     1     0
.line	676	getupval     r11    u2
.line	676	loadk        r12   k30 ; k30 = 149
.line	676	loadk        r13   k31 ; k31 = 51
.line	676	loadk        r14   k32 ; k32 = 25
.line	676	loadk        r15   k33 ; k33 = 150
.line	676	loadk        r16   k34 ; k34 = 134
.line	676	loadk        r17   k35 ; k35 = 254
.line	676	loadk        r18   k36 ; k36 = 126
.line	676	loadk        r19   k37 ; k37 = 123
.line	676	loadk        r20   k38 ; k38 = 86
.line	676	loadk        r21   k39 ; k39 = 197
.line	676	loadk        r22   k40 ; k40 = 162
.line	676	loadk        r23   k33 ; k33 = 150
.line	676	loadk        r24   k41 ; k41 = 191
.line	676	loadk        r25   k42 ; k42 = 198
.line	676	loadk        r26   k43 ; k43 = 108
.line	676	loadk        r27   k44 ; k44 = 175
.line	676	loadk        r28   k45 ; k45 = 18
.line	676	loadk        r29   k46 ; k46 = 29
.line	676	loadk        r30   k47 ; k47 = 120
.line	676	loadk        r31   k48 ; k48 = 172
.line	676	loadk        r32   k49 ; k49 = 127
.line	676	loadk        r33   k50 ; k50 = 242
.line	676	loadk        r34   k51 ; k51 = 2
.line	676	loadk        r35   k52 ; k52 = 90
.line	676	loadk        r36   k53 ; k53 = 85
.line	676	loadk        r37   k54 ; k54 = 246
.line	676	loadk        r38   k55 ; k55 = 165
.line	676	loadk        r39   k56 ; k56 = 184
.line	676	loadk        r40   k57 ; k57 = 136
.line	676	loadk        r41   k42 ; k42 = 198
.line	676	loadk        r42   k58 ; k58 = 96
.line	676	loadk        r43   k59 ; k59 = 190
.line	676	loadk        r44   k60 ; k60 = 106
.line	676	loadk        r45    k9 ; k9 = 12
.line	676	loadk        r46   k43 ; k43 = 108
.line	676	loadk        r47   k48 ; k48 = 172
.line	676	loadk        r48   k61 ; k61 = 99
.line	676	loadk        r49   k62 ; k62 = 196
.line	676	loadk        r50   k63 ; k63 = 21
.line	676	loadk        r51   k64 ; k64 = 76
.line	676	call         r11    41     2
.line	676	getupval     r12    u2
.line	676	loadk        r13   k65 ; k65 = 177
.line	676	loadk        r14   k66 ; k66 = 11
.line	676	loadk        r15   k67 ; k67 = 52
.line	676	loadk        r16   k68 ; k68 = 186
.line	676	loadk        r17   k69 ; k69 = 132
.line	676	loadk        r18   k70 ; k70 = 244
.line	676	loadk        r19   k71 ; k71 = 111
.line	676	loadk        r20   k43 ; k43 = 108
.line	676	loadk        r21   k72 ; k72 = 31
.line	676	loadk        r22   k12 ; k12 = 163
.line	676	loadk        r23   k73 ; k73 = 142
.line	676	loadk        r24   k74 ; k74 = 153
.line	676	loadk        r25   k75 ; k75 = 173
.line	676	loadk        r26   k76 ; k76 = 220
.line	676	loadk        r27   k10 ; k10 = 36
.line	676	loadk        r28   k77 ; k77 = 239
.line	676	loadk        r29   k78 ; k78 = 91
.line	676	call         r12    18     0
.line	676	setlist      r10     0     1
.line	676	call          r9     2     2
.line	676	move         r10    r6
.line	676	call          r8     3     2
.label	l132
.line	676	call          r7     2     1
.line	676	self          r7    r0   k79 ; k79 = "IsGameFinishedState"
.line	676	call          r7     2     2
.line	676	test          r7     0
.line	676	jmp            0  l138
.line	676	return        r0     1
.label	l138
.line	676	gettabup      r7    u0   k80 ; k80 = "NetUtil"
.line	676	gettable      r7    r7   k81 ; k81 = "SendPacket"
.line	676	getupval      r8    u2
.line	676	loadk         r9   k82 ; k82 = 170
.line	676	loadk        r10   k83 ; k83 = 26
.line	676	loadk        r11   k84 ; k84 = 40
.line	676	loadk        r12   k85 ; k85 = 176
.line	676	loadk        r13   k40 ; k40 = 162
.line	676	loadk        r14   k86 ; k86 = 229
.line	676	loadk        r15   k87 ; k87 = 72
.line	676	loadk        r16   k37 ; k37 = 123
.line	676	loadk        r17   k88 ; k88 = 92
.line	676	loadk        r18   k20 ; k20 = 238
.line	676	loadk        r19   k82 ; k82 = 170
.line	676	loadk        r20   k89 ; k89 = 152
.line	676	loadk        r21   k55 ; k55 = 165
.line	676	loadk        r22   k90 ; k90 = 236
.line	676	loadk        r23   k91 ; k91 = 119
.line	676	loadk        r24   k92 ; k92 = 164
.line	676	loadk        r25   k93 ; k93 = 78
.line	676	loadk        r26   k94 ; k94 = 32
.line	676	call          r8    19     2
.line	676	getupval      r9    u2
.line	676	loadk        r10   k57 ; k57 = 136
.line	676	loadk        r11   k95 ; k95 = 19
.line	676	loadk        r12   k96 ; k96 = 57
.line	676	loadk        r13   k17 ; k17 = 166
.line	676	loadk        r14   k97 ; k97 = 181
.line	676	loadk        r15   k98 ; k98 = 227
.line	676	loadk        r16   k38 ; k38 = 86
.line	676	loadk        r17   k99 ; k99 = 75
.line	676	loadk        r18  k100 ; k100 = 97
.line	676	loadk        r19  k101 ; k101 = 209
.line	676	loadk        r20   k40 ; k40 = 162
.line	676	loadk        r21  k102 ; k102 = 148
.line	676	loadk        r22   k92 ; k92 = 164
.line	676	loadk        r23  k103 ; k103 = 193
.line	676	loadk        r24  k104 ; k104 = 122
.line	676	call          r9    16     2
.line	676	gettable     r10    r0    k4 ; k4 = "Owner"
.line	676	gettable     r10   r10    k5 ; k5 = "Object"
.line	676	gettable     r10   r10  k105 ; k105 = "UID"
.line	676	move         r11    r6
.line	676	call          r7     5     1
.label	l182
.line	676	return        r0     1
.line	676	move          r0    r0
.line	676	move          r0    r0
.line	676	move          r0    r0
.line	676	move          r0    r0
.line	676	return        r0     1

.function	main/f37

.source	null
.linedefined	689
.lastlinedefined	694
.numparams	1
.is_vararg	0
.maxstacksize	16

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"slua"
.constant	k1	"isValid"
.constant	k2	"CGameState"
.constant	k3	"GetGameModeState"
.constant	k4	158
.constant	k5	22
.constant	k6	54
.constant	k7	182
.constant	k8	163
.constant	k9	249
.constant	k10	114
.constant	k11	124
.constant	k12	96
.constant	k13	247
.constant	k14	166
.constant	k15	131
.constant	k16	174

.line	689	gettabup      r1    u0    k0 ; k0 = "slua"
.line	689	gettable      r1    r1    k1 ; k1 = "isValid"
.line	689	gettabup      r2    u0    k2 ; k2 = "CGameState"
.line	689	call          r1     2     2
.line	689	test          r1     0
.line	689	jmp            0   l11
.line	689	gettabup      r1    u0    k2 ; k2 = "CGameState"
.line	689	gettable      r1    r1    k3 ; k3 = "GetGameModeState"
.line	689	test          r1     1
.line	689	jmp            0   l13
.label	l11
.line	689	loadbool      r1     0     0
.line	689	return        r1     2
.label	l13
.line	689	gettabup      r1    u0    k2 ; k2 = "CGameState"
.line	689	self          r1    r1    k3 ; k3 = "GetGameModeState"
.line	689	call          r1     2     2
.line	689	getupval      r2    u1
.line	689	loadk         r3    k4 ; k4 = 158
.line	689	loadk         r4    k5 ; k5 = 22
.line	689	loadk         r5    k6 ; k6 = 54
.line	689	loadk         r6    k7 ; k7 = 182
.line	689	loadk         r7    k8 ; k8 = 163
.line	689	loadk         r8    k9 ; k9 = 249
.line	689	loadk         r9   k10 ; k10 = 114
.line	689	loadk        r10   k11 ; k11 = 124
.line	689	loadk        r11   k12 ; k12 = 96
.line	689	loadk        r12   k13 ; k13 = 247
.line	689	loadk        r13   k14 ; k14 = 166
.line	689	loadk        r14   k15 ; k15 = 131
.line	689	loadk        r15   k16 ; k16 = 174
.line	689	call          r2    14     2
.line	689	eq             1    r1    r2
.line	689	jmp            0   l34
.line	689	loadbool      r1     0     1
.label	l34
.line	689	loadbool      r1     1     0
.line	689	return        r1     2
.line	689	return        r0     1
.line	689	move          r0    r0
.line	689	move          r0    r0
.line	689	return        r0     1

.function	main/f38

.source	null
.linedefined	696
.lastlinedefined	710
.numparams	3
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	9	true
.upvalue	"U1"	1	true
.upvalue	"U2"	0	false
.upvalue	"U3"	6	true

.constant	k0	0
.constant	k1	150
.constant	k2	16
.constant	k3	54
.constant	k4	186
.constant	k5	"print"
.constant	k6	"bWriteLog"
.constant	k7	"string"
.constant	k8	"format"
.constant	k9	"table"
.constant	k10	"concat"
.constant	k11	131
.constant	k12	26
.constant	k13	42
.constant	k14	173
.constant	k15	191
.constant	k16	227
.constant	k17	74
.constant	k18	56
.constant	k19	126
.constant	k20	207
.constant	k21	134
.constant	k22	190
.constant	k23	157
.constant	k24	220
.constant	k25	119
.constant	k26	169
.constant	k27	77
.constant	k28	9
.constant	k29	142
.constant	k30	84
.constant	k31	212
.constant	k32	21
.constant	k33	25
.constant	k34	192
.constant	k35	178
.constant	k36	147
.constant	k37	137
.constant	k38	240
.constant	k39	90
.constant	k40	107
.constant	k41	139
.constant	k42	89
.constant	k43	197
.constant	k44	27
.constant	k45	93
.constant	k46	28
.constant	k47	61
.constant	k48	177
.constant	k49	181
.constant	k50	223
.constant	k51	118
.constant	k52	117
.constant	k53	86
.constant	k54	175
.constant	k55	231
.constant	k56	130
.constant	k57	165
.constant	k58	216
.constant	k59	112
.constant	k60	95
.constant	k61	33
.constant	k62	8
.constant	k63	156
.constant	k64	67
.constant	k65	196
.constant	k66	3
.constant	k67	253
.constant	k68	182
.constant	k69	138
.constant	k70	153
.constant	k71	43
.constant	k72	20
.constant	k73	127
.constant	k74	125
.constant	k75	135
.constant	k76	68
.constant	k77	195
.constant	k78	22
.constant	k79	2
.constant	k80	12
.constant	k81	"tostring"
.constant	k82	"Client"
.constant	k83	"nRSTSSceneID"
.constant	k84	"SendMLAIVoiceDebugInfo"
.constant	k85	"ASRStateChange"
.constant	k86	245
.constant	k87	"ApplyRSTSSceneID"

.line	696	test          r1     1
.line	696	jmp            0    l4
.line	696	return        r0     1
.label	l4
.line	696	gettabup      r3    u0    r1
.line	696	test          r3     1
.line	696	jmp            0    l8
.line	696	loadk         r3    k0 ; k0 = 0
.label	l8
.line	696	eq             0    r3    k0 ; k0 = 0
.line	696	jmp            0  l125
.line	696	getupval      r4    u1
.line	696	loadk         r5    k1 ; k1 = 150
.line	696	loadk         r6    k2 ; k2 = 16
.line	696	loadk         r7    k3 ; k3 = 54
.line	696	loadk         r8    k4 ; k4 = 186
.line	696	call          r4     5     2
.line	696	eq             1    r1    r4
.line	696	jmp            0  l125
.line	696	gettabup      r4    u2    k5 ; k5 = "print"
.line	696	gettabup      r5    u2    k6 ; k6 = "bWriteLog"
.line	696	test          r5     0
.line	696	jmp            0  l124
.line	696	gettabup      r5    u2    k7 ; k7 = "string"
.line	696	gettable      r5    r5    k8 ; k8 = "format"
.line	696	gettabup      r6    u2    k9 ; k9 = "table"
.line	696	gettable      r6    r6   k10 ; k10 = "concat"
.line	696	newtable      r7     2     0
.line	696	getupval      r8    u1
.line	696	loadk         r9   k11 ; k11 = 131
.line	696	loadk        r10   k12 ; k12 = 26
.line	696	loadk        r11   k13 ; k13 = 42
.line	696	loadk        r12   k14 ; k14 = 173
.line	696	loadk        r13   k15 ; k15 = 191
.line	696	loadk        r14   k16 ; k16 = 227
.line	696	loadk        r15   k17 ; k17 = 74
.line	696	loadk        r16   k18 ; k18 = 56
.line	696	loadk        r17   k19 ; k19 = 126
.line	696	loadk        r18   k20 ; k20 = 207
.line	696	loadk        r19   k21 ; k21 = 134
.line	696	loadk        r20   k22 ; k22 = 190
.line	696	loadk        r21   k23 ; k23 = 157
.line	696	loadk        r22   k24 ; k24 = 220
.line	696	loadk        r23   k25 ; k25 = 119
.line	696	loadk        r24   k26 ; k26 = 169
.line	696	loadk        r25   k27 ; k27 = 77
.line	696	loadk        r26   k28 ; k28 = 9
.line	696	loadk        r27   k27 ; k27 = 77
.line	696	loadk        r28   k29 ; k29 = 142
.line	696	loadk        r29   k30 ; k30 = 84
.line	696	loadk        r30   k31 ; k31 = 212
.line	696	loadk        r31   k32 ; k32 = 21
.line	696	loadk        r32   k27 ; k27 = 77
.line	696	loadk        r33   k33 ; k33 = 25
.line	696	loadk        r34   k34 ; k34 = 192
.line	696	loadk        r35   k35 ; k35 = 178
.line	696	loadk        r36   k36 ; k36 = 147
.line	696	loadk        r37   k37 ; k37 = 137
.line	696	loadk        r38   k38 ; k38 = 240
.line	696	loadk        r39   k39 ; k39 = 90
.line	696	loadk        r40   k37 ; k37 = 137
.line	696	loadk        r41   k40 ; k40 = 107
.line	696	loadk        r42   k13 ; k13 = 42
.line	696	loadk        r43   k39 ; k39 = 90
.line	696	loadk        r44   k41 ; k41 = 139
.line	696	loadk        r45   k42 ; k42 = 89
.line	696	loadk        r46   k43 ; k43 = 197
.line	696	loadk        r47   k44 ; k44 = 27
.line	696	loadk        r48   k45 ; k45 = 93
.line	696	call          r8    41     2
.line	696	getupval      r9    u1
.line	696	loadk        r10   k41 ; k41 = 139
.line	696	loadk        r11   k46 ; k46 = 28
.line	696	loadk        r12   k47 ; k47 = 61
.line	696	loadk        r13   k48 ; k48 = 177
.line	696	loadk        r14   k49 ; k49 = 181
.line	696	loadk        r15   k50 ; k50 = 223
.line	696	loadk        r16   k51 ; k51 = 118
.line	696	loadk        r17   k52 ; k52 = 117
.line	696	loadk        r18   k53 ; k53 = 86
.line	696	loadk        r19   k54 ; k54 = 175
.line	696	loadk        r20   k55 ; k55 = 231
.line	696	loadk        r21   k56 ; k56 = 130
.line	696	loadk        r22   k57 ; k57 = 165
.line	696	loadk        r23   k58 ; k58 = 216
.line	696	loadk        r24   k59 ; k59 = 112
.line	696	loadk        r25   k57 ; k57 = 165
.line	696	loadk        r26   k60 ; k60 = 95
.line	696	loadk        r27   k61 ; k61 = 33
.line	696	loadk        r28   k62 ; k62 = 8
.line	696	loadk        r29   k63 ; k63 = 156
.line	696	loadk        r30   k64 ; k64 = 67
.line	696	loadk        r31   k65 ; k65 = 196
.line	696	loadk        r32   k28 ; k28 = 9
.line	696	loadk        r33   k27 ; k27 = 77
.line	696	loadk        r34   k66 ; k66 = 3
.line	696	loadk        r35   k67 ; k67 = 253
.line	696	loadk        r36   k68 ; k68 = 182
.line	696	loadk        r37   k69 ; k69 = 138
.line	696	loadk        r38   k22 ; k22 = 190
.line	696	loadk        r39   k70 ; k70 = 153
.line	696	loadk        r40   k71 ; k71 = 43
.line	696	loadk        r41   k26 ; k26 = 169
.line	696	loadk        r42   k72 ; k72 = 20
.line	696	loadk        r43   k73 ; k73 = 127
.line	696	loadk        r44   k74 ; k74 = 125
.line	696	loadk        r45   k75 ; k75 = 135
.line	696	loadk        r46   k76 ; k76 = 68
.line	696	loadk        r47   k77 ; k77 = 195
.line	696	loadk        r48   k78 ; k78 = 22
.line	696	loadk        r49   k79 ; k79 = 2
.line	696	call          r9    41     2
.line	696	getupval     r10    u1
.line	696	loadk        r11   k67 ; k67 = 253
.line	696	loadk        r12   k80 ; k80 = 12
.line	696	call         r10     3     0
.line	696	setlist       r7     0     1
.line	696	call          r6     2     2
.line	696	gettabup      r7    u2   k81 ; k81 = "tostring"
.line	696	move          r8    r1
.line	696	call          r7     2     2
.line	696	gettabup      r8    u2   k81 ; k81 = "tostring"
.line	696	move          r9    r2
.line	696	call          r8     2     0
.line	696	call          r5     0     2
.label	l124
.line	696	call          r4     2     1
.label	l125
.line	696	gettabup      r4    u2   k82 ; k82 = "Client"
.line	696	test          r4     0
.line	696	jmp            0  l141
.line	696	settable      r0   k83    r3 ; k83 = "nRSTSSceneID"
.line	696	self          r4    r0   k84 ; k84 = "SendMLAIVoiceDebugIn" (truncated)
.line	696	gettabup      r6    u3   k85 ; k85 = "ASRStateChange"
.line	696	gettabup      r7    u2   k81 ; k81 = "tostring"
.line	696	gettable      r8    r0   k83 ; k83 = "nRSTSSceneID"
.line	696	call          r7     2     2
.line	696	getupval      r8    u1
.line	696	loadk         r9   k86 ; k86 = 245
.line	696	call          r8     2     2
.line	696	move          r9    r2
.line	696	concat        r7    r7    r9
.line	696	call          r4     4     1
.line	696	return        r0     1
.label	l141
.line	696	self          r4    r0   k87 ; k87 = "ApplyRSTSSceneID"
.line	696	move          r6    r3
.line	696	move          r7    r2
.line	696	call          r4     4     1
.line	696	return        r0     1
.line	696	move          r0    r0
.line	696	return        r0     1

.function	main/f39

.source	null
.linedefined	712
.lastlinedefined	723
.numparams	3
.is_vararg	0
.maxstacksize	11

.upvalue	"_ENV"	0	false
.upvalue	"U1"	6	true
.upvalue	"U2"	1	true

.constant	k0	"Client"
.constant	k1	"_ArbitrateRSTSSceneID"
.constant	k2	0
.constant	k3	nil
.constant	k4	"nRSTSSceneID"
.constant	k5	"SendMLAIVoiceDebugInfo"
.constant	k6	"ASRStateChange"
.constant	k7	"tostring"
.constant	k8	245
.constant	k9	"_TryRestoreSceneLessDialogTarget"

.line	712	gettabup      r3    u0    k0 ; k0 = "Client"
.line	712	test          r3     0
.line	712	jmp            0    l5
.line	712	return        r0     1
.label	l5
.line	712	self          r3    r0    k1 ; k1 = "_ArbitrateRSTSSceneI" (truncated)
.line	712	testset       r5    r1     1
.line	712	jmp            0    l9
.line	712	loadk         r5    k2 ; k2 = 0
.label	l9
.line	712	move          r6    r2
.line	712	call          r3     4     2
.line	712	eq             0    r3    k3 ; k3 = nil
.line	712	jmp            0   l14
.line	712	return        r0     1
.label	l14
.line	712	settable      r0    k4    r3 ; k4 = "nRSTSSceneID"
.line	712	self          r4    r0    k5 ; k5 = "SendMLAIVoiceDebugIn" (truncated)
.line	712	gettabup      r6    u1    k6 ; k6 = "ASRStateChange"
.line	712	gettabup      r7    u0    k7 ; k7 = "tostring"
.line	712	move          r8    r3
.line	712	call          r7     2     2
.line	712	getupval      r8    u2
.line	712	loadk         r9    k8 ; k8 = 245
.line	712	call          r8     2     2
.line	712	gettabup      r9    u0    k7 ; k7 = "tostring"
.line	712	move         r10    r2
.line	712	call          r9     2     2
.line	712	concat        r7    r7    r9
.line	712	call          r4     4     1
.line	712	self          r4    r0    k9 ; k9 = "_TryRestoreSceneLess" (truncated)
.line	712	move          r6    r2
.line	712	call          r4     3     1
.line	712	return        r0     1
.line	712	move          r0    r0
.line	712	move          r0    r0
.line	712	move          r0    r0
.line	712	move          r0    r0
.line	712	return        r0     1

.function	main/f40

.source	null
.linedefined	725
.lastlinedefined	736
.numparams	3
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	9	true
.upvalue	"U2"	1	true

.constant	k0	"Client"
.constant	k1	0
.constant	k2	"nRSTSSceneID"
.constant	k3	"print"
.constant	k4	"bWriteLog"
.constant	k5	"string"
.constant	k6	"format"
.constant	k7	"table"
.constant	k8	"concat"
.constant	k9	149
.constant	k10	51
.constant	k11	25
.constant	k12	150
.constant	k13	134
.constant	k14	254
.constant	k15	126
.constant	k16	123
.constant	k17	86
.constant	k18	197
.constant	k19	162
.constant	k20	191
.constant	k21	198
.constant	k22	108
.constant	k23	175
.constant	k24	18
.constant	k25	12
.constant	k26	68
.constant	k27	128
.constant	k28	83
.constant	k29	196
.constant	k30	53
.constant	k31	119
.constant	k32	192
.constant	k33	132
.constant	k34	190
.constant	k35	205
.constant	k36	107
.constant	k37	147
.constant	k38	94
.constant	k39	28
.constant	k40	77
.constant	k41	141
.constant	k42	66
.constant	k43	212
.constant	k44	76
.constant	k45	244
.constant	k46	95
.constant	k47	11
.constant	k48	188
.constant	k49	181
.constant	k50	255
.constant	k51	114
.constant	k52	34
.constant	k53	22
.constant	k54	240
.constant	k55	235
.constant	k56	215
.constant	k57	142
.constant	k58	203
.constant	k59	106
.constant	k60	184
.constant	k61	73
.constant	k62	117
.constant	k63	13
.constant	k64	156
.constant	k65	"tostring"
.constant	k66	"ApplyRSTSSceneID"

.line	725	gettabup      r3    u0    k0 ; k0 = "Client"
.line	725	test          r3     0
.line	725	jmp            0    l6
.line	725	loadbool      r3     0     0
.line	725	return        r3     2
.label	l6
.line	725	gettabup      r3    u1    r1
.line	725	test          r3     1
.line	725	jmp            0   l10
.line	725	loadk         r3    k1 ; k1 = 0
.label	l10
.line	725	le             1    r3    k1 ; k1 = 0
.line	725	jmp            0   l15
.line	725	gettable      r4    r0    k2 ; k2 = "nRSTSSceneID"
.line	725	eq             1    r4    r3
.line	725	jmp            0   l17
.label	l15
.line	725	loadbool      r4     0     0
.line	725	return        r4     2
.label	l17
.line	725	gettabup      r4    u0    k3 ; k3 = "print"
.line	725	gettabup      r5    u0    k4 ; k4 = "bWriteLog"
.line	725	test          r5     0
.line	725	jmp            0   l99
.line	725	gettabup      r5    u0    k5 ; k5 = "string"
.line	725	gettable      r5    r5    k6 ; k6 = "format"
.line	725	gettabup      r6    u0    k7 ; k7 = "table"
.line	725	gettable      r6    r6    k8 ; k8 = "concat"
.line	725	newtable      r7     1     0
.line	725	getupval      r8    u2
.line	725	loadk         r9    k9 ; k9 = 149
.line	725	loadk        r10   k10 ; k10 = 51
.line	725	loadk        r11   k11 ; k11 = 25
.line	725	loadk        r12   k12 ; k12 = 150
.line	725	loadk        r13   k13 ; k13 = 134
.line	725	loadk        r14   k14 ; k14 = 254
.line	725	loadk        r15   k15 ; k15 = 126
.line	725	loadk        r16   k16 ; k16 = 123
.line	725	loadk        r17   k17 ; k17 = 86
.line	725	loadk        r18   k18 ; k18 = 197
.line	725	loadk        r19   k19 ; k19 = 162
.line	725	loadk        r20   k12 ; k12 = 150
.line	725	loadk        r21   k20 ; k20 = 191
.line	725	loadk        r22   k21 ; k21 = 198
.line	725	loadk        r23   k22 ; k22 = 108
.line	725	loadk        r24   k23 ; k23 = 175
.line	725	loadk        r25   k24 ; k24 = 18
.line	725	loadk        r26   k25 ; k25 = 12
.line	725	loadk        r27   k26 ; k26 = 68
.line	725	loadk        r28   k27 ; k27 = 128
.line	725	loadk        r29   k28 ; k28 = 83
.line	725	loadk        r30   k29 ; k29 = 196
.line	725	loadk        r31   k30 ; k30 = 53
.line	725	loadk        r32   k16 ; k16 = 123
.line	725	loadk        r33   k31 ; k31 = 119
.line	725	loadk        r34   k32 ; k32 = 192
.line	725	loadk        r35   k33 ; k33 = 132
.line	725	loadk        r36   k33 ; k33 = 132
.line	725	loadk        r37   k34 ; k34 = 190
.line	725	loadk        r38   k35 ; k35 = 205
.line	725	loadk        r39   k36 ; k36 = 107
.line	725	loadk        r40   k37 ; k37 = 147
.line	725	loadk        r41   k38 ; k38 = 94
.line	725	loadk        r42   k39 ; k39 = 28
.line	725	loadk        r43   k40 ; k40 = 77
.line	725	loadk        r44   k41 ; k41 = 141
.line	725	loadk        r45   k42 ; k42 = 66
.line	725	loadk        r46   k43 ; k43 = 212
.line	725	loadk        r47   k11 ; k11 = 25
.line	725	loadk        r48   k44 ; k44 = 76
.line	725	call          r8    41     2
.line	725	getupval      r9    u2
.line	725	loadk        r10   k45 ; k45 = 244
.line	725	loadk        r11   k46 ; k46 = 95
.line	725	loadk        r12   k47 ; k47 = 11
.line	725	loadk        r13   k48 ; k48 = 188
.line	725	loadk        r14   k49 ; k49 = 181
.line	725	loadk        r15   k50 ; k50 = 255
.line	725	loadk        r16   k51 ; k51 = 114
.line	725	loadk        r17   k52 ; k52 = 34
.line	725	loadk        r18   k53 ; k53 = 22
.line	725	loadk        r19   k54 ; k54 = 240
.line	725	loadk        r20   k55 ; k55 = 235
.line	725	loadk        r21   k56 ; k56 = 215
.line	725	loadk        r22   k57 ; k57 = 142
.line	725	loadk        r23   k58 ; k58 = 203
.line	725	loadk        r24   k59 ; k59 = 106
.line	725	loadk        r25   k60 ; k60 = 184
.line	725	loadk        r26   k61 ; k61 = 73
.line	725	loadk        r27   k62 ; k62 = 117
.line	725	loadk        r28   k63 ; k63 = 13
.line	725	loadk        r29   k64 ; k64 = 156
.line	725	call          r9    21     0
.line	725	setlist       r7     0     1
.line	725	call          r6     2     2
.line	725	gettabup      r7    u0   k65 ; k65 = "tostring"
.line	725	move          r8    r1
.line	725	call          r7     2     2
.line	725	gettabup      r8    u0   k65 ; k65 = "tostring"
.line	725	move          r9    r2
.line	725	call          r8     2     0
.line	725	call          r5     0     2
.label	l99
.line	725	call          r4     2     1
.line	725	self          r4    r0   k66 ; k66 = "ApplyRSTSSceneID"
.line	725	loadk         r6    k1 ; k1 = 0
.line	725	move          r7    r2
.line	725	call          r4     4     1
.line	725	loadbool      r4     1     0
.line	725	return        r4     2
.line	725	return        r0     1
.line	725	move          r0    r0
.line	725	return        r0     1

.function	main/f41

.source	null
.linedefined	738
.lastlinedefined	757
.numparams	3
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	3	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"Enum_ASRSceneID"
.constant	k1	"PublicOpinion"
.constant	k2	"nRSTSSceneID"
.constant	k3	0
.constant	k4	"bPublicOpinionASRDesired"
.constant	k5	true
.constant	k6	"print"
.constant	k7	"bWriteLog"
.constant	k8	"string"
.constant	k9	"format"
.constant	k10	"table"
.constant	k11	"concat"
.constant	k12	149
.constant	k13	51
.constant	k14	25
.constant	k15	150
.constant	k16	134
.constant	k17	254
.constant	k18	126
.constant	k19	123
.constant	k20	86
.constant	k21	197
.constant	k22	162
.constant	k23	191
.constant	k24	198
.constant	k25	108
.constant	k26	175
.constant	k27	18
.constant	k28	16
.constant	k29	105
.constant	k30	157
.constant	k31	66
.constant	k32	200
.constant	k33	19
.constant	k34	90
.constant	k35	231
.constant	k36	178
.constant	k37	181
.constant	k38	136
.constant	k39	247
.constant	k40	93
.constant	k41	137
.constant	k42	91
.constant	k43	58
.constant	k44	154
.constant	k45	121
.constant	k46	245
.constant	k47	87
.constant	k48	180
.constant	k49	59
.constant	k50	55
.constant	k51	122
.constant	k52	74
.constant	k53	163
.constant	k54	158
.constant	k55	172
.constant	k56	219
.constant	k57	184
.constant	k58	8
.constant	k59	63
.constant	k60	79
.constant	k61	211
.constant	k62	14
.constant	k63	92
.constant	k64	179
.constant	k65	164
.constant	k66	132
.constant	k67	190
.constant	k68	205
.constant	k69	107
.constant	k70	246
.constant	k71	24
.constant	k72	28
.constant	k73	77
.constant	k74	141
.constant	k75	10
.constant	k76	148
.constant	k77	4
.constant	k78	20
.constant	k79	248
.constant	k80	32
.constant	k81	171
.constant	k82	240
.constant	k83	45
.constant	k84	61
.constant	k85	64
.constant	k86	"tostring"
.constant	k87	94
.constant	k88	185
.constant	k89	52
.constant	k90	189
.constant	k91	177
.constant	k92	242
.constant	k93	124
.constant	k94	56
.constant	k95	71
.constant	k96	236
.constant	k97	167
.constant	k98	209
.constant	k99	114
.constant	k100	75
.constant	k101	88
.constant	k102	78
.constant	k103	70
.constant	k104	15
.constant	k105	146
.constant	k106	169
.constant	k107	153
.constant	k108	43
.constant	k109	127
.constant	k110	125
.constant	k111	135
.constant	k112	68
.constant	k113	195
.constant	k114	22
.constant	k115	2
.constant	k116	253
.constant	k117	12

.line	738	gettabup      r3    u0    k0 ; k0 = "Enum_ASRSceneID"
.line	738	gettable      r3    r3    k1 ; k1 = "PublicOpinion"
.line	738	gettable      r4    r0    k2 ; k2 = "nRSTSSceneID"
.line	738	test          r4     1
.line	738	jmp            0    l7
.line	738	loadk         r4    k3 ; k3 = 0
.label	l7
.line	738	eq             0    r1    r3
.line	738	jmp            0  l131
.line	738	settable      r0    k4    k5 ; k5 = true
.line	738	lt             0    k3    r4 ; k3 = 0
.line	738	jmp            0  l130
.line	738	eq             1    r4    r3
.line	738	jmp            0  l130
.line	738	gettabup      r5    u1    k6 ; k6 = "print"
.line	738	gettabup      r6    u1    k7 ; k7 = "bWriteLog"
.line	738	test          r6     0
.line	738	jmp            0  l127
.line	738	gettabup      r6    u1    k8 ; k8 = "string"
.line	738	gettable      r6    r6    k9 ; k9 = "format"
.line	738	gettabup      r7    u1   k10 ; k10 = "table"
.line	738	gettable      r7    r7   k11 ; k11 = "concat"
.line	738	newtable      r8     2     0
.line	738	getupval      r9    u2
.line	738	loadk        r10   k12 ; k12 = 149
.line	738	loadk        r11   k13 ; k13 = 51
.line	738	loadk        r12   k14 ; k14 = 25
.line	738	loadk        r13   k15 ; k15 = 150
.line	738	loadk        r14   k16 ; k16 = 134
.line	738	loadk        r15   k17 ; k17 = 254
.line	738	loadk        r16   k18 ; k18 = 126
.line	738	loadk        r17   k19 ; k19 = 123
.line	738	loadk        r18   k20 ; k20 = 86
.line	738	loadk        r19   k21 ; k21 = 197
.line	738	loadk        r20   k22 ; k22 = 162
.line	738	loadk        r21   k15 ; k15 = 150
.line	738	loadk        r22   k23 ; k23 = 191
.line	738	loadk        r23   k24 ; k24 = 198
.line	738	loadk        r24   k25 ; k25 = 108
.line	738	loadk        r25   k26 ; k26 = 175
.line	738	loadk        r26   k27 ; k27 = 18
.line	738	loadk        r27   k28 ; k28 = 16
.line	738	loadk        r28   k29 ; k29 = 105
.line	738	loadk        r29   k30 ; k30 = 157
.line	738	loadk        r30   k31 ; k31 = 66
.line	738	loadk        r31   k32 ; k32 = 200
.line	738	loadk        r32   k33 ; k33 = 19
.line	738	loadk        r33   k34 ; k34 = 90
.line	738	loadk        r34   k31 ; k31 = 66
.line	738	loadk        r35   k35 ; k35 = 231
.line	738	loadk        r36   k36 ; k36 = 178
.line	738	loadk        r37   k37 ; k37 = 181
.line	738	loadk        r38   k38 ; k38 = 136
.line	738	loadk        r39   k39 ; k39 = 247
.line	738	loadk        r40   k40 ; k40 = 93
.line	738	loadk        r41   k41 ; k41 = 137
.line	738	loadk        r42   k42 ; k42 = 91
.line	738	loadk        r43   k43 ; k43 = 58
.line	738	loadk        r44   k20 ; k20 = 86
.line	738	loadk        r45   k44 ; k44 = 154
.line	738	loadk        r46   k45 ; k45 = 121
.line	738	loadk        r47   k46 ; k46 = 245
.line	738	loadk        r48   k47 ; k47 = 87
.line	738	loadk        r49   k34 ; k34 = 90
.line	738	call          r9    41     2
.line	738	getupval     r10    u2
.line	738	loadk        r11   k48 ; k48 = 180
.line	738	loadk        r12   k28 ; k28 = 16
.line	738	loadk        r13   k49 ; k49 = 59
.line	738	loadk        r14   k48 ; k48 = 180
.line	738	loadk        r15   k37 ; k37 = 181
.line	738	loadk        r16   k46 ; k46 = 245
.line	738	loadk        r17   k50 ; k50 = 55
.line	738	loadk        r18   k51 ; k51 = 122
.line	738	loadk        r19   k52 ; k52 = 74
.line	738	loadk        r20   k53 ; k53 = 163
.line	738	loadk        r21   k26 ; k26 = 175
.line	738	loadk        r22   k54 ; k54 = 158
.line	738	loadk        r23   k55 ; k55 = 172
.line	738	loadk        r24   k56 ; k56 = 219
.line	738	loadk        r25   k19 ; k19 = 123
.line	738	loadk        r26   k57 ; k57 = 184
.line	738	loadk        r27   k58 ; k58 = 8
.line	738	loadk        r28   k59 ; k59 = 63
.line	738	loadk        r29   k34 ; k34 = 90
.line	738	loadk        r30   k16 ; k16 = 134
.line	738	loadk        r31   k60 ; k60 = 79
.line	738	loadk        r32   k61 ; k61 = 211
.line	738	loadk        r33   k62 ; k62 = 14
.line	738	loadk        r34   k63 ; k63 = 92
.line	738	loadk        r35   k34 ; k34 = 90
.line	738	loadk        r36   k64 ; k64 = 179
.line	738	loadk        r37   k65 ; k65 = 164
.line	738	loadk        r38   k66 ; k66 = 132
.line	738	loadk        r39   k67 ; k67 = 190
.line	738	loadk        r40   k68 ; k68 = 205
.line	738	loadk        r41   k69 ; k69 = 107
.line	738	loadk        r42   k70 ; k70 = 246
.line	738	loadk        r43   k71 ; k71 = 24
.line	738	loadk        r44   k72 ; k72 = 28
.line	738	loadk        r45   k73 ; k73 = 77
.line	738	loadk        r46   k74 ; k74 = 141
.line	738	loadk        r47   k75 ; k75 = 10
.line	738	loadk        r48   k76 ; k76 = 148
.line	738	loadk        r49   k77 ; k77 = 4
.line	738	loadk        r50   k78 ; k78 = 20
.line	738	call         r10    41     2
.line	738	getupval     r11    u2
.line	738	loadk        r12   k79 ; k79 = 248
.line	738	loadk        r13   k43 ; k43 = 58
.line	738	loadk        r14   k80 ; k80 = 32
.line	738	loadk        r15   k81 ; k81 = 171
.line	738	loadk        r16   k22 ; k22 = 162
.line	738	loadk        r17   k82 ; k82 = 240
.line	738	loadk        r18   k83 ; k83 = 45
.line	738	loadk        r19   k84 ; k84 = 61
.line	738	loadk        r20   k85 ; k85 = 64
.line	738	call         r11    10     0
.line	738	setlist       r8     0     1
.line	738	call          r7     2     2
.line	738	gettabup      r8    u1   k86 ; k86 = "tostring"
.line	738	move          r9    r4
.line	738	call          r8     2     2
.line	738	gettabup      r9    u1   k86 ; k86 = "tostring"
.line	738	move         r10    r2
.line	738	call          r9     2     0
.line	738	call          r6     0     2
.label	l127
.line	738	call          r5     2     1
.line	738	loadnil       r5     0
.line	738	return        r5     2
.label	l130
.line	738	return        r3     2
.label	l131
.line	738	le             0    r1    k3 ; k3 = 0
.line	738	jmp            0  l246
.line	738	gettable      r5    r0    k4 ; k4 = "bPublicOpinionASRDes" (truncated)
.line	738	test          r5     0
.line	738	jmp            0  l244
.line	738	gettabup      r5    u1    k6 ; k6 = "print"
.line	738	gettabup      r6    u1    k7 ; k7 = "bWriteLog"
.line	738	test          r6     0
.line	738	jmp            0  l242
.line	738	gettabup      r6    u1    k8 ; k8 = "string"
.line	738	gettable      r6    r6    k9 ; k9 = "format"
.line	738	gettabup      r7    u1   k10 ; k10 = "table"
.line	738	gettable      r7    r7   k11 ; k11 = "concat"
.line	738	newtable      r8     2     0
.line	738	getupval      r9    u2
.line	738	loadk        r10   k12 ; k12 = 149
.line	738	loadk        r11   k13 ; k13 = 51
.line	738	loadk        r12   k14 ; k14 = 25
.line	738	loadk        r13   k15 ; k15 = 150
.line	738	loadk        r14   k16 ; k16 = 134
.line	738	loadk        r15   k17 ; k17 = 254
.line	738	loadk        r16   k18 ; k18 = 126
.line	738	loadk        r17   k19 ; k19 = 123
.line	738	loadk        r18   k20 ; k20 = 86
.line	738	loadk        r19   k21 ; k21 = 197
.line	738	loadk        r20   k22 ; k22 = 162
.line	738	loadk        r21   k15 ; k15 = 150
.line	738	loadk        r22   k23 ; k23 = 191
.line	738	loadk        r23   k24 ; k24 = 198
.line	738	loadk        r24   k25 ; k25 = 108
.line	738	loadk        r25   k26 ; k26 = 175
.line	738	loadk        r26   k27 ; k27 = 18
.line	738	loadk        r27   k28 ; k28 = 16
.line	738	loadk        r28   k29 ; k29 = 105
.line	738	loadk        r29   k30 ; k30 = 157
.line	738	loadk        r30   k31 ; k31 = 66
.line	738	loadk        r31   k32 ; k32 = 200
.line	738	loadk        r32   k33 ; k33 = 19
.line	738	loadk        r33   k34 ; k34 = 90
.line	738	loadk        r34   k31 ; k31 = 66
.line	738	loadk        r35   k35 ; k35 = 231
.line	738	loadk        r36   k36 ; k36 = 178
.line	738	loadk        r37   k37 ; k37 = 181
.line	738	loadk        r38   k38 ; k38 = 136
.line	738	loadk        r39   k39 ; k39 = 247
.line	738	loadk        r40   k40 ; k40 = 93
.line	738	loadk        r41   k41 ; k41 = 137
.line	738	loadk        r42   k42 ; k42 = 91
.line	738	loadk        r43   k43 ; k43 = 58
.line	738	loadk        r44   k20 ; k20 = 86
.line	738	loadk        r45   k44 ; k44 = 154
.line	738	loadk        r46   k45 ; k45 = 121
.line	738	loadk        r47   k46 ; k46 = 245
.line	738	loadk        r48   k47 ; k47 = 87
.line	738	loadk        r49   k87 ; k87 = 94
.line	738	call          r9    41     2
.line	738	getupval     r10    u2
.line	738	loadk        r11   k88 ; k88 = 185
.line	738	loadk        r12   k33 ; k33 = 19
.line	738	loadk        r13   k89 ; k89 = 52
.line	738	loadk        r14   k90 ; k90 = 189
.line	738	loadk        r15   k91 ; k91 = 177
.line	738	loadk        r16   k92 ; k92 = 242
.line	738	loadk        r17   k93 ; k93 = 124
.line	738	loadk        r18   k94 ; k94 = 56
.line	738	loadk        r19   k95 ; k95 = 71
.line	738	loadk        r20   k96 ; k96 = 236
.line	738	loadk        r21   k35 ; k35 = 231
.line	738	loadk        r22   k97 ; k97 = 167
.line	738	loadk        r23   k67 ; k67 = 190
.line	738	loadk        r24   k98 ; k98 = 209
.line	738	loadk        r25   k99 ; k99 = 114
.line	738	loadk        r26   k53 ; k53 = 163
.line	738	loadk        r27  k100 ; k100 = 75
.line	738	loadk        r28    k3 ; k3 = 0
.line	738	loadk        r29  k101 ; k101 = 88
.line	738	loadk        r30   k16 ; k16 = 134
.line	738	loadk        r31  k102 ; k102 = 78
.line	738	loadk        r32   k32 ; k32 = 200
.line	738	loadk        r33   k58 ; k58 = 8
.line	738	loadk        r34  k103 ; k103 = 70
.line	738	loadk        r35  k104 ; k104 = 15
.line	738	loadk        r36   k64 ; k64 = 179
.line	738	loadk        r37   k76 ; k76 = 148
.line	738	loadk        r38  k105 ; k105 = 146
.line	738	loadk        r39  k106 ; k106 = 169
.line	738	loadk        r40  k107 ; k107 = 153
.line	738	loadk        r41  k108 ; k108 = 43
.line	738	loadk        r42  k106 ; k106 = 169
.line	738	loadk        r43   k78 ; k78 = 20
.line	738	loadk        r44  k109 ; k109 = 127
.line	738	loadk        r45  k110 ; k110 = 125
.line	738	loadk        r46  k111 ; k111 = 135
.line	738	loadk        r47  k112 ; k112 = 68
.line	738	loadk        r48  k113 ; k113 = 195
.line	738	loadk        r49  k114 ; k114 = 22
.line	738	loadk        r50  k115 ; k115 = 2
.line	738	call         r10    41     2
.line	738	getupval     r11    u2
.line	738	loadk        r12  k116 ; k116 = 253
.line	738	loadk        r13  k117 ; k117 = 12
.line	738	call         r11     3     0
.line	738	setlist       r8     0     1
.line	738	call          r7     2     2
.line	738	gettabup      r8    u1   k86 ; k86 = "tostring"
.line	738	move          r9    r4
.line	738	call          r8     2     2
.line	738	gettabup      r9    u1   k86 ; k86 = "tostring"
.line	738	move         r10    r2
.line	738	call          r9     2     0
.line	738	call          r6     0     2
.label	l242
.line	738	call          r5     2     1
.line	738	return        r3     2
.label	l244
.line	738	loadk         r5    k3 ; k3 = 0
.line	738	return        r5     2
.label	l246
.line	738	return        r1     2
.line	738	return        r0     1
.line	738	move          r0    r0
.line	738	move          r0    r0
.line	738	move          r0    r0
.line	738	return        r0     1

.function	main/f42

.source	null
.linedefined	759
.lastlinedefined	777
.numparams	3
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	3	true
.upvalue	"U3"	6	true

.constant	k0	"Client"
.constant	k1	"print"
.constant	k2	"bWriteLog"
.constant	k3	"string"
.constant	k4	"format"
.constant	k5	"table"
.constant	k6	"concat"
.constant	k7	149
.constant	k8	51
.constant	k9	25
.constant	k10	150
.constant	k11	134
.constant	k12	254
.constant	k13	126
.constant	k14	123
.constant	k15	86
.constant	k16	197
.constant	k17	162
.constant	k18	191
.constant	k19	198
.constant	k20	108
.constant	k21	175
.constant	k22	18
.constant	k23	28
.constant	k24	77
.constant	k25	155
.constant	k26	112
.constant	k27	212
.constant	k28	5
.constant	k29	68
.constant	k30	74
.constant	k31	240
.constant	k32	152
.constant	k33	151
.constant	k34	178
.constant	k35	205
.constant	k36	103
.constant	k37	181
.constant	k38	30
.constant	k39	107
.constant	k40	173
.constant	k41	99
.constant	k42	22
.constant	k43	76
.constant	k44	189
.constant	k45	83
.constant	k46	120
.constant	k47	159
.constant	k48	225
.constant	k49	114
.constant	k50	118
.constant	k51	9
.constant	k52	166
.constant	k53	180
.constant	k54	219
.constant	k55	235
.constant	k56	246
.constant	k57	102
.constant	k58	190
.constant	k59	90
.constant	k60	46
.constant	k61	202
.constant	k62	"tostring"
.constant	k63	"bPublicOpinionASRDesired"
.constant	k64	"Enum_ASRSceneID"
.constant	k65	"PublicOpinion"
.constant	k66	"ApplyRSTSSceneID"
.constant	k67	136
.constant	k68	10
.constant	k69	58
.constant	k70	179
.constant	k71	185
.constant	k72	242
.constant	k73	88
.constant	k74	104
.constant	k75	237
.constant	k76	174
.constant	k77	165
.constant	k78	147
.constant	k79	81
.constant	k80	186
.constant	k81	33
.constant	k82	"nRSTSSceneID"
.constant	k83	0
.constant	k84	"SendMLAIVoiceDebugInfo"
.constant	k85	"ASRStateChange"
.constant	k86	232
.constant	k87	82
.constant	k88	93
.constant	k89	71
.constant	k90	60
.constant	k91	"HasMLAIVoiceHolder"
.constant	k92	169
.constant	k93	248
.constant	k94	116
.constant	k95	125
.constant	k96	19
.constant	k97	158
.constant	k98	167
.constant	k99	223
.constant	k100	62
.constant	k101	35
.constant	k102	207
.constant	k103	66
.constant	k104	216
.constant	k105	105
.constant	k106	106
.constant	k107	247
.constant	k108	140
.constant	k109	250
.constant	k110	78
.constant	k111	48
.constant	k112	156
.constant	k113	85
.constant	k114	145
.constant	k115	24
.constant	k116	72
.constant	k117	17
.constant	k118	"ChangeMLAIVoiceState"

.line	759	gettabup      r3    u0    k0 ; k0 = "Client"
.line	759	test          r3     0
.line	759	jmp            0    l5
.line	759	return        r0     1
.label	l5
.line	759	gettabup      r3    u0    k1 ; k1 = "print"
.line	759	gettabup      r4    u0    k2 ; k2 = "bWriteLog"
.line	759	test          r4     0
.line	759	jmp            0   l88
.line	759	gettabup      r4    u0    k3 ; k3 = "string"
.line	759	gettable      r4    r4    k4 ; k4 = "format"
.line	759	gettabup      r5    u0    k5 ; k5 = "table"
.line	759	gettable      r5    r5    k6 ; k6 = "concat"
.line	759	newtable      r6     1     0
.line	759	getupval      r7    u1
.line	759	loadk         r8    k7 ; k7 = 149
.line	759	loadk         r9    k8 ; k8 = 51
.line	759	loadk        r10    k9 ; k9 = 25
.line	759	loadk        r11   k10 ; k10 = 150
.line	759	loadk        r12   k11 ; k11 = 134
.line	759	loadk        r13   k12 ; k12 = 254
.line	759	loadk        r14   k13 ; k13 = 126
.line	759	loadk        r15   k14 ; k14 = 123
.line	759	loadk        r16   k15 ; k15 = 86
.line	759	loadk        r17   k16 ; k16 = 197
.line	759	loadk        r18   k17 ; k17 = 162
.line	759	loadk        r19   k10 ; k10 = 150
.line	759	loadk        r20   k18 ; k18 = 191
.line	759	loadk        r21   k19 ; k19 = 198
.line	759	loadk        r22   k20 ; k20 = 108
.line	759	loadk        r23   k21 ; k21 = 175
.line	759	loadk        r24   k22 ; k22 = 18
.line	759	loadk        r25   k23 ; k23 = 28
.line	759	loadk        r26   k24 ; k24 = 77
.line	759	loadk        r27   k25 ; k25 = 155
.line	759	loadk        r28   k26 ; k26 = 112
.line	759	loadk        r29   k27 ; k27 = 212
.line	759	loadk        r30   k28 ; k28 = 5
.line	759	loadk        r31   k29 ; k29 = 68
.line	759	loadk        r32   k30 ; k30 = 74
.line	759	loadk        r33   k31 ; k31 = 240
.line	759	loadk        r34   k32 ; k32 = 152
.line	759	loadk        r35   k33 ; k33 = 151
.line	759	loadk        r36   k34 ; k34 = 178
.line	759	loadk        r37   k35 ; k35 = 205
.line	759	loadk        r38   k36 ; k36 = 103
.line	759	loadk        r39   k37 ; k37 = 181
.line	759	loadk        r40   k15 ; k15 = 86
.line	759	loadk        r41   k38 ; k38 = 30
.line	759	loadk        r42   k39 ; k39 = 107
.line	759	loadk        r43   k40 ; k40 = 173
.line	759	loadk        r44   k41 ; k41 = 99
.line	759	loadk        r45   k16 ; k16 = 197
.line	759	loadk        r46   k42 ; k42 = 22
.line	759	loadk        r47   k43 ; k43 = 76
.line	759	call          r7    41     2
.line	759	getupval      r8    u1
.line	759	loadk         r9   k44 ; k44 = 189
.line	759	loadk        r10   k45 ; k45 = 83
.line	759	loadk        r11   k46 ; k46 = 120
.line	759	loadk        r12   k44 ; k44 = 189
.line	759	loadk        r13   k47 ; k47 = 159
.line	759	loadk        r14   k48 ; k48 = 225
.line	759	loadk        r15   k49 ; k49 = 114
.line	759	loadk        r16   k50 ; k50 = 118
.line	759	loadk        r17   k51 ; k51 = 9
.line	759	loadk        r18   k52 ; k52 = 166
.line	759	loadk        r19   k53 ; k53 = 180
.line	759	loadk        r20   k54 ; k54 = 219
.line	759	loadk        r21   k55 ; k55 = 235
.line	759	loadk        r22   k56 ; k56 = 246
.line	759	loadk        r23   k57 ; k57 = 102
.line	759	loadk        r24   k58 ; k58 = 190
.line	759	loadk        r25   k59 ; k59 = 90
.line	759	loadk        r26   k60 ; k60 = 46
.line	759	loadk        r27   k22 ; k22 = 18
.line	759	loadk        r28   k61 ; k61 = 202
.line	759	loadk        r29   k45 ; k45 = 83
.line	759	call          r8    22     0
.line	759	setlist       r6     0     1
.line	759	call          r5     2     2
.line	759	gettabup      r6    u0   k62 ; k62 = "tostring"
.line	759	move          r7    r1
.line	759	call          r6     2     2
.line	759	gettabup      r7    u0   k62 ; k62 = "tostring"
.line	759	move          r8    r2
.line	759	call          r7     2     0
.line	759	call          r4     0     2
.label	l88
.line	759	call          r3     2     1
.line	759	test          r1     0
.line	759	jmp            0   l94
.line	759	loadbool      r3     1     0
.line	759	test          r3     1
.line	759	jmp            0   l95
.label	l94
.line	759	loadbool      r3     0     0
.label	l95
.line	759	settable      r0   k63    r3 ; k63 = "bPublicOpinionASRDes" (truncated)
.line	759	gettabup      r3    u2   k64 ; k64 = "Enum_ASRSceneID"
.line	759	gettable      r3    r3   k65 ; k65 = "PublicOpinion"
.line	759	test          r1     0
.line	759	jmp            0  l126
.line	759	self          r4    r0   k66 ; k66 = "ApplyRSTSSceneID"
.line	759	move          r6    r3
.line	759	testset       r7    r2     1
.line	759	jmp            0  l124
.line	759	getupval      r7    u1
.line	759	loadk         r8   k67 ; k67 = 136
.line	759	loadk         r9   k68 ; k68 = 10
.line	759	loadk        r10   k69 ; k69 = 58
.line	759	loadk        r11   k70 ; k70 = 179
.line	759	loadk        r12   k71 ; k71 = 185
.line	759	loadk        r13   k72 ; k72 = 242
.line	759	loadk        r14   k73 ; k73 = 88
.line	759	loadk        r15   k74 ; k74 = 104
.line	759	loadk        r16   k59 ; k59 = 90
.line	759	loadk        r17   k75 ; k75 = 237
.line	759	loadk        r18   k76 ; k76 = 174
.line	759	loadk        r19   k32 ; k32 = 152
.line	759	loadk        r20   k77 ; k77 = 165
.line	759	loadk        r21   k78 ; k78 = 147
.line	759	loadk        r22   k79 ; k79 = 81
.line	759	loadk        r23   k80 ; k80 = 186
.line	759	loadk        r24   k24 ; k24 = 77
.line	759	loadk        r25   k81 ; k81 = 33
.line	759	call          r7    19     2
.label	l124
.line	759	call          r4     4     1
.line	759	jmp            0  l272
.label	l126
.line	759	gettable      r4    r0   k82 ; k82 = "nRSTSSceneID"
.line	759	test          r4     1
.line	759	jmp            0  l130
.line	759	loadk         r4   k83 ; k83 = 0
.label	l130
.line	759	eq             0    r4    r3
.line	759	jmp            0  l272
.line	759	settable      r0   k82   k83 ; k83 = 0
.line	759	self          r4    r0   k84 ; k84 = "SendMLAIVoiceDebugIn" (truncated)
.line	759	gettabup      r6    u3   k85 ; k85 = "ASRStateChange"
.line	759	getupval      r7    u1
.line	759	loadk         r8   k86 ; k86 = 232
.line	759	loadk         r9   k87 ; k87 = 82
.line	759	call          r7     3     2
.line	759	gettabup      r8    u0   k62 ; k62 = "tostring"
.line	759	testset       r9    r2     1
.line	759	jmp            0  l163
.line	759	getupval      r9    u1
.line	759	loadk        r10   k67 ; k67 = 136
.line	759	loadk        r11   k68 ; k68 = 10
.line	759	loadk        r12   k69 ; k69 = 58
.line	759	loadk        r13   k70 ; k70 = 179
.line	759	loadk        r14   k71 ; k71 = 185
.line	759	loadk        r15   k72 ; k72 = 242
.line	759	loadk        r16   k73 ; k73 = 88
.line	759	loadk        r17   k74 ; k74 = 104
.line	759	loadk        r18   k59 ; k59 = 90
.line	759	loadk        r19   k75 ; k75 = 237
.line	759	loadk        r20   k76 ; k76 = 174
.line	759	loadk        r21   k32 ; k32 = 152
.line	759	loadk        r22   k77 ; k77 = 165
.line	759	loadk        r23   k78 ; k78 = 147
.line	759	loadk        r24   k88 ; k88 = 93
.line	759	loadk        r25   k52 ; k52 = 166
.line	759	loadk        r26   k89 ; k89 = 71
.line	759	loadk        r27   k90 ; k90 = 60
.line	759	loadk        r28   k24 ; k24 = 77
.line	759	call          r9    20     2
.label	l163
.line	759	call          r8     2     2
.line	759	concat        r7    r7    r8
.line	759	call          r4     4     1
.line	759	self          r4    r0   k91 ; k91 = "HasMLAIVoiceHolder"
.line	759	call          r4     2     2
.line	759	test          r4     0
.line	759	jmp            0  l269
.line	759	gettabup      r4    u0    k1 ; k1 = "print"
.line	759	gettabup      r5    u0    k2 ; k2 = "bWriteLog"
.line	759	test          r5     0
.line	759	jmp            0  l267
.line	759	gettabup      r5    u0    k5 ; k5 = "table"
.line	759	gettable      r5    r5    k6 ; k6 = "concat"
.line	759	newtable      r6     2     0
.line	759	getupval      r7    u1
.line	759	loadk         r8    k7 ; k7 = 149
.line	759	loadk         r9    k8 ; k8 = 51
.line	759	loadk        r10    k9 ; k9 = 25
.line	759	loadk        r11   k10 ; k10 = 150
.line	759	loadk        r12   k11 ; k11 = 134
.line	759	loadk        r13   k12 ; k12 = 254
.line	759	loadk        r14   k13 ; k13 = 126
.line	759	loadk        r15   k14 ; k14 = 123
.line	759	loadk        r16   k15 ; k15 = 86
.line	759	loadk        r17   k16 ; k16 = 197
.line	759	loadk        r18   k17 ; k17 = 162
.line	759	loadk        r19   k10 ; k10 = 150
.line	759	loadk        r20   k18 ; k18 = 191
.line	759	loadk        r21   k19 ; k19 = 198
.line	759	loadk        r22   k20 ; k20 = 108
.line	759	loadk        r23   k21 ; k21 = 175
.line	759	loadk        r24   k22 ; k22 = 18
.line	759	loadk        r25   k23 ; k23 = 28
.line	759	loadk        r26   k24 ; k24 = 77
.line	759	loadk        r27   k25 ; k25 = 155
.line	759	loadk        r28   k26 ; k26 = 112
.line	759	loadk        r29   k27 ; k27 = 212
.line	759	loadk        r30   k28 ; k28 = 5
.line	759	loadk        r31   k29 ; k29 = 68
.line	759	loadk        r32   k30 ; k30 = 74
.line	759	loadk        r33   k31 ; k31 = 240
.line	759	loadk        r34   k32 ; k32 = 152
.line	759	loadk        r35   k33 ; k33 = 151
.line	759	loadk        r36   k34 ; k34 = 178
.line	759	loadk        r37   k35 ; k35 = 205
.line	759	loadk        r38   k36 ; k36 = 103
.line	759	loadk        r39   k37 ; k37 = 181
.line	759	loadk        r40   k15 ; k15 = 86
.line	759	loadk        r41   k38 ; k38 = 30
.line	759	loadk        r42   k39 ; k39 = 107
.line	759	loadk        r43   k40 ; k40 = 173
.line	759	loadk        r44   k41 ; k41 = 99
.line	759	loadk        r45   k16 ; k16 = 197
.line	759	loadk        r46   k42 ; k42 = 22
.line	759	loadk        r47   k43 ; k43 = 76
.line	759	call          r7    41     2
.line	759	getupval      r8    u1
.line	759	loadk         r9   k44 ; k44 = 189
.line	759	loadk        r10   k45 ; k45 = 83
.line	759	loadk        r11   k46 ; k46 = 120
.line	759	loadk        r12   k92 ; k92 = 169
.line	759	loadk        r13   k18 ; k18 = 191
.line	759	loadk        r14   k93 ; k93 = 248
.line	759	loadk        r15   k94 ; k94 = 116
.line	759	loadk        r16   k95 ; k95 = 125
.line	759	loadk        r17   k96 ; k96 = 19
.line	759	loadk        r18   k31 ; k31 = 240
.line	759	loadk        r19   k70 ; k70 = 179
.line	759	loadk        r20   k97 ; k97 = 158
.line	759	loadk        r21   k98 ; k98 = 167
.line	759	loadk        r22   k99 ; k99 = 223
.line	759	loadk        r23  k100 ; k100 = 62
.line	759	loadk        r24   k17 ; k17 = 162
.line	759	loadk        r25   k24 ; k24 = 77
.line	759	loadk        r26  k101 ; k101 = 35
.line	759	loadk        r27   k43 ; k43 = 76
.line	759	loadk        r28  k102 ; k102 = 207
.line	759	loadk        r29  k103 ; k103 = 66
.line	759	loadk        r30  k104 ; k104 = 216
.line	759	loadk        r31   k89 ; k89 = 71
.line	759	loadk        r32  k105 ; k105 = 105
.line	759	loadk        r33  k106 ; k106 = 106
.line	759	loadk        r34   k18 ; k18 = 191
.line	759	loadk        r35  k107 ; k107 = 247
.line	759	loadk        r36  k108 ; k108 = 140
.line	759	loadk        r37   k58 ; k58 = 190
.line	759	loadk        r38   k19 ; k19 = 198
.line	759	loadk        r39   k13 ; k13 = 126
.line	759	loadk        r40  k109 ; k109 = 250
.line	759	loadk        r41  k110 ; k110 = 78
.line	759	loadk        r42  k111 ; k111 = 48
.line	759	loadk        r43   k79 ; k79 = 81
.line	759	loadk        r44  k112 ; k112 = 156
.line	759	loadk        r45  k113 ; k113 = 85
.line	759	loadk        r46  k114 ; k114 = 145
.line	759	loadk        r47  k115 ; k115 = 24
.line	759	loadk        r48  k116 ; k116 = 72
.line	759	call          r8    41     2
.line	759	getupval      r9    u1
.line	759	loadk        r10   k44 ; k44 = 189
.line	759	loadk        r11  k117 ; k117 = 17
.line	759	call          r9     3     0
.line	759	setlist       r6     0     1
.line	759	call          r5     2     2
.label	l267
.line	759	call          r4     2     1
.line	759	jmp            0  l272
.label	l269
.line	759	self          r4    r0  k118 ; k118 = "ChangeMLAIVoiceState"
.line	759	loadbool      r6     0     0
.line	759	call          r4     3     1
.label	l272
.line	759	return        r0     1
.line	759	move          r0    r0
.line	759	move          r0    r0
.line	759	return        r0     1

.function	main/f43

.source	null
.linedefined	779
.lastlinedefined	788
.numparams	4
.is_vararg	0
.maxstacksize	53

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"ASRSceneID"
.constant	k1	"tostring"
.constant	k2	"json"
.constant	k3	"encode"
.constant	k4	"require"
.constant	k5	187
.constant	k6	19
.constant	k7	49
.constant	k8	186
.constant	k9	190
.constant	k10	229
.constant	k11	57
.constant	k12	107
.constant	k13	95
.constant	k14	246
.constant	k15	166
.constant	k16	217
.constant	k17	167
.constant	k18	220
.constant	k19	121
.constant	k20	163
.constant	k21	75
.constant	k22	97
.constant	k23	68
.constant	k24	128
.constant	k25	66
.constant	k26	195
.constant	k27	30
.constant	k28	119
.constant	k29	84
.constant	k30	242
.constant	k31	130
.constant	k32	169
.constant	k33	206
.constant	k34	111
.constant	k35	168
.constant	k36	83
.constant	k37	113
.constant	k38	90
.constant	k39	158
.constant	k40	67
.constant	k41	212
.constant	k42	65
.constant	k43	12
.constant	k44	"ErrorCode"
.constant	k45	"AntsVoiceInterface"
.constant	k46	"EnableRSTSSubtitle"
.constant	k47	"LangID"
.constant	k48	"print"
.constant	k49	"bWriteLog"
.constant	k50	"string"
.constant	k51	"format"
.constant	k52	"table"
.constant	k53	"concat"
.constant	k54	149
.constant	k55	51
.constant	k56	25
.constant	k57	150
.constant	k58	134
.constant	k59	254
.constant	k60	126
.constant	k61	123
.constant	k62	86
.constant	k63	197
.constant	k64	162
.constant	k65	191
.constant	k66	198
.constant	k67	108
.constant	k68	175
.constant	k69	18
.constant	k70	16
.constant	k71	101
.constant	k72	207
.constant	k73	6
.constant	k74	74
.constant	k75	79
.constant	k76	133
.constant	k77	180
.constant	k78	143
.constant	k79	240
.constant	k80	93
.constant	k81	43
.constant	k82	81
.constant	k83	139
.constant	k84	92
.constant	k85	91
.constant	k86	24
.constant	k87	44
.constant	k88	164
.constant	k89	244
.constant	k90	45
.constant	k91	61
.constant	k92	64
.constant	k93	231
.constant	k94	178
.constant	k95	185
.constant	k96	193
.constant	k97	184
.constant	k98	32
.constant	k99	76
.constant	k100	138
.constant	k101	26
.constant	k102	132
.constant	k103	20
.constant	k104	4
.constant	k105	3
.constant	k106	214
.constant	k107	147
.constant	k108	194
.constant	k109	71
.constant	k110	94
.constant	k111	48
.constant	k112	2
.constant	k113	218

.line	779	newtable      r4     0     1
.line	779	gettabup      r5    u0    k1 ; k1 = "tostring"
.line	779	move          r6    r2
.line	779	call          r5     2     2
.line	779	settable      r4    k0    r5 ; k0 = "ASRSceneID"
.line	779	gettabup      r5    u0    k2 ; k2 = "json"
.line	779	gettable      r5    r5    k3 ; k3 = "encode"
.line	779	move          r6    r4
.line	779	call          r5     2     2
.line	779	gettabup      r6    u0    k4 ; k4 = "require"
.line	779	getupval      r7    u1
.line	779	loadk         r8    k5 ; k5 = 187
.line	779	loadk         r9    k6 ; k6 = 19
.line	779	loadk        r10    k7 ; k7 = 49
.line	779	loadk        r11    k8 ; k8 = 186
.line	779	loadk        r12    k9 ; k9 = 190
.line	779	loadk        r13   k10 ; k10 = 229
.line	779	loadk        r14   k11 ; k11 = 57
.line	779	loadk        r15   k12 ; k12 = 107
.line	779	loadk        r16   k13 ; k13 = 95
.line	779	loadk        r17   k14 ; k14 = 246
.line	779	loadk        r18   k15 ; k15 = 166
.line	779	loadk        r19   k16 ; k16 = 217
.line	779	loadk        r20   k17 ; k17 = 167
.line	779	loadk        r21   k18 ; k18 = 220
.line	779	loadk        r22   k19 ; k19 = 121
.line	779	loadk        r23   k20 ; k20 = 163
.line	779	loadk        r24   k21 ; k21 = 75
.line	779	loadk        r25   k22 ; k22 = 97
.line	779	loadk        r26   k23 ; k23 = 68
.line	779	loadk        r27   k24 ; k24 = 128
.line	779	loadk        r28   k25 ; k25 = 66
.line	779	loadk        r29   k26 ; k26 = 195
.line	779	loadk        r30   k27 ; k27 = 30
.line	779	loadk        r31   k28 ; k28 = 119
.line	779	loadk        r32   k29 ; k29 = 84
.line	779	loadk        r33   k30 ; k30 = 242
.line	779	loadk        r34   k20 ; k20 = 163
.line	779	loadk        r35   k31 ; k31 = 130
.line	779	loadk        r36   k32 ; k32 = 169
.line	779	loadk        r37   k33 ; k33 = 206
.line	779	loadk        r38   k34 ; k34 = 111
.line	779	loadk        r39   k35 ; k35 = 168
.line	779	loadk        r40   k36 ; k36 = 83
.line	779	loadk        r41   k37 ; k37 = 113
.line	779	loadk        r42   k38 ; k38 = 90
.line	779	loadk        r43   k39 ; k39 = 158
.line	779	loadk        r44   k40 ; k40 = 67
.line	779	loadk        r45   k41 ; k41 = 212
.line	779	loadk        r46   k42 ; k42 = 65
.line	779	loadk        r47   k43 ; k43 = 12
.line	779	call          r7    41     2
.line	779	call          r6     2     2
.line	779	gettable      r7    r6    k3 ; k3 = "encode"
.line	779	move          r8    r5
.line	779	call          r7     2     2
.line	779	gettable      r8    r0   k45 ; k45 = "AntsVoiceInterface"
.line	779	test          r8     0
.line	779	jmp            0   l66
.line	779	gettable      r8    r0   k45 ; k45 = "AntsVoiceInterface"
.line	779	self          r8    r8   k46 ; k46 = "EnableRSTSSubtitle"
.line	779	move         r10    r1
.line	779	gettable     r11    r0   k47 ; k47 = "LangID"
.line	779	move         r12    r7
.line	779	call          r8     5     2
.label	l66
.line	779	settable      r0   k44    r8 ; k44 = "ErrorCode"
.line	779	gettabup      r8    u0   k48 ; k48 = "print"
.line	779	gettabup      r9    u0   k49 ; k49 = "bWriteLog"
.line	779	test          r9     0
.line	779	jmp            0  l167
.line	779	gettabup      r9    u0   k50 ; k50 = "string"
.line	779	gettable      r9    r9   k51 ; k51 = "format"
.line	779	gettabup     r10    u0   k52 ; k52 = "table"
.line	779	gettable     r10   r10   k53 ; k53 = "concat"
.line	779	newtable     r11     1     0
.line	779	getupval     r12    u1
.line	779	loadk        r13   k54 ; k54 = 149
.line	779	loadk        r14   k55 ; k55 = 51
.line	779	loadk        r15   k56 ; k56 = 25
.line	779	loadk        r16   k57 ; k57 = 150
.line	779	loadk        r17   k58 ; k58 = 134
.line	779	loadk        r18   k59 ; k59 = 254
.line	779	loadk        r19   k60 ; k60 = 126
.line	779	loadk        r20   k61 ; k61 = 123
.line	779	loadk        r21   k62 ; k62 = 86
.line	779	loadk        r22   k63 ; k63 = 197
.line	779	loadk        r23   k64 ; k64 = 162
.line	779	loadk        r24   k57 ; k57 = 150
.line	779	loadk        r25   k65 ; k65 = 191
.line	779	loadk        r26   k66 ; k66 = 198
.line	779	loadk        r27   k67 ; k67 = 108
.line	779	loadk        r28   k68 ; k68 = 175
.line	779	loadk        r29   k69 ; k69 = 18
.line	779	loadk        r30   k70 ; k70 = 16
.line	779	loadk        r31   k67 ; k67 = 108
.line	779	loadk        r32   k24 ; k24 = 128
.line	779	loadk        r33   k71 ; k71 = 101
.line	779	loadk        r34   k72 ; k72 = 207
.line	779	loadk        r35   k73 ; k73 = 6
.line	779	loadk        r36   k74 ; k74 = 74
.line	779	loadk        r37   k75 ; k75 = 79
.line	779	loadk        r38   k14 ; k14 = 246
.line	779	loadk        r39   k76 ; k76 = 133
.line	779	loadk        r40   k77 ; k77 = 180
.line	779	loadk        r41   k78 ; k78 = 143
.line	779	loadk        r42   k79 ; k79 = 240
.line	779	loadk        r43   k80 ; k80 = 93
.line	779	loadk        r44   k68 ; k68 = 175
.line	779	loadk        r45   k38 ; k38 = 90
.line	779	loadk        r46   k81 ; k81 = 43
.line	779	loadk        r47   k82 ; k82 = 81
.line	779	loadk        r48   k83 ; k83 = 139
.line	779	loadk        r49   k84 ; k84 = 92
.line	779	loadk        r50   k41 ; k41 = 212
.line	779	loadk        r51   k85 ; k85 = 91
.line	779	loadk        r52   k86 ; k86 = 24
.line	779	call         r12    41     2
.line	779	getupval     r13    u1
.line	779	loadk        r14    k8 ; k8 = 186
.line	779	loadk        r15   k87 ; k87 = 44
.line	779	loadk        r16   k87 ; k87 = 44
.line	779	loadk        r17    k9 ; k9 = 190
.line	779	loadk        r18   k88 ; k88 = 164
.line	779	loadk        r19   k89 ; k89 = 244
.line	779	loadk        r20   k90 ; k90 = 45
.line	779	loadk        r21   k91 ; k91 = 61
.line	779	loadk        r22   k92 ; k92 = 64
.line	779	loadk        r23   k68 ; k68 = 175
.line	779	loadk        r24   k93 ; k93 = 231
.line	779	loadk        r25   k94 ; k94 = 178
.line	779	loadk        r26   k95 ; k95 = 185
.line	779	loadk        r27   k96 ; k96 = 193
.line	779	loadk        r28   k37 ; k37 = 113
.line	779	loadk        r29   k97 ; k97 = 184
.line	779	loadk        r30   k12 ; k12 = 107
.line	779	loadk        r31   k98 ; k98 = 32
.line	779	loadk        r32   k99 ; k99 = 76
.line	779	loadk        r33  k100 ; k100 = 138
.line	779	loadk        r34  k101 ; k101 = 26
.line	779	loadk        r35  k102 ; k102 = 132
.line	779	loadk        r36  k103 ; k103 = 20
.line	779	loadk        r37  k104 ; k104 = 4
.line	779	loadk        r38  k105 ; k105 = 3
.line	779	loadk        r39  k106 ; k106 = 214
.line	779	loadk        r40   k68 ; k68 = 175
.line	779	loadk        r41  k107 ; k107 = 147
.line	779	loadk        r42   k32 ; k32 = 169
.line	779	loadk        r43  k108 ; k108 = 194
.line	779	loadk        r44  k109 ; k109 = 71
.line	779	loadk        r45   k77 ; k77 = 180
.line	779	loadk        r46  k110 ; k110 = 94
.line	779	loadk        r47  k111 ; k111 = 48
.line	779	loadk        r48  k112 ; k112 = 2
.line	779	loadk        r49  k113 ; k113 = 218
.line	779	loadk        r50   k40 ; k40 = 67
.line	779	call         r13    38     0
.line	779	setlist      r11     0     1
.line	779	call         r10     2     2
.line	779	gettabup     r11    u0    k1 ; k1 = "tostring"
.line	779	move         r12    r1
.line	779	call         r11     2     2
.line	779	gettabup     r12    u0    k1 ; k1 = "tostring"
.line	779	gettable     r13    r0   k44 ; k44 = "ErrorCode"
.line	779	call         r12     2     2
.line	779	move         r13    r5
.line	779	call          r9     5     2
.label	l167
.line	779	call          r8     2     1
.line	779	return        r0     1
.line	779	move          r0    r0
.line	779	return        r0     1

.function	main/f44

.source	null
.linedefined	790
.lastlinedefined	811
.numparams	3
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	6	true
.upvalue	"U2"	1	true

.constant	k0	"Client"
.constant	k1	nil
.constant	k2	0
.constant	k3	"SendMLAIVoiceDebugInfo"
.constant	k4	"ASRStateChange"
.constant	k5	"tostring"
.constant	k6	245
.constant	k7	"EnabledRSTSSceneID"
.constant	k8	"print"
.constant	k9	"bWriteLog"
.constant	k10	"string"
.constant	k11	"format"
.constant	k12	"table"
.constant	k13	"concat"
.constant	k14	149
.constant	k15	51
.constant	k16	25
.constant	k17	150
.constant	k18	134
.constant	k19	254
.constant	k20	126
.constant	k21	123
.constant	k22	86
.constant	k23	197
.constant	k24	162
.constant	k25	191
.constant	k26	198
.constant	k27	108
.constant	k28	175
.constant	k29	18
.constant	k30	28
.constant	k31	77
.constant	k32	155
.constant	k33	114
.constant	k34	242
.constant	k35	112
.constant	k36	230
.constant	k37	181
.constant	k38	147
.constant	k39	178
.constant	k40	215
.constant	k41	98
.constant	k42	107
.constant	k43	43
.constant	k44	89
.constant	k45	139
.constant	k46	85
.constant	k47	157
.constant	k48	87
.constant	k49	75
.constant	k50	187
.constant	k51	26
.constant	k52	54
.constant	k53	186
.constant	k54	240
.constant	k55	180
.constant	k56	100
.constant	k57	56
.constant	k58	82
.constant	k59	239
.constant	k60	146
.constant	k61	170
.constant	k62	103
.constant	k63	234
.constant	k64	33
.constant	k65	73
.constant	k66	141
.constant	k67	76
.constant	k68	196
.constant	k69	3
.constant	k70	4
.constant	k71	224
.constant	k72	188
.constant	k73	142
.constant	k74	171
.constant	k75	143
.constant	k76	46
.constant	k77	159
.constant	k78	64
.constant	k79	74
.constant	k80	158
.constant	k81	10
.constant	k82	148
.constant	k83	226
.constant	k84	96
.constant	k85	113
.constant	k86	71
.constant	k87	238
.constant	k88	192
.constant	k89	62
.constant	k90	231
.constant	k91	22
.constant	k92	111
.constant	k93	13
.constant	k94	156
.constant	k95	12
.constant	k96	129
.constant	k97	65
.constant	k98	80
.constant	k99	190
.constant	k100	131
.constant	k101	97
.constant	k102	182
.constant	k103	92
.constant	k104	127
.constant	k105	223
.constant	k106	24
.constant	k107	42
.constant	k108	172
.constant	k109	164
.constant	k110	189
.constant	k111	55
.constant	k112	93
.constant	k113	247
.constant	k114	241
.constant	k115	109
.constant	k116	61
.constant	k117	177
.constant	k118	90
.constant	k119	235
.constant	k120	106
.constant	k121	91
.constant	k122	207
.constant	k123	68
.constant	k124	200
.constant	k125	20
.constant	k126	255
.constant	k127	199
.constant	k128	250
.constant	k129	21
.constant	k130	29
.constant	k131	140
.constant	k132	"_DoEnableRSTSSubtitle"

.line	790	gettabup      r3    u0    k0 ; k0 = "Client"
.line	790	test          r3     0
.line	790	jmp            0  l342
.line	790	loadbool      r3     0     0
.line	790	eq             1    r1    k1 ; k1 = nil
.line	790	jmp            0   l10
.line	790	lt             0    k2    r1 ; k2 = 0
.line	790	jmp            0   l10
.line	790	loadbool      r3     1     0
.label	l10
.line	790	self          r4    r0    k3 ; k3 = "SendMLAIVoiceDebugIn" (truncated)
.line	790	gettabup      r6    u1    k4 ; k4 = "ASRStateChange"
.line	790	gettabup      r7    u0    k5 ; k5 = "tostring"
.line	790	move          r8    r1
.line	790	call          r7     2     2
.line	790	getupval      r8    u2
.line	790	loadk         r9    k6 ; k6 = 245
.line	790	call          r8     2     2
.line	790	move          r9    r2
.line	790	concat        r7    r7    r9
.line	790	call          r4     4     1
.line	790	gettable      r4    r0    k7 ; k7 = "EnabledRSTSSceneID"
.line	790	test          r4     1
.line	790	jmp            0   l25
.line	790	loadk         r4    k2 ; k2 = 0
.label	l25
.line	790	test          r3     0
.line	790	jmp            0  l132
.line	790	eq             0    r4    r1
.line	790	jmp            0  l132
.line	790	gettabup      r5    u0    k8 ; k8 = "print"
.line	790	gettabup      r6    u0    k9 ; k9 = "bWriteLog"
.line	790	test          r6     0
.line	790	jmp            0  l130
.line	790	gettabup      r6    u0   k10 ; k10 = "string"
.line	790	gettable      r6    r6   k11 ; k11 = "format"
.line	790	gettabup      r7    u0   k12 ; k12 = "table"
.line	790	gettable      r7    r7   k13 ; k13 = "concat"
.line	790	newtable      r8     1     0
.line	790	getupval      r9    u2
.line	790	loadk        r10   k14 ; k14 = 149
.line	790	loadk        r11   k15 ; k15 = 51
.line	790	loadk        r12   k16 ; k16 = 25
.line	790	loadk        r13   k17 ; k17 = 150
.line	790	loadk        r14   k18 ; k18 = 134
.line	790	loadk        r15   k19 ; k19 = 254
.line	790	loadk        r16   k20 ; k20 = 126
.line	790	loadk        r17   k21 ; k21 = 123
.line	790	loadk        r18   k22 ; k22 = 86
.line	790	loadk        r19   k23 ; k23 = 197
.line	790	loadk        r20   k24 ; k24 = 162
.line	790	loadk        r21   k17 ; k17 = 150
.line	790	loadk        r22   k25 ; k25 = 191
.line	790	loadk        r23   k26 ; k26 = 198
.line	790	loadk        r24   k27 ; k27 = 108
.line	790	loadk        r25   k28 ; k28 = 175
.line	790	loadk        r26   k29 ; k29 = 18
.line	790	loadk        r27   k30 ; k30 = 28
.line	790	loadk        r28   k31 ; k31 = 77
.line	790	loadk        r29   k32 ; k32 = 155
.line	790	loadk        r30   k33 ; k33 = 114
.line	790	loadk        r31   k34 ; k34 = 242
.line	790	loadk        r32   k15 ; k15 = 51
.line	790	loadk        r33   k21 ; k21 = 123
.line	790	loadk        r34   k35 ; k35 = 112
.line	790	loadk        r35   k36 ; k36 = 230
.line	790	loadk        r36   k37 ; k37 = 181
.line	790	loadk        r37   k38 ; k38 = 147
.line	790	loadk        r38   k39 ; k39 = 178
.line	790	loadk        r39   k40 ; k40 = 215
.line	790	loadk        r40   k41 ; k41 = 98
.line	790	loadk        r41   k25 ; k25 = 191
.line	790	loadk        r42   k42 ; k42 = 107
.line	790	loadk        r43   k43 ; k43 = 43
.line	790	loadk        r44   k44 ; k44 = 89
.line	790	loadk        r45   k45 ; k45 = 139
.line	790	loadk        r46   k46 ; k46 = 85
.line	790	loadk        r47   k47 ; k47 = 157
.line	790	loadk        r48   k48 ; k48 = 87
.line	790	loadk        r49   k49 ; k49 = 75
.line	790	call          r9    41     2
.line	790	getupval     r10    u2
.line	790	loadk        r11   k50 ; k50 = 187
.line	790	loadk        r12   k51 ; k51 = 26
.line	790	loadk        r13   k52 ; k52 = 54
.line	790	loadk        r14   k53 ; k53 = 186
.line	790	loadk        r15   k54 ; k54 = 240
.line	790	loadk        r16   k55 ; k55 = 180
.line	790	loadk        r17   k56 ; k56 = 100
.line	790	loadk        r18   k57 ; k57 = 56
.line	790	loadk        r19   k58 ; k58 = 82
.line	790	loadk        r20   k59 ; k59 = 239
.line	790	loadk        r21   k37 ; k37 = 181
.line	790	loadk        r22   k60 ; k60 = 146
.line	790	loadk        r23   k61 ; k61 = 170
.line	790	loadk        r24   k40 ; k40 = 215
.line	790	loadk        r25   k62 ; k62 = 103
.line	790	loadk        r26   k63 ; k63 = 234
.line	790	loadk        r27   k31 ; k31 = 77
.line	790	loadk        r28   k64 ; k64 = 33
.line	790	loadk        r29   k65 ; k65 = 73
.line	790	loadk        r30   k66 ; k66 = 141
.line	790	loadk        r31   k67 ; k67 = 76
.line	790	loadk        r32   k68 ; k68 = 196
.line	790	loadk        r33   k69 ; k69 = 3
.line	790	loadk        r34   k70 ; k70 = 4
.line	790	loadk        r35   k69 ; k69 = 3
.line	790	loadk        r36   k71 ; k71 = 224
.line	790	loadk        r37   k72 ; k72 = 188
.line	790	loadk        r38   k73 ; k73 = 142
.line	790	loadk        r39   k74 ; k74 = 171
.line	790	loadk        r40   k75 ; k75 = 143
.line	790	loadk        r41   k76 ; k76 = 46
.line	790	loadk        r42   k77 ; k77 = 159
.line	790	loadk        r43   k78 ; k78 = 64
.line	790	loadk        r44   k43 ; k43 = 43
.line	790	loadk        r45   k79 ; k79 = 74
.line	790	loadk        r46   k80 ; k80 = 158
.line	790	loadk        r47   k81 ; k81 = 10
.line	790	loadk        r48   k82 ; k82 = 148
.line	790	loadk        r49   k70 ; k70 = 4
.line	790	call         r10    40     0
.line	790	setlist       r8     0     1
.line	790	call          r7     2     2
.line	790	gettabup      r8    u0    k5 ; k5 = "tostring"
.line	790	move          r9    r1
.line	790	call          r8     2     2
.line	790	gettabup      r9    u0    k5 ; k5 = "tostring"
.line	790	move         r10    r2
.line	790	call          r9     2     0
.line	790	call          r6     0     2
.label	l130
.line	790	call          r5     2     1
.line	790	return        r0     1
.label	l132
.line	790	lt             0    k2    r4 ; k2 = 0
.line	790	jmp            0  l320
.line	790	testset       r5    r1     1
.line	790	jmp            0  l137
.line	790	loadk         r5    k2 ; k2 = 0
.label	l137
.line	790	eq             1    r4    r5
.line	790	jmp            0  l320
.line	790	gettabup      r5    u0    k8 ; k8 = "print"
.line	790	gettabup      r6    u0    k9 ; k9 = "bWriteLog"
.line	790	test          r6     0
.line	790	jmp            0  l261
.line	790	gettabup      r6    u0   k10 ; k10 = "string"
.line	790	gettable      r6    r6   k11 ; k11 = "format"
.line	790	gettabup      r7    u0   k12 ; k12 = "table"
.line	790	gettable      r7    r7   k13 ; k13 = "concat"
.line	790	newtable      r8     2     0
.line	790	getupval      r9    u2
.line	790	loadk        r10   k14 ; k14 = 149
.line	790	loadk        r11   k15 ; k15 = 51
.line	790	loadk        r12   k16 ; k16 = 25
.line	790	loadk        r13   k17 ; k17 = 150
.line	790	loadk        r14   k18 ; k18 = 134
.line	790	loadk        r15   k19 ; k19 = 254
.line	790	loadk        r16   k20 ; k20 = 126
.line	790	loadk        r17   k21 ; k21 = 123
.line	790	loadk        r18   k22 ; k22 = 86
.line	790	loadk        r19   k23 ; k23 = 197
.line	790	loadk        r20   k24 ; k24 = 162
.line	790	loadk        r21   k17 ; k17 = 150
.line	790	loadk        r22   k25 ; k25 = 191
.line	790	loadk        r23   k26 ; k26 = 198
.line	790	loadk        r24   k27 ; k27 = 108
.line	790	loadk        r25   k28 ; k28 = 175
.line	790	loadk        r26   k29 ; k29 = 18
.line	790	loadk        r27   k30 ; k30 = 28
.line	790	loadk        r28   k31 ; k31 = 77
.line	790	loadk        r29   k32 ; k32 = 155
.line	790	loadk        r30   k33 ; k33 = 114
.line	790	loadk        r31   k34 ; k34 = 242
.line	790	loadk        r32   k15 ; k15 = 51
.line	790	loadk        r33   k21 ; k21 = 123
.line	790	loadk        r34   k35 ; k35 = 112
.line	790	loadk        r35   k36 ; k36 = 230
.line	790	loadk        r36   k37 ; k37 = 181
.line	790	loadk        r37   k38 ; k38 = 147
.line	790	loadk        r38   k39 ; k39 = 178
.line	790	loadk        r39   k40 ; k40 = 215
.line	790	loadk        r40   k41 ; k41 = 98
.line	790	loadk        r41   k25 ; k25 = 191
.line	790	loadk        r42   k42 ; k42 = 107
.line	790	loadk        r43   k43 ; k43 = 43
.line	790	loadk        r44   k44 ; k44 = 89
.line	790	loadk        r45   k45 ; k45 = 139
.line	790	loadk        r46   k46 ; k46 = 85
.line	790	loadk        r47   k47 ; k47 = 157
.line	790	loadk        r48   k48 ; k48 = 87
.line	790	loadk        r49   k49 ; k49 = 75
.line	790	call          r9    41     2
.line	790	getupval     r10    u2
.line	790	loadk        r11   k50 ; k50 = 187
.line	790	loadk        r12   k51 ; k51 = 26
.line	790	loadk        r13   k52 ; k52 = 54
.line	790	loadk        r14   k53 ; k53 = 186
.line	790	loadk        r15   k54 ; k54 = 240
.line	790	loadk        r16   k83 ; k83 = 226
.line	790	loadk        r17   k84 ; k84 = 96
.line	790	loadk        r18   k85 ; k85 = 113
.line	790	loadk        r19   k86 ; k86 = 71
.line	790	loadk        r20   k71 ; k71 = 224
.line	790	loadk        r21   k28 ; k28 = 175
.line	790	loadk        r22   k40 ; k40 = 215
.line	790	loadk        r23   k87 ; k87 = 238
.line	790	loadk        r24   k88 ; k88 = 192
.line	790	loadk        r25   k89 ; k89 = 62
.line	790	loadk        r26   k90 ; k90 = 231
.line	790	loadk        r27   k91 ; k91 = 22
.line	790	loadk        r28   k92 ; k92 = 111
.line	790	loadk        r29   k93 ; k93 = 13
.line	790	loadk        r30   k94 ; k94 = 156
.line	790	loadk        r31   k95 ; k95 = 12
.line	790	loadk        r32   k96 ; k96 = 129
.line	790	loadk        r33   k69 ; k69 = 3
.line	790	loadk        r34   k97 ; k97 = 65
.line	790	loadk        r35   k98 ; k98 = 80
.line	790	loadk        r36   k34 ; k34 = 242
.line	790	loadk        r37   k37 ; k37 = 181
.line	790	loadk        r38   k45 ; k45 = 139
.line	790	loadk        r39   k99 ; k99 = 190
.line	790	loadk        r40  k100 ; k100 = 131
.line	790	loadk        r41  k101 ; k101 = 97
.line	790	loadk        r42  k102 ; k102 = 182
.line	790	loadk        r43  k103 ; k103 = 92
.line	790	loadk        r44  k104 ; k104 = 127
.line	790	loadk        r45   k49 ; k49 = 75
.line	790	loadk        r46   k94 ; k94 = 156
.line	790	loadk        r47   k46 ; k46 = 85
.line	790	loadk        r48  k105 ; k105 = 223
.line	790	loadk        r49   k29 ; k29 = 18
.line	790	loadk        r50  k106 ; k106 = 24
.line	790	call         r10    41     2
.line	790	getupval     r11    u2
.line	790	loadk        r12   k99 ; k99 = 190
.line	790	loadk        r13   k91 ; k91 = 22
.line	790	loadk        r14  k107 ; k107 = 42
.line	790	loadk        r15  k108 ; k108 = 172
.line	790	loadk        r16  k109 ; k109 = 164
.line	790	loadk        r17  k110 ; k110 = 189
.line	790	loadk        r18  k111 ; k111 = 55
.line	790	loadk        r19  k112 ; k112 = 93
.line	790	loadk        r20   k49 ; k49 = 75
.line	790	loadk        r21  k113 ; k113 = 247
.line	790	loadk        r22   k37 ; k37 = 181
.line	790	loadk        r23   k17 ; k17 = 150
.line	790	loadk        r24  k114 ; k114 = 241
.line	790	loadk        r25   k17 ; k17 = 150
.line	790	loadk        r26  k115 ; k115 = 109
.line	790	call         r11    16     0
.line	790	setlist       r8     0     1
.line	790	call          r7     2     2
.line	790	gettabup      r8    u0    k5 ; k5 = "tostring"
.line	790	move          r9    r4
.line	790	call          r8     2     2
.line	790	gettabup      r9    u0    k5 ; k5 = "tostring"
.line	790	move         r10    r1
.line	790	call          r9     2     2
.line	790	gettabup     r10    u0    k5 ; k5 = "tostring"
.line	790	move         r11    r2
.line	790	call         r10     2     0
.line	790	call          r6     0     2
.label	l261
.line	790	call          r5     2     1
.line	790	self          r5    r0    k3 ; k3 = "SendMLAIVoiceDebugIn" (truncated)
.line	790	gettabup      r7    u1    k4 ; k4 = "ASRStateChange"
.line	790	gettabup      r8    u0   k10 ; k10 = "string"
.line	790	gettable      r8    r8   k11 ; k11 = "format"
.line	790	getupval      r9    u2
.line	790	loadk        r10   k74 ; k74 = 171
.line	790	loadk        r11   k30 ; k30 = 28
.line	790	loadk        r12  k116 ; k116 = 61
.line	790	loadk        r13  k117 ; k117 = 177
.line	790	loadk        r14   k37 ; k37 = 181
.line	790	loadk        r15  k117 ; k117 = 177
.line	790	loadk        r16   k56 ; k56 = 100
.line	790	loadk        r17   k92 ; k92 = 111
.line	790	loadk        r18  k118 ; k118 = 90
.line	790	loadk        r19  k113 ; k113 = 247
.line	790	loadk        r20  k109 ; k109 = 164
.line	790	loadk        r21   k77 ; k77 = 159
.line	790	loadk        r22  k119 ; k119 = 235
.line	790	loadk        r23   k17 ; k17 = 150
.line	790	loadk        r24  k115 ; k115 = 109
.line	790	loadk        r25   k90 ; k90 = 231
.line	790	loadk        r26   k91 ; k91 = 22
.line	790	loadk        r27  k120 ; k120 = 106
.line	790	loadk        r28  k121 ; k121 = 91
.line	790	loadk        r29  k122 ; k122 = 207
.line	790	loadk        r30  k123 ; k123 = 68
.line	790	loadk        r31  k124 ; k124 = 200
.line	790	loadk        r32  k125 ; k125 = 20
.line	790	loadk        r33   k65 ; k65 = 73
.line	790	loadk        r34   k97 ; k97 = 65
.line	790	loadk        r35  k126 ; k126 = 255
.line	790	loadk        r36   k39 ; k39 = 178
.line	790	loadk        r37  k127 ; k127 = 199
.line	790	loadk        r38   k55 ; k55 = 180
.line	790	loadk        r39  k122 ; k122 = 207
.line	790	loadk        r40  k120 ; k120 = 106
.line	790	loadk        r41  k128 ; k128 = 250
.line	790	loadk        r42  k129 ; k129 = 21
.line	790	loadk        r43  k104 ; k104 = 127
.line	790	loadk        r44  k130 ; k130 = 29
.line	790	loadk        r45  k131 ; k131 = 140
.line	790	call          r9    37     2
.line	790	gettabup     r10    u0    k5 ; k5 = "tostring"
.line	790	move         r11    r4
.line	790	call         r10     2     2
.line	790	gettabup     r11    u0    k5 ; k5 = "tostring"
.line	790	move         r12    r1
.line	790	call         r11     2     2
.line	790	gettabup     r12    u0    k5 ; k5 = "tostring"
.line	790	move         r13    r2
.line	790	call         r12     2     0
.line	790	call          r8     0     0
.line	790	call          r5     0     1
.line	790	self          r5    r0  k132 ; k132 = "_DoEnableRSTSSubtitl" (truncated)
.line	790	loadbool      r7     0     0
.line	790	move          r8    r4
.line	790	move          r9    r2
.line	790	call          r5     5     1
.label	l320
.line	790	self          r5    r0  k132 ; k132 = "_DoEnableRSTSSubtitl" (truncated)
.line	790	move          r7    r3
.line	790	move          r8    r1
.line	790	move          r9    r2
.line	790	call          r5     5     1
.line	790	test          r3     0
.line	790	jmp            0  l329
.line	790	testset       r5    r1     1
.line	790	jmp            0  l330
.label	l329
.line	790	loadk         r5    k2 ; k2 = 0
.label	l330
.line	790	settable      r0    k7    r5 ; k7 = "EnabledRSTSSceneID"
.line	790	self          r5    r0    k3 ; k3 = "SendMLAIVoiceDebugIn" (truncated)
.line	790	gettabup      r7    u1    k4 ; k4 = "ASRStateChange"
.line	790	gettabup      r8    u0    k5 ; k5 = "tostring"
.line	790	move          r9    r1
.line	790	call          r8     2     2
.line	790	getupval      r9    u2
.line	790	loadk        r10    k6 ; k6 = 245
.line	790	call          r9     2     2
.line	790	move         r10    r2
.line	790	concat        r8    r8   r10
.line	790	call          r5     4     1
.label	l342
.line	790	return        r0     1
.line	790	move          r0    r0
.line	790	move          r0    r0
.line	790	return        r0     1

.function	main/f45

.source	null
.linedefined	813
.lastlinedefined	816
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	0
.constant	k23	70
.constant	k24	189
.constant	k25	115
.constant	k26	245
.constant	k27	52
.constant	k28	241
.constant	k29	163
.constant	k30	142
.constant	k31	207
.constant	k32	107
.constant	k33	155
.constant	k34	13
.constant	k35	139
.constant	k36	81
.constant	k37	195
.constant	k38	3
.constant	k39	185
.constant	k40	19
.constant	k41	177
.constant	k42	242
.constant	k43	124
.constant	k44	240
.constant	k45	164
.constant	k46	153
.constant	k47	224
.constant	k48	91
.constant	k49	38
.constant	k50	71
.constant	k51	129
.constant	k52	110
.constant	k53	192
.constant	k54	10
.constant	k55	77
.constant	k56	182
.constant	k57	"ASRRecord"
.constant	k58	"slua"
.constant	k59	"getMiliseconds"

.line	813	gettabup      r2    u0    k0 ; k0 = "print"
.line	813	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	813	test          r3     0
.line	813	jmp            0   l85
.line	813	gettabup      r3    u0    k2 ; k2 = "string"
.line	813	gettable      r3    r3    k3 ; k3 = "format"
.line	813	gettabup      r4    u0    k4 ; k4 = "table"
.line	813	gettable      r4    r4    k5 ; k5 = "concat"
.line	813	newtable      r5     1     0
.line	813	getupval      r6    u1
.line	813	loadk         r7    k6 ; k6 = 149
.line	813	loadk         r8    k7 ; k7 = 51
.line	813	loadk         r9    k8 ; k8 = 25
.line	813	loadk        r10    k9 ; k9 = 150
.line	813	loadk        r11   k10 ; k10 = 134
.line	813	loadk        r12   k11 ; k11 = 254
.line	813	loadk        r13   k12 ; k12 = 126
.line	813	loadk        r14   k13 ; k13 = 123
.line	813	loadk        r15   k14 ; k14 = 86
.line	813	loadk        r16   k15 ; k15 = 197
.line	813	loadk        r17   k16 ; k16 = 162
.line	813	loadk        r18    k9 ; k9 = 150
.line	813	loadk        r19   k17 ; k17 = 191
.line	813	loadk        r20   k18 ; k18 = 198
.line	813	loadk        r21   k19 ; k19 = 108
.line	813	loadk        r22   k20 ; k20 = 175
.line	813	loadk        r23   k21 ; k21 = 18
.line	813	loadk        r24   k22 ; k22 = 0
.line	813	loadk        r25   k23 ; k23 = 70
.line	813	loadk        r26   k24 ; k24 = 189
.line	813	loadk        r27   k25 ; k25 = 115
.line	813	loadk        r28   k26 ; k26 = 245
.line	813	loadk        r29   k27 ; k27 = 52
.line	813	loadk        r30   k13 ; k13 = 123
.line	813	loadk        r31   k14 ; k14 = 86
.line	813	loadk        r32   k28 ; k28 = 241
.line	813	loadk        r33   k29 ; k29 = 163
.line	813	loadk        r34   k30 ; k30 = 142
.line	813	loadk        r35   k20 ; k20 = 175
.line	813	loadk        r36   k31 ; k31 = 207
.line	813	loadk        r37   k32 ; k32 = 107
.line	813	loadk        r38   k33 ; k33 = 155
.line	813	loadk        r39   k32 ; k32 = 107
.line	813	loadk        r40   k34 ; k34 = 13
.line	813	loadk        r41   k32 ; k32 = 107
.line	813	loadk        r42   k35 ; k35 = 139
.line	813	loadk        r43   k36 ; k36 = 81
.line	813	loadk        r44   k37 ; k37 = 195
.line	813	loadk        r45   k38 ; k38 = 3
.line	813	loadk        r46   k13 ; k13 = 123
.line	813	call          r6    41     2
.line	813	getupval      r7    u1
.line	813	loadk         r8   k39 ; k39 = 185
.line	813	loadk         r9   k40 ; k40 = 19
.line	813	loadk        r10   k27 ; k27 = 52
.line	813	loadk        r11   k24 ; k24 = 189
.line	813	loadk        r12   k41 ; k41 = 177
.line	813	loadk        r13   k42 ; k42 = 242
.line	813	loadk        r14   k43 ; k43 = 124
.line	813	loadk        r15   k27 ; k27 = 52
.line	813	loadk        r16   k40 ; k40 = 19
.line	813	loadk        r17   k44 ; k44 = 240
.line	813	loadk        r18   k10 ; k10 = 134
.line	813	loadk        r19   k45 ; k45 = 164
.line	813	loadk        r20   k46 ; k46 = 153
.line	813	loadk        r21   k47 ; k47 = 224
.line	813	loadk        r22   k13 ; k13 = 123
.line	813	loadk        r23   k39 ; k39 = 185
.line	813	loadk        r24   k48 ; k48 = 91
.line	813	loadk        r25   k49 ; k49 = 38
.line	813	loadk        r26   k50 ; k50 = 71
.line	813	loadk        r27   k51 ; k51 = 129
.line	813	loadk        r28   k52 ; k52 = 110
.line	813	loadk        r29   k53 ; k53 = 192
.line	813	loadk        r30   k54 ; k54 = 10
.line	813	loadk        r31   k55 ; k55 = 77
.line	813	loadk        r32    k8 ; k8 = 25
.line	813	loadk        r33   k56 ; k56 = 182
.line	813	loadk        r34   k45 ; k45 = 164
.line	813	call          r7    28     0
.line	813	setlist       r5     0     1
.line	813	call          r4     2     2
.line	813	move          r5    r1
.line	813	call          r3     3     2
.label	l85
.line	813	call          r2     2     1
.line	813	gettable      r2    r0   k57 ; k57 = "ASRRecord"
.line	813	gettabup      r3    u0   k58 ; k58 = "slua"
.line	813	gettable      r3    r3   k59 ; k59 = "getMiliseconds"
.line	813	call          r3     1     2
.line	813	settable      r2    r1    r3
.line	813	return        r0     1
.line	813	move          r0    r0
.line	813	move          r0    r0
.line	813	move          r0    r0
.line	813	move          r0    r0
.line	813	return        r0     1

.function	main/f46

.source	null
.linedefined	818
.lastlinedefined	827
.numparams	3
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false

.constant	k0	"CacheSessionName"
.constant	k1	"CacheSessionNameClearTimer"
.constant	k2	nil
.constant	k3	"Game"
.constant	k4	"ClearTimer"
.constant	k5	"AddGameTimer"
.constant	k6	0.5

.line	818	settable      r0    k0    r2 ; k0 = "CacheSessionName"
.line	818	gettable      r3    r0    k1 ; k1 = "CacheSessionNameClea" (truncated)
.line	818	eq             1    r3    k2 ; k2 = nil
.line	818	jmp            0    l9
.line	818	gettabup      r3    u0    k3 ; k3 = "Game"
.line	818	self          r3    r3    k4 ; k4 = "ClearTimer"
.line	818	gettable      r5    r0    k1 ; k1 = "CacheSessionNameClea" (truncated)
.line	818	call          r3     3     1
.label	l9
.line	818	self          r3    r0    k5 ; k5 = "AddGameTimer"
.line	818	loadk         r5    k6 ; k6 = 0.5
.line	818	loadbool      r6     0     0
.line	818	closure       r7    f0
.line	818	call          r3     5     2
.line	818	settable      r0    k1    r3 ; k1 = "CacheSessionNameClea" (truncated)
.line	818	return        r0     1
.line	818	move          r0    r0
.line	818	return        r0     1

.function	main/f46/f0

.source	null
.linedefined	823
.lastlinedefined	826
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	true

.constant	k0	"CacheSessionName"
.constant	k1	nil
.constant	k2	"CacheSessionNameClearTimer"

.line	823	settabup      u0    k0    k1 ; k1 = nil
.line	823	settabup      u0    k2    k1 ; k1 = nil
.line	823	return        r0     1
.line	823	move          r0    r0
.line	823	move          r0    r0
.line	823	move          r0    r0
.line	823	return        r0     1

.function	main/f47

.source	null
.linedefined	829
.lastlinedefined	862
.numparams	7
.is_vararg	0
.maxstacksize	56

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	15	true
.upvalue	"U3"	11	true
.upvalue	"U4"	3	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	0
.constant	k23	70
.constant	k24	189
.constant	k25	115
.constant	k26	245
.constant	k27	52
.constant	k28	241
.constant	k29	163
.constant	k30	142
.constant	k31	207
.constant	k32	107
.constant	k33	153
.constant	k34	89
.constant	k35	84
.constant	k36	157
.constant	k37	81
.constant	k38	210
.constant	k39	28
.constant	k40	20
.constant	k41	248
.constant	k42	54
.constant	k43	156
.constant	k44	114
.constant	k45	19
.constant	k46	202
.constant	k47	169
.constant	k48	164
.constant	k49	185
.constant	k50	208
.constant	k51	82
.constant	k52	171
.constant	k53	40
.constant	k54	4
.constant	k55	105
.constant	k56	73
.constant	k57	244
.constant	k58	178
.constant	k59	147
.constant	k60	151
.constant	k61	194
.constant	k62	96
.constant	k63	127
.constant	k64	113
.constant	k65	145
.constant	k66	99
.constant	k67	195
.constant	k68	7
.constant	k69	44
.constant	k70	243
.constant	k71	240
.constant	k72	216
.constant	k73	121
.constant	k74	76
.constant	k75	160
.constant	k76	146
.constant	k77	231
.constant	k78	92
.constant	k79	8
.constant	k80	166
.constant	k81	78
.constant	k82	2
.constant	k83	75
.constant	k84	225
.constant	k85	179
.constant	k86	161
.constant	k87	224
.constant	k88	29
.constant	k89	223
.constant	k90	21
.constant	k91	91
.constant	k92	24
.constant	k93	253
.constant	k94	12
.constant	k95	116
.constant	k96	255
.constant	k97	226
.constant	k98	"GFrameCount"
.constant	k99	"LastMsgFrame"
.constant	k100	60
.constant	k101	45
.constant	k102	173
.constant	k103	117
.constant	k104	154
.constant	k105	174
.constant	k106	35
.constant	k107	247
.constant	k108	3
.constant	k109	236
.constant	k110	79
.constant	k111	101
.constant	k112	182
.constant	k113	138
.constant	k114	190
.constant	k115	131
.constant	k116	77
.constant	k117	74
.constant	k118	93
.constant	k119	68
.constant	k120	5
.constant	k121	181
.constant	k122	26
.constant	k123	98
.constant	k124	250
.constant	k125	"tostring"
.constant	k126	"bSpeechToTextState"
.constant	k127	false
.constant	k128	"GetPlayerController"
.constant	k129	"slua"
.constant	k130	"isValid"
.constant	k131	"bShowRSTSSubtitleText"
.constant	k132	"bSendingASRDebugMsg"
.constant	k133	true
.constant	k134	"pcall"
.constant	k135	"SendStringMsg"
.constant	k136	-1
.constant	k137	232
.constant	k138	61
.constant	k139	177
.constant	k140	180
.constant	k141	106
.constant	k142	90
.constant	k143	237
.constant	k144	186
.constant	k145	184
.constant	k146	212
.constant	k147	62
.constant	k148	172
.constant	k149	38
.constant	k150	155
.constant	k151	66
.constant	k152	"nRSTSSceneID"
.constant	k153	"Enum_ASRSceneID"
.constant	k154	"PublicOpinion"
.constant	k155	"SendDeliveryDataByVoice"
.constant	k156	1
.constant	k157	"bComplaint"
.constant	k158	"_NotifyDialogASRText"
.constant	k159	"ASRRecord"
.constant	k160	"getMiliseconds"
.constant	k161	"RPC_Server_SendRSTSSubtitleText"
.constant	k162	"GetCurrentServerTimeSec"
.constant	k163	16
.constant	k164	139
.constant	k165	227
.constant	k166	112
.constant	k167	125
.constant	k168	71
.constant	k169	215
.constant	k170	143
.constant	k171	119
.constant	k172	42
.constant	k173	69
.constant	k174	159

.line	829	gettabup      r7    u0    k0 ; k0 = "print"
.line	829	gettabup      r8    u0    k1 ; k1 = "bWriteLog"
.line	829	test          r8     0
.line	829	jmp            0  l152
.line	829	gettabup      r8    u0    k2 ; k2 = "string"
.line	829	gettable      r8    r8    k3 ; k3 = "format"
.line	829	gettabup      r9    u0    k4 ; k4 = "table"
.line	829	gettable      r9    r9    k5 ; k5 = "concat"
.line	829	newtable     r10     3     0
.line	829	getupval     r11    u1
.line	829	loadk        r12    k6 ; k6 = 149
.line	829	loadk        r13    k7 ; k7 = 51
.line	829	loadk        r14    k8 ; k8 = 25
.line	829	loadk        r15    k9 ; k9 = 150
.line	829	loadk        r16   k10 ; k10 = 134
.line	829	loadk        r17   k11 ; k11 = 254
.line	829	loadk        r18   k12 ; k12 = 126
.line	829	loadk        r19   k13 ; k13 = 123
.line	829	loadk        r20   k14 ; k14 = 86
.line	829	loadk        r21   k15 ; k15 = 197
.line	829	loadk        r22   k16 ; k16 = 162
.line	829	loadk        r23    k9 ; k9 = 150
.line	829	loadk        r24   k17 ; k17 = 191
.line	829	loadk        r25   k18 ; k18 = 198
.line	829	loadk        r26   k19 ; k19 = 108
.line	829	loadk        r27   k20 ; k20 = 175
.line	829	loadk        r28   k21 ; k21 = 18
.line	829	loadk        r29   k22 ; k22 = 0
.line	829	loadk        r30   k23 ; k23 = 70
.line	829	loadk        r31   k24 ; k24 = 189
.line	829	loadk        r32   k25 ; k25 = 115
.line	829	loadk        r33   k26 ; k26 = 245
.line	829	loadk        r34   k27 ; k27 = 52
.line	829	loadk        r35   k13 ; k13 = 123
.line	829	loadk        r36   k14 ; k14 = 86
.line	829	loadk        r37   k28 ; k28 = 241
.line	829	loadk        r38   k29 ; k29 = 163
.line	829	loadk        r39   k30 ; k30 = 142
.line	829	loadk        r40   k20 ; k20 = 175
.line	829	loadk        r41   k31 ; k31 = 207
.line	829	loadk        r42   k32 ; k32 = 107
.line	829	loadk        r43   k33 ; k33 = 153
.line	829	loadk        r44   k34 ; k34 = 89
.line	829	loadk        r45    k7 ; k7 = 51
.line	829	loadk        r46   k35 ; k35 = 84
.line	829	loadk        r47   k36 ; k36 = 157
.line	829	loadk        r48   k37 ; k37 = 81
.line	829	loadk        r49   k38 ; k38 = 210
.line	829	loadk        r50   k39 ; k39 = 28
.line	829	loadk        r51   k40 ; k40 = 20
.line	829	call         r11    41     2
.line	829	getupval     r12    u1
.line	829	loadk        r13   k41 ; k41 = 248
.line	829	loadk        r14   k42 ; k42 = 54
.line	829	loadk        r15   k42 ; k42 = 54
.line	829	loadk        r16   k43 ; k43 = 156
.line	829	loadk        r17   k17 ; k17 = 191
.line	829	loadk        r18   k26 ; k26 = 245
.line	829	loadk        r19   k44 ; k44 = 114
.line	829	loadk        r20   k27 ; k27 = 52
.line	829	loadk        r21   k45 ; k45 = 19
.line	829	loadk        r22   k46 ; k46 = 202
.line	829	loadk        r23   k47 ; k47 = 169
.line	829	loadk        r24   k48 ; k48 = 164
.line	829	loadk        r25   k49 ; k49 = 185
.line	829	loadk        r26   k50 ; k50 = 208
.line	829	loadk        r27   k51 ; k51 = 82
.line	829	loadk        r28   k52 ; k52 = 171
.line	829	loadk        r29   k23 ; k23 = 70
.line	829	loadk        r30   k53 ; k53 = 40
.line	829	loadk        r31   k54 ; k54 = 4
.line	829	loadk        r32   k31 ; k31 = 207
.line	829	loadk        r33   k55 ; k55 = 105
.line	829	loadk        r34   k31 ; k31 = 207
.line	829	loadk        r35    k7 ; k7 = 51
.line	829	loadk        r36   k56 ; k56 = 73
.line	829	loadk        r37   k37 ; k37 = 81
.line	829	loadk        r38   k57 ; k57 = 244
.line	829	loadk        r39   k58 ; k58 = 178
.line	829	loadk        r40   k59 ; k59 = 147
.line	829	loadk        r41   k60 ; k60 = 151
.line	829	loadk        r42   k61 ; k61 = 194
.line	829	loadk        r43   k62 ; k62 = 96
.line	829	loadk        r44   k24 ; k24 = 189
.line	829	loadk        r45   k40 ; k40 = 20
.line	829	loadk        r46   k63 ; k63 = 127
.line	829	loadk        r47   k64 ; k64 = 113
.line	829	loadk        r48   k65 ; k65 = 145
.line	829	loadk        r49   k66 ; k66 = 99
.line	829	loadk        r50   k67 ; k67 = 195
.line	829	loadk        r51   k40 ; k40 = 20
.line	829	loadk        r52   k19 ; k19 = 108
.line	829	call         r12    41     2
.line	829	getupval     r13    u1
.line	829	loadk        r14   k24 ; k24 = 189
.line	829	loadk        r15   k68 ; k68 = 7
.line	829	loadk        r16   k69 ; k69 = 44
.line	829	loadk        r17   k70 ; k70 = 243
.line	829	loadk        r18   k71 ; k71 = 240
.line	829	loadk        r19   k72 ; k72 = 216
.line	829	loadk        r20   k73 ; k73 = 121
.line	829	loadk        r21   k74 ; k74 = 76
.line	829	loadk        r22   k51 ; k51 = 82
.line	829	loadk        r23   k28 ; k28 = 241
.line	829	loadk        r24   k75 ; k75 = 160
.line	829	loadk        r25   k76 ; k76 = 146
.line	829	loadk        r26   k17 ; k17 = 191
.line	829	loadk        r27   k77 ; k77 = 231
.line	829	loadk        r28   k13 ; k13 = 123
.line	829	loadk        r29   k58 ; k58 = 178
.line	829	loadk        r30   k78 ; k78 = 92
.line	829	loadk        r31   k66 ; k66 = 99
.line	829	loadk        r32   k79 ; k79 = 8
.line	829	loadk        r33   k80 ; k80 = 166
.line	829	loadk        r34   k81 ; k81 = 78
.line	829	loadk        r35   k70 ; k70 = 243
.line	829	loadk        r36   k82 ; k82 = 2
.line	829	loadk        r37   k83 ; k83 = 75
.line	829	loadk        r38   k74 ; k74 = 76
.line	829	loadk        r39   k84 ; k84 = 225
.line	829	loadk        r40   k85 ; k85 = 179
.line	829	loadk        r41   k86 ; k86 = 161
.line	829	loadk        r42   k58 ; k58 = 178
.line	829	loadk        r43   k31 ; k31 = 207
.line	829	loadk        r44   k32 ; k32 = 107
.line	829	loadk        r45   k87 ; k87 = 224
.line	829	loadk        r46   k88 ; k88 = 29
.line	829	loadk        r47   k69 ; k69 = 44
.line	829	loadk        r48   k40 ; k40 = 20
.line	829	loadk        r49   k89 ; k89 = 223
.line	829	loadk        r50   k90 ; k90 = 21
.line	829	loadk        r51   k61 ; k61 = 194
.line	829	loadk        r52   k91 ; k91 = 91
.line	829	loadk        r53   k92 ; k92 = 24
.line	829	call         r13    41     2
.line	829	getupval     r14    u1
.line	829	loadk        r15   k93 ; k93 = 253
.line	829	loadk        r16   k94 ; k94 = 12
.line	829	loadk        r17   k95 ; k95 = 116
.line	829	loadk        r18   k96 ; k96 = 255
.line	829	loadk        r19   k26 ; k26 = 245
.line	829	loadk        r20   k97 ; k97 = 226
.line	829	call         r14     7     0
.line	829	setlist      r10     0     1
.line	829	call          r9     2     2
.line	829	move         r10    r1
.line	829	move         r11    r2
.line	829	move         r12    r3
.line	829	move         r13    r4
.line	829	move         r14    r6
.line	829	call          r8     7     2
.label	l152
.line	829	call          r7     2     1
.line	829	gettabup      r7    u2   k98 ; k98 = "GFrameCount"
.line	829	test          r7     1
.line	829	jmp            0  l157
.line	829	loadk         r7   k22 ; k22 = 0
.label	l157
.line	829	gettable      r8    r0   k99 ; k99 = "LastMsgFrame"
.line	829	test          r8     0
.line	829	jmp            0  l271
.line	829	gettable      r8    r0   k99 ; k99 = "LastMsgFrame"
.line	829	eq             0    r7    r8
.line	829	jmp            0  l271
.line	829	gettabup      r8    u0    k0 ; k0 = "print"
.line	829	gettabup      r9    u0    k1 ; k1 = "bWriteLog"
.line	829	test          r9     0
.line	829	jmp            0  l269
.line	829	gettabup      r9    u0    k2 ; k2 = "string"
.line	829	gettable      r9    r9    k3 ; k3 = "format"
.line	829	gettabup     r10    u0    k4 ; k4 = "table"
.line	829	gettable     r10   r10    k5 ; k5 = "concat"
.line	829	newtable     r11     2     0
.line	829	getupval     r12    u1
.line	829	loadk        r13    k6 ; k6 = 149
.line	829	loadk        r14    k7 ; k7 = 51
.line	829	loadk        r15    k8 ; k8 = 25
.line	829	loadk        r16    k9 ; k9 = 150
.line	829	loadk        r17   k10 ; k10 = 134
.line	829	loadk        r18   k11 ; k11 = 254
.line	829	loadk        r19   k12 ; k12 = 126
.line	829	loadk        r20   k13 ; k13 = 123
.line	829	loadk        r21   k14 ; k14 = 86
.line	829	loadk        r22   k15 ; k15 = 197
.line	829	loadk        r23   k16 ; k16 = 162
.line	829	loadk        r24    k9 ; k9 = 150
.line	829	loadk        r25   k17 ; k17 = 191
.line	829	loadk        r26   k18 ; k18 = 198
.line	829	loadk        r27   k19 ; k19 = 108
.line	829	loadk        r28   k20 ; k20 = 175
.line	829	loadk        r29   k21 ; k21 = 18
.line	829	loadk        r30   k22 ; k22 = 0
.line	829	loadk        r31   k23 ; k23 = 70
.line	829	loadk        r32   k24 ; k24 = 189
.line	829	loadk        r33   k25 ; k25 = 115
.line	829	loadk        r34   k26 ; k26 = 245
.line	829	loadk        r35   k27 ; k27 = 52
.line	829	loadk        r36   k13 ; k13 = 123
.line	829	loadk        r37   k14 ; k14 = 86
.line	829	loadk        r38   k28 ; k28 = 241
.line	829	loadk        r39   k29 ; k29 = 163
.line	829	loadk        r40   k30 ; k30 = 142
.line	829	loadk        r41   k20 ; k20 = 175
.line	829	loadk        r42   k31 ; k31 = 207
.line	829	loadk        r43   k32 ; k32 = 107
.line	829	loadk        r44   k33 ; k33 = 153
.line	829	loadk        r45   k34 ; k34 = 89
.line	829	loadk        r46    k7 ; k7 = 51
.line	829	loadk        r47   k35 ; k35 = 84
.line	829	loadk        r48   k36 ; k36 = 157
.line	829	loadk        r49   k37 ; k37 = 81
.line	829	loadk        r50   k38 ; k38 = 210
.line	829	loadk        r51   k39 ; k39 = 28
.line	829	loadk        r52   k40 ; k40 = 20
.line	829	call         r12    41     2
.line	829	getupval     r13    u1
.line	829	loadk        r14   k41 ; k41 = 248
.line	829	loadk        r15  k100 ; k100 = 60
.line	829	loadk        r16  k101 ; k101 = 45
.line	829	loadk        r17  k102 ; k102 = 173
.line	829	loadk        r18   k16 ; k16 = 162
.line	829	loadk        r19   k57 ; k57 = 244
.line	829	loadk        r20   k73 ; k73 = 121
.line	829	loadk        r21   k19 ; k19 = 108
.line	829	loadk        r22  k103 ; k103 = 117
.line	829	loadk        r23   k28 ; k28 = 241
.line	829	loadk        r24   k80 ; k80 = 166
.line	829	loadk        r25  k104 ; k104 = 154
.line	829	loadk        r26  k105 ; k105 = 174
.line	829	loadk        r27   k59 ; k59 = 147
.line	829	loadk        r28  k106 ; k106 = 35
.line	829	loadk        r29  k107 ; k107 = 247
.line	829	loadk        r30   k79 ; k79 = 8
.line	829	loadk        r31  k108 ; k108 = 3
.line	829	loadk        r32   k56 ; k56 = 73
.line	829	loadk        r33   k43 ; k43 = 156
.line	829	loadk        r34   k35 ; k35 = 84
.line	829	loadk        r35  k109 ; k109 = 236
.line	829	loadk        r36   k40 ; k40 = 20
.line	829	loadk        r37  k110 ; k110 = 79
.line	829	loadk        r38  k111 ; k111 = 101
.line	829	loadk        r39   k84 ; k84 = 225
.line	829	loadk        r40  k112 ; k112 = 182
.line	829	loadk        r41  k113 ; k113 = 138
.line	829	loadk        r42  k114 ; k114 = 190
.line	829	loadk        r43  k115 ; k115 = 131
.line	829	loadk        r44  k116 ; k116 = 77
.line	829	loadk        r45   k20 ; k20 = 175
.line	829	loadk        r46  k117 ; k117 = 74
.line	829	loadk        r47  k101 ; k101 = 45
.line	829	loadk        r48  k118 ; k118 = 93
.line	829	loadk        r49   k65 ; k65 = 145
.line	829	loadk        r50  k119 ; k119 = 68
.line	829	loadk        r51  k107 ; k107 = 247
.line	829	loadk        r52  k120 ; k120 = 5
.line	829	loadk        r53   k34 ; k34 = 89
.line	829	call         r13    41     2
.line	829	getupval     r14    u1
.line	829	loadk        r15  k121 ; k121 = 181
.line	829	loadk        r16  k122 ; k122 = 26
.line	829	loadk        r17  k123 ; k123 = 98
.line	829	loadk        r18  k124 ; k124 = 250
.line	829	loadk        r19   k29 ; k29 = 163
.line	829	call         r14     6     0
.line	829	setlist      r11     0     1
.line	829	call         r10     2     2
.line	829	gettabup     r11    u0  k125 ; k125 = "tostring"
.line	829	move         r12    r7
.line	829	call         r11     2     0
.line	829	call          r9     0     2
.label	l269
.line	829	call          r8     2     1
.line	829	return        r0     1
.label	l271
.line	829	settable      r0   k99    r7 ; k99 = "LastMsgFrame"
.line	829	getupval      r8    u1
.line	829	call          r8     1     2
.line	829	eq             1    r5    r8
.line	829	jmp            0  l438
.line	829	gettable      r8    r0  k126 ; k126 = "bSpeechToTextState"
.line	829	eq             0    r8  k127 ; k127 = false
.line	829	jmp            0  l438
.line	829	gettabup      r8    u3  k128 ; k128 = "GetPlayerController"
.line	829	call          r8     1     2
.line	829	gettabup      r9    u0  k129 ; k129 = "slua"
.line	829	gettable      r9    r9  k130 ; k130 = "isValid"
.line	829	move         r10    r8
.line	829	call          r9     2     2
.line	829	test          r9     0
.line	829	jmp            0  l514
.line	829	gettable      r9    r0  k131 ; k131 = "bShowRSTSSubtitleTex" (truncated)
.line	829	test          r9     0
.line	829	jmp            0  l393
.line	829	settable      r0  k132  k133 ; k133 = true
.line	829	gettabup      r9    u0  k134 ; k134 = "pcall"
.line	829	gettable     r10    r8  k135 ; k135 = "SendStringMsg"
.line	829	move         r11    r8
.line	829	move         r12    r5
.line	829	loadk        r13  k136 ; k136 = -1
.line	829	loadk        r14   k22 ; k22 = 0
.line	829	getupval     r15    u1
.line	829	loadk        r16  k137 ; k137 = 232
.line	829	call         r15     2     2
.line	829	loadk        r16   k22 ; k22 = 0
.line	829	loadk        r17   k22 ; k22 = 0
.line	829	loadbool     r18     0     0
.line	829	loadbool     r19     0     0
.line	829	loadbool     r20     0     0
.line	829	call          r9    12     3
.line	829	settable      r0  k132  k127 ; k127 = false
.line	829	test          r9     1
.line	829	jmp            0  l393
.line	829	gettabup     r11    u0    k0 ; k0 = "print"
.line	829	gettabup     r12    u0    k1 ; k1 = "bWriteLog"
.line	829	test         r12     0
.line	829	jmp            0  l392
.line	829	gettabup     r12    u0    k2 ; k2 = "string"
.line	829	gettable     r12   r12    k3 ; k3 = "format"
.line	829	gettabup     r13    u0    k4 ; k4 = "table"
.line	829	gettable     r13   r13    k5 ; k5 = "concat"
.line	829	newtable     r14     1     0
.line	829	getupval     r15    u1
.line	829	loadk        r16    k6 ; k6 = 149
.line	829	loadk        r17    k7 ; k7 = 51
.line	829	loadk        r18    k8 ; k8 = 25
.line	829	loadk        r19    k9 ; k9 = 150
.line	829	loadk        r20   k10 ; k10 = 134
.line	829	loadk        r21   k11 ; k11 = 254
.line	829	loadk        r22   k12 ; k12 = 126
.line	829	loadk        r23   k13 ; k13 = 123
.line	829	loadk        r24   k14 ; k14 = 86
.line	829	loadk        r25   k15 ; k15 = 197
.line	829	loadk        r26   k16 ; k16 = 162
.line	829	loadk        r27    k9 ; k9 = 150
.line	829	loadk        r28   k17 ; k17 = 191
.line	829	loadk        r29   k18 ; k18 = 198
.line	829	loadk        r30   k19 ; k19 = 108
.line	829	loadk        r31   k20 ; k20 = 175
.line	829	loadk        r32   k21 ; k21 = 18
.line	829	loadk        r33   k22 ; k22 = 0
.line	829	loadk        r34   k23 ; k23 = 70
.line	829	loadk        r35   k24 ; k24 = 189
.line	829	loadk        r36   k25 ; k25 = 115
.line	829	loadk        r37   k26 ; k26 = 245
.line	829	loadk        r38   k27 ; k27 = 52
.line	829	loadk        r39   k13 ; k13 = 123
.line	829	loadk        r40   k14 ; k14 = 86
.line	829	loadk        r41   k28 ; k28 = 241
.line	829	loadk        r42   k29 ; k29 = 163
.line	829	loadk        r43   k30 ; k30 = 142
.line	829	loadk        r44   k20 ; k20 = 175
.line	829	loadk        r45   k31 ; k31 = 207
.line	829	loadk        r46   k32 ; k32 = 107
.line	829	loadk        r47   k33 ; k33 = 153
.line	829	loadk        r48   k34 ; k34 = 89
.line	829	loadk        r49    k7 ; k7 = 51
.line	829	loadk        r50   k35 ; k35 = 84
.line	829	loadk        r51   k36 ; k36 = 157
.line	829	loadk        r52   k37 ; k37 = 81
.line	829	loadk        r53   k38 ; k38 = 210
.line	829	loadk        r54   k39 ; k39 = 28
.line	829	loadk        r55   k40 ; k40 = 20
.line	829	call         r15    41     2
.line	829	getupval     r16    u1
.line	829	loadk        r17   k41 ; k41 = 248
.line	829	loadk        r18   k69 ; k69 = 44
.line	829	loadk        r19  k138 ; k138 = 61
.line	829	loadk        r20  k139 ; k139 = 177
.line	829	loadk        r21  k140 ; k140 = 180
.line	829	loadk        r22   k61 ; k61 = 194
.line	829	loadk        r23   k66 ; k66 = 99
.line	829	loadk        r24  k141 ; k141 = 106
.line	829	loadk        r25  k142 ; k142 = 90
.line	829	loadk        r26  k143 ; k143 = 237
.line	829	loadk        r27   k75 ; k75 = 160
.line	829	loadk        r28  k144 ; k144 = 186
.line	829	loadk        r29  k145 ; k145 = 184
.line	829	loadk        r30  k146 ; k146 = 212
.line	829	loadk        r31  k147 ; k147 = 62
.line	829	loadk        r32  k148 ; k148 = 172
.line	829	loadk        r33   k56 ; k56 = 73
.line	829	loadk        r34  k149 ; k149 = 38
.line	829	loadk        r35  k119 ; k119 = 68
.line	829	loadk        r36  k113 ; k113 = 138
.line	829	loadk        r37  k119 ; k119 = 68
.line	829	loadk        r38  k150 ; k150 = 155
.line	829	loadk        r39  k151 ; k151 = 66
.line	829	loadk        r40   k91 ; k91 = 91
.line	829	call         r16    25     0
.line	829	setlist      r14     0     1
.line	829	call         r13     2     2
.line	829	gettabup     r14    u0  k125 ; k125 = "tostring"
.line	829	move         r15   r10
.line	829	call         r14     2     0
.line	829	call         r12     0     2
.label	l392
.line	829	call         r11     2     1
.label	l393
.line	829	gettable      r9    r0  k152 ; k152 = "nRSTSSceneID"
.line	829	gettabup     r10    u4  k153 ; k153 = "Enum_ASRSceneID"
.line	829	gettable     r10   r10  k154 ; k154 = "PublicOpinion"
.line	829	eq             1    r9   r10
.line	829	jmp            0  l399
.line	829	loadbool      r9     0     1
.label	l399
.line	829	loadbool      r9     1     0
.line	829	test          r9     1
.line	829	jmp            0  l412
.line	829	self         r10    r0  k155 ; k155 = "SendDeliveryDataByVo" (truncated)
.line	829	move         r12    r5
.line	829	loadk        r13  k156 ; k156 = 1
.line	829	move         r14    r2
.line	829	move         r15    r6
.line	829	gettable     r16    r0  k157 ; k157 = "bComplaint"
.line	829	call         r10     7     1
.line	829	self         r10    r0  k158 ; k158 = "_NotifyDialogASRText"
.line	829	move         r12    r5
.line	829	call         r10     3     1
.label	l412
.line	829	loadk        r10   k22 ; k22 = 0
.line	829	gettable     r11    r0  k159 ; k159 = "ASRRecord"
.line	829	gettable     r11   r11    r6
.line	829	test         r11     0
.line	829	jmp            0  l423
.line	829	gettabup     r11    u0  k129 ; k129 = "slua"
.line	829	gettable     r11   r11  k160 ; k160 = "getMiliseconds"
.line	829	call         r11     1     2
.line	829	gettable     r12    r0  k159 ; k159 = "ASRRecord"
.line	829	gettable     r12   r12    r6
.line	829	sub          r10   r11   r12
.label	l423
.line	829	self         r11    r0  k161 ; k161 = "RPC_Server_SendRSTSS" (truncated)
.line	829	move         r13    r5
.line	829	self         r14    r0  k162 ; k162 = "GetCurrentServerTime" (truncated)
.line	829	call         r14     2     2
.line	829	move         r15   r10
.line	829	testset      r16    r6     1
.line	829	jmp            0  l436
.line	829	getupval     r16    u1
.line	829	loadk        r17  k112 ; k112 = 182
.line	829	loadk        r18  k163 ; k163 = 16
.line	829	loadk        r19   k42 ; k42 = 54
.line	829	loadk        r20  k144 ; k144 = 186
.line	829	call         r16     5     2
.label	l436
.line	829	call         r11     6     1
.line	829	jmp            0  l514
.label	l438
.line	829	gettabup      r8    u0    k0 ; k0 = "print"
.line	829	gettabup      r9    u0    k1 ; k1 = "bWriteLog"
.line	829	test          r9     0
.line	829	jmp            0  l513
.line	829	gettabup      r9    u0    k4 ; k4 = "table"
.line	829	gettable      r9    r9    k5 ; k5 = "concat"
.line	829	newtable     r10     1     0
.line	829	getupval     r11    u1
.line	829	loadk        r12    k6 ; k6 = 149
.line	829	loadk        r13    k7 ; k7 = 51
.line	829	loadk        r14    k8 ; k8 = 25
.line	829	loadk        r15    k9 ; k9 = 150
.line	829	loadk        r16   k10 ; k10 = 134
.line	829	loadk        r17   k11 ; k11 = 254
.line	829	loadk        r18   k12 ; k12 = 126
.line	829	loadk        r19   k13 ; k13 = 123
.line	829	loadk        r20   k14 ; k14 = 86
.line	829	loadk        r21   k15 ; k15 = 197
.line	829	loadk        r22   k16 ; k16 = 162
.line	829	loadk        r23    k9 ; k9 = 150
.line	829	loadk        r24   k17 ; k17 = 191
.line	829	loadk        r25   k18 ; k18 = 198
.line	829	loadk        r26   k19 ; k19 = 108
.line	829	loadk        r27   k20 ; k20 = 175
.line	829	loadk        r28   k21 ; k21 = 18
.line	829	loadk        r29   k22 ; k22 = 0
.line	829	loadk        r30   k23 ; k23 = 70
.line	829	loadk        r31   k24 ; k24 = 189
.line	829	loadk        r32   k25 ; k25 = 115
.line	829	loadk        r33   k26 ; k26 = 245
.line	829	loadk        r34   k27 ; k27 = 52
.line	829	loadk        r35   k13 ; k13 = 123
.line	829	loadk        r36   k14 ; k14 = 86
.line	829	loadk        r37   k28 ; k28 = 241
.line	829	loadk        r38   k29 ; k29 = 163
.line	829	loadk        r39   k30 ; k30 = 142
.line	829	loadk        r40   k20 ; k20 = 175
.line	829	loadk        r41   k31 ; k31 = 207
.line	829	loadk        r42   k32 ; k32 = 107
.line	829	loadk        r43   k33 ; k33 = 153
.line	829	loadk        r44   k34 ; k34 = 89
.line	829	loadk        r45    k7 ; k7 = 51
.line	829	loadk        r46   k35 ; k35 = 84
.line	829	loadk        r47   k36 ; k36 = 157
.line	829	loadk        r48   k37 ; k37 = 81
.line	829	loadk        r49   k38 ; k38 = 210
.line	829	loadk        r50   k39 ; k39 = 28
.line	829	loadk        r51   k40 ; k40 = 20
.line	829	call         r11    41     2
.line	829	getupval     r12    u1
.line	829	loadk        r13   k41 ; k41 = 248
.line	829	loadk        r14   k42 ; k42 = 54
.line	829	loadk        r15   k42 ; k42 = 54
.line	829	loadk        r16  k164 ; k164 = 139
.line	829	loadk        r17  k139 ; k139 = 177
.line	829	loadk        r18  k165 ; k165 = 227
.line	829	loadk        r19  k166 ; k166 = 112
.line	829	loadk        r20  k167 ; k167 = 125
.line	829	loadk        r21  k168 ; k168 = 71
.line	829	loadk        r22  k169 ; k169 = 215
.line	829	loadk        r23   k16 ; k16 = 162
.line	829	loadk        r24  k170 ; k170 = 143
.line	829	loadk        r25   k17 ; k17 = 191
.line	829	loadk        r26   k59 ; k59 = 147
.line	829	loadk        r27  k171 ; k171 = 119
.line	829	loadk        r28   k49 ; k49 = 185
.line	829	loadk        r29   k79 ; k79 = 8
.line	829	loadk        r30  k172 ; k172 = 42
.line	829	loadk        r31  k173 ; k173 = 69
.line	829	loadk        r32  k174 ; k174 = 159
.line	829	loadk        r33   k35 ; k35 = 84
.line	829	loadk        r34   k72 ; k72 = 216
.line	829	call         r12    23     0
.line	829	setlist      r10     0     1
.line	829	call          r9     2     2
.label	l513
.line	829	call          r8     2     1
.label	l514
.line	829	return        r0     1
.line	829	move          r0    r0
.line	829	move          r0    r0
.line	829	move          r0    r0
.line	829	move          r0    r0
.line	829	return        r0     1

.function	main/f48

.source	null
.linedefined	864
.lastlinedefined	882
.numparams	2
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	3	true
.upvalue	"U3"	11	true

.constant	k0	"Client"
.constant	k1	"nRSTSSceneID"
.constant	k2	"Enum_ASRSceneID"
.constant	k3	"NightWatch"
.constant	k4	"GetPlayerState"
.constant	k5	"slua"
.constant	k6	"isValid"
.constant	k7	"NeutralNPCDialogFeature"
.constant	k8	"HandleVoiceASRTextClient"

.line	864	gettabup      r2    u0    k0 ; k0 = "Client"
.line	864	test          r2     1
.line	864	jmp            0    l5
.line	864	return        r0     1
.label	l5
.line	864	test          r1     0
.line	864	jmp            0   l11
.line	864	getupval      r2    u1
.line	864	call          r2     1     2
.line	864	eq             0    r1    r2
.line	864	jmp            0   l12
.label	l11
.line	864	return        r0     1
.label	l12
.line	864	gettable      r2    r0    k1 ; k1 = "nRSTSSceneID"
.line	864	gettabup      r3    u2    k2 ; k2 = "Enum_ASRSceneID"
.line	864	gettable      r3    r3    k3 ; k3 = "NightWatch"
.line	864	eq             1    r2    r3
.line	864	jmp            0   l18
.line	864	return        r0     1
.label	l18
.line	864	gettabup      r2    u3    k4 ; k4 = "GetPlayerState"
.line	864	call          r2     1     2
.line	864	gettabup      r3    u0    k5 ; k5 = "slua"
.line	864	gettable      r3    r3    k6 ; k6 = "isValid"
.line	864	move          r4    r2
.line	864	call          r3     2     2
.line	864	test          r3     1
.line	864	jmp            0   l27
.line	864	return        r0     1
.label	l27
.line	864	gettable      r3    r2    k7 ; k7 = "NeutralNPCDialogFeat" (truncated)
.line	864	test          r3     0
.line	864	jmp            0   l36
.line	864	gettable      r4    r3    k8 ; k8 = "HandleVoiceASRTextCl" (truncated)
.line	864	test          r4     0
.line	864	jmp            0   l36
.line	864	self          r4    r3    k8 ; k8 = "HandleVoiceASRTextCl" (truncated)
.line	864	move          r6    r1
.line	864	call          r4     3     1
.label	l36
.line	864	return        r0     1
.line	864	move          r0    r0
.line	864	move          r0    r0
.line	864	move          r0    r0
.line	864	move          r0    r0
.line	864	return        r0     1

.function	main/f49

.source	null
.linedefined	884
.lastlinedefined	891
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	7
.constant	k23	73
.constant	k24	129
.constant	k25	68
.constant	k26	205
.constant	k27	2
.constant	k28	103
.constant	k29	77
.constant	k30	195
.constant	k31	187
.constant	k32	124
.constant	k33	137
.constant	k34	93
.constant	k35	49
.constant	k36	92
.constant	k37	172
.constant	k38	100
.constant	k39	229
.constant	k40	58
.constant	k41	75
.constant	k42	59
.constant	k43	61
.constant	k44	179
.constant	k45	181
.constant	k46	246
.constant	k47	118
.constant	k48	231
.constant	k49	132
.constant	k50	214
.constant	k51	109
.constant	k52	185
.constant	k53	40
.constant	k54	202
.constant	k55	83
.constant	k56	"bSendingASRDebugMsg"
.constant	k57	178
.constant	k58	67
.constant	k59	87
.constant	k60	22
.constant	k61	255
.constant	k62	145
.constant	k63	194
.constant	k64	69
.constant	k65	56
.constant	k66	230
.constant	k67	165
.constant	k68	130
.constant	k69	147
.constant	k70	169
.constant	k71	64
.constant	k72	32
.constant	k73	"SendDeliveryDataByVoice"
.constant	k74	"LangID"
.constant	k75	"bComplaint"

.line	884	gettabup      r2    u0    k0 ; k0 = "print"
.line	884	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	884	test          r3     0
.line	884	jmp            0   l79
.line	884	gettabup      r3    u0    k2 ; k2 = "string"
.line	884	gettable      r3    r3    k3 ; k3 = "format"
.line	884	gettabup      r4    u0    k4 ; k4 = "table"
.line	884	gettable      r4    r4    k5 ; k5 = "concat"
.line	884	newtable      r5     1     0
.line	884	getupval      r6    u1
.line	884	loadk         r7    k6 ; k6 = 149
.line	884	loadk         r8    k7 ; k7 = 51
.line	884	loadk         r9    k8 ; k8 = 25
.line	884	loadk        r10    k9 ; k9 = 150
.line	884	loadk        r11   k10 ; k10 = 134
.line	884	loadk        r12   k11 ; k11 = 254
.line	884	loadk        r13   k12 ; k12 = 126
.line	884	loadk        r14   k13 ; k13 = 123
.line	884	loadk        r15   k14 ; k14 = 86
.line	884	loadk        r16   k15 ; k15 = 197
.line	884	loadk        r17   k16 ; k16 = 162
.line	884	loadk        r18    k9 ; k9 = 150
.line	884	loadk        r19   k17 ; k17 = 191
.line	884	loadk        r20   k18 ; k18 = 198
.line	884	loadk        r21   k19 ; k19 = 108
.line	884	loadk        r22   k20 ; k20 = 175
.line	884	loadk        r23   k21 ; k21 = 18
.line	884	loadk        r24   k22 ; k22 = 7
.line	884	loadk        r25   k23 ; k23 = 73
.line	884	loadk        r26   k24 ; k24 = 129
.line	884	loadk        r27   k25 ; k25 = 68
.line	884	loadk        r28   k26 ; k26 = 205
.line	884	loadk        r29   k27 ; k27 = 2
.line	884	loadk        r30   k28 ; k28 = 103
.line	884	loadk        r31   k29 ; k29 = 77
.line	884	loadk        r32   k30 ; k30 = 195
.line	884	loadk        r33   k31 ; k31 = 187
.line	884	loadk        r34   k10 ; k10 = 134
.line	884	loadk        r35   k16 ; k16 = 162
.line	884	loadk        r36   k18 ; k18 = 198
.line	884	loadk        r37   k32 ; k32 = 124
.line	884	loadk        r38   k33 ; k33 = 137
.line	884	loadk        r39   k34 ; k34 = 93
.line	884	loadk        r40   k35 ; k35 = 49
.line	884	loadk        r41   k36 ; k36 = 92
.line	884	loadk        r42   k37 ; k37 = 172
.line	884	loadk        r43   k38 ; k38 = 100
.line	884	loadk        r44   k39 ; k39 = 229
.line	884	loadk        r45   k40 ; k40 = 58
.line	884	loadk        r46   k41 ; k41 = 75
.line	884	call          r6    41     2
.line	884	getupval      r7    u1
.line	884	loadk         r8   k17 ; k17 = 191
.line	884	loadk         r9   k42 ; k42 = 59
.line	884	loadk        r10   k43 ; k43 = 61
.line	884	loadk        r11   k44 ; k44 = 179
.line	884	loadk        r12   k45 ; k45 = 181
.line	884	loadk        r13   k46 ; k46 = 246
.line	884	loadk        r14   k47 ; k47 = 118
.line	884	loadk        r15   k19 ; k19 = 108
.line	884	loadk        r16   k14 ; k14 = 86
.line	884	loadk        r17   k20 ; k20 = 175
.line	884	loadk        r18   k48 ; k48 = 231
.line	884	loadk        r19   k49 ; k49 = 132
.line	884	loadk        r20   k10 ; k10 = 134
.line	884	loadk        r21   k50 ; k50 = 214
.line	884	loadk        r22   k51 ; k51 = 109
.line	884	loadk        r23   k52 ; k52 = 185
.line	884	loadk        r24   k23 ; k23 = 73
.line	884	loadk        r25   k53 ; k53 = 40
.line	884	loadk        r26   k29 ; k29 = 77
.line	884	loadk        r27   k54 ; k54 = 202
.line	884	loadk        r28   k55 ; k55 = 83
.line	884	call          r7    22     0
.line	884	setlist       r5     0     1
.line	884	call          r4     2     2
.line	884	move          r5    r1
.line	884	call          r3     3     2
.label	l79
.line	884	call          r2     2     1
.line	884	gettable      r2    r0   k56 ; k56 = "bSendingASRDebugMsg"
.line	884	test          r2     0
.line	884	jmp            0  l156
.line	884	gettabup      r2    u0    k0 ; k0 = "print"
.line	884	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	884	test          r3     0
.line	884	jmp            0  l154
.line	884	gettabup      r3    u0    k4 ; k4 = "table"
.line	884	gettable      r3    r3    k5 ; k5 = "concat"
.line	884	newtable      r4     1     0
.line	884	getupval      r5    u1
.line	884	loadk         r6    k6 ; k6 = 149
.line	884	loadk         r7    k7 ; k7 = 51
.line	884	loadk         r8    k8 ; k8 = 25
.line	884	loadk         r9    k9 ; k9 = 150
.line	884	loadk        r10   k10 ; k10 = 134
.line	884	loadk        r11   k11 ; k11 = 254
.line	884	loadk        r12   k12 ; k12 = 126
.line	884	loadk        r13   k13 ; k13 = 123
.line	884	loadk        r14   k14 ; k14 = 86
.line	884	loadk        r15   k15 ; k15 = 197
.line	884	loadk        r16   k16 ; k16 = 162
.line	884	loadk        r17    k9 ; k9 = 150
.line	884	loadk        r18   k17 ; k17 = 191
.line	884	loadk        r19   k18 ; k18 = 198
.line	884	loadk        r20   k19 ; k19 = 108
.line	884	loadk        r21   k20 ; k20 = 175
.line	884	loadk        r22   k21 ; k21 = 18
.line	884	loadk        r23   k22 ; k22 = 7
.line	884	loadk        r24   k23 ; k23 = 73
.line	884	loadk        r25   k24 ; k24 = 129
.line	884	loadk        r26   k25 ; k25 = 68
.line	884	loadk        r27   k26 ; k26 = 205
.line	884	loadk        r28   k27 ; k27 = 2
.line	884	loadk        r29   k28 ; k28 = 103
.line	884	loadk        r30   k29 ; k29 = 77
.line	884	loadk        r31   k30 ; k30 = 195
.line	884	loadk        r32   k31 ; k31 = 187
.line	884	loadk        r33   k10 ; k10 = 134
.line	884	loadk        r34   k16 ; k16 = 162
.line	884	loadk        r35   k18 ; k18 = 198
.line	884	loadk        r36   k32 ; k32 = 124
.line	884	loadk        r37   k33 ; k33 = 137
.line	884	loadk        r38   k34 ; k34 = 93
.line	884	loadk        r39   k35 ; k35 = 49
.line	884	loadk        r40   k36 ; k36 = 92
.line	884	loadk        r41   k57 ; k57 = 178
.line	884	loadk        r42   k58 ; k58 = 67
.line	884	loadk        r43   k50 ; k50 = 214
.line	884	loadk        r44   k59 ; k59 = 87
.line	884	loadk        r45   k41 ; k41 = 75
.line	884	call          r5    41     2
.line	884	getupval      r6    u1
.line	884	loadk         r7   k44 ; k44 = 179
.line	884	loadk         r8   k60 ; k60 = 22
.line	884	loadk         r9   k53 ; k53 = 40
.line	884	loadk        r10   k61 ; k61 = 255
.line	884	loadk        r11   k62 ; k62 = 145
.line	884	loadk        r12   k63 ; k63 = 194
.line	884	loadk        r13   k64 ; k64 = 69
.line	884	loadk        r14   k65 ; k65 = 56
.line	884	loadk        r15   k59 ; k59 = 87
.line	884	loadk        r16   k66 ; k66 = 230
.line	884	loadk        r17   k67 ; k67 = 165
.line	884	loadk        r18   k68 ; k68 = 130
.line	884	loadk        r19   k37 ; k37 = 172
.line	884	loadk        r20   k69 ; k69 = 147
.line	884	loadk        r21   k13 ; k13 = 123
.line	884	loadk        r22   k70 ; k70 = 169
.line	884	loadk        r23   k71 ; k71 = 64
.line	884	loadk        r24   k72 ; k72 = 32
.line	884	call          r6    19     0
.line	884	setlist       r4     0     1
.line	884	call          r3     2     2
.label	l154
.line	884	call          r2     2     1
.line	884	return        r0     1
.label	l156
.line	884	self          r2    r0   k73 ; k73 = "SendDeliveryDataByVo" (truncated)
.line	884	move          r4    r1
.line	884	loadk         r5   k27 ; k27 = 2
.line	884	gettable      r6    r0   k74 ; k74 = "LangID"
.line	884	loadnil       r7     0
.line	884	gettable      r8    r0   k75 ; k75 = "bComplaint"
.line	884	call          r2     7     1
.line	884	return        r0     1
.line	884	move          r0    r0
.line	884	return        r0     1

.function	main/f50

.source	null
.linedefined	893
.lastlinedefined	896
.numparams	6
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	7
.constant	k23	73
.constant	k24	129
.constant	k25	68
.constant	k26	205
.constant	k27	2
.constant	k28	103
.constant	k29	77
.constant	k30	221
.constant	k31	135
.constant	k32	164
.constant	k33	159
.constant	k34	202
.constant	k35	111
.constant	k36	182
.constant	k37	87
.constant	k38	56
.constant	k39	107
.constant	k40	154
.constant	k41	94
.constant	k42	213
.constant	k43	35
.constant	k44	93
.constant	k45	160
.constant	k46	11
.constant	k47	116
.constant	k48	255
.constant	k49	163
.constant	k50	220
.constant	k51	114
.constant	k52	64
.constant	k53	226
.constant	k54	146
.constant	k55	246
.constant	k56	109
.constant	k57	"tostring"
.constant	k58	"SendDeliveryDataByVoice"
.constant	k59	"LangID"
.constant	k60	"bComplaint"

.line	893	gettabup      r6    u0    k0 ; k0 = "print"
.line	893	gettabup      r7    u0    k1 ; k1 = "bWriteLog"
.line	893	test          r7     0
.line	893	jmp            0   l75
.line	893	gettabup      r7    u0    k2 ; k2 = "string"
.line	893	gettable      r7    r7    k3 ; k3 = "format"
.line	893	gettabup      r8    u0    k4 ; k4 = "table"
.line	893	gettable      r8    r8    k5 ; k5 = "concat"
.line	893	newtable      r9     1     0
.line	893	getupval     r10    u1
.line	893	loadk        r11    k6 ; k6 = 149
.line	893	loadk        r12    k7 ; k7 = 51
.line	893	loadk        r13    k8 ; k8 = 25
.line	893	loadk        r14    k9 ; k9 = 150
.line	893	loadk        r15   k10 ; k10 = 134
.line	893	loadk        r16   k11 ; k11 = 254
.line	893	loadk        r17   k12 ; k12 = 126
.line	893	loadk        r18   k13 ; k13 = 123
.line	893	loadk        r19   k14 ; k14 = 86
.line	893	loadk        r20   k15 ; k15 = 197
.line	893	loadk        r21   k16 ; k16 = 162
.line	893	loadk        r22    k9 ; k9 = 150
.line	893	loadk        r23   k17 ; k17 = 191
.line	893	loadk        r24   k18 ; k18 = 198
.line	893	loadk        r25   k19 ; k19 = 108
.line	893	loadk        r26   k20 ; k20 = 175
.line	893	loadk        r27   k21 ; k21 = 18
.line	893	loadk        r28   k22 ; k22 = 7
.line	893	loadk        r29   k23 ; k23 = 73
.line	893	loadk        r30   k24 ; k24 = 129
.line	893	loadk        r31   k25 ; k25 = 68
.line	893	loadk        r32   k26 ; k26 = 205
.line	893	loadk        r33   k27 ; k27 = 2
.line	893	loadk        r34   k28 ; k28 = 103
.line	893	loadk        r35   k29 ; k29 = 77
.line	893	loadk        r36   k30 ; k30 = 221
.line	893	loadk        r37   k31 ; k31 = 135
.line	893	loadk        r38   k32 ; k32 = 164
.line	893	loadk        r39   k33 ; k33 = 159
.line	893	loadk        r40   k34 ; k34 = 202
.line	893	loadk        r41   k35 ; k35 = 111
.line	893	loadk        r42   k36 ; k36 = 182
.line	893	loadk        r43   k37 ; k37 = 87
.line	893	loadk        r44   k38 ; k38 = 56
.line	893	loadk        r45   k39 ; k39 = 107
.line	893	loadk        r46   k40 ; k40 = 154
.line	893	loadk        r47   k41 ; k41 = 94
.line	893	loadk        r48   k42 ; k42 = 213
.line	893	loadk        r49   k43 ; k43 = 35
.line	893	loadk        r50   k44 ; k44 = 93
.line	893	call         r10    41     2
.line	893	getupval     r11    u1
.line	893	loadk        r12   k45 ; k45 = 160
.line	893	loadk        r13   k46 ; k46 = 11
.line	893	loadk        r14   k47 ; k47 = 116
.line	893	loadk        r15   k48 ; k48 = 255
.line	893	loadk        r16   k49 ; k49 = 163
.line	893	loadk        r17   k50 ; k50 = 220
.line	893	loadk        r18   k51 ; k51 = 114
.line	893	loadk        r19   k39 ; k39 = 107
.line	893	loadk        r20   k52 ; k52 = 64
.line	893	loadk        r21   k53 ; k53 = 226
.line	893	loadk        r22   k45 ; k45 = 160
.line	893	loadk        r23   k54 ; k54 = 146
.line	893	loadk        r24   k55 ; k55 = 246
.line	893	loadk        r25    k9 ; k9 = 150
.line	893	loadk        r26   k56 ; k56 = 109
.line	893	call         r11    16     0
.line	893	setlist       r9     0     1
.line	893	call          r8     2     2
.line	893	gettabup      r9    u0   k57 ; k57 = "tostring"
.line	893	move         r10    r3
.line	893	call          r9     2     0
.line	893	call          r7     0     2
.label	l75
.line	893	call          r6     2     1
.line	893	self          r6    r0   k58 ; k58 = "SendDeliveryDataByVo" (truncated)
.line	893	move          r8    r3
.line	893	loadk         r9   k27 ; k27 = 2
.line	893	gettable     r10    r0   k59 ; k59 = "LangID"
.line	893	loadnil      r11     0
.line	893	gettable     r12    r0   k60 ; k60 = "bComplaint"
.line	893	move         r13    r5
.line	893	call          r6     8     1
.line	893	return        r0     1
.line	893	move          r0    r0
.line	893	move          r0    r0
.line	893	return        r0     1

.function	main/f51

.source	null
.linedefined	898
.lastlinedefined	960
.numparams	8
.is_vararg	0
.maxstacksize	61

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	139
.constant	k7	26
.constant	k8	54
.constant	k9	187
.constant	k10	148
.constant	k11	244
.constant	k12	123
.constant	k13	113
.constant	k14	69
.constant	k15	230
.constant	k16	181
.constant	k17	142
.constant	k18	143
.constant	k19	210
.constant	k20	106
.constant	k21	171
.constant	k22	126
.constant	k23	128
.constant	k24	73
.constant	k25	194
.constant	k26	2
.constant	k27	8
.constant	k28	80
.constant	k29	222
.constant	k30	178
.constant	k31	168
.constant	k32	105
.constant	k33	191
.constant	k34	24
.constant	k35	98
.constant	k36	218
.constant	k37	67
.constant	k38	145
.constant	k39	25
.constant	k40	108
.constant	k41	161
.constant	k42	15
.constant	k43	61
.constant	k44	255
.constant	k45	237
.constant	k46	177
.constant	k47	50
.constant	k48	107
.constant	k49	"tostring"
.constant	k50	"CanSendDeliverInfo"
.constant	k51	149
.constant	k52	51
.constant	k53	150
.constant	k54	134
.constant	k55	254
.constant	k56	86
.constant	k57	197
.constant	k58	162
.constant	k59	198
.constant	k60	175
.constant	k61	18
.constant	k62	28
.constant	k63	77
.constant	k64	129
.constant	k65	68
.constant	k66	229
.constant	k67	74
.constant	k68	231
.constant	k69	111
.constant	k70	174
.constant	k71	89
.constant	k72	29
.constant	k73	65
.constant	k74	169
.constant	k75	95
.constant	k76	216
.constant	k77	20
.constant	k78	93
.constant	k79	248
.constant	k80	27
.constant	k81	117
.constant	k82	97
.constant	k83	19
.constant	k84	192
.constant	k85	166
.constant	k86	153
.constant	k87	152
.constant	k88	214
.constant	k89	112
.constant	k90	42
.constant	k91	196
.constant	k92	21
.constant	k93	245
.constant	k94	184
.constant	k95	"find"
.constant	k96	228
.constant	k97	60
.constant	k98	48
.constant	k99	190
.constant	k100	164
.constant	k101	232
.constant	k102	138
.constant	k103	132
.constant	k104	172
.constant	k105	141
.constant	k106	1
.constant	k107	12
.constant	k108	182
.constant	k109	160
.constant	k110	84
.constant	k111	82
.constant	k112	247
.constant	k113	130
.constant	k114	208
.constant	k115	135
.constant	k116	91
.constant	k117	40
.constant	k118	155
.constant	k119	217
.constant	k120	"Owner"
.constant	k121	"Object"
.constant	k122	"slua"
.constant	k123	"isValid"
.constant	k124	10
.constant	k125	179
.constant	k126	114
.constant	k127	236
.constant	k128	131
.constant	k129	185
.constant	k130	220
.constant	k131	83
.constant	k132	9
.constant	k133	79
.constant	k134	"PlayerState"
.constant	k135	"AIGCRequestID"
.constant	k136	nil
.constant	k137	"AreaID"
.constant	k138	"InitSecurityBaseInfo"
.constant	k139	"require"
.constant	k140	49
.constant	k141	186
.constant	k142	57
.constant	k143	92
.constant	k144	238
.constant	k145	170
.constant	k146	165
.constant	k147	157
.constant	k148	163
.constant	k149	119
.constant	k150	154
.constant	k151	200
.constant	k152	11
.constant	k153	"GetServerTimeInSec"
.constant	k154	"option"
.constant	k155	189
.constant	k156	17
.constant	k157	45
.constant	k158	240
.constant	k159	100
.constant	k160	71
.constant	k161	226
.constant	k162	"loadfile"
.constant	k163	188
.constant	k164	7
.constant	k165	118
.constant	k166	158
.constant	k167	46
.constant	k168	90
.constant	k169	127
.constant	k170	207
.constant	k171	23
.constant	k172	75
.constant	k173	124
.constant	k174	205
.constant	k175	122
.constant	k176	72
.constant	k177	"tonumber"
.constant	k178	0
.constant	k179	"DialogTargetUID"
.constant	k180	10000
.constant	k181	"request_id"
.constant	k182	"query"
.constant	k183	"version"
.constant	k184	233
.constant	k185	"context"
.constant	k186	"uid"
.constant	k187	"UID"
.constant	k188	"query_gen_type"
.constant	k189	"plat_id"
.constant	k190	"PlatID"
.constant	k191	"area_id"
.constant	k192	"region_id"
.constant	k193	"GetRegionID"
.constant	k194	"lang_id"
.constant	k195	"LangID"
.constant	k196	-1
.constant	k197	"session_name"
.constant	k198	"is_complaint"
.constant	k199	"target_uid"
.constant	k200	44
.constant	k201	246
.constant	k202	147
.constant	k203	241
.constant	k204	109
.constant	k205	"encode"
.constant	k206	173
.constant	k207	206
.constant	k208	121
.constant	k209	104
.constant	k210	6
.constant	k211	14
.constant	k212	99
.constant	k213	243
.constant	k214	"AntsVoiceInterface"
.constant	k215	"SetDeliverData"
.constant	k216	"log_tree"
.constant	k217	94
.constant	k218	209
.constant	k219	"_AddAIDialogContext"
.constant	k220	"PlayerName"

.line	898	gettabup      r8    u0    k0 ; k0 = "print"
.line	898	gettabup      r9    u0    k1 ; k1 = "bWriteLog"
.line	898	test          r9     0
.line	898	jmp            0   l71
.line	898	gettabup      r9    u0    k2 ; k2 = "string"
.line	898	gettable      r9    r9    k3 ; k3 = "format"
.line	898	gettabup     r10    u0    k4 ; k4 = "table"
.line	898	gettable     r10   r10    k5 ; k5 = "concat"
.line	898	newtable     r11     1     0
.line	898	getupval     r12    u1
.line	898	loadk        r13    k6 ; k6 = 139
.line	898	loadk        r14    k7 ; k7 = 26
.line	898	loadk        r15    k8 ; k8 = 54
.line	898	loadk        r16    k9 ; k9 = 187
.line	898	loadk        r17   k10 ; k10 = 148
.line	898	loadk        r18   k11 ; k11 = 244
.line	898	loadk        r19   k12 ; k12 = 123
.line	898	loadk        r20   k13 ; k13 = 113
.line	898	loadk        r21   k14 ; k14 = 69
.line	898	loadk        r22   k15 ; k15 = 230
.line	898	loadk        r23   k16 ; k16 = 181
.line	898	loadk        r24   k17 ; k17 = 142
.line	898	loadk        r25   k18 ; k18 = 143
.line	898	loadk        r26   k19 ; k19 = 210
.line	898	loadk        r27   k20 ; k20 = 106
.line	898	loadk        r28   k21 ; k21 = 171
.line	898	loadk        r29   k20 ; k20 = 106
.line	898	loadk        r30    k8 ; k8 = 54
.line	898	loadk        r31   k22 ; k22 = 126
.line	898	loadk        r32   k23 ; k23 = 128
.line	898	loadk        r33   k24 ; k24 = 73
.line	898	loadk        r34   k25 ; k25 = 194
.line	898	loadk        r35   k26 ; k26 = 2
.line	898	loadk        r36   k27 ; k27 = 8
.line	898	loadk        r37   k28 ; k28 = 80
.line	898	loadk        r38   k29 ; k29 = 222
.line	898	loadk        r39   k30 ; k30 = 178
.line	898	loadk        r40   k10 ; k10 = 148
.line	898	loadk        r41   k31 ; k31 = 168
.line	898	loadk        r42   k25 ; k25 = 194
.line	898	loadk        r43   k32 ; k32 = 105
.line	898	loadk        r44   k33 ; k33 = 191
.line	898	loadk        r45   k34 ; k34 = 24
.line	898	loadk        r46   k35 ; k35 = 98
.line	898	loadk        r47   k34 ; k34 = 24
.line	898	loadk        r48   k36 ; k36 = 218
.line	898	loadk        r49   k37 ; k37 = 67
.line	898	loadk        r50   k38 ; k38 = 145
.line	898	loadk        r51   k39 ; k39 = 25
.line	898	loadk        r52   k40 ; k40 = 108
.line	898	call         r12    41     2
.line	898	getupval     r13    u1
.line	898	loadk        r14   k41 ; k41 = 161
.line	898	loadk        r15   k42 ; k42 = 15
.line	898	loadk        r16   k43 ; k43 = 61
.line	898	loadk        r17   k44 ; k44 = 255
.line	898	loadk        r18   k45 ; k45 = 237
.line	898	loadk        r19   k46 ; k46 = 177
.line	898	loadk        r20   k47 ; k47 = 50
.line	898	loadk        r21   k48 ; k48 = 107
.line	898	call         r13     9     0
.line	898	setlist      r11     0     1
.line	898	call         r10     2     2
.line	898	gettabup     r11    u0   k49 ; k49 = "tostring"
.line	898	move         r12    r1
.line	898	call         r11     2     2
.line	898	gettabup     r12    u0   k49 ; k49 = "tostring"
.line	898	move         r13    r2
.line	898	call         r12     2     0
.line	898	call          r9     0     2
.label	l71
.line	898	call          r8     2     1
.line	898	self          r8    r0   k50 ; k50 = "CanSendDeliverInfo"
.line	898	call          r8     2     2
.line	898	test          r8     1
.line	898	jmp            0  l158
.line	898	gettabup      r8    u0    k0 ; k0 = "print"
.line	898	gettabup      r9    u0    k1 ; k1 = "bWriteLog"
.line	898	test          r9     0
.line	898	jmp            0  l156
.line	898	gettabup      r9    u0    k4 ; k4 = "table"
.line	898	gettable      r9    r9    k5 ; k5 = "concat"
.line	898	newtable     r10     1     0
.line	898	getupval     r11    u1
.line	898	loadk        r12   k51 ; k51 = 149
.line	898	loadk        r13   k52 ; k52 = 51
.line	898	loadk        r14   k39 ; k39 = 25
.line	898	loadk        r15   k53 ; k53 = 150
.line	898	loadk        r16   k54 ; k54 = 134
.line	898	loadk        r17   k55 ; k55 = 254
.line	898	loadk        r18   k22 ; k22 = 126
.line	898	loadk        r19   k12 ; k12 = 123
.line	898	loadk        r20   k56 ; k56 = 86
.line	898	loadk        r21   k57 ; k57 = 197
.line	898	loadk        r22   k58 ; k58 = 162
.line	898	loadk        r23   k53 ; k53 = 150
.line	898	loadk        r24   k33 ; k33 = 191
.line	898	loadk        r25   k59 ; k59 = 198
.line	898	loadk        r26   k40 ; k40 = 108
.line	898	loadk        r27   k60 ; k60 = 175
.line	898	loadk        r28   k61 ; k61 = 18
.line	898	loadk        r29   k62 ; k62 = 28
.line	898	loadk        r30   k63 ; k63 = 77
.line	898	loadk        r31   k64 ; k64 = 129
.line	898	loadk        r32   k65 ; k65 = 68
.line	898	loadk        r33   k66 ; k66 = 229
.line	898	loadk        r34   k26 ; k26 = 2
.line	898	loadk        r35   k65 ; k65 = 68
.line	898	loadk        r36   k67 ; k67 = 74
.line	898	loadk        r37   k66 ; k66 = 229
.line	898	loadk        r38   k30 ; k30 = 178
.line	898	loadk        r39   k51 ; k51 = 149
.line	898	loadk        r40   k58 ; k58 = 162
.line	898	loadk        r41   k68 ; k68 = 231
.line	898	loadk        r42   k69 ; k69 = 111
.line	898	loadk        r43   k70 ; k70 = 174
.line	898	loadk        r44   k71 ; k71 = 89
.line	898	loadk        r45   k72 ; k72 = 29
.line	898	loadk        r46   k73 ; k73 = 65
.line	898	loadk        r47   k74 ; k74 = 169
.line	898	loadk        r48   k75 ; k75 = 95
.line	898	loadk        r49   k76 ; k76 = 216
.line	898	loadk        r50   k77 ; k77 = 20
.line	898	loadk        r51   k78 ; k78 = 93
.line	898	call         r11    41     2
.line	898	getupval     r12    u1
.line	898	loadk        r13   k79 ; k79 = 248
.line	898	loadk        r14   k80 ; k80 = 27
.line	898	loadk        r15   k43 ; k43 = 61
.line	898	loadk        r16   k46 ; k46 = 177
.line	898	loadk        r17   k74 ; k74 = 169
.line	898	loadk        r18   k46 ; k46 = 177
.line	898	loadk        r19   k81 ; k81 = 117
.line	898	loadk        r20   k82 ; k82 = 97
.line	898	loadk        r21   k83 ; k83 = 19
.line	898	loadk        r22   k84 ; k84 = 192
.line	898	loadk        r23   k85 ; k85 = 166
.line	898	loadk        r24   k86 ; k86 = 153
.line	898	loadk        r25   k87 ; k87 = 152
.line	898	loadk        r26   k88 ; k88 = 214
.line	898	loadk        r27   k89 ; k89 = 112
.line	898	loadk        r28   k70 ; k70 = 174
.line	898	loadk        r29   k40 ; k40 = 108
.line	898	loadk        r30   k90 ; k90 = 42
.line	898	loadk        r31   k65 ; k65 = 68
.line	898	loadk        r32   k54 ; k54 = 134
.line	898	loadk        r33   k56 ; k56 = 86
.line	898	loadk        r34   k91 ; k91 = 196
.line	898	loadk        r35   k92 ; k92 = 21
.line	898	loadk        r36   k82 ; k82 = 97
.line	898	loadk        r37   k63 ; k63 = 77
.line	898	loadk        r38   k93 ; k93 = 245
.line	898	loadk        r39   k94 ; k94 = 184
.line	898	call         r12    28     0
.line	898	setlist      r10     0     1
.line	898	call          r9     2     2
.label	l156
.line	898	call          r8     2     1
.line	898	return        r0     1
.label	l158
.line	898	eq             0    r2   k26 ; k26 = 2
.line	898	jmp            0  l264
.line	898	test          r1     0
.line	898	jmp            0  l264
.line	898	gettabup      r8    u0    k2 ; k2 = "string"
.line	898	gettable      r8    r8   k95 ; k95 = "find"
.line	898	move          r9    r1
.line	898	getupval     r10    u1
.line	898	loadk        r11   k96 ; k96 = 228
.line	898	loadk        r12   k97 ; k97 = 60
.line	898	loadk        r13   k98 ; k98 = 48
.line	898	loadk        r14   k99 ; k99 = 190
.line	898	loadk        r15  k100 ; k100 = 164
.line	898	loadk        r16   k84 ; k84 = 192
.line	898	loadk        r17   k35 ; k35 = 98
.line	898	loadk        r18   k13 ; k13 = 113
.line	898	loadk        r19   k28 ; k28 = 80
.line	898	loadk        r20  k101 ; k101 = 232
.line	898	loadk        r21  k102 ; k102 = 138
.line	898	loadk        r22  k103 ; k103 = 132
.line	898	loadk        r23  k104 ; k104 = 172
.line	898	loadk        r24  k105 ; k105 = 141
.line	898	call         r10    15     2
.line	898	loadk        r11  k106 ; k106 = 1
.line	898	loadbool     r12     1     0
.line	898	call          r8     5     2
.line	898	test          r8     0
.line	898	jmp            0  l264
.line	898	gettabup      r8    u0    k0 ; k0 = "print"
.line	898	gettabup      r9    u0    k1 ; k1 = "bWriteLog"
.line	898	test          r9     0
.line	898	jmp            0  l262
.line	898	gettabup      r9    u0    k4 ; k4 = "table"
.line	898	gettable      r9    r9    k5 ; k5 = "concat"
.line	898	newtable     r10     1     0
.line	898	getupval     r11    u1
.line	898	loadk        r12   k51 ; k51 = 149
.line	898	loadk        r13   k52 ; k52 = 51
.line	898	loadk        r14   k39 ; k39 = 25
.line	898	loadk        r15   k53 ; k53 = 150
.line	898	loadk        r16   k54 ; k54 = 134
.line	898	loadk        r17   k55 ; k55 = 254
.line	898	loadk        r18   k22 ; k22 = 126
.line	898	loadk        r19   k12 ; k12 = 123
.line	898	loadk        r20   k56 ; k56 = 86
.line	898	loadk        r21   k57 ; k57 = 197
.line	898	loadk        r22   k58 ; k58 = 162
.line	898	loadk        r23   k53 ; k53 = 150
.line	898	loadk        r24   k33 ; k33 = 191
.line	898	loadk        r25   k59 ; k59 = 198
.line	898	loadk        r26   k40 ; k40 = 108
.line	898	loadk        r27   k60 ; k60 = 175
.line	898	loadk        r28   k61 ; k61 = 18
.line	898	loadk        r29   k62 ; k62 = 28
.line	898	loadk        r30   k63 ; k63 = 77
.line	898	loadk        r31   k64 ; k64 = 129
.line	898	loadk        r32   k65 ; k65 = 68
.line	898	loadk        r33   k66 ; k66 = 229
.line	898	loadk        r34   k26 ; k26 = 2
.line	898	loadk        r35   k65 ; k65 = 68
.line	898	loadk        r36   k67 ; k67 = 74
.line	898	loadk        r37   k66 ; k66 = 229
.line	898	loadk        r38   k30 ; k30 = 178
.line	898	loadk        r39   k51 ; k51 = 149
.line	898	loadk        r40   k58 ; k58 = 162
.line	898	loadk        r41   k68 ; k68 = 231
.line	898	loadk        r42   k69 ; k69 = 111
.line	898	loadk        r43   k70 ; k70 = 174
.line	898	loadk        r44   k71 ; k71 = 89
.line	898	loadk        r45   k72 ; k72 = 29
.line	898	loadk        r46   k73 ; k73 = 65
.line	898	loadk        r47   k74 ; k74 = 169
.line	898	loadk        r48   k75 ; k75 = 95
.line	898	loadk        r49   k76 ; k76 = 216
.line	898	loadk        r50   k77 ; k77 = 20
.line	898	loadk        r51   k78 ; k78 = 93
.line	898	call         r11    41     2
.line	898	getupval     r12    u1
.line	898	loadk        r13   k79 ; k79 = 248
.line	898	loadk        r14  k107 ; k107 = 12
.line	898	loadk        r15   k52 ; k52 = 51
.line	898	loadk        r16  k108 ; k108 = 182
.line	898	loadk        r17  k109 ; k109 = 160
.line	898	loadk        r18   k46 ; k46 = 177
.line	898	loadk        r19  k110 ; k110 = 84
.line	898	loadk        r20   k89 ; k89 = 112
.line	898	loadk        r21  k111 ; k111 = 82
.line	898	loadk        r22  k112 ; k112 = 247
.line	898	loadk        r23   k53 ; k53 = 150
.line	898	loadk        r24  k113 ; k113 = 130
.line	898	loadk        r25   k58 ; k58 = 162
.line	898	loadk        r26  k114 ; k114 = 208
.line	898	loadk        r27   k81 ; k81 = 117
.line	898	loadk        r28  k115 ; k115 = 135
.line	898	loadk        r29  k116 ; k116 = 91
.line	898	loadk        r30  k117 ; k117 = 40
.line	898	loadk        r31   k27 ; k27 = 8
.line	898	loadk        r32  k118 ; k118 = 155
.line	898	loadk        r33   k14 ; k14 = 69
.line	898	loadk        r34  k119 ; k119 = 217
.line	898	loadk        r35   k83 ; k83 = 19
.line	898	call         r12    24     0
.line	898	setlist      r10     0     1
.line	898	call          r9     2     2
.label	l262
.line	898	call          r8     2     1
.line	898	return        r0     1
.label	l264
.line	898	test          r1     0
.line	898	jmp            0  l675
.line	898	getupval      r8    u1
.line	898	call          r8     1     2
.line	898	eq             1    r1    r8
.line	898	jmp            0  l675
.line	898	test          r2     0
.line	898	jmp            0  l675
.line	898	gettable      r8    r0  k120 ; k120 = "Owner"
.line	898	gettable      r8    r8  k121 ; k121 = "Object"
.line	898	gettabup      r9    u0  k122 ; k122 = "slua"
.line	898	gettable      r9    r9  k123 ; k123 = "isValid"
.line	898	move         r10    r8
.line	898	call          r9     2     2
.line	898	test          r9     1
.line	898	jmp            0  l360
.line	898	gettabup      r9    u0    k0 ; k0 = "print"
.line	898	gettabup     r10    u0    k1 ; k1 = "bWriteLog"
.line	898	test         r10     0
.line	898	jmp            0  l358
.line	898	gettabup     r10    u0    k4 ; k4 = "table"
.line	898	gettable     r10   r10    k5 ; k5 = "concat"
.line	898	newtable     r11     1     0
.line	898	getupval     r12    u1
.line	898	loadk        r13   k51 ; k51 = 149
.line	898	loadk        r14   k52 ; k52 = 51
.line	898	loadk        r15   k39 ; k39 = 25
.line	898	loadk        r16   k53 ; k53 = 150
.line	898	loadk        r17   k54 ; k54 = 134
.line	898	loadk        r18   k55 ; k55 = 254
.line	898	loadk        r19   k22 ; k22 = 126
.line	898	loadk        r20   k12 ; k12 = 123
.line	898	loadk        r21   k56 ; k56 = 86
.line	898	loadk        r22   k57 ; k57 = 197
.line	898	loadk        r23   k58 ; k58 = 162
.line	898	loadk        r24   k53 ; k53 = 150
.line	898	loadk        r25   k33 ; k33 = 191
.line	898	loadk        r26   k59 ; k59 = 198
.line	898	loadk        r27   k40 ; k40 = 108
.line	898	loadk        r28   k60 ; k60 = 175
.line	898	loadk        r29   k61 ; k61 = 18
.line	898	loadk        r30   k62 ; k62 = 28
.line	898	loadk        r31   k63 ; k63 = 77
.line	898	loadk        r32   k64 ; k64 = 129
.line	898	loadk        r33   k65 ; k65 = 68
.line	898	loadk        r34   k66 ; k66 = 229
.line	898	loadk        r35   k26 ; k26 = 2
.line	898	loadk        r36   k65 ; k65 = 68
.line	898	loadk        r37   k67 ; k67 = 74
.line	898	loadk        r38   k66 ; k66 = 229
.line	898	loadk        r39   k30 ; k30 = 178
.line	898	loadk        r40   k51 ; k51 = 149
.line	898	loadk        r41   k58 ; k58 = 162
.line	898	loadk        r42   k68 ; k68 = 231
.line	898	loadk        r43   k69 ; k69 = 111
.line	898	loadk        r44   k70 ; k70 = 174
.line	898	loadk        r45   k71 ; k71 = 89
.line	898	loadk        r46   k72 ; k72 = 29
.line	898	loadk        r47   k73 ; k73 = 65
.line	898	loadk        r48   k74 ; k74 = 169
.line	898	loadk        r49   k75 ; k75 = 95
.line	898	loadk        r50   k76 ; k76 = 216
.line	898	loadk        r51   k77 ; k77 = 20
.line	898	loadk        r52   k78 ; k78 = 93
.line	898	call         r12    41     2
.line	898	getupval     r13    u1
.line	898	loadk        r14   k79 ; k79 = 248
.line	898	loadk        r15  k124 ; k124 = 10
.line	898	loadk        r16   k27 ; k27 = 8
.line	898	loadk        r17  k125 ; k125 = 179
.line	898	loadk        r18   k46 ; k46 = 177
.line	898	loadk        r19  k101 ; k101 = 232
.line	898	loadk        r20  k126 ; k126 = 114
.line	898	loadk        r21   k20 ; k20 = 106
.line	898	loadk        r22   k89 ; k89 = 112
.line	898	loadk        r23  k127 ; k127 = 236
.line	898	loadk        r24   k74 ; k74 = 169
.line	898	loadk        r25  k128 ; k128 = 131
.line	898	loadk        r26  k129 ; k129 = 185
.line	898	loadk        r27  k130 ; k130 = 220
.line	898	loadk        r28  k126 ; k126 = 114
.line	898	loadk        r29   k85 ; k85 = 166
.line	898	loadk        r30   k63 ; k63 = 77
.line	898	loadk        r31   k43 ; k43 = 61
.line	898	loadk        r32   k27 ; k27 = 8
.line	898	loadk        r33   k54 ; k54 = 134
.line	898	loadk        r34  k131 ; k131 = 83
.line	898	loadk        r35   k64 ; k64 = 129
.line	898	loadk        r36  k132 ; k132 = 9
.line	898	loadk        r37   k73 ; k73 = 65
.line	898	loadk        r38  k133 ; k133 = 79
.line	898	call         r13    26     0
.line	898	setlist      r11     0     1
.line	898	call         r10     2     2
.label	l358
.line	898	call          r9     2     1
.line	898	return        r0     1
.label	l360
.line	898	gettable      r9    r8  k134 ; k134 = "PlayerState"
.line	898	gettabup     r10    u0  k122 ; k122 = "slua"
.line	898	gettable     r10   r10  k123 ; k123 = "isValid"
.line	898	move         r11    r9
.line	898	call         r10     2     2
.line	898	test         r10     0
.line	898	jmp            0  l675
.line	898	gettable     r10    r9  k135 ; k135 = "AIGCRequestID"
.line	898	eq             0   r10  k136 ; k136 = nil
.line	898	jmp            0  l371
.line	898	settable      r9  k135  k106 ; k106 = 1
.label	l371
.line	898	gettable     r10    r0  k137 ; k137 = "AreaID"
.line	898	eq             0   r10  k136 ; k136 = nil
.line	898	jmp            0  l377
.line	898	self         r10    r0  k138 ; k138 = "InitSecurityBaseInfo"
.line	898	move         r12    r8
.line	898	call         r10     3     1
.label	l377
.line	898	gettabup     r10    u0  k139 ; k139 = "require"
.line	898	getupval     r11    u1
.line	898	loadk        r12    k9 ; k9 = 187
.line	898	loadk        r13   k83 ; k83 = 19
.line	898	loadk        r14  k140 ; k140 = 49
.line	898	loadk        r15  k141 ; k141 = 186
.line	898	loadk        r16   k99 ; k99 = 190
.line	898	loadk        r17   k66 ; k66 = 229
.line	898	loadk        r18  k142 ; k142 = 57
.line	898	loadk        r19   k12 ; k12 = 123
.line	898	loadk        r20  k143 ; k143 = 92
.line	898	loadk        r21  k144 ; k144 = 238
.line	898	loadk        r22  k145 ; k145 = 170
.line	898	loadk        r23   k87 ; k87 = 152
.line	898	loadk        r24  k146 ; k146 = 165
.line	898	loadk        r25  k147 ; k147 = 157
.line	898	loadk        r26   k20 ; k20 = 106
.line	898	loadk        r27  k148 ; k148 = 163
.line	898	loadk        r28   k14 ; k14 = 69
.line	898	loadk        r29   k90 ; k90 = 42
.line	898	loadk        r30  k149 ; k149 = 119
.line	898	loadk        r31  k150 ; k150 = 154
.line	898	loadk        r32  k110 ; k110 = 84
.line	898	loadk        r33  k151 ; k151 = 200
.line	898	loadk        r34  k152 ; k152 = 11
.line	898	call         r11    24     2
.line	898	call         r10     2     2
.line	898	gettable     r11   r10  k153 ; k153 = "GetServerTimeInSec"
.line	898	call         r11     1     2
.line	898	gettabup     r12    u0  k139 ; k139 = "require"
.line	898	getupval     r13    u1
.line	898	loadk        r14   k31 ; k31 = 168
.line	898	loadk        r15   k72 ; k72 = 29
.line	898	call         r13     3     2
.line	898	call         r12     2     2
.line	898	gettable     r13   r12  k154 ; k154 = "option"
.line	898	getupval     r14    u1
.line	898	loadk        r15  k155 ; k155 = 189
.line	898	loadk        r16  k156 ; k156 = 17
.line	898	loadk        r17  k157 ; k157 = 45
.line	898	loadk        r18   k30 ; k30 = 178
.line	898	loadk        r19   k18 ; k18 = 143
.line	898	loadk        r20  k158 ; k158 = 240
.line	898	loadk        r21  k159 ; k159 = 100
.line	898	loadk        r22  k160 ; k160 = 71
.line	898	loadk        r23   k14 ; k14 = 69
.line	898	loadk        r24  k161 ; k161 = 226
.line	898	loadk        r25   k21 ; k21 = 171
.line	898	loadk        r26  k113 ; k113 = 130
.line	898	loadk        r27   k70 ; k70 = 174
.line	898	call         r14    14     2
.line	898	call         r13     2     1
.line	898	gettable     r13   r12  k162 ; k162 = "loadfile"
.line	898	getupval     r14    u1
.line	898	loadk        r15  k163 ; k163 = 188
.line	898	loadk        r16  k107 ; k107 = 12
.line	898	loadk        r17  k164 ; k164 = 7
.line	898	loadk        r18  k163 ; k163 = 188
.line	898	loadk        r19  k163 ; k163 = 188
.line	898	loadk        r20   k79 ; k79 = 248
.line	898	loadk        r21  k126 ; k126 = 114
.line	898	loadk        r22  k165 ; k165 = 118
.line	898	loadk        r23  k160 ; k160 = 71
.line	898	loadk        r24  k104 ; k104 = 172
.line	898	loadk        r25   k85 ; k85 = 166
.line	898	loadk        r26  k166 ; k166 = 158
.line	898	loadk        r27  k104 ; k104 = 172
.line	898	loadk        r28  k114 ; k114 = 208
.line	898	loadk        r29   k73 ; k73 = 65
.line	898	loadk        r30  k129 ; k129 = 185
.line	898	loadk        r31   k14 ; k14 = 69
.line	898	loadk        r32  k167 ; k167 = 46
.line	898	loadk        r33  k168 ; k168 = 90
.line	898	loadk        r34  k118 ; k118 = 155
.line	898	loadk        r35  k169 ; k169 = 127
.line	898	loadk        r36  k170 ; k170 = 207
.line	898	loadk        r37  k171 ; k171 = 23
.line	898	loadk        r38  k172 ; k172 = 75
.line	898	loadk        r39  k173 ; k173 = 124
.line	898	loadk        r40  k158 ; k158 = 240
.line	898	loadk        r41    k9 ; k9 = 187
.line	898	loadk        r42   k17 ; k17 = 142
.line	898	loadk        r43   k99 ; k99 = 190
.line	898	loadk        r44  k174 ; k174 = 205
.line	898	loadk        r45  k175 ; k175 = 122
.line	898	loadk        r46   k11 ; k11 = 244
.line	898	loadk        r47  k176 ; k176 = 72
.line	898	loadk        r48   k43 ; k43 = 61
.line	898	call         r14    35     2
.line	898	call         r13     2     1
.line	898	gettabup     r13    u0  k177 ; k177 = "tonumber"
.line	898	move         r14    r6
.line	898	call         r13     2     2
.line	898	test         r13     1
.line	898	jmp            0  l473
.line	898	loadk        r13  k178 ; k178 = 0
.label	l473
.line	898	le             0   r13  k178 ; k178 = 0
.line	898	jmp            0  l481
.line	898	gettabup     r14    u0  k177 ; k177 = "tonumber"
.line	898	gettable     r15    r0  k179 ; k179 = "DialogTargetUID"
.line	898	call         r14     2     2
.line	898	testset      r13   r14     1
.line	898	jmp            0  l481
.line	898	loadk        r13  k178 ; k178 = 0
.label	l481
.line	898	mul          r14   r11  k180 ; k180 = 10000
.line	898	gettable     r15    r9  k135 ; k135 = "AIGCRequestID"
.line	898	add          r14   r14   r15
.line	898	newtable     r15     0    13
.line	898	settable     r15  k181   r14 ; k181 = "request_id"
.line	898	settable     r15  k182    r1 ; k182 = "query"
.line	898	getupval     r16    u1
.line	898	loadk        r17  k184 ; k184 = 233
.line	898	call         r16     2     2
.line	898	settable     r15  k183   r16 ; k183 = "version"
.line	898	settable     r15  k185  k136 ; k136 = nil
.line	898	gettable     r16    r9  k187 ; k187 = "UID"
.line	898	settable     r15  k186   r16 ; k186 = "uid"
.line	898	settable     r15  k188    r2 ; k188 = "query_gen_type"
.line	898	gettable     r16    r0  k190 ; k190 = "PlatID"
.line	898	test         r16     1
.line	898	jmp            0  l499
.line	898	loadk        r16  k178 ; k178 = 0
.label	l499
.line	898	settable     r15  k189   r16 ; k189 = "plat_id"
.line	898	gettable     r16    r0  k137 ; k137 = "AreaID"
.line	898	test         r16     1
.line	898	jmp            0  l504
.line	898	loadk        r16  k178 ; k178 = 0
.label	l504
.line	898	settable     r15  k191   r16 ; k191 = "area_id"
.line	898	self         r16    r0  k193 ; k193 = "GetRegionID"
.line	898	call         r16     2     2
.line	898	settable     r15  k192   r16 ; k192 = "region_id"
.line	898	gettable     r16    r0  k195 ; k195 = "LangID"
.line	898	test         r16     1
.line	898	jmp            0  l512
.line	898	loadk        r16  k196 ; k196 = -1
.label	l512
.line	898	settable     r15  k194   r16 ; k194 = "lang_id"
.line	898	gettabup     r16    u0   k49 ; k49 = "tostring"
.line	898	testset      r17    r4     1
.line	898	jmp            0  l517
.line	898	move         r17   r14
.label	l517
.line	898	call         r16     2     2
.line	898	settable     r15  k197   r16 ; k197 = "session_name"
.line	898	settable     r15  k198    r5 ; k198 = "is_complaint"
.line	898	settable     r15  k199   r13 ; k199 = "target_uid"
.line	898	gettabup     r16    u0    k0 ; k0 = "print"
.line	898	gettabup     r17    u0    k1 ; k1 = "bWriteLog"
.line	898	test         r17     0
.line	898	jmp            0  l595
.line	898	gettabup     r17    u0    k2 ; k2 = "string"
.line	898	gettable     r17   r17    k3 ; k3 = "format"
.line	898	gettabup     r18    u0    k4 ; k4 = "table"
.line	898	gettable     r18   r18    k5 ; k5 = "concat"
.line	898	newtable     r19     1     0
.line	898	getupval     r20    u1
.line	898	loadk        r21   k51 ; k51 = 149
.line	898	loadk        r22   k52 ; k52 = 51
.line	898	loadk        r23   k39 ; k39 = 25
.line	898	loadk        r24   k53 ; k53 = 150
.line	898	loadk        r25   k54 ; k54 = 134
.line	898	loadk        r26   k55 ; k55 = 254
.line	898	loadk        r27   k22 ; k22 = 126
.line	898	loadk        r28   k12 ; k12 = 123
.line	898	loadk        r29   k56 ; k56 = 86
.line	898	loadk        r30   k57 ; k57 = 197
.line	898	loadk        r31   k58 ; k58 = 162
.line	898	loadk        r32   k53 ; k53 = 150
.line	898	loadk        r33   k33 ; k33 = 191
.line	898	loadk        r34   k59 ; k59 = 198
.line	898	loadk        r35   k40 ; k40 = 108
.line	898	loadk        r36   k60 ; k60 = 175
.line	898	loadk        r37   k61 ; k61 = 18
.line	898	loadk        r38   k62 ; k62 = 28
.line	898	loadk        r39   k63 ; k63 = 77
.line	898	loadk        r40   k64 ; k64 = 129
.line	898	loadk        r41   k65 ; k65 = 68
.line	898	loadk        r42   k66 ; k66 = 229
.line	898	loadk        r43   k26 ; k26 = 2
.line	898	loadk        r44   k65 ; k65 = 68
.line	898	loadk        r45   k67 ; k67 = 74
.line	898	loadk        r46   k66 ; k66 = 229
.line	898	loadk        r47   k30 ; k30 = 178
.line	898	loadk        r48   k51 ; k51 = 149
.line	898	loadk        r49   k58 ; k58 = 162
.line	898	loadk        r50   k68 ; k68 = 231
.line	898	loadk        r51   k69 ; k69 = 111
.line	898	loadk        r52   k70 ; k70 = 174
.line	898	loadk        r53   k71 ; k71 = 89
.line	898	loadk        r54   k72 ; k72 = 29
.line	898	loadk        r55   k73 ; k73 = 65
.line	898	loadk        r56   k74 ; k74 = 169
.line	898	loadk        r57   k75 ; k75 = 95
.line	898	loadk        r58   k76 ; k76 = 216
.line	898	loadk        r59   k77 ; k77 = 20
.line	898	loadk        r60   k78 ; k78 = 93
.line	898	call         r20    41     2
.line	898	getupval     r21    u1
.line	898	loadk        r22   k11 ; k11 = 244
.line	898	loadk        r23   k75 ; k75 = 95
.line	898	loadk        r24  k200 ; k200 = 44
.line	898	loadk        r25   k99 ; k99 = 190
.line	898	loadk        r26   k58 ; k58 = 162
.line	898	loadk        r27  k201 ; k201 = 246
.line	898	loadk        r28  k126 ; k126 = 114
.line	898	loadk        r29   k40 ; k40 = 108
.line	898	loadk        r30   k40 ; k40 = 108
.line	898	loadk        r31  k201 ; k201 = 246
.line	898	loadk        r32   k70 ; k70 = 174
.line	898	loadk        r33  k202 ; k202 = 147
.line	898	loadk        r34  k203 ; k203 = 241
.line	898	loadk        r35   k53 ; k53 = 150
.line	898	loadk        r36  k204 ; k204 = 109
.line	898	call         r21    16     0
.line	898	setlist      r19     0     1
.line	898	call         r18     2     2
.line	898	gettabup     r19    u0   k49 ; k49 = "tostring"
.line	898	move         r20   r13
.line	898	call         r19     2     0
.line	898	call         r17     0     2
.label	l595
.line	898	call         r16     2     1
.line	898	gettable     r16    r9  k135 ; k135 = "AIGCRequestID"
.line	898	add          r16   r16  k106 ; k106 = 1
.line	898	settable      r9  k135   r16 ; k135 = "AIGCRequestID"
.line	898	gettable     r16    r9  k135 ; k135 = "AIGCRequestID"
.line	898	mod          r16   r16  k180 ; k180 = 10000
.line	898	settable      r9  k135   r16 ; k135 = "AIGCRequestID"
.line	898	gettable     r16   r12  k205 ; k205 = "encode"
.line	898	getupval     r17    u1
.line	898	loadk        r18   k21 ; k21 = 171
.line	898	loadk        r19   k61 ; k61 = 18
.line	898	loadk        r20  k142 ; k142 = 57
.line	898	loadk        r21  k206 ; k206 = 173
.line	898	loadk        r22  k100 ; k100 = 164
.line	898	loadk        r23  k207 ; k207 = 206
.line	898	loadk        r24  k208 ; k208 = 121
.line	898	loadk        r25  k209 ; k209 = 104
.line	898	loadk        r26   k28 ; k28 = 80
.line	898	loadk        r27  k130 ; k130 = 220
.line	898	loadk        r28  k100 ; k100 = 164
.line	898	loadk        r29  k118 ; k118 = 155
.line	898	loadk        r30   k58 ; k58 = 162
.line	898	loadk        r31   k88 ; k88 = 214
.line	898	loadk        r32   k89 ; k89 = 112
.line	898	loadk        r33   k99 ; k99 = 190
.line	898	loadk        r34  k210 ; k210 = 6
.line	898	loadk        r35  k211 ; k211 = 14
.line	898	loadk        r36   k82 ; k82 = 97
.line	898	loadk        r37   k31 ; k31 = 168
.line	898	loadk        r38  k212 ; k212 = 99
.line	898	loadk        r39  k213 ; k213 = 243
.line	898	loadk        r40   k26 ; k26 = 2
.line	898	loadk        r41   k71 ; k71 = 89
.line	898	loadk        r42   k56 ; k56 = 86
.line	898	loadk        r43  k201 ; k201 = 246
.line	898	loadk        r44  k100 ; k100 = 164
.line	898	loadk        r45  k202 ; k202 = 147
.line	898	call         r17    29     2
.line	898	move         r18   r15
.line	898	call         r16     3     2
.line	898	gettabup     r17    u0  k122 ; k122 = "slua"
.line	898	gettable     r17   r17  k123 ; k123 = "isValid"
.line	898	gettable     r18    r0  k214 ; k214 = "AntsVoiceInterface"
.line	898	call         r17     2     2
.line	898	test         r17     0
.line	898	jmp            0  l675
.line	898	gettable     r17    r0  k214 ; k214 = "AntsVoiceInterface"
.line	898	self         r17   r17  k215 ; k215 = "SetDeliverData"
.line	898	move         r19   r16
.line	898	len          r20   r16
.line	898	call         r17     4     1
.line	898	gettabup     r17    u0  k216 ; k216 = "log_tree"
.line	898	getupval     r18    u1
.line	898	loadk        r19    k6 ; k6 = 139
.line	898	loadk        r20    k7 ; k7 = 26
.line	898	loadk        r21    k8 ; k8 = 54
.line	898	loadk        r22    k9 ; k9 = 187
.line	898	loadk        r23  k158 ; k158 = 240
.line	898	loadk        r24  k114 ; k114 = 208
.line	898	loadk        r25  k217 ; k217 = 94
.line	898	loadk        r26   k75 ; k75 = 95
.line	898	loadk        r27   k89 ; k89 = 112
.line	898	loadk        r28  k218 ; k218 = 209
.line	898	loadk        r29   k58 ; k58 = 162
.line	898	loadk        r30   k54 ; k54 = 134
.line	898	loadk        r31   k99 ; k99 = 190
.line	898	loadk        r32   k88 ; k88 = 214
.line	898	loadk        r33  k204 ; k204 = 109
.line	898	loadk        r34   k99 ; k99 = 190
.line	898	call         r18    17     2
.line	898	move         r19   r15
.line	898	call         r17     3     1
.line	898	test          r7     1
.line	898	jmp            0  l675
.line	898	self         r17    r0  k219 ; k219 = "_AddAIDialogContext"
.line	898	gettable     r19    r9  k220 ; k220 = "PlayerName"
.line	898	move         r20   r13
.line	898	move         r21    r1
.line	898	loadbool     r22     1     0
.line	898	call         r17     6     1
.label	l675
.line	898	return        r0     1
.line	898	move          r0    r0
.line	898	gettabup      r1    u0  k135 ; k135 = "AIGCRequestID"
.line	898	return        r0     1

.function	main/f52

.source	null
.linedefined	962
.lastlinedefined	977
.numparams	2
.is_vararg	0
.maxstacksize	17

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"GetPlayerCharacterSafety"
.constant	k1	"slua"
.constant	k2	"isValid"
.constant	k3	"GetSecuryComponent"
.constant	k4	"PlatID"
.constant	k5	"GameBaseInfo"
.constant	k6	"import"
.constant	k7	145
.constant	k8	50
.constant	k9	11
.constant	k10	155
.constant	k11	217
.constant	k12	114
.constant	k13	116
.constant	k14	67
.constant	k15	230
.constant	k16	181
.constant	k17	nil
.constant	k18	"GetInstance"
.constant	k19	"AreaID"
.constant	k20	"ConvertTConndChannel2IMSDKChannel"

.line	962	self          r2    r1    k0 ; k0 = "GetPlayerCharacterSa" (truncated)
.line	962	call          r2     2     2
.line	962	gettabup      r3    u0    k1 ; k1 = "slua"
.line	962	gettable      r3    r3    k2 ; k2 = "isValid"
.line	962	move          r4    r2
.line	962	call          r3     2     2
.line	962	test          r3     0
.line	962	jmp            0   l50
.line	962	self          r3    r2    k3 ; k3 = "GetSecuryComponent"
.line	962	call          r3     2     2
.line	962	gettabup      r4    u0    k1 ; k1 = "slua"
.line	962	gettable      r4    r4    k2 ; k2 = "isValid"
.line	962	move          r5    r3
.line	962	call          r4     2     2
.line	962	test          r4     0
.line	962	jmp            0   l50
.line	962	gettable      r4    r3    k5 ; k5 = "GameBaseInfo"
.line	962	gettable      r4    r4    k4 ; k4 = "PlatID"
.line	962	settable      r0    k4    r4 ; k4 = "PlatID"
.line	962	gettabup      r4    u0    k6 ; k6 = "import"
.line	962	getupval      r5    u1
.line	962	loadk         r6    k7 ; k7 = 145
.line	962	loadk         r7    k8 ; k8 = 50
.line	962	loadk         r8    k9 ; k9 = 11
.line	962	loadk         r9   k10 ; k10 = 155
.line	962	loadk        r10   k10 ; k10 = 155
.line	962	loadk        r11   k11 ; k11 = 217
.line	962	loadk        r12   k12 ; k12 = 114
.line	962	loadk        r13   k13 ; k13 = 116
.line	962	loadk        r14   k14 ; k14 = 67
.line	962	loadk        r15   k15 ; k15 = 230
.line	962	loadk        r16   k16 ; k16 = 181
.line	962	call          r5    12     2
.line	962	call          r4     2     2
.line	962	eq             1    r4   k17 ; k17 = nil
.line	962	jmp            0   l50
.line	962	gettable      r5    r4   k18 ; k18 = "GetInstance"
.line	962	call          r5     1     2
.line	962	gettabup      r6    u0    k1 ; k1 = "slua"
.line	962	gettable      r6    r6    k2 ; k2 = "isValid"
.line	962	move          r7    r5
.line	962	call          r6     2     2
.line	962	test          r6     0
.line	962	jmp            0   l50
.line	962	self          r6    r5   k20 ; k20 = "ConvertTConndChannel" (truncated)
.line	962	gettable      r8    r3    k5 ; k5 = "GameBaseInfo"
.line	962	gettable      r8    r8   k19 ; k19 = "AreaID"
.line	962	call          r6     3     2
.line	962	settable      r0   k19    r6 ; k19 = "AreaID"
.label	l50
.line	962	return        r0     1
.line	962	move          r0    r0
.line	962	move          r0    r0
.line	962	return        r0     1

.function	main/f53

.source	null
.linedefined	979
.lastlinedefined	982
.numparams	4
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"bSpeechToTextState"
.constant	k1	"print"
.constant	k2	"bWriteLog"
.constant	k3	"string"
.constant	k4	"format"
.constant	k5	"table"
.constant	k6	"concat"
.constant	k7	149
.constant	k8	51
.constant	k9	25
.constant	k10	150
.constant	k11	134
.constant	k12	254
.constant	k13	126
.constant	k14	123
.constant	k15	86
.constant	k16	197
.constant	k17	162
.constant	k18	191
.constant	k19	198
.constant	k20	108
.constant	k21	175
.constant	k22	18
.constant	k23	0
.constant	k24	70
.constant	k25	188
.constant	k26	116
.constant	k27	245
.constant	k28	52
.constant	k29	92
.constant	k30	66
.constant	k31	231
.constant	k32	178
.constant	k33	164
.constant	k34	179
.constant	k35	194
.constant	k36	96
.constant	k37	189
.constant	k38	93
.constant	k39	115
.constant	k40	24
.constant	k41	157
.constant	k42	127
.constant	k43	193
.constant	k44	226
.constant	k45	90
.constant	k46	43
.constant	k47	"tostring"

.line	979	settable      r0    k0    r3 ; k0 = "bSpeechToTextState"
.line	979	gettabup      r4    u0    k1 ; k1 = "print"
.line	979	gettabup      r5    u0    k2 ; k2 = "bWriteLog"
.line	979	test          r5     0
.line	979	jmp            0   l64
.line	979	gettabup      r5    u0    k3 ; k3 = "string"
.line	979	gettable      r5    r5    k4 ; k4 = "format"
.line	979	gettabup      r6    u0    k5 ; k5 = "table"
.line	979	gettable      r6    r6    k6 ; k6 = "concat"
.line	979	newtable      r7     1     0
.line	979	getupval      r8    u1
.line	979	loadk         r9    k7 ; k7 = 149
.line	979	loadk        r10    k8 ; k8 = 51
.line	979	loadk        r11    k9 ; k9 = 25
.line	979	loadk        r12   k10 ; k10 = 150
.line	979	loadk        r13   k11 ; k11 = 134
.line	979	loadk        r14   k12 ; k12 = 254
.line	979	loadk        r15   k13 ; k13 = 126
.line	979	loadk        r16   k14 ; k14 = 123
.line	979	loadk        r17   k15 ; k15 = 86
.line	979	loadk        r18   k16 ; k16 = 197
.line	979	loadk        r19   k17 ; k17 = 162
.line	979	loadk        r20   k10 ; k10 = 150
.line	979	loadk        r21   k18 ; k18 = 191
.line	979	loadk        r22   k19 ; k19 = 198
.line	979	loadk        r23   k20 ; k20 = 108
.line	979	loadk        r24   k21 ; k21 = 175
.line	979	loadk        r25   k22 ; k22 = 18
.line	979	loadk        r26   k23 ; k23 = 0
.line	979	loadk        r27   k24 ; k24 = 70
.line	979	loadk        r28   k25 ; k25 = 188
.line	979	loadk        r29   k26 ; k26 = 116
.line	979	loadk        r30   k27 ; k27 = 245
.line	979	loadk        r31   k28 ; k28 = 52
.line	979	loadk        r32   k29 ; k29 = 92
.line	979	loadk        r33   k30 ; k30 = 66
.line	979	loadk        r34   k31 ; k31 = 231
.line	979	loadk        r35   k32 ; k32 = 178
.line	979	loadk        r36   k33 ; k33 = 164
.line	979	loadk        r37   k34 ; k34 = 179
.line	979	loadk        r38   k35 ; k35 = 194
.line	979	loadk        r39   k36 ; k36 = 96
.line	979	loadk        r40   k37 ; k37 = 189
.line	979	loadk        r41   k38 ; k38 = 93
.line	979	loadk        r42   k39 ; k39 = 115
.line	979	loadk        r43   k40 ; k40 = 24
.line	979	loadk        r44   k41 ; k41 = 157
.line	979	loadk        r45   k42 ; k42 = 127
.line	979	loadk        r46   k43 ; k43 = 193
.line	979	loadk        r47   k22 ; k22 = 18
.line	979	loadk        r48   k15 ; k15 = 86
.line	979	call          r8    41     2
.line	979	getupval      r9    u1
.line	979	loadk        r10   k44 ; k44 = 226
.line	979	loadk        r11   k45 ; k45 = 90
.line	979	loadk        r12   k46 ; k46 = 43
.line	979	call          r9     4     0
.line	979	setlist       r7     0     1
.line	979	call          r6     2     2
.line	979	gettabup      r7    u0   k47 ; k47 = "tostring"
.line	979	move          r8    r3
.line	979	call          r7     2     0
.line	979	call          r5     0     2
.label	l64
.line	979	call          r4     2     1
.line	979	return        r0     1
.line	979	move          r0    r0
.line	979	move          r0    r0
.line	979	move          r0    r0
.line	979	move          r0    r0
.line	979	return        r0     1

.function	main/f54

.source	null
.linedefined	984
.lastlinedefined	1043
.numparams	4
.is_vararg	0
.maxstacksize	55

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	0
.constant	k23	70
.constant	k24	171
.constant	k25	69
.constant	k26	205
.constant	k27	14
.constant	k28	94
.constant	k29	225
.constant	k30	147
.constant	k31	194
.constant	k32	77
.constant	k33	187
.constant	k34	84
.constant	k35	90
.constant	k36	158
.constant	k37	83
.constant	k38	218
.constant	k39	91
.constant	k40	24
.constant	k41	182
.constant	k42	61
.constant	k43	177
.constant	k44	234
.constant	k45	180
.constant	k46	100
.constant	k47	52
.constant	k48	19
.constant	k49	240
.constant	k50	136
.constant	k51	135
.constant	k52	174
.constant	k53	221
.constant	k54	87
.constant	k55	142
.constant	k56	106
.constant	k57	"tostring"
.constant	k58	"GetTeammatePlayerStateByOpenID"
.constant	k59	"slua"
.constant	k60	"isValid"
.constant	k61	"GetNeutralNPCUIDByOpenID"
.constant	k62	"nMasterIndex"
.constant	k63	"require"
.constant	k64	168
.constant	k65	29
.constant	k66	"option"
.constant	k67	189
.constant	k68	17
.constant	k69	45
.constant	k70	178
.constant	k71	143
.constant	k72	71
.constant	k73	226
.constant	k74	130
.constant	k75	"loadfile"
.constant	k76	188
.constant	k77	12
.constant	k78	7
.constant	k79	248
.constant	k80	114
.constant	k81	118
.constant	k82	172
.constant	k83	166
.constant	k84	208
.constant	k85	65
.constant	k86	185
.constant	k87	46
.constant	k88	155
.constant	k89	127
.constant	k90	207
.constant	k91	23
.constant	k92	75
.constant	k93	124
.constant	k94	190
.constant	k95	122
.constant	k96	244
.constant	k97	72
.constant	k98	"decode"
.constant	k99	57
.constant	k100	173
.constant	k101	164
.constant	k102	206
.constant	k103	121
.constant	k104	104
.constant	k105	80
.constant	k106	220
.constant	k107	214
.constant	k108	112
.constant	k109	6
.constant	k110	97
.constant	k111	99
.constant	k112	243
.constant	k113	2
.constant	k114	252
.constant	k115	148
.constant	k116	"log_tree"
.constant	k117	145
.constant	k118	56
.constant	k119	27
.constant	k120	141
.constant	k121	181
.constant	k122	103
.constant	k123	119
.constant	k124	93
.constant	k125	"audio_id"
.constant	k126	"audio_duration"
.constant	k127	49
.constant	k128	186
.constant	k129	229
.constant	k130	117
.constant	k131	92
.constant	k132	231
.constant	k133	236
.constant	k134	120
.constant	k135	184
.constant	k136	73
.constant	k137	34
.constant	k138	152
.constant	k139	79
.constant	k140	211
.constant	k141	110
.constant	k142	179
.constant	k143	146
.constant	k144	183
.constant	k145	67
.constant	k146	62
.constant	k147	95
.constant	k148	154
.constant	k149	66
.constant	k150	"GetModule"
.constant	k151	"CommonModuleConfig"
.constant	k152	"logic_chat_voice"
.constant	k153	"permanent"
.constant	k154	true
.constant	k155	"OpenID"
.constant	k156	"FileID"
.constant	k157	"Duration"
.constant	k158	"bSkipTips"
.constant	k159	"bOnlyFightingState"
.constant	k160	"VoiceVolume"
.constant	k161	"_ResolveVoiceMessageVolume"
.constant	k162	nil
.constant	k163	"VoiceFileDownloadRecord"
.constant	k164	"OnDownloadFileEnd"
.constant	k165	"Game"
.constant	k166	"ClearTimer"
.constant	k167	"Timer"
.constant	k168	"Owner"
.constant	k169	"Object"
.constant	k170	"PlayerState"
.constant	k171	"UID"
.constant	k172	"SenderUID"
.constant	k173	"DownloadState"
.constant	k174	"PlayResult"
.constant	k175	"SessionName"
.constant	k176	"session_name"
.constant	k177	"AddGameTimer"
.constant	k178	"TryStopPlayRecordVoice"
.constant	k179	"PlayVoiceFile"
.constant	k180	"audio_id"
.constant	k181	153
.constant	k182	54
.constant	k183	31
.constant	k184	156
.constant	k185	237
.constant	k186	210
.constant	k187	107
.constant	k188	32
.constant	k189	68
.constant	k190	129
.constant	k191	3
.constant	k192	246
.constant	k193	151
.constant	k194	235
.constant	k195	109
.constant	k196	38
.constant	k197	26
.constant	k198	227
.constant	k199	55
.constant	k200	113
.constant	k201	64
.constant	k202	163
.constant	k203	169
.constant	k204	199
.constant	k205	111
.constant	k206	138
.constant	k207	204
.constant	k208	10
.constant	k209	251
.constant	k210	59
.constant	k211	81
.constant	k212	222
.constant	k213	16
.constant	k214	125
.constant	k215	132

.line	984	gettabup      r4    u0    k0 ; k0 = "print"
.line	984	gettabup      r5    u0    k1 ; k1 = "bWriteLog"
.line	984	test          r5     0
.line	984	jmp            0   l82
.line	984	gettabup      r5    u0    k2 ; k2 = "string"
.line	984	gettable      r5    r5    k3 ; k3 = "format"
.line	984	gettabup      r6    u0    k4 ; k4 = "table"
.line	984	gettable      r6    r6    k5 ; k5 = "concat"
.line	984	newtable      r7     1     0
.line	984	getupval      r8    u1
.line	984	loadk         r9    k6 ; k6 = 149
.line	984	loadk        r10    k7 ; k7 = 51
.line	984	loadk        r11    k8 ; k8 = 25
.line	984	loadk        r12    k9 ; k9 = 150
.line	984	loadk        r13   k10 ; k10 = 134
.line	984	loadk        r14   k11 ; k11 = 254
.line	984	loadk        r15   k12 ; k12 = 126
.line	984	loadk        r16   k13 ; k13 = 123
.line	984	loadk        r17   k14 ; k14 = 86
.line	984	loadk        r18   k15 ; k15 = 197
.line	984	loadk        r19   k16 ; k16 = 162
.line	984	loadk        r20    k9 ; k9 = 150
.line	984	loadk        r21   k17 ; k17 = 191
.line	984	loadk        r22   k18 ; k18 = 198
.line	984	loadk        r23   k19 ; k19 = 108
.line	984	loadk        r24   k20 ; k20 = 175
.line	984	loadk        r25   k21 ; k21 = 18
.line	984	loadk        r26   k22 ; k22 = 0
.line	984	loadk        r27   k23 ; k23 = 70
.line	984	loadk        r28   k24 ; k24 = 171
.line	984	loadk        r29   k25 ; k25 = 69
.line	984	loadk        r30   k26 ; k26 = 205
.line	984	loadk        r31   k27 ; k27 = 14
.line	984	loadk        r32   k28 ; k28 = 94
.line	984	loadk        r33   k23 ; k23 = 70
.line	984	loadk        r34   k29 ; k29 = 225
.line	984	loadk        r35   k30 ; k30 = 147
.line	984	loadk        r36   k10 ; k10 = 134
.line	984	loadk        r37   k20 ; k20 = 175
.line	984	loadk        r38   k31 ; k31 = 194
.line	984	loadk        r39   k32 ; k32 = 77
.line	984	loadk        r40   k33 ; k33 = 187
.line	984	loadk        r41   k34 ; k34 = 84
.line	984	loadk        r42    k7 ; k7 = 51
.line	984	loadk        r43   k35 ; k35 = 90
.line	984	loadk        r44   k36 ; k36 = 158
.line	984	loadk        r45   k37 ; k37 = 83
.line	984	loadk        r46   k38 ; k38 = 218
.line	984	loadk        r47   k39 ; k39 = 91
.line	984	loadk        r48   k40 ; k40 = 24
.line	984	call          r8    41     2
.line	984	getupval      r9    u1
.line	984	loadk        r10   k41 ; k41 = 182
.line	984	loadk        r11    k7 ; k7 = 51
.line	984	loadk        r12   k42 ; k42 = 61
.line	984	loadk        r13   k43 ; k43 = 177
.line	984	loadk        r14   k44 ; k44 = 234
.line	984	loadk        r15   k45 ; k45 = 180
.line	984	loadk        r16   k46 ; k46 = 100
.line	984	loadk        r17   k47 ; k47 = 52
.line	984	loadk        r18   k48 ; k48 = 19
.line	984	loadk        r19   k49 ; k49 = 240
.line	984	loadk        r20   k50 ; k50 = 136
.line	984	loadk        r21   k51 ; k51 = 135
.line	984	loadk        r22   k52 ; k52 = 174
.line	984	loadk        r23   k53 ; k53 = 221
.line	984	loadk        r24   k54 ; k54 = 87
.line	984	loadk        r25   k55 ; k55 = 142
.line	984	loadk        r26   k21 ; k21 = 18
.line	984	loadk        r27   k56 ; k56 = 106
.line	984	loadk        r28   k39 ; k39 = 91
.line	984	call          r9    20     0
.line	984	setlist       r7     0     1
.line	984	call          r6     2     2
.line	984	gettabup      r7    u0   k57 ; k57 = "tostring"
.line	984	move          r8    r2
.line	984	call          r7     2     2
.line	984	gettabup      r8    u0   k57 ; k57 = "tostring"
.line	984	move          r9    r3
.line	984	call          r8     2     0
.line	984	call          r5     0     2
.label	l82
.line	984	call          r4     2     1
.line	984	self          r4    r0   k58 ; k58 = "GetTeammatePlayerSta" (truncated)
.line	984	move          r6    r3
.line	984	call          r4     3     2
.line	984	loadnil       r5     0
.line	984	gettabup      r6    u0   k59 ; k59 = "slua"
.line	984	gettable      r6    r6   k60 ; k60 = "isValid"
.line	984	move          r7    r4
.line	984	call          r6     2     2
.line	984	test          r6     1
.line	984	jmp            0   l97
.line	984	self          r6    r0   k61 ; k61 = "GetNeutralNPCUIDByOp" (truncated)
.line	984	move          r8    r3
.line	984	call          r6     3     2
.line	984	move          r5    r6
.label	l97
.line	984	gettabup      r6    u0   k59 ; k59 = "slua"
.line	984	gettable      r6    r6   k60 ; k60 = "isValid"
.line	984	move          r7    r4
.line	984	call          r6     2     2
.line	984	test          r6     0
.line	984	jmp            0  l109
.line	984	gettable      r6    r4   k62 ; k62 = "nMasterIndex"
.line	984	test          r6     0
.line	984	jmp            0  l109
.line	984	gettable      r6    r4   k62 ; k62 = "nMasterIndex"
.line	984	le             1   k22    r6 ; k22 = 0
.line	984	jmp            0  l111
.label	l109
.line	984	test          r5     0
.line	984	jmp            0  l579
.label	l111
.line	984	gettabup      r6    u0   k63 ; k63 = "require"
.line	984	getupval      r7    u1
.line	984	loadk         r8   k64 ; k64 = 168
.line	984	loadk         r9   k65 ; k65 = 29
.line	984	call          r7     3     2
.line	984	call          r6     2     2
.line	984	gettable      r7    r6   k66 ; k66 = "option"
.line	984	getupval      r8    u1
.line	984	loadk         r9   k67 ; k67 = 189
.line	984	loadk        r10   k68 ; k68 = 17
.line	984	loadk        r11   k69 ; k69 = 45
.line	984	loadk        r12   k70 ; k70 = 178
.line	984	loadk        r13   k71 ; k71 = 143
.line	984	loadk        r14   k49 ; k49 = 240
.line	984	loadk        r15   k46 ; k46 = 100
.line	984	loadk        r16   k72 ; k72 = 71
.line	984	loadk        r17   k25 ; k25 = 69
.line	984	loadk        r18   k73 ; k73 = 226
.line	984	loadk        r19   k24 ; k24 = 171
.line	984	loadk        r20   k74 ; k74 = 130
.line	984	loadk        r21   k52 ; k52 = 174
.line	984	call          r8    14     2
.line	984	call          r7     2     1
.line	984	gettable      r7    r6   k75 ; k75 = "loadfile"
.line	984	getupval      r8    u1
.line	984	loadk         r9   k76 ; k76 = 188
.line	984	loadk        r10   k77 ; k77 = 12
.line	984	loadk        r11   k78 ; k78 = 7
.line	984	loadk        r12   k76 ; k76 = 188
.line	984	loadk        r13   k76 ; k76 = 188
.line	984	loadk        r14   k79 ; k79 = 248
.line	984	loadk        r15   k80 ; k80 = 114
.line	984	loadk        r16   k81 ; k81 = 118
.line	984	loadk        r17   k72 ; k72 = 71
.line	984	loadk        r18   k82 ; k82 = 172
.line	984	loadk        r19   k83 ; k83 = 166
.line	984	loadk        r20   k36 ; k36 = 158
.line	984	loadk        r21   k82 ; k82 = 172
.line	984	loadk        r22   k84 ; k84 = 208
.line	984	loadk        r23   k85 ; k85 = 65
.line	984	loadk        r24   k86 ; k86 = 185
.line	984	loadk        r25   k25 ; k25 = 69
.line	984	loadk        r26   k87 ; k87 = 46
.line	984	loadk        r27   k35 ; k35 = 90
.line	984	loadk        r28   k88 ; k88 = 155
.line	984	loadk        r29   k89 ; k89 = 127
.line	984	loadk        r30   k90 ; k90 = 207
.line	984	loadk        r31   k91 ; k91 = 23
.line	984	loadk        r32   k92 ; k92 = 75
.line	984	loadk        r33   k93 ; k93 = 124
.line	984	loadk        r34   k49 ; k49 = 240
.line	984	loadk        r35   k33 ; k33 = 187
.line	984	loadk        r36   k55 ; k55 = 142
.line	984	loadk        r37   k94 ; k94 = 190
.line	984	loadk        r38   k26 ; k26 = 205
.line	984	loadk        r39   k95 ; k95 = 122
.line	984	loadk        r40   k96 ; k96 = 244
.line	984	loadk        r41   k97 ; k97 = 72
.line	984	loadk        r42   k42 ; k42 = 61
.line	984	call          r8    35     2
.line	984	call          r7     2     1
.line	984	gettable      r7    r6   k98 ; k98 = "decode"
.line	984	getupval      r8    u1
.line	984	loadk         r9   k24 ; k24 = 171
.line	984	loadk        r10   k21 ; k21 = 18
.line	984	loadk        r11   k99 ; k99 = 57
.line	984	loadk        r12  k100 ; k100 = 173
.line	984	loadk        r13  k101 ; k101 = 164
.line	984	loadk        r14  k102 ; k102 = 206
.line	984	loadk        r15  k103 ; k103 = 121
.line	984	loadk        r16  k104 ; k104 = 104
.line	984	loadk        r17  k105 ; k105 = 80
.line	984	loadk        r18  k106 ; k106 = 220
.line	984	loadk        r19  k101 ; k101 = 164
.line	984	loadk        r20   k88 ; k88 = 155
.line	984	loadk        r21   k16 ; k16 = 162
.line	984	loadk        r22  k107 ; k107 = 214
.line	984	loadk        r23  k108 ; k108 = 112
.line	984	loadk        r24   k94 ; k94 = 190
.line	984	loadk        r25  k109 ; k109 = 6
.line	984	loadk        r26   k27 ; k27 = 14
.line	984	loadk        r27  k110 ; k110 = 97
.line	984	loadk        r28   k64 ; k64 = 168
.line	984	loadk        r29  k111 ; k111 = 99
.line	984	loadk        r30  k112 ; k112 = 243
.line	984	loadk        r31  k113 ; k113 = 2
.line	984	loadk        r32   k39 ; k39 = 91
.line	984	loadk        r33   k37 ; k37 = 83
.line	984	loadk        r34  k114 ; k114 = 252
.line	984	loadk        r35   k86 ; k86 = 185
.line	984	loadk        r36  k115 ; k115 = 148
.line	984	loadk        r37   k94 ; k94 = 190
.line	984	call          r8    30     2
.line	984	move          r9    r1
.line	984	call          r7     3     2
.line	984	test          r7     0
.line	984	jmp            0  l504
.line	984	gettabup      r8    u0  k116 ; k116 = "log_tree"
.line	984	gettabup      r9    u0    k4 ; k4 = "table"
.line	984	gettable      r9    r9    k5 ; k5 = "concat"
.line	984	newtable     r10     1     0
.line	984	getupval     r11    u1
.line	984	loadk        r12    k6 ; k6 = 149
.line	984	loadk        r13    k7 ; k7 = 51
.line	984	loadk        r14    k8 ; k8 = 25
.line	984	loadk        r15    k9 ; k9 = 150
.line	984	loadk        r16   k10 ; k10 = 134
.line	984	loadk        r17   k11 ; k11 = 254
.line	984	loadk        r18   k12 ; k12 = 126
.line	984	loadk        r19   k13 ; k13 = 123
.line	984	loadk        r20   k14 ; k14 = 86
.line	984	loadk        r21   k15 ; k15 = 197
.line	984	loadk        r22   k16 ; k16 = 162
.line	984	loadk        r23    k9 ; k9 = 150
.line	984	loadk        r24   k17 ; k17 = 191
.line	984	loadk        r25   k18 ; k18 = 198
.line	984	loadk        r26   k19 ; k19 = 108
.line	984	loadk        r27   k20 ; k20 = 175
.line	984	loadk        r28   k21 ; k21 = 18
.line	984	loadk        r29   k22 ; k22 = 0
.line	984	loadk        r30   k23 ; k23 = 70
.line	984	loadk        r31   k24 ; k24 = 171
.line	984	loadk        r32   k25 ; k25 = 69
.line	984	loadk        r33   k26 ; k26 = 205
.line	984	loadk        r34   k27 ; k27 = 14
.line	984	loadk        r35   k28 ; k28 = 94
.line	984	loadk        r36   k23 ; k23 = 70
.line	984	loadk        r37   k29 ; k29 = 225
.line	984	loadk        r38   k30 ; k30 = 147
.line	984	loadk        r39   k10 ; k10 = 134
.line	984	loadk        r40   k20 ; k20 = 175
.line	984	loadk        r41   k31 ; k31 = 194
.line	984	loadk        r42   k32 ; k32 = 77
.line	984	loadk        r43   k33 ; k33 = 187
.line	984	loadk        r44   k34 ; k34 = 84
.line	984	loadk        r45    k7 ; k7 = 51
.line	984	loadk        r46   k35 ; k35 = 90
.line	984	loadk        r47   k36 ; k36 = 158
.line	984	loadk        r48   k37 ; k37 = 83
.line	984	loadk        r49   k38 ; k38 = 218
.line	984	loadk        r50   k54 ; k54 = 87
.line	984	loadk        r51  k103 ; k103 = 121
.line	984	call         r11    41     2
.line	984	getupval     r12    u1
.line	984	loadk        r13  k117 ; k117 = 145
.line	984	loadk        r14  k118 ; k118 = 56
.line	984	loadk        r15  k119 ; k119 = 27
.line	984	loadk        r16  k120 ; k120 = 141
.line	984	loadk        r17  k121 ; k121 = 181
.line	984	loadk        r18   k73 ; k73 = 226
.line	984	loadk        r19  k122 ; k122 = 103
.line	984	loadk        r20  k123 ; k123 = 119
.line	984	loadk        r21  k124 ; k124 = 93
.line	984	loadk        r22   k49 ; k49 = 240
.line	984	loadk        r23   k16 ; k16 = 162
.line	984	call         r12    12     0
.line	984	setlist      r10     0     1
.line	984	call          r9     2     2
.line	984	move         r10    r7
.line	984	call          r8     3     1
.line	984	gettable      r8    r7  k125 ; k125 = "audio_id"
.line	984	test          r8     0
.line	984	jmp            7  l686
.line	984	gettable      r8    r7  k126 ; k126 = "audio_duration"
.line	984	test          r8     0
.line	984	jmp            7  l686
.line	984	gettabup      r8    u0   k63 ; k63 = "require"
.line	984	getupval      r9    u1
.line	984	loadk        r10   k33 ; k33 = 187
.line	984	loadk        r11   k48 ; k48 = 19
.line	984	loadk        r12  k127 ; k127 = 49
.line	984	loadk        r13  k128 ; k128 = 186
.line	984	loadk        r14   k94 ; k94 = 190
.line	984	loadk        r15  k129 ; k129 = 229
.line	984	loadk        r16   k99 ; k99 = 57
.line	984	loadk        r17  k130 ; k130 = 117
.line	984	loadk        r18  k131 ; k131 = 92
.line	984	loadk        r19  k132 ; k132 = 231
.line	984	loadk        r20   k70 ; k70 = 178
.line	984	loadk        r21   k88 ; k88 = 155
.line	984	loadk        r22   k52 ; k52 = 174
.line	984	loadk        r23  k133 ; k133 = 236
.line	984	loadk        r24  k134 ; k134 = 120
.line	984	loadk        r25  k135 ; k135 = 184
.line	984	loadk        r26  k136 ; k136 = 73
.line	984	loadk        r27  k137 ; k137 = 34
.line	984	loadk        r28   k32 ; k32 = 77
.line	984	loadk        r29  k138 ; k138 = 152
.line	984	loadk        r30  k139 ; k139 = 79
.line	984	loadk        r31  k140 ; k140 = 211
.line	984	loadk        r32   k77 ; k77 = 12
.line	984	loadk        r33  k109 ; k109 = 6
.line	984	loadk        r34  k141 ; k141 = 110
.line	984	loadk        r35  k114 ; k114 = 252
.line	984	loadk        r36  k142 ; k142 = 179
.line	984	loadk        r37  k143 ; k143 = 146
.line	984	loadk        r38  k144 ; k144 = 183
.line	984	loadk        r39   k18 ; k18 = 198
.line	984	loadk        r40  k145 ; k145 = 67
.line	984	loadk        r41   k33 ; k33 = 187
.line	984	loadk        r42   k14 ; k14 = 86
.line	984	loadk        r43  k146 ; k146 = 62
.line	984	loadk        r44  k147 ; k147 = 95
.line	984	loadk        r45  k148 ; k148 = 154
.line	984	loadk        r46  k149 ; k149 = 66
.line	984	call          r9    38     2
.line	984	call          r8     2     2
.line	984	gettable      r9    r8  k150 ; k150 = "GetModule"
.line	984	gettable     r10    r8  k151 ; k151 = "CommonModuleConfig"
.line	984	gettable     r10   r10  k152 ; k152 = "logic_chat_voice"
.line	984	call          r9     2     2
.line	984	newtable     r10     0     7
.line	984	settable     r10  k153  k154 ; k154 = true
.line	984	settable     r10  k155    r3 ; k155 = "OpenID"
.line	984	gettable     r11    r7  k125 ; k125 = "audio_id"
.line	984	settable     r10  k156   r11 ; k156 = "FileID"
.line	984	gettable     r11    r7  k126 ; k126 = "audio_duration"
.line	984	settable     r10  k157   r11 ; k157 = "Duration"
.line	984	settable     r10  k158  k154 ; k154 = true
.line	984	settable     r10  k159  k154 ; k154 = true
.line	984	self         r11    r0  k161 ; k161 = "_ResolveVoiceMessage" (truncated)
.line	984	move         r13    r3
.line	984	call         r11     3     2
.line	984	settable     r10  k160   r11 ; k160 = "VoiceVolume"
.line	984	gettable     r11    r7  k125 ; k125 = "audio_id"
.line	984	eq             1   r11  k162 ; k162 = nil
.line	984	jmp            0  l419
.line	984	gettable     r11    r7  k125 ; k125 = "audio_id"
.line	984	getupval     r12    u1
.line	984	call         r12     1     2
.line	984	eq             1   r11   r12
.line	984	jmp            0  l419
.line	984	gettable     r11    r0  k163 ; k163 = "VoiceFileDownloadRec" (truncated)
.line	984	gettable     r12    r7  k125 ; k125 = "audio_id"
.line	984	gettable     r11   r11   r12
.line	984	eq             1   r11  k162 ; k162 = nil
.line	984	jmp            0  l360
.line	984	self         r11    r0  k164 ; k164 = "OnDownloadFileEnd"
.line	984	loadnil      r13     1
.line	984	gettable     r15    r7  k125 ; k125 = "audio_id"
.line	984	loadbool     r16     0     0
.line	984	call         r11     6     1
.line	984	gettabup     r11    u0  k165 ; k165 = "Game"
.line	984	self         r11   r11  k166 ; k166 = "ClearTimer"
.line	984	gettable     r13    r0  k163 ; k163 = "VoiceFileDownloadRec" (truncated)
.line	984	gettable     r14    r7  k125 ; k125 = "audio_id"
.line	984	gettable     r13   r13   r14
.line	984	gettable     r13   r13  k167 ; k167 = "Timer"
.line	984	call         r11     3     1
.label	l360
.line	984	loadk        r11   k22 ; k22 = 0
.line	984	gettabup     r12    u0   k59 ; k59 = "slua"
.line	984	gettable     r12   r12   k60 ; k60 = "isValid"
.line	984	gettable     r13    r0  k168 ; k168 = "Owner"
.line	984	gettable     r13   r13  k169 ; k169 = "Object"
.line	984	call         r12     2     2
.line	984	test         r12     0
.line	984	jmp            0  l380
.line	984	gettabup     r12    u0   k59 ; k59 = "slua"
.line	984	gettable     r12   r12   k60 ; k60 = "isValid"
.line	984	gettable     r13    r0  k168 ; k168 = "Owner"
.line	984	gettable     r13   r13  k169 ; k169 = "Object"
.line	984	gettable     r13   r13  k170 ; k170 = "PlayerState"
.line	984	call         r12     2     2
.line	984	test         r12     0
.line	984	jmp            0  l380
.line	984	gettable     r12    r0  k168 ; k168 = "Owner"
.line	984	gettable     r12   r12  k169 ; k169 = "Object"
.line	984	gettable     r12   r12  k170 ; k170 = "PlayerState"
.line	984	gettable     r11   r12  k171 ; k171 = "UID"
.label	l380
.line	984	gettable     r12    r0  k163 ; k163 = "VoiceFileDownloadRec" (truncated)
.line	984	gettable     r13    r7  k125 ; k125 = "audio_id"
.line	984	newtable     r14     0     7
.line	984	settable     r14  k171   r11 ; k171 = "UID"
.line	984	gettabup     r15    u0   k59 ; k59 = "slua"
.line	984	gettable     r15   r15   k60 ; k60 = "isValid"
.line	984	move         r16    r4
.line	984	call         r15     2     2
.line	984	test         r15     0
.line	984	jmp            0  l393
.line	984	gettable     r15    r4  k171 ; k171 = "UID"
.line	984	test         r15     1
.line	984	jmp            0  l394
.label	l393
.line	984	move         r15    r5
.label	l394
.line	984	settable     r14  k172   r15 ; k172 = "SenderUID"
.line	984	settable     r14  k155    r3 ; k155 = "OpenID"
.line	984	settable     r14  k173   k22 ; k22 = 0
.line	984	settable     r14  k157   k22 ; k22 = 0
.line	984	settable     r14  k174   k22 ; k22 = 0
.line	984	gettable     r15    r7  k176 ; k176 = "session_name"
.line	984	settable     r14  k175   r15 ; k175 = "SessionName"
.line	984	settable     r12   r13   r14
.line	984	gettable     r12    r0  k163 ; k163 = "VoiceFileDownloadRec" (truncated)
.line	984	gettable     r13    r7  k125 ; k125 = "audio_id"
.line	984	gettable     r12   r12   r13
.line	984	self         r13    r0  k177 ; k177 = "AddGameTimer"
.line	984	loadk        r15  k113 ; k113 = 2
.line	984	loadbool     r16     0     0
.line	984	closure      r17    f0
.line	984	call         r13     5     2
.line	984	settable     r12  k167   r13 ; k167 = "Timer"
.line	984	self         r12    r9  k178 ; k178 = "TryStopPlayRecordVoi" (truncated)
.line	984	call         r12     2     1
.line	984	self         r12    r9  k179 ; k179 = "PlayVoiceFile"
.line	984	gettable     r14    r7  k180 ; k180 = "audio_id"
.line	984	gettable     r15    r7  k126 ; k126 = "audio_duration"
.line	984	move         r16   r10
.line	984	call         r12     5     1
.line	984	jmp            7  l686
.label	l419
.line	984	gettabup     r11    u0    k0 ; k0 = "print"
.line	984	gettabup     r12    u0    k1 ; k1 = "bWriteLog"
.line	984	test         r12     0
.line	984	jmp            0  l502
.line	984	gettabup     r12    u0    k4 ; k4 = "table"
.line	984	gettable     r12   r12    k5 ; k5 = "concat"
.line	984	newtable     r13     1     0
.line	984	getupval     r14    u1
.line	984	loadk        r15    k6 ; k6 = 149
.line	984	loadk        r16    k7 ; k7 = 51
.line	984	loadk        r17    k8 ; k8 = 25
.line	984	loadk        r18    k9 ; k9 = 150
.line	984	loadk        r19   k10 ; k10 = 134
.line	984	loadk        r20   k11 ; k11 = 254
.line	984	loadk        r21   k12 ; k12 = 126
.line	984	loadk        r22   k13 ; k13 = 123
.line	984	loadk        r23   k14 ; k14 = 86
.line	984	loadk        r24   k15 ; k15 = 197
.line	984	loadk        r25   k16 ; k16 = 162
.line	984	loadk        r26    k9 ; k9 = 150
.line	984	loadk        r27   k17 ; k17 = 191
.line	984	loadk        r28   k18 ; k18 = 198
.line	984	loadk        r29   k19 ; k19 = 108
.line	984	loadk        r30   k20 ; k20 = 175
.line	984	loadk        r31   k21 ; k21 = 18
.line	984	loadk        r32   k22 ; k22 = 0
.line	984	loadk        r33   k23 ; k23 = 70
.line	984	loadk        r34   k24 ; k24 = 171
.line	984	loadk        r35   k25 ; k25 = 69
.line	984	loadk        r36   k26 ; k26 = 205
.line	984	loadk        r37   k27 ; k27 = 14
.line	984	loadk        r38   k28 ; k28 = 94
.line	984	loadk        r39   k23 ; k23 = 70
.line	984	loadk        r40   k29 ; k29 = 225
.line	984	loadk        r41   k30 ; k30 = 147
.line	984	loadk        r42   k10 ; k10 = 134
.line	984	loadk        r43   k20 ; k20 = 175
.line	984	loadk        r44   k31 ; k31 = 194
.line	984	loadk        r45   k32 ; k32 = 77
.line	984	loadk        r46   k33 ; k33 = 187
.line	984	loadk        r47   k34 ; k34 = 84
.line	984	loadk        r48    k7 ; k7 = 51
.line	984	loadk        r49   k35 ; k35 = 90
.line	984	loadk        r50   k36 ; k36 = 158
.line	984	loadk        r51   k37 ; k37 = 83
.line	984	loadk        r52   k38 ; k38 = 218
.line	984	loadk        r53   k39 ; k39 = 91
.line	984	loadk        r54   k40 ; k40 = 24
.line	984	call         r14    41     2
.line	984	getupval     r15    u1
.line	984	loadk        r16  k181 ; k181 = 153
.line	984	loadk        r17  k182 ; k182 = 54
.line	984	loadk        r18  k183 ; k183 = 31
.line	984	loadk        r19  k184 ; k184 = 156
.line	984	loadk        r20   k74 ; k74 = 130
.line	984	loadk        r21   k96 ; k96 = 244
.line	984	loadk        r22   k46 ; k46 = 100
.line	984	loadk        r23  k104 ; k104 = 104
.line	984	loadk        r24  k131 ; k131 = 92
.line	984	loadk        r25  k185 ; k185 = 237
.line	984	loadk        r26   k45 ; k45 = 180
.line	984	loadk        r27  k143 ; k143 = 146
.line	984	loadk        r28  k129 ; k129 = 229
.line	984	loadk        r29  k186 ; k186 = 210
.line	984	loadk        r30  k187 ; k187 = 107
.line	984	loadk        r31   k52 ; k52 = 174
.line	984	loadk        r32   k85 ; k85 = 65
.line	984	loadk        r33  k188 ; k188 = 32
.line	984	loadk        r34  k123 ; k123 = 119
.line	984	loadk        r35   k10 ; k10 = 134
.line	984	loadk        r36  k189 ; k189 = 68
.line	984	loadk        r37  k190 ; k190 = 129
.line	984	loadk        r38   k27 ; k27 = 14
.line	984	loadk        r39   k39 ; k39 = 91
.line	984	loadk        r40  k191 ; k191 = 3
.line	984	loadk        r41  k192 ; k192 = 246
.line	984	loadk        r42  k128 ; k128 = 186
.line	984	loadk        r43  k193 ; k193 = 151
.line	984	loadk        r44   k20 ; k20 = 175
.line	984	loadk        r45   k38 ; k38 = 218
.line	984	call         r15    31     0
.line	984	setlist      r13     0     1
.line	984	call         r12     2     2
.label	l502
.line	984	call         r11     2     1
.line	984	jmp            7  l686
.label	l504
.line	984	gettabup      r8    u0    k0 ; k0 = "print"
.line	984	gettabup      r9    u0    k1 ; k1 = "bWriteLog"
.line	984	test          r9     0
.line	984	jmp            0  l576
.line	984	gettabup      r9    u0    k4 ; k4 = "table"
.line	984	gettable      r9    r9    k5 ; k5 = "concat"
.line	984	newtable     r10     1     0
.line	984	getupval     r11    u1
.line	984	loadk        r12    k6 ; k6 = 149
.line	984	loadk        r13    k7 ; k7 = 51
.line	984	loadk        r14    k8 ; k8 = 25
.line	984	loadk        r15    k9 ; k9 = 150
.line	984	loadk        r16   k10 ; k10 = 134
.line	984	loadk        r17   k11 ; k11 = 254
.line	984	loadk        r18   k12 ; k12 = 126
.line	984	loadk        r19   k13 ; k13 = 123
.line	984	loadk        r20   k14 ; k14 = 86
.line	984	loadk        r21   k15 ; k15 = 197
.line	984	loadk        r22   k16 ; k16 = 162
.line	984	loadk        r23    k9 ; k9 = 150
.line	984	loadk        r24   k17 ; k17 = 191
.line	984	loadk        r25   k18 ; k18 = 198
.line	984	loadk        r26   k19 ; k19 = 108
.line	984	loadk        r27   k20 ; k20 = 175
.line	984	loadk        r28   k21 ; k21 = 18
.line	984	loadk        r29   k22 ; k22 = 0
.line	984	loadk        r30   k23 ; k23 = 70
.line	984	loadk        r31   k24 ; k24 = 171
.line	984	loadk        r32   k25 ; k25 = 69
.line	984	loadk        r33   k26 ; k26 = 205
.line	984	loadk        r34   k27 ; k27 = 14
.line	984	loadk        r35   k28 ; k28 = 94
.line	984	loadk        r36   k23 ; k23 = 70
.line	984	loadk        r37   k29 ; k29 = 225
.line	984	loadk        r38   k30 ; k30 = 147
.line	984	loadk        r39   k10 ; k10 = 134
.line	984	loadk        r40   k20 ; k20 = 175
.line	984	loadk        r41   k31 ; k31 = 194
.line	984	loadk        r42   k32 ; k32 = 77
.line	984	loadk        r43   k33 ; k33 = 187
.line	984	loadk        r44   k34 ; k34 = 84
.line	984	loadk        r45    k7 ; k7 = 51
.line	984	loadk        r46   k35 ; k35 = 90
.line	984	loadk        r47   k36 ; k36 = 158
.line	984	loadk        r48   k37 ; k37 = 83
.line	984	loadk        r49   k38 ; k38 = 218
.line	984	loadk        r50   k39 ; k39 = 91
.line	984	loadk        r51   k40 ; k40 = 24
.line	984	call         r11    41     2
.line	984	getupval     r12    u1
.line	984	loadk        r13  k181 ; k181 = 153
.line	984	loadk        r14  k182 ; k182 = 54
.line	984	loadk        r15  k183 ; k183 = 31
.line	984	loadk        r16  k184 ; k184 = 156
.line	984	loadk        r17   k74 ; k74 = 130
.line	984	loadk        r18   k96 ; k96 = 244
.line	984	loadk        r19   k46 ; k46 = 100
.line	984	loadk        r20  k104 ; k104 = 104
.line	984	loadk        r21  k131 ; k131 = 92
.line	984	loadk        r22  k185 ; k185 = 237
.line	984	loadk        r23   k45 ; k45 = 180
.line	984	loadk        r24  k143 ; k143 = 146
.line	984	loadk        r25  k194 ; k194 = 235
.line	984	loadk        r26   k38 ; k38 = 218
.line	984	loadk        r27  k195 ; k195 = 109
.line	984	loadk        r28   k44 ; k44 = 234
.line	984	loadk        r29   k23 ; k23 = 70
.line	984	loadk        r30  k196 ; k196 = 38
.line	984	loadk        r31  k189 ; k189 = 68
.line	984	call         r12    20     0
.line	984	setlist      r10     0     1
.line	984	call          r9     2     2
.label	l576
.line	984	call          r8     2     1
.line	984	jmp            7  l686
.line	984	jmp            0  l686
.label	l579
.line	984	gettabup      r6    u0    k0 ; k0 = "print"
.line	984	gettabup      r7    u0    k1 ; k1 = "bWriteLog"
.line	984	test          r7     0
.line	984	jmp            0  l685
.line	984	gettabup      r7    u0    k4 ; k4 = "table"
.line	984	gettable      r7    r7    k5 ; k5 = "concat"
.line	984	newtable      r8     2     0
.line	984	getupval      r9    u1
.line	984	loadk        r10    k6 ; k6 = 149
.line	984	loadk        r11    k7 ; k7 = 51
.line	984	loadk        r12    k8 ; k8 = 25
.line	984	loadk        r13    k9 ; k9 = 150
.line	984	loadk        r14   k10 ; k10 = 134
.line	984	loadk        r15   k11 ; k11 = 254
.line	984	loadk        r16   k12 ; k12 = 126
.line	984	loadk        r17   k13 ; k13 = 123
.line	984	loadk        r18   k14 ; k14 = 86
.line	984	loadk        r19   k15 ; k15 = 197
.line	984	loadk        r20   k16 ; k16 = 162
.line	984	loadk        r21    k9 ; k9 = 150
.line	984	loadk        r22   k17 ; k17 = 191
.line	984	loadk        r23   k18 ; k18 = 198
.line	984	loadk        r24   k19 ; k19 = 108
.line	984	loadk        r25   k20 ; k20 = 175
.line	984	loadk        r26   k21 ; k21 = 18
.line	984	loadk        r27   k22 ; k22 = 0
.line	984	loadk        r28   k23 ; k23 = 70
.line	984	loadk        r29   k24 ; k24 = 171
.line	984	loadk        r30   k25 ; k25 = 69
.line	984	loadk        r31   k26 ; k26 = 205
.line	984	loadk        r32   k27 ; k27 = 14
.line	984	loadk        r33   k28 ; k28 = 94
.line	984	loadk        r34   k23 ; k23 = 70
.line	984	loadk        r35   k29 ; k29 = 225
.line	984	loadk        r36   k30 ; k30 = 147
.line	984	loadk        r37   k10 ; k10 = 134
.line	984	loadk        r38   k20 ; k20 = 175
.line	984	loadk        r39   k31 ; k31 = 194
.line	984	loadk        r40   k32 ; k32 = 77
.line	984	loadk        r41   k33 ; k33 = 187
.line	984	loadk        r42   k34 ; k34 = 84
.line	984	loadk        r43    k7 ; k7 = 51
.line	984	loadk        r44   k35 ; k35 = 90
.line	984	loadk        r45   k36 ; k36 = 158
.line	984	loadk        r46   k37 ; k37 = 83
.line	984	loadk        r47   k38 ; k38 = 218
.line	984	loadk        r48   k39 ; k39 = 91
.line	984	loadk        r49   k40 ; k40 = 24
.line	984	call          r9    41     2
.line	984	getupval     r10    u1
.line	984	loadk        r11   k24 ; k24 = 171
.line	984	loadk        r12  k197 ; k197 = 26
.line	984	loadk        r13  k182 ; k182 = 54
.line	984	loadk        r14   k33 ; k33 = 187
.line	984	loadk        r15  k121 ; k121 = 181
.line	984	loadk        r16  k198 ; k198 = 227
.line	984	loadk        r17  k199 ; k199 = 55
.line	984	loadk        r18  k200 ; k200 = 113
.line	984	loadk        r19  k201 ; k201 = 64
.line	984	loadk        r20  k202 ; k202 = 163
.line	984	loadk        r21  k203 ; k203 = 169
.line	984	loadk        r22  k143 ; k143 = 146
.line	984	loadk        r23   k16 ; k16 = 162
.line	984	loadk        r24  k204 ; k204 = 199
.line	984	loadk        r25   k81 ; k81 = 118
.line	984	loadk        r26   k20 ; k20 = 175
.line	984	loadk        r27   k35 ; k35 = 90
.line	984	loadk        r28  k205 ; k205 = 111
.line	984	loadk        r29   k93 ; k93 = 124
.line	984	loadk        r30  k206 ; k206 = 138
.line	984	loadk        r31   k85 ; k85 = 65
.line	984	loadk        r32  k207 ; k207 = 204
.line	984	loadk        r33  k208 ; k208 = 10
.line	984	loadk        r34  k136 ; k136 = 73
.line	984	loadk        r35   k54 ; k54 = 87
.line	984	loadk        r36  k192 ; k192 = 246
.line	984	loadk        r37    k9 ; k9 = 150
.line	984	loadk        r38   k52 ; k52 = 174
.line	984	loadk        r39  k209 ; k209 = 251
.line	984	loadk        r40   k26 ; k26 = 205
.line	984	loadk        r41  k110 ; k110 = 97
.line	984	loadk        r42   k64 ; k64 = 168
.line	984	loadk        r43   k40 ; k40 = 24
.line	984	loadk        r44  k210 ; k210 = 59
.line	984	loadk        r45  k211 ; k211 = 81
.line	984	loadk        r46   k36 ; k36 = 158
.line	984	loadk        r47  k131 ; k131 = 92
.line	984	loadk        r48  k212 ; k212 = 222
.line	984	loadk        r49  k213 ; k213 = 16
.line	984	loadk        r50   k40 ; k40 = 24
.line	984	call         r10    41     2
.line	984	getupval     r11    u1
.line	984	loadk        r12   k41 ; k41 = 182
.line	984	loadk        r13  k197 ; k197 = 26
.line	984	loadk        r14   k69 ; k69 = 45
.line	984	loadk        r15   k24 ; k24 = 171
.line	984	loadk        r16   k16 ; k16 = 162
.line	984	loadk        r17   k49 ; k49 = 240
.line	984	loadk        r18   k13 ; k13 = 123
.line	984	loadk        r19  k118 ; k118 = 56
.line	984	loadk        r20  k214 ; k214 = 125
.line	984	loadk        r21  k140 ; k140 = 211
.line	984	loadk        r22  k215 ; k215 = 132
.line	984	call         r11    12     0
.line	984	setlist       r8     0     1
.line	984	call          r7     2     2
.label	l685
.line	984	call          r6     2     1
.label	l686
.line	984	return        r0     1
.line	984	move          r0    r0
.line	984	move          r0    r0
.line	984	move          r0    r0
.line	984	move          r0    r0
.line	984	return        r0     1

.function	main/f54/f0

.source	null
.linedefined	1028
.lastlinedefined	1030
.numparams	0
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	0	true
.upvalue	"U1"	7	true

.constant	k0	"OnVoiceFileEndPlay"
.constant	k1	"audio_id"

.line	1028	getupval      r0    u0
.line	1028	self          r0    r0    k0 ; k0 = "OnVoiceFileEndPlay"
.line	1028	gettabup      r2    u1    k1 ; k1 = "audio_id"
.line	1028	call          r0     3     1
.line	1028	return        r0     1
.line	1028	move          r0    r0
.line	1028	move          r0    r0
.line	1028	move          r0    r0
.line	1028	return        r0     1

.function	main/f55

.source	null
.linedefined	1045
.lastlinedefined	1051
.numparams	2
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	3	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	159
.constant	k4	30
.constant	k5	53
.constant	k6	186
.constant	k7	156
.constant	k8	228
.constant	k9	118
.constant	k10	54
.constant	k11	126
.constant	k12	236
.constant	k13	163
.constant	k14	217
.constant	k15	137
.constant	k16	210
.constant	k17	109
.constant	k18	175
.constant	k19	101
.constant	k20	32
.constant	k21	76
.constant	k22	193
.constant	k23	99
.constant	k24	206
.constant	k25	10
.constant	k26	69
.constant	k27	253
.constant	k28	249
.constant	k29	174
.constant	k30	181
.constant	k31	111
.constant	k32	183
.constant	k33	93
.constant	k34	9
.constant	k35	87
.constant	k36	150
.constant	k37	83
.constant	k38	212
.constant	k39	35
.constant	k40	19
.constant	k41	43
.constant	k42	"nRSTSSceneID"
.constant	k43	"Enum_ASRSceneID"
.constant	k44	"NightWatch"
.constant	k45	"GetNightWatchVoiceVolume"
.constant	k46	"GetTeammateAIVoiceVolume"

.line	1045	gettabup      r2    u0    k0 ; k0 = "require"
.line	1045	gettabup      r3    u0    k1 ; k1 = "table"
.line	1045	gettable      r3    r3    k2 ; k2 = "concat"
.line	1045	newtable      r4     1     0
.line	1045	getupval      r5    u1
.line	1045	loadk         r6    k3 ; k3 = 159
.line	1045	loadk         r7    k4 ; k4 = 30
.line	1045	loadk         r8    k5 ; k5 = 53
.line	1045	loadk         r9    k6 ; k6 = 186
.line	1045	loadk        r10    k7 ; k7 = 156
.line	1045	loadk        r11    k8 ; k8 = 228
.line	1045	loadk        r12    k9 ; k9 = 118
.line	1045	loadk        r13   k10 ; k10 = 54
.line	1045	loadk        r14   k11 ; k11 = 126
.line	1045	loadk        r15   k12 ; k12 = 236
.line	1045	loadk        r16   k13 ; k13 = 163
.line	1045	loadk        r17   k14 ; k14 = 217
.line	1045	loadk        r18   k15 ; k15 = 137
.line	1045	loadk        r19   k16 ; k16 = 210
.line	1045	loadk        r20   k17 ; k17 = 109
.line	1045	loadk        r21   k18 ; k18 = 175
.line	1045	loadk        r22   k19 ; k19 = 101
.line	1045	loadk        r23   k20 ; k20 = 32
.line	1045	loadk        r24   k21 ; k21 = 76
.line	1045	loadk        r25   k22 ; k22 = 193
.line	1045	loadk        r26   k23 ; k23 = 99
.line	1045	loadk        r27   k24 ; k24 = 206
.line	1045	loadk        r28   k25 ; k25 = 10
.line	1045	loadk        r29   k26 ; k26 = 69
.line	1045	loadk        r30   k21 ; k21 = 76
.line	1045	loadk        r31   k27 ; k27 = 253
.line	1045	loadk        r32   k28 ; k28 = 249
.line	1045	loadk        r33   k29 ; k29 = 174
.line	1045	loadk        r34   k30 ; k30 = 181
.line	1045	loadk        r35    k8 ; k8 = 228
.line	1045	loadk        r36   k31 ; k31 = 111
.line	1045	loadk        r37   k32 ; k32 = 183
.line	1045	loadk        r38   k33 ; k33 = 93
.line	1045	loadk        r39   k34 ; k34 = 9
.line	1045	loadk        r40   k35 ; k35 = 87
.line	1045	loadk        r41   k36 ; k36 = 150
.line	1045	loadk        r42   k37 ; k37 = 83
.line	1045	loadk        r43   k38 ; k38 = 212
.line	1045	loadk        r44   k39 ; k39 = 35
.line	1045	loadk        r45   k35 ; k35 = 87
.line	1045	call          r5    41     2
.line	1045	getupval      r6    u1
.line	1045	loadk         r7   k32 ; k32 = 183
.line	1045	loadk         r8   k40 ; k40 = 19
.line	1045	loadk         r9   k41 ; k41 = 43
.line	1045	call          r6     4     0
.line	1045	setlist       r4     0     1
.line	1045	call          r3     2     2
.line	1045	call          r2     2     2
.line	1045	gettable      r3    r0   k42 ; k42 = "nRSTSSceneID"
.line	1045	gettabup      r4    u2   k43 ; k43 = "Enum_ASRSceneID"
.line	1045	gettable      r4    r4   k44 ; k44 = "NightWatch"
.line	1045	eq             0    r3    r4
.line	1045	jmp            0   l63
.line	1045	gettable      r3    r2   k45 ; k45 = "GetNightWatchVoiceVo" (truncated)
.line	1045	tailcall      r3     1
.line	1045	return        r3     0
.label	l63
.line	1045	gettable      r3    r2   k46 ; k46 = "GetTeammateAIVoiceVo" (truncated)
.line	1045	move          r4    r1
.line	1045	tailcall      r3     2
.line	1045	return        r3     0
.line	1045	return        r0     1
.line	1045	move          r0    r0
.line	1045	move          r0    r0
.line	1045	move          r0    r0
.line	1045	move          r0    r0
.line	1045	return        r0     1

.function	main/f56

.source	null
.linedefined	1053
.lastlinedefined	1066
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	0
.constant	k1	1
.constant	k2	"DataMgr"
.constant	k3	"roleData"
.constant	k4	"eugdpr"
.constant	k5	"user_type"
.constant	k6	"print"
.constant	k7	"bWriteLog"
.constant	k8	"table"
.constant	k9	"concat"
.constant	k10	149
.constant	k11	51
.constant	k12	25
.constant	k13	150
.constant	k14	134
.constant	k15	254
.constant	k16	126
.constant	k17	123
.constant	k18	86
.constant	k19	197
.constant	k20	162
.constant	k21	191
.constant	k22	198
.constant	k23	108
.constant	k24	175
.constant	k25	18
.constant	k26	8
.constant	k27	77
.constant	k28	155
.constant	k29	114
.constant	k30	196
.constant	k31	65
.constant	k32	76
.constant	k33	253
.constant	k34	158
.constant	k35	163
.constant	k36	251
.constant	k37	189
.constant	k38	92
.constant	k39	47
.constant	k40	74
.constant	k41	223
.constant	k42	89
.constant	k43	194
.constant	k44	87
.constant	k45	177
.constant	k46	19
.constant	k47	"require"
.constant	k48	187
.constant	k49	49
.constant	k50	186
.constant	k51	190
.constant	k52	229
.constant	k53	57
.constant	k54	107
.constant	k55	95
.constant	k56	246
.constant	k57	166
.constant	k58	217
.constant	k59	167
.constant	k60	220
.constant	k61	121
.constant	k62	75
.constant	k63	97
.constant	k64	79
.constant	k65	139
.constant	k66	80
.constant	k67	211
.constant	k68	73
.constant	k69	68
.constant	k70	244
.constant	k71	132
.constant	k72	106
.constant	k73	170
.constant	k74	"IsEUGDPRUser"

.line	1053	loadk         r1    k0 ; k0 = 0
.line	1053	loadk         r2    k1 ; k1 = 1
.line	1053	gettabup      r3    u0    k2 ; k2 = "DataMgr"
.line	1053	gettable      r3    r3    k3 ; k3 = "roleData"
.line	1053	gettable      r3    r3    k4 ; k4 = "eugdpr"
.line	1053	test          r3     0
.line	1053	jmp            0   l13
.line	1053	gettabup      r3    u0    k2 ; k2 = "DataMgr"
.line	1053	gettable      r3    r3    k3 ; k3 = "roleData"
.line	1053	gettable      r3    r3    k4 ; k4 = "eugdpr"
.line	1053	gettable      r2    r3    k5 ; k5 = "user_type"
.line	1053	jmp            0   l69
.label	l13
.line	1053	gettabup      r3    u0    k6 ; k6 = "print"
.line	1053	gettabup      r4    u0    k7 ; k7 = "bWriteLog"
.line	1053	test          r4     0
.line	1053	jmp            0   l68
.line	1053	gettabup      r4    u0    k8 ; k8 = "table"
.line	1053	gettable      r4    r4    k9 ; k9 = "concat"
.line	1053	newtable      r5     1     0
.line	1053	getupval      r6    u1
.line	1053	loadk         r7   k10 ; k10 = 149
.line	1053	loadk         r8   k11 ; k11 = 51
.line	1053	loadk         r9   k12 ; k12 = 25
.line	1053	loadk        r10   k13 ; k13 = 150
.line	1053	loadk        r11   k14 ; k14 = 134
.line	1053	loadk        r12   k15 ; k15 = 254
.line	1053	loadk        r13   k16 ; k16 = 126
.line	1053	loadk        r14   k17 ; k17 = 123
.line	1053	loadk        r15   k18 ; k18 = 86
.line	1053	loadk        r16   k19 ; k19 = 197
.line	1053	loadk        r17   k20 ; k20 = 162
.line	1053	loadk        r18   k13 ; k13 = 150
.line	1053	loadk        r19   k21 ; k21 = 191
.line	1053	loadk        r20   k22 ; k22 = 198
.line	1053	loadk        r21   k23 ; k23 = 108
.line	1053	loadk        r22   k24 ; k24 = 175
.line	1053	loadk        r23   k25 ; k25 = 18
.line	1053	loadk        r24   k26 ; k26 = 8
.line	1053	loadk        r25   k27 ; k27 = 77
.line	1053	loadk        r26   k28 ; k28 = 155
.line	1053	loadk        r27   k29 ; k29 = 114
.line	1053	loadk        r28   k30 ; k30 = 196
.line	1053	loadk        r29    k0 ; k0 = 0
.line	1053	loadk        r30   k31 ; k31 = 65
.line	1053	loadk        r31   k32 ; k32 = 76
.line	1053	loadk        r32   k33 ; k33 = 253
.line	1053	loadk        r33   k34 ; k34 = 158
.line	1053	loadk        r34   k35 ; k35 = 163
.line	1053	loadk        r35   k36 ; k36 = 251
.line	1053	loadk        r36   k22 ; k22 = 198
.line	1053	loadk        r37   k17 ; k17 = 123
.line	1053	loadk        r38   k37 ; k37 = 189
.line	1053	loadk        r39   k38 ; k38 = 92
.line	1053	loadk        r40   k39 ; k39 = 47
.line	1053	loadk        r41   k40 ; k40 = 74
.line	1053	loadk        r42   k41 ; k41 = 223
.line	1053	loadk        r43   k42 ; k42 = 89
.line	1053	loadk        r44   k43 ; k43 = 194
.line	1053	loadk        r45   k44 ; k44 = 87
.line	1053	loadk        r46   k18 ; k18 = 86
.line	1053	call          r6    41     2
.line	1053	getupval      r7    u1
.line	1053	loadk         r8   k45 ; k45 = 177
.line	1053	loadk         r9   k46 ; k46 = 19
.line	1053	call          r7     3     0
.line	1053	setlist       r5     0     1
.line	1053	call          r4     2     2
.label	l68
.line	1053	call          r3     2     1
.label	l69
.line	1053	gettabup      r3    u0   k47 ; k47 = "require"
.line	1053	getupval      r4    u1
.line	1053	loadk         r5   k48 ; k48 = 187
.line	1053	loadk         r6   k46 ; k46 = 19
.line	1053	loadk         r7   k49 ; k49 = 49
.line	1053	loadk         r8   k50 ; k50 = 186
.line	1053	loadk         r9   k51 ; k51 = 190
.line	1053	loadk        r10   k52 ; k52 = 229
.line	1053	loadk        r11   k53 ; k53 = 57
.line	1053	loadk        r12   k54 ; k54 = 107
.line	1053	loadk        r13   k55 ; k55 = 95
.line	1053	loadk        r14   k56 ; k56 = 246
.line	1053	loadk        r15   k57 ; k57 = 166
.line	1053	loadk        r16   k58 ; k58 = 217
.line	1053	loadk        r17   k59 ; k59 = 167
.line	1053	loadk        r18   k60 ; k60 = 220
.line	1053	loadk        r19   k61 ; k61 = 121
.line	1053	loadk        r20   k35 ; k35 = 163
.line	1053	loadk        r21   k62 ; k62 = 75
.line	1053	loadk        r22   k63 ; k63 = 97
.line	1053	loadk        r23   k64 ; k64 = 79
.line	1053	loadk        r24   k65 ; k65 = 139
.line	1053	loadk        r25   k66 ; k66 = 80
.line	1053	loadk        r26   k67 ; k67 = 211
.line	1053	loadk        r27   k68 ; k68 = 73
.line	1053	loadk        r28   k69 ; k69 = 68
.line	1053	loadk        r29   k32 ; k32 = 76
.line	1053	loadk        r30   k70 ; k70 = 244
.line	1053	loadk        r31   k51 ; k51 = 190
.line	1053	loadk        r32   k71 ; k71 = 132
.line	1053	loadk        r33   k71 ; k71 = 132
.line	1053	loadk        r34   k30 ; k30 = 196
.line	1053	loadk        r35   k72 ; k72 = 106
.line	1053	loadk        r36   k73 ; k73 = 170
.line	1053	loadk        r37   k40 ; k40 = 74
.line	1053	call          r4    34     2
.line	1053	call          r3     2     2
.line	1053	eq             1    r2    k0 ; k0 = 0
.line	1053	jmp            0  l114
.line	1053	gettable      r4    r3   k74 ; k74 = "IsEUGDPRUser"
.line	1053	move          r5    r2
.line	1053	call          r4     2     2
.line	1053	test          r4     0
.line	1053	jmp            0  l114
.line	1053	loadk         r1    k1 ; k1 = 1
.label	l114
.line	1053	return        r1     2
.line	1053	return        r0     1
.line	1053	move          r0    r0
.line	1053	move          r0    r0
.line	1053	return        r0     1

.function	main/f57

.source	null
.linedefined	1068
.lastlinedefined	1076
.numparams	1
.is_vararg	0
.maxstacksize	3

.constant	k0	"bOpenMLAIVoice"
.constant	k1	true
.constant	k2	"_IsPublicOpinionScene"
.constant	k3	"_CheckMinorCompliance"

.line	1068	gettable      r1    r0    k0 ; k0 = "bOpenMLAIVoice"
.line	1068	eq             1    r1    k1 ; k1 = true
.line	1068	jmp            0    l6
.line	1068	loadbool      r1     0     0
.line	1068	return        r1     2
.label	l6
.line	1068	self          r1    r0    k2 ; k2 = "_IsPublicOpinionScen" (truncated)
.line	1068	call          r1     2     2
.line	1068	test          r1     0
.line	1068	jmp            0   l12
.line	1068	loadbool      r1     1     0
.line	1068	return        r1     2
.label	l12
.line	1068	self          r1    r0    k3 ; k3 = "_CheckMinorComplianc" (truncated)
.line	1068	tailcall      r1     2
.line	1068	return        r1     0
.line	1068	return        r0     1
.line	1068	move          r0    r0
.line	1068	return        r0     1

.function	main/f58

.source	null
.linedefined	1078
.lastlinedefined	1090
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"bOpenMLAIVoice"
.constant	k1	true
.constant	k2	"_IsPublicOpinionScene"
.constant	k3	"_CheckMinorCompliance"
.constant	k4	"print"
.constant	k5	"bWriteLog"
.constant	k6	"table"
.constant	k7	"concat"
.constant	k8	149
.constant	k9	51
.constant	k10	25
.constant	k11	150
.constant	k12	134
.constant	k13	254
.constant	k14	126
.constant	k15	123
.constant	k16	86
.constant	k17	197
.constant	k18	162
.constant	k19	191
.constant	k20	198
.constant	k21	108
.constant	k22	175
.constant	k23	18
.constant	k24	12
.constant	k25	73
.constant	k26	129
.constant	k27	115
.constant	k28	196
.constant	k29	9
.constant	k30	76
.constant	k31	103
.constant	k32	246
.constant	k33	187
.constant	k34	142
.constant	k35	173
.constant	k36	124
.constant	k37	147
.constant	k38	57
.constant	k39	87
.constant	k40	223
.constant	k41	84
.constant	k42	212
.constant	k43	65
.constant	k44	248
.constant	k45	29
.constant	k46	33
.constant	k47	255
.constant	k48	189
.constant	k49	121
.constant	k50	119
.constant	k51	163
.constant	k52	164
.constant	k53	152
.constant	k54	166
.constant	k55	195
.constant	k56	114
.constant	k57	75
.constant	k58	138

.line	1078	gettable      r1    r0    k0 ; k0 = "bOpenMLAIVoice"
.line	1078	eq             1    r1    k1 ; k1 = true
.line	1078	jmp            0    l6
.line	1078	loadbool      r1     0     0
.line	1078	return        r1     2
.label	l6
.line	1078	self          r1    r0    k2 ; k2 = "_IsPublicOpinionScen" (truncated)
.line	1078	call          r1     2     2
.line	1078	test          r1     0
.line	1078	jmp            0   l12
.line	1078	loadbool      r1     0     0
.line	1078	return        r1     2
.label	l12
.line	1078	self          r1    r0    k3 ; k3 = "_CheckMinorComplianc" (truncated)
.line	1078	call          r1     2     2
.line	1078	test          r1     1
.line	1078	jmp            0   l92
.line	1078	gettabup      r1    u0    k4 ; k4 = "print"
.line	1078	gettabup      r2    u0    k5 ; k5 = "bWriteLog"
.line	1078	test          r2     0
.line	1078	jmp            0   l89
.line	1078	gettabup      r2    u0    k6 ; k6 = "table"
.line	1078	gettable      r2    r2    k7 ; k7 = "concat"
.line	1078	newtable      r3     1     0
.line	1078	getupval      r4    u1
.line	1078	loadk         r5    k8 ; k8 = 149
.line	1078	loadk         r6    k9 ; k9 = 51
.line	1078	loadk         r7   k10 ; k10 = 25
.line	1078	loadk         r8   k11 ; k11 = 150
.line	1078	loadk         r9   k12 ; k12 = 134
.line	1078	loadk        r10   k13 ; k13 = 254
.line	1078	loadk        r11   k14 ; k14 = 126
.line	1078	loadk        r12   k15 ; k15 = 123
.line	1078	loadk        r13   k16 ; k16 = 86
.line	1078	loadk        r14   k17 ; k17 = 197
.line	1078	loadk        r15   k18 ; k18 = 162
.line	1078	loadk        r16   k11 ; k11 = 150
.line	1078	loadk        r17   k19 ; k19 = 191
.line	1078	loadk        r18   k20 ; k20 = 198
.line	1078	loadk        r19   k21 ; k21 = 108
.line	1078	loadk        r20   k22 ; k22 = 175
.line	1078	loadk        r21   k23 ; k23 = 18
.line	1078	loadk        r22   k24 ; k24 = 12
.line	1078	loadk        r23   k25 ; k25 = 73
.line	1078	loadk        r24   k26 ; k26 = 129
.line	1078	loadk        r25   k27 ; k27 = 115
.line	1078	loadk        r26   k28 ; k28 = 196
.line	1078	loadk        r27   k29 ; k29 = 9
.line	1078	loadk        r28   k30 ; k30 = 76
.line	1078	loadk        r29   k31 ; k31 = 103
.line	1078	loadk        r30   k32 ; k32 = 246
.line	1078	loadk        r31   k33 ; k33 = 187
.line	1078	loadk        r32   k34 ; k34 = 142
.line	1078	loadk        r33   k35 ; k35 = 173
.line	1078	loadk        r34   k20 ; k20 = 198
.line	1078	loadk        r35   k36 ; k36 = 124
.line	1078	loadk        r36   k37 ; k37 = 147
.line	1078	loadk        r37   k16 ; k16 = 86
.line	1078	loadk        r38   k38 ; k38 = 57
.line	1078	loadk        r39   k39 ; k39 = 87
.line	1078	loadk        r40   k40 ; k40 = 223
.line	1078	loadk        r41   k41 ; k41 = 84
.line	1078	loadk        r42   k42 ; k42 = 212
.line	1078	loadk        r43   k10 ; k10 = 25
.line	1078	loadk        r44   k43 ; k43 = 65
.line	1078	call          r4    41     2
.line	1078	getupval      r5    u1
.line	1078	loadk         r6   k44 ; k44 = 248
.line	1078	loadk         r7   k45 ; k45 = 29
.line	1078	loadk         r8   k46 ; k46 = 33
.line	1078	loadk         r9   k47 ; k47 = 255
.line	1078	loadk        r10   k48 ; k48 = 189
.line	1078	loadk        r11   k44 ; k44 = 248
.line	1078	loadk        r12   k49 ; k49 = 121
.line	1078	loadk        r13   k50 ; k50 = 119
.line	1078	loadk        r14   k43 ; k43 = 65
.line	1078	loadk        r15   k51 ; k51 = 163
.line	1078	loadk        r16   k52 ; k52 = 164
.line	1078	loadk        r17   k53 ; k53 = 152
.line	1078	loadk        r18   k54 ; k54 = 166
.line	1078	loadk        r19   k55 ; k55 = 195
.line	1078	loadk        r20   k56 ; k56 = 114
.line	1078	loadk        r21   k51 ; k51 = 163
.line	1078	loadk        r22   k25 ; k25 = 73
.line	1078	loadk        r23   k46 ; k46 = 33
.line	1078	loadk        r24   k57 ; k57 = 75
.line	1078	loadk        r25   k58 ; k58 = 138
.line	1078	call          r5    21     0
.line	1078	setlist       r3     0     1
.line	1078	call          r2     2     2
.label	l89
.line	1078	call          r1     2     1
.line	1078	loadbool      r1     0     0
.line	1078	return        r1     2
.label	l92
.line	1078	loadbool      r1     1     0
.line	1078	return        r1     2
.line	1078	return        r0     1
.line	1078	move          r0    r0
.line	1078	move          r0    r0
.line	1078	move          r0    r0
.line	1078	move          r0    r0
.line	1078	return        r0     1

.function	main/f59

.source	null
.linedefined	1092
.lastlinedefined	1114
.numparams	1
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	5	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	4	true

.constant	k0	"GetDebugMockVerdict"
.constant	k1	nil
.constant	k2	"print"
.constant	k3	"bWriteLog"
.constant	k4	"string"
.constant	k5	"format"
.constant	k6	"table"
.constant	k7	"concat"
.constant	k8	149
.constant	k9	51
.constant	k10	25
.constant	k11	150
.constant	k12	134
.constant	k13	254
.constant	k14	126
.constant	k15	123
.constant	k16	86
.constant	k17	197
.constant	k18	162
.constant	k19	191
.constant	k20	198
.constant	k21	108
.constant	k22	175
.constant	k23	18
.constant	k24	16
.constant	k25	107
.constant	k26	135
.constant	k27	69
.constant	k28	194
.constant	k29	12
.constant	k30	101
.constant	k31	74
.constant	k32	253
.constant	k33	184
.constant	k34	152
.constant	k35	204
.constant	k36	99
.constant	k37	170
.constant	k38	84
.constant	k39	54
.constant	k40	89
.constant	k41	145
.constant	k42	83
.constant	k43	212
.constant	k44	87
.constant	k45	77
.constant	k46	171
.constant	k47	26
.constant	k48	120
.constant	k49	187
.constant	k50	181
.constant	k51	243
.constant	k52	98
.constant	k53	127
.constant	k54	19
.constant	k55	238
.constant	k56	168
.constant	k57	148
.constant	k58	160
.constant	k59	159
.constant	k60	62
.constant	k61	186
.constant	k62	73
.constant	k63	60
.constant	k64	91
.constant	k65	213
.constant	k66	5
.constant	k67	210
.constant	k68	"tostring"
.constant	k69	"require"
.constant	k70	49
.constant	k71	190
.constant	k72	229
.constant	k73	57
.constant	k74	117
.constant	k75	92
.constant	k76	231
.constant	k77	178
.constant	k78	155
.constant	k79	174
.constant	k80	236
.constant	k81	34
.constant	k82	79
.constant	k83	211
.constant	k84	6
.constant	k85	110
.constant	k86	252
.constant	k87	179
.constant	k88	146
.constant	k89	183
.constant	k90	67
.constant	k91	95
.constant	k92	154
.constant	k93	66
.constant	k94	"GetModule"
.constant	k95	"CommonModuleConfig"
.constant	k96	"logic_familycenter"
.constant	k97	"IsInGrayScale"
.constant	k98	"GetCachedResult"
.constant	k99	"ENUM_SCENE"
.constant	k100	"AI"
.constant	k101	185
.constant	k102	177
.constant	k103	116
.constant	k104	224
.constant	k105	153
.constant	k106	214
.constant	k107	234
.constant	k108	75
.constant	k109	46
.constant	k110	141
.constant	k111	71
.constant	k112	88
.constant	k113	164
.constant	k114	221
.constant	k115	208
.constant	k116	250
.constant	k117	58
.constant	k118	138
.constant	k119	29
.constant	k120	"pass"
.constant	k121	"result"
.constant	k122	"_bLegacyFallbackPass"
.constant	k123	246
.constant	k124	118
.constant	k125	163
.constant	k126	161
.constant	k127	167
.constant	k128	223
.constant	k129	124
.constant	k130	36
.constant	k131	8
.constant	k132	3
.constant	k133	65
.constant	k134	64
.constant	k135	251
.constant	k136	199
.constant	k137	125
.constant	k138	169
.constant	k139	2
.constant	k140	122
.constant	k141	94
.constant	k142	242
.constant	k143	114
.constant	k144	230
.constant	k145	215
.constant	k146	111
.constant	k147	158
.constant	k148	96
.constant	k149	81
.constant	k150	24
.constant	k151	142
.constant	k152	189
.constant	k153	27
.constant	k154	"_IsMinorByLegacyCheck"

.line	1092	gettabup      r1    u0    k0 ; k0 = "GetDebugMockVerdict"
.line	1092	call          r1     1     2
.line	1092	eq             1    r1    k1 ; k1 = nil
.line	1092	jmp            0   l88
.line	1092	gettabup      r2    u1    k2 ; k2 = "print"
.line	1092	gettabup      r3    u1    k3 ; k3 = "bWriteLog"
.line	1092	test          r3     0
.line	1092	jmp            0   l86
.line	1092	gettabup      r3    u1    k4 ; k4 = "string"
.line	1092	gettable      r3    r3    k5 ; k5 = "format"
.line	1092	gettabup      r4    u1    k6 ; k6 = "table"
.line	1092	gettable      r4    r4    k7 ; k7 = "concat"
.line	1092	newtable      r5     1     0
.line	1092	getupval      r6    u2
.line	1092	loadk         r7    k8 ; k8 = 149
.line	1092	loadk         r8    k9 ; k9 = 51
.line	1092	loadk         r9   k10 ; k10 = 25
.line	1092	loadk        r10   k11 ; k11 = 150
.line	1092	loadk        r11   k12 ; k12 = 134
.line	1092	loadk        r12   k13 ; k13 = 254
.line	1092	loadk        r13   k14 ; k14 = 126
.line	1092	loadk        r14   k15 ; k15 = 123
.line	1092	loadk        r15   k16 ; k16 = 86
.line	1092	loadk        r16   k17 ; k17 = 197
.line	1092	loadk        r17   k18 ; k18 = 162
.line	1092	loadk        r18   k11 ; k11 = 150
.line	1092	loadk        r19   k19 ; k19 = 191
.line	1092	loadk        r20   k20 ; k20 = 198
.line	1092	loadk        r21   k21 ; k21 = 108
.line	1092	loadk        r22   k22 ; k22 = 175
.line	1092	loadk        r23   k23 ; k23 = 18
.line	1092	loadk        r24   k24 ; k24 = 16
.line	1092	loadk        r25   k25 ; k25 = 107
.line	1092	loadk        r26   k26 ; k26 = 135
.line	1092	loadk        r27   k27 ; k27 = 69
.line	1092	loadk        r28   k28 ; k28 = 194
.line	1092	loadk        r29   k29 ; k29 = 12
.line	1092	loadk        r30   k30 ; k30 = 101
.line	1092	loadk        r31   k31 ; k31 = 74
.line	1092	loadk        r32   k32 ; k32 = 253
.line	1092	loadk        r33   k33 ; k33 = 184
.line	1092	loadk        r34    k8 ; k8 = 149
.line	1092	loadk        r35   k34 ; k34 = 152
.line	1092	loadk        r36   k35 ; k35 = 204
.line	1092	loadk        r37   k36 ; k36 = 99
.line	1092	loadk        r38   k37 ; k37 = 170
.line	1092	loadk        r39   k38 ; k38 = 84
.line	1092	loadk        r40   k39 ; k39 = 54
.line	1092	loadk        r41   k40 ; k40 = 89
.line	1092	loadk        r42   k41 ; k41 = 145
.line	1092	loadk        r43   k42 ; k42 = 83
.line	1092	loadk        r44   k43 ; k43 = 212
.line	1092	loadk        r45   k44 ; k44 = 87
.line	1092	loadk        r46   k45 ; k45 = 77
.line	1092	call          r6    41     2
.line	1092	getupval      r7    u2
.line	1092	loadk         r8   k46 ; k46 = 171
.line	1092	loadk         r9   k47 ; k47 = 26
.line	1092	loadk        r10   k48 ; k48 = 120
.line	1092	loadk        r11   k49 ; k49 = 187
.line	1092	loadk        r12   k50 ; k50 = 181
.line	1092	loadk        r13   k51 ; k51 = 243
.line	1092	loadk        r14   k52 ; k52 = 98
.line	1092	loadk        r15   k53 ; k53 = 127
.line	1092	loadk        r16   k54 ; k54 = 19
.line	1092	loadk        r17   k55 ; k55 = 238
.line	1092	loadk        r18   k56 ; k56 = 168
.line	1092	loadk        r19   k57 ; k57 = 148
.line	1092	loadk        r20   k58 ; k58 = 160
.line	1092	loadk        r21   k59 ; k59 = 159
.line	1092	loadk        r22   k60 ; k60 = 62
.line	1092	loadk        r23   k61 ; k61 = 186
.line	1092	loadk        r24   k62 ; k62 = 73
.line	1092	loadk        r25   k63 ; k63 = 60
.line	1092	loadk        r26   k64 ; k64 = 91
.line	1092	loadk        r27   k65 ; k65 = 213
.line	1092	loadk        r28   k66 ; k66 = 5
.line	1092	loadk        r29   k67 ; k67 = 210
.line	1092	call          r7    23     0
.line	1092	setlist       r5     0     1
.line	1092	call          r4     2     2
.line	1092	gettabup      r5    u1   k68 ; k68 = "tostring"
.line	1092	move          r6    r1
.line	1092	call          r5     2     0
.line	1092	call          r3     0     2
.label	l86
.line	1092	call          r2     2     1
.line	1092	return        r1     2
.label	l88
.line	1092	gettabup      r2    u1   k69 ; k69 = "require"
.line	1092	getupval      r3    u2
.line	1092	loadk         r4   k49 ; k49 = 187
.line	1092	loadk         r5   k54 ; k54 = 19
.line	1092	loadk         r6   k70 ; k70 = 49
.line	1092	loadk         r7   k61 ; k61 = 186
.line	1092	loadk         r8   k71 ; k71 = 190
.line	1092	loadk         r9   k72 ; k72 = 229
.line	1092	loadk        r10   k73 ; k73 = 57
.line	1092	loadk        r11   k74 ; k74 = 117
.line	1092	loadk        r12   k75 ; k75 = 92
.line	1092	loadk        r13   k76 ; k76 = 231
.line	1092	loadk        r14   k77 ; k77 = 178
.line	1092	loadk        r15   k78 ; k78 = 155
.line	1092	loadk        r16   k79 ; k79 = 174
.line	1092	loadk        r17   k80 ; k80 = 236
.line	1092	loadk        r18   k48 ; k48 = 120
.line	1092	loadk        r19   k33 ; k33 = 184
.line	1092	loadk        r20   k62 ; k62 = 73
.line	1092	loadk        r21   k81 ; k81 = 34
.line	1092	loadk        r22   k45 ; k45 = 77
.line	1092	loadk        r23   k34 ; k34 = 152
.line	1092	loadk        r24   k82 ; k82 = 79
.line	1092	loadk        r25   k83 ; k83 = 211
.line	1092	loadk        r26   k29 ; k29 = 12
.line	1092	loadk        r27   k84 ; k84 = 6
.line	1092	loadk        r28   k85 ; k85 = 110
.line	1092	loadk        r29   k86 ; k86 = 252
.line	1092	loadk        r30   k87 ; k87 = 179
.line	1092	loadk        r31   k88 ; k88 = 146
.line	1092	loadk        r32   k89 ; k89 = 183
.line	1092	loadk        r33   k20 ; k20 = 198
.line	1092	loadk        r34   k90 ; k90 = 67
.line	1092	loadk        r35   k49 ; k49 = 187
.line	1092	loadk        r36   k16 ; k16 = 86
.line	1092	loadk        r37   k60 ; k60 = 62
.line	1092	loadk        r38   k91 ; k91 = 95
.line	1092	loadk        r39   k92 ; k92 = 154
.line	1092	loadk        r40   k93 ; k93 = 66
.line	1092	call          r3    38     2
.line	1092	call          r2     2     2
.line	1092	gettable      r3    r2   k94 ; k94 = "GetModule"
.line	1092	gettable      r4    r2   k95 ; k95 = "CommonModuleConfig"
.line	1092	gettable      r4    r4   k96 ; k96 = "logic_familycenter"
.line	1092	call          r3     2     2
.line	1092	test          r3     0
.line	1092	jmp            0  l453
.line	1092	self          r4    r3   k97 ; k97 = "IsInGrayScale"
.line	1092	call          r4     2     2
.line	1092	test          r4     0
.line	1092	jmp            0  l453
.line	1092	self          r4    r3   k98 ; k98 = "GetCachedResult"
.line	1092	gettabup      r6    u3   k99 ; k99 = "ENUM_SCENE"
.line	1092	gettable      r6    r6  k100 ; k100 = "AI"
.line	1092	call          r4     3     2
.line	1092	test          r4     0
.line	1092	jmp            0  l253
.line	1092	gettabup      r5    u1    k2 ; k2 = "print"
.line	1092	gettabup      r6    u1    k3 ; k3 = "bWriteLog"
.line	1092	test          r6     0
.line	1092	jmp            0  l250
.line	1092	gettabup      r6    u1    k4 ; k4 = "string"
.line	1092	gettable      r6    r6    k5 ; k5 = "format"
.line	1092	gettabup      r7    u1    k6 ; k6 = "table"
.line	1092	gettable      r7    r7    k7 ; k7 = "concat"
.line	1092	newtable      r8     2     0
.line	1092	getupval      r9    u2
.line	1092	loadk        r10    k8 ; k8 = 149
.line	1092	loadk        r11    k9 ; k9 = 51
.line	1092	loadk        r12   k10 ; k10 = 25
.line	1092	loadk        r13   k11 ; k11 = 150
.line	1092	loadk        r14   k12 ; k12 = 134
.line	1092	loadk        r15   k13 ; k13 = 254
.line	1092	loadk        r16   k14 ; k14 = 126
.line	1092	loadk        r17   k15 ; k15 = 123
.line	1092	loadk        r18   k16 ; k16 = 86
.line	1092	loadk        r19   k17 ; k17 = 197
.line	1092	loadk        r20   k18 ; k18 = 162
.line	1092	loadk        r21   k11 ; k11 = 150
.line	1092	loadk        r22   k19 ; k19 = 191
.line	1092	loadk        r23   k20 ; k20 = 198
.line	1092	loadk        r24   k21 ; k21 = 108
.line	1092	loadk        r25   k22 ; k22 = 175
.line	1092	loadk        r26   k23 ; k23 = 18
.line	1092	loadk        r27   k24 ; k24 = 16
.line	1092	loadk        r28   k25 ; k25 = 107
.line	1092	loadk        r29   k26 ; k26 = 135
.line	1092	loadk        r30   k27 ; k27 = 69
.line	1092	loadk        r31   k28 ; k28 = 194
.line	1092	loadk        r32   k29 ; k29 = 12
.line	1092	loadk        r33   k30 ; k30 = 101
.line	1092	loadk        r34   k31 ; k31 = 74
.line	1092	loadk        r35   k32 ; k32 = 253
.line	1092	loadk        r36   k33 ; k33 = 184
.line	1092	loadk        r37    k8 ; k8 = 149
.line	1092	loadk        r38   k34 ; k34 = 152
.line	1092	loadk        r39   k35 ; k35 = 204
.line	1092	loadk        r40   k36 ; k36 = 99
.line	1092	loadk        r41   k37 ; k37 = 170
.line	1092	loadk        r42   k38 ; k38 = 84
.line	1092	loadk        r43   k39 ; k39 = 54
.line	1092	loadk        r44   k40 ; k40 = 89
.line	1092	loadk        r45   k41 ; k41 = 145
.line	1092	loadk        r46   k42 ; k42 = 83
.line	1092	loadk        r47   k43 ; k43 = 212
.line	1092	loadk        r48   k44 ; k44 = 87
.line	1092	loadk        r49   k45 ; k45 = 77
.line	1092	call          r9    41     2
.line	1092	getupval     r10    u2
.line	1092	loadk        r11   k46 ; k46 = 171
.line	1092	loadk        r12   k47 ; k47 = 26
.line	1092	loadk        r13   k48 ; k48 = 120
.line	1092	loadk        r14  k101 ; k101 = 185
.line	1092	loadk        r15  k102 ; k102 = 177
.line	1092	loadk        r16   k86 ; k86 = 252
.line	1092	loadk        r17   k14 ; k14 = 126
.line	1092	loadk        r18  k103 ; k103 = 116
.line	1092	loadk        r19   k31 ; k31 = 74
.line	1092	loadk        r20  k104 ; k104 = 224
.line	1092	loadk        r21   k18 ; k18 = 162
.line	1092	loadk        r22  k105 ; k105 = 153
.line	1092	loadk        r23   k19 ; k19 = 191
.line	1092	loadk        r24  k106 ; k106 = 214
.line	1092	loadk        r25   k21 ; k21 = 108
.line	1092	loadk        r26  k107 ; k107 = 234
.line	1092	loadk        r27  k108 ; k108 = 75
.line	1092	loadk        r28  k109 ; k109 = 46
.line	1092	loadk        r29  k108 ; k108 = 75
.line	1092	loadk        r30   k26 ; k26 = 135
.line	1092	loadk        r31   k27 ; k27 = 69
.line	1092	loadk        r32  k110 ; k110 = 141
.line	1092	loadk        r33  k111 ; k111 = 71
.line	1092	loadk        r34  k112 ; k112 = 88
.line	1092	loadk        r35   k93 ; k93 = 66
.line	1092	loadk        r36  k104 ; k104 = 224
.line	1092	loadk        r37  k113 ; k113 = 164
.line	1092	loadk        r38  k114 ; k114 = 221
.line	1092	loadk        r39   k13 ; k13 = 254
.line	1092	loadk        r40  k115 ; k115 = 208
.line	1092	loadk        r41   k81 ; k81 = 34
.line	1092	loadk        r42  k116 ; k116 = 250
.line	1092	loadk        r43   k31 ; k31 = 74
.line	1092	loadk        r44  k117 ; k117 = 58
.line	1092	loadk        r45  k108 ; k108 = 75
.line	1092	loadk        r46  k118 ; k118 = 138
.line	1092	loadk        r47   k75 ; k75 = 92
.line	1092	loadk        r48   k17 ; k17 = 197
.line	1092	loadk        r49   k45 ; k45 = 77
.line	1092	loadk        r50  k119 ; k119 = 29
.line	1092	call         r10    41     2
.line	1092	getupval     r11    u2
.line	1092	loadk        r12   k46 ; k46 = 171
.line	1092	call         r11     2     0
.line	1092	setlist       r8     0     1
.line	1092	call          r7     2     2
.line	1092	gettabup      r8    u1   k68 ; k68 = "tostring"
.line	1092	gettable      r9    r4  k120 ; k120 = "pass"
.line	1092	call          r8     2     2
.line	1092	gettabup      r9    u1   k68 ; k68 = "tostring"
.line	1092	gettable     r10    r4  k121 ; k121 = "result"
.line	1092	call          r9     2     0
.line	1092	call          r6     0     2
.label	l250
.line	1092	call          r5     2     1
.line	1092	gettable      r5    r4  k120 ; k120 = "pass"
.line	1092	return        r5     2
.label	l253
.line	1092	gettable      r5    r0  k122 ; k122 = "_bLegacyFallbackPass"
.line	1092	eq             1    r5    k1 ; k1 = nil
.line	1092	jmp            0  l353
.line	1092	gettabup      r5    u1    k2 ; k2 = "print"
.line	1092	gettabup      r6    u1    k3 ; k3 = "bWriteLog"
.line	1092	test          r6     0
.line	1092	jmp            0  l350
.line	1092	gettabup      r6    u1    k4 ; k4 = "string"
.line	1092	gettable      r6    r6    k5 ; k5 = "format"
.line	1092	gettabup      r7    u1    k6 ; k6 = "table"
.line	1092	gettable      r7    r7    k7 ; k7 = "concat"
.line	1092	newtable      r8     1     0
.line	1092	getupval      r9    u2
.line	1092	loadk        r10    k8 ; k8 = 149
.line	1092	loadk        r11    k9 ; k9 = 51
.line	1092	loadk        r12   k10 ; k10 = 25
.line	1092	loadk        r13   k11 ; k11 = 150
.line	1092	loadk        r14   k12 ; k12 = 134
.line	1092	loadk        r15   k13 ; k13 = 254
.line	1092	loadk        r16   k14 ; k14 = 126
.line	1092	loadk        r17   k15 ; k15 = 123
.line	1092	loadk        r18   k16 ; k16 = 86
.line	1092	loadk        r19   k17 ; k17 = 197
.line	1092	loadk        r20   k18 ; k18 = 162
.line	1092	loadk        r21   k11 ; k11 = 150
.line	1092	loadk        r22   k19 ; k19 = 191
.line	1092	loadk        r23   k20 ; k20 = 198
.line	1092	loadk        r24   k21 ; k21 = 108
.line	1092	loadk        r25   k22 ; k22 = 175
.line	1092	loadk        r26   k23 ; k23 = 18
.line	1092	loadk        r27   k24 ; k24 = 16
.line	1092	loadk        r28   k25 ; k25 = 107
.line	1092	loadk        r29   k26 ; k26 = 135
.line	1092	loadk        r30   k27 ; k27 = 69
.line	1092	loadk        r31   k28 ; k28 = 194
.line	1092	loadk        r32   k29 ; k29 = 12
.line	1092	loadk        r33   k30 ; k30 = 101
.line	1092	loadk        r34   k31 ; k31 = 74
.line	1092	loadk        r35   k32 ; k32 = 253
.line	1092	loadk        r36   k33 ; k33 = 184
.line	1092	loadk        r37    k8 ; k8 = 149
.line	1092	loadk        r38   k34 ; k34 = 152
.line	1092	loadk        r39   k35 ; k35 = 204
.line	1092	loadk        r40   k36 ; k36 = 99
.line	1092	loadk        r41   k37 ; k37 = 170
.line	1092	loadk        r42   k38 ; k38 = 84
.line	1092	loadk        r43   k39 ; k39 = 54
.line	1092	loadk        r44   k40 ; k40 = 89
.line	1092	loadk        r45   k41 ; k41 = 145
.line	1092	loadk        r46   k42 ; k42 = 83
.line	1092	loadk        r47   k43 ; k43 = 212
.line	1092	loadk        r48   k44 ; k44 = 87
.line	1092	loadk        r49   k45 ; k45 = 77
.line	1092	call          r9    41     2
.line	1092	getupval     r10    u2
.line	1092	loadk        r11   k46 ; k46 = 171
.line	1092	loadk        r12   k47 ; k47 = 26
.line	1092	loadk        r13   k48 ; k48 = 120
.line	1092	loadk        r14   k87 ; k87 = 179
.line	1092	loadk        r15   k50 ; k50 = 181
.line	1092	loadk        r16  k123 ; k123 = 246
.line	1092	loadk        r17  k124 ; k124 = 118
.line	1092	loadk        r18   k15 ; k15 = 123
.line	1092	loadk        r19   k31 ; k31 = 74
.line	1092	loadk        r20  k125 ; k125 = 163
.line	1092	loadk        r21  k126 ; k126 = 161
.line	1092	loadk        r22   k11 ; k11 = 150
.line	1092	loadk        r23  k127 ; k127 = 167
.line	1092	loadk        r24  k128 ; k128 = 223
.line	1092	loadk        r25  k129 ; k129 = 124
.line	1092	loadk        r26   k46 ; k46 = 171
.line	1092	loadk        r27  k108 ; k108 = 75
.line	1092	loadk        r28  k130 ; k130 = 36
.line	1092	loadk        r29  k131 ; k131 = 8
.line	1092	loadk        r30  k105 ; k105 = 153
.line	1092	loadk        r31   k27 ; k27 = 69
.line	1092	loadk        r32   k83 ; k83 = 211
.line	1092	loadk        r33  k132 ; k132 = 3
.line	1092	loadk        r34  k133 ; k133 = 65
.line	1092	loadk        r35  k134 ; k134 = 64
.line	1092	loadk        r36   k76 ; k76 = 231
.line	1092	loadk        r37  k135 ; k135 = 251
.line	1092	loadk        r38  k136 ; k136 = 199
.line	1092	loadk        r39   k46 ; k46 = 171
.line	1092	loadk        r40   k28 ; k28 = 194
.line	1092	loadk        r41  k137 ; k137 = 125
.line	1092	loadk        r42  k138 ; k138 = 169
.line	1092	loadk        r43  k139 ; k139 = 2
.line	1092	loadk        r44  k140 ; k140 = 122
.line	1092	loadk        r45  k108 ; k108 = 75
.line	1092	call         r10    36     0
.line	1092	setlist       r8     0     1
.line	1092	call          r7     2     2
.line	1092	gettabup      r8    u1   k68 ; k68 = "tostring"
.line	1092	gettable      r9    r0  k122 ; k122 = "_bLegacyFallbackPass"
.line	1092	call          r8     2     0
.line	1092	call          r6     0     2
.label	l350
.line	1092	call          r5     2     1
.line	1092	gettable      r5    r0  k122 ; k122 = "_bLegacyFallbackPass"
.line	1092	return        r5     2
.label	l353
.line	1092	gettabup      r5    u1    k2 ; k2 = "print"
.line	1092	gettabup      r6    u1    k3 ; k3 = "bWriteLog"
.line	1092	test          r6     0
.line	1092	jmp            0  l450
.line	1092	gettabup      r6    u1    k6 ; k6 = "table"
.line	1092	gettable      r6    r6    k7 ; k7 = "concat"
.line	1092	newtable      r7     2     0
.line	1092	getupval      r8    u2
.line	1092	loadk         r9    k8 ; k8 = 149
.line	1092	loadk        r10    k9 ; k9 = 51
.line	1092	loadk        r11   k10 ; k10 = 25
.line	1092	loadk        r12   k11 ; k11 = 150
.line	1092	loadk        r13   k12 ; k12 = 134
.line	1092	loadk        r14   k13 ; k13 = 254
.line	1092	loadk        r15   k14 ; k14 = 126
.line	1092	loadk        r16   k15 ; k15 = 123
.line	1092	loadk        r17   k16 ; k16 = 86
.line	1092	loadk        r18   k17 ; k17 = 197
.line	1092	loadk        r19   k18 ; k18 = 162
.line	1092	loadk        r20   k11 ; k11 = 150
.line	1092	loadk        r21   k19 ; k19 = 191
.line	1092	loadk        r22   k20 ; k20 = 198
.line	1092	loadk        r23   k21 ; k21 = 108
.line	1092	loadk        r24   k22 ; k22 = 175
.line	1092	loadk        r25   k23 ; k23 = 18
.line	1092	loadk        r26   k24 ; k24 = 16
.line	1092	loadk        r27   k25 ; k25 = 107
.line	1092	loadk        r28   k26 ; k26 = 135
.line	1092	loadk        r29   k27 ; k27 = 69
.line	1092	loadk        r30   k28 ; k28 = 194
.line	1092	loadk        r31   k29 ; k29 = 12
.line	1092	loadk        r32   k30 ; k30 = 101
.line	1092	loadk        r33   k31 ; k31 = 74
.line	1092	loadk        r34   k32 ; k32 = 253
.line	1092	loadk        r35   k33 ; k33 = 184
.line	1092	loadk        r36    k8 ; k8 = 149
.line	1092	loadk        r37   k34 ; k34 = 152
.line	1092	loadk        r38   k35 ; k35 = 204
.line	1092	loadk        r39   k36 ; k36 = 99
.line	1092	loadk        r40   k37 ; k37 = 170
.line	1092	loadk        r41   k38 ; k38 = 84
.line	1092	loadk        r42   k39 ; k39 = 54
.line	1092	loadk        r43   k40 ; k40 = 89
.line	1092	loadk        r44   k41 ; k41 = 145
.line	1092	loadk        r45   k42 ; k42 = 83
.line	1092	loadk        r46   k43 ; k43 = 212
.line	1092	loadk        r47   k44 ; k44 = 87
.line	1092	loadk        r48  k141 ; k141 = 94
.line	1092	call          r8    41     2
.line	1092	getupval      r9    u2
.line	1092	loadk        r10  k101 ; k101 = 185
.line	1092	loadk        r11   k23 ; k23 = 18
.line	1092	loadk        r12   k70 ; k70 = 49
.line	1092	loadk        r13   k87 ; k87 = 179
.line	1092	loadk        r14  k138 ; k138 = 169
.line	1092	loadk        r15  k142 ; k142 = 242
.line	1092	loadk        r16  k143 ; k143 = 114
.line	1092	loadk        r17  k124 ; k124 = 118
.line	1092	loadk        r18  k111 ; k111 = 71
.line	1092	loadk        r19  k144 ; k144 = 230
.line	1092	loadk        r20   k50 ; k50 = 181
.line	1092	loadk        r21  k145 ; k145 = 215
.line	1092	loadk        r22   k56 ; k56 = 168
.line	1092	loadk        r23   k67 ; k67 = 210
.line	1092	loadk        r24  k137 ; k137 = 125
.line	1092	loadk        r25   k18 ; k18 = 162
.line	1092	loadk        r26   k45 ; k45 = 77
.line	1092	loadk        r27  k146 ; k146 = 111
.line	1092	loadk        r28   k27 ; k27 = 69
.line	1092	loadk        r29   k12 ; k12 = 134
.line	1092	loadk        r30   k42 ; k42 = 83
.line	1092	loadk        r31   k67 ; k67 = 210
.line	1092	loadk        r32  k108 ; k108 = 75
.line	1092	loadk        r33  k131 ; k131 = 8
.line	1092	loadk        r34  k111 ; k111 = 71
.line	1092	loadk        r35  k123 ; k123 = 246
.line	1092	loadk        r36  k101 ; k101 = 185
.line	1092	loadk        r37  k147 ; k147 = 158
.line	1092	loadk        r38  k135 ; k135 = 251
.line	1092	loadk        r39  k106 ; k106 = 214
.line	1092	loadk        r40  k148 ; k148 = 96
.line	1092	loadk        r41   k79 ; k79 = 174
.line	1092	loadk        r42  k149 ; k149 = 81
.line	1092	loadk        r43    k9 ; k9 = 51
.line	1092	loadk        r44  k150 ; k150 = 24
.line	1092	loadk        r45  k151 ; k151 = 142
.line	1092	loadk        r46   k27 ; k27 = 69
.line	1092	loadk        r47   k43 ; k43 = 212
.line	1092	loadk        r48   k66 ; k66 = 5
.line	1092	loadk        r49  k149 ; k149 = 81
.line	1092	call          r9    41     2
.line	1092	getupval     r10    u2
.line	1092	loadk        r11  k152 ; k152 = 189
.line	1092	loadk        r12  k153 ; k153 = 27
.line	1092	call         r10     3     0
.line	1092	setlist       r7     0     1
.line	1092	call          r6     2     2
.label	l450
.line	1092	call          r5     2     1
.line	1092	loadbool      r5     0     0
.line	1092	return        r5     2
.label	l453
.line	1092	self          r4    r0  k154 ; k154 = "_IsMinorByLegacyChec" (truncated)
.line	1092	call          r4     2     2
.line	1092	not           r4    r4
.line	1092	return        r4     2
.line	1092	return        r0     1
.line	1092	move          r0    r0
.line	1092	move          r0    r0
.line	1092	return        r0     1

.function	main/f60

.source	null
.linedefined	1116
.lastlinedefined	1118
.numparams	1
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	5	true

.constant	k0	"IsMinorByLegacyCheck"

.line	1116	gettabup      r1    u0    k0 ; k0 = "IsMinorByLegacyCheck"
.line	1116	tailcall      r1     1
.line	1116	return        r1     0
.line	1116	return        r0     1
.line	1116	move          r0    r0
.line	1116	move          r0    r0
.line	1116	move          r0    r0
.line	1116	move          r0    r0
.line	1116	return        r0     1

.function	main/f61

.source	null
.linedefined	1120
.lastlinedefined	1156
.numparams	4
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	7	true

.constant	k0	"log_tree"
.constant	k1	149
.constant	k2	51
.constant	k3	25
.constant	k4	150
.constant	k5	134
.constant	k6	254
.constant	k7	126
.constant	k8	123
.constant	k9	86
.constant	k10	197
.constant	k11	162
.constant	k12	191
.constant	k13	198
.constant	k14	108
.constant	k15	175
.constant	k16	18
.constant	k17	0
.constant	k18	70
.constant	k19	69
.constant	k20	204
.constant	k21	5
.constant	k22	77
.constant	k23	81
.constant	k24	184
.constant	k25	142
.constant	k26	"table"
.constant	k27	"concat"
.constant	k28	46
.constant	k29	151
.constant	k30	93
.constant	k31	50
.constant	k32	90
.constant	k33	154
.constant	k34	66
.constant	k35	231
.constant	k36	24
.constant	k37	187
.constant	k38	26
.constant	k39	10
.constant	k40	186
.constant	k41	179
.constant	k42	115
.constant	k43	"MemberVoiceRecod"
.constant	k44	"uid"
.constant	k45	"slua"
.constant	k46	"isValid"
.constant	k47	"CGameState"
.constant	k48	"GetPlayerStateByUID"
.constant	k49	"user_info"
.constant	k50	"gmatch"
.constant	k51	240
.constant	k52	36
.constant	k53	6
.constant	k54	249
.constant	k55	141
.constant	k56	62
.constant	k57	"insert"
.constant	k58	1
.constant	k59	"GetTeammatePlayerStateByOpenID"
.constant	k60	"print"
.constant	k61	"bWriteLog"
.constant	k62	"string"
.constant	k63	"format"
.constant	k64	34
.constant	k65	250
.constant	k66	11
.constant	k67	158
.constant	k68	220
.constant	k69	22
.constant	k70	76
.constant	k71	189
.constant	k72	47
.constant	k73	52
.constant	k74	190
.constant	k75	169
.constant	k76	244
.constant	k77	101
.constant	k78	75
.constant	k79	71
.constant	k80	226
.constant	k81	146
.constant	k82	241
.constant	k83	109
.constant	k84	"tostring"
.constant	k85	"IsMasterOfTeammate"
.constant	k86	"UID"
.constant	k87	nil
.constant	k88	"status"
.constant	k89	2
.constant	k90	"StartTime"
.constant	k91	"getMiliseconds"
.constant	k92	"SessionName"
.constant	k93	"CacheSessionName"
.constant	k94	182
.constant	k95	16
.constant	k96	54
.constant	k97	"CacheSessionNameClearTimer"
.constant	k98	"Game"
.constant	k99	"ClearTimer"
.constant	k100	253
.constant	k101	12
.constant	k102	163
.constant	k103	237
.constant	k104	107
.constant	k105	79
.constant	k106	166
.constant	k107	180
.constant	k108	104
.constant	k109	185
.constant	k110	"GetCurrentServerTimeSec"
.constant	k111	113
.constant	k112	49
.constant	k113	94
.constant	k114	144
.constant	k115	148
.constant	k116	4
.constant	k117	"RPC_Server_SendAIVoiceTLog"
.constant	k118	"AIVoiceRecord"
.constant	k119	235
.constant	k120	218
.constant	k121	234
.constant	k122	32
.constant	k123	92
.constant	k124	207
.constant	k125	192
.constant	k126	20
.constant	k127	225

.line	1120	gettabup      r4    u0    k0 ; k0 = "log_tree"
.line	1120	getupval      r5    u1
.line	1120	loadk         r6    k1 ; k1 = 149
.line	1120	loadk         r7    k2 ; k2 = 51
.line	1120	loadk         r8    k3 ; k3 = 25
.line	1120	loadk         r9    k4 ; k4 = 150
.line	1120	loadk        r10    k5 ; k5 = 134
.line	1120	loadk        r11    k6 ; k6 = 254
.line	1120	loadk        r12    k7 ; k7 = 126
.line	1120	loadk        r13    k8 ; k8 = 123
.line	1120	loadk        r14    k9 ; k9 = 86
.line	1120	loadk        r15   k10 ; k10 = 197
.line	1120	loadk        r16   k11 ; k11 = 162
.line	1120	loadk        r17    k4 ; k4 = 150
.line	1120	loadk        r18   k12 ; k12 = 191
.line	1120	loadk        r19   k13 ; k13 = 198
.line	1120	loadk        r20   k14 ; k14 = 108
.line	1120	loadk        r21   k15 ; k15 = 175
.line	1120	loadk        r22   k16 ; k16 = 18
.line	1120	loadk        r23   k17 ; k17 = 0
.line	1120	loadk        r24   k18 ; k18 = 70
.line	1120	loadk        r25   k11 ; k11 = 162
.line	1120	loadk        r26   k19 ; k19 = 69
.line	1120	loadk        r27   k20 ; k20 = 204
.line	1120	loadk        r28   k21 ; k21 = 5
.line	1120	loadk        r29   k22 ; k22 = 77
.line	1120	loadk        r30   k23 ; k23 = 81
.line	1120	loadk        r31   k10 ; k10 = 197
.line	1120	loadk        r32   k24 ; k24 = 184
.line	1120	loadk        r33   k25 ; k25 = 142
.line	1120	loadk        r34   k24 ; k24 = 184
.line	1120	loadk        r35   k13 ; k13 = 198
.line	1120	call          r5    31     2
.line	1120	move          r6    r3
.line	1120	call          r4     3     1
.line	1120	gettabup      r4    u0    k0 ; k0 = "log_tree"
.line	1120	gettabup      r5    u0   k26 ; k26 = "table"
.line	1120	gettable      r5    r5   k27 ; k27 = "concat"
.line	1120	newtable      r6     1     0
.line	1120	getupval      r7    u1
.line	1120	loadk         r8    k1 ; k1 = 149
.line	1120	loadk         r9    k2 ; k2 = 51
.line	1120	loadk        r10    k3 ; k3 = 25
.line	1120	loadk        r11    k4 ; k4 = 150
.line	1120	loadk        r12    k5 ; k5 = 134
.line	1120	loadk        r13    k6 ; k6 = 254
.line	1120	loadk        r14    k7 ; k7 = 126
.line	1120	loadk        r15    k8 ; k8 = 123
.line	1120	loadk        r16    k9 ; k9 = 86
.line	1120	loadk        r17   k10 ; k10 = 197
.line	1120	loadk        r18   k11 ; k11 = 162
.line	1120	loadk        r19    k4 ; k4 = 150
.line	1120	loadk        r20   k12 ; k12 = 191
.line	1120	loadk        r21   k13 ; k13 = 198
.line	1120	loadk        r22   k14 ; k14 = 108
.line	1120	loadk        r23   k15 ; k15 = 175
.line	1120	loadk        r24   k16 ; k16 = 18
.line	1120	loadk        r25   k17 ; k17 = 0
.line	1120	loadk        r26   k18 ; k18 = 70
.line	1120	loadk        r27   k11 ; k11 = 162
.line	1120	loadk        r28   k19 ; k19 = 69
.line	1120	loadk        r29   k20 ; k20 = 204
.line	1120	loadk        r30   k21 ; k21 = 5
.line	1120	loadk        r31   k22 ; k22 = 77
.line	1120	loadk        r32   k23 ; k23 = 81
.line	1120	loadk        r33   k10 ; k10 = 197
.line	1120	loadk        r34   k24 ; k24 = 184
.line	1120	loadk        r35   k25 ; k25 = 142
.line	1120	loadk        r36   k24 ; k24 = 184
.line	1120	loadk        r37   k13 ; k13 = 198
.line	1120	loadk        r38   k28 ; k28 = 46
.line	1120	loadk        r39   k29 ; k29 = 151
.line	1120	loadk        r40   k30 ; k30 = 93
.line	1120	loadk        r41   k31 ; k31 = 50
.line	1120	loadk        r42   k32 ; k32 = 90
.line	1120	loadk        r43   k33 ; k33 = 154
.line	1120	loadk        r44   k34 ; k34 = 66
.line	1120	loadk        r45   k35 ; k35 = 231
.line	1120	loadk        r46   k36 ; k36 = 24
.line	1120	loadk        r47   k23 ; k23 = 81
.line	1120	call          r7    41     2
.line	1120	getupval      r8    u1
.line	1120	loadk         r9   k37 ; k37 = 187
.line	1120	loadk        r10   k38 ; k38 = 26
.line	1120	loadk        r11   k39 ; k39 = 10
.line	1120	loadk        r12   k40 ; k40 = 186
.line	1120	loadk        r13   k41 ; k41 = 179
.line	1120	loadk        r14    k6 ; k6 = 254
.line	1120	loadk        r15   k42 ; k42 = 115
.line	1120	call          r8     8     0
.line	1120	setlist       r6     0     1
.line	1120	call          r5     2     2
.line	1120	gettable      r6    r0   k43 ; k43 = "MemberVoiceRecod"
.line	1120	call          r4     3     1
.line	1120	loadnil       r4     0
.line	1120	gettable      r5    r3   k44 ; k44 = "uid"
.line	1120	test          r5     0
.line	1120	jmp            0  l114
.line	1120	gettabup      r5    u0   k45 ; k45 = "slua"
.line	1120	gettable      r5    r5   k46 ; k46 = "isValid"
.line	1120	gettabup      r6    u0   k47 ; k47 = "CGameState"
.line	1120	call          r5     2     2
.line	1120	test          r5     0
.line	1120	jmp            0  l114
.line	1120	gettabup      r5    u0   k47 ; k47 = "CGameState"
.line	1120	self          r5    r5   k48 ; k48 = "GetPlayerStateByUID"
.line	1120	gettable      r7    r3   k44 ; k44 = "uid"
.line	1120	test          r7     1
.line	1120	jmp            0  l111
.line	1120	loadk         r7   k17 ; k17 = 0
.label	l111
.line	1120	call          r5     3     2
.line	1120	move          r4    r5
.line	1120	jmp            0  l147
.label	l114
.line	1120	gettable      r5    r3   k49 ; k49 = "user_info"
.line	1120	test          r5     0
.line	1120	jmp            0  l147
.line	1120	newtable      r5     0     0
.line	1120	gettable      r6    r3   k49 ; k49 = "user_info"
.line	1120	self          r6    r6   k50 ; k50 = "gmatch"
.line	1120	getupval      r8    u1
.line	1120	loadk         r9   k51 ; k51 = 240
.line	1120	loadk        r10   k52 ; k52 = 36
.line	1120	loadk        r11   k53 ; k53 = 6
.line	1120	loadk        r12   k54 ; k54 = 249
.line	1120	loadk        r13   k55 ; k55 = 141
.line	1120	loadk        r14   k40 ; k40 = 186
.line	1120	loadk        r15   k56 ; k56 = 62
.line	1120	call          r8     8     2
.line	1120	call          r6     3     4
.line	1120	jmp            0  l136
.line	1120	gettabup     r10    u0   k26 ; k26 = "table"
.line	1120	gettable     r10   r10   k57 ; k57 = "insert"
.line	1120	move         r11    r5
.line	1120	move         r12    r9
.line	1120	call         r10     3     1
.label	l136
.line	1120	move          r0    r0
.line	1120	move          r0    r0
.line	1120	gettable      r6    r5   k58 ; k58 = 1
.line	1120	test          r6     1
.line	1120	jmp            0  l143
.line	1120	getupval      r6    u1
.line	1120	call          r6     1     2
.label	l143
.line	1120	self          r7    r0   k59 ; k59 = "GetTeammatePlayerSta" (truncated)
.line	1120	move          r9    r6
.line	1120	call          r7     3     2
.line	1120	move          r4    r7
.label	l147
.line	1120	gettabup      r5    u0   k60 ; k60 = "print"
.line	1120	gettabup      r6    u0   k61 ; k61 = "bWriteLog"
.line	1120	test          r6     0
.line	1120	jmp            0  l221
.line	1120	gettabup      r6    u0   k62 ; k62 = "string"
.line	1120	gettable      r6    r6   k63 ; k63 = "format"
.line	1120	gettabup      r7    u0   k26 ; k26 = "table"
.line	1120	gettable      r7    r7   k27 ; k27 = "concat"
.line	1120	newtable      r8     1     0
.line	1120	getupval      r9    u1
.line	1120	loadk        r10    k1 ; k1 = 149
.line	1120	loadk        r11    k2 ; k2 = 51
.line	1120	loadk        r12    k3 ; k3 = 25
.line	1120	loadk        r13    k4 ; k4 = 150
.line	1120	loadk        r14    k5 ; k5 = 134
.line	1120	loadk        r15    k6 ; k6 = 254
.line	1120	loadk        r16    k7 ; k7 = 126
.line	1120	loadk        r17    k8 ; k8 = 123
.line	1120	loadk        r18    k9 ; k9 = 86
.line	1120	loadk        r19   k10 ; k10 = 197
.line	1120	loadk        r20   k11 ; k11 = 162
.line	1120	loadk        r21    k4 ; k4 = 150
.line	1120	loadk        r22   k12 ; k12 = 191
.line	1120	loadk        r23   k13 ; k13 = 198
.line	1120	loadk        r24   k14 ; k14 = 108
.line	1120	loadk        r25   k15 ; k15 = 175
.line	1120	loadk        r26   k16 ; k16 = 18
.line	1120	loadk        r27   k17 ; k17 = 0
.line	1120	loadk        r28   k18 ; k18 = 70
.line	1120	loadk        r29   k11 ; k11 = 162
.line	1120	loadk        r30   k19 ; k19 = 69
.line	1120	loadk        r31   k20 ; k20 = 204
.line	1120	loadk        r32   k21 ; k21 = 5
.line	1120	loadk        r33   k22 ; k22 = 77
.line	1120	loadk        r34   k23 ; k23 = 81
.line	1120	loadk        r35   k10 ; k10 = 197
.line	1120	loadk        r36   k24 ; k24 = 184
.line	1120	loadk        r37   k25 ; k25 = 142
.line	1120	loadk        r38   k24 ; k24 = 184
.line	1120	loadk        r39   k13 ; k13 = 198
.line	1120	loadk        r40   k64 ; k64 = 34
.line	1120	loadk        r41   k65 ; k65 = 250
.line	1120	loadk        r42   k22 ; k22 = 77
.line	1120	loadk        r43   k66 ; k66 = 11
.line	1120	loadk        r44   k30 ; k30 = 93
.line	1120	loadk        r45   k67 ; k67 = 158
.line	1120	loadk        r46   k30 ; k30 = 93
.line	1120	loadk        r47   k68 ; k68 = 220
.line	1120	loadk        r48   k69 ; k69 = 22
.line	1120	loadk        r49   k70 ; k70 = 76
.line	1120	call          r9    41     2
.line	1120	getupval     r10    u1
.line	1120	loadk        r11   k71 ; k71 = 189
.line	1120	loadk        r12   k72 ; k72 = 47
.line	1120	loadk        r13   k73 ; k73 = 52
.line	1120	loadk        r14   k74 ; k74 = 190
.line	1120	loadk        r15   k75 ; k75 = 169
.line	1120	loadk        r16   k76 ; k76 = 244
.line	1120	loadk        r17   k77 ; k77 = 101
.line	1120	loadk        r18   k78 ; k78 = 75
.line	1120	loadk        r19   k79 ; k79 = 71
.line	1120	loadk        r20   k80 ; k80 = 226
.line	1120	loadk        r21   k41 ; k41 = 179
.line	1120	loadk        r22   k81 ; k81 = 146
.line	1120	loadk        r23   k82 ; k82 = 241
.line	1120	loadk        r24    k4 ; k4 = 150
.line	1120	loadk        r25   k83 ; k83 = 109
.line	1120	call         r10    16     0
.line	1120	setlist       r8     0     1
.line	1120	call          r7     2     2
.line	1120	gettabup      r8    u0   k84 ; k84 = "tostring"
.line	1120	move          r9    r4
.line	1120	call          r8     2     0
.line	1120	call          r6     0     2
.label	l221
.line	1120	call          r5     2     1
.line	1120	gettabup      r5    u0   k45 ; k45 = "slua"
.line	1120	gettable      r5    r5   k46 ; k46 = "isValid"
.line	1120	move          r6    r4
.line	1120	call          r5     2     2
.line	1120	test          r5     0
.line	1120	jmp            0  l395
.line	1120	self          r5    r0   k85 ; k85 = "IsMasterOfTeammate"
.line	1120	move          r7    r4
.line	1120	call          r5     3     2
.line	1120	test          r5     0
.line	1120	jmp            0  l395
.line	1120	gettable      r5    r0   k43 ; k43 = "MemberVoiceRecod"
.line	1120	gettable      r6    r4   k86 ; k86 = "UID"
.line	1120	gettable      r5    r5    r6
.line	1120	eq             0    r5   k87 ; k87 = nil
.line	1120	jmp            0  l241
.line	1120	gettable      r5    r3   k88 ; k88 = "status"
.line	1120	eq             1    r5   k58 ; k58 = 1
.line	1120	jmp            0  l244
.label	l241
.line	1120	gettable      r5    r3   k88 ; k88 = "status"
.line	1120	eq             0    r5   k89 ; k89 = 2
.line	1120	jmp            0  l274
.label	l244
.line	1120	gettable      r5    r0   k43 ; k43 = "MemberVoiceRecod"
.line	1120	gettable      r6    r4   k86 ; k86 = "UID"
.line	1120	newtable      r7     0     2
.line	1120	gettabup      r8    u0   k45 ; k45 = "slua"
.line	1120	gettable      r8    r8   k91 ; k91 = "getMiliseconds"
.line	1120	call          r8     1     2
.line	1120	settable      r7   k90    r8 ; k90 = "StartTime"
.line	1120	gettable      r8    r0   k93 ; k93 = "CacheSessionName"
.line	1120	test          r8     1
.line	1120	jmp            0  l262
.line	1120	gettabup      r8    u0   k84 ; k84 = "tostring"
.line	1120	getupval      r9    u1
.line	1120	loadk        r10   k94 ; k94 = 182
.line	1120	loadk        r11   k95 ; k95 = 16
.line	1120	loadk        r12   k96 ; k96 = 54
.line	1120	loadk        r13   k40 ; k40 = 186
.line	1120	call          r9     5     2
.line	1120	call          r8     2     2
.label	l262
.line	1120	settable      r7   k92    r8 ; k92 = "SessionName"
.line	1120	settable      r5    r6    r7
.line	1120	gettable      r5    r0   k97 ; k97 = "CacheSessionNameClea" (truncated)
.line	1120	eq             1    r5   k87 ; k87 = nil
.line	1120	jmp            0  l478
.line	1120	settable      r0   k93   k87 ; k87 = nil
.line	1120	gettabup      r5    u0   k98 ; k98 = "Game"
.line	1120	self          r5    r5   k99 ; k99 = "ClearTimer"
.line	1120	gettable      r7    r0   k97 ; k97 = "CacheSessionNameClea" (truncated)
.line	1120	call          r5     3     1
.line	1120	settable      r0   k97   k87 ; k87 = nil
.line	1120	jmp            0  l478
.label	l274
.line	1120	gettable      r5    r3   k88 ; k88 = "status"
.line	1120	eq             0    r5   k17 ; k17 = 0
.line	1120	jmp            0  l478
.line	1120	gettable      r5    r0   k43 ; k43 = "MemberVoiceRecod"
.line	1120	gettable      r6    r4   k86 ; k86 = "UID"
.line	1120	gettable      r5    r5    r6
.line	1120	test          r5     0
.line	1120	jmp            0  l478
.line	1120	gettabup      r5    u0   k45 ; k45 = "slua"
.line	1120	gettable      r5    r5   k91 ; k91 = "getMiliseconds"
.line	1120	call          r5     1     2
.line	1120	gettable      r6    r0   k43 ; k43 = "MemberVoiceRecod"
.line	1120	gettable      r7    r4   k86 ; k86 = "UID"
.line	1120	gettable      r6    r6    r7
.line	1120	gettable      r6    r6   k90 ; k90 = "StartTime"
.line	1120	sub           r5    r5    r6
.line	1120	gettabup      r6    u0   k62 ; k62 = "string"
.line	1120	gettable      r6    r6   k63 ; k63 = "format"
.line	1120	getupval      r7    u1
.line	1120	loadk         r8  k100 ; k100 = 253
.line	1120	loadk         r9  k101 ; k101 = 12
.line	1120	loadk        r10   k52 ; k52 = 36
.line	1120	loadk        r11   k65 ; k65 = 250
.line	1120	loadk        r12  k102 ; k102 = 163
.line	1120	loadk        r13  k103 ; k103 = 237
.line	1120	loadk        r14   k31 ; k31 = 50
.line	1120	loadk        r15  k104 ; k104 = 107
.line	1120	loadk        r16  k105 ; k105 = 79
.line	1120	loadk        r17  k106 ; k106 = 166
.line	1120	loadk        r18  k107 ; k107 = 180
.line	1120	call          r7    12     2
.line	1120	gettable      r8    r0   k43 ; k43 = "MemberVoiceRecod"
.line	1120	gettable      r9    r4   k86 ; k86 = "UID"
.line	1120	gettable      r8    r8    r9
.line	1120	gettable      r8    r8   k92 ; k92 = "SessionName"
.line	1120	gettabup      r9    u0   k62 ; k62 = "string"
.line	1120	gettable      r9    r9   k63 ; k63 = "format"
.line	1120	getupval     r10    u1
.line	1120	loadk        r11  k100 ; k100 = 253
.line	1120	loadk        r12   k23 ; k23 = 81
.line	1120	loadk        r13  k108 ; k108 = 104
.line	1120	loadk        r14  k109 ; k109 = 185
.line	1120	call         r10     5     2
.line	1120	self         r11    r0  k110 ; k110 = "GetCurrentServerTime" (truncated)
.line	1120	call         r11     2     0
.line	1120	call          r9     0     2
.line	1120	gettabup     r10    u0   k62 ; k62 = "string"
.line	1120	gettable     r10   r10   k63 ; k63 = "format"
.line	1120	getupval     r11    u1
.line	1120	loadk        r12  k100 ; k100 = 253
.line	1120	loadk        r13   k23 ; k23 = 81
.line	1120	loadk        r14  k108 ; k108 = 104
.line	1120	loadk        r15  k109 ; k109 = 185
.line	1120	call         r11     5     2
.line	1120	move         r12    r5
.line	1120	call         r10     3     2
.line	1120	gettabup     r11    u0   k84 ; k84 = "tostring"
.line	1120	gettable     r12    r4   k86 ; k86 = "UID"
.line	1120	call         r11     2     0
.line	1120	call          r6     0     2
.line	1120	gettabup      r7    u0   k60 ; k60 = "print"
.line	1120	gettabup      r8    u0   k61 ; k61 = "bWriteLog"
.line	1120	test          r8     0
.line	1120	jmp            0  l385
.line	1120	gettabup      r8    u0   k62 ; k62 = "string"
.line	1120	gettable      r8    r8   k63 ; k63 = "format"
.line	1120	getupval      r9    u1
.line	1120	loadk        r10    k1 ; k1 = 149
.line	1120	loadk        r11    k2 ; k2 = 51
.line	1120	loadk        r12    k3 ; k3 = 25
.line	1120	loadk        r13    k4 ; k4 = 150
.line	1120	loadk        r14    k5 ; k5 = 134
.line	1120	loadk        r15    k6 ; k6 = 254
.line	1120	loadk        r16    k7 ; k7 = 126
.line	1120	loadk        r17    k8 ; k8 = 123
.line	1120	loadk        r18    k9 ; k9 = 86
.line	1120	loadk        r19   k10 ; k10 = 197
.line	1120	loadk        r20   k11 ; k11 = 162
.line	1120	loadk        r21    k4 ; k4 = 150
.line	1120	loadk        r22   k12 ; k12 = 191
.line	1120	loadk        r23   k13 ; k13 = 198
.line	1120	loadk        r24   k14 ; k14 = 108
.line	1120	loadk        r25   k15 ; k15 = 175
.line	1120	loadk        r26   k16 ; k16 = 18
.line	1120	loadk        r27   k17 ; k17 = 0
.line	1120	loadk        r28   k18 ; k18 = 70
.line	1120	loadk        r29   k11 ; k11 = 162
.line	1120	loadk        r30   k19 ; k19 = 69
.line	1120	loadk        r31   k20 ; k20 = 204
.line	1120	loadk        r32   k21 ; k21 = 5
.line	1120	loadk        r33   k22 ; k22 = 77
.line	1120	loadk        r34   k23 ; k23 = 81
.line	1120	loadk        r35   k10 ; k10 = 197
.line	1120	loadk        r36   k24 ; k24 = 184
.line	1120	loadk        r37   k25 ; k25 = 142
.line	1120	loadk        r38   k24 ; k24 = 184
.line	1120	loadk        r39   k13 ; k13 = 198
.line	1120	loadk        r40   k64 ; k64 = 34
.line	1120	loadk        r41   k65 ; k65 = 250
.line	1120	loadk        r42  k111 ; k111 = 113
.line	1120	loadk        r43  k112 ; k112 = 49
.line	1120	loadk        r44  k113 ; k113 = 94
.line	1120	loadk        r45  k114 ; k114 = 144
.line	1120	loadk        r46   k39 ; k39 = 10
.line	1120	loadk        r47  k115 ; k115 = 148
.line	1120	loadk        r48  k116 ; k116 = 4
.line	1120	call          r9    40     2
.line	1120	gettabup     r10    u0   k84 ; k84 = "tostring"
.line	1120	move         r11    r6
.line	1120	call         r10     2     0
.line	1120	call          r8     0     2
.label	l385
.line	1120	call          r7     2     1
.line	1120	gettable      r7    r0   k43 ; k43 = "MemberVoiceRecod"
.line	1120	gettable      r8    r4   k86 ; k86 = "UID"
.line	1120	settable      r7    r8   k87 ; k87 = nil
.line	1120	self          r7    r0  k117 ; k117 = "RPC_Server_SendAIVoi" (truncated)
.line	1120	gettable      r9    r4   k86 ; k86 = "UID"
.line	1120	gettabup     r10    u2  k118 ; k118 = "AIVoiceRecord"
.line	1120	move         r11    r6
.line	1120	call          r7     5     1
.line	1120	jmp            0  l478
.label	l395
.line	1120	gettabup      r5    u0   k60 ; k60 = "print"
.line	1120	gettabup      r6    u0   k61 ; k61 = "bWriteLog"
.line	1120	test          r6     0
.line	1120	jmp            0  l477
.line	1120	gettabup      r6    u0   k62 ; k62 = "string"
.line	1120	gettable      r6    r6   k63 ; k63 = "format"
.line	1120	gettabup      r7    u0   k26 ; k26 = "table"
.line	1120	gettable      r7    r7   k27 ; k27 = "concat"
.line	1120	newtable      r8     1     0
.line	1120	getupval      r9    u1
.line	1120	loadk        r10    k1 ; k1 = 149
.line	1120	loadk        r11    k2 ; k2 = 51
.line	1120	loadk        r12    k3 ; k3 = 25
.line	1120	loadk        r13    k4 ; k4 = 150
.line	1120	loadk        r14    k5 ; k5 = 134
.line	1120	loadk        r15    k6 ; k6 = 254
.line	1120	loadk        r16    k7 ; k7 = 126
.line	1120	loadk        r17    k8 ; k8 = 123
.line	1120	loadk        r18    k9 ; k9 = 86
.line	1120	loadk        r19   k10 ; k10 = 197
.line	1120	loadk        r20   k11 ; k11 = 162
.line	1120	loadk        r21    k4 ; k4 = 150
.line	1120	loadk        r22   k12 ; k12 = 191
.line	1120	loadk        r23   k13 ; k13 = 198
.line	1120	loadk        r24   k14 ; k14 = 108
.line	1120	loadk        r25   k15 ; k15 = 175
.line	1120	loadk        r26   k16 ; k16 = 18
.line	1120	loadk        r27   k17 ; k17 = 0
.line	1120	loadk        r28   k18 ; k18 = 70
.line	1120	loadk        r29   k11 ; k11 = 162
.line	1120	loadk        r30   k19 ; k19 = 69
.line	1120	loadk        r31   k20 ; k20 = 204
.line	1120	loadk        r32   k21 ; k21 = 5
.line	1120	loadk        r33   k22 ; k22 = 77
.line	1120	loadk        r34   k23 ; k23 = 81
.line	1120	loadk        r35   k10 ; k10 = 197
.line	1120	loadk        r36   k24 ; k24 = 184
.line	1120	loadk        r37   k25 ; k25 = 142
.line	1120	loadk        r38   k24 ; k24 = 184
.line	1120	loadk        r39   k13 ; k13 = 198
.line	1120	loadk        r40   k64 ; k64 = 34
.line	1120	loadk        r41   k65 ; k65 = 250
.line	1120	loadk        r42   k22 ; k22 = 77
.line	1120	loadk        r43   k66 ; k66 = 11
.line	1120	loadk        r44   k30 ; k30 = 93
.line	1120	loadk        r45   k67 ; k67 = 158
.line	1120	loadk        r46   k30 ; k30 = 93
.line	1120	loadk        r47   k68 ; k68 = 220
.line	1120	loadk        r48   k69 ; k69 = 22
.line	1120	loadk        r49   k70 ; k70 = 76
.line	1120	call          r9    41     2
.line	1120	getupval     r10    u1
.line	1120	loadk        r11   k71 ; k71 = 189
.line	1120	loadk        r12   k72 ; k72 = 47
.line	1120	loadk        r13   k73 ; k73 = 52
.line	1120	loadk        r14   k74 ; k74 = 190
.line	1120	loadk        r15   k75 ; k75 = 169
.line	1120	loadk        r16   k76 ; k76 = 244
.line	1120	loadk        r17   k77 ; k77 = 101
.line	1120	loadk        r18   k78 ; k78 = 75
.line	1120	loadk        r19   k79 ; k79 = 71
.line	1120	loadk        r20   k80 ; k80 = 226
.line	1120	loadk        r21   k41 ; k41 = 179
.line	1120	loadk        r22   k81 ; k81 = 146
.line	1120	loadk        r23  k119 ; k119 = 235
.line	1120	loadk        r24  k120 ; k120 = 218
.line	1120	loadk        r25   k83 ; k83 = 109
.line	1120	loadk        r26  k121 ; k121 = 234
.line	1120	loadk        r27   k18 ; k18 = 70
.line	1120	loadk        r28  k122 ; k122 = 32
.line	1120	loadk        r29  k123 ; k123 = 92
.line	1120	loadk        r30  k124 ; k124 = 207
.line	1120	loadk        r31   k22 ; k22 = 77
.line	1120	loadk        r32  k125 ; k125 = 192
.line	1120	loadk        r33  k126 ; k126 = 20
.line	1120	loadk        r34  k123 ; k123 = 92
.line	1120	loadk        r35   k18 ; k18 = 70
.line	1120	loadk        r36  k127 ; k127 = 225
.line	1120	call         r10    27     0
.line	1120	setlist       r8     0     1
.line	1120	call          r7     2     2
.line	1120	call          r6     2     2
.label	l477
.line	1120	call          r5     2     1
.label	l478
.line	1120	return        r0     1
.line	1120	gettabup      r2    u0   k70 ; k70 = 76
.line	1120	move          r0    r0
.line	1120	return        r0     1

.function	main/f62

.source	null
.linedefined	1158
.lastlinedefined	1172
.numparams	5
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	0
.constant	k23	70
.constant	k24	172
.constant	k25	79
.constant	k26	204
.constant	k27	10
.constant	k28	71
.constant	k29	77
.constant	k30	222
.constant	k31	178
.constant	k32	138
.constant	k33	185
.constant	k34	124
.constant	k35	147
.constant	k36	75
.constant	k37	12
.constant	k38	72
.constant	k39	154
.constant	k40	81
.constant	k41	218
.constant	k42	30
.constant	k43	83
.constant	k44	120
.constant	k45	140
.constant	k46	164
.constant	k47	240
.constant	k48	99
.constant	k49	109
.constant	k50	64
.constant	k51	226
.constant	k52	132
.constant	k53	231
.constant	k54	76
.constant	k55	165
.constant	k56	34
.constant	k57	202
.constant	k58	141
.constant	k59	101
.constant	k60	181
.constant	k61	130
.constant	k62	169
.constant	k63	153
.constant	k64	43
.constant	k65	20
.constant	k66	127
.constant	k67	85
.constant	k68	195
.constant	k69	62
.constant	k70	190
.constant	k71	16
.constant	k72	98
.constant	k73	250
.constant	k74	163
.constant	k75	"tostring"
.constant	k76	"gmatch"
.constant	k77	36
.constant	k78	6
.constant	k79	249
.constant	k80	186
.constant	k81	"insert"
.constant	k82	"GetNeutralNPCUIDByOpenID"
.constant	k83	1
.constant	k84	"_HandleNeutralNPCMemberVoice"

.line	1158	gettabup      r5    u0    k0 ; k0 = "print"
.line	1158	gettabup      r6    u0    k1 ; k1 = "bWriteLog"
.line	1158	test          r6     0
.line	1158	jmp            0  l116
.line	1158	gettabup      r6    u0    k2 ; k2 = "string"
.line	1158	gettable      r6    r6    k3 ; k3 = "format"
.line	1158	gettabup      r7    u0    k4 ; k4 = "table"
.line	1158	gettable      r7    r7    k5 ; k5 = "concat"
.line	1158	newtable      r8     2     0
.line	1158	getupval      r9    u1
.line	1158	loadk        r10    k6 ; k6 = 149
.line	1158	loadk        r11    k7 ; k7 = 51
.line	1158	loadk        r12    k8 ; k8 = 25
.line	1158	loadk        r13    k9 ; k9 = 150
.line	1158	loadk        r14   k10 ; k10 = 134
.line	1158	loadk        r15   k11 ; k11 = 254
.line	1158	loadk        r16   k12 ; k12 = 126
.line	1158	loadk        r17   k13 ; k13 = 123
.line	1158	loadk        r18   k14 ; k14 = 86
.line	1158	loadk        r19   k15 ; k15 = 197
.line	1158	loadk        r20   k16 ; k16 = 162
.line	1158	loadk        r21    k9 ; k9 = 150
.line	1158	loadk        r22   k17 ; k17 = 191
.line	1158	loadk        r23   k18 ; k18 = 198
.line	1158	loadk        r24   k19 ; k19 = 108
.line	1158	loadk        r25   k20 ; k20 = 175
.line	1158	loadk        r26   k21 ; k21 = 18
.line	1158	loadk        r27   k22 ; k22 = 0
.line	1158	loadk        r28   k23 ; k23 = 70
.line	1158	loadk        r29   k24 ; k24 = 172
.line	1158	loadk        r30   k25 ; k25 = 79
.line	1158	loadk        r31   k26 ; k26 = 204
.line	1158	loadk        r32   k27 ; k27 = 10
.line	1158	loadk        r33   k28 ; k28 = 71
.line	1158	loadk        r34   k29 ; k29 = 77
.line	1158	loadk        r35   k30 ; k30 = 222
.line	1158	loadk        r36   k31 ; k31 = 178
.line	1158	loadk        r37   k32 ; k32 = 138
.line	1158	loadk        r38   k33 ; k33 = 185
.line	1158	loadk        r39   k18 ; k18 = 198
.line	1158	loadk        r40   k34 ; k34 = 124
.line	1158	loadk        r41   k35 ; k35 = 147
.line	1158	loadk        r42   k36 ; k36 = 75
.line	1158	loadk        r43   k37 ; k37 = 12
.line	1158	loadk        r44   k38 ; k38 = 72
.line	1158	loadk        r45   k39 ; k39 = 154
.line	1158	loadk        r46   k40 ; k40 = 81
.line	1158	loadk        r47   k41 ; k41 = 218
.line	1158	loadk        r48   k42 ; k42 = 30
.line	1158	loadk        r49   k14 ; k14 = 86
.line	1158	call          r9    41     2
.line	1158	getupval     r10    u1
.line	1158	loadk        r11   k17 ; k17 = 191
.line	1158	loadk        r12   k43 ; k43 = 83
.line	1158	loadk        r13   k44 ; k44 = 120
.line	1158	loadk        r14   k45 ; k45 = 140
.line	1158	loadk        r15   k46 ; k46 = 164
.line	1158	loadk        r16   k47 ; k47 = 240
.line	1158	loadk        r17   k48 ; k48 = 99
.line	1158	loadk        r18   k49 ; k49 = 109
.line	1158	loadk        r19   k50 ; k50 = 64
.line	1158	loadk        r20   k33 ; k33 = 185
.line	1158	loadk        r21   k51 ; k51 = 226
.line	1158	loadk        r22   k52 ; k52 = 132
.line	1158	loadk        r23   k53 ; k53 = 231
.line	1158	loadk        r24   k35 ; k35 = 147
.line	1158	loadk        r25   k54 ; k54 = 76
.line	1158	loadk        r26   k55 ; k55 = 165
.line	1158	loadk        r27   k28 ; k28 = 71
.line	1158	loadk        r28   k56 ; k56 = 34
.line	1158	loadk        r29   k21 ; k21 = 18
.line	1158	loadk        r30   k57 ; k57 = 202
.line	1158	loadk        r31   k43 ; k43 = 83
.line	1158	loadk        r32   k58 ; k58 = 141
.line	1158	loadk        r33   k28 ; k28 = 71
.line	1158	loadk        r34   k59 ; k59 = 101
.line	1158	loadk        r35   k23 ; k23 = 70
.line	1158	loadk        r36   k11 ; k11 = 254
.line	1158	loadk        r37   k60 ; k60 = 181
.line	1158	loadk        r38   k61 ; k61 = 130
.line	1158	loadk        r39   k62 ; k62 = 169
.line	1158	loadk        r40   k63 ; k63 = 153
.line	1158	loadk        r41   k64 ; k64 = 43
.line	1158	loadk        r42   k62 ; k62 = 169
.line	1158	loadk        r43   k65 ; k65 = 20
.line	1158	loadk        r44   k66 ; k66 = 127
.line	1158	loadk        r45   k49 ; k49 = 109
.line	1158	loadk        r46   k45 ; k45 = 140
.line	1158	loadk        r47   k67 ; k67 = 85
.line	1158	loadk        r48   k68 ; k68 = 195
.line	1158	loadk        r49   k69 ; k69 = 62
.line	1158	loadk        r50   k14 ; k14 = 86
.line	1158	call         r10    41     2
.line	1158	getupval     r11    u1
.line	1158	loadk        r12   k70 ; k70 = 190
.line	1158	loadk        r13   k71 ; k71 = 16
.line	1158	loadk        r14   k72 ; k72 = 98
.line	1158	loadk        r15   k73 ; k73 = 250
.line	1158	loadk        r16   k74 ; k74 = 163
.line	1158	call         r11     6     0
.line	1158	setlist       r8     0     1
.line	1158	call          r7     2     2
.line	1158	gettabup      r8    u0   k75 ; k75 = "tostring"
.line	1158	move          r9    r1
.line	1158	call          r8     2     2
.line	1158	gettabup      r9    u0   k75 ; k75 = "tostring"
.line	1158	move         r10    r2
.line	1158	call          r9     2     2
.line	1158	gettabup     r10    u0   k75 ; k75 = "tostring"
.line	1158	move         r11    r3
.line	1158	call         r10     2     2
.line	1158	gettabup     r11    u0   k75 ; k75 = "tostring"
.line	1158	move         r12    r4
.line	1158	call         r11     2     0
.line	1158	call          r6     0     2
.label	l116
.line	1158	call          r5     2     1
.line	1158	test          r4     0
.line	1158	jmp            0  l123
.line	1158	getupval      r5    u1
.line	1158	call          r5     1     2
.line	1158	eq             0    r4    r5
.line	1158	jmp            0  l124
.label	l123
.line	1158	return        r0     1
.label	l124
.line	1158	newtable      r5     0     0
.line	1158	self          r6    r4   k76 ; k76 = "gmatch"
.line	1158	getupval      r8    u1
.line	1158	loadk         r9   k47 ; k47 = 240
.line	1158	loadk        r10   k77 ; k77 = 36
.line	1158	loadk        r11   k78 ; k78 = 6
.line	1158	loadk        r12   k79 ; k79 = 249
.line	1158	loadk        r13   k58 ; k58 = 141
.line	1158	loadk        r14   k80 ; k80 = 186
.line	1158	loadk        r15   k69 ; k69 = 62
.line	1158	call          r8     8     2
.line	1158	call          r6     3     4
.line	1158	jmp            0  l142
.line	1158	gettabup     r10    u0    k4 ; k4 = "table"
.line	1158	gettable     r10   r10   k81 ; k81 = "insert"
.line	1158	move         r11    r5
.line	1158	move         r12    r9
.line	1158	call         r10     3     1
.label	l142
.line	1158	move          r0    r0
.line	1158	move          r0    r0
.line	1158	self          r6    r0   k82 ; k82 = "GetNeutralNPCUIDByOp" (truncated)
.line	1158	gettable      r8    r5   k83 ; k83 = 1
.line	1158	test          r8     1
.line	1158	jmp            0  l150
.line	1158	getupval      r8    u1
.line	1158	call          r8     1     2
.label	l150
.line	1158	call          r6     3     2
.line	1158	test          r6     1
.line	1158	jmp            0  l154
.line	1158	return        r0     1
.label	l154
.line	1158	self          r7    r0   k84 ; k84 = "_HandleNeutralNPCMem" (truncated)
.line	1158	move          r9    r6
.line	1158	move         r10    r1
.line	1158	call          r7     4     1
.line	1158	return        r0     1
.line	1158	move          r0    r0
.line	1158	move          r0    r0
.line	1158	move          r0    r0
.line	1158	move          r0    r0
.line	1158	return        r0     1

.function	main/f63

.source	null
.linedefined	1174
.lastlinedefined	1194
.numparams	3
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	7	true

.constant	k0	1
.constant	k1	2
.constant	k2	"MemberVoiceRecod"
.constant	k3	nil
.constant	k4	"StartTime"
.constant	k5	"slua"
.constant	k6	"getMiliseconds"
.constant	k7	"SessionName"
.constant	k8	"CacheSessionName"
.constant	k9	"tostring"
.constant	k10	182
.constant	k11	16
.constant	k12	54
.constant	k13	186
.constant	k14	"CacheSessionNameClearTimer"
.constant	k15	"Game"
.constant	k16	"ClearTimer"
.constant	k17	0
.constant	k18	"string"
.constant	k19	"format"
.constant	k20	253
.constant	k21	12
.constant	k22	36
.constant	k23	250
.constant	k24	163
.constant	k25	237
.constant	k26	50
.constant	k27	107
.constant	k28	79
.constant	k29	166
.constant	k30	180
.constant	k31	81
.constant	k32	104
.constant	k33	185
.constant	k34	"GetCurrentServerTimeSec"
.constant	k35	"print"
.constant	k36	"bWriteLog"
.constant	k37	"table"
.constant	k38	"concat"
.constant	k39	149
.constant	k40	51
.constant	k41	25
.constant	k42	150
.constant	k43	134
.constant	k44	254
.constant	k45	126
.constant	k46	123
.constant	k47	86
.constant	k48	197
.constant	k49	162
.constant	k50	191
.constant	k51	198
.constant	k52	108
.constant	k53	175
.constant	k54	18
.constant	k55	96
.constant	k56	142
.constant	k57	78
.constant	k58	11
.constant	k59	77
.constant	k60	109
.constant	k61	246
.constant	k62	147
.constant	k63	169
.constant	k64	194
.constant	k65	98
.constant	k66	148
.constant	k67	28
.constant	k68	117
.constant	k69	154
.constant	k70	93
.constant	k71	211
.constant	k72	74
.constant	k73	49
.constant	k74	188
.constant	k75	181
.constant	k76	189
.constant	k77	55
.constant	k78	89
.constant	k79	122
.constant	k80	213
.constant	k81	168
.constant	k82	158
.constant	k83	214
.constant	k84	76
.constant	k85	75
.constant	k86	32
.constant	k87	90
.constant	k88	139
.constant	k89	232
.constant	k90	9
.constant	k91	242
.constant	k92	"RPC_Server_SendAIVoiceTLog"
.constant	k93	"AIVoiceRecord"

.line	1174	eq             1    r2    k0 ; k0 = 1
.line	1174	jmp            0    l5
.line	1174	eq             0    r2    k1 ; k1 = 2
.line	1174	jmp            0   l38
.label	l5
.line	1174	gettable      r3    r0    k2 ; k2 = "MemberVoiceRecod"
.line	1174	gettable      r3    r3    r1
.line	1174	eq             0    r3    k3 ; k3 = nil
.line	1174	jmp            0  l187
.line	1174	gettable      r3    r0    k2 ; k2 = "MemberVoiceRecod"
.line	1174	newtable      r4     0     2
.line	1174	gettabup      r5    u0    k5 ; k5 = "slua"
.line	1174	gettable      r5    r5    k6 ; k6 = "getMiliseconds"
.line	1174	call          r5     1     2
.line	1174	settable      r4    k4    r5 ; k4 = "StartTime"
.line	1174	gettable      r5    r0    k8 ; k8 = "CacheSessionName"
.line	1174	test          r5     1
.line	1174	jmp            0   l26
.line	1174	gettabup      r5    u0    k9 ; k9 = "tostring"
.line	1174	getupval      r6    u1
.line	1174	loadk         r7   k10 ; k10 = 182
.line	1174	loadk         r8   k11 ; k11 = 16
.line	1174	loadk         r9   k12 ; k12 = 54
.line	1174	loadk        r10   k13 ; k13 = 186
.line	1174	call          r6     5     2
.line	1174	call          r5     2     2
.label	l26
.line	1174	settable      r4    k7    r5 ; k7 = "SessionName"
.line	1174	settable      r3    r1    r4
.line	1174	gettable      r3    r0   k14 ; k14 = "CacheSessionNameClea" (truncated)
.line	1174	eq             1    r3    k3 ; k3 = nil
.line	1174	jmp            0  l187
.line	1174	settable      r0    k8    k3 ; k3 = nil
.line	1174	gettabup      r3    u0   k15 ; k15 = "Game"
.line	1174	self          r3    r3   k16 ; k16 = "ClearTimer"
.line	1174	gettable      r5    r0   k14 ; k14 = "CacheSessionNameClea" (truncated)
.line	1174	call          r3     3     1
.line	1174	settable      r0   k14    k3 ; k3 = nil
.line	1174	jmp            0  l187
.label	l38
.line	1174	eq             0    r2   k17 ; k17 = 0
.line	1174	jmp            0  l187
.line	1174	gettable      r3    r0    k2 ; k2 = "MemberVoiceRecod"
.line	1174	gettable      r3    r3    r1
.line	1174	test          r3     0
.line	1174	jmp            0  l187
.line	1174	gettabup      r3    u0    k5 ; k5 = "slua"
.line	1174	gettable      r3    r3    k6 ; k6 = "getMiliseconds"
.line	1174	call          r3     1     2
.line	1174	gettable      r4    r0    k2 ; k2 = "MemberVoiceRecod"
.line	1174	gettable      r4    r4    r1
.line	1174	gettable      r4    r4    k4 ; k4 = "StartTime"
.line	1174	sub           r3    r3    r4
.line	1174	gettabup      r4    u0   k18 ; k18 = "string"
.line	1174	gettable      r4    r4   k19 ; k19 = "format"
.line	1174	getupval      r5    u1
.line	1174	loadk         r6   k20 ; k20 = 253
.line	1174	loadk         r7   k21 ; k21 = 12
.line	1174	loadk         r8   k22 ; k22 = 36
.line	1174	loadk         r9   k23 ; k23 = 250
.line	1174	loadk        r10   k24 ; k24 = 163
.line	1174	loadk        r11   k25 ; k25 = 237
.line	1174	loadk        r12   k26 ; k26 = 50
.line	1174	loadk        r13   k27 ; k27 = 107
.line	1174	loadk        r14   k28 ; k28 = 79
.line	1174	loadk        r15   k29 ; k29 = 166
.line	1174	loadk        r16   k30 ; k30 = 180
.line	1174	call          r5    12     2
.line	1174	gettable      r6    r0    k2 ; k2 = "MemberVoiceRecod"
.line	1174	gettable      r6    r6    r1
.line	1174	gettable      r6    r6    k7 ; k7 = "SessionName"
.line	1174	gettabup      r7    u0   k18 ; k18 = "string"
.line	1174	gettable      r7    r7   k19 ; k19 = "format"
.line	1174	getupval      r8    u1
.line	1174	loadk         r9   k20 ; k20 = 253
.line	1174	loadk        r10   k31 ; k31 = 81
.line	1174	loadk        r11   k32 ; k32 = 104
.line	1174	loadk        r12   k33 ; k33 = 185
.line	1174	call          r8     5     2
.line	1174	self          r9    r0   k34 ; k34 = "GetCurrentServerTime" (truncated)
.line	1174	call          r9     2     0
.line	1174	call          r7     0     2
.line	1174	gettabup      r8    u0   k18 ; k18 = "string"
.line	1174	gettable      r8    r8   k19 ; k19 = "format"
.line	1174	getupval      r9    u1
.line	1174	loadk        r10   k20 ; k20 = 253
.line	1174	loadk        r11   k31 ; k31 = 81
.line	1174	loadk        r12   k32 ; k32 = 104
.line	1174	loadk        r13   k33 ; k33 = 185
.line	1174	call          r9     5     2
.line	1174	move         r10    r3
.line	1174	call          r8     3     2
.line	1174	gettabup      r9    u0    k9 ; k9 = "tostring"
.line	1174	move         r10    r1
.line	1174	call          r9     2     0
.line	1174	call          r4     0     2
.line	1174	gettabup      r5    u0   k35 ; k35 = "print"
.line	1174	gettabup      r6    u0   k36 ; k36 = "bWriteLog"
.line	1174	test          r6     0
.line	1174	jmp            0  l179
.line	1174	gettabup      r6    u0   k18 ; k18 = "string"
.line	1174	gettable      r6    r6   k19 ; k19 = "format"
.line	1174	gettabup      r7    u0   k37 ; k37 = "table"
.line	1174	gettable      r7    r7   k38 ; k38 = "concat"
.line	1174	newtable      r8     1     0
.line	1174	getupval      r9    u1
.line	1174	loadk        r10   k39 ; k39 = 149
.line	1174	loadk        r11   k40 ; k40 = 51
.line	1174	loadk        r12   k41 ; k41 = 25
.line	1174	loadk        r13   k42 ; k42 = 150
.line	1174	loadk        r14   k43 ; k43 = 134
.line	1174	loadk        r15   k44 ; k44 = 254
.line	1174	loadk        r16   k45 ; k45 = 126
.line	1174	loadk        r17   k46 ; k46 = 123
.line	1174	loadk        r18   k47 ; k47 = 86
.line	1174	loadk        r19   k48 ; k48 = 197
.line	1174	loadk        r20   k49 ; k49 = 162
.line	1174	loadk        r21   k42 ; k42 = 150
.line	1174	loadk        r22   k50 ; k50 = 191
.line	1174	loadk        r23   k51 ; k51 = 198
.line	1174	loadk        r24   k52 ; k52 = 108
.line	1174	loadk        r25   k53 ; k53 = 175
.line	1174	loadk        r26   k54 ; k54 = 18
.line	1174	loadk        r27   k11 ; k11 = 16
.line	1174	loadk        r28   k55 ; k55 = 96
.line	1174	loadk        r29   k56 ; k56 = 142
.line	1174	loadk        r30   k57 ; k57 = 78
.line	1174	loadk        r31   k48 ; k48 = 197
.line	1174	loadk        r32   k58 ; k58 = 11
.line	1174	loadk        r33   k59 ; k59 = 77
.line	1174	loadk        r34   k60 ; k60 = 109
.line	1174	loadk        r35   k61 ; k61 = 246
.line	1174	loadk        r36   k49 ; k49 = 162
.line	1174	loadk        r37   k62 ; k62 = 147
.line	1174	loadk        r38   k63 ; k63 = 169
.line	1174	loadk        r39   k64 ; k64 = 194
.line	1174	loadk        r40   k65 ; k65 = 98
.line	1174	loadk        r41   k66 ; k66 = 148
.line	1174	loadk        r42   k32 ; k32 = 104
.line	1174	loadk        r43   k67 ; k67 = 28
.line	1174	loadk        r44   k68 ; k68 = 117
.line	1174	loadk        r45   k69 ; k69 = 154
.line	1174	loadk        r46   k70 ; k70 = 93
.line	1174	loadk        r47   k71 ; k71 = 211
.line	1174	loadk        r48   k54 ; k54 = 18
.line	1174	loadk        r49   k72 ; k72 = 74
.line	1174	call          r9    41     2
.line	1174	getupval     r10    u1
.line	1174	loadk        r11   k56 ; k56 = 142
.line	1174	loadk        r12   k11 ; k11 = 16
.line	1174	loadk        r13   k73 ; k73 = 49
.line	1174	loadk        r14   k74 ; k74 = 188
.line	1174	loadk        r15   k75 ; k75 = 181
.line	1174	loadk        r16   k76 ; k76 = 189
.line	1174	loadk        r17   k77 ; k77 = 55
.line	1174	loadk        r18   k78 ; k78 = 89
.line	1174	loadk        r19   k79 ; k79 = 122
.line	1174	loadk        r20   k80 ; k80 = 213
.line	1174	loadk        r21   k81 ; k81 = 168
.line	1174	loadk        r22   k82 ; k82 = 158
.line	1174	loadk        r23   k81 ; k81 = 168
.line	1174	loadk        r24   k83 ; k83 = 214
.line	1174	loadk        r25   k84 ; k84 = 76
.line	1174	loadk        r26   k53 ; k53 = 175
.line	1174	loadk        r27   k85 ; k85 = 75
.line	1174	loadk        r28   k86 ; k86 = 32
.line	1174	loadk        r29   k87 ; k87 = 90
.line	1174	loadk        r30   k88 ; k88 = 139
.line	1174	loadk        r31   k17 ; k17 = 0
.line	1174	loadk        r32   k89 ; k89 = 232
.line	1174	loadk        r33   k90 ; k90 = 9
.line	1174	loadk        r34   k57 ; k57 = 78
.line	1174	loadk        r35   k84 ; k84 = 76
.line	1174	loadk        r36   k63 ; k63 = 169
.line	1174	loadk        r37   k91 ; k91 = 242
.line	1174	loadk        r38   k66 ; k66 = 148
.line	1174	call         r10    29     0
.line	1174	setlist       r8     0     1
.line	1174	call          r7     2     2
.line	1174	move          r8    r4
.line	1174	call          r6     3     2
.label	l179
.line	1174	call          r5     2     1
.line	1174	gettable      r5    r0    k2 ; k2 = "MemberVoiceRecod"
.line	1174	settable      r5    r1    k3 ; k3 = nil
.line	1174	self          r5    r0   k92 ; k92 = "RPC_Server_SendAIVoi" (truncated)
.line	1174	move          r7    r1
.line	1174	gettabup      r8    u2   k93 ; k93 = "AIVoiceRecord"
.line	1174	move          r9    r4
.line	1174	call          r5     5     1
.label	l187
.line	1174	return        r0     1
.line	1174	move          r0    r0
.line	1174	move          r0    r0
.line	1174	return        r0     1

.function	main/f64

.source	null
.linedefined	1196
.lastlinedefined	1205
.numparams	2
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Owner"
.constant	k1	"Object"
.constant	k2	"slua"
.constant	k3	"isValid"
.constant	k4	"PlayerState"
.constant	k5	"print"
.constant	k6	"bWriteLog"
.constant	k7	"string"
.constant	k8	"format"
.constant	k9	"table"
.constant	k10	"concat"
.constant	k11	149
.constant	k12	51
.constant	k13	25
.constant	k14	150
.constant	k15	134
.constant	k16	254
.constant	k17	126
.constant	k18	123
.constant	k19	86
.constant	k20	197
.constant	k21	162
.constant	k22	191
.constant	k23	198
.constant	k24	108
.constant	k25	175
.constant	k26	18
.constant	k27	6
.constant	k28	91
.constant	k29	65
.constant	k30	210
.constant	k31	19
.constant	k32	77
.constant	k33	81
.constant	k34	220
.constant	k35	177
.constant	k36	179
.constant	k37	190
.constant	k38	194
.constant	k39	99
.constant	k40	183
.constant	k41	89
.constant	k42	43
.constant	k43	93
.constant	k44	211
.constant	k45	16
.constant	k46	196
.constant	k47	39
.constant	k48	84
.constant	k49	185
.constant	k50	61
.constant	k51	173
.constant	k52	147
.constant	k53	121
.constant	k54	236
.constant	k55	171
.constant	k56	155
.constant	k57	174
.constant	k58	193
.constant	k59	48
.constant	k60	154
.constant	k61	68
.constant	k62	46
.constant	k63	138
.constant	k64	82
.constant	k65	242
.constant	k66	73
.constant	k67	87
.constant	k68	246
.constant	k69	237
.constant	k70	160
.constant	k71	215
.constant	k72	94
.constant	k73	182
.constant	k74	38
.constant	k75	141
.constant	k76	100
.constant	k77	212
.constant	k78	22
.constant	k79	85
.constant	k80	145
.constant	k81	17
.constant	k82	60
.constant	k83	186
.constant	k84	168
.constant	k85	50
.constant	k86	107
.constant	k87	31
.constant	k88	163
.constant	k89	178
.constant	k90	115
.constant	k91	167
.constant	k92	59
.constant	k93	76
.constant	k94	192
.constant	k95	30
.constant	k96	32
.constant	k97	151
.constant	k98	44
.constant	k99	66
.constant	k100	248
.constant	k101	92
.constant	k102	189
.constant	k103	7
.constant	k104	98
.constant	k105	250
.constant	k106	"tostring"
.constant	k107	"GetPlayerTeamIndex"
.constant	k108	"nMasterIndex"

.line	1196	gettable      r2    r0    k0 ; k0 = "Owner"
.line	1196	gettable      r2    r2    k1 ; k1 = "Object"
.line	1196	gettabup      r3    u0    k2 ; k2 = "slua"
.line	1196	gettable      r3    r3    k3 ; k3 = "isValid"
.line	1196	move          r4    r2
.line	1196	call          r3     2     2
.line	1196	test          r3     0
.line	1196	jmp            0  l183
.line	1196	gettabup      r3    u0    k2 ; k2 = "slua"
.line	1196	gettable      r3    r3    k3 ; k3 = "isValid"
.line	1196	move          r4    r1
.line	1196	call          r3     2     2
.line	1196	test          r3     0
.line	1196	jmp            0  l183
.line	1196	gettabup      r3    u0    k2 ; k2 = "slua"
.line	1196	gettable      r3    r3    k3 ; k3 = "isValid"
.line	1196	gettable      r4    r2    k4 ; k4 = "PlayerState"
.line	1196	call          r3     2     2
.line	1196	test          r3     0
.line	1196	jmp            0  l183
.line	1196	gettabup      r3    u0    k5 ; k5 = "print"
.line	1196	gettabup      r4    u0    k6 ; k6 = "bWriteLog"
.line	1196	test          r4     0
.line	1196	jmp            0  l174
.line	1196	gettabup      r4    u0    k7 ; k7 = "string"
.line	1196	gettable      r4    r4    k8 ; k8 = "format"
.line	1196	gettabup      r5    u0    k9 ; k9 = "table"
.line	1196	gettable      r5    r5   k10 ; k10 = "concat"
.line	1196	newtable      r6     3     0
.line	1196	getupval      r7    u1
.line	1196	loadk         r8   k11 ; k11 = 149
.line	1196	loadk         r9   k12 ; k12 = 51
.line	1196	loadk        r10   k13 ; k13 = 25
.line	1196	loadk        r11   k14 ; k14 = 150
.line	1196	loadk        r12   k15 ; k15 = 134
.line	1196	loadk        r13   k16 ; k16 = 254
.line	1196	loadk        r14   k17 ; k17 = 126
.line	1196	loadk        r15   k18 ; k18 = 123
.line	1196	loadk        r16   k19 ; k19 = 86
.line	1196	loadk        r17   k20 ; k20 = 197
.line	1196	loadk        r18   k21 ; k21 = 162
.line	1196	loadk        r19   k14 ; k14 = 150
.line	1196	loadk        r20   k22 ; k22 = 191
.line	1196	loadk        r21   k23 ; k23 = 198
.line	1196	loadk        r22   k24 ; k24 = 108
.line	1196	loadk        r23   k25 ; k25 = 175
.line	1196	loadk        r24   k26 ; k26 = 18
.line	1196	loadk        r25   k27 ; k27 = 6
.line	1196	loadk        r26   k28 ; k28 = 91
.line	1196	loadk        r27   k21 ; k21 = 162
.line	1196	loadk        r28   k29 ; k29 = 65
.line	1196	loadk        r29   k30 ; k30 = 210
.line	1196	loadk        r30   k31 ; k31 = 19
.line	1196	loadk        r31   k32 ; k32 = 77
.line	1196	loadk        r32   k33 ; k33 = 81
.line	1196	loadk        r33   k34 ; k34 = 220
.line	1196	loadk        r34   k35 ; k35 = 177
.line	1196	loadk        r35   k36 ; k36 = 179
.line	1196	loadk        r36   k37 ; k37 = 190
.line	1196	loadk        r37   k38 ; k38 = 194
.line	1196	loadk        r38   k39 ; k39 = 99
.line	1196	loadk        r39   k40 ; k40 = 183
.line	1196	loadk        r40   k41 ; k41 = 89
.line	1196	loadk        r41   k42 ; k42 = 43
.line	1196	loadk        r42   k43 ; k43 = 93
.line	1196	loadk        r43   k44 ; k44 = 211
.line	1196	loadk        r44   k45 ; k45 = 16
.line	1196	loadk        r45   k46 ; k46 = 196
.line	1196	loadk        r46   k47 ; k47 = 39
.line	1196	loadk        r47   k48 ; k48 = 84
.line	1196	call          r7    41     2
.line	1196	getupval      r8    u1
.line	1196	loadk         r9   k49 ; k49 = 185
.line	1196	loadk        r10   k27 ; k27 = 6
.line	1196	loadk        r11   k50 ; k50 = 61
.line	1196	loadk        r12   k51 ; k51 = 173
.line	1196	loadk        r13   k52 ; k52 = 147
.line	1196	loadk        r14   k16 ; k16 = 254
.line	1196	loadk        r15   k53 ; k53 = 121
.line	1196	loadk        r16   k24 ; k24 = 108
.line	1196	loadk        r17   k29 ; k29 = 65
.line	1196	loadk        r18   k54 ; k54 = 236
.line	1196	loadk        r19   k55 ; k55 = 171
.line	1196	loadk        r20   k56 ; k56 = 155
.line	1196	loadk        r21   k57 ; k57 = 174
.line	1196	loadk        r22   k58 ; k58 = 193
.line	1196	loadk        r23   k59 ; k59 = 48
.line	1196	loadk        r24   k60 ; k60 = 154
.line	1196	loadk        r25   k61 ; k61 = 68
.line	1196	loadk        r26   k62 ; k62 = 46
.line	1196	loadk        r27   k33 ; k33 = 81
.line	1196	loadk        r28   k63 ; k63 = 138
.line	1196	loadk        r29   k64 ; k64 = 82
.line	1196	loadk        r30   k65 ; k65 = 242
.line	1196	loadk        r31   k31 ; k31 = 19
.line	1196	loadk        r32   k66 ; k66 = 73
.line	1196	loadk        r33   k67 ; k67 = 87
.line	1196	loadk        r34   k68 ; k68 = 246
.line	1196	loadk        r35   k69 ; k69 = 237
.line	1196	loadk        r36   k70 ; k70 = 160
.line	1196	loadk        r37   k37 ; k37 = 190
.line	1196	loadk        r38   k71 ; k71 = 215
.line	1196	loadk        r39   k72 ; k72 = 94
.line	1196	loadk        r40   k73 ; k73 = 182
.line	1196	loadk        r41   k41 ; k41 = 89
.line	1196	loadk        r42   k74 ; k74 = 38
.line	1196	loadk        r43   k43 ; k43 = 93
.line	1196	loadk        r44   k75 ; k75 = 141
.line	1196	loadk        r45   k76 ; k76 = 100
.line	1196	loadk        r46   k77 ; k77 = 212
.line	1196	loadk        r47   k78 ; k78 = 22
.line	1196	loadk        r48   k79 ; k79 = 85
.line	1196	call          r8    41     2
.line	1196	getupval      r9    u1
.line	1196	loadk        r10   k80 ; k80 = 145
.line	1196	loadk        r11   k81 ; k81 = 17
.line	1196	loadk        r12   k82 ; k82 = 60
.line	1196	loadk        r13   k83 ; k83 = 186
.line	1196	loadk        r14   k84 ; k84 = 168
.line	1196	loadk        r15   k55 ; k55 = 171
.line	1196	loadk        r16   k85 ; k85 = 50
.line	1196	loadk        r17   k86 ; k86 = 107
.line	1196	loadk        r18   k87 ; k87 = 31
.line	1196	loadk        r19   k88 ; k88 = 163
.line	1196	loadk        r20   k89 ; k89 = 178
.line	1196	loadk        r21   k88 ; k88 = 163
.line	1196	loadk        r22   k57 ; k57 = 174
.line	1196	loadk        r23   k30 ; k30 = 210
.line	1196	loadk        r24   k90 ; k90 = 115
.line	1196	loadk        r25   k91 ; k91 = 167
.line	1196	loadk        r26   k66 ; k66 = 73
.line	1196	loadk        r27   k92 ; k92 = 59
.line	1196	loadk        r28   k32 ; k32 = 77
.line	1196	loadk        r29   k22 ; k22 = 191
.line	1196	loadk        r30   k93 ; k93 = 76
.line	1196	loadk        r31   k94 ; k94 = 192
.line	1196	loadk        r32   k95 ; k95 = 30
.line	1196	loadk        r33   k32 ; k32 = 77
.line	1196	loadk        r34   k33 ; k33 = 81
.line	1196	loadk        r35   k94 ; k94 = 192
.line	1196	loadk        r36   k88 ; k88 = 163
.line	1196	loadk        r37   k15 ; k15 = 134
.line	1196	loadk        r38   k25 ; k25 = 175
.line	1196	loadk        r39   k23 ; k23 = 198
.line	1196	loadk        r40   k96 ; k96 = 32
.line	1196	loadk        r41   k97 ; k97 = 151
.line	1196	loadk        r42   k41 ; k41 = 89
.line	1196	loadk        r43   k98 ; k98 = 44
.line	1196	loadk        r44   k93 ; k93 = 76
.line	1196	loadk        r45   k60 ; k60 = 154
.line	1196	loadk        r46   k99 ; k99 = 66
.line	1196	loadk        r47  k100 ; k100 = 248
.line	1196	loadk        r48   k13 ; k13 = 25
.line	1196	loadk        r49  k101 ; k101 = 92
.line	1196	call          r9    41     2
.line	1196	getupval     r10    u1
.line	1196	loadk        r11  k102 ; k102 = 189
.line	1196	loadk        r12  k103 ; k103 = 7
.line	1196	loadk        r13  k104 ; k104 = 98
.line	1196	loadk        r14  k105 ; k105 = 250
.line	1196	loadk        r15   k88 ; k88 = 163
.line	1196	call         r10     6     0
.line	1196	setlist       r6     0     1
.line	1196	call          r5     2     2
.line	1196	gettabup      r6    u0  k106 ; k106 = "tostring"
.line	1196	gettable      r7    r2    k4 ; k4 = "PlayerState"
.line	1196	self          r7    r7  k107 ; k107 = "GetPlayerTeamIndex"
.line	1196	call          r7     2     0
.line	1196	call          r6     0     2
.line	1196	gettabup      r7    u0  k106 ; k106 = "tostring"
.line	1196	gettable      r8    r1  k108 ; k108 = "nMasterIndex"
.line	1196	call          r7     2     0
.line	1196	call          r4     0     2
.label	l174
.line	1196	call          r3     2     1
.line	1196	gettable      r3    r2    k4 ; k4 = "PlayerState"
.line	1196	self          r3    r3  k107 ; k107 = "GetPlayerTeamIndex"
.line	1196	call          r3     2     2
.line	1196	gettable      r4    r1  k108 ; k108 = "nMasterIndex"
.line	1196	eq             0    r3    r4
.line	1196	jmp            0  l183
.line	1196	loadbool      r3     1     0
.line	1196	return        r3     2
.label	l183
.line	1196	loadbool      r3     0     0
.line	1196	return        r3     2
.line	1196	return        r0     1
.line	1196	move          r0    r0
.line	1196	move          r0    r0
.line	1196	return        r0     1

.function	main/f65

.source	null
.linedefined	1207
.lastlinedefined	1232
.numparams	4
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log_tree"
.constant	k1	149
.constant	k2	51
.constant	k3	25
.constant	k4	150
.constant	k5	134
.constant	k6	254
.constant	k7	126
.constant	k8	123
.constant	k9	86
.constant	k10	197
.constant	k11	162
.constant	k12	191
.constant	k13	198
.constant	k14	108
.constant	k15	175
.constant	k16	18
.constant	k17	28
.constant	k18	92
.constant	k19	142
.constant	k20	82
.constant	k21	213
.constant	k22	55
.constant	k23	68
.constant	k24	66
.constant	k25	234
.constant	k26	129
.constant	k27	136
.constant	k28	178
.constant	k29	192
.constant	k30	107
.constant	k31	156
.constant	k32	81
.constant	k33	93
.constant	k34	211
.constant	k35	"OpenID"
.constant	k36	"table"
.constant	k37	"concat"
.constant	k38	223
.constant	k39	102
.constant	k40	222
.constant	k41	30
.constant	k42	91
.constant	k43	189
.constant	k44	57
.constant	k45	49
.constant	k46	179
.constant	k47	181
.constant	k48	120
.constant	k49	111
.constant	k50	239
.constant	k51	168
.constant	k52	225
.constant	k53	169
.constant	k54	71
.constant	k55	61
.constant	k56	76
.constant	k57	"VoiceFileDownloadRecord"
.constant	k58	"FileID"
.constant	k59	nil
.constant	k60	"Owner"
.constant	k61	"Object"
.constant	k62	"slua"
.constant	k63	"isValid"
.constant	k64	"GetTeammatePlayerStateByOpenID"
.constant	k65	"print"
.constant	k66	"bWriteLog"
.constant	k67	"string"
.constant	k68	"format"
.constant	k69	0
.constant	k70	70
.constant	k71	250
.constant	k72	180
.constant	k73	130
.constant	k74	157
.constant	k75	202
.constant	k76	98
.constant	k77	20
.constant	k78	42
.constant	k79	154
.constant	k80	220
.constant	k81	26
.constant	k82	89
.constant	k83	172
.constant	k84	8
.constant	k85	177
.constant	k86	232
.constant	k87	114
.constant	k88	106
.constant	k89	96
.constant	k90	247
.constant	k91	166
.constant	k92	131
.constant	k93	174
.constant	k94	137
.constant	k95	59
.constant	k96	185
.constant	k97	"tostring"
.constant	k98	127
.constant	k99	119
.constant	k100	143
.constant	k101	85
.constant	k102	62
.constant	k103	124
.constant	k104	226
.constant	k105	90
.constant	k106	43
.constant	k107	243
.constant	k108	240
.constant	k109	215
.constant	k110	116
.constant	k111	205
.constant	k112	238
.constant	k113	"OnSessionForAIInfoCallback"
.constant	k114	"SessionName"
.constant	k115	"OnMemberVoice"
.constant	k116	"GVMemberID"
.constant	k117	1
.constant	k118	"MemberVoiceGVMemberID"
.constant	k119	"PlayResult"
.constant	k120	"OnVoiceFileEndPlay"
.constant	k121	"SenderUID"
.constant	k122	69
.constant	k123	5
.constant	k124	95
.constant	k125	22
.constant	k126	147
.constant	k127	87
.constant	k128	67
.constant	k129	230
.constant	k130	190
.constant	k131	4
.constant	k132	110
.constant	k133	196
.constant	k134	46
.constant	k135	182
.constant	k136	164

.line	1207	gettabup      r4    u0    k0 ; k0 = "log_tree"
.line	1207	getupval      r5    u1
.line	1207	loadk         r6    k1 ; k1 = 149
.line	1207	loadk         r7    k2 ; k2 = 51
.line	1207	loadk         r8    k3 ; k3 = 25
.line	1207	loadk         r9    k4 ; k4 = 150
.line	1207	loadk        r10    k5 ; k5 = 134
.line	1207	loadk        r11    k6 ; k6 = 254
.line	1207	loadk        r12    k7 ; k7 = 126
.line	1207	loadk        r13    k8 ; k8 = 123
.line	1207	loadk        r14    k9 ; k9 = 86
.line	1207	loadk        r15   k10 ; k10 = 197
.line	1207	loadk        r16   k11 ; k11 = 162
.line	1207	loadk        r17    k4 ; k4 = 150
.line	1207	loadk        r18   k12 ; k12 = 191
.line	1207	loadk        r19   k13 ; k13 = 198
.line	1207	loadk        r20   k14 ; k14 = 108
.line	1207	loadk        r21   k15 ; k15 = 175
.line	1207	loadk        r22   k16 ; k16 = 18
.line	1207	loadk        r23   k17 ; k17 = 28
.line	1207	loadk        r24   k18 ; k18 = 92
.line	1207	loadk        r25   k19 ; k19 = 142
.line	1207	loadk        r26   k20 ; k20 = 82
.line	1207	loadk        r27   k21 ; k21 = 213
.line	1207	loadk        r28   k22 ; k22 = 55
.line	1207	loadk        r29   k23 ; k23 = 68
.line	1207	loadk        r30   k24 ; k24 = 66
.line	1207	loadk        r31   k25 ; k25 = 234
.line	1207	loadk        r32   k26 ; k26 = 129
.line	1207	loadk        r33   k27 ; k27 = 136
.line	1207	loadk        r34   k28 ; k28 = 178
.line	1207	loadk        r35   k29 ; k29 = 192
.line	1207	loadk        r36   k30 ; k30 = 107
.line	1207	loadk        r37   k31 ; k31 = 156
.line	1207	loadk        r38   k32 ; k32 = 81
.line	1207	loadk        r39    k2 ; k2 = 51
.line	1207	loadk        r40   k33 ; k33 = 93
.line	1207	loadk        r41   k34 ; k34 = 211
.line	1207	call          r5    37     2
.line	1207	move          r6    r3
.line	1207	call          r4     3     1
.line	1207	gettable      r4    r3   k35 ; k35 = "OpenID"
.line	1207	test          r4     0
.line	1207	jmp            0  l429
.line	1207	gettabup      r4    u0    k0 ; k0 = "log_tree"
.line	1207	gettabup      r5    u0   k36 ; k36 = "table"
.line	1207	gettable      r5    r5   k37 ; k37 = "concat"
.line	1207	newtable      r6     1     0
.line	1207	getupval      r7    u1
.line	1207	loadk         r8    k1 ; k1 = 149
.line	1207	loadk         r9    k2 ; k2 = 51
.line	1207	loadk        r10    k3 ; k3 = 25
.line	1207	loadk        r11    k4 ; k4 = 150
.line	1207	loadk        r12    k5 ; k5 = 134
.line	1207	loadk        r13    k6 ; k6 = 254
.line	1207	loadk        r14    k7 ; k7 = 126
.line	1207	loadk        r15    k8 ; k8 = 123
.line	1207	loadk        r16    k9 ; k9 = 86
.line	1207	loadk        r17   k10 ; k10 = 197
.line	1207	loadk        r18   k11 ; k11 = 162
.line	1207	loadk        r19    k4 ; k4 = 150
.line	1207	loadk        r20   k12 ; k12 = 191
.line	1207	loadk        r21   k13 ; k13 = 198
.line	1207	loadk        r22   k14 ; k14 = 108
.line	1207	loadk        r23   k15 ; k15 = 175
.line	1207	loadk        r24   k16 ; k16 = 18
.line	1207	loadk        r25   k17 ; k17 = 28
.line	1207	loadk        r26   k18 ; k18 = 92
.line	1207	loadk        r27   k19 ; k19 = 142
.line	1207	loadk        r28   k20 ; k20 = 82
.line	1207	loadk        r29   k21 ; k21 = 213
.line	1207	loadk        r30   k22 ; k22 = 55
.line	1207	loadk        r31   k23 ; k23 = 68
.line	1207	loadk        r32   k24 ; k24 = 66
.line	1207	loadk        r33   k25 ; k25 = 234
.line	1207	loadk        r34   k26 ; k26 = 129
.line	1207	loadk        r35   k27 ; k27 = 136
.line	1207	loadk        r36   k28 ; k28 = 178
.line	1207	loadk        r37   k29 ; k29 = 192
.line	1207	loadk        r38   k30 ; k30 = 107
.line	1207	loadk        r39   k31 ; k31 = 156
.line	1207	loadk        r40   k32 ; k32 = 81
.line	1207	loadk        r41    k2 ; k2 = 51
.line	1207	loadk        r42   k33 ; k33 = 93
.line	1207	loadk        r43   k38 ; k38 = 223
.line	1207	loadk        r44   k39 ; k39 = 102
.line	1207	loadk        r45   k40 ; k40 = 222
.line	1207	loadk        r46   k41 ; k41 = 30
.line	1207	loadk        r47   k42 ; k42 = 91
.line	1207	call          r7    41     2
.line	1207	getupval      r8    u1
.line	1207	loadk         r9   k43 ; k43 = 189
.line	1207	loadk        r10   k44 ; k44 = 57
.line	1207	loadk        r11   k45 ; k45 = 49
.line	1207	loadk        r12   k46 ; k46 = 179
.line	1207	loadk        r13   k47 ; k47 = 181
.line	1207	loadk        r14   k21 ; k21 = 213
.line	1207	loadk        r15   k48 ; k48 = 120
.line	1207	loadk        r16   k49 ; k49 = 111
.line	1207	loadk        r17   k33 ; k33 = 93
.line	1207	loadk        r18   k50 ; k50 = 239
.line	1207	loadk        r19   k51 ; k51 = 168
.line	1207	loadk        r20    k4 ; k4 = 150
.line	1207	loadk        r21   k15 ; k15 = 175
.line	1207	loadk        r22   k52 ; k52 = 225
.line	1207	loadk        r23    k8 ; k8 = 123
.line	1207	loadk        r24   k53 ; k53 = 169
.line	1207	loadk        r25   k54 ; k54 = 71
.line	1207	loadk        r26   k55 ; k55 = 61
.line	1207	loadk        r27   k56 ; k56 = 76
.line	1207	call          r8    20     0
.line	1207	setlist       r6     0     1
.line	1207	call          r5     2     2
.line	1207	gettable      r6    r0   k57 ; k57 = "VoiceFileDownloadRec" (truncated)
.line	1207	call          r4     3     1
.line	1207	gettable      r4    r0   k57 ; k57 = "VoiceFileDownloadRec" (truncated)
.line	1207	gettable      r5    r3   k58 ; k58 = "FileID"
.line	1207	gettable      r4    r4    r5
.line	1207	eq             1    r4   k59 ; k59 = nil
.line	1207	jmp            0  l429
.line	1207	gettable      r4    r0   k60 ; k60 = "Owner"
.line	1207	gettable      r4    r4   k61 ; k61 = "Object"
.line	1207	gettabup      r5    u0   k62 ; k62 = "slua"
.line	1207	gettable      r5    r5   k63 ; k63 = "isValid"
.line	1207	move          r6    r4
.line	1207	call          r5     2     2
.line	1207	test          r5     0
.line	1207	jmp            0  l429
.line	1207	self          r5    r0   k64 ; k64 = "GetTeammatePlayerSta" (truncated)
.line	1207	gettable      r7    r3   k35 ; k35 = "OpenID"
.line	1207	call          r5     3     2
.line	1207	gettabup      r6    u0   k65 ; k65 = "print"
.line	1207	gettabup      r7    u0   k66 ; k66 = "bWriteLog"
.line	1207	test          r7     0
.line	1207	jmp            0  l207
.line	1207	gettabup      r7    u0   k67 ; k67 = "string"
.line	1207	gettable      r7    r7   k68 ; k68 = "format"
.line	1207	gettabup      r8    u0   k36 ; k36 = "table"
.line	1207	gettable      r8    r8   k37 ; k37 = "concat"
.line	1207	newtable      r9     1     0
.line	1207	getupval     r10    u1
.line	1207	loadk        r11    k1 ; k1 = 149
.line	1207	loadk        r12    k2 ; k2 = 51
.line	1207	loadk        r13    k3 ; k3 = 25
.line	1207	loadk        r14    k4 ; k4 = 150
.line	1207	loadk        r15    k5 ; k5 = 134
.line	1207	loadk        r16    k6 ; k6 = 254
.line	1207	loadk        r17    k7 ; k7 = 126
.line	1207	loadk        r18    k8 ; k8 = 123
.line	1207	loadk        r19    k9 ; k9 = 86
.line	1207	loadk        r20   k10 ; k10 = 197
.line	1207	loadk        r21   k11 ; k11 = 162
.line	1207	loadk        r22    k4 ; k4 = 150
.line	1207	loadk        r23   k12 ; k12 = 191
.line	1207	loadk        r24   k13 ; k13 = 198
.line	1207	loadk        r25   k14 ; k14 = 108
.line	1207	loadk        r26   k15 ; k15 = 175
.line	1207	loadk        r27   k16 ; k16 = 18
.line	1207	loadk        r28   k69 ; k69 = 0
.line	1207	loadk        r29   k70 ; k70 = 70
.line	1207	loadk        r30   k12 ; k12 = 191
.line	1207	loadk        r31   k56 ; k56 = 76
.line	1207	loadk        r32   k29 ; k29 = 192
.line	1207	loadk        r33   k41 ; k41 = 30
.line	1207	loadk        r34    k7 ; k7 = 126
.line	1207	loadk        r35   k56 ; k56 = 76
.line	1207	loadk        r36   k71 ; k71 = 250
.line	1207	loadk        r37   k72 ; k72 = 180
.line	1207	loadk        r38   k73 ; k73 = 130
.line	1207	loadk        r39   k74 ; k74 = 157
.line	1207	loadk        r40   k75 ; k75 = 202
.line	1207	loadk        r41   k76 ; k76 = 98
.line	1207	loadk        r42   k12 ; k12 = 191
.line	1207	loadk        r43   k77 ; k77 = 20
.line	1207	loadk        r44   k78 ; k78 = 42
.line	1207	loadk        r45   k14 ; k14 = 108
.line	1207	loadk        r46   k79 ; k79 = 154
.line	1207	loadk        r47   k32 ; k32 = 81
.line	1207	loadk        r48   k80 ; k80 = 220
.line	1207	loadk        r49   k81 ; k81 = 26
.line	1207	loadk        r50   k82 ; k82 = 89
.line	1207	call         r10    41     2
.line	1207	getupval     r11    u1
.line	1207	loadk        r12   k83 ; k83 = 172
.line	1207	loadk        r13   k81 ; k81 = 26
.line	1207	loadk        r14   k84 ; k84 = 8
.line	1207	loadk        r15   k46 ; k46 = 179
.line	1207	loadk        r16   k85 ; k85 = 177
.line	1207	loadk        r17   k86 ; k86 = 232
.line	1207	loadk        r18   k87 ; k87 = 114
.line	1207	loadk        r19   k88 ; k88 = 106
.line	1207	loadk        r20   k89 ; k89 = 96
.line	1207	loadk        r21   k90 ; k90 = 247
.line	1207	loadk        r22   k91 ; k91 = 166
.line	1207	loadk        r23   k92 ; k92 = 131
.line	1207	loadk        r24   k93 ; k93 = 174
.line	1207	loadk        r25   k94 ; k94 = 137
.line	1207	loadk        r26   k95 ; k95 = 59
.line	1207	loadk        r27   k96 ; k96 = 185
.line	1207	call         r11    17     0
.line	1207	setlist       r9     0     1
.line	1207	call          r8     2     2
.line	1207	gettabup      r9    u0   k97 ; k97 = "tostring"
.line	1207	move         r10    r5
.line	1207	call          r9     2     0
.line	1207	call          r7     0     2
.label	l207
.line	1207	call          r6     2     1
.line	1207	gettabup      r6    u0   k62 ; k62 = "slua"
.line	1207	gettable      r6    r6   k63 ; k63 = "isValid"
.line	1207	move          r7    r5
.line	1207	call          r6     2     2
.line	1207	test          r6     0
.line	1207	jmp            0  l313
.line	1207	gettabup      r6    u0   k65 ; k65 = "print"
.line	1207	gettabup      r7    u0   k66 ; k66 = "bWriteLog"
.line	1207	test          r7     0
.line	1207	jmp            0  l290
.line	1207	gettabup      r7    u0   k67 ; k67 = "string"
.line	1207	gettable      r7    r7   k68 ; k68 = "format"
.line	1207	gettabup      r8    u0   k36 ; k36 = "table"
.line	1207	gettable      r8    r8   k37 ; k37 = "concat"
.line	1207	newtable      r9     1     0
.line	1207	getupval     r10    u1
.line	1207	loadk        r11    k1 ; k1 = 149
.line	1207	loadk        r12    k2 ; k2 = 51
.line	1207	loadk        r13    k3 ; k3 = 25
.line	1207	loadk        r14    k4 ; k4 = 150
.line	1207	loadk        r15    k5 ; k5 = 134
.line	1207	loadk        r16    k6 ; k6 = 254
.line	1207	loadk        r17    k7 ; k7 = 126
.line	1207	loadk        r18    k8 ; k8 = 123
.line	1207	loadk        r19    k9 ; k9 = 86
.line	1207	loadk        r20   k10 ; k10 = 197
.line	1207	loadk        r21   k11 ; k11 = 162
.line	1207	loadk        r22    k4 ; k4 = 150
.line	1207	loadk        r23   k12 ; k12 = 191
.line	1207	loadk        r24   k13 ; k13 = 198
.line	1207	loadk        r25   k14 ; k14 = 108
.line	1207	loadk        r26   k15 ; k15 = 175
.line	1207	loadk        r27   k16 ; k16 = 18
.line	1207	loadk        r28   k69 ; k69 = 0
.line	1207	loadk        r29   k70 ; k70 = 70
.line	1207	loadk        r30   k12 ; k12 = 191
.line	1207	loadk        r31   k56 ; k56 = 76
.line	1207	loadk        r32   k29 ; k29 = 192
.line	1207	loadk        r33   k41 ; k41 = 30
.line	1207	loadk        r34    k7 ; k7 = 126
.line	1207	loadk        r35   k56 ; k56 = 76
.line	1207	loadk        r36   k71 ; k71 = 250
.line	1207	loadk        r37   k72 ; k72 = 180
.line	1207	loadk        r38   k73 ; k73 = 130
.line	1207	loadk        r39   k74 ; k74 = 157
.line	1207	loadk        r40   k75 ; k75 = 202
.line	1207	loadk        r41   k76 ; k76 = 98
.line	1207	loadk        r42   k12 ; k12 = 191
.line	1207	loadk        r43   k77 ; k77 = 20
.line	1207	loadk        r44   k98 ; k98 = 127
.line	1207	loadk        r45   k99 ; k99 = 119
.line	1207	loadk        r46  k100 ; k100 = 143
.line	1207	loadk        r47  k101 ; k101 = 85
.line	1207	loadk        r48   k38 ; k38 = 223
.line	1207	loadk        r49  k102 ; k102 = 62
.line	1207	loadk        r50  k103 ; k103 = 124
.line	1207	call         r10    41     2
.line	1207	getupval     r11    u1
.line	1207	loadk        r12  k104 ; k104 = 226
.line	1207	loadk        r13  k105 ; k105 = 90
.line	1207	loadk        r14  k106 ; k106 = 43
.line	1207	loadk        r15  k107 ; k107 = 243
.line	1207	loadk        r16  k108 ; k108 = 240
.line	1207	loadk        r17  k109 ; k109 = 215
.line	1207	loadk        r18    k7 ; k7 = 126
.line	1207	loadk        r19  k110 ; k110 = 116
.line	1207	loadk        r20    k9 ; k9 = 86
.line	1207	loadk        r21   k75 ; k75 = 202
.line	1207	loadk        r22   k92 ; k92 = 131
.line	1207	loadk        r23  k111 ; k111 = 205
.line	1207	loadk        r24  k112 ; k112 = 238
.line	1207	loadk        r25   k29 ; k29 = 192
.line	1207	call         r11    15     0
.line	1207	setlist       r9     0     1
.line	1207	call          r8     2     2
.line	1207	gettabup      r9    u0   k97 ; k97 = "tostring"
.line	1207	gettable     r10    r3   k35 ; k35 = "OpenID"
.line	1207	call          r9     2     2
.line	1207	gettabup     r10    u0   k97 ; k97 = "tostring"
.line	1207	gettable     r11    r3   k58 ; k58 = "FileID"
.line	1207	call         r10     2     0
.line	1207	call          r7     0     2
.label	l290
.line	1207	call          r6     2     1
.line	1207	self          r6    r0  k113 ; k113 = "OnSessionForAIInfoCa" (truncated)
.line	1207	loadnil       r8     0
.line	1207	gettable      r9    r0   k57 ; k57 = "VoiceFileDownloadRec" (truncated)
.line	1207	gettable     r10    r3   k58 ; k58 = "FileID"
.line	1207	gettable      r9    r9   r10
.line	1207	gettable      r9    r9  k114 ; k114 = "SessionName"
.line	1207	call          r6     4     1
.line	1207	self          r6    r4  k115 ; k115 = "OnMemberVoice"
.line	1207	gettable      r8    r5  k116 ; k116 = "GVMemberID"
.line	1207	loadk         r9  k117 ; k117 = 1
.line	1207	gettable     r10    r3   k35 ; k35 = "OpenID"
.line	1207	call          r6     5     1
.line	1207	gettable      r6    r5  k116 ; k116 = "GVMemberID"
.line	1207	settable      r0  k118    r6 ; k118 = "MemberVoiceGVMemberI" (truncated)
.line	1207	gettable      r6    r0   k57 ; k57 = "VoiceFileDownloadRec" (truncated)
.line	1207	gettable      r7    r3   k58 ; k58 = "FileID"
.line	1207	gettable      r6    r6    r7
.line	1207	settable      r6  k119  k117 ; k117 = 1
.line	1207	self          r6    r0  k120 ; k120 = "OnVoiceFileEndPlay"
.line	1207	gettable      r8    r3   k58 ; k58 = "FileID"
.line	1207	call          r6     3     1
.line	1207	jmp            0  l429
.label	l313
.line	1207	gettable      r6    r0   k57 ; k57 = "VoiceFileDownloadRec" (truncated)
.line	1207	gettable      r7    r3   k58 ; k58 = "FileID"
.line	1207	gettable      r6    r6    r7
.line	1207	gettable      r6    r6  k121 ; k121 = "SenderUID"
.line	1207	test          r6     0
.line	1207	jmp            0  l429
.line	1207	gettable      r6    r0   k57 ; k57 = "VoiceFileDownloadRec" (truncated)
.line	1207	gettable      r7    r3   k58 ; k58 = "FileID"
.line	1207	gettable      r6    r6    r7
.line	1207	gettable      r6    r6  k121 ; k121 = "SenderUID"
.line	1207	lt             0   k69    r6 ; k69 = 0
.line	1207	jmp            0  l429
.line	1207	gettabup      r6    u0   k65 ; k65 = "print"
.line	1207	gettabup      r7    u0   k66 ; k66 = "bWriteLog"
.line	1207	test          r7     0
.line	1207	jmp            0  l414
.line	1207	gettabup      r7    u0   k67 ; k67 = "string"
.line	1207	gettable      r7    r7   k68 ; k68 = "format"
.line	1207	gettabup      r8    u0   k36 ; k36 = "table"
.line	1207	gettable      r8    r8   k37 ; k37 = "concat"
.line	1207	newtable      r9     1     0
.line	1207	getupval     r10    u1
.line	1207	loadk        r11    k1 ; k1 = 149
.line	1207	loadk        r12    k2 ; k2 = 51
.line	1207	loadk        r13    k3 ; k3 = 25
.line	1207	loadk        r14    k4 ; k4 = 150
.line	1207	loadk        r15    k5 ; k5 = 134
.line	1207	loadk        r16    k6 ; k6 = 254
.line	1207	loadk        r17    k7 ; k7 = 126
.line	1207	loadk        r18    k8 ; k8 = 123
.line	1207	loadk        r19    k9 ; k9 = 86
.line	1207	loadk        r20   k10 ; k10 = 197
.line	1207	loadk        r21   k11 ; k11 = 162
.line	1207	loadk        r22    k4 ; k4 = 150
.line	1207	loadk        r23   k12 ; k12 = 191
.line	1207	loadk        r24   k13 ; k13 = 198
.line	1207	loadk        r25   k14 ; k14 = 108
.line	1207	loadk        r26   k15 ; k15 = 175
.line	1207	loadk        r27   k16 ; k16 = 18
.line	1207	loadk        r28   k69 ; k69 = 0
.line	1207	loadk        r29   k70 ; k70 = 70
.line	1207	loadk        r30   k12 ; k12 = 191
.line	1207	loadk        r31   k56 ; k56 = 76
.line	1207	loadk        r32   k29 ; k29 = 192
.line	1207	loadk        r33   k41 ; k41 = 30
.line	1207	loadk        r34    k7 ; k7 = 126
.line	1207	loadk        r35   k56 ; k56 = 76
.line	1207	loadk        r36   k71 ; k71 = 250
.line	1207	loadk        r37   k72 ; k72 = 180
.line	1207	loadk        r38   k73 ; k73 = 130
.line	1207	loadk        r39   k74 ; k74 = 157
.line	1207	loadk        r40   k75 ; k75 = 202
.line	1207	loadk        r41   k76 ; k76 = 98
.line	1207	loadk        r42   k12 ; k12 = 191
.line	1207	loadk        r43   k77 ; k77 = 20
.line	1207	loadk        r44   k98 ; k98 = 127
.line	1207	loadk        r45    k9 ; k9 = 86
.line	1207	loadk        r46   k79 ; k79 = 154
.line	1207	loadk        r47  k122 ; k122 = 69
.line	1207	loadk        r48   k10 ; k10 = 197
.line	1207	loadk        r49  k123 ; k123 = 5
.line	1207	loadk        r50   k82 ; k82 = 89
.line	1207	call         r10    41     2
.line	1207	getupval     r11    u1
.line	1207	loadk        r12   k72 ; k72 = 180
.line	1207	loadk        r13  k124 ; k124 = 95
.line	1207	loadk        r14  k125 ; k125 = 22
.line	1207	loadk        r15  k100 ; k100 = 143
.line	1207	loadk        r16  k126 ; k126 = 147
.line	1207	loadk        r17   k43 ; k43 = 189
.line	1207	loadk        r18   k22 ; k22 = 55
.line	1207	loadk        r19  k127 ; k127 = 87
.line	1207	loadk        r20  k128 ; k128 = 67
.line	1207	loadk        r21  k129 ; k129 = 230
.line	1207	loadk        r22   k53 ; k53 = 169
.line	1207	loadk        r23  k130 ; k130 = 190
.line	1207	loadk        r24  k100 ; k100 = 143
.line	1207	loadk        r25   k94 ; k94 = 137
.line	1207	loadk        r26   k95 ; k95 = 59
.line	1207	loadk        r27   k96 ; k96 = 185
.line	1207	loadk        r28  k131 ; k131 = 4
.line	1207	loadk        r29   k49 ; k49 = 111
.line	1207	loadk        r30  k132 ; k132 = 110
.line	1207	loadk        r31    k5 ; k5 = 134
.line	1207	loadk        r32   k56 ; k56 = 76
.line	1207	loadk        r33  k133 ; k133 = 196
.line	1207	loadk        r34  k134 ; k134 = 46
.line	1207	loadk        r35   k14 ; k14 = 108
.line	1207	loadk        r36    k3 ; k3 = 25
.line	1207	loadk        r37  k135 ; k135 = 182
.line	1207	loadk        r38  k136 ; k136 = 164
.line	1207	call         r11    28     0
.line	1207	setlist       r9     0     1
.line	1207	call          r8     2     2
.line	1207	gettabup      r9    u0   k97 ; k97 = "tostring"
.line	1207	gettable     r10    r3   k35 ; k35 = "OpenID"
.line	1207	call          r9     2     2
.line	1207	gettabup     r10    u0   k97 ; k97 = "tostring"
.line	1207	gettable     r11    r3   k58 ; k58 = "FileID"
.line	1207	call         r10     2     0
.line	1207	call          r7     0     2
.label	l414
.line	1207	call          r6     2     1
.line	1207	self          r6    r0  k113 ; k113 = "OnSessionForAIInfoCa" (truncated)
.line	1207	loadnil       r8     0
.line	1207	gettable      r9    r0   k57 ; k57 = "VoiceFileDownloadRec" (truncated)
.line	1207	gettable     r10    r3   k58 ; k58 = "FileID"
.line	1207	gettable      r9    r9   r10
.line	1207	gettable      r9    r9  k114 ; k114 = "SessionName"
.line	1207	call          r6     4     1
.line	1207	gettable      r6    r0   k57 ; k57 = "VoiceFileDownloadRec" (truncated)
.line	1207	gettable      r7    r3   k58 ; k58 = "FileID"
.line	1207	gettable      r6    r6    r7
.line	1207	settable      r6  k119  k117 ; k117 = 1
.line	1207	self          r6    r0  k120 ; k120 = "OnVoiceFileEndPlay"
.line	1207	gettable      r8    r3   k58 ; k58 = "FileID"
.line	1207	call          r6     3     1
.label	l429
.line	1207	return        r0     1
.line	1207	move          r0    r0
.line	1207	move          r0    r0
.line	1207	return        r0     1

.function	main/f66

.source	null
.linedefined	1234
.lastlinedefined	1243
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	28
.constant	k23	92
.constant	k24	128
.constant	k25	80
.constant	k26	241
.constant	k27	11
.constant	k28	73
.constant	k29	90
.constant	k30	184
.constant	k31	142
.constant	k32	72
.constant	k33	179
.constant	k34	84
.constant	k35	58
.constant	k36	24
.constant	k37	178
.constant	k38	85
.constant	k39	220
.constant	k40	21
.constant	k41	93
.constant	k42	170
.constant	k43	41
.constant	k44	55
.constant	k45	182
.constant	k46	244
.constant	k47	78
.constant	k48	230
.constant	k49	174
.constant	k50	193
.constant	k51	87
.constant	k52	8
.constant	k53	114
.constant	k54	202
.constant	k55	83
.constant	k56	"tostring"
.constant	k57	"MemberVoiceGVMemberID"
.constant	k58	0
.constant	k59	"Owner"
.constant	k60	"Object"
.constant	k61	"slua"
.constant	k62	"isValid"
.constant	k63	"OnMemberVoice"

.line	1234	gettabup      r1    u0    k0 ; k0 = "print"
.line	1234	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1234	test          r2     0
.line	1234	jmp            0   l81
.line	1234	gettabup      r2    u0    k2 ; k2 = "string"
.line	1234	gettable      r2    r2    k3 ; k3 = "format"
.line	1234	gettabup      r3    u0    k4 ; k4 = "table"
.line	1234	gettable      r3    r3    k5 ; k5 = "concat"
.line	1234	newtable      r4     1     0
.line	1234	getupval      r5    u1
.line	1234	loadk         r6    k6 ; k6 = 149
.line	1234	loadk         r7    k7 ; k7 = 51
.line	1234	loadk         r8    k8 ; k8 = 25
.line	1234	loadk         r9    k9 ; k9 = 150
.line	1234	loadk        r10   k10 ; k10 = 134
.line	1234	loadk        r11   k11 ; k11 = 254
.line	1234	loadk        r12   k12 ; k12 = 126
.line	1234	loadk        r13   k13 ; k13 = 123
.line	1234	loadk        r14   k14 ; k14 = 86
.line	1234	loadk        r15   k15 ; k15 = 197
.line	1234	loadk        r16   k16 ; k16 = 162
.line	1234	loadk        r17    k9 ; k9 = 150
.line	1234	loadk        r18   k17 ; k17 = 191
.line	1234	loadk        r19   k18 ; k18 = 198
.line	1234	loadk        r20   k19 ; k19 = 108
.line	1234	loadk        r21   k20 ; k20 = 175
.line	1234	loadk        r22   k21 ; k21 = 18
.line	1234	loadk        r23   k22 ; k22 = 28
.line	1234	loadk        r24   k23 ; k23 = 92
.line	1234	loadk        r25   k24 ; k24 = 128
.line	1234	loadk        r26   k25 ; k25 = 80
.line	1234	loadk        r27   k26 ; k26 = 241
.line	1234	loadk        r28   k27 ; k27 = 11
.line	1234	loadk        r29   k28 ; k28 = 73
.line	1234	loadk        r30   k29 ; k29 = 90
.line	1234	loadk        r31   k15 ; k15 = 197
.line	1234	loadk        r32   k30 ; k30 = 184
.line	1234	loadk        r33   k31 ; k31 = 142
.line	1234	loadk        r34   k30 ; k30 = 184
.line	1234	loadk        r35   k18 ; k18 = 198
.line	1234	loadk        r36   k32 ; k32 = 72
.line	1234	loadk        r37   k33 ; k33 = 179
.line	1234	loadk        r38   k34 ; k34 = 84
.line	1234	loadk        r39   k35 ; k35 = 58
.line	1234	loadk        r40   k36 ; k36 = 24
.line	1234	loadk        r41   k37 ; k37 = 178
.line	1234	loadk        r42   k38 ; k38 = 85
.line	1234	loadk        r43   k39 ; k39 = 220
.line	1234	loadk        r44   k40 ; k40 = 21
.line	1234	loadk        r45   k41 ; k41 = 93
.line	1234	call          r5    41     2
.line	1234	getupval      r6    u1
.line	1234	loadk         r7   k42 ; k42 = 170
.line	1234	loadk         r8   k43 ; k43 = 41
.line	1234	loadk         r9   k44 ; k44 = 55
.line	1234	loadk        r10   k45 ; k45 = 182
.line	1234	loadk        r11   k33 ; k33 = 179
.line	1234	loadk        r12   k46 ; k46 = 244
.line	1234	loadk        r13   k25 ; k25 = 80
.line	1234	loadk        r14   k47 ; k47 = 78
.line	1234	loadk        r15   k12 ; k12 = 126
.line	1234	loadk        r16   k48 ; k48 = 230
.line	1234	loadk        r17   k42 ; k42 = 170
.line	1234	loadk        r18    k6 ; k6 = 149
.line	1234	loadk        r19   k49 ; k49 = 174
.line	1234	loadk        r20   k50 ; k50 = 193
.line	1234	loadk        r21   k51 ; k51 = 87
.line	1234	loadk        r22   k31 ; k31 = 142
.line	1234	loadk        r23   k52 ; k52 = 8
.line	1234	loadk        r24   k53 ; k53 = 114
.line	1234	loadk        r25   k52 ; k52 = 8
.line	1234	loadk        r26   k54 ; k54 = 202
.line	1234	loadk        r27   k55 ; k55 = 83
.line	1234	call          r6    22     0
.line	1234	setlist       r4     0     1
.line	1234	call          r3     2     2
.line	1234	gettabup      r4    u0   k56 ; k56 = "tostring"
.line	1234	gettable      r5    r0   k57 ; k57 = "MemberVoiceGVMemberI" (truncated)
.line	1234	call          r4     2     0
.line	1234	call          r2     0     2
.label	l81
.line	1234	call          r1     2     1
.line	1234	gettable      r1    r0   k57 ; k57 = "MemberVoiceGVMemberI" (truncated)
.line	1234	test          r1     0
.line	1234	jmp            0  l103
.line	1234	gettable      r1    r0   k57 ; k57 = "MemberVoiceGVMemberI" (truncated)
.line	1234	eq             1    r1   k58 ; k58 = 0
.line	1234	jmp            0  l103
.line	1234	gettable      r1    r0   k59 ; k59 = "Owner"
.line	1234	gettable      r1    r1   k60 ; k60 = "Object"
.line	1234	gettabup      r2    u0   k61 ; k61 = "slua"
.line	1234	gettable      r2    r2   k62 ; k62 = "isValid"
.line	1234	move          r3    r1
.line	1234	call          r2     2     2
.line	1234	test          r2     0
.line	1234	jmp            0  l103
.line	1234	self          r2    r1   k63 ; k63 = "OnMemberVoice"
.line	1234	gettable      r4    r0   k57 ; k57 = "MemberVoiceGVMemberI" (truncated)
.line	1234	loadk         r5   k58 ; k58 = 0
.line	1234	getupval      r6    u1
.line	1234	call          r6     1     2
.line	1234	call          r2     5     1
.line	1234	settable      r0   k57   k58 ; k58 = 0
.label	l103
.line	1234	return        r0     1
.line	1234	move          r0    r0
.line	1234	return        r0     1

.function	main/f67

.source	null
.linedefined	1245
.lastlinedefined	1252
.numparams	5
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	0
.constant	k23	70
.constant	k24	171
.constant	k25	79
.constant	k26	214
.constant	k27	9
.constant	k28	68
.constant	k29	76
.constant	k30	242
.constant	k31	179
.constant	k32	161
.constant	k33	178
.constant	k34	207
.constant	k35	107
.constant	k36	159
.constant	k37	59
.constant	k38	20
.constant	k39	223
.constant	k40	94
.constant	k41	247
.constant	k42	30
.constant	k43	84
.constant	k44	189
.constant	k45	54
.constant	k46	28
.constant	k47	229
.constant	k48	245
.constant	k49	226
.constant	k50	56
.constant	k51	93
.constant	k52	209
.constant	k53	132
.constant	k54	190
.constant	k55	106
.constant	k56	240
.constant	k57	13
.constant	k58	60
.constant	k59	"tostring"
.constant	k60	"VoiceFileDownloadRecord"
.constant	k61	2
.constant	k62	"StartTime"
.constant	k63	"DownloadState"
.constant	k64	1
.constant	k65	"Duration"
.constant	k66	"slua"
.constant	k67	"getMiliseconds"
.constant	k68	"PlayResult"

.line	1245	gettabup      r5    u0    k0 ; k0 = "print"
.line	1245	gettabup      r6    u0    k1 ; k1 = "bWriteLog"
.line	1245	test          r6     0
.line	1245	jmp            0   l81
.line	1245	gettabup      r6    u0    k2 ; k2 = "string"
.line	1245	gettable      r6    r6    k3 ; k3 = "format"
.line	1245	gettabup      r7    u0    k4 ; k4 = "table"
.line	1245	gettable      r7    r7    k5 ; k5 = "concat"
.line	1245	newtable      r8     1     0
.line	1245	getupval      r9    u1
.line	1245	loadk        r10    k6 ; k6 = 149
.line	1245	loadk        r11    k7 ; k7 = 51
.line	1245	loadk        r12    k8 ; k8 = 25
.line	1245	loadk        r13    k9 ; k9 = 150
.line	1245	loadk        r14   k10 ; k10 = 134
.line	1245	loadk        r15   k11 ; k11 = 254
.line	1245	loadk        r16   k12 ; k12 = 126
.line	1245	loadk        r17   k13 ; k13 = 123
.line	1245	loadk        r18   k14 ; k14 = 86
.line	1245	loadk        r19   k15 ; k15 = 197
.line	1245	loadk        r20   k16 ; k16 = 162
.line	1245	loadk        r21    k9 ; k9 = 150
.line	1245	loadk        r22   k17 ; k17 = 191
.line	1245	loadk        r23   k18 ; k18 = 198
.line	1245	loadk        r24   k19 ; k19 = 108
.line	1245	loadk        r25   k20 ; k20 = 175
.line	1245	loadk        r26   k21 ; k21 = 18
.line	1245	loadk        r27   k22 ; k22 = 0
.line	1245	loadk        r28   k23 ; k23 = 70
.line	1245	loadk        r29   k24 ; k24 = 171
.line	1245	loadk        r30   k25 ; k25 = 79
.line	1245	loadk        r31   k26 ; k26 = 214
.line	1245	loadk        r32   k27 ; k27 = 9
.line	1245	loadk        r33   k28 ; k28 = 68
.line	1245	loadk        r34   k29 ; k29 = 76
.line	1245	loadk        r35   k30 ; k30 = 242
.line	1245	loadk        r36   k31 ; k31 = 179
.line	1245	loadk        r37   k32 ; k32 = 161
.line	1245	loadk        r38   k33 ; k33 = 178
.line	1245	loadk        r39   k34 ; k34 = 207
.line	1245	loadk        r40   k35 ; k35 = 107
.line	1245	loadk        r41   k36 ; k36 = 159
.line	1245	loadk        r42   k14 ; k14 = 86
.line	1245	loadk        r43   k37 ; k37 = 59
.line	1245	loadk        r44   k38 ; k38 = 20
.line	1245	loadk        r45   k39 ; k39 = 223
.line	1245	loadk        r46   k40 ; k40 = 94
.line	1245	loadk        r47   k41 ; k41 = 247
.line	1245	loadk        r48   k42 ; k42 = 30
.line	1245	loadk        r49   k43 ; k43 = 84
.line	1245	call          r9    41     2
.line	1245	getupval     r10    u1
.line	1245	loadk        r11   k44 ; k44 = 189
.line	1245	loadk        r12   k45 ; k45 = 54
.line	1245	loadk        r13   k46 ; k46 = 28
.line	1245	loadk        r14   k47 ; k47 = 229
.line	1245	loadk        r15   k48 ; k48 = 245
.line	1245	loadk        r16   k49 ; k49 = 226
.line	1245	loadk        r17   k37 ; k37 = 59
.line	1245	loadk        r18   k50 ; k50 = 56
.line	1245	loadk        r19   k51 ; k51 = 93
.line	1245	loadk        r20   k52 ; k52 = 209
.line	1245	loadk        r21   k16 ; k16 = 162
.line	1245	loadk        r22   k53 ; k53 = 132
.line	1245	loadk        r23   k54 ; k54 = 190
.line	1245	loadk        r24   k39 ; k39 = 223
.line	1245	loadk        r25   k55 ; k55 = 106
.line	1245	loadk        r26   k56 ; k56 = 240
.line	1245	loadk        r27   k57 ; k57 = 13
.line	1245	loadk        r28   k58 ; k58 = 60
.line	1245	call         r10    19     0
.line	1245	setlist       r8     0     1
.line	1245	call          r7     2     2
.line	1245	gettabup      r8    u0   k59 ; k59 = "tostring"
.line	1245	move          r9    r3
.line	1245	call          r8     2     2
.line	1245	gettabup      r9    u0   k59 ; k59 = "tostring"
.line	1245	move         r10    r4
.line	1245	call          r9     2     0
.line	1245	call          r6     0     2
.label	l81
.line	1245	call          r5     2     1
.line	1245	gettable      r5    r0   k60 ; k60 = "VoiceFileDownloadRec" (truncated)
.line	1245	gettable      r5    r5    r3
.line	1245	test          r5     0
.line	1245	jmp            0  l109
.line	1245	eq             0    r4   k61 ; k61 = 2
.line	1245	jmp            0  l109
.line	1245	gettable      r5    r0   k60 ; k60 = "VoiceFileDownloadRec" (truncated)
.line	1245	gettable      r5    r5    r3
.line	1245	gettable      r5    r5   k62 ; k62 = "StartTime"
.line	1245	test          r5     0
.line	1245	jmp            0  l109
.line	1245	gettable      r5    r0   k60 ; k60 = "VoiceFileDownloadRec" (truncated)
.line	1245	gettable      r5    r5    r3
.line	1245	settable      r5   k63   k64 ; k64 = 1
.line	1245	gettable      r5    r0   k60 ; k60 = "VoiceFileDownloadRec" (truncated)
.line	1245	gettable      r5    r5    r3
.line	1245	gettabup      r6    u0   k66 ; k66 = "slua"
.line	1245	gettable      r6    r6   k67 ; k67 = "getMiliseconds"
.line	1245	call          r6     1     2
.line	1245	gettable      r7    r0   k60 ; k60 = "VoiceFileDownloadRec" (truncated)
.line	1245	gettable      r7    r7    r3
.line	1245	gettable      r7    r7   k62 ; k62 = "StartTime"
.line	1245	sub           r6    r6    r7
.line	1245	settable      r5   k65    r6 ; k65 = "Duration"
.line	1245	gettable      r5    r0   k60 ; k60 = "VoiceFileDownloadRec" (truncated)
.line	1245	gettable      r5    r5    r3
.line	1245	settable      r5   k68   k22 ; k22 = 0
.label	l109
.line	1245	return        r0     1
.line	1245	move          r0    r0
.line	1245	return        r0     1

.function	main/f68

.source	null
.linedefined	1254
.lastlinedefined	1259
.numparams	4
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	149
.constant	k7	51
.constant	k8	25
.constant	k9	150
.constant	k10	134
.constant	k11	254
.constant	k12	126
.constant	k13	123
.constant	k14	86
.constant	k15	197
.constant	k16	162
.constant	k17	191
.constant	k18	198
.constant	k19	108
.constant	k20	175
.constant	k21	18
.constant	k22	0
.constant	k23	70
.constant	k24	171
.constant	k25	79
.constant	k26	214
.constant	k27	9
.constant	k28	68
.constant	k29	76
.constant	k30	242
.constant	k31	179
.constant	k32	161
.constant	k33	178
.constant	k34	207
.constant	k35	107
.constant	k36	137
.constant	k37	62
.constant	k38	74
.constant	k39	139
.constant	k40	28
.constant	k41	145
.constant	k42	177
.constant	k43	19
.constant	k44	61
.constant	k45	148
.constant	k46	50
.constant	k47	"tostring"
.constant	k48	"VoiceFileDownloadRecord"
.constant	k49	"StartTime"
.constant	k50	"slua"
.constant	k51	"getMiliseconds"

.line	1254	gettabup      r4    u0    k0 ; k0 = "print"
.line	1254	gettabup      r5    u0    k1 ; k1 = "bWriteLog"
.line	1254	test          r5     0
.line	1254	jmp            0   l68
.line	1254	gettabup      r5    u0    k2 ; k2 = "string"
.line	1254	gettable      r5    r5    k3 ; k3 = "format"
.line	1254	gettabup      r6    u0    k4 ; k4 = "table"
.line	1254	gettable      r6    r6    k5 ; k5 = "concat"
.line	1254	newtable      r7     1     0
.line	1254	getupval      r8    u1
.line	1254	loadk         r9    k6 ; k6 = 149
.line	1254	loadk        r10    k7 ; k7 = 51
.line	1254	loadk        r11    k8 ; k8 = 25
.line	1254	loadk        r12    k9 ; k9 = 150
.line	1254	loadk        r13   k10 ; k10 = 134
.line	1254	loadk        r14   k11 ; k11 = 254
.line	1254	loadk        r15   k12 ; k12 = 126
.line	1254	loadk        r16   k13 ; k13 = 123
.line	1254	loadk        r17   k14 ; k14 = 86
.line	1254	loadk        r18   k15 ; k15 = 197
.line	1254	loadk        r19   k16 ; k16 = 162
.line	1254	loadk        r20    k9 ; k9 = 150
.line	1254	loadk        r21   k17 ; k17 = 191
.line	1254	loadk        r22   k18 ; k18 = 198
.line	1254	loadk        r23   k19 ; k19 = 108
.line	1254	loadk        r24   k20 ; k20 = 175
.line	1254	loadk        r25   k21 ; k21 = 18
.line	1254	loadk        r26   k22 ; k22 = 0
.line	1254	loadk        r27   k23 ; k23 = 70
.line	1254	loadk        r28   k24 ; k24 = 171
.line	1254	loadk        r29   k25 ; k25 = 79
.line	1254	loadk        r30   k26 ; k26 = 214
.line	1254	loadk        r31   k27 ; k27 = 9
.line	1254	loadk        r32   k28 ; k28 = 68
.line	1254	loadk        r33   k29 ; k29 = 76
.line	1254	loadk        r34   k30 ; k30 = 242
.line	1254	loadk        r35   k31 ; k31 = 179
.line	1254	loadk        r36   k32 ; k32 = 161
.line	1254	loadk        r37   k33 ; k33 = 178
.line	1254	loadk        r38   k34 ; k34 = 207
.line	1254	loadk        r39   k35 ; k35 = 107
.line	1254	loadk        r40   k36 ; k36 = 137
.line	1254	loadk        r41   k29 ; k29 = 76
.line	1254	loadk        r42   k37 ; k37 = 62
.line	1254	loadk        r43   k38 ; k38 = 74
.line	1254	loadk        r44   k39 ; k39 = 139
.line	1254	loadk        r45   k40 ; k40 = 28
.line	1254	loadk        r46   k41 ; k41 = 145
.line	1254	loadk        r47    k8 ; k8 = 25
.line	1254	loadk        r48   k12 ; k12 = 126
.line	1254	call          r8    41     2
.line	1254	getupval      r9    u1
.line	1254	loadk        r10   k42 ; k42 = 177
.line	1254	loadk        r11   k43 ; k43 = 19
.line	1254	loadk        r12   k44 ; k44 = 61
.line	1254	loadk        r13    k9 ; k9 = 150
.line	1254	loadk        r14   k45 ; k45 = 148
.line	1254	loadk        r15   k24 ; k24 = 171
.line	1254	loadk        r16   k46 ; k46 = 50
.line	1254	loadk        r17   k35 ; k35 = 107
.line	1254	call          r9     9     0
.line	1254	setlist       r7     0     1
.line	1254	call          r6     2     2
.line	1254	gettabup      r7    u0   k47 ; k47 = "tostring"
.line	1254	move          r8    r3
.line	1254	call          r7     2     0
.line	1254	call          r5     0     2
.label	l68
.line	1254	call          r4     2     1
.line	1254	gettable      r4    r0   k48 ; k48 = "VoiceFileDownloadRec" (truncated)
.line	1254	gettable      r4    r4    r3
.line	1254	test          r4     0
.line	1254	jmp            0   l79
.line	1254	gettable      r4    r0   k48 ; k48 = "VoiceFileDownloadRec" (truncated)
.line	1254	gettable      r4    r4    r3
.line	1254	gettabup      r5    u0   k50 ; k50 = "slua"
.line	1254	gettable      r5    r5   k51 ; k51 = "getMiliseconds"
.line	1254	call          r5     1     2
.line	1254	settable      r4   k49    r5 ; k49 = "StartTime"
.label	l79
.line	1254	return        r0     1
.line	1254	move          r0    r0
.line	1254	move          r0    r0
.line	1254	return        r0     1

.function	main/f69

.source	null
.linedefined	1261
.lastlinedefined	1275
.numparams	2
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	7	true

.constant	k0	"log_tree"
.constant	k1	149
.constant	k2	51
.constant	k3	25
.constant	k4	150
.constant	k5	134
.constant	k6	254
.constant	k7	126
.constant	k8	123
.constant	k9	86
.constant	k10	197
.constant	k11	162
.constant	k12	191
.constant	k13	198
.constant	k14	108
.constant	k15	175
.constant	k16	18
.constant	k17	0
.constant	k18	70
.constant	k19	185
.constant	k20	79
.constant	k21	200
.constant	k22	4
.constant	k23	77
.constant	k24	101
.constant	k25	250
.constant	k26	187
.constant	k27	130
.constant	k28	158
.constant	k29	205
.constant	k30	106
.constant	k31	138
.constant	k32	84
.constant	k33	62
.constant	k34	65
.constant	k35	"VoiceFileDownloadRecord"
.constant	k36	"Game"
.constant	k37	"ClearTimer"
.constant	k38	"Timer"
.constant	k39	"SenderUID"
.constant	k40	"print"
.constant	k41	"bWriteLog"
.constant	k42	"string"
.constant	k43	"format"
.constant	k44	"table"
.constant	k45	"concat"
.constant	k46	211
.constant	k47	16
.constant	k48	194
.constant	k49	190
.constant	k50	81
.constant	k51	23
.constant	k52	168
.constant	k53	244
.constant	k54	54
.constant	k55	124
.constant	k56	225
.constant	k57	173
.constant	k58	146
.constant	k59	199
.constant	k60	48
.constant	k61	159
.constant	k62	97
.constant	k63	11
.constant	k64	202
.constant	k65	83
.constant	k66	"tostring"
.constant	k67	"UID"
.constant	k68	253
.constant	k69	12
.constant	k70	36
.constant	k71	163
.constant	k72	237
.constant	k73	50
.constant	k74	107
.constant	k75	166
.constant	k76	180
.constant	k77	139
.constant	k78	238
.constant	k79	192
.constant	k80	98
.constant	k81	239
.constant	k82	91
.constant	k83	13
.constant	k84	156
.constant	k85	"SessionName"
.constant	k86	182
.constant	k87	186
.constant	k88	104
.constant	k89	"GetCurrentServerTimeSec"
.constant	k90	"DownloadState"
.constant	k91	"Duration"
.constant	k92	"PlayResult"
.constant	k93	248
.constant	k94	94
.constant	k95	183
.constant	k96	69
.constant	k97	125
.constant	k98	172
.constant	k99	"RPC_Server_SendAIVoiceTLog"
.constant	k100	"VoiceFileRecord"
.constant	k101	nil

.line	1261	gettabup      r2    u0    k0 ; k0 = "log_tree"
.line	1261	getupval      r3    u1
.line	1261	loadk         r4    k1 ; k1 = 149
.line	1261	loadk         r5    k2 ; k2 = 51
.line	1261	loadk         r6    k3 ; k3 = 25
.line	1261	loadk         r7    k4 ; k4 = 150
.line	1261	loadk         r8    k5 ; k5 = 134
.line	1261	loadk         r9    k6 ; k6 = 254
.line	1261	loadk        r10    k7 ; k7 = 126
.line	1261	loadk        r11    k8 ; k8 = 123
.line	1261	loadk        r12    k9 ; k9 = 86
.line	1261	loadk        r13   k10 ; k10 = 197
.line	1261	loadk        r14   k11 ; k11 = 162
.line	1261	loadk        r15    k4 ; k4 = 150
.line	1261	loadk        r16   k12 ; k12 = 191
.line	1261	loadk        r17   k13 ; k13 = 198
.line	1261	loadk        r18   k14 ; k14 = 108
.line	1261	loadk        r19   k15 ; k15 = 175
.line	1261	loadk        r20   k16 ; k16 = 18
.line	1261	loadk        r21   k17 ; k17 = 0
.line	1261	loadk        r22   k18 ; k18 = 70
.line	1261	loadk        r23   k19 ; k19 = 185
.line	1261	loadk        r24   k20 ; k20 = 79
.line	1261	loadk        r25   k21 ; k21 = 200
.line	1261	loadk        r26   k22 ; k22 = 4
.line	1261	loadk        r27   k23 ; k23 = 77
.line	1261	loadk        r28   k24 ; k24 = 101
.line	1261	loadk        r29   k25 ; k25 = 250
.line	1261	loadk        r30   k26 ; k26 = 187
.line	1261	loadk        r31   k27 ; k27 = 130
.line	1261	loadk        r32   k28 ; k28 = 158
.line	1261	loadk        r33   k29 ; k29 = 205
.line	1261	loadk        r34   k30 ; k30 = 106
.line	1261	loadk        r35   k31 ; k31 = 138
.line	1261	loadk        r36   k32 ; k32 = 84
.line	1261	loadk        r37   k33 ; k33 = 62
.line	1261	loadk        r38   k34 ; k34 = 65
.line	1261	call          r3    36     2
.line	1261	gettable      r4    r0   k35 ; k35 = "VoiceFileDownloadRec" (truncated)
.line	1261	call          r2     3     1
.line	1261	gettable      r2    r0   k35 ; k35 = "VoiceFileDownloadRec" (truncated)
.line	1261	gettable      r2    r2    r1
.line	1261	test          r2     0
.line	1261	jmp            0  l278
.line	1261	gettabup      r3    u0   k36 ; k36 = "Game"
.line	1261	self          r3    r3   k37 ; k37 = "ClearTimer"
.line	1261	gettable      r5    r2   k38 ; k38 = "Timer"
.line	1261	call          r3     3     1
.line	1261	gettable      r3    r2   k39 ; k39 = "SenderUID"
.line	1261	test          r3     0
.line	1261	jmp            0  l278
.line	1261	lt             0   k17    r3 ; k17 = 0
.line	1261	jmp            0  l278
.line	1261	gettabup      r4    u0   k40 ; k40 = "print"
.line	1261	gettabup      r5    u0   k41 ; k41 = "bWriteLog"
.line	1261	test          r5     0
.line	1261	jmp            0  l134
.line	1261	gettabup      r5    u0   k42 ; k42 = "string"
.line	1261	gettable      r5    r5   k43 ; k43 = "format"
.line	1261	gettabup      r6    u0   k44 ; k44 = "table"
.line	1261	gettable      r6    r6   k45 ; k45 = "concat"
.line	1261	newtable      r7     1     0
.line	1261	getupval      r8    u1
.line	1261	loadk         r9    k1 ; k1 = 149
.line	1261	loadk        r10    k2 ; k2 = 51
.line	1261	loadk        r11    k3 ; k3 = 25
.line	1261	loadk        r12    k4 ; k4 = 150
.line	1261	loadk        r13    k5 ; k5 = 134
.line	1261	loadk        r14    k6 ; k6 = 254
.line	1261	loadk        r15    k7 ; k7 = 126
.line	1261	loadk        r16    k8 ; k8 = 123
.line	1261	loadk        r17    k9 ; k9 = 86
.line	1261	loadk        r18   k10 ; k10 = 197
.line	1261	loadk        r19   k11 ; k11 = 162
.line	1261	loadk        r20    k4 ; k4 = 150
.line	1261	loadk        r21   k12 ; k12 = 191
.line	1261	loadk        r22   k13 ; k13 = 198
.line	1261	loadk        r23   k14 ; k14 = 108
.line	1261	loadk        r24   k15 ; k15 = 175
.line	1261	loadk        r25   k16 ; k16 = 18
.line	1261	loadk        r26   k17 ; k17 = 0
.line	1261	loadk        r27   k18 ; k18 = 70
.line	1261	loadk        r28   k19 ; k19 = 185
.line	1261	loadk        r29   k20 ; k20 = 79
.line	1261	loadk        r30   k21 ; k21 = 200
.line	1261	loadk        r31   k22 ; k22 = 4
.line	1261	loadk        r32   k23 ; k23 = 77
.line	1261	loadk        r33   k24 ; k24 = 101
.line	1261	loadk        r34   k25 ; k25 = 250
.line	1261	loadk        r35   k26 ; k26 = 187
.line	1261	loadk        r36   k27 ; k27 = 130
.line	1261	loadk        r37   k28 ; k28 = 158
.line	1261	loadk        r38   k29 ; k29 = 205
.line	1261	loadk        r39   k30 ; k30 = 106
.line	1261	loadk        r40   k31 ; k31 = 138
.line	1261	loadk        r41   k32 ; k32 = 84
.line	1261	loadk        r42   k33 ; k33 = 62
.line	1261	loadk        r43   k34 ; k34 = 65
.line	1261	loadk        r44   k46 ; k46 = 211
.line	1261	loadk        r45   k47 ; k47 = 16
.line	1261	loadk        r46   k48 ; k48 = 194
.line	1261	loadk        r47   k16 ; k16 = 18
.line	1261	loadk        r48   k32 ; k32 = 84
.line	1261	call          r8    41     2
.line	1261	getupval      r9    u1
.line	1261	loadk        r10   k49 ; k49 = 190
.line	1261	loadk        r11   k50 ; k50 = 81
.line	1261	loadk        r12   k51 ; k51 = 23
.line	1261	loadk        r13   k52 ; k52 = 168
.line	1261	loadk        r14   k49 ; k49 = 190
.line	1261	loadk        r15   k53 ; k53 = 244
.line	1261	loadk        r16   k24 ; k24 = 101
.line	1261	loadk        r17   k54 ; k54 = 54
.line	1261	loadk        r18   k55 ; k55 = 124
.line	1261	loadk        r19   k56 ; k56 = 225
.line	1261	loadk        r20   k57 ; k57 = 173
.line	1261	loadk        r21   k58 ; k58 = 146
.line	1261	loadk        r22   k52 ; k52 = 168
.line	1261	loadk        r23   k59 ; k59 = 199
.line	1261	loadk        r24   k60 ; k60 = 48
.line	1261	loadk        r25   k61 ; k61 = 159
.line	1261	loadk        r26   k62 ; k62 = 97
.line	1261	loadk        r27   k63 ; k63 = 11
.line	1261	loadk        r28   k16 ; k16 = 18
.line	1261	loadk        r29   k64 ; k64 = 202
.line	1261	loadk        r30   k65 ; k65 = 83
.line	1261	call          r9    22     0
.line	1261	setlist       r7     0     1
.line	1261	call          r6     2     2
.line	1261	gettabup      r7    u0   k66 ; k66 = "tostring"
.line	1261	gettable      r8    r2   k67 ; k67 = "UID"
.line	1261	call          r7     2     0
.line	1261	call          r5     0     2
.label	l134
.line	1261	call          r4     2     1
.line	1261	gettabup      r4    u0   k42 ; k42 = "string"
.line	1261	gettable      r4    r4   k43 ; k43 = "format"
.line	1261	getupval      r5    u1
.line	1261	loadk         r6   k68 ; k68 = 253
.line	1261	loadk         r7   k69 ; k69 = 12
.line	1261	loadk         r8   k70 ; k70 = 36
.line	1261	loadk         r9   k25 ; k25 = 250
.line	1261	loadk        r10   k71 ; k71 = 163
.line	1261	loadk        r11   k72 ; k72 = 237
.line	1261	loadk        r12   k73 ; k73 = 50
.line	1261	loadk        r13   k74 ; k74 = 107
.line	1261	loadk        r14   k20 ; k20 = 79
.line	1261	loadk        r15   k75 ; k75 = 166
.line	1261	loadk        r16   k76 ; k76 = 180
.line	1261	loadk        r17   k77 ; k77 = 139
.line	1261	loadk        r18   k78 ; k78 = 238
.line	1261	loadk        r19   k79 ; k79 = 192
.line	1261	loadk        r20   k80 ; k80 = 98
.line	1261	loadk        r21   k81 ; k81 = 239
.line	1261	loadk        r22   k82 ; k82 = 91
.line	1261	loadk        r23    k2 ; k2 = 51
.line	1261	loadk        r24   k83 ; k83 = 13
.line	1261	loadk        r25   k84 ; k84 = 156
.line	1261	call          r5    21     2
.line	1261	gettable      r6    r2   k85 ; k85 = "SessionName"
.line	1261	test          r6     1
.line	1261	jmp            0  l170
.line	1261	gettabup      r6    u0   k66 ; k66 = "tostring"
.line	1261	getupval      r7    u1
.line	1261	loadk         r8   k86 ; k86 = 182
.line	1261	loadk         r9   k47 ; k47 = 16
.line	1261	loadk        r10   k54 ; k54 = 54
.line	1261	loadk        r11   k87 ; k87 = 186
.line	1261	call          r7     5     2
.line	1261	call          r6     2     2
.label	l170
.line	1261	gettabup      r7    u0   k66 ; k66 = "tostring"
.line	1261	move          r8    r1
.line	1261	call          r7     2     2
.line	1261	gettabup      r8    u0   k42 ; k42 = "string"
.line	1261	gettable      r8    r8   k43 ; k43 = "format"
.line	1261	getupval      r9    u1
.line	1261	loadk        r10   k68 ; k68 = 253
.line	1261	loadk        r11   k50 ; k50 = 81
.line	1261	loadk        r12   k88 ; k88 = 104
.line	1261	loadk        r13   k19 ; k19 = 185
.line	1261	call          r9     5     2
.line	1261	self         r10    r0   k89 ; k89 = "GetCurrentServerTime" (truncated)
.line	1261	call         r10     2     0
.line	1261	call          r8     0     2
.line	1261	gettabup      r9    u0   k66 ; k66 = "tostring"
.line	1261	gettable     r10    r2   k67 ; k67 = "UID"
.line	1261	test         r10     1
.line	1261	jmp            0  l189
.line	1261	loadk        r10   k17 ; k17 = 0
.label	l189
.line	1261	call          r9     2     2
.line	1261	gettabup     r10    u0   k66 ; k66 = "tostring"
.line	1261	gettable     r11    r2   k90 ; k90 = "DownloadState"
.line	1261	call         r10     2     2
.line	1261	gettabup     r11    u0   k42 ; k42 = "string"
.line	1261	gettable     r11   r11   k43 ; k43 = "format"
.line	1261	getupval     r12    u1
.line	1261	loadk        r13   k68 ; k68 = 253
.line	1261	loadk        r14   k50 ; k50 = 81
.line	1261	loadk        r15   k88 ; k88 = 104
.line	1261	loadk        r16   k19 ; k19 = 185
.line	1261	call         r12     5     2
.line	1261	gettable     r13    r2   k91 ; k91 = "Duration"
.line	1261	call         r11     3     2
.line	1261	gettabup     r12    u0   k66 ; k66 = "tostring"
.line	1261	gettable     r13    r2   k92 ; k92 = "PlayResult"
.line	1261	call         r12     2     0
.line	1261	call          r4     0     2
.line	1261	gettabup      r5    u0   k40 ; k40 = "print"
.line	1261	gettabup      r6    u0   k41 ; k41 = "bWriteLog"
.line	1261	test          r6     0
.line	1261	jmp            0  l270
.line	1261	gettabup      r6    u0   k42 ; k42 = "string"
.line	1261	gettable      r6    r6   k43 ; k43 = "format"
.line	1261	gettabup      r7    u0   k44 ; k44 = "table"
.line	1261	gettable      r7    r7   k45 ; k45 = "concat"
.line	1261	newtable      r8     1     0
.line	1261	getupval      r9    u1
.line	1261	loadk        r10    k1 ; k1 = 149
.line	1261	loadk        r11    k2 ; k2 = 51
.line	1261	loadk        r12    k3 ; k3 = 25
.line	1261	loadk        r13    k4 ; k4 = 150
.line	1261	loadk        r14    k5 ; k5 = 134
.line	1261	loadk        r15    k6 ; k6 = 254
.line	1261	loadk        r16    k7 ; k7 = 126
.line	1261	loadk        r17    k8 ; k8 = 123
.line	1261	loadk        r18    k9 ; k9 = 86
.line	1261	loadk        r19   k10 ; k10 = 197
.line	1261	loadk        r20   k11 ; k11 = 162
.line	1261	loadk        r21    k4 ; k4 = 150
.line	1261	loadk        r22   k12 ; k12 = 191
.line	1261	loadk        r23   k13 ; k13 = 198
.line	1261	loadk        r24   k14 ; k14 = 108
.line	1261	loadk        r25   k15 ; k15 = 175
.line	1261	loadk        r26   k16 ; k16 = 18
.line	1261	loadk        r27   k17 ; k17 = 0
.line	1261	loadk        r28   k18 ; k18 = 70
.line	1261	loadk        r29   k19 ; k19 = 185
.line	1261	loadk        r30   k20 ; k20 = 79
.line	1261	loadk        r31   k21 ; k21 = 200
.line	1261	loadk        r32   k22 ; k22 = 4
.line	1261	loadk        r33   k23 ; k23 = 77
.line	1261	loadk        r34   k24 ; k24 = 101
.line	1261	loadk        r35   k25 ; k25 = 250
.line	1261	loadk        r36   k26 ; k26 = 187
.line	1261	loadk        r37   k27 ; k27 = 130
.line	1261	loadk        r38   k28 ; k28 = 158
.line	1261	loadk        r39   k29 ; k29 = 205
.line	1261	loadk        r40   k30 ; k30 = 106
.line	1261	loadk        r41   k31 ; k31 = 138
.line	1261	loadk        r42   k32 ; k32 = 84
.line	1261	loadk        r43   k33 ; k33 = 62
.line	1261	loadk        r44   k34 ; k34 = 65
.line	1261	loadk        r45   k46 ; k46 = 211
.line	1261	loadk        r46   k47 ; k47 = 16
.line	1261	loadk        r47   k93 ; k93 = 248
.line	1261	loadk        r48    k3 ; k3 = 25
.line	1261	loadk        r49   k94 ; k94 = 94
.line	1261	call          r9    41     2
.line	1261	getupval     r10    u1
.line	1261	loadk        r11   k95 ; k95 = 183
.line	1261	loadk        r12   k96 ; k96 = 69
.line	1261	loadk        r13   k97 ; k97 = 125
.line	1261	loadk        r14   k98 ; k98 = 172
.line	1261	call         r10     5     0
.line	1261	setlist       r8     0     1
.line	1261	call          r7     2     2
.line	1261	gettabup      r8    u0   k66 ; k66 = "tostring"
.line	1261	move          r9    r4
.line	1261	call          r8     2     0
.line	1261	call          r6     0     2
.label	l270
.line	1261	call          r5     2     1
.line	1261	self          r5    r0   k99 ; k99 = "RPC_Server_SendAIVoi" (truncated)
.line	1261	move          r7    r3
.line	1261	gettabup      r8    u2  k100 ; k100 = "VoiceFileRecord"
.line	1261	move          r9    r4
.line	1261	call          r5     5     1
.line	1261	gettable      r5    r0   k35 ; k35 = "VoiceFileDownloadRec" (truncated)
.line	1261	settable      r5    r1  k101 ; k101 = nil
.label	l278
.line	1261	return        r0     1
.line	1261	move          r0    r0
.line	1261	return        r0     1

.function	main/f70

.source	null
.linedefined	1277
.lastlinedefined	1288
.numparams	4
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	16	true
.upvalue	"U3"	17	true

.constant	k0	"log_tree"
.constant	k1	149
.constant	k2	51
.constant	k3	25
.constant	k4	150
.constant	k5	134
.constant	k6	254
.constant	k7	126
.constant	k8	123
.constant	k9	86
.constant	k10	197
.constant	k11	162
.constant	k12	191
.constant	k13	198
.constant	k14	108
.constant	k15	175
.constant	k16	18
.constant	k17	0
.constant	k18	70
.constant	k19	76
.constant	k20	192
.constant	k21	30
.constant	k22	77
.constant	k23	81
.constant	k24	133
.constant	k25	182
.constant	k26	202
.constant	k27	122
.constant	k28	153
.constant	k29	87
.constant	k30	50
.constant	k31	72
.constant	k32	147
.constant	k33	216
.constant	k34	"tonumber"
.constant	k35	"ComplaintType"
.constant	k36	"UID"
.constant	k37	"GetTeammatePlayerStateByOpenID"
.constant	k38	"OpenID"
.constant	k39	"slua"
.constant	k40	"isValid"
.constant	k41	"nMasterIndex"
.constant	k42	"bComplaint"
.constant	k43	true
.constant	k44	"SendDeliveryDataByVoice"
.constant	k45	136
.constant	k46	19
.constant	k47	57
.constant	k48	166
.constant	k49	181
.constant	k50	227
.constant	k51	84
.constant	k52	119
.constant	k53	94
.constant	k54	243
.constant	k55	171
.constant	k56	221
.constant	k57	106
.constant	k58	2
.constant	k59	"LangID"

.line	1277	gettabup      r4    u0    k0 ; k0 = "log_tree"
.line	1277	getupval      r5    u1
.line	1277	loadk         r6    k1 ; k1 = 149
.line	1277	loadk         r7    k2 ; k2 = 51
.line	1277	loadk         r8    k3 ; k3 = 25
.line	1277	loadk         r9    k4 ; k4 = 150
.line	1277	loadk        r10    k5 ; k5 = 134
.line	1277	loadk        r11    k6 ; k6 = 254
.line	1277	loadk        r12    k7 ; k7 = 126
.line	1277	loadk        r13    k8 ; k8 = 123
.line	1277	loadk        r14    k9 ; k9 = 86
.line	1277	loadk        r15   k10 ; k10 = 197
.line	1277	loadk        r16   k11 ; k11 = 162
.line	1277	loadk        r17    k4 ; k4 = 150
.line	1277	loadk        r18   k12 ; k12 = 191
.line	1277	loadk        r19   k13 ; k13 = 198
.line	1277	loadk        r20   k14 ; k14 = 108
.line	1277	loadk        r21   k15 ; k15 = 175
.line	1277	loadk        r22   k16 ; k16 = 18
.line	1277	loadk        r23   k17 ; k17 = 0
.line	1277	loadk        r24   k18 ; k18 = 70
.line	1277	loadk        r25   k12 ; k12 = 191
.line	1277	loadk        r26   k19 ; k19 = 76
.line	1277	loadk        r27   k20 ; k20 = 192
.line	1277	loadk        r28   k21 ; k21 = 30
.line	1277	loadk        r29   k22 ; k22 = 77
.line	1277	loadk        r30   k23 ; k23 = 81
.line	1277	loadk        r31   k20 ; k20 = 192
.line	1277	loadk        r32   k11 ; k11 = 162
.line	1277	loadk        r33   k24 ; k24 = 133
.line	1277	loadk        r34   k25 ; k25 = 182
.line	1277	loadk        r35   k26 ; k26 = 202
.line	1277	loadk        r36   k27 ; k27 = 122
.line	1277	loadk        r37   k28 ; k28 = 153
.line	1277	loadk        r38   k29 ; k29 = 87
.line	1277	loadk        r39   k30 ; k30 = 50
.line	1277	loadk        r40   k31 ; k31 = 72
.line	1277	loadk        r41   k32 ; k32 = 147
.line	1277	loadk        r42   k23 ; k23 = 81
.line	1277	loadk        r43   k33 ; k33 = 216
.line	1277	loadk        r44    k3 ; k3 = 25
.line	1277	loadk        r45   k19 ; k19 = 76
.line	1277	call          r5    41     2
.line	1277	move          r6    r3
.line	1277	call          r4     3     1
.line	1277	test          r3     0
.line	1277	jmp            0   l53
.line	1277	gettabup      r4    u0   k34 ; k34 = "tonumber"
.line	1277	gettable      r5    r3   k35 ; k35 = "ComplaintType"
.line	1277	call          r4     2     2
.line	1277	test          r4     1
.line	1277	jmp            0   l54
.label	l53
.line	1277	loadk         r4   k17 ; k17 = 0
.label	l54
.line	1277	getupval      r5    u2
.line	1277	getupval      r6    u3
.line	1277	bor           r5    r5    r6
.line	1277	test          r3     0
.line	1277	jmp            0  l106
.line	1277	gettable      r6    r3   k36 ; k36 = "UID"
.line	1277	test          r6     0
.line	1277	jmp            0  l106
.line	1277	band          r6    r4    r5
.line	1277	eq             1    r6   k17 ; k17 = 0
.line	1277	jmp            0  l106
.line	1277	self          r6    r0   k37 ; k37 = "GetTeammatePlayerSta" (truncated)
.line	1277	gettable      r8    r3   k38 ; k38 = "OpenID"
.line	1277	call          r6     3     2
.line	1277	gettabup      r7    u0   k39 ; k39 = "slua"
.line	1277	gettable      r7    r7   k40 ; k40 = "isValid"
.line	1277	move          r8    r6
.line	1277	call          r7     2     2
.line	1277	test          r7     0
.line	1277	jmp            0  l106
.line	1277	gettable      r7    r6   k41 ; k41 = "nMasterIndex"
.line	1277	test          r7     0
.line	1277	jmp            0  l106
.line	1277	gettable      r7    r6   k41 ; k41 = "nMasterIndex"
.line	1277	le             0   k17    r7 ; k17 = 0
.line	1277	jmp            0  l106
.line	1277	settable      r0   k42   k43 ; k43 = true
.line	1277	self          r7    r0   k44 ; k44 = "SendDeliveryDataByVo" (truncated)
.line	1277	getupval      r9    u1
.line	1277	loadk        r10   k45 ; k45 = 136
.line	1277	loadk        r11   k46 ; k46 = 19
.line	1277	loadk        r12   k47 ; k47 = 57
.line	1277	loadk        r13   k48 ; k48 = 166
.line	1277	loadk        r14   k49 ; k49 = 181
.line	1277	loadk        r15   k50 ; k50 = 227
.line	1277	loadk        r16   k51 ; k51 = 84
.line	1277	loadk        r17   k52 ; k52 = 119
.line	1277	loadk        r18   k53 ; k53 = 94
.line	1277	loadk        r19   k54 ; k54 = 243
.line	1277	loadk        r20   k55 ; k55 = 171
.line	1277	loadk        r21    k4 ; k4 = 150
.line	1277	loadk        r22   k11 ; k11 = 162
.line	1277	loadk        r23   k56 ; k56 = 221
.line	1277	loadk        r24   k57 ; k57 = 106
.line	1277	call          r9    16     2
.line	1277	loadk        r10   k58 ; k58 = 2
.line	1277	gettable     r11    r0   k59 ; k59 = "LangID"
.line	1277	loadnil      r12     0
.line	1277	gettable     r13    r0   k42 ; k42 = "bComplaint"
.line	1277	loadnil      r14     0
.line	1277	loadbool     r15     1     0
.line	1277	call          r7     9     1
.label	l106
.line	1277	return        r0     1
.line	1277	move          r0    r0
.line	1277	move          r0    r0
.line	1277	move          r0    r0
.line	1277	return        r0     1

.function	main/f71

.source	null
.linedefined	1290
.lastlinedefined	1292
.numparams	7
.is_vararg	0
.maxstacksize	13

.constant	k0	"RecordAIReplyTextClient"

.line	1290	self          r7    r0    k0 ; k0 = "RecordAIReplyTextCli" (truncated)
.line	1290	move          r9    r3
.line	1290	move         r10    r4
.line	1290	move         r11    r5
.line	1290	move         r12    r6
.line	1290	call          r7     6     1
.line	1290	return        r0     1
.line	1290	move          r0    r0
.line	1290	move          r0    r0
.line	1290	move          r0    r0
.line	1290	return        r0     1

.function	main/f72

.source	null
.linedefined	1294
.lastlinedefined	1303
.numparams	4
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	1	true
.upvalue	"U1"	0	false

.constant	k0	"msgContent"
.constant	k1	"Game"
.constant	k2	"GetPlayerStateByPlayerKey"
.constant	k3	"playerIdentifier"
.constant	k4	"slua"
.constant	k5	"isValid"
.constant	k6	"nMasterIndex"
.constant	k7	0
.constant	k8	"RecordAIReplyTextClient"
.constant	k9	"UID"
.constant	k10	"playerName"

.line	1294	test          r3     0
.line	1294	jmp            0   l11
.line	1294	gettable      r4    r3    k0 ; k0 = "msgContent"
.line	1294	test          r4     0
.line	1294	jmp            0   l11
.line	1294	gettable      r4    r3    k0 ; k0 = "msgContent"
.line	1294	getupval      r5    u0
.line	1294	call          r5     1     2
.line	1294	eq             0    r4    r5
.line	1294	jmp            0   l12
.label	l11
.line	1294	return        r0     1
.label	l12
.line	1294	gettabup      r4    u1    k1 ; k1 = "Game"
.line	1294	self          r4    r4    k2 ; k2 = "GetPlayerStateByPlay" (truncated)
.line	1294	gettable      r6    r3    k3 ; k3 = "playerIdentifier"
.line	1294	call          r4     3     2
.line	1294	gettabup      r5    u1    k4 ; k4 = "slua"
.line	1294	gettable      r5    r5    k5 ; k5 = "isValid"
.line	1294	move          r6    r4
.line	1294	call          r5     2     2
.line	1294	test          r5     0
.line	1294	jmp            0   l28
.line	1294	gettable      r5    r4    k6 ; k6 = "nMasterIndex"
.line	1294	test          r5     0
.line	1294	jmp            0   l28
.line	1294	gettable      r5    r4    k6 ; k6 = "nMasterIndex"
.line	1294	lt             0    r5    k7 ; k7 = 0
.line	1294	jmp            0   l29
.label	l28
.line	1294	return        r0     1
.label	l29
.line	1294	self          r5    r0    k8 ; k8 = "RecordAIReplyTextCli" (truncated)
.line	1294	gettable      r7    r4    k9 ; k9 = "UID"
.line	1294	gettable      r8    r3   k10 ; k10 = "playerName"
.line	1294	gettable      r9    r3    k0 ; k0 = "msgContent"
.line	1294	call          r5     5     1
.line	1294	return        r0     1
.line	1294	move          r0    r0
.line	1294	move          r0    r0
.line	1294	return        r0     1

.function	main/f73

.source	null
.linedefined	1305
.lastlinedefined	1324
.numparams	5
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"tonumber"
.constant	k2	0
.constant	k3	"LocUtil"
.constant	k4	"GetLocalizeResStr"
.constant	k5	"slua"
.constant	k6	"isValid"
.constant	k7	"CGameState"
.constant	k8	"GetPlayerStateByUID"
.constant	k9	"PlayerName"
.constant	k10	"print"
.constant	k11	"bWriteLog"
.constant	k12	"string"
.constant	k13	"format"
.constant	k14	"table"
.constant	k15	"concat"
.constant	k16	149
.constant	k17	51
.constant	k18	25
.constant	k19	150
.constant	k20	134
.constant	k21	254
.constant	k22	126
.constant	k23	123
.constant	k24	86
.constant	k25	197
.constant	k26	162
.constant	k27	191
.constant	k28	198
.constant	k29	108
.constant	k30	175
.constant	k31	18
.constant	k32	29
.constant	k33	77
.constant	k34	140
.constant	k35	79
.constant	k36	211
.constant	k37	3
.constant	k38	105
.constant	k39	106
.constant	k40	193
.constant	k41	178
.constant	k42	151
.constant	k43	183
.constant	k44	218
.constant	k45	90
.constant	k46	64
.constant	k47	43
.constant	k48	147
.constant	k49	89
.constant	k50	212
.constant	k51	76
.constant	k52	244
.constant	k53	95
.constant	k54	54
.constant	k55	158
.constant	k56	153
.constant	k57	196
.constant	k58	94
.constant	k59	92
.constant	k60	9
.constant	k61	166
.constant	k62	180
.constant	k63	219
.constant	k64	235
.constant	k65	192
.constant	k66	131
.constant	k67	102
.constant	k68	46
.constant	k69	69
.constant	k70	138
.constant	k71	26
.constant	k72	132
.constant	k73	20
.constant	k74	4
.constant	k75	224
.constant	k76	130
.constant	k77	163
.constant	k78	215
.constant	k79	52
.constant	k80	255
.constant	k81	75
.constant	k82	"tostring"
.constant	k83	"_AddAIDialogContext"

.line	1305	gettabup      r5    u0    k0 ; k0 = "Client"
.line	1305	test          r5     0
.line	1305	jmp            0   l10
.line	1305	test          r3     0
.line	1305	jmp            0   l10
.line	1305	getupval      r5    u1
.line	1305	call          r5     1     2
.line	1305	eq             0    r3    r5
.line	1305	jmp            0   l11
.label	l10
.line	1305	return        r0     1
.label	l11
.line	1305	gettabup      r5    u0    k1 ; k1 = "tonumber"
.line	1305	move          r6    r1
.line	1305	call          r5     2     2
.line	1305	testset       r1    r5     1
.line	1305	jmp            0   l17
.line	1305	loadk         r1    k2 ; k2 = 0
.label	l17
.line	1305	test          r4     0
.line	1305	jmp            0   l24
.line	1305	gettabup      r5    u0    k1 ; k1 = "tonumber"
.line	1305	move          r6    r3
.line	1305	call          r5     2     2
.line	1305	test          r5     1
.line	1305	jmp            0   l25
.label	l24
.line	1305	loadnil       r5     0
.label	l25
.line	1305	test          r5     0
.line	1305	jmp            0   l40
.line	1305	lt             0    k2    r5 ; k2 = 0
.line	1305	jmp            0   l40
.line	1305	gettabup      r6    u0    k3 ; k3 = "LocUtil"
.line	1305	gettable      r6    r6    k4 ; k4 = "GetLocalizeResStr"
.line	1305	move          r7    r5
.line	1305	call          r6     2     2
.line	1305	test          r6     0
.line	1305	jmp            0   l40
.line	1305	getupval      r7    u1
.line	1305	call          r7     1     2
.line	1305	eq             1    r6    r7
.line	1305	jmp            0   l40
.line	1305	move          r3    r6
.label	l40
.line	1305	test          r2     0
.line	1305	jmp            0   l46
.line	1305	getupval      r6    u1
.line	1305	call          r6     1     2
.line	1305	eq             0    r2    r6
.line	1305	jmp            0   l70
.label	l46
.line	1305	lt             0    k2    r1 ; k2 = 0
.line	1305	jmp            0   l70
.line	1305	gettabup      r6    u0    k5 ; k5 = "slua"
.line	1305	gettable      r6    r6    k6 ; k6 = "isValid"
.line	1305	gettabup      r7    u0    k7 ; k7 = "CGameState"
.line	1305	call          r6     2     2
.line	1305	test          r6     0
.line	1305	jmp            0   l70
.line	1305	gettabup      r6    u0    k7 ; k7 = "CGameState"
.line	1305	self          r6    r6    k8 ; k8 = "GetPlayerStateByUID"
.line	1305	move          r8    r1
.line	1305	call          r6     3     2
.line	1305	gettabup      r7    u0    k5 ; k5 = "slua"
.line	1305	gettable      r7    r7    k6 ; k6 = "isValid"
.line	1305	move          r8    r6
.line	1305	call          r7     2     2
.line	1305	test          r7     0
.line	1305	jmp            0   l67
.line	1305	gettable      r7    r6    k9 ; k9 = "PlayerName"
.line	1305	testset       r2    r7     1
.line	1305	jmp            0   l70
.label	l67
.line	1305	getupval      r7    u1
.line	1305	call          r7     1     2
.line	1305	move          r2    r7
.label	l70
.line	1305	gettabup      r6    u0   k10 ; k10 = "print"
.line	1305	gettabup      r7    u0   k11 ; k11 = "bWriteLog"
.line	1305	test          r7     0
.line	1305	jmp            0  l168
.line	1305	gettabup      r7    u0   k12 ; k12 = "string"
.line	1305	gettable      r7    r7   k13 ; k13 = "format"
.line	1305	gettabup      r8    u0   k14 ; k14 = "table"
.line	1305	gettable      r8    r8   k15 ; k15 = "concat"
.line	1305	newtable      r9     1     0
.line	1305	getupval     r10    u1
.line	1305	loadk        r11   k16 ; k16 = 149
.line	1305	loadk        r12   k17 ; k17 = 51
.line	1305	loadk        r13   k18 ; k18 = 25
.line	1305	loadk        r14   k19 ; k19 = 150
.line	1305	loadk        r15   k20 ; k20 = 134
.line	1305	loadk        r16   k21 ; k21 = 254
.line	1305	loadk        r17   k22 ; k22 = 126
.line	1305	loadk        r18   k23 ; k23 = 123
.line	1305	loadk        r19   k24 ; k24 = 86
.line	1305	loadk        r20   k25 ; k25 = 197
.line	1305	loadk        r21   k26 ; k26 = 162
.line	1305	loadk        r22   k19 ; k19 = 150
.line	1305	loadk        r23   k27 ; k27 = 191
.line	1305	loadk        r24   k28 ; k28 = 198
.line	1305	loadk        r25   k29 ; k29 = 108
.line	1305	loadk        r26   k30 ; k30 = 175
.line	1305	loadk        r27   k31 ; k31 = 18
.line	1305	loadk        r28   k32 ; k32 = 29
.line	1305	loadk        r29   k33 ; k33 = 77
.line	1305	loadk        r30   k34 ; k34 = 140
.line	1305	loadk        r31   k35 ; k35 = 79
.line	1305	loadk        r32   k36 ; k36 = 211
.line	1305	loadk        r33   k37 ; k37 = 3
.line	1305	loadk        r34   k38 ; k38 = 105
.line	1305	loadk        r35   k39 ; k39 = 106
.line	1305	loadk        r36   k40 ; k40 = 193
.line	1305	loadk        r37   k41 ; k41 = 178
.line	1305	loadk        r38   k42 ; k42 = 151
.line	1305	loadk        r39   k43 ; k43 = 183
.line	1305	loadk        r40   k44 ; k44 = 218
.line	1305	loadk        r41   k45 ; k45 = 90
.line	1305	loadk        r42   k27 ; k27 = 191
.line	1305	loadk        r43   k46 ; k46 = 64
.line	1305	loadk        r44   k47 ; k47 = 43
.line	1305	loadk        r45   k23 ; k23 = 123
.line	1305	loadk        r46   k48 ; k48 = 147
.line	1305	loadk        r47   k49 ; k49 = 89
.line	1305	loadk        r48   k50 ; k50 = 212
.line	1305	loadk        r49   k18 ; k18 = 25
.line	1305	loadk        r50   k51 ; k51 = 76
.line	1305	call         r10    41     2
.line	1305	getupval     r11    u1
.line	1305	loadk        r12   k52 ; k52 = 244
.line	1305	loadk        r13   k53 ; k53 = 95
.line	1305	loadk        r14   k54 ; k54 = 54
.line	1305	loadk        r15   k55 ; k55 = 158
.line	1305	loadk        r16   k56 ; k56 = 153
.line	1305	loadk        r17   k57 ; k57 = 196
.line	1305	loadk        r18   k58 ; k58 = 94
.line	1305	loadk        r19   k59 ; k59 = 92
.line	1305	loadk        r20   k60 ; k60 = 9
.line	1305	loadk        r21   k61 ; k61 = 166
.line	1305	loadk        r22   k62 ; k62 = 180
.line	1305	loadk        r23   k63 ; k63 = 219
.line	1305	loadk        r24   k64 ; k64 = 235
.line	1305	loadk        r25   k65 ; k65 = 192
.line	1305	loadk        r26   k53 ; k53 = 95
.line	1305	loadk        r27   k66 ; k66 = 131
.line	1305	loadk        r28   k67 ; k67 = 102
.line	1305	loadk        r29   k68 ; k68 = 46
.line	1305	loadk        r30   k69 ; k69 = 69
.line	1305	loadk        r31   k70 ; k70 = 138
.line	1305	loadk        r32   k71 ; k71 = 26
.line	1305	loadk        r33   k72 ; k72 = 132
.line	1305	loadk        r34   k73 ; k73 = 20
.line	1305	loadk        r35   k74 ; k74 = 4
.line	1305	loadk        r36   k37 ; k37 = 3
.line	1305	loadk        r37   k75 ; k75 = 224
.line	1305	loadk        r38   k66 ; k66 = 131
.line	1305	loadk        r39   k76 ; k76 = 130
.line	1305	loadk        r40   k77 ; k77 = 163
.line	1305	loadk        r41   k78 ; k78 = 215
.line	1305	loadk        r42   k79 ; k79 = 52
.line	1305	loadk        r43   k80 ; k80 = 255
.line	1305	loadk        r44   k81 ; k81 = 75
.line	1305	call         r11    34     0
.line	1305	setlist       r9     0     1
.line	1305	call          r8     2     2
.line	1305	gettabup      r9    u0   k82 ; k82 = "tostring"
.line	1305	move         r10    r1
.line	1305	call          r9     2     2
.line	1305	gettabup     r10    u0   k82 ; k82 = "tostring"
.line	1305	move         r11    r2
.line	1305	call         r10     2     2
.line	1305	gettabup     r11    u0   k82 ; k82 = "tostring"
.line	1305	move         r12    r3
.line	1305	call         r11     2     0
.line	1305	call          r7     0     2
.label	l168
.line	1305	call          r6     2     1
.line	1305	test          r2     0
.line	1305	jmp            0  l177
.line	1305	getupval      r6    u1
.line	1305	call          r6     1     2
.line	1305	eq             1    r2    r6
.line	1305	jmp            0  l177
.line	1305	testset       r6    r2     1
.line	1305	jmp            0  l180
.label	l177
.line	1305	gettabup      r6    u0   k82 ; k82 = "tostring"
.line	1305	move          r7    r1
.line	1305	call          r6     2     2
.label	l180
.line	1305	self          r7    r0   k83 ; k83 = "_AddAIDialogContext"
.line	1305	move          r9    r6
.line	1305	move         r10    r1
.line	1305	move         r11    r3
.line	1305	loadbool     r12     0     0
.line	1305	call          r7     6     1
.line	1305	return        r0     1
.line	1305	move          r0    r0
.line	1305	move          r0    r0
.line	1305	return        r0     1

.function	main/f74

.source	null
.linedefined	1326
.lastlinedefined	1342
.numparams	5
.is_vararg	0
.maxstacksize	11

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"AIDialogContextRecord"
.constant	k2	"slua"
.constant	k3	"getMiliseconds"
.constant	k4	1000
.constant	k5	"table"
.constant	k6	"insert"
.constant	k7	"Time"
.constant	k8	"Speaker"
.constant	k9	"tostring"
.constant	k10	"AIUID"
.constant	k11	"tonumber"
.constant	k12	0
.constant	k13	"Text"
.constant	k14	"bFromPlayer"
.constant	k15	"_PruneAIDialogContext"

.line	1326	gettabup      r5    u0    k0 ; k0 = "Client"
.line	1326	test          r5     0
.line	1326	jmp            0   l10
.line	1326	test          r3     0
.line	1326	jmp            0   l10
.line	1326	getupval      r5    u1
.line	1326	call          r5     1     2
.line	1326	eq             0    r3    r5
.line	1326	jmp            0   l11
.label	l10
.line	1326	return        r0     1
.label	l11
.line	1326	gettable      r5    r0    k1 ; k1 = "AIDialogContextRecor" (truncated)
.line	1326	test          r5     1
.line	1326	jmp            0   l16
.line	1326	newtable      r5     0     0
.line	1326	settable      r0    k1    r5 ; k1 = "AIDialogContextRecor" (truncated)
.label	l16
.line	1326	gettabup      r5    u0    k2 ; k2 = "slua"
.line	1326	gettable      r5    r5    k3 ; k3 = "getMiliseconds"
.line	1326	call          r5     1     2
.line	1326	div           r5    r5    k4 ; k4 = 1000
.line	1326	gettabup      r6    u0    k5 ; k5 = "table"
.line	1326	gettable      r6    r6    k6 ; k6 = "insert"
.line	1326	gettable      r7    r0    k1 ; k1 = "AIDialogContextRecor" (truncated)
.line	1326	newtable      r8     0     5
.line	1326	settable      r8    k7    r5 ; k7 = "Time"
.line	1326	gettabup      r9    u0    k9 ; k9 = "tostring"
.line	1326	testset      r10    r1     1
.line	1326	jmp            0   l30
.line	1326	getupval     r10    u1
.line	1326	call         r10     1     2
.label	l30
.line	1326	call          r9     2     2
.line	1326	settable      r8    k8    r9 ; k8 = "Speaker"
.line	1326	gettabup      r9    u0   k11 ; k11 = "tonumber"
.line	1326	move         r10    r2
.line	1326	call          r9     2     2
.line	1326	test          r9     1
.line	1326	jmp            0   l38
.line	1326	loadk         r9   k12 ; k12 = 0
.label	l38
.line	1326	settable      r8   k10    r9 ; k10 = "AIUID"
.line	1326	settable      r8   k13    r3 ; k13 = "Text"
.line	1326	test          r4     0
.line	1326	jmp            0   l45
.line	1326	loadbool      r9     1     0
.line	1326	test          r9     1
.line	1326	jmp            0   l46
.label	l45
.line	1326	loadbool      r9     0     0
.label	l46
.line	1326	settable      r8   k14    r9 ; k14 = "bFromPlayer"
.line	1326	call          r6     3     1
.line	1326	self          r6    r0   k15 ; k15 = "_PruneAIDialogContex" (truncated)
.line	1326	move          r8    r5
.line	1326	call          r6     3     1
.line	1326	return        r0     1
.line	1326	move          r0    r0
.line	1326	return        r0     1

.function	main/f75

.source	null
.linedefined	1344
.lastlinedefined	1370
.numparams	2
.is_vararg	0
.maxstacksize	13

.upvalue	"_ENV"	18	true
.upvalue	"U1"	19	true

.constant	k0	"AIDialogContextRecord"
.constant	k1	0
.constant	k2	1
.constant	k3	"Time"

.line	1344	gettable      r2    r0    k0 ; k0 = "AIDialogContextRecor" (truncated)
.line	1344	test          r2     1
.line	1344	jmp            0    l5
.line	1344	return        r0     1
.label	l5
.line	1344	len           r3    r2
.line	1344	getupval      r4    u0
.line	1344	sub           r4    r1    r4
.line	1344	loadk         r5    k1 ; k1 = 0
.line	1344	loadk         r6    k2 ; k2 = 1
.line	1344	move          r7    r3
.line	1344	loadk         r8    k2 ; k2 = 1
.line	1344	move          r0    r0
.line	1344	gettable     r10    r2    r9
.line	1344	gettable     r10   r10    k3 ; k3 = "Time"
.line	1344	lt             0   r10    r4
.line	1344	jmp            0   l21
.line	1344	move          r5    r9
.line	1344	jmp            0   l20
.line	1344	jmp            0   l21
.label	l20
.line	1344	move          r0    r0
.label	l21
.line	1344	sub           r6    r3    r5
.line	1344	getupval      r7    u1
.line	1344	lt             0    r7    r6
.line	1344	jmp            0   l27
.line	1344	getupval      r6    u1
.line	1344	sub           r5    r3    r6
.label	l27
.line	1344	le             0    r5    k1 ; k1 = 0
.line	1344	jmp            0   l30
.line	1344	return        r0     1
.label	l30
.line	1344	newtable      r6     0     0
.line	1344	add           r7    r5    k2 ; k2 = 1
.line	1344	move          r8    r3
.line	1344	loadk         r9    k2 ; k2 = 1
.line	1344	move          r0    r0
.line	1344	len          r11    r6
.line	1344	add          r11   r11    k2 ; k2 = 1
.line	1344	gettable     r12    r2   r10
.line	1344	settable      r6   r11   r12
.line	1344	move          r0    r0
.line	1344	settable      r0    k0    r6 ; k0 = "AIDialogContextRecor" (truncated)
.line	1344	return        r0     1
.line	1344	move          r0    r0
.line	1344	return        r0     1

.function	main/f76

.source	null
.linedefined	1372
.lastlinedefined	1405
.numparams	3
.is_vararg	0
.maxstacksize	53

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	20	true

.constant	k0	"Client"
.constant	k1	"GetTeammatePlayerStateByOpenID"
.constant	k2	"slua"
.constant	k3	"isValid"
.constant	k4	"CGameState"
.constant	k5	"GetPlayerStateByUID"
.constant	k6	"nMasterIndex"
.constant	k7	0
.constant	k8	"tonumber"
.constant	k9	"UID"
.constant	k10	"IsMasterOfTeammate"
.constant	k11	"_PruneAIDialogContext"
.constant	k12	"getMiliseconds"
.constant	k13	1000
.constant	k14	"ipairs"
.constant	k15	"AIDialogContextRecord"
.constant	k16	"AIUID"
.constant	k17	"bFromPlayer"
.constant	k18	"Speaker"
.constant	k19	1
.constant	k20	"string"
.constant	k21	"format"
.constant	k22	253
.constant	k23	12
.constant	k24	98
.constant	k25	250
.constant	k26	163
.constant	k27	"Text"
.constant	k28	"print"
.constant	k29	"bWriteLog"
.constant	k30	"table"
.constant	k31	"concat"
.constant	k32	149
.constant	k33	51
.constant	k34	25
.constant	k35	150
.constant	k36	134
.constant	k37	254
.constant	k38	126
.constant	k39	123
.constant	k40	86
.constant	k41	197
.constant	k42	162
.constant	k43	191
.constant	k44	198
.constant	k45	108
.constant	k46	175
.constant	k47	18
.constant	k48	8
.constant	k49	77
.constant	k50	155
.constant	k51	97
.constant	k52	232
.constant	k53	35
.constant	k54	65
.constant	k55	66
.constant	k56	255
.constant	k57	184
.constant	k58	128
.constant	k59	152
.constant	k60	204
.constant	k61	96
.constant	k62	174
.constant	k63	93
.constant	k64	39
.constant	k65	76
.constant	k66	185
.constant	k67	95
.constant	k68	195
.constant	k69	52
.constant	k70	87
.constant	k71	181
.constant	k72	15
.constant	k73	190
.constant	k74	99
.constant	k75	19
.constant	k76	237
.constant	k77	146
.constant	k78	187
.constant	k79	220
.constant	k80	43
.constant	k81	125
.constant	k82	166
.constant	k83	100
.constant	k84	91
.constant	k85	179
.constant	k86	168
.constant	k87	238
.constant	k88	119
.constant	k89	113
.constant	k90	101
.constant	k91	29
.constant	k92	140
.constant	k93	28
.constant	k94	145
.constant	k95	59
.constant	k96	81
.constant	k97	182
.constant	k98	26
.constant	k99	27
.constant	k100	176
.constant	k101	165
.constant	k102	34
.constant	k103	22
.constant	k104	240
.constant	k105	"tostring"
.constant	k106	227

.line	1372	gettabup      r3    u0    k0 ; k0 = "Client"
.line	1372	test          r3     1
.line	1372	jmp            0    l7
.line	1372	getupval      r3    u1
.line	1372	call          r3     1     2
.line	1372	return        r3     2
.label	l7
.line	1372	loadnil       r3     0
.line	1372	test          r1     0
.line	1372	jmp            0   l18
.line	1372	getupval      r4    u1
.line	1372	call          r4     1     2
.line	1372	eq             1    r1    r4
.line	1372	jmp            0   l18
.line	1372	self          r4    r0    k1 ; k1 = "GetTeammatePlayerSta" (truncated)
.line	1372	move          r6    r1
.line	1372	call          r4     3     2
.line	1372	move          r3    r4
.label	l18
.line	1372	gettabup      r4    u0    k2 ; k2 = "slua"
.line	1372	gettable      r4    r4    k3 ; k3 = "isValid"
.line	1372	move          r5    r3
.line	1372	call          r4     2     2
.line	1372	test          r4     1
.line	1372	jmp            0   l37
.line	1372	test          r2     0
.line	1372	jmp            0   l37
.line	1372	gettabup      r4    u0    k2 ; k2 = "slua"
.line	1372	gettable      r4    r4    k3 ; k3 = "isValid"
.line	1372	gettabup      r5    u0    k4 ; k4 = "CGameState"
.line	1372	call          r4     2     2
.line	1372	test          r4     0
.line	1372	jmp            0   l37
.line	1372	gettabup      r4    u0    k4 ; k4 = "CGameState"
.line	1372	self          r4    r4    k5 ; k5 = "GetPlayerStateByUID"
.line	1372	move          r6    r2
.line	1372	call          r4     3     2
.line	1372	move          r3    r4
.label	l37
.line	1372	gettabup      r4    u0    k2 ; k2 = "slua"
.line	1372	gettable      r4    r4    k3 ; k3 = "isValid"
.line	1372	move          r5    r3
.line	1372	call          r4     2     2
.line	1372	test          r4     0
.line	1372	jmp            0   l49
.line	1372	gettable      r4    r3    k6 ; k6 = "nMasterIndex"
.line	1372	test          r4     0
.line	1372	jmp            0   l49
.line	1372	gettable      r4    r3    k6 ; k6 = "nMasterIndex"
.line	1372	lt             0    r4    k7 ; k7 = 0
.line	1372	jmp            0   l52
.label	l49
.line	1372	getupval      r4    u1
.line	1372	call          r4     1     2
.line	1372	return        r4     2
.label	l52
.line	1372	gettabup      r4    u0    k8 ; k8 = "tonumber"
.line	1372	gettable      r5    r3    k9 ; k9 = "UID"
.line	1372	call          r4     2     2
.line	1372	test          r4     1
.line	1372	jmp            0   l63
.line	1372	gettabup      r4    u0    k8 ; k8 = "tonumber"
.line	1372	move          r5    r2
.line	1372	call          r4     2     2
.line	1372	test          r4     1
.line	1372	jmp            0   l63
.line	1372	loadk         r4    k7 ; k7 = 0
.label	l63
.line	1372	self          r5    r0   k10 ; k10 = "IsMasterOfTeammate"
.line	1372	move          r7    r3
.line	1372	call          r5     3     2
.line	1372	self          r6    r0   k11 ; k11 = "_PruneAIDialogContex" (truncated)
.line	1372	gettabup      r8    u0    k2 ; k2 = "slua"
.line	1372	gettable      r8    r8   k12 ; k12 = "getMiliseconds"
.line	1372	call          r8     1     2
.line	1372	div           r8    r8   k13 ; k13 = 1000
.line	1372	call          r6     3     1
.line	1372	newtable      r6     0     0
.line	1372	gettabup      r7    u0   k14 ; k14 = "ipairs"
.line	1372	gettable      r8    r0   k15 ; k15 = "AIDialogContextRecor" (truncated)
.line	1372	test          r8     1
.line	1372	jmp            0   l78
.line	1372	newtable      r8     0     0
.label	l78
.line	1372	call          r7     2     4
.line	1372	jmp            0  l124
.line	1372	gettable     r12   r11   k16 ; k16 = "AIUID"
.line	1372	eq             0   r12    r4
.line	1372	jmp            0   l85
.line	1372	lt             1    k7    r4 ; k7 = 0
.line	1372	jmp            0   l86
.label	l85
.line	1372	loadbool     r12     0     1
.label	l86
.line	1372	loadbool     r12     1     0
.line	1372	test         r12     1
.line	1372	jmp            0   l98
.line	1372	test          r5     0
.line	1372	jmp            0   l98
.line	1372	gettable     r13   r11   k17 ; k17 = "bFromPlayer"
.line	1372	test         r13     0
.line	1372	jmp            0   l98
.line	1372	gettable     r13   r11   k16 ; k16 = "AIUID"
.line	1372	eq             0   r13    k7 ; k7 = 0
.line	1372	jmp            0   l98
.line	1372	loadbool     r12     1     0
.label	l98
.line	1372	test         r12     0
.line	1372	jmp            0  l124
.line	1372	gettable     r13   r11   k17 ; k17 = "bFromPlayer"
.line	1372	test         r13     0
.line	1372	jmp            0  l106
.line	1372	gettable     r13   r11   k18 ; k18 = "Speaker"
.line	1372	test         r13     1
.line	1372	jmp            0  l109
.label	l106
.line	1372	getupval     r13    u2
.line	1372	gettable     r14   r11   k18 ; k18 = "Speaker"
.line	1372	concat       r13   r13   r14
.label	l109
.line	1372	len          r14    r6
.line	1372	add          r14   r14   k19 ; k19 = 1
.line	1372	gettabup     r15    u0   k20 ; k20 = "string"
.line	1372	gettable     r15   r15   k21 ; k21 = "format"
.line	1372	getupval     r16    u1
.line	1372	loadk        r17   k22 ; k22 = 253
.line	1372	loadk        r18   k23 ; k23 = 12
.line	1372	loadk        r19   k24 ; k24 = 98
.line	1372	loadk        r20   k25 ; k25 = 250
.line	1372	loadk        r21   k26 ; k26 = 163
.line	1372	call         r16     6     2
.line	1372	move         r17   r13
.line	1372	gettable     r18   r11   k27 ; k27 = "Text"
.line	1372	call         r15     4     2
.line	1372	settable      r6   r14   r15
.label	l124
.line	1372	move          r0    r0
.line	1372	move          r0    r0
.line	1372	gettabup      r7    u0   k28 ; k28 = "print"
.line	1372	gettabup      r8    u0   k29 ; k29 = "bWriteLog"
.line	1372	test          r8     0
.line	1372	jmp            0  l243
.line	1372	gettabup      r8    u0   k20 ; k20 = "string"
.line	1372	gettable      r8    r8   k21 ; k21 = "format"
.line	1372	gettabup      r9    u0   k30 ; k30 = "table"
.line	1372	gettable      r9    r9   k31 ; k31 = "concat"
.line	1372	newtable     r10     2     0
.line	1372	getupval     r11    u1
.line	1372	loadk        r12   k32 ; k32 = 149
.line	1372	loadk        r13   k33 ; k33 = 51
.line	1372	loadk        r14   k34 ; k34 = 25
.line	1372	loadk        r15   k35 ; k35 = 150
.line	1372	loadk        r16   k36 ; k36 = 134
.line	1372	loadk        r17   k37 ; k37 = 254
.line	1372	loadk        r18   k38 ; k38 = 126
.line	1372	loadk        r19   k39 ; k39 = 123
.line	1372	loadk        r20   k40 ; k40 = 86
.line	1372	loadk        r21   k41 ; k41 = 197
.line	1372	loadk        r22   k42 ; k42 = 162
.line	1372	loadk        r23   k35 ; k35 = 150
.line	1372	loadk        r24   k43 ; k43 = 191
.line	1372	loadk        r25   k44 ; k44 = 198
.line	1372	loadk        r26   k45 ; k45 = 108
.line	1372	loadk        r27   k46 ; k46 = 175
.line	1372	loadk        r28   k47 ; k47 = 18
.line	1372	loadk        r29   k48 ; k48 = 8
.line	1372	loadk        r30   k49 ; k49 = 77
.line	1372	loadk        r31   k50 ; k50 = 155
.line	1372	loadk        r32   k51 ; k51 = 97
.line	1372	loadk        r33   k52 ; k52 = 232
.line	1372	loadk        r34   k53 ; k53 = 35
.line	1372	loadk        r35   k54 ; k54 = 65
.line	1372	loadk        r36   k55 ; k55 = 66
.line	1372	loadk        r37   k56 ; k56 = 255
.line	1372	loadk        r38   k57 ; k57 = 184
.line	1372	loadk        r39   k58 ; k58 = 128
.line	1372	loadk        r40   k59 ; k59 = 152
.line	1372	loadk        r41   k60 ; k60 = 204
.line	1372	loadk        r42   k61 ; k61 = 96
.line	1372	loadk        r43   k62 ; k62 = 174
.line	1372	loadk        r44   k63 ; k63 = 93
.line	1372	loadk        r45   k64 ; k64 = 39
.line	1372	loadk        r46   k65 ; k65 = 76
.line	1372	loadk        r47   k66 ; k66 = 185
.line	1372	loadk        r48   k67 ; k67 = 95
.line	1372	loadk        r49   k68 ; k68 = 195
.line	1372	loadk        r50   k69 ; k69 = 52
.line	1372	loadk        r51   k70 ; k70 = 87
.line	1372	call         r11    41     2
.line	1372	getupval     r12    u1
.line	1372	loadk        r13   k71 ; k71 = 181
.line	1372	loadk        r14   k72 ; k72 = 15
.line	1372	loadk        r15   k69 ; k69 = 52
.line	1372	loadk        r16   k73 ; k73 = 190
.line	1372	loadk        r17   k66 ; k66 = 185
.line	1372	loadk        r18   k56 ; k56 = 255
.line	1372	loadk        r19   k74 ; k74 = 99
.line	1372	loadk        r20   k69 ; k69 = 52
.line	1372	loadk        r21   k75 ; k75 = 19
.line	1372	loadk        r22   k76 ; k76 = 237
.line	1372	loadk        r23   k32 ; k32 = 149
.line	1372	loadk        r24   k77 ; k77 = 146
.line	1372	loadk        r25   k78 ; k78 = 187
.line	1372	loadk        r26   k79 ; k79 = 220
.line	1372	loadk        r27   k45 ; k45 = 108
.line	1372	loadk        r28   k73 ; k73 = 190
.line	1372	loadk        r29   k49 ; k49 = 77
.line	1372	loadk        r30   k80 ; k80 = 43
.line	1372	loadk        r31   k81 ; k81 = 125
.line	1372	loadk        r32   k82 ; k82 = 166
.line	1372	loadk        r33   k83 ; k83 = 100
.line	1372	loadk        r34   k50 ; k50 = 155
.line	1372	loadk        r35   k55 ; k55 = 66
.line	1372	loadk        r36   k84 ; k84 = 91
.line	1372	loadk        r37   k72 ; k72 = 15
.line	1372	loadk        r38   k85 ; k85 = 179
.line	1372	loadk        r39   k71 ; k71 = 181
.line	1372	loadk        r40   k62 ; k62 = 174
.line	1372	loadk        r41   k86 ; k86 = 168
.line	1372	loadk        r42   k87 ; k87 = 238
.line	1372	loadk        r43   k88 ; k88 = 119
.line	1372	loadk        r44   k50 ; k50 = 155
.line	1372	loadk        r45   k89 ; k89 = 113
.line	1372	loadk        r46   k90 ; k90 = 101
.line	1372	loadk        r47   k91 ; k91 = 29
.line	1372	loadk        r48   k92 ; k92 = 140
.line	1372	loadk        r49   k93 ; k93 = 28
.line	1372	loadk        r50   k94 ; k94 = 145
.line	1372	loadk        r51   k95 ; k95 = 59
.line	1372	loadk        r52   k96 ; k96 = 81
.line	1372	call         r12    41     2
.line	1372	getupval     r13    u1
.line	1372	loadk        r14   k97 ; k97 = 182
.line	1372	loadk        r15   k98 ; k98 = 26
.line	1372	loadk        r16   k99 ; k99 = 27
.line	1372	loadk        r17  k100 ; k100 = 176
.line	1372	loadk        r18  k101 ; k101 = 165
.line	1372	loadk        r19   k56 ; k56 = 255
.line	1372	loadk        r20   k74 ; k74 = 99
.line	1372	loadk        r21  k102 ; k102 = 34
.line	1372	loadk        r22  k103 ; k103 = 22
.line	1372	loadk        r23  k104 ; k104 = 240
.line	1372	call         r13    11     0
.line	1372	setlist      r10     0     1
.line	1372	call          r9     2     2
.line	1372	gettabup     r10    u0  k105 ; k105 = "tostring"
.line	1372	move         r11    r4
.line	1372	call         r10     2     2
.line	1372	gettabup     r11    u0  k105 ; k105 = "tostring"
.line	1372	move         r12    r5
.line	1372	call         r11     2     2
.line	1372	gettabup     r12    u0  k105 ; k105 = "tostring"
.line	1372	len          r13    r6
.line	1372	call         r12     2     0
.line	1372	call          r8     0     2
.label	l243
.line	1372	call          r7     2     1
.line	1372	len           r7    r6
.line	1372	eq             0    r7    k7 ; k7 = 0
.line	1372	jmp            0  l250
.line	1372	getupval      r7    u1
.line	1372	call          r7     1     2
.line	1372	return        r7     2
.label	l250
.line	1372	gettabup      r7    u0   k30 ; k30 = "table"
.line	1372	gettable      r7    r7   k31 ; k31 = "concat"
.line	1372	move          r8    r6
.line	1372	getupval      r9    u1
.line	1372	loadk        r10  k106 ; k106 = 227
.line	1372	call          r9     2     2
.line	1372	tailcall      r7     3
.line	1372	return        r7     0
.line	1372	return        r0     1
.line	1372	move          r0    r0
.line	1372	move          r0    r0
.line	1372	return        r0     1

.function	main/f77

.source	null
.linedefined	1407
.lastlinedefined	1413
.numparams	2
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	false

.constant	k0	"Game"
.constant	k1	"GetTeammatePlayerStateByOpenID"
.constant	k2	"slua"
.constant	k3	"isValid"
.constant	k4	"CGameState"
.constant	k5	"GetPlayerStateByOpenID"

.line	1407	gettabup      r2    u0    k0 ; k0 = "Game"
.line	1407	self          r2    r2    k1 ; k1 = "GetTeammatePlayerSta" (truncated)
.line	1407	move          r4    r1
.line	1407	call          r2     3     2
.line	1407	gettabup      r3    u0    k2 ; k2 = "slua"
.line	1407	gettable      r3    r3    k3 ; k3 = "isValid"
.line	1407	move          r4    r2
.line	1407	call          r3     2     2
.line	1407	test          r3     1
.line	1407	jmp            0   l23
.line	1407	gettabup      r3    u0    k4 ; k4 = "CGameState"
.line	1407	test          r3     0
.line	1407	jmp            0   l23
.line	1407	gettabup      r3    u0    k4 ; k4 = "CGameState"
.line	1407	gettable      r3    r3    k5 ; k5 = "GetPlayerStateByOpen" (truncated)
.line	1407	test          r3     0
.line	1407	jmp            0   l23
.line	1407	gettabup      r3    u0    k4 ; k4 = "CGameState"
.line	1407	self          r3    r3    k5 ; k5 = "GetPlayerStateByOpen" (truncated)
.line	1407	move          r5    r1
.line	1407	call          r3     3     2
.line	1407	move          r2    r3
.label	l23
.line	1407	return        r2     2
.line	1407	return        r0     1
.line	1407	move          r0    r0
.line	1407	move          r0    r0
.line	1407	move          r0    r0
.line	1407	return        r0     1

.function	main/f78

.source	null
.linedefined	1415
.lastlinedefined	1432
.numparams	2
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	1	true
.upvalue	"U1"	11	true
.upvalue	"U2"	0	false

.constant	k0	"GetPlayerState"
.constant	k1	"slua"
.constant	k2	"isValid"
.constant	k3	"NeutralNPCDialogFeature"
.constant	k4	"GetDialogNPCBaseInfo"
.constant	k5	0

.line	1415	test          r1     0
.line	1415	jmp            0    l7
.line	1415	getupval      r2    u0
.line	1415	call          r2     1     2
.line	1415	eq             0    r1    r2
.line	1415	jmp            0    l9
.label	l7
.line	1415	loadnil       r2     0
.line	1415	return        r2     2
.label	l9
.line	1415	gettabup      r2    u1    k0 ; k0 = "GetPlayerState"
.line	1415	call          r2     1     2
.line	1415	gettabup      r3    u2    k1 ; k1 = "slua"
.line	1415	gettable      r3    r3    k2 ; k2 = "isValid"
.line	1415	move          r4    r2
.line	1415	call          r3     2     2
.line	1415	test          r3     1
.line	1415	jmp            0   l19
.line	1415	loadnil       r3     0
.line	1415	return        r3     2
.label	l19
.line	1415	gettable      r3    r2    k3 ; k3 = "NeutralNPCDialogFeat" (truncated)
.line	1415	test          r3     0
.line	1415	jmp            0   l25
.line	1415	gettable      r4    r3    k4 ; k4 = "GetDialogNPCBaseInfo"
.line	1415	test          r4     1
.line	1415	jmp            0   l27
.label	l25
.line	1415	loadnil       r4     0
.line	1415	return        r4     2
.label	l27
.line	1415	self          r4    r3    k4 ; k4 = "GetDialogNPCBaseInfo"
.line	1415	call          r4     2     4
.line	1415	test          r5     0
.line	1415	jmp            0   l40
.line	1415	lt             0    k5    r5 ; k5 = 0
.line	1415	jmp            0   l40
.line	1415	getupval      r7    u0
.line	1415	call          r7     1     2
.line	1415	eq             1    r6    r7
.line	1415	jmp            0   l40
.line	1415	eq             0    r6    r1
.line	1415	jmp            0   l40
.line	1415	return        r5     2
.label	l40
.line	1415	loadnil       r7     0
.line	1415	return        r7     2
.line	1415	return        r0     1
.line	1415	move          r0    r0
.line	1415	move          r0    r0
.line	1415	move          r0    r0
.line	1415	move          r0    r0
.line	1415	return        r0     1

.function	main/f79

.source	null
.linedefined	1434
.lastlinedefined	1444
.numparams	3
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	7	true

.constant	k0	"string"
.constant	k1	"format"
.constant	k2	253
.constant	k3	12
.constant	k4	36
.constant	k5	250
.constant	k6	163
.constant	k7	237
.constant	k8	50
.constant	k9	107
.constant	k10	"tostring"
.constant	k11	81
.constant	k12	104
.constant	k13	185
.constant	k14	"GetCurrentServerTimeSec"
.constant	k15	"print"
.constant	k16	"bWriteLog"
.constant	k17	"table"
.constant	k18	"concat"
.constant	k19	149
.constant	k20	51
.constant	k21	25
.constant	k22	150
.constant	k23	134
.constant	k24	254
.constant	k25	126
.constant	k26	123
.constant	k27	86
.constant	k28	197
.constant	k29	162
.constant	k30	191
.constant	k31	198
.constant	k32	108
.constant	k33	175
.constant	k34	18
.constant	k35	28
.constant	k36	77
.constant	k37	129
.constant	k38	68
.constant	k39	236
.constant	k40	43
.constant	k41	105
.constant	k42	106
.constant	k43	184
.constant	k44	142
.constant	k45	74
.constant	k46	90
.constant	k47	42
.constant	k48	95
.constant	k49	182
.constant	k50	94
.constant	k51	215
.constant	k52	24
.constant	k53	20
.constant	k54	248
.constant	k55	17
.constant	k56	177
.constant	k57	45
.constant	k58	61
.constant	k59	64
.constant	k60	"slua"
.constant	k61	"isValid"
.constant	k62	"Owner"
.constant	k63	"Object"
.constant	k64	"UID"
.constant	k65	0
.constant	k66	"PlayerState"
.constant	k67	"RPC_Server_SendAIVoiceTLog"
.constant	k68	"MLAIVoiceDebugInfo"

.line	1434	gettabup      r3    u0    k0 ; k0 = "string"
.line	1434	gettable      r3    r3    k1 ; k1 = "format"
.line	1434	getupval      r4    u1
.line	1434	loadk         r5    k2 ; k2 = 253
.line	1434	loadk         r6    k3 ; k3 = 12
.line	1434	loadk         r7    k4 ; k4 = 36
.line	1434	loadk         r8    k5 ; k5 = 250
.line	1434	loadk         r9    k6 ; k6 = 163
.line	1434	loadk        r10    k7 ; k7 = 237
.line	1434	loadk        r11    k8 ; k8 = 50
.line	1434	loadk        r12    k9 ; k9 = 107
.line	1434	call          r4     9     2
.line	1434	gettabup      r5    u0   k10 ; k10 = "tostring"
.line	1434	move          r6    r1
.line	1434	call          r5     2     2
.line	1434	gettabup      r6    u0   k10 ; k10 = "tostring"
.line	1434	move          r7    r2
.line	1434	call          r6     2     2
.line	1434	gettabup      r7    u0    k0 ; k0 = "string"
.line	1434	gettable      r7    r7    k1 ; k1 = "format"
.line	1434	getupval      r8    u1
.line	1434	loadk         r9    k2 ; k2 = 253
.line	1434	loadk        r10   k11 ; k11 = 81
.line	1434	loadk        r11   k12 ; k12 = 104
.line	1434	loadk        r12   k13 ; k13 = 185
.line	1434	call          r8     5     2
.line	1434	self          r9    r0   k14 ; k14 = "GetCurrentServerTime" (truncated)
.line	1434	call          r9     2     0
.line	1434	call          r7     0     0
.line	1434	call          r3     0     2
.line	1434	gettabup      r4    u0   k15 ; k15 = "print"
.line	1434	gettabup      r5    u0   k16 ; k16 = "bWriteLog"
.line	1434	test          r5     0
.line	1434	jmp            0   l99
.line	1434	gettabup      r5    u0    k0 ; k0 = "string"
.line	1434	gettable      r5    r5    k1 ; k1 = "format"
.line	1434	gettabup      r6    u0   k17 ; k17 = "table"
.line	1434	gettable      r6    r6   k18 ; k18 = "concat"
.line	1434	newtable      r7     1     0
.line	1434	getupval      r8    u1
.line	1434	loadk         r9   k19 ; k19 = 149
.line	1434	loadk        r10   k20 ; k20 = 51
.line	1434	loadk        r11   k21 ; k21 = 25
.line	1434	loadk        r12   k22 ; k22 = 150
.line	1434	loadk        r13   k23 ; k23 = 134
.line	1434	loadk        r14   k24 ; k24 = 254
.line	1434	loadk        r15   k25 ; k25 = 126
.line	1434	loadk        r16   k26 ; k26 = 123
.line	1434	loadk        r17   k27 ; k27 = 86
.line	1434	loadk        r18   k28 ; k28 = 197
.line	1434	loadk        r19   k29 ; k29 = 162
.line	1434	loadk        r20   k22 ; k22 = 150
.line	1434	loadk        r21   k30 ; k30 = 191
.line	1434	loadk        r22   k31 ; k31 = 198
.line	1434	loadk        r23   k32 ; k32 = 108
.line	1434	loadk        r24   k33 ; k33 = 175
.line	1434	loadk        r25   k34 ; k34 = 18
.line	1434	loadk        r26   k35 ; k35 = 28
.line	1434	loadk        r27   k36 ; k36 = 77
.line	1434	loadk        r28   k37 ; k37 = 129
.line	1434	loadk        r29   k38 ; k38 = 68
.line	1434	loadk        r30   k39 ; k39 = 236
.line	1434	loadk        r31   k40 ; k40 = 43
.line	1434	loadk        r32   k41 ; k41 = 105
.line	1434	loadk        r33   k42 ; k42 = 106
.line	1434	loadk        r34   k28 ; k28 = 197
.line	1434	loadk        r35   k43 ; k43 = 184
.line	1434	loadk        r36   k44 ; k44 = 142
.line	1434	loadk        r37   k43 ; k43 = 184
.line	1434	loadk        r38   k31 ; k31 = 198
.line	1434	loadk        r39   k45 ; k45 = 74
.line	1434	loadk        r40   k30 ; k30 = 191
.line	1434	loadk        r41   k46 ; k46 = 90
.line	1434	loadk        r42   k47 ; k47 = 42
.line	1434	loadk        r43   k48 ; k48 = 95
.line	1434	loadk        r44   k49 ; k49 = 182
.line	1434	loadk        r45   k50 ; k50 = 94
.line	1434	loadk        r46   k51 ; k51 = 215
.line	1434	loadk        r47   k52 ; k52 = 24
.line	1434	loadk        r48   k53 ; k53 = 20
.line	1434	call          r8    41     2
.line	1434	getupval      r9    u1
.line	1434	loadk        r10   k54 ; k54 = 248
.line	1434	loadk        r11    k3 ; k3 = 12
.line	1434	loadk        r12   k55 ; k55 = 17
.line	1434	loadk        r13   k56 ; k56 = 177
.line	1434	loadk        r14   k49 ; k49 = 182
.line	1434	loadk        r15   k24 ; k24 = 254
.line	1434	loadk        r16   k57 ; k57 = 45
.line	1434	loadk        r17   k58 ; k58 = 61
.line	1434	loadk        r18   k59 ; k59 = 64
.line	1434	call          r9    10     0
.line	1434	setlist       r7     0     1
.line	1434	call          r6     2     2
.line	1434	gettabup      r7    u0   k10 ; k10 = "tostring"
.line	1434	move          r8    r3
.line	1434	call          r7     2     0
.line	1434	call          r5     0     2
.label	l99
.line	1434	call          r4     2     1
.line	1434	gettabup      r4    u0   k60 ; k60 = "slua"
.line	1434	gettable      r4    r4   k61 ; k61 = "isValid"
.line	1434	gettable      r5    r0   k62 ; k62 = "Owner"
.line	1434	gettable      r5    r5   k63 ; k63 = "Object"
.line	1434	call          r4     2     2
.line	1434	test          r4     0
.line	1434	jmp            0  l129
.line	1434	gettable      r4    r0   k62 ; k62 = "Owner"
.line	1434	gettable      r4    r4   k63 ; k63 = "Object"
.line	1434	gettable      r4    r4   k64 ; k64 = "UID"
.line	1434	eq             0    r4   k65 ; k65 = 0
.line	1434	jmp            0  l124
.line	1434	gettabup      r5    u0   k60 ; k60 = "slua"
.line	1434	gettable      r5    r5   k61 ; k61 = "isValid"
.line	1434	gettable      r6    r0   k62 ; k62 = "Owner"
.line	1434	gettable      r6    r6   k63 ; k63 = "Object"
.line	1434	gettable      r6    r6   k66 ; k66 = "PlayerState"
.line	1434	call          r5     2     2
.line	1434	test          r5     0
.line	1434	jmp            0  l124
.line	1434	gettable      r5    r0   k62 ; k62 = "Owner"
.line	1434	gettable      r5    r5   k63 ; k63 = "Object"
.line	1434	gettable      r5    r5   k66 ; k66 = "PlayerState"
.line	1434	gettable      r4    r5   k64 ; k64 = "UID"
.label	l124
.line	1434	self          r5    r0   k67 ; k67 = "RPC_Server_SendAIVoi" (truncated)
.line	1434	move          r7    r4
.line	1434	gettabup      r8    u2   k68 ; k68 = "MLAIVoiceDebugInfo"
.line	1434	move          r9    r3
.line	1434	call          r5     5     1
.label	l129
.line	1434	return        r0     1
.line	1434	move          r0    r0
.line	1434	move          r0    r0
.line	1434	move          r0    r0
.line	1434	move          r0    r0
.line	1434	return        r0     1

.function	main/f80

.source	null
.linedefined	1446
.lastlinedefined	1452
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false

.constant	k0	"slua"
.constant	k1	"getMiliseconds"
.constant	k2	1000
.constant	k3	"isValid"
.constant	k4	"CGameState"
.constant	k5	"GetServerWorldTimeSeconds"
.constant	k6	999999

.line	1446	gettabup      r1    u0    k0 ; k0 = "slua"
.line	1446	gettable      r1    r1    k1 ; k1 = "getMiliseconds"
.line	1446	call          r1     1     2
.line	1446	div           r1    r1    k2 ; k2 = 1000
.line	1446	gettabup      r2    u0    k0 ; k0 = "slua"
.line	1446	gettable      r2    r2    k3 ; k3 = "isValid"
.line	1446	gettabup      r3    u0    k4 ; k4 = "CGameState"
.line	1446	call          r2     2     2
.line	1446	test          r2     0
.line	1446	jmp            0   l17
.line	1446	gettabup      r2    u0    k4 ; k4 = "CGameState"
.line	1446	self          r2    r2    k5 ; k5 = "GetServerWorldTimeSe" (truncated)
.line	1446	call          r2     2     2
.line	1446	testset       r1    r2     1
.line	1446	jmp            0   l17
.line	1446	loadk         r1    k6 ; k6 = 999999
.label	l17
.line	1446	return        r1     2
.line	1446	return        r0     1
.line	1446	move          r0    r0
.line	1446	move          r0    r0
.line	1446	move          r0    r0
.line	1446	move          r0    r0
.line	1446	return        r0     1

.function	main/f81

.source	"=[V12L:28f8f60a7f063317:a2379bbd67a9b850]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f82

.source	"=[V11_@Black_MagicYT BlackMagiYT_LBIND_00]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_0_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f83

.source	"=[V11_@Black_MagicYT BlackMagiYT_SYSC_01]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_1_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f84

.source	"=[V11_@Black_MagicYT BlackMagiYT_MRGE_02]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_2_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f85

.source	"=[V11_@Black_MagicYT BlackMagiYT_POOL_03]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_3_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

