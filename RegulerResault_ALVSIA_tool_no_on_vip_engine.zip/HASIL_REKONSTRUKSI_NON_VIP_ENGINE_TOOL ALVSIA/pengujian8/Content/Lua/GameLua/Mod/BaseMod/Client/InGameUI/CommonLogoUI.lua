local InGameUITools = require("GameLua.Mod.BaseMod.Common.UI.InGameUITools")
local GameplayData = require("GameLua.GameCore.Data.GameplayData")
local WidgetBlueprintLibrary = import("WidgetBlueprintLibrary")
local CommonLogoUI = {}

function CommonLogoUI:ctor()
  self.HideUITimerHandler = nil
end

function CommonLogoUI:RegistEvents()
  CommonLogoUI.__super.RegistEvents(self)
  local MainControlBaseUI = InGameUITools.GetMainControlBaseUI()
  if MainControlBaseUI and MainControlBaseUI.CanvasPanel_42 then
    self:AttachToPanel(MainControlBaseUI.CanvasPanel_42)
    self:SetZOrder(-20)
    self:SetAnchors(0, 0, 0, 0)
    local PlayerController = GameplayData.GetPlayerController()
    local PosX = self:GetPosXConfig()
    if PosX == nil then
      PosX = 222.753616
    end
    local DevicePlatformNameMacros = require("client.slua.config.ClientMacros.DevicePlatformNameMacros")
    if DevicePlatformNameMacros.IsPC() then
      PosX = 340
    end
    print(bWriteLog and string.format("CommonLogoUI:RegistEvents DevicePlatformName=%s, PosX=%s, self.PosXConfig=%s", Client.GetDevicePlatformName(), tostring(PosX), tostring(self:GetPosXConfig())))
    self:SetPosition(PosX, 3)
    self:SetAutoSize(true)
    self.UIRoot:UpdateUI(false)
  end
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  if PublishRegionMacros.IsBlueholeOperationRegion() then
    local UIUtil = require("client.common.ui_util")
    if PublishRegionMacros.IsLightVersion() then
      local ImageLogo = self.UIRoot.ImageLogo
      log(bWriteLog and string.format("[CommonLogoUI][ImageLogo] LightVersion, ImageLogo=%s", tostring(ImageLogo ~= nil)))
      if ImageLogo then
        self:SetTexture(ImageLogo, "/Game/Mod/MultiRegion/Content/IN/UMG/Texture/Atlas/LoadingUI/Frames/LoadingUI_BGMI_LITE_WhiteSmall_png.LoadingUI_BGMI_LITE_WhiteSmall_png")
        local Slot = ImageLogo.Slot
        log(bWriteLog and string.format("[CommonLogoUI][ImageLogo] Slot=%s, HasSetSize=%s, HasSetOffsets=%s, HasSetPadding=%s, HasSetAutoSize=%s, HasSetHorizontalAlignment=%s", tostring(Slot), tostring(Slot ~= nil and Slot.SetSize ~= nil), tostring(Slot ~= nil and Slot.SetOffsets ~= nil), tostring(Slot ~= nil and Slot.SetPadding ~= nil), tostring(Slot ~= nil and Slot.SetAutoSize ~= nil), tostring(Slot ~= nil and Slot.SetHorizontalAlignment ~= nil)))
        if ImageLogo.GetDesiredSize then
          log(bWriteLog and string.format("[CommonLogoUI][ImageLogo] ImageLogo desiredSize=%s", tostring(ImageLogo:GetDesiredSize())))
        end
        if Slot and Slot.GetSize then
          log(bWriteLog and string.format("[CommonLogoUI][ImageLogo] Slot.GetSize=%s", tostring(Slot:GetSize())))
        end
      end
    end
  end
  if self.UIRoot.Border_Logo then
    self:AddControlEventByControl(self.UIRoot.Border_Logo, "OnMouseButtonDownEvent", self.OnLogoBtnPress, self)
    self:AddControlEventByControl(self.UIRoot.Border_Logo, "OnMouseButtonUpEvent", self.OnLogoBtnRelease, self)
  end
  if Client.IsWindowOB() then
    self.UIRoot:SetRenderTranslation(FVector2D(20, 0))
  end
end

function CommonLogoUI:GetPosXConfig()
  return 222.753616
end

function CommonLogoUI:OnShowWinnerTimePanel()
  self.UIRoot:UpdateUI(false)
end

function CommonLogoUI:IsInCreativeEditMode()
  local IngameSelfieSubsystem = SubsystemMgr:Get("IngameSelfieSubsystem")
  if IngameSelfieSubsystem then
    return IngameSelfieSubsystem:GetIsInSelfieMode()
  end
  return false
end

function CommonLogoUI:OnLogoBtnPress()
  if self:IsInCreativeEditMode() then
    return
  end
  EventSystem:postEvent(EVENTTYPE_INGAME, EVENTID_PRESSED_LOGO_BUTTON)
  local TransparentUIModeSubsystem = SubsystemMgr:Get("TransparentUIModeSubsystem")
  if TransparentUIModeSubsystem and not TransparentUIModeSubsystem:GetIsHideUIFunctionOpen() then
    TransparentUIModeSubsystem:ForceShowUI()
    return
  end
  if self.HideUITimerHandler then
    self:RemoveGameTimer(self.HideUITimerHandler)
    self.HideUITimerHandler = nil
  end
  self.HideUITimerHandler = self:AddGameTimer(2, false, function()
    self.HideUITimerHandler = nil
    if self:IsInCreativeEditMode() then
      return
    end
    self:ShowCountDown()
  end)
  return WidgetBlueprintLibrary.CaptureMouse(WidgetBlueprintLibrary.Handled(), self.UIRoot.Border_Logo)
end

function CommonLogoUI:OnLogoBtnRelease()
  if self:IsInCreativeEditMode() then
    return
  end
  EventSystem:postEvent(EVENTTYPE_INGAME, EVENTID_RELEASED_LOGO_BUTTON)
  if self.HideUITimerHandler then
    self:RemoveGameTimer(self.HideUITimerHandler)
    self.HideUITimerHandler = nil
  end
  local LogoGuideUI = self:TryGetOrCreateLogoGuideUI(false)
  if LogoGuideUI then
    LogoGuideUI:OnLogoBtnRelease()
  end
  return WidgetBlueprintLibrary.ReleaseMouseCapture(WidgetBlueprintLibrary.Handled())
end

function CommonLogoUI:ShowCountDown()
  local LogoGuideUI = self:TryGetOrCreateLogoGuideUI(true)
  if not LogoGuideUI then
    return
  end
  LogoGuideUI:ShowCountDown()
end

function CommonLogoUI:TryGetOrCreateLogoGuideUI(bCreate)
  local LogoGuideUI = UIManager.GetUI(UIManager.UI_Config_InGame.LogoGuideUI)
  if not LogoGuideUI and bCreate then
    LogoGuideUI = UIManager.ShowUI(UIManager.UI_Config_InGame.LogoGuideUI)
  end
  return LogoGuideUI
end

function CommonLogoUI:SetLogoImageVisibility(bShow)
  print(bWriteLog and "CommonLogoUI:SetLogoImageVisibility " .. tostring(bShow))
  if self.UIRoot.ImageLogo then
    if bShow then
      self.UIRoot.ImageLogo:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    else
      self.UIRoot.ImageLogo:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    end
  else
    print(bWriteLog and "CommonLogoUI:SetLogoImageVisibility ImageLogo Not Exists. Is this UI overriden?")
  end
end

local class = require("class")
local UIBase = require("client.slua_ui_framework.base")
return class(UIBase, nil, CommonLogoUI)
