.version	5.3

.format	0
.int_size	4
.size_t_size	4
.instruction_size	4
.integer_format	8
.float_format	8
.endianness	LITTLE

.function	main

.source	null
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	1
.maxstacksize	70

.upvalue	"_ENV"	0	true

.constant	k0	68
.constant	k1	23
.constant	k2	239
.constant	k3	103
.constant	k4	87
.constant	k5	3
.constant	k6	136
.constant	k7	214
.constant	k8	42
.constant	k9	178
.constant	k10	55
.constant	k11	22
.constant	k12	233
.constant	k13	67
.constant	k14	169
.constant	k15	96
.constant	k16	"import"
.constant	k17	2
.constant	k18	71
.constant	k19	203
.constant	k20	119
.constant	k21	181
.constant	k22	211
.constant	k23	28
.constant	k24	66
.constant	k25	188
.constant	k26	192
.constant	k27	121
.constant	k28	1
.constant	k29	80
.constant	k30	201
.constant	k31	104
.constant	k32	164
.constant	k33	93
.constant	k34	128
.constant	k35	216
.constant	k36	99
.constant	k37	38
.constant	k38	225
.constant	k39	16
.constant	k40	101
.constant	k41	123
.constant	k42	160
.constant	k43	40
.constant	k44	156
.constant	k45	249
.constant	k46	126
.constant	k47	35
.constant	k48	254
.constant	k49	170
.constant	k50	"require"
.constant	k51	32
.constant	k52	195
.constant	k53	102
.constant	k54	186
.constant	k55	213
.constant	k56	69
.constant	k57	185
.constant	k58	217
.constant	k59	107
.constant	k60	21
.constant	k61	231
.constant	k62	176
.constant	k63	79
.constant	k64	222
.constant	k65	193
.constant	k66	183
.constant	k67	86
.constant	k68	83
.constant	k69	75
.constant	k70	109
.constant	k71	235
.constant	k72	110
.constant	k73	51
.constant	k74	238
.constant	k75	85
.constant	k76	37
.constant	k77	252
.constant	k78	247
.constant	k79	113
.constant	k80	205
.constant	k81	215
.constant	k82	108
.constant	k83	81
.constant	k84	229
.constant	k85	106
.constant	k86	90
.constant	k87	237
.constant	k88	98
.constant	k89	196
.constant	k90	57
.constant	k91	180
.constant	k92	89
.constant	k93	62
.constant	k94	243
.constant	k95	173
.constant	k96	219
.constant	k97	8
.constant	k98	88
.constant	k99	177
.constant	k100	4
.constant	k101	161
.constant	k102	70
.constant	k103	240
.constant	k104	171
.constant	k105	202
.constant	k106	0
.constant	k107	165
.constant	k108	6
.constant	k109	251
.constant	k110	187
.constant	k111	120
.constant	k112	20
.constant	k113	206
.constant	k114	100
.constant	k115	5
.constant	k116	172
.constant	k117	127
.constant	k118	114
.constant	k119	210
.constant	k120	115
.constant	k121	163
.constant	k122	227
.constant	k123	220
.constant	k124	92
.constant	k125	209
.constant	k126	65
.constant	k127	11
.constant	k128	122
.constant	k129	56
.constant	k130	244
.constant	k131	218
.constant	k132	168
.constant	k133	82
.constant	k134	232
.constant	k135	116
.constant	k136	111
.constant	k137	58
.constant	k138	224
.constant	k139	204
.constant	k140	245
.constant	k141	248
.constant	k142	137
.constant	k143	199
.constant	k144	152
.constant	k145	212
.constant	k146	24
.constant	k147	146
.constant	k148	47
.constant	k149	182
.constant	k150	221
.constant	k151	157
.constant	k152	191
.constant	k153	54
.constant	k154	112
.constant	k155	"table"
.constant	k156	"concat"
.constant	k157	208
.constant	k158	184
.constant	k159	190
.constant	k160	29
.constant	k161	84
.constant	k162	52
.constant	k163	15
.constant	k164	73
.constant	k165	198
.constant	k166	228
.constant	k167	167
.constant	k168	94
.constant	k169	197
.constant	k170	48672
.constant	k171	48670
.constant	k172	89290
.constant	k173	50000
.constant	k174	"FVector2D"
.constant	k175	-20000
.constant	k176	118
.constant	k177	142
.constant	k178	131
.constant	k179	234
.constant	k180	105
.constant	k181	117
.constant	k182	166
.constant	k183	149
.constant	k184	246
.constant	k185	59
.constant	k186	125
.constant	k187	133
.constant	k188	129
.constant	k189	97
.constant	k190	26
.constant	k191	194
.constant	k192	46
.constant	k193	138
.constant	k194	61
.constant	k195	"None"
.constant	k196	"Expression"
.constant	k197	"PetExpression"
.constant	k198	"Bubble"
.constant	k199	"Collection"
.constant	k200	"Flaunt"
.constant	k201	"MiniTvExpression"
.constant	k202	12219241
.constant	k203	true
.constant	k204	12219243
.constant	k205	12219359
.constant	k206	12219360
.constant	k207	12219440
.constant	k208	12219601
.constant	k209	12220038
.constant	k210	12220100
.constant	k211	12220101
.constant	k212	12220102
.constant	k213	12220349
.constant	k214	12220370
.constant	k215	12220501
.constant	k216	"ctor"
.constant	k217	"Dispose"
.constant	k218	"SetCanShowSelfieButton"
.constant	k219	"Tick"
.constant	k220	"Initialize"
.constant	k221	"InitExpression"
.constant	k222	"OnCustomWeaponShowChange"
.constant	k223	"OnButtonLeft"
.constant	k224	"OnButtonRight"
.constant	k225	"OnButtonEmoteOrPet"
.constant	k226	"OnButtonBubble"
.constant	k227	"OnButtonCollectionOrFlaunt"
.constant	k228	"OnButtonShowPet"
.constant	k229	"OnAvatarAllMeshLoaded"
.constant	k230	"MakeWidgetArray"
.constant	k231	"BackpackReceive"
.constant	k232	"RefreshCirclePanel"
.constant	k233	"RefreshBubble"
.constant	k234	"RefreshPetExpression"
.constant	k235	"IsPlanPHMode"
.constant	k236	"IsCollectionMode"
.constant	k237	"RefreshCollection"
.constant	k238	"RefreshEmote"
.constant	k239	"OnMouseButtonDownOnBorder"
.constant	k240	"OnClickItem"
.constant	k241	"TryToPlayBubble"
.constant	k242	"TryToPlayPetExpression"
.constant	k243	"TryToPlayEmote"
.constant	k244	"TryToPlayCollection"
.constant	k245	"PlayEmoteInternal"
.constant	k246	"GetEmoteImagePalthMap"
.constant	k247	"PlayRedClothAudio"
.constant	k248	"OnLoadSoundFromPath"
.constant	k249	"RefreshEmoteWhenShow"
.constant	k250	"ShowHideRing"
.constant	k251	"CheckIsWearingEmoteLimitCloth"
.constant	k252	"SetEmoteColorState"
.constant	k253	"IsBornisland"
.constant	k254	"CheckPlayEmote"
.constant	k255	"HideRing"
.constant	k256	"GetIsEmoteExist"
.constant	k257	"ShowOrHideRing"
.constant	k258	"IsHide"
.constant	k259	"FeatureButtonRefresh"
.constant	k260	"RefreshCheckGunBtnState"
.constant	k261	"HandleChangeCurrentUsingWeapon"
.constant	k262	"OnButtonCheckGun"
.constant	k263	"GetCurrentCheckGunState"
.constant	k264	"TryDoCheckGun"
.constant	k265	"table"
.constant	k266	"concat"
.constant	k267	108
.constant	k268	118
.constant	k269	203
.constant	k270	110
.constant	k271	177
.constant	k272	142
.constant	k273	27
.constant	k274	83
.constant	k275	166
.constant	k276	67
.constant	k277	13
.constant	k278	238
.constant	k279	32
.constant	k280	136
.constant	k281	156
.constant	k282	64
.constant	k283	168
.constant	k284	71
.constant	k285	87
.constant	k286	190
.constant	k287	79
.constant	k288	234
.constant	k289	232
.constant	k290	123
.constant	k291	56
.constant	k292	172
.constant	k293	73
.constant	k294	204
.constant	k295	127
.constant	k296	185
.constant	k297	12
.constant	k298	113
.constant	k299	236
.constant	k300	70
.constant	k301	98
.constant	k302	38
.constant	k303	30
.constant	k304	227
.constant	k305	96
.constant	k306	187
.constant	k307	207
.constant	k308	22
.constant	k309	2
.constant	k310	226
.constant	k311	58
.constant	k312	21
.constant	k313	202
.constant	k314	170
.constant	k315	101
.constant	k316	209
.constant	k317	199
.constant	k318	94
.constant	k319	82
.constant	k320	77
.constant	k321	253
.constant	k322	74
.constant	k323	48
.constant	k324	154
.constant	k325	141
.constant	k326	40
.constant	k327	128
.constant	k328	99
.constant	k329	205
.constant	k330	78
.constant	k331	254
.constant	k332	20
.constant	k333	4
.constant	k334	68
.constant	k335	195
.constant	k336	119
.constant	k337	139
.constant	k338	245
.constant	k339	95
.constant	k340	223
.constant	k341	60
.constant	k342	163
.constant	k343	235
.constant	k344	53
.constant	k345	57
.constant	k346	"GetXSuitTailButtonState"
.constant	k347	"RefreshXSuitTailRedPoint"
.constant	k348	"ApplyXSuitTailButtonState"
.constant	k349	"GetAvatarFormState"
.constant	k350	"GetAvatarFormIcon"
.constant	k351	"RefreshChangeAvatarFormBtnState"
.constant	k352	"TickChangeAvatarFormCD"
.constant	k353	"RefreshTransformButton"
.constant	k354	"TickChangeDragonFormCD"
.constant	k355	"RefreshSelfieButton"
.constant	k356	"CheckIsSpecialPet"
.constant	k357	"RefreshPetButton"
.constant	k358	"OnButtonChangeAvatarForm"
.constant	k359	"OnButtonButton_Transfiguration"
.constant	k360	"OnButton_SelfieClick"
.constant	k361	"OnButtonPetFeature"
.constant	k362	"CanShowXSuitEmote"
.constant	k363	"RefreshXSuitEmoteButton"
.constant	k364	"GetBornIslandAction"
.constant	k365	"OnButtonXSuitEmote"
.constant	k366	"ChangeAvatarForm"
.constant	k367	"OnDestroy"
.constant	k368	"RefreshCollectionList"
.constant	k369	"RefreshPetInfo"
.constant	k370	"GetCurPet"
.constant	k371	"GetShowMyPet"
.constant	k372	"IsSocialIsland"
.constant	k373	"IsMainCity"
.constant	k374	"IsAvatarRequirementMatch"
.constant	k375	"RefreshSwitchButtonState"
.constant	k376	"OnButtonSubTypeSwitchClick"
.constant	k377	"RefreshFlauntList"
.constant	k378	"RefreshFlaunt"
.constant	k379	"OnCardCollectionShowInfoRsp"
.constant	k380	"TryToPlayFlaunt"
.constant	k381	"TryPlayPetExhibitAction"
.constant	k382	"RefreshCDInternal"
.constant	k383	"NeedHidePetExpression"
.constant	k384	"OnButtonRobotClick"
.constant	k385	"RefreshMiniTvExpression"
.constant	k386	"RefreshMiniTvShowSwitch"
.constant	k387	"GetMiniTvType"
.constant	k388	"PrepareMiniTvExpressionList"
.constant	k389	"TryToPlayMiniTvExpression"
.constant	k390	"require"
.constant	k391	32
.constant	k392	93
.constant	k393	203
.constant	k394	112
.constant	k395	167
.constant	k396	94
.constant	k397	199
.constant	k398	110
.constant	k399	187
.constant	k400	207
.constant	k401	103
.constant	k402	82
.constant	k403	176
.constant	k404	192
.constant	k405	111
.constant	k406	45
.constant	k407	243
.constant	k408	173
.constant	k409	117
.constant	k410	231
.constant	k411	208
.constant	k412	180
.constant	k413	71
.constant	k414	69
.constant	k415	248
.constant	k416	87
.constant	k417	99
.constant	k418	183

.line	0	newtable      r0    16     0
.line	0	loadk         r1    k0 ; k0 = 68
.line	0	loadk         r2    k1 ; k1 = 23
.line	0	loadk         r3    k2 ; k2 = 239
.line	0	loadk         r4    k3 ; k3 = 103
.line	0	loadk         r5    k4 ; k4 = 87
.line	0	loadk         r6    k5 ; k5 = 3
.line	0	loadk         r7    k6 ; k6 = 136
.line	0	loadk         r8    k7 ; k7 = 214
.line	0	loadk         r9    k8 ; k8 = 42
.line	0	loadk        r10    k9 ; k9 = 178
.line	0	loadk        r11   k10 ; k10 = 55
.line	0	loadk        r12   k11 ; k11 = 22
.line	0	loadk        r13   k12 ; k12 = 233
.line	0	loadk        r14   k13 ; k13 = 67
.line	0	loadk        r15   k14 ; k14 = 169
.line	0	loadk        r16   k15 ; k15 = 96
.line	0	setlist       r0    16     1
.line	0	closure       r1    f0
.line	0	gettabup      r2    u0   k16 ; k16 = "import"
.line	0	move          r3    r1
.line	0	loadk         r4   k17 ; k17 = 2
.line	0	loadk         r5   k18 ; k18 = 71
.line	0	loadk         r6   k19 ; k19 = 203
.line	0	loadk         r7   k20 ; k20 = 119
.line	0	loadk         r8   k21 ; k21 = 181
.line	0	loadk         r9   k22 ; k22 = 211
.line	0	loadk        r10   k23 ; k23 = 28
.line	0	loadk        r11   k24 ; k24 = 66
.line	0	loadk        r12   k25 ; k25 = 188
.line	0	loadk        r13   k26 ; k26 = 192
.line	0	loadk        r14   k27 ; k27 = 121
.line	0	call          r3    12     2
.line	0	call          r2     2     2
.line	0	gettabup      r3    u0   k16 ; k16 = "import"
.line	0	move          r4    r1
.line	0	loadk         r5   k28 ; k28 = 1
.line	0	loadk         r6   k29 ; k29 = 80
.line	0	loadk         r7   k30 ; k30 = 201
.line	0	loadk         r8   k31 ; k31 = 104
.line	0	loadk         r9   k32 ; k32 = 164
.line	0	loadk        r10   k26 ; k26 = 192
.line	0	loadk        r11    k8 ; k8 = 42
.line	0	loadk        r12   k33 ; k33 = 93
.line	0	loadk        r13   k34 ; k34 = 128
.line	0	loadk        r14   k35 ; k35 = 216
.line	0	loadk        r15   k36 ; k36 = 99
.line	0	loadk        r16   k37 ; k37 = 38
.line	0	loadk        r17   k38 ; k38 = 225
.line	0	call          r4    14     2
.line	0	call          r3     2     2
.line	0	gettabup      r4    u0   k16 ; k16 = "import"
.line	0	move          r5    r1
.line	0	loadk         r6   k39 ; k39 = 16
.line	0	loadk         r7   k40 ; k40 = 101
.line	0	loadk         r8    k2 ; k2 = 239
.line	0	loadk         r9   k41 ; k41 = 123
.line	0	loadk        r10   k42 ; k42 = 160
.line	0	loadk        r11   k22 ; k22 = 211
.line	0	loadk        r12   k43 ; k43 = 40
.line	0	loadk        r13   k36 ; k36 = 99
.line	0	loadk        r14   k44 ; k44 = 156
.line	0	loadk        r15   k45 ; k45 = 249
.line	0	loadk        r16   k46 ; k46 = 126
.line	0	loadk        r17   k47 ; k47 = 35
.line	0	loadk        r18   k48 ; k48 = 254
.line	0	loadk        r19   k49 ; k49 = 170
.line	0	call          r5    15     2
.line	0	call          r4     2     2
.line	0	gettabup      r5    u0   k50 ; k50 = "require"
.line	0	move          r6    r1
.line	0	loadk         r7   k51 ; k51 = 32
.line	0	loadk         r8   k33 ; k33 = 93
.line	0	loadk         r9   k52 ; k52 = 195
.line	0	loadk        r10   k53 ; k53 = 102
.line	0	loadk        r11   k54 ; k54 = 186
.line	0	loadk        r12   k55 ; k55 = 213
.line	0	loadk        r13    k3 ; k3 = 103
.line	0	loadk        r14   k56 ; k56 = 69
.line	0	loadk        r15   k57 ; k57 = 185
.line	0	loadk        r16   k58 ; k58 = 217
.line	0	loadk        r17   k59 ; k59 = 107
.line	0	loadk        r18   k60 ; k60 = 21
.line	0	loadk        r19   k61 ; k61 = 231
.line	0	loadk        r20   k62 ; k62 = 176
.line	0	loadk        r21   k63 ; k63 = 79
.line	0	loadk        r22   k64 ; k64 = 222
.line	0	loadk        r23   k65 ; k65 = 193
.line	0	loadk        r24   k15 ; k15 = 96
.line	0	loadk        r25   k66 ; k66 = 183
.line	0	loadk        r26   k67 ; k67 = 86
.line	0	loadk        r27   k68 ; k68 = 83
.line	0	loadk        r28   k48 ; k48 = 254
.line	0	loadk        r29   k69 ; k69 = 75
.line	0	loadk        r30   k70 ; k70 = 109
.line	0	loadk        r31   k71 ; k71 = 235
.line	0	loadk        r32   k30 ; k30 = 201
.line	0	loadk        r33   k72 ; k72 = 110
.line	0	loadk        r34   k73 ; k73 = 51
.line	0	loadk        r35   k74 ; k74 = 238
.line	0	call          r6    30     2
.line	0	call          r5     2     2
.line	0	gettabup      r6    u0   k50 ; k50 = "require"
.line	0	move          r7    r1
.line	0	loadk         r8   k51 ; k51 = 32
.line	0	loadk         r9   k33 ; k33 = 93
.line	0	loadk        r10   k52 ; k52 = 195
.line	0	loadk        r11   k53 ; k53 = 102
.line	0	loadk        r12   k54 ; k54 = 186
.line	0	loadk        r13   k55 ; k55 = 213
.line	0	loadk        r14    k3 ; k3 = 103
.line	0	loadk        r15   k75 ; k75 = 85
.line	0	loadk        r16   k54 ; k54 = 186
.line	0	loadk        r17   k65 ; k65 = 193
.line	0	loadk        r18    k3 ; k3 = 103
.line	0	loadk        r19   k76 ; k76 = 37
.line	0	loadk        r20   k77 ; k77 = 252
.line	0	loadk        r21   k78 ; k78 = 247
.line	0	loadk        r22   k79 ; k79 = 113
.line	0	loadk        r23   k80 ; k80 = 205
.line	0	loadk        r24   k81 ; k81 = 215
.line	0	loadk        r25   k31 ; k31 = 104
.line	0	loadk        r26   k21 ; k21 = 181
.line	0	loadk        r27   k82 ; k82 = 108
.line	0	loadk        r28   k83 ; k83 = 81
.line	0	loadk        r29   k84 ; k84 = 229
.line	0	loadk        r30   k29 ; k29 = 80
.line	0	loadk        r31   k85 ; k85 = 106
.line	0	call          r7    25     2
.line	0	call          r6     2     2
.line	0	gettabup      r7    u0   k16 ; k16 = "import"
.line	0	move          r8    r1
.line	0	loadk         r9   k17 ; k17 = 2
.line	0	loadk        r10   k86 ; k86 = 90
.line	0	loadk        r11   k87 ; k87 = 237
.line	0	loadk        r12   k88 ; k88 = 98
.line	0	loadk        r13   k57 ; k57 = 185
.line	0	loadk        r14   k89 ; k89 = 196
.line	0	loadk        r15   k90 ; k90 = 57
.line	0	loadk        r16   k86 ; k86 = 90
.line	0	loadk        r17   k91 ; k91 = 180
.line	0	loadk        r18   k55 ; k55 = 213
.line	0	loadk        r19   k92 ; k92 = 89
.line	0	loadk        r20   k93 ; k93 = 62
.line	0	loadk        r21   k94 ; k94 = 243
.line	0	loadk        r22   k95 ; k95 = 173
.line	0	loadk        r23   k27 ; k27 = 121
.line	0	loadk        r24   k96 ; k96 = 219
.line	0	loadk        r25   k26 ; k26 = 192
.line	0	call          r8    18     2
.line	0	call          r7     2     2
.line	0	gettabup      r8    u0   k16 ; k16 = "import"
.line	0	move          r9    r1
.line	0	loadk        r10   k97 ; k97 = 8
.line	0	loadk        r11   k98 ; k98 = 88
.line	0	loadk        r12   k58 ; k58 = 217
.line	0	loadk        r13   k72 ; k72 = 110
.line	0	loadk        r14   k99 ; k99 = 177
.line	0	loadk        r15   k55 ; k55 = 213
.line	0	loadk        r16  k100 ; k100 = 4
.line	0	loadk        r17    k4 ; k4 = 87
.line	0	loadk        r18  k101 ; k101 = 161
.line	0	loadk        r19   k89 ; k89 = 196
.line	0	loadk        r20  k102 ; k102 = 70
.line	0	loadk        r21   k47 ; k47 = 35
.line	0	loadk        r22  k103 ; k103 = 240
.line	0	loadk        r23  k104 ; k104 = 171
.line	0	loadk        r24   k79 ; k79 = 113
.line	0	loadk        r25  k105 ; k105 = 202
.line	0	loadk        r26  k105 ; k105 = 202
.line	0	call          r9    18     2
.line	0	call          r8     2     2
.line	0	gettabup      r9    u0   k16 ; k16 = "import"
.line	0	move         r10    r1
.line	0	loadk        r11   k97 ; k97 = 8
.line	0	loadk        r12   k98 ; k98 = 88
.line	0	loadk        r13   k58 ; k58 = 217
.line	0	loadk        r14   k72 ; k72 = 110
.line	0	loadk        r15   k99 ; k99 = 177
.line	0	loadk        r16   k55 ; k55 = 213
.line	0	loadk        r17  k106 ; k106 = 0
.line	0	loadk        r18   k98 ; k98 = 88
.line	0	loadk        r19  k107 ; k107 = 165
.line	0	loadk        r20   k58 ; k58 = 217
.line	0	loadk        r21   k46 ; k46 = 126
.line	0	loadk        r22  k108 ; k108 = 6
.line	0	loadk        r23  k109 ; k109 = 251
.line	0	loadk        r24  k110 ; k110 = 187
.line	0	loadk        r25   k88 ; k88 = 98
.line	0	loadk        r26   k58 ; k58 = 217
.line	0	loadk        r27   k65 ; k65 = 193
.line	0	loadk        r28  k111 ; k111 = 120
.line	0	call         r10    19     2
.line	0	call          r9     2     2
.line	0	gettabup     r10    u0   k16 ; k16 = "import"
.line	0	move         r11    r1
.line	0	loadk        r12  k112 ; k112 = 20
.line	0	loadk        r13   k98 ; k98 = 88
.line	0	loadk        r14  k113 ; k113 = 206
.line	0	loadk        r15  k114 ; k114 = 100
.line	0	loadk        r16   k99 ; k99 = 177
.line	0	loadk        r17   k55 ; k55 = 213
.line	0	loadk        r18  k115 ; k115 = 5
.line	0	loadk        r19    k4 ; k4 = 87
.line	0	loadk        r20  k116 ; k116 = 172
.line	0	loadk        r21   k52 ; k52 = 195
.line	0	loadk        r22  k117 ; k117 = 127
.line	0	loadk        r23   k93 ; k93 = 62
.line	0	loadk        r24   k64 ; k64 = 222
.line	0	loadk        r25   k62 ; k62 = 176
.line	0	loadk        r26  k118 ; k118 = 114
.line	0	loadk        r27  k105 ; k105 = 202
.line	0	loadk        r28  k119 ; k119 = 210
.line	0	loadk        r29  k120 ; k120 = 115
.line	0	loadk        r30  k121 ; k121 = 163
.line	0	call         r11    20     2
.line	0	call         r10     2     2
.line	0	gettabup     r11    u0   k16 ; k16 = "import"
.line	0	move         r12    r1
.line	0	loadk        r13   k39 ; k39 = 16
.line	0	loadk        r14   k33 ; k33 = 93
.line	0	loadk        r15   k19 ; k19 = 203
.line	0	loadk        r16   k20 ; k20 = 119
.line	0	loadk        r17   k99 ; k99 = 177
.line	0	loadk        r18  k122 ; k122 = 227
.line	0	loadk        r19   k76 ; k76 = 37
.line	0	loadk        r20   k13 ; k13 = 67
.line	0	loadk        r21   k62 ; k62 = 176
.line	0	loadk        r22  k123 ; k123 = 220
.line	0	loadk        r23  k111 ; k111 = 120
.line	0	loadk        r24   k47 ; k47 = 35
.line	0	loadk        r25   k77 ; k77 = 252
.line	0	loadk        r26   k95 ; k95 = 173
.line	0	loadk        r27  k124 ; k124 = 92
.line	0	loadk        r28  k125 ; k125 = 209
.line	0	loadk        r29  k125 ; k125 = 209
.line	0	loadk        r30  k120 ; k120 = 115
.line	0	loadk        r31  k110 ; k110 = 187
.line	0	loadk        r32  k126 ; k126 = 65
.line	0	loadk        r33   k33 ; k33 = 93
.line	0	call         r12    22     2
.line	0	call         r11     2     2
.line	0	gettabup     r12    u0   k16 ; k16 = "import"
.line	0	move         r13    r1
.line	0	loadk        r14  k112 ; k112 = 20
.line	0	loadk        r15   k98 ; k98 = 88
.line	0	loadk        r16  k113 ; k113 = 206
.line	0	loadk        r17  k114 ; k114 = 100
.line	0	loadk        r18   k99 ; k99 = 177
.line	0	loadk        r19   k55 ; k55 = 213
.line	0	loadk        r20  k127 ; k127 = 11
.line	0	loadk        r21   k86 ; k86 = 90
.line	0	loadk        r22   k42 ; k42 = 160
.line	0	loadk        r23   k30 ; k30 = 201
.line	0	loadk        r24  k128 ; k128 = 122
.line	0	loadk        r25  k129 ; k129 = 56
.line	0	loadk        r26  k109 ; k109 = 251
.line	0	loadk        r27   k66 ; k66 = 183
.line	0	loadk        r28  k114 ; k114 = 100
.line	0	loadk        r29  k130 ; k130 = 244
.line	0	loadk        r30  k131 ; k131 = 218
.line	0	loadk        r31   k36 ; k36 = 99
.line	0	loadk        r32  k132 ; k132 = 168
.line	0	loadk        r33  k133 ; k133 = 82
.line	0	loadk        r34   k67 ; k67 = 86
.line	0	loadk        r35  k134 ; k134 = 232
.line	0	call         r13    23     2
.line	0	call         r12     2     2
.line	0	gettabup     r13    u0   k16 ; k16 = "import"
.line	0	move         r14    r1
.line	0	loadk        r15   k39 ; k39 = 16
.line	0	loadk        r16   k40 ; k40 = 101
.line	0	loadk        r17    k2 ; k2 = 239
.line	0	loadk        r18   k41 ; k41 = 123
.line	0	loadk        r19   k42 ; k42 = 160
.line	0	loadk        r20   k22 ; k22 = 211
.line	0	loadk        r21   k43 ; k43 = 40
.line	0	loadk        r22  k135 ; k135 = 116
.line	0	loadk        r23   k57 ; k57 = 185
.line	0	loadk        r24   k58 ; k58 = 217
.line	0	loadk        r25  k136 ; k136 = 111
.line	0	loadk        r26  k137 ; k137 = 58
.line	0	loadk        r27  k138 ; k138 = 224
.line	0	loadk        r28   k62 ; k62 = 176
.line	0	loadk        r29   k46 ; k46 = 126
.line	0	loadk        r30  k139 ; k139 = 204
.line	0	loadk        r31  k140 ; k140 = 245
.line	0	loadk        r32  k135 ; k135 = 116
.line	0	loadk        r33   k91 ; k91 = 180
.line	0	loadk        r34   k29 ; k29 = 80
.line	0	loadk        r35   k29 ; k29 = 80
.line	0	loadk        r36  k141 ; k141 = 248
.line	0	loadk        r37   k67 ; k67 = 86
.line	0	loadk        r38   k31 ; k31 = 104
.line	0	loadk        r39  k142 ; k142 = 137
.line	0	loadk        r40   k55 ; k55 = 213
.line	0	loadk        r41  k111 ; k111 = 120
.line	0	loadk        r42   k43 ; k43 = 40
.line	0	loadk        r43  k122 ; k122 = 227
.line	0	loadk        r44  k110 ; k110 = 187
.line	0	loadk        r45   k27 ; k27 = 121
.line	0	call         r14    32     2
.line	0	call         r13     2     2
.line	0	gettabup     r14    u0   k50 ; k50 = "require"
.line	0	move         r15    r1
.line	0	loadk        r16  k100 ; k100 = 4
.line	0	loadk        r17   k29 ; k29 = 80
.line	0	loadk        r18  k143 ; k143 = 199
.line	0	loadk        r19   k53 ; k53 = 102
.line	0	loadk        r20  k144 ; k144 = 152
.line	0	loadk        r21  k145 ; k145 = 212
.line	0	loadk        r22   k43 ; k43 = 40
.line	0	loadk        r23  k146 ; k146 = 24
.line	0	loadk        r24  k147 ; k147 = 146
.line	0	loadk        r25   k80 ; k80 = 205
.line	0	loadk        r26    k3 ; k3 = 103
.line	0	loadk        r27  k148 ; k148 = 47
.line	0	loadk        r28  k125 ; k125 = 209
.line	0	loadk        r29  k149 ; k149 = 182
.line	0	loadk        r30   k88 ; k88 = 98
.line	0	loadk        r31  k150 ; k150 = 221
.line	0	loadk        r32  k151 ; k151 = 157
.line	0	loadk        r33   k56 ; k56 = 69
.line	0	loadk        r34  k110 ; k110 = 187
.line	0	loadk        r35   k18 ; k18 = 71
.line	0	loadk        r36   k56 ; k56 = 69
.line	0	loadk        r37  k152 ; k152 = 191
.line	0	loadk        r38   k46 ; k46 = 126
.line	0	loadk        r39    k3 ; k3 = 103
.line	0	loadk        r40  k132 ; k132 = 168
.line	0	loadk        r41   k58 ; k58 = 217
.line	0	loadk        r42   k85 ; k85 = 106
.line	0	loadk        r43  k153 ; k153 = 54
.line	0	loadk        r44  k122 ; k122 = 227
.line	0	loadk        r45   k62 ; k62 = 176
.line	0	loadk        r46    k0 ; k0 = 68
.line	0	loadk        r47   k30 ; k30 = 201
.line	0	loadk        r48   k81 ; k81 = 215
.line	0	loadk        r49  k154 ; k154 = 112
.line	0	call         r15    35     2
.line	0	call         r14     2     2
.line	0	gettabup     r15    u0   k50 ; k50 = "require"
.line	0	gettabup     r16    u0  k155 ; k155 = "table"
.line	0	gettable     r16   r16  k156 ; k156 = "concat"
.line	0	newtable     r17     1     0
.line	0	move         r18    r1
.line	0	loadk        r19  k100 ; k100 = 4
.line	0	loadk        r20   k29 ; k29 = 80
.line	0	loadk        r21  k143 ; k143 = 199
.line	0	loadk        r22   k53 ; k53 = 102
.line	0	loadk        r23  k144 ; k144 = 152
.line	0	loadk        r24  k145 ; k145 = 212
.line	0	loadk        r25   k43 ; k43 = 40
.line	0	loadk        r26  k146 ; k146 = 24
.line	0	loadk        r27  k144 ; k144 = 152
.line	0	loadk        r28   k52 ; k52 = 195
.line	0	loadk        r29   k72 ; k72 = 110
.line	0	loadk        r30  k114 ; k114 = 100
.line	0	loadk        r31  k157 ; k157 = 208
.line	0	loadk        r32  k158 ; k158 = 184
.line	0	loadk        r33   k36 ; k36 = 99
.line	0	loadk        r34  k150 ; k150 = 221
.line	0	loadk        r35   k48 ; k48 = 254
.line	0	loadk        r36   k72 ; k72 = 110
.line	0	loadk        r37  k159 ; k159 = 190
.line	0	loadk        r38  k160 ; k160 = 29
.line	0	loadk        r39    k3 ; k3 = 103
.line	0	loadk        r40   k48 ; k48 = 254
.line	0	loadk        r41  k161 ; k161 = 84
.line	0	loadk        r42   k59 ; k59 = 107
.line	0	loadk        r43   k49 ; k49 = 170
.line	0	loadk        r44  k119 ; k119 = 210
.line	0	loadk        r45  k162 ; k162 = 52
.line	0	loadk        r46  k163 ; k163 = 15
.line	0	loadk        r47   k19 ; k19 = 203
.line	0	loadk        r48   k61 ; k61 = 231
.line	0	loadk        r49  k164 ; k164 = 73
.line	0	loadk        r50  k165 ; k165 = 198
.line	0	loadk        r51  k166 ; k166 = 228
.line	0	loadk        r52  k154 ; k154 = 112
.line	0	loadk        r53  k167 ; k167 = 167
.line	0	loadk        r54  k102 ; k102 = 70
.line	0	loadk        r55   k15 ; k15 = 96
.line	0	loadk        r56  k134 ; k134 = 232
.line	0	loadk        r57   k92 ; k92 = 89
.line	0	loadk        r58   k40 ; k40 = 101
.line	0	call         r18    41     2
.line	0	move         r19    r1
.line	0	loadk        r20    k1 ; k1 = 23
.line	0	loadk        r21  k168 ; k168 = 94
.line	0	loadk        r22  k169 ; k169 = 197
.line	0	loadk        r23  k136 ; k136 = 111
.line	0	loadk        r24  k167 ; k167 = 167
.line	0	call         r19     6     0
.line	0	setlist      r17     0     1
.line	0	call         r16     2     2
.line	0	call         r15     2     2
.line	0	loadk        r16  k170 ; k170 = 48672
.line	0	loadk        r17  k171 ; k171 = 48670
.line	0	loadk        r18  k172 ; k172 = 89290
.line	0	loadk        r19  k173 ; k173 = 50000
.line	0	gettabup     r20    u0  k174 ; k174 = "FVector2D"
.line	0	loadk        r21  k175 ; k175 = -20000
.line	0	loadk        r22  k106 ; k106 = 0
.line	0	call         r20     3     2
.line	0	gettabup     r21    u0  k155 ; k155 = "table"
.line	0	gettable     r21   r21  k156 ; k156 = "concat"
.line	0	newtable     r22     2     0
.line	0	move         r23    r1
.line	0	loadk        r24   k82 ; k82 = 108
.line	0	loadk        r25  k176 ; k176 = 118
.line	0	loadk        r26   k19 ; k19 = 203
.line	0	loadk        r27   k72 ; k72 = 110
.line	0	loadk        r28   k99 ; k99 = 177
.line	0	loadk        r29  k177 ; k177 = 142
.line	0	loadk        r30   k23 ; k23 = 28
.line	0	loadk        r31   k41 ; k41 = 123
.line	0	loadk        r32  k147 ; k147 = 146
.line	0	loadk        r33  k178 ; k178 = 131
.line	0	loadk        r34  k168 ; k168 = 94
.line	0	loadk        r35  k148 ; k148 = 47
.line	0	loadk        r36  k179 ; k179 = 234
.line	0	loadk        r37   k95 ; k95 = 173
.line	0	loadk        r38   k40 ; k40 = 101
.line	0	loadk        r39  k105 ; k105 = 202
.line	0	loadk        r40    k7 ; k7 = 214
.line	0	loadk        r41  k168 ; k168 = 94
.line	0	loadk        r42  k134 ; k134 = 232
.line	0	loadk        r43    k5 ; k5 = 3
.line	0	loadk        r44  k112 ; k112 = 20
.line	0	loadk        r45  k159 ; k159 = 190
.line	0	loadk        r46  k111 ; k111 = 120
.line	0	loadk        r47  k118 ; k118 = 114
.line	0	loadk        r48   k14 ; k14 = 169
.line	0	loadk        r49  k150 ; k150 = 221
.line	0	loadk        r50  k180 ; k180 = 105
.line	0	loadk        r51  k181 ; k181 = 117
.line	0	loadk        r52   k65 ; k65 = 193
.line	0	loadk        r53  k182 ; k182 = 166
.line	0	loadk        r54   k70 ; k70 = 109
.line	0	loadk        r55  k169 ; k169 = 197
.line	0	loadk        r56  k139 ; k139 = 204
.line	0	loadk        r57  k117 ; k117 = 127
.line	0	loadk        r58  k183 ; k183 = 149
.line	0	loadk        r59   k70 ; k70 = 109
.line	0	loadk        r60   k83 ; k83 = 81
.line	0	loadk        r61  k184 ; k184 = 246
.line	0	loadk        r62  k176 ; k176 = 118
.line	0	loadk        r63    k4 ; k4 = 87
.line	0	call         r23    41     2
.line	0	move         r24    r1
.line	0	loadk        r25   k10 ; k10 = 55
.line	0	loadk        r26   k33 ; k33 = 93
.line	0	loadk        r27   k19 ; k19 = 203
.line	0	loadk        r28  k154 ; k154 = 112
.line	0	loadk        r29  k109 ; k109 = 251
.line	0	loadk        r30   k61 ; k61 = 231
.line	0	loadk        r31  k185 ; k185 = 59
.line	0	loadk        r32    k4 ; k4 = 87
.line	0	loadk        r33  k158 ; k158 = 184
.line	0	loadk        r34   k30 ; k30 = 201
.line	0	loadk        r35   k27 ; k27 = 121
.line	0	loadk        r36   k40 ; k40 = 101
.line	0	loadk        r37  k125 ; k125 = 209
.line	0	loadk        r38  k149 ; k149 = 182
.line	0	loadk        r39  k186 ; k186 = 125
.line	0	loadk        r40   k55 ; k55 = 213
.line	0	loadk        r41  k123 ; k123 = 220
.line	0	loadk        r42  k136 ; k136 = 111
.line	0	loadk        r43  k187 ; k187 = 133
.line	0	loadk        r44  k128 ; k128 = 122
.line	0	loadk        r45   k18 ; k18 = 71
.line	0	loadk        r46   k48 ; k48 = 254
.line	0	loadk        r47    k4 ; k4 = 87
.line	0	loadk        r48   k92 ; k92 = 89
.line	0	loadk        r49  k188 ; k188 = 129
.line	0	loadk        r50   k22 ; k22 = 211
.line	0	loadk        r51   k70 ; k70 = 109
.line	0	loadk        r52  k162 ; k162 = 52
.line	0	loadk        r53   k74 ; k74 = 238
.line	0	loadk        r54  k182 ; k182 = 166
.line	0	loadk        r55  k189 ; k189 = 97
.line	0	loadk        r56  k139 ; k139 = 204
.line	0	loadk        r57   k77 ; k77 = 252
.line	0	loadk        r58  k189 ; k189 = 97
.line	0	loadk        r59   k32 ; k32 = 164
.line	0	loadk        r60    k0 ; k0 = 68
.line	0	loadk        r61  k190 ; k190 = 26
.line	0	loadk        r62  k191 ; k191 = 194
.line	0	loadk        r63  k102 ; k102 = 70
.line	0	loadk        r64   k41 ; k41 = 123
.line	0	call         r24    41     2
.line	0	move         r25    r1
.line	0	loadk        r26  k192 ; k192 = 46
.line	0	loadk        r27  k168 ; k168 = 94
.line	0	loadk        r28   k89 ; k89 = 196
.line	0	loadk        r29  k124 ; k124 = 92
.line	0	loadk        r30  k151 ; k151 = 157
.line	0	loadk        r31  k191 ; k191 = 194
.line	0	loadk        r32   k37 ; k37 = 38
.line	0	loadk        r33   k98 ; k98 = 88
.line	0	loadk        r34  k193 ; k193 = 138
.line	0	loadk        r35  k134 ; k134 = 232
.line	0	loadk        r36   k40 ; k40 = 101
.line	0	loadk        r37  k194 ; k194 = 61
.line	0	loadk        r38   k77 ; k77 = 252
.line	0	loadk        r39   k21 ; k21 = 181
.line	0	loadk        r40  k117 ; k117 = 127
.line	0	loadk        r41   k58 ; k58 = 217
.line	0	loadk        r42   k81 ; k81 = 215
.line	0	loadk        r43  k168 ; k168 = 94
.line	0	loadk        r44   k49 ; k49 = 170
.line	0	loadk        r45   k33 ; k33 = 93
.line	0	loadk        r46   k13 ; k13 = 67
.line	0	call         r25    22     0
.line	0	setlist      r22     0     1
.line	0	call         r21     2     2
.line	0	newtable     r22     0     0
.line	0	newtable     r23     0     7
.line	0	settable     r23  k195  k106 ; k106 = 0
.line	0	settable     r23  k196   k28 ; k28 = 1
.line	0	settable     r23  k197   k17 ; k17 = 2
.line	0	settable     r23  k198    k5 ; k5 = 3
.line	0	settable     r23  k199  k100 ; k100 = 4
.line	0	settable     r23  k200  k115 ; k115 = 5
.line	0	settable     r23  k201  k108 ; k108 = 6
.line	0	newtable     r24     0    13
.line	0	settable     r24  k202  k203 ; k203 = true
.line	0	settable     r24  k204  k203 ; k203 = true
.line	0	settable     r24  k205  k203 ; k203 = true
.line	0	settable     r24  k206  k203 ; k203 = true
.line	0	settable     r24  k207  k203 ; k203 = true
.line	0	settable     r24  k208  k203 ; k203 = true
.line	0	settable     r24  k209  k203 ; k203 = true
.line	0	settable     r24  k210  k203 ; k203 = true
.line	0	settable     r24  k211  k203 ; k203 = true
.line	0	settable     r24  k212  k203 ; k203 = true
.line	0	settable     r24  k213  k203 ; k203 = true
.line	0	settable     r24  k214  k203 ; k203 = true
.line	0	settable     r24  k215  k203 ; k203 = true
.line	0	closure      r25    f1
.line	0	settable     r22  k216   r25 ; k216 = "ctor"
.line	0	closure      r25    f2
.line	0	settable     r22  k217   r25 ; k217 = "Dispose"
.line	0	closure      r25    f3
.line	0	settable     r22  k218   r25 ; k218 = "SetCanShowSelfieButt" (truncated)
.line	0	closure      r25    f4
.line	0	settable     r22  k219   r25 ; k219 = "Tick"
.line	0	closure      r25    f5
.line	0	settable     r22  k220   r25 ; k220 = "Initialize"
.line	0	closure      r25    f6
.line	0	settable     r22  k221   r25 ; k221 = "InitExpression"
.line	0	closure      r25    f7
.line	0	settable     r22  k222   r25 ; k222 = "OnCustomWeaponShowCh" (truncated)
.line	0	closure      r25    f8
.line	0	settable     r22  k223   r25 ; k223 = "OnButtonLeft"
.line	0	closure      r25    f9
.line	0	settable     r22  k224   r25 ; k224 = "OnButtonRight"
.line	0	closure      r25   f10
.line	0	settable     r22  k225   r25 ; k225 = "OnButtonEmoteOrPet"
.line	0	closure      r25   f11
.line	0	settable     r22  k226   r25 ; k226 = "OnButtonBubble"
.line	0	closure      r25   f12
.line	0	settable     r22  k227   r25 ; k227 = "OnButtonCollectionOr" (truncated)
.line	0	closure      r25   f13
.line	0	settable     r22  k228   r25 ; k228 = "OnButtonShowPet"
.line	0	closure      r25   f14
.line	0	settable     r22  k229   r25 ; k229 = "OnAvatarAllMeshLoade" (truncated)
.line	0	closure      r25   f15
.line	0	settable     r22  k230   r25 ; k230 = "MakeWidgetArray"
.line	0	closure      r25   f16
.line	0	settable     r22  k231   r25 ; k231 = "BackpackReceive"
.line	0	closure      r25   f17
.line	0	settable     r22  k232   r25 ; k232 = "RefreshCirclePanel"
.line	0	closure      r25   f18
.line	0	settable     r22  k233   r25 ; k233 = "RefreshBubble"
.line	0	closure      r25   f19
.line	0	settable     r22  k234   r25 ; k234 = "RefreshPetExpression"
.line	0	closure      r25   f20
.line	0	settable     r22  k235   r25 ; k235 = "IsPlanPHMode"
.line	0	closure      r25   f21
.line	0	settable     r22  k236   r25 ; k236 = "IsCollectionMode"
.line	0	closure      r25   f22
.line	0	settable     r22  k237   r25 ; k237 = "RefreshCollection"
.line	0	closure      r25   f23
.line	0	settable     r22  k238   r25 ; k238 = "RefreshEmote"
.line	0	closure      r25   f24
.line	0	settable     r22  k239   r25 ; k239 = "OnMouseButtonDownOnB" (truncated)
.line	0	closure      r25   f25
.line	0	settable     r22  k240   r25 ; k240 = "OnClickItem"
.line	0	closure      r25   f26
.line	0	settable     r22  k241   r25 ; k241 = "TryToPlayBubble"
.line	0	closure      r25   f27
.line	0	settable     r22  k242   r25 ; k242 = "TryToPlayPetExpressi" (truncated)
.line	0	closure      r25   f28
.line	0	settable     r22  k243   r25 ; k243 = "TryToPlayEmote"
.line	0	closure      r25   f29
.line	0	settable     r22  k244   r25 ; k244 = "TryToPlayCollection"
.line	0	closure      r25   f30
.line	0	settable     r22  k245   r25 ; k245 = "PlayEmoteInternal"
.line	0	closure      r25   f31
.line	0	settable     r22  k246   r25 ; k246 = "GetEmoteImagePalthMa" (truncated)
.line	0	closure      r25   f32
.line	0	settable     r22  k247   r25 ; k247 = "PlayRedClothAudio"
.line	0	closure      r25   f33
.line	0	settable     r22  k248   r25 ; k248 = "OnLoadSoundFromPath"
.line	0	closure      r25   f34
.line	0	settable     r22  k249   r25 ; k249 = "RefreshEmoteWhenShow"
.line	0	closure      r25   f35
.line	0	settable     r22  k250   r25 ; k250 = "ShowHideRing"
.line	0	closure      r25   f36
.line	0	settable     r22  k251   r25 ; k251 = "CheckIsWearingEmoteL" (truncated)
.line	0	closure      r25   f37
.line	0	settable     r22  k252   r25 ; k252 = "SetEmoteColorState"
.line	0	closure      r25   f38
.line	0	settable     r22  k253   r25 ; k253 = "IsBornisland"
.line	0	closure      r25   f39
.line	0	settable     r22  k254   r25 ; k254 = "CheckPlayEmote"
.line	0	closure      r25   f40
.line	0	settable     r22  k255   r25 ; k255 = "HideRing"
.line	0	loadk        r25  k256 ; k256 = "GetIsEmoteExist"
.line	0	closure      r26   f41
.line	0	settable     r22   r25   r26
.line	0	loadk        r25  k257 ; k257 = "ShowOrHideRing"
.line	0	closure      r26   f42
.line	0	settable     r22   r25   r26
.line	0	loadk        r25  k258 ; k258 = "IsHide"
.line	0	closure      r26   f43
.line	0	settable     r22   r25   r26
.line	0	loadk        r25  k259 ; k259 = "FeatureButtonRefresh"
.line	0	closure      r26   f44
.line	0	settable     r22   r25   r26
.line	0	loadk        r25  k260 ; k260 = "RefreshCheckGunBtnSt" (truncated)
.line	0	closure      r26   f45
.line	0	settable     r22   r25   r26
.line	0	loadk        r25  k261 ; k261 = "HandleChangeCurrentU" (truncated)
.line	0	closure      r26   f46
.line	0	settable     r22   r25   r26
.line	0	loadk        r25  k262 ; k262 = "OnButtonCheckGun"
.line	0	closure      r26   f47
.line	0	settable     r22   r25   r26
.line	0	loadk        r25  k263 ; k263 = "GetCurrentCheckGunSt" (truncated)
.line	0	closure      r26   f48
.line	0	settable     r22   r25   r26
.line	0	loadk        r25  k264 ; k264 = "TryDoCheckGun"
.line	0	closure      r26   f49
.line	0	settable     r22   r25   r26
.line	0	loadk        r25  k265 ; k265 = "table"
.line	0	gettabup     r25    u0   r25
.line	0	loadk        r26  k266 ; k266 = "concat"
.line	0	gettable     r25   r25   r26
.line	0	newtable     r26     2     0
.line	0	move         r27    r1
.line	0	loadk        r28  k267 ; k267 = 108
.line	0	loadk        r29  k268 ; k268 = 118
.line	0	loadk        r30  k269 ; k269 = 203
.line	0	loadk        r31  k270 ; k270 = 110
.line	0	loadk        r32  k271 ; k271 = 177
.line	0	loadk        r33  k272 ; k272 = 142
.line	0	loadk        r34  k273 ; k273 = 27
.line	0	loadk        r35  k274 ; k274 = 83
.line	0	loadk        r36  k275 ; k275 = 166
.line	0	loadk        r37  k178 ; k178 = 131
.line	0	loadk        r38  k276 ; k276 = 67
.line	0	loadk        r39  k277 ; k277 = 13
.line	0	loadk        r40  k275 ; k275 = 166
.line	0	loadk        r41  k278 ; k278 = 238
.line	0	loadk        r42  k279 ; k279 = 32
.line	0	loadk        r43  k280 ; k280 = 136
.line	0	loadk        r44  k281 ; k281 = 156
.line	0	loadk        r45  k282 ; k282 = 64
.line	0	loadk        r46  k283 ; k283 = 168
.line	0	loadk        r47  k284 ; k284 = 71
.line	0	loadk        r48  k285 ; k285 = 87
.line	0	loadk        r49  k286 ; k286 = 190
.line	0	loadk        r50  k267 ; k267 = 108
.line	0	loadk        r51  k287 ; k287 = 79
.line	0	loadk        r52  k288 ; k288 = 234
.line	0	loadk        r53  k289 ; k289 = 232
.line	0	loadk        r54  k290 ; k290 = 123
.line	0	loadk        r55  k291 ; k291 = 56
.line	0	loadk        r56  k278 ; k278 = 238
.line	0	loadk        r57  k292 ; k292 = 172
.line	0	loadk        r58  k293 ; k293 = 73
.line	0	loadk        r59  k269 ; k269 = 203
.line	0	loadk        r60  k294 ; k294 = 204
.line	0	loadk        r61  k295 ; k295 = 127
.line	0	loadk        r62  k296 ; k296 = 185
.line	0	loadk        r63  k297 ; k297 = 12
.line	0	loadk        r64  k298 ; k298 = 113
.line	0	loadk        r65  k299 ; k299 = 236
.line	0	loadk        r66  k300 ; k300 = 70
.line	0	loadk        r67  k301 ; k301 = 98
.line	0	call         r27    41     2
.line	0	move         r28    r1
.line	0	loadk        r29  k302 ; k302 = 38
.line	0	loadk        r30  k303 ; k303 = 30
.line	0	loadk        r31  k304 ; k304 = 227
.line	0	loadk        r32  k305 ; k305 = 96
.line	0	loadk        r33  k306 ; k306 = 187
.line	0	loadk        r34  k307 ; k307 = 207
.line	0	loadk        r35  k308 ; k308 = 22
.line	0	loadk        r36  k309 ; k309 = 2
.line	0	loadk        r37  k310 ; k310 = 226
.line	0	loadk        r38  k281 ; k281 = 156
.line	0	loadk        r39  k311 ; k311 = 58
.line	0	loadk        r40  k312 ; k312 = 21
.line	0	loadk        r41  k313 ; k313 = 202
.line	0	loadk        r42  k314 ; k314 = 170
.line	0	loadk        r43  k315 ; k315 = 101
.line	0	loadk        r44  k316 ; k316 = 209
.line	0	loadk        r45  k317 ; k317 = 199
.line	0	loadk        r46  k318 ; k318 = 94
.line	0	loadk        r47  k272 ; k272 = 142
.line	0	loadk        r48  k319 ; k319 = 82
.line	0	loadk        r49  k320 ; k320 = 77
.line	0	loadk        r50  k321 ; k321 = 253
.line	0	loadk        r51  k322 ; k322 = 74
.line	0	loadk        r52  k323 ; k323 = 48
.line	0	loadk        r53  k324 ; k324 = 154
.line	0	loadk        r54  k325 ; k325 = 141
.line	0	loadk        r55  k326 ; k326 = 40
.line	0	loadk        r56  k301 ; k301 = 98
.line	0	loadk        r57  k292 ; k292 = 172
.line	0	loadk        r58  k327 ; k327 = 128
.line	0	loadk        r59  k328 ; k328 = 99
.line	0	loadk        r60  k317 ; k317 = 199
.line	0	loadk        r61  k329 ; k329 = 205
.line	0	loadk        r62  k330 ; k330 = 78
.line	0	loadk        r63  k331 ; k331 = 254
.line	0	loadk        r64  k332 ; k332 = 20
.line	0	loadk        r65  k333 ; k333 = 4
.line	0	loadk        r66  k271 ; k271 = 177
.line	0	loadk        r67  k268 ; k268 = 118
.line	0	loadk        r68  k330 ; k330 = 78
.line	0	call         r28    41     2
.line	0	move         r29    r1
.line	0	loadk        r30  k323 ; k323 = 48
.line	0	loadk        r31  k334 ; k334 = 68
.line	0	loadk        r32  k335 ; k335 = 195
.line	0	loadk        r33  k336 ; k336 = 119
.line	0	loadk        r34  k337 ; k337 = 139
.line	0	loadk        r35  k338 ; k338 = 245
.line	0	loadk        r36  k326 ; k326 = 40
.line	0	loadk        r37  k339 ; k339 = 95
.line	0	loadk        r38  k296 ; k296 = 185
.line	0	loadk        r39  k340 ; k340 = 223
.line	0	loadk        r40  k341 ; k341 = 60
.line	0	loadk        r41  k312 ; k312 = 21
.line	0	loadk        r42  k342 ; k342 = 163
.line	0	loadk        r43  k343 ; k343 = 235
.line	0	loadk        r44  k326 ; k326 = 40
.line	0	call         r29    16     0
.line	0	setlist      r26     0     1
.line	0	call         r25     2     2
.line	0	loadk        r26  k265 ; k265 = "table"
.line	0	gettabup     r26    u0   r26
.line	0	loadk        r27  k266 ; k266 = "concat"
.line	0	gettable     r26   r26   r27
.line	0	newtable     r27     2     0
.line	0	move         r28    r1
.line	0	loadk        r29  k267 ; k267 = 108
.line	0	loadk        r30  k268 ; k268 = 118
.line	0	loadk        r31  k269 ; k269 = 203
.line	0	loadk        r32  k270 ; k270 = 110
.line	0	loadk        r33  k271 ; k271 = 177
.line	0	loadk        r34  k272 ; k272 = 142
.line	0	loadk        r35  k273 ; k273 = 27
.line	0	loadk        r36  k274 ; k274 = 83
.line	0	loadk        r37  k275 ; k275 = 166
.line	0	loadk        r38  k178 ; k178 = 131
.line	0	loadk        r39  k276 ; k276 = 67
.line	0	loadk        r40  k277 ; k277 = 13
.line	0	loadk        r41  k275 ; k275 = 166
.line	0	loadk        r42  k278 ; k278 = 238
.line	0	loadk        r43  k279 ; k279 = 32
.line	0	loadk        r44  k280 ; k280 = 136
.line	0	loadk        r45  k281 ; k281 = 156
.line	0	loadk        r46  k282 ; k282 = 64
.line	0	loadk        r47  k283 ; k283 = 168
.line	0	loadk        r48  k284 ; k284 = 71
.line	0	loadk        r49  k285 ; k285 = 87
.line	0	loadk        r50  k286 ; k286 = 190
.line	0	loadk        r51  k267 ; k267 = 108
.line	0	loadk        r52  k287 ; k287 = 79
.line	0	loadk        r53  k288 ; k288 = 234
.line	0	loadk        r54  k289 ; k289 = 232
.line	0	loadk        r55  k290 ; k290 = 123
.line	0	loadk        r56  k291 ; k291 = 56
.line	0	loadk        r57  k278 ; k278 = 238
.line	0	loadk        r58  k292 ; k292 = 172
.line	0	loadk        r59  k293 ; k293 = 73
.line	0	loadk        r60  k269 ; k269 = 203
.line	0	loadk        r61  k294 ; k294 = 204
.line	0	loadk        r62  k295 ; k295 = 127
.line	0	loadk        r63  k296 ; k296 = 185
.line	0	loadk        r64  k297 ; k297 = 12
.line	0	loadk        r65  k298 ; k298 = 113
.line	0	loadk        r66  k299 ; k299 = 236
.line	0	loadk        r67  k300 ; k300 = 70
.line	0	loadk        r68  k301 ; k301 = 98
.line	0	call         r28    41     2
.line	0	move         r29    r1
.line	0	loadk        r30  k302 ; k302 = 38
.line	0	loadk        r31  k303 ; k303 = 30
.line	0	loadk        r32  k304 ; k304 = 227
.line	0	loadk        r33  k305 ; k305 = 96
.line	0	loadk        r34  k306 ; k306 = 187
.line	0	loadk        r35  k307 ; k307 = 207
.line	0	loadk        r36  k308 ; k308 = 22
.line	0	loadk        r37  k309 ; k309 = 2
.line	0	loadk        r38  k310 ; k310 = 226
.line	0	loadk        r39  k281 ; k281 = 156
.line	0	loadk        r40  k311 ; k311 = 58
.line	0	loadk        r41  k312 ; k312 = 21
.line	0	loadk        r42  k313 ; k313 = 202
.line	0	loadk        r43  k314 ; k314 = 170
.line	0	loadk        r44  k315 ; k315 = 101
.line	0	loadk        r45  k316 ; k316 = 209
.line	0	loadk        r46  k317 ; k317 = 199
.line	0	loadk        r47  k318 ; k318 = 94
.line	0	loadk        r48  k272 ; k272 = 142
.line	0	loadk        r49  k319 ; k319 = 82
.line	0	loadk        r50  k320 ; k320 = 77
.line	0	loadk        r51  k321 ; k321 = 253
.line	0	loadk        r52  k322 ; k322 = 74
.line	0	loadk        r53  k344 ; k344 = 53
.line	0	loadk        r54  k324 ; k324 = 154
.line	0	loadk        r55  k325 ; k325 = 141
.line	0	loadk        r56  k326 ; k326 = 40
.line	0	loadk        r57  k301 ; k301 = 98
.line	0	loadk        r58  k292 ; k292 = 172
.line	0	loadk        r59  k327 ; k327 = 128
.line	0	loadk        r60  k328 ; k328 = 99
.line	0	loadk        r61  k317 ; k317 = 199
.line	0	loadk        r62  k329 ; k329 = 205
.line	0	loadk        r63  k330 ; k330 = 78
.line	0	loadk        r64  k331 ; k331 = 254
.line	0	loadk        r65  k332 ; k332 = 20
.line	0	loadk        r66  k333 ; k333 = 4
.line	0	loadk        r67  k271 ; k271 = 177
.line	0	loadk        r68  k268 ; k268 = 118
.line	0	loadk        r69  k330 ; k330 = 78
.line	0	call         r29    41     2
.line	0	move         r30    r1
.line	0	loadk        r31  k323 ; k323 = 48
.line	0	loadk        r32  k334 ; k334 = 68
.line	0	loadk        r33  k335 ; k335 = 195
.line	0	loadk        r34  k336 ; k336 = 119
.line	0	loadk        r35  k337 ; k337 = 139
.line	0	loadk        r36  k338 ; k338 = 245
.line	0	loadk        r37  k326 ; k326 = 40
.line	0	loadk        r38  k339 ; k339 = 95
.line	0	loadk        r39  k296 ; k296 = 185
.line	0	loadk        r40  k340 ; k340 = 223
.line	0	loadk        r41  k345 ; k345 = 57
.line	0	loadk        r42  k312 ; k312 = 21
.line	0	loadk        r43  k342 ; k342 = 163
.line	0	loadk        r44  k343 ; k343 = 235
.line	0	loadk        r45  k326 ; k326 = 40
.line	0	call         r30    16     0
.line	0	setlist      r27     0     1
.line	0	call         r26     2     2
.line	0	loadk        r27  k346 ; k346 = "GetXSuitTailButtonSt" (truncated)
.line	0	closure      r28   f50
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k347 ; k347 = "RefreshXSuitTailRedP" (truncated)
.line	0	closure      r28   f51
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k348 ; k348 = "ApplyXSuitTailButton" (truncated)
.line	0	closure      r28   f52
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k349 ; k349 = "GetAvatarFormState"
.line	0	closure      r28   f53
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k350 ; k350 = "GetAvatarFormIcon"
.line	0	closure      r28   f54
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k351 ; k351 = "RefreshChangeAvatarF" (truncated)
.line	0	closure      r28   f55
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k352 ; k352 = "TickChangeAvatarForm" (truncated)
.line	0	closure      r28   f56
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k353 ; k353 = "RefreshTransformButt" (truncated)
.line	0	closure      r28   f57
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k354 ; k354 = "TickChangeDragonForm" (truncated)
.line	0	closure      r28   f58
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k355 ; k355 = "RefreshSelfieButton"
.line	0	closure      r28   f59
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k356 ; k356 = "CheckIsSpecialPet"
.line	0	closure      r28   f60
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k357 ; k357 = "RefreshPetButton"
.line	0	closure      r28   f61
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k358 ; k358 = "OnButtonChangeAvatar" (truncated)
.line	0	closure      r28   f62
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k359 ; k359 = "OnButtonButton_Trans" (truncated)
.line	0	closure      r28   f63
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k360 ; k360 = "OnButton_SelfieClick"
.line	0	closure      r28   f64
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k361 ; k361 = "OnButtonPetFeature"
.line	0	closure      r28   f65
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k362 ; k362 = "CanShowXSuitEmote"
.line	0	closure      r28   f66
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k363 ; k363 = "RefreshXSuitEmoteBut" (truncated)
.line	0	closure      r28   f67
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k364 ; k364 = "GetBornIslandAction"
.line	0	closure      r28   f68
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k365 ; k365 = "OnButtonXSuitEmote"
.line	0	closure      r28   f69
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k366 ; k366 = "ChangeAvatarForm"
.line	0	closure      r28   f70
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k367 ; k367 = "OnDestroy"
.line	0	closure      r28   f71
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k368 ; k368 = "RefreshCollectionLis" (truncated)
.line	0	closure      r28   f72
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k369 ; k369 = "RefreshPetInfo"
.line	0	closure      r28   f73
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k370 ; k370 = "GetCurPet"
.line	0	closure      r28   f74
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k371 ; k371 = "GetShowMyPet"
.line	0	closure      r28   f75
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k372 ; k372 = "IsSocialIsland"
.line	0	closure      r28   f76
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k373 ; k373 = "IsMainCity"
.line	0	closure      r28   f77
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k374 ; k374 = "IsAvatarRequirementM" (truncated)
.line	0	closure      r28   f78
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k375 ; k375 = "RefreshSwitchButtonS" (truncated)
.line	0	closure      r28   f79
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k376 ; k376 = "OnButtonSubTypeSwitc" (truncated)
.line	0	closure      r28   f80
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k377 ; k377 = "RefreshFlauntList"
.line	0	closure      r28   f81
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k378 ; k378 = "RefreshFlaunt"
.line	0	closure      r28   f82
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k379 ; k379 = "OnCardCollectionShow" (truncated)
.line	0	closure      r28   f83
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k380 ; k380 = "TryToPlayFlaunt"
.line	0	closure      r28   f84
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k381 ; k381 = "TryPlayPetExhibitAct" (truncated)
.line	0	closure      r28   f85
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k382 ; k382 = "RefreshCDInternal"
.line	0	closure      r28   f86
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k383 ; k383 = "NeedHidePetExpressio" (truncated)
.line	0	closure      r28   f87
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k384 ; k384 = "OnButtonRobotClick"
.line	0	closure      r28   f88
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k385 ; k385 = "RefreshMiniTvExpress" (truncated)
.line	0	closure      r28   f89
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k386 ; k386 = "RefreshMiniTvShowSwi" (truncated)
.line	0	closure      r28   f90
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k387 ; k387 = "GetMiniTvType"
.line	0	closure      r28   f91
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k388 ; k388 = "PrepareMiniTvExpress" (truncated)
.line	0	closure      r28   f92
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k389 ; k389 = "TryToPlayMiniTvExpre" (truncated)
.line	0	closure      r28   f93
.line	0	settable     r22   r27   r28
.line	0	loadk        r27  k390 ; k390 = "require"
.line	0	gettabup     r27    u0   r27
.line	0	move         r28    r1
.line	0	loadk        r29  k391 ; k391 = 32
.line	0	loadk        r30  k392 ; k392 = 93
.line	0	loadk        r31  k393 ; k393 = 203
.line	0	loadk        r32  k394 ; k394 = 112
.line	0	loadk        r33  k395 ; k395 = 167
.line	0	call         r28     6     2
.line	0	call         r27     2     2
.line	0	loadk        r28  k390 ; k390 = "require"
.line	0	gettabup     r28    u0   r28
.line	0	move         r29    r1
.line	0	loadk        r30  k391 ; k391 = 32
.line	0	loadk        r31  k396 ; k396 = 94
.line	0	loadk        r32  k397 ; k397 = 199
.line	0	loadk        r33  k398 ; k398 = 110
.line	0	loadk        r34  k399 ; k399 = 187
.line	0	loadk        r35  k400 ; k400 = 207
.line	0	loadk        r36  k401 ; k401 = 103
.line	0	loadk        r37  k402 ; k402 = 82
.line	0	loadk        r38  k403 ; k403 = 176
.line	0	loadk        r39  k404 ; k404 = 192
.line	0	loadk        r40  k405 ; k405 = 111
.line	0	loadk        r41  k406 ; k406 = 45
.line	0	loadk        r42  k407 ; k407 = 243
.line	0	loadk        r43  k408 ; k408 = 173
.line	0	loadk        r44  k409 ; k409 = 117
.line	0	loadk        r45  k410 ; k410 = 231
.line	0	loadk        r46  k411 ; k411 = 208
.line	0	loadk        r47  k398 ; k398 = 110
.line	0	loadk        r48  k412 ; k412 = 180
.line	0	loadk        r49  k413 ; k413 = 71
.line	0	loadk        r50  k414 ; k414 = 69
.line	0	loadk        r51  k415 ; k415 = 248
.line	0	loadk        r52  k416 ; k416 = 87
.line	0	loadk        r53  k417 ; k417 = 99
.line	0	loadk        r54  k418 ; k418 = 183
.line	0	call         r29    26     2
.line	0	call         r28     2     2
.line	0	move         r29   r27
.line	0	move         r30   r28
.line	0	loadnil      r31     0
.line	0	move         r32   r22
.line	0	tailcall     r29     4
.line	0	return       r29     0
.line	0	return        r0     1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	gettabup      r2    u0  k120 ; k120 = 115
.line	0	return        r0     1

.function	main/f0

.source	null
.linedefined	2
.lastlinedefined	9
.numparams	0
.is_vararg	1
.maxstacksize	9

.upvalue	"_ENV"	0	false
.upvalue	"U1"	0	true

.constant	k0	1
.constant	k1	"string"
.constant	k2	"char"
.constant	k3	16
.constant	k4	31
.constant	k5	7
.constant	k6	256
.constant	k7	"table"
.constant	k8	"concat"

.line	2	newtable      r0     0     0
.line	2	vararg        r1     0
.line	2	setlist       r0     0     1
.line	2	newtable      r1     0     0
.line	2	loadk         r2    k0 ; k0 = 1
.line	2	len           r3    r0
.line	2	loadk         r4    k0 ; k0 = 1
.line	2	move          r0    r0
.line	2	gettabup      r6    u0    k1 ; k1 = "string"
.line	2	gettable      r6    r6    k2 ; k2 = "char"
.line	2	gettable      r7    r0    r5
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mod           r8    r8    k3 ; k3 = 16
.line	2	add           r8    r8    k0 ; k0 = 1
.line	2	gettabup      r8    u1    r8
.line	2	bxor          r7    r7    r8
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mul           r8    r8    k4 ; k4 = 31
.line	2	add           r8    r8    k5 ; k5 = 7
.line	2	mod           r8    r8    k6 ; k6 = 256
.line	2	bxor          r7    r7    r8
.line	2	mod           r7    r7    k6 ; k6 = 256
.line	2	call          r6     2     2
.line	2	settable      r1    r5    r6
.line	2	move          r0    r0
.line	2	gettabup      r2    u0    k7 ; k7 = "table"
.line	2	gettable      r2    r2    k8 ; k8 = "concat"
.line	2	move          r3    r1
.line	2	tailcall      r2     2
.line	2	return        r2     0
.line	2	return        r0     1
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	return        r0     1

.function	main/f1

.source	null
.linedefined	70
.lastlinedefined	94
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false
.upvalue	"U1"	23	true

.constant	k0	"ItemDefineIDTemp"
.constant	k1	"FItemDefineIDDefault"
.constant	k2	"CurrentIndex"
.constant	k3	0
.constant	k4	"ItemInTheRing"
.constant	k5	"ClothBackpackItem"
.constant	k6	"AllLimitEmoteList"
.constant	k7	"ItemIDToImagePathMap"
.constant	k8	"LoadImageHandleTable"
.constant	k9	"StartPressPoint"
.constant	k10	"FVector2D"
.constant	k11	"bHasInitExpression"
.constant	k12	false
.constant	k13	"CurrentShowState"
.constant	k14	"None"
.constant	k15	"IndexToPetExpression"
.constant	k16	"uBubbleIDList"
.constant	k17	"CurEmotePage"
.constant	k18	"CurrentRecoverLayout"
.constant	k19	"CollectionList"
.constant	k20	"FlauntList"
.constant	k21	"PetExhibitIndex"
.constant	k22	-1
.constant	k23	"RefreshCDInfoTimer"
.constant	k24	nil
.constant	k25	"MiniTvExpressionList"
.constant	k26	"IndexToMiniTvExpression"
.constant	k27	"bShowMiniTv"
.constant	k28	"bInitMiniTvExpressionList"
.constant	k29	"_nWeaponShowEmoteID"

.line	70	gettabup      r1    u0    k1 ; k1 = "FItemDefineIDDefault"
.line	70	call          r1     1     2
.line	70	settable      r0    k0    r1 ; k0 = "ItemDefineIDTemp"
.line	70	settable      r0    k2    k3 ; k3 = 0
.line	70	newtable      r1     0     0
.line	70	settable      r0    k4    r1 ; k4 = "ItemInTheRing"
.line	70	newtable      r1     0     0
.line	70	settable      r0    k5    r1 ; k5 = "ClothBackpackItem"
.line	70	newtable      r1     0     0
.line	70	settable      r0    k6    r1 ; k6 = "AllLimitEmoteList"
.line	70	newtable      r1     0     0
.line	70	settable      r0    k7    r1 ; k7 = "ItemIDToImagePathMap"
.line	70	newtable      r1     0     0
.line	70	settable      r0    k8    r1 ; k8 = "LoadImageHandleTable"
.line	70	gettabup      r1    u0   k10 ; k10 = "FVector2D"
.line	70	loadk         r2    k3 ; k3 = 0
.line	70	loadk         r3    k3 ; k3 = 0
.line	70	call          r1     3     2
.line	70	settable      r0    k9    r1 ; k9 = "StartPressPoint"
.line	70	settable      r0   k11   k12 ; k12 = false
.line	70	gettabup      r1    u1   k14 ; k14 = "None"
.line	70	settable      r0   k13    r1 ; k13 = "CurrentShowState"
.line	70	newtable      r1     0     0
.line	70	settable      r0   k15    r1 ; k15 = "IndexToPetExpression"
.line	70	newtable      r1     0     0
.line	70	settable      r0   k16    r1 ; k16 = "uBubbleIDList"
.line	70	settable      r0   k17    k3 ; k3 = 0
.line	70	newtable      r1     0     0
.line	70	settable      r0   k18    r1 ; k18 = "CurrentRecoverLayout"
.line	70	newtable      r1     0     0
.line	70	settable      r0   k19    r1 ; k19 = "CollectionList"
.line	70	newtable      r1     0     0
.line	70	settable      r0   k20    r1 ; k20 = "FlauntList"
.line	70	settable      r0   k21   k22 ; k22 = -1
.line	70	settable      r0   k23   k24 ; k24 = nil
.line	70	newtable      r1     0     0
.line	70	settable      r0   k25    r1 ; k25 = "MiniTvExpressionList"
.line	70	newtable      r1     0     0
.line	70	settable      r0   k26    r1 ; k26 = "IndexToMiniTvExpress" (truncated)
.line	70	settable      r0   k27   k12 ; k12 = false
.line	70	settable      r0   k28   k12 ; k12 = false
.line	70	settable      r0   k29    k3 ; k3 = 0
.line	70	return        r0     1
.line	70	move          r0    r0
.line	70	return        r0     1

.function	main/f2

.source	null
.linedefined	96
.lastlinedefined	106
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	22	true

.constant	k0	"ChangeAvatarFormCDTimer"
.constant	k1	"RemoveTimer"
.constant	k2	nil
.constant	k3	"RefreshCDInfoTimer"
.constant	k4	"__super"
.constant	k5	"Dispose"

.line	96	gettable      r1    r0    k0 ; k0 = "ChangeAvatarFormCDTi" (truncated)
.line	96	test          r1     0
.line	96	jmp            0    l8
.line	96	self          r1    r0    k1 ; k1 = "RemoveTimer"
.line	96	gettable      r3    r0    k0 ; k0 = "ChangeAvatarFormCDTi" (truncated)
.line	96	call          r1     3     1
.line	96	settable      r0    k0    k2 ; k2 = nil
.label	l8
.line	96	gettable      r1    r0    k3 ; k3 = "RefreshCDInfoTimer"
.line	96	test          r1     0
.line	96	jmp            0   l15
.line	96	self          r1    r0    k1 ; k1 = "RemoveTimer"
.line	96	gettable      r3    r0    k3 ; k3 = "RefreshCDInfoTimer"
.line	96	call          r1     3     1
.line	96	settable      r0    k3    k2 ; k2 = nil
.label	l15
.line	96	gettabup      r1    u0    k4 ; k4 = "__super"
.line	96	gettable      r1    r1    k5 ; k5 = "Dispose"
.line	96	move          r2    r0
.line	96	call          r1     2     1
.line	96	return        r0     1
.line	96	move          r0    r0
.line	96	move          r0    r0
.line	96	return        r0     1

.function	main/f3

.source	null
.linedefined	108
.lastlinedefined	123
.numparams	2
.is_vararg	0
.maxstacksize	42

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	20	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	18
.constant	k3	68
.constant	k4	195
.constant	k5	96
.constant	k6	191
.constant	k7	228
.constant	k8	49
.constant	k9	70
.constant	k10	167
.constant	k11	201
.constant	k12	121
.constant	k13	57
.constant	k14	251
.constant	k15	182
.constant	k16	126
.constant	k17	130
.constant	k18	224
.constant	k19	100
.constant	k20	174
.constant	k21	112
.constant	k22	69
.constant	k23	255
.constant	k24	106
.constant	k25	110
.constant	k26	170
.constant	k27	203
.constant	k28	73
.constant	k29	63
.constant	k30	238
.constant	k31	175
.constant	k32	105
.constant	k33	205
.constant	k34	225
.constant	k35	190
.constant	k36	87
.constant	k37	91
.constant	k38	239
.constant	k39	"CurrentRecoverLayout"
.constant	k40	"Button_Selfie"
.constant	k41	nil
.constant	k42	"RenderTransform"
.constant	k43	"Translation"
.constant	k44	"clone"
.constant	k45	"Button_CheckGun"
.constant	k46	"SetRenderTranslation"

.line	108	gettabup      r2    u0    k0 ; k0 = "print"
.line	108	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	108	test          r3     0
.line	108	jmp            0   l45
.line	108	getupval      r3    u1
.line	108	loadk         r4    k2 ; k2 = 18
.line	108	loadk         r5    k3 ; k3 = 68
.line	108	loadk         r6    k4 ; k4 = 195
.line	108	loadk         r7    k5 ; k5 = 96
.line	108	loadk         r8    k6 ; k6 = 191
.line	108	loadk         r9    k7 ; k7 = 228
.line	108	loadk        r10    k8 ; k8 = 49
.line	108	loadk        r11    k9 ; k9 = 70
.line	108	loadk        r12   k10 ; k10 = 167
.line	108	loadk        r13   k11 ; k11 = 201
.line	108	loadk        r14   k12 ; k12 = 121
.line	108	loadk        r15   k13 ; k13 = 57
.line	108	loadk        r16   k14 ; k14 = 251
.line	108	loadk        r17   k15 ; k15 = 182
.line	108	loadk        r18   k16 ; k16 = 126
.line	108	loadk        r19   k17 ; k17 = 130
.line	108	loadk        r20   k18 ; k18 = 224
.line	108	loadk        r21   k19 ; k19 = 100
.line	108	loadk        r22   k20 ; k20 = 174
.line	108	loadk        r23   k21 ; k21 = 112
.line	108	loadk        r24   k22 ; k22 = 69
.line	108	loadk        r25   k23 ; k23 = 255
.line	108	loadk        r26   k24 ; k24 = 106
.line	108	loadk        r27   k25 ; k25 = 110
.line	108	loadk        r28   k26 ; k26 = 170
.line	108	loadk        r29   k27 ; k27 = 203
.line	108	loadk        r30   k28 ; k28 = 73
.line	108	loadk        r31   k29 ; k29 = 63
.line	108	loadk        r32   k30 ; k30 = 238
.line	108	loadk        r33   k31 ; k31 = 175
.line	108	loadk        r34   k32 ; k32 = 105
.line	108	loadk        r35   k33 ; k33 = 205
.line	108	loadk        r36   k34 ; k34 = 225
.line	108	loadk        r37   k19 ; k19 = 100
.line	108	loadk        r38   k35 ; k35 = 190
.line	108	loadk        r39   k36 ; k36 = 87
.line	108	loadk        r40   k37 ; k37 = 91
.line	108	loadk        r41   k38 ; k38 = 239
.line	108	call          r3    39     2
.label	l45
.line	108	move          r4    r1
.line	108	call          r2     3     1
.line	108	test          r1     1
.line	108	jmp            0   l80
.line	108	gettable      r2    r0   k39 ; k39 = "CurrentRecoverLayout"
.line	108	gettable      r2    r2   k40 ; k40 = "Button_Selfie"
.line	108	eq             0    r2   k41 ; k41 = nil
.line	108	jmp            0   l60
.line	108	gettable      r2    r0   k39 ; k39 = "CurrentRecoverLayout"
.line	108	gettable      r3    r0   k40 ; k40 = "Button_Selfie"
.line	108	gettable      r3    r3   k42 ; k42 = "RenderTransform"
.line	108	gettable      r3    r3   k43 ; k43 = "Translation"
.line	108	self          r3    r3   k44 ; k44 = "clone"
.line	108	call          r3     2     2
.line	108	settable      r2   k40    r3 ; k40 = "Button_Selfie"
.label	l60
.line	108	gettable      r2    r0   k39 ; k39 = "CurrentRecoverLayout"
.line	108	gettable      r2    r2   k45 ; k45 = "Button_CheckGun"
.line	108	eq             0    r2   k41 ; k41 = nil
.line	108	jmp            0   l71
.line	108	gettable      r2    r0   k39 ; k39 = "CurrentRecoverLayout"
.line	108	gettable      r3    r0   k45 ; k45 = "Button_CheckGun"
.line	108	gettable      r3    r3   k42 ; k42 = "RenderTransform"
.line	108	gettable      r3    r3   k43 ; k43 = "Translation"
.line	108	self          r3    r3   k44 ; k44 = "clone"
.line	108	call          r3     2     2
.line	108	settable      r2   k45    r3 ; k45 = "Button_CheckGun"
.label	l71
.line	108	gettable      r2    r0   k40 ; k40 = "Button_Selfie"
.line	108	self          r2    r2   k46 ; k46 = "SetRenderTranslation"
.line	108	getupval      r4    u2
.line	108	call          r2     3     1
.line	108	gettable      r2    r0   k45 ; k45 = "Button_CheckGun"
.line	108	self          r2    r2   k46 ; k46 = "SetRenderTranslation"
.line	108	getupval      r4    u2
.line	108	call          r2     3     1
.line	108	jmp            0   l94
.label	l80
.line	108	gettable      r2    r0   k39 ; k39 = "CurrentRecoverLayout"
.line	108	gettable      r2    r2   k40 ; k40 = "Button_Selfie"
.line	108	test          r2     0
.line	108	jmp            0   l94
.line	108	gettable      r2    r0   k40 ; k40 = "Button_Selfie"
.line	108	self          r2    r2   k46 ; k46 = "SetRenderTranslation"
.line	108	gettable      r4    r0   k39 ; k39 = "CurrentRecoverLayout"
.line	108	gettable      r4    r4   k40 ; k40 = "Button_Selfie"
.line	108	call          r2     3     1
.line	108	gettable      r2    r0   k45 ; k45 = "Button_CheckGun"
.line	108	self          r2    r2   k46 ; k46 = "SetRenderTranslation"
.line	108	gettable      r4    r0   k39 ; k39 = "CurrentRecoverLayout"
.line	108	gettable      r4    r4   k45 ; k45 = "Button_CheckGun"
.line	108	call          r2     3     1
.label	l94
.line	108	return        r0     1
.line	108	move          r0    r0
.line	108	move          r0    r0
.line	108	return        r0     1

.function	main/f4

.source	null
.linedefined	125
.lastlinedefined	131
.numparams	3
.is_vararg	0
.maxstacksize	5

.constant	k0	"IsClothDirty"
.constant	k1	"RefreshEmote"
.constant	k2	false

.line	125	gettable      r3    r0    k0 ; k0 = "IsClothDirty"
.line	125	test          r3     1
.line	125	jmp            0    l5
.line	125	return        r0     1
.label	l5
.line	125	self          r3    r0    k1 ; k1 = "RefreshEmote"
.line	125	call          r3     2     1
.line	125	settable      r0    k0    k2 ; k2 = false
.line	125	return        r0     1
.line	125	move          r0    r0
.line	125	return        r0     1

.function	main/f5

.source	null
.linedefined	133
.lastlinedefined	135
.numparams	1
.is_vararg	0
.maxstacksize	3

.constant	k0	"InitExpression"

.line	133	self          r1    r0    k0 ; k0 = "InitExpression"
.line	133	call          r1     2     1
.line	133	return        r0     1
.line	133	move          r0    r0
.line	133	move          r0    r0
.line	133	move          r0    r0
.line	133	move          r0    r0
.line	133	return        r0     1

.function	main/f6

.source	null
.linedefined	137
.lastlinedefined	194
.numparams	1
.is_vararg	0
.maxstacksize	42

.upvalue	"_ENV"	11	true
.upvalue	"U1"	10	true
.upvalue	"U2"	8	true
.upvalue	"U3"	0	false
.upvalue	"U4"	1	true

.constant	k0	"bHasInitExpression"
.constant	k1	true
.constant	k2	"MakeWidgetArray"
.constant	k3	"GetEmoteImagePalthMap"
.constant	k4	"ButtonLength"
.constant	k5	90
.constant	k6	"BorderEX_Ring"
.constant	k7	"GetCachedGeometry"
.constant	k8	"RingCenter"
.constant	k9	"GetAbsolutePosition"
.constant	k10	"SlotAsCanvasSlot"
.constant	k11	"GetSize"
.constant	k12	"RingLength"
.constant	k13	"X"
.constant	k14	"InnerCircleRadius"
.constant	k15	"FTrunc"
.constant	k16	"Y"
.constant	k17	2
.constant	k18	"SectorButtonDegree"
.constant	k19	"EmoteImageArray"
.constant	k20	"Num"
.constant	k21	360
.constant	k22	"SectorButtonHalfDegree"
.constant	k23	0.5
.constant	k24	"BackpackReceive"
.constant	k25	"slua_GameFrontendHUD"
.constant	k26	"GetPlayerController"
.constant	k27	"slua"
.constant	k28	"isValid"
.constant	k29	"GetPlayerCharacterSafety"
.constant	k30	"GetWeaponManager"
.constant	k31	"AddControlEvent"
.constant	k32	0
.constant	k33	89
.constant	k34	203
.constant	k35	109
.constant	k36	179
.constant	k37	196
.constant	k38	10
.constant	k39	67
.constant	k40	167
.constant	k41	222
.constant	k42	111
.constant	k43	36
.constant	k44	230
.constant	k45	140
.constant	k46	99
.constant	k47	209
.constant	k48	221
.constant	k49	102
.constant	k50	141
.constant	k51	86
.constant	k52	69
.constant	k53	225
.constant	k54	104
.constant	k55	129
.constant	k56	217
.constant	k57	118
.constant	k58	63
.constant	k59	229
.constant	k60	168
.constant	k61	116
.constant	k62	205
.constant	k63	"HandleChangeCurrentUsingWeapon"
.constant	k64	"Button_CheckGun"
.constant	k65	12
.constant	k66	95
.constant	k67	233
.constant	k68	189
.constant	k69	194
.constant	k70	34
.constant	k71	83
.constant	k72	177
.constant	k73	"OnButtonCheckGun"
.constant	k74	"Button_ChangeAvatarForm"
.constant	k75	"OnButtonChangeAvatarForm"
.constant	k76	"Button_Transfiguration"
.constant	k77	"OnButtonButton_Transfiguration"
.constant	k78	"Button_Selfie"
.constant	k79	"OnButton_SelfieClick"
.constant	k80	"Button_PetFeature"
.constant	k81	"OnButtonPetFeature"
.constant	k82	"Button_XSuit"
.constant	k83	"OnButtonXSuitEmote"
.constant	k84	"Button_Bubble_01"
.constant	k85	"OnButtonBubble"
.constant	k86	"Button_Bubble_02"
.constant	k87	"Button_EmoteOrPet_01"
.constant	k88	"OnButtonEmoteOrPet"
.constant	k89	"Button_EmoteOrPet_02"
.constant	k90	"Button_CollectionOrFlaunt_01"
.constant	k91	"OnButtonCollectionOrFlaunt"
.constant	k92	"Button_CollectionOrFlaunt_02"
.constant	k93	"Button_ShowPet"
.constant	k94	"OnButtonShowPet"
.constant	k95	"Button_Left"
.constant	k96	"OnButtonLeft"
.constant	k97	"Button_Right"
.constant	k98	"OnButtonRight"
.constant	k99	"Button_SubTypeSwitch"
.constant	k100	"OnButtonSubTypeSwitchClick"
.constant	k101	"Button_Robot_01"
.constant	k102	"OnButtonRobotClick"
.constant	k103	"Button_Robot_02"
.constant	k104	"AddSettingOptionEvent"
.constant	k105	65
.constant	k106	207
.constant	k107	153
.constant	k108	216
.constant	k109	25
.constant	k110	161
.constant	k111	234
.constant	k112	26
.constant	k113	"WidgetSwitcher_CollectionOrFlaunt"
.constant	k114	"SetActiveWidgetIndex"
.constant	k115	1
.constant	k116	"AddCommonEvent"
.constant	k117	"EVENTTYPE_PLAYEREVENT_AVATAR"
.constant	k118	L"EVENTID_LOCAL_PLAYEREVENT_AVATAR_ALL_MESH_LOADED"
.constant	k119	"OnAvatarAllMeshLoaded"
.constant	k120	"EVENTTYPE_INGAME"
.constant	k121	"EVENTID_INGAME_WEAPON_SHOW_CHANGE"
.constant	k122	"OnCustomWeaponShowChange"
.constant	k123	"EVENTTYPE_CARD_COLLECTION"
.constant	k124	"EVENTID_CARDCOLLECTION_FIND_SERIES_RSP"
.constant	k125	"OnCardCollectionShowInfoRsp"

.line	137	gettable      r1    r0    k0 ; k0 = "bHasInitExpression"
.line	137	test          r1     0
.line	137	jmp            0    l5
.line	137	return        r0     1
.label	l5
.line	137	settable      r0    k0    k1 ; k1 = true
.line	137	self          r1    r0    k2 ; k2 = "MakeWidgetArray"
.line	137	call          r1     2     1
.line	137	self          r1    r0    k3 ; k3 = "GetEmoteImagePalthMa" (truncated)
.line	137	call          r1     2     1
.line	137	settable      r0    k4    k5 ; k5 = 90
.line	137	gettable      r1    r0    k6 ; k6 = "BorderEX_Ring"
.line	137	self          r1    r1    k7 ; k7 = "GetCachedGeometry"
.line	137	call          r1     2     2
.line	137	gettabup      r2    u0    k9 ; k9 = "GetAbsolutePosition"
.line	137	move          r3    r1
.line	137	call          r2     2     2
.line	137	settable      r0    k8    r2 ; k8 = "RingCenter"
.line	137	gettabup      r2    u1   k10 ; k10 = "SlotAsCanvasSlot"
.line	137	gettable      r3    r0    k6 ; k6 = "BorderEX_Ring"
.line	137	call          r2     2     2
.line	137	test          r2     0
.line	137	jmp            0   l43
.line	137	self          r3    r2   k11 ; k11 = "GetSize"
.line	137	call          r3     2     2
.line	137	gettable      r4    r3   k13 ; k13 = "X"
.line	137	settable      r0   k12    r4 ; k12 = "RingLength"
.line	137	gettabup      r4    u2   k15 ; k15 = "FTrunc"
.line	137	gettable      r5    r3   k16 ; k16 = "Y"
.line	137	gettable      r6    r0    k4 ; k4 = "ButtonLength"
.line	137	mul           r6    r6   k17 ; k17 = 2
.line	137	sub           r5    r5    r6
.line	137	div           r5    r5   k17 ; k17 = 2
.line	137	call          r4     2     2
.line	137	settable      r0   k14    r4 ; k14 = "InnerCircleRadius"
.line	137	gettable      r4    r0   k19 ; k19 = "EmoteImageArray"
.line	137	self          r4    r4   k20 ; k20 = "Num"
.line	137	call          r4     2     2
.line	137	div           r4   k21    r4 ; k21 = 360
.line	137	settable      r0   k18    r4 ; k18 = "SectorButtonDegree"
.line	137	gettable      r4    r0   k18 ; k18 = "SectorButtonDegree"
.line	137	mul           r4    r4   k23 ; k23 = 0.5
.line	137	settable      r0   k22    r4 ; k22 = "SectorButtonHalfDegr" (truncated)
.label	l43
.line	137	self          r3    r0   k24 ; k24 = "BackpackReceive"
.line	137	call          r3     2     1
.line	137	gettabup      r3    u3   k25 ; k25 = "slua_GameFrontendHUD"
.line	137	self          r3    r3   k26 ; k26 = "GetPlayerController"
.line	137	call          r3     2     2
.line	137	gettabup      r4    u3   k27 ; k27 = "slua"
.line	137	gettable      r4    r4   k28 ; k28 = "isValid"
.line	137	move          r5    r3
.line	137	call          r4     2     2
.line	137	test          r4     0
.line	137	jmp            0  l117
.line	137	gettable      r4    r3   k29 ; k29 = "GetPlayerCharacterSa" (truncated)
.line	137	test          r4     0
.line	137	jmp            0  l117
.line	137	self          r4    r3   k29 ; k29 = "GetPlayerCharacterSa" (truncated)
.line	137	call          r4     2     2
.line	137	test          r4     0
.line	137	jmp            0  l117
.line	137	gettabup      r5    u3   k27 ; k27 = "slua"
.line	137	gettable      r5    r5   k28 ; k28 = "isValid"
.line	137	move          r6    r4
.line	137	call          r5     2     2
.line	137	test          r5     0
.line	137	jmp            0  l117
.line	137	gettable      r5    r4   k30 ; k30 = "GetWeaponManager"
.line	137	test          r5     0
.line	137	jmp            0  l117
.line	137	self          r5    r4   k30 ; k30 = "GetWeaponManager"
.line	137	call          r5     2     2
.line	137	gettabup      r6    u3   k27 ; k27 = "slua"
.line	137	gettable      r6    r6   k28 ; k28 = "isValid"
.line	137	move          r7    r5
.line	137	call          r6     2     2
.line	137	test          r6     0
.line	137	jmp            0  l117
.line	137	self          r6    r0   k31 ; k31 = "AddControlEvent"
.line	137	move          r8    r5
.line	137	getupval      r9    u4
.line	137	loadk        r10   k32 ; k32 = 0
.line	137	loadk        r11   k33 ; k33 = 89
.line	137	loadk        r12   k34 ; k34 = 203
.line	137	loadk        r13   k35 ; k35 = 109
.line	137	loadk        r14   k36 ; k36 = 179
.line	137	loadk        r15   k37 ; k37 = 196
.line	137	loadk        r16   k38 ; k38 = 10
.line	137	loadk        r17   k39 ; k39 = 67
.line	137	loadk        r18   k40 ; k40 = 167
.line	137	loadk        r19   k41 ; k41 = 222
.line	137	loadk        r20   k42 ; k42 = 111
.line	137	loadk        r21   k43 ; k43 = 36
.line	137	loadk        r22   k44 ; k44 = 230
.line	137	loadk        r23   k45 ; k45 = 140
.line	137	loadk        r24   k46 ; k46 = 99
.line	137	loadk        r25   k47 ; k47 = 209
.line	137	loadk        r26   k48 ; k48 = 221
.line	137	loadk        r27   k49 ; k49 = 102
.line	137	loadk        r28   k50 ; k50 = 141
.line	137	loadk        r29   k51 ; k51 = 86
.line	137	loadk        r30   k52 ; k52 = 69
.line	137	loadk        r31   k53 ; k53 = 225
.line	137	loadk        r32   k51 ; k51 = 86
.line	137	loadk        r33   k54 ; k54 = 104
.line	137	loadk        r34   k55 ; k55 = 129
.line	137	loadk        r35   k56 ; k56 = 217
.line	137	loadk        r36   k57 ; k57 = 118
.line	137	loadk        r37   k58 ; k58 = 63
.line	137	loadk        r38   k59 ; k59 = 229
.line	137	loadk        r39   k60 ; k60 = 168
.line	137	loadk        r40   k61 ; k61 = 116
.line	137	loadk        r41   k62 ; k62 = 205
.line	137	call          r9    33     2
.line	137	gettable     r10    r0   k63 ; k63 = "HandleChangeCurrentU" (truncated)
.line	137	move         r11    r0
.line	137	call          r6     6     1
.label	l117
.line	137	self          r4    r0   k31 ; k31 = "AddControlEvent"
.line	137	gettable      r6    r0   k64 ; k64 = "Button_CheckGun"
.line	137	getupval      r7    u4
.line	137	loadk         r8   k65 ; k65 = 12
.line	137	loadk         r9   k66 ; k66 = 95
.line	137	loadk        r10   k67 ; k67 = 233
.line	137	loadk        r11   k42 ; k42 = 111
.line	137	loadk        r12   k68 ; k68 = 189
.line	137	loadk        r13   k69 ; k69 = 194
.line	137	loadk        r14   k70 ; k70 = 34
.line	137	loadk        r15   k71 ; k71 = 83
.line	137	loadk        r16   k72 ; k72 = 177
.line	137	call          r7    10     2
.line	137	gettable      r8    r0   k73 ; k73 = "OnButtonCheckGun"
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0   k31 ; k31 = "AddControlEvent"
.line	137	gettable      r6    r0   k74 ; k74 = "Button_ChangeAvatarF" (truncated)
.line	137	getupval      r7    u4
.line	137	loadk         r8   k65 ; k65 = 12
.line	137	loadk         r9   k66 ; k66 = 95
.line	137	loadk        r10   k67 ; k67 = 233
.line	137	loadk        r11   k42 ; k42 = 111
.line	137	loadk        r12   k68 ; k68 = 189
.line	137	loadk        r13   k69 ; k69 = 194
.line	137	loadk        r14   k70 ; k70 = 34
.line	137	loadk        r15   k71 ; k71 = 83
.line	137	loadk        r16   k72 ; k72 = 177
.line	137	call          r7    10     2
.line	137	gettable      r8    r0   k75 ; k75 = "OnButtonChangeAvatar" (truncated)
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0   k31 ; k31 = "AddControlEvent"
.line	137	gettable      r6    r0   k76 ; k76 = "Button_Transfigurati" (truncated)
.line	137	getupval      r7    u4
.line	137	loadk         r8   k65 ; k65 = 12
.line	137	loadk         r9   k66 ; k66 = 95
.line	137	loadk        r10   k67 ; k67 = 233
.line	137	loadk        r11   k42 ; k42 = 111
.line	137	loadk        r12   k68 ; k68 = 189
.line	137	loadk        r13   k69 ; k69 = 194
.line	137	loadk        r14   k70 ; k70 = 34
.line	137	loadk        r15   k71 ; k71 = 83
.line	137	loadk        r16   k72 ; k72 = 177
.line	137	call          r7    10     2
.line	137	gettable      r8    r0   k77 ; k77 = "OnButtonButton_Trans" (truncated)
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0   k31 ; k31 = "AddControlEvent"
.line	137	gettable      r6    r0   k78 ; k78 = "Button_Selfie"
.line	137	getupval      r7    u4
.line	137	loadk         r8   k65 ; k65 = 12
.line	137	loadk         r9   k66 ; k66 = 95
.line	137	loadk        r10   k67 ; k67 = 233
.line	137	loadk        r11   k42 ; k42 = 111
.line	137	loadk        r12   k68 ; k68 = 189
.line	137	loadk        r13   k69 ; k69 = 194
.line	137	loadk        r14   k70 ; k70 = 34
.line	137	loadk        r15   k71 ; k71 = 83
.line	137	loadk        r16   k72 ; k72 = 177
.line	137	call          r7    10     2
.line	137	gettable      r8    r0   k79 ; k79 = "OnButton_SelfieClick"
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0   k31 ; k31 = "AddControlEvent"
.line	137	gettable      r6    r0   k80 ; k80 = "Button_PetFeature"
.line	137	getupval      r7    u4
.line	137	loadk         r8   k65 ; k65 = 12
.line	137	loadk         r9   k66 ; k66 = 95
.line	137	loadk        r10   k67 ; k67 = 233
.line	137	loadk        r11   k42 ; k42 = 111
.line	137	loadk        r12   k68 ; k68 = 189
.line	137	loadk        r13   k69 ; k69 = 194
.line	137	loadk        r14   k70 ; k70 = 34
.line	137	loadk        r15   k71 ; k71 = 83
.line	137	loadk        r16   k72 ; k72 = 177
.line	137	call          r7    10     2
.line	137	gettable      r8    r0   k81 ; k81 = "OnButtonPetFeature"
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0   k31 ; k31 = "AddControlEvent"
.line	137	gettable      r6    r0   k82 ; k82 = "Button_XSuit"
.line	137	getupval      r7    u4
.line	137	loadk         r8   k65 ; k65 = 12
.line	137	loadk         r9   k66 ; k66 = 95
.line	137	loadk        r10   k67 ; k67 = 233
.line	137	loadk        r11   k42 ; k42 = 111
.line	137	loadk        r12   k68 ; k68 = 189
.line	137	loadk        r13   k69 ; k69 = 194
.line	137	loadk        r14   k70 ; k70 = 34
.line	137	loadk        r15   k71 ; k71 = 83
.line	137	loadk        r16   k72 ; k72 = 177
.line	137	call          r7    10     2
.line	137	gettable      r8    r0   k83 ; k83 = "OnButtonXSuitEmote"
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0   k31 ; k31 = "AddControlEvent"
.line	137	gettable      r6    r0   k84 ; k84 = "Button_Bubble_01"
.line	137	getupval      r7    u4
.line	137	loadk         r8   k65 ; k65 = 12
.line	137	loadk         r9   k66 ; k66 = 95
.line	137	loadk        r10   k67 ; k67 = 233
.line	137	loadk        r11   k42 ; k42 = 111
.line	137	loadk        r12   k68 ; k68 = 189
.line	137	loadk        r13   k69 ; k69 = 194
.line	137	loadk        r14   k70 ; k70 = 34
.line	137	loadk        r15   k71 ; k71 = 83
.line	137	loadk        r16   k72 ; k72 = 177
.line	137	call          r7    10     2
.line	137	gettable      r8    r0   k85 ; k85 = "OnButtonBubble"
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0   k31 ; k31 = "AddControlEvent"
.line	137	gettable      r6    r0   k86 ; k86 = "Button_Bubble_02"
.line	137	getupval      r7    u4
.line	137	loadk         r8   k65 ; k65 = 12
.line	137	loadk         r9   k66 ; k66 = 95
.line	137	loadk        r10   k67 ; k67 = 233
.line	137	loadk        r11   k42 ; k42 = 111
.line	137	loadk        r12   k68 ; k68 = 189
.line	137	loadk        r13   k69 ; k69 = 194
.line	137	loadk        r14   k70 ; k70 = 34
.line	137	loadk        r15   k71 ; k71 = 83
.line	137	loadk        r16   k72 ; k72 = 177
.line	137	call          r7    10     2
.line	137	gettable      r8    r0   k85 ; k85 = "OnButtonBubble"
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0   k31 ; k31 = "AddControlEvent"
.line	137	gettable      r6    r0   k87 ; k87 = "Button_EmoteOrPet_01"
.line	137	getupval      r7    u4
.line	137	loadk         r8   k65 ; k65 = 12
.line	137	loadk         r9   k66 ; k66 = 95
.line	137	loadk        r10   k67 ; k67 = 233
.line	137	loadk        r11   k42 ; k42 = 111
.line	137	loadk        r12   k68 ; k68 = 189
.line	137	loadk        r13   k69 ; k69 = 194
.line	137	loadk        r14   k70 ; k70 = 34
.line	137	loadk        r15   k71 ; k71 = 83
.line	137	loadk        r16   k72 ; k72 = 177
.line	137	call          r7    10     2
.line	137	gettable      r8    r0   k88 ; k88 = "OnButtonEmoteOrPet"
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0   k31 ; k31 = "AddControlEvent"
.line	137	gettable      r6    r0   k89 ; k89 = "Button_EmoteOrPet_02"
.line	137	getupval      r7    u4
.line	137	loadk         r8   k65 ; k65 = 12
.line	137	loadk         r9   k66 ; k66 = 95
.line	137	loadk        r10   k67 ; k67 = 233
.line	137	loadk        r11   k42 ; k42 = 111
.line	137	loadk        r12   k68 ; k68 = 189
.line	137	loadk        r13   k69 ; k69 = 194
.line	137	loadk        r14   k70 ; k70 = 34
.line	137	loadk        r15   k71 ; k71 = 83
.line	137	loadk        r16   k72 ; k72 = 177
.line	137	call          r7    10     2
.line	137	gettable      r8    r0   k88 ; k88 = "OnButtonEmoteOrPet"
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0   k31 ; k31 = "AddControlEvent"
.line	137	gettable      r6    r0   k90 ; k90 = "Button_CollectionOrF" (truncated)
.line	137	getupval      r7    u4
.line	137	loadk         r8   k65 ; k65 = 12
.line	137	loadk         r9   k66 ; k66 = 95
.line	137	loadk        r10   k67 ; k67 = 233
.line	137	loadk        r11   k42 ; k42 = 111
.line	137	loadk        r12   k68 ; k68 = 189
.line	137	loadk        r13   k69 ; k69 = 194
.line	137	loadk        r14   k70 ; k70 = 34
.line	137	loadk        r15   k71 ; k71 = 83
.line	137	loadk        r16   k72 ; k72 = 177
.line	137	call          r7    10     2
.line	137	gettable      r8    r0   k91 ; k91 = "OnButtonCollectionOr" (truncated)
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0   k31 ; k31 = "AddControlEvent"
.line	137	gettable      r6    r0   k92 ; k92 = "Button_CollectionOrF" (truncated)
.line	137	getupval      r7    u4
.line	137	loadk         r8   k65 ; k65 = 12
.line	137	loadk         r9   k66 ; k66 = 95
.line	137	loadk        r10   k67 ; k67 = 233
.line	137	loadk        r11   k42 ; k42 = 111
.line	137	loadk        r12   k68 ; k68 = 189
.line	137	loadk        r13   k69 ; k69 = 194
.line	137	loadk        r14   k70 ; k70 = 34
.line	137	loadk        r15   k71 ; k71 = 83
.line	137	loadk        r16   k72 ; k72 = 177
.line	137	call          r7    10     2
.line	137	gettable      r8    r0   k91 ; k91 = "OnButtonCollectionOr" (truncated)
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0   k31 ; k31 = "AddControlEvent"
.line	137	gettable      r6    r0   k93 ; k93 = "Button_ShowPet"
.line	137	getupval      r7    u4
.line	137	loadk         r8   k65 ; k65 = 12
.line	137	loadk         r9   k66 ; k66 = 95
.line	137	loadk        r10   k67 ; k67 = 233
.line	137	loadk        r11   k42 ; k42 = 111
.line	137	loadk        r12   k68 ; k68 = 189
.line	137	loadk        r13   k69 ; k69 = 194
.line	137	loadk        r14   k70 ; k70 = 34
.line	137	loadk        r15   k71 ; k71 = 83
.line	137	loadk        r16   k72 ; k72 = 177
.line	137	call          r7    10     2
.line	137	gettable      r8    r0   k94 ; k94 = "OnButtonShowPet"
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0   k31 ; k31 = "AddControlEvent"
.line	137	gettable      r6    r0   k95 ; k95 = "Button_Left"
.line	137	getupval      r7    u4
.line	137	loadk         r8   k65 ; k65 = 12
.line	137	loadk         r9   k66 ; k66 = 95
.line	137	loadk        r10   k67 ; k67 = 233
.line	137	loadk        r11   k42 ; k42 = 111
.line	137	loadk        r12   k68 ; k68 = 189
.line	137	loadk        r13   k69 ; k69 = 194
.line	137	loadk        r14   k70 ; k70 = 34
.line	137	loadk        r15   k71 ; k71 = 83
.line	137	loadk        r16   k72 ; k72 = 177
.line	137	call          r7    10     2
.line	137	gettable      r8    r0   k96 ; k96 = "OnButtonLeft"
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0   k31 ; k31 = "AddControlEvent"
.line	137	gettable      r6    r0   k97 ; k97 = "Button_Right"
.line	137	getupval      r7    u4
.line	137	loadk         r8   k65 ; k65 = 12
.line	137	loadk         r9   k66 ; k66 = 95
.line	137	loadk        r10   k67 ; k67 = 233
.line	137	loadk        r11   k42 ; k42 = 111
.line	137	loadk        r12   k68 ; k68 = 189
.line	137	loadk        r13   k69 ; k69 = 194
.line	137	loadk        r14   k70 ; k70 = 34
.line	137	loadk        r15   k71 ; k71 = 83
.line	137	loadk        r16   k72 ; k72 = 177
.line	137	call          r7    10     2
.line	137	gettable      r8    r0   k98 ; k98 = "OnButtonRight"
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0   k31 ; k31 = "AddControlEvent"
.line	137	gettable      r6    r0   k99 ; k99 = "Button_SubTypeSwitch"
.line	137	getupval      r7    u4
.line	137	loadk         r8   k65 ; k65 = 12
.line	137	loadk         r9   k66 ; k66 = 95
.line	137	loadk        r10   k67 ; k67 = 233
.line	137	loadk        r11   k42 ; k42 = 111
.line	137	loadk        r12   k68 ; k68 = 189
.line	137	loadk        r13   k69 ; k69 = 194
.line	137	loadk        r14   k70 ; k70 = 34
.line	137	loadk        r15   k71 ; k71 = 83
.line	137	loadk        r16   k72 ; k72 = 177
.line	137	call          r7    10     2
.line	137	gettable      r8    r0  k100 ; k100 = "OnButtonSubTypeSwitc" (truncated)
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0   k31 ; k31 = "AddControlEvent"
.line	137	gettable      r6    r0  k101 ; k101 = "Button_Robot_01"
.line	137	getupval      r7    u4
.line	137	loadk         r8   k65 ; k65 = 12
.line	137	loadk         r9   k66 ; k66 = 95
.line	137	loadk        r10   k67 ; k67 = 233
.line	137	loadk        r11   k42 ; k42 = 111
.line	137	loadk        r12   k68 ; k68 = 189
.line	137	loadk        r13   k69 ; k69 = 194
.line	137	loadk        r14   k70 ; k70 = 34
.line	137	loadk        r15   k71 ; k71 = 83
.line	137	loadk        r16   k72 ; k72 = 177
.line	137	call          r7    10     2
.line	137	gettable      r8    r0  k102 ; k102 = "OnButtonRobotClick"
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0   k31 ; k31 = "AddControlEvent"
.line	137	gettable      r6    r0  k103 ; k103 = "Button_Robot_02"
.line	137	getupval      r7    u4
.line	137	loadk         r8   k65 ; k65 = 12
.line	137	loadk         r9   k66 ; k66 = 95
.line	137	loadk        r10   k67 ; k67 = 233
.line	137	loadk        r11   k42 ; k42 = 111
.line	137	loadk        r12   k68 ; k68 = 189
.line	137	loadk        r13   k69 ; k69 = 194
.line	137	loadk        r14   k70 ; k70 = 34
.line	137	loadk        r15   k71 ; k71 = 83
.line	137	loadk        r16   k72 ; k72 = 177
.line	137	call          r7    10     2
.line	137	gettable      r8    r0  k102 ; k102 = "OnButtonRobotClick"
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0  k104 ; k104 = "AddSettingOptionEven" (truncated)
.line	137	getupval      r6    u4
.line	137	loadk         r7   k65 ; k65 = 12
.line	137	loadk         r8  k105 ; k105 = 65
.line	137	loadk         r9  k106 ; k106 = 207
.line	137	loadk        r10   k35 ; k35 = 109
.line	137	loadk        r11  k107 ; k107 = 153
.line	137	loadk        r12  k108 ; k108 = 216
.line	137	loadk        r13  k109 ; k109 = 25
.line	137	loadk        r14   k71 ; k71 = 83
.line	137	loadk        r15  k110 ; k110 = 161
.line	137	call          r6    10     2
.line	137	closure       r7    f0
.line	137	call          r4     4     1
.line	137	self          r4    r0  k104 ; k104 = "AddSettingOptionEven" (truncated)
.line	137	getupval      r6    u4
.line	137	loadk         r7   k65 ; k65 = 12
.line	137	loadk         r8  k105 ; k105 = 65
.line	137	loadk         r9  k106 ; k106 = 207
.line	137	loadk        r10   k35 ; k35 = 109
.line	137	loadk        r11  k107 ; k107 = 153
.line	137	loadk        r12  k108 ; k108 = 216
.line	137	loadk        r13  k109 ; k109 = 25
.line	137	loadk        r14   k71 ; k71 = 83
.line	137	loadk        r15  k110 ; k110 = 161
.line	137	loadk        r16  k111 ; k111 = 234
.line	137	loadk        r17    k5 ; k5 = 90
.line	137	loadk        r18  k112 ; k112 = 26
.line	137	call          r6    13     2
.line	137	closure       r7    f1
.line	137	call          r4     4     1
.line	137	gettable      r4    r0  k113 ; k113 = "WidgetSwitcher_Colle" (truncated)
.line	137	self          r4    r4  k114 ; k114 = "SetActiveWidgetIndex"
.line	137	loadk         r6  k115 ; k115 = 1
.line	137	call          r4     3     1
.line	137	self          r4    r0  k116 ; k116 = "AddCommonEvent"
.line	137	gettabup      r6    u3  k117 ; k117 = "EVENTTYPE_PLAYEREVEN" (truncated)
.line	137	gettabup      r7    u3  k118 ; k118 = L"EVENTID_LOCAL_PLAYER" (truncated)
.line	137	gettable      r8    r0  k119 ; k119 = "OnAvatarAllMeshLoade" (truncated)
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0  k116 ; k116 = "AddCommonEvent"
.line	137	gettabup      r6    u3  k120 ; k120 = "EVENTTYPE_INGAME"
.line	137	gettabup      r7    u3  k121 ; k121 = "EVENTID_INGAME_WEAPO" (truncated)
.line	137	gettable      r8    r0  k122 ; k122 = "OnCustomWeaponShowCh" (truncated)
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	self          r4    r0  k116 ; k116 = "AddCommonEvent"
.line	137	gettabup      r6    u3  k123 ; k123 = "EVENTTYPE_CARD_COLLE" (truncated)
.line	137	gettabup      r7    u3  k124 ; k124 = "EVENTID_CARDCOLLECTI" (truncated)
.line	137	gettable      r8    r0  k125 ; k125 = "OnCardCollectionShow" (truncated)
.line	137	move          r9    r0
.line	137	call          r4     6     1
.line	137	return        r0     1
.line	137	move          r0    r0
.line	137	move          r0    r0
.line	137	gettabup      r3    u0   k63 ; k63 = "HandleChangeCurrentU" (truncated)
.line	137	move          r0    r0
.line	137	return        r0     1

.function	main/f6/f0

.source	null
.linedefined	184
.lastlinedefined	186
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	true

.constant	k0	"RefreshPetExpression"

.line	184	getupval      r0    u0
.line	184	self          r0    r0    k0 ; k0 = "RefreshPetExpression"
.line	184	call          r0     2     1
.line	184	return        r0     1
.line	184	move          r0    r0
.line	184	move          r0    r0
.line	184	move          r0    r0
.line	184	move          r0    r0
.line	184	return        r0     1

.function	main/f6/f1

.source	null
.linedefined	187
.lastlinedefined	189
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	true

.constant	k0	"RefreshPetExpression"

.line	187	getupval      r0    u0
.line	187	self          r0    r0    k0 ; k0 = "RefreshPetExpression"
.line	187	call          r0     2     1
.line	187	return        r0     1
.line	187	move          r0    r0
.line	187	return        r0     1

.function	main/f7

.source	null
.linedefined	196
.lastlinedefined	198
.numparams	1
.is_vararg	0
.maxstacksize	3

.constant	k0	"RefreshCheckGunBtnState"

.line	196	self          r1    r0    k0 ; k0 = "RefreshCheckGunBtnSt" (truncated)
.line	196	call          r1     2     1
.line	196	return        r0     1
.line	196	move          r0    r0
.line	196	move          r0    r0
.line	196	move          r0    r0
.line	196	return        r0     1

.function	main/f8

.source	null
.linedefined	200
.lastlinedefined	206
.numparams	1
.is_vararg	0
.maxstacksize	31

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	18
.constant	k3	68
.constant	k4	195
.constant	k5	96
.constant	k6	191
.constant	k7	228
.constant	k8	49
.constant	k9	70
.constant	k10	167
.constant	k11	201
.constant	k12	121
.constant	k13	57
.constant	k14	251
.constant	k15	182
.constant	k16	126
.constant	k17	130
.constant	k18	252
.constant	k19	111
.constant	k20	152
.constant	k21	80
.constant	k22	229
.constant	k23	86
.constant	k24	104
.constant	k25	137
.constant	k26	217
.constant	k27	124
.constant	k28	46
.constant	k29	"CurEmotePage"
.constant	k30	0
.constant	k31	1
.constant	k32	"RefreshCirclePanel"

.line	200	gettabup      r1    u0    k0 ; k0 = "print"
.line	200	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	200	test          r2     0
.line	200	jmp            0   l35
.line	200	getupval      r2    u1
.line	200	loadk         r3    k2 ; k2 = 18
.line	200	loadk         r4    k3 ; k3 = 68
.line	200	loadk         r5    k4 ; k4 = 195
.line	200	loadk         r6    k5 ; k5 = 96
.line	200	loadk         r7    k6 ; k6 = 191
.line	200	loadk         r8    k7 ; k7 = 228
.line	200	loadk         r9    k8 ; k8 = 49
.line	200	loadk        r10    k9 ; k9 = 70
.line	200	loadk        r11   k10 ; k10 = 167
.line	200	loadk        r12   k11 ; k11 = 201
.line	200	loadk        r13   k12 ; k12 = 121
.line	200	loadk        r14   k13 ; k13 = 57
.line	200	loadk        r15   k14 ; k14 = 251
.line	200	loadk        r16   k15 ; k15 = 182
.line	200	loadk        r17   k16 ; k16 = 126
.line	200	loadk        r18   k17 ; k17 = 130
.line	200	loadk        r19   k18 ; k18 = 252
.line	200	loadk        r20   k19 ; k19 = 111
.line	200	loadk        r21   k20 ; k20 = 152
.line	200	loadk        r22    k9 ; k9 = 70
.line	200	loadk        r23   k21 ; k21 = 80
.line	200	loadk        r24   k22 ; k22 = 229
.line	200	loadk        r25   k23 ; k23 = 86
.line	200	loadk        r26   k24 ; k24 = 104
.line	200	loadk        r27   k25 ; k25 = 137
.line	200	loadk        r28   k26 ; k26 = 217
.line	200	loadk        r29   k27 ; k27 = 124
.line	200	loadk        r30   k28 ; k28 = 46
.line	200	call          r2    29     2
.label	l35
.line	200	gettable      r3    r0   k29 ; k29 = "CurEmotePage"
.line	200	call          r1     3     1
.line	200	gettable      r1    r0   k29 ; k29 = "CurEmotePage"
.line	200	lt             0   k30    r1 ; k30 = 0
.line	200	jmp            0   l45
.line	200	gettable      r1    r0   k29 ; k29 = "CurEmotePage"
.line	200	sub           r1    r1   k31 ; k31 = 1
.line	200	settable      r0   k29    r1 ; k29 = "CurEmotePage"
.line	200	self          r1    r0   k32 ; k32 = "RefreshCirclePanel"
.line	200	call          r1     2     1
.label	l45
.line	200	return        r0     1
.line	200	move          r0    r0
.line	200	move          r0    r0
.line	200	move          r0    r0
.line	200	move          r0    r0
.line	200	return        r0     1

.function	main/f9

.source	null
.linedefined	208
.lastlinedefined	212
.numparams	1
.is_vararg	0
.maxstacksize	32

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	18
.constant	k3	68
.constant	k4	195
.constant	k5	96
.constant	k6	191
.constant	k7	228
.constant	k8	49
.constant	k9	70
.constant	k10	167
.constant	k11	201
.constant	k12	121
.constant	k13	57
.constant	k14	251
.constant	k15	182
.constant	k16	126
.constant	k17	130
.constant	k18	252
.constant	k19	111
.constant	k20	152
.constant	k21	80
.constant	k22	229
.constant	k23	86
.constant	k24	104
.constant	k25	151
.constant	k26	213
.constant	k27	125
.constant	k28	50
.constant	k29	246
.constant	k30	"CurEmotePage"
.constant	k31	1
.constant	k32	"RefreshCirclePanel"

.line	208	gettabup      r1    u0    k0 ; k0 = "print"
.line	208	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	208	test          r2     0
.line	208	jmp            0   l36
.line	208	getupval      r2    u1
.line	208	loadk         r3    k2 ; k2 = 18
.line	208	loadk         r4    k3 ; k3 = 68
.line	208	loadk         r5    k4 ; k4 = 195
.line	208	loadk         r6    k5 ; k5 = 96
.line	208	loadk         r7    k6 ; k6 = 191
.line	208	loadk         r8    k7 ; k7 = 228
.line	208	loadk         r9    k8 ; k8 = 49
.line	208	loadk        r10    k9 ; k9 = 70
.line	208	loadk        r11   k10 ; k10 = 167
.line	208	loadk        r12   k11 ; k11 = 201
.line	208	loadk        r13   k12 ; k12 = 121
.line	208	loadk        r14   k13 ; k13 = 57
.line	208	loadk        r15   k14 ; k14 = 251
.line	208	loadk        r16   k15 ; k15 = 182
.line	208	loadk        r17   k16 ; k16 = 126
.line	208	loadk        r18   k17 ; k17 = 130
.line	208	loadk        r19   k18 ; k18 = 252
.line	208	loadk        r20   k19 ; k19 = 111
.line	208	loadk        r21   k20 ; k20 = 152
.line	208	loadk        r22    k9 ; k9 = 70
.line	208	loadk        r23   k21 ; k21 = 80
.line	208	loadk        r24   k22 ; k22 = 229
.line	208	loadk        r25   k23 ; k23 = 86
.line	208	loadk        r26   k24 ; k24 = 104
.line	208	loadk        r27   k25 ; k25 = 151
.line	208	loadk        r28   k26 ; k26 = 213
.line	208	loadk        r29   k27 ; k27 = 125
.line	208	loadk        r30   k28 ; k28 = 50
.line	208	loadk        r31   k29 ; k29 = 246
.line	208	call          r2    30     2
.label	l36
.line	208	gettable      r3    r0   k30 ; k30 = "CurEmotePage"
.line	208	call          r1     3     1
.line	208	gettable      r1    r0   k30 ; k30 = "CurEmotePage"
.line	208	add           r1    r1   k31 ; k31 = 1
.line	208	settable      r0   k30    r1 ; k30 = "CurEmotePage"
.line	208	self          r1    r0   k32 ; k32 = "RefreshCirclePanel"
.line	208	call          r1     2     1
.line	208	return        r0     1
.line	208	move          r0    r0
.line	208	return        r0     1

.function	main/f10

.source	null
.linedefined	214
.lastlinedefined	222
.numparams	1
.is_vararg	0
.maxstacksize	37

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	23	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	18
.constant	k3	68
.constant	k4	195
.constant	k5	96
.constant	k6	191
.constant	k7	228
.constant	k8	49
.constant	k9	70
.constant	k10	167
.constant	k11	201
.constant	k12	121
.constant	k13	57
.constant	k14	251
.constant	k15	182
.constant	k16	126
.constant	k17	130
.constant	k18	252
.constant	k19	111
.constant	k20	152
.constant	k21	80
.constant	k22	229
.constant	k23	86
.constant	k24	104
.constant	k25	128
.constant	k26	209
.constant	k27	117
.constant	k28	46
.constant	k29	231
.constant	k30	134
.constant	k31	114
.constant	k32	248
.constant	k33	198
.constant	k34	101
.constant	k35	"CurrentShowState"
.constant	k36	"WidgetSwitcher_EmoteOrPet"
.constant	k37	"GetActiveWidgetIndex"
.constant	k38	1
.constant	k39	"PetExpression"
.constant	k40	"Expression"
.constant	k41	"RefreshCirclePanel"

.line	214	gettabup      r1    u0    k0 ; k0 = "print"
.line	214	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	214	test          r2     0
.line	214	jmp            0   l41
.line	214	getupval      r2    u1
.line	214	loadk         r3    k2 ; k2 = 18
.line	214	loadk         r4    k3 ; k3 = 68
.line	214	loadk         r5    k4 ; k4 = 195
.line	214	loadk         r6    k5 ; k5 = 96
.line	214	loadk         r7    k6 ; k6 = 191
.line	214	loadk         r8    k7 ; k7 = 228
.line	214	loadk         r9    k8 ; k8 = 49
.line	214	loadk        r10    k9 ; k9 = 70
.line	214	loadk        r11   k10 ; k10 = 167
.line	214	loadk        r12   k11 ; k11 = 201
.line	214	loadk        r13   k12 ; k12 = 121
.line	214	loadk        r14   k13 ; k13 = 57
.line	214	loadk        r15   k14 ; k14 = 251
.line	214	loadk        r16   k15 ; k15 = 182
.line	214	loadk        r17   k16 ; k16 = 126
.line	214	loadk        r18   k17 ; k17 = 130
.line	214	loadk        r19   k18 ; k18 = 252
.line	214	loadk        r20   k19 ; k19 = 111
.line	214	loadk        r21   k20 ; k20 = 152
.line	214	loadk        r22    k9 ; k9 = 70
.line	214	loadk        r23   k21 ; k21 = 80
.line	214	loadk        r24   k22 ; k22 = 229
.line	214	loadk        r25   k23 ; k23 = 86
.line	214	loadk        r26   k24 ; k24 = 104
.line	214	loadk        r27   k25 ; k25 = 128
.line	214	loadk        r28   k26 ; k26 = 209
.line	214	loadk        r29   k27 ; k27 = 117
.line	214	loadk        r30   k28 ; k28 = 46
.line	214	loadk        r31   k29 ; k29 = 231
.line	214	loadk        r32   k30 ; k30 = 134
.line	214	loadk        r33   k31 ; k31 = 114
.line	214	loadk        r34   k32 ; k32 = 248
.line	214	loadk        r35   k33 ; k33 = 198
.line	214	loadk        r36   k34 ; k34 = 101
.line	214	call          r2    35     2
.label	l41
.line	214	gettable      r3    r0   k35 ; k35 = "CurrentShowState"
.line	214	call          r1     3     1
.line	214	gettable      r1    r0   k36 ; k36 = "WidgetSwitcher_Emote" (truncated)
.line	214	self          r1    r1   k37 ; k37 = "GetActiveWidgetIndex"
.line	214	call          r1     2     2
.line	214	eq             0    r1   k38 ; k38 = 1
.line	214	jmp            0   l51
.line	214	gettabup      r1    u2   k39 ; k39 = "PetExpression"
.line	214	settable      r0   k35    r1 ; k35 = "CurrentShowState"
.line	214	jmp            0   l53
.label	l51
.line	214	gettabup      r1    u2   k40 ; k40 = "Expression"
.line	214	settable      r0   k35    r1 ; k35 = "CurrentShowState"
.label	l53
.line	214	self          r1    r0   k41 ; k41 = "RefreshCirclePanel"
.line	214	call          r1     2     1
.line	214	return        r0     1
.line	214	move          r0    r0
.line	214	move          r0    r0
.line	214	move          r0    r0
.line	214	move          r0    r0
.line	214	return        r0     1

.function	main/f11

.source	null
.linedefined	224
.lastlinedefined	228
.numparams	1
.is_vararg	0
.maxstacksize	33

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	23	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	18
.constant	k3	68
.constant	k4	195
.constant	k5	96
.constant	k6	191
.constant	k7	228
.constant	k8	49
.constant	k9	70
.constant	k10	167
.constant	k11	201
.constant	k12	121
.constant	k13	57
.constant	k14	251
.constant	k15	182
.constant	k16	126
.constant	k17	130
.constant	k18	252
.constant	k19	111
.constant	k20	152
.constant	k21	80
.constant	k22	229
.constant	k23	86
.constant	k24	104
.constant	k25	135
.constant	k26	120
.constant	k27	56
.constant	k28	238
.constant	k29	172
.constant	k30	"CurrentShowState"
.constant	k31	"Bubble"
.constant	k32	"RefreshCirclePanel"

.line	224	gettabup      r1    u0    k0 ; k0 = "print"
.line	224	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	224	test          r2     0
.line	224	jmp            0   l37
.line	224	getupval      r2    u1
.line	224	loadk         r3    k2 ; k2 = 18
.line	224	loadk         r4    k3 ; k3 = 68
.line	224	loadk         r5    k4 ; k4 = 195
.line	224	loadk         r6    k5 ; k5 = 96
.line	224	loadk         r7    k6 ; k6 = 191
.line	224	loadk         r8    k7 ; k7 = 228
.line	224	loadk         r9    k8 ; k8 = 49
.line	224	loadk        r10    k9 ; k9 = 70
.line	224	loadk        r11   k10 ; k10 = 167
.line	224	loadk        r12   k11 ; k11 = 201
.line	224	loadk        r13   k12 ; k12 = 121
.line	224	loadk        r14   k13 ; k13 = 57
.line	224	loadk        r15   k14 ; k14 = 251
.line	224	loadk        r16   k15 ; k15 = 182
.line	224	loadk        r17   k16 ; k16 = 126
.line	224	loadk        r18   k17 ; k17 = 130
.line	224	loadk        r19   k18 ; k18 = 252
.line	224	loadk        r20   k19 ; k19 = 111
.line	224	loadk        r21   k20 ; k20 = 152
.line	224	loadk        r22    k9 ; k9 = 70
.line	224	loadk        r23   k21 ; k21 = 80
.line	224	loadk        r24   k22 ; k22 = 229
.line	224	loadk        r25   k23 ; k23 = 86
.line	224	loadk        r26   k24 ; k24 = 104
.line	224	loadk        r27   k25 ; k25 = 135
.line	224	loadk        r28   k11 ; k11 = 201
.line	224	loadk        r29   k26 ; k26 = 120
.line	224	loadk        r30   k27 ; k27 = 56
.line	224	loadk        r31   k28 ; k28 = 238
.line	224	loadk        r32   k29 ; k29 = 172
.line	224	call          r2    31     2
.label	l37
.line	224	gettable      r3    r0   k30 ; k30 = "CurrentShowState"
.line	224	call          r1     3     1
.line	224	gettabup      r1    u2   k31 ; k31 = "Bubble"
.line	224	settable      r0   k30    r1 ; k30 = "CurrentShowState"
.line	224	self          r1    r0   k32 ; k32 = "RefreshCirclePanel"
.line	224	call          r1     2     1
.line	224	return        r0     1
.line	224	move          r0    r0
.line	224	move          r0    r0
.line	224	return        r0     1

.function	main/f12

.source	null
.linedefined	230
.lastlinedefined	241
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	23	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	18
.constant	k5	68
.constant	k6	195
.constant	k7	96
.constant	k8	191
.constant	k9	228
.constant	k10	49
.constant	k11	70
.constant	k12	167
.constant	k13	201
.constant	k14	121
.constant	k15	57
.constant	k16	251
.constant	k17	182
.constant	k18	126
.constant	k19	130
.constant	k20	252
.constant	k21	111
.constant	k22	152
.constant	k23	80
.constant	k24	229
.constant	k25	86
.constant	k26	104
.constant	k27	134
.constant	k28	211
.constant	k29	118
.constant	k30	54
.constant	k31	231
.constant	k32	170
.constant	k33	116
.constant	k34	193
.constant	k35	204
.constant	k36	127
.constant	k37	133
.constant	k38	81
.constant	k39	114
.constant	k40	237
.constant	k41	72
.constant	k42	99
.constant	k43	45
.constant	k44	69
.constant	k45	"CurrentShowState"
.constant	k46	"require"
.constant	k47	32
.constant	k48	93
.constant	k49	102
.constant	k50	186
.constant	k51	213
.constant	k52	103
.constant	k53	185
.constant	k54	217
.constant	k55	107
.constant	k56	100
.constant	k57	241
.constant	k58	222
.constant	k59	218
.constant	k60	244
.constant	k61	112
.constant	k62	248
.constant	k63	92
.constant	k64	177
.constant	k65	123
.constant	k66	240
.constant	k67	166
.constant	k68	115
.constant	k69	243
.constant	k70	168
.constant	k71	79
.constant	k72	242
.constant	k73	65
.constant	k74	38
.constant	k75	108
.constant	k76	236
.constant	k77	40
.constant	k78	85
.constant	k79	"IsBlueholeOperationRegion"
.constant	k80	"Flaunt"
.constant	k81	"WidgetSwitcher_CollectionOrFlaunt"
.constant	k82	"GetActiveWidgetIndex"
.constant	k83	1
.constant	k84	"Collection"
.constant	k85	"RefreshCirclePanel"

.line	230	gettabup      r1    u0    k0 ; k0 = "print"
.line	230	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	230	test          r2     0
.line	230	jmp            0   l56
.line	230	gettabup      r2    u0    k2 ; k2 = "table"
.line	230	gettable      r2    r2    k3 ; k3 = "concat"
.line	230	newtable      r3     1     0
.line	230	getupval      r4    u1
.line	230	loadk         r5    k4 ; k4 = 18
.line	230	loadk         r6    k5 ; k5 = 68
.line	230	loadk         r7    k6 ; k6 = 195
.line	230	loadk         r8    k7 ; k7 = 96
.line	230	loadk         r9    k8 ; k8 = 191
.line	230	loadk        r10    k9 ; k9 = 228
.line	230	loadk        r11   k10 ; k10 = 49
.line	230	loadk        r12   k11 ; k11 = 70
.line	230	loadk        r13   k12 ; k12 = 167
.line	230	loadk        r14   k13 ; k13 = 201
.line	230	loadk        r15   k14 ; k14 = 121
.line	230	loadk        r16   k15 ; k15 = 57
.line	230	loadk        r17   k16 ; k16 = 251
.line	230	loadk        r18   k17 ; k17 = 182
.line	230	loadk        r19   k18 ; k18 = 126
.line	230	loadk        r20   k19 ; k19 = 130
.line	230	loadk        r21   k20 ; k20 = 252
.line	230	loadk        r22   k21 ; k21 = 111
.line	230	loadk        r23   k22 ; k22 = 152
.line	230	loadk        r24   k11 ; k11 = 70
.line	230	loadk        r25   k23 ; k23 = 80
.line	230	loadk        r26   k24 ; k24 = 229
.line	230	loadk        r27   k25 ; k25 = 86
.line	230	loadk        r28   k26 ; k26 = 104
.line	230	loadk        r29   k27 ; k27 = 134
.line	230	loadk        r30   k28 ; k28 = 211
.line	230	loadk        r31   k29 ; k29 = 118
.line	230	loadk        r32   k30 ; k30 = 54
.line	230	loadk        r33   k31 ; k31 = 231
.line	230	loadk        r34   k32 ; k32 = 170
.line	230	loadk        r35   k33 ; k33 = 116
.line	230	loadk        r36   k34 ; k34 = 193
.line	230	loadk        r37   k35 ; k35 = 204
.line	230	loadk        r38   k36 ; k36 = 127
.line	230	loadk        r39   k37 ; k37 = 133
.line	230	loadk        r40   k38 ; k38 = 81
.line	230	loadk        r41   k39 ; k39 = 114
.line	230	loadk        r42   k40 ; k40 = 237
.line	230	loadk        r43   k41 ; k41 = 72
.line	230	loadk        r44   k42 ; k42 = 99
.line	230	call          r4    41     2
.line	230	getupval      r5    u1
.line	230	loadk         r6   k43 ; k43 = 45
.line	230	loadk         r7   k44 ; k44 = 69
.line	230	call          r5     3     0
.line	230	setlist       r3     0     1
.line	230	call          r2     2     2
.label	l56
.line	230	gettable      r3    r0   k45 ; k45 = "CurrentShowState"
.line	230	call          r1     3     1
.line	230	gettabup      r1    u0   k46 ; k46 = "require"
.line	230	gettabup      r2    u0    k2 ; k2 = "table"
.line	230	gettable      r2    r2    k3 ; k3 = "concat"
.line	230	newtable      r3     1     0
.line	230	getupval      r4    u1
.line	230	loadk         r5   k47 ; k47 = 32
.line	230	loadk         r6   k48 ; k48 = 93
.line	230	loadk         r7    k6 ; k6 = 195
.line	230	loadk         r8   k49 ; k49 = 102
.line	230	loadk         r9   k50 ; k50 = 186
.line	230	loadk        r10   k51 ; k51 = 213
.line	230	loadk        r11   k52 ; k52 = 103
.line	230	loadk        r12   k44 ; k44 = 69
.line	230	loadk        r13   k53 ; k53 = 185
.line	230	loadk        r14   k54 ; k54 = 217
.line	230	loadk        r15   k55 ; k55 = 107
.line	230	loadk        r16   k56 ; k56 = 100
.line	230	loadk        r17   k57 ; k57 = 241
.line	230	loadk        r18   k17 ; k17 = 182
.line	230	loadk        r19   k18 ; k18 = 126
.line	230	loadk        r20   k58 ; k58 = 222
.line	230	loadk        r21   k59 ; k59 = 218
.line	230	loadk        r22   k49 ; k49 = 102
.line	230	loadk        r23   k60 ; k60 = 244
.line	230	loadk        r24   k61 ; k61 = 112
.line	230	loadk        r25   k41 ; k41 = 72
.line	230	loadk        r26   k62 ; k62 = 248
.line	230	loadk        r27   k63 ; k63 = 92
.line	230	loadk        r28   k26 ; k26 = 104
.line	230	loadk        r29   k64 ; k64 = 177
.line	230	loadk        r30   k57 ; k57 = 241
.line	230	loadk        r31   k65 ; k65 = 123
.line	230	loadk        r32   k15 ; k15 = 57
.line	230	loadk        r33   k66 ; k66 = 240
.line	230	loadk        r34   k67 ; k67 = 166
.line	230	loadk        r35   k68 ; k68 = 115
.line	230	loadk        r36   k27 ; k27 = 134
.line	230	loadk        r37   k69 ; k69 = 243
.line	230	loadk        r38   k56 ; k56 = 100
.line	230	loadk        r39   k70 ; k70 = 168
.line	230	loadk        r40   k71 ; k71 = 79
.line	230	loadk        r41   k48 ; k48 = 93
.line	230	loadk        r42   k72 ; k72 = 242
.line	230	loadk        r43   k73 ; k73 = 65
.line	230	loadk        r44    k5 ; k5 = 68
.line	230	call          r4    41     2
.line	230	getupval      r5    u1
.line	230	loadk         r6   k74 ; k74 = 38
.line	230	loadk         r7   k25 ; k25 = 86
.line	230	loadk         r8    k6 ; k6 = 195
.line	230	loadk         r9   k75 ; k75 = 108
.line	230	loadk        r10   k50 ; k50 = 186
.line	230	loadk        r11   k76 ; k76 = 236
.line	230	loadk        r12   k77 ; k77 = 40
.line	230	loadk        r13   k78 ; k78 = 85
.line	230	loadk        r14   k12 ; k12 = 167
.line	230	loadk        r15    k6 ; k6 = 195
.line	230	loadk        r16   k14 ; k14 = 121
.line	230	call          r5    12     0
.line	230	setlist       r3     0     1
.line	230	call          r2     2     2
.line	230	call          r1     2     2
.line	230	gettable      r2    r1   k79 ; k79 = "IsBlueholeOperationR" (truncated)
.line	230	call          r2     1     2
.line	230	test          r2     0
.line	230	jmp            0  l127
.line	230	gettabup      r2    u2   k80 ; k80 = "Flaunt"
.line	230	settable      r0   k45    r2 ; k45 = "CurrentShowState"
.line	230	jmp            0  l137
.label	l127
.line	230	gettable      r2    r0   k81 ; k81 = "WidgetSwitcher_Colle" (truncated)
.line	230	self          r2    r2   k82 ; k82 = "GetActiveWidgetIndex"
.line	230	call          r2     2     2
.line	230	eq             0    r2   k83 ; k83 = 1
.line	230	jmp            0  l135
.line	230	gettabup      r2    u2   k80 ; k80 = "Flaunt"
.line	230	settable      r0   k45    r2 ; k45 = "CurrentShowState"
.line	230	jmp            0  l137
.label	l135
.line	230	gettabup      r2    u2   k84 ; k84 = "Collection"
.line	230	settable      r0   k45    r2 ; k45 = "CurrentShowState"
.label	l137
.line	230	self          r2    r0   k85 ; k85 = "RefreshCirclePanel"
.line	230	call          r2     2     1
.line	230	return        r0     1
.line	230	gettabup      r2    u1   k37 ; k37 = 133
.line	230	return        r0     1

.function	main/f13

.source	null
.linedefined	243
.lastlinedefined	248
.numparams	1
.is_vararg	0
.maxstacksize	34

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	18
.constant	k3	68
.constant	k4	195
.constant	k5	96
.constant	k6	191
.constant	k7	228
.constant	k8	49
.constant	k9	70
.constant	k10	167
.constant	k11	201
.constant	k12	121
.constant	k13	57
.constant	k14	251
.constant	k15	182
.constant	k16	126
.constant	k17	130
.constant	k18	252
.constant	k19	111
.constant	k20	152
.constant	k21	80
.constant	k22	229
.constant	k23	86
.constant	k24	104
.constant	k25	150
.constant	k26	212
.constant	k27	117
.constant	k28	45
.constant	k29	210
.constant	k30	172
.constant	k31	116
.constant	k32	"ModuleManager"
.constant	k33	"GetModule"
.constant	k34	"CommonModuleConfig"
.constant	k35	"SettingModule"
.constant	k36	"SetOptionValue"
.constant	k37	12
.constant	k38	65
.constant	k39	207
.constant	k40	109
.constant	k41	153
.constant	k42	216
.constant	k43	25
.constant	k44	83
.constant	k45	161
.constant	k46	234
.constant	k47	90
.constant	k48	26

.line	243	gettabup      r1    u0    k0 ; k0 = "print"
.line	243	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	243	test          r2     0
.line	243	jmp            0   l38
.line	243	getupval      r2    u1
.line	243	loadk         r3    k2 ; k2 = 18
.line	243	loadk         r4    k3 ; k3 = 68
.line	243	loadk         r5    k4 ; k4 = 195
.line	243	loadk         r6    k5 ; k5 = 96
.line	243	loadk         r7    k6 ; k6 = 191
.line	243	loadk         r8    k7 ; k7 = 228
.line	243	loadk         r9    k8 ; k8 = 49
.line	243	loadk        r10    k9 ; k9 = 70
.line	243	loadk        r11   k10 ; k10 = 167
.line	243	loadk        r12   k11 ; k11 = 201
.line	243	loadk        r13   k12 ; k12 = 121
.line	243	loadk        r14   k13 ; k13 = 57
.line	243	loadk        r15   k14 ; k14 = 251
.line	243	loadk        r16   k15 ; k15 = 182
.line	243	loadk        r17   k16 ; k16 = 126
.line	243	loadk        r18   k17 ; k17 = 130
.line	243	loadk        r19   k18 ; k18 = 252
.line	243	loadk        r20   k19 ; k19 = 111
.line	243	loadk        r21   k20 ; k20 = 152
.line	243	loadk        r22    k9 ; k9 = 70
.line	243	loadk        r23   k21 ; k21 = 80
.line	243	loadk        r24   k22 ; k22 = 229
.line	243	loadk        r25   k23 ; k23 = 86
.line	243	loadk        r26   k24 ; k24 = 104
.line	243	loadk        r27   k25 ; k25 = 150
.line	243	loadk        r28   k26 ; k26 = 212
.line	243	loadk        r29   k27 ; k27 = 117
.line	243	loadk        r30   k28 ; k28 = 45
.line	243	loadk        r31   k29 ; k29 = 210
.line	243	loadk        r32   k30 ; k30 = 172
.line	243	loadk        r33   k31 ; k31 = 116
.line	243	call          r2    32     2
.label	l38
.line	243	call          r1     2     1
.line	243	gettabup      r1    u0   k32 ; k32 = "ModuleManager"
.line	243	gettable      r1    r1   k33 ; k33 = "GetModule"
.line	243	gettabup      r2    u0   k32 ; k32 = "ModuleManager"
.line	243	gettable      r2    r2   k34 ; k34 = "CommonModuleConfig"
.line	243	gettable      r2    r2   k35 ; k35 = "SettingModule"
.line	243	call          r1     2     2
.line	243	self          r2    r1   k36 ; k36 = "SetOptionValue"
.line	243	getupval      r4    u1
.line	243	loadk         r5   k37 ; k37 = 12
.line	243	loadk         r6   k38 ; k38 = 65
.line	243	loadk         r7   k39 ; k39 = 207
.line	243	loadk         r8   k40 ; k40 = 109
.line	243	loadk         r9   k41 ; k41 = 153
.line	243	loadk        r10   k42 ; k42 = 216
.line	243	loadk        r11   k43 ; k43 = 25
.line	243	loadk        r12   k44 ; k44 = 83
.line	243	loadk        r13   k45 ; k45 = 161
.line	243	loadk        r14   k46 ; k46 = 234
.line	243	loadk        r15   k47 ; k47 = 90
.line	243	loadk        r16   k48 ; k48 = 26
.line	243	call          r4    13     2
.line	243	loadbool      r5     1     0
.line	243	call          r2     4     1
.line	243	self          r2    r1   k36 ; k36 = "SetOptionValue"
.line	243	getupval      r4    u1
.line	243	loadk         r5   k37 ; k37 = 12
.line	243	loadk         r6   k38 ; k38 = 65
.line	243	loadk         r7   k39 ; k39 = 207
.line	243	loadk         r8   k40 ; k40 = 109
.line	243	loadk         r9   k41 ; k41 = 153
.line	243	loadk        r10   k42 ; k42 = 216
.line	243	loadk        r11   k43 ; k43 = 25
.line	243	loadk        r12   k44 ; k44 = 83
.line	243	loadk        r13   k45 ; k45 = 161
.line	243	call          r4    10     2
.line	243	loadbool      r5     1     0
.line	243	call          r2     4     1
.line	243	return        r0     1
.line	243	move          r0    r0
.line	243	move          r0    r0
.line	243	move          r0    r0
.line	243	move          r0    r0
.line	243	return        r0     1

.function	main/f14

.source	null
.linedefined	250
.lastlinedefined	257
.numparams	1
.is_vararg	0
.maxstacksize	40

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	23	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	18
.constant	k3	68
.constant	k4	195
.constant	k5	96
.constant	k6	191
.constant	k7	228
.constant	k8	49
.constant	k9	70
.constant	k10	167
.constant	k11	201
.constant	k12	121
.constant	k13	57
.constant	k14	251
.constant	k15	182
.constant	k16	126
.constant	k17	130
.constant	k18	252
.constant	k19	111
.constant	k20	155
.constant	k21	69
.constant	k22	229
.constant	k23	88
.constant	k24	116
.constant	k25	132
.constant	k26	208
.constant	k27	118
.constant	k28	23
.constant	k29	231
.constant	k30	186
.constant	k31	104
.constant	k32	204
.constant	k33	112
.constant	k34	174
.constant	k35	80
.constant	k36	"CurrentShowState"
.constant	k37	"None"
.constant	k38	"RefreshChangeAvatarFormBtnState"
.constant	k39	"RefreshTransformButton"
.constant	k40	"RefreshXSuitEmoteButton"

.line	250	gettabup      r1    u0    k0 ; k0 = "print"
.line	250	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	250	test          r2     0
.line	250	jmp            0   l44
.line	250	getupval      r2    u1
.line	250	loadk         r3    k2 ; k2 = 18
.line	250	loadk         r4    k3 ; k3 = 68
.line	250	loadk         r5    k4 ; k4 = 195
.line	250	loadk         r6    k5 ; k5 = 96
.line	250	loadk         r7    k6 ; k6 = 191
.line	250	loadk         r8    k7 ; k7 = 228
.line	250	loadk         r9    k8 ; k8 = 49
.line	250	loadk        r10    k9 ; k9 = 70
.line	250	loadk        r11   k10 ; k10 = 167
.line	250	loadk        r12   k11 ; k11 = 201
.line	250	loadk        r13   k12 ; k12 = 121
.line	250	loadk        r14   k13 ; k13 = 57
.line	250	loadk        r15   k14 ; k14 = 251
.line	250	loadk        r16   k15 ; k15 = 182
.line	250	loadk        r17   k16 ; k16 = 126
.line	250	loadk        r18   k17 ; k17 = 130
.line	250	loadk        r19   k18 ; k18 = 252
.line	250	loadk        r20   k19 ; k19 = 111
.line	250	loadk        r21   k20 ; k20 = 155
.line	250	loadk        r22   k21 ; k21 = 69
.line	250	loadk        r23   k21 ; k21 = 69
.line	250	loadk        r24   k22 ; k22 = 229
.line	250	loadk        r25   k23 ; k23 = 88
.line	250	loadk        r26   k24 ; k24 = 116
.line	250	loadk        r27   k25 ; k25 = 132
.line	250	loadk        r28   k26 ; k26 = 208
.line	250	loadk        r29   k27 ; k27 = 118
.line	250	loadk        r30   k28 ; k28 = 23
.line	250	loadk        r31   k29 ; k29 = 231
.line	250	loadk        r32   k30 ; k30 = 186
.line	250	loadk        r33   k31 ; k31 = 104
.line	250	loadk        r34    k7 ; k7 = 228
.line	250	loadk        r35   k32 ; k32 = 204
.line	250	loadk        r36   k33 ; k33 = 112
.line	250	loadk        r37   k34 ; k34 = 174
.line	250	loadk        r38    k9 ; k9 = 70
.line	250	loadk        r39   k35 ; k35 = 80
.line	250	call          r2    38     2
.label	l44
.line	250	call          r1     2     1
.line	250	gettable      r1    r0   k36 ; k36 = "CurrentShowState"
.line	250	gettabup      r2    u2   k37 ; k37 = "None"
.line	250	eq             1    r1    r2
.line	250	jmp            0   l51
.line	250	self          r1    r0   k38 ; k38 = "RefreshChangeAvatarF" (truncated)
.line	250	call          r1     2     1
.label	l51
.line	250	self          r1    r0   k39 ; k39 = "RefreshTransformButt" (truncated)
.line	250	call          r1     2     1
.line	250	self          r1    r0   k40 ; k40 = "RefreshXSuitEmoteBut" (truncated)
.line	250	call          r1     2     1
.line	250	return        r0     1
.line	250	move          r0    r0
.line	250	move          r0    r0
.line	250	move          r0    r0
.line	250	return        r0     1

.function	main/f15

.source	null
.linedefined	259
.lastlinedefined	317
.numparams	1
.is_vararg	0
.maxstacksize	29

.upvalue	"_ENV"	1	true
.upvalue	"U1"	0	false

.constant	k0	1
.constant	k1	12
.constant	k2	10
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	0
.constant	k6	92
.constant	k7	203
.constant	k8	100
.constant	k9	177
.constant	k10	254
.constant	k11	110
.constant	k12	138
.constant	k13	99
.constant	k14	36
.constant	k15	245
.constant	k16	134
.constant	k17	20
.constant	k18	88
.constant	k19	206
.constant	k20	213
.constant	k21	26
.constant	k22	65
.constant	k23	188
.constant	k24	216
.constant	k25	105
.constant	k26	34
.constant	k27	247
.constant	k28	171
.constant	k29	85
.constant	k30	224
.constant	k31	23
.constant	k32	84
.constant	k33	210
.constant	k34	119
.constant	k35	139
.constant	k36	228
.constant	k37	17
.constant	k38	135
.constant	k39	197
.constant	k40	45
.constant	k41	205
.constant	k42	5
.constant	k43	89
.constant	k44	182
.constant	k45	199
.constant	k46	79
.constant	k47	80
.constant	k48	196
.constant	k49	117
.constant	k50	181
.constant	k51	25
.constant	k52	87
.constant	k53	187
.constant	k54	201
.constant	k55	102
.constant	k56	21
.constant	k57	209
.constant	k58	157
.constant	k59	150
.constant	k60	38
.constant	k61	190
.constant	k62	243
.constant	k63	73
.constant	k64	14
.constant	k65	"EmoteImageArray"
.constant	k66	"Add"
.constant	k67	"SlotSwitcherArray"
.constant	k68	"EmoteNameArray"
.constant	k69	"LockImageArray"
.constant	k70	"EmoteEffectSwitcherArray"
.constant	k71	"CDPanelArray"
.constant	k72	"CDTextArray"

.line	259	loadk         r1    k0 ; k0 = 1
.line	259	loadk         r2    k1 ; k1 = 12
.line	259	loadk         r3    k0 ; k0 = 1
.line	259	move          r0    r0
.line	259	getupval      r5    u0
.line	259	call          r5     1     2
.line	259	lt             0    r4    k2 ; k2 = 10
.line	259	jmp            0   l18
.line	259	gettabup      r6    u1    k3 ; k3 = "table"
.line	259	gettable      r6    r6    k4 ; k4 = "concat"
.line	259	newtable      r7     2     0
.line	259	loadk         r8    k5 ; k5 = 0
.line	259	move          r9    r4
.line	259	setlist       r7     2     1
.line	259	call          r6     2     2
.line	259	move          r5    r6
.line	259	jmp            0   l25
.label	l18
.line	259	gettabup      r6    u1    k3 ; k3 = "table"
.line	259	gettable      r6    r6    k4 ; k4 = "concat"
.line	259	newtable      r7     1     0
.line	259	move          r8    r4
.line	259	setlist       r7     1     1
.line	259	call          r6     2     2
.line	259	move          r5    r6
.label	l25
.line	259	gettabup      r6    u1    k3 ; k3 = "table"
.line	259	gettable      r6    r6    k4 ; k4 = "concat"
.line	259	newtable      r7     2     0
.line	259	getupval      r8    u0
.line	259	loadk         r9    k2 ; k2 = 10
.line	259	loadk        r10    k6 ; k6 = 92
.line	259	loadk        r11    k7 ; k7 = 203
.line	259	loadk        r12    k8 ; k8 = 100
.line	259	loadk        r13    k9 ; k9 = 177
.line	259	loadk        r14   k10 ; k10 = 254
.line	259	loadk        r15    k1 ; k1 = 12
.line	259	loadk        r16   k11 ; k11 = 110
.line	259	loadk        r17   k12 ; k12 = 138
.line	259	loadk        r18   k10 ; k10 = 254
.line	259	loadk        r19   k13 ; k13 = 99
.line	259	loadk        r20   k14 ; k14 = 36
.line	259	loadk        r21   k15 ; k15 = 245
.line	259	loadk        r22   k16 ; k16 = 134
.line	259	call          r8    15     2
.line	259	move          r9    r5
.line	259	setlist       r7     2     1
.line	259	call          r6     2     2
.line	259	gettabup      r7    u1    k3 ; k3 = "table"
.line	259	gettable      r7    r7    k4 ; k4 = "concat"
.line	259	newtable      r8     2     0
.line	259	getupval      r9    u0
.line	259	loadk        r10   k17 ; k17 = 20
.line	259	loadk        r11   k18 ; k18 = 88
.line	259	loadk        r12   k19 ; k19 = 206
.line	259	loadk        r13    k8 ; k8 = 100
.line	259	loadk        r14    k9 ; k9 = 177
.line	259	loadk        r15   k20 ; k20 = 213
.line	259	loadk        r16   k21 ; k21 = 26
.line	259	loadk        r17   k22 ; k22 = 65
.line	259	loadk        r18   k23 ; k23 = 188
.line	259	loadk        r19   k24 ; k24 = 216
.line	259	loadk        r20   k25 ; k25 = 105
.line	259	loadk        r21   k26 ; k26 = 34
.line	259	loadk        r22   k27 ; k27 = 247
.line	259	loadk        r23   k28 ; k28 = 171
.line	259	loadk        r24   k29 ; k29 = 85
.line	259	loadk        r25   k30 ; k30 = 224
.line	259	call          r9    17     2
.line	259	move         r10    r5
.line	259	setlist       r8     2     1
.line	259	call          r7     2     2
.line	259	gettabup      r8    u1    k3 ; k3 = "table"
.line	259	gettable      r8    r8    k4 ; k4 = "concat"
.line	259	newtable      r9     2     0
.line	259	getupval     r10    u0
.line	259	loadk        r11   k31 ; k31 = 23
.line	259	loadk        r12   k32 ; k32 = 84
.line	259	loadk        r13   k33 ; k33 = 210
.line	259	loadk        r14   k34 ; k34 = 119
.line	259	loadk        r15   k35 ; k35 = 139
.line	259	loadk        r16   k36 ; k36 = 228
.line	259	loadk        r17   k37 ; k37 = 17
.line	259	loadk        r18   k25 ; k25 = 105
.line	259	loadk        r19   k38 ; k38 = 135
.line	259	loadk        r20   k39 ; k39 = 197
.line	259	loadk        r21    k8 ; k8 = 100
.line	259	loadk        r22   k40 ; k40 = 45
.line	259	loadk        r23   k41 ; k41 = 205
.line	259	call         r10    14     2
.line	259	move         r11    r5
.line	259	setlist       r9     2     1
.line	259	call          r8     2     2
.line	259	gettabup      r9    u1    k3 ; k3 = "table"
.line	259	gettable      r9    r9    k4 ; k4 = "concat"
.line	259	newtable     r10     2     0
.line	259	getupval     r11    u0
.line	259	loadk        r12    k2 ; k2 = 10
.line	259	loadk        r13    k6 ; k6 = 92
.line	259	loadk        r14    k7 ; k7 = 203
.line	259	loadk        r15    k8 ; k8 = 100
.line	259	loadk        r16    k9 ; k9 = 177
.line	259	loadk        r17   k10 ; k10 = 254
.line	259	loadk        r18   k42 ; k42 = 5
.line	259	loadk        r19   k43 ; k43 = 89
.line	259	loadk        r20   k44 ; k44 = 182
.line	259	loadk        r21   k45 ; k45 = 199
.line	259	loadk        r22   k29 ; k29 = 85
.line	259	call         r11    12     2
.line	259	move         r12    r5
.line	259	setlist      r10     2     1
.line	259	call          r9     2     2
.line	259	gettabup     r10    u1    k3 ; k3 = "table"
.line	259	gettable     r10   r10    k4 ; k4 = "concat"
.line	259	newtable     r11     2     0
.line	259	getupval     r12    u0
.line	259	loadk        r13   k17 ; k17 = 20
.line	259	loadk        r14   k18 ; k18 = 88
.line	259	loadk        r15   k19 ; k19 = 206
.line	259	loadk        r16    k8 ; k8 = 100
.line	259	loadk        r17    k9 ; k9 = 177
.line	259	loadk        r18   k20 ; k20 = 213
.line	259	loadk        r19   k21 ; k21 = 26
.line	259	loadk        r20   k22 ; k22 = 65
.line	259	loadk        r21   k23 ; k23 = 188
.line	259	loadk        r22   k24 ; k24 = 216
.line	259	loadk        r23   k25 ; k25 = 105
.line	259	loadk        r24   k26 ; k26 = 34
.line	259	loadk        r25   k27 ; k27 = 247
.line	259	loadk        r26   k28 ; k28 = 171
.line	259	loadk        r27   k46 ; k46 = 79
.line	259	call         r12    16     2
.line	259	move         r13    r5
.line	259	setlist      r11     2     1
.line	259	call         r10     2     2
.line	259	gettabup     r11    u1    k3 ; k3 = "table"
.line	259	gettable     r11   r11    k4 ; k4 = "concat"
.line	259	newtable     r12     2     0
.line	259	getupval     r13    u0
.line	259	loadk        r14    k5 ; k5 = 0
.line	259	loadk        r15   k47 ; k47 = 80
.line	259	loadk        r16   k48 ; k48 = 196
.line	259	loadk        r17   k49 ; k49 = 117
.line	259	loadk        r18   k50 ; k50 = 181
.line	259	loadk        r19   k33 ; k33 = 210
.line	259	loadk        r20   k51 ; k51 = 25
.line	259	loadk        r21   k52 ; k52 = 87
.line	259	loadk        r22   k53 ; k53 = 187
.line	259	loadk        r23   k54 ; k54 = 201
.line	259	loadk        r24   k55 ; k55 = 102
.line	259	loadk        r25   k56 ; k56 = 21
.line	259	loadk        r26   k57 ; k57 = 209
.line	259	loadk        r27   k58 ; k58 = 157
.line	259	loadk        r28   k46 ; k46 = 79
.line	259	call         r13    16     2
.line	259	move         r14    r5
.line	259	setlist      r12     2     1
.line	259	call         r11     2     2
.line	259	gettabup     r12    u1    k3 ; k3 = "table"
.line	259	gettable     r12   r12    k4 ; k4 = "concat"
.line	259	newtable     r13     2     0
.line	259	getupval     r14    u0
.line	259	loadk        r15   k31 ; k31 = 23
.line	259	loadk        r16   k32 ; k32 = 84
.line	259	loadk        r17   k33 ; k33 = 210
.line	259	loadk        r18   k34 ; k34 = 119
.line	259	loadk        r19   k59 ; k59 = 150
.line	259	loadk        r20   k41 ; k41 = 205
.line	259	loadk        r21   k60 ; k60 = 38
.line	259	loadk        r22   k29 ; k29 = 85
.line	259	loadk        r23   k61 ; k61 = 190
.line	259	loadk        r24   k62 ; k62 = 243
.line	259	loadk        r25   k63 ; k63 = 73
.line	259	loadk        r26   k64 ; k64 = 14
.line	259	loadk        r27   k41 ; k41 = 205
.line	259	call         r14    14     2
.line	259	move         r15    r5
.line	259	setlist      r13     2     1
.line	259	call         r12     2     2
.line	259	gettable     r13    r0    r6
.line	259	test         r13     0
.line	259	jmp            0  l185
.line	259	gettable     r13    r0   k65 ; k65 = "EmoteImageArray"
.line	259	self         r13   r13   k66 ; k66 = "Add"
.line	259	gettable     r15    r0    r6
.line	259	call         r13     3     1
.label	l185
.line	259	gettable     r13    r0    r7
.line	259	test         r13     0
.line	259	jmp            0  l192
.line	259	gettable     r13    r0   k67 ; k67 = "SlotSwitcherArray"
.line	259	self         r13   r13   k66 ; k66 = "Add"
.line	259	gettable     r15    r0    r7
.line	259	call         r13     3     1
.label	l192
.line	259	gettable     r13    r0    r8
.line	259	test         r13     0
.line	259	jmp            0  l199
.line	259	gettable     r13    r0   k68 ; k68 = "EmoteNameArray"
.line	259	self         r13   r13   k66 ; k66 = "Add"
.line	259	gettable     r15    r0    r8
.line	259	call         r13     3     1
.label	l199
.line	259	gettable     r13    r0    r9
.line	259	test         r13     0
.line	259	jmp            0  l206
.line	259	gettable     r13    r0   k69 ; k69 = "LockImageArray"
.line	259	self         r13   r13   k66 ; k66 = "Add"
.line	259	gettable     r15    r0    r9
.line	259	call         r13     3     1
.label	l206
.line	259	gettable     r13    r0    r9
.line	259	test         r13     0
.line	259	jmp            0  l213
.line	259	gettable     r13    r0   k70 ; k70 = "EmoteEffectSwitcherA" (truncated)
.line	259	self         r13   r13   k66 ; k66 = "Add"
.line	259	gettable     r15    r0   r10
.line	259	call         r13     3     1
.label	l213
.line	259	gettable     r13    r0   r11
.line	259	test         r13     0
.line	259	jmp            0  l220
.line	259	gettable     r13    r0   k71 ; k71 = "CDPanelArray"
.line	259	self         r13   r13   k66 ; k66 = "Add"
.line	259	gettable     r15    r0   r11
.line	259	call         r13     3     1
.label	l220
.line	259	gettable     r13    r0   r12
.line	259	test         r13     0
.line	259	jmp            0  l227
.line	259	gettable     r13    r0   k72 ; k72 = "CDTextArray"
.line	259	self         r13   r13   k66 ; k66 = "Add"
.line	259	gettable     r15    r0   r12
.line	259	call         r13     3     1
.label	l227
.line	259	move          r0    r0
.line	259	return        r0     1
.line	259	move          r0    r0
.line	259	return        r0     1

.function	main/f16

.source	null
.linedefined	319
.lastlinedefined	322
.numparams	1
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	0	false

.constant	k0	"RefreshEmote"
.constant	k1	"AddCommonEvent"
.constant	k2	"EVENTTYPE_INGAME_BACKPACK"
.constant	k3	L"EVENTID_BACKPACK_SINGLE_ITEM_UPDATED_EMOTE_22"

.line	319	self          r1    r0    k0 ; k0 = "RefreshEmote"
.line	319	call          r1     2     1
.line	319	self          r1    r0    k1 ; k1 = "AddCommonEvent"
.line	319	gettabup      r3    u0    k2 ; k2 = "EVENTTYPE_INGAME_BAC" (truncated)
.line	319	gettabup      r4    u0    k3 ; k3 = L"EVENTID_BACKPACK_SIN" (truncated)
.line	319	gettable      r5    r0    k0 ; k0 = "RefreshEmote"
.line	319	move          r6    r0
.line	319	call          r1     6     1
.line	319	return        r0     1
.line	319	move          r0    r0
.line	319	move          r0    r0
.line	319	move          r0    r0
.line	319	move          r0    r0
.line	319	return        r0     1

.function	main/f17

.source	null
.linedefined	324
.lastlinedefined	419
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	19	true
.upvalue	"U3"	23	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	18
.constant	k3	68
.constant	k4	195
.constant	k5	96
.constant	k6	191
.constant	k7	228
.constant	k8	49
.constant	k9	70
.constant	k10	167
.constant	k11	201
.constant	k12	121
.constant	k13	57
.constant	k14	251
.constant	k15	182
.constant	k16	126
.constant	k17	130
.constant	k18	225
.constant	k19	100
.constant	k20	188
.constant	k21	65
.constant	k22	226
.constant	k23	81
.constant	k24	69
.constant	k25	172
.constant	k26	206
.constant	k27	54
.constant	k28	231
.constant	k29	153
.constant	k30	97
.constant	k31	198
.constant	k32	125
.constant	k33	"CurrentShowState"
.constant	k34	"slua_GameFrontendHUD"
.constant	k35	"GetPlayerController"
.constant	k36	"WidgetSwitcher_Bubble"
.constant	k37	"SetActiveWidgetIndex"
.constant	k38	0
.constant	k39	"WidgetSwitcher_Pet"
.constant	k40	"WidgetSwitcher_Emote"
.constant	k41	"WidgetSwitcher_Collection"
.constant	k42	"WidgetSwitcher_Flaunt"
.constant	k43	"WidgetSwitcher_Robot"
.constant	k44	"pairs"
.constant	k45	"EmoteEffectSwitcherArray"
.constant	k46	"slua"
.constant	k47	"isValid"
.constant	k48	"SetWidgetVisibility"
.constant	k49	"UEnums"
.constant	k50	"ESlateVisibility"
.constant	k51	"Collapsed"
.constant	k52	"LockImageArray"
.constant	k53	"CDPanelArray"
.constant	k54	"RefreshCDInfoTimer"
.constant	k55	"AddTimerLoop"
.constant	k56	"TIMER_INFINITE"
.constant	k57	1
.constant	k58	"IsInPetSpectator"
.constant	k59	"CanvasPanel_Pages"
.constant	k60	"GetPetSpectatorComp"
.constant	k61	"GetCurrentSpectatorPetID"
.constant	k62	"MiniTvExpression"
.constant	k63	"PetExpression"
.constant	k64	"SelfHitTestInvisible"
.constant	k65	"IsSocialIsland"
.constant	k66	"Button_Bubble_01"
.constant	k67	"Visible"
.constant	k68	"Button_Bubble_02"
.constant	k69	"CanvasPanel_BubblePage"
.constant	k70	"NeedHidePetExpression"
.constant	k71	"table"
.constant	k72	"concat"
.constant	k73	13
.constant	k74	84
.constant	k75	207
.constant	k76	103
.constant	k77	156
.constant	k78	200
.constant	k79	45
.constant	k80	83
.constant	k81	133
.constant	k82	15
.constant	k83	234
.constant	k84	169
.constant	k85	98
.constant	k86	221
.constant	k87	192
.constant	k88	114
.constant	k89	179
.constant	k90	92
.constant	k91	74
.constant	k92	223
.constant	k93	99
.constant	k94	161
.constant	k95	244
.constant	k96	115
.constant	k97	62
.constant	k98	101
.constant	k99	220
.constant	k100	230
.constant	k101	105
.constant	k102	186
.constant	k103	242
.constant	k104	90
.constant	k105	127
.constant	k106	44
.constant	k107	95
.constant	k108	"WidgetSwitcher_Center"
.constant	k109	"SpectatorPetID"
.constant	k110	"SubsystemMgr"
.constant	k111	"Get"
.constant	k112	10
.constant	k113	205
.constant	k114	185
.constant	k115	196
.constant	k116	26
.constant	k117	202
.constant	k118	47
.constant	k119	193
.constant	k120	203
.constant	k121	174
.constant	k122	86
.constant	k123	73
.constant	k124	"bIsIngameSelfieMode"
.constant	k125	"Button_CheckGun"
.constant	k126	"Button_Left"
.constant	k127	"Button_Right"
.constant	k128	"Expression"
.constant	k129	"RefreshEmote"
.constant	k130	"Bubble"
.constant	k131	"RefreshBubble"
.constant	k132	"RefreshPetExpression"
.constant	k133	"Collection"
.constant	k134	"RefreshCollection"
.constant	k135	"Flaunt"
.constant	k136	"RefreshFlaunt"
.constant	k137	"RefreshMiniTvExpression"
.constant	k138	"RefreshSwitchButtonState"
.constant	k139	"FeatureButtonRefresh"

.line	324	gettabup      r1    u0    k0 ; k0 = "print"
.line	324	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	324	test          r2     0
.line	324	jmp            0   l41
.line	324	getupval      r2    u1
.line	324	loadk         r3    k2 ; k2 = 18
.line	324	loadk         r4    k3 ; k3 = 68
.line	324	loadk         r5    k4 ; k4 = 195
.line	324	loadk         r6    k5 ; k5 = 96
.line	324	loadk         r7    k6 ; k6 = 191
.line	324	loadk         r8    k7 ; k7 = 228
.line	324	loadk         r9    k8 ; k8 = 49
.line	324	loadk        r10    k9 ; k9 = 70
.line	324	loadk        r11   k10 ; k10 = 167
.line	324	loadk        r12   k11 ; k11 = 201
.line	324	loadk        r13   k12 ; k12 = 121
.line	324	loadk        r14   k13 ; k13 = 57
.line	324	loadk        r15   k14 ; k14 = 251
.line	324	loadk        r16   k15 ; k15 = 182
.line	324	loadk        r17   k16 ; k16 = 126
.line	324	loadk        r18   k17 ; k17 = 130
.line	324	loadk        r19   k18 ; k18 = 225
.line	324	loadk        r20   k19 ; k19 = 100
.line	324	loadk        r21   k20 ; k20 = 188
.line	324	loadk        r22   k21 ; k21 = 65
.line	324	loadk        r23   k21 ; k21 = 65
.line	324	loadk        r24   k22 ; k22 = 226
.line	324	loadk        r25   k23 ; k23 = 81
.line	324	loadk        r26   k24 ; k24 = 69
.line	324	loadk        r27   k25 ; k25 = 172
.line	324	loadk        r28   k26 ; k26 = 206
.line	324	loadk        r29   k12 ; k12 = 121
.line	324	loadk        r30   k27 ; k27 = 54
.line	324	loadk        r31   k28 ; k28 = 231
.line	324	loadk        r32   k29 ; k29 = 153
.line	324	loadk        r33   k30 ; k30 = 97
.line	324	loadk        r34   k31 ; k31 = 198
.line	324	loadk        r35   k31 ; k31 = 198
.line	324	loadk        r36   k32 ; k32 = 125
.line	324	call          r2    35     2
.label	l41
.line	324	gettable      r3    r0   k33 ; k33 = "CurrentShowState"
.line	324	call          r1     3     1
.line	324	gettabup      r1    u0   k34 ; k34 = "slua_GameFrontendHUD"
.line	324	self          r1    r1   k35 ; k35 = "GetPlayerController"
.line	324	call          r1     2     2
.line	324	gettable      r2    r0   k36 ; k36 = "WidgetSwitcher_Bubbl" (truncated)
.line	324	self          r2    r2   k37 ; k37 = "SetActiveWidgetIndex"
.line	324	loadk         r4   k38 ; k38 = 0
.line	324	call          r2     3     1
.line	324	gettable      r2    r0   k39 ; k39 = "WidgetSwitcher_Pet"
.line	324	self          r2    r2   k37 ; k37 = "SetActiveWidgetIndex"
.line	324	loadk         r4   k38 ; k38 = 0
.line	324	call          r2     3     1
.line	324	gettable      r2    r0   k40 ; k40 = "WidgetSwitcher_Emote"
.line	324	self          r2    r2   k37 ; k37 = "SetActiveWidgetIndex"
.line	324	loadk         r4   k38 ; k38 = 0
.line	324	call          r2     3     1
.line	324	gettable      r2    r0   k41 ; k41 = "WidgetSwitcher_Colle" (truncated)
.line	324	self          r2    r2   k37 ; k37 = "SetActiveWidgetIndex"
.line	324	loadk         r4   k38 ; k38 = 0
.line	324	call          r2     3     1
.line	324	gettable      r2    r0   k42 ; k42 = "WidgetSwitcher_Flaun" (truncated)
.line	324	self          r2    r2   k37 ; k37 = "SetActiveWidgetIndex"
.line	324	loadk         r4   k38 ; k38 = 0
.line	324	call          r2     3     1
.line	324	gettable      r2    r0   k43 ; k43 = "WidgetSwitcher_Robot"
.line	324	self          r2    r2   k37 ; k37 = "SetActiveWidgetIndex"
.line	324	loadk         r4   k38 ; k38 = 0
.line	324	call          r2     3     1
.line	324	gettabup      r2    u0   k44 ; k44 = "pairs"
.line	324	gettable      r3    r0   k45 ; k45 = "EmoteEffectSwitcherA" (truncated)
.line	324	call          r2     2     4
.line	324	jmp            0   l85
.line	324	gettabup      r7    u0   k46 ; k46 = "slua"
.line	324	gettable      r7    r7   k47 ; k47 = "isValid"
.line	324	move          r8    r6
.line	324	call          r7     2     2
.line	324	test          r7     0
.line	324	jmp            0   l85
.line	324	self          r7    r6   k48 ; k48 = "SetWidgetVisibility"
.line	324	gettabup      r9    u0   k49 ; k49 = "UEnums"
.line	324	gettable      r9    r9   k50 ; k50 = "ESlateVisibility"
.line	324	gettable      r9    r9   k51 ; k51 = "Collapsed"
.line	324	call          r7     3     1
.label	l85
.line	324	move          r0    r0
.line	324	move          r0    r0
.line	324	gettabup      r2    u0   k44 ; k44 = "pairs"
.line	324	gettable      r3    r0   k52 ; k52 = "LockImageArray"
.line	324	call          r2     2     4
.line	324	jmp            0   l98
.line	324	test          r6     0
.line	324	jmp            0   l98
.line	324	self          r7    r6   k48 ; k48 = "SetWidgetVisibility"
.line	324	gettabup      r9    u0   k49 ; k49 = "UEnums"
.line	324	gettable      r9    r9   k50 ; k50 = "ESlateVisibility"
.line	324	gettable      r9    r9   k51 ; k51 = "Collapsed"
.line	324	call          r7     3     1
.label	l98
.line	324	move          r0    r0
.line	324	move          r0    r0
.line	324	gettabup      r2    u0   k44 ; k44 = "pairs"
.line	324	gettable      r3    r0   k53 ; k53 = "CDPanelArray"
.line	324	call          r2     2     4
.line	324	jmp            0  l111
.line	324	test          r6     0
.line	324	jmp            0  l111
.line	324	self          r7    r6   k48 ; k48 = "SetWidgetVisibility"
.line	324	gettabup      r9    u0   k49 ; k49 = "UEnums"
.line	324	gettable      r9    r9   k50 ; k50 = "ESlateVisibility"
.line	324	gettable      r9    r9   k51 ; k51 = "Collapsed"
.line	324	call          r7     3     1
.label	l111
.line	324	move          r0    r0
.line	324	move          r0    r0
.line	324	gettable      r2    r0   k54 ; k54 = "RefreshCDInfoTimer"
.line	324	test          r2     1
.line	324	jmp            0  l123
.line	324	self          r2    r0   k55 ; k55 = "AddTimerLoop"
.line	324	loadk         r4   k38 ; k38 = 0
.line	324	closure       r5    f0
.line	324	gettabup      r6    u0   k56 ; k56 = "TIMER_INFINITE"
.line	324	loadk         r7   k57 ; k57 = 1
.line	324	call          r2     6     2
.line	324	settable      r0   k54    r2 ; k54 = "RefreshCDInfoTimer"
.label	l123
.line	324	gettabup      r2    u0   k46 ; k46 = "slua"
.line	324	gettable      r2    r2   k47 ; k47 = "isValid"
.line	324	move          r3    r1
.line	324	call          r2     2     2
.line	324	test          r2     0
.line	324	jmp            0  l164
.line	324	gettable      r2    r1   k58 ; k58 = "IsInPetSpectator"
.line	324	test          r2     0
.line	324	jmp            0  l164
.line	324	self          r2    r1   k58 ; k58 = "IsInPetSpectator"
.line	324	call          r2     2     2
.line	324	test          r2     0
.line	324	jmp            0  l164
.line	324	gettable      r2    r0   k59 ; k59 = "CanvasPanel_Pages"
.line	324	self          r2    r2   k48 ; k48 = "SetWidgetVisibility"
.line	324	gettabup      r4    u0   k49 ; k49 = "UEnums"
.line	324	gettable      r4    r4   k50 ; k50 = "ESlateVisibility"
.line	324	gettable      r4    r4   k51 ; k51 = "Collapsed"
.line	324	call          r2     3     1
.line	324	gettable      r2    r1   k60 ; k60 = "GetPetSpectatorComp"
.line	324	test          r2     0
.line	324	jmp            0  l147
.line	324	self          r2    r1   k60 ; k60 = "GetPetSpectatorComp"
.line	324	call          r2     2     2
.label	l147
.line	324	gettabup      r3    u0   k46 ; k46 = "slua"
.line	324	gettable      r3    r3   k47 ; k47 = "isValid"
.line	324	move          r4    r2
.line	324	call          r3     2     2
.line	324	test          r3     0
.line	324	jmp            0  l161
.line	324	self          r3    r2   k61 ; k61 = "GetCurrentSpectatorP" (truncated)
.line	324	call          r3     2     2
.line	324	getupval      r4    u2
.line	324	eq             0    r3    r4
.line	324	jmp            0  l161
.line	324	gettabup      r3    u3   k62 ; k62 = "MiniTvExpression"
.line	324	settable      r0   k33    r3 ; k33 = "CurrentShowState"
.line	324	jmp            0  l211
.label	l161
.line	324	gettabup      r3    u3   k63 ; k63 = "PetExpression"
.line	324	settable      r0   k33    r3 ; k33 = "CurrentShowState"
.line	324	jmp            0  l211
.label	l164
.line	324	gettable      r2    r0   k59 ; k59 = "CanvasPanel_Pages"
.line	324	self          r2    r2   k48 ; k48 = "SetWidgetVisibility"
.line	324	gettabup      r4    u0   k49 ; k49 = "UEnums"
.line	324	gettable      r4    r4   k50 ; k50 = "ESlateVisibility"
.line	324	gettable      r4    r4   k64 ; k64 = "SelfHitTestInvisible"
.line	324	call          r2     3     1
.line	324	self          r2    r0   k65 ; k65 = "IsSocialIsland"
.line	324	call          r2     2     2
.line	324	test          r2     0
.line	324	jmp            0  l193
.line	324	gettable      r2    r0   k66 ; k66 = "Button_Bubble_01"
.line	324	self          r2    r2   k48 ; k48 = "SetWidgetVisibility"
.line	324	gettabup      r4    u0   k49 ; k49 = "UEnums"
.line	324	gettable      r4    r4   k50 ; k50 = "ESlateVisibility"
.line	324	gettable      r4    r4   k67 ; k67 = "Visible"
.line	324	call          r2     3     1
.line	324	gettable      r2    r0   k68 ; k68 = "Button_Bubble_02"
.line	324	self          r2    r2   k48 ; k48 = "SetWidgetVisibility"
.line	324	gettabup      r4    u0   k49 ; k49 = "UEnums"
.line	324	gettable      r4    r4   k50 ; k50 = "ESlateVisibility"
.line	324	gettable      r4    r4   k67 ; k67 = "Visible"
.line	324	call          r2     3     1
.line	324	gettable      r2    r0   k69 ; k69 = "CanvasPanel_BubblePa" (truncated)
.line	324	self          r2    r2   k48 ; k48 = "SetWidgetVisibility"
.line	324	gettabup      r4    u0   k49 ; k49 = "UEnums"
.line	324	gettable      r4    r4   k50 ; k50 = "ESlateVisibility"
.line	324	gettable      r4    r4   k64 ; k64 = "SelfHitTestInvisible"
.line	324	call          r2     3     1
.line	324	jmp            0  l211
.label	l193
.line	324	gettable      r2    r0   k66 ; k66 = "Button_Bubble_01"
.line	324	self          r2    r2   k48 ; k48 = "SetWidgetVisibility"
.line	324	gettabup      r4    u0   k49 ; k49 = "UEnums"
.line	324	gettable      r4    r4   k50 ; k50 = "ESlateVisibility"
.line	324	gettable      r4    r4   k51 ; k51 = "Collapsed"
.line	324	call          r2     3     1
.line	324	gettable      r2    r0   k68 ; k68 = "Button_Bubble_02"
.line	324	self          r2    r2   k48 ; k48 = "SetWidgetVisibility"
.line	324	gettabup      r4    u0   k49 ; k49 = "UEnums"
.line	324	gettable      r4    r4   k50 ; k50 = "ESlateVisibility"
.line	324	gettable      r4    r4   k51 ; k51 = "Collapsed"
.line	324	call          r2     3     1
.line	324	gettable      r2    r0   k69 ; k69 = "CanvasPanel_BubblePa" (truncated)
.line	324	self          r2    r2   k48 ; k48 = "SetWidgetVisibility"
.line	324	gettabup      r4    u0   k49 ; k49 = "UEnums"
.line	324	gettable      r4    r4   k50 ; k50 = "ESlateVisibility"
.line	324	gettable      r4    r4   k51 ; k51 = "Collapsed"
.line	324	call          r2     3     1
.label	l211
.line	324	self          r2    r0   k70 ; k70 = "NeedHidePetExpressio" (truncated)
.line	324	call          r2     2     2
.line	324	test          r2     0
.line	324	jmp            0  l271
.line	324	gettabup      r2    u0    k0 ; k0 = "print"
.line	324	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	324	test          r3     0
.line	324	jmp            0  l270
.line	324	gettabup      r3    u0   k71 ; k71 = "table"
.line	324	gettable      r3    r3   k72 ; k72 = "concat"
.line	324	newtable      r4     1     0
.line	324	getupval      r5    u1
.line	324	loadk         r6   k73 ; k73 = 13
.line	324	loadk         r7   k74 ; k74 = 84
.line	324	loadk         r8   k75 ; k75 = 207
.line	324	loadk         r9   k76 ; k76 = 103
.line	324	loadk        r10   k77 ; k77 = 156
.line	324	loadk        r11   k78 ; k78 = 200
.line	324	loadk        r12   k79 ; k79 = 45
.line	324	loadk        r13   k80 ; k80 = 83
.line	324	loadk        r14   k81 ; k81 = 133
.line	324	loadk        r15   k11 ; k11 = 201
.line	324	loadk        r16   k16 ; k16 = 126
.line	324	loadk        r17   k82 ; k82 = 15
.line	324	loadk        r18   k83 ; k83 = 234
.line	324	loadk        r19   k84 ; k84 = 169
.line	324	loadk        r20   k85 ; k85 = 98
.line	324	loadk        r21   k86 ; k86 = 221
.line	324	loadk        r22   k87 ; k87 = 192
.line	324	loadk        r23   k88 ; k88 = 114
.line	324	loadk        r24   k89 ; k89 = 179
.line	324	loadk        r25   k90 ; k90 = 92
.line	324	loadk        r26   k91 ; k91 = 74
.line	324	loadk        r27   k92 ; k92 = 223
.line	324	loadk        r28   k90 ; k90 = 92
.line	324	loadk        r29   k93 ; k93 = 99
.line	324	loadk        r30   k94 ; k94 = 161
.line	324	loadk        r31   k95 ; k95 = 244
.line	324	loadk        r32   k96 ; k96 = 115
.line	324	loadk        r33   k97 ; k97 = 62
.line	324	loadk        r34   k28 ; k28 = 231
.line	324	loadk        r35   k29 ; k29 = 153
.line	324	loadk        r36   k98 ; k98 = 101
.line	324	loadk        r37   k99 ; k99 = 220
.line	324	loadk        r38  k100 ; k100 = 230
.line	324	loadk        r39  k101 ; k101 = 105
.line	324	loadk        r40  k102 ; k102 = 186
.line	324	loadk        r41   k23 ; k23 = 81
.line	324	loadk        r42   k23 ; k23 = 81
.line	324	loadk        r43  k103 ; k103 = 242
.line	324	loadk        r44  k104 ; k104 = 90
.line	324	loadk        r45  k105 ; k105 = 127
.line	324	call          r5    41     2
.line	324	getupval      r6    u1
.line	324	loadk         r7  k106 ; k106 = 44
.line	324	loadk         r8  k107 ; k107 = 95
.line	324	call          r6     3     0
.line	324	setlist       r4     0     1
.line	324	call          r3     2     2
.label	l270
.line	324	call          r2     2     1
.label	l271
.line	324	gettable      r2    r0  k108 ; k108 = "WidgetSwitcher_Cente" (truncated)
.line	324	self          r2    r2   k37 ; k37 = "SetActiveWidgetIndex"
.line	324	loadk         r4   k38 ; k38 = 0
.line	324	call          r2     3     1
.line	324	gettabup      r2    u0   k46 ; k46 = "slua"
.line	324	gettable      r2    r2   k47 ; k47 = "isValid"
.line	324	move          r3    r1
.line	324	call          r2     2     2
.line	324	test          r2     0
.line	324	jmp            0  l286
.line	324	gettable      r2    r1   k58 ; k58 = "IsInPetSpectator"
.line	324	test          r2     0
.line	324	jmp            0  l286
.line	324	self          r2    r1   k58 ; k58 = "IsInPetSpectator"
.line	324	call          r2     2     2
.label	l286
.line	324	loadbool      r3     0     0
.line	324	test          r2     0
.line	324	jmp            0  l305
.line	324	gettable      r4    r1   k60 ; k60 = "GetPetSpectatorComp"
.line	324	test          r4     0
.line	324	jmp            0  l294
.line	324	self          r4    r1   k60 ; k60 = "GetPetSpectatorComp"
.line	324	call          r4     2     2
.label	l294
.line	324	gettabup      r5    u0   k46 ; k46 = "slua"
.line	324	gettable      r5    r5   k47 ; k47 = "isValid"
.line	324	move          r6    r4
.line	324	call          r5     2     2
.line	324	test          r5     0
.line	324	jmp            0  l305
.line	324	gettable      r5    r4  k109 ; k109 = "SpectatorPetID"
.line	324	getupval      r6    u2
.line	324	eq             0    r5    r6
.line	324	jmp            0  l305
.line	324	loadbool      r3     1     0
.label	l305
.line	324	test          r2     0
.line	324	jmp            0  l316
.line	324	test          r3     1
.line	324	jmp            0  l316
.line	324	gettable      r4    r0  k108 ; k108 = "WidgetSwitcher_Cente" (truncated)
.line	324	self          r4    r4   k48 ; k48 = "SetWidgetVisibility"
.line	324	gettabup      r6    u0   k49 ; k49 = "UEnums"
.line	324	gettable      r6    r6   k50 ; k50 = "ESlateVisibility"
.line	324	gettable      r6    r6   k51 ; k51 = "Collapsed"
.line	324	call          r4     3     1
.line	324	jmp            0  l322
.label	l316
.line	324	gettable      r4    r0  k108 ; k108 = "WidgetSwitcher_Cente" (truncated)
.line	324	self          r4    r4   k48 ; k48 = "SetWidgetVisibility"
.line	324	gettabup      r6    u0   k49 ; k49 = "UEnums"
.line	324	gettable      r6    r6   k50 ; k50 = "ESlateVisibility"
.line	324	gettable      r6    r6   k64 ; k64 = "SelfHitTestInvisible"
.line	324	call          r4     3     1
.label	l322
.line	324	gettabup      r4    u0  k110 ; k110 = "SubsystemMgr"
.line	324	self          r4    r4  k111 ; k111 = "Get"
.line	324	getupval      r6    u1
.line	324	loadk         r7  k112 ; k112 = 10
.line	324	loadk         r8  k107 ; k107 = 95
.line	324	loadk         r9  k113 ; k113 = 205
.line	324	loadk        r10   k85 ; k85 = 98
.line	324	loadk        r11  k114 ; k114 = 185
.line	324	loadk        r12  k115 ; k115 = 196
.line	324	loadk        r13  k116 ; k116 = 26
.line	324	loadk        r14   k80 ; k80 = 83
.line	324	loadk        r15  k114 ; k114 = 185
.line	324	loadk        r16  k117 ; k117 = 202
.line	324	loadk        r17   k93 ; k93 = 99
.line	324	loadk        r18  k118 ; k118 = 47
.line	324	loadk        r19  k119 ; k119 = 193
.line	324	loadk        r20   k25 ; k25 = 172
.line	324	loadk        r21   k88 ; k88 = 114
.line	324	loadk        r22  k120 ; k120 = 203
.line	324	loadk        r23  k117 ; k117 = 202
.line	324	loadk        r24   k88 ; k88 = 114
.line	324	loadk        r25  k121 ; k121 = 174
.line	324	loadk        r26  k122 ; k122 = 86
.line	324	loadk        r27  k123 ; k123 = 73
.line	324	call          r6    22     2
.line	324	call          r4     3     2
.line	324	test          r4     0
.line	324	jmp            0  l360
.line	324	gettable      r5    r4  k124 ; k124 = "bIsIngameSelfieMode"
.line	324	test          r5     0
.line	324	jmp            0  l360
.line	324	gettable      r5    r0  k125 ; k125 = "Button_CheckGun"
.line	324	self          r5    r5   k48 ; k48 = "SetWidgetVisibility"
.line	324	gettabup      r7    u0   k49 ; k49 = "UEnums"
.line	324	gettable      r7    r7   k50 ; k50 = "ESlateVisibility"
.line	324	gettable      r7    r7   k51 ; k51 = "Collapsed"
.line	324	call          r5     3     1
.line	324	jmp            0  l366
.label	l360
.line	324	gettable      r5    r0  k125 ; k125 = "Button_CheckGun"
.line	324	self          r5    r5   k48 ; k48 = "SetWidgetVisibility"
.line	324	gettabup      r7    u0   k49 ; k49 = "UEnums"
.line	324	gettable      r7    r7   k50 ; k50 = "ESlateVisibility"
.line	324	gettable      r7    r7   k67 ; k67 = "Visible"
.line	324	call          r5     3     1
.label	l366
.line	324	gettable      r5    r0  k126 ; k126 = "Button_Left"
.line	324	self          r5    r5   k48 ; k48 = "SetWidgetVisibility"
.line	324	gettabup      r7    u0   k49 ; k49 = "UEnums"
.line	324	gettable      r7    r7   k50 ; k50 = "ESlateVisibility"
.line	324	gettable      r7    r7   k51 ; k51 = "Collapsed"
.line	324	call          r5     3     1
.line	324	gettable      r5    r0  k127 ; k127 = "Button_Right"
.line	324	self          r5    r5   k48 ; k48 = "SetWidgetVisibility"
.line	324	gettabup      r7    u0   k49 ; k49 = "UEnums"
.line	324	gettable      r7    r7   k50 ; k50 = "ESlateVisibility"
.line	324	gettable      r7    r7   k51 ; k51 = "Collapsed"
.line	324	call          r5     3     1
.line	324	gettable      r5    r0   k33 ; k33 = "CurrentShowState"
.line	324	gettabup      r6    u3  k128 ; k128 = "Expression"
.line	324	eq             0    r5    r6
.line	324	jmp            0  l389
.line	324	gettable      r5    r0   k40 ; k40 = "WidgetSwitcher_Emote"
.line	324	self          r5    r5   k37 ; k37 = "SetActiveWidgetIndex"
.line	324	loadk         r7   k57 ; k57 = 1
.line	324	call          r5     3     1
.line	324	self          r5    r0  k129 ; k129 = "RefreshEmote"
.line	324	call          r5     2     1
.line	324	jmp            0  l443
.label	l389
.line	324	gettable      r5    r0   k33 ; k33 = "CurrentShowState"
.line	324	gettabup      r6    u3  k130 ; k130 = "Bubble"
.line	324	eq             0    r5    r6
.line	324	jmp            0  l400
.line	324	gettable      r5    r0   k36 ; k36 = "WidgetSwitcher_Bubbl" (truncated)
.line	324	self          r5    r5   k37 ; k37 = "SetActiveWidgetIndex"
.line	324	loadk         r7   k57 ; k57 = 1
.line	324	call          r5     3     1
.line	324	self          r5    r0  k131 ; k131 = "RefreshBubble"
.line	324	call          r5     2     1
.line	324	jmp            0  l443
.label	l400
.line	324	gettable      r5    r0   k33 ; k33 = "CurrentShowState"
.line	324	gettabup      r6    u3   k63 ; k63 = "PetExpression"
.line	324	eq             0    r5    r6
.line	324	jmp            0  l411
.line	324	gettable      r5    r0   k39 ; k39 = "WidgetSwitcher_Pet"
.line	324	self          r5    r5   k37 ; k37 = "SetActiveWidgetIndex"
.line	324	loadk         r7   k57 ; k57 = 1
.line	324	call          r5     3     1
.line	324	self          r5    r0  k132 ; k132 = "RefreshPetExpression"
.line	324	call          r5     2     1
.line	324	jmp            0  l443
.label	l411
.line	324	gettable      r5    r0   k33 ; k33 = "CurrentShowState"
.line	324	gettabup      r6    u3  k133 ; k133 = "Collection"
.line	324	eq             0    r5    r6
.line	324	jmp            0  l422
.line	324	gettable      r5    r0   k41 ; k41 = "WidgetSwitcher_Colle" (truncated)
.line	324	self          r5    r5   k37 ; k37 = "SetActiveWidgetIndex"
.line	324	loadk         r7   k57 ; k57 = 1
.line	324	call          r5     3     1
.line	324	self          r5    r0  k134 ; k134 = "RefreshCollection"
.line	324	call          r5     2     1
.line	324	jmp            0  l443
.label	l422
.line	324	gettable      r5    r0   k33 ; k33 = "CurrentShowState"
.line	324	gettabup      r6    u3  k135 ; k135 = "Flaunt"
.line	324	eq             0    r5    r6
.line	324	jmp            0  l433
.line	324	gettable      r5    r0   k42 ; k42 = "WidgetSwitcher_Flaun" (truncated)
.line	324	self          r5    r5   k37 ; k37 = "SetActiveWidgetIndex"
.line	324	loadk         r7   k57 ; k57 = 1
.line	324	call          r5     3     1
.line	324	self          r5    r0  k136 ; k136 = "RefreshFlaunt"
.line	324	call          r5     2     1
.line	324	jmp            0  l443
.label	l433
.line	324	gettable      r5    r0   k33 ; k33 = "CurrentShowState"
.line	324	gettabup      r6    u3   k62 ; k62 = "MiniTvExpression"
.line	324	eq             0    r5    r6
.line	324	jmp            0  l443
.line	324	gettable      r5    r0   k43 ; k43 = "WidgetSwitcher_Robot"
.line	324	self          r5    r5   k37 ; k37 = "SetActiveWidgetIndex"
.line	324	loadk         r7   k57 ; k57 = 1
.line	324	call          r5     3     1
.line	324	self          r5    r0  k137 ; k137 = "RefreshMiniTvExpress" (truncated)
.line	324	call          r5     2     1
.label	l443
.line	324	self          r5    r0  k138 ; k138 = "RefreshSwitchButtonS" (truncated)
.line	324	call          r5     2     1
.line	324	self          r5    r0  k139 ; k139 = "FeatureButtonRefresh"
.line	324	call          r5     2     1
.line	324	return        r0     1
.line	324	move          r0    r0
.line	324	return        r0     1

.function	main/f17/f0

.source	null
.linedefined	349
.lastlinedefined	351
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	true

.constant	k0	"RefreshCDInternal"

.line	349	getupval      r0    u0
.line	349	self          r0    r0    k0 ; k0 = "RefreshCDInternal"
.line	349	call          r0     2     1
.line	349	return        r0     1
.line	349	move          r0    r0
.line	349	move          r0    r0
.line	349	return        r0     1

.function	main/f18

.source	null
.linedefined	421
.lastlinedefined	451
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	18
.constant	k3	68
.constant	k4	195
.constant	k5	96
.constant	k6	191
.constant	k7	228
.constant	k8	49
.constant	k9	70
.constant	k10	167
.constant	k11	201
.constant	k12	121
.constant	k13	57
.constant	k14	251
.constant	k15	182
.constant	k16	126
.constant	k17	130
.constant	k18	225
.constant	k19	100
.constant	k20	188
.constant	k21	65
.constant	k22	226
.constant	k23	81
.constant	k24	176
.constant	k25	222
.constant	k26	120
.constant	k27	54
.constant	k28	231
.constant	k29	"GameplaySysMgr"
.constant	k30	"require"
.constant	k31	"table"
.constant	k32	"concat"
.constant	k33	4
.constant	k34	80
.constant	k35	199
.constant	k36	102
.constant	k37	152
.constant	k38	212
.constant	k39	40
.constant	k40	24
.constant	k41	110
.constant	k42	208
.constant	k43	184
.constant	k44	99
.constant	k45	221
.constant	k46	254
.constant	k47	190
.constant	k48	29
.constant	k49	240
.constant	k50	84
.constant	k51	149
.constant	k52	123
.constant	k53	35
.constant	k54	172
.constant	k55	138
.constant	k56	111
.constant	k57	218
.constant	k58	198
.constant	k59	63
.constant	k60	141
.constant	k61	66
.constant	k62	89
.constant	k63	122
.constant	k64	34
.constant	k65	72
.constant	k66	249
.constant	k67	236
.constant	k68	46
.constant	k69	"GetSysByName"
.constant	k70	10
.constant	k71	98
.constant	k72	186
.constant	k73	197
.constant	k74	11
.constant	k75	67
.constant	k76	183
.constant	k77	206
.constant	k78	47
.constant	k79	215
.constant	k80	180
.constant	k81	127
.constant	k82	204
.constant	k83	214
.constant	k84	82
.constant	k85	163
.constant	k86	64
.constant	k87	nil
.constant	k88	"uBubbleIDList"
.constant	k89	"GetBubbleIdList"
.constant	k90	"log_tree"
.constant	k91	115
.constant	k92	223
.constant	k93	97
.constant	k94	205
.constant	k95	44
.constant	k96	145
.constant	k97	224
.constant	k98	230
.constant	k99	227
.constant	k100	"pairs"
.constant	k101	"EmoteNameArray"
.constant	k102	"SetText"
.constant	k103	"SlotSwitcherArray"
.constant	k104	"SetActiveWidgetIndex"
.constant	k105	1
.constant	k106	"EmoteImageArray"
.constant	k107	"Get"
.constant	k108	"GetBubbleIconPath"
.constant	k109	0
.constant	k110	32
.constant	k111	93
.constant	k112	213
.constant	k113	103
.constant	k114	69
.constant	k115	185
.constant	k116	217
.constant	k117	107
.constant	k118	21
.constant	k119	79
.constant	k120	193
.constant	k121	86
.constant	k122	83
.constant	k123	75
.constant	k124	109
.constant	k125	235
.constant	k126	51
.constant	k127	238
.constant	k128	"SetTexture"
.constant	k129	"sync"
.constant	k130	false
.constant	k131	"SetColorAndOpacity"
.constant	k132	"FLinearColor"

.line	421	gettabup      r1    u0    k0 ; k0 = "print"
.line	421	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	421	test          r2     0
.line	421	jmp            0   l36
.line	421	getupval      r2    u1
.line	421	loadk         r3    k2 ; k2 = 18
.line	421	loadk         r4    k3 ; k3 = 68
.line	421	loadk         r5    k4 ; k4 = 195
.line	421	loadk         r6    k5 ; k5 = 96
.line	421	loadk         r7    k6 ; k6 = 191
.line	421	loadk         r8    k7 ; k7 = 228
.line	421	loadk         r9    k8 ; k8 = 49
.line	421	loadk        r10    k9 ; k9 = 70
.line	421	loadk        r11   k10 ; k10 = 167
.line	421	loadk        r12   k11 ; k11 = 201
.line	421	loadk        r13   k12 ; k12 = 121
.line	421	loadk        r14   k13 ; k13 = 57
.line	421	loadk        r15   k14 ; k14 = 251
.line	421	loadk        r16   k15 ; k15 = 182
.line	421	loadk        r17   k16 ; k16 = 126
.line	421	loadk        r18   k17 ; k17 = 130
.line	421	loadk        r19   k18 ; k18 = 225
.line	421	loadk        r20   k19 ; k19 = 100
.line	421	loadk        r21   k20 ; k20 = 188
.line	421	loadk        r22   k21 ; k21 = 65
.line	421	loadk        r23   k21 ; k21 = 65
.line	421	loadk        r24   k22 ; k22 = 226
.line	421	loadk        r25   k23 ; k23 = 81
.line	421	loadk        r26    k3 ; k3 = 68
.line	421	loadk        r27   k24 ; k24 = 176
.line	421	loadk        r28   k25 ; k25 = 222
.line	421	loadk        r29   k26 ; k26 = 120
.line	421	loadk        r30   k27 ; k27 = 54
.line	421	loadk        r31   k28 ; k28 = 231
.line	421	call          r2    30     2
.label	l36
.line	421	call          r1     2     1
.line	421	gettabup      r1    u0   k30 ; k30 = "require"
.line	421	gettabup      r2    u0   k31 ; k31 = "table"
.line	421	gettable      r2    r2   k32 ; k32 = "concat"
.line	421	newtable      r3     1     0
.line	421	getupval      r4    u1
.line	421	loadk         r5   k33 ; k33 = 4
.line	421	loadk         r6   k34 ; k34 = 80
.line	421	loadk         r7   k35 ; k35 = 199
.line	421	loadk         r8   k36 ; k36 = 102
.line	421	loadk         r9   k37 ; k37 = 152
.line	421	loadk        r10   k38 ; k38 = 212
.line	421	loadk        r11   k39 ; k39 = 40
.line	421	loadk        r12   k40 ; k40 = 24
.line	421	loadk        r13   k37 ; k37 = 152
.line	421	loadk        r14    k4 ; k4 = 195
.line	421	loadk        r15   k41 ; k41 = 110
.line	421	loadk        r16   k19 ; k19 = 100
.line	421	loadk        r17   k42 ; k42 = 208
.line	421	loadk        r18   k43 ; k43 = 184
.line	421	loadk        r19   k44 ; k44 = 99
.line	421	loadk        r20   k45 ; k45 = 221
.line	421	loadk        r21   k46 ; k46 = 254
.line	421	loadk        r22   k41 ; k41 = 110
.line	421	loadk        r23   k47 ; k47 = 190
.line	421	loadk        r24   k48 ; k48 = 29
.line	421	loadk        r25   k44 ; k44 = 99
.line	421	loadk        r26   k49 ; k49 = 240
.line	421	loadk        r27   k50 ; k50 = 84
.line	421	loadk        r28   k44 ; k44 = 99
.line	421	loadk        r29   k51 ; k51 = 149
.line	421	loadk        r30   k42 ; k42 = 208
.line	421	loadk        r31   k52 ; k52 = 123
.line	421	loadk        r32   k53 ; k53 = 35
.line	421	loadk        r33   k54 ; k54 = 172
.line	421	loadk        r34   k55 ; k55 = 138
.line	421	loadk        r35   k56 ; k56 = 111
.line	421	loadk        r36   k57 ; k57 = 218
.line	421	loadk        r37   k58 ; k58 = 198
.line	421	loadk        r38   k59 ; k59 = 63
.line	421	loadk        r39   k60 ; k60 = 141
.line	421	loadk        r40   k61 ; k61 = 66
.line	421	loadk        r41   k62 ; k62 = 89
.line	421	loadk        r42    k7 ; k7 = 228
.line	421	loadk        r43   k62 ; k62 = 89
.line	421	loadk        r44   k63 ; k63 = 122
.line	421	call          r4    41     2
.line	421	getupval      r5    u1
.line	421	loadk         r6   k64 ; k64 = 34
.line	421	loadk         r7   k65 ; k65 = 72
.line	421	loadk         r8   k66 ; k66 = 249
.line	421	loadk         r9   k63 ; k63 = 122
.line	421	loadk        r10   k10 ; k10 = 167
.line	421	loadk        r11   k67 ; k67 = 236
.line	421	loadk        r12   k68 ; k68 = 46
.line	421	loadk        r13    k3 ; k3 = 68
.line	421	call          r5     9     0
.line	421	setlist       r3     0     1
.line	421	call          r2     2     2
.line	421	call          r1     2     2
.line	421	settabup      u0   k29    r1 ; k29 = "GameplaySysMgr"
.line	421	gettabup      r1    u0   k29 ; k29 = "GameplaySysMgr"
.line	421	gettable      r1    r1   k69 ; k69 = "GetSysByName"
.line	421	getupval      r2    u1
.line	421	loadk         r3   k70 ; k70 = 10
.line	421	loadk         r4   k61 ; k61 = 66
.line	421	loadk         r5   k58 ; k58 = 198
.line	421	loadk         r6   k71 ; k71 = 98
.line	421	loadk         r7   k72 ; k72 = 186
.line	421	loadk         r8   k73 ; k73 = 197
.line	421	loadk         r9   k74 ; k74 = 11
.line	421	loadk        r10   k75 ; k75 = 67
.line	421	loadk        r11   k76 ; k76 = 183
.line	421	loadk        r12   k77 ; k77 = 206
.line	421	loadk        r13   k36 ; k36 = 102
.line	421	loadk        r14   k78 ; k78 = 47
.line	421	loadk        r15   k79 ; k79 = 215
.line	421	loadk        r16   k80 ; k80 = 180
.line	421	loadk        r17   k81 ; k81 = 127
.line	421	loadk        r18   k82 ; k82 = 204
.line	421	loadk        r19   k83 ; k83 = 214
.line	421	loadk        r20   k84 ; k84 = 82
.line	421	loadk        r21   k85 ; k85 = 163
.line	421	loadk        r22   k86 ; k86 = 64
.line	421	call          r2    21     2
.line	421	call          r1     2     2
.line	421	eq             1    r1   k87 ; k87 = nil
.line	421	jmp            0  l248
.line	421	self          r2    r1   k89 ; k89 = "GetBubbleIdList"
.line	421	call          r2     2     2
.line	421	settable      r0   k88    r2 ; k88 = "uBubbleIDList"
.line	421	gettabup      r2    u0   k90 ; k90 = "log_tree"
.line	421	getupval      r3    u1
.line	421	loadk         r4   k27 ; k27 = 54
.line	421	loadk         r5   k91 ; k91 = 115
.line	421	loadk         r6   k92 ; k92 = 223
.line	421	loadk         r7   k93 ; k93 = 97
.line	421	loadk         r8   k15 ; k15 = 182
.line	421	loadk         r9   k94 ; k94 = 205
.line	421	loadk        r10   k95 ; k95 = 44
.line	421	loadk        r11   k81 ; k81 = 127
.line	421	loadk        r12   k96 ; k96 = 145
.line	421	loadk        r13   k97 ; k97 = 224
.line	421	loadk        r14   k44 ; k44 = 99
.line	421	loadk        r15   k13 ; k13 = 57
.line	421	loadk        r16   k98 ; k98 = 230
.line	421	loadk        r17   k99 ; k99 = 227
.line	421	call          r3    15     2
.line	421	gettable      r4    r0   k88 ; k88 = "uBubbleIDList"
.line	421	call          r2     3     1
.line	421	gettabup      r2    u0  k100 ; k100 = "pairs"
.line	421	gettable      r3    r0  k101 ; k101 = "EmoteNameArray"
.line	421	call          r2     2     4
.line	421	jmp            0  l156
.line	421	test          r6     0
.line	421	jmp            0  l156
.line	421	self          r7    r6  k102 ; k102 = "SetText"
.line	421	getupval      r9    u1
.line	421	call          r9     1     2
.line	421	call          r7     3     1
.label	l156
.line	421	move          r0    r0
.line	421	move          r0    r0
.line	421	gettabup      r2    u0  k100 ; k100 = "pairs"
.line	421	gettable      r3    r0  k103 ; k103 = "SlotSwitcherArray"
.line	421	call          r2     2     4
.line	421	jmp            0  l167
.line	421	test          r6     0
.line	421	jmp            0  l167
.line	421	self          r7    r6  k104 ; k104 = "SetActiveWidgetIndex"
.line	421	loadk         r9  k105 ; k105 = 1
.line	421	call          r7     3     1
.label	l167
.line	421	move          r0    r0
.line	421	move          r0    r0
.line	421	gettabup      r2    u0  k100 ; k100 = "pairs"
.line	421	gettable      r3    r0   k88 ; k88 = "uBubbleIDList"
.line	421	call          r2     2     4
.line	421	jmp            0  l246
.line	421	gettable      r7    r0  k106 ; k106 = "EmoteImageArray"
.line	421	self          r7    r7  k107 ; k107 = "Get"
.line	421	sub           r9    r5  k105 ; k105 = 1
.line	421	call          r7     3     2
.line	421	gettable      r8    r0  k103 ; k103 = "SlotSwitcherArray"
.line	421	self          r8    r8  k107 ; k107 = "Get"
.line	421	sub          r10    r5  k105 ; k105 = 1
.line	421	call          r8     3     2
.line	421	gettable      r9    r0  k101 ; k101 = "EmoteNameArray"
.line	421	self          r9    r9  k107 ; k107 = "Get"
.line	421	sub          r11    r5  k105 ; k105 = 1
.line	421	call          r9     3     2
.line	421	self         r10    r1  k108 ; k108 = "GetBubbleIconPath"
.line	421	move         r12    r6
.line	421	call         r10     3     2
.line	421	test          r7     0
.line	421	jmp            0  l246
.line	421	test          r8     0
.line	421	jmp            0  l246
.line	421	test          r9     0
.line	421	jmp            0  l246
.line	421	test         r10     0
.line	421	jmp            0  l246
.line	421	self         r11    r8  k104 ; k104 = "SetActiveWidgetIndex"
.line	421	loadk        r13  k109 ; k109 = 0
.line	421	call         r11     3     1
.line	421	gettabup     r11    u0   k30 ; k30 = "require"
.line	421	getupval     r12    u1
.line	421	loadk        r13  k110 ; k110 = 32
.line	421	loadk        r14  k111 ; k111 = 93
.line	421	loadk        r15    k4 ; k4 = 195
.line	421	loadk        r16   k36 ; k36 = 102
.line	421	loadk        r17   k72 ; k72 = 186
.line	421	loadk        r18  k112 ; k112 = 213
.line	421	loadk        r19  k113 ; k113 = 103
.line	421	loadk        r20  k114 ; k114 = 69
.line	421	loadk        r21  k115 ; k115 = 185
.line	421	loadk        r22  k116 ; k116 = 217
.line	421	loadk        r23  k117 ; k117 = 107
.line	421	loadk        r24  k118 ; k118 = 21
.line	421	loadk        r25   k28 ; k28 = 231
.line	421	loadk        r26   k24 ; k24 = 176
.line	421	loadk        r27  k119 ; k119 = 79
.line	421	loadk        r28   k25 ; k25 = 222
.line	421	loadk        r29  k120 ; k120 = 193
.line	421	loadk        r30    k5 ; k5 = 96
.line	421	loadk        r31   k76 ; k76 = 183
.line	421	loadk        r32  k121 ; k121 = 86
.line	421	loadk        r33  k122 ; k122 = 83
.line	421	loadk        r34   k46 ; k46 = 254
.line	421	loadk        r35  k123 ; k123 = 75
.line	421	loadk        r36  k124 ; k124 = 109
.line	421	loadk        r37  k125 ; k125 = 235
.line	421	loadk        r38   k11 ; k11 = 201
.line	421	loadk        r39   k41 ; k41 = 110
.line	421	loadk        r40  k126 ; k126 = 51
.line	421	loadk        r41  k127 ; k127 = 238
.line	421	call         r12    30     2
.line	421	call         r11     2     2
.line	421	gettable     r12   r11  k128 ; k128 = "SetTexture"
.line	421	move         r13    r7
.line	421	move         r14   r10
.line	421	newtable     r15     0     1
.line	421	settable     r15  k129  k130 ; k130 = false
.line	421	call         r12     4     1
.line	421	self         r12    r7  k131 ; k131 = "SetColorAndOpacity"
.line	421	gettabup     r14    u0  k132 ; k132 = "FLinearColor"
.line	421	loadk        r15  k105 ; k105 = 1
.line	421	loadk        r16  k105 ; k105 = 1
.line	421	loadk        r17  k105 ; k105 = 1
.line	421	loadk        r18  k105 ; k105 = 1
.line	421	call         r14     5     0
.line	421	call         r12     0     1
.label	l246
.line	421	move          r0    r0
.line	421	move          r0    r0
.label	l248
.line	421	return        r0     1
.line	421	gettabup      r3    u0  k102 ; k102 = "SetText"
.line	421	move          r0    r0
.line	421	move          r0    r0
.line	421	move          r0    r0
.line	421	return        r0     1

.function	main/f19

.source	null
.linedefined	453
.lastlinedefined	528
.numparams	1
.is_vararg	0
.maxstacksize	60

.upvalue	"_ENV"	23	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	16	true
.upvalue	"U4"	17	true
.upvalue	"U5"	21	true

.constant	k0	"CurrentShowState"
.constant	k1	"PetExpression"
.constant	k2	"RefreshPetInfo"
.constant	k3	"print"
.constant	k4	"bWriteLog"
.constant	k5	18
.constant	k6	68
.constant	k7	195
.constant	k8	96
.constant	k9	191
.constant	k10	228
.constant	k11	49
.constant	k12	70
.constant	k13	167
.constant	k14	201
.constant	k15	121
.constant	k16	57
.constant	k17	251
.constant	k18	182
.constant	k19	126
.constant	k20	130
.constant	k21	225
.constant	k22	100
.constant	k23	188
.constant	k24	65
.constant	k25	226
.constant	k26	81
.constant	k27	86
.constant	k28	160
.constant	k29	200
.constant	k30	95
.constant	k31	34
.constant	k32	242
.constant	k33	187
.constant	k34	101
.constant	k35	219
.constant	k36	208
.constant	k37	120
.constant	k38	165
.constant	k39	77
.constant	k40	"PetID"
.constant	k41	"bShowMyPet"
.constant	k42	"pairs"
.constant	k43	"EmoteNameArray"
.constant	k44	"SetText"
.constant	k45	"SlotSwitcherArray"
.constant	k46	"SetActiveWidgetIndex"
.constant	k47	1
.constant	k48	0
.constant	k49	"WidgetSwitcher_Center"
.constant	k50	"IsPlanPHMode"
.constant	k51	"Text_Pet"
.constant	k52	"LocUtil"
.constant	k53	"GetLocalizeResStr"
.constant	k54	655424
.constant	k55	"IsCollectionMode"
.constant	k56	880060105
.constant	k57	"Button_ShowPet"
.constant	k58	"SetWidgetVisibility"
.constant	k59	"UEnums"
.constant	k60	"ESlateVisibility"
.constant	k61	"Collapsed"
.constant	k62	"Visible"
.constant	k63	"CurPetExpressionList"
.constant	k64	"EmoteImageArray"
.constant	k65	"Num"
.constant	k66	"Get"
.constant	k67	"CDataTable"
.constant	k68	"GetTableData"
.constant	k69	19
.constant	k70	84
.constant	k71	222
.constant	k72	66
.constant	k73	183
.constant	k74	213
.constant	k75	32
.constant	k76	89
.constant	k77	248
.constant	k78	107
.constant	k79	40
.constant	k80	254
.constant	k81	"ID"
.constant	k82	"require"
.constant	k83	93
.constant	k84	102
.constant	k85	186
.constant	k86	103
.constant	k87	69
.constant	k88	185
.constant	k89	217
.constant	k90	21
.constant	k91	231
.constant	k92	176
.constant	k93	79
.constant	k94	193
.constant	k95	83
.constant	k96	75
.constant	k97	109
.constant	k98	235
.constant	k99	110
.constant	k100	51
.constant	k101	238
.constant	k102	"PetActionID"
.constant	k103	85
.constant	k104	37
.constant	k105	252
.constant	k106	247
.constant	k107	209
.constant	k108	236
.constant	k109	116
.constant	k110	174
.constant	k111	90
.constant	k112	72
.constant	k113	"GetItemSmallIcon"
.constant	k114	"table"
.constant	k115	"concat"
.constant	k116	20
.constant	k117	71
.constant	k118	114
.constant	k119	38
.constant	k120	73
.constant	k121	239
.constant	k122	98
.constant	k123	99
.constant	k124	210
.constant	k125	106
.constant	k126	"SetTexture"
.constant	k127	"sync"
.constant	k128	false
.constant	k129	"bHasAddKnownMissing"
.constant	k130	"IndexToPetExpression"
.constant	k131	"IsLocked"
.constant	k132	"SetColorAndOpacity"
.constant	k133	"FLinearColor"
.constant	k134	0.5
.constant	k135	"LockImageArray"
.constant	k136	"SelfHitTestInvisible"

.line	453	gettable      r1    r0    k0 ; k0 = "CurrentShowState"
.line	453	gettabup      r2    u0    k1 ; k1 = "PetExpression"
.line	453	eq             1    r1    r2
.line	453	jmp            0    l6
.line	453	return        r0     1
.label	l6
.line	453	self          r1    r0    k2 ; k2 = "RefreshPetInfo"
.line	453	call          r1     2     1
.line	453	gettabup      r1    u1    k3 ; k3 = "print"
.line	453	gettabup      r2    u1    k4 ; k4 = "bWriteLog"
.line	453	test          r2     0
.line	453	jmp            0   l50
.line	453	getupval      r2    u2
.line	453	loadk         r3    k5 ; k5 = 18
.line	453	loadk         r4    k6 ; k6 = 68
.line	453	loadk         r5    k7 ; k7 = 195
.line	453	loadk         r6    k8 ; k8 = 96
.line	453	loadk         r7    k9 ; k9 = 191
.line	453	loadk         r8   k10 ; k10 = 228
.line	453	loadk         r9   k11 ; k11 = 49
.line	453	loadk        r10   k12 ; k12 = 70
.line	453	loadk        r11   k13 ; k13 = 167
.line	453	loadk        r12   k14 ; k14 = 201
.line	453	loadk        r13   k15 ; k15 = 121
.line	453	loadk        r14   k16 ; k16 = 57
.line	453	loadk        r15   k17 ; k17 = 251
.line	453	loadk        r16   k18 ; k18 = 182
.line	453	loadk        r17   k19 ; k19 = 126
.line	453	loadk        r18   k20 ; k20 = 130
.line	453	loadk        r19   k21 ; k21 = 225
.line	453	loadk        r20   k22 ; k22 = 100
.line	453	loadk        r21   k23 ; k23 = 188
.line	453	loadk        r22   k24 ; k24 = 65
.line	453	loadk        r23   k24 ; k24 = 65
.line	453	loadk        r24   k25 ; k25 = 226
.line	453	loadk        r25   k26 ; k26 = 81
.line	453	loadk        r26   k27 ; k27 = 86
.line	453	loadk        r27   k28 ; k28 = 160
.line	453	loadk        r28   k29 ; k29 = 200
.line	453	loadk        r29   k30 ; k30 = 95
.line	453	loadk        r30   k31 ; k31 = 34
.line	453	loadk        r31   k32 ; k32 = 242
.line	453	loadk        r32   k33 ; k33 = 187
.line	453	loadk        r33   k34 ; k34 = 101
.line	453	loadk        r34   k35 ; k35 = 219
.line	453	loadk        r35   k36 ; k36 = 208
.line	453	loadk        r36   k37 ; k37 = 120
.line	453	loadk        r37   k38 ; k38 = 165
.line	453	loadk        r38   k39 ; k39 = 77
.line	453	call          r2    37     2
.label	l50
.line	453	gettable      r3    r0   k40 ; k40 = "PetID"
.line	453	gettable      r4    r0   k41 ; k41 = "bShowMyPet"
.line	453	call          r1     4     1
.line	453	gettabup      r1    u1   k42 ; k42 = "pairs"
.line	453	gettable      r2    r0   k43 ; k43 = "EmoteNameArray"
.line	453	call          r1     2     4
.line	453	jmp            0   l63
.line	453	test          r5     0
.line	453	jmp            0   l63
.line	453	self          r6    r5   k44 ; k44 = "SetText"
.line	453	getupval      r8    u2
.line	453	call          r8     1     2
.line	453	call          r6     3     1
.label	l63
.line	453	move          r0    r0
.line	453	move          r0    r0
.line	453	gettabup      r1    u1   k42 ; k42 = "pairs"
.line	453	gettable      r2    r0   k45 ; k45 = "SlotSwitcherArray"
.line	453	call          r1     2     4
.line	453	jmp            0   l74
.line	453	test          r5     0
.line	453	jmp            0   l74
.line	453	self          r6    r5   k46 ; k46 = "SetActiveWidgetIndex"
.line	453	loadk         r8   k47 ; k47 = 1
.line	453	call          r6     3     1
.label	l74
.line	453	move          r0    r0
.line	453	move          r0    r0
.line	453	gettable      r1    r0   k40 ; k40 = "PetID"
.line	453	test          r1     0
.line	453	jmp            0   l82
.line	453	gettable      r1    r0   k40 ; k40 = "PetID"
.line	453	le             0    r1   k48 ; k48 = 0
.line	453	jmp            0  l124
.label	l82
.line	453	gettable      r1    r0   k49 ; k49 = "WidgetSwitcher_Cente" (truncated)
.line	453	self          r1    r1   k46 ; k46 = "SetActiveWidgetIndex"
.line	453	loadk         r3   k47 ; k47 = 1
.line	453	call          r1     3     1
.line	453	self          r1    r0   k50 ; k50 = "IsPlanPHMode"
.line	453	call          r1     2     2
.line	453	test          r1     0
.line	453	jmp            0   l98
.line	453	gettable      r1    r0   k51 ; k51 = "Text_Pet"
.line	453	self          r1    r1   k44 ; k44 = "SetText"
.line	453	gettabup      r3    u1   k52 ; k52 = "LocUtil"
.line	453	gettable      r3    r3   k53 ; k53 = "GetLocalizeResStr"
.line	453	loadk         r4   k54 ; k54 = 655424
.line	453	call          r3     2     0
.line	453	call          r1     0     1
.line	453	jmp            0  l117
.label	l98
.line	453	self          r1    r0   k55 ; k55 = "IsCollectionMode"
.line	453	call          r1     2     2
.line	453	test          r1     0
.line	453	jmp            0  l110
.line	453	gettable      r1    r0   k51 ; k51 = "Text_Pet"
.line	453	self          r1    r1   k44 ; k44 = "SetText"
.line	453	gettabup      r3    u1   k52 ; k52 = "LocUtil"
.line	453	gettable      r3    r3   k53 ; k53 = "GetLocalizeResStr"
.line	453	loadk         r4   k56 ; k56 = 880060105
.line	453	call          r3     2     0
.line	453	call          r1     0     1
.line	453	jmp            0  l117
.label	l110
.line	453	gettable      r1    r0   k51 ; k51 = "Text_Pet"
.line	453	self          r1    r1   k44 ; k44 = "SetText"
.line	453	gettabup      r3    u1   k52 ; k52 = "LocUtil"
.line	453	gettable      r3    r3   k53 ; k53 = "GetLocalizeResStr"
.line	453	getupval      r4    u3
.line	453	call          r3     2     0
.line	453	call          r1     0     1
.label	l117
.line	453	gettable      r1    r0   k57 ; k57 = "Button_ShowPet"
.line	453	self          r1    r1   k58 ; k58 = "SetWidgetVisibility"
.line	453	gettabup      r3    u1   k59 ; k59 = "UEnums"
.line	453	gettable      r3    r3   k60 ; k60 = "ESlateVisibility"
.line	453	gettable      r3    r3   k61 ; k61 = "Collapsed"
.line	453	call          r1     3     1
.line	453	return        r0     1
.label	l124
.line	453	gettable      r1    r0   k41 ; k41 = "bShowMyPet"
.line	453	test          r1     1
.line	453	jmp            0  l145
.line	453	gettable      r1    r0   k49 ; k49 = "WidgetSwitcher_Cente" (truncated)
.line	453	self          r1    r1   k46 ; k46 = "SetActiveWidgetIndex"
.line	453	loadk         r3   k47 ; k47 = 1
.line	453	call          r1     3     1
.line	453	gettable      r1    r0   k51 ; k51 = "Text_Pet"
.line	453	self          r1    r1   k44 ; k44 = "SetText"
.line	453	gettabup      r3    u1   k52 ; k52 = "LocUtil"
.line	453	gettable      r3    r3   k53 ; k53 = "GetLocalizeResStr"
.line	453	getupval      r4    u4
.line	453	call          r3     2     0
.line	453	call          r1     0     1
.line	453	gettable      r1    r0   k57 ; k57 = "Button_ShowPet"
.line	453	self          r1    r1   k58 ; k58 = "SetWidgetVisibility"
.line	453	gettabup      r3    u1   k59 ; k59 = "UEnums"
.line	453	gettable      r3    r3   k60 ; k60 = "ESlateVisibility"
.line	453	gettable      r3    r3   k62 ; k62 = "Visible"
.line	453	call          r1     3     1
.line	453	return        r0     1
.label	l145
.line	453	gettable      r1    r0   k49 ; k49 = "WidgetSwitcher_Cente" (truncated)
.line	453	self          r1    r1   k46 ; k46 = "SetActiveWidgetIndex"
.line	453	loadk         r3   k48 ; k48 = 0
.line	453	call          r1     3     1
.line	453	gettable      r1    r0   k63 ; k63 = "CurPetExpressionList"
.line	453	test          r1     0
.line	453	jmp            0  l457
.line	453	gettable      r1    r0   k63 ; k63 = "CurPetExpressionList"
.line	453	len           r1    r1
.line	453	lt             0   k48    r1 ; k48 = 0
.line	453	jmp            0  l457
.line	453	gettabup      r1    u1   k42 ; k42 = "pairs"
.line	453	gettable      r2    r0   k63 ; k63 = "CurPetExpressionList"
.line	453	call          r1     2     4
.line	453	jmp            0  l455
.line	453	sub           r6    r4   k47 ; k47 = 1
.line	453	gettable      r7    r0   k64 ; k64 = "EmoteImageArray"
.line	453	self          r7    r7   k65 ; k65 = "Num"
.line	453	call          r7     2     2
.line	453	le             1    r7    r6
.line	453	jmp            0  l457
.line	453	gettable      r6    r0   k64 ; k64 = "EmoteImageArray"
.line	453	self          r6    r6   k66 ; k66 = "Get"
.line	453	sub           r8    r4   k47 ; k47 = 1
.line	453	call          r6     3     2
.line	453	gettable      r7    r0   k45 ; k45 = "SlotSwitcherArray"
.line	453	self          r7    r7   k66 ; k66 = "Get"
.line	453	sub           r9    r4   k47 ; k47 = 1
.line	453	call          r7     3     2
.line	453	gettable      r8    r0   k43 ; k43 = "EmoteNameArray"
.line	453	self          r8    r8   k66 ; k66 = "Get"
.line	453	sub          r10    r4   k47 ; k47 = 1
.line	453	call          r8     3     2
.line	453	gettabup      r9    u1   k67 ; k67 = "CDataTable"
.line	453	gettable      r9    r9   k68 ; k68 = "GetTableData"
.line	453	getupval     r10    u2
.line	453	loadk        r11   k69 ; k69 = 19
.line	453	loadk        r12   k70 ; k70 = 84
.line	453	loadk        r13   k71 ; k71 = 222
.line	453	loadk        r14   k72 ; k72 = 66
.line	453	loadk        r15   k73 ; k73 = 183
.line	453	loadk        r16   k74 ; k74 = 213
.line	453	loadk        r17   k75 ; k75 = 32
.line	453	loadk        r18   k76 ; k76 = 89
.line	453	loadk        r19   k33 ; k33 = 187
.line	453	loadk        r20   k77 ; k77 = 248
.line	453	loadk        r21   k78 ; k78 = 107
.line	453	loadk        r22   k79 ; k79 = 40
.line	453	loadk        r23   k80 ; k80 = 254
.line	453	loadk        r24   k23 ; k23 = 188
.line	453	call         r10    15     2
.line	453	gettable     r11    r5   k81 ; k81 = "ID"
.line	453	call          r9     3     2
.line	453	test          r6     0
.line	453	jmp            0  l455
.line	453	test          r7     0
.line	453	jmp            0  l455
.line	453	test          r8     0
.line	453	jmp            0  l455
.line	453	test          r9     0
.line	453	jmp            0  l455
.line	453	self         r10    r7   k46 ; k46 = "SetActiveWidgetIndex"
.line	453	loadk        r12   k48 ; k48 = 0
.line	453	call         r10     3     1
.line	453	gettabup     r10    u1   k82 ; k82 = "require"
.line	453	getupval     r11    u2
.line	453	loadk        r12   k75 ; k75 = 32
.line	453	loadk        r13   k83 ; k83 = 93
.line	453	loadk        r14    k7 ; k7 = 195
.line	453	loadk        r15   k84 ; k84 = 102
.line	453	loadk        r16   k85 ; k85 = 186
.line	453	loadk        r17   k74 ; k74 = 213
.line	453	loadk        r18   k86 ; k86 = 103
.line	453	loadk        r19   k87 ; k87 = 69
.line	453	loadk        r20   k88 ; k88 = 185
.line	453	loadk        r21   k89 ; k89 = 217
.line	453	loadk        r22   k78 ; k78 = 107
.line	453	loadk        r23   k90 ; k90 = 21
.line	453	loadk        r24   k91 ; k91 = 231
.line	453	loadk        r25   k92 ; k92 = 176
.line	453	loadk        r26   k93 ; k93 = 79
.line	453	loadk        r27   k71 ; k71 = 222
.line	453	loadk        r28   k94 ; k94 = 193
.line	453	loadk        r29    k8 ; k8 = 96
.line	453	loadk        r30   k73 ; k73 = 183
.line	453	loadk        r31   k27 ; k27 = 86
.line	453	loadk        r32   k95 ; k95 = 83
.line	453	loadk        r33   k80 ; k80 = 254
.line	453	loadk        r34   k96 ; k96 = 75
.line	453	loadk        r35   k97 ; k97 = 109
.line	453	loadk        r36   k98 ; k98 = 235
.line	453	loadk        r37   k14 ; k14 = 201
.line	453	loadk        r38   k99 ; k99 = 110
.line	453	loadk        r39  k100 ; k100 = 51
.line	453	loadk        r40  k101 ; k101 = 238
.line	453	call         r11    30     2
.line	453	call         r10     2     2
.line	453	gettable     r11    r9  k102 ; k102 = "PetActionID"
.line	453	gettabup     r12    u1   k82 ; k82 = "require"
.line	453	getupval     r13    u2
.line	453	loadk        r14   k75 ; k75 = 32
.line	453	loadk        r15   k83 ; k83 = 93
.line	453	loadk        r16    k7 ; k7 = 195
.line	453	loadk        r17   k84 ; k84 = 102
.line	453	loadk        r18   k85 ; k85 = 186
.line	453	loadk        r19   k74 ; k74 = 213
.line	453	loadk        r20   k86 ; k86 = 103
.line	453	loadk        r21  k103 ; k103 = 85
.line	453	loadk        r22   k85 ; k85 = 186
.line	453	loadk        r23   k94 ; k94 = 193
.line	453	loadk        r24   k86 ; k86 = 103
.line	453	loadk        r25  k104 ; k104 = 37
.line	453	loadk        r26  k105 ; k105 = 252
.line	453	loadk        r27  k106 ; k106 = 247
.line	453	loadk        r28   k34 ; k34 = 101
.line	453	loadk        r29  k107 ; k107 = 209
.line	453	loadk        r30  k108 ; k108 = 236
.line	453	loadk        r31  k109 ; k109 = 116
.line	453	loadk        r32  k110 ; k110 = 174
.line	453	loadk        r33  k111 ; k111 = 90
.line	453	loadk        r34  k112 ; k112 = 72
.line	453	call         r13    22     2
.line	453	call         r12     2     2
.line	453	gettable     r13   r12  k113 ; k113 = "GetItemSmallIcon"
.line	453	move         r14   r11
.line	453	move         r15    r6
.line	453	call         r13     3     4
.line	453	gettabup     r16    u1    k3 ; k3 = "print"
.line	453	gettabup     r17    u1    k4 ; k4 = "bWriteLog"
.line	453	test         r17     0
.line	453	jmp            0  l327
.line	453	gettabup     r17    u1  k114 ; k114 = "table"
.line	453	gettable     r17   r17  k115 ; k115 = "concat"
.line	453	newtable     r18     1     0
.line	453	getupval     r19    u2
.line	453	loadk        r20    k5 ; k5 = 18
.line	453	loadk        r21    k6 ; k6 = 68
.line	453	loadk        r22    k7 ; k7 = 195
.line	453	loadk        r23    k8 ; k8 = 96
.line	453	loadk        r24    k9 ; k9 = 191
.line	453	loadk        r25   k10 ; k10 = 228
.line	453	loadk        r26   k11 ; k11 = 49
.line	453	loadk        r27   k12 ; k12 = 70
.line	453	loadk        r28   k13 ; k13 = 167
.line	453	loadk        r29   k14 ; k14 = 201
.line	453	loadk        r30   k15 ; k15 = 121
.line	453	loadk        r31   k16 ; k16 = 57
.line	453	loadk        r32   k17 ; k17 = 251
.line	453	loadk        r33   k18 ; k18 = 182
.line	453	loadk        r34   k19 ; k19 = 126
.line	453	loadk        r35   k20 ; k20 = 130
.line	453	loadk        r36   k21 ; k21 = 225
.line	453	loadk        r37   k22 ; k22 = 100
.line	453	loadk        r38   k23 ; k23 = 188
.line	453	loadk        r39   k24 ; k24 = 65
.line	453	loadk        r40   k24 ; k24 = 65
.line	453	loadk        r41   k25 ; k25 = 226
.line	453	loadk        r42   k26 ; k26 = 81
.line	453	loadk        r43   k27 ; k27 = 86
.line	453	loadk        r44   k28 ; k28 = 160
.line	453	loadk        r45   k29 ; k29 = 200
.line	453	loadk        r46   k30 ; k30 = 95
.line	453	loadk        r47   k31 ; k31 = 34
.line	453	loadk        r48   k32 ; k32 = 242
.line	453	loadk        r49   k33 ; k33 = 187
.line	453	loadk        r50   k34 ; k34 = 101
.line	453	loadk        r51   k35 ; k35 = 219
.line	453	loadk        r52   k36 ; k36 = 208
.line	453	loadk        r53   k37 ; k37 = 120
.line	453	loadk        r54   k38 ; k38 = 165
.line	453	loadk        r55   k39 ; k39 = 77
.line	453	loadk        r56  k116 ; k116 = 20
.line	453	loadk        r57   k29 ; k29 = 200
.line	453	loadk        r58  k117 ; k117 = 71
.line	453	loadk        r59  k118 ; k118 = 114
.line	453	call         r19    41     2
.line	453	getupval     r20    u2
.line	453	loadk        r21  k119 ; k119 = 38
.line	453	loadk        r22  k120 ; k120 = 73
.line	453	call         r20     3     0
.line	453	setlist      r18     0     1
.line	453	call         r17     2     2
.label	l327
.line	453	move         r18   r11
.line	453	move         r19   r13
.line	453	move         r20   r14
.line	453	move         r21   r15
.line	453	call         r16     6     1
.line	453	test         r15     0
.line	453	jmp            0  l402
.line	453	gettabup     r16    u1    k3 ; k3 = "print"
.line	453	gettabup     r17    u1    k4 ; k4 = "bWriteLog"
.line	453	test         r17     0
.line	453	jmp            0  l393
.line	453	gettabup     r17    u1  k114 ; k114 = "table"
.line	453	gettable     r17   r17  k115 ; k115 = "concat"
.line	453	newtable     r18     1     0
.line	453	getupval     r19    u2
.line	453	loadk        r20    k5 ; k5 = 18
.line	453	loadk        r21    k6 ; k6 = 68
.line	453	loadk        r22    k7 ; k7 = 195
.line	453	loadk        r23    k8 ; k8 = 96
.line	453	loadk        r24    k9 ; k9 = 191
.line	453	loadk        r25   k10 ; k10 = 228
.line	453	loadk        r26   k11 ; k11 = 49
.line	453	loadk        r27   k12 ; k12 = 70
.line	453	loadk        r28   k13 ; k13 = 167
.line	453	loadk        r29   k14 ; k14 = 201
.line	453	loadk        r30   k15 ; k15 = 121
.line	453	loadk        r31   k16 ; k16 = 57
.line	453	loadk        r32   k17 ; k17 = 251
.line	453	loadk        r33   k18 ; k18 = 182
.line	453	loadk        r34   k19 ; k19 = 126
.line	453	loadk        r35   k20 ; k20 = 130
.line	453	loadk        r36   k21 ; k21 = 225
.line	453	loadk        r37   k22 ; k22 = 100
.line	453	loadk        r38   k23 ; k23 = 188
.line	453	loadk        r39   k24 ; k24 = 65
.line	453	loadk        r40   k24 ; k24 = 65
.line	453	loadk        r41   k25 ; k25 = 226
.line	453	loadk        r42   k26 ; k26 = 81
.line	453	loadk        r43   k27 ; k27 = 86
.line	453	loadk        r44   k28 ; k28 = 160
.line	453	loadk        r45   k29 ; k29 = 200
.line	453	loadk        r46   k30 ; k30 = 95
.line	453	loadk        r47   k31 ; k31 = 34
.line	453	loadk        r48   k32 ; k32 = 242
.line	453	loadk        r49   k33 ; k33 = 187
.line	453	loadk        r50   k34 ; k34 = 101
.line	453	loadk        r51   k35 ; k35 = 219
.line	453	loadk        r52   k36 ; k36 = 208
.line	453	loadk        r53   k37 ; k37 = 120
.line	453	loadk        r54   k38 ; k38 = 165
.line	453	loadk        r55   k39 ; k39 = 77
.line	453	loadk        r56  k116 ; k116 = 20
.line	453	loadk        r57  k121 ; k121 = 239
.line	453	loadk        r58   k12 ; k12 = 70
.line	453	loadk        r59  k122 ; k122 = 98
.line	453	call         r19    41     2
.line	453	getupval     r20    u2
.line	453	loadk        r21  k123 ; k123 = 99
.line	453	loadk        r22   k70 ; k70 = 84
.line	453	loadk        r23  k124 ; k124 = 210
.line	453	loadk        r24  k125 ; k125 = 106
.line	453	loadk        r25   k13 ; k13 = 167
.line	453	loadk        r26   k74 ; k74 = 213
.line	453	call         r20     7     0
.line	453	setlist      r18     0     1
.line	453	call         r17     2     2
.label	l393
.line	453	move         r18    r4
.line	453	call         r16     3     1
.line	453	gettable     r16   r10  k126 ; k126 = "SetTexture"
.line	453	move         r17    r6
.line	453	getupval     r18    u5
.line	453	newtable     r19     0     1
.line	453	settable     r19  k127  k128 ; k128 = false
.line	453	call         r16     4     1
.line	453	jmp            0  l410
.label	l402
.line	453	newtable     r16     0     2
.line	453	settable     r16  k127  k128 ; k128 = false
.line	453	settable     r16  k129   r14 ; k129 = "bHasAddKnownMissing"
.line	453	gettable     r17   r10  k126 ; k126 = "SetTexture"
.line	453	move         r18    r6
.line	453	move         r19   r13
.line	453	move         r20   r16
.line	453	call         r17     4     1
.label	l410
.line	453	gettable     r16    r0  k130 ; k130 = "IndexToPetExpression"
.line	453	gettable     r17    r5   k81 ; k81 = "ID"
.line	453	settable     r16    r4   r17
.line	453	gettable     r16    r5  k131 ; k131 = "IsLocked"
.line	453	test         r16     0
.line	453	jmp            0  l436
.line	453	self         r16    r6  k132 ; k132 = "SetColorAndOpacity"
.line	453	gettabup     r18    u1  k133 ; k133 = "FLinearColor"
.line	453	loadk        r19   k47 ; k47 = 1
.line	453	loadk        r20   k47 ; k47 = 1
.line	453	loadk        r21   k47 ; k47 = 1
.line	453	loadk        r22  k134 ; k134 = 0.5
.line	453	call         r18     5     0
.line	453	call         r16     0     1
.line	453	gettable     r16    r0  k135 ; k135 = "LockImageArray"
.line	453	self         r16   r16   k66 ; k66 = "Get"
.line	453	sub          r18    r4   k47 ; k47 = 1
.line	453	call         r16     3     2
.line	453	test         r16     0
.line	453	jmp            0  l455
.line	453	self         r17   r16   k58 ; k58 = "SetWidgetVisibility"
.line	453	gettabup     r19    u1   k59 ; k59 = "UEnums"
.line	453	gettable     r19   r19   k60 ; k60 = "ESlateVisibility"
.line	453	gettable     r19   r19  k136 ; k136 = "SelfHitTestInvisible"
.line	453	call         r17     3     1
.line	453	jmp            0  l455
.label	l436
.line	453	self         r16    r6  k132 ; k132 = "SetColorAndOpacity"
.line	453	gettabup     r18    u1  k133 ; k133 = "FLinearColor"
.line	453	loadk        r19   k47 ; k47 = 1
.line	453	loadk        r20   k47 ; k47 = 1
.line	453	loadk        r21   k47 ; k47 = 1
.line	453	loadk        r22   k47 ; k47 = 1
.line	453	call         r18     5     0
.line	453	call         r16     0     1
.line	453	gettable     r16    r0  k135 ; k135 = "LockImageArray"
.line	453	self         r16   r16   k66 ; k66 = "Get"
.line	453	sub          r18    r4   k47 ; k47 = 1
.line	453	call         r16     3     2
.line	453	test         r16     0
.line	453	jmp            0  l455
.line	453	self         r17   r16   k58 ; k58 = "SetWidgetVisibility"
.line	453	gettabup     r19    u1   k59 ; k59 = "UEnums"
.line	453	gettable     r19   r19   k60 ; k60 = "ESlateVisibility"
.line	453	gettable     r19   r19   k61 ; k61 = "Collapsed"
.line	453	call         r17     3     1
.label	l455
.line	453	move          r0    r0
.line	453	move          r0    r0
.label	l457
.line	453	return        r0     1
.line	453	gettabup      r2    u1   k89 ; k89 = 217
.line	453	move          r0    r0
.line	453	move          r0    r0
.line	453	return        r0     1

.function	main/f20

.source	null
.linedefined	530
.lastlinedefined	538
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"GetGameModeID"
.constant	k2	"GameFrontendHUD"
.constant	k3	"log"
.constant	k4	"bWriteLog"
.constant	k5	"table"
.constant	k6	"concat"
.constant	k7	18
.constant	k8	68
.constant	k9	195
.constant	k10	96
.constant	k11	191
.constant	k12	228
.constant	k13	49
.constant	k14	70
.constant	k15	167
.constant	k16	201
.constant	k17	121
.constant	k18	57
.constant	k19	251
.constant	k20	182
.constant	k21	126
.constant	k22	130
.constant	k23	250
.constant	k24	114
.constant	k25	138
.constant	k26	95
.constant	k27	69
.constant	k28	255
.constant	k29	105
.constant	k30	78
.constant	k31	136
.constant	k32	211
.constant	k33	63
.constant	k34	162
.constant	k35	117
.constant	k36	218
.constant	k37	112
.constant	k38	238
.constant	k39	77
.constant	k40	115
.constant	k41	10
.constant	k42	62
.constant	k43	244
.constant	k44	"tostring"
.constant	k45	"require"
.constant	k46	32
.constant	k47	93
.constant	k48	102
.constant	k49	186
.constant	k50	213
.constant	k51	103
.constant	k52	185
.constant	k53	217
.constant	k54	107
.constant	k55	100
.constant	k56	254
.constant	k57	119
.constant	k58	209
.constant	k59	208
.constant	k60	47
.constant	k61	178
.constant	k62	92
.constant	k63	73
.constant	k64	23
.constant	k65	110
.constant	k66	170
.constant	k67	127
.constant	k68	5
.constant	k69	239
.constant	k70	168
.constant	k71	99
.constant	k72	204
.constant	k73	98
.constant	k74	"Home_SubMode"
.constant	k75	"Visit"

.line	530	gettabup      r1    u0    k0 ; k0 = "Client"
.line	530	gettable      r1    r1    k1 ; k1 = "GetGameModeID"
.line	530	gettabup      r2    u0    k2 ; k2 = "GameFrontendHUD"
.line	530	call          r1     2     2
.line	530	gettabup      r2    u0    k3 ; k3 = "log"
.line	530	gettabup      r3    u0    k4 ; k4 = "bWriteLog"
.line	530	test          r3     0
.line	530	jmp            0   l67
.line	530	gettabup      r3    u0    k5 ; k5 = "table"
.line	530	gettable      r3    r3    k6 ; k6 = "concat"
.line	530	newtable      r4     1     0
.line	530	getupval      r5    u1
.line	530	loadk         r6    k7 ; k7 = 18
.line	530	loadk         r7    k8 ; k8 = 68
.line	530	loadk         r8    k9 ; k9 = 195
.line	530	loadk         r9   k10 ; k10 = 96
.line	530	loadk        r10   k11 ; k11 = 191
.line	530	loadk        r11   k12 ; k12 = 228
.line	530	loadk        r12   k13 ; k13 = 49
.line	530	loadk        r13   k14 ; k14 = 70
.line	530	loadk        r14   k15 ; k15 = 167
.line	530	loadk        r15   k16 ; k16 = 201
.line	530	loadk        r16   k17 ; k17 = 121
.line	530	loadk        r17   k18 ; k18 = 57
.line	530	loadk        r18   k19 ; k19 = 251
.line	530	loadk        r19   k20 ; k20 = 182
.line	530	loadk        r20   k21 ; k21 = 126
.line	530	loadk        r21   k22 ; k22 = 130
.line	530	loadk        r22   k23 ; k23 = 250
.line	530	loadk        r23   k24 ; k24 = 114
.line	530	loadk        r24   k25 ; k25 = 138
.line	530	loadk        r25   k26 ; k26 = 95
.line	530	loadk        r26   k27 ; k27 = 69
.line	530	loadk        r27   k28 ; k28 = 255
.line	530	loadk        r28   k29 ; k29 = 105
.line	530	loadk        r29   k30 ; k30 = 78
.line	530	loadk        r30   k31 ; k31 = 136
.line	530	loadk        r31   k32 ; k32 = 211
.line	530	loadk        r32   k21 ; k21 = 126
.line	530	loadk        r33   k33 ; k33 = 63
.line	530	loadk        r34   k34 ; k34 = 162
.line	530	loadk        r35   k25 ; k25 = 138
.line	530	loadk        r36   k35 ; k35 = 117
.line	530	loadk        r37   k36 ; k36 = 218
.line	530	loadk        r38   k12 ; k12 = 228
.line	530	loadk        r39   k37 ; k37 = 112
.line	530	loadk        r40   k15 ; k15 = 167
.line	530	loadk        r41   k14 ; k14 = 70
.line	530	loadk        r42   k17 ; k17 = 121
.line	530	loadk        r43   k38 ; k38 = 238
.line	530	loadk        r44   k39 ; k39 = 77
.line	530	loadk        r45   k40 ; k40 = 115
.line	530	call          r5    41     2
.line	530	getupval      r6    u1
.line	530	loadk         r7   k41 ; k41 = 10
.line	530	loadk         r8   k35 ; k35 = 117
.line	530	loadk         r9   k25 ; k25 = 138
.line	530	loadk        r10   k42 ; k42 = 62
.line	530	loadk        r11   k43 ; k43 = 244
.line	530	call          r6     6     0
.line	530	setlist       r4     0     1
.line	530	call          r3     2     2
.line	530	gettabup      r4    u0   k44 ; k44 = "tostring"
.line	530	move          r5    r1
.line	530	call          r4     2     2
.line	530	concat        r3    r3    r4
.label	l67
.line	530	call          r2     2     1
.line	530	gettabup      r2    u0   k45 ; k45 = "require"
.line	530	getupval      r3    u1
.line	530	loadk         r4   k46 ; k46 = 32
.line	530	loadk         r5   k47 ; k47 = 93
.line	530	loadk         r6    k9 ; k9 = 195
.line	530	loadk         r7   k48 ; k48 = 102
.line	530	loadk         r8   k49 ; k49 = 186
.line	530	loadk         r9   k50 ; k50 = 213
.line	530	loadk        r10   k51 ; k51 = 103
.line	530	loadk        r11   k27 ; k27 = 69
.line	530	loadk        r12   k52 ; k52 = 185
.line	530	loadk        r13   k53 ; k53 = 217
.line	530	loadk        r14   k54 ; k54 = 107
.line	530	loadk        r15   k55 ; k55 = 100
.line	530	loadk        r16   k56 ; k56 = 254
.line	530	loadk        r17   k20 ; k20 = 182
.line	530	loadk        r18   k57 ; k57 = 119
.line	530	loadk        r19   k58 ; k58 = 209
.line	530	loadk        r20   k59 ; k59 = 208
.line	530	loadk        r21   k60 ; k60 = 47
.line	530	loadk        r22   k61 ; k61 = 178
.line	530	loadk        r23   k62 ; k62 = 92
.line	530	loadk        r24   k63 ; k63 = 73
.line	530	loadk        r25   k43 ; k43 = 244
.line	530	loadk        r26   k64 ; k64 = 23
.line	530	loadk        r27   k65 ; k65 = 110
.line	530	loadk        r28   k66 ; k66 = 170
.line	530	loadk        r29   k58 ; k58 = 209
.line	530	loadk        r30   k67 ; k67 = 127
.line	530	loadk        r31   k68 ; k68 = 5
.line	530	loadk        r32   k69 ; k69 = 239
.line	530	loadk        r33   k70 ; k70 = 168
.line	530	loadk        r34   k71 ; k71 = 99
.line	530	loadk        r35   k36 ; k36 = 218
.line	530	loadk        r36   k72 ; k72 = 204
.line	530	loadk        r37   k73 ; k73 = 98
.line	530	call          r3    35     2
.line	530	call          r2     2     2
.line	530	gettabup      r3    u0   k44 ; k44 = "tostring"
.line	530	move          r4    r1
.line	530	call          r3     2     2
.line	530	gettabup      r4    u0   k44 ; k44 = "tostring"
.line	530	gettable      r5    r2   k74 ; k74 = "Home_SubMode"
.line	530	gettable      r5    r5   k75 ; k75 = "Visit"
.line	530	call          r4     2     2
.line	530	eq             0    r3    r4
.line	530	jmp            0  l117
.line	530	loadbool      r3     1     0
.line	530	return        r3     2
.label	l117
.line	530	loadbool      r3     0     0
.line	530	return        r3     2
.line	530	return        r0     1
.line	530	move          r0    r0
.line	530	move          r0    r0
.line	530	return        r0     1

.function	main/f21

.source	null
.linedefined	540
.lastlinedefined	543
.numparams	1
.is_vararg	0
.maxstacksize	35

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	18
.constant	k3	68
.constant	k4	195
.constant	k5	96
.constant	k6	191
.constant	k7	228
.constant	k8	49
.constant	k9	70
.constant	k10	167
.constant	k11	201
.constant	k12	121
.constant	k13	57
.constant	k14	251
.constant	k15	182
.constant	k16	126
.constant	k17	130
.constant	k18	250
.constant	k19	114
.constant	k20	153
.constant	k21	92
.constant	k22	72
.constant	k23	253
.constant	k24	101
.constant	k25	177
.constant	k26	213
.constant	k27	117
.constant	k28	52
.constant	k29	207
.constant	k30	166
.constant	k31	100
.constant	k32	205
.constant	k33	"GameStatus"
.constant	k34	"IsCollectionHallMode"

.line	540	gettabup      r1    u0    k0 ; k0 = "log"
.line	540	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	540	test          r2     0
.line	540	jmp            0   l39
.line	540	getupval      r2    u1
.line	540	loadk         r3    k2 ; k2 = 18
.line	540	loadk         r4    k3 ; k3 = 68
.line	540	loadk         r5    k4 ; k4 = 195
.line	540	loadk         r6    k5 ; k5 = 96
.line	540	loadk         r7    k6 ; k6 = 191
.line	540	loadk         r8    k7 ; k7 = 228
.line	540	loadk         r9    k8 ; k8 = 49
.line	540	loadk        r10    k9 ; k9 = 70
.line	540	loadk        r11   k10 ; k10 = 167
.line	540	loadk        r12   k11 ; k11 = 201
.line	540	loadk        r13   k12 ; k12 = 121
.line	540	loadk        r14   k13 ; k13 = 57
.line	540	loadk        r15   k14 ; k14 = 251
.line	540	loadk        r16   k15 ; k15 = 182
.line	540	loadk        r17   k16 ; k16 = 126
.line	540	loadk        r18   k17 ; k17 = 130
.line	540	loadk        r19   k18 ; k18 = 250
.line	540	loadk        r20   k19 ; k19 = 114
.line	540	loadk        r21   k20 ; k20 = 153
.line	540	loadk        r22   k21 ; k21 = 92
.line	540	loadk        r23   k22 ; k22 = 72
.line	540	loadk        r24   k23 ; k23 = 253
.line	540	loadk        r25   k21 ; k21 = 92
.line	540	loadk        r26   k24 ; k24 = 101
.line	540	loadk        r27   k25 ; k25 = 177
.line	540	loadk        r28   k26 ; k26 = 213
.line	540	loadk        r29   k27 ; k27 = 117
.line	540	loadk        r30   k28 ; k28 = 52
.line	540	loadk        r31   k29 ; k29 = 207
.line	540	loadk        r32   k30 ; k30 = 166
.line	540	loadk        r33   k31 ; k31 = 100
.line	540	loadk        r34   k32 ; k32 = 205
.line	540	call          r2    33     2
.label	l39
.line	540	call          r1     2     1
.line	540	gettabup      r1    u0   k33 ; k33 = "GameStatus"
.line	540	gettable      r1    r1   k34 ; k34 = "IsCollectionHallMode"
.line	540	tailcall      r1     1
.line	540	return        r1     0
.line	540	return        r0     1
.line	540	move          r0    r0
.line	540	move          r0    r0
.line	540	move          r0    r0
.line	540	move          r0    r0
.line	540	return        r0     1

.function	main/f22

.source	null
.linedefined	545
.lastlinedefined	578
.numparams	1
.is_vararg	0
.maxstacksize	42

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	23	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	18
.constant	k3	68
.constant	k4	195
.constant	k5	96
.constant	k6	191
.constant	k7	228
.constant	k8	49
.constant	k9	70
.constant	k10	167
.constant	k11	201
.constant	k12	121
.constant	k13	57
.constant	k14	251
.constant	k15	182
.constant	k16	126
.constant	k17	130
.constant	k18	225
.constant	k19	100
.constant	k20	188
.constant	k21	65
.constant	k22	226
.constant	k23	81
.constant	k24	69
.constant	k25	170
.constant	k26	208
.constant	k27	118
.constant	k28	63
.constant	k29	189
.constant	k30	105
.constant	k31	199
.constant	k32	205
.constant	k33	"CurrentShowState"
.constant	k34	"Collection"
.constant	k35	"RefreshCollectionList"
.constant	k36	"log_tree"
.constant	k37	17
.constant	k38	84
.constant	k39	204
.constant	k40	113
.constant	k41	177
.constant	k42	210
.constant	k43	33
.constant	k44	117
.constant	k45	186
.constant	k46	192
.constant	k47	102
.constant	k48	47
.constant	k49	241
.constant	k50	173
.constant	k51	215
.constant	k52	221
.constant	k53	77
.constant	k54	179
.constant	k55	64
.constant	k56	80
.constant	k57	171
.constant	k58	"CollectionList"
.constant	k59	"pairs"
.constant	k60	"EmoteNameArray"
.constant	k61	"SetText"
.constant	k62	"SlotSwitcherArray"
.constant	k63	"SetActiveWidgetIndex"
.constant	k64	1
.constant	k65	12
.constant	k66	"EmoteImageArray"
.constant	k67	"Get"
.constant	k68	"require"
.constant	k69	32
.constant	k70	93
.constant	k71	213
.constant	k72	103
.constant	k73	85
.constant	k74	193
.constant	k75	37
.constant	k76	252
.constant	k77	247
.constant	k78	101
.constant	k79	209
.constant	k80	236
.constant	k81	116
.constant	k82	174
.constant	k83	90
.constant	k84	72
.constant	k85	"GetItemSmallIcon"
.constant	k86	0
.constant	k87	185
.constant	k88	217
.constant	k89	107
.constant	k90	21
.constant	k91	231
.constant	k92	176
.constant	k93	79
.constant	k94	222
.constant	k95	183
.constant	k96	86
.constant	k97	83
.constant	k98	254
.constant	k99	75
.constant	k100	109
.constant	k101	235
.constant	k102	110
.constant	k103	51
.constant	k104	238
.constant	k105	"SetTexture"
.constant	k106	"sync"
.constant	k107	false
.constant	k108	"SetColorAndOpacity"
.constant	k109	"FLinearColor"

.line	545	gettabup      r1    u0    k0 ; k0 = "print"
.line	545	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	545	test          r2     0
.line	545	jmp            0   l40
.line	545	getupval      r2    u1
.line	545	loadk         r3    k2 ; k2 = 18
.line	545	loadk         r4    k3 ; k3 = 68
.line	545	loadk         r5    k4 ; k4 = 195
.line	545	loadk         r6    k5 ; k5 = 96
.line	545	loadk         r7    k6 ; k6 = 191
.line	545	loadk         r8    k7 ; k7 = 228
.line	545	loadk         r9    k8 ; k8 = 49
.line	545	loadk        r10    k9 ; k9 = 70
.line	545	loadk        r11   k10 ; k10 = 167
.line	545	loadk        r12   k11 ; k11 = 201
.line	545	loadk        r13   k12 ; k12 = 121
.line	545	loadk        r14   k13 ; k13 = 57
.line	545	loadk        r15   k14 ; k14 = 251
.line	545	loadk        r16   k15 ; k15 = 182
.line	545	loadk        r17   k16 ; k16 = 126
.line	545	loadk        r18   k17 ; k17 = 130
.line	545	loadk        r19   k18 ; k18 = 225
.line	545	loadk        r20   k19 ; k19 = 100
.line	545	loadk        r21   k20 ; k20 = 188
.line	545	loadk        r22   k21 ; k21 = 65
.line	545	loadk        r23   k21 ; k21 = 65
.line	545	loadk        r24   k22 ; k22 = 226
.line	545	loadk        r25   k23 ; k23 = 81
.line	545	loadk        r26   k24 ; k24 = 69
.line	545	loadk        r27   k25 ; k25 = 170
.line	545	loadk        r28   k26 ; k26 = 208
.line	545	loadk        r29   k27 ; k27 = 118
.line	545	loadk        r30   k28 ; k28 = 63
.line	545	loadk        r31   k18 ; k18 = 225
.line	545	loadk        r32   k29 ; k29 = 189
.line	545	loadk        r33   k30 ; k30 = 105
.line	545	loadk        r34   k31 ; k31 = 199
.line	545	loadk        r35   k32 ; k32 = 205
.line	545	call          r2    34     2
.label	l40
.line	545	gettable      r3    r0   k33 ; k33 = "CurrentShowState"
.line	545	call          r1     3     1
.line	545	gettable      r1    r0   k33 ; k33 = "CurrentShowState"
.line	545	gettabup      r2    u2   k34 ; k34 = "Collection"
.line	545	eq             1    r1    r2
.line	545	jmp            0   l47
.line	545	return        r0     1
.label	l47
.line	545	self          r1    r0   k35 ; k35 = "RefreshCollectionLis" (truncated)
.line	545	call          r1     2     1
.line	545	gettabup      r1    u0   k36 ; k36 = "log_tree"
.line	545	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	545	test          r2     0
.line	545	jmp            0   l77
.line	545	getupval      r2    u1
.line	545	loadk         r3   k37 ; k37 = 17
.line	545	loadk         r4   k38 ; k38 = 84
.line	545	loadk         r5   k39 ; k39 = 204
.line	545	loadk         r6   k40 ; k40 = 113
.line	545	loadk         r7   k41 ; k41 = 177
.line	545	loadk         r8   k42 ; k42 = 210
.line	545	loadk         r9   k43 ; k43 = 33
.line	545	loadk        r10   k44 ; k44 = 117
.line	545	loadk        r11   k45 ; k45 = 186
.line	545	loadk        r12   k46 ; k46 = 192
.line	545	loadk        r13   k47 ; k47 = 102
.line	545	loadk        r14   k48 ; k48 = 47
.line	545	loadk        r15   k49 ; k49 = 241
.line	545	loadk        r16   k50 ; k50 = 173
.line	545	loadk        r17   k12 ; k12 = 121
.line	545	loadk        r18   k51 ; k51 = 215
.line	545	loadk        r19   k52 ; k52 = 221
.line	545	loadk        r20   k53 ; k53 = 77
.line	545	loadk        r21   k54 ; k54 = 179
.line	545	loadk        r22   k55 ; k55 = 64
.line	545	loadk        r23   k56 ; k56 = 80
.line	545	loadk        r24   k57 ; k57 = 171
.line	545	call          r2    23     2
.label	l77
.line	545	gettable      r3    r0   k58 ; k58 = "CollectionList"
.line	545	call          r1     3     1
.line	545	gettabup      r1    u0   k59 ; k59 = "pairs"
.line	545	gettable      r2    r0   k60 ; k60 = "EmoteNameArray"
.line	545	call          r1     2     4
.line	545	jmp            0   l89
.line	545	test          r5     0
.line	545	jmp            0   l89
.line	545	self          r6    r5   k61 ; k61 = "SetText"
.line	545	getupval      r8    u1
.line	545	call          r8     1     2
.line	545	call          r6     3     1
.label	l89
.line	545	move          r0    r0
.line	545	move          r0    r0
.line	545	gettabup      r1    u0   k59 ; k59 = "pairs"
.line	545	gettable      r2    r0   k62 ; k62 = "SlotSwitcherArray"
.line	545	call          r1     2     4
.line	545	jmp            0  l100
.line	545	test          r5     0
.line	545	jmp            0  l100
.line	545	self          r6    r5   k63 ; k63 = "SetActiveWidgetIndex"
.line	545	loadk         r8   k64 ; k64 = 1
.line	545	call          r6     3     1
.label	l100
.line	545	move          r0    r0
.line	545	move          r0    r0
.line	545	gettabup      r1    u0   k59 ; k59 = "pairs"
.line	545	gettable      r2    r0   k58 ; k58 = "CollectionList"
.line	545	call          r1     2     4
.line	545	jmp            0  l206
.line	545	lt             1   k65    r4 ; k65 = 12
.line	545	jmp            0  l208
.line	545	gettable      r6    r0   k66 ; k66 = "EmoteImageArray"
.line	545	self          r6    r6   k67 ; k67 = "Get"
.line	545	sub           r8    r4   k64 ; k64 = 1
.line	545	call          r6     3     2
.line	545	gettable      r7    r0   k62 ; k62 = "SlotSwitcherArray"
.line	545	self          r7    r7   k67 ; k67 = "Get"
.line	545	sub           r9    r4   k64 ; k64 = 1
.line	545	call          r7     3     2
.line	545	gettable      r8    r0   k60 ; k60 = "EmoteNameArray"
.line	545	self          r8    r8   k67 ; k67 = "Get"
.line	545	sub          r10    r4   k64 ; k64 = 1
.line	545	call          r8     3     2
.line	545	gettabup      r9    u0   k68 ; k68 = "require"
.line	545	getupval     r10    u1
.line	545	loadk        r11   k69 ; k69 = 32
.line	545	loadk        r12   k70 ; k70 = 93
.line	545	loadk        r13    k4 ; k4 = 195
.line	545	loadk        r14   k47 ; k47 = 102
.line	545	loadk        r15   k45 ; k45 = 186
.line	545	loadk        r16   k71 ; k71 = 213
.line	545	loadk        r17   k72 ; k72 = 103
.line	545	loadk        r18   k73 ; k73 = 85
.line	545	loadk        r19   k45 ; k45 = 186
.line	545	loadk        r20   k74 ; k74 = 193
.line	545	loadk        r21   k72 ; k72 = 103
.line	545	loadk        r22   k75 ; k75 = 37
.line	545	loadk        r23   k76 ; k76 = 252
.line	545	loadk        r24   k77 ; k77 = 247
.line	545	loadk        r25   k78 ; k78 = 101
.line	545	loadk        r26   k79 ; k79 = 209
.line	545	loadk        r27   k80 ; k80 = 236
.line	545	loadk        r28   k81 ; k81 = 116
.line	545	loadk        r29   k82 ; k82 = 174
.line	545	loadk        r30   k83 ; k83 = 90
.line	545	loadk        r31   k84 ; k84 = 72
.line	545	call         r10    22     2
.line	545	call          r9     2     2
.line	545	gettable     r10    r9   k85 ; k85 = "GetItemSmallIcon"
.line	545	move         r11    r5
.line	545	call         r10     2     2
.line	545	test          r6     0
.line	545	jmp            0  l206
.line	545	test          r7     0
.line	545	jmp            0  l206
.line	545	test          r8     0
.line	545	jmp            0  l206
.line	545	test         r10     0
.line	545	jmp            0  l206
.line	545	self         r11    r7   k63 ; k63 = "SetActiveWidgetIndex"
.line	545	loadk        r13   k86 ; k86 = 0
.line	545	call         r11     3     1
.line	545	gettabup     r11    u0   k68 ; k68 = "require"
.line	545	getupval     r12    u1
.line	545	loadk        r13   k69 ; k69 = 32
.line	545	loadk        r14   k70 ; k70 = 93
.line	545	loadk        r15    k4 ; k4 = 195
.line	545	loadk        r16   k47 ; k47 = 102
.line	545	loadk        r17   k45 ; k45 = 186
.line	545	loadk        r18   k71 ; k71 = 213
.line	545	loadk        r19   k72 ; k72 = 103
.line	545	loadk        r20   k24 ; k24 = 69
.line	545	loadk        r21   k87 ; k87 = 185
.line	545	loadk        r22   k88 ; k88 = 217
.line	545	loadk        r23   k89 ; k89 = 107
.line	545	loadk        r24   k90 ; k90 = 21
.line	545	loadk        r25   k91 ; k91 = 231
.line	545	loadk        r26   k92 ; k92 = 176
.line	545	loadk        r27   k93 ; k93 = 79
.line	545	loadk        r28   k94 ; k94 = 222
.line	545	loadk        r29   k74 ; k74 = 193
.line	545	loadk        r30    k5 ; k5 = 96
.line	545	loadk        r31   k95 ; k95 = 183
.line	545	loadk        r32   k96 ; k96 = 86
.line	545	loadk        r33   k97 ; k97 = 83
.line	545	loadk        r34   k98 ; k98 = 254
.line	545	loadk        r35   k99 ; k99 = 75
.line	545	loadk        r36  k100 ; k100 = 109
.line	545	loadk        r37  k101 ; k101 = 235
.line	545	loadk        r38   k11 ; k11 = 201
.line	545	loadk        r39  k102 ; k102 = 110
.line	545	loadk        r40  k103 ; k103 = 51
.line	545	loadk        r41  k104 ; k104 = 238
.line	545	call         r12    30     2
.line	545	call         r11     2     2
.line	545	gettable     r12   r11  k105 ; k105 = "SetTexture"
.line	545	move         r13    r6
.line	545	move         r14   r10
.line	545	newtable     r15     0     1
.line	545	settable     r15  k106  k107 ; k107 = false
.line	545	call         r12     4     1
.line	545	self         r12    r6  k108 ; k108 = "SetColorAndOpacity"
.line	545	gettabup     r14    u0  k109 ; k109 = "FLinearColor"
.line	545	loadk        r15   k64 ; k64 = 1
.line	545	loadk        r16   k64 ; k64 = 1
.line	545	loadk        r17   k64 ; k64 = 1
.line	545	loadk        r18   k64 ; k64 = 1
.line	545	call         r14     5     0
.line	545	call         r12     0     1
.label	l206
.line	545	move          r0    r0
.line	545	move          r0    r0
.label	l208
.line	545	return        r0     1
.line	545	gettabup      r0    u1  k103 ; k103 = 51
.line	545	return        r0     1

.function	main/f23

.source	null
.linedefined	580
.lastlinedefined	692
.numparams	4
.is_vararg	0
.maxstacksize	71

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	23	true
.upvalue	"U3"	13	true
.upvalue	"U4"	24	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	18
.constant	k3	68
.constant	k4	195
.constant	k5	96
.constant	k6	191
.constant	k7	228
.constant	k8	49
.constant	k9	70
.constant	k10	167
.constant	k11	201
.constant	k12	121
.constant	k13	57
.constant	k14	251
.constant	k15	182
.constant	k16	126
.constant	k17	130
.constant	k18	225
.constant	k19	100
.constant	k20	188
.constant	k21	65
.constant	k22	226
.constant	k23	81
.constant	k24	67
.constant	k25	168
.constant	k26	211
.constant	k27	110
.constant	k28	63
.constant	k29	"CurrentShowState"
.constant	k30	"Expression"
.constant	k31	"GetOwningPlayer"
.constant	k32	"slua"
.constant	k33	"isValid"
.constant	k34	"GetBackpackComponentFromController"
.constant	k35	"require"
.constant	k36	"table"
.constant	k37	"concat"
.constant	k38	4
.constant	k39	80
.constant	k40	199
.constant	k41	102
.constant	k42	152
.constant	k43	212
.constant	k44	40
.constant	k45	24
.constant	k46	208
.constant	k47	184
.constant	k48	99
.constant	k49	221
.constant	k50	254
.constant	k51	190
.constant	k52	29
.constant	k53	103
.constant	k54	253
.constant	k55	171
.constant	k56	200
.constant	k57	52
.constant	k58	31
.constant	k59	239
.constant	k60	166
.constant	k61	116
.constant	k62	205
.constant	k63	141
.constant	k64	64
.constant	k65	74
.constant	k66	87
.constant	k67	234
.constant	k68	108
.constant	k69	51
.constant	k70	207
.constant	k71	112
.constant	k72	38
.constant	k73	88
.constant	k74	128
.constant	k75	216
.constant	k76	"ClothBackpackItem"
.constant	k77	"GetClothBackpackItem"
.constant	k78	"GetShowExpressionList"
.constant	k79	223
.constant	k80	214
.constant	k81	240
.constant	k82	104
.constant	k83	174
.constant	k84	10
.constant	k85	197
.constant	k86	86
.constant	k87	105
.constant	k88	169
.constant	k89	23
.constant	k90	227
.constant	k91	160
.constant	k92	235
.constant	k93	202
.constant	k94	101
.constant	k95	179
.constant	k96	124
.constant	k97	115
.constant	k98	224
.constant	k99	19
.constant	k100	93
.constant	k101	203
.constant	k102	122
.constant	k103	139
.constant	k104	245
.constant	k105	89
.constant	k106	185
.constant	k107	"IsInMainCity"
.constant	k108	"GetExpressionItems"
.constant	k109	"GetPHomeSameAsMainCityExpressionList"
.constant	k110	0
.constant	k111	"_nWeaponShowEmoteID"
.constant	k112	"AllLimitEmoteList"
.constant	k113	"EmoteImageArray"
.constant	k114	"Num"
.constant	k115	"EmoteNameArray"
.constant	k116	"ItemInTheRing"
.constant	k117	"CurrentIndex"
.constant	k118	"pairs"
.constant	k119	"SlotSwitcherArray"
.constant	k120	"SetActiveWidgetIndex"
.constant	k121	1
.constant	k122	"DefineID"
.constant	k123	"TypeSpecificID"
.constant	k124	"PlayEmoteFeature"
.constant	k125	"EmoteLevelMap"
.constant	k126	"CDataTable"
.constant	k127	"GetTableData"
.constant	k128	119
.constant	k129	189
.constant	k130	194
.constant	k131	37
.constant	k132	83
.constant	k133	144
.constant	k134	193
.constant	k135	62
.constant	k136	247
.constant	k137	154
.constant	k138	118
.constant	k139	"Level"
.constant	k140	"EmoteIDLevel2"
.constant	k141	"ClientCacheShowEmoteEffect"
.constant	k142	2
.constant	k143	6
.constant	k144	92
.constant	k145	206
.constant	k146	39
.constant	k147	209
.constant	k148	"EmotionID"
.constant	k149	true
.constant	k150	"Name"
.constant	k151	162
.constant	k152	"ItemIDToImagePathMap"
.constant	k153	"ModuleManager"
.constant	k154	"GetModule"
.constant	k155	"CommonModuleConfig"
.constant	k156	"item_display_fallback_logic"
.constant	k157	"ResolveBattleIcon"
.constant	k158	"CurEmotePage"
.constant	k159	138
.constant	k160	117
.constant	k161	218
.constant	k162	164
.constant	k163	125
.constant	k164	77
.constant	k165	59
.constant	k166	"Get"
.constant	k167	32
.constant	k168	186
.constant	k169	213
.constant	k170	69
.constant	k171	217
.constant	k172	107
.constant	k173	21
.constant	k174	231
.constant	k175	176
.constant	k176	79
.constant	k177	222
.constant	k178	183
.constant	k179	75
.constant	k180	109
.constant	k181	238
.constant	k182	"SetTexture"
.constant	k183	"sync"
.constant	k184	false
.constant	k185	"EmoteEffectSwitcherArray"
.constant	k186	"SetWidgetVisibility"
.constant	k187	"UEnums"
.constant	k188	"ESlateVisibility"
.constant	k189	"SelfHitTestInvisible"
.constant	k190	"Collapsed"
.constant	k191	"SetColorAndOpacity"
.constant	k192	"FLinearColor"
.constant	k193	85
.constant	k194	252
.constant	k195	236
.constant	k196	90
.constant	k197	72
.constant	k198	"GetLocalizationString"
.constant	k199	"SetText"
.constant	k200	"sandbox"
.constant	k201	"LogNormal"
.constant	k202	196
.constant	k203	35
.constant	k204	61
.constant	k205	22
.constant	k206	46
.constant	k207	178
.constant	k208	250
.constant	k209	229
.constant	k210	42
.constant	k211	58
.constant	k212	136
.constant	k213	"Button_Left"
.constant	k214	"Visible"
.constant	k215	"Button_Right"
.constant	k216	"SetEmoteColorState"
.constant	k217	140
.constant	k218	204

.line	580	gettabup      r4    u0    k0 ; k0 = "print"
.line	580	gettabup      r5    u0    k1 ; k1 = "bWriteLog"
.line	580	test          r5     0
.line	580	jmp            0   l35
.line	580	getupval      r5    u1
.line	580	loadk         r6    k2 ; k2 = 18
.line	580	loadk         r7    k3 ; k3 = 68
.line	580	loadk         r8    k4 ; k4 = 195
.line	580	loadk         r9    k5 ; k5 = 96
.line	580	loadk        r10    k6 ; k6 = 191
.line	580	loadk        r11    k7 ; k7 = 228
.line	580	loadk        r12    k8 ; k8 = 49
.line	580	loadk        r13    k9 ; k9 = 70
.line	580	loadk        r14   k10 ; k10 = 167
.line	580	loadk        r15   k11 ; k11 = 201
.line	580	loadk        r16   k12 ; k12 = 121
.line	580	loadk        r17   k13 ; k13 = 57
.line	580	loadk        r18   k14 ; k14 = 251
.line	580	loadk        r19   k15 ; k15 = 182
.line	580	loadk        r20   k16 ; k16 = 126
.line	580	loadk        r21   k17 ; k17 = 130
.line	580	loadk        r22   k18 ; k18 = 225
.line	580	loadk        r23   k19 ; k19 = 100
.line	580	loadk        r24   k20 ; k20 = 188
.line	580	loadk        r25   k21 ; k21 = 65
.line	580	loadk        r26   k21 ; k21 = 65
.line	580	loadk        r27   k22 ; k22 = 226
.line	580	loadk        r28   k23 ; k23 = 81
.line	580	loadk        r29   k24 ; k24 = 67
.line	580	loadk        r30   k25 ; k25 = 168
.line	580	loadk        r31   k26 ; k26 = 211
.line	580	loadk        r32   k27 ; k27 = 110
.line	580	loadk        r33   k28 ; k28 = 63
.line	580	call          r5    29     2
.label	l35
.line	580	gettable      r6    r0   k29 ; k29 = "CurrentShowState"
.line	580	call          r4     3     1
.line	580	gettable      r4    r0   k29 ; k29 = "CurrentShowState"
.line	580	gettabup      r5    u2   k30 ; k30 = "Expression"
.line	580	eq             1    r4    r5
.line	580	jmp            0   l42
.line	580	return        r0     1
.label	l42
.line	580	self          r4    r0   k31 ; k31 = "GetOwningPlayer"
.line	580	call          r4     2     2
.line	580	test          r4     0
.line	580	jmp            0   l52
.line	580	gettabup      r5    u0   k32 ; k32 = "slua"
.line	580	gettable      r5    r5   k33 ; k33 = "isValid"
.line	580	move          r6    r4
.line	580	call          r5     2     2
.line	580	test          r5     1
.line	580	jmp            0   l53
.label	l52
.line	580	return        r0     1
.label	l53
.line	580	test          r3     0
.line	580	jmp            0   l61
.line	580	gettabup      r5    u0   k32 ; k32 = "slua"
.line	580	gettable      r5    r5   k33 ; k33 = "isValid"
.line	580	move          r6    r3
.line	580	call          r5     2     2
.line	580	test          r5     1
.line	580	jmp            0   l65
.label	l61
.line	580	gettabup      r5    u3   k34 ; k34 = "GetBackpackComponent" (truncated)
.line	580	move          r6    r4
.line	580	call          r5     2     2
.line	580	move          r3    r5
.label	l65
.line	580	test          r3     0
.line	580	jmp            0   l73
.line	580	gettabup      r5    u0   k32 ; k32 = "slua"
.line	580	gettable      r5    r5   k33 ; k33 = "isValid"
.line	580	move          r6    r3
.line	580	call          r5     2     2
.line	580	test          r5     1
.line	580	jmp            0   l74
.label	l73
.line	580	return        r0     1
.label	l74
.line	580	gettabup      r5    u0   k35 ; k35 = "require"
.line	580	gettabup      r6    u0   k36 ; k36 = "table"
.line	580	gettable      r6    r6   k37 ; k37 = "concat"
.line	580	newtable      r7     1     0
.line	580	getupval      r8    u1
.line	580	loadk         r9   k38 ; k38 = 4
.line	580	loadk        r10   k39 ; k39 = 80
.line	580	loadk        r11   k40 ; k40 = 199
.line	580	loadk        r12   k41 ; k41 = 102
.line	580	loadk        r13   k42 ; k42 = 152
.line	580	loadk        r14   k43 ; k43 = 212
.line	580	loadk        r15   k44 ; k44 = 40
.line	580	loadk        r16   k45 ; k45 = 24
.line	580	loadk        r17   k42 ; k42 = 152
.line	580	loadk        r18    k4 ; k4 = 195
.line	580	loadk        r19   k27 ; k27 = 110
.line	580	loadk        r20   k19 ; k19 = 100
.line	580	loadk        r21   k46 ; k46 = 208
.line	580	loadk        r22   k47 ; k47 = 184
.line	580	loadk        r23   k48 ; k48 = 99
.line	580	loadk        r24   k49 ; k49 = 221
.line	580	loadk        r25   k50 ; k50 = 254
.line	580	loadk        r26   k27 ; k27 = 110
.line	580	loadk        r27   k51 ; k51 = 190
.line	580	loadk        r28   k52 ; k52 = 29
.line	580	loadk        r29   k53 ; k53 = 103
.line	580	loadk        r30   k54 ; k54 = 253
.line	580	loadk        r31   k39 ; k39 = 80
.line	580	loadk        r32   k48 ; k48 = 99
.line	580	loadk        r33   k55 ; k55 = 171
.line	580	loadk        r34   k56 ; k56 = 200
.line	580	loadk        r35   k57 ; k57 = 52
.line	580	loadk        r36   k58 ; k58 = 31
.line	580	loadk        r37   k59 ; k59 = 239
.line	580	loadk        r38   k60 ; k60 = 166
.line	580	loadk        r39   k61 ; k61 = 116
.line	580	loadk        r40   k62 ; k62 = 205
.line	580	loadk        r41   k63 ; k63 = 141
.line	580	loadk        r42   k64 ; k64 = 64
.line	580	loadk        r43    k6 ; k6 = 191
.line	580	loadk        r44   k65 ; k65 = 74
.line	580	loadk        r45   k66 ; k66 = 87
.line	580	loadk        r46   k67 ; k67 = 234
.line	580	loadk        r47   k68 ; k68 = 108
.line	580	loadk        r48   k27 ; k27 = 110
.line	580	call          r8    41     2
.line	580	getupval      r9    u1
.line	580	loadk        r10   k69 ; k69 = 51
.line	580	loadk        r11   k24 ; k24 = 67
.line	580	loadk        r12   k70 ; k70 = 207
.line	580	loadk        r13   k71 ; k71 = 112
.line	580	loadk        r14   k10 ; k10 = 167
.line	580	loadk        r15   k56 ; k56 = 200
.line	580	loadk        r16   k72 ; k72 = 38
.line	580	loadk        r17   k73 ; k73 = 88
.line	580	loadk        r18   k74 ; k74 = 128
.line	580	loadk        r19   k75 ; k75 = 216
.line	580	loadk        r20   k48 ; k48 = 99
.line	580	loadk        r21   k72 ; k72 = 38
.line	580	loadk        r22   k18 ; k18 = 225
.line	580	call          r9    14     0
.line	580	setlist       r7     0     1
.line	580	call          r6     2     2
.line	580	call          r5     2     2
.line	580	gettable      r6    r5   k77 ; k77 = "GetClothBackpackItem"
.line	580	call          r6     1     2
.line	580	settable      r0   k76    r6 ; k76 = "ClothBackpackItem"
.line	580	gettable      r6    r5   k78 ; k78 = "GetShowExpressionLis" (truncated)
.line	580	call          r6     1     3
.line	580	gettabup      r8    u0   k35 ; k35 = "require"
.line	580	gettabup      r9    u0   k36 ; k36 = "table"
.line	580	gettable      r9    r9   k37 ; k37 = "concat"
.line	580	newtable     r10     1     0
.line	580	getupval     r11    u1
.line	580	loadk        r12   k38 ; k38 = 4
.line	580	loadk        r13   k39 ; k39 = 80
.line	580	loadk        r14   k40 ; k40 = 199
.line	580	loadk        r15   k41 ; k41 = 102
.line	580	loadk        r16   k42 ; k42 = 152
.line	580	loadk        r17   k43 ; k43 = 212
.line	580	loadk        r18   k44 ; k44 = 40
.line	580	loadk        r19   k45 ; k45 = 24
.line	580	loadk        r20   k42 ; k42 = 152
.line	580	loadk        r21    k4 ; k4 = 195
.line	580	loadk        r22   k27 ; k27 = 110
.line	580	loadk        r23   k19 ; k19 = 100
.line	580	loadk        r24   k79 ; k79 = 223
.line	580	loadk        r25   k47 ; k47 = 184
.line	580	loadk        r26   k12 ; k12 = 121
.line	580	loadk        r27   k80 ; k80 = 214
.line	580	loadk        r28   k81 ; k81 = 240
.line	580	loadk        r29   k82 ; k82 = 104
.line	580	loadk        r30   k83 ; k83 = 174
.line	580	loadk        r31   k65 ; k65 = 74
.line	580	loadk        r32   k84 ; k84 = 10
.line	580	loadk        r33   k85 ; k85 = 197
.line	580	loadk        r34   k86 ; k86 = 86
.line	580	loadk        r35   k87 ; k87 = 105
.line	580	loadk        r36   k88 ; k88 = 169
.line	580	loadk        r37   k70 ; k70 = 207
.line	580	loadk        r38   k57 ; k57 = 52
.line	580	loadk        r39   k89 ; k89 = 23
.line	580	loadk        r40   k90 ; k90 = 227
.line	580	loadk        r41   k91 ; k91 = 160
.line	580	loadk        r42   k27 ; k27 = 110
.line	580	loadk        r43   k92 ; k92 = 235
.line	580	loadk        r44   k93 ; k93 = 202
.line	580	loadk        r45   k94 ; k94 = 101
.line	580	loadk        r46   k95 ; k95 = 179
.line	580	loadk        r47   k96 ; k96 = 124
.line	580	loadk        r48   k97 ; k97 = 115
.line	580	loadk        r49   k98 ; k98 = 224
.line	580	loadk        r50    k3 ; k3 = 68
.line	580	loadk        r51   k97 ; k97 = 115
.line	580	call         r11    41     2
.line	580	getupval     r12    u1
.line	580	loadk        r13   k99 ; k99 = 19
.line	580	loadk        r14  k100 ; k100 = 93
.line	580	loadk        r15  k101 ; k101 = 203
.line	580	loadk        r16  k102 ; k102 = 122
.line	580	loadk        r17  k103 ; k103 = 139
.line	580	loadk        r18  k104 ; k104 = 245
.line	580	loadk        r19   k72 ; k72 = 38
.line	580	loadk        r20  k105 ; k105 = 89
.line	580	loadk        r21  k106 ; k106 = 185
.line	580	loadk        r22   k79 ; k79 = 223
.line	580	call         r12    11     0
.line	580	setlist      r10     0     1
.line	580	call          r9     2     2
.line	580	call          r8     2     2
.line	580	gettable      r9    r8  k107 ; k107 = "IsInMainCity"
.line	580	call          r9     1     2
.line	580	test          r9     0
.line	580	jmp            0  l212
.line	580	gettable      r9    r8  k108 ; k108 = "GetExpressionItems"
.line	580	call          r9     1     2
.line	580	move          r6    r9
.line	580	jmp            0  l218
.label	l212
.line	580	gettable      r9    r5  k109 ; k109 = "GetPHomeSameAsMainCi" (truncated)
.line	580	call          r9     1     2
.line	580	test          r9     0
.line	580	jmp            0  l218
.line	580	move          r6    r9
.line	580	loadk         r7  k110 ; k110 = 0
.label	l218
.line	580	settable      r0  k111    r7 ; k111 = "_nWeaponShowEmoteID"
.line	580	newtable      r9     0     0
.line	580	settable      r0  k112    r9 ; k112 = "AllLimitEmoteList"
.line	580	gettable      r9    r0  k113 ; k113 = "EmoteImageArray"
.line	580	self          r9    r9  k114 ; k114 = "Num"
.line	580	call          r9     2     2
.line	580	gettable     r10    r0  k115 ; k115 = "EmoteNameArray"
.line	580	self         r10   r10  k114 ; k114 = "Num"
.line	580	call         r10     2     2
.line	580	newtable     r11     0     0
.line	580	settable      r0  k116   r11 ; k116 = "ItemInTheRing"
.line	580	settable      r0  k117  k110 ; k110 = 0
.line	580	gettabup     r11    u0  k118 ; k118 = "pairs"
.line	580	gettable     r12    r0  k119 ; k119 = "SlotSwitcherArray"
.line	580	call         r11     2     4
.line	580	jmp            0  l239
.line	580	test         r15     0
.line	580	jmp            0  l239
.line	580	self         r16   r15  k120 ; k120 = "SetActiveWidgetIndex"
.line	580	loadk        r18  k121 ; k121 = 1
.line	580	call         r16     3     1
.label	l239
.line	580	move          r0    r0
.line	580	move          r0    r0
.line	580	loadbool     r11     0     0
.line	580	loadbool     r12     0     0
.line	580	gettabup     r13    u0  k118 ; k118 = "pairs"
.line	580	move         r14    r6
.line	580	call         r13     2     4
.line	580	jmp            0  l633
.line	580	gettable     r18   r17  k122 ; k122 = "DefineID"
.line	580	gettable     r18   r18  k123 ; k123 = "TypeSpecificID"
.line	580	loadk        r19  k110 ; k110 = 0
.line	580	gettable     r20    r4  k124 ; k124 = "PlayEmoteFeature"
.line	580	gettable     r20   r20  k125 ; k125 = "EmoteLevelMap"
.line	580	gettable     r20   r20   r18
.line	580	gettabup     r21    u0  k126 ; k126 = "CDataTable"
.line	580	gettable     r21   r21  k127 ; k127 = "GetTableData"
.line	580	getupval     r22    u1
.line	580	loadk        r23   k99 ; k99 = 19
.line	580	loadk        r24   k39 ; k39 = 80
.line	580	loadk        r25   k75 ; k75 = 216
.line	580	loadk        r26  k128 ; k128 = 119
.line	580	loadk        r27  k129 ; k129 = 189
.line	580	loadk        r28  k130 ; k130 = 194
.line	580	loadk        r29  k131 ; k131 = 37
.line	580	loadk        r30  k132 ; k132 = 83
.line	580	loadk        r31  k133 ; k133 = 144
.line	580	loadk        r32  k134 ; k134 = 193
.line	580	loadk        r33   k94 ; k94 = 101
.line	580	loadk        r34  k135 ; k135 = 62
.line	580	loadk        r35  k136 ; k136 = 247
.line	580	loadk        r36  k137 ; k137 = 154
.line	580	loadk        r37  k138 ; k138 = 118
.line	580	loadk        r38   k79 ; k79 = 223
.line	580	call         r22    17     2
.line	580	move         r23   r18
.line	580	call         r21     3     2
.line	580	test         r20     0
.line	580	jmp            0  l293
.line	580	test         r21     0
.line	580	jmp            0  l293
.line	580	gettable     r22   r21  k139 ; k139 = "Level"
.line	580	le             0   r22   r20
.line	580	jmp            0  l293
.line	580	gettable     r22   r21  k140 ; k140 = "EmoteIDLevel2"
.line	580	gettable     r23    r4  k124 ; k124 = "PlayEmoteFeature"
.line	580	gettable     r23   r23  k141 ; k141 = "ClientCacheShowEmote" (truncated)
.line	580	test         r23     0
.line	580	jmp            0  l292
.line	580	test         r22     0
.line	580	jmp            0  l292
.line	580	move         r18   r22
.line	580	loadk        r19  k142 ; k142 = 2
.line	580	jmp            0  l293
.label	l292
.line	580	loadk        r19  k121 ; k121 = 1
.label	l293
.line	580	gettabup     r22    u0  k126 ; k126 = "CDataTable"
.line	580	gettable     r22   r22  k127 ; k127 = "GetTableData"
.line	580	getupval     r23    u1
.line	580	loadk        r24  k143 ; k143 = 6
.line	580	loadk        r25  k144 ; k144 = 92
.line	580	loadk        r26   k85 ; k85 = 197
.line	580	loadk        r27  k128 ; k128 = 119
.line	580	loadk        r28  k129 ; k129 = 189
.line	580	loadk        r29  k145 ; k145 = 206
.line	580	loadk        r30  k146 ; k146 = 39
.line	580	loadk        r31  k102 ; k102 = 122
.line	580	loadk        r32   k20 ; k20 = 188
.line	580	loadk        r33  k134 ; k134 = 193
.line	580	loadk        r34   k48 ; k48 = 99
.line	580	loadk        r35  k135 ; k135 = 62
.line	580	loadk        r36  k147 ; k147 = 209
.line	580	loadk        r37    k6 ; k6 = 191
.line	580	loadk        r38  k128 ; k128 = 119
.line	580	call         r23    16     2
.line	580	move         r24   r18
.line	580	call         r22     3     2
.line	580	test         r22     0
.line	580	jmp            0  l322
.line	580	gettable     r23   r22  k148 ; k148 = "EmotionID"
.line	580	test         r23     0
.line	580	jmp            0  l322
.line	580	gettable     r23    r0  k112 ; k112 = "AllLimitEmoteList"
.line	580	gettable     r24   r22  k148 ; k148 = "EmotionID"
.line	580	settable     r23   r24  k149 ; k149 = true
.label	l322
.line	580	gettable     r23   r17  k150 ; k150 = "Name"
.line	580	test         r23     1
.line	580	jmp            0  l327
.line	580	getupval     r23    u1
.line	580	call         r23     1     2
.label	l327
.line	580	gettabup     r24    u0    k0 ; k0 = "print"
.line	580	gettabup     r25    u0    k1 ; k1 = "bWriteLog"
.line	580	test         r25     0
.line	580	jmp            0  l365
.line	580	getupval     r25    u1
.line	580	loadk        r26    k2 ; k2 = 18
.line	580	loadk        r27    k3 ; k3 = 68
.line	580	loadk        r28    k4 ; k4 = 195
.line	580	loadk        r29    k5 ; k5 = 96
.line	580	loadk        r30    k6 ; k6 = 191
.line	580	loadk        r31    k7 ; k7 = 228
.line	580	loadk        r32    k8 ; k8 = 49
.line	580	loadk        r33    k9 ; k9 = 70
.line	580	loadk        r34   k10 ; k10 = 167
.line	580	loadk        r35   k11 ; k11 = 201
.line	580	loadk        r36   k12 ; k12 = 121
.line	580	loadk        r37   k13 ; k13 = 57
.line	580	loadk        r38   k14 ; k14 = 251
.line	580	loadk        r39   k15 ; k15 = 182
.line	580	loadk        r40   k16 ; k16 = 126
.line	580	loadk        r41   k17 ; k17 = 130
.line	580	loadk        r42   k18 ; k18 = 225
.line	580	loadk        r43   k19 ; k19 = 100
.line	580	loadk        r44   k20 ; k20 = 188
.line	580	loadk        r45   k21 ; k21 = 65
.line	580	loadk        r46   k21 ; k21 = 65
.line	580	loadk        r47   k22 ; k22 = 226
.line	580	loadk        r48   k23 ; k23 = 81
.line	580	loadk        r49   k24 ; k24 = 67
.line	580	loadk        r50   k25 ; k25 = 168
.line	580	loadk        r51   k26 ; k26 = 211
.line	580	loadk        r52   k27 ; k27 = 110
.line	580	loadk        r53   k28 ; k28 = 63
.line	580	loadk        r54  k151 ; k151 = 162
.line	580	loadk        r55   k91 ; k91 = 160
.line	580	loadk        r56   k19 ; k19 = 100
.line	580	loadk        r57   k46 ; k46 = 208
.line	580	call         r25    33     2
.label	l365
.line	580	move         r26   r16
.line	580	gettable     r27    r0  k116 ; k116 = "ItemInTheRing"
.line	580	gettable     r27   r27   r18
.line	580	gettabup     r28    u4   r18
.line	580	call         r24     5     1
.line	580	gettable     r24    r0  k116 ; k116 = "ItemInTheRing"
.line	580	gettable     r24   r24   r18
.line	580	test         r24     1
.line	580	jmp            0  l633
.line	580	gettabup     r24    u4   r18
.line	580	test         r24     1
.line	580	jmp            0  l633
.line	580	gettable     r24    r0  k152 ; k152 = "ItemIDToImagePathMap"
.line	580	gettable     r24   r24   r18
.line	580	gettabup     r25    u0  k153 ; k153 = "ModuleManager"
.line	580	gettable     r25   r25  k154 ; k154 = "GetModule"
.line	580	gettabup     r26    u0  k153 ; k153 = "ModuleManager"
.line	580	gettable     r26   r26  k155 ; k155 = "CommonModuleConfig"
.line	580	gettable     r26   r26  k156 ; k156 = "item_display_fallbac" (truncated)
.line	580	call         r25     2     2
.line	580	self         r26   r25  k157 ; k157 = "ResolveBattleIcon"
.line	580	move         r28   r18
.line	580	move         r29   r24
.line	580	call         r26     4     2
.line	580	move         r24   r26
.line	580	test         r24     0
.line	580	jmp            0  l592
.line	580	gettable     r26    r0  k117 ; k117 = "CurrentIndex"
.line	580	gettable     r27    r0  k158 ; k158 = "CurEmotePage"
.line	580	mul          r27   r27    r9
.line	580	sub          r26   r26   r27
.line	580	gettable     r27    r0  k116 ; k116 = "ItemInTheRing"
.line	580	settable     r27   r18   r26
.line	580	gettable     r27    r0  k117 ; k117 = "CurrentIndex"
.line	580	add          r27   r27  k121 ; k121 = 1
.line	580	settable      r0  k117   r27 ; k117 = "CurrentIndex"
.line	580	gettabup     r27    u0    k0 ; k0 = "print"
.line	580	gettabup     r28    u0    k1 ; k1 = "bWriteLog"
.line	580	test         r28     0
.line	580	jmp            0  l455
.line	580	gettabup     r28    u0   k36 ; k36 = "table"
.line	580	gettable     r28   r28   k37 ; k37 = "concat"
.line	580	newtable     r29     1     0
.line	580	getupval     r30    u1
.line	580	loadk        r31    k2 ; k2 = 18
.line	580	loadk        r32    k3 ; k3 = 68
.line	580	loadk        r33    k4 ; k4 = 195
.line	580	loadk        r34    k5 ; k5 = 96
.line	580	loadk        r35    k6 ; k6 = 191
.line	580	loadk        r36    k7 ; k7 = 228
.line	580	loadk        r37    k8 ; k8 = 49
.line	580	loadk        r38    k9 ; k9 = 70
.line	580	loadk        r39   k10 ; k10 = 167
.line	580	loadk        r40   k11 ; k11 = 201
.line	580	loadk        r41   k12 ; k12 = 121
.line	580	loadk        r42   k13 ; k13 = 57
.line	580	loadk        r43   k14 ; k14 = 251
.line	580	loadk        r44   k15 ; k15 = 182
.line	580	loadk        r45   k16 ; k16 = 126
.line	580	loadk        r46   k17 ; k17 = 130
.line	580	loadk        r47   k18 ; k18 = 225
.line	580	loadk        r48   k19 ; k19 = 100
.line	580	loadk        r49   k20 ; k20 = 188
.line	580	loadk        r50   k21 ; k21 = 65
.line	580	loadk        r51   k21 ; k21 = 65
.line	580	loadk        r52   k22 ; k22 = 226
.line	580	loadk        r53   k23 ; k23 = 81
.line	580	loadk        r54   k24 ; k24 = 67
.line	580	loadk        r55   k25 ; k25 = 168
.line	580	loadk        r56   k26 ; k26 = 211
.line	580	loadk        r57   k27 ; k27 = 110
.line	580	loadk        r58   k28 ; k28 = 63
.line	580	loadk        r59  k151 ; k151 = 162
.line	580	loadk        r60  k159 ; k159 = 138
.line	580	loadk        r61  k160 ; k160 = 117
.line	580	loadk        r62  k161 ; k161 = 218
.line	580	loadk        r63  k147 ; k147 = 209
.line	580	loadk        r64   k61 ; k61 = 116
.line	580	loadk        r65  k162 ; k162 = 164
.line	580	loadk        r66   k66 ; k66 = 87
.line	580	loadk        r67  k163 ; k163 = 125
.line	580	loadk        r68   k59 ; k59 = 239
.line	580	loadk        r69  k164 ; k164 = 77
.line	580	loadk        r70   k97 ; k97 = 115
.line	580	call         r30    41     2
.line	580	getupval     r31    u1
.line	580	loadk        r32  k165 ; k165 = 59
.line	580	call         r31     2     0
.line	580	setlist      r29     0     1
.line	580	call         r28     2     2
.label	l455
.line	580	gettable     r29    r0  k117 ; k117 = "CurrentIndex"
.line	580	move         r30   r26
.line	580	move         r31    r9
.line	580	call         r27     5     1
.line	580	lt             0   r26  k110 ; k110 = 0
.line	580	jmp            0  l463
.line	580	loadbool     r11     1     0
.line	580	jmp            0  l633
.label	l463
.line	580	le             0    r9   r26
.line	580	jmp            0  l467
.line	580	loadbool     r12     1     0
.line	580	jmp            0  l633
.label	l467
.line	580	gettable     r27    r0  k113 ; k113 = "EmoteImageArray"
.line	580	self         r27   r27  k166 ; k166 = "Get"
.line	580	move         r29   r26
.line	580	call         r27     3     2
.line	580	gettabup     r28    u0   k35 ; k35 = "require"
.line	580	getupval     r29    u1
.line	580	loadk        r30  k167 ; k167 = 32
.line	580	loadk        r31  k100 ; k100 = 93
.line	580	loadk        r32    k4 ; k4 = 195
.line	580	loadk        r33   k41 ; k41 = 102
.line	580	loadk        r34  k168 ; k168 = 186
.line	580	loadk        r35  k169 ; k169 = 213
.line	580	loadk        r36   k53 ; k53 = 103
.line	580	loadk        r37  k170 ; k170 = 69
.line	580	loadk        r38  k106 ; k106 = 185
.line	580	loadk        r39  k171 ; k171 = 217
.line	580	loadk        r40  k172 ; k172 = 107
.line	580	loadk        r41  k173 ; k173 = 21
.line	580	loadk        r42  k174 ; k174 = 231
.line	580	loadk        r43  k175 ; k175 = 176
.line	580	loadk        r44  k176 ; k176 = 79
.line	580	loadk        r45  k177 ; k177 = 222
.line	580	loadk        r46  k134 ; k134 = 193
.line	580	loadk        r47    k5 ; k5 = 96
.line	580	loadk        r48  k178 ; k178 = 183
.line	580	loadk        r49   k86 ; k86 = 86
.line	580	loadk        r50  k132 ; k132 = 83
.line	580	loadk        r51   k50 ; k50 = 254
.line	580	loadk        r52  k179 ; k179 = 75
.line	580	loadk        r53  k180 ; k180 = 109
.line	580	loadk        r54   k92 ; k92 = 235
.line	580	loadk        r55   k11 ; k11 = 201
.line	580	loadk        r56   k27 ; k27 = 110
.line	580	loadk        r57   k69 ; k69 = 51
.line	580	loadk        r58  k181 ; k181 = 238
.line	580	call         r29    30     2
.line	580	call         r28     2     2
.line	580	gettable     r29   r28  k182 ; k182 = "SetTexture"
.line	580	move         r30   r27
.line	580	move         r31   r24
.line	580	newtable     r32     0     1
.line	580	settable     r32  k183  k184 ; k184 = false
.line	580	call         r29     4     1
.line	580	gettable     r29    r0  k185 ; k185 = "EmoteEffectSwitcherA" (truncated)
.line	580	self         r29   r29  k166 ; k166 = "Get"
.line	580	move         r31   r26
.line	580	call         r29     3     2
.line	580	eq             0   r19  k121 ; k121 = 1
.line	580	jmp            0  l525
.line	580	self         r30   r29  k186 ; k186 = "SetWidgetVisibility"
.line	580	gettabup     r32    u0  k187 ; k187 = "UEnums"
.line	580	gettable     r32   r32  k188 ; k188 = "ESlateVisibility"
.line	580	gettable     r32   r32  k189 ; k189 = "SelfHitTestInvisible"
.line	580	call         r30     3     1
.line	580	self         r30   r29  k120 ; k120 = "SetActiveWidgetIndex"
.line	580	loadk        r32  k110 ; k110 = 0
.line	580	call         r30     3     1
.line	580	jmp            0  l541
.label	l525
.line	580	eq             0   r19  k142 ; k142 = 2
.line	580	jmp            0  l536
.line	580	self         r30   r29  k186 ; k186 = "SetWidgetVisibility"
.line	580	gettabup     r32    u0  k187 ; k187 = "UEnums"
.line	580	gettable     r32   r32  k188 ; k188 = "ESlateVisibility"
.line	580	gettable     r32   r32  k189 ; k189 = "SelfHitTestInvisible"
.line	580	call         r30     3     1
.line	580	self         r30   r29  k120 ; k120 = "SetActiveWidgetIndex"
.line	580	loadk        r32  k121 ; k121 = 1
.line	580	call         r30     3     1
.line	580	jmp            0  l541
.label	l536
.line	580	self         r30   r29  k186 ; k186 = "SetWidgetVisibility"
.line	580	gettabup     r32    u0  k187 ; k187 = "UEnums"
.line	580	gettable     r32   r32  k188 ; k188 = "ESlateVisibility"
.line	580	gettable     r32   r32  k190 ; k190 = "Collapsed"
.line	580	call         r30     3     1
.label	l541
.line	580	self         r30   r27  k191 ; k191 = "SetColorAndOpacity"
.line	580	gettabup     r32    u0  k192 ; k192 = "FLinearColor"
.line	580	loadk        r33  k121 ; k121 = 1
.line	580	loadk        r34  k121 ; k121 = 1
.line	580	loadk        r35  k121 ; k121 = 1
.line	580	loadk        r36  k121 ; k121 = 1
.line	580	call         r32     5     0
.line	580	call         r30     0     1
.line	580	gettable     r30    r0  k119 ; k119 = "SlotSwitcherArray"
.line	580	self         r30   r30  k166 ; k166 = "Get"
.line	580	move         r32   r26
.line	580	call         r30     3     2
.line	580	self         r31   r30  k120 ; k120 = "SetActiveWidgetIndex"
.line	580	loadk        r33  k110 ; k110 = 0
.line	580	call         r31     3     1
.line	580	gettabup     r31    u0   k35 ; k35 = "require"
.line	580	getupval     r32    u1
.line	580	loadk        r33  k167 ; k167 = 32
.line	580	loadk        r34  k100 ; k100 = 93
.line	580	loadk        r35    k4 ; k4 = 195
.line	580	loadk        r36   k41 ; k41 = 102
.line	580	loadk        r37  k168 ; k168 = 186
.line	580	loadk        r38  k169 ; k169 = 213
.line	580	loadk        r39   k53 ; k53 = 103
.line	580	loadk        r40  k193 ; k193 = 85
.line	580	loadk        r41  k168 ; k168 = 186
.line	580	loadk        r42  k134 ; k134 = 193
.line	580	loadk        r43   k53 ; k53 = 103
.line	580	loadk        r44  k131 ; k131 = 37
.line	580	loadk        r45  k194 ; k194 = 252
.line	580	loadk        r46  k136 ; k136 = 247
.line	580	loadk        r47   k94 ; k94 = 101
.line	580	loadk        r48  k147 ; k147 = 209
.line	580	loadk        r49  k195 ; k195 = 236
.line	580	loadk        r50   k61 ; k61 = 116
.line	580	loadk        r51   k83 ; k83 = 174
.line	580	loadk        r52  k196 ; k196 = 90
.line	580	loadk        r53  k197 ; k197 = 72
.line	580	call         r32    22     2
.line	580	call         r31     2     2
.line	580	gettable     r32   r31  k198 ; k198 = "GetLocalizationStrin" (truncated)
.line	580	move         r33   r23
.line	580	call         r32     2     2
.line	580	gettable     r33    r0  k115 ; k115 = "EmoteNameArray"
.line	580	self         r33   r33  k166 ; k166 = "Get"
.line	580	move         r35   r26
.line	580	call         r33     3     2
.line	580	self         r34   r33  k199 ; k199 = "SetText"
.line	580	move         r36   r32
.line	580	call         r34     3     1
.line	580	jmp            0  l633
.label	l592
.line	580	gettabup     r26    u0  k200 ; k200 = "sandbox"
.line	580	gettable     r26   r26  k201 ; k201 = "LogNormal"
.line	580	gettabup     r27    u0    k1 ; k1 = "bWriteLog"
.line	580	test         r27     0
.line	580	jmp            0  l631
.line	580	getupval     r27    u1
.line	580	loadk        r28  k110 ; k110 = 0
.line	580	loadk        r29   k39 ; k39 = 80
.line	580	loadk        r30  k202 ; k202 = 196
.line	580	loadk        r31  k203 ; k203 = 35
.line	580	loadk        r32  k168 ; k168 = 186
.line	580	loadk        r33  k145 ; k145 = 206
.line	580	loadk        r34  k204 ; k204 = 61
.line	580	loadk        r35  k205 ; k205 = 22
.line	580	loadk        r36   k95 ; k95 = 179
.line	580	loadk        r37   k85 ; k85 = 197
.line	580	loadk        r38   k19 ; k19 = 100
.line	580	loadk        r39  k206 ; k206 = 46
.line	580	loadk        r40  k207 ; k207 = 178
.line	580	loadk        r41  k175 ; k175 = 176
.line	580	loadk        r42  k163 ; k163 = 125
.line	580	loadk        r43  k171 ; k171 = 217
.line	580	loadk        r44   k43 ; k43 = 212
.line	580	loadk        r45   k19 ; k19 = 100
.line	580	loadk        r46  k208 ; k208 = 250
.line	580	loadk        r47   k24 ; k24 = 67
.line	580	loadk        r48  k170 ; k170 = 69
.line	580	loadk        r49  k209 ; k209 = 229
.line	580	loadk        r50   k23 ; k23 = 81
.line	580	loadk        r51  k210 ; k210 = 42
.line	580	loadk        r52  k209 ; k209 = 229
.line	580	loadk        r53  k169 ; k169 = 213
.line	580	loadk        r54   k16 ; k16 = 126
.line	580	loadk        r55  k102 ; k102 = 122
.line	580	loadk        r56   k92 ; k92 = 235
.line	580	loadk        r57  k168 ; k168 = 186
.line	580	loadk        r58  k211 ; k211 = 58
.line	580	loadk        r59  k212 ; k212 = 136
.line	580	call         r27    33     2
.label	l631
.line	580	move         r28   r18
.line	580	call         r26     3     1
.label	l633
.line	580	move          r0    r0
.line	580	move          r0    r0
.line	580	test         r11     0
.line	580	jmp            0  l646
.line	580	gettable     r13    r0  k158 ; k158 = "CurEmotePage"
.line	580	lt             0  k110   r13 ; k110 = 0
.line	580	jmp            0  l646
.line	580	gettable     r13    r0  k213 ; k213 = "Button_Left"
.line	580	self         r13   r13  k186 ; k186 = "SetWidgetVisibility"
.line	580	gettabup     r15    u0  k187 ; k187 = "UEnums"
.line	580	gettable     r15   r15  k188 ; k188 = "ESlateVisibility"
.line	580	gettable     r15   r15  k214 ; k214 = "Visible"
.line	580	call         r13     3     1
.label	l646
.line	580	test         r12     0
.line	580	jmp            0  l654
.line	580	gettable     r13    r0  k215 ; k215 = "Button_Right"
.line	580	self         r13   r13  k186 ; k186 = "SetWidgetVisibility"
.line	580	gettabup     r15    u0  k187 ; k187 = "UEnums"
.line	580	gettable     r15   r15  k188 ; k188 = "ESlateVisibility"
.line	580	gettable     r15   r15  k214 ; k214 = "Visible"
.line	580	call         r13     3     1
.label	l654
.line	580	gettabup     r13    u0  k118 ; k118 = "pairs"
.line	580	move         r14    r6
.line	580	call         r13     2     4
.line	580	jmp            0  l663
.line	580	gettable     r18   r17  k122 ; k122 = "DefineID"
.line	580	gettable     r18   r18  k123 ; k123 = "TypeSpecificID"
.line	580	self         r19    r0  k216 ; k216 = "SetEmoteColorState"
.line	580	move         r21   r18
.line	580	call         r19     3     1
.label	l663
.line	580	move          r0    r0
.line	580	move          r0    r0
.line	580	gettabup     r13    u0    k0 ; k0 = "print"
.line	580	gettabup     r14    u0    k1 ; k1 = "bWriteLog"
.line	580	test         r14     0
.line	580	jmp            0  l703
.line	580	getupval     r14    u1
.line	580	loadk        r15    k2 ; k2 = 18
.line	580	loadk        r16    k3 ; k3 = 68
.line	580	loadk        r17    k4 ; k4 = 195
.line	580	loadk        r18    k5 ; k5 = 96
.line	580	loadk        r19    k6 ; k6 = 191
.line	580	loadk        r20    k7 ; k7 = 228
.line	580	loadk        r21    k8 ; k8 = 49
.line	580	loadk        r22    k9 ; k9 = 70
.line	580	loadk        r23   k10 ; k10 = 167
.line	580	loadk        r24   k11 ; k11 = 201
.line	580	loadk        r25   k12 ; k12 = 121
.line	580	loadk        r26   k13 ; k13 = 57
.line	580	loadk        r27   k14 ; k14 = 251
.line	580	loadk        r28   k15 ; k15 = 182
.line	580	loadk        r29   k16 ; k16 = 126
.line	580	loadk        r30   k17 ; k17 = 130
.line	580	loadk        r31   k18 ; k18 = 225
.line	580	loadk        r32   k19 ; k19 = 100
.line	580	loadk        r33   k20 ; k20 = 188
.line	580	loadk        r34   k21 ; k21 = 65
.line	580	loadk        r35   k21 ; k21 = 65
.line	580	loadk        r36   k22 ; k22 = 226
.line	580	loadk        r37   k23 ; k23 = 81
.line	580	loadk        r38   k24 ; k24 = 67
.line	580	loadk        r39   k25 ; k25 = 168
.line	580	loadk        r40   k26 ; k26 = 211
.line	580	loadk        r41   k27 ; k27 = 110
.line	580	loadk        r42   k28 ; k28 = 63
.line	580	loadk        r43  k151 ; k151 = 162
.line	580	loadk        r44  k217 ; k217 = 140
.line	580	loadk        r45   k27 ; k27 = 110
.line	580	loadk        r46  k218 ; k218 = 204
.line	580	call         r14    33     2
.label	l703
.line	580	gettable     r15    r0  k117 ; k117 = "CurrentIndex"
.line	580	len          r16    r6
.line	580	call         r13     4     1
.line	580	return        r0     1
.line	580	move          r0    r0
.line	580	return        r0     1

.function	main/f24

.source	null
.linedefined	694
.lastlinedefined	718
.numparams	3
.is_vararg	0
.maxstacksize	12

.upvalue	"_ENV"	11	true
.upvalue	"U1"	9	true
.upvalue	"U2"	0	false
.upvalue	"U3"	8	true
.upvalue	"U4"	12	true

.constant	k0	"GetLocalSize"
.constant	k1	"PointerEvent_GetScreenSpacePosition"
.constant	k2	"AbsoluteToLocal"
.constant	k3	"FVector2D"
.constant	k4	0
.constant	k5	"X"
.constant	k6	0.5
.constant	k7	"Y"
.constant	k8	"math"
.constant	k9	"sqrt"
.constant	k10	"InnerCircleRadius"
.constant	k11	"ButtonLength"
.constant	k12	"ClockWiseOffset"
.constant	k13	"DegAcos"
.constant	k14	360
.constant	k15	"SectorButtonDegree"
.constant	k16	"SectorButtonNum"
.constant	k17	"FFloor"
.constant	k18	"SectorButtonHalfDegree"
.constant	k19	"EmoteImageArray"
.constant	k20	"Num"
.constant	k21	"OnClickItem"
.constant	k22	"Handled"

.line	694	gettabup      r3    u0    k0 ; k0 = "GetLocalSize"
.line	694	move          r4    r1
.line	694	call          r3     2     2
.line	694	gettabup      r4    u1    k1 ; k1 = "PointerEvent_GetScre" (truncated)
.line	694	move          r5    r2
.line	694	call          r4     2     2
.line	694	gettabup      r5    u0    k2 ; k2 = "AbsoluteToLocal"
.line	694	move          r6    r1
.line	694	move          r7    r4
.line	694	call          r5     3     2
.line	694	gettabup      r6    u2    k3 ; k3 = "FVector2D"
.line	694	loadk         r7    k4 ; k4 = 0
.line	694	loadk         r8    k4 ; k4 = 0
.line	694	call          r6     3     2
.line	694	gettable      r7    r5    k5 ; k5 = "X"
.line	694	gettable      r8    r3    k5 ; k5 = "X"
.line	694	mul           r8    r8    k6 ; k6 = 0.5
.line	694	sub           r7    r7    r8
.line	694	settable      r6    k5    r7 ; k5 = "X"
.line	694	gettable      r7    r5    k7 ; k7 = "Y"
.line	694	gettable      r8    r3    k7 ; k7 = "Y"
.line	694	mul           r8    r8    k6 ; k6 = 0.5
.line	694	sub           r7    r7    r8
.line	694	settable      r6    k7    r7 ; k7 = "Y"
.line	694	gettabup      r7    u2    k8 ; k8 = "math"
.line	694	gettable      r7    r7    k9 ; k9 = "sqrt"
.line	694	gettable      r8    r6    k5 ; k5 = "X"
.line	694	gettable      r9    r6    k5 ; k5 = "X"
.line	694	mul           r8    r8    r9
.line	694	gettable      r9    r6    k7 ; k7 = "Y"
.line	694	gettable     r10    r6    k7 ; k7 = "Y"
.line	694	mul           r9    r9   r10
.line	694	add           r8    r8    r9
.line	694	call          r7     2     2
.line	694	gettable      r8    r0   k10 ; k10 = "InnerCircleRadius"
.line	694	lt             0    r8    r7
.line	694	jmp            0   l85
.line	694	gettable      r8    r0   k10 ; k10 = "InnerCircleRadius"
.line	694	gettable      r9    r0   k11 ; k11 = "ButtonLength"
.line	694	add           r8    r8    r9
.line	694	le             0    r7    r8
.line	694	jmp            0   l85
.line	694	gettable      r8    r6    k5 ; k5 = "X"
.line	694	lt             1    k4    r8 ; k4 = 0
.line	694	jmp            0   l47
.line	694	loadbool      r8     0     1
.label	l47
.line	694	loadbool      r8     1     0
.line	694	test          r8     0
.line	694	jmp            0   l57
.line	694	gettabup      r9    u3   k13 ; k13 = "DegAcos"
.line	694	gettable     r10    r6    k7 ; k7 = "Y"
.line	694	unm          r10   r10
.line	694	div          r10   r10    r7
.line	694	call          r9     2     2
.line	694	settable      r0   k12    r9 ; k12 = "ClockWiseOffset"
.line	694	jmp            0   l64
.label	l57
.line	694	gettabup      r9    u3   k13 ; k13 = "DegAcos"
.line	694	gettable     r10    r6    k7 ; k7 = "Y"
.line	694	unm          r10   r10
.line	694	div          r10   r10    r7
.line	694	call          r9     2     2
.line	694	sub           r9   k14    r9 ; k14 = 360
.line	694	settable      r0   k12    r9 ; k12 = "ClockWiseOffset"
.label	l64
.line	694	gettable      r9    r0   k15 ; k15 = "SectorButtonDegree"
.line	694	lt             0    k4    r9 ; k4 = 0
.line	694	jmp            0   l85
.line	694	gettabup      r9    u3   k17 ; k17 = "FFloor"
.line	694	gettable     r10    r0   k12 ; k12 = "ClockWiseOffset"
.line	694	gettable     r11    r0   k18 ; k18 = "SectorButtonHalfDegr" (truncated)
.line	694	add          r10   r10   r11
.line	694	gettable     r11    r0   k15 ; k15 = "SectorButtonDegree"
.line	694	div          r10   r10   r11
.line	694	call          r9     2     2
.line	694	settable      r0   k16    r9 ; k16 = "SectorButtonNum"
.line	694	gettable      r9    r0   k16 ; k16 = "SectorButtonNum"
.line	694	gettable     r10    r0   k19 ; k19 = "EmoteImageArray"
.line	694	self         r10   r10   k20 ; k20 = "Num"
.line	694	call         r10     2     2
.line	694	eq             0    r9   r10
.line	694	jmp            0   l82
.line	694	settable      r0   k16    k4 ; k4 = 0
.label	l82
.line	694	self          r9    r0   k21 ; k21 = "OnClickItem"
.line	694	gettable     r11    r0   k16 ; k16 = "SectorButtonNum"
.line	694	call          r9     3     1
.label	l85
.line	694	gettabup      r8    u4   k22 ; k22 = "Handled"
.line	694	tailcall      r8     1
.line	694	return        r8     0
.line	694	return        r0     1
.line	694	move          r0    r0
.line	694	move          r0    r0
.line	694	return        r0     1

.function	main/f25

.source	null
.linedefined	720
.lastlinedefined	735
.numparams	2
.is_vararg	0
.maxstacksize	31

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	23	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	18
.constant	k3	68
.constant	k4	195
.constant	k5	96
.constant	k6	191
.constant	k7	228
.constant	k8	49
.constant	k9	70
.constant	k10	167
.constant	k11	201
.constant	k12	121
.constant	k13	57
.constant	k14	251
.constant	k15	182
.constant	k16	126
.constant	k17	130
.constant	k18	252
.constant	k19	111
.constant	k20	153
.constant	k21	95
.constant	k22	77
.constant	k23	242
.constant	k24	82
.constant	k25	79
.constant	k26	177
.constant	k27	217
.constant	k28	119
.constant	k29	"CurrentShowState"
.constant	k30	"Expression"
.constant	k31	"TryToPlayEmote"
.constant	k32	"PetExpression"
.constant	k33	"TryToPlayPetExpression"
.constant	k34	"Bubble"
.constant	k35	"TryToPlayBubble"
.constant	k36	"Collection"
.constant	k37	"TryToPlayCollection"
.constant	k38	"Flaunt"
.constant	k39	"TryToPlayFlaunt"
.constant	k40	"MiniTvExpression"
.constant	k41	"TryToPlayMiniTvExpression"

.line	720	gettabup      r2    u0    k0 ; k0 = "print"
.line	720	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	720	test          r3     0
.line	720	jmp            0   l34
.line	720	getupval      r3    u1
.line	720	loadk         r4    k2 ; k2 = 18
.line	720	loadk         r5    k3 ; k3 = 68
.line	720	loadk         r6    k4 ; k4 = 195
.line	720	loadk         r7    k5 ; k5 = 96
.line	720	loadk         r8    k6 ; k6 = 191
.line	720	loadk         r9    k7 ; k7 = 228
.line	720	loadk        r10    k8 ; k8 = 49
.line	720	loadk        r11    k9 ; k9 = 70
.line	720	loadk        r12   k10 ; k10 = 167
.line	720	loadk        r13   k11 ; k11 = 201
.line	720	loadk        r14   k12 ; k12 = 121
.line	720	loadk        r15   k13 ; k13 = 57
.line	720	loadk        r16   k14 ; k14 = 251
.line	720	loadk        r17   k15 ; k15 = 182
.line	720	loadk        r18   k16 ; k16 = 126
.line	720	loadk        r19   k17 ; k17 = 130
.line	720	loadk        r20   k18 ; k18 = 252
.line	720	loadk        r21   k19 ; k19 = 111
.line	720	loadk        r22   k20 ; k20 = 153
.line	720	loadk        r23   k21 ; k21 = 95
.line	720	loadk        r24   k22 ; k22 = 77
.line	720	loadk        r25   k23 ; k23 = 242
.line	720	loadk        r26   k24 ; k24 = 82
.line	720	loadk        r27   k25 ; k25 = 79
.line	720	loadk        r28   k26 ; k26 = 177
.line	720	loadk        r29   k27 ; k27 = 217
.line	720	loadk        r30   k28 ; k28 = 119
.line	720	call          r3    28     2
.label	l34
.line	720	move          r4    r1
.line	720	gettable      r5    r0   k29 ; k29 = "CurrentShowState"
.line	720	call          r2     4     1
.line	720	gettable      r2    r0   k29 ; k29 = "CurrentShowState"
.line	720	gettabup      r3    u2   k30 ; k30 = "Expression"
.line	720	eq             0    r2    r3
.line	720	jmp            0   l45
.line	720	self          r2    r0   k31 ; k31 = "TryToPlayEmote"
.line	720	move          r4    r1
.line	720	call          r2     3     1
.line	720	jmp            0   l84
.label	l45
.line	720	gettable      r2    r0   k29 ; k29 = "CurrentShowState"
.line	720	gettabup      r3    u2   k32 ; k32 = "PetExpression"
.line	720	eq             0    r2    r3
.line	720	jmp            0   l53
.line	720	self          r2    r0   k33 ; k33 = "TryToPlayPetExpressi" (truncated)
.line	720	move          r4    r1
.line	720	call          r2     3     1
.line	720	jmp            0   l84
.label	l53
.line	720	gettable      r2    r0   k29 ; k29 = "CurrentShowState"
.line	720	gettabup      r3    u2   k34 ; k34 = "Bubble"
.line	720	eq             0    r2    r3
.line	720	jmp            0   l61
.line	720	self          r2    r0   k35 ; k35 = "TryToPlayBubble"
.line	720	move          r4    r1
.line	720	call          r2     3     1
.line	720	jmp            0   l84
.label	l61
.line	720	gettable      r2    r0   k29 ; k29 = "CurrentShowState"
.line	720	gettabup      r3    u2   k36 ; k36 = "Collection"
.line	720	eq             0    r2    r3
.line	720	jmp            0   l69
.line	720	self          r2    r0   k37 ; k37 = "TryToPlayCollection"
.line	720	move          r4    r1
.line	720	call          r2     3     1
.line	720	jmp            0   l84
.label	l69
.line	720	gettable      r2    r0   k29 ; k29 = "CurrentShowState"
.line	720	gettabup      r3    u2   k38 ; k38 = "Flaunt"
.line	720	eq             0    r2    r3
.line	720	jmp            0   l77
.line	720	self          r2    r0   k39 ; k39 = "TryToPlayFlaunt"
.line	720	move          r4    r1
.line	720	call          r2     3     1
.line	720	jmp            0   l84
.label	l77
.line	720	gettable      r2    r0   k29 ; k29 = "CurrentShowState"
.line	720	gettabup      r3    u2   k40 ; k40 = "MiniTvExpression"
.line	720	eq             0    r2    r3
.line	720	jmp            0   l84
.line	720	self          r2    r0   k41 ; k41 = "TryToPlayMiniTvExpre" (truncated)
.line	720	move          r4    r1
.line	720	call          r2     3     1
.label	l84
.line	720	return        r0     1
.line	720	move          r0    r0
.line	720	move          r0    r0
.line	720	move          r0    r0
.line	720	return        r0     1

.function	main/f26

.source	null
.linedefined	737
.lastlinedefined	750
.numparams	2
.is_vararg	0
.maxstacksize	36

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"uBubbleIDList"
.constant	k1	nil
.constant	k2	1
.constant	k3	"print"
.constant	k4	"bWriteLog"
.constant	k5	18
.constant	k6	68
.constant	k7	195
.constant	k8	96
.constant	k9	191
.constant	k10	228
.constant	k11	49
.constant	k12	70
.constant	k13	167
.constant	k14	201
.constant	k15	121
.constant	k16	57
.constant	k17	251
.constant	k18	182
.constant	k19	126
.constant	k20	130
.constant	k21	231
.constant	k22	115
.constant	k23	163
.constant	k24	103
.constant	k25	75
.constant	k26	193
.constant	k27	85
.constant	k28	188
.constant	k29	254
.constant	k30	111
.constant	k31	56
.constant	k32	224
.constant	k33	165
.constant	k34	101
.constant	k35	"GameplaySysMgr"
.constant	k36	"GetSysByName"
.constant	k37	10
.constant	k38	66
.constant	k39	198
.constant	k40	98
.constant	k41	186
.constant	k42	197
.constant	k43	11
.constant	k44	67
.constant	k45	183
.constant	k46	206
.constant	k47	102
.constant	k48	47
.constant	k49	215
.constant	k50	180
.constant	k51	127
.constant	k52	204
.constant	k53	214
.constant	k54	82
.constant	k55	64
.constant	k56	"ReqDoBubbleEmote"
.constant	k57	"ShowOrHideRing"

.line	737	gettable      r2    r0    k0 ; k0 = "uBubbleIDList"
.line	737	eq             0    r2    k1 ; k1 = nil
.line	737	jmp            0    l5
.line	737	return        r0     1
.label	l5
.line	737	gettable      r2    r0    k0 ; k0 = "uBubbleIDList"
.line	737	add           r3    r1    k2 ; k2 = 1
.line	737	gettable      r2    r2    r3
.line	737	gettabup      r3    u0    k3 ; k3 = "print"
.line	737	gettabup      r4    u0    k4 ; k4 = "bWriteLog"
.line	737	test          r4     0
.line	737	jmp            0   l45
.line	737	getupval      r4    u1
.line	737	loadk         r5    k5 ; k5 = 18
.line	737	loadk         r6    k6 ; k6 = 68
.line	737	loadk         r7    k7 ; k7 = 195
.line	737	loadk         r8    k8 ; k8 = 96
.line	737	loadk         r9    k9 ; k9 = 191
.line	737	loadk        r10   k10 ; k10 = 228
.line	737	loadk        r11   k11 ; k11 = 49
.line	737	loadk        r12   k12 ; k12 = 70
.line	737	loadk        r13   k13 ; k13 = 167
.line	737	loadk        r14   k14 ; k14 = 201
.line	737	loadk        r15   k15 ; k15 = 121
.line	737	loadk        r16   k16 ; k16 = 57
.line	737	loadk        r17   k17 ; k17 = 251
.line	737	loadk        r18   k18 ; k18 = 182
.line	737	loadk        r19   k19 ; k19 = 126
.line	737	loadk        r20   k20 ; k20 = 130
.line	737	loadk        r21   k21 ; k21 = 231
.line	737	loadk        r22   k22 ; k22 = 115
.line	737	loadk        r23   k23 ; k23 = 163
.line	737	loadk        r24   k24 ; k24 = 103
.line	737	loadk        r25   k25 ; k25 = 75
.line	737	loadk        r26   k26 ; k26 = 193
.line	737	loadk        r27   k27 ; k27 = 85
.line	737	loadk        r28   k24 ; k24 = 103
.line	737	loadk        r29   k28 ; k28 = 188
.line	737	loadk        r30   k29 ; k29 = 254
.line	737	loadk        r31   k30 ; k30 = 111
.line	737	loadk        r32   k31 ; k31 = 56
.line	737	loadk        r33   k32 ; k32 = 224
.line	737	loadk        r34   k33 ; k33 = 165
.line	737	loadk        r35   k34 ; k34 = 101
.line	737	call          r4    32     2
.label	l45
.line	737	move          r5    r1
.line	737	move          r6    r2
.line	737	call          r3     4     1
.line	737	test          r2     0
.line	737	jmp            0   l80
.line	737	gettabup      r3    u0   k35 ; k35 = "GameplaySysMgr"
.line	737	gettable      r3    r3   k36 ; k36 = "GetSysByName"
.line	737	getupval      r4    u1
.line	737	loadk         r5   k37 ; k37 = 10
.line	737	loadk         r6   k38 ; k38 = 66
.line	737	loadk         r7   k39 ; k39 = 198
.line	737	loadk         r8   k40 ; k40 = 98
.line	737	loadk         r9   k41 ; k41 = 186
.line	737	loadk        r10   k42 ; k42 = 197
.line	737	loadk        r11   k43 ; k43 = 11
.line	737	loadk        r12   k44 ; k44 = 67
.line	737	loadk        r13   k45 ; k45 = 183
.line	737	loadk        r14   k46 ; k46 = 206
.line	737	loadk        r15   k47 ; k47 = 102
.line	737	loadk        r16   k48 ; k48 = 47
.line	737	loadk        r17   k49 ; k49 = 215
.line	737	loadk        r18   k50 ; k50 = 180
.line	737	loadk        r19   k51 ; k51 = 127
.line	737	loadk        r20   k52 ; k52 = 204
.line	737	loadk        r21   k53 ; k53 = 214
.line	737	loadk        r22   k54 ; k54 = 82
.line	737	loadk        r23   k23 ; k23 = 163
.line	737	loadk        r24   k55 ; k55 = 64
.line	737	call          r4    21     2
.line	737	call          r3     2     2
.line	737	eq             1    r3    k1 ; k1 = nil
.line	737	jmp            0   l80
.line	737	self          r4    r3   k56 ; k56 = "ReqDoBubbleEmote"
.line	737	move          r6    r2
.line	737	call          r4     3     1
.label	l80
.line	737	self          r3    r0   k57 ; k57 = "ShowOrHideRing"
.line	737	loadbool      r5     0     0
.line	737	call          r3     3     1
.line	737	return        r0     1
.line	737	move          r0    r0
.line	737	move          r0    r0
.line	737	return        r0     1

.function	main/f27

.source	null
.linedefined	752
.lastlinedefined	816
.numparams	2
.is_vararg	0
.maxstacksize	57

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	15	true

.constant	k0	"IndexToPetExpression"
.constant	k1	nil
.constant	k2	1
.constant	k3	"slua_GameFrontendHUD"
.constant	k4	"GetPlayerController"
.constant	k5	"print"
.constant	k6	"bWriteLog"
.constant	k7	18
.constant	k8	68
.constant	k9	195
.constant	k10	96
.constant	k11	191
.constant	k12	228
.constant	k13	49
.constant	k14	70
.constant	k15	167
.constant	k16	201
.constant	k17	121
.constant	k18	57
.constant	k19	251
.constant	k20	182
.constant	k21	126
.constant	k22	130
.constant	k23	231
.constant	k24	115
.constant	k25	163
.constant	k26	103
.constant	k27	75
.constant	k28	193
.constant	k29	85
.constant	k30	188
.constant	k31	236
.constant	k32	127
.constant	k33	46
.constant	k34	199
.constant	k35	177
.constant	k36	112
.constant	k37	218
.constant	k38	198
.constant	k39	98
.constant	k40	185
.constant	k41	74
.constant	k42	91
.constant	k43	239
.constant	k44	9
.constant	k45	"tostring"
.constant	k46	111
.constant	k47	17
.constant	k48	"slua"
.constant	k49	"isValid"
.constant	k50	"pairs"
.constant	k51	"CurPetExpressionList"
.constant	k52	"ID"
.constant	k53	"IsLocked"
.constant	k54	"MasterSkillID"
.constant	k55	"table"
.constant	k56	"concat"
.constant	k57	95
.constant	k58	48
.constant	k59	125
.constant	k60	197
.constant	k61	196
.constant	k62	45
.constant	k63	23
.constant	k64	244
.constant	k65	140
.constant	k66	"BattleNormalTipsByTextID"
.constant	k67	48775
.constant	k68	"GetIsEmoteExist"
.constant	k69	252
.constant	k70	153
.constant	k71	77
.constant	k72	242
.constant	k73	82
.constant	k74	79
.constant	k75	217
.constant	k76	119
.constant	k77	13
.constant	k78	235
.constant	k79	173
.constant	k80	205
.constant	k81	215
.constant	k82	154
.constant	k83	64
.constant	k84	81
.constant	k85	102
.constant	k86	84
.constant	k87	189
.constant	k88	206
.constant	k89	39
.constant	k90	22
.constant	k91	187
.constant	k92	106
.constant	k93	247
.constant	k94	161
.constant	k95	203
.constant	k96	32
.constant	k97	19
.constant	k98	43005
.constant	k99	"ED_QuickExpressShowHide"
.constant	k100	"BroadCast"
.constant	k101	"EventSystem"
.constant	k102	"postEvent"
.constant	k103	"EVENTTYPE_INGAME"
.constant	k104	L"EVENTID_INGAME_SHOW_OR_HIDE_QUICK_EXPRESSION"
.constant	k105	"ShowOrHideRing"
.constant	k106	"IsInPetSpectator"
.constant	k107	"GetPetSpectatorComp"
.constant	k108	"PetSpectatorPawn"
.constant	k109	120
.constant	k110	83
.constant	k111	213
.constant	k112	26
.constant	k113	176
.constant	k114	207
.constant	k115	43
.constant	k116	230
.constant	k117	"import"
.constant	k118	6
.constant	k119	183
.constant	k120	40
.constant	k121	66
.constant	k122	186
.constant	k123	222
.constant	k124	90
.constant	k125	47
.constant	k126	138
.constant	k127	100
.constant	k128	151
.constant	k129	67
.constant	k130	118
.constant	k131	160
.constant	k132	"LocalHandleSpectatorPetStateMsg"
.constant	k133	"SpectatorPetMsgPlayEmoteMotage"
.constant	k134	"GetCurPawn"
.constant	k135	"PetComponent_BP"
.constant	k136	"PetPawn"
.constant	k137	97
.constant	k138	135
.constant	k139	"PetHasState"
.constant	k140	"PetParachute"
.constant	k141	"PetSwimming"
.constant	k142	"PetSleeping"
.constant	k143	"PetPlayingFeature"
.constant	k144	34
.constant	k145	69
.constant	k146	35
.constant	k147	210
.constant	k148	105
.constant	k149	80
.constant	k150	104
.constant	k151	246
.constant	k152	117
.constant	k153	214
.constant	k154	146
.constant	k155	49084
.constant	k156	0
.constant	k157	122
.constant	k158	168
.constant	k159	220
.constant	k160	99
.constant	k161	234
.constant	k162	87
.constant	k163	232
.constant	k164	78
.constant	k165	113
.constant	k166	38
.constant	k167	200
.constant	k168	37
.constant	k169	"GetSkillManager"
.constant	k170	"GetSkill"
.constant	k171	"IsCDOK"
.constant	k172	-1
.constant	k173	"GetCoolDownTime"
.constant	k174	"bUseNewSkillCD"
.constant	k175	"string"
.constant	k176	"format"
.constant	k177	93
.constant	k178	42
.constant	k179	86
.constant	k180	166
.constant	k181	129
.constant	k182	4
.constant	k183	216
.constant	k184	56
.constant	k185	178
.constant	k186	170
.constant	k187	123
.constant	k188	209
.constant	k189	223
.constant	k190	109
.constant	k191	224
.constant	k192	3
.constant	k193	89
.constant	k194	30
.constant	k195	174
.constant	k196	233
.constant	k197	110
.constant	k198	192
.constant	k199	73
.constant	k200	14
.constant	k201	7108
.constant	k202	"PlaySpecifiedPetAnimation"

.line	752	gettable      r2    r0    k0 ; k0 = "IndexToPetExpression"
.line	752	eq             0    r2    k1 ; k1 = nil
.line	752	jmp            0    l5
.line	752	return        r0     1
.label	l5
.line	752	gettable      r2    r0    k0 ; k0 = "IndexToPetExpression"
.line	752	add           r3    r1    k2 ; k2 = 1
.line	752	gettable      r2    r2    r3
.line	752	gettabup      r3    u0    k3 ; k3 = "slua_GameFrontendHUD"
.line	752	self          r3    r3    k4 ; k4 = "GetPlayerController"
.line	752	call          r3     2     2
.line	752	gettabup      r4    u0    k5 ; k5 = "print"
.line	752	gettabup      r5    u0    k6 ; k6 = "bWriteLog"
.line	752	test          r5     0
.line	752	jmp            0   l67
.line	752	getupval      r5    u1
.line	752	loadk         r6    k7 ; k7 = 18
.line	752	loadk         r7    k8 ; k8 = 68
.line	752	loadk         r8    k9 ; k9 = 195
.line	752	loadk         r9   k10 ; k10 = 96
.line	752	loadk        r10   k11 ; k11 = 191
.line	752	loadk        r11   k12 ; k12 = 228
.line	752	loadk        r12   k13 ; k13 = 49
.line	752	loadk        r13   k14 ; k14 = 70
.line	752	loadk        r14   k15 ; k15 = 167
.line	752	loadk        r15   k16 ; k16 = 201
.line	752	loadk        r16   k17 ; k17 = 121
.line	752	loadk        r17   k18 ; k18 = 57
.line	752	loadk        r18   k19 ; k19 = 251
.line	752	loadk        r19   k20 ; k20 = 182
.line	752	loadk        r20   k21 ; k21 = 126
.line	752	loadk        r21   k22 ; k22 = 130
.line	752	loadk        r22   k23 ; k23 = 231
.line	752	loadk        r23   k24 ; k24 = 115
.line	752	loadk        r24   k25 ; k25 = 163
.line	752	loadk        r25   k26 ; k26 = 103
.line	752	loadk        r26   k27 ; k27 = 75
.line	752	loadk        r27   k28 ; k28 = 193
.line	752	loadk        r28   k29 ; k29 = 85
.line	752	loadk        r29   k26 ; k26 = 103
.line	752	loadk        r30   k30 ; k30 = 188
.line	752	loadk        r31   k31 ; k31 = 236
.line	752	loadk        r32   k32 ; k32 = 127
.line	752	loadk        r33   k33 ; k33 = 46
.line	752	loadk        r34   k34 ; k34 = 199
.line	752	loadk        r35   k35 ; k35 = 177
.line	752	loadk        r36   k36 ; k36 = 112
.line	752	loadk        r37   k37 ; k37 = 218
.line	752	loadk        r38   k38 ; k38 = 198
.line	752	loadk        r39   k39 ; k39 = 98
.line	752	loadk        r40   k40 ; k40 = 185
.line	752	loadk        r41   k41 ; k41 = 74
.line	752	loadk        r42   k42 ; k42 = 91
.line	752	loadk        r43   k43 ; k43 = 239
.line	752	loadk        r44   k44 ; k44 = 9
.line	752	call          r5    40     2
.line	752	gettabup      r6    u0   k45 ; k45 = "tostring"
.line	752	move          r7    r1
.line	752	call          r6     2     2
.line	752	getupval      r7    u1
.line	752	loadk         r8   k46 ; k46 = 111
.line	752	loadk         r9   k47 ; k47 = 17
.line	752	call          r7     3     2
.line	752	gettabup      r8    u0   k45 ; k45 = "tostring"
.line	752	move          r9    r2
.line	752	call          r8     2     2
.line	752	concat        r5    r5    r8
.label	l67
.line	752	call          r4     2     1
.line	752	gettabup      r4    u0   k48 ; k48 = "slua"
.line	752	gettable      r4    r4   k49 ; k49 = "isValid"
.line	752	move          r5    r3
.line	752	call          r4     2     2
.line	752	test          r4     0
.line	752	jmp            0  l749
.line	752	test          r2     0
.line	752	jmp            0  l749
.line	752	loadbool      r4     1     0
.line	752	loadnil       r5     0
.line	752	gettabup      r6    u0   k50 ; k50 = "pairs"
.line	752	gettable      r7    r0   k51 ; k51 = "CurPetExpressionList"
.line	752	call          r6     2     4
.line	752	jmp            0   l88
.line	752	gettable     r11   r10   k52 ; k52 = "ID"
.line	752	eq             0   r11    r2
.line	752	jmp            0   l88
.line	752	gettable      r4   r10   k53 ; k53 = "IsLocked"
.line	752	gettable      r5   r10   k54 ; k54 = "MasterSkillID"
.line	752	jmp            0   l90
.label	l88
.line	752	move          r0    r0
.line	752	move          r0    r0
.label	l90
.line	752	test          r4     0
.line	752	jmp            0  l162
.line	752	gettabup      r6    u0    k5 ; k5 = "print"
.line	752	gettabup      r7    u0    k6 ; k6 = "bWriteLog"
.line	752	test          r7     0
.line	752	jmp            0  l157
.line	752	gettabup      r7    u0   k55 ; k55 = "table"
.line	752	gettable      r7    r7   k56 ; k56 = "concat"
.line	752	newtable      r8     1     0
.line	752	getupval      r9    u1
.line	752	loadk        r10    k7 ; k7 = 18
.line	752	loadk        r11    k8 ; k8 = 68
.line	752	loadk        r12    k9 ; k9 = 195
.line	752	loadk        r13   k10 ; k10 = 96
.line	752	loadk        r14   k11 ; k11 = 191
.line	752	loadk        r15   k12 ; k12 = 228
.line	752	loadk        r16   k13 ; k13 = 49
.line	752	loadk        r17   k14 ; k14 = 70
.line	752	loadk        r18   k15 ; k15 = 167
.line	752	loadk        r19   k16 ; k16 = 201
.line	752	loadk        r20   k17 ; k17 = 121
.line	752	loadk        r21   k18 ; k18 = 57
.line	752	loadk        r22   k19 ; k19 = 251
.line	752	loadk        r23   k20 ; k20 = 182
.line	752	loadk        r24   k21 ; k21 = 126
.line	752	loadk        r25   k22 ; k22 = 130
.line	752	loadk        r26   k23 ; k23 = 231
.line	752	loadk        r27   k24 ; k24 = 115
.line	752	loadk        r28   k25 ; k25 = 163
.line	752	loadk        r29   k26 ; k26 = 103
.line	752	loadk        r30   k27 ; k27 = 75
.line	752	loadk        r31   k28 ; k28 = 193
.line	752	loadk        r32   k29 ; k29 = 85
.line	752	loadk        r33   k26 ; k26 = 103
.line	752	loadk        r34   k30 ; k30 = 188
.line	752	loadk        r35   k31 ; k31 = 236
.line	752	loadk        r36   k32 ; k32 = 127
.line	752	loadk        r37   k33 ; k33 = 46
.line	752	loadk        r38   k34 ; k34 = 199
.line	752	loadk        r39   k35 ; k35 = 177
.line	752	loadk        r40   k36 ; k36 = 112
.line	752	loadk        r41   k37 ; k37 = 218
.line	752	loadk        r42   k38 ; k38 = 198
.line	752	loadk        r43   k39 ; k39 = 98
.line	752	loadk        r44   k40 ; k40 = 185
.line	752	loadk        r45   k41 ; k41 = 74
.line	752	loadk        r46   k42 ; k42 = 91
.line	752	loadk        r47   k43 ; k43 = 239
.line	752	loadk        r48   k44 ; k44 = 9
.line	752	loadk        r49   k57 ; k57 = 95
.line	752	call          r9    41     2
.line	752	getupval     r10    u1
.line	752	loadk        r11   k58 ; k58 = 48
.line	752	loadk        r12   k59 ; k59 = 125
.line	752	loadk        r13   k60 ; k60 = 197
.line	752	loadk        r14   k10 ; k10 = 96
.line	752	loadk        r15   k11 ; k11 = 191
.line	752	loadk        r16   k61 ; k61 = 196
.line	752	loadk        r17   k62 ; k62 = 45
.line	752	loadk        r18   k63 ; k63 = 23
.line	752	loadk        r19   k64 ; k64 = 244
.line	752	loadk        r20   k65 ; k65 = 140
.line	752	call         r10    11     0
.line	752	setlist       r8     0     1
.line	752	call          r7     2     2
.line	752	move          r8    r2
.line	752	concat        r7    r7    r8
.label	l157
.line	752	call          r6     2     1
.line	752	gettabup      r6    u2   k66 ; k66 = "BattleNormalTipsByTe" (truncated)
.line	752	loadk         r7   k67 ; k67 = 48775
.line	752	call          r6     2     1
.line	752	return        r0     1
.label	l162
.line	752	self          r6    r0   k68 ; k68 = "GetIsEmoteExist"
.line	752	move          r8    r2
.line	752	call          r6     3     2
.line	752	test          r6     1
.line	752	jmp            0  l260
.line	752	gettabup      r6    u0    k5 ; k5 = "print"
.line	752	gettabup      r7    u0    k6 ; k6 = "bWriteLog"
.line	752	test          r7     0
.line	752	jmp            0  l242
.line	752	gettabup      r7    u0   k55 ; k55 = "table"
.line	752	gettable      r7    r7   k56 ; k56 = "concat"
.line	752	newtable      r8     1     0
.line	752	getupval      r9    u1
.line	752	loadk        r10    k7 ; k7 = 18
.line	752	loadk        r11    k8 ; k8 = 68
.line	752	loadk        r12    k9 ; k9 = 195
.line	752	loadk        r13   k10 ; k10 = 96
.line	752	loadk        r14   k11 ; k11 = 191
.line	752	loadk        r15   k12 ; k12 = 228
.line	752	loadk        r16   k13 ; k13 = 49
.line	752	loadk        r17   k14 ; k14 = 70
.line	752	loadk        r18   k15 ; k15 = 167
.line	752	loadk        r19   k16 ; k16 = 201
.line	752	loadk        r20   k17 ; k17 = 121
.line	752	loadk        r21   k18 ; k18 = 57
.line	752	loadk        r22   k19 ; k19 = 251
.line	752	loadk        r23   k20 ; k20 = 182
.line	752	loadk        r24   k21 ; k21 = 126
.line	752	loadk        r25   k22 ; k22 = 130
.line	752	loadk        r26   k69 ; k69 = 252
.line	752	loadk        r27   k46 ; k46 = 111
.line	752	loadk        r28   k70 ; k70 = 153
.line	752	loadk        r29   k57 ; k57 = 95
.line	752	loadk        r30   k71 ; k71 = 77
.line	752	loadk        r31   k72 ; k72 = 242
.line	752	loadk        r32   k73 ; k73 = 82
.line	752	loadk        r33   k74 ; k74 = 79
.line	752	loadk        r34   k35 ; k35 = 177
.line	752	loadk        r35   k75 ; k75 = 217
.line	752	loadk        r36   k76 ; k76 = 119
.line	752	loadk        r37   k77 ; k77 = 13
.line	752	loadk        r38   k78 ; k78 = 235
.line	752	loadk        r39   k79 ; k79 = 173
.line	752	loadk        r40   k26 ; k26 = 103
.line	752	loadk        r41   k80 ; k80 = 205
.line	752	loadk        r42   k81 ; k81 = 215
.line	752	loadk        r43   k13 ; k13 = 49
.line	752	loadk        r44   k82 ; k82 = 154
.line	752	loadk        r45   k14 ; k14 = 70
.line	752	loadk        r46   k83 ; k83 = 64
.line	752	loadk        r47   k61 ; k61 = 196
.line	752	loadk        r48   k84 ; k84 = 81
.line	752	loadk        r49   k85 ; k85 = 102
.line	752	call          r9    41     2
.line	752	getupval     r10    u1
.line	752	loadk        r11   k13 ; k13 = 49
.line	752	loadk        r12   k86 ; k86 = 84
.line	752	loadk        r13   k75 ; k75 = 217
.line	752	loadk        r14   k36 ; k36 = 112
.line	752	loadk        r15   k87 ; k87 = 189
.line	752	loadk        r16   k88 ; k88 = 206
.line	752	loadk        r17   k89 ; k89 = 39
.line	752	loadk        r18   k90 ; k90 = 22
.line	752	loadk        r19   k91 ; k91 = 187
.line	752	loadk        r20    k9 ; k9 = 195
.line	752	loadk        r21   k21 ; k21 = 126
.line	752	loadk        r22   k92 ; k92 = 106
.line	752	loadk        r23   k93 ; k93 = 247
.line	752	loadk        r24   k94 ; k94 = 161
.line	752	loadk        r25   k17 ; k17 = 121
.line	752	loadk        r26   k95 ; k95 = 203
.line	752	loadk        r27   k34 ; k34 = 199
.line	752	loadk        r28   k96 ; k96 = 32
.line	752	loadk        r29   k19 ; k19 = 251
.line	752	loadk        r30   k97 ; k97 = 19
.line	752	call         r10    21     0
.line	752	setlist       r8     0     1
.line	752	call          r7     2     2
.line	752	move          r8    r2
.line	752	concat        r7    r7    r8
.label	l242
.line	752	call          r6     2     1
.line	752	gettabup      r6    u2   k66 ; k66 = "BattleNormalTipsByTe" (truncated)
.line	752	loadk         r7   k98 ; k98 = 43005
.line	752	call          r6     2     1
.line	752	gettable      r6    r0   k99 ; k99 = "ED_QuickExpressShowH" (truncated)
.line	752	self          r6    r6  k100 ; k100 = "BroadCast"
.line	752	loadbool      r8     0     0
.line	752	call          r6     3     1
.line	752	gettabup      r6    u0  k101 ; k101 = "EventSystem"
.line	752	self          r6    r6  k102 ; k102 = "postEvent"
.line	752	gettabup      r8    u0  k103 ; k103 = "EVENTTYPE_INGAME"
.line	752	gettabup      r9    u0  k104 ; k104 = L"EVENTID_INGAME_SHOW_" (truncated)
.line	752	loadbool     r10     0     0
.line	752	call          r6     5     1
.line	752	self          r6    r0  k105 ; k105 = "ShowOrHideRing"
.line	752	loadbool      r8     0     0
.line	752	call          r6     3     1
.line	752	return        r0     1
.label	l260
.line	752	gettable      r6    r3  k106 ; k106 = "IsInPetSpectator"
.line	752	test          r6     0
.line	752	jmp            0  l384
.line	752	self          r6    r3  k106 ; k106 = "IsInPetSpectator"
.line	752	call          r6     2     2
.line	752	test          r6     0
.line	752	jmp            0  l384
.line	752	self          r6    r3  k107 ; k107 = "GetPetSpectatorComp"
.line	752	call          r6     2     2
.line	752	test          r6     0
.line	752	jmp            0  l384
.line	752	self          r6    r3  k107 ; k107 = "GetPetSpectatorComp"
.line	752	call          r6     2     2
.line	752	gettable      r6    r6  k108 ; k108 = "PetSpectatorPawn"
.line	752	test          r6     0
.line	752	jmp            0  l384
.line	752	gettabup      r6    u0    k5 ; k5 = "print"
.line	752	gettabup      r7    u0    k6 ; k6 = "bWriteLog"
.line	752	test          r7     0
.line	752	jmp            0  l346
.line	752	gettabup      r7    u0   k55 ; k55 = "table"
.line	752	gettable      r7    r7   k56 ; k56 = "concat"
.line	752	newtable      r8     1     0
.line	752	getupval      r9    u1
.line	752	loadk        r10    k7 ; k7 = 18
.line	752	loadk        r11    k8 ; k8 = 68
.line	752	loadk        r12    k9 ; k9 = 195
.line	752	loadk        r13   k10 ; k10 = 96
.line	752	loadk        r14   k11 ; k11 = 191
.line	752	loadk        r15   k12 ; k12 = 228
.line	752	loadk        r16   k13 ; k13 = 49
.line	752	loadk        r17   k14 ; k14 = 70
.line	752	loadk        r18   k15 ; k15 = 167
.line	752	loadk        r19   k16 ; k16 = 201
.line	752	loadk        r20   k17 ; k17 = 121
.line	752	loadk        r21   k18 ; k18 = 57
.line	752	loadk        r22   k19 ; k19 = 251
.line	752	loadk        r23   k20 ; k20 = 182
.line	752	loadk        r24   k21 ; k21 = 126
.line	752	loadk        r25   k22 ; k22 = 130
.line	752	loadk        r26   k23 ; k23 = 231
.line	752	loadk        r27   k24 ; k24 = 115
.line	752	loadk        r28   k25 ; k25 = 163
.line	752	loadk        r29   k26 ; k26 = 103
.line	752	loadk        r30   k27 ; k27 = 75
.line	752	loadk        r31   k28 ; k28 = 193
.line	752	loadk        r32   k29 ; k29 = 85
.line	752	loadk        r33   k26 ; k26 = 103
.line	752	loadk        r34   k30 ; k30 = 188
.line	752	loadk        r35   k31 ; k31 = 236
.line	752	loadk        r36   k32 ; k32 = 127
.line	752	loadk        r37   k33 ; k33 = 46
.line	752	loadk        r38   k34 ; k34 = 199
.line	752	loadk        r39   k35 ; k35 = 177
.line	752	loadk        r40   k36 ; k36 = 112
.line	752	loadk        r41   k37 ; k37 = 218
.line	752	loadk        r42   k38 ; k38 = 198
.line	752	loadk        r43   k39 ; k39 = 98
.line	752	loadk        r44   k40 ; k40 = 185
.line	752	loadk        r45   k41 ; k41 = 74
.line	752	loadk        r46   k42 ; k42 = 91
.line	752	loadk        r47   k43 ; k43 = 239
.line	752	loadk        r48   k44 ; k44 = 9
.line	752	loadk        r49   k57 ; k57 = 95
.line	752	call          r9    41     2
.line	752	getupval     r10    u1
.line	752	loadk        r11   k58 ; k58 = 48
.line	752	loadk        r12  k109 ; k109 = 120
.line	752	loadk        r13   k61 ; k61 = 196
.line	752	loadk        r14  k110 ; k110 = 83
.line	752	loadk        r15   k35 ; k35 = 177
.line	752	loadk        r16  k111 ; k111 = 213
.line	752	loadk        r17  k112 ; k112 = 26
.line	752	loadk        r18   k14 ; k14 = 70
.line	752	loadk        r19  k113 ; k113 = 176
.line	752	loadk        r20  k114 ; k114 = 207
.line	752	loadk        r21   k21 ; k21 = 126
.line	752	loadk        r22  k115 ; k115 = 43
.line	752	loadk        r23  k116 ; k116 = 230
.line	752	loadk        r24   k20 ; k20 = 182
.line	752	loadk        r25   k39 ; k39 = 98
.line	752	call         r10    16     0
.line	752	setlist       r8     0     1
.line	752	call          r7     2     2
.line	752	move          r8    r2
.line	752	concat        r7    r7    r8
.label	l346
.line	752	call          r6     2     1
.line	752	gettabup      r6    u0  k117 ; k117 = "import"
.line	752	getupval      r7    u1
.line	752	loadk         r8  k118 ; k118 = 6
.line	752	loadk         r9   k39 ; k39 = 98
.line	752	loadk        r10   k37 ; k37 = 218
.line	752	loadk        r11   k85 ; k85 = 102
.line	752	loadk        r12  k119 ; k119 = 183
.line	752	loadk        r13  k111 ; k111 = 213
.line	752	loadk        r14  k120 ; k120 = 40
.line	752	loadk        r15  k121 ; k121 = 66
.line	752	loadk        r16  k122 ; k122 = 186
.line	752	loadk        r17  k123 ; k123 = 222
.line	752	loadk        r18  k124 ; k124 = 90
.line	752	loadk        r19  k125 ; k125 = 47
.line	752	loadk        r20  k116 ; k116 = 230
.line	752	loadk        r21  k126 ; k126 = 138
.line	752	loadk        r22  k127 ; k127 = 100
.line	752	loadk        r23   k75 ; k75 = 217
.line	752	loadk        r24   k34 ; k34 = 199
.line	752	loadk        r25  k127 ; k127 = 100
.line	752	loadk        r26  k128 ; k128 = 151
.line	752	loadk        r27   k83 ; k83 = 64
.line	752	loadk        r28  k129 ; k129 = 67
.line	752	loadk        r29   k60 ; k60 = 197
.line	752	loadk        r30   k83 ; k83 = 64
.line	752	loadk        r31  k130 ; k130 = 118
.line	752	loadk        r32  k131 ; k131 = 160
.line	752	call          r7    26     2
.line	752	call          r6     2     2
.line	752	self          r7    r3  k107 ; k107 = "GetPetSpectatorComp"
.line	752	call          r7     2     2
.line	752	gettable      r7    r7  k108 ; k108 = "PetSpectatorPawn"
.line	752	self          r7    r7  k132 ; k132 = "LocalHandleSpectator" (truncated)
.line	752	gettable      r9    r6  k133 ; k133 = "SpectatorPetMsgPlayE" (truncated)
.line	752	move         r10    r2
.line	752	call          r7     4     1
.line	752	jmp            0  l746
.label	l384
.line	752	self          r6    r3  k134 ; k134 = "GetCurPawn"
.line	752	call          r6     2     2
.line	752	gettabup      r7    u0   k48 ; k48 = "slua"
.line	752	gettable      r7    r7   k49 ; k49 = "isValid"
.line	752	move          r8    r6
.line	752	call          r7     2     2
.line	752	test          r7     0
.line	752	jmp            0  l521
.line	752	gettabup      r7    u0   k48 ; k48 = "slua"
.line	752	gettable      r7    r7   k49 ; k49 = "isValid"
.line	752	gettable      r8    r6  k135 ; k135 = "PetComponent_BP"
.line	752	call          r7     2     2
.line	752	test          r7     0
.line	752	jmp            0  l521
.line	752	gettabup      r7    u0   k48 ; k48 = "slua"
.line	752	gettable      r7    r7   k49 ; k49 = "isValid"
.line	752	gettable      r8    r6  k135 ; k135 = "PetComponent_BP"
.line	752	gettable      r8    r8  k136 ; k136 = "PetPawn"
.line	752	call          r7     2     2
.line	752	test          r7     0
.line	752	jmp            0  l521
.line	752	gettabup      r7    u0  k117 ; k117 = "import"
.line	752	getupval      r8    u1
.line	752	loadk         r9  k118 ; k118 = 6
.line	752	loadk        r10  k137 ; k137 = 97
.line	752	loadk        r11  k114 ; k114 = 207
.line	752	loadk        r12   k76 ; k76 = 119
.line	752	loadk        r13  k138 ; k138 = 135
.line	752	loadk        r14  k111 ; k111 = 213
.line	752	loadk        r15  k120 ; k120 = 40
.line	752	loadk        r16  k121 ; k121 = 66
.line	752	loadk        r17  k113 ; k113 = 176
.line	752	call          r8    10     2
.line	752	call          r7     2     2
.line	752	gettable      r8    r6  k135 ; k135 = "PetComponent_BP"
.line	752	gettable      r8    r8  k136 ; k136 = "PetPawn"
.line	752	self          r8    r8  k139 ; k139 = "PetHasState"
.line	752	gettable     r10    r7  k140 ; k140 = "PetParachute"
.line	752	call          r8     3     2
.line	752	test          r8     1
.line	752	jmp            0  l446
.line	752	gettable      r8    r6  k135 ; k135 = "PetComponent_BP"
.line	752	gettable      r8    r8  k136 ; k136 = "PetPawn"
.line	752	self          r8    r8  k139 ; k139 = "PetHasState"
.line	752	gettable     r10    r7  k141 ; k141 = "PetSwimming"
.line	752	call          r8     3     2
.line	752	test          r8     1
.line	752	jmp            0  l446
.line	752	gettable      r8    r6  k135 ; k135 = "PetComponent_BP"
.line	752	gettable      r8    r8  k136 ; k136 = "PetPawn"
.line	752	self          r8    r8  k139 ; k139 = "PetHasState"
.line	752	gettable     r10    r7  k142 ; k142 = "PetSleeping"
.line	752	call          r8     3     2
.line	752	test          r8     1
.line	752	jmp            0  l446
.line	752	gettable      r8    r6  k135 ; k135 = "PetComponent_BP"
.line	752	gettable      r8    r8  k136 ; k136 = "PetPawn"
.line	752	self          r8    r8  k139 ; k139 = "PetHasState"
.line	752	gettable     r10    r7  k143 ; k143 = "PetPlayingFeature"
.line	752	call          r8     3     2
.line	752	test          r8     0
.line	752	jmp            0  l521
.label	l446
.line	752	gettabup      r8    u0    k5 ; k5 = "print"
.line	752	gettabup      r9    u0    k6 ; k6 = "bWriteLog"
.line	752	test          r9     0
.line	752	jmp            0  l516
.line	752	gettabup      r9    u0   k55 ; k55 = "table"
.line	752	gettable      r9    r9   k56 ; k56 = "concat"
.line	752	newtable     r10     1     0
.line	752	getupval     r11    u1
.line	752	loadk        r12    k7 ; k7 = 18
.line	752	loadk        r13    k8 ; k8 = 68
.line	752	loadk        r14    k9 ; k9 = 195
.line	752	loadk        r15   k10 ; k10 = 96
.line	752	loadk        r16   k11 ; k11 = 191
.line	752	loadk        r17   k12 ; k12 = 228
.line	752	loadk        r18   k13 ; k13 = 49
.line	752	loadk        r19   k14 ; k14 = 70
.line	752	loadk        r20   k15 ; k15 = 167
.line	752	loadk        r21   k16 ; k16 = 201
.line	752	loadk        r22   k17 ; k17 = 121
.line	752	loadk        r23   k18 ; k18 = 57
.line	752	loadk        r24   k19 ; k19 = 251
.line	752	loadk        r25   k20 ; k20 = 182
.line	752	loadk        r26   k21 ; k21 = 126
.line	752	loadk        r27   k22 ; k22 = 130
.line	752	loadk        r28   k69 ; k69 = 252
.line	752	loadk        r29   k46 ; k46 = 111
.line	752	loadk        r30   k70 ; k70 = 153
.line	752	loadk        r31   k57 ; k57 = 95
.line	752	loadk        r32   k71 ; k71 = 77
.line	752	loadk        r33   k72 ; k72 = 242
.line	752	loadk        r34   k73 ; k73 = 82
.line	752	loadk        r35   k74 ; k74 = 79
.line	752	loadk        r36   k35 ; k35 = 177
.line	752	loadk        r37   k75 ; k75 = 217
.line	752	loadk        r38   k76 ; k76 = 119
.line	752	loadk        r39   k77 ; k77 = 13
.line	752	loadk        r40   k78 ; k78 = 235
.line	752	loadk        r41   k79 ; k79 = 173
.line	752	loadk        r42   k26 ; k26 = 103
.line	752	loadk        r43   k80 ; k80 = 205
.line	752	loadk        r44   k81 ; k81 = 215
.line	752	loadk        r45   k13 ; k13 = 49
.line	752	loadk        r46  k122 ; k122 = 186
.line	752	loadk        r47   k14 ; k14 = 70
.line	752	loadk        r48   k83 ; k83 = 64
.line	752	loadk        r49   k94 ; k94 = 161
.line	752	loadk        r50  k124 ; k124 = 90
.line	752	loadk        r51   k39 ; k39 = 98
.line	752	call         r11    41     2
.line	752	getupval     r12    u1
.line	752	loadk        r13  k144 ; k144 = 34
.line	752	loadk        r14  k145 ; k145 = 69
.line	752	loadk        r15  k114 ; k114 = 207
.line	752	loadk        r16  k146 ; k146 = 35
.line	752	loadk        r17   k87 ; k87 = 189
.line	752	loadk        r18  k147 ; k147 = 210
.line	752	loadk        r19  k148 ; k148 = 105
.line	752	loadk        r20  k149 ; k149 = 80
.line	752	loadk        r21  k122 ; k122 = 186
.line	752	loadk        r22  k123 ; k123 = 222
.line	752	loadk        r23  k150 ; k150 = 104
.line	752	loadk        r24  k146 ; k146 = 35
.line	752	loadk        r25  k151 ; k151 = 246
.line	752	loadk        r26   k87 ; k87 = 189
.line	752	loadk        r27  k152 ; k152 = 117
.line	752	loadk        r28  k153 ; k153 = 214
.line	752	loadk        r29  k154 ; k154 = 146
.line	752	call         r12    18     0
.line	752	setlist      r10     0     1
.line	752	call          r9     2     2
.label	l516
.line	752	call          r8     2     1
.line	752	gettabup      r8    u2   k66 ; k66 = "BattleNormalTipsByTe" (truncated)
.line	752	loadk         r9  k155 ; k155 = 49084
.line	752	call          r8     2     1
.line	752	return        r0     1
.label	l521
.line	752	eq             1    r5    k1 ; k1 = nil
.line	752	jmp            0  l743
.line	752	lt             0  k156    r5 ; k156 = 0
.line	752	jmp            0  l743
.line	752	gettabup      r7    u0    k5 ; k5 = "print"
.line	752	gettabup      r8    u0    k6 ; k6 = "bWriteLog"
.line	752	test          r8     0
.line	752	jmp            0  l586
.line	752	gettabup      r8    u0   k55 ; k55 = "table"
.line	752	gettable      r8    r8   k56 ; k56 = "concat"
.line	752	newtable      r9     1     0
.line	752	getupval     r10    u1
.line	752	loadk        r11    k7 ; k7 = 18
.line	752	loadk        r12    k8 ; k8 = 68
.line	752	loadk        r13    k9 ; k9 = 195
.line	752	loadk        r14   k10 ; k10 = 96
.line	752	loadk        r15   k11 ; k11 = 191
.line	752	loadk        r16   k12 ; k12 = 228
.line	752	loadk        r17   k13 ; k13 = 49
.line	752	loadk        r18   k14 ; k14 = 70
.line	752	loadk        r19   k15 ; k15 = 167
.line	752	loadk        r20   k16 ; k16 = 201
.line	752	loadk        r21   k17 ; k17 = 121
.line	752	loadk        r22   k18 ; k18 = 57
.line	752	loadk        r23   k19 ; k19 = 251
.line	752	loadk        r24   k20 ; k20 = 182
.line	752	loadk        r25   k21 ; k21 = 126
.line	752	loadk        r26   k22 ; k22 = 130
.line	752	loadk        r27   k69 ; k69 = 252
.line	752	loadk        r28   k46 ; k46 = 111
.line	752	loadk        r29   k70 ; k70 = 153
.line	752	loadk        r30   k57 ; k57 = 95
.line	752	loadk        r31   k71 ; k71 = 77
.line	752	loadk        r32   k72 ; k72 = 242
.line	752	loadk        r33   k73 ; k73 = 82
.line	752	loadk        r34   k74 ; k74 = 79
.line	752	loadk        r35   k35 ; k35 = 177
.line	752	loadk        r36   k75 ; k75 = 217
.line	752	loadk        r37   k76 ; k76 = 119
.line	752	loadk        r38  k157 ; k157 = 122
.line	752	loadk        r39  k114 ; k114 = 207
.line	752	loadk        r40  k158 ; k158 = 168
.line	752	loadk        r41   k24 ; k24 = 115
.line	752	loadk        r42  k159 ; k159 = 220
.line	752	loadk        r43   k38 ; k38 = 198
.line	752	loadk        r44  k160 ; k160 = 99
.line	752	loadk        r45  k161 ; k161 = 234
.line	752	loadk        r46  k162 ; k162 = 87
.line	752	loadk        r47   k14 ; k14 = 70
.line	752	loadk        r48  k163 ; k163 = 232
.line	752	loadk        r49  k164 ; k164 = 78
.line	752	loadk        r50  k165 ; k165 = 113
.line	752	call         r10    41     2
.line	752	getupval     r11    u1
.line	752	loadk        r12  k166 ; k166 = 38
.line	752	loadk        r13  k129 ; k129 = 67
.line	752	loadk        r14  k126 ; k126 = 138
.line	752	loadk        r15   k36 ; k36 = 112
.line	752	loadk        r16   k11 ; k11 = 191
.line	752	loadk        r17  k167 ; k167 = 200
.line	752	loadk        r18  k168 ; k168 = 37
.line	752	loadk        r19  k124 ; k124 = 90
.line	752	call         r11     9     0
.line	752	setlist       r9     0     1
.line	752	call          r8     2     2
.label	l586
.line	752	move          r9    r5
.line	752	call          r7     3     1
.line	752	gettabup      r7    u0   k48 ; k48 = "slua"
.line	752	gettable      r7    r7   k49 ; k49 = "isValid"
.line	752	move          r8    r6
.line	752	call          r7     2     2
.line	752	test          r7     0
.line	752	jmp            0  l743
.line	752	self          r7    r6  k169 ; k169 = "GetSkillManager"
.line	752	call          r7     2     2
.line	752	gettabup      r8    u0   k48 ; k48 = "slua"
.line	752	gettable      r8    r8   k49 ; k49 = "isValid"
.line	752	move          r9    r7
.line	752	call          r8     2     2
.line	752	test          r8     0
.line	752	jmp            0  l743
.line	752	self          r8    r7  k170 ; k170 = "GetSkill"
.line	752	move         r10    r5
.line	752	call          r8     3     2
.line	752	test          r8     0
.line	752	jmp            0  l743
.line	752	self          r9    r8  k171 ; k171 = "IsCDOK"
.line	752	move         r11    r7
.line	752	loadk        r12  k172 ; k172 = -1
.line	752	call          r9     4     2
.line	752	test          r9     1
.line	752	jmp            0  l743
.line	752	self          r9    r8  k173 ; k173 = "GetCoolDownTime"
.line	752	move         r11    r7
.line	752	loadk        r12  k156 ; k156 = 0
.line	752	call          r9     4     2
.line	752	gettable     r10    r8  k174 ; k174 = "bUseNewSkillCD"
.line	752	gettabup     r11    u0    k5 ; k5 = "print"
.line	752	gettabup     r12    u0    k6 ; k6 = "bWriteLog"
.line	752	test         r12     0
.line	752	jmp            0  l738
.line	752	gettabup     r12    u0  k175 ; k175 = "string"
.line	752	gettable     r12   r12  k176 ; k176 = "format"
.line	752	gettabup     r13    u0   k55 ; k55 = "table"
.line	752	gettable     r13   r13   k56 ; k56 = "concat"
.line	752	newtable     r14     2     0
.line	752	getupval     r15    u1
.line	752	loadk        r16    k7 ; k7 = 18
.line	752	loadk        r17    k8 ; k8 = 68
.line	752	loadk        r18    k9 ; k9 = 195
.line	752	loadk        r19   k10 ; k10 = 96
.line	752	loadk        r20   k11 ; k11 = 191
.line	752	loadk        r21   k12 ; k12 = 228
.line	752	loadk        r22   k13 ; k13 = 49
.line	752	loadk        r23   k14 ; k14 = 70
.line	752	loadk        r24   k15 ; k15 = 167
.line	752	loadk        r25   k16 ; k16 = 201
.line	752	loadk        r26   k17 ; k17 = 121
.line	752	loadk        r27   k18 ; k18 = 57
.line	752	loadk        r28   k19 ; k19 = 251
.line	752	loadk        r29   k20 ; k20 = 182
.line	752	loadk        r30   k21 ; k21 = 126
.line	752	loadk        r31   k22 ; k22 = 130
.line	752	loadk        r32   k69 ; k69 = 252
.line	752	loadk        r33   k46 ; k46 = 111
.line	752	loadk        r34   k70 ; k70 = 153
.line	752	loadk        r35   k57 ; k57 = 95
.line	752	loadk        r36   k71 ; k71 = 77
.line	752	loadk        r37   k72 ; k72 = 242
.line	752	loadk        r38   k73 ; k73 = 82
.line	752	loadk        r39   k74 ; k74 = 79
.line	752	loadk        r40   k35 ; k35 = 177
.line	752	loadk        r41   k75 ; k75 = 217
.line	752	loadk        r42   k76 ; k76 = 119
.line	752	loadk        r43  k157 ; k157 = 122
.line	752	loadk        r44   k12 ; k12 = 228
.line	752	loadk        r45  k158 ; k158 = 168
.line	752	loadk        r46  k148 ; k148 = 105
.line	752	loadk        r47   k61 ; k61 = 196
.line	752	loadk        r48   k38 ; k38 = 198
.line	752	loadk        r49  k152 ; k152 = 117
.line	752	loadk        r50  k161 ; k161 = 234
.line	752	loadk        r51  k162 ; k162 = 87
.line	752	loadk        r52   k42 ; k42 = 91
.line	752	loadk        r53   k94 ; k94 = 161
.line	752	loadk        r54  k177 ; k177 = 93
.line	752	loadk        r55  k127 ; k127 = 100
.line	752	call         r15    41     2
.line	752	getupval     r16    u1
.line	752	loadk        r17  k178 ; k178 = 42
.line	752	loadk        r18  k179 ; k179 = 86
.line	752	loadk        r19   k80 ; k80 = 205
.line	752	loadk        r20   k85 ; k85 = 102
.line	752	loadk        r21  k180 ; k180 = 166
.line	752	loadk        r22  k181 ; k181 = 129
.line	752	loadk        r23  k182 ; k182 = 4
.line	752	loadk        r24  k162 ; k162 = 87
.line	752	loadk        r25  k180 ; k180 = 166
.line	752	loadk        r26  k183 ; k183 = 216
.line	752	loadk        r27   k46 ; k46 = 111
.line	752	loadk        r28  k184 ; k184 = 56
.line	752	loadk        r29  k185 ; k185 = 178
.line	752	loadk        r30  k186 ; k186 = 170
.line	752	loadk        r31  k187 ; k187 = 123
.line	752	loadk        r32  k188 ; k188 = 209
.line	752	loadk        r33  k189 ; k189 = 223
.line	752	loadk        r34  k190 ; k190 = 109
.line	752	loadk        r35  k191 ; k191 = 224
.line	752	loadk        r36   k90 ; k90 = 22
.line	752	loadk        r37   k83 ; k83 = 64
.line	752	loadk        r38   k35 ; k35 = 177
.line	752	loadk        r39  k192 ; k192 = 3
.line	752	loadk        r40  k166 ; k166 = 38
.line	752	loadk        r41   k65 ; k65 = 140
.line	752	loadk        r42  k147 ; k147 = 210
.line	752	loadk        r43  k193 ; k193 = 89
.line	752	loadk        r44  k194 ; k194 = 30
.line	752	loadk        r45  k195 ; k195 = 174
.line	752	loadk        r46  k196 ; k196 = 233
.line	752	loadk        r47  k197 ; k197 = 110
.line	752	loadk        r48   k78 ; k78 = 235
.line	752	loadk        r49   k23 ; k23 = 231
.line	752	loadk        r50  k115 ; k115 = 43
.line	752	loadk        r51   k43 ; k43 = 239
.line	752	loadk        r52  k149 ; k149 = 80
.line	752	loadk        r53  k112 ; k112 = 26
.line	752	loadk        r54   k94 ; k94 = 161
.line	752	loadk        r55   k27 ; k27 = 75
.line	752	loadk        r56  k129 ; k129 = 67
.line	752	call         r16    41     2
.line	752	getupval     r17    u1
.line	752	loadk        r18   k58 ; k58 = 48
.line	752	loadk        r19   k86 ; k86 = 84
.line	752	loadk        r20   k12 ; k12 = 228
.line	752	loadk        r21   k85 ; k85 = 102
.line	752	loadk        r22   k25 ; k25 = 163
.line	752	loadk        r23   k72 ; k72 = 242
.line	752	loadk        r24  k144 ; k144 = 34
.line	752	loadk        r25   k57 ; k57 = 95
.line	752	loadk        r26   k40 ; k40 = 185
.line	752	loadk        r27  k198 ; k198 = 192
.line	752	loadk        r28  k199 ; k199 = 73
.line	752	loadk        r29  k200 ; k200 = 14
.line	752	loadk        r30  k158 ; k158 = 168
.line	752	loadk        r31   k69 ; k69 = 252
.line	752	loadk        r32  k160 ; k160 = 99
.line	752	call         r17    16     0
.line	752	setlist      r14     0     1
.line	752	call         r13     2     2
.line	752	move         r14    r5
.line	752	gettabup     r15    u0   k45 ; k45 = "tostring"
.line	752	move         r16    r9
.line	752	call         r15     2     2
.line	752	gettabup     r16    u0   k45 ; k45 = "tostring"
.line	752	move         r17   r10
.line	752	call         r16     2     0
.line	752	call         r12     0     2
.label	l738
.line	752	call         r11     2     1
.line	752	gettabup     r11    u2   k66 ; k66 = "BattleNormalTipsByTe" (truncated)
.line	752	loadk        r12  k201 ; k201 = 7108
.line	752	call         r11     2     1
.line	752	return        r0     1
.label	l743
.line	752	self          r7    r3  k202 ; k202 = "PlaySpecifiedPetAnim" (truncated)
.line	752	move          r9    r2
.line	752	call          r7     3     1
.label	l746
.line	752	self          r6    r0  k105 ; k105 = "ShowOrHideRing"
.line	752	loadbool      r8     0     0
.line	752	call          r6     3     1
.label	l749
.line	752	return        r0     1
.line	752	move          r0    r0
.line	752	move          r0    r0
.line	752	gettabup      r0    u1  k195 ; k195 = 174
.line	752	move          r0    r0
.line	752	return        r0     1

.function	main/f28

.source	null
.linedefined	818
.lastlinedefined	876
.numparams	2
.is_vararg	0
.maxstacksize	58

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	15	true
.upvalue	"U3"	14	true

.constant	k0	"pairs"
.constant	k1	"ItemInTheRing"
.constant	k2	"_nWeaponShowEmoteID"
.constant	k3	"require"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	4
.constant	k7	80
.constant	k8	199
.constant	k9	102
.constant	k10	152
.constant	k11	212
.constant	k12	40
.constant	k13	24
.constant	k14	195
.constant	k15	110
.constant	k16	100
.constant	k17	208
.constant	k18	184
.constant	k19	99
.constant	k20	221
.constant	k21	254
.constant	k22	190
.constant	k23	29
.constant	k24	103
.constant	k25	253
.constant	k26	171
.constant	k27	200
.constant	k28	52
.constant	k29	31
.constant	k30	239
.constant	k31	166
.constant	k32	116
.constant	k33	205
.constant	k34	141
.constant	k35	64
.constant	k36	191
.constant	k37	74
.constant	k38	87
.constant	k39	234
.constant	k40	108
.constant	k41	51
.constant	k42	67
.constant	k43	207
.constant	k44	112
.constant	k45	167
.constant	k46	38
.constant	k47	88
.constant	k48	128
.constant	k49	216
.constant	k50	225
.constant	k51	"TryPlayWeaponShowEmote"
.constant	k52	"ShowOrHideRing"
.constant	k53	"GetIsEmoteExist"
.constant	k54	"BattleNormalTipsByTextID"
.constant	k55	27679
.constant	k56	"ED_QuickExpressShowHide"
.constant	k57	"BroadCast"
.constant	k58	"EventSystem"
.constant	k59	"postEvent"
.constant	k60	"EVENTTYPE_INGAME"
.constant	k61	L"EVENTID_INGAME_SHOW_OR_HIDE_QUICK_EXPRESSION"
.constant	k62	"GetPlayerCharacter"
.constant	k63	"slua"
.constant	k64	"isValid"
.constant	k65	"GetOwningPlayer"
.constant	k66	222
.constant	k67	176
.constant	k68	114
.constant	k69	202
.constant	k70	210
.constant	k71	115
.constant	k72	163
.constant	k73	240
.constant	k74	84
.constant	k75	149
.constant	k76	123
.constant	k77	35
.constant	k78	172
.constant	k79	136
.constant	k80	118
.constant	k81	201
.constant	k82	215
.constant	k83	13
.constant	k84	113
.constant	k85	236
.constant	k86	70
.constant	k87	98
.constant	k88	198
.constant	k89	179
.constant	k90	42
.constant	k91	105
.constant	k92	193
.constant	k93	101
.constant	k94	62
.constant	k95	247
.constant	k96	"CheckEmoteIsBan"
.constant	k97	"DisplayGameTipWithMsgID"
.constant	k98	"CheckIsWearingEmoteLimitCloth"
.constant	k99	"AllLimitEmoteList"
.constant	k100	6036
.constant	k101	"CheckIsDanceTogetherEmote"
.constant	k102	"print"
.constant	k103	"bWriteLog"
.constant	k104	18
.constant	k105	68
.constant	k106	96
.constant	k107	228
.constant	k108	49
.constant	k109	121
.constant	k110	57
.constant	k111	251
.constant	k112	182
.constant	k113	126
.constant	k114	227
.constant	k115	109
.constant	k116	187
.constant	k117	197
.constant	k118	86
.constant	k119	97
.constant	k120	160
.constant	k121	63
.constant	k122	233
.constant	k123	69
.constant	k124	204
.constant	k125	175
.constant	k126	"TriggerDanceBuildSkill"
.constant	k127	"PlayEmoteInternal"
.constant	k128	25
.constant	k129	238
.constant	k130	134
.constant	k131	76
.constant	k132	83
.constant	k133	106
.constant	k134	122
.constant	k135	196
.constant	k136	119
.constant	k137	237
.constant	k138	81
.constant	k139	"ReportCommonTLogDataByBRPhase"
.constant	k140	"tostring"
.constant	k141	1
.constant	k142	0

.line	818	loadnil       r2     0
.line	818	gettabup      r3    u0    k0 ; k0 = "pairs"
.line	818	gettable      r4    r0    k1 ; k1 = "ItemInTheRing"
.line	818	call          r3     2     4
.line	818	jmp            0    l9
.line	818	eq             0    r7    r1
.line	818	jmp            0    l9
.line	818	move          r2    r6
.label	l9
.line	818	move          r0    r0
.line	818	move          r0    r0
.line	818	test          r2     1
.line	818	jmp            0   l14
.line	818	return        r0     1
.label	l14
.line	818	gettable      r3    r0    k2 ; k2 = "_nWeaponShowEmoteID"
.line	818	eq             0    r2    r3
.line	818	jmp            0   l87
.line	818	gettabup      r3    u0    k3 ; k3 = "require"
.line	818	gettabup      r4    u0    k4 ; k4 = "table"
.line	818	gettable      r4    r4    k5 ; k5 = "concat"
.line	818	newtable      r5     1     0
.line	818	getupval      r6    u1
.line	818	loadk         r7    k6 ; k6 = 4
.line	818	loadk         r8    k7 ; k7 = 80
.line	818	loadk         r9    k8 ; k8 = 199
.line	818	loadk        r10    k9 ; k9 = 102
.line	818	loadk        r11   k10 ; k10 = 152
.line	818	loadk        r12   k11 ; k11 = 212
.line	818	loadk        r13   k12 ; k12 = 40
.line	818	loadk        r14   k13 ; k13 = 24
.line	818	loadk        r15   k10 ; k10 = 152
.line	818	loadk        r16   k14 ; k14 = 195
.line	818	loadk        r17   k15 ; k15 = 110
.line	818	loadk        r18   k16 ; k16 = 100
.line	818	loadk        r19   k17 ; k17 = 208
.line	818	loadk        r20   k18 ; k18 = 184
.line	818	loadk        r21   k19 ; k19 = 99
.line	818	loadk        r22   k20 ; k20 = 221
.line	818	loadk        r23   k21 ; k21 = 254
.line	818	loadk        r24   k15 ; k15 = 110
.line	818	loadk        r25   k22 ; k22 = 190
.line	818	loadk        r26   k23 ; k23 = 29
.line	818	loadk        r27   k24 ; k24 = 103
.line	818	loadk        r28   k25 ; k25 = 253
.line	818	loadk        r29    k7 ; k7 = 80
.line	818	loadk        r30   k19 ; k19 = 99
.line	818	loadk        r31   k26 ; k26 = 171
.line	818	loadk        r32   k27 ; k27 = 200
.line	818	loadk        r33   k28 ; k28 = 52
.line	818	loadk        r34   k29 ; k29 = 31
.line	818	loadk        r35   k30 ; k30 = 239
.line	818	loadk        r36   k31 ; k31 = 166
.line	818	loadk        r37   k32 ; k32 = 116
.line	818	loadk        r38   k33 ; k33 = 205
.line	818	loadk        r39   k34 ; k34 = 141
.line	818	loadk        r40   k35 ; k35 = 64
.line	818	loadk        r41   k36 ; k36 = 191
.line	818	loadk        r42   k37 ; k37 = 74
.line	818	loadk        r43   k38 ; k38 = 87
.line	818	loadk        r44   k39 ; k39 = 234
.line	818	loadk        r45   k40 ; k40 = 108
.line	818	loadk        r46   k15 ; k15 = 110
.line	818	call          r6    41     2
.line	818	getupval      r7    u1
.line	818	loadk         r8   k41 ; k41 = 51
.line	818	loadk         r9   k42 ; k42 = 67
.line	818	loadk        r10   k43 ; k43 = 207
.line	818	loadk        r11   k44 ; k44 = 112
.line	818	loadk        r12   k45 ; k45 = 167
.line	818	loadk        r13   k27 ; k27 = 200
.line	818	loadk        r14   k46 ; k46 = 38
.line	818	loadk        r15   k47 ; k47 = 88
.line	818	loadk        r16   k48 ; k48 = 128
.line	818	loadk        r17   k49 ; k49 = 216
.line	818	loadk        r18   k19 ; k19 = 99
.line	818	loadk        r19   k46 ; k46 = 38
.line	818	loadk        r20   k50 ; k50 = 225
.line	818	call          r7    14     0
.line	818	setlist       r5     0     1
.line	818	call          r4     2     2
.line	818	call          r3     2     2
.line	818	gettable      r4    r3   k51 ; k51 = "TryPlayWeaponShowEmo" (truncated)
.line	818	call          r4     1     1
.line	818	self          r4    r0   k52 ; k52 = "ShowOrHideRing"
.line	818	loadbool      r6     0     0
.line	818	call          r4     3     1
.line	818	return        r0     1
.label	l87
.line	818	self          r3    r0   k53 ; k53 = "GetIsEmoteExist"
.line	818	move          r5    r2
.line	818	call          r3     3     2
.line	818	test          r3     1
.line	818	jmp            0  l109
.line	818	gettabup      r4    u2   k54 ; k54 = "BattleNormalTipsByTe" (truncated)
.line	818	loadk         r5   k55 ; k55 = 27679
.line	818	call          r4     2     1
.line	818	gettable      r4    r0   k56 ; k56 = "ED_QuickExpressShowH" (truncated)
.line	818	self          r4    r4   k57 ; k57 = "BroadCast"
.line	818	loadbool      r6     0     0
.line	818	call          r4     3     1
.line	818	gettabup      r4    u0   k58 ; k58 = "EventSystem"
.line	818	self          r4    r4   k59 ; k59 = "postEvent"
.line	818	gettabup      r6    u0   k60 ; k60 = "EVENTTYPE_INGAME"
.line	818	gettabup      r7    u0   k61 ; k61 = L"EVENTID_INGAME_SHOW_" (truncated)
.line	818	loadbool      r8     0     0
.line	818	call          r4     5     1
.line	818	self          r4    r0   k52 ; k52 = "ShowOrHideRing"
.line	818	loadbool      r6     0     0
.line	818	call          r4     3     1
.line	818	return        r0     1
.label	l109
.line	818	gettabup      r4    u3   k62 ; k62 = "GetPlayerCharacter"
.line	818	call          r4     1     2
.line	818	test          r4     0
.line	818	jmp            0  l119
.line	818	gettabup      r5    u0   k63 ; k63 = "slua"
.line	818	gettable      r5    r5   k64 ; k64 = "isValid"
.line	818	move          r6    r4
.line	818	call          r5     2     2
.line	818	test          r5     1
.line	818	jmp            0  l120
.label	l119
.line	818	return        r0     1
.label	l120
.line	818	self          r5    r0   k65 ; k65 = "GetOwningPlayer"
.line	818	call          r5     2     2
.line	818	gettabup      r6    u0    k3 ; k3 = "require"
.line	818	gettabup      r7    u0    k4 ; k4 = "table"
.line	818	gettable      r7    r7    k5 ; k5 = "concat"
.line	818	newtable      r8     1     0
.line	818	getupval      r9    u1
.line	818	loadk        r10    k6 ; k6 = 4
.line	818	loadk        r11    k7 ; k7 = 80
.line	818	loadk        r12    k8 ; k8 = 199
.line	818	loadk        r13    k9 ; k9 = 102
.line	818	loadk        r14   k10 ; k10 = 152
.line	818	loadk        r15   k11 ; k11 = 212
.line	818	loadk        r16   k12 ; k12 = 40
.line	818	loadk        r17   k13 ; k13 = 24
.line	818	loadk        r18   k10 ; k10 = 152
.line	818	loadk        r19   k14 ; k14 = 195
.line	818	loadk        r20   k15 ; k15 = 110
.line	818	loadk        r21   k16 ; k16 = 100
.line	818	loadk        r22   k66 ; k66 = 222
.line	818	loadk        r23   k67 ; k67 = 176
.line	818	loadk        r24   k68 ; k68 = 114
.line	818	loadk        r25   k69 ; k69 = 202
.line	818	loadk        r26   k70 ; k70 = 210
.line	818	loadk        r27   k71 ; k71 = 115
.line	818	loadk        r28   k72 ; k72 = 163
.line	818	loadk        r29   k23 ; k23 = 29
.line	818	loadk        r30   k19 ; k19 = 99
.line	818	loadk        r31   k73 ; k73 = 240
.line	818	loadk        r32   k74 ; k74 = 84
.line	818	loadk        r33   k19 ; k19 = 99
.line	818	loadk        r34   k75 ; k75 = 149
.line	818	loadk        r35   k17 ; k17 = 208
.line	818	loadk        r36   k76 ; k76 = 123
.line	818	loadk        r37   k77 ; k77 = 35
.line	818	loadk        r38   k78 ; k78 = 172
.line	818	loadk        r39   k79 ; k79 = 136
.line	818	loadk        r40   k80 ; k80 = 118
.line	818	loadk        r41   k81 ; k81 = 201
.line	818	loadk        r42   k82 ; k82 = 215
.line	818	loadk        r43   k44 ; k44 = 112
.line	818	loadk        r44   k18 ; k18 = 184
.line	818	loadk        r45   k83 ; k83 = 13
.line	818	loadk        r46   k84 ; k84 = 113
.line	818	loadk        r47   k85 ; k85 = 236
.line	818	loadk        r48   k86 ; k86 = 70
.line	818	loadk        r49   k87 ; k87 = 98
.line	818	call          r9    41     2
.line	818	getupval     r10    u1
.line	818	loadk        r11   k46 ; k46 = 38
.line	818	loadk        r12   k29 ; k29 = 31
.line	818	loadk        r13   k88 ; k88 = 198
.line	818	loadk        r14   k40 ; k40 = 108
.line	818	loadk        r15   k89 ; k89 = 179
.line	818	loadk        r16   k27 ; k27 = 200
.line	818	loadk        r17   k90 ; k90 = 42
.line	818	loadk        r18   k91 ; k91 = 105
.line	818	loadk        r19   k67 ; k67 = 176
.line	818	loadk        r20   k92 ; k92 = 193
.line	818	loadk        r21   k93 ; k93 = 101
.line	818	loadk        r22   k94 ; k94 = 62
.line	818	loadk        r23   k95 ; k95 = 247
.line	818	call         r10    14     0
.line	818	setlist       r8     0     1
.line	818	call          r7     2     2
.line	818	call          r6     2     2
.line	818	gettable      r7    r6   k96 ; k96 = "CheckEmoteIsBan"
.line	818	move          r8    r2
.line	818	call          r7     2     3
.line	818	test          r7     0
.line	818	jmp            0  l200
.line	818	test          r5     0
.line	818	jmp            0  l200
.line	818	gettable      r9    r5   k97 ; k97 = "DisplayGameTipWithMs" (truncated)
.line	818	test          r9     0
.line	818	jmp            0  l200
.line	818	self          r9    r5   k97 ; k97 = "DisplayGameTipWithMs" (truncated)
.line	818	move         r11    r8
.line	818	call          r9     3     1
.line	818	return        r0     1
.label	l200
.line	818	self          r9    r0   k98 ; k98 = "CheckIsWearingEmoteL" (truncated)
.line	818	move         r11    r2
.line	818	call          r9     3     3
.line	818	gettable     r11    r0   k99 ; k99 = "AllLimitEmoteList"
.line	818	gettable     r11   r11    r2
.line	818	loadbool     r12     0     0
.line	818	test         r11     0
.line	818	jmp            0  l212
.line	818	test         r11     0
.line	818	jmp            0  l214
.line	818	test          r9     0
.line	818	jmp            0  l214
.label	l212
.line	818	loadbool     r12     1     0
.line	818	jmp            0  l223
.label	l214
.line	818	test          r5     0
.line	818	jmp            0  l223
.line	818	gettable     r13    r5   k97 ; k97 = "DisplayGameTipWithMs" (truncated)
.line	818	test         r13     0
.line	818	jmp            0  l223
.line	818	self         r13    r5   k97 ; k97 = "DisplayGameTipWithMs" (truncated)
.line	818	loadk        r15  k100 ; k100 = 6036
.line	818	call         r13     3     1
.line	818	return        r0     1
.label	l223
.line	818	gettabup     r13    u0    k3 ; k3 = "require"
.line	818	gettabup     r14    u0    k4 ; k4 = "table"
.line	818	gettable     r14   r14    k5 ; k5 = "concat"
.line	818	newtable     r15     1     0
.line	818	getupval     r16    u1
.line	818	loadk        r17    k6 ; k6 = 4
.line	818	loadk        r18    k7 ; k7 = 80
.line	818	loadk        r19    k8 ; k8 = 199
.line	818	loadk        r20    k9 ; k9 = 102
.line	818	loadk        r21   k10 ; k10 = 152
.line	818	loadk        r22   k11 ; k11 = 212
.line	818	loadk        r23   k12 ; k12 = 40
.line	818	loadk        r24   k13 ; k13 = 24
.line	818	loadk        r25   k10 ; k10 = 152
.line	818	loadk        r26   k14 ; k14 = 195
.line	818	loadk        r27   k15 ; k15 = 110
.line	818	loadk        r28   k16 ; k16 = 100
.line	818	loadk        r29   k66 ; k66 = 222
.line	818	loadk        r30   k67 ; k67 = 176
.line	818	loadk        r31   k68 ; k68 = 114
.line	818	loadk        r32   k69 ; k69 = 202
.line	818	loadk        r33   k70 ; k70 = 210
.line	818	loadk        r34   k71 ; k71 = 115
.line	818	loadk        r35   k72 ; k72 = 163
.line	818	loadk        r36   k23 ; k23 = 29
.line	818	loadk        r37   k19 ; k19 = 99
.line	818	loadk        r38   k73 ; k73 = 240
.line	818	loadk        r39   k74 ; k74 = 84
.line	818	loadk        r40   k19 ; k19 = 99
.line	818	loadk        r41   k75 ; k75 = 149
.line	818	loadk        r42   k17 ; k17 = 208
.line	818	loadk        r43   k76 ; k76 = 123
.line	818	loadk        r44   k77 ; k77 = 35
.line	818	loadk        r45   k78 ; k78 = 172
.line	818	loadk        r46   k79 ; k79 = 136
.line	818	loadk        r47   k80 ; k80 = 118
.line	818	loadk        r48   k81 ; k81 = 201
.line	818	loadk        r49   k82 ; k82 = 215
.line	818	loadk        r50   k44 ; k44 = 112
.line	818	loadk        r51   k18 ; k18 = 184
.line	818	loadk        r52   k83 ; k83 = 13
.line	818	loadk        r53   k84 ; k84 = 113
.line	818	loadk        r54   k85 ; k85 = 236
.line	818	loadk        r55   k86 ; k86 = 70
.line	818	loadk        r56   k87 ; k87 = 98
.line	818	call         r16    41     2
.line	818	getupval     r17    u1
.line	818	loadk        r18   k46 ; k46 = 38
.line	818	loadk        r19   k29 ; k29 = 31
.line	818	loadk        r20   k88 ; k88 = 198
.line	818	loadk        r21   k40 ; k40 = 108
.line	818	loadk        r22   k89 ; k89 = 179
.line	818	loadk        r23   k27 ; k27 = 200
.line	818	loadk        r24   k90 ; k90 = 42
.line	818	loadk        r25   k91 ; k91 = 105
.line	818	loadk        r26   k67 ; k67 = 176
.line	818	loadk        r27   k92 ; k92 = 193
.line	818	loadk        r28   k93 ; k93 = 101
.line	818	loadk        r29   k94 ; k94 = 62
.line	818	loadk        r30   k95 ; k95 = 247
.line	818	call         r17    14     0
.line	818	setlist      r15     0     1
.line	818	call         r14     2     2
.line	818	call         r13     2     2
.line	818	gettable     r14   r13  k101 ; k101 = "CheckIsDanceTogether" (truncated)
.line	818	move         r15    r2
.line	818	call         r14     2     2
.line	818	test         r14     0
.line	818	jmp            0  l338
.line	818	gettabup     r14    u0  k102 ; k102 = "print"
.line	818	gettabup     r15    u0  k103 ; k103 = "bWriteLog"
.line	818	test         r15     0
.line	818	jmp            0  l333
.line	818	getupval     r15    u1
.line	818	loadk        r16  k104 ; k104 = 18
.line	818	loadk        r17  k105 ; k105 = 68
.line	818	loadk        r18   k14 ; k14 = 195
.line	818	loadk        r19  k106 ; k106 = 96
.line	818	loadk        r20   k36 ; k36 = 191
.line	818	loadk        r21  k107 ; k107 = 228
.line	818	loadk        r22  k108 ; k108 = 49
.line	818	loadk        r23   k86 ; k86 = 70
.line	818	loadk        r24   k45 ; k45 = 167
.line	818	loadk        r25   k81 ; k81 = 201
.line	818	loadk        r26  k109 ; k109 = 121
.line	818	loadk        r27  k110 ; k110 = 57
.line	818	loadk        r28  k111 ; k111 = 251
.line	818	loadk        r29  k112 ; k112 = 182
.line	818	loadk        r30  k113 ; k113 = 126
.line	818	loadk        r31   k10 ; k10 = 152
.line	818	loadk        r32  k114 ; k114 = 227
.line	818	loadk        r33  k115 ; k115 = 109
.line	818	loadk        r34  k116 ; k116 = 187
.line	818	loadk        r35   k37 ; k37 = 74
.line	818	loadk        r36    k6 ; k6 = 4
.line	818	loadk        r37  k117 ; k117 = 197
.line	818	loadk        r38  k118 ; k118 = 86
.line	818	loadk        r39  k119 ; k119 = 97
.line	818	loadk        r40  k120 ; k120 = 160
.line	818	loadk        r41   k27 ; k27 = 200
.line	818	loadk        r42   k68 ; k68 = 114
.line	818	loadk        r43  k121 ; k121 = 63
.line	818	loadk        r44   k73 ; k73 = 240
.line	818	loadk        r45  k122 ; k122 = 233
.line	818	loadk        r46  k123 ; k123 = 69
.line	818	loadk        r47  k117 ; k117 = 197
.line	818	loadk        r48  k124 ; k124 = 204
.line	818	loadk        r49   k93 ; k93 = 101
.line	818	loadk        r50  k125 ; k125 = 175
.line	818	call         r15    36     2
.label	l333
.line	818	call         r14     2     1
.line	818	loadbool     r12     0     0
.line	818	gettable     r14   r13  k126 ; k126 = "TriggerDanceBuildSki" (truncated)
.line	818	move         r15    r2
.line	818	call         r14     2     1
.label	l338
.line	818	test         r12     0
.line	818	jmp            0  l415
.line	818	self         r14    r0  k127 ; k127 = "PlayEmoteInternal"
.line	818	move         r16    r2
.line	818	call         r14     3     1
.line	818	gettabup     r14    u0    k3 ; k3 = "require"
.line	818	gettabup     r15    u0    k4 ; k4 = "table"
.line	818	gettable     r15   r15    k5 ; k5 = "concat"
.line	818	newtable     r16     1     0
.line	818	getupval     r17    u1
.line	818	loadk        r18    k6 ; k6 = 4
.line	818	loadk        r19    k7 ; k7 = 80
.line	818	loadk        r20    k8 ; k8 = 199
.line	818	loadk        r21    k9 ; k9 = 102
.line	818	loadk        r22   k10 ; k10 = 152
.line	818	loadk        r23   k11 ; k11 = 212
.line	818	loadk        r24   k12 ; k12 = 40
.line	818	loadk        r25   k13 ; k13 = 24
.line	818	loadk        r26   k10 ; k10 = 152
.line	818	loadk        r27   k14 ; k14 = 195
.line	818	loadk        r28   k15 ; k15 = 110
.line	818	loadk        r29   k16 ; k16 = 100
.line	818	loadk        r30   k17 ; k17 = 208
.line	818	loadk        r31   k18 ; k18 = 184
.line	818	loadk        r32   k19 ; k19 = 99
.line	818	loadk        r33   k20 ; k20 = 221
.line	818	loadk        r34   k21 ; k21 = 254
.line	818	loadk        r35   k15 ; k15 = 110
.line	818	loadk        r36   k22 ; k22 = 190
.line	818	loadk        r37   k23 ; k23 = 29
.line	818	loadk        r38   k24 ; k24 = 103
.line	818	loadk        r39   k25 ; k25 = 253
.line	818	loadk        r40    k7 ; k7 = 80
.line	818	loadk        r41   k19 ; k19 = 99
.line	818	loadk        r42   k26 ; k26 = 171
.line	818	loadk        r43   k27 ; k27 = 200
.line	818	loadk        r44   k28 ; k28 = 52
.line	818	loadk        r45  k128 ; k128 = 25
.line	818	loadk        r46  k129 ; k129 = 238
.line	818	loadk        r47  k120 ; k120 = 160
.line	818	loadk        r48   k93 ; k93 = 101
.line	818	loadk        r49   k88 ; k88 = 198
.line	818	loadk        r50   k82 ; k82 = 215
.line	818	loadk        r51  k123 ; k123 = 69
.line	818	loadk        r52  k130 ; k130 = 134
.line	818	loadk        r53  k131 ; k131 = 76
.line	818	loadk        r54  k132 ; k132 = 83
.line	818	loadk        r55  k125 ; k125 = 175
.line	818	loadk        r56  k133 ; k133 = 106
.line	818	loadk        r57  k134 ; k134 = 122
.line	818	call         r17    41     2
.line	818	getupval     r18    u1
.line	818	loadk        r19   k90 ; k90 = 42
.line	818	loadk        r20   k74 ; k74 = 84
.line	818	loadk        r21  k135 ; k135 = 196
.line	818	loadk        r22  k136 ; k136 = 119
.line	818	loadk        r23   k48 ; k48 = 128
.line	818	loadk        r24  k137 ; k137 = 237
.line	818	loadk        r25   k46 ; k46 = 38
.line	818	loadk        r26  k138 ; k138 = 81
.line	818	loadk        r27   k48 ; k48 = 128
.line	818	loadk        r28   k49 ; k49 = 216
.line	818	loadk        r29   k19 ; k19 = 99
.line	818	loadk        r30   k46 ; k46 = 38
.line	818	call         r18    13     0
.line	818	setlist      r16     0     1
.line	818	call         r15     2     2
.line	818	call         r14     2     2
.line	818	gettable     r15   r14  k139 ; k139 = "ReportCommonTLogData" (truncated)
.line	818	loadk        r16   k82 ; k82 = 215
.line	818	loadk        r17   k82 ; k82 = 215
.line	818	gettabup     r18    u0  k140 ; k140 = "tostring"
.line	818	move         r19    r2
.line	818	call         r18     2     2
.line	818	loadk        r19  k141 ; k141 = 1
.line	818	call         r15     5     1
.line	818	jmp            0  l422
.label	l415
.line	818	test         r10     0
.line	818	jmp            0  l422
.line	818	lt             0  k142   r10 ; k142 = 0
.line	818	jmp            0  l422
.line	818	gettabup     r14    u2   k54 ; k54 = "BattleNormalTipsByTe" (truncated)
.line	818	move         r15   r10
.line	818	call         r14     2     1
.label	l422
.line	818	self         r14    r0   k52 ; k52 = "ShowOrHideRing"
.line	818	loadbool     r16     0     0
.line	818	call         r14     3     1
.line	818	return        r0     1
.line	818	move          r0    r0
.line	818	move          r0    r0
.line	818	move          r0    r0
.line	818	return        r0     1

.function	main/f29

.source	null
.linedefined	878
.lastlinedefined	893
.numparams	2
.is_vararg	0
.maxstacksize	40

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	-1
.constant	k1	0
.constant	k2	"CollectionList"
.constant	k3	1
.constant	k4	"print"
.constant	k5	"bWriteLog"
.constant	k6	18
.constant	k7	68
.constant	k8	195
.constant	k9	96
.constant	k10	191
.constant	k11	228
.constant	k12	49
.constant	k13	70
.constant	k14	167
.constant	k15	201
.constant	k16	121
.constant	k17	57
.constant	k18	251
.constant	k19	182
.constant	k20	126
.constant	k21	130
.constant	k22	231
.constant	k23	115
.constant	k24	163
.constant	k25	103
.constant	k26	75
.constant	k27	193
.constant	k28	85
.constant	k29	188
.constant	k30	255
.constant	k31	117
.constant	k32	54
.constant	k33	238
.constant	k34	172
.constant	k35	99
.constant	k36	220
.constant	k37	202
.constant	k38	164
.constant	k39	"PlayEmoteInternal"
.constant	k40	"require"
.constant	k41	4
.constant	k42	80
.constant	k43	199
.constant	k44	102
.constant	k45	152
.constant	k46	212
.constant	k47	40
.constant	k48	24
.constant	k49	146
.constant	k50	205
.constant	k51	47
.constant	k52	209
.constant	k53	98
.constant	k54	221
.constant	k55	157
.constant	k56	69
.constant	k57	187
.constant	k58	71
.constant	k59	168
.constant	k60	217
.constant	k61	106
.constant	k62	227
.constant	k63	176
.constant	k64	215
.constant	k65	112
.constant	k66	"GetPlayerState"
.constant	k67	"slua"
.constant	k68	"isValid"
.constant	k69	"RPC_ServerAddGeneralCount"
.constant	k70	11041
.constant	k71	"ShowOrHideRing"

.line	878	loadk         r2    k0 ; k0 = -1
.line	878	test          r1     0
.line	878	jmp            0    l9
.line	878	le             0    k1    r1 ; k1 = 0
.line	878	jmp            0    l9
.line	878	gettable      r3    r0    k2 ; k2 = "CollectionList"
.line	878	add           r4    r1    k3 ; k3 = 1
.line	878	gettable      r2    r3    r4
.label	l9
.line	878	gettabup      r3    u0    k4 ; k4 = "print"
.line	878	gettabup      r4    u0    k5 ; k5 = "bWriteLog"
.line	878	test          r4     0
.line	878	jmp            0   l50
.line	878	getupval      r4    u1
.line	878	loadk         r5    k6 ; k6 = 18
.line	878	loadk         r6    k7 ; k7 = 68
.line	878	loadk         r7    k8 ; k8 = 195
.line	878	loadk         r8    k9 ; k9 = 96
.line	878	loadk         r9   k10 ; k10 = 191
.line	878	loadk        r10   k11 ; k11 = 228
.line	878	loadk        r11   k12 ; k12 = 49
.line	878	loadk        r12   k13 ; k13 = 70
.line	878	loadk        r13   k14 ; k14 = 167
.line	878	loadk        r14   k15 ; k15 = 201
.line	878	loadk        r15   k16 ; k16 = 121
.line	878	loadk        r16   k17 ; k17 = 57
.line	878	loadk        r17   k18 ; k18 = 251
.line	878	loadk        r18   k19 ; k19 = 182
.line	878	loadk        r19   k20 ; k20 = 126
.line	878	loadk        r20   k21 ; k21 = 130
.line	878	loadk        r21   k22 ; k22 = 231
.line	878	loadk        r22   k23 ; k23 = 115
.line	878	loadk        r23   k24 ; k24 = 163
.line	878	loadk        r24   k25 ; k25 = 103
.line	878	loadk        r25   k26 ; k26 = 75
.line	878	loadk        r26   k27 ; k27 = 193
.line	878	loadk        r27   k28 ; k28 = 85
.line	878	loadk        r28   k25 ; k25 = 103
.line	878	loadk        r29   k29 ; k29 = 188
.line	878	loadk        r30   k30 ; k30 = 255
.line	878	loadk        r31   k31 ; k31 = 117
.line	878	loadk        r32   k32 ; k32 = 54
.line	878	loadk        r33   k33 ; k33 = 238
.line	878	loadk        r34   k34 ; k34 = 172
.line	878	loadk        r35   k35 ; k35 = 99
.line	878	loadk        r36   k36 ; k36 = 220
.line	878	loadk        r37   k37 ; k37 = 202
.line	878	loadk        r38   k20 ; k20 = 126
.line	878	loadk        r39   k38 ; k38 = 164
.line	878	call          r4    36     2
.label	l50
.line	878	move          r5    r1
.line	878	move          r6    r2
.line	878	call          r3     4     1
.line	878	test          r2     0
.line	878	jmp            0  l117
.line	878	lt             0    k1    r2 ; k1 = 0
.line	878	jmp            0  l117
.line	878	self          r3    r0   k39 ; k39 = "PlayEmoteInternal"
.line	878	move          r5    r2
.line	878	call          r3     3     1
.line	878	gettabup      r3    u0   k40 ; k40 = "require"
.line	878	getupval      r4    u1
.line	878	loadk         r5   k41 ; k41 = 4
.line	878	loadk         r6   k42 ; k42 = 80
.line	878	loadk         r7   k43 ; k43 = 199
.line	878	loadk         r8   k44 ; k44 = 102
.line	878	loadk         r9   k45 ; k45 = 152
.line	878	loadk        r10   k46 ; k46 = 212
.line	878	loadk        r11   k47 ; k47 = 40
.line	878	loadk        r12   k48 ; k48 = 24
.line	878	loadk        r13   k49 ; k49 = 146
.line	878	loadk        r14   k50 ; k50 = 205
.line	878	loadk        r15   k25 ; k25 = 103
.line	878	loadk        r16   k51 ; k51 = 47
.line	878	loadk        r17   k52 ; k52 = 209
.line	878	loadk        r18   k19 ; k19 = 182
.line	878	loadk        r19   k53 ; k53 = 98
.line	878	loadk        r20   k54 ; k54 = 221
.line	878	loadk        r21   k55 ; k55 = 157
.line	878	loadk        r22   k56 ; k56 = 69
.line	878	loadk        r23   k57 ; k57 = 187
.line	878	loadk        r24   k58 ; k58 = 71
.line	878	loadk        r25   k56 ; k56 = 69
.line	878	loadk        r26   k10 ; k10 = 191
.line	878	loadk        r27   k20 ; k20 = 126
.line	878	loadk        r28   k25 ; k25 = 103
.line	878	loadk        r29   k59 ; k59 = 168
.line	878	loadk        r30   k60 ; k60 = 217
.line	878	loadk        r31   k61 ; k61 = 106
.line	878	loadk        r32   k32 ; k32 = 54
.line	878	loadk        r33   k62 ; k62 = 227
.line	878	loadk        r34   k63 ; k63 = 176
.line	878	loadk        r35    k7 ; k7 = 68
.line	878	loadk        r36   k15 ; k15 = 201
.line	878	loadk        r37   k64 ; k64 = 215
.line	878	loadk        r38   k65 ; k65 = 112
.line	878	call          r4    35     2
.line	878	call          r3     2     2
.line	878	gettable      r4    r3   k66 ; k66 = "GetPlayerState"
.line	878	call          r4     1     2
.line	878	gettabup      r5    u0   k67 ; k67 = "slua"
.line	878	gettable      r5    r5   k68 ; k68 = "isValid"
.line	878	move          r6    r4
.line	878	call          r5     2     2
.line	878	test          r5     0
.line	878	jmp            0  l114
.line	878	gettable      r5    r4   k69 ; k69 = "RPC_ServerAddGeneral" (truncated)
.line	878	test          r5     0
.line	878	jmp            0  l114
.line	878	self          r5    r4   k69 ; k69 = "RPC_ServerAddGeneral" (truncated)
.line	878	loadk         r7   k70 ; k70 = 11041
.line	878	loadk         r8    k3 ; k3 = 1
.line	878	loadbool      r9     0     0
.line	878	call          r5     5     1
.label	l114
.line	878	self          r5    r0   k71 ; k71 = "ShowOrHideRing"
.line	878	loadbool      r7     0     0
.line	878	call          r5     3     1
.label	l117
.line	878	return        r0     1
.line	878	move          r0    r0
.line	878	move          r0    r0
.line	878	move          r0    r0
.line	878	move          r0    r0
.line	878	return        r0     1

.function	main/f30

.source	null
.linedefined	895
.lastlinedefined	919
.numparams	2
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	14	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	18
.constant	k3	68
.constant	k4	195
.constant	k5	96
.constant	k6	191
.constant	k7	228
.constant	k8	49
.constant	k9	70
.constant	k10	167
.constant	k11	201
.constant	k12	121
.constant	k13	57
.constant	k14	251
.constant	k15	182
.constant	k16	126
.constant	k17	130
.constant	k18	227
.constant	k19	109
.constant	k20	187
.constant	k21	74
.constant	k22	97
.constant	k23	252
.constant	k24	86
.constant	k25	114
.constant	k26	160
.constant	k27	245
.constant	k28	116
.constant	k29	46
.constant	k30	231
.constant	k31	110
.constant	k32	207
.constant	k33	"GetPlayerCharacter"
.constant	k34	"slua"
.constant	k35	"isValid"
.constant	k36	"OnPlayEmote"
.constant	k37	"SubsystemMgr"
.constant	k38	"Get"
.constant	k39	6
.constant	k40	92
.constant	k41	197
.constant	k42	119
.constant	k43	177
.constant	k44	242
.constant	k45	60
.constant	k46	84
.constant	k47	134
.constant	k48	213
.constant	k49	62
.constant	k50	247
.constant	k51	180
.constant	k52	"TryPlayMovableEmote"
.constant	k53	"require"
.constant	k54	"table"
.constant	k55	"concat"
.constant	k56	4
.constant	k57	80
.constant	k58	199
.constant	k59	102
.constant	k60	152
.constant	k61	212
.constant	k62	40
.constant	k63	24
.constant	k64	100
.constant	k65	222
.constant	k66	176
.constant	k67	202
.constant	k68	210
.constant	k69	115
.constant	k70	163
.constant	k71	29
.constant	k72	99
.constant	k73	240
.constant	k74	149
.constant	k75	208
.constant	k76	123
.constant	k77	35
.constant	k78	172
.constant	k79	136
.constant	k80	118
.constant	k81	215
.constant	k82	112
.constant	k83	184
.constant	k84	13
.constant	k85	113
.constant	k86	236
.constant	k87	98
.constant	k88	38
.constant	k89	31
.constant	k90	198
.constant	k91	108
.constant	k92	179
.constant	k93	200
.constant	k94	42
.constant	k95	105
.constant	k96	193
.constant	k97	101
.constant	k98	"PlayEmote"
.constant	k99	"EventSystem"
.constant	k100	"postEvent"
.constant	k101	"EVENTTYPE_INGAME"
.constant	k102	"EVENTID_INGAME_OLD_EXPRESSION_PLAY_EMOTE"
.constant	k103	"slua_GameFrontendHUD"
.constant	k104	"GetPlayerController"
.constant	k105	nil
.constant	k106	"CastUIMsg"
.constant	k107	22
.constant	k108	120
.constant	k109	254
.constant	k110	10
.constant	k111	90
.constant	k112	186
.constant	k113	223
.constant	k114	111
.constant	k115	27
.constant	k116	211
.constant	k117	246
.constant	k118	170
.constant	k119	65
.constant	k120	226
.constant	k121	72
.constant	k122	51
.constant	k123	174
.constant	k124	95
.constant	k125	205
.constant	k126	185
.constant	k127	196
.constant	k128	"ED_QuickExpressShowHide"
.constant	k129	"BroadCast"
.constant	k130	L"EVENTID_INGAME_SHOW_OR_HIDE_QUICK_EXPRESSION"

.line	895	gettabup      r2    u0    k0 ; k0 = "print"
.line	895	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	895	test          r3     0
.line	895	jmp            0   l40
.line	895	getupval      r3    u1
.line	895	loadk         r4    k2 ; k2 = 18
.line	895	loadk         r5    k3 ; k3 = 68
.line	895	loadk         r6    k4 ; k4 = 195
.line	895	loadk         r7    k5 ; k5 = 96
.line	895	loadk         r8    k6 ; k6 = 191
.line	895	loadk         r9    k7 ; k7 = 228
.line	895	loadk        r10    k8 ; k8 = 49
.line	895	loadk        r11    k9 ; k9 = 70
.line	895	loadk        r12   k10 ; k10 = 167
.line	895	loadk        r13   k11 ; k11 = 201
.line	895	loadk        r14   k12 ; k12 = 121
.line	895	loadk        r15   k13 ; k13 = 57
.line	895	loadk        r16   k14 ; k14 = 251
.line	895	loadk        r17   k15 ; k15 = 182
.line	895	loadk        r18   k16 ; k16 = 126
.line	895	loadk        r19   k17 ; k17 = 130
.line	895	loadk        r20   k18 ; k18 = 227
.line	895	loadk        r21   k19 ; k19 = 109
.line	895	loadk        r22   k20 ; k20 = 187
.line	895	loadk        r23   k21 ; k21 = 74
.line	895	loadk        r24   k22 ; k22 = 97
.line	895	loadk        r25   k23 ; k23 = 252
.line	895	loadk        r26   k24 ; k24 = 86
.line	895	loadk        r27   k25 ; k25 = 114
.line	895	loadk        r28   k26 ; k26 = 160
.line	895	loadk        r29   k27 ; k27 = 245
.line	895	loadk        r30   k28 ; k28 = 116
.line	895	loadk        r31   k29 ; k29 = 46
.line	895	loadk        r32   k30 ; k30 = 231
.line	895	loadk        r33   k20 ; k20 = 187
.line	895	loadk        r34   k31 ; k31 = 110
.line	895	loadk        r35   k11 ; k11 = 201
.line	895	loadk        r36   k32 ; k32 = 207
.line	895	call          r3    34     2
.label	l40
.line	895	move          r4    r1
.line	895	call          r2     3     1
.line	895	gettabup      r2    u2   k33 ; k33 = "GetPlayerCharacter"
.line	895	call          r2     1     2
.line	895	test          r2     0
.line	895	jmp            0   l55
.line	895	gettabup      r3    u0   k34 ; k34 = "slua"
.line	895	gettable      r3    r3   k35 ; k35 = "isValid"
.line	895	move          r4    r2
.line	895	call          r3     2     2
.line	895	test          r3     0
.line	895	jmp            0   l55
.line	895	gettable      r3    r2   k36 ; k36 = "OnPlayEmote"
.line	895	test          r3     1
.line	895	jmp            0   l56
.label	l55
.line	895	return        r0     1
.label	l56
.line	895	loadbool      r3     0     0
.line	895	gettabup      r4    u0   k37 ; k37 = "SubsystemMgr"
.line	895	self          r4    r4   k38 ; k38 = "Get"
.line	895	getupval      r6    u1
.line	895	loadk         r7   k39 ; k39 = 6
.line	895	loadk         r8   k40 ; k40 = 92
.line	895	loadk         r9   k41 ; k41 = 197
.line	895	loadk        r10   k42 ; k42 = 119
.line	895	loadk        r11   k43 ; k43 = 177
.line	895	loadk        r12   k44 ; k44 = 242
.line	895	loadk        r13   k45 ; k45 = 60
.line	895	loadk        r14   k46 ; k46 = 84
.line	895	loadk        r15   k47 ; k47 = 134
.line	895	loadk        r16   k48 ; k48 = 213
.line	895	loadk        r17   k12 ; k12 = 121
.line	895	loadk        r18   k49 ; k49 = 62
.line	895	loadk        r19   k50 ; k50 = 247
.line	895	loadk        r20   k51 ; k51 = 180
.line	895	call          r6    15     2
.line	895	call          r4     3     2
.line	895	test          r4     0
.line	895	jmp            0   l83
.line	895	self          r5    r4   k52 ; k52 = "TryPlayMovableEmote"
.line	895	move          r7    r1
.line	895	move          r8    r2
.line	895	call          r5     4     2
.line	895	move          r3    r5
.label	l83
.line	895	test          r3     1
.line	895	jmp            0  l153
.line	895	gettabup      r5    u0   k53 ; k53 = "require"
.line	895	gettabup      r6    u0   k54 ; k54 = "table"
.line	895	gettable      r6    r6   k55 ; k55 = "concat"
.line	895	newtable      r7     1     0
.line	895	getupval      r8    u1
.line	895	loadk         r9   k56 ; k56 = 4
.line	895	loadk        r10   k57 ; k57 = 80
.line	895	loadk        r11   k58 ; k58 = 199
.line	895	loadk        r12   k59 ; k59 = 102
.line	895	loadk        r13   k60 ; k60 = 152
.line	895	loadk        r14   k61 ; k61 = 212
.line	895	loadk        r15   k62 ; k62 = 40
.line	895	loadk        r16   k63 ; k63 = 24
.line	895	loadk        r17   k60 ; k60 = 152
.line	895	loadk        r18    k4 ; k4 = 195
.line	895	loadk        r19   k31 ; k31 = 110
.line	895	loadk        r20   k64 ; k64 = 100
.line	895	loadk        r21   k65 ; k65 = 222
.line	895	loadk        r22   k66 ; k66 = 176
.line	895	loadk        r23   k25 ; k25 = 114
.line	895	loadk        r24   k67 ; k67 = 202
.line	895	loadk        r25   k68 ; k68 = 210
.line	895	loadk        r26   k69 ; k69 = 115
.line	895	loadk        r27   k70 ; k70 = 163
.line	895	loadk        r28   k71 ; k71 = 29
.line	895	loadk        r29   k72 ; k72 = 99
.line	895	loadk        r30   k73 ; k73 = 240
.line	895	loadk        r31   k46 ; k46 = 84
.line	895	loadk        r32   k72 ; k72 = 99
.line	895	loadk        r33   k74 ; k74 = 149
.line	895	loadk        r34   k75 ; k75 = 208
.line	895	loadk        r35   k76 ; k76 = 123
.line	895	loadk        r36   k77 ; k77 = 35
.line	895	loadk        r37   k78 ; k78 = 172
.line	895	loadk        r38   k79 ; k79 = 136
.line	895	loadk        r39   k80 ; k80 = 118
.line	895	loadk        r40   k11 ; k11 = 201
.line	895	loadk        r41   k81 ; k81 = 215
.line	895	loadk        r42   k82 ; k82 = 112
.line	895	loadk        r43   k83 ; k83 = 184
.line	895	loadk        r44   k84 ; k84 = 13
.line	895	loadk        r45   k85 ; k85 = 113
.line	895	loadk        r46   k86 ; k86 = 236
.line	895	loadk        r47    k9 ; k9 = 70
.line	895	loadk        r48   k87 ; k87 = 98
.line	895	call          r8    41     2
.line	895	getupval      r9    u1
.line	895	loadk        r10   k88 ; k88 = 38
.line	895	loadk        r11   k89 ; k89 = 31
.line	895	loadk        r12   k90 ; k90 = 198
.line	895	loadk        r13   k91 ; k91 = 108
.line	895	loadk        r14   k92 ; k92 = 179
.line	895	loadk        r15   k93 ; k93 = 200
.line	895	loadk        r16   k94 ; k94 = 42
.line	895	loadk        r17   k95 ; k95 = 105
.line	895	loadk        r18   k66 ; k66 = 176
.line	895	loadk        r19   k96 ; k96 = 193
.line	895	loadk        r20   k97 ; k97 = 101
.line	895	loadk        r21   k49 ; k49 = 62
.line	895	loadk        r22   k50 ; k50 = 247
.line	895	call          r9    14     0
.line	895	setlist       r7     0     1
.line	895	call          r6     2     2
.line	895	call          r5     2     2
.line	895	gettable      r6    r5   k98 ; k98 = "PlayEmote"
.line	895	move          r7    r2
.line	895	move          r8    r1
.line	895	call          r6     3     1
.label	l153
.line	895	gettabup      r5    u0   k99 ; k99 = "EventSystem"
.line	895	self          r5    r5  k100 ; k100 = "postEvent"
.line	895	gettabup      r7    u0  k101 ; k101 = "EVENTTYPE_INGAME"
.line	895	gettabup      r8    u0  k102 ; k102 = "EVENTID_INGAME_OLD_E" (truncated)
.line	895	call          r5     4     1
.line	895	gettabup      r5    u0  k103 ; k103 = "slua_GameFrontendHUD"
.line	895	self          r5    r5  k104 ; k104 = "GetPlayerController"
.line	895	call          r5     2     2
.line	895	eq             1    r5  k105 ; k105 = nil
.line	895	jmp            0  l211
.line	895	gettabup      r6    u0   k34 ; k34 = "slua"
.line	895	gettable      r6    r6   k35 ; k35 = "isValid"
.line	895	move          r7    r5
.line	895	call          r6     2     2
.line	895	test          r6     0
.line	895	jmp            0  l211
.line	895	self          r6    r5  k106 ; k106 = "CastUIMsg"
.line	895	getupval      r8    u1
.line	895	loadk         r9  k107 ; k107 = 22
.line	895	loadk        r10  k108 ; k108 = 120
.line	895	loadk        r11   k30 ; k30 = 231
.line	895	loadk        r12   k82 ; k82 = 112
.line	895	loadk        r13   k92 ; k92 = 179
.line	895	loadk        r14  k109 ; k109 = 254
.line	895	loadk        r15  k110 ; k110 = 10
.line	895	loadk        r16  k111 ; k111 = 90
.line	895	loadk        r17  k112 ; k112 = 186
.line	895	loadk        r18  k113 ; k113 = 223
.line	895	loadk        r19  k114 ; k114 = 111
.line	895	loadk        r20  k115 ; k115 = 27
.line	895	loadk        r21   k30 ; k30 = 231
.line	895	loadk        r22   k66 ; k66 = 176
.line	895	loadk        r23   k69 ; k69 = 115
.line	895	loadk        r24  k116 ; k116 = 211
.line	895	loadk        r25  k117 ; k117 = 246
.line	895	loadk        r26   k12 ; k12 = 121
.line	895	loadk        r27  k118 ; k118 = 170
.line	895	loadk        r28  k119 ; k119 = 65
.line	895	loadk        r29  k119 ; k119 = 65
.line	895	loadk        r30  k120 ; k120 = 226
.line	895	loadk        r31   k21 ; k21 = 74
.line	895	loadk        r32  k114 ; k114 = 111
.line	895	loadk        r33  k118 ; k118 = 170
.line	895	loadk        r34   k68 ; k68 = 210
.line	895	loadk        r35  k121 ; k121 = 72
.line	895	loadk        r36  k122 ; k122 = 51
.line	895	loadk        r37   k86 ; k86 = 236
.line	895	loadk        r38  k123 ; k123 = 174
.line	895	call          r8    31     2
.line	895	getupval      r9    u1
.line	895	loadk        r10   k94 ; k94 = 42
.line	895	loadk        r11  k124 ; k124 = 95
.line	895	loadk        r12  k125 ; k125 = 205
.line	895	loadk        r13   k87 ; k87 = 98
.line	895	loadk        r14  k126 ; k126 = 185
.line	895	loadk        r15  k127 ; k127 = 196
.line	895	call          r9     7     2
.line	895	call          r6     4     1
.label	l211
.line	895	gettable      r6    r0  k128 ; k128 = "ED_QuickExpressShowH" (truncated)
.line	895	test          r6     0
.line	895	jmp            0  l224
.line	895	gettable      r6    r0  k128 ; k128 = "ED_QuickExpressShowH" (truncated)
.line	895	self          r6    r6  k129 ; k129 = "BroadCast"
.line	895	loadbool      r8     0     0
.line	895	call          r6     3     1
.line	895	gettabup      r6    u0   k99 ; k99 = "EventSystem"
.line	895	self          r6    r6  k100 ; k100 = "postEvent"
.line	895	gettabup      r8    u0  k101 ; k101 = "EVENTTYPE_INGAME"
.line	895	gettabup      r9    u0  k130 ; k130 = L"EVENTID_INGAME_SHOW_" (truncated)
.line	895	loadbool     r10     0     0
.line	895	call          r6     5     1
.label	l224
.line	895	return        r0     1
.line	895	move          r0    r0
.line	895	move          r0    r0
.line	895	move          r0    r0
.line	895	move          r0    r0
.line	895	return        r0     1

.function	main/f31

.source	null
.linedefined	921
.lastlinedefined	934
.numparams	1
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	0	false

.constant	k0	"GetOwningPlayer"
.constant	k1	"slua"
.constant	k2	"isValid"
.constant	k3	"EmoteItemIDToImagePathMap"
.constant	k4	"EmoteItemIDToImageBattlePathMap"
.constant	k5	"pairs"
.constant	k6	"Get"
.constant	k7	"ItemIDToImagePathMap"

.line	921	self          r1    r0    k0 ; k0 = "GetOwningPlayer"
.line	921	call          r1     2     2
.line	921	test          r1     0
.line	921	jmp            0   l17
.line	921	gettabup      r2    u0    k1 ; k1 = "slua"
.line	921	gettable      r2    r2    k2 ; k2 = "isValid"
.line	921	move          r3    r1
.line	921	call          r2     2     2
.line	921	test          r2     0
.line	921	jmp            0   l17
.line	921	gettable      r2    r1    k3 ; k3 = "EmoteItemIDToImagePa" (truncated)
.line	921	test          r2     0
.line	921	jmp            0   l17
.line	921	gettable      r2    r1    k4 ; k4 = "EmoteItemIDToImageBa" (truncated)
.line	921	test          r2     1
.line	921	jmp            0   l18
.label	l17
.line	921	return        r0     1
.label	l18
.line	921	gettabup      r2    u0    k5 ; k5 = "pairs"
.line	921	gettable      r3    r1    k3 ; k3 = "EmoteItemIDToImagePa" (truncated)
.line	921	call          r2     2     4
.line	921	jmp            0   l33
.line	921	gettable      r7    r1    k4 ; k4 = "EmoteItemIDToImageBa" (truncated)
.line	921	self          r7    r7    k6 ; k6 = "Get"
.line	921	move          r9    r5
.line	921	call          r7     3     2
.line	921	test          r7     0
.line	921	jmp            0   l31
.line	921	gettable      r8    r0    k7 ; k7 = "ItemIDToImagePathMap"
.line	921	settable      r8    r5    r7
.line	921	jmp            0   l33
.label	l31
.line	921	gettable      r8    r0    k7 ; k7 = "ItemIDToImagePathMap"
.line	921	settable      r8    r5    r6
.label	l33
.line	921	move          r0    r0
.line	921	move          r0    r0
.line	921	return        r0     1
.line	921	move          r0    r0
.line	921	move          r0    r0
.line	921	return        r0     1

.function	main/f32

.source	null
.linedefined	936
.lastlinedefined	948
.numparams	2
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	5	true

.constant	k0	"CDataTable"
.constant	k1	"GetTableData"
.constant	k2	10
.constant	k3	69
.constant	k4	207
.constant	k5	110
.constant	k6	"ItemID"
.constant	k7	0
.constant	k8	"RedEmotionSoundPath"
.constant	k9	"VoiceDelegate"
.constant	k10	"GetAssetAsync"

.line	936	gettabup      r2    u0    k0 ; k0 = "CDataTable"
.line	936	gettable      r2    r2    k1 ; k1 = "GetTableData"
.line	936	getupval      r3    u1
.line	936	loadk         r4    k2 ; k2 = 10
.line	936	loadk         r5    k3 ; k3 = 69
.line	936	loadk         r6    k4 ; k4 = 207
.line	936	loadk         r7    k5 ; k5 = 110
.line	936	call          r3     5     2
.line	936	move          r4    r1
.line	936	call          r2     3     2
.line	936	test          r2     1
.line	936	jmp            0   l14
.line	936	return        r0     1
.label	l14
.line	936	gettable      r3    r2    k6 ; k6 = "ItemID"
.line	936	eq             1    r3    k7 ; k7 = 0
.line	936	jmp            0   l22
.line	936	gettable      r3    r2    k8 ; k8 = "RedEmotionSoundPath"
.line	936	getupval      r4    u1
.line	936	call          r4     1     2
.line	936	eq             0    r3    r4
.line	936	jmp            0   l22
.label	l22
.line	936	gettabup      r3    u2   k10 ; k10 = "GetAssetAsync"
.line	936	gettable      r4    r2    k8 ; k8 = "RedEmotionSoundPath"
.line	936	closure       r5    f0
.line	936	call          r3     3     2
.line	936	settable      r0    k9    r3 ; k9 = "VoiceDelegate"
.line	936	return        r0     1
.line	936	move          r0    r0
.line	936	move          r0    r0
.line	936	return        r0     1

.function	main/f32/f0

.source	null
.linedefined	943
.lastlinedefined	947
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	true

.constant	k0	"OnLoadSoundFromPath"

.line	943	test          r0     0
.line	943	jmp            0    l7
.line	943	getupval      r1    u0
.line	943	self          r1    r1    k0 ; k0 = "OnLoadSoundFromPath"
.line	943	move          r3    r0
.line	943	call          r1     3     1
.label	l7
.line	943	return        r0     1
.line	943	move          r0    r0
.line	943	move          r0    r0
.line	943	return        r0     1

.function	main/f33

.source	null
.linedefined	950
.lastlinedefined	961
.numparams	2
.is_vararg	0
.maxstacksize	27

.upvalue	"_ENV"	0	false
.upvalue	"U1"	14	true
.upvalue	"U2"	1	true
.upvalue	"U3"	7	true

.constant	k0	"slua"
.constant	k1	"isValid"
.constant	k2	"GetPlayerCharacter"
.constant	k3	"K2_GetActorLocation"
.constant	k4	"require"
.constant	k5	32
.constant	k6	93
.constant	k7	195
.constant	k8	102
.constant	k9	186
.constant	k10	213
.constant	k11	103
.constant	k12	85
.constant	k13	193
.constant	k14	37
.constant	k15	252
.constant	k16	247
.constant	k17	101
.constant	k18	209
.constant	k19	236
.constant	k20	116
.constant	k21	174
.constant	k22	90
.constant	k23	72
.constant	k24	"PostEventAtLocation"
.constant	k25	"FRotator"
.constant	k26	0
.constant	k27	"GetGameInstance"

.line	950	test          r1     0
.line	950	jmp            0    l9
.line	950	gettabup      r2    u0    k0 ; k0 = "slua"
.line	950	gettable      r2    r2    k1 ; k1 = "isValid"
.line	950	move          r3    r1
.line	950	call          r2     2     2
.line	950	test          r2     1
.line	950	jmp            0   l10
.label	l9
.line	950	return        r0     1
.label	l10
.line	950	gettabup      r2    u1    k2 ; k2 = "GetPlayerCharacter"
.line	950	call          r2     1     2
.line	950	test          r2     0
.line	950	jmp            0   l20
.line	950	gettabup      r3    u0    k0 ; k0 = "slua"
.line	950	gettable      r3    r3    k1 ; k1 = "isValid"
.line	950	move          r4    r2
.line	950	call          r3     2     2
.line	950	test          r3     1
.line	950	jmp            0   l21
.label	l20
.line	950	return        r0     1
.label	l21
.line	950	self          r3    r2    k3 ; k3 = "K2_GetActorLocation"
.line	950	call          r3     2     2
.line	950	gettabup      r4    u0    k4 ; k4 = "require"
.line	950	getupval      r5    u2
.line	950	loadk         r6    k5 ; k5 = 32
.line	950	loadk         r7    k6 ; k6 = 93
.line	950	loadk         r8    k7 ; k7 = 195
.line	950	loadk         r9    k8 ; k8 = 102
.line	950	loadk        r10    k9 ; k9 = 186
.line	950	loadk        r11   k10 ; k10 = 213
.line	950	loadk        r12   k11 ; k11 = 103
.line	950	loadk        r13   k12 ; k12 = 85
.line	950	loadk        r14    k9 ; k9 = 186
.line	950	loadk        r15   k13 ; k13 = 193
.line	950	loadk        r16   k11 ; k11 = 103
.line	950	loadk        r17   k14 ; k14 = 37
.line	950	loadk        r18   k15 ; k15 = 252
.line	950	loadk        r19   k16 ; k16 = 247
.line	950	loadk        r20   k17 ; k17 = 101
.line	950	loadk        r21   k18 ; k18 = 209
.line	950	loadk        r22   k19 ; k19 = 236
.line	950	loadk        r23   k20 ; k20 = 116
.line	950	loadk        r24   k21 ; k21 = 174
.line	950	loadk        r25   k22 ; k22 = 90
.line	950	loadk        r26   k23 ; k23 = 72
.line	950	call          r5    22     2
.line	950	call          r4     2     2
.line	950	gettabup      r5    u3   k24 ; k24 = "PostEventAtLocation"
.line	950	move          r6    r1
.line	950	move          r7    r3
.line	950	gettabup      r8    u0   k25 ; k25 = "FRotator"
.line	950	loadk         r9   k26 ; k26 = 0
.line	950	call          r8     2     2
.line	950	getupval      r9    u2
.line	950	call          r9     1     2
.line	950	gettable     r10    r4   k27 ; k27 = "GetGameInstance"
.line	950	call         r10     1     0
.line	950	call          r5     0     1
.line	950	return        r0     1
.line	950	move          r0    r0
.line	950	move          r0    r0
.line	950	move          r0    r0
.line	950	return        r0     1

.function	main/f34

.source	null
.linedefined	963
.lastlinedefined	971
.numparams	1
.is_vararg	0
.maxstacksize	3

.constant	k0	"CanvasPanel_Root"
.constant	k1	"IsVisible"
.constant	k2	"IsClothDirty"
.constant	k3	true

.line	963	gettable      r1    r0    k0 ; k0 = "CanvasPanel_Root"
.line	963	test          r1     1
.line	963	jmp            0    l5
.line	963	return        r0     1
.label	l5
.line	963	gettable      r1    r0    k0 ; k0 = "CanvasPanel_Root"
.line	963	self          r1    r1    k1 ; k1 = "IsVisible"
.line	963	call          r1     2     2
.line	963	test          r1     0
.line	963	jmp            0   l11
.line	963	settable      r0    k2    k3 ; k3 = true
.label	l11
.line	963	return        r0     1
.line	963	move          r0    r0
.line	963	move          r0    r0
.line	963	move          r0    r0
.line	963	move          r0    r0
.line	963	return        r0     1

.function	main/f35

.source	null
.linedefined	973
.lastlinedefined	975
.numparams	2
.is_vararg	0
.maxstacksize	5

.constant	k0	"ShowOrHideRing"

.line	973	self          r2    r0    k0 ; k0 = "ShowOrHideRing"
.line	973	move          r4    r1
.line	973	call          r2     3     1
.line	973	return        r0     1
.line	973	move          r0    r0
.line	973	move          r0    r0
.line	973	move          r0    r0
.line	973	return        r0     1

.function	main/f36

.source	null
.linedefined	977
.lastlinedefined	1000
.numparams	2
.is_vararg	0
.maxstacksize	19

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"CDataTable"
.constant	k1	"GetTableData"
.constant	k2	6
.constant	k3	92
.constant	k4	197
.constant	k5	119
.constant	k6	189
.constant	k7	206
.constant	k8	39
.constant	k9	122
.constant	k10	188
.constant	k11	193
.constant	k12	99
.constant	k13	62
.constant	k14	209
.constant	k15	191
.constant	k16	0
.constant	k17	"TipsID"
.constant	k18	"ItemID_a"
.constant	k19	"IsShow"
.constant	k20	"pairs"
.constant	k21	"ClothBackpackItem"

.line	977	gettabup      r2    u0    k0 ; k0 = "CDataTable"
.line	977	gettable      r2    r2    k1 ; k1 = "GetTableData"
.line	977	getupval      r3    u1
.line	977	loadk         r4    k2 ; k2 = 6
.line	977	loadk         r5    k3 ; k3 = 92
.line	977	loadk         r6    k4 ; k4 = 197
.line	977	loadk         r7    k5 ; k5 = 119
.line	977	loadk         r8    k6 ; k6 = 189
.line	977	loadk         r9    k7 ; k7 = 206
.line	977	loadk        r10    k8 ; k8 = 39
.line	977	loadk        r11    k9 ; k9 = 122
.line	977	loadk        r12   k10 ; k10 = 188
.line	977	loadk        r13   k11 ; k11 = 193
.line	977	loadk        r14   k12 ; k12 = 99
.line	977	loadk        r15   k13 ; k13 = 62
.line	977	loadk        r16   k14 ; k14 = 209
.line	977	loadk        r17   k15 ; k15 = 191
.line	977	loadk        r18    k5 ; k5 = 119
.line	977	call          r3    16     2
.line	977	move          r4    r1
.line	977	call          r2     3     2
.line	977	loadk         r3   k16 ; k16 = 0
.line	977	test          r2     0
.line	977	jmp            0   l58
.line	977	gettable      r3    r2   k17 ; k17 = "TipsID"
.line	977	gettable      r4    r2   k18 ; k18 = "ItemID_a"
.line	977	gettable      r5    r2   k19 ; k19 = "IsShow"
.line	977	test          r5     0
.line	977	jmp            0   l46
.line	977	loadbool      r5     1     0
.line	977	gettabup      r6    u0   k20 ; k20 = "pairs"
.line	977	move          r7    r4
.line	977	call          r6     2     4
.line	977	jmp            0   l40
.line	977	gettable     r11    r0   k21 ; k21 = "ClothBackpackItem"
.line	977	gettable     r11   r11   r10
.line	977	test         r11     1
.line	977	jmp            0   l40
.line	977	loadbool      r5     0     0
.label	l40
.line	977	move          r0    r0
.line	977	move          r0    r0
.line	977	move          r6    r5
.line	977	move          r7    r3
.line	977	return        r6     3
.line	977	jmp            0   l58
.label	l46
.line	977	gettabup      r5    u0   k20 ; k20 = "pairs"
.line	977	move          r6    r4
.line	977	call          r5     2     4
.line	977	jmp            0   l56
.line	977	gettable     r10    r0   k21 ; k21 = "ClothBackpackItem"
.line	977	gettable     r10   r10    r9
.line	977	test         r10     0
.line	977	jmp            0   l56
.line	977	loadbool     r10     1     0
.line	977	return       r10     2
.label	l56
.line	977	move          r0    r0
.line	977	move          r0    r0
.label	l58
.line	977	loadbool      r4     0     0
.line	977	move          r5    r3
.line	977	return        r4     3
.line	977	return        r0     1
.line	977	move          r0    r0
.line	977	move          r0    r0
.line	977	return        r0     1

.function	main/f37

.source	null
.linedefined	1002
.lastlinedefined	1029
.numparams	2
.is_vararg	0
.maxstacksize	54

.upvalue	"_ENV"	0	false
.upvalue	"U1"	8	true
.upvalue	"U2"	1	true

.constant	k0	"AllLimitEmoteList"
.constant	k1	"ItemInTheRing"
.constant	k2	"EmoteImageArray"
.constant	k3	"Num"
.constant	k4	0
.constant	k5	"Get"
.constant	k6	"GetIsEmoteExist"
.constant	k7	"FLinearColor"
.constant	k8	0.49
.constant	k9	1.0
.constant	k10	"HSVToRGB"
.constant	k11	0.0
.constant	k12	0.2
.constant	k13	"CheckIsWearingEmoteLimitCloth"
.constant	k14	"require"
.constant	k15	"table"
.constant	k16	"concat"
.constant	k17	4
.constant	k18	80
.constant	k19	199
.constant	k20	102
.constant	k21	152
.constant	k22	212
.constant	k23	40
.constant	k24	24
.constant	k25	195
.constant	k26	110
.constant	k27	100
.constant	k28	222
.constant	k29	176
.constant	k30	114
.constant	k31	202
.constant	k32	210
.constant	k33	115
.constant	k34	163
.constant	k35	29
.constant	k36	99
.constant	k37	240
.constant	k38	84
.constant	k39	149
.constant	k40	208
.constant	k41	123
.constant	k42	35
.constant	k43	172
.constant	k44	136
.constant	k45	118
.constant	k46	201
.constant	k47	215
.constant	k48	112
.constant	k49	184
.constant	k50	13
.constant	k51	113
.constant	k52	236
.constant	k53	70
.constant	k54	98
.constant	k55	38
.constant	k56	31
.constant	k57	198
.constant	k58	108
.constant	k59	179
.constant	k60	200
.constant	k61	42
.constant	k62	105
.constant	k63	193
.constant	k64	101
.constant	k65	62
.constant	k66	247
.constant	k67	"CheckEmoteIsBan"
.constant	k68	"SetColorAndOpacity"

.line	1002	gettable      r2    r0    k0 ; k0 = "AllLimitEmoteList"
.line	1002	gettable      r2    r2    r1
.line	1002	test          r2     1
.line	1002	jmp            0    l6
.line	1002	return        r0     1
.label	l6
.line	1002	gettable      r2    r0    k1 ; k1 = "ItemInTheRing"
.line	1002	gettable      r2    r2    r1
.line	1002	test          r2     1
.line	1002	jmp            0   l11
.line	1002	return        r0     1
.label	l11
.line	1002	gettable      r3    r0    k2 ; k2 = "EmoteImageArray"
.line	1002	self          r3    r3    k3 ; k3 = "Num"
.line	1002	call          r3     2     2
.line	1002	lt             1    r2    k4 ; k4 = 0
.line	1002	jmp            0   l18
.line	1002	le             0    r3    r2
.line	1002	jmp            0   l19
.label	l18
.line	1002	return        r0     1
.label	l19
.line	1002	gettable      r4    r0    k2 ; k2 = "EmoteImageArray"
.line	1002	self          r4    r4    k5 ; k5 = "Get"
.line	1002	move          r6    r2
.line	1002	call          r4     3     2
.line	1002	self          r5    r0    k6 ; k6 = "GetIsEmoteExist"
.line	1002	move          r7    r1
.line	1002	call          r5     3     2
.line	1002	gettabup      r6    u0    k7 ; k7 = "FLinearColor"
.line	1002	loadk         r7    k8 ; k8 = 0.49
.line	1002	loadk         r8    k8 ; k8 = 0.49
.line	1002	loadk         r9    k8 ; k8 = 0.49
.line	1002	loadk        r10    k9 ; k9 = 1.0
.line	1002	call          r6     5     2
.line	1002	test          r5     0
.line	1002	jmp            0  l122
.line	1002	gettabup      r7    u1   k10 ; k10 = "HSVToRGB"
.line	1002	loadk         r8   k11 ; k11 = 0.0
.line	1002	loadk         r9   k11 ; k11 = 0.0
.line	1002	loadk        r10   k12 ; k12 = 0.2
.line	1002	loadk        r11    k9 ; k9 = 1.0
.line	1002	call          r7     5     2
.line	1002	gettabup      r8    u1   k10 ; k10 = "HSVToRGB"
.line	1002	loadk         r9   k11 ; k11 = 0.0
.line	1002	loadk        r10   k11 ; k11 = 0.0
.line	1002	loadk        r11    k9 ; k9 = 1.0
.line	1002	loadk        r12    k9 ; k9 = 1.0
.line	1002	call          r8     5     2
.line	1002	self          r9    r0   k13 ; k13 = "CheckIsWearingEmoteL" (truncated)
.line	1002	move         r11    r1
.line	1002	call          r9     3     2
.line	1002	gettabup     r10    u0   k14 ; k14 = "require"
.line	1002	gettabup     r11    u0   k15 ; k15 = "table"
.line	1002	gettable     r11   r11   k16 ; k16 = "concat"
.line	1002	newtable     r12     1     0
.line	1002	getupval     r13    u2
.line	1002	loadk        r14   k17 ; k17 = 4
.line	1002	loadk        r15   k18 ; k18 = 80
.line	1002	loadk        r16   k19 ; k19 = 199
.line	1002	loadk        r17   k20 ; k20 = 102
.line	1002	loadk        r18   k21 ; k21 = 152
.line	1002	loadk        r19   k22 ; k22 = 212
.line	1002	loadk        r20   k23 ; k23 = 40
.line	1002	loadk        r21   k24 ; k24 = 24
.line	1002	loadk        r22   k21 ; k21 = 152
.line	1002	loadk        r23   k25 ; k25 = 195
.line	1002	loadk        r24   k26 ; k26 = 110
.line	1002	loadk        r25   k27 ; k27 = 100
.line	1002	loadk        r26   k28 ; k28 = 222
.line	1002	loadk        r27   k29 ; k29 = 176
.line	1002	loadk        r28   k30 ; k30 = 114
.line	1002	loadk        r29   k31 ; k31 = 202
.line	1002	loadk        r30   k32 ; k32 = 210
.line	1002	loadk        r31   k33 ; k33 = 115
.line	1002	loadk        r32   k34 ; k34 = 163
.line	1002	loadk        r33   k35 ; k35 = 29
.line	1002	loadk        r34   k36 ; k36 = 99
.line	1002	loadk        r35   k37 ; k37 = 240
.line	1002	loadk        r36   k38 ; k38 = 84
.line	1002	loadk        r37   k36 ; k36 = 99
.line	1002	loadk        r38   k39 ; k39 = 149
.line	1002	loadk        r39   k40 ; k40 = 208
.line	1002	loadk        r40   k41 ; k41 = 123
.line	1002	loadk        r41   k42 ; k42 = 35
.line	1002	loadk        r42   k43 ; k43 = 172
.line	1002	loadk        r43   k44 ; k44 = 136
.line	1002	loadk        r44   k45 ; k45 = 118
.line	1002	loadk        r45   k46 ; k46 = 201
.line	1002	loadk        r46   k47 ; k47 = 215
.line	1002	loadk        r47   k48 ; k48 = 112
.line	1002	loadk        r48   k49 ; k49 = 184
.line	1002	loadk        r49   k50 ; k50 = 13
.line	1002	loadk        r50   k51 ; k51 = 113
.line	1002	loadk        r51   k52 ; k52 = 236
.line	1002	loadk        r52   k53 ; k53 = 70
.line	1002	loadk        r53   k54 ; k54 = 98
.line	1002	call         r13    41     2
.line	1002	getupval     r14    u2
.line	1002	loadk        r15   k55 ; k55 = 38
.line	1002	loadk        r16   k56 ; k56 = 31
.line	1002	loadk        r17   k57 ; k57 = 198
.line	1002	loadk        r18   k58 ; k58 = 108
.line	1002	loadk        r19   k59 ; k59 = 179
.line	1002	loadk        r20   k60 ; k60 = 200
.line	1002	loadk        r21   k61 ; k61 = 42
.line	1002	loadk        r22   k62 ; k62 = 105
.line	1002	loadk        r23   k29 ; k29 = 176
.line	1002	loadk        r24   k63 ; k63 = 193
.line	1002	loadk        r25   k64 ; k64 = 101
.line	1002	loadk        r26   k65 ; k65 = 62
.line	1002	loadk        r27   k66 ; k66 = 247
.line	1002	call         r14    14     0
.line	1002	setlist      r12     0     1
.line	1002	call         r11     2     2
.line	1002	call         r10     2     2
.line	1002	gettable     r11   r10   k67 ; k67 = "CheckEmoteIsBan"
.line	1002	move         r12    r1
.line	1002	call         r11     2     3
.line	1002	move          r6    r8
.line	1002	test          r9     0
.line	1002	jmp            0  l121
.line	1002	test         r11     0
.line	1002	jmp            0  l122
.label	l121
.line	1002	move          r6    r7
.label	l122
.line	1002	self          r7    r4   k68 ; k68 = "SetColorAndOpacity"
.line	1002	move          r9    r6
.line	1002	call          r7     3     1
.line	1002	return        r0     1
.line	1002	move          r0    r0
.line	1002	return        r0     1

.function	main/f38

.source	null
.linedefined	1031
.lastlinedefined	1037
.numparams	1
.is_vararg	0
.maxstacksize	14

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"slua_GameFrontendHUD"
.constant	k1	"GetGameState"
.constant	k2	"slua"
.constant	k3	"isValid"
.constant	k4	"GetGameModeState"
.constant	k5	17
.constant	k6	84
.constant	k7	203
.constant	k8	103
.constant	k9	173
.constant	k10	242
.constant	k11	61
.constant	k12	87
.constant	k13	161
.constant	k14	201

.line	1031	gettabup      r1    u0    k0 ; k0 = "slua_GameFrontendHUD"
.line	1031	self          r1    r1    k1 ; k1 = "GetGameState"
.line	1031	call          r1     2     2
.line	1031	gettabup      r2    u0    k2 ; k2 = "slua"
.line	1031	gettable      r2    r2    k3 ; k3 = "isValid"
.line	1031	move          r3    r1
.line	1031	call          r2     2     2
.line	1031	test          r2     0
.line	1031	jmp            0   l13
.line	1031	gettable      r2    r1    k4 ; k4 = "GetGameModeState"
.line	1031	test          r2     1
.line	1031	jmp            0   l15
.label	l13
.line	1031	loadbool      r2     0     0
.line	1031	return        r2     2
.label	l15
.line	1031	self          r2    r1    k4 ; k4 = "GetGameModeState"
.line	1031	call          r2     2     2
.line	1031	getupval      r3    u1
.line	1031	loadk         r4    k5 ; k5 = 17
.line	1031	loadk         r5    k6 ; k6 = 84
.line	1031	loadk         r6    k7 ; k7 = 203
.line	1031	loadk         r7    k8 ; k8 = 103
.line	1031	loadk         r8    k9 ; k9 = 173
.line	1031	loadk         r9   k10 ; k10 = 242
.line	1031	loadk        r10   k11 ; k11 = 61
.line	1031	loadk        r11   k12 ; k12 = 87
.line	1031	loadk        r12   k13 ; k13 = 161
.line	1031	loadk        r13   k14 ; k14 = 201
.line	1031	call          r3    11     2
.line	1031	eq             1    r2    r3
.line	1031	jmp            0   l32
.line	1031	loadbool      r2     0     1
.label	l32
.line	1031	loadbool      r2     1     0
.line	1031	return        r2     2
.line	1031	return        r0     1
.line	1031	move          r0    r0
.line	1031	move          r0    r0
.line	1031	move          r0    r0
.line	1031	move          r0    r0
.line	1031	return        r0     1

.function	main/f39

.source	null
.linedefined	1039
.lastlinedefined	1041
.numparams	2
.is_vararg	0
.maxstacksize	3

.line	1039	loadbool      r2     1     0
.line	1039	return        r2     2
.line	1039	return        r0     1
.line	1039	move          r0    r0
.line	1039	return        r0     1

.function	main/f40

.source	null
.linedefined	1043
.lastlinedefined	1045
.numparams	1
.is_vararg	0
.maxstacksize	4

.constant	k0	"ShowOrHideRing"

.line	1043	self          r1    r0    k0 ; k0 = "ShowOrHideRing"
.line	1043	loadbool      r3     0     0
.line	1043	call          r1     3     1
.line	1043	return        r0     1
.line	1043	move          r0    r0
.line	1043	move          r0    r0
.line	1043	move          r0    r0
.line	1043	move          r0    r0
.line	1043	return        r0     1

.function	main/f41

.source	null
.linedefined	1047
.lastlinedefined	1051
.numparams	2
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	3	true

.constant	k0	"ItemDefineIDTemp"
.constant	k1	"Type"
.constant	k2	22
.constant	k3	"TypeSpecificID"
.constant	k4	"IsBattleItemHandleExist"

.line	1047	gettable      r2    r0    k0 ; k0 = "ItemDefineIDTemp"
.line	1047	settable      r2    k1    k2 ; k2 = 22
.line	1047	gettable      r2    r0    k0 ; k0 = "ItemDefineIDTemp"
.line	1047	settable      r2    k3    r1 ; k3 = "TypeSpecificID"
.line	1047	gettabup      r2    u0    k4 ; k4 = "IsBattleItemHandleEx" (truncated)
.line	1047	gettable      r3    r0    k0 ; k0 = "ItemDefineIDTemp"
.line	1047	loadbool      r4     1     0
.line	1047	loadbool      r5     0     0
.line	1047	loadbool      r6     0     0
.line	1047	tailcall      r2     5
.line	1047	return        r2     0
.line	1047	return        r0     1
.line	1047	move          r0    r0
.line	1047	return        r0     1

.function	main/f42

.source	null
.linedefined	1053
.lastlinedefined	1090
.numparams	2
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	6	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	22	true
.upvalue	"U4"	23	true

.constant	k0	"PlayAudio"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	108
.constant	k4	118
.constant	k5	203
.constant	k6	110
.constant	k7	177
.constant	k8	142
.constant	k9	30
.constant	k10	65
.constant	k11	188
.constant	k12	223
.constant	k13	111
.constant	k14	15
.constant	k15	228
.constant	k16	126
.constant	k17	204
.constant	k18	156
.constant	k19	84
.constant	k20	147
.constant	k21	76
.constant	k22	240
.constant	k23	85
.constant	k24	106
.constant	k25	234
.constant	k26	236
.constant	k27	59
.constant	k28	251
.constant	k29	150
.constant	k30	225
.constant	k31	252
.constant	k32	114
.constant	k33	166
.constant	k34	74
.constant	k35	87
.constant	k36	27
.constant	k37	56
.constant	k38	19
.constant	k39	93
.constant	k40	122
.constant	k41	139
.constant	k42	244
.constant	k43	0
.constant	k44	105
.constant	k45	182
.constant	k46	192
.constant	k47	99
.constant	k48	41
.constant	k49	249
.constant	k50	235
.constant	k51	"ChangeAvatarFormCDTimer"
.constant	k52	"RemoveTimer"
.constant	k53	nil
.constant	k54	"bXSuitTailButton"
.constant	k55	false
.constant	k56	"XSuitTailButtonIcon"
.constant	k57	"RefreshXSuitTailRedPoint"
.constant	k58	"CurrentShowState"
.constant	k59	"None"
.constant	k60	"LastShowState"
.constant	k61	"print"
.constant	k62	"bWriteLog"
.constant	k63	18
.constant	k64	68
.constant	k65	195
.constant	k66	96
.constant	k67	191
.constant	k68	49
.constant	k69	70
.constant	k70	167
.constant	k71	201
.constant	k72	121
.constant	k73	57
.constant	k74	130
.constant	k75	224
.constant	k76	181
.constant	k77	107
.constant	k78	227
.constant	k79	113
.constant	k80	161
.constant	k81	217
.constant	k82	72
.constant	k83	51
.constant	k84	174
.constant	k85	32
.constant	k86	194
.constant	k87	98
.constant	k88	190
.constant	k89	112
.constant	k90	92
.constant	k91	238
.constant	k92	94
.constant	k93	69
.constant	k94	55
.constant	k95	80
.constant	k96	222
.constant	k97	102
.constant	k98	37
.constant	k99	89
.constant	k100	"IsHide"
.constant	k101	"CanvasPanel_Root"
.constant	k102	"SetWidgetVisibility"
.constant	k103	"UEnums"
.constant	k104	"ESlateVisibility"
.constant	k105	"Collapsed"
.constant	k106	"slua_GameFrontendHUD"
.constant	k107	"GetPlayerController"
.constant	k108	"slua"
.constant	k109	"isValid"
.constant	k110	"CastUIMsg"
.constant	k111	22
.constant	k112	120
.constant	k113	231
.constant	k114	179
.constant	k115	254
.constant	k116	10
.constant	k117	90
.constant	k118	186
.constant	k119	176
.constant	k120	115
.constant	k121	211
.constant	k122	246
.constant	k123	170
.constant	k124	226
.constant	k125	210
.constant	k126	42
.constant	k127	95
.constant	k128	205
.constant	k129	185
.constant	k130	196
.constant	k131	"RefreshTransformButton"
.constant	k132	"Expression"
.constant	k133	206
.constant	k134	83
.constant	k135	187
.constant	k136	"SelfHitTestInvisible"
.constant	k137	"ED_QuickExpressBtnClick"
.constant	k138	"BroadCast"
.constant	k139	"EventSystem"
.constant	k140	"postEvent"
.constant	k141	"EVENTTYPE_INGAME"
.constant	k142	"EVENTID_INGAME_QUICK_EXPRESSION_CLICK"
.constant	k143	"GetEmoteImagePalthMap"
.constant	k144	"RefreshCirclePanel"
.constant	k145	"PlayUserWidgetAnimation"
.constant	k146	"open"
.constant	k147	1

.line	1053	gettabup      r2    u0    k0 ; k0 = "PlayAudio"
.line	1053	gettabup      r3    u1    k1 ; k1 = "table"
.line	1053	gettable      r3    r3    k2 ; k2 = "concat"
.line	1053	newtable      r4     1     0
.line	1053	getupval      r5    u2
.line	1053	loadk         r6    k3 ; k3 = 108
.line	1053	loadk         r7    k4 ; k4 = 118
.line	1053	loadk         r8    k5 ; k5 = 203
.line	1053	loadk         r9    k6 ; k6 = 110
.line	1053	loadk        r10    k7 ; k7 = 177
.line	1053	loadk        r11    k8 ; k8 = 142
.line	1053	loadk        r12    k9 ; k9 = 30
.line	1053	loadk        r13   k10 ; k10 = 65
.line	1053	loadk        r14   k11 ; k11 = 188
.line	1053	loadk        r15   k12 ; k12 = 223
.line	1053	loadk        r16   k13 ; k13 = 111
.line	1053	loadk        r17   k14 ; k14 = 15
.line	1053	loadk        r18   k15 ; k15 = 228
.line	1053	loadk        r19   k11 ; k11 = 188
.line	1053	loadk        r20   k16 ; k16 = 126
.line	1053	loadk        r21   k17 ; k17 = 204
.line	1053	loadk        r22   k18 ; k18 = 156
.line	1053	loadk        r23   k19 ; k19 = 84
.line	1053	loadk        r24   k20 ; k20 = 147
.line	1053	loadk        r25    k3 ; k3 = 108
.line	1053	loadk        r26   k21 ; k21 = 76
.line	1053	loadk        r27   k22 ; k22 = 240
.line	1053	loadk        r28   k23 ; k23 = 85
.line	1053	loadk        r29   k24 ; k24 = 106
.line	1053	loadk        r30   k25 ; k25 = 234
.line	1053	loadk        r31   k26 ; k26 = 236
.line	1053	loadk        r32    k4 ; k4 = 118
.line	1053	loadk        r33   k27 ; k27 = 59
.line	1053	loadk        r34   k28 ; k28 = 251
.line	1053	loadk        r35   k29 ; k29 = 150
.line	1053	loadk        r36   k23 ; k23 = 85
.line	1053	loadk        r37   k30 ; k30 = 225
.line	1053	loadk        r38   k31 ; k31 = 252
.line	1053	loadk        r39   k32 ; k32 = 114
.line	1053	loadk        r40   k33 ; k33 = 166
.line	1053	loadk        r41   k34 ; k34 = 74
.line	1053	loadk        r42   k35 ; k35 = 87
.line	1053	loadk        r43   k25 ; k25 = 234
.line	1053	loadk        r44   k36 ; k36 = 27
.line	1053	loadk        r45   k37 ; k37 = 56
.line	1053	call          r5    41     2
.line	1053	getupval      r6    u2
.line	1053	loadk         r7   k38 ; k38 = 19
.line	1053	loadk         r8   k39 ; k39 = 93
.line	1053	loadk         r9    k5 ; k5 = 203
.line	1053	loadk        r10   k40 ; k40 = 122
.line	1053	loadk        r11   k41 ; k41 = 139
.line	1053	loadk        r12   k42 ; k42 = 244
.line	1053	loadk        r13   k43 ; k43 = 0
.line	1053	loadk        r14   k44 ; k44 = 105
.line	1053	loadk        r15   k45 ; k45 = 182
.line	1053	loadk        r16   k46 ; k46 = 192
.line	1053	loadk        r17   k47 ; k47 = 99
.line	1053	loadk        r18   k48 ; k48 = 41
.line	1053	loadk        r19   k49 ; k49 = 249
.line	1053	loadk        r20   k50 ; k50 = 235
.line	1053	call          r6    15     0
.line	1053	setlist       r4     0     1
.line	1053	call          r3     2     2
.line	1053	call          r2     2     1
.line	1053	test          r1     1
.line	1053	jmp            0  l223
.line	1053	gettable      r2    r0   k51 ; k51 = "ChangeAvatarFormCDTi" (truncated)
.line	1053	test          r2     0
.line	1053	jmp            0   l75
.line	1053	self          r2    r0   k52 ; k52 = "RemoveTimer"
.line	1053	gettable      r4    r0   k51 ; k51 = "ChangeAvatarFormCDTi" (truncated)
.line	1053	call          r2     3     1
.line	1053	settable      r0   k51   k53 ; k53 = nil
.label	l75
.line	1053	settable      r0   k54   k55 ; k55 = false
.line	1053	settable      r0   k56   k53 ; k53 = nil
.line	1053	gettabup      r2    u3   k57 ; k57 = "RefreshXSuitTailRedP" (truncated)
.line	1053	move          r3    r0
.line	1053	loadbool      r4     0     0
.line	1053	call          r2     3     1
.line	1053	gettable      r2    r0   k58 ; k58 = "CurrentShowState"
.line	1053	gettabup      r3    u4   k59 ; k59 = "None"
.line	1053	eq             0    r2    r3
.line	1053	jmp            0   l86
.line	1053	return        r0     1
.label	l86
.line	1053	gettable      r2    r0   k58 ; k58 = "CurrentShowState"
.line	1053	settable      r0   k60    r2 ; k60 = "LastShowState"
.line	1053	gettabup      r2    u4   k59 ; k59 = "None"
.line	1053	settable      r0   k58    r2 ; k58 = "CurrentShowState"
.line	1053	gettabup      r2    u1   k61 ; k61 = "print"
.line	1053	gettabup      r3    u1   k62 ; k62 = "bWriteLog"
.line	1053	test          r3     0
.line	1053	jmp            0  l153
.line	1053	gettabup      r3    u1    k1 ; k1 = "table"
.line	1053	gettable      r3    r3    k2 ; k2 = "concat"
.line	1053	newtable      r4     1     0
.line	1053	getupval      r5    u2
.line	1053	loadk         r6   k63 ; k63 = 18
.line	1053	loadk         r7   k64 ; k64 = 68
.line	1053	loadk         r8   k65 ; k65 = 195
.line	1053	loadk         r9   k66 ; k66 = 96
.line	1053	loadk        r10   k67 ; k67 = 191
.line	1053	loadk        r11   k15 ; k15 = 228
.line	1053	loadk        r12   k68 ; k68 = 49
.line	1053	loadk        r13   k69 ; k69 = 70
.line	1053	loadk        r14   k70 ; k70 = 167
.line	1053	loadk        r15   k71 ; k71 = 201
.line	1053	loadk        r16   k72 ; k72 = 121
.line	1053	loadk        r17   k73 ; k73 = 57
.line	1053	loadk        r18   k28 ; k28 = 251
.line	1053	loadk        r19   k45 ; k45 = 182
.line	1053	loadk        r20   k16 ; k16 = 126
.line	1053	loadk        r21   k74 ; k74 = 130
.line	1053	loadk        r22   k75 ; k75 = 224
.line	1053	loadk        r23   k44 ; k44 = 105
.line	1053	loadk        r24   k76 ; k76 = 181
.line	1053	loadk        r25   k64 ; k64 = 68
.line	1053	loadk        r26   k77 ; k77 = 107
.line	1053	loadk        r27   k78 ; k78 = 227
.line	1053	loadk        r28   k79 ; k79 = 113
.line	1053	loadk        r29   k13 ; k13 = 111
.line	1053	loadk        r30   k80 ; k80 = 161
.line	1053	loadk        r31   k81 ; k81 = 217
.line	1053	loadk        r32   k82 ; k82 = 72
.line	1053	loadk        r33   k83 ; k83 = 51
.line	1053	loadk        r34   k26 ; k26 = 236
.line	1053	loadk        r35   k84 ; k84 = 174
.line	1053	loadk        r36   k85 ; k85 = 32
.line	1053	loadk        r37   k15 ; k15 = 228
.line	1053	loadk        r38   k86 ; k86 = 194
.line	1053	loadk        r39   k87 ; k87 = 98
.line	1053	loadk        r40   k88 ; k88 = 190
.line	1053	loadk        r41   k89 ; k89 = 112
.line	1053	loadk        r42   k90 ; k90 = 92
.line	1053	loadk        r43   k91 ; k91 = 238
.line	1053	loadk        r44   k92 ; k92 = 94
.line	1053	loadk        r45   k93 ; k93 = 69
.line	1053	call          r5    41     2
.line	1053	getupval      r6    u2
.line	1053	loadk         r7   k94 ; k94 = 55
.line	1053	loadk         r8   k95 ; k95 = 80
.line	1053	loadk         r9   k96 ; k96 = 222
.line	1053	loadk        r10   k97 ; k97 = 102
.line	1053	loadk        r11   k42 ; k42 = 244
.line	1053	loadk        r12   k86 ; k86 = 194
.line	1053	loadk        r13   k98 ; k98 = 37
.line	1053	loadk        r14   k99 ; k99 = 89
.line	1053	loadk        r15   k33 ; k33 = 166
.line	1053	loadk        r16   k71 ; k71 = 201
.line	1053	call          r6    11     0
.line	1053	setlist       r4     0     1
.line	1053	call          r3     2     2
.label	l153
.line	1053	gettable      r4    r0   k60 ; k60 = "LastShowState"
.line	1053	gettable      r5    r0   k58 ; k58 = "CurrentShowState"
.line	1053	call          r2     4     1
.line	1053	self          r2    r0  k100 ; k100 = "IsHide"
.line	1053	call          r2     2     2
.line	1053	test          r2     0
.line	1053	jmp            0  l161
.line	1053	return        r0     1
.label	l161
.line	1053	gettable      r2    r0  k101 ; k101 = "CanvasPanel_Root"
.line	1053	self          r2    r2  k102 ; k102 = "SetWidgetVisibility"
.line	1053	gettabup      r4    u1  k103 ; k103 = "UEnums"
.line	1053	gettable      r4    r4  k104 ; k104 = "ESlateVisibility"
.line	1053	gettable      r4    r4  k105 ; k105 = "Collapsed"
.line	1053	call          r2     3     1
.line	1053	gettabup      r2    u1  k106 ; k106 = "slua_GameFrontendHUD"
.line	1053	self          r2    r2  k107 ; k107 = "GetPlayerController"
.line	1053	call          r2     2     2
.line	1053	eq             1    r2   k53 ; k53 = nil
.line	1053	jmp            0  l220
.line	1053	gettabup      r3    u1  k108 ; k108 = "slua"
.line	1053	gettable      r3    r3  k109 ; k109 = "isValid"
.line	1053	move          r4    r2
.line	1053	call          r3     2     2
.line	1053	test          r3     0
.line	1053	jmp            0  l220
.line	1053	self          r3    r2  k110 ; k110 = "CastUIMsg"
.line	1053	getupval      r5    u2
.line	1053	loadk         r6  k111 ; k111 = 22
.line	1053	loadk         r7  k112 ; k112 = 120
.line	1053	loadk         r8  k113 ; k113 = 231
.line	1053	loadk         r9   k89 ; k89 = 112
.line	1053	loadk        r10  k114 ; k114 = 179
.line	1053	loadk        r11  k115 ; k115 = 254
.line	1053	loadk        r12  k116 ; k116 = 10
.line	1053	loadk        r13  k117 ; k117 = 90
.line	1053	loadk        r14  k118 ; k118 = 186
.line	1053	loadk        r15   k12 ; k12 = 223
.line	1053	loadk        r16   k13 ; k13 = 111
.line	1053	loadk        r17   k36 ; k36 = 27
.line	1053	loadk        r18  k113 ; k113 = 231
.line	1053	loadk        r19  k119 ; k119 = 176
.line	1053	loadk        r20  k120 ; k120 = 115
.line	1053	loadk        r21  k121 ; k121 = 211
.line	1053	loadk        r22  k122 ; k122 = 246
.line	1053	loadk        r23   k72 ; k72 = 121
.line	1053	loadk        r24  k123 ; k123 = 170
.line	1053	loadk        r25   k10 ; k10 = 65
.line	1053	loadk        r26   k10 ; k10 = 65
.line	1053	loadk        r27  k124 ; k124 = 226
.line	1053	loadk        r28   k34 ; k34 = 74
.line	1053	loadk        r29   k13 ; k13 = 111
.line	1053	loadk        r30  k123 ; k123 = 170
.line	1053	loadk        r31  k125 ; k125 = 210
.line	1053	loadk        r32   k82 ; k82 = 72
.line	1053	loadk        r33   k83 ; k83 = 51
.line	1053	loadk        r34   k26 ; k26 = 236
.line	1053	loadk        r35   k84 ; k84 = 174
.line	1053	call          r5    31     2
.line	1053	getupval      r6    u2
.line	1053	loadk         r7  k126 ; k126 = 42
.line	1053	loadk         r8  k127 ; k127 = 95
.line	1053	loadk         r9  k128 ; k128 = 205
.line	1053	loadk        r10   k87 ; k87 = 98
.line	1053	loadk        r11  k129 ; k129 = 185
.line	1053	loadk        r12  k130 ; k130 = 196
.line	1053	call          r6     7     2
.line	1053	call          r3     4     1
.label	l220
.line	1053	self          r3    r0  k131 ; k131 = "RefreshTransformButt" (truncated)
.line	1053	call          r3     2     1
.line	1053	return        r0     1
.label	l223
.line	1053	gettable      r2    r0   k60 ; k60 = "LastShowState"
.line	1053	test          r2     1
.line	1053	jmp            0  l227
.line	1053	gettabup      r2    u4  k132 ; k132 = "Expression"
.label	l227
.line	1053	settable      r0   k58    r2 ; k58 = "CurrentShowState"
.line	1053	gettabup      r2    u1   k61 ; k61 = "print"
.line	1053	gettabup      r3    u1   k62 ; k62 = "bWriteLog"
.line	1053	test          r3     0
.line	1053	jmp            0  l290
.line	1053	gettabup      r3    u1    k1 ; k1 = "table"
.line	1053	gettable      r3    r3    k2 ; k2 = "concat"
.line	1053	newtable      r4     1     0
.line	1053	getupval      r5    u2
.line	1053	loadk         r6   k63 ; k63 = 18
.line	1053	loadk         r7   k64 ; k64 = 68
.line	1053	loadk         r8   k65 ; k65 = 195
.line	1053	loadk         r9   k66 ; k66 = 96
.line	1053	loadk        r10   k67 ; k67 = 191
.line	1053	loadk        r11   k15 ; k15 = 228
.line	1053	loadk        r12   k68 ; k68 = 49
.line	1053	loadk        r13   k69 ; k69 = 70
.line	1053	loadk        r14   k70 ; k70 = 167
.line	1053	loadk        r15   k71 ; k71 = 201
.line	1053	loadk        r16   k72 ; k72 = 121
.line	1053	loadk        r17   k73 ; k73 = 57
.line	1053	loadk        r18   k28 ; k28 = 251
.line	1053	loadk        r19   k45 ; k45 = 182
.line	1053	loadk        r20   k16 ; k16 = 126
.line	1053	loadk        r21   k74 ; k74 = 130
.line	1053	loadk        r22   k75 ; k75 = 224
.line	1053	loadk        r23   k44 ; k44 = 105
.line	1053	loadk        r24   k76 ; k76 = 181
.line	1053	loadk        r25   k64 ; k64 = 68
.line	1053	loadk        r26   k77 ; k77 = 107
.line	1053	loadk        r27   k78 ; k78 = 227
.line	1053	loadk        r28   k79 ; k79 = 113
.line	1053	loadk        r29   k13 ; k13 = 111
.line	1053	loadk        r30   k80 ; k80 = 161
.line	1053	loadk        r31   k81 ; k81 = 217
.line	1053	loadk        r32   k82 ; k82 = 72
.line	1053	loadk        r33   k83 ; k83 = 51
.line	1053	loadk        r34   k26 ; k26 = 236
.line	1053	loadk        r35   k84 ; k84 = 174
.line	1053	loadk        r36   k85 ; k85 = 32
.line	1053	loadk        r37   k15 ; k15 = 228
.line	1053	loadk        r38   k86 ; k86 = 194
.line	1053	loadk        r39   k87 ; k87 = 98
.line	1053	loadk        r40   k88 ; k88 = 190
.line	1053	loadk        r41   k89 ; k89 = 112
.line	1053	loadk        r42   k90 ; k90 = 92
.line	1053	loadk        r43   k91 ; k91 = 238
.line	1053	loadk        r44   k92 ; k92 = 94
.line	1053	loadk        r45   k93 ; k93 = 69
.line	1053	call          r5    41     2
.line	1053	getupval      r6    u2
.line	1053	loadk         r7   k94 ; k94 = 55
.line	1053	loadk         r8   k95 ; k95 = 80
.line	1053	loadk         r9   k96 ; k96 = 222
.line	1053	loadk        r10   k97 ; k97 = 102
.line	1053	loadk        r11   k42 ; k42 = 244
.line	1053	loadk        r12  k133 ; k133 = 206
.line	1053	loadk        r13   k73 ; k73 = 57
.line	1053	loadk        r14  k134 ; k134 = 83
.line	1053	loadk        r15  k135 ; k135 = 187
.line	1053	call          r6    10     0
.line	1053	setlist       r4     0     1
.line	1053	call          r3     2     2
.label	l290
.line	1053	gettable      r4    r0   k60 ; k60 = "LastShowState"
.line	1053	gettable      r5    r0   k58 ; k58 = "CurrentShowState"
.line	1053	call          r2     4     1
.line	1053	gettable      r2    r0  k101 ; k101 = "CanvasPanel_Root"
.line	1053	self          r2    r2  k102 ; k102 = "SetWidgetVisibility"
.line	1053	gettabup      r4    u1  k103 ; k103 = "UEnums"
.line	1053	gettable      r4    r4  k104 ; k104 = "ESlateVisibility"
.line	1053	gettable      r4    r4  k136 ; k136 = "SelfHitTestInvisible"
.line	1053	call          r2     3     1
.line	1053	gettable      r2    r0  k137 ; k137 = "ED_QuickExpressBtnCl" (truncated)
.line	1053	test          r2     0
.line	1053	jmp            0  l305
.line	1053	gettable      r2    r0  k137 ; k137 = "ED_QuickExpressBtnCl" (truncated)
.line	1053	self          r2    r2  k138 ; k138 = "BroadCast"
.line	1053	call          r2     2     1
.label	l305
.line	1053	gettabup      r2    u1  k139 ; k139 = "EventSystem"
.line	1053	self          r2    r2  k140 ; k140 = "postEvent"
.line	1053	gettabup      r4    u1  k141 ; k141 = "EVENTTYPE_INGAME"
.line	1053	gettabup      r5    u1  k142 ; k142 = "EVENTID_INGAME_QUICK" (truncated)
.line	1053	call          r2     4     1
.line	1053	self          r2    r0  k143 ; k143 = "GetEmoteImagePalthMa" (truncated)
.line	1053	call          r2     2     1
.line	1053	self          r2    r0  k144 ; k144 = "RefreshCirclePanel"
.line	1053	call          r2     2     1
.line	1053	self          r2    r0  k145 ; k145 = "PlayUserWidgetAnimat" (truncated)
.line	1053	gettable      r4    r0  k146 ; k146 = "open"
.line	1053	loadk         r5   k43 ; k43 = 0
.line	1053	loadk         r6  k147 ; k147 = 1
.line	1053	loadk         r7   k43 ; k43 = 0
.line	1053	loadk         r8  k147 ; k147 = 1
.line	1053	call          r2     7     1
.line	1053	return        r0     1
.line	1053	move          r0    r0
.line	1053	move          r0    r0
.line	1053	move          r0    r0
.line	1053	move          r0    r0
.line	1053	return        r0     1

.function	main/f43

.source	null
.linedefined	1092
.lastlinedefined	1094
.numparams	1
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	0	false

.constant	k0	"CanvasPanel_Root"
.constant	k1	"GetVisibility"
.constant	k2	"UEnums"
.constant	k3	"ESlateVisibility"
.constant	k4	"Collapsed"

.line	1092	gettable      r1    r0    k0 ; k0 = "CanvasPanel_Root"
.line	1092	self          r1    r1    k1 ; k1 = "GetVisibility"
.line	1092	call          r1     2     2
.line	1092	gettabup      r2    u0    k2 ; k2 = "UEnums"
.line	1092	gettable      r2    r2    k3 ; k3 = "ESlateVisibility"
.line	1092	gettable      r2    r2    k4 ; k4 = "Collapsed"
.line	1092	eq             1    r1    r2
.line	1092	jmp            0   l10
.line	1092	loadbool      r1     0     1
.label	l10
.line	1092	loadbool      r1     1     0
.line	1092	return        r1     2
.line	1092	return        r0     1
.line	1092	move          r0    r0
.line	1092	move          r0    r0
.line	1092	move          r0    r0
.line	1092	return        r0     1

.function	main/f44

.source	null
.linedefined	1096
.lastlinedefined	1104
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	24
.constant	k5	117
.constant	k6	207
.constant	k7	98
.constant	k8	186
.constant	k9	235
.constant	k10	16
.constant	k11	136
.constant	k12	140
.constant	k13	91
.constant	k14	63
.constant	k15	251
.constant	k16	123
.constant	k17	253
.constant	k18	203
.constant	k19	113
.constant	k20	168
.constant	k21	86
.constant	k22	87
.constant	k23	226
.constant	k24	80
.constant	k25	105
.constant	k26	171
.constant	k27	134
.constant	k28	92
.constant	k29	227
.constant	k30	189
.constant	k31	218
.constant	k32	198
.constant	k33	83
.constant	k34	191
.constant	k35	64
.constant	k36	238
.constant	k37	71
.constant	k38	68
.constant	k39	38
.constant	k40	216
.constant	k41	102
.constant	k42	167
.constant	k43	201
.constant	k44	"RefreshCheckGunBtnState"
.constant	k45	"RefreshChangeAvatarFormBtnState"
.constant	k46	"RefreshTransformButton"
.constant	k47	"RefreshSelfieButton"
.constant	k48	"RefreshPetButton"
.constant	k49	"RefreshXSuitEmoteButton"

.line	1096	gettabup      r1    u0    k0 ; k0 = "log"
.line	1096	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1096	test          r2     0
.line	1096	jmp            0   l60
.line	1096	gettabup      r2    u0    k2 ; k2 = "table"
.line	1096	gettable      r2    r2    k3 ; k3 = "concat"
.line	1096	newtable      r3     1     0
.line	1096	getupval      r4    u1
.line	1096	loadk         r5    k4 ; k4 = 24
.line	1096	loadk         r6    k5 ; k5 = 117
.line	1096	loadk         r7    k6 ; k6 = 207
.line	1096	loadk         r8    k7 ; k7 = 98
.line	1096	loadk         r9    k8 ; k8 = 186
.line	1096	loadk        r10    k9 ; k9 = 235
.line	1096	loadk        r11   k10 ; k10 = 16
.line	1096	loadk        r12    k7 ; k7 = 98
.line	1096	loadk        r13   k11 ; k11 = 136
.line	1096	loadk        r14   k12 ; k12 = 140
.line	1096	loadk        r15   k13 ; k13 = 91
.line	1096	loadk        r16   k14 ; k14 = 63
.line	1096	loadk        r17   k15 ; k15 = 251
.line	1096	loadk        r18    k8 ; k8 = 186
.line	1096	loadk        r19   k16 ; k16 = 123
.line	1096	loadk        r20   k17 ; k17 = 253
.line	1096	loadk        r21   k18 ; k18 = 203
.line	1096	loadk        r22   k19 ; k19 = 113
.line	1096	loadk        r23   k20 ; k20 = 168
.line	1096	loadk        r24   k21 ; k21 = 86
.line	1096	loadk        r25   k22 ; k22 = 87
.line	1096	loadk        r26   k23 ; k23 = 226
.line	1096	loadk        r27   k24 ; k24 = 80
.line	1096	loadk        r28   k25 ; k25 = 105
.line	1096	loadk        r29   k26 ; k26 = 171
.line	1096	loadk        r30   k27 ; k27 = 134
.line	1096	loadk        r31   k28 ; k28 = 92
.line	1096	loadk        r32   k14 ; k14 = 63
.line	1096	loadk        r33   k29 ; k29 = 227
.line	1096	loadk        r34   k30 ; k30 = 189
.line	1096	loadk        r35    k5 ; k5 = 117
.line	1096	loadk        r36   k31 ; k31 = 218
.line	1096	loadk        r37   k32 ; k32 = 198
.line	1096	loadk        r38   k33 ; k33 = 83
.line	1096	loadk        r39   k34 ; k34 = 191
.line	1096	loadk        r40   k22 ; k22 = 87
.line	1096	loadk        r41   k35 ; k35 = 64
.line	1096	loadk        r42   k36 ; k36 = 238
.line	1096	loadk        r43   k37 ; k37 = 71
.line	1096	loadk        r44   k38 ; k38 = 68
.line	1096	call          r4    41     2
.line	1096	getupval      r5    u1
.line	1096	loadk         r6   k39 ; k39 = 38
.line	1096	loadk         r7   k22 ; k22 = 87
.line	1096	loadk         r8   k40 ; k40 = 216
.line	1096	loadk         r9   k41 ; k41 = 102
.line	1096	loadk        r10   k42 ; k42 = 167
.line	1096	loadk        r11   k43 ; k43 = 201
.line	1096	call          r5     7     0
.line	1096	setlist       r3     0     1
.line	1096	call          r2     2     2
.label	l60
.line	1096	call          r1     2     1
.line	1096	self          r1    r0   k44 ; k44 = "RefreshCheckGunBtnSt" (truncated)
.line	1096	call          r1     2     1
.line	1096	self          r1    r0   k45 ; k45 = "RefreshChangeAvatarF" (truncated)
.line	1096	call          r1     2     1
.line	1096	self          r1    r0   k46 ; k46 = "RefreshTransformButt" (truncated)
.line	1096	call          r1     2     1
.line	1096	self          r1    r0   k47 ; k47 = "RefreshSelfieButton"
.line	1096	call          r1     2     1
.line	1096	self          r1    r0   k48 ; k48 = "RefreshPetButton"
.line	1096	call          r1     2     1
.line	1096	self          r1    r0   k49 ; k49 = "RefreshXSuitEmoteBut" (truncated)
.line	1096	call          r1     2     1
.line	1096	return        r0     1
.line	1096	move          r0    r0
.line	1096	move          r0    r0
.line	1096	move          r0    r0
.line	1096	move          r0    r0
.line	1096	return        r0     1

.function	main/f45

.source	null
.linedefined	1106
.lastlinedefined	1133
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	4
.constant	k4	80
.constant	k5	199
.constant	k6	102
.constant	k7	152
.constant	k8	212
.constant	k9	40
.constant	k10	24
.constant	k11	195
.constant	k12	110
.constant	k13	100
.constant	k14	222
.constant	k15	176
.constant	k16	114
.constant	k17	202
.constant	k18	210
.constant	k19	115
.constant	k20	163
.constant	k21	29
.constant	k22	99
.constant	k23	240
.constant	k24	84
.constant	k25	149
.constant	k26	208
.constant	k27	123
.constant	k28	35
.constant	k29	172
.constant	k30	136
.constant	k31	118
.constant	k32	201
.constant	k33	215
.constant	k34	112
.constant	k35	184
.constant	k36	13
.constant	k37	113
.constant	k38	236
.constant	k39	70
.constant	k40	98
.constant	k41	38
.constant	k42	31
.constant	k43	198
.constant	k44	108
.constant	k45	179
.constant	k46	200
.constant	k47	42
.constant	k48	105
.constant	k49	193
.constant	k50	101
.constant	k51	62
.constant	k52	247
.constant	k53	"bCustomWeaponShow"
.constant	k54	"WidgetSwitcher_Check"
.constant	k55	"SetActiveWidgetIndex"
.constant	k56	1
.constant	k57	0
.constant	k58	"GetCurrentCheckGunState"
.constant	k59	"print"
.constant	k60	"bWriteLog"
.constant	k61	18
.constant	k62	68
.constant	k63	96
.constant	k64	191
.constant	k65	228
.constant	k66	49
.constant	k67	167
.constant	k68	121
.constant	k69	57
.constant	k70	251
.constant	k71	182
.constant	k72	126
.constant	k73	130
.constant	k74	225
.constant	k75	188
.constant	k76	65
.constant	k77	226
.constant	k78	81
.constant	k79	69
.constant	k80	173
.constant	k81	217
.constant	k82	197
.constant	k83	234
.constant	k84	127
.constant	k85	153
.constant	k86	87
.constant	k87	85
.constant	k88	245
.constant	k89	76
.constant	k90	"HalfAlpha_LColor"
.constant	k91	nil
.constant	k92	"FLinearColor"
.constant	k93	1.0
.constant	k94	0.5
.constant	k95	"HalfAlpha_SColor"
.constant	k96	"FSlateColor"
.constant	k97	"FullAlpha_LColor"
.constant	k98	"FullAlpha_SColor"
.constant	k99	"Image_CheckGun"
.constant	k100	"TextBlock_CheckGun"
.constant	k101	-1
.constant	k102	2
.constant	k103	3
.constant	k104	"SetColorAndOpacity"

.line	1106	gettabup      r1    u0    k0 ; k0 = "require"
.line	1106	gettabup      r2    u0    k1 ; k1 = "table"
.line	1106	gettable      r2    r2    k2 ; k2 = "concat"
.line	1106	newtable      r3     1     0
.line	1106	getupval      r4    u1
.line	1106	loadk         r5    k3 ; k3 = 4
.line	1106	loadk         r6    k4 ; k4 = 80
.line	1106	loadk         r7    k5 ; k5 = 199
.line	1106	loadk         r8    k6 ; k6 = 102
.line	1106	loadk         r9    k7 ; k7 = 152
.line	1106	loadk        r10    k8 ; k8 = 212
.line	1106	loadk        r11    k9 ; k9 = 40
.line	1106	loadk        r12   k10 ; k10 = 24
.line	1106	loadk        r13    k7 ; k7 = 152
.line	1106	loadk        r14   k11 ; k11 = 195
.line	1106	loadk        r15   k12 ; k12 = 110
.line	1106	loadk        r16   k13 ; k13 = 100
.line	1106	loadk        r17   k14 ; k14 = 222
.line	1106	loadk        r18   k15 ; k15 = 176
.line	1106	loadk        r19   k16 ; k16 = 114
.line	1106	loadk        r20   k17 ; k17 = 202
.line	1106	loadk        r21   k18 ; k18 = 210
.line	1106	loadk        r22   k19 ; k19 = 115
.line	1106	loadk        r23   k20 ; k20 = 163
.line	1106	loadk        r24   k21 ; k21 = 29
.line	1106	loadk        r25   k22 ; k22 = 99
.line	1106	loadk        r26   k23 ; k23 = 240
.line	1106	loadk        r27   k24 ; k24 = 84
.line	1106	loadk        r28   k22 ; k22 = 99
.line	1106	loadk        r29   k25 ; k25 = 149
.line	1106	loadk        r30   k26 ; k26 = 208
.line	1106	loadk        r31   k27 ; k27 = 123
.line	1106	loadk        r32   k28 ; k28 = 35
.line	1106	loadk        r33   k29 ; k29 = 172
.line	1106	loadk        r34   k30 ; k30 = 136
.line	1106	loadk        r35   k31 ; k31 = 118
.line	1106	loadk        r36   k32 ; k32 = 201
.line	1106	loadk        r37   k33 ; k33 = 215
.line	1106	loadk        r38   k34 ; k34 = 112
.line	1106	loadk        r39   k35 ; k35 = 184
.line	1106	loadk        r40   k36 ; k36 = 13
.line	1106	loadk        r41   k37 ; k37 = 113
.line	1106	loadk        r42   k38 ; k38 = 236
.line	1106	loadk        r43   k39 ; k39 = 70
.line	1106	loadk        r44   k40 ; k40 = 98
.line	1106	call          r4    41     2
.line	1106	getupval      r5    u1
.line	1106	loadk         r6   k41 ; k41 = 38
.line	1106	loadk         r7   k42 ; k42 = 31
.line	1106	loadk         r8   k43 ; k43 = 198
.line	1106	loadk         r9   k44 ; k44 = 108
.line	1106	loadk        r10   k45 ; k45 = 179
.line	1106	loadk        r11   k46 ; k46 = 200
.line	1106	loadk        r12   k47 ; k47 = 42
.line	1106	loadk        r13   k48 ; k48 = 105
.line	1106	loadk        r14   k15 ; k15 = 176
.line	1106	loadk        r15   k49 ; k49 = 193
.line	1106	loadk        r16   k50 ; k50 = 101
.line	1106	loadk        r17   k51 ; k51 = 62
.line	1106	loadk        r18   k52 ; k52 = 247
.line	1106	call          r5    14     0
.line	1106	setlist       r3     0     1
.line	1106	call          r2     2     2
.line	1106	call          r1     2     2
.line	1106	gettable      r2    r1   k53 ; k53 = "bCustomWeaponShow"
.line	1106	test          r2     0
.line	1106	jmp            0   l76
.line	1106	gettable      r2    r0   k54 ; k54 = "WidgetSwitcher_Check"
.line	1106	test          r2     0
.line	1106	jmp            0   l83
.line	1106	gettable      r2    r0   k54 ; k54 = "WidgetSwitcher_Check"
.line	1106	self          r2    r2   k55 ; k55 = "SetActiveWidgetIndex"
.line	1106	loadk         r4   k56 ; k56 = 1
.line	1106	call          r2     3     1
.line	1106	jmp            0   l83
.label	l76
.line	1106	gettable      r2    r0   k54 ; k54 = "WidgetSwitcher_Check"
.line	1106	test          r2     0
.line	1106	jmp            0   l83
.line	1106	gettable      r2    r0   k54 ; k54 = "WidgetSwitcher_Check"
.line	1106	self          r2    r2   k55 ; k55 = "SetActiveWidgetIndex"
.line	1106	loadk         r4   k57 ; k57 = 0
.line	1106	call          r2     3     1
.label	l83
.line	1106	self          r2    r0   k58 ; k58 = "GetCurrentCheckGunSt" (truncated)
.line	1106	call          r2     2     2
.line	1106	gettabup      r3    u0   k59 ; k59 = "print"
.line	1106	gettabup      r4    u0   k60 ; k60 = "bWriteLog"
.line	1106	test          r4     0
.line	1106	jmp            0  l130
.line	1106	getupval      r4    u1
.line	1106	loadk         r5   k61 ; k61 = 18
.line	1106	loadk         r6   k62 ; k62 = 68
.line	1106	loadk         r7   k11 ; k11 = 195
.line	1106	loadk         r8   k63 ; k63 = 96
.line	1106	loadk         r9   k64 ; k64 = 191
.line	1106	loadk        r10   k65 ; k65 = 228
.line	1106	loadk        r11   k66 ; k66 = 49
.line	1106	loadk        r12   k39 ; k39 = 70
.line	1106	loadk        r13   k67 ; k67 = 167
.line	1106	loadk        r14   k32 ; k32 = 201
.line	1106	loadk        r15   k68 ; k68 = 121
.line	1106	loadk        r16   k69 ; k69 = 57
.line	1106	loadk        r17   k70 ; k70 = 251
.line	1106	loadk        r18   k71 ; k71 = 182
.line	1106	loadk        r19   k72 ; k72 = 126
.line	1106	loadk        r20   k73 ; k73 = 130
.line	1106	loadk        r21   k74 ; k74 = 225
.line	1106	loadk        r22   k13 ; k13 = 100
.line	1106	loadk        r23   k75 ; k75 = 188
.line	1106	loadk        r24   k76 ; k76 = 65
.line	1106	loadk        r25   k76 ; k76 = 65
.line	1106	loadk        r26   k77 ; k77 = 226
.line	1106	loadk        r27   k78 ; k78 = 81
.line	1106	loadk        r28   k79 ; k79 = 69
.line	1106	loadk        r29   k80 ; k80 = 173
.line	1106	loadk        r30   k81 ; k81 = 217
.line	1106	loadk        r31   k68 ; k68 = 121
.line	1106	loadk        r32   k66 ; k66 = 49
.line	1106	loadk        r33   k82 ; k82 = 197
.line	1106	loadk        r34   k75 ; k75 = 188
.line	1106	loadk        r35   k12 ; k12 = 110
.line	1106	loadk        r36   k83 ; k83 = 234
.line	1106	loadk        r37   k33 ; k33 = 215
.line	1106	loadk        r38   k84 ; k84 = 127
.line	1106	loadk        r39   k85 ; k85 = 153
.line	1106	loadk        r40   k86 ; k86 = 87
.line	1106	loadk        r41   k87 ; k87 = 85
.line	1106	loadk        r42   k88 ; k88 = 245
.line	1106	loadk        r43   k89 ; k89 = 76
.line	1106	call          r4    40     2
.label	l130
.line	1106	move          r5    r2
.line	1106	call          r3     3     1
.line	1106	gettable      r3    r0   k90 ; k90 = "HalfAlpha_LColor"
.line	1106	eq             0    r3   k91 ; k91 = nil
.line	1106	jmp            0  l167
.line	1106	gettabup      r3    u0   k92 ; k92 = "FLinearColor"
.line	1106	loadk         r4   k93 ; k93 = 1.0
.line	1106	loadk         r5   k93 ; k93 = 1.0
.line	1106	loadk         r6   k93 ; k93 = 1.0
.line	1106	loadk         r7   k94 ; k94 = 0.5
.line	1106	call          r3     5     2
.line	1106	settable      r0   k90    r3 ; k90 = "HalfAlpha_LColor"
.line	1106	gettabup      r3    u0   k96 ; k96 = "FSlateColor"
.line	1106	gettabup      r4    u0   k92 ; k92 = "FLinearColor"
.line	1106	loadk         r5   k93 ; k93 = 1.0
.line	1106	loadk         r6   k93 ; k93 = 1.0
.line	1106	loadk         r7   k93 ; k93 = 1.0
.line	1106	loadk         r8   k94 ; k94 = 0.5
.line	1106	call          r4     5     0
.line	1106	call          r3     0     2
.line	1106	settable      r0   k95    r3 ; k95 = "HalfAlpha_SColor"
.line	1106	gettabup      r3    u0   k92 ; k92 = "FLinearColor"
.line	1106	loadk         r4   k93 ; k93 = 1.0
.line	1106	loadk         r5   k93 ; k93 = 1.0
.line	1106	loadk         r6   k93 ; k93 = 1.0
.line	1106	loadk         r7   k93 ; k93 = 1.0
.line	1106	call          r3     5     2
.line	1106	settable      r0   k97    r3 ; k97 = "FullAlpha_LColor"
.line	1106	gettabup      r3    u0   k96 ; k96 = "FSlateColor"
.line	1106	gettabup      r4    u0   k92 ; k92 = "FLinearColor"
.line	1106	loadk         r5   k93 ; k93 = 1.0
.line	1106	loadk         r6   k93 ; k93 = 1.0
.line	1106	loadk         r7   k93 ; k93 = 1.0
.line	1106	loadk         r8   k93 ; k93 = 1.0
.line	1106	call          r4     5     0
.line	1106	call          r3     0     2
.line	1106	settable      r0   k98    r3 ; k98 = "FullAlpha_SColor"
.label	l167
.line	1106	gettable      r3    r0   k99 ; k99 = "Image_CheckGun"
.line	1106	test          r3     0
.line	1106	jmp            0  l173
.line	1106	gettable      r3    r0  k100 ; k100 = "TextBlock_CheckGun"
.line	1106	test          r3     1
.line	1106	jmp            0  l174
.label	l173
.line	1106	return        r0     1
.label	l174
.line	1106	eq             1    r2  k101 ; k101 = -1
.line	1106	jmp            0  l180
.line	1106	eq             1    r2  k102 ; k102 = 2
.line	1106	jmp            0  l180
.line	1106	eq             0    r2  k103 ; k103 = 3
.line	1106	jmp            0  l189
.label	l180
.line	1106	gettable      r3    r0   k99 ; k99 = "Image_CheckGun"
.line	1106	self          r3    r3  k104 ; k104 = "SetColorAndOpacity"
.line	1106	gettable      r5    r0   k90 ; k90 = "HalfAlpha_LColor"
.line	1106	call          r3     3     1
.line	1106	gettable      r3    r0  k100 ; k100 = "TextBlock_CheckGun"
.line	1106	self          r3    r3  k104 ; k104 = "SetColorAndOpacity"
.line	1106	gettable      r5    r0   k95 ; k95 = "HalfAlpha_SColor"
.line	1106	call          r3     3     1
.line	1106	jmp            0  l197
.label	l189
.line	1106	gettable      r3    r0   k99 ; k99 = "Image_CheckGun"
.line	1106	self          r3    r3  k104 ; k104 = "SetColorAndOpacity"
.line	1106	gettable      r5    r0   k97 ; k97 = "FullAlpha_LColor"
.line	1106	call          r3     3     1
.line	1106	gettable      r3    r0  k100 ; k100 = "TextBlock_CheckGun"
.line	1106	self          r3    r3  k104 ; k104 = "SetColorAndOpacity"
.line	1106	gettable      r5    r0   k98 ; k98 = "FullAlpha_SColor"
.line	1106	call          r3     3     1
.label	l197
.line	1106	return        r0     1
.line	1106	move          r0    r0
.line	1106	return        r0     1

.function	main/f46

.source	null
.linedefined	1135
.lastlinedefined	1137
.numparams	1
.is_vararg	0
.maxstacksize	3

.constant	k0	"RefreshCheckGunBtnState"

.line	1135	self          r1    r0    k0 ; k0 = "RefreshCheckGunBtnSt" (truncated)
.line	1135	call          r1     2     1
.line	1135	return        r0     1
.line	1135	move          r0    r0
.line	1135	move          r0    r0
.line	1135	return        r0     1

.function	main/f47

.source	null
.linedefined	1139
.lastlinedefined	1142
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	22	true

.constant	k0	"ShowOrHideRing"
.constant	k1	"TryDoCheckGun"

.line	1139	self          r1    r0    k0 ; k0 = "ShowOrHideRing"
.line	1139	loadbool      r3     0     0
.line	1139	call          r1     3     1
.line	1139	gettabup      r1    u0    k1 ; k1 = "TryDoCheckGun"
.line	1139	move          r2    r0
.line	1139	call          r1     2     1
.line	1139	return        r0     1
.line	1139	move          r0    r0
.line	1139	move          r0    r0
.line	1139	return        r0     1

.function	main/f48

.source	null
.linedefined	1144
.lastlinedefined	1216
.numparams	1
.is_vararg	0
.maxstacksize	64

.upvalue	"_ENV"	14	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	2	true

.constant	k0	"GetPlayerCharacter"
.constant	k1	"slua"
.constant	k2	"isValid"
.constant	k3	"print"
.constant	k4	"bWriteLog"
.constant	k5	"table"
.constant	k6	"concat"
.constant	k7	18
.constant	k8	68
.constant	k9	195
.constant	k10	96
.constant	k11	191
.constant	k12	228
.constant	k13	49
.constant	k14	70
.constant	k15	167
.constant	k16	201
.constant	k17	121
.constant	k18	57
.constant	k19	251
.constant	k20	182
.constant	k21	126
.constant	k22	130
.constant	k23	244
.constant	k24	100
.constant	k25	174
.constant	k26	112
.constant	k27	81
.constant	k28	227
.constant	k29	75
.constant	k30	99
.constant	k31	171
.constant	k32	200
.constant	k33	89
.constant	k34	50
.constant	k35	231
.constant	k36	170
.constant	k37	107
.constant	k38	239
.constant	k39	214
.constant	k40	127
.constant	k41	153
.constant	k42	87
.constant	k43	85
.constant	k44	245
.constant	k45	76
.constant	k46	54
.constant	k47	6
.constant	k48	67
.constant	k49	216
.constant	k50	108
.constant	k51	166
.constant	k52	129
.constant	k53	120
.constant	k54	-1
.constant	k55	"GetPlayerControllerSafety"
.constant	k56	123
.constant	k57	"GetCurrentWeapon"
.constant	k58	122
.constant	k59	"WeaponAvatarComponent"
.constant	k60	2
.constant	k61	"import"
.constant	k62	102
.constant	k63	207
.constant	k64	98
.constant	k65	164
.constant	k66	206
.constant	k67	39
.constant	k68	119
.constant	k69	161
.constant	k70	41
.constant	k71	250
.constant	k72	180
.constant	k73	117
.constant	k74	199
.constant	k75	82
.constant	k76	181
.constant	k77	80
.constant	k78	79
.constant	k79	77
.constant	k80	188
.constant	k81	204
.constant	k82	114
.constant	k83	194
.constant	k84	242
.constant	k85	83
.constant	k86	197
.constant	k87	38
.constant	k88	222
.constant	k89	221
.constant	k90	223
.constant	k91	66
.constant	k92	101
.constant	k93	160
.constant	k94	232
.constant	k95	42
.constant	k96	"GetEquippedItemDefineID"
.constant	k97	"MasterGun"
.constant	k98	"TypeSpecificID"
.constant	k99	0
.constant	k100	8
.constant	k101	22
.constant	k102	58
.constant	k103	253
.constant	k104	183
.constant	k105	210
.constant	k106	187
.constant	k107	65
.constant	k108	109
.constant	k109	213
.constant	k110	25
.constant	k111	59
.constant	k112	"GetItemDefineID"
.constant	k113	11
.constant	k114	"SubsystemMgr"
.constant	k115	"Get"
.constant	k116	19
.constant	k117	230
.constant	k118	165
.constant	k119	196
.constant	k120	111
.constant	k121	56
.constant	k122	193
.constant	k123	172
.constant	k124	235
.constant	k125	202
.constant	k126	86
.constant	k127	73
.constant	k128	"bIsPhotoGrapherMode"
.constant	k129	1
.constant	k130	1014433
.constant	k131	"GetSkillManager"
.constant	k132	"Game"
.constant	k133	"IsValid"
.constant	k134	"IsCastingSkillID"
.constant	k135	"GetBPIDByResID"
.constant	k136	"GetWeaponAvatarParentID"
.constant	k137	"GetEquippedHandle"
.constant	k138	"WeaponSpecialLevelSequenceList"
.constant	k139	"pairs"
.constant	k140	"LevelSequenceType"
.constant	k141	"ECharSpecLvSeq_WeaponCheck"
.constant	k142	"LevelSequenceConfig"
.constant	k143	"LevelSequenceDuration"
.constant	k144	10
.constant	k145	124
.constant	k146	47
.constant	k147	254
.constant	k148	138
.constant	k149	198
.constant	k150	104
.constant	k151	163
.constant	k152	125
.constant	k153	3
.constant	k154	"SequenceActorTemplate"
.constant	k155	"IsNull"
.constant	k156	"LevelSequence"
.constant	k157	"ToSoftObjectPath"
.constant	k158	13
.constant	k159	217
.constant	k160	178
.constant	k161	208
.constant	k162	90
.constant	k163	78
.constant	k164	63
.constant	k165	185
.constant	k166	215
.constant	k167	116
.constant	k168	234
.constant	k169	115
.constant	k170	53
.constant	k171	84
.constant	k172	177
.constant	k173	60
.constant	k174	"CDataTable"
.constant	k175	"GetTableData"
.constant	k176	20
.constant	k177	203
.constant	k178	94
.constant	k179	176
.constant	k180	97
.constant	k181	249
.constant	k182	212
.constant	k183	"LevelSequencePath"
.constant	k184	"CurrentStates"
.constant	k185	"UEnums"
.constant	k186	"EPawnState"
.constant	k187	"Stand"
.constant	k188	"IsHandleInFold"

.line	1144	gettabup      r1    u0    k0 ; k0 = "GetPlayerCharacter"
.line	1144	call          r1     1     2
.line	1144	test          r1     0
.line	1144	jmp            0   l11
.line	1144	gettabup      r2    u1    k1 ; k1 = "slua"
.line	1144	gettable      r2    r2    k2 ; k2 = "isValid"
.line	1144	move          r3    r1
.line	1144	call          r2     2     2
.line	1144	test          r2     1
.line	1144	jmp            0   l74
.label	l11
.line	1144	gettabup      r2    u1    k3 ; k3 = "print"
.line	1144	gettabup      r3    u1    k4 ; k4 = "bWriteLog"
.line	1144	test          r3     0
.line	1144	jmp            0   l71
.line	1144	gettabup      r3    u1    k5 ; k5 = "table"
.line	1144	gettable      r3    r3    k6 ; k6 = "concat"
.line	1144	newtable      r4     1     0
.line	1144	getupval      r5    u2
.line	1144	loadk         r6    k7 ; k7 = 18
.line	1144	loadk         r7    k8 ; k8 = 68
.line	1144	loadk         r8    k9 ; k9 = 195
.line	1144	loadk         r9   k10 ; k10 = 96
.line	1144	loadk        r10   k11 ; k11 = 191
.line	1144	loadk        r11   k12 ; k12 = 228
.line	1144	loadk        r12   k13 ; k13 = 49
.line	1144	loadk        r13   k14 ; k14 = 70
.line	1144	loadk        r14   k15 ; k15 = 167
.line	1144	loadk        r15   k16 ; k16 = 201
.line	1144	loadk        r16   k17 ; k17 = 121
.line	1144	loadk        r17   k18 ; k18 = 57
.line	1144	loadk        r18   k19 ; k19 = 251
.line	1144	loadk        r19   k20 ; k20 = 182
.line	1144	loadk        r20   k21 ; k21 = 126
.line	1144	loadk        r21   k22 ; k22 = 130
.line	1144	loadk        r22   k23 ; k23 = 244
.line	1144	loadk        r23   k24 ; k24 = 100
.line	1144	loadk        r24   k25 ; k25 = 174
.line	1144	loadk        r25   k26 ; k26 = 112
.line	1144	loadk        r26   k27 ; k27 = 81
.line	1144	loadk        r27   k28 ; k28 = 227
.line	1144	loadk        r28   k29 ; k29 = 75
.line	1144	loadk        r29   k30 ; k30 = 99
.line	1144	loadk        r30   k31 ; k31 = 171
.line	1144	loadk        r31   k32 ; k32 = 200
.line	1144	loadk        r32   k33 ; k33 = 89
.line	1144	loadk        r33   k34 ; k34 = 50
.line	1144	loadk        r34   k35 ; k35 = 231
.line	1144	loadk        r35   k36 ; k36 = 170
.line	1144	loadk        r36   k37 ; k37 = 107
.line	1144	loadk        r37   k38 ; k38 = 239
.line	1144	loadk        r38   k39 ; k39 = 214
.line	1144	loadk        r39   k40 ; k40 = 127
.line	1144	loadk        r40   k41 ; k41 = 153
.line	1144	loadk        r41   k42 ; k42 = 87
.line	1144	loadk        r42   k43 ; k43 = 85
.line	1144	loadk        r43   k44 ; k44 = 245
.line	1144	loadk        r44   k45 ; k45 = 76
.line	1144	loadk        r45   k46 ; k46 = 54
.line	1144	call          r5    41     2
.line	1144	getupval      r6    u2
.line	1144	loadk         r7   k47 ; k47 = 6
.line	1144	loadk         r8   k48 ; k48 = 67
.line	1144	loadk         r9   k49 ; k49 = 216
.line	1144	loadk        r10   k50 ; k50 = 108
.line	1144	loadk        r11   k51 ; k51 = 166
.line	1144	loadk        r12   k52 ; k52 = 129
.line	1144	loadk        r13   k53 ; k53 = 120
.line	1144	call          r6     8     0
.line	1144	setlist       r4     0     1
.line	1144	call          r3     2     2
.label	l71
.line	1144	call          r2     2     1
.line	1144	loadk         r2   k54 ; k54 = -1
.line	1144	return        r2     2
.label	l74
.line	1144	self          r2    r1   k55 ; k55 = "GetPlayerControllerS" (truncated)
.line	1144	call          r2     2     2
.line	1144	test          r2     0
.line	1144	jmp            0   l84
.line	1144	gettabup      r3    u1    k1 ; k1 = "slua"
.line	1144	gettable      r3    r3    k2 ; k2 = "isValid"
.line	1144	move          r4    r2
.line	1144	call          r3     2     2
.line	1144	test          r3     1
.line	1144	jmp            0  l147
.label	l84
.line	1144	gettabup      r3    u1    k3 ; k3 = "print"
.line	1144	gettabup      r4    u1    k4 ; k4 = "bWriteLog"
.line	1144	test          r4     0
.line	1144	jmp            0  l144
.line	1144	gettabup      r4    u1    k5 ; k5 = "table"
.line	1144	gettable      r4    r4    k6 ; k6 = "concat"
.line	1144	newtable      r5     1     0
.line	1144	getupval      r6    u2
.line	1144	loadk         r7    k7 ; k7 = 18
.line	1144	loadk         r8    k8 ; k8 = 68
.line	1144	loadk         r9    k9 ; k9 = 195
.line	1144	loadk        r10   k10 ; k10 = 96
.line	1144	loadk        r11   k11 ; k11 = 191
.line	1144	loadk        r12   k12 ; k12 = 228
.line	1144	loadk        r13   k13 ; k13 = 49
.line	1144	loadk        r14   k14 ; k14 = 70
.line	1144	loadk        r15   k15 ; k15 = 167
.line	1144	loadk        r16   k16 ; k16 = 201
.line	1144	loadk        r17   k17 ; k17 = 121
.line	1144	loadk        r18   k18 ; k18 = 57
.line	1144	loadk        r19   k19 ; k19 = 251
.line	1144	loadk        r20   k20 ; k20 = 182
.line	1144	loadk        r21   k21 ; k21 = 126
.line	1144	loadk        r22   k22 ; k22 = 130
.line	1144	loadk        r23   k23 ; k23 = 244
.line	1144	loadk        r24   k24 ; k24 = 100
.line	1144	loadk        r25   k25 ; k25 = 174
.line	1144	loadk        r26   k26 ; k26 = 112
.line	1144	loadk        r27   k27 ; k27 = 81
.line	1144	loadk        r28   k28 ; k28 = 227
.line	1144	loadk        r29   k29 ; k29 = 75
.line	1144	loadk        r30   k30 ; k30 = 99
.line	1144	loadk        r31   k31 ; k31 = 171
.line	1144	loadk        r32   k32 ; k32 = 200
.line	1144	loadk        r33   k33 ; k33 = 89
.line	1144	loadk        r34   k34 ; k34 = 50
.line	1144	loadk        r35   k35 ; k35 = 231
.line	1144	loadk        r36   k36 ; k36 = 170
.line	1144	loadk        r37   k37 ; k37 = 107
.line	1144	loadk        r38   k38 ; k38 = 239
.line	1144	loadk        r39   k39 ; k39 = 214
.line	1144	loadk        r40   k40 ; k40 = 127
.line	1144	loadk        r41   k41 ; k41 = 153
.line	1144	loadk        r42   k42 ; k42 = 87
.line	1144	loadk        r43   k43 ; k43 = 85
.line	1144	loadk        r44   k44 ; k44 = 245
.line	1144	loadk        r45   k45 ; k45 = 76
.line	1144	loadk        r46   k46 ; k46 = 54
.line	1144	call          r6    41     2
.line	1144	getupval      r7    u2
.line	1144	loadk         r8   k47 ; k47 = 6
.line	1144	loadk         r9   k48 ; k48 = 67
.line	1144	loadk        r10   k49 ; k49 = 216
.line	1144	loadk        r11   k50 ; k50 = 108
.line	1144	loadk        r12   k51 ; k51 = 166
.line	1144	loadk        r13   k52 ; k52 = 129
.line	1144	loadk        r14   k56 ; k56 = 123
.line	1144	call          r7     8     0
.line	1144	setlist       r5     0     1
.line	1144	call          r4     2     2
.label	l144
.line	1144	call          r3     2     1
.line	1144	loadk         r3   k54 ; k54 = -1
.line	1144	return        r3     2
.label	l147
.line	1144	gettable      r3    r1   k57 ; k57 = "GetCurrentWeapon"
.line	1144	test          r3     1
.line	1144	jmp            0  l213
.line	1144	gettabup      r3    u1    k3 ; k3 = "print"
.line	1144	gettabup      r4    u1    k4 ; k4 = "bWriteLog"
.line	1144	test          r4     0
.line	1144	jmp            0  l210
.line	1144	gettabup      r4    u1    k5 ; k5 = "table"
.line	1144	gettable      r4    r4    k6 ; k6 = "concat"
.line	1144	newtable      r5     1     0
.line	1144	getupval      r6    u2
.line	1144	loadk         r7    k7 ; k7 = 18
.line	1144	loadk         r8    k8 ; k8 = 68
.line	1144	loadk         r9    k9 ; k9 = 195
.line	1144	loadk        r10   k10 ; k10 = 96
.line	1144	loadk        r11   k11 ; k11 = 191
.line	1144	loadk        r12   k12 ; k12 = 228
.line	1144	loadk        r13   k13 ; k13 = 49
.line	1144	loadk        r14   k14 ; k14 = 70
.line	1144	loadk        r15   k15 ; k15 = 167
.line	1144	loadk        r16   k16 ; k16 = 201
.line	1144	loadk        r17   k17 ; k17 = 121
.line	1144	loadk        r18   k18 ; k18 = 57
.line	1144	loadk        r19   k19 ; k19 = 251
.line	1144	loadk        r20   k20 ; k20 = 182
.line	1144	loadk        r21   k21 ; k21 = 126
.line	1144	loadk        r22   k22 ; k22 = 130
.line	1144	loadk        r23   k23 ; k23 = 244
.line	1144	loadk        r24   k24 ; k24 = 100
.line	1144	loadk        r25   k25 ; k25 = 174
.line	1144	loadk        r26   k26 ; k26 = 112
.line	1144	loadk        r27   k27 ; k27 = 81
.line	1144	loadk        r28   k28 ; k28 = 227
.line	1144	loadk        r29   k29 ; k29 = 75
.line	1144	loadk        r30   k30 ; k30 = 99
.line	1144	loadk        r31   k31 ; k31 = 171
.line	1144	loadk        r32   k32 ; k32 = 200
.line	1144	loadk        r33   k33 ; k33 = 89
.line	1144	loadk        r34   k34 ; k34 = 50
.line	1144	loadk        r35   k35 ; k35 = 231
.line	1144	loadk        r36   k36 ; k36 = 170
.line	1144	loadk        r37   k37 ; k37 = 107
.line	1144	loadk        r38   k38 ; k38 = 239
.line	1144	loadk        r39   k39 ; k39 = 214
.line	1144	loadk        r40   k40 ; k40 = 127
.line	1144	loadk        r41   k41 ; k41 = 153
.line	1144	loadk        r42   k42 ; k42 = 87
.line	1144	loadk        r43   k43 ; k43 = 85
.line	1144	loadk        r44   k44 ; k44 = 245
.line	1144	loadk        r45   k45 ; k45 = 76
.line	1144	loadk        r46   k46 ; k46 = 54
.line	1144	call          r6    41     2
.line	1144	getupval      r7    u2
.line	1144	loadk         r8   k47 ; k47 = 6
.line	1144	loadk         r9   k48 ; k48 = 67
.line	1144	loadk        r10   k49 ; k49 = 216
.line	1144	loadk        r11   k50 ; k50 = 108
.line	1144	loadk        r12   k51 ; k51 = 166
.line	1144	loadk        r13   k52 ; k52 = 129
.line	1144	loadk        r14   k58 ; k58 = 122
.line	1144	call          r7     8     0
.line	1144	setlist       r5     0     1
.line	1144	call          r4     2     2
.label	l210
.line	1144	call          r3     2     1
.line	1144	loadk         r3   k54 ; k54 = -1
.line	1144	return        r3     2
.label	l213
.line	1144	self          r3    r1   k57 ; k57 = "GetCurrentWeapon"
.line	1144	call          r3     2     2
.line	1144	gettabup      r4    u1    k1 ; k1 = "slua"
.line	1144	gettable      r4    r4    k2 ; k2 = "isValid"
.line	1144	move          r5    r3
.line	1144	call          r4     2     2
.line	1144	test          r4     0
.line	1144	jmp            0  l227
.line	1144	gettabup      r4    u1    k1 ; k1 = "slua"
.line	1144	gettable      r4    r4    k2 ; k2 = "isValid"
.line	1144	gettable      r5    r3   k59 ; k59 = "WeaponAvatarComponen" (truncated)
.line	1144	call          r4     2     2
.line	1144	test          r4     1
.line	1144	jmp            0  l229
.label	l227
.line	1144	loadk         r4   k60 ; k60 = 2
.line	1144	return        r4     2
.label	l229
.line	1144	gettabup      r4    u1   k61 ; k61 = "import"
.line	1144	getupval      r5    u2
.line	1144	loadk         r6   k47 ; k47 = 6
.line	1144	loadk         r7   k62 ; k62 = 102
.line	1144	loadk         r8   k63 ; k63 = 207
.line	1144	loadk         r9   k64 ; k64 = 98
.line	1144	loadk        r10   k65 ; k65 = 164
.line	1144	loadk        r11   k66 ; k66 = 206
.line	1144	loadk        r12   k67 ; k67 = 39
.line	1144	loadk        r13   k68 ; k68 = 119
.line	1144	loadk        r14   k69 ; k69 = 161
.line	1144	loadk        r15   k49 ; k49 = 216
.line	1144	loadk        r16   k37 ; k37 = 107
.line	1144	loadk        r17   k70 ; k70 = 41
.line	1144	loadk        r18   k71 ; k71 = 250
.line	1144	loadk        r19   k72 ; k72 = 180
.line	1144	loadk        r20   k73 ; k73 = 117
.line	1144	loadk        r21   k39 ; k39 = 214
.line	1144	loadk        r22   k74 ; k74 = 199
.line	1144	loadk        r23   k75 ; k75 = 82
.line	1144	loadk        r24   k76 ; k76 = 181
.line	1144	loadk        r25   k77 ; k77 = 80
.line	1144	loadk        r26   k78 ; k78 = 79
.line	1144	loadk        r27   k23 ; k23 = 244
.line	1144	loadk        r28   k79 ; k79 = 77
.line	1144	loadk        r29   k75 ; k75 = 82
.line	1144	loadk        r30   k80 ; k80 = 188
.line	1144	loadk        r31   k81 ; k81 = 204
.line	1144	loadk        r32   k40 ; k40 = 127
.line	1144	call          r5    28     2
.line	1144	call          r4     2     2
.line	1144	gettabup      r5    u1   k61 ; k61 = "import"
.line	1144	getupval      r6    u2
.line	1144	loadk         r7   k47 ; k47 = 6
.line	1144	loadk         r8   k82 ; k82 = 114
.line	1144	loadk         r9   k83 ; k83 = 194
.line	1144	loadk        r10   k64 ; k64 = 98
.line	1144	loadk        r11   k51 ; k51 = 166
.line	1144	loadk        r12   k84 ; k84 = 242
.line	1144	loadk        r13   k18 ; k18 = 57
.line	1144	loadk        r14   k85 ; k85 = 83
.line	1144	loadk        r15   k20 ; k20 = 182
.line	1144	loadk        r16   k86 ; k86 = 197
.line	1144	loadk        r17   k37 ; k37 = 107
.line	1144	loadk        r18   k87 ; k87 = 38
.line	1144	loadk        r19   k88 ; k88 = 222
.line	1144	loadk        r20   k80 ; k80 = 188
.line	1144	loadk        r21   k62 ; k62 = 102
.line	1144	loadk        r22   k89 ; k89 = 221
.line	1144	loadk        r23   k90 ; k90 = 223
.line	1144	loadk        r24   k75 ; k75 = 82
.line	1144	loadk        r25   k11 ; k11 = 191
.line	1144	loadk        r26   k91 ; k91 = 66
.line	1144	loadk        r27   k27 ; k27 = 81
.line	1144	loadk        r28   k23 ; k23 = 244
.line	1144	loadk        r29   k42 ; k42 = 87
.line	1144	loadk        r30   k92 ; k92 = 101
.line	1144	loadk        r31   k93 ; k93 = 160
.line	1144	loadk        r32   k94 ; k94 = 232
.line	1144	loadk        r33   k30 ; k30 = 99
.line	1144	loadk        r34   k95 ; k95 = 42
.line	1144	loadk        r35   k35 ; k35 = 231
.line	1144	call          r6    30     2
.line	1144	call          r5     2     2
.line	1144	gettable      r6    r3   k59 ; k59 = "WeaponAvatarComponen" (truncated)
.line	1144	self          r6    r6   k96 ; k96 = "GetEquippedItemDefin" (truncated)
.line	1144	gettable      r8    r4   k97 ; k97 = "MasterGun"
.line	1144	call          r6     3     2
.line	1144	gettable      r6    r6   k98 ; k98 = "TypeSpecificID"
.line	1144	le             0    r6   k99 ; k99 = 0
.line	1144	jmp            0  l382
.line	1144	gettabup      r7    u1    k3 ; k3 = "print"
.line	1144	gettabup      r8    u1    k4 ; k4 = "bWriteLog"
.line	1144	test          r8     0
.line	1144	jmp            0  l377
.line	1144	gettabup      r8    u1    k5 ; k5 = "table"
.line	1144	gettable      r8    r8    k6 ; k6 = "concat"
.line	1144	newtable      r9     1     0
.line	1144	getupval     r10    u2
.line	1144	loadk        r11    k7 ; k7 = 18
.line	1144	loadk        r12    k8 ; k8 = 68
.line	1144	loadk        r13    k9 ; k9 = 195
.line	1144	loadk        r14   k10 ; k10 = 96
.line	1144	loadk        r15   k11 ; k11 = 191
.line	1144	loadk        r16   k12 ; k12 = 228
.line	1144	loadk        r17   k13 ; k13 = 49
.line	1144	loadk        r18   k14 ; k14 = 70
.line	1144	loadk        r19   k15 ; k15 = 167
.line	1144	loadk        r20   k16 ; k16 = 201
.line	1144	loadk        r21   k17 ; k17 = 121
.line	1144	loadk        r22   k18 ; k18 = 57
.line	1144	loadk        r23   k19 ; k19 = 251
.line	1144	loadk        r24   k20 ; k20 = 182
.line	1144	loadk        r25   k21 ; k21 = 126
.line	1144	loadk        r26   k22 ; k22 = 130
.line	1144	loadk        r27   k23 ; k23 = 244
.line	1144	loadk        r28   k24 ; k24 = 100
.line	1144	loadk        r29   k25 ; k25 = 174
.line	1144	loadk        r30   k26 ; k26 = 112
.line	1144	loadk        r31   k27 ; k27 = 81
.line	1144	loadk        r32   k28 ; k28 = 227
.line	1144	loadk        r33   k29 ; k29 = 75
.line	1144	loadk        r34   k30 ; k30 = 99
.line	1144	loadk        r35   k31 ; k31 = 171
.line	1144	loadk        r36   k32 ; k32 = 200
.line	1144	loadk        r37   k33 ; k33 = 89
.line	1144	loadk        r38   k34 ; k34 = 50
.line	1144	loadk        r39   k35 ; k35 = 231
.line	1144	loadk        r40   k36 ; k36 = 170
.line	1144	loadk        r41   k37 ; k37 = 107
.line	1144	loadk        r42   k38 ; k38 = 239
.line	1144	loadk        r43   k39 ; k39 = 214
.line	1144	loadk        r44   k40 ; k40 = 127
.line	1144	loadk        r45   k41 ; k41 = 153
.line	1144	loadk        r46   k42 ; k42 = 87
.line	1144	loadk        r47   k43 ; k43 = 85
.line	1144	loadk        r48   k44 ; k44 = 245
.line	1144	loadk        r49   k45 ; k45 = 76
.line	1144	loadk        r50   k46 ; k46 = 54
.line	1144	call         r10    41     2
.line	1144	getupval     r11    u2
.line	1144	loadk        r12   k47 ; k47 = 6
.line	1144	loadk        r13   k48 ; k48 = 67
.line	1144	loadk        r14   k49 ; k49 = 216
.line	1144	loadk        r15   k50 ; k50 = 108
.line	1144	loadk        r16   k51 ; k51 = 166
.line	1144	loadk        r17   k52 ; k52 = 129
.line	1144	loadk        r18  k100 ; k100 = 8
.line	1144	loadk        r19  k101 ; k101 = 22
.line	1144	loadk        r20   k22 ; k22 = 130
.line	1144	loadk        r21   k16 ; k16 = 201
.line	1144	loadk        r22   k37 ; k37 = 107
.line	1144	loadk        r23  k102 ; k102 = 58
.line	1144	loadk        r24  k103 ; k103 = 253
.line	1144	loadk        r25  k104 ; k104 = 183
.line	1144	loadk        r26   k27 ; k27 = 81
.line	1144	loadk        r27   k66 ; k66 = 206
.line	1144	loadk        r28  k105 ; k105 = 210
.line	1144	loadk        r29   k73 ; k73 = 117
.line	1144	loadk        r30  k106 ; k106 = 187
.line	1144	loadk        r31  k107 ; k107 = 65
.line	1144	loadk        r32  k108 ; k108 = 109
.line	1144	loadk        r33  k109 ; k109 = 213
.line	1144	loadk        r34  k110 ; k110 = 25
.line	1144	loadk        r35  k111 ; k111 = 59
.line	1144	call         r11    25     0
.line	1144	setlist       r9     0     1
.line	1144	call          r8     2     2
.label	l377
.line	1144	move          r9    r6
.line	1144	call          r7     3     1
.line	1144	self          r7    r3  k112 ; k112 = "GetItemDefineID"
.line	1144	call          r7     2     2
.line	1144	gettable      r6    r7   k98 ; k98 = "TypeSpecificID"
.label	l382
.line	1144	le             0    r6   k99 ; k99 = 0
.line	1144	jmp            0  l465
.line	1144	gettabup      r7    u1    k3 ; k3 = "print"
.line	1144	gettabup      r8    u1    k4 ; k4 = "bWriteLog"
.line	1144	test          r8     0
.line	1144	jmp            0  l461
.line	1144	gettabup      r8    u1    k5 ; k5 = "table"
.line	1144	gettable      r8    r8    k6 ; k6 = "concat"
.line	1144	newtable      r9     1     0
.line	1144	getupval     r10    u2
.line	1144	loadk        r11    k7 ; k7 = 18
.line	1144	loadk        r12    k8 ; k8 = 68
.line	1144	loadk        r13    k9 ; k9 = 195
.line	1144	loadk        r14   k10 ; k10 = 96
.line	1144	loadk        r15   k11 ; k11 = 191
.line	1144	loadk        r16   k12 ; k12 = 228
.line	1144	loadk        r17   k13 ; k13 = 49
.line	1144	loadk        r18   k14 ; k14 = 70
.line	1144	loadk        r19   k15 ; k15 = 167
.line	1144	loadk        r20   k16 ; k16 = 201
.line	1144	loadk        r21   k17 ; k17 = 121
.line	1144	loadk        r22   k18 ; k18 = 57
.line	1144	loadk        r23   k19 ; k19 = 251
.line	1144	loadk        r24   k20 ; k20 = 182
.line	1144	loadk        r25   k21 ; k21 = 126
.line	1144	loadk        r26   k22 ; k22 = 130
.line	1144	loadk        r27   k23 ; k23 = 244
.line	1144	loadk        r28   k24 ; k24 = 100
.line	1144	loadk        r29   k25 ; k25 = 174
.line	1144	loadk        r30   k26 ; k26 = 112
.line	1144	loadk        r31   k27 ; k27 = 81
.line	1144	loadk        r32   k28 ; k28 = 227
.line	1144	loadk        r33   k29 ; k29 = 75
.line	1144	loadk        r34   k30 ; k30 = 99
.line	1144	loadk        r35   k31 ; k31 = 171
.line	1144	loadk        r36   k32 ; k32 = 200
.line	1144	loadk        r37   k33 ; k33 = 89
.line	1144	loadk        r38   k34 ; k34 = 50
.line	1144	loadk        r39   k35 ; k35 = 231
.line	1144	loadk        r40   k36 ; k36 = 170
.line	1144	loadk        r41   k37 ; k37 = 107
.line	1144	loadk        r42   k38 ; k38 = 239
.line	1144	loadk        r43   k39 ; k39 = 214
.line	1144	loadk        r44   k40 ; k40 = 127
.line	1144	loadk        r45   k41 ; k41 = 153
.line	1144	loadk        r46   k42 ; k42 = 87
.line	1144	loadk        r47   k43 ; k43 = 85
.line	1144	loadk        r48   k44 ; k44 = 245
.line	1144	loadk        r49   k45 ; k45 = 76
.line	1144	loadk        r50   k46 ; k46 = 54
.line	1144	call         r10    41     2
.line	1144	getupval     r11    u2
.line	1144	loadk        r12   k47 ; k47 = 6
.line	1144	loadk        r13   k48 ; k48 = 67
.line	1144	loadk        r14   k49 ; k49 = 216
.line	1144	loadk        r15   k50 ; k50 = 108
.line	1144	loadk        r16   k51 ; k51 = 166
.line	1144	loadk        r17   k52 ; k52 = 129
.line	1144	loadk        r18  k113 ; k113 = 11
.line	1144	loadk        r19  k101 ; k101 = 22
.line	1144	loadk        r20   k22 ; k22 = 130
.line	1144	loadk        r21   k16 ; k16 = 201
.line	1144	loadk        r22   k37 ; k37 = 107
.line	1144	loadk        r23  k102 ; k102 = 58
.line	1144	loadk        r24  k103 ; k103 = 253
.line	1144	loadk        r25  k104 ; k104 = 183
.line	1144	loadk        r26   k27 ; k27 = 81
.line	1144	loadk        r27   k66 ; k66 = 206
.line	1144	loadk        r28  k105 ; k105 = 210
.line	1144	loadk        r29   k73 ; k73 = 117
.line	1144	loadk        r30  k106 ; k106 = 187
.line	1144	loadk        r31  k107 ; k107 = 65
.line	1144	loadk        r32  k108 ; k108 = 109
.line	1144	loadk        r33  k109 ; k109 = 213
.line	1144	loadk        r34  k110 ; k110 = 25
.line	1144	loadk        r35  k111 ; k111 = 59
.line	1144	call         r11    25     0
.line	1144	setlist       r9     0     1
.line	1144	call          r8     2     2
.label	l461
.line	1144	move          r9    r6
.line	1144	call          r7     3     1
.line	1144	loadk         r7   k54 ; k54 = -1
.line	1144	return        r7     2
.label	l465
.line	1144	gettabup      r7    u1  k114 ; k114 = "SubsystemMgr"
.line	1144	self          r7    r7  k115 ; k115 = "Get"
.line	1144	getupval      r9    u2
.line	1144	loadk        r10  k116 ; k116 = 19
.line	1144	loadk        r11   k33 ; k33 = 89
.line	1144	loadk        r12   k86 ; k86 = 197
.line	1144	loadk        r13   k68 ; k68 = 119
.line	1144	loadk        r14  k106 ; k106 = 187
.line	1144	loadk        r15  k117 ; k117 = 230
.line	1144	loadk        r16  k111 ; k111 = 59
.line	1144	loadk        r17   k42 ; k42 = 87
.line	1144	loadk        r18  k118 ; k118 = 165
.line	1144	loadk        r19  k119 ; k119 = 196
.line	1144	loadk        r20  k120 ; k120 = 111
.line	1144	loadk        r21  k121 ; k121 = 56
.line	1144	loadk        r22  k122 ; k122 = 193
.line	1144	loadk        r23  k123 ; k123 = 172
.line	1144	loadk        r24   k82 ; k82 = 114
.line	1144	loadk        r25  k124 ; k124 = 235
.line	1144	loadk        r26  k125 ; k125 = 202
.line	1144	loadk        r27   k82 ; k82 = 114
.line	1144	loadk        r28   k25 ; k25 = 174
.line	1144	loadk        r29  k126 ; k126 = 86
.line	1144	loadk        r30  k127 ; k127 = 73
.line	1144	call          r9    22     2
.line	1144	call          r7     3     2
.line	1144	test          r7     0
.line	1144	jmp            0  l498
.line	1144	gettable      r8    r7  k128 ; k128 = "bIsPhotoGrapherMode"
.line	1144	test          r8     0
.line	1144	jmp            0  l498
.line	1144	loadk         r8  k129 ; k129 = 1
.line	1144	return        r8     2
.label	l498
.line	1144	loadk         r8  k130 ; k130 = 1014433
.line	1144	gettable      r9    r1  k131 ; k131 = "GetSkillManager"
.line	1144	test          r9     0
.line	1144	jmp            0  l517
.line	1144	self          r9    r1  k131 ; k131 = "GetSkillManager"
.line	1144	call          r9     2     2
.line	1144	gettabup     r10    u1  k132 ; k132 = "Game"
.line	1144	self         r10   r10  k133 ; k133 = "IsValid"
.line	1144	move         r12    r9
.line	1144	call         r10     3     2
.line	1144	test         r10     0
.line	1144	jmp            0  l517
.line	1144	self         r10    r9  k134 ; k134 = "IsCastingSkillID"
.line	1144	move         r12    r8
.line	1144	call         r10     3     2
.line	1144	test         r10     0
.line	1144	jmp            0  l517
.line	1144	loadk        r10  k129 ; k129 = 1
.line	1144	return       r10     2
.label	l517
.line	1144	gettabup      r9    u3  k135 ; k135 = "GetBPIDByResID"
.line	1144	move         r10    r6
.line	1144	call          r9     2     2
.line	1144	gettabup     r10    u3  k136 ; k136 = "GetWeaponAvatarParen" (truncated)
.line	1144	move         r11    r9
.line	1144	loadbool     r12     0     0
.line	1144	call         r10     3     2
.line	1144	gettable     r11    r3   k59 ; k59 = "WeaponAvatarComponen" (truncated)
.line	1144	self         r11   r11  k137 ; k137 = "GetEquippedHandle"
.line	1144	gettable     r13    r4   k97 ; k97 = "MasterGun"
.line	1144	call         r11     3     2
.line	1144	loadbool     r12     0     0
.line	1144	test         r11     0
.line	1144	jmp            0  l765
.line	1144	gettabup     r13    u1    k1 ; k1 = "slua"
.line	1144	gettable     r13   r13    k2 ; k2 = "isValid"
.line	1144	move         r14   r11
.line	1144	call         r13     2     2
.line	1144	test         r13     0
.line	1144	jmp            0  l765
.line	1144	gettable     r13   r11  k138 ; k138 = "WeaponSpecialLevelSe" (truncated)
.line	1144	test         r13     0
.line	1144	jmp            0  l765
.line	1144	gettabup     r13    u1  k139 ; k139 = "pairs"
.line	1144	gettable     r14   r11  k138 ; k138 = "WeaponSpecialLevelSe" (truncated)
.line	1144	call         r13     2     4
.line	1144	jmp            0  l763
.line	1144	gettable     r18   r17  k140 ; k140 = "LevelSequenceType"
.line	1144	gettable     r19    r5  k141 ; k141 = "ECharSpecLvSeq_Weapo" (truncated)
.line	1144	eq             0   r18   r19
.line	1144	jmp            0  l763
.line	1144	gettable     r18   r17  k142 ; k142 = "LevelSequenceConfig"
.line	1144	test         r18     0
.line	1144	jmp            0  l554
.line	1144	gettable     r19   r18  k143 ; k143 = "LevelSequenceDuratio" (truncated)
.line	1144	le             0   r19   k99 ; k99 = 0
.line	1144	jmp            0  l640
.label	l554
.line	1144	gettabup     r19    u1    k3 ; k3 = "print"
.line	1144	gettabup     r20    u1    k4 ; k4 = "bWriteLog"
.line	1144	test         r20     0
.line	1144	jmp            0  l636
.line	1144	gettabup     r20    u1    k5 ; k5 = "table"
.line	1144	gettable     r20   r20    k6 ; k6 = "concat"
.line	1144	newtable     r21     1     0
.line	1144	getupval     r22    u2
.line	1144	loadk        r23    k7 ; k7 = 18
.line	1144	loadk        r24    k8 ; k8 = 68
.line	1144	loadk        r25    k9 ; k9 = 195
.line	1144	loadk        r26   k10 ; k10 = 96
.line	1144	loadk        r27   k11 ; k11 = 191
.line	1144	loadk        r28   k12 ; k12 = 228
.line	1144	loadk        r29   k13 ; k13 = 49
.line	1144	loadk        r30   k14 ; k14 = 70
.line	1144	loadk        r31   k15 ; k15 = 167
.line	1144	loadk        r32   k16 ; k16 = 201
.line	1144	loadk        r33   k17 ; k17 = 121
.line	1144	loadk        r34   k18 ; k18 = 57
.line	1144	loadk        r35   k19 ; k19 = 251
.line	1144	loadk        r36   k20 ; k20 = 182
.line	1144	loadk        r37   k21 ; k21 = 126
.line	1144	loadk        r38   k22 ; k22 = 130
.line	1144	loadk        r39   k23 ; k23 = 244
.line	1144	loadk        r40   k24 ; k24 = 100
.line	1144	loadk        r41   k25 ; k25 = 174
.line	1144	loadk        r42   k26 ; k26 = 112
.line	1144	loadk        r43   k27 ; k27 = 81
.line	1144	loadk        r44   k28 ; k28 = 227
.line	1144	loadk        r45   k29 ; k29 = 75
.line	1144	loadk        r46   k30 ; k30 = 99
.line	1144	loadk        r47   k31 ; k31 = 171
.line	1144	loadk        r48   k32 ; k32 = 200
.line	1144	loadk        r49   k33 ; k33 = 89
.line	1144	loadk        r50   k34 ; k34 = 50
.line	1144	loadk        r51   k35 ; k35 = 231
.line	1144	loadk        r52   k36 ; k36 = 170
.line	1144	loadk        r53   k37 ; k37 = 107
.line	1144	loadk        r54   k38 ; k38 = 239
.line	1144	loadk        r55   k39 ; k39 = 214
.line	1144	loadk        r56   k40 ; k40 = 127
.line	1144	loadk        r57   k41 ; k41 = 153
.line	1144	loadk        r58   k42 ; k42 = 87
.line	1144	loadk        r59   k43 ; k43 = 85
.line	1144	loadk        r60   k44 ; k44 = 245
.line	1144	loadk        r61   k45 ; k45 = 76
.line	1144	loadk        r62   k46 ; k46 = 54
.line	1144	call         r22    41     2
.line	1144	getupval     r23    u2
.line	1144	loadk        r24   k47 ; k47 = 6
.line	1144	loadk        r25   k48 ; k48 = 67
.line	1144	loadk        r26   k49 ; k49 = 216
.line	1144	loadk        r27   k50 ; k50 = 108
.line	1144	loadk        r28   k51 ; k51 = 166
.line	1144	loadk        r29   k52 ; k52 = 129
.line	1144	loadk        r30  k144 ; k144 = 10
.line	1144	loadk        r31  k101 ; k101 = 22
.line	1144	loadk        r32   k41 ; k41 = 153
.line	1144	loadk        r33   k16 ; k16 = 201
.line	1144	loadk        r34  k145 ; k145 = 124
.line	1144	loadk        r35  k146 ; k146 = 47
.line	1144	loadk        r36  k147 ; k147 = 254
.line	1144	loadk        r37  k148 ; k148 = 138
.line	1144	loadk        r38   k73 ; k73 = 117
.line	1144	loadk        r39   k16 ; k16 = 201
.line	1144	loadk        r40  k149 ; k149 = 198
.line	1144	loadk        r41   k24 ; k24 = 100
.line	1144	loadk        r42   k72 ; k72 = 180
.line	1144	loadk        r43   k77 ; k77 = 80
.line	1144	loadk        r44  k107 ; k107 = 65
.line	1144	loadk        r45  k105 ; k105 = 210
.line	1144	loadk        r46  k126 ; k126 = 86
.line	1144	loadk        r47  k150 ; k150 = 104
.line	1144	loadk        r48  k151 ; k151 = 163
.line	1144	loadk        r49  k109 ; k109 = 213
.line	1144	loadk        r50  k152 ; k152 = 125
.line	1144	loadk        r51   k58 ; k58 = 122
.line	1144	loadk        r52   k11 ; k11 = 191
.line	1144	call         r23    30     0
.line	1144	setlist      r21     0     1
.line	1144	call         r20     2     2
.label	l636
.line	1144	move         r21   r18
.line	1144	call         r19     3     1
.line	1144	loadk        r19  k153 ; k153 = 3
.line	1144	return       r19     2
.label	l640
.line	1144	gettable     r19   r18  k154 ; k154 = "SequenceActorTemplat" (truncated)
.line	1144	self         r19   r19  k155 ; k155 = "IsNull"
.line	1144	call         r19     2     2
.line	1144	test         r19     1
.line	1144	jmp            0  l652
.line	1144	gettable     r19   r18  k156 ; k156 = "LevelSequence"
.line	1144	self         r19   r19  k157 ; k157 = "ToSoftObjectPath"
.line	1144	call         r19     2     2
.line	1144	self         r19   r19  k155 ; k155 = "IsNull"
.line	1144	call         r19     2     2
.line	1144	test         r19     0
.line	1144	jmp            0  l761
.label	l652
.line	1144	gettabup     r19    u1    k3 ; k3 = "print"
.line	1144	gettabup     r20    u1    k4 ; k4 = "bWriteLog"
.line	1144	test         r20     0
.line	1144	jmp            0  l758
.line	1144	gettabup     r20    u1    k5 ; k5 = "table"
.line	1144	gettable     r20   r20    k6 ; k6 = "concat"
.line	1144	newtable     r21     2     0
.line	1144	getupval     r22    u2
.line	1144	loadk        r23    k7 ; k7 = 18
.line	1144	loadk        r24    k8 ; k8 = 68
.line	1144	loadk        r25    k9 ; k9 = 195
.line	1144	loadk        r26   k10 ; k10 = 96
.line	1144	loadk        r27   k11 ; k11 = 191
.line	1144	loadk        r28   k12 ; k12 = 228
.line	1144	loadk        r29   k13 ; k13 = 49
.line	1144	loadk        r30   k14 ; k14 = 70
.line	1144	loadk        r31   k15 ; k15 = 167
.line	1144	loadk        r32   k16 ; k16 = 201
.line	1144	loadk        r33   k17 ; k17 = 121
.line	1144	loadk        r34   k18 ; k18 = 57
.line	1144	loadk        r35   k19 ; k19 = 251
.line	1144	loadk        r36   k20 ; k20 = 182
.line	1144	loadk        r37   k21 ; k21 = 126
.line	1144	loadk        r38   k22 ; k22 = 130
.line	1144	loadk        r39   k23 ; k23 = 244
.line	1144	loadk        r40   k24 ; k24 = 100
.line	1144	loadk        r41   k25 ; k25 = 174
.line	1144	loadk        r42   k26 ; k26 = 112
.line	1144	loadk        r43   k27 ; k27 = 81
.line	1144	loadk        r44   k28 ; k28 = 227
.line	1144	loadk        r45   k29 ; k29 = 75
.line	1144	loadk        r46   k30 ; k30 = 99
.line	1144	loadk        r47   k31 ; k31 = 171
.line	1144	loadk        r48   k32 ; k32 = 200
.line	1144	loadk        r49   k33 ; k33 = 89
.line	1144	loadk        r50   k34 ; k34 = 50
.line	1144	loadk        r51   k35 ; k35 = 231
.line	1144	loadk        r52   k36 ; k36 = 170
.line	1144	loadk        r53   k37 ; k37 = 107
.line	1144	loadk        r54   k38 ; k38 = 239
.line	1144	loadk        r55   k39 ; k39 = 214
.line	1144	loadk        r56   k40 ; k40 = 127
.line	1144	loadk        r57   k41 ; k41 = 153
.line	1144	loadk        r58   k42 ; k42 = 87
.line	1144	loadk        r59   k43 ; k43 = 85
.line	1144	loadk        r60   k44 ; k44 = 245
.line	1144	loadk        r61   k45 ; k45 = 76
.line	1144	loadk        r62   k46 ; k46 = 54
.line	1144	call         r22    41     2
.line	1144	getupval     r23    u2
.line	1144	loadk        r24   k47 ; k47 = 6
.line	1144	loadk        r25   k48 ; k48 = 67
.line	1144	loadk        r26   k49 ; k49 = 216
.line	1144	loadk        r27   k50 ; k50 = 108
.line	1144	loadk        r28   k51 ; k51 = 166
.line	1144	loadk        r29   k52 ; k52 = 129
.line	1144	loadk        r30  k158 ; k158 = 13
.line	1144	loadk        r31  k101 ; k101 = 22
.line	1144	loadk        r32  k106 ; k106 = 187
.line	1144	loadk        r33  k159 ; k159 = 217
.line	1144	loadk        r34   k62 ; k62 = 102
.line	1144	loadk        r35   k87 ; k87 = 38
.line	1144	loadk        r36  k160 ; k160 = 178
.line	1144	loadk        r37  k148 ; k148 = 138
.line	1144	loadk        r38   k73 ; k73 = 117
.line	1144	loadk        r39   k16 ; k16 = 201
.line	1144	loadk        r40  k149 ; k149 = 198
.line	1144	loadk        r41   k24 ; k24 = 100
.line	1144	loadk        r42   k72 ; k72 = 180
.line	1144	loadk        r43   k77 ; k77 = 80
.line	1144	loadk        r44  k107 ; k107 = 65
.line	1144	loadk        r45  k161 ; k161 = 208
.line	1144	loadk        r46  k162 ; k162 = 90
.line	1144	loadk        r47   k82 ; k82 = 114
.line	1144	loadk        r48   k36 ; k36 = 170
.line	1144	loadk        r49   k66 ; k66 = 206
.line	1144	loadk        r50  k163 ; k163 = 78
.line	1144	loadk        r51  k164 ; k164 = 63
.line	1144	loadk        r52   k38 ; k38 = 239
.line	1144	loadk        r53  k165 ; k165 = 185
.line	1144	loadk        r54   k50 ; k50 = 108
.line	1144	loadk        r55   k16 ; k16 = 201
.line	1144	loadk        r56  k166 ; k166 = 215
.line	1144	loadk        r57  k167 ; k167 = 116
.line	1144	loadk        r58  k168 ; k168 = 234
.line	1144	loadk        r59   k45 ; k45 = 76
.line	1144	loadk        r60   k14 ; k14 = 70
.line	1144	loadk        r61   k69 ; k69 = 161
.line	1144	loadk        r62   k92 ; k92 = 101
.line	1144	loadk        r63  k169 ; k169 = 115
.line	1144	call         r23    41     2
.line	1144	getupval     r24    u2
.line	1144	loadk        r25  k170 ; k170 = 53
.line	1144	loadk        r26  k171 ; k171 = 84
.line	1144	loadk        r27  k149 ; k149 = 198
.line	1144	loadk        r28   k77 ; k77 = 80
.line	1144	loadk        r29  k172 ; k172 = 177
.line	1144	loadk        r30  k161 ; k161 = 208
.line	1144	loadk        r31  k173 ; k173 = 60
.line	1144	loadk        r32   k85 ; k85 = 83
.line	1144	loadk        r33  k106 ; k106 = 187
.line	1144	loadk        r34   k63 ; k63 = 207
.line	1144	loadk        r35  k120 ; k120 = 111
.line	1144	call         r24    12     0
.line	1144	setlist      r21     0     1
.line	1144	call         r20     2     2
.label	l758
.line	1144	call         r19     2     1
.line	1144	loadk        r19  k153 ; k153 = 3
.line	1144	return       r19     2
.label	l761
.line	1144	loadbool     r12     1     0
.line	1144	jmp            0  l765
.label	l763
.line	1144	move          r0    r0
.line	1144	move          r0    r0
.label	l765
.line	1144	test         r12     1
.line	1144	jmp            0  l798
.line	1144	gettabup     r13    u1  k174 ; k174 = "CDataTable"
.line	1144	gettable     r13   r13  k175 ; k175 = "GetTableData"
.line	1144	getupval     r14    u2
.line	1144	loadk        r15  k176 ; k176 = 20
.line	1144	loadk        r16  k171 ; k171 = 84
.line	1144	loadk        r17  k177 ; k177 = 203
.line	1144	loadk        r18  k169 ; k169 = 115
.line	1144	loadk        r19  k106 ; k106 = 187
.line	1144	loadk        r20   k63 ; k63 = 207
.line	1144	loadk        r21  k144 ; k144 = 10
.line	1144	loadk        r22  k178 ; k178 = 94
.line	1144	loadk        r23  k179 ; k179 = 176
.line	1144	loadk        r24   k63 ; k63 = 207
.line	1144	loadk        r25  k180 ; k180 = 97
.line	1144	loadk        r26  k110 ; k110 = 25
.line	1144	loadk        r27  k181 ; k181 = 249
.line	1144	loadk        r28  k179 ; k179 = 176
.line	1144	loadk        r29  k145 ; k145 = 124
.line	1144	loadk        r30  k182 ; k182 = 212
.line	1144	call         r14    17     2
.line	1144	move         r15   r10
.line	1144	call         r13     3     2
.line	1144	test         r13     0
.line	1144	jmp            0  l796
.line	1144	gettable     r14   r13  k183 ; k183 = "LevelSequencePath"
.line	1144	getupval     r15    u2
.line	1144	call         r15     1     2
.line	1144	eq             0   r14   r15
.line	1144	jmp            0  l798
.label	l796
.line	1144	loadk        r14  k153 ; k153 = 3
.line	1144	return       r14     2
.label	l798
.line	1144	gettable     r13    r1  k184 ; k184 = "CurrentStates"
.line	1144	gettabup     r14    u1  k185 ; k185 = "UEnums"
.line	1144	gettable     r14   r14  k186 ; k186 = "EPawnState"
.line	1144	gettable     r14   r14  k187 ; k187 = "Stand"
.line	1144	shl          r14  k129   r14 ; k129 = 1
.line	1144	eq             0   r13   r14
.line	1144	jmp            0  l812
.line	1144	gettable     r13    r1  k188 ; k188 = "IsHandleInFold"
.line	1144	test         r13     0
.line	1144	jmp            0  l812
.line	1144	self         r13    r1  k188 ; k188 = "IsHandleInFold"
.line	1144	call         r13     2     2
.line	1144	test         r13     0
.line	1144	jmp            0  l814
.label	l812
.line	1144	loadk        r13  k129 ; k129 = 1
.line	1144	return       r13     2
.label	l814
.line	1144	loadk        r13   k99 ; k99 = 0
.line	1144	move         r14    r9
.line	1144	return       r13     3
.line	1144	return        r0     1
.line	1144	move          r0    r0
.line	1144	move          r0    r0
.line	1144	return        r0     1

.function	main/f49

.source	null
.linedefined	1218
.lastlinedefined	1257
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	14	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	22	true

.constant	k0	"GetPlayerCharacter"
.constant	k1	"slua"
.constant	k2	"isValid"
.constant	k3	"require"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	4
.constant	k7	80
.constant	k8	199
.constant	k9	102
.constant	k10	152
.constant	k11	212
.constant	k12	40
.constant	k13	24
.constant	k14	195
.constant	k15	110
.constant	k16	100
.constant	k17	222
.constant	k18	176
.constant	k19	114
.constant	k20	202
.constant	k21	210
.constant	k22	115
.constant	k23	163
.constant	k24	29
.constant	k25	99
.constant	k26	240
.constant	k27	84
.constant	k28	149
.constant	k29	208
.constant	k30	123
.constant	k31	35
.constant	k32	172
.constant	k33	136
.constant	k34	118
.constant	k35	201
.constant	k36	215
.constant	k37	112
.constant	k38	184
.constant	k39	13
.constant	k40	113
.constant	k41	236
.constant	k42	70
.constant	k43	98
.constant	k44	38
.constant	k45	31
.constant	k46	198
.constant	k47	108
.constant	k48	179
.constant	k49	200
.constant	k50	42
.constant	k51	105
.constant	k52	193
.constant	k53	101
.constant	k54	62
.constant	k55	247
.constant	k56	"bCustomWeaponShow"
.constant	k57	"CustomWeaponShowEmoteID"
.constant	k58	0
.constant	k59	"print"
.constant	k60	"bWriteLog"
.constant	k61	18
.constant	k62	68
.constant	k63	96
.constant	k64	191
.constant	k65	228
.constant	k66	49
.constant	k67	167
.constant	k68	121
.constant	k69	57
.constant	k70	251
.constant	k71	182
.constant	k72	126
.constant	k73	130
.constant	k74	231
.constant	k75	119
.constant	k76	75
.constant	k77	81
.constant	k78	166
.constant	k79	93
.constant	k80	47
.constant	k81	233
.constant	k82	235
.constant	k83	214
.constant	k84	190
.constant	k85	76
.constant	k86	89
.constant	k87	51
.constant	k88	94
.constant	k89	196
.constant	k90	188
.constant	k91	206
.constant	k92	22
.constant	k93	144
.constant	k94	"PlayEmote"
.constant	k95	"GetCurrentCheckGunState"
.constant	k96	"GetPlayerControllerSafety"
.constant	k97	"DisplayGameTipWithMsgID"
.constant	k98	1
.constant	k99	44556
.constant	k100	2
.constant	k101	43600
.constant	k102	3
.constant	k103	43601
.constant	k104	83
.constant	k105	220
.constant	k106	194
.constant	k107	175
.constant	k108	1014405
.constant	k109	"GetSkillManager"
.constant	k110	"Game"
.constant	k111	"IsValid"
.constant	k112	"IsCastingSkillID"
.constant	k113	"ForceSyncMovementState"
.constant	k114	"TriggerEntrySkillWithID"
.constant	k115	"SubsystemMgr"
.constant	k116	"Get"
.constant	k117	186
.constant	k118	213
.constant	k119	122
.constant	k120	203
.constant	k121	71
.constant	k122	43
.constant	k123	252
.constant	k124	221
.constant	k125	"AddValueByKey"
.constant	k126	19
.constant	k127	177
.constant	k128	211
.constant	k129	28
.constant	k130	69
.constant	k131	111
.constant	k132	226
.constant	k133	219
.constant	k134	185
.constant	k135	88
.constant	k136	253
.constant	k137	86

.line	1218	gettabup      r1    u0    k0 ; k0 = "GetPlayerCharacter"
.line	1218	call          r1     1     2
.line	1218	test          r1     0
.line	1218	jmp            0   l11
.line	1218	gettabup      r2    u1    k1 ; k1 = "slua"
.line	1218	gettable      r2    r2    k2 ; k2 = "isValid"
.line	1218	move          r3    r1
.line	1218	call          r2     2     2
.line	1218	test          r2     1
.line	1218	jmp            0   l12
.label	l11
.line	1218	return        r0     1
.label	l12
.line	1218	gettabup      r2    u1    k3 ; k3 = "require"
.line	1218	gettabup      r3    u1    k4 ; k4 = "table"
.line	1218	gettable      r3    r3    k5 ; k5 = "concat"
.line	1218	newtable      r4     1     0
.line	1218	getupval      r5    u2
.line	1218	loadk         r6    k6 ; k6 = 4
.line	1218	loadk         r7    k7 ; k7 = 80
.line	1218	loadk         r8    k8 ; k8 = 199
.line	1218	loadk         r9    k9 ; k9 = 102
.line	1218	loadk        r10   k10 ; k10 = 152
.line	1218	loadk        r11   k11 ; k11 = 212
.line	1218	loadk        r12   k12 ; k12 = 40
.line	1218	loadk        r13   k13 ; k13 = 24
.line	1218	loadk        r14   k10 ; k10 = 152
.line	1218	loadk        r15   k14 ; k14 = 195
.line	1218	loadk        r16   k15 ; k15 = 110
.line	1218	loadk        r17   k16 ; k16 = 100
.line	1218	loadk        r18   k17 ; k17 = 222
.line	1218	loadk        r19   k18 ; k18 = 176
.line	1218	loadk        r20   k19 ; k19 = 114
.line	1218	loadk        r21   k20 ; k20 = 202
.line	1218	loadk        r22   k21 ; k21 = 210
.line	1218	loadk        r23   k22 ; k22 = 115
.line	1218	loadk        r24   k23 ; k23 = 163
.line	1218	loadk        r25   k24 ; k24 = 29
.line	1218	loadk        r26   k25 ; k25 = 99
.line	1218	loadk        r27   k26 ; k26 = 240
.line	1218	loadk        r28   k27 ; k27 = 84
.line	1218	loadk        r29   k25 ; k25 = 99
.line	1218	loadk        r30   k28 ; k28 = 149
.line	1218	loadk        r31   k29 ; k29 = 208
.line	1218	loadk        r32   k30 ; k30 = 123
.line	1218	loadk        r33   k31 ; k31 = 35
.line	1218	loadk        r34   k32 ; k32 = 172
.line	1218	loadk        r35   k33 ; k33 = 136
.line	1218	loadk        r36   k34 ; k34 = 118
.line	1218	loadk        r37   k35 ; k35 = 201
.line	1218	loadk        r38   k36 ; k36 = 215
.line	1218	loadk        r39   k37 ; k37 = 112
.line	1218	loadk        r40   k38 ; k38 = 184
.line	1218	loadk        r41   k39 ; k39 = 13
.line	1218	loadk        r42   k40 ; k40 = 113
.line	1218	loadk        r43   k41 ; k41 = 236
.line	1218	loadk        r44   k42 ; k42 = 70
.line	1218	loadk        r45   k43 ; k43 = 98
.line	1218	call          r5    41     2
.line	1218	getupval      r6    u2
.line	1218	loadk         r7   k44 ; k44 = 38
.line	1218	loadk         r8   k45 ; k45 = 31
.line	1218	loadk         r9   k46 ; k46 = 198
.line	1218	loadk        r10   k47 ; k47 = 108
.line	1218	loadk        r11   k48 ; k48 = 179
.line	1218	loadk        r12   k49 ; k49 = 200
.line	1218	loadk        r13   k50 ; k50 = 42
.line	1218	loadk        r14   k51 ; k51 = 105
.line	1218	loadk        r15   k18 ; k18 = 176
.line	1218	loadk        r16   k52 ; k52 = 193
.line	1218	loadk        r17   k53 ; k53 = 101
.line	1218	loadk        r18   k54 ; k54 = 62
.line	1218	loadk        r19   k55 ; k55 = 247
.line	1218	call          r6    14     0
.line	1218	setlist       r4     0     1
.line	1218	call          r3     2     2
.line	1218	call          r2     2     2
.line	1218	gettable      r3    r2   k56 ; k56 = "bCustomWeaponShow"
.line	1218	test          r3     0
.line	1218	jmp            0  l158
.line	1218	gettable      r3    r2   k57 ; k57 = "CustomWeaponShowEmot" (truncated)
.line	1218	lt             0   k58    r3 ; k58 = 0
.line	1218	jmp            0  l158
.line	1218	gettabup      r3    u1   k59 ; k59 = "print"
.line	1218	gettabup      r4    u1   k60 ; k60 = "bWriteLog"
.line	1218	test          r4     0
.line	1218	jmp            0  l151
.line	1218	gettabup      r4    u1    k4 ; k4 = "table"
.line	1218	gettable      r4    r4    k5 ; k5 = "concat"
.line	1218	newtable      r5     1     0
.line	1218	getupval      r6    u2
.line	1218	loadk         r7   k61 ; k61 = 18
.line	1218	loadk         r8   k62 ; k62 = 68
.line	1218	loadk         r9   k14 ; k14 = 195
.line	1218	loadk        r10   k63 ; k63 = 96
.line	1218	loadk        r11   k64 ; k64 = 191
.line	1218	loadk        r12   k65 ; k65 = 228
.line	1218	loadk        r13   k66 ; k66 = 49
.line	1218	loadk        r14   k42 ; k42 = 70
.line	1218	loadk        r15   k67 ; k67 = 167
.line	1218	loadk        r16   k35 ; k35 = 201
.line	1218	loadk        r17   k68 ; k68 = 121
.line	1218	loadk        r18   k69 ; k69 = 57
.line	1218	loadk        r19   k70 ; k70 = 251
.line	1218	loadk        r20   k71 ; k71 = 182
.line	1218	loadk        r21   k72 ; k72 = 126
.line	1218	loadk        r22   k73 ; k73 = 130
.line	1218	loadk        r23   k74 ; k74 = 231
.line	1218	loadk        r24   k22 ; k22 = 115
.line	1218	loadk        r25   k23 ; k23 = 163
.line	1218	loadk        r26   k75 ; k75 = 119
.line	1218	loadk        r27   k76 ; k76 = 75
.line	1218	loadk        r28   k21 ; k21 = 210
.line	1218	loadk        r29   k77 ; k77 = 81
.line	1218	loadk        r30   k25 ; k25 = 99
.line	1218	loadk        r31   k78 ; k78 = 166
.line	1218	loadk        r32   k36 ; k36 = 215
.line	1218	loadk        r33   k79 ; k79 = 93
.line	1218	loadk        r34   k80 ; k80 = 47
.line	1218	loadk        r35   k41 ; k41 = 236
.line	1218	loadk        r36   k81 ; k81 = 233
.line	1218	loadk        r37   k43 ; k43 = 98
.line	1218	loadk        r38   k82 ; k82 = 235
.line	1218	loadk        r39   k83 ; k83 = 214
.line	1218	loadk        r40   k43 ; k43 = 98
.line	1218	loadk        r41   k84 ; k84 = 190
.line	1218	loadk        r42   k85 ; k85 = 76
.line	1218	loadk        r43   k86 ; k86 = 89
.line	1218	loadk        r44   k83 ; k83 = 214
.line	1218	loadk        r45   k85 ; k85 = 76
.line	1218	loadk        r46   k75 ; k75 = 119
.line	1218	call          r6    41     2
.line	1218	getupval      r7    u2
.line	1218	loadk         r8   k87 ; k87 = 51
.line	1218	loadk         r9   k88 ; k88 = 94
.line	1218	loadk        r10   k89 ; k89 = 196
.line	1218	loadk        r11    k7 ; k7 = 80
.line	1218	loadk        r12   k90 ; k90 = 188
.line	1218	loadk        r13   k91 ; k91 = 206
.line	1218	loadk        r14   k54 ; k54 = 62
.line	1218	loadk        r15   k92 ; k92 = 22
.line	1218	loadk        r16   k93 ; k93 = 144
.line	1218	loadk        r17   k52 ; k52 = 193
.line	1218	loadk        r18   k53 ; k53 = 101
.line	1218	loadk        r19   k54 ; k54 = 62
.line	1218	loadk        r20   k55 ; k55 = 247
.line	1218	loadk        r21   k93 ; k93 = 144
.line	1218	loadk        r22   k27 ; k27 = 84
.line	1218	loadk        r23   k73 ; k73 = 130
.line	1218	call          r7    17     0
.line	1218	setlist       r5     0     1
.line	1218	call          r4     2     2
.label	l151
.line	1218	gettable      r5    r2   k57 ; k57 = "CustomWeaponShowEmot" (truncated)
.line	1218	call          r3     3     1
.line	1218	gettable      r3    r2   k94 ; k94 = "PlayEmote"
.line	1218	move          r4    r1
.line	1218	gettable      r5    r2   k57 ; k57 = "CustomWeaponShowEmot" (truncated)
.line	1218	call          r3     3     1
.line	1218	return        r0     1
.label	l158
.line	1218	gettabup      r3    u3   k95 ; k95 = "GetCurrentCheckGunSt" (truncated)
.line	1218	call          r3     1     3
.line	1218	eq             1    r3   k58 ; k58 = 0
.line	1218	jmp            0  l237
.line	1218	self          r5    r1   k96 ; k96 = "GetPlayerControllerS" (truncated)
.line	1218	call          r5     2     2
.line	1218	test          r5     0
.line	1218	jmp            0  l236
.line	1218	gettabup      r6    u1    k1 ; k1 = "slua"
.line	1218	gettable      r6    r6    k2 ; k2 = "isValid"
.line	1218	move          r7    r5
.line	1218	call          r6     2     2
.line	1218	test          r6     0
.line	1218	jmp            0  l236
.line	1218	gettable      r6    r5   k97 ; k97 = "DisplayGameTipWithMs" (truncated)
.line	1218	test          r6     0
.line	1218	jmp            0  l236
.line	1218	eq             0    r3   k98 ; k98 = 1
.line	1218	jmp            0  l181
.line	1218	self          r6    r5   k97 ; k97 = "DisplayGameTipWithMs" (truncated)
.line	1218	loadk         r8   k99 ; k99 = 44556
.line	1218	call          r6     3     1
.line	1218	jmp            0  l236
.label	l181
.line	1218	eq             0    r3  k100 ; k100 = 2
.line	1218	jmp            0  l187
.line	1218	self          r6    r5   k97 ; k97 = "DisplayGameTipWithMs" (truncated)
.line	1218	loadk         r8  k101 ; k101 = 43600
.line	1218	call          r6     3     1
.line	1218	jmp            0  l236
.label	l187
.line	1218	eq             0    r3  k102 ; k102 = 3
.line	1218	jmp            0  l193
.line	1218	self          r6    r5   k97 ; k97 = "DisplayGameTipWithMs" (truncated)
.line	1218	loadk         r8  k103 ; k103 = 43601
.line	1218	call          r6     3     1
.line	1218	jmp            0  l236
.label	l193
.line	1218	gettabup      r6    u1   k59 ; k59 = "print"
.line	1218	gettabup      r7    u1   k60 ; k60 = "bWriteLog"
.line	1218	test          r7     0
.line	1218	jmp            0  l234
.line	1218	getupval      r7    u2
.line	1218	loadk         r8   k61 ; k61 = 18
.line	1218	loadk         r9   k62 ; k62 = 68
.line	1218	loadk        r10   k14 ; k14 = 195
.line	1218	loadk        r11   k63 ; k63 = 96
.line	1218	loadk        r12   k64 ; k64 = 191
.line	1218	loadk        r13   k65 ; k65 = 228
.line	1218	loadk        r14   k66 ; k66 = 49
.line	1218	loadk        r15   k42 ; k42 = 70
.line	1218	loadk        r16   k67 ; k67 = 167
.line	1218	loadk        r17   k35 ; k35 = 201
.line	1218	loadk        r18   k68 ; k68 = 121
.line	1218	loadk        r19   k69 ; k69 = 57
.line	1218	loadk        r20   k70 ; k70 = 251
.line	1218	loadk        r21   k71 ; k71 = 182
.line	1218	loadk        r22   k72 ; k72 = 126
.line	1218	loadk        r23   k73 ; k73 = 130
.line	1218	loadk        r24   k74 ; k74 = 231
.line	1218	loadk        r25   k22 ; k22 = 115
.line	1218	loadk        r26   k23 ; k23 = 163
.line	1218	loadk        r27   k75 ; k75 = 119
.line	1218	loadk        r28   k76 ; k76 = 75
.line	1218	loadk        r29   k21 ; k21 = 210
.line	1218	loadk        r30   k77 ; k77 = 81
.line	1218	loadk        r31   k25 ; k25 = 99
.line	1218	loadk        r32   k78 ; k78 = 166
.line	1218	loadk        r33   k36 ; k36 = 215
.line	1218	loadk        r34   k79 ; k79 = 93
.line	1218	loadk        r35   k80 ; k80 = 47
.line	1218	loadk        r36   k41 ; k41 = 236
.line	1218	loadk        r37   k81 ; k81 = 233
.line	1218	loadk        r38  k104 ; k104 = 83
.line	1218	loadk        r39  k105 ; k105 = 220
.line	1218	loadk        r40  k106 ; k106 = 194
.line	1218	loadk        r41   k53 ; k53 = 101
.line	1218	loadk        r42  k107 ; k107 = 175
.line	1218	call          r7    36     2
.label	l234
.line	1218	move          r8    r3
.line	1218	call          r6     3     1
.label	l236
.line	1218	return        r0     1
.label	l237
.line	1218	loadk         r5  k108 ; k108 = 1014405
.line	1218	self          r6    r1  k109 ; k109 = "GetSkillManager"
.line	1218	call          r6     2     2
.line	1218	gettabup      r7    u1  k110 ; k110 = "Game"
.line	1218	self          r7    r7  k111 ; k111 = "IsValid"
.line	1218	move          r9    r6
.line	1218	call          r7     3     2
.line	1218	test          r7     0
.line	1218	jmp            0  l252
.line	1218	self          r7    r6  k112 ; k112 = "IsCastingSkillID"
.line	1218	move          r9    r5
.line	1218	call          r7     3     2
.line	1218	test          r7     0
.line	1218	jmp            0  l252
.line	1218	return        r0     1
.label	l252
.line	1218	gettabup      r7    u1   k59 ; k59 = "print"
.line	1218	gettabup      r8    u1   k60 ; k60 = "bWriteLog"
.line	1218	test          r8     0
.line	1218	jmp            0  l287
.line	1218	getupval      r8    u2
.line	1218	loadk         r9   k61 ; k61 = 18
.line	1218	loadk        r10   k62 ; k62 = 68
.line	1218	loadk        r11   k14 ; k14 = 195
.line	1218	loadk        r12   k63 ; k63 = 96
.line	1218	loadk        r13   k64 ; k64 = 191
.line	1218	loadk        r14   k65 ; k65 = 228
.line	1218	loadk        r15   k66 ; k66 = 49
.line	1218	loadk        r16   k42 ; k42 = 70
.line	1218	loadk        r17   k67 ; k67 = 167
.line	1218	loadk        r18   k35 ; k35 = 201
.line	1218	loadk        r19   k68 ; k68 = 121
.line	1218	loadk        r20   k69 ; k69 = 57
.line	1218	loadk        r21   k70 ; k70 = 251
.line	1218	loadk        r22   k71 ; k71 = 182
.line	1218	loadk        r23   k72 ; k72 = 126
.line	1218	loadk        r24   k73 ; k73 = 130
.line	1218	loadk        r25   k74 ; k74 = 231
.line	1218	loadk        r26   k22 ; k22 = 115
.line	1218	loadk        r27   k23 ; k23 = 163
.line	1218	loadk        r28   k75 ; k75 = 119
.line	1218	loadk        r29   k76 ; k76 = 75
.line	1218	loadk        r30   k21 ; k21 = 210
.line	1218	loadk        r31   k77 ; k77 = 81
.line	1218	loadk        r32   k25 ; k25 = 99
.line	1218	loadk        r33   k78 ; k78 = 166
.line	1218	loadk        r34   k36 ; k36 = 215
.line	1218	loadk        r35   k79 ; k79 = 93
.line	1218	loadk        r36   k80 ; k80 = 47
.line	1218	loadk        r37   k41 ; k41 = 236
.line	1218	call          r8    30     2
.label	l287
.line	1218	move          r9    r4
.line	1218	call          r7     3     1
.line	1218	self          r7    r1  k113 ; k113 = "ForceSyncMovementSta" (truncated)
.line	1218	call          r7     2     1
.line	1218	self          r7    r1  k114 ; k114 = "TriggerEntrySkillWit" (truncated)
.line	1218	move          r9    r5
.line	1218	loadbool     r10     1     0
.line	1218	call          r7     4     1
.line	1218	gettabup      r7    u1  k115 ; k115 = "SubsystemMgr"
.line	1218	self          r7    r7  k116 ; k116 = "Get"
.line	1218	getupval      r9    u2
.line	1218	loadk        r10   k58 ; k58 = 0
.line	1218	loadk        r11   k79 ; k79 = 93
.line	1218	loadk        r12   k14 ; k14 = 195
.line	1218	loadk        r13    k9 ; k9 = 102
.line	1218	loadk        r14  k117 ; k117 = 186
.line	1218	loadk        r15  k118 ; k118 = 213
.line	1218	loadk        r16   k24 ; k24 = 29
.line	1218	loadk        r17  k119 ; k119 = 122
.line	1218	loadk        r18  k117 ; k117 = 186
.line	1218	loadk        r19  k120 ; k120 = 203
.line	1218	loadk        r20  k121 ; k121 = 71
.line	1218	loadk        r21  k122 ; k122 = 43
.line	1218	loadk        r22  k123 ; k123 = 252
.line	1218	loadk        r23   k38 ; k38 = 184
.line	1218	loadk        r24   k75 ; k75 = 119
.line	1218	loadk        r25  k124 ; k124 = 221
.line	1218	loadk        r26   k52 ; k52 = 193
.line	1218	call          r9    18     2
.line	1218	call          r7     3     2
.line	1218	test          r7     0
.line	1218	jmp            0  l349
.line	1218	self          r8    r7  k125 ; k125 = "AddValueByKey"
.line	1218	getupval     r10    u2
.line	1218	loadk        r11  k126 ; k126 = 19
.line	1218	loadk        r12   k79 ; k79 = 93
.line	1218	loadk        r13  k120 ; k120 = 203
.line	1218	loadk        r14  k119 ; k119 = 122
.line	1218	loadk        r15  k127 ; k127 = 177
.line	1218	loadk        r16  k128 ; k128 = 211
.line	1218	loadk        r17  k129 ; k129 = 28
.line	1218	loadk        r18  k130 ; k130 = 69
.line	1218	loadk        r19   k18 ; k18 = 176
.line	1218	loadk        r20   k70 ; k70 = 251
.line	1218	loadk        r21  k131 ; k131 = 111
.line	1218	loadk        r22  k122 ; k122 = 43
.line	1218	loadk        r23  k132 ; k132 = 226
.line	1218	loadk        r24   k71 ; k71 = 182
.line	1218	loadk        r25   k72 ; k72 = 126
.line	1218	loadk        r26   k70 ; k70 = 251
.line	1218	loadk        r27  k133 ; k133 = 219
.line	1218	loadk        r28   k16 ; k16 = 100
.line	1218	loadk        r29  k134 ; k134 = 185
.line	1218	loadk        r30  k135 ; k135 = 88
.line	1218	loadk        r31   k43 ; k43 = 98
.line	1218	loadk        r32  k136 ; k136 = 253
.line	1218	loadk        r33  k137 ; k137 = 86
.line	1218	loadk        r34   k40 ; k40 = 113
.line	1218	call         r10    25     2
.line	1218	move         r11    r4
.line	1218	loadk        r12   k98 ; k98 = 1
.line	1218	call          r8     5     1
.label	l349
.line	1218	return        r0     1
.line	1218	move          r0    r0
.line	1218	return        r0     1

.function	main/f50

.source	null
.linedefined	1262
.lastlinedefined	1265
.numparams	0
.is_vararg	0
.maxstacksize	44

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	4
.constant	k4	80
.constant	k5	199
.constant	k6	102
.constant	k7	152
.constant	k8	212
.constant	k9	40
.constant	k10	24
.constant	k11	148
.constant	k12	207
.constant	k13	126
.constant	k14	35
.constant	k15	228
.constant	k16	176
.constant	k17	100
.constant	k18	193
.constant	k19	157
.constant	k20	66
.constant	k21	181
.constant	k22	94
.constant	k23	73
.constant	k24	244
.constant	k25	75
.constant	k26	101
.constant	k27	172
.constant	k28	221
.constant	k29	118
.constant	k30	51
.constant	k31	248
.constant	k32	46
.constant	k33	239
.constant	k34	194
.constant	k35	124
.constant	k36	175
.constant	k37	115
.constant	k38	88
.constant	k39	224
.constant	k40	56
.constant	k41	27
.constant	k42	98
.constant	k43	223
.constant	k44	106
.constant	k45	160
.constant	k46	143
.constant	k47	29
.constant	k48	87
.constant	k49	188
.constant	k50	192
.constant	k51	36
.constant	k52	18
.constant	k53	121
.constant	k54	204
.constant	k55	231
.constant	k56	96
.constant	k57	179
.constant	k58	95
.constant	k59	103
.constant	k60	254
.constant	k61	84
.constant	k62	170
.constant	k63	210
.constant	k64	127
.constant	k65	52
.constant	k66	246
.constant	k67	"GetLocalButtonState"

.line	1262	gettabup      r0    u0    k0 ; k0 = "require"
.line	1262	gettabup      r1    u0    k1 ; k1 = "table"
.line	1262	gettable      r1    r1    k2 ; k2 = "concat"
.line	1262	newtable      r2     1     0
.line	1262	getupval      r3    u1
.line	1262	loadk         r4    k3 ; k3 = 4
.line	1262	loadk         r5    k4 ; k4 = 80
.line	1262	loadk         r6    k5 ; k5 = 199
.line	1262	loadk         r7    k6 ; k6 = 102
.line	1262	loadk         r8    k7 ; k7 = 152
.line	1262	loadk         r9    k8 ; k8 = 212
.line	1262	loadk        r10    k9 ; k9 = 40
.line	1262	loadk        r11   k10 ; k10 = 24
.line	1262	loadk        r12   k11 ; k11 = 148
.line	1262	loadk        r13   k12 ; k12 = 207
.line	1262	loadk        r14   k13 ; k13 = 126
.line	1262	loadk        r15   k14 ; k14 = 35
.line	1262	loadk        r16   k15 ; k15 = 228
.line	1262	loadk        r17   k16 ; k16 = 176
.line	1262	loadk        r18   k17 ; k17 = 100
.line	1262	loadk        r19   k18 ; k18 = 193
.line	1262	loadk        r20   k19 ; k19 = 157
.line	1262	loadk        r21   k20 ; k20 = 66
.line	1262	loadk        r22   k21 ; k21 = 181
.line	1262	loadk        r23   k22 ; k22 = 94
.line	1262	loadk        r24   k23 ; k23 = 73
.line	1262	loadk        r25   k24 ; k24 = 244
.line	1262	loadk        r26   k25 ; k25 = 75
.line	1262	loadk        r27   k26 ; k26 = 101
.line	1262	loadk        r28   k27 ; k27 = 172
.line	1262	loadk        r29   k28 ; k28 = 221
.line	1262	loadk        r30   k29 ; k29 = 118
.line	1262	loadk        r31   k30 ; k30 = 51
.line	1262	loadk        r32   k31 ; k31 = 248
.line	1262	loadk        r33   k27 ; k27 = 172
.line	1262	loadk        r34   k32 ; k32 = 46
.line	1262	loadk        r35   k33 ; k33 = 239
.line	1262	loadk        r36   k34 ; k34 = 194
.line	1262	loadk        r37   k35 ; k35 = 124
.line	1262	loadk        r38   k36 ; k36 = 175
.line	1262	loadk        r39   k37 ; k37 = 115
.line	1262	loadk        r40   k38 ; k38 = 88
.line	1262	loadk        r41   k39 ; k39 = 224
.line	1262	loadk        r42    k4 ; k4 = 80
.line	1262	loadk        r43   k40 ; k40 = 56
.line	1262	call          r3    41     2
.line	1262	getupval      r4    u1
.line	1262	loadk         r5   k41 ; k41 = 27
.line	1262	loadk         r6   k42 ; k42 = 98
.line	1262	loadk         r7   k43 ; k43 = 223
.line	1262	loadk         r8   k44 ; k44 = 106
.line	1262	loadk         r9   k45 ; k45 = 160
.line	1262	loadk        r10   k46 ; k46 = 143
.line	1262	loadk        r11   k47 ; k47 = 29
.line	1262	loadk        r12   k48 ; k48 = 87
.line	1262	loadk        r13   k49 ; k49 = 188
.line	1262	loadk        r14   k50 ; k50 = 192
.line	1262	loadk        r15   k51 ; k51 = 36
.line	1262	loadk        r16   k52 ; k52 = 18
.line	1262	loadk        r17   k18 ; k18 = 193
.line	1262	loadk        r18   k27 ; k27 = 172
.line	1262	loadk        r19   k53 ; k53 = 121
.line	1262	loadk        r20   k54 ; k54 = 204
.line	1262	loadk        r21   k55 ; k55 = 231
.line	1262	loadk        r22   k56 ; k56 = 96
.line	1262	loadk        r23   k57 ; k57 = 179
.line	1262	loadk        r24   k58 ; k58 = 95
.line	1262	loadk        r25   k59 ; k59 = 103
.line	1262	loadk        r26   k60 ; k60 = 254
.line	1262	loadk        r27   k61 ; k61 = 84
.line	1262	loadk        r28   k29 ; k29 = 118
.line	1262	loadk        r29   k62 ; k62 = 170
.line	1262	loadk        r30   k63 ; k63 = 210
.line	1262	loadk        r31   k64 ; k64 = 127
.line	1262	loadk        r32   k65 ; k65 = 52
.line	1262	loadk        r33   k66 ; k66 = 246
.line	1262	call          r4    30     0
.line	1262	setlist       r2     0     1
.line	1262	call          r1     2     2
.line	1262	call          r0     2     2
.line	1262	gettable      r1    r0   k67 ; k67 = "GetLocalButtonState"
.line	1262	tailcall      r1     1
.line	1262	return        r1     0
.line	1262	return        r0     1
.line	1262	move          r0    r0
.line	1262	move          r0    r0
.line	1262	move          r0    r0
.line	1262	return        r0     1

.function	main/f51

.source	null
.linedefined	1267
.lastlinedefined	1277
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"slua"
.constant	k1	"isValid"
.constant	k2	"Image_XSuitTailRedPoint"
.constant	k3	"DataMgr"
.constant	k4	"roleData"
.constant	k5	"openID"
.constant	k6	"require"
.constant	k7	"table"
.constant	k8	"concat"
.constant	k9	32
.constant	k10	93
.constant	k11	195
.constant	k12	102
.constant	k13	186
.constant	k14	213
.constant	k15	103
.constant	k16	90
.constant	k17	203
.constant	k18	99
.constant	k19	41
.constant	k20	188
.constant	k21	149
.constant	k22	127
.constant	k23	223
.constant	k24	218
.constant	k25	98
.constant	k26	138
.constant	k27	95
.constant	k28	69
.constant	k29	232
.constant	k30	92
.constant	k31	116
.constant	k32	206
.constant	k33	60
.constant	k34	241
.constant	k35	231
.constant	k36	112
.constant	k37	196
.constant	k38	194
.constant	k39	104
.constant	k40	175
.constant	k41	81
.constant	k42	68
.constant	k43	243
.constant	k44	76
.constant	k45	48
.constant	k46	"LoadFileToTable_N"
.constant	k47	"ePlayerPrefsType"
.constant	k48	"eXSuitTailButtonSeen"
.constant	k49	1
.constant	k50	"SetWidgetVisibility"
.constant	k51	"UEnums"
.constant	k52	"ESlateVisibility"
.constant	k53	"SelfHitTestInvisible"
.constant	k54	"Collapsed"

.line	1267	gettabup      r2    u0    k0 ; k0 = "slua"
.line	1267	gettable      r2    r2    k1 ; k1 = "isValid"
.line	1267	gettable      r3    r0    k2 ; k2 = "Image_XSuitTailRedPo" (truncated)
.line	1267	call          r2     2     2
.line	1267	test          r2     1
.line	1267	jmp            0    l8
.line	1267	return        r0     1
.label	l8
.line	1267	loadbool      r2     0     0
.line	1267	test          r1     0
.line	1267	jmp            0   l83
.line	1267	gettabup      r3    u0    k3 ; k3 = "DataMgr"
.line	1267	test          r3     0
.line	1267	jmp            0   l83
.line	1267	gettabup      r3    u0    k3 ; k3 = "DataMgr"
.line	1267	gettable      r3    r3    k4 ; k4 = "roleData"
.line	1267	test          r3     0
.line	1267	jmp            0   l83
.line	1267	gettabup      r3    u0    k3 ; k3 = "DataMgr"
.line	1267	gettable      r3    r3    k4 ; k4 = "roleData"
.line	1267	gettable      r3    r3    k5 ; k5 = "openID"
.line	1267	test          r3     0
.line	1267	jmp            0   l83
.line	1267	gettabup      r3    u0    k6 ; k6 = "require"
.line	1267	gettabup      r4    u0    k7 ; k7 = "table"
.line	1267	gettable      r4    r4    k8 ; k8 = "concat"
.line	1267	newtable      r5     1     0
.line	1267	getupval      r6    u1
.line	1267	loadk         r7    k9 ; k9 = 32
.line	1267	loadk         r8   k10 ; k10 = 93
.line	1267	loadk         r9   k11 ; k11 = 195
.line	1267	loadk        r10   k12 ; k12 = 102
.line	1267	loadk        r11   k13 ; k13 = 186
.line	1267	loadk        r12   k14 ; k14 = 213
.line	1267	loadk        r13   k15 ; k15 = 103
.line	1267	loadk        r14   k16 ; k16 = 90
.line	1267	loadk        r15   k13 ; k13 = 186
.line	1267	loadk        r16   k17 ; k17 = 203
.line	1267	loadk        r17   k18 ; k18 = 99
.line	1267	loadk        r18   k19 ; k19 = 41
.line	1267	loadk        r19   k20 ; k20 = 188
.line	1267	loadk        r20   k21 ; k21 = 149
.line	1267	loadk        r21   k22 ; k22 = 127
.line	1267	loadk        r22   k23 ; k23 = 223
.line	1267	loadk        r23   k24 ; k24 = 218
.line	1267	loadk        r24   k25 ; k25 = 98
.line	1267	loadk        r25   k26 ; k26 = 138
.line	1267	loadk        r26   k27 ; k27 = 95
.line	1267	loadk        r27   k28 ; k28 = 69
.line	1267	loadk        r28   k29 ; k29 = 232
.line	1267	loadk        r29   k30 ; k30 = 92
.line	1267	loadk        r30   k31 ; k31 = 116
.line	1267	loadk        r31   k21 ; k21 = 149
.line	1267	loadk        r32   k32 ; k32 = 206
.line	1267	loadk        r33   k22 ; k22 = 127
.line	1267	loadk        r34   k33 ; k33 = 60
.line	1267	loadk        r35   k34 ; k34 = 241
.line	1267	loadk        r36   k35 ; k35 = 231
.line	1267	loadk        r37   k36 ; k36 = 112
.line	1267	loadk        r38   k37 ; k37 = 196
.line	1267	loadk        r39   k38 ; k38 = 194
.line	1267	loadk        r40   k39 ; k39 = 104
.line	1267	loadk        r41   k40 ; k40 = 175
.line	1267	loadk        r42   k41 ; k41 = 81
.line	1267	loadk        r43   k42 ; k42 = 68
.line	1267	loadk        r44   k43 ; k43 = 243
.line	1267	loadk        r45   k44 ; k44 = 76
.line	1267	loadk        r46   k36 ; k36 = 112
.line	1267	call          r6    41     2
.line	1267	getupval      r7    u1
.line	1267	loadk         r8   k45 ; k45 = 48
.line	1267	call          r7     2     0
.line	1267	setlist       r5     0     1
.line	1267	call          r4     2     2
.line	1267	call          r3     2     2
.line	1267	gettable      r4    r3   k46 ; k46 = "LoadFileToTable_N"
.line	1267	gettable      r5    r3   k47 ; k47 = "ePlayerPrefsType"
.line	1267	gettable      r5    r5   k48 ; k48 = "eXSuitTailButtonSeen"
.line	1267	call          r4     2     2
.line	1267	eq             0    r4   k49 ; k49 = 1
.line	1267	jmp            0   l82
.line	1267	loadbool      r2     0     1
.label	l82
.line	1267	loadbool      r2     1     0
.label	l83
.line	1267	gettable      r3    r0    k2 ; k2 = "Image_XSuitTailRedPo" (truncated)
.line	1267	self          r3    r3   k50 ; k50 = "SetWidgetVisibility"
.line	1267	test          r2     0
.line	1267	jmp            0   l92
.line	1267	gettabup      r5    u0   k51 ; k51 = "UEnums"
.line	1267	gettable      r5    r5   k52 ; k52 = "ESlateVisibility"
.line	1267	gettable      r5    r5   k53 ; k53 = "SelfHitTestInvisible"
.line	1267	test          r5     1
.line	1267	jmp            0   l95
.label	l92
.line	1267	gettabup      r5    u0   k51 ; k51 = "UEnums"
.line	1267	gettable      r5    r5   k52 ; k52 = "ESlateVisibility"
.line	1267	gettable      r5    r5   k54 ; k54 = "Collapsed"
.label	l95
.line	1267	call          r3     3     1
.line	1267	return        r0     1
.line	1267	move          r0    r0
.line	1267	move          r0    r0
.line	1267	move          r0    r0
.line	1267	return        r0     1

.function	main/f52

.source	null
.linedefined	1279
.lastlinedefined	1291
.numparams	3
.is_vararg	0
.maxstacksize	9

.upvalue	"_ENV"	25	true
.upvalue	"U1"	26	true
.upvalue	"U2"	0	false
.upvalue	"U3"	5	true

.constant	k0	"bBusy"
.constant	k1	"TargetCount"
.constant	k2	"ConfirmedCount"
.constant	k3	3
.constant	k4	"Button_ChangeAvatarForm"
.constant	k5	"SetWidgetVisibility"
.constant	k6	"UEnums"
.constant	k7	"ESlateVisibility"
.constant	k8	"Visible"
.constant	k9	"SetIsEnabled"
.constant	k10	"bCanToggle"
.constant	k11	true
.constant	k12	"slua"
.constant	k13	"isValid"
.constant	k14	"Image_CDTime"
.constant	k15	"Collapsed"
.constant	k16	"SetTexture"
.constant	k17	"Image_ChangeAvatarForm"
.constant	k18	"sync"
.constant	k19	false

.line	1279	gettable      r3    r1    k0 ; k0 = "bBusy"
.line	1279	test          r3     0
.line	1279	jmp            0    l7
.line	1279	gettable      r3    r1    k1 ; k1 = "TargetCount"
.line	1279	test          r3     1
.line	1279	jmp            0    l8
.label	l7
.line	1279	gettable      r3    r1    k2 ; k2 = "ConfirmedCount"
.label	l8
.line	1279	eq             0    r3    k3 ; k3 = 3
.line	1279	jmp            0   l13
.line	1279	getupval      r4    u0
.line	1279	test          r4     1
.line	1279	jmp            0   l14
.label	l13
.line	1279	getupval      r4    u1
.label	l14
.line	1279	gettable      r5    r0    k4 ; k4 = "Button_ChangeAvatarF" (truncated)
.line	1279	self          r5    r5    k5 ; k5 = "SetWidgetVisibility"
.line	1279	gettabup      r7    u2    k6 ; k6 = "UEnums"
.line	1279	gettable      r7    r7    k7 ; k7 = "ESlateVisibility"
.line	1279	gettable      r7    r7    k8 ; k8 = "Visible"
.line	1279	call          r5     3     1
.line	1279	gettable      r5    r0    k4 ; k4 = "Button_ChangeAvatarF" (truncated)
.line	1279	self          r5    r5    k9 ; k9 = "SetIsEnabled"
.line	1279	gettable      r7    r1   k10 ; k10 = "bCanToggle"
.line	1279	eq             1    r7   k11 ; k11 = true
.line	1279	jmp            0   l26
.line	1279	loadbool      r7     0     1
.label	l26
.line	1279	loadbool      r7     1     0
.line	1279	call          r5     3     1
.line	1279	gettabup      r5    u2   k12 ; k12 = "slua"
.line	1279	gettable      r5    r5   k13 ; k13 = "isValid"
.line	1279	gettable      r6    r0   k14 ; k14 = "Image_CDTime"
.line	1279	call          r5     2     2
.line	1279	test          r5     0
.line	1279	jmp            0   l40
.line	1279	gettable      r5    r0   k14 ; k14 = "Image_CDTime"
.line	1279	self          r5    r5    k5 ; k5 = "SetWidgetVisibility"
.line	1279	gettabup      r7    u2    k6 ; k6 = "UEnums"
.line	1279	gettable      r7    r7    k7 ; k7 = "ESlateVisibility"
.line	1279	gettable      r7    r7   k15 ; k15 = "Collapsed"
.line	1279	call          r5     3     1
.label	l40
.line	1279	eq             1    r4    r2
.line	1279	jmp            0   l48
.line	1279	gettabup      r5    u3   k16 ; k16 = "SetTexture"
.line	1279	gettable      r6    r0   k17 ; k17 = "Image_ChangeAvatarFo" (truncated)
.line	1279	move          r7    r4
.line	1279	newtable      r8     0     1
.line	1279	settable      r8   k18   k19 ; k19 = false
.line	1279	call          r5     4     1
.label	l48
.line	1279	return        r4     2
.line	1279	return        r0     1
.line	1279	move          r0    r0
.line	1279	move          r0    r0
.line	1279	move          r0    r0
.line	1279	return        r0     1

.function	main/f53

.source	null
.linedefined	1293
.lastlinedefined	1327
.numparams	1
.is_vararg	0
.maxstacksize	57

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"getAvatarComponent2"
.constant	k1	"slua"
.constant	k2	"isValid"
.constant	k3	0
.constant	k4	"import"
.constant	k5	6
.constant	k6	112
.constant	k7	220
.constant	k8	98
.constant	k9	160
.constant	k10	192
.constant	k11	59
.constant	k12	101
.constant	k13	185
.constant	k14	195
.constant	k15	126
.constant	k16	30
.constant	k17	235
.constant	k18	169
.constant	k19	117
.constant	k20	"GetAvatarSlotDesc"
.constant	k21	"EAvatarSlotType_ClothesEquipemtSlot"
.constant	k22	"ItemDefineID"
.constant	k23	"CustomInfo"
.constant	k24	"ColorID"
.constant	k25	"require"
.constant	k26	"table"
.constant	k27	"concat"
.constant	k28	4
.constant	k29	80
.constant	k30	199
.constant	k31	102
.constant	k32	152
.constant	k33	212
.constant	k34	40
.constant	k35	24
.constant	k36	148
.constant	k37	207
.constant	k38	35
.constant	k39	228
.constant	k40	176
.constant	k41	100
.constant	k42	193
.constant	k43	157
.constant	k44	66
.constant	k45	181
.constant	k46	94
.constant	k47	73
.constant	k48	244
.constant	k49	75
.constant	k50	172
.constant	k51	221
.constant	k52	118
.constant	k53	51
.constant	k54	248
.constant	k55	46
.constant	k56	239
.constant	k57	194
.constant	k58	124
.constant	k59	175
.constant	k60	115
.constant	k61	88
.constant	k62	224
.constant	k63	56
.constant	k64	27
.constant	k65	223
.constant	k66	106
.constant	k67	143
.constant	k68	17
.constant	k69	197
.constant	k70	31
.constant	k71	230
.constant	k72	"GetPeriodByItemId"
.constant	k73	"TypeSpecificID"
.constant	k74	"GetCurAvatarState"
.constant	k75	110
.constant	k76	184
.constant	k77	121
.constant	k78	214
.constant	k79	240
.constant	k80	104
.constant	k81	174
.constant	k82	74
.constant	k83	10
.constant	k84	86
.constant	k85	105
.constant	k86	52
.constant	k87	23
.constant	k88	227
.constant	k89	202
.constant	k90	179
.constant	k91	68
.constant	k92	19
.constant	k93	93
.constant	k94	203
.constant	k95	122
.constant	k96	139
.constant	k97	245
.constant	k98	38
.constant	k99	89
.constant	k100	"IsInMainCity"
.constant	k101	"GetCfgByItemId"
.constant	k102	"second_item_id"
.constant	k103	1
.constant	k104	2
.constant	k105	32
.constant	k106	186
.constant	k107	213
.constant	k108	103
.constant	k109	69
.constant	k110	217
.constant	k111	107
.constant	k112	254
.constant	k113	182
.constant	k114	119
.constant	k115	209
.constant	k116	208
.constant	k117	47
.constant	k118	130
.constant	k119	96
.constant	k120	81
.constant	k121	77
.constant	k122	211
.constant	k123	125
.constant	k124	225
.constant	k125	150
.constant	k126	120
.constant	k127	219
.constant	k128	190
.constant	k129	"CheckUnlockState"
.constant	k130	"print"
.constant	k131	"bWriteLog"
.constant	k132	16
.constant	k133	90
.constant	k134	111
.constant	k135	42
.constant	k136	188
.constant	k137	21
.constant	k138	177
.constant	k139	113
.constant	k140	155
.constant	k141	229
.constant	k142	116
.constant	k143	131
.constant	k144	55
.constant	k145	133
.constant	k146	201
.constant	k147	241
.constant	k148	171
.constant	k149	79
.constant	k150	238
.constant	k151	109
.constant	k152	232
.constant	k153	58
.constant	k154	127
.constant	k155	187
.constant	k156	252
.constant	k157	154
.constant	k158	204
.constant	k159	33
.constant	k160	180
.constant	k161	92
.constant	k162	76
.constant	k163	49
.constant	k164	162
.constant	k165	153
.constant	k166	70
.constant	k167	"tostring"

.line	1293	self          r1    r0    k0 ; k0 = "getAvatarComponent2"
.line	1293	call          r1     2     2
.line	1293	gettabup      r2    u0    k1 ; k1 = "slua"
.line	1293	gettable      r2    r2    k2 ; k2 = "isValid"
.line	1293	move          r3    r1
.line	1293	call          r2     2     2
.line	1293	test          r2     1
.line	1293	jmp            0   l11
.line	1293	loadk         r2    k3 ; k3 = 0
.line	1293	return        r2     2
.label	l11
.line	1293	gettabup      r2    u0    k4 ; k4 = "import"
.line	1293	getupval      r3    u1
.line	1293	loadk         r4    k5 ; k5 = 6
.line	1293	loadk         r5    k6 ; k6 = 112
.line	1293	loadk         r6    k7 ; k7 = 220
.line	1293	loadk         r7    k8 ; k8 = 98
.line	1293	loadk         r8    k9 ; k9 = 160
.line	1293	loadk         r9   k10 ; k10 = 192
.line	1293	loadk        r10   k11 ; k11 = 59
.line	1293	loadk        r11   k12 ; k12 = 101
.line	1293	loadk        r12   k13 ; k13 = 185
.line	1293	loadk        r13   k14 ; k14 = 195
.line	1293	loadk        r14   k15 ; k15 = 126
.line	1293	loadk        r15   k16 ; k16 = 30
.line	1293	loadk        r16   k17 ; k17 = 235
.line	1293	loadk        r17   k18 ; k18 = 169
.line	1293	loadk        r18   k19 ; k19 = 117
.line	1293	call          r3    16     2
.line	1293	call          r2     2     2
.line	1293	self          r3    r1   k20 ; k20 = "GetAvatarSlotDesc"
.line	1293	gettable      r5    r2   k21 ; k21 = "EAvatarSlotType_Clot" (truncated)
.line	1293	call          r3     3     2
.line	1293	gettable      r4    r3   k22 ; k22 = "ItemDefineID"
.line	1293	gettable      r5    r3   k23 ; k23 = "CustomInfo"
.line	1293	gettable      r5    r5   k24 ; k24 = "ColorID"
.line	1293	gettabup      r6    u0   k25 ; k25 = "require"
.line	1293	gettabup      r7    u0   k26 ; k26 = "table"
.line	1293	gettable      r7    r7   k27 ; k27 = "concat"
.line	1293	newtable      r8     1     0
.line	1293	getupval      r9    u1
.line	1293	loadk        r10   k28 ; k28 = 4
.line	1293	loadk        r11   k29 ; k29 = 80
.line	1293	loadk        r12   k30 ; k30 = 199
.line	1293	loadk        r13   k31 ; k31 = 102
.line	1293	loadk        r14   k32 ; k32 = 152
.line	1293	loadk        r15   k33 ; k33 = 212
.line	1293	loadk        r16   k34 ; k34 = 40
.line	1293	loadk        r17   k35 ; k35 = 24
.line	1293	loadk        r18   k36 ; k36 = 148
.line	1293	loadk        r19   k37 ; k37 = 207
.line	1293	loadk        r20   k15 ; k15 = 126
.line	1293	loadk        r21   k38 ; k38 = 35
.line	1293	loadk        r22   k39 ; k39 = 228
.line	1293	loadk        r23   k40 ; k40 = 176
.line	1293	loadk        r24   k41 ; k41 = 100
.line	1293	loadk        r25   k42 ; k42 = 193
.line	1293	loadk        r26   k43 ; k43 = 157
.line	1293	loadk        r27   k44 ; k44 = 66
.line	1293	loadk        r28   k45 ; k45 = 181
.line	1293	loadk        r29   k46 ; k46 = 94
.line	1293	loadk        r30   k47 ; k47 = 73
.line	1293	loadk        r31   k48 ; k48 = 244
.line	1293	loadk        r32   k49 ; k49 = 75
.line	1293	loadk        r33   k12 ; k12 = 101
.line	1293	loadk        r34   k50 ; k50 = 172
.line	1293	loadk        r35   k51 ; k51 = 221
.line	1293	loadk        r36   k52 ; k52 = 118
.line	1293	loadk        r37   k53 ; k53 = 51
.line	1293	loadk        r38   k54 ; k54 = 248
.line	1293	loadk        r39   k50 ; k50 = 172
.line	1293	loadk        r40   k55 ; k55 = 46
.line	1293	loadk        r41   k56 ; k56 = 239
.line	1293	loadk        r42   k57 ; k57 = 194
.line	1293	loadk        r43   k58 ; k58 = 124
.line	1293	loadk        r44   k59 ; k59 = 175
.line	1293	loadk        r45   k60 ; k60 = 115
.line	1293	loadk        r46   k61 ; k61 = 88
.line	1293	loadk        r47   k62 ; k62 = 224
.line	1293	loadk        r48   k29 ; k29 = 80
.line	1293	loadk        r49   k63 ; k63 = 56
.line	1293	call          r9    41     2
.line	1293	getupval     r10    u1
.line	1293	loadk        r11   k64 ; k64 = 27
.line	1293	loadk        r12    k8 ; k8 = 98
.line	1293	loadk        r13   k65 ; k65 = 223
.line	1293	loadk        r14   k66 ; k66 = 106
.line	1293	loadk        r15    k9 ; k9 = 160
.line	1293	loadk        r16   k67 ; k67 = 143
.line	1293	loadk        r17   k68 ; k68 = 17
.line	1293	loadk        r18   k12 ; k12 = 101
.line	1293	loadk        r19    k9 ; k9 = 160
.line	1293	loadk        r20   k69 ; k69 = 197
.line	1293	loadk        r21   k15 ; k15 = 126
.line	1293	loadk        r22   k70 ; k70 = 31
.line	1293	loadk        r23   k71 ; k71 = 230
.line	1293	loadk        r24   k40 ; k40 = 176
.line	1293	loadk        r25   k58 ; k58 = 124
.line	1293	call         r10    16     0
.line	1293	setlist       r8     0     1
.line	1293	call          r7     2     2
.line	1293	call          r6     2     2
.line	1293	self          r7    r6   k72 ; k72 = "GetPeriodByItemId"
.line	1293	gettable      r9    r4   k73 ; k73 = "TypeSpecificID"
.line	1293	call          r7     3     2
.line	1293	test          r7     1
.line	1293	jmp            0  l109
.line	1293	loadk         r8    k3 ; k3 = 0
.line	1293	return        r8     2
.label	l109
.line	1293	self          r8    r1   k74 ; k74 = "GetCurAvatarState"
.line	1293	move         r10    r7
.line	1293	move         r11    r5
.line	1293	call          r8     4     2
.line	1293	gettabup      r9    u0   k25 ; k25 = "require"
.line	1293	gettabup     r10    u0   k26 ; k26 = "table"
.line	1293	gettable     r10   r10   k27 ; k27 = "concat"
.line	1293	newtable     r11     1     0
.line	1293	getupval     r12    u1
.line	1293	loadk        r13   k28 ; k28 = 4
.line	1293	loadk        r14   k29 ; k29 = 80
.line	1293	loadk        r15   k30 ; k30 = 199
.line	1293	loadk        r16   k31 ; k31 = 102
.line	1293	loadk        r17   k32 ; k32 = 152
.line	1293	loadk        r18   k33 ; k33 = 212
.line	1293	loadk        r19   k34 ; k34 = 40
.line	1293	loadk        r20   k35 ; k35 = 24
.line	1293	loadk        r21   k32 ; k32 = 152
.line	1293	loadk        r22   k14 ; k14 = 195
.line	1293	loadk        r23   k75 ; k75 = 110
.line	1293	loadk        r24   k41 ; k41 = 100
.line	1293	loadk        r25   k65 ; k65 = 223
.line	1293	loadk        r26   k76 ; k76 = 184
.line	1293	loadk        r27   k77 ; k77 = 121
.line	1293	loadk        r28   k78 ; k78 = 214
.line	1293	loadk        r29   k79 ; k79 = 240
.line	1293	loadk        r30   k80 ; k80 = 104
.line	1293	loadk        r31   k81 ; k81 = 174
.line	1293	loadk        r32   k82 ; k82 = 74
.line	1293	loadk        r33   k83 ; k83 = 10
.line	1293	loadk        r34   k69 ; k69 = 197
.line	1293	loadk        r35   k84 ; k84 = 86
.line	1293	loadk        r36   k85 ; k85 = 105
.line	1293	loadk        r37   k18 ; k18 = 169
.line	1293	loadk        r38   k37 ; k37 = 207
.line	1293	loadk        r39   k86 ; k86 = 52
.line	1293	loadk        r40   k87 ; k87 = 23
.line	1293	loadk        r41   k88 ; k88 = 227
.line	1293	loadk        r42    k9 ; k9 = 160
.line	1293	loadk        r43   k75 ; k75 = 110
.line	1293	loadk        r44   k17 ; k17 = 235
.line	1293	loadk        r45   k89 ; k89 = 202
.line	1293	loadk        r46   k12 ; k12 = 101
.line	1293	loadk        r47   k90 ; k90 = 179
.line	1293	loadk        r48   k58 ; k58 = 124
.line	1293	loadk        r49   k60 ; k60 = 115
.line	1293	loadk        r50   k62 ; k62 = 224
.line	1293	loadk        r51   k91 ; k91 = 68
.line	1293	loadk        r52   k60 ; k60 = 115
.line	1293	call         r12    41     2
.line	1293	getupval     r13    u1
.line	1293	loadk        r14   k92 ; k92 = 19
.line	1293	loadk        r15   k93 ; k93 = 93
.line	1293	loadk        r16   k94 ; k94 = 203
.line	1293	loadk        r17   k95 ; k95 = 122
.line	1293	loadk        r18   k96 ; k96 = 139
.line	1293	loadk        r19   k97 ; k97 = 245
.line	1293	loadk        r20   k98 ; k98 = 38
.line	1293	loadk        r21   k99 ; k99 = 89
.line	1293	loadk        r22   k13 ; k13 = 185
.line	1293	loadk        r23   k65 ; k65 = 223
.line	1293	call         r13    11     0
.line	1293	setlist      r11     0     1
.line	1293	call         r10     2     2
.line	1293	call          r9     2     2
.line	1293	gettable     r10    r9  k100 ; k100 = "IsInMainCity"
.line	1293	call         r10     1     2
.line	1293	test         r10     0
.line	1293	jmp            0  l415
.line	1293	self         r10    r6  k101 ; k101 = "GetCfgByItemId"
.line	1293	gettable     r12    r4   k73 ; k73 = "TypeSpecificID"
.line	1293	call         r10     3     2
.line	1293	test         r10     0
.line	1293	jmp            0  l415
.line	1293	test         r10     0
.line	1293	jmp            0  l190
.line	1293	gettable     r11   r10  k102 ; k102 = "second_item_id"
.line	1293	test         r11     0
.line	1293	jmp            0  l190
.line	1293	loadk         r8  k103 ; k103 = 1
.line	1293	jmp            0  l191
.label	l190
.line	1293	loadk         r8  k104 ; k104 = 2
.label	l191
.line	1293	gettabup     r11    u0   k25 ; k25 = "require"
.line	1293	getupval     r12    u1
.line	1293	loadk        r13  k105 ; k105 = 32
.line	1293	loadk        r14   k93 ; k93 = 93
.line	1293	loadk        r15   k14 ; k14 = 195
.line	1293	loadk        r16   k31 ; k31 = 102
.line	1293	loadk        r17  k106 ; k106 = 186
.line	1293	loadk        r18  k107 ; k107 = 213
.line	1293	loadk        r19  k108 ; k108 = 103
.line	1293	loadk        r20  k109 ; k109 = 69
.line	1293	loadk        r21   k13 ; k13 = 185
.line	1293	loadk        r22  k110 ; k110 = 217
.line	1293	loadk        r23  k111 ; k111 = 107
.line	1293	loadk        r24   k41 ; k41 = 100
.line	1293	loadk        r25  k112 ; k112 = 254
.line	1293	loadk        r26  k113 ; k113 = 182
.line	1293	loadk        r27  k114 ; k114 = 119
.line	1293	loadk        r28  k115 ; k115 = 209
.line	1293	loadk        r29  k116 ; k116 = 208
.line	1293	loadk        r30  k117 ; k117 = 47
.line	1293	loadk        r31  k118 ; k118 = 130
.line	1293	loadk        r32  k119 ; k119 = 96
.line	1293	loadk        r33  k120 ; k120 = 81
.line	1293	loadk        r34   k54 ; k54 = 248
.line	1293	loadk        r35  k121 ; k121 = 77
.line	1293	loadk        r36   k34 ; k34 = 40
.line	1293	loadk        r37   k18 ; k18 = 169
.line	1293	loadk        r38  k122 ; k122 = 211
.line	1293	loadk        r39  k123 ; k123 = 125
.line	1293	loadk        r40   k53 ; k53 = 51
.line	1293	loadk        r41  k124 ; k124 = 225
.line	1293	loadk        r42  k125 ; k125 = 150
.line	1293	loadk        r43  k126 ; k126 = 120
.line	1293	loadk        r44  k127 ; k127 = 219
.line	1293	loadk        r45   k78 ; k78 = 214
.line	1293	loadk        r46  k126 ; k126 = 120
.line	1293	loadk        r47  k128 ; k128 = 190
.line	1293	call         r12    36     2
.line	1293	call         r11     2     2
.line	1293	eq             0    r8  k103 ; k103 = 1
.line	1293	jmp            0  l235
.line	1293	loadk        r12  k104 ; k104 = 2
.line	1293	test         r12     1
.line	1293	jmp            0  l236
.label	l235
.line	1293	loadk        r12  k103 ; k103 = 1
.label	l236
.line	1293	gettable     r13   r11  k129 ; k129 = "CheckUnlockState"
.line	1293	move         r14    r7
.line	1293	move         r15   r12
.line	1293	move         r16    r5
.line	1293	call         r13     4     2
.line	1293	test         r13     1
.line	1293	jmp            0  l328
.line	1293	gettabup     r13    u0  k130 ; k130 = "print"
.line	1293	gettabup     r14    u0  k131 ; k131 = "bWriteLog"
.line	1293	test         r14     0
.line	1293	jmp            0  l325
.line	1293	gettabup     r14    u0   k26 ; k26 = "table"
.line	1293	gettable     r14   r14   k27 ; k27 = "concat"
.line	1293	newtable     r15     1     0
.line	1293	getupval     r16    u1
.line	1293	loadk        r17  k132 ; k132 = 16
.line	1293	loadk        r18  k133 ; k133 = 90
.line	1293	loadk        r19   k14 ; k14 = 195
.line	1293	loadk        r20  k134 ; k134 = 111
.line	1293	loadk        r21   k76 ; k76 = 184
.line	1293	loadk        r22   k62 ; k62 = 224
.line	1293	loadk        r23  k135 ; k135 = 42
.line	1293	loadk        r24   k44 ; k44 = 66
.line	1293	loadk        r25  k136 ; k136 = 188
.line	1293	loadk        r26   k14 ; k14 = 195
.line	1293	loadk        r27   k41 ; k41 = 100
.line	1293	loadk        r28  k137 ; k137 = 21
.line	1293	loadk        r29  k115 ; k115 = 209
.line	1293	loadk        r30  k138 ; k138 = 177
.line	1293	loadk        r31  k139 ; k139 = 113
.line	1293	loadk        r32   k78 ; k78 = 214
.line	1293	loadk        r33   k33 ; k33 = 212
.line	1293	loadk        r34   k41 ; k41 = 100
.line	1293	loadk        r35  k140 ; k140 = 155
.line	1293	loadk        r36  k109 ; k109 = 69
.line	1293	loadk        r37  k109 ; k109 = 69
.line	1293	loadk        r38  k141 ; k141 = 229
.line	1293	loadk        r39   k61 ; k61 = 88
.line	1293	loadk        r40  k142 ; k142 = 116
.line	1293	loadk        r41  k143 ; k143 = 131
.line	1293	loadk        r42  k122 ; k122 = 211
.line	1293	loadk        r43   k80 ; k80 = 104
.line	1293	loadk        r44  k144 ; k144 = 55
.line	1293	loadk        r45   k76 ; k76 = 184
.line	1293	loadk        r46  k145 ; k145 = 133
.line	1293	loadk        r47   k19 ; k19 = 117
.line	1293	loadk        r48  k146 ; k146 = 201
.line	1293	loadk        r49  k147 ; k147 = 241
.line	1293	loadk        r50  k142 ; k142 = 116
.line	1293	loadk        r51  k148 ; k148 = 171
.line	1293	loadk        r52  k149 ; k149 = 79
.line	1293	loadk        r53    k6 ; k6 = 112
.line	1293	loadk        r54  k150 ; k150 = 238
.line	1293	loadk        r55   k80 ; k80 = 104
.line	1293	loadk        r56   k19 ; k19 = 117
.line	1293	call         r16    41     2
.line	1293	getupval     r17    u1
.line	1293	loadk        r18  k144 ; k144 = 55
.line	1293	loadk        r19   k61 ; k61 = 88
.line	1293	loadk        r20   k69 ; k69 = 197
.line	1293	loadk        r21  k151 ; k151 = 109
.line	1293	loadk        r22   k48 ; k48 = 244
.line	1293	loadk        r23  k152 ; k152 = 232
.line	1293	loadk        r24  k153 ; k153 = 58
.line	1293	loadk        r25  k154 ; k154 = 127
.line	1293	loadk        r26  k155 ; k155 = 187
.line	1293	loadk        r27  k124 ; k124 = 225
.line	1293	loadk        r28  k111 ; k111 = 107
.line	1293	loadk        r29   k38 ; k38 = 35
.line	1293	loadk        r30  k156 ; k156 = 252
.line	1293	loadk        r31  k157 ; k157 = 154
.line	1293	loadk        r32   k77 ; k77 = 121
.line	1293	loadk        r33  k158 ; k158 = 204
.line	1293	loadk        r34   k89 ; k89 = 202
.line	1293	loadk        r35  k159 ; k159 = 33
.line	1293	loadk        r36  k160 ; k160 = 180
.line	1293	loadk        r37  k161 ; k161 = 92
.line	1293	loadk        r38   k29 ; k29 = 80
.line	1293	loadk        r39  k138 ; k138 = 177
.line	1293	loadk        r40  k162 ; k162 = 76
.line	1293	loadk        r41   k80 ; k80 = 104
.line	1293	loadk        r42   k18 ; k18 = 169
.line	1293	loadk        r43  k122 ; k122 = 211
.line	1293	loadk        r44   k77 ; k77 = 121
.line	1293	loadk        r45  k163 ; k163 = 49
.line	1293	loadk        r46  k164 ; k164 = 162
.line	1293	call         r17    30     0
.line	1293	setlist      r15     0     1
.line	1293	call         r14     2     2
.label	l325
.line	1293	call         r13     2     1
.line	1293	loadk        r13    k3 ; k3 = 0
.line	1293	return       r13     2
.label	l328
.line	1293	gettabup     r13    u0  k130 ; k130 = "print"
.line	1293	gettabup     r14    u0  k131 ; k131 = "bWriteLog"
.line	1293	test         r14     0
.line	1293	jmp            0  l414
.line	1293	gettabup     r14    u0   k26 ; k26 = "table"
.line	1293	gettable     r14   r14   k27 ; k27 = "concat"
.line	1293	newtable     r15     1     0
.line	1293	getupval     r16    u1
.line	1293	loadk        r17  k132 ; k132 = 16
.line	1293	loadk        r18  k133 ; k133 = 90
.line	1293	loadk        r19   k14 ; k14 = 195
.line	1293	loadk        r20  k134 ; k134 = 111
.line	1293	loadk        r21   k76 ; k76 = 184
.line	1293	loadk        r22   k62 ; k62 = 224
.line	1293	loadk        r23  k135 ; k135 = 42
.line	1293	loadk        r24   k44 ; k44 = 66
.line	1293	loadk        r25  k136 ; k136 = 188
.line	1293	loadk        r26   k14 ; k14 = 195
.line	1293	loadk        r27   k41 ; k41 = 100
.line	1293	loadk        r28  k137 ; k137 = 21
.line	1293	loadk        r29  k115 ; k115 = 209
.line	1293	loadk        r30  k138 ; k138 = 177
.line	1293	loadk        r31  k139 ; k139 = 113
.line	1293	loadk        r32   k78 ; k78 = 214
.line	1293	loadk        r33   k33 ; k33 = 212
.line	1293	loadk        r34   k41 ; k41 = 100
.line	1293	loadk        r35  k140 ; k140 = 155
.line	1293	loadk        r36  k109 ; k109 = 69
.line	1293	loadk        r37  k109 ; k109 = 69
.line	1293	loadk        r38  k141 ; k141 = 229
.line	1293	loadk        r39   k61 ; k61 = 88
.line	1293	loadk        r40  k142 ; k142 = 116
.line	1293	loadk        r41  k143 ; k143 = 131
.line	1293	loadk        r42  k122 ; k122 = 211
.line	1293	loadk        r43   k80 ; k80 = 104
.line	1293	loadk        r44  k144 ; k144 = 55
.line	1293	loadk        r45   k76 ; k76 = 184
.line	1293	loadk        r46  k145 ; k145 = 133
.line	1293	loadk        r47   k19 ; k19 = 117
.line	1293	loadk        r48  k146 ; k146 = 201
.line	1293	loadk        r49  k147 ; k147 = 241
.line	1293	loadk        r50  k142 ; k142 = 116
.line	1293	loadk        r51  k148 ; k148 = 171
.line	1293	loadk        r52  k149 ; k149 = 79
.line	1293	loadk        r53    k6 ; k6 = 112
.line	1293	loadk        r54  k150 ; k150 = 238
.line	1293	loadk        r55   k80 ; k80 = 104
.line	1293	loadk        r56   k19 ; k19 = 117
.line	1293	call         r16    41     2
.line	1293	getupval     r17    u1
.line	1293	loadk        r18  k144 ; k144 = 55
.line	1293	loadk        r19   k61 ; k61 = 88
.line	1293	loadk        r20   k69 ; k69 = 197
.line	1293	loadk        r21  k151 ; k151 = 109
.line	1293	loadk        r22   k48 ; k48 = 244
.line	1293	loadk        r23  k152 ; k152 = 232
.line	1293	loadk        r24  k153 ; k153 = 58
.line	1293	loadk        r25  k154 ; k154 = 127
.line	1293	loadk        r26  k155 ; k155 = 187
.line	1293	loadk        r27  k124 ; k124 = 225
.line	1293	loadk        r28  k111 ; k111 = 107
.line	1293	loadk        r29   k38 ; k38 = 35
.line	1293	loadk        r30  k156 ; k156 = 252
.line	1293	loadk        r31  k157 ; k157 = 154
.line	1293	loadk        r32   k77 ; k77 = 121
.line	1293	loadk        r33  k158 ; k158 = 204
.line	1293	loadk        r34   k89 ; k89 = 202
.line	1293	loadk        r35  k159 ; k159 = 33
.line	1293	loadk        r36  k165 ; k165 = 153
.line	1293	loadk        r37  k166 ; k166 = 70
.line	1293	loadk        r38   k84 ; k84 = 86
.line	1293	loadk        r39   k57 ; k57 = 194
.line	1293	loadk        r40  k121 ; k121 = 77
.line	1293	loadk        r41  k108 ; k108 = 103
.line	1293	loadk        r42  k138 ; k138 = 177
.line	1293	loadk        r43  k110 ; k110 = 217
.line	1293	loadk        r44  k153 ; k153 = 58
.line	1293	loadk        r45  k108 ; k108 = 103
.line	1293	loadk        r46  k164 ; k164 = 162
.line	1293	call         r17    30     0
.line	1293	setlist      r15     0     1
.line	1293	call         r14     2     2
.line	1293	gettabup     r15    u0  k167 ; k167 = "tostring"
.line	1293	move         r16    r8
.line	1293	call         r15     2     2
.line	1293	concat       r14   r14   r15
.label	l414
.line	1293	call         r13     2     1
.label	l415
.line	1293	return        r8     2
.line	1293	return        r0     1
.line	1293	move          r0    r0
.line	1293	return        r0     1

.function	main/f54

.source	null
.linedefined	1329
.lastlinedefined	1339
.numparams	1
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"getAvatarComponent2"
.constant	k1	"slua"
.constant	k2	"isValid"
.constant	k3	"import"
.constant	k4	6
.constant	k5	112
.constant	k6	220
.constant	k7	98
.constant	k8	160
.constant	k9	192
.constant	k10	59
.constant	k11	101
.constant	k12	185
.constant	k13	195
.constant	k14	126
.constant	k15	30
.constant	k16	235
.constant	k17	169
.constant	k18	117
.constant	k19	"GetEquippedItemDefineID"
.constant	k20	"EAvatarSlotType_ClothesEquipemtSlot"
.constant	k21	"require"
.constant	k22	"table"
.constant	k23	"concat"
.constant	k24	4
.constant	k25	80
.constant	k26	199
.constant	k27	102
.constant	k28	152
.constant	k29	212
.constant	k30	40
.constant	k31	24
.constant	k32	148
.constant	k33	207
.constant	k34	35
.constant	k35	228
.constant	k36	176
.constant	k37	100
.constant	k38	193
.constant	k39	157
.constant	k40	66
.constant	k41	181
.constant	k42	94
.constant	k43	73
.constant	k44	244
.constant	k45	75
.constant	k46	172
.constant	k47	221
.constant	k48	118
.constant	k49	51
.constant	k50	248
.constant	k51	46
.constant	k52	239
.constant	k53	194
.constant	k54	124
.constant	k55	175
.constant	k56	115
.constant	k57	88
.constant	k58	224
.constant	k59	56
.constant	k60	27
.constant	k61	223
.constant	k62	106
.constant	k63	143
.constant	k64	17
.constant	k65	197
.constant	k66	31
.constant	k67	230
.constant	k68	"GetStateIcon"
.constant	k69	"TypeSpecificID"

.line	1329	self          r1    r0    k0 ; k0 = "getAvatarComponent2"
.line	1329	call          r1     2     2
.line	1329	gettabup      r2    u0    k1 ; k1 = "slua"
.line	1329	gettable      r2    r2    k2 ; k2 = "isValid"
.line	1329	move          r3    r1
.line	1329	call          r2     2     2
.line	1329	test          r2     1
.line	1329	jmp            0   l11
.line	1329	loadnil       r2     0
.line	1329	return        r2     2
.label	l11
.line	1329	gettabup      r2    u0    k3 ; k3 = "import"
.line	1329	getupval      r3    u1
.line	1329	loadk         r4    k4 ; k4 = 6
.line	1329	loadk         r5    k5 ; k5 = 112
.line	1329	loadk         r6    k6 ; k6 = 220
.line	1329	loadk         r7    k7 ; k7 = 98
.line	1329	loadk         r8    k8 ; k8 = 160
.line	1329	loadk         r9    k9 ; k9 = 192
.line	1329	loadk        r10   k10 ; k10 = 59
.line	1329	loadk        r11   k11 ; k11 = 101
.line	1329	loadk        r12   k12 ; k12 = 185
.line	1329	loadk        r13   k13 ; k13 = 195
.line	1329	loadk        r14   k14 ; k14 = 126
.line	1329	loadk        r15   k15 ; k15 = 30
.line	1329	loadk        r16   k16 ; k16 = 235
.line	1329	loadk        r17   k17 ; k17 = 169
.line	1329	loadk        r18   k18 ; k18 = 117
.line	1329	call          r3    16     2
.line	1329	call          r2     2     2
.line	1329	self          r3    r1   k19 ; k19 = "GetEquippedItemDefin" (truncated)
.line	1329	gettable      r5    r2   k20 ; k20 = "EAvatarSlotType_Clot" (truncated)
.line	1329	call          r3     3     2
.line	1329	gettabup      r4    u0   k21 ; k21 = "require"
.line	1329	gettabup      r5    u0   k22 ; k22 = "table"
.line	1329	gettable      r5    r5   k23 ; k23 = "concat"
.line	1329	newtable      r6     1     0
.line	1329	getupval      r7    u1
.line	1329	loadk         r8   k24 ; k24 = 4
.line	1329	loadk         r9   k25 ; k25 = 80
.line	1329	loadk        r10   k26 ; k26 = 199
.line	1329	loadk        r11   k27 ; k27 = 102
.line	1329	loadk        r12   k28 ; k28 = 152
.line	1329	loadk        r13   k29 ; k29 = 212
.line	1329	loadk        r14   k30 ; k30 = 40
.line	1329	loadk        r15   k31 ; k31 = 24
.line	1329	loadk        r16   k32 ; k32 = 148
.line	1329	loadk        r17   k33 ; k33 = 207
.line	1329	loadk        r18   k14 ; k14 = 126
.line	1329	loadk        r19   k34 ; k34 = 35
.line	1329	loadk        r20   k35 ; k35 = 228
.line	1329	loadk        r21   k36 ; k36 = 176
.line	1329	loadk        r22   k37 ; k37 = 100
.line	1329	loadk        r23   k38 ; k38 = 193
.line	1329	loadk        r24   k39 ; k39 = 157
.line	1329	loadk        r25   k40 ; k40 = 66
.line	1329	loadk        r26   k41 ; k41 = 181
.line	1329	loadk        r27   k42 ; k42 = 94
.line	1329	loadk        r28   k43 ; k43 = 73
.line	1329	loadk        r29   k44 ; k44 = 244
.line	1329	loadk        r30   k45 ; k45 = 75
.line	1329	loadk        r31   k11 ; k11 = 101
.line	1329	loadk        r32   k46 ; k46 = 172
.line	1329	loadk        r33   k47 ; k47 = 221
.line	1329	loadk        r34   k48 ; k48 = 118
.line	1329	loadk        r35   k49 ; k49 = 51
.line	1329	loadk        r36   k50 ; k50 = 248
.line	1329	loadk        r37   k46 ; k46 = 172
.line	1329	loadk        r38   k51 ; k51 = 46
.line	1329	loadk        r39   k52 ; k52 = 239
.line	1329	loadk        r40   k53 ; k53 = 194
.line	1329	loadk        r41   k54 ; k54 = 124
.line	1329	loadk        r42   k55 ; k55 = 175
.line	1329	loadk        r43   k56 ; k56 = 115
.line	1329	loadk        r44   k57 ; k57 = 88
.line	1329	loadk        r45   k58 ; k58 = 224
.line	1329	loadk        r46   k25 ; k25 = 80
.line	1329	loadk        r47   k59 ; k59 = 56
.line	1329	call          r7    41     2
.line	1329	getupval      r8    u1
.line	1329	loadk         r9   k60 ; k60 = 27
.line	1329	loadk        r10    k7 ; k7 = 98
.line	1329	loadk        r11   k61 ; k61 = 223
.line	1329	loadk        r12   k62 ; k62 = 106
.line	1329	loadk        r13    k8 ; k8 = 160
.line	1329	loadk        r14   k63 ; k63 = 143
.line	1329	loadk        r15   k64 ; k64 = 17
.line	1329	loadk        r16   k11 ; k11 = 101
.line	1329	loadk        r17    k8 ; k8 = 160
.line	1329	loadk        r18   k65 ; k65 = 197
.line	1329	loadk        r19   k14 ; k14 = 126
.line	1329	loadk        r20   k66 ; k66 = 31
.line	1329	loadk        r21   k67 ; k67 = 230
.line	1329	loadk        r22   k36 ; k36 = 176
.line	1329	loadk        r23   k54 ; k54 = 124
.line	1329	call          r8    16     0
.line	1329	setlist       r6     0     1
.line	1329	call          r5     2     2
.line	1329	call          r4     2     2
.line	1329	self          r5    r4   k68 ; k68 = "GetStateIcon"
.line	1329	gettable      r7    r3   k69 ; k69 = "TypeSpecificID"
.line	1329	call          r5     3     2
.line	1329	return        r5     2
.line	1329	return        r0     1
.line	1329	move          r0    r0
.line	1329	move          r0    r0
.line	1329	return        r0     1

.function	main/f55

.source	null
.linedefined	1341
.lastlinedefined	1377
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	22	true
.upvalue	"U3"	14	true
.upvalue	"U4"	5	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	18
.constant	k5	68
.constant	k6	195
.constant	k7	96
.constant	k8	191
.constant	k9	228
.constant	k10	49
.constant	k11	70
.constant	k12	167
.constant	k13	201
.constant	k14	121
.constant	k15	57
.constant	k16	251
.constant	k17	182
.constant	k18	126
.constant	k19	130
.constant	k20	225
.constant	k21	100
.constant	k22	188
.constant	k23	65
.constant	k24	226
.constant	k25	81
.constant	k26	69
.constant	k27	173
.constant	k28	221
.constant	k29	116
.constant	k30	61
.constant	k31	231
.constant	k32	136
.constant	k33	118
.constant	k34	215
.constant	k35	112
.constant	k36	184
.constant	k37	101
.constant	k38	91
.constant	k39	243
.constant	k40	84
.constant	k41	55
.constant	k42	95
.constant	k43	249
.constant	k44	119
.constant	k45	181
.constant	k46	213
.constant	k47	44
.constant	k48	"ChangeAvatarFormCDTimer"
.constant	k49	"RemoveTimer"
.constant	k50	nil
.constant	k51	"XSuitTailButtonIcon"
.constant	k52	"GetXSuitTailButtonState"
.constant	k53	"bXSuitTailButton"
.constant	k54	"bAvailable"
.constant	k55	true
.constant	k56	"RefreshXSuitTailRedPoint"
.constant	k57	"ApplyXSuitTailButtonState"
.constant	k58	"AddTimerLoop"
.constant	k59	0
.constant	k60	"TIMER_INFINITE"
.constant	k61	0.2
.constant	k62	"Button_ChangeAvatarForm"
.constant	k63	"SetIsEnabled"
.constant	k64	"SetWidgetVisibility"
.constant	k65	"UEnums"
.constant	k66	"ESlateVisibility"
.constant	k67	"Collapsed"
.constant	k68	"GetPlayerCharacter"
.constant	k69	"slua"
.constant	k70	"isValid"
.constant	k71	"GetAvatarFormState"
.constant	k72	"GetAvatarFormIcon"
.constant	k73	"Visible"
.constant	k74	"SetTexture"
.constant	k75	"Image_ChangeAvatarForm"
.constant	k76	"sync"
.constant	k77	false

.line	1341	gettabup      r1    u0    k0 ; k0 = "print"
.line	1341	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1341	test          r2     0
.line	1341	jmp            0   l61
.line	1341	gettabup      r2    u0    k2 ; k2 = "table"
.line	1341	gettable      r2    r2    k3 ; k3 = "concat"
.line	1341	newtable      r3     1     0
.line	1341	getupval      r4    u1
.line	1341	loadk         r5    k4 ; k4 = 18
.line	1341	loadk         r6    k5 ; k5 = 68
.line	1341	loadk         r7    k6 ; k6 = 195
.line	1341	loadk         r8    k7 ; k7 = 96
.line	1341	loadk         r9    k8 ; k8 = 191
.line	1341	loadk        r10    k9 ; k9 = 228
.line	1341	loadk        r11   k10 ; k10 = 49
.line	1341	loadk        r12   k11 ; k11 = 70
.line	1341	loadk        r13   k12 ; k12 = 167
.line	1341	loadk        r14   k13 ; k13 = 201
.line	1341	loadk        r15   k14 ; k14 = 121
.line	1341	loadk        r16   k15 ; k15 = 57
.line	1341	loadk        r17   k16 ; k16 = 251
.line	1341	loadk        r18   k17 ; k17 = 182
.line	1341	loadk        r19   k18 ; k18 = 126
.line	1341	loadk        r20   k19 ; k19 = 130
.line	1341	loadk        r21   k20 ; k20 = 225
.line	1341	loadk        r22   k21 ; k21 = 100
.line	1341	loadk        r23   k22 ; k22 = 188
.line	1341	loadk        r24   k23 ; k23 = 65
.line	1341	loadk        r25   k23 ; k23 = 65
.line	1341	loadk        r26   k24 ; k24 = 226
.line	1341	loadk        r27   k25 ; k25 = 81
.line	1341	loadk        r28   k26 ; k26 = 69
.line	1341	loadk        r29   k27 ; k27 = 173
.line	1341	loadk        r30   k28 ; k28 = 221
.line	1341	loadk        r31   k29 ; k29 = 116
.line	1341	loadk        r32   k30 ; k30 = 61
.line	1341	loadk        r33   k31 ; k31 = 231
.line	1341	loadk        r34   k32 ; k32 = 136
.line	1341	loadk        r35   k33 ; k33 = 118
.line	1341	loadk        r36   k13 ; k13 = 201
.line	1341	loadk        r37   k34 ; k34 = 215
.line	1341	loadk        r38   k35 ; k35 = 112
.line	1341	loadk        r39   k36 ; k36 = 184
.line	1341	loadk        r40   k37 ; k37 = 101
.line	1341	loadk        r41   k38 ; k38 = 91
.line	1341	loadk        r42   k39 ; k39 = 243
.line	1341	loadk        r43    k5 ; k5 = 68
.line	1341	loadk        r44   k40 ; k40 = 84
.line	1341	call          r4    41     2
.line	1341	getupval      r5    u1
.line	1341	loadk         r6   k41 ; k41 = 55
.line	1341	loadk         r7   k42 ; k42 = 95
.line	1341	loadk         r8   k43 ; k43 = 249
.line	1341	loadk         r9   k44 ; k44 = 119
.line	1341	loadk        r10   k45 ; k45 = 181
.line	1341	loadk        r11   k46 ; k46 = 213
.line	1341	loadk        r12   k47 ; k47 = 44
.line	1341	call          r5     8     0
.line	1341	setlist       r3     0     1
.line	1341	call          r2     2     2
.label	l61
.line	1341	call          r1     2     1
.line	1341	gettable      r1    r0   k48 ; k48 = "ChangeAvatarFormCDTi" (truncated)
.line	1341	test          r1     0
.line	1341	jmp            0   l69
.line	1341	self          r1    r0   k49 ; k49 = "RemoveTimer"
.line	1341	gettable      r3    r0   k48 ; k48 = "ChangeAvatarFormCDTi" (truncated)
.line	1341	call          r1     3     1
.line	1341	settable      r0   k48   k50 ; k50 = nil
.label	l69
.line	1341	settable      r0   k51   k50 ; k50 = nil
.line	1341	gettabup      r1    u2   k52 ; k52 = "GetXSuitTailButtonSt" (truncated)
.line	1341	call          r1     1     2
.line	1341	gettable      r2    r1   k54 ; k54 = "bAvailable"
.line	1341	eq             1    r2   k55 ; k55 = true
.line	1341	jmp            0   l76
.line	1341	loadbool      r2     0     1
.label	l76
.line	1341	loadbool      r2     1     0
.line	1341	settable      r0   k53    r2 ; k53 = "bXSuitTailButton"
.line	1341	gettabup      r2    u2   k56 ; k56 = "RefreshXSuitTailRedP" (truncated)
.line	1341	move          r3    r0
.line	1341	gettable      r4    r0   k53 ; k53 = "bXSuitTailButton"
.line	1341	call          r2     3     1
.line	1341	gettable      r2    r0   k53 ; k53 = "bXSuitTailButton"
.line	1341	test          r2     0
.line	1341	jmp            0   l98
.line	1341	gettabup      r2    u2   k57 ; k57 = "ApplyXSuitTailButton" (truncated)
.line	1341	move          r3    r0
.line	1341	move          r4    r1
.line	1341	call          r2     3     2
.line	1341	settable      r0   k51    r2 ; k51 = "XSuitTailButtonIcon"
.line	1341	self          r2    r0   k58 ; k58 = "AddTimerLoop"
.line	1341	loadk         r4   k59 ; k59 = 0
.line	1341	closure       r5    f0
.line	1341	gettabup      r6    u0   k60 ; k60 = "TIMER_INFINITE"
.line	1341	loadk         r7   k61 ; k61 = 0.2
.line	1341	call          r2     6     2
.line	1341	settable      r0   k48    r2 ; k48 = "ChangeAvatarFormCDTi" (truncated)
.line	1341	return        r0     1
.label	l98
.line	1341	gettable      r2    r0   k62 ; k62 = "Button_ChangeAvatarF" (truncated)
.line	1341	self          r2    r2   k63 ; k63 = "SetIsEnabled"
.line	1341	loadbool      r4     1     0
.line	1341	call          r2     3     1
.line	1341	gettable      r2    r0   k62 ; k62 = "Button_ChangeAvatarF" (truncated)
.line	1341	self          r2    r2   k64 ; k64 = "SetWidgetVisibility"
.line	1341	gettabup      r4    u0   k65 ; k65 = "UEnums"
.line	1341	gettable      r4    r4   k66 ; k66 = "ESlateVisibility"
.line	1341	gettable      r4    r4   k67 ; k67 = "Collapsed"
.line	1341	call          r2     3     1
.line	1341	gettabup      r2    u3   k68 ; k68 = "GetPlayerCharacter"
.line	1341	call          r2     1     2
.line	1341	test          r2     0
.line	1341	jmp            0  l118
.line	1341	gettabup      r3    u0   k69 ; k69 = "slua"
.line	1341	gettable      r3    r3   k70 ; k70 = "isValid"
.line	1341	move          r4    r2
.line	1341	call          r3     2     2
.line	1341	test          r3     1
.line	1341	jmp            0  l119
.label	l118
.line	1341	return        r0     1
.label	l119
.line	1341	gettabup      r3    u2   k71 ; k71 = "GetAvatarFormState"
.line	1341	move          r4    r2
.line	1341	call          r3     2     2
.line	1341	eq             0    r3   k59 ; k59 = 0
.line	1341	jmp            0  l125
.line	1341	return        r0     1
.label	l125
.line	1341	gettabup      r4    u2   k72 ; k72 = "GetAvatarFormIcon"
.line	1341	move          r5    r2
.line	1341	call          r4     2     2
.line	1341	test          r4     1
.line	1341	jmp            0  l131
.line	1341	return        r0     1
.label	l131
.line	1341	gettable      r5    r0   k62 ; k62 = "Button_ChangeAvatarF" (truncated)
.line	1341	self          r5    r5   k64 ; k64 = "SetWidgetVisibility"
.line	1341	gettabup      r7    u0   k65 ; k65 = "UEnums"
.line	1341	gettable      r7    r7   k66 ; k66 = "ESlateVisibility"
.line	1341	gettable      r7    r7   k73 ; k73 = "Visible"
.line	1341	call          r5     3     1
.line	1341	gettabup      r5    u4   k74 ; k74 = "SetTexture"
.line	1341	gettable      r6    r0   k75 ; k75 = "Image_ChangeAvatarFo" (truncated)
.line	1341	move          r7    r4
.line	1341	newtable      r8     0     1
.line	1341	settable      r8   k76   k77 ; k77 = false
.line	1341	call          r5     4     1
.line	1341	self          r5    r0   k58 ; k58 = "AddTimerLoop"
.line	1341	loadk         r7   k59 ; k59 = 0
.line	1341	closure       r8    f1
.line	1341	gettabup      r9    u0   k60 ; k60 = "TIMER_INFINITE"
.line	1341	loadk        r10   k61 ; k61 = 0.2
.line	1341	call          r5     6     2
.line	1341	settable      r0   k48    r5 ; k48 = "ChangeAvatarFormCDTi" (truncated)
.line	1341	return        r0     1
.line	1341	move          r0    r0
.line	1341	move          r0    r0
.line	1341	return        r0     1

.function	main/f55/f0

.source	null
.linedefined	1353
.lastlinedefined	1355
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	true

.constant	k0	"TickChangeAvatarFormCD"

.line	1353	getupval      r0    u0
.line	1353	self          r0    r0    k0 ; k0 = "TickChangeAvatarForm" (truncated)
.line	1353	call          r0     2     1
.line	1353	return        r0     1
.line	1353	move          r0    r0
.line	1353	return        r0     1

.function	main/f55/f1

.source	null
.linedefined	1374
.lastlinedefined	1376
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	true

.constant	k0	"TickChangeAvatarFormCD"

.line	1374	getupval      r0    u0
.line	1374	self          r0    r0    k0 ; k0 = "TickChangeAvatarForm" (truncated)
.line	1374	call          r0     2     1
.line	1374	return        r0     1
.line	1374	move          r0    r0
.line	1374	move          r0    r0
.line	1374	move          r0    r0
.line	1374	move          r0    r0
.line	1374	return        r0     1

.function	main/f56

.source	null
.linedefined	1379
.lastlinedefined	1414
.numparams	1
.is_vararg	0
.maxstacksize	23

.upvalue	"_ENV"	22	true
.upvalue	"U1"	14	true
.upvalue	"U2"	0	false
.upvalue	"U3"	1	true

.constant	k0	"bXSuitTailButton"
.constant	k1	"GetXSuitTailButtonState"
.constant	k2	"bAvailable"
.constant	k3	"RefreshChangeAvatarFormBtnState"
.constant	k4	"XSuitTailButtonIcon"
.constant	k5	"ApplyXSuitTailButtonState"
.constant	k6	"GetPlayerCharacter"
.constant	k7	"slua"
.constant	k8	"isValid"
.constant	k9	"SkillManager"
.constant	k10	"GetSkillBaseData"
.constant	k11	1014419
.constant	k12	"SkillCDs"
.constant	k13	"Num"
.constant	k14	1
.constant	k15	"Get"
.constant	k16	0
.constant	k17	"Image_CDTime"
.constant	k18	"GetMaxTime"
.constant	k19	"GetCurrentTime"
.constant	k20	"GetDynamicMaterial"
.constant	k21	"SetWidgetVisibility"
.constant	k22	"UEnums"
.constant	k23	"ESlateVisibility"
.constant	k24	"SelfHitTestInvisible"
.constant	k25	"SetScalarParameterValue"
.constant	k26	14
.constant	k27	80
.constant	k28	217
.constant	k29	104
.constant	k30	139
.constant	k31	241
.constant	k32	44
.constant	k33	68
.constant	k34	182
.constant	k35	201
.constant	k36	100
.constant	k37	62

.line	1379	gettable      r1    r0    k0 ; k0 = "bXSuitTailButton"
.line	1379	test          r1     0
.line	1379	jmp            0   l19
.line	1379	gettabup      r1    u0    k1 ; k1 = "GetXSuitTailButtonSt" (truncated)
.line	1379	call          r1     1     2
.line	1379	gettable      r2    r1    k2 ; k2 = "bAvailable"
.line	1379	test          r2     1
.line	1379	jmp            0   l12
.line	1379	self          r2    r0    k3 ; k3 = "RefreshChangeAvatarF" (truncated)
.line	1379	call          r2     2     1
.line	1379	return        r0     1
.label	l12
.line	1379	gettabup      r2    u0    k5 ; k5 = "ApplyXSuitTailButton" (truncated)
.line	1379	move          r3    r0
.line	1379	move          r4    r1
.line	1379	gettable      r5    r0    k4 ; k4 = "XSuitTailButtonIcon"
.line	1379	call          r2     4     2
.line	1379	settable      r0    k4    r2 ; k4 = "XSuitTailButtonIcon"
.line	1379	return        r0     1
.label	l19
.line	1379	gettabup      r1    u1    k6 ; k6 = "GetPlayerCharacter"
.line	1379	call          r1     1     2
.line	1379	gettabup      r2    u2    k7 ; k7 = "slua"
.line	1379	gettable      r2    r2    k8 ; k8 = "isValid"
.line	1379	move          r3    r1
.line	1379	call          r2     2     2
.line	1379	test          r2     1
.line	1379	jmp            0   l28
.line	1379	return        r0     1
.label	l28
.line	1379	gettabup      r2    u2    k7 ; k7 = "slua"
.line	1379	gettable      r2    r2    k8 ; k8 = "isValid"
.line	1379	gettable      r3    r1    k9 ; k9 = "SkillManager"
.line	1379	call          r2     2     2
.line	1379	test          r2     1
.line	1379	jmp            0   l35
.line	1379	return        r0     1
.label	l35
.line	1379	gettable      r2    r1    k9 ; k9 = "SkillManager"
.line	1379	self          r2    r2   k10 ; k10 = "GetSkillBaseData"
.line	1379	loadk         r4   k11 ; k11 = 1014419
.line	1379	call          r2     3     2
.line	1379	gettable      r2    r2   k12 ; k12 = "SkillCDs"
.line	1379	loadnil       r3     0
.line	1379	self          r4    r2   k13 ; k13 = "Num"
.line	1379	call          r4     2     2
.line	1379	le             0   k14    r4 ; k14 = 1
.line	1379	jmp            0   l49
.line	1379	self          r4    r2   k15 ; k15 = "Get"
.line	1379	loadk         r6   k16 ; k16 = 0
.line	1379	call          r4     3     2
.line	1379	move          r3    r4
.label	l49
.line	1379	gettabup      r4    u2    k7 ; k7 = "slua"
.line	1379	gettable      r4    r4    k8 ; k8 = "isValid"
.line	1379	move          r5    r3
.line	1379	call          r4     2     2
.line	1379	test          r4     1
.line	1379	jmp            0   l56
.line	1379	return        r0     1
.label	l56
.line	1379	gettabup      r4    u2    k7 ; k7 = "slua"
.line	1379	gettable      r4    r4    k8 ; k8 = "isValid"
.line	1379	gettable      r5    r0   k17 ; k17 = "Image_CDTime"
.line	1379	call          r4     2     2
.line	1379	test          r4     0
.line	1379	jmp            0   l99
.line	1379	self          r4    r3   k18 ; k18 = "GetMaxTime"
.line	1379	call          r4     2     2
.line	1379	self          r5    r3   k19 ; k19 = "GetCurrentTime"
.line	1379	call          r5     2     2
.line	1379	div           r6    r5    r4
.line	1379	gettable      r7    r0   k17 ; k17 = "Image_CDTime"
.line	1379	self          r7    r7   k20 ; k20 = "GetDynamicMaterial"
.line	1379	call          r7     2     2
.line	1379	gettabup      r8    u2    k7 ; k7 = "slua"
.line	1379	gettable      r8    r8    k8 ; k8 = "isValid"
.line	1379	move          r9    r7
.line	1379	call          r8     2     2
.line	1379	test          r8     0
.line	1379	jmp            0   l99
.line	1379	gettable      r8    r0   k17 ; k17 = "Image_CDTime"
.line	1379	self          r8    r8   k21 ; k21 = "SetWidgetVisibility"
.line	1379	gettabup     r10    u2   k22 ; k22 = "UEnums"
.line	1379	gettable     r10   r10   k23 ; k23 = "ESlateVisibility"
.line	1379	gettable     r10   r10   k24 ; k24 = "SelfHitTestInvisible"
.line	1379	call          r8     3     1
.line	1379	self          r8    r7   k25 ; k25 = "SetScalarParameterVa" (truncated)
.line	1379	getupval     r10    u3
.line	1379	loadk        r11   k26 ; k26 = 14
.line	1379	loadk        r12   k27 ; k27 = 80
.line	1379	loadk        r13   k28 ; k28 = 217
.line	1379	loadk        r14   k29 ; k29 = 104
.line	1379	loadk        r15   k30 ; k30 = 139
.line	1379	loadk        r16   k31 ; k31 = 241
.line	1379	loadk        r17   k32 ; k32 = 44
.line	1379	loadk        r18   k33 ; k33 = 68
.line	1379	loadk        r19   k34 ; k34 = 182
.line	1379	loadk        r20   k35 ; k35 = 201
.line	1379	loadk        r21   k36 ; k36 = 100
.line	1379	loadk        r22   k37 ; k37 = 62
.line	1379	call         r10    13     2
.line	1379	move         r11    r6
.line	1379	call          r8     4     1
.label	l99
.line	1379	return        r0     1
.line	1379	move          r0    r0
.line	1379	move          r0    r0
.line	1379	return        r0     1

.function	main/f57

.source	null
.linedefined	1416
.lastlinedefined	1465
.numparams	1
.is_vararg	0
.maxstacksize	52

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	14	true
.upvalue	"U3"	5	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	18
.constant	k3	68
.constant	k4	195
.constant	k5	96
.constant	k6	191
.constant	k7	228
.constant	k8	49
.constant	k9	70
.constant	k10	167
.constant	k11	201
.constant	k12	121
.constant	k13	57
.constant	k14	251
.constant	k15	182
.constant	k16	126
.constant	k17	130
.constant	k18	225
.constant	k19	100
.constant	k20	188
.constant	k21	65
.constant	k22	226
.constant	k23	81
.constant	k24	82
.constant	k25	183
.constant	k26	221
.constant	k27	116
.constant	k28	41
.constant	k29	166
.constant	k30	114
.constant	k31	197
.constant	k32	190
.constant	k33	87
.constant	k34	91
.constant	k35	239
.constant	k36	"ChangeDragonFormCDTimer"
.constant	k37	"RemoveTimer"
.constant	k38	nil
.constant	k39	"IsHide"
.constant	k40	"GetPlayerCharacter"
.constant	k41	"slua"
.constant	k42	"isValid"
.constant	k43	"SubsystemMgr"
.constant	k44	"Get"
.constant	k45	2
.constant	k46	71
.constant	k47	203
.constant	k48	119
.constant	k49	181
.constant	k50	211
.constant	k51	10
.constant	k52	94
.constant	k53	180
.constant	k54	194
.constant	k55	109
.constant	k56	47
.constant	k57	212
.constant	k58	98
.constant	k59	213
.constant	k60	224
.constant	k61	184
.constant	k62	64
.constant	k63	93
.constant	k64	77
.constant	k65	99
.constant	k66	168
.constant	k67	"CheckChangeFormCondition"
.constant	k68	"Button_Transfiguration"
.constant	k69	"SetWidgetVisibility"
.constant	k70	"UEnums"
.constant	k71	"ESlateVisibility"
.constant	k72	"Visible"
.constant	k73	"CDataTable"
.constant	k74	"GetTableData"
.constant	k75	0
.constant	k76	200
.constant	k77	39
.constant	k78	134
.constant	k79	216
.constant	k80	107
.constant	k81	62
.constant	k82	247
.constant	k83	154
.constant	k84	127
.constant	k85	214
.constant	k86	104
.constant	k87	189
.constant	k88	"AfterClothID"
.constant	k89	"BattleIcon"
.constant	k90	"SetTexture"
.constant	k91	"Image_50"
.constant	k92	"ActionType"
.constant	k93	"table"
.constant	k94	"concat"
.constant	k95	108
.constant	k96	118
.constant	k97	110
.constant	k98	177
.constant	k99	142
.constant	k100	8
.constant	k101	161
.constant	k102	223
.constant	k103	37
.constant	k104	31
.constant	k105	219
.constant	k106	246
.constant	k107	204
.constant	k108	169
.constant	k109	28
.constant	k110	102
.constant	k111	240
.constant	k112	217
.constant	k113	79
.constant	k114	19
.constant	k115	173
.constant	k116	135
.constant	k117	101
.constant	k118	66
.constant	k119	174
.constant	k120	111
.constant	k121	34
.constant	k122	92
.constant	k123	207
.constant	k124	112
.constant	k125	13
.constant	k126	105
.constant	k127	156
.constant	k128	36
.constant	k129	205
.constant	k130	141
.constant	k131	90
.constant	k132	67
.constant	k133	75
.constant	k134	103
.constant	k135	117
.constant	k136	52
.constant	k137	185
.constant	k138	124
.constant	k139	125
.constant	k140	120
.constant	k141	186
.constant	k142	210
.constant	k143	95
.constant	k144	178
.constant	k145	43
.constant	k146	230
.constant	k147	176
.constant	k148	236
.constant	k149	113
.constant	k150	84
.constant	k151	249
.constant	k152	50
.constant	k153	32
.constant	k154	196
.constant	k155	128
.constant	k156	40
.constant	k157	88
.constant	k158	202
.constant	k159	45
.constant	k160	231
.constant	k161	171
.constant	k162	218
.constant	k163	20
.constant	k164	163
.constant	k165	"GlobalData"
.constant	k166	"IsJapanOrKorea"
.constant	k167	"GetUnlockState"
.constant	k168	"Image_mask"
.constant	k169	"Collapsed"
.constant	k170	"Image_lock"
.constant	k171	"SelfHitTestInvisible"
.constant	k172	"AddTimerLoop"
.constant	k173	"TIMER_INFINITE"
.constant	k174	0.2

.line	1416	gettabup      r1    u0    k0 ; k0 = "print"
.line	1416	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1416	test          r2     0
.line	1416	jmp            0   l45
.line	1416	getupval      r2    u1
.line	1416	loadk         r3    k2 ; k2 = 18
.line	1416	loadk         r4    k3 ; k3 = 68
.line	1416	loadk         r5    k4 ; k4 = 195
.line	1416	loadk         r6    k5 ; k5 = 96
.line	1416	loadk         r7    k6 ; k6 = 191
.line	1416	loadk         r8    k7 ; k7 = 228
.line	1416	loadk         r9    k8 ; k8 = 49
.line	1416	loadk        r10    k9 ; k9 = 70
.line	1416	loadk        r11   k10 ; k10 = 167
.line	1416	loadk        r12   k11 ; k11 = 201
.line	1416	loadk        r13   k12 ; k12 = 121
.line	1416	loadk        r14   k13 ; k13 = 57
.line	1416	loadk        r15   k14 ; k14 = 251
.line	1416	loadk        r16   k15 ; k15 = 182
.line	1416	loadk        r17   k16 ; k16 = 126
.line	1416	loadk        r18   k17 ; k17 = 130
.line	1416	loadk        r19   k18 ; k18 = 225
.line	1416	loadk        r20   k19 ; k19 = 100
.line	1416	loadk        r21   k20 ; k20 = 188
.line	1416	loadk        r22   k21 ; k21 = 65
.line	1416	loadk        r23   k21 ; k21 = 65
.line	1416	loadk        r24   k22 ; k22 = 226
.line	1416	loadk        r25   k23 ; k23 = 81
.line	1416	loadk        r26   k24 ; k24 = 82
.line	1416	loadk        r27   k25 ; k25 = 183
.line	1416	loadk        r28   k26 ; k26 = 221
.line	1416	loadk        r29   k27 ; k27 = 116
.line	1416	loadk        r30   k28 ; k28 = 41
.line	1416	loadk        r31    k7 ; k7 = 228
.line	1416	loadk        r32   k29 ; k29 = 166
.line	1416	loadk        r33   k30 ; k30 = 114
.line	1416	loadk        r34   k31 ; k31 = 197
.line	1416	loadk        r35   k18 ; k18 = 225
.line	1416	loadk        r36   k19 ; k19 = 100
.line	1416	loadk        r37   k32 ; k32 = 190
.line	1416	loadk        r38   k33 ; k33 = 87
.line	1416	loadk        r39   k34 ; k34 = 91
.line	1416	loadk        r40   k35 ; k35 = 239
.line	1416	call          r2    39     2
.label	l45
.line	1416	call          r1     2     1
.line	1416	gettable      r1    r0   k36 ; k36 = "ChangeDragonFormCDTi" (truncated)
.line	1416	test          r1     0
.line	1416	jmp            0   l53
.line	1416	self          r1    r0   k37 ; k37 = "RemoveTimer"
.line	1416	gettable      r3    r0   k36 ; k36 = "ChangeDragonFormCDTi" (truncated)
.line	1416	call          r1     3     1
.line	1416	settable      r0   k36   k38 ; k38 = nil
.label	l53
.line	1416	self          r1    r0   k39 ; k39 = "IsHide"
.line	1416	call          r1     2     2
.line	1416	test          r1     0
.line	1416	jmp            0   l58
.line	1416	return        r0     1
.label	l58
.line	1416	gettabup      r1    u2   k40 ; k40 = "GetPlayerCharacter"
.line	1416	call          r1     1     2
.line	1416	test          r1     0
.line	1416	jmp            0   l68
.line	1416	gettabup      r2    u0   k41 ; k41 = "slua"
.line	1416	gettable      r2    r2   k42 ; k42 = "isValid"
.line	1416	move          r3    r1
.line	1416	call          r2     2     2
.line	1416	test          r2     1
.line	1416	jmp            0   l69
.label	l68
.line	1416	return        r0     1
.label	l69
.line	1416	gettabup      r2    u0   k43 ; k43 = "SubsystemMgr"
.line	1416	self          r2    r2   k44 ; k44 = "Get"
.line	1416	getupval      r4    u1
.line	1416	loadk         r5   k45 ; k45 = 2
.line	1416	loadk         r6   k46 ; k46 = 71
.line	1416	loadk         r7   k47 ; k47 = 203
.line	1416	loadk         r8   k48 ; k48 = 119
.line	1416	loadk         r9   k49 ; k49 = 181
.line	1416	loadk        r10   k50 ; k50 = 211
.line	1416	loadk        r11   k51 ; k51 = 10
.line	1416	loadk        r12   k52 ; k52 = 94
.line	1416	loadk        r13   k53 ; k53 = 180
.line	1416	loadk        r14   k54 ; k54 = 194
.line	1416	loadk        r15   k55 ; k55 = 109
.line	1416	loadk        r16   k56 ; k56 = 47
.line	1416	loadk        r17   k57 ; k57 = 212
.line	1416	loadk        r18   k15 ; k15 = 182
.line	1416	loadk        r19   k58 ; k58 = 98
.line	1416	loadk        r20   k59 ; k59 = 213
.line	1416	loadk        r21   k60 ; k60 = 224
.line	1416	loadk        r22   k27 ; k27 = 116
.line	1416	loadk        r23   k61 ; k61 = 184
.line	1416	loadk        r24   k62 ; k62 = 64
.line	1416	loadk        r25   k63 ; k63 = 93
.line	1416	loadk        r26   k22 ; k22 = 226
.line	1416	loadk        r27   k64 ; k64 = 77
.line	1416	loadk        r28   k65 ; k65 = 99
.line	1416	loadk        r29   k66 ; k66 = 168
.line	1416	call          r4    26     2
.line	1416	call          r2     3     2
.line	1416	test          r2     0
.line	1416	jmp            0  l448
.line	1416	self          r3    r2   k67 ; k67 = "CheckChangeFormCondi" (truncated)
.line	1416	move          r5    r1
.line	1416	call          r3     3     2
.line	1416	test          r3     0
.line	1416	jmp            0  l441
.line	1416	gettable      r4    r0   k68 ; k68 = "Button_Transfigurati" (truncated)
.line	1416	self          r4    r4   k69 ; k69 = "SetWidgetVisibility"
.line	1416	gettabup      r6    u0   k70 ; k70 = "UEnums"
.line	1416	gettable      r6    r6   k71 ; k71 = "ESlateVisibility"
.line	1416	gettable      r6    r6   k72 ; k72 = "Visible"
.line	1416	call          r4     3     1
.line	1416	gettabup      r4    u0   k73 ; k73 = "CDataTable"
.line	1416	gettable      r4    r4   k74 ; k74 = "GetTableData"
.line	1416	getupval      r5    u1
.line	1416	loadk         r6   k75 ; k75 = 0
.line	1416	loadk         r7   k63 ; k63 = 93
.line	1416	loadk         r8   k31 ; k31 = 197
.line	1416	loadk         r9   k48 ; k48 = 119
.line	1416	loadk        r10   k20 ; k20 = 188
.line	1416	loadk        r11   k76 ; k76 = 200
.line	1416	loadk        r12   k77 ; k77 = 39
.line	1416	loadk        r13   k23 ; k23 = 81
.line	1416	loadk        r14   k78 ; k78 = 134
.line	1416	loadk        r15   k79 ; k79 = 216
.line	1416	loadk        r16   k80 ; k80 = 107
.line	1416	loadk        r17   k81 ; k81 = 62
.line	1416	loadk        r18   k82 ; k82 = 247
.line	1416	loadk        r19   k83 ; k83 = 154
.line	1416	loadk        r20   k84 ; k84 = 127
.line	1416	loadk        r21   k85 ; k85 = 214
.line	1416	loadk        r22   k59 ; k59 = 213
.line	1416	loadk        r23   k86 ; k86 = 104
.line	1416	loadk        r24   k87 ; k87 = 189
.line	1416	call          r5    20     2
.line	1416	gettable      r6    r3   k88 ; k88 = "AfterClothID"
.line	1416	call          r4     3     2
.line	1416	testset       r5    r4     0
.line	1416	jmp            0  l140
.line	1416	gettable      r5    r4   k89 ; k89 = "BattleIcon"
.label	l140
.line	1416	test          r5     0
.line	1416	jmp            0  l147
.line	1416	gettabup      r6    u3   k90 ; k90 = "SetTexture"
.line	1416	gettable      r7    r0   k91 ; k91 = "Image_50"
.line	1416	move          r8    r5
.line	1416	call          r6     3     1
.line	1416	jmp            0  l385
.label	l147
.line	1416	gettable      r6    r3   k92 ; k92 = "ActionType"
.line	1416	eq             0    r6   k75 ; k75 = 0
.line	1416	jmp            0  l265
.line	1416	gettabup      r6    u3   k90 ; k90 = "SetTexture"
.line	1416	gettable      r7    r0   k91 ; k91 = "Image_50"
.line	1416	gettabup      r8    u0   k93 ; k93 = "table"
.line	1416	gettable      r8    r8   k94 ; k94 = "concat"
.line	1416	newtable      r9     2     0
.line	1416	getupval     r10    u1
.line	1416	loadk        r11   k95 ; k95 = 108
.line	1416	loadk        r12   k96 ; k96 = 118
.line	1416	loadk        r13   k47 ; k47 = 203
.line	1416	loadk        r14   k97 ; k97 = 110
.line	1416	loadk        r15   k98 ; k98 = 177
.line	1416	loadk        r16   k99 ; k99 = 142
.line	1416	loadk        r17  k100 ; k100 = 8
.line	1416	loadk        r18    k3 ; k3 = 68
.line	1416	loadk        r19  k101 ; k101 = 161
.line	1416	loadk        r20  k102 ; k102 = 223
.line	1416	loadk        r21  k103 ; k103 = 37
.line	1416	loadk        r22  k104 ; k104 = 31
.line	1416	loadk        r23  k105 ; k105 = 219
.line	1416	loadk        r24  k106 ; k106 = 246
.line	1416	loadk        r25   k23 ; k23 = 81
.line	1416	loadk        r26  k107 ; k107 = 204
.line	1416	loadk        r27  k102 ; k102 = 223
.line	1416	loadk        r28    k5 ; k5 = 96
.line	1416	loadk        r29  k108 ; k108 = 169
.line	1416	loadk        r30  k109 ; k109 = 28
.line	1416	loadk        r31  k110 ; k110 = 102
.line	1416	loadk        r32  k111 ; k111 = 240
.line	1416	loadk        r33   k64 ; k64 = 77
.line	1416	loadk        r34   k30 ; k30 = 114
.line	1416	loadk        r35  k108 ; k108 = 169
.line	1416	loadk        r36  k112 ; k112 = 217
.line	1416	loadk        r37  k113 ; k113 = 79
.line	1416	loadk        r38  k114 ; k114 = 19
.line	1416	loadk        r39  k115 ; k115 = 173
.line	1416	loadk        r40  k116 ; k116 = 135
.line	1416	loadk        r41  k117 ; k117 = 101
.line	1416	loadk        r42  k102 ; k102 = 223
.line	1416	loadk        r43   k22 ; k22 = 226
.line	1416	loadk        r44  k117 ; k117 = 101
.line	1416	loadk        r45   k29 ; k29 = 166
.line	1416	loadk        r46  k118 ; k118 = 66
.line	1416	loadk        r47   k46 ; k46 = 71
.line	1416	loadk        r48  k119 ; k119 = 174
.line	1416	loadk        r49  k120 ; k120 = 111
.line	1416	loadk        r50   k19 ; k19 = 100
.line	1416	call         r10    41     2
.line	1416	getupval     r11    u1
.line	1416	loadk        r12  k121 ; k121 = 34
.line	1416	loadk        r13  k122 ; k122 = 92
.line	1416	loadk        r14  k123 ; k123 = 207
.line	1416	loadk        r15  k124 ; k124 = 112
.line	1416	loadk        r16   k14 ; k14 = 251
.line	1416	loadk        r17   k14 ; k14 = 251
.line	1416	loadk        r18  k125 ; k125 = 13
.line	1416	loadk        r19  k126 ; k126 = 105
.line	1416	loadk        r20  k127 ; k127 = 156
.line	1416	loadk        r21  k123 ; k123 = 207
.line	1416	loadk        r22  k117 ; k117 = 101
.line	1416	loadk        r23  k128 ; k128 = 36
.line	1416	loadk        r24  k129 ; k129 = 205
.line	1416	loadk        r25  k130 ; k130 = 141
.line	1416	loadk        r26   k58 ; k58 = 98
.line	1416	loadk        r27  k112 ; k112 = 217
.line	1416	loadk        r28   k26 ; k26 = 221
.line	1416	loadk        r29   k30 ; k30 = 114
.line	1416	loadk        r30   k20 ; k20 = 188
.line	1416	loadk        r31  k131 ; k131 = 90
.line	1416	loadk        r32  k132 ; k132 = 67
.line	1416	loadk        r33    k7 ; k7 = 228
.line	1416	loadk        r34  k133 ; k133 = 75
.line	1416	loadk        r35  k134 ; k134 = 103
.line	1416	loadk        r36   k98 ; k98 = 177
.line	1416	loadk        r37   k59 ; k59 = 213
.line	1416	loadk        r38  k135 ; k135 = 117
.line	1416	loadk        r39  k136 ; k136 = 52
.line	1416	loadk        r40   k26 ; k26 = 221
.line	1416	loadk        r41  k137 ; k137 = 185
.line	1416	loadk        r42   k97 ; k97 = 110
.line	1416	loadk        r43  k123 ; k123 = 207
.line	1416	loadk        r44  k130 ; k130 = 141
.line	1416	loadk        r45  k133 ; k133 = 75
.line	1416	loadk        r46   k99 ; k99 = 142
.line	1416	loadk        r47  k138 ; k138 = 124
.line	1416	loadk        r48  k139 ; k139 = 125
.line	1416	loadk        r49   k22 ; k22 = 226
.line	1416	loadk        r50    k9 ; k9 = 70
.line	1416	loadk        r51  k140 ; k140 = 120
.line	1416	call         r11    41     2
.line	1416	getupval     r12    u1
.line	1416	loadk        r13  k109 ; k109 = 28
.line	1416	loadk        r14  k117 ; k117 = 101
.line	1416	loadk        r15   k79 ; k79 = 216
.line	1416	loadk        r16   k58 ; k58 = 98
.line	1416	loadk        r17  k141 ; k141 = 186
.line	1416	loadk        r18  k142 ; k142 = 210
.line	1416	loadk        r19   k56 ; k56 = 47
.line	1416	loadk        r20  k143 ; k143 = 95
.line	1416	loadk        r21  k144 ; k144 = 178
.line	1416	loadk        r22  k112 ; k112 = 217
.line	1416	loadk        r23  k140 ; k140 = 120
.line	1416	loadk        r24  k145 ; k145 = 43
.line	1416	loadk        r25  k146 ; k146 = 230
.line	1416	loadk        r26  k147 ; k147 = 176
.line	1416	loadk        r27   k84 ; k84 = 127
.line	1416	loadk        r28   k85 ; k85 = 214
.line	1416	loadk        r29  k148 ; k148 = 236
.line	1416	loadk        r30  k149 ; k149 = 113
.line	1416	loadk        r31   k53 ; k53 = 180
.line	1416	loadk        r32  k150 ; k150 = 84
.line	1416	call         r12    21     0
.line	1416	setlist       r9     0     1
.line	1416	call          r8     2     2
.line	1416	call          r6     3     1
.line	1416	jmp            0  l385
.label	l265
.line	1416	gettabup      r6    u3   k90 ; k90 = "SetTexture"
.line	1416	gettable      r7    r0   k91 ; k91 = "Image_50"
.line	1416	gettabup      r8    u0   k93 ; k93 = "table"
.line	1416	gettable      r8    r8   k94 ; k94 = "concat"
.line	1416	newtable      r9     2     0
.line	1416	getupval     r10    u1
.line	1416	loadk        r11   k95 ; k95 = 108
.line	1416	loadk        r12   k96 ; k96 = 118
.line	1416	loadk        r13   k47 ; k47 = 203
.line	1416	loadk        r14   k97 ; k97 = 110
.line	1416	loadk        r15   k98 ; k98 = 177
.line	1416	loadk        r16   k99 ; k99 = 142
.line	1416	loadk        r17  k100 ; k100 = 8
.line	1416	loadk        r18    k3 ; k3 = 68
.line	1416	loadk        r19  k101 ; k101 = 161
.line	1416	loadk        r20  k102 ; k102 = 223
.line	1416	loadk        r21  k103 ; k103 = 37
.line	1416	loadk        r22  k104 ; k104 = 31
.line	1416	loadk        r23  k105 ; k105 = 219
.line	1416	loadk        r24  k106 ; k106 = 246
.line	1416	loadk        r25   k23 ; k23 = 81
.line	1416	loadk        r26  k107 ; k107 = 204
.line	1416	loadk        r27  k102 ; k102 = 223
.line	1416	loadk        r28    k5 ; k5 = 96
.line	1416	loadk        r29  k108 ; k108 = 169
.line	1416	loadk        r30  k109 ; k109 = 28
.line	1416	loadk        r31  k110 ; k110 = 102
.line	1416	loadk        r32  k111 ; k111 = 240
.line	1416	loadk        r33   k64 ; k64 = 77
.line	1416	loadk        r34   k30 ; k30 = 114
.line	1416	loadk        r35  k108 ; k108 = 169
.line	1416	loadk        r36  k112 ; k112 = 217
.line	1416	loadk        r37  k113 ; k113 = 79
.line	1416	loadk        r38  k114 ; k114 = 19
.line	1416	loadk        r39  k115 ; k115 = 173
.line	1416	loadk        r40  k116 ; k116 = 135
.line	1416	loadk        r41  k117 ; k117 = 101
.line	1416	loadk        r42  k102 ; k102 = 223
.line	1416	loadk        r43   k22 ; k22 = 226
.line	1416	loadk        r44  k117 ; k117 = 101
.line	1416	loadk        r45   k29 ; k29 = 166
.line	1416	loadk        r46  k118 ; k118 = 66
.line	1416	loadk        r47   k46 ; k46 = 71
.line	1416	loadk        r48  k119 ; k119 = 174
.line	1416	loadk        r49  k120 ; k120 = 111
.line	1416	loadk        r50   k19 ; k19 = 100
.line	1416	call         r10    41     2
.line	1416	getupval     r11    u1
.line	1416	loadk        r12  k121 ; k121 = 34
.line	1416	loadk        r13  k122 ; k122 = 92
.line	1416	loadk        r14  k123 ; k123 = 207
.line	1416	loadk        r15  k124 ; k124 = 112
.line	1416	loadk        r16   k14 ; k14 = 251
.line	1416	loadk        r17   k14 ; k14 = 251
.line	1416	loadk        r18  k125 ; k125 = 13
.line	1416	loadk        r19  k126 ; k126 = 105
.line	1416	loadk        r20  k127 ; k127 = 156
.line	1416	loadk        r21  k123 ; k123 = 207
.line	1416	loadk        r22  k117 ; k117 = 101
.line	1416	loadk        r23  k128 ; k128 = 36
.line	1416	loadk        r24  k129 ; k129 = 205
.line	1416	loadk        r25  k130 ; k130 = 141
.line	1416	loadk        r26   k58 ; k58 = 98
.line	1416	loadk        r27  k112 ; k112 = 217
.line	1416	loadk        r28   k26 ; k26 = 221
.line	1416	loadk        r29   k30 ; k30 = 114
.line	1416	loadk        r30   k20 ; k20 = 188
.line	1416	loadk        r31  k131 ; k131 = 90
.line	1416	loadk        r32  k132 ; k132 = 67
.line	1416	loadk        r33    k7 ; k7 = 228
.line	1416	loadk        r34  k133 ; k133 = 75
.line	1416	loadk        r35  k134 ; k134 = 103
.line	1416	loadk        r36   k98 ; k98 = 177
.line	1416	loadk        r37   k59 ; k59 = 213
.line	1416	loadk        r38  k135 ; k135 = 117
.line	1416	loadk        r39  k136 ; k136 = 52
.line	1416	loadk        r40   k26 ; k26 = 221
.line	1416	loadk        r41  k151 ; k151 = 249
.line	1416	loadk        r42  k152 ; k152 = 50
.line	1416	loadk        r43   k82 ; k82 = 247
.line	1416	loadk        r44   k50 ; k50 = 211
.line	1416	loadk        r45   k84 ; k84 = 127
.line	1416	loadk        r46  k115 ; k115 = 173
.line	1416	loadk        r47  k125 ; k125 = 13
.line	1416	loadk        r48   k97 ; k97 = 110
.line	1416	loadk        r49   k31 ; k31 = 197
.line	1416	loadk        r50   k96 ; k96 = 118
.line	1416	loadk        r51  k143 ; k143 = 95
.line	1416	call         r11    41     2
.line	1416	getupval     r12    u1
.line	1416	loadk        r13  k153 ; k153 = 32
.line	1416	loadk        r14   k52 ; k52 = 94
.line	1416	loadk        r15  k154 ; k154 = 196
.line	1416	loadk        r16  k122 ; k122 = 92
.line	1416	loadk        r17  k155 ; k155 = 128
.line	1416	loadk        r18   k50 ; k50 = 211
.line	1416	loadk        r19  k156 ; k156 = 40
.line	1416	loadk        r20  k157 ; k157 = 88
.line	1416	loadk        r21   k29 ; k29 = 166
.line	1416	loadk        r22  k158 ; k158 = 202
.line	1416	loadk        r23   k65 ; k65 = 99
.line	1416	loadk        r24  k159 ; k159 = 45
.line	1416	loadk        r25  k160 ; k160 = 231
.line	1416	loadk        r26  k161 ; k161 = 171
.line	1416	loadk        r27  k149 ; k149 = 113
.line	1416	loadk        r28  k107 ; k107 = 204
.line	1416	loadk        r29  k162 ; k162 = 218
.line	1416	loadk        r30   k97 ; k97 = 110
.line	1416	loadk        r31   k53 ; k53 = 180
.line	1416	loadk        r32   k95 ; k95 = 108
.line	1416	loadk        r33  k163 ; k163 = 20
.line	1416	loadk        r34  k164 ; k164 = 163
.line	1416	loadk        r35  k110 ; k110 = 102
.line	1416	loadk        r36   k96 ; k96 = 118
.line	1416	loadk        r37  k161 ; k161 = 171
.line	1416	loadk        r38  k105 ; k105 = 219
.line	1416	call         r12    27     0
.line	1416	setlist       r9     0     1
.line	1416	call          r8     2     2
.line	1416	call          r6     3     1
.label	l385
.line	1416	gettabup      r6    u0  k165 ; k165 = "GlobalData"
.line	1416	gettable      r6    r6  k166 ; k166 = "IsJapanOrKorea"
.line	1416	call          r6     1     2
.line	1416	test          r6     0
.line	1416	jmp            0  l421
.line	1416	self          r6    r2  k167 ; k167 = "GetUnlockState"
.line	1416	move          r8    r1
.line	1416	call          r6     3     2
.line	1416	test          r6     0
.line	1416	jmp            0  l408
.line	1416	gettable      r7    r0  k168 ; k168 = "Image_mask"
.line	1416	self          r7    r7   k69 ; k69 = "SetWidgetVisibility"
.line	1416	gettabup      r9    u0   k70 ; k70 = "UEnums"
.line	1416	gettable      r9    r9   k71 ; k71 = "ESlateVisibility"
.line	1416	gettable      r9    r9  k169 ; k169 = "Collapsed"
.line	1416	call          r7     3     1
.line	1416	gettable      r7    r0  k170 ; k170 = "Image_lock"
.line	1416	self          r7    r7   k69 ; k69 = "SetWidgetVisibility"
.line	1416	gettabup      r9    u0   k70 ; k70 = "UEnums"
.line	1416	gettable      r9    r9   k71 ; k71 = "ESlateVisibility"
.line	1416	gettable      r9    r9  k169 ; k169 = "Collapsed"
.line	1416	call          r7     3     1
.line	1416	jmp            0  l433
.label	l408
.line	1416	gettable      r7    r0  k168 ; k168 = "Image_mask"
.line	1416	self          r7    r7   k69 ; k69 = "SetWidgetVisibility"
.line	1416	gettabup      r9    u0   k70 ; k70 = "UEnums"
.line	1416	gettable      r9    r9   k71 ; k71 = "ESlateVisibility"
.line	1416	gettable      r9    r9  k171 ; k171 = "SelfHitTestInvisible"
.line	1416	call          r7     3     1
.line	1416	gettable      r7    r0  k170 ; k170 = "Image_lock"
.line	1416	self          r7    r7   k69 ; k69 = "SetWidgetVisibility"
.line	1416	gettabup      r9    u0   k70 ; k70 = "UEnums"
.line	1416	gettable      r9    r9   k71 ; k71 = "ESlateVisibility"
.line	1416	gettable      r9    r9  k171 ; k171 = "SelfHitTestInvisible"
.line	1416	call          r7     3     1
.line	1416	jmp            0  l433
.label	l421
.line	1416	gettable      r6    r0  k168 ; k168 = "Image_mask"
.line	1416	self          r6    r6   k69 ; k69 = "SetWidgetVisibility"
.line	1416	gettabup      r8    u0   k70 ; k70 = "UEnums"
.line	1416	gettable      r8    r8   k71 ; k71 = "ESlateVisibility"
.line	1416	gettable      r8    r8  k169 ; k169 = "Collapsed"
.line	1416	call          r6     3     1
.line	1416	gettable      r6    r0  k170 ; k170 = "Image_lock"
.line	1416	self          r6    r6   k69 ; k69 = "SetWidgetVisibility"
.line	1416	gettabup      r8    u0   k70 ; k70 = "UEnums"
.line	1416	gettable      r8    r8   k71 ; k71 = "ESlateVisibility"
.line	1416	gettable      r8    r8  k169 ; k169 = "Collapsed"
.line	1416	call          r6     3     1
.label	l433
.line	1416	self          r6    r0  k172 ; k172 = "AddTimerLoop"
.line	1416	loadk         r8   k75 ; k75 = 0
.line	1416	closure       r9    f0
.line	1416	gettabup     r10    u0  k173 ; k173 = "TIMER_INFINITE"
.line	1416	loadk        r11  k174 ; k174 = 0.2
.line	1416	call          r6     6     2
.line	1416	settable      r0   k36    r6 ; k36 = "ChangeDragonFormCDTi" (truncated)
.line	1416	jmp            0  l454
.label	l441
.line	1416	gettable      r4    r0   k68 ; k68 = "Button_Transfigurati" (truncated)
.line	1416	self          r4    r4   k69 ; k69 = "SetWidgetVisibility"
.line	1416	gettabup      r6    u0   k70 ; k70 = "UEnums"
.line	1416	gettable      r6    r6   k71 ; k71 = "ESlateVisibility"
.line	1416	gettable      r6    r6  k169 ; k169 = "Collapsed"
.line	1416	call          r4     3     1
.line	1416	jmp            0  l454
.label	l448
.line	1416	gettable      r3    r0   k68 ; k68 = "Button_Transfigurati" (truncated)
.line	1416	self          r3    r3   k69 ; k69 = "SetWidgetVisibility"
.line	1416	gettabup      r5    u0   k70 ; k70 = "UEnums"
.line	1416	gettable      r5    r5   k71 ; k71 = "ESlateVisibility"
.line	1416	gettable      r5    r5  k169 ; k169 = "Collapsed"
.line	1416	call          r3     3     1
.label	l454
.line	1416	return        r0     1
.line	1416	move          r0    r0
.line	1416	gettabup      r1    u1   k63 ; k63 = 93
.line	1416	gettabup      r3    u0   k41 ; k41 = "slua"
.line	1416	return        r0     1

.function	main/f57/f0

.source	null
.linedefined	1456
.lastlinedefined	1458
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	true

.constant	k0	"TickChangeDragonFormCD"

.line	1456	getupval      r0    u0
.line	1456	self          r0    r0    k0 ; k0 = "TickChangeDragonForm" (truncated)
.line	1456	call          r0     2     1
.line	1456	return        r0     1
.line	1456	move          r0    r0
.line	1456	move          r0    r0
.line	1456	return        r0     1

.function	main/f58

.source	null
.linedefined	1467
.lastlinedefined	1493
.numparams	1
.is_vararg	0
.maxstacksize	23

.upvalue	"_ENV"	14	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"GetPlayerCharacter"
.constant	k1	"slua"
.constant	k2	"isValid"
.constant	k3	"SkillManager"
.constant	k4	"GetSkillBaseData"
.constant	k5	1014419
.constant	k6	"SkillCDs"
.constant	k7	"Num"
.constant	k8	1
.constant	k9	"Get"
.constant	k10	0
.constant	k11	"Image_53"
.constant	k12	"GetMaxTime"
.constant	k13	"GetCurrentTime"
.constant	k14	"GetDynamicMaterial"
.constant	k15	"SetWidgetVisibility"
.constant	k16	"UEnums"
.constant	k17	"ESlateVisibility"
.constant	k18	"SelfHitTestInvisible"
.constant	k19	"SetScalarParameterValue"
.constant	k20	14
.constant	k21	80
.constant	k22	217
.constant	k23	104
.constant	k24	139
.constant	k25	241
.constant	k26	44
.constant	k27	68
.constant	k28	182
.constant	k29	201
.constant	k30	100
.constant	k31	62

.line	1467	gettabup      r1    u0    k0 ; k0 = "GetPlayerCharacter"
.line	1467	call          r1     1     2
.line	1467	gettabup      r2    u1    k1 ; k1 = "slua"
.line	1467	gettable      r2    r2    k2 ; k2 = "isValid"
.line	1467	move          r3    r1
.line	1467	call          r2     2     2
.line	1467	test          r2     1
.line	1467	jmp            0   l10
.line	1467	return        r0     1
.label	l10
.line	1467	gettabup      r2    u1    k1 ; k1 = "slua"
.line	1467	gettable      r2    r2    k2 ; k2 = "isValid"
.line	1467	gettable      r3    r1    k3 ; k3 = "SkillManager"
.line	1467	call          r2     2     2
.line	1467	test          r2     1
.line	1467	jmp            0   l17
.line	1467	return        r0     1
.label	l17
.line	1467	gettable      r2    r1    k3 ; k3 = "SkillManager"
.line	1467	self          r2    r2    k4 ; k4 = "GetSkillBaseData"
.line	1467	loadk         r4    k5 ; k5 = 1014419
.line	1467	call          r2     3     2
.line	1467	gettable      r2    r2    k6 ; k6 = "SkillCDs"
.line	1467	loadnil       r3     0
.line	1467	self          r4    r2    k7 ; k7 = "Num"
.line	1467	call          r4     2     2
.line	1467	le             0    k8    r4 ; k8 = 1
.line	1467	jmp            0   l31
.line	1467	self          r4    r2    k9 ; k9 = "Get"
.line	1467	loadk         r6   k10 ; k10 = 0
.line	1467	call          r4     3     2
.line	1467	move          r3    r4
.label	l31
.line	1467	gettabup      r4    u1    k1 ; k1 = "slua"
.line	1467	gettable      r4    r4    k2 ; k2 = "isValid"
.line	1467	move          r5    r3
.line	1467	call          r4     2     2
.line	1467	test          r4     1
.line	1467	jmp            0   l38
.line	1467	return        r0     1
.label	l38
.line	1467	gettabup      r4    u1    k1 ; k1 = "slua"
.line	1467	gettable      r4    r4    k2 ; k2 = "isValid"
.line	1467	gettable      r5    r0   k11 ; k11 = "Image_53"
.line	1467	call          r4     2     2
.line	1467	test          r4     0
.line	1467	jmp            0   l81
.line	1467	self          r4    r3   k12 ; k12 = "GetMaxTime"
.line	1467	call          r4     2     2
.line	1467	self          r5    r3   k13 ; k13 = "GetCurrentTime"
.line	1467	call          r5     2     2
.line	1467	div           r6    r5    r4
.line	1467	gettable      r7    r0   k11 ; k11 = "Image_53"
.line	1467	self          r7    r7   k14 ; k14 = "GetDynamicMaterial"
.line	1467	call          r7     2     2
.line	1467	gettabup      r8    u1    k1 ; k1 = "slua"
.line	1467	gettable      r8    r8    k2 ; k2 = "isValid"
.line	1467	move          r9    r7
.line	1467	call          r8     2     2
.line	1467	test          r8     0
.line	1467	jmp            0   l81
.line	1467	gettable      r8    r0   k11 ; k11 = "Image_53"
.line	1467	self          r8    r8   k15 ; k15 = "SetWidgetVisibility"
.line	1467	gettabup     r10    u1   k16 ; k16 = "UEnums"
.line	1467	gettable     r10   r10   k17 ; k17 = "ESlateVisibility"
.line	1467	gettable     r10   r10   k18 ; k18 = "SelfHitTestInvisible"
.line	1467	call          r8     3     1
.line	1467	self          r8    r7   k19 ; k19 = "SetScalarParameterVa" (truncated)
.line	1467	getupval     r10    u2
.line	1467	loadk        r11   k20 ; k20 = 14
.line	1467	loadk        r12   k21 ; k21 = 80
.line	1467	loadk        r13   k22 ; k22 = 217
.line	1467	loadk        r14   k23 ; k23 = 104
.line	1467	loadk        r15   k24 ; k24 = 139
.line	1467	loadk        r16   k25 ; k25 = 241
.line	1467	loadk        r17   k26 ; k26 = 44
.line	1467	loadk        r18   k27 ; k27 = 68
.line	1467	loadk        r19   k28 ; k28 = 182
.line	1467	loadk        r20   k29 ; k29 = 201
.line	1467	loadk        r21   k30 ; k30 = 100
.line	1467	loadk        r22   k31 ; k31 = 62
.line	1467	call         r10    13     2
.line	1467	move         r11    r6
.line	1467	call          r8     4     1
.label	l81
.line	1467	return        r0     1
.line	1467	move          r0    r0
.line	1467	move          r0    r0
.line	1467	move          r0    r0
.line	1467	return        r0     1

.function	main/f59

.source	null
.linedefined	1495
.lastlinedefined	1514
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	24
.constant	k5	117
.constant	k6	207
.constant	k7	98
.constant	k8	186
.constant	k9	235
.constant	k10	16
.constant	k11	136
.constant	k12	140
.constant	k13	91
.constant	k14	63
.constant	k15	251
.constant	k16	123
.constant	k17	253
.constant	k18	203
.constant	k19	113
.constant	k20	168
.constant	k21	86
.constant	k22	87
.constant	k23	226
.constant	k24	80
.constant	k25	105
.constant	k26	171
.constant	k27	134
.constant	k28	72
.constant	k29	228
.constant	k30	187
.constant	k31	101
.constant	k32	219
.constant	k33	66
.constant	k34	175
.constant	k35	79
.constant	k36	82
.constant	k37	232
.constant	k38	76
.constant	k39	84
.constant	k40	54
.constant	k41	69
.constant	k42	222
.constant	k43	108
.constant	k44	"LobbySystem"
.constant	k45	"CheckOpen"
.constant	k46	"BP_ENUM_MODULE_SELFIE_SWITCH"
.constant	k47	"Button_Selfie"
.constant	k48	"SetWidgetVisibility"
.constant	k49	"UEnums"
.constant	k50	"ESlateVisibility"
.constant	k51	"Collapsed"
.constant	k52	"SubsystemMgr"
.constant	k53	"Get"
.constant	k54	10
.constant	k55	95
.constant	k56	205
.constant	k57	185
.constant	k58	196
.constant	k59	26
.constant	k60	83
.constant	k61	202
.constant	k62	99
.constant	k63	47
.constant	k64	193
.constant	k65	172
.constant	k66	114
.constant	k67	174
.constant	k68	73
.constant	k69	129
.constant	k70	42
.constant	k71	194
.constant	k72	62
.constant	k73	178
.constant	k74	190
.constant	k75	204
.constant	k76	147
.constant	k77	180
.constant	k78	252
.constant	k79	92
.constant	k80	85
.constant	k81	160
.constant	k82	208
.constant	k83	124
.constant	k84	51
.constant	k85	231
.constant	k86	154
.constant	k87	104
.constant	k88	81
.constant	k89	236
.constant	k90	"CheckModeCanEnterSelfie"
.constant	k91	"GetIsInSelfieMode"
.constant	k92	33
.constant	k93	177
.constant	k94	201
.constant	k95	57
.constant	k96	247
.constant	k97	181
.constant	k98	118
.constant	k99	209
.constant	k100	214
.constant	k101	184
.constant	k102	70
.constant	k103	229
.constant	k104	58
.constant	k105	94
.constant	k106	"Visible"

.line	1495	gettabup      r1    u0    k0 ; k0 = "log"
.line	1495	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1495	test          r2     0
.line	1495	jmp            0   l59
.line	1495	gettabup      r2    u0    k2 ; k2 = "table"
.line	1495	gettable      r2    r2    k3 ; k3 = "concat"
.line	1495	newtable      r3     1     0
.line	1495	getupval      r4    u1
.line	1495	loadk         r5    k4 ; k4 = 24
.line	1495	loadk         r6    k5 ; k5 = 117
.line	1495	loadk         r7    k6 ; k6 = 207
.line	1495	loadk         r8    k7 ; k7 = 98
.line	1495	loadk         r9    k8 ; k8 = 186
.line	1495	loadk        r10    k9 ; k9 = 235
.line	1495	loadk        r11   k10 ; k10 = 16
.line	1495	loadk        r12    k7 ; k7 = 98
.line	1495	loadk        r13   k11 ; k11 = 136
.line	1495	loadk        r14   k12 ; k12 = 140
.line	1495	loadk        r15   k13 ; k13 = 91
.line	1495	loadk        r16   k14 ; k14 = 63
.line	1495	loadk        r17   k15 ; k15 = 251
.line	1495	loadk        r18    k8 ; k8 = 186
.line	1495	loadk        r19   k16 ; k16 = 123
.line	1495	loadk        r20   k17 ; k17 = 253
.line	1495	loadk        r21   k18 ; k18 = 203
.line	1495	loadk        r22   k19 ; k19 = 113
.line	1495	loadk        r23   k20 ; k20 = 168
.line	1495	loadk        r24   k21 ; k21 = 86
.line	1495	loadk        r25   k22 ; k22 = 87
.line	1495	loadk        r26   k23 ; k23 = 226
.line	1495	loadk        r27   k24 ; k24 = 80
.line	1495	loadk        r28   k25 ; k25 = 105
.line	1495	loadk        r29   k26 ; k26 = 171
.line	1495	loadk        r30   k27 ; k27 = 134
.line	1495	loadk        r31   k28 ; k28 = 72
.line	1495	loadk        r32   k14 ; k14 = 63
.line	1495	loadk        r33   k29 ; k29 = 228
.line	1495	loadk        r34   k30 ; k30 = 187
.line	1495	loadk        r35   k31 ; k31 = 101
.line	1495	loadk        r36   k32 ; k32 = 219
.line	1495	loadk        r37   k18 ; k18 = 203
.line	1495	loadk        r38   k33 ; k33 = 66
.line	1495	loadk        r39   k34 ; k34 = 175
.line	1495	loadk        r40   k35 ; k35 = 79
.line	1495	loadk        r41   k36 ; k36 = 82
.line	1495	loadk        r42   k37 ; k37 = 232
.line	1495	loadk        r43   k38 ; k38 = 76
.line	1495	loadk        r44   k39 ; k39 = 84
.line	1495	call          r4    41     2
.line	1495	getupval      r5    u1
.line	1495	loadk         r6   k40 ; k40 = 54
.line	1495	loadk         r7   k41 ; k41 = 69
.line	1495	loadk         r8   k42 ; k42 = 222
.line	1495	loadk         r9   k43 ; k43 = 108
.line	1495	loadk        r10    k8 ; k8 = 186
.line	1495	call          r5     6     0
.line	1495	setlist       r3     0     1
.line	1495	call          r2     2     2
.label	l59
.line	1495	call          r1     2     1
.line	1495	gettabup      r1    u0   k44 ; k44 = "LobbySystem"
.line	1495	gettable      r1    r1   k45 ; k45 = "CheckOpen"
.line	1495	gettabup      r2    u0   k46 ; k46 = "BP_ENUM_MODULE_SELFI" (truncated)
.line	1495	call          r1     2     2
.line	1495	test          r1     1
.line	1495	jmp            0   l73
.line	1495	gettable      r1    r0   k47 ; k47 = "Button_Selfie"
.line	1495	self          r1    r1   k48 ; k48 = "SetWidgetVisibility"
.line	1495	gettabup      r3    u0   k49 ; k49 = "UEnums"
.line	1495	gettable      r3    r3   k50 ; k50 = "ESlateVisibility"
.line	1495	gettable      r3    r3   k51 ; k51 = "Collapsed"
.line	1495	call          r1     3     1
.line	1495	return        r0     1
.label	l73
.line	1495	gettabup      r1    u0   k52 ; k52 = "SubsystemMgr"
.line	1495	self          r1    r1   k53 ; k53 = "Get"
.line	1495	getupval      r3    u1
.line	1495	loadk         r4   k54 ; k54 = 10
.line	1495	loadk         r5   k55 ; k55 = 95
.line	1495	loadk         r6   k56 ; k56 = 205
.line	1495	loadk         r7    k7 ; k7 = 98
.line	1495	loadk         r8   k57 ; k57 = 185
.line	1495	loadk         r9   k58 ; k58 = 196
.line	1495	loadk        r10   k59 ; k59 = 26
.line	1495	loadk        r11   k60 ; k60 = 83
.line	1495	loadk        r12   k57 ; k57 = 185
.line	1495	loadk        r13   k61 ; k61 = 202
.line	1495	loadk        r14   k62 ; k62 = 99
.line	1495	loadk        r15   k63 ; k63 = 47
.line	1495	loadk        r16   k64 ; k64 = 193
.line	1495	loadk        r17   k65 ; k65 = 172
.line	1495	loadk        r18   k66 ; k66 = 114
.line	1495	loadk        r19   k18 ; k18 = 203
.line	1495	loadk        r20   k61 ; k61 = 202
.line	1495	loadk        r21   k66 ; k66 = 114
.line	1495	loadk        r22   k67 ; k67 = 174
.line	1495	loadk        r23   k21 ; k21 = 86
.line	1495	loadk        r24   k68 ; k68 = 73
.line	1495	call          r3    22     2
.line	1495	call          r1     3     2
.line	1495	test          r1     1
.line	1495	jmp            0  l200
.line	1495	gettable      r2    r0   k47 ; k47 = "Button_Selfie"
.line	1495	self          r2    r2   k48 ; k48 = "SetWidgetVisibility"
.line	1495	gettabup      r4    u0   k49 ; k49 = "UEnums"
.line	1495	gettable      r4    r4   k50 ; k50 = "ESlateVisibility"
.line	1495	gettable      r4    r4   k51 ; k51 = "Collapsed"
.line	1495	call          r2     3     1
.line	1495	gettabup      r2    u0    k0 ; k0 = "log"
.line	1495	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1495	test          r3     0
.line	1495	jmp            0  l198
.line	1495	gettabup      r3    u0    k2 ; k2 = "table"
.line	1495	gettable      r3    r3    k3 ; k3 = "concat"
.line	1495	newtable      r4     1     0
.line	1495	getupval      r5    u1
.line	1495	loadk         r6    k4 ; k4 = 24
.line	1495	loadk         r7    k5 ; k5 = 117
.line	1495	loadk         r8    k6 ; k6 = 207
.line	1495	loadk         r9    k7 ; k7 = 98
.line	1495	loadk        r10    k8 ; k8 = 186
.line	1495	loadk        r11    k9 ; k9 = 235
.line	1495	loadk        r12   k10 ; k10 = 16
.line	1495	loadk        r13    k7 ; k7 = 98
.line	1495	loadk        r14   k11 ; k11 = 136
.line	1495	loadk        r15   k12 ; k12 = 140
.line	1495	loadk        r16   k13 ; k13 = 91
.line	1495	loadk        r17   k14 ; k14 = 63
.line	1495	loadk        r18   k15 ; k15 = 251
.line	1495	loadk        r19    k8 ; k8 = 186
.line	1495	loadk        r20   k16 ; k16 = 123
.line	1495	loadk        r21   k17 ; k17 = 253
.line	1495	loadk        r22   k18 ; k18 = 203
.line	1495	loadk        r23   k19 ; k19 = 113
.line	1495	loadk        r24   k20 ; k20 = 168
.line	1495	loadk        r25   k21 ; k21 = 86
.line	1495	loadk        r26   k22 ; k22 = 87
.line	1495	loadk        r27   k23 ; k23 = 226
.line	1495	loadk        r28   k24 ; k24 = 80
.line	1495	loadk        r29   k25 ; k25 = 105
.line	1495	loadk        r30   k26 ; k26 = 171
.line	1495	loadk        r31   k27 ; k27 = 134
.line	1495	loadk        r32   k28 ; k28 = 72
.line	1495	loadk        r33   k14 ; k14 = 63
.line	1495	loadk        r34   k29 ; k29 = 228
.line	1495	loadk        r35   k30 ; k30 = 187
.line	1495	loadk        r36   k31 ; k31 = 101
.line	1495	loadk        r37   k32 ; k32 = 219
.line	1495	loadk        r38   k18 ; k18 = 203
.line	1495	loadk        r39   k33 ; k33 = 66
.line	1495	loadk        r40   k34 ; k34 = 175
.line	1495	loadk        r41   k35 ; k35 = 79
.line	1495	loadk        r42   k36 ; k36 = 82
.line	1495	loadk        r43   k37 ; k37 = 232
.line	1495	loadk        r44   k38 ; k38 = 76
.line	1495	loadk        r45   k39 ; k39 = 84
.line	1495	call          r5    41     2
.line	1495	getupval      r6    u1
.line	1495	loadk         r7   k40 ; k40 = 54
.line	1495	loadk         r8   k41 ; k41 = 69
.line	1495	loadk         r9   k42 ; k42 = 222
.line	1495	loadk        r10   k43 ; k43 = 108
.line	1495	loadk        r11    k8 ; k8 = 186
.line	1495	loadk        r12   k69 ; k69 = 129
.line	1495	loadk        r13   k70 ; k70 = 42
.line	1495	loadk        r14   k22 ; k22 = 87
.line	1495	loadk        r15   k30 ; k30 = 187
.line	1495	loadk        r16   k71 ; k71 = 194
.line	1495	loadk        r17   k31 ; k31 = 101
.line	1495	loadk        r18   k72 ; k72 = 62
.line	1495	loadk        r19   k73 ; k73 = 178
.line	1495	loadk        r20   k74 ; k74 = 190
.line	1495	loadk        r21    k5 ; k5 = 117
.line	1495	loadk        r22   k75 ; k75 = 204
.line	1495	loadk        r23   k76 ; k76 = 147
.line	1495	loadk        r24   k28 ; k28 = 72
.line	1495	loadk        r25   k77 ; k77 = 180
.line	1495	loadk        r26   k39 ; k39 = 84
.line	1495	loadk        r27   k41 ; k41 = 69
.line	1495	loadk        r28   k78 ; k78 = 252
.line	1495	loadk        r29   k79 ; k79 = 92
.line	1495	loadk        r30   k80 ; k80 = 85
.line	1495	loadk        r31   k81 ; k81 = 160
.line	1495	loadk        r32   k82 ; k82 = 208
.line	1495	loadk        r33   k83 ; k83 = 124
.line	1495	loadk        r34   k84 ; k84 = 51
.line	1495	loadk        r35   k85 ; k85 = 231
.line	1495	loadk        r36   k86 ; k86 = 154
.line	1495	loadk        r37    k5 ; k5 = 117
.line	1495	loadk        r38   k61 ; k61 = 202
.line	1495	loadk        r39   k82 ; k82 = 208
.line	1495	loadk        r40   k87 ; k87 = 104
.line	1495	loadk        r41   k57 ; k57 = 185
.line	1495	loadk        r42   k22 ; k22 = 87
.line	1495	loadk        r43   k88 ; k88 = 81
.line	1495	loadk        r44   k89 ; k89 = 236
.line	1495	call          r6    39     0
.line	1495	setlist       r4     0     1
.line	1495	call          r3     2     2
.label	l198
.line	1495	call          r2     2     1
.line	1495	return        r0     1
.label	l200
.line	1495	self          r2    r1   k90 ; k90 = "CheckModeCanEnterSel" (truncated)
.line	1495	call          r2     2     2
.line	1495	test          r2     0
.line	1495	jmp            0  l208
.line	1495	self          r2    r1   k91 ; k91 = "GetIsInSelfieMode"
.line	1495	call          r2     2     2
.line	1495	test          r2     0
.line	1495	jmp            0  l293
.label	l208
.line	1495	gettabup      r2    u0    k0 ; k0 = "log"
.line	1495	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1495	test          r3     0
.line	1495	jmp            0  l285
.line	1495	gettabup      r3    u0    k2 ; k2 = "table"
.line	1495	gettable      r3    r3    k3 ; k3 = "concat"
.line	1495	newtable      r4     1     0
.line	1495	getupval      r5    u1
.line	1495	loadk         r6    k4 ; k4 = 24
.line	1495	loadk         r7    k5 ; k5 = 117
.line	1495	loadk         r8    k6 ; k6 = 207
.line	1495	loadk         r9    k7 ; k7 = 98
.line	1495	loadk        r10    k8 ; k8 = 186
.line	1495	loadk        r11    k9 ; k9 = 235
.line	1495	loadk        r12   k10 ; k10 = 16
.line	1495	loadk        r13    k7 ; k7 = 98
.line	1495	loadk        r14   k11 ; k11 = 136
.line	1495	loadk        r15   k12 ; k12 = 140
.line	1495	loadk        r16   k13 ; k13 = 91
.line	1495	loadk        r17   k14 ; k14 = 63
.line	1495	loadk        r18   k15 ; k15 = 251
.line	1495	loadk        r19    k8 ; k8 = 186
.line	1495	loadk        r20   k16 ; k16 = 123
.line	1495	loadk        r21   k17 ; k17 = 253
.line	1495	loadk        r22   k18 ; k18 = 203
.line	1495	loadk        r23   k19 ; k19 = 113
.line	1495	loadk        r24   k20 ; k20 = 168
.line	1495	loadk        r25   k21 ; k21 = 86
.line	1495	loadk        r26   k22 ; k22 = 87
.line	1495	loadk        r27   k23 ; k23 = 226
.line	1495	loadk        r28   k24 ; k24 = 80
.line	1495	loadk        r29   k25 ; k25 = 105
.line	1495	loadk        r30   k26 ; k26 = 171
.line	1495	loadk        r31   k27 ; k27 = 134
.line	1495	loadk        r32   k28 ; k28 = 72
.line	1495	loadk        r33   k14 ; k14 = 63
.line	1495	loadk        r34   k29 ; k29 = 228
.line	1495	loadk        r35   k30 ; k30 = 187
.line	1495	loadk        r36   k31 ; k31 = 101
.line	1495	loadk        r37   k32 ; k32 = 219
.line	1495	loadk        r38   k18 ; k18 = 203
.line	1495	loadk        r39   k33 ; k33 = 66
.line	1495	loadk        r40   k34 ; k34 = 175
.line	1495	loadk        r41   k35 ; k35 = 79
.line	1495	loadk        r42   k36 ; k36 = 82
.line	1495	loadk        r43   k37 ; k37 = 232
.line	1495	loadk        r44   k38 ; k38 = 76
.line	1495	loadk        r45   k39 ; k39 = 84
.line	1495	call          r5    41     2
.line	1495	getupval      r6    u1
.line	1495	loadk         r7   k40 ; k40 = 54
.line	1495	loadk         r8   k41 ; k41 = 69
.line	1495	loadk         r9   k42 ; k42 = 222
.line	1495	loadk        r10   k43 ; k43 = 108
.line	1495	loadk        r11    k8 ; k8 = 186
.line	1495	loadk        r12   k69 ; k69 = 129
.line	1495	loadk        r13   k92 ; k92 = 33
.line	1495	loadk        r14   k55 ; k55 = 95
.line	1495	loadk        r15   k93 ; k93 = 177
.line	1495	loadk        r16   k94 ; k94 = 201
.line	1495	loadk        r17   k70 ; k70 = 42
.line	1495	loadk        r18   k95 ; k95 = 57
.line	1495	loadk        r19   k96 ; k96 = 247
.line	1495	loadk        r20   k97 ; k97 = 181
.line	1495	loadk        r21   k98 ; k98 = 118
.line	1495	loadk        r22   k99 ; k99 = 209
.line	1495	loadk        r23  k100 ; k100 = 214
.line	1495	loadk        r24   k92 ; k92 = 33
.line	1495	loadk        r25  k101 ; k101 = 184
.line	1495	loadk        r26  k102 ; k102 = 70
.line	1495	loadk        r27   k24 ; k24 = 80
.line	1495	loadk        r28  k103 ; k103 = 229
.line	1495	loadk        r29   k21 ; k21 = 86
.line	1495	loadk        r30   k87 ; k87 = 104
.line	1495	call          r6    25     0
.line	1495	setlist       r4     0     1
.line	1495	call          r3     2     2
.label	l285
.line	1495	call          r2     2     1
.line	1495	gettable      r2    r0   k47 ; k47 = "Button_Selfie"
.line	1495	self          r2    r2   k48 ; k48 = "SetWidgetVisibility"
.line	1495	gettabup      r4    u0   k49 ; k49 = "UEnums"
.line	1495	gettable      r4    r4   k50 ; k50 = "ESlateVisibility"
.line	1495	gettable      r4    r4   k51 ; k51 = "Collapsed"
.line	1495	call          r2     3     1
.line	1495	jmp            0  l377
.label	l293
.line	1495	gettabup      r2    u0    k0 ; k0 = "log"
.line	1495	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1495	test          r3     0
.line	1495	jmp            0  l370
.line	1495	gettabup      r3    u0    k2 ; k2 = "table"
.line	1495	gettable      r3    r3    k3 ; k3 = "concat"
.line	1495	newtable      r4     1     0
.line	1495	getupval      r5    u1
.line	1495	loadk         r6    k4 ; k4 = 24
.line	1495	loadk         r7    k5 ; k5 = 117
.line	1495	loadk         r8    k6 ; k6 = 207
.line	1495	loadk         r9    k7 ; k7 = 98
.line	1495	loadk        r10    k8 ; k8 = 186
.line	1495	loadk        r11    k9 ; k9 = 235
.line	1495	loadk        r12   k10 ; k10 = 16
.line	1495	loadk        r13    k7 ; k7 = 98
.line	1495	loadk        r14   k11 ; k11 = 136
.line	1495	loadk        r15   k12 ; k12 = 140
.line	1495	loadk        r16   k13 ; k13 = 91
.line	1495	loadk        r17   k14 ; k14 = 63
.line	1495	loadk        r18   k15 ; k15 = 251
.line	1495	loadk        r19    k8 ; k8 = 186
.line	1495	loadk        r20   k16 ; k16 = 123
.line	1495	loadk        r21   k17 ; k17 = 253
.line	1495	loadk        r22   k18 ; k18 = 203
.line	1495	loadk        r23   k19 ; k19 = 113
.line	1495	loadk        r24   k20 ; k20 = 168
.line	1495	loadk        r25   k21 ; k21 = 86
.line	1495	loadk        r26   k22 ; k22 = 87
.line	1495	loadk        r27   k23 ; k23 = 226
.line	1495	loadk        r28   k24 ; k24 = 80
.line	1495	loadk        r29   k25 ; k25 = 105
.line	1495	loadk        r30   k26 ; k26 = 171
.line	1495	loadk        r31   k27 ; k27 = 134
.line	1495	loadk        r32   k28 ; k28 = 72
.line	1495	loadk        r33   k14 ; k14 = 63
.line	1495	loadk        r34   k29 ; k29 = 228
.line	1495	loadk        r35   k30 ; k30 = 187
.line	1495	loadk        r36   k31 ; k31 = 101
.line	1495	loadk        r37   k32 ; k32 = 219
.line	1495	loadk        r38   k18 ; k18 = 203
.line	1495	loadk        r39   k33 ; k33 = 66
.line	1495	loadk        r40   k34 ; k34 = 175
.line	1495	loadk        r41   k35 ; k35 = 79
.line	1495	loadk        r42   k36 ; k36 = 82
.line	1495	loadk        r43   k37 ; k37 = 232
.line	1495	loadk        r44   k38 ; k38 = 76
.line	1495	loadk        r45   k39 ; k39 = 84
.line	1495	call          r5    41     2
.line	1495	getupval      r6    u1
.line	1495	loadk         r7   k40 ; k40 = 54
.line	1495	loadk         r8   k41 ; k41 = 69
.line	1495	loadk         r9   k42 ; k42 = 222
.line	1495	loadk        r10   k43 ; k43 = 108
.line	1495	loadk        r11    k8 ; k8 = 186
.line	1495	loadk        r12   k69 ; k69 = 129
.line	1495	loadk        r13  k104 ; k104 = 58
.line	1495	loadk        r14  k105 ; k105 = 94
.line	1495	loadk        r15    k8 ; k8 = 186
.line	1495	loadk        r16   k32 ; k32 = 219
.line	1495	loadk        r17   k70 ; k70 = 42
.line	1495	loadk        r18   k95 ; k95 = 57
.line	1495	loadk        r19   k96 ; k96 = 247
.line	1495	loadk        r20   k97 ; k97 = 181
.line	1495	loadk        r21   k98 ; k98 = 118
.line	1495	loadk        r22   k99 ; k99 = 209
.line	1495	loadk        r23  k100 ; k100 = 214
.line	1495	loadk        r24   k92 ; k92 = 33
.line	1495	loadk        r25  k101 ; k101 = 184
.line	1495	loadk        r26  k102 ; k102 = 70
.line	1495	loadk        r27   k24 ; k24 = 80
.line	1495	loadk        r28  k103 ; k103 = 229
.line	1495	loadk        r29   k21 ; k21 = 86
.line	1495	loadk        r30   k87 ; k87 = 104
.line	1495	call          r6    25     0
.line	1495	setlist       r4     0     1
.line	1495	call          r3     2     2
.label	l370
.line	1495	call          r2     2     1
.line	1495	gettable      r2    r0   k47 ; k47 = "Button_Selfie"
.line	1495	self          r2    r2   k48 ; k48 = "SetWidgetVisibility"
.line	1495	gettabup      r4    u0   k49 ; k49 = "UEnums"
.line	1495	gettable      r4    r4   k50 ; k50 = "ESlateVisibility"
.line	1495	gettable      r4    r4  k106 ; k106 = "Visible"
.line	1495	call          r2     3     1
.label	l377
.line	1495	return        r0     1
.line	1495	gettabup      r3    u0   k93 ; k93 = 177
.line	1495	move          r0    r0
.line	1495	return        r0     1

.function	main/f60

.source	null
.linedefined	1516
.lastlinedefined	1533
.numparams	1
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	4
.constant	k2	80
.constant	k3	199
.constant	k4	102
.constant	k5	152
.constant	k6	212
.constant	k7	40
.constant	k8	24
.constant	k9	146
.constant	k10	205
.constant	k11	103
.constant	k12	47
.constant	k13	209
.constant	k14	182
.constant	k15	98
.constant	k16	221
.constant	k17	157
.constant	k18	69
.constant	k19	187
.constant	k20	71
.constant	k21	191
.constant	k22	126
.constant	k23	168
.constant	k24	217
.constant	k25	106
.constant	k26	54
.constant	k27	227
.constant	k28	176
.constant	k29	68
.constant	k30	201
.constant	k31	215
.constant	k32	112
.constant	k33	"GetPlayerController"
.constant	k34	"slua"
.constant	k35	"isValid"
.constant	k36	"GetPlayerCharacterSafety"
.constant	k37	"PetComponent_BP"
.constant	k38	"PetInfo"
.constant	k39	"PetId"
.constant	k40	50023
.constant	k41	50024
.constant	k42	"print"
.constant	k43	"bWriteLog"
.constant	k44	"table"
.constant	k45	"concat"
.constant	k46	18
.constant	k47	195
.constant	k48	96
.constant	k49	228
.constant	k50	49
.constant	k51	70
.constant	k52	167
.constant	k53	121
.constant	k54	57
.constant	k55	251
.constant	k56	130
.constant	k57	240
.constant	k58	105
.constant	k59	79
.constant	k60	216
.constant	k61	74
.constant	k62	85
.constant	k63	181
.constant	k64	51
.constant	k65	165
.constant	k66	163
.constant	k67	20
.constant	k68	242
.constant	k69	89
.constant	k70	115
.constant	k71	32
.constant	k72	88
.constant	k73	203
.constant	k74	111
.constant	k75	244
.constant	k76	241
.constant	k77	44
.constant	k78	66
.constant	k79	239
.constant	k80	99
.constant	k81	218
.constant	k82	183
.constant	k83	200
.constant	k84	90
.constant	k85	245

.line	1516	gettabup      r1    u0    k0 ; k0 = "require"
.line	1516	getupval      r2    u1
.line	1516	loadk         r3    k1 ; k1 = 4
.line	1516	loadk         r4    k2 ; k2 = 80
.line	1516	loadk         r5    k3 ; k3 = 199
.line	1516	loadk         r6    k4 ; k4 = 102
.line	1516	loadk         r7    k5 ; k5 = 152
.line	1516	loadk         r8    k6 ; k6 = 212
.line	1516	loadk         r9    k7 ; k7 = 40
.line	1516	loadk        r10    k8 ; k8 = 24
.line	1516	loadk        r11    k9 ; k9 = 146
.line	1516	loadk        r12   k10 ; k10 = 205
.line	1516	loadk        r13   k11 ; k11 = 103
.line	1516	loadk        r14   k12 ; k12 = 47
.line	1516	loadk        r15   k13 ; k13 = 209
.line	1516	loadk        r16   k14 ; k14 = 182
.line	1516	loadk        r17   k15 ; k15 = 98
.line	1516	loadk        r18   k16 ; k16 = 221
.line	1516	loadk        r19   k17 ; k17 = 157
.line	1516	loadk        r20   k18 ; k18 = 69
.line	1516	loadk        r21   k19 ; k19 = 187
.line	1516	loadk        r22   k20 ; k20 = 71
.line	1516	loadk        r23   k18 ; k18 = 69
.line	1516	loadk        r24   k21 ; k21 = 191
.line	1516	loadk        r25   k22 ; k22 = 126
.line	1516	loadk        r26   k11 ; k11 = 103
.line	1516	loadk        r27   k23 ; k23 = 168
.line	1516	loadk        r28   k24 ; k24 = 217
.line	1516	loadk        r29   k25 ; k25 = 106
.line	1516	loadk        r30   k26 ; k26 = 54
.line	1516	loadk        r31   k27 ; k27 = 227
.line	1516	loadk        r32   k28 ; k28 = 176
.line	1516	loadk        r33   k29 ; k29 = 68
.line	1516	loadk        r34   k30 ; k30 = 201
.line	1516	loadk        r35   k31 ; k31 = 215
.line	1516	loadk        r36   k32 ; k32 = 112
.line	1516	call          r2    35     2
.line	1516	call          r1     2     2
.line	1516	gettable      r2    r1   k33 ; k33 = "GetPlayerController"
.line	1516	call          r2     1     2
.line	1516	gettabup      r3    u0   k34 ; k34 = "slua"
.line	1516	gettable      r3    r3   k35 ; k35 = "isValid"
.line	1516	move          r4    r2
.line	1516	call          r3     2     2
.line	1516	test          r3     1
.line	1516	jmp            0   l49
.line	1516	loadbool      r3     0     0
.line	1516	return        r3     2
.label	l49
.line	1516	self          r3    r2   k36 ; k36 = "GetPlayerCharacterSa" (truncated)
.line	1516	call          r3     2     2
.line	1516	gettabup      r4    u0   k34 ; k34 = "slua"
.line	1516	gettable      r4    r4   k35 ; k35 = "isValid"
.line	1516	move          r5    r3
.line	1516	call          r4     2     2
.line	1516	test          r4     0
.line	1516	jmp            0   l63
.line	1516	gettabup      r4    u0   k34 ; k34 = "slua"
.line	1516	gettable      r4    r4   k35 ; k35 = "isValid"
.line	1516	gettable      r5    r3   k37 ; k37 = "PetComponent_BP"
.line	1516	call          r4     2     2
.line	1516	test          r4     1
.line	1516	jmp            0   l65
.label	l63
.line	1516	loadbool      r4     0     0
.line	1516	return        r4     2
.label	l65
.line	1516	gettable      r4    r3   k37 ; k37 = "PetComponent_BP"
.line	1516	gettable      r4    r4   k38 ; k38 = "PetInfo"
.line	1516	gettable      r4    r4   k39 ; k39 = "PetId"
.line	1516	eq             1    r4   k40 ; k40 = 50023
.line	1516	jmp            0   l72
.line	1516	eq             0    r4   k41 ; k41 = 50024
.line	1516	jmp            0  l136
.label	l72
.line	1516	gettabup      r5    u0   k42 ; k42 = "print"
.line	1516	gettabup      r6    u0   k43 ; k43 = "bWriteLog"
.line	1516	test          r6     0
.line	1516	jmp            0  l133
.line	1516	gettabup      r6    u0   k44 ; k44 = "table"
.line	1516	gettable      r6    r6   k45 ; k45 = "concat"
.line	1516	newtable      r7     1     0
.line	1516	getupval      r8    u1
.line	1516	loadk         r9   k46 ; k46 = 18
.line	1516	loadk        r10   k29 ; k29 = 68
.line	1516	loadk        r11   k47 ; k47 = 195
.line	1516	loadk        r12   k48 ; k48 = 96
.line	1516	loadk        r13   k21 ; k21 = 191
.line	1516	loadk        r14   k49 ; k49 = 228
.line	1516	loadk        r15   k50 ; k50 = 49
.line	1516	loadk        r16   k51 ; k51 = 70
.line	1516	loadk        r17   k52 ; k52 = 167
.line	1516	loadk        r18   k30 ; k30 = 201
.line	1516	loadk        r19   k53 ; k53 = 121
.line	1516	loadk        r20   k54 ; k54 = 57
.line	1516	loadk        r21   k55 ; k55 = 251
.line	1516	loadk        r22   k14 ; k14 = 182
.line	1516	loadk        r23   k22 ; k22 = 126
.line	1516	loadk        r24   k56 ; k56 = 130
.line	1516	loadk        r25   k57 ; k57 = 240
.line	1516	loadk        r26   k58 ; k58 = 105
.line	1516	loadk        r27   k21 ; k21 = 191
.line	1516	loadk        r28    k2 ; k2 = 80
.line	1516	loadk        r29   k59 ; k59 = 79
.line	1516	loadk        r30   k60 ; k60 = 216
.line	1516	loadk        r31   k61 ; k61 = 74
.line	1516	loadk        r32   k62 ; k62 = 85
.line	1516	loadk        r33   k63 ; k63 = 181
.line	1516	loadk        r34   k24 ; k24 = 217
.line	1516	loadk        r35   k53 ; k53 = 121
.line	1516	loadk        r36   k64 ; k64 = 51
.line	1516	loadk        r37   k27 ; k27 = 227
.line	1516	loadk        r38   k65 ; k65 = 165
.line	1516	loadk        r39    k2 ; k2 = 80
.line	1516	loadk        r40   k10 ; k10 = 205
.line	1516	loadk        r41   k31 ; k31 = 215
.line	1516	loadk        r42   k50 ; k50 = 49
.line	1516	loadk        r43   k66 ; k66 = 163
.line	1516	loadk        r44    k2 ; k2 = 80
.line	1516	loadk        r45   k67 ; k67 = 20
.line	1516	loadk        r46   k68 ; k68 = 242
.line	1516	loadk        r47   k69 ; k69 = 89
.line	1516	loadk        r48   k70 ; k70 = 115
.line	1516	call          r8    41     2
.line	1516	getupval      r9    u1
.line	1516	loadk        r10   k71 ; k71 = 32
.line	1516	loadk        r11   k72 ; k72 = 88
.line	1516	loadk        r12   k73 ; k73 = 203
.line	1516	loadk        r13   k74 ; k74 = 111
.line	1516	loadk        r14   k75 ; k75 = 244
.line	1516	loadk        r15   k76 ; k76 = 241
.line	1516	loadk        r16   k77 ; k77 = 44
.line	1516	loadk        r17   k78 ; k78 = 66
.line	1516	call          r9     9     0
.line	1516	setlist       r7     0     1
.line	1516	call          r6     2     2
.label	l133
.line	1516	call          r5     2     1
.line	1516	loadbool      r5     1     0
.line	1516	return        r5     2
.label	l136
.line	1516	gettabup      r5    u0   k42 ; k42 = "print"
.line	1516	gettabup      r6    u0   k43 ; k43 = "bWriteLog"
.line	1516	test          r6     0
.line	1516	jmp            0  l198
.line	1516	gettabup      r6    u0   k44 ; k44 = "table"
.line	1516	gettable      r6    r6   k45 ; k45 = "concat"
.line	1516	newtable      r7     1     0
.line	1516	getupval      r8    u1
.line	1516	loadk         r9   k46 ; k46 = 18
.line	1516	loadk        r10   k29 ; k29 = 68
.line	1516	loadk        r11   k47 ; k47 = 195
.line	1516	loadk        r12   k48 ; k48 = 96
.line	1516	loadk        r13   k21 ; k21 = 191
.line	1516	loadk        r14   k49 ; k49 = 228
.line	1516	loadk        r15   k50 ; k50 = 49
.line	1516	loadk        r16   k51 ; k51 = 70
.line	1516	loadk        r17   k52 ; k52 = 167
.line	1516	loadk        r18   k30 ; k30 = 201
.line	1516	loadk        r19   k53 ; k53 = 121
.line	1516	loadk        r20   k54 ; k54 = 57
.line	1516	loadk        r21   k55 ; k55 = 251
.line	1516	loadk        r22   k14 ; k14 = 182
.line	1516	loadk        r23   k22 ; k22 = 126
.line	1516	loadk        r24   k56 ; k56 = 130
.line	1516	loadk        r25   k57 ; k57 = 240
.line	1516	loadk        r26   k58 ; k58 = 105
.line	1516	loadk        r27   k21 ; k21 = 191
.line	1516	loadk        r28    k2 ; k2 = 80
.line	1516	loadk        r29   k59 ; k59 = 79
.line	1516	loadk        r30   k60 ; k60 = 216
.line	1516	loadk        r31   k61 ; k61 = 74
.line	1516	loadk        r32   k62 ; k62 = 85
.line	1516	loadk        r33   k63 ; k63 = 181
.line	1516	loadk        r34   k24 ; k24 = 217
.line	1516	loadk        r35   k53 ; k53 = 121
.line	1516	loadk        r36   k64 ; k64 = 51
.line	1516	loadk        r37   k27 ; k27 = 227
.line	1516	loadk        r38   k65 ; k65 = 165
.line	1516	loadk        r39    k2 ; k2 = 80
.line	1516	loadk        r40   k10 ; k10 = 205
.line	1516	loadk        r41   k31 ; k31 = 215
.line	1516	loadk        r42   k50 ; k50 = 49
.line	1516	loadk        r43   k66 ; k66 = 163
.line	1516	loadk        r44    k2 ; k2 = 80
.line	1516	loadk        r45   k67 ; k67 = 20
.line	1516	loadk        r46   k79 ; k79 = 239
.line	1516	loadk        r47   k51 ; k51 = 70
.line	1516	loadk        r48   k15 ; k15 = 98
.line	1516	call          r8    41     2
.line	1516	getupval      r9    u1
.line	1516	loadk        r10   k80 ; k80 = 99
.line	1516	loadk        r11   k78 ; k78 = 66
.line	1516	loadk        r12   k81 ; k81 = 218
.line	1516	loadk        r13    k4 ; k4 = 102
.line	1516	loadk        r14   k82 ; k82 = 183
.line	1516	loadk        r15   k83 ; k83 = 200
.line	1516	loadk        r16    k7 ; k7 = 40
.line	1516	loadk        r17   k84 ; k84 = 90
.line	1516	loadk        r18   k85 ; k85 = 245
.line	1516	call          r9    10     0
.line	1516	setlist       r7     0     1
.line	1516	call          r6     2     2
.label	l198
.line	1516	call          r5     2     1
.line	1516	loadbool      r5     0     0
.line	1516	return        r5     2
.line	1516	return        r0     1
.line	1516	move          r0    r0
.line	1516	move          r0    r0
.line	1516	move          r0    r0
.line	1516	move          r0    r0
.line	1516	return        r0     1

.function	main/f61

.source	null
.linedefined	1535
.lastlinedefined	1548
.numparams	1
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	23	true
.upvalue	"U1"	0	false

.constant	k0	"AddTimerLoop"
.constant	k1	2
.constant	k2	5
.constant	k3	1

.line	1535	closure       r1    f0
.line	1535	move          r2    r1
.line	1535	call          r2     1     1
.line	1535	self          r2    r0    k0 ; k0 = "AddTimerLoop"
.line	1535	loadk         r4    k1 ; k1 = 2
.line	1535	closure       r5    f1
.line	1535	loadk         r6    k2 ; k2 = 5
.line	1535	loadk         r7    k3 ; k3 = 1
.line	1535	call          r2     6     1
.line	1535	return        r0     1
.line	1535	move          r0    r0
.line	1535	return        r0     1

.function	main/f61/f0

.source	null
.linedefined	1536
.lastlinedefined	1543
.numparams	0
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	false

.constant	k0	"CheckIsSpecialPet"
.constant	k1	"CurrentShowState"
.constant	k2	"PetExpression"
.constant	k3	"Button_PetFeature"
.constant	k4	"SetWidgetVisibility"
.constant	k5	"UEnums"
.constant	k6	"ESlateVisibility"
.constant	k7	"Visible"
.constant	k8	"Collapsed"

.line	1536	getupval      r0    u0
.line	1536	self          r0    r0    k0 ; k0 = "CheckIsSpecialPet"
.line	1536	call          r0     2     2
.line	1536	test          r0     0
.line	1536	jmp            0   l17
.line	1536	gettabup      r1    u0    k1 ; k1 = "CurrentShowState"
.line	1536	gettabup      r2    u1    k2 ; k2 = "PetExpression"
.line	1536	eq             0    r1    r2
.line	1536	jmp            0   l17
.line	1536	gettabup      r1    u0    k3 ; k3 = "Button_PetFeature"
.line	1536	self          r1    r1    k4 ; k4 = "SetWidgetVisibility"
.line	1536	gettabup      r3    u2    k5 ; k5 = "UEnums"
.line	1536	gettable      r3    r3    k6 ; k6 = "ESlateVisibility"
.line	1536	gettable      r3    r3    k7 ; k7 = "Visible"
.line	1536	call          r1     3     1
.line	1536	jmp            0   l23
.label	l17
.line	1536	gettabup      r1    u0    k3 ; k3 = "Button_PetFeature"
.line	1536	self          r1    r1    k4 ; k4 = "SetWidgetVisibility"
.line	1536	gettabup      r3    u2    k5 ; k5 = "UEnums"
.line	1536	gettable      r3    r3    k6 ; k6 = "ESlateVisibility"
.line	1536	gettable      r3    r3    k8 ; k8 = "Collapsed"
.line	1536	call          r1     3     1
.label	l23
.line	1536	return        r0     1
.line	1536	move          r0    r0
.line	1536	move          r0    r0
.line	1536	move          r0    r0
.line	1536	move          r0    r0
.line	1536	return        r0     1

.function	main/f61/f1

.source	null
.linedefined	1545
.lastlinedefined	1547
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	1	true

.line	1545	getupval      r0    u0
.line	1545	call          r0     1     1
.line	1545	return        r0     1
.line	1545	move          r0    r0
.line	1545	move          r0    r0
.line	1545	move          r0    r0
.line	1545	return        r0     1

.function	main/f62

.source	null
.linedefined	1550
.lastlinedefined	1553
.numparams	1
.is_vararg	0
.maxstacksize	4

.constant	k0	"ShowOrHideRing"
.constant	k1	"ChangeAvatarForm"

.line	1550	self          r1    r0    k0 ; k0 = "ShowOrHideRing"
.line	1550	loadbool      r3     0     0
.line	1550	call          r1     3     1
.line	1550	self          r1    r0    k1 ; k1 = "ChangeAvatarForm"
.line	1550	call          r1     2     1
.line	1550	return        r0     1
.line	1550	move          r0    r0
.line	1550	move          r0    r0
.line	1550	move          r0    r0
.line	1550	return        r0     1

.function	main/f63

.source	null
.linedefined	1555
.lastlinedefined	1562
.numparams	1
.is_vararg	0
.maxstacksize	30

.upvalue	"_ENV"	14	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"ShowOrHideRing"
.constant	k1	"GetPlayerCharacter"
.constant	k2	"SubsystemMgr"
.constant	k3	"Get"
.constant	k4	2
.constant	k5	71
.constant	k6	203
.constant	k7	119
.constant	k8	181
.constant	k9	211
.constant	k10	10
.constant	k11	94
.constant	k12	180
.constant	k13	194
.constant	k14	109
.constant	k15	47
.constant	k16	212
.constant	k17	182
.constant	k18	98
.constant	k19	213
.constant	k20	224
.constant	k21	116
.constant	k22	184
.constant	k23	64
.constant	k24	93
.constant	k25	226
.constant	k26	77
.constant	k27	99
.constant	k28	168
.constant	k29	"TryTransform"

.line	1555	self          r1    r0    k0 ; k0 = "ShowOrHideRing"
.line	1555	loadbool      r3     0     0
.line	1555	call          r1     3     1
.line	1555	gettabup      r1    u0    k1 ; k1 = "GetPlayerCharacter"
.line	1555	call          r1     1     2
.line	1555	gettabup      r2    u1    k2 ; k2 = "SubsystemMgr"
.line	1555	self          r2    r2    k3 ; k3 = "Get"
.line	1555	getupval      r4    u2
.line	1555	loadk         r5    k4 ; k4 = 2
.line	1555	loadk         r6    k5 ; k5 = 71
.line	1555	loadk         r7    k6 ; k6 = 203
.line	1555	loadk         r8    k7 ; k7 = 119
.line	1555	loadk         r9    k8 ; k8 = 181
.line	1555	loadk        r10    k9 ; k9 = 211
.line	1555	loadk        r11   k10 ; k10 = 10
.line	1555	loadk        r12   k11 ; k11 = 94
.line	1555	loadk        r13   k12 ; k12 = 180
.line	1555	loadk        r14   k13 ; k13 = 194
.line	1555	loadk        r15   k14 ; k14 = 109
.line	1555	loadk        r16   k15 ; k15 = 47
.line	1555	loadk        r17   k16 ; k16 = 212
.line	1555	loadk        r18   k17 ; k17 = 182
.line	1555	loadk        r19   k18 ; k18 = 98
.line	1555	loadk        r20   k19 ; k19 = 213
.line	1555	loadk        r21   k20 ; k20 = 224
.line	1555	loadk        r22   k21 ; k21 = 116
.line	1555	loadk        r23   k22 ; k22 = 184
.line	1555	loadk        r24   k23 ; k23 = 64
.line	1555	loadk        r25   k24 ; k24 = 93
.line	1555	loadk        r26   k25 ; k25 = 226
.line	1555	loadk        r27   k26 ; k26 = 77
.line	1555	loadk        r28   k27 ; k27 = 99
.line	1555	loadk        r29   k28 ; k28 = 168
.line	1555	call          r4    26     2
.line	1555	call          r2     3     2
.line	1555	test          r2     0
.line	1555	jmp            0   l41
.line	1555	self          r3    r2   k29 ; k29 = "TryTransform"
.line	1555	move          r5    r1
.line	1555	call          r3     3     1
.label	l41
.line	1555	return        r0     1
.line	1555	move          r0    r0
.line	1555	move          r0    r0
.line	1555	move          r0    r0
.line	1555	move          r0    r0
.line	1555	return        r0     1

.function	main/f64

.source	null
.linedefined	1564
.lastlinedefined	1574
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"SubsystemMgr"
.constant	k1	"Get"
.constant	k2	10
.constant	k3	95
.constant	k4	205
.constant	k5	98
.constant	k6	185
.constant	k7	196
.constant	k8	26
.constant	k9	83
.constant	k10	202
.constant	k11	99
.constant	k12	47
.constant	k13	193
.constant	k14	172
.constant	k15	114
.constant	k16	203
.constant	k17	174
.constant	k18	86
.constant	k19	73
.constant	k20	"log"
.constant	k21	"bWriteLog"
.constant	k22	"table"
.constant	k23	"concat"
.constant	k24	24
.constant	k25	117
.constant	k26	207
.constant	k27	186
.constant	k28	235
.constant	k29	16
.constant	k30	136
.constant	k31	140
.constant	k32	91
.constant	k33	63
.constant	k34	251
.constant	k35	123
.constant	k36	253
.constant	k37	113
.constant	k38	168
.constant	k39	87
.constant	k40	226
.constant	k41	80
.constant	k42	105
.constant	k43	171
.constant	k44	134
.constant	k45	85
.constant	k46	52
.constant	k47	192
.constant	k48	188
.constant	k49	116
.constant	k50	220
.constant	k51	204
.constant	k52	127
.constant	k53	149
.constant	k54	112
.constant	k55	81
.constant	k56	237
.constant	k57	79
.constant	k58	38
.constant	k59	198
.constant	k60	106
.constant	k61	183
.constant	k62	180
.constant	k63	194
.constant	k64	100
.constant	k65	37
.constant	k66	230
.constant	k67	249
.constant	k68	119
.constant	k69	221
.constant	k70	199
.constant	k71	33
.constant	k72	147
.constant	k73	93
.constant	k74	67
.constant	k75	240
.constant	k76	84
.constant	k77	150
.constant	k78	217
.constant	k79	118
.constant	k80	60
.constant	k81	179
.constant	k82	64
.constant	k83	228
.constant	k84	68
.constant	k85	"Game"
.constant	k86	"SocialIslandEmoteCheck"
.constant	k87	"OnButton_PhotoEditClick"

.line	1564	gettabup      r1    u0    k0 ; k0 = "SubsystemMgr"
.line	1564	self          r1    r1    k1 ; k1 = "Get"
.line	1564	getupval      r3    u1
.line	1564	loadk         r4    k2 ; k2 = 10
.line	1564	loadk         r5    k3 ; k3 = 95
.line	1564	loadk         r6    k4 ; k4 = 205
.line	1564	loadk         r7    k5 ; k5 = 98
.line	1564	loadk         r8    k6 ; k6 = 185
.line	1564	loadk         r9    k7 ; k7 = 196
.line	1564	loadk        r10    k8 ; k8 = 26
.line	1564	loadk        r11    k9 ; k9 = 83
.line	1564	loadk        r12    k6 ; k6 = 185
.line	1564	loadk        r13   k10 ; k10 = 202
.line	1564	loadk        r14   k11 ; k11 = 99
.line	1564	loadk        r15   k12 ; k12 = 47
.line	1564	loadk        r16   k13 ; k13 = 193
.line	1564	loadk        r17   k14 ; k14 = 172
.line	1564	loadk        r18   k15 ; k15 = 114
.line	1564	loadk        r19   k16 ; k16 = 203
.line	1564	loadk        r20   k10 ; k10 = 202
.line	1564	loadk        r21   k15 ; k15 = 114
.line	1564	loadk        r22   k17 ; k17 = 174
.line	1564	loadk        r23   k18 ; k18 = 86
.line	1564	loadk        r24   k19 ; k19 = 73
.line	1564	call          r3    22     2
.line	1564	call          r1     3     2
.line	1564	test          r1     1
.line	1564	jmp            0  l123
.line	1564	gettabup      r2    u0   k20 ; k20 = "log"
.line	1564	gettabup      r3    u0   k21 ; k21 = "bWriteLog"
.line	1564	test          r3     0
.line	1564	jmp            0  l121
.line	1564	gettabup      r3    u0   k22 ; k22 = "table"
.line	1564	gettable      r3    r3   k23 ; k23 = "concat"
.line	1564	newtable      r4     1     0
.line	1564	getupval      r5    u1
.line	1564	loadk         r6   k24 ; k24 = 24
.line	1564	loadk         r7   k25 ; k25 = 117
.line	1564	loadk         r8   k26 ; k26 = 207
.line	1564	loadk         r9    k5 ; k5 = 98
.line	1564	loadk        r10   k27 ; k27 = 186
.line	1564	loadk        r11   k28 ; k28 = 235
.line	1564	loadk        r12   k29 ; k29 = 16
.line	1564	loadk        r13    k5 ; k5 = 98
.line	1564	loadk        r14   k30 ; k30 = 136
.line	1564	loadk        r15   k31 ; k31 = 140
.line	1564	loadk        r16   k32 ; k32 = 91
.line	1564	loadk        r17   k33 ; k33 = 63
.line	1564	loadk        r18   k34 ; k34 = 251
.line	1564	loadk        r19   k27 ; k27 = 186
.line	1564	loadk        r20   k35 ; k35 = 123
.line	1564	loadk        r21   k36 ; k36 = 253
.line	1564	loadk        r22   k16 ; k16 = 203
.line	1564	loadk        r23   k37 ; k37 = 113
.line	1564	loadk        r24   k38 ; k38 = 168
.line	1564	loadk        r25   k18 ; k18 = 86
.line	1564	loadk        r26   k39 ; k39 = 87
.line	1564	loadk        r27   k40 ; k40 = 226
.line	1564	loadk        r28   k41 ; k41 = 80
.line	1564	loadk        r29   k42 ; k42 = 105
.line	1564	loadk        r30   k43 ; k43 = 171
.line	1564	loadk        r31   k44 ; k44 = 134
.line	1564	loadk        r32   k45 ; k45 = 85
.line	1564	loadk        r33   k46 ; k46 = 52
.line	1564	loadk        r34   k47 ; k47 = 192
.line	1564	loadk        r35   k48 ; k48 = 188
.line	1564	loadk        r36   k49 ; k49 = 116
.line	1564	loadk        r37   k50 ; k50 = 220
.line	1564	loadk        r38   k51 ; k51 = 204
.line	1564	loadk        r39   k52 ; k52 = 127
.line	1564	loadk        r40   k53 ; k53 = 149
.line	1564	loadk        r41   k54 ; k54 = 112
.line	1564	loadk        r42   k55 ; k55 = 81
.line	1564	loadk        r43   k56 ; k56 = 237
.line	1564	loadk        r44   k57 ; k57 = 79
.line	1564	loadk        r45   k52 ; k52 = 127
.line	1564	call          r5    41     2
.line	1564	getupval      r6    u1
.line	1564	loadk         r7   k58 ; k58 = 38
.line	1564	loadk         r8   k15 ; k15 = 114
.line	1564	loadk         r9   k59 ; k59 = 198
.line	1564	loadk        r10   k60 ; k60 = 106
.line	1564	loadk        r11   k61 ; k61 = 183
.line	1564	loadk        r12   k10 ; k10 = 202
.line	1564	loadk        r13   k42 ; k42 = 105
.line	1564	loadk        r14   k45 ; k45 = 85
.line	1564	loadk        r15   k62 ; k62 = 180
.line	1564	loadk        r16   k63 ; k63 = 194
.line	1564	loadk        r17   k64 ; k64 = 100
.line	1564	loadk        r18   k65 ; k65 = 37
.line	1564	loadk        r19   k66 ; k66 = 230
.line	1564	loadk        r20   k67 ; k67 = 249
.line	1564	loadk        r21   k68 ; k68 = 119
.line	1564	loadk        r22   k69 ; k69 = 221
.line	1564	loadk        r23   k70 ; k70 = 199
.line	1564	loadk        r24   k71 ; k71 = 33
.line	1564	loadk        r25   k72 ; k72 = 147
.line	1564	loadk        r26   k73 ; k73 = 93
.line	1564	loadk        r27   k74 ; k74 = 67
.line	1564	loadk        r28   k75 ; k75 = 240
.line	1564	loadk        r29   k76 ; k76 = 84
.line	1564	loadk        r30   k11 ; k11 = 99
.line	1564	loadk        r31   k77 ; k77 = 150
.line	1564	loadk        r32   k78 ; k78 = 217
.line	1564	loadk        r33   k79 ; k79 = 118
.line	1564	loadk        r34   k80 ; k80 = 60
.line	1564	loadk        r35   k28 ; k28 = 235
.line	1564	loadk        r36   k14 ; k14 = 172
.line	1564	loadk        r37    k9 ; k9 = 83
.line	1564	loadk        r38   k69 ; k69 = 221
.line	1564	loadk        r39   k13 ; k13 = 193
.line	1564	loadk        r40    k5 ; k5 = 98
.line	1564	loadk        r41   k81 ; k81 = 179
.line	1564	loadk        r42   k41 ; k41 = 80
.line	1564	loadk        r43   k82 ; k82 = 64
.line	1564	loadk        r44   k83 ; k83 = 228
.line	1564	loadk        r45   k84 ; k84 = 68
.line	1564	call          r6    40     0
.line	1564	setlist       r4     0     1
.line	1564	call          r3     2     2
.label	l121
.line	1564	call          r2     2     1
.line	1564	return        r0     1
.label	l123
.line	1564	gettabup      r2    u0   k85 ; k85 = "Game"
.line	1564	self          r2    r2   k86 ; k86 = "SocialIslandEmoteChe" (truncated)
.line	1564	call          r2     2     2
.line	1564	test          r2     1
.line	1564	jmp            0  l129
.line	1564	return        r0     1
.label	l129
.line	1564	self          r2    r1   k87 ; k87 = "OnButton_PhotoEditCl" (truncated)
.line	1564	call          r2     2     1
.line	1564	return        r0     1
.line	1564	move          r0    r0
.line	1564	return        r0     1

.function	main/f65

.source	null
.linedefined	1576
.lastlinedefined	1590
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"SubsystemMgr"
.constant	k1	"Get"
.constant	k2	19
.constant	k3	89
.constant	k4	197
.constant	k5	119
.constant	k6	187
.constant	k7	230
.constant	k8	59
.constant	k9	87
.constant	k10	165
.constant	k11	196
.constant	k12	111
.constant	k13	56
.constant	k14	193
.constant	k15	172
.constant	k16	114
.constant	k17	235
.constant	k18	202
.constant	k19	174
.constant	k20	86
.constant	k21	73
.constant	k22	"log"
.constant	k23	"bWriteLog"
.constant	k24	"table"
.constant	k25	"concat"
.constant	k26	24
.constant	k27	121
.constant	k28	240
.constant	k29	66
.constant	k30	137
.constant	k31	129
.constant	k32	67
.constant	k33	188
.constant	k34	207
.constant	k35	97
.constant	k36	15
.constant	k37	234
.constant	k38	169
.constant	k39	98
.constant	k40	221
.constant	k41	192
.constant	k42	179
.constant	k43	92
.constant	k44	74
.constant	k45	171
.constant	k46	118
.constant	k47	104
.constant	k48	135
.constant	k49	201
.constant	k50	110
.constant	k51	46
.constant	k52	237
.constant	k53	167
.constant	k54	80
.constant	k55	205
.constant	k56	215
.constant	k57	175
.constant	k58	64
.constant	k59	244
.constant	k60	91
.constant	k61	115
.constant	k62	99
.constant	k63	82
.constant	k64	203
.constant	k65	109
.constant	k66	186
.constant	k67	206
.constant	k68	61
.constant	k69	22
.constant	k70	178
.constant	k71	126
.constant	k72	106
.constant	k73	194
.constant	k74	177
.constant	k75	127
.constant	k76	204
.constant	k77	220
.constant	k78	70
.constant	k79	168
.constant	k80	84
.constant	k81	249
.constant	k82	116
.constant	k83	150
.constant	k84	120
.constant	k85	9
.constant	k86	251
.constant	k87	"CheckIsInVehicle"
.constant	k88	"ShowNotice"
.constant	k89	49084
.constant	k90	"PlayPetFeature"
.constant	k91	"ShowOrHideRing"

.line	1576	gettabup      r1    u0    k0 ; k0 = "SubsystemMgr"
.line	1576	self          r1    r1    k1 ; k1 = "Get"
.line	1576	getupval      r3    u1
.line	1576	loadk         r4    k2 ; k2 = 19
.line	1576	loadk         r5    k3 ; k3 = 89
.line	1576	loadk         r6    k4 ; k4 = 197
.line	1576	loadk         r7    k5 ; k5 = 119
.line	1576	loadk         r8    k6 ; k6 = 187
.line	1576	loadk         r9    k7 ; k7 = 230
.line	1576	loadk        r10    k8 ; k8 = 59
.line	1576	loadk        r11    k9 ; k9 = 87
.line	1576	loadk        r12   k10 ; k10 = 165
.line	1576	loadk        r13   k11 ; k11 = 196
.line	1576	loadk        r14   k12 ; k12 = 111
.line	1576	loadk        r15   k13 ; k13 = 56
.line	1576	loadk        r16   k14 ; k14 = 193
.line	1576	loadk        r17   k15 ; k15 = 172
.line	1576	loadk        r18   k16 ; k16 = 114
.line	1576	loadk        r19   k17 ; k17 = 235
.line	1576	loadk        r20   k18 ; k18 = 202
.line	1576	loadk        r21   k16 ; k16 = 114
.line	1576	loadk        r22   k19 ; k19 = 174
.line	1576	loadk        r23   k20 ; k20 = 86
.line	1576	loadk        r24   k21 ; k21 = 73
.line	1576	call          r3    22     2
.line	1576	call          r1     3     2
.line	1576	test          r1     1
.line	1576	jmp            0  l117
.line	1576	gettabup      r2    u0   k22 ; k22 = "log"
.line	1576	gettabup      r3    u0   k23 ; k23 = "bWriteLog"
.line	1576	test          r3     0
.line	1576	jmp            0  l115
.line	1576	gettabup      r3    u0   k24 ; k24 = "table"
.line	1576	gettable      r3    r3   k25 ; k25 = "concat"
.line	1576	newtable      r4     1     0
.line	1576	getupval      r5    u1
.line	1576	loadk         r6   k26 ; k26 = 24
.line	1576	loadk         r7   k27 ; k27 = 121
.line	1576	loadk         r8   k28 ; k28 = 240
.line	1576	loadk         r9   k29 ; k29 = 66
.line	1576	loadk        r10   k30 ; k30 = 137
.line	1576	loadk        r11   k31 ; k31 = 129
.line	1576	loadk        r12   k26 ; k26 = 24
.line	1576	loadk        r13   k32 ; k32 = 67
.line	1576	loadk        r14   k33 ; k33 = 188
.line	1576	loadk        r15   k34 ; k34 = 207
.line	1576	loadk        r16   k35 ; k35 = 97
.line	1576	loadk        r17   k36 ; k36 = 15
.line	1576	loadk        r18   k37 ; k37 = 234
.line	1576	loadk        r19   k38 ; k38 = 169
.line	1576	loadk        r20   k39 ; k39 = 98
.line	1576	loadk        r21   k40 ; k40 = 221
.line	1576	loadk        r22   k41 ; k41 = 192
.line	1576	loadk        r23   k16 ; k16 = 114
.line	1576	loadk        r24   k42 ; k42 = 179
.line	1576	loadk        r25   k43 ; k43 = 92
.line	1576	loadk        r26   k44 ; k44 = 74
.line	1576	loadk        r27   k45 ; k45 = 171
.line	1576	loadk        r28   k46 ; k46 = 118
.line	1576	loadk        r29   k47 ; k47 = 104
.line	1576	loadk        r30   k48 ; k48 = 135
.line	1576	loadk        r31   k49 ; k49 = 201
.line	1576	loadk        r32   k50 ; k50 = 110
.line	1576	loadk        r33   k51 ; k51 = 46
.line	1576	loadk        r34   k52 ; k52 = 237
.line	1576	loadk        r35   k53 ; k53 = 167
.line	1576	loadk        r36   k54 ; k54 = 80
.line	1576	loadk        r37   k55 ; k55 = 205
.line	1576	loadk        r38   k56 ; k56 = 215
.line	1576	loadk        r39    k9 ; k9 = 87
.line	1576	loadk        r40   k57 ; k57 = 175
.line	1576	loadk        r41   k29 ; k29 = 66
.line	1576	loadk        r42   k58 ; k58 = 64
.line	1576	loadk        r43   k59 ; k59 = 244
.line	1576	loadk        r44   k60 ; k60 = 91
.line	1576	loadk        r45   k61 ; k61 = 115
.line	1576	call          r5    41     2
.line	1576	getupval      r6    u1
.line	1576	loadk         r7   k62 ; k62 = 99
.line	1576	loadk         r8   k63 ; k63 = 82
.line	1576	loadk         r9   k64 ; k64 = 203
.line	1576	loadk        r10   k65 ; k65 = 109
.line	1576	loadk        r11   k66 ; k66 = 186
.line	1576	loadk        r12   k67 ; k67 = 206
.line	1576	loadk        r13   k68 ; k68 = 61
.line	1576	loadk        r14   k69 ; k69 = 22
.line	1576	loadk        r15   k70 ; k70 = 178
.line	1576	loadk        r16   k49 ; k49 = 201
.line	1576	loadk        r17   k71 ; k71 = 126
.line	1576	loadk        r18   k72 ; k72 = 106
.line	1576	loadk        r19   k73 ; k73 = 194
.line	1576	loadk        r20   k74 ; k74 = 177
.line	1576	loadk        r21   k75 ; k75 = 127
.line	1576	loadk        r22   k76 ; k76 = 204
.line	1576	loadk        r23   k77 ; k77 = 220
.line	1576	loadk        r24   k78 ; k78 = 70
.line	1576	loadk        r25   k79 ; k79 = 168
.line	1576	loadk        r26   k63 ; k63 = 82
.line	1576	loadk        r27   k80 ; k80 = 84
.line	1576	loadk        r28   k81 ; k81 = 249
.line	1576	loadk        r29   k43 ; k43 = 92
.line	1576	loadk        r30   k82 ; k82 = 116
.line	1576	loadk        r31   k83 ; k83 = 150
.line	1576	loadk        r32   k49 ; k49 = 201
.line	1576	loadk        r33   k84 ; k84 = 120
.line	1576	loadk        r34   k85 ; k85 = 9
.line	1576	loadk        r35   k86 ; k86 = 251
.line	1576	loadk        r36   k66 ; k66 = 186
.line	1576	loadk        r37   k82 ; k82 = 116
.line	1576	loadk        r38   k55 ; k55 = 205
.line	1576	loadk        r39   k67 ; k67 = 206
.line	1576	call          r6    34     0
.line	1576	setlist       r4     0     1
.line	1576	call          r3     2     2
.label	l115
.line	1576	call          r2     2     1
.line	1576	return        r0     1
.label	l117
.line	1576	self          r2    r1   k87 ; k87 = "CheckIsInVehicle"
.line	1576	call          r2     2     2
.line	1576	test          r2     0
.line	1576	jmp            0  l125
.line	1576	gettabup      r2    u0   k88 ; k88 = "ShowNotice"
.line	1576	loadk         r3   k89 ; k89 = 49084
.line	1576	call          r2     2     1
.line	1576	return        r0     1
.label	l125
.line	1576	self          r2    r1   k90 ; k90 = "PlayPetFeature"
.line	1576	call          r2     2     1
.line	1576	gettable      r2    r0   k91 ; k91 = "ShowOrHideRing"
.line	1576	test          r2     0
.line	1576	jmp            0  l133
.line	1576	self          r2    r0   k91 ; k91 = "ShowOrHideRing"
.line	1576	loadbool      r4     0     0
.line	1576	call          r2     3     1
.label	l133
.line	1576	return        r0     1
.line	1576	move          r0    r0
.line	1576	gettabup      r0    u1   k53 ; k53 = 167
.line	1576	return        r0     1

.function	main/f66

.source	null
.linedefined	1592
.lastlinedefined	1637
.numparams	2
.is_vararg	0
.maxstacksize	59

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	14	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	18
.constant	k3	68
.constant	k4	195
.constant	k5	96
.constant	k6	191
.constant	k7	228
.constant	k8	49
.constant	k9	70
.constant	k10	167
.constant	k11	201
.constant	k12	121
.constant	k13	57
.constant	k14	251
.constant	k15	182
.constant	k16	126
.constant	k17	130
.constant	k18	240
.constant	k19	180
.constant	k20	76
.constant	k21	254
.constant	k22	78
.constant	k23	94
.constant	k24	150
.constant	k25	115
.constant	k26	46
.constant	k27	199
.constant	k28	164
.constant	k29	111
.constant	k30	220
.constant	k31	198
.constant	k32	"IsSocialIsland"
.constant	k33	"IsBornisland"
.constant	k34	"IsMainCity"
.constant	k35	"table"
.constant	k36	"concat"
.constant	k37	64
.constant	k38	161
.constant	k39	101
.constant	k40	16
.constant	k41	106
.constant	k42	181
.constant	k43	205
.constant	k44	0
.constant	k45	69
.constant	k46	185
.constant	k47	100
.constant	k48	178
.constant	k49	98
.constant	k50	152
.constant	k51	250
.constant	k52	114
.constant	k53	92
.constant	k54	86
.constant	k55	255
.constant	k56	80
.constant	k57	117
.constant	k58	169
.constant	k59	221
.constant	k60	116
.constant	k61	62
.constant	k62	"GetPlayerCharacter"
.constant	k63	"slua"
.constant	k64	"isValid"
.constant	k65	102
.constant	k66	97
.constant	k67	45
.constant	k68	88
.constant	k69	196
.constant	k70	149
.constant	k71	194
.constant	k72	61
.constant	k73	89
.constant	k74	"getAvatarComponent2"
.constant	k75	87
.constant	k76	53
.constant	k77	222
.constant	k78	166
.constant	k79	226
.constant	k80	38
.constant	k81	91
.constant	k82	165
.constant	k83	158
.constant	k84	"slua_GameFrontendHUD"
.constant	k85	"GetPlayerController"
.constant	k86	"CommerFeature"
.constant	k87	47
.constant	k88	211
.constant	k89	188
.constant	k90	"import"
.constant	k91	6
.constant	k92	112
.constant	k93	160
.constant	k94	192
.constant	k95	59
.constant	k96	30
.constant	k97	235
.constant	k98	"GetEquippedItemDefineID"
.constant	k99	"EAvatarSlotType_ClothesEquipemtSlot"
.constant	k100	"require"
.constant	k101	4
.constant	k102	212
.constant	k103	40
.constant	k104	24
.constant	k105	148
.constant	k106	207
.constant	k107	35
.constant	k108	176
.constant	k109	193
.constant	k110	157
.constant	k111	66
.constant	k112	73
.constant	k113	244
.constant	k114	75
.constant	k115	172
.constant	k116	118
.constant	k117	51
.constant	k118	248
.constant	k119	239
.constant	k120	124
.constant	k121	175
.constant	k122	224
.constant	k123	56
.constant	k124	27
.constant	k125	223
.constant	k126	143
.constant	k127	17
.constant	k128	197
.constant	k129	31
.constant	k130	230
.constant	k131	32
.constant	k132	93
.constant	k133	186
.constant	k134	213
.constant	k135	103
.constant	k136	217
.constant	k137	107
.constant	k138	119
.constant	k139	209
.constant	k140	208
.constant	k141	190
.constant	k142	83
.constant	k143	85
.constant	k144	105
.constant	k145	216
.constant	k146	52
.constant	k147	42
.constant	k148	247
.constant	k149	63
.constant	k150	82
.constant	k151	231
.constant	k152	28
.constant	k153	203
.constant	k154	109
.constant	k155	44
.constant	k156	90
.constant	k157	242
.constant	k158	"GetState"
.constant	k159	"ENUM_DownloadType"
.constant	k160	"ODPAK"
.constant	k161	"TypeSpecificID"
.constant	k162	"log"
.constant	k163	234
.constant	k164	71
.constant	k165	246
.constant	k166	34
.constant	k167	249
.constant	k168	12
.constant	k169	245
.constant	k170	"tostring"
.constant	k171	"ENUM_DownloadState"
.constant	k172	"Done"
.constant	k173	77
.constant	k174	95
.constant	k175	108
.constant	k176	"GetPeriodByItemId"
.constant	k177	5
.constant	k178	162
.constant	k179	60
.constant	k180	"GetUnLockLevelByFeature"
.constant	k181	"XSuitUnlockLevelList"
.constant	k182	"IsValidXSuitEffect"
.constant	k183	"BornIslandAction"
.constant	k184	168
.constant	k185	237
.constant	k186	99
.constant	k187	177
.constant	k188	241
.constant	k189	144
.constant	k190	84
.constant	k191	133
.constant	k192	113
.constant	k193	189
.constant	k194	206
.constant	k195	11
.constant	k196	79
.constant	k197	187
.constant	k198	122
.constant	k199	218
.constant	k200	"GetBornIslandActionByItemID"
.constant	k201	136
.constant	k202	48

.line	1592	gettabup      r2    u0    k0 ; k0 = "print"
.line	1592	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1592	test          r3     0
.line	1592	jmp            0   l40
.line	1592	getupval      r3    u1
.line	1592	loadk         r4    k2 ; k2 = 18
.line	1592	loadk         r5    k3 ; k3 = 68
.line	1592	loadk         r6    k4 ; k4 = 195
.line	1592	loadk         r7    k5 ; k5 = 96
.line	1592	loadk         r8    k6 ; k6 = 191
.line	1592	loadk         r9    k7 ; k7 = 228
.line	1592	loadk        r10    k8 ; k8 = 49
.line	1592	loadk        r11    k9 ; k9 = 70
.line	1592	loadk        r12   k10 ; k10 = 167
.line	1592	loadk        r13   k11 ; k11 = 201
.line	1592	loadk        r14   k12 ; k12 = 121
.line	1592	loadk        r15   k13 ; k13 = 57
.line	1592	loadk        r16   k14 ; k14 = 251
.line	1592	loadk        r17   k15 ; k15 = 182
.line	1592	loadk        r18   k16 ; k16 = 126
.line	1592	loadk        r19   k17 ; k17 = 130
.line	1592	loadk        r20   k18 ; k18 = 240
.line	1592	loadk        r21    k5 ; k5 = 96
.line	1592	loadk        r22   k19 ; k19 = 180
.line	1592	loadk        r23    k5 ; k5 = 96
.line	1592	loadk        r24   k20 ; k20 = 76
.line	1592	loadk        r25   k21 ; k21 = 254
.line	1592	loadk        r26   k22 ; k22 = 78
.line	1592	loadk        r27   k23 ; k23 = 94
.line	1592	loadk        r28   k24 ; k24 = 150
.line	1592	loadk        r29   k11 ; k11 = 201
.line	1592	loadk        r30   k25 ; k25 = 115
.line	1592	loadk        r31   k26 ; k26 = 46
.line	1592	loadk        r32   k27 ; k27 = 199
.line	1592	loadk        r33   k28 ; k28 = 164
.line	1592	loadk        r34   k29 ; k29 = 111
.line	1592	loadk        r35   k30 ; k30 = 220
.line	1592	loadk        r36   k31 ; k31 = 198
.line	1592	call          r3    34     2
.label	l40
.line	1592	call          r2     2     1
.line	1592	gettable      r2    r0   k32 ; k32 = "IsSocialIsland"
.line	1592	test          r2     0
.line	1592	jmp            0   l48
.line	1592	self          r2    r0   k32 ; k32 = "IsSocialIsland"
.line	1592	call          r2     2     2
.line	1592	test          r2     1
.line	1592	jmp            0  l164
.label	l48
.line	1592	test          r1     0
.line	1592	jmp            0   l54
.line	1592	self          r2    r1   k32 ; k32 = "IsSocialIsland"
.line	1592	call          r2     2     2
.line	1592	test          r2     1
.line	1592	jmp            0  l164
.label	l54
.line	1592	gettable      r2    r0   k33 ; k33 = "IsBornisland"
.line	1592	test          r2     0
.line	1592	jmp            0   l61
.line	1592	self          r2    r0   k33 ; k33 = "IsBornisland"
.line	1592	call          r2     2     2
.line	1592	test          r2     1
.line	1592	jmp            0  l164
.label	l61
.line	1592	test          r1     0
.line	1592	jmp            0   l67
.line	1592	self          r2    r1   k33 ; k33 = "IsBornisland"
.line	1592	call          r2     2     2
.line	1592	test          r2     1
.line	1592	jmp            0  l164
.label	l67
.line	1592	gettable      r2    r0   k34 ; k34 = "IsMainCity"
.line	1592	test          r2     0
.line	1592	jmp            0   l74
.line	1592	self          r2    r0   k34 ; k34 = "IsMainCity"
.line	1592	call          r2     2     2
.line	1592	test          r2     1
.line	1592	jmp            0  l164
.label	l74
.line	1592	test          r1     0
.line	1592	jmp            0   l80
.line	1592	self          r2    r1   k34 ; k34 = "IsMainCity"
.line	1592	call          r2     2     2
.line	1592	test          r2     1
.line	1592	jmp            0  l164
.label	l80
.line	1592	gettabup      r2    u0    k0 ; k0 = "print"
.line	1592	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1592	test          r3     0
.line	1592	jmp            0  l161
.line	1592	gettabup      r3    u0   k35 ; k35 = "table"
.line	1592	gettable      r3    r3   k36 ; k36 = "concat"
.line	1592	newtable      r4     1     0
.line	1592	getupval      r5    u1
.line	1592	loadk         r6    k2 ; k2 = 18
.line	1592	loadk         r7    k3 ; k3 = 68
.line	1592	loadk         r8    k4 ; k4 = 195
.line	1592	loadk         r9    k5 ; k5 = 96
.line	1592	loadk        r10    k6 ; k6 = 191
.line	1592	loadk        r11    k7 ; k7 = 228
.line	1592	loadk        r12    k8 ; k8 = 49
.line	1592	loadk        r13    k9 ; k9 = 70
.line	1592	loadk        r14   k10 ; k10 = 167
.line	1592	loadk        r15   k11 ; k11 = 201
.line	1592	loadk        r16   k12 ; k12 = 121
.line	1592	loadk        r17   k13 ; k13 = 57
.line	1592	loadk        r18   k14 ; k14 = 251
.line	1592	loadk        r19   k15 ; k15 = 182
.line	1592	loadk        r20   k16 ; k16 = 126
.line	1592	loadk        r21   k17 ; k17 = 130
.line	1592	loadk        r22   k18 ; k18 = 240
.line	1592	loadk        r23    k5 ; k5 = 96
.line	1592	loadk        r24   k19 ; k19 = 180
.line	1592	loadk        r25    k5 ; k5 = 96
.line	1592	loadk        r26   k20 ; k20 = 76
.line	1592	loadk        r27   k21 ; k21 = 254
.line	1592	loadk        r28   k22 ; k22 = 78
.line	1592	loadk        r29   k23 ; k23 = 94
.line	1592	loadk        r30   k24 ; k24 = 150
.line	1592	loadk        r31   k11 ; k11 = 201
.line	1592	loadk        r32   k25 ; k25 = 115
.line	1592	loadk        r33   k26 ; k26 = 46
.line	1592	loadk        r34   k27 ; k27 = 199
.line	1592	loadk        r35   k28 ; k28 = 164
.line	1592	loadk        r36   k29 ; k29 = 111
.line	1592	loadk        r37   k30 ; k30 = 220
.line	1592	loadk        r38   k31 ; k31 = 198
.line	1592	loadk        r39    k8 ; k8 = 49
.line	1592	loadk        r40   k28 ; k28 = 164
.line	1592	loadk        r41   k20 ; k20 = 76
.line	1592	loadk        r42   k37 ; k37 = 64
.line	1592	loadk        r43   k38 ; k38 = 161
.line	1592	loadk        r44    k5 ; k5 = 96
.line	1592	loadk        r45   k39 ; k39 = 101
.line	1592	call          r5    41     2
.line	1592	getupval      r6    u1
.line	1592	loadk         r7   k40 ; k40 = 16
.line	1592	loadk         r8   k23 ; k23 = 94
.line	1592	loadk         r9   k11 ; k11 = 201
.line	1592	loadk        r10   k41 ; k41 = 106
.line	1592	loadk        r11   k42 ; k42 = 181
.line	1592	loadk        r12   k43 ; k43 = 205
.line	1592	loadk        r13   k44 ; k44 = 0
.line	1592	loadk        r14   k45 ; k45 = 69
.line	1592	loadk        r15   k46 ; k46 = 185
.line	1592	loadk        r16   k43 ; k43 = 205
.line	1592	loadk        r17   k47 ; k47 = 100
.line	1592	loadk        r18   k26 ; k26 = 46
.line	1592	loadk        r19   k48 ; k48 = 178
.line	1592	loadk        r20   k15 ; k15 = 182
.line	1592	loadk        r21   k49 ; k49 = 98
.line	1592	loadk        r22   k50 ; k50 = 152
.line	1592	loadk        r23   k51 ; k51 = 250
.line	1592	loadk        r24   k52 ; k52 = 114
.line	1592	loadk        r25   k50 ; k50 = 152
.line	1592	loadk        r26   k53 ; k53 = 92
.line	1592	loadk        r27   k54 ; k54 = 86
.line	1592	loadk        r28   k55 ; k55 = 255
.line	1592	loadk        r29   k56 ; k56 = 80
.line	1592	loadk        r30   k57 ; k57 = 117
.line	1592	loadk        r31   k58 ; k58 = 169
.line	1592	loadk        r32   k59 ; k59 = 221
.line	1592	loadk        r33   k60 ; k60 = 116
.line	1592	loadk        r34   k61 ; k61 = 62
.line	1592	call          r6    29     0
.line	1592	setlist       r4     0     1
.line	1592	call          r3     2     2
.label	l161
.line	1592	call          r2     2     1
.line	1592	loadbool      r2     0     0
.line	1592	return        r2     2
.label	l164
.line	1592	gettabup      r2    u2   k62 ; k62 = "GetPlayerCharacter"
.line	1592	call          r2     1     2
.line	1592	test          r2     0
.line	1592	jmp            0  l174
.line	1592	gettabup      r3    u0   k63 ; k63 = "slua"
.line	1592	gettable      r3    r3   k64 ; k64 = "isValid"
.line	1592	move          r4    r2
.line	1592	call          r3     2     2
.line	1592	test          r3     1
.line	1592	jmp            0  l239
.label	l174
.line	1592	gettabup      r3    u0    k0 ; k0 = "print"
.line	1592	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	1592	test          r4     0
.line	1592	jmp            0  l236
.line	1592	gettabup      r4    u0   k35 ; k35 = "table"
.line	1592	gettable      r4    r4   k36 ; k36 = "concat"
.line	1592	newtable      r5     1     0
.line	1592	getupval      r6    u1
.line	1592	loadk         r7    k2 ; k2 = 18
.line	1592	loadk         r8    k3 ; k3 = 68
.line	1592	loadk         r9    k4 ; k4 = 195
.line	1592	loadk        r10    k5 ; k5 = 96
.line	1592	loadk        r11    k6 ; k6 = 191
.line	1592	loadk        r12    k7 ; k7 = 228
.line	1592	loadk        r13    k8 ; k8 = 49
.line	1592	loadk        r14    k9 ; k9 = 70
.line	1592	loadk        r15   k10 ; k10 = 167
.line	1592	loadk        r16   k11 ; k11 = 201
.line	1592	loadk        r17   k12 ; k12 = 121
.line	1592	loadk        r18   k13 ; k13 = 57
.line	1592	loadk        r19   k14 ; k14 = 251
.line	1592	loadk        r20   k15 ; k15 = 182
.line	1592	loadk        r21   k16 ; k16 = 126
.line	1592	loadk        r22   k17 ; k17 = 130
.line	1592	loadk        r23   k18 ; k18 = 240
.line	1592	loadk        r24    k5 ; k5 = 96
.line	1592	loadk        r25   k19 ; k19 = 180
.line	1592	loadk        r26    k5 ; k5 = 96
.line	1592	loadk        r27   k20 ; k20 = 76
.line	1592	loadk        r28   k21 ; k21 = 254
.line	1592	loadk        r29   k22 ; k22 = 78
.line	1592	loadk        r30   k23 ; k23 = 94
.line	1592	loadk        r31   k24 ; k24 = 150
.line	1592	loadk        r32   k11 ; k11 = 201
.line	1592	loadk        r33   k25 ; k25 = 115
.line	1592	loadk        r34   k26 ; k26 = 46
.line	1592	loadk        r35   k27 ; k27 = 199
.line	1592	loadk        r36   k28 ; k28 = 164
.line	1592	loadk        r37   k29 ; k29 = 111
.line	1592	loadk        r38   k30 ; k30 = 220
.line	1592	loadk        r39   k31 ; k31 = 198
.line	1592	loadk        r40    k8 ; k8 = 49
.line	1592	loadk        r41   k28 ; k28 = 164
.line	1592	loadk        r42   k20 ; k20 = 76
.line	1592	loadk        r43   k37 ; k37 = 64
.line	1592	loadk        r44   k38 ; k38 = 161
.line	1592	loadk        r45   k65 ; k65 = 102
.line	1592	loadk        r46   k66 ; k66 = 97
.line	1592	call          r6    41     2
.line	1592	getupval      r7    u1
.line	1592	loadk         r8   k67 ; k67 = 45
.line	1592	loadk         r9   k68 ; k68 = 88
.line	1592	loadk        r10   k69 ; k69 = 196
.line	1592	loadk        r11   k47 ; k47 = 100
.line	1592	loadk        r12   k70 ; k70 = 149
.line	1592	loadk        r13   k71 ; k71 = 194
.line	1592	loadk        r14   k72 ; k72 = 61
.line	1592	loadk        r15   k73 ; k73 = 89
.line	1592	loadk        r16   k10 ; k10 = 167
.line	1592	call          r7    10     0
.line	1592	setlist       r5     0     1
.line	1592	call          r4     2     2
.label	l236
.line	1592	call          r3     2     1
.line	1592	loadbool      r3     0     0
.line	1592	return        r3     2
.label	l239
.line	1592	self          r3    r2   k74 ; k74 = "getAvatarComponent2"
.line	1592	call          r3     2     2
.line	1592	gettabup      r4    u0   k63 ; k63 = "slua"
.line	1592	gettable      r4    r4   k64 ; k64 = "isValid"
.line	1592	move          r5    r3
.line	1592	call          r4     2     2
.line	1592	test          r4     1
.line	1592	jmp            0  l313
.line	1592	gettabup      r4    u0    k0 ; k0 = "print"
.line	1592	gettabup      r5    u0    k1 ; k1 = "bWriteLog"
.line	1592	test          r5     0
.line	1592	jmp            0  l310
.line	1592	gettabup      r5    u0   k35 ; k35 = "table"
.line	1592	gettable      r5    r5   k36 ; k36 = "concat"
.line	1592	newtable      r6     1     0
.line	1592	getupval      r7    u1
.line	1592	loadk         r8    k2 ; k2 = 18
.line	1592	loadk         r9    k3 ; k3 = 68
.line	1592	loadk        r10    k4 ; k4 = 195
.line	1592	loadk        r11    k5 ; k5 = 96
.line	1592	loadk        r12    k6 ; k6 = 191
.line	1592	loadk        r13    k7 ; k7 = 228
.line	1592	loadk        r14    k8 ; k8 = 49
.line	1592	loadk        r15    k9 ; k9 = 70
.line	1592	loadk        r16   k10 ; k10 = 167
.line	1592	loadk        r17   k11 ; k11 = 201
.line	1592	loadk        r18   k12 ; k12 = 121
.line	1592	loadk        r19   k13 ; k13 = 57
.line	1592	loadk        r20   k14 ; k14 = 251
.line	1592	loadk        r21   k15 ; k15 = 182
.line	1592	loadk        r22   k16 ; k16 = 126
.line	1592	loadk        r23   k17 ; k17 = 130
.line	1592	loadk        r24   k18 ; k18 = 240
.line	1592	loadk        r25    k5 ; k5 = 96
.line	1592	loadk        r26   k19 ; k19 = 180
.line	1592	loadk        r27    k5 ; k5 = 96
.line	1592	loadk        r28   k20 ; k20 = 76
.line	1592	loadk        r29   k21 ; k21 = 254
.line	1592	loadk        r30   k22 ; k22 = 78
.line	1592	loadk        r31   k23 ; k23 = 94
.line	1592	loadk        r32   k24 ; k24 = 150
.line	1592	loadk        r33   k11 ; k11 = 201
.line	1592	loadk        r34   k25 ; k25 = 115
.line	1592	loadk        r35   k26 ; k26 = 46
.line	1592	loadk        r36   k27 ; k27 = 199
.line	1592	loadk        r37   k28 ; k28 = 164
.line	1592	loadk        r38   k29 ; k29 = 111
.line	1592	loadk        r39   k30 ; k30 = 220
.line	1592	loadk        r40   k31 ; k31 = 198
.line	1592	loadk        r41    k8 ; k8 = 49
.line	1592	loadk        r42   k28 ; k28 = 164
.line	1592	loadk        r43   k20 ; k20 = 76
.line	1592	loadk        r44   k37 ; k37 = 64
.line	1592	loadk        r45   k38 ; k38 = 161
.line	1592	loadk        r46   k53 ; k53 = 92
.line	1592	loadk        r47   k75 ; k75 = 87
.line	1592	call          r7    41     2
.line	1592	getupval      r8    u1
.line	1592	loadk         r9   k76 ; k76 = 53
.line	1592	loadk        r10   k56 ; k56 = 80
.line	1592	loadk        r11   k77 ; k77 = 222
.line	1592	loadk        r12   k49 ; k49 = 98
.line	1592	loadk        r13   k78 ; k78 = 166
.line	1592	loadk        r14   k79 ; k79 = 226
.line	1592	loadk        r15   k80 ; k80 = 38
.line	1592	loadk        r16   k81 ; k81 = 91
.line	1592	loadk        r17   k82 ; k82 = 165
.line	1592	loadk        r18   k83 ; k83 = 158
.line	1592	call          r8    11     0
.line	1592	setlist       r6     0     1
.line	1592	call          r5     2     2
.label	l310
.line	1592	call          r4     2     1
.line	1592	loadbool      r4     0     0
.line	1592	return        r4     2
.label	l313
.line	1592	gettabup      r4    u0   k84 ; k84 = "slua_GameFrontendHUD"
.line	1592	self          r4    r4   k85 ; k85 = "GetPlayerController"
.line	1592	call          r4     2     2
.line	1592	gettabup      r5    u0   k63 ; k63 = "slua"
.line	1592	gettable      r5    r5   k64 ; k64 = "isValid"
.line	1592	move          r6    r4
.line	1592	call          r5     2     2
.line	1592	test          r5     0
.line	1592	jmp            0  l325
.line	1592	gettable      r5    r4   k86 ; k86 = "CommerFeature"
.line	1592	test          r5     1
.line	1592	jmp            0  l396
.label	l325
.line	1592	gettabup      r5    u0    k0 ; k0 = "print"
.line	1592	gettabup      r6    u0    k1 ; k1 = "bWriteLog"
.line	1592	test          r6     0
.line	1592	jmp            0  l393
.line	1592	gettabup      r6    u0   k35 ; k35 = "table"
.line	1592	gettable      r6    r6   k36 ; k36 = "concat"
.line	1592	newtable      r7     1     0
.line	1592	getupval      r8    u1
.line	1592	loadk         r9    k2 ; k2 = 18
.line	1592	loadk        r10    k3 ; k3 = 68
.line	1592	loadk        r11    k4 ; k4 = 195
.line	1592	loadk        r12    k5 ; k5 = 96
.line	1592	loadk        r13    k6 ; k6 = 191
.line	1592	loadk        r14    k7 ; k7 = 228
.line	1592	loadk        r15    k8 ; k8 = 49
.line	1592	loadk        r16    k9 ; k9 = 70
.line	1592	loadk        r17   k10 ; k10 = 167
.line	1592	loadk        r18   k11 ; k11 = 201
.line	1592	loadk        r19   k12 ; k12 = 121
.line	1592	loadk        r20   k13 ; k13 = 57
.line	1592	loadk        r21   k14 ; k14 = 251
.line	1592	loadk        r22   k15 ; k15 = 182
.line	1592	loadk        r23   k16 ; k16 = 126
.line	1592	loadk        r24   k17 ; k17 = 130
.line	1592	loadk        r25   k18 ; k18 = 240
.line	1592	loadk        r26    k5 ; k5 = 96
.line	1592	loadk        r27   k19 ; k19 = 180
.line	1592	loadk        r28    k5 ; k5 = 96
.line	1592	loadk        r29   k20 ; k20 = 76
.line	1592	loadk        r30   k21 ; k21 = 254
.line	1592	loadk        r31   k22 ; k22 = 78
.line	1592	loadk        r32   k23 ; k23 = 94
.line	1592	loadk        r33   k24 ; k24 = 150
.line	1592	loadk        r34   k11 ; k11 = 201
.line	1592	loadk        r35   k25 ; k25 = 115
.line	1592	loadk        r36   k26 ; k26 = 46
.line	1592	loadk        r37   k27 ; k27 = 199
.line	1592	loadk        r38   k28 ; k28 = 164
.line	1592	loadk        r39   k29 ; k29 = 111
.line	1592	loadk        r40   k30 ; k30 = 220
.line	1592	loadk        r41   k31 ; k31 = 198
.line	1592	loadk        r42    k8 ; k8 = 49
.line	1592	loadk        r43   k28 ; k28 = 164
.line	1592	loadk        r44   k20 ; k20 = 76
.line	1592	loadk        r45   k37 ; k37 = 64
.line	1592	loadk        r46   k38 ; k38 = 161
.line	1592	loadk        r47   k53 ; k53 = 92
.line	1592	loadk        r48    k9 ; k9 = 70
.line	1592	call          r8    41     2
.line	1592	getupval      r9    u1
.line	1592	loadk        r10   k87 ; k87 = 47
.line	1592	loadk        r11   k56 ; k56 = 80
.line	1592	loadk        r12   k88 ; k88 = 211
.line	1592	loadk        r13   k65 ; k65 = 102
.line	1592	loadk        r14   k78 ; k78 = 166
.line	1592	loadk        r15   k79 ; k79 = 226
.line	1592	loadk        r16   k80 ; k80 = 38
.line	1592	loadk        r17   k68 ; k68 = 88
.line	1592	loadk        r18   k38 ; k38 = 161
.line	1592	loadk        r19   k77 ; k77 = 222
.line	1592	loadk        r20   k39 ; k39 = 101
.line	1592	loadk        r21   k80 ; k80 = 38
.line	1592	loadk        r22   k21 ; k21 = 254
.line	1592	loadk        r23   k89 ; k89 = 188
.line	1592	loadk        r24   k49 ; k49 = 98
.line	1592	call          r9    16     0
.line	1592	setlist       r7     0     1
.line	1592	call          r6     2     2
.label	l393
.line	1592	call          r5     2     1
.line	1592	loadbool      r5     0     0
.line	1592	return        r5     2
.label	l396
.line	1592	gettabup      r5    u0   k90 ; k90 = "import"
.line	1592	getupval      r6    u1
.line	1592	loadk         r7   k91 ; k91 = 6
.line	1592	loadk         r8   k92 ; k92 = 112
.line	1592	loadk         r9   k30 ; k30 = 220
.line	1592	loadk        r10   k49 ; k49 = 98
.line	1592	loadk        r11   k93 ; k93 = 160
.line	1592	loadk        r12   k94 ; k94 = 192
.line	1592	loadk        r13   k95 ; k95 = 59
.line	1592	loadk        r14   k39 ; k39 = 101
.line	1592	loadk        r15   k46 ; k46 = 185
.line	1592	loadk        r16    k4 ; k4 = 195
.line	1592	loadk        r17   k16 ; k16 = 126
.line	1592	loadk        r18   k96 ; k96 = 30
.line	1592	loadk        r19   k97 ; k97 = 235
.line	1592	loadk        r20   k58 ; k58 = 169
.line	1592	loadk        r21   k57 ; k57 = 117
.line	1592	call          r6    16     2
.line	1592	call          r5     2     2
.line	1592	self          r6    r3   k98 ; k98 = "GetEquippedItemDefin" (truncated)
.line	1592	gettable      r8    r5   k99 ; k99 = "EAvatarSlotType_Clot" (truncated)
.line	1592	call          r6     3     2
.line	1592	gettabup      r7    u0  k100 ; k100 = "require"
.line	1592	gettabup      r8    u0   k35 ; k35 = "table"
.line	1592	gettable      r8    r8   k36 ; k36 = "concat"
.line	1592	newtable      r9     1     0
.line	1592	getupval     r10    u1
.line	1592	loadk        r11  k101 ; k101 = 4
.line	1592	loadk        r12   k56 ; k56 = 80
.line	1592	loadk        r13   k27 ; k27 = 199
.line	1592	loadk        r14   k65 ; k65 = 102
.line	1592	loadk        r15   k50 ; k50 = 152
.line	1592	loadk        r16  k102 ; k102 = 212
.line	1592	loadk        r17  k103 ; k103 = 40
.line	1592	loadk        r18  k104 ; k104 = 24
.line	1592	loadk        r19  k105 ; k105 = 148
.line	1592	loadk        r20  k106 ; k106 = 207
.line	1592	loadk        r21   k16 ; k16 = 126
.line	1592	loadk        r22  k107 ; k107 = 35
.line	1592	loadk        r23    k7 ; k7 = 228
.line	1592	loadk        r24  k108 ; k108 = 176
.line	1592	loadk        r25   k47 ; k47 = 100
.line	1592	loadk        r26  k109 ; k109 = 193
.line	1592	loadk        r27  k110 ; k110 = 157
.line	1592	loadk        r28  k111 ; k111 = 66
.line	1592	loadk        r29   k42 ; k42 = 181
.line	1592	loadk        r30   k23 ; k23 = 94
.line	1592	loadk        r31  k112 ; k112 = 73
.line	1592	loadk        r32  k113 ; k113 = 244
.line	1592	loadk        r33  k114 ; k114 = 75
.line	1592	loadk        r34   k39 ; k39 = 101
.line	1592	loadk        r35  k115 ; k115 = 172
.line	1592	loadk        r36   k59 ; k59 = 221
.line	1592	loadk        r37  k116 ; k116 = 118
.line	1592	loadk        r38  k117 ; k117 = 51
.line	1592	loadk        r39  k118 ; k118 = 248
.line	1592	loadk        r40  k115 ; k115 = 172
.line	1592	loadk        r41   k26 ; k26 = 46
.line	1592	loadk        r42  k119 ; k119 = 239
.line	1592	loadk        r43   k71 ; k71 = 194
.line	1592	loadk        r44  k120 ; k120 = 124
.line	1592	loadk        r45  k121 ; k121 = 175
.line	1592	loadk        r46   k25 ; k25 = 115
.line	1592	loadk        r47   k68 ; k68 = 88
.line	1592	loadk        r48  k122 ; k122 = 224
.line	1592	loadk        r49   k56 ; k56 = 80
.line	1592	loadk        r50  k123 ; k123 = 56
.line	1592	call         r10    41     2
.line	1592	getupval     r11    u1
.line	1592	loadk        r12  k124 ; k124 = 27
.line	1592	loadk        r13   k49 ; k49 = 98
.line	1592	loadk        r14  k125 ; k125 = 223
.line	1592	loadk        r15   k41 ; k41 = 106
.line	1592	loadk        r16   k93 ; k93 = 160
.line	1592	loadk        r17  k126 ; k126 = 143
.line	1592	loadk        r18  k127 ; k127 = 17
.line	1592	loadk        r19   k39 ; k39 = 101
.line	1592	loadk        r20   k93 ; k93 = 160
.line	1592	loadk        r21  k128 ; k128 = 197
.line	1592	loadk        r22   k16 ; k16 = 126
.line	1592	loadk        r23  k129 ; k129 = 31
.line	1592	loadk        r24  k130 ; k130 = 230
.line	1592	loadk        r25  k108 ; k108 = 176
.line	1592	loadk        r26  k120 ; k120 = 124
.line	1592	call         r11    16     0
.line	1592	setlist       r9     0     1
.line	1592	call          r8     2     2
.line	1592	call          r7     2     2
.line	1592	gettabup      r8    u0  k100 ; k100 = "require"
.line	1592	gettabup      r9    u0   k35 ; k35 = "table"
.line	1592	gettable      r9    r9   k36 ; k36 = "concat"
.line	1592	newtable     r10     1     0
.line	1592	getupval     r11    u1
.line	1592	loadk        r12  k131 ; k131 = 32
.line	1592	loadk        r13  k132 ; k132 = 93
.line	1592	loadk        r14    k4 ; k4 = 195
.line	1592	loadk        r15   k65 ; k65 = 102
.line	1592	loadk        r16  k133 ; k133 = 186
.line	1592	loadk        r17  k134 ; k134 = 213
.line	1592	loadk        r18  k135 ; k135 = 103
.line	1592	loadk        r19   k45 ; k45 = 69
.line	1592	loadk        r20   k46 ; k46 = 185
.line	1592	loadk        r21  k136 ; k136 = 217
.line	1592	loadk        r22  k137 ; k137 = 107
.line	1592	loadk        r23   k47 ; k47 = 100
.line	1592	loadk        r24   k21 ; k21 = 254
.line	1592	loadk        r25   k15 ; k15 = 182
.line	1592	loadk        r26  k138 ; k138 = 119
.line	1592	loadk        r27  k139 ; k139 = 209
.line	1592	loadk        r28  k140 ; k140 = 208
.line	1592	loadk        r29   k87 ; k87 = 47
.line	1592	loadk        r30  k141 ; k141 = 190
.line	1592	loadk        r31   k53 ; k53 = 92
.line	1592	loadk        r32  k142 ; k142 = 83
.line	1592	loadk        r33   k55 ; k55 = 255
.line	1592	loadk        r34  k143 ; k143 = 85
.line	1592	loadk        r35  k144 ; k144 = 105
.line	1592	loadk        r36   k28 ; k28 = 164
.line	1592	loadk        r37  k145 ; k145 = 216
.line	1592	loadk        r38  k146 ; k146 = 52
.line	1592	loadk        r39  k147 ; k147 = 42
.line	1592	loadk        r40  k148 ; k148 = 247
.line	1592	loadk        r41  k121 ; k121 = 175
.line	1592	loadk        r42   k65 ; k65 = 102
.line	1592	loadk        r43   k43 ; k43 = 205
.line	1592	loadk        r44  k139 ; k139 = 209
.line	1592	loadk        r45  k149 ; k149 = 63
.line	1592	loadk        r46  k133 ; k133 = 186
.line	1592	loadk        r47   k54 ; k54 = 86
.line	1592	loadk        r48  k150 ; k150 = 82
.line	1592	loadk        r49  k151 ; k151 = 231
.line	1592	loadk        r50   k20 ; k20 = 76
.line	1592	loadk        r51   k47 ; k47 = 100
.line	1592	call         r11    41     2
.line	1592	getupval     r12    u1
.line	1592	loadk        r13  k152 ; k152 = 28
.line	1592	loadk        r14   k53 ; k53 = 92
.line	1592	loadk        r15  k153 ; k153 = 203
.line	1592	loadk        r16  k154 ; k154 = 109
.line	1592	loadk        r17   k42 ; k42 = 181
.line	1592	loadk        r18   k31 ; k31 = 198
.line	1592	loadk        r19  k155 ; k155 = 44
.line	1592	loadk        r20    k3 ; k3 = 68
.line	1592	call         r12     9     0
.line	1592	setlist      r10     0     1
.line	1592	call          r9     2     2
.line	1592	call          r8     2     2
.line	1592	gettabup      r9    u0  k100 ; k100 = "require"
.line	1592	getupval     r10    u1
.line	1592	loadk        r11  k131 ; k131 = 32
.line	1592	loadk        r12  k132 ; k132 = 93
.line	1592	loadk        r13    k4 ; k4 = 195
.line	1592	loadk        r14   k65 ; k65 = 102
.line	1592	loadk        r15  k133 ; k133 = 186
.line	1592	loadk        r16  k134 ; k134 = 213
.line	1592	loadk        r17  k135 ; k135 = 103
.line	1592	loadk        r18   k45 ; k45 = 69
.line	1592	loadk        r19   k46 ; k46 = 185
.line	1592	loadk        r20  k136 ; k136 = 217
.line	1592	loadk        r21  k137 ; k137 = 107
.line	1592	loadk        r22   k47 ; k47 = 100
.line	1592	loadk        r23   k21 ; k21 = 254
.line	1592	loadk        r24   k15 ; k15 = 182
.line	1592	loadk        r25  k138 ; k138 = 119
.line	1592	loadk        r26  k139 ; k139 = 209
.line	1592	loadk        r27  k140 ; k140 = 208
.line	1592	loadk        r28   k87 ; k87 = 47
.line	1592	loadk        r29  k141 ; k141 = 190
.line	1592	loadk        r30   k53 ; k53 = 92
.line	1592	loadk        r31  k142 ; k142 = 83
.line	1592	loadk        r32   k55 ; k55 = 255
.line	1592	loadk        r33  k143 ; k143 = 85
.line	1592	loadk        r34  k144 ; k144 = 105
.line	1592	loadk        r35   k28 ; k28 = 164
.line	1592	loadk        r36  k145 ; k145 = 216
.line	1592	loadk        r37  k146 ; k146 = 52
.line	1592	loadk        r38  k147 ; k147 = 42
.line	1592	loadk        r39  k148 ; k148 = 247
.line	1592	loadk        r40  k121 ; k121 = 175
.line	1592	loadk        r41   k65 ; k65 = 102
.line	1592	loadk        r42   k43 ; k43 = 205
.line	1592	loadk        r43  k139 ; k139 = 209
.line	1592	loadk        r44   k22 ; k22 = 78
.line	1592	loadk        r45   k58 ; k58 = 169
.line	1592	loadk        r46   k20 ; k20 = 76
.line	1592	loadk        r47  k156 ; k156 = 90
.line	1592	loadk        r48  k157 ; k157 = 242
.line	1592	loadk        r49  k132 ; k132 = 93
.line	1592	call         r10    40     2
.line	1592	call          r9     2     2
.line	1592	gettable     r10    r8  k158 ; k158 = "GetState"
.line	1592	gettable     r11    r9  k159 ; k159 = "ENUM_DownloadType"
.line	1592	gettable     r11   r11  k160 ; k160 = "ODPAK"
.line	1592	newtable     r12     1     0
.line	1592	gettable     r13    r6  k161 ; k161 = "TypeSpecificID"
.line	1592	setlist      r12     1     1
.line	1592	call         r10     3     2
.line	1592	gettabup     r11    u0  k162 ; k162 = "log"
.line	1592	gettabup     r12    u0    k1 ; k1 = "bWriteLog"
.line	1592	test         r12     0
.line	1592	jmp            0  l659
.line	1592	gettabup     r12    u0   k35 ; k35 = "table"
.line	1592	gettable     r12   r12   k36 ; k36 = "concat"
.line	1592	newtable     r13     1     0
.line	1592	getupval     r14    u1
.line	1592	loadk        r15    k2 ; k2 = 18
.line	1592	loadk        r16    k3 ; k3 = 68
.line	1592	loadk        r17    k4 ; k4 = 195
.line	1592	loadk        r18    k5 ; k5 = 96
.line	1592	loadk        r19    k6 ; k6 = 191
.line	1592	loadk        r20    k7 ; k7 = 228
.line	1592	loadk        r21    k8 ; k8 = 49
.line	1592	loadk        r22    k9 ; k9 = 70
.line	1592	loadk        r23   k10 ; k10 = 167
.line	1592	loadk        r24   k11 ; k11 = 201
.line	1592	loadk        r25   k12 ; k12 = 121
.line	1592	loadk        r26   k13 ; k13 = 57
.line	1592	loadk        r27   k14 ; k14 = 251
.line	1592	loadk        r28   k15 ; k15 = 182
.line	1592	loadk        r29   k16 ; k16 = 126
.line	1592	loadk        r30   k17 ; k17 = 130
.line	1592	loadk        r31   k18 ; k18 = 240
.line	1592	loadk        r32    k5 ; k5 = 96
.line	1592	loadk        r33   k19 ; k19 = 180
.line	1592	loadk        r34    k5 ; k5 = 96
.line	1592	loadk        r35   k20 ; k20 = 76
.line	1592	loadk        r36   k21 ; k21 = 254
.line	1592	loadk        r37   k22 ; k22 = 78
.line	1592	loadk        r38   k23 ; k23 = 94
.line	1592	loadk        r39   k24 ; k24 = 150
.line	1592	loadk        r40   k11 ; k11 = 201
.line	1592	loadk        r41   k25 ; k25 = 115
.line	1592	loadk        r42   k26 ; k26 = 46
.line	1592	loadk        r43   k27 ; k27 = 199
.line	1592	loadk        r44   k28 ; k28 = 164
.line	1592	loadk        r45   k29 ; k29 = 111
.line	1592	loadk        r46   k30 ; k30 = 220
.line	1592	loadk        r47   k31 ; k31 = 198
.line	1592	loadk        r48  k149 ; k149 = 63
.line	1592	loadk        r49  k163 ; k163 = 234
.line	1592	loadk        r50  k164 ; k164 = 71
.line	1592	loadk        r51   k81 ; k81 = 91
.line	1592	loadk        r52  k165 ; k165 = 246
.line	1592	loadk        r53   k45 ; k45 = 69
.line	1592	loadk        r54   k12 ; k12 = 121
.line	1592	call         r14    41     2
.line	1592	getupval     r15    u1
.line	1592	loadk        r16  k166 ; k166 = 34
.line	1592	loadk        r17  k143 ; k143 = 85
.line	1592	loadk        r18  k167 ; k167 = 249
.line	1592	loadk        r19  k138 ; k138 = 119
.line	1592	loadk        r20   k42 ; k42 = 181
.line	1592	loadk        r21  k134 ; k134 = 213
.line	1592	loadk        r22  k155 ; k155 = 44
.line	1592	loadk        r23  k168 ; k168 = 12
.line	1592	loadk        r24  k169 ; k169 = 245
.line	1592	call         r15    10     0
.line	1592	setlist      r13     0     1
.line	1592	call         r12     2     2
.line	1592	gettabup     r13    u0  k170 ; k170 = "tostring"
.line	1592	move         r14   r10
.line	1592	call         r13     2     2
.line	1592	concat       r12   r12   r13
.label	l659
.line	1592	call         r11     2     1
.line	1592	gettable     r11    r9  k171 ; k171 = "ENUM_DownloadState"
.line	1592	gettable     r11   r11  k172 ; k172 = "Done"
.line	1592	eq             1   r10   r11
.line	1592	jmp            0  l728
.line	1592	gettabup     r11    u0    k0 ; k0 = "print"
.line	1592	gettabup     r12    u0    k1 ; k1 = "bWriteLog"
.line	1592	test         r12     0
.line	1592	jmp            0  l725
.line	1592	gettabup     r12    u0   k35 ; k35 = "table"
.line	1592	gettable     r12   r12   k36 ; k36 = "concat"
.line	1592	newtable     r13     1     0
.line	1592	getupval     r14    u1
.line	1592	loadk        r15    k2 ; k2 = 18
.line	1592	loadk        r16    k3 ; k3 = 68
.line	1592	loadk        r17    k4 ; k4 = 195
.line	1592	loadk        r18    k5 ; k5 = 96
.line	1592	loadk        r19    k6 ; k6 = 191
.line	1592	loadk        r20    k7 ; k7 = 228
.line	1592	loadk        r21    k8 ; k8 = 49
.line	1592	loadk        r22    k9 ; k9 = 70
.line	1592	loadk        r23   k10 ; k10 = 167
.line	1592	loadk        r24   k11 ; k11 = 201
.line	1592	loadk        r25   k12 ; k12 = 121
.line	1592	loadk        r26   k13 ; k13 = 57
.line	1592	loadk        r27   k14 ; k14 = 251
.line	1592	loadk        r28   k15 ; k15 = 182
.line	1592	loadk        r29   k16 ; k16 = 126
.line	1592	loadk        r30   k17 ; k17 = 130
.line	1592	loadk        r31   k18 ; k18 = 240
.line	1592	loadk        r32    k5 ; k5 = 96
.line	1592	loadk        r33   k19 ; k19 = 180
.line	1592	loadk        r34    k5 ; k5 = 96
.line	1592	loadk        r35   k20 ; k20 = 76
.line	1592	loadk        r36   k21 ; k21 = 254
.line	1592	loadk        r37   k22 ; k22 = 78
.line	1592	loadk        r38   k23 ; k23 = 94
.line	1592	loadk        r39   k24 ; k24 = 150
.line	1592	loadk        r40   k11 ; k11 = 201
.line	1592	loadk        r41   k25 ; k25 = 115
.line	1592	loadk        r42   k26 ; k26 = 46
.line	1592	loadk        r43   k27 ; k27 = 199
.line	1592	loadk        r44   k28 ; k28 = 164
.line	1592	loadk        r45   k29 ; k29 = 111
.line	1592	loadk        r46   k30 ; k30 = 220
.line	1592	loadk        r47   k31 ; k31 = 198
.line	1592	loadk        r48    k8 ; k8 = 49
.line	1592	loadk        r49   k28 ; k28 = 164
.line	1592	loadk        r50   k20 ; k20 = 76
.line	1592	loadk        r51   k37 ; k37 = 64
.line	1592	loadk        r52   k38 ; k38 = 161
.line	1592	loadk        r53  k173 ; k173 = 77
.line	1592	loadk        r54   k12 ; k12 = 121
.line	1592	call         r14    41     2
.line	1592	getupval     r15    u1
.line	1592	loadk        r16  k146 ; k146 = 52
.line	1592	loadk        r17  k174 ; k174 = 95
.line	1592	loadk        r18   k31 ; k31 = 198
.line	1592	loadk        r19  k175 ; k175 = 108
.line	1592	loadk        r20   k42 ; k42 = 181
.line	1592	loadk        r21  k128 ; k128 = 197
.line	1592	loadk        r22  k155 ; k155 = 44
.line	1592	loadk        r23  k150 ; k150 = 82
.line	1592	call         r15     9     0
.line	1592	setlist      r13     0     1
.line	1592	call         r12     2     2
.label	l725
.line	1592	call         r11     2     1
.line	1592	loadbool     r11     0     0
.line	1592	return       r11     2
.label	l728
.line	1592	self         r11    r7  k176 ; k176 = "GetPeriodByItemId"
.line	1592	gettable     r13    r6  k161 ; k161 = "TypeSpecificID"
.line	1592	call         r11     3     2
.line	1592	test         r11     0
.line	1592	jmp            0  l929
.line	1592	lt             0   k44   r11 ; k44 = 0
.line	1592	jmp            0  l929
.line	1592	gettabup     r12    u0  k100 ; k100 = "require"
.line	1592	gettabup     r13    u0   k35 ; k35 = "table"
.line	1592	gettable     r13   r13   k36 ; k36 = "concat"
.line	1592	newtable     r14     1     0
.line	1592	getupval     r15    u1
.line	1592	loadk        r16  k101 ; k101 = 4
.line	1592	loadk        r17   k56 ; k56 = 80
.line	1592	loadk        r18   k27 ; k27 = 199
.line	1592	loadk        r19   k65 ; k65 = 102
.line	1592	loadk        r20   k50 ; k50 = 152
.line	1592	loadk        r21  k102 ; k102 = 212
.line	1592	loadk        r22  k103 ; k103 = 40
.line	1592	loadk        r23  k104 ; k104 = 24
.line	1592	loadk        r24  k105 ; k105 = 148
.line	1592	loadk        r25  k106 ; k106 = 207
.line	1592	loadk        r26   k16 ; k16 = 126
.line	1592	loadk        r27  k107 ; k107 = 35
.line	1592	loadk        r28    k7 ; k7 = 228
.line	1592	loadk        r29  k108 ; k108 = 176
.line	1592	loadk        r30   k47 ; k47 = 100
.line	1592	loadk        r31  k109 ; k109 = 193
.line	1592	loadk        r32  k110 ; k110 = 157
.line	1592	loadk        r33  k111 ; k111 = 66
.line	1592	loadk        r34   k42 ; k42 = 181
.line	1592	loadk        r35   k23 ; k23 = 94
.line	1592	loadk        r36  k112 ; k112 = 73
.line	1592	loadk        r37  k113 ; k113 = 244
.line	1592	loadk        r38  k114 ; k114 = 75
.line	1592	loadk        r39   k39 ; k39 = 101
.line	1592	loadk        r40  k115 ; k115 = 172
.line	1592	loadk        r41   k59 ; k59 = 221
.line	1592	loadk        r42  k116 ; k116 = 118
.line	1592	loadk        r43  k117 ; k117 = 51
.line	1592	loadk        r44  k118 ; k118 = 248
.line	1592	loadk        r45  k115 ; k115 = 172
.line	1592	loadk        r46   k26 ; k26 = 46
.line	1592	loadk        r47  k119 ; k119 = 239
.line	1592	loadk        r48   k71 ; k71 = 194
.line	1592	loadk        r49  k120 ; k120 = 124
.line	1592	loadk        r50  k121 ; k121 = 175
.line	1592	loadk        r51   k25 ; k25 = 115
.line	1592	loadk        r52   k68 ; k68 = 88
.line	1592	loadk        r53  k122 ; k122 = 224
.line	1592	loadk        r54   k56 ; k56 = 80
.line	1592	loadk        r55  k123 ; k123 = 56
.line	1592	call         r15    41     2
.line	1592	getupval     r16    u1
.line	1592	loadk        r17  k124 ; k124 = 27
.line	1592	loadk        r18   k49 ; k49 = 98
.line	1592	loadk        r19  k125 ; k125 = 223
.line	1592	loadk        r20   k41 ; k41 = 106
.line	1592	loadk        r21   k93 ; k93 = 160
.line	1592	loadk        r22  k126 ; k126 = 143
.line	1592	loadk        r23  k177 ; k177 = 5
.line	1592	loadk        r24   k73 ; k73 = 89
.line	1592	loadk        r25  k178 ; k178 = 162
.line	1592	loadk        r26  k122 ; k122 = 224
.line	1592	loadk        r27   k29 ; k29 = 111
.line	1592	loadk        r28  k179 ; k179 = 60
.line	1592	loadk        r29  k148 ; k148 = 247
.line	1592	loadk        r30   k42 ; k42 = 181
.line	1592	loadk        r31  k143 ; k143 = 85
.line	1592	loadk        r32   k77 ; k77 = 222
.line	1592	loadk        r33  k134 ; k134 = 213
.line	1592	loadk        r34   k47 ; k47 = 100
.line	1592	loadk        r35   k46 ; k46 = 185
.line	1592	loadk        r36  k164 ; k164 = 71
.line	1592	call         r16    21     0
.line	1592	setlist      r14     0     1
.line	1592	call         r13     2     2
.line	1592	call         r12     2     2
.line	1592	self         r13    r7  k180 ; k180 = "GetUnLockLevelByFeat" (truncated)
.line	1592	gettable     r15    r6  k161 ; k161 = "TypeSpecificID"
.line	1592	move         r16   r11
.line	1592	gettable     r17    r4   k86 ; k86 = "CommerFeature"
.line	1592	gettable     r17   r17  k181 ; k181 = "XSuitUnlockLevelList"
.line	1592	call         r13     5     2
.line	1592	self         r14    r7  k182 ; k182 = "IsValidXSuitEffect"
.line	1592	gettable     r16    r6  k161 ; k161 = "TypeSpecificID"
.line	1592	gettable     r17   r12  k183 ; k183 = "BornIslandAction"
.line	1592	move         r18   r13
.line	1592	call         r14     5     2
.line	1592	gettabup     r15    u0    k0 ; k0 = "print"
.line	1592	gettabup     r16    u0    k1 ; k1 = "bWriteLog"
.line	1592	test         r16     0
.line	1592	jmp            0  l927
.line	1592	gettabup     r16    u0   k35 ; k35 = "table"
.line	1592	gettable     r16   r16   k36 ; k36 = "concat"
.line	1592	newtable     r17     1     0
.line	1592	getupval     r18    u1
.line	1592	loadk        r19    k2 ; k2 = 18
.line	1592	loadk        r20    k3 ; k3 = 68
.line	1592	loadk        r21    k4 ; k4 = 195
.line	1592	loadk        r22    k5 ; k5 = 96
.line	1592	loadk        r23    k6 ; k6 = 191
.line	1592	loadk        r24    k7 ; k7 = 228
.line	1592	loadk        r25    k8 ; k8 = 49
.line	1592	loadk        r26    k9 ; k9 = 70
.line	1592	loadk        r27   k10 ; k10 = 167
.line	1592	loadk        r28   k11 ; k11 = 201
.line	1592	loadk        r29   k12 ; k12 = 121
.line	1592	loadk        r30   k13 ; k13 = 57
.line	1592	loadk        r31   k14 ; k14 = 251
.line	1592	loadk        r32   k15 ; k15 = 182
.line	1592	loadk        r33   k16 ; k16 = 126
.line	1592	loadk        r34   k17 ; k17 = 130
.line	1592	loadk        r35   k18 ; k18 = 240
.line	1592	loadk        r36    k5 ; k5 = 96
.line	1592	loadk        r37   k19 ; k19 = 180
.line	1592	loadk        r38    k5 ; k5 = 96
.line	1592	loadk        r39   k20 ; k20 = 76
.line	1592	loadk        r40   k21 ; k21 = 254
.line	1592	loadk        r41   k22 ; k22 = 78
.line	1592	loadk        r42   k23 ; k23 = 94
.line	1592	loadk        r43   k24 ; k24 = 150
.line	1592	loadk        r44   k11 ; k11 = 201
.line	1592	loadk        r45   k25 ; k25 = 115
.line	1592	loadk        r46   k26 ; k26 = 46
.line	1592	loadk        r47   k27 ; k27 = 199
.line	1592	loadk        r48   k28 ; k28 = 164
.line	1592	loadk        r49   k29 ; k29 = 111
.line	1592	loadk        r50   k30 ; k30 = 220
.line	1592	loadk        r51   k31 ; k31 = 198
.line	1592	loadk        r52    k8 ; k8 = 49
.line	1592	loadk        r53  k184 ; k184 = 168
.line	1592	loadk        r54   k57 ; k57 = 117
.line	1592	loadk        r55  k143 ; k143 = 85
.line	1592	loadk        r56  k185 ; k185 = 237
.line	1592	loadk        r57   k37 ; k37 = 64
.line	1592	loadk        r58   k52 ; k52 = 114
.line	1592	call         r18    41     2
.line	1592	getupval     r19    u1
.line	1592	loadk        r20   k16 ; k16 = 126
.line	1592	call         r19     2     0
.line	1592	setlist      r17     0     1
.line	1592	call         r16     2     2
.line	1592	gettabup     r17    u0  k170 ; k170 = "tostring"
.line	1592	move         r18   r14
.line	1592	call         r17     2     2
.line	1592	getupval     r18    u1
.line	1592	loadk        r19  k186 ; k186 = 99
.line	1592	loadk        r20   k39 ; k39 = 101
.line	1592	loadk        r21   k88 ; k88 = 211
.line	1592	loadk        r22   k25 ; k25 = 115
.line	1592	loadk        r23  k187 ; k187 = 177
.line	1592	loadk        r24  k157 ; k157 = 242
.line	1592	loadk        r25   k13 ; k13 = 57
.line	1592	loadk        r26  k142 ; k142 = 83
.line	1592	loadk        r27   k15 ; k15 = 182
.line	1592	loadk        r28  k128 ; k128 = 197
.line	1592	loadk        r29  k175 ; k175 = 108
.line	1592	loadk        r30  k107 ; k107 = 35
.line	1592	loadk        r31  k188 ; k188 = 241
.line	1592	loadk        r32  k189 ; k189 = 144
.line	1592	loadk        r33  k190 ; k190 = 84
.line	1592	loadk        r34  k191 ; k191 = 133
.line	1592	call         r18    17     2
.line	1592	gettabup     r19    u0  k170 ; k170 = "tostring"
.line	1592	gettable     r20    r6  k161 ; k161 = "TypeSpecificID"
.line	1592	call         r19     2     2
.line	1592	getupval     r20    u1
.line	1592	loadk        r21  k186 ; k186 = 99
.line	1592	loadk        r22   k66 ; k66 = 97
.line	1592	loadk        r23  k106 ; k106 = 207
.line	1592	loadk        r24  k192 ; k192 = 113
.line	1592	loadk        r25  k193 ; k193 = 189
.line	1592	loadk        r26  k194 ; k194 = 206
.line	1592	loadk        r27   k67 ; k67 = 45
.line	1592	loadk        r28  k195 ; k195 = 11
.line	1592	call         r20     9     2
.line	1592	gettabup     r21    u0  k170 ; k170 = "tostring"
.line	1592	move         r22   r11
.line	1592	call         r21     2     2
.line	1592	getupval     r22    u1
.line	1592	loadk        r23  k186 ; k186 = 99
.line	1592	loadk        r24   k47 ; k47 = 100
.line	1592	loadk        r25   k69 ; k69 = 196
.line	1592	loadk        r26  k196 ; k196 = 79
.line	1592	loadk        r27  k197 ; k197 = 187
.line	1592	loadk        r28   k71 ; k71 = 194
.line	1592	loadk        r29  k166 ; k166 = 34
.line	1592	loadk        r30  k198 ; k198 = 122
.line	1592	loadk        r31  k108 ; k108 = 176
.line	1592	loadk        r32  k199 ; k199 = 218
.line	1592	loadk        r33   k29 ; k29 = 111
.line	1592	loadk        r34   k80 ; k80 = 38
.line	1592	loadk        r35  k121 ; k121 = 175
.line	1592	call         r22    14     2
.line	1592	gettabup     r23    u0  k170 ; k170 = "tostring"
.line	1592	move         r24   r13
.line	1592	call         r23     2     2
.line	1592	concat       r16   r16   r23
.label	l927
.line	1592	call         r15     2     1
.line	1592	return       r14     2
.label	l929
.line	1592	self         r12    r7  k200 ; k200 = "GetBornIslandActionB" (truncated)
.line	1592	gettable     r14    r6  k161 ; k161 = "TypeSpecificID"
.line	1592	move         r15    r3
.line	1592	call         r12     4     2
.line	1592	gettabup     r13    u0    k0 ; k0 = "print"
.line	1592	gettabup     r14    u0    k1 ; k1 = "bWriteLog"
.line	1592	test         r14     0
.line	1592	jmp            0 l1001
.line	1592	gettabup     r14    u0   k35 ; k35 = "table"
.line	1592	gettable     r14   r14   k36 ; k36 = "concat"
.line	1592	newtable     r15     1     0
.line	1592	getupval     r16    u1
.line	1592	loadk        r17    k2 ; k2 = 18
.line	1592	loadk        r18    k3 ; k3 = 68
.line	1592	loadk        r19    k4 ; k4 = 195
.line	1592	loadk        r20    k5 ; k5 = 96
.line	1592	loadk        r21    k6 ; k6 = 191
.line	1592	loadk        r22    k7 ; k7 = 228
.line	1592	loadk        r23    k8 ; k8 = 49
.line	1592	loadk        r24    k9 ; k9 = 70
.line	1592	loadk        r25   k10 ; k10 = 167
.line	1592	loadk        r26   k11 ; k11 = 201
.line	1592	loadk        r27   k12 ; k12 = 121
.line	1592	loadk        r28   k13 ; k13 = 57
.line	1592	loadk        r29   k14 ; k14 = 251
.line	1592	loadk        r30   k15 ; k15 = 182
.line	1592	loadk        r31   k16 ; k16 = 126
.line	1592	loadk        r32   k17 ; k17 = 130
.line	1592	loadk        r33   k18 ; k18 = 240
.line	1592	loadk        r34    k5 ; k5 = 96
.line	1592	loadk        r35   k19 ; k19 = 180
.line	1592	loadk        r36    k5 ; k5 = 96
.line	1592	loadk        r37   k20 ; k20 = 76
.line	1592	loadk        r38   k21 ; k21 = 254
.line	1592	loadk        r39   k22 ; k22 = 78
.line	1592	loadk        r40   k23 ; k23 = 94
.line	1592	loadk        r41   k24 ; k24 = 150
.line	1592	loadk        r42   k11 ; k11 = 201
.line	1592	loadk        r43   k25 ; k25 = 115
.line	1592	loadk        r44   k26 ; k26 = 46
.line	1592	loadk        r45   k27 ; k27 = 199
.line	1592	loadk        r46   k28 ; k28 = 164
.line	1592	loadk        r47   k29 ; k29 = 111
.line	1592	loadk        r48   k30 ; k30 = 220
.line	1592	loadk        r49   k31 ; k31 = 198
.line	1592	loadk        r50    k8 ; k8 = 49
.line	1592	loadk        r51  k201 ; k201 = 136
.line	1592	loadk        r52   k20 ; k20 = 76
.line	1592	loadk        r53    k9 ; k9 = 70
.line	1592	loadk        r54  k119 ; k119 = 239
.line	1592	loadk        r55    k5 ; k5 = 96
.line	1592	loadk        r56   k39 ; k39 = 101
.line	1592	call         r16    41     2
.line	1592	getupval     r17    u1
.line	1592	loadk        r18   k87 ; k87 = 47
.line	1592	loadk        r19   k56 ; k56 = 80
.line	1592	loadk        r20   k69 ; k69 = 196
.line	1592	loadk        r21  k135 ; k135 = 103
.line	1592	loadk        r22   k70 ; k70 = 149
.line	1592	loadk        r23   k71 ; k71 = 194
.line	1592	loadk        r24   k72 ; k72 = 61
.line	1592	loadk        r25  k174 ; k174 = 95
.line	1592	loadk        r26  k133 ; k133 = 186
.line	1592	loadk        r27   k71 ; k71 = 194
.line	1592	loadk        r28  k202 ; k202 = 48
.line	1592	call         r17    12     0
.line	1592	setlist      r15     0     1
.line	1592	call         r14     2     2
.line	1592	gettabup     r15    u0  k170 ; k170 = "tostring"
.line	1592	move         r16   r12
.line	1592	call         r15     2     2
.line	1592	concat       r14   r14   r15
.label	l1001
.line	1592	call         r13     2     1
.line	1592	lt             1   k44   r12 ; k44 = 0
.line	1592	jmp            0 l1005
.line	1592	loadbool     r13     0     1
.label	l1005
.line	1592	loadbool     r13     1     0
.line	1592	return       r13     2
.line	1592	return        r0     1
.line	1592	move          r0    r0
.line	1592	move          r0    r0
.line	1592	return        r0     1

.function	main/f67

.source	null
.linedefined	1639
.lastlinedefined	1654
.numparams	1
.is_vararg	0
.maxstacksize	26

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	5	true
.upvalue	"U3"	23	true

.constant	k0	"CanShowXSuitEmote"
.constant	k1	"Button_XSuit"
.constant	k2	"SetWidgetVisibility"
.constant	k3	"UEnums"
.constant	k4	"ESlateVisibility"
.constant	k5	"Visible"
.constant	k6	"GetBornIslandAction"
.constant	k7	0
.constant	k8	"require"
.constant	k9	32
.constant	k10	93
.constant	k11	195
.constant	k12	102
.constant	k13	186
.constant	k14	213
.constant	k15	103
.constant	k16	85
.constant	k17	193
.constant	k18	37
.constant	k19	252
.constant	k20	247
.constant	k21	101
.constant	k22	209
.constant	k23	236
.constant	k24	116
.constant	k25	174
.constant	k26	90
.constant	k27	72
.constant	k28	"SetTexture"
.constant	k29	"Image_51"
.constant	k30	"GetItemBigIcon"
.constant	k31	"sync"
.constant	k32	false
.constant	k33	"Collapsed"
.constant	k34	"CurrentShowState"
.constant	k35	"PetExpression"

.line	1639	self          r1    r0    k0 ; k0 = "CanShowXSuitEmote"
.line	1639	call          r1     2     2
.line	1639	test          r1     0
.line	1639	jmp            0   l49
.line	1639	gettable      r2    r0    k1 ; k1 = "Button_XSuit"
.line	1639	self          r2    r2    k2 ; k2 = "SetWidgetVisibility"
.line	1639	gettabup      r4    u0    k3 ; k3 = "UEnums"
.line	1639	gettable      r4    r4    k4 ; k4 = "ESlateVisibility"
.line	1639	gettable      r4    r4    k5 ; k5 = "Visible"
.line	1639	call          r2     3     1
.line	1639	self          r2    r0    k6 ; k6 = "GetBornIslandAction"
.line	1639	call          r2     2     2
.line	1639	eq             1    r2    k7 ; k7 = 0
.line	1639	jmp            0   l55
.line	1639	gettabup      r3    u0    k8 ; k8 = "require"
.line	1639	getupval      r4    u1
.line	1639	loadk         r5    k9 ; k9 = 32
.line	1639	loadk         r6   k10 ; k10 = 93
.line	1639	loadk         r7   k11 ; k11 = 195
.line	1639	loadk         r8   k12 ; k12 = 102
.line	1639	loadk         r9   k13 ; k13 = 186
.line	1639	loadk        r10   k14 ; k14 = 213
.line	1639	loadk        r11   k15 ; k15 = 103
.line	1639	loadk        r12   k16 ; k16 = 85
.line	1639	loadk        r13   k13 ; k13 = 186
.line	1639	loadk        r14   k17 ; k17 = 193
.line	1639	loadk        r15   k15 ; k15 = 103
.line	1639	loadk        r16   k18 ; k18 = 37
.line	1639	loadk        r17   k19 ; k19 = 252
.line	1639	loadk        r18   k20 ; k20 = 247
.line	1639	loadk        r19   k21 ; k21 = 101
.line	1639	loadk        r20   k22 ; k22 = 209
.line	1639	loadk        r21   k23 ; k23 = 236
.line	1639	loadk        r22   k24 ; k24 = 116
.line	1639	loadk        r23   k25 ; k25 = 174
.line	1639	loadk        r24   k26 ; k26 = 90
.line	1639	loadk        r25   k27 ; k27 = 72
.line	1639	call          r4    22     2
.line	1639	call          r3     2     2
.line	1639	gettabup      r4    u2   k28 ; k28 = "SetTexture"
.line	1639	gettable      r5    r0   k29 ; k29 = "Image_51"
.line	1639	gettable      r6    r3   k30 ; k30 = "GetItemBigIcon"
.line	1639	move          r7    r2
.line	1639	call          r6     2     2
.line	1639	newtable      r7     0     1
.line	1639	settable      r7   k31   k32 ; k32 = false
.line	1639	call          r4     4     1
.line	1639	jmp            0   l55
.label	l49
.line	1639	gettable      r2    r0    k1 ; k1 = "Button_XSuit"
.line	1639	self          r2    r2    k2 ; k2 = "SetWidgetVisibility"
.line	1639	gettabup      r4    u0    k3 ; k3 = "UEnums"
.line	1639	gettable      r4    r4    k4 ; k4 = "ESlateVisibility"
.line	1639	gettable      r4    r4   k33 ; k33 = "Collapsed"
.line	1639	call          r2     3     1
.label	l55
.line	1639	gettable      r2    r0   k34 ; k34 = "CurrentShowState"
.line	1639	gettabup      r3    u3   k35 ; k35 = "PetExpression"
.line	1639	eq             0    r2    r3
.line	1639	jmp            0   l65
.line	1639	gettable      r2    r0    k1 ; k1 = "Button_XSuit"
.line	1639	self          r2    r2    k2 ; k2 = "SetWidgetVisibility"
.line	1639	gettabup      r4    u0    k3 ; k3 = "UEnums"
.line	1639	gettable      r4    r4    k4 ; k4 = "ESlateVisibility"
.line	1639	gettable      r4    r4   k33 ; k33 = "Collapsed"
.line	1639	call          r2     3     1
.label	l65
.line	1639	return        r0     1
.line	1639	move          r0    r0
.line	1639	move          r0    r0
.line	1639	move          r0    r0
.line	1639	return        r0     1

.function	main/f68

.source	null
.linedefined	1656
.lastlinedefined	1669
.numparams	1
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	14	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"GetPlayerCharacter"
.constant	k1	"slua"
.constant	k2	"isValid"
.constant	k3	0
.constant	k4	"getAvatarComponent2"
.constant	k5	"import"
.constant	k6	6
.constant	k7	112
.constant	k8	220
.constant	k9	98
.constant	k10	160
.constant	k11	192
.constant	k12	59
.constant	k13	101
.constant	k14	185
.constant	k15	195
.constant	k16	126
.constant	k17	30
.constant	k18	235
.constant	k19	169
.constant	k20	117
.constant	k21	"GetEquippedItemDefineID"
.constant	k22	"EAvatarSlotType_ClothesEquipemtSlot"
.constant	k23	"require"
.constant	k24	"table"
.constant	k25	"concat"
.constant	k26	4
.constant	k27	80
.constant	k28	199
.constant	k29	102
.constant	k30	152
.constant	k31	212
.constant	k32	40
.constant	k33	24
.constant	k34	148
.constant	k35	207
.constant	k36	35
.constant	k37	228
.constant	k38	176
.constant	k39	100
.constant	k40	193
.constant	k41	157
.constant	k42	66
.constant	k43	181
.constant	k44	94
.constant	k45	73
.constant	k46	244
.constant	k47	75
.constant	k48	172
.constant	k49	221
.constant	k50	118
.constant	k51	51
.constant	k52	248
.constant	k53	46
.constant	k54	239
.constant	k55	194
.constant	k56	124
.constant	k57	175
.constant	k58	115
.constant	k59	88
.constant	k60	224
.constant	k61	56
.constant	k62	27
.constant	k63	223
.constant	k64	106
.constant	k65	143
.constant	k66	17
.constant	k67	197
.constant	k68	31
.constant	k69	230
.constant	k70	"GetBornIslandActionByItemID"
.constant	k71	"TypeSpecificID"

.line	1656	gettabup      r1    u0    k0 ; k0 = "GetPlayerCharacter"
.line	1656	call          r1     1     2
.line	1656	test          r1     0
.line	1656	jmp            0   l11
.line	1656	gettabup      r2    u1    k1 ; k1 = "slua"
.line	1656	gettable      r2    r2    k2 ; k2 = "isValid"
.line	1656	move          r3    r1
.line	1656	call          r2     2     2
.line	1656	test          r2     1
.line	1656	jmp            0   l13
.label	l11
.line	1656	loadk         r2    k3 ; k3 = 0
.line	1656	return        r2     2
.label	l13
.line	1656	self          r2    r1    k4 ; k4 = "getAvatarComponent2"
.line	1656	call          r2     2     2
.line	1656	gettabup      r3    u1    k1 ; k1 = "slua"
.line	1656	gettable      r3    r3    k2 ; k2 = "isValid"
.line	1656	move          r4    r2
.line	1656	call          r3     2     2
.line	1656	test          r3     1
.line	1656	jmp            0   l23
.line	1656	loadk         r3    k3 ; k3 = 0
.line	1656	return        r3     2
.label	l23
.line	1656	gettabup      r3    u1    k5 ; k5 = "import"
.line	1656	getupval      r4    u2
.line	1656	loadk         r5    k6 ; k6 = 6
.line	1656	loadk         r6    k7 ; k7 = 112
.line	1656	loadk         r7    k8 ; k8 = 220
.line	1656	loadk         r8    k9 ; k9 = 98
.line	1656	loadk         r9   k10 ; k10 = 160
.line	1656	loadk        r10   k11 ; k11 = 192
.line	1656	loadk        r11   k12 ; k12 = 59
.line	1656	loadk        r12   k13 ; k13 = 101
.line	1656	loadk        r13   k14 ; k14 = 185
.line	1656	loadk        r14   k15 ; k15 = 195
.line	1656	loadk        r15   k16 ; k16 = 126
.line	1656	loadk        r16   k17 ; k17 = 30
.line	1656	loadk        r17   k18 ; k18 = 235
.line	1656	loadk        r18   k19 ; k19 = 169
.line	1656	loadk        r19   k20 ; k20 = 117
.line	1656	call          r4    16     2
.line	1656	call          r3     2     2
.line	1656	self          r4    r2   k21 ; k21 = "GetEquippedItemDefin" (truncated)
.line	1656	gettable      r6    r3   k22 ; k22 = "EAvatarSlotType_Clot" (truncated)
.line	1656	call          r4     3     2
.line	1656	gettabup      r5    u1   k23 ; k23 = "require"
.line	1656	gettabup      r6    u1   k24 ; k24 = "table"
.line	1656	gettable      r6    r6   k25 ; k25 = "concat"
.line	1656	newtable      r7     1     0
.line	1656	getupval      r8    u2
.line	1656	loadk         r9   k26 ; k26 = 4
.line	1656	loadk        r10   k27 ; k27 = 80
.line	1656	loadk        r11   k28 ; k28 = 199
.line	1656	loadk        r12   k29 ; k29 = 102
.line	1656	loadk        r13   k30 ; k30 = 152
.line	1656	loadk        r14   k31 ; k31 = 212
.line	1656	loadk        r15   k32 ; k32 = 40
.line	1656	loadk        r16   k33 ; k33 = 24
.line	1656	loadk        r17   k34 ; k34 = 148
.line	1656	loadk        r18   k35 ; k35 = 207
.line	1656	loadk        r19   k16 ; k16 = 126
.line	1656	loadk        r20   k36 ; k36 = 35
.line	1656	loadk        r21   k37 ; k37 = 228
.line	1656	loadk        r22   k38 ; k38 = 176
.line	1656	loadk        r23   k39 ; k39 = 100
.line	1656	loadk        r24   k40 ; k40 = 193
.line	1656	loadk        r25   k41 ; k41 = 157
.line	1656	loadk        r26   k42 ; k42 = 66
.line	1656	loadk        r27   k43 ; k43 = 181
.line	1656	loadk        r28   k44 ; k44 = 94
.line	1656	loadk        r29   k45 ; k45 = 73
.line	1656	loadk        r30   k46 ; k46 = 244
.line	1656	loadk        r31   k47 ; k47 = 75
.line	1656	loadk        r32   k13 ; k13 = 101
.line	1656	loadk        r33   k48 ; k48 = 172
.line	1656	loadk        r34   k49 ; k49 = 221
.line	1656	loadk        r35   k50 ; k50 = 118
.line	1656	loadk        r36   k51 ; k51 = 51
.line	1656	loadk        r37   k52 ; k52 = 248
.line	1656	loadk        r38   k48 ; k48 = 172
.line	1656	loadk        r39   k53 ; k53 = 46
.line	1656	loadk        r40   k54 ; k54 = 239
.line	1656	loadk        r41   k55 ; k55 = 194
.line	1656	loadk        r42   k56 ; k56 = 124
.line	1656	loadk        r43   k57 ; k57 = 175
.line	1656	loadk        r44   k58 ; k58 = 115
.line	1656	loadk        r45   k59 ; k59 = 88
.line	1656	loadk        r46   k60 ; k60 = 224
.line	1656	loadk        r47   k27 ; k27 = 80
.line	1656	loadk        r48   k61 ; k61 = 56
.line	1656	call          r8    41     2
.line	1656	getupval      r9    u2
.line	1656	loadk        r10   k62 ; k62 = 27
.line	1656	loadk        r11    k9 ; k9 = 98
.line	1656	loadk        r12   k63 ; k63 = 223
.line	1656	loadk        r13   k64 ; k64 = 106
.line	1656	loadk        r14   k10 ; k10 = 160
.line	1656	loadk        r15   k65 ; k65 = 143
.line	1656	loadk        r16   k66 ; k66 = 17
.line	1656	loadk        r17   k13 ; k13 = 101
.line	1656	loadk        r18   k10 ; k10 = 160
.line	1656	loadk        r19   k67 ; k67 = 197
.line	1656	loadk        r20   k16 ; k16 = 126
.line	1656	loadk        r21   k68 ; k68 = 31
.line	1656	loadk        r22   k69 ; k69 = 230
.line	1656	loadk        r23   k38 ; k38 = 176
.line	1656	loadk        r24   k56 ; k56 = 124
.line	1656	call          r9    16     0
.line	1656	setlist       r7     0     1
.line	1656	call          r6     2     2
.line	1656	call          r5     2     2
.line	1656	self          r6    r5   k70 ; k70 = "GetBornIslandActionB" (truncated)
.line	1656	gettable      r8    r4   k71 ; k71 = "TypeSpecificID"
.line	1656	move          r9    r2
.line	1656	tailcall      r6     4
.line	1656	return        r6     0
.line	1656	return        r0     1
.line	1656	move          r0    r0
.line	1656	return        r0     1

.function	main/f69

.source	null
.linedefined	1671
.lastlinedefined	1713
.numparams	2
.is_vararg	0
.maxstacksize	57

.upvalue	"_ENV"	14	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"GetPlayerCharacter"
.constant	k1	"slua"
.constant	k2	"isValid"
.constant	k3	"print"
.constant	k4	"bWriteLog"
.constant	k5	"table"
.constant	k6	"concat"
.constant	k7	18
.constant	k8	68
.constant	k9	195
.constant	k10	96
.constant	k11	191
.constant	k12	228
.constant	k13	49
.constant	k14	70
.constant	k15	167
.constant	k16	201
.constant	k17	121
.constant	k18	57
.constant	k19	251
.constant	k20	182
.constant	k21	126
.constant	k22	130
.constant	k23	252
.constant	k24	111
.constant	k25	152
.constant	k26	80
.constant	k27	229
.constant	k28	86
.constant	k29	104
.constant	k30	157
.constant	k31	239
.constant	k32	51
.constant	k33	246
.constant	k34	140
.constant	k35	109
.constant	k36	199
.constant	k37	215
.constant	k38	116
.constant	k39	234
.constant	k40	77
.constant	k41	91
.constant	k42	245
.constant	k43	9
.constant	k44	89
.constant	k45	52
.constant	k46	95
.constant	k47	179
.constant	k48	224
.constant	k49	42
.constant	k50	66
.constant	k51	186
.constant	k52	222
.constant	k53	"getAvatarComponent2"
.constant	k54	99
.constant	k55	2
.constant	k56	71
.constant	k57	203
.constant	k58	119
.constant	k59	181
.constant	k60	211
.constant	k61	10
.constant	k62	184
.constant	k63	220
.constant	k64	56
.constant	k65	"import"
.constant	k66	6
.constant	k67	112
.constant	k68	98
.constant	k69	160
.constant	k70	192
.constant	k71	59
.constant	k72	101
.constant	k73	185
.constant	k74	30
.constant	k75	235
.constant	k76	169
.constant	k77	117
.constant	k78	"GetEquippedItemDefineID"
.constant	k79	"EAvatarSlotType_ClothesEquipemtSlot"
.constant	k80	"require"
.constant	k81	4
.constant	k82	102
.constant	k83	212
.constant	k84	40
.constant	k85	24
.constant	k86	148
.constant	k87	207
.constant	k88	35
.constant	k89	176
.constant	k90	100
.constant	k91	193
.constant	k92	94
.constant	k93	73
.constant	k94	244
.constant	k95	75
.constant	k96	172
.constant	k97	221
.constant	k98	118
.constant	k99	248
.constant	k100	46
.constant	k101	194
.constant	k102	124
.constant	k103	175
.constant	k104	115
.constant	k105	88
.constant	k106	27
.constant	k107	223
.constant	k108	106
.constant	k109	143
.constant	k110	17
.constant	k111	197
.constant	k112	31
.constant	k113	230
.constant	k114	"GetBornIslandActionByItemID"
.constant	k115	"TypeSpecificID"
.constant	k116	0
.constant	k117	97
.constant	k118	243
.constant	k119	48
.constant	k120	93
.constant	k121	188
.constant	k122	136
.constant	k123	"slua_GameFrontendHUD"
.constant	k124	"GetPlayerController"
.constant	k125	"CommerFeature"
.constant	k126	19
.constant	k127	122
.constant	k128	177
.constant	k129	187
.constant	k130	216
.constant	k131	120
.constant	k132	37
.constant	k133	254
.constant	k134	202
.constant	k135	5
.constant	k136	162
.constant	k137	60
.constant	k138	247
.constant	k139	85
.constant	k140	213
.constant	k141	"GetPeriodByItemId"
.constant	k142	"GetUnLockLevelByFeature"
.constant	k143	"XSuitUnlockLevelList"
.constant	k144	"IsValidXSuitEffect"
.constant	k145	"BornIslandAction"
.constant	k146	21
.constant	k147	198
.constant	k148	"PlayEmoteInternal"
.constant	k149	"ShowOrHideRing"

.line	1671	gettabup      r2    u0    k0 ; k0 = "GetPlayerCharacter"
.line	1671	call          r2     1     2
.line	1671	test          r2     0
.line	1671	jmp            0   l11
.line	1671	gettabup      r3    u1    k1 ; k1 = "slua"
.line	1671	gettable      r3    r3    k2 ; k2 = "isValid"
.line	1671	move          r4    r2
.line	1671	call          r3     2     2
.line	1671	test          r3     1
.line	1671	jmp            0   l76
.label	l11
.line	1671	gettabup      r3    u1    k3 ; k3 = "print"
.line	1671	gettabup      r4    u1    k4 ; k4 = "bWriteLog"
.line	1671	test          r4     0
.line	1671	jmp            0   l74
.line	1671	gettabup      r4    u1    k5 ; k5 = "table"
.line	1671	gettable      r4    r4    k6 ; k6 = "concat"
.line	1671	newtable      r5     1     0
.line	1671	getupval      r6    u2
.line	1671	loadk         r7    k7 ; k7 = 18
.line	1671	loadk         r8    k8 ; k8 = 68
.line	1671	loadk         r9    k9 ; k9 = 195
.line	1671	loadk        r10   k10 ; k10 = 96
.line	1671	loadk        r11   k11 ; k11 = 191
.line	1671	loadk        r12   k12 ; k12 = 228
.line	1671	loadk        r13   k13 ; k13 = 49
.line	1671	loadk        r14   k14 ; k14 = 70
.line	1671	loadk        r15   k15 ; k15 = 167
.line	1671	loadk        r16   k16 ; k16 = 201
.line	1671	loadk        r17   k17 ; k17 = 121
.line	1671	loadk        r18   k18 ; k18 = 57
.line	1671	loadk        r19   k19 ; k19 = 251
.line	1671	loadk        r20   k20 ; k20 = 182
.line	1671	loadk        r21   k21 ; k21 = 126
.line	1671	loadk        r22   k22 ; k22 = 130
.line	1671	loadk        r23   k23 ; k23 = 252
.line	1671	loadk        r24   k24 ; k24 = 111
.line	1671	loadk        r25   k25 ; k25 = 152
.line	1671	loadk        r26   k14 ; k14 = 70
.line	1671	loadk        r27   k26 ; k26 = 80
.line	1671	loadk        r28   k27 ; k27 = 229
.line	1671	loadk        r29   k28 ; k28 = 86
.line	1671	loadk        r30   k29 ; k29 = 104
.line	1671	loadk        r31   k30 ; k30 = 157
.line	1671	loadk        r32   k31 ; k31 = 239
.line	1671	loadk        r33   k24 ; k24 = 111
.line	1671	loadk        r34   k32 ; k32 = 51
.line	1671	loadk        r35   k33 ; k33 = 246
.line	1671	loadk        r36   k34 ; k34 = 140
.line	1671	loadk        r37   k35 ; k35 = 109
.line	1671	loadk        r38   k36 ; k36 = 199
.line	1671	loadk        r39   k37 ; k37 = 215
.line	1671	loadk        r40   k38 ; k38 = 116
.line	1671	loadk        r41   k39 ; k39 = 234
.line	1671	loadk        r42   k40 ; k40 = 77
.line	1671	loadk        r43   k41 ; k41 = 91
.line	1671	loadk        r44   k42 ; k42 = 245
.line	1671	loadk        r45   k43 ; k43 = 9
.line	1671	loadk        r46   k44 ; k44 = 89
.line	1671	call          r6    41     2
.line	1671	getupval      r7    u2
.line	1671	loadk         r8   k45 ; k45 = 52
.line	1671	loadk         r9   k46 ; k46 = 95
.line	1671	loadk        r10    k9 ; k9 = 195
.line	1671	loadk        r11   k35 ; k35 = 109
.line	1671	loadk        r12   k47 ; k47 = 179
.line	1671	loadk        r13   k48 ; k48 = 224
.line	1671	loadk        r14   k49 ; k49 = 42
.line	1671	loadk        r15   k50 ; k50 = 66
.line	1671	loadk        r16   k51 ; k51 = 186
.line	1671	loadk        r17   k52 ; k52 = 222
.line	1671	call          r7    11     0
.line	1671	setlist       r5     0     1
.line	1671	call          r4     2     2
.label	l74
.line	1671	call          r3     2     1
.line	1671	return        r0     1
.label	l76
.line	1671	self          r3    r2   k53 ; k53 = "getAvatarComponent2"
.line	1671	call          r3     2     2
.line	1671	gettabup      r4    u1    k1 ; k1 = "slua"
.line	1671	gettable      r4    r4    k2 ; k2 = "isValid"
.line	1671	move          r5    r3
.line	1671	call          r4     2     2
.line	1671	test          r4     1
.line	1671	jmp            0  l150
.line	1671	gettabup      r4    u1    k3 ; k3 = "print"
.line	1671	gettabup      r5    u1    k4 ; k4 = "bWriteLog"
.line	1671	test          r5     0
.line	1671	jmp            0  l148
.line	1671	gettabup      r5    u1    k5 ; k5 = "table"
.line	1671	gettable      r5    r5    k6 ; k6 = "concat"
.line	1671	newtable      r6     1     0
.line	1671	getupval      r7    u2
.line	1671	loadk         r8    k7 ; k7 = 18
.line	1671	loadk         r9    k8 ; k8 = 68
.line	1671	loadk        r10    k9 ; k9 = 195
.line	1671	loadk        r11   k10 ; k10 = 96
.line	1671	loadk        r12   k11 ; k11 = 191
.line	1671	loadk        r13   k12 ; k12 = 228
.line	1671	loadk        r14   k13 ; k13 = 49
.line	1671	loadk        r15   k14 ; k14 = 70
.line	1671	loadk        r16   k15 ; k15 = 167
.line	1671	loadk        r17   k16 ; k16 = 201
.line	1671	loadk        r18   k17 ; k17 = 121
.line	1671	loadk        r19   k18 ; k18 = 57
.line	1671	loadk        r20   k19 ; k19 = 251
.line	1671	loadk        r21   k20 ; k20 = 182
.line	1671	loadk        r22   k21 ; k21 = 126
.line	1671	loadk        r23   k22 ; k22 = 130
.line	1671	loadk        r24   k23 ; k23 = 252
.line	1671	loadk        r25   k24 ; k24 = 111
.line	1671	loadk        r26   k25 ; k25 = 152
.line	1671	loadk        r27   k14 ; k14 = 70
.line	1671	loadk        r28   k26 ; k26 = 80
.line	1671	loadk        r29   k27 ; k27 = 229
.line	1671	loadk        r30   k28 ; k28 = 86
.line	1671	loadk        r31   k29 ; k29 = 104
.line	1671	loadk        r32   k30 ; k30 = 157
.line	1671	loadk        r33   k31 ; k31 = 239
.line	1671	loadk        r34   k24 ; k24 = 111
.line	1671	loadk        r35   k32 ; k32 = 51
.line	1671	loadk        r36   k33 ; k33 = 246
.line	1671	loadk        r37   k34 ; k34 = 140
.line	1671	loadk        r38   k35 ; k35 = 109
.line	1671	loadk        r39   k36 ; k36 = 199
.line	1671	loadk        r40   k37 ; k37 = 215
.line	1671	loadk        r41   k38 ; k38 = 116
.line	1671	loadk        r42   k39 ; k39 = 234
.line	1671	loadk        r43   k40 ; k40 = 77
.line	1671	loadk        r44   k41 ; k41 = 91
.line	1671	loadk        r45   k42 ; k42 = 245
.line	1671	loadk        r46   k43 ; k43 = 9
.line	1671	loadk        r47   k54 ; k54 = 99
.line	1671	call          r7    41     2
.line	1671	getupval      r8    u2
.line	1671	loadk         r9   k55 ; k55 = 2
.line	1671	loadk        r10   k56 ; k56 = 71
.line	1671	loadk        r11   k57 ; k57 = 203
.line	1671	loadk        r12   k58 ; k58 = 119
.line	1671	loadk        r13   k59 ; k59 = 181
.line	1671	loadk        r14   k60 ; k60 = 211
.line	1671	loadk        r15   k61 ; k61 = 10
.line	1671	loadk        r16   k44 ; k44 = 89
.line	1671	loadk        r17   k62 ; k62 = 184
.line	1671	loadk        r18   k63 ; k63 = 220
.line	1671	loadk        r19   k64 ; k64 = 56
.line	1671	call          r8    12     0
.line	1671	setlist       r6     0     1
.line	1671	call          r5     2     2
.label	l148
.line	1671	call          r4     2     1
.line	1671	return        r0     1
.label	l150
.line	1671	gettabup      r4    u1   k65 ; k65 = "import"
.line	1671	getupval      r5    u2
.line	1671	loadk         r6   k66 ; k66 = 6
.line	1671	loadk         r7   k67 ; k67 = 112
.line	1671	loadk         r8   k63 ; k63 = 220
.line	1671	loadk         r9   k68 ; k68 = 98
.line	1671	loadk        r10   k69 ; k69 = 160
.line	1671	loadk        r11   k70 ; k70 = 192
.line	1671	loadk        r12   k71 ; k71 = 59
.line	1671	loadk        r13   k72 ; k72 = 101
.line	1671	loadk        r14   k73 ; k73 = 185
.line	1671	loadk        r15    k9 ; k9 = 195
.line	1671	loadk        r16   k21 ; k21 = 126
.line	1671	loadk        r17   k74 ; k74 = 30
.line	1671	loadk        r18   k75 ; k75 = 235
.line	1671	loadk        r19   k76 ; k76 = 169
.line	1671	loadk        r20   k77 ; k77 = 117
.line	1671	call          r5    16     2
.line	1671	call          r4     2     2
.line	1671	self          r5    r3   k78 ; k78 = "GetEquippedItemDefin" (truncated)
.line	1671	gettable      r7    r4   k79 ; k79 = "EAvatarSlotType_Clot" (truncated)
.line	1671	call          r5     3     2
.line	1671	gettabup      r6    u1   k80 ; k80 = "require"
.line	1671	gettabup      r7    u1    k5 ; k5 = "table"
.line	1671	gettable      r7    r7    k6 ; k6 = "concat"
.line	1671	newtable      r8     1     0
.line	1671	getupval      r9    u2
.line	1671	loadk        r10   k81 ; k81 = 4
.line	1671	loadk        r11   k26 ; k26 = 80
.line	1671	loadk        r12   k36 ; k36 = 199
.line	1671	loadk        r13   k82 ; k82 = 102
.line	1671	loadk        r14   k25 ; k25 = 152
.line	1671	loadk        r15   k83 ; k83 = 212
.line	1671	loadk        r16   k84 ; k84 = 40
.line	1671	loadk        r17   k85 ; k85 = 24
.line	1671	loadk        r18   k86 ; k86 = 148
.line	1671	loadk        r19   k87 ; k87 = 207
.line	1671	loadk        r20   k21 ; k21 = 126
.line	1671	loadk        r21   k88 ; k88 = 35
.line	1671	loadk        r22   k12 ; k12 = 228
.line	1671	loadk        r23   k89 ; k89 = 176
.line	1671	loadk        r24   k90 ; k90 = 100
.line	1671	loadk        r25   k91 ; k91 = 193
.line	1671	loadk        r26   k30 ; k30 = 157
.line	1671	loadk        r27   k50 ; k50 = 66
.line	1671	loadk        r28   k59 ; k59 = 181
.line	1671	loadk        r29   k92 ; k92 = 94
.line	1671	loadk        r30   k93 ; k93 = 73
.line	1671	loadk        r31   k94 ; k94 = 244
.line	1671	loadk        r32   k95 ; k95 = 75
.line	1671	loadk        r33   k72 ; k72 = 101
.line	1671	loadk        r34   k96 ; k96 = 172
.line	1671	loadk        r35   k97 ; k97 = 221
.line	1671	loadk        r36   k98 ; k98 = 118
.line	1671	loadk        r37   k32 ; k32 = 51
.line	1671	loadk        r38   k99 ; k99 = 248
.line	1671	loadk        r39   k96 ; k96 = 172
.line	1671	loadk        r40  k100 ; k100 = 46
.line	1671	loadk        r41   k31 ; k31 = 239
.line	1671	loadk        r42  k101 ; k101 = 194
.line	1671	loadk        r43  k102 ; k102 = 124
.line	1671	loadk        r44  k103 ; k103 = 175
.line	1671	loadk        r45  k104 ; k104 = 115
.line	1671	loadk        r46  k105 ; k105 = 88
.line	1671	loadk        r47   k48 ; k48 = 224
.line	1671	loadk        r48   k26 ; k26 = 80
.line	1671	loadk        r49   k64 ; k64 = 56
.line	1671	call          r9    41     2
.line	1671	getupval     r10    u2
.line	1671	loadk        r11  k106 ; k106 = 27
.line	1671	loadk        r12   k68 ; k68 = 98
.line	1671	loadk        r13  k107 ; k107 = 223
.line	1671	loadk        r14  k108 ; k108 = 106
.line	1671	loadk        r15   k69 ; k69 = 160
.line	1671	loadk        r16  k109 ; k109 = 143
.line	1671	loadk        r17  k110 ; k110 = 17
.line	1671	loadk        r18   k72 ; k72 = 101
.line	1671	loadk        r19   k69 ; k69 = 160
.line	1671	loadk        r20  k111 ; k111 = 197
.line	1671	loadk        r21   k21 ; k21 = 126
.line	1671	loadk        r22  k112 ; k112 = 31
.line	1671	loadk        r23  k113 ; k113 = 230
.line	1671	loadk        r24   k89 ; k89 = 176
.line	1671	loadk        r25  k102 ; k102 = 124
.line	1671	call         r10    16     0
.line	1671	setlist       r8     0     1
.line	1671	call          r7     2     2
.line	1671	call          r6     2     2
.line	1671	self          r7    r6  k114 ; k114 = "GetBornIslandActionB" (truncated)
.line	1671	gettable      r9    r5  k115 ; k115 = "TypeSpecificID"
.line	1671	move         r10    r3
.line	1671	call          r7     4     2
.line	1671	eq             0    r7  k116 ; k116 = 0
.line	1671	jmp            0  l315
.line	1671	gettabup      r8    u1    k3 ; k3 = "print"
.line	1671	gettabup      r9    u1    k4 ; k4 = "bWriteLog"
.line	1671	test          r9     0
.line	1671	jmp            0  l313
.line	1671	gettabup      r9    u1    k5 ; k5 = "table"
.line	1671	gettable      r9    r9    k6 ; k6 = "concat"
.line	1671	newtable     r10     1     0
.line	1671	getupval     r11    u2
.line	1671	loadk        r12    k7 ; k7 = 18
.line	1671	loadk        r13    k8 ; k8 = 68
.line	1671	loadk        r14    k9 ; k9 = 195
.line	1671	loadk        r15   k10 ; k10 = 96
.line	1671	loadk        r16   k11 ; k11 = 191
.line	1671	loadk        r17   k12 ; k12 = 228
.line	1671	loadk        r18   k13 ; k13 = 49
.line	1671	loadk        r19   k14 ; k14 = 70
.line	1671	loadk        r20   k15 ; k15 = 167
.line	1671	loadk        r21   k16 ; k16 = 201
.line	1671	loadk        r22   k17 ; k17 = 121
.line	1671	loadk        r23   k18 ; k18 = 57
.line	1671	loadk        r24   k19 ; k19 = 251
.line	1671	loadk        r25   k20 ; k20 = 182
.line	1671	loadk        r26   k21 ; k21 = 126
.line	1671	loadk        r27   k22 ; k22 = 130
.line	1671	loadk        r28   k23 ; k23 = 252
.line	1671	loadk        r29   k24 ; k24 = 111
.line	1671	loadk        r30   k25 ; k25 = 152
.line	1671	loadk        r31   k14 ; k14 = 70
.line	1671	loadk        r32   k26 ; k26 = 80
.line	1671	loadk        r33   k27 ; k27 = 229
.line	1671	loadk        r34   k28 ; k28 = 86
.line	1671	loadk        r35   k29 ; k29 = 104
.line	1671	loadk        r36   k30 ; k30 = 157
.line	1671	loadk        r37   k31 ; k31 = 239
.line	1671	loadk        r38   k24 ; k24 = 111
.line	1671	loadk        r39   k32 ; k32 = 51
.line	1671	loadk        r40   k33 ; k33 = 246
.line	1671	loadk        r41   k34 ; k34 = 140
.line	1671	loadk        r42   k35 ; k35 = 109
.line	1671	loadk        r43   k36 ; k36 = 199
.line	1671	loadk        r44   k37 ; k37 = 215
.line	1671	loadk        r45   k38 ; k38 = 116
.line	1671	loadk        r46   k39 ; k39 = 234
.line	1671	loadk        r47  k117 ; k117 = 97
.line	1671	loadk        r48   k41 ; k41 = 91
.line	1671	loadk        r49  k118 ; k118 = 243
.line	1671	loadk        r50   k56 ; k56 = 71
.line	1671	loadk        r51   k46 ; k46 = 95
.line	1671	call         r11    41     2
.line	1671	getupval     r12    u2
.line	1671	loadk        r13  k119 ; k119 = 48
.line	1671	loadk        r14  k120 ; k120 = 93
.line	1671	loadk        r15   k57 ; k57 = 203
.line	1671	loadk        r16   k35 ; k35 = 109
.line	1671	loadk        r17   k89 ; k89 = 176
.line	1671	loadk        r18   k48 ; k48 = 224
.line	1671	loadk        r19   k49 ; k49 = 42
.line	1671	loadk        r20   k50 ; k50 = 66
.line	1671	loadk        r21  k121 ; k121 = 188
.line	1671	loadk        r22    k9 ; k9 = 195
.line	1671	loadk        r23   k90 ; k90 = 100
.line	1671	loadk        r24  k108 ; k108 = 106
.line	1671	loadk        r25  k103 ; k103 = 175
.line	1671	loadk        r26   k12 ; k12 = 228
.line	1671	loadk        r27  k119 ; k119 = 48
.line	1671	loadk        r28  k122 ; k122 = 136
.line	1671	call         r12    17     0
.line	1671	setlist      r10     0     1
.line	1671	call          r9     2     2
.label	l313
.line	1671	call          r8     2     1
.line	1671	return        r0     1
.label	l315
.line	1671	gettabup      r8    u1  k123 ; k123 = "slua_GameFrontendHUD"
.line	1671	self          r8    r8  k124 ; k124 = "GetPlayerController"
.line	1671	call          r8     2     2
.line	1671	gettabup      r9    u1    k1 ; k1 = "slua"
.line	1671	gettable      r9    r9    k2 ; k2 = "isValid"
.line	1671	move         r10    r8
.line	1671	call          r9     2     2
.line	1671	test          r9     0
.line	1671	jmp            0  l327
.line	1671	gettable      r9    r8  k125 ; k125 = "CommerFeature"
.line	1671	test          r9     1
.line	1671	jmp            0  l398
.label	l327
.line	1671	gettabup      r9    u1    k3 ; k3 = "print"
.line	1671	gettabup     r10    u1    k4 ; k4 = "bWriteLog"
.line	1671	test         r10     0
.line	1671	jmp            0  l396
.line	1671	gettabup     r10    u1    k5 ; k5 = "table"
.line	1671	gettable     r10   r10    k6 ; k6 = "concat"
.line	1671	newtable     r11     1     0
.line	1671	getupval     r12    u2
.line	1671	loadk        r13    k7 ; k7 = 18
.line	1671	loadk        r14    k8 ; k8 = 68
.line	1671	loadk        r15    k9 ; k9 = 195
.line	1671	loadk        r16   k10 ; k10 = 96
.line	1671	loadk        r17   k11 ; k11 = 191
.line	1671	loadk        r18   k12 ; k12 = 228
.line	1671	loadk        r19   k13 ; k13 = 49
.line	1671	loadk        r20   k14 ; k14 = 70
.line	1671	loadk        r21   k15 ; k15 = 167
.line	1671	loadk        r22   k16 ; k16 = 201
.line	1671	loadk        r23   k17 ; k17 = 121
.line	1671	loadk        r24   k18 ; k18 = 57
.line	1671	loadk        r25   k19 ; k19 = 251
.line	1671	loadk        r26   k20 ; k20 = 182
.line	1671	loadk        r27   k21 ; k21 = 126
.line	1671	loadk        r28   k22 ; k22 = 130
.line	1671	loadk        r29   k23 ; k23 = 252
.line	1671	loadk        r30   k24 ; k24 = 111
.line	1671	loadk        r31   k25 ; k25 = 152
.line	1671	loadk        r32   k14 ; k14 = 70
.line	1671	loadk        r33   k26 ; k26 = 80
.line	1671	loadk        r34   k27 ; k27 = 229
.line	1671	loadk        r35   k28 ; k28 = 86
.line	1671	loadk        r36   k29 ; k29 = 104
.line	1671	loadk        r37   k30 ; k30 = 157
.line	1671	loadk        r38   k31 ; k31 = 239
.line	1671	loadk        r39   k24 ; k24 = 111
.line	1671	loadk        r40   k32 ; k32 = 51
.line	1671	loadk        r41   k33 ; k33 = 246
.line	1671	loadk        r42   k34 ; k34 = 140
.line	1671	loadk        r43   k35 ; k35 = 109
.line	1671	loadk        r44   k36 ; k36 = 199
.line	1671	loadk        r45   k37 ; k37 = 215
.line	1671	loadk        r46   k38 ; k38 = 116
.line	1671	loadk        r47   k39 ; k39 = 234
.line	1671	loadk        r48   k40 ; k40 = 77
.line	1671	loadk        r49   k41 ; k41 = 91
.line	1671	loadk        r50   k42 ; k42 = 245
.line	1671	loadk        r51   k43 ; k43 = 9
.line	1671	loadk        r52   k54 ; k54 = 99
.line	1671	call         r12    41     2
.line	1671	getupval     r13    u2
.line	1671	loadk        r14  k126 ; k126 = 19
.line	1671	loadk        r15  k120 ; k120 = 93
.line	1671	loadk        r16   k57 ; k57 = 203
.line	1671	loadk        r17  k127 ; k127 = 122
.line	1671	loadk        r18  k128 ; k128 = 177
.line	1671	loadk        r19   k60 ; k60 = 211
.line	1671	loadk        r20   k61 ; k61 = 10
.line	1671	loadk        r21   k44 ; k44 = 89
.line	1671	loadk        r22  k129 ; k129 = 187
.line	1671	loadk        r23  k130 ; k130 = 216
.line	1671	loadk        r24  k131 ; k131 = 120
.line	1671	loadk        r25  k132 ; k132 = 37
.line	1671	loadk        r26  k133 ; k133 = 254
.line	1671	loadk        r27   k59 ; k59 = 181
.line	1671	loadk        r28   k77 ; k77 = 117
.line	1671	loadk        r29  k134 ; k134 = 202
.line	1671	call         r13    17     0
.line	1671	setlist      r11     0     1
.line	1671	call         r10     2     2
.label	l396
.line	1671	call          r9     2     1
.line	1671	return        r0     1
.label	l398
.line	1671	gettabup      r9    u1   k80 ; k80 = "require"
.line	1671	gettabup     r10    u1    k5 ; k5 = "table"
.line	1671	gettable     r10   r10    k6 ; k6 = "concat"
.line	1671	newtable     r11     1     0
.line	1671	getupval     r12    u2
.line	1671	loadk        r13   k81 ; k81 = 4
.line	1671	loadk        r14   k26 ; k26 = 80
.line	1671	loadk        r15   k36 ; k36 = 199
.line	1671	loadk        r16   k82 ; k82 = 102
.line	1671	loadk        r17   k25 ; k25 = 152
.line	1671	loadk        r18   k83 ; k83 = 212
.line	1671	loadk        r19   k84 ; k84 = 40
.line	1671	loadk        r20   k85 ; k85 = 24
.line	1671	loadk        r21   k86 ; k86 = 148
.line	1671	loadk        r22   k87 ; k87 = 207
.line	1671	loadk        r23   k21 ; k21 = 126
.line	1671	loadk        r24   k88 ; k88 = 35
.line	1671	loadk        r25   k12 ; k12 = 228
.line	1671	loadk        r26   k89 ; k89 = 176
.line	1671	loadk        r27   k90 ; k90 = 100
.line	1671	loadk        r28   k91 ; k91 = 193
.line	1671	loadk        r29   k30 ; k30 = 157
.line	1671	loadk        r30   k50 ; k50 = 66
.line	1671	loadk        r31   k59 ; k59 = 181
.line	1671	loadk        r32   k92 ; k92 = 94
.line	1671	loadk        r33   k93 ; k93 = 73
.line	1671	loadk        r34   k94 ; k94 = 244
.line	1671	loadk        r35   k95 ; k95 = 75
.line	1671	loadk        r36   k72 ; k72 = 101
.line	1671	loadk        r37   k96 ; k96 = 172
.line	1671	loadk        r38   k97 ; k97 = 221
.line	1671	loadk        r39   k98 ; k98 = 118
.line	1671	loadk        r40   k32 ; k32 = 51
.line	1671	loadk        r41   k99 ; k99 = 248
.line	1671	loadk        r42   k96 ; k96 = 172
.line	1671	loadk        r43  k100 ; k100 = 46
.line	1671	loadk        r44   k31 ; k31 = 239
.line	1671	loadk        r45  k101 ; k101 = 194
.line	1671	loadk        r46  k102 ; k102 = 124
.line	1671	loadk        r47  k103 ; k103 = 175
.line	1671	loadk        r48  k104 ; k104 = 115
.line	1671	loadk        r49  k105 ; k105 = 88
.line	1671	loadk        r50   k48 ; k48 = 224
.line	1671	loadk        r51   k26 ; k26 = 80
.line	1671	loadk        r52   k64 ; k64 = 56
.line	1671	call         r12    41     2
.line	1671	getupval     r13    u2
.line	1671	loadk        r14  k106 ; k106 = 27
.line	1671	loadk        r15   k68 ; k68 = 98
.line	1671	loadk        r16  k107 ; k107 = 223
.line	1671	loadk        r17  k108 ; k108 = 106
.line	1671	loadk        r18   k69 ; k69 = 160
.line	1671	loadk        r19  k109 ; k109 = 143
.line	1671	loadk        r20  k135 ; k135 = 5
.line	1671	loadk        r21   k44 ; k44 = 89
.line	1671	loadk        r22  k136 ; k136 = 162
.line	1671	loadk        r23   k48 ; k48 = 224
.line	1671	loadk        r24   k24 ; k24 = 111
.line	1671	loadk        r25  k137 ; k137 = 60
.line	1671	loadk        r26  k138 ; k138 = 247
.line	1671	loadk        r27   k59 ; k59 = 181
.line	1671	loadk        r28  k139 ; k139 = 85
.line	1671	loadk        r29   k52 ; k52 = 222
.line	1671	loadk        r30  k140 ; k140 = 213
.line	1671	loadk        r31   k90 ; k90 = 100
.line	1671	loadk        r32   k73 ; k73 = 185
.line	1671	loadk        r33   k56 ; k56 = 71
.line	1671	call         r13    21     0
.line	1671	setlist      r11     0     1
.line	1671	call         r10     2     2
.line	1671	call          r9     2     2
.line	1671	self         r10    r6  k141 ; k141 = "GetPeriodByItemId"
.line	1671	gettable     r12    r5  k115 ; k115 = "TypeSpecificID"
.line	1671	call         r10     3     2
.line	1671	test         r10     0
.line	1671	jmp            0  l549
.line	1671	lt             0  k116   r10 ; k116 = 0
.line	1671	jmp            0  l549
.line	1671	self         r11    r6  k142 ; k142 = "GetUnLockLevelByFeat" (truncated)
.line	1671	gettable     r13    r5  k115 ; k115 = "TypeSpecificID"
.line	1671	move         r14   r10
.line	1671	gettable     r15    r8  k125 ; k125 = "CommerFeature"
.line	1671	gettable     r15   r15  k143 ; k143 = "XSuitUnlockLevelList"
.line	1671	call         r11     5     2
.line	1671	self         r12    r6  k144 ; k144 = "IsValidXSuitEffect"
.line	1671	gettable     r14    r5  k115 ; k115 = "TypeSpecificID"
.line	1671	gettable     r15    r9  k145 ; k145 = "BornIslandAction"
.line	1671	move         r16   r11
.line	1671	call         r12     5     2
.line	1671	test         r12     1
.line	1671	jmp            0  l549
.line	1671	gettabup     r13    u1    k3 ; k3 = "print"
.line	1671	gettabup     r14    u1    k4 ; k4 = "bWriteLog"
.line	1671	test         r14     0
.line	1671	jmp            0  l547
.line	1671	gettabup     r14    u1    k5 ; k5 = "table"
.line	1671	gettable     r14   r14    k6 ; k6 = "concat"
.line	1671	newtable     r15     1     0
.line	1671	getupval     r16    u2
.line	1671	loadk        r17    k7 ; k7 = 18
.line	1671	loadk        r18    k8 ; k8 = 68
.line	1671	loadk        r19    k9 ; k9 = 195
.line	1671	loadk        r20   k10 ; k10 = 96
.line	1671	loadk        r21   k11 ; k11 = 191
.line	1671	loadk        r22   k12 ; k12 = 228
.line	1671	loadk        r23   k13 ; k13 = 49
.line	1671	loadk        r24   k14 ; k14 = 70
.line	1671	loadk        r25   k15 ; k15 = 167
.line	1671	loadk        r26   k16 ; k16 = 201
.line	1671	loadk        r27   k17 ; k17 = 121
.line	1671	loadk        r28   k18 ; k18 = 57
.line	1671	loadk        r29   k19 ; k19 = 251
.line	1671	loadk        r30   k20 ; k20 = 182
.line	1671	loadk        r31   k21 ; k21 = 126
.line	1671	loadk        r32   k22 ; k22 = 130
.line	1671	loadk        r33   k23 ; k23 = 252
.line	1671	loadk        r34   k24 ; k24 = 111
.line	1671	loadk        r35   k25 ; k25 = 152
.line	1671	loadk        r36   k14 ; k14 = 70
.line	1671	loadk        r37   k26 ; k26 = 80
.line	1671	loadk        r38   k27 ; k27 = 229
.line	1671	loadk        r39   k28 ; k28 = 86
.line	1671	loadk        r40   k29 ; k29 = 104
.line	1671	loadk        r41   k30 ; k30 = 157
.line	1671	loadk        r42   k31 ; k31 = 239
.line	1671	loadk        r43   k24 ; k24 = 111
.line	1671	loadk        r44   k32 ; k32 = 51
.line	1671	loadk        r45   k33 ; k33 = 246
.line	1671	loadk        r46   k34 ; k34 = 140
.line	1671	loadk        r47   k35 ; k35 = 109
.line	1671	loadk        r48   k36 ; k36 = 199
.line	1671	loadk        r49   k37 ; k37 = 215
.line	1671	loadk        r50   k38 ; k38 = 116
.line	1671	loadk        r51   k39 ; k39 = 234
.line	1671	loadk        r52   k40 ; k40 = 77
.line	1671	loadk        r53   k41 ; k41 = 91
.line	1671	loadk        r54   k42 ; k42 = 245
.line	1671	loadk        r55   k43 ; k43 = 9
.line	1671	loadk        r56   k38 ; k38 = 116
.line	1671	call         r16    41     2
.line	1671	getupval     r17    u2
.line	1671	loadk        r18  k146 ; k146 = 21
.line	1671	loadk        r19   k26 ; k26 = 80
.line	1671	loadk        r20  k147 ; k147 = 198
.line	1671	loadk        r21  k108 ; k108 = 106
.line	1671	loadk        r22   k89 ; k89 = 176
.line	1671	call         r17     6     0
.line	1671	setlist      r15     0     1
.line	1671	call         r14     2     2
.label	l547
.line	1671	call         r13     2     1
.line	1671	return        r0     1
.label	l549
.line	1671	gettable     r11    r0  k148 ; k148 = "PlayEmoteInternal"
.line	1671	test         r11     0
.line	1671	jmp            0  l556
.line	1671	self         r11    r0  k148 ; k148 = "PlayEmoteInternal"
.line	1671	move         r13    r7
.line	1671	call         r11     3     1
.line	1671	jmp            0  l559
.label	l556
.line	1671	self         r11    r1  k148 ; k148 = "PlayEmoteInternal"
.line	1671	move         r13    r7
.line	1671	call         r11     3     1
.label	l559
.line	1671	gettable     r11    r0  k149 ; k149 = "ShowOrHideRing"
.line	1671	test         r11     0
.line	1671	jmp            0  l565
.line	1671	self         r11    r0  k149 ; k149 = "ShowOrHideRing"
.line	1671	loadbool     r13     0     0
.line	1671	call         r11     3     1
.label	l565
.line	1671	return        r0     1
.line	1671	gettabup      r0    u1  k140 ; k140 = 213
.line	1671	move          r0    r0
.line	1671	return        r0     1

.function	main/f70

.source	null
.linedefined	1715
.lastlinedefined	1746
.numparams	1
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	22	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	14	true

.constant	k0	"GetXSuitTailButtonState"
.constant	k1	"bAvailable"
.constant	k2	"require"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	4
.constant	k6	80
.constant	k7	199
.constant	k8	102
.constant	k9	152
.constant	k10	212
.constant	k11	40
.constant	k12	24
.constant	k13	148
.constant	k14	207
.constant	k15	126
.constant	k16	35
.constant	k17	228
.constant	k18	176
.constant	k19	100
.constant	k20	193
.constant	k21	157
.constant	k22	66
.constant	k23	181
.constant	k24	94
.constant	k25	73
.constant	k26	244
.constant	k27	75
.constant	k28	101
.constant	k29	172
.constant	k30	221
.constant	k31	118
.constant	k32	51
.constant	k33	248
.constant	k34	46
.constant	k35	239
.constant	k36	194
.constant	k37	124
.constant	k38	175
.constant	k39	115
.constant	k40	88
.constant	k41	224
.constant	k42	56
.constant	k43	27
.constant	k44	98
.constant	k45	223
.constant	k46	106
.constant	k47	160
.constant	k48	143
.constant	k49	29
.constant	k50	87
.constant	k51	188
.constant	k52	192
.constant	k53	36
.constant	k54	18
.constant	k55	121
.constant	k56	204
.constant	k57	231
.constant	k58	96
.constant	k59	179
.constant	k60	95
.constant	k61	103
.constant	k62	254
.constant	k63	84
.constant	k64	170
.constant	k65	210
.constant	k66	127
.constant	k67	52
.constant	k68	246
.constant	k69	"RequestLocalToggle"
.constant	k70	"DataMgr"
.constant	k71	"roleData"
.constant	k72	"openID"
.constant	k73	32
.constant	k74	93
.constant	k75	195
.constant	k76	186
.constant	k77	213
.constant	k78	90
.constant	k79	203
.constant	k80	99
.constant	k81	41
.constant	k82	149
.constant	k83	218
.constant	k84	138
.constant	k85	69
.constant	k86	232
.constant	k87	92
.constant	k88	116
.constant	k89	206
.constant	k90	60
.constant	k91	241
.constant	k92	112
.constant	k93	196
.constant	k94	104
.constant	k95	81
.constant	k96	68
.constant	k97	243
.constant	k98	76
.constant	k99	48
.constant	k100	"SaveTableToFile_N"
.constant	k101	1
.constant	k102	"ePlayerPrefsType"
.constant	k103	"eXSuitTailButtonSeen"
.constant	k104	"RefreshXSuitTailRedPoint"
.constant	k105	"bWriteLog"
.constant	k106	"printf"
.constant	k107	191
.constant	k108	49
.constant	k109	70
.constant	k110	167
.constant	k111	201
.constant	k112	57
.constant	k113	251
.constant	k114	182
.constant	k115	229
.constant	k116	86
.constant	k117	97
.constant	k118	162
.constant	k119	208
.constant	k120	122
.constant	k121	240
.constant	k122	205
.constant	k123	71
.constant	k124	20
.constant	k125	119
.constant	k126	"tostring"
.constant	k127	"GetPlayerCharacter"
.constant	k128	"slua"
.constant	k129	"isValid"
.constant	k130	"GetAvatarFormState"
.constant	k131	0
.constant	k132	1014419
.constant	k133	"GetSkillManager"
.constant	k134	"Game"
.constant	k135	"IsValid"
.constant	k136	"IsCastingSkillID"
.constant	k137	"print"
.constant	k138	130
.constant	k139	105
.constant	k140	187
.constant	k141	67
.constant	k142	120
.constant	k143	164
.constant	k144	200
.constant	k145	123
.constant	k146	166
.constant	k147	114
.constant	k148	197
.constant	k149	"TriggerEntrySkillWithID"

.line	1715	gettabup      r1    u0    k0 ; k0 = "GetXSuitTailButtonSt" (truncated)
.line	1715	call          r1     1     2
.line	1715	gettable      r2    r1    k1 ; k1 = "bAvailable"
.line	1715	test          r2     0
.line	1715	jmp            0  l228
.line	1715	gettabup      r2    u1    k2 ; k2 = "require"
.line	1715	gettabup      r3    u1    k3 ; k3 = "table"
.line	1715	gettable      r3    r3    k4 ; k4 = "concat"
.line	1715	newtable      r4     1     0
.line	1715	getupval      r5    u2
.line	1715	loadk         r6    k5 ; k5 = 4
.line	1715	loadk         r7    k6 ; k6 = 80
.line	1715	loadk         r8    k7 ; k7 = 199
.line	1715	loadk         r9    k8 ; k8 = 102
.line	1715	loadk        r10    k9 ; k9 = 152
.line	1715	loadk        r11   k10 ; k10 = 212
.line	1715	loadk        r12   k11 ; k11 = 40
.line	1715	loadk        r13   k12 ; k12 = 24
.line	1715	loadk        r14   k13 ; k13 = 148
.line	1715	loadk        r15   k14 ; k14 = 207
.line	1715	loadk        r16   k15 ; k15 = 126
.line	1715	loadk        r17   k16 ; k16 = 35
.line	1715	loadk        r18   k17 ; k17 = 228
.line	1715	loadk        r19   k18 ; k18 = 176
.line	1715	loadk        r20   k19 ; k19 = 100
.line	1715	loadk        r21   k20 ; k20 = 193
.line	1715	loadk        r22   k21 ; k21 = 157
.line	1715	loadk        r23   k22 ; k22 = 66
.line	1715	loadk        r24   k23 ; k23 = 181
.line	1715	loadk        r25   k24 ; k24 = 94
.line	1715	loadk        r26   k25 ; k25 = 73
.line	1715	loadk        r27   k26 ; k26 = 244
.line	1715	loadk        r28   k27 ; k27 = 75
.line	1715	loadk        r29   k28 ; k28 = 101
.line	1715	loadk        r30   k29 ; k29 = 172
.line	1715	loadk        r31   k30 ; k30 = 221
.line	1715	loadk        r32   k31 ; k31 = 118
.line	1715	loadk        r33   k32 ; k32 = 51
.line	1715	loadk        r34   k33 ; k33 = 248
.line	1715	loadk        r35   k29 ; k29 = 172
.line	1715	loadk        r36   k34 ; k34 = 46
.line	1715	loadk        r37   k35 ; k35 = 239
.line	1715	loadk        r38   k36 ; k36 = 194
.line	1715	loadk        r39   k37 ; k37 = 124
.line	1715	loadk        r40   k38 ; k38 = 175
.line	1715	loadk        r41   k39 ; k39 = 115
.line	1715	loadk        r42   k40 ; k40 = 88
.line	1715	loadk        r43   k41 ; k41 = 224
.line	1715	loadk        r44    k6 ; k6 = 80
.line	1715	loadk        r45   k42 ; k42 = 56
.line	1715	call          r5    41     2
.line	1715	getupval      r6    u2
.line	1715	loadk         r7   k43 ; k43 = 27
.line	1715	loadk         r8   k44 ; k44 = 98
.line	1715	loadk         r9   k45 ; k45 = 223
.line	1715	loadk        r10   k46 ; k46 = 106
.line	1715	loadk        r11   k47 ; k47 = 160
.line	1715	loadk        r12   k48 ; k48 = 143
.line	1715	loadk        r13   k49 ; k49 = 29
.line	1715	loadk        r14   k50 ; k50 = 87
.line	1715	loadk        r15   k51 ; k51 = 188
.line	1715	loadk        r16   k52 ; k52 = 192
.line	1715	loadk        r17   k53 ; k53 = 36
.line	1715	loadk        r18   k54 ; k54 = 18
.line	1715	loadk        r19   k20 ; k20 = 193
.line	1715	loadk        r20   k29 ; k29 = 172
.line	1715	loadk        r21   k55 ; k55 = 121
.line	1715	loadk        r22   k56 ; k56 = 204
.line	1715	loadk        r23   k57 ; k57 = 231
.line	1715	loadk        r24   k58 ; k58 = 96
.line	1715	loadk        r25   k59 ; k59 = 179
.line	1715	loadk        r26   k60 ; k60 = 95
.line	1715	loadk        r27   k61 ; k61 = 103
.line	1715	loadk        r28   k62 ; k62 = 254
.line	1715	loadk        r29   k63 ; k63 = 84
.line	1715	loadk        r30   k31 ; k31 = 118
.line	1715	loadk        r31   k64 ; k64 = 170
.line	1715	loadk        r32   k65 ; k65 = 210
.line	1715	loadk        r33   k66 ; k66 = 127
.line	1715	loadk        r34   k67 ; k67 = 52
.line	1715	loadk        r35   k68 ; k68 = 246
.line	1715	call          r6    30     0
.line	1715	setlist       r4     0     1
.line	1715	call          r3     2     2
.line	1715	call          r2     2     2
.line	1715	gettable      r3    r2   k69 ; k69 = "RequestLocalToggle"
.line	1715	call          r3     1     3
.line	1715	test          r3     0
.line	1715	jmp            0  l164
.line	1715	gettabup      r5    u1   k70 ; k70 = "DataMgr"
.line	1715	test          r5     0
.line	1715	jmp            0  l159
.line	1715	gettabup      r5    u1   k70 ; k70 = "DataMgr"
.line	1715	gettable      r5    r5   k71 ; k71 = "roleData"
.line	1715	test          r5     0
.line	1715	jmp            0  l159
.line	1715	gettabup      r5    u1   k70 ; k70 = "DataMgr"
.line	1715	gettable      r5    r5   k71 ; k71 = "roleData"
.line	1715	gettable      r5    r5   k72 ; k72 = "openID"
.line	1715	test          r5     0
.line	1715	jmp            0  l159
.line	1715	gettabup      r5    u1    k2 ; k2 = "require"
.line	1715	gettabup      r6    u1    k3 ; k3 = "table"
.line	1715	gettable      r6    r6    k4 ; k4 = "concat"
.line	1715	newtable      r7     1     0
.line	1715	getupval      r8    u2
.line	1715	loadk         r9   k73 ; k73 = 32
.line	1715	loadk        r10   k74 ; k74 = 93
.line	1715	loadk        r11   k75 ; k75 = 195
.line	1715	loadk        r12    k8 ; k8 = 102
.line	1715	loadk        r13   k76 ; k76 = 186
.line	1715	loadk        r14   k77 ; k77 = 213
.line	1715	loadk        r15   k61 ; k61 = 103
.line	1715	loadk        r16   k78 ; k78 = 90
.line	1715	loadk        r17   k76 ; k76 = 186
.line	1715	loadk        r18   k79 ; k79 = 203
.line	1715	loadk        r19   k80 ; k80 = 99
.line	1715	loadk        r20   k81 ; k81 = 41
.line	1715	loadk        r21   k51 ; k51 = 188
.line	1715	loadk        r22   k82 ; k82 = 149
.line	1715	loadk        r23   k66 ; k66 = 127
.line	1715	loadk        r24   k45 ; k45 = 223
.line	1715	loadk        r25   k83 ; k83 = 218
.line	1715	loadk        r26   k44 ; k44 = 98
.line	1715	loadk        r27   k84 ; k84 = 138
.line	1715	loadk        r28   k60 ; k60 = 95
.line	1715	loadk        r29   k85 ; k85 = 69
.line	1715	loadk        r30   k86 ; k86 = 232
.line	1715	loadk        r31   k87 ; k87 = 92
.line	1715	loadk        r32   k88 ; k88 = 116
.line	1715	loadk        r33   k82 ; k82 = 149
.line	1715	loadk        r34   k89 ; k89 = 206
.line	1715	loadk        r35   k66 ; k66 = 127
.line	1715	loadk        r36   k90 ; k90 = 60
.line	1715	loadk        r37   k91 ; k91 = 241
.line	1715	loadk        r38   k57 ; k57 = 231
.line	1715	loadk        r39   k92 ; k92 = 112
.line	1715	loadk        r40   k93 ; k93 = 196
.line	1715	loadk        r41   k36 ; k36 = 194
.line	1715	loadk        r42   k94 ; k94 = 104
.line	1715	loadk        r43   k38 ; k38 = 175
.line	1715	loadk        r44   k95 ; k95 = 81
.line	1715	loadk        r45   k96 ; k96 = 68
.line	1715	loadk        r46   k97 ; k97 = 243
.line	1715	loadk        r47   k98 ; k98 = 76
.line	1715	loadk        r48   k92 ; k92 = 112
.line	1715	call          r8    41     2
.line	1715	getupval      r9    u2
.line	1715	loadk        r10   k99 ; k99 = 48
.line	1715	call          r9     2     0
.line	1715	setlist       r7     0     1
.line	1715	call          r6     2     2
.line	1715	call          r5     2     2
.line	1715	gettable      r6    r5  k100 ; k100 = "SaveTableToFile_N"
.line	1715	loadk         r7  k101 ; k101 = 1
.line	1715	gettable      r8    r5  k102 ; k102 = "ePlayerPrefsType"
.line	1715	gettable      r8    r8  k103 ; k103 = "eXSuitTailButtonSeen"
.line	1715	call          r6     3     1
.label	l159
.line	1715	gettabup      r5    u0  k104 ; k104 = "RefreshXSuitTailRedP" (truncated)
.line	1715	move          r6    r0
.line	1715	loadbool      r7     0     0
.line	1715	call          r5     3     1
.line	1715	jmp            0  l227
.label	l164
.line	1715	gettabup      r5    u1  k105 ; k105 = "bWriteLog"
.line	1715	test          r5     0
.line	1715	jmp            0  l227
.line	1715	gettabup      r5    u1  k106 ; k106 = "printf"
.line	1715	gettabup      r6    u1    k3 ; k3 = "table"
.line	1715	gettable      r6    r6    k4 ; k4 = "concat"
.line	1715	newtable      r7     1     0
.line	1715	getupval      r8    u2
.line	1715	loadk         r9   k54 ; k54 = 18
.line	1715	loadk        r10   k96 ; k96 = 68
.line	1715	loadk        r11   k75 ; k75 = 195
.line	1715	loadk        r12   k58 ; k58 = 96
.line	1715	loadk        r13  k107 ; k107 = 191
.line	1715	loadk        r14   k17 ; k17 = 228
.line	1715	loadk        r15  k108 ; k108 = 49
.line	1715	loadk        r16  k109 ; k109 = 70
.line	1715	loadk        r17  k110 ; k110 = 167
.line	1715	loadk        r18  k111 ; k111 = 201
.line	1715	loadk        r19   k55 ; k55 = 121
.line	1715	loadk        r20  k112 ; k112 = 57
.line	1715	loadk        r21  k113 ; k113 = 251
.line	1715	loadk        r22  k114 ; k114 = 182
.line	1715	loadk        r23   k15 ; k15 = 126
.line	1715	loadk        r24    k9 ; k9 = 152
.line	1715	loadk        r25    k7 ; k7 = 199
.line	1715	loadk        r26   k58 ; k58 = 96
.line	1715	loadk        r27   k59 ; k59 = 179
.line	1715	loadk        r28   k60 ; k60 = 95
.line	1715	loadk        r29    k5 ; k5 = 4
.line	1715	loadk        r30  k115 ; k115 = 229
.line	1715	loadk        r31  k116 ; k116 = 86
.line	1715	loadk        r32  k117 ; k117 = 97
.line	1715	loadk        r33  k118 ; k118 = 162
.line	1715	loadk        r34  k119 ; k119 = 208
.line	1715	loadk        r35   k66 ; k66 = 127
.line	1715	loadk        r36  k120 ; k120 = 122
.line	1715	loadk        r37  k121 ; k121 = 240
.line	1715	loadk        r38   k29 ; k29 = 172
.line	1715	loadk        r39   k46 ; k46 = 106
.line	1715	loadk        r40  k122 ; k122 = 205
.line	1715	loadk        r41   k52 ; k52 = 192
.line	1715	loadk        r42   k28 ; k28 = 101
.line	1715	loadk        r43   k38 ; k38 = 175
.line	1715	loadk        r44  k123 ; k123 = 71
.line	1715	loadk        r45  k124 ; k124 = 20
.line	1715	loadk        r46   k97 ; k97 = 243
.line	1715	loadk        r47   k98 ; k98 = 76
.line	1715	loadk        r48  k125 ; k125 = 119
.line	1715	call          r8    41     2
.line	1715	getupval      r9    u2
.line	1715	loadk        r10   k99 ; k99 = 48
.line	1715	loadk        r11   k24 ; k24 = 94
.line	1715	loadk        r12   k93 ; k93 = 196
.line	1715	loadk        r13  k112 ; k112 = 57
.line	1715	loadk        r14   k91 ; k91 = 241
.line	1715	loadk        r15   k65 ; k65 = 210
.line	1715	call          r9     7     0
.line	1715	setlist       r7     0     1
.line	1715	call          r6     2     2
.line	1715	gettabup      r7    u1  k126 ; k126 = "tostring"
.line	1715	move          r8    r4
.line	1715	call          r7     2     0
.line	1715	call          r5     0     1
.label	l227
.line	1715	return        r0     1
.label	l228
.line	1715	gettabup      r2    u3  k127 ; k127 = "GetPlayerCharacter"
.line	1715	call          r2     1     2
.line	1715	test          r2     0
.line	1715	jmp            0  l238
.line	1715	gettabup      r3    u1  k128 ; k128 = "slua"
.line	1715	gettable      r3    r3  k129 ; k129 = "isValid"
.line	1715	move          r4    r2
.line	1715	call          r3     2     2
.line	1715	test          r3     1
.line	1715	jmp            0  l239
.label	l238
.line	1715	return        r0     1
.label	l239
.line	1715	gettabup      r3    u0  k130 ; k130 = "GetAvatarFormState"
.line	1715	move          r4    r2
.line	1715	call          r3     2     2
.line	1715	eq             0    r3  k131 ; k131 = 0
.line	1715	jmp            0  l245
.line	1715	return        r0     1
.label	l245
.line	1715	loadk         r4  k132 ; k132 = 1014419
.line	1715	self          r5    r2  k133 ; k133 = "GetSkillManager"
.line	1715	call          r5     2     2
.line	1715	gettabup      r6    u1  k134 ; k134 = "Game"
.line	1715	self          r6    r6  k135 ; k135 = "IsValid"
.line	1715	move          r8    r5
.line	1715	call          r6     3     2
.line	1715	test          r6     0
.line	1715	jmp            0  l260
.line	1715	self          r6    r5  k136 ; k136 = "IsCastingSkillID"
.line	1715	move          r8    r4
.line	1715	call          r6     3     2
.line	1715	test          r6     0
.line	1715	jmp            0  l260
.line	1715	return        r0     1
.label	l260
.line	1715	gettabup      r6    u1  k137 ; k137 = "print"
.line	1715	gettabup      r7    u1  k105 ; k105 = "bWriteLog"
.line	1715	test          r7     0
.line	1715	jmp            0  l298
.line	1715	getupval      r7    u2
.line	1715	loadk         r8   k54 ; k54 = 18
.line	1715	loadk         r9   k96 ; k96 = 68
.line	1715	loadk        r10   k75 ; k75 = 195
.line	1715	loadk        r11   k58 ; k58 = 96
.line	1715	loadk        r12  k107 ; k107 = 191
.line	1715	loadk        r13   k17 ; k17 = 228
.line	1715	loadk        r14  k108 ; k108 = 49
.line	1715	loadk        r15  k109 ; k109 = 70
.line	1715	loadk        r16  k110 ; k110 = 167
.line	1715	loadk        r17  k111 ; k111 = 201
.line	1715	loadk        r18   k55 ; k55 = 121
.line	1715	loadk        r19  k112 ; k112 = 57
.line	1715	loadk        r20  k113 ; k113 = 251
.line	1715	loadk        r21  k114 ; k114 = 182
.line	1715	loadk        r22   k15 ; k15 = 126
.line	1715	loadk        r23  k138 ; k138 = 130
.line	1715	loadk        r24  k121 ; k121 = 240
.line	1715	loadk        r25  k139 ; k139 = 105
.line	1715	loadk        r26  k140 ; k140 = 187
.line	1715	loadk        r27   k74 ; k74 = 93
.line	1715	loadk        r28  k141 ; k141 = 67
.line	1715	loadk        r29   k26 ; k26 = 244
.line	1715	loadk        r30  k142 ; k142 = 120
.line	1715	loadk        r31   k92 ; k92 = 112
.line	1715	loadk        r32  k143 ; k143 = 164
.line	1715	loadk        r33  k144 ; k144 = 200
.line	1715	loadk        r34  k145 ; k145 = 123
.line	1715	loadk        r35   k11 ; k11 = 40
.line	1715	loadk        r36   k93 ; k93 = 196
.line	1715	loadk        r37  k146 ; k146 = 166
.line	1715	loadk        r38  k147 ; k147 = 114
.line	1715	loadk        r39  k148 ; k148 = 197
.line	1715	call          r7    33     2
.label	l298
.line	1715	move          r8    r4
.line	1715	call          r6     3     1
.line	1715	self          r6    r2  k149 ; k149 = "TriggerEntrySkillWit" (truncated)
.line	1715	move          r8    r4
.line	1715	loadbool      r9     1     0
.line	1715	call          r6     4     1
.line	1715	return        r0     1
.line	1715	move          r0    r0
.line	1715	move          r0    r0
.line	1715	move          r0    r0
.line	1715	move          r0    r0
.line	1715	return        r0     1

.function	main/f71

.source	null
.linedefined	1748
.lastlinedefined	1750
.numparams	1
.is_vararg	0
.maxstacksize	3

.constant	k0	"Dispose"

.line	1748	self          r1    r0    k0 ; k0 = "Dispose"
.line	1748	call          r1     2     1
.line	1748	return        r0     1
.line	1748	move          r0    r0
.line	1748	return        r0     1

.function	main/f72

.source	null
.linedefined	1752
.lastlinedefined	1772
.numparams	1
.is_vararg	0
.maxstacksize	11

.upvalue	"_ENV"	0	false
.upvalue	"U1"	24	true

.constant	k0	"bCollectionInited"
.constant	k1	"slua_GameFrontendHUD"
.constant	k2	"GetPlayerController"
.constant	k3	"slua"
.constant	k4	"isValid"
.constant	k5	"PlayEmoteFeature"
.constant	k6	"CollectionEmoteMap"
.constant	k7	"pairs"
.constant	k8	"table"
.constant	k9	"insert"
.constant	k10	"CollectionList"
.constant	k11	true
.constant	k12	"sort"

.line	1752	gettable      r1    r0    k0 ; k0 = "bCollectionInited"
.line	1752	test          r1     0
.line	1752	jmp            0    l5
.line	1752	return        r0     1
.label	l5
.line	1752	gettabup      r1    u0    k1 ; k1 = "slua_GameFrontendHUD"
.line	1752	self          r1    r1    k2 ; k2 = "GetPlayerController"
.line	1752	call          r1     2     2
.line	1752	gettabup      r2    u0    k3 ; k3 = "slua"
.line	1752	gettable      r2    r2    k4 ; k4 = "isValid"
.line	1752	move          r3    r1
.line	1752	call          r2     2     2
.line	1752	test          r2     0
.line	1752	jmp            0   l17
.line	1752	gettable      r2    r1    k5 ; k5 = "PlayEmoteFeature"
.line	1752	test          r2     1
.line	1752	jmp            0   l18
.label	l17
.line	1752	return        r0     1
.label	l18
.line	1752	gettable      r2    r1    k5 ; k5 = "PlayEmoteFeature"
.line	1752	gettable      r2    r2    k6 ; k6 = "CollectionEmoteMap"
.line	1752	test          r2     1
.line	1752	jmp            0   l23
.line	1752	return        r0     1
.label	l23
.line	1752	gettabup      r3    u0    k7 ; k7 = "pairs"
.line	1752	move          r4    r2
.line	1752	call          r3     2     4
.line	1752	jmp            0   l34
.line	1752	gettabup      r8    u0    k8 ; k8 = "table"
.line	1752	gettable      r8    r8    k9 ; k9 = "insert"
.line	1752	gettable      r9    r0   k10 ; k10 = "CollectionList"
.line	1752	move         r10    r6
.line	1752	call          r8     3     1
.line	1752	settabup      u1    r6   k11 ; k11 = true
.line	1752	settable      r0    k0   k11 ; k11 = true
.label	l34
.line	1752	move          r0    r0
.line	1752	move          r0    r0
.line	1752	gettabup      r3    u0    k8 ; k8 = "table"
.line	1752	gettable      r3    r3   k12 ; k12 = "sort"
.line	1752	gettable      r4    r0   k10 ; k10 = "CollectionList"
.line	1752	closure       r5    f0
.line	1752	call          r3     3     1
.line	1752	return        r0     1
.line	1752	move          r0    r0
.line	1752	move          r0    r0
.line	1752	return        r0     1

.function	main/f72/f0

.source	null
.linedefined	1769
.lastlinedefined	1771
.numparams	2
.is_vararg	0
.maxstacksize	3

.line	1769	lt             1    r0    r1
.line	1769	jmp            0    l4
.line	1769	loadbool      r2     0     1
.label	l4
.line	1769	loadbool      r2     1     0
.line	1769	return        r2     2
.line	1769	return        r0     1
.line	1769	move          r0    r0
.line	1769	move          r0    r0
.line	1769	return        r0     1

.function	main/f73

.source	null
.linedefined	1774
.lastlinedefined	1844
.numparams	1
.is_vararg	0
.maxstacksize	57

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"GetCurPet"
.constant	k1	"GetShowMyPet"
.constant	k2	"slua_GameFrontendHUD"
.constant	k3	"GetPlayerController"
.constant	k4	"slua"
.constant	k5	"isValid"
.constant	k6	"IsInPetSpectator"
.constant	k7	"print"
.constant	k8	"bWriteLog"
.constant	k9	18
.constant	k10	68
.constant	k11	195
.constant	k12	96
.constant	k13	191
.constant	k14	228
.constant	k15	49
.constant	k16	70
.constant	k17	167
.constant	k18	201
.constant	k19	121
.constant	k20	57
.constant	k21	251
.constant	k22	182
.constant	k23	126
.constant	k24	130
.constant	k25	225
.constant	k26	100
.constant	k27	188
.constant	k28	65
.constant	k29	226
.constant	k30	81
.constant	k31	86
.constant	k32	160
.constant	k33	200
.constant	k34	83
.constant	k35	52
.constant	k36	166
.constant	k37	"PetID"
.constant	k38	"PetLevel"
.constant	k39	"bShowMyPet"
.constant	k40	"CurPetExpressionList"
.constant	k41	0
.constant	k42	"table"
.constant	k43	"concat"
.constant	k44	32
.constant	k45	208
.constant	k46	66
.constant	k47	186
.constant	k48	87
.constant	k49	245
.constant	k50	72
.constant	k51	98
.constant	k52	44
.constant	k53	67
.constant	k54	"require"
.constant	k55	94
.constant	k56	199
.constant	k57	110
.constant	k58	187
.constant	k59	207
.constant	k60	103
.constant	k61	69
.constant	k62	161
.constant	k63	222
.constant	k64	99
.constant	k65	36
.constant	k66	134
.constant	k67	101
.constant	k68	204
.constant	k69	218
.constant	k70	109
.constant	k71	"pairs"
.constant	k72	"CDataTable"
.constant	k73	"GetTable"
.constant	k74	19
.constant	k75	84
.constant	k76	183
.constant	k77	213
.constant	k78	89
.constant	k79	248
.constant	k80	107
.constant	k81	40
.constant	k82	254
.constant	k83	235
.constant	k84	194
.constant	k85	127
.constant	k86	154
.constant	k87	79
.constant	k88	85
.constant	k89	120
.constant	k90	1
.constant	k91	80
.constant	k92	119
.constant	k93	184
.constant	k94	196
.constant	k95	"CanPlayInBattle"
.constant	k96	2
.constant	k97	3
.constant	k98	"DependingClothesID"
.constant	k99	"Split"
.constant	k100	63
.constant	k101	"next"
.constant	k102	"IsAvatarRequirementMatch"
.constant	k103	"insert"
.constant	k104	"ID"
.constant	k105	"PetActionID"
.constant	k106	"IsLocked"
.constant	k107	true
.constant	k108	"SortKey"
.constant	k109	"MasterSkillID"
.constant	k110	"sort"
.constant	k111	10000
.constant	k112	"GetTableData"
.constant	k113	177
.constant	k114	215
.constant	k115	90
.constant	k116	129
.constant	k117	205
.constant	k118	104
.constant	k119	38
.constant	k120	247
.constant	k121	"AllAction"
.constant	k122	"pairs"

.line	1774	self          r1    r0    k0 ; k0 = "GetCurPet"
.line	1774	call          r1     2     3
.line	1774	self          r3    r0    k1 ; k1 = "GetShowMyPet"
.line	1774	call          r3     2     2
.line	1774	loadbool      r4     0     0
.line	1774	gettabup      r5    u0    k2 ; k2 = "slua_GameFrontendHUD"
.line	1774	self          r5    r5    k3 ; k3 = "GetPlayerController"
.line	1774	call          r5     2     2
.line	1774	gettabup      r6    u0    k4 ; k4 = "slua"
.line	1774	gettable      r6    r6    k5 ; k5 = "isValid"
.line	1774	move          r7    r5
.line	1774	call          r6     2     2
.line	1774	test          r6     0
.line	1774	jmp            0   l23
.line	1774	gettable      r6    r5    k6 ; k6 = "IsInPetSpectator"
.line	1774	test          r6     0
.line	1774	jmp            0   l23
.line	1774	self          r6    r5    k6 ; k6 = "IsInPetSpectator"
.line	1774	call          r6     2     2
.line	1774	test          r6     0
.line	1774	jmp            0   l23
.line	1774	loadbool      r4     1     0
.label	l23
.line	1774	loadbool      r6     0     0
.line	1774	gettable      r7    r0    k6 ; k6 = "IsInPetSpectator"
.line	1774	eq             1    r7    r4
.line	1774	jmp            0   l29
.line	1774	settable      r0    k6    r4 ; k6 = "IsInPetSpectator"
.line	1774	loadbool      r6     1     0
.label	l29
.line	1774	gettabup      r7    u0    k7 ; k7 = "print"
.line	1774	gettabup      r8    u0    k8 ; k8 = "bWriteLog"
.line	1774	test          r8     0
.line	1774	jmp            0   l65
.line	1774	getupval      r8    u1
.line	1774	loadk         r9    k9 ; k9 = 18
.line	1774	loadk        r10   k10 ; k10 = 68
.line	1774	loadk        r11   k11 ; k11 = 195
.line	1774	loadk        r12   k12 ; k12 = 96
.line	1774	loadk        r13   k13 ; k13 = 191
.line	1774	loadk        r14   k14 ; k14 = 228
.line	1774	loadk        r15   k15 ; k15 = 49
.line	1774	loadk        r16   k16 ; k16 = 70
.line	1774	loadk        r17   k17 ; k17 = 167
.line	1774	loadk        r18   k18 ; k18 = 201
.line	1774	loadk        r19   k19 ; k19 = 121
.line	1774	loadk        r20   k20 ; k20 = 57
.line	1774	loadk        r21   k21 ; k21 = 251
.line	1774	loadk        r22   k22 ; k22 = 182
.line	1774	loadk        r23   k23 ; k23 = 126
.line	1774	loadk        r24   k24 ; k24 = 130
.line	1774	loadk        r25   k25 ; k25 = 225
.line	1774	loadk        r26   k26 ; k26 = 100
.line	1774	loadk        r27   k27 ; k27 = 188
.line	1774	loadk        r28   k28 ; k28 = 65
.line	1774	loadk        r29   k28 ; k28 = 65
.line	1774	loadk        r30   k29 ; k29 = 226
.line	1774	loadk        r31   k30 ; k30 = 81
.line	1774	loadk        r32   k31 ; k31 = 86
.line	1774	loadk        r33   k32 ; k32 = 160
.line	1774	loadk        r34   k33 ; k33 = 200
.line	1774	loadk        r35   k34 ; k34 = 83
.line	1774	loadk        r36   k35 ; k35 = 52
.line	1774	loadk        r37   k14 ; k14 = 228
.line	1774	loadk        r38   k36 ; k36 = 166
.line	1774	call          r8    31     2
.label	l65
.line	1774	gettable      r9    r0   k37 ; k37 = "PetID"
.line	1774	move         r10    r1
.line	1774	gettable     r11    r0   k38 ; k38 = "PetLevel"
.line	1774	move         r12    r2
.line	1774	move         r13    r3
.line	1774	move         r14    r6
.line	1774	call          r7     8     1
.line	1774	gettable      r7    r0   k37 ; k37 = "PetID"
.line	1774	eq             0    r7    r1
.line	1774	jmp            0   l84
.line	1774	gettable      r7    r0   k38 ; k38 = "PetLevel"
.line	1774	eq             0    r7    r2
.line	1774	jmp            0   l84
.line	1774	gettable      r7    r0   k39 ; k39 = "bShowMyPet"
.line	1774	eq             0    r7    r3
.line	1774	jmp            0   l84
.line	1774	test          r6     1
.line	1774	jmp            0   l84
.line	1774	return        r0     1
.label	l84
.line	1774	settable      r0   k37    r1 ; k37 = "PetID"
.line	1774	settable      r0   k38    r2 ; k38 = "PetLevel"
.line	1774	newtable      r7     0     0
.line	1774	settable      r0   k40    r7 ; k40 = "CurPetExpressionList"
.line	1774	settable      r0   k39    r3 ; k39 = "bShowMyPet"
.line	1774	gettabup      r7    u0    k7 ; k7 = "print"
.line	1774	gettabup      r8    u0    k8 ; k8 = "bWriteLog"
.line	1774	test          r8     0
.line	1774	jmp            0  l126
.line	1774	getupval      r8    u1
.line	1774	loadk         r9    k9 ; k9 = 18
.line	1774	loadk        r10   k10 ; k10 = 68
.line	1774	loadk        r11   k11 ; k11 = 195
.line	1774	loadk        r12   k12 ; k12 = 96
.line	1774	loadk        r13   k13 ; k13 = 191
.line	1774	loadk        r14   k14 ; k14 = 228
.line	1774	loadk        r15   k15 ; k15 = 49
.line	1774	loadk        r16   k16 ; k16 = 70
.line	1774	loadk        r17   k17 ; k17 = 167
.line	1774	loadk        r18   k18 ; k18 = 201
.line	1774	loadk        r19   k19 ; k19 = 121
.line	1774	loadk        r20   k20 ; k20 = 57
.line	1774	loadk        r21   k21 ; k21 = 251
.line	1774	loadk        r22   k22 ; k22 = 182
.line	1774	loadk        r23   k23 ; k23 = 126
.line	1774	loadk        r24   k24 ; k24 = 130
.line	1774	loadk        r25   k25 ; k25 = 225
.line	1774	loadk        r26   k26 ; k26 = 100
.line	1774	loadk        r27   k27 ; k27 = 188
.line	1774	loadk        r28   k28 ; k28 = 65
.line	1774	loadk        r29   k28 ; k28 = 65
.line	1774	loadk        r30   k29 ; k29 = 226
.line	1774	loadk        r31   k30 ; k30 = 81
.line	1774	loadk        r32   k31 ; k31 = 86
.line	1774	loadk        r33   k32 ; k32 = 160
.line	1774	loadk        r34   k33 ; k33 = 200
.line	1774	loadk        r35   k34 ; k34 = 83
.line	1774	loadk        r36   k35 ; k35 = 52
.line	1774	loadk        r37   k14 ; k14 = 228
.line	1774	loadk        r38   k36 ; k36 = 166
.line	1774	loadk        r39   k15 ; k15 = 49
.line	1774	call          r8    32     2
.label	l126
.line	1774	gettable      r9    r0   k37 ; k37 = "PetID"
.line	1774	gettable     r10    r0   k38 ; k38 = "PetLevel"
.line	1774	gettable     r11    r0   k39 ; k39 = "bShowMyPet"
.line	1774	call          r7     5     1
.line	1774	gettable      r7    r0   k37 ; k37 = "PetID"
.line	1774	test          r7     0
.line	1774	jmp            0  l139
.line	1774	gettable      r7    r0   k37 ; k37 = "PetID"
.line	1774	le             1    r7   k41 ; k41 = 0
.line	1774	jmp            0  l139
.line	1774	gettable      r7    r0   k39 ; k39 = "bShowMyPet"
.line	1774	test          r7     1
.line	1774	jmp            0  l142
.label	l139
.line	1774	test          r6     1
.line	1774	jmp            0  l142
.line	1774	return        r0     1
.label	l142
.line	1774	gettabup      r7    u0    k7 ; k7 = "print"
.line	1774	gettabup      r8    u0    k8 ; k8 = "bWriteLog"
.line	1774	test          r8     0
.line	1774	jmp            0  l197
.line	1774	gettabup      r8    u0   k42 ; k42 = "table"
.line	1774	gettable      r8    r8   k43 ; k43 = "concat"
.line	1774	newtable      r9     1     0
.line	1774	getupval     r10    u1
.line	1774	loadk        r11    k9 ; k9 = 18
.line	1774	loadk        r12   k10 ; k10 = 68
.line	1774	loadk        r13   k11 ; k11 = 195
.line	1774	loadk        r14   k12 ; k12 = 96
.line	1774	loadk        r15   k13 ; k13 = 191
.line	1774	loadk        r16   k14 ; k14 = 228
.line	1774	loadk        r17   k15 ; k15 = 49
.line	1774	loadk        r18   k16 ; k16 = 70
.line	1774	loadk        r19   k17 ; k17 = 167
.line	1774	loadk        r20   k18 ; k18 = 201
.line	1774	loadk        r21   k19 ; k19 = 121
.line	1774	loadk        r22   k20 ; k20 = 57
.line	1774	loadk        r23   k21 ; k21 = 251
.line	1774	loadk        r24   k22 ; k22 = 182
.line	1774	loadk        r25   k23 ; k23 = 126
.line	1774	loadk        r26   k24 ; k24 = 130
.line	1774	loadk        r27   k25 ; k25 = 225
.line	1774	loadk        r28   k26 ; k26 = 100
.line	1774	loadk        r29   k27 ; k27 = 188
.line	1774	loadk        r30   k28 ; k28 = 65
.line	1774	loadk        r31   k28 ; k28 = 65
.line	1774	loadk        r32   k29 ; k29 = 226
.line	1774	loadk        r33   k30 ; k30 = 81
.line	1774	loadk        r34   k31 ; k31 = 86
.line	1774	loadk        r35   k32 ; k32 = 160
.line	1774	loadk        r36   k33 ; k33 = 200
.line	1774	loadk        r37   k34 ; k34 = 83
.line	1774	loadk        r38   k35 ; k35 = 52
.line	1774	loadk        r39   k14 ; k14 = 228
.line	1774	loadk        r40   k36 ; k36 = 166
.line	1774	loadk        r41   k44 ; k44 = 32
.line	1774	loadk        r42   k25 ; k25 = 225
.line	1774	loadk        r43   k45 ; k45 = 208
.line	1774	loadk        r44   k46 ; k46 = 66
.line	1774	loadk        r45   k47 ; k47 = 186
.line	1774	loadk        r46   k16 ; k16 = 70
.line	1774	loadk        r47   k48 ; k48 = 87
.line	1774	loadk        r48   k49 ; k49 = 245
.line	1774	loadk        r49   k50 ; k50 = 72
.line	1774	loadk        r50   k51 ; k51 = 98
.line	1774	call         r10    41     2
.line	1774	getupval     r11    u1
.line	1774	loadk        r12   k52 ; k52 = 44
.line	1774	loadk        r13   k53 ; k53 = 67
.line	1774	call         r11     3     0
.line	1774	setlist       r9     0     1
.line	1774	call          r8     2     2
.label	l197
.line	1774	call          r7     2     1
.line	1774	gettabup      r7    u0   k54 ; k54 = "require"
.line	1774	getupval      r8    u1
.line	1774	loadk         r9   k44 ; k44 = 32
.line	1774	loadk        r10   k55 ; k55 = 94
.line	1774	loadk        r11   k56 ; k56 = 199
.line	1774	loadk        r12   k57 ; k57 = 110
.line	1774	loadk        r13   k58 ; k58 = 187
.line	1774	loadk        r14   k59 ; k59 = 207
.line	1774	loadk        r15   k60 ; k60 = 103
.line	1774	loadk        r16   k61 ; k61 = 69
.line	1774	loadk        r17   k62 ; k62 = 161
.line	1774	loadk        r18   k63 ; k63 = 222
.line	1774	loadk        r19   k64 ; k64 = 99
.line	1774	loadk        r20   k65 ; k65 = 36
.line	1774	loadk        r21   k49 ; k49 = 245
.line	1774	loadk        r22   k66 ; k66 = 134
.line	1774	loadk        r23   k67 ; k67 = 101
.line	1774	loadk        r24   k68 ; k68 = 204
.line	1774	loadk        r25   k69 ; k69 = 218
.line	1774	loadk        r26   k70 ; k70 = 109
.line	1774	call          r8    19     2
.line	1774	call          r7     2     2
.line	1774	gettabup      r8    u0   k71 ; k71 = "pairs"
.line	1774	gettabup      r9    u0   k72 ; k72 = "CDataTable"
.line	1774	gettable      r9    r9   k73 ; k73 = "GetTable"
.line	1774	getupval     r10    u1
.line	1774	loadk        r11   k74 ; k74 = 19
.line	1774	loadk        r12   k75 ; k75 = 84
.line	1774	loadk        r13   k63 ; k63 = 222
.line	1774	loadk        r14   k46 ; k46 = 66
.line	1774	loadk        r15   k76 ; k76 = 183
.line	1774	loadk        r16   k77 ; k77 = 213
.line	1774	loadk        r17   k44 ; k44 = 32
.line	1774	loadk        r18   k78 ; k78 = 89
.line	1774	loadk        r19   k58 ; k58 = 187
.line	1774	loadk        r20   k79 ; k79 = 248
.line	1774	loadk        r21   k80 ; k80 = 107
.line	1774	loadk        r22   k81 ; k81 = 40
.line	1774	loadk        r23   k82 ; k82 = 254
.line	1774	loadk        r24   k27 ; k27 = 188
.line	1774	call         r10    15     2
.line	1774	call          r9     2     0
.line	1774	call          r8     0     4
.line	1774	jmp            0  l361
.line	1774	gettable     r13    r0   k37 ; k37 = "PetID"
.line	1774	gettable     r14   r12   k37 ; k37 = "PetID"
.line	1774	eq             0   r13   r14
.line	1774	jmp            0  l361
.line	1774	gettabup     r13    u0    k7 ; k7 = "print"
.line	1774	gettabup     r14    u0    k8 ; k8 = "bWriteLog"
.line	1774	test         r14     0
.line	1774	jmp            0  l305
.line	1774	gettabup     r14    u0   k42 ; k42 = "table"
.line	1774	gettable     r14   r14   k43 ; k43 = "concat"
.line	1774	newtable     r15     1     0
.line	1774	getupval     r16    u1
.line	1774	loadk        r17    k9 ; k9 = 18
.line	1774	loadk        r18   k10 ; k10 = 68
.line	1774	loadk        r19   k11 ; k11 = 195
.line	1774	loadk        r20   k12 ; k12 = 96
.line	1774	loadk        r21   k13 ; k13 = 191
.line	1774	loadk        r22   k14 ; k14 = 228
.line	1774	loadk        r23   k15 ; k15 = 49
.line	1774	loadk        r24   k16 ; k16 = 70
.line	1774	loadk        r25   k17 ; k17 = 167
.line	1774	loadk        r26   k18 ; k18 = 201
.line	1774	loadk        r27   k19 ; k19 = 121
.line	1774	loadk        r28   k20 ; k20 = 57
.line	1774	loadk        r29   k21 ; k21 = 251
.line	1774	loadk        r30   k22 ; k22 = 182
.line	1774	loadk        r31   k23 ; k23 = 126
.line	1774	loadk        r32   k24 ; k24 = 130
.line	1774	loadk        r33   k25 ; k25 = 225
.line	1774	loadk        r34   k26 ; k26 = 100
.line	1774	loadk        r35   k27 ; k27 = 188
.line	1774	loadk        r36   k28 ; k28 = 65
.line	1774	loadk        r37   k28 ; k28 = 65
.line	1774	loadk        r38   k29 ; k29 = 226
.line	1774	loadk        r39   k30 ; k30 = 81
.line	1774	loadk        r40   k31 ; k31 = 86
.line	1774	loadk        r41   k32 ; k32 = 160
.line	1774	loadk        r42   k33 ; k33 = 200
.line	1774	loadk        r43   k34 ; k34 = 83
.line	1774	loadk        r44   k35 ; k35 = 52
.line	1774	loadk        r45   k14 ; k14 = 228
.line	1774	loadk        r46   k36 ; k36 = 166
.line	1774	loadk        r47   k44 ; k44 = 32
.line	1774	loadk        r48   k83 ; k83 = 235
.line	1774	loadk        r49   k84 ; k84 = 194
.line	1774	loadk        r50   k85 ; k85 = 127
.line	1774	loadk        r51   k86 ; k86 = 154
.line	1774	loadk        r52   k87 ; k87 = 79
.line	1774	loadk        r53   k88 ; k88 = 85
.line	1774	loadk        r54   k79 ; k79 = 248
.line	1774	loadk        r55   k12 ; k12 = 96
.line	1774	loadk        r56   k89 ; k89 = 120
.line	1774	call         r16    41     2
.line	1774	getupval     r17    u1
.line	1774	loadk        r18   k90 ; k90 = 1
.line	1774	loadk        r19   k91 ; k91 = 80
.line	1774	loadk        r20   k63 ; k63 = 222
.line	1774	loadk        r21   k92 ; k92 = 119
.line	1774	loadk        r22   k93 ; k93 = 184
.line	1774	loadk        r23   k94 ; k94 = 196
.line	1774	call         r17     7     0
.line	1774	setlist      r15     0     1
.line	1774	call         r14     2     2
.label	l305
.line	1774	gettable     r15   r12   k95 ; k95 = "CanPlayInBattle"
.line	1774	move         r16    r4
.line	1774	call         r13     4     1
.line	1774	gettable     r13   r12   k95 ; k95 = "CanPlayInBattle"
.line	1774	eq             1   r13   k90 ; k90 = 1
.line	1774	jmp            0  l321
.line	1774	gettable     r13   r12   k95 ; k95 = "CanPlayInBattle"
.line	1774	eq             0   r13   k96 ; k96 = 2
.line	1774	jmp            0  l316
.line	1774	test          r4     0
.line	1774	jmp            0  l321
.label	l316
.line	1774	gettable     r13   r12   k95 ; k95 = "CanPlayInBattle"
.line	1774	eq             0   r13   k97 ; k97 = 3
.line	1774	jmp            0  l361
.line	1774	test          r4     0
.line	1774	jmp            0  l361
.label	l321
.line	1774	loadbool     r13     1     0
.line	1774	gettable     r14   r12   k98 ; k98 = "DependingClothesID"
.line	1774	test         r14     0
.line	1774	jmp            0  l347
.line	1774	gettable     r14   r12   k98 ; k98 = "DependingClothesID"
.line	1774	getupval     r15    u1
.line	1774	call         r15     1     2
.line	1774	eq             1   r14   r15
.line	1774	jmp            0  l347
.line	1774	gettable     r14    r7   k99 ; k99 = "Split"
.line	1774	gettable     r15   r12   k98 ; k98 = "DependingClothesID"
.line	1774	getupval     r16    u1
.line	1774	loadk        r17  k100 ; k100 = 63
.line	1774	call         r16     2     2
.line	1774	call         r14     3     2
.line	1774	test         r14     0
.line	1774	jmp            0  l347
.line	1774	gettabup     r15    u0  k101 ; k101 = "next"
.line	1774	move         r16   r14
.line	1774	call         r15     2     2
.line	1774	test         r15     0
.line	1774	jmp            0  l347
.line	1774	self         r15    r0  k102 ; k102 = "IsAvatarRequirementM" (truncated)
.line	1774	move         r17   r14
.line	1774	call         r15     3     2
.line	1774	move         r13   r15
.label	l347
.line	1774	test         r13     0
.line	1774	jmp            0  l361
.line	1774	gettabup     r14    u0   k42 ; k42 = "table"
.line	1774	gettable     r14   r14  k103 ; k103 = "insert"
.line	1774	gettable     r15    r0   k40 ; k40 = "CurPetExpressionList"
.line	1774	newtable     r16     0     4
.line	1774	gettable     r17   r12  k105 ; k105 = "PetActionID"
.line	1774	settable     r16  k104   r17 ; k104 = "ID"
.line	1774	settable     r16  k106  k107 ; k107 = true
.line	1774	gettable     r17   r12  k108 ; k108 = "SortKey"
.line	1774	settable     r16  k108   r17 ; k108 = "SortKey"
.line	1774	gettable     r17   r12  k109 ; k109 = "MasterSkillID"
.line	1774	settable     r16  k109   r17 ; k109 = "MasterSkillID"
.line	1774	call         r14     3     1
.label	l361
.line	1774	move          r0    r0
.line	1774	move          r0    r0
.line	1774	gettable      r8    r0   k40 ; k40 = "CurPetExpressionList"
.line	1774	len           r8    r8
.line	1774	le             0    r8   k41 ; k41 = 0
.line	1774	jmp            0  l368
.line	1774	return        r0     1
.label	l368
.line	1774	gettabup      r8    u0   k42 ; k42 = "table"
.line	1774	gettable      r8    r8  k110 ; k110 = "sort"
.line	1774	gettable      r9    r0   k40 ; k40 = "CurPetExpressionList"
.line	1774	closure      r10    f0
.line	1774	call          r8     3     1
.line	1774	mul           r8  k111    r1 ; k111 = 10000
.line	1774	add           r8    r8    r2
.line	1774	gettabup      r9    u0   k72 ; k72 = "CDataTable"
.line	1774	gettable      r9    r9  k112 ; k112 = "GetTableData"
.line	1774	getupval     r10    u1
.line	1774	loadk        r11   k74 ; k74 = 19
.line	1774	loadk        r12   k75 ; k75 = 84
.line	1774	loadk        r13   k63 ; k63 = 222
.line	1774	loadk        r14   k87 ; k87 = 79
.line	1774	loadk        r15  k113 ; k113 = 177
.line	1774	loadk        r16  k114 ; k114 = 215
.line	1774	loadk        r17   k52 ; k52 = 44
.line	1774	loadk        r18  k115 ; k115 = 90
.line	1774	loadk        r19  k116 ; k116 = 129
.line	1774	loadk        r20  k117 ; k117 = 205
.line	1774	loadk        r21  k118 ; k118 = 104
.line	1774	loadk        r22  k119 ; k119 = 38
.line	1774	loadk        r23  k120 ; k120 = 247
.line	1774	call         r10    14     2
.line	1774	move         r11    r8
.line	1774	call          r9     3     2
.line	1774	gettable     r10    r7   k99 ; k99 = "Split"
.line	1774	gettable     r11    r9  k121 ; k121 = "AllAction"
.line	1774	getupval     r12    u1
.line	1774	loadk        r13  k100 ; k100 = 63
.line	1774	call         r12     2     2
.line	1774	call         r10     3     2
.line	1774	closure      r11    f1
.line	1774	gettabup     r12    u0  k122 ; k122 = "pairs"
.line	1774	gettable     r13    r0   k40 ; k40 = "CurPetExpressionList"
.line	1774	call         r12     2     4
.line	1774	jmp            0  l410
.line	1774	move         r17   r11
.line	1774	gettable     r18   r16  k104 ; k104 = "ID"
.line	1774	call         r17     2     2
.line	1774	not          r17   r17
.line	1774	settable     r16  k106   r17 ; k106 = "IsLocked"
.label	l410
.line	1774	move          r0    r0
.line	1774	move          r0    r0
.line	1774	return        r0     1
.line	1774	move          r0    r0
.line	1774	move          r0    r0
.line	1774	return        r0     1

.function	main/f73/f0

.source	null
.linedefined	1826
.lastlinedefined	1828
.numparams	2
.is_vararg	0
.maxstacksize	4

.constant	k0	"SortKey"

.line	1826	gettable      r2    r0    k0 ; k0 = "SortKey"
.line	1826	gettable      r3    r1    k0 ; k0 = "SortKey"
.line	1826	lt             1    r2    r3
.line	1826	jmp            0    l6
.line	1826	loadbool      r2     0     1
.label	l6
.line	1826	loadbool      r2     1     0
.line	1826	return        r2     2
.line	1826	return        r0     1
.line	1826	move          r0    r0
.line	1826	move          r0    r0
.line	1826	move          r0    r0
.line	1826	return        r0     1

.function	main/f73/f1

.source	null
.linedefined	1832
.lastlinedefined	1840
.numparams	1
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	10	true
.upvalue	"U1"	0	false

.constant	k0	0
.constant	k1	"pairs"
.constant	k2	"tonumber"

.line	1832	getupval      r1    u0
.line	1832	test          r1     0
.line	1832	jmp            0   l21
.line	1832	getupval      r1    u0
.line	1832	len           r1    r1
.line	1832	lt             0    k0    r1 ; k0 = 0
.line	1832	jmp            0   l21
.line	1832	gettabup      r1    u1    k1 ; k1 = "pairs"
.line	1832	getupval      r2    u0
.line	1832	call          r1     2     4
.line	1832	jmp            0   l19
.line	1832	gettabup      r6    u1    k2 ; k2 = "tonumber"
.line	1832	move          r7    r5
.line	1832	call          r6     2     2
.line	1832	eq             0    r0    r6
.line	1832	jmp            0   l19
.line	1832	loadbool      r6     1     0
.line	1832	return        r6     2
.label	l19
.line	1832	move          r0    r0
.line	1832	move          r0    r0
.label	l21
.line	1832	return        r0     1
.line	1832	move          r0    r0
.line	1832	move          r0    r0
.line	1832	return        r0     1

.function	main/f74

.source	null
.linedefined	1846
.lastlinedefined	1867
.numparams	1
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false

.constant	k0	"slua_GameFrontendHUD"
.constant	k1	"GetPlayerController"
.constant	k2	"slua"
.constant	k3	"isValid"
.constant	k4	"IsInPetSpectator"
.constant	k5	"GetPetSpectatorComp"
.constant	k6	"GetPetInfo"
.constant	k7	"GetCurrentSpectatorPetID"
.constant	k8	"PetID"
.constant	k9	"PetLevel"
.constant	k10	"GetPlayerCharacterSafety"
.constant	k11	"PetComponent_BP"
.constant	k12	"PetPawn"
.constant	k13	"PetLevelInfo"
.constant	k14	"PetId"

.line	1846	gettabup      r1    u0    k0 ; k0 = "slua_GameFrontendHUD"
.line	1846	self          r1    r1    k1 ; k1 = "GetPlayerController"
.line	1846	call          r1     2     2
.line	1846	test          r1     0
.line	1846	jmp            0   l12
.line	1846	gettabup      r2    u0    k2 ; k2 = "slua"
.line	1846	gettable      r2    r2    k3 ; k3 = "isValid"
.line	1846	move          r3    r1
.line	1846	call          r2     2     2
.line	1846	test          r2     1
.line	1846	jmp            0   l13
.label	l12
.line	1846	return        r0     1
.label	l13
.line	1846	gettable      r2    r1    k4 ; k4 = "IsInPetSpectator"
.line	1846	test          r2     0
.line	1846	jmp            0   l37
.line	1846	self          r2    r1    k4 ; k4 = "IsInPetSpectator"
.line	1846	call          r2     2     2
.line	1846	test          r2     0
.line	1846	jmp            0   l37
.line	1846	self          r2    r1    k5 ; k5 = "GetPetSpectatorComp"
.line	1846	call          r2     2     2
.line	1846	gettabup      r3    u0    k2 ; k2 = "slua"
.line	1846	gettable      r3    r3    k3 ; k3 = "isValid"
.line	1846	move          r4    r2
.line	1846	call          r3     2     2
.line	1846	test          r3     0
.line	1846	jmp            0   l37
.line	1846	self          r3    r2    k6 ; k6 = "GetPetInfo"
.line	1846	self          r5    r2    k7 ; k7 = "GetCurrentSpectatorP" (truncated)
.line	1846	call          r5     2     0
.line	1846	call          r3     0     2
.line	1846	test          r3     0
.line	1846	jmp            0   l37
.line	1846	gettable      r4    r3    k8 ; k8 = "PetID"
.line	1846	gettable      r5    r3    k9 ; k9 = "PetLevel"
.line	1846	return        r4     3
.label	l37
.line	1846	self          r2    r1   k10 ; k10 = "GetPlayerCharacterSa" (truncated)
.line	1846	call          r2     2     2
.line	1846	gettabup      r3    u0    k2 ; k2 = "slua"
.line	1846	gettable      r3    r3    k3 ; k3 = "isValid"
.line	1846	move          r4    r2
.line	1846	call          r3     2     2
.line	1846	test          r3     0
.line	1846	jmp            0   l67
.line	1846	gettabup      r3    u0    k2 ; k2 = "slua"
.line	1846	gettable      r3    r3    k3 ; k3 = "isValid"
.line	1846	gettable      r4    r2   k11 ; k11 = "PetComponent_BP"
.line	1846	call          r3     2     2
.line	1846	test          r3     0
.line	1846	jmp            0   l67
.line	1846	gettabup      r3    u0    k2 ; k2 = "slua"
.line	1846	gettable      r3    r3    k3 ; k3 = "isValid"
.line	1846	gettable      r4    r2   k11 ; k11 = "PetComponent_BP"
.line	1846	gettable      r4    r4   k12 ; k12 = "PetPawn"
.line	1846	call          r3     2     2
.line	1846	test          r3     0
.line	1846	jmp            0   l67
.line	1846	gettable      r3    r2   k11 ; k11 = "PetComponent_BP"
.line	1846	gettable      r3    r3   k12 ; k12 = "PetPawn"
.line	1846	gettable      r4    r3   k13 ; k13 = "PetLevelInfo"
.line	1846	gettable      r4    r4   k14 ; k14 = "PetId"
.line	1846	gettable      r5    r3   k13 ; k13 = "PetLevelInfo"
.line	1846	gettable      r5    r5    k9 ; k9 = "PetLevel"
.line	1846	move          r6    r4
.line	1846	move          r7    r5
.line	1846	return        r6     3
.label	l67
.line	1846	return        r0     1
.line	1846	move          r0    r0
.line	1846	return        r0     1

.function	main/f75

.source	null
.linedefined	1869
.lastlinedefined	1889
.numparams	1
.is_vararg	0
.maxstacksize	19

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"slua_GameFrontendHUD"
.constant	k1	"GetPlayerController"
.constant	k2	"slua"
.constant	k3	"isValid"
.constant	k4	"IsInPetSpectator"
.constant	k5	"GetPetSpectatorComp"
.constant	k6	"GetPetInfo"
.constant	k7	"GetCurrentSpectatorPetID"
.constant	k8	"ModuleManager"
.constant	k9	"GetModule"
.constant	k10	"CommonModuleConfig"
.constant	k11	"SettingModule"
.constant	k12	"GetPlayerCharacterSafety"
.constant	k13	"IsFPP"
.constant	k14	"GetOptionValue"
.constant	k15	12
.constant	k16	65
.constant	k17	207
.constant	k18	109
.constant	k19	153
.constant	k20	216
.constant	k21	25
.constant	k22	83
.constant	k23	161
.constant	k24	234
.constant	k25	90
.constant	k26	26

.line	1869	gettabup      r1    u0    k0 ; k0 = "slua_GameFrontendHUD"
.line	1869	self          r1    r1    k1 ; k1 = "GetPlayerController"
.line	1869	call          r1     2     2
.line	1869	gettabup      r2    u0    k2 ; k2 = "slua"
.line	1869	gettable      r2    r2    k3 ; k3 = "isValid"
.line	1869	move          r3    r1
.line	1869	call          r2     2     2
.line	1869	test          r2     0
.line	1869	jmp            0   l33
.line	1869	gettable      r2    r1    k4 ; k4 = "IsInPetSpectator"
.line	1869	test          r2     0
.line	1869	jmp            0   l33
.line	1869	self          r2    r1    k4 ; k4 = "IsInPetSpectator"
.line	1869	call          r2     2     2
.line	1869	test          r2     0
.line	1869	jmp            0   l33
.line	1869	self          r2    r1    k5 ; k5 = "GetPetSpectatorComp"
.line	1869	call          r2     2     2
.line	1869	gettabup      r3    u0    k2 ; k2 = "slua"
.line	1869	gettable      r3    r3    k3 ; k3 = "isValid"
.line	1869	move          r4    r2
.line	1869	call          r3     2     2
.line	1869	test          r3     0
.line	1869	jmp            0   l33
.line	1869	self          r3    r2    k6 ; k6 = "GetPetInfo"
.line	1869	self          r5    r2    k7 ; k7 = "GetCurrentSpectatorP" (truncated)
.line	1869	call          r5     2     0
.line	1869	call          r3     0     2
.line	1869	test          r3     0
.line	1869	jmp            0   l33
.line	1869	loadbool      r3     1     0
.line	1869	return        r3     2
.label	l33
.line	1869	gettabup      r2    u0    k8 ; k8 = "ModuleManager"
.line	1869	gettable      r2    r2    k9 ; k9 = "GetModule"
.line	1869	gettabup      r3    u0    k8 ; k8 = "ModuleManager"
.line	1869	gettable      r3    r3   k10 ; k10 = "CommonModuleConfig"
.line	1869	gettable      r3    r3   k11 ; k11 = "SettingModule"
.line	1869	call          r2     2     2
.line	1869	gettabup      r3    u0    k2 ; k2 = "slua"
.line	1869	gettable      r3    r3    k3 ; k3 = "isValid"
.line	1869	move          r4    r1
.line	1869	call          r3     2     2
.line	1869	test          r3     0
.line	1869	jmp            0   l84
.line	1869	self          r3    r1   k12 ; k12 = "GetPlayerCharacterSa" (truncated)
.line	1869	call          r3     2     2
.line	1869	test          r3     0
.line	1869	jmp            0   l84
.line	1869	gettable      r4    r3   k13 ; k13 = "IsFPP"
.line	1869	test          r4     0
.line	1869	jmp            0   l70
.line	1869	self          r4    r2   k14 ; k14 = "GetOptionValue"
.line	1869	getupval      r6    u1
.line	1869	loadk         r7   k15 ; k15 = 12
.line	1869	loadk         r8   k16 ; k16 = 65
.line	1869	loadk         r9   k17 ; k17 = 207
.line	1869	loadk        r10   k18 ; k18 = 109
.line	1869	loadk        r11   k19 ; k19 = 153
.line	1869	loadk        r12   k20 ; k20 = 216
.line	1869	loadk        r13   k21 ; k21 = 25
.line	1869	loadk        r14   k22 ; k22 = 83
.line	1869	loadk        r15   k23 ; k23 = 161
.line	1869	loadk        r16   k24 ; k24 = 234
.line	1869	loadk        r17   k25 ; k25 = 90
.line	1869	loadk        r18   k26 ; k26 = 26
.line	1869	call          r6    13     2
.line	1869	tailcall      r4     3
.line	1869	return        r4     0
.line	1869	jmp            0   l84
.label	l70
.line	1869	self          r4    r2   k14 ; k14 = "GetOptionValue"
.line	1869	getupval      r6    u1
.line	1869	loadk         r7   k15 ; k15 = 12
.line	1869	loadk         r8   k16 ; k16 = 65
.line	1869	loadk         r9   k17 ; k17 = 207
.line	1869	loadk        r10   k18 ; k18 = 109
.line	1869	loadk        r11   k19 ; k19 = 153
.line	1869	loadk        r12   k20 ; k20 = 216
.line	1869	loadk        r13   k21 ; k21 = 25
.line	1869	loadk        r14   k22 ; k22 = 83
.line	1869	loadk        r15   k23 ; k23 = 161
.line	1869	call          r6    10     2
.line	1869	tailcall      r4     3
.line	1869	return        r4     0
.label	l84
.line	1869	loadbool      r3     0     0
.line	1869	return        r3     2
.line	1869	return        r0     1
.line	1869	move          r0    r0
.line	1869	move          r0    r0
.line	1869	move          r0    r0
.line	1869	move          r0    r0
.line	1869	return        r0     1

.function	main/f76

.source	null
.linedefined	1891
.lastlinedefined	1898
.numparams	1
.is_vararg	0
.maxstacksize	18

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"import"
.constant	k1	4
.constant	k2	80
.constant	k3	199
.constant	k4	102
.constant	k5	164
.constant	k6	205
.constant	k7	40
.constant	k8	79
.constant	k9	134
.constant	k10	216
.constant	k11	107
.constant	k12	62
.constant	k13	251
.constant	k14	186
.constant	k15	99
.constant	k16	"GetGameState"
.constant	k17	"slua"
.constant	k18	"isValid"
.constant	k19	"IsNonePlayerOnIsland"

.line	1891	gettabup      r1    u0    k0 ; k0 = "import"
.line	1891	getupval      r2    u1
.line	1891	loadk         r3    k1 ; k1 = 4
.line	1891	loadk         r4    k2 ; k2 = 80
.line	1891	loadk         r5    k3 ; k3 = 199
.line	1891	loadk         r6    k4 ; k4 = 102
.line	1891	loadk         r7    k5 ; k5 = 164
.line	1891	loadk         r8    k6 ; k6 = 205
.line	1891	loadk         r9    k7 ; k7 = 40
.line	1891	loadk        r10    k8 ; k8 = 79
.line	1891	loadk        r11    k9 ; k9 = 134
.line	1891	loadk        r12   k10 ; k10 = 216
.line	1891	loadk        r13   k11 ; k11 = 107
.line	1891	loadk        r14   k12 ; k12 = 62
.line	1891	loadk        r15   k13 ; k13 = 251
.line	1891	loadk        r16   k14 ; k14 = 186
.line	1891	loadk        r17   k15 ; k15 = 99
.line	1891	call          r2    16     2
.line	1891	call          r1     2     2
.line	1891	gettable      r2    r1   k16 ; k16 = "GetGameState"
.line	1891	move          r3    r0
.line	1891	call          r2     2     2
.line	1891	gettabup      r3    u0   k17 ; k17 = "slua"
.line	1891	gettable      r3    r3   k18 ; k18 = "isValid"
.line	1891	move          r4    r2
.line	1891	call          r3     2     2
.line	1891	test          r3     0
.line	1891	jmp            0   l34
.line	1891	gettable      r3    r2   k19 ; k19 = "IsNonePlayerOnIsland"
.line	1891	test          r3     0
.line	1891	jmp            0   l34
.line	1891	loadbool      r3     1     0
.line	1891	return        r3     2
.label	l34
.line	1891	loadbool      r3     0     0
.line	1891	return        r3     2
.line	1891	return        r0     1
.line	1891	move          r0    r0
.line	1891	move          r0    r0
.line	1891	move          r0    r0
.line	1891	return        r0     1

.function	main/f77

.source	null
.linedefined	1900
.lastlinedefined	1902
.numparams	1
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	false

.constant	k0	"GameStatus"
.constant	k1	"IsInMainCity"

.line	1900	gettabup      r1    u0    k0 ; k0 = "GameStatus"
.line	1900	gettable      r1    r1    k1 ; k1 = "IsInMainCity"
.line	1900	tailcall      r1     1
.line	1900	return        r1     0
.line	1900	return        r0     1
.line	1900	move          r0    r0
.line	1900	return        r0     1

.function	main/f78

.source	null
.linedefined	1904
.lastlinedefined	1924
.numparams	2
.is_vararg	0
.maxstacksize	16

.upvalue	"_ENV"	0	false

.constant	k0	"next"
.constant	k1	"slua_GameFrontendHUD"
.constant	k2	"GetPlayerController"
.constant	k3	"slua"
.constant	k4	"isValid"
.constant	k5	"GetCurrentPetInfo"
.constant	k6	"PetAvatarList"
.constant	k7	"pairs"
.constant	k8	"tostring"

.line	1904	test          r1     0
.line	1904	jmp            0    l8
.line	1904	gettabup      r2    u0    k0 ; k0 = "next"
.line	1904	move          r3    r1
.line	1904	call          r2     2     2
.line	1904	test          r2     1
.line	1904	jmp            0   l10
.label	l8
.line	1904	loadbool      r2     1     0
.line	1904	return        r2     2
.label	l10
.line	1904	loadnil       r2     0
.line	1904	gettabup      r3    u0    k1 ; k1 = "slua_GameFrontendHUD"
.line	1904	self          r3    r3    k2 ; k2 = "GetPlayerController"
.line	1904	call          r3     2     2
.line	1904	gettabup      r4    u0    k3 ; k3 = "slua"
.line	1904	gettable      r4    r4    k4 ; k4 = "isValid"
.line	1904	move          r5    r3
.line	1904	call          r4     2     2
.line	1904	test          r4     0
.line	1904	jmp            0   l23
.line	1904	self          r4    r3    k5 ; k5 = "GetCurrentPetInfo"
.line	1904	call          r4     2     2
.line	1904	move          r2    r4
.label	l23
.line	1904	test          r2     0
.line	1904	jmp            0   l47
.line	1904	gettable      r4    r2    k6 ; k6 = "PetAvatarList"
.line	1904	test          r4     0
.line	1904	jmp            0   l47
.line	1904	gettabup      r4    u0    k7 ; k7 = "pairs"
.line	1904	gettable      r5    r2    k6 ; k6 = "PetAvatarList"
.line	1904	call          r4     2     4
.line	1904	jmp            0   l45
.line	1904	gettabup      r9    u0    k8 ; k8 = "tostring"
.line	1904	move         r10    r8
.line	1904	call          r9     2     2
.line	1904	gettabup     r10    u0    k7 ; k7 = "pairs"
.line	1904	move         r11    r1
.line	1904	call         r10     2     4
.line	1904	jmp            0   l43
.line	1904	eq             0    r9   r14
.line	1904	jmp            0   l43
.line	1904	loadbool     r15     1     0
.line	1904	return       r15     2
.label	l43
.line	1904	move          r0    r0
.line	1904	move          r0    r0
.label	l45
.line	1904	move          r0    r0
.line	1904	move          r0    r0
.label	l47
.line	1904	loadbool      r4     0     0
.line	1904	return        r4     2
.line	1904	return        r0     1
.line	1904	move          r0    r0
.line	1904	move          r0    r0
.line	1904	move          r0    r0
.line	1904	move          r0    r0
.line	1904	return        r0     1

.function	main/f79

.source	null
.linedefined	1926
.lastlinedefined	1950
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	23	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"CurrentShowState"
.constant	k1	"Bubble"
.constant	k2	"MiniTvExpression"
.constant	k3	"CanvasPanel_SubTypeSwitch"
.constant	k4	"SetWidgetVisibility"
.constant	k5	"UEnums"
.constant	k6	"ESlateVisibility"
.constant	k7	"Collapsed"
.constant	k8	"require"
.constant	k9	"table"
.constant	k10	"concat"
.constant	k11	32
.constant	k12	93
.constant	k13	195
.constant	k14	102
.constant	k15	186
.constant	k16	213
.constant	k17	103
.constant	k18	69
.constant	k19	185
.constant	k20	217
.constant	k21	107
.constant	k22	100
.constant	k23	241
.constant	k24	182
.constant	k25	126
.constant	k26	222
.constant	k27	218
.constant	k28	244
.constant	k29	112
.constant	k30	72
.constant	k31	248
.constant	k32	92
.constant	k33	104
.constant	k34	177
.constant	k35	123
.constant	k36	57
.constant	k37	240
.constant	k38	166
.constant	k39	115
.constant	k40	134
.constant	k41	243
.constant	k42	168
.constant	k43	79
.constant	k44	242
.constant	k45	65
.constant	k46	68
.constant	k47	38
.constant	k48	86
.constant	k49	108
.constant	k50	236
.constant	k51	40
.constant	k52	85
.constant	k53	167
.constant	k54	121
.constant	k55	"IsBlueholeOperationRegion"
.constant	k56	"Collection"
.constant	k57	"Flaunt"
.constant	k58	"SelfHitTestInvisible"
.constant	k59	"Expression"
.constant	k60	"NeedHidePetExpression"
.constant	k61	"WidgetSwitcher_1"
.constant	k62	"SetActiveWidgetIndex"
.constant	k63	0
.constant	k64	"PetExpression"
.constant	k65	1
.constant	k66	2
.constant	k67	3

.line	1926	gettable      r1    r0    k0 ; k0 = "CurrentShowState"
.line	1926	gettabup      r2    u0    k1 ; k1 = "Bubble"
.line	1926	eq             1    r1    r2
.line	1926	jmp            0    l9
.line	1926	gettable      r1    r0    k0 ; k0 = "CurrentShowState"
.line	1926	gettabup      r2    u0    k2 ; k2 = "MiniTvExpression"
.line	1926	eq             0    r1    r2
.line	1926	jmp            0   l16
.label	l9
.line	1926	gettable      r1    r0    k3 ; k3 = "CanvasPanel_SubTypeS" (truncated)
.line	1926	self          r1    r1    k4 ; k4 = "SetWidgetVisibility"
.line	1926	gettabup      r3    u1    k5 ; k5 = "UEnums"
.line	1926	gettable      r3    r3    k6 ; k6 = "ESlateVisibility"
.line	1926	gettable      r3    r3    k7 ; k7 = "Collapsed"
.line	1926	call          r1     3     1
.line	1926	return        r0     1
.label	l16
.line	1926	gettabup      r1    u1    k8 ; k8 = "require"
.line	1926	gettabup      r2    u1    k9 ; k9 = "table"
.line	1926	gettable      r2    r2   k10 ; k10 = "concat"
.line	1926	newtable      r3     1     0
.line	1926	getupval      r4    u2
.line	1926	loadk         r5   k11 ; k11 = 32
.line	1926	loadk         r6   k12 ; k12 = 93
.line	1926	loadk         r7   k13 ; k13 = 195
.line	1926	loadk         r8   k14 ; k14 = 102
.line	1926	loadk         r9   k15 ; k15 = 186
.line	1926	loadk        r10   k16 ; k16 = 213
.line	1926	loadk        r11   k17 ; k17 = 103
.line	1926	loadk        r12   k18 ; k18 = 69
.line	1926	loadk        r13   k19 ; k19 = 185
.line	1926	loadk        r14   k20 ; k20 = 217
.line	1926	loadk        r15   k21 ; k21 = 107
.line	1926	loadk        r16   k22 ; k22 = 100
.line	1926	loadk        r17   k23 ; k23 = 241
.line	1926	loadk        r18   k24 ; k24 = 182
.line	1926	loadk        r19   k25 ; k25 = 126
.line	1926	loadk        r20   k26 ; k26 = 222
.line	1926	loadk        r21   k27 ; k27 = 218
.line	1926	loadk        r22   k14 ; k14 = 102
.line	1926	loadk        r23   k28 ; k28 = 244
.line	1926	loadk        r24   k29 ; k29 = 112
.line	1926	loadk        r25   k30 ; k30 = 72
.line	1926	loadk        r26   k31 ; k31 = 248
.line	1926	loadk        r27   k32 ; k32 = 92
.line	1926	loadk        r28   k33 ; k33 = 104
.line	1926	loadk        r29   k34 ; k34 = 177
.line	1926	loadk        r30   k23 ; k23 = 241
.line	1926	loadk        r31   k35 ; k35 = 123
.line	1926	loadk        r32   k36 ; k36 = 57
.line	1926	loadk        r33   k37 ; k37 = 240
.line	1926	loadk        r34   k38 ; k38 = 166
.line	1926	loadk        r35   k39 ; k39 = 115
.line	1926	loadk        r36   k40 ; k40 = 134
.line	1926	loadk        r37   k41 ; k41 = 243
.line	1926	loadk        r38   k22 ; k22 = 100
.line	1926	loadk        r39   k42 ; k42 = 168
.line	1926	loadk        r40   k43 ; k43 = 79
.line	1926	loadk        r41   k12 ; k12 = 93
.line	1926	loadk        r42   k44 ; k44 = 242
.line	1926	loadk        r43   k45 ; k45 = 65
.line	1926	loadk        r44   k46 ; k46 = 68
.line	1926	call          r4    41     2
.line	1926	getupval      r5    u2
.line	1926	loadk         r6   k47 ; k47 = 38
.line	1926	loadk         r7   k48 ; k48 = 86
.line	1926	loadk         r8   k13 ; k13 = 195
.line	1926	loadk         r9   k49 ; k49 = 108
.line	1926	loadk        r10   k15 ; k15 = 186
.line	1926	loadk        r11   k50 ; k50 = 236
.line	1926	loadk        r12   k51 ; k51 = 40
.line	1926	loadk        r13   k52 ; k52 = 85
.line	1926	loadk        r14   k53 ; k53 = 167
.line	1926	loadk        r15   k13 ; k13 = 195
.line	1926	loadk        r16   k54 ; k54 = 121
.line	1926	call          r5    12     0
.line	1926	setlist       r3     0     1
.line	1926	call          r2     2     2
.line	1926	call          r1     2     2
.line	1926	gettable      r2    r1   k55 ; k55 = "IsBlueholeOperationR" (truncated)
.line	1926	call          r2     1     2
.line	1926	test          r2     0
.line	1926	jmp            0   l97
.line	1926	gettable      r2    r0    k0 ; k0 = "CurrentShowState"
.line	1926	gettabup      r3    u0   k56 ; k56 = "Collection"
.line	1926	eq             1    r2    r3
.line	1926	jmp            0   l90
.line	1926	gettable      r2    r0    k0 ; k0 = "CurrentShowState"
.line	1926	gettabup      r3    u0   k57 ; k57 = "Flaunt"
.line	1926	eq             0    r2    r3
.line	1926	jmp            0   l97
.label	l90
.line	1926	gettable      r2    r0    k3 ; k3 = "CanvasPanel_SubTypeS" (truncated)
.line	1926	self          r2    r2    k4 ; k4 = "SetWidgetVisibility"
.line	1926	gettabup      r4    u1    k5 ; k5 = "UEnums"
.line	1926	gettable      r4    r4    k6 ; k6 = "ESlateVisibility"
.line	1926	gettable      r4    r4    k7 ; k7 = "Collapsed"
.line	1926	call          r2     3     1
.line	1926	return        r0     1
.label	l97
.line	1926	gettable      r2    r0    k3 ; k3 = "CanvasPanel_SubTypeS" (truncated)
.line	1926	self          r2    r2    k4 ; k4 = "SetWidgetVisibility"
.line	1926	gettabup      r4    u1    k5 ; k5 = "UEnums"
.line	1926	gettable      r4    r4    k6 ; k6 = "ESlateVisibility"
.line	1926	gettable      r4    r4   k58 ; k58 = "SelfHitTestInvisible"
.line	1926	call          r2     3     1
.line	1926	gettable      r2    r0    k0 ; k0 = "CurrentShowState"
.line	1926	gettabup      r3    u0   k59 ; k59 = "Expression"
.line	1926	eq             0    r2    r3
.line	1926	jmp            0  l123
.line	1926	self          r2    r0   k60 ; k60 = "NeedHidePetExpressio" (truncated)
.line	1926	call          r2     2     2
.line	1926	test          r2     0
.line	1926	jmp            0  l118
.line	1926	gettable      r2    r0    k3 ; k3 = "CanvasPanel_SubTypeS" (truncated)
.line	1926	self          r2    r2    k4 ; k4 = "SetWidgetVisibility"
.line	1926	gettabup      r4    u1    k5 ; k5 = "UEnums"
.line	1926	gettable      r4    r4    k6 ; k6 = "ESlateVisibility"
.line	1926	gettable      r4    r4    k7 ; k7 = "Collapsed"
.line	1926	call          r2     3     1
.line	1926	jmp            0  l149
.label	l118
.line	1926	gettable      r2    r0   k61 ; k61 = "WidgetSwitcher_1"
.line	1926	self          r2    r2   k62 ; k62 = "SetActiveWidgetIndex"
.line	1926	loadk         r4   k63 ; k63 = 0
.line	1926	call          r2     3     1
.line	1926	jmp            0  l149
.label	l123
.line	1926	gettable      r2    r0    k0 ; k0 = "CurrentShowState"
.line	1926	gettabup      r3    u0   k64 ; k64 = "PetExpression"
.line	1926	eq             0    r2    r3
.line	1926	jmp            0  l132
.line	1926	gettable      r2    r0   k61 ; k61 = "WidgetSwitcher_1"
.line	1926	self          r2    r2   k62 ; k62 = "SetActiveWidgetIndex"
.line	1926	loadk         r4   k65 ; k65 = 1
.line	1926	call          r2     3     1
.line	1926	jmp            0  l149
.label	l132
.line	1926	gettable      r2    r0    k0 ; k0 = "CurrentShowState"
.line	1926	gettabup      r3    u0   k56 ; k56 = "Collection"
.line	1926	eq             0    r2    r3
.line	1926	jmp            0  l141
.line	1926	gettable      r2    r0   k61 ; k61 = "WidgetSwitcher_1"
.line	1926	self          r2    r2   k62 ; k62 = "SetActiveWidgetIndex"
.line	1926	loadk         r4   k66 ; k66 = 2
.line	1926	call          r2     3     1
.line	1926	jmp            0  l149
.label	l141
.line	1926	gettable      r2    r0    k0 ; k0 = "CurrentShowState"
.line	1926	gettabup      r3    u0   k57 ; k57 = "Flaunt"
.line	1926	eq             0    r2    r3
.line	1926	jmp            0  l149
.line	1926	gettable      r2    r0   k61 ; k61 = "WidgetSwitcher_1"
.line	1926	self          r2    r2   k62 ; k62 = "SetActiveWidgetIndex"
.line	1926	loadk         r4   k67 ; k67 = 3
.line	1926	call          r2     3     1
.label	l149
.line	1926	return        r0     1
.line	1926	move          r0    r0
.line	1926	return        r0     1

.function	main/f80

.source	null
.linedefined	1952
.lastlinedefined	1968
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	23	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	18
.constant	k5	68
.constant	k6	195
.constant	k7	96
.constant	k8	191
.constant	k9	228
.constant	k10	49
.constant	k11	70
.constant	k12	167
.constant	k13	201
.constant	k14	121
.constant	k15	57
.constant	k16	251
.constant	k17	182
.constant	k18	126
.constant	k19	130
.constant	k20	252
.constant	k21	111
.constant	k22	152
.constant	k23	80
.constant	k24	229
.constant	k25	86
.constant	k26	104
.constant	k27	150
.constant	k28	120
.constant	k29	14
.constant	k30	185
.constant	k31	101
.constant	k32	212
.constant	k33	190
.constant	k34	64
.constant	k35	92
.constant	k36	194
.constant	k37	69
.constant	k38	127
.constant	k39	32
.constant	k40	90
.constant	k41	"CurrentShowState"
.constant	k42	"Expression"
.constant	k43	"PetExpression"
.constant	k44	"WidgetSwitcher_EmoteOrPet"
.constant	k45	"SetActiveWidgetIndex"
.constant	k46	1
.constant	k47	0
.constant	k48	"Collection"
.constant	k49	"Flaunt"
.constant	k50	"WidgetSwitcher_CollectionOrFlaunt"
.constant	k51	"RefreshCirclePanel"

.line	1952	gettabup      r1    u0    k0 ; k0 = "print"
.line	1952	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1952	test          r2     0
.line	1952	jmp            0   l56
.line	1952	gettabup      r2    u0    k2 ; k2 = "table"
.line	1952	gettable      r2    r2    k3 ; k3 = "concat"
.line	1952	newtable      r3     1     0
.line	1952	getupval      r4    u1
.line	1952	loadk         r5    k4 ; k4 = 18
.line	1952	loadk         r6    k5 ; k5 = 68
.line	1952	loadk         r7    k6 ; k6 = 195
.line	1952	loadk         r8    k7 ; k7 = 96
.line	1952	loadk         r9    k8 ; k8 = 191
.line	1952	loadk        r10    k9 ; k9 = 228
.line	1952	loadk        r11   k10 ; k10 = 49
.line	1952	loadk        r12   k11 ; k11 = 70
.line	1952	loadk        r13   k12 ; k12 = 167
.line	1952	loadk        r14   k13 ; k13 = 201
.line	1952	loadk        r15   k14 ; k14 = 121
.line	1952	loadk        r16   k15 ; k15 = 57
.line	1952	loadk        r17   k16 ; k16 = 251
.line	1952	loadk        r18   k17 ; k17 = 182
.line	1952	loadk        r19   k18 ; k18 = 126
.line	1952	loadk        r20   k19 ; k19 = 130
.line	1952	loadk        r21   k20 ; k20 = 252
.line	1952	loadk        r22   k21 ; k21 = 111
.line	1952	loadk        r23   k22 ; k22 = 152
.line	1952	loadk        r24   k11 ; k11 = 70
.line	1952	loadk        r25   k23 ; k23 = 80
.line	1952	loadk        r26   k24 ; k24 = 229
.line	1952	loadk        r27   k25 ; k25 = 86
.line	1952	loadk        r28   k26 ; k26 = 104
.line	1952	loadk        r29   k27 ; k27 = 150
.line	1952	loadk        r30   k13 ; k13 = 201
.line	1952	loadk        r31   k28 ; k28 = 120
.line	1952	loadk        r32   k29 ; k29 = 14
.line	1952	loadk        r33   k16 ; k16 = 251
.line	1952	loadk        r34   k30 ; k30 = 185
.line	1952	loadk        r35   k31 ; k31 = 101
.line	1952	loadk        r36   k16 ; k16 = 251
.line	1952	loadk        r37   k32 ; k32 = 212
.line	1952	loadk        r38   k28 ; k28 = 120
.line	1952	loadk        r39   k33 ; k33 = 190
.line	1952	loadk        r40   k34 ; k34 = 64
.line	1952	loadk        r41   k35 ; k35 = 92
.line	1952	loadk        r42   k36 ; k36 = 194
.line	1952	loadk        r43   k37 ; k37 = 69
.line	1952	loadk        r44   k38 ; k38 = 127
.line	1952	call          r4    41     2
.line	1952	getupval      r5    u1
.line	1952	loadk         r6   k39 ; k39 = 32
.line	1952	loadk         r7   k40 ; k40 = 90
.line	1952	call          r5     3     0
.line	1952	setlist       r3     0     1
.line	1952	call          r2     2     2
.label	l56
.line	1952	gettable      r3    r0   k41 ; k41 = "CurrentShowState"
.line	1952	call          r1     3     1
.line	1952	gettable      r1    r0   k41 ; k41 = "CurrentShowState"
.line	1952	gettabup      r2    u2   k42 ; k42 = "Expression"
.line	1952	eq             0    r1    r2
.line	1952	jmp            0   l69
.line	1952	gettabup      r1    u2   k43 ; k43 = "PetExpression"
.line	1952	settable      r0   k41    r1 ; k41 = "CurrentShowState"
.line	1952	gettable      r1    r0   k44 ; k44 = "WidgetSwitcher_Emote" (truncated)
.line	1952	self          r1    r1   k45 ; k45 = "SetActiveWidgetIndex"
.line	1952	loadk         r3   k46 ; k46 = 1
.line	1952	call          r1     3     1
.line	1952	jmp            0  l101
.label	l69
.line	1952	gettable      r1    r0   k41 ; k41 = "CurrentShowState"
.line	1952	gettabup      r2    u2   k43 ; k43 = "PetExpression"
.line	1952	eq             0    r1    r2
.line	1952	jmp            0   l80
.line	1952	gettabup      r1    u2   k42 ; k42 = "Expression"
.line	1952	settable      r0   k41    r1 ; k41 = "CurrentShowState"
.line	1952	gettable      r1    r0   k44 ; k44 = "WidgetSwitcher_Emote" (truncated)
.line	1952	self          r1    r1   k45 ; k45 = "SetActiveWidgetIndex"
.line	1952	loadk         r3   k47 ; k47 = 0
.line	1952	call          r1     3     1
.line	1952	jmp            0  l101
.label	l80
.line	1952	gettable      r1    r0   k41 ; k41 = "CurrentShowState"
.line	1952	gettabup      r2    u2   k48 ; k48 = "Collection"
.line	1952	eq             0    r1    r2
.line	1952	jmp            0   l91
.line	1952	gettabup      r1    u2   k49 ; k49 = "Flaunt"
.line	1952	settable      r0   k41    r1 ; k41 = "CurrentShowState"
.line	1952	gettable      r1    r0   k50 ; k50 = "WidgetSwitcher_Colle" (truncated)
.line	1952	self          r1    r1   k45 ; k45 = "SetActiveWidgetIndex"
.line	1952	loadk         r3   k46 ; k46 = 1
.line	1952	call          r1     3     1
.line	1952	jmp            0  l101
.label	l91
.line	1952	gettable      r1    r0   k41 ; k41 = "CurrentShowState"
.line	1952	gettabup      r2    u2   k49 ; k49 = "Flaunt"
.line	1952	eq             0    r1    r2
.line	1952	jmp            0  l101
.line	1952	gettabup      r1    u2   k48 ; k48 = "Collection"
.line	1952	settable      r0   k41    r1 ; k41 = "CurrentShowState"
.line	1952	gettable      r1    r0   k50 ; k50 = "WidgetSwitcher_Colle" (truncated)
.line	1952	self          r1    r1   k45 ; k45 = "SetActiveWidgetIndex"
.line	1952	loadk         r3   k47 ; k47 = 0
.line	1952	call          r1     3     1
.label	l101
.line	1952	self          r1    r0   k51 ; k51 = "RefreshCirclePanel"
.line	1952	call          r1     2     1
.line	1952	return        r0     1
.line	1952	move          r0    r0
.line	1952	return        r0     1

.function	main/f81

.source	null
.linedefined	1970
.lastlinedefined	1984
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	4
.constant	k4	80
.constant	k5	199
.constant	k6	102
.constant	k7	152
.constant	k8	212
.constant	k9	40
.constant	k10	24
.constant	k11	195
.constant	k12	110
.constant	k13	100
.constant	k14	222
.constant	k15	176
.constant	k16	114
.constant	k17	202
.constant	k18	210
.constant	k19	115
.constant	k20	163
.constant	k21	29
.constant	k22	99
.constant	k23	240
.constant	k24	84
.constant	k25	149
.constant	k26	208
.constant	k27	123
.constant	k28	35
.constant	k29	172
.constant	k30	136
.constant	k31	118
.constant	k32	201
.constant	k33	215
.constant	k34	112
.constant	k35	184
.constant	k36	13
.constant	k37	113
.constant	k38	236
.constant	k39	70
.constant	k40	98
.constant	k41	38
.constant	k42	31
.constant	k43	198
.constant	k44	108
.constant	k45	179
.constant	k46	200
.constant	k47	42
.constant	k48	105
.constant	k49	193
.constant	k50	101
.constant	k51	62
.constant	k52	247
.constant	k53	"GetFlauntEmote"
.constant	k54	"NeedHidePetExpression"
.constant	k55	"pairs"
.constant	k56	"CheckIsPetExhibitionEmote"
.constant	k57	1
.constant	k58	"FlauntList"

.line	1970	gettabup      r1    u0    k0 ; k0 = "require"
.line	1970	gettabup      r2    u0    k1 ; k1 = "table"
.line	1970	gettable      r2    r2    k2 ; k2 = "concat"
.line	1970	newtable      r3     1     0
.line	1970	getupval      r4    u1
.line	1970	loadk         r5    k3 ; k3 = 4
.line	1970	loadk         r6    k4 ; k4 = 80
.line	1970	loadk         r7    k5 ; k5 = 199
.line	1970	loadk         r8    k6 ; k6 = 102
.line	1970	loadk         r9    k7 ; k7 = 152
.line	1970	loadk        r10    k8 ; k8 = 212
.line	1970	loadk        r11    k9 ; k9 = 40
.line	1970	loadk        r12   k10 ; k10 = 24
.line	1970	loadk        r13    k7 ; k7 = 152
.line	1970	loadk        r14   k11 ; k11 = 195
.line	1970	loadk        r15   k12 ; k12 = 110
.line	1970	loadk        r16   k13 ; k13 = 100
.line	1970	loadk        r17   k14 ; k14 = 222
.line	1970	loadk        r18   k15 ; k15 = 176
.line	1970	loadk        r19   k16 ; k16 = 114
.line	1970	loadk        r20   k17 ; k17 = 202
.line	1970	loadk        r21   k18 ; k18 = 210
.line	1970	loadk        r22   k19 ; k19 = 115
.line	1970	loadk        r23   k20 ; k20 = 163
.line	1970	loadk        r24   k21 ; k21 = 29
.line	1970	loadk        r25   k22 ; k22 = 99
.line	1970	loadk        r26   k23 ; k23 = 240
.line	1970	loadk        r27   k24 ; k24 = 84
.line	1970	loadk        r28   k22 ; k22 = 99
.line	1970	loadk        r29   k25 ; k25 = 149
.line	1970	loadk        r30   k26 ; k26 = 208
.line	1970	loadk        r31   k27 ; k27 = 123
.line	1970	loadk        r32   k28 ; k28 = 35
.line	1970	loadk        r33   k29 ; k29 = 172
.line	1970	loadk        r34   k30 ; k30 = 136
.line	1970	loadk        r35   k31 ; k31 = 118
.line	1970	loadk        r36   k32 ; k32 = 201
.line	1970	loadk        r37   k33 ; k33 = 215
.line	1970	loadk        r38   k34 ; k34 = 112
.line	1970	loadk        r39   k35 ; k35 = 184
.line	1970	loadk        r40   k36 ; k36 = 13
.line	1970	loadk        r41   k37 ; k37 = 113
.line	1970	loadk        r42   k38 ; k38 = 236
.line	1970	loadk        r43   k39 ; k39 = 70
.line	1970	loadk        r44   k40 ; k40 = 98
.line	1970	call          r4    41     2
.line	1970	getupval      r5    u1
.line	1970	loadk         r6   k41 ; k41 = 38
.line	1970	loadk         r7   k42 ; k42 = 31
.line	1970	loadk         r8   k43 ; k43 = 198
.line	1970	loadk         r9   k44 ; k44 = 108
.line	1970	loadk        r10   k45 ; k45 = 179
.line	1970	loadk        r11   k46 ; k46 = 200
.line	1970	loadk        r12   k47 ; k47 = 42
.line	1970	loadk        r13   k48 ; k48 = 105
.line	1970	loadk        r14   k15 ; k15 = 176
.line	1970	loadk        r15   k49 ; k49 = 193
.line	1970	loadk        r16   k50 ; k50 = 101
.line	1970	loadk        r17   k51 ; k51 = 62
.line	1970	loadk        r18   k52 ; k52 = 247
.line	1970	call          r5    14     0
.line	1970	setlist       r3     0     1
.line	1970	call          r2     2     2
.line	1970	call          r1     2     2
.line	1970	gettable      r2    r1   k53 ; k53 = "GetFlauntEmote"
.line	1970	call          r2     1     2
.line	1970	self          r3    r0   k54 ; k54 = "NeedHidePetExpressio" (truncated)
.line	1970	call          r3     2     2
.line	1970	test          r3     0
.line	1970	jmp            0   l88
.line	1970	newtable      r3     0     0
.line	1970	gettabup      r4    u0   k55 ; k55 = "pairs"
.line	1970	move          r5    r2
.line	1970	call          r4     2     4
.line	1970	jmp            0   l84
.line	1970	gettable      r9    r1   k56 ; k56 = "CheckIsPetExhibition" (truncated)
.line	1970	move         r10    r8
.line	1970	call          r9     2     2
.line	1970	test          r9     1
.line	1970	jmp            0   l84
.line	1970	len           r9    r3
.line	1970	add           r9    r9   k57 ; k57 = 1
.line	1970	settable      r3    r9    r8
.label	l84
.line	1970	move          r0    r0
.line	1970	move          r0    r0
.line	1970	settable      r0   k58    r3 ; k58 = "FlauntList"
.line	1970	jmp            0   l89
.label	l88
.line	1970	settable      r0   k58    r2 ; k58 = "FlauntList"
.label	l89
.line	1970	return        r0     1
.line	1970	move          r0    r0
.line	1970	return        r0     1

.function	main/f82

.source	null
.linedefined	1986
.lastlinedefined	2024
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	23	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	18
.constant	k3	68
.constant	k4	195
.constant	k5	96
.constant	k6	191
.constant	k7	228
.constant	k8	49
.constant	k9	70
.constant	k10	167
.constant	k11	201
.constant	k12	121
.constant	k13	57
.constant	k14	251
.constant	k15	182
.constant	k16	126
.constant	k17	130
.constant	k18	225
.constant	k19	100
.constant	k20	188
.constant	k21	65
.constant	k22	226
.constant	k23	81
.constant	k24	64
.constant	k25	169
.constant	k26	221
.constant	k27	111
.constant	k28	52
.constant	k29	246
.constant	k30	"CurrentShowState"
.constant	k31	"Flaunt"
.constant	k32	"log"
.constant	k33	"string"
.constant	k34	"format"
.constant	k35	"table"
.constant	k36	"concat"
.constant	k37	233
.constant	k38	115
.constant	k39	202
.constant	k40	97
.constant	k41	230
.constant	k42	3
.constant	k43	119
.constant	k44	244
.constant	k45	91
.constant	k46	38
.constant	k47	95
.constant	k48	222
.constant	k49	80
.constant	k50	206
.constant	k51	62
.constant	k52	101
.constant	k53	161
.constant	k54	205
.constant	k55	47
.constant	k56	175
.constant	k57	252
.constant	k58	99
.constant	k59	"tostring"
.constant	k60	"RefreshFlauntList"
.constant	k61	"log_tree"
.constant	k62	17
.constant	k63	84
.constant	k64	204
.constant	k65	113
.constant	k66	177
.constant	k67	210
.constant	k68	33
.constant	k69	112
.constant	k70	185
.constant	k71	127
.constant	k72	36
.constant	k73	227
.constant	k74	"FlauntList"
.constant	k75	"pairs"
.constant	k76	"EmoteNameArray"
.constant	k77	"SetText"
.constant	k78	"SlotSwitcherArray"
.constant	k79	"SetActiveWidgetIndex"
.constant	k80	1
.constant	k81	"EmoteImageArray"
.constant	k82	"Num"
.constant	k83	"require"
.constant	k84	4
.constant	k85	199
.constant	k86	102
.constant	k87	152
.constant	k88	212
.constant	k89	40
.constant	k90	24
.constant	k91	110
.constant	k92	176
.constant	k93	114
.constant	k94	163
.constant	k95	29
.constant	k96	240
.constant	k97	149
.constant	k98	208
.constant	k99	123
.constant	k100	35
.constant	k101	172
.constant	k102	136
.constant	k103	118
.constant	k104	215
.constant	k105	184
.constant	k106	13
.constant	k107	236
.constant	k108	98
.constant	k109	31
.constant	k110	198
.constant	k111	108
.constant	k112	179
.constant	k113	200
.constant	k114	42
.constant	k115	105
.constant	k116	193
.constant	k117	247
.constant	k118	"Get"
.constant	k119	32
.constant	k120	93
.constant	k121	186
.constant	k122	213
.constant	k123	103
.constant	k124	85
.constant	k125	37
.constant	k126	209
.constant	k127	116
.constant	k128	174
.constant	k129	90
.constant	k130	72
.constant	k131	"GetItemSmallIcon"
.constant	k132	0
.constant	k133	69
.constant	k134	217
.constant	k135	107
.constant	k136	21
.constant	k137	231
.constant	k138	79
.constant	k139	183
.constant	k140	86
.constant	k141	83
.constant	k142	254
.constant	k143	75
.constant	k144	109
.constant	k145	235
.constant	k146	51
.constant	k147	238
.constant	k148	"SetTexture"
.constant	k149	"sync"
.constant	k150	false
.constant	k151	"SetColorAndOpacity"
.constant	k152	"FLinearColor"
.constant	k153	"CheckIsPetExhibitionEmote"
.constant	k154	"PetExhibitIndex"

.line	1986	gettabup      r1    u0    k0 ; k0 = "print"
.line	1986	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1986	test          r2     0
.line	1986	jmp            0   l36
.line	1986	getupval      r2    u1
.line	1986	loadk         r3    k2 ; k2 = 18
.line	1986	loadk         r4    k3 ; k3 = 68
.line	1986	loadk         r5    k4 ; k4 = 195
.line	1986	loadk         r6    k5 ; k5 = 96
.line	1986	loadk         r7    k6 ; k6 = 191
.line	1986	loadk         r8    k7 ; k7 = 228
.line	1986	loadk         r9    k8 ; k8 = 49
.line	1986	loadk        r10    k9 ; k9 = 70
.line	1986	loadk        r11   k10 ; k10 = 167
.line	1986	loadk        r12   k11 ; k11 = 201
.line	1986	loadk        r13   k12 ; k12 = 121
.line	1986	loadk        r14   k13 ; k13 = 57
.line	1986	loadk        r15   k14 ; k14 = 251
.line	1986	loadk        r16   k15 ; k15 = 182
.line	1986	loadk        r17   k16 ; k16 = 126
.line	1986	loadk        r18   k17 ; k17 = 130
.line	1986	loadk        r19   k18 ; k18 = 225
.line	1986	loadk        r20   k19 ; k19 = 100
.line	1986	loadk        r21   k20 ; k20 = 188
.line	1986	loadk        r22   k21 ; k21 = 65
.line	1986	loadk        r23   k21 ; k21 = 65
.line	1986	loadk        r24   k22 ; k22 = 226
.line	1986	loadk        r25   k23 ; k23 = 81
.line	1986	loadk        r26   k24 ; k24 = 64
.line	1986	loadk        r27   k25 ; k25 = 169
.line	1986	loadk        r28   k26 ; k26 = 221
.line	1986	loadk        r29   k27 ; k27 = 111
.line	1986	loadk        r30   k28 ; k28 = 52
.line	1986	loadk        r31   k29 ; k29 = 246
.line	1986	call          r2    30     2
.label	l36
.line	1986	gettable      r3    r0   k30 ; k30 = "CurrentShowState"
.line	1986	call          r1     3     1
.line	1986	gettable      r1    r0   k30 ; k30 = "CurrentShowState"
.line	1986	gettabup      r2    u2   k31 ; k31 = "Flaunt"
.line	1986	eq             1    r1    r2
.line	1986	jmp            0  l118
.line	1986	gettabup      r1    u0   k32 ; k32 = "log"
.line	1986	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1986	test          r2     0
.line	1986	jmp            0  l116
.line	1986	gettabup      r2    u0   k33 ; k33 = "string"
.line	1986	gettable      r2    r2   k34 ; k34 = "format"
.line	1986	gettabup      r3    u0   k35 ; k35 = "table"
.line	1986	gettable      r3    r3   k36 ; k36 = "concat"
.line	1986	newtable      r4     1     0
.line	1986	getupval      r5    u1
.line	1986	loadk         r6    k2 ; k2 = 18
.line	1986	loadk         r7    k3 ; k3 = 68
.line	1986	loadk         r8    k4 ; k4 = 195
.line	1986	loadk         r9    k5 ; k5 = 96
.line	1986	loadk        r10    k6 ; k6 = 191
.line	1986	loadk        r11    k7 ; k7 = 228
.line	1986	loadk        r12    k8 ; k8 = 49
.line	1986	loadk        r13    k9 ; k9 = 70
.line	1986	loadk        r14   k10 ; k10 = 167
.line	1986	loadk        r15   k11 ; k11 = 201
.line	1986	loadk        r16   k12 ; k12 = 121
.line	1986	loadk        r17   k13 ; k13 = 57
.line	1986	loadk        r18   k14 ; k14 = 251
.line	1986	loadk        r19   k15 ; k15 = 182
.line	1986	loadk        r20   k16 ; k16 = 126
.line	1986	loadk        r21   k17 ; k17 = 130
.line	1986	loadk        r22   k18 ; k18 = 225
.line	1986	loadk        r23   k19 ; k19 = 100
.line	1986	loadk        r24   k20 ; k20 = 188
.line	1986	loadk        r25   k21 ; k21 = 65
.line	1986	loadk        r26   k21 ; k21 = 65
.line	1986	loadk        r27   k22 ; k22 = 226
.line	1986	loadk        r28   k23 ; k23 = 81
.line	1986	loadk        r29   k24 ; k24 = 64
.line	1986	loadk        r30   k25 ; k25 = 169
.line	1986	loadk        r31   k26 ; k26 = 221
.line	1986	loadk        r32   k27 ; k27 = 111
.line	1986	loadk        r33   k28 ; k28 = 52
.line	1986	loadk        r34   k29 ; k29 = 246
.line	1986	loadk        r35   k37 ; k37 = 233
.line	1986	loadk        r36   k38 ; k38 = 115
.line	1986	loadk        r37    k4 ; k4 = 195
.line	1986	loadk        r38   k39 ; k39 = 202
.line	1986	loadk        r39   k40 ; k40 = 97
.line	1986	loadk        r40   k41 ; k41 = 230
.line	1986	loadk        r41   k42 ; k42 = 3
.line	1986	loadk        r42   k43 ; k43 = 119
.line	1986	loadk        r43   k44 ; k44 = 244
.line	1986	loadk        r44   k45 ; k45 = 91
.line	1986	loadk        r45   k19 ; k19 = 100
.line	1986	call          r5    41     2
.line	1986	getupval      r6    u1
.line	1986	loadk         r7   k46 ; k46 = 38
.line	1986	loadk         r8   k47 ; k47 = 95
.line	1986	loadk         r9   k48 ; k48 = 222
.line	1986	loadk        r10   k49 ; k49 = 80
.line	1986	loadk        r11   k20 ; k20 = 188
.line	1986	loadk        r12   k50 ; k50 = 206
.line	1986	loadk        r13   k51 ; k51 = 62
.line	1986	loadk        r14   k52 ; k52 = 101
.line	1986	loadk        r15   k53 ; k53 = 161
.line	1986	loadk        r16   k54 ; k54 = 205
.line	1986	loadk        r17   k16 ; k16 = 126
.line	1986	loadk        r18   k55 ; k55 = 47
.line	1986	loadk        r19   k56 ; k56 = 175
.line	1986	loadk        r20   k57 ; k57 = 252
.line	1986	loadk        r21   k58 ; k58 = 99
.line	1986	call          r6    16     0
.line	1986	setlist       r4     0     1
.line	1986	call          r3     2     2
.line	1986	gettabup      r4    u0   k59 ; k59 = "tostring"
.line	1986	gettable      r5    r0   k30 ; k30 = "CurrentShowState"
.line	1986	call          r4     2     0
.line	1986	call          r2     0     2
.label	l116
.line	1986	call          r1     2     1
.line	1986	return        r0     1
.label	l118
.line	1986	self          r1    r0   k60 ; k60 = "RefreshFlauntList"
.line	1986	call          r1     2     1
.line	1986	gettabup      r1    u0   k61 ; k61 = "log_tree"
.line	1986	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1986	test          r2     0
.line	1986	jmp            0  l140
.line	1986	getupval      r2    u1
.line	1986	loadk         r3   k62 ; k62 = 17
.line	1986	loadk         r4   k63 ; k63 = 84
.line	1986	loadk         r5   k64 ; k64 = 204
.line	1986	loadk         r6   k65 ; k65 = 113
.line	1986	loadk         r7   k66 ; k66 = 177
.line	1986	loadk         r8   k67 ; k67 = 210
.line	1986	loadk         r9   k68 ; k68 = 33
.line	1986	loadk        r10   k69 ; k69 = 112
.line	1986	loadk        r11   k70 ; k70 = 185
.line	1986	loadk        r12   k54 ; k54 = 205
.line	1986	loadk        r13   k71 ; k71 = 127
.line	1986	loadk        r14   k72 ; k72 = 36
.line	1986	loadk        r15   k41 ; k41 = 230
.line	1986	loadk        r16   k73 ; k73 = 227
.line	1986	call          r2    15     2
.label	l140
.line	1986	gettable      r3    r0   k74 ; k74 = "FlauntList"
.line	1986	call          r1     3     1
.line	1986	gettabup      r1    u0   k75 ; k75 = "pairs"
.line	1986	gettable      r2    r0   k76 ; k76 = "EmoteNameArray"
.line	1986	call          r1     2     4
.line	1986	jmp            0  l152
.line	1986	test          r5     0
.line	1986	jmp            0  l152
.line	1986	self          r6    r5   k77 ; k77 = "SetText"
.line	1986	getupval      r8    u1
.line	1986	call          r8     1     2
.line	1986	call          r6     3     1
.label	l152
.line	1986	move          r0    r0
.line	1986	move          r0    r0
.line	1986	gettabup      r1    u0   k75 ; k75 = "pairs"
.line	1986	gettable      r2    r0   k78 ; k78 = "SlotSwitcherArray"
.line	1986	call          r1     2     4
.line	1986	jmp            0  l163
.line	1986	test          r5     0
.line	1986	jmp            0  l163
.line	1986	self          r6    r5   k79 ; k79 = "SetActiveWidgetIndex"
.line	1986	loadk         r8   k80 ; k80 = 1
.line	1986	call          r6     3     1
.label	l163
.line	1986	move          r0    r0
.line	1986	move          r0    r0
.line	1986	gettable      r1    r0   k81 ; k81 = "EmoteImageArray"
.line	1986	self          r1    r1   k82 ; k82 = "Num"
.line	1986	call          r1     2     2
.line	1986	gettabup      r2    u0   k83 ; k83 = "require"
.line	1986	gettabup      r3    u0   k35 ; k35 = "table"
.line	1986	gettable      r3    r3   k36 ; k36 = "concat"
.line	1986	newtable      r4     1     0
.line	1986	getupval      r5    u1
.line	1986	loadk         r6   k84 ; k84 = 4
.line	1986	loadk         r7   k49 ; k49 = 80
.line	1986	loadk         r8   k85 ; k85 = 199
.line	1986	loadk         r9   k86 ; k86 = 102
.line	1986	loadk        r10   k87 ; k87 = 152
.line	1986	loadk        r11   k88 ; k88 = 212
.line	1986	loadk        r12   k89 ; k89 = 40
.line	1986	loadk        r13   k90 ; k90 = 24
.line	1986	loadk        r14   k87 ; k87 = 152
.line	1986	loadk        r15    k4 ; k4 = 195
.line	1986	loadk        r16   k91 ; k91 = 110
.line	1986	loadk        r17   k19 ; k19 = 100
.line	1986	loadk        r18   k48 ; k48 = 222
.line	1986	loadk        r19   k92 ; k92 = 176
.line	1986	loadk        r20   k93 ; k93 = 114
.line	1986	loadk        r21   k39 ; k39 = 202
.line	1986	loadk        r22   k67 ; k67 = 210
.line	1986	loadk        r23   k38 ; k38 = 115
.line	1986	loadk        r24   k94 ; k94 = 163
.line	1986	loadk        r25   k95 ; k95 = 29
.line	1986	loadk        r26   k58 ; k58 = 99
.line	1986	loadk        r27   k96 ; k96 = 240
.line	1986	loadk        r28   k63 ; k63 = 84
.line	1986	loadk        r29   k58 ; k58 = 99
.line	1986	loadk        r30   k97 ; k97 = 149
.line	1986	loadk        r31   k98 ; k98 = 208
.line	1986	loadk        r32   k99 ; k99 = 123
.line	1986	loadk        r33  k100 ; k100 = 35
.line	1986	loadk        r34  k101 ; k101 = 172
.line	1986	loadk        r35  k102 ; k102 = 136
.line	1986	loadk        r36  k103 ; k103 = 118
.line	1986	loadk        r37   k11 ; k11 = 201
.line	1986	loadk        r38  k104 ; k104 = 215
.line	1986	loadk        r39   k69 ; k69 = 112
.line	1986	loadk        r40  k105 ; k105 = 184
.line	1986	loadk        r41  k106 ; k106 = 13
.line	1986	loadk        r42   k65 ; k65 = 113
.line	1986	loadk        r43  k107 ; k107 = 236
.line	1986	loadk        r44    k9 ; k9 = 70
.line	1986	loadk        r45  k108 ; k108 = 98
.line	1986	call          r5    41     2
.line	1986	getupval      r6    u1
.line	1986	loadk         r7   k46 ; k46 = 38
.line	1986	loadk         r8  k109 ; k109 = 31
.line	1986	loadk         r9  k110 ; k110 = 198
.line	1986	loadk        r10  k111 ; k111 = 108
.line	1986	loadk        r11  k112 ; k112 = 179
.line	1986	loadk        r12  k113 ; k113 = 200
.line	1986	loadk        r13  k114 ; k114 = 42
.line	1986	loadk        r14  k115 ; k115 = 105
.line	1986	loadk        r15   k92 ; k92 = 176
.line	1986	loadk        r16  k116 ; k116 = 193
.line	1986	loadk        r17   k52 ; k52 = 101
.line	1986	loadk        r18   k51 ; k51 = 62
.line	1986	loadk        r19  k117 ; k117 = 247
.line	1986	call          r6    14     0
.line	1986	setlist       r4     0     1
.line	1986	call          r3     2     2
.line	1986	call          r2     2     2
.line	1986	gettabup      r3    u0   k75 ; k75 = "pairs"
.line	1986	gettable      r4    r0   k74 ; k74 = "FlauntList"
.line	1986	call          r3     2     4
.line	1986	jmp            0  l342
.line	1986	le             0    r6    r1
.line	1986	jmp            0  l336
.line	1986	gettable      r8    r0   k81 ; k81 = "EmoteImageArray"
.line	1986	self          r8    r8  k118 ; k118 = "Get"
.line	1986	sub          r10    r6   k80 ; k80 = 1
.line	1986	call          r8     3     2
.line	1986	gettable      r9    r0   k78 ; k78 = "SlotSwitcherArray"
.line	1986	self          r9    r9  k118 ; k118 = "Get"
.line	1986	sub          r11    r6   k80 ; k80 = 1
.line	1986	call          r9     3     2
.line	1986	gettable     r10    r0   k76 ; k76 = "EmoteNameArray"
.line	1986	self         r10   r10  k118 ; k118 = "Get"
.line	1986	sub          r12    r6   k80 ; k80 = 1
.line	1986	call         r10     3     2
.line	1986	gettabup     r11    u0   k83 ; k83 = "require"
.line	1986	getupval     r12    u1
.line	1986	loadk        r13  k119 ; k119 = 32
.line	1986	loadk        r14  k120 ; k120 = 93
.line	1986	loadk        r15    k4 ; k4 = 195
.line	1986	loadk        r16   k86 ; k86 = 102
.line	1986	loadk        r17  k121 ; k121 = 186
.line	1986	loadk        r18  k122 ; k122 = 213
.line	1986	loadk        r19  k123 ; k123 = 103
.line	1986	loadk        r20  k124 ; k124 = 85
.line	1986	loadk        r21  k121 ; k121 = 186
.line	1986	loadk        r22  k116 ; k116 = 193
.line	1986	loadk        r23  k123 ; k123 = 103
.line	1986	loadk        r24  k125 ; k125 = 37
.line	1986	loadk        r25   k57 ; k57 = 252
.line	1986	loadk        r26  k117 ; k117 = 247
.line	1986	loadk        r27   k52 ; k52 = 101
.line	1986	loadk        r28  k126 ; k126 = 209
.line	1986	loadk        r29  k107 ; k107 = 236
.line	1986	loadk        r30  k127 ; k127 = 116
.line	1986	loadk        r31  k128 ; k128 = 174
.line	1986	loadk        r32  k129 ; k129 = 90
.line	1986	loadk        r33  k130 ; k130 = 72
.line	1986	call         r12    22     2
.line	1986	call         r11     2     2
.line	1986	gettable     r12   r11  k131 ; k131 = "GetItemSmallIcon"
.line	1986	move         r13    r7
.line	1986	call         r12     2     2
.line	1986	test          r8     0
.line	1986	jmp            0  l336
.line	1986	test          r9     0
.line	1986	jmp            0  l336
.line	1986	test         r10     0
.line	1986	jmp            0  l336
.line	1986	test         r12     0
.line	1986	jmp            0  l336
.line	1986	self         r13    r9   k79 ; k79 = "SetActiveWidgetIndex"
.line	1986	loadk        r15  k132 ; k132 = 0
.line	1986	call         r13     3     1
.line	1986	gettabup     r13    u0   k83 ; k83 = "require"
.line	1986	getupval     r14    u1
.line	1986	loadk        r15  k119 ; k119 = 32
.line	1986	loadk        r16  k120 ; k120 = 93
.line	1986	loadk        r17    k4 ; k4 = 195
.line	1986	loadk        r18   k86 ; k86 = 102
.line	1986	loadk        r19  k121 ; k121 = 186
.line	1986	loadk        r20  k122 ; k122 = 213
.line	1986	loadk        r21  k123 ; k123 = 103
.line	1986	loadk        r22  k133 ; k133 = 69
.line	1986	loadk        r23   k70 ; k70 = 185
.line	1986	loadk        r24  k134 ; k134 = 217
.line	1986	loadk        r25  k135 ; k135 = 107
.line	1986	loadk        r26  k136 ; k136 = 21
.line	1986	loadk        r27  k137 ; k137 = 231
.line	1986	loadk        r28   k92 ; k92 = 176
.line	1986	loadk        r29  k138 ; k138 = 79
.line	1986	loadk        r30   k48 ; k48 = 222
.line	1986	loadk        r31  k116 ; k116 = 193
.line	1986	loadk        r32    k5 ; k5 = 96
.line	1986	loadk        r33  k139 ; k139 = 183
.line	1986	loadk        r34  k140 ; k140 = 86
.line	1986	loadk        r35  k141 ; k141 = 83
.line	1986	loadk        r36  k142 ; k142 = 254
.line	1986	loadk        r37  k143 ; k143 = 75
.line	1986	loadk        r38  k144 ; k144 = 109
.line	1986	loadk        r39  k145 ; k145 = 235
.line	1986	loadk        r40   k11 ; k11 = 201
.line	1986	loadk        r41   k91 ; k91 = 110
.line	1986	loadk        r42  k146 ; k146 = 51
.line	1986	loadk        r43  k147 ; k147 = 238
.line	1986	call         r14    30     2
.line	1986	call         r13     2     2
.line	1986	gettable     r14   r13  k148 ; k148 = "SetTexture"
.line	1986	move         r15    r8
.line	1986	move         r16   r12
.line	1986	newtable     r17     0     1
.line	1986	settable     r17  k149  k150 ; k150 = false
.line	1986	call         r14     4     1
.line	1986	self         r14    r8  k151 ; k151 = "SetColorAndOpacity"
.line	1986	gettabup     r16    u0  k152 ; k152 = "FLinearColor"
.line	1986	loadk        r17   k80 ; k80 = 1
.line	1986	loadk        r18   k80 ; k80 = 1
.line	1986	loadk        r19   k80 ; k80 = 1
.line	1986	loadk        r20   k80 ; k80 = 1
.line	1986	call         r16     5     0
.line	1986	call         r14     0     1
.label	l336
.line	1986	gettable      r8    r2  k153 ; k153 = "CheckIsPetExhibition" (truncated)
.line	1986	move          r9    r7
.line	1986	call          r8     2     2
.line	1986	test          r8     0
.line	1986	jmp            0  l342
.line	1986	settable      r0  k154    r6 ; k154 = "PetExhibitIndex"
.label	l342
.line	1986	move          r0    r0
.line	1986	move          r0    r0
.line	1986	return        r0     1
.line	1986	move          r0    r0
.line	1986	move          r0    r0
.line	1986	move          r0    r0
.line	1986	move          r0    r0
.line	1986	return        r0     1

.function	main/f83

.source	null
.linedefined	2026
.lastlinedefined	2033
.numparams	4
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"tonumber"
.constant	k1	"DataMgr"
.constant	k2	"roleData"
.constant	k3	"uid"
.constant	k4	"log"
.constant	k5	"bWriteLog"
.constant	k6	"string"
.constant	k7	"format"
.constant	k8	"table"
.constant	k9	"concat"
.constant	k10	18
.constant	k11	68
.constant	k12	195
.constant	k13	96
.constant	k14	191
.constant	k15	228
.constant	k16	49
.constant	k17	70
.constant	k18	167
.constant	k19	201
.constant	k20	121
.constant	k21	57
.constant	k22	251
.constant	k23	182
.constant	k24	126
.constant	k25	130
.constant	k26	252
.constant	k27	111
.constant	k28	153
.constant	k29	82
.constant	k30	86
.constant	k31	245
.constant	k32	122
.constant	k33	105
.constant	k34	169
.constant	k35	208
.constant	k36	127
.constant	k37	246
.constant	k38	160
.constant	k39	198
.constant	k40	240
.constant	k41	165
.constant	k42	84
.constant	k43	125
.constant	k44	239
.constant	k45	79
.constant	k46	17
.constant	k47	66
.constant	k48	218
.constant	k49	35
.constant	k50	202
.constant	k51	32
.constant	k52	249
.constant	k53	140
.constant	k54	53
.constant	k55	203
.constant	k56	147
.constant	k57	181
.constant	k58	71
.constant	k59	4
.constant	k60	226
.constant	k61	92
.constant	k62	106
.constant	k63	163
.constant	k64	"tostring"
.constant	k65	166
.constant	k66	196
.constant	k67	47
.constant	k68	176
.constant	k69	223
.constant	k70	98
.constant	k71	244
.constant	k72	113
.constant	k73	205
.constant	k74	221
.constant	k75	117
.constant	k76	"RefreshFlaunt"

.line	2026	gettabup      r4    u0    k0 ; k0 = "tonumber"
.line	2026	move          r5    r3
.line	2026	call          r4     2     2
.line	2026	gettabup      r5    u0    k0 ; k0 = "tonumber"
.line	2026	gettabup      r6    u0    k1 ; k1 = "DataMgr"
.line	2026	gettable      r6    r6    k2 ; k2 = "roleData"
.line	2026	gettable      r6    r6    k3 ; k3 = "uid"
.line	2026	call          r5     2     2
.line	2026	eq             1    r4    r5
.line	2026	jmp            0   l97
.line	2026	gettabup      r4    u0    k4 ; k4 = "log"
.line	2026	gettabup      r5    u0    k5 ; k5 = "bWriteLog"
.line	2026	test          r5     0
.line	2026	jmp            0   l95
.line	2026	gettabup      r5    u0    k6 ; k6 = "string"
.line	2026	gettable      r5    r5    k7 ; k7 = "format"
.line	2026	gettabup      r6    u0    k8 ; k8 = "table"
.line	2026	gettable      r6    r6    k9 ; k9 = "concat"
.line	2026	newtable      r7     1     0
.line	2026	getupval      r8    u1
.line	2026	loadk         r9   k10 ; k10 = 18
.line	2026	loadk        r10   k11 ; k11 = 68
.line	2026	loadk        r11   k12 ; k12 = 195
.line	2026	loadk        r12   k13 ; k13 = 96
.line	2026	loadk        r13   k14 ; k14 = 191
.line	2026	loadk        r14   k15 ; k15 = 228
.line	2026	loadk        r15   k16 ; k16 = 49
.line	2026	loadk        r16   k17 ; k17 = 70
.line	2026	loadk        r17   k18 ; k18 = 167
.line	2026	loadk        r18   k19 ; k19 = 201
.line	2026	loadk        r19   k20 ; k20 = 121
.line	2026	loadk        r20   k21 ; k21 = 57
.line	2026	loadk        r21   k22 ; k22 = 251
.line	2026	loadk        r22   k23 ; k23 = 182
.line	2026	loadk        r23   k24 ; k24 = 126
.line	2026	loadk        r24   k25 ; k25 = 130
.line	2026	loadk        r25   k26 ; k26 = 252
.line	2026	loadk        r26   k27 ; k27 = 111
.line	2026	loadk        r27   k28 ; k28 = 153
.line	2026	loadk        r28   k29 ; k29 = 82
.line	2026	loadk        r29   k30 ; k30 = 86
.line	2026	loadk        r30   k31 ; k31 = 245
.line	2026	loadk        r31   k32 ; k32 = 122
.line	2026	loadk        r32   k33 ; k33 = 105
.line	2026	loadk        r33   k34 ; k34 = 169
.line	2026	loadk        r34   k35 ; k35 = 208
.line	2026	loadk        r35   k36 ; k36 = 127
.line	2026	loadk        r36   k21 ; k21 = 57
.line	2026	loadk        r37   k37 ; k37 = 246
.line	2026	loadk        r38   k38 ; k38 = 160
.line	2026	loadk        r39   k27 ; k27 = 111
.line	2026	loadk        r40   k39 ; k39 = 198
.line	2026	loadk        r41   k40 ; k40 = 240
.line	2026	loadk        r42   k20 ; k20 = 121
.line	2026	loadk        r43   k41 ; k41 = 165
.line	2026	loadk        r44   k42 ; k42 = 84
.line	2026	loadk        r45   k43 ; k43 = 125
.line	2026	loadk        r46   k44 ; k44 = 239
.line	2026	loadk        r47   k45 ; k45 = 79
.line	2026	loadk        r48   k20 ; k20 = 121
.line	2026	call          r8    41     2
.line	2026	getupval      r9    u1
.line	2026	loadk        r10   k46 ; k46 = 17
.line	2026	loadk        r11   k47 ; k47 = 66
.line	2026	loadk        r12   k48 ; k48 = 218
.line	2026	loadk        r13   k49 ; k49 = 35
.line	2026	loadk        r14   k18 ; k18 = 167
.line	2026	loadk        r15   k50 ; k50 = 202
.line	2026	loadk        r16   k51 ; k51 = 32
.line	2026	loadk        r17   k17 ; k17 = 70
.line	2026	loadk        r18   k52 ; k52 = 249
.line	2026	loadk        r19   k53 ; k53 = 140
.line	2026	loadk        r20   k36 ; k36 = 127
.line	2026	loadk        r21   k49 ; k49 = 35
.line	2026	loadk        r22   k37 ; k37 = 246
.line	2026	loadk        r23   k15 ; k15 = 228
.line	2026	loadk        r24   k54 ; k54 = 53
.line	2026	loadk        r25   k55 ; k55 = 203
.line	2026	loadk        r26   k56 ; k56 = 147
.line	2026	loadk        r27   k27 ; k27 = 111
.line	2026	loadk        r28   k57 ; k57 = 181
.line	2026	loadk        r29   k58 ; k58 = 71
.line	2026	loadk        r30   k59 ; k59 = 4
.line	2026	loadk        r31   k60 ; k60 = 226
.line	2026	loadk        r32   k61 ; k61 = 92
.line	2026	loadk        r33   k62 ; k62 = 106
.line	2026	loadk        r34   k63 ; k63 = 163
.line	2026	call          r9    26     0
.line	2026	setlist       r7     0     1
.line	2026	call          r6     2     2
.line	2026	gettabup      r7    u0   k64 ; k64 = "tostring"
.line	2026	move          r8    r3
.line	2026	call          r7     2     0
.line	2026	call          r5     0     2
.label	l95
.line	2026	call          r4     2     1
.line	2026	return        r0     1
.label	l97
.line	2026	gettabup      r4    u0    k4 ; k4 = "log"
.line	2026	gettabup      r5    u0    k5 ; k5 = "bWriteLog"
.line	2026	test          r5     0
.line	2026	jmp            0  l168
.line	2026	gettabup      r5    u0    k8 ; k8 = "table"
.line	2026	gettable      r5    r5    k9 ; k9 = "concat"
.line	2026	newtable      r6     1     0
.line	2026	getupval      r7    u1
.line	2026	loadk         r8   k10 ; k10 = 18
.line	2026	loadk         r9   k11 ; k11 = 68
.line	2026	loadk        r10   k12 ; k12 = 195
.line	2026	loadk        r11   k13 ; k13 = 96
.line	2026	loadk        r12   k14 ; k14 = 191
.line	2026	loadk        r13   k15 ; k15 = 228
.line	2026	loadk        r14   k16 ; k16 = 49
.line	2026	loadk        r15   k17 ; k17 = 70
.line	2026	loadk        r16   k18 ; k18 = 167
.line	2026	loadk        r17   k19 ; k19 = 201
.line	2026	loadk        r18   k20 ; k20 = 121
.line	2026	loadk        r19   k21 ; k21 = 57
.line	2026	loadk        r20   k22 ; k22 = 251
.line	2026	loadk        r21   k23 ; k23 = 182
.line	2026	loadk        r22   k24 ; k24 = 126
.line	2026	loadk        r23   k25 ; k25 = 130
.line	2026	loadk        r24   k26 ; k26 = 252
.line	2026	loadk        r25   k27 ; k27 = 111
.line	2026	loadk        r26   k28 ; k28 = 153
.line	2026	loadk        r27   k29 ; k29 = 82
.line	2026	loadk        r28   k30 ; k30 = 86
.line	2026	loadk        r29   k31 ; k31 = 245
.line	2026	loadk        r30   k32 ; k32 = 122
.line	2026	loadk        r31   k33 ; k33 = 105
.line	2026	loadk        r32   k34 ; k34 = 169
.line	2026	loadk        r33   k35 ; k35 = 208
.line	2026	loadk        r34   k36 ; k36 = 127
.line	2026	loadk        r35   k21 ; k21 = 57
.line	2026	loadk        r36   k37 ; k37 = 246
.line	2026	loadk        r37   k38 ; k38 = 160
.line	2026	loadk        r38   k27 ; k27 = 111
.line	2026	loadk        r39   k39 ; k39 = 198
.line	2026	loadk        r40   k40 ; k40 = 240
.line	2026	loadk        r41   k20 ; k20 = 121
.line	2026	loadk        r42   k41 ; k41 = 165
.line	2026	loadk        r43   k42 ; k42 = 84
.line	2026	loadk        r44   k43 ; k43 = 125
.line	2026	loadk        r45   k44 ; k44 = 239
.line	2026	loadk        r46   k45 ; k45 = 79
.line	2026	loadk        r47   k20 ; k20 = 121
.line	2026	call          r7    41     2
.line	2026	getupval      r8    u1
.line	2026	loadk         r9   k46 ; k46 = 17
.line	2026	loadk        r10   k47 ; k47 = 66
.line	2026	loadk        r11   k48 ; k48 = 218
.line	2026	loadk        r12   k49 ; k49 = 35
.line	2026	loadk        r13   k65 ; k65 = 166
.line	2026	loadk        r14   k66 ; k66 = 196
.line	2026	loadk        r15   k67 ; k67 = 47
.line	2026	loadk        r16   k11 ; k11 = 68
.line	2026	loadk        r17   k68 ; k68 = 176
.line	2026	loadk        r18   k69 ; k69 = 223
.line	2026	loadk        r19   k70 ; k70 = 98
.line	2026	loadk        r20   k62 ; k62 = 106
.line	2026	loadk        r21   k71 ; k71 = 244
.line	2026	loadk        r22   k57 ; k57 = 181
.line	2026	loadk        r23   k72 ; k72 = 113
.line	2026	loadk        r24   k73 ; k73 = 205
.line	2026	loadk        r25   k74 ; k74 = 221
.line	2026	loadk        r26   k75 ; k75 = 117
.line	2026	call          r8    19     0
.line	2026	setlist       r6     0     1
.line	2026	call          r5     2     2
.label	l168
.line	2026	call          r4     2     1
.line	2026	self          r4    r0   k76 ; k76 = "RefreshFlaunt"
.line	2026	call          r4     2     1
.line	2026	return        r0     1
.line	2026	move          r0    r0
.line	2026	return        r0     1

.function	main/f84

.source	null
.linedefined	2035
.lastlinedefined	2056
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	-1
.constant	k1	0
.constant	k2	"FlauntList"
.constant	k3	1
.constant	k4	"print"
.constant	k5	"bWriteLog"
.constant	k6	18
.constant	k7	68
.constant	k8	195
.constant	k9	96
.constant	k10	191
.constant	k11	228
.constant	k12	49
.constant	k13	70
.constant	k14	167
.constant	k15	201
.constant	k16	121
.constant	k17	57
.constant	k18	251
.constant	k19	182
.constant	k20	126
.constant	k21	130
.constant	k22	231
.constant	k23	115
.constant	k24	163
.constant	k25	103
.constant	k26	75
.constant	k27	193
.constant	k28	85
.constant	k29	188
.constant	k30	250
.constant	k31	118
.constant	k32	59
.constant	k33	247
.constant	k34	116
.constant	k35	"require"
.constant	k36	"table"
.constant	k37	"concat"
.constant	k38	4
.constant	k39	80
.constant	k40	199
.constant	k41	102
.constant	k42	152
.constant	k43	212
.constant	k44	40
.constant	k45	24
.constant	k46	110
.constant	k47	100
.constant	k48	222
.constant	k49	176
.constant	k50	114
.constant	k51	202
.constant	k52	210
.constant	k53	29
.constant	k54	99
.constant	k55	240
.constant	k56	84
.constant	k57	149
.constant	k58	208
.constant	k59	123
.constant	k60	35
.constant	k61	172
.constant	k62	136
.constant	k63	215
.constant	k64	112
.constant	k65	184
.constant	k66	13
.constant	k67	113
.constant	k68	236
.constant	k69	98
.constant	k70	38
.constant	k71	31
.constant	k72	198
.constant	k73	108
.constant	k74	179
.constant	k75	200
.constant	k76	42
.constant	k77	105
.constant	k78	101
.constant	k79	62
.constant	k80	"CheckIsPetExhibitionEmote"
.constant	k81	"CheckCanUsePetExhibitionEmote"
.constant	k82	"GetPetExhibitRemainCD"
.constant	k83	"TryPlayPetExhibitAction"
.constant	k84	"ShowNotice"
.constant	k85	530022
.constant	k86	"PlayEmoteInternal"
.constant	k87	"ShowOrHideRing"

.line	2035	loadk         r2    k0 ; k0 = -1
.line	2035	test          r1     0
.line	2035	jmp            0    l9
.line	2035	le             0    k1    r1 ; k1 = 0
.line	2035	jmp            0    l9
.line	2035	gettable      r3    r0    k2 ; k2 = "FlauntList"
.line	2035	add           r4    r1    k3 ; k3 = 1
.line	2035	gettable      r2    r3    r4
.label	l9
.line	2035	gettabup      r3    u0    k4 ; k4 = "print"
.line	2035	gettabup      r4    u0    k5 ; k5 = "bWriteLog"
.line	2035	test          r4     0
.line	2035	jmp            0   l46
.line	2035	getupval      r4    u1
.line	2035	loadk         r5    k6 ; k6 = 18
.line	2035	loadk         r6    k7 ; k7 = 68
.line	2035	loadk         r7    k8 ; k8 = 195
.line	2035	loadk         r8    k9 ; k9 = 96
.line	2035	loadk         r9   k10 ; k10 = 191
.line	2035	loadk        r10   k11 ; k11 = 228
.line	2035	loadk        r11   k12 ; k12 = 49
.line	2035	loadk        r12   k13 ; k13 = 70
.line	2035	loadk        r13   k14 ; k14 = 167
.line	2035	loadk        r14   k15 ; k15 = 201
.line	2035	loadk        r15   k16 ; k16 = 121
.line	2035	loadk        r16   k17 ; k17 = 57
.line	2035	loadk        r17   k18 ; k18 = 251
.line	2035	loadk        r18   k19 ; k19 = 182
.line	2035	loadk        r19   k20 ; k20 = 126
.line	2035	loadk        r20   k21 ; k21 = 130
.line	2035	loadk        r21   k22 ; k22 = 231
.line	2035	loadk        r22   k23 ; k23 = 115
.line	2035	loadk        r23   k24 ; k24 = 163
.line	2035	loadk        r24   k25 ; k25 = 103
.line	2035	loadk        r25   k26 ; k26 = 75
.line	2035	loadk        r26   k27 ; k27 = 193
.line	2035	loadk        r27   k28 ; k28 = 85
.line	2035	loadk        r28   k25 ; k25 = 103
.line	2035	loadk        r29   k29 ; k29 = 188
.line	2035	loadk        r30   k30 ; k30 = 250
.line	2035	loadk        r31   k31 ; k31 = 118
.line	2035	loadk        r32   k32 ; k32 = 59
.line	2035	loadk        r33   k33 ; k33 = 247
.line	2035	loadk        r34   k14 ; k14 = 167
.line	2035	loadk        r35   k34 ; k34 = 116
.line	2035	call          r4    32     2
.label	l46
.line	2035	move          r5    r1
.line	2035	move          r6    r2
.line	2035	call          r3     4     1
.line	2035	test          r2     0
.line	2035	jmp            0  l143
.line	2035	lt             0    k1    r2 ; k1 = 0
.line	2035	jmp            0  l143
.line	2035	gettabup      r3    u0   k35 ; k35 = "require"
.line	2035	gettabup      r4    u0   k36 ; k36 = "table"
.line	2035	gettable      r4    r4   k37 ; k37 = "concat"
.line	2035	newtable      r5     1     0
.line	2035	getupval      r6    u1
.line	2035	loadk         r7   k38 ; k38 = 4
.line	2035	loadk         r8   k39 ; k39 = 80
.line	2035	loadk         r9   k40 ; k40 = 199
.line	2035	loadk        r10   k41 ; k41 = 102
.line	2035	loadk        r11   k42 ; k42 = 152
.line	2035	loadk        r12   k43 ; k43 = 212
.line	2035	loadk        r13   k44 ; k44 = 40
.line	2035	loadk        r14   k45 ; k45 = 24
.line	2035	loadk        r15   k42 ; k42 = 152
.line	2035	loadk        r16    k8 ; k8 = 195
.line	2035	loadk        r17   k46 ; k46 = 110
.line	2035	loadk        r18   k47 ; k47 = 100
.line	2035	loadk        r19   k48 ; k48 = 222
.line	2035	loadk        r20   k49 ; k49 = 176
.line	2035	loadk        r21   k50 ; k50 = 114
.line	2035	loadk        r22   k51 ; k51 = 202
.line	2035	loadk        r23   k52 ; k52 = 210
.line	2035	loadk        r24   k23 ; k23 = 115
.line	2035	loadk        r25   k24 ; k24 = 163
.line	2035	loadk        r26   k53 ; k53 = 29
.line	2035	loadk        r27   k54 ; k54 = 99
.line	2035	loadk        r28   k55 ; k55 = 240
.line	2035	loadk        r29   k56 ; k56 = 84
.line	2035	loadk        r30   k54 ; k54 = 99
.line	2035	loadk        r31   k57 ; k57 = 149
.line	2035	loadk        r32   k58 ; k58 = 208
.line	2035	loadk        r33   k59 ; k59 = 123
.line	2035	loadk        r34   k60 ; k60 = 35
.line	2035	loadk        r35   k61 ; k61 = 172
.line	2035	loadk        r36   k62 ; k62 = 136
.line	2035	loadk        r37   k31 ; k31 = 118
.line	2035	loadk        r38   k15 ; k15 = 201
.line	2035	loadk        r39   k63 ; k63 = 215
.line	2035	loadk        r40   k64 ; k64 = 112
.line	2035	loadk        r41   k65 ; k65 = 184
.line	2035	loadk        r42   k66 ; k66 = 13
.line	2035	loadk        r43   k67 ; k67 = 113
.line	2035	loadk        r44   k68 ; k68 = 236
.line	2035	loadk        r45   k13 ; k13 = 70
.line	2035	loadk        r46   k69 ; k69 = 98
.line	2035	call          r6    41     2
.line	2035	getupval      r7    u1
.line	2035	loadk         r8   k70 ; k70 = 38
.line	2035	loadk         r9   k71 ; k71 = 31
.line	2035	loadk        r10   k72 ; k72 = 198
.line	2035	loadk        r11   k73 ; k73 = 108
.line	2035	loadk        r12   k74 ; k74 = 179
.line	2035	loadk        r13   k75 ; k75 = 200
.line	2035	loadk        r14   k76 ; k76 = 42
.line	2035	loadk        r15   k77 ; k77 = 105
.line	2035	loadk        r16   k49 ; k49 = 176
.line	2035	loadk        r17   k27 ; k27 = 193
.line	2035	loadk        r18   k78 ; k78 = 101
.line	2035	loadk        r19   k79 ; k79 = 62
.line	2035	loadk        r20   k33 ; k33 = 247
.line	2035	call          r7    14     0
.line	2035	setlist       r5     0     1
.line	2035	call          r4     2     2
.line	2035	call          r3     2     2
.line	2035	gettable      r4    r3   k80 ; k80 = "CheckIsPetExhibition" (truncated)
.line	2035	move          r5    r2
.line	2035	call          r4     2     2
.line	2035	test          r4     0
.line	2035	jmp            0  l137
.line	2035	gettable      r4    r3   k81 ; k81 = "CheckCanUsePetExhibi" (truncated)
.line	2035	call          r4     1     2
.line	2035	test          r4     0
.line	2035	jmp            0  l133
.line	2035	gettable      r4    r3   k82 ; k82 = "GetPetExhibitRemainC" (truncated)
.line	2035	call          r4     1     2
.line	2035	le             0    r4    k1 ; k1 = 0
.line	2035	jmp            0  l140
.line	2035	self          r4    r0   k83 ; k83 = "TryPlayPetExhibitAct" (truncated)
.line	2035	call          r4     2     1
.line	2035	jmp            0  l140
.label	l133
.line	2035	gettabup      r4    u0   k84 ; k84 = "ShowNotice"
.line	2035	loadk         r5   k85 ; k85 = 530022
.line	2035	call          r4     2     1
.line	2035	jmp            0  l140
.label	l137
.line	2035	self          r4    r0   k86 ; k86 = "PlayEmoteInternal"
.line	2035	move          r6    r2
.line	2035	call          r4     3     1
.label	l140
.line	2035	self          r4    r0   k87 ; k87 = "ShowOrHideRing"
.line	2035	loadbool      r6     0     0
.line	2035	call          r4     3     1
.label	l143
.line	2035	return        r0     1
.line	2035	move          r0    r0
.line	2035	move          r0    r0
.line	2035	move          r0    r0
.line	2035	move          r0    r0
.line	2035	return        r0     1

.function	main/f85

.source	null
.linedefined	2058
.lastlinedefined	2074
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	14	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	32
.constant	k4	93
.constant	k5	195
.constant	k6	102
.constant	k7	186
.constant	k8	213
.constant	k9	103
.constant	k10	69
.constant	k11	185
.constant	k12	217
.constant	k13	107
.constant	k14	100
.constant	k15	254
.constant	k16	182
.constant	k17	119
.constant	k18	209
.constant	k19	208
.constant	k20	47
.constant	k21	190
.constant	k22	92
.constant	k23	83
.constant	k24	255
.constant	k25	85
.constant	k26	105
.constant	k27	164
.constant	k28	216
.constant	k29	52
.constant	k30	60
.constant	k31	235
.constant	k32	189
.constant	k33	46
.constant	k34	196
.constant	k35	204
.constant	k36	118
.constant	k37	163
.constant	k38	64
.constant	k39	231
.constant	k40	98
.constant	k41	21
.constant	k42	84
.constant	k43	112
.constant	k44	206
.constant	k45	39
.constant	k46	177
.constant	k47	125
.constant	k48	36
.constant	k49	113
.constant	k50	220
.constant	k51	"IsFitLobbyResDownloaded"
.constant	k52	"ShowNotice"
.constant	k53	43005
.constant	k54	"GetPlayerCharacter"
.constant	k55	"slua"
.constant	k56	"isValid"
.constant	k57	"AllowState"
.constant	k58	"UEnums"
.constant	k59	"EPawnState"
.constant	k60	"PlayEmote"
.constant	k61	"TriggerEntrySkillWithID"
.constant	k62	1014668
.constant	k63	82212
.constant	k64	"print"
.constant	k65	"bWriteLog"
.constant	k66	18
.constant	k67	68
.constant	k68	96
.constant	k69	191
.constant	k70	228
.constant	k71	49
.constant	k72	70
.constant	k73	167
.constant	k74	201
.constant	k75	121
.constant	k76	57
.constant	k77	251
.constant	k78	126
.constant	k79	130
.constant	k80	227
.constant	k81	109
.constant	k82	187
.constant	k83	74
.constant	k84	116
.constant	k85	244
.constant	k86	77
.constant	k87	67
.constant	k88	212
.constant	k89	115
.constant	k90	56
.constant	k91	65
.constant	k92	203
.constant	k93	215
.constant	k94	120
.constant	k95	165
.constant	k96	20
.constant	k97	58
.constant	k98	188
.constant	k99	192
.constant	k100	59
.constant	k101	87
.constant	k102	111
.constant	k103	178
.constant	k104	176
.constant	k105	99
.constant	k106	152
.constant	k107	218
.constant	k108	172
.constant	k109	82
.constant	k110	72
.constant	k111	248
.constant	k112	40

.line	2058	gettabup      r1    u0    k0 ; k0 = "require"
.line	2058	gettabup      r2    u0    k1 ; k1 = "table"
.line	2058	gettable      r2    r2    k2 ; k2 = "concat"
.line	2058	newtable      r3     1     0
.line	2058	getupval      r4    u1
.line	2058	loadk         r5    k3 ; k3 = 32
.line	2058	loadk         r6    k4 ; k4 = 93
.line	2058	loadk         r7    k5 ; k5 = 195
.line	2058	loadk         r8    k6 ; k6 = 102
.line	2058	loadk         r9    k7 ; k7 = 186
.line	2058	loadk        r10    k8 ; k8 = 213
.line	2058	loadk        r11    k9 ; k9 = 103
.line	2058	loadk        r12   k10 ; k10 = 69
.line	2058	loadk        r13   k11 ; k11 = 185
.line	2058	loadk        r14   k12 ; k12 = 217
.line	2058	loadk        r15   k13 ; k13 = 107
.line	2058	loadk        r16   k14 ; k14 = 100
.line	2058	loadk        r17   k15 ; k15 = 254
.line	2058	loadk        r18   k16 ; k16 = 182
.line	2058	loadk        r19   k17 ; k17 = 119
.line	2058	loadk        r20   k18 ; k18 = 209
.line	2058	loadk        r21   k19 ; k19 = 208
.line	2058	loadk        r22   k20 ; k20 = 47
.line	2058	loadk        r23   k21 ; k21 = 190
.line	2058	loadk        r24   k22 ; k22 = 92
.line	2058	loadk        r25   k23 ; k23 = 83
.line	2058	loadk        r26   k24 ; k24 = 255
.line	2058	loadk        r27   k25 ; k25 = 85
.line	2058	loadk        r28   k26 ; k26 = 105
.line	2058	loadk        r29   k27 ; k27 = 164
.line	2058	loadk        r30   k28 ; k28 = 216
.line	2058	loadk        r31   k29 ; k29 = 52
.line	2058	loadk        r32   k30 ; k30 = 60
.line	2058	loadk        r33   k31 ; k31 = 235
.line	2058	loadk        r34   k32 ; k32 = 189
.line	2058	loadk        r35   k33 ; k33 = 46
.line	2058	loadk        r36   k34 ; k34 = 196
.line	2058	loadk        r37   k35 ; k35 = 204
.line	2058	loadk        r38   k36 ; k36 = 118
.line	2058	loadk        r39   k37 ; k37 = 163
.line	2058	loadk        r40   k38 ; k38 = 64
.line	2058	loadk        r41   k13 ; k13 = 107
.line	2058	loadk        r42   k39 ; k39 = 231
.line	2058	loadk        r43   k38 ; k38 = 64
.line	2058	loadk        r44   k40 ; k40 = 98
.line	2058	call          r4    41     2
.line	2058	getupval      r5    u1
.line	2058	loadk         r6   k41 ; k41 = 21
.line	2058	loadk         r7   k42 ; k42 = 84
.line	2058	loadk         r8   k28 ; k28 = 216
.line	2058	loadk         r9   k43 ; k43 = 112
.line	2058	loadk        r10   k32 ; k32 = 189
.line	2058	loadk        r11   k44 ; k44 = 206
.line	2058	loadk        r12   k45 ; k45 = 39
.line	2058	loadk        r13   k26 ; k26 = 105
.line	2058	loadk        r14   k46 ; k46 = 177
.line	2058	loadk        r15    k5 ; k5 = 195
.line	2058	loadk        r16   k47 ; k47 = 125
.line	2058	loadk        r17   k48 ; k48 = 36
.line	2058	loadk        r18   k15 ; k15 = 254
.line	2058	loadk        r19   k16 ; k16 = 182
.line	2058	loadk        r20   k49 ; k49 = 113
.line	2058	loadk        r21   k50 ; k50 = 220
.line	2058	call          r5    17     0
.line	2058	setlist       r3     0     1
.line	2058	call          r2     2     2
.line	2058	call          r1     2     2
.line	2058	gettable      r2    r1   k51 ; k51 = "IsFitLobbyResDownloa" (truncated)
.line	2058	call          r2     1     2
.line	2058	test          r2     1
.line	2058	jmp            0   l76
.line	2058	gettabup      r2    u0   k52 ; k52 = "ShowNotice"
.line	2058	loadk         r3   k53 ; k53 = 43005
.line	2058	call          r2     2     1
.line	2058	return        r0     1
.label	l76
.line	2058	gettabup      r2    u2   k54 ; k54 = "GetPlayerCharacter"
.line	2058	call          r2     1     2
.line	2058	test          r2     0
.line	2058	jmp            0  l103
.line	2058	gettabup      r3    u0   k55 ; k55 = "slua"
.line	2058	gettable      r3    r3   k56 ; k56 = "isValid"
.line	2058	move          r4    r2
.line	2058	call          r3     2     2
.line	2058	test          r3     0
.line	2058	jmp            0  l103
.line	2058	self          r3    r2   k57 ; k57 = "AllowState"
.line	2058	gettabup      r5    u0   k58 ; k58 = "UEnums"
.line	2058	gettable      r5    r5   k59 ; k59 = "EPawnState"
.line	2058	gettable      r5    r5   k60 ; k60 = "PlayEmote"
.line	2058	loadbool      r6     1     0
.line	2058	call          r3     4     2
.line	2058	test          r3     0
.line	2058	jmp            0   l99
.line	2058	self          r3    r2   k61 ; k61 = "TriggerEntrySkillWit" (truncated)
.line	2058	loadk         r5   k62 ; k62 = 1014668
.line	2058	loadbool      r6     1     0
.line	2058	call          r3     4     1
.line	2058	jmp            0  l181
.label	l99
.line	2058	gettabup      r3    u0   k52 ; k52 = "ShowNotice"
.line	2058	loadk         r4   k63 ; k63 = 82212
.line	2058	call          r3     2     1
.line	2058	jmp            0  l181
.label	l103
.line	2058	gettabup      r3    u0   k64 ; k64 = "print"
.line	2058	gettabup      r4    u0   k65 ; k65 = "bWriteLog"
.line	2058	test          r4     0
.line	2058	jmp            0  l180
.line	2058	gettabup      r4    u0    k1 ; k1 = "table"
.line	2058	gettable      r4    r4    k2 ; k2 = "concat"
.line	2058	newtable      r5     1     0
.line	2058	getupval      r6    u1
.line	2058	loadk         r7   k66 ; k66 = 18
.line	2058	loadk         r8   k67 ; k67 = 68
.line	2058	loadk         r9    k5 ; k5 = 195
.line	2058	loadk        r10   k68 ; k68 = 96
.line	2058	loadk        r11   k69 ; k69 = 191
.line	2058	loadk        r12   k70 ; k70 = 228
.line	2058	loadk        r13   k71 ; k71 = 49
.line	2058	loadk        r14   k72 ; k72 = 70
.line	2058	loadk        r15   k73 ; k73 = 167
.line	2058	loadk        r16   k74 ; k74 = 201
.line	2058	loadk        r17   k75 ; k75 = 121
.line	2058	loadk        r18   k76 ; k76 = 57
.line	2058	loadk        r19   k77 ; k77 = 251
.line	2058	loadk        r20   k16 ; k16 = 182
.line	2058	loadk        r21   k78 ; k78 = 126
.line	2058	loadk        r22   k79 ; k79 = 130
.line	2058	loadk        r23   k80 ; k80 = 227
.line	2058	loadk        r24   k81 ; k81 = 109
.line	2058	loadk        r25   k82 ; k82 = 187
.line	2058	loadk        r26   k83 ; k83 = 74
.line	2058	loadk        r27   k84 ; k84 = 116
.line	2058	loadk        r28   k85 ; k85 = 244
.line	2058	loadk        r29   k86 ; k86 = 77
.line	2058	loadk        r30   k87 ; k87 = 67
.line	2058	loadk        r31   k32 ; k32 = 189
.line	2058	loadk        r32   k88 ; k88 = 212
.line	2058	loadk        r33   k89 ; k89 = 115
.line	2058	loadk        r34   k90 ; k90 = 56
.line	2058	loadk        r35   k31 ; k31 = 235
.line	2058	loadk        r36   k32 ; k32 = 189
.line	2058	loadk        r37   k91 ; k91 = 65
.line	2058	loadk        r38   k92 ; k92 = 203
.line	2058	loadk        r39   k93 ; k93 = 215
.line	2058	loadk        r40   k94 ; k94 = 120
.line	2058	loadk        r41   k95 ; k95 = 165
.line	2058	loadk        r42   k86 ; k86 = 77
.line	2058	loadk        r43   k96 ; k96 = 20
.line	2058	loadk        r44   k18 ; k18 = 209
.line	2058	loadk        r45   k10 ; k10 = 69
.line	2058	loadk        r46   k17 ; k17 = 119
.line	2058	call          r6    41     2
.line	2058	getupval      r7    u1
.line	2058	loadk         r8   k97 ; k97 = 58
.line	2058	loadk         r9   k42 ; k42 = 84
.line	2058	loadk        r10   k28 ; k28 = 216
.line	2058	loadk        r11   k38 ; k38 = 64
.line	2058	loadk        r12   k98 ; k98 = 188
.line	2058	loadk        r13   k99 ; k99 = 192
.line	2058	loadk        r14  k100 ; k100 = 59
.line	2058	loadk        r15  k101 ; k101 = 87
.line	2058	loadk        r16   k16 ; k16 = 182
.line	2058	loadk        r17   k28 ; k28 = 216
.line	2058	loadk        r18  k102 ; k102 = 111
.line	2058	loadk        r19   k90 ; k90 = 56
.line	2058	loadk        r20  k103 ; k103 = 178
.line	2058	loadk        r21  k104 ; k104 = 176
.line	2058	loadk        r22  k105 ; k105 = 99
.line	2058	loadk        r23  k106 ; k106 = 152
.line	2058	loadk        r24  k107 ; k107 = 218
.line	2058	loadk        r25  k102 ; k102 = 111
.line	2058	loadk        r26  k108 ; k108 = 172
.line	2058	loadk        r27  k109 ; k109 = 82
.line	2058	loadk        r28  k110 ; k110 = 72
.line	2058	loadk        r29  k111 ; k111 = 248
.line	2058	loadk        r30    k4 ; k4 = 93
.line	2058	loadk        r31  k112 ; k112 = 40
.line	2058	call          r7    25     0
.line	2058	setlist       r5     0     1
.line	2058	call          r4     2     2
.label	l180
.line	2058	call          r3     2     1
.label	l181
.line	2058	return        r0     1
.line	2058	move          r0    r0
.line	2058	move          r0    r0
.line	2058	move          r0    r0
.line	2058	move          r0    r0
.line	2058	return        r0     1

.function	main/f86

.source	null
.linedefined	2076
.lastlinedefined	2096
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	23	true

.constant	k0	"PetExhibitIndex"
.constant	k1	0
.constant	k2	"require"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	4
.constant	k6	80
.constant	k7	199
.constant	k8	102
.constant	k9	152
.constant	k10	212
.constant	k11	40
.constant	k12	24
.constant	k13	195
.constant	k14	110
.constant	k15	100
.constant	k16	222
.constant	k17	176
.constant	k18	114
.constant	k19	202
.constant	k20	210
.constant	k21	115
.constant	k22	163
.constant	k23	29
.constant	k24	99
.constant	k25	240
.constant	k26	84
.constant	k27	149
.constant	k28	208
.constant	k29	123
.constant	k30	35
.constant	k31	172
.constant	k32	136
.constant	k33	118
.constant	k34	201
.constant	k35	215
.constant	k36	112
.constant	k37	184
.constant	k38	13
.constant	k39	113
.constant	k40	236
.constant	k41	70
.constant	k42	98
.constant	k43	38
.constant	k44	31
.constant	k45	198
.constant	k46	108
.constant	k47	179
.constant	k48	200
.constant	k49	42
.constant	k50	105
.constant	k51	193
.constant	k52	101
.constant	k53	62
.constant	k54	247
.constant	k55	"CurrentShowState"
.constant	k56	"Flaunt"
.constant	k57	"GetPetExhibitRemainCD"
.constant	k58	"CDPanelArray"
.constant	k59	"Get"
.constant	k60	1
.constant	k61	"slua"
.constant	k62	"isValid"
.constant	k63	"SetWidgetVisibility"
.constant	k64	"UEnums"
.constant	k65	"ESlateVisibility"
.constant	k66	"SelfHitTestInvisible"
.constant	k67	"Collapsed"
.constant	k68	"CDTextArray"
.constant	k69	"SetText"
.constant	k70	"tostring"
.constant	k71	"math"
.constant	k72	"floor"

.line	2076	gettable      r1    r0    k0 ; k0 = "PetExhibitIndex"
.line	2076	lt             0    k1    r1 ; k1 = 0
.line	2076	jmp            0  l124
.line	2076	gettabup      r1    u0    k2 ; k2 = "require"
.line	2076	gettabup      r2    u0    k3 ; k3 = "table"
.line	2076	gettable      r2    r2    k4 ; k4 = "concat"
.line	2076	newtable      r3     1     0
.line	2076	getupval      r4    u1
.line	2076	loadk         r5    k5 ; k5 = 4
.line	2076	loadk         r6    k6 ; k6 = 80
.line	2076	loadk         r7    k7 ; k7 = 199
.line	2076	loadk         r8    k8 ; k8 = 102
.line	2076	loadk         r9    k9 ; k9 = 152
.line	2076	loadk        r10   k10 ; k10 = 212
.line	2076	loadk        r11   k11 ; k11 = 40
.line	2076	loadk        r12   k12 ; k12 = 24
.line	2076	loadk        r13    k9 ; k9 = 152
.line	2076	loadk        r14   k13 ; k13 = 195
.line	2076	loadk        r15   k14 ; k14 = 110
.line	2076	loadk        r16   k15 ; k15 = 100
.line	2076	loadk        r17   k16 ; k16 = 222
.line	2076	loadk        r18   k17 ; k17 = 176
.line	2076	loadk        r19   k18 ; k18 = 114
.line	2076	loadk        r20   k19 ; k19 = 202
.line	2076	loadk        r21   k20 ; k20 = 210
.line	2076	loadk        r22   k21 ; k21 = 115
.line	2076	loadk        r23   k22 ; k22 = 163
.line	2076	loadk        r24   k23 ; k23 = 29
.line	2076	loadk        r25   k24 ; k24 = 99
.line	2076	loadk        r26   k25 ; k25 = 240
.line	2076	loadk        r27   k26 ; k26 = 84
.line	2076	loadk        r28   k24 ; k24 = 99
.line	2076	loadk        r29   k27 ; k27 = 149
.line	2076	loadk        r30   k28 ; k28 = 208
.line	2076	loadk        r31   k29 ; k29 = 123
.line	2076	loadk        r32   k30 ; k30 = 35
.line	2076	loadk        r33   k31 ; k31 = 172
.line	2076	loadk        r34   k32 ; k32 = 136
.line	2076	loadk        r35   k33 ; k33 = 118
.line	2076	loadk        r36   k34 ; k34 = 201
.line	2076	loadk        r37   k35 ; k35 = 215
.line	2076	loadk        r38   k36 ; k36 = 112
.line	2076	loadk        r39   k37 ; k37 = 184
.line	2076	loadk        r40   k38 ; k38 = 13
.line	2076	loadk        r41   k39 ; k39 = 113
.line	2076	loadk        r42   k40 ; k40 = 236
.line	2076	loadk        r43   k41 ; k41 = 70
.line	2076	loadk        r44   k42 ; k42 = 98
.line	2076	call          r4    41     2
.line	2076	getupval      r5    u1
.line	2076	loadk         r6   k43 ; k43 = 38
.line	2076	loadk         r7   k44 ; k44 = 31
.line	2076	loadk         r8   k45 ; k45 = 198
.line	2076	loadk         r9   k46 ; k46 = 108
.line	2076	loadk        r10   k47 ; k47 = 179
.line	2076	loadk        r11   k48 ; k48 = 200
.line	2076	loadk        r12   k49 ; k49 = 42
.line	2076	loadk        r13   k50 ; k50 = 105
.line	2076	loadk        r14   k17 ; k17 = 176
.line	2076	loadk        r15   k51 ; k51 = 193
.line	2076	loadk        r16   k52 ; k52 = 101
.line	2076	loadk        r17   k53 ; k53 = 62
.line	2076	loadk        r18   k54 ; k54 = 247
.line	2076	call          r5    14     0
.line	2076	setlist       r3     0     1
.line	2076	call          r2     2     2
.line	2076	call          r1     2     2
.line	2076	loadk         r2    k1 ; k1 = 0
.line	2076	gettable      r3    r0   k55 ; k55 = "CurrentShowState"
.line	2076	gettabup      r4    u2   k56 ; k56 = "Flaunt"
.line	2076	eq             0    r3    r4
.line	2076	jmp            0   l76
.line	2076	gettable      r3    r1   k57 ; k57 = "GetPetExhibitRemainC" (truncated)
.line	2076	call          r3     1     2
.line	2076	move          r2    r3
.label	l76
.line	2076	gettable      r3    r0   k58 ; k58 = "CDPanelArray"
.line	2076	test          r3     0
.line	2076	jmp            0  l102
.line	2076	gettable      r3    r0   k58 ; k58 = "CDPanelArray"
.line	2076	self          r3    r3   k59 ; k59 = "Get"
.line	2076	gettable      r5    r0    k0 ; k0 = "PetExhibitIndex"
.line	2076	sub           r5    r5   k60 ; k60 = 1
.line	2076	call          r3     3     2
.line	2076	gettabup      r4    u0   k61 ; k61 = "slua"
.line	2076	gettable      r4    r4   k62 ; k62 = "isValid"
.line	2076	move          r5    r3
.line	2076	call          r4     2     2
.line	2076	test          r4     0
.line	2076	jmp            0  l102
.line	2076	self          r4    r3   k63 ; k63 = "SetWidgetVisibility"
.line	2076	lt             0    k1    r2 ; k1 = 0
.line	2076	jmp            0   l98
.line	2076	gettabup      r6    u0   k64 ; k64 = "UEnums"
.line	2076	gettable      r6    r6   k65 ; k65 = "ESlateVisibility"
.line	2076	gettable      r6    r6   k66 ; k66 = "SelfHitTestInvisible"
.line	2076	test          r6     1
.line	2076	jmp            0  l101
.label	l98
.line	2076	gettabup      r6    u0   k64 ; k64 = "UEnums"
.line	2076	gettable      r6    r6   k65 ; k65 = "ESlateVisibility"
.line	2076	gettable      r6    r6   k67 ; k67 = "Collapsed"
.label	l101
.line	2076	call          r4     3     1
.label	l102
.line	2076	gettable      r3    r0   k68 ; k68 = "CDTextArray"
.line	2076	test          r3     0
.line	2076	jmp            0  l124
.line	2076	gettable      r3    r0   k68 ; k68 = "CDTextArray"
.line	2076	self          r3    r3   k59 ; k59 = "Get"
.line	2076	gettable      r5    r0    k0 ; k0 = "PetExhibitIndex"
.line	2076	sub           r5    r5   k60 ; k60 = 1
.line	2076	call          r3     3     2
.line	2076	gettabup      r4    u0   k61 ; k61 = "slua"
.line	2076	gettable      r4    r4   k62 ; k62 = "isValid"
.line	2076	move          r5    r3
.line	2076	call          r4     2     2
.line	2076	test          r4     0
.line	2076	jmp            0  l124
.line	2076	self          r4    r3   k69 ; k69 = "SetText"
.line	2076	gettabup      r6    u0   k70 ; k70 = "tostring"
.line	2076	gettabup      r7    u0   k71 ; k71 = "math"
.line	2076	gettable      r7    r7   k72 ; k72 = "floor"
.line	2076	move          r8    r2
.line	2076	call          r7     2     0
.line	2076	call          r6     0     0
.line	2076	call          r4     0     1
.label	l124
.line	2076	return        r0     1
.line	2076	move          r0    r0
.line	2076	move          r0    r0
.line	2076	move          r0    r0
.line	2076	move          r0    r0
.line	2076	return        r0     1

.function	main/f87

.source	null
.linedefined	2098
.lastlinedefined	2104
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false

.constant	k0	"slua_GameFrontendHUD"
.constant	k1	"GetPlayerController"
.constant	k2	"slua"
.constant	k3	"isValid"
.constant	k4	"NeedHidePetExpression"

.line	2098	gettabup      r1    u0    k0 ; k0 = "slua_GameFrontendHUD"
.line	2098	self          r1    r1    k1 ; k1 = "GetPlayerController"
.line	2098	call          r1     2     2
.line	2098	gettabup      r2    u0    k2 ; k2 = "slua"
.line	2098	gettable      r2    r2    k3 ; k3 = "isValid"
.line	2098	move          r3    r1
.line	2098	call          r2     2     2
.line	2098	test          r2     0
.line	2098	jmp            0   l19
.line	2098	gettable      r2    r1    k4 ; k4 = "NeedHidePetExpressio" (truncated)
.line	2098	test          r2     0
.line	2098	jmp            0   l19
.line	2098	self          r2    r1    k4 ; k4 = "NeedHidePetExpressio" (truncated)
.line	2098	call          r2     2     2
.line	2098	test          r2     0
.line	2098	jmp            0   l19
.line	2098	loadbool      r2     1     0
.line	2098	return        r2     2
.label	l19
.line	2098	loadbool      r2     0     0
.line	2098	return        r2     2
.line	2098	return        r0     1
.line	2098	move          r0    r0
.line	2098	move          r0    r0
.line	2098	move          r0    r0
.line	2098	return        r0     1

.function	main/f88

.source	null
.linedefined	2106
.lastlinedefined	2110
.numparams	1
.is_vararg	0
.maxstacksize	37

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	23	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	18
.constant	k3	68
.constant	k4	195
.constant	k5	96
.constant	k6	191
.constant	k7	228
.constant	k8	49
.constant	k9	70
.constant	k10	167
.constant	k11	201
.constant	k12	121
.constant	k13	57
.constant	k14	251
.constant	k15	182
.constant	k16	126
.constant	k17	130
.constant	k18	252
.constant	k19	111
.constant	k20	152
.constant	k21	80
.constant	k22	229
.constant	k23	86
.constant	k24	104
.constant	k25	151
.constant	k26	211
.constant	k27	120
.constant	k28	53
.constant	k29	246
.constant	k30	138
.constant	k31	108
.constant	k32	193
.constant	k33	192
.constant	k34	122
.constant	k35	"CurrentShowState"
.constant	k36	"MiniTvExpression"
.constant	k37	"RefreshCirclePanel"

.line	2106	gettabup      r1    u0    k0 ; k0 = "print"
.line	2106	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	2106	test          r2     0
.line	2106	jmp            0   l41
.line	2106	getupval      r2    u1
.line	2106	loadk         r3    k2 ; k2 = 18
.line	2106	loadk         r4    k3 ; k3 = 68
.line	2106	loadk         r5    k4 ; k4 = 195
.line	2106	loadk         r6    k5 ; k5 = 96
.line	2106	loadk         r7    k6 ; k6 = 191
.line	2106	loadk         r8    k7 ; k7 = 228
.line	2106	loadk         r9    k8 ; k8 = 49
.line	2106	loadk        r10    k9 ; k9 = 70
.line	2106	loadk        r11   k10 ; k10 = 167
.line	2106	loadk        r12   k11 ; k11 = 201
.line	2106	loadk        r13   k12 ; k12 = 121
.line	2106	loadk        r14   k13 ; k13 = 57
.line	2106	loadk        r15   k14 ; k14 = 251
.line	2106	loadk        r16   k15 ; k15 = 182
.line	2106	loadk        r17   k16 ; k16 = 126
.line	2106	loadk        r18   k17 ; k17 = 130
.line	2106	loadk        r19   k18 ; k18 = 252
.line	2106	loadk        r20   k19 ; k19 = 111
.line	2106	loadk        r21   k20 ; k20 = 152
.line	2106	loadk        r22    k9 ; k9 = 70
.line	2106	loadk        r23   k21 ; k21 = 80
.line	2106	loadk        r24   k22 ; k22 = 229
.line	2106	loadk        r25   k23 ; k23 = 86
.line	2106	loadk        r26   k24 ; k24 = 104
.line	2106	loadk        r27   k25 ; k25 = 151
.line	2106	loadk        r28   k26 ; k26 = 211
.line	2106	loadk        r29   k27 ; k27 = 120
.line	2106	loadk        r30   k28 ; k28 = 53
.line	2106	loadk        r31   k29 ; k29 = 246
.line	2106	loadk        r32   k30 ; k30 = 138
.line	2106	loadk        r33   k31 ; k31 = 108
.line	2106	loadk        r34   k32 ; k32 = 193
.line	2106	loadk        r35   k33 ; k33 = 192
.line	2106	loadk        r36   k34 ; k34 = 122
.line	2106	call          r2    35     2
.label	l41
.line	2106	gettable      r3    r0   k35 ; k35 = "CurrentShowState"
.line	2106	call          r1     3     1
.line	2106	gettabup      r1    u2   k36 ; k36 = "MiniTvExpression"
.line	2106	settable      r0   k35    r1 ; k35 = "CurrentShowState"
.line	2106	self          r1    r0   k37 ; k37 = "RefreshCirclePanel"
.line	2106	call          r1     2     1
.line	2106	return        r0     1
.line	2106	move          r0    r0
.line	2106	move          r0    r0
.line	2106	return        r0     1

.function	main/f89

.source	null
.linedefined	2112
.lastlinedefined	2186
.numparams	1
.is_vararg	0
.maxstacksize	66

.upvalue	"_ENV"	23	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	14	true
.upvalue	"U4"	18	true
.upvalue	"U5"	21	true

.constant	k0	"CurrentShowState"
.constant	k1	"MiniTvExpression"
.constant	k2	"print"
.constant	k3	"bWriteLog"
.constant	k4	18
.constant	k5	68
.constant	k6	195
.constant	k7	96
.constant	k8	191
.constant	k9	228
.constant	k10	49
.constant	k11	70
.constant	k12	167
.constant	k13	201
.constant	k14	121
.constant	k15	57
.constant	k16	251
.constant	k17	182
.constant	k18	126
.constant	k19	130
.constant	k20	225
.constant	k21	100
.constant	k22	188
.constant	k23	65
.constant	k24	226
.constant	k25	81
.constant	k26	75
.constant	k27	172
.constant	k28	210
.constant	k29	115
.constant	k30	14
.constant	k31	244
.constant	k32	140
.constant	k33	120
.constant	k34	216
.constant	k35	209
.constant	k36	116
.constant	k37	185
.constant	k38	80
.constant	k39	93
.constant	k40	238
.constant	k41	71
.constant	k42	"RefreshMiniTvShowSwitch"
.constant	k43	"PrepareMiniTvExpressionList"
.constant	k44	"pairs"
.constant	k45	"EmoteNameArray"
.constant	k46	"SetText"
.constant	k47	"SlotSwitcherArray"
.constant	k48	"SetActiveWidgetIndex"
.constant	k49	1
.constant	k50	"GetPlayerController"
.constant	k51	"slua"
.constant	k52	"isValid"
.constant	k53	"IsInPetSpectator"
.constant	k54	"bIsSpectatingAssistantPet"
.constant	k55	"bIsMiniTvStandalone"
.constant	k56	"bShowMiniTv"
.constant	k57	"MiniTvExpressionList"
.constant	k58	0
.constant	k59	"WidgetSwitcher_Center"
.constant	k60	"Text_Pet"
.constant	k61	"LocUtil"
.constant	k62	"GetLocalizeResStr"
.constant	k63	"Button_ShowPet"
.constant	k64	"SetWidgetVisibility"
.constant	k65	"UEnums"
.constant	k66	"ESlateVisibility"
.constant	k67	"Collapsed"
.constant	k68	2
.constant	k69	"IndexToMiniTvExpression"
.constant	k70	"EmoteImageArray"
.constant	k71	"Num"
.constant	k72	"Get"
.constant	k73	"CDataTable"
.constant	k74	"GetTableData"
.constant	k75	19
.constant	k76	84
.constant	k77	222
.constant	k78	66
.constant	k79	183
.constant	k80	213
.constant	k81	32
.constant	k82	89
.constant	k83	187
.constant	k84	248
.constant	k85	107
.constant	k86	40
.constant	k87	254
.constant	k88	"ID"
.constant	k89	"require"
.constant	k90	102
.constant	k91	186
.constant	k92	103
.constant	k93	69
.constant	k94	217
.constant	k95	21
.constant	k96	231
.constant	k97	176
.constant	k98	79
.constant	k99	193
.constant	k100	86
.constant	k101	83
.constant	k102	109
.constant	k103	235
.constant	k104	110
.constant	k105	51
.constant	k106	"PetActionID"
.constant	k107	85
.constant	k108	37
.constant	k109	252
.constant	k110	247
.constant	k111	101
.constant	k112	236
.constant	k113	174
.constant	k114	90
.constant	k115	72
.constant	k116	"GetItemSmallIcon"
.constant	k117	"table"
.constant	k118	"concat"
.constant	k119	54
.constant	k120	10
.constant	k121	95
.constant	k122	206
.constant	k123	45
.constant	k124	94
.constant	k125	35
.constant	k126	177
.constant	k127	161
.constant	k128	"SetTexture"
.constant	k129	"sync"
.constant	k130	false
.constant	k131	"bHasAddKnownMissing"
.constant	k132	"IsLocked"
.constant	k133	"SetColorAndOpacity"
.constant	k134	"FLinearColor"
.constant	k135	0.5
.constant	k136	"LockImageArray"
.constant	k137	"SelfHitTestInvisible"

.line	2112	gettable      r1    r0    k0 ; k0 = "CurrentShowState"
.line	2112	gettabup      r2    u0    k1 ; k1 = "MiniTvExpression"
.line	2112	eq             1    r1    r2
.line	2112	jmp            0    l6
.line	2112	return        r0     1
.label	l6
.line	2112	gettabup      r1    u1    k2 ; k2 = "print"
.line	2112	gettabup      r2    u1    k3 ; k3 = "bWriteLog"
.line	2112	test          r2     0
.line	2112	jmp            0   l51
.line	2112	getupval      r2    u2
.line	2112	loadk         r3    k4 ; k4 = 18
.line	2112	loadk         r4    k5 ; k5 = 68
.line	2112	loadk         r5    k6 ; k6 = 195
.line	2112	loadk         r6    k7 ; k7 = 96
.line	2112	loadk         r7    k8 ; k8 = 191
.line	2112	loadk         r8    k9 ; k9 = 228
.line	2112	loadk         r9   k10 ; k10 = 49
.line	2112	loadk        r10   k11 ; k11 = 70
.line	2112	loadk        r11   k12 ; k12 = 167
.line	2112	loadk        r12   k13 ; k13 = 201
.line	2112	loadk        r13   k14 ; k14 = 121
.line	2112	loadk        r14   k15 ; k15 = 57
.line	2112	loadk        r15   k16 ; k16 = 251
.line	2112	loadk        r16   k17 ; k17 = 182
.line	2112	loadk        r17   k18 ; k18 = 126
.line	2112	loadk        r18   k19 ; k19 = 130
.line	2112	loadk        r19   k20 ; k20 = 225
.line	2112	loadk        r20   k21 ; k21 = 100
.line	2112	loadk        r21   k22 ; k22 = 188
.line	2112	loadk        r22   k23 ; k23 = 65
.line	2112	loadk        r23   k23 ; k23 = 65
.line	2112	loadk        r24   k24 ; k24 = 226
.line	2112	loadk        r25   k25 ; k25 = 81
.line	2112	loadk        r26   k26 ; k26 = 75
.line	2112	loadk        r27   k27 ; k27 = 172
.line	2112	loadk        r28   k28 ; k28 = 210
.line	2112	loadk        r29   k29 ; k29 = 115
.line	2112	loadk        r30   k30 ; k30 = 14
.line	2112	loadk        r31   k31 ; k31 = 244
.line	2112	loadk        r32   k32 ; k32 = 140
.line	2112	loadk        r33   k33 ; k33 = 120
.line	2112	loadk        r34   k34 ; k34 = 216
.line	2112	loadk        r35   k35 ; k35 = 209
.line	2112	loadk        r36   k36 ; k36 = 116
.line	2112	loadk        r37   k37 ; k37 = 185
.line	2112	loadk        r38   k38 ; k38 = 80
.line	2112	loadk        r39   k39 ; k39 = 93
.line	2112	loadk        r40   k40 ; k40 = 238
.line	2112	loadk        r41   k41 ; k41 = 71
.line	2112	call          r2    40     2
.label	l51
.line	2112	call          r1     2     1
.line	2112	self          r1    r0   k42 ; k42 = "RefreshMiniTvShowSwi" (truncated)
.line	2112	call          r1     2     1
.line	2112	self          r1    r0   k43 ; k43 = "PrepareMiniTvExpress" (truncated)
.line	2112	call          r1     2     1
.line	2112	gettabup      r1    u1   k44 ; k44 = "pairs"
.line	2112	gettable      r2    r0   k45 ; k45 = "EmoteNameArray"
.line	2112	call          r1     2     4
.line	2112	jmp            0   l66
.line	2112	test          r5     0
.line	2112	jmp            0   l66
.line	2112	self          r6    r5   k46 ; k46 = "SetText"
.line	2112	getupval      r8    u2
.line	2112	call          r8     1     2
.line	2112	call          r6     3     1
.label	l66
.line	2112	move          r0    r0
.line	2112	move          r0    r0
.line	2112	gettabup      r1    u1   k44 ; k44 = "pairs"
.line	2112	gettable      r2    r0   k47 ; k47 = "SlotSwitcherArray"
.line	2112	call          r1     2     4
.line	2112	jmp            0   l77
.line	2112	test          r5     0
.line	2112	jmp            0   l77
.line	2112	self          r6    r5   k48 ; k48 = "SetActiveWidgetIndex"
.line	2112	loadk         r8   k49 ; k49 = 1
.line	2112	call          r6     3     1
.label	l77
.line	2112	move          r0    r0
.line	2112	move          r0    r0
.line	2112	gettabup      r1    u3   k50 ; k50 = "GetPlayerController"
.line	2112	call          r1     1     2
.line	2112	gettabup      r2    u1   k51 ; k51 = "slua"
.line	2112	gettable      r2    r2   k52 ; k52 = "isValid"
.line	2112	move          r3    r1
.line	2112	call          r2     2     2
.line	2112	test          r2     0
.line	2112	jmp            0   l94
.line	2112	gettable      r2    r1   k53 ; k53 = "IsInPetSpectator"
.line	2112	test          r2     0
.line	2112	jmp            0   l94
.line	2112	self          r2    r1   k53 ; k53 = "IsInPetSpectator"
.line	2112	call          r2     2     2
.line	2112	test          r2     1
.line	2112	jmp            0   l95
.label	l94
.line	2112	loadbool      r2     0     0
.label	l95
.line	2112	testset       r3    r2     0
.line	2112	jmp            0   l99
.line	2112	gettable      r3    r0   k54 ; k54 = "bIsSpectatingAssista" (truncated)
.line	2112	not           r3    r3
.label	l99
.line	2112	test          r2     1
.line	2112	jmp            0  l107
.line	2112	gettable      r4    r0   k55 ; k55 = "bIsMiniTvStandalone"
.line	2112	test          r4     0
.line	2112	jmp            0  l108
.line	2112	gettable      r4    r0   k56 ; k56 = "bShowMiniTv"
.line	2112	not           r4    r4
.line	2112	jmp            0  l109
.label	l107
.line	2112	loadbool      r4     0     1
.label	l108
.line	2112	loadbool      r4     1     0
.label	l109
.line	2112	gettable      r5    r0   k57 ; k57 = "MiniTvExpressionList"
.line	2112	test          r5     0
.line	2112	jmp            0  l117
.line	2112	gettable      r5    r0   k57 ; k57 = "MiniTvExpressionList"
.line	2112	len           r5    r5
.line	2112	le             1    r5   k58 ; k58 = 0
.line	2112	jmp            0  l117
.line	2112	loadbool      r5     0     1
.label	l117
.line	2112	loadbool      r5     1     0
.line	2112	testset       r6    r3     1
.line	2112	jmp            0  l123
.line	2112	testset       r6    r4     1
.line	2112	jmp            0  l123
.line	2112	move          r6    r5
.label	l123
.line	2112	test          r6     0
.line	2112	jmp            0  l143
.line	2112	gettable      r7    r0   k59 ; k59 = "WidgetSwitcher_Cente" (truncated)
.line	2112	self          r7    r7   k48 ; k48 = "SetActiveWidgetIndex"
.line	2112	loadk         r9   k49 ; k49 = 1
.line	2112	call          r7     3     1
.line	2112	gettable      r7    r0   k60 ; k60 = "Text_Pet"
.line	2112	self          r7    r7   k46 ; k46 = "SetText"
.line	2112	gettabup      r9    u1   k61 ; k61 = "LocUtil"
.line	2112	gettable      r9    r9   k62 ; k62 = "GetLocalizeResStr"
.line	2112	getupval     r10    u4
.line	2112	call          r9     2     0
.line	2112	call          r7     0     1
.line	2112	gettable      r7    r0   k63 ; k63 = "Button_ShowPet"
.line	2112	self          r7    r7   k64 ; k64 = "SetWidgetVisibility"
.line	2112	gettabup      r9    u1   k65 ; k65 = "UEnums"
.line	2112	gettable      r9    r9   k66 ; k66 = "ESlateVisibility"
.line	2112	gettable      r9    r9   k67 ; k67 = "Collapsed"
.line	2112	call          r7     3     1
.line	2112	return        r0     1
.label	l143
.line	2112	test          r2     0
.line	2112	jmp            0  l150
.line	2112	gettable      r7    r0   k59 ; k59 = "WidgetSwitcher_Cente" (truncated)
.line	2112	self          r7    r7   k48 ; k48 = "SetActiveWidgetIndex"
.line	2112	loadk         r9   k68 ; k68 = 2
.line	2112	call          r7     3     1
.line	2112	jmp            0  l154
.label	l150
.line	2112	gettable      r7    r0   k59 ; k59 = "WidgetSwitcher_Cente" (truncated)
.line	2112	self          r7    r7   k48 ; k48 = "SetActiveWidgetIndex"
.line	2112	loadk         r9   k58 ; k58 = 0
.line	2112	call          r7     3     1
.label	l154
.line	2112	gettable      r7    r0   k63 ; k63 = "Button_ShowPet"
.line	2112	self          r7    r7   k64 ; k64 = "SetWidgetVisibility"
.line	2112	gettabup      r9    u1   k65 ; k65 = "UEnums"
.line	2112	gettable      r9    r9   k66 ; k66 = "ESlateVisibility"
.line	2112	gettable      r9    r9   k67 ; k67 = "Collapsed"
.line	2112	call          r7     3     1
.line	2112	newtable      r7     0     0
.line	2112	settable      r0   k69    r7 ; k69 = "IndexToMiniTvExpress" (truncated)
.line	2112	gettabup      r7    u1   k44 ; k44 = "pairs"
.line	2112	gettable      r8    r0   k57 ; k57 = "MiniTvExpressionList"
.line	2112	call          r7     2     4
.line	2112	jmp            0  l467
.line	2112	sub          r12   r10   k49 ; k49 = 1
.line	2112	gettable     r13    r0   k70 ; k70 = "EmoteImageArray"
.line	2112	self         r13   r13   k71 ; k71 = "Num"
.line	2112	call         r13     2     2
.line	2112	le             1   r13   r12
.line	2112	jmp            0  l469
.line	2112	gettable     r12    r0   k70 ; k70 = "EmoteImageArray"
.line	2112	self         r12   r12   k72 ; k72 = "Get"
.line	2112	sub          r14   r10   k49 ; k49 = 1
.line	2112	call         r12     3     2
.line	2112	gettable     r13    r0   k47 ; k47 = "SlotSwitcherArray"
.line	2112	self         r13   r13   k72 ; k72 = "Get"
.line	2112	sub          r15   r10   k49 ; k49 = 1
.line	2112	call         r13     3     2
.line	2112	gettable     r14    r0   k45 ; k45 = "EmoteNameArray"
.line	2112	self         r14   r14   k72 ; k72 = "Get"
.line	2112	sub          r16   r10   k49 ; k49 = 1
.line	2112	call         r14     3     2
.line	2112	gettabup     r15    u1   k73 ; k73 = "CDataTable"
.line	2112	gettable     r15   r15   k74 ; k74 = "GetTableData"
.line	2112	getupval     r16    u2
.line	2112	loadk        r17   k75 ; k75 = 19
.line	2112	loadk        r18   k76 ; k76 = 84
.line	2112	loadk        r19   k77 ; k77 = 222
.line	2112	loadk        r20   k78 ; k78 = 66
.line	2112	loadk        r21   k79 ; k79 = 183
.line	2112	loadk        r22   k80 ; k80 = 213
.line	2112	loadk        r23   k81 ; k81 = 32
.line	2112	loadk        r24   k82 ; k82 = 89
.line	2112	loadk        r25   k83 ; k83 = 187
.line	2112	loadk        r26   k84 ; k84 = 248
.line	2112	loadk        r27   k85 ; k85 = 107
.line	2112	loadk        r28   k86 ; k86 = 40
.line	2112	loadk        r29   k87 ; k87 = 254
.line	2112	loadk        r30   k22 ; k22 = 188
.line	2112	call         r16    15     2
.line	2112	gettable     r17   r11   k88 ; k88 = "ID"
.line	2112	call         r15     3     2
.line	2112	test         r12     0
.line	2112	jmp            0  l467
.line	2112	test         r13     0
.line	2112	jmp            0  l467
.line	2112	test         r14     0
.line	2112	jmp            0  l467
.line	2112	test         r15     0
.line	2112	jmp            0  l467
.line	2112	self         r16   r13   k48 ; k48 = "SetActiveWidgetIndex"
.line	2112	loadk        r18   k58 ; k58 = 0
.line	2112	call         r16     3     1
.line	2112	gettabup     r16    u1   k89 ; k89 = "require"
.line	2112	getupval     r17    u2
.line	2112	loadk        r18   k81 ; k81 = 32
.line	2112	loadk        r19   k39 ; k39 = 93
.line	2112	loadk        r20    k6 ; k6 = 195
.line	2112	loadk        r21   k90 ; k90 = 102
.line	2112	loadk        r22   k91 ; k91 = 186
.line	2112	loadk        r23   k80 ; k80 = 213
.line	2112	loadk        r24   k92 ; k92 = 103
.line	2112	loadk        r25   k93 ; k93 = 69
.line	2112	loadk        r26   k37 ; k37 = 185
.line	2112	loadk        r27   k94 ; k94 = 217
.line	2112	loadk        r28   k85 ; k85 = 107
.line	2112	loadk        r29   k95 ; k95 = 21
.line	2112	loadk        r30   k96 ; k96 = 231
.line	2112	loadk        r31   k97 ; k97 = 176
.line	2112	loadk        r32   k98 ; k98 = 79
.line	2112	loadk        r33   k77 ; k77 = 222
.line	2112	loadk        r34   k99 ; k99 = 193
.line	2112	loadk        r35    k7 ; k7 = 96
.line	2112	loadk        r36   k79 ; k79 = 183
.line	2112	loadk        r37  k100 ; k100 = 86
.line	2112	loadk        r38  k101 ; k101 = 83
.line	2112	loadk        r39   k87 ; k87 = 254
.line	2112	loadk        r40   k26 ; k26 = 75
.line	2112	loadk        r41  k102 ; k102 = 109
.line	2112	loadk        r42  k103 ; k103 = 235
.line	2112	loadk        r43   k13 ; k13 = 201
.line	2112	loadk        r44  k104 ; k104 = 110
.line	2112	loadk        r45  k105 ; k105 = 51
.line	2112	loadk        r46   k40 ; k40 = 238
.line	2112	call         r17    30     2
.line	2112	call         r16     2     2
.line	2112	gettable     r17   r15  k106 ; k106 = "PetActionID"
.line	2112	gettabup     r18    u1   k89 ; k89 = "require"
.line	2112	getupval     r19    u2
.line	2112	loadk        r20   k81 ; k81 = 32
.line	2112	loadk        r21   k39 ; k39 = 93
.line	2112	loadk        r22    k6 ; k6 = 195
.line	2112	loadk        r23   k90 ; k90 = 102
.line	2112	loadk        r24   k91 ; k91 = 186
.line	2112	loadk        r25   k80 ; k80 = 213
.line	2112	loadk        r26   k92 ; k92 = 103
.line	2112	loadk        r27  k107 ; k107 = 85
.line	2112	loadk        r28   k91 ; k91 = 186
.line	2112	loadk        r29   k99 ; k99 = 193
.line	2112	loadk        r30   k92 ; k92 = 103
.line	2112	loadk        r31  k108 ; k108 = 37
.line	2112	loadk        r32  k109 ; k109 = 252
.line	2112	loadk        r33  k110 ; k110 = 247
.line	2112	loadk        r34  k111 ; k111 = 101
.line	2112	loadk        r35   k35 ; k35 = 209
.line	2112	loadk        r36  k112 ; k112 = 236
.line	2112	loadk        r37   k36 ; k36 = 116
.line	2112	loadk        r38  k113 ; k113 = 174
.line	2112	loadk        r39  k114 ; k114 = 90
.line	2112	loadk        r40  k115 ; k115 = 72
.line	2112	call         r19    22     2
.line	2112	call         r18     2     2
.line	2112	gettable     r19   r18  k116 ; k116 = "GetItemSmallIcon"
.line	2112	move         r20   r17
.line	2112	move         r21   r12
.line	2112	call         r19     3     4
.line	2112	gettabup     r22    u1    k2 ; k2 = "print"
.line	2112	gettabup     r23    u1    k3 ; k3 = "bWriteLog"
.line	2112	test         r23     0
.line	2112	jmp            0  l336
.line	2112	gettabup     r23    u1  k117 ; k117 = "table"
.line	2112	gettable     r23   r23  k118 ; k118 = "concat"
.line	2112	newtable     r24     1     0
.line	2112	getupval     r25    u2
.line	2112	loadk        r26    k4 ; k4 = 18
.line	2112	loadk        r27    k5 ; k5 = 68
.line	2112	loadk        r28    k6 ; k6 = 195
.line	2112	loadk        r29    k7 ; k7 = 96
.line	2112	loadk        r30    k8 ; k8 = 191
.line	2112	loadk        r31    k9 ; k9 = 228
.line	2112	loadk        r32   k10 ; k10 = 49
.line	2112	loadk        r33   k11 ; k11 = 70
.line	2112	loadk        r34   k12 ; k12 = 167
.line	2112	loadk        r35   k13 ; k13 = 201
.line	2112	loadk        r36   k14 ; k14 = 121
.line	2112	loadk        r37   k15 ; k15 = 57
.line	2112	loadk        r38   k16 ; k16 = 251
.line	2112	loadk        r39   k17 ; k17 = 182
.line	2112	loadk        r40   k18 ; k18 = 126
.line	2112	loadk        r41   k19 ; k19 = 130
.line	2112	loadk        r42   k20 ; k20 = 225
.line	2112	loadk        r43   k21 ; k21 = 100
.line	2112	loadk        r44   k22 ; k22 = 188
.line	2112	loadk        r45   k23 ; k23 = 65
.line	2112	loadk        r46   k23 ; k23 = 65
.line	2112	loadk        r47   k24 ; k24 = 226
.line	2112	loadk        r48   k25 ; k25 = 81
.line	2112	loadk        r49   k26 ; k26 = 75
.line	2112	loadk        r50   k27 ; k27 = 172
.line	2112	loadk        r51   k28 ; k28 = 210
.line	2112	loadk        r52   k29 ; k29 = 115
.line	2112	loadk        r53   k30 ; k30 = 14
.line	2112	loadk        r54   k31 ; k31 = 244
.line	2112	loadk        r55   k32 ; k32 = 140
.line	2112	loadk        r56   k33 ; k33 = 120
.line	2112	loadk        r57   k34 ; k34 = 216
.line	2112	loadk        r58   k35 ; k35 = 209
.line	2112	loadk        r59   k36 ; k36 = 116
.line	2112	loadk        r60   k37 ; k37 = 185
.line	2112	loadk        r61   k38 ; k38 = 80
.line	2112	loadk        r62   k39 ; k39 = 93
.line	2112	loadk        r63   k40 ; k40 = 238
.line	2112	loadk        r64   k41 ; k41 = 71
.line	2112	loadk        r65  k119 ; k119 = 54
.line	2112	call         r25    41     2
.line	2112	getupval     r26    u2
.line	2112	loadk        r27  k120 ; k120 = 10
.line	2112	loadk        r28  k121 ; k121 = 95
.line	2112	loadk        r29  k122 ; k122 = 206
.line	2112	loadk        r30   k90 ; k90 = 102
.line	2112	loadk        r31   k27 ; k27 = 172
.line	2112	call         r26     6     0
.line	2112	setlist      r24     0     1
.line	2112	call         r23     2     2
.label	l336
.line	2112	move         r24   r17
.line	2112	move         r25   r19
.line	2112	move         r26   r20
.line	2112	move         r27   r21
.line	2112	call         r22     6     1
.line	2112	test         r21     0
.line	2112	jmp            0  l414
.line	2112	gettabup     r22    u1    k2 ; k2 = "print"
.line	2112	gettabup     r23    u1    k3 ; k3 = "bWriteLog"
.line	2112	test         r23     0
.line	2112	jmp            0  l405
.line	2112	gettabup     r23    u1  k117 ; k117 = "table"
.line	2112	gettable     r23   r23  k118 ; k118 = "concat"
.line	2112	newtable     r24     1     0
.line	2112	getupval     r25    u2
.line	2112	loadk        r26    k4 ; k4 = 18
.line	2112	loadk        r27    k5 ; k5 = 68
.line	2112	loadk        r28    k6 ; k6 = 195
.line	2112	loadk        r29    k7 ; k7 = 96
.line	2112	loadk        r30    k8 ; k8 = 191
.line	2112	loadk        r31    k9 ; k9 = 228
.line	2112	loadk        r32   k10 ; k10 = 49
.line	2112	loadk        r33   k11 ; k11 = 70
.line	2112	loadk        r34   k12 ; k12 = 167
.line	2112	loadk        r35   k13 ; k13 = 201
.line	2112	loadk        r36   k14 ; k14 = 121
.line	2112	loadk        r37   k15 ; k15 = 57
.line	2112	loadk        r38   k16 ; k16 = 251
.line	2112	loadk        r39   k17 ; k17 = 182
.line	2112	loadk        r40   k18 ; k18 = 126
.line	2112	loadk        r41   k19 ; k19 = 130
.line	2112	loadk        r42   k20 ; k20 = 225
.line	2112	loadk        r43   k21 ; k21 = 100
.line	2112	loadk        r44   k22 ; k22 = 188
.line	2112	loadk        r45   k23 ; k23 = 65
.line	2112	loadk        r46   k23 ; k23 = 65
.line	2112	loadk        r47   k24 ; k24 = 226
.line	2112	loadk        r48   k25 ; k25 = 81
.line	2112	loadk        r49   k26 ; k26 = 75
.line	2112	loadk        r50   k27 ; k27 = 172
.line	2112	loadk        r51   k28 ; k28 = 210
.line	2112	loadk        r52   k29 ; k29 = 115
.line	2112	loadk        r53   k30 ; k30 = 14
.line	2112	loadk        r54   k31 ; k31 = 244
.line	2112	loadk        r55   k32 ; k32 = 140
.line	2112	loadk        r56   k33 ; k33 = 120
.line	2112	loadk        r57   k34 ; k34 = 216
.line	2112	loadk        r58   k35 ; k35 = 209
.line	2112	loadk        r59   k36 ; k36 = 116
.line	2112	loadk        r60   k37 ; k37 = 185
.line	2112	loadk        r61   k38 ; k38 = 80
.line	2112	loadk        r62   k39 ; k39 = 93
.line	2112	loadk        r63   k40 ; k40 = 238
.line	2112	loadk        r64   k41 ; k41 = 71
.line	2112	loadk        r65  k119 ; k119 = 54
.line	2112	call         r25    41     2
.line	2112	getupval     r26    u2
.line	2112	loadk        r27  k123 ; k123 = 45
.line	2112	loadk        r28  k124 ; k124 = 94
.line	2112	loadk        r29   k77 ; k77 = 222
.line	2112	loadk        r30  k125 ; k125 = 35
.line	2112	loadk        r31  k126 ; k126 = 177
.line	2112	loadk        r32   k94 ; k94 = 217
.line	2112	loadk        r33   k81 ; k81 = 32
.line	2112	loadk        r34   k93 ; k93 = 69
.line	2112	loadk        r35  k127 ; k127 = 161
.line	2112	call         r26    10     0
.line	2112	setlist      r24     0     1
.line	2112	call         r23     2     2
.label	l405
.line	2112	move         r24   r10
.line	2112	call         r22     3     1
.line	2112	gettable     r22   r16  k128 ; k128 = "SetTexture"
.line	2112	move         r23   r12
.line	2112	getupval     r24    u5
.line	2112	newtable     r25     0     1
.line	2112	settable     r25  k129  k130 ; k130 = false
.line	2112	call         r22     4     1
.line	2112	jmp            0  l422
.label	l414
.line	2112	newtable     r22     0     2
.line	2112	settable     r22  k129  k130 ; k130 = false
.line	2112	settable     r22  k131   r20 ; k131 = "bHasAddKnownMissing"
.line	2112	gettable     r23   r16  k128 ; k128 = "SetTexture"
.line	2112	move         r24   r12
.line	2112	move         r25   r19
.line	2112	move         r26   r22
.line	2112	call         r23     4     1
.label	l422
.line	2112	gettable     r22    r0   k69 ; k69 = "IndexToMiniTvExpress" (truncated)
.line	2112	gettable     r23   r11   k88 ; k88 = "ID"
.line	2112	settable     r22   r10   r23
.line	2112	gettable     r22   r11  k132 ; k132 = "IsLocked"
.line	2112	test         r22     0
.line	2112	jmp            0  l448
.line	2112	self         r22   r12  k133 ; k133 = "SetColorAndOpacity"
.line	2112	gettabup     r24    u1  k134 ; k134 = "FLinearColor"
.line	2112	loadk        r25   k49 ; k49 = 1
.line	2112	loadk        r26   k49 ; k49 = 1
.line	2112	loadk        r27   k49 ; k49 = 1
.line	2112	loadk        r28  k135 ; k135 = 0.5
.line	2112	call         r24     5     0
.line	2112	call         r22     0     1
.line	2112	gettable     r22    r0  k136 ; k136 = "LockImageArray"
.line	2112	self         r22   r22   k72 ; k72 = "Get"
.line	2112	sub          r24   r10   k49 ; k49 = 1
.line	2112	call         r22     3     2
.line	2112	test         r22     0
.line	2112	jmp            0  l467
.line	2112	self         r23   r22   k64 ; k64 = "SetWidgetVisibility"
.line	2112	gettabup     r25    u1   k65 ; k65 = "UEnums"
.line	2112	gettable     r25   r25   k66 ; k66 = "ESlateVisibility"
.line	2112	gettable     r25   r25  k137 ; k137 = "SelfHitTestInvisible"
.line	2112	call         r23     3     1
.line	2112	jmp            0  l467
.label	l448
.line	2112	self         r22   r12  k133 ; k133 = "SetColorAndOpacity"
.line	2112	gettabup     r24    u1  k134 ; k134 = "FLinearColor"
.line	2112	loadk        r25   k49 ; k49 = 1
.line	2112	loadk        r26   k49 ; k49 = 1
.line	2112	loadk        r27   k49 ; k49 = 1
.line	2112	loadk        r28   k49 ; k49 = 1
.line	2112	call         r24     5     0
.line	2112	call         r22     0     1
.line	2112	gettable     r22    r0  k136 ; k136 = "LockImageArray"
.line	2112	self         r22   r22   k72 ; k72 = "Get"
.line	2112	sub          r24   r10   k49 ; k49 = 1
.line	2112	call         r22     3     2
.line	2112	test         r22     0
.line	2112	jmp            0  l467
.line	2112	self         r23   r22   k64 ; k64 = "SetWidgetVisibility"
.line	2112	gettabup     r25    u1   k65 ; k65 = "UEnums"
.line	2112	gettable     r25   r25   k66 ; k66 = "ESlateVisibility"
.line	2112	gettable     r25   r25   k67 ; k67 = "Collapsed"
.line	2112	call         r23     3     1
.label	l467
.line	2112	move          r0    r0
.line	2112	move          r0    r0
.label	l469
.line	2112	return        r0     1
.line	2112	move          r0    r0
.line	2112	move          r0    r0
.line	2112	return        r0     1

.function	main/f90

.source	null
.linedefined	2188
.lastlinedefined	2203
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	14	true
.upvalue	"U3"	19	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"CommonModuleConfig"
.constant	k3	"SettingModule"
.constant	k4	"bShowMiniTv"
.constant	k5	"GetOptionValue"
.constant	k6	16
.constant	k7	89
.constant	k8	197
.constant	k9	116
.constant	k10	153
.constant	k11	200
.constant	k12	39
.constant	k13	95
.constant	k14	129
.constant	k15	218
.constant	k16	67
.constant	k17	36
.constant	k18	212
.constant	k19	176
.constant	k20	119
.constant	k21	208
.constant	k22	199
.constant	k23	104
.constant	k24	180
.constant	k25	84
.constant	k26	"print"
.constant	k27	"bWriteLog"
.constant	k28	"table"
.constant	k29	"concat"
.constant	k30	18
.constant	k31	68
.constant	k32	195
.constant	k33	96
.constant	k34	191
.constant	k35	228
.constant	k36	49
.constant	k37	70
.constant	k38	167
.constant	k39	201
.constant	k40	121
.constant	k41	57
.constant	k42	251
.constant	k43	182
.constant	k44	126
.constant	k45	130
.constant	k46	225
.constant	k47	100
.constant	k48	188
.constant	k49	65
.constant	k50	226
.constant	k51	81
.constant	k52	75
.constant	k53	172
.constant	k54	210
.constant	k55	115
.constant	k56	14
.constant	k57	244
.constant	k58	154
.constant	k59	66
.constant	k60	189
.constant	k61	74
.constant	k62	64
.constant	k63	54
.constant	k64	33
.constant	k65	98
.constant	k66	194
.constant	k67	108
.constant	k68	163
.constant	k69	236
.constant	k70	32
.constant	k71	88
.constant	k72	248
.constant	k73	124
.constant	k74	112
.constant	k75	"require"
.constant	k76	4
.constant	k77	80
.constant	k78	102
.constant	k79	152
.constant	k80	40
.constant	k81	24
.constant	k82	110
.constant	k83	139
.constant	k84	93
.constant	k85	215
.constant	k86	47
.constant	k87	157
.constant	k88	82
.constant	k89	73
.constant	k90	106
.constant	k91	164
.constant	k92	52
.constant	k93	27
.constant	k94	111
.constant	k95	141
.constant	k96	175
.constant	k97	87
.constant	k98	26
.constant	k99	204
.constant	k100	120
.constant	k101	42
.constant	k102	101
.constant	k103	220
.constant	k104	86
.constant	k105	160
.constant	k106	37
.constant	k107	"GetMiniTvType"
.constant	k108	"bIsMiniTvStandalone"
.constant	k109	"ENUM_MINITV_TYPE"
.constant	k110	"Standalone"
.constant	k111	"bIsSpectatingAssistantPet"
.constant	k112	false
.constant	k113	"GetPlayerController"
.constant	k114	"slua"
.constant	k115	"isValid"
.constant	k116	"IsInPetSpectator"
.constant	k117	"GetPetSpectatorComp"
.constant	k118	"SpectatorPetID"
.constant	k119	true

.line	2188	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	2188	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	2188	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	2188	gettable      r2    r2    k2 ; k2 = "CommonModuleConfig"
.line	2188	gettable      r2    r2    k3 ; k3 = "SettingModule"
.line	2188	call          r1     2     2
.line	2188	self          r2    r1    k5 ; k5 = "GetOptionValue"
.line	2188	getupval      r4    u1
.line	2188	loadk         r5    k6 ; k6 = 16
.line	2188	loadk         r6    k7 ; k7 = 89
.line	2188	loadk         r7    k8 ; k8 = 197
.line	2188	loadk         r8    k9 ; k9 = 116
.line	2188	loadk         r9   k10 ; k10 = 153
.line	2188	loadk        r10   k11 ; k11 = 200
.line	2188	loadk        r11   k12 ; k12 = 39
.line	2188	loadk        r12   k13 ; k13 = 95
.line	2188	loadk        r13   k14 ; k14 = 129
.line	2188	loadk        r14   k15 ; k15 = 218
.line	2188	loadk        r15   k16 ; k16 = 67
.line	2188	loadk        r16   k17 ; k17 = 36
.line	2188	loadk        r17   k18 ; k18 = 212
.line	2188	loadk        r18   k19 ; k19 = 176
.line	2188	loadk        r19   k20 ; k20 = 119
.line	2188	loadk        r20   k21 ; k21 = 208
.line	2188	loadk        r21   k22 ; k22 = 199
.line	2188	loadk        r22   k23 ; k23 = 104
.line	2188	loadk        r23   k24 ; k24 = 180
.line	2188	loadk        r24   k25 ; k25 = 84
.line	2188	call          r4    21     2
.line	2188	call          r2     3     2
.line	2188	settable      r0    k4    r2 ; k4 = "bShowMiniTv"
.line	2188	gettabup      r2    u0   k26 ; k26 = "print"
.line	2188	gettabup      r3    u0   k27 ; k27 = "bWriteLog"
.line	2188	test          r3     0
.line	2188	jmp            0   l97
.line	2188	gettabup      r3    u0   k28 ; k28 = "table"
.line	2188	gettable      r3    r3   k29 ; k29 = "concat"
.line	2188	newtable      r4     1     0
.line	2188	getupval      r5    u1
.line	2188	loadk         r6   k30 ; k30 = 18
.line	2188	loadk         r7   k31 ; k31 = 68
.line	2188	loadk         r8   k32 ; k32 = 195
.line	2188	loadk         r9   k33 ; k33 = 96
.line	2188	loadk        r10   k34 ; k34 = 191
.line	2188	loadk        r11   k35 ; k35 = 228
.line	2188	loadk        r12   k36 ; k36 = 49
.line	2188	loadk        r13   k37 ; k37 = 70
.line	2188	loadk        r14   k38 ; k38 = 167
.line	2188	loadk        r15   k39 ; k39 = 201
.line	2188	loadk        r16   k40 ; k40 = 121
.line	2188	loadk        r17   k41 ; k41 = 57
.line	2188	loadk        r18   k42 ; k42 = 251
.line	2188	loadk        r19   k43 ; k43 = 182
.line	2188	loadk        r20   k44 ; k44 = 126
.line	2188	loadk        r21   k45 ; k45 = 130
.line	2188	loadk        r22   k46 ; k46 = 225
.line	2188	loadk        r23   k47 ; k47 = 100
.line	2188	loadk        r24   k48 ; k48 = 188
.line	2188	loadk        r25   k49 ; k49 = 65
.line	2188	loadk        r26   k49 ; k49 = 65
.line	2188	loadk        r27   k50 ; k50 = 226
.line	2188	loadk        r28   k51 ; k51 = 81
.line	2188	loadk        r29   k52 ; k52 = 75
.line	2188	loadk        r30   k53 ; k53 = 172
.line	2188	loadk        r31   k54 ; k54 = 210
.line	2188	loadk        r32   k55 ; k55 = 115
.line	2188	loadk        r33   k56 ; k56 = 14
.line	2188	loadk        r34   k57 ; k57 = 244
.line	2188	loadk        r35   k58 ; k58 = 154
.line	2188	loadk        r36   k23 ; k23 = 104
.line	2188	loadk        r37   k22 ; k22 = 199
.line	2188	loadk        r38   k18 ; k18 = 212
.line	2188	loadk        r39   k59 ; k59 = 66
.line	2188	loadk        r40   k60 ; k60 = 189
.line	2188	loadk        r41   k61 ; k61 = 74
.line	2188	loadk        r42   k62 ; k62 = 64
.line	2188	loadk        r43   k50 ; k50 = 226
.line	2188	loadk        r44   k49 ; k49 = 65
.line	2188	loadk        r45   k63 ; k63 = 54
.line	2188	call          r5    41     2
.line	2188	getupval      r6    u1
.line	2188	loadk         r7   k64 ; k64 = 33
.line	2188	loadk         r8   k65 ; k65 = 98
.line	2188	loadk         r9   k66 ; k66 = 194
.line	2188	loadk        r10   k67 ; k67 = 108
.line	2188	loadk        r11   k68 ; k68 = 163
.line	2188	loadk        r12   k69 ; k69 = 236
.line	2188	loadk        r13   k70 ; k70 = 32
.line	2188	loadk        r14   k71 ; k71 = 88
.line	2188	loadk        r15   k48 ; k48 = 188
.line	2188	loadk        r16   k72 ; k72 = 248
.line	2188	loadk        r17   k73 ; k73 = 124
.line	2188	loadk        r18   k74 ; k74 = 112
.line	2188	call          r6    13     0
.line	2188	setlist       r4     0     1
.line	2188	call          r3     2     2
.label	l97
.line	2188	gettable      r4    r0    k4 ; k4 = "bShowMiniTv"
.line	2188	call          r2     3     1
.line	2188	gettabup      r2    u0   k75 ; k75 = "require"
.line	2188	gettabup      r3    u0   k28 ; k28 = "table"
.line	2188	gettable      r3    r3   k29 ; k29 = "concat"
.line	2188	newtable      r4     1     0
.line	2188	getupval      r5    u1
.line	2188	loadk         r6   k76 ; k76 = 4
.line	2188	loadk         r7   k77 ; k77 = 80
.line	2188	loadk         r8   k22 ; k22 = 199
.line	2188	loadk         r9   k78 ; k78 = 102
.line	2188	loadk        r10   k79 ; k79 = 152
.line	2188	loadk        r11   k18 ; k18 = 212
.line	2188	loadk        r12   k80 ; k80 = 40
.line	2188	loadk        r13   k81 ; k81 = 24
.line	2188	loadk        r14   k79 ; k79 = 152
.line	2188	loadk        r15   k32 ; k32 = 195
.line	2188	loadk        r16   k82 ; k82 = 110
.line	2188	loadk        r17   k47 ; k47 = 100
.line	2188	loadk        r18   k21 ; k21 = 208
.line	2188	loadk        r19   k83 ; k83 = 139
.line	2188	loadk        r20   k84 ; k84 = 93
.line	2188	loadk        r21   k85 ; k85 = 215
.line	2188	loadk        r22   k85 ; k85 = 215
.line	2188	loadk        r23   k86 ; k86 = 47
.line	2188	loadk        r24   k87 ; k87 = 157
.line	2188	loadk        r25   k88 ; k88 = 82
.line	2188	loadk        r26   k89 ; k89 = 73
.line	2188	loadk        r27   k57 ; k57 = 244
.line	2188	loadk        r28   k89 ; k89 = 73
.line	2188	loadk        r29   k90 ; k90 = 106
.line	2188	loadk        r30   k91 ; k91 = 164
.line	2188	loadk        r31    k8 ; k8 = 197
.line	2188	loadk        r32   k92 ; k92 = 52
.line	2188	loadk        r33   k93 ; k93 = 27
.line	2188	loadk        r34   k46 ; k46 = 225
.line	2188	loadk        r35   k60 ; k60 = 189
.line	2188	loadk        r36   k94 ; k94 = 111
.line	2188	loadk        r37   k15 ; k15 = 218
.line	2188	loadk        r38   k95 ; k95 = 141
.line	2188	loadk        r39   k49 ; k49 = 65
.line	2188	loadk        r40   k96 ; k96 = 175
.line	2188	loadk        r41   k97 ; k97 = 87
.line	2188	loadk        r42   k98 ; k98 = 26
.line	2188	loadk        r43   k99 ; k99 = 204
.line	2188	loadk        r44   k62 ; k62 = 64
.line	2188	loadk        r45  k100 ; k100 = 120
.line	2188	call          r5    41     2
.line	2188	getupval      r6    u1
.line	2188	loadk         r7  k101 ; k101 = 42
.line	2188	loadk         r8  k102 ; k102 = 101
.line	2188	loadk         r9  k103 ; k103 = 220
.line	2188	loadk        r10  k104 ; k104 = 86
.line	2188	loadk        r11  k105 ; k105 = 160
.line	2188	loadk        r12   k11 ; k11 = 200
.line	2188	loadk        r13  k106 ; k106 = 37
.line	2188	call          r6     8     0
.line	2188	setlist       r4     0     1
.line	2188	call          r3     2     2
.line	2188	call          r2     2     2
.line	2188	self          r3    r0  k107 ; k107 = "GetMiniTvType"
.line	2188	call          r3     2     2
.line	2188	gettable      r4    r2  k109 ; k109 = "ENUM_MINITV_TYPE"
.line	2188	gettable      r4    r4  k110 ; k110 = "Standalone"
.line	2188	eq             1    r3    r4
.line	2188	jmp            0  l164
.line	2188	loadbool      r4     0     1
.label	l164
.line	2188	loadbool      r4     1     0
.line	2188	settable      r0  k108    r4 ; k108 = "bIsMiniTvStandalone"
.line	2188	settable      r0  k111  k112 ; k112 = false
.line	2188	gettabup      r4    u2  k113 ; k113 = "GetPlayerController"
.line	2188	call          r4     1     2
.line	2188	gettabup      r5    u0  k114 ; k114 = "slua"
.line	2188	gettable      r5    r5  k115 ; k115 = "isValid"
.line	2188	move          r6    r4
.line	2188	call          r5     2     2
.line	2188	test          r5     0
.line	2188	jmp            0  l198
.line	2188	gettable      r5    r4  k116 ; k116 = "IsInPetSpectator"
.line	2188	test          r5     0
.line	2188	jmp            0  l198
.line	2188	self          r5    r4  k116 ; k116 = "IsInPetSpectator"
.line	2188	call          r5     2     2
.line	2188	test          r5     0
.line	2188	jmp            0  l198
.line	2188	gettable      r5    r4  k117 ; k117 = "GetPetSpectatorComp"
.line	2188	test          r5     0
.line	2188	jmp            0  l187
.line	2188	self          r5    r4  k117 ; k117 = "GetPetSpectatorComp"
.line	2188	call          r5     2     2
.label	l187
.line	2188	gettabup      r6    u0  k114 ; k114 = "slua"
.line	2188	gettable      r6    r6  k115 ; k115 = "isValid"
.line	2188	move          r7    r5
.line	2188	call          r6     2     2
.line	2188	test          r6     0
.line	2188	jmp            0  l198
.line	2188	gettable      r6    r5  k118 ; k118 = "SpectatorPetID"
.line	2188	getupval      r7    u3
.line	2188	eq             0    r6    r7
.line	2188	jmp            0  l198
.line	2188	settable      r0  k111  k119 ; k119 = true
.label	l198
.line	2188	return        r0     1
.line	2188	move          r0    r0
.line	2188	return        r0     1

.function	main/f91

.source	null
.linedefined	2205
.lastlinedefined	2218
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	14	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	4
.constant	k4	80
.constant	k5	199
.constant	k6	102
.constant	k7	152
.constant	k8	212
.constant	k9	40
.constant	k10	24
.constant	k11	195
.constant	k12	110
.constant	k13	100
.constant	k14	208
.constant	k15	139
.constant	k16	93
.constant	k17	215
.constant	k18	47
.constant	k19	157
.constant	k20	82
.constant	k21	73
.constant	k22	244
.constant	k23	106
.constant	k24	164
.constant	k25	197
.constant	k26	52
.constant	k27	27
.constant	k28	225
.constant	k29	189
.constant	k30	111
.constant	k31	218
.constant	k32	141
.constant	k33	65
.constant	k34	175
.constant	k35	87
.constant	k36	26
.constant	k37	204
.constant	k38	64
.constant	k39	120
.constant	k40	42
.constant	k41	101
.constant	k42	220
.constant	k43	86
.constant	k44	160
.constant	k45	200
.constant	k46	37
.constant	k47	"ENUM_MINITV_TYPE"
.constant	k48	"None"
.constant	k49	"GetPlayerController"
.constant	k50	"slua"
.constant	k51	"isValid"
.constant	k52	"IsInPetSpectator"
.constant	k53	"GetPlayerCharacter"
.constant	k54	"PetComponent_BP"
.constant	k55	"GetMiniTvType"

.line	2205	gettabup      r1    u0    k0 ; k0 = "require"
.line	2205	gettabup      r2    u0    k1 ; k1 = "table"
.line	2205	gettable      r2    r2    k2 ; k2 = "concat"
.line	2205	newtable      r3     1     0
.line	2205	getupval      r4    u1
.line	2205	loadk         r5    k3 ; k3 = 4
.line	2205	loadk         r6    k4 ; k4 = 80
.line	2205	loadk         r7    k5 ; k5 = 199
.line	2205	loadk         r8    k6 ; k6 = 102
.line	2205	loadk         r9    k7 ; k7 = 152
.line	2205	loadk        r10    k8 ; k8 = 212
.line	2205	loadk        r11    k9 ; k9 = 40
.line	2205	loadk        r12   k10 ; k10 = 24
.line	2205	loadk        r13    k7 ; k7 = 152
.line	2205	loadk        r14   k11 ; k11 = 195
.line	2205	loadk        r15   k12 ; k12 = 110
.line	2205	loadk        r16   k13 ; k13 = 100
.line	2205	loadk        r17   k14 ; k14 = 208
.line	2205	loadk        r18   k15 ; k15 = 139
.line	2205	loadk        r19   k16 ; k16 = 93
.line	2205	loadk        r20   k17 ; k17 = 215
.line	2205	loadk        r21   k17 ; k17 = 215
.line	2205	loadk        r22   k18 ; k18 = 47
.line	2205	loadk        r23   k19 ; k19 = 157
.line	2205	loadk        r24   k20 ; k20 = 82
.line	2205	loadk        r25   k21 ; k21 = 73
.line	2205	loadk        r26   k22 ; k22 = 244
.line	2205	loadk        r27   k21 ; k21 = 73
.line	2205	loadk        r28   k23 ; k23 = 106
.line	2205	loadk        r29   k24 ; k24 = 164
.line	2205	loadk        r30   k25 ; k25 = 197
.line	2205	loadk        r31   k26 ; k26 = 52
.line	2205	loadk        r32   k27 ; k27 = 27
.line	2205	loadk        r33   k28 ; k28 = 225
.line	2205	loadk        r34   k29 ; k29 = 189
.line	2205	loadk        r35   k30 ; k30 = 111
.line	2205	loadk        r36   k31 ; k31 = 218
.line	2205	loadk        r37   k32 ; k32 = 141
.line	2205	loadk        r38   k33 ; k33 = 65
.line	2205	loadk        r39   k34 ; k34 = 175
.line	2205	loadk        r40   k35 ; k35 = 87
.line	2205	loadk        r41   k36 ; k36 = 26
.line	2205	loadk        r42   k37 ; k37 = 204
.line	2205	loadk        r43   k38 ; k38 = 64
.line	2205	loadk        r44   k39 ; k39 = 120
.line	2205	call          r4    41     2
.line	2205	getupval      r5    u1
.line	2205	loadk         r6   k40 ; k40 = 42
.line	2205	loadk         r7   k41 ; k41 = 101
.line	2205	loadk         r8   k42 ; k42 = 220
.line	2205	loadk         r9   k43 ; k43 = 86
.line	2205	loadk        r10   k44 ; k44 = 160
.line	2205	loadk        r11   k45 ; k45 = 200
.line	2205	loadk        r12   k46 ; k46 = 37
.line	2205	call          r5     8     0
.line	2205	setlist       r3     0     1
.line	2205	call          r2     2     2
.line	2205	call          r1     2     2
.line	2205	gettable      r2    r1   k47 ; k47 = "ENUM_MINITV_TYPE"
.line	2205	gettable      r2    r2   k48 ; k48 = "None"
.line	2205	gettabup      r3    u2   k49 ; k49 = "GetPlayerController"
.line	2205	call          r3     1     2
.line	2205	gettabup      r4    u0   k50 ; k50 = "slua"
.line	2205	gettable      r4    r4   k51 ; k51 = "isValid"
.line	2205	move          r5    r3
.line	2205	call          r4     2     2
.line	2205	test          r4     0
.line	2205	jmp            0   l79
.line	2205	gettable      r4    r3   k52 ; k52 = "IsInPetSpectator"
.line	2205	test          r4     0
.line	2205	jmp            0   l79
.line	2205	self          r4    r3   k52 ; k52 = "IsInPetSpectator"
.line	2205	call          r4     2     2
.line	2205	test          r4     0
.line	2205	jmp            0   l79
.line	2205	gettable      r4    r1   k47 ; k47 = "ENUM_MINITV_TYPE"
.line	2205	gettable      r2    r4   k48 ; k48 = "None"
.line	2205	jmp            0   l97
.label	l79
.line	2205	gettabup      r4    u2   k53 ; k53 = "GetPlayerCharacter"
.line	2205	call          r4     1     2
.line	2205	gettabup      r5    u0   k50 ; k50 = "slua"
.line	2205	gettable      r5    r5   k51 ; k51 = "isValid"
.line	2205	move          r6    r4
.line	2205	call          r5     2     2
.line	2205	test          r5     0
.line	2205	jmp            0   l97
.line	2205	gettabup      r5    u0   k50 ; k50 = "slua"
.line	2205	gettable      r5    r5   k51 ; k51 = "isValid"
.line	2205	gettable      r6    r4   k54 ; k54 = "PetComponent_BP"
.line	2205	call          r5     2     2
.line	2205	test          r5     0
.line	2205	jmp            0   l97
.line	2205	gettable      r5    r4   k54 ; k54 = "PetComponent_BP"
.line	2205	self          r5    r5   k55 ; k55 = "GetMiniTvType"
.line	2205	call          r5     2     2
.line	2205	move          r2    r5
.label	l97
.line	2205	return        r2     2
.line	2205	return        r0     1
.line	2205	move          r0    r0
.line	2205	move          r0    r0
.line	2205	return        r0     1

.function	main/f92

.source	null
.linedefined	2220
.lastlinedefined	2244
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	14	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"bInitMiniTvExpressionList"
.constant	k1	true
.constant	k2	"MiniTvExpressionList"
.constant	k3	"GetPlayerController"
.constant	k4	"CommerFeature"
.constant	k5	"MiniTVActionIDList"
.constant	k6	"pairs"
.constant	k7	"CDataTable"
.constant	k8	"GetTableDataByFilter"
.constant	k9	19
.constant	k10	84
.constant	k11	222
.constant	k12	66
.constant	k13	183
.constant	k14	213
.constant	k15	32
.constant	k16	89
.constant	k17	187
.constant	k18	248
.constant	k19	107
.constant	k20	40
.constant	k21	254
.constant	k22	188
.constant	k23	229
.constant	k24	78
.constant	k25	"MasterSkillID"
.constant	k26	1
.constant	k27	"ID"
.constant	k28	"IsLocked"
.constant	k29	false
.constant	k30	"SortKey"
.constant	k31	"print"
.constant	k32	"bWriteLog"
.constant	k33	"table"
.constant	k34	"concat"
.constant	k35	18
.constant	k36	68
.constant	k37	195
.constant	k38	96
.constant	k39	191
.constant	k40	228
.constant	k41	49
.constant	k42	70
.constant	k43	167
.constant	k44	201
.constant	k45	121
.constant	k46	57
.constant	k47	251
.constant	k48	182
.constant	k49	126
.constant	k50	130
.constant	k51	227
.constant	k52	115
.constant	k53	67
.constant	k54	69
.constant	k55	92
.constant	k56	75
.constant	k57	172
.constant	k58	210
.constant	k59	14
.constant	k60	244
.constant	k61	140
.constant	k62	120
.constant	k63	216
.constant	k64	209
.constant	k65	116
.constant	k66	185
.constant	k67	80
.constant	k68	93
.constant	k69	238
.constant	k70	71
.constant	k71	90
.constant	k72	42
.constant	k73	35
.constant	k74	206
.constant	k75	60
.constant	k76	88
.constant	k77	161
.constant	k78	150

.line	2220	gettable      r1    r0    k0 ; k0 = "bInitMiniTvExpressio" (truncated)
.line	2220	test          r1     0
.line	2220	jmp            0    l5
.line	2220	return        r0     1
.label	l5
.line	2220	settable      r0    k0    k1 ; k1 = true
.line	2220	newtable      r1     0     0
.line	2220	settable      r0    k2    r1 ; k2 = "MiniTvExpressionList"
.line	2220	gettabup      r1    u0    k3 ; k3 = "GetPlayerController"
.line	2220	call          r1     1     2
.line	2220	gettable      r2    r1    k4 ; k4 = "CommerFeature"
.line	2220	test          r2     0
.line	2220	jmp            0   l15
.line	2220	gettable      r2    r1    k4 ; k4 = "CommerFeature"
.line	2220	gettable      r2    r2    k5 ; k5 = "MiniTVActionIDList"
.label	l15
.line	2220	test          r2     0
.line	2220	jmp            0   l71
.line	2220	gettabup      r3    u1    k6 ; k6 = "pairs"
.line	2220	move          r4    r2
.line	2220	call          r3     2     4
.line	2220	jmp            0   l69
.line	2220	loadnil       r8     0
.line	2220	gettabup      r9    u1    k7 ; k7 = "CDataTable"
.line	2220	gettable      r9    r9    k8 ; k8 = "GetTableDataByFilter"
.line	2220	getupval     r10    u2
.line	2220	loadk        r11    k9 ; k9 = 19
.line	2220	loadk        r12   k10 ; k10 = 84
.line	2220	loadk        r13   k11 ; k11 = 222
.line	2220	loadk        r14   k12 ; k12 = 66
.line	2220	loadk        r15   k13 ; k13 = 183
.line	2220	loadk        r16   k14 ; k14 = 213
.line	2220	loadk        r17   k15 ; k15 = 32
.line	2220	loadk        r18   k16 ; k16 = 89
.line	2220	loadk        r19   k17 ; k17 = 187
.line	2220	loadk        r20   k18 ; k18 = 248
.line	2220	loadk        r21   k19 ; k19 = 107
.line	2220	loadk        r22   k20 ; k20 = 40
.line	2220	loadk        r23   k21 ; k21 = 254
.line	2220	loadk        r24   k22 ; k22 = 188
.line	2220	call         r10    15     2
.line	2220	getupval     r11    u2
.line	2220	loadk        r12    k9 ; k9 = 19
.line	2220	loadk        r13   k10 ; k10 = 84
.line	2220	loadk        r14   k11 ; k11 = 222
.line	2220	loadk        r15   k12 ; k12 = 66
.line	2220	loadk        r16   k13 ; k13 = 183
.line	2220	loadk        r17   k14 ; k14 = 213
.line	2220	loadk        r18   k15 ; k15 = 32
.line	2220	loadk        r19   k16 ; k16 = 89
.line	2220	loadk        r20   k17 ; k17 = 187
.line	2220	loadk        r21   k23 ; k23 = 229
.line	2220	loadk        r22   k24 ; k24 = 78
.line	2220	call         r11    12     2
.line	2220	move         r12    r7
.line	2220	call          r9     4     2
.line	2220	test          r9     0
.line	2220	jmp            0   l69
.line	2220	gettable      r8    r9   k25 ; k25 = "MasterSkillID"
.line	2220	gettable     r10    r0    k2 ; k2 = "MiniTvExpressionList"
.line	2220	gettable     r11    r0    k2 ; k2 = "MiniTvExpressionList"
.line	2220	len          r11   r11
.line	2220	add          r11   r11   k26 ; k26 = 1
.line	2220	newtable     r12     0     4
.line	2220	settable     r12   k27    r7 ; k27 = "ID"
.line	2220	settable     r12   k28   k29 ; k29 = false
.line	2220	gettable     r13    r9   k30 ; k30 = "SortKey"
.line	2220	settable     r12   k30   r13 ; k30 = "SortKey"
.line	2220	settable     r12   k25    r8 ; k25 = "MasterSkillID"
.line	2220	settable     r10   r11   r12
.label	l69
.line	2220	move          r0    r0
.line	2220	move          r0    r0
.label	l71
.line	2220	gettabup      r3    u1   k31 ; k31 = "print"
.line	2220	gettabup      r4    u1   k32 ; k32 = "bWriteLog"
.line	2220	test          r4     0
.line	2220	jmp            0  l134
.line	2220	gettabup      r4    u1   k33 ; k33 = "table"
.line	2220	gettable      r4    r4   k34 ; k34 = "concat"
.line	2220	newtable      r5     1     0
.line	2220	getupval      r6    u2
.line	2220	loadk         r7   k35 ; k35 = 18
.line	2220	loadk         r8   k36 ; k36 = 68
.line	2220	loadk         r9   k37 ; k37 = 195
.line	2220	loadk        r10   k38 ; k38 = 96
.line	2220	loadk        r11   k39 ; k39 = 191
.line	2220	loadk        r12   k40 ; k40 = 228
.line	2220	loadk        r13   k41 ; k41 = 49
.line	2220	loadk        r14   k42 ; k42 = 70
.line	2220	loadk        r15   k43 ; k43 = 167
.line	2220	loadk        r16   k44 ; k44 = 201
.line	2220	loadk        r17   k45 ; k45 = 121
.line	2220	loadk        r18   k46 ; k46 = 57
.line	2220	loadk        r19   k47 ; k47 = 251
.line	2220	loadk        r20   k48 ; k48 = 182
.line	2220	loadk        r21   k49 ; k49 = 126
.line	2220	loadk        r22   k50 ; k50 = 130
.line	2220	loadk        r23   k51 ; k51 = 227
.line	2220	loadk        r24   k52 ; k52 = 115
.line	2220	loadk        r25   k39 ; k39 = 191
.line	2220	loadk        r26   k53 ; k53 = 67
.line	2220	loadk        r27   k54 ; k54 = 69
.line	2220	loadk        r28   k51 ; k51 = 227
.line	2220	loadk        r29   k55 ; k55 = 92
.line	2220	loadk        r30   k56 ; k56 = 75
.line	2220	loadk        r31   k57 ; k57 = 172
.line	2220	loadk        r32   k58 ; k58 = 210
.line	2220	loadk        r33   k52 ; k52 = 115
.line	2220	loadk        r34   k59 ; k59 = 14
.line	2220	loadk        r35   k60 ; k60 = 244
.line	2220	loadk        r36   k61 ; k61 = 140
.line	2220	loadk        r37   k62 ; k62 = 120
.line	2220	loadk        r38   k63 ; k63 = 216
.line	2220	loadk        r39   k64 ; k64 = 209
.line	2220	loadk        r40   k65 ; k65 = 116
.line	2220	loadk        r41   k66 ; k66 = 185
.line	2220	loadk        r42   k67 ; k67 = 80
.line	2220	loadk        r43   k68 ; k68 = 93
.line	2220	loadk        r44   k69 ; k69 = 238
.line	2220	loadk        r45   k70 ; k70 = 71
.line	2220	loadk        r46   k71 ; k71 = 90
.line	2220	call          r6    41     2
.line	2220	getupval      r7    u2
.line	2220	loadk         r8   k72 ; k72 = 42
.line	2220	loadk         r9   k12 ; k12 = 66
.line	2220	loadk        r10   k11 ; k11 = 222
.line	2220	loadk        r11   k73 ; k73 = 35
.line	2220	loadk        r12   k13 ; k13 = 183
.line	2220	loadk        r13   k74 ; k74 = 206
.line	2220	loadk        r14   k75 ; k75 = 60
.line	2220	loadk        r15   k76 ; k76 = 88
.line	2220	loadk        r16   k77 ; k77 = 161
.line	2220	loadk        r17   k78 ; k78 = 150
.line	2220	call          r7    11     0
.line	2220	setlist       r5     0     1
.line	2220	call          r4     2     2
.label	l134
.line	2220	gettable      r5    r0    k2 ; k2 = "MiniTvExpressionList"
.line	2220	len           r5    r5
.line	2220	call          r3     3     1
.line	2220	return        r0     1
.line	2220	move          r0    r0
.line	2220	return        r0     1

.function	main/f93

.source	null
.linedefined	2246
.lastlinedefined	2305
.numparams	2
.is_vararg	0
.maxstacksize	54

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	15	true

.constant	k0	"IndexToMiniTvExpression"
.constant	k1	nil
.constant	k2	1
.constant	k3	"slua_GameFrontendHUD"
.constant	k4	"GetPlayerController"
.constant	k5	"print"
.constant	k6	"bWriteLog"
.constant	k7	"table"
.constant	k8	"concat"
.constant	k9	18
.constant	k10	68
.constant	k11	195
.constant	k12	96
.constant	k13	191
.constant	k14	228
.constant	k15	49
.constant	k16	70
.constant	k17	167
.constant	k18	201
.constant	k19	121
.constant	k20	57
.constant	k21	251
.constant	k22	182
.constant	k23	126
.constant	k24	130
.constant	k25	231
.constant	k26	115
.constant	k27	163
.constant	k28	103
.constant	k29	75
.constant	k30	193
.constant	k31	85
.constant	k32	188
.constant	k33	241
.constant	k34	52
.constant	k35	235
.constant	k36	157
.constant	k37	118
.constant	k38	237
.constant	k39	219
.constant	k40	97
.constant	k41	184
.constant	k42	71
.constant	k43	242
.constant	k44	64
.constant	k45	45
.constant	k46	"slua"
.constant	k47	"isValid"
.constant	k48	"pairs"
.constant	k49	"MiniTvExpressionList"
.constant	k50	"ID"
.constant	k51	"MasterSkillID"
.constant	k52	"GetIsEmoteExist"
.constant	k53	17
.constant	k54	196
.constant	k55	108
.constant	k56	160
.constant	k57	129
.constant	k58	44
.constant	k59	78
.constant	k60	223
.constant	k61	"BattleNormalTipsByTextID"
.constant	k62	43005
.constant	k63	"ED_QuickExpressShowHide"
.constant	k64	"BroadCast"
.constant	k65	"EventSystem"
.constant	k66	"postEvent"
.constant	k67	"EVENTTYPE_INGAME"
.constant	k68	L"EVENTID_INGAME_SHOW_OR_HIDE_QUICK_EXPRESSION"
.constant	k69	"ShowOrHideRing"
.constant	k70	"IsInPetSpectator"
.constant	k71	"GetPetSpectatorComp"
.constant	k72	"PetSpectatorPawn"
.constant	k73	227
.constant	k74	112
.constant	k75	207
.constant	k76	25
.constant	k77	83
.constant	k78	161
.constant	k79	255
.constant	k80	122
.constant	k81	47
.constant	k82	173
.constant	k83	113
.constant	k84	204
.constant	k85	220
.constant	k86	"import"
.constant	k87	6
.constant	k88	98
.constant	k89	218
.constant	k90	102
.constant	k91	183
.constant	k92	213
.constant	k93	40
.constant	k94	66
.constant	k95	186
.constant	k96	222
.constant	k97	90
.constant	k98	230
.constant	k99	138
.constant	k100	100
.constant	k101	217
.constant	k102	199
.constant	k103	151
.constant	k104	67
.constant	k105	197
.constant	k106	"LocalHandleSpectatorPetStateMsg"
.constant	k107	"SpectatorPetMsgPlayEmoteMotage"
.constant	k108	"GetCurPawn"
.constant	k109	"PetComponent_BP"
.constant	k110	119
.constant	k111	135
.constant	k112	176
.constant	k113	"GetMiniTVPawn"
.constant	k114	"PetHasState"
.constant	k115	"PetParachute"
.constant	k116	"PetSwimming"
.constant	k117	"PetSleeping"
.constant	k118	"PetPlayingFeature"
.constant	k119	106
.constant	k120	200
.constant	k121	29
.constant	k122	245
.constant	k123	43
.constant	k124	48
.constant	k125	209
.constant	k126	192
.constant	k127	33
.constant	k128	92
.constant	k129	86
.constant	k130	243
.constant	k131	80
.constant	k132	116
.constant	k133	123
.constant	k134	49084
.constant	k135	0
.constant	k136	216
.constant	k137	120
.constant	k138	35
.constant	k139	190
.constant	k140	117
.constant	k141	202
.constant	k142	147
.constant	k143	114
.constant	k144	177
.constant	k145	72
.constant	k146	253
.constant	k147	"GetSkillManager"
.constant	k148	"GetSkill"
.constant	k149	"IsCDOK"
.constant	k150	-1
.constant	k151	104
.constant	k152	189
.constant	k153	205
.constant	k154	37
.constant	k155	22
.constant	k156	156
.constant	k157	194
.constant	k158	73
.constant	k159	14
.constant	k160	7108
.constant	k161	"PlaySpecifiedPetAnimation"

.line	2246	gettable      r2    r0    k0 ; k0 = "IndexToMiniTvExpress" (truncated)
.line	2246	eq             0    r2    k1 ; k1 = nil
.line	2246	jmp            0    l5
.line	2246	return        r0     1
.label	l5
.line	2246	gettable      r2    r0    k0 ; k0 = "IndexToMiniTvExpress" (truncated)
.line	2246	add           r3    r1    k2 ; k2 = 1
.line	2246	gettable      r2    r2    r3
.line	2246	gettabup      r3    u0    k3 ; k3 = "slua_GameFrontendHUD"
.line	2246	self          r3    r3    k4 ; k4 = "GetPlayerController"
.line	2246	call          r3     2     2
.line	2246	gettabup      r4    u0    k5 ; k5 = "print"
.line	2246	gettabup      r5    u0    k6 ; k6 = "bWriteLog"
.line	2246	test          r5     0
.line	2246	jmp            0   l65
.line	2246	gettabup      r5    u0    k7 ; k7 = "table"
.line	2246	gettable      r5    r5    k8 ; k8 = "concat"
.line	2246	newtable      r6     1     0
.line	2246	getupval      r7    u1
.line	2246	loadk         r8    k9 ; k9 = 18
.line	2246	loadk         r9   k10 ; k10 = 68
.line	2246	loadk        r10   k11 ; k11 = 195
.line	2246	loadk        r11   k12 ; k12 = 96
.line	2246	loadk        r12   k13 ; k13 = 191
.line	2246	loadk        r13   k14 ; k14 = 228
.line	2246	loadk        r14   k15 ; k15 = 49
.line	2246	loadk        r15   k16 ; k16 = 70
.line	2246	loadk        r16   k17 ; k17 = 167
.line	2246	loadk        r17   k18 ; k18 = 201
.line	2246	loadk        r18   k19 ; k19 = 121
.line	2246	loadk        r19   k20 ; k20 = 57
.line	2246	loadk        r20   k21 ; k21 = 251
.line	2246	loadk        r21   k22 ; k22 = 182
.line	2246	loadk        r22   k23 ; k23 = 126
.line	2246	loadk        r23   k24 ; k24 = 130
.line	2246	loadk        r24   k25 ; k25 = 231
.line	2246	loadk        r25   k26 ; k26 = 115
.line	2246	loadk        r26   k27 ; k27 = 163
.line	2246	loadk        r27   k28 ; k28 = 103
.line	2246	loadk        r28   k29 ; k29 = 75
.line	2246	loadk        r29   k30 ; k30 = 193
.line	2246	loadk        r30   k31 ; k31 = 85
.line	2246	loadk        r31   k28 ; k28 = 103
.line	2246	loadk        r32   k32 ; k32 = 188
.line	2246	loadk        r33   k33 ; k33 = 241
.line	2246	loadk        r34   k26 ; k26 = 115
.line	2246	loadk        r35   k34 ; k34 = 52
.line	2246	loadk        r36   k35 ; k35 = 235
.line	2246	loadk        r37   k36 ; k36 = 157
.line	2246	loadk        r38   k37 ; k37 = 118
.line	2246	loadk        r39   k38 ; k38 = 237
.line	2246	loadk        r40   k39 ; k39 = 219
.line	2246	loadk        r41   k40 ; k40 = 97
.line	2246	loadk        r42   k41 ; k41 = 184
.line	2246	loadk        r43   k16 ; k16 = 70
.line	2246	loadk        r44   k42 ; k42 = 71
.line	2246	loadk        r45   k43 ; k43 = 242
.line	2246	loadk        r46   k44 ; k44 = 64
.line	2246	loadk        r47   k19 ; k19 = 121
.line	2246	call          r7    41     2
.line	2246	getupval      r8    u1
.line	2246	loadk         r9   k45 ; k45 = 45
.line	2246	call          r8     2     0
.line	2246	setlist       r6     0     1
.line	2246	call          r5     2     2
.label	l65
.line	2246	move          r6    r1
.line	2246	move          r7    r2
.line	2246	call          r4     4     1
.line	2246	gettabup      r4    u0   k46 ; k46 = "slua"
.line	2246	gettable      r4    r4   k47 ; k47 = "isValid"
.line	2246	move          r5    r3
.line	2246	call          r4     2     2
.line	2246	test          r4     0
.line	2246	jmp            0  l637
.line	2246	test          r2     0
.line	2246	jmp            0  l637
.line	2246	loadnil       r4     0
.line	2246	gettabup      r5    u0   k48 ; k48 = "pairs"
.line	2246	gettable      r6    r0   k49 ; k49 = "MiniTvExpressionList"
.line	2246	call          r5     2     4
.line	2246	jmp            0   l86
.line	2246	gettable     r10    r9   k50 ; k50 = "ID"
.line	2246	eq             0   r10    r2
.line	2246	jmp            0   l86
.line	2246	gettable      r4    r9   k51 ; k51 = "MasterSkillID"
.line	2246	jmp            0   l88
.label	l86
.line	2246	move          r0    r0
.line	2246	move          r0    r0
.label	l88
.line	2246	self          r5    r0   k52 ; k52 = "GetIsEmoteExist"
.line	2246	move          r7    r2
.line	2246	call          r5     3     2
.line	2246	test          r5     1
.line	2246	jmp            0  l176
.line	2246	gettabup      r5    u0    k5 ; k5 = "print"
.line	2246	gettabup      r6    u0    k6 ; k6 = "bWriteLog"
.line	2246	test          r6     0
.line	2246	jmp            0  l157
.line	2246	gettabup      r6    u0    k7 ; k7 = "table"
.line	2246	gettable      r6    r6    k8 ; k8 = "concat"
.line	2246	newtable      r7     1     0
.line	2246	getupval      r8    u1
.line	2246	loadk         r9    k9 ; k9 = 18
.line	2246	loadk        r10   k10 ; k10 = 68
.line	2246	loadk        r11   k11 ; k11 = 195
.line	2246	loadk        r12   k12 ; k12 = 96
.line	2246	loadk        r13   k13 ; k13 = 191
.line	2246	loadk        r14   k14 ; k14 = 228
.line	2246	loadk        r15   k15 ; k15 = 49
.line	2246	loadk        r16   k16 ; k16 = 70
.line	2246	loadk        r17   k17 ; k17 = 167
.line	2246	loadk        r18   k18 ; k18 = 201
.line	2246	loadk        r19   k19 ; k19 = 121
.line	2246	loadk        r20   k20 ; k20 = 57
.line	2246	loadk        r21   k21 ; k21 = 251
.line	2246	loadk        r22   k22 ; k22 = 182
.line	2246	loadk        r23   k23 ; k23 = 126
.line	2246	loadk        r24   k24 ; k24 = 130
.line	2246	loadk        r25   k25 ; k25 = 231
.line	2246	loadk        r26   k26 ; k26 = 115
.line	2246	loadk        r27   k27 ; k27 = 163
.line	2246	loadk        r28   k28 ; k28 = 103
.line	2246	loadk        r29   k29 ; k29 = 75
.line	2246	loadk        r30   k30 ; k30 = 193
.line	2246	loadk        r31   k31 ; k31 = 85
.line	2246	loadk        r32   k28 ; k28 = 103
.line	2246	loadk        r33   k32 ; k32 = 188
.line	2246	loadk        r34   k33 ; k33 = 241
.line	2246	loadk        r35   k26 ; k26 = 115
.line	2246	loadk        r36   k34 ; k34 = 52
.line	2246	loadk        r37   k35 ; k35 = 235
.line	2246	loadk        r38   k36 ; k36 = 157
.line	2246	loadk        r39   k37 ; k37 = 118
.line	2246	loadk        r40   k38 ; k38 = 237
.line	2246	loadk        r41   k39 ; k39 = 219
.line	2246	loadk        r42   k40 ; k40 = 97
.line	2246	loadk        r43   k41 ; k41 = 184
.line	2246	loadk        r44   k16 ; k16 = 70
.line	2246	loadk        r45   k42 ; k42 = 71
.line	2246	loadk        r46   k43 ; k43 = 242
.line	2246	loadk        r47   k44 ; k44 = 64
.line	2246	loadk        r48   k19 ; k19 = 121
.line	2246	call          r8    41     2
.line	2246	getupval      r9    u1
.line	2246	loadk        r10   k45 ; k45 = 45
.line	2246	loadk        r11   k53 ; k53 = 17
.line	2246	loadk        r12   k54 ; k54 = 196
.line	2246	loadk        r13   k55 ; k55 = 108
.line	2246	loadk        r14   k56 ; k56 = 160
.line	2246	loadk        r15   k57 ; k57 = 129
.line	2246	loadk        r16   k58 ; k58 = 44
.line	2246	loadk        r17   k59 ; k59 = 78
.line	2246	loadk        r18   k32 ; k32 = 188
.line	2246	loadk        r19   k60 ; k60 = 223
.line	2246	loadk        r20   k23 ; k23 = 126
.line	2246	call          r9    12     0
.line	2246	setlist       r7     0     1
.line	2246	call          r6     2     2
.label	l157
.line	2246	move          r7    r2
.line	2246	call          r5     3     1
.line	2246	gettabup      r5    u2   k61 ; k61 = "BattleNormalTipsByTe" (truncated)
.line	2246	loadk         r6   k62 ; k62 = 43005
.line	2246	call          r5     2     1
.line	2246	gettable      r5    r0   k63 ; k63 = "ED_QuickExpressShowH" (truncated)
.line	2246	self          r5    r5   k64 ; k64 = "BroadCast"
.line	2246	loadbool      r7     0     0
.line	2246	call          r5     3     1
.line	2246	gettabup      r5    u0   k65 ; k65 = "EventSystem"
.line	2246	self          r5    r5   k66 ; k66 = "postEvent"
.line	2246	gettabup      r7    u0   k67 ; k67 = "EVENTTYPE_INGAME"
.line	2246	gettabup      r8    u0   k68 ; k68 = L"EVENTID_INGAME_SHOW_" (truncated)
.line	2246	loadbool      r9     0     0
.line	2246	call          r5     5     1
.line	2246	self          r5    r0   k69 ; k69 = "ShowOrHideRing"
.line	2246	loadbool      r7     0     0
.line	2246	call          r5     3     1
.line	2246	return        r0     1
.label	l176
.line	2246	gettable      r5    r3   k70 ; k70 = "IsInPetSpectator"
.line	2246	test          r5     0
.line	2246	jmp            0  l305
.line	2246	self          r5    r3   k70 ; k70 = "IsInPetSpectator"
.line	2246	call          r5     2     2
.line	2246	test          r5     0
.line	2246	jmp            0  l305
.line	2246	self          r5    r3   k71 ; k71 = "GetPetSpectatorComp"
.line	2246	call          r5     2     2
.line	2246	test          r5     0
.line	2246	jmp            0  l305
.line	2246	self          r5    r3   k71 ; k71 = "GetPetSpectatorComp"
.line	2246	call          r5     2     2
.line	2246	gettable      r5    r5   k72 ; k72 = "PetSpectatorPawn"
.line	2246	test          r5     0
.line	2246	jmp            0  l305
.line	2246	gettabup      r5    u0    k5 ; k5 = "print"
.line	2246	gettabup      r6    u0    k6 ; k6 = "bWriteLog"
.line	2246	test          r6     0
.line	2246	jmp            0  l263
.line	2246	gettabup      r6    u0    k7 ; k7 = "table"
.line	2246	gettable      r6    r6    k8 ; k8 = "concat"
.line	2246	newtable      r7     1     0
.line	2246	getupval      r8    u1
.line	2246	loadk         r9    k9 ; k9 = 18
.line	2246	loadk        r10   k10 ; k10 = 68
.line	2246	loadk        r11   k11 ; k11 = 195
.line	2246	loadk        r12   k12 ; k12 = 96
.line	2246	loadk        r13   k13 ; k13 = 191
.line	2246	loadk        r14   k14 ; k14 = 228
.line	2246	loadk        r15   k15 ; k15 = 49
.line	2246	loadk        r16   k16 ; k16 = 70
.line	2246	loadk        r17   k17 ; k17 = 167
.line	2246	loadk        r18   k18 ; k18 = 201
.line	2246	loadk        r19   k19 ; k19 = 121
.line	2246	loadk        r20   k20 ; k20 = 57
.line	2246	loadk        r21   k21 ; k21 = 251
.line	2246	loadk        r22   k22 ; k22 = 182
.line	2246	loadk        r23   k23 ; k23 = 126
.line	2246	loadk        r24   k24 ; k24 = 130
.line	2246	loadk        r25   k25 ; k25 = 231
.line	2246	loadk        r26   k26 ; k26 = 115
.line	2246	loadk        r27   k27 ; k27 = 163
.line	2246	loadk        r28   k28 ; k28 = 103
.line	2246	loadk        r29   k29 ; k29 = 75
.line	2246	loadk        r30   k30 ; k30 = 193
.line	2246	loadk        r31   k31 ; k31 = 85
.line	2246	loadk        r32   k28 ; k28 = 103
.line	2246	loadk        r33   k32 ; k32 = 188
.line	2246	loadk        r34   k33 ; k33 = 241
.line	2246	loadk        r35   k26 ; k26 = 115
.line	2246	loadk        r36   k34 ; k34 = 52
.line	2246	loadk        r37   k35 ; k35 = 235
.line	2246	loadk        r38   k36 ; k36 = 157
.line	2246	loadk        r39   k37 ; k37 = 118
.line	2246	loadk        r40   k38 ; k38 = 237
.line	2246	loadk        r41   k39 ; k39 = 219
.line	2246	loadk        r42   k40 ; k40 = 97
.line	2246	loadk        r43   k41 ; k41 = 184
.line	2246	loadk        r44   k16 ; k16 = 70
.line	2246	loadk        r45   k42 ; k42 = 71
.line	2246	loadk        r46   k43 ; k43 = 242
.line	2246	loadk        r47   k44 ; k44 = 64
.line	2246	loadk        r48   k19 ; k19 = 121
.line	2246	call          r8    41     2
.line	2246	getupval      r9    u1
.line	2246	loadk        r10   k45 ; k45 = 45
.line	2246	loadk        r11   k53 ; k53 = 17
.line	2246	loadk        r12   k73 ; k73 = 227
.line	2246	loadk        r13   k74 ; k74 = 112
.line	2246	loadk        r14   k36 ; k36 = 157
.line	2246	loadk        r15   k75 ; k75 = 207
.line	2246	loadk        r16   k76 ; k76 = 25
.line	2246	loadk        r17   k77 ; k77 = 83
.line	2246	loadk        r18   k78 ; k78 = 161
.line	2246	loadk        r19   k79 ; k79 = 255
.line	2246	loadk        r20   k80 ; k80 = 122
.line	2246	loadk        r21   k81 ; k81 = 47
.line	2246	loadk        r22   k33 ; k33 = 241
.line	2246	loadk        r23   k82 ; k82 = 173
.line	2246	loadk        r24   k83 ; k83 = 113
.line	2246	loadk        r25   k84 ; k84 = 204
.line	2246	loadk        r26   k85 ; k85 = 220
.line	2246	loadk        r27   k26 ; k26 = 115
.line	2246	call          r9    19     0
.line	2246	setlist       r7     0     1
.line	2246	call          r6     2     2
.label	l263
.line	2246	move          r7    r2
.line	2246	call          r5     3     1
.line	2246	gettabup      r5    u0   k86 ; k86 = "import"
.line	2246	getupval      r6    u1
.line	2246	loadk         r7   k87 ; k87 = 6
.line	2246	loadk         r8   k88 ; k88 = 98
.line	2246	loadk         r9   k89 ; k89 = 218
.line	2246	loadk        r10   k90 ; k90 = 102
.line	2246	loadk        r11   k91 ; k91 = 183
.line	2246	loadk        r12   k92 ; k92 = 213
.line	2246	loadk        r13   k93 ; k93 = 40
.line	2246	loadk        r14   k94 ; k94 = 66
.line	2246	loadk        r15   k95 ; k95 = 186
.line	2246	loadk        r16   k96 ; k96 = 222
.line	2246	loadk        r17   k97 ; k97 = 90
.line	2246	loadk        r18   k81 ; k81 = 47
.line	2246	loadk        r19   k98 ; k98 = 230
.line	2246	loadk        r20   k99 ; k99 = 138
.line	2246	loadk        r21  k100 ; k100 = 100
.line	2246	loadk        r22  k101 ; k101 = 217
.line	2246	loadk        r23  k102 ; k102 = 199
.line	2246	loadk        r24  k100 ; k100 = 100
.line	2246	loadk        r25  k103 ; k103 = 151
.line	2246	loadk        r26   k44 ; k44 = 64
.line	2246	loadk        r27  k104 ; k104 = 67
.line	2246	loadk        r28  k105 ; k105 = 197
.line	2246	loadk        r29   k44 ; k44 = 64
.line	2246	loadk        r30   k37 ; k37 = 118
.line	2246	loadk        r31   k56 ; k56 = 160
.line	2246	call          r6    26     2
.line	2246	call          r5     2     2
.line	2246	self          r6    r3   k71 ; k71 = "GetPetSpectatorComp"
.line	2246	call          r6     2     2
.line	2246	gettable      r6    r6   k72 ; k72 = "PetSpectatorPawn"
.line	2246	self          r6    r6  k106 ; k106 = "LocalHandleSpectator" (truncated)
.line	2246	gettable      r8    r5  k107 ; k107 = "SpectatorPetMsgPlayE" (truncated)
.line	2246	move          r9    r2
.line	2246	call          r6     4     1
.line	2246	self          r6    r0   k69 ; k69 = "ShowOrHideRing"
.line	2246	loadbool      r8     0     0
.line	2246	call          r6     3     1
.line	2246	return        r0     1
.label	l305
.line	2246	self          r5    r3  k108 ; k108 = "GetCurPawn"
.line	2246	call          r5     2     2
.line	2246	gettabup      r6    u0   k46 ; k46 = "slua"
.line	2246	gettable      r6    r6   k47 ; k47 = "isValid"
.line	2246	move          r7    r5
.line	2246	call          r6     2     2
.line	2246	test          r6     0
.line	2246	jmp            0  l634
.line	2246	gettabup      r6    u0   k46 ; k46 = "slua"
.line	2246	gettable      r6    r6   k47 ; k47 = "isValid"
.line	2246	gettable      r7    r5  k109 ; k109 = "PetComponent_BP"
.line	2246	call          r6     2     2
.line	2246	test          r6     0
.line	2246	jmp            0  l634
.line	2246	gettabup      r6    u0   k86 ; k86 = "import"
.line	2246	getupval      r7    u1
.line	2246	loadk         r8   k87 ; k87 = 6
.line	2246	loadk         r9   k40 ; k40 = 97
.line	2246	loadk        r10   k75 ; k75 = 207
.line	2246	loadk        r11  k110 ; k110 = 119
.line	2246	loadk        r12  k111 ; k111 = 135
.line	2246	loadk        r13   k92 ; k92 = 213
.line	2246	loadk        r14   k93 ; k93 = 40
.line	2246	loadk        r15   k94 ; k94 = 66
.line	2246	loadk        r16  k112 ; k112 = 176
.line	2246	call          r7    10     2
.line	2246	call          r6     2     2
.line	2246	gettable      r7    r5  k109 ; k109 = "PetComponent_BP"
.line	2246	self          r7    r7  k113 ; k113 = "GetMiniTVPawn"
.line	2246	call          r7     2     2
.line	2246	gettabup      r8    u0   k46 ; k46 = "slua"
.line	2246	gettable      r8    r8   k47 ; k47 = "isValid"
.line	2246	move          r9    r7
.line	2246	call          r8     2     2
.line	2246	test          r8     0
.line	2246	jmp            0  l450
.line	2246	self          r8    r7  k114 ; k114 = "PetHasState"
.line	2246	gettable     r10    r6  k115 ; k115 = "PetParachute"
.line	2246	call          r8     3     2
.line	2246	test          r8     1
.line	2246	jmp            0  l361
.line	2246	self          r8    r7  k114 ; k114 = "PetHasState"
.line	2246	gettable     r10    r6  k116 ; k116 = "PetSwimming"
.line	2246	call          r8     3     2
.line	2246	test          r8     1
.line	2246	jmp            0  l361
.line	2246	self          r8    r7  k114 ; k114 = "PetHasState"
.line	2246	gettable     r10    r6  k117 ; k117 = "PetSleeping"
.line	2246	call          r8     3     2
.line	2246	test          r8     1
.line	2246	jmp            0  l361
.line	2246	self          r8    r7  k114 ; k114 = "PetHasState"
.line	2246	gettable     r10    r6  k118 ; k118 = "PetPlayingFeature"
.line	2246	call          r8     3     2
.line	2246	test          r8     0
.line	2246	jmp            0  l450
.label	l361
.line	2246	gettabup      r8    u0    k5 ; k5 = "print"
.line	2246	gettabup      r9    u0    k6 ; k6 = "bWriteLog"
.line	2246	test          r9     0
.line	2246	jmp            0  l442
.line	2246	gettabup      r9    u0    k7 ; k7 = "table"
.line	2246	gettable      r9    r9    k8 ; k8 = "concat"
.line	2246	newtable     r10     1     0
.line	2246	getupval     r11    u1
.line	2246	loadk        r12    k9 ; k9 = 18
.line	2246	loadk        r13   k10 ; k10 = 68
.line	2246	loadk        r14   k11 ; k11 = 195
.line	2246	loadk        r15   k12 ; k12 = 96
.line	2246	loadk        r16   k13 ; k13 = 191
.line	2246	loadk        r17   k14 ; k14 = 228
.line	2246	loadk        r18   k15 ; k15 = 49
.line	2246	loadk        r19   k16 ; k16 = 70
.line	2246	loadk        r20   k17 ; k17 = 167
.line	2246	loadk        r21   k18 ; k18 = 201
.line	2246	loadk        r22   k19 ; k19 = 121
.line	2246	loadk        r23   k20 ; k20 = 57
.line	2246	loadk        r24   k21 ; k21 = 251
.line	2246	loadk        r25   k22 ; k22 = 182
.line	2246	loadk        r26   k23 ; k23 = 126
.line	2246	loadk        r27   k24 ; k24 = 130
.line	2246	loadk        r28   k25 ; k25 = 231
.line	2246	loadk        r29   k26 ; k26 = 115
.line	2246	loadk        r30   k27 ; k27 = 163
.line	2246	loadk        r31   k28 ; k28 = 103
.line	2246	loadk        r32   k29 ; k29 = 75
.line	2246	loadk        r33   k30 ; k30 = 193
.line	2246	loadk        r34   k31 ; k31 = 85
.line	2246	loadk        r35   k28 ; k28 = 103
.line	2246	loadk        r36   k32 ; k32 = 188
.line	2246	loadk        r37   k33 ; k33 = 241
.line	2246	loadk        r38   k26 ; k26 = 115
.line	2246	loadk        r39   k34 ; k34 = 52
.line	2246	loadk        r40   k35 ; k35 = 235
.line	2246	loadk        r41   k36 ; k36 = 157
.line	2246	loadk        r42   k37 ; k37 = 118
.line	2246	loadk        r43   k38 ; k38 = 237
.line	2246	loadk        r44   k39 ; k39 = 219
.line	2246	loadk        r45   k40 ; k40 = 97
.line	2246	loadk        r46   k41 ; k41 = 184
.line	2246	loadk        r47   k16 ; k16 = 70
.line	2246	loadk        r48   k42 ; k42 = 71
.line	2246	loadk        r49   k43 ; k43 = 242
.line	2246	loadk        r50   k44 ; k44 = 64
.line	2246	loadk        r51   k19 ; k19 = 121
.line	2246	call         r11    41     2
.line	2246	getupval     r12    u1
.line	2246	loadk        r13   k45 ; k45 = 45
.line	2246	loadk        r14   k53 ; k53 = 17
.line	2246	loadk        r15   k25 ; k25 = 231
.line	2246	loadk        r16  k119 ; k119 = 106
.line	2246	loadk        r17   k95 ; k95 = 186
.line	2246	loadk        r18  k120 ; k120 = 200
.line	2246	loadk        r19  k121 ; k121 = 29
.line	2246	loadk        r20   k44 ; k44 = 64
.line	2246	loadk        r21  k122 ; k122 = 245
.line	2246	loadk        r22   k60 ; k60 = 223
.line	2246	loadk        r23   k23 ; k23 = 126
.line	2246	loadk        r24  k123 ; k123 = 43
.line	2246	loadk        r25   k98 ; k98 = 230
.line	2246	loadk        r26   k32 ; k32 = 188
.line	2246	loadk        r27  k124 ; k124 = 48
.line	2246	loadk        r28  k125 ; k125 = 209
.line	2246	loadk        r29  k126 ; k126 = 192
.line	2246	loadk        r30  k127 ; k127 = 33
.line	2246	loadk        r31   k32 ; k32 = 188
.line	2246	loadk        r32  k128 ; k128 = 92
.line	2246	loadk        r33  k129 ; k129 = 86
.line	2246	loadk        r34  k130 ; k130 = 243
.line	2246	loadk        r35  k131 ; k131 = 80
.line	2246	loadk        r36   k88 ; k88 = 98
.line	2246	loadk        r37   k78 ; k78 = 161
.line	2246	loadk        r38  k101 ; k101 = 217
.line	2246	loadk        r39  k132 ; k132 = 116
.line	2246	loadk        r40  k133 ; k133 = 123
.line	2246	call         r12    29     0
.line	2246	setlist      r10     0     1
.line	2246	call          r9     2     2
.label	l442
.line	2246	call          r8     2     1
.line	2246	gettabup      r8    u2   k61 ; k61 = "BattleNormalTipsByTe" (truncated)
.line	2246	loadk         r9  k134 ; k134 = 49084
.line	2246	call          r8     2     1
.line	2246	self          r8    r0   k69 ; k69 = "ShowOrHideRing"
.line	2246	loadbool     r10     0     0
.line	2246	call          r8     3     1
.line	2246	return        r0     1
.label	l450
.line	2246	eq             1    r4    k1 ; k1 = nil
.line	2246	jmp            0  l630
.line	2246	lt             0  k135    r4 ; k135 = 0
.line	2246	jmp            0  l630
.line	2246	gettabup      r8    u0    k5 ; k5 = "print"
.line	2246	gettabup      r9    u0    k6 ; k6 = "bWriteLog"
.line	2246	test          r9     0
.line	2246	jmp            0  l529
.line	2246	gettabup      r9    u0    k7 ; k7 = "table"
.line	2246	gettable      r9    r9    k8 ; k8 = "concat"
.line	2246	newtable     r10     1     0
.line	2246	getupval     r11    u1
.line	2246	loadk        r12    k9 ; k9 = 18
.line	2246	loadk        r13   k10 ; k10 = 68
.line	2246	loadk        r14   k11 ; k11 = 195
.line	2246	loadk        r15   k12 ; k12 = 96
.line	2246	loadk        r16   k13 ; k13 = 191
.line	2246	loadk        r17   k14 ; k14 = 228
.line	2246	loadk        r18   k15 ; k15 = 49
.line	2246	loadk        r19   k16 ; k16 = 70
.line	2246	loadk        r20   k17 ; k17 = 167
.line	2246	loadk        r21   k18 ; k18 = 201
.line	2246	loadk        r22   k19 ; k19 = 121
.line	2246	loadk        r23   k20 ; k20 = 57
.line	2246	loadk        r24   k21 ; k21 = 251
.line	2246	loadk        r25   k22 ; k22 = 182
.line	2246	loadk        r26   k23 ; k23 = 126
.line	2246	loadk        r27   k24 ; k24 = 130
.line	2246	loadk        r28   k25 ; k25 = 231
.line	2246	loadk        r29   k26 ; k26 = 115
.line	2246	loadk        r30   k27 ; k27 = 163
.line	2246	loadk        r31   k28 ; k28 = 103
.line	2246	loadk        r32   k29 ; k29 = 75
.line	2246	loadk        r33   k30 ; k30 = 193
.line	2246	loadk        r34   k31 ; k31 = 85
.line	2246	loadk        r35   k28 ; k28 = 103
.line	2246	loadk        r36   k32 ; k32 = 188
.line	2246	loadk        r37   k33 ; k33 = 241
.line	2246	loadk        r38   k26 ; k26 = 115
.line	2246	loadk        r39   k34 ; k34 = 52
.line	2246	loadk        r40   k35 ; k35 = 235
.line	2246	loadk        r41   k36 ; k36 = 157
.line	2246	loadk        r42   k37 ; k37 = 118
.line	2246	loadk        r43   k38 ; k38 = 237
.line	2246	loadk        r44   k39 ; k39 = 219
.line	2246	loadk        r45   k40 ; k40 = 97
.line	2246	loadk        r46   k41 ; k41 = 184
.line	2246	loadk        r47   k16 ; k16 = 70
.line	2246	loadk        r48   k42 ; k42 = 71
.line	2246	loadk        r49   k43 ; k43 = 242
.line	2246	loadk        r50   k44 ; k44 = 64
.line	2246	loadk        r51   k19 ; k19 = 121
.line	2246	call         r11    41     2
.line	2246	getupval     r12    u1
.line	2246	loadk        r13   k45 ; k45 = 45
.line	2246	loadk        r14   k53 ; k53 = 17
.line	2246	loadk        r15   k25 ; k25 = 231
.line	2246	loadk        r16   k88 ; k88 = 98
.line	2246	loadk        r17   k17 ; k17 = 167
.line	2246	loadk        r18   k92 ; k92 = 213
.line	2246	loadk        r19   k58 ; k58 = 44
.line	2246	loadk        r20   k10 ; k10 = 68
.line	2246	loadk        r21  k122 ; k122 = 245
.line	2246	loadk        r22  k136 ; k136 = 216
.line	2246	loadk        r23  k137 ; k137 = 120
.line	2246	loadk        r24  k138 ; k138 = 35
.line	2246	loadk        r25  k122 ; k122 = 245
.line	2246	loadk        r26  k139 ; k139 = 190
.line	2246	loadk        r27  k140 ; k140 = 117
.line	2246	loadk        r28  k141 ; k141 = 202
.line	2246	loadk        r29  k142 ; k142 = 147
.line	2246	loadk        r30  k143 ; k143 = 114
.line	2246	loadk        r31  k144 ; k144 = 177
.line	2246	loadk        r32   k97 ; k97 = 90
.line	2246	loadk        r33  k145 ; k145 = 72
.line	2246	loadk        r34  k146 ; k146 = 253
.line	2246	call         r12    23     0
.line	2246	setlist      r10     0     1
.line	2246	call          r9     2     2
.label	l529
.line	2246	move         r10    r4
.line	2246	call          r8     3     1
.line	2246	gettabup      r8    u0   k46 ; k46 = "slua"
.line	2246	gettable      r8    r8   k47 ; k47 = "isValid"
.line	2246	move          r9    r5
.line	2246	call          r8     2     2
.line	2246	test          r8     0
.line	2246	jmp            0  l630
.line	2246	self          r8    r5  k147 ; k147 = "GetSkillManager"
.line	2246	call          r8     2     2
.line	2246	gettabup      r9    u0   k46 ; k46 = "slua"
.line	2246	gettable      r9    r9   k47 ; k47 = "isValid"
.line	2246	move         r10    r8
.line	2246	call          r9     2     2
.line	2246	test          r9     0
.line	2246	jmp            0  l630
.line	2246	self          r9    r8  k148 ; k148 = "GetSkill"
.line	2246	move         r11    r4
.line	2246	call          r9     3     2
.line	2246	test          r9     0
.line	2246	jmp            0  l630
.line	2246	self         r10    r9  k149 ; k149 = "IsCDOK"
.line	2246	move         r12    r8
.line	2246	loadk        r13  k150 ; k150 = -1
.line	2246	call         r10     4     2
.line	2246	test         r10     1
.line	2246	jmp            0  l630
.line	2246	gettabup     r10    u0    k5 ; k5 = "print"
.line	2246	gettabup     r11    u0    k6 ; k6 = "bWriteLog"
.line	2246	test         r11     0
.line	2246	jmp            0  l621
.line	2246	gettabup     r11    u0    k7 ; k7 = "table"
.line	2246	gettable     r11   r11    k8 ; k8 = "concat"
.line	2246	newtable     r12     1     0
.line	2246	getupval     r13    u1
.line	2246	loadk        r14    k9 ; k9 = 18
.line	2246	loadk        r15   k10 ; k10 = 68
.line	2246	loadk        r16   k11 ; k11 = 195
.line	2246	loadk        r17   k12 ; k12 = 96
.line	2246	loadk        r18   k13 ; k13 = 191
.line	2246	loadk        r19   k14 ; k14 = 228
.line	2246	loadk        r20   k15 ; k15 = 49
.line	2246	loadk        r21   k16 ; k16 = 70
.line	2246	loadk        r22   k17 ; k17 = 167
.line	2246	loadk        r23   k18 ; k18 = 201
.line	2246	loadk        r24   k19 ; k19 = 121
.line	2246	loadk        r25   k20 ; k20 = 57
.line	2246	loadk        r26   k21 ; k21 = 251
.line	2246	loadk        r27   k22 ; k22 = 182
.line	2246	loadk        r28   k23 ; k23 = 126
.line	2246	loadk        r29   k24 ; k24 = 130
.line	2246	loadk        r30   k25 ; k25 = 231
.line	2246	loadk        r31   k26 ; k26 = 115
.line	2246	loadk        r32   k27 ; k27 = 163
.line	2246	loadk        r33   k28 ; k28 = 103
.line	2246	loadk        r34   k29 ; k29 = 75
.line	2246	loadk        r35   k30 ; k30 = 193
.line	2246	loadk        r36   k31 ; k31 = 85
.line	2246	loadk        r37   k28 ; k28 = 103
.line	2246	loadk        r38   k32 ; k32 = 188
.line	2246	loadk        r39   k33 ; k33 = 241
.line	2246	loadk        r40   k26 ; k26 = 115
.line	2246	loadk        r41   k34 ; k34 = 52
.line	2246	loadk        r42   k35 ; k35 = 235
.line	2246	loadk        r43   k36 ; k36 = 157
.line	2246	loadk        r44   k37 ; k37 = 118
.line	2246	loadk        r45   k38 ; k38 = 237
.line	2246	loadk        r46   k39 ; k39 = 219
.line	2246	loadk        r47   k40 ; k40 = 97
.line	2246	loadk        r48   k41 ; k41 = 184
.line	2246	loadk        r49   k16 ; k16 = 70
.line	2246	loadk        r50   k42 ; k42 = 71
.line	2246	loadk        r51   k43 ; k43 = 242
.line	2246	loadk        r52   k44 ; k44 = 64
.line	2246	loadk        r53   k19 ; k19 = 121
.line	2246	call         r13    41     2
.line	2246	getupval     r14    u1
.line	2246	loadk        r15   k45 ; k45 = 45
.line	2246	loadk        r16   k53 ; k53 = 17
.line	2246	loadk        r17  k101 ; k101 = 217
.line	2246	loadk        r18  k151 ; k151 = 104
.line	2246	loadk        r19  k152 ; k152 = 189
.line	2246	loadk        r20  k153 ; k153 = 205
.line	2246	loadk        r21  k154 ; k154 = 37
.line	2246	loadk        r22  k155 ; k155 = 22
.line	2246	loadk        r23  k156 ; k156 = 156
.line	2246	loadk        r24  k157 ; k157 = 194
.line	2246	loadk        r25  k158 ; k158 = 73
.line	2246	loadk        r26  k159 ; k159 = 14
.line	2246	call         r14    13     0
.line	2246	setlist      r12     0     1
.line	2246	call         r11     2     2
.label	l621
.line	2246	move         r12    r4
.line	2246	call         r10     3     1
.line	2246	gettabup     r10    u2   k61 ; k61 = "BattleNormalTipsByTe" (truncated)
.line	2246	loadk        r11  k160 ; k160 = 7108
.line	2246	call         r10     2     1
.line	2246	self         r10    r0   k69 ; k69 = "ShowOrHideRing"
.line	2246	loadbool     r12     0     0
.line	2246	call         r10     3     1
.line	2246	return        r0     1
.label	l630
.line	2246	self          r8    r3  k161 ; k161 = "PlaySpecifiedPetAnim" (truncated)
.line	2246	move         r10    r2
.line	2246	loadbool     r11     1     0
.line	2246	call          r8     4     1
.label	l634
.line	2246	self          r6    r0   k69 ; k69 = "ShowOrHideRing"
.line	2246	loadbool      r8     0     0
.line	2246	call          r6     3     1
.label	l637
.line	2246	return        r0     1
.line	2246	move          r0    r0
.line	2246	move          r0    r0
.line	2246	move          r0    r0
.line	2246	return        r0     1

.function	main/f94

.source	"=[V12L:7ce631a10e697db2:bcfa78d6cdfb8792]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f95

.source	"=[V11_@Black_MagicYT BlackMagiYT_LBIND_00]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_0_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f96

.source	"=[V11_@Black_MagicYT BlackMagiYT_SYSC_01]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_1_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f97

.source	"=[V11_@Black_MagicYT BlackMagiYT_MRGE_02]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_2_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f98

.source	"=[V11_@Black_MagicYT BlackMagiYT_POOL_03]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_3_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	return        r0     1

