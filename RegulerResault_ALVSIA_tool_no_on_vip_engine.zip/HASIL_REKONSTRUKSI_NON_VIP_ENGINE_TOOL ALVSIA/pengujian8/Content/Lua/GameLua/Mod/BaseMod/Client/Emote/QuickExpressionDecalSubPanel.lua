do return require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(118, 120, 161, 136, 127)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(118, 120, 169, 158, 98, 4, 104, 77, 43, 247, 209, 150, 226, 86, 84, 90, 151, 69, 221, 174, 139, 47, 68, 101, 121, 240, 193, 170, 226))), nil, {
  ["ctor"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 76, 111, 67, 135))
      _ARG_0_.CurrentShowState = U2.None
      _ARG_0_.ItemDefineIDTemp = FItemDefineIDDefault()
      _ARG_0_.AllLimitEmoteList = {}
      _ARG_0_.ClothBackpackItem = {}
      _ARG_0_.GreyColor = FLinearColor(0.49, 0.49, 0.49, 1.0)
      _ARG_0_.ColorA = U3.HSVToRGB(0.0, 0.0, 0.2, 1.0)
      _ARG_0_.ColorB = U3.HSVToRGB(0.0, 0.0, 1.0, 1.0)
      _ARG_0_.EmoteDecalArray = slua.Array(UEnums.EPropertyClass.Int)
      _ARG_0_.EmoteDecalArray:Add(UEnums.EBackpackItemType.Emote)
      _ARG_0_.EmoteDecalArray:Add(UEnums.EBackpackItemType.Decal)
      _ARG_0_.PetID = -1
      _ARG_0_.PetLevel = -1
      _ARG_0_.CurPetExpressionList = {}
      _ARG_0_.CollectionList = {}
      _ARG_0_.bShowMyPet = false
      _ARG_0_.QuickExpressionDecalItemList = {}
      _ARG_0_.WeaponShowEmoteID = 0
      _ARG_0_.bShowBottom = true
      _ARG_0_.bShowDecal = true
      _ARG_0_.bInitMiniTvExpressionList = false
      _ARG_0_.MiniTvExpressionList = {}
      _ARG_0_.bShowMiniTv = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 111, 153, 91, 211, 190))
      _ARG_0_:RefreshChangeAvatarFormBtnState(false)
      if _ARG_0_.OnEnterBattleEventHandle then
        EventSystem:UnregistEventByID(_ARG_0_.OnEnterBattleEventHandle)
        _ARG_0_.OnEnterBattleEventHandle = nil
      end
      goto lbl_61
      ::lbl_61::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.QuickExpressionDecalItemList = nil
      U2.__super.OnClose(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      if UIManager.GetUI(UIManager.UI_Config_InGame.QuickExpressionDecalUI) then
      end
      _ARG_0_.LastCloseShowState = U2.None
      if _ARG_0_:IsSocialIsland() then
        _ARG_0_.LastEmoteState = U2.IslandExpression
      else
        _ARG_0_.LastEmoteState = U2.Expression
      end
      _ARG_0_.LastMoreState = U2.Decal
      if not _ARG_0_:HasEquipHolography() then
      elseif _ARG_0_:IsSocialIsland() then
      elseif _ARG_0_:IsMainCity() then
      elseif _ARG_0_:IsTypicalGameMode() then
        _ARG_0_.OnEnterBattleEventHandle = EventSystem:registEventWithConditions(EVENTTYPE_INGAME_NORMAL, EVENTID_GAME_MODE_STATE_CHANGE, {
          [1] = U1(83, 125, 167, 147, 120, 25, 40, 89, 20, 246, 209, 189, 242)
        }, _ARG_0_.OnEnterBattle, _ARG_0_)
      else
      end
      if _ARG_0_:CanShowPetBubblePanel() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 125, 126, 75, 156, 71, 212, 158, 154, 53, 72, 106),
        U1(102)
      }))
      U2(_ARG_0_, _ARG_0_.UIRoot.Button_2, U1(87, 97, 180, 143, 99, 30, 25, 12), U1(90, 122, 131, 151, 101, 19, 45, 91, 35), _ARG_0_.OnButtonHolography)
      U2(_ARG_0_, _ARG_0_.UIRoot.Button_0, U1(87, 97, 180, 143, 99, 30, 25, 14), U1(90, 122, 131, 151, 101, 19, 45, 91, 35), _ARG_0_.OnButtonExpression)
      U2(_ARG_0_, _ARG_0_.UIRoot.Button_20, U1(87, 97, 180, 143, 99, 30, 25, 12, 119), U1(90, 122, 131, 151, 101, 19, 45, 91, 35), _ARG_0_.OnButtonCollection)
      U2(_ARG_0_, _ARG_0_.UIRoot.Button_24, U1(87, 97, 180, 143, 99, 30, 25, 12, 115), U1(90, 122, 131, 151, 101, 19, 45, 91, 35), _ARG_0_.OnButtonMore)
      U2(_ARG_0_, _ARG_0_.UIRoot.Button_28, U1(87, 97, 180, 143, 99, 30, 25, 12, 127), U1(90, 122, 131, 151, 101, 19, 45, 91, 35), _ARG_0_.OnButtonPlayerExpression)
      U2(_ARG_0_, _ARG_0_.UIRoot.Button_6, U1(87, 97, 180, 143, 99, 30, 25, 8), U1(90, 122, 131, 151, 101, 19, 45, 91, 35), _ARG_0_.OnButtonBubble)
      U2(_ARG_0_, _ARG_0_.UIRoot.Button_8, U1(87, 97, 180, 143, 99, 30, 25, 6), U1(90, 122, 131, 151, 101, 19, 45, 91, 35), _ARG_0_.OnButtonDecal)
      U2(_ARG_0_, _ARG_0_.UIRoot.Button_4, U1(87, 97, 180, 143, 99, 30, 25, 10), U1(90, 122, 131, 151, 101, 19, 45, 91, 35), _ARG_0_.OnButtonPetExpression)
      U2(_ARG_0_, _ARG_0_.UIRoot.Button_PhotoEdit, U1(87, 97, 180, 143, 99, 30, 25, 110, 47, 237, 196, 166, 210, 91, 98, 72), U1(90, 122, 131, 151, 101, 19, 45, 91, 35), _ARG_0_.OnButton_PhotoEditClick)
      U2(_ARG_0_, _ARG_0_.UIRoot.Button_ShowPet, U1(87, 97, 180, 143, 99, 30, 25, 109, 47, 237, 199, 153, 242, 75), U1(90, 122, 131, 151, 101, 19, 45, 91, 35), _ARG_0_.OnButtonShowPet)
      U2(_ARG_0_, _ARG_0_.UIRoot.Button_10, U1(87, 97, 180, 143, 99, 30, 25, 15, 119), U1(90, 122, 131, 151, 101, 19, 45, 91, 35), _ARG_0_.OnButtonPetBubble)
      U2(_ARG_0_, _ARG_0_.UIRoot.Button_12, U1(87, 97, 180, 143, 99, 30, 25, 15, 117), U1(90, 122, 131, 151, 101, 19, 45, 91, 35), _ARG_0_.OnButtonSpectatorPetBubble)
      U2(_ARG_0_, _ARG_0_.UIRoot.Button_14, U1(87, 97, 180, 143, 99, 30, 25, 15, 115), U1(90, 122, 131, 151, 101, 19, 45, 91, 35), _ARG_0_.OnButtonMiniTvExpression)
      U2(_ARG_0_, _ARG_0_.UIRoot.Button_ShowRobot, U1(87, 97, 180, 143, 99, 30, 25, 109, 47, 237, 199, 155, 248, 93, 100, 72), U1(90, 122, 131, 151, 101, 19, 45, 91, 35), _ARG_0_.OnButtonShowMiniTv)
      U2(_ARG_0_, _ARG_0_.UIRoot.Button_Flaunt_UnSelect, U1(87, 97, 180, 143, 99, 30, 25, 120, 43, 227, 197, 167, 227, 96, 94, 82, 182, 65, 220, 174, 159, 52), U1(90, 122, 131, 151, 101, 19, 45, 91, 35), _ARG_0_.OnButtonFlaunt_UnSelect)
      U2(_ARG_0_, _ARG_0_.UIRoot.Button_Collection_UnSelect, U1(87, 97, 180, 143, 99, 30, 25, 125, 40, 238, 220, 172, 244, 75, 98, 83, 139, 123, 229, 165, 175, 37, 90, 107, 52, 230), U1(90, 122, 131, 151, 101, 19, 45, 91, 35), _ARG_0_.OnButtonCollection_UnSelect)
      _ARG_0_.UpdateItemArr = slua.Array(UEnums.EPropertyClass.Int)
      if U3.GetCurrentConfig((U1(92, 96, 165, 150, 79, 31, 40, 88, 46, 229))) and U3.GetCurrentConfig((U1(92, 96, 165, 150, 79, 31, 40, 88, 46, 229))).ItemID2Emote and _ARG_0_.UpdateItemArr then
        goto lbl_649
        ::lbl_649::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCustomWeaponShowChange"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshCheckGunBtnState()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostInitialize"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 124, 154, 71, 212, 146, 130, 57, 82, 119),
        U1(116, 120, 169, 129, 105)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShow"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 127, 157, 91, 215))
      if slua.isValid((slua_GameFrontendHUD:GetGameState())) and slua_GameFrontendHUD:GetGameState().GetGameModeState then
        if slua_GameFrontendHUD:GetGameState():GetGameModeState() == U1(83, 125, 167, 147, 120, 25, 40, 89, 20, 246, 209, 189, 242) then
          _ARG_0_.HasEnterBattle = true
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnHide"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 100, 156, 80, 197))
      _ARG_0_:CloseContent()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenContent"] = function(_ARG_0_)
    do
      if _ARG_0_.LastCloseShowState ~= None then
        _ARG_0_.CurrentShowState = _ARG_0_.LastCloseShowState
      elseif _ARG_0_:IsSocialIsland() then
        _ARG_0_.CurrentShowState = IslandExpression
      else
        _ARG_0_.CurrentShowState = Expression
      end
      U1.print(U1.bWriteLog and U1.table.concat({
        U2(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 107, 73, 155, 119, 207, 181, 152, 53, 72, 106),
        U2(57, 52)
      }) .. _ARG_0_.CurrentShowState)
      _ARG_0_:RefreshGridPanel()
      U1.EventSystem:postEvent(U1.EVENTTYPE_INGAME, U1.EVENTID_INGAME_QUICK_EXPRESSION_DECAL_CLICK)
      U1.EventSystem:postEvent(U1.EVENTTYPE_CLIENT_TLOG, U1.EVENTID_ADD_VALUE_TLOG, U2(92, 122, 164, 146, 122, 25, 34, 75, 38, 238, 243, 165, 254, 92, 96, 114, 144, 73), 1)
      _ARG_0_.UIRoot:InvalidateLayoutAndVolatility()
      _ARG_0_.UIRoot:ForceLayoutPrepass()
      _ARG_0_:ShowChangeFormGuide2()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseContent"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 108, 119, 67, 134, 81, 227, 180, 130, 36, 67, 112),
        U1(97, 56, 224)
      }) .. _ARG_0_.CurrentShowState)
      if _ARG_0_.CurrentShowState ~= U3.None then
        _ARG_0_.LastCloseShowState = _ARG_0_.CurrentShowState
        _ARG_0_.CurrentShowState = U3.None
      end
      if UIManager.GetUI(UIManager.UI_Config_InGame.QuickExpressionDecalUI) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnAvatarAllMeshLoaded"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 109, 131, 85, 212, 186, 158, 17, 74, 114),
        U1(88, 113, 179, 147, 64, 31, 39, 90, 34, 230)
      }))
      if _ARG_0_.CurrentShowState ~= U2.None then
        _ARG_0_:RefreshChangeAvatarFormBtnState(true)
      end
      _ARG_0_:RefreshTransformButton()
      _ARG_0_:ShowChangeFormGuide2()
      _ARG_0_:RefreshXSuitEmoteButton()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCheckShowEffects"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 111, 157, 81, 195, 176, 191, 56, 73, 105),
        U1(80, 114, 166, 158, 111, 4, 53)
      }) .. tostring(_ARG_1_))
      if slua.isValid((U2.GetPlayerController())) then
        if _ARG_0_.CurrentShowState == U3.Expression then
        elseif _ARG_0_.CurrentShowState == U3.IslandExpression then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreEnterSelfie"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(78, 80, 165, 154, 98, 58, 31, 106, 26, 162, 225, 188, 254, 92, 96, 121, 157, 84, 194, 174, 143, 51, 95, 97, 57, 214, 197, 186, 230, 67, 72, 89, 151, 100, 193, 181, 137, 60, 28, 81),
        U1(123, 68, 178, 158, 73, 30, 50, 91, 53, 209, 213, 165, 241, 86, 110)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetShowMyPet"] = function(_ARG_0_)
    do
      if U1.slua.isValid((GetPlayerController())) and GetPlayerController().IsInPetSpectator and GetPlayerController():IsInPetSpectator() and GetPlayerController().InitialPetInfo then
        return true
      end
      if U1.slua.isValid((GetPlayerController())) and U1.slua.isValid((GetPlayerCharacter())) then
        if GetPlayerCharacter().IsFPP then
          return U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.SettingModule):GetOptionValue((U2(90, 100, 165, 149, 65, 9, 22, 91, 51, 196, 224, 153)))
        else
          return U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.SettingModule):GetOptionValue((U2(90, 100, 165, 149, 65, 9, 22, 91, 51)))
        end
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonHolography"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 110, 128, 64, 212, 180, 130, 24, 73, 114),
        U1(122, 115, 178, 154, 124, 24, 63)
      }) .. _ARG_0_.CurrentShowState)
      if _ARG_0_.CurrentShowState ~= U2.Holography then
        _ARG_0_.CurrentShowState = U2.Holography
        _ARG_0_:RefreshGridPanel()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonExpression"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 110, 128, 64, 212, 180, 130, 21, 94, 110),
        U1(103, 113, 179, 136, 101, 31, 40)
      }) .. _ARG_0_.CurrentShowState)
      if _ARG_0_.CurrentShowState ~= _ARG_0_.LastEmoteState then
        _ARG_0_.CurrentShowState = _ARG_0_.LastEmoteState
        _ARG_0_:RefreshGridPanel()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonPlayerExpression"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 110, 128, 64, 212, 180, 130, 0, 74, 127),
        U1(108, 113, 178, 190, 116, 0, 52, 91, 52, 241, 217, 166, 249)
      }) .. _ARG_0_.CurrentShowState)
      if _ARG_0_:IsSocialIsland() then
        if _ARG_0_.CurrentShowState ~= U2.IslandExpression then
          _ARG_0_.CurrentShowState = U2.IslandExpression
          _ARG_0_:RefreshGridPanel()
        end
      elseif _ARG_0_.CurrentShowState ~= U2.Expression then
        _ARG_0_.CurrentShowState = U2.Expression
        _ARG_0_:RefreshGridPanel()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonMore"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 110, 128, 64, 212, 180, 130, 29, 73, 108),
        U1(112)
      }) .. _ARG_0_.CurrentShowState, _ARG_0_.LastMoreState)
      if _ARG_0_.CurrentShowState ~= _ARG_0_.LastMoreState then
        _ARG_0_.CurrentShowState = _ARG_0_.LastMoreState
        _ARG_0_:RefreshGridPanel()
      end
      _ARG_0_:RefreshAndSaveRed(true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshAndSaveRed"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
        return
      end
      if not require((table.concat({
        U1(118, 120, 169, 158, 98, 4, 104, 82, 40, 229, 217, 170, 185, 115, 100, 91, 140, 71, 224, 167, 157, 57, 83, 124, 7, 224, 197, 191, 244, 1, 107, 64, 148, 77, 197, 169, 156, 34, 67, 120),
        U1(102)
      }))).LoadFileToTable_N(require((table.concat({
        U1(118, 120, 169, 158, 98, 4, 104, 82, 40, 229, 217, 170, 185, 115, 100, 91, 140, 71, 224, 167, 157, 57, 83, 124, 7, 224, 197, 191, 244, 1, 107, 64, 148, 77, 197, 169, 156, 34, 67, 120),
        U1(102)
      }))).ePlayerPrefsType.ePetActionInBattleRed) or require((table.concat({
        U1(118, 120, 169, 158, 98, 4, 104, 82, 40, 229, 217, 170, 185, 115, 100, 91, 140, 71, 224, 167, 157, 57, 83, 124, 7, 224, 197, 191, 244, 1, 107, 64, 148, 77, 197, 169, 156, 34, 67, 120),
        U1(102)
      }))).LoadFileToTable_N(require((table.concat({
        U1(118, 120, 169, 158, 98, 4, 104, 82, 40, 229, 217, 170, 185, 115, 100, 91, 140, 71, 224, 167, 157, 57, 83, 124, 7, 224, 197, 191, 244, 1, 107, 64, 148, 77, 197, 169, 156, 34, 67, 120),
        U1(102)
      }))).ePlayerPrefsType.ePetActionInBattleRed) == 0 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonBubble"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 110, 128, 64, 212, 180, 130, 18, 83, 124),
        U1(119, 120, 165)
      }) .. _ARG_0_.CurrentShowState)
      if _ARG_0_.CurrentShowState ~= U2.Bubble then
        _ARG_0_.CurrentShowState = U2.Bubble
        _ARG_0_:RefreshGridPanel()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonDecal"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 110, 128, 64, 212, 180, 130, 20, 67, 125),
        U1(116, 120)
      }) .. _ARG_0_.CurrentShowState)
      if _ARG_0_.CurrentShowState ~= U2.Decal then
        _ARG_0_.CurrentShowState = U2.Decal
        _ARG_0_:RefreshGridPanel()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonPetExpression"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 110, 128, 64, 212, 180, 130, 0, 67, 106),
        U1(80, 108, 176, 137, 105, 3, 53, 87, 40, 236)
      }) .. _ARG_0_.CurrentShowState)
      if _ARG_0_.CurrentShowState ~= U2.PetExpression then
        print(bWriteLog and table.concat({
          U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 110, 128, 64, 212, 180, 130, 0, 67, 106),
          U1(80, 108, 176, 137, 105, 3, 53, 87, 40, 236, 144, 153, 242, 75, 66, 120, 223)
        }) .. tostring(_ARG_0_.PetID) .. U1(57, 52, 162, 168, 100, 31, 49, 115, 62, 210, 213, 189, 173) .. tostring(_ARG_0_.bShowMyPet))
        _ARG_0_.CurrentShowState = U2.PetExpression
        _ARG_0_:RefreshGridPanel()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonShowPet"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 110, 128, 64, 212, 180, 130, 3, 78, 113),
        U1(98, 68, 165, 143)
      }))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_PhotoEditClick"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(78, 80, 165, 154, 98, 58, 31, 106, 26, 162, 225, 188, 254, 92, 96, 121, 157, 84, 194, 174, 143, 51, 95, 97, 57, 214, 197, 186, 230, 67, 72, 89, 151, 100, 193, 181, 137, 60, 28, 81),
        U1(123, 86, 181, 143, 120, 31, 40, 97, 23, 234, 223, 189, 248, 122, 111, 85, 145, 103, 220, 162, 159, 43)
      }))
      if SubsystemMgr:Get((U1(65, 102, 161, 149, 127, 0, 39, 76, 34, 236, 196, 156, 222, 114, 100, 88, 128, 119, 197, 169, 143, 57, 69, 122, 50, 255))) and not SubsystemMgr:Get((U1(65, 102, 161, 149, 127, 0, 39, 76, 34, 236, 196, 156, 222, 114, 100, 88, 128, 119, 197, 169, 143, 57, 69, 122, 50, 255))).IsShow then
        return
      end
      if not SubsystemMgr:Get((U1(92, 122, 167, 154, 97, 21, 21, 91, 43, 228, 217, 172, 196, 74, 105, 79, 156, 87, 196, 174, 145))) then
        return
      end
      do return end
      _ARG_0_ = _ENV[67]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonCollection"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 110, 128, 64, 212, 180, 130, 19, 73, 114),
        U1(121, 113, 163, 143, 101, 31, 40)
      }) .. _ARG_0_.CurrentShowState)
      if _ARG_0_.CurrentShowState ~= U2.Flaunt then
        _ARG_0_.CurrentShowState = U2.Flaunt
        _ARG_0_:RefreshGridPanel()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonFlaunt_UnSelect"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 110, 128, 64, 212, 180, 130, 22, 74, 127),
        U1(96, 122, 180, 164, 89, 30, 21, 91, 43, 231, 211, 189)
      }) .. _ARG_0_.CurrentShowState)
      if _ARG_0_.CurrentShowState ~= U2.Flaunt then
        _ARG_0_.CurrentShowState = U2.Flaunt
        _ARG_0_:RefreshGridPanel()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonCollection_UnSelect"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 110, 128, 64, 212, 180, 130, 19, 73, 114),
        U1(121, 113, 163, 143, 101, 31, 40, 97, 18, 236, 227, 172, 251, 90, 104, 72)
      }) .. _ARG_0_.CurrentShowState)
      if _ARG_0_.CurrentShowState ~= U2.Collection then
        _ARG_0_.CurrentShowState = U2.Collection
        _ARG_0_:RefreshGridPanel()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetShowState"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 124, 126, 88, 166, 92, 207, 172, 191, 36, 71, 106),
        U1(112, 52, 179, 158, 120, 80, 123, 30)
      }) .. _ARG_1_ .. U1(53, 119, 181, 137, 126, 21, 40, 74, 103, 191, 144) .. _ARG_0_.CurrentShowState)
      if _ARG_0_.CurrentShowState ~= _ARG_1_ then
        _ARG_0_.CurrentShowState = _ARG_1_
        _ARG_0_:RefreshGridPanel()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickItem"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or _ARG_1_ <= 0 then
        return
      end
      if not require((U1(118, 120, 169, 158, 98, 4, 104, 93, 40, 239, 221, 166, 249, 17, 126, 85, 186, 81, 196, 162, 144))).CanClickNow(require((U1(118, 120, 169, 158, 98, 4, 104, 93, 40, 239, 221, 166, 249, 17, 126, 85, 186, 81, 196, 162, 144))).ClickFrequencyLimit.InteractiveCommon) then
        return false
      end
      if _ARG_0_.CurrentShowState == U2.Decal then
        if not _ARG_0_:GetIsItemHandleExist(23, _ARG_1_) then
          return
        end
        if _ARG_0_:RequirPaint(_ARG_1_) then
        end
      elseif _ARG_0_.CurrentShowState == U2.Holography then
      elseif _ARG_0_.CurrentShowState == U2.Expression then
      elseif _ARG_0_.CurrentShowState == U2.Bubble then
        if _ARG_1_ ~= nil and U4.GetSysByName((U1(92, 103, 172, 154, 98, 20, 4, 75, 37, 224, 220, 172, 210, 82, 100, 72, 128, 119, 201, 184))) ~= nil then
        end
      elseif _ARG_0_.CurrentShowState == U2.IslandExpression then
        if _ARG_1_ == _ARG_0_.WeaponShowEmoteID then
        elseif U4.GetSysByName((U1(80, 121, 175, 143, 105, 49, 37, 74, 46, 237, 222, 154, 238, 76))) ~= nil and U4.GetSysByName((U1(80, 121, 175, 143, 105, 49, 37, 74, 46, 237, 222, 154, 238, 76))):TryPlayEmote(_ARG_1_) then
        end
      elseif _ARG_0_.CurrentShowState == U2.PetExpression then
        U5().AnimationAssetId = _ARG_1_
        if slua.isValid((U6.GetPlayerController())) and _ARG_1_ then
          goto lbl_505
          if (176).ID == _ARG_1_ then
          else
            ::lbl_505::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
          if (176).IsLocked then
            return
          end
          if not _ARG_0_:GetIsEmoteExist(_ARG_1_) then
            return
          end
          if U6.GetPlayerController().IsInPetSpectator and U6.GetPlayerController():IsInPetSpectator() and U6.GetPlayerController():GetPetSpectatorComp() and U6.GetPlayerController():GetPetSpectatorComp().PetSpectatorPawn then
          else
            if slua.isValid((U6.GetPlayerController():GetCurPawn())) and slua.isValid(U6.GetPlayerController():GetCurPawn().PetComponent_BP) and slua.isValid(U6.GetPlayerController():GetCurPawn().PetComponent_BP.PetPawn) and (U6.GetPlayerController():GetCurPawn().PetComponent_BP.PetPawn:PetHasState(U8.PetParachute) or U6.GetPlayerController():GetCurPawn().PetComponent_BP.PetPawn:PetHasState(U8.PetSwimming) or U6.GetPlayerController():GetCurPawn().PetComponent_BP.PetPawn:PetHasState(U8.PetSleeping) or U6.GetPlayerController():GetCurPawn().PetComponent_BP.PetPawn:PetHasState(U8.PetPlayingFeature)) then
              return
            end
            if (176).MasterSkillID ~= nil and 0 < (176).MasterSkillID then
              if slua.isValid((U6.GetPlayerController():GetCurPawn())) and slua.isValid((U6.GetPlayerController():GetCurPawn():GetSkillManager())) and U6.GetPlayerController():GetCurPawn():GetSkillManager():GetSkill((176).MasterSkillID) and not U6.GetPlayerController():GetCurPawn():GetSkillManager():GetSkill((176).MasterSkillID):IsCDOK(U6.GetPlayerController():GetCurPawn():GetSkillManager(), -1) then
                return
              end
            end
          end
        end
      elseif _ARG_0_.CurrentShowState == U2.Collection then
      elseif _ARG_0_.CurrentShowState == U2.Flaunt then
        if not U9.CheckIsPetExhibitionEmote(_ARG_1_) then
        elseif U9.CheckCanUsePetExhibitionEmote() then
        else
        end
      elseif _ARG_0_.CurrentShowState == U2.PetBubble or _ARG_0_.CurrentShowState == U2.SpectatorPetBubble then
        if _ARG_1_ and slua.isValid((U6.GetPlayerController())) then
          if U6.GetPlayerController().IsInPetSpectator and U6.GetPlayerController():IsInPetSpectator() then
            if slua.isValid(slua.isValid(U6.GetPlayerController():GetPetSpectatorComp() and U6.GetPlayerController():GetPetSpectatorComp().PetSpectatorPawn) and (U6.GetPlayerController():GetPetSpectatorComp() and U6.GetPlayerController():GetPetSpectatorComp().PetSpectatorPawn).PetBubbleComponent_BP) then
              if slua.isValid(slua.isValid(U6.GetPlayerController():GetPetSpectatorComp() and U6.GetPlayerController():GetPetSpectatorComp().PetSpectatorPawn) and (U6.GetPlayerController():GetPetSpectatorComp() and U6.GetPlayerController():GetPetSpectatorComp().PetSpectatorPawn).PetBubbleComponent_BP) then
              else
              end
            end
          else
            if not U6.GetPlayerController():CanShowMyPet() then
              return
            end
            if slua.isValid((U6.GetPlayerController():GetCurPawn())) then
              if slua.isValid(U6.GetPlayerController():GetCurPawn().PetComponent_BP) and slua.isValid(U6.GetPlayerController():GetCurPawn().PetComponent_BP.PetPawn) and (U6.GetPlayerController():GetCurPawn().PetComponent_BP.PetPawn:PetHasState(U8.PetParachute) or U6.GetPlayerController():GetCurPawn().PetComponent_BP.PetPawn:PetHasState(U8.PetSwimming) or U6.GetPlayerController():GetCurPawn().PetComponent_BP.PetPawn:PetHasState(U8.PetSleeping) or U6.GetPlayerController():GetCurPawn().PetComponent_BP.PetPawn:PetHasState(U8.PetPlayingFeature)) then
                return
              end
              if 0 <= U6.GetPlayerController().UsingAdditionalPetIndex and U6.GetPlayerController().AdditionalPetInfo:Num() > U6.GetPlayerController().UsingAdditionalPetIndex then
              else
              end
              if (U6.GetPlayerController().InitialPetInfo.PetId or 0) == 0 or (U6.GetPlayerController().InitialPetInfo.PetId or 0) == 50001 then
                return
              end
              if U6.GetPlayerController():GetCurPawn().PetExhibitFeature then
              else
              end
            end
          end
        end
      elseif _ARG_0_.CurrentShowState == U2.MiniTvExpression then
        U5().AnimationAssetId = _ARG_1_
        if slua.isValid((U6.GetPlayerController())) and _ARG_1_ then
          goto lbl_1691
          if U1(53, 68, 165, 143, 73, 8, 46, 87, 37, 235, 196, 143, 242, 94, 127, 73, 151, 65, 144, 162, 143, 96, 88, 97, 35, 178, 214, 184, 235, 70, 127).ID == _ARG_1_ then
          else
            ::lbl_1691::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
          if not _ARG_0_:GetIsEmoteExist(_ARG_1_) then
            return
          end
          if U6.GetPlayerController().IsInPetSpectator and U6.GetPlayerController():IsInPetSpectator() and U6.GetPlayerController():GetPetSpectatorComp() and U6.GetPlayerController():GetPetSpectatorComp().PetSpectatorPawn then
          else
            if slua.isValid((U6.GetPlayerController():GetCurPawn())) and slua.isValid(U6.GetPlayerController():GetCurPawn().PetComponent_BP) and slua.isValid((U6.GetPlayerController():GetCurPawn().PetComponent_BP:GetMiniTVPawn())) and (U6.GetPlayerController():GetCurPawn().PetComponent_BP:GetMiniTVPawn():PetHasState(U8.PetParachute) or U6.GetPlayerController():GetCurPawn().PetComponent_BP:GetMiniTVPawn():PetHasState(U8.PetSwimming) or U6.GetPlayerController():GetCurPawn().PetComponent_BP:GetMiniTVPawn():PetHasState(U8.PetSleeping) or U6.GetPlayerController():GetCurPawn().PetComponent_BP:GetMiniTVPawn():PetHasState(U8.PetPlayingFeature)) then
              return
            end
            if U1(53, 68, 165, 143, 73, 8, 46, 87, 37, 235, 196, 143, 242, 94, 127, 73, 151, 65, 144, 162, 143, 96, 88, 97, 35, 178, 214, 184, 235, 70, 127).MasterSkillID ~= nil and 0 < U1(53, 68, 165, 143, 73, 8, 46, 87, 37, 235, 196, 143, 242, 94, 127, 73, 151, 65, 144, 162, 143, 96, 88, 97, 35, 178, 214, 184, 235, 70, 127).MasterSkillID then
              if slua.isValid((U6.GetPlayerController():GetCurPawn())) and slua.isValid((U6.GetPlayerController():GetCurPawn():GetSkillManager())) and U6.GetPlayerController():GetCurPawn():GetSkillManager():GetSkill(U1(53, 68, 165, 143, 73, 8, 46, 87, 37, 235, 196, 143, 242, 94, 127, 73, 151, 65, 144, 162, 143, 96, 88, 97, 35, 178, 214, 184, 235, 70, 127).MasterSkillID) and not U6.GetPlayerController():GetCurPawn():GetSkillManager():GetSkill(U1(53, 68, 165, 143, 73, 8, 46, 87, 37, 235, 196, 143, 242, 94, 127, 73, 151, 65, 144, 162, 143, 96, 88, 97, 35, 178, 214, 184, 235, 70, 127).MasterSkillID):IsCDOK(U6.GetPlayerController():GetCurPawn():GetSkillManager(), -1) then
                return
              end
            end
            if slua.isValid(U6.GetPlayerController():GetCurPawn().GetPlayerStateSafety and U6.GetPlayerController():GetCurPawn():GetPlayerStateSafety()) and (U6.GetPlayerController():GetCurPawn().GetPlayerStateSafety and U6.GetPlayerController():GetCurPawn():GetPlayerStateSafety()).RPC_ServerAddGeneralCount then
            else
            end
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RequirPaint"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == -1 then
      elseif not _ARG_0_:CanPaintDecal(_ARG_1_) then
        return
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleChangeCurrentUsingWeapon"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshCheckGunBtnState()
      if _ARG_0_.CurrentShowState == Expression then
        U1.print(U1.bWriteLog and U1.table.concat({
          U2(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 103, 122, 66, 145, 88, 197, 152, 132, 49, 72, 121),
          U2(112, 87, 181, 137, 126, 21, 40, 74, 18, 241, 217, 167, 240, 104, 110, 93, 149, 75, 222, 235, 174, 37, 80, 124, 50, 225, 200, 249, 194, 87, 107, 94, 144, 71, 211, 178, 131, 62)
        }))
        _ARG_0_:AddGameTimer(0.6, false, function()
          _ENV:RefreshExpression()
          return
        end)
      elseif _ARG_0_.CurrentShowState == IslandExpression then
        _ARG_0_:AddGameTimer(0.6, false, function()
          _ENV:RefreshIslandExpression()
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshItemEmoteInfo"] = function(_ARG_0_, _ARG_1_)
    do
      goto lbl_73
      ::lbl_73::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshGridPanel"] = function(_ARG_0_)
    do
      if not (_ARG_0_:HasEquipHolography() and (_ARG_0_:IsSocialIsland() or _ARG_0_:IsTypicalGameMode() and not _ARG_0_.HasEnterBattle or _ARG_0_:IsMainCity())) then
        if _ARG_0_.CurrentShowState == U3.Holography then
          _ARG_0_.CurrentShowState = U3.Expression
        end
        if _ARG_0_.LastMoreState == U3.Holography then
          _ARG_0_.LastMoreState = U3.Decal
        end
      end
      if _ARG_0_.CurrentShowState == U3.IslandExpression or _ARG_0_.CurrentShowState == U3.Expression or _ARG_0_.CurrentShowState == U3.PetExpression or _ARG_0_.CurrentShowState == U3.SpectatorPetBubble or _ARG_0_.CurrentShowState == U3.MiniTvExpression then
      elseif _ARG_0_.CurrentShowState == U3.Collection or _ARG_0_.CurrentShowState == U3.Flaunt then
      else
      end
      if U1.require((U1.table.concat({
        U2(118, 120, 169, 158, 98, 4, 104, 77, 43, 247, 209, 231, 244, 80, 101, 90, 140, 67, 158, 136, 144, 41, 83, 96, 35, 223, 193, 186, 245, 64, 104, 2, 165, 65, 194, 183, 133, 35, 78, 76),
        U2(112, 115, 169, 148, 98, 61, 39, 93, 53, 237, 195)
      }))).IsBlueholeOperationRegion() then
      else
      end
      if U1.slua.isValid((GetPlayerController())) and GetPlayerController().IsInPetSpectator and GetPlayerController():IsInPetSpectator() then
        if _ARG_0_.CurrentShowState ~= U3.SpectatorPetBubble then
          _ARG_0_.CurrentShowState = U3.PetExpression
        end
        if _ARG_0_:CanShowPetBubblePanel() then
        else
        end
      else
        if _ARG_0_.bShowBottom then
        else
        end
        if _ARG_0_:HasEquipHolography() and (_ARG_0_:IsSocialIsland() or _ARG_0_:IsTypicalGameMode() and not _ARG_0_.HasEnterBattle or _ARG_0_:IsMainCity()) then
        else
        end
        if not _ARG_0_:IsSocialIsland() then
        else
        end
        if _ARG_0_.bShowDecal then
        else
        end
      end
      if _ARG_0_.bShowMiniTvExpressionTab then
      else
      end
      if U1.slua.isValid((GetPlayerCharacter())) then
        if _ARG_0_.CurrentShowState == U3.Decal then
        else
        end
      end
      if _ARG_0_.CurrentShowState == U3.None then
      elseif _ARG_0_.CurrentShowState == U3.Holography then
        _ARG_0_.LastMoreState = _ARG_0_.CurrentShowState
      elseif _ARG_0_.CurrentShowState == U3.Decal then
        _ARG_0_.LastMoreState = _ARG_0_.CurrentShowState
      elseif _ARG_0_.CurrentShowState == U3.Expression then
        _ARG_0_.LastEmoteState = _ARG_0_.CurrentShowState
      elseif _ARG_0_.CurrentShowState == U3.Bubble then
        _ARG_0_.LastMoreState = _ARG_0_.CurrentShowState
      elseif _ARG_0_.CurrentShowState == U3.IslandExpression then
        _ARG_0_.LastEmoteState = _ARG_0_.CurrentShowState
      elseif _ARG_0_.CurrentShowState == U3.PetExpression then
        _ARG_0_.LastEmoteState = _ARG_0_.CurrentShowState
      elseif _ARG_0_.CurrentShowState == U3.Collection then
      elseif _ARG_0_.CurrentShowState == U3.Flaunt then
      elseif _ARG_0_.CurrentShowState == U3.PetBubble then
        _ARG_0_.LastMoreState = _ARG_0_.CurrentShowState
      elseif _ARG_0_.CurrentShowState == U3.SpectatorPetBubble then
        _ARG_0_.LastMoreState = _ARG_0_.CurrentShowState
      elseif _ARG_0_.CurrentShowState == U3.MiniTvExpression then
        _ARG_0_.LastShowState = _ARG_0_.CurrentShowState
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshHolography"] = function(_ARG_0_)
    do
      if _ARG_0_:GetEquipHolography() then
        goto lbl_99
        if _ARG_0_:GetQuickExpressionDecalItemByIndex((_ARG_0_:GetEquipHolography() and _ARG_0_:GetEquipHolography():Num()) + 1) then
        end
        ::lbl_99::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDecalItems"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return nil
      end
      if not U1.slua.isValid((U3.GetBackpackComponentFromController((GetPlayerController())))) then
        return nil
      end
      goto lbl_189
      ::lbl_189::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {
        [U2(120, 103, 224, 185, 109, 19, 45, 110, 38, 225, 219, 138, 248, 82, 123, 28, 140, 87, 144, 165, 149, 44) + 1] = U2(120, 103, 224, 185, 109, 19, 45, 110, 38, 225, 219, 138, 248, 82, 123, 28, 140, 87, 144, 165, 149, 44)
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshDecalItems"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 125, 126, 74, 135, 81, 211, 179, 168, 53, 69, 127),
        U1(121, 93, 180, 158, 97, 3)
      }))
      if not _ARG_0_:GetDecalItems() then
        return
      end
      goto lbl_236
      if U1(121, 93, 180, 158, 97, 3, 106, 30) and _ARG_0_:GetQuickExpressionDecalItemByIndex((U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 125, 126, 74, 135, 81, 211, 179, 168, 53, 69, 127))) then
      end
      ::lbl_236::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetExpressionItems"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 94, 120, 89, 168, 75, 212, 229, 191, 44, 95, 107, 57, 230, 142, 156, 234, 64, 111, 73, 219, 101, 213, 178, 143, 59, 99, 102),
        U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228)
      }))).GetPHomeSameAsMainCityExpressionList() then
        return (require((table.concat({
          U1(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 94, 120, 89, 168, 75, 212, 229, 191, 44, 95, 107, 57, 230, 142, 156, 234, 64, 111, 73, 219, 101, 213, 178, 143, 59, 99, 102),
          U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228)
        }))).GetPHomeSameAsMainCityExpressionList())
      end
      do return require((table.concat({
        U1(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 94, 120, 89, 168, 75, 212, 229, 191, 44, 95, 107, 57, 230, 142, 156, 234, 64, 111, 73, 219, 101, 213, 178, 143, 59, 99, 102),
        U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228)
      }))).GetShowExpressionList() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[217]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetParticleEmoteID"] = function(_ARG_0_, _ARG_1_)
    do
      if GetPlayerController().PlayEmoteFeature.EmoteLevelMap[_ARG_1_] and U1.CDataTable.GetTableData(U2(69, 117, 178, 143, 101, 19, 42, 91, 2, 239, 223, 189, 242, 124, 109, 91), _ARG_1_) and GetPlayerController().PlayEmoteFeature.EmoteLevelMap[_ARG_1_] >= U1.CDataTable.GetTableData(U2(69, 117, 178, 143, 101, 19, 42, 91, 2, 239, 223, 189, 242, 124, 109, 91), _ARG_1_).Level then
        return U1.CDataTable.GetTableData(U2(69, 117, 178, 143, 101, 19, 42, 91, 2, 239, 223, 189, 242, 124, 109, 91), _ARG_1_).EmoteIDLevel2
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshExpression"] = function(_ARG_0_)
    do
      if not _ARG_0_:GetExpressionItems() then
        return
      end
      _ARG_0_.WeaponShowEmoteID, _ARG_0_.ClothBackpackItem = require((table.concat({
        U1(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 94, 120, 89, 168, 75, 212, 229, 191, 44, 95, 107, 57, 230, 142, 156, 234, 64, 111, 73, 219, 101, 213, 178, 143, 59, 99, 102),
        U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228)
      }))).GetWeaponShowEmoteID(), require((table.concat({
        U1(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 94, 120, 89, 168, 75, 212, 229, 191, 44, 95, 107, 57, 230, 142, 156, 234, 64, 111, 73, 219, 101, 213, 178, 143, 59, 99, 102),
        U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228)
      }))).GetClothBackpackItem()
      goto lbl_693
      if U3[U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228).DefineID.TypeSpecificID] then
      else
        if _ARG_0_:GetParticleEmoteID(U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228).DefineID.TypeSpecificID) then
          if U2.GetPlayerController().PlayEmoteFeature.ClientCacheShowEmoteEffect then
          else
          end
        end
        if CDataTable.GetTableData(U1(80, 121, 175, 143, 101, 31, 40, 114, 46, 239, 217, 189, 212, 89, 108), (_ARG_0_:GetParticleEmoteID(U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228).DefineID.TypeSpecificID))) and CDataTable.GetTableData(U1(80, 121, 175, 143, 101, 31, 40, 114, 46, 239, 217, 189, 212, 89, 108), (_ARG_0_:GetParticleEmoteID(U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228).DefineID.TypeSpecificID))).EmotionID then
          _ARG_0_.AllLimitEmoteList[CDataTable.GetTableData(U1(80, 121, 175, 143, 101, 31, 40, 114, 46, 239, 217, 189, 212, 89, 108), (_ARG_0_:GetParticleEmoteID(U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228).DefineID.TypeSpecificID))).EmotionID] = true
        end
        if _ARG_0_:GetQuickExpressionDecalItemByIndex(U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228)) then
          if 1 == 1 then
          elseif 1 == 2 then
          else
          end
          if U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228).bWeaponShow then
          else
          end
          if _ARG_0_.AllLimitEmoteList[_ARG_0_:GetParticleEmoteID(U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228).DefineID.TypeSpecificID)] then
            if _ARG_0_:GetIsEmoteExist((_ARG_0_:GetParticleEmoteID(U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228).DefineID.TypeSpecificID))) then
              if not _ARG_0_:CheckIsWearingEmoteLimitCloth((_ARG_0_:GetParticleEmoteID(U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228).DefineID.TypeSpecificID))) or U4.CheckEmoteIsBan((_ARG_0_:GetParticleEmoteID(U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228).DefineID.TypeSpecificID))) then
              end
            end
          end
        end
      end
      ::lbl_693::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if 0 < 0 + 1 and true then
        if U2.GetPlayerController().PlayEmoteFeature.ClientCacheShowEmoteEffect then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshBubble"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 125, 126, 74, 135, 81, 211, 179, 174, 37, 68, 124),
        U1(121, 113)
      }))
      _ARG_0_:RefreshEmoteActionSys()
      if U2.GetSysByName((U1(92, 103, 172, 154, 98, 20, 4, 75, 37, 224, 220, 172, 210, 82, 100, 72, 128, 119, 201, 184))) ~= nil then
        _ARG_0_.uBubbleIDList = U2.GetSysByName((U1(92, 103, 172, 154, 98, 20, 4, 75, 37, 224, 220, 172, 210, 82, 100, 72, 128, 119, 201, 184))):GetBubbleIdList()
        goto lbl_167
        if _ARG_0_:GetQuickExpressionDecalItemByIndex((U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 125, 126, 74, 135, 81, 211, 179, 174, 37, 68, 124))) then
        end
        ::lbl_167::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshIslandExpression"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 125, 126, 74, 135, 81, 211, 179, 165, 35, 74, 127),
        U1(123, 112, 133, 131, 124, 2, 35, 77, 52, 235, 223, 167)
      }))
      if not slua.isValid((U2.GetPlayerController())) or not U2.GetPlayerController().PlayEmoteFeature then
        return
      end
      if U3.GetSysByName((U1(80, 121, 175, 143, 105, 49, 37, 74, 46, 237, 222, 154, 238, 76))) ~= nil then
        _ARG_0_.uEmoteIDList = U3.GetSysByName((U1(80, 121, 175, 143, 105, 49, 37, 74, 46, 237, 222, 154, 238, 76))):GetEmoteList()
        _ARG_0_.WeaponShowEmoteID = 0
        _ARG_0_.ClothEmoteID = 0
        if require((table.concat({
          U1(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 94, 120, 89, 168, 75, 212, 229, 191, 44, 95, 107, 57, 230, 142, 156, 234, 64, 111, 73, 219, 101, 213, 178, 143, 59, 99, 102),
          U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228)
        }))).GetCurrentWeaponShowEmoteState() == 0 or require((table.concat({
          U1(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 94, 120, 89, 168, 75, 212, 229, 191, 44, 95, 107, 57, 230, 142, 156, 234, 64, 111, 73, 219, 101, 213, 178, 143, 59, 99, 102),
          U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228)
        }))).GetCurrentWeaponShowEmoteState() == 1 then
          _ARG_0_.WeaponShowEmoteID = require((table.concat({
            U1(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 94, 120, 89, 168, 75, 212, 229, 191, 44, 95, 107, 57, 230, 142, 156, 234, 64, 111, 73, 219, 101, 213, 178, 143, 59, 99, 102),
            U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228)
          }))).GetCurrentWeaponShowEmoteState()
        end
        if require((table.concat({
          U1(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 94, 120, 89, 168, 75, 212, 229, 191, 44, 95, 107, 57, 230, 142, 156, 234, 64, 111, 73, 219, 101, 213, 178, 143, 59, 99, 102),
          U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228)
        }))).GetClothEmoteID() and 0 < require((table.concat({
          U1(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 94, 120, 89, 168, 75, 212, 229, 191, 44, 95, 107, 57, 230, 142, 156, 234, 64, 111, 73, 219, 101, 213, 178, 143, 59, 99, 102),
          U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228)
        }))).GetClothEmoteID() then
          _ARG_0_.ClothEmoteID = require((table.concat({
            U1(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 94, 120, 89, 168, 75, 212, 229, 191, 44, 95, 107, 57, 230, 142, 156, 234, 64, 111, 73, 219, 101, 213, 178, 143, 59, 99, 102),
            U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228)
          }))).GetClothEmoteID(), print(bWriteLog and table.concat({
            U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 125, 126, 74, 135, 81, 211, 179, 165, 35, 74, 127),
            U1(123, 112, 133, 131, 124, 2, 35, 77, 52, 235, 223, 167, 183, 87, 106, 79, 166, 72, 223, 191, 148, 5, 91, 97, 35, 247, 128, 144, 195, 21)
          }) .. tostring((require((table.concat({
            U1(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 94, 120, 89, 168, 75, 212, 229, 191, 44, 95, 107, 57, 230, 142, 156, 234, 64, 111, 73, 219, 101, 213, 178, 143, 59, 99, 102),
            U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228)
          }))).GetClothEmoteID())))
        end
        goto lbl_697
        if U4[U1(123, 112, 133, 131, 124, 2, 35, 77, 52, 235, 223, 167, 183, 87, 106, 79, 166, 72, 223, 191, 148, 5, 91, 97, 35, 247, 128, 144, 195, 21)] then
        else
          if U2.GetPlayerController().PlayEmoteFeature.EmoteLevelMap[U1(123, 112, 133, 131, 124, 2, 35, 77, 52, 235, 223, 167, 183, 87, 106, 79, 166, 72, 223, 191, 148, 5, 91, 97, 35, 247, 128, 144, 195, 21)] and CDataTable.GetTableData(U1(69, 117, 178, 143, 101, 19, 42, 91, 2, 239, 223, 189, 242, 124, 109, 91), U1(123, 112, 133, 131, 124, 2, 35, 77, 52, 235, 223, 167, 183, 87, 106, 79, 166, 72, 223, 191, 148, 5, 91, 97, 35, 247, 128, 144, 195, 21)) and U2.GetPlayerController().PlayEmoteFeature.EmoteLevelMap[U1(123, 112, 133, 131, 124, 2, 35, 77, 52, 235, 223, 167, 183, 87, 106, 79, 166, 72, 223, 191, 148, 5, 91, 97, 35, 247, 128, 144, 195, 21)] >= CDataTable.GetTableData(U1(69, 117, 178, 143, 101, 19, 42, 91, 2, 239, 223, 189, 242, 124, 109, 91), U1(123, 112, 133, 131, 124, 2, 35, 77, 52, 235, 223, 167, 183, 87, 106, 79, 166, 72, 223, 191, 148, 5, 91, 97, 35, 247, 128, 144, 195, 21)).Level then
            if U2.GetPlayerController().PlayEmoteFeature.ClientCacheShowEmoteEffect and CDataTable.GetTableData(U1(69, 117, 178, 143, 101, 19, 42, 91, 2, 239, 223, 189, 242, 124, 109, 91), U1(123, 112, 133, 131, 124, 2, 35, 77, 52, 235, 223, 167, 183, 87, 106, 79, 166, 72, 223, 191, 148, 5, 91, 97, 35, 247, 128, 144, 195, 21)).EmoteIDLevel2 then
            else
            end
          end
          if _ARG_0_:GetQuickExpressionDecalItemByIndex((require((table.concat({
            U1(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 94, 120, 89, 168, 75, 212, 229, 191, 44, 95, 107, 57, 230, 142, 156, 234, 64, 111, 73, 219, 101, 213, 178, 143, 59, 99, 102),
            U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228)
          }))).GetClothEmoteID())) then
            if 1 == 1 then
            elseif 1 == 2 then
            else
            end
            if require((table.concat({
              U1(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 94, 120, 89, 168, 75, 212, 229, 191, 44, 95, 107, 57, 230, 142, 156, 234, 64, 111, 73, 219, 101, 213, 178, 143, 59, 99, 102),
              U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228)
            }))).GetClothEmoteID() == 1 and _ARG_0_.WeaponShowEmoteID ~= 0 then
            else
            end
          end
        end
        ::lbl_697::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if 0 < 0 + 1 and true then
          if U2.GetPlayerController().PlayEmoteFeature.ClientCacheShowEmoteEffect then
          else
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPetExpression"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshPetInfo()
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 125, 126, 74, 135, 81, 211, 179, 188, 53, 82, 91),
        U1(109, 100, 178, 158, 127, 3, 47, 81, 41, 174, 144)
      }) .. tostring(_ARG_0_.PetID) .. U1(57, 52) .. tostring(_ARG_0_.PetLevel) .. U1(57, 52) .. tostring(_ARG_0_.bShowMyPet))
      if not _ARG_0_.PetID or _ARG_0_.PetID <= 0 or not _ARG_0_.bShowMyPet then
        _ARG_0_:HideRestBlocks(0)
        return
      end
      goto lbl_125
      if _ARG_0_:GetQuickExpressionDecalItemByIndex((tostring(_ARG_0_.PetLevel))) then
      end
      ::lbl_125::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshCollection"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshCollectionList()
      if #_ARG_0_.CollectionList == 0 then
        _ARG_0_:HideRestBlocks(0)
        return
      end
      goto lbl_36
      if _ARG_0_:GetQuickExpressionDecalItemByIndex(nil) then
      end
      ::lbl_36::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshFlaunt"] = function(_ARG_0_)
    do
      goto lbl_28
      if _ARG_0_:GetQuickExpressionDecalItemByIndex(nil) then
      end
      ::lbl_28::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_104
      ::lbl_104::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCardCollectionShowInfoRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if tonumber(_ARG_3_) ~= tonumber(DataMgr.roleData.uid) then
        log(bWriteLog and string.format(table.concat({
          U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 111, 148, 70, 196, 152, 131, 60, 74, 123),
          U1(118, 96, 169, 148, 98, 35, 46, 81, 48, 203, 222, 175, 248, 109, 120, 76, 197, 87, 219, 162, 140, 108, 22, 123, 62, 246, 157, 252, 244, 15, 117, 67, 129, 20, 211, 190, 128, 54)
        }), tostring(_ARG_3_)))
        return
      end
      if _ARG_0_.CurrentShowState ~= U2.Flaunt then
        log(bWriteLog and string.format(table.concat({
          U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 111, 148, 70, 196, 152, 131, 60, 74, 123),
          U1(118, 96, 169, 148, 98, 35, 46, 81, 48, 203, 222, 175, 248, 109, 120, 76, 197, 87, 219, 162, 140, 108, 22, 77, 34, 224, 210, 188, 233, 91, 72, 68, 154, 67, 243, 175, 141, 36, 67, 35),
          U1(48, 103)
        }), tostring(_ARG_0_.CurrentShowState)))
        return
      end
      log(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 111, 148, 70, 196, 152, 131, 60, 74, 123),
        U1(118, 96, 169, 148, 98, 35, 46, 81, 48, 203, 222, 175, 248, 109, 120, 76, 197, 86, 213, 173, 142, 37, 69, 102, 119, 244, 204, 184, 242, 65, 111)
      }))
      _ARG_0_:RefreshFlaunt()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshEmoteActionSys"] = function(_ARG_0_)
    do
      if GetSysByName((U1(80, 121, 175, 143, 105, 49, 37, 74, 46, 237, 222, 154, 238, 76))) ~= nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetQuickExpressionDecalItemByIndex"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 104, 126, 88, 164, 65, 201, 184, 135, 21, 94, 110),
        U1(103, 113, 179, 136, 101, 31, 40, 122, 34, 225, 209, 165, 222, 75, 110, 81, 167, 93, 249, 165, 152, 37, 78, 46, 30, 252, 196, 188, 255, 21)
      }), _ARG_1_)
      while _ARG_1_ > #_ARG_0_.QuickExpressionDecalItemList do
      end
      do return _ARG_0_.QuickExpressionDecalItemList[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideRestBlocks"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_ or not _ARG_0_.UIRoot then
        return
      end
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 103, 114, 72, 144, 102, 197, 168, 152, 18, 74, 113),
        U1(118, 127, 179)
      }) .. _ARG_1_)
      _ARG_0_.UIRoot.ScrollBox_0.SizeY = 200
      if _ARG_1_ <= 0 then
        if _ARG_0_.CurrentShowState == U2.Expression or _ARG_0_.CurrentShowState == U2.IslandExpression then
        elseif _ARG_0_.CurrentShowState == U2.Bubble then
        elseif _ARG_0_.CurrentShowState == U2.Decal then
        elseif _ARG_0_.CurrentShowState == U2.Holography then
        elseif _ARG_0_.CurrentShowState == U2.PetExpression then
          if not _ARG_0_.PetID or 0 >= _ARG_0_.PetID then
            if _ARG_0_:IsPlanPHMode() then
            elseif _ARG_0_:IsCollectionMode() then
            else
            end
          elseif not _ARG_0_.bShowMyPet then
          end
        elseif _ARG_0_.CurrentShowState == U2.Collection then
        elseif _ARG_0_.CurrentShowState == U2.PetBubble then
        elseif _ARG_0_.CurrentShowState == U2.SpectatorPetBubble then
        elseif _ARG_0_.CurrentShowState == U2.MiniTvExpression then
          if _ARG_0_.bShowMiniTv then
          else
          end
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryToThrowHolography"] = function(_ARG_0_, _ARG_1_)
    do
      if U1.slua.isValid((GetPlayerController())) and GetPlayerController().GetPlayerCharacterSafety then
        if U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) then
          if U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety():GetSkillManager())) then
          else
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryToPlayEmote"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return
      end
      if _ARG_1_ == _ARG_0_.WeaponShowEmoteID then
        return
      end
      if GameStatus.IsPHomeMode(true) and slua.isValid((U2.GetPlayerCharacter())) and U2.GetPlayerCharacter().CharacterMovement and U2.GetPlayerCharacter().CharacterMovement:IsFlying() then
        return
      end
      if not _ARG_0_:GetIsEmoteExist(_ARG_1_) then
        return
      end
      if CDataTable.GetTableData(U1(86, 120, 175, 143, 100, 21, 53, 12, 2, 239, 223, 189, 242, 124, 109, 91), _ARG_1_) and slua.isValid((U2.GetPlayerCharacter())) then
        goto lbl_252
        if U2.GetPlayerCharacter().CharacterAvatarComp2_BP:IsItemHasEquipped(12) then
          goto lbl_254
        else
        end
        ::lbl_252::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_254::
      if false then
        return
      end
      if not U4.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot) or not slua.isValid((U4.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot))) then
        return
      end
      if U5.CheckEmoteIsBan(_ARG_1_) and U2.GetPlayerController() and U2.GetPlayerController().DisplayGameTipWithMsgID then
        return
      end
      _ARG_0_.ClothBackpackItem = require((table.concat({
        U1(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 94, 120, 89, 168, 75, 212, 229, 191, 44, 95, 107, 57, 230, 142, 156, 234, 64, 111, 73, 219, 101, 213, 178, 143, 59, 99, 102),
        U1(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228)
      }))).GetClothBackpackItem()
      if not _ARG_0_.AllLimitEmoteList[_ARG_1_] or _ARG_0_.AllLimitEmoteList[_ARG_1_] and _ARG_0_:CheckIsWearingEmoteLimitCloth(_ARG_1_) then
      elseif U2.GetPlayerController() and U2.GetPlayerController().DisplayGameTipWithMsgID then
        return
      end
      if false then
      elseif _ARG_0_:CheckIsWearingEmoteLimitCloth(_ARG_1_) and _ARG_0_:CheckIsWearingEmoteLimitCloth(_ARG_1_) > 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryPlayWeaponShowEmote"] = function(_ARG_0_)
    do
      if not GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot) or not U1.slua.isValid((GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot))) then
        return
      end
      if U1.require((U1.table.concat({
        U2(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 94, 120, 89, 168, 75, 212, 229, 191, 44, 95, 107, 57, 230, 142, 156, 234, 64, 111, 73, 219, 101, 213, 178, 143, 59, 99, 102),
        U2(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228)
      }))).GetCurrentWeaponShowEmoteState() ~= 0 then
        if GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot):GetPlayerControllerSafety() and U1.slua.isValid((GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot):GetPlayerControllerSafety())) and GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot):GetPlayerControllerSafety().DisplayGameTipWithMsgID and U1.require((U1.table.concat({
          U2(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 94, 120, 89, 168, 75, 212, 229, 191, 44, 95, 107, 57, 230, 142, 156, 234, 64, 111, 73, 219, 101, 213, 178, 143, 59, 99, 102),
          U2(101, 102, 165, 136, 127, 25, 41, 80, 18, 246, 217, 165, 228)
        }))).GetCurrentWeaponShowEmoteState() == 1 then
        else
        end
        return
      end
      if U1.Game:IsValid((GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot):GetSkillManager())) and GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot):GetSkillManager():IsCastingSkillID(1014433) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayEmoteInternal"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if (not GetPlayerCharacter() or not U1.slua.isValid((GetPlayerCharacter()))) and (not U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot) or not U1.slua.isValid((U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot)))) then
        return
      end
      if U1.require((U1.table.concat({
        U3(82, 117, 173, 158, 64, 5, 39, 16, 6, 225, 196, 160, 225, 86, 127, 69, 203, 103, 223, 166, 145, 37, 68, 109, 62, 243, 204, 176, 253, 74, 53, 107, 148, 89, 197, 139, 128, 49, 95, 48),
        U3(86, 123, 175, 139, 73, 29, 41, 74, 34, 172, 243, 166, 248, 79, 78, 81, 138, 80, 213, 158, 136, 41, 90)
      }))).IsCoopEmote(_ARG_1_) then
        if U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot).CoopEmoteCharFeature and U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot).CoopEmoteCharFeature:IsInCoopEmote() then
          return
        end
        if U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot).GetPlayEmoteComponent and U1.slua.isValid((U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot):GetPlayEmoteComponent())) then
          U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot):GetPlayEmoteComponent().CoopEmoteTargetOffset = U1.require((U1.table.concat({
            U3(82, 117, 173, 158, 64, 5, 39, 16, 6, 225, 196, 160, 225, 86, 127, 69, 203, 103, 223, 166, 145, 37, 68, 109, 62, 243, 204, 176, 253, 74, 53, 107, 148, 89, 197, 139, 128, 49, 95, 48),
            U3(86, 123, 175, 139, 73, 29, 41, 74, 34, 172, 243, 166, 248, 79, 78, 81, 138, 80, 213, 158, 136, 41, 90)
          }))).GetCoopEmoteTarget(_ARG_1_)
        end
        if U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot).CheckCanBeginPlayCoopEmote and not U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot):CheckCanBeginPlayCoopEmote() then
          return
        end
        goto lbl_533
        if not U1.import((U3(64, 81, 144, 154, 120, 24, 19, 74, 46, 238, 217, 189, 238, 114, 110, 72, 141, 75, 212, 184))).IsAvatarResPathExist((U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot):GetEmoteHandlePath(U1.require((U1.table.concat({
          U3(82, 117, 173, 158, 64, 5, 39, 16, 6, 225, 196, 160, 225, 86, 127, 69, 203, 103, 223, 166, 145, 37, 68, 109, 62, 243, 204, 176, 253, 74, 53, 107, 148, 89, 197, 139, 128, 49, 95, 48),
          U3(86, 123, 175, 139, 73, 29, 41, 74, 34, 172, 243, 166, 248, 79, 78, 81, 138, 80, 213, 158, 136, 41, 90)
        }))).GetAllRelateEmote(_ARG_1_)))) then
          return
        end
        ::lbl_533::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if U1.SubsystemMgr:Get((U3(80, 121, 175, 143, 105, 35, 51, 92, 20, 251, 195, 189, 242, 82))) and U1.SubsystemMgr:Get((U3(80, 121, 175, 143, 105, 35, 51, 92, 20, 251, 195, 189, 242, 82))):TryPlayMovableEmote(_ARG_1_, (U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot))) then
        return true
      end
      if U1.require((U1.table.concat({
        U3(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 219, 86, 105, 78, 132, 86, 201, 229, 187, 33, 91, 107, 7, 254, 193, 160, 169, 110, 109, 77, 129, 85, 210, 245, 169, 61, 73, 106),
        U3(112, 58, 172, 148, 107, 25, 37, 97, 34, 239, 223, 189, 242)
      }))).PlayEmote(U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot), _ARG_1_) then
        if _ARG_2_ then
          if U1.slua.isValid((U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot):GetPlayerStateSafety())) and U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot):GetPlayerStateSafety().RPC_ServerAddGeneralCount then
          end
        else
        end
        return true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsWearingEmoteLimitCloth"] = function(_ARG_0_, _ARG_1_)
    do
      if CDataTable.GetTableData(U1(80, 121, 175, 143, 101, 31, 40, 114, 46, 239, 217, 189, 212, 89, 108), _ARG_1_) then
        if CDataTable.GetTableData(U1(80, 121, 175, 143, 101, 31, 40, 114, 46, 239, 217, 189, 212, 89, 108), _ARG_1_).IsShow then
          goto lbl_40
          if not _ARG_0_.ClothBackpackItem[40] then
          end
          ::lbl_40::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          return false, CDataTable.GetTableData(U1(80, 121, 175, 143, 101, 31, 40, 114, 46, 239, 217, 189, 212, 89, 108), _ARG_1_).TipsID
        else
          goto lbl_56
          if _ARG_0_.ClothBackpackItem[31] then
            return true
          end
          ::lbl_56::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      do return false, CDataTable.GetTableData(U1(80, 121, 175, 143, 101, 31, 40, 114, 46, 239, 217, 189, 212, 89, 108), _ARG_1_).TipsID end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIsEmoteExist"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetIsItemHandleExist(22, _ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIsItemHandleExist"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.ItemDefineIDTemp.Type = _ARG_1_
      _ARG_0_.ItemDefineIDTemp.TypeSpecificID = _ARG_2_
      do return U1.IsBattleItemHandleExist(_ARG_0_.ItemDefineIDTemp, not GameStatus.InSupportDownloadState(), false, false) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSocialIsland"] = function(_ARG_0_)
    do
      if U1.slua.isValid((GetGameState())) and GetGameState().IsNonePlayerOnIsland then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsMainCity"] = function(_ARG_0_)
    do
      do return GameStatus.IsInMainCity() end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPlanPHMode"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 102, 104, 124, 153, 85, 206, 139, 164, 29, 73, 122),
        U1(112)
      }))
      if tostring((Client.GetGameModeID(GameFrontendHUD))) == tostring(require((U1(118, 120, 169, 158, 98, 4, 104, 77, 43, 247, 209, 231, 251, 80, 108, 85, 134, 10, 216, 164, 145, 37, 24, 102, 56, 255, 197, 134, 234, 78, 120, 94, 154, 71))).Home_SubMode.Visit) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCollectionMode"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 102, 104, 111, 154, 88, 204, 190, 143, 36, 79, 113),
        U1(123, 89, 175, 159, 105)
      }))
      do return GameStatus.IsCollectionHallMode() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBornisland"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetGameState())) or not GetGameState().GetGameModeState then
        return false
      end
      do return GetGameState():GetGameModeState() == U2(71, 113, 161, 159, 117, 35, 50, 95, 51, 231) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HasEquipHolography"] = function(_ARG_0_)
    do
      do return _ARG_0_:GetEquipHolography() and _ARG_0_:GetEquipHolography():Num() > 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetEquipHolography"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) or not GetPlayerController().CommerFeature then
        return nil
      end
      if not GetPlayerController().CommerFeature.HolographyList then
        return nil
      end
      do return GetPlayerController().CommerFeature.HolographyList end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsTypicalGameMode"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetGameState())) then
        return false
      end
      if GetGameState().GameModeType == U3.ETypicalGameMode or GetGameState().GameModeType == U3.EFourInOneGameMode then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEnterBattle"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 15, 84, 66, 176, 90, 212, 190, 158, 18, 71, 106),
        U1(97, 120, 165)
      }))
      _ARG_0_.HasEnterBattle = true
      _ARG_0_.UIRoot.WidgetSwitcher_Hologram:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      if _ARG_0_.LastCloseShowState == U2.Holography then
        _ARG_0_.LastCloseShowState = U2.None
      end
      if _ARG_0_.LastMoreState == U2.Holography then
        _ARG_0_.LastMoreState = U2.Decal
      end
      _ARG_0_:CloseContent()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInInteractiveState"] = function(_ARG_0_)
    do
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanPaintDecal"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:CheckPHomeCanPaintDecal(_ARG_1_) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckPHomeCanPaintDecal"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 108, 115, 73, 150, 95, 240, 147, 131, 61, 67, 93),
        U1(116, 122, 144, 154, 101, 30, 50, 122, 34, 225, 209, 165, 183, 118, 79, 6)
      }) .. tostring(_ARG_1_))
      if GameStatus.IsInFightingStatus() then
        if GameStatus.IsSocialIslandMode() then
          if U2.GetSysByName((U1(69, 92, 175, 150, 105, 51, 42, 87, 34, 236, 196, 154, 238, 76))) and U2.GetSysByName((U1(69, 92, 175, 150, 105, 51, 42, 87, 34, 236, 196, 154, 238, 76))):IsMyselfInStoreBuilding() then
          end
        end
        if GameStatus.IsPHomeMode(true) then
          if not U3[_ARG_1_] then
          end
        end
        if GameStatus.IsCollectionHallMode(true) then
        end
        if true or true or GameStatus.IsCollectionHallMode(true) then
          return false
        end
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FeatureButtonRefresh"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshCheckGunBtnState()
      _ARG_0_:RefreshChangeAvatarFormBtnState(true)
      _ARG_0_:RefreshTransformButton()
      _ARG_0_:RefreshPetButton()
      _ARG_0_:RefreshXSuitEmoteButton()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshCheckGunBtnState"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 219, 86, 105, 78, 132, 86, 201, 229, 187, 33, 91, 107, 7, 254, 193, 160, 169, 110, 109, 77, 129, 85, 210, 245, 169, 61, 73, 106),
        U1(112, 58, 172, 148, 107, 25, 37, 97, 34, 239, 223, 189, 242)
      }))).bCustomWeaponShow then
      else
      end
      if _ARG_0_.HalfAlpha_LColor == nil then
        _ARG_0_.HalfAlpha_LColor = FLinearColor(1.0, 1.0, 1.0, 0.5)
        _ARG_0_.HalfAlpha_SColor = FSlateColor(FLinearColor(1.0, 1.0, 1.0, 0.5))
        _ARG_0_.FullAlpha_LColor = FLinearColor(1.0, 1.0, 1.0, 1.0)
        _ARG_0_.FullAlpha_SColor = FSlateColor(FLinearColor(1.0, 1.0, 1.0, 1.0))
      end
      if U2.GetCurrentCheckGunState(_ARG_0_.UIRoot) == -1 or U2.GetCurrentCheckGunState(_ARG_0_.UIRoot) == 2 or U2.GetCurrentCheckGunState(_ARG_0_.UIRoot) == 3 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshChangeAvatarFormBtnState"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 125, 126, 74, 135, 81, 211, 179, 175, 56, 71, 112),
        U1(114, 113, 129, 141, 109, 4, 39, 76, 1, 237, 194, 164, 213, 75, 101, 111, 145, 69, 196, 174, 208, 96)
      }) .. tostring(_ARG_1_))
      if _ARG_0_.ChangeAvatarFormCDTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.ChangeAvatarFormCDTimer)
        _ARG_0_.ChangeAvatarFormCDTimer = nil
      end
      _ARG_0_.XSuitTailButtonIcon = nil
      if not _ARG_1_ then
        _ARG_0_.bXSuitTailButton = false
        U2.RefreshXSuitTailRedPoint(_ARG_0_.UIRoot, false)
        return
      end
      _ARG_0_.bXSuitTailButton = U2.GetXSuitTailButtonState().bAvailable == true
      if _ARG_0_.bXSuitTailButton then
        _ARG_0_.XSuitTailButtonIcon = U2.ApplyXSuitTailButtonState(_ARG_0_.UIRoot, (U2.GetXSuitTailButtonState()))
        _ARG_0_.ChangeAvatarFormCDTimer = _ARG_0_:AddTimerLoop(0, function()
          _ENV:TickChangeAvatarFormCD()
          return
        end, TIMER_INFINITE, 0.2)
        return
      end
      if not U3.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot) or not slua.isValid((U3.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot))) then
        return
      end
      if U2.GetAvatarFormState((U3.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot))) == 0 then
        return
      end
      if not U2.GetAvatarFormIcon((U3.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot))) then
        return
      end
      _ARG_0_.ChangeAvatarFormCDTimer = _ARG_0_:AddTimerLoop(0, function()
        _ENV:TickChangeAvatarFormCD()
        return
      end, TIMER_INFINITE, 0.2)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshTransformButton"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 125, 126, 74, 135, 81, 211, 179, 184, 34, 71, 112),
        U1(102, 114, 175, 137, 97, 50, 51, 74, 51, 237, 222)
      }))
      if _ARG_0_.ChangeDragonFormCDTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.ChangeDragonFormCDTimer)
        _ARG_0_.ChangeDragonFormCDTimer = nil
      end
      if not U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot) or not slua.isValid((U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot))) then
        return
      end
      if SubsystemMgr:Get((U1(84, 98, 161, 143, 109, 2, 5, 86, 38, 236, 215, 172, 209, 80, 121, 81, 182, 81, 210, 184, 133, 51, 66, 107, 58))) then
        if SubsystemMgr:Get((U1(84, 98, 161, 143, 109, 2, 5, 86, 38, 236, 215, 172, 209, 80, 121, 81, 182, 81, 210, 184, 133, 51, 66, 107, 58))):CheckChangeFormCondition((U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot))) then
          if CDataTable.GetTableData(U1(86, 120, 175, 143, 100, 25, 40, 89, 20, 246, 209, 189, 242, 124, 100, 82, 131, 77, 215), SubsystemMgr:Get((U1(84, 98, 161, 143, 109, 2, 5, 86, 38, 236, 215, 172, 209, 80, 121, 81, 182, 81, 210, 184, 133, 51, 66, 107, 58))):CheckChangeFormCondition((U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot))).AfterClothID) and CDataTable.GetTableData(U1(86, 120, 175, 143, 100, 25, 40, 89, 20, 246, 209, 189, 242, 124, 100, 82, 131, 77, 215), SubsystemMgr:Get((U1(84, 98, 161, 143, 109, 2, 5, 86, 38, 236, 215, 172, 209, 80, 121, 81, 182, 81, 210, 184, 133, 51, 66, 107, 58))):CheckChangeFormCondition((U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot))).AfterClothID).BattleIcon then
            if not require((U1(118, 120, 169, 158, 98, 4, 104, 93, 40, 239, 221, 166, 249, 17, 123, 93, 142, 123, 197, 191, 149, 44))).IsTextureDownloadedByPath(CDataTable.GetTableData(U1(86, 120, 175, 143, 100, 25, 40, 89, 20, 246, 209, 189, 242, 124, 100, 82, 131, 77, 215), SubsystemMgr:Get((U1(84, 98, 161, 143, 109, 2, 5, 86, 38, 236, 215, 172, 209, 80, 121, 81, 182, 81, 210, 184, 133, 51, 66, 107, 58))):CheckChangeFormCondition((U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot))).AfterClothID) and CDataTable.GetTableData(U1(86, 120, 175, 143, 100, 25, 40, 89, 20, 246, 209, 189, 242, 124, 100, 82, 131, 77, 215), SubsystemMgr:Get((U1(84, 98, 161, 143, 109, 2, 5, 86, 38, 236, 215, 172, 209, 80, 121, 81, 182, 81, 210, 184, 133, 51, 66, 107, 58))):CheckChangeFormCondition((U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot))).AfterClothID).BattleIcon) then
            end
          elseif SubsystemMgr:Get((U1(84, 98, 161, 143, 109, 2, 5, 86, 38, 236, 215, 172, 209, 80, 121, 81, 182, 81, 210, 184, 133, 51, 66, 107, 58))):CheckChangeFormCondition((U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot))).ActionType == 0 then
          else
          end
          if GlobalData.IsJapanOrKorea() then
            if SubsystemMgr:Get((U1(84, 98, 161, 143, 109, 2, 5, 86, 38, 236, 215, 172, 209, 80, 121, 81, 182, 81, 210, 184, 133, 51, 66, 107, 58))):GetUnlockState((U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot))) then
            else
            end
          else
          end
          _ARG_0_.ChangeDragonFormCDTimer = _ARG_0_:AddTimerLoop(0, function()
            _ENV:TickChangeDragonFormCD()
            return
          end, TIMER_INFINITE, 0.2)
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TickChangeDragonFormCD"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot))) then
        return
      end
      if not U1.slua.isValid(GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot).SkillManager) then
        return
      end
      if GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot).SkillManager:GetSkillBaseData(1014419).SkillCDs:Num() >= 1 then
      end
      if not U1.slua.isValid((GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot).SkillManager:GetSkillBaseData(1014419).SkillCDs:Get(0))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPetButton"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshXSuitEmoteButton"] = function(_ARG_0_)
    do
      if CanShowXSuitEmote(_ARG_0_.UIRoot, _ARG_0_) then
        if GetBornIslandAction(_ARG_0_.UIRoot) ~= 0 then
        end
      else
      end
      if _ARG_0_.CurrentShowState == U3.PetExpression then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TickChangeAvatarFormCD"] = function(_ARG_0_)
    do
      if _ARG_0_.bXSuitTailButton then
        if not GetXSuitTailButtonState().bAvailable then
          return
        end
        _ARG_0_.XSuitTailButtonIcon = ApplyXSuitTailButtonState(_ARG_0_.UIRoot, GetXSuitTailButtonState(), _ARG_0_.XSuitTailButtonIcon)
        return
      end
      if not U2.slua.isValid((U1.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot))) then
        return
      end
      if not U2.slua.isValid(U1.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot).SkillManager) then
        return
      end
      if U1.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot).SkillManager:GetSkillBaseData(1014419).SkillCDs:Num() >= 1 then
      end
      if not U2.slua.isValid((U1.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot).SkillManager:GetSkillBaseData(1014419).SkillCDs:Get(0))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonCheckGun"] = function(_ARG_0_)
    do
      _ARG_0_:CloseContent()
      TryDoCheckGun(_ARG_0_.UIRoot)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonChangeAvatarForm"] = function(_ARG_0_)
    do
      _ARG_0_:CloseContent()
      ChangeAvatarForm(_ARG_0_.UIRoot)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonTransfiguration"] = function(_ARG_0_)
    do
      _ARG_0_:CloseContent()
      if _ARG_0_.UIRoot.CanvasPanel_Guide2:GetVisibility() ~= UEnums.ESlateVisibility.Collapsed and SubsystemMgr:Get((U1(84, 98, 161, 143, 109, 2, 5, 86, 38, 236, 215, 172, 209, 80, 121, 81, 182, 81, 210, 184, 133, 51, 66, 107, 58))) then
      end
      if SubsystemMgr:Get((U1(84, 98, 161, 143, 109, 2, 5, 86, 38, 236, 215, 172, 209, 80, 121, 81, 182, 81, 210, 184, 133, 51, 66, 107, 58))) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonPetFeature"] = function(_ARG_0_)
    do
      _ARG_0_:CloseContent()
      OnButtonPetFeature(_ARG_0_.UIRoot)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonXSuitEmote"] = function(_ARG_0_)
    do
      _ARG_0_:CloseContent()
      OnButtonXSuitEmote(_ARG_0_.UIRoot, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPetInfo"] = function(_ARG_0_)
    do
      if U1.slua.isValid((GetPlayerController())) and GetPlayerController().IsInPetSpectator and GetPlayerController():IsInPetSpectator() then
      end
      if _ARG_0_.IsInPetSpectator ~= true then
        _ARG_0_.IsInPetSpectator = true
      end
      if _ARG_0_.PetID == _ARG_0_:GetCurPet() and _ARG_0_.PetLevel == _ARG_0_:GetCurPet() and _ARG_0_:GetShowMyPet() == _ARG_0_.bShowMyPet and not true then
        return
      end
      _ARG_0_.PetLevel, _ARG_0_.PetID = _ARG_0_:GetCurPet()
      _ARG_0_.bShowMyPet, _ARG_0_.CurPetExpressionList = _ARG_0_:GetShowMyPet(), {}
      if (not _ARG_0_.PetID or _ARG_0_.PetID <= 0 or not _ARG_0_.bShowMyPet) and not true then
        return
      end
      goto lbl_344
      if _ARG_0_.PetID == U1.CDataTable.GetTable((U2(69, 113, 180, 186, 111, 4, 47, 81, 41, 214, 209, 171, 251, 90))).PetID then
        if (not (U1.CDataTable.GetTable((U2(69, 113, 180, 186, 111, 4, 47, 81, 41, 214, 209, 171, 251, 90))).CanPlayInBattle ~= 1 and (U1.CDataTable.GetTable((U2(69, 113, 180, 186, 111, 4, 47, 81, 41, 214, 209, 171, 251, 90))).CanPlayInBattle ~= 2 or true)) or U1.CDataTable.GetTable((U2(69, 113, 180, 186, 111, 4, 47, 81, 41, 214, 209, 171, 251, 90))).CanPlayInBattle == 3 and true) and _ARG_0_:IsAvatarRequirementMatch((U3.Split(U1.CDataTable.GetTable((U2(69, 113, 180, 186, 111, 4, 47, 81, 41, 214, 209, 171, 251, 90))).DependingClothesID, (U2(105))))) then
        end
      end
      ::lbl_344::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if #_ARG_0_.CurPetExpressionList <= 0 then
        return
      end
      goto lbl_393
      ;(6).IsLocked = not (function(_ARG_0_)
        do
          if _ENV and 0 < #_ENV then
            goto lbl_19
            if _ARG_0_ == U1.tonumber(nil) then
              return true
            end
            ::lbl_19::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)((6).ID)
      ::lbl_393::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshCollectionList"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 125, 126, 74, 135, 81, 211, 179, 175, 63, 74, 114),
        U1(112, 119, 180, 146, 99, 30, 10, 87, 52, 246)
      }), _ARG_0_.bCollectionInited)
      if _ARG_0_.bCollectionInited then
        return
      end
      if not slua.isValid((U2.GetPlayerController())) or not U2.GetPlayerController().PlayEmoteFeature then
        return
      end
      if not U2.GetPlayerController().PlayEmoteFeature.CollectionList then
        return
      end
      goto lbl_97
      U3[U1(112, 119, 180, 146, 99, 30, 10, 87, 52, 246)] = true
      ::lbl_97::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.bCollectionInited = true
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurPet"] = function(_ARG_0_)
    do
      if not GetPlayerController() or not U1.slua.isValid((GetPlayerController())) then
        return
      end
      if GetPlayerController().IsInPetSpectator and GetPlayerController():IsInPetSpectator() and GetPlayerController().GetPetSpectatorComp and U1.slua.isValid((GetPlayerController():GetPetSpectatorComp())) and GetPlayerController():GetPetSpectatorComp().PetSpectatorPawn and GetPlayerController():GetPetSpectatorComp().PetSpectatorPawn.PetLevelInfo then
        return GetPlayerController():GetPetSpectatorComp().PetSpectatorPawn.PetLevelInfo.PetId, GetPlayerController():GetPetSpectatorComp().PetSpectatorPawn.PetLevelInfo.PetLevel
      end
      if U1.slua.isValid((GetPlayerController():GetPlayerCharacterSafety())) and U1.slua.isValid(GetPlayerController():GetPlayerCharacterSafety().PetComponent_BP) and U1.slua.isValid(GetPlayerController():GetPlayerCharacterSafety().PetComponent_BP.PetPawn) then
        return GetPlayerController():GetPlayerCharacterSafety().PetComponent_BP.PetPawn.PetLevelInfo.PetId, GetPlayerController():GetPlayerCharacterSafety().PetComponent_BP.PetPawn.PetLevelInfo.PetLevel
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowChangeFormGuide2"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 124, 115, 67, 130, 119, 200, 186, 130, 55, 67, 88),
        U1(122, 102, 173, 188, 121, 25, 34, 91, 117)
      }))
      if not U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot) or not slua.isValid((U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot))) then
        return
      end
      if SubsystemMgr:Get((U1(84, 98, 161, 143, 109, 2, 5, 86, 38, 236, 215, 172, 209, 80, 121, 81, 182, 81, 210, 184, 133, 51, 66, 107, 58))) then
        if SubsystemMgr:Get((U1(84, 98, 161, 143, 109, 2, 5, 86, 38, 236, 215, 172, 209, 80, 121, 81, 182, 81, 210, 184, 133, 51, 66, 107, 58))):GetGuideState(U2.GetOwningPlayerPawnOrVehicleDriver(_ARG_0_.UIRoot), 2) then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetElementVisibility"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 124, 126, 88, 176, 88, 197, 182, 137, 62, 82, 72),
        U1(124, 103, 169, 153, 101, 28, 47, 74, 62)
      }), _ARG_1_, _ARG_2_)
      if _ARG_0_.bShowBottom ~= _ARG_1_ or _ARG_0_.bShowDecal ~= _ARG_2_ then
        _ARG_0_.bShowBottom = _ARG_1_
        _ARG_0_.bShowDecal = _ARG_2_
        if _ARG_0_.CurrentShowState ~= U2.None then
          _ARG_0_:RefreshGridPanel()
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsAvatarRequirementMatch"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return true
      end
      if slua_GameFrontendHUD:GetPlayerController():GetCurrentPetInfo() and slua_GameFrontendHUD:GetPlayerController():GetCurrentPetInfo().PetAvatarList then
        goto lbl_45
        goto lbl_43
        if tostring(nil) == nil then
          return true
        end
        ::lbl_43::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        ::lbl_45::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryPlayPetExhibitAction"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(118, 120, 169, 158, 98, 4, 104, 77, 43, 247, 209, 231, 251, 80, 108, 85, 134, 10, 212, 164, 139, 46, 90, 97, 54, 246, 142, 191, 238, 91, 53, 64, 154, 83, 201, 184, 179, 54, 79, 106),
        U1(67, 113, 178, 136, 101, 31, 40, 97, 35, 237, 199, 167, 251, 80, 106, 88)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      if U2.GetPlayerCharacter() and slua.isValid((U2.GetPlayerCharacter())) and U2.GetPlayerCharacter().PetExhibitFeature then
        if U2.GetPlayerCharacter():AllowState(UEnums.EPawnState.PlayEmote, true) then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanShowPetBubblePanel"] = function(_ARG_0_)
    do
      do return GetPlayerController().CommerFeature and GetPlayerController().CommerFeature.bHasPetBubblePrivilege end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonPetBubble"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 110, 128, 64, 212, 180, 130, 0, 67, 106),
        U1(87, 97, 162, 153, 96, 21, 102)
      }) .. _ARG_0_.CurrentShowState)
      if _ARG_0_.CurrentShowState ~= U2.PetBubble then
        _ARG_0_.CurrentShowState = U2.PetBubble
        _ARG_0_:RefreshGridPanel()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonSpectatorPetBubble"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 110, 128, 64, 212, 180, 130, 3, 86, 123),
        U1(118, 96, 161, 143, 99, 2, 22, 91, 51, 192, 197, 171, 245, 83, 110, 28)
      }) .. _ARG_0_.CurrentShowState)
      if _ARG_0_.CurrentShowState ~= U2.SpectatorPetBubble then
        _ARG_0_.CurrentShowState = U2.SpectatorPetBubble
        _ARG_0_:RefreshGridPanel()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPetBubble"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 125, 126, 74, 135, 81, 211, 179, 188, 53, 82, 92),
        U1(96, 118, 162, 151, 105)
      }))
      if U2.GetPlayerController().CommerFeature and U2.GetPlayerController().CommerFeature.PetBubbleIDList then
        _ARG_0_ = _ARG_0_
        if _ARG_0_:GetQuickExpressionDecalItemByIndex(U1(96, 118, 162, 151, 105) + 1) then
        end
        _ARG_0_ = _ARG_0_
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClothChange"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 111, 153, 91, 212, 179, 175, 56, 71, 112),
        U1(114, 113, 224, 184, 121, 2, 52, 91, 41, 246, 227, 161, 248, 72, 88, 72, 132, 80, 213)
      }), _ARG_0_.CurrentShowState)
      if _ARG_0_.CurrentShowState ~= U2.None then
        _ARG_0_:RefreshChangeAvatarFormBtnState(true)
      end
      if _ARG_0_.CurrentShowState == U2.Expression then
        _ARG_0_:RefreshExpression()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonMiniTvExpression"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 110, 128, 64, 212, 180, 130, 29, 79, 112),
        U1(124, 64, 182, 190, 116, 0, 52, 91, 52, 241, 217, 166, 249, 31)
      }) .. _ARG_0_.CurrentShowState)
      if _ARG_0_.CurrentShowState ~= U2.MiniTvExpression then
        _ARG_0_.CurrentShowState = U2.MiniTvExpression
        _ARG_0_:RefreshGridPanel()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PrepareMiniTvExpressionList"] = function(_ARG_0_)
    do
      if _ARG_0_.bInitMiniTvExpressionList then
        return
      end
      _ARG_0_.bInitMiniTvExpressionList = true
      _ARG_0_.MiniTvExpressionList = {}
      if GetPlayerController().CommerFeature and GetPlayerController().CommerFeature.MiniTVActionIDList then
        goto lbl_69
        if U1.CDataTable.GetTableDataByFilter(U2(69, 113, 180, 186, 111, 4, 47, 81, 41, 214, 209, 171, 251, 90), U2(69, 113, 180, 186, 111, 4, 47, 81, 41, 203, 244), nil) then
          _ARG_0_.MiniTvExpressionList[#_ARG_0_.MiniTvExpressionList + 1] = {
            ID = nil,
            IsLocked = false,
            SortKey = U1.CDataTable.GetTableDataByFilter(U2(69, 113, 180, 186, 111, 4, 47, 81, 41, 214, 209, 171, 251, 90), U2(69, 113, 180, 186, 111, 4, 47, 81, 41, 203, 244), nil).SortKey,
            MasterSkillID = U1.CDataTable.GetTableDataByFilter(U2(69, 113, 180, 186, 111, 4, 47, 81, 41, 214, 209, 171, 251, 90), U2(69, 113, 180, 186, 111, 4, 47, 81, 41, 203, 244), nil).MasterSkillID
          }
        end
        ::lbl_69::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshMiniTvExpression"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 125, 126, 74, 135, 81, 211, 179, 161, 57, 72, 119),
        U1(65, 98, 133, 131, 124, 2, 35, 77, 52, 235, 223, 167)
      }))
      _ARG_0_:RefreshMiniTvShowSwitch()
      _ARG_0_:PrepareMiniTvExpressionList()
      if not _ARG_0_.bShowMiniTv or #_ARG_0_.MiniTvExpressionList <= 0 then
        _ARG_0_:HideRestBlocks(0)
        return
      end
      goto lbl_108
      if _ARG_0_:GetQuickExpressionDecalItemByIndex(U1(65, 98, 133, 131, 124, 2, 35, 77, 52, 235, 223, 167)) then
      end
      ::lbl_108::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshMiniTvShowSwitch"] = function(_ARG_0_)
    do
      _ARG_0_.bShowMiniTv = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.SettingModule):GetOptionValue((U1(70, 124, 175, 140, 65, 25, 40, 87, 19, 244, 249, 167, 209, 86, 108, 84, 145, 77, 222, 172)))
      _ARG_0_.bShowMiniTvExpressionTab = _ARG_0_:GetMiniTvType() == require((table.concat({
        U1(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 109, 70, 83, 129, 10, 247, 170, 145, 37, 70, 98, 54, 235, 142, 152, 228, 91, 116, 94, 219, 100, 197, 175, 194, 29, 79, 112),
        U1(124, 64, 182, 174, 120, 25, 42)
      }))).ENUM_MINITV_TYPE.Standalone
      _ARG_0_.bShowMiniTvBubbleExpression = _ARG_0_.bShowMiniTv and _ARG_0_:GetMiniTvType() == require((table.concat({
        U1(82, 117, 173, 158, 64, 5, 39, 16, 10, 237, 212, 231, 213, 109, 70, 83, 129, 10, 247, 170, 145, 37, 70, 98, 54, 235, 142, 152, 228, 91, 116, 94, 219, 100, 197, 175, 194, 29, 79, 112),
        U1(124, 64, 182, 174, 120, 25, 42)
      }))).ENUM_MINITV_TYPE.AttachedToPet
      if _ARG_0_.bShowMiniTvBubbleExpression then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonShowMiniTv"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 96, 117, 110, 128, 64, 212, 180, 130, 3, 78, 113),
        U1(98, 89, 169, 149, 101, 36, 48)
      }))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMiniTvType"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(68, 97, 169, 152, 103, 53, 62, 78, 53, 231, 195, 186, 254, 80, 101, 120, 128, 71, 209, 167, 175, 53, 84, 94, 54, 252, 197, 181, 189, 104, 126, 88, 184, 93, 206, 178, 184, 38, 114, 103),
        U1(101, 113)
      }))
      if slua.isValid((U2.GetPlayerController())) and U2.GetPlayerController().IsInPetSpectator and U2.GetPlayerController():IsInPetSpectator() then
      else
      end
      do return (U2.GetPlayerCharacter().PetComponent_BP:GetMiniTvType()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonMiniTvBubbleExpression"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(78, 121, 169, 149, 101, 47, 50, 72, 26, 162, 225, 188, 254, 92, 96, 121, 157, 84, 194, 174, 143, 51, 95, 97, 57, 214, 197, 186, 230, 67, 72, 89, 151, 100, 193, 181, 137, 60, 28, 81),
        U1(123, 86, 181, 143, 120, 31, 40, 115, 46, 236, 217, 157, 225, 125, 126, 94, 135, 72, 213, 142, 132, 48, 68, 107, 36, 225, 201, 182, 233)
      }))
      if slua.isValid((U2.GetPlayerController())) and U2.GetPlayerController().IsInPetSpectator and U2.GetPlayerController():IsInPetSpectator() then
      elseif slua.isValid((U2.GetPlayerCharacter())) and U2.GetPlayerCharacter().PetExhibitFeature then
        if not _ARG_0_:GetRandomUnlockedPetActionID() then
          return
        end
        if slua.isValid(U2.GetPlayerCharacter().GetPlayerStateSafety and U2.GetPlayerCharacter():GetPlayerStateSafety()) and (U2.GetPlayerCharacter().GetPlayerStateSafety and U2.GetPlayerCharacter():GetPlayerStateSafety()).RPC_ServerAddGeneralCount then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetRandomUnlockedPetActionID"] = function(_ARG_0_)
    do
      if not _ARG_0_.CurPetExpressionList or not next(_ARG_0_.CurPetExpressionList) then
        _ARG_0_:RefreshPetInfo()
      end
      if not _ARG_0_.CurPetExpressionList or not next(_ARG_0_.CurPetExpressionList) then
        print(bWriteLog and table.concat({
          U1(78, 121, 169, 149, 101, 47, 50, 72, 26, 162, 247, 172, 227, 109, 106, 82, 129, 75, 221, 158, 146, 44, 89, 109, 60, 247, 196, 137, 226, 91, 90, 79, 129, 93, 207, 181, 165, 20, 28, 62),
          U1(86, 97, 178, 171, 105, 4, 3, 70, 55, 240, 213, 186, 228, 86, 100, 82, 169, 77, 195, 191, 220, 41, 69, 46, 50, 255, 208, 173, 254)
        }))
        return nil
      end
      goto lbl_117
      ::lbl_117::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if #{} <= 0 then
        return nil
      end
      do return ({})[math.random(#{})] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}) end
return
