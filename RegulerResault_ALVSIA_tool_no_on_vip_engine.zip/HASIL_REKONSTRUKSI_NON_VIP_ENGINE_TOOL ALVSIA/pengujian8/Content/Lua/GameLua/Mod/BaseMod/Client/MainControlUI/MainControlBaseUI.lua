do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(239, 217, 167, 213, 139)))(require((table.concat({
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(203, 212, 171, 195, 180, 48, 242, 236, 156, 200, 249, 178, 140, 140, 131, 122, 49, 234, 210, 184, 75, 26, 142, 159, 174, 217, 163, 217, 151, 211, 181, 70, 32, 224, 199, 211, 107, 0, 129, 181),
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(229, 209, 161, 195, 140)
}))), nil, {
  ["ctor"] = function(_ARG_0_)
    do
      _ARG_0_.bNeedDelayRegistEvents = true
      _ARG_0_.HasInit = false
      _ARG_0_.BackPackPickUpPanel = nil
      _ARG_0_.BasicSkillsMenuUI = nil
      _ARG_0_.CanHideUIMainModeID = {
        [101] = {},
        [102] = {},
        [103] = {},
        [111] = {},
        [112] = {},
        [113] = {},
        [401] = {},
        [402] = {},
        [403] = {},
        [411] = {},
        [412] = {},
        [413] = {}
      }
      _ARG_0_.GoldNum = 0
      _ARG_0_.ChatTurnplateCommonRotaryTableUITool = _ENV()
      _ARG_0_.ChatTurnplateCommonRotaryTableUITool:Initialize(78, 1, 8, 60)
      _ARG_0_.BuffListCloseStartCountDown = false
      _ARG_0_.DynamicBattleFBTipsWidget = nil
      _ARG_0_.RolewearTabArray = {}
      _ARG_0_.ForceShowWidgets = {}
      _ARG_0_.ForceHideWidgets = {}
      _ARG_0_.HideWidgetsNames = {}
      _ARG_0_.IsInitHideUIFunc = false
      _ARG_0_.HighLayerHideWidgetsNames = {
        BuffAddHp_UIBP_C = U1(196, 229, 150, 199, 150, 32, 255)
      }
      _ARG_0_.IsFirstHideUI = true
      _ARG_0_.HasRecevieInitWidgetEvent = false
      _ARG_0_.QuickMsgIndex = -1
      _ARG_0_.CurBuffListCloseCountTime = 0.0
      _ARG_0_.IsCurTurnplateTipsShow = false
      _ARG_0_.bFinishedLoadBattleUI = false
      _ARG_0_.BigEvent_Btn = nil
      _ARG_0_.ChatBtnNormalOpacity = 0.0
      _ARG_0_.HideNavigator = false
      _ARG_0_.ShowNavigator = true
      _ARG_0_.NavigatorIsShow = true
      _ARG_0_.bIsQuickMenuCoolingDown = false
      _ARG_0_.VoiceForbidBtn = false
      _ARG_0_.bGuideLoopAnim = false
      _ARG_0_.GuideLoopTimer = nil
      _ARG_0_.GuideBtnShowMap = {}
      _ARG_0_.HitTipsTimer = nil
      _ARG_0_.DamageCauserLocation = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 228, 243, 111, 28, 144, 134, 132, 193, 232, 226, 170, 142))
      _ARG_0_:AddControlEvent(_ARG_0_.Button_IngameGM, U1(195, 219, 133, 202, 145, 38, 248, 167, 181), _ARG_0_.OpenIngameGMPanel, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_.Button_Border_close, U1(195, 219, 133, 202, 145, 38, 248, 167, 181), _ARG_0_.OnClickQuickChatClose, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_.Image_25, U1(195, 219, 139, 201, 141, 54, 246, 128, 164, 211, 233, 243, 160, 169, 159, 104, 18, 192, 192, 243, 102, 1), _ARG_0_.OnCreateGMUI, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_.EntireMapTrigger, U1(195, 219, 150, 212, 157, 54, 224, 134, 190, 208, 243), _ARG_0_.OnEntireMapTriggerOnPressDown, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_.EntireMapTrigger, U1(195, 219, 142, 201, 148, 33, 214, 172, 181, 194, 249), _ARG_0_.OnEntireMapTriggerHoldEnded, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_.EntireMapTrigger, U1(195, 219, 133, 202, 145, 38, 248, 149, 184, 211, 245, 243, 187, 153, 184, 112, 16, 225), _ARG_0_.OnEntireMapTriggerClick, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_.TurnplateBtn_UIBP_0, U1(201, 241, 153, 242, 141, 55, 253, 178, 189, 198, 233, 249, 140, 153, 158, 75, 19, 240, 213, 254, 91, 1, 130, 128, 181), _ARG_0_.OnTurnplateBtnTouchStart, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_.TurnplateBtn_UIBP_0, U1(201, 241, 153, 242, 141, 55, 253, 178, 189, 198, 233, 249, 140, 153, 158, 75, 19, 240, 213, 254, 69, 26, 149, 151), _ARG_0_.OnTurnplateBtnTouchMove, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_.TurnplateBtn_UIBP_0, U1(201, 241, 153, 242, 141, 55, 253, 178, 189, 198, 233, 249, 140, 153, 158, 75, 19, 240, 213, 254, 77, 27, 135), _ARG_0_.OnTurnplateBtnTouchEnd, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_.Button_ReportBug, U1(195, 219, 133, 202, 145, 38, 248, 167, 181), _ARG_0_.OnClicked_Button_ReportBug, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_.Button_0, U1(195, 219, 133, 202, 145, 38, 248, 167, 181), _ARG_0_.OnClicked_Button_0, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_.Button_B_Sigh_yellow, U1(195, 219, 133, 202, 145, 38, 248, 167, 181), _ARG_0_.OnClicked_Button_B_Sigh_yellow, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_.MultiButton_EntireMapTrigger, U1(195, 219, 133, 202, 145, 38, 248, 167, 181), _ARG_0_.OnClicked_MultiButton_EntireMapTrigger, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_.Button_ExitTraining, U1(195, 219, 133, 202, 145, 38, 248, 167, 181), _ARG_0_.OnClicked_Button_ExitTraining, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_.Button_GameGuide, U1(195, 219, 133, 202, 145, 38, 248, 167, 181), _ARG_0_.OnClicked_Button_GameGuide, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_[U2.TipsFlyAnim], U1(195, 219, 135, 200, 145, 40, 242, 182, 184, 200, 243, 218, 167, 131, 153, 108, 20, 224, 210), _ARG_0_.OnTipsAnimationFinished, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME, EVENTID_INGAME_ENTERPRISEGMMOD_CHANGE, _ARG_0_.CheckEnterpriseGMMod, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME, EVENTID_INGAME_QUICK_EXPRESSION_CLICK, _ARG_0_.HandleQuickExpressClick, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME, EVENTID_INGAME_SHOW_OR_HIDE_QUICK_EXPRESSION, _ARG_0_.OnShowOrHideQuickExpressionRing, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME, EVENTID_INGAME_CONTROLLER_BEGINPLAY_FINISH, _ARG_0_.OnPlayerControllerBeginplayFinish, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME, EVENTID_INGAME_OPEN_HIDE_SPEECH_TO_TEXT, _ARG_0_.OnShowSpeechToText, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME, EVENTID_INGAME_SHOWOFF_TIPS, _ARG_0_.OnShowOffTips, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME_PARACHUTING, EVENTID_PARACHUTING_ENTER_PLANE, _ARG_0_.OnEnterPlane, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME_SPECTATING, EVENTID_OBSERVE_LAST_ATTACKER, _ARG_0_.ObserveLastAttacker, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME_UI, EVENTID_SHOW_ATTACH_UI, _ARG_0_.ShowAttachUI, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME, EVENTID_INGAME_SHOWALLUIFORDELATRESULT, _ARG_0_.ShowAllUIForDelayResult, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME, EVENTID_SHOW_ALL_UI, _ARG_0_.OnTurnplateBtnTouchEnd, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME, EVENTID_SHOW_COMPLETE_PLAYBACK_UI, _ARG_0_.OnEnterCompletePlayback, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME, EVENTID_INGAME_ON_ENTER_WONDERFUL, _ARG_0_.OnEnterWonderfulPlayback, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME, EVENTID_SHOW_SPECTATING_UI, _ARG_0_.ShowSpectatingUI, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME, EVENTID_CHANGE_MAP_BUTTON_SHOW, _ARG_0_.ChangeMapBtnShow, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_GAME_MODE_STATE_CHANGE, _ARG_0_.HandleOnGameModeStateChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_INGAME_TEAM_SHOW_READY, _ARG_0_.HideTurnplateUIBP, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME, EVENTID_INGAME_SHOW_DARK_NIGHT, _ARG_0_.OnShowDarkNight, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME_MAINCONTROLUI_PANEL, EVENTID_MAINCONTROLPANELUI_REMINDCHATBTN, _ARG_0_.RemindQuickChatBtn, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME_MAINCONTROLUI_PANEL, EVENTID_MAINCONTROLPANELUI_CHECKSHOWWMODEUI, function()
        _ENV:CheckShowWModeUI(true)
        return
      end, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME_MAINCONTROLUI_PANEL, EVENTID_MAINCONTROLPANELUI_STARTCHATBARANIMA, function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
        do
          _ENV:StartChatBarAnima(_ARG_3_)
          do return end
          _ARG_0_ = _ARG_0_
        end
      end, _ARG_0_)
      _ARG_0_:AddDataListener(U3.GetSuperData(), U1(220, 217, 167, 223, 157, 55, 208, 170, 176, 213, 252, 255, 186, 136, 130), _ARG_0_.OnPlayerCharacterChange, _ARG_0_)
      _ARG_0_.BasicSkillsMenuUI = _ARG_0_:AddChildWidget(_ARG_0_.BasicSkillsMenu_BP, U5.LuaFileExits((string.format(table.concat({
        U1(203, 212, 171, 195, 180, 48, 242, 236, 156, 200, 249, 178, 235, 158, 222, 92, 16, 236, 211, 248, 124, 91, 176, 153, 168, 219, 225, 162, 156, 156, 147, 102, 15, 198, 205, 239, 116, 9, 128, 175),
        U1(233, 219, 179, 228, 168, 26, 222, 163, 184, 201)
      }), (U4.GetModType())))) and string.format(table.concat({
        U1(203, 212, 171, 195, 180, 48, 242, 236, 156, 200, 249, 178, 235, 158, 222, 92, 16, 236, 211, 248, 124, 91, 176, 153, 168, 219, 225, 162, 156, 156, 147, 102, 15, 198, 205, 239, 116, 9, 128, 175),
        U1(233, 219, 179, 228, 168, 26, 222, 163, 184, 201)
      }), (U4.GetModType())) or table.concat({
        U1(203, 212, 171, 195, 180, 48, 242, 236, 156, 200, 249, 178, 140, 140, 131, 122, 49, 234, 210, 184, 75, 25, 138, 151, 175, 195, 163, 223, 181, 148, 140, 99, 66, 215, 199, 245, 113, 6, 160, 137),
        U1(229, 217, 170, 213, 181, 32, 253, 183, 147, 247, 194, 209, 175, 132, 158)
      }))
      _ARG_0_.BackPackPickUpPanel = _ARG_0_:AddChildWidget(_ARG_0_.BackPackPickUpPanel_BP, (table.concat({
        U1(203, 212, 171, 195, 180, 48, 242, 236, 156, 200, 249, 178, 140, 140, 131, 122, 49, 234, 210, 184, 75, 25, 138, 151, 175, 195, 163, 206, 191, 158, 139, 95, 13, 246, 205, 168, 90, 4, 144, 137),
        U1(220, 212, 165, 205, 168, 44, 240, 169, 132, 215, 205, 253, 160, 136, 156)
      })))
      if U6.GetAllActorsOfClass(_ARG_0_, import((table.concat({
        U1(163, 242, 167, 203, 157, 106, 209, 174, 164, 194, 205, 238, 167, 131, 132, 108, 83, 198, 217, 228, 109, 90, 161, 162, 158, 250, 228, 226, 183, 176, 129, 127, 63, 225, 199, 232, 124, 4, 129, 134),
        U1(220, 218, 175, 200, 140, 107, 209, 146, 142, 234, 244, 242, 167, 160, 145, 111, 47, 241, 215, 248, 108, 20, 145, 150, 145, 216, 228, 226, 170, 162, 163)
      }))), (slua.Array(UEnums.EPropertyClass.Object, (import((U1(163, 230, 165, 212, 145, 53, 231, 237, 148, 201, 250, 245, 160, 136, 222, 94, 31, 241, 217, 228))))))):Num() > 0 and slua.isValid((U6.GetAllActorsOfClass(_ARG_0_, import((table.concat({
        U1(163, 242, 167, 203, 157, 106, 209, 174, 164, 194, 205, 238, 167, 131, 132, 108, 83, 198, 217, 228, 109, 90, 161, 162, 158, 250, 228, 226, 183, 176, 129, 127, 63, 225, 199, 232, 124, 4, 129, 134),
        U1(220, 218, 175, 200, 140, 107, 209, 146, 142, 234, 244, 242, 167, 160, 145, 111, 47, 241, 215, 248, 108, 20, 145, 150, 145, 216, 228, 226, 170, 162, 163)
      }))), (slua.Array(UEnums.EPropertyClass.Object, (import((U1(163, 230, 165, 212, 145, 53, 231, 237, 148, 201, 250, 245, 160, 136, 222, 94, 31, 241, 217, 228))))))):Get(0))) then
        _ARG_0_.NavigateCorrecteAngle = U6.GetAllActorsOfClass(_ARG_0_, import((table.concat({
          U1(163, 242, 167, 203, 157, 106, 209, 174, 164, 194, 205, 238, 167, 131, 132, 108, 83, 198, 217, 228, 109, 90, 161, 162, 158, 250, 228, 226, 183, 176, 129, 127, 63, 225, 199, 232, 124, 4, 129, 134),
          U1(220, 218, 175, 200, 140, 107, 209, 146, 142, 234, 244, 242, 167, 160, 145, 111, 47, 241, 215, 248, 108, 20, 145, 150, 145, 216, 228, 226, 170, 162, 163)
        }))), (slua.Array(UEnums.EPropertyClass.Object, (import((U1(163, 230, 165, 212, 145, 53, 231, 237, 148, 201, 250, 245, 160, 136, 222, 94, 31, 241, 217, 228))))))):Get(0):K2_GetActorRotation().Yaw
      end
      if not _ARG_0_.HasRecevieInitWidgetEvent and _ARG_0_:CheckIsNeedOpenGameJoy() then
      end
      _ARG_0_.HasRecevieInitWidgetEvent = true
      _ARG_0_.NavigatorIsShow = _ARG_0_:ShouldShowNavigator(), "NavigatorIsShow"
      if slua.isValid((U3.GetGameState())) then
      else
      end
      if UIManager.ShowUI(UIManager.UI_Config_InGame.ChangeSightUI, _ARG_0_) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceivedInitWidget"] = function(_ARG_0_)
    do
      _ARG_0_:OnInitializeDelay()
      _ARG_0_:RegistEventsDelay()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitializeDelay"] = function(_ARG_0_)
    do
      _ARG_0_:InitQuickSignUI()
      _ARG_0_:InitSpeakerUIUI()
      _ARG_0_:CreateChildWindow(_ARG_0_.CanvasPanel_ZTK, UIManager.UI_Config_InGame.SettingButton)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEventsDelay"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitQuickSignUI"] = function(_ARG_0_)
    do
      _ARG_0_:CreateChildWindow(_ARG_0_.CanvasPanel_QuickSign, UIManager.UI_Config_InGame.QuickSignUI)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitSpeakerUIUI"] = function(_ARG_0_)
    do
      _ARG_0_:CreateChildWindow(_ARG_0_.SpeakerCanvasPanel, UIManager.UI_Config_InGame.SpeakerUI)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayerCharacterChange"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SwitchCameraModeScope_Aim"] = function(_ARG_0_)
    do
      if _ARG_0_.NewFreeCameraBtn then
        _ARG_0_.NewFreeCameraBtn:SwitchCameraModeScope_Aim()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowServerTime"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ongamemodestatechanged"] = function(_ARG_0_)
    do
      _ARG_0_:UIMsg_Onplayercontrollerstatechanged()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowAttachUI"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_3_) then
        _ARG_0_.CanvasPanel_ActorUISlot:AddChild(_ARG_3_)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIMsg_Onplayercontrollerstatechanged"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetGameState())) or GetGameState().GetGameModeState == nil then
        return
      end
      if GetGameState():GetGameModeState() == U2(222, 208, 167, 194, 129, 22, 231, 163, 165, 194) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnterReadyState"] = function(_ARG_0_)
    do
      if UIManager.UI_Config_InGame.IslandSurviveCountPanel then
        UIManager.ShowUI(UIManager.UI_Config_InGame.IslandSurviveCountPanel)
      end
      if U1.GetSurviveInfoPanel() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ExitReadyState"] = function(_ARG_0_)
    do
      if UIManager.UI_Config_InGame.IslandSurviveCountPanel then
        UIManager.CloseUI(UIManager.UI_Config_InGame.IslandSurviveCountPanel)
      end
      if U1.GetSurviveInfoPanel() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowOrHideNewbieGuide"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ENV[_ARG_1_] then
        return
      end
      if not U1.UIManager.UI_Config_InGame or not U1.UIManager.UI_Config_InGame[_ENV[_ARG_1_].UIConfigName] then
        return
      end
      if not _ARG_2_ then
        return
      end
      if not U1.slua.isValid((U2.GetPlayerController())) or U2.GetPlayerController():IsSpectator() then
        return
      end
      if not U1.CDataTable.GetTableData(U3(203, 192, 175, 194, 157, 17, 246, 186, 165), _ARG_1_) then
        return
      end
      if U1.UIManager.ShowUI(U1.UIManager.UI_Config_InGame[_ENV[_ARG_1_].UIConfigName], (U1.CDataTable.GetTableData(U3(203, 192, 175, 194, 157, 17, 246, 186, 165), _ARG_1_))) and _ARG_0_[_ENV[_ARG_1_].SocketName] then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnBackPackClose"] = function(_ARG_0_)
    do
      _ARG_0_:ShowQuickMsgInfo(true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIMsg_ShowDeathMatchUI"] = function(_ARG_0_)
    do
      _ARG_0_:ShowDeathMatchUI()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIMsg_PlayHelmetEffect"] = function(_ARG_0_)
    do
      _ARG_0_:PlayUserWidgetAnimation(_ARG_0_.HelmetFull, 0, 1, 0, 1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIMsg_PlayArmorEffect"] = function(_ARG_0_)
    do
      _ARG_0_:PlayUserWidgetAnimation(_ARG_0_.ArmorFull, 0, 1, 0, 1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIMsg_UpdateBackpackCloth"] = function(_ARG_0_)
    do
      _ARG_0_:CallBackpackLuaFunction((_ENV(217, 197, 162, 199, 140, 32, 208, 174, 190, 211, 245, 213, 186, 136, 157, 83, 21, 246, 194)))
      _ARG_0_:RefreshEmoteWhenShow()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIMsg_RefreshEmote"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshEmote()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIMsg_EnterTrainingMode"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetGameState())) then
        return
      end
      if not GetGameState().bIsTrainingMode then
      else
        if not U1.slua.isValid((GetPlayerController())) then
          return
        end
        if GetPlayerController():IsFriendObserver() then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIMsg_HideJoinGameUI"] = function(_ARG_0_)
    do
      _ARG_0_:HideJoinGameUI()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIMsg_ScopeChanged"] = function(_ARG_0_)
    do
      if not _ARG_0_.NewFreeCameraBtn then
        return
      end
      _ARG_0_.NewFreeCameraBtn:UIMsg_ScopeChanged()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnHUDSettingChange"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 254, 247, 102, 17, 143, 151, 142, 217, 197, 217, 154, 174, 133, 123, 24, 252, 200, 225, 91, 13, 146, 140),
        U1(235, 208)
      }))
      _ARG_0_:RefreshVehicleHPPanel()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleAttachedToVehicle"] = function(_ARG_0_)
    do
      if not _ARG_0_:GetVehicleUserComponent() then
        return
      end
      _ARG_0_.CurVehicle = _ARG_0_:GetVehicleUserComponent():GetVehicle()
      if not slua.isValid(_ARG_0_.CurVehicle) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleDetachedFromVehicle"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 254, 247, 102, 17, 143, 151, 133, 210, 249, 237, 189, 149, 133, 107, 42, 231, 201, 235, 78, 0, 155, 139),
        U1(239, 217, 163)
      }))
      _ARG_0_.CurVehicle = nil
      _ARG_0_:RefreshVehicleHPPanel()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshVehicleHPPanel"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 228, 243, 110, 7, 134, 129, 169, 225, 232, 228, 183, 158, 140, 106, 36, 197, 246, 231, 118, 0, 159), _ARG_0_.CurVehicle)
      if not _ARG_0_:GetVehicleUserComponent() then
        return
      end
      if UIManager.UI_Config_InGame.VehicleHPPanel == nil then
        return
      end
      if _ARG_0_.CurVehicle == nil then
        if UIManager.GetUI(UIManager.UI_Config_InGame.PlayerInfoPanelMain) then
        end
        return
      end
      if _ARG_0_:GetVehicleUserComponent():GetVehicle():GetVehicleCommon() and slua.isValid((_ARG_0_:GetVehicleUserComponent():GetVehicle():GetVehicleCommon())) then
        if _ARG_0_:GetVehicleUserComponent():GetVehicle():GetVehicleCommon().GetUGCHUDStatus and _ARG_0_:GetVehicleUserComponent():GetVehicle():GetVehicleCommon():GetUGCHUDStatus() == U2.VehicleHPOn then
          if not UIManager.IsUIShow(UIManager.UI_Config_InGame.VehicleHPPanel) and UIManager.ShowUI(UIManager.UI_Config_InGame.VehicleHPPanel) then
            if UIManager.GetUI(UIManager.UI_Config_InGame.PlayerInfoPanelMain) then
            end
          end
        elseif UIManager.GetUI(UIManager.UI_Config_InGame.PlayerInfoPanelMain) then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnVehicleHPChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 249, 248, 94, 16, 139, 155, 162, 219, 232, 196, 142, 190, 136, 110, 2, 242, 195, 166) .. _ARG_1_((U1(160, 149))) .. _ARG_2_)
      if UIManager.UI_Config_InGame.VehicleHPPanel == nil then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIMsg_VehicleHPChanged"] = function(_ARG_0_, _ARG_1_)
    do
      if UIManager.UI_Config_InGame.VehicleHPPanel == nil or not slua.isValid(_ARG_1_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleUserComponent"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) then
        return nil
      end
      if not U1.slua.isValid((GetPlayerController():GetVehicleUserComp())) then
        return nil
      end
      do return (GetPlayerController():GetVehicleUserComp()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickBackPackButton"] = function(_ARG_0_)
    do
      if SubsystemMgr:Get((U1(195, 197, 163, 212, 153, 49, 246, 145, 164, 197, 238, 229, 189, 153, 149, 114))) then
      end
      if _ARG_0_:IsBackpackCollapsed() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBackPackPickUpPanel"] = function(_ARG_0_)
    do
      do return _ARG_0_.BackPackPickUpPanel end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBasicSkillsMenuUI"] = function(_ARG_0_)
    do
      do return _ARG_0_.BasicSkillsMenuUI end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Reconnect_ResetUIByPlayerControllerState"] = function(_ARG_0_)
    do
      if U1.slua.isValid((GetPlayerController())) then
        if GetPlayerController():IsInFight() then
        elseif GetPlayerController():IsInPlane() then
        else
        end
      end
      if U1.slua.isValid((GetGameState())) and GetGameState().GetSuperData then
        if GetGameState():GetSuperData().NeedUpdateAllWarModeUI == nil then
          GetGameState():GetSuperData().NeedUpdateAllWarModeUI = 0
        end
        GetGameState():GetSuperData().NeedUpdateAllWarModeUI = 1 - GetGameState():GetSuperData().NeedUpdateAllWarModeUI
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopFreeCamera"] = function(_ARG_0_)
    do
      _ARG_0_.NewFreeCameraBtn:StopFreeCamera()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideQuickChatMenu"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 254, 255, 108, 16, 178, 135, 168, 212, 230, 207, 182, 156, 148, 66, 9, 251, 211), _ARG_1_)
      if not _ARG_1_ and UIManager.GetUI(UIManager.UI_Config_InGame.QuickMenu) then
        if UIManager.GetUI(UIManager.UI_Config_InGame.QuickMenu):IsShow() then
        else
        end
      end
      if not _ARG_0_.WidgetSwitcher_Chat:GetActiveWidgetIndex() == 2 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowQuickChatMenu"] = function(_ARG_0_)
    do
      if UIManager.GetUI(UIManager.UI_Config_InGame.BackPackPanelUI) and UIManager.GetUI(UIManager.UI_Config_InGame.BackPackPanelUI):IsCollapsed() then
        if UIManager.GetUI(UIManager.UI_Config_InGame.QuickMenu) then
        end
        if not slua.isValid((slua_GameFrontendHUD:GetPlayerController())) then
          return
        end
        if not slua.isValid((import((U2(223, 225, 131, 222, 140, 55, 242, 128, 189, 210, 248, 236, 188, 132, 158, 107, 58, 240, 216, 245, 124, 28, 140, 156, 141, 222, 239, 254, 191, 143, 153))).GetChatComponentfromController((slua_GameFrontendHUD:GetPlayerController())))) then
          return
        end
        if _ARG_0_.Image_hot:GetVisibility() == U1.Visible or _ARG_0_.Image_hot:GetVisibility() == U1.HitTestInvisible or _ARG_0_.Image_hot:GetVisibility() == U1.SelfHitTestInvisible then
          if UIManager.GetUI(UIManager.UI_Config_InGame.QuickMenu) then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleQuickExpressClick"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.HideBuffList then
        _ARG_0_:HideBuffList()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShowOrHideQuickExpressionRing"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ then
        _ARG_0_:ShowExpressionRing()
      else
        _ARG_0_:HideExpressionRing()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowExpressionRing"] = function(_ARG_0_)
    do
      if UIManager.ShowUI(UIManager.UI_Config_InGame.QuickExpression) then
      end
      if _ARG_0_.Emote_SettingControl and UIManager.ShowUI(UIManager.UI_Config_InGame.QuickExpression) then
      end
      if UIManager.ShowUI(UIManager.UI_Config_InGame.QuickExpression) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetExpressionRing"] = function(_ARG_0_)
    do
      if UIManager.UI_Config_InGame.QuickExpression then
        return UIManager.GetUI(UIManager.UI_Config_InGame.QuickExpression)
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideExpressionRing"] = function(_ARG_0_)
    do
      if _ARG_0_:GetExpressionRing() then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshEmoteWhenShow"] = function(_ARG_0_)
    do
      if _ARG_0_:GetExpressionRing() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshEmote"] = function(_ARG_0_)
    do
      if _ARG_0_:GetExpressionRing() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenIngameGMPanel"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayerControllerBeginplayFinish"] = function(_ARG_0_)
    do
      _ARG_0_:CheckEnterpriseGMMod()
      _ARG_0_:CheckGMButtonVisibility()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCreateGMUI"] = function(_ARG_0_)
    do
      if U1.slua.isValid((GetPlayerController())) and GetPlayerController():IsAGMPlayer() then
        if not U1.slua.isValid(_ARG_0_.GMUI) then
          _ARG_0_.GMUI = U1.import((U2(223, 225, 131, 222, 140, 55, 242, 128, 189, 210, 248, 236, 188, 132, 158, 107, 58, 240, 216, 245, 124, 28, 140, 156, 141, 222, 239, 254, 191, 143, 153))).CreateWidgetByPathName(U1.table.concat({
            U2(163, 242, 167, 203, 157, 106, 209, 174, 164, 194, 205, 238, 167, 131, 132, 108, 83, 208, 255, 185, 79, 56, 160, 157, 175, 196, 226, 224, 187, 210, 167, 66, 57, 220, 136, 193, 85, 48, 186, 189),
            U2(207)
          }), (GetPlayerController()))
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckGMButtonVisibility"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Button_IngameGM) then
        return
      end
      if not slua.isValid(_ARG_0_.TextBlock_GMUI) then
        return
      end
      if slua.isValid((U1.GetPlayerController())) and (U1.GetPlayerController():IsAGMPlayer() or U1.GetPlayerController():IsEnterpriseGMMod()) then
        if not Client.IsEditor() then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckEnterpriseGMMod"] = function(_ARG_0_)
    do
      if slua_GameFrontendHUD:GetPlayerController():IsEnterpriseGMMod() then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBackpackCollapsed"] = function(_ARG_0_)
    do
      if not UIManager.GetUI(UIManager.UI_Config_InGame.BackPackPanelUI) then
        return true
      end
      do return UIManager.GetUI(UIManager.UI_Config_InGame.BackPackPanelUI):IsCollapsed() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CallBackpackLuaFunction"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetBackpackUI() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BackpackGetArmorSlotItem"] = function(_ARG_0_, _ARG_1_)
    do
      do return GetBackpackUI():GetArmorSlotItem(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAddNewMiniMap"] = function(_ARG_0_)
    do
      if UIManager.GetUI(UIManager.UI_Config_InGame.MiniMapWindow) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnChatPrivacyAccepted"] = function(_ARG_0_)
    do
      if SubsystemMgr:Get((U1(218, 218, 175, 197, 157, 6, 251, 163, 165, 244, 232, 254, 189, 148, 131, 107, 25, 232))) then
        SubsystemMgr:Get((U1(218, 218, 175, 197, 157, 6, 251, 163, 165, 244, 232, 254, 189, 148, 131, 107, 25, 232))):GetSuperData().bOnChatPrivacyAccepted = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateSnowBoardBtn"] = function(_ARG_0_)
    do
      if not (U1.slua.isValid((GetPlayerCharacter())) and GetPlayerCharacter().IsCanDriveSnowBoard) or not GetPlayerCharacter():IsCanDriveSnowBoard() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBlueCirclePreWarningGeneralTipId"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:IsWinOBCN() then
        return 1000207
      elseif _ARG_1_ == 0 then
        return 1000201
      elseif _ARG_1_ == 1 then
        return 1000202
      elseif _ARG_1_ == 2 then
        return 1000203
      else
        return 1000201
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShowSpeechToText"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ then
        _ARG_0_:CreateChildWindow(_ARG_0_.ChatAndChatPanelCanvas, UIManager.UI_Config_InGame.SpeechToText)
        _ARG_0_:HideQuickChatMenu()
      else
        if UIManager.GetUI(UIManager.UI_Config_InGame.SpeechToText) then
          UIManager.CloseUI(UIManager.UI_Config_InGame.SpeechToText)
        end
        _ARG_0_:ShowQuickChatMenu()
      end
      _ARG_0_.CanvasPanel_ShowOffTips:SetWidgetVisibility(U1.Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShowOffTips"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 249, 248, 91, 29, 140, 133, 142, 209, 235, 216, 183, 141, 147), _ARG_3_)
      if UIManager.UI_Config_InGame.ShowOffTipsUI and UIManager.ShowUI(UIManager.UI_Config_InGame.ShowOffTipsUI, _ARG_3_) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = _ENV[219]
    end
  end,
  ["OnEnterPlane"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 249, 248, 77, 27, 151, 151, 179, 231, 225, 237, 176, 152))
      if UIManager.UI_Config_InGame.ShowOffTipsUI and UIManager.IsUIShow(UIManager.UI_Config_InGame.ShowOffTipsUI) then
        UIManager.CloseUI(UIManager.UI_Config_InGame.ShowOffTipsUI)
      end
      _ARG_0_:CallBackpackLuaFunction((U1(207, 217, 175, 197, 147, 6, 255, 173, 162, 194, 223, 253, 173, 134, 128, 126, 31, 238)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickQuickChatClose"] = function(_ARG_0_)
    do
      if _ARG_0_.bIsQuickMenuCoolingDown then
        return
      end
      _ARG_0_.bIsQuickMenuCoolingDown = true
      _ARG_0_:AddGameTimer(0.2, false, function()
        bIsQuickMenuCoolingDown = false
        return
      end)
      _ARG_0_:HideQuickChatMenu()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDestroy"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 249, 248, 76, 16, 144, 134, 179, 216, 244))
      _ARG_0_.HasInit = false
      _ARG_0_.BackPackPickUpPanel = nil
      _ARG_0_.BasicSkillsMenuUI = nil
      _ARG_0_.GMUI = nil
      EventSystem:postEvent(EVENTTYPE_INGAME_UI, EVENTID_REMOVE_FROM_FORCE_HIDE_UI_ARRAY, _ARG_0_.Object)
      EventSystem:postEvent(EVENTTYPE_INGAME_UI, EVENTID_REMOVE_FROM_FORCE_HIDE_UI_ARRAY, _ARG_0_.Chat)
      U2.UnRegisterCanvasVisibleEvent(_ARG_0_.BasicSkillsMenu_BP)
      U2.UnRegisterCanvasVisibleEvent(_ARG_0_.CanvasPanel_BackpackPanel)
      U2.UnRegisterCanvasVisibleEvent(_ARG_0_.Emote_SwimingControl)
      U2.UnRegisterCanvasVisibleEvent(_ARG_0_.CircleChasingProgress)
      U2.UnRegisterCanvasVisibleEvent(_ARG_0_.CanvasPanel_MiniMapAndSetting)
      U2.UnRegisterCanvasVisibleEvent(_ARG_0_.Border_NewBackPack)
      U2.UnRegisterCanvasVisibleEvent(_ARG_0_.BackPackPickUpPanel_BP)
      U2.UnRegisterCanvasVisibleEvent(_ARG_0_.CanvasPanel_FreeCamera)
      if _ARG_0_.UpdateTrainingTimer then
        _ARG_0_:RemoveGameTimer(_ARG_0_.UpdateTrainingTimer)
        _ARG_0_.UpdateTrainingTimer = nil
      end
      if _ARG_0_.HitTipsTimer then
        print(bWriteLog and table.concat({
          U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 249, 248, 92, 20, 136, 151, 133, 214, 224, 237, 185, 152, 192, 93, 9, 248, 201, 240, 125, 69, 187, 139),
          U1(248, 225, 175, 214, 139, 17, 250, 175, 180, 213)
        }))
        _ARG_0_:RemoveGameTimer(_ARG_0_.HitTipsTimer)
        _ARG_0_.HitTipsTimer = nil
      end
      _ARG_0_.DamageCauserLocation = nil
      _ARG_0_.DynamicBattleFBTipsWidget = nil
      _ARG_0_.RolewearTabArray = nil
      _ARG_0_.ForceShowWidgets = nil
      _ARG_0_.ForceHideWidgets = nil
      _ARG_0_.BigEvent_Btn = nil
      if UIManager and UIManager.UI_Config_InGame.ChangeSightUI then
        UIManager.CloseUI(UIManager.UI_Config_InGame.ChangeSightUI)
      end
      if UIManager and UIManager.UI_Config_InGame.QuickExpression then
        UIManager.CloseUI(UIManager.UI_Config_InGame.QuickExpression)
      end
      if UIManager and UIManager.UI_Config_InGame.SpeechToText then
        UIManager.CloseUI(UIManager.UI_Config_InGame.SpeechToText)
      end
      if UIManager and UIManager.UI_Config_InGame.MicrophoneButton then
        UIManager.CloseUI(UIManager.UI_Config_InGame.MicrophoneButton)
      end
      if _ARG_0_.VoiceForbidBtn then
        _ARG_0_.VoiceForbidBtn:Close()
        _ARG_0_.VoiceForbidBtn = nil
      end
      U3.__super.OnDestroy(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearBPArray"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ and _ARG_1_.Clear then
        _ARG_1_:Clear()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEntireMapTriggerOnPressDown"] = function(_ARG_0_, _ARG_1_)
    do
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.SettingModule):GetOptionValue((U1(238, 246, 167, 200, 181, 36, 227, 142, 190, 201, 250, 204, 188, 136, 131, 108))) == nil or ModuleManager.GetModule(ModuleManager.CommonModuleConfig.SettingModule):GetOptionValue((U1(238, 246, 167, 200, 181, 36, 227, 142, 190, 201, 250, 204, 188, 136, 131, 108))) == true then
        _ARG_0_.EntireMapTrigger.ButtonType = 3
      else
        _ARG_0_.EntireMapTrigger.ButtonType = 1
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEntireMapTriggerHoldEnded"] = function(_ARG_0_)
    do
      BatttleWindowMgr.HideUI((U1(201, 219, 178, 207, 138, 32, 222, 163, 161, 240, 244, 242, 170, 130, 135)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEntireMapTriggerClick"] = function(_ARG_0_)
    do
      if _ARG_0_.EntireMapTrigger.ButtonType == 1 then
        _ARG_0_:ShowEntireMapWindow()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowEntireMapWindow"] = function(_ARG_0_)
    do
      if UIManager.GetUI(UIManager.UI_Config_InGame.EntireMapWindow) then
        if UIManager.IsUIShow(UIManager.UI_Config_InGame.EntireMapWindow) then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTurnplateBtnTouchStart"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 249, 248, 92, 0, 145, 156, 177, 219, 236, 248, 187, 191, 148, 97, 56, 250, 211, 229, 112, 54, 135, 131),
        U1(254, 193)
      }), _ARG_0_.bIsQuickMenuCoolingDown, _ARG_0_.ChatOpenTime)
      if _ARG_0_.bIsQuickMenuCoolingDown then
        return
      end
      if U2.GetRealTimeSeconds(_ARG_0_) > _ARG_0_.ChatOpenTime then
        _ARG_0_.ChatTurnplateCommonRotaryTableUITool:OnTouchedStart(_ARG_0_.TurnplateBtn_UIBP_0.PressedPosition)
        _ARG_0_:HideQuickChatMenu(true)
        _ARG_0_.ChatBtnLongPressTimerID = _ARG_0_:AddGameTimer(0.2, false, function()
          ChatBtnLongPressTimerID = nil
          _ENV:ShowTurnplateUI()
          return
        end)
        _ARG_0_.bIsQuickMenuCoolingDown = true
        _ARG_0_:AddGameTimer(0.5, false, function()
          bIsQuickMenuCoolingDown = false
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowTurnplateUI"] = function(_ARG_0_)
    do
      _ARG_0_.Image_ChatBG:SetWidgetVisibility(SelfHitTestInvisible)
      _ARG_0_.Image_ChatBG:SetRenderScale(U1.FVector2D(1.25, 1.25))
      _ARG_0_.Image_ChatBG:SetOpacity(1)
      _ARG_0_:HideBuffList()
      if U1.slua.isValid((U2.GetPlayerController())) then
        if not U1.slua.isValid((U3.GetChatComponentFromController((U2.GetPlayerController())))) then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTurnplateBtnTouchMove"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 249, 248, 92, 0, 145, 156, 177, 219, 236, 248, 187, 191, 148, 97, 56, 250, 211, 229, 112, 40, 156, 148),
        U1(233)
      }))
      if U2.GetRealTimeSeconds(_ARG_0_) > _ARG_0_.ChatOpenTime and UIManager.UI_Config_InGame and UIManager.UI_Config_InGame.TurnplateUIControl then
        if UIManager.GetUI(UIManager.UI_Config_InGame.TurnplateUIControl) then
        elseif _ARG_0_.ChatTurnplateCommonRotaryTableUITool:IsValidedMove(slua.IndexReference(_ARG_0_.TurnplateBtn_UIBP_0, (U1(207, 192, 180, 246, 151, 54, 250, 182, 184, 200, 243))), 5) and _ARG_0_.ChatBtnLongPressTimerID then
          _ARG_0_.ChatBtnLongPressTimerID = nil
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["QuickMsgTurnplateBtnMove"] = function(_ARG_0_)
    do
      if UIManager.GetUI(UIManager.UI_Config_InGame.TurnplateUIControl) then
      end
      if _ARG_0_.ChatTurnplateCommonRotaryTableUITool.CurIndex == -1 then
        _ARG_0_.QuickMsgIndex = -1
      elseif _ARG_0_.ChatTurnplateCommonRotaryTableUITool.CurIndex ~= _ARG_0_.QuickMsgIndex then
        _ARG_0_.QuickMsgIndex = _ARG_0_.ChatTurnplateCommonRotaryTableUITool.CurIndex
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTurnplateBtnTouchEnd"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 249, 248, 92, 0, 145, 156, 177, 219, 236, 248, 187, 191, 148, 97, 56, 250, 211, 229, 112, 32, 157, 134))
      if _ARG_0_.ChatBtnLongPressTimerID then
        _ARG_0_:RemoveGameTimer(_ARG_0_.ChatBtnLongPressTimerID)
        _ARG_0_.ChatBtnLongPressTimerID = nil
        if U2.GetRealTimeSeconds(_ARG_0_) > _ARG_0_.ChatOpenTime then
          _ARG_0_:CheckTopChatMsg()
          _ARG_0_:ShowQuickChatMenu()
          U3.ReportGeneralCountByBRPhase(12008, 12010)
        end
      elseif UIManager.GetUI(UIManager.UI_Config_InGame.TurnplateUIControl) then
        if UIManager.GetUI(UIManager.UI_Config_InGame.TurnplateUIControl).UIRoot:IsIndexValid(_ARG_0_.QuickMsgIndex) and 0 <= _ARG_0_.QuickMsgIndex and slua.isValid((U4.GetPlayerController())) and slua.isValid((U5.GetChatComponentFromController((U4.GetPlayerController())))) then
          if slua.isValid(U5.GetChatComponentFromController((U4.GetPlayerController())).TurnplateChatQuickList) and 0 <= _ARG_0_.QuickMsgIndex and _ARG_0_.QuickMsgIndex < U5.GetChatComponentFromController((U4.GetPlayerController())).TurnplateChatQuickList:Num() and U5.GetChatComponentFromController((U4.GetPlayerController())).TurnplateChatQuickList:Get(_ARG_0_.QuickMsgIndex) and (U5.GetChatComponentFromController((U4.GetPlayerController())).TurnplateChatQuickList:Get(_ARG_0_.QuickMsgIndex).chatTextID or 0) ~= 0 then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideTurnplateUIBP"] = function(_ARG_0_)
    do
      _ARG_0_.Image_ChatBG:SetWidgetVisibility(SelfHitTestInvisible)
      _ARG_0_.Image_ChatBG:SetRenderScale(U1.FVector2D(1, 1))
      _ARG_0_.Image_ChatBG:SetOpacity(_ARG_0_.ChatBtnNormalOpacity)
      _ARG_0_.Image_SelectedChatCircle:SetWidgetVisibility(Collapsed)
      _ARG_0_.Border_Normal:SetRenderTranslation(U1.FVector2D(0, 0))
      _ARG_0_.QuickMsgIndex = -1
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckTopChatMsg"] = function(_ARG_0_)
    do
      if not SubsystemMgr:Get((U1(218, 218, 175, 197, 157, 23, 246, 161, 190, 202, 240, 249, 160, 137, 145, 107, 21, 234, 216, 197, 125, 23, 144, 139, 178, 195, 232, 225))) then
        return
      end
      if not slua.isValid((U2.GetPlayerController())) then
        return
      end
      if not slua.isValid((U3.GetChatComponentFromController((U2.GetPlayerController())))) then
        return
      end
      if U4.IsJapanOrKorea() then
        return
      end
      if SubsystemMgr:Get((U1(218, 218, 175, 197, 157, 23, 246, 161, 190, 202, 240, 249, 160, 137, 145, 107, 21, 234, 216, 197, 125, 23, 144, 139, 178, 195, 232, 225))):DoCheckCondition() ~= nil and SubsystemMgr:Get((U1(218, 218, 175, 197, 157, 23, 246, 161, 190, 202, 240, 249, 160, 137, 145, 107, 21, 234, 216, 197, 125, 23, 144, 139, 178, 195, 232, 225))):DoCheckCondition() ~= -1 then
      end
      if _ARG_0_.LastRecommendIndex ~= nil and _ARG_0_.LastRecommendIndex == SubsystemMgr:Get((U1(218, 218, 175, 197, 157, 23, 246, 161, 190, 202, 240, 249, 160, 137, 145, 107, 21, 234, 216, 197, 125, 23, 144, 139, 178, 195, 232, 225))):DoCheckCondition() then
        return
      end
      _ARG_0_.LastRecommendIndex = SubsystemMgr:Get((U1(218, 218, 175, 197, 157, 23, 246, 161, 190, 202, 240, 249, 160, 137, 145, 107, 21, 234, 216, 197, 125, 23, 144, 139, 178, 195, 232, 225))):DoCheckCondition()
      if SubsystemMgr:Get((U1(218, 218, 175, 197, 157, 23, 246, 161, 190, 202, 240, 249, 160, 137, 145, 107, 21, 234, 216, 197, 125, 23, 144, 139, 178, 195, 232, 225))):DoCheckCondition() ~= nil then
        goto lbl_92
        ::lbl_92::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if UIManager.GetUI(UIManager.UI_Config_InGame.QuickMenu) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartChatBarAnimation"] = function(_ARG_0_, _ARG_1_)
    do
      if 0 < _ARG_1_ then
        Client.RequireSlateTickEveryFrame(SlateUI_ID.MAINCONTROL_BASE_UI_CHATBAR_CD)
        _ARG_0_.ChatOpenTime = U2.GetRealTimeSeconds(_ARG_0_) + _ARG_1_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleChangeSightUIAndroidBack"] = function(_ARG_0_)
    do
      if UIManager.GetUI(UIManager.UI_Config_InGame.ChangeSightUI) and UIManager.GetUI(UIManager.UI_Config_InGame.ChangeSightUI).UIRoot.CanvasPanelList:GetVisibility() ~= U1.Collapsed then
        _ARG_0_.hasOpenedSubPanel = true
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsUseNewHitEffect"] = function(_ARG_0_)
    do
      if not SubsystemMgr:Get((U1(223, 218, 179, 200, 156, 19, 250, 177, 164, 198, 241, 245, 180, 140, 132, 118, 19, 235, 229, 227, 106, 6, 154, 129, 181, 210, 224))) then
        return false
      end
      if Game:IsValid((U2.GetPlayerController())) and U2.GetPlayerController().IsObserver and U2.GetPlayerController():IsObserver() then
        return false
      end
      do return SubsystemMgr:Get((U1(223, 218, 179, 200, 156, 19, 250, 177, 164, 198, 241, 245, 180, 140, 132, 118, 19, 235, 229, 227, 106, 6, 154, 129, 181, 210, 224))):UseNewHitStyle() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowNavigatorPanel"] = function(_ARG_0_)
    do
      if not UIManager.GetUI(UIManager.UI_Config_InGame.NavigatorPanel) then
        UIManager.ShowUI(UIManager.UI_Config_InGame.NavigatorPanel)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnNavigatorVisibleChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_.NavigatorIsShow = _ARG_3_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowOrHideBackPackBtnTips"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if UIManager.GetUI(UIManager.UI_Config_InGame.BackpackClothingEntryUI) then
        if _ARG_2_ then
          _ARG_2_.text1 = _ARG_2_.Text1
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TickHitTips"] = function(_ARG_0_)
    do
      if not _ARG_0_.DamageCauserLocation then
        print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 226, 255, 107, 30, 171, 155, 181, 227, 228, 252, 173, 221, 166, 110, 5, 249, 195, 226))
        _ARG_0_.CanvasPanel_HItTips:SetWidgetVisibility(U2.Collapsed)
        _ARG_0_.CanvasPanel_OBAttackerTips:SetWidgetVisibility(U2.Collapsed)
        if _ARG_0_.HitTipsTimer then
          print(bWriteLog and table.concat({
            U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 249, 248, 92, 20, 136, 151, 133, 214, 224, 237, 185, 152, 192, 93, 9, 248, 201, 240, 125, 69, 187, 139),
            U1(248, 225, 175, 214, 139, 17, 250, 175, 180, 213)
          }))
          _ARG_0_:RemoveGameTimer(_ARG_0_.HitTipsTimer)
          _ARG_0_.HitTipsTimer = nil
        end
        return
      end
      if U3.CalculateDirectionAngle(_ARG_0_.DamageCauserLocation, 0) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTakeDamage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 249, 248, 92, 20, 136, 151, 133, 214, 224, 237, 185, 152, 192, 78, 2, 242, 202, 227), _ARG_1_, _ARG_2_, _ARG_3_)
      if slua.isValid((U2.GetPlayerCharacter())) and _ARG_3_ <= 0 and U2.GetPlayerCharacter().bIgnoreShowHurtEffectWhenAttackByTeammate then
        return
      end
      if not (U2.GetPlayerController():IsShowBlood() and _ARG_0_:IsShowHit()) or not _ARG_1_ then
        if _ARG_0_.HitTipsTimer then
          _ARG_0_.HitTipsTimer = nil
        end
        return
      end
      if not slua.isValid(_ARG_2_) then
        return
      end
      _ARG_0_.DamageCauserLocation = _ARG_2_:K2_GetActorLocation()
      if not _ARG_0_.HitTipsTimer then
        _ARG_0_.HitTipsTimer = _ARG_0_:AddGameTimer(U3, true, function()
          _ENV:TickHitTips()
          CanvasPanel_HItTips:SetWidgetVisibility(U1.HitTestInvisible)
          return
        end)
      end
      if U2.GetPlayerController():IsObserver() and slua.isValid(_ARG_2_) and not (Game:IsMonster(_ARG_2_) or Game:IsAI(_ARG_2_) and 0 < _ARG_2_.ResId) then
        if slua.isValid(_ARG_0_.AttackerTips) and math.cos(math.rad(-_ARG_1_ + 90)) * 200 and -math.sin(math.rad(-_ARG_1_ + 90)) * 200 then
          if 0 < math.cos(math.rad(-_ARG_1_ + 90)) * 200 then
          else
          end
          if SubsystemMgr:Get((U1(195, 247, 147, 210, 145, 41, 250, 182, 168, 244, 232, 254, 189, 148, 131, 107, 25, 232))) and SubsystemMgr:Get((U1(195, 247, 147, 210, 145, 41, 250, 182, 168, 244, 232, 254, 189, 148, 131, 107, 25, 232))):GetSyncOBDataActor() then
            goto lbl_482
            if (210).PlayerKey == _ARG_2_.PlayerKey then
            end
            ::lbl_482::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
          if SubsystemMgr:Get((U1(195, 247, 147, 210, 145, 41, 250, 182, 168, 244, 232, 254, 189, 148, 131, 107, 25, 232))) and _ARG_2_.TeamID then
          end
          if (210).PlayerName then
          end
          if (210).TeamName then
          end
        end
      end
      if slua.isValid(_ARG_2_) and _ARG_2_.PlayerKey then
        _ARG_0_.nLastAttackerPlayerKey = _ARG_2_.PlayerKey
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPCOBAttackerTips"] = function(_ARG_0_)
    do
      if _ARG_0_.AttackerTips then
        return _ARG_0_.AttackerTips
      end
      _ARG_0_.AttackerTips = slua.loadUI((table.concat({
        U1(163, 242, 167, 203, 157, 106, 209, 174, 164, 194, 205, 238, 167, 131, 132, 108, 83, 208, 255, 185, 71, 55, 182, 187, 238, 254, 249, 233, 179, 210, 175, 77, 51, 212, 210, 242, 121, 6, 152, 135),
        U1(254, 225, 175, 214, 139, 107, 220, 128, 142, 230, 233, 232, 175, 142, 155, 122, 14, 209, 223, 230, 123)
      })))
      if _ARG_0_.AttackerTips then
        _ARG_0_.CanvasPanel_OBAttackerTips:AddChild(_ARG_0_.AttackerTips)
        _ARG_0_.AttackerTips.Slot:SetAnchors(FAnchors(0, 0, 0, 0))
        _ARG_0_.AttackerTips.Slot:SetOffsets(FMargin(0, 0, 0, 0))
        _ARG_0_.AttackerTips.Slot:SetAutoSize(true)
        return _ARG_0_.AttackerTips
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ObserveLastAttacker"] = function(_ARG_0_)
    do
      if U1.slua.isValid((GetPlayerController())) and GetPlayerController().ServerObserveCharacter and GetPlayerController():IsObserver() and _ARG_0_.nLastAttackerPlayerKey and _ARG_0_.nLastAttackerPlayerKey > 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVoiceSDKInterface"] = function(_ARG_0_)
    do
      do return require((U1(239, 217, 175, 195, 150, 49, 189, 161, 190, 202, 240, 243, 160, 195, 133, 118, 35, 240, 194, 255, 100))).GetGameFrontendHUD():GetVoiceSDKInterface() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenReportBug"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 249, 230, 109, 27, 177, 151, 177, 216, 255, 248, 156, 136, 135))
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_home_entry):IsPlanPHMode() then
        if UIManager.UI_Config_InGame.BattleReportBug then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegShowQuickDecal"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShowQuickDecalButton"] = function(_ARG_0_, _ARG_1_)
    do
      if UIManager.UI_Config_InGame.QuickExpressionDecalUI then
        if _ARG_0_:CreateAndGetQuickExpressionDecalUI() and _ARG_1_ == U1.NormalPlayer then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CreateAndGetQuickExpressionDecalUI"] = function(_ARG_0_)
    do
      do return not UIManager.UI_Config_InGame.QuickExpressionDecalUI or UIManager.GetUI(UIManager.UI_Config_InGame.QuickExpressionDecalUI) or UIManager.ShowUI(UIManager.UI_Config_InGame.QuickExpressionDecalUI) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideQuickExpressionDecalUI"] = function(_ARG_0_)
    do
      if UIManager.GetUI(UIManager.UI_Config_InGame.QuickExpressionDecalUI) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleAndroidBack"] = function(_ARG_0_)
    do
      _ARG_0_:CallBackpackLuaFunction((_ENV(207, 217, 175, 197, 147, 6, 255, 173, 162, 194, 223, 253, 173, 134, 128, 126, 31, 238)))
      _ARG_0_:ShowQuickMsgInfo(true)
      _ARG_0_:HideQuickChatMenu()
      _ARG_0_:ShowOrHideQuickExpressionRing(false)
      U1.BatttleWindowMgr.CheckCloseMiniMap()
      _ARG_0_:HandleChangeSightUIAndroidBack()
      _ARG_0_:HideBuffList()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleEntireMapTrigger"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_0_.EntireMapTrigger) then
        print(bWriteLog and string.format((table.concat({
          U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 254, 247, 102, 17, 143, 151, 132, 217, 249, 229, 172, 152, 173, 110, 28, 193, 212, 239, 127, 2, 150, 144),
          U1(172, 152, 131, 200, 140, 44, 225, 167, 156, 198, 237, 200, 188, 132, 151, 120, 25, 247, 150, 255, 123, 85, 141, 155, 173)
        }))))
        return
      end
      if _ARG_2_ == EVENTID_OPEN_BACKPACK then
        _ARG_0_.EntireMapTrigger:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      elseif _ARG_2_ == EVENTID_CLOSE_BACKPACK then
        _ARG_0_.EntireMapTrigger:SetWidgetVisibility(UEnums.ESlateVisibility.Visible)
      end
      print(bWriteLog and string.format(table.concat({
        U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 254, 247, 102, 17, 143, 151, 132, 217, 249, 229, 172, 152, 173, 110, 28, 193, 212, 239, 127, 2, 150, 144),
        U1(172, 152, 131, 200, 140, 44, 225, 167, 156, 198, 237, 200, 188, 132, 151, 120, 25, 247, 150, 224, 97, 6, 138, 144, 168, 219, 228, 248, 167, 199, 192, 42, 8)
      }), _ARG_0_.EntireMapTrigger:GetVisibility()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenGMInterface"] = function(_ARG_0_)
    do
      if U1.slua.isValid((GetPlayerController())) then
        if GetPlayerController():IsAGMPlayer() then
          if U1.Client.IsEditor() then
            return
          end
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnterFlying"] = function(_ARG_0_)
    do
      _ARG_0_:ShowOrHideFreeCam(false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleEmoteSetting"] = function(_ARG_0_)
    do
      _ARG_0_:AddSettingOptionEvent(_ENV(205, 214, 178, 201, 138, 4, 253, 171, 188, 198, 233, 245, 161, 131, 163, 104, 21, 241, 213, 254), function(_ARG_0_)
        do
          _ENV:SetEmoteControlVisibility(Emote_SettingControl, _ARG_0_)
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)
      _ARG_0_:AddSettingOptionEvent(_ENV(195, 247, 149, 228, 141, 41, 255, 167, 165, 243, 239, 253, 173, 134), function(_ARG_0_)
        do
          do return end
          _ARG_0_ = _ARG_0_
        end
      end)
      if U2.slua_GameFrontendHUD:GetUserSettings() then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIMsg_ShowEnemyLaunchRocketTips"] = function(_ARG_0_)
    do
      _ARG_0_.CanvasPanel_EnemyLaunchRocketTip:SetWidgetVisibility(SelfHitTestInvisible)
      _ARG_0_:AddGameTimer(3.0, false, function()
        CanvasPanel_EnemyLaunchRocketTip:SetWidgetVisibility(U1.Collapsed)
        return
      end)
      _ARG_0_.CanvasPanel_CircleTipsPanel:SetWidgetVisibility(Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnterJumping"] = function(_ARG_0_)
    do
      _ARG_0_:EnterJumpingSetUI()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClicked_Button_ReportBug"] = function(_ARG_0_)
    do
      PlayAudio(U1.sound_config.set)
      _ARG_0_:OpenReportBug()
      U1.print(U1.bWriteLog and U2(215, 198, 169, 200, 159, 2, 199, 159, 241, 135, 255, 249, 168, 130, 130, 122, 92, 165, 198, 250, 105, 12, 195, 129, 174, 194, 227, 232, 254))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClicked_MultiButton_EntireMapTrigger"] = function(_ARG_0_)
    do
      _ARG_0_:TriggerEntireMap()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TriggerEntireMap"] = function(_ARG_0_)
    do
      BatttleWindowMgr.OpenOrHideEntireMap()
      _ARG_0_:HideBuffList()
      _ARG_0_:HideQuickChatMenu()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClicked_Button_0"] = function(_ARG_0_)
    do
      if GetRealTimeSeconds(_ARG_0_) > _ARG_0_.ChatOpenTime then
        _ARG_0_:ShowQuickChatMenu()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClicked_Button_B_Sigh_yellow"] = function(_ARG_0_)
    do
      if GetRealTimeSeconds(_ARG_0_) > _ARG_0_.ChatOpenTime then
        _ARG_0_:ShowQuickChatMenu()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartChatBarAnima"] = function(_ARG_0_, _ARG_1_)
    do
      if 0.0 < _ARG_1_ then
        Client.RequireSlateTickEveryFrame(SlateUI_ID.MAINCONTROL_BASE_UI_CHATBAR_CD)
        _ARG_0_.ChatOpenTime = U1.GetRealTimeSeconds(_ARG_0_) + _ARG_1_
        _ARG_0_.Image_ChatCDBar:SetWidgetVisibility(U2.SelfHitTestInvisible)
        _ARG_0_:PlayUserWidgetAnimation(_ARG_0_.Chat_Bar, 0.0, 1, U3.Forward, 1.0 / _ARG_1_)
        _ARG_0_:DelayHideChatCD(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DelayHideChatCD"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:AddGameTimer(_ARG_1_, false, function()
        Client.ResetSlateTickEveryFrame(SlateUI_ID.MAINCONTROL_BASE_UI_CHATBAR_CD)
        U1.Image_ChatCDBar:SetWidgetVisibility(U2.Collapsed)
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClicked_Button_ExitTraining"] = function(_ARG_0_)
    do
      _ARG_0_:ExitTraining()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ExitTraining"] = function(_ARG_0_)
    do
      PlayAudio(U1.sound_config.confirm)
      if U1.EventShowBackToLobbyFromTrainingNotice ~= nil then
        U1.EventShowBackToLobbyFromTrainingNotice()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BuffDisplayListBtnClickEvent"] = function(_ARG_0_)
    do
      if _ARG_0_.BuffEffectDisplayIDList:Num() > 0 then
        if _ARG_0_.DynamicBattleFBTipsWidget:GetVisibility() == Collapsed then
          _ARG_0_.DynamicBattleFBTipsWidget:SetWidgetVisibility(SelfHitTestInvisible)
        else
          _ARG_0_.DynamicBattleFBTipsWidget:SetWidgetVisibility(Collapsed)
          _ARG_0_.BuffListCloseStartCountDown = false
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowHelpIcon"] = function(_ARG_0_)
    do
      _ARG_0_.DynamicBattleFBTipsWidget.GridPanel_Help:SetWidgetVisibility(HitTestInvisible)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideHelpIcon"] = function(_ARG_0_)
    do
      _ARG_0_.DynamicBattleFBTipsWidget.GridPanel_Help:SetWidgetVisibility(Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowPowerIcon"] = function(_ARG_0_)
    do
      _ARG_0_.DynamicBattleFBTipsWidget.GridPanel_Power:SetWidgetVisibility(HitTestInvisible)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HidePowerIcon"] = function(_ARG_0_)
    do
      _ARG_0_.DynamicBattleFBTipsWidget.GridPanel_Power:SetWidgetVisibility(Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideBuffListEvent"] = function(_ARG_0_)
    do
      _ARG_0_:HideBuffList()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BindEventToBattleFBTips"] = function(_ARG_0_)
    do
      _ARG_0_:AddControlEvent(_ARG_0_.QuickExpressionUIBPDynamic, _ENV(201, 241, 153, 247, 141, 44, 240, 169, 148, 223, 237, 238, 171, 158, 131, 93, 8, 235, 245, 250, 97, 22, 136), _ARG_0_.HideBuffListEvent, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_.DynamicBattleFBTipsWidget, _ENV(201, 241, 153, 238, 145, 33, 246, 128, 164, 193, 251, 208, 167, 158, 132, 87, 19, 241, 247, 228, 109, 20, 160, 158, 168, 212, 230), _ARG_0_.HideBuffListEvent, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClicked_Button_Normal_EX"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClicked_EXButton_close"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIMsg_CloseQuickExpressionRing"] = function(_ARG_0_)
    do
      _ARG_0_:ShowOrHideQuickExpressionRing(false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DemoReplay_ReInit"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInfectedAreaWarnBroadcast"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayInfectAreaWarning()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClicked_Button_Setting"] = function(_ARG_0_)
    do
      PlayAudio(U1.sound_config.set)
      U1.EventSystem:postEvent(U1.EVENTTYPE_INGAME_UI, U1.EVENTID_NEW_EXPANDPANEL_MUTEX)
      if U1.UIManager.UI_Config_InGame and U1.UIManager.UI_Config_InGame.EntireMapWindow then
        U1.UIManager.HideUI(U1.UIManager.UI_Config_InGame.EntireMapWindow)
      end
      if U1.SubsystemMgr:Get((U2(195, 197, 163, 212, 153, 49, 246, 145, 164, 197, 238, 229, 189, 153, 149, 114))) then
      end
      if _ARG_0_._settingClickTimer then
        _ARG_0_._settingClickTimer = nil
        return
      end
      _ARG_0_._settingClickTimer = _ARG_0_:AddTimerOnce(0.2, function()
        _settingClickTimer = nil
        U1.UIManager.ShowUI(U1.UIManager.UI_Config.setting_main, U2.GetCurrentConfig((U3(223, 208, 178, 210, 145, 43, 244, 129, 176, 211, 252, 240, 161, 138))))
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitCircleInfo"] = function(_ARG_0_, _ARG_1_)
    do
      if U1.slua.isValid((GetGameState())) then
        if _ARG_1_ then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCircleBlueCirclePreWarning"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:IsBlueCirclePreWarningShouldShow((math.floor(_ARG_1_ + 0.5))) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSecondsFontType"] = function(_ARG_0_, _ARG_1_)
    do
      if 180 <= _ARG_1_ then
        return 0
      elseif 30 <= _ARG_1_ then
        return 1
      else
        return 2
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCircleBlueCircleRun"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:IsWinOBCN() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseLbsMicWhenCorpsMode"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitRolewearTab"] = function(_ARG_0_, _ARG_1_)
    do
      if U1.slua.isValid((GetPlayerController())) and GetPlayerController().RolewearIndex and GetPlayerController().FashionBagStartIndex then
        goto lbl_54
        ::lbl_54::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DynamicallyCreateBattleFBTipsUI"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.DynamicBattleFBTipsWidget) then
        _ARG_0_.DynamicBattleFBTipsWidget = U1.CreateWidgetByPathName(table.concat({
          U2(163, 242, 167, 203, 157, 106, 198, 143, 150, 136, 200, 213, 145, 175, 160, 48, 63, 234, 219, 251, 103, 27, 204, 176, 160, 195, 249, 224, 187, 162, 166, 77, 56, 252, 214, 245, 71, 48, 186, 160),
          U2(220, 155, 132, 199, 140, 49, 255, 167, 142, 225, 223, 200, 167, 157, 131, 64, 41, 204, 244, 198, 87, 54)
        }), _ARG_0_)
        _ARG_0_.DynamicBattleFBTipsWidget:SetParentWidget(_ARG_0_)
        _ARG_0_.DynamicBattleFBTipsWidget:SetWidgetVisibility(U3.SelfHitTestInvisible)
        _ARG_0_.CanvasPanel_42:AddChild(_ARG_0_.DynamicBattleFBTipsWidget)
        if Client.GetActiveProfileName() == U2(197, 229, 174, 201, 150, 32, 203) or Client.GetActiveProfileName() == U2(197, 229, 174, 201, 150, 32, 203, 145) or Client.GetActiveProfileName() == U2(197, 229, 174, 201, 150, 32, 203, 145, 156, 198, 229) or Client.GetActiveProfileName() == U2(197, 229, 174, 201, 150, 32, 203, 144) then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CreateHotAirBallonControl"] = function(_ARG_0_)
    do
      if slua.isValid(_ARG_0_.HotAirBallonControl) then
        _ARG_0_:SetHotAirBallonControlVisible(true)
        return _ARG_0_.HotAirBallonControl
      end
      _ARG_0_.HotAirBallonControl = U1.CreateWidgetByPathName(table.concat({
        U2(163, 242, 167, 203, 157, 106, 222, 173, 181, 136, 216, 234, 161, 175, 145, 108, 25, 170, 244, 250, 125, 16, 179, 128, 168, 217, 249, 255, 241, 168, 169, 32, 37, 251, 193, 231, 117, 0, 172, 170),
        U2(227, 193, 135, 207, 138, 7, 242, 174, 189, 200, 242, 242, 141, 130, 158, 107, 14, 234, 218, 201, 93, 60, 161, 162, 239, 254, 227, 235, 191, 144, 133, 80, 36, 250, 210, 199, 113, 23, 177, 131),
        U2(224, 217, 169, 201, 150, 6, 252, 172, 165, 213, 242, 240, 145, 184, 185, 93, 44, 218, 245)
      }), _ARG_0_)
      if not slua.isValid(_ARG_0_.HotAirBallonControl) then
        print(bWriteLog and table.concat({
          U2(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 245, 228, 109, 20, 151, 151, 137, 216, 249, 205, 183, 143, 162, 110, 0, 249, 201, 232, 91, 10, 157, 150),
          U2(254, 218, 170, 134, 213, 101, 208, 176, 180, 198, 233, 249, 238, 154, 153, 123, 27, 224, 194, 182, 110, 20, 138, 158, 164, 211)
        }))
        return
      end
      _ARG_0_.HotAirBallonControl:SetParentWidget(_ARG_0_)
      _ARG_0_.HotAirBallonControl:SetWidgetVisibility(U3.SelfHitTestInvisible)
      _ARG_0_.CanvasPanel_42:AddChild(_ARG_0_.HotAirBallonControl)
      _ARG_0_.HotAirBallonControl:UpdateObservationAreaUI()
      do return _ARG_0_.HotAirBallonControl end
      return
    end
  end,
  ["SetHotAirBallonControlVisible"] = function(_ARG_0_, _ARG_1_)
    do
      if slua.isValid(_ARG_0_.HotAirBallonControl) then
        _ARG_0_.HotAirBallonControl:UpdateObservationAreaUI()
        _ARG_0_.HotAirBallonControl:SetWidgetVisibility(_ARG_1_ and U1.SelfHitTestInvisible or U1.Collapsed)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddModeUI"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.TmodePanel:SetWidgetVisibility(SelfHitTestInvisible)
      _ARG_0_.TmodePanel.Slot:SetAnchors(U1.FAnchors(0.0, 0.0, 1.0, 1.0))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowOrHideQuickExpressionRing"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
        _ARG_0_:ShowExpressionRing()
      else
        _ARG_0_:HideExpressionRing()
        _ARG_0_.bLowDevice = import((U1(223, 225, 131, 222, 140, 55, 242, 133, 176, 202, 248, 213, 160, 158, 132, 126, 18, 230, 211))).GetInstance():IsIOSOneGigabyteDevice()
        if import((U1(223, 225, 131, 222, 140, 55, 242, 133, 176, 202, 248, 213, 160, 158, 132, 126, 18, 230, 211))) then
        end
      end
      EventSystem:postEvent(EVENTTYPE_INGAME, EVENTID_INGAME_SHOW_OR_HIDE_QUICK_EXPRESSION, false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DestroyExpressionRing"] = function(_ARG_0_)
    do
      if UIManager.UI_Config_InGame.QuickExpression then
        UIManager.CloseUI(UIManager.UI_Config_InGame.QuickExpression)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitMap"] = function(_ARG_0_)
    do
      _ARG_0_:CheckAddNewMiniMap()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnFBTipsIPXAdapt"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_1_:SetPosition(FVector2D(0.0, -57.0))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitDelegate"] = function(_ARG_0_)
    do
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME_BACKPACK, EVENTID_BACKPACK_AVATAR_ON_CHANGE_WEARING_DONE, function(_ARG_0_, _ARG_1_, _ARG_2_)
        do
          _ENV:InitRolewearTab(_ARG_2_)
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdatePickupList"] = function(_ARG_0_)
    do
      if U1.slua.isValid((GetPlayerController())) and U1.UIManager.UI_Config_InGame.PickUpListPanel then
        if GetPlayerController().bInItemGenerator then
          if GetPlayerController().bInItemGenerator or GetPlayerController().bInTombBoxGenerator then
            if U1.UIManager.GetUI(U1.UIManager.UI_Config_InGame.PickUpListPanel) then
            end
          elseif U1.UIManager.GetUI(U1.UIManager.UI_Config_InGame.PickUpListPanel) then
          end
        elseif U1.UIManager.GetUI(U1.UIManager.UI_Config_InGame.PickUpListPanel) then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideJoinGameUI"] = function(_ARG_0_)
    do
      _ARG_0_.CanvasPanel_AutoJoinPanel:SetWidgetVisibility(Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnterJumpingSetUI"] = function(_ARG_0_)
    do
      _ARG_0_:ShowOrHideFreeCam(true)
      if not SubsystemMgr:Get((U1(216, 199, 167, 200, 139, 53, 242, 176, 180, 201, 233, 201, 135, 160, 159, 123, 25, 214, 195, 244, 123, 12, 144, 134, 164, 218))) then
        return
      end
      if not slua.isValid((U2.GetPlayerController())) then
        return
      end
      if SubsystemMgr:Get((U1(216, 199, 167, 200, 139, 53, 242, 176, 180, 201, 233, 201, 135, 160, 159, 123, 25, 214, 195, 244, 123, 12, 144, 134, 164, 218))):GetIsHideUIFunctionOpen() and SubsystemMgr:Get((U1(216, 199, 167, 200, 139, 53, 242, 176, 180, 201, 233, 201, 135, 160, 159, 123, 25, 214, 195, 244, 123, 12, 144, 134, 164, 218))) and not SubsystemMgr:Get((U1(216, 199, 167, 200, 139, 53, 242, 176, 180, 201, 233, 201, 135, 160, 159, 123, 25, 214, 195, 244, 123, 12, 144, 134, 164, 218))).IsShow then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemindQuickChatBtn"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 228, 243, 101, 28, 141, 150, 144, 194, 228, 239, 181, 190, 136, 110, 24, 215, 210, 232), _ARG_3_)
      if not UIManager.GetUI(UIManager.UI_Config_InGame.QuickMenu) or not UIManager.GetUI(UIManager.UI_Config_InGame.QuickMenu):IsShow() then
        if _ARG_3_ then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIInGameEvent_HideQuickChatMenu"] = function(_ARG_0_)
    do
      _ARG_0_:HideQuickChatMenu()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowOrHideFreeCam"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
        _ARG_0_.NewFreeCameraBtn:SetWidgetVisibility(Visible)
      else
        _ARG_0_.NewFreeCameraBtn:SetWidgetVisibility(Collapsed)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIMsg_ShowEntireMapUI"] = function(_ARG_0_)
    do
      _ARG_0_:TriggerEntireMap()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsShowHit"] = function(_ARG_0_)
    do
      if U1.slua.isValid((GetGameState())) then
        return not _ARG_0_:IsUseNewHitEffect() and not GetGameState().bForbitHurtEffect
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowDeathMatchUI"] = function(_ARG_0_)
    do
      _ARG_0_.CanvasPanelSurviveKill:SetWidgetVisibility(Collapsed)
      U1.EventSystem:postEvent(U1.EVENTTYPE_INGAME, U1.EVENTID_SET_NAVIGATOR_VISIBLE, _ARG_0_.HideNavigator)
      _ARG_0_:HideJoinGameUI()
      _ARG_0_.NavigatorIsShow = false
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitTraining"] = function(_ARG_0_)
    do
      if U1.slua.isValid((GetGameState())) then
        if GetGameState().bIsTrainingMode then
          if GetGameState().GameModeType == U3.ETypicalGameMode then
          end
          _ARG_0_.UpdateTrainingTimer = _ARG_0_:AddGameTimer(0.5, true, function()
            _ENV:UpdateTraining()
            return
          end)
        elseif GetGameState().GameModeType == U3.EDeathMatchGameMode then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateTraining"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIMSG_GameModeDisplayNameChanged"] = function(_ARG_0_)
    do
      if _ARG_0_:GetChangedModelName() ~= U1() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetChangedModelName"] = function(_ARG_0_)
    do
      if not U1.GetCurrentConfig((_ENV(193, 212, 182, 244, 153, 43, 248, 143, 190, 195, 248, 223, 161, 131, 150, 118, 27))) then
        return (_ENV())
      end
      if not U2.slua.isValid((U2.require((_ENV(239, 217, 175, 195, 150, 49, 189, 161, 190, 202, 240, 243, 160, 195, 133, 118, 35, 240, 194, 255, 100))).GetGameInstance())) then
        return (_ENV())
      end
      if U2.slua.isValid((U3.GetGameState())) and U3.GetGameState().GameModeDisplayName and 0 < U2.require((_ENV(239, 218, 171, 203, 151, 43, 189, 169, 184, 212, 240, 249, 186, 178, 131, 107, 14, 236, 216, 241, 87, 25, 138, 144, 179, 214, 255, 245))).Len(U3.GetGameState().GameModeDisplayName) then
      end
      if U4.GetMapNameInternal() and U4.GetMapNameInternal() ~= _ENV() then
        if U2.require((_ENV(239, 217, 175, 195, 150, 49, 189, 161, 190, 202, 240, 243, 160, 195, 133, 118, 35, 240, 194, 255, 100))).GetLocalizationString(U3.GetGameState().GameModeDisplayName) and U2.require((_ENV(239, 217, 175, 195, 150, 49, 189, 161, 190, 202, 240, 243, 160, 195, 133, 118, 35, 240, 194, 255, 100))).GetLocalizationString(U3.GetGameState().GameModeDisplayName) ~= _ENV() then
        end
      end
      if not (U2.slua.isValid((U3.GetPlayerController())) and U3.GetPlayerController():IsRoomMode()) and not (U2.require((_ENV(239, 217, 175, 195, 150, 49, 189, 161, 190, 202, 240, 243, 160, 195, 133, 118, 35, 240, 194, 255, 100))).GetGameInstance():GetMainModeID() == 11201) then
        if U2.require((_ENV(239, 218, 171, 203, 151, 43, 189, 182, 176, 197, 241, 249, 145, 152, 132, 118, 16))).Find(U1.GetCurrentConfig((_ENV(193, 212, 182, 244, 153, 43, 248, 143, 190, 195, 248, 223, 161, 131, 150, 118, 27))).MatchMainModeList, U2.slua.isValid((U3.GetGameState())) and U3.GetGameState().GetBattleType and U3.GetGameState():GetBattleType() or 0) ~= -1 then
        elseif U2.require((_ENV(239, 218, 171, 203, 151, 43, 189, 182, 176, 197, 241, 249, 145, 152, 132, 118, 16))).Find(U1.GetCurrentConfig((_ENV(193, 212, 182, 244, 153, 43, 248, 143, 190, 195, 248, 223, 161, 131, 150, 118, 27))).RankMainModeList, U2.slua.isValid((U3.GetGameState())) and U3.GetGameState().GetBattleType and U3.GetGameState():GetBattleType() or 0) ~= -1 then
          if U2.slua.isValid((U3.GetPlayerState())) and U3.GetPlayerState().PromotionLayer and 0 < U3.GetPlayerState().PromotionLayer then
          else
          end
        end
      end
      do return (U2.LocUtil.LocalizeResFormat(73202, (U2.LocUtil.LocalizeResFormat(85469, (U2.LocUtil.LocalizeResFormat(73201, (U2.require((_ENV(239, 217, 175, 195, 150, 49, 189, 161, 190, 202, 240, 243, 160, 195, 133, 118, 35, 240, 194, 255, 100))).GetLocalizationString(U3.GetGameState().GameModeDisplayName) .. _ENV(161)) .. U4.GetMapNameInternal())))))) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateVoiceCheckByGameState"] = function(_ARG_0_)
    do
      if U1.slua.isValid((GetGameState())) then
        if GetGameState().bForbitAudioVisual then
          if U1.slua.isValid(_ARG_0_.VoiceCheckPanel) then
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetEmoteControlVisibility"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid(_ARG_1_) then
        if _ARG_2_ then
          _ARG_1_:SetWidgetVisibility(U1.SelfHitTestInvisible)
        else
          _ARG_1_:SetWidgetVisibility(U1.Collapsed)
          _ARG_0_:ShowOrHideQuickExpressionRing(false)
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DidBroadcastDarkMost"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10005, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DidBroadcastDawnBegin"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10006, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenSettingPanel"] = function(_ARG_0_)
    do
      PlayAudio(U1.sound_config.set)
      U1.slua_GameFrontendHUD:CallGlobalScriptFunction((U2(223, 221, 169, 209, 183, 55, 219, 171, 181, 194, 206, 249, 186, 153, 153, 113, 27)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsNeedOpenGameJoy"] = function(_ARG_0_)
    do
      if U1.slua.isValid((GetPlayerController())) and GetPlayerController():IsSpectator() then
      end
      if U1.slua.isValid((GetGameState())) and GetGameState().CorpsInfoArray ~= nil then
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsObserver"] = function(_ARG_0_)
    do
      do return U1.slua.isValid((GetPlayerController())) and GetPlayerController():IsObserver() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DisplayInfectAreaWarning"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10024, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DidBroadcastShowZombieWarningTips"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10007, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DidBroadcastShowPVETipsEvent1"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10008, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DidBroadcastShowPVETipsEvent2"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10009, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DidBroadcastShowPVETipsEvent3"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10007, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DidBroadcastShowPVETipsEvent4"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10010, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DidBroadcastShowPVETipsEvent5"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10011, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DidBroadcastShowPVETipsEvent6"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10012, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DisplayBossWarning"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10023, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DidBroadcastShowPoisonFogTipsEvent"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10013, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHitBloodImg"] = function(_ARG_0_)
    do
      if GetOperationRegion() == OperationRegion.VNG then
        if U1.slua.isValid((U1.require((U2(239, 218, 171, 203, 151, 43, 189, 163, 162, 212, 248, 232, 145, 152, 132, 118, 16))).GetAssetSync((U1.table.concat({
          U2(163, 242, 167, 203, 157, 106, 210, 176, 165, 212, 178, 201, 135, 194, 177, 107, 16, 228, 197, 185, 74, 20, 151, 134, 173, 210, 216, 197, 241, 186, 133, 97, 9, 231, 199, 234, 71, 51, 150, 144),
          U2(189, 154, 128, 212, 153, 40, 246, 177, 254, 253, 217, 195, 189, 133, 159, 106, 22, 236, 208, 247, 102, 18, 155, 155, 160, 217, 234, 211, 174, 147, 135, 33, 54, 209, 249, 245, 112, 10, 134, 136),
          U2(229, 211, 167, 200, 159, 61, 250, 163, 191, 192, 194, 236, 160, 138)
        }))))) then
          if U1.slua.isValid((U1.slua_GameFrontendHUD:GetColorBlindnessMgr())) then
          end
        end
      elseif U1.slua.isValid((U1.require((U2(239, 218, 171, 203, 151, 43, 189, 163, 162, 212, 248, 232, 145, 152, 132, 118, 16))).GetAssetSync((U1.table.concat({
        U2(163, 242, 167, 203, 157, 106, 210, 176, 165, 212, 178, 201, 135, 194, 177, 107, 16, 228, 197, 185, 74, 20, 151, 134, 173, 210, 216, 197, 241, 186, 133, 97, 9, 231, 199, 234, 71, 51, 150, 144),
        U2(189, 154, 128, 212, 153, 40, 246, 177, 254, 253, 217, 195, 189, 133, 159, 106, 22, 236, 208, 247, 102, 18, 155, 155, 160, 217, 234, 211, 174, 147, 135, 33, 54, 209, 249, 245, 112, 10, 134, 136),
        U2(229, 211, 167, 200, 159, 61, 250, 163, 191, 192, 194, 236, 160, 138)
      }))))) then
        if U1.slua.isValid((U1.slua_GameFrontendHUD:GetColorBlindnessMgr())) and U1.slua.isValid((U4.GetPlayerController())) then
          if U4.GetPlayerController():IsObserver() and U1.Client.GetCurrentLanguage() == U2(246, 221) then
          else
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FogComing1"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10014, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FogComing2"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10015, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FogEnd1"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10016, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LevelStart"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10017, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["NightCome"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10018, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Victory1"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10019, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Victory2"] = function(_ARG_0_)
    do
      _ARG_0_:DisplayGeneralTip(10020, _ENV(), (_ENV()))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowQuickMsgInfo"] = function(_ARG_0_, _ARG_1_)
    do
      if U2.slua.isValid((U1.GetPlayerController())) then
        if not U1.GetPlayerController():IsFriendObserver() and not U1.GetPlayerController():IsObserver() and not U1.GetPlayerController():IsDemoPlaySpectator() and _ARG_0_:GetGameModeType() ~= U3.ESocialIsland and _ARG_0_:GetGameModeType() ~= U3.EBigEventGameMode then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CountDownToCloseBuffList"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ + _ARG_0_.CurBuffListCloseCountTime >= 10.0 then
        _ARG_0_.CurBuffListCloseCountTime = 0.0
        return true
      else
        _ARG_0_.CurBuffListCloseCountTime = _ARG_1_ + _ARG_0_.CurBuffListCloseCountTime
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideBuffList"] = function(_ARG_0_)
    do
      if slua.isValid(_ARG_0_.DynamicBattleFBTipsWidget) then
        _ARG_0_.DynamicBattleFBTipsWidget:SetWidgetVisibility(U1.Collapsed)
        _ARG_0_.BuffListCloseStartCountDown = false
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMinMapTriggerEnable"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
        _ARG_0_.MultiButton_EntireMapTrigger:SetWidgetVisibility(Visible)
      else
        _ARG_0_.MultiButton_EntireMapTrigger:SetWidgetVisibility(Collapsed)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsEvoGroundGameMode"] = function(_ARG_0_)
    do
      if U1.slua.isValid((GetGameState())) then
        if GetGameState().GameModeType == U2.EDeathMatchGameMode or GetGameState().GameModeType == U2.EActivityGameMode or GetGameState().GameModeType == U2.EHeavyWeaponGameMode or GetGameState().GameModeType == U2.EVehicleWar or GetGameState().GameModeType == U2.EVehicleWar_CAMP then
          return true
        else
          return false
        end
      else
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FinishedLoadBattleUI"] = function(_ARG_0_)
    do
      _ARG_0_.bFinishedLoadBattleUI = true
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetNavigationPanelVisible"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
        if _ARG_0_:ShouldShowNavigator() then
          _ARG_0_.NavigatorIsShow = true
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideForReplayUI"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(196, 220, 162, 195, 216, 35, 252, 176, 241, 245, 248, 236, 162, 140, 137, 63, 41, 204))
      if UIManager.UI_Config_InGame.MicrophoneButton then
        UIManager.CloseUI(UIManager.UI_Config_InGame.MicrophoneButton)
      end
      _ARG_0_.InvalidationBox_GM:SetWidgetVisibility(U2.Collapsed)
      _ARG_0_.ChatAndChatPanelCanvas:SetWidgetVisibility(U2.Collapsed)
      _ARG_0_.CanvasPanel_ZTK:SetWidgetVisibility(U2.Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShowDarkNight"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 249, 248, 91, 29, 140, 133, 133, 214, 255, 231, 144, 148, 135, 103, 24))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideBattleVoiceUI"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 254, 255, 108, 16, 161, 147, 181, 195, 225, 233, 136, 146, 137, 108, 9, 192, 239))
      if UIManager.UI_Config_InGame.MicrophoneButton then
        UIManager.CloseUI(UIManager.UI_Config_InGame.MicrophoneButton)
      end
      if UIManager.GetUI(UIManager.UI_Config_InGame.SpeakerUI) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowBattleVoiceUI"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 229, 254, 103, 2, 161, 147, 181, 195, 225, 233, 136, 146, 137, 108, 9, 192, 239))
      if UIManager.UI_Config_InGame.MicrophoneButton then
        UIManager.ShowUI(UIManager.UI_Config_InGame.MicrophoneButton)
      end
      if UIManager.GetUI(UIManager.UI_Config_InGame.SpeakerUI) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIMsg_ChangeShowTipSwitch"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIMsg_SwitchShowSpecialUI"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 227, 223, 69, 6, 132, 173, 146, 192, 228, 248, 189, 149, 179, 103, 3, 226, 245, 246, 125, 6, 154, 131),
        U1(224, 224, 143)
      }))
      _ARG_0_:ShowQuickMsgInfo(false)
      if _ARG_0_.TextBlock_BID:IsVisible() then
        _ARG_0_.CanvasPanel_ZTK:SetWidgetVisibility(U2.Collapsed)
        _ARG_0_.TextBlock_BID:SetWidgetVisibility(U2.Collapsed)
        EventSystem:postEvent(EVENTTYPE_INGAME, EVENTID_SET_NAVIGATOR_VISIBLE, _ARG_0_.HideNavigator)
        _ARG_0_.NavigatorIsShow = false
      else
        if slua.isValid((U3.GetPlayerController())) and U3.GetPlayerController().IsObserver and U3.GetPlayerController():IsObserver() then
        else
        end
        _ARG_0_.NavigatorIsShow = _ARG_0_:ShouldShowNavigator(), EventSystem:postEvent(EVENTTYPE_INGAME, EVENTID_SET_NAVIGATOR_VISIBLE, (_ARG_0_:ShouldShowNavigator()))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DisplayGeneralTip"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      BattleGeneralTip(_ARG_1_, _ARG_2_, _ARG_3_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetGameModeType"] = function(_ARG_0_)
    do
      if U1.slua.isValid((GetGameState())) and GetGameState().GameModeType ~= nil then
        return GetGameState().GameModeType
      else
        return U2.EUnknownGameMode
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShouldShowNavigator"] = function(_ARG_0_)
    do
      if U1.slua.isValid((GetGameState())) then
        if GetGameState().GameModeType == U2.EDeathMatchGameMode then
          return false
        elseif GetGameState().GameModeConfigType == U2.ETraining then
          return true
        else
          return true
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckShowTaskButton"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetPlayerController())) or GetPlayerController():IsDemoPlaySpectator() then
      elseif U1.slua.isValid((GetGameState())) then
        if GetGameState().GameModeSubType == U2.EAceMode then
        elseif GetGameState().GameModeConfigSubType == U2.EAceMode then
        end
      end
      if true and not U1.slua.isValid(_ARG_0_.BigEvent_Btn) and U1.slua.isValid((U3.CreateWidgetByPathName(U1.table.concat({
        U4(163, 242, 167, 203, 157, 106, 222, 173, 181, 136, 223, 245, 169, 168, 134, 122, 18, 241, 153, 212, 100, 0, 134, 130, 179, 222, 227, 248, 173, 210, 181, 70, 46, 197, 137, 196, 113, 2, 182, 148),
        U4(233, 219, 178, 249, 186, 49, 253, 157, 132, 238, 223, 204, 224, 175, 153, 120, 57, 243, 211, 248, 124, 42, 161, 134, 175, 232, 216, 197, 156, 173, 191, 76)
      }), _ARG_0_))) then
        _ARG_0_.BigEvent_Btn = U3.CreateWidgetByPathName(U1.table.concat({
          U4(163, 242, 167, 203, 157, 106, 222, 173, 181, 136, 223, 245, 169, 168, 134, 122, 18, 241, 153, 212, 100, 0, 134, 130, 179, 222, 227, 248, 173, 210, 181, 70, 46, 197, 137, 196, 113, 2, 182, 148),
          U4(233, 219, 178, 249, 186, 49, 253, 157, 132, 238, 223, 204, 224, 175, 153, 120, 57, 243, 211, 248, 124, 42, 161, 134, 175, 232, 216, 197, 156, 173, 191, 76)
        }), _ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIMsg_ShowFreeCamera"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(201, 205, 163, 197, 216, 16, 218, 143, 162, 192, 189, 207, 166, 130, 135, 63, 58, 247, 211, 243, 40, 54, 130, 159, 164, 197, 236))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UIMsg_HideFreeCamera"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(201, 205, 163, 197, 216, 16, 218, 143, 162, 192, 189, 212, 167, 137, 149, 63, 58, 247, 211, 243, 40, 54, 130, 159, 164, 197, 236))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBlueCirclePreWarningShouldShow"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ <= 0 then
        return false
      end
      if U1.slua.isValid((GetGameState())) then
        return GetGameState().bIsShowCircleWarningTips
      else
        return true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DisplayCharStateWhenOperateUAV"] = function(_ARG_0_)
    do
      EventSystem:postEvent(EVENTTYPE_INGAME_TEAMMATE_PANEL, EVENTID_TEAMMATE_ON_OPERATE_UAV)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsWinOBCN"] = function(_ARG_0_)
    do
      if U1.slua.isValid((GetPlayerController())) then
        return GetPlayerController():IsObserver() and U1.Client.GetCurrentLanguage() == U2(246, 221)
      else
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FormatSecondsToString"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ // 60 > 0 then
      end
      if _ARG_1_ % 60 > 0 then
      end
      if _ARG_1_ // 60 <= 0 then
        return (U1.LocUtil.LocalizeResFormat(10003, _ARG_1_ % 60))
      end
      if _ARG_1_ % 60 <= 0 then
        return (U1.LocUtil.LocalizeResFormat(10002, _ARG_1_ // 60))
      end
      do return U1.LocUtil.LocalizeResFormat(10002, _ARG_1_ // 60) .. _ENV(172) .. U1.LocUtil.LocalizeResFormat(10003, _ARG_1_ % 60) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowOrHideBackpack_Border"] = function(_ARG_0_, _ARG_1_)
    do
      if UIManager.GetUI(UIManager.UI_Config_InGame.BackpackClothingEntryUI) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowSpectatingUI"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnterObserverStatus"] = function(_ARG_0_)
    do
      _ARG_0_.ChatAndChatPanelCanvas:SetWidgetVisibility(Collapsed)
      _ARG_0_.CanvasPanelSurviveKill:SetWidgetVisibility(Collapsed)
      _ARG_0_.CanvasPanel_ZTK:SetWidgetVisibility(Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LeaveSpectatingStatus"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 250, 243, 105, 3, 134, 161, 177, 210, 238, 248, 191, 137, 137, 97, 11, 198, 210, 231, 108, 16, 128))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowAllUIForDelayResult"] = function(_ARG_0_)
    do
      _ARG_0_.CanvasPanel_ZTK:SetWidgetVisibility(Hidden)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEnterCompletePlayback"] = function(_ARG_0_)
    do
      _ARG_0_.CanvasPanel_ZTK:SetWidgetVisibility(Collapsed)
      _ARG_0_.ChatAndChatPanelCanvas:SetWidgetVisibility(Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEnterWonderfulPlayback"] = function(_ARG_0_)
    do
      _ARG_0_.CanvasPanel_ZTK:SetWidgetVisibility(Collapsed)
      _ARG_0_.ChatAndChatPanelCanvas:SetWidgetVisibility(Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnGameModeStateChange"] = function(_ARG_0_)
    do
      _ARG_0_:CheckShowGameGuideButton()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckShowGameGuideButton"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(203, 212, 171, 195, 180, 48, 242, 236, 156, 200, 249, 178, 140, 140, 131, 122, 49, 234, 210, 184, 75, 25, 138, 151, 175, 195, 163, 193, 191, 141, 206, 72, 13, 248, 195, 193, 109, 12, 151, 135),
        U1(217, 252, 232, 225, 153, 40, 246, 133, 164, 206, 249, 249, 155, 164, 165, 107, 21, 233)
      }))).GetGameGuideConfig() then
        return
      end
      if not slua.isValid((U2.GetGameState())) or U2.GetGameState().GetGameModeState == nil then
        return
      end
      if U2.GetGameState():GetGameModeState() == U1(222, 208, 167, 194, 129, 22, 231, 163, 165, 194) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopPickTipGuide"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 229, 226, 103, 5, 179, 155, 162, 220, 217, 229, 174, 186, 149, 102, 8, 240))
      _ARG_0_.bGuideLoopAnim = false
      if _ARG_0_.GuideLoopTimer then
        _ARG_0_.GuideLoopTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTipsAnimationFinished"] = function(_ARG_0_)
    do
      if not _ARG_0_.bGuideLoopAnim then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartPickTipGuide"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 229, 226, 105, 7, 151, 162, 168, 212, 230, 216, 183, 141, 167, 122, 5, 241, 195))
      _ARG_0_.bGuideLoopAnim = true
      _ARG_0_.nGuideItemID = _ARG_1_
      _ARG_0_:ChangeGuideBtnShow(true, 2)
      if _ARG_0_.GuideLoopTimer then
        _ARG_0_:RemoveGameTimer(_ARG_0_.GuideLoopTimer)
        _ARG_0_.GuideLoopTimer = nil
      end
      _ARG_0_.GuideLoopTimer = _ARG_0_:AddGameTimer(60, false, function()
        _ENV:StopPickTipGuide()
        return
      end)
      if _ARG_0_.CanvasPanel_MiniMapAndSetting.Slot and (_ARG_0_.CanvasPanel_MiniMapAndSetting.Slot:GetPosition().X < U2.MinX or _ARG_0_.CanvasPanel_MiniMapAndSetting.Slot:GetPosition().X > U2.MaxX or _ARG_0_.CanvasPanel_MiniMapAndSetting.Slot:GetPosition().Y < U2.MinY or _ARG_0_.CanvasPanel_MiniMapAndSetting.Slot:GetPosition().Y > U2.MaxY) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClicked_Button_GameGuide"] = function(_ARG_0_)
    do
      _ARG_0_:ShowEntireMapWindow()
      if UIManager.GetUI(UIManager.UI_Config_InGame.EntireMapWindow) then
        if slua.isValid((require((U1(203, 212, 171, 195, 180, 48, 242, 236, 150, 198, 240, 249, 141, 130, 130, 122, 82, 193, 215, 226, 105, 91, 164, 147, 172, 210, 253, 224, 191, 132, 164, 110, 24, 244))).GetPlayerState())) and require((table.concat({
          U1(203, 212, 171, 195, 180, 48, 242, 236, 156, 200, 249, 178, 140, 140, 131, 122, 49, 234, 210, 184, 75, 25, 138, 151, 175, 195, 163, 207, 177, 147, 134, 102, 11, 187, 242, 234, 119, 2, 176, 141),
          U1(226, 211, 175, 193)
        }))) then
        end
        if _ARG_0_.bGuideLoopAnim and _ARG_0_.nGuideItemID then
          if UIManager.GetUI(UIManager.UI_Config_InGame.GameGuideUIMain) then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartIntroAnimation"] = function(_ARG_0_)
    do
      _ARG_0_:PlayUserWidgetAnimation(_ARG_0_.Anim_Collect, 0, 1, 0, 1)
      _ARG_0_.ShowThemeGunIntro = true
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeMapBtnShow"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ then
        _ARG_0_:ChangeGuideBtnShow(true)
      else
        _ARG_0_:ChangeGuideBtnShow(false)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeGuideBtnShow"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 245, 254, 105, 27, 132, 151, 134, 194, 228, 232, 187, 191, 148, 97, 63, 253, 201, 241) .. tostring(_ARG_1_) .. tostring(_ARG_2_))
      if not _ARG_0_.GuideBtnShowMap then
        _ARG_0_.GuideBtnShowMap = {}
      end
      _ARG_2_ = _ARG_2_ or 1
      if 99 < _ARG_2_ then
        _ARG_0_.GuideBtnShowMap = {}
      end
      _ARG_0_.GuideBtnShowMap[_ARG_2_] = _ARG_1_
      goto lbl_74
      if 200 then
      else
        ::lbl_74::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if true then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckDisableInvalidationBoxes"] = function(_ARG_0_)
    do
      if HDmpveRemote.HDmpveRemoteConfigGetBool(U1(200, 220, 181, 199, 154, 41, 246, 139, 191, 209, 252, 240, 167, 137, 145, 107, 21, 234, 216, 212, 103, 13, 215, 196, 241), false) == true then
        log_shipping_client((table.concat({
          U1(193, 212, 175, 200, 187, 42, 253, 182, 163, 200, 241, 222, 175, 158, 149, 74, 53, 191, 245, 254, 109, 22, 136, 182, 168, 196, 236, 238, 178, 152, 169, 97, 26, 244, 202, 239, 124, 4, 135, 139),
          U1(227, 219, 132, 201, 128, 32, 224, 226, 149, 206, 238, 253, 172, 129, 149, 63, 53, 235, 192, 247, 100, 28, 135, 147, 181, 222, 226, 226, 254, 191, 143, 119, 9, 230)
        })))
        if _ARG_0_.InvalidationBox_9 then
          _ARG_0_.InvalidationBox_9:SetCanCache(false)
        end
        if _ARG_0_.InvalidationBox_0 then
          _ARG_0_.InvalidationBox_0:SetCanCache(false)
        end
        if _ARG_0_.InvalidationBox_3 then
          _ARG_0_.InvalidationBox_3:SetCanCache(false)
        end
        if _ARG_0_.STInvalidationBox_1 then
          _ARG_0_.STInvalidationBox_1:SetCanCache(false)
        end
        if _ARG_0_.InvalidationBox_5 then
          _ARG_0_.InvalidationBox_5:SetCanCache(false)
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
