do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(189, 76, 145, 143, 182)))(require((table.concat({
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 189, 75, 33, 69, 51),
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(172, 14, 179, 142, 160, 1, 54, 31, 189, 235, 187, 18, 97, 11, 75, 101, 92, 82, 225, 191, 80)
}))), nil, {
  ["ctor"] = function(_ARG_0_)
    do
      _ARG_0_.bBinaryDataLoadFail = false
      _ARG_0_.LoadedBinaryData = nil
      _ARG_0_.LoadedInstanceTree = nil
      _ARG_0_.LoadedGameParameter = nil
      _ARG_0_.LoadedCodeData = nil
      _ARG_0_.LoadedLuaCodeInfoMap = nil
      _ARG_0_.CurBinaryBaseVersion = 10000
      _ARG_0_.PreUpgradeBinaryData = nil
      _ARG_0_.TestUGCModMetaData = nil
      _ARG_0_.EditorBindTemplateMetaData = nil
      _ARG_0_.StandaloneMetaData = nil
      _ARG_0_.ServerBinaryDataLoaded = false
      _ARG_0_.ClientBinaryDataPreLoaded = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveDoPostInit"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(157, 82, 149, 157, 177, 9, 52, 19, 137, 231, 152, 18, 125, 19, 104, 97, 90, 113, 205, 173, 91, 49, 85, 35, 169, 164, 180, 6, 124, 31, 85, 102, 91, 68, 255, 140, 74, 51, 86, 31),
        U1(176, 73, 132)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ManagerInitializeCompleteInit"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(157, 82, 149, 157, 177, 9, 52, 19, 137, 231, 152, 18, 125, 19, 104, 97, 90, 113, 205, 173, 91, 49, 85, 35, 169, 164, 171, 2, 113, 27, 91, 117, 76, 73, 254, 181, 81, 41, 67, 58),
        U1(183, 90, 149, 191, 170, 13, 50, 26, 174, 250, 147, 58, 97, 3, 88)
      }))
      if not _ARG_0_:HasAuthority() then
        _ARG_0_:ClientPreLoadBinaryData()
      else
        _ARG_0_:ServerLoadBinaryData()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveOnPostSetLuaEventBridgeInstance"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(157, 82, 149, 157, 177, 9, 52, 19, 137, 231, 152, 18, 125, 19, 104, 97, 90, 113, 205, 173, 91, 49, 85, 35, 169, 164, 180, 6, 124, 31, 85, 102, 91, 79, 254, 140, 74, 51, 86, 5),
        U1(187, 84, 188, 137, 164, 37, 52, 19, 165, 250, 180, 1, 102, 14, 75, 101, 103, 126, 243, 184, 84, 62, 81, 35)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerLoadBinaryData"] = function(_ARG_0_)
    do
      if _ARG_0_:HasAuthority() and _ARG_0_.ServerBinaryDataLoaded == false then
        if CGameMode and CGameMode.bIsCreativeWoW then
        end
        if EVENTID_MATCH_UPDATE_STATUS_MATCHING_OR_NOT and _ARG_0_:GetStandAloneModData() > 0 then
        end
        if IsEditor and false then
          if _ARG_0_:IsStandalone() then
          else
          end
        end
        if require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 197, 168, 76, 44, 75, 34),
          U1(167, 14, 179, 142, 160, 1, 54, 31, 189, 235, 187, 63, 91, 24, 77, 105, 64, 121, 238, 171, 113, 49, 70, 39, 142, 234, 143, 15)
        }))).GetMLTrainingModID() then
          if require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 197, 168, 76, 44, 75, 34),
            U1(167, 14, 179, 142, 160, 1, 54, 31, 189, 235, 187, 63, 91, 24, 77, 105, 64, 121, 238, 171, 113, 49, 70, 39, 142, 234, 143, 15)
          }))).LoadUGCModDataFromLocal((require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 197, 168, 76, 44, 75, 34),
            U1(167, 14, 179, 142, 160, 1, 54, 31, 189, 235, 187, 63, 91, 24, 77, 105, 64, 121, 238, 171, 113, 49, 70, 39, 142, 234, 143, 15)
          }))).GetMLTrainingModID())) then
          else
          end
        end
        _ARG_0_.ServerBinaryDataLoaded = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ProcessCreativeWoWData"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetStandAloneModData"] = function(_ARG_0_)
    do
      if ModuleManager == nil then
        return 0, nil
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch) then
        return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetStandAloneData()
      end
      do return 0, nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StandaloneServerLoadBinaryData"] = function(_ARG_0_)
    do
      if _ARG_0_:IsStandalone() then
        if 0 < _ARG_0_:GetStandAloneModData() then
          if CDataTable.GetTableData(U1(139, 103, 179, 168, 160, 13, 50, 26, 170, 250, 147, 55, 110, 30, 77, 67, 65, 126, 230, 165, 82), _ARG_0_:GetStandAloneModData()) then
            if _ARG_0_:GetStandAloneModData() == nil and slua.LuaArchiverDecode(LuaStateWrapper, (import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).LoadFileToArrayByFullPath((import((U1(141, 116, 181, 132, 177, 18, 35, 52, 167, 251, 147, 3, 125, 3, 66, 116, 104, 101, 238, 175, 65, 57, 93, 40, 151, 247, 132, 17, 126, 8, 69))).ProjectContentDir() .. U1(138, 69, 157, 140, 169, 1, 54, 19, 184, 161, 163, 52, 76, 69, 120, 101, 67, 96, 236, 173, 65, 53, 118, 39, 175, 255, 201)) .. CDataTable.GetTableData(U1(139, 103, 179, 168, 160, 13, 50, 26, 170, 250, 147, 55, 110, 30, 77, 67, 65, 126, 230, 165, 82), _ARG_0_:GetStandAloneModData()).InitialMeta))) then
              ;({
                base = {}
              }).setting, ({
                base = {}
              }).base.version = slua.LuaArchiverDecode(LuaStateWrapper, (import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).LoadFileToArrayByFullPath((import((U1(141, 116, 181, 132, 177, 18, 35, 52, 167, 251, 147, 3, 125, 3, 66, 116, 104, 101, 238, 175, 65, 57, 93, 40, 151, 247, 132, 17, 126, 8, 69))).ProjectContentDir() .. U1(138, 69, 157, 140, 169, 1, 54, 19, 184, 161, 163, 52, 76, 69, 120, 101, 67, 96, 236, 173, 65, 53, 118, 39, 175, 255, 201)) .. CDataTable.GetTableData(U1(139, 103, 179, 168, 160, 13, 50, 26, 170, 250, 147, 55, 110, 30, 77, 67, 65, 126, 230, 165, 82), _ARG_0_:GetStandAloneModData()).InitialMeta))), slua.LuaArchiverDecode(LuaStateWrapper, (import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).LoadFileToArrayByFullPath((import((U1(141, 116, 181, 132, 177, 18, 35, 52, 167, 251, 147, 3, 125, 3, 66, 116, 104, 101, 238, 175, 65, 57, 93, 40, 151, 247, 132, 17, 126, 8, 69))).ProjectContentDir() .. U1(138, 69, 157, 140, 169, 1, 54, 19, 184, 161, 163, 52, 76, 69, 120, 101, 67, 96, 236, 173, 65, 53, 118, 39, 175, 255, 201)) .. CDataTable.GetTableData(U1(139, 103, 179, 168, 160, 13, 50, 26, 170, 250, 147, 55, 110, 30, 77, 67, 65, 126, 230, 165, 82), _ARG_0_:GetStandAloneModData()).InitialMeta))).version_temp
            end
          else
          end
          if import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).LoadFileToArrayByFullPath((import((U1(141, 116, 181, 132, 177, 18, 35, 52, 167, 251, 147, 3, 125, 3, 66, 116, 104, 101, 238, 175, 65, 57, 93, 40, 151, 247, 132, 17, 126, 8, 69))).ProjectContentDir() .. U1(138, 69, 157, 140, 169, 1, 54, 19, 184, 161, 163, 52, 76, 69, 120, 101, 67, 96, 236, 173, 65, 53, 118, 39, 175, 255, 201)) .. CDataTable.GetTableData(U1(139, 103, 179, 168, 160, 13, 50, 26, 170, 250, 147, 55, 110, 30, 77, 67, 65, 126, 230, 165, 82), _ARG_0_:GetStandAloneModData()).InitialBin) == nil then
          end
          if {
            base = {}
          } == nil then
          end
          _ARG_0_.StandaloneMetaData = {}
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientPreLoadBinaryData"] = function(_ARG_0_)
    do
      if not _ARG_0_:HasAuthority() and _ARG_0_.ClientBinaryDataPreLoaded ~= true then
        if CGameState and CGameState.bIsCreativeWoW then
          return
        end
        _ARG_0_.ClientBinaryDataPreLoaded = true
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBinaryDataLoadFailTag"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(157, 82, 149, 157, 177, 9, 52, 19, 137, 231, 152, 18, 125, 19, 104, 97, 90, 113, 205, 173, 91, 49, 85, 35, 169, 164, 181, 6, 107, 56, 85, 126, 95, 114, 233, 152, 68, 52, 67, 26),
        U1(177, 65, 148, 186, 164, 9, 46, 34, 170, 233)
      }))
      _ARG_0_.bBinaryDataLoadFail = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBinaryDataLoadFailTag"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(157, 82, 149, 157, 177, 9, 52, 19, 137, 231, 152, 18, 125, 19, 104, 97, 90, 113, 205, 173, 91, 49, 85, 35, 169, 164, 161, 6, 107, 56, 85, 126, 95, 114, 233, 152, 68, 52, 67, 26),
        U1(177, 65, 148, 186, 164, 9, 46, 34, 170, 233, 214, 17, 77, 3, 66, 97, 92, 105, 196, 173, 65, 49, 126, 41, 186, 250, 160, 2, 118, 22, 6)
      }) .. tostring(_ARG_0_.bBinaryDataLoadFail))
      do return _ARG_0_.bBinaryDataLoadFail end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSkipLoadBinaryData"] = function(_ARG_0_)
    do
      _ARG_0_.LoadedInstanceTree = {}
      _ARG_0_.LoadedGameParameter = {}
      _ARG_0_.TestUGCModMetaData = {}
      _ARG_0_.LoadedCodeData = {}
      _ARG_0_.LoadedPresetData = {}
      _ARG_0_:_PostBinaryDataLoadedEvent()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLoadModBinaryData"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(157, 82, 149, 157, 177, 9, 52, 19, 137, 231, 152, 18, 125, 19, 104, 97, 90, 113, 205, 173, 91, 49, 85, 35, 169, 164, 169, 13, 83, 21, 93, 116, 115, 111, 244, 158, 76, 46, 67, 36),
        U1(167, 100, 145, 136, 164)
      }))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LoadModBinaryData"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_3_ == nil then
        _ARG_3_ = true
      end
      if _ARG_2_.base ~= nil then
      end
      if _ARG_2_.base.version == nil then
      end
      if _ARG_2_.setting ~= nil then
      end
      do return _ARG_0_:LoadBinaryDataPre(_ARG_1_, _ARG_2_, 10000, _ARG_2_.setting.DevVersion, _ARG_3_, _ARG_4_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LoadBinaryDataPre"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if _ARG_5_ == nil then
        _ARG_5_ = true
      end
      if import((U1(141, 116, 181, 132, 177, 18, 35, 49, 170, 227, 147, 3, 99, 11, 85, 83, 90, 113, 244, 165, 86, 35))) then
        if not import((U1(141, 116, 181, 132, 177, 18, 35, 49, 170, 227, 147, 3, 99, 11, 85, 83, 90, 113, 244, 165, 86, 35))).IsShipping() and _ARG_4_ then
          _ARG_1_ = U2.LoadDevVersionBin(_ARG_1_, _ARG_4_, _ARG_3_)
        end
      end
      if _ARG_5_ ~= false and not _ARG_0_:HasAuthority() and IsEditor and type(_ARG_1_) == U1(173, 84, 130, 149, 171, 7) and (ModuleManager and ModuleManager.LobbyModuleConfig and ModuleManager.LobbyModuleConfig.LogicUGCLobbyBin and ModuleManager.GetModule(ModuleManager and ModuleManager.LobbyModuleConfig and ModuleManager.LobbyModuleConfig.LogicUGCLobbyBin) or nil) and (_ARG_0_.TestUGCModMetaData and _ARG_0_.TestUGCModMetaData.base and _ARG_0_.TestUGCModMetaData.base.mod_id) ~= nil then
      end
      if _ARG_5_ ~= false then
        _ARG_0_.PreUpgradeBinaryData = _ARG_1_
      end
      if not require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 112, 48, 101, 36),
        U1(191, 68, 149, 169, 177, 9, 46, 31, 191, 247, 216, 48, 125, 15, 77, 116, 71, 102, 229, 142, 92, 62, 83, 52, 162, 218, 135, 23, 126, 47, 76, 87, 76, 97, 244, 185, 112, 52, 75, 58),
        U1(183, 84, 137)
      }))).BinaryDataVersionUpgrade(_ARG_1_, _ARG_3_, nil, _ARG_5_) then
      end
      if _ARG_5_ ~= false then
        _ARG_0_.CurBinaryBaseVersion = _ARG_3_
      end
      do return _ARG_0_:LoadBinaryData(require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 112, 48, 101, 36),
        U1(191, 68, 149, 169, 177, 9, 46, 31, 191, 247, 216, 48, 125, 15, 77, 116, 71, 102, 229, 142, 92, 62, 83, 52, 162, 218, 135, 23, 126, 47, 76, 87, 76, 97, 244, 185, 112, 52, 75, 58),
        U1(183, 84, 137)
      }))).BinaryDataVersionUpgrade(_ARG_1_, _ARG_3_, nil, _ARG_5_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LoadDevVersionBin"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(157, 82, 149, 157, 177, 9, 52, 19, 137, 231, 152, 18, 125, 19, 104, 97, 90, 113, 205, 173, 91, 49, 85, 35, 169, 164, 170, 12, 126, 30, 120, 117, 72, 86, 245, 174, 86, 41, 77, 56),
        U1(156, 73, 158, 220, 129, 5, 52, 32, 174, 252, 133, 26, 96, 4, 22)
      }) .. tostring(_ARG_1_) .. U1(254, 114, 149, 144, 160, 1, 49, 19, 157, 235, 132, 73) .. tostring(_ARG_2_))
      if xpcall(U2.DevPbBufferUpToLatest, U2.UGCPbErrorMessageHandler, _ARG_0_, _ARG_1_, _ARG_2_) and xpcall(U2.DevPbBufferUpToLatest, U2.UGCPbErrorMessageHandler, _ARG_0_, _ARG_1_, _ARG_2_) and #xpcall(U2.DevPbBufferUpToLatest, U2.UGCPbErrorMessageHandler, _ARG_0_, _ARG_1_, _ARG_2_) > 0 then
        _ARG_0_ = xpcall(U2.DevPbBufferUpToLatest, U2.UGCPbErrorMessageHandler, _ARG_0_, _ARG_1_, _ARG_2_)
      end
      do return _ARG_0_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LoadBinaryData"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_1_ ~= nil then
        if xpcall(U2.PbBufferUnPackToBinary, U2.UGCPbErrorMessageHandler, _ARG_1_) then
          if _ARG_4_ ~= nil and require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 103, 41, 76, 55),
            U1(172, 89, 177, 143, 182, 5, 54, 34, 164, 225, 154)
          }))).UnPackBinaryAsset(_ARG_4_) ~= nil then
          end
        else
        end
        if string.find(_ARG_1_, U1(151, 78, 131, 136, 164, 14, 33, 19, 159, 252, 147, 22), 1) or string.find(_ARG_1_, U1(153, 65, 157, 153, 149, 1, 48, 23, 166, 235, 130, 22, 125, 46, 77, 116, 79), 1) then
          if xpcall(require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
            U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
          }))).StrToTable, U2.UGCPbErrorMessageHandler, require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
            U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
          }))), _ARG_1_) and xpcall(require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
            U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
          }))).StrToTable, U2.UGCPbErrorMessageHandler, require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
            U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
          }))), _ARG_1_) ~= nil then
          else
          end
        end
      end
      if xpcall(require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
        U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
      }))).StrToTable, U2.UGCPbErrorMessageHandler, require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
        U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
      }))), _ARG_1_) then
        if xpcall(require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
          U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
        }))).StrToTable, U2.UGCPbErrorMessageHandler, require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
          U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
        }))), _ARG_1_).InstanceTree then
        else
        end
        if xpcall(require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
          U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
        }))).StrToTable, U2.UGCPbErrorMessageHandler, require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
          U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
        }))), _ARG_1_).GameParameterData then
        else
        end
      else
      end
      if _ARG_2_ ~= false then
        if not false then
        end
        _ARG_0_.LoadedLuaCodeInfoMap, _ARG_0_.LoadedPresetData, _ARG_0_.LoadedCodeData, _ARG_0_.LoadedGameParameter, _ARG_0_.LoadedInstanceTree, _ARG_0_.LoadedBinaryData = {}, {}, {}, {}, {}, {}, false, {}, {}, {}, {}, {}, require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 112, 48, 101, 36),
          U1(191, 68, 149, 169, 177, 9, 46, 31, 191, 247, 216, 48, 125, 15, 77, 116, 71, 102, 229, 143, 64, 35, 70, 41, 182, 203, 175, 42, 113, 9, 72, 113, 80, 99, 245, 137, 85, 39, 80, 55),
          U1(186, 69, 165, 136, 172, 12, 43, 2, 178)
        }))), _ARG_0_:SetBinaryDataLoadFailTag()
        if _ARG_1_ ~= nil then
        end
      end
      do return false, {}, {}, {}, {}, {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SortGroupChildren"] = function(_ARG_0_, _ARG_1_)
    do
      goto lbl_23
      if nil and (nil).ObjectGroup and (nil).ObjectGroup.Children and (nil).ObjectGroup.Children.overrides then
      end
      ::lbl_23::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CheckTransformAndFix"] = function(_ARG_0_, _ARG_1_)
    do
      if CGameState and CGameState:GetInitializeGameType() == U1.CreativeModeGameType_Game then
        return _ARG_1_
      end
      goto lbl_47
      if nil and (nil).ObjectGroup and (nil).ObjectGroup.Children and (nil).ObjectGroup.Children.overrides then
        goto lbl_37
        ::lbl_37::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if (nil).Transform == nil then
      end
      ::lbl_47::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if 0 < #{} then
        goto lbl_271
        if ({
          [nil] = (nil).InstanceId
        })[U2(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)] then
          if _ARG_1_[({
            [nil] = (nil).InstanceId
          })[U2(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)]] and _ARG_1_[({
            [nil] = (nil).InstanceId
          })[U2(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)]].Transform then
            DeepCopy(_ARG_1_[({
              [nil] = (nil).InstanceId
            })[U2(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)]].Transform).Location.X = DeepCopy(_ARG_1_[({
              [nil] = (nil).InstanceId
            })[U2(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)]].Transform).Location.X + 0 % 10 * 100
            DeepCopy(_ARG_1_[({
              [nil] = (nil).InstanceId
            })[U2(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)]].Transform).Location, DeepCopy(_ARG_1_[({
              [nil] = (nil).InstanceId
            })[U2(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)]].Transform).Location.Y = DeepCopy(_ARG_1_[({
              [nil] = (nil).InstanceId
            })[U2(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)]].Transform).Location, DeepCopy(_ARG_1_[({
              [nil] = (nil).InstanceId
            })[U2(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)]].Transform).Location.Y + math.ceil(0 / 10) * 100
            _ARG_1_[U2(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)].Transform = DeepCopy(_ARG_1_[({
              [nil] = (nil).InstanceId
            })[U2(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)]].Transform)
          end
        else
          _ARG_1_[U2(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)].Transform = require((table.concat({
            U2(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
            U2(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
          }))):MakeLuaTransform()
        end
        ::lbl_271::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CheckLoadType"] = function(_ARG_0_, _ARG_1_)
    do
      goto lbl_76
      if 20 then
        if (20).AssetId == 3101066 and (20).GroupManipulator then
          goto lbl_65
          if _ARG_1_[153] and _ARG_1_[153].ObjectGroup and _ARG_1_[153].ObjectGroup.Children then
            goto lbl_63
            ::lbl_63::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
          ::lbl_65::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if (20).LoadType == import((U1(155, 99, 130, 153, 164, 20, 43, 0, 174, 195, 153, 23, 106, 38, 67, 97, 74, 68, 249, 188, 80))).CreativeModeLoadType_Manual then
        end
      end
      ::lbl_76::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_88
      if not ({
        [74] = true
      })[(20).InstanceId] then
        ;(20).LoadType = import((U1(155, 99, 130, 153, 164, 20, 43, 0, 174, 195, 153, 23, 106, 38, 67, 97, 74, 68, 249, 188, 80))).CreativeModeLoadType_Auto
      end
      ::lbl_88::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PostBinaryDataLoadedEvent"] = function(_ARG_0_)
    do
      if _ARG_0_:HasAuthority() then
        EventSystem:postEvent(EVENTTYPE_INGAME_CREATIVE_MODE, EVENTID_INTERMEDIATE_DATA_LOADED)
        EventSystem:postEvent(EVENTTYPE_INGAME_CREATIVE_MODE, EVENTID_INTERMEDIATE_POST_DATA_LOADED)
      else
        EventSystem:postEvent(EVENTTYPE_INGAME_CREATIVE_MODE, EVENTID_CLIENT_BINARY_DATA_PRE_LOADED)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PostClassifyBinaryDataLoadedEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_:HasAuthority() then
        EventSystem:postEvent(EVENTTYPE_INGAME_CREATIVE_MODE, EVENTID_CLASSIFY_BINARY_DATA_LOADED, _ARG_1_, _ARG_2_)
        EventSystem:postEvent(EVENTTYPE_INGAME_CREATIVE_MODE, EVENTID_CLASSIFY_BINARY_POST_DATA_LOADED, _ARG_1_, _ARG_2_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LoadDefaultTestData"] = function(_ARG_0_)
    do
      _ARG_0_.LoadedPresetData = {}
      _ARG_0_.LoadedBinaryData = {}
      _ARG_0_.CurBinaryBaseVersion = require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 102, 47, 76, 48),
        U1(183, 71, 222, 191, 183, 5, 35, 2, 162, 248, 147, 49, 102, 4, 77, 114, 87, 84, 225, 184, 84, 6, 87, 52, 168, 247, 137, 13, 92, 21, 82, 118, 87, 103)
      }))).CurVersion
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LoadSubGameTestData"] = function(_ARG_0_)
    do
      if slua.isValid(CGameState) and CGameState.EditorBindTemplateID ~= nil then
      end
      if CGameState.EditorBindTemplateID == 0 then
        return false
      end
      if CDataTable.GetTableData(U1(139, 103, 179, 168, 160, 13, 50, 26, 170, 250, 147, 55, 110, 30, 77, 67, 65, 126, 230, 165, 82), CGameState.EditorBindTemplateID) ~= nil and CDataTable.GetTableData(U1(139, 103, 179, 168, 160, 13, 50, 26, 170, 250, 147, 55, 110, 30, 77, 67, 65, 126, 230, 165, 82), CGameState.EditorBindTemplateID).InitialBin ~= U1() and CDataTable.GetTableData(U1(139, 103, 179, 168, 160, 13, 50, 26, 170, 250, 147, 55, 110, 30, 77, 67, 65, 126, 230, 165, 82), CGameState.EditorBindTemplateID).InitialMeta ~= U1() then
        return true
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LoadTestData"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(157, 82, 149, 157, 177, 9, 52, 19, 137, 231, 152, 18, 125, 19, 104, 97, 90, 113, 205, 173, 91, 49, 85, 35, 169, 164, 170, 12, 126, 30, 104, 117, 77, 116, 212, 189, 81, 33))
      if _ARG_0_:GetLoadedInstanceTree() ~= nil then
        return
      end
      if not _ARG_0_:GetLocalTemplateBinPath() and _ARG_0_:LoadSubGameTestData() then
        return
      end
      if not _ARG_0_:LoadTestDataFromBin() and not _ARG_0_:LoadTestDataFromTxt() then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LoadTestDataFromTxt"] = function(_ARG_0_)
    do
      if IsEditor ~= true then
        return
      end
      if require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
        U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
      }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))) ~= nil then
        _ARG_0_.LoadedCodeData = {}
        _ARG_0_.LoadedPresetData = {}
        _ARG_0_.LoadedLuaCodeInfoMap = {}
        if require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
          U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
        }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read() == nil or not string.find(require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
          U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
        }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read(), U1(183, 78, 131, 136, 164, 14, 33, 19, 159, 252, 147, 22, 75, 11, 88, 97, 125, 100, 242), 1) then
          return false
        else
          while require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
            U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
          }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read() do
            if nil == nil then
            elseif string.find(require((table.concat({
              U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
              U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
            }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read(), U1(183, 78, 131, 136, 164, 14, 33, 19, 159, 252, 147, 22, 75, 11, 88, 97, 125, 100, 242), 1) then
              _ARG_0_.LoadedInstanceTree = require((table.concat({
                U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
                U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
              }))):StrToTable((require((table.concat({
                U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
                U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
              }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read()))
            elseif string.find(require((table.concat({
              U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
              U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
            }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read(), U1(185, 65, 157, 153, 149, 1, 48, 23, 166, 235, 130, 22, 125, 46, 77, 116, 79, 67, 244, 190), 1) then
              _ARG_0_.LoadedGameParameter = require((table.concat({
                U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
                U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
              }))):StrToTable((require((table.concat({
                U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
                U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
              }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read()))
            elseif string.find(require((table.concat({
              U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
              U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
            }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read(), U1(179, 69, 132, 157, 129, 1, 54, 23, 152, 250, 132), 1) then
              _ARG_0_.TestUGCModMetaData = require((table.concat({
                U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
                U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
              }))):StrToTable((require((table.concat({
                U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
                U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
              }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read()))
              if _ARG_0_.TestUGCModMetaData.base == nil then
                _ARG_0_.TestUGCModMetaData.base = require((table.concat({
                  U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 211, 179, 75, 38, 75, 49),
                  U1(240, 103, 145, 145, 160, 48, 35, 4, 170, 227, 147, 7, 106, 24, 2, 67, 92, 117, 225, 184, 92, 38, 87, 11, 180, 250, 131, 36, 126, 23, 89, 64, 95, 114, 241, 177, 64, 52, 71, 36),
                  U1(157, 70, 151)
                }))).GetTestUGCModMetaData().base
              end
              if _ARG_0_.TestUGCModMetaData.setting == nil then
                _ARG_0_.TestUGCModMetaData.setting = require((table.concat({
                  U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 211, 179, 75, 38, 75, 49),
                  U1(240, 103, 145, 145, 160, 48, 35, 4, 170, 227, 147, 7, 106, 24, 2, 67, 92, 117, 225, 184, 92, 38, 87, 11, 180, 250, 131, 36, 126, 23, 89, 64, 95, 114, 241, 177, 64, 52, 71, 36),
                  U1(157, 70, 151)
                }))).GetTestUGCModMetaData().setting
              end
            elseif string.find(require((table.concat({
              U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
              U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
            }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read(), U1(157, 79, 148, 153, 129, 1, 54, 23, 152, 250, 132), 1) then
              if U2.base64decode((require((table.concat({
                U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
                U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
              }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read())) and U2.PbBufferUnPackToBinary((U2.base64decode((require((table.concat({
                U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
                U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
              }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read())))) then
                _ARG_0_.LoadedCodeData = U2.PbBufferUnPackToBinary((U2.base64decode((require((table.concat({
                  U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
                  U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
                }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read())))).CodeData
              end
            elseif string.find(require((table.concat({
              U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
              U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
            }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read(), U1(146, 85, 145, 191, 170, 4, 39, 63, 165, 232, 153, 62, 110, 26, 127, 116, 92), 1) then
              _ARG_0_.LoadedLuaCodeInfoMap = require((table.concat({
                U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
                U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
              }))):StrToTable((require((table.concat({
                U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
                U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
              }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read()))
            elseif string.find(require((table.concat({
              U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
              U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
            }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read(), U1(145, 84, 152, 153, 183, 34, 43, 24, 170, 252, 143, 55, 110, 30, 77, 83, 90, 98), 1) and U2.base64decode((require((table.concat({
              U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
              U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
            }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read())) and U2.PbBufferUnPackToBinary((U2.base64decode((require((table.concat({
              U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
              U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
            }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read())))) ~= nil and U2.PbBufferUnPackToBinary((U2.base64decode((require((table.concat({
              U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
              U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
            }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read())))).PresetData ~= nil then
              _ARG_0_.LoadedBinaryData, _ARG_0_.LoadedPresetData = U2.PbBufferUnPackToBinary((U2.base64decode((require((table.concat({
                U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
                U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
              }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read())))), U2.PbBufferUnPackToBinary((U2.base64decode((require((table.concat({
                U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
                U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
              }))):DevIOOpen(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).ProjectSavedDir() .. U1(241, 98, 153, 146, 164, 18, 59, 50, 170, 250, 151, 93, 123, 18, 88), (U1(172))):read())))).PresetData
            end
          end
        end
      else
        return false
      end
      if _ARG_0_.TestUGCModMetaData.base ~= nil then
      end
      if _ARG_0_.TestUGCModMetaData.base.version == nil then
      end
      _ARG_0_.CurBinaryBaseVersion = require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 102, 47, 76, 48),
        U1(183, 71, 222, 191, 183, 5, 35, 2, 162, 248, 147, 49, 102, 4, 77, 114, 87, 84, 225, 184, 84, 6, 87, 52, 168, 247, 137, 13, 92, 21, 82, 118, 87, 103)
      }))).CurVersion
      if require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 102, 47, 76, 48),
        U1(183, 71, 222, 191, 183, 5, 35, 2, 162, 248, 147, 49, 102, 4, 77, 114, 87, 84, 225, 184, 84, 6, 87, 52, 168, 247, 137, 13, 92, 21, 82, 118, 87, 103)
      }))).CurVersion ~= require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 102, 47, 76, 48),
        U1(183, 71, 222, 191, 183, 5, 35, 2, 162, 248, 147, 49, 102, 4, 77, 114, 87, 84, 225, 184, 84, 6, 87, 52, 168, 247, 137, 13, 92, 21, 82, 118, 87, 103)
      }))).CurVersion then
        goto lbl_937
        if false then
        elseif U1(183, 84, 137) == require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 102, 47, 76, 48),
          U1(183, 71, 222, 191, 183, 5, 35, 2, 162, 248, 147, 49, 102, 4, 77, 114, 87, 84, 225, 184, 84, 6, 87, 52, 168, 247, 137, 13, 92, 21, 82, 118, 87, 103)
        }))).CurVersion then
        end
        ::lbl_937::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if true then
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_.LoadedInstanceTree = require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 112, 48, 101, 36),
            U1(191, 68, 149, 169, 177, 9, 46, 31, 191, 247, 216, 48, 125, 15, 77, 116, 71, 102, 229, 142, 92, 62, 83, 52, 162, 218, 135, 23, 126, 47, 76, 87, 76, 97, 244, 185, 112, 52, 75, 58),
            U1(183, 84, 137)
          }))).UpGradeBinaryDataVersion({
            ["InstanceTree"] = require((U1(189, 79, 157, 145, 170, 14, 108, 2, 170, 236, 154, 22, 80, 31, 88, 105, 66))).CopyTable(_ARG_0_.LoadedInstanceTree),
            ["GameParameterData"] = require((U1(189, 79, 157, 145, 170, 14, 108, 2, 170, 236, 154, 22, 80, 31, 88, 105, 66))).CopyTable(_ARG_0_.LoadedGameParameter)
          }, require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 102, 47, 76, 48),
            U1(183, 71, 222, 191, 183, 5, 35, 2, 162, 248, 147, 49, 102, 4, 77, 114, 87, 84, 225, 184, 84, 6, 87, 52, 168, 247, 137, 13, 92, 21, 82, 118, 87, 103)
          }))).CurVersion, ({})[table.insert({}, U1(183, 84, 137))]).InstanceTree
          _ARG_0_.LoadedGameParameter = require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 112, 48, 101, 36),
            U1(191, 68, 149, 169, 177, 9, 46, 31, 191, 247, 216, 48, 125, 15, 77, 116, 71, 102, 229, 142, 92, 62, 83, 52, 162, 218, 135, 23, 126, 47, 76, 87, 76, 97, 244, 185, 112, 52, 75, 58),
            U1(183, 84, 137)
          }))).UpGradeBinaryDataVersion({
            ["InstanceTree"] = require((U1(189, 79, 157, 145, 170, 14, 108, 2, 170, 236, 154, 22, 80, 31, 88, 105, 66))).CopyTable(_ARG_0_.LoadedInstanceTree),
            ["GameParameterData"] = require((U1(189, 79, 157, 145, 170, 14, 108, 2, 170, 236, 154, 22, 80, 31, 88, 105, 66))).CopyTable(_ARG_0_.LoadedGameParameter)
          }, require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 102, 47, 76, 48),
            U1(183, 71, 222, 191, 183, 5, 35, 2, 162, 248, 147, 49, 102, 4, 77, 114, 87, 84, 225, 184, 84, 6, 87, 52, 168, 247, 137, 13, 92, 21, 82, 118, 87, 103)
          }))).CurVersion, ({})[table.insert({}, U1(183, 84, 137))]).GameParameterData
        else
        end
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLocalTemplateBinPath"] = function(_ARG_0_)
    do
      if not IsEditor then
        return
      end
      if not CDataTable.GetTableData(U1(139, 103, 179, 168, 160, 13, 50, 26, 170, 250, 147, 48, 96, 4, 74, 105, 73), CGameState.EditorBindTemplateID) then
        return
      end
      if not CDataTable.GetTableData(U1(156, 116, 189, 147, 161, 5), CDataTable.GetTableData(U1(139, 103, 179, 168, 160, 13, 50, 26, 170, 250, 147, 48, 96, 4, 74, 105, 73), CGameState.EditorBindTemplateID).SubModeID) then
        return
      end
      if require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
        U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
      }))):DevIOOpen((string.format(U1(251, 83, 223, 175, 170, 21, 48, 21, 174, 161, 142, 31, 124, 69, 88, 97, 76, 124, 229, 191, 106, 37, 85, 37, 244, 187, 149, 76, 124, 10, 99, 53, 77, 46, 242, 181, 75), import((U1(141, 116, 181, 132, 177, 18, 35, 52, 167, 251, 147, 3, 125, 3, 66, 116, 104, 101, 238, 175, 65, 57, 93, 40, 151, 247, 132, 17, 126, 8, 69))).ProjectContentDir():sub(1, #import((U1(141, 116, 181, 132, 177, 18, 35, 52, 167, 251, 147, 3, 125, 3, 66, 116, 104, 101, 238, 175, 65, 57, 93, 40, 151, 247, 132, 17, 126, 8, 69))).ProjectContentDir() - 9), CDataTable.GetTableData(U1(156, 116, 189, 147, 161, 5), CDataTable.GetTableData(U1(139, 103, 179, 168, 160, 13, 50, 26, 170, 250, 147, 48, 96, 4, 74, 105, 73), CGameState.EditorBindTemplateID).SubModeID).ModType, CDataTable.GetTableData(U1(156, 116, 189, 147, 161, 5), CDataTable.GetTableData(U1(139, 103, 179, 168, 160, 13, 50, 26, 170, 250, 147, 48, 96, 4, 74, 105, 73), CGameState.EditorBindTemplateID).SubModeID).ModType))) ~= nil then
        return (string.format(U1(251, 83, 223, 175, 170, 21, 48, 21, 174, 161, 142, 31, 124, 69, 88, 97, 76, 124, 229, 191, 106, 37, 85, 37, 244, 187, 149, 76, 124, 10, 99, 53, 77, 46, 242, 181, 75), import((U1(141, 116, 181, 132, 177, 18, 35, 52, 167, 251, 147, 3, 125, 3, 66, 116, 104, 101, 238, 175, 65, 57, 93, 40, 151, 247, 132, 17, 126, 8, 69))).ProjectContentDir():sub(1, #import((U1(141, 116, 181, 132, 177, 18, 35, 52, 167, 251, 147, 3, 125, 3, 66, 116, 104, 101, 238, 175, 65, 57, 93, 40, 151, 247, 132, 17, 126, 8, 69))).ProjectContentDir() - 9), CDataTable.GetTableData(U1(156, 116, 189, 147, 161, 5), CDataTable.GetTableData(U1(139, 103, 179, 168, 160, 13, 50, 26, 170, 250, 147, 48, 96, 4, 74, 105, 73), CGameState.EditorBindTemplateID).SubModeID).ModType, CDataTable.GetTableData(U1(156, 116, 189, 147, 161, 5), CDataTable.GetTableData(U1(139, 103, 179, 168, 160, 13, 50, 26, 170, 250, 147, 48, 96, 4, 74, 105, 73), CGameState.EditorBindTemplateID).SubModeID).ModType))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LoadTestDataFromBin"] = function(_ARG_0_)
    do
      if not IsEditor then
        return
      end
      _ARG_0_ = _ARG_0_
      if U1(183, 71, 222, 191, 183, 5, 35, 2, 162, 248, 147, 49, 102, 4, 77, 114, 87, 84, 225, 184, 84, 6, 87, 52, 168, 247, 137, 13, 92, 21, 82, 118, 87, 103) <= #require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 102, 47, 76, 48),
        U1(183, 71, 222, 191, 183, 5, 35, 2, 162, 248, 147, 49, 102, 4, 77, 114, 87, 84, 225, 184, 84, 6, 87, 52, 168, 247, 137, 13, 92, 21, 82, 118, 87, 103)
      }))).HistoricalVersion then
      else
      end
      if (function(_ARG_0_)
        do
          if require((table.concat({
            U2(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
            U2(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
          }))):DevIOOpen(string.format(U1, tostring(_ARG_0_)), (U2(172, 66))) then
            if require((table.concat({
              U2(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
              U2(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
            }))):DevIOOpen(string.format(U1, tostring(_ARG_0_)), (U2(172, 66))):read((require((table.concat({
              U2(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
              U2(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
            }))):DevIOOpen(string.format(U1, tostring(_ARG_0_)), (U2(172, 66))):seek((U2(187, 78, 148))))) == nil then
            end
          end
          do return (U2()) end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)(require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 102, 47, 76, 48),
        U1(183, 71, 222, 191, 183, 5, 35, 2, 162, 248, 147, 49, 102, 4, 77, 114, 87, 84, 225, 184, 84, 6, 87, 52, 168, 247, 137, 13, 92, 21, 82, 118, 87, 103)
      }))).CurVersion) ~= nil then
        if not _ARG_0_:LoadTestMetaData() and _ARG_0_.TestUGCModMetaData == nil then
          _ARG_0_.TestUGCModMetaData = require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 211, 179, 75, 38, 75, 49),
            U1(240, 103, 145, 145, 160, 48, 35, 4, 170, 227, 147, 7, 106, 24, 2, 67, 92, 117, 225, 184, 92, 38, 87, 11, 180, 250, 131, 36, 126, 23, 89, 64, 95, 114, 241, 177, 64, 52, 71, 36),
            U1(157, 70, 151)
          }))).GetTestUGCModMetaData()
        end
        if _ARG_0_.TestUGCModMetaData ~= nil and _ARG_0_.TestUGCModMetaData.setting ~= nil and _ARG_0_.TestUGCModMetaData.setting.DevVersion ~= nil then
        end
        if (function()
          if require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
            U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
          }))):DevIOOpen(U2, (U1(172, 66))) then
          end
          do return (require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
            U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
          }))):DevIOOpen(U2, (U1(172, 66))):read((require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
            U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
          }))):DevIOOpen(U2, (U1(172, 66))):seek((U1(187, 78, 148)))))) end
          return
        end)() ~= nil and (slua.LuaArchiverDecode(LuaStateWrapper, ((function()
          if require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
            U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
          }))):DevIOOpen(U2, (U1(172, 66))) then
          end
          do return (require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
            U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
          }))):DevIOOpen(U2, (U1(172, 66))):read((require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
            U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
          }))):DevIOOpen(U2, (U1(172, 66))):seek((U1(187, 78, 148)))))) end
          return
        end)())) or nil) ~= nil then
          if _ARG_0_.TestUGCModMetaData ~= nil and (slua.LuaArchiverDecode(LuaStateWrapper, ((function()
            if require((table.concat({
              U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
              U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
            }))):DevIOOpen(U2, (U1(172, 66))) then
            end
            do return (require((table.concat({
              U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
              U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
            }))):DevIOOpen(U2, (U1(172, 66))):read((require((table.concat({
              U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
              U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
            }))):DevIOOpen(U2, (U1(172, 66))):seek((U1(187, 78, 148)))))) end
            return
          end)())) or nil).global_setting ~= nil then
          end
          if (slua.LuaArchiverDecode(LuaStateWrapper, ((function()
            if require((table.concat({
              U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
              U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
            }))):DevIOOpen(U2, (U1(172, 66))) then
            end
            do return (require((table.concat({
              U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
              U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
            }))):DevIOOpen(U2, (U1(172, 66))):read((require((table.concat({
              U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
              U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
            }))):DevIOOpen(U2, (U1(172, 66))):seek((U1(187, 78, 148)))))) end
            return
          end)())) or nil).global_bin ~= nil then
          end
        end
        return true
      end
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LoadUGCModMetaData"] = function(_ARG_0_)
    do
      if not IsEditor then
        return nil
      end
      if _ARG_0_:GetLocalTemplateBinPath() ~= nil then
      end
      if require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
        U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
      }))):DevIOOpen(_ARG_0_:GetLocalTemplateBinPath():sub(1, #_ARG_0_:GetLocalTemplateBinPath() - 3) .. U1(179, 69, 132, 157), (U1(172))) then
      end
      if require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
        U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
      }))):DevIOOpen(_ARG_0_:GetLocalTemplateBinPath():sub(1, #_ARG_0_:GetLocalTemplateBinPath() - 3) .. U1(179, 69, 132, 157), (U1(172))):read((U1(244, 65, 156, 144))) ~= nil then
        if pcall(require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
          U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
        }))).StrToTable, require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
          U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
        }))), (require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
          U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
        }))):DevIOOpen(_ARG_0_:GetLocalTemplateBinPath():sub(1, #_ARG_0_:GetLocalTemplateBinPath() - 3) .. U1(179, 69, 132, 157), (U1(172))):read((U1(244, 65, 156, 144))))) and pcall(require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
          U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
        }))).StrToTable, require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
          U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
        }))), (require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
          U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
        }))):DevIOOpen(_ARG_0_:GetLocalTemplateBinPath():sub(1, #_ARG_0_:GetLocalTemplateBinPath() - 3) .. U1(179, 69, 132, 157), (U1(172))):read((U1(244, 65, 156, 144))))) ~= nil then
          return pcall(require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
            U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
          }))).StrToTable, require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
            U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
          }))), (require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
            U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
          }))):DevIOOpen(_ARG_0_:GetLocalTemplateBinPath():sub(1, #_ARG_0_:GetLocalTemplateBinPath() - 3) .. U1(179, 69, 132, 157), (U1(172))):read((U1(244, 65, 156, 144)))))
        elseif slua.LuaArchiverDecode(LuaStateWrapper, (import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).LoadFileToArrayByFullPath(_ARG_0_:GetLocalTemplateBinPath():sub(1, #_ARG_0_:GetLocalTemplateBinPath() - 3) .. U1(179, 69, 132, 157)))) ~= nil then
          ;({
            base = {}
          }).base.version = slua.LuaArchiverDecode(LuaStateWrapper, (import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).LoadFileToArrayByFullPath(_ARG_0_:GetLocalTemplateBinPath():sub(1, #_ARG_0_:GetLocalTemplateBinPath() - 3) .. U1(179, 69, 132, 157)))).version_temp
          ;({
            base = {}
          }).setting, slua.LuaArchiverDecode(LuaStateWrapper, (import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).LoadFileToArrayByFullPath(_ARG_0_:GetLocalTemplateBinPath():sub(1, #_ARG_0_:GetLocalTemplateBinPath() - 3) .. U1(179, 69, 132, 157)))).version_temp = slua.LuaArchiverDecode(LuaStateWrapper, (import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).LoadFileToArrayByFullPath(_ARG_0_:GetLocalTemplateBinPath():sub(1, #_ARG_0_:GetLocalTemplateBinPath() - 3) .. U1(179, 69, 132, 157)))), nil
          return {
            base = {}
          }
        end
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LoadTestMetaData"] = function(_ARG_0_)
    do
      if _ARG_0_:LoadUGCModMetaData() ~= nil then
        _ARG_0_.TestUGCModMetaData = _ARG_0_:LoadUGCModMetaData()
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUGCModPublicInfo"] = function(_ARG_0_)
    do
      if ServerDataMgr == nil then
        if _ARG_0_:IsStandalone() and _ARG_0_:GetStandAloneModData() > 0 then
          return _ARG_0_.StandaloneMetaData
        end
        if IsEditor then
          if _ARG_0_.EditorBindTemplateMetaData ~= nil then
            return _ARG_0_.EditorBindTemplateMetaData
          end
          return _ARG_0_.TestUGCModMetaData
        end
        return nil
      else
        if ServerDataMgr:GetUGCModGlobalSetting() ~= nil then
          if ServerDataMgr:GetMergedUGCModPublicInfo() == nil then
            if ServerDataMgr:GetUGCModPublicInfo() == nil then
            else
            end
          end
          return (require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
            U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
          }))):DeepCopy((ServerDataMgr:GetUGCModPublicInfo())))
        end
        return ServerDataMgr:GetUGCModPublicInfo()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLoadedBinaryData"] = function(_ARG_0_)
    do
      do return _ARG_0_.LoadedBinaryData end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPreUpgradeBinaryData"] = function(_ARG_0_)
    do
      do return _ARG_0_.PreUpgradeBinaryData end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLoadedInstanceTree"] = function(_ARG_0_)
    do
      do return _ARG_0_.LoadedInstanceTree end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLoadedGameParameter"] = function(_ARG_0_)
    do
      do return _ARG_0_.LoadedGameParameter end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLoadedCodeData"] = function(_ARG_0_)
    do
      do return _ARG_0_.LoadedCodeData, _ARG_0_.LoadedLuaCodeInfoMap end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLoadedPresetData"] = function(_ARG_0_)
    do
      do return _ARG_0_.LoadedPresetData end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurBinaryBaseVersion"] = function(_ARG_0_)
    do
      do return _ARG_0_.CurBinaryBaseVersion end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LoadBinaryDataForPath"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_3_ == nil then
        _ARG_3_ = false
      end
      if _ARG_1_ ~= nil then
      end
      if _ARG_2_ ~= nil then
        if _G.IsEditor and require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
          U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
        }))):DevIOOpen(_ARG_2_, (U1(172))) then
          if require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
            U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
          }))):DevIOOpen(_ARG_2_, (U1(172))):read((U1(244, 65, 156, 144))) and pcall(require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
            U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
          }))).StrToTable, require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
            U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
          }))), require((table.concat({
            U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
            U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
          }))):DevIOOpen(_ARG_2_, (U1(172))):read((U1(244, 65, 156, 144))), true) then
          end
        end
        if pcall(require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
          U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
        }))).StrToTable, require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 21),
          U1(172, 69, 145, 136, 172, 22, 39, 59, 164, 234, 147, 38, 123, 3, 64, 105, 90, 105)
        }))), require((table.concat({
          U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 218, 131, 21, 49, 55, 89, 100, 95, 46, 211, 174, 64, 33, 86, 63),
          U1(168, 69, 189, 147, 161, 5, 6, 19, 189, 219, 130, 26, 99, 3, 88, 121)
        }))):DevIOOpen(_ARG_2_, (U1(172))):read((U1(244, 65, 156, 144))), true) == nil then
        end
        if slua.LuaArchiverDecode(LuaStateWrapper, (import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).LoadFileToArrayByFullPath(_ARG_2_))) then
          ;({
            base = {}
          }).setting, ({
            base = {}
          }).base.version = slua.LuaArchiverDecode(LuaStateWrapper, (import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).LoadFileToArrayByFullPath(_ARG_2_))), slua.LuaArchiverDecode(LuaStateWrapper, (import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).LoadFileToArrayByFullPath(_ARG_2_))).version_temp
        end
      end
      if import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).LoadFileToArrayByFullPath(_ARG_1_) == nil then
      end
      if {
        base = {}
      } == nil then
      end
      if _ARG_4_ ~= nil then
      end
      do return _ARG_0_:LoadModBinaryData(U1(), {}, _ARG_3_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LoadBinaryDataOnlyByVersion"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_1_ ~= nil then
      end
      if _ARG_2_ == nil then
        _ARG_2_ = 10000
      end
      do return _ARG_0_:LoadBinaryDataPre(import((U1(157, 82, 149, 157, 177, 9, 52, 19, 134, 225, 146, 22, 77, 6, 89, 101, 94, 98, 233, 162, 65, 28, 91, 36, 169, 255, 148, 26))).LoadFileToArrayByFullPath(_ARG_1_), nil, _ARG_2_, nil, false) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSaveBinaryData"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if _ARG_3_ == nil then
        _ARG_3_ = true
      end
      if _ARG_4_ == nil then
        _ARG_4_ = false
      end
      if GetInstanceManager() then
      elseif _ARG_0_:GetLoadedInstanceTree() ~= nil then
      else
      end
      if GetGameParameterManager() then
      elseif _ARG_0_:GetLoadedGameParameter() ~= nil then
      else
      end
      if GetCreativeLuaCodeManager() then
      else
        if _ARG_0_:GetLoadedCodeData() then
        else
        end
        if _ARG_0_:GetLoadedCodeData() then
        else
        end
      end
      if SubsystemMgr:Get((U1(157, 82, 149, 157, 177, 9, 52, 19, 152, 237, 132, 26, 127, 30, 127, 117, 76, 99, 249, 191, 65, 53, 95))) then
        if SubsystemMgr:Get((U1(157, 82, 149, 157, 177, 9, 52, 19, 152, 237, 132, 26, 127, 30, 127, 117, 76, 99, 249, 191, 65, 53, 95))):GetScriptData() then
        else
        end
      elseif _ARG_0_.LoadedBinaryData and _ARG_0_.LoadedBinaryData.ScriptData then
      else
      end
      if GetCreativeActorDataManager() ~= nil then
      else
        if _ARG_0_.LoadedBinaryData ~= nil and _ARG_0_.LoadedBinaryData.ActorInfoTree ~= nil then
        else
        end
        if _ARG_0_.LoadedBinaryData ~= nil and _ARG_0_.LoadedBinaryData.ComponentInfoTree ~= nil then
        else
        end
      end
      if GetCreativeUMGInfoManager() ~= nil then
      elseif _ARG_0_.LoadedBinaryData ~= nil and _ARG_0_.LoadedBinaryData.UMGInfoMap ~= nil then
      else
      end
      if _ARG_3_ then
      end
      require((U1(189, 79, 157, 145, 170, 14, 108, 2, 170, 236, 154, 22, 80, 31, 88, 105, 66))).CopyTable({
        ["InstanceTree"] = GetInstanceManager():GetInstanceTreeData(true),
        ["InstanceTree"] = _ARG_0_:GetLoadedInstanceTree(),
        ["InstanceTree"] = {},
        ["GameParameterData"] = GetGameParameterManager():GetGameParameterData(true),
        ["GameParameterData"] = _ARG_0_:GetLoadedGameParameter(),
        ["GameParameterData"] = {},
        ["CodeData"] = GetCreativeLuaCodeManager():GetAllCodeData(true)
      }).BinaryVersion = require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 102, 47, 76, 48),
        U1(183, 71, 222, 191, 183, 5, 35, 2, 162, 248, 147, 49, 102, 4, 77, 114, 87, 84, 225, 184, 84, 6, 87, 52, 168, 247, 137, 13, 92, 21, 82, 118, 87, 103)
      }))).CurVersion
      do return require((U1(189, 79, 157, 145, 170, 14, 108, 2, 170, 236, 154, 22, 80, 31, 88, 105, 66))).CopyTable({
        ["InstanceTree"] = GetInstanceManager():GetInstanceTreeData(true),
        ["InstanceTree"] = _ARG_0_:GetLoadedInstanceTree(),
        ["InstanceTree"] = {},
        ["GameParameterData"] = GetGameParameterManager():GetGameParameterData(true),
        ["GameParameterData"] = _ARG_0_:GetLoadedGameParameter(),
        ["GameParameterData"] = {},
        ["CodeData"] = GetCreativeLuaCodeManager():GetAllCodeData(true)
      }), require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 217, 135, 14, 122, 10, 80, 113, 71, 46, 221, 185, 81, 33, 12, 5),
        U1(191, 86, 149, 177, 170, 4, 23, 2, 162, 226, 159, 7, 118)
      }))).WriteInModInformation(_ARG_1_.setting, require((U1(189, 79, 157, 145, 170, 14, 108, 2, 170, 236, 154, 22, 80, 31, 88, 105, 66))).CopyTable({
        ["InstanceTree"] = GetInstanceManager():GetInstanceTreeData(true),
        ["InstanceTree"] = _ARG_0_:GetLoadedInstanceTree(),
        ["InstanceTree"] = {},
        ["GameParameterData"] = GetGameParameterManager():GetGameParameterData(true),
        ["GameParameterData"] = _ARG_0_:GetLoadedGameParameter(),
        ["GameParameterData"] = {},
        ["CodeData"] = GetCreativeLuaCodeManager():GetAllCodeData(true)
      }), _ARG_2_, _ARG_4_, _ARG_5_) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientPreLoadTestData"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(157, 82, 149, 157, 177, 9, 52, 19, 137, 231, 152, 18, 125, 19, 104, 97, 90, 113, 205, 173, 91, 49, 85, 35, 169, 164, 165, 15, 118, 31, 82, 100, 110, 114, 245, 144, 74, 33, 70, 2),
        U1(187, 83, 132, 184, 164, 20, 35)
      }))
      if _ARG_0_:GetLoadedInstanceTree() ~= nil then
        return
      end
      if _ARG_0_:LoadSubGameTestData() then
        return
      end
      if not _ARG_0_:LoadTestDataFromBin() then
        if _ARG_0_:LoadTestDataFromTxt() then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSaveGlobalSettingAndBinTable"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return require((U1(189, 79, 157, 145, 170, 14, 108, 35, 140, 205, 216, 52, 99, 5, 78, 97, 66, 82, 233, 162, 96, 36, 91, 42, 178, 234, 159))).GetSaveGlobalSettingAndBinTable(_ARG_1_, _ARG_2_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MergeGlobalSetting"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return require((U1(189, 79, 157, 145, 170, 14, 108, 35, 140, 205, 216, 52, 99, 5, 78, 97, 66, 82, 233, 162, 96, 36, 91, 42, 178, 234, 159))).MergeGlobalSetting(_ARG_1_, _ARG_2_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MergeGlobalBinTable"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return require((U1(189, 79, 157, 145, 170, 14, 108, 35, 140, 205, 216, 52, 99, 5, 78, 97, 66, 82, 233, 162, 96, 36, 91, 42, 178, 234, 159))).MergeGlobalBinTable(_ARG_1_, _ARG_2_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CategoryFlag"] = {
    Scene = (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(173, 67, 149, 146, 160),
    CustomUI = (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(189, 85, 131, 136, 170, 13, 55, 31),
    LuaScript = (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(178, 85, 145, 143, 166, 18, 43, 6, 191),
    Blockly = (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(188, 76, 159, 159, 174, 12, 59),
    Other = (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(177, 84, 152, 153, 183),
    All = (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(191, 76, 156)
  },
  ["CategoryTypeEnumToFlag"] = {
    [1] = ({
      Scene = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(173, 67, 149, 146, 160),
      CustomUI = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(189, 85, 131, 136, 170, 13, 55, 31),
      LuaScript = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(178, 85, 145, 143, 166, 18, 43, 6, 191),
      Blockly = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(188, 76, 159, 159, 174, 12, 59),
      Other = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(177, 84, 152, 153, 183),
      All = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(191, 76, 156)
    }).All,
    [2] = ({
      Scene = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(173, 67, 149, 146, 160),
      CustomUI = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(189, 85, 131, 136, 170, 13, 55, 31),
      LuaScript = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(178, 85, 145, 143, 166, 18, 43, 6, 191),
      Blockly = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(188, 76, 159, 159, 174, 12, 59),
      Other = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(177, 84, 152, 153, 183),
      All = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(191, 76, 156)
    }).Scene,
    [3] = ({
      Scene = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(173, 67, 149, 146, 160),
      CustomUI = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(189, 85, 131, 136, 170, 13, 55, 31),
      LuaScript = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(178, 85, 145, 143, 166, 18, 43, 6, 191),
      Blockly = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(188, 76, 159, 159, 174, 12, 59),
      Other = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(177, 84, 152, 153, 183),
      All = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(191, 76, 156)
    }).CustomUI,
    [4] = ({
      Scene = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(173, 67, 149, 146, 160),
      CustomUI = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(189, 85, 131, 136, 170, 13, 55, 31),
      LuaScript = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(178, 85, 145, 143, 166, 18, 43, 6, 191),
      Blockly = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(188, 76, 159, 159, 174, 12, 59),
      Other = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(177, 84, 152, 153, 183),
      All = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(191, 76, 156)
    }).LuaScript,
    [5] = ({
      Scene = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(173, 67, 149, 146, 160),
      CustomUI = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(189, 85, 131, 136, 170, 13, 55, 31),
      LuaScript = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(178, 85, 145, 143, 166, 18, 43, 6, 191),
      Blockly = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(188, 76, 159, 159, 174, 12, 59),
      Other = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(177, 84, 152, 153, 183),
      All = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(191, 76, 156)
    }).Blockly,
    [6] = ({
      Scene = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(173, 67, 149, 146, 160),
      CustomUI = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(189, 85, 131, 136, 170, 13, 55, 31),
      LuaScript = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(178, 85, 145, 143, 166, 18, 43, 6, 191),
      Blockly = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(188, 76, 159, 159, 174, 12, 59),
      Other = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(177, 84, 152, 153, 183),
      All = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(191, 76, 156)
    }).Other
  },
  ["NormalizeCategoryToFlagStr"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) == U1(173, 84, 130, 149, 171, 7) then
        return _ARG_1_
      end
      if type(_ARG_1_) == U1(176, 85, 157, 158, 160, 18) then
        return U2[_ARG_1_] or U1()
      end
      if type(_ARG_1_) == U1(170, 65, 146, 144, 160) then
        goto lbl_91
        if type(144) == U1(176, 85, 157, 158, 160, 18) then
          if U2[144] then
          end
        elseif type(144) == U1(173, 84, 130, 149, 171, 7) then
        end
        ::lbl_91::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        return table.concat({}, (U1(242)))
      end
      do return (U1()) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LoadBinaryDataByCategory"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if require((U1(189, 79, 157, 145, 170, 14, 108, 3, 191, 231, 154, 26, 123, 19))).IsReleaseVersion() then
        if not ((GetGameParameterManager and GetGameParameterManager() or nil) and (GetGameParameterManager and GetGameParameterManager() or nil):GetGameParameter((U1(137, 79, 130, 151, 146, 8, 43, 2, 174, 226, 159, 0, 123))).Value or nil) then
          return
        elseif not (GetGameParameterManager and GetGameParameterManager() or nil) and (GetGameParameterManager and GetGameParameterManager() or nil):GetGameParameter((U1(137, 79, 130, 151, 146, 8, 43, 2, 174, 226, 159, 0, 123))).Value or nil.editor_export then
          return
        end
      end
      _ARG_1_ = string.gsub(_ARG_1_, U1(212), (U1()))
      _ARG_1_ = string.gsub(_ARG_1_, U1(211), (U1()))
      if import((U1(141, 67, 130, 149, 181, 20, 10, 19, 167, 254, 147, 1, 76, 6, 69, 101, 64, 100))).LoadFileToArray(_ARG_1_ .. U1(240, 66, 153, 146)) == nil then
        return
      end
      if xpcall(U2.PbBufferUnPackToBinary, U2.UGCPbErrorMessageHandler, import((U1(141, 67, 130, 149, 181, 20, 10, 19, 167, 254, 147, 1, 76, 6, 69, 101, 64, 100))).LoadFileToArray(_ARG_1_ .. U1(240, 66, 153, 146)), require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 102, 47, 76, 48),
        U1(183, 71, 222, 191, 183, 5, 35, 2, 162, 248, 147, 49, 102, 4, 77, 114, 87, 84, 225, 184, 84, 6, 87, 52, 168, 247, 137, 13, 92, 21, 82, 118, 87, 103)
      }))).CurVersion) == nil then
        return
      end
      if not xpcall(require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 102, 50, 71, 55),
        U1(170, 73, 134, 153, 136, 15, 38, 19, 155, 236, 163, 7, 102, 6, 69, 116, 87)
      }))).BinaryPackToPbBuffer, require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 102, 50, 71, 55),
        U1(170, 73, 134, 153, 136, 15, 38, 19, 155, 236, 163, 7, 102, 6, 69, 116, 87)
      }))).UGCPbErrorMessageHandler, xpcall(U2.PbBufferUnPackToBinary, U2.UGCPbErrorMessageHandler, import((U1(141, 67, 130, 149, 181, 20, 10, 19, 167, 254, 147, 1, 76, 6, 69, 101, 64, 100))).LoadFileToArray(_ARG_1_ .. U1(240, 66, 153, 146)), require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 102, 47, 76, 48),
        U1(183, 71, 222, 191, 183, 5, 35, 2, 162, 248, 147, 49, 102, 4, 77, 114, 87, 84, 225, 184, 84, 6, 87, 52, 168, 247, 137, 13, 92, 21, 82, 118, 87, 103)
      }))).CurVersion)) or xpcall(require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 102, 50, 71, 55),
        U1(170, 73, 134, 153, 136, 15, 38, 19, 155, 236, 163, 7, 102, 6, 69, 116, 87)
      }))).BinaryPackToPbBuffer, require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 102, 50, 71, 55),
        U1(170, 73, 134, 153, 136, 15, 38, 19, 155, 236, 163, 7, 102, 6, 69, 116, 87)
      }))).UGCPbErrorMessageHandler, xpcall(U2.PbBufferUnPackToBinary, U2.UGCPbErrorMessageHandler, import((U1(141, 67, 130, 149, 181, 20, 10, 19, 167, 254, 147, 1, 76, 6, 69, 101, 64, 100))).LoadFileToArray(_ARG_1_ .. U1(240, 66, 153, 146)), require((table.concat({
        U1(153, 65, 157, 153, 137, 21, 35, 88, 134, 225, 146, 93, 76, 24, 73, 97, 90, 121, 246, 169, 119, 49, 65, 35, 245, 220, 143, 13, 126, 8, 69, 84, 95, 116, 241, 242, 102, 47, 76, 48),
        U1(183, 71, 222, 191, 183, 5, 35, 2, 162, 248, 147, 49, 102, 4, 77, 114, 87, 84, 225, 184, 84, 6, 87, 52, 168, 247, 137, 13, 92, 21, 82, 118, 87, 103)
      }))).CurVersion)) == nil then
        return
      end
      if not slua.isValid((require((U1(153, 65, 157, 153, 137, 21, 35, 88, 140, 239, 155, 22, 76, 5, 94, 101, 0, 84, 225, 184, 84, 126, 117, 39, 182, 251, 150, 15, 126, 3, 120, 113, 74, 97))).GetPlayerController())) then
        return
      end
      if U3(_ARG_3_)[U5.All] then
      else
        goto lbl_1243
        ::lbl_1243::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if require((U1(153, 65, 157, 153, 137, 21, 35, 88, 140, 239, 155, 22, 76, 5, 94, 101, 0, 84, 225, 184, 84, 126, 117, 39, 182, 251, 150, 15, 126, 3, 120, 113, 74, 97))).GetPlayerController().CreativeInstanceDataPullFeature ~= nil then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SnapshotOldCustomAssetKeyMapping"] = function(_ARG_0_)
    do
      if (GetGameParameterManager and GetGameParameterManager() or nil) == nil then
        return nil
      end
      if (GetGameParameterManager and GetGameParameterManager() or nil):GetGameParameter((U1(151, 78, 183, 157, 168, 5, 1, 3, 184, 250, 153, 30, 78, 25, 95, 101, 90, 91, 229, 181, 120, 49, 66, 54, 178, 240, 129))) == nil or type((GetGameParameterManager and GetGameParameterManager() or nil):GetGameParameter((U1(151, 78, 183, 157, 168, 5, 1, 3, 184, 250, 153, 30, 78, 25, 95, 101, 90, 91, 229, 181, 120, 49, 66, 54, 178, 240, 129))).Value) ~= U1(170, 65, 146, 144, 160) then
        return nil
      end
      goto lbl_66
      ::lbl_66::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {
        [146] = 144
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GMMergeAndMountCustomAssetKeyMapping"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if type(_ARG_2_) ~= U1(170, 65, 146, 144, 160) then
        return
      end
      goto lbl_48
      if type(144) == U1(170, 65, 146, 144, 160) and (144).InGameCustomAssetKeyMapping ~= nil and type((144).InGameCustomAssetKeyMapping.Value) == U1(170, 65, 146, 144, 160) then
      else
        ::lbl_48::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if (144).InGameCustomAssetKeyMapping.Value == nil then
        if type(_ARG_1_) == U1(170, 65, 146, 144, 160) and next(_ARG_1_) ~= nil and (GetGameParameterManager and GetGameParameterManager() or nil) ~= nil then
        end
        return
      end
      if type(_ARG_1_) == U1(170, 65, 146, 144, 160) then
        goto lbl_130
        ::lbl_130::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      goto lbl_137
      ::lbl_137::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if CustomAssetMgr == nil or CustomAssetMgr.MountCustomAsset == nil then
        return
      end
      goto lbl_395
      if U1(177, 84, 208, 157, 179, 1, 43, 26, 170, 236, 154, 22) ~= nil and U1(177, 84, 208, 157, 179, 1, 43, 26, 170, 236, 154, 22) ~= U1() then
        if CustomAssetMgr:MountCustomAsset(U1(177, 84, 208, 157, 179, 1, 43, 26, 170, 236, 154, 22)) == 0 then
        else
        end
      end
      ::lbl_395::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if bWriteLog and (0 < 0 + 1 or 0 < 0 + 1) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DSClearBinaryDataByCategory"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:IsDedicatedServer() then
        print(bWriteLog and table.concat({
          U1(157, 82, 149, 157, 177, 9, 52, 19, 137, 231, 152, 18, 125, 19, 104, 97, 90, 113, 205, 173, 91, 49, 85, 35, 169, 164, 162, 48, 92, 22, 89, 113, 76, 66, 249, 178, 68, 50, 91, 18),
          U1(191, 84, 145, 190, 188, 35, 35, 2, 174, 233, 153, 1, 118, 80, 12, 115, 69, 121, 240, 188, 80, 52, 30, 102, 181, 241, 146, 67, 112, 20, 28, 116, 91, 100, 249, 191, 68, 52, 71, 50),
          U1(254, 83, 149, 142, 179, 5, 48)
        }))
        return
      end
      if not (U3((U2(_ARG_1_))).all == true) and not (U3((U2(_ARG_1_))).all == true or U3((U2(_ARG_1_))).scene == true) and not (U3((U2(_ARG_1_))).all == true or U3((U2(_ARG_1_))).customui == true) and not (U3((U2(_ARG_1_))).all == true or U3((U2(_ARG_1_))).luascript == true) and not (U3((U2(_ARG_1_))).all == true or U3((U2(_ARG_1_))).blockly == true) and not (U3((U2(_ARG_1_))).all == true or U3((U2(_ARG_1_))).other == true) then
        return
      end
      if U3((U2(_ARG_1_))).all == true or U3((U2(_ARG_1_))).all == true or U3((U2(_ARG_1_))).scene == true or U3((U2(_ARG_1_))).all == true or U3((U2(_ARG_1_))).customui == true then
        if (GetInstanceManager and GetInstanceManager() or nil) ~= nil then
          ;(GetInstanceManager and GetInstanceManager() or nil).LoadPendingClearState = {
            OldInstanceIdSet = U4(GetInstanceManager and GetInstanceManager() or nil, U3((U2(_ARG_1_))).all == true, U3((U2(_ARG_1_))).all == true or U3((U2(_ARG_1_))).scene == true, U3((U2(_ARG_1_))).all == true or U3((U2(_ARG_1_))).customui == true) or {},
            KeepAll = U3((U2(_ARG_1_))).all == true,
            KeepScene = U3((U2(_ARG_1_))).all == true or U3((U2(_ARG_1_))).scene == true,
            KeepCustomUI = U3((U2(_ARG_1_))).all == true or U3((U2(_ARG_1_))).customui == true
          }
        end
      elseif (GetInstanceManager and GetInstanceManager() or nil) ~= nil then
        ;(GetInstanceManager and GetInstanceManager() or nil).LoadPendingClearState = nil
      end
      if U3((U2(_ARG_1_))).all == true or U3((U2(_ARG_1_))).blockly == true then
        if (GetCreativeLuaCodeManager and GetCreativeLuaCodeManager() or nil) ~= nil and (GetCreativeLuaCodeManager and GetCreativeLuaCodeManager() or nil).DSClearLuaCodeData ~= nil then
        else
        end
      end
      if U3((U2(_ARG_1_))).all == true or U3((U2(_ARG_1_))).luascript == true then
      end
      if U3((U2(_ARG_1_))).all == true or U3((U2(_ARG_1_))).other == true then
        if (GetGameParameterManager and GetGameParameterManager() or nil) ~= nil and (GetGameParameterManager and GetGameParameterManager() or nil).DSClearGameParameters ~= nil then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SaveBinaryDataWithVersion"] = function(_ARG_0_, _ARG_1_)
    do
      if require((U1(189, 79, 157, 145, 170, 14, 108, 3, 191, 231, 154, 26, 123, 19))).IsReleaseVersion() then
        if not ((GetGameParameterManager and GetGameParameterManager() or nil) and (GetGameParameterManager and GetGameParameterManager() or nil):GetGameParameter((U1(137, 79, 130, 151, 146, 8, 43, 2, 174, 226, 159, 0, 123))).Value or nil) then
          return
        elseif not (GetGameParameterManager and GetGameParameterManager() or nil) and (GetGameParameterManager and GetGameParameterManager() or nil):GetGameParameter((U1(137, 79, 130, 151, 146, 8, 43, 2, 174, 226, 159, 0, 123))).Value or nil.editor_export then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
