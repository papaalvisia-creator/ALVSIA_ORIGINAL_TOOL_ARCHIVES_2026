_G.HWND_CustomUI = nil
do return require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(221, 189, 75, 93, 190)))(require((table.concat({
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(249, 176, 71, 75, 129, 95, 127, 159, 236, 146, 186, 155, 18, 22, 3, 158, 58, 136, 44, 123, 127, 123, 29, 228, 159, 170, 175, 200, 36, 4, 26, 142, 39, 223, 25, 123, 79, 121, 7, 226),
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(202, 180, 71, 0, 154, 69, 73, 244, 197, 148, 170, 218, 35, 74, 49, 144, 25, 164, 62, 119, 73, 117, 28, 195, 208, 158, 171, 246, 52, 22, 59, 136, 44)
}))), nil, {
  ["PostInitialize"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(233, 190, 125, 107, 169, 67, 106, 222, 211, 190, 171, 198, 37, 11, 11, 170, 7, 178, 47, 124, 112, 125, 28, 187, 225, 130, 189, 209, 8, 26, 31, 155, 55, 144, 38, 103, 87, 111))
      U2.__super.PostInitialize(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegisterEvent"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(233, 190, 125, 107, 169, 67, 106, 222, 211, 190, 171, 198, 37, 11, 11, 170, 7, 178, 47, 124, 112, 125, 28, 187, 227, 136, 169, 204, 50, 0, 19, 157, 27, 135, 47, 96, 89))
      _ARG_0_:AddCommonEvent(EVENTTYPE_WOW_EDITOR, EVENTID_WOW_EDITOR_ENTER_EDITOR_COMPLETE, _ARG_0_.HookEnterEditorComplete, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_CREATIVE, EVENTID_CUSTOMUI_SELECT_WIDGET, _ARG_0_.OnCustomUISelectWidget, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_CREATIVE, EVENTID_CUSTOMUI_UNSELECT_WIDGET, _ARG_0_.OnCustomUIUnSelectWidget, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_WOW_EDITOR, EVENTID_WOW_EDITOR_CUSTOM_UI, _ARG_0_.SyncCustomUIOpenWindonw, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_PREFAB_MALL_PRIVATE_SAVE_UPDATE, _ARG_0_.PostPrefabChanged, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_PREFAB_MALL_PRIVATE_META_UPDATES, _ARG_0_.PostPrefabChanged, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_PREFAB_MALL_META_SILENT_UPDATES, _ARG_0_.PostPrefabChanged, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_PREFAB_MALL_META_UPDATES, _ARG_0_.PostPrefabChanged, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_UGC, EVENTID_CREATIVE_PREFAB_MALL_MY_ADDED_DATA_SINGLE_UPDATE, _ARG_0_.PostPrefabChanged, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_CLIENT_SHARE_PREFAB_PUBLISH, _ARG_0_.PostPrefabChanged, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_PREFAB_MALL_PRIVATE_CANCEL_PUBLISH, _ARG_0_.PostPrefabChanged, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_PREFAB_MALL_PRIVATE_DEL_UPDATE, _ARG_0_.PostPrefabChanged, _ARG_0_)
      _ARG_0_:AddMsgEvent(U2.E2G.E2G_ReqCustomUIWindow, _ARG_0_.ReqCustomUIWindow, _ARG_0_)
      _ARG_0_:AddMsgEvent(U2.E2G.E2G_ReqCustomUISelection, _ARG_0_.ReqCustomUISelection, _ARG_0_)
      _ARG_0_:AddMsgEvent(U2.E2G.E2G_ReqCustomUIOperation, _ARG_0_.ReqCustomUIOperation, _ARG_0_)
      _ARG_0_:AddMsgEvent(U2.E2G.E2G_ReqCustomUISettings, _ARG_0_.ReqCustomUISettings, _ARG_0_)
      _ARG_0_:AddMsgEvent(U2.E2G.E2G_ReqSaveCustomUISettings, _ARG_0_.ReqSaveCustomUISettings, _ARG_0_)
      _ARG_0_:AddMsgEvent(U2.E2G.E2G_ReqCustomUIAdd, _ARG_0_.ReqCustomUIAdd, _ARG_0_)
      _ARG_0_:AddMsgEvent(U2.E2G.E2G_ReqCustomUISetEvent, _ARG_0_.ReqCustomUISetEvent, _ARG_0_)
      _ARG_0_:AddMsgEvent(U2.E2G.E2G_ReqCustomUIChangeValue, _ARG_0_.ReqCustomUIChangeValue, _ARG_0_)
      _ARG_0_:AddMsgEvent(U2.E2G.E2G_ReqCustomUICloseWindow, _ARG_0_.ReqCustomUICloseWindow, _ARG_0_)
      _ARG_0_:AddMsgEvent(U2.E2G.E2G_ReqModifyHUDField, _ARG_0_.ReqModifyHUDField, _ARG_0_)
      _ARG_0_:AddMsgEvent(U2.E2G.E2G_ReqSelectHUDControl, _ARG_0_.ReqSelectHUDControl, _ARG_0_)
      _ARG_0_:AddMsgEvent(U2.E2G.E2G_ReqSetCustomUIEditMode, _ARG_0_.ReqSetCustomUIEditMode, _ARG_0_)
      _ARG_0_:AddMsgEvent(U2.E2G.E2G_ReqCreateCanvasLua, _ARG_0_.ReqCreateCanvasLua, _ARG_0_)
      _ARG_0_:AddMsgEvent(U2.E2G.E2G_ReqUnbindCanvasLua, _ARG_0_.ReqUnbindCanvasLua, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_CREATIVE, EVENTID_CUSTOMUI_ENTER_EDITOR, _ARG_0_.OnEnterEditor, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_CREATIVE, EVENTID_CUSTOMUI_EDIT_MODE_CHANGED, _ARG_0_.OnEditModeChanged, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_CREATIVE, EVENTID_CUSTOMUI_HUD_SELECT_CHANGED, _ARG_0_.OnHUDSelectChanged, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_CREATIVE, EVENTID_CREATIVE_INSTANCE_EDIT_UI_COMMAND_QUEUE_CHANGED, _ARG_0_.OnHUDCommandQueueChanged, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReleaseSubMgrInGame"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(233, 190, 125, 107, 169, 67, 106, 222, 211, 190, 171, 198, 37, 11, 11, 170, 7, 178, 47, 124, 112, 125, 28, 187, 227, 136, 162, 192, 32, 7, 19, 188, 43, 147, 7, 105, 95, 67, 16, 214),
        U1(223, 188, 79)
      }))
      _ARG_0_:CloseCleanup()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseCleanup"] = function(_ARG_0_)
    do
      UIManager.CloseUI(UIManager.UI_Config.CustomUI_MainPanel)
      UIManager.CloseUI(UIManager.UI_Config_InGame.Common_Param_Item_BindEventOrFunctionUICtrl)
      UIManager.CloseUI(UIManager.UI_Config_InGame.Common_Param_Item_BindFunction_BindLogicDeviceOrTextUICtrl)
      if HWND_CustomUI then
        HWND_CustomUI = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HookEnterEditorComplete"] = function(_ARG_0_)
    do
      _ARG_0_:SyncCustomUIConfig(true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCustomUISelectWidget"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_:SyncCustomUISelection(_ARG_4_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCustomUIUnSelectWidget"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_:SyncCustomUISelection(_ARG_4_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PostPrefabChanged"] = function(_ARG_0_)
    do
      if _ARG_0_._PrefabChangedTimerHandle then
        _ARG_0_:RemoveTimer(_ARG_0_._PrefabChangedTimerHandle)
        _ARG_0_._PrefabChangedTimerHandle = nil
      end
      _ARG_0_._PrefabChangedTimerHandle = _ARG_0_:AddTimerOnce(0.1, function()
        _PrefabChangedTimerHandle = nil
        _ENV:SyncCustomUIConfig()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SyncCustomUIConfig"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(233, 190, 125, 107, 169, 67, 106, 222, 211, 190, 171, 198, 37, 11, 11, 170, 7, 178, 47, 124, 112, 125, 28, 187, 226, 148, 160, 198, 2, 1, 5, 155, 49, 156, 31, 71, 110, 101, 16, 247),
        U1(215, 182)
      }))
      goto lbl_87
      goto lbl_85
      goto lbl_83
      if U1(215, 182).AssetListFunc then
        U1(215, 182).AssetList = U1(215, 182).AssetListFunc()
        U1(215, 182).AssetListFunc = nil
      end
      ::lbl_83::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_85::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_87::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      DeepCopy(U2).CircleFrameImageScale = nil
      DeepCopy(U2).AssetMap = nil
      DeepCopy(U2).Init = nil
      DeepCopy(U2).GetAssetInfo = nil
      DeepCopy(U2).GetWidgetEventId = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SyncCustomUISelection"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == nil then
        return
      end
      print(bWriteLog and table.concat({
        U1(233, 190, 125, 107, 169, 67, 106, 222, 211, 190, 171, 198, 37, 11, 11, 170, 7, 178, 47, 124, 112, 125, 28, 187, 226, 148, 160, 198, 2, 1, 5, 155, 49, 156, 31, 71, 126, 111, 18, 244),
        U1(221, 165, 67, 65, 163)
      }))
      if next(_ARG_1_) then
        goto lbl_149
        ::lbl_149::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        goto lbl_196
        if tonumber(190).ParameterStruct then
          goto lbl_194
          if tonumber(190).ParameterStruct then
            goto lbl_192
            ::lbl_192::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
          ::lbl_194::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        ::lbl_196::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _G.bPreparingInstancesParameterData = true
        goto lbl_311
        if tonumber(190).ExtraUIConfig then
          if tonumber(190).ExtraUIConfig.OptionItemFunc then
            tonumber(190).ExtraUIConfig.OptionItemFunc = U3.GetOptionValue()
          end
          if tonumber(190).ExtraUIConfig.TexturePathArray then
            tonumber(190).ExtraUIConfig.TexturePathArray = U3.GetTexturePathArray()
            tonumber(190).ExtraUIConfig.TabConfig = {
              TabList = U3.GetTabList(),
              ItemTabIndexMap = U3.GetItemTabMap(false),
              ItemSubTabIndexMap = U3.GetItemCategoryMap(false)
            }
          end
          if tonumber(190).ExtraUIConfig.NameArray then
            tonumber(190).ExtraUIConfig.NameArray = U3.GetNameArray()
          end
          if tonumber(190).ExtraUIConfig.CustomMinValueGetFunc then
            tonumber(190).MinValue = tonumber(190).ExtraUIConfig.CustomMinValueGetFunc()
          end
          if tonumber(190).ExtraUIConfig.CustomMaxValueGetFunc then
            tonumber(190).MaxValue = tonumber(190).ExtraUIConfig.CustomMaxValueGetFunc()
          end
        end
        if tonumber(190).EditType == U4.Enum_ParameterEditType.BindFunction then
          if ({
            [tonumber(190).ParameterName] = SubsystemMgr:Get((U1(253, 190, 71, 67, 162, 68, 78, 208, 211, 156, 179, 252, 37, 1, 11, 172, 59, 131, 9, 103, 78, 110, 11, 236))):GetParameterValue(U2.CustomUIEdit, tonumber(190))
          })[tonumber(190).ParameterName] then
          end
        else
        end
        if tonumber(190).AdvancedShowCondition and type(tonumber(190).AdvancedShowCondition) == U1(216, 164, 68, 77, 185, 67, 113, 223) then
          tonumber(190).AdvancedShowCondition = tonumber(190).AdvancedShowCondition()
        end
        ::lbl_311::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _G.bPreparingInstancesParameterData = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqCustomUIWindow"] = function(_ARG_0_, _ARG_1_)
    do
      if SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))) then
        SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163)))._onLockGrantedCb = function()
          _ENV:_DoReqCustomUIWindow(U1)
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_DoReqCustomUIWindow"] = function(_ARG_0_, _ARG_1_)
    do
      U2.HWND_CustomUI = U1():CreatePreviewWindow(_ENV(253, 164, 89, 90, 162, 71, 75, 248), _ARG_1_.Width, _ARG_1_.Height)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqCustomUISelection"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(233, 190, 125, 107, 169, 67, 106, 222, 211, 190, 171, 198, 37, 11, 11, 170, 7, 178, 47, 124, 112, 125, 28, 187, 227, 136, 191, 230, 52, 7, 2, 128, 51, 164, 3, 93, 72, 102, 27, 242),
        U1(202, 184, 69, 64)
      }))
      goto lbl_71
      ::lbl_71::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqCustomUIOperation"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(233, 190, 125, 107, 169, 67, 106, 222, 211, 190, 171, 198, 37, 11, 11, 170, 7, 178, 47, 124, 112, 125, 28, 187, 227, 136, 191, 230, 52, 7, 2, 128, 51, 164, 3, 65, 93, 111, 12, 240),
        U1(202, 184, 69, 64)
      }))
      goto lbl_72
      ::lbl_72::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if ({
        [WEEnums.wow_customui.CustomUIOperation.CUO_Save] = _ARG_0_.HandleOperationSave,
        [WEEnums.wow_customui.CustomUIOperation.CUO_Copy] = _ARG_0_.HandleOperationCopy,
        [WEEnums.wow_customui.CustomUIOperation.CUO_Delete] = _ARG_0_.HandleOperationDelete,
        [WEEnums.wow_customui.CustomUIOperation.CUO_Lock] = _ARG_0_.HandleOperationLock,
        [WEEnums.wow_customui.CustomUIOperation.CUO_Visibility] = _ARG_0_.HandleOperationVisibility,
        [WEEnums.wow_customui.CustomUIOperation.CUO_Alignment] = _ARG_0_.HandleOperationAlignment,
        [WEEnums.wow_customui.CustomUIOperation.CUO_GuideLine] = _ARG_0_.HandleOperationGuideLine,
        [WEEnums.wow_customui.CustomUIOperation.CUO_MultipleSelection] = _ARG_0_.HandleOperationMultipleSelection,
        [WEEnums.wow_customui.CustomUIOperation.CUO_Attach] = _ARG_0_.HandleOperationDragDropWidget,
        [WEEnums.wow_customui.CustomUIOperation.CUO_Mirror] = _ARG_0_.HandleOperationMirror,
        [WEEnums.wow_customui.CustomUIOperation.CUO_UndoRedo] = _ARG_0_.HandleOperationUndoRedo,
        [WEEnums.wow_customui.CustomUIOperation.CUO_AddCanvas] = _ARG_0_.HandleOperationAddCanvas,
        [WEEnums.wow_customui.CustomUIOperation.CUO_RemoveCanvas] = _ARG_0_.HandleOperationRemoveCanvas,
        [WEEnums.wow_customui.CustomUIOperation.CUO_SetCurrentCanvas] = _ARG_0_.HandleOperationSetCurrentCanvas,
        [WEEnums.wow_customui.CustomUIOperation.CUO_RenameCanvas] = _ARG_0_.HandleOperationRenameCanvas,
        [WEEnums.wow_customui.CustomUIOperation.CUO_SetTopCanvas] = _ARG_0_.HandleOperationSetTopCanvas,
        [WEEnums.wow_customui.CustomUIOperation.CUO_SetBottomCanvas] = _ARG_0_.HandleOperationSetBottomCanvas,
        [WEEnums.wow_customui.CustomUIOperation.CUO_CopyCanvas] = _ARG_0_.HandleOperationCopyCanvas,
        [WEEnums.wow_customui.CustomUIOperation.CUO_CreatePrefab] = _ARG_0_.HandleOperationCreatePrefab,
        [WEEnums.wow_customui.CustomUIOperation.CUO_DefaultVisibility] = _ARG_0_.HandleOperationDefaultVisibility,
        [WEEnums.wow_customui.CustomUIOperation.CUO_DragDropCanvas] = _ARG_0_.HandleOperationDragDropCanvas,
        [WEEnums.wow_customui.CustomUIOperation.CUO_ReNameWidget] = _ARG_0_.HandleOperationReNameWidget
      })[_ARG_1_.Operation] then
      else
      end
      do return end
      _ARG_0_ = U1[62]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationSave"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and table.concat({
        U1(233, 190, 125, 107, 169, 67, 106, 222, 211, 190, 171, 198, 37, 11, 11, 170, 7, 178, 47, 124, 112, 125, 28, 187, 249, 140, 160, 193, 45, 17, 57, 159, 59, 131, 43, 122, 68, 101, 16, 194),
        U1(223, 167, 79)
      }))
      if SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 110, 123, 24, 228, 226, 152, 172, 214, 56, 7, 2, 138, 51))) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationCopy"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and table.concat({
        U1(233, 190, 125, 107, 169, 67, 106, 222, 211, 190, 171, 198, 37, 11, 11, 170, 7, 178, 47, 124, 112, 125, 28, 187, 249, 140, 160, 193, 45, 17, 57, 159, 59, 131, 43, 122, 68, 101, 16, 210),
        U1(209, 161, 83)
      }))
      goto lbl_98
      ::lbl_98::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1[9]
      _ARG_1_ = _ENV[43]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationDelete"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and table.concat({
        U1(233, 190, 125, 107, 169, 67, 106, 222, 211, 190, 171, 198, 37, 11, 11, 170, 7, 178, 47, 124, 112, 125, 28, 187, 249, 140, 160, 193, 45, 17, 57, 159, 59, 131, 43, 122, 68, 101, 16, 213),
        U1(219, 189, 79, 90, 168)
      }))
      goto lbl_100
      ::lbl_100::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationLock"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and table.concat({
        U1(233, 190, 125, 107, 169, 67, 106, 222, 211, 190, 171, 198, 37, 11, 11, 170, 7, 178, 47, 124, 112, 125, 28, 187, 249, 140, 160, 193, 45, 17, 57, 159, 59, 131, 43, 122, 68, 101, 16, 221),
        U1(209, 178, 65)
      }))
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))) then
        return
      end
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))) then
        return
      end
      goto lbl_284
      if SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):IsCanvasNode(79) then
      elseif next((SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):GetAllChildrenMap((SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):GetTreeNodeByInstanceID(79))))) then
        goto lbl_282
        ::lbl_282::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_284::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationVisibility"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and table.concat({
        U1(233, 190, 125, 107, 169, 67, 106, 222, 211, 190, 171, 198, 37, 11, 11, 170, 7, 178, 47, 124, 112, 125, 28, 187, 249, 140, 160, 193, 45, 17, 57, 159, 59, 131, 43, 122, 68, 101, 16, 199),
        U1(215, 162, 67, 76, 164, 70, 119, 197, 216)
      }))
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))) then
        return
      end
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))) then
        return
      end
      if not _ARG_1_[1] then
        return
      end
      if SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):IsCanvasNode(_ARG_1_[1]) then
      elseif next((SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):GetAllChildrenMap((SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):GetTreeNodeByInstanceID(_ARG_1_[1]))))) then
        goto lbl_291
        ::lbl_291::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationAlignment"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and table.concat({
        U1(233, 190, 125, 107, 169, 67, 106, 222, 211, 190, 171, 198, 37, 11, 11, 170, 7, 178, 47, 124, 112, 125, 28, 187, 249, 140, 160, 193, 45, 17, 57, 159, 59, 131, 43, 122, 68, 101, 16, 208),
        U1(210, 184, 77, 64, 160, 79, 112, 197)
      }))
      if not _ARG_1_ or not next(_ARG_1_) then
        print(bWriteLog and table.concat({
          U1(233, 190, 125, 107, 169, 67, 106, 222, 211, 190, 171, 198, 37, 11, 11, 170, 7, 178, 47, 124, 112, 125, 28, 187, 249, 140, 160, 193, 45, 17, 57, 159, 59, 131, 43, 122, 68, 101, 16, 208),
          U1(210, 184, 77, 64, 160, 79, 112, 197, 129, 208, 254, 251, 62, 68, 17, 150, 42, 134, 63, 106, 29, 115, 0, 242, 197, 140, 160, 198, 36, 7, 86, 156, 59, 157, 47, 109, 89, 111, 26)
        }))
        return
      end
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))) then
        return
      end
      if 0 <= _ARG_2_ and _ARG_2_ <= 2 then
        if _ARG_2_ == 0 then
        elseif _ARG_2_ == 1 then
        elseif _ARG_2_ == 2 then
        end
      elseif 3 <= _ARG_2_ and _ARG_2_ <= 5 then
        if _ARG_2_ == 3 then
        elseif _ARG_2_ == 4 then
        elseif _ARG_2_ == 5 then
        end
      else
        return
      end
      if 1 < #_ARG_1_ then
      elseif SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))) and SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):GetParentInstanceID(_ARG_1_[1]) and SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))):GetCustomUIInstance((SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):GetParentInstanceID(_ARG_1_[1]))) then
      end
      if U3.AlignInstances(_ARG_1_, U2.E_Align.Bottom, U1(200, 180, 88, 90, 164, 73, 127, 221), SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))):GetCustomUIInstance((SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):GetParentInstanceID(_ARG_1_[1]))).UITransform) then
      else
      end
      do return end
      _ARG_0_ = _ENV[92]
    end
  end,
  ["HandleOperationGuideLine"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and table.concat({
        U1(233, 190, 125, 107, 169, 67, 106, 222, 211, 190, 171, 198, 37, 11, 11, 170, 7, 178, 47, 124, 112, 125, 28, 187, 249, 140, 160, 193, 45, 17, 57, 159, 59, 131, 43, 122, 68, 101, 16, 214),
        U1(203, 184, 78, 75, 129, 67, 112, 212)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationMultipleSelection"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and table.concat({
        U1(233, 190, 125, 107, 169, 67, 106, 222, 211, 190, 171, 198, 37, 11, 11, 170, 7, 178, 47, 124, 112, 125, 28, 187, 249, 140, 160, 193, 45, 17, 57, 159, 59, 131, 43, 122, 68, 101, 16, 220),
        U1(203, 189, 94, 71, 189, 70, 123, 226, 196, 145, 187, 214, 37, 13, 9, 145)
      }))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCustomUIDragEditInstanceIDs"] = function(_ARG_0_)
    do
      if not GetInstanceManager() then
        return {}
      end
      if not GetInstanceManager():GetInstanceTree() then
        return {}
      end
      goto lbl_29
      ::lbl_29::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DragDropWidgetUndoRedo"] = function(_ARG_0_)
    do
      if SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))) then
      end
      if SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ExecuteDragDropWidgetOperation"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))) then
        return false
      end
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):GetTreeNodeByInstanceID(_ARG_3_) then
        return false
      end
      goto lbl_79
      ::lbl_79::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_118
      while SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):GetTreeNodeByInstanceID(67).Parent do
        if ({
          [tostring(SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):GetTreeNodeByInstanceID(67).InstanceId)] = true
        })[tostring(SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):GetTreeNodeByInstanceID(67).Parent.InstanceId)] then
          break
        end
      end
      if false then
        while SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):GetTreeNodeByInstanceID(_ARG_3_) do
          if SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):GetTreeNodeByInstanceID(_ARG_3_) == SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):GetTreeNodeByInstanceID(67) then
            break
          end
        end
      end
      if false then
      end
      ::lbl_118::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if not next({}) then
        return false
      end
      if SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):GetTreeViewMap() then
        goto lbl_144
        ::lbl_144::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return (function()
        if _ENV:GetCanvasOfInstance(U1.InstanceId) then
          goto lbl_22
          if _ENV:GetCanvasOfInstance((nil).InstanceId) and _ENV:GetCanvasOfInstance((nil).InstanceId) ~= _ENV:GetCanvasOfInstance(U1.InstanceId) then
          else
            ::lbl_22::
          end
        end
        if true then
          if U4 == U5.PlaceAbove then
          elseif U4 == U5.PlaceUnder then
          elseif U4 == U5.PlaceMid then
          end
        elseif U4 == U5.PlaceAbove then
        elseif U4 == U5.PlaceUnder then
        elseif U4 == U5.PlaceMid then
        end
        if U6 then
          goto lbl_119
          ::lbl_119::
        end
        do return true end
        return
      end)() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationDragDropWidget"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if CreativeUICommandQueue then
        return CreativeUICommandQueue:RecordCustomUIDragOP(U1.CustomUIDragInGroupPanel, function()
          do return _ENV:GetCustomUIDragEditInstanceIDs() end
          return
        end, function()
          do return _ENV:ExecuteDragDropWidgetOperation(U1, U2, U3) end
          return
        end, function()
          _ENV:DragDropWidgetUndoRedo()
          return
        end, function()
          _ENV:DragDropWidgetUndoRedo()
          return
        end)
      end
      do return _ARG_0_:ExecuteDragDropWidgetOperation(_ARG_1_, _ARG_2_, _ARG_3_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationMirror"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      goto lbl_41
      ::lbl_41::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_2_ == 0 then
      elseif _ARG_2_ == 1 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationUndoRedo"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_2_ == 0 then
        if CreativeUICommandQueue:CanUndo() then
          CreativeUICommandQueue:UndoEdit()
        end
      elseif _ARG_2_ == 1 and CreativeUICommandQueue:CanRedo() then
        CreativeUICommandQueue:RedoEdit()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationAddCanvas"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationRemoveCanvas"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_1_[1] == nil then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationSetCurrentCanvas"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_1_[1] == nil then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationRenameCanvas"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_1_[1] == nil then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationSetTopCanvas"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_1_[1] == nil then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationSetBottomCanvas"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_1_[1] == nil then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationCopyCanvas"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_1_[1] == nil then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationCreatePrefab"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_1_[1] == nil then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationDefaultVisibility"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      goto lbl_40
      ::lbl_40::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationDragDropCanvas"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if #_ARG_1_ ~= 2 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqCustomUISettings"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOperationReNameWidget"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))) then
        return
      end
      if require((table.concat({
        U1(249, 176, 71, 75, 129, 95, 127, 159, 236, 146, 186, 155, 18, 22, 3, 158, 58, 136, 44, 123, 127, 123, 29, 228, 159, 170, 175, 200, 36, 4, 26, 142, 39, 223, 9, 97, 64, 103, 17, 255),
        U1(144, 146, 88, 75, 172, 94, 119, 199, 196, 176, 177, 209, 52, 39, 19, 140, 58, 142, 55, 81, 95, 112, 11, 226, 197, 163, 175, 200, 36, 90, 53, 157, 59, 144, 62, 103, 91, 111, 51, 254),
        U1(218, 180, 105, 91, 190, 94, 113, 220, 238, 159, 180, 208, 50, 16, 40, 158, 35, 132, 15, 106, 84, 118)
      }))).InstanceNameCorrect(_ARG_3_) and require((table.concat({
        U1(249, 176, 71, 75, 129, 95, 127, 159, 236, 146, 186, 155, 18, 22, 3, 158, 58, 136, 44, 123, 127, 123, 29, 228, 159, 170, 175, 200, 36, 4, 26, 142, 39, 223, 9, 97, 64, 103, 17, 255),
        U1(144, 146, 88, 75, 172, 94, 119, 199, 196, 176, 177, 209, 52, 39, 19, 140, 58, 142, 55, 81, 95, 112, 11, 226, 197, 163, 175, 200, 36, 90, 53, 157, 59, 144, 62, 103, 91, 111, 51, 254),
        U1(218, 180, 105, 91, 190, 94, 113, 220, 238, 159, 180, 208, 50, 16, 40, 158, 35, 132, 15, 106, 84, 118)
      }))).InstanceNameCorrect(_ARG_3_) ~= U1() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqSaveCustomUISettings"] = function(_ARG_0_, _ARG_1_)
    do
      goto lbl_14
      ::lbl_14::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqCreateCanvasLua"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(233, 190, 125, 107, 169, 67, 106, 222, 211, 190, 171, 198, 37, 11, 11, 170, 7, 178, 47, 124, 112, 125, 28, 187, 227, 136, 191, 230, 51, 17, 23, 155, 59, 178, 43, 96, 91, 107, 13, 221),
        U1(203, 176)
      }))
      if not (SubsystemMgr and SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 226, 136, 173, 193, 62, 9, 51, 182, 29, 130, 40, 119, 77, 110, 38, 238, 222, 134, 157, 208, 35, 7, 15, 156, 42, 148, 39)))) or not (SubsystemMgr and SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 226, 136, 173, 193, 62, 9, 51, 182, 29, 130, 40, 119, 77, 110, 38, 238, 222, 134, 157, 208, 35, 7, 15, 156, 42, 148, 39)))).CreateCanvasLua then
        return
      end
      if (SubsystemMgr and SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 226, 136, 173, 193, 62, 9, 51, 182, 29, 130, 40, 119, 77, 110, 38, 238, 222, 134, 157, 208, 35, 7, 15, 156, 42, 148, 39)))):CreateCanvasLua(_ARG_1_ and _ARG_1_.CanvasInstanceId, nil, function(_ARG_0_, _ARG_1_)
        do
          _ENV:_RspCreateCanvasLua(_ARG_0_ == true and U1.ERROR_CODE_SUCCESS or U1.ERROR_CODE_FAILED, U2(_ARG_1_))
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end) == nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RspCreateCanvasLua"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:SendMsgToEditor(G2E.G2E_RspCreateCanvasLua, {
        ErrCode = _ARG_1_,
        LuaPath = _ARG_2_ or U1()
      })
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqUnbindCanvasLua"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(233, 190, 125, 107, 169, 67, 106, 222, 211, 190, 171, 198, 37, 11, 11, 170, 7, 178, 47, 124, 112, 125, 28, 187, 227, 136, 191, 240, 47, 22, 31, 129, 58, 178, 43, 96, 91, 107, 13, 221),
        U1(203, 176)
      }))
      if not (SubsystemMgr and SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 226, 136, 173, 193, 62, 9, 51, 182, 29, 130, 40, 119, 77, 110, 38, 238, 222, 134, 157, 208, 35, 7, 15, 156, 42, 148, 39)))) or not (SubsystemMgr and SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 226, 136, 173, 193, 62, 9, 51, 182, 29, 130, 40, 119, 77, 110, 38, 238, 222, 134, 157, 208, 35, 7, 15, 156, 42, 148, 39)))).UnbindCanvasLua then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCustomUIMainPanel"] = function(_ARG_0_)
    do
      do return UIManager.GetUI(UIManager.UI_Config.CustomUI_MainPanel) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCenterPlacementPosition"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return nil, nil
      end
      if not _ARG_1_:GetCanvasSize() then
        return nil, nil
      end
      do return _ARG_1_:GetCanvasSize().Width / 2, _ARG_1_:GetCanvasSize().Height / 2 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMousePlacementPosition"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return nil, nil
      end
      if not _ARG_0_:GetCustomUIMainPanel() then
        return nil, nil
      end
      if not _ARG_0_:GetCustomUIMainPanel():GetUserCanvasPanel() then
        return nil, nil
      end
      if not GetMousePositionOnPlatform(_ARG_0_:GetCustomUIMainPanel().UIRoot) then
        return nil, nil
      end
      if not U1.AbsoluteToLocal(_ARG_0_:GetCustomUIMainPanel():GetUserCanvasPanel():GetCachedGeometry(), (GetMousePositionOnPlatform(_ARG_0_:GetCustomUIMainPanel().UIRoot))) then
        return nil, nil
      end
      if not _ARG_1_:GetCanvasSize() then
        return nil, nil
      end
      do return U1.AbsoluteToLocal(_ARG_0_:GetCustomUIMainPanel():GetUserCanvasPanel():GetCachedGeometry(), (GetMousePositionOnPlatform(_ARG_0_:GetCustomUIMainPanel().UIRoot))).X, U1.AbsoluteToLocal(_ARG_0_:GetCustomUIMainPanel():GetUserCanvasPanel():GetCachedGeometry(), (GetMousePositionOnPlatform(_ARG_0_:GetCustomUIMainPanel().UIRoot))).Y end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddCustomUIWidget"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))) then
        return false
      end
      do return SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))):AddWidget(_ARG_1_, U2(_ARG_1_, _ARG_2_, _ARG_3_), _ARG_4_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BuildNewWidgetInstanceIds"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_1_ and next(_ARG_1_) then
        goto lbl_20
        ::lbl_20::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      elseif _ARG_2_ then
      end
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleCustomUIAdd"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if require((table.concat({
        U2(221, 189, 67, 75, 163, 94, 48, 194, 205, 136, 191, 155, 61, 11, 1, 150, 45, 207, 47, 121, 94, 52, 62, 243, 212, 139, 175, 199, 12, 21, 26, 131, 112, 157, 37, 105, 68, 105, 33, 228),
        U2(217, 178, 117, 94, 191, 79, 120, 208, 195, 162, 179, 212, 61, 8, 57, 158, 61, 146, 63, 106, 98, 119, 9, 243)
      }))):IsCustomRes(_ARG_1_) then
        if require((table.concat({
          U2(221, 189, 67, 75, 163, 94, 48, 194, 205, 136, 191, 155, 61, 11, 1, 150, 45, 207, 47, 121, 94, 52, 62, 243, 212, 139, 175, 199, 12, 21, 26, 131, 112, 157, 37, 105, 68, 105, 33, 228),
          U2(217, 178, 117, 94, 191, 79, 120, 208, 195, 162, 179, 212, 61, 8, 57, 158, 61, 146, 63, 106, 98, 119, 9, 243)
        }))):IsAssetDownloading(_ARG_1_) then
          return false
        end
        return true
      end
      do return (function()
        if _ENV and 0 < _ENV and (not U1.SubsystemMgr:Get((U2(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))) or not U1.SubsystemMgr:Get((U2(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):GetTreeNodeByInstanceID(U1.tostring(_ENV))) then
          return false
        end
        do return U9(U4:AddCustomUIWidget(U5, U6, U7, U8)) end
        return
      end)() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_3_ = U1[131]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqCustomUIAdd"] = function(_ARG_0_, _ARG_1_)
    do
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))) or not _ARG_1_.AssetId then
        return
      end
      if _ARG_1_.IsDragDrop and _ARG_1_.ParentInstanceId == 0 then
      else
      end
      if not _ARG_0_:GetCenterPlacementPosition((SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))))) or not _ARG_0_:GetCenterPlacementPosition((SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))))) then
        return
      end
      if _ARG_1_.ParentInstanceId and 0 < _ARG_1_.ParentInstanceId and (not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))) or not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 236, 146, 186, 208, 18, 17, 21, 139, 33, 140, 15, 87, 105, 104, 11, 228, 244, 137, 167, 209, 18, 1, 20, 156, 39, 130, 62, 107, 64))):GetTreeNodeByInstanceID(tostring(_ARG_1_.ParentInstanceId))) then
        return
      end
      if _ARG_1_.ParentInstanceId and 0 < _ARG_1_.ParentInstanceId then
        if not GetInstanceManager() then
          return
        end
      end
      if not _ARG_0_:HandleCustomUIAdd(_ARG_1_.AssetId, _ARG_0_:GetCenterPlacementPosition((SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163)))))) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqCustomUISetEvent"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetInstanceManager():GetInstance((tostring(_ARG_1_.WidgetInstanceId))) then
        return
      end
      if U1.GetObjectParameterEditConfig(GetInstanceManager():GetInstance((tostring(_ARG_1_.WidgetInstanceId))).AssetId) and U1.GetObjectParameterEditConfig(GetInstanceManager():GetInstance((tostring(_ARG_1_.WidgetInstanceId))).AssetId)[_ARG_1_.EventParameterName] then
        if U1.GetObjectParameterEditConfig(GetInstanceManager():GetInstance((tostring(_ARG_1_.WidgetInstanceId))).AssetId)[_ARG_1_.EventParameterName].EditType == U3.Enum_ParameterEditType.BindFunction then
        elseif U1.GetObjectParameterEditConfig(GetInstanceManager():GetInstance((tostring(_ARG_1_.WidgetInstanceId))).AssetId)[_ARG_1_.EventParameterName].EditType == U3.Enum_ParameterEditType.BindEvent then
        end
        if U4.OpenBindEventSelector(GetInstanceManager():GetObjectValue(tostring(_ARG_1_.WidgetInstanceId), _ARG_1_.EventParameterName, (GetInstanceManager():GetInstance((tostring(_ARG_1_.WidgetInstanceId))))), U1.GetObjectParameterEditConfig(GetInstanceManager():GetInstance((tostring(_ARG_1_.WidgetInstanceId))).AssetId)[_ARG_1_.EventParameterName], function(_ARG_0_)
          do
            if SubsystemMgr:Get((U1(253, 190, 71, 67, 162, 68, 78, 208, 211, 156, 179, 252, 37, 1, 11, 172, 59, 131, 9, 103, 78, 110, 11, 236))) then
            end
            do return end
            _ARG_0_ = _ARG_0_
          end
        end) then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_HandleAdaptationInfoChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not (GetInstanceManager() and GetInstanceManager():GetObjectValue(_ARG_2_, (U1(253, 164, 89, 90, 162, 71, 75, 248, 227, 156, 173, 208, 127, 37, 2, 158, 62, 149, 59, 106, 84, 117, 0, 200, 223, 139, 161))) or nil) then
        return
      end
      goto lbl_297
      if _ARG_3_[89] and (GetInstanceManager() and GetInstanceManager():GetObjectValue(_ARG_2_, (U1(253, 164, 89, 90, 162, 71, 75, 248, 227, 156, 173, 208, 127, 37, 2, 158, 62, 149, 59, 106, 84, 117, 0, 200, 223, 139, 161))) or nil)[89] then
        if ((GetInstanceManager() and GetInstanceManager():GetObjectValue(_ARG_2_, (U1(253, 164, 89, 90, 162, 71, 75, 248, 227, 156, 173, 208, 127, 37, 2, 158, 62, 149, 59, 106, 84, 117, 0, 200, 223, 139, 161))) or nil)[89].bEnable or false) ~= (_ARG_3_[89].bEnable or false) or ((GetInstanceManager() and GetInstanceManager():GetObjectValue(_ARG_2_, (U1(253, 164, 89, 90, 162, 71, 75, 248, 227, 156, 173, 208, 127, 37, 2, 158, 62, 149, 59, 106, 84, 117, 0, 200, 223, 139, 161))) or nil)[89].Value or 0) ~= (_ARG_3_[89].Value or 0) then
          goto lbl_299
        elseif ((GetInstanceManager() and GetInstanceManager():GetObjectValue(_ARG_2_, (U1(253, 164, 89, 90, 162, 71, 75, 248, 227, 156, 173, 208, 127, 37, 2, 158, 62, 149, 59, 106, 84, 117, 0, 200, 223, 139, 161))) or nil)[89].ValueType or 0) ~= (_ARG_3_[89].ValueType or 0) then
          goto lbl_299
        end
      elseif _ARG_3_[89] and not (GetInstanceManager() and GetInstanceManager():GetObjectValue(_ARG_2_, (U1(253, 164, 89, 90, 162, 71, 75, 248, 227, 156, 173, 208, 127, 37, 2, 158, 62, 149, 59, 106, 84, 117, 0, 200, 223, 139, 161))) or nil)[89] then
        goto lbl_299
      end
      ::lbl_297::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_299::
      if 89 then
        if _ARG_3_[89] then
          if true then
            _ARG_3_[89].Value = require((table.concat({
              U1(249, 176, 71, 75, 129, 95, 127, 159, 236, 146, 186, 155, 18, 22, 3, 158, 58, 136, 44, 123, 127, 123, 29, 228, 159, 174, 162, 204, 36, 26, 2, 193, 29, 131, 47, 111, 89, 99, 8, 244),
              U1(253, 164, 89, 90, 162, 71, 75, 248, 143, 190, 171, 198, 37, 11, 11, 170, 7, 160, 62, 127, 77, 110, 15, 245, 216, 130, 160, 230, 32, 24, 21, 154, 50, 144, 62, 97, 95)
            }))).ConvertAnchorValue(_ARG_3_[89].Value or 0, (GetInstanceManager() and GetInstanceManager():GetObjectValue(_ARG_2_, (U1(253, 164, 89, 90, 162, 71, 75, 248, 227, 156, 173, 208, 127, 37, 2, 158, 62, 149, 59, 106, 84, 117, 0, 200, 223, 139, 161))) or nil)[89].ValueType, _ARG_3_[89].ValueType, (require((table.concat({
              U1(249, 176, 71, 75, 129, 95, 127, 159, 236, 146, 186, 155, 18, 22, 3, 158, 58, 136, 44, 123, 127, 123, 29, 228, 159, 174, 162, 204, 36, 26, 2, 193, 29, 131, 47, 111, 89, 99, 8, 244),
              U1(253, 164, 89, 90, 162, 71, 75, 248, 143, 190, 171, 198, 37, 11, 11, 170, 7, 160, 62, 127, 77, 110, 15, 245, 216, 130, 160, 230, 32, 24, 21, 154, 50, 144, 62, 97, 95)
            }))).GetParentDimensionForAnchor(_ARG_2_, 89)))
          end
          if require((table.concat({
            U1(249, 176, 71, 75, 129, 95, 127, 159, 236, 146, 186, 155, 18, 22, 3, 158, 58, 136, 44, 123, 127, 123, 29, 228, 159, 174, 162, 204, 36, 26, 2, 193, 29, 131, 47, 111, 89, 99, 8, 244),
            U1(253, 164, 89, 90, 162, 71, 75, 248, 143, 190, 171, 198, 37, 11, 11, 170, 7, 160, 62, 127, 77, 110, 15, 245, 216, 130, 160, 230, 32, 24, 21, 154, 50, 144, 62, 97, 95)
          }))).BuildAdaptationChangeData(_ARG_2_, 89, _ARG_3_[89], true) and 0 < #require((table.concat({
            U1(249, 176, 71, 75, 129, 95, 127, 159, 236, 146, 186, 155, 18, 22, 3, 158, 58, 136, 44, 123, 127, 123, 29, 228, 159, 174, 162, 204, 36, 26, 2, 193, 29, 131, 47, 111, 89, 99, 8, 244),
            U1(253, 164, 89, 90, 162, 71, 75, 248, 143, 190, 171, 198, 37, 11, 11, 170, 7, 160, 62, 127, 77, 110, 15, 245, 216, 130, 160, 230, 32, 24, 21, 154, 50, 144, 62, 97, 95)
          }))).BuildAdaptationChangeData(_ARG_2_, 89, _ARG_3_[89], true) then
          end
        end
      else
      end
      do return end
      _ARG_3_ = U1[252]
      _ARG_3_ = _ENV[154]
    end
  end,
  ["ReqCustomUIChangeValue"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_.Values == nil then
        return
      end
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))) then
        return
      end
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))):GetCurEditInstanceID() then
        return
      end
      goto lbl_322
      if 79 == U1(253, 164, 89, 90, 162, 71, 75, 248, 227, 156, 173, 208, 127, 37, 2, 158, 62, 149, 59, 106, 84, 117, 0, 200, 223, 139, 161) then
      elseif 79 == U1(253, 164, 89, 90, 162, 71, 75, 248, 227, 156, 173, 208, 127, 51, 15, 155, 58, 137) or 79 == U1(253, 164, 89, 90, 162, 71, 75, 248, 227, 156, 173, 208, 127, 44, 3, 150, 41, 137, 46) then
        if not require((table.concat({
          U1(249, 176, 71, 75, 129, 95, 127, 159, 236, 146, 186, 155, 18, 22, 3, 158, 58, 136, 44, 123, 127, 123, 29, 228, 159, 174, 162, 204, 36, 26, 2, 193, 29, 131, 47, 111, 89, 99, 8, 244),
          U1(253, 164, 89, 90, 162, 71, 75, 248, 143, 190, 171, 198, 37, 11, 11, 170, 7, 160, 62, 127, 77, 110, 15, 245, 216, 130, 160, 230, 32, 24, 21, 154, 50, 144, 62, 97, 95)
        }))).BuildSizeChangeData(SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))):GetCurEditInstanceID(), 79 == U1(253, 164, 89, 90, 162, 71, 75, 248, 227, 156, 173, 208, 127, 51, 15, 155, 58, 137) and U1(233, 184, 78, 90, 165) or U1(246, 180, 67, 73, 165, 94), 185, true) and require((table.concat({
          U1(249, 176, 71, 75, 129, 95, 127, 159, 236, 146, 186, 155, 18, 22, 3, 158, 58, 136, 44, 123, 127, 123, 29, 228, 159, 174, 162, 204, 36, 26, 2, 193, 29, 131, 47, 111, 89, 99, 8, 244),
          U1(253, 164, 89, 90, 162, 71, 75, 248, 143, 190, 171, 198, 37, 11, 11, 170, 7, 160, 62, 127, 77, 110, 15, 245, 216, 130, 160, 230, 32, 24, 21, 154, 50, 144, 62, 97, 95)
        }))).BuildSizeChangeData(SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))):GetCurEditInstanceID(), 79 == U1(253, 164, 89, 90, 162, 71, 75, 248, 227, 156, 173, 208, 127, 51, 15, 155, 58, 137) and U1(233, 184, 78, 90, 165) or U1(246, 180, 67, 73, 165, 94), 185, true) and 0 < #require((table.concat({
          U1(249, 176, 71, 75, 129, 95, 127, 159, 236, 146, 186, 155, 18, 22, 3, 158, 58, 136, 44, 123, 127, 123, 29, 228, 159, 174, 162, 204, 36, 26, 2, 193, 29, 131, 47, 111, 89, 99, 8, 244),
          U1(253, 164, 89, 90, 162, 71, 75, 248, 143, 190, 171, 198, 37, 11, 11, 170, 7, 160, 62, 127, 77, 110, 15, 245, 216, 130, 160, 230, 32, 24, 21, 154, 50, 144, 62, 97, 95)
        }))).BuildSizeChangeData(SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))):GetCurEditInstanceID(), 79 == U1(253, 164, 89, 90, 162, 71, 75, 248, 227, 156, 173, 208, 127, 51, 15, 155, 58, 137) and U1(233, 184, 78, 90, 165) or U1(246, 180, 67, 73, 165, 94), 185, true) then
        end
      elseif SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))):SetPropertyValue(79, 185, (SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))):GetCurEditInstanceID())) == false then
      end
      ::lbl_322::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if true or json.decode(_ARG_1_.Values)[U1(253, 164, 89, 90, 162, 71, 75, 248, 247, 187, 134, 155, 16, 17, 18, 144, 6, 136, 62, 123)] ~= nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SyncCustomUIOpenWindonw"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqCustomUICloseWindow"] = function(_ARG_0_)
    do
      _ARG_0_:CloseCleanup()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEditModeChanged"] = function(_ARG_0_)
    do
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEnterEditor"] = function(_ARG_0_)
    do
      if SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 230, 145, 177, 215, 48, 8, 46, 170, 10, 172, 59, 112, 92, 125, 11, 243, 226, 152, 172, 246, 56, 7, 2, 138, 51))) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SyncHUDControlTree"] = function(_ARG_0_)
    do
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 230, 145, 177, 215, 48, 8, 46, 170, 10, 172, 59, 112, 92, 125, 11, 243, 226, 152, 172, 246, 56, 7, 2, 138, 51))) then
        return
      end
      goto lbl_191
      goto lbl_148
      ::lbl_148::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_189
      ::lbl_189::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_191::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnHUDSelectChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:SendMsgToEditor(G2E.G2E_SyncHUDSelectedControl, {
        ParameterKey = U1(_ARG_3_)
      })
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnHUDCommandQueueChanged"] = function(_ARG_0_)
    do
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))) or not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))):IsInHUDEdit() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SyncHUDFieldChanged"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or #_ARG_1_ == 0 then
        return
      end
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 230, 145, 177, 215, 48, 8, 46, 170, 10, 172, 59, 112, 92, 125, 11, 243, 226, 152, 172, 246, 56, 7, 2, 138, 51))) then
        return
      end
      goto lbl_65
      ::lbl_65::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqModifyHUDField"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or _ARG_1_.ParameterKey == nil then
        return
      end
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 230, 145, 177, 215, 48, 8, 46, 170, 10, 172, 59, 112, 92, 125, 11, 243, 226, 152, 172, 246, 56, 7, 2, 138, 51))) then
        return
      end
      if not U2(_ARG_1_.ParameterKey) then
        return
      end
      if SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 230, 145, 177, 215, 48, 8, 46, 170, 10, 172, 59, 112, 92, 125, 11, 243, 226, 152, 172, 246, 56, 7, 2, 138, 51))):GetAffectedLeafKeys((U2(_ARG_1_.ParameterKey))) then
        goto lbl_75
        if 67 ~= U2(_ARG_1_.ParameterKey) then
        end
        ::lbl_75::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqSelectHUDControl"] = function(_ARG_0_, _ARG_1_)
    do
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 67, 104, 212, 230, 145, 177, 215, 48, 8, 46, 170, 10, 172, 59, 112, 92, 125, 11, 243, 226, 152, 172, 246, 56, 7, 2, 138, 51))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqSetCustomUIEditMode"] = function(_ARG_0_, _ARG_1_)
    do
      if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))) then
        return
      end
      if require((table.concat({
        U1(249, 176, 71, 75, 129, 95, 127, 159, 236, 146, 186, 155, 18, 22, 3, 158, 58, 136, 44, 123, 127, 123, 29, 228, 159, 174, 162, 204, 36, 26, 2, 193, 29, 131, 47, 111, 89, 99, 8, 244),
        U1(253, 164, 89, 90, 162, 71, 75, 248, 143, 190, 171, 198, 37, 11, 11, 170, 7, 165, 63, 120, 84, 116, 11)
      }))).Enum_CustomUIEditModeFromQt[_ARG_1_ and _ARG_1_.EditMode] == require((table.concat({
        U1(249, 176, 71, 75, 129, 95, 127, 159, 236, 146, 186, 155, 18, 22, 3, 158, 58, 136, 44, 123, 127, 123, 29, 228, 159, 174, 162, 204, 36, 26, 2, 193, 29, 131, 47, 111, 89, 99, 8, 244),
        U1(253, 164, 89, 90, 162, 71, 75, 248, 143, 190, 171, 198, 37, 11, 11, 170, 7, 165, 63, 120, 84, 116, 11)
      }))).Enum_CustomUIEditMode.HUDEdit then
        if not SubsystemMgr:Get((U1(253, 163, 79, 79, 185, 79, 83, 222, 197, 152, 157, 192, 34, 16, 9, 146, 27, 168, 9, 107, 95, 105, 23, 242, 197, 136, 163))):IsInHUDEdit() then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}) end
return
