.version	5.3

.format	0
.int_size	4
.size_t_size	4
.instruction_size	4
.integer_format	8
.float_format	8
.endianness	LITTLE

.function	main

.source	null
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	1
.maxstacksize	54

.upvalue	"_ENV"	0	true

.constant	k0	58
.constant	k1	16
.constant	k2	39
.constant	k3	44
.constant	k4	83
.constant	k5	97
.constant	k6	144
.constant	k7	218
.constant	k8	164
.constant	k9	48
.constant	k10	84
.constant	k11	55
.constant	k12	205
.constant	k13	202
.constant	k14	167
.constant	k15	"require"
.constant	k16	"table"
.constant	k17	"concat"
.constant	k18	122
.constant	k19	87
.constant	k20	15
.constant	k21	45
.constant	k22	156
.constant	k23	182
.constant	k24	20
.constant	k25	22
.constant	k26	65
.constant	k27	13
.constant	k28	69
.constant	k29	245
.constant	k30	76
.constant	k31	30
.constant	k32	185
.constant	k33	111
.constant	k34	100
.constant	k35	29
.constant	k36	98
.constant	k37	146
.constant	k38	82
.constant	k39	101
.constant	k40	124
.constant	k41	16
.constant	k42	21
.constant	k43	199
.constant	k44	92
.constant	k45	26
.constant	k46	43
.constant	k47	188
.constant	k48	99
.constant	k49	70
.constant	k50	115
.constant	k51	145
.constant	k52	123
.constant	k53	73
.constant	k54	95
.constant	k55	157
.constant	k56	172
.constant	k57	53
.constant	k58	11
.constant	k59	60
.constant	k60	31
.constant	k61	223
.constant	k62	180
.constant	k63	121
.constant	k64	24
.constant	k65	195
.constant	k66	94
.constant	k67	14
.constant	k68	56
.constant	k69	79
.constant	k70	68
.constant	k71	130
.constant	k72	89
.constant	k73	3
.constant	k74	181
.constant	k75	52
.constant	k76	119
.constant	k77	74
.constant	k78	12
.constant	k79	62
.constant	k80	194
.constant	k81	127
.constant	k82	"ServerRPC"
.constant	k83	"ClientRPC"
.constant	k84	"ServerDataTransferRPC"
.constant	k85	"ClientDataTransferRPC"
.constant	k86	"import"
.constant	k87	126
.constant	k88	7
.constant	k89	41
.constant	k90	170
.constant	k91	91
.constant	k92	217
.constant	k93	38
.constant	k94	54
.constant	k95	137
.constant	k96	103
.constant	k97	102
.constant	k98	25
.constant	k99	116
.constant	k100	129
.constant	k101	64
.constant	k102	88
.constant	k103	28
.constant	k104	9
.constant	k105	232
.constant	k106	10
.constant	k107	"ctor"
.constant	k108	"ReceiveGetSelfTable"
.constant	k109	"HasAuthority"
.constant	k110	"ReceiveBeginPlay"
.constant	k111	"ReceiveEndPlay"
.constant	k112	"GetCDOInstanceIDOfInstance"
.constant	k113	"GetCDOInstance"
.constant	k114	"RewriteIdReferences"
.constant	k115	"CloneCDOToRuntime"
.constant	k116	"DSChangeCustomUIData"
.constant	k117	"ChangeInstance"
.constant	k118	"_SendFieldDelta"
.constant	k119	"ChangeUIVisibility"
.constant	k120	"GetInstanceChildren"
.constant	k121	"GetAllChildren"
.constant	k122	"ChangeUIVisibilityWithChildren"
.constant	k123	"_HandleVFXAutoHide"
.constant	k124	"_RemoveVFXAutoHideTimer"
.constant	k125	"OnObjectBroadcastEvent"
.constant	k126	"OnCustomEvent"
.constant	k127	"OnCustomUIClicked"
.constant	k128	"ClientTryLoadCustomUIObject"
.constant	k129	"_CreateCustomUILuaObject"
.constant	k130	"IsPreviewInstance"
.constant	k131	"RegisterInstanceIndex"
.constant	k132	"UnregisterEventIndex"
.constant	k133	"RegisterEventIndex"
.constant	k134	"NotifyTalentNodeLanded"
.constant	k135	"RecordAppliedFieldDelta"
.constant	k136	"ReplayAppliedFieldDeltas"
.constant	k137	"OnReceivePostCustomUIDataAdd"
.constant	k138	"OnReceivePreCustomUIDataRemove"
.constant	k139	"DestroyRuntimeInstance"
.constant	k140	"OnReceivePostCustomUIDataChange"
.constant	k141	"CreateRuntimeInstance"
.constant	k142	"CopyUIInstance"
.constant	k143	"ResetUIInstance"
.constant	k144	"FlushPendingLoad"
.constant	k145	"GetUIBinTableFromMap"
.constant	k146	"ClientPreloadFromMapData"
.constant	k147	"OnGameTypeChanged"
.constant	k148	"ReceiveRequestPullCustomUIDataNodeFromDs"
.constant	k149	L"ServerRPC_RequestPullCustomUIDataResumeNode"
.constant	k150	"Reliable"
.constant	k151	true
.constant	k152	"Params"
.constant	k153	"UEnums"
.constant	k154	"EPropertyClass"
.constant	k155	"UInt32"
.constant	k156	"Array"
.constant	k157	"ClientRPC_RespondCustomUIDataResumeNode"
.constant	k158	"TransferResultHandle"
.constant	k159	"table"
.constant	k160	"concat"
.constant	k161	126
.constant	k162	90
.constant	k163	11
.constant	k164	45
.constant	k165	190
.constant	k166	183
.constant	k167	3
.constant	k168	106
.constant	k169	24
.constant	k170	113
.constant	k171	59
.constant	k172	14
.constant	k173	197
.constant	k174	78
.constant	k175	28
.constant	k176	17
.constant	k177	169
.constant	k178	69
.constant	k179	103
.constant	k180	84
.constant	k181	156
.constant	k182	76
.constant	k183	95
.constant	k184	2
.constant	k185	122
.constant	k186	15
.constant	k187	199
.constant	k188	124
.constant	k189	6
.constant	k190	168
.constant	k191	123
.constant	k192	38
.constant	k193	135
.constant	k194	111
.constant	k195	83
.constant	k196	61
.constant	k197	188
.constant	k198	L"ClientRPC_RespondCustomUIDataResumeNode_Result"
.constant	k199	"CreativeWidgetObjects"
.constant	k200	"DestroyWidgetObjects"
.constant	k201	"GetWidgetObjectByRuntimeId"
.constant	k202	"GetWidgetObjectByInstanceID"
.constant	k203	"GetRuntimeIdsByCDOId"
.constant	k204	"RegisterCanvasReadyCallback"
.constant	k205	"FireCanvasReadyCallbacks"
.constant	k206	"OnCanvasChildrenReady"
.constant	k207	"OnCanvasReady"
.constant	k208	"GetCustomUIDataByInstanceID"
.constant	k209	"GetUIObjectByUUID"
.constant	k210	"ReportGameCanvasSize"
.constant	k211	"ServerRPC_ReportGameCanvasSize"
.constant	k212	true
.constant	k213	"UEnums"
.constant	k214	"EPropertyClass"
.constant	k215	"Float"
.constant	k216	"GetGameCanvasSize"
.constant	k217	"ClientRPC_SetWidgetImageByURL"
.constant	k218	"Array"
.constant	k219	"Str"
.constant	k220	"GetTreeSubsystem"
.constant	k221	"GetExpectedChildCountFromInstance"
.constant	k222	"GetCanvasIDOfWidget"
.constant	k223	"AddReadyChild"
.constant	k224	"BuildCanvasSubtree"
.constant	k225	"TriggerCanvasReady"
.constant	k226	"_DispatchCanvasReady"
.constant	k227	"OnNodeObjectReady"
.constant	k228	"OnNodeDataReady"
.constant	k229	"_DownloadAndUnpackInstanceTree"
.constant	k230	"LoadUMGAsync"
.constant	k231	"CreateUMGByCustomAssetKey"
.constant	k232	"_GetTopCanvasSortOrder"
.constant	k233	"_BuildDynamicCanvasFromBinTable"
.constant	k234	"_BuildAndSpawnUMGFromBinTable"
.constant	k235	"ReportClientUILoadResultToGEM"
.constant	k236	"WrapClientUILoadCallbackForReport"
.constant	k237	"ClientLoadUMGRes"
.constant	k238	"_GetMapCanvasSource"
.constant	k239	"CreateUMGByCanvasID"
.constant	k240	"ClientLoadUMGByCanvasID"
.constant	k241	"ClientLoadUMGForPreview"
.constant	k242	"_ClearPreviewSeq"
.constant	k243	"ClientRemoveUMGForPreview"
.constant	k244	"RemoveUMGByRuntimeID"
.constant	k245	"ClientRemoveUMGByRuntimeID"
.constant	k246	"require"
.constant	k247	94
.constant	k248	90
.constant	k249	3
.constant	k250	59
.constant	k251	163
.constant	k252	"table"
.constant	k253	"concat"
.constant	k254	122
.constant	k255	87
.constant	k256	15
.constant	k257	45
.constant	k258	156
.constant	k259	182
.constant	k260	48
.constant	k261	20
.constant	k262	22
.constant	k263	65
.constant	k264	13
.constant	k265	69
.constant	k266	244
.constant	k267	95
.constant	k268	0
.constant	k269	26
.constant	k270	128
.constant	k271	105
.constant	k272	118
.constant	k273	86
.constant	k274	99
.constant	k275	76
.constant	k276	103
.constant	k277	36
.constant	k278	80
.constant	k279	56
.constant	k280	201
.constant	k281	92
.constant	k282	6
.constant	k283	117
.constant	k284	7
.constant	k285	66
.constant	k286	160
.constant	k287	119
.constant	k288	77
.constant	k289	89
.constant	k290	12
.constant	k291	190
.constant	k292	183
.constant	k293	19
.constant	k294	91
.constant	k295	40
.constant	k296	75

.line	0	newtable      r0    16     0
.line	0	loadk         r1    k0 ; k0 = 58
.line	0	loadk         r2    k1 ; k1 = 16
.line	0	loadk         r3    k2 ; k2 = 39
.line	0	loadk         r4    k3 ; k3 = 44
.line	0	loadk         r5    k4 ; k4 = 83
.line	0	loadk         r6    k5 ; k5 = 97
.line	0	loadk         r7    k6 ; k6 = 144
.line	0	loadk         r8    k7 ; k7 = 218
.line	0	loadk         r9    k8 ; k8 = 164
.line	0	loadk        r10    k9 ; k9 = 48
.line	0	loadk        r11   k10 ; k10 = 84
.line	0	loadk        r12   k11 ; k11 = 55
.line	0	loadk        r13   k12 ; k12 = 205
.line	0	loadk        r14    k8 ; k8 = 164
.line	0	loadk        r15   k13 ; k13 = 202
.line	0	loadk        r16   k14 ; k14 = 167
.line	0	setlist       r0    16     1
.line	0	closure       r1    f0
.line	0	gettabup      r2    u0   k15 ; k15 = "require"
.line	0	gettabup      r3    u0   k16 ; k16 = "table"
.line	0	gettable      r3    r3   k17 ; k17 = "concat"
.line	0	newtable      r4     1     0
.line	0	move          r5    r1
.line	0	loadk         r6   k18 ; k18 = 122
.line	0	loadk         r7   k19 ; k19 = 87
.line	0	loadk         r8   k20 ; k20 = 15
.line	0	loadk         r9   k21 ; k21 = 45
.line	0	loadk        r10   k22 ; k22 = 156
.line	0	loadk        r11   k23 ; k23 = 182
.line	0	loadk        r12    k9 ; k9 = 48
.line	0	loadk        r13   k24 ; k24 = 20
.line	0	loadk        r14   k25 ; k25 = 22
.line	0	loadk        r15   k26 ; k26 = 65
.line	0	loadk        r16   k27 ; k27 = 13
.line	0	loadk        r17   k28 ; k28 = 69
.line	0	loadk        r18   k29 ; k29 = 245
.line	0	loadk        r19   k30 ; k30 = 76
.line	0	loadk        r20   k25 ; k25 = 22
.line	0	loadk        r21   k31 ; k31 = 30
.line	0	loadk        r22   k32 ; k32 = 185
.line	0	loadk        r23   k33 ; k33 = 111
.line	0	loadk        r24   k34 ; k34 = 100
.line	0	loadk        r25   k35 ; k35 = 29
.line	0	loadk        r26   k36 ; k36 = 98
.line	0	loadk        r27   k37 ; k37 = 146
.line	0	loadk        r28   k38 ; k38 = 82
.line	0	loadk        r29   k33 ; k33 = 111
.line	0	loadk        r30   k39 ; k39 = 101
.line	0	loadk        r31   k40 ; k40 = 124
.line	0	loadk        r32   k41 ; k41 = 16
.line	0	loadk        r33   k42 ; k42 = 21
.line	0	loadk        r34   k43 ; k43 = 199
.line	0	loadk        r35   k44 ; k44 = 92
.line	0	loadk        r36   k45 ; k45 = 26
.line	0	loadk        r37   k46 ; k46 = 43
.line	0	loadk        r38   k47 ; k47 = 188
.line	0	loadk        r39   k36 ; k36 = 98
.line	0	loadk        r40   k48 ; k48 = 99
.line	0	loadk        r41   k49 ; k49 = 70
.line	0	loadk        r42   k50 ; k50 = 115
.line	0	loadk        r43   k51 ; k51 = 145
.line	0	loadk        r44   k10 ; k10 = 84
.line	0	loadk        r45   k52 ; k52 = 123
.line	0	call          r5    41     2
.line	0	move          r6    r1
.line	0	loadk         r7   k53 ; k53 = 73
.line	0	loadk         r8   k54 ; k54 = 95
.line	0	loadk         r9   k24 ; k24 = 20
.line	0	loadk        r10   k21 ; k21 = 45
.line	0	loadk        r11   k55 ; k55 = 157
.line	0	loadk        r12   k56 ; k56 = 172
.line	0	loadk        r13   k57 ; k57 = 53
.line	0	loadk        r14   k54 ; k54 = 95
.line	0	loadk        r15   k58 ; k58 = 11
.line	0	loadk        r16   k30 ; k30 = 76
.line	0	loadk        r17   k59 ; k59 = 60
.line	0	loadk        r18   k60 ; k60 = 31
.line	0	loadk        r19   k61 ; k61 = 223
.line	0	loadk        r20   k38 ; k38 = 82
.line	0	loadk        r21   k45 ; k45 = 26
.line	0	loadk        r22   k58 ; k58 = 11
.line	0	loadk        r23   k62 ; k62 = 180
.line	0	call          r6    18     0
.line	0	setlist       r4     0     1
.line	0	call          r3     2     2
.line	0	call          r2     2     2
.line	0	gettabup      r3    u0   k15 ; k15 = "require"
.line	0	gettabup      r4    u0   k16 ; k16 = "table"
.line	0	gettable      r4    r4   k17 ; k17 = "concat"
.line	0	newtable      r5     1     0
.line	0	move          r6    r1
.line	0	loadk         r7   k18 ; k18 = 122
.line	0	loadk         r8   k19 ; k19 = 87
.line	0	loadk         r9   k20 ; k20 = 15
.line	0	loadk        r10   k21 ; k21 = 45
.line	0	loadk        r11   k22 ; k22 = 156
.line	0	loadk        r12   k23 ; k23 = 182
.line	0	loadk        r13    k9 ; k9 = 48
.line	0	loadk        r14   k24 ; k24 = 20
.line	0	loadk        r15   k25 ; k25 = 22
.line	0	loadk        r16   k26 ; k26 = 65
.line	0	loadk        r17   k27 ; k27 = 13
.line	0	loadk        r18   k28 ; k28 = 69
.line	0	loadk        r19   k29 ; k29 = 245
.line	0	loadk        r20   k30 ; k30 = 76
.line	0	loadk        r21   k25 ; k25 = 22
.line	0	loadk        r22   k31 ; k31 = 30
.line	0	loadk        r23   k32 ; k32 = 185
.line	0	loadk        r24   k33 ; k33 = 111
.line	0	loadk        r25   k34 ; k34 = 100
.line	0	loadk        r26   k35 ; k35 = 29
.line	0	loadk        r27   k36 ; k36 = 98
.line	0	loadk        r28   k37 ; k37 = 146
.line	0	loadk        r29   k38 ; k38 = 82
.line	0	loadk        r30   k33 ; k33 = 111
.line	0	loadk        r31   k39 ; k39 = 101
.line	0	loadk        r32   k63 ; k63 = 121
.line	0	loadk        r33   k64 ; k64 = 24
.line	0	loadk        r34   k25 ; k25 = 22
.line	0	loadk        r35   k65 ; k65 = 195
.line	0	loadk        r36   k66 ; k66 = 94
.line	0	loadk        r37   k20 ; k20 = 15
.line	0	loadk        r38   k67 ; k67 = 14
.line	0	loadk        r39    k8 ; k8 = 164
.line	0	loadk        r40   k68 ; k68 = 56
.line	0	loadk        r41   k69 ; k69 = 79
.line	0	loadk        r42   k27 ; k27 = 13
.line	0	loadk        r43   k70 ; k70 = 68
.line	0	loadk        r44   k71 ; k71 = 130
.line	0	loadk        r45   k60 ; k60 = 31
.line	0	loadk        r46   k72 ; k72 = 89
.line	0	call          r6    41     2
.line	0	move          r7    r1
.line	0	loadk         r8   k69 ; k69 = 79
.line	0	loadk         r9    k4 ; k4 = 83
.line	0	loadk        r10   k73 ; k73 = 3
.line	0	loadk        r11   k59 ; k59 = 60
.line	0	loadk        r12   k32 ; k32 = 185
.line	0	loadk        r13   k74 ; k74 = 181
.line	0	loadk        r14   k75 ; k75 = 52
.line	0	loadk        r15   k76 ; k76 = 119
.line	0	loadk        r16   k75 ; k75 = 52
.line	0	loadk        r17   k77 ; k77 = 74
.line	0	loadk        r18   k78 ; k78 = 12
.line	0	loadk        r19   k79 ; k79 = 62
.line	0	loadk        r20   k80 ; k80 = 194
.line	0	loadk        r21   k19 ; k19 = 87
.line	0	loadk        r22   k60 ; k60 = 31
.line	0	loadk        r23   k25 ; k25 = 22
.line	0	loadk        r24   k32 ; k32 = 185
.line	0	loadk        r25   k81 ; k81 = 127
.line	0	call          r7    19     0
.line	0	setlist       r5     0     1
.line	0	call          r4     2     2
.line	0	call          r3     2     2
.line	0	newtable      r4     0     4
.line	0	newtable      r5     0     0
.line	0	settable      r4   k82    r5 ; k82 = "ServerRPC"
.line	0	newtable      r5     0     0
.line	0	settable      r4   k83    r5 ; k83 = "ClientRPC"
.line	0	newtable      r5     0     0
.line	0	settable      r4   k84    r5 ; k84 = "ServerDataTransferRP" (truncated)
.line	0	newtable      r5     0     0
.line	0	settable      r4   k85    r5 ; k85 = "ClientDataTransferRP" (truncated)
.line	0	gettabup      r5    u0   k86 ; k86 = "import"
.line	0	move          r6    r1
.line	0	loadk         r7   k87 ; k87 = 126
.line	0	loadk         r8   k70 ; k70 = 68
.line	0	loadk         r9   k88 ; k88 = 7
.line	0	loadk        r10   k89 ; k89 = 41
.line	0	loadk        r11    k8 ; k8 = 164
.line	0	loadk        r12   k90 ; k90 = 170
.line	0	loadk        r13    k2 ; k2 = 39
.line	0	loadk        r14   k54 ; k54 = 95
.line	0	loadk        r15   k64 ; k64 = 24
.line	0	loadk        r16   k91 ; k91 = 91
.line	0	loadk        r17   k45 ; k45 = 26
.line	0	loadk        r18   k60 ; k60 = 31
.line	0	loadk        r19   k92 ; k92 = 217
.line	0	loadk        r20    k4 ; k4 = 83
.line	0	loadk        r21   k93 ; k93 = 38
.line	0	loadk        r22   k94 ; k94 = 54
.line	0	loadk        r23   k95 ; k95 = 137
.line	0	loadk        r24   k96 ; k96 = 103
.line	0	loadk        r25   k97 ; k97 = 102
.line	0	loadk        r26   k98 ; k98 = 25
.line	0	loadk        r27   k99 ; k99 = 116
.line	0	loadk        r28  k100 ; k100 = 129
.line	0	loadk        r29  k101 ; k101 = 64
.line	0	loadk        r30   k34 ; k34 = 100
.line	0	loadk        r31   k68 ; k68 = 56
.line	0	loadk        r32  k102 ; k102 = 88
.line	0	loadk        r33  k103 ; k103 = 28
.line	0	loadk        r34  k104 ; k104 = 9
.line	0	loadk        r35  k105 ; k105 = 232
.line	0	loadk        r36   k26 ; k26 = 65
.line	0	loadk        r37   k88 ; k88 = 7
.line	0	loadk        r38  k106 ; k106 = 10
.line	0	call          r6    33     2
.line	0	call          r5     2     2
.line	0	loadbool      r6     1     0
.line	0	closure       r7    f1
.line	0	settable      r4  k107    r7 ; k107 = "ctor"
.line	0	closure       r7    f2
.line	0	settable      r4  k108    r7 ; k108 = "ReceiveGetSelfTable"
.line	0	closure       r7    f3
.line	0	settable      r4  k109    r7 ; k109 = "HasAuthority"
.line	0	closure       r7    f4
.line	0	settable      r4  k110    r7 ; k110 = "ReceiveBeginPlay"
.line	0	closure       r7    f5
.line	0	settable      r4  k111    r7 ; k111 = "ReceiveEndPlay"
.line	0	closure       r7    f6
.line	0	settable      r4  k112    r7 ; k112 = "GetCDOInstanceIDOfIn" (truncated)
.line	0	closure       r7    f7
.line	0	settable      r4  k113    r7 ; k113 = "GetCDOInstance"
.line	0	closure       r7    f8
.line	0	closure       r8    f9
.line	0	settable      r4  k114    r8 ; k114 = "RewriteIdReferences"
.line	0	closure       r8   f10
.line	0	closure       r9   f11
.line	0	settable      r4  k115    r9 ; k115 = "CloneCDOToRuntime"
.line	0	closure       r9   f12
.line	0	settable      r4  k116    r9 ; k116 = "DSChangeCustomUIData"
.line	0	closure       r9   f13
.line	0	settable      r4  k117    r9 ; k117 = "ChangeInstance"
.line	0	closure       r9   f14
.line	0	settable      r4  k118    r9 ; k118 = "_SendFieldDelta"
.line	0	closure       r9   f15
.line	0	settable      r4  k119    r9 ; k119 = "ChangeUIVisibility"
.line	0	closure       r9   f16
.line	0	settable      r4  k120    r9 ; k120 = "GetInstanceChildren"
.line	0	closure       r9   f17
.line	0	settable      r4  k121    r9 ; k121 = "GetAllChildren"
.line	0	closure       r9   f18
.line	0	settable      r4  k122    r9 ; k122 = "ChangeUIVisibilityWi" (truncated)
.line	0	closure       r9   f19
.line	0	settable      r4  k123    r9 ; k123 = "_HandleVFXAutoHide"
.line	0	closure       r9   f20
.line	0	settable      r4  k124    r9 ; k124 = "_RemoveVFXAutoHideTi" (truncated)
.line	0	closure       r9   f21
.line	0	settable      r4  k125    r9 ; k125 = "OnObjectBroadcastEve" (truncated)
.line	0	closure       r9   f22
.line	0	settable      r4  k126    r9 ; k126 = "OnCustomEvent"
.line	0	closure       r9   f23
.line	0	settable      r4  k127    r9 ; k127 = "OnCustomUIClicked"
.line	0	closure       r9   f24
.line	0	settable      r4  k128    r9 ; k128 = "ClientTryLoadCustomU" (truncated)
.line	0	closure       r9   f25
.line	0	settable      r4  k129    r9 ; k129 = "_CreateCustomUILuaOb" (truncated)
.line	0	closure       r9   f26
.line	0	settable      r4  k130    r9 ; k130 = "IsPreviewInstance"
.line	0	closure       r9   f27
.line	0	settable      r4  k131    r9 ; k131 = "RegisterInstanceInde" (truncated)
.line	0	closure       r9   f28
.line	0	settable      r4  k132    r9 ; k132 = "UnregisterEventIndex"
.line	0	closure       r9   f29
.line	0	settable      r4  k133    r9 ; k133 = "RegisterEventIndex"
.line	0	closure       r9   f30
.line	0	settable      r4  k134    r9 ; k134 = "NotifyTalentNodeLand" (truncated)
.line	0	closure       r9   f31
.line	0	settable      r4  k135    r9 ; k135 = "RecordAppliedFieldDe" (truncated)
.line	0	closure       r9   f32
.line	0	settable      r4  k136    r9 ; k136 = "ReplayAppliedFieldDe" (truncated)
.line	0	closure       r9   f33
.line	0	settable      r4  k137    r9 ; k137 = "OnReceivePostCustomU" (truncated)
.line	0	closure       r9   f34
.line	0	settable      r4  k138    r9 ; k138 = "OnReceivePreCustomUI" (truncated)
.line	0	closure       r9   f35
.line	0	settable      r4  k139    r9 ; k139 = "DestroyRuntimeInstan" (truncated)
.line	0	closure       r9   f36
.line	0	settable      r4  k140    r9 ; k140 = "OnReceivePostCustomU" (truncated)
.line	0	closure       r9   f37
.line	0	settable      r4  k141    r9 ; k141 = "CreateRuntimeInstanc" (truncated)
.line	0	closure       r9   f38
.line	0	settable      r4  k142    r9 ; k142 = "CopyUIInstance"
.line	0	closure       r9   f39
.line	0	settable      r4  k143    r9 ; k143 = "ResetUIInstance"
.line	0	closure       r9   f40
.line	0	settable      r4  k144    r9 ; k144 = "FlushPendingLoad"
.line	0	closure       r9   f41
.line	0	settable      r4  k145    r9 ; k145 = "GetUIBinTableFromMap"
.line	0	closure       r9   f42
.line	0	settable      r4  k146    r9 ; k146 = "ClientPreloadFromMap" (truncated)
.line	0	closure       r9   f43
.line	0	settable      r4  k147    r9 ; k147 = "OnGameTypeChanged"
.line	0	closure       r9   f44
.line	0	settable      r4  k148    r9 ; k148 = "ReceiveRequestPullCu" (truncated)
.line	0	gettable      r9    r4   k82 ; k82 = "ServerRPC"
.line	0	newtable     r10     0     2
.line	0	settable     r10  k150  k151 ; k151 = true
.line	0	newtable     r11     2     0
.line	0	gettabup     r12    u0  k153 ; k153 = "UEnums"
.line	0	gettable     r12   r12  k154 ; k154 = "EPropertyClass"
.line	0	gettable     r12   r12  k155 ; k155 = "UInt32"
.line	0	newtable     r13     2     0
.line	0	gettabup     r14    u0  k153 ; k153 = "UEnums"
.line	0	gettable     r14   r14  k154 ; k154 = "EPropertyClass"
.line	0	gettable     r14   r14  k156 ; k156 = "Array"
.line	0	gettabup     r15    u0  k153 ; k153 = "UEnums"
.line	0	gettable     r15   r15  k154 ; k154 = "EPropertyClass"
.line	0	gettable     r15   r15  k155 ; k155 = "UInt32"
.line	0	setlist      r13     2     1
.line	0	setlist      r11     2     1
.line	0	settable     r10  k152   r11 ; k152 = "Params"
.line	0	settable      r9  k149   r10 ; k149 = L"ServerRPC_RequestPul" (truncated)
.line	0	closure       r9   f45
.line	0	settable      r4  k149    r9 ; k149 = L"ServerRPC_RequestPul" (truncated)
.line	0	gettable      r9    r4   k85 ; k85 = "ClientDataTransferRP" (truncated)
.line	0	newtable     r10     0     1
.line	0	gettabup     r11    u0  k159 ; k159 = "table"
.line	0	gettable     r11   r11  k160 ; k160 = "concat"
.line	0	newtable     r12     1     0
.line	0	move         r13    r1
.line	0	loadk        r14  k161 ; k161 = 126
.line	0	loadk        r15  k162 ; k162 = 90
.line	0	loadk        r16  k163 ; k163 = 11
.line	0	loadk        r17  k164 ; k164 = 45
.line	0	loadk        r18  k165 ; k165 = 190
.line	0	loadk        r19  k166 ; k166 = 183
.line	0	loadk        r20  k167 ; k167 = 3
.line	0	loadk        r21  k168 ; k168 = 106
.line	0	loadk        r22  k169 ; k169 = 24
.line	0	loadk        r23  k170 ; k170 = 113
.line	0	loadk        r24  k171 ; k171 = 59
.line	0	loadk        r25  k172 ; k172 = 14
.line	0	loadk        r26  k173 ; k173 = 197
.line	0	loadk        r27  k174 ; k174 = 78
.line	0	loadk        r28  k175 ; k175 = 28
.line	0	loadk        r29  k176 ; k176 = 17
.line	0	loadk        r30  k177 ; k177 = 169
.line	0	loadk        r31  k178 ; k178 = 69
.line	0	loadk        r32  k179 ; k179 = 103
.line	0	loadk        r33  k163 ; k163 = 11
.line	0	loadk        r34  k180 ; k180 = 84
.line	0	loadk        r35  k181 ; k181 = 156
.line	0	loadk        r36  k182 ; k182 = 76
.line	0	loadk        r37  k183 ; k183 = 95
.line	0	loadk        r38  k184 ; k184 = 2
.line	0	loadk        r39  k185 ; k185 = 122
.line	0	loadk        r40  k169 ; k169 = 24
.line	0	loadk        r41  k186 ; k186 = 15
.line	0	loadk        r42  k187 ; k187 = 199
.line	0	loadk        r43  k188 ; k188 = 124
.line	0	loadk        r44  k189 ; k189 = 6
.line	0	loadk        r45  k175 ; k175 = 28
.line	0	loadk        r46  k190 ; k190 = 168
.line	0	loadk        r47  k191 ; k191 = 123
.line	0	loadk        r48  k179 ; k179 = 103
.line	0	loadk        r49  k192 ; k192 = 38
.line	0	loadk        r50  k183 ; k183 = 95
.line	0	loadk        r51  k193 ; k193 = 135
.line	0	loadk        r52  k180 ; k180 = 84
.line	0	loadk        r53  k178 ; k178 = 69
.line	0	call         r13    41     2
.line	0	move         r14    r1
.line	0	loadk        r15  k194 ; k194 = 111
.line	0	loadk        r16  k195 ; k195 = 83
.line	0	loadk        r17  k176 ; k176 = 17
.line	0	loadk        r18  k196 ; k196 = 61
.line	0	loadk        r19  k197 ; k197 = 188
.line	0	loadk        r20  k166 ; k166 = 183
.line	0	call         r14     7     0
.line	0	setlist      r12     0     1
.line	0	call         r11     2     2
.line	0	settable     r10  k158   r11 ; k158 = "TransferResultHandle"
.line	0	settable      r9  k157   r10 ; k157 = "ClientRPC_RespondCus" (truncated)
.line	0	closure       r9   f46
.line	0	settable      r4  k198    r9 ; k198 = L"ClientRPC_RespondCus" (truncated)
.line	0	closure       r9   f47
.line	0	settable      r4  k157    r9 ; k157 = "ClientRPC_RespondCus" (truncated)
.line	0	closure       r9   f48
.line	0	settable      r4  k199    r9 ; k199 = "CreativeWidgetObject" (truncated)
.line	0	closure       r9   f49
.line	0	settable      r4  k200    r9 ; k200 = "DestroyWidgetObjects"
.line	0	closure       r9   f50
.line	0	settable      r4  k201    r9 ; k201 = "GetWidgetObjectByRun" (truncated)
.line	0	closure       r9   f51
.line	0	settable      r4  k202    r9 ; k202 = "GetWidgetObjectByIns" (truncated)
.line	0	closure       r9   f52
.line	0	settable      r4  k203    r9 ; k203 = "GetRuntimeIdsByCDOId"
.line	0	closure       r9   f53
.line	0	settable      r4  k204    r9 ; k204 = "RegisterCanvasReadyC" (truncated)
.line	0	closure       r9   f54
.line	0	settable      r4  k205    r9 ; k205 = "FireCanvasReadyCallb" (truncated)
.line	0	closure       r9   f55
.line	0	settable      r4  k206    r9 ; k206 = "OnCanvasChildrenRead" (truncated)
.line	0	closure       r9   f56
.line	0	settable      r4  k207    r9 ; k207 = "OnCanvasReady"
.line	0	closure       r9   f57
.line	0	settable      r4  k208    r9 ; k208 = "GetCustomUIDataByIns" (truncated)
.line	0	closure       r9   f58
.line	0	settable      r4  k209    r9 ; k209 = "GetUIObjectByUUID"
.line	0	closure       r9   f59
.line	0	settable      r4  k210    r9 ; k210 = "ReportGameCanvasSize"
.line	0	gettable      r9    r4   k82 ; k82 = "ServerRPC"
.line	0	newtable     r10     0     2
.line	0	settable     r10  k150  k212 ; k212 = true
.line	0	newtable     r11     2     0
.line	0	gettabup     r12    u0  k213 ; k213 = "UEnums"
.line	0	gettable     r12   r12  k214 ; k214 = "EPropertyClass"
.line	0	gettable     r12   r12  k215 ; k215 = "Float"
.line	0	gettabup     r13    u0  k213 ; k213 = "UEnums"
.line	0	gettable     r13   r13  k214 ; k214 = "EPropertyClass"
.line	0	gettable     r13   r13  k215 ; k215 = "Float"
.line	0	setlist      r11     2     1
.line	0	settable     r10  k152   r11 ; k152 = "Params"
.line	0	settable      r9  k211   r10 ; k211 = "ServerRPC_ReportGame" (truncated)
.line	0	closure       r9   f60
.line	0	settable      r4  k211    r9 ; k211 = "ServerRPC_ReportGame" (truncated)
.line	0	closure       r9   f61
.line	0	settable      r4  k216    r9 ; k216 = "GetGameCanvasSize"
.line	0	gettable      r9    r4   k83 ; k83 = "ClientRPC"
.line	0	newtable     r10     0     2
.line	0	settable     r10  k150  k212 ; k212 = true
.line	0	newtable     r11     2     0
.line	0	newtable     r12     2     0
.line	0	gettabup     r13    u0  k213 ; k213 = "UEnums"
.line	0	gettable     r13   r13  k214 ; k214 = "EPropertyClass"
.line	0	gettable     r13   r13  k218 ; k218 = "Array"
.line	0	gettabup     r14    u0  k213 ; k213 = "UEnums"
.line	0	gettable     r14   r14  k214 ; k214 = "EPropertyClass"
.line	0	gettable     r14   r14  k219 ; k219 = "Str"
.line	0	setlist      r12     2     1
.line	0	gettabup     r13    u0  k213 ; k213 = "UEnums"
.line	0	gettable     r13   r13  k214 ; k214 = "EPropertyClass"
.line	0	gettable     r13   r13  k219 ; k219 = "Str"
.line	0	setlist      r11     2     1
.line	0	settable     r10  k152   r11 ; k152 = "Params"
.line	0	settable      r9  k217   r10 ; k217 = "ClientRPC_SetWidgetI" (truncated)
.line	0	closure       r9   f62
.line	0	settable      r4  k217    r9 ; k217 = "ClientRPC_SetWidgetI" (truncated)
.line	0	closure       r9   f63
.line	0	settable      r4  k220    r9 ; k220 = "GetTreeSubsystem"
.line	0	closure       r9   f64
.line	0	settable      r4  k221    r9 ; k221 = "GetExpectedChildCoun" (truncated)
.line	0	closure       r9   f65
.line	0	settable      r4  k222    r9 ; k222 = "GetCanvasIDOfWidget"
.line	0	closure       r9   f66
.line	0	settable      r4  k223    r9 ; k223 = "AddReadyChild"
.line	0	closure       r9   f67
.line	0	settable      r4  k224    r9 ; k224 = "BuildCanvasSubtree"
.line	0	closure       r9   f68
.line	0	settable      r4  k225    r9 ; k225 = "TriggerCanvasReady"
.line	0	closure       r9   f69
.line	0	settable      r4  k226    r9 ; k226 = "_DispatchCanvasReady"
.line	0	closure       r9   f70
.line	0	settable      r4  k227    r9 ; k227 = "OnNodeObjectReady"
.line	0	closure       r9   f71
.line	0	settable      r4  k228    r9 ; k228 = "OnNodeDataReady"
.line	0	closure       r9   f72
.line	0	settable      r4  k229    r9 ; k229 = "_DownloadAndUnpackIn" (truncated)
.line	0	closure       r9   f73
.line	0	settable      r4  k230    r9 ; k230 = "LoadUMGAsync"
.line	0	closure       r9   f74
.line	0	settable      r4  k231    r9 ; k231 = "CreateUMGByCustomAss" (truncated)
.line	0	closure       r9   f75
.line	0	settable      r4  k232    r9 ; k232 = "_GetTopCanvasSortOrd" (truncated)
.line	0	closure       r9   f76
.line	0	settable      r4  k233    r9 ; k233 = "_BuildDynamicCanvasF" (truncated)
.line	0	closure       r9   f77
.line	0	settable      r4  k234    r9 ; k234 = "_BuildAndSpawnUMGFro" (truncated)
.line	0	closure       r9   f78
.line	0	settable      r4  k235    r9 ; k235 = "ReportClientUILoadRe" (truncated)
.line	0	closure       r9   f79
.line	0	settable      r4  k236    r9 ; k236 = "WrapClientUILoadCall" (truncated)
.line	0	closure       r9   f80
.line	0	settable      r4  k237    r9 ; k237 = "ClientLoadUMGRes"
.line	0	closure       r9   f81
.line	0	settable      r4  k238    r9 ; k238 = "_GetMapCanvasSource"
.line	0	closure       r9   f82
.line	0	settable      r4  k239    r9 ; k239 = "CreateUMGByCanvasID"
.line	0	closure       r9   f83
.line	0	settable      r4  k240    r9 ; k240 = "ClientLoadUMGByCanva" (truncated)
.line	0	closure       r9   f84
.line	0	settable      r4  k241    r9 ; k241 = "ClientLoadUMGForPrev" (truncated)
.line	0	closure       r9   f85
.line	0	settable      r4  k242    r9 ; k242 = "_ClearPreviewSeq"
.line	0	closure       r9   f86
.line	0	settable      r4  k243    r9 ; k243 = "ClientRemoveUMGForPr" (truncated)
.line	0	closure       r9   f87
.line	0	settable      r4  k244    r9 ; k244 = "RemoveUMGByRuntimeID"
.line	0	closure       r9   f88
.line	0	settable      r4  k245    r9 ; k245 = "ClientRemoveUMGByRun" (truncated)
.line	0	gettabup      r9    u0  k246 ; k246 = "require"
.line	0	move         r10    r1
.line	0	loadk        r11  k247 ; k247 = 94
.line	0	loadk        r12  k248 ; k248 = 90
.line	0	loadk        r13  k249 ; k249 = 3
.line	0	loadk        r14  k250 ; k250 = 59
.line	0	loadk        r15  k251 ; k251 = 163
.line	0	call         r10     6     2
.line	0	call          r9     2     2
.line	0	gettabup     r10    u0  k246 ; k246 = "require"
.line	0	gettabup     r11    u0  k252 ; k252 = "table"
.line	0	gettable     r11   r11  k253 ; k253 = "concat"
.line	0	newtable     r12     1     0
.line	0	move         r13    r1
.line	0	loadk        r14  k254 ; k254 = 122
.line	0	loadk        r15  k255 ; k255 = 87
.line	0	loadk        r16  k256 ; k256 = 15
.line	0	loadk        r17  k257 ; k257 = 45
.line	0	loadk        r18  k258 ; k258 = 156
.line	0	loadk        r19  k259 ; k259 = 182
.line	0	loadk        r20  k260 ; k260 = 48
.line	0	loadk        r21  k261 ; k261 = 20
.line	0	loadk        r22  k262 ; k262 = 22
.line	0	loadk        r23  k263 ; k263 = 65
.line	0	loadk        r24  k264 ; k264 = 13
.line	0	loadk        r25  k265 ; k265 = 69
.line	0	loadk        r26  k266 ; k266 = 244
.line	0	loadk        r27  k267 ; k267 = 95
.line	0	loadk        r28  k268 ; k268 = 0
.line	0	loadk        r29  k269 ; k269 = 26
.line	0	loadk        r30  k270 ; k270 = 128
.line	0	loadk        r31  k271 ; k271 = 105
.line	0	loadk        r32  k272 ; k272 = 118
.line	0	loadk        r33  k273 ; k273 = 86
.line	0	loadk        r34  k274 ; k274 = 99
.line	0	loadk        r35  k258 ; k258 = 156
.line	0	loadk        r36  k275 ; k275 = 76
.line	0	loadk        r37  k276 ; k276 = 103
.line	0	loadk        r38  k277 ; k277 = 36
.line	0	loadk        r39  k278 ; k278 = 80
.line	0	loadk        r40  k255 ; k255 = 87
.line	0	loadk        r41  k279 ; k279 = 56
.line	0	loadk        r42  k280 ; k280 = 201
.line	0	loadk        r43  k281 ; k281 = 92
.line	0	loadk        r44  k282 ; k282 = 6
.line	0	loadk        r45  k263 ; k263 = 65
.line	0	loadk        r46  k258 ; k258 = 156
.line	0	loadk        r47  k283 ; k283 = 117
.line	0	loadk        r48  k272 ; k272 = 118
.line	0	loadk        r49  k284 ; k284 = 7
.line	0	loadk        r50  k285 ; k285 = 66
.line	0	loadk        r51  k286 ; k286 = 160
.line	0	loadk        r52  k247 ; k247 = 94
.line	0	loadk        r53  k287 ; k287 = 119
.line	0	call         r13    41     2
.line	0	move         r14    r1
.line	0	loadk        r15  k288 ; k288 = 77
.line	0	loadk        r16  k289 ; k289 = 89
.line	0	loadk        r17  k290 ; k290 = 12
.line	0	loadk        r18  k257 ; k257 = 45
.line	0	loadk        r19  k291 ; k291 = 190
.line	0	loadk        r20  k292 ; k292 = 183
.line	0	loadk        r21  k293 ; k293 = 19
.line	0	loadk        r22  k294 ; k294 = 91
.line	0	loadk        r23  k295 ; k295 = 40
.line	0	loadk        r24  k296 ; k296 = 75
.line	0	call         r14    11     0
.line	0	setlist      r12     0     1
.line	0	call         r11     2     2
.line	0	call         r10     2     2
.line	0	move         r11    r9
.line	0	move         r12   r10
.line	0	loadnil      r13     0
.line	0	move         r14    r4
.line	0	tailcall     r11     4
.line	0	return       r11     0
.line	0	return        r0     1
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f0

.source	null
.linedefined	2
.lastlinedefined	9
.numparams	0
.is_vararg	1
.maxstacksize	9

.upvalue	"_ENV"	0	false
.upvalue	"U1"	0	true

.constant	k0	1
.constant	k1	"string"
.constant	k2	"char"
.constant	k3	16
.constant	k4	31
.constant	k5	7
.constant	k6	256
.constant	k7	"table"
.constant	k8	"concat"

.line	2	newtable      r0     0     0
.line	2	vararg        r1     0
.line	2	setlist       r0     0     1
.line	2	newtable      r1     0     0
.line	2	loadk         r2    k0 ; k0 = 1
.line	2	len           r3    r0
.line	2	loadk         r4    k0 ; k0 = 1
.line	2	move          r0    r0
.line	2	gettabup      r6    u0    k1 ; k1 = "string"
.line	2	gettable      r6    r6    k2 ; k2 = "char"
.line	2	gettable      r7    r0    r5
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mod           r8    r8    k3 ; k3 = 16
.line	2	add           r8    r8    k0 ; k0 = 1
.line	2	gettabup      r8    u1    r8
.line	2	bxor          r7    r7    r8
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mul           r8    r8    k4 ; k4 = 31
.line	2	add           r8    r8    k5 ; k5 = 7
.line	2	mod           r8    r8    k6 ; k6 = 256
.line	2	bxor          r7    r7    r8
.line	2	mod           r7    r7    k6 ; k6 = 256
.line	2	call          r6     2     2
.line	2	settable      r1    r5    r6
.line	2	move          r0    r0
.line	2	gettabup      r2    u0    k7 ; k7 = "table"
.line	2	gettable      r2    r2    k8 ; k8 = "concat"
.line	2	move          r3    r1
.line	2	tailcall      r2     2
.line	2	return        r2     0
.line	2	return        r0     1
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	return        r0     1

.function	main/f1

.source	null
.linedefined	35
.lastlinedefined	62
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false
.upvalue	"U1"	5	true

.constant	k0	"_bHasAuthority"
.constant	k1	nil
.constant	k2	"RespondResumeNodeTagMap"
.constant	k3	"RequestPullSeq"
.constant	k4	1
.constant	k5	"DefaultCustomUIDataTransferNode"
.constant	k6	"slua"
.constant	k7	"Array"
.constant	k8	"UEnums"
.constant	k9	"EPropertyClass"
.constant	k10	"Struct"
.constant	k11	"CustomUIData"
.constant	k12	"CustomUIObject"
.constant	k13	"BroadcastEventIndex"
.constant	k14	"CustomEventIndex"
.constant	k15	"UIEventIndexKeys"
.constant	k16	"_AsyncLoadSeq"
.constant	k17	0
.constant	k18	"_CancelledAsyncSeqs"
.constant	k19	"PendingCanvasReadyCallbacks"
.constant	k20	"GameCanvasSize"
.constant	k21	"bNeedCanvasSizeReport"
.constant	k22	false
.constant	k23	"InstanceChangeCache"
.constant	k24	"CDORuntimeCount"
.constant	k25	"CanvasReadyState"
.constant	k26	"CanvasBuilt"
.constant	k27	"CDOToRuntimeIds"
.constant	k28	"RuntimeToCDO"
.constant	k29	"RuntimeReady"
.constant	k30	"PendingLoadRuntimeIds"
.constant	k31	"PreviewRuntimeIds"
.constant	k32	"PreviewSeqToIds"
.constant	k33	"_VFXAutoHideTimers"
.constant	k34	"AppliedFieldDeltas"

.line	35	settable      r0    k0    k1 ; k1 = nil
.line	35	newtable      r1     0     0
.line	35	settable      r0    k2    r1 ; k2 = "RespondResumeNodeTag" (truncated)
.line	35	settable      r0    k3    k4 ; k4 = 1
.line	35	gettabup      r1    u0    k6 ; k6 = "slua"
.line	35	gettable      r1    r1    k7 ; k7 = "Array"
.line	35	gettabup      r2    u0    k8 ; k8 = "UEnums"
.line	35	gettable      r2    r2    k9 ; k9 = "EPropertyClass"
.line	35	gettable      r2    r2   k10 ; k10 = "Struct"
.line	35	getupval      r3    u1
.line	35	call          r1     3     2
.line	35	settable      r0    k5    r1 ; k5 = "DefaultCustomUIDataT" (truncated)
.line	35	newtable      r1     0     0
.line	35	settable      r0   k11    r1 ; k11 = "CustomUIData"
.line	35	newtable      r1     0     0
.line	35	settable      r0   k12    r1 ; k12 = "CustomUIObject"
.line	35	newtable      r1     0     0
.line	35	settable      r0   k13    r1 ; k13 = "BroadcastEventIndex"
.line	35	newtable      r1     0     0
.line	35	settable      r0   k14    r1 ; k14 = "CustomEventIndex"
.line	35	newtable      r1     0     0
.line	35	settable      r0   k15    r1 ; k15 = "UIEventIndexKeys"
.line	35	settable      r0   k16   k17 ; k17 = 0
.line	35	newtable      r1     0     0
.line	35	settable      r0   k18    r1 ; k18 = "_CancelledAsyncSeqs"
.line	35	newtable      r1     0     0
.line	35	settable      r0   k19    r1 ; k19 = "PendingCanvasReadyCa" (truncated)
.line	35	settable      r0   k20    k1 ; k1 = nil
.line	35	settable      r0   k21   k22 ; k22 = false
.line	35	newtable      r1     0     0
.line	35	settable      r0   k23    r1 ; k23 = "InstanceChangeCache"
.line	35	newtable      r1     0     0
.line	35	settable      r0   k24    r1 ; k24 = "CDORuntimeCount"
.line	35	newtable      r1     0     0
.line	35	settable      r0   k25    r1 ; k25 = "CanvasReadyState"
.line	35	newtable      r1     0     0
.line	35	settable      r0   k26    r1 ; k26 = "CanvasBuilt"
.line	35	newtable      r1     0     0
.line	35	settable      r0   k27    r1 ; k27 = "CDOToRuntimeIds"
.line	35	newtable      r1     0     0
.line	35	settable      r0   k28    r1 ; k28 = "RuntimeToCDO"
.line	35	newtable      r1     0     0
.line	35	settable      r0   k29    r1 ; k29 = "RuntimeReady"
.line	35	newtable      r1     0     0
.line	35	settable      r0   k30    r1 ; k30 = "PendingLoadRuntimeId" (truncated)
.line	35	newtable      r1     0     0
.line	35	settable      r0   k31    r1 ; k31 = "PreviewRuntimeIds"
.line	35	newtable      r1     0     0
.line	35	settable      r0   k32    r1 ; k32 = "PreviewSeqToIds"
.line	35	newtable      r1     0     0
.line	35	settable      r0   k33    r1 ; k33 = "_VFXAutoHideTimers"
.line	35	newtable      r1     0     0
.line	35	settable      r0   k34    r1 ; k34 = "AppliedFieldDeltas"
.line	35	return        r0     1
.line	35	move          r0    r0
.line	35	move          r0    r0
.line	35	move          r0    r0
.line	35	return        r0     1

.function	main/f2

.source	null
.linedefined	64
.lastlinedefined	66
.numparams	1
.is_vararg	0
.maxstacksize	2

.line	64	return        r0     2
.line	64	return        r0     1
.line	64	move          r0    r0
.line	64	move          r0    r0
.line	64	return        r0     1

.function	main/f3

.source	null
.linedefined	68
.lastlinedefined	76
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false

.constant	k0	"_bHasAuthority"
.constant	k1	nil
.constant	k2	"GetOwner"
.constant	k3	"slua"
.constant	k4	"isValid"
.constant	k5	"HasAuthority"
.constant	k6	true

.line	68	gettable      r1    r0    k0 ; k0 = "_bHasAuthority"
.line	68	eq             0    r1    k1 ; k1 = nil
.line	68	jmp            0   l15
.line	68	self          r1    r0    k2 ; k2 = "GetOwner"
.line	68	call          r1     2     2
.line	68	gettabup      r2    u0    k3 ; k3 = "slua"
.line	68	gettable      r2    r2    k4 ; k4 = "isValid"
.line	68	move          r3    r1
.line	68	call          r2     2     2
.line	68	test          r2     0
.line	68	jmp            0   l15
.line	68	self          r2    r1    k5 ; k5 = "HasAuthority"
.line	68	call          r2     2     2
.line	68	settable      r0    k0    r2 ; k0 = "_bHasAuthority"
.label	l15
.line	68	gettable      r1    r0    k0 ; k0 = "_bHasAuthority"
.line	68	eq             1    r1    k6 ; k6 = true
.line	68	jmp            0   l19
.line	68	loadbool      r1     0     1
.label	l19
.line	68	loadbool      r1     1     0
.line	68	return        r1     2
.line	68	return        r0     1
.line	68	move          r0    r0
.line	68	return        r0     1

.function	main/f4

.source	null
.linedefined	78
.lastlinedefined	114
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	4	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"__super"
.constant	k1	"ReceiveBeginPlay"
.constant	k2	"print"
.constant	k3	"bWriteLog"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	126
.constant	k7	68
.constant	k8	7
.constant	k9	41
.constant	k10	164
.constant	k11	170
.constant	k12	39
.constant	k13	95
.constant	k14	24
.constant	k15	91
.constant	k16	26
.constant	k17	31
.constant	k18	217
.constant	k19	83
.constant	k20	38
.constant	k21	54
.constant	k22	137
.constant	k23	103
.constant	k24	102
.constant	k25	25
.constant	k26	99
.constant	k27	156
.constant	k28	76
.constant	k29	122
.constant	k30	113
.constant	k31	108
.constant	k32	28
.constant	k33	195
.constant	k34	71
.constant	k35	21
.constant	k36	10
.constant	k37	159
.constant	k38	115
.constant	k39	101
.constant	k40	1
.constant	k41	94
.constant	k42	179
.constant	k43	93
.constant	k44	123
.constant	k45	"SingleSerializeNum"
.constant	k46	150
.constant	k47	"SinglePullDataNodeNum"
.constant	k48	50
.constant	k49	"DataNodePullTimeroutInterval"
.constant	k50	5
.constant	k51	"GetOwner"
.constant	k52	"slua"
.constant	k53	"isValid"
.constant	k54	"_bHasAuthority"
.constant	k55	"HasAuthority"
.constant	k56	"GetLoadManager"
.constant	k57	"bNewCustomUI"
.constant	k58	"AddCommonEvent"
.constant	k59	"EVENTTYPE_CREATIVE"
.constant	k60	"EVENTID_CREATIVE_OBJECT_BROADCAST_EVENT"
.constant	k61	"OnObjectBroadcastEvent"
.constant	k62	"EVENTID_CUSTOM_EVENT"
.constant	k63	"OnCustomEvent"
.constant	k64	"EVENTID_CUSTOMUI_CLICKED"
.constant	k65	"OnCustomUIClicked"
.constant	k66	"bNeedCanvasSizeReport"
.constant	k67	true
.constant	k68	"AddControlEvent"
.constant	k69	109
.constant	k70	90
.constant	k71	3
.constant	k72	49
.constant	k73	181
.constant	k74	177
.constant	k75	18
.constant	k76	85
.constant	k77	53
.constant	k78	27
.constant	k79	4
.constant	k80	218
.constant	k81	82
.constant	k82	22
.constant	k83	13
.constant	k84	129
.constant	k85	105
.constant	k86	97
.constant	k87	12
.constant	k88	100
.constant	k89	77
.constant	k90	111
.constant	k91	44
.constant	k92	30
.constant	k93	13
.constant	k94	140
.constant	k95	125
.constant	k96	84
.constant	k97	167
.constant	k98	78
.constant	k99	79
.constant	k100	51
.constant	k101	87
.constant	k102	63
.constant	k103	66
.constant	k104	6
.constant	k105	8
.constant	k106	188
.constant	k107	98
.constant	k108	103
.constant	k109	"EVENTID_CUSTOMUI_CANVAS_CHILDREN_READY"
.constant	k110	"OnCanvasChildrenReady"
.constant	k111	"EVENTID_GAMETYPE_CHANGED"
.constant	k112	"OnGameTypeChanged"
.constant	k113	"import"
.constant	k114	120
.constant	k115	117
.constant	k116	16
.constant	k117	45
.constant	k118	183
.constant	k119	56
.constant	k120	76
.constant	k121	62
.constant	k122	99
.constant	k123	15
.constant	k124	211
.constant	k125	121
.constant	k126	168
.constant	k127	107
.constant	k128	69
.constant	k129	"CGameState"
.constant	k130	"GetCurrentGameType"
.constant	k131	"CreativeModeGameType_Game"
.constant	k132	"CopyUIInstance"

.line	78	gettabup      r1    u0    k0 ; k0 = "__super"
.line	78	gettable      r1    r1    k1 ; k1 = "ReceiveBeginPlay"
.line	78	move          r2    r0
.line	78	call          r1     2     1
.line	78	gettabup      r1    u1    k2 ; k2 = "print"
.line	78	gettabup      r2    u1    k3 ; k3 = "bWriteLog"
.line	78	test          r2     0
.line	78	jmp            0   l59
.line	78	gettabup      r2    u1    k4 ; k4 = "table"
.line	78	gettable      r2    r2    k5 ; k5 = "concat"
.line	78	newtable      r3     1     0
.line	78	getupval      r4    u2
.line	78	loadk         r5    k6 ; k6 = 126
.line	78	loadk         r6    k7 ; k7 = 68
.line	78	loadk         r7    k8 ; k8 = 7
.line	78	loadk         r8    k9 ; k9 = 41
.line	78	loadk         r9   k10 ; k10 = 164
.line	78	loadk        r10   k11 ; k11 = 170
.line	78	loadk        r11   k12 ; k12 = 39
.line	78	loadk        r12   k13 ; k13 = 95
.line	78	loadk        r13   k14 ; k14 = 24
.line	78	loadk        r14   k15 ; k15 = 91
.line	78	loadk        r15   k16 ; k16 = 26
.line	78	loadk        r16   k17 ; k17 = 31
.line	78	loadk        r17   k18 ; k18 = 217
.line	78	loadk        r18   k19 ; k19 = 83
.line	78	loadk        r19   k20 ; k20 = 38
.line	78	loadk        r20   k21 ; k21 = 54
.line	78	loadk        r21   k22 ; k22 = 137
.line	78	loadk        r22   k23 ; k23 = 103
.line	78	loadk        r23   k24 ; k24 = 102
.line	78	loadk        r24   k25 ; k25 = 25
.line	78	loadk        r25   k26 ; k26 = 99
.line	78	loadk        r26   k27 ; k27 = 156
.line	78	loadk        r27   k28 ; k28 = 76
.line	78	loadk        r28   k29 ; k29 = 122
.line	78	loadk        r29   k30 ; k30 = 113
.line	78	loadk        r30   k31 ; k31 = 108
.line	78	loadk        r31   k32 ; k32 = 28
.line	78	loadk        r32   k14 ; k14 = 24
.line	78	loadk        r33   k33 ; k33 = 195
.line	78	loadk        r34   k34 ; k34 = 71
.line	78	loadk        r35   k35 ; k35 = 21
.line	78	loadk        r36   k36 ; k36 = 10
.line	78	loadk        r37   k37 ; k37 = 159
.line	78	loadk        r38   k38 ; k38 = 115
.line	78	loadk        r39   k39 ; k39 = 101
.line	78	loadk        r40   k40 ; k40 = 1
.line	78	loadk        r41   k41 ; k41 = 94
.line	78	loadk        r42   k42 ; k42 = 179
.line	78	loadk        r43   k43 ; k43 = 93
.line	78	loadk        r44   k44 ; k44 = 123
.line	78	call          r4    41     2
.line	78	getupval      r5    u2
.line	78	loadk         r6    k7 ; k7 = 68
.line	78	call          r5     2     0
.line	78	setlist       r3     0     1
.line	78	call          r2     2     2
.label	l59
.line	78	call          r1     2     1
.line	78	settable      r0   k45   k46 ; k46 = 150
.line	78	settable      r0   k47   k48 ; k48 = 50
.line	78	settable      r0   k49   k50 ; k50 = 5
.line	78	self          r1    r0   k51 ; k51 = "GetOwner"
.line	78	call          r1     2     2
.line	78	gettabup      r2    u1   k52 ; k52 = "slua"
.line	78	gettable      r2    r2   k53 ; k53 = "isValid"
.line	78	move          r3    r1
.line	78	call          r2     2     2
.line	78	test          r2     0
.line	78	jmp            0   l74
.line	78	self          r2    r1   k55 ; k55 = "HasAuthority"
.line	78	call          r2     2     2
.line	78	settable      r0   k54    r2 ; k54 = "_bHasAuthority"
.label	l74
.line	78	self          r2    r0   k55 ; k55 = "HasAuthority"
.line	78	call          r2     2     2
.line	78	test          r2     0
.line	78	jmp            0  l180
.line	78	gettabup      r2    u1   k56 ; k56 = "GetLoadManager"
.line	78	call          r2     1     2
.line	78	test          r2     0
.line	78	jmp            0  l103
.line	78	gettable      r3    r2   k57 ; k57 = "bNewCustomUI"
.line	78	test          r3     0
.line	78	jmp            0  l103
.line	78	self          r3    r0   k58 ; k58 = "AddCommonEvent"
.line	78	gettabup      r5    u1   k59 ; k59 = "EVENTTYPE_CREATIVE"
.line	78	gettabup      r6    u1   k60 ; k60 = "EVENTID_CREATIVE_OBJ" (truncated)
.line	78	gettable      r7    r0   k61 ; k61 = "OnObjectBroadcastEve" (truncated)
.line	78	move          r8    r0
.line	78	call          r3     6     1
.line	78	self          r3    r0   k58 ; k58 = "AddCommonEvent"
.line	78	gettabup      r5    u1   k59 ; k59 = "EVENTTYPE_CREATIVE"
.line	78	gettabup      r6    u1   k62 ; k62 = "EVENTID_CUSTOM_EVENT"
.line	78	gettable      r7    r0   k63 ; k63 = "OnCustomEvent"
.line	78	move          r8    r0
.line	78	call          r3     6     1
.line	78	self          r3    r0   k58 ; k58 = "AddCommonEvent"
.line	78	gettabup      r5    u1   k59 ; k59 = "EVENTTYPE_CREATIVE"
.line	78	gettabup      r6    u1   k64 ; k64 = "EVENTID_CUSTOMUI_CLI" (truncated)
.line	78	gettable      r7    r0   k65 ; k65 = "OnCustomUIClicked"
.line	78	move          r8    r0
.line	78	call          r3     6     1
.label	l103
.line	78	settable      r0   k66   k67 ; k67 = true
.line	78	self          r3    r0   k68 ; k68 = "AddControlEvent"
.line	78	move          r5    r1
.line	78	getupval      r6    u2
.line	78	loadk         r7   k69 ; k69 = 109
.line	78	loadk         r8   k70 ; k70 = 90
.line	78	loadk         r9   k71 ; k71 = 3
.line	78	loadk        r10   k72 ; k72 = 49
.line	78	loadk        r11   k73 ; k73 = 181
.line	78	loadk        r12   k74 ; k74 = 177
.line	78	loadk        r13   k75 ; k75 = 18
.line	78	loadk        r14   k76 ; k76 = 85
.line	78	loadk        r15   k77 ; k77 = 53
.line	78	loadk        r16   k70 ; k70 = 90
.line	78	loadk        r17   k78 ; k78 = 27
.line	78	loadk        r18   k79 ; k79 = 4
.line	78	loadk        r19   k80 ; k80 = 218
.line	78	loadk        r20   k81 ; k81 = 82
.line	78	loadk        r21   k82 ; k82 = 22
.line	78	loadk        r22   k83 ; k83 = 13
.line	78	loadk        r23   k84 ; k84 = 129
.line	78	loadk        r24   k85 ; k85 = 105
.line	78	loadk        r25   k86 ; k86 = 97
.line	78	loadk        r26   k87 ; k87 = 12
.line	78	loadk        r27   k88 ; k88 = 100
.line	78	loadk        r28   k46 ; k46 = 150
.line	78	loadk        r29   k89 ; k89 = 77
.line	78	loadk        r30   k90 ; k90 = 111
.line	78	loadk        r31   k91 ; k91 = 44
.line	78	loadk        r32   k13 ; k13 = 95
.line	78	loadk        r33   k83 ; k83 = 13
.line	78	loadk        r34   k92 ; k92 = 30
.line	78	call          r6    29     2
.line	78	closure       r7    f0
.line	78	call          r3     5     1
.line	78	self          r3    r0   k68 ; k68 = "AddControlEvent"
.line	78	move          r5    r1
.line	78	getupval      r6    u2
.line	78	loadk         r7   k69 ; k69 = 109
.line	78	loadk         r8   k70 ; k70 = 90
.line	78	loadk         r9   k71 ; k71 = 3
.line	78	loadk        r10   k72 ; k72 = 49
.line	78	loadk        r11   k73 ; k73 = 181
.line	78	loadk        r12   k74 ; k74 = 177
.line	78	loadk        r13   k75 ; k75 = 18
.line	78	loadk        r14   k76 ; k76 = 85
.line	78	loadk        r15   k77 ; k77 = 53
.line	78	loadk        r16   k70 ; k70 = 90
.line	78	loadk        r17   k78 ; k78 = 27
.line	78	loadk        r18   k79 ; k79 = 4
.line	78	loadk        r19   k80 ; k80 = 218
.line	78	loadk        r20   k81 ; k81 = 82
.line	78	loadk        r21   k82 ; k82 = 22
.line	78	loadk        r22   k93 ; k93 = 13
.line	78	loadk        r23   k94 ; k94 = 140
.line	78	loadk        r24   k88 ; k88 = 100
.line	78	loadk        r25   k95 ; k95 = 125
.line	78	loadk        r26   k93 ; k93 = 13
.line	78	loadk        r27   k96 ; k96 = 84
.line	78	loadk        r28   k97 ; k97 = 167
.line	78	loadk        r29   k98 ; k98 = 78
.line	78	loadk        r30   k99 ; k99 = 79
.line	78	loadk        r31  k100 ; k100 = 51
.line	78	loadk        r32  k101 ; k101 = 87
.line	78	loadk        r33   k93 ; k93 = 13
.line	78	loadk        r34  k102 ; k102 = 63
.line	78	loadk        r35   k33 ; k33 = 195
.line	78	loadk        r36  k103 ; k103 = 66
.line	78	loadk        r37  k104 ; k104 = 6
.line	78	loadk        r38  k105 ; k105 = 8
.line	78	loadk        r39  k106 ; k106 = 188
.line	78	loadk        r40  k107 ; k107 = 98
.line	78	loadk        r41  k108 ; k108 = 103
.line	78	call          r6    36     2
.line	78	closure       r7    f1
.line	78	call          r3     5     1
.line	78	jmp            0  l186
.label	l180
.line	78	self          r2    r0   k58 ; k58 = "AddCommonEvent"
.line	78	gettabup      r4    u1   k59 ; k59 = "EVENTTYPE_CREATIVE"
.line	78	gettabup      r5    u1  k109 ; k109 = "EVENTID_CUSTOMUI_CAN" (truncated)
.line	78	gettable      r6    r0  k110 ; k110 = "OnCanvasChildrenRead" (truncated)
.line	78	move          r7    r0
.line	78	call          r2     6     1
.label	l186
.line	78	self          r2    r0   k58 ; k58 = "AddCommonEvent"
.line	78	gettabup      r4    u1   k59 ; k59 = "EVENTTYPE_CREATIVE"
.line	78	gettabup      r5    u1  k111 ; k111 = "EVENTID_GAMETYPE_CHA" (truncated)
.line	78	gettable      r6    r0  k112 ; k112 = "OnGameTypeChanged"
.line	78	move          r7    r0
.line	78	call          r2     6     1
.line	78	self          r2    r0   k55 ; k55 = "HasAuthority"
.line	78	call          r2     2     2
.line	78	test          r2     0
.line	78	jmp            0  l238
.line	78	gettabup      r2    u1  k113 ; k113 = "import"
.line	78	getupval      r3    u2
.line	78	loadk         r4  k114 ; k114 = 120
.line	78	loadk         r5  k115 ; k115 = 117
.line	78	loadk         r6  k116 ; k116 = 16
.line	78	loadk         r7  k117 ; k117 = 45
.line	78	loadk         r8   k74 ; k74 = 177
.line	78	loadk         r9  k118 ; k118 = 183
.line	78	loadk        r10  k119 ; k119 = 56
.line	78	loadk        r11  k120 ; k120 = 76
.line	78	loadk        r12  k121 ; k121 = 62
.line	78	loadk        r13  k122 ; k122 = 99
.line	78	loadk        r14  k104 ; k104 = 6
.line	78	loadk        r15  k123 ; k123 = 15
.line	78	loadk        r16  k124 ; k124 = 211
.line	78	loadk        r17  k125 ; k125 = 121
.line	78	loadk        r18   k75 ; k75 = 18
.line	78	loadk        r19   k75 ; k75 = 18
.line	78	loadk        r20  k126 ; k126 = 168
.line	78	loadk        r21   k81 ; k81 = 82
.line	78	loadk        r22  k127 ; k127 = 107
.line	78	loadk        r23  k105 ; k105 = 8
.line	78	loadk        r24  k128 ; k128 = 69
.line	78	call          r3    22     2
.line	78	call          r2     2     2
.line	78	gettabup      r3    u1  k129 ; k129 = "CGameState"
.line	78	test          r3     0
.line	78	jmp            0  l238
.line	78	gettabup      r3    u1   k52 ; k52 = "slua"
.line	78	gettable      r3    r3   k53 ; k53 = "isValid"
.line	78	gettabup      r4    u1  k129 ; k129 = "CGameState"
.line	78	call          r3     2     2
.line	78	test          r3     0
.line	78	jmp            0  l238
.line	78	gettabup      r3    u1  k129 ; k129 = "CGameState"
.line	78	self          r3    r3  k130 ; k130 = "GetCurrentGameType"
.line	78	call          r3     2     2
.line	78	gettable      r4    r2  k131 ; k131 = "CreativeModeGameType" (truncated)
.line	78	eq             0    r3    r4
.line	78	jmp            0  l238
.line	78	self          r3    r0  k132 ; k132 = "CopyUIInstance"
.line	78	call          r3     2     1
.label	l238
.line	78	return        r0     1
.line	78	move          r0    r0
.line	78	move          r0    r0
.line	78	move          r0    r0
.line	78	return        r0     1

.function	main/f4/f0

.source	null
.linedefined	96
.lastlinedefined	99
.numparams	0
.is_vararg	0
.maxstacksize	44

.upvalue	"_ENV"	1	false
.upvalue	"U1"	2	false
.upvalue	"U2"	1	true
.upvalue	"U3"	0	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	126
.constant	k5	68
.constant	k6	7
.constant	k7	41
.constant	k8	164
.constant	k9	170
.constant	k10	39
.constant	k11	95
.constant	k12	24
.constant	k13	91
.constant	k14	26
.constant	k15	31
.constant	k16	217
.constant	k17	83
.constant	k18	38
.constant	k19	54
.constant	k20	137
.constant	k21	103
.constant	k22	102
.constant	k23	25
.constant	k24	99
.constant	k25	156
.constant	k26	76
.constant	k27	122
.constant	k28	113
.constant	k29	110
.constant	k30	21
.constant	k31	223
.constant	k32	75
.constant	k33	17
.constant	k34	44
.constant	k35	178
.constant	k36	120
.constant	k37	118
.constant	k38	143
.constant	k39	93
.constant	k40	127
.constant	k41	79
.constant	k42	13
.constant	k43	59
.constant	k44	135
.constant	k45	52
.constant	k46	86
.constant	k47	62
.constant	k48	73
.constant	k49	8
.constant	k50	211
.constant	k51	30
.constant	k52	35
.constant	k53	19
.constant	k54	172
.constant	k55	119
.constant	k56	10
.constant	k57	107
.constant	k58	150
.constant	k59	88
.constant	k60	48
.constant	k61	"tostring"
.constant	k62	"PlayerKey"
.constant	k63	"bNeedCanvasSizeReport"
.constant	k64	true

.line	96	gettabup      r0    u0    k0 ; k0 = "print"
.line	96	gettabup      r1    u0    k1 ; k1 = "bWriteLog"
.line	96	test          r1     0
.line	96	jmp            0   l82
.line	96	gettabup      r1    u0    k2 ; k2 = "table"
.line	96	gettable      r1    r1    k3 ; k3 = "concat"
.line	96	newtable      r2     1     0
.line	96	getupval      r3    u1
.line	96	loadk         r4    k4 ; k4 = 126
.line	96	loadk         r5    k5 ; k5 = 68
.line	96	loadk         r6    k6 ; k6 = 7
.line	96	loadk         r7    k7 ; k7 = 41
.line	96	loadk         r8    k8 ; k8 = 164
.line	96	loadk         r9    k9 ; k9 = 170
.line	96	loadk        r10   k10 ; k10 = 39
.line	96	loadk        r11   k11 ; k11 = 95
.line	96	loadk        r12   k12 ; k12 = 24
.line	96	loadk        r13   k13 ; k13 = 91
.line	96	loadk        r14   k14 ; k14 = 26
.line	96	loadk        r15   k15 ; k15 = 31
.line	96	loadk        r16   k16 ; k16 = 217
.line	96	loadk        r17   k17 ; k17 = 83
.line	96	loadk        r18   k18 ; k18 = 38
.line	96	loadk        r19   k19 ; k19 = 54
.line	96	loadk        r20   k20 ; k20 = 137
.line	96	loadk        r21   k21 ; k21 = 103
.line	96	loadk        r22   k22 ; k22 = 102
.line	96	loadk        r23   k23 ; k23 = 25
.line	96	loadk        r24   k24 ; k24 = 99
.line	96	loadk        r25   k25 ; k25 = 156
.line	96	loadk        r26   k26 ; k26 = 76
.line	96	loadk        r27   k27 ; k27 = 122
.line	96	loadk        r28   k28 ; k28 = 113
.line	96	loadk        r29   k29 ; k29 = 110
.line	96	loadk        r30   k30 ; k30 = 21
.line	96	loadk        r31   k14 ; k14 = 26
.line	96	loadk        r32   k31 ; k31 = 223
.line	96	loadk        r33   k32 ; k32 = 75
.line	96	loadk        r34   k33 ; k33 = 17
.line	96	loadk        r35   k34 ; k34 = 44
.line	96	loadk        r36   k35 ; k35 = 178
.line	96	loadk        r37   k36 ; k36 = 120
.line	96	loadk        r38   k37 ; k37 = 118
.line	96	loadk        r39   k14 ; k14 = 26
.line	96	loadk        r40   k11 ; k11 = 95
.line	96	loadk        r41   k38 ; k38 = 143
.line	96	loadk        r42   k39 ; k39 = 93
.line	96	loadk        r43   k40 ; k40 = 127
.line	96	call          r3    41     2
.line	96	getupval      r4    u1
.line	96	loadk         r5   k41 ; k41 = 79
.line	96	loadk         r6   k27 ; k27 = 122
.line	96	loadk         r7   k42 ; k42 = 13
.line	96	loadk         r8   k43 ; k43 = 59
.line	96	loadk         r9    k8 ; k8 = 164
.line	96	loadk        r10   k44 ; k44 = 135
.line	96	loadk        r11   k45 ; k45 = 52
.line	96	loadk        r12   k46 ; k46 = 86
.line	96	loadk        r13   k47 ; k47 = 62
.line	96	loadk        r14   k48 ; k48 = 73
.line	96	loadk        r15   k49 ; k49 = 8
.line	96	loadk        r16   k15 ; k15 = 31
.line	96	loadk        r17   k50 ; k50 = 211
.line	96	loadk        r18   k51 ; k51 = 30
.line	96	loadk        r19   k52 ; k52 = 35
.line	96	loadk        r20   k53 ; k53 = 19
.line	96	loadk        r21   k54 ; k54 = 172
.line	96	loadk        r22   k40 ; k40 = 127
.line	96	loadk        r23   k55 ; k55 = 119
.line	96	loadk        r24   k56 ; k56 = 10
.line	96	loadk        r25   k57 ; k57 = 107
.line	96	loadk        r26   k58 ; k58 = 150
.line	96	loadk        r27   k59 ; k59 = 88
.line	96	loadk        r28   k60 ; k60 = 48
.line	96	call          r4    25     0
.line	96	setlist       r2     0     1
.line	96	call          r1     2     2
.line	96	gettabup      r2    u0   k61 ; k61 = "tostring"
.line	96	gettabup      r3    u2   k62 ; k62 = "PlayerKey"
.line	96	call          r2     2     2
.line	96	concat        r1    r1    r2
.label	l82
.line	96	call          r0     2     1
.line	96	settabup      u3   k63   k64 ; k64 = true
.line	96	return        r0     1
.line	96	move          r0    r0
.line	96	move          r0    r0
.line	96	return        r0     1

.function	main/f4/f1

.source	null
.linedefined	100
.lastlinedefined	103
.numparams	0
.is_vararg	0
.maxstacksize	44

.upvalue	"_ENV"	1	false
.upvalue	"U1"	2	false
.upvalue	"U2"	1	true
.upvalue	"U3"	0	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	126
.constant	k5	68
.constant	k6	7
.constant	k7	41
.constant	k8	164
.constant	k9	170
.constant	k10	39
.constant	k11	95
.constant	k12	24
.constant	k13	91
.constant	k14	26
.constant	k15	31
.constant	k16	217
.constant	k17	83
.constant	k18	38
.constant	k19	54
.constant	k20	137
.constant	k21	103
.constant	k22	102
.constant	k23	25
.constant	k24	99
.constant	k25	156
.constant	k26	76
.constant	k27	122
.constant	k28	113
.constant	k29	110
.constant	k30	21
.constant	k31	223
.constant	k32	75
.constant	k33	17
.constant	k34	44
.constant	k35	178
.constant	k36	120
.constant	k37	118
.constant	k38	143
.constant	k39	93
.constant	k40	127
.constant	k41	79
.constant	k42	119
.constant	k43	0
.constant	k44	165
.constant	k45	183
.constant	k46	5
.constant	k47	85
.constant	k48	30
.constant	k49	86
.constant	k50	242
.constant	k51	29
.constant	k52	163
.constant	k53	77
.constant	k54	107
.constant	k55	50
.constant	k56	11
.constant	k57	48
.constant	k58	195
.constant	k59	87
.constant	k60	89
.constant	k61	"tostring"
.constant	k62	"PlayerKey"
.constant	k63	"bNeedCanvasSizeReport"
.constant	k64	true

.line	100	gettabup      r0    u0    k0 ; k0 = "print"
.line	100	gettabup      r1    u0    k1 ; k1 = "bWriteLog"
.line	100	test          r1     0
.line	100	jmp            0   l89
.line	100	gettabup      r1    u0    k2 ; k2 = "table"
.line	100	gettable      r1    r1    k3 ; k3 = "concat"
.line	100	newtable      r2     1     0
.line	100	getupval      r3    u1
.line	100	loadk         r4    k4 ; k4 = 126
.line	100	loadk         r5    k5 ; k5 = 68
.line	100	loadk         r6    k6 ; k6 = 7
.line	100	loadk         r7    k7 ; k7 = 41
.line	100	loadk         r8    k8 ; k8 = 164
.line	100	loadk         r9    k9 ; k9 = 170
.line	100	loadk        r10   k10 ; k10 = 39
.line	100	loadk        r11   k11 ; k11 = 95
.line	100	loadk        r12   k12 ; k12 = 24
.line	100	loadk        r13   k13 ; k13 = 91
.line	100	loadk        r14   k14 ; k14 = 26
.line	100	loadk        r15   k15 ; k15 = 31
.line	100	loadk        r16   k16 ; k16 = 217
.line	100	loadk        r17   k17 ; k17 = 83
.line	100	loadk        r18   k18 ; k18 = 38
.line	100	loadk        r19   k19 ; k19 = 54
.line	100	loadk        r20   k20 ; k20 = 137
.line	100	loadk        r21   k21 ; k21 = 103
.line	100	loadk        r22   k22 ; k22 = 102
.line	100	loadk        r23   k23 ; k23 = 25
.line	100	loadk        r24   k24 ; k24 = 99
.line	100	loadk        r25   k25 ; k25 = 156
.line	100	loadk        r26   k26 ; k26 = 76
.line	100	loadk        r27   k27 ; k27 = 122
.line	100	loadk        r28   k28 ; k28 = 113
.line	100	loadk        r29   k29 ; k29 = 110
.line	100	loadk        r30   k30 ; k30 = 21
.line	100	loadk        r31   k14 ; k14 = 26
.line	100	loadk        r32   k31 ; k31 = 223
.line	100	loadk        r33   k32 ; k32 = 75
.line	100	loadk        r34   k33 ; k33 = 17
.line	100	loadk        r35   k34 ; k34 = 44
.line	100	loadk        r36   k35 ; k35 = 178
.line	100	loadk        r37   k36 ; k36 = 120
.line	100	loadk        r38   k37 ; k37 = 118
.line	100	loadk        r39   k14 ; k14 = 26
.line	100	loadk        r40   k11 ; k11 = 95
.line	100	loadk        r41   k38 ; k38 = 143
.line	100	loadk        r42   k39 ; k39 = 93
.line	100	loadk        r43   k40 ; k40 = 127
.line	100	call          r3    41     2
.line	100	getupval      r4    u1
.line	100	loadk         r5   k41 ; k41 = 79
.line	100	loadk         r6   k42 ; k42 = 119
.line	100	loadk         r7   k43 ; k43 = 0
.line	100	loadk         r8   k10 ; k10 = 39
.line	100	loadk         r9   k44 ; k44 = 165
.line	100	loadk        r10   k45 ; k45 = 183
.line	100	loadk        r11   k46 ; k46 = 5
.line	100	loadk        r12   k47 ; k47 = 85
.line	100	loadk        r13   k48 ; k48 = 30
.line	100	loadk        r14   k49 ; k49 = 86
.line	100	loadk        r15   k43 ; k43 = 0
.line	100	loadk        r16   k15 ; k15 = 31
.line	100	loadk        r17   k50 ; k50 = 242
.line	100	loadk        r18   k13 ; k13 = 91
.line	100	loadk        r19   k15 ; k15 = 31
.line	100	loadk        r20   k14 ; k14 = 26
.line	100	loadk        r21    k9 ; k9 = 170
.line	100	loadk        r22   k21 ; k21 = 103
.line	100	loadk        r23   k22 ; k22 = 102
.line	100	loadk        r24   k51 ; k51 = 29
.line	100	loadk        r25   k43 ; k43 = 0
.line	100	loadk        r26   k52 ; k52 = 163
.line	100	loadk        r27   k53 ; k53 = 77
.line	100	loadk        r28   k54 ; k54 = 107
.line	100	loadk        r29   k55 ; k55 = 50
.line	100	loadk        r30   k13 ; k13 = 91
.line	100	loadk        r31   k56 ; k56 = 11
.line	100	loadk        r32   k57 ; k57 = 48
.line	100	loadk        r33   k58 ; k58 = 195
.line	100	loadk        r34   k59 ; k59 = 87
.line	100	loadk        r35   k60 ; k60 = 89
.line	100	call          r4    32     0
.line	100	setlist       r2     0     1
.line	100	call          r1     2     2
.line	100	gettabup      r2    u0   k61 ; k61 = "tostring"
.line	100	gettabup      r3    u2   k62 ; k62 = "PlayerKey"
.line	100	call          r2     2     2
.line	100	concat        r1    r1    r2
.label	l89
.line	100	call          r0     2     1
.line	100	settabup      u3   k63   k64 ; k64 = true
.line	100	return        r0     1
.line	100	move          r0    r0
.line	100	return        r0     1

.function	main/f5

.source	null
.linedefined	116
.lastlinedefined	127
.numparams	2
.is_vararg	0
.maxstacksize	43

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	4	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	126
.constant	k3	68
.constant	k4	7
.constant	k5	41
.constant	k6	164
.constant	k7	170
.constant	k8	39
.constant	k9	95
.constant	k10	24
.constant	k11	91
.constant	k12	26
.constant	k13	31
.constant	k14	217
.constant	k15	83
.constant	k16	38
.constant	k17	54
.constant	k18	137
.constant	k19	103
.constant	k20	102
.constant	k21	25
.constant	k22	99
.constant	k23	156
.constant	k24	76
.constant	k25	122
.constant	k26	113
.constant	k27	108
.constant	k28	28
.constant	k29	195
.constant	k30	71
.constant	k31	21
.constant	k32	10
.constant	k33	152
.constant	k34	120
.constant	k35	56
.constant	k36	92
.constant	k37	130
.constant	k38	72
.constant	k39	"_VFXAutoHideTimers"
.constant	k40	nil
.constant	k41	"pairs"
.constant	k42	"RemoveGameTimer"
.constant	k43	"DestroyWidgetObjects"
.constant	k44	"RespondResumeNodeTagMap"
.constant	k45	"__super"
.constant	k46	"ReceiveEndPlay"

.line	116	gettabup      r2    u0    k0 ; k0 = "print"
.line	116	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	116	test          r3     0
.line	116	jmp            0   l46
.line	116	getupval      r3    u1
.line	116	loadk         r4    k2 ; k2 = 126
.line	116	loadk         r5    k3 ; k3 = 68
.line	116	loadk         r6    k4 ; k4 = 7
.line	116	loadk         r7    k5 ; k5 = 41
.line	116	loadk         r8    k6 ; k6 = 164
.line	116	loadk         r9    k7 ; k7 = 170
.line	116	loadk        r10    k8 ; k8 = 39
.line	116	loadk        r11    k9 ; k9 = 95
.line	116	loadk        r12   k10 ; k10 = 24
.line	116	loadk        r13   k11 ; k11 = 91
.line	116	loadk        r14   k12 ; k12 = 26
.line	116	loadk        r15   k13 ; k13 = 31
.line	116	loadk        r16   k14 ; k14 = 217
.line	116	loadk        r17   k15 ; k15 = 83
.line	116	loadk        r18   k16 ; k16 = 38
.line	116	loadk        r19   k17 ; k17 = 54
.line	116	loadk        r20   k18 ; k18 = 137
.line	116	loadk        r21   k19 ; k19 = 103
.line	116	loadk        r22   k20 ; k20 = 102
.line	116	loadk        r23   k21 ; k21 = 25
.line	116	loadk        r24   k22 ; k22 = 99
.line	116	loadk        r25   k23 ; k23 = 156
.line	116	loadk        r26   k24 ; k24 = 76
.line	116	loadk        r27   k25 ; k25 = 122
.line	116	loadk        r28   k26 ; k26 = 113
.line	116	loadk        r29   k27 ; k27 = 108
.line	116	loadk        r30   k28 ; k28 = 28
.line	116	loadk        r31   k10 ; k10 = 24
.line	116	loadk        r32   k29 ; k29 = 195
.line	116	loadk        r33   k30 ; k30 = 71
.line	116	loadk        r34   k31 ; k31 = 21
.line	116	loadk        r35   k32 ; k32 = 10
.line	116	loadk        r36   k33 ; k33 = 152
.line	116	loadk        r37   k34 ; k34 = 120
.line	116	loadk        r38   k20 ; k20 = 102
.line	116	loadk        r39   k35 ; k35 = 56
.line	116	loadk        r40   k36 ; k36 = 92
.line	116	loadk        r41   k37 ; k37 = 130
.line	116	loadk        r42   k38 ; k38 = 72
.line	116	call          r3    40     2
.label	l46
.line	116	call          r2     2     1
.line	116	gettable      r2    r0   k39 ; k39 = "_VFXAutoHideTimers"
.line	116	eq             1    r2   k40 ; k40 = nil
.line	116	jmp            0   l61
.line	116	gettabup      r2    u0   k41 ; k41 = "pairs"
.line	116	gettable      r3    r0   k39 ; k39 = "_VFXAutoHideTimers"
.line	116	call          r2     2     4
.line	116	jmp            0   l57
.line	116	self          r7    r0   k42 ; k42 = "RemoveGameTimer"
.line	116	move          r9    r6
.line	116	call          r7     3     1
.label	l57
.line	116	move          r0    r0
.line	116	move          r0    r0
.line	116	newtable      r2     0     0
.line	116	settable      r0   k39    r2 ; k39 = "_VFXAutoHideTimers"
.label	l61
.line	116	self          r2    r0   k43 ; k43 = "DestroyWidgetObjects"
.line	116	call          r2     2     1
.line	116	newtable      r2     0     0
.line	116	settable      r0   k44    r2 ; k44 = "RespondResumeNodeTag" (truncated)
.line	116	gettabup      r2    u2   k45 ; k45 = "__super"
.line	116	gettable      r2    r2   k46 ; k46 = "ReceiveEndPlay"
.line	116	move          r3    r0
.line	116	move          r4    r1
.line	116	call          r2     3     1
.line	116	return        r0     1
.line	116	move          r0    r0
.line	116	return        r0     1

.function	main/f6

.source	null
.linedefined	129
.lastlinedefined	140
.numparams	2
.is_vararg	0
.maxstacksize	3

.constant	k0	"UMGCanvasInfo"
.constant	k1	"CDOInstanceID"
.constant	k2	"CustomUIBase"

.line	129	test          r1     1
.line	129	jmp            0    l5
.line	129	loadnil       r2     0
.line	129	return        r2     2
.label	l5
.line	129	gettable      r2    r1    k0 ; k0 = "UMGCanvasInfo"
.line	129	test          r2     0
.line	129	jmp            0   l11
.line	129	gettable      r2    r1    k0 ; k0 = "UMGCanvasInfo"
.line	129	gettable      r2    r2    k1 ; k1 = "CDOInstanceID"
.line	129	return        r2     2
.label	l11
.line	129	gettable      r2    r1    k2 ; k2 = "CustomUIBase"
.line	129	test          r2     0
.line	129	jmp            0   l17
.line	129	gettable      r2    r1    k2 ; k2 = "CustomUIBase"
.line	129	gettable      r2    r2    k1 ; k1 = "CDOInstanceID"
.line	129	return        r2     2
.label	l17
.line	129	loadnil       r2     0
.line	129	return        r2     2
.line	129	return        r0     1
.line	129	move          r0    r0
.line	129	move          r0    r0
.line	129	move          r0    r0
.line	129	return        r0     1

.function	main/f7

.source	null
.linedefined	142
.lastlinedefined	155
.numparams	2
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	0	false

.constant	k0	"GetInstanceManager"
.constant	k1	"GetInstanceTree"

.line	142	test          r1     1
.line	142	jmp            0    l5
.line	142	loadnil       r2     0
.line	142	return        r2     2
.label	l5
.line	142	gettabup      r2    u0    k0 ; k0 = "GetInstanceManager"
.line	142	call          r2     1     2
.line	142	test          r2     1
.line	142	jmp            0   l11
.line	142	loadnil       r3     0
.line	142	return        r3     2
.label	l11
.line	142	self          r3    r2    k1 ; k1 = "GetInstanceTree"
.line	142	call          r3     2     2
.line	142	test          r3     1
.line	142	jmp            0   l17
.line	142	loadnil       r4     0
.line	142	return        r4     2
.label	l17
.line	142	gettable      r4    r3    r1
.line	142	return        r4     2
.line	142	return        r0     1
.line	142	move          r0    r0
.line	142	return        r0     1

.function	main/f8

.source	null
.linedefined	157
.lastlinedefined	165
.numparams	1
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"type"
.constant	k1	73
.constant	k2	87
.constant	k3	0
.constant	k4	36
.constant	k5	181
.constant	k6	"overrides"

.line	157	gettabup      r1    u0    k0 ; k0 = "type"
.line	157	move          r2    r0
.line	157	call          r1     2     2
.line	157	getupval      r2    u1
.line	157	loadk         r3    k1 ; k1 = 73
.line	157	loadk         r4    k2 ; k2 = 87
.line	157	loadk         r5    k3 ; k3 = 0
.line	157	loadk         r6    k4 ; k4 = 36
.line	157	loadk         r7    k5 ; k5 = 181
.line	157	call          r2     6     2
.line	157	eq             1    r1    r2
.line	157	jmp            0   l15
.line	157	loadnil       r1     0
.line	157	return        r1     2
.label	l15
.line	157	gettable      r1    r0    k6 ; k6 = "overrides"
.line	157	test          r1     0
.line	157	jmp            0   l32
.line	157	gettabup      r1    u0    k0 ; k0 = "type"
.line	157	gettable      r2    r0    k6 ; k6 = "overrides"
.line	157	call          r1     2     2
.line	157	getupval      r2    u1
.line	157	loadk         r3    k1 ; k1 = 73
.line	157	loadk         r4    k2 ; k2 = 87
.line	157	loadk         r5    k3 ; k3 = 0
.line	157	loadk         r6    k4 ; k4 = 36
.line	157	loadk         r7    k5 ; k5 = 181
.line	157	call          r2     6     2
.line	157	eq             0    r1    r2
.line	157	jmp            0   l32
.line	157	gettable      r1    r0    k6 ; k6 = "overrides"
.line	157	return        r1     2
.label	l32
.line	157	return        r0     2
.line	157	return        r0     1
.line	157	move          r0    r0
.line	157	move          r0    r0
.line	157	move          r0    r0
.line	157	move          r0    r0
.line	157	return        r0     1

.function	main/f9

.source	null
.linedefined	167
.lastlinedefined	199
.numparams	3
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	7	true

.constant	k0	"CustomUIBase"
.constant	k1	"CanvasID"
.constant	k2	"UMGCanvasInfo"
.constant	k3	"AllWidgets"
.constant	k4	1
.constant	k5	"ObjectGroup"
.constant	k6	"Children"

.line	167	test          r1     0
.line	167	jmp            0    l5
.line	167	test          r2     1
.line	167	jmp            0    l6
.label	l5
.line	167	return        r0     1
.label	l6
.line	167	gettable      r3    r1    k0 ; k0 = "CustomUIBase"
.line	167	test          r3     0
.line	167	jmp            0   l19
.line	167	gettable      r3    r1    k0 ; k0 = "CustomUIBase"
.line	167	gettable      r3    r3    k1 ; k1 = "CanvasID"
.line	167	test          r3     0
.line	167	jmp            0   l19
.line	167	gettable      r4    r2    r3
.line	167	test          r4     0
.line	167	jmp            0   l19
.line	167	gettable      r4    r1    k0 ; k0 = "CustomUIBase"
.line	167	gettable      r5    r2    r3
.line	167	settable      r4    k1    r5 ; k1 = "CanvasID"
.label	l19
.line	167	gettable      r3    r1    k2 ; k2 = "UMGCanvasInfo"
.line	167	test          r3     0
.line	167	jmp            0   l41
.line	167	getupval      r3    u0
.line	167	gettable      r4    r1    k2 ; k2 = "UMGCanvasInfo"
.line	167	gettable      r4    r4    k3 ; k3 = "AllWidgets"
.line	167	call          r3     2     2
.line	167	test          r3     0
.line	167	jmp            0   l41
.line	167	loadk         r4    k4 ; k4 = 1
.line	167	len           r5    r3
.line	167	loadk         r6    k4 ; k4 = 1
.line	167	move          r0    r0
.line	167	gettable      r8    r3    r7
.line	167	test          r8     0
.line	167	jmp            0   l40
.line	167	gettable      r9    r2    r8
.line	167	test          r9     0
.line	167	jmp            0   l40
.line	167	gettable      r9    r2    r8
.line	167	settable      r3    r7    r9
.label	l40
.line	167	move          r0    r0
.label	l41
.line	167	gettable      r3    r1    k5 ; k5 = "ObjectGroup"
.line	167	test          r3     0
.line	167	jmp            0   l63
.line	167	getupval      r3    u0
.line	167	gettable      r4    r1    k5 ; k5 = "ObjectGroup"
.line	167	gettable      r4    r4    k6 ; k6 = "Children"
.line	167	call          r3     2     2
.line	167	test          r3     0
.line	167	jmp            0   l63
.line	167	loadk         r4    k4 ; k4 = 1
.line	167	len           r5    r3
.line	167	loadk         r6    k4 ; k4 = 1
.line	167	move          r0    r0
.line	167	gettable      r8    r3    r7
.line	167	test          r8     0
.line	167	jmp            0   l62
.line	167	gettable      r9    r2    r8
.line	167	test          r9     0
.line	167	jmp            0   l62
.line	167	gettable      r9    r2    r8
.line	167	settable      r3    r7    r9
.label	l62
.line	167	move          r0    r0
.label	l63
.line	167	return        r0     1
.line	167	move          r0    r0
.line	167	move          r0    r0
.line	167	return        r0     1

.function	main/f10

.source	null
.linedefined	201
.lastlinedefined	207
.numparams	3
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	3	true

.constant	k0	"tostring"
.constant	k1	98
.constant	k2	"MakeHashByFNV1a32"

.line	201	gettabup      r3    u0    k0 ; k0 = "tostring"
.line	201	move          r4    r0
.line	201	call          r3     2     2
.line	201	getupval      r4    u1
.line	201	loadk         r5    k1 ; k1 = 98
.line	201	call          r4     2     2
.line	201	gettabup      r5    u0    k0 ; k0 = "tostring"
.line	201	move          r6    r1
.line	201	call          r5     2     2
.line	201	concat        r3    r3    r5
.line	201	test          r2     0
.line	201	jmp            0   l19
.line	201	move          r4    r2
.line	201	getupval      r5    u1
.line	201	loadk         r6    k1 ; k1 = 98
.line	201	call          r5     2     2
.line	201	move          r6    r3
.line	201	concat        r3    r4    r6
.label	l19
.line	201	getupval      r4    u2
.line	201	self          r4    r4    k2 ; k2 = "MakeHashByFNV1a32"
.line	201	move          r6    r3
.line	201	tailcall      r4     3
.line	201	return        r4     0
.line	201	return        r0     1
.line	201	move          r0    r0
.line	201	move          r0    r0
.line	201	move          r0    r0
.line	201	move          r0    r0
.line	201	return        r0     1

.function	main/f11

.source	null
.linedefined	209
.lastlinedefined	262
.numparams	5
.is_vararg	0
.maxstacksize	64

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true
.upvalue	"U3"	2	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	126
.constant	k5	68
.constant	k6	7
.constant	k7	41
.constant	k8	164
.constant	k9	170
.constant	k10	39
.constant	k11	95
.constant	k12	24
.constant	k13	91
.constant	k14	26
.constant	k15	31
.constant	k16	217
.constant	k17	83
.constant	k18	38
.constant	k19	54
.constant	k20	137
.constant	k21	103
.constant	k22	102
.constant	k23	25
.constant	k24	99
.constant	k25	156
.constant	k26	76
.constant	k27	122
.constant	k28	113
.constant	k29	125
.constant	k30	21
.constant	k31	20
.constant	k32	200
.constant	k33	75
.constant	k34	32
.constant	k35	43
.constant	k36	146
.constant	k37	66
.constant	k38	109
.constant	k39	58
.constant	k40	69
.constant	k41	141
.constant	k42	115
.constant	k43	80
.constant	k44	11
.constant	k45	148
.constant	k46	140
.constant	k47	18
.constant	k48	53
.constant	k49	88
.constant	k50	8
.constant	k51	255
.constant	k52	90
.constant	k53	22
.constant	k54	190
.constant	k55	124
.constant	k56	17
.constant	k57	1
.constant	k58	"UMGCanvasInfo"
.constant	k59	191
.constant	k60	183
.constant	k61	123
.constant	k62	77
.constant	k63	5
.constant	k64	192
.constant	k65	0
.constant	k66	142
.constant	k67	93
.constant	k68	"require"
.constant	k69	87
.constant	k70	15
.constant	k71	45
.constant	k72	182
.constant	k73	48
.constant	k74	65
.constant	k75	13
.constant	k76	245
.constant	k77	30
.constant	k78	185
.constant	k79	111
.constant	k80	100
.constant	k81	29
.constant	k82	98
.constant	k83	82
.constant	k84	101
.constant	k85	195
.constant	k86	64
.constant	k87	23
.constant	k88	158
.constant	k89	9
.constant	k90	138
.constant	k91	71
.constant	k92	127
.constant	k93	67
.constant	k94	60
.constant	k95	174
.constant	k96	4
.constant	k97	117
.constant	k98	28
.constant	k99	194
.constant	k100	81
.constant	k101	42
.constant	k102	132
.constant	k103	119
.constant	k104	73
.constant	k105	157
.constant	k106	"CanvasType"
.constant	k107	"UMGCanvasType"
.constant	k108	"Default"
.constant	k109	"Game"
.constant	k110	"AllWidgets"
.constant	k111	"overrides"
.constant	k112	"pairs"
.constant	k113	"DeepCopy"
.constant	k114	"InstanceId"
.constant	k115	"RewriteIdReferences"
.constant	k116	37
.constant	k117	176
.constant	k118	34
.constant	k119	40
.constant	k120	242
.constant	k121	163
.constant	k122	78
.constant	k123	144

.line	209	test          r1     1
.line	209	jmp            0   l80
.line	209	gettabup      r5    u0    k0 ; k0 = "print"
.line	209	gettabup      r6    u0    k1 ; k1 = "bWriteLog"
.line	209	test          r6     0
.line	209	jmp            0   l77
.line	209	gettabup      r6    u0    k2 ; k2 = "table"
.line	209	gettable      r6    r6    k3 ; k3 = "concat"
.line	209	newtable      r7     1     0
.line	209	getupval      r8    u1
.line	209	loadk         r9    k4 ; k4 = 126
.line	209	loadk        r10    k5 ; k5 = 68
.line	209	loadk        r11    k6 ; k6 = 7
.line	209	loadk        r12    k7 ; k7 = 41
.line	209	loadk        r13    k8 ; k8 = 164
.line	209	loadk        r14    k9 ; k9 = 170
.line	209	loadk        r15   k10 ; k10 = 39
.line	209	loadk        r16   k11 ; k11 = 95
.line	209	loadk        r17   k12 ; k12 = 24
.line	209	loadk        r18   k13 ; k13 = 91
.line	209	loadk        r19   k14 ; k14 = 26
.line	209	loadk        r20   k15 ; k15 = 31
.line	209	loadk        r21   k16 ; k16 = 217
.line	209	loadk        r22   k17 ; k17 = 83
.line	209	loadk        r23   k18 ; k18 = 38
.line	209	loadk        r24   k19 ; k19 = 54
.line	209	loadk        r25   k20 ; k20 = 137
.line	209	loadk        r26   k21 ; k21 = 103
.line	209	loadk        r27   k22 ; k22 = 102
.line	209	loadk        r28   k23 ; k23 = 25
.line	209	loadk        r29   k24 ; k24 = 99
.line	209	loadk        r30   k25 ; k25 = 156
.line	209	loadk        r31   k26 ; k26 = 76
.line	209	loadk        r32   k27 ; k27 = 122
.line	209	loadk        r33   k28 ; k28 = 113
.line	209	loadk        r34   k29 ; k29 = 125
.line	209	loadk        r35   k30 ; k30 = 21
.line	209	loadk        r36   k31 ; k31 = 20
.line	209	loadk        r37   k32 ; k32 = 200
.line	209	loadk        r38   k33 ; k33 = 75
.line	209	loadk        r39   k34 ; k34 = 32
.line	209	loadk        r40   k35 ; k35 = 43
.line	209	loadk        r41   k36 ; k36 = 146
.line	209	loadk        r42   k37 ; k37 = 66
.line	209	loadk        r43   k38 ; k38 = 109
.line	209	loadk        r44   k39 ; k39 = 58
.line	209	loadk        r45   k40 ; k40 = 69
.line	209	loadk        r46   k41 ; k41 = 141
.line	209	loadk        r47   k40 ; k40 = 69
.line	209	loadk        r48   k42 ; k42 = 115
.line	209	call          r8    41     2
.line	209	getupval      r9    u1
.line	209	loadk        r10   k43 ; k43 = 80
.line	209	loadk        r11   k17 ; k17 = 83
.line	209	loadk        r12   k37 ; k37 = 66
.line	209	loadk        r13   k44 ; k44 = 11
.line	209	loadk        r14   k45 ; k45 = 148
.line	209	loadk        r15   k46 ; k46 = 140
.line	209	loadk        r16   k47 ; k47 = 18
.line	209	loadk        r17   k13 ; k13 = 91
.line	209	loadk        r18   k48 ; k48 = 53
.line	209	loadk        r19   k49 ; k49 = 88
.line	209	loadk        r20   k50 ; k50 = 8
.line	209	loadk        r21   k12 ; k12 = 24
.line	209	loadk        r22   k51 ; k51 = 255
.line	209	loadk        r23   k52 ; k52 = 90
.line	209	loadk        r24   k17 ; k17 = 83
.line	209	loadk        r25   k53 ; k53 = 22
.line	209	loadk        r26   k54 ; k54 = 190
.line	209	loadk        r27   k18 ; k18 = 38
.line	209	loadk        r28   k55 ; k55 = 124
.line	209	loadk        r29   k56 ; k56 = 17
.line	209	loadk        r30   k26 ; k26 = 76
.line	209	call          r9    22     0
.line	209	setlist       r7     0     1
.line	209	call          r6     2     2
.label	l77
.line	209	call          r5     2     1
.line	209	loadnil       r5     1
.line	209	return        r5     3
.label	l80
.line	209	test          r3     1
.line	209	jmp            0   l83
.line	209	loadk         r3   k57 ; k57 = 1
.label	l83
.line	209	closure       r5    f0
.line	209	move          r6    r5
.line	209	move          r7    r1
.line	209	call          r6     2     2
.line	209	test          r6     0
.line	209	jmp            0   l92
.line	209	gettable      r7    r6   k58 ; k58 = "UMGCanvasInfo"
.line	209	test          r7     1
.line	209	jmp            0  l168
.label	l92
.line	209	gettabup      r7    u0    k0 ; k0 = "print"
.line	209	gettabup      r8    u0    k1 ; k1 = "bWriteLog"
.line	209	test          r8     0
.line	209	jmp            0  l164
.line	209	gettabup      r8    u0    k2 ; k2 = "table"
.line	209	gettable      r8    r8    k3 ; k3 = "concat"
.line	209	newtable      r9     1     0
.line	209	getupval     r10    u1
.line	209	loadk        r11    k4 ; k4 = 126
.line	209	loadk        r12    k5 ; k5 = 68
.line	209	loadk        r13    k6 ; k6 = 7
.line	209	loadk        r14    k7 ; k7 = 41
.line	209	loadk        r15    k8 ; k8 = 164
.line	209	loadk        r16    k9 ; k9 = 170
.line	209	loadk        r17   k10 ; k10 = 39
.line	209	loadk        r18   k11 ; k11 = 95
.line	209	loadk        r19   k12 ; k12 = 24
.line	209	loadk        r20   k13 ; k13 = 91
.line	209	loadk        r21   k14 ; k14 = 26
.line	209	loadk        r22   k15 ; k15 = 31
.line	209	loadk        r23   k16 ; k16 = 217
.line	209	loadk        r24   k17 ; k17 = 83
.line	209	loadk        r25   k18 ; k18 = 38
.line	209	loadk        r26   k19 ; k19 = 54
.line	209	loadk        r27   k20 ; k20 = 137
.line	209	loadk        r28   k21 ; k21 = 103
.line	209	loadk        r29   k22 ; k22 = 102
.line	209	loadk        r30   k23 ; k23 = 25
.line	209	loadk        r31   k24 ; k24 = 99
.line	209	loadk        r32   k25 ; k25 = 156
.line	209	loadk        r33   k26 ; k26 = 76
.line	209	loadk        r34   k27 ; k27 = 122
.line	209	loadk        r35   k28 ; k28 = 113
.line	209	loadk        r36   k29 ; k29 = 125
.line	209	loadk        r37   k30 ; k30 = 21
.line	209	loadk        r38   k31 ; k31 = 20
.line	209	loadk        r39   k32 ; k32 = 200
.line	209	loadk        r40   k33 ; k33 = 75
.line	209	loadk        r41   k34 ; k34 = 32
.line	209	loadk        r42   k35 ; k35 = 43
.line	209	loadk        r43   k36 ; k36 = 146
.line	209	loadk        r44   k37 ; k37 = 66
.line	209	loadk        r45   k38 ; k38 = 109
.line	209	loadk        r46   k39 ; k39 = 58
.line	209	loadk        r47   k40 ; k40 = 69
.line	209	loadk        r48   k41 ; k41 = 141
.line	209	loadk        r49   k40 ; k40 = 69
.line	209	loadk        r50   k42 ; k42 = 115
.line	209	call         r10    41     2
.line	209	getupval     r11    u1
.line	209	loadk        r12   k43 ; k43 = 80
.line	209	loadk        r13   k17 ; k17 = 83
.line	209	loadk        r14   k37 ; k37 = 66
.line	209	loadk        r15   k18 ; k18 = 38
.line	209	loadk        r16   k59 ; k59 = 191
.line	209	loadk        r17   k60 ; k60 = 183
.line	209	loadk        r18   k28 ; k28 = 113
.line	209	loadk        r19   k13 ; k13 = 91
.line	209	loadk        r20   k61 ; k61 = 123
.line	209	loadk        r21   k62 ; k62 = 77
.line	209	loadk        r22   k50 ; k50 = 8
.line	209	loadk        r23   k63 ; k63 = 5
.line	209	loadk        r24   k64 ; k64 = 192
.line	209	loadk        r25   k11 ; k11 = 95
.line	209	loadk        r26   k65 ; k65 = 0
.line	209	loadk        r27   k11 ; k11 = 95
.line	209	loadk        r28   k66 ; k66 = 142
.line	209	loadk        r29   k37 ; k37 = 66
.line	209	loadk        r30   k67 ; k67 = 93
.line	209	call         r11    20     0
.line	209	setlist       r9     0     1
.line	209	call          r8     2     2
.label	l164
.line	209	move          r9    r1
.line	209	call          r7     3     1
.line	209	loadnil       r7     1
.line	209	return        r7     3
.label	l168
.line	209	gettabup      r7    u0   k68 ; k68 = "require"
.line	209	gettabup      r8    u0    k2 ; k2 = "table"
.line	209	gettable      r8    r8    k3 ; k3 = "concat"
.line	209	newtable      r9     1     0
.line	209	getupval     r10    u1
.line	209	loadk        r11   k27 ; k27 = 122
.line	209	loadk        r12   k69 ; k69 = 87
.line	209	loadk        r13   k70 ; k70 = 15
.line	209	loadk        r14   k71 ; k71 = 45
.line	209	loadk        r15   k25 ; k25 = 156
.line	209	loadk        r16   k72 ; k72 = 182
.line	209	loadk        r17   k73 ; k73 = 48
.line	209	loadk        r18   k31 ; k31 = 20
.line	209	loadk        r19   k53 ; k53 = 22
.line	209	loadk        r20   k74 ; k74 = 65
.line	209	loadk        r21   k75 ; k75 = 13
.line	209	loadk        r22   k40 ; k40 = 69
.line	209	loadk        r23   k76 ; k76 = 245
.line	209	loadk        r24   k26 ; k26 = 76
.line	209	loadk        r25   k53 ; k53 = 22
.line	209	loadk        r26   k77 ; k77 = 30
.line	209	loadk        r27   k78 ; k78 = 185
.line	209	loadk        r28   k79 ; k79 = 111
.line	209	loadk        r29   k80 ; k80 = 100
.line	209	loadk        r30   k81 ; k81 = 29
.line	209	loadk        r31   k82 ; k82 = 98
.line	209	loadk        r32   k36 ; k36 = 146
.line	209	loadk        r33   k83 ; k83 = 82
.line	209	loadk        r34   k79 ; k79 = 111
.line	209	loadk        r35   k84 ; k84 = 101
.line	209	loadk        r36   k29 ; k29 = 125
.line	209	loadk        r37   k30 ; k30 = 21
.line	209	loadk        r38   k47 ; k47 = 18
.line	209	loadk        r39   k85 ; k85 = 195
.line	209	loadk        r40   k86 ; k86 = 64
.line	209	loadk        r41   k87 ; k87 = 23
.line	209	loadk        r42   k74 ; k74 = 65
.line	209	loadk        r43   k88 ; k88 = 158
.line	209	loadk        r44   k80 ; k80 = 100
.line	209	loadk        r45   k21 ; k21 = 103
.line	209	loadk        r46   k89 ; k89 = 9
.line	209	loadk        r47    k5 ; k5 = 68
.line	209	loadk        r48   k90 ; k90 = 138
.line	209	loadk        r49   k91 ; k91 = 71
.line	209	loadk        r50   k92 ; k92 = 127
.line	209	call         r10    41     2
.line	209	getupval     r11    u1
.line	209	loadk        r12    k4 ; k4 = 126
.line	209	loadk        r13   k93 ; k93 = 67
.line	209	loadk        r14   k56 ; k56 = 17
.line	209	loadk        r15   k94 ; k94 = 60
.line	209	loadk        r16   k59 ; k59 = 191
.line	209	loadk        r17   k95 ; k95 = 174
.line	209	loadk        r18   k96 ; k96 = 4
.line	209	loadk        r19   k42 ; k42 = 115
.line	209	loadk        r20   k97 ; k97 = 117
.line	209	loadk        r21   k38 ; k38 = 109
.line	209	loadk        r22   k98 ; k98 = 28
.line	209	loadk        r23   k12 ; k12 = 24
.line	209	loadk        r24   k99 ; k99 = 194
.line	209	loadk        r25  k100 ; k100 = 81
.line	209	loadk        r26   k77 ; k77 = 30
.line	209	loadk        r27  k101 ; k101 = 42
.line	209	loadk        r28  k102 ; k102 = 132
.line	209	loadk        r29   k37 ; k37 = 66
.line	209	loadk        r30  k103 ; k103 = 119
.line	209	loadk        r31   k77 ; k77 = 30
.line	209	loadk        r32  k104 ; k104 = 73
.line	209	loadk        r33  k105 ; k105 = 157
.line	209	loadk        r34    k5 ; k5 = 68
.line	209	call         r11    24     0
.line	209	setlist       r9     0     1
.line	209	call          r8     2     2
.line	209	call          r7     2     2
.line	209	gettable      r8    r6   k58 ; k58 = "UMGCanvasInfo"
.line	209	gettable      r8    r8  k106 ; k106 = "CanvasType"
.line	209	gettable      r9    r7  k107 ; k107 = "UMGCanvasType"
.line	209	gettable      r9    r9  k108 ; k108 = "Default"
.line	209	eq             1    r8    r9
.line	209	jmp            0  l253
.line	209	gettable      r9    r7  k107 ; k107 = "UMGCanvasType"
.line	209	gettable      r9    r9  k109 ; k109 = "Game"
.line	209	eq             1    r8    r9
.line	209	jmp            0  l253
.line	209	loadbool      r9     0     1
.label	l253
.line	209	loadbool      r9     1     0
.line	209	closure      r10    f1
.line	209	newtable     r11     0     0
.line	209	move         r12   r10
.line	209	move         r13    r1
.line	209	call         r12     2     2
.line	209	settable     r11    r1   r12
.line	209	gettable     r12    r6   k58 ; k58 = "UMGCanvasInfo"
.line	209	gettable     r12   r12  k110 ; k110 = "AllWidgets"
.line	209	test         r12     0
.line	209	jmp            0  l268
.line	209	gettable     r13   r12  k111 ; k111 = "overrides"
.line	209	test         r13     0
.line	209	jmp            0  l268
.line	209	gettable     r12   r12  k111 ; k111 = "overrides"
.label	l268
.line	209	test         r12     0
.line	209	jmp            0  l285
.line	209	loadk        r13   k57 ; k57 = 1
.line	209	len          r14   r12
.line	209	loadk        r15   k57 ; k57 = 1
.line	209	move          r0    r0
.line	209	gettable     r17   r12   r16
.line	209	test         r17     0
.line	209	jmp            0  l284
.line	209	gettable     r18   r11   r17
.line	209	test         r18     1
.line	209	jmp            0  l284
.line	209	move         r18   r10
.line	209	move         r19   r17
.line	209	call         r18     2     2
.line	209	settable     r11   r17   r18
.label	l284
.line	209	move          r0    r0
.label	l285
.line	209	newtable     r13     0     0
.line	209	gettabup     r14    u0  k112 ; k112 = "pairs"
.line	209	move         r15   r11
.line	209	call         r14     2     4
.line	209	jmp            0  l383
.line	209	move         r19    r5
.line	209	move         r20   r17
.line	209	call         r19     2     2
.line	209	test         r19     0
.line	209	jmp            0  l305
.line	209	gettabup     r20    u3  k113 ; k113 = "DeepCopy"
.line	209	move         r21   r19
.line	209	call         r20     2     2
.line	209	settable     r20  k114   r18 ; k114 = "InstanceId"
.line	209	self         r21    r0  k115 ; k115 = "RewriteIdReferences"
.line	209	move         r23   r20
.line	209	move         r24   r11
.line	209	call         r21     4     1
.line	209	settable     r13   r18   r20
.line	209	jmp            0  l383
.label	l305
.line	209	gettabup     r20    u0    k0 ; k0 = "print"
.line	209	gettabup     r21    u0    k1 ; k1 = "bWriteLog"
.line	209	test         r21     0
.line	209	jmp            0  l381
.line	209	gettabup     r21    u0    k2 ; k2 = "table"
.line	209	gettable     r21   r21    k3 ; k3 = "concat"
.line	209	newtable     r22     1     0
.line	209	getupval     r23    u1
.line	209	loadk        r24    k4 ; k4 = 126
.line	209	loadk        r25    k5 ; k5 = 68
.line	209	loadk        r26    k6 ; k6 = 7
.line	209	loadk        r27    k7 ; k7 = 41
.line	209	loadk        r28    k8 ; k8 = 164
.line	209	loadk        r29    k9 ; k9 = 170
.line	209	loadk        r30   k10 ; k10 = 39
.line	209	loadk        r31   k11 ; k11 = 95
.line	209	loadk        r32   k12 ; k12 = 24
.line	209	loadk        r33   k13 ; k13 = 91
.line	209	loadk        r34   k14 ; k14 = 26
.line	209	loadk        r35   k15 ; k15 = 31
.line	209	loadk        r36   k16 ; k16 = 217
.line	209	loadk        r37   k17 ; k17 = 83
.line	209	loadk        r38   k18 ; k18 = 38
.line	209	loadk        r39   k19 ; k19 = 54
.line	209	loadk        r40   k20 ; k20 = 137
.line	209	loadk        r41   k21 ; k21 = 103
.line	209	loadk        r42   k22 ; k22 = 102
.line	209	loadk        r43   k23 ; k23 = 25
.line	209	loadk        r44   k24 ; k24 = 99
.line	209	loadk        r45   k25 ; k25 = 156
.line	209	loadk        r46   k26 ; k26 = 76
.line	209	loadk        r47   k27 ; k27 = 122
.line	209	loadk        r48   k28 ; k28 = 113
.line	209	loadk        r49   k29 ; k29 = 125
.line	209	loadk        r50   k30 ; k30 = 21
.line	209	loadk        r51   k31 ; k31 = 20
.line	209	loadk        r52   k32 ; k32 = 200
.line	209	loadk        r53   k33 ; k33 = 75
.line	209	loadk        r54   k34 ; k34 = 32
.line	209	loadk        r55   k35 ; k35 = 43
.line	209	loadk        r56   k36 ; k36 = 146
.line	209	loadk        r57   k37 ; k37 = 66
.line	209	loadk        r58   k38 ; k38 = 109
.line	209	loadk        r59   k39 ; k39 = 58
.line	209	loadk        r60   k40 ; k40 = 69
.line	209	loadk        r61   k41 ; k41 = 141
.line	209	loadk        r62   k40 ; k40 = 69
.line	209	loadk        r63   k42 ; k42 = 115
.line	209	call         r23    41     2
.line	209	getupval     r24    u1
.line	209	loadk        r25   k43 ; k43 = 80
.line	209	loadk        r26   k17 ; k17 = 83
.line	209	loadk        r27   k37 ; k37 = 66
.line	209	loadk        r28  k116 ; k116 = 37
.line	209	loadk        r29   k78 ; k78 = 185
.line	209	loadk        r30  k117 ; k117 = 176
.line	209	loadk        r31  k118 ; k118 = 34
.line	209	loadk        r32   k17 ; k17 = 83
.line	209	loadk        r33   k48 ; k48 = 53
.line	209	loadk        r34  k104 ; k104 = 73
.line	209	loadk        r35  k104 ; k104 = 73
.line	209	loadk        r36  k119 ; k119 = 40
.line	209	loadk        r37  k120 ; k120 = 242
.line	209	loadk        r38   k28 ; k28 = 113
.line	209	loadk        r39   k17 ; k17 = 83
.line	209	loadk        r40   k19 ; k19 = 54
.line	209	loadk        r41  k121 ; k121 = 163
.line	209	loadk        r42   k97 ; k97 = 117
.line	209	loadk        r43   k22 ; k22 = 102
.line	209	loadk        r44   k23 ; k23 = 25
.line	209	loadk        r45  k122 ; k122 = 78
.line	209	loadk        r46  k123 ; k123 = 144
.line	209	loadk        r47    k5 ; k5 = 68
.line	209	call         r24    24     0
.line	209	setlist      r22     0     1
.line	209	call         r21     2     2
.label	l381
.line	209	move         r22   r17
.line	209	call         r20     3     1
.label	l383
.line	209	move          r0    r0
.line	209	move          r0    r0
.line	209	move         r14   r11
.line	209	move         r15   r13
.line	209	return       r14     3
.line	209	return        r0     1
.line	209	move          r0    r0
.line	209	return        r0     1

.function	main/f11/f0

.source	null
.linedefined	215
.lastlinedefined	220
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	2	true
.upvalue	"U1"	0	true

.constant	k0	"GetCDOInstance"

.line	215	getupval      r1    u0
.line	215	test          r1     0
.line	215	jmp            0    l9
.line	215	gettabup      r1    u0    r0
.line	215	test          r1     0
.line	215	jmp            0    l9
.line	215	gettabup      r1    u0    r0
.line	215	return        r1     2
.label	l9
.line	215	getupval      r1    u1
.line	215	self          r1    r1    k0 ; k0 = "GetCDOInstance"
.line	215	move          r3    r0
.line	215	tailcall      r1     3
.line	215	return        r1     0
.line	215	return        r0     1
.line	215	move          r0    r0
.line	215	move          r0    r0
.line	215	move          r0    r0
.line	215	return        r0     1

.function	main/f11/f1

.source	null
.linedefined	229
.lastlinedefined	234
.numparams	1
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	9	true
.upvalue	"U1"	2	false
.upvalue	"U2"	3	true
.upvalue	"U3"	4	true

.line	229	getupval      r1    u0
.line	229	test          r1     0
.line	229	jmp            0    l5
.line	229	return        r0     2
.label	l5
.line	229	getupval      r1    u1
.line	229	move          r2    r0
.line	229	getupval      r3    u2
.line	229	getupval      r4    u3
.line	229	tailcall      r1     4
.line	229	return        r1     0
.line	229	return        r0     1
.line	229	move          r0    r0
.line	229	move          r0    r0
.line	229	move          r0    r0
.line	229	return        r0     1

.function	main/f12

.source	null
.linedefined	264
.lastlinedefined	268
.numparams	3
.is_vararg	0
.maxstacksize	7

.constant	k0	"CustomUIData"
.constant	k1	"RegisterInstanceIndex"
.constant	k2	"RegisterEventIndex"

.line	264	gettable      r3    r0    k0 ; k0 = "CustomUIData"
.line	264	settable      r3    r1    r2
.line	264	self          r3    r0    k1 ; k1 = "RegisterInstanceInde" (truncated)
.line	264	move          r5    r1
.line	264	move          r6    r2
.line	264	call          r3     4     1
.line	264	self          r3    r0    k2 ; k2 = "RegisterEventIndex"
.line	264	move          r5    r1
.line	264	move          r6    r2
.line	264	call          r3     4     1
.line	264	return        r0     1
.line	264	move          r0    r0
.line	264	return        r0     1

.function	main/f13

.source	null
.linedefined	270
.lastlinedefined	293
.numparams	3
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	2	true

.constant	k0	nil
.constant	k1	"print"
.constant	k2	"bWriteLog"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	126
.constant	k6	68
.constant	k7	7
.constant	k8	41
.constant	k9	164
.constant	k10	170
.constant	k11	39
.constant	k12	95
.constant	k13	24
.constant	k14	91
.constant	k15	26
.constant	k16	31
.constant	k17	217
.constant	k18	83
.constant	k19	38
.constant	k20	54
.constant	k21	137
.constant	k22	103
.constant	k23	102
.constant	k24	25
.constant	k25	99
.constant	k26	156
.constant	k27	76
.constant	k28	122
.constant	k29	113
.constant	k30	125
.constant	k31	17
.constant	k32	200
.constant	k33	73
.constant	k34	6
.constant	k35	179
.constant	k36	101
.constant	k37	118
.constant	k38	9
.constant	k39	94
.constant	k40	128
.constant	k41	84
.constant	k42	58
.constant	k43	116
.constant	k44	88
.constant	k45	60
.constant	k46	177
.constant	k47	173
.constant	k48	50
.constant	k49	18
.constant	k50	74
.constant	k51	2
.constant	k52	197
.constant	k53	30
.constant	k54	29
.constant	k55	22
.constant	k56	161
.constant	k57	"require"
.constant	k58	87
.constant	k59	15
.constant	k60	45
.constant	k61	182
.constant	k62	48
.constant	k63	20
.constant	k64	65
.constant	k65	13
.constant	k66	69
.constant	k67	245
.constant	k68	185
.constant	k69	111
.constant	k70	100
.constant	k71	98
.constant	k72	146
.constant	k73	82
.constant	k74	121
.constant	k75	195
.constant	k76	14
.constant	k77	56
.constant	k78	81
.constant	k79	144
.constant	k80	72
.constant	k81	105
.constant	k82	147
.constant	k83	34
.constant	k84	78
.constant	k85	52
.constant	k86	67
.constant	k87	226
.constant	k88	136
.constant	k89	123
.constant	k90	12
.constant	k91	176
.constant	k92	63
.constant	k93	46
.constant	k94	239
.constant	k95	10
.constant	k96	184
.constant	k97	119
.constant	k98	1
.constant	k99	92
.constant	k100	135
.constant	k101	110
.constant	k102	90
.constant	k103	"IsCustomUIOrCanvas"
.constant	k104	"InstanceChangeCache"
.constant	k105	"ChangeInstanceHandle"
.constant	k106	"RemoveTimer"
.constant	k107	"AddTimerOnce"
.constant	k108	0

.line	270	eq             0    r1    k0 ; k0 = nil
.line	270	jmp            0   l75
.line	270	gettabup      r3    u0    k1 ; k1 = "print"
.line	270	gettabup      r4    u0    k2 ; k2 = "bWriteLog"
.line	270	test          r4     0
.line	270	jmp            0   l73
.line	270	gettabup      r4    u0    k3 ; k3 = "table"
.line	270	gettable      r4    r4    k4 ; k4 = "concat"
.line	270	newtable      r5     1     0
.line	270	getupval      r6    u1
.line	270	loadk         r7    k5 ; k5 = 126
.line	270	loadk         r8    k6 ; k6 = 68
.line	270	loadk         r9    k7 ; k7 = 7
.line	270	loadk        r10    k8 ; k8 = 41
.line	270	loadk        r11    k9 ; k9 = 164
.line	270	loadk        r12   k10 ; k10 = 170
.line	270	loadk        r13   k11 ; k11 = 39
.line	270	loadk        r14   k12 ; k12 = 95
.line	270	loadk        r15   k13 ; k13 = 24
.line	270	loadk        r16   k14 ; k14 = 91
.line	270	loadk        r17   k15 ; k15 = 26
.line	270	loadk        r18   k16 ; k16 = 31
.line	270	loadk        r19   k17 ; k17 = 217
.line	270	loadk        r20   k18 ; k18 = 83
.line	270	loadk        r21   k19 ; k19 = 38
.line	270	loadk        r22   k20 ; k20 = 54
.line	270	loadk        r23   k21 ; k21 = 137
.line	270	loadk        r24   k22 ; k22 = 103
.line	270	loadk        r25   k23 ; k23 = 102
.line	270	loadk        r26   k24 ; k24 = 25
.line	270	loadk        r27   k25 ; k25 = 99
.line	270	loadk        r28   k26 ; k26 = 156
.line	270	loadk        r29   k27 ; k27 = 76
.line	270	loadk        r30   k28 ; k28 = 122
.line	270	loadk        r31   k29 ; k29 = 113
.line	270	loadk        r32   k30 ; k30 = 125
.line	270	loadk        r33   k31 ; k31 = 17
.line	270	loadk        r34   k15 ; k15 = 26
.line	270	loadk        r35   k32 ; k32 = 200
.line	270	loadk        r36   k33 ; k33 = 73
.line	270	loadk        r37   k34 ; k34 = 6
.line	270	loadk        r38   k19 ; k19 = 38
.line	270	loadk        r39   k35 ; k35 = 179
.line	270	loadk        r40   k36 ; k36 = 101
.line	270	loadk        r41   k37 ; k37 = 118
.line	270	loadk        r42   k38 ; k38 = 9
.line	270	loadk        r43   k39 ; k39 = 94
.line	270	loadk        r44   k40 ; k40 = 128
.line	270	loadk        r45   k41 ; k41 = 84
.line	270	loadk        r46   k42 ; k42 = 58
.line	270	call          r6    41     2
.line	270	getupval      r7    u1
.line	270	loadk         r8   k43 ; k43 = 116
.line	270	loadk         r9   k44 ; k44 = 88
.line	270	loadk        r10   k31 ; k31 = 17
.line	270	loadk        r11   k45 ; k45 = 60
.line	270	loadk        r12   k46 ; k46 = 177
.line	270	loadk        r13   k47 ; k47 = 173
.line	270	loadk        r14   k48 ; k48 = 50
.line	270	loadk        r15   k12 ; k12 = 95
.line	270	loadk        r16   k49 ; k49 = 18
.line	270	loadk        r17   k50 ; k50 = 74
.line	270	loadk        r18   k33 ; k33 = 73
.line	270	loadk        r19   k51 ; k51 = 2
.line	270	loadk        r20   k52 ; k52 = 197
.line	270	loadk        r21   k53 ; k53 = 30
.line	270	loadk        r22   k54 ; k54 = 29
.line	270	loadk        r23   k55 ; k55 = 22
.line	270	loadk        r24   k56 ; k56 = 161
.line	270	call          r7    18     0
.line	270	setlist       r5     0     1
.line	270	call          r4     2     2
.label	l73
.line	270	call          r3     2     1
.line	270	return        r0     1
.label	l75
.line	270	gettabup      r3    u0   k57 ; k57 = "require"
.line	270	gettabup      r4    u0    k3 ; k3 = "table"
.line	270	gettable      r4    r4    k4 ; k4 = "concat"
.line	270	newtable      r5     2     0
.line	270	getupval      r6    u1
.line	270	loadk         r7   k28 ; k28 = 122
.line	270	loadk         r8   k58 ; k58 = 87
.line	270	loadk         r9   k59 ; k59 = 15
.line	270	loadk        r10   k60 ; k60 = 45
.line	270	loadk        r11   k26 ; k26 = 156
.line	270	loadk        r12   k61 ; k61 = 182
.line	270	loadk        r13   k62 ; k62 = 48
.line	270	loadk        r14   k63 ; k63 = 20
.line	270	loadk        r15   k55 ; k55 = 22
.line	270	loadk        r16   k64 ; k64 = 65
.line	270	loadk        r17   k65 ; k65 = 13
.line	270	loadk        r18   k66 ; k66 = 69
.line	270	loadk        r19   k67 ; k67 = 245
.line	270	loadk        r20   k27 ; k27 = 76
.line	270	loadk        r21   k55 ; k55 = 22
.line	270	loadk        r22   k53 ; k53 = 30
.line	270	loadk        r23   k68 ; k68 = 185
.line	270	loadk        r24   k69 ; k69 = 111
.line	270	loadk        r25   k70 ; k70 = 100
.line	270	loadk        r26   k54 ; k54 = 29
.line	270	loadk        r27   k71 ; k71 = 98
.line	270	loadk        r28   k72 ; k72 = 146
.line	270	loadk        r29   k73 ; k73 = 82
.line	270	loadk        r30   k69 ; k69 = 111
.line	270	loadk        r31   k36 ; k36 = 101
.line	270	loadk        r32   k74 ; k74 = 121
.line	270	loadk        r33   k13 ; k13 = 24
.line	270	loadk        r34   k55 ; k55 = 22
.line	270	loadk        r35   k75 ; k75 = 195
.line	270	loadk        r36   k39 ; k39 = 94
.line	270	loadk        r37   k59 ; k59 = 15
.line	270	loadk        r38   k76 ; k76 = 14
.line	270	loadk        r39    k9 ; k9 = 164
.line	270	loadk        r40   k77 ; k77 = 56
.line	270	loadk        r41   k78 ; k78 = 81
.line	270	loadk        r42   k54 ; k54 = 29
.line	270	loadk        r43   k73 ; k73 = 82
.line	270	loadk        r44   k79 ; k79 = 144
.line	270	loadk        r45   k80 ; k80 = 72
.line	270	loadk        r46   k81 ; k81 = 105
.line	270	call          r6    41     2
.line	270	getupval      r7    u1
.line	270	loadk         r8   k33 ; k33 = 73
.line	270	loadk         r9   k18 ; k18 = 83
.line	270	loadk        r10   k59 ; k59 = 15
.line	270	loadk        r11   k23 ; k23 = 102
.line	270	loadk        r12   k82 ; k82 = 147
.line	270	loadk        r13   k61 ; k61 = 182
.line	270	loadk        r14   k83 ; k83 = 34
.line	270	loadk        r15   k84 ; k84 = 78
.line	270	loadk        r16   k85 ; k85 = 52
.line	270	loadk        r17   k86 ; k86 = 67
.line	270	loadk        r18   k45 ; k45 = 60
.line	270	loadk        r19   k83 ; k83 = 34
.line	270	loadk        r20   k87 ; k87 = 226
.line	270	loadk        r21   k27 ; k27 = 76
.line	270	loadk        r22   k55 ; k55 = 22
.line	270	loadk        r23   k15 ; k15 = 26
.line	270	loadk        r24   k88 ; k88 = 136
.line	270	loadk        r25   k71 ; k71 = 98
.line	270	loadk        r26   k89 ; k89 = 123
.line	270	loadk        r27   k90 ; k90 = 12
.line	270	loadk        r28   k76 ; k76 = 14
.line	270	loadk        r29   k91 ; k91 = 176
.line	270	loadk        r30   k41 ; k41 = 84
.line	270	loadk        r31   k74 ; k74 = 121
.line	270	loadk        r32   k92 ; k92 = 63
.line	270	loadk        r33   k78 ; k78 = 81
.line	270	loadk        r34   k63 ; k63 = 20
.line	270	loadk        r35   k93 ; k93 = 46
.line	270	loadk        r36   k94 ; k94 = 239
.line	270	loadk        r37   k28 ; k28 = 122
.line	270	loadk        r38   k31 ; k31 = 17
.line	270	loadk        r39   k95 ; k95 = 10
.line	270	loadk        r40   k96 ; k96 = 184
.line	270	loadk        r41   k41 ; k41 = 84
.line	270	loadk        r42   k97 ; k97 = 119
.line	270	loadk        r43   k98 ; k98 = 1
.line	270	loadk        r44   k99 ; k99 = 92
.line	270	loadk        r45  k100 ; k100 = 135
.line	270	loadk        r46   k70 ; k70 = 100
.line	270	loadk        r47  k101 ; k101 = 110
.line	270	call          r7    41     2
.line	270	getupval      r8    u1
.line	270	loadk         r9   k41 ; k41 = 84
.line	270	loadk        r10  k102 ; k102 = 90
.line	270	loadk        r11   k31 ; k31 = 17
.line	270	call          r8     4     0
.line	270	setlist       r5     0     1
.line	270	call          r4     2     2
.line	270	call          r3     2     2
.line	270	gettable      r4    r3  k103 ; k103 = "IsCustomUIOrCanvas"
.line	270	move          r5    r2
.line	270	call          r4     2     2
.line	270	test          r4     0
.line	270	jmp            0  l193
.line	270	gettable      r4    r0  k104 ; k104 = "InstanceChangeCache"
.line	270	settable      r4    r1    r2
.line	270	gettable      r4    r0  k105 ; k105 = "ChangeInstanceHandle"
.line	270	test          r4     0
.line	270	jmp            0  l185
.line	270	self          r4    r0  k106 ; k106 = "RemoveTimer"
.line	270	gettable      r6    r0  k105 ; k105 = "ChangeInstanceHandle"
.line	270	call          r4     3     1
.line	270	settable      r0  k105    k0 ; k0 = nil
.label	l185
.line	270	gettable      r4    r0  k105 ; k105 = "ChangeInstanceHandle"
.line	270	test          r4     1
.line	270	jmp            0  l193
.line	270	self          r4    r0  k107 ; k107 = "AddTimerOnce"
.line	270	loadk         r6  k108 ; k108 = 0
.line	270	closure       r7    f0
.line	270	call          r4     4     2
.line	270	settable      r0  k105    r4 ; k105 = "ChangeInstanceHandle"
.label	l193
.line	270	return        r0     1
.line	270	move          r0    r0
.line	270	move          r0    r0
.line	270	return        r0     1

.function	main/f13/f0

.source	null
.linedefined	283
.lastlinedefined	290
.numparams	0
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	0	false
.upvalue	"U1"	0	true
.upvalue	"U2"	2	false

.constant	k0	"pairs"
.constant	k1	"InstanceChangeCache"
.constant	k2	"InstancePackToPbBuffer"
.constant	k3	"ChangeCustomUI"
.constant	k4	"ChangeInstanceHandle"
.constant	k5	nil

.line	283	gettabup      r0    u0    k0 ; k0 = "pairs"
.line	283	gettabup      r1    u1    k1 ; k1 = "InstanceChangeCache"
.line	283	call          r0     2     4
.line	283	jmp            0   l14
.line	283	gettabup      r5    u2    k2 ; k2 = "InstancePackToPbBuff" (truncated)
.line	283	move          r6    r4
.line	283	loadbool      r7     1     0
.line	283	call          r5     3     2
.line	283	getupval      r6    u1
.line	283	self          r6    r6    k3 ; k3 = "ChangeCustomUI"
.line	283	move          r8    r3
.line	283	move          r9    r5
.line	283	call          r6     4     1
.label	l14
.line	283	move          r0    r0
.line	283	move          r0    r0
.line	283	newtable      r0     0     0
.line	283	settabup      u1    k1    r0 ; k1 = "InstanceChangeCache"
.line	283	settabup      u1    k4    k5 ; k5 = nil
.line	283	return        r0     1
.line	283	move          r0    r0
.line	283	move          r0    r0
.line	283	move          r0    r0
.line	283	return        r0     1

.function	main/f14

.source	null
.linedefined	295
.lastlinedefined	305
.numparams	4
.is_vararg	0
.maxstacksize	11

.upvalue	"_ENV"	0	false

.constant	k0	"GetOwner"
.constant	k1	"slua"
.constant	k2	"isValid"
.constant	k3	"CreativeModeCustomUIFeature"
.constant	k4	"EnqueueFieldDelta"

.line	295	self          r4    r0    k0 ; k0 = "GetOwner"
.line	295	call          r4     2     2
.line	295	gettabup      r5    u0    k1 ; k1 = "slua"
.line	295	gettable      r5    r5    k2 ; k2 = "isValid"
.line	295	move          r6    r4
.line	295	call          r5     2     2
.line	295	test          r5     1
.line	295	jmp            0   l10
.line	295	return        r0     1
.label	l10
.line	295	gettable      r5    r4    k3 ; k3 = "CreativeModeCustomUI" (truncated)
.line	295	test          r5     1
.line	295	jmp            0   l14
.line	295	return        r0     1
.label	l14
.line	295	self          r6    r5    k4 ; k4 = "EnqueueFieldDelta"
.line	295	move          r8    r1
.line	295	move          r9    r2
.line	295	move         r10    r3
.line	295	call          r6     5     1
.line	295	return        r0     1
.line	295	move          r0    r0
.line	295	move          r0    r0
.line	295	move          r0    r0
.line	295	move          r0    r0
.line	295	return        r0     1

.function	main/f15

.source	null
.linedefined	307
.lastlinedefined	324
.numparams	3
.is_vararg	0
.maxstacksize	30

.upvalue	"_ENV"	1	true
.upvalue	"U1"	0	false

.constant	k0	"CustomUIData"
.constant	k1	"CustomUIBase"
.constant	k2	"Visible"
.constant	k3	"DSChangeCustomUIData"
.constant	k4	"HasAuthority"
.constant	k5	"_SendFieldDelta"
.constant	k6	126
.constant	k7	67
.constant	k8	17
.constant	k9	60
.constant	k10	191
.constant	k11	174
.constant	k12	4
.constant	k13	115
.constant	k14	25
.constant	k15	79
.constant	k16	26
.constant	k17	14
.constant	k18	152
.constant	k19	104
.constant	k20	12
.constant	k21	164
.constant	k22	100
.constant	k23	29
.constant	k24	"GetOwner"
.constant	k25	"slua"
.constant	k26	"isValid"
.constant	k27	"CreativeModeCustomUIFeature"
.constant	k28	"type"
.constant	k29	"_ApplyFieldValue"
.constant	k30	91
.constant	k31	43
.constant	k32	170
.constant	k33	62
.constant	k34	84
.constant	k35	"_HandleVFXAutoHide"

.line	307	gettable      r3    r0    k0 ; k0 = "CustomUIData"
.line	307	gettable      r3    r3    r1
.line	307	test          r3     0
.line	307	jmp            0    l8
.line	307	gettable      r4    r3    k1 ; k1 = "CustomUIBase"
.line	307	test          r4     1
.line	307	jmp            0    l9
.label	l8
.line	307	return        r0     1
.label	l9
.line	307	gettable      r4    r3    k1 ; k1 = "CustomUIBase"
.line	307	settable      r4    k2    r2 ; k2 = "Visible"
.line	307	self          r4    r0    k3 ; k3 = "DSChangeCustomUIData"
.line	307	move          r6    r1
.line	307	move          r7    r3
.line	307	call          r4     4     1
.line	307	self          r4    r0    k4 ; k4 = "HasAuthority"
.line	307	call          r4     2     2
.line	307	test          r4     0
.line	307	jmp            0   l46
.line	307	self          r4    r0    k5 ; k5 = "_SendFieldDelta"
.line	307	move          r6    r1
.line	307	getupval      r7    u0
.line	307	loadk         r8    k6 ; k6 = 126
.line	307	loadk         r9    k7 ; k7 = 67
.line	307	loadk        r10    k8 ; k8 = 17
.line	307	loadk        r11    k9 ; k9 = 60
.line	307	loadk        r12   k10 ; k10 = 191
.line	307	loadk        r13   k11 ; k11 = 174
.line	307	loadk        r14   k12 ; k12 = 4
.line	307	loadk        r15   k13 ; k13 = 115
.line	307	loadk        r16   k14 ; k14 = 25
.line	307	loadk        r17   k15 ; k15 = 79
.line	307	loadk        r18   k16 ; k16 = 26
.line	307	loadk        r19   k17 ; k17 = 14
.line	307	loadk        r20   k18 ; k18 = 152
.line	307	loadk        r21   k19 ; k19 = 104
.line	307	loadk        r22   k16 ; k16 = 26
.line	307	loadk        r23   k20 ; k20 = 12
.line	307	loadk        r24   k21 ; k21 = 164
.line	307	loadk        r25   k22 ; k22 = 100
.line	307	loadk        r26    k6 ; k6 = 126
.line	307	loadk        r27   k23 ; k23 = 29
.line	307	call          r7    21     2
.line	307	move          r8    r2
.line	307	call          r4     5     1
.line	307	jmp            0  l101
.label	l46
.line	307	self          r4    r0   k24 ; k24 = "GetOwner"
.line	307	call          r4     2     2
.line	307	gettabup      r5    u1   k25 ; k25 = "slua"
.line	307	gettable      r5    r5   k26 ; k26 = "isValid"
.line	307	move          r6    r4
.line	307	call          r5     2     2
.line	307	test          r5     0
.line	307	jmp            0   l57
.line	307	gettable      r5    r4   k27 ; k27 = "CreativeModeCustomUI" (truncated)
.line	307	test          r5     1
.line	307	jmp            0   l58
.label	l57
.line	307	loadnil       r5     0
.label	l58
.line	307	test          r5     0
.line	307	jmp            0  l101
.line	307	gettabup      r6    u1   k28 ; k28 = "type"
.line	307	gettable      r7    r5   k29 ; k29 = "_ApplyFieldValue"
.line	307	call          r6     2     2
.line	307	getupval      r7    u0
.line	307	loadk         r8   k30 ; k30 = 91
.line	307	loadk         r9    k7 ; k7 = 67
.line	307	loadk        r10   k20 ; k20 = 12
.line	307	loadk        r11   k31 ; k31 = 43
.line	307	loadk        r12   k21 ; k21 = 164
.line	307	loadk        r13   k32 ; k32 = 170
.line	307	loadk        r14   k33 ; k33 = 62
.line	307	loadk        r15   k34 ; k34 = 84
.line	307	call          r7     9     2
.line	307	eq             0    r6    r7
.line	307	jmp            0  l101
.line	307	self          r6    r5   k29 ; k29 = "_ApplyFieldValue"
.line	307	move          r8    r1
.line	307	getupval      r9    u0
.line	307	loadk        r10    k6 ; k6 = 126
.line	307	loadk        r11    k7 ; k7 = 67
.line	307	loadk        r12    k8 ; k8 = 17
.line	307	loadk        r13    k9 ; k9 = 60
.line	307	loadk        r14   k10 ; k10 = 191
.line	307	loadk        r15   k11 ; k11 = 174
.line	307	loadk        r16   k12 ; k12 = 4
.line	307	loadk        r17   k13 ; k13 = 115
.line	307	loadk        r18   k14 ; k14 = 25
.line	307	loadk        r19   k15 ; k15 = 79
.line	307	loadk        r20   k16 ; k16 = 26
.line	307	loadk        r21   k17 ; k17 = 14
.line	307	loadk        r22   k18 ; k18 = 152
.line	307	loadk        r23   k19 ; k19 = 104
.line	307	loadk        r24   k16 ; k16 = 26
.line	307	loadk        r25   k20 ; k20 = 12
.line	307	loadk        r26   k21 ; k21 = 164
.line	307	loadk        r27   k22 ; k22 = 100
.line	307	loadk        r28    k6 ; k6 = 126
.line	307	loadk        r29   k23 ; k23 = 29
.line	307	call          r9    21     2
.line	307	move         r10    r2
.line	307	call          r6     5     1
.label	l101
.line	307	self          r4    r0   k35 ; k35 = "_HandleVFXAutoHide"
.line	307	move          r6    r1
.line	307	move          r7    r3
.line	307	move          r8    r2
.line	307	call          r4     5     1
.line	307	return        r0     1
.line	307	move          r0    r0
.line	307	move          r0    r0
.line	307	move          r0    r0
.line	307	move          r0    r0
.line	307	return        r0     1

.function	main/f16

.source	null
.linedefined	326
.lastlinedefined	338
.numparams	2
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"ObjectGroup"
.constant	k1	"Children"
.constant	k2	"overrides"
.constant	k3	"type"
.constant	k4	73
.constant	k5	87
.constant	k6	0
.constant	k7	36
.constant	k8	181

.line	326	test          r1     0
.line	326	jmp            0    l6
.line	326	gettable      r2    r1    k0 ; k0 = "ObjectGroup"
.line	326	test          r2     1
.line	326	jmp            0    l8
.label	l6
.line	326	loadnil       r2     0
.line	326	return        r2     2
.label	l8
.line	326	gettable      r2    r1    k0 ; k0 = "ObjectGroup"
.line	326	gettable      r2    r2    k1 ; k1 = "Children"
.line	326	test          r2     0
.line	326	jmp            0   l16
.line	326	gettable      r3    r2    k2 ; k2 = "overrides"
.line	326	test          r3     0
.line	326	jmp            0   l16
.line	326	gettable      r2    r2    k2 ; k2 = "overrides"
.label	l16
.line	326	gettabup      r3    u0    k3 ; k3 = "type"
.line	326	move          r4    r2
.line	326	call          r3     2     2
.line	326	getupval      r4    u1
.line	326	loadk         r5    k4 ; k4 = 73
.line	326	loadk         r6    k5 ; k5 = 87
.line	326	loadk         r7    k6 ; k6 = 0
.line	326	loadk         r8    k7 ; k7 = 36
.line	326	loadk         r9    k8 ; k8 = 181
.line	326	call          r4     6     2
.line	326	eq             0    r3    r4
.line	326	jmp            0   l32
.line	326	len           r3    r2
.line	326	lt             0    k6    r3 ; k6 = 0
.line	326	jmp            0   l32
.line	326	return        r2     2
.label	l32
.line	326	loadnil       r3     0
.line	326	return        r3     2
.line	326	return        r0     1
.line	326	move          r0    r0
.line	326	return        r0     1

.function	main/f17

.source	null
.linedefined	340
.lastlinedefined	354
.numparams	3
.is_vararg	0
.maxstacksize	14

.upvalue	"_ENV"	0	false

.constant	k0	"CustomUIData"
.constant	k1	"GetInstanceChildren"
.constant	k2	1
.constant	k3	"tostring"
.constant	k4	"GetAllChildren"

.line	340	gettable      r3    r0    k0 ; k0 = "CustomUIData"
.line	340	gettable      r3    r3    r1
.line	340	test          r3     1
.line	340	jmp            0    l6
.line	340	return        r0     1
.label	l6
.line	340	self          r4    r0    k1 ; k1 = "GetInstanceChildren"
.line	340	move          r6    r3
.line	340	call          r4     3     2
.line	340	test          r4     1
.line	340	jmp            0   l12
.line	340	return        r0     1
.label	l12
.line	340	loadk         r5    k2 ; k2 = 1
.line	340	len           r6    r4
.line	340	loadk         r7    k2 ; k2 = 1
.line	340	move          r0    r0
.line	340	gettabup      r9    u0    k3 ; k3 = "tostring"
.line	340	gettable     r10    r4    r8
.line	340	call          r9     2     2
.line	340	len          r10    r2
.line	340	add          r10   r10    k2 ; k2 = 1
.line	340	settable      r2   r10    r9
.line	340	self         r10    r0    k4 ; k4 = "GetAllChildren"
.line	340	move         r12    r9
.line	340	move         r13    r2
.line	340	call         r10     4     1
.line	340	move          r0    r0
.line	340	return        r0     1
.line	340	move          r0    r0
.line	340	move          r0    r0
.line	340	return        r0     1

.function	main/f18

.source	null
.linedefined	356
.lastlinedefined	367
.numparams	3
.is_vararg	0
.maxstacksize	13

.constant	k0	"CustomUIData"
.constant	k1	"CustomUIBase"
.constant	k2	"ChangeUIVisibility"
.constant	k3	"GetAllChildren"
.constant	k4	1

.line	356	gettable      r3    r0    k0 ; k0 = "CustomUIData"
.line	356	gettable      r3    r3    r1
.line	356	test          r3     0
.line	356	jmp            0    l8
.line	356	gettable      r4    r3    k1 ; k1 = "CustomUIBase"
.line	356	test          r4     1
.line	356	jmp            0    l9
.label	l8
.line	356	return        r0     1
.label	l9
.line	356	self          r4    r0    k2 ; k2 = "ChangeUIVisibility"
.line	356	move          r6    r1
.line	356	move          r7    r2
.line	356	call          r4     4     1
.line	356	newtable      r4     0     0
.line	356	self          r5    r0    k3 ; k3 = "GetAllChildren"
.line	356	move          r7    r1
.line	356	move          r8    r4
.line	356	call          r5     4     1
.line	356	loadk         r5    k4 ; k4 = 1
.line	356	len           r6    r4
.line	356	loadk         r7    k4 ; k4 = 1
.line	356	move          r0    r0
.line	356	self          r9    r0    k2 ; k2 = "ChangeUIVisibility"
.line	356	gettable     r11    r4    r8
.line	356	move         r12    r2
.line	356	call          r9     4     1
.line	356	move          r0    r0
.line	356	return        r0     1
.line	356	move          r0    r0
.line	356	move          r0    r0
.line	356	move          r0    r0
.line	356	move          r0    r0
.line	356	return        r0     1

.function	main/f19

.source	null
.linedefined	369
.lastlinedefined	385
.numparams	4
.is_vararg	0
.maxstacksize	11

.constant	k0	"CustomUIVFX"
.constant	k1	"_RemoveVFXAutoHideTimer"
.constant	k2	"AutoHide"
.constant	k3	true
.constant	k4	"AutoHideTime"
.constant	k5	1
.constant	k6	"_VFXAutoHideTimers"
.constant	k7	"AddGameTimer"

.line	369	test          r2     0
.line	369	jmp            0    l6
.line	369	gettable      r4    r2    k0 ; k0 = "CustomUIVFX"
.line	369	test          r4     1
.line	369	jmp            0    l7
.label	l6
.line	369	return        r0     1
.label	l7
.line	369	self          r4    r0    k1 ; k1 = "_RemoveVFXAutoHideTi" (truncated)
.line	369	move          r6    r1
.line	369	call          r4     3     1
.line	369	test          r3     1
.line	369	jmp            0   l13
.line	369	return        r0     1
.label	l13
.line	369	gettable      r4    r2    k0 ; k0 = "CustomUIVFX"
.line	369	gettable      r4    r4    k2 ; k2 = "AutoHide"
.line	369	eq             1    r4    k3 ; k3 = true
.line	369	jmp            0   l18
.line	369	return        r0     1
.label	l18
.line	369	gettable      r4    r2    k0 ; k0 = "CustomUIVFX"
.line	369	gettable      r4    r4    k4 ; k4 = "AutoHideTime"
.line	369	test          r4     1
.line	369	jmp            0   l23
.line	369	loadk         r4    k5 ; k5 = 1
.label	l23
.line	369	gettable      r5    r0    k6 ; k6 = "_VFXAutoHideTimers"
.line	369	self          r6    r0    k7 ; k7 = "AddGameTimer"
.line	369	move          r8    r4
.line	369	loadbool      r9     0     0
.line	369	closure      r10    f0
.line	369	call          r6     5     2
.line	369	settable      r5    r1    r6
.line	369	return        r0     1
.line	369	move          r0    r0
.line	369	return        r0     1

.function	main/f19/f0

.source	null
.linedefined	381
.lastlinedefined	384
.numparams	0
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	true
.upvalue	"U1"	1	true

.constant	k0	"_VFXAutoHideTimers"
.constant	k1	nil
.constant	k2	"ChangeUIVisibility"

.line	381	gettabup      r0    u0    k0 ; k0 = "_VFXAutoHideTimers"
.line	381	getupval      r1    u1
.line	381	settable      r0    r1    k1 ; k1 = nil
.line	381	getupval      r0    u0
.line	381	self          r0    r0    k2 ; k2 = "ChangeUIVisibility"
.line	381	getupval      r2    u1
.line	381	loadbool      r3     0     0
.line	381	call          r0     4     1
.line	381	return        r0     1
.line	381	move          r0    r0
.line	381	move          r0    r0
.line	381	move          r0    r0
.line	381	move          r0    r0
.line	381	return        r0     1

.function	main/f20

.source	null
.linedefined	387
.lastlinedefined	393
.numparams	2
.is_vararg	0
.maxstacksize	6

.constant	k0	"_VFXAutoHideTimers"
.constant	k1	nil
.constant	k2	"RemoveGameTimer"

.line	387	gettable      r2    r0    k0 ; k0 = "_VFXAutoHideTimers"
.line	387	gettable      r2    r2    r1
.line	387	eq             1    r2    k1 ; k1 = nil
.line	387	jmp            0   l10
.line	387	self          r3    r0    k2 ; k2 = "RemoveGameTimer"
.line	387	move          r5    r2
.line	387	call          r3     3     1
.line	387	gettable      r3    r0    k0 ; k0 = "_VFXAutoHideTimers"
.line	387	settable      r3    r1    k1 ; k1 = nil
.label	l10
.line	387	return        r0     1
.line	387	move          r0    r0
.line	387	move          r0    r0
.line	387	move          r0    r0
.line	387	move          r0    r0
.line	387	return        r0     1

.function	main/f21

.source	null
.linedefined	395
.lastlinedefined	429
.numparams	7
.is_vararg	0
.maxstacksize	60

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	0
.constant	k1	"tonumber"
.constant	k2	"TriggerPlayerUID"
.constant	k3	-1
.constant	k4	"GetOwner"
.constant	k5	"slua"
.constant	k6	"isValid"
.constant	k7	"PlayerState"
.constant	k8	"UID"
.constant	k9	"tostring"
.constant	k10	61
.constant	k11	"BroadcastEventIndex"
.constant	k12	"pairs"
.constant	k13	"bShow"
.constant	k14	"ShowBranchKey"
.constant	k15	"print"
.constant	k16	"bWriteLog"
.constant	k17	"table"
.constant	k18	"concat"
.constant	k19	126
.constant	k20	68
.constant	k21	7
.constant	k22	41
.constant	k23	164
.constant	k24	170
.constant	k25	39
.constant	k26	95
.constant	k27	24
.constant	k28	91
.constant	k29	26
.constant	k30	31
.constant	k31	217
.constant	k32	83
.constant	k33	38
.constant	k34	54
.constant	k35	137
.constant	k36	103
.constant	k37	102
.constant	k38	25
.constant	k39	99
.constant	k40	156
.constant	k41	76
.constant	k42	122
.constant	k43	113
.constant	k44	23
.constant	k45	52
.constant	k46	196
.constant	k47	6
.constant	k48	12
.constant	k49	169
.constant	k50	84
.constant	k51	112
.constant	k52	81
.constant	k53	135
.constant	k54	82
.constant	k55	123
.constant	k56	78
.constant	k57	66
.constant	k58	62
.constant	k59	181
.constant	k60	173
.constant	k61	37
.constant	k62	15
.constant	k63	92
.constant	k64	16
.constant	k65	56
.constant	k66	222
.constant	k67	4
.constant	k68	"ChangeUIVisibilityWithChildren"
.constant	k69	"bHide"
.constant	k70	"HideBranchKey"
.constant	k71	35
.constant	k72	223
.constant	k73	90
.constant	k74	22

.line	395	test          r5     1
.line	395	jmp            0    l4
.line	395	loadk         r5    k0 ; k0 = 0
.label	l4
.line	395	test          r6     0
.line	395	jmp            0   l11
.line	395	gettabup      r7    u0    k1 ; k1 = "tonumber"
.line	395	gettable      r8    r6    k2 ; k2 = "TriggerPlayerUID"
.line	395	call          r7     2     2
.line	395	test          r7     1
.line	395	jmp            0   l12
.label	l11
.line	395	loadk         r7    k3 ; k3 = -1
.label	l12
.line	395	lt             0    k0    r7 ; k0 = 0
.line	395	jmp            0   l34
.line	395	self          r8    r0    k4 ; k4 = "GetOwner"
.line	395	call          r8     2     2
.line	395	gettabup      r9    u0    k5 ; k5 = "slua"
.line	395	gettable      r9    r9    k6 ; k6 = "isValid"
.line	395	move         r10    r8
.line	395	call          r9     2     2
.line	395	test          r9     1
.line	395	jmp            0   l23
.line	395	return        r0     1
.label	l23
.line	395	gettable      r9    r8    k7 ; k7 = "PlayerState"
.line	395	test          r9     0
.line	395	jmp            0   l30
.line	395	gettable      r9    r8    k7 ; k7 = "PlayerState"
.line	395	gettable      r9    r9    k8 ; k8 = "UID"
.line	395	test          r9     1
.line	395	jmp            0   l31
.label	l30
.line	395	loadk         r9    k0 ; k0 = 0
.label	l31
.line	395	eq             1    r9    r7
.line	395	jmp            0   l34
.line	395	return        r0     1
.label	l34
.line	395	gettabup      r8    u0    k9 ; k9 = "tostring"
.line	395	move          r9    r3
.line	395	call          r8     2     2
.line	395	getupval      r9    u1
.line	395	loadk        r10   k10 ; k10 = 61
.line	395	call          r9     2     2
.line	395	gettabup     r10    u0    k9 ; k9 = "tostring"
.line	395	move         r11    r4
.line	395	call         r10     2     2
.line	395	concat        r8    r8   r10
.line	395	gettable      r9    r0   k11 ; k11 = "BroadcastEventIndex"
.line	395	gettable      r9    r9    r8
.line	395	test          r9     1
.line	395	jmp            0   l49
.line	395	return        r0     1
.label	l49
.line	395	gettabup     r10    u0   k12 ; k12 = "pairs"
.line	395	move         r11    r9
.line	395	call         r10     2     4
.line	395	jmp            0  l229
.line	395	gettable     r15   r14   k13 ; k13 = "bShow"
.line	395	test         r15     0
.line	395	jmp            0  l141
.line	395	gettable     r15   r14   k14 ; k14 = "ShowBranchKey"
.line	395	test         r15     1
.line	395	jmp            0   l60
.line	395	loadk        r15    k0 ; k0 = 0
.label	l60
.line	395	le             1   r15    k0 ; k0 = 0
.line	395	jmp            0   l64
.line	395	eq             0   r15    r5
.line	395	jmp            0  l141
.label	l64
.line	395	gettabup     r16    u0   k15 ; k15 = "print"
.line	395	gettabup     r17    u0   k16 ; k16 = "bWriteLog"
.line	395	test         r17     0
.line	395	jmp            0  l132
.line	395	gettabup     r17    u0   k17 ; k17 = "table"
.line	395	gettable     r17   r17   k18 ; k18 = "concat"
.line	395	newtable     r18     1     0
.line	395	getupval     r19    u1
.line	395	loadk        r20   k19 ; k19 = 126
.line	395	loadk        r21   k20 ; k20 = 68
.line	395	loadk        r22   k21 ; k21 = 7
.line	395	loadk        r23   k22 ; k22 = 41
.line	395	loadk        r24   k23 ; k23 = 164
.line	395	loadk        r25   k24 ; k24 = 170
.line	395	loadk        r26   k25 ; k25 = 39
.line	395	loadk        r27   k26 ; k26 = 95
.line	395	loadk        r28   k27 ; k27 = 24
.line	395	loadk        r29   k28 ; k28 = 91
.line	395	loadk        r30   k29 ; k29 = 26
.line	395	loadk        r31   k30 ; k30 = 31
.line	395	loadk        r32   k31 ; k31 = 217
.line	395	loadk        r33   k32 ; k32 = 83
.line	395	loadk        r34   k33 ; k33 = 38
.line	395	loadk        r35   k34 ; k34 = 54
.line	395	loadk        r36   k35 ; k35 = 137
.line	395	loadk        r37   k36 ; k36 = 103
.line	395	loadk        r38   k37 ; k37 = 102
.line	395	loadk        r39   k38 ; k38 = 25
.line	395	loadk        r40   k39 ; k39 = 99
.line	395	loadk        r41   k40 ; k40 = 156
.line	395	loadk        r42   k41 ; k41 = 76
.line	395	loadk        r43   k42 ; k42 = 122
.line	395	loadk        r44   k43 ; k43 = 113
.line	395	loadk        r45   k43 ; k43 = 113
.line	395	loadk        r46   k44 ; k44 = 23
.line	395	loadk        r47   k45 ; k45 = 52
.line	395	loadk        r48   k46 ; k46 = 196
.line	395	loadk        r49   k20 ; k20 = 68
.line	395	loadk        r50   k47 ; k47 = 6
.line	395	loadk        r51   k48 ; k48 = 12
.line	395	loadk        r52   k49 ; k49 = 169
.line	395	loadk        r53   k50 ; k50 = 84
.line	395	loadk        r54   k51 ; k51 = 112
.line	395	loadk        r55   k21 ; k21 = 7
.line	395	loadk        r56   k52 ; k52 = 81
.line	395	loadk        r57   k53 ; k53 = 135
.line	395	loadk        r58   k54 ; k54 = 82
.line	395	loadk        r59   k55 ; k55 = 123
.line	395	call         r19    41     2
.line	395	getupval     r20    u1
.line	395	loadk        r21   k56 ; k56 = 78
.line	395	loadk        r22   k57 ; k57 = 66
.line	395	loadk        r23   k25 ; k25 = 39
.line	395	loadk        r24   k58 ; k58 = 62
.line	395	loadk        r25   k59 ; k59 = 181
.line	395	loadk        r26   k60 ; k60 = 173
.line	395	loadk        r27   k61 ; k61 = 37
.line	395	loadk        r28   k29 ; k29 = 26
.line	395	loadk        r29   k62 ; k62 = 15
.line	395	loadk        r30   k63 ; k63 = 92
.line	395	loadk        r31   k64 ; k64 = 16
.line	395	loadk        r32   k65 ; k65 = 56
.line	395	loadk        r33   k66 ; k66 = 222
.line	395	loadk        r34   k52 ; k52 = 81
.line	395	loadk        r35   k67 ; k67 = 4
.line	395	call         r20    16     0
.line	395	setlist      r18     0     1
.line	395	call         r17     2     2
.label	l132
.line	395	move         r18   r13
.line	395	move         r19    r3
.line	395	move         r20    r4
.line	395	move         r21    r5
.line	395	call         r16     6     1
.line	395	self         r16    r0   k68 ; k68 = "ChangeUIVisibilityWi" (truncated)
.line	395	move         r18   r13
.line	395	loadbool     r19     1     0
.line	395	call         r16     4     1
.label	l141
.line	395	gettable     r15   r14   k69 ; k69 = "bHide"
.line	395	test         r15     0
.line	395	jmp            0  l229
.line	395	gettable     r15   r14   k70 ; k70 = "HideBranchKey"
.line	395	test         r15     1
.line	395	jmp            0  l148
.line	395	loadk        r15    k0 ; k0 = 0
.label	l148
.line	395	le             1   r15    k0 ; k0 = 0
.line	395	jmp            0  l152
.line	395	eq             0   r15    r5
.line	395	jmp            0  l229
.label	l152
.line	395	gettabup     r16    u0   k15 ; k15 = "print"
.line	395	gettabup     r17    u0   k16 ; k16 = "bWriteLog"
.line	395	test         r17     0
.line	395	jmp            0  l220
.line	395	gettabup     r17    u0   k17 ; k17 = "table"
.line	395	gettable     r17   r17   k18 ; k18 = "concat"
.line	395	newtable     r18     1     0
.line	395	getupval     r19    u1
.line	395	loadk        r20   k19 ; k19 = 126
.line	395	loadk        r21   k20 ; k20 = 68
.line	395	loadk        r22   k21 ; k21 = 7
.line	395	loadk        r23   k22 ; k22 = 41
.line	395	loadk        r24   k23 ; k23 = 164
.line	395	loadk        r25   k24 ; k24 = 170
.line	395	loadk        r26   k25 ; k25 = 39
.line	395	loadk        r27   k26 ; k26 = 95
.line	395	loadk        r28   k27 ; k27 = 24
.line	395	loadk        r29   k28 ; k28 = 91
.line	395	loadk        r30   k29 ; k29 = 26
.line	395	loadk        r31   k30 ; k30 = 31
.line	395	loadk        r32   k31 ; k31 = 217
.line	395	loadk        r33   k32 ; k32 = 83
.line	395	loadk        r34   k33 ; k33 = 38
.line	395	loadk        r35   k34 ; k34 = 54
.line	395	loadk        r36   k35 ; k35 = 137
.line	395	loadk        r37   k36 ; k36 = 103
.line	395	loadk        r38   k37 ; k37 = 102
.line	395	loadk        r39   k38 ; k38 = 25
.line	395	loadk        r40   k39 ; k39 = 99
.line	395	loadk        r41   k40 ; k40 = 156
.line	395	loadk        r42   k41 ; k41 = 76
.line	395	loadk        r43   k42 ; k42 = 122
.line	395	loadk        r44   k43 ; k43 = 113
.line	395	loadk        r45   k43 ; k43 = 113
.line	395	loadk        r46   k44 ; k44 = 23
.line	395	loadk        r47   k45 ; k45 = 52
.line	395	loadk        r48   k46 ; k46 = 196
.line	395	loadk        r49   k20 ; k20 = 68
.line	395	loadk        r50   k47 ; k47 = 6
.line	395	loadk        r51   k48 ; k48 = 12
.line	395	loadk        r52   k49 ; k49 = 169
.line	395	loadk        r53   k50 ; k50 = 84
.line	395	loadk        r54   k51 ; k51 = 112
.line	395	loadk        r55   k21 ; k21 = 7
.line	395	loadk        r56   k52 ; k52 = 81
.line	395	loadk        r57   k53 ; k53 = 135
.line	395	loadk        r58   k54 ; k54 = 82
.line	395	loadk        r59   k55 ; k55 = 123
.line	395	call         r19    41     2
.line	395	getupval     r20    u1
.line	395	loadk        r21   k56 ; k56 = 78
.line	395	loadk        r22   k57 ; k57 = 66
.line	395	loadk        r23   k25 ; k25 = 39
.line	395	loadk        r24   k58 ; k58 = 62
.line	395	loadk        r25   k59 ; k59 = 181
.line	395	loadk        r26   k60 ; k60 = 173
.line	395	loadk        r27   k61 ; k61 = 37
.line	395	loadk        r28   k29 ; k29 = 26
.line	395	loadk        r29   k62 ; k62 = 15
.line	395	loadk        r30   k63 ; k63 = 92
.line	395	loadk        r31   k64 ; k64 = 16
.line	395	loadk        r32   k71 ; k71 = 35
.line	395	loadk        r33   k72 ; k72 = 223
.line	395	loadk        r34   k73 ; k73 = 90
.line	395	loadk        r35   k74 ; k74 = 22
.line	395	call         r20    16     0
.line	395	setlist      r18     0     1
.line	395	call         r17     2     2
.label	l220
.line	395	move         r18   r13
.line	395	move         r19    r3
.line	395	move         r20    r4
.line	395	move         r21    r5
.line	395	call         r16     6     1
.line	395	self         r16    r0   k68 ; k68 = "ChangeUIVisibilityWi" (truncated)
.line	395	move         r18   r13
.line	395	loadbool     r19     0     0
.line	395	call         r16     4     1
.label	l229
.line	395	move          r0    r0
.line	395	move          r0    r0
.line	395	return        r0     1
.line	395	move          r0    r0
.line	395	move          r0    r0
.line	395	move          r0    r0
.line	395	return        r0     1

.function	main/f22

.source	null
.linedefined	431
.lastlinedefined	455
.numparams	5
.is_vararg	0
.maxstacksize	55

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	nil
.constant	k1	"GetOwner"
.constant	k2	"slua"
.constant	k3	"isValid"
.constant	k4	"PlayerKey"
.constant	k5	"CustomEventIndex"
.constant	k6	"pairs"
.constant	k7	"bShow"
.constant	k8	"print"
.constant	k9	"bWriteLog"
.constant	k10	"table"
.constant	k11	"concat"
.constant	k12	126
.constant	k13	68
.constant	k14	7
.constant	k15	41
.constant	k16	164
.constant	k17	170
.constant	k18	39
.constant	k19	95
.constant	k20	24
.constant	k21	91
.constant	k22	26
.constant	k23	31
.constant	k24	217
.constant	k25	83
.constant	k26	38
.constant	k27	54
.constant	k28	137
.constant	k29	103
.constant	k30	102
.constant	k31	25
.constant	k32	99
.constant	k33	156
.constant	k34	76
.constant	k35	122
.constant	k36	113
.constant	k37	23
.constant	k38	56
.constant	k39	211
.constant	k40	93
.constant	k41	0
.constant	k42	176
.constant	k43	116
.constant	k44	13
.constant	k45	94
.constant	k46	151
.constant	k47	17
.constant	k48	78
.constant	k49	79
.constant	k50	49
.constant	k51	32
.constant	k52	191
.constant	k53	180
.constant	k54	"ChangeUIVisibilityWithChildren"
.constant	k55	"bHide"
.constant	k56	42
.constant	k57	33
.constant	k58	166

.line	431	eq             1    r4    k0 ; k0 = nil
.line	431	jmp            0   l16
.line	431	self          r5    r0    k1 ; k1 = "GetOwner"
.line	431	call          r5     2     2
.line	431	gettabup      r6    u0    k2 ; k2 = "slua"
.line	431	gettable      r6    r6    k3 ; k3 = "isValid"
.line	431	move          r7    r5
.line	431	call          r6     2     2
.line	431	test          r6     1
.line	431	jmp            0   l12
.line	431	return        r0     1
.label	l12
.line	431	gettable      r6    r5    k4 ; k4 = "PlayerKey"
.line	431	eq             1    r6    r4
.line	431	jmp            0   l16
.line	431	return        r0     1
.label	l16
.line	431	gettable      r5    r0    k5 ; k5 = "CustomEventIndex"
.line	431	gettable      r5    r5    r3
.line	431	test          r5     1
.line	431	jmp            0   l21
.line	431	return        r0     1
.label	l21
.line	431	gettabup      r6    u0    k6 ; k6 = "pairs"
.line	431	move          r7    r5
.line	431	call          r6     2     4
.line	431	jmp            0  l161
.line	431	gettable     r11   r10    k7 ; k7 = "bShow"
.line	431	test         r11     0
.line	431	jmp            0   l93
.line	431	gettabup     r11    u0    k8 ; k8 = "print"
.line	431	gettabup     r12    u0    k9 ; k9 = "bWriteLog"
.line	431	test         r12     0
.line	431	jmp            0   l87
.line	431	gettabup     r12    u0   k10 ; k10 = "table"
.line	431	gettable     r12   r12   k11 ; k11 = "concat"
.line	431	newtable     r13     1     0
.line	431	getupval     r14    u1
.line	431	loadk        r15   k12 ; k12 = 126
.line	431	loadk        r16   k13 ; k13 = 68
.line	431	loadk        r17   k14 ; k14 = 7
.line	431	loadk        r18   k15 ; k15 = 41
.line	431	loadk        r19   k16 ; k16 = 164
.line	431	loadk        r20   k17 ; k17 = 170
.line	431	loadk        r21   k18 ; k18 = 39
.line	431	loadk        r22   k19 ; k19 = 95
.line	431	loadk        r23   k20 ; k20 = 24
.line	431	loadk        r24   k21 ; k21 = 91
.line	431	loadk        r25   k22 ; k22 = 26
.line	431	loadk        r26   k23 ; k23 = 31
.line	431	loadk        r27   k24 ; k24 = 217
.line	431	loadk        r28   k25 ; k25 = 83
.line	431	loadk        r29   k26 ; k26 = 38
.line	431	loadk        r30   k27 ; k27 = 54
.line	431	loadk        r31   k28 ; k28 = 137
.line	431	loadk        r32   k29 ; k29 = 103
.line	431	loadk        r33   k30 ; k30 = 102
.line	431	loadk        r34   k31 ; k31 = 25
.line	431	loadk        r35   k32 ; k32 = 99
.line	431	loadk        r36   k33 ; k33 = 156
.line	431	loadk        r37   k34 ; k34 = 76
.line	431	loadk        r38   k35 ; k35 = 122
.line	431	loadk        r39   k36 ; k36 = 113
.line	431	loadk        r40   k36 ; k36 = 113
.line	431	loadk        r41   k37 ; k37 = 23
.line	431	loadk        r42   k38 ; k38 = 56
.line	431	loadk        r43   k39 ; k39 = 211
.line	431	loadk        r44   k40 ; k40 = 93
.line	431	loadk        r45   k37 ; k37 = 23
.line	431	loadk        r46   k41 ; k41 = 0
.line	431	loadk        r47   k42 ; k42 = 176
.line	431	loadk        r48   k25 ; k25 = 83
.line	431	loadk        r49   k43 ; k43 = 116
.line	431	loadk        r50   k44 ; k44 = 13
.line	431	loadk        r51   k45 ; k45 = 94
.line	431	loadk        r52   k46 ; k46 = 151
.line	431	loadk        r53   k47 ; k47 = 17
.line	431	loadk        r54   k48 ; k48 = 78
.line	431	call         r14    41     2
.line	431	getupval     r15    u1
.line	431	loadk        r16   k49 ; k49 = 79
.line	431	loadk        r17   k49 ; k49 = 79
.line	431	loadk        r18   k50 ; k50 = 49
.line	431	loadk        r19   k51 ; k51 = 32
.line	431	loadk        r20   k52 ; k52 = 191
.line	431	loadk        r21   k53 ; k53 = 180
.line	431	call         r15     7     0
.line	431	setlist      r13     0     1
.line	431	call         r12     2     2
.label	l87
.line	431	move         r13    r9
.line	431	call         r11     3     1
.line	431	self         r11    r0   k54 ; k54 = "ChangeUIVisibilityWi" (truncated)
.line	431	move         r13    r9
.line	431	loadbool     r14     1     0
.line	431	call         r11     4     1
.label	l93
.line	431	gettable     r11   r10   k55 ; k55 = "bHide"
.line	431	test         r11     0
.line	431	jmp            0  l161
.line	431	gettabup     r11    u0    k8 ; k8 = "print"
.line	431	gettabup     r12    u0    k9 ; k9 = "bWriteLog"
.line	431	test         r12     0
.line	431	jmp            0  l155
.line	431	gettabup     r12    u0   k10 ; k10 = "table"
.line	431	gettable     r12   r12   k11 ; k11 = "concat"
.line	431	newtable     r13     1     0
.line	431	getupval     r14    u1
.line	431	loadk        r15   k12 ; k12 = 126
.line	431	loadk        r16   k13 ; k13 = 68
.line	431	loadk        r17   k14 ; k14 = 7
.line	431	loadk        r18   k15 ; k15 = 41
.line	431	loadk        r19   k16 ; k16 = 164
.line	431	loadk        r20   k17 ; k17 = 170
.line	431	loadk        r21   k18 ; k18 = 39
.line	431	loadk        r22   k19 ; k19 = 95
.line	431	loadk        r23   k20 ; k20 = 24
.line	431	loadk        r24   k21 ; k21 = 91
.line	431	loadk        r25   k22 ; k22 = 26
.line	431	loadk        r26   k23 ; k23 = 31
.line	431	loadk        r27   k24 ; k24 = 217
.line	431	loadk        r28   k25 ; k25 = 83
.line	431	loadk        r29   k26 ; k26 = 38
.line	431	loadk        r30   k27 ; k27 = 54
.line	431	loadk        r31   k28 ; k28 = 137
.line	431	loadk        r32   k29 ; k29 = 103
.line	431	loadk        r33   k30 ; k30 = 102
.line	431	loadk        r34   k31 ; k31 = 25
.line	431	loadk        r35   k32 ; k32 = 99
.line	431	loadk        r36   k33 ; k33 = 156
.line	431	loadk        r37   k34 ; k34 = 76
.line	431	loadk        r38   k35 ; k35 = 122
.line	431	loadk        r39   k36 ; k36 = 113
.line	431	loadk        r40   k36 ; k36 = 113
.line	431	loadk        r41   k37 ; k37 = 23
.line	431	loadk        r42   k38 ; k38 = 56
.line	431	loadk        r43   k39 ; k39 = 211
.line	431	loadk        r44   k40 ; k40 = 93
.line	431	loadk        r45   k37 ; k37 = 23
.line	431	loadk        r46   k41 ; k41 = 0
.line	431	loadk        r47   k42 ; k42 = 176
.line	431	loadk        r48   k25 ; k25 = 83
.line	431	loadk        r49   k43 ; k43 = 116
.line	431	loadk        r50   k44 ; k44 = 13
.line	431	loadk        r51   k45 ; k45 = 94
.line	431	loadk        r52   k46 ; k46 = 151
.line	431	loadk        r53   k47 ; k47 = 17
.line	431	loadk        r54   k48 ; k48 = 78
.line	431	call         r14    41     2
.line	431	getupval     r15    u1
.line	431	loadk        r16   k49 ; k49 = 79
.line	431	loadk        r17   k49 ; k49 = 79
.line	431	loadk        r18   k56 ; k56 = 42
.line	431	loadk        r19   k57 ; k57 = 33
.line	431	loadk        r20   k53 ; k53 = 180
.line	431	loadk        r21   k58 ; k58 = 166
.line	431	call         r15     7     0
.line	431	setlist      r13     0     1
.line	431	call         r12     2     2
.label	l155
.line	431	move         r13    r9
.line	431	call         r11     3     1
.line	431	self         r11    r0   k54 ; k54 = "ChangeUIVisibilityWi" (truncated)
.line	431	move         r13    r9
.line	431	loadbool     r14     0     0
.line	431	call         r11     4     1
.label	l161
.line	431	move          r0    r0
.line	431	move          r0    r0
.line	431	return        r0     1
.line	431	move          r0    r0
.line	431	move          r0    r0
.line	431	move          r0    r0
.line	431	move          r0    r0
.line	431	return        r0     1

.function	main/f23

.source	null
.linedefined	457
.lastlinedefined	486
.numparams	6
.is_vararg	0
.maxstacksize	20

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"slua"
.constant	k1	"isValid"
.constant	k2	"GetOwner"
.constant	k3	nil
.constant	k4	"CustomUIData"
.constant	k5	"CustomUIVFX"
.constant	k6	"ClickAutoHide"
.constant	k7	true
.constant	k8	"GetCurPlayerState"
.constant	k9	"type"
.constant	k10	91
.constant	k11	67
.constant	k12	12
.constant	k13	43
.constant	k14	164
.constant	k15	170
.constant	k16	62
.constant	k17	84
.constant	k18	"PlayerState"
.constant	k19	"ChangeUIVisibilityWithChildren"

.line	457	gettabup      r6    u0    k0 ; k0 = "slua"
.line	457	gettable      r6    r6    k1 ; k1 = "isValid"
.line	457	move          r7    r3
.line	457	call          r6     2     2
.line	457	test          r6     1
.line	457	jmp            0    l8
.line	457	return        r0     1
.label	l8
.line	457	self          r6    r0    k2 ; k2 = "GetOwner"
.line	457	call          r6     2     2
.line	457	gettabup      r7    u0    k0 ; k0 = "slua"
.line	457	gettable      r7    r7    k1 ; k1 = "isValid"
.line	457	move          r8    r6
.line	457	call          r7     2     2
.line	457	test          r7     1
.line	457	jmp            0   l17
.line	457	return        r0     1
.label	l17
.line	457	eq             0    r5    k3 ; k3 = nil
.line	457	jmp            0   l20
.line	457	return        r0     1
.label	l20
.line	457	gettable      r7    r0    k4 ; k4 = "CustomUIData"
.line	457	gettable      r7    r7    r5
.line	457	test          r7     0
.line	457	jmp            0   l27
.line	457	gettable      r8    r7    k5 ; k5 = "CustomUIVFX"
.line	457	test          r8     1
.line	457	jmp            0   l28
.label	l27
.line	457	return        r0     1
.label	l28
.line	457	gettable      r8    r7    k5 ; k5 = "CustomUIVFX"
.line	457	gettable      r8    r8    k6 ; k6 = "ClickAutoHide"
.line	457	eq             1    r8    k7 ; k7 = true
.line	457	jmp            0   l33
.line	457	return        r0     1
.label	l33
.line	457	loadnil       r8     0
.line	457	gettable      r9    r6    k8 ; k8 = "GetCurPlayerState"
.line	457	gettabup     r10    u0    k9 ; k9 = "type"
.line	457	move         r11    r9
.line	457	call         r10     2     2
.line	457	getupval     r11    u1
.line	457	loadk        r12   k10 ; k10 = 91
.line	457	loadk        r13   k11 ; k11 = 67
.line	457	loadk        r14   k12 ; k12 = 12
.line	457	loadk        r15   k13 ; k13 = 43
.line	457	loadk        r16   k14 ; k14 = 164
.line	457	loadk        r17   k15 ; k15 = 170
.line	457	loadk        r18   k16 ; k16 = 62
.line	457	loadk        r19   k17 ; k17 = 84
.line	457	call         r11     9     2
.line	457	eq             0   r10   r11
.line	457	jmp            0   l55
.line	457	move         r10    r9
.line	457	move         r11    r6
.line	457	call         r10     2     2
.line	457	move          r8   r10
.line	457	jmp            0   l56
.label	l55
.line	457	gettable      r8    r6   k18 ; k18 = "PlayerState"
.label	l56
.line	457	eq             1    r8    r3
.line	457	jmp            0   l59
.line	457	return        r0     1
.label	l59
.line	457	self         r10    r0   k19 ; k19 = "ChangeUIVisibilityWi" (truncated)
.line	457	move         r12    r5
.line	457	loadbool     r13     0     0
.line	457	call         r10     4     1
.line	457	return        r0     1
.line	457	move          r0    r0
.line	457	move          r0    r0
.line	457	move          r0    r0
.line	457	move          r0    r0
.line	457	return        r0     1

.function	main/f24

.source	null
.linedefined	488
.lastlinedefined	532
.numparams	3
.is_vararg	0
.maxstacksize	54

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"IsPreviewInstance"
.constant	k2	"import"
.constant	k3	120
.constant	k4	117
.constant	k5	16
.constant	k6	45
.constant	k7	177
.constant	k8	183
.constant	k9	56
.constant	k10	76
.constant	k11	62
.constant	k12	99
.constant	k13	6
.constant	k14	15
.constant	k15	211
.constant	k16	121
.constant	k17	18
.constant	k18	168
.constant	k19	82
.constant	k20	107
.constant	k21	8
.constant	k22	69
.constant	k23	"CGameState"
.constant	k24	"slua"
.constant	k25	"isValid"
.constant	k26	"GetCurrentGameType"
.constant	k27	"CreativeModeGameType_Game"
.constant	k28	"PendingLoadRuntimeIds"
.constant	k29	true
.constant	k30	"print"
.constant	k31	"bWriteLog"
.constant	k32	"table"
.constant	k33	"concat"
.constant	k34	126
.constant	k35	68
.constant	k36	7
.constant	k37	41
.constant	k38	164
.constant	k39	170
.constant	k40	39
.constant	k41	95
.constant	k42	24
.constant	k43	91
.constant	k44	26
.constant	k45	31
.constant	k46	217
.constant	k47	83
.constant	k48	38
.constant	k49	54
.constant	k50	137
.constant	k51	103
.constant	k52	102
.constant	k53	25
.constant	k54	156
.constant	k55	122
.constant	k56	113
.constant	k57	125
.constant	k58	21
.constant	k59	195
.constant	k60	64
.constant	k61	23
.constant	k62	59
.constant	k63	175
.constant	k64	111
.constant	k65	78
.constant	k66	81
.constant	k67	135
.constant	k68	114
.constant	k69	66
.constant	k70	13
.constant	k71	37
.constant	k72	133
.constant	k73	138
.constant	k74	30
.constant	k75	88
.constant	k76	49
.constant	k77	75
.constant	k78	10
.constant	k79	150
.constant	k80	28
.constant	k81	165
.constant	k82	180
.constant	k83	46
.constant	k84	106
.constant	k85	0
.constant	k86	11
.constant	k87	14
.constant	k88	169
.constant	k89	9
.constant	k90	93
.constant	k91	134
.constant	k92	101
.constant	k93	77
.constant	k94	104
.constant	k95	160
.constant	k96	166
.constant	k97	63
.constant	k98	94
.constant	k99	50
.constant	k100	"GetLoadManager"
.constant	k101	"bNewCustomUI"
.constant	k102	"GetCDOInstanceIDOfInstance"
.constant	k103	"RuntimeToCDO"
.constant	k104	55
.constant	k105	48
.constant	k106	132
.constant	k107	98
.constant	k108	73
.constant	k109	128
.constant	k110	89
.constant	k111	"CustomUIObject"
.constant	k112	"_CreateCustomUILuaObject"
.constant	k113	58
.constant	k114	108
.constant	k115	119
.constant	k116	27
.constant	k117	84
.constant	k118	112
.constant	k119	67
.constant	k120	12
.constant	k121	60
.constant	k122	185
.constant	k123	174
.constant	k124	52
.constant	k125	115
.constant	k126	19
.constant	k127	1
.constant	k128	254
.constant	k129	"GetOwner"
.constant	k130	"AddRuntimeInstanceData"
.constant	k131	127
.constant	k132	40
.constant	k133	213
.constant	k134	36
.constant	k135	130
.constant	k136	53
.constant	k137	74
.constant	k138	"tostring"
.constant	k139	"RuntimeReady"
.constant	k140	"OnNodeObjectReady"

.line	488	gettabup      r3    u0    k0 ; k0 = "Client"
.line	488	test          r3     1
.line	488	jmp            0    l5
.line	488	return        r0     1
.label	l5
.line	488	test          r2     1
.line	488	jmp            0    l8
.line	488	return        r0     1
.label	l8
.line	488	self          r3    r0    k1 ; k1 = "IsPreviewInstance"
.line	488	move          r5    r1
.line	488	call          r3     3     2
.line	488	gettabup      r4    u0    k2 ; k2 = "import"
.line	488	getupval      r5    u1
.line	488	loadk         r6    k3 ; k3 = 120
.line	488	loadk         r7    k4 ; k4 = 117
.line	488	loadk         r8    k5 ; k5 = 16
.line	488	loadk         r9    k6 ; k6 = 45
.line	488	loadk        r10    k7 ; k7 = 177
.line	488	loadk        r11    k8 ; k8 = 183
.line	488	loadk        r12    k9 ; k9 = 56
.line	488	loadk        r13   k10 ; k10 = 76
.line	488	loadk        r14   k11 ; k11 = 62
.line	488	loadk        r15   k12 ; k12 = 99
.line	488	loadk        r16   k13 ; k13 = 6
.line	488	loadk        r17   k14 ; k14 = 15
.line	488	loadk        r18   k15 ; k15 = 211
.line	488	loadk        r19   k16 ; k16 = 121
.line	488	loadk        r20   k17 ; k17 = 18
.line	488	loadk        r21   k17 ; k17 = 18
.line	488	loadk        r22   k18 ; k18 = 168
.line	488	loadk        r23   k19 ; k19 = 82
.line	488	loadk        r24   k20 ; k20 = 107
.line	488	loadk        r25   k21 ; k21 = 8
.line	488	loadk        r26   k22 ; k22 = 69
.line	488	call          r5    22     2
.line	488	call          r4     2     2
.line	488	test          r3     1
.line	488	jmp            0  l164
.line	488	gettabup      r5    u0   k23 ; k23 = "CGameState"
.line	488	test          r5     0
.line	488	jmp            0  l164
.line	488	gettabup      r5    u0   k24 ; k24 = "slua"
.line	488	gettable      r5    r5   k25 ; k25 = "isValid"
.line	488	gettabup      r6    u0   k23 ; k23 = "CGameState"
.line	488	call          r5     2     2
.line	488	test          r5     0
.line	488	jmp            0  l164
.line	488	gettabup      r5    u0   k23 ; k23 = "CGameState"
.line	488	self          r5    r5   k26 ; k26 = "GetCurrentGameType"
.line	488	call          r5     2     2
.line	488	gettable      r6    r4   k27 ; k27 = "CreativeModeGameType" (truncated)
.line	488	eq             1    r5    r6
.line	488	jmp            0  l164
.line	488	gettable      r5    r0   k28 ; k28 = "PendingLoadRuntimeId" (truncated)
.line	488	settable      r5    r1   k29 ; k29 = true
.line	488	gettabup      r5    u0   k30 ; k30 = "print"
.line	488	gettabup      r6    u0   k31 ; k31 = "bWriteLog"
.line	488	test          r6     0
.line	488	jmp            0  l161
.line	488	gettabup      r6    u0   k32 ; k32 = "table"
.line	488	gettable      r6    r6   k33 ; k33 = "concat"
.line	488	newtable      r7     2     0
.line	488	getupval      r8    u1
.line	488	loadk         r9   k34 ; k34 = 126
.line	488	loadk        r10   k35 ; k35 = 68
.line	488	loadk        r11   k36 ; k36 = 7
.line	488	loadk        r12   k37 ; k37 = 41
.line	488	loadk        r13   k38 ; k38 = 164
.line	488	loadk        r14   k39 ; k39 = 170
.line	488	loadk        r15   k40 ; k40 = 39
.line	488	loadk        r16   k41 ; k41 = 95
.line	488	loadk        r17   k42 ; k42 = 24
.line	488	loadk        r18   k43 ; k43 = 91
.line	488	loadk        r19   k44 ; k44 = 26
.line	488	loadk        r20   k45 ; k45 = 31
.line	488	loadk        r21   k46 ; k46 = 217
.line	488	loadk        r22   k47 ; k47 = 83
.line	488	loadk        r23   k48 ; k48 = 38
.line	488	loadk        r24   k49 ; k49 = 54
.line	488	loadk        r25   k50 ; k50 = 137
.line	488	loadk        r26   k51 ; k51 = 103
.line	488	loadk        r27   k52 ; k52 = 102
.line	488	loadk        r28   k53 ; k53 = 25
.line	488	loadk        r29   k12 ; k12 = 99
.line	488	loadk        r30   k54 ; k54 = 156
.line	488	loadk        r31   k10 ; k10 = 76
.line	488	loadk        r32   k55 ; k55 = 122
.line	488	loadk        r33   k56 ; k56 = 113
.line	488	loadk        r34   k57 ; k57 = 125
.line	488	loadk        r35   k58 ; k58 = 21
.line	488	loadk        r36   k17 ; k17 = 18
.line	488	loadk        r37   k59 ; k59 = 195
.line	488	loadk        r38   k60 ; k60 = 64
.line	488	loadk        r39   k61 ; k61 = 23
.line	488	loadk        r40   k62 ; k62 = 59
.line	488	loadk        r41   k63 ; k63 = 175
.line	488	loadk        r42   k64 ; k64 = 111
.line	488	loadk        r43   k65 ; k65 = 78
.line	488	loadk        r44   k36 ; k36 = 7
.line	488	loadk        r45   k66 ; k66 = 81
.line	488	loadk        r46   k67 ; k67 = 135
.line	488	loadk        r47   k68 ; k68 = 114
.line	488	loadk        r48   k64 ; k64 = 111
.line	488	call          r8    41     2
.line	488	getupval      r9    u1
.line	488	loadk        r10   k65 ; k65 = 78
.line	488	loadk        r11   k69 ; k69 = 66
.line	488	loadk        r12   k70 ; k70 = 13
.line	488	loadk        r13   k71 ; k71 = 37
.line	488	loadk        r14   k72 ; k72 = 133
.line	488	loadk        r15   k73 ; k73 = 138
.line	488	loadk        r16   k74 ; k74 = 30
.line	488	loadk        r17   k75 ; k75 = 88
.line	488	loadk        r18   k76 ; k76 = 49
.line	488	loadk        r19   k77 ; k77 = 75
.line	488	loadk        r20   k78 ; k78 = 10
.line	488	loadk        r21   k45 ; k45 = 31
.line	488	loadk        r22   k79 ; k79 = 150
.line	488	loadk        r23   k57 ; k57 = 125
.line	488	loadk        r24   k17 ; k17 = 18
.line	488	loadk        r25   k80 ; k80 = 28
.line	488	loadk        r26   k81 ; k81 = 165
.line	488	loadk        r27   k12 ; k12 = 99
.line	488	loadk        r28   k66 ; k66 = 81
.line	488	loadk        r29   k70 ; k70 = 13
.line	488	loadk        r30   k19 ; k19 = 82
.line	488	loadk        r31   k82 ; k82 = 180
.line	488	loadk        r32   k60 ; k60 = 64
.line	488	loadk        r33   k51 ; k51 = 103
.line	488	loadk        r34   k83 ; k83 = 46
.line	488	loadk        r35   k84 ; k84 = 106
.line	488	loadk        r36   k85 ; k85 = 0
.line	488	loadk        r37   k86 ; k86 = 11
.line	488	loadk        r38   k59 ; k59 = 195
.line	488	loadk        r39   k87 ; k87 = 14
.line	488	loadk        r40   k70 ; k70 = 13
.line	488	loadk        r41   k85 ; k85 = 0
.line	488	loadk        r42   k88 ; k88 = 169
.line	488	loadk        r43   k49 ; k49 = 54
.line	488	loadk        r44   k22 ; k22 = 69
.line	488	loadk        r45   k89 ; k89 = 9
.line	488	loadk        r46   k90 ; k90 = 93
.line	488	loadk        r47   k91 ; k91 = 134
.line	488	loadk        r48   k92 ; k92 = 101
.line	488	loadk        r49   k12 ; k12 = 99
.line	488	call          r9    41     2
.line	488	getupval     r10    u1
.line	488	loadk        r11   k93 ; k93 = 77
.line	488	loadk        r12   k47 ; k47 = 83
.line	488	loadk        r13   k65 ; k65 = 78
.line	488	loadk        r14   k94 ; k94 = 104
.line	488	loadk        r15   k95 ; k95 = 160
.line	488	loadk        r16   k96 ; k96 = 166
.line	488	loadk        r17   k97 ; k97 = 63
.line	488	loadk        r18   k98 ; k98 = 94
.line	488	loadk        r19   k99 ; k99 = 50
.line	488	loadk        r20   k60 ; k60 = 64
.line	488	loadk        r21   k87 ; k87 = 14
.line	488	call         r10    12     0
.line	488	setlist       r7     0     1
.line	488	call          r6     2     2
.label	l161
.line	488	move          r7    r1
.line	488	call          r5     3     1
.line	488	return        r0     1
.label	l164
.line	488	gettabup      r5    u0  k100 ; k100 = "GetLoadManager"
.line	488	call          r5     1     2
.line	488	test          r5     0
.line	488	jmp            0  l171
.line	488	gettable      r6    r5  k101 ; k101 = "bNewCustomUI"
.line	488	test          r6     1
.line	488	jmp            0  l172
.label	l171
.line	488	return        r0     1
.label	l172
.line	488	self          r6    r0  k102 ; k102 = "GetCDOInstanceIDOfIn" (truncated)
.line	488	move          r8    r2
.line	488	call          r6     3     2
.line	488	test          r6     0
.line	488	jmp            0  l181
.line	488	getupval      r7    u1
.line	488	call          r7     1     2
.line	488	eq             0    r6    r7
.line	488	jmp            0  l183
.label	l181
.line	488	gettable      r7    r0  k103 ; k103 = "RuntimeToCDO"
.line	488	gettable      r6    r7    r1
.label	l183
.line	488	test          r6     1
.line	488	jmp            0  l267
.line	488	gettabup      r7    u0   k30 ; k30 = "print"
.line	488	gettabup      r8    u0   k31 ; k31 = "bWriteLog"
.line	488	test          r8     0
.line	488	jmp            0  l264
.line	488	gettabup      r8    u0   k32 ; k32 = "table"
.line	488	gettable      r8    r8   k33 ; k33 = "concat"
.line	488	newtable      r9     1     0
.line	488	getupval     r10    u1
.line	488	loadk        r11   k34 ; k34 = 126
.line	488	loadk        r12   k35 ; k35 = 68
.line	488	loadk        r13   k36 ; k36 = 7
.line	488	loadk        r14   k37 ; k37 = 41
.line	488	loadk        r15   k38 ; k38 = 164
.line	488	loadk        r16   k39 ; k39 = 170
.line	488	loadk        r17   k40 ; k40 = 39
.line	488	loadk        r18   k41 ; k41 = 95
.line	488	loadk        r19   k42 ; k42 = 24
.line	488	loadk        r20   k43 ; k43 = 91
.line	488	loadk        r21   k44 ; k44 = 26
.line	488	loadk        r22   k45 ; k45 = 31
.line	488	loadk        r23   k46 ; k46 = 217
.line	488	loadk        r24   k47 ; k47 = 83
.line	488	loadk        r25   k48 ; k48 = 38
.line	488	loadk        r26   k49 ; k49 = 54
.line	488	loadk        r27   k50 ; k50 = 137
.line	488	loadk        r28   k51 ; k51 = 103
.line	488	loadk        r29   k52 ; k52 = 102
.line	488	loadk        r30   k53 ; k53 = 25
.line	488	loadk        r31   k12 ; k12 = 99
.line	488	loadk        r32   k54 ; k54 = 156
.line	488	loadk        r33   k10 ; k10 = 76
.line	488	loadk        r34   k55 ; k55 = 122
.line	488	loadk        r35   k56 ; k56 = 113
.line	488	loadk        r36   k57 ; k57 = 125
.line	488	loadk        r37   k58 ; k58 = 21
.line	488	loadk        r38   k17 ; k17 = 18
.line	488	loadk        r39   k59 ; k59 = 195
.line	488	loadk        r40   k60 ; k60 = 64
.line	488	loadk        r41   k61 ; k61 = 23
.line	488	loadk        r42   k62 ; k62 = 59
.line	488	loadk        r43   k63 ; k63 = 175
.line	488	loadk        r44   k64 ; k64 = 111
.line	488	loadk        r45   k65 ; k65 = 78
.line	488	loadk        r46   k36 ; k36 = 7
.line	488	loadk        r47   k66 ; k66 = 81
.line	488	loadk        r48   k67 ; k67 = 135
.line	488	loadk        r49   k68 ; k68 = 114
.line	488	loadk        r50   k64 ; k64 = 111
.line	488	call         r10    41     2
.line	488	getupval     r11    u1
.line	488	loadk        r12   k65 ; k65 = 78
.line	488	loadk        r13   k69 ; k69 = 66
.line	488	loadk        r14   k70 ; k70 = 13
.line	488	loadk        r15   k71 ; k71 = 37
.line	488	loadk        r16   k72 ; k72 = 133
.line	488	loadk        r17   k73 ; k73 = 138
.line	488	loadk        r18   k74 ; k74 = 30
.line	488	loadk        r19   k75 ; k75 = 88
.line	488	loadk        r20   k76 ; k76 = 49
.line	488	loadk        r21   k77 ; k77 = 75
.line	488	loadk        r22   k78 ; k78 = 10
.line	488	loadk        r23   k45 ; k45 = 31
.line	488	loadk        r24   k79 ; k79 = 150
.line	488	loadk        r25   k57 ; k57 = 125
.line	488	loadk        r26  k104 ; k104 = 55
.line	488	loadk        r27  k105 ; k105 = 48
.line	488	loadk        r28  k106 ; k106 = 132
.line	488	loadk        r29  k107 ; k107 = 98
.line	488	loadk        r30   k99 ; k99 = 50
.line	488	loadk        r31   k58 ; k58 = 21
.line	488	loadk        r32  k108 ; k108 = 73
.line	488	loadk        r33  k109 ; k109 = 128
.line	488	loadk        r34   k19 ; k19 = 82
.line	488	loadk        r35   k12 ; k12 = 99
.line	488	loadk        r36   k71 ; k71 = 37
.line	488	loadk        r37  k110 ; k110 = 89
.line	488	call         r11    27     0
.line	488	setlist       r9     0     1
.line	488	call          r8     2     2
.label	l264
.line	488	move          r9    r1
.line	488	call          r7     3     1
.line	488	return        r0     1
.label	l267
.line	488	gettable      r7    r0  k111 ; k111 = "CustomUIObject"
.line	488	gettable      r7    r7    r6
.line	488	test          r7     1
.line	488	jmp            0  l385
.line	488	self          r8    r0  k112 ; k112 = "_CreateCustomUILuaOb" (truncated)
.line	488	move         r10    r6
.line	488	move         r11    r2
.line	488	call          r8     4     2
.line	488	move          r7    r8
.line	488	test          r7     1
.line	488	jmp            0  l383
.line	488	gettabup      r8    u0   k30 ; k30 = "print"
.line	488	gettabup      r9    u0   k31 ; k31 = "bWriteLog"
.line	488	test          r9     0
.line	488	jmp            0  l359
.line	488	gettabup      r9    u0   k32 ; k32 = "table"
.line	488	gettable      r9    r9   k33 ; k33 = "concat"
.line	488	newtable     r10     1     0
.line	488	getupval     r11    u1
.line	488	loadk        r12   k34 ; k34 = 126
.line	488	loadk        r13   k35 ; k35 = 68
.line	488	loadk        r14   k36 ; k36 = 7
.line	488	loadk        r15   k37 ; k37 = 41
.line	488	loadk        r16   k38 ; k38 = 164
.line	488	loadk        r17   k39 ; k39 = 170
.line	488	loadk        r18   k40 ; k40 = 39
.line	488	loadk        r19   k41 ; k41 = 95
.line	488	loadk        r20   k42 ; k42 = 24
.line	488	loadk        r21   k43 ; k43 = 91
.line	488	loadk        r22   k44 ; k44 = 26
.line	488	loadk        r23   k45 ; k45 = 31
.line	488	loadk        r24   k46 ; k46 = 217
.line	488	loadk        r25   k47 ; k47 = 83
.line	488	loadk        r26   k48 ; k48 = 38
.line	488	loadk        r27   k49 ; k49 = 54
.line	488	loadk        r28   k50 ; k50 = 137
.line	488	loadk        r29   k51 ; k51 = 103
.line	488	loadk        r30   k52 ; k52 = 102
.line	488	loadk        r31   k53 ; k53 = 25
.line	488	loadk        r32   k12 ; k12 = 99
.line	488	loadk        r33   k54 ; k54 = 156
.line	488	loadk        r34   k10 ; k10 = 76
.line	488	loadk        r35   k55 ; k55 = 122
.line	488	loadk        r36   k56 ; k56 = 113
.line	488	loadk        r37   k57 ; k57 = 125
.line	488	loadk        r38   k58 ; k58 = 21
.line	488	loadk        r39   k17 ; k17 = 18
.line	488	loadk        r40   k59 ; k59 = 195
.line	488	loadk        r41   k60 ; k60 = 64
.line	488	loadk        r42   k61 ; k61 = 23
.line	488	loadk        r43   k62 ; k62 = 59
.line	488	loadk        r44   k63 ; k63 = 175
.line	488	loadk        r45   k64 ; k64 = 111
.line	488	loadk        r46   k65 ; k65 = 78
.line	488	loadk        r47   k36 ; k36 = 7
.line	488	loadk        r48   k66 ; k66 = 81
.line	488	loadk        r49   k67 ; k67 = 135
.line	488	loadk        r50   k68 ; k68 = 114
.line	488	loadk        r51   k64 ; k64 = 111
.line	488	call         r11    41     2
.line	488	getupval     r12    u1
.line	488	loadk        r13   k65 ; k65 = 78
.line	488	loadk        r14   k69 ; k69 = 66
.line	488	loadk        r15   k70 ; k70 = 13
.line	488	loadk        r16   k71 ; k71 = 37
.line	488	loadk        r17   k72 ; k72 = 133
.line	488	loadk        r18   k73 ; k73 = 138
.line	488	loadk        r19   k74 ; k74 = 30
.line	488	loadk        r20   k75 ; k75 = 88
.line	488	loadk        r21   k76 ; k76 = 49
.line	488	loadk        r22   k77 ; k77 = 75
.line	488	loadk        r23   k78 ; k78 = 10
.line	488	loadk        r24   k45 ; k45 = 31
.line	488	loadk        r25   k79 ; k79 = 150
.line	488	loadk        r26   k20 ; k20 = 107
.line	488	loadk        r27  k113 ; k113 = 58
.line	488	loadk        r28  k105 ; k105 = 48
.line	488	loadk        r29   k63 ; k63 = 175
.line	488	loadk        r30  k114 ; k114 = 108
.line	488	loadk        r31  k115 ; k115 = 119
.line	488	loadk        r32  k116 ; k116 = 27
.line	488	loadk        r33  k117 ; k117 = 84
.line	488	loadk        r34   k15 ; k15 = 211
.line	488	loadk        r35   k94 ; k94 = 104
.line	488	loadk        r36   k16 ; k16 = 121
.line	488	loadk        r37   k20 ; k20 = 107
.line	488	loadk        r38  k118 ; k118 = 112
.line	488	loadk        r39    k5 ; k5 = 16
.line	488	loadk        r40   k61 ; k61 = 23
.line	488	call         r12    29     0
.line	488	setlist      r10     0     1
.line	488	call          r9     2     2
.label	l359
.line	488	getupval     r10    u1
.line	488	loadk        r11   k64 ; k64 = 111
.line	488	loadk        r12  k119 ; k119 = 67
.line	488	loadk        r13  k120 ; k120 = 12
.line	488	loadk        r14  k121 ; k121 = 60
.line	488	loadk        r15  k122 ; k122 = 185
.line	488	loadk        r16  k123 ; k123 = 174
.line	488	loadk        r17  k124 ; k124 = 52
.line	488	loadk        r18  k125 ; k125 = 115
.line	488	loadk        r19   k97 ; k97 = 63
.line	488	loadk        r20  k126 ; k126 = 19
.line	488	call         r10    11     2
.line	488	move         r11    r1
.line	488	getupval     r12    u1
.line	488	loadk        r13   k34 ; k34 = 126
.line	488	loadk        r14   k68 ; k68 = 114
.line	488	loadk        r15    k6 ; k6 = 45
.line	488	loadk        r16  k127 ; k127 = 1
.line	488	loadk        r17   k82 ; k82 = 180
.line	488	loadk        r18  k128 ; k128 = 254
.line	488	call         r12     7     2
.line	488	move         r13    r6
.line	488	call          r8     6     1
.line	488	return        r0     1
.label	l383
.line	488	gettable      r8    r0  k111 ; k111 = "CustomUIObject"
.line	488	settable      r8    r6    r7
.label	l385
.line	488	self          r8    r0  k129 ; k129 = "GetOwner"
.line	488	call          r8     2     2
.line	488	test          r7     0
.line	488	jmp            0  l528
.line	488	gettabup      r9    u0   k24 ; k24 = "slua"
.line	488	gettable      r9    r9   k25 ; k25 = "isValid"
.line	488	move         r10    r8
.line	488	call          r9     2     2
.line	488	test          r9     0
.line	488	jmp            0  l528
.line	488	self          r9    r7  k130 ; k130 = "AddRuntimeInstanceDa" (truncated)
.line	488	move         r11    r8
.line	488	move         r12    r1
.line	488	move         r13    r2
.line	488	call          r9     5     2
.line	488	gettabup     r10    u0   k30 ; k30 = "print"
.line	488	gettabup     r11    u0   k31 ; k31 = "bWriteLog"
.line	488	test         r11     0
.line	488	jmp            0  l482
.line	488	gettabup     r11    u0   k32 ; k32 = "table"
.line	488	gettable     r11   r11   k33 ; k33 = "concat"
.line	488	newtable     r12     1     0
.line	488	getupval     r13    u1
.line	488	loadk        r14   k34 ; k34 = 126
.line	488	loadk        r15   k35 ; k35 = 68
.line	488	loadk        r16   k36 ; k36 = 7
.line	488	loadk        r17   k37 ; k37 = 41
.line	488	loadk        r18   k38 ; k38 = 164
.line	488	loadk        r19   k39 ; k39 = 170
.line	488	loadk        r20   k40 ; k40 = 39
.line	488	loadk        r21   k41 ; k41 = 95
.line	488	loadk        r22   k42 ; k42 = 24
.line	488	loadk        r23   k43 ; k43 = 91
.line	488	loadk        r24   k44 ; k44 = 26
.line	488	loadk        r25   k45 ; k45 = 31
.line	488	loadk        r26   k46 ; k46 = 217
.line	488	loadk        r27   k47 ; k47 = 83
.line	488	loadk        r28   k48 ; k48 = 38
.line	488	loadk        r29   k49 ; k49 = 54
.line	488	loadk        r30   k50 ; k50 = 137
.line	488	loadk        r31   k51 ; k51 = 103
.line	488	loadk        r32   k52 ; k52 = 102
.line	488	loadk        r33   k53 ; k53 = 25
.line	488	loadk        r34   k12 ; k12 = 99
.line	488	loadk        r35   k54 ; k54 = 156
.line	488	loadk        r36   k10 ; k10 = 76
.line	488	loadk        r37   k55 ; k55 = 122
.line	488	loadk        r38   k56 ; k56 = 113
.line	488	loadk        r39   k57 ; k57 = 125
.line	488	loadk        r40   k58 ; k58 = 21
.line	488	loadk        r41   k17 ; k17 = 18
.line	488	loadk        r42   k59 ; k59 = 195
.line	488	loadk        r43   k60 ; k60 = 64
.line	488	loadk        r44   k61 ; k61 = 23
.line	488	loadk        r45   k62 ; k62 = 59
.line	488	loadk        r46   k63 ; k63 = 175
.line	488	loadk        r47   k64 ; k64 = 111
.line	488	loadk        r48   k65 ; k65 = 78
.line	488	loadk        r49   k36 ; k36 = 7
.line	488	loadk        r50   k66 ; k66 = 81
.line	488	loadk        r51   k67 ; k67 = 135
.line	488	loadk        r52   k68 ; k68 = 114
.line	488	loadk        r53   k64 ; k64 = 111
.line	488	call         r13    41     2
.line	488	getupval     r14    u1
.line	488	loadk        r15   k65 ; k65 = 78
.line	488	loadk        r16   k69 ; k69 = 66
.line	488	loadk        r17   k70 ; k70 = 13
.line	488	loadk        r18   k71 ; k71 = 37
.line	488	loadk        r19   k72 ; k72 = 133
.line	488	loadk        r20   k73 ; k73 = 138
.line	488	loadk        r21   k74 ; k74 = 30
.line	488	loadk        r22   k75 ; k75 = 88
.line	488	loadk        r23   k76 ; k76 = 49
.line	488	loadk        r24   k77 ; k77 = 75
.line	488	loadk        r25   k78 ; k78 = 10
.line	488	loadk        r26   k45 ; k45 = 31
.line	488	loadk        r27   k79 ; k79 = 150
.line	488	loadk        r28   k20 ; k20 = 107
.line	488	loadk        r29  k113 ; k113 = 58
.line	488	loadk        r30  k105 ; k105 = 48
.line	488	loadk        r31   k63 ; k63 = 175
.line	488	loadk        r32  k114 ; k114 = 108
.line	488	loadk        r33  k115 ; k115 = 119
.line	488	loadk        r34  k116 ; k116 = 27
.line	488	loadk        r35  k117 ; k117 = 84
.line	488	loadk        r36   k15 ; k15 = 211
.line	488	loadk        r37   k68 ; k68 = 114
.line	488	loadk        r38  k131 ; k131 = 127
.line	488	loadk        r39  k132 ; k132 = 40
.line	488	loadk        r40   k90 ; k90 = 93
.line	488	loadk        r41   k80 ; k80 = 28
.line	488	loadk        r42   k21 ; k21 = 8
.line	488	loadk        r43  k133 ; k133 = 213
.line	488	call         r14    30     0
.line	488	setlist      r12     0     1
.line	488	call         r11     2     2
.label	l482
.line	488	getupval     r12    u1
.line	488	loadk        r13   k64 ; k64 = 111
.line	488	loadk        r14  k119 ; k119 = 67
.line	488	loadk        r15  k120 ; k120 = 12
.line	488	loadk        r16  k121 ; k121 = 60
.line	488	loadk        r17  k122 ; k122 = 185
.line	488	loadk        r18  k123 ; k123 = 174
.line	488	loadk        r19  k124 ; k124 = 52
.line	488	loadk        r20  k125 ; k125 = 115
.line	488	loadk        r21   k97 ; k97 = 63
.line	488	loadk        r22  k126 ; k126 = 19
.line	488	call         r12    11     2
.line	488	move         r13    r1
.line	488	getupval     r14    u1
.line	488	loadk        r15   k34 ; k34 = 126
.line	488	loadk        r16   k68 ; k68 = 114
.line	488	loadk        r17    k6 ; k6 = 45
.line	488	loadk        r18  k127 ; k127 = 1
.line	488	loadk        r19   k82 ; k82 = 180
.line	488	loadk        r20  k128 ; k128 = 254
.line	488	call         r14     7     2
.line	488	move         r15    r6
.line	488	getupval     r16    u1
.line	488	loadk        r17  k125 ; k125 = 115
.line	488	loadk        r18   k47 ; k47 = 83
.line	488	loadk        r19   k58 ; k58 = 21
.line	488	loadk        r20  k134 ; k134 = 36
.line	488	loadk        r21   k88 ; k88 = 169
.line	488	loadk        r22  k135 ; k135 = 130
.line	488	loadk        r23  k136 ; k136 = 53
.line	488	loadk        r24   k98 ; k98 = 94
.line	488	loadk        r25   k11 ; k11 = 62
.line	488	loadk        r26  k137 ; k137 = 74
.line	488	loadk        r27  k117 ; k117 = 84
.line	488	call         r16    12     2
.line	488	gettabup     r17    u0  k138 ; k138 = "tostring"
.line	488	move         r18    r9
.line	488	call         r17     2     0
.line	488	call         r10     0     1
.line	488	test          r9     0
.line	488	jmp            0  l528
.line	488	gettable     r10    r0  k139 ; k139 = "RuntimeReady"
.line	488	settable     r10    r1   k29 ; k29 = true
.line	488	self         r10    r0  k140 ; k140 = "OnNodeObjectReady"
.line	488	move         r12    r1
.line	488	call         r10     3     1
.label	l528
.line	488	return        r0     1
.line	488	move          r0    r0
.line	488	move          r0    r0
.line	488	move          r0    r0
.line	488	move          r0    r0
.line	488	return        r0     1

.function	main/f25

.source	null
.linedefined	534
.lastlinedefined	556
.numparams	3
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"GetAssetManager"
.constant	k1	"AssetId"
.constant	k2	"GetAsset"
.constant	k3	"print"
.constant	k4	"bWriteLog"
.constant	k5	"table"
.constant	k6	"concat"
.constant	k7	126
.constant	k8	68
.constant	k9	7
.constant	k10	41
.constant	k11	164
.constant	k12	170
.constant	k13	39
.constant	k14	95
.constant	k15	24
.constant	k16	91
.constant	k17	26
.constant	k18	31
.constant	k19	217
.constant	k20	83
.constant	k21	38
.constant	k22	54
.constant	k23	137
.constant	k24	103
.constant	k25	102
.constant	k26	25
.constant	k27	99
.constant	k28	156
.constant	k29	76
.constant	k30	122
.constant	k31	113
.constant	k32	97
.constant	k33	58
.constant	k34	9
.constant	k35	195
.constant	k36	79
.constant	k37	23
.constant	k38	10
.constant	k39	158
.constant	k40	28
.constant	k41	142
.constant	k42	100
.constant	k43	67
.constant	k44	3
.constant	k45	178
.constant	k46	169
.constant	k47	52
.constant	k48	89
.constant	k49	47
.constant	k50	14
.constant	k51	40
.constant	k52	197
.constant	k53	163
.constant	k54	96
.constant	k55	125
.constant	k56	88
.constant	k57	78
.constant	k58	154
.constant	k59	77
.constant	k60	114
.constant	k61	45
.constant	k62	1
.constant	k63	180
.constant	k64	254
.constant	k65	124
.constant	k66	69
.constant	k67	17
.constant	k68	138
.constant	k69	53
.constant	k70	"tostring"
.constant	k71	"UMGCanvasInfo"
.constant	k72	"require"
.constant	k73	87
.constant	k74	15
.constant	k75	182
.constant	k76	48
.constant	k77	20
.constant	k78	22
.constant	k79	65
.constant	k80	13
.constant	k81	245
.constant	k82	30
.constant	k83	185
.constant	k84	111
.constant	k85	29
.constant	k86	98
.constant	k87	146
.constant	k88	82
.constant	k89	101
.constant	k90	121
.constant	k91	94
.constant	k92	56
.constant	k93	90
.constant	k94	134
.constant	k95	110
.constant	k96	19
.constant	k97	117
.constant	k98	16
.constant	k99	177
.constant	k100	183
.constant	k101	62
.constant	k102	105
.constant	k103	8
.constant	k104	6
.constant	k105	211
.constant	k106	107
.constant	k107	132
.constant	k108	104
.constant	k109	116
.constant	k110	108
.constant	k111	64
.constant	k112	84
.constant	k113	210
.constant	k114	27
.constant	k115	85
.constant	k116	33
.constant	k117	"OnInit"

.line	534	test          r1     0
.line	534	jmp            0    l5
.line	534	test          r2     1
.line	534	jmp            0    l7
.label	l5
.line	534	loadnil       r3     0
.line	534	return        r3     2
.label	l7
.line	534	gettabup      r3    u0    k0 ; k0 = "GetAssetManager"
.line	534	test          r3     0
.line	534	jmp            0   l14
.line	534	gettabup      r3    u0    k0 ; k0 = "GetAssetManager"
.line	534	call          r3     1     2
.line	534	test          r3     1
.line	534	jmp            0   l15
.label	l14
.line	534	loadnil       r3     0
.label	l15
.line	534	gettable      r4    r2    k1 ; k1 = "AssetId"
.line	534	test          r3     0
.line	534	jmp            0   l25
.line	534	test          r4     0
.line	534	jmp            0   l25
.line	534	self          r5    r3    k2 ; k2 = "GetAsset"
.line	534	move          r7    r4
.line	534	call          r5     3     2
.line	534	test          r5     1
.line	534	jmp            0   l26
.label	l25
.line	534	loadnil       r5     0
.label	l26
.line	534	test          r5     1
.line	534	jmp            0  l129
.line	534	gettabup      r6    u0    k3 ; k3 = "print"
.line	534	gettabup      r7    u0    k4 ; k4 = "bWriteLog"
.line	534	test          r7     0
.line	534	jmp            0  l104
.line	534	gettabup      r7    u0    k5 ; k5 = "table"
.line	534	gettable      r7    r7    k6 ; k6 = "concat"
.line	534	newtable      r8     1     0
.line	534	getupval      r9    u1
.line	534	loadk        r10    k7 ; k7 = 126
.line	534	loadk        r11    k8 ; k8 = 68
.line	534	loadk        r12    k9 ; k9 = 7
.line	534	loadk        r13   k10 ; k10 = 41
.line	534	loadk        r14   k11 ; k11 = 164
.line	534	loadk        r15   k12 ; k12 = 170
.line	534	loadk        r16   k13 ; k13 = 39
.line	534	loadk        r17   k14 ; k14 = 95
.line	534	loadk        r18   k15 ; k15 = 24
.line	534	loadk        r19   k16 ; k16 = 91
.line	534	loadk        r20   k17 ; k17 = 26
.line	534	loadk        r21   k18 ; k18 = 31
.line	534	loadk        r22   k19 ; k19 = 217
.line	534	loadk        r23   k20 ; k20 = 83
.line	534	loadk        r24   k21 ; k21 = 38
.line	534	loadk        r25   k22 ; k22 = 54
.line	534	loadk        r26   k23 ; k23 = 137
.line	534	loadk        r27   k24 ; k24 = 103
.line	534	loadk        r28   k25 ; k25 = 102
.line	534	loadk        r29   k26 ; k26 = 25
.line	534	loadk        r30   k27 ; k27 = 99
.line	534	loadk        r31   k28 ; k28 = 156
.line	534	loadk        r32   k29 ; k29 = 76
.line	534	loadk        r33   k30 ; k30 = 122
.line	534	loadk        r34   k31 ; k31 = 113
.line	534	loadk        r35   k32 ; k32 = 97
.line	534	loadk        r36   k33 ; k33 = 58
.line	534	loadk        r37   k34 ; k34 = 9
.line	534	loadk        r38   k35 ; k35 = 195
.line	534	loadk        r39   k36 ; k36 = 79
.line	534	loadk        r40   k37 ; k37 = 23
.line	534	loadk        r41   k38 ; k38 = 10
.line	534	loadk        r42   k39 ; k39 = 158
.line	534	loadk        r43   k27 ; k27 = 99
.line	534	loadk        r44   k31 ; k31 = 113
.line	534	loadk        r45   k40 ; k40 = 28
.line	534	loadk        r46   k14 ; k14 = 95
.line	534	loadk        r47   k41 ; k41 = 142
.line	534	loadk        r48   k42 ; k42 = 100
.line	534	loadk        r49   k20 ; k20 = 83
.line	534	call          r9    41     2
.line	534	getupval     r10    u1
.line	534	loadk        r11   k31 ; k31 = 113
.line	534	loadk        r12   k43 ; k43 = 67
.line	534	loadk        r13   k44 ; k44 = 3
.line	534	loadk        r14    k9 ; k9 = 7
.line	534	loadk        r15   k45 ; k45 = 178
.line	534	loadk        r16   k46 ; k46 = 169
.line	534	loadk        r17   k47 ; k47 = 52
.line	534	loadk        r18   k48 ; k48 = 89
.line	534	loadk        r19   k49 ; k49 = 47
.line	534	loadk        r20   k50 ; k50 = 14
.line	534	loadk        r21   k51 ; k51 = 40
.line	534	loadk        r22   k15 ; k15 = 24
.line	534	loadk        r23   k52 ; k52 = 197
.line	534	loadk        r24   k16 ; k16 = 91
.line	534	loadk        r25    k9 ; k9 = 7
.line	534	loadk        r26   k22 ; k22 = 54
.line	534	loadk        r27   k53 ; k53 = 163
.line	534	loadk        r28   k54 ; k54 = 96
.line	534	loadk        r29   k55 ; k55 = 125
.line	534	loadk        r30   k56 ; k56 = 88
.line	534	loadk        r31   k57 ; k57 = 78
.line	534	loadk        r32   k58 ; k58 = 154
.line	534	loadk        r33   k59 ; k59 = 77
.line	534	call         r10    24     0
.line	534	setlist       r8     0     1
.line	534	call          r7     2     2
.label	l104
.line	534	getupval      r8    u1
.line	534	loadk         r9    k7 ; k7 = 126
.line	534	loadk        r10   k60 ; k60 = 114
.line	534	loadk        r11   k61 ; k61 = 45
.line	534	loadk        r12   k62 ; k62 = 1
.line	534	loadk        r13   k63 ; k63 = 180
.line	534	loadk        r14   k64 ; k64 = 254
.line	534	call          r8     7     2
.line	534	move          r9    r1
.line	534	getupval     r10    u1
.line	534	loadk        r11   k65 ; k65 = 124
.line	534	loadk        r12   k66 ; k66 = 69
.line	534	loadk        r13   k67 ; k67 = 17
.line	534	loadk        r14   k61 ; k61 = 45
.line	534	loadk        r15   k11 ; k11 = 164
.line	534	loadk        r16   k68 ; k68 = 138
.line	534	loadk        r17   k69 ; k69 = 53
.line	534	loadk        r18    k9 ; k9 = 7
.line	534	call         r10     9     2
.line	534	gettabup     r11    u0   k70 ; k70 = "tostring"
.line	534	move         r12    r4
.line	534	call         r11     2     0
.line	534	call          r6     0     1
.line	534	loadnil       r6     0
.line	534	return        r6     2
.label	l129
.line	534	loadnil       r6     0
.line	534	gettable      r7    r2   k71 ; k71 = "UMGCanvasInfo"
.line	534	test          r7     0
.line	534	jmp            0  l215
.line	534	gettabup      r7    u0   k72 ; k72 = "require"
.line	534	gettabup      r8    u0    k5 ; k5 = "table"
.line	534	gettable      r8    r8    k6 ; k6 = "concat"
.line	534	newtable      r9     1     0
.line	534	getupval     r10    u1
.line	534	loadk        r11   k30 ; k30 = 122
.line	534	loadk        r12   k73 ; k73 = 87
.line	534	loadk        r13   k74 ; k74 = 15
.line	534	loadk        r14   k61 ; k61 = 45
.line	534	loadk        r15   k28 ; k28 = 156
.line	534	loadk        r16   k75 ; k75 = 182
.line	534	loadk        r17   k76 ; k76 = 48
.line	534	loadk        r18   k77 ; k77 = 20
.line	534	loadk        r19   k78 ; k78 = 22
.line	534	loadk        r20   k79 ; k79 = 65
.line	534	loadk        r21   k80 ; k80 = 13
.line	534	loadk        r22   k66 ; k66 = 69
.line	534	loadk        r23   k81 ; k81 = 245
.line	534	loadk        r24   k29 ; k29 = 76
.line	534	loadk        r25   k78 ; k78 = 22
.line	534	loadk        r26   k82 ; k82 = 30
.line	534	loadk        r27   k83 ; k83 = 185
.line	534	loadk        r28   k84 ; k84 = 111
.line	534	loadk        r29   k42 ; k42 = 100
.line	534	loadk        r30   k85 ; k85 = 29
.line	534	loadk        r31   k86 ; k86 = 98
.line	534	loadk        r32   k87 ; k87 = 146
.line	534	loadk        r33   k88 ; k88 = 82
.line	534	loadk        r34   k84 ; k84 = 111
.line	534	loadk        r35   k89 ; k89 = 101
.line	534	loadk        r36   k90 ; k90 = 121
.line	534	loadk        r37   k15 ; k15 = 24
.line	534	loadk        r38   k78 ; k78 = 22
.line	534	loadk        r39   k35 ; k35 = 195
.line	534	loadk        r40   k91 ; k91 = 94
.line	534	loadk        r41   k74 ; k74 = 15
.line	534	loadk        r42   k50 ; k50 = 14
.line	534	loadk        r43   k11 ; k11 = 164
.line	534	loadk        r44   k92 ; k92 = 56
.line	534	loadk        r45   k59 ; k59 = 77
.line	534	loadk        r46   k38 ; k38 = 10
.line	534	loadk        r47   k93 ; k93 = 90
.line	534	loadk        r48   k94 ; k94 = 134
.line	534	loadk        r49   k88 ; k88 = 82
.line	534	loadk        r50   k95 ; k95 = 110
.line	534	call         r10    41     2
.line	534	getupval     r11    u1
.line	534	loadk        r12   k96 ; k96 = 19
.line	534	loadk        r13   k97 ; k97 = 117
.line	534	loadk        r14   k98 ; k98 = 16
.line	534	loadk        r15   k61 ; k61 = 45
.line	534	loadk        r16   k99 ; k99 = 177
.line	534	loadk        r17  k100 ; k100 = 183
.line	534	loadk        r18   k92 ; k92 = 56
.line	534	loadk        r19   k29 ; k29 = 76
.line	534	loadk        r20  k101 ; k101 = 62
.line	534	loadk        r21  k102 ; k102 = 105
.line	534	loadk        r22  k103 ; k103 = 8
.line	534	loadk        r23  k104 ; k104 = 6
.line	534	loadk        r24  k105 ; k105 = 211
.line	534	loadk        r25  k106 ; k106 = 107
.line	534	loadk        r26  k101 ; k101 = 62
.line	534	loadk        r27   k92 ; k92 = 56
.line	534	loadk        r28  k107 ; k107 = 132
.line	534	loadk        r29  k108 ; k108 = 104
.line	534	loadk        r30  k109 ; k109 = 116
.line	534	loadk        r31   k37 ; k37 = 23
.line	534	loadk        r32  k110 ; k110 = 108
.line	534	loadk        r33   k94 ; k94 = 134
.line	534	loadk        r34  k111 ; k111 = 64
.line	534	loadk        r35   k66 ; k66 = 69
.line	534	loadk        r36   k10 ; k10 = 41
.line	534	loadk        r37  k112 ; k112 = 84
.line	534	loadk        r38   k40 ; k40 = 28
.line	534	loadk        r39   k15 ; k15 = 24
.line	534	loadk        r40  k113 ; k113 = 210
.line	534	call         r11    30     0
.line	534	setlist       r9     0     1
.line	534	call          r8     2     2
.line	534	call          r7     2     2
.line	534	move          r6    r7
.line	534	jmp            0  l295
.label	l215
.line	534	gettabup      r7    u0   k72 ; k72 = "require"
.line	534	gettabup      r8    u0    k5 ; k5 = "table"
.line	534	gettable      r8    r8    k6 ; k6 = "concat"
.line	534	newtable      r9     1     0
.line	534	getupval     r10    u1
.line	534	loadk        r11   k30 ; k30 = 122
.line	534	loadk        r12   k73 ; k73 = 87
.line	534	loadk        r13   k74 ; k74 = 15
.line	534	loadk        r14   k61 ; k61 = 45
.line	534	loadk        r15   k28 ; k28 = 156
.line	534	loadk        r16   k75 ; k75 = 182
.line	534	loadk        r17   k76 ; k76 = 48
.line	534	loadk        r18   k77 ; k77 = 20
.line	534	loadk        r19   k78 ; k78 = 22
.line	534	loadk        r20   k79 ; k79 = 65
.line	534	loadk        r21   k80 ; k80 = 13
.line	534	loadk        r22   k66 ; k66 = 69
.line	534	loadk        r23   k81 ; k81 = 245
.line	534	loadk        r24   k29 ; k29 = 76
.line	534	loadk        r25   k78 ; k78 = 22
.line	534	loadk        r26   k82 ; k82 = 30
.line	534	loadk        r27   k83 ; k83 = 185
.line	534	loadk        r28   k84 ; k84 = 111
.line	534	loadk        r29   k42 ; k42 = 100
.line	534	loadk        r30   k85 ; k85 = 29
.line	534	loadk        r31   k86 ; k86 = 98
.line	534	loadk        r32   k87 ; k87 = 146
.line	534	loadk        r33   k88 ; k88 = 82
.line	534	loadk        r34   k84 ; k84 = 111
.line	534	loadk        r35   k89 ; k89 = 101
.line	534	loadk        r36   k90 ; k90 = 121
.line	534	loadk        r37   k15 ; k15 = 24
.line	534	loadk        r38   k78 ; k78 = 22
.line	534	loadk        r39   k35 ; k35 = 195
.line	534	loadk        r40   k91 ; k91 = 94
.line	534	loadk        r41   k74 ; k74 = 15
.line	534	loadk        r42   k50 ; k50 = 14
.line	534	loadk        r43   k11 ; k11 = 164
.line	534	loadk        r44   k92 ; k92 = 56
.line	534	loadk        r45   k59 ; k59 = 77
.line	534	loadk        r46   k38 ; k38 = 10
.line	534	loadk        r47   k93 ; k93 = 90
.line	534	loadk        r48   k94 ; k94 = 134
.line	534	loadk        r49   k88 ; k88 = 82
.line	534	loadk        r50   k95 ; k95 = 110
.line	534	call         r10    41     2
.line	534	getupval     r11    u1
.line	534	loadk        r12   k96 ; k96 = 19
.line	534	loadk        r13   k97 ; k97 = 117
.line	534	loadk        r14   k98 ; k98 = 16
.line	534	loadk        r15   k61 ; k61 = 45
.line	534	loadk        r16   k99 ; k99 = 177
.line	534	loadk        r17  k100 ; k100 = 183
.line	534	loadk        r18   k92 ; k92 = 56
.line	534	loadk        r19   k29 ; k29 = 76
.line	534	loadk        r20  k101 ; k101 = 62
.line	534	loadk        r21  k102 ; k102 = 105
.line	534	loadk        r22  k103 ; k103 = 8
.line	534	loadk        r23  k104 ; k104 = 6
.line	534	loadk        r24  k105 ; k105 = 211
.line	534	loadk        r25  k102 ; k102 = 105
.line	534	loadk        r26   k17 ; k17 = 26
.line	534	loadk        r27  k114 ; k114 = 27
.line	534	loadk        r28   k12 ; k12 = 170
.line	534	loadk        r29   k27 ; k27 = 99
.line	534	loadk        r30   k25 ; k25 = 102
.line	534	loadk        r31   k47 ; k47 = 52
.line	534	loadk        r32  k115 ; k115 = 85
.line	534	loadk        r33   k87 ; k87 = 146
.line	534	loadk        r34   k95 ; k95 = 110
.line	534	loadk        r35  k108 ; k108 = 104
.line	534	loadk        r36  k116 ; k116 = 33
.line	534	loadk        r37   k16 ; k16 = 91
.line	534	loadk        r38   k17 ; k17 = 26
.line	534	loadk        r39   k74 ; k74 = 15
.line	534	call         r11    29     0
.line	534	setlist       r9     0     1
.line	534	call          r8     2     2
.line	534	call          r7     2     2
.line	534	move          r6    r7
.label	l295
.line	534	move          r7    r6
.line	534	call          r7     1     2
.line	534	test          r7     0
.line	534	jmp            0  l307
.line	534	gettable      r8    r7  k117 ; k117 = "OnInit"
.line	534	test          r8     0
.line	534	jmp            0  l307
.line	534	self          r8    r7  k117 ; k117 = "OnInit"
.line	534	move         r10    r0
.line	534	move         r11    r1
.line	534	move         r12    r5
.line	534	call          r8     5     1
.label	l307
.line	534	return        r7     2
.line	534	return        r0     1
.line	534	move          r0    r0
.line	534	return        r0     1

.function	main/f26

.source	null
.linedefined	558
.lastlinedefined	563
.numparams	2
.is_vararg	0
.maxstacksize	3

.constant	k0	nil
.constant	k1	"PreviewRuntimeIds"
.constant	k2	true

.line	558	eq             0    r1    k0 ; k0 = nil
.line	558	jmp            0    l5
.line	558	loadbool      r2     0     0
.line	558	return        r2     2
.label	l5
.line	558	gettable      r2    r0    k1 ; k1 = "PreviewRuntimeIds"
.line	558	eq             1    r2    k0 ; k0 = nil
.line	558	jmp            0   l12
.line	558	gettable      r2    r0    k1 ; k1 = "PreviewRuntimeIds"
.line	558	gettable      r2    r2    r1
.line	558	eq             1    r2    k2 ; k2 = true
.line	558	jmp            0   l13
.label	l12
.line	558	loadbool      r2     0     1
.label	l13
.line	558	loadbool      r2     1     0
.line	558	return        r2     2
.line	558	return        r0     1
.line	558	move          r0    r0
.line	558	return        r0     1

.function	main/f27

.source	null
.linedefined	565
.lastlinedefined	573
.numparams	3
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	1	true

.constant	k0	"GetCDOInstanceIDOfInstance"
.constant	k1	"RuntimeToCDO"
.constant	k2	"CDOToRuntimeIds"
.constant	k3	true

.line	565	self          r3    r0    k0 ; k0 = "GetCDOInstanceIDOfIn" (truncated)
.line	565	move          r5    r2
.line	565	call          r3     3     2
.line	565	test          r3     0
.line	565	jmp            0   l10
.line	565	getupval      r4    u0
.line	565	call          r4     1     2
.line	565	eq             0    r3    r4
.line	565	jmp            0   l11
.label	l10
.line	565	return        r0     1
.label	l11
.line	565	gettable      r4    r0    k1 ; k1 = "RuntimeToCDO"
.line	565	settable      r4    r1    r3
.line	565	gettable      r4    r0    k2 ; k2 = "CDOToRuntimeIds"
.line	565	gettable      r5    r0    k2 ; k2 = "CDOToRuntimeIds"
.line	565	gettable      r5    r5    r3
.line	565	test          r5     1
.line	565	jmp            0   l19
.line	565	newtable      r5     0     0
.label	l19
.line	565	settable      r4    r3    r5
.line	565	gettable      r4    r0    k2 ; k2 = "CDOToRuntimeIds"
.line	565	gettable      r4    r4    r3
.line	565	settable      r4    r1    k3 ; k3 = true
.line	565	return        r0     1
.line	565	move          r0    r0
.line	565	return        r0     1

.function	main/f28

.source	null
.linedefined	575
.lastlinedefined	591
.numparams	2
.is_vararg	0
.maxstacksize	11

.upvalue	"_ENV"	0	false

.constant	k0	"UIEventIndexKeys"
.constant	k1	1
.constant	k2	"Table"
.constant	k3	"Key"
.constant	k4	nil
.constant	k5	"next"

.line	575	gettable      r2    r0    k0 ; k0 = "UIEventIndexKeys"
.line	575	gettable      r2    r2    r1
.line	575	test          r2     1
.line	575	jmp            0    l6
.line	575	return        r0     1
.label	l6
.line	575	loadk         r3    k1 ; k1 = 1
.line	575	len           r4    r2
.line	575	loadk         r5    k1 ; k1 = 1
.line	575	move          r0    r0
.line	575	gettable      r7    r2    r6
.line	575	gettable      r8    r7    k2 ; k2 = "Table"
.line	575	gettable      r9    r7    k3 ; k3 = "Key"
.line	575	gettable      r8    r8    r9
.line	575	test          r8     0
.line	575	jmp            0   l25
.line	575	settable      r8    r1    k4 ; k4 = nil
.line	575	gettabup      r9    u0    k5 ; k5 = "next"
.line	575	move         r10    r8
.line	575	call          r9     2     2
.line	575	eq             0    r9    k4 ; k4 = nil
.line	575	jmp            0   l25
.line	575	gettable      r9    r7    k2 ; k2 = "Table"
.line	575	gettable     r10    r7    k3 ; k3 = "Key"
.line	575	settable      r9   r10    k4 ; k4 = nil
.label	l25
.line	575	move          r0    r0
.line	575	gettable      r3    r0    k0 ; k0 = "UIEventIndexKeys"
.line	575	settable      r3    r1    k4 ; k4 = nil
.line	575	return        r0     1
.line	575	move          r0    r0
.line	575	return        r0     1

.function	main/f29

.source	null
.linedefined	593
.lastlinedefined	677
.numparams	3
.is_vararg	0
.maxstacksize	38

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"HasAuthority"
.constant	k1	"UnregisterEventIndex"
.constant	k2	"CustomUIBase"
.constant	k3	"ShowOnEvent"
.constant	k4	"HideOnEvent"
.constant	k5	"UIEventIndexKeys"
.constant	k6	"import"
.constant	k7	126
.constant	k8	68
.constant	k9	7
.constant	k10	41
.constant	k11	164
.constant	k12	170
.constant	k13	39
.constant	k14	95
.constant	k15	22
.constant	k16	65
.constant	k17	13
.constant	k18	14
.constant	k19	244
.constant	k20	82
.constant	k21	6
.constant	k22	26
.constant	k23	189
.constant	k24	116
.constant	k25	123
.constant	k26	84
.constant	k27	191
.constant	k28	72
.constant	k29	104
.constant	k30	57
.constant	k31	11
.constant	k32	2
.constant	k33	0
.constant	k34	nil

.line	593	self          r3    r0    k0 ; k0 = "HasAuthority"
.line	593	call          r3     2     2
.line	593	test          r3     1
.line	593	jmp            0    l6
.line	593	return        r0     1
.label	l6
.line	593	self          r3    r0    k1 ; k1 = "UnregisterEventIndex"
.line	593	move          r5    r1
.line	593	call          r3     3     1
.line	593	test          r2     0
.line	593	jmp            0   l14
.line	593	gettable      r3    r2    k2 ; k2 = "CustomUIBase"
.line	593	test          r3     1
.line	593	jmp            0   l15
.label	l14
.line	593	return        r0     1
.label	l15
.line	593	closure       r3    f0
.line	593	move          r4    r3
.line	593	gettable      r5    r2    k2 ; k2 = "CustomUIBase"
.line	593	gettable      r5    r5    k3 ; k3 = "ShowOnEvent"
.line	593	call          r4     2     2
.line	593	move          r5    r3
.line	593	gettable      r6    r2    k2 ; k2 = "CustomUIBase"
.line	593	gettable      r6    r6    k4 ; k4 = "HideOnEvent"
.line	593	call          r5     2     2
.line	593	gettable      r6    r0    k5 ; k5 = "UIEventIndexKeys"
.line	593	gettable      r6    r6    r1
.line	593	test          r6     1
.line	593	jmp            0   l32
.line	593	newtable      r7     0     0
.line	593	move          r6    r7
.line	593	gettable      r7    r0    k5 ; k5 = "UIEventIndexKeys"
.line	593	settable      r7    r1    r6
.label	l32
.line	593	closure       r7    f1
.line	593	gettabup      r8    u0    k6 ; k6 = "import"
.line	593	getupval      r9    u1
.line	593	loadk        r10    k7 ; k7 = 126
.line	593	loadk        r11    k8 ; k8 = 68
.line	593	loadk        r12    k9 ; k9 = 7
.line	593	loadk        r13   k10 ; k10 = 41
.line	593	loadk        r14   k11 ; k11 = 164
.line	593	loadk        r15   k12 ; k12 = 170
.line	593	loadk        r16   k13 ; k13 = 39
.line	593	loadk        r17   k14 ; k14 = 95
.line	593	loadk        r18   k15 ; k15 = 22
.line	593	loadk        r19   k16 ; k16 = 65
.line	593	loadk        r20   k17 ; k17 = 13
.line	593	loadk        r21   k18 ; k18 = 14
.line	593	loadk        r22   k19 ; k19 = 244
.line	593	loadk        r23   k20 ; k20 = 82
.line	593	loadk        r24   k21 ; k21 = 6
.line	593	loadk        r25   k22 ; k22 = 26
.line	593	loadk        r26   k23 ; k23 = 189
.line	593	loadk        r27   k24 ; k24 = 116
.line	593	loadk        r28   k25 ; k25 = 123
.line	593	loadk        r29   k15 ; k15 = 22
.line	593	loadk        r30   k26 ; k26 = 84
.line	593	loadk        r31   k27 ; k27 = 191
.line	593	loadk        r32   k28 ; k28 = 72
.line	593	loadk        r33   k29 ; k29 = 104
.line	593	loadk        r34   k30 ; k30 = 57
.line	593	loadk        r35   k14 ; k14 = 95
.line	593	loadk        r36   k31 ; k31 = 11
.line	593	loadk        r37   k32 ; k32 = 2
.line	593	call          r9    29     2
.line	593	call          r8     2     2
.line	593	closure       r9    f2
.line	593	move         r10    r7
.line	593	move         r11    r4
.line	593	loadbool     r12     1     0
.line	593	call         r10     3     1
.line	593	move         r10    r7
.line	593	move         r11    r5
.line	593	loadbool     r12     0     0
.line	593	call         r10     3     1
.line	593	move         r10    r9
.line	593	move         r11    r4
.line	593	loadbool     r12     1     0
.line	593	call         r10     3     1
.line	593	move         r10    r9
.line	593	move         r11    r5
.line	593	loadbool     r12     0     0
.line	593	call         r10     3     1
.line	593	len          r10    r6
.line	593	eq             0   r10   k33 ; k33 = 0
.line	593	jmp            0   l87
.line	593	gettable     r10    r0    k5 ; k5 = "UIEventIndexKeys"
.line	593	settable     r10    r1   k34 ; k34 = nil
.label	l87
.line	593	return        r0     1
.line	593	move          r0    r0
.line	593	return        r0     1

.function	main/f29/f0

.source	null
.linedefined	601
.lastlinedefined	606
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	"overrides"

.line	601	test          r0     0
.line	601	jmp            0    l8
.line	601	gettable      r1    r0    k0 ; k0 = "overrides"
.line	601	test          r1     0
.line	601	jmp            0    l8
.line	601	gettable      r1    r0    k0 ; k0 = "overrides"
.line	601	return        r1     2
.label	l8
.line	601	return        r0     2
.line	601	return        r0     1
.line	601	move          r0    r0
.line	601	move          r0    r0
.line	601	return        r0     1

.function	main/f29/f1

.source	null
.linedefined	614
.lastlinedefined	640
.numparams	2
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	0	true
.upvalue	"U3"	1	true
.upvalue	"U4"	6	true

.constant	k0	"InstanceID"
.constant	k1	nil
.constant	k2	"EventName"
.constant	k3	"tostring"
.constant	k4	61
.constant	k5	"BroadcastEventIndex"
.constant	k6	1
.constant	k7	"Table"
.constant	k8	"Key"
.constant	k9	"bShow"
.constant	k10	true
.constant	k11	"ShowBranchKey"
.constant	k12	"EventBranchKey"
.constant	k13	0
.constant	k14	"bHide"
.constant	k15	"HideBranchKey"

.line	614	test          r0     0
.line	614	jmp            0    l9
.line	614	gettable      r2    r0    k0 ; k0 = "InstanceID"
.line	614	eq             1    r2    k1 ; k1 = nil
.line	614	jmp            0    l9
.line	614	gettable      r2    r0    k2 ; k2 = "EventName"
.line	614	eq             0    r2    k1 ; k1 = nil
.line	614	jmp            0   l10
.label	l9
.line	614	return        r0     1
.label	l10
.line	614	gettabup      r2    u0    k3 ; k3 = "tostring"
.line	614	gettable      r3    r0    k0 ; k0 = "InstanceID"
.line	614	call          r2     2     2
.line	614	getupval      r3    u1
.line	614	loadk         r4    k4 ; k4 = 61
.line	614	call          r3     2     2
.line	614	gettabup      r4    u0    k3 ; k3 = "tostring"
.line	614	gettable      r5    r0    k2 ; k2 = "EventName"
.line	614	call          r4     2     2
.line	614	concat        r2    r2    r4
.line	614	gettabup      r3    u2    k5 ; k5 = "BroadcastEventIndex"
.line	614	gettable      r3    r3    r2
.line	614	test          r3     1
.line	614	jmp            0   l28
.line	614	newtable      r4     0     0
.line	614	move          r3    r4
.line	614	gettabup      r4    u2    k5 ; k5 = "BroadcastEventIndex"
.line	614	settable      r4    r2    r3
.label	l28
.line	614	getupval      r4    u3
.line	614	gettable      r4    r3    r4
.line	614	test          r4     1
.line	614	jmp            0   l44
.line	614	newtable      r5     0     0
.line	614	move          r4    r5
.line	614	getupval      r5    u3
.line	614	settable      r3    r5    r4
.line	614	getupval      r5    u4
.line	614	len           r5    r5
.line	614	add           r5    r5    k6 ; k6 = 1
.line	614	newtable      r6     0     2
.line	614	gettabup      r7    u2    k5 ; k5 = "BroadcastEventIndex"
.line	614	settable      r6    k7    r7 ; k7 = "Table"
.line	614	settable      r6    k8    r2 ; k8 = "Key"
.line	614	settabup      u4    r5    r6
.label	l44
.line	614	test          r1     0
.line	614	jmp            0   l53
.line	614	settable      r4    k9   k10 ; k10 = true
.line	614	gettable      r5    r0   k12 ; k12 = "EventBranchKey"
.line	614	test          r5     1
.line	614	jmp            0   l51
.line	614	loadk         r5   k13 ; k13 = 0
.label	l51
.line	614	settable      r4   k11    r5 ; k11 = "ShowBranchKey"
.line	614	jmp            0   l59
.label	l53
.line	614	settable      r4   k14   k10 ; k10 = true
.line	614	gettable      r5    r0   k12 ; k12 = "EventBranchKey"
.line	614	test          r5     1
.line	614	jmp            0   l58
.line	614	loadk         r5   k13 ; k13 = 0
.label	l58
.line	614	settable      r4   k15    r5 ; k15 = "HideBranchKey"
.label	l59
.line	614	return        r0     1
.line	614	move          r0    r0
.line	614	move          r0    r0
.line	614	return        r0     1

.function	main/f29/f2

.source	null
.linedefined	642
.lastlinedefined	669
.numparams	2
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	8	true
.upvalue	"U3"	0	true
.upvalue	"U4"	1	true
.upvalue	"U5"	6	true

.constant	k0	"type"
.constant	k1	"SignalName"
.constant	k2	78
.constant	k3	66
.constant	k4	16
.constant	k5	33
.constant	k6	190
.constant	k7	164
.constant	k8	"GetCustomEventHashString"
.constant	k9	"CustomEventIndex"
.constant	k10	1
.constant	k11	"Table"
.constant	k12	"Key"
.constant	k13	"bShow"
.constant	k14	true
.constant	k15	"bHide"

.line	642	test          r0     0
.line	642	jmp            0   l21
.line	642	gettabup      r2    u0    k0 ; k0 = "type"
.line	642	gettable      r3    r0    k1 ; k1 = "SignalName"
.line	642	call          r2     2     2
.line	642	getupval      r3    u1
.line	642	loadk         r4    k2 ; k2 = 78
.line	642	loadk         r5    k3 ; k3 = 66
.line	642	loadk         r6    k4 ; k4 = 16
.line	642	loadk         r7    k5 ; k5 = 33
.line	642	loadk         r8    k6 ; k6 = 190
.line	642	loadk         r9    k7 ; k7 = 164
.line	642	call          r3     7     2
.line	642	eq             0    r2    r3
.line	642	jmp            0   l21
.line	642	gettable      r2    r0    k1 ; k1 = "SignalName"
.line	642	getupval      r3    u1
.line	642	call          r3     1     2
.line	642	eq             0    r2    r3
.line	642	jmp            0   l22
.label	l21
.line	642	return        r0     1
.label	l22
.line	642	gettabup      r2    u2    k8 ; k8 = "GetCustomEventHashSt" (truncated)
.line	642	gettable      r3    r0    k1 ; k1 = "SignalName"
.line	642	loadbool      r4     0     0
.line	642	call          r2     3     2
.line	642	test          r2     1
.line	642	jmp            0   l29
.line	642	return        r0     1
.label	l29
.line	642	gettabup      r3    u3    k9 ; k9 = "CustomEventIndex"
.line	642	gettable      r3    r3    r2
.line	642	test          r3     1
.line	642	jmp            0   l37
.line	642	newtable      r4     0     0
.line	642	move          r3    r4
.line	642	gettabup      r4    u3    k9 ; k9 = "CustomEventIndex"
.line	642	settable      r4    r2    r3
.label	l37
.line	642	getupval      r4    u4
.line	642	gettable      r4    r3    r4
.line	642	test          r4     1
.line	642	jmp            0   l53
.line	642	newtable      r5     0     0
.line	642	move          r4    r5
.line	642	getupval      r5    u4
.line	642	settable      r3    r5    r4
.line	642	getupval      r5    u5
.line	642	len           r5    r5
.line	642	add           r5    r5   k10 ; k10 = 1
.line	642	newtable      r6     0     2
.line	642	gettabup      r7    u3    k9 ; k9 = "CustomEventIndex"
.line	642	settable      r6   k11    r7 ; k11 = "Table"
.line	642	settable      r6   k12    r2 ; k12 = "Key"
.line	642	settabup      u5    r5    r6
.label	l53
.line	642	test          r1     0
.line	642	jmp            0   l57
.line	642	settable      r4   k13   k14 ; k14 = true
.line	642	jmp            0   l58
.label	l57
.line	642	settable      r4   k15   k14 ; k14 = true
.label	l58
.line	642	return        r0     1
.line	642	move          r0    r0
.line	642	return        r0     1

.function	main/f30

.source	null
.linedefined	679
.lastlinedefined	688
.numparams	3
.is_vararg	0
.maxstacksize	33

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"CustomUIBase"
.constant	k1	"CustomUITalentNode"
.constant	k2	"SubsystemMgr"
.constant	k3	"Get"
.constant	k4	126
.constant	k5	68
.constant	k6	7
.constant	k7	41
.constant	k8	164
.constant	k9	170
.constant	k10	39
.constant	k11	95
.constant	k12	22
.constant	k13	65
.constant	k14	13
.constant	k15	14
.constant	k16	226
.constant	k17	31
.constant	k18	26
.constant	k19	163
.constant	k20	114
.constant	k21	66
.constant	k22	160
.constant	k23	88
.constant	k24	121
.constant	k25	63
.constant	k26	91
.constant	k27	20
.constant	k28	"RecordTalentInstanceFromRuntime"

.line	679	test          r2     0
.line	679	jmp            0    l9
.line	679	gettable      r3    r2    k0 ; k0 = "CustomUIBase"
.line	679	test          r3     0
.line	679	jmp            0    l9
.line	679	gettable      r3    r2    k1 ; k1 = "CustomUITalentNode"
.line	679	test          r3     1
.line	679	jmp            0   l10
.label	l9
.line	679	return        r0     1
.label	l10
.line	679	gettabup      r3    u0    k2 ; k2 = "SubsystemMgr"
.line	679	self          r3    r3    k3 ; k3 = "Get"
.line	679	getupval      r5    u1
.line	679	loadk         r6    k4 ; k4 = 126
.line	679	loadk         r7    k5 ; k5 = 68
.line	679	loadk         r8    k6 ; k6 = 7
.line	679	loadk         r9    k7 ; k7 = 41
.line	679	loadk        r10    k8 ; k8 = 164
.line	679	loadk        r11    k9 ; k9 = 170
.line	679	loadk        r12   k10 ; k10 = 39
.line	679	loadk        r13   k11 ; k11 = 95
.line	679	loadk        r14   k12 ; k12 = 22
.line	679	loadk        r15   k13 ; k13 = 65
.line	679	loadk        r16   k14 ; k14 = 13
.line	679	loadk        r17   k15 ; k15 = 14
.line	679	loadk        r18   k16 ; k16 = 226
.line	679	loadk        r19   k11 ; k11 = 95
.line	679	loadk        r20   k17 ; k17 = 31
.line	679	loadk        r21   k18 ; k18 = 26
.line	679	loadk        r22   k19 ; k19 = 163
.line	679	loadk        r23   k20 ; k20 = 114
.line	679	loadk        r24   k13 ; k13 = 65
.line	679	loadk        r25   k14 ; k14 = 13
.line	679	loadk        r26   k21 ; k21 = 66
.line	679	loadk        r27   k22 ; k22 = 160
.line	679	loadk        r28   k23 ; k23 = 88
.line	679	loadk        r29   k24 ; k24 = 121
.line	679	loadk        r30   k25 ; k25 = 63
.line	679	loadk        r31   k26 ; k26 = 91
.line	679	loadk        r32   k27 ; k27 = 20
.line	679	call          r5    28     2
.line	679	call          r3     3     2
.line	679	test          r3     0
.line	679	jmp            0   l47
.line	679	gettable      r4    r3   k28 ; k28 = "RecordTalentInstance" (truncated)
.line	679	test          r4     1
.line	679	jmp            0   l48
.label	l47
.line	679	return        r0     1
.label	l48
.line	679	self          r4    r3   k28 ; k28 = "RecordTalentInstance" (truncated)
.line	679	move          r6    r1
.line	679	move          r7    r2
.line	679	call          r4     4     1
.line	679	return        r0     1
.line	679	move          r0    r0
.line	679	return        r0     1

.function	main/f31

.source	null
.linedefined	690
.lastlinedefined	698
.numparams	4
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	false

.constant	k0	nil
.constant	k1	"tostring"
.constant	k2	"AppliedFieldDeltas"

.line	690	eq             0    r3    k0 ; k0 = nil
.line	690	jmp            0    l4
.line	690	return        r0     1
.label	l4
.line	690	gettabup      r4    u0    k1 ; k1 = "tostring"
.line	690	move          r5    r1
.line	690	call          r4     2     2
.line	690	move          r1    r4
.line	690	gettable      r4    r0    k2 ; k2 = "AppliedFieldDeltas"
.line	690	test          r4     1
.line	690	jmp            0   l12
.line	690	newtable      r4     0     0
.label	l12
.line	690	settable      r0    k2    r4 ; k2 = "AppliedFieldDeltas"
.line	690	gettable      r4    r0    k2 ; k2 = "AppliedFieldDeltas"
.line	690	gettable      r5    r0    k2 ; k2 = "AppliedFieldDeltas"
.line	690	gettable      r5    r5    r1
.line	690	test          r5     1
.line	690	jmp            0   l19
.line	690	newtable      r5     0     0
.label	l19
.line	690	settable      r4    r1    r5
.line	690	gettable      r4    r0    k2 ; k2 = "AppliedFieldDeltas"
.line	690	gettable      r4    r4    r1
.line	690	settable      r4    r2    r3
.line	690	return        r0     1
.line	690	move          r0    r0
.line	690	move          r0    r0
.line	690	move          r0    r0
.line	690	return        r0     1

.function	main/f32

.source	null
.linedefined	700
.lastlinedefined	722
.numparams	2
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"tostring"
.constant	k2	"AppliedFieldDeltas"
.constant	k3	"next"
.constant	k4	"GetOwner"
.constant	k5	"slua"
.constant	k6	"isValid"
.constant	k7	"CreativeModeCustomUIFeature"
.constant	k8	"type"
.constant	k9	"_ApplyFieldValue"
.constant	k10	91
.constant	k11	67
.constant	k12	12
.constant	k13	43
.constant	k14	164
.constant	k15	170
.constant	k16	62
.constant	k17	84
.constant	k18	0
.constant	k19	"pairs"
.constant	k20	1
.constant	k21	"print"
.constant	k22	"bWriteLog"
.constant	k23	"string"
.constant	k24	"format"
.constant	k25	"table"
.constant	k26	"concat"
.constant	k27	126
.constant	k28	68
.constant	k29	7
.constant	k30	41
.constant	k31	39
.constant	k32	95
.constant	k33	24
.constant	k34	26
.constant	k35	31
.constant	k36	217
.constant	k37	83
.constant	k38	38
.constant	k39	54
.constant	k40	137
.constant	k41	103
.constant	k42	102
.constant	k43	25
.constant	k44	99
.constant	k45	156
.constant	k46	76
.constant	k47	122
.constant	k48	113
.constant	k49	108
.constant	k50	28
.constant	k51	11
.constant	k52	202
.constant	k53	79
.constant	k54	46
.constant	k55	173
.constant	k56	110
.constant	k57	85
.constant	k58	135
.constant	k59	119
.constant	k60	115
.constant	k61	88
.constant	k62	90
.constant	k63	6
.constant	k64	181
.constant	k65	175
.constant	k66	37
.constant	k67	40
.constant	k68	14
.constant	k69	32
.constant	k70	15
.constant	k71	139
.constant	k72	27
.constant	k73	111
.constant	k74	20
.constant	k75	176
.constant	k76	78
.constant	k77	127
.constant	k78	74
.constant	k79	94
.constant	k80	194

.line	700	gettabup      r2    u0    k0 ; k0 = "Client"
.line	700	test          r2     1
.line	700	jmp            0    l5
.line	700	return        r0     1
.label	l5
.line	700	gettabup      r2    u0    k1 ; k1 = "tostring"
.line	700	move          r3    r1
.line	700	call          r2     2     2
.line	700	move          r1    r2
.line	700	gettable      r2    r0    k2 ; k2 = "AppliedFieldDeltas"
.line	700	test          r2     0
.line	700	jmp            0   l14
.line	700	gettable      r2    r0    k2 ; k2 = "AppliedFieldDeltas"
.line	700	gettable      r2    r2    r1
.label	l14
.line	700	test          r2     0
.line	700	jmp            0   l21
.line	700	gettabup      r3    u0    k3 ; k3 = "next"
.line	700	move          r4    r2
.line	700	call          r3     2     2
.line	700	test          r3     1
.line	700	jmp            0   l22
.label	l21
.line	700	return        r0     1
.label	l22
.line	700	self          r3    r0    k4 ; k4 = "GetOwner"
.line	700	call          r3     2     2
.line	700	gettabup      r4    u0    k5 ; k5 = "slua"
.line	700	gettable      r4    r4    k6 ; k6 = "isValid"
.line	700	move          r5    r3
.line	700	call          r4     2     2
.line	700	test          r4     0
.line	700	jmp            0   l33
.line	700	gettable      r4    r3    k7 ; k7 = "CreativeModeCustomUI" (truncated)
.line	700	test          r4     1
.line	700	jmp            0   l34
.label	l33
.line	700	loadnil       r4     0
.label	l34
.line	700	test          r4     0
.line	700	jmp            0   l51
.line	700	gettabup      r5    u0    k8 ; k8 = "type"
.line	700	gettable      r6    r4    k9 ; k9 = "_ApplyFieldValue"
.line	700	call          r5     2     2
.line	700	getupval      r6    u1
.line	700	loadk         r7   k10 ; k10 = 91
.line	700	loadk         r8   k11 ; k11 = 67
.line	700	loadk         r9   k12 ; k12 = 12
.line	700	loadk        r10   k13 ; k13 = 43
.line	700	loadk        r11   k14 ; k14 = 164
.line	700	loadk        r12   k15 ; k15 = 170
.line	700	loadk        r13   k16 ; k16 = 62
.line	700	loadk        r14   k17 ; k17 = 84
.line	700	call          r6     9     2
.line	700	eq             1    r5    r6
.line	700	jmp            0   l52
.label	l51
.line	700	return        r0     1
.label	l52
.line	700	loadk         r5   k18 ; k18 = 0
.line	700	gettabup      r6    u0   k19 ; k19 = "pairs"
.line	700	move          r7    r2
.line	700	call          r6     2     4
.line	700	jmp            0   l58
.line	700	add           r5    r5   k20 ; k20 = 1
.label	l58
.line	700	move          r0    r0
.line	700	move          r0    r0
.line	700	gettabup      r6    u0   k21 ; k21 = "print"
.line	700	gettabup      r7    u0   k22 ; k22 = "bWriteLog"
.line	700	test          r7     0
.line	700	jmp            0  l149
.line	700	gettabup      r7    u0   k23 ; k23 = "string"
.line	700	gettable      r7    r7   k24 ; k24 = "format"
.line	700	gettabup      r8    u0   k25 ; k25 = "table"
.line	700	gettable      r8    r8   k26 ; k26 = "concat"
.line	700	newtable      r9     1     0
.line	700	getupval     r10    u1
.line	700	loadk        r11   k27 ; k27 = 126
.line	700	loadk        r12   k28 ; k28 = 68
.line	700	loadk        r13   k29 ; k29 = 7
.line	700	loadk        r14   k30 ; k30 = 41
.line	700	loadk        r15   k14 ; k14 = 164
.line	700	loadk        r16   k15 ; k15 = 170
.line	700	loadk        r17   k31 ; k31 = 39
.line	700	loadk        r18   k32 ; k32 = 95
.line	700	loadk        r19   k33 ; k33 = 24
.line	700	loadk        r20   k10 ; k10 = 91
.line	700	loadk        r21   k34 ; k34 = 26
.line	700	loadk        r22   k35 ; k35 = 31
.line	700	loadk        r23   k36 ; k36 = 217
.line	700	loadk        r24   k37 ; k37 = 83
.line	700	loadk        r25   k38 ; k38 = 38
.line	700	loadk        r26   k39 ; k39 = 54
.line	700	loadk        r27   k40 ; k40 = 137
.line	700	loadk        r28   k41 ; k41 = 103
.line	700	loadk        r29   k42 ; k42 = 102
.line	700	loadk        r30   k43 ; k43 = 25
.line	700	loadk        r31   k44 ; k44 = 99
.line	700	loadk        r32   k45 ; k45 = 156
.line	700	loadk        r33   k46 ; k46 = 76
.line	700	loadk        r34   k47 ; k47 = 122
.line	700	loadk        r35   k48 ; k48 = 113
.line	700	loadk        r36   k49 ; k49 = 108
.line	700	loadk        r37   k50 ; k50 = 28
.line	700	loadk        r38   k51 ; k51 = 11
.line	700	loadk        r39   k52 ; k52 = 202
.line	700	loadk        r40   k53 ; k53 = 79
.line	700	loadk        r41   k34 ; k34 = 26
.line	700	loadk        r42   k54 ; k54 = 46
.line	700	loadk        r43   k55 ; k55 = 173
.line	700	loadk        r44   k42 ; k42 = 102
.line	700	loadk        r45   k56 ; k56 = 110
.line	700	loadk        r46   k20 ; k20 = 1
.line	700	loadk        r47   k57 ; k57 = 85
.line	700	loadk        r48   k58 ; k58 = 135
.line	700	loadk        r49   k59 ; k59 = 119
.line	700	loadk        r50   k60 ; k60 = 115
.line	700	call         r10    41     2
.line	700	getupval     r11    u1
.line	700	loadk        r12   k61 ; k61 = 88
.line	700	loadk        r13   k62 ; k62 = 90
.line	700	loadk        r14   k63 ; k63 = 6
.line	700	loadk        r15   k12 ; k12 = 12
.line	700	loadk        r16   k64 ; k64 = 181
.line	700	loadk        r17   k65 ; k65 = 175
.line	700	loadk        r18   k66 ; k66 = 37
.line	700	loadk        r19   k10 ; k10 = 91
.line	700	loadk        r20   k67 ; k67 = 40
.line	700	loadk        r21   k68 ; k68 = 14
.line	700	loadk        r22   k69 ; k69 = 32
.line	700	loadk        r23   k70 ; k70 = 15
.line	700	loadk        r24   k71 ; k71 = 139
.line	700	loadk        r25   k72 ; k72 = 27
.line	700	loadk        r26   k18 ; k18 = 0
.line	700	loadk        r27   k32 ; k32 = 95
.line	700	loadk        r28   k71 ; k71 = 139
.line	700	loadk        r29   k73 ; k73 = 111
.line	700	loadk        r30   k59 ; k59 = 119
.line	700	loadk        r31   k74 ; k74 = 20
.line	700	loadk        r32   k28 ; k28 = 68
.line	700	loadk        r33   k75 ; k75 = 176
.line	700	loadk        r34   k76 ; k76 = 78
.line	700	loadk        r35   k77 ; k77 = 127
.line	700	loadk        r36   k66 ; k66 = 37
.line	700	loadk        r37   k78 ; k78 = 74
.line	700	loadk        r38   k28 ; k28 = 68
.line	700	loadk        r39   k79 ; k79 = 94
.line	700	loadk        r40   k80 ; k80 = 194
.line	700	call         r11    30     0
.line	700	setlist       r9     0     1
.line	700	call          r8     2     2
.line	700	gettabup      r9    u0    k1 ; k1 = "tostring"
.line	700	move         r10    r1
.line	700	call          r9     2     2
.line	700	move         r10    r5
.line	700	call          r7     4     2
.label	l149
.line	700	call          r6     2     1
.line	700	gettabup      r6    u0   k19 ; k19 = "pairs"
.line	700	move          r7    r2
.line	700	call          r6     2     4
.line	700	jmp            0  l159
.line	700	self         r11    r4    k9 ; k9 = "_ApplyFieldValue"
.line	700	move         r13    r1
.line	700	move         r14    r9
.line	700	move         r15   r10
.line	700	call         r11     5     1
.label	l159
.line	700	move          r0    r0
.line	700	move          r0    r0
.line	700	return        r0     1
.line	700	move          r0    r0
.line	700	move          r0    r0
.line	700	move          r0    r0
.line	700	move          r0    r0
.line	700	return        r0     1

.function	main/f33

.source	null
.linedefined	724
.lastlinedefined	748
.numparams	3
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	0	false
.upvalue	"U1"	2	true

.constant	k0	"tostring"
.constant	k1	"InstanceChangeCache"
.constant	k2	nil
.constant	k3	"xpcall"
.constant	k4	"UnPackToInstance"
.constant	k5	"UGCPbErrorMessageHandler"
.constant	k6	"CustomUIData"
.constant	k7	"RegisterInstanceIndex"
.constant	k8	"RegisterEventIndex"
.constant	k9	"NotifyTalentNodeLanded"
.constant	k10	"Client"
.constant	k11	"ClientTryLoadCustomUIObject"
.constant	k12	"ReplayAppliedFieldDeltas"
.constant	k13	"OnNodeDataReady"

.line	724	gettabup      r3    u0    k0 ; k0 = "tostring"
.line	724	move          r4    r1
.line	724	call          r3     2     2
.line	724	move          r1    r3
.line	724	loadbool      r3     0     0
.line	724	loadnil       r4     0
.line	724	gettable      r5    r0    k1 ; k1 = "InstanceChangeCache"
.line	724	gettable      r5    r5    r1
.line	724	eq             1    r5    k2 ; k2 = nil
.line	724	jmp            0   l17
.line	724	gettable      r5    r0    k1 ; k1 = "InstanceChangeCache"
.line	724	gettable      r4    r5    r1
.line	724	loadbool      r3     1     0
.line	724	gettable      r5    r0    k1 ; k1 = "InstanceChangeCache"
.line	724	settable      r5    r1    k2 ; k2 = nil
.line	724	jmp            0   l25
.label	l17
.line	724	gettabup      r5    u0    k3 ; k3 = "xpcall"
.line	724	gettabup      r6    u1    k4 ; k4 = "UnPackToInstance"
.line	724	gettabup      r7    u1    k5 ; k5 = "UGCPbErrorMessageHan" (truncated)
.line	724	move          r8    r2
.line	724	move          r9    r1
.line	724	call          r5     5     3
.line	724	move          r4    r6
.line	724	move          r3    r5
.label	l25
.line	724	test          r3     1
.line	724	jmp            0   l31
.line	724	gettable      r5    r0    k6 ; k6 = "CustomUIData"
.line	724	newtable      r6     0     0
.line	724	settable      r5    r1    r6
.line	724	jmp            0   l59
.label	l31
.line	724	gettable      r5    r0    k6 ; k6 = "CustomUIData"
.line	724	settable      r5    r1    r4
.line	724	self          r5    r0    k7 ; k7 = "RegisterInstanceInde" (truncated)
.line	724	move          r7    r1
.line	724	move          r8    r4
.line	724	call          r5     4     1
.line	724	self          r5    r0    k8 ; k8 = "RegisterEventIndex"
.line	724	move          r7    r1
.line	724	move          r8    r4
.line	724	call          r5     4     1
.line	724	self          r5    r0    k9 ; k9 = "NotifyTalentNodeLand" (truncated)
.line	724	move          r7    r1
.line	724	move          r8    r4
.line	724	call          r5     4     1
.line	724	gettabup      r5    u0   k10 ; k10 = "Client"
.line	724	test          r5     0
.line	724	jmp            0   l56
.line	724	self          r5    r0   k11 ; k11 = "ClientTryLoadCustomU" (truncated)
.line	724	move          r7    r1
.line	724	move          r8    r4
.line	724	call          r5     4     1
.line	724	self          r5    r0   k12 ; k12 = "ReplayAppliedFieldDe" (truncated)
.line	724	move          r7    r1
.line	724	call          r5     3     1
.line	724	jmp            0   l59
.label	l56
.line	724	self          r5    r0   k13 ; k13 = "OnNodeDataReady"
.line	724	move          r7    r1
.line	724	call          r5     3     1
.label	l59
.line	724	return        r0     1
.line	724	move          r0    r0
.line	724	move          r0    r0
.line	724	move          r0    r0
.line	724	move          r0    r0
.line	724	return        r0     1

.function	main/f34

.source	null
.linedefined	750
.lastlinedefined	790
.numparams	2
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false

.constant	k0	"tostring"
.constant	k1	"CustomUIData"
.constant	k2	"RuntimeToCDO"
.constant	k3	"Client"
.constant	k4	"CustomUIObject"
.constant	k5	"RemoveRuntimeInstanceData"
.constant	k6	nil
.constant	k7	"CDOToRuntimeIds"
.constant	k8	"next"
.constant	k9	"RuntimeReady"
.constant	k10	"PendingLoadRuntimeIds"
.constant	k11	"PreviewRuntimeIds"
.constant	k12	"UnregisterEventIndex"
.constant	k13	"UMGCanvasInfo"
.constant	k14	"FireCanvasReadyCallbacks"
.constant	k15	"CanvasReadyState"
.constant	k16	"CanvasBuilt"
.constant	k17	"AppliedFieldDeltas"

.line	750	gettabup      r2    u0    k0 ; k0 = "tostring"
.line	750	move          r3    r1
.line	750	call          r2     2     2
.line	750	move          r1    r2
.line	750	gettable      r2    r0    k1 ; k1 = "CustomUIData"
.line	750	gettable      r2    r2    r1
.line	750	gettable      r3    r0    k2 ; k2 = "RuntimeToCDO"
.line	750	gettable      r3    r3    r1
.line	750	gettabup      r4    u0    k3 ; k3 = "Client"
.line	750	test          r4     0
.line	750	jmp            0   l24
.line	750	test          r3     0
.line	750	jmp            0   l24
.line	750	gettable      r4    r0    k4 ; k4 = "CustomUIObject"
.line	750	gettable      r4    r4    r3
.line	750	test          r4     0
.line	750	jmp            0   l24
.line	750	gettable      r5    r4    k5 ; k5 = "RemoveRuntimeInstanc" (truncated)
.line	750	test          r5     0
.line	750	jmp            0   l24
.line	750	self          r5    r4    k5 ; k5 = "RemoveRuntimeInstanc" (truncated)
.line	750	move          r7    r1
.line	750	call          r5     3     1
.label	l24
.line	750	gettable      r4    r0    k2 ; k2 = "RuntimeToCDO"
.line	750	settable      r4    r1    k6 ; k6 = nil
.line	750	test          r3     0
.line	750	jmp            0   l43
.line	750	gettable      r4    r0    k7 ; k7 = "CDOToRuntimeIds"
.line	750	gettable      r4    r4    r3
.line	750	test          r4     0
.line	750	jmp            0   l43
.line	750	gettable      r4    r0    k7 ; k7 = "CDOToRuntimeIds"
.line	750	gettable      r4    r4    r3
.line	750	settable      r4    r1    k6 ; k6 = nil
.line	750	gettabup      r4    u0    k8 ; k8 = "next"
.line	750	gettable      r5    r0    k7 ; k7 = "CDOToRuntimeIds"
.line	750	gettable      r5    r5    r3
.line	750	call          r4     2     2
.line	750	eq             0    r4    k6 ; k6 = nil
.line	750	jmp            0   l43
.line	750	gettable      r4    r0    k7 ; k7 = "CDOToRuntimeIds"
.line	750	settable      r4    r3    k6 ; k6 = nil
.label	l43
.line	750	gettable      r4    r0    k9 ; k9 = "RuntimeReady"
.line	750	test          r4     0
.line	750	jmp            0   l48
.line	750	gettable      r4    r0    k9 ; k9 = "RuntimeReady"
.line	750	settable      r4    r1    k6 ; k6 = nil
.label	l48
.line	750	gettable      r4    r0   k10 ; k10 = "PendingLoadRuntimeId" (truncated)
.line	750	test          r4     0
.line	750	jmp            0   l53
.line	750	gettable      r4    r0   k10 ; k10 = "PendingLoadRuntimeId" (truncated)
.line	750	settable      r4    r1    k6 ; k6 = nil
.label	l53
.line	750	gettable      r4    r0   k11 ; k11 = "PreviewRuntimeIds"
.line	750	test          r4     0
.line	750	jmp            0   l58
.line	750	gettable      r4    r0   k11 ; k11 = "PreviewRuntimeIds"
.line	750	settable      r4    r1    k6 ; k6 = nil
.label	l58
.line	750	self          r4    r0   k12 ; k12 = "UnregisterEventIndex"
.line	750	move          r6    r1
.line	750	call          r4     3     1
.line	750	test          r2     0
.line	750	jmp            0   l80
.line	750	gettable      r4    r2   k13 ; k13 = "UMGCanvasInfo"
.line	750	test          r4     0
.line	750	jmp            0   l80
.line	750	self          r4    r0   k14 ; k14 = "FireCanvasReadyCallb" (truncated)
.line	750	move          r6    r1
.line	750	loadnil       r7     0
.line	750	call          r4     4     1
.line	750	gettable      r4    r0   k15 ; k15 = "CanvasReadyState"
.line	750	test          r4     0
.line	750	jmp            0   l75
.line	750	gettable      r4    r0   k15 ; k15 = "CanvasReadyState"
.line	750	settable      r4    r1    k6 ; k6 = nil
.label	l75
.line	750	gettable      r4    r0   k16 ; k16 = "CanvasBuilt"
.line	750	test          r4     0
.line	750	jmp            0   l80
.line	750	gettable      r4    r0   k16 ; k16 = "CanvasBuilt"
.line	750	settable      r4    r1    k6 ; k6 = nil
.label	l80
.line	750	gettable      r4    r0   k17 ; k17 = "AppliedFieldDeltas"
.line	750	test          r4     0
.line	750	jmp            0   l85
.line	750	gettable      r4    r0   k17 ; k17 = "AppliedFieldDeltas"
.line	750	settable      r4    r1    k6 ; k6 = nil
.label	l85
.line	750	gettable      r4    r0    k1 ; k1 = "CustomUIData"
.line	750	settable      r4    r1    k6 ; k6 = nil
.line	750	return        r0     1
.line	750	move          r0    r0
.line	750	return        r0     1

.function	main/f35

.source	null
.linedefined	792
.lastlinedefined	817
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"CustomUIData"
.constant	k1	"UMGCanvasInfo"
.constant	k2	"print"
.constant	k3	"bWriteLog"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	126
.constant	k7	68
.constant	k8	7
.constant	k9	41
.constant	k10	164
.constant	k11	170
.constant	k12	39
.constant	k13	95
.constant	k14	24
.constant	k15	91
.constant	k16	26
.constant	k17	31
.constant	k18	217
.constant	k19	83
.constant	k20	38
.constant	k21	54
.constant	k22	137
.constant	k23	103
.constant	k24	102
.constant	k25	25
.constant	k26	99
.constant	k27	156
.constant	k28	76
.constant	k29	122
.constant	k30	113
.constant	k31	28
.constant	k32	8
.constant	k33	210
.constant	k34	92
.constant	k35	12
.constant	k36	22
.constant	k37	143
.constant	k38	108
.constant	k39	89
.constant	k40	142
.constant	k41	84
.constant	k42	69
.constant	k43	190
.constant	k44	160
.constant	k45	52
.constant	k46	47
.constant	k47	79
.constant	k48	27
.constant	k49	211
.constant	k50	74
.constant	k51	124
.constant	k52	23
.constant	k53	64
.constant	k54	42
.constant	k55	57
.constant	k56	75
.constant	k57	15
.constant	k58	207
.constant	k59	67
.constant	k60	6
.constant	k61	119
.constant	k62	30
.constant	k63	81
.constant	k64	144
.constant	k65	"AllWidgets"
.constant	k66	"overrides"
.constant	k67	1
.constant	k68	"RemoveCustomUI"

.line	792	test          r1     1
.line	792	jmp            0    l4
.line	792	return        r0     1
.label	l4
.line	792	gettable      r2    r0    k0 ; k0 = "CustomUIData"
.line	792	gettable      r2    r2    r1
.line	792	test          r2     0
.line	792	jmp            0   l11
.line	792	gettable      r3    r2    k1 ; k1 = "UMGCanvasInfo"
.line	792	test          r3     1
.line	792	jmp            0  l105
.label	l11
.line	792	gettabup      r3    u0    k2 ; k2 = "print"
.line	792	gettabup      r4    u0    k3 ; k3 = "bWriteLog"
.line	792	test          r4     0
.line	792	jmp            0  l102
.line	792	gettabup      r4    u0    k4 ; k4 = "table"
.line	792	gettable      r4    r4    k5 ; k5 = "concat"
.line	792	newtable      r5     1     0
.line	792	getupval      r6    u1
.line	792	loadk         r7    k6 ; k6 = 126
.line	792	loadk         r8    k7 ; k7 = 68
.line	792	loadk         r9    k8 ; k8 = 7
.line	792	loadk        r10    k9 ; k9 = 41
.line	792	loadk        r11   k10 ; k10 = 164
.line	792	loadk        r12   k11 ; k11 = 170
.line	792	loadk        r13   k12 ; k12 = 39
.line	792	loadk        r14   k13 ; k13 = 95
.line	792	loadk        r15   k14 ; k14 = 24
.line	792	loadk        r16   k15 ; k15 = 91
.line	792	loadk        r17   k16 ; k16 = 26
.line	792	loadk        r18   k17 ; k17 = 31
.line	792	loadk        r19   k18 ; k18 = 217
.line	792	loadk        r20   k19 ; k19 = 83
.line	792	loadk        r21   k20 ; k20 = 38
.line	792	loadk        r22   k21 ; k21 = 54
.line	792	loadk        r23   k22 ; k22 = 137
.line	792	loadk        r24   k23 ; k23 = 103
.line	792	loadk        r25   k24 ; k24 = 102
.line	792	loadk        r26   k25 ; k25 = 25
.line	792	loadk        r27   k26 ; k26 = 99
.line	792	loadk        r28   k27 ; k27 = 156
.line	792	loadk        r29   k28 ; k28 = 76
.line	792	loadk        r30   k29 ; k29 = 122
.line	792	loadk        r31   k30 ; k30 = 113
.line	792	loadk        r32   k29 ; k29 = 122
.line	792	loadk        r33   k31 ; k31 = 28
.line	792	loadk        r34   k32 ; k32 = 8
.line	792	loadk        r35   k33 ; k33 = 210
.line	792	loadk        r36   k34 ; k34 = 92
.line	792	loadk        r37   k35 ; k35 = 12
.line	792	loadk        r38   k36 ; k36 = 22
.line	792	loadk        r39   k37 ; k37 = 143
.line	792	loadk        r40   k26 ; k26 = 99
.line	792	loadk        r41   k38 ; k38 = 108
.line	792	loadk        r42   k31 ; k31 = 28
.line	792	loadk        r43   k39 ; k39 = 89
.line	792	loadk        r44   k40 ; k40 = 142
.line	792	loadk        r45   k41 ; k41 = 84
.line	792	loadk        r46   k19 ; k19 = 83
.line	792	call          r6    41     2
.line	792	getupval      r7    u1
.line	792	loadk         r8   k19 ; k19 = 83
.line	792	loadk         r9   k42 ; k42 = 69
.line	792	loadk        r10   k36 ; k36 = 22
.line	792	loadk        r11    k9 ; k9 = 41
.line	792	loadk        r12   k43 ; k43 = 190
.line	792	loadk        r13   k44 ; k44 = 160
.line	792	loadk        r14   k45 ; k45 = 52
.line	792	loadk        r15   k16 ; k16 = 26
.line	792	loadk        r16   k46 ; k46 = 47
.line	792	loadk        r17   k47 ; k47 = 79
.line	792	loadk        r18   k48 ; k48 = 27
.line	792	loadk        r19   k35 ; k35 = 12
.line	792	loadk        r20   k49 ; k49 = 211
.line	792	loadk        r21   k50 ; k50 = 74
.line	792	loadk        r22   k19 ; k19 = 83
.line	792	loadk        r23   k36 ; k36 = 22
.line	792	loadk        r24   k43 ; k43 = 190
.line	792	loadk        r25   k20 ; k20 = 38
.line	792	loadk        r26   k51 ; k51 = 124
.line	792	loadk        r27   k52 ; k52 = 23
.line	792	loadk        r28   k41 ; k41 = 84
.line	792	loadk        r29   k49 ; k49 = 211
.line	792	loadk        r30   k53 ; k53 = 64
.line	792	loadk        r31   k54 ; k54 = 42
.line	792	loadk        r32   k55 ; k55 = 57
.line	792	loadk        r33   k56 ; k56 = 75
.line	792	loadk        r34   k52 ; k52 = 23
.line	792	loadk        r35   k57 ; k57 = 15
.line	792	loadk        r36   k58 ; k58 = 207
.line	792	loadk        r37   k59 ; k59 = 67
.line	792	loadk        r38   k60 ; k60 = 6
.line	792	loadk        r39   k47 ; k47 = 79
.line	792	loadk        r40   k43 ; k43 = 190
.line	792	loadk        r41   k61 ; k61 = 119
.line	792	loadk        r42   k38 ; k38 = 108
.line	792	loadk        r43   k62 ; k62 = 30
.line	792	loadk        r44   k63 ; k63 = 81
.line	792	loadk        r45   k64 ; k64 = 144
.line	792	call          r7    39     0
.line	792	setlist       r5     0     1
.line	792	call          r4     2     2
.label	l102
.line	792	move          r5    r1
.line	792	call          r3     3     1
.line	792	return        r0     1
.label	l105
.line	792	newtable      r3     1     0
.line	792	move          r4    r1
.line	792	setlist       r3     1     1
.line	792	gettable      r4    r2    k1 ; k1 = "UMGCanvasInfo"
.line	792	gettable      r4    r4   k65 ; k65 = "AllWidgets"
.line	792	test          r4     0
.line	792	jmp            0  l116
.line	792	gettable      r5    r4   k66 ; k66 = "overrides"
.line	792	test          r5     0
.line	792	jmp            0  l116
.line	792	gettable      r4    r4   k66 ; k66 = "overrides"
.label	l116
.line	792	test          r4     0
.line	792	jmp            0  l129
.line	792	loadk         r5   k67 ; k67 = 1
.line	792	len           r6    r4
.line	792	loadk         r7   k67 ; k67 = 1
.line	792	move          r0    r0
.line	792	gettable      r9    r4    r8
.line	792	test          r9     0
.line	792	jmp            0  l128
.line	792	len          r10    r3
.line	792	add          r10   r10   k67 ; k67 = 1
.line	792	settable      r3   r10    r9
.label	l128
.line	792	move          r0    r0
.label	l129
.line	792	loadk         r5   k67 ; k67 = 1
.line	792	len           r6    r3
.line	792	loadk         r7   k67 ; k67 = 1
.line	792	move          r0    r0
.line	792	self          r9    r0   k68 ; k68 = "RemoveCustomUI"
.line	792	gettable     r11    r3    r8
.line	792	call          r9     3     1
.line	792	move          r0    r0
.line	792	return        r0     1
.line	792	move          r0    r0
.line	792	move          r0    r0
.line	792	move          r0    r0
.line	792	move          r0    r0
.line	792	return        r0     1

.function	main/f36

.source	null
.linedefined	819
.lastlinedefined	842
.numparams	3
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	0	false
.upvalue	"U1"	2	true

.constant	k0	"tostring"
.constant	k1	"InstanceChangeCache"
.constant	k2	nil
.constant	k3	"xpcall"
.constant	k4	"UnPackToInstance"
.constant	k5	"UGCPbErrorMessageHandler"
.constant	k6	"CustomUIData"
.constant	k7	"UnregisterEventIndex"
.constant	k8	"RegisterInstanceIndex"
.constant	k9	"RegisterEventIndex"
.constant	k10	"NotifyTalentNodeLanded"
.constant	k11	"ClientTryLoadCustomUIObject"
.constant	k12	"Client"
.constant	k13	"_bResumeResponseReplacing"
.constant	k14	"ReplayAppliedFieldDeltas"

.line	819	gettabup      r3    u0    k0 ; k0 = "tostring"
.line	819	move          r4    r1
.line	819	call          r3     2     2
.line	819	move          r1    r3
.line	819	loadbool      r3     0     0
.line	819	loadnil       r4     0
.line	819	gettable      r5    r0    k1 ; k1 = "InstanceChangeCache"
.line	819	gettable      r5    r5    r1
.line	819	eq             1    r5    k2 ; k2 = nil
.line	819	jmp            0   l17
.line	819	gettable      r5    r0    k1 ; k1 = "InstanceChangeCache"
.line	819	gettable      r4    r5    r1
.line	819	loadbool      r3     1     0
.line	819	gettable      r5    r0    k1 ; k1 = "InstanceChangeCache"
.line	819	settable      r5    r1    k2 ; k2 = nil
.line	819	jmp            0   l25
.label	l17
.line	819	gettabup      r5    u0    k3 ; k3 = "xpcall"
.line	819	gettabup      r6    u1    k4 ; k4 = "UnPackToInstance"
.line	819	gettabup      r7    u1    k5 ; k5 = "UGCPbErrorMessageHan" (truncated)
.line	819	move          r8    r2
.line	819	move          r9    r1
.line	819	call          r5     5     3
.line	819	move          r4    r6
.line	819	move          r3    r5
.label	l25
.line	819	test          r3     1
.line	819	jmp            0   l34
.line	819	gettable      r5    r0    k6 ; k6 = "CustomUIData"
.line	819	newtable      r6     0     0
.line	819	settable      r5    r1    r6
.line	819	self          r5    r0    k7 ; k7 = "UnregisterEventIndex"
.line	819	move          r7    r1
.line	819	call          r5     3     1
.line	819	jmp            0   l61
.label	l34
.line	819	gettable      r5    r0    k6 ; k6 = "CustomUIData"
.line	819	settable      r5    r1    r4
.line	819	self          r5    r0    k8 ; k8 = "RegisterInstanceInde" (truncated)
.line	819	move          r7    r1
.line	819	move          r8    r4
.line	819	call          r5     4     1
.line	819	self          r5    r0    k9 ; k9 = "RegisterEventIndex"
.line	819	move          r7    r1
.line	819	move          r8    r4
.line	819	call          r5     4     1
.line	819	self          r5    r0   k10 ; k10 = "NotifyTalentNodeLand" (truncated)
.line	819	move          r7    r1
.line	819	move          r8    r4
.line	819	call          r5     4     1
.line	819	self          r5    r0   k11 ; k11 = "ClientTryLoadCustomU" (truncated)
.line	819	move          r7    r1
.line	819	move          r8    r4
.line	819	call          r5     4     1
.line	819	gettabup      r5    u0   k12 ; k12 = "Client"
.line	819	test          r5     0
.line	819	jmp            0   l61
.line	819	gettable      r5    r0   k13 ; k13 = "_bResumeResponseRepl" (truncated)
.line	819	test          r5     0
.line	819	jmp            0   l61
.line	819	self          r5    r0   k14 ; k14 = "ReplayAppliedFieldDe" (truncated)
.line	819	move          r7    r1
.line	819	call          r5     3     1
.label	l61
.line	819	return        r0     1
.line	819	move          r0    r0
.line	819	return        r0     1

.function	main/f37

.source	null
.linedefined	844
.lastlinedefined	867
.numparams	5
.is_vararg	0
.maxstacksize	58

.upvalue	"_ENV"	1	true
.upvalue	"U1"	0	false
.upvalue	"U2"	2	true

.constant	k0	"CDORuntimeCount"
.constant	k1	0
.constant	k2	1
.constant	k3	"CloneCDOToRuntime"
.constant	k4	"UMGCanvasInfo"
.constant	k5	"Tag"
.constant	k6	"pairs"
.constant	k7	"InstanceChangeCache"
.constant	k8	"InstancePackToPbBuffer"
.constant	k9	"print"
.constant	k10	"bWriteLog"
.constant	k11	"table"
.constant	k12	"concat"
.constant	k13	126
.constant	k14	68
.constant	k15	7
.constant	k16	41
.constant	k17	164
.constant	k18	170
.constant	k19	39
.constant	k20	95
.constant	k21	24
.constant	k22	91
.constant	k23	26
.constant	k24	31
.constant	k25	217
.constant	k26	83
.constant	k27	38
.constant	k28	54
.constant	k29	137
.constant	k30	103
.constant	k31	102
.constant	k32	25
.constant	k33	99
.constant	k34	156
.constant	k35	76
.constant	k36	122
.constant	k37	113
.constant	k38	125
.constant	k39	11
.constant	k40	30
.constant	k41	199
.constant	k42	90
.constant	k43	6
.constant	k44	61
.constant	k45	168
.constant	k46	120
.constant	k47	118
.constant	k48	93
.constant	k49	134
.constant	k50	116
.constant	k51	78
.constant	k52	66
.constant	k53	3
.constant	k54	179
.constant	k55	166
.constant	k56	123
.constant	k57	63
.constant	k58	74
.constant	k59	42
.constant	k60	197
.constant	k61	28
.constant	k62	18
.constant	k63	152
.constant	k64	79
.constant	k65	"AddCustomUI"
.constant	k66	"CustomUIVFX"
.constant	k67	"AutoHide"
.constant	k68	true
.constant	k69	"CustomUIBase"
.constant	k70	"Visible"
.constant	k71	false
.constant	k72	"_HandleVFXAutoHide"

.line	844	gettable      r5    r0    k0 ; k0 = "CDORuntimeCount"
.line	844	gettable      r5    r5    r1
.line	844	test          r5     1
.line	844	jmp            0    l6
.line	844	loadk         r5    k1 ; k1 = 0
.label	l6
.line	844	add           r5    r5    k2 ; k2 = 1
.line	844	self          r6    r0    k3 ; k3 = "CloneCDOToRuntime"
.line	844	move          r8    r1
.line	844	move          r9    r2
.line	844	move         r10    r5
.line	844	move         r11    r3
.line	844	call          r6     6     3
.line	844	test          r6     0
.line	844	jmp            0   l17
.line	844	test          r7     1
.line	844	jmp            0   l19
.label	l17
.line	844	loadnil       r8     0
.line	844	return        r8     2
.label	l19
.line	844	gettable      r8    r0    k0 ; k0 = "CDORuntimeCount"
.line	844	settable      r8    r1    r5
.line	844	test          r4     0
.line	844	jmp            0   l36
.line	844	getupval      r8    u0
.line	844	call          r8     1     2
.line	844	eq             1    r4    r8
.line	844	jmp            0   l36
.line	844	gettable      r8    r6    r1
.line	844	gettable      r8    r7    r8
.line	844	test          r8     0
.line	844	jmp            0   l36
.line	844	gettable      r9    r8    k4 ; k4 = "UMGCanvasInfo"
.line	844	test          r9     0
.line	844	jmp            0   l36
.line	844	gettable      r9    r8    k4 ; k4 = "UMGCanvasInfo"
.line	844	settable      r9    k5    r4 ; k5 = "Tag"
.label	l36
.line	844	gettabup      r8    u1    k6 ; k6 = "pairs"
.line	844	move          r9    r7
.line	844	call          r8     2     4
.line	844	jmp            0  l142
.line	844	gettable     r13    r0    k7 ; k7 = "InstanceChangeCache"
.line	844	settable     r13   r11   r12
.line	844	gettabup     r13    u2    k8 ; k8 = "InstancePackToPbBuff" (truncated)
.line	844	move         r14   r12
.line	844	loadbool     r15     1     0
.line	844	call         r13     3     2
.line	844	gettabup     r14    u1    k9 ; k9 = "print"
.line	844	gettabup     r15    u1   k10 ; k10 = "bWriteLog"
.line	844	test         r15     0
.line	844	jmp            0  l117
.line	844	gettabup     r15    u1   k11 ; k11 = "table"
.line	844	gettable     r15   r15   k12 ; k12 = "concat"
.line	844	newtable     r16     1     0
.line	844	getupval     r17    u0
.line	844	loadk        r18   k13 ; k13 = 126
.line	844	loadk        r19   k14 ; k14 = 68
.line	844	loadk        r20   k15 ; k15 = 7
.line	844	loadk        r21   k16 ; k16 = 41
.line	844	loadk        r22   k17 ; k17 = 164
.line	844	loadk        r23   k18 ; k18 = 170
.line	844	loadk        r24   k19 ; k19 = 39
.line	844	loadk        r25   k20 ; k20 = 95
.line	844	loadk        r26   k21 ; k21 = 24
.line	844	loadk        r27   k22 ; k22 = 91
.line	844	loadk        r28   k23 ; k23 = 26
.line	844	loadk        r29   k24 ; k24 = 31
.line	844	loadk        r30   k25 ; k25 = 217
.line	844	loadk        r31   k26 ; k26 = 83
.line	844	loadk        r32   k27 ; k27 = 38
.line	844	loadk        r33   k28 ; k28 = 54
.line	844	loadk        r34   k29 ; k29 = 137
.line	844	loadk        r35   k30 ; k30 = 103
.line	844	loadk        r36   k31 ; k31 = 102
.line	844	loadk        r37   k32 ; k32 = 25
.line	844	loadk        r38   k33 ; k33 = 99
.line	844	loadk        r39   k34 ; k34 = 156
.line	844	loadk        r40   k35 ; k35 = 76
.line	844	loadk        r41   k36 ; k36 = 122
.line	844	loadk        r42   k37 ; k37 = 113
.line	844	loadk        r43   k38 ; k38 = 125
.line	844	loadk        r44   k39 ; k39 = 11
.line	844	loadk        r45   k40 ; k40 = 30
.line	844	loadk        r46   k41 ; k41 = 199
.line	844	loadk        r47   k42 ; k42 = 90
.line	844	loadk        r48   k43 ; k43 = 6
.line	844	loadk        r49   k44 ; k44 = 61
.line	844	loadk        r50   k45 ; k45 = 168
.line	844	loadk        r51   k46 ; k46 = 120
.line	844	loadk        r52   k47 ; k47 = 118
.line	844	loadk        r53    k2 ; k2 = 1
.line	844	loadk        r54   k48 ; k48 = 93
.line	844	loadk        r55   k49 ; k49 = 134
.line	844	loadk        r56   k46 ; k46 = 120
.line	844	loadk        r57   k50 ; k50 = 116
.line	844	call         r17    41     2
.line	844	getupval     r18    u0
.line	844	loadk        r19   k51 ; k51 = 78
.line	844	loadk        r20   k52 ; k52 = 66
.line	844	loadk        r21   k53 ; k53 = 3
.line	844	loadk        r22   k27 ; k27 = 38
.line	844	loadk        r23   k54 ; k54 = 179
.line	844	loadk        r24   k55 ; k55 = 166
.line	844	loadk        r25   k37 ; k37 = 113
.line	844	loadk        r26   k56 ; k56 = 123
.line	844	loadk        r27   k57 ; k57 = 63
.line	844	loadk        r28   k58 ; k58 = 74
.line	844	loadk        r29   k59 ; k59 = 42
.line	844	loadk        r30   k40 ; k40 = 30
.line	844	loadk        r31   k60 ; k60 = 197
.line	844	loadk        r32   k58 ; k58 = 74
.line	844	loadk        r33   k61 ; k61 = 28
.line	844	loadk        r34   k62 ; k62 = 18
.line	844	loadk        r35   k63 ; k63 = 152
.line	844	loadk        r36   k64 ; k64 = 79
.line	844	call         r18    19     0
.line	844	setlist      r16     0     1
.line	844	call         r15     2     2
.label	l117
.line	844	move         r16   r11
.line	844	call         r14     3     1
.line	844	self         r14    r0   k65 ; k65 = "AddCustomUI"
.line	844	move         r16   r11
.line	844	move         r17   r13
.line	844	call         r14     4     1
.line	844	gettable     r14   r12   k66 ; k66 = "CustomUIVFX"
.line	844	test         r14     0
.line	844	jmp            0  l142
.line	844	gettable     r14   r12   k66 ; k66 = "CustomUIVFX"
.line	844	gettable     r14   r14   k67 ; k67 = "AutoHide"
.line	844	eq             0   r14   k68 ; k68 = true
.line	844	jmp            0  l142
.line	844	gettable     r14   r12   k69 ; k69 = "CustomUIBase"
.line	844	test         r14     0
.line	844	jmp            0  l142
.line	844	gettable     r14   r12   k69 ; k69 = "CustomUIBase"
.line	844	gettable     r14   r14   k70 ; k70 = "Visible"
.line	844	eq             1   r14   k71 ; k71 = false
.line	844	jmp            0  l142
.line	844	self         r14    r0   k72 ; k72 = "_HandleVFXAutoHide"
.line	844	move         r16   r11
.line	844	move         r17   r12
.line	844	loadbool     r18     1     0
.line	844	call         r14     5     1
.label	l142
.line	844	move          r0    r0
.line	844	move          r0    r0
.line	844	gettable      r8    r6    r1
.line	844	return        r8     2
.line	844	return        r0     1
.line	844	move          r0    r0
.line	844	return        r0     1

.function	main/f38

.source	null
.linedefined	869
.lastlinedefined	884
.numparams	1
.is_vararg	0
.maxstacksize	42

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	126
.constant	k3	68
.constant	k4	7
.constant	k5	41
.constant	k6	164
.constant	k7	170
.constant	k8	39
.constant	k9	95
.constant	k10	24
.constant	k11	91
.constant	k12	26
.constant	k13	31
.constant	k14	217
.constant	k15	83
.constant	k16	38
.constant	k17	54
.constant	k18	137
.constant	k19	103
.constant	k20	102
.constant	k21	25
.constant	k22	99
.constant	k23	156
.constant	k24	76
.constant	k25	122
.constant	k26	113
.constant	k27	125
.constant	k28	22
.constant	k29	11
.constant	k30	223
.constant	k31	123
.constant	k32	42
.constant	k33	179
.constant	k34	101
.constant	k35	118
.constant	k36	9
.constant	k37	94
.constant	k38	128
.constant	k39	84
.constant	k40	"GetLoadManager"
.constant	k41	"bNewCustomUI"
.constant	k42	"GetUIBinTableFromMap"
.constant	k43	"pairs"
.constant	k44	"UMGCanvasInfo"
.constant	k45	"CustomUIBase"
.constant	k46	nil
.constant	k47	"CreateRuntimeInstance"

.line	869	gettabup      r1    u0    k0 ; k0 = "print"
.line	869	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	869	test          r2     0
.line	869	jmp            0   l46
.line	869	getupval      r2    u1
.line	869	loadk         r3    k2 ; k2 = 126
.line	869	loadk         r4    k3 ; k3 = 68
.line	869	loadk         r5    k4 ; k4 = 7
.line	869	loadk         r6    k5 ; k5 = 41
.line	869	loadk         r7    k6 ; k6 = 164
.line	869	loadk         r8    k7 ; k7 = 170
.line	869	loadk         r9    k8 ; k8 = 39
.line	869	loadk        r10    k9 ; k9 = 95
.line	869	loadk        r11   k10 ; k10 = 24
.line	869	loadk        r12   k11 ; k11 = 91
.line	869	loadk        r13   k12 ; k12 = 26
.line	869	loadk        r14   k13 ; k13 = 31
.line	869	loadk        r15   k14 ; k14 = 217
.line	869	loadk        r16   k15 ; k15 = 83
.line	869	loadk        r17   k16 ; k16 = 38
.line	869	loadk        r18   k17 ; k17 = 54
.line	869	loadk        r19   k18 ; k18 = 137
.line	869	loadk        r20   k19 ; k19 = 103
.line	869	loadk        r21   k20 ; k20 = 102
.line	869	loadk        r22   k21 ; k21 = 25
.line	869	loadk        r23   k22 ; k22 = 99
.line	869	loadk        r24   k23 ; k23 = 156
.line	869	loadk        r25   k24 ; k24 = 76
.line	869	loadk        r26   k25 ; k25 = 122
.line	869	loadk        r27   k26 ; k26 = 113
.line	869	loadk        r28   k27 ; k27 = 125
.line	869	loadk        r29   k28 ; k28 = 22
.line	869	loadk        r30   k29 ; k29 = 11
.line	869	loadk        r31   k30 ; k30 = 223
.line	869	loadk        r32   k31 ; k31 = 123
.line	869	loadk        r33   k32 ; k32 = 42
.line	869	loadk        r34   k16 ; k16 = 38
.line	869	loadk        r35   k33 ; k33 = 179
.line	869	loadk        r36   k34 ; k34 = 101
.line	869	loadk        r37   k35 ; k35 = 118
.line	869	loadk        r38   k36 ; k36 = 9
.line	869	loadk        r39   k37 ; k37 = 94
.line	869	loadk        r40   k38 ; k38 = 128
.line	869	loadk        r41   k39 ; k39 = 84
.line	869	call          r2    40     2
.label	l46
.line	869	call          r1     2     1
.line	869	gettabup      r1    u0   k40 ; k40 = "GetLoadManager"
.line	869	call          r1     1     2
.line	869	test          r1     0
.line	869	jmp            0   l54
.line	869	gettable      r2    r1   k41 ; k41 = "bNewCustomUI"
.line	869	test          r2     1
.line	869	jmp            0   l55
.label	l54
.line	869	return        r0     1
.label	l55
.line	869	self          r2    r0   k42 ; k42 = "GetUIBinTableFromMap"
.line	869	call          r2     2     2
.line	869	test          r2     1
.line	869	jmp            0   l60
.line	869	return        r0     1
.label	l60
.line	869	gettabup      r3    u0   k43 ; k43 = "pairs"
.line	869	move          r4    r2
.line	869	call          r3     2     4
.line	869	jmp            0   l76
.line	869	test          r7     0
.line	869	jmp            0   l76
.line	869	gettable      r8    r7   k44 ; k44 = "UMGCanvasInfo"
.line	869	test          r8     0
.line	869	jmp            0   l76
.line	869	gettable      r8    r7   k45 ; k45 = "CustomUIBase"
.line	869	eq             0    r8   k46 ; k46 = nil
.line	869	jmp            0   l76
.line	869	self          r8    r0   k47 ; k47 = "CreateRuntimeInstanc" (truncated)
.line	869	move         r10    r6
.line	869	move         r11    r2
.line	869	call          r8     4     1
.label	l76
.line	869	move          r0    r0
.line	869	move          r0    r0
.line	869	return        r0     1
.line	869	move          r0    r0
.line	869	move          r0    r0
.line	869	move          r0    r0
.line	869	return        r0     1

.function	main/f39

.source	null
.linedefined	886
.lastlinedefined	907
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	126
.constant	k5	68
.constant	k6	7
.constant	k7	41
.constant	k8	164
.constant	k9	170
.constant	k10	39
.constant	k11	95
.constant	k12	24
.constant	k13	91
.constant	k14	26
.constant	k15	31
.constant	k16	217
.constant	k17	83
.constant	k18	38
.constant	k19	54
.constant	k20	137
.constant	k21	103
.constant	k22	102
.constant	k23	25
.constant	k24	99
.constant	k25	156
.constant	k26	76
.constant	k27	122
.constant	k28	113
.constant	k29	108
.constant	k30	28
.constant	k31	8
.constant	k32	195
.constant	k33	90
.constant	k34	148
.constant	k35	120
.constant	k36	81
.constant	k37	141
.constant	k38	82
.constant	k39	127
.constant	k40	123
.constant	k41	89
.constant	k42	16
.constant	k43	13
.constant	k44	180
.constant	k45	37
.constant	k46	85
.constant	k47	"CustomUIData"
.constant	k48	"CanvasReadyState"
.constant	k49	"CanvasBuilt"
.constant	k50	"InstanceChangeCache"
.constant	k51	"CDORuntimeCount"
.constant	k52	"CDOToRuntimeIds"
.constant	k53	"RuntimeToCDO"
.constant	k54	"RuntimeReady"
.constant	k55	"PendingLoadRuntimeIds"
.constant	k56	"AppliedFieldDeltas"
.constant	k57	"BroadcastEventIndex"
.constant	k58	"CustomEventIndex"
.constant	k59	"UIEventIndexKeys"
.constant	k60	"_VFXAutoHideTimers"
.constant	k61	nil
.constant	k62	"pairs"
.constant	k63	"RemoveGameTimer"

.line	886	gettabup      r1    u0    k0 ; k0 = "print"
.line	886	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	886	test          r2     0
.line	886	jmp            0   l63
.line	886	gettabup      r2    u0    k2 ; k2 = "table"
.line	886	gettable      r2    r2    k3 ; k3 = "concat"
.line	886	newtable      r3     1     0
.line	886	getupval      r4    u1
.line	886	loadk         r5    k4 ; k4 = 126
.line	886	loadk         r6    k5 ; k5 = 68
.line	886	loadk         r7    k6 ; k6 = 7
.line	886	loadk         r8    k7 ; k7 = 41
.line	886	loadk         r9    k8 ; k8 = 164
.line	886	loadk        r10    k9 ; k9 = 170
.line	886	loadk        r11   k10 ; k10 = 39
.line	886	loadk        r12   k11 ; k11 = 95
.line	886	loadk        r13   k12 ; k12 = 24
.line	886	loadk        r14   k13 ; k13 = 91
.line	886	loadk        r15   k14 ; k14 = 26
.line	886	loadk        r16   k15 ; k15 = 31
.line	886	loadk        r17   k16 ; k16 = 217
.line	886	loadk        r18   k17 ; k17 = 83
.line	886	loadk        r19   k18 ; k18 = 38
.line	886	loadk        r20   k19 ; k19 = 54
.line	886	loadk        r21   k20 ; k20 = 137
.line	886	loadk        r22   k21 ; k21 = 103
.line	886	loadk        r23   k22 ; k22 = 102
.line	886	loadk        r24   k23 ; k23 = 25
.line	886	loadk        r25   k24 ; k24 = 99
.line	886	loadk        r26   k25 ; k25 = 156
.line	886	loadk        r27   k26 ; k26 = 76
.line	886	loadk        r28   k27 ; k27 = 122
.line	886	loadk        r29   k28 ; k28 = 113
.line	886	loadk        r30   k29 ; k29 = 108
.line	886	loadk        r31   k30 ; k30 = 28
.line	886	loadk        r32   k31 ; k31 = 8
.line	886	loadk        r33   k32 ; k32 = 195
.line	886	loadk        r34   k33 ; k33 = 90
.line	886	loadk        r35   k19 ; k19 = 54
.line	886	loadk        r36   k18 ; k18 = 38
.line	886	loadk        r37   k34 ; k34 = 148
.line	886	loadk        r38   k35 ; k35 = 120
.line	886	loadk        r39   k28 ; k28 = 113
.line	886	loadk        r40   k30 ; k30 = 28
.line	886	loadk        r41   k36 ; k36 = 81
.line	886	loadk        r42   k37 ; k37 = 141
.line	886	loadk        r43   k38 ; k38 = 82
.line	886	loadk        r44   k39 ; k39 = 127
.line	886	call          r4    41     2
.line	886	getupval      r5    u1
.line	886	loadk         r6   k40 ; k40 = 123
.line	886	loadk         r7   k41 ; k41 = 89
.line	886	loadk         r8   k42 ; k42 = 16
.line	886	loadk         r9   k43 ; k43 = 13
.line	886	loadk        r10   k44 ; k44 = 180
.line	886	loadk        r11    k9 ; k9 = 170
.line	886	loadk        r12   k45 ; k45 = 37
.line	886	loadk        r13   k46 ; k46 = 85
.line	886	loadk        r14    k7 ; k7 = 41
.line	886	call          r5    10     0
.line	886	setlist       r3     0     1
.line	886	call          r2     2     2
.label	l63
.line	886	call          r1     2     1
.line	886	newtable      r1     0     0
.line	886	settable      r0   k47    r1 ; k47 = "CustomUIData"
.line	886	newtable      r1     0     0
.line	886	settable      r0   k48    r1 ; k48 = "CanvasReadyState"
.line	886	newtable      r1     0     0
.line	886	settable      r0   k49    r1 ; k49 = "CanvasBuilt"
.line	886	newtable      r1     0     0
.line	886	settable      r0   k50    r1 ; k50 = "InstanceChangeCache"
.line	886	newtable      r1     0     0
.line	886	settable      r0   k51    r1 ; k51 = "CDORuntimeCount"
.line	886	newtable      r1     0     0
.line	886	settable      r0   k52    r1 ; k52 = "CDOToRuntimeIds"
.line	886	newtable      r1     0     0
.line	886	settable      r0   k53    r1 ; k53 = "RuntimeToCDO"
.line	886	newtable      r1     0     0
.line	886	settable      r0   k54    r1 ; k54 = "RuntimeReady"
.line	886	newtable      r1     0     0
.line	886	settable      r0   k55    r1 ; k55 = "PendingLoadRuntimeId" (truncated)
.line	886	newtable      r1     0     0
.line	886	settable      r0   k56    r1 ; k56 = "AppliedFieldDeltas"
.line	886	newtable      r1     0     0
.line	886	settable      r0   k57    r1 ; k57 = "BroadcastEventIndex"
.line	886	newtable      r1     0     0
.line	886	settable      r0   k58    r1 ; k58 = "CustomEventIndex"
.line	886	newtable      r1     0     0
.line	886	settable      r0   k59    r1 ; k59 = "UIEventIndexKeys"
.line	886	gettable      r1    r0   k60 ; k60 = "_VFXAutoHideTimers"
.line	886	eq             1    r1   k61 ; k61 = nil
.line	886	jmp            0  l104
.line	886	gettabup      r1    u0   k62 ; k62 = "pairs"
.line	886	gettable      r2    r0   k60 ; k60 = "_VFXAutoHideTimers"
.line	886	call          r1     2     4
.line	886	jmp            0  l100
.line	886	self          r6    r0   k63 ; k63 = "RemoveGameTimer"
.line	886	move          r8    r5
.line	886	call          r6     3     1
.label	l100
.line	886	move          r0    r0
.line	886	move          r0    r0
.line	886	newtable      r1     0     0
.line	886	settable      r0   k60    r1 ; k60 = "_VFXAutoHideTimers"
.label	l104
.line	886	return        r0     1
.line	886	move          r0    r0
.line	886	move          r0    r0
.line	886	move          r0    r0
.line	886	move          r0    r0
.line	886	return        r0     1

.function	main/f40

.source	null
.linedefined	909
.lastlinedefined	932
.numparams	1
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"PendingLoadRuntimeIds"
.constant	k1	"pairs"
.constant	k2	"CustomUIData"
.constant	k3	"UMGCanvasInfo"
.constant	k4	"print"
.constant	k5	"bWriteLog"
.constant	k6	"table"
.constant	k7	"concat"
.constant	k8	126
.constant	k9	68
.constant	k10	7
.constant	k11	41
.constant	k12	164
.constant	k13	170
.constant	k14	39
.constant	k15	95
.constant	k16	24
.constant	k17	91
.constant	k18	26
.constant	k19	31
.constant	k20	217
.constant	k21	83
.constant	k22	38
.constant	k23	54
.constant	k24	137
.constant	k25	103
.constant	k26	102
.constant	k27	25
.constant	k28	99
.constant	k29	156
.constant	k30	76
.constant	k31	122
.constant	k32	113
.constant	k33	120
.constant	k34	21
.constant	k35	14
.constant	k36	213
.constant	k37	70
.constant	k38	51
.constant	k39	10
.constant	k40	179
.constant	k41	114
.constant	k42	107
.constant	k43	6
.constant	k44	87
.constant	k45	175
.constant	k46	94
.constant	k47	123
.constant	k48	89
.constant	k49	22
.constant	k50	16
.constant	k51	45
.constant	k52	160
.constant	k53	48
.constant	k54	67
.constant	k55	118
.constant	k56	77
.constant	k57	8
.constant	k58	5
.constant	k59	192
.constant	k60	0
.constant	k61	"ClientTryLoadCustomUIObject"
.constant	k62	"ReplayAppliedFieldDeltas"
.constant	k63	nil
.constant	k64	15
.constant	k65	209

.line	909	gettable      r1    r0    k0 ; k0 = "PendingLoadRuntimeId" (truncated)
.line	909	test          r1     1
.line	909	jmp            0    l5
.line	909	return        r0     1
.label	l5
.line	909	gettable      r1    r0    k0 ; k0 = "PendingLoadRuntimeId" (truncated)
.line	909	newtable      r2     0     0
.line	909	settable      r0    k0    r2 ; k0 = "PendingLoadRuntimeId" (truncated)
.line	909	gettabup      r2    u0    k1 ; k1 = "pairs"
.line	909	move          r3    r1
.line	909	call          r2     2     4
.line	909	jmp            0   l97
.line	909	gettable      r6    r0    k2 ; k2 = "CustomUIData"
.line	909	gettable      r6    r6    r5
.line	909	test          r6     0
.line	909	jmp            0   l97
.line	909	gettable      r7    r6    k3 ; k3 = "UMGCanvasInfo"
.line	909	test          r7     0
.line	909	jmp            0   l97
.line	909	gettabup      r7    u0    k4 ; k4 = "print"
.line	909	gettabup      r8    u0    k5 ; k5 = "bWriteLog"
.line	909	test          r8     0
.line	909	jmp            0   l87
.line	909	gettabup      r8    u0    k6 ; k6 = "table"
.line	909	gettable      r8    r8    k7 ; k7 = "concat"
.line	909	newtable      r9     1     0
.line	909	getupval     r10    u1
.line	909	loadk        r11    k8 ; k8 = 126
.line	909	loadk        r12    k9 ; k9 = 68
.line	909	loadk        r13   k10 ; k10 = 7
.line	909	loadk        r14   k11 ; k11 = 41
.line	909	loadk        r15   k12 ; k12 = 164
.line	909	loadk        r16   k13 ; k13 = 170
.line	909	loadk        r17   k14 ; k14 = 39
.line	909	loadk        r18   k15 ; k15 = 95
.line	909	loadk        r19   k16 ; k16 = 24
.line	909	loadk        r20   k17 ; k17 = 91
.line	909	loadk        r21   k18 ; k18 = 26
.line	909	loadk        r22   k19 ; k19 = 31
.line	909	loadk        r23   k20 ; k20 = 217
.line	909	loadk        r24   k21 ; k21 = 83
.line	909	loadk        r25   k22 ; k22 = 38
.line	909	loadk        r26   k23 ; k23 = 54
.line	909	loadk        r27   k24 ; k24 = 137
.line	909	loadk        r28   k25 ; k25 = 103
.line	909	loadk        r29   k26 ; k26 = 102
.line	909	loadk        r30   k27 ; k27 = 25
.line	909	loadk        r31   k28 ; k28 = 99
.line	909	loadk        r32   k29 ; k29 = 156
.line	909	loadk        r33   k30 ; k30 = 76
.line	909	loadk        r34   k31 ; k31 = 122
.line	909	loadk        r35   k32 ; k32 = 113
.line	909	loadk        r36   k33 ; k33 = 120
.line	909	loadk        r37   k34 ; k34 = 21
.line	909	loadk        r38   k35 ; k35 = 14
.line	909	loadk        r39   k36 ; k36 = 213
.line	909	loadk        r40   k37 ; k37 = 70
.line	909	loadk        r41   k38 ; k38 = 51
.line	909	loadk        r42   k39 ; k39 = 10
.line	909	loadk        r43   k40 ; k40 = 179
.line	909	loadk        r44   k41 ; k41 = 114
.line	909	loadk        r45   k42 ; k42 = 107
.line	909	loadk        r46   k43 ; k43 = 6
.line	909	loadk        r47   k44 ; k44 = 87
.line	909	loadk        r48   k45 ; k45 = 175
.line	909	loadk        r49   k46 ; k46 = 94
.line	909	loadk        r50   k47 ; k47 = 123
.line	909	call         r10    41     2
.line	909	getupval     r11    u1
.line	909	loadk        r12   k48 ; k48 = 89
.line	909	loadk        r13   k49 ; k49 = 22
.line	909	loadk        r14   k50 ; k50 = 16
.line	909	loadk        r15   k51 ; k51 = 45
.line	909	loadk        r16   k52 ; k52 = 160
.line	909	loadk        r17   k45 ; k45 = 175
.line	909	loadk        r18   k53 ; k53 = 48
.line	909	loadk        r19   k54 ; k54 = 67
.line	909	loadk        r20   k55 ; k55 = 118
.line	909	loadk        r21   k56 ; k56 = 77
.line	909	loadk        r22   k57 ; k57 = 8
.line	909	loadk        r23   k58 ; k58 = 5
.line	909	loadk        r24   k59 ; k59 = 192
.line	909	loadk        r25   k15 ; k15 = 95
.line	909	loadk        r26   k60 ; k60 = 0
.line	909	call         r11    16     0
.line	909	setlist       r9     0     1
.line	909	call          r8     2     2
.label	l87
.line	909	move          r9    r5
.line	909	call          r7     3     1
.line	909	self          r7    r0   k61 ; k61 = "ClientTryLoadCustomU" (truncated)
.line	909	move          r9    r5
.line	909	move         r10    r6
.line	909	call          r7     4     1
.line	909	self          r7    r0   k62 ; k62 = "ReplayAppliedFieldDe" (truncated)
.line	909	move          r9    r5
.line	909	call          r7     3     1
.line	909	settable      r1    r5   k63 ; k63 = nil
.label	l97
.line	909	move          r0    r0
.line	909	move          r0    r0
.line	909	gettabup      r2    u0    k1 ; k1 = "pairs"
.line	909	move          r3    r1
.line	909	call          r2     2     4
.line	909	jmp            0  l184
.line	909	gettable      r6    r0    k2 ; k2 = "CustomUIData"
.line	909	gettable      r6    r6    r5
.line	909	test          r6     0
.line	909	jmp            0  l184
.line	909	gettabup      r7    u0    k4 ; k4 = "print"
.line	909	gettabup      r8    u0    k5 ; k5 = "bWriteLog"
.line	909	test          r8     0
.line	909	jmp            0  l175
.line	909	gettabup      r8    u0    k6 ; k6 = "table"
.line	909	gettable      r8    r8    k7 ; k7 = "concat"
.line	909	newtable      r9     1     0
.line	909	getupval     r10    u1
.line	909	loadk        r11    k8 ; k8 = 126
.line	909	loadk        r12    k9 ; k9 = 68
.line	909	loadk        r13   k10 ; k10 = 7
.line	909	loadk        r14   k11 ; k11 = 41
.line	909	loadk        r15   k12 ; k12 = 164
.line	909	loadk        r16   k13 ; k13 = 170
.line	909	loadk        r17   k14 ; k14 = 39
.line	909	loadk        r18   k15 ; k15 = 95
.line	909	loadk        r19   k16 ; k16 = 24
.line	909	loadk        r20   k17 ; k17 = 91
.line	909	loadk        r21   k18 ; k18 = 26
.line	909	loadk        r22   k19 ; k19 = 31
.line	909	loadk        r23   k20 ; k20 = 217
.line	909	loadk        r24   k21 ; k21 = 83
.line	909	loadk        r25   k22 ; k22 = 38
.line	909	loadk        r26   k23 ; k23 = 54
.line	909	loadk        r27   k24 ; k24 = 137
.line	909	loadk        r28   k25 ; k25 = 103
.line	909	loadk        r29   k26 ; k26 = 102
.line	909	loadk        r30   k27 ; k27 = 25
.line	909	loadk        r31   k28 ; k28 = 99
.line	909	loadk        r32   k29 ; k29 = 156
.line	909	loadk        r33   k30 ; k30 = 76
.line	909	loadk        r34   k31 ; k31 = 122
.line	909	loadk        r35   k32 ; k32 = 113
.line	909	loadk        r36   k33 ; k33 = 120
.line	909	loadk        r37   k34 ; k34 = 21
.line	909	loadk        r38   k35 ; k35 = 14
.line	909	loadk        r39   k36 ; k36 = 213
.line	909	loadk        r40   k37 ; k37 = 70
.line	909	loadk        r41   k38 ; k38 = 51
.line	909	loadk        r42   k39 ; k39 = 10
.line	909	loadk        r43   k40 ; k40 = 179
.line	909	loadk        r44   k41 ; k41 = 114
.line	909	loadk        r45   k42 ; k42 = 107
.line	909	loadk        r46   k43 ; k43 = 6
.line	909	loadk        r47   k44 ; k44 = 87
.line	909	loadk        r48   k45 ; k45 = 175
.line	909	loadk        r49   k46 ; k46 = 94
.line	909	loadk        r50   k47 ; k47 = 123
.line	909	call         r10    41     2
.line	909	getupval     r11    u1
.line	909	loadk        r12   k48 ; k48 = 89
.line	909	loadk        r13   k49 ; k49 = 22
.line	909	loadk        r14   k50 ; k50 = 16
.line	909	loadk        r15   k51 ; k51 = 45
.line	909	loadk        r16   k52 ; k52 = 160
.line	909	loadk        r17   k45 ; k45 = 175
.line	909	loadk        r18   k53 ; k53 = 48
.line	909	loadk        r19   k54 ; k54 = 67
.line	909	loadk        r20   k55 ; k55 = 118
.line	909	loadk        r21   k48 ; k48 = 89
.line	909	loadk        r22   k60 ; k60 = 0
.line	909	loadk        r23   k64 ; k64 = 15
.line	909	loadk        r24   k65 ; k65 = 209
.line	909	loadk        r25   k17 ; k17 = 91
.line	909	loadk        r26   k10 ; k10 = 7
.line	909	call         r11    16     0
.line	909	setlist       r9     0     1
.line	909	call          r8     2     2
.label	l175
.line	909	move          r9    r5
.line	909	call          r7     3     1
.line	909	self          r7    r0   k61 ; k61 = "ClientTryLoadCustomU" (truncated)
.line	909	move          r9    r5
.line	909	move         r10    r6
.line	909	call          r7     4     1
.line	909	self          r7    r0   k62 ; k62 = "ReplayAppliedFieldDe" (truncated)
.line	909	move          r9    r5
.line	909	call          r7     3     1
.label	l184
.line	909	move          r0    r0
.line	909	move          r0    r0
.line	909	return        r0     1
.line	909	move          r0    r0
.line	909	move          r0    r0
.line	909	move          r0    r0
.line	909	move          r0    r0
.line	909	return        r0     1

.function	main/f41

.source	null
.linedefined	934
.lastlinedefined	985
.numparams	1
.is_vararg	0
.maxstacksize	17

.upvalue	"_ENV"	0	false

.constant	k0	"GetInstanceManager"
.constant	k1	"GetCreativeUMGInfoManager"
.constant	k2	"CGameState"
.constant	k3	"slua"
.constant	k4	"isValid"
.constant	k5	"IsOfficialGame"
.constant	k6	"HasAuthority"
.constant	k7	"_G"
.constant	k8	"EnableUMGInfoManager"
.constant	k9	"GetInstanceTree"
.constant	k10	"GetAllGameUMGInfoTree"
.constant	k11	"next"
.constant	k12	"pairs"
.constant	k13	"UMGCanvasInfo"
.constant	k14	"CustomUIBase"
.constant	k15	L"PrebuildClientUMGInfoTreeFromLobbyBinCache"

.line	934	gettabup      r1    u0    k0 ; k0 = "GetInstanceManager"
.line	934	call          r1     1     2
.line	934	gettabup      r2    u0    k1 ; k1 = "GetCreativeUMGInfoMa" (truncated)
.line	934	call          r2     1     2
.line	934	gettabup      r3    u0    k2 ; k2 = "CGameState"
.line	934	test          r3     0
.line	934	jmp            0   l21
.line	934	gettabup      r3    u0    k3 ; k3 = "slua"
.line	934	gettable      r3    r3    k4 ; k4 = "isValid"
.line	934	gettabup      r4    u0    k2 ; k2 = "CGameState"
.line	934	call          r3     2     2
.line	934	test          r3     0
.line	934	jmp            0   l21
.line	934	gettabup      r3    u0    k2 ; k2 = "CGameState"
.line	934	gettable      r3    r3    k5 ; k5 = "IsOfficialGame"
.line	934	test          r3     0
.line	934	jmp            0   l21
.line	934	gettabup      r3    u0    k2 ; k2 = "CGameState"
.line	934	self          r3    r3    k5 ; k5 = "IsOfficialGame"
.line	934	call          r3     2     2
.label	l21
.line	934	self          r4    r0    k6 ; k6 = "HasAuthority"
.line	934	call          r4     2     2
.line	934	test          r4     0
.line	934	jmp            0   l86
.line	934	gettabup      r4    u0    k7 ; k7 = "_G"
.line	934	gettable      r4    r4    k8 ; k8 = "EnableUMGInfoManager"
.line	934	test          r4     1
.line	934	jmp            0   l35
.line	934	testset       r4    r1     0
.line	934	jmp            0   l33
.line	934	self          r4    r1    k9 ; k9 = "GetInstanceTree"
.line	934	call          r4     2     2
.label	l33
.line	934	return        r4     2
.line	934	jmp            0  l133
.label	l35
.line	934	newtable      r4     0     0
.line	934	testset       r5    r2     0
.line	934	jmp            0   l40
.line	934	self          r5    r2   k10 ; k10 = "GetAllGameUMGInfoTre" (truncated)
.line	934	call          r5     2     2
.label	l40
.line	934	test          r5     0
.line	934	jmp            0   l63
.line	934	gettabup      r6    u0   k11 ; k11 = "next"
.line	934	move          r7    r5
.line	934	call          r6     2     2
.line	934	test          r6     0
.line	934	jmp            0   l63
.line	934	gettabup      r6    u0   k12 ; k12 = "pairs"
.line	934	move          r7    r5
.line	934	call          r6     2     4
.line	934	jmp            0   l60
.line	934	test         r10     0
.line	934	jmp            0   l60
.line	934	gettabup     r11    u0   k12 ; k12 = "pairs"
.line	934	move         r12   r10
.line	934	call         r11     2     4
.line	934	jmp            0   l58
.line	934	settable      r4   r14   r15
.label	l58
.line	934	move          r0    r0
.line	934	move          r0    r0
.label	l60
.line	934	move          r0    r0
.line	934	move          r0    r0
.line	934	jmp            0   l84
.label	l63
.line	934	testset       r6    r1     0
.line	934	jmp            0   l67
.line	934	self          r6    r1    k9 ; k9 = "GetInstanceTree"
.line	934	call          r6     2     2
.label	l67
.line	934	test          r6     0
.line	934	jmp            0   l84
.line	934	gettabup      r7    u0   k12 ; k12 = "pairs"
.line	934	move          r8    r6
.line	934	call          r7     2     4
.line	934	jmp            0   l82
.line	934	test         r11     0
.line	934	jmp            0   l82
.line	934	gettable     r12   r11   k13 ; k13 = "UMGCanvasInfo"
.line	934	test         r12     1
.line	934	jmp            0   l81
.line	934	gettable     r12   r11   k14 ; k14 = "CustomUIBase"
.line	934	test         r12     0
.line	934	jmp            0   l82
.label	l81
.line	934	settable      r4   r10   r11
.label	l82
.line	934	move          r0    r0
.line	934	move          r0    r0
.label	l84
.line	934	return        r4     2
.line	934	jmp            0  l133
.label	l86
.line	934	test          r3     0
.line	934	jmp            0   l95
.line	934	test          r2     0
.line	934	jmp            0   l95
.line	934	gettable      r4    r2   k15 ; k15 = L"PrebuildClientUMGInf" (truncated)
.line	934	test          r4     0
.line	934	jmp            0   l95
.line	934	self          r4    r2   k15 ; k15 = L"PrebuildClientUMGInf" (truncated)
.line	934	call          r4     2     1
.label	l95
.line	934	gettabup      r4    u0    k7 ; k7 = "_G"
.line	934	gettable      r4    r4    k8 ; k8 = "EnableUMGInfoManager"
.line	934	test          r4     1
.line	934	jmp            0  l105
.line	934	testset       r4    r1     0
.line	934	jmp            0  l103
.line	934	self          r4    r1    k9 ; k9 = "GetInstanceTree"
.line	934	call          r4     2     2
.label	l103
.line	934	return        r4     2
.line	934	jmp            0  l133
.label	l105
.line	934	newtable      r4     0     0
.line	934	testset       r5    r2     0
.line	934	jmp            0  l110
.line	934	self          r5    r2   k10 ; k10 = "GetAllGameUMGInfoTre" (truncated)
.line	934	call          r5     2     2
.label	l110
.line	934	test          r5     0
.line	934	jmp            0  l132
.line	934	gettabup      r6    u0   k11 ; k11 = "next"
.line	934	move          r7    r5
.line	934	call          r6     2     2
.line	934	test          r6     0
.line	934	jmp            0  l132
.line	934	gettabup      r6    u0   k12 ; k12 = "pairs"
.line	934	move          r7    r5
.line	934	call          r6     2     4
.line	934	jmp            0  l130
.line	934	test         r10     0
.line	934	jmp            0  l130
.line	934	gettabup     r11    u0   k12 ; k12 = "pairs"
.line	934	move         r12   r10
.line	934	call         r11     2     4
.line	934	jmp            0  l128
.line	934	settable      r4   r14   r15
.label	l128
.line	934	move          r0    r0
.line	934	move          r0    r0
.label	l130
.line	934	move          r0    r0
.line	934	move          r0    r0
.label	l132
.line	934	return        r4     2
.label	l133
.line	934	return        r0     1
.line	934	move          r0    r0
.line	934	move          r0    r0
.line	934	return        r0     1

.function	main/f42

.source	null
.linedefined	987
.lastlinedefined	1014
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"GetLoadManager"
.constant	k2	"bNewCustomUI"
.constant	k3	"GetUIBinTableFromMap"
.constant	k4	"print"
.constant	k5	"bWriteLog"
.constant	k6	"table"
.constant	k7	"concat"
.constant	k8	126
.constant	k9	68
.constant	k10	7
.constant	k11	41
.constant	k12	164
.constant	k13	170
.constant	k14	39
.constant	k15	95
.constant	k16	24
.constant	k17	91
.constant	k18	26
.constant	k19	31
.constant	k20	217
.constant	k21	83
.constant	k22	38
.constant	k23	54
.constant	k24	137
.constant	k25	103
.constant	k26	102
.constant	k27	25
.constant	k28	99
.constant	k29	156
.constant	k30	76
.constant	k31	122
.constant	k32	113
.constant	k33	125
.constant	k34	21
.constant	k35	18
.constant	k36	195
.constant	k37	64
.constant	k38	23
.constant	k39	63
.constant	k40	175
.constant	k41	115
.constant	k42	110
.constant	k43	81
.constant	k44	135
.constant	k45	119
.constant	k46	104
.constant	k47	82
.constant	k48	47
.constant	k49	160
.constant	k50	48
.constant	k51	78
.constant	k52	58
.constant	k53	"pairs"
.constant	k54	"UMGCanvasInfo"
.constant	k55	"CustomUIBase"
.constant	k56	nil
.constant	k57	"CloneCDOToRuntime"
.constant	k58	1
.constant	k59	"CustomUIData"
.constant	k60	"RegisterInstanceIndex"
.constant	k61	"NotifyTalentNodeLanded"
.constant	k62	"ClientTryLoadCustomUIObject"
.constant	k63	"ReplayAppliedFieldDeltas"

.line	987	gettabup      r1    u0    k0 ; k0 = "Client"
.line	987	test          r1     1
.line	987	jmp            0    l5
.line	987	return        r0     1
.label	l5
.line	987	gettabup      r1    u0    k1 ; k1 = "GetLoadManager"
.line	987	call          r1     1     2
.line	987	test          r1     0
.line	987	jmp            0   l12
.line	987	gettable      r2    r1    k2 ; k2 = "bNewCustomUI"
.line	987	test          r2     1
.line	987	jmp            0   l13
.label	l12
.line	987	return        r0     1
.label	l13
.line	987	self          r2    r0    k3 ; k3 = "GetUIBinTableFromMap"
.line	987	call          r2     2     2
.line	987	test          r2     1
.line	987	jmp            0   l18
.line	987	return        r0     1
.label	l18
.line	987	gettabup      r3    u0    k4 ; k4 = "print"
.line	987	gettabup      r4    u0    k5 ; k5 = "bWriteLog"
.line	987	test          r4     0
.line	987	jmp            0   l80
.line	987	gettabup      r4    u0    k6 ; k6 = "table"
.line	987	gettable      r4    r4    k7 ; k7 = "concat"
.line	987	newtable      r5     1     0
.line	987	getupval      r6    u1
.line	987	loadk         r7    k8 ; k8 = 126
.line	987	loadk         r8    k9 ; k9 = 68
.line	987	loadk         r9   k10 ; k10 = 7
.line	987	loadk        r10   k11 ; k11 = 41
.line	987	loadk        r11   k12 ; k12 = 164
.line	987	loadk        r12   k13 ; k13 = 170
.line	987	loadk        r13   k14 ; k14 = 39
.line	987	loadk        r14   k15 ; k15 = 95
.line	987	loadk        r15   k16 ; k16 = 24
.line	987	loadk        r16   k17 ; k17 = 91
.line	987	loadk        r17   k18 ; k18 = 26
.line	987	loadk        r18   k19 ; k19 = 31
.line	987	loadk        r19   k20 ; k20 = 217
.line	987	loadk        r20   k21 ; k21 = 83
.line	987	loadk        r21   k22 ; k22 = 38
.line	987	loadk        r22   k23 ; k23 = 54
.line	987	loadk        r23   k24 ; k24 = 137
.line	987	loadk        r24   k25 ; k25 = 103
.line	987	loadk        r25   k26 ; k26 = 102
.line	987	loadk        r26   k27 ; k27 = 25
.line	987	loadk        r27   k28 ; k28 = 99
.line	987	loadk        r28   k29 ; k29 = 156
.line	987	loadk        r29   k30 ; k30 = 76
.line	987	loadk        r30   k31 ; k31 = 122
.line	987	loadk        r31   k32 ; k32 = 113
.line	987	loadk        r32   k33 ; k33 = 125
.line	987	loadk        r33   k34 ; k34 = 21
.line	987	loadk        r34   k35 ; k35 = 18
.line	987	loadk        r35   k36 ; k36 = 195
.line	987	loadk        r36   k37 ; k37 = 64
.line	987	loadk        r37   k38 ; k38 = 23
.line	987	loadk        r38   k39 ; k39 = 63
.line	987	loadk        r39   k40 ; k40 = 175
.line	987	loadk        r40   k41 ; k41 = 115
.line	987	loadk        r41   k42 ; k42 = 110
.line	987	loadk        r42   k10 ; k10 = 7
.line	987	loadk        r43   k43 ; k43 = 81
.line	987	loadk        r44   k44 ; k44 = 135
.line	987	loadk        r45   k45 ; k45 = 119
.line	987	loadk        r46   k46 ; k46 = 104
.line	987	call          r6    41     2
.line	987	getupval      r7    u1
.line	987	loadk         r8   k47 ; k47 = 82
.line	987	loadk         r9   k17 ; k17 = 91
.line	987	loadk        r10   k48 ; k48 = 47
.line	987	loadk        r11   k11 ; k11 = 41
.line	987	loadk        r12   k49 ; k49 = 160
.line	987	loadk        r13   k44 ; k44 = 135
.line	987	loadk        r14   k50 ; k50 = 48
.line	987	loadk        r15   k51 ; k51 = 78
.line	987	loadk        r16   k52 ; k52 = 58
.line	987	call          r7    10     0
.line	987	setlist       r5     0     1
.line	987	call          r4     2     2
.label	l80
.line	987	call          r3     2     1
.line	987	gettabup      r3    u0   k53 ; k53 = "pairs"
.line	987	move          r4    r2
.line	987	call          r3     2     4
.line	987	jmp            0  l125
.line	987	test          r7     0
.line	987	jmp            0  l125
.line	987	gettable      r8    r7   k54 ; k54 = "UMGCanvasInfo"
.line	987	test          r8     0
.line	987	jmp            0  l125
.line	987	gettable      r8    r7   k55 ; k55 = "CustomUIBase"
.line	987	eq             0    r8   k56 ; k56 = nil
.line	987	jmp            0  l125
.line	987	self          r8    r0   k57 ; k57 = "CloneCDOToRuntime"
.line	987	move         r10    r6
.line	987	move         r11    r2
.line	987	loadk        r12   k58 ; k58 = 1
.line	987	call          r8     5     3
.line	987	test          r8     0
.line	987	jmp            0  l125
.line	987	test          r9     0
.line	987	jmp            0  l125
.line	987	gettabup     r10    u0   k53 ; k53 = "pairs"
.line	987	move         r11    r9
.line	987	call         r10     2     4
.line	987	jmp            0  l123
.line	987	gettable     r15    r0   k59 ; k59 = "CustomUIData"
.line	987	settable     r15   r13   r14
.line	987	self         r15    r0   k60 ; k60 = "RegisterInstanceInde" (truncated)
.line	987	move         r17   r13
.line	987	move         r18   r14
.line	987	call         r15     4     1
.line	987	self         r15    r0   k61 ; k61 = "NotifyTalentNodeLand" (truncated)
.line	987	move         r17   r13
.line	987	move         r18   r14
.line	987	call         r15     4     1
.line	987	self         r15    r0   k62 ; k62 = "ClientTryLoadCustomU" (truncated)
.line	987	move         r17   r13
.line	987	move         r18   r14
.line	987	call         r15     4     1
.line	987	self         r15    r0   k63 ; k63 = "ReplayAppliedFieldDe" (truncated)
.line	987	move         r17   r13
.line	987	call         r15     3     1
.label	l123
.line	987	move          r0    r0
.line	987	move          r0    r0
.label	l125
.line	987	move          r0    r0
.line	987	move          r0    r0
.line	987	return        r0     1
.line	987	move          r0    r0
.line	987	move          r0    r0
.line	987	move          r0    r0
.line	987	move          r0    r0
.line	987	return        r0     1

.function	main/f43

.source	null
.linedefined	1016
.lastlinedefined	1036
.numparams	5
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	6	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	126
.constant	k5	68
.constant	k6	7
.constant	k7	41
.constant	k8	164
.constant	k9	170
.constant	k10	39
.constant	k11	95
.constant	k12	24
.constant	k13	91
.constant	k14	26
.constant	k15	31
.constant	k16	217
.constant	k17	83
.constant	k18	38
.constant	k19	54
.constant	k20	137
.constant	k21	103
.constant	k22	102
.constant	k23	25
.constant	k24	99
.constant	k25	156
.constant	k26	76
.constant	k27	122
.constant	k28	113
.constant	k29	23
.constant	k30	60
.constant	k31	199
.constant	k32	67
.constant	k33	6
.constant	k34	59
.constant	k35	43
.constant	k36	88
.constant	k37	130
.constant	k38	125
.constant	k39	82
.constant	k40	66
.constant	k41	4
.constant	k42	177
.constant	k43	176
.constant	k44	37
.constant	k45	58
.constant	k46	12
.constant	k47	63
.constant	k48	207
.constant	k49	78
.constant	k50	22
.constant	k51	69
.constant	k52	"tostring"
.constant	k53	29
.constant	k54	117
.constant	k55	162
.constant	k56	166
.constant	k57	28
.constant	k58	79
.constant	k59	14
.constant	k60	226
.constant	k61	71
.constant	k62	3
.constant	k63	247
.constant	k64	"import"
.constant	k65	120
.constant	k66	16
.constant	k67	45
.constant	k68	183
.constant	k69	56
.constant	k70	62
.constant	k71	15
.constant	k72	211
.constant	k73	121
.constant	k74	18
.constant	k75	168
.constant	k76	107
.constant	k77	8
.constant	k78	"CacheCurGameType"
.constant	k79	"HasAuthority"
.constant	k80	"CreativeModeGameType_Game"
.constant	k81	"CopyUIInstance"
.constant	k82	"CreativeModeGameType_Editor"
.constant	k83	"ResetUIInstance"
.constant	k84	"FlushPendingLoad"
.constant	k85	"ReportGameCanvasSize"
.constant	k86	"ClientPreloadFromMapData"
.constant	k87	"DestroyWidgetObjects"

.line	1016	gettabup      r5    u0    k0 ; k0 = "print"
.line	1016	gettabup      r6    u0    k1 ; k1 = "bWriteLog"
.line	1016	test          r6     0
.line	1016	jmp            0   l96
.line	1016	gettabup      r6    u0    k2 ; k2 = "table"
.line	1016	gettable      r6    r6    k3 ; k3 = "concat"
.line	1016	newtable      r7     1     0
.line	1016	getupval      r8    u1
.line	1016	loadk         r9    k4 ; k4 = 126
.line	1016	loadk        r10    k5 ; k5 = 68
.line	1016	loadk        r11    k6 ; k6 = 7
.line	1016	loadk        r12    k7 ; k7 = 41
.line	1016	loadk        r13    k8 ; k8 = 164
.line	1016	loadk        r14    k9 ; k9 = 170
.line	1016	loadk        r15   k10 ; k10 = 39
.line	1016	loadk        r16   k11 ; k11 = 95
.line	1016	loadk        r17   k12 ; k12 = 24
.line	1016	loadk        r18   k13 ; k13 = 91
.line	1016	loadk        r19   k14 ; k14 = 26
.line	1016	loadk        r20   k15 ; k15 = 31
.line	1016	loadk        r21   k16 ; k16 = 217
.line	1016	loadk        r22   k17 ; k17 = 83
.line	1016	loadk        r23   k18 ; k18 = 38
.line	1016	loadk        r24   k19 ; k19 = 54
.line	1016	loadk        r25   k20 ; k20 = 137
.line	1016	loadk        r26   k21 ; k21 = 103
.line	1016	loadk        r27   k22 ; k22 = 102
.line	1016	loadk        r28   k23 ; k23 = 25
.line	1016	loadk        r29   k24 ; k24 = 99
.line	1016	loadk        r30   k25 ; k25 = 156
.line	1016	loadk        r31   k26 ; k26 = 76
.line	1016	loadk        r32   k27 ; k27 = 122
.line	1016	loadk        r33   k28 ; k28 = 113
.line	1016	loadk        r34   k28 ; k28 = 113
.line	1016	loadk        r35   k29 ; k29 = 23
.line	1016	loadk        r36   k30 ; k30 = 60
.line	1016	loadk        r37   k31 ; k31 = 199
.line	1016	loadk        r38   k32 ; k32 = 67
.line	1016	loadk        r39   k33 ; k33 = 6
.line	1016	loadk        r40   k34 ; k34 = 59
.line	1016	loadk        r41    k8 ; k8 = 164
.line	1016	loadk        r42   k22 ; k22 = 102
.line	1016	loadk        r43   k21 ; k21 = 103
.line	1016	loadk        r44   k35 ; k35 = 43
.line	1016	loadk        r45   k36 ; k36 = 88
.line	1016	loadk        r46   k37 ; k37 = 130
.line	1016	loadk        r47   k11 ; k11 = 95
.line	1016	loadk        r48   k38 ; k38 = 125
.line	1016	call          r8    41     2
.line	1016	getupval      r9    u1
.line	1016	loadk        r10   k36 ; k36 = 88
.line	1016	loadk        r11   k39 ; k39 = 82
.line	1016	loadk        r12   k40 ; k40 = 66
.line	1016	loadk        r13   k41 ; k41 = 4
.line	1016	loadk        r14   k42 ; k42 = 177
.line	1016	loadk        r15   k43 ; k43 = 176
.line	1016	loadk        r16   k44 ; k44 = 37
.line	1016	loadk        r17   k38 ; k38 = 125
.line	1016	loadk        r18   k45 ; k45 = 58
.line	1016	loadk        r19   k32 ; k32 = 67
.line	1016	loadk        r20   k46 ; k46 = 12
.line	1016	loadk        r21   k47 ; k47 = 63
.line	1016	loadk        r22   k48 ; k48 = 207
.line	1016	loadk        r23   k49 ; k49 = 78
.line	1016	loadk        r24   k50 ; k50 = 22
.line	1016	loadk        r25   k51 ; k51 = 69
.line	1016	call          r9    17     0
.line	1016	setlist       r7     0     1
.line	1016	call          r6     2     2
.line	1016	gettabup      r7    u0   k52 ; k52 = "tostring"
.line	1016	move          r8    r3
.line	1016	call          r7     2     2
.line	1016	getupval      r8    u1
.line	1016	loadk         r9   k53 ; k53 = 29
.line	1016	loadk        r10   k54 ; k54 = 117
.line	1016	loadk        r11   k29 ; k29 = 23
.line	1016	loadk        r12   k45 ; k45 = 58
.line	1016	loadk        r13   k55 ; k55 = 162
.line	1016	loadk        r14   k56 ; k56 = 166
.line	1016	loadk        r15   k47 ; k47 = 63
.line	1016	loadk        r16   k49 ; k49 = 78
.line	1016	loadk        r17   k57 ; k57 = 28
.line	1016	loadk        r18   k58 ; k58 = 79
.line	1016	loadk        r19   k41 ; k41 = 4
.line	1016	loadk        r20   k59 ; k59 = 14
.line	1016	loadk        r21   k60 ; k60 = 226
.line	1016	loadk        r22   k61 ; k61 = 71
.line	1016	loadk        r23   k62 ; k62 = 3
.line	1016	loadk        r24   k14 ; k14 = 26
.line	1016	loadk        r25   k63 ; k63 = 247
.line	1016	call          r8    18     2
.line	1016	gettabup      r9    u0   k52 ; k52 = "tostring"
.line	1016	move         r10    r4
.line	1016	call          r9     2     2
.line	1016	concat        r6    r6    r9
.label	l96
.line	1016	call          r5     2     1
.line	1016	gettabup      r5    u0   k64 ; k64 = "import"
.line	1016	getupval      r6    u1
.line	1016	loadk         r7   k65 ; k65 = 120
.line	1016	loadk         r8   k54 ; k54 = 117
.line	1016	loadk         r9   k66 ; k66 = 16
.line	1016	loadk        r10   k67 ; k67 = 45
.line	1016	loadk        r11   k42 ; k42 = 177
.line	1016	loadk        r12   k68 ; k68 = 183
.line	1016	loadk        r13   k69 ; k69 = 56
.line	1016	loadk        r14   k26 ; k26 = 76
.line	1016	loadk        r15   k70 ; k70 = 62
.line	1016	loadk        r16   k24 ; k24 = 99
.line	1016	loadk        r17   k33 ; k33 = 6
.line	1016	loadk        r18   k71 ; k71 = 15
.line	1016	loadk        r19   k72 ; k72 = 211
.line	1016	loadk        r20   k73 ; k73 = 121
.line	1016	loadk        r21   k74 ; k74 = 18
.line	1016	loadk        r22   k74 ; k74 = 18
.line	1016	loadk        r23   k75 ; k75 = 168
.line	1016	loadk        r24   k39 ; k39 = 82
.line	1016	loadk        r25   k76 ; k76 = 107
.line	1016	loadk        r26   k77 ; k77 = 8
.line	1016	loadk        r27   k51 ; k51 = 69
.line	1016	call          r6    22     2
.line	1016	call          r5     2     2
.line	1016	settable      r0   k78    r4 ; k78 = "CacheCurGameType"
.line	1016	self          r6    r0   k79 ; k79 = "HasAuthority"
.line	1016	call          r6     2     2
.line	1016	test          r6     0
.line	1016	jmp            0  l139
.line	1016	gettable      r6    r5   k80 ; k80 = "CreativeModeGameType" (truncated)
.line	1016	eq             0    r4    r6
.line	1016	jmp            0  l133
.line	1016	self          r6    r0   k81 ; k81 = "CopyUIInstance"
.line	1016	call          r6     2     1
.line	1016	jmp            0  l159
.label	l133
.line	1016	gettable      r6    r5   k82 ; k82 = "CreativeModeGameType" (truncated)
.line	1016	eq             0    r4    r6
.line	1016	jmp            0  l159
.line	1016	self          r6    r0   k83 ; k83 = "ResetUIInstance"
.line	1016	call          r6     2     1
.line	1016	jmp            0  l159
.label	l139
.line	1016	gettable      r6    r5   k80 ; k80 = "CreativeModeGameType" (truncated)
.line	1016	eq             0    r4    r6
.line	1016	jmp            0  l152
.line	1016	self          r6    r0   k84 ; k84 = "FlushPendingLoad"
.line	1016	call          r6     2     1
.line	1016	self          r6    r0   k85 ; k85 = "ReportGameCanvasSize"
.line	1016	call          r6     2     1
.line	1016	getupval      r6    u2
.line	1016	test          r6     0
.line	1016	jmp            0  l159
.line	1016	self          r6    r0   k86 ; k86 = "ClientPreloadFromMap" (truncated)
.line	1016	call          r6     2     1
.line	1016	jmp            0  l159
.label	l152
.line	1016	gettable      r6    r5   k82 ; k82 = "CreativeModeGameType" (truncated)
.line	1016	eq             0    r4    r6
.line	1016	jmp            0  l159
.line	1016	self          r6    r0   k87 ; k87 = "DestroyWidgetObjects"
.line	1016	call          r6     2     1
.line	1016	self          r6    r0   k83 ; k83 = "ResetUIInstance"
.line	1016	call          r6     2     1
.label	l159
.line	1016	return        r0     1
.line	1016	move          r0    r0
.line	1016	move          r0    r0
.line	1016	return        r0     1

.function	main/f44

.source	null
.linedefined	1038
.lastlinedefined	1043
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"RequestPullSeq"
.constant	k1	1
.constant	k2	"print"
.constant	k3	"bWriteLog"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	126
.constant	k7	68
.constant	k8	7
.constant	k9	41
.constant	k10	164
.constant	k11	170
.constant	k12	39
.constant	k13	95
.constant	k14	24
.constant	k15	91
.constant	k16	26
.constant	k17	31
.constant	k18	217
.constant	k19	83
.constant	k20	38
.constant	k21	54
.constant	k22	137
.constant	k23	103
.constant	k24	102
.constant	k25	25
.constant	k26	99
.constant	k27	156
.constant	k28	76
.constant	k29	122
.constant	k30	113
.constant	k31	108
.constant	k32	28
.constant	k33	10
.constant	k34	211
.constant	k35	75
.constant	k36	16
.constant	k37	27
.constant	k38	141
.constant	k39	110
.constant	k40	4
.constant	k41	115
.constant	k42	150
.constant	k43	66
.constant	k44	82
.constant	k45	55
.constant	k46	148
.constant	k47	162
.constant	k48	37
.constant	k49	9
.constant	k50	30
.constant	k51	219
.constant	k52	61
.constant	k53	169
.constant	k54	84
.constant	k55	79
.constant	k56	158
.constant	k57	101
.constant	k58	121
.constant	k59	107
.constant	k60	109
.constant	k61	"tostring"
.constant	k62	29
.constant	k63	127
.constant	k64	6
.constant	k65	59
.constant	k66	234
.constant	k67	L"ServerRPC_RequestPullCustomUIDataResumeNode"

.line	1038	gettable      r2    r0    k0 ; k0 = "RequestPullSeq"
.line	1038	gettable      r3    r0    k0 ; k0 = "RequestPullSeq"
.line	1038	add           r3    r3    k1 ; k1 = 1
.line	1038	settable      r0    k0    r3 ; k0 = "RequestPullSeq"
.line	1038	gettabup      r3    u0    k2 ; k2 = "print"
.line	1038	gettabup      r4    u0    k3 ; k3 = "bWriteLog"
.line	1038	test          r4     0
.line	1038	jmp            0  l101
.line	1038	gettabup      r4    u0    k4 ; k4 = "table"
.line	1038	gettable      r4    r4    k5 ; k5 = "concat"
.line	1038	newtable      r5     1     0
.line	1038	getupval      r6    u1
.line	1038	loadk         r7    k6 ; k6 = 126
.line	1038	loadk         r8    k7 ; k7 = 68
.line	1038	loadk         r9    k8 ; k8 = 7
.line	1038	loadk        r10    k9 ; k9 = 41
.line	1038	loadk        r11   k10 ; k10 = 164
.line	1038	loadk        r12   k11 ; k11 = 170
.line	1038	loadk        r13   k12 ; k12 = 39
.line	1038	loadk        r14   k13 ; k13 = 95
.line	1038	loadk        r15   k14 ; k14 = 24
.line	1038	loadk        r16   k15 ; k15 = 91
.line	1038	loadk        r17   k16 ; k16 = 26
.line	1038	loadk        r18   k17 ; k17 = 31
.line	1038	loadk        r19   k18 ; k18 = 217
.line	1038	loadk        r20   k19 ; k19 = 83
.line	1038	loadk        r21   k20 ; k20 = 38
.line	1038	loadk        r22   k21 ; k21 = 54
.line	1038	loadk        r23   k22 ; k22 = 137
.line	1038	loadk        r24   k23 ; k23 = 103
.line	1038	loadk        r25   k24 ; k24 = 102
.line	1038	loadk        r26   k25 ; k25 = 25
.line	1038	loadk        r27   k26 ; k26 = 99
.line	1038	loadk        r28   k27 ; k27 = 156
.line	1038	loadk        r29   k28 ; k28 = 76
.line	1038	loadk        r30   k29 ; k29 = 122
.line	1038	loadk        r31   k30 ; k30 = 113
.line	1038	loadk        r32   k31 ; k31 = 108
.line	1038	loadk        r33   k32 ; k32 = 28
.line	1038	loadk        r34   k33 ; k33 = 10
.line	1038	loadk        r35   k34 ; k34 = 211
.line	1038	loadk        r36   k35 ; k35 = 75
.line	1038	loadk        r37   k36 ; k36 = 16
.line	1038	loadk        r38   k37 ; k37 = 27
.line	1038	loadk        r39   k38 ; k38 = 141
.line	1038	loadk        r40   k26 ; k26 = 99
.line	1038	loadk        r41   k39 ; k39 = 110
.line	1038	loadk        r42   k40 ; k40 = 4
.line	1038	loadk        r43   k41 ; k41 = 115
.line	1038	loadk        r44   k42 ; k42 = 150
.line	1038	loadk        r45   k43 ; k43 = 66
.line	1038	loadk        r46   k39 ; k39 = 110
.line	1038	call          r6    41     2
.line	1038	getupval      r7    u1
.line	1038	loadk         r8   k44 ; k44 = 82
.line	1038	loadk         r9   k15 ; k15 = 91
.line	1038	loadk        r10   k45 ; k45 = 55
.line	1038	loadk        r11    k1 ; k1 = 1
.line	1038	loadk        r12   k46 ; k46 = 148
.line	1038	loadk        r13   k47 ; k47 = 162
.line	1038	loadk        r14   k48 ; k48 = 37
.line	1038	loadk        r15   k15 ; k15 = 91
.line	1038	loadk        r16   k49 ; k49 = 9
.line	1038	loadk        r17   k35 ; k35 = 75
.line	1038	loadk        r18   k16 ; k16 = 26
.line	1038	loadk        r19   k50 ; k50 = 30
.line	1038	loadk        r20   k51 ; k51 = 219
.line	1038	loadk        r21   k15 ; k15 = 91
.line	1038	loadk        r22   k52 ; k52 = 61
.line	1038	loadk        r23   k36 ; k36 = 16
.line	1038	loadk        r24   k53 ; k53 = 169
.line	1038	loadk        r25   k26 ; k26 = 99
.line	1038	loadk        r26   k54 ; k54 = 84
.line	1038	loadk        r27   k33 ; k33 = 10
.line	1038	loadk        r28   k55 ; k55 = 79
.line	1038	loadk        r29   k56 ; k56 = 158
.line	1038	loadk        r30   k57 ; k57 = 101
.line	1038	loadk        r31   k58 ; k58 = 121
.line	1038	loadk        r32   k59 ; k59 = 107
.line	1038	loadk        r33   k60 ; k60 = 109
.line	1038	loadk        r34   k32 ; k32 = 28
.line	1038	loadk        r35   k33 ; k33 = 10
.line	1038	loadk        r36   k27 ; k27 = 156
.line	1038	call          r7    30     0
.line	1038	setlist       r5     0     1
.line	1038	call          r4     2     2
.line	1038	gettabup      r5    u0   k61 ; k61 = "tostring"
.line	1038	move          r6    r2
.line	1038	call          r5     2     2
.line	1038	getupval      r6    u1
.line	1038	loadk         r7   k62 ; k62 = 29
.line	1038	loadk         r8   k63 ; k63 = 127
.line	1038	loadk         r9   k64 ; k64 = 6
.line	1038	loadk        r10   k65 ; k65 = 59
.line	1038	loadk        r11   k66 ; k66 = 234
.line	1038	call          r6     6     2
.line	1038	gettabup      r7    u0   k61 ; k61 = "tostring"
.line	1038	move          r8    r1
.line	1038	call          r7     2     2
.line	1038	concat        r4    r4    r7
.label	l101
.line	1038	call          r3     2     1
.line	1038	self          r3    r0   k67 ; k67 = L"ServerRPC_RequestPul" (truncated)
.line	1038	move          r5    r2
.line	1038	move          r6    r1
.line	1038	call          r3     4     1
.line	1038	return        r0     1
.line	1038	move          r0    r0
.line	1038	move          r0    r0
.line	1038	move          r0    r0
.line	1038	return        r0     1

.function	main/f45

.source	null
.linedefined	1056
.lastlinedefined	1072
.numparams	3
.is_vararg	0
.maxstacksize	57

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	126
.constant	k5	68
.constant	k6	7
.constant	k7	41
.constant	k8	164
.constant	k9	170
.constant	k10	39
.constant	k11	95
.constant	k12	24
.constant	k13	91
.constant	k14	26
.constant	k15	31
.constant	k16	217
.constant	k17	83
.constant	k18	38
.constant	k19	54
.constant	k20	137
.constant	k21	103
.constant	k22	102
.constant	k23	25
.constant	k24	99
.constant	k25	156
.constant	k26	76
.constant	k27	122
.constant	k28	113
.constant	k29	4
.constant	k30	42
.constant	k31	30
.constant	k32	212
.constant	k33	88
.constant	k34	6
.constant	k35	29
.constant	k36	143
.constant	k37	70
.constant	k38	65
.constant	k39	55
.constant	k40	98
.constant	k41	134
.constant	k42	64
.constant	k43	111
.constant	k44	69
.constant	k45	22
.constant	k46	165
.constant	k47	175
.constant	k48	61
.constant	k49	121
.constant	k50	46
.constant	k51	93
.constant	k52	219
.constant	k53	107
.constant	k54	58
.constant	k55	59
.constant	k56	172
.constant	k57	114
.constant	k58	115
.constant	k59	128
.constant	k60	84
.constant	k61	112
.constant	k62	195
.constant	k63	14
.constant	k64	48
.constant	k65	10
.constant	k66	44
.constant	k67	"tostring"
.constant	k68	127
.constant	k69	254
.constant	k70	141
.constant	k71	36
.constant	k72	87
.constant	k73	97
.constant	k74	"Num"
.constant	k75	0
.constant	k76	1
.constant	k77	"Get"
.constant	k78	"slua"
.constant	k79	"Array"
.constant	k80	"UEnums"
.constant	k81	"EPropertyClass"
.constant	k82	"Byte"
.constant	k83	"GetCustomUIContent"
.constant	k84	"Id"
.constant	k85	"Content"
.constant	k86	109
.constant	k87	28
.constant	k88	9
.constant	k89	208
.constant	k90	75
.constant	k91	17
.constant	k92	85
.constant	k93	146
.constant	k94	78
.constant	k95	66
.constant	k96	50
.constant	k97	188
.constant	k98	18
.constant	k99	79
.constant	k100	40
.constant	k101	90
.constant	k102	227
.constant	k103	119
.constant	k104	185
.constant	k105	5
.constant	k106	81
.constant	k107	105
.constant	k108	27
.constant	k109	158
.constant	k110	142
.constant	k111	100
.constant	k112	89
.constant	k113	12
.constant	k114	60
.constant	k115	181
.constant	k116	173
.constant	k117	37
.constant	k118	211
.constant	k119	169
.constant	k120	"ClientRPC_RespondCustomUIDataResumeNode"

.line	1056	gettabup      r3    u0    k0 ; k0 = "print"
.line	1056	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	1056	test          r4     0
.line	1056	jmp            0  l107
.line	1056	gettabup      r4    u0    k2 ; k2 = "table"
.line	1056	gettable      r4    r4    k3 ; k3 = "concat"
.line	1056	newtable      r5     1     0
.line	1056	getupval      r6    u1
.line	1056	loadk         r7    k4 ; k4 = 126
.line	1056	loadk         r8    k5 ; k5 = 68
.line	1056	loadk         r9    k6 ; k6 = 7
.line	1056	loadk        r10    k7 ; k7 = 41
.line	1056	loadk        r11    k8 ; k8 = 164
.line	1056	loadk        r12    k9 ; k9 = 170
.line	1056	loadk        r13   k10 ; k10 = 39
.line	1056	loadk        r14   k11 ; k11 = 95
.line	1056	loadk        r15   k12 ; k12 = 24
.line	1056	loadk        r16   k13 ; k13 = 91
.line	1056	loadk        r17   k14 ; k14 = 26
.line	1056	loadk        r18   k15 ; k15 = 31
.line	1056	loadk        r19   k16 ; k16 = 217
.line	1056	loadk        r20   k17 ; k17 = 83
.line	1056	loadk        r21   k18 ; k18 = 38
.line	1056	loadk        r22   k19 ; k19 = 54
.line	1056	loadk        r23   k20 ; k20 = 137
.line	1056	loadk        r24   k21 ; k21 = 103
.line	1056	loadk        r25   k22 ; k22 = 102
.line	1056	loadk        r26   k23 ; k23 = 25
.line	1056	loadk        r27   k24 ; k24 = 99
.line	1056	loadk        r28   k25 ; k25 = 156
.line	1056	loadk        r29   k26 ; k26 = 76
.line	1056	loadk        r30   k27 ; k27 = 122
.line	1056	loadk        r31   k28 ; k28 = 113
.line	1056	loadk        r32   k29 ; k29 = 4
.line	1056	loadk        r33   k30 ; k30 = 42
.line	1056	loadk        r34   k31 ; k31 = 30
.line	1056	loadk        r35   k32 ; k32 = 212
.line	1056	loadk        r36   k33 ; k33 = 88
.line	1056	loadk        r37   k34 ; k34 = 6
.line	1056	loadk        r38   k35 ; k35 = 29
.line	1056	loadk        r39   k36 ; k36 = 143
.line	1056	loadk        r40   k37 ; k37 = 70
.line	1056	loadk        r41   k38 ; k38 = 65
.line	1056	loadk        r42   k39 ; k39 = 55
.line	1056	loadk        r43   k40 ; k40 = 98
.line	1056	loadk        r44   k41 ; k41 = 134
.line	1056	loadk        r45   k42 ; k42 = 64
.line	1056	loadk        r46   k43 ; k43 = 111
.line	1056	call          r6    41     2
.line	1056	getupval      r7    u1
.line	1056	loadk         r8   k33 ; k33 = 88
.line	1056	loadk         r9   k44 ; k44 = 69
.line	1056	loadk        r10   k45 ; k45 = 22
.line	1056	loadk        r11   k12 ; k12 = 24
.line	1056	loadk        r12   k46 ; k46 = 165
.line	1056	loadk        r13   k47 ; k47 = 175
.line	1056	loadk        r14   k48 ; k48 = 61
.line	1056	loadk        r15   k49 ; k49 = 121
.line	1056	loadk        r16   k50 ; k50 = 46
.line	1056	loadk        r17   k51 ; k51 = 93
.line	1056	loadk        r18   k35 ; k35 = 29
.line	1056	loadk        r19   k29 ; k29 = 4
.line	1056	loadk        r20   k52 ; k52 = 219
.line	1056	loadk        r21   k53 ; k53 = 107
.line	1056	loadk        r22   k54 ; k54 = 58
.line	1056	loadk        r23   k55 ; k55 = 59
.line	1056	loadk        r24   k56 ; k56 = 172
.line	1056	loadk        r25   k57 ; k57 = 114
.line	1056	loadk        r26   k58 ; k58 = 115
.line	1056	loadk        r27   k30 ; k30 = 42
.line	1056	loadk        r28   k44 ; k44 = 69
.line	1056	loadk        r29   k59 ; k59 = 128
.line	1056	loadk        r30   k60 ; k60 = 84
.line	1056	loadk        r31   k21 ; k21 = 103
.line	1056	loadk        r32   k50 ; k50 = 46
.line	1056	loadk        r33   k61 ; k61 = 112
.line	1056	loadk        r34   k45 ; k45 = 22
.line	1056	loadk        r35   k15 ; k15 = 31
.line	1056	loadk        r36   k62 ; k62 = 195
.line	1056	loadk        r37   k63 ; k63 = 14
.line	1056	loadk        r38   k64 ; k64 = 48
.line	1056	loadk        r39   k65 ; k65 = 10
.line	1056	loadk        r40   k56 ; k56 = 172
.line	1056	loadk        r41   k66 ; k66 = 44
.line	1056	call          r7    35     0
.line	1056	setlist       r5     0     1
.line	1056	call          r4     2     2
.line	1056	gettabup      r5    u0   k67 ; k67 = "tostring"
.line	1056	move          r6    r1
.line	1056	call          r5     2     2
.line	1056	getupval      r6    u1
.line	1056	loadk         r7   k35 ; k35 = 29
.line	1056	loadk         r8   k68 ; k68 = 127
.line	1056	loadk         r9   k34 ; k34 = 6
.line	1056	loadk        r10   k55 ; k55 = 59
.line	1056	loadk        r11   k69 ; k69 = 254
.line	1056	loadk        r12   k70 ; k70 = 141
.line	1056	loadk        r13   k71 ; k71 = 36
.line	1056	loadk        r14   k72 ; k72 = 87
.line	1056	loadk        r15   k73 ; k73 = 97
.line	1056	call          r6    10     2
.line	1056	gettabup      r7    u0   k67 ; k67 = "tostring"
.line	1056	self          r8    r2   k74 ; k74 = "Num"
.line	1056	call          r8     2     0
.line	1056	call          r7     0     2
.line	1056	concat        r4    r4    r7
.label	l107
.line	1056	call          r3     2     1
.line	1056	newtable      r3     0     0
.line	1056	self          r4    r2   k74 ; k74 = "Num"
.line	1056	call          r4     2     2
.line	1056	loadk         r5   k75 ; k75 = 0
.line	1056	sub           r6    r4   k76 ; k76 = 1
.line	1056	loadk         r7   k76 ; k76 = 1
.line	1056	move          r0    r0
.line	1056	self          r9    r2   k77 ; k77 = "Get"
.line	1056	move         r11    r8
.line	1056	call          r9     3     2
.line	1056	gettabup     r10    u0   k78 ; k78 = "slua"
.line	1056	gettable     r10   r10   k79 ; k79 = "Array"
.line	1056	gettabup     r11    u0   k80 ; k80 = "UEnums"
.line	1056	gettable     r11   r11   k81 ; k81 = "EPropertyClass"
.line	1056	gettable     r11   r11   k82 ; k82 = "Byte"
.line	1056	call         r10     2     2
.line	1056	loadbool     r11     0     0
.line	1056	self         r12    r0   k83 ; k83 = "GetCustomUIContent"
.line	1056	gettabup     r14    u0   k67 ; k67 = "tostring"
.line	1056	move         r15    r9
.line	1056	call         r14     2     2
.line	1056	move         r15   r10
.line	1056	call         r12     4     3
.line	1056	move         r10   r13
.line	1056	move         r11   r12
.line	1056	test         r11     0
.line	1056	jmp            0  l142
.line	1056	len          r12    r3
.line	1056	add          r12   r12   k76 ; k76 = 1
.line	1056	newtable     r13     0     2
.line	1056	settable     r13   k84    r9 ; k84 = "Id"
.line	1056	settable     r13   k85   r10 ; k85 = "Content"
.line	1056	settable      r3   r12   r13
.line	1056	jmp            0  l260
.label	l142
.line	1056	gettabup     r12    u0    k0 ; k0 = "print"
.line	1056	gettabup     r13    u0    k1 ; k1 = "bWriteLog"
.line	1056	test         r13     0
.line	1056	jmp            0  l259
.line	1056	gettabup     r13    u0    k2 ; k2 = "table"
.line	1056	gettable     r13   r13    k3 ; k3 = "concat"
.line	1056	newtable     r14     2     0
.line	1056	getupval     r15    u1
.line	1056	loadk        r16    k4 ; k4 = 126
.line	1056	loadk        r17    k5 ; k5 = 68
.line	1056	loadk        r18    k6 ; k6 = 7
.line	1056	loadk        r19    k7 ; k7 = 41
.line	1056	loadk        r20    k8 ; k8 = 164
.line	1056	loadk        r21    k9 ; k9 = 170
.line	1056	loadk        r22   k10 ; k10 = 39
.line	1056	loadk        r23   k11 ; k11 = 95
.line	1056	loadk        r24   k12 ; k12 = 24
.line	1056	loadk        r25   k13 ; k13 = 91
.line	1056	loadk        r26   k14 ; k14 = 26
.line	1056	loadk        r27   k15 ; k15 = 31
.line	1056	loadk        r28   k16 ; k16 = 217
.line	1056	loadk        r29   k17 ; k17 = 83
.line	1056	loadk        r30   k18 ; k18 = 38
.line	1056	loadk        r31   k19 ; k19 = 54
.line	1056	loadk        r32   k20 ; k20 = 137
.line	1056	loadk        r33   k21 ; k21 = 103
.line	1056	loadk        r34   k22 ; k22 = 102
.line	1056	loadk        r35   k23 ; k23 = 25
.line	1056	loadk        r36   k24 ; k24 = 99
.line	1056	loadk        r37   k25 ; k25 = 156
.line	1056	loadk        r38   k26 ; k26 = 76
.line	1056	loadk        r39   k27 ; k27 = 122
.line	1056	loadk        r40   k28 ; k28 = 113
.line	1056	loadk        r41   k86 ; k86 = 109
.line	1056	loadk        r42   k87 ; k87 = 28
.line	1056	loadk        r43   k88 ; k88 = 9
.line	1056	loadk        r44   k89 ; k89 = 208
.line	1056	loadk        r45   k90 ; k90 = 75
.line	1056	loadk        r46   k91 ; k91 = 17
.line	1056	loadk        r47   k48 ; k48 = 61
.line	1056	loadk        r48   k70 ; k70 = 141
.line	1056	loadk        r49   k92 ; k92 = 85
.line	1056	loadk        r50   k51 ; k51 = 93
.line	1056	loadk        r51   k54 ; k54 = 58
.line	1056	loadk        r52   k92 ; k92 = 85
.line	1056	loadk        r53   k93 ; k93 = 146
.line	1056	loadk        r54    k5 ; k5 = 68
.line	1056	loadk        r55   k68 ; k68 = 127
.line	1056	call         r15    41     2
.line	1056	getupval     r16    u1
.line	1056	loadk        r17   k94 ; k94 = 78
.line	1056	loadk        r18   k95 ; k95 = 66
.line	1056	loadk        r19   k96 ; k96 = 50
.line	1056	loadk        r20   k48 ; k48 = 61
.line	1056	loadk        r21   k97 ; k97 = 188
.line	1056	loadk        r22   k47 ; k47 = 175
.line	1056	loadk        r23   k98 ; k98 = 18
.line	1056	loadk        r24   k99 ; k99 = 79
.line	1056	loadk        r25  k100 ; k100 = 40
.line	1056	loadk        r26  k101 ; k101 = 90
.line	1056	loadk        r27   k34 ; k34 = 6
.line	1056	loadk        r28   k34 ; k34 = 6
.line	1056	loadk        r29  k102 ; k102 = 227
.line	1056	loadk        r30  k103 ; k103 = 119
.line	1056	loadk        r31   k39 ; k39 = 55
.line	1056	loadk        r32   k31 ; k31 = 30
.line	1056	loadk        r33  k104 ; k104 = 185
.line	1056	loadk        r34   k21 ; k21 = 103
.line	1056	loadk        r35   k42 ; k42 = 64
.line	1056	loadk        r36   k35 ; k35 = 29
.line	1056	loadk        r37   k17 ; k17 = 83
.line	1056	loadk        r38   k41 ; k41 = 134
.line	1056	loadk        r39   k26 ; k26 = 76
.line	1056	loadk        r40   k43 ; k43 = 111
.line	1056	loadk        r41  k105 ; k105 = 5
.line	1056	loadk        r42  k106 ; k106 = 81
.line	1056	loadk        r43   k35 ; k35 = 29
.line	1056	loadk        r44   k31 ; k31 = 30
.line	1056	loadk        r45   k41 ; k41 = 134
.line	1056	loadk        r46  k107 ; k107 = 105
.line	1056	loadk        r47   k34 ; k34 = 6
.line	1056	loadk        r48  k108 ; k108 = 27
.line	1056	loadk        r49  k109 ; k109 = 158
.line	1056	loadk        r50   k24 ; k24 = 99
.line	1056	loadk        r51   k28 ; k28 = 113
.line	1056	loadk        r52   k87 ; k87 = 28
.line	1056	loadk        r53   k11 ; k11 = 95
.line	1056	loadk        r54  k110 ; k110 = 142
.line	1056	loadk        r55  k111 ; k111 = 100
.line	1056	loadk        r56   k17 ; k17 = 83
.line	1056	call         r16    41     2
.line	1056	getupval     r17    u1
.line	1056	loadk        r18    k4 ; k4 = 126
.line	1056	loadk        r19  k112 ; k112 = 89
.line	1056	loadk        r20  k113 ; k113 = 12
.line	1056	loadk        r21  k114 ; k114 = 60
.line	1056	loadk        r22  k115 ; k115 = 181
.line	1056	loadk        r23  k116 ; k116 = 173
.line	1056	loadk        r24  k117 ; k117 = 37
.line	1056	loadk        r25   k14 ; k14 = 26
.line	1056	loadk        r26   k48 ; k48 = 61
.line	1056	loadk        r27   k99 ; k99 = 79
.line	1056	loadk        r28   k75 ; k75 = 0
.line	1056	loadk        r29    k6 ; k6 = 7
.line	1056	loadk        r30  k118 ; k118 = 211
.line	1056	loadk        r31  k101 ; k101 = 90
.line	1056	loadk        r32   k17 ; k17 = 83
.line	1056	loadk        r33   k19 ; k19 = 54
.line	1056	loadk        r34  k119 ; k119 = 169
.line	1056	loadk        r35  k114 ; k114 = 60
.line	1056	call         r17    19     0
.line	1056	setlist      r14     0     1
.line	1056	call         r13     2     2
.line	1056	gettabup     r14    u0   k67 ; k67 = "tostring"
.line	1056	move         r15    r9
.line	1056	call         r14     2     2
.line	1056	concat       r13   r13   r14
.label	l259
.line	1056	call         r12     2     1
.label	l260
.line	1056	move          r0    r0
.line	1056	self          r5    r0  k120 ; k120 = "ClientRPC_RespondCus" (truncated)
.line	1056	move          r7    r1
.line	1056	move          r8    r3
.line	1056	call          r5     4     1
.line	1056	return        r0     1
.line	1056	gettabup      r2    u1  k115 ; k115 = 181
.line	1056	return        r0     1

.function	main/f46

.source	null
.linedefined	1078
.lastlinedefined	1080
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	126
.constant	k5	68
.constant	k6	7
.constant	k7	41
.constant	k8	164
.constant	k9	170
.constant	k10	39
.constant	k11	95
.constant	k12	24
.constant	k13	91
.constant	k14	26
.constant	k15	31
.constant	k16	217
.constant	k17	83
.constant	k18	38
.constant	k19	54
.constant	k20	137
.constant	k21	103
.constant	k22	102
.constant	k23	25
.constant	k24	99
.constant	k25	156
.constant	k26	76
.constant	k27	122
.constant	k28	113
.constant	k29	125
.constant	k30	21
.constant	k31	18
.constant	k32	195
.constant	k33	64
.constant	k34	23
.constant	k35	61
.constant	k36	141
.constant	k37	85
.constant	k38	93
.constant	k39	58
.constant	k40	144
.constant	k41	65
.constant	k42	117
.constant	k43	82
.constant	k44	33
.constant	k45	163
.constant	k46	183
.constant	k47	62
.constant	k48	87
.constant	k49	14
.constant	k50	45
.constant	k51	10
.constant	k52	194
.constant	k53	190
.constant	k54	115
.constant	k55	127
.constant	k56	29
.constant	k57	110
.constant	k58	69
.constant	k59	111
.constant	k60	20
.constant	k61	108
.constant	k62	28
.constant	k63	8
.constant	k64	211
.constant	k65	66
.constant	k66	79
.constant	k67	158
.constant	k68	121
.constant	k69	92
.constant	k70	134
.constant	k71	89
.constant	k72	12
.constant	k73	"tostring"

.line	1078	gettabup      r2    u0    k0 ; k0 = "print"
.line	1078	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1078	test          r3     0
.line	1078	jmp            0  l102
.line	1078	gettabup      r3    u0    k2 ; k2 = "table"
.line	1078	gettable      r3    r3    k3 ; k3 = "concat"
.line	1078	newtable      r4     2     0
.line	1078	getupval      r5    u1
.line	1078	loadk         r6    k4 ; k4 = 126
.line	1078	loadk         r7    k5 ; k5 = 68
.line	1078	loadk         r8    k6 ; k6 = 7
.line	1078	loadk         r9    k7 ; k7 = 41
.line	1078	loadk        r10    k8 ; k8 = 164
.line	1078	loadk        r11    k9 ; k9 = 170
.line	1078	loadk        r12   k10 ; k10 = 39
.line	1078	loadk        r13   k11 ; k11 = 95
.line	1078	loadk        r14   k12 ; k12 = 24
.line	1078	loadk        r15   k13 ; k13 = 91
.line	1078	loadk        r16   k14 ; k14 = 26
.line	1078	loadk        r17   k15 ; k15 = 31
.line	1078	loadk        r18   k16 ; k16 = 217
.line	1078	loadk        r19   k17 ; k17 = 83
.line	1078	loadk        r20   k18 ; k18 = 38
.line	1078	loadk        r21   k19 ; k19 = 54
.line	1078	loadk        r22   k20 ; k20 = 137
.line	1078	loadk        r23   k21 ; k21 = 103
.line	1078	loadk        r24   k22 ; k22 = 102
.line	1078	loadk        r25   k23 ; k23 = 25
.line	1078	loadk        r26   k24 ; k24 = 99
.line	1078	loadk        r27   k25 ; k25 = 156
.line	1078	loadk        r28   k26 ; k26 = 76
.line	1078	loadk        r29   k27 ; k27 = 122
.line	1078	loadk        r30   k28 ; k28 = 113
.line	1078	loadk        r31   k29 ; k29 = 125
.line	1078	loadk        r32   k30 ; k30 = 21
.line	1078	loadk        r33   k31 ; k31 = 18
.line	1078	loadk        r34   k32 ; k32 = 195
.line	1078	loadk        r35   k33 ; k33 = 64
.line	1078	loadk        r36   k34 ; k34 = 23
.line	1078	loadk        r37   k35 ; k35 = 61
.line	1078	loadk        r38   k36 ; k36 = 141
.line	1078	loadk        r39   k37 ; k37 = 85
.line	1078	loadk        r40   k38 ; k38 = 93
.line	1078	loadk        r41   k39 ; k39 = 58
.line	1078	loadk        r42   k37 ; k37 = 85
.line	1078	loadk        r43   k40 ; k40 = 144
.line	1078	loadk        r44   k41 ; k41 = 65
.line	1078	loadk        r45   k42 ; k42 = 117
.line	1078	call          r5    41     2
.line	1078	getupval      r6    u1
.line	1078	loadk         r7   k17 ; k17 = 83
.line	1078	loadk         r8   k43 ; k43 = 82
.line	1078	loadk         r9   k44 ; k44 = 33
.line	1078	loadk        r10   k35 ; k35 = 61
.line	1078	loadk        r11   k45 ; k45 = 163
.line	1078	loadk        r12   k46 ; k46 = 183
.line	1078	loadk        r13   k47 ; k47 = 62
.line	1078	loadk        r14   k48 ; k48 = 87
.line	1078	loadk        r15   k49 ; k49 = 14
.line	1078	loadk        r16   k21 ; k21 = 103
.line	1078	loadk        r17   k50 ; k50 = 45
.line	1078	loadk        r18   k51 ; k51 = 10
.line	1078	loadk        r19   k52 ; k52 = 194
.line	1078	loadk        r20   k11 ; k11 = 95
.line	1078	loadk        r21   k44 ; k44 = 33
.line	1078	loadk        r22   k14 ; k14 = 26
.line	1078	loadk        r23   k53 ; k53 = 190
.line	1078	loadk        r24   k54 ; k54 = 115
.line	1078	loadk        r25   k55 ; k55 = 127
.line	1078	loadk        r26   k56 ; k56 = 29
.line	1078	loadk        r27   k57 ; k57 = 110
.line	1078	loadk        r28   k25 ; k25 = 156
.line	1078	loadk        r29   k58 ; k58 = 69
.line	1078	loadk        r30   k59 ; k59 = 111
.line	1078	loadk        r31   k60 ; k60 = 20
.line	1078	loadk        r32   k61 ; k61 = 108
.line	1078	loadk        r33   k62 ; k62 = 28
.line	1078	loadk        r34   k63 ; k63 = 8
.line	1078	loadk        r35   k64 ; k64 = 211
.line	1078	loadk        r36   k65 ; k65 = 66
.line	1078	loadk        r37   k34 ; k34 = 23
.line	1078	loadk        r38   k66 ; k66 = 79
.line	1078	loadk        r39   k67 ; k67 = 158
.line	1078	loadk        r40   k68 ; k68 = 121
.line	1078	loadk        r41   k59 ; k59 = 111
.line	1078	loadk        r42   k12 ; k12 = 24
.line	1078	loadk        r43   k69 ; k69 = 92
.line	1078	loadk        r44   k70 ; k70 = 134
.line	1078	loadk        r45   k58 ; k58 = 69
.line	1078	loadk        r46   k55 ; k55 = 127
.line	1078	call          r6    41     2
.line	1078	getupval      r7    u1
.line	1078	loadk         r8   k71 ; k71 = 89
.line	1078	loadk         r9   k72 ; k72 = 12
.line	1078	call          r7     3     0
.line	1078	setlist       r4     0     1
.line	1078	call          r3     2     2
.line	1078	gettabup      r4    u0   k73 ; k73 = "tostring"
.line	1078	move          r5    r1
.line	1078	call          r4     2     2
.line	1078	concat        r3    r3    r4
.label	l102
.line	1078	call          r2     2     1
.line	1078	return        r0     1
.line	1078	move          r0    r0
.line	1078	return        r0     1

.function	main/f47

.source	null
.linedefined	1082
.lastlinedefined	1103
.numparams	3
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	126
.constant	k5	68
.constant	k6	7
.constant	k7	41
.constant	k8	164
.constant	k9	170
.constant	k10	39
.constant	k11	95
.constant	k12	24
.constant	k13	91
.constant	k14	26
.constant	k15	31
.constant	k16	217
.constant	k17	83
.constant	k18	38
.constant	k19	54
.constant	k20	137
.constant	k21	103
.constant	k22	102
.constant	k23	25
.constant	k24	99
.constant	k25	156
.constant	k26	76
.constant	k27	122
.constant	k28	113
.constant	k29	4
.constant	k30	58
.constant	k31	23
.constant	k32	207
.constant	k33	75
.constant	k34	13
.constant	k35	27
.constant	k36	143
.constant	k37	70
.constant	k38	65
.constant	k39	55
.constant	k40	98
.constant	k41	134
.constant	k42	66
.constant	k43	106
.constant	k44	82
.constant	k45	88
.constant	k46	6
.constant	k47	11
.constant	k48	165
.constant	k49	176
.constant	k50	37
.constant	k51	85
.constant	k52	123
.constant	k53	32
.constant	k54	47
.constant	k55	215
.constant	k56	74
.constant	k57	18
.constant	k58	45
.constant	k59	168
.constant	k60	117
.constant	k61	21
.constant	k62	69
.constant	k63	189
.constant	k64	78
.constant	k65	110
.constant	k66	46
.constant	k67	30
.constant	k68	42
.constant	k69	20
.constant	k70	"tostring"
.constant	k71	"RespondResumeNodeTagMap"
.constant	k72	true
.constant	k73	"Client"
.constant	k74	"_bResumeResponseReplacing"
.constant	k75	"pcall"
.constant	k76	false
.constant	k77	125
.constant	k78	195
.constant	k79	64
.constant	k80	61
.constant	k81	141
.constant	k82	93
.constant	k83	144
.constant	k84	33
.constant	k85	163
.constant	k86	183
.constant	k87	62
.constant	k88	87
.constant	k89	14
.constant	k90	10
.constant	k91	194
.constant	k92	190
.constant	k93	115
.constant	k94	127
.constant	k95	29
.constant	k96	111
.constant	k97	107
.constant	k98	9
.constant	k99	201
.constant	k100	92
.constant	k101	89
.constant	k102	"ipairs"
.constant	k103	"SetCustomUIDataById"
.constant	k104	"Id"
.constant	k105	"Content"

.line	1082	gettabup      r3    u0    k0 ; k0 = "print"
.line	1082	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	1082	test          r4     0
.line	1082	jmp            0   l88
.line	1082	gettabup      r4    u0    k2 ; k2 = "table"
.line	1082	gettable      r4    r4    k3 ; k3 = "concat"
.line	1082	newtable      r5     1     0
.line	1082	getupval      r6    u1
.line	1082	loadk         r7    k4 ; k4 = 126
.line	1082	loadk         r8    k5 ; k5 = 68
.line	1082	loadk         r9    k6 ; k6 = 7
.line	1082	loadk        r10    k7 ; k7 = 41
.line	1082	loadk        r11    k8 ; k8 = 164
.line	1082	loadk        r12    k9 ; k9 = 170
.line	1082	loadk        r13   k10 ; k10 = 39
.line	1082	loadk        r14   k11 ; k11 = 95
.line	1082	loadk        r15   k12 ; k12 = 24
.line	1082	loadk        r16   k13 ; k13 = 91
.line	1082	loadk        r17   k14 ; k14 = 26
.line	1082	loadk        r18   k15 ; k15 = 31
.line	1082	loadk        r19   k16 ; k16 = 217
.line	1082	loadk        r20   k17 ; k17 = 83
.line	1082	loadk        r21   k18 ; k18 = 38
.line	1082	loadk        r22   k19 ; k19 = 54
.line	1082	loadk        r23   k20 ; k20 = 137
.line	1082	loadk        r24   k21 ; k21 = 103
.line	1082	loadk        r25   k22 ; k22 = 102
.line	1082	loadk        r26   k23 ; k23 = 25
.line	1082	loadk        r27   k24 ; k24 = 99
.line	1082	loadk        r28   k25 ; k25 = 156
.line	1082	loadk        r29   k26 ; k26 = 76
.line	1082	loadk        r30   k27 ; k27 = 122
.line	1082	loadk        r31   k28 ; k28 = 113
.line	1082	loadk        r32   k29 ; k29 = 4
.line	1082	loadk        r33   k30 ; k30 = 58
.line	1082	loadk        r34   k31 ; k31 = 23
.line	1082	loadk        r35   k32 ; k32 = 207
.line	1082	loadk        r36   k33 ; k33 = 75
.line	1082	loadk        r37   k34 ; k34 = 13
.line	1082	loadk        r38   k35 ; k35 = 27
.line	1082	loadk        r39   k36 ; k36 = 143
.line	1082	loadk        r40   k37 ; k37 = 70
.line	1082	loadk        r41   k38 ; k38 = 65
.line	1082	loadk        r42   k39 ; k39 = 55
.line	1082	loadk        r43   k40 ; k40 = 98
.line	1082	loadk        r44   k41 ; k41 = 134
.line	1082	loadk        r45   k42 ; k42 = 66
.line	1082	loadk        r46   k43 ; k43 = 106
.line	1082	call          r6    41     2
.line	1082	getupval      r7    u1
.line	1082	loadk         r8   k44 ; k44 = 82
.line	1082	loadk         r9   k45 ; k45 = 88
.line	1082	loadk        r10   k46 ; k46 = 6
.line	1082	loadk        r11   k47 ; k47 = 11
.line	1082	loadk        r12   k48 ; k48 = 165
.line	1082	loadk        r13   k49 ; k49 = 176
.line	1082	loadk        r14   k50 ; k50 = 37
.line	1082	loadk        r15   k51 ; k51 = 85
.line	1082	loadk        r16   k19 ; k19 = 54
.line	1082	loadk        r17   k52 ; k52 = 123
.line	1082	loadk        r18   k53 ; k53 = 32
.line	1082	loadk        r19   k54 ; k54 = 47
.line	1082	loadk        r20   k55 ; k55 = 215
.line	1082	loadk        r21   k56 ; k56 = 74
.line	1082	loadk        r22   k57 ; k57 = 18
.line	1082	loadk        r23   k58 ; k58 = 45
.line	1082	loadk        r24   k59 ; k59 = 168
.line	1082	loadk        r25   k60 ; k60 = 117
.line	1082	loadk        r26   k21 ; k21 = 103
.line	1082	loadk        r27   k61 ; k61 = 21
.line	1082	loadk        r28   k62 ; k62 = 69
.line	1082	loadk        r29   k63 ; k63 = 189
.line	1082	loadk        r30   k64 ; k64 = 78
.line	1082	loadk        r31   k65 ; k65 = 110
.line	1082	loadk        r32   k66 ; k66 = 46
.line	1082	loadk        r33   k67 ; k67 = 30
.line	1082	loadk        r34   k68 ; k68 = 42
.line	1082	loadk        r35   k67 ; k67 = 30
.line	1082	loadk        r36   k55 ; k55 = 215
.line	1082	loadk        r37   k69 ; k69 = 20
.line	1082	call          r7    31     0
.line	1082	setlist       r5     0     1
.line	1082	call          r4     2     2
.line	1082	gettabup      r5    u0   k70 ; k70 = "tostring"
.line	1082	move          r6    r1
.line	1082	call          r5     2     2
.line	1082	concat        r4    r4    r5
.label	l88
.line	1082	call          r3     2     1
.line	1082	gettable      r3    r0   k71 ; k71 = "RespondResumeNodeTag" (truncated)
.line	1082	settable      r3    r1   k72 ; k72 = true
.line	1082	test          r2     0
.line	1082	jmp            0  l200
.line	1082	gettabup      r3    u0   k73 ; k73 = "Client"
.line	1082	test          r3     0
.line	1082	jmp            0  l190
.line	1082	settable      r0   k74   k72 ; k72 = true
.line	1082	gettabup      r3    u0   k75 ; k75 = "pcall"
.line	1082	closure       r4    f0
.line	1082	call          r3     2     3
.line	1082	settable      r0   k74   k76 ; k76 = false
.line	1082	test          r3     1
.line	1082	jmp            0  l200
.line	1082	gettabup      r5    u0    k0 ; k0 = "print"
.line	1082	gettabup      r6    u0    k2 ; k2 = "table"
.line	1082	gettable      r6    r6    k3 ; k3 = "concat"
.line	1082	newtable      r7     1     0
.line	1082	getupval      r8    u1
.line	1082	loadk         r9    k4 ; k4 = 126
.line	1082	loadk        r10    k5 ; k5 = 68
.line	1082	loadk        r11    k6 ; k6 = 7
.line	1082	loadk        r12    k7 ; k7 = 41
.line	1082	loadk        r13    k8 ; k8 = 164
.line	1082	loadk        r14    k9 ; k9 = 170
.line	1082	loadk        r15   k10 ; k10 = 39
.line	1082	loadk        r16   k11 ; k11 = 95
.line	1082	loadk        r17   k12 ; k12 = 24
.line	1082	loadk        r18   k13 ; k13 = 91
.line	1082	loadk        r19   k14 ; k14 = 26
.line	1082	loadk        r20   k15 ; k15 = 31
.line	1082	loadk        r21   k16 ; k16 = 217
.line	1082	loadk        r22   k17 ; k17 = 83
.line	1082	loadk        r23   k18 ; k18 = 38
.line	1082	loadk        r24   k19 ; k19 = 54
.line	1082	loadk        r25   k20 ; k20 = 137
.line	1082	loadk        r26   k21 ; k21 = 103
.line	1082	loadk        r27   k22 ; k22 = 102
.line	1082	loadk        r28   k23 ; k23 = 25
.line	1082	loadk        r29   k24 ; k24 = 99
.line	1082	loadk        r30   k25 ; k25 = 156
.line	1082	loadk        r31   k26 ; k26 = 76
.line	1082	loadk        r32   k27 ; k27 = 122
.line	1082	loadk        r33   k28 ; k28 = 113
.line	1082	loadk        r34   k77 ; k77 = 125
.line	1082	loadk        r35   k61 ; k61 = 21
.line	1082	loadk        r36   k57 ; k57 = 18
.line	1082	loadk        r37   k78 ; k78 = 195
.line	1082	loadk        r38   k79 ; k79 = 64
.line	1082	loadk        r39   k31 ; k31 = 23
.line	1082	loadk        r40   k80 ; k80 = 61
.line	1082	loadk        r41   k81 ; k81 = 141
.line	1082	loadk        r42   k51 ; k51 = 85
.line	1082	loadk        r43   k82 ; k82 = 93
.line	1082	loadk        r44   k30 ; k30 = 58
.line	1082	loadk        r45   k51 ; k51 = 85
.line	1082	loadk        r46   k83 ; k83 = 144
.line	1082	loadk        r47   k38 ; k38 = 65
.line	1082	loadk        r48   k60 ; k60 = 117
.line	1082	call          r8    41     2
.line	1082	getupval      r9    u1
.line	1082	loadk        r10   k17 ; k17 = 83
.line	1082	loadk        r11   k44 ; k44 = 82
.line	1082	loadk        r12   k84 ; k84 = 33
.line	1082	loadk        r13   k80 ; k80 = 61
.line	1082	loadk        r14   k85 ; k85 = 163
.line	1082	loadk        r15   k86 ; k86 = 183
.line	1082	loadk        r16   k87 ; k87 = 62
.line	1082	loadk        r17   k88 ; k88 = 87
.line	1082	loadk        r18   k89 ; k89 = 14
.line	1082	loadk        r19   k21 ; k21 = 103
.line	1082	loadk        r20   k58 ; k58 = 45
.line	1082	loadk        r21   k90 ; k90 = 10
.line	1082	loadk        r22   k91 ; k91 = 194
.line	1082	loadk        r23   k11 ; k11 = 95
.line	1082	loadk        r24   k84 ; k84 = 33
.line	1082	loadk        r25   k14 ; k14 = 26
.line	1082	loadk        r26   k92 ; k92 = 190
.line	1082	loadk        r27   k93 ; k93 = 115
.line	1082	loadk        r28   k94 ; k94 = 127
.line	1082	loadk        r29   k95 ; k95 = 29
.line	1082	loadk        r30   k65 ; k65 = 110
.line	1082	loadk        r31   k25 ; k25 = 156
.line	1082	loadk        r32   k62 ; k62 = 69
.line	1082	loadk        r33   k96 ; k96 = 111
.line	1082	loadk        r34   k97 ; k97 = 107
.line	1082	loadk        r35   k13 ; k13 = 91
.line	1082	loadk        r36   k47 ; k47 = 11
.line	1082	loadk        r37   k98 ; k98 = 9
.line	1082	loadk        r38   k99 ; k99 = 201
.line	1082	loadk        r39  k100 ; k100 = 92
.line	1082	loadk        r40  k101 ; k101 = 89
.line	1082	call          r9    32     0
.line	1082	setlist       r7     0     1
.line	1082	call          r6     2     2
.line	1082	gettabup      r7    u0   k70 ; k70 = "tostring"
.line	1082	move          r8    r4
.line	1082	call          r7     2     2
.line	1082	concat        r6    r6    r7
.line	1082	call          r5     2     1
.line	1082	jmp            0  l200
.label	l190
.line	1082	gettabup      r3    u0  k102 ; k102 = "ipairs"
.line	1082	move          r4    r2
.line	1082	call          r3     2     4
.line	1082	jmp            0  l198
.line	1082	self          r8    r0  k103 ; k103 = "SetCustomUIDataById"
.line	1082	gettable     r10    r7  k104 ; k104 = "Id"
.line	1082	gettable     r11    r7  k105 ; k105 = "Content"
.line	1082	call          r8     4     1
.label	l198
.line	1082	move          r0    r0
.line	1082	move          r0    r0
.label	l200
.line	1082	return        r0     1
.line	1082	move          r0    r0
.line	1082	move          r0    r0
.line	1082	move          r0    r0
.line	1082	move          r0    r0
.line	1082	return        r0     1

.function	main/f47/f0

.source	null
.linedefined	1088
.lastlinedefined	1092
.numparams	0
.is_vararg	0
.maxstacksize	9

.upvalue	"_ENV"	0	false
.upvalue	"U1"	2	true
.upvalue	"U2"	0	true

.constant	k0	"ipairs"
.constant	k1	"SetCustomUIDataById"
.constant	k2	"Id"
.constant	k3	"Content"

.line	1088	gettabup      r0    u0    k0 ; k0 = "ipairs"
.line	1088	getupval      r1    u1
.line	1088	call          r0     2     4
.line	1088	jmp            0   l10
.line	1088	getupval      r5    u2
.line	1088	self          r5    r5    k1 ; k1 = "SetCustomUIDataById"
.line	1088	gettable      r7    r4    k2 ; k2 = "Id"
.line	1088	gettable      r8    r4    k3 ; k3 = "Content"
.line	1088	call          r5     4     1
.label	l10
.line	1088	move          r0    r0
.line	1088	move          r0    r0
.line	1088	return        r0     1
.line	1088	move          r0    r0
.line	1088	move          r0    r0
.line	1088	move          r0    r0
.line	1088	return        r0     1

.function	main/f48

.source	null
.linedefined	1105
.lastlinedefined	1127
.numparams	1
.is_vararg	0
.maxstacksize	53

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	126
.constant	k5	68
.constant	k6	7
.constant	k7	41
.constant	k8	164
.constant	k9	170
.constant	k10	39
.constant	k11	95
.constant	k12	24
.constant	k13	91
.constant	k14	26
.constant	k15	31
.constant	k16	217
.constant	k17	83
.constant	k18	38
.constant	k19	54
.constant	k20	137
.constant	k21	103
.constant	k22	102
.constant	k23	25
.constant	k24	99
.constant	k25	156
.constant	k26	76
.constant	k27	122
.constant	k28	113
.constant	k29	125
.constant	k30	11
.constant	k31	30
.constant	k32	199
.constant	k33	90
.constant	k34	10
.constant	k35	184
.constant	k36	65
.constant	k37	107
.constant	k38	12
.constant	k39	87
.constant	k40	134
.constant	k41	69
.constant	k42	85
.constant	k43	92
.constant	k44	43
.constant	k45	176
.constant	k46	"GetLoadManager"
.constant	k47	"bNewCustomUI"
.constant	k48	118
.constant	k49	52
.constant	k50	79
.constant	k51	13
.constant	k52	209
.constant	k53	16
.constant	k54	191
.constant	k55	112
.constant	k56	132
.constant	k57	98
.constant	k58	127
.constant	k59	56
.constant	k60	74
.constant	k61	22
.constant	k62	243
.constant	k63	67
.constant	k64	6
.constant	k65	174
.constant	k66	108
.constant	k67	1
.constant	k68	"pairs"
.constant	k69	"CustomUIData"
.constant	k70	"GetCDOInstanceIDOfInstance"
.constant	k71	"RuntimeToCDO"
.constant	k72	"tostring"
.constant	k73	"CustomUIObject"
.constant	k74	"_CreateCustomUILuaObject"
.constant	k75	105
.constant	k76	46
.constant	k77	77
.constant	k78	14
.constant	k79	197
.constant	k80	"GetOwner"
.constant	k81	"AddRuntimeInstanceData"

.line	1105	gettabup      r1    u0    k0 ; k0 = "print"
.line	1105	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1105	test          r2     0
.line	1105	jmp            0   l60
.line	1105	gettabup      r2    u0    k2 ; k2 = "table"
.line	1105	gettable      r2    r2    k3 ; k3 = "concat"
.line	1105	newtable      r3     1     0
.line	1105	getupval      r4    u1
.line	1105	loadk         r5    k4 ; k4 = 126
.line	1105	loadk         r6    k5 ; k5 = 68
.line	1105	loadk         r7    k6 ; k6 = 7
.line	1105	loadk         r8    k7 ; k7 = 41
.line	1105	loadk         r9    k8 ; k8 = 164
.line	1105	loadk        r10    k9 ; k9 = 170
.line	1105	loadk        r11   k10 ; k10 = 39
.line	1105	loadk        r12   k11 ; k11 = 95
.line	1105	loadk        r13   k12 ; k12 = 24
.line	1105	loadk        r14   k13 ; k13 = 91
.line	1105	loadk        r15   k14 ; k14 = 26
.line	1105	loadk        r16   k15 ; k15 = 31
.line	1105	loadk        r17   k16 ; k16 = 217
.line	1105	loadk        r18   k17 ; k17 = 83
.line	1105	loadk        r19   k18 ; k18 = 38
.line	1105	loadk        r20   k19 ; k19 = 54
.line	1105	loadk        r21   k20 ; k20 = 137
.line	1105	loadk        r22   k21 ; k21 = 103
.line	1105	loadk        r23   k22 ; k22 = 102
.line	1105	loadk        r24   k23 ; k23 = 25
.line	1105	loadk        r25   k24 ; k24 = 99
.line	1105	loadk        r26   k25 ; k25 = 156
.line	1105	loadk        r27   k26 ; k26 = 76
.line	1105	loadk        r28   k27 ; k27 = 122
.line	1105	loadk        r29   k28 ; k28 = 113
.line	1105	loadk        r30   k29 ; k29 = 125
.line	1105	loadk        r31   k30 ; k30 = 11
.line	1105	loadk        r32   k31 ; k31 = 30
.line	1105	loadk        r33   k32 ; k32 = 199
.line	1105	loadk        r34   k33 ; k33 = 90
.line	1105	loadk        r35   k34 ; k34 = 10
.line	1105	loadk        r36   k23 ; k23 = 25
.line	1105	loadk        r37   k35 ; k35 = 184
.line	1105	loadk        r38   k36 ; k36 = 65
.line	1105	loadk        r39   k37 ; k37 = 107
.line	1105	loadk        r40   k38 ; k38 = 12
.line	1105	loadk        r41   k39 ; k39 = 87
.line	1105	loadk        r42   k40 ; k40 = 134
.line	1105	loadk        r43   k41 ; k41 = 69
.line	1105	loadk        r44   k42 ; k42 = 85
.line	1105	call          r4    41     2
.line	1105	getupval      r5    u1
.line	1105	loadk         r6   k11 ; k11 = 95
.line	1105	loadk         r7   k43 ; k43 = 92
.line	1105	loadk         r8    k6 ; k6 = 7
.line	1105	loadk         r9   k44 ; k44 = 43
.line	1105	loadk        r10    k8 ; k8 = 164
.line	1105	loadk        r11   k45 ; k45 = 176
.line	1105	call          r5     7     0
.line	1105	setlist       r3     0     1
.line	1105	call          r2     2     2
.label	l60
.line	1105	call          r1     2     1
.line	1105	gettabup      r1    u0   k46 ; k46 = "GetLoadManager"
.line	1105	call          r1     1     2
.line	1105	test          r1     0
.line	1105	jmp            0   l68
.line	1105	gettable      r2    r1   k47 ; k47 = "bNewCustomUI"
.line	1105	test          r2     1
.line	1105	jmp            0  l160
.label	l68
.line	1105	gettabup      r2    u0    k0 ; k0 = "print"
.line	1105	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1105	test          r3     0
.line	1105	jmp            0  l158
.line	1105	gettabup      r3    u0    k2 ; k2 = "table"
.line	1105	gettable      r3    r3    k3 ; k3 = "concat"
.line	1105	newtable      r4     1     0
.line	1105	getupval      r5    u1
.line	1105	loadk         r6    k4 ; k4 = 126
.line	1105	loadk         r7    k5 ; k5 = 68
.line	1105	loadk         r8    k6 ; k6 = 7
.line	1105	loadk         r9    k7 ; k7 = 41
.line	1105	loadk        r10    k8 ; k8 = 164
.line	1105	loadk        r11    k9 ; k9 = 170
.line	1105	loadk        r12   k10 ; k10 = 39
.line	1105	loadk        r13   k11 ; k11 = 95
.line	1105	loadk        r14   k12 ; k12 = 24
.line	1105	loadk        r15   k13 ; k13 = 91
.line	1105	loadk        r16   k14 ; k14 = 26
.line	1105	loadk        r17   k15 ; k15 = 31
.line	1105	loadk        r18   k16 ; k16 = 217
.line	1105	loadk        r19   k17 ; k17 = 83
.line	1105	loadk        r20   k18 ; k18 = 38
.line	1105	loadk        r21   k19 ; k19 = 54
.line	1105	loadk        r22   k20 ; k20 = 137
.line	1105	loadk        r23   k21 ; k21 = 103
.line	1105	loadk        r24   k22 ; k22 = 102
.line	1105	loadk        r25   k23 ; k23 = 25
.line	1105	loadk        r26   k24 ; k24 = 99
.line	1105	loadk        r27   k25 ; k25 = 156
.line	1105	loadk        r28   k26 ; k26 = 76
.line	1105	loadk        r29   k27 ; k27 = 122
.line	1105	loadk        r30   k28 ; k28 = 113
.line	1105	loadk        r31   k29 ; k29 = 125
.line	1105	loadk        r32   k30 ; k30 = 11
.line	1105	loadk        r33   k31 ; k31 = 30
.line	1105	loadk        r34   k32 ; k32 = 199
.line	1105	loadk        r35   k33 ; k33 = 90
.line	1105	loadk        r36   k34 ; k34 = 10
.line	1105	loadk        r37   k23 ; k23 = 25
.line	1105	loadk        r38   k35 ; k35 = 184
.line	1105	loadk        r39   k36 ; k36 = 65
.line	1105	loadk        r40   k37 ; k37 = 107
.line	1105	loadk        r41   k38 ; k38 = 12
.line	1105	loadk        r42   k39 ; k39 = 87
.line	1105	loadk        r43   k40 ; k40 = 134
.line	1105	loadk        r44   k41 ; k41 = 69
.line	1105	loadk        r45   k42 ; k42 = 85
.line	1105	call          r5    41     2
.line	1105	getupval      r6    u1
.line	1105	loadk         r7   k11 ; k11 = 95
.line	1105	loadk         r8   k43 ; k43 = 92
.line	1105	loadk         r9    k6 ; k6 = 7
.line	1105	loadk        r10   k44 ; k44 = 43
.line	1105	loadk        r11    k8 ; k8 = 164
.line	1105	loadk        r12   k45 ; k45 = 176
.line	1105	loadk        r13   k28 ; k28 = 113
.line	1105	loadk        r14   k48 ; k48 = 118
.line	1105	loadk        r15   k49 ; k49 = 52
.line	1105	loadk        r16   k50 ; k50 = 79
.line	1105	loadk        r17   k51 ; k51 = 13
.line	1105	loadk        r18   k18 ; k18 = 38
.line	1105	loadk        r19   k52 ; k52 = 209
.line	1105	loadk        r20   k26 ; k26 = 76
.line	1105	loadk        r21   k17 ; k17 = 83
.line	1105	loadk        r22   k53 ; k53 = 16
.line	1105	loadk        r23   k54 ; k54 = 191
.line	1105	loadk        r24   k18 ; k18 = 38
.line	1105	loadk        r25   k55 ; k55 = 112
.line	1105	loadk        r26   k19 ; k19 = 54
.line	1105	loadk        r27   k41 ; k41 = 69
.line	1105	loadk        r28   k56 ; k56 = 132
.line	1105	loadk        r29   k57 ; k57 = 98
.line	1105	loadk        r30   k58 ; k58 = 127
.line	1105	loadk        r31   k59 ; k59 = 56
.line	1105	loadk        r32   k60 ; k60 = 74
.line	1105	loadk        r33   k61 ; k61 = 22
.line	1105	loadk        r34   k61 ; k61 = 22
.line	1105	loadk        r35   k62 ; k62 = 243
.line	1105	loadk        r36   k21 ; k21 = 103
.line	1105	loadk        r37   k63 ; k63 = 67
.line	1105	loadk        r38   k64 ; k64 = 6
.line	1105	loadk        r39   k65 ; k65 = 174
.line	1105	loadk        r40   k19 ; k19 = 54
.line	1105	loadk        r41   k66 ; k66 = 108
.line	1105	loadk        r42   k67 ; k67 = 1
.line	1105	loadk        r43   k43 ; k43 = 92
.line	1105	call          r6    38     0
.line	1105	setlist       r4     0     1
.line	1105	call          r3     2     2
.label	l158
.line	1105	call          r2     2     1
.line	1105	return        r0     1
.label	l160
.line	1105	gettabup      r2    u0   k68 ; k68 = "pairs"
.line	1105	gettable      r3    r0   k69 ; k69 = "CustomUIData"
.line	1105	call          r2     2     4
.line	1105	jmp            0  l269
.line	1105	self          r7    r0   k70 ; k70 = "GetCDOInstanceIDOfIn" (truncated)
.line	1105	move          r9    r6
.line	1105	call          r7     3     2
.line	1105	test          r7     1
.line	1105	jmp            0  l176
.line	1105	gettable      r7    r0   k71 ; k71 = "RuntimeToCDO"
.line	1105	gettable      r7    r7    r5
.line	1105	test          r7     1
.line	1105	jmp            0  l176
.line	1105	gettabup      r7    u0   k72 ; k72 = "tostring"
.line	1105	move          r8    r5
.line	1105	call          r7     2     2
.label	l176
.line	1105	gettable      r8    r0   k73 ; k73 = "CustomUIObject"
.line	1105	gettable      r8    r8    r7
.line	1105	test          r8     1
.line	1105	jmp            0  l189
.line	1105	self          r9    r0   k74 ; k74 = "_CreateCustomUILuaOb" (truncated)
.line	1105	move         r11    r7
.line	1105	move         r12    r6
.line	1105	call          r9     4     2
.line	1105	move          r8    r9
.line	1105	test          r8     0
.line	1105	jmp            0  l189
.line	1105	gettable      r9    r0   k73 ; k73 = "CustomUIObject"
.line	1105	settable      r9    r7    r8
.label	l189
.line	1105	test          r8     0
.line	1105	jmp            0  l269
.line	1105	gettabup      r9    u0    k0 ; k0 = "print"
.line	1105	gettabup     r10    u0    k1 ; k1 = "bWriteLog"
.line	1105	test         r10     0
.line	1105	jmp            0  l258
.line	1105	gettabup     r10    u0    k2 ; k2 = "table"
.line	1105	gettable     r10   r10    k3 ; k3 = "concat"
.line	1105	newtable     r11     1     0
.line	1105	getupval     r12    u1
.line	1105	loadk        r13    k4 ; k4 = 126
.line	1105	loadk        r14    k5 ; k5 = 68
.line	1105	loadk        r15    k6 ; k6 = 7
.line	1105	loadk        r16    k7 ; k7 = 41
.line	1105	loadk        r17    k8 ; k8 = 164
.line	1105	loadk        r18    k9 ; k9 = 170
.line	1105	loadk        r19   k10 ; k10 = 39
.line	1105	loadk        r20   k11 ; k11 = 95
.line	1105	loadk        r21   k12 ; k12 = 24
.line	1105	loadk        r22   k13 ; k13 = 91
.line	1105	loadk        r23   k14 ; k14 = 26
.line	1105	loadk        r24   k15 ; k15 = 31
.line	1105	loadk        r25   k16 ; k16 = 217
.line	1105	loadk        r26   k17 ; k17 = 83
.line	1105	loadk        r27   k18 ; k18 = 38
.line	1105	loadk        r28   k19 ; k19 = 54
.line	1105	loadk        r29   k20 ; k20 = 137
.line	1105	loadk        r30   k21 ; k21 = 103
.line	1105	loadk        r31   k22 ; k22 = 102
.line	1105	loadk        r32   k23 ; k23 = 25
.line	1105	loadk        r33   k24 ; k24 = 99
.line	1105	loadk        r34   k25 ; k25 = 156
.line	1105	loadk        r35   k26 ; k26 = 76
.line	1105	loadk        r36   k27 ; k27 = 122
.line	1105	loadk        r37   k28 ; k28 = 113
.line	1105	loadk        r38   k29 ; k29 = 125
.line	1105	loadk        r39   k30 ; k30 = 11
.line	1105	loadk        r40   k31 ; k31 = 30
.line	1105	loadk        r41   k32 ; k32 = 199
.line	1105	loadk        r42   k33 ; k33 = 90
.line	1105	loadk        r43   k34 ; k34 = 10
.line	1105	loadk        r44   k23 ; k23 = 25
.line	1105	loadk        r45   k35 ; k35 = 184
.line	1105	loadk        r46   k36 ; k36 = 65
.line	1105	loadk        r47   k37 ; k37 = 107
.line	1105	loadk        r48   k38 ; k38 = 12
.line	1105	loadk        r49   k39 ; k39 = 87
.line	1105	loadk        r50   k40 ; k40 = 134
.line	1105	loadk        r51   k41 ; k41 = 69
.line	1105	loadk        r52   k42 ; k42 = 85
.line	1105	call         r12    41     2
.line	1105	getupval     r13    u1
.line	1105	loadk        r14   k11 ; k11 = 95
.line	1105	loadk        r15   k43 ; k43 = 92
.line	1105	loadk        r16    k6 ; k6 = 7
.line	1105	loadk        r17   k44 ; k44 = 43
.line	1105	loadk        r18    k8 ; k8 = 164
.line	1105	loadk        r19   k45 ; k45 = 176
.line	1105	loadk        r20   k28 ; k28 = 113
.line	1105	loadk        r21   k75 ; k75 = 105
.line	1105	loadk        r22   k76 ; k76 = 46
.line	1105	loadk        r23   k77 ; k77 = 77
.line	1105	loadk        r24   k34 ; k34 = 10
.line	1105	loadk        r25   k78 ; k78 = 14
.line	1105	loadk        r26   k79 ; k79 = 197
.line	1105	loadk        r27   k77 ; k77 = 77
.line	1105	call         r13    15     0
.line	1105	setlist      r11     0     1
.line	1105	call         r10     2     2
.label	l258
.line	1105	gettabup     r11    u0   k72 ; k72 = "tostring"
.line	1105	move         r12    r5
.line	1105	call         r11     2     0
.line	1105	call          r9     0     1
.line	1105	self          r9    r0   k80 ; k80 = "GetOwner"
.line	1105	call          r9     2     2
.line	1105	self         r10    r8   k81 ; k81 = "AddRuntimeInstanceDa" (truncated)
.line	1105	move         r12    r9
.line	1105	move         r13    r5
.line	1105	move         r14    r6
.line	1105	call         r10     5     1
.label	l269
.line	1105	move          r0    r0
.line	1105	move          r0    r0
.line	1105	return        r0     1
.line	1105	move          r0    r0
.line	1105	move          r0    r0
.line	1105	move          r0    r0
.line	1105	return        r0     1

.function	main/f49

.source	null
.linedefined	1129
.lastlinedefined	1150
.numparams	1
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	126
.constant	k5	68
.constant	k6	7
.constant	k7	41
.constant	k8	164
.constant	k9	170
.constant	k10	39
.constant	k11	95
.constant	k12	24
.constant	k13	91
.constant	k14	26
.constant	k15	31
.constant	k16	217
.constant	k17	83
.constant	k18	38
.constant	k19	54
.constant	k20	137
.constant	k21	103
.constant	k22	102
.constant	k23	25
.constant	k24	99
.constant	k25	156
.constant	k26	76
.constant	k27	122
.constant	k28	113
.constant	k29	28
.constant	k30	8
.constant	k31	210
.constant	k32	92
.constant	k33	12
.constant	k34	22
.constant	k35	138
.constant	k36	127
.constant	k37	15
.constant	k38	85
.constant	k39	151
.constant	k40	120
.constant	k41	87
.constant	k42	1
.constant	k43	60
.constant	k44	163
.constant	k45	"pairs"
.constant	k46	"CustomUIObject"
.constant	k47	"OnDestroy"
.constant	k48	227
.constant	k49	30
.constant	k50	84
.constant	k51	75
.constant	k52	196
.constant	k53	81
.constant	k54	10
.constant	k55	"tostring"
.constant	k56	nil
.constant	k57	"RuntimeReady"
.constant	k58	"CanvasBuilt"
.constant	k59	"PendingLoadRuntimeIds"
.constant	k60	"PendingCanvasReadyCallbacks"
.constant	k61	"FireCanvasReadyCallbacks"

.line	1129	gettabup      r1    u0    k0 ; k0 = "print"
.line	1129	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1129	test          r2     0
.line	1129	jmp            0   l59
.line	1129	gettabup      r2    u0    k2 ; k2 = "table"
.line	1129	gettable      r2    r2    k3 ; k3 = "concat"
.line	1129	newtable      r3     1     0
.line	1129	getupval      r4    u1
.line	1129	loadk         r5    k4 ; k4 = 126
.line	1129	loadk         r6    k5 ; k5 = 68
.line	1129	loadk         r7    k6 ; k6 = 7
.line	1129	loadk         r8    k7 ; k7 = 41
.line	1129	loadk         r9    k8 ; k8 = 164
.line	1129	loadk        r10    k9 ; k9 = 170
.line	1129	loadk        r11   k10 ; k10 = 39
.line	1129	loadk        r12   k11 ; k11 = 95
.line	1129	loadk        r13   k12 ; k12 = 24
.line	1129	loadk        r14   k13 ; k13 = 91
.line	1129	loadk        r15   k14 ; k14 = 26
.line	1129	loadk        r16   k15 ; k15 = 31
.line	1129	loadk        r17   k16 ; k16 = 217
.line	1129	loadk        r18   k17 ; k17 = 83
.line	1129	loadk        r19   k18 ; k18 = 38
.line	1129	loadk        r20   k19 ; k19 = 54
.line	1129	loadk        r21   k20 ; k20 = 137
.line	1129	loadk        r22   k21 ; k21 = 103
.line	1129	loadk        r23   k22 ; k22 = 102
.line	1129	loadk        r24   k23 ; k23 = 25
.line	1129	loadk        r25   k24 ; k24 = 99
.line	1129	loadk        r26   k25 ; k25 = 156
.line	1129	loadk        r27   k26 ; k26 = 76
.line	1129	loadk        r28   k27 ; k27 = 122
.line	1129	loadk        r29   k28 ; k28 = 113
.line	1129	loadk        r30   k27 ; k27 = 122
.line	1129	loadk        r31   k29 ; k29 = 28
.line	1129	loadk        r32   k30 ; k30 = 8
.line	1129	loadk        r33   k31 ; k31 = 210
.line	1129	loadk        r34   k32 ; k32 = 92
.line	1129	loadk        r35   k33 ; k33 = 12
.line	1129	loadk        r36   k34 ; k34 = 22
.line	1129	loadk        r37   k35 ; k35 = 138
.line	1129	loadk        r38   k36 ; k36 = 127
.line	1129	loadk        r39   k22 ; k22 = 102
.line	1129	loadk        r40   k37 ; k37 = 15
.line	1129	loadk        r41   k38 ; k38 = 85
.line	1129	loadk        r42   k39 ; k39 = 151
.line	1129	loadk        r43    k4 ; k4 = 126
.line	1129	loadk        r44   k40 ; k40 = 120
.line	1129	call          r4    41     2
.line	1129	getupval      r5    u1
.line	1129	loadk         r6   k41 ; k41 = 87
.line	1129	loadk         r7   k17 ; k17 = 83
.line	1129	loadk         r8   k42 ; k42 = 1
.line	1129	loadk         r9   k43 ; k43 = 60
.line	1129	loadk        r10   k44 ; k44 = 163
.line	1129	call          r5     6     0
.line	1129	setlist       r3     0     1
.line	1129	call          r2     2     2
.label	l59
.line	1129	call          r1     2     1
.line	1129	gettabup      r1    u0   k45 ; k45 = "pairs"
.line	1129	gettable      r2    r0   k46 ; k46 = "CustomUIObject"
.line	1129	call          r1     2     4
.line	1129	jmp            0  l145
.line	1129	test          r5     0
.line	1129	jmp            0  l143
.line	1129	gettable      r6    r5   k47 ; k47 = "OnDestroy"
.line	1129	test          r6     0
.line	1129	jmp            0  l143
.line	1129	gettabup      r6    u0    k0 ; k0 = "print"
.line	1129	gettabup      r7    u0    k1 ; k1 = "bWriteLog"
.line	1129	test          r7     0
.line	1129	jmp            0  l137
.line	1129	gettabup      r7    u0    k2 ; k2 = "table"
.line	1129	gettable      r7    r7    k3 ; k3 = "concat"
.line	1129	newtable      r8     1     0
.line	1129	getupval      r9    u1
.line	1129	loadk        r10    k4 ; k4 = 126
.line	1129	loadk        r11    k5 ; k5 = 68
.line	1129	loadk        r12    k6 ; k6 = 7
.line	1129	loadk        r13    k7 ; k7 = 41
.line	1129	loadk        r14    k8 ; k8 = 164
.line	1129	loadk        r15    k9 ; k9 = 170
.line	1129	loadk        r16   k10 ; k10 = 39
.line	1129	loadk        r17   k11 ; k11 = 95
.line	1129	loadk        r18   k12 ; k12 = 24
.line	1129	loadk        r19   k13 ; k13 = 91
.line	1129	loadk        r20   k14 ; k14 = 26
.line	1129	loadk        r21   k15 ; k15 = 31
.line	1129	loadk        r22   k16 ; k16 = 217
.line	1129	loadk        r23   k17 ; k17 = 83
.line	1129	loadk        r24   k18 ; k18 = 38
.line	1129	loadk        r25   k19 ; k19 = 54
.line	1129	loadk        r26   k20 ; k20 = 137
.line	1129	loadk        r27   k21 ; k21 = 103
.line	1129	loadk        r28   k22 ; k22 = 102
.line	1129	loadk        r29   k23 ; k23 = 25
.line	1129	loadk        r30   k24 ; k24 = 99
.line	1129	loadk        r31   k25 ; k25 = 156
.line	1129	loadk        r32   k26 ; k26 = 76
.line	1129	loadk        r33   k27 ; k27 = 122
.line	1129	loadk        r34   k28 ; k28 = 113
.line	1129	loadk        r35   k27 ; k27 = 122
.line	1129	loadk        r36   k29 ; k29 = 28
.line	1129	loadk        r37   k30 ; k30 = 8
.line	1129	loadk        r38   k31 ; k31 = 210
.line	1129	loadk        r39   k32 ; k32 = 92
.line	1129	loadk        r40   k33 ; k33 = 12
.line	1129	loadk        r41   k34 ; k34 = 22
.line	1129	loadk        r42   k35 ; k35 = 138
.line	1129	loadk        r43   k36 ; k36 = 127
.line	1129	loadk        r44   k22 ; k22 = 102
.line	1129	loadk        r45   k37 ; k37 = 15
.line	1129	loadk        r46   k38 ; k38 = 85
.line	1129	loadk        r47   k39 ; k39 = 151
.line	1129	loadk        r48    k4 ; k4 = 126
.line	1129	loadk        r49   k40 ; k40 = 120
.line	1129	call          r9    41     2
.line	1129	getupval     r10    u1
.line	1129	loadk        r11   k41 ; k41 = 87
.line	1129	loadk        r12   k17 ; k17 = 83
.line	1129	loadk        r13   k42 ; k42 = 1
.line	1129	loadk        r14   k43 ; k43 = 60
.line	1129	loadk        r15   k44 ; k44 = 163
.line	1129	loadk        r16   k48 ; k48 = 227
.line	1129	loadk        r17   k49 ; k49 = 30
.line	1129	loadk        r18   k50 ; k50 = 84
.line	1129	loadk        r19   k15 ; k15 = 31
.line	1129	loadk        r20   k51 ; k51 = 75
.line	1129	loadk        r21   k14 ; k14 = 26
.line	1129	loadk        r22   k15 ; k15 = 31
.line	1129	loadk        r23   k52 ; k52 = 196
.line	1129	loadk        r24   k53 ; k53 = 81
.line	1129	loadk        r25   k54 ; k54 = 10
.line	1129	call         r10    16     0
.line	1129	setlist       r8     0     1
.line	1129	call          r7     2     2
.label	l137
.line	1129	gettabup      r8    u0   k55 ; k55 = "tostring"
.line	1129	move          r9    r4
.line	1129	call          r8     2     0
.line	1129	call          r6     0     1
.line	1129	self          r6    r5   k47 ; k47 = "OnDestroy"
.line	1129	call          r6     2     1
.label	l143
.line	1129	gettable      r6    r0   k46 ; k46 = "CustomUIObject"
.line	1129	settable      r6    r4   k56 ; k56 = nil
.label	l145
.line	1129	move          r0    r0
.line	1129	move          r0    r0
.line	1129	newtable      r1     0     0
.line	1129	settable      r0   k57    r1 ; k57 = "RuntimeReady"
.line	1129	settable      r0   k58   k56 ; k56 = nil
.line	1129	newtable      r1     0     0
.line	1129	settable      r0   k59    r1 ; k59 = "PendingLoadRuntimeId" (truncated)
.line	1129	gettable      r1    r0   k60 ; k60 = "PendingCanvasReadyCa" (truncated)
.line	1129	test          r1     0
.line	1129	jmp            0  l174
.line	1129	newtable      r1     0     0
.line	1129	gettabup      r2    u0   k45 ; k45 = "pairs"
.line	1129	gettable      r3    r0   k60 ; k60 = "PendingCanvasReadyCa" (truncated)
.line	1129	call          r2     2     4
.line	1129	jmp            0  l163
.line	1129	len           r6    r1
.line	1129	add           r6    r6   k42 ; k42 = 1
.line	1129	settable      r1    r6    r5
.label	l163
.line	1129	move          r0    r0
.line	1129	move          r0    r0
.line	1129	loadk         r2   k42 ; k42 = 1
.line	1129	len           r3    r1
.line	1129	loadk         r4   k42 ; k42 = 1
.line	1129	move          r0    r0
.line	1129	self          r6    r0   k61 ; k61 = "FireCanvasReadyCallb" (truncated)
.line	1129	gettable      r8    r1    r5
.line	1129	loadnil       r9     0
.line	1129	call          r6     4     1
.line	1129	move          r0    r0
.label	l174
.line	1129	return        r0     1
.line	1129	move          r0    r0
.line	1129	move          r0    r0
.line	1129	move          r0    r0
.line	1129	move          r0    r0
.line	1129	return        r0     1

.function	main/f50

.source	null
.linedefined	1152
.lastlinedefined	1158
.numparams	2
.is_vararg	0
.maxstacksize	4

.constant	k0	"RuntimeToCDO"
.constant	k1	"CustomUIObject"

.line	1152	gettable      r2    r0    k0 ; k0 = "RuntimeToCDO"
.line	1152	test          r2     0
.line	1152	jmp            0    l6
.line	1152	gettable      r2    r0    k0 ; k0 = "RuntimeToCDO"
.line	1152	gettable      r2    r2    r1
.label	l6
.line	1152	test          r2     1
.line	1152	jmp            0   l10
.line	1152	loadnil       r3     0
.line	1152	return        r3     2
.label	l10
.line	1152	gettable      r3    r0    k1 ; k1 = "CustomUIObject"
.line	1152	gettable      r3    r3    r2
.line	1152	return        r3     2
.line	1152	return        r0     1
.line	1152	move          r0    r0
.line	1152	move          r0    r0
.line	1152	return        r0     1

.function	main/f51

.source	null
.linedefined	1160
.lastlinedefined	1169
.numparams	2
.is_vararg	0
.maxstacksize	6

.constant	k0	"CustomUIObject"
.constant	k1	"GetWidgetObjectByRuntimeId"

.line	1160	test          r1     1
.line	1160	jmp            0    l5
.line	1160	loadnil       r2     0
.line	1160	return        r2     2
.label	l5
.line	1160	gettable      r2    r0    k0 ; k0 = "CustomUIObject"
.line	1160	gettable      r2    r2    r1
.line	1160	test          r2     0
.line	1160	jmp            0   l10
.line	1160	return        r2     2
.label	l10
.line	1160	self          r3    r0    k1 ; k1 = "GetWidgetObjectByRun" (truncated)
.line	1160	move          r5    r1
.line	1160	tailcall      r3     3
.line	1160	return        r3     0
.line	1160	return        r0     1
.line	1160	move          r0    r0
.line	1160	move          r0    r0
.line	1160	return        r0     1

.function	main/f52

.source	null
.linedefined	1171
.lastlinedefined	1179
.numparams	2
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	0	false

.constant	k0	"CDOToRuntimeIds"
.constant	k1	"next"
.constant	k2	nil

.line	1171	test          r1     1
.line	1171	jmp            0    l5
.line	1171	loadnil       r2     0
.line	1171	return        r2     2
.label	l5
.line	1171	gettable      r2    r0    k0 ; k0 = "CDOToRuntimeIds"
.line	1171	test          r2     0
.line	1171	jmp            0   l10
.line	1171	gettable      r2    r0    k0 ; k0 = "CDOToRuntimeIds"
.line	1171	gettable      r2    r2    r1
.label	l10
.line	1171	test          r2     0
.line	1171	jmp            0   l18
.line	1171	gettabup      r3    u0    k1 ; k1 = "next"
.line	1171	move          r4    r2
.line	1171	call          r3     2     2
.line	1171	eq             1    r3    k2 ; k2 = nil
.line	1171	jmp            0   l18
.line	1171	return        r2     2
.label	l18
.line	1171	return        r0     1
.line	1171	move          r0    r0
.line	1171	move          r0    r0
.line	1171	return        r0     1

.function	main/f53

.source	null
.linedefined	1181
.lastlinedefined	1192
.numparams	3
.is_vararg	0
.maxstacksize	13

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"type"
.constant	k1	91
.constant	k2	67
.constant	k3	12
.constant	k4	43
.constant	k5	164
.constant	k6	170
.constant	k7	62
.constant	k8	84
.constant	k9	"PendingCanvasReadyCallbacks"
.constant	k10	1

.line	1181	test          r1     0
.line	1181	jmp            0   l18
.line	1181	gettabup      r3    u0    k0 ; k0 = "type"
.line	1181	move          r4    r2
.line	1181	call          r3     2     2
.line	1181	getupval      r4    u1
.line	1181	loadk         r5    k1 ; k1 = 91
.line	1181	loadk         r6    k2 ; k2 = 67
.line	1181	loadk         r7    k3 ; k3 = 12
.line	1181	loadk         r8    k4 ; k4 = 43
.line	1181	loadk         r9    k5 ; k5 = 164
.line	1181	loadk        r10    k6 ; k6 = 170
.line	1181	loadk        r11    k7 ; k7 = 62
.line	1181	loadk        r12    k8 ; k8 = 84
.line	1181	call          r4     9     2
.line	1181	eq             1    r3    r4
.line	1181	jmp            0   l19
.label	l18
.line	1181	return        r0     1
.label	l19
.line	1181	gettable      r3    r0    k9 ; k9 = "PendingCanvasReadyCa" (truncated)
.line	1181	test          r3     1
.line	1181	jmp            0   l23
.line	1181	newtable      r3     0     0
.label	l23
.line	1181	settable      r0    k9    r3 ; k9 = "PendingCanvasReadyCa" (truncated)
.line	1181	gettable      r3    r0    k9 ; k9 = "PendingCanvasReadyCa" (truncated)
.line	1181	gettable      r3    r3    r1
.line	1181	test          r3     1
.line	1181	jmp            0   l32
.line	1181	newtable      r4     0     0
.line	1181	move          r3    r4
.line	1181	gettable      r4    r0    k9 ; k9 = "PendingCanvasReadyCa" (truncated)
.line	1181	settable      r4    r1    r3
.label	l32
.line	1181	len           r4    r3
.line	1181	add           r4    r4   k10 ; k10 = 1
.line	1181	settable      r3    r4    r2
.line	1181	return        r0     1
.line	1181	move          r0    r0
.line	1181	move          r0    r0
.line	1181	return        r0     1

.function	main/f54

.source	null
.linedefined	1194
.lastlinedefined	1206
.numparams	3
.is_vararg	0
.maxstacksize	54

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"PendingCanvasReadyCallbacks"
.constant	k1	nil
.constant	k2	1
.constant	k3	"pcall"
.constant	k4	"print"
.constant	k5	"table"
.constant	k6	"concat"
.constant	k7	126
.constant	k8	68
.constant	k9	7
.constant	k10	41
.constant	k11	164
.constant	k12	170
.constant	k13	39
.constant	k14	95
.constant	k15	24
.constant	k16	91
.constant	k17	26
.constant	k18	31
.constant	k19	217
.constant	k20	83
.constant	k21	38
.constant	k22	54
.constant	k23	137
.constant	k24	103
.constant	k25	102
.constant	k26	25
.constant	k27	99
.constant	k28	156
.constant	k29	76
.constant	k30	122
.constant	k31	113
.constant	k32	120
.constant	k33	16
.constant	k34	9
.constant	k35	195
.constant	k36	109
.constant	k37	2
.constant	k38	171
.constant	k39	119
.constant	k40	58
.constant	k41	85
.constant	k42	130
.constant	k43	87
.constant	k44	14
.constant	k45	36
.constant	k46	178
.constant	k47	162
.constant	k48	50
.constant	k49	81
.constant	k50	40
.constant	k51	10
.constant	k52	218
.constant	k53	82
.constant	k54	17
.constant	k55	30
.constant	k56	174
.constant	k57	29
.constant	k58	129
.constant	k59	78
.constant	k60	"tostring"

.line	1194	gettable      r3    r0    k0 ; k0 = "PendingCanvasReadyCa" (truncated)
.line	1194	test          r3     0
.line	1194	jmp            0    l6
.line	1194	gettable      r3    r0    k0 ; k0 = "PendingCanvasReadyCa" (truncated)
.line	1194	gettable      r3    r3    r1
.label	l6
.line	1194	test          r3     1
.line	1194	jmp            0    l9
.line	1194	return        r0     1
.label	l9
.line	1194	gettable      r4    r0    k0 ; k0 = "PendingCanvasReadyCa" (truncated)
.line	1194	settable      r4    r1    k1 ; k1 = nil
.line	1194	loadk         r4    k2 ; k2 = 1
.line	1194	len           r5    r3
.line	1194	loadk         r6    k2 ; k2 = 1
.line	1194	move          r0    r0
.line	1194	gettabup      r8    u0    k3 ; k3 = "pcall"
.line	1194	gettable      r9    r3    r7
.line	1194	move         r10    r2
.line	1194	move         r11    r1
.line	1194	call          r8     4     3
.line	1194	test          r8     1
.line	1194	jmp            0  l102
.line	1194	gettabup     r10    u0    k4 ; k4 = "print"
.line	1194	gettabup     r11    u0    k5 ; k5 = "table"
.line	1194	gettable     r11   r11    k6 ; k6 = "concat"
.line	1194	newtable     r12     1     0
.line	1194	getupval     r13    u1
.line	1194	loadk        r14    k7 ; k7 = 126
.line	1194	loadk        r15    k8 ; k8 = 68
.line	1194	loadk        r16    k9 ; k9 = 7
.line	1194	loadk        r17   k10 ; k10 = 41
.line	1194	loadk        r18   k11 ; k11 = 164
.line	1194	loadk        r19   k12 ; k12 = 170
.line	1194	loadk        r20   k13 ; k13 = 39
.line	1194	loadk        r21   k14 ; k14 = 95
.line	1194	loadk        r22   k15 ; k15 = 24
.line	1194	loadk        r23   k16 ; k16 = 91
.line	1194	loadk        r24   k17 ; k17 = 26
.line	1194	loadk        r25   k18 ; k18 = 31
.line	1194	loadk        r26   k19 ; k19 = 217
.line	1194	loadk        r27   k20 ; k20 = 83
.line	1194	loadk        r28   k21 ; k21 = 38
.line	1194	loadk        r29   k22 ; k22 = 54
.line	1194	loadk        r30   k23 ; k23 = 137
.line	1194	loadk        r31   k24 ; k24 = 103
.line	1194	loadk        r32   k25 ; k25 = 102
.line	1194	loadk        r33   k26 ; k26 = 25
.line	1194	loadk        r34   k27 ; k27 = 99
.line	1194	loadk        r35   k28 ; k28 = 156
.line	1194	loadk        r36   k29 ; k29 = 76
.line	1194	loadk        r37   k30 ; k30 = 122
.line	1194	loadk        r38   k31 ; k31 = 113
.line	1194	loadk        r39   k32 ; k32 = 120
.line	1194	loadk        r40   k33 ; k33 = 16
.line	1194	loadk        r41   k34 ; k34 = 9
.line	1194	loadk        r42   k35 ; k35 = 195
.line	1194	loadk        r43   k36 ; k36 = 109
.line	1194	loadk        r44   k37 ; k37 = 2
.line	1194	loadk        r45    k2 ; k2 = 1
.line	1194	loadk        r46   k38 ; k38 = 171
.line	1194	loadk        r47   k39 ; k39 = 119
.line	1194	loadk        r48   k31 ; k31 = 113
.line	1194	loadk        r49   k40 ; k40 = 58
.line	1194	loadk        r50   k41 ; k41 = 85
.line	1194	loadk        r51   k42 ; k42 = 130
.line	1194	loadk        r52   k41 ; k41 = 85
.line	1194	loadk        r53   k27 ; k27 = 99
.line	1194	call         r13    41     2
.line	1194	getupval     r14    u1
.line	1194	loadk        r15    k7 ; k7 = 126
.line	1194	loadk        r16   k43 ; k43 = 87
.line	1194	loadk        r17   k44 ; k44 = 14
.line	1194	loadk        r18   k45 ; k45 = 36
.line	1194	loadk        r19   k46 ; k46 = 178
.line	1194	loadk        r20   k47 ; k47 = 162
.line	1194	loadk        r21   k48 ; k48 = 50
.line	1194	loadk        r22   k49 ; k49 = 81
.line	1194	loadk        r23   k50 ; k50 = 40
.line	1194	loadk        r24   k44 ; k44 = 14
.line	1194	loadk        r25   k51 ; k51 = 10
.line	1194	loadk        r26   k51 ; k51 = 10
.line	1194	loadk        r27   k52 ; k52 = 218
.line	1194	loadk        r28   k53 ; k53 = 82
.line	1194	loadk        r29   k54 ; k54 = 17
.line	1194	loadk        r30   k55 ; k55 = 30
.line	1194	loadk        r31   k56 ; k56 = 174
.line	1194	loadk        r32   k36 ; k36 = 109
.line	1194	loadk        r33   k48 ; k48 = 50
.line	1194	loadk        r34   k57 ; k57 = 29
.line	1194	loadk        r35   k53 ; k53 = 82
.line	1194	loadk        r36   k58 ; k58 = 129
.line	1194	loadk        r37   k59 ; k59 = 78
.line	1194	loadk        r38   k32 ; k32 = 120
.line	1194	loadk        r39   k31 ; k31 = 113
.line	1194	call         r14    26     0
.line	1194	setlist      r12     0     1
.line	1194	call         r11     2     2
.line	1194	gettabup     r12    u0   k60 ; k60 = "tostring"
.line	1194	move         r13    r9
.line	1194	call         r12     2     2
.line	1194	concat       r11   r11   r12
.line	1194	call         r10     2     1
.label	l102
.line	1194	move          r0    r0
.line	1194	return        r0     1
.line	1194	move          r0    r0
.line	1194	return        r0     1

.function	main/f55

.source	null
.linedefined	1208
.lastlinedefined	1211
.numparams	6
.is_vararg	0
.maxstacksize	11

.upvalue	"_ENV"	0	false

.constant	k0	"slua"
.constant	k1	"isValid"
.constant	k2	"FireCanvasReadyCallbacks"

.line	1208	test          r4     0
.line	1208	jmp            0   l13
.line	1208	test          r5     0
.line	1208	jmp            0   l13
.line	1208	gettabup      r6    u0    k0 ; k0 = "slua"
.line	1208	gettable      r6    r6    k1 ; k1 = "isValid"
.line	1208	move          r7    r5
.line	1208	call          r6     2     2
.line	1208	test          r6     0
.line	1208	jmp            0   l13
.line	1208	testset       r6    r5     1
.line	1208	jmp            0   l14
.label	l13
.line	1208	loadnil       r6     0
.label	l14
.line	1208	self          r7    r0    k2 ; k2 = "FireCanvasReadyCallb" (truncated)
.line	1208	move          r9    r3
.line	1208	move         r10    r6
.line	1208	call          r7     4     1
.line	1208	return        r0     1
.line	1208	move          r0    r0
.line	1208	move          r0    r0
.line	1208	move          r0    r0
.line	1208	return        r0     1

.function	main/f56

.source	null
.linedefined	1213
.lastlinedefined	1222
.numparams	2
.is_vararg	0
.maxstacksize	42

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	126
.constant	k3	68
.constant	k4	7
.constant	k5	41
.constant	k6	164
.constant	k7	170
.constant	k8	39
.constant	k9	95
.constant	k10	24
.constant	k11	91
.constant	k12	26
.constant	k13	31
.constant	k14	217
.constant	k15	83
.constant	k16	38
.constant	k17	54
.constant	k18	137
.constant	k19	103
.constant	k20	102
.constant	k21	25
.constant	k22	99
.constant	k23	156
.constant	k24	76
.constant	k25	122
.constant	k26	113
.constant	k27	23
.constant	k28	56
.constant	k29	199
.constant	k30	64
.constant	k31	21
.constant	k32	14
.constant	k33	174
.constant	k34	9
.constant	k35	84
.constant	k36	154
.constant	k37	"GetWidgetObjectByRuntimeId"
.constant	k38	"bIsUMGInfo"
.constant	k39	"EnsureWidgetReady"

.line	1213	gettabup      r2    u0    k0 ; k0 = "print"
.line	1213	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1213	test          r3     0
.line	1213	jmp            0   l45
.line	1213	getupval      r3    u1
.line	1213	loadk         r4    k2 ; k2 = 126
.line	1213	loadk         r5    k3 ; k3 = 68
.line	1213	loadk         r6    k4 ; k4 = 7
.line	1213	loadk         r7    k5 ; k5 = 41
.line	1213	loadk         r8    k6 ; k6 = 164
.line	1213	loadk         r9    k7 ; k7 = 170
.line	1213	loadk        r10    k8 ; k8 = 39
.line	1213	loadk        r11    k9 ; k9 = 95
.line	1213	loadk        r12   k10 ; k10 = 24
.line	1213	loadk        r13   k11 ; k11 = 91
.line	1213	loadk        r14   k12 ; k12 = 26
.line	1213	loadk        r15   k13 ; k13 = 31
.line	1213	loadk        r16   k14 ; k14 = 217
.line	1213	loadk        r17   k15 ; k15 = 83
.line	1213	loadk        r18   k16 ; k16 = 38
.line	1213	loadk        r19   k17 ; k17 = 54
.line	1213	loadk        r20   k18 ; k18 = 137
.line	1213	loadk        r21   k19 ; k19 = 103
.line	1213	loadk        r22   k20 ; k20 = 102
.line	1213	loadk        r23   k21 ; k21 = 25
.line	1213	loadk        r24   k22 ; k22 = 99
.line	1213	loadk        r25   k23 ; k23 = 156
.line	1213	loadk        r26   k24 ; k24 = 76
.line	1213	loadk        r27   k25 ; k25 = 122
.line	1213	loadk        r28   k26 ; k26 = 113
.line	1213	loadk        r29   k26 ; k26 = 113
.line	1213	loadk        r30   k27 ; k27 = 23
.line	1213	loadk        r31   k28 ; k28 = 56
.line	1213	loadk        r32   k29 ; k29 = 199
.line	1213	loadk        r33   k30 ; k30 = 64
.line	1213	loadk        r34   k31 ; k31 = 21
.line	1213	loadk        r35   k32 ; k32 = 14
.line	1213	loadk        r36   k33 ; k33 = 174
.line	1213	loadk        r37    k3 ; k3 = 68
.line	1213	loadk        r38   k19 ; k19 = 103
.line	1213	loadk        r39   k34 ; k34 = 9
.line	1213	loadk        r40   k35 ; k35 = 84
.line	1213	loadk        r41   k36 ; k36 = 154
.line	1213	call          r3    39     2
.label	l45
.line	1213	move          r4    r1
.line	1213	call          r2     3     1
.line	1213	test          r1     1
.line	1213	jmp            0   l50
.line	1213	return        r0     1
.label	l50
.line	1213	self          r2    r0   k37 ; k37 = "GetWidgetObjectByRun" (truncated)
.line	1213	move          r4    r1
.line	1213	call          r2     3     2
.line	1213	test          r2     0
.line	1213	jmp            0   l64
.line	1213	gettable      r3    r2   k38 ; k38 = "bIsUMGInfo"
.line	1213	test          r3     0
.line	1213	jmp            0   l64
.line	1213	gettable      r3    r2   k39 ; k39 = "EnsureWidgetReady"
.line	1213	test          r3     0
.line	1213	jmp            0   l64
.line	1213	self          r3    r2   k39 ; k39 = "EnsureWidgetReady"
.line	1213	move          r5    r1
.line	1213	call          r3     3     1
.label	l64
.line	1213	return        r0     1
.line	1213	move          r0    r0
.line	1213	move          r0    r0
.line	1213	move          r0    r0
.line	1213	return        r0     1

.function	main/f57

.source	null
.linedefined	1224
.lastlinedefined	1226
.numparams	2
.is_vararg	0
.maxstacksize	3

.constant	k0	"CustomUIData"

.line	1224	gettable      r2    r0    k0 ; k0 = "CustomUIData"
.line	1224	gettable      r2    r2    r1
.line	1224	return        r2     2
.line	1224	return        r0     1
.line	1224	move          r0    r0
.line	1224	return        r0     1

.function	main/f58

.source	null
.linedefined	1228
.lastlinedefined	1270
.numparams	3
.is_vararg	0
.maxstacksize	52

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"type"
.constant	k1	83
.constant	k2	67
.constant	k3	15
.constant	k4	42
.constant	k5	181
.constant	k6	177
.constant	k7	"GetCreativeEntityManager"
.constant	k8	nil
.constant	k9	"tostring"
.constant	k10	"UUID2Key"
.constant	k11	"CDOToRuntimeIds"
.constant	k12	"next"
.constant	k13	"RuntimeToCDO"
.constant	k14	"CustomUIData"
.constant	k15	"Client"
.constant	k16	"GetWidgetObjectByRuntimeId"
.constant	k17	"GetWidgetByRuntimeId"
.constant	k18	"slua"
.constant	k19	"isValid"
.constant	k20	"UMGCanvasInfo"
.constant	k21	"require"
.constant	k22	"table"
.constant	k23	"concat"
.constant	k24	122
.constant	k25	87
.constant	k26	45
.constant	k27	156
.constant	k28	182
.constant	k29	48
.constant	k30	20
.constant	k31	22
.constant	k32	65
.constant	k33	13
.constant	k34	69
.constant	k35	245
.constant	k36	76
.constant	k37	30
.constant	k38	185
.constant	k39	111
.constant	k40	100
.constant	k41	29
.constant	k42	98
.constant	k43	146
.constant	k44	82
.constant	k45	101
.constant	k46	125
.constant	k47	21
.constant	k48	18
.constant	k49	195
.constant	k50	64
.constant	k51	23
.constant	k52	158
.constant	k53	103
.constant	k54	9
.constant	k55	68
.constant	k56	138
.constant	k57	71
.constant	k58	127
.constant	k59	126
.constant	k60	17
.constant	k61	60
.constant	k62	191
.constant	k63	174
.constant	k64	4
.constant	k65	115
.constant	k66	117
.constant	k67	109
.constant	k68	27
.constant	k69	14
.constant	k70	215
.constant	k71	74
.constant	k72	26
.constant	k73	168
.constant	k74	97
.constant	k75	164
.constant	k76	72
.constant	k77	110
.constant	k78	44
.constant	k79	91
.constant	k80	52
.constant	k81	233
.constant	k82	32
.constant	k83	3
.constant	k84	188
.constant	k85	113
.constant	k86	28
.constant	k87	24
.constant	k88	194
.constant	k89	81
.constant	k90	132
.constant	k91	102
.constant	k92	154
.constant	k93	85
.constant	k94	"BuildChildOOPByRuntimeId"

.line	1228	gettabup      r3    u0    k0 ; k0 = "type"
.line	1228	move          r4    r1
.line	1228	call          r3     2     2
.line	1228	getupval      r4    u1
.line	1228	loadk         r5    k1 ; k1 = 83
.line	1228	loadk         r6    k2 ; k2 = 67
.line	1228	loadk         r7    k3 ; k3 = 15
.line	1228	loadk         r8    k4 ; k4 = 42
.line	1228	loadk         r9    k5 ; k5 = 181
.line	1228	loadk        r10    k6 ; k6 = 177
.line	1228	call          r4     7     2
.line	1228	eq             1    r3    r4
.line	1228	jmp            0   l16
.line	1228	loadnil       r3     0
.line	1228	return        r3     2
.label	l16
.line	1228	gettabup      r3    u0    k7 ; k7 = "GetCreativeEntityMan" (truncated)
.line	1228	call          r3     1     2
.line	1228	eq             0    r3    k8 ; k8 = nil
.line	1228	jmp            0   l22
.line	1228	loadnil       r4     0
.line	1228	return        r4     2
.label	l22
.line	1228	gettabup      r4    u0    k9 ; k9 = "tostring"
.line	1228	self          r5    r3   k10 ; k10 = "UUID2Key"
.line	1228	move          r7    r1
.line	1228	call          r5     3     2
.line	1228	test          r5     1
.line	1228	jmp            0   l30
.line	1228	getupval      r5    u1
.line	1228	call          r5     1     2
.label	l30
.line	1228	call          r4     2     2
.line	1228	getupval      r5    u1
.line	1228	call          r5     1     2
.line	1228	eq             0    r4    r5
.line	1228	jmp            0   l37
.line	1228	loadnil       r5     0
.line	1228	return        r5     2
.label	l37
.line	1228	loadnil       r5     0
.line	1228	gettable      r6    r0   k11 ; k11 = "CDOToRuntimeIds"
.line	1228	test          r6     0
.line	1228	jmp            0   l43
.line	1228	gettable      r6    r0   k11 ; k11 = "CDOToRuntimeIds"
.line	1228	gettable      r6    r6    r4
.label	l43
.line	1228	test          r6     0
.line	1228	jmp            0   l55
.line	1228	gettabup      r7    u0   k12 ; k12 = "next"
.line	1228	move          r8    r6
.line	1228	call          r7     2     2
.line	1228	eq             1    r7    k8 ; k8 = nil
.line	1228	jmp            0   l55
.line	1228	gettabup      r7    u0   k12 ; k12 = "next"
.line	1228	move          r8    r6
.line	1228	call          r7     2     2
.line	1228	move          r5    r7
.line	1228	jmp            0   l63
.label	l55
.line	1228	gettable      r7    r0   k13 ; k13 = "RuntimeToCDO"
.line	1228	test          r7     0
.line	1228	jmp            0   l63
.line	1228	gettable      r7    r0   k13 ; k13 = "RuntimeToCDO"
.line	1228	gettable      r7    r7    r4
.line	1228	test          r7     0
.line	1228	jmp            0   l63
.line	1228	move          r5    r4
.label	l63
.line	1228	eq             0    r5    k8 ; k8 = nil
.line	1228	jmp            0   l67
.line	1228	loadnil       r7     0
.line	1228	return        r7     2
.label	l67
.line	1228	gettable      r7    r0   k14 ; k14 = "CustomUIData"
.line	1228	gettable      r7    r7    r5
.line	1228	eq             0    r7    k8 ; k8 = nil
.line	1228	jmp            0   l73
.line	1228	loadnil       r8     0
.line	1228	return        r8     2
.label	l73
.line	1228	gettabup      r8    u0   k15 ; k15 = "Client"
.line	1228	test          r8     0
.line	1228	jmp            0   l98
.line	1228	self          r8    r0   k16 ; k16 = "GetWidgetObjectByRun" (truncated)
.line	1228	move         r10    r5
.line	1228	call          r8     3     2
.line	1228	test          r8     0
.line	1228	jmp            0   l96
.line	1228	gettable      r9    r8   k17 ; k17 = "GetWidgetByRuntimeId"
.line	1228	test          r9     0
.line	1228	jmp            0   l96
.line	1228	self          r9    r8   k17 ; k17 = "GetWidgetByRuntimeId"
.line	1228	move         r11    r5
.line	1228	call          r9     3     2
.line	1228	test          r9     0
.line	1228	jmp            0   l96
.line	1228	gettabup     r10    u0   k18 ; k18 = "slua"
.line	1228	gettable     r10   r10   k19 ; k19 = "isValid"
.line	1228	move         r11    r9
.line	1228	call         r10     2     2
.line	1228	test         r10     0
.line	1228	jmp            0   l96
.line	1228	return        r9     2
.label	l96
.line	1228	loadnil       r9     0
.line	1228	return        r9     2
.label	l98
.line	1228	gettable      r8    r7   k20 ; k20 = "UMGCanvasInfo"
.line	1228	test          r8     0
.line	1228	jmp            0  l192
.line	1228	gettabup      r8    u0   k21 ; k21 = "require"
.line	1228	gettabup      r9    u0   k22 ; k22 = "table"
.line	1228	gettable      r9    r9   k23 ; k23 = "concat"
.line	1228	newtable     r10     1     0
.line	1228	getupval     r11    u1
.line	1228	loadk        r12   k24 ; k24 = 122
.line	1228	loadk        r13   k25 ; k25 = 87
.line	1228	loadk        r14    k3 ; k3 = 15
.line	1228	loadk        r15   k26 ; k26 = 45
.line	1228	loadk        r16   k27 ; k27 = 156
.line	1228	loadk        r17   k28 ; k28 = 182
.line	1228	loadk        r18   k29 ; k29 = 48
.line	1228	loadk        r19   k30 ; k30 = 20
.line	1228	loadk        r20   k31 ; k31 = 22
.line	1228	loadk        r21   k32 ; k32 = 65
.line	1228	loadk        r22   k33 ; k33 = 13
.line	1228	loadk        r23   k34 ; k34 = 69
.line	1228	loadk        r24   k35 ; k35 = 245
.line	1228	loadk        r25   k36 ; k36 = 76
.line	1228	loadk        r26   k31 ; k31 = 22
.line	1228	loadk        r27   k37 ; k37 = 30
.line	1228	loadk        r28   k38 ; k38 = 185
.line	1228	loadk        r29   k39 ; k39 = 111
.line	1228	loadk        r30   k40 ; k40 = 100
.line	1228	loadk        r31   k41 ; k41 = 29
.line	1228	loadk        r32   k42 ; k42 = 98
.line	1228	loadk        r33   k43 ; k43 = 146
.line	1228	loadk        r34   k44 ; k44 = 82
.line	1228	loadk        r35   k39 ; k39 = 111
.line	1228	loadk        r36   k45 ; k45 = 101
.line	1228	loadk        r37   k46 ; k46 = 125
.line	1228	loadk        r38   k47 ; k47 = 21
.line	1228	loadk        r39   k48 ; k48 = 18
.line	1228	loadk        r40   k49 ; k49 = 195
.line	1228	loadk        r41   k50 ; k50 = 64
.line	1228	loadk        r42   k51 ; k51 = 23
.line	1228	loadk        r43   k32 ; k32 = 65
.line	1228	loadk        r44   k52 ; k52 = 158
.line	1228	loadk        r45   k40 ; k40 = 100
.line	1228	loadk        r46   k53 ; k53 = 103
.line	1228	loadk        r47   k54 ; k54 = 9
.line	1228	loadk        r48   k55 ; k55 = 68
.line	1228	loadk        r49   k56 ; k56 = 138
.line	1228	loadk        r50   k57 ; k57 = 71
.line	1228	loadk        r51   k58 ; k58 = 127
.line	1228	call         r11    41     2
.line	1228	getupval     r12    u1
.line	1228	loadk        r13   k59 ; k59 = 126
.line	1228	loadk        r14    k2 ; k2 = 67
.line	1228	loadk        r15   k60 ; k60 = 17
.line	1228	loadk        r16   k61 ; k61 = 60
.line	1228	loadk        r17   k62 ; k62 = 191
.line	1228	loadk        r18   k63 ; k63 = 174
.line	1228	loadk        r19   k64 ; k64 = 4
.line	1228	loadk        r20   k65 ; k65 = 115
.line	1228	loadk        r21   k66 ; k66 = 117
.line	1228	loadk        r22   k67 ; k67 = 109
.line	1228	loadk        r23   k68 ; k68 = 27
.line	1228	loadk        r24   k69 ; k69 = 14
.line	1228	loadk        r25   k70 ; k70 = 215
.line	1228	loadk        r26   k71 ; k71 = 74
.line	1228	loadk        r27   k72 ; k72 = 26
.line	1228	loadk        r28   k54 ; k54 = 9
.line	1228	loadk        r29   k73 ; k73 = 168
.line	1228	loadk        r30    k1 ; k1 = 83
.line	1228	loadk        r31   k74 ; k74 = 97
.line	1228	loadk        r32   k41 ; k41 = 29
.line	1228	loadk        r33   k44 ; k44 = 82
.line	1228	loadk        r34   k75 ; k75 = 164
.line	1228	loadk        r35   k76 ; k76 = 72
.line	1228	loadk        r36   k77 ; k77 = 110
.line	1228	loadk        r37   k78 ; k78 = 44
.line	1228	loadk        r38   k79 ; k79 = 91
.line	1228	loadk        r39   k33 ; k33 = 13
.line	1228	loadk        r40   k80 ; k80 = 52
.line	1228	loadk        r41   k81 ; k81 = 233
.line	1228	loadk        r42   k59 ; k59 = 126
.line	1228	loadk        r43   k82 ; k82 = 32
.line	1228	loadk        r44   k83 ; k83 = 3
.line	1228	loadk        r45   k84 ; k84 = 188
.line	1228	loadk        r46   k45 ; k45 = 101
.line	1228	loadk        r47   k85 ; k85 = 113
.line	1228	call         r12    36     0
.line	1228	setlist      r10     0     1
.line	1228	call          r9     2     2
.line	1228	call          r8     2     2
.line	1228	move          r9    r8
.line	1228	move         r10    r2
.line	1228	move         r11    r1
.line	1228	tailcall      r9     3
.line	1228	return        r9     0
.label	l192
.line	1228	gettabup      r8    u0   k21 ; k21 = "require"
.line	1228	gettabup      r9    u0   k22 ; k22 = "table"
.line	1228	gettable      r9    r9   k23 ; k23 = "concat"
.line	1228	newtable     r10     1     0
.line	1228	getupval     r11    u1
.line	1228	loadk        r12   k24 ; k24 = 122
.line	1228	loadk        r13   k25 ; k25 = 87
.line	1228	loadk        r14    k3 ; k3 = 15
.line	1228	loadk        r15   k26 ; k26 = 45
.line	1228	loadk        r16   k27 ; k27 = 156
.line	1228	loadk        r17   k28 ; k28 = 182
.line	1228	loadk        r18   k29 ; k29 = 48
.line	1228	loadk        r19   k30 ; k30 = 20
.line	1228	loadk        r20   k31 ; k31 = 22
.line	1228	loadk        r21   k32 ; k32 = 65
.line	1228	loadk        r22   k33 ; k33 = 13
.line	1228	loadk        r23   k34 ; k34 = 69
.line	1228	loadk        r24   k35 ; k35 = 245
.line	1228	loadk        r25   k36 ; k36 = 76
.line	1228	loadk        r26   k31 ; k31 = 22
.line	1228	loadk        r27   k37 ; k37 = 30
.line	1228	loadk        r28   k38 ; k38 = 185
.line	1228	loadk        r29   k39 ; k39 = 111
.line	1228	loadk        r30   k40 ; k40 = 100
.line	1228	loadk        r31   k41 ; k41 = 29
.line	1228	loadk        r32   k42 ; k42 = 98
.line	1228	loadk        r33   k43 ; k43 = 146
.line	1228	loadk        r34   k44 ; k44 = 82
.line	1228	loadk        r35   k39 ; k39 = 111
.line	1228	loadk        r36   k45 ; k45 = 101
.line	1228	loadk        r37   k46 ; k46 = 125
.line	1228	loadk        r38   k47 ; k47 = 21
.line	1228	loadk        r39   k48 ; k48 = 18
.line	1228	loadk        r40   k49 ; k49 = 195
.line	1228	loadk        r41   k50 ; k50 = 64
.line	1228	loadk        r42   k51 ; k51 = 23
.line	1228	loadk        r43   k32 ; k32 = 65
.line	1228	loadk        r44   k52 ; k52 = 158
.line	1228	loadk        r45   k40 ; k40 = 100
.line	1228	loadk        r46   k53 ; k53 = 103
.line	1228	loadk        r47   k54 ; k54 = 9
.line	1228	loadk        r48   k55 ; k55 = 68
.line	1228	loadk        r49   k56 ; k56 = 138
.line	1228	loadk        r50   k57 ; k57 = 71
.line	1228	loadk        r51   k58 ; k58 = 127
.line	1228	call         r11    41     2
.line	1228	getupval     r12    u1
.line	1228	loadk        r13   k59 ; k59 = 126
.line	1228	loadk        r14    k2 ; k2 = 67
.line	1228	loadk        r15   k60 ; k60 = 17
.line	1228	loadk        r16   k61 ; k61 = 60
.line	1228	loadk        r17   k62 ; k62 = 191
.line	1228	loadk        r18   k63 ; k63 = 174
.line	1228	loadk        r19   k64 ; k64 = 4
.line	1228	loadk        r20   k65 ; k65 = 115
.line	1228	loadk        r21   k66 ; k66 = 117
.line	1228	loadk        r22   k67 ; k67 = 109
.line	1228	loadk        r23   k86 ; k86 = 28
.line	1228	loadk        r24   k87 ; k87 = 24
.line	1228	loadk        r25   k88 ; k88 = 194
.line	1228	loadk        r26   k89 ; k89 = 81
.line	1228	loadk        r27   k37 ; k37 = 30
.line	1228	loadk        r28    k4 ; k4 = 42
.line	1228	loadk        r29   k90 ; k90 = 132
.line	1228	loadk        r30    k1 ; k1 = 83
.line	1228	loadk        r31   k91 ; k91 = 102
.line	1228	loadk        r32   k60 ; k60 = 17
.line	1228	loadk        r33   k36 ; k36 = 76
.line	1228	loadk        r34   k92 ; k92 = 154
.line	1228	loadk        r35   k93 ; k93 = 85
.line	1228	loadk        r36   k65 ; k65 = 115
.line	1228	call         r12    25     0
.line	1228	setlist      r10     0     1
.line	1228	call          r9     2     2
.line	1228	call          r8     2     2
.line	1228	gettable      r9    r8   k94 ; k94 = "BuildChildOOPByRunti" (truncated)
.line	1228	move         r10    r2
.line	1228	move         r11    r5
.line	1228	move         r12    r7
.line	1228	tailcall      r9     4
.line	1228	return        r9     0
.line	1228	return        r0     1
.line	1228	move          r0    r0
.line	1228	move          r0    r0
.line	1228	move          r0    r0
.line	1228	move          r0    r0
.line	1228	return        r0     1

.function	main/f59

.source	null
.linedefined	1272
.lastlinedefined	1294
.numparams	1
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"require"
.constant	k2	94
.constant	k3	90
.constant	k4	11
.constant	k5	45
.constant	k6	190
.constant	k7	183
.constant	k8	127
.constant	k9	89
.constant	k10	52
.constant	k11	67
.constant	k12	4
.constant	k13	216
.constant	k14	16
.constant	k15	6
.constant	k16	22
.constant	k17	146
.constant	k18	115
.constant	k19	102
.constant	k20	17
.constant	k21	76
.constant	k22	"table"
.constant	k23	"concat"
.constant	k24	122
.constant	k25	87
.constant	k26	15
.constant	k27	156
.constant	k28	182
.constant	k29	48
.constant	k30	20
.constant	k31	65
.constant	k32	13
.constant	k33	69
.constant	k34	244
.constant	k35	95
.constant	k36	0
.constant	k37	26
.constant	k38	128
.constant	k39	105
.constant	k40	118
.constant	k41	86
.constant	k42	99
.constant	k43	103
.constant	k44	36
.constant	k45	80
.constant	k46	46
.constant	k47	239
.constant	k48	42
.constant	k49	1
.constant	k50	154
.constant	k51	119
.constant	k52	111
.constant	k53	101
.constant	k54	170
.constant	k55	117
.constant	k56	82
.constant	k57	"GetMainControlPanelTochButton"
.constant	k58	"CreativeCustomUILayer"
.constant	k59	"print"
.constant	k60	"bWriteLog"
.constant	k61	126
.constant	k62	68
.constant	k63	7
.constant	k64	41
.constant	k65	164
.constant	k66	39
.constant	k67	24
.constant	k68	91
.constant	k69	31
.constant	k70	217
.constant	k71	83
.constant	k72	38
.constant	k73	54
.constant	k74	137
.constant	k75	25
.constant	k76	113
.constant	k77	108
.constant	k78	28
.constant	k79	201
.constant	k80	92
.constant	k81	23
.constant	k82	40
.constant	k83	188
.constant	k84	123
.constant	k85	43
.constant	k86	81
.constant	k87	141
.constant	k88	71
.constant	k89	78
.constant	k90	50
.constant	k91	181
.constant	k92	227
.constant	k93	64
.constant	k94	74
.constant	k95	161
.constant	k96	159
.constant	k97	59
.constant	k98	14
.constant	k99	210
.constant	k100	12
.constant	k101	253
.constant	k102	121
.constant	k103	112
.constant	k104	72
.constant	k105	145
.constant	k106	84
.constant	k107	73
.constant	k108	147
.constant	k109	34
.constant	k110	60
.constant	k111	250
.constant	k112	10
.constant	k113	191
.constant	k114	157
.constant	k115	"GetLocalSize"
.constant	k116	"X"
.constant	k117	"Y"
.constant	k118	29
.constant	k119	85
.constant	k120	56
.constant	k121	79
.constant	k122	5
.constant	k123	223
.constant	k124	133
.constant	k125	"tostring"
.constant	k126	"GameCanvasSize"
.constant	k127	"string"
.constant	k128	"format"
.constant	k129	9
.constant	k130	93
.constant	k131	139
.constant	k132	27
.constant	k133	"ServerRPC_ReportGameCanvasSize"

.line	1272	gettabup      r1    u0    k0 ; k0 = "Client"
.line	1272	test          r1     1
.line	1272	jmp            0    l5
.line	1272	return        r0     1
.label	l5
.line	1272	gettabup      r1    u0    k1 ; k1 = "require"
.line	1272	getupval      r2    u1
.line	1272	loadk         r3    k2 ; k2 = 94
.line	1272	loadk         r4    k3 ; k3 = 90
.line	1272	loadk         r5    k4 ; k4 = 11
.line	1272	loadk         r6    k5 ; k5 = 45
.line	1272	loadk         r7    k6 ; k6 = 190
.line	1272	loadk         r8    k7 ; k7 = 183
.line	1272	loadk         r9    k8 ; k8 = 127
.line	1272	loadk        r10    k9 ; k9 = 89
.line	1272	loadk        r11   k10 ; k10 = 52
.line	1272	loadk        r12   k11 ; k11 = 67
.line	1272	loadk        r13   k12 ; k12 = 4
.line	1272	loadk        r14   k12 ; k12 = 4
.line	1272	loadk        r15   k13 ; k13 = 216
.line	1272	loadk        r16   k14 ; k14 = 16
.line	1272	loadk        r17   k15 ; k15 = 6
.line	1272	loadk        r18   k16 ; k16 = 22
.line	1272	loadk        r19   k17 ; k17 = 146
.line	1272	loadk        r20   k18 ; k18 = 115
.line	1272	loadk        r21   k19 ; k19 = 102
.line	1272	loadk        r22   k20 ; k20 = 17
.line	1272	loadk        r23   k21 ; k21 = 76
.line	1272	call          r2    22     2
.line	1272	call          r1     2     2
.line	1272	gettabup      r2    u0    k1 ; k1 = "require"
.line	1272	gettabup      r3    u0   k22 ; k22 = "table"
.line	1272	gettable      r3    r3   k23 ; k23 = "concat"
.line	1272	newtable      r4     1     0
.line	1272	getupval      r5    u1
.line	1272	loadk         r6   k24 ; k24 = 122
.line	1272	loadk         r7   k25 ; k25 = 87
.line	1272	loadk         r8   k26 ; k26 = 15
.line	1272	loadk         r9    k5 ; k5 = 45
.line	1272	loadk        r10   k27 ; k27 = 156
.line	1272	loadk        r11   k28 ; k28 = 182
.line	1272	loadk        r12   k29 ; k29 = 48
.line	1272	loadk        r13   k30 ; k30 = 20
.line	1272	loadk        r14   k16 ; k16 = 22
.line	1272	loadk        r15   k31 ; k31 = 65
.line	1272	loadk        r16   k32 ; k32 = 13
.line	1272	loadk        r17   k33 ; k33 = 69
.line	1272	loadk        r18   k34 ; k34 = 244
.line	1272	loadk        r19   k35 ; k35 = 95
.line	1272	loadk        r20   k36 ; k36 = 0
.line	1272	loadk        r21   k37 ; k37 = 26
.line	1272	loadk        r22   k38 ; k38 = 128
.line	1272	loadk        r23   k39 ; k39 = 105
.line	1272	loadk        r24   k40 ; k40 = 118
.line	1272	loadk        r25   k41 ; k41 = 86
.line	1272	loadk        r26   k42 ; k42 = 99
.line	1272	loadk        r27   k27 ; k27 = 156
.line	1272	loadk        r28   k21 ; k21 = 76
.line	1272	loadk        r29   k43 ; k43 = 103
.line	1272	loadk        r30   k44 ; k44 = 36
.line	1272	loadk        r31   k45 ; k45 = 80
.line	1272	loadk        r32   k25 ; k25 = 87
.line	1272	loadk        r33   k46 ; k46 = 46
.line	1272	loadk        r34   k47 ; k47 = 239
.line	1272	loadk        r35   k36 ; k36 = 0
.line	1272	loadk        r36   k48 ; k48 = 42
.line	1272	loadk        r37   k49 ; k49 = 1
.line	1272	loadk        r38   k50 ; k50 = 154
.line	1272	loadk        r39   k51 ; k51 = 119
.line	1272	loadk        r40   k52 ; k52 = 111
.line	1272	loadk        r41   k32 ; k32 = 13
.line	1272	loadk        r42   k53 ; k53 = 101
.line	1272	loadk        r43   k54 ; k54 = 170
.line	1272	loadk        r44   k53 ; k53 = 101
.line	1272	loadk        r45   k55 ; k55 = 117
.line	1272	call          r5    41     2
.line	1272	getupval      r6    u1
.line	1272	loadk         r7   k56 ; k56 = 82
.line	1272	loadk         r8    k3 ; k3 = 90
.line	1272	loadk         r9   k20 ; k20 = 17
.line	1272	call          r6     4     0
.line	1272	setlist       r4     0     1
.line	1272	call          r3     2     2
.line	1272	call          r2     2     2
.line	1272	gettable      r3    r2   k57 ; k57 = "GetMainControlPanelT" (truncated)
.line	1272	call          r3     1     2
.line	1272	test          r3     0
.line	1272	jmp            0   l91
.line	1272	gettable      r4    r3   k58 ; k58 = "CreativeCustomUILaye" (truncated)
.line	1272	test          r4     1
.line	1272	jmp            0  l212
.label	l91
.line	1272	gettabup      r4    u0   k59 ; k59 = "print"
.line	1272	gettabup      r5    u0   k60 ; k60 = "bWriteLog"
.line	1272	test          r5     0
.line	1272	jmp            0  l210
.line	1272	gettabup      r5    u0   k22 ; k22 = "table"
.line	1272	gettable      r5    r5   k23 ; k23 = "concat"
.line	1272	newtable      r6     2     0
.line	1272	getupval      r7    u1
.line	1272	loadk         r8   k61 ; k61 = 126
.line	1272	loadk         r9   k62 ; k62 = 68
.line	1272	loadk        r10   k63 ; k63 = 7
.line	1272	loadk        r11   k64 ; k64 = 41
.line	1272	loadk        r12   k65 ; k65 = 164
.line	1272	loadk        r13   k54 ; k54 = 170
.line	1272	loadk        r14   k66 ; k66 = 39
.line	1272	loadk        r15   k35 ; k35 = 95
.line	1272	loadk        r16   k67 ; k67 = 24
.line	1272	loadk        r17   k68 ; k68 = 91
.line	1272	loadk        r18   k37 ; k37 = 26
.line	1272	loadk        r19   k69 ; k69 = 31
.line	1272	loadk        r20   k70 ; k70 = 217
.line	1272	loadk        r21   k71 ; k71 = 83
.line	1272	loadk        r22   k72 ; k72 = 38
.line	1272	loadk        r23   k73 ; k73 = 54
.line	1272	loadk        r24   k74 ; k74 = 137
.line	1272	loadk        r25   k43 ; k43 = 103
.line	1272	loadk        r26   k19 ; k19 = 102
.line	1272	loadk        r27   k75 ; k75 = 25
.line	1272	loadk        r28   k42 ; k42 = 99
.line	1272	loadk        r29   k27 ; k27 = 156
.line	1272	loadk        r30   k21 ; k21 = 76
.line	1272	loadk        r31   k24 ; k24 = 122
.line	1272	loadk        r32   k76 ; k76 = 113
.line	1272	loadk        r33   k77 ; k77 = 108
.line	1272	loadk        r34   k78 ; k78 = 28
.line	1272	loadk        r35    k4 ; k4 = 11
.line	1272	loadk        r36   k79 ; k79 = 201
.line	1272	loadk        r37   k80 ; k80 = 92
.line	1272	loadk        r38   k81 ; k81 = 23
.line	1272	loadk        r39   k82 ; k82 = 40
.line	1272	loadk        r40   k83 ; k83 = 188
.line	1272	loadk        r41   k84 ; k84 = 123
.line	1272	loadk        r42   k43 ; k43 = 103
.line	1272	loadk        r43   k85 ; k85 = 43
.line	1272	loadk        r44   k86 ; k86 = 81
.line	1272	loadk        r45   k87 ; k87 = 141
.line	1272	loadk        r46   k88 ; k88 = 71
.line	1272	loadk        r47   k84 ; k84 = 123
.line	1272	call          r7    41     2
.line	1272	getupval      r8    u1
.line	1272	loadk         r9   k89 ; k89 = 78
.line	1272	loadk        r10   k53 ; k53 = 101
.line	1272	loadk        r11    k4 ; k4 = 11
.line	1272	loadk        r12   k90 ; k90 = 50
.line	1272	loadk        r13   k91 ; k91 = 181
.line	1272	loadk        r14   k92 ; k92 = 227
.line	1272	loadk        r15   k78 ; k78 = 28
.line	1272	loadk        r16   k68 ; k68 = 91
.line	1272	loadk        r17   k90 ; k90 = 50
.line	1272	loadk        r18   k93 ; k93 = 64
.line	1272	loadk        r19   k48 ; k48 = 42
.line	1272	loadk        r20   k12 ; k12 = 4
.line	1272	loadk        r21   k13 ; k13 = 216
.line	1272	loadk        r22   k94 ; k94 = 74
.line	1272	loadk        r23   k49 ; k49 = 1
.line	1272	loadk        r24   k14 ; k14 = 16
.line	1272	loadk        r25   k95 ; k95 = 161
.line	1272	loadk        r26   k41 ; k41 = 86
.line	1272	loadk        r27   k18 ; k18 = 115
.line	1272	loadk        r28   k16 ; k16 = 22
.line	1272	loadk        r29   k33 ; k33 = 69
.line	1272	loadk        r30   k96 ; k96 = 159
.line	1272	loadk        r31   k55 ; k55 = 117
.line	1272	loadk        r32   k53 ; k53 = 101
.line	1272	loadk        r33   k82 ; k82 = 40
.line	1272	loadk        r34   k41 ; k41 = 86
.line	1272	loadk        r35   k97 ; k97 = 59
.line	1272	loadk        r36   k98 ; k98 = 14
.line	1272	loadk        r37   k99 ; k99 = 210
.line	1272	loadk        r38    k3 ; k3 = 90
.line	1272	loadk        r39  k100 ; k100 = 12
.line	1272	loadk        r40   k49 ; k49 = 1
.line	1272	loadk        r41  k101 ; k101 = 253
.line	1272	loadk        r42  k102 ; k102 = 121
.line	1272	loadk        r43  k103 ; k103 = 112
.line	1272	loadk        r44  k104 ; k104 = 72
.line	1272	loadk        r45   k18 ; k18 = 115
.line	1272	loadk        r46  k105 ; k105 = 145
.line	1272	loadk        r47  k106 ; k106 = 84
.line	1272	loadk        r48   k84 ; k84 = 123
.line	1272	call          r8    41     2
.line	1272	getupval      r9    u1
.line	1272	loadk        r10  k107 ; k107 = 73
.line	1272	loadk        r11   k35 ; k35 = 95
.line	1272	loadk        r12   k30 ; k30 = 20
.line	1272	loadk        r13    k5 ; k5 = 45
.line	1272	loadk        r14  k108 ; k108 = 147
.line	1272	loadk        r15   k28 ; k28 = 182
.line	1272	loadk        r16  k109 ; k109 = 34
.line	1272	loadk        r17   k89 ; k89 = 78
.line	1272	loadk        r18   k10 ; k10 = 52
.line	1272	loadk        r19   k11 ; k11 = 67
.line	1272	loadk        r20  k110 ; k110 = 60
.line	1272	loadk        r21  k109 ; k109 = 34
.line	1272	loadk        r22  k111 ; k111 = 250
.line	1272	loadk        r23   k35 ; k35 = 95
.line	1272	loadk        r24  k112 ; k112 = 10
.line	1272	loadk        r25   k37 ; k37 = 26
.line	1272	loadk        r26  k113 ; k113 = 191
.line	1272	loadk        r27   k72 ; k72 = 38
.line	1272	loadk        r28   k84 ; k84 = 123
.line	1272	loadk        r29    k4 ; k4 = 11
.line	1272	loadk        r30   k36 ; k36 = 0
.line	1272	loadk        r31  k114 ; k114 = 157
.line	1272	loadk        r32  k104 ; k104 = 72
.line	1272	loadk        r33   k19 ; k19 = 102
.line	1272	call          r9    25     0
.line	1272	setlist       r6     0     1
.line	1272	call          r5     2     2
.label	l210
.line	1272	call          r4     2     1
.line	1272	return        r0     1
.label	l212
.line	1272	gettable      r4    r1  k115 ; k115 = "GetLocalSize"
.line	1272	gettable      r5    r3   k58 ; k58 = "CreativeCustomUILaye" (truncated)
.line	1272	call          r4     2     2
.line	1272	test          r4     0
.line	1272	jmp            0  l223
.line	1272	gettable      r5    r4  k116 ; k116 = "X"
.line	1272	le             1    r5   k36 ; k36 = 0
.line	1272	jmp            0  l223
.line	1272	gettable      r5    r4  k117 ; k117 = "Y"
.line	1272	le             0    r5   k36 ; k36 = 0
.line	1272	jmp            0  l310
.label	l223
.line	1272	gettabup      r5    u0   k59 ; k59 = "print"
.line	1272	gettabup      r6    u0   k60 ; k60 = "bWriteLog"
.line	1272	test          r6     0
.line	1272	jmp            0  l308
.line	1272	gettabup      r6    u0   k22 ; k22 = "table"
.line	1272	gettable      r6    r6   k23 ; k23 = "concat"
.line	1272	newtable      r7     1     0
.line	1272	getupval      r8    u1
.line	1272	loadk         r9   k61 ; k61 = 126
.line	1272	loadk        r10   k62 ; k62 = 68
.line	1272	loadk        r11   k63 ; k63 = 7
.line	1272	loadk        r12   k64 ; k64 = 41
.line	1272	loadk        r13   k65 ; k65 = 164
.line	1272	loadk        r14   k54 ; k54 = 170
.line	1272	loadk        r15   k66 ; k66 = 39
.line	1272	loadk        r16   k35 ; k35 = 95
.line	1272	loadk        r17   k67 ; k67 = 24
.line	1272	loadk        r18   k68 ; k68 = 91
.line	1272	loadk        r19   k37 ; k37 = 26
.line	1272	loadk        r20   k69 ; k69 = 31
.line	1272	loadk        r21   k70 ; k70 = 217
.line	1272	loadk        r22   k71 ; k71 = 83
.line	1272	loadk        r23   k72 ; k72 = 38
.line	1272	loadk        r24   k73 ; k73 = 54
.line	1272	loadk        r25   k74 ; k74 = 137
.line	1272	loadk        r26   k43 ; k43 = 103
.line	1272	loadk        r27   k19 ; k19 = 102
.line	1272	loadk        r28   k75 ; k75 = 25
.line	1272	loadk        r29   k42 ; k42 = 99
.line	1272	loadk        r30   k27 ; k27 = 156
.line	1272	loadk        r31   k21 ; k21 = 76
.line	1272	loadk        r32   k24 ; k24 = 122
.line	1272	loadk        r33   k76 ; k76 = 113
.line	1272	loadk        r34   k77 ; k77 = 108
.line	1272	loadk        r35   k78 ; k78 = 28
.line	1272	loadk        r36    k4 ; k4 = 11
.line	1272	loadk        r37   k79 ; k79 = 201
.line	1272	loadk        r38   k80 ; k80 = 92
.line	1272	loadk        r39   k81 ; k81 = 23
.line	1272	loadk        r40   k82 ; k82 = 40
.line	1272	loadk        r41   k83 ; k83 = 188
.line	1272	loadk        r42   k84 ; k84 = 123
.line	1272	loadk        r43   k43 ; k43 = 103
.line	1272	loadk        r44   k85 ; k85 = 43
.line	1272	loadk        r45   k86 ; k86 = 81
.line	1272	loadk        r46   k87 ; k87 = 141
.line	1272	loadk        r47   k88 ; k88 = 71
.line	1272	loadk        r48   k84 ; k84 = 123
.line	1272	call          r8    41     2
.line	1272	getupval      r9    u1
.line	1272	loadk        r10   k89 ; k89 = 78
.line	1272	loadk        r11   k53 ; k53 = 101
.line	1272	loadk        r12    k4 ; k4 = 11
.line	1272	loadk        r13   k90 ; k90 = 50
.line	1272	loadk        r14   k91 ; k91 = 181
.line	1272	loadk        r15   k92 ; k92 = 227
.line	1272	loadk        r16  k118 ; k118 = 29
.line	1272	loadk        r17  k119 ; k119 = 85
.line	1272	loadk        r18  k120 ; k120 = 56
.line	1272	loadk        r19  k121 ; k121 = 79
.line	1272	loadk        r20  k122 ; k122 = 5
.line	1272	loadk        r21  k120 ; k120 = 56
.line	1272	loadk        r22  k123 ; k123 = 223
.line	1272	loadk        r23   k62 ; k62 = 68
.line	1272	loadk        r24   k16 ; k16 = 22
.line	1272	loadk        r25   k35 ; k35 = 95
.line	1272	loadk        r26   k65 ; k65 = 164
.line	1272	loadk        r27   k55 ; k55 = 117
.line	1272	loadk        r28   k90 ; k90 = 50
.line	1272	loadk        r29   k20 ; k20 = 17
.line	1272	loadk        r30   k89 ; k89 = 78
.line	1272	loadk        r31  k124 ; k124 = 133
.line	1272	loadk        r32   k93 ; k93 = 64
.line	1272	loadk        r33   k19 ; k19 = 102
.line	1272	loadk        r34  k109 ; k109 = 34
.line	1272	loadk        r35    k3 ; k3 = 90
.line	1272	loadk        r36   k11 ; k11 = 67
.line	1272	loadk        r37   k68 ; k68 = 91
.line	1272	call          r9    29     0
.line	1272	setlist       r7     0     1
.line	1272	call          r6     2     2
.line	1272	gettabup      r7    u0  k125 ; k125 = "tostring"
.line	1272	move          r8    r4
.line	1272	call          r7     2     2
.line	1272	concat        r6    r6    r7
.label	l308
.line	1272	call          r5     2     1
.line	1272	return        r0     1
.label	l310
.line	1272	newtable      r5     0     2
.line	1272	gettable      r6    r4  k116 ; k116 = "X"
.line	1272	settable      r5  k116    r6 ; k116 = "X"
.line	1272	gettable      r6    r4  k117 ; k117 = "Y"
.line	1272	settable      r5  k117    r6 ; k117 = "Y"
.line	1272	settable      r0  k126    r5 ; k126 = "GameCanvasSize"
.line	1272	gettabup      r5    u0   k59 ; k59 = "print"
.line	1272	gettabup      r6    u0   k60 ; k60 = "bWriteLog"
.line	1272	test          r6     0
.line	1272	jmp            0  l393
.line	1272	gettabup      r6    u0  k127 ; k127 = "string"
.line	1272	gettable      r6    r6  k128 ; k128 = "format"
.line	1272	gettabup      r7    u0   k22 ; k22 = "table"
.line	1272	gettable      r7    r7   k23 ; k23 = "concat"
.line	1272	newtable      r8     1     0
.line	1272	getupval      r9    u1
.line	1272	loadk        r10   k61 ; k61 = 126
.line	1272	loadk        r11   k62 ; k62 = 68
.line	1272	loadk        r12   k63 ; k63 = 7
.line	1272	loadk        r13   k64 ; k64 = 41
.line	1272	loadk        r14   k65 ; k65 = 164
.line	1272	loadk        r15   k54 ; k54 = 170
.line	1272	loadk        r16   k66 ; k66 = 39
.line	1272	loadk        r17   k35 ; k35 = 95
.line	1272	loadk        r18   k67 ; k67 = 24
.line	1272	loadk        r19   k68 ; k68 = 91
.line	1272	loadk        r20   k37 ; k37 = 26
.line	1272	loadk        r21   k69 ; k69 = 31
.line	1272	loadk        r22   k70 ; k70 = 217
.line	1272	loadk        r23   k71 ; k71 = 83
.line	1272	loadk        r24   k72 ; k72 = 38
.line	1272	loadk        r25   k73 ; k73 = 54
.line	1272	loadk        r26   k74 ; k74 = 137
.line	1272	loadk        r27   k43 ; k43 = 103
.line	1272	loadk        r28   k19 ; k19 = 102
.line	1272	loadk        r29   k75 ; k75 = 25
.line	1272	loadk        r30   k42 ; k42 = 99
.line	1272	loadk        r31   k27 ; k27 = 156
.line	1272	loadk        r32   k21 ; k21 = 76
.line	1272	loadk        r33   k24 ; k24 = 122
.line	1272	loadk        r34   k76 ; k76 = 113
.line	1272	loadk        r35   k77 ; k77 = 108
.line	1272	loadk        r36   k78 ; k78 = 28
.line	1272	loadk        r37    k4 ; k4 = 11
.line	1272	loadk        r38   k79 ; k79 = 201
.line	1272	loadk        r39   k80 ; k80 = 92
.line	1272	loadk        r40   k81 ; k81 = 23
.line	1272	loadk        r41   k82 ; k82 = 40
.line	1272	loadk        r42   k83 ; k83 = 188
.line	1272	loadk        r43   k84 ; k84 = 123
.line	1272	loadk        r44   k43 ; k43 = 103
.line	1272	loadk        r45   k85 ; k85 = 43
.line	1272	loadk        r46   k86 ; k86 = 81
.line	1272	loadk        r47   k87 ; k87 = 141
.line	1272	loadk        r48   k88 ; k88 = 71
.line	1272	loadk        r49   k84 ; k84 = 123
.line	1272	call          r9    41     2
.line	1272	getupval     r10    u1
.line	1272	loadk        r11   k89 ; k89 = 78
.line	1272	loadk        r12   k53 ; k53 = 101
.line	1272	loadk        r13    k4 ; k4 = 11
.line	1272	loadk        r14   k90 ; k90 = 50
.line	1272	loadk        r15   k91 ; k91 = 181
.line	1272	loadk        r16   k92 ; k92 = 227
.line	1272	loadk        r17  k129 ; k129 = 9
.line	1272	loadk        r18   k63 ; k63 = 7
.line	1272	loadk        r19   k61 ; k61 = 126
.line	1272	loadk        r20  k130 ; k130 = 93
.line	1272	loadk        r21  k107 ; k107 = 73
.line	1272	loadk        r22   k90 ; k90 = 50
.line	1272	loadk        r23  k131 ; k131 = 139
.line	1272	loadk        r24  k132 ; k132 = 27
.line	1272	loadk        r25   k36 ; k36 = 0
.line	1272	call         r10    16     0
.line	1272	setlist       r8     0     1
.line	1272	call          r7     2     2
.line	1272	gettabup      r8    u0  k125 ; k125 = "tostring"
.line	1272	gettable      r9    r4  k116 ; k116 = "X"
.line	1272	call          r8     2     2
.line	1272	gettabup      r9    u0  k125 ; k125 = "tostring"
.line	1272	gettable     r10    r4  k117 ; k117 = "Y"
.line	1272	call          r9     2     0
.line	1272	call          r6     0     2
.label	l393
.line	1272	call          r5     2     1
.line	1272	self          r5    r0  k133 ; k133 = "ServerRPC_ReportGame" (truncated)
.line	1272	gettable      r7    r4  k116 ; k116 = "X"
.line	1272	gettable      r8    r4  k117 ; k117 = "Y"
.line	1272	call          r5     4     1
.line	1272	return        r0     1
.line	1272	move          r0    r0
.line	1272	move          r0    r0
.line	1272	gettabup      r3    u0   k75 ; k75 = 25
.line	1272	return        r0     1

.function	main/f60

.source	null
.linedefined	1304
.lastlinedefined	1312
.numparams	3
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	0
.constant	k1	"print"
.constant	k2	"bWriteLog"
.constant	k3	"string"
.constant	k4	"format"
.constant	k5	"table"
.constant	k6	"concat"
.constant	k7	126
.constant	k8	68
.constant	k9	7
.constant	k10	41
.constant	k11	164
.constant	k12	170
.constant	k13	39
.constant	k14	95
.constant	k15	24
.constant	k16	91
.constant	k17	26
.constant	k18	31
.constant	k19	217
.constant	k20	83
.constant	k21	38
.constant	k22	54
.constant	k23	137
.constant	k24	103
.constant	k25	102
.constant	k26	25
.constant	k27	99
.constant	k28	156
.constant	k29	76
.constant	k30	122
.constant	k31	113
.constant	k32	109
.constant	k33	28
.constant	k34	9
.constant	k35	208
.constant	k36	75
.constant	k37	17
.constant	k38	61
.constant	k39	141
.constant	k40	85
.constant	k41	93
.constant	k42	58
.constant	k43	147
.constant	k44	94
.constant	k45	104
.constant	k46	73
.constant	k47	3
.constant	k48	37
.constant	k49	181
.constant	k50	128
.constant	k51	48
.constant	k52	84
.constant	k53	45
.constant	k54	79
.constant	k55	56
.constant	k56	223
.constant	k57	22
.constant	k58	100
.constant	k59	154
.constant	k60	69
.constant	k61	42
.constant	k62	87
.constant	k63	30
.constant	k64	134
.constant	k65	118
.constant	k66	74
.constant	k67	174
.constant	k68	21
.constant	k69	144
.constant	k70	"tostring"
.constant	k71	149
.constant	k72	59
.constant	k73	55
.constant	k74	11
.constant	k75	47
.constant	k76	"GameCanvasSize"
.constant	k77	"X"
.constant	k78	"Y"
.constant	k79	"bNeedCanvasSizeReport"
.constant	k80	false

.line	1304	test          r1     0
.line	1304	jmp            0    l9
.line	1304	test          r2     0
.line	1304	jmp            0    l9
.line	1304	le             1    r1    k0 ; k0 = 0
.line	1304	jmp            0    l9
.line	1304	le             0    r2    k0 ; k0 = 0
.line	1304	jmp            0  l111
.label	l9
.line	1304	gettabup      r3    u0    k1 ; k1 = "print"
.line	1304	gettabup      r4    u0    k2 ; k2 = "bWriteLog"
.line	1304	test          r4     0
.line	1304	jmp            0  l109
.line	1304	gettabup      r4    u0    k3 ; k3 = "string"
.line	1304	gettable      r4    r4    k4 ; k4 = "format"
.line	1304	gettabup      r5    u0    k5 ; k5 = "table"
.line	1304	gettable      r5    r5    k6 ; k6 = "concat"
.line	1304	newtable      r6     1     0
.line	1304	getupval      r7    u1
.line	1304	loadk         r8    k7 ; k7 = 126
.line	1304	loadk         r9    k8 ; k8 = 68
.line	1304	loadk        r10    k9 ; k9 = 7
.line	1304	loadk        r11   k10 ; k10 = 41
.line	1304	loadk        r12   k11 ; k11 = 164
.line	1304	loadk        r13   k12 ; k12 = 170
.line	1304	loadk        r14   k13 ; k13 = 39
.line	1304	loadk        r15   k14 ; k14 = 95
.line	1304	loadk        r16   k15 ; k15 = 24
.line	1304	loadk        r17   k16 ; k16 = 91
.line	1304	loadk        r18   k17 ; k17 = 26
.line	1304	loadk        r19   k18 ; k18 = 31
.line	1304	loadk        r20   k19 ; k19 = 217
.line	1304	loadk        r21   k20 ; k20 = 83
.line	1304	loadk        r22   k21 ; k21 = 38
.line	1304	loadk        r23   k22 ; k22 = 54
.line	1304	loadk        r24   k23 ; k23 = 137
.line	1304	loadk        r25   k24 ; k24 = 103
.line	1304	loadk        r26   k25 ; k25 = 102
.line	1304	loadk        r27   k26 ; k26 = 25
.line	1304	loadk        r28   k27 ; k27 = 99
.line	1304	loadk        r29   k28 ; k28 = 156
.line	1304	loadk        r30   k29 ; k29 = 76
.line	1304	loadk        r31   k30 ; k30 = 122
.line	1304	loadk        r32   k31 ; k31 = 113
.line	1304	loadk        r33   k32 ; k32 = 109
.line	1304	loadk        r34   k33 ; k33 = 28
.line	1304	loadk        r35   k34 ; k34 = 9
.line	1304	loadk        r36   k35 ; k35 = 208
.line	1304	loadk        r37   k36 ; k36 = 75
.line	1304	loadk        r38   k37 ; k37 = 17
.line	1304	loadk        r39   k38 ; k38 = 61
.line	1304	loadk        r40   k39 ; k39 = 141
.line	1304	loadk        r41   k40 ; k40 = 85
.line	1304	loadk        r42   k41 ; k41 = 93
.line	1304	loadk        r43   k42 ; k42 = 58
.line	1304	loadk        r44   k40 ; k40 = 85
.line	1304	loadk        r45   k43 ; k43 = 147
.line	1304	loadk        r46   k44 ; k44 = 94
.line	1304	loadk        r47   k45 ; k45 = 104
.line	1304	call          r7    41     2
.line	1304	getupval      r8    u1
.line	1304	loadk         r9   k46 ; k46 = 73
.line	1304	loadk        r10   k31 ; k31 = 113
.line	1304	loadk        r11   k47 ; k47 = 3
.line	1304	loadk        r12   k48 ; k48 = 37
.line	1304	loadk        r13   k49 ; k49 = 181
.line	1304	loadk        r14   k50 ; k50 = 128
.line	1304	loadk        r15   k51 ; k51 = 48
.line	1304	loadk        r16   k52 ; k52 = 84
.line	1304	loadk        r17   k53 ; k53 = 45
.line	1304	loadk        r18   k54 ; k54 = 79
.line	1304	loadk        r19   k17 ; k17 = 26
.line	1304	loadk        r20   k55 ; k55 = 56
.line	1304	loadk        r21   k56 ; k56 = 223
.line	1304	loadk        r22    k8 ; k8 = 68
.line	1304	loadk        r23   k57 ; k57 = 22
.line	1304	loadk        r24   k14 ; k14 = 95
.line	1304	loadk        r25   k11 ; k11 = 164
.line	1304	loadk        r26   k45 ; k45 = 104
.line	1304	loadk        r27   k58 ; k58 = 100
.line	1304	loadk        r28   k26 ; k26 = 25
.line	1304	loadk        r29   k29 ; k29 = 76
.line	1304	loadk        r30   k59 ; k59 = 154
.line	1304	loadk        r31   k60 ; k60 = 69
.line	1304	loadk        r32   k61 ; k61 = 42
.line	1304	loadk        r33   k55 ; k55 = 56
.line	1304	loadk        r34   k62 ; k62 = 87
.line	1304	loadk        r35   k47 ; k47 = 3
.line	1304	loadk        r36   k63 ; k63 = 30
.line	1304	loadk        r37   k64 ; k64 = 134
.line	1304	loadk        r38   k65 ; k65 = 118
.line	1304	loadk        r39   k44 ; k44 = 94
.line	1304	loadk        r40   k66 ; k66 = 74
.line	1304	loadk        r41   k67 ; k67 = 174
.line	1304	loadk        r42   k22 ; k22 = 54
.line	1304	loadk        r43   k16 ; k16 = 91
.line	1304	loadk        r44   k40 ; k40 = 85
.line	1304	loadk        r45   k68 ; k68 = 21
.line	1304	loadk        r46   k69 ; k69 = 144
.line	1304	call          r8    39     0
.line	1304	setlist       r6     0     1
.line	1304	call          r5     2     2
.line	1304	gettabup      r6    u0   k70 ; k70 = "tostring"
.line	1304	move          r7    r1
.line	1304	call          r6     2     2
.line	1304	gettabup      r7    u0   k70 ; k70 = "tostring"
.line	1304	move          r8    r2
.line	1304	call          r7     2     0
.line	1304	call          r4     0     2
.label	l109
.line	1304	call          r3     2     1
.line	1304	return        r0     1
.label	l111
.line	1304	gettabup      r3    u0    k1 ; k1 = "print"
.line	1304	gettabup      r4    u0    k2 ; k2 = "bWriteLog"
.line	1304	test          r4     0
.line	1304	jmp            0  l198
.line	1304	gettabup      r4    u0    k3 ; k3 = "string"
.line	1304	gettable      r4    r4    k4 ; k4 = "format"
.line	1304	gettabup      r5    u0    k5 ; k5 = "table"
.line	1304	gettable      r5    r5    k6 ; k6 = "concat"
.line	1304	newtable      r6     1     0
.line	1304	getupval      r7    u1
.line	1304	loadk         r8    k7 ; k7 = 126
.line	1304	loadk         r9    k8 ; k8 = 68
.line	1304	loadk        r10    k9 ; k9 = 7
.line	1304	loadk        r11   k10 ; k10 = 41
.line	1304	loadk        r12   k11 ; k11 = 164
.line	1304	loadk        r13   k12 ; k12 = 170
.line	1304	loadk        r14   k13 ; k13 = 39
.line	1304	loadk        r15   k14 ; k14 = 95
.line	1304	loadk        r16   k15 ; k15 = 24
.line	1304	loadk        r17   k16 ; k16 = 91
.line	1304	loadk        r18   k17 ; k17 = 26
.line	1304	loadk        r19   k18 ; k18 = 31
.line	1304	loadk        r20   k19 ; k19 = 217
.line	1304	loadk        r21   k20 ; k20 = 83
.line	1304	loadk        r22   k21 ; k21 = 38
.line	1304	loadk        r23   k22 ; k22 = 54
.line	1304	loadk        r24   k23 ; k23 = 137
.line	1304	loadk        r25   k24 ; k24 = 103
.line	1304	loadk        r26   k25 ; k25 = 102
.line	1304	loadk        r27   k26 ; k26 = 25
.line	1304	loadk        r28   k27 ; k27 = 99
.line	1304	loadk        r29   k28 ; k28 = 156
.line	1304	loadk        r30   k29 ; k29 = 76
.line	1304	loadk        r31   k30 ; k30 = 122
.line	1304	loadk        r32   k31 ; k31 = 113
.line	1304	loadk        r33   k32 ; k32 = 109
.line	1304	loadk        r34   k33 ; k33 = 28
.line	1304	loadk        r35   k34 ; k34 = 9
.line	1304	loadk        r36   k35 ; k35 = 208
.line	1304	loadk        r37   k36 ; k36 = 75
.line	1304	loadk        r38   k37 ; k37 = 17
.line	1304	loadk        r39   k38 ; k38 = 61
.line	1304	loadk        r40   k39 ; k39 = 141
.line	1304	loadk        r41   k40 ; k40 = 85
.line	1304	loadk        r42   k41 ; k41 = 93
.line	1304	loadk        r43   k42 ; k42 = 58
.line	1304	loadk        r44   k40 ; k40 = 85
.line	1304	loadk        r45   k43 ; k43 = 147
.line	1304	loadk        r46   k44 ; k44 = 94
.line	1304	loadk        r47   k45 ; k45 = 104
.line	1304	call          r7    41     2
.line	1304	getupval      r8    u1
.line	1304	loadk         r9   k46 ; k46 = 73
.line	1304	loadk        r10   k31 ; k31 = 113
.line	1304	loadk        r11   k47 ; k47 = 3
.line	1304	loadk        r12   k48 ; k48 = 37
.line	1304	loadk        r13   k49 ; k49 = 181
.line	1304	loadk        r14   k50 ; k50 = 128
.line	1304	loadk        r15   k51 ; k51 = 48
.line	1304	loadk        r16   k52 ; k52 = 84
.line	1304	loadk        r17   k53 ; k53 = 45
.line	1304	loadk        r18   k54 ; k54 = 79
.line	1304	loadk        r19   k17 ; k17 = 26
.line	1304	loadk        r20   k55 ; k55 = 56
.line	1304	loadk        r21   k56 ; k56 = 223
.line	1304	loadk        r22    k8 ; k8 = 68
.line	1304	loadk        r23   k57 ; k57 = 22
.line	1304	loadk        r24   k14 ; k14 = 95
.line	1304	loadk        r25   k71 ; k71 = 149
.line	1304	loadk        r26   k72 ; k72 = 59
.line	1304	loadk        r27   k73 ; k73 = 55
.line	1304	loadk        r28   k74 ; k74 = 11
.line	1304	loadk        r29    k0 ; k0 = 0
.line	1304	loadk        r30   k12 ; k12 = 170
.line	1304	loadk        r31   k33 ; k33 = 28
.line	1304	loadk        r32   k75 ; k75 = 47
.line	1304	loadk        r33   k55 ; k55 = 56
.line	1304	call          r8    26     0
.line	1304	setlist       r6     0     1
.line	1304	call          r5     2     2
.line	1304	gettabup      r6    u0   k70 ; k70 = "tostring"
.line	1304	move          r7    r1
.line	1304	call          r6     2     2
.line	1304	gettabup      r7    u0   k70 ; k70 = "tostring"
.line	1304	move          r8    r2
.line	1304	call          r7     2     0
.line	1304	call          r4     0     2
.label	l198
.line	1304	call          r3     2     1
.line	1304	newtable      r3     0     2
.line	1304	settable      r3   k77    r1 ; k77 = "X"
.line	1304	settable      r3   k78    r2 ; k78 = "Y"
.line	1304	settable      r0   k76    r3 ; k76 = "GameCanvasSize"
.line	1304	settable      r0   k79   k80 ; k80 = false
.line	1304	return        r0     1
.line	1304	move          r0    r0
.line	1304	move          r0    r0
.line	1304	move          r0    r0
.line	1304	move          r0    r0
.line	1304	return        r0     1

.function	main/f61

.source	null
.linedefined	1314
.lastlinedefined	1319
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	"GameCanvasSize"
.constant	k1	"X"
.constant	k2	1920
.constant	k3	"Y"
.constant	k4	1080

.line	1314	gettable      r1    r0    k0 ; k0 = "GameCanvasSize"
.line	1314	test          r1     0
.line	1314	jmp            0    l6
.line	1314	gettable      r1    r0    k0 ; k0 = "GameCanvasSize"
.line	1314	return        r1     2
.label	l6
.line	1314	newtable      r1     0     2
.line	1314	settable      r1    k1    k2 ; k2 = 1920
.line	1314	settable      r1    k3    k4 ; k4 = 1080
.line	1314	return        r1     2
.line	1314	return        r0     1
.line	1314	move          r0    r0
.line	1314	move          r0    r0
.line	1314	move          r0    r0
.line	1314	move          r0    r0
.line	1314	return        r0     1

.function	main/f62

.source	null
.linedefined	1332
.lastlinedefined	1372
.numparams	3
.is_vararg	0
.maxstacksize	55

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"type"
.constant	k1	78
.constant	k2	66
.constant	k3	16
.constant	k4	33
.constant	k5	190
.constant	k6	164
.constant	k7	"print"
.constant	k8	"bWriteLog"
.constant	k9	"table"
.constant	k10	"concat"
.constant	k11	126
.constant	k12	68
.constant	k13	7
.constant	k14	41
.constant	k15	170
.constant	k16	39
.constant	k17	95
.constant	k18	24
.constant	k19	91
.constant	k20	26
.constant	k21	31
.constant	k22	217
.constant	k23	83
.constant	k24	38
.constant	k25	54
.constant	k26	137
.constant	k27	103
.constant	k28	102
.constant	k29	25
.constant	k30	99
.constant	k31	156
.constant	k32	76
.constant	k33	122
.constant	k34	113
.constant	k35	125
.constant	k36	21
.constant	k37	18
.constant	k38	195
.constant	k39	64
.constant	k40	23
.constant	k41	61
.constant	k42	141
.constant	k43	85
.constant	k44	93
.constant	k45	59
.constant	k46	151
.constant	k47	115
.constant	k48	89
.constant	k49	81
.constant	k50	60
.constant	k51	153
.constant	k52	174
.constant	k53	48
.constant	k54	62
.constant	k55	108
.constant	k56	228
.constant	k57	114
.constant	k58	22
.constant	k59	163
.constant	k60	112
.constant	k61	20
.constant	k62	73
.constant	k63	1
.constant	k64	nil
.constant	k65	45
.constant	k66	184
.constant	k67	104
.constant	k68	17
.constant	k69	77
.constant	k70	150
.constant	k71	110
.constant	k72	56
.constant	k73	30
.constant	k74	8
.constant	k75	134
.constant	k76	10
.constant	k77	3
.constant	k78	0
.constant	k79	"Num"
.constant	k80	67
.constant	k81	12
.constant	k82	43
.constant	k83	84
.constant	k84	87
.constant	k85	36
.constant	k86	181
.constant	k87	160
.constant	k88	118
.constant	k89	161
.constant	k90	100
.constant	k91	63
.constant	k92	239
.constant	k93	74
.constant	k94	"Get"
.constant	k95	"GetWidgetObjectByRuntimeId"
.constant	k96	"GetWidgetByRuntimeId"
.constant	k97	"slua"
.constant	k98	"isValid"
.constant	k99	"SetImageByURL"
.constant	k100	98
.constant	k101	117
.constant	k102	29
.constant	k103	211
.constant	k104	79
.constant	k105	101
.constant	k106	11
.constant	k107	199
.constant	k108	42
.constant	k109	132
.constant	k110	69
.constant	k111	144
.constant	k112	207
.constant	k113	4

.line	1332	gettabup      r3    u0    k0 ; k0 = "type"
.line	1332	move          r4    r2
.line	1332	call          r3     2     2
.line	1332	getupval      r4    u1
.line	1332	loadk         r5    k1 ; k1 = 78
.line	1332	loadk         r6    k2 ; k2 = 66
.line	1332	loadk         r7    k3 ; k3 = 16
.line	1332	loadk         r8    k4 ; k4 = 33
.line	1332	loadk         r9    k5 ; k5 = 190
.line	1332	loadk        r10    k6 ; k6 = 164
.line	1332	call          r4     7     2
.line	1332	eq             0    r3    r4
.line	1332	jmp            0   l18
.line	1332	getupval      r3    u1
.line	1332	call          r3     1     2
.line	1332	eq             0    r2    r3
.line	1332	jmp            0   l99
.label	l18
.line	1332	gettabup      r3    u0    k7 ; k7 = "print"
.line	1332	gettabup      r4    u0    k8 ; k8 = "bWriteLog"
.line	1332	test          r4     0
.line	1332	jmp            0   l97
.line	1332	gettabup      r4    u0    k9 ; k9 = "table"
.line	1332	gettable      r4    r4   k10 ; k10 = "concat"
.line	1332	newtable      r5     1     0
.line	1332	getupval      r6    u1
.line	1332	loadk         r7   k11 ; k11 = 126
.line	1332	loadk         r8   k12 ; k12 = 68
.line	1332	loadk         r9   k13 ; k13 = 7
.line	1332	loadk        r10   k14 ; k14 = 41
.line	1332	loadk        r11    k6 ; k6 = 164
.line	1332	loadk        r12   k15 ; k15 = 170
.line	1332	loadk        r13   k16 ; k16 = 39
.line	1332	loadk        r14   k17 ; k17 = 95
.line	1332	loadk        r15   k18 ; k18 = 24
.line	1332	loadk        r16   k19 ; k19 = 91
.line	1332	loadk        r17   k20 ; k20 = 26
.line	1332	loadk        r18   k21 ; k21 = 31
.line	1332	loadk        r19   k22 ; k22 = 217
.line	1332	loadk        r20   k23 ; k23 = 83
.line	1332	loadk        r21   k24 ; k24 = 38
.line	1332	loadk        r22   k25 ; k25 = 54
.line	1332	loadk        r23   k26 ; k26 = 137
.line	1332	loadk        r24   k27 ; k27 = 103
.line	1332	loadk        r25   k28 ; k28 = 102
.line	1332	loadk        r26   k29 ; k29 = 25
.line	1332	loadk        r27   k30 ; k30 = 99
.line	1332	loadk        r28   k31 ; k31 = 156
.line	1332	loadk        r29   k32 ; k32 = 76
.line	1332	loadk        r30   k33 ; k33 = 122
.line	1332	loadk        r31   k34 ; k34 = 113
.line	1332	loadk        r32   k35 ; k35 = 125
.line	1332	loadk        r33   k36 ; k36 = 21
.line	1332	loadk        r34   k37 ; k37 = 18
.line	1332	loadk        r35   k38 ; k38 = 195
.line	1332	loadk        r36   k39 ; k39 = 64
.line	1332	loadk        r37   k40 ; k40 = 23
.line	1332	loadk        r38   k41 ; k41 = 61
.line	1332	loadk        r39   k42 ; k42 = 141
.line	1332	loadk        r40   k43 ; k43 = 85
.line	1332	loadk        r41   k44 ; k44 = 93
.line	1332	loadk        r42   k45 ; k45 = 59
.line	1332	loadk        r43   k43 ; k43 = 85
.line	1332	loadk        r44   k46 ; k46 = 151
.line	1332	loadk        r45   k28 ; k28 = 102
.line	1332	loadk        r46   k47 ; k47 = 115
.line	1332	call          r6    41     2
.line	1332	getupval      r7    u1
.line	1332	loadk         r8   k48 ; k48 = 89
.line	1332	loadk         r9   k49 ; k49 = 81
.line	1332	loadk        r10   k13 ; k13 = 7
.line	1332	loadk        r11   k50 ; k50 = 60
.line	1332	loadk        r12   k51 ; k51 = 153
.line	1332	loadk        r13   k52 ; k52 = 174
.line	1332	loadk        r14   k53 ; k53 = 48
.line	1332	loadk        r15   k44 ; k44 = 93
.line	1332	loadk        r16   k54 ; k54 = 62
.line	1332	loadk        r17   k55 ; k55 = 108
.line	1332	loadk        r18    k3 ; k3 = 16
.line	1332	loadk        r19   k54 ; k54 = 62
.line	1332	loadk        r20   k56 ; k56 = 228
.line	1332	loadk        r21   k57 ; k57 = 114
.line	1332	loadk        r22   k23 ; k23 = 83
.line	1332	loadk        r23   k58 ; k58 = 22
.line	1332	loadk        r24   k59 ; k59 = 163
.line	1332	loadk        r25   k60 ; k60 = 112
.line	1332	loadk        r26   k47 ; k47 = 115
.line	1332	loadk        r27   k61 ; k61 = 20
.line	1332	loadk        r28   k62 ; k62 = 73
.line	1332	loadk        r29   k46 ; k46 = 151
.line	1332	loadk        r30   k63 ; k63 = 1
.line	1332	loadk        r31   k17 ; k17 = 95
.line	1332	loadk        r32   k29 ; k29 = 25
.line	1332	loadk        r33   k57 ; k57 = 114
.line	1332	call          r7    27     0
.line	1332	setlist       r5     0     1
.line	1332	call          r4     2     2
.label	l97
.line	1332	call          r3     2     1
.line	1332	return        r0     1
.label	l99
.line	1332	eq             0    r1   k64 ; k64 = nil
.line	1332	jmp            0  l188
.line	1332	gettabup      r3    u0    k7 ; k7 = "print"
.line	1332	gettabup      r4    u0    k8 ; k8 = "bWriteLog"
.line	1332	test          r4     0
.line	1332	jmp            0  l186
.line	1332	gettabup      r4    u0    k9 ; k9 = "table"
.line	1332	gettable      r4    r4   k10 ; k10 = "concat"
.line	1332	newtable      r5     1     0
.line	1332	getupval      r6    u1
.line	1332	loadk         r7   k11 ; k11 = 126
.line	1332	loadk         r8   k12 ; k12 = 68
.line	1332	loadk         r9   k13 ; k13 = 7
.line	1332	loadk        r10   k14 ; k14 = 41
.line	1332	loadk        r11    k6 ; k6 = 164
.line	1332	loadk        r12   k15 ; k15 = 170
.line	1332	loadk        r13   k16 ; k16 = 39
.line	1332	loadk        r14   k17 ; k17 = 95
.line	1332	loadk        r15   k18 ; k18 = 24
.line	1332	loadk        r16   k19 ; k19 = 91
.line	1332	loadk        r17   k20 ; k20 = 26
.line	1332	loadk        r18   k21 ; k21 = 31
.line	1332	loadk        r19   k22 ; k22 = 217
.line	1332	loadk        r20   k23 ; k23 = 83
.line	1332	loadk        r21   k24 ; k24 = 38
.line	1332	loadk        r22   k25 ; k25 = 54
.line	1332	loadk        r23   k26 ; k26 = 137
.line	1332	loadk        r24   k27 ; k27 = 103
.line	1332	loadk        r25   k28 ; k28 = 102
.line	1332	loadk        r26   k29 ; k29 = 25
.line	1332	loadk        r27   k30 ; k30 = 99
.line	1332	loadk        r28   k31 ; k31 = 156
.line	1332	loadk        r29   k32 ; k32 = 76
.line	1332	loadk        r30   k33 ; k33 = 122
.line	1332	loadk        r31   k34 ; k34 = 113
.line	1332	loadk        r32   k35 ; k35 = 125
.line	1332	loadk        r33   k36 ; k36 = 21
.line	1332	loadk        r34   k37 ; k37 = 18
.line	1332	loadk        r35   k38 ; k38 = 195
.line	1332	loadk        r36   k39 ; k39 = 64
.line	1332	loadk        r37   k40 ; k40 = 23
.line	1332	loadk        r38   k41 ; k41 = 61
.line	1332	loadk        r39   k42 ; k42 = 141
.line	1332	loadk        r40   k43 ; k43 = 85
.line	1332	loadk        r41   k44 ; k44 = 93
.line	1332	loadk        r42   k45 ; k45 = 59
.line	1332	loadk        r43   k43 ; k43 = 85
.line	1332	loadk        r44   k46 ; k46 = 151
.line	1332	loadk        r45   k28 ; k28 = 102
.line	1332	loadk        r46   k47 ; k47 = 115
.line	1332	call          r6    41     2
.line	1332	getupval      r7    u1
.line	1332	loadk         r8   k48 ; k48 = 89
.line	1332	loadk         r9   k49 ; k49 = 81
.line	1332	loadk        r10   k13 ; k13 = 7
.line	1332	loadk        r11   k50 ; k50 = 60
.line	1332	loadk        r12   k51 ; k51 = 153
.line	1332	loadk        r13   k52 ; k52 = 174
.line	1332	loadk        r14   k53 ; k53 = 48
.line	1332	loadk        r15   k44 ; k44 = 93
.line	1332	loadk        r16   k54 ; k54 = 62
.line	1332	loadk        r17   k55 ; k55 = 108
.line	1332	loadk        r18    k3 ; k3 = 16
.line	1332	loadk        r19   k54 ; k54 = 62
.line	1332	loadk        r20   k56 ; k56 = 228
.line	1332	loadk        r21   k57 ; k57 = 114
.line	1332	loadk        r22   k23 ; k23 = 83
.line	1332	loadk        r23   k65 ; k65 = 45
.line	1332	loadk        r24   k66 ; k66 = 184
.line	1332	loadk        r25   k67 ; k67 = 104
.line	1332	loadk        r26   k28 ; k28 = 102
.line	1332	loadk        r27   k68 ; k68 = 17
.line	1332	loadk        r28   k69 ; k69 = 77
.line	1332	loadk        r29   k70 ; k70 = 150
.line	1332	loadk        r30   k67 ; k67 = 104
.line	1332	loadk        r31   k71 ; k71 = 110
.line	1332	loadk        r32   k72 ; k72 = 56
.line	1332	loadk        r33   k73 ; k73 = 30
.line	1332	loadk        r34    k3 ; k3 = 16
.line	1332	loadk        r35   k74 ; k74 = 8
.line	1332	loadk        r36   k75 ; k75 = 134
.line	1332	loadk        r37   k39 ; k39 = 64
.line	1332	loadk        r38   k76 ; k76 = 10
.line	1332	loadk        r39   k77 ; k77 = 3
.line	1332	call          r7    33     0
.line	1332	setlist       r5     0     1
.line	1332	call          r4     2     2
.label	l186
.line	1332	call          r3     2     1
.line	1332	return        r0     1
.label	l188
.line	1332	loadk         r3   k78 ; k78 = 0
.line	1332	gettabup      r4    u0    k0 ; k0 = "type"
.line	1332	gettable      r5    r1   k79 ; k79 = "Num"
.line	1332	call          r4     2     2
.line	1332	getupval      r5    u1
.line	1332	loadk         r6   k19 ; k19 = 91
.line	1332	loadk         r7   k80 ; k80 = 67
.line	1332	loadk         r8   k81 ; k81 = 12
.line	1332	loadk         r9   k82 ; k82 = 43
.line	1332	loadk        r10    k6 ; k6 = 164
.line	1332	loadk        r11   k15 ; k15 = 170
.line	1332	loadk        r12   k54 ; k54 = 62
.line	1332	loadk        r13   k83 ; k83 = 84
.line	1332	call          r5     9     2
.line	1332	eq             0    r4    r5
.line	1332	jmp            0  l208
.line	1332	self          r4    r1   k79 ; k79 = "Num"
.line	1332	call          r4     2     2
.line	1332	move          r3    r4
.line	1332	jmp            0  l221
.label	l208
.line	1332	gettabup      r4    u0    k0 ; k0 = "type"
.line	1332	move          r5    r1
.line	1332	call          r4     2     2
.line	1332	getupval      r5    u1
.line	1332	loadk         r6   k62 ; k62 = 73
.line	1332	loadk         r7   k84 ; k84 = 87
.line	1332	loadk         r8   k78 ; k78 = 0
.line	1332	loadk         r9   k85 ; k85 = 36
.line	1332	loadk        r10   k86 ; k86 = 181
.line	1332	call          r5     6     2
.line	1332	eq             0    r4    r5
.line	1332	jmp            0  l221
.line	1332	len           r3    r1
.label	l221
.line	1332	le             0    r3   k78 ; k78 = 0
.line	1332	jmp            0  l309
.line	1332	gettabup      r4    u0    k7 ; k7 = "print"
.line	1332	gettabup      r5    u0    k8 ; k8 = "bWriteLog"
.line	1332	test          r5     0
.line	1332	jmp            0  l307
.line	1332	gettabup      r5    u0    k9 ; k9 = "table"
.line	1332	gettable      r5    r5   k10 ; k10 = "concat"
.line	1332	newtable      r6     1     0
.line	1332	getupval      r7    u1
.line	1332	loadk         r8   k11 ; k11 = 126
.line	1332	loadk         r9   k12 ; k12 = 68
.line	1332	loadk        r10   k13 ; k13 = 7
.line	1332	loadk        r11   k14 ; k14 = 41
.line	1332	loadk        r12    k6 ; k6 = 164
.line	1332	loadk        r13   k15 ; k15 = 170
.line	1332	loadk        r14   k16 ; k16 = 39
.line	1332	loadk        r15   k17 ; k17 = 95
.line	1332	loadk        r16   k18 ; k18 = 24
.line	1332	loadk        r17   k19 ; k19 = 91
.line	1332	loadk        r18   k20 ; k20 = 26
.line	1332	loadk        r19   k21 ; k21 = 31
.line	1332	loadk        r20   k22 ; k22 = 217
.line	1332	loadk        r21   k23 ; k23 = 83
.line	1332	loadk        r22   k24 ; k24 = 38
.line	1332	loadk        r23   k25 ; k25 = 54
.line	1332	loadk        r24   k26 ; k26 = 137
.line	1332	loadk        r25   k27 ; k27 = 103
.line	1332	loadk        r26   k28 ; k28 = 102
.line	1332	loadk        r27   k29 ; k29 = 25
.line	1332	loadk        r28   k30 ; k30 = 99
.line	1332	loadk        r29   k31 ; k31 = 156
.line	1332	loadk        r30   k32 ; k32 = 76
.line	1332	loadk        r31   k33 ; k33 = 122
.line	1332	loadk        r32   k34 ; k34 = 113
.line	1332	loadk        r33   k35 ; k35 = 125
.line	1332	loadk        r34   k36 ; k36 = 21
.line	1332	loadk        r35   k37 ; k37 = 18
.line	1332	loadk        r36   k38 ; k38 = 195
.line	1332	loadk        r37   k39 ; k39 = 64
.line	1332	loadk        r38   k40 ; k40 = 23
.line	1332	loadk        r39   k41 ; k41 = 61
.line	1332	loadk        r40   k42 ; k42 = 141
.line	1332	loadk        r41   k43 ; k43 = 85
.line	1332	loadk        r42   k44 ; k44 = 93
.line	1332	loadk        r43   k45 ; k45 = 59
.line	1332	loadk        r44   k43 ; k43 = 85
.line	1332	loadk        r45   k46 ; k46 = 151
.line	1332	loadk        r46   k28 ; k28 = 102
.line	1332	loadk        r47   k47 ; k47 = 115
.line	1332	call          r7    41     2
.line	1332	getupval      r8    u1
.line	1332	loadk         r9   k48 ; k48 = 89
.line	1332	loadk        r10   k49 ; k49 = 81
.line	1332	loadk        r11   k13 ; k13 = 7
.line	1332	loadk        r12   k50 ; k50 = 60
.line	1332	loadk        r13   k51 ; k51 = 153
.line	1332	loadk        r14   k52 ; k52 = 174
.line	1332	loadk        r15   k53 ; k53 = 48
.line	1332	loadk        r16   k44 ; k44 = 93
.line	1332	loadk        r17   k54 ; k54 = 62
.line	1332	loadk        r18   k55 ; k55 = 108
.line	1332	loadk        r19    k3 ; k3 = 16
.line	1332	loadk        r20   k54 ; k54 = 62
.line	1332	loadk        r21   k56 ; k56 = 228
.line	1332	loadk        r22   k57 ; k57 = 114
.line	1332	loadk        r23   k23 ; k23 = 83
.line	1332	loadk        r24   k20 ; k20 = 26
.line	1332	loadk        r25   k87 ; k87 = 160
.line	1332	loadk        r26   k88 ; k88 = 118
.line	1332	loadk        r27   k28 ; k28 = 102
.line	1332	loadk        r28   k63 ; k63 = 1
.line	1332	loadk        r29   k78 ; k78 = 0
.line	1332	loadk        r30   k89 ; k89 = 161
.line	1332	loadk        r31   k83 ; k83 = 84
.line	1332	loadk        r32   k90 ; k90 = 100
.line	1332	loadk        r33   k91 ; k91 = 63
.line	1332	loadk        r34   k84 ; k84 = 87
.line	1332	loadk        r35   k61 ; k61 = 20
.line	1332	loadk        r36   k73 ; k73 = 30
.line	1332	loadk        r37   k92 ; k92 = 239
.line	1332	loadk        r38   k93 ; k93 = 74
.line	1332	loadk        r39    k3 ; k3 = 16
.line	1332	call          r8    32     0
.line	1332	setlist       r6     0     1
.line	1332	call          r5     2     2
.label	l307
.line	1332	call          r4     2     1
.line	1332	return        r0     1
.label	l309
.line	1332	loadk         r4   k78 ; k78 = 0
.line	1332	sub           r5    r3   k63 ; k63 = 1
.line	1332	loadk         r6   k63 ; k63 = 1
.line	1332	move          r0    r0
.line	1332	loadnil       r8     0
.line	1332	gettabup      r9    u0    k0 ; k0 = "type"
.line	1332	gettable     r10    r1   k94 ; k94 = "Get"
.line	1332	call          r9     2     2
.line	1332	getupval     r10    u1
.line	1332	loadk        r11   k19 ; k19 = 91
.line	1332	loadk        r12   k80 ; k80 = 67
.line	1332	loadk        r13   k81 ; k81 = 12
.line	1332	loadk        r14   k82 ; k82 = 43
.line	1332	loadk        r15    k6 ; k6 = 164
.line	1332	loadk        r16   k15 ; k15 = 170
.line	1332	loadk        r17   k54 ; k54 = 62
.line	1332	loadk        r18   k83 ; k83 = 84
.line	1332	call         r10     9     2
.line	1332	eq             0    r9   r10
.line	1332	jmp            0  l334
.line	1332	self          r9    r1   k94 ; k94 = "Get"
.line	1332	move         r11    r7
.line	1332	call          r9     3     2
.line	1332	move          r8    r9
.line	1332	jmp            0  l335
.label	l334
.line	1332	gettable      r8    r1    r7
.label	l335
.line	1332	gettabup      r9    u0    k0 ; k0 = "type"
.line	1332	move         r10    r8
.line	1332	call          r9     2     2
.line	1332	getupval     r10    u1
.line	1332	loadk        r11    k1 ; k1 = 78
.line	1332	loadk        r12    k2 ; k2 = 66
.line	1332	loadk        r13    k3 ; k3 = 16
.line	1332	loadk        r14    k4 ; k4 = 33
.line	1332	loadk        r15    k5 ; k5 = 190
.line	1332	loadk        r16    k6 ; k6 = 164
.line	1332	call         r10     7     2
.line	1332	eq             0    r9   r10
.line	1332	jmp            0  l575
.line	1332	getupval      r9    u1
.line	1332	call          r9     1     2
.line	1332	eq             1    r8    r9
.line	1332	jmp            0  l575
.line	1332	self          r9    r0   k95 ; k95 = "GetWidgetObjectByRun" (truncated)
.line	1332	move         r11    r8
.line	1332	call          r9     3     2
.line	1332	test          r9     0
.line	1332	jmp            0  l489
.line	1332	gettabup     r10    u0    k0 ; k0 = "type"
.line	1332	gettable     r11    r9   k96 ; k96 = "GetWidgetByRuntimeId"
.line	1332	call         r10     2     2
.line	1332	getupval     r11    u1
.line	1332	loadk        r12   k19 ; k19 = 91
.line	1332	loadk        r13   k80 ; k80 = 67
.line	1332	loadk        r14   k81 ; k81 = 12
.line	1332	loadk        r15   k82 ; k82 = 43
.line	1332	loadk        r16    k6 ; k6 = 164
.line	1332	loadk        r17   k15 ; k15 = 170
.line	1332	loadk        r18   k54 ; k54 = 62
.line	1332	loadk        r19   k83 ; k83 = 84
.line	1332	call         r11     9     2
.line	1332	eq             0   r10   r11
.line	1332	jmp            0  l489
.line	1332	self         r10    r9   k96 ; k96 = "GetWidgetByRuntimeId"
.line	1332	move         r12    r8
.line	1332	call         r10     3     2
.line	1332	test         r10     0
.line	1332	jmp            0  l402
.line	1332	gettabup     r11    u0   k97 ; k97 = "slua"
.line	1332	gettable     r11   r11   k98 ; k98 = "isValid"
.line	1332	move         r12   r10
.line	1332	call         r11     2     2
.line	1332	test         r11     0
.line	1332	jmp            0  l402
.line	1332	gettabup     r11    u0    k0 ; k0 = "type"
.line	1332	gettable     r12   r10   k99 ; k99 = "SetImageByURL"
.line	1332	call         r11     2     2
.line	1332	getupval     r12    u1
.line	1332	loadk        r13   k19 ; k19 = 91
.line	1332	loadk        r14   k80 ; k80 = 67
.line	1332	loadk        r15   k81 ; k81 = 12
.line	1332	loadk        r16   k82 ; k82 = 43
.line	1332	loadk        r17    k6 ; k6 = 164
.line	1332	loadk        r18   k15 ; k15 = 170
.line	1332	loadk        r19   k54 ; k54 = 62
.line	1332	loadk        r20   k83 ; k83 = 84
.line	1332	call         r12     9     2
.line	1332	eq             0   r11   r12
.line	1332	jmp            0  l402
.line	1332	self         r11   r10   k99 ; k99 = "SetImageByURL"
.line	1332	move         r13    r2
.line	1332	call         r11     3     1
.line	1332	jmp            0  l575
.label	l402
.line	1332	gettabup     r11    u0    k7 ; k7 = "print"
.line	1332	gettabup     r12    u0    k8 ; k8 = "bWriteLog"
.line	1332	test         r12     0
.line	1332	jmp            0  l486
.line	1332	gettabup     r12    u0    k9 ; k9 = "table"
.line	1332	gettable     r12   r12   k10 ; k10 = "concat"
.line	1332	newtable     r13     1     0
.line	1332	getupval     r14    u1
.line	1332	loadk        r15   k11 ; k11 = 126
.line	1332	loadk        r16   k12 ; k12 = 68
.line	1332	loadk        r17   k13 ; k13 = 7
.line	1332	loadk        r18   k14 ; k14 = 41
.line	1332	loadk        r19    k6 ; k6 = 164
.line	1332	loadk        r20   k15 ; k15 = 170
.line	1332	loadk        r21   k16 ; k16 = 39
.line	1332	loadk        r22   k17 ; k17 = 95
.line	1332	loadk        r23   k18 ; k18 = 24
.line	1332	loadk        r24   k19 ; k19 = 91
.line	1332	loadk        r25   k20 ; k20 = 26
.line	1332	loadk        r26   k21 ; k21 = 31
.line	1332	loadk        r27   k22 ; k22 = 217
.line	1332	loadk        r28   k23 ; k23 = 83
.line	1332	loadk        r29   k24 ; k24 = 38
.line	1332	loadk        r30   k25 ; k25 = 54
.line	1332	loadk        r31   k26 ; k26 = 137
.line	1332	loadk        r32   k27 ; k27 = 103
.line	1332	loadk        r33   k28 ; k28 = 102
.line	1332	loadk        r34   k29 ; k29 = 25
.line	1332	loadk        r35   k30 ; k30 = 99
.line	1332	loadk        r36   k31 ; k31 = 156
.line	1332	loadk        r37   k32 ; k32 = 76
.line	1332	loadk        r38   k33 ; k33 = 122
.line	1332	loadk        r39   k34 ; k34 = 113
.line	1332	loadk        r40   k35 ; k35 = 125
.line	1332	loadk        r41   k36 ; k36 = 21
.line	1332	loadk        r42   k37 ; k37 = 18
.line	1332	loadk        r43   k38 ; k38 = 195
.line	1332	loadk        r44   k39 ; k39 = 64
.line	1332	loadk        r45   k40 ; k40 = 23
.line	1332	loadk        r46   k41 ; k41 = 61
.line	1332	loadk        r47   k42 ; k42 = 141
.line	1332	loadk        r48   k43 ; k43 = 85
.line	1332	loadk        r49   k44 ; k44 = 93
.line	1332	loadk        r50   k45 ; k45 = 59
.line	1332	loadk        r51   k43 ; k43 = 85
.line	1332	loadk        r52   k46 ; k46 = 151
.line	1332	loadk        r53   k28 ; k28 = 102
.line	1332	loadk        r54   k47 ; k47 = 115
.line	1332	call         r14    41     2
.line	1332	getupval     r15    u1
.line	1332	loadk        r16   k48 ; k48 = 89
.line	1332	loadk        r17   k49 ; k49 = 81
.line	1332	loadk        r18   k13 ; k13 = 7
.line	1332	loadk        r19   k50 ; k50 = 60
.line	1332	loadk        r20   k51 ; k51 = 153
.line	1332	loadk        r21   k52 ; k52 = 174
.line	1332	loadk        r22   k53 ; k53 = 48
.line	1332	loadk        r23   k44 ; k44 = 93
.line	1332	loadk        r24   k54 ; k54 = 62
.line	1332	loadk        r25   k55 ; k55 = 108
.line	1332	loadk        r26    k3 ; k3 = 16
.line	1332	loadk        r27   k54 ; k54 = 62
.line	1332	loadk        r28   k56 ; k56 = 228
.line	1332	loadk        r29   k57 ; k57 = 114
.line	1332	loadk        r30   k23 ; k23 = 83
.line	1332	loadk        r31   k74 ; k74 = 8
.line	1332	loadk        r32    k6 ; k6 = 164
.line	1332	loadk        r33  k100 ; k100 = 98
.line	1332	loadk        r34  k101 ; k101 = 117
.line	1332	loadk        r35  k102 ; k102 = 29
.line	1332	loadk        r36   k83 ; k83 = 84
.line	1332	loadk        r37  k103 ; k103 = 211
.line	1332	loadk        r38  k104 ; k104 = 79
.line	1332	loadk        r39  k105 ; k105 = 101
.line	1332	loadk        r40   k91 ; k91 = 63
.line	1332	loadk        r41   k73 ; k73 = 30
.line	1332	loadk        r42  k106 ; k106 = 11
.line	1332	loadk        r43   k73 ; k73 = 30
.line	1332	loadk        r44  k107 ; k107 = 199
.line	1332	loadk        r45   k93 ; k93 = 74
.line	1332	loadk        r46   k20 ; k20 = 26
.line	1332	call         r15    32     0
.line	1332	setlist      r13     0     1
.line	1332	call         r12     2     2
.label	l486
.line	1332	move         r13    r8
.line	1332	call         r11     3     1
.line	1332	jmp            0  l575
.label	l489
.line	1332	gettabup     r10    u0    k7 ; k7 = "print"
.line	1332	gettabup     r11    u0    k8 ; k8 = "bWriteLog"
.line	1332	test         r11     0
.line	1332	jmp            0  l573
.line	1332	gettabup     r11    u0    k9 ; k9 = "table"
.line	1332	gettable     r11   r11   k10 ; k10 = "concat"
.line	1332	newtable     r12     1     0
.line	1332	getupval     r13    u1
.line	1332	loadk        r14   k11 ; k11 = 126
.line	1332	loadk        r15   k12 ; k12 = 68
.line	1332	loadk        r16   k13 ; k13 = 7
.line	1332	loadk        r17   k14 ; k14 = 41
.line	1332	loadk        r18    k6 ; k6 = 164
.line	1332	loadk        r19   k15 ; k15 = 170
.line	1332	loadk        r20   k16 ; k16 = 39
.line	1332	loadk        r21   k17 ; k17 = 95
.line	1332	loadk        r22   k18 ; k18 = 24
.line	1332	loadk        r23   k19 ; k19 = 91
.line	1332	loadk        r24   k20 ; k20 = 26
.line	1332	loadk        r25   k21 ; k21 = 31
.line	1332	loadk        r26   k22 ; k22 = 217
.line	1332	loadk        r27   k23 ; k23 = 83
.line	1332	loadk        r28   k24 ; k24 = 38
.line	1332	loadk        r29   k25 ; k25 = 54
.line	1332	loadk        r30   k26 ; k26 = 137
.line	1332	loadk        r31   k27 ; k27 = 103
.line	1332	loadk        r32   k28 ; k28 = 102
.line	1332	loadk        r33   k29 ; k29 = 25
.line	1332	loadk        r34   k30 ; k30 = 99
.line	1332	loadk        r35   k31 ; k31 = 156
.line	1332	loadk        r36   k32 ; k32 = 76
.line	1332	loadk        r37   k33 ; k33 = 122
.line	1332	loadk        r38   k34 ; k34 = 113
.line	1332	loadk        r39   k35 ; k35 = 125
.line	1332	loadk        r40   k36 ; k36 = 21
.line	1332	loadk        r41   k37 ; k37 = 18
.line	1332	loadk        r42   k38 ; k38 = 195
.line	1332	loadk        r43   k39 ; k39 = 64
.line	1332	loadk        r44   k40 ; k40 = 23
.line	1332	loadk        r45   k41 ; k41 = 61
.line	1332	loadk        r46   k42 ; k42 = 141
.line	1332	loadk        r47   k43 ; k43 = 85
.line	1332	loadk        r48   k44 ; k44 = 93
.line	1332	loadk        r49   k45 ; k45 = 59
.line	1332	loadk        r50   k43 ; k43 = 85
.line	1332	loadk        r51   k46 ; k46 = 151
.line	1332	loadk        r52   k28 ; k28 = 102
.line	1332	loadk        r53   k47 ; k47 = 115
.line	1332	call         r13    41     2
.line	1332	getupval     r14    u1
.line	1332	loadk        r15   k48 ; k48 = 89
.line	1332	loadk        r16   k49 ; k49 = 81
.line	1332	loadk        r17   k13 ; k13 = 7
.line	1332	loadk        r18   k50 ; k50 = 60
.line	1332	loadk        r19   k51 ; k51 = 153
.line	1332	loadk        r20   k52 ; k52 = 174
.line	1332	loadk        r21   k53 ; k53 = 48
.line	1332	loadk        r22   k44 ; k44 = 93
.line	1332	loadk        r23   k54 ; k54 = 62
.line	1332	loadk        r24   k55 ; k55 = 108
.line	1332	loadk        r25    k3 ; k3 = 16
.line	1332	loadk        r26   k54 ; k54 = 62
.line	1332	loadk        r27   k56 ; k56 = 228
.line	1332	loadk        r28   k57 ; k57 = 114
.line	1332	loadk        r29   k23 ; k23 = 83
.line	1332	loadk        r30  k108 ; k108 = 42
.line	1332	loadk        r31  k109 ; k109 = 132
.line	1332	loadk        r32   k62 ; k62 = 73
.line	1332	loadk        r33   k60 ; k60 = 112
.line	1332	loadk        r34   k37 ; k37 = 18
.line	1332	loadk        r35  k110 ; k110 = 69
.line	1332	loadk        r36  k111 ; k111 = 144
.line	1332	loadk        r37   k43 ; k43 = 85
.line	1332	loadk        r38  k108 ; k108 = 42
.line	1332	loadk        r39   k24 ; k24 = 38
.line	1332	loadk        r40   k84 ; k84 = 87
.line	1332	loadk        r41   k76 ; k76 = 10
.line	1332	loadk        r42   k74 ; k74 = 8
.line	1332	loadk        r43  k112 ; k112 = 207
.line	1332	loadk        r44   k39 ; k39 = 64
.line	1332	loadk        r45  k113 ; k113 = 4
.line	1332	call         r14    32     0
.line	1332	setlist      r12     0     1
.line	1332	call         r11     2     2
.label	l573
.line	1332	move         r12    r8
.line	1332	call         r10     3     1
.label	l575
.line	1332	move          r0    r0
.line	1332	return        r0     1
.line	1332	gettabup      r2    u1  k104 ; k104 = 79
.line	1332	return        r0     1

.function	main/f63

.source	null
.linedefined	1374
.lastlinedefined	1379
.numparams	1
.is_vararg	0
.maxstacksize	37

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"SubsystemMgr"
.constant	k1	"Get"
.constant	k2	126
.constant	k3	68
.constant	k4	7
.constant	k5	41
.constant	k6	164
.constant	k7	170
.constant	k8	39
.constant	k9	95
.constant	k10	22
.constant	k11	65
.constant	k12	13
.constant	k13	14
.constant	k14	245
.constant	k15	75
.constant	k16	0
.constant	k17	11
.constant	k18	162
.constant	k19	107
.constant	k20	71
.constant	k21	49
.constant	k22	116
.constant	k23	129
.constant	k24	111
.constant	k25	24
.constant	k26	27
.constant	k27	8
.constant	k28	223
.constant	k29	93
.constant	k30	23
.constant	k31	10
.constant	k32	176

.line	1374	gettabup      r1    u0    k0 ; k0 = "SubsystemMgr"
.line	1374	test          r1     1
.line	1374	jmp            0    l6
.line	1374	loadnil       r1     0
.line	1374	return        r1     2
.label	l6
.line	1374	gettabup      r1    u0    k0 ; k0 = "SubsystemMgr"
.line	1374	self          r1    r1    k1 ; k1 = "Get"
.line	1374	getupval      r3    u1
.line	1374	loadk         r4    k2 ; k2 = 126
.line	1374	loadk         r5    k3 ; k3 = 68
.line	1374	loadk         r6    k4 ; k4 = 7
.line	1374	loadk         r7    k5 ; k5 = 41
.line	1374	loadk         r8    k6 ; k6 = 164
.line	1374	loadk         r9    k7 ; k7 = 170
.line	1374	loadk        r10    k8 ; k8 = 39
.line	1374	loadk        r11    k9 ; k9 = 95
.line	1374	loadk        r12   k10 ; k10 = 22
.line	1374	loadk        r13   k11 ; k11 = 65
.line	1374	loadk        r14   k12 ; k12 = 13
.line	1374	loadk        r15   k13 ; k13 = 14
.line	1374	loadk        r16   k14 ; k14 = 245
.line	1374	loadk        r17   k15 ; k15 = 75
.line	1374	loadk        r18   k16 ; k16 = 0
.line	1374	loadk        r19   k17 ; k17 = 11
.line	1374	loadk        r20   k18 ; k18 = 162
.line	1374	loadk        r21   k19 ; k19 = 107
.line	1374	loadk        r22   k20 ; k20 = 71
.line	1374	loadk        r23   k21 ; k21 = 49
.line	1374	loadk        r24   k22 ; k22 = 116
.line	1374	loadk        r25   k23 ; k23 = 129
.line	1374	loadk        r26    k3 ; k3 = 68
.line	1374	loadk        r27   k24 ; k24 = 111
.line	1374	loadk        r28   k25 ; k25 = 24
.line	1374	loadk        r29   k15 ; k15 = 75
.line	1374	loadk        r30   k26 ; k26 = 27
.line	1374	loadk        r31   k27 ; k27 = 8
.line	1374	loadk        r32   k28 ; k28 = 223
.line	1374	loadk        r33   k29 ; k29 = 93
.line	1374	loadk        r34   k30 ; k30 = 23
.line	1374	loadk        r35   k31 ; k31 = 10
.line	1374	loadk        r36   k32 ; k32 = 176
.line	1374	call          r3    34     2
.line	1374	tailcall      r1     3
.line	1374	return        r1     0
.line	1374	return        r0     1
.line	1374	move          r0    r0
.line	1374	move          r0    r0
.line	1374	move          r0    r0
.line	1374	move          r0    r0
.line	1374	return        r0     1

.function	main/f64

.source	null
.linedefined	1381
.lastlinedefined	1390
.numparams	2
.is_vararg	0
.maxstacksize	4

.constant	k0	"UMGCanvasInfo"
.constant	k1	0
.constant	k2	"AllWidgets"
.constant	k3	"overrides"

.line	1381	test          r1     0
.line	1381	jmp            0    l6
.line	1381	gettable      r2    r1    k0 ; k0 = "UMGCanvasInfo"
.line	1381	test          r2     1
.line	1381	jmp            0    l8
.label	l6
.line	1381	loadk         r2    k1 ; k1 = 0
.line	1381	return        r2     2
.label	l8
.line	1381	gettable      r2    r1    k0 ; k0 = "UMGCanvasInfo"
.line	1381	gettable      r2    r2    k2 ; k2 = "AllWidgets"
.line	1381	test          r2     0
.line	1381	jmp            0   l16
.line	1381	gettable      r3    r2    k3 ; k3 = "overrides"
.line	1381	test          r3     0
.line	1381	jmp            0   l16
.line	1381	gettable      r2    r2    k3 ; k3 = "overrides"
.label	l16
.line	1381	test          r2     0
.line	1381	jmp            0   l21
.line	1381	len           r3    r2
.line	1381	test          r3     1
.line	1381	jmp            0   l22
.label	l21
.line	1381	loadk         r3    k1 ; k1 = 0
.label	l22
.line	1381	return        r3     2
.line	1381	return        r0     1
.line	1381	move          r0    r0
.line	1381	move          r0    r0
.line	1381	move          r0    r0
.line	1381	return        r0     1

.function	main/f65

.source	null
.linedefined	1392
.lastlinedefined	1397
.numparams	2
.is_vararg	0
.maxstacksize	3

.constant	k0	"CustomUIBase"
.constant	k1	"CanvasID"

.line	1392	test          r1     0
.line	1392	jmp            0    l6
.line	1392	gettable      r2    r1    k0 ; k0 = "CustomUIBase"
.line	1392	test          r2     1
.line	1392	jmp            0    l8
.label	l6
.line	1392	loadnil       r2     0
.line	1392	return        r2     2
.label	l8
.line	1392	gettable      r2    r1    k0 ; k0 = "CustomUIBase"
.line	1392	gettable      r2    r2    k1 ; k1 = "CanvasID"
.line	1392	return        r2     2
.line	1392	return        r0     1
.line	1392	move          r0    r0
.line	1392	move          r0    r0
.line	1392	move          r0    r0
.line	1392	move          r0    r0
.line	1392	return        r0     1

.function	main/f66

.source	null
.linedefined	1399
.lastlinedefined	1412
.numparams	4
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	nil
.constant	k1	"ReadyChildren"
.constant	k2	"print"
.constant	k3	"bWriteLog"
.constant	k4	"string"
.constant	k5	"format"
.constant	k6	"table"
.constant	k7	"concat"
.constant	k8	126
.constant	k9	68
.constant	k10	7
.constant	k11	41
.constant	k12	164
.constant	k13	170
.constant	k14	39
.constant	k15	95
.constant	k16	24
.constant	k17	91
.constant	k18	26
.constant	k19	31
.constant	k20	217
.constant	k21	83
.constant	k22	38
.constant	k23	54
.constant	k24	137
.constant	k25	103
.constant	k26	102
.constant	k27	25
.constant	k28	99
.constant	k29	156
.constant	k30	76
.constant	k31	122
.constant	k32	113
.constant	k33	127
.constant	k34	29
.constant	k35	244
.constant	k36	75
.constant	k37	2
.constant	k38	11
.constant	k39	85
.constant	k40	106
.constant	k41	1
.constant	k42	92
.constant	k43	135
.constant	k44	17
.constant	k45	105
.constant	k46	86
.constant	k47	18
.constant	k48	101
.constant	k49	180
.constant	k50	182
.constant	k51	33
.constant	k52	50
.constant	k53	77
.constant	k54	8
.constant	k55	211
.constant	k56	30
.constant	k57	138
.constant	k58	79
.constant	k59	124
.constant	k60	186
.constant	k61	69
.constant	k62	55
.constant	k63	110
.constant	k64	89
.constant	k65	56
.constant	k66	206
.constant	k67	71
.constant	k68	15
.constant	k69	148
.constant	k70	114
.constant	k71	63
.constant	k72	67
.constant	k73	"tostring"
.constant	k74	true
.constant	k75	"CurrentCount"
.constant	k76	0
.constant	k77	123
.constant	k78	82
.constant	k79	44
.constant	k80	240
.constant	k81	150
.constant	k82	28
.constant	k83	125
.constant	k84	64
.constant	k85	4
.constant	k86	255
.constant	k87	90
.constant	k88	78
.constant	k89	190
.constant	k90	81
.constant	k91	16
.constant	k92	73
.constant	k93	159
.constant	k94	47
.constant	k95	3
.constant	k96	134
.constant	k97	109
.constant	k98	22
.constant	k99	175
.constant	k100	115
.constant	k101	108
.constant	k102	13
.constant	k103	198
.constant	k104	66
.constant	k105	53
.constant	k106	"ExpectedCount"

.line	1399	test          r1     0
.line	1399	jmp            0    l5
.line	1399	eq             0    r2    k0 ; k0 = nil
.line	1399	jmp            0    l7
.label	l5
.line	1399	loadbool      r4     0     0
.line	1399	return        r4     2
.label	l7
.line	1399	gettable      r4    r1    k1 ; k1 = "ReadyChildren"
.line	1399	test          r4     1
.line	1399	jmp            0   l11
.line	1399	newtable      r4     0     0
.label	l11
.line	1399	settable      r1    k1    r4 ; k1 = "ReadyChildren"
.line	1399	gettable      r4    r1    k1 ; k1 = "ReadyChildren"
.line	1399	gettable      r4    r4    r2
.line	1399	test          r4     0
.line	1399	jmp            0  l118
.line	1399	gettabup      r4    u0    k2 ; k2 = "print"
.line	1399	gettabup      r5    u0    k3 ; k3 = "bWriteLog"
.line	1399	test          r5     0
.line	1399	jmp            0  l115
.line	1399	gettabup      r5    u0    k4 ; k4 = "string"
.line	1399	gettable      r5    r5    k5 ; k5 = "format"
.line	1399	gettabup      r6    u0    k6 ; k6 = "table"
.line	1399	gettable      r6    r6    k7 ; k7 = "concat"
.line	1399	newtable      r7     1     0
.line	1399	getupval      r8    u1
.line	1399	loadk         r9    k8 ; k8 = 126
.line	1399	loadk        r10    k9 ; k9 = 68
.line	1399	loadk        r11   k10 ; k10 = 7
.line	1399	loadk        r12   k11 ; k11 = 41
.line	1399	loadk        r13   k12 ; k12 = 164
.line	1399	loadk        r14   k13 ; k13 = 170
.line	1399	loadk        r15   k14 ; k14 = 39
.line	1399	loadk        r16   k15 ; k15 = 95
.line	1399	loadk        r17   k16 ; k16 = 24
.line	1399	loadk        r18   k17 ; k17 = 91
.line	1399	loadk        r19   k18 ; k18 = 26
.line	1399	loadk        r20   k19 ; k19 = 31
.line	1399	loadk        r21   k20 ; k20 = 217
.line	1399	loadk        r22   k21 ; k21 = 83
.line	1399	loadk        r23   k22 ; k22 = 38
.line	1399	loadk        r24   k23 ; k23 = 54
.line	1399	loadk        r25   k24 ; k24 = 137
.line	1399	loadk        r26   k25 ; k25 = 103
.line	1399	loadk        r27   k26 ; k26 = 102
.line	1399	loadk        r28   k27 ; k27 = 25
.line	1399	loadk        r29   k28 ; k28 = 99
.line	1399	loadk        r30   k29 ; k29 = 156
.line	1399	loadk        r31   k30 ; k30 = 76
.line	1399	loadk        r32   k31 ; k31 = 122
.line	1399	loadk        r33   k32 ; k32 = 113
.line	1399	loadk        r34   k33 ; k33 = 127
.line	1399	loadk        r35   k34 ; k34 = 29
.line	1399	loadk        r36   k19 ; k19 = 31
.line	1399	loadk        r37   k35 ; k35 = 244
.line	1399	loadk        r38   k36 ; k36 = 75
.line	1399	loadk        r39   k37 ; k37 = 2
.line	1399	loadk        r40   k38 ; k38 = 11
.line	1399	loadk        r41   k12 ; k12 = 164
.line	1399	loadk        r42   k39 ; k39 = 85
.line	1399	loadk        r43   k40 ; k40 = 106
.line	1399	loadk        r44   k41 ; k41 = 1
.line	1399	loadk        r45   k42 ; k42 = 92
.line	1399	loadk        r46   k43 ; k43 = 135
.line	1399	loadk        r47   k44 ; k44 = 17
.line	1399	loadk        r48   k45 ; k45 = 105
.line	1399	call          r8    41     2
.line	1399	getupval      r9    u1
.line	1399	loadk        r10   k46 ; k46 = 86
.line	1399	loadk        r11   k15 ; k15 = 95
.line	1399	loadk        r12   k47 ; k47 = 18
.line	1399	loadk        r13   k48 ; k48 = 101
.line	1399	loadk        r14   k49 ; k49 = 180
.line	1399	loadk        r15   k50 ; k50 = 182
.line	1399	loadk        r16   k51 ; k51 = 33
.line	1399	loadk        r17   k46 ; k46 = 86
.line	1399	loadk        r18   k52 ; k52 = 50
.line	1399	loadk        r19   k53 ; k53 = 77
.line	1399	loadk        r20   k54 ; k54 = 8
.line	1399	loadk        r21   k19 ; k19 = 31
.line	1399	loadk        r22   k55 ; k55 = 211
.line	1399	loadk        r23   k56 ; k56 = 30
.line	1399	loadk        r24   k22 ; k22 = 38
.line	1399	loadk        r25   k52 ; k52 = 50
.line	1399	loadk        r26   k57 ; k57 = 138
.line	1399	loadk        r27   k58 ; k58 = 79
.line	1399	loadk        r28   k59 ; k59 = 124
.line	1399	loadk        r29   k56 ; k56 = 30
.line	1399	loadk        r30   k58 ; k58 = 79
.line	1399	loadk        r31   k60 ; k60 = 186
.line	1399	loadk        r32   k61 ; k61 = 69
.line	1399	loadk        r33   k62 ; k62 = 55
.line	1399	loadk        r34   k63 ; k63 = 110
.line	1399	loadk        r35   k53 ; k53 = 77
.line	1399	loadk        r36   k64 ; k64 = 89
.line	1399	loadk        r37   k65 ; k65 = 56
.line	1399	loadk        r38   k66 ; k66 = 206
.line	1399	loadk        r39   k67 ; k67 = 71
.line	1399	loadk        r40   k68 ; k68 = 15
.line	1399	loadk        r41   k38 ; k38 = 11
.line	1399	loadk        r42   k69 ; k69 = 148
.line	1399	loadk        r43   k70 ; k70 = 114
.line	1399	loadk        r44   k71 ; k71 = 63
.line	1399	loadk        r45   k53 ; k53 = 77
.line	1399	loadk        r46   k72 ; k72 = 67
.line	1399	call          r9    38     0
.line	1399	setlist       r7     0     1
.line	1399	call          r6     2     2
.line	1399	gettabup      r7    u0   k73 ; k73 = "tostring"
.line	1399	move          r8    r3
.line	1399	call          r7     2     2
.line	1399	gettabup      r8    u0   k73 ; k73 = "tostring"
.line	1399	move          r9    r2
.line	1399	call          r8     2     0
.line	1399	call          r5     0     2
.label	l115
.line	1399	call          r4     2     1
.line	1399	loadbool      r4     0     0
.line	1399	return        r4     2
.label	l118
.line	1399	gettable      r4    r1    k1 ; k1 = "ReadyChildren"
.line	1399	settable      r4    r2   k74 ; k74 = true
.line	1399	gettable      r4    r1   k75 ; k75 = "CurrentCount"
.line	1399	test          r4     1
.line	1399	jmp            0  l124
.line	1399	loadk         r4   k76 ; k76 = 0
.label	l124
.line	1399	add           r4    r4   k41 ; k41 = 1
.line	1399	settable      r1   k75    r4 ; k75 = "CurrentCount"
.line	1399	gettabup      r4    u0    k2 ; k2 = "print"
.line	1399	gettabup      r5    u0    k3 ; k3 = "bWriteLog"
.line	1399	test          r5     0
.line	1399	jmp            0  l238
.line	1399	gettabup      r5    u0    k4 ; k4 = "string"
.line	1399	gettable      r5    r5    k5 ; k5 = "format"
.line	1399	gettabup      r6    u0    k6 ; k6 = "table"
.line	1399	gettable      r6    r6    k7 ; k7 = "concat"
.line	1399	newtable      r7     2     0
.line	1399	getupval      r8    u1
.line	1399	loadk         r9    k8 ; k8 = 126
.line	1399	loadk        r10    k9 ; k9 = 68
.line	1399	loadk        r11   k10 ; k10 = 7
.line	1399	loadk        r12   k11 ; k11 = 41
.line	1399	loadk        r13   k12 ; k12 = 164
.line	1399	loadk        r14   k13 ; k13 = 170
.line	1399	loadk        r15   k14 ; k14 = 39
.line	1399	loadk        r16   k15 ; k15 = 95
.line	1399	loadk        r17   k16 ; k16 = 24
.line	1399	loadk        r18   k17 ; k17 = 91
.line	1399	loadk        r19   k18 ; k18 = 26
.line	1399	loadk        r20   k19 ; k19 = 31
.line	1399	loadk        r21   k20 ; k20 = 217
.line	1399	loadk        r22   k21 ; k21 = 83
.line	1399	loadk        r23   k22 ; k22 = 38
.line	1399	loadk        r24   k23 ; k23 = 54
.line	1399	loadk        r25   k24 ; k24 = 137
.line	1399	loadk        r26   k25 ; k25 = 103
.line	1399	loadk        r27   k26 ; k26 = 102
.line	1399	loadk        r28   k27 ; k27 = 25
.line	1399	loadk        r29   k28 ; k28 = 99
.line	1399	loadk        r30   k29 ; k29 = 156
.line	1399	loadk        r31   k30 ; k30 = 76
.line	1399	loadk        r32   k31 ; k31 = 122
.line	1399	loadk        r33   k32 ; k32 = 113
.line	1399	loadk        r34   k33 ; k33 = 127
.line	1399	loadk        r35   k34 ; k34 = 29
.line	1399	loadk        r36   k19 ; k19 = 31
.line	1399	loadk        r37   k35 ; k35 = 244
.line	1399	loadk        r38   k36 ; k36 = 75
.line	1399	loadk        r39   k37 ; k37 = 2
.line	1399	loadk        r40   k38 ; k38 = 11
.line	1399	loadk        r41   k12 ; k12 = 164
.line	1399	loadk        r42   k39 ; k39 = 85
.line	1399	loadk        r43   k40 ; k40 = 106
.line	1399	loadk        r44   k41 ; k41 = 1
.line	1399	loadk        r45   k42 ; k42 = 92
.line	1399	loadk        r46   k43 ; k43 = 135
.line	1399	loadk        r47   k44 ; k44 = 17
.line	1399	loadk        r48   k77 ; k77 = 123
.line	1399	call          r8    41     2
.line	1399	getupval      r9    u1
.line	1399	loadk        r10   k64 ; k64 = 89
.line	1399	loadk        r11   k78 ; k78 = 82
.line	1399	loadk        r12   k10 ; k10 = 7
.line	1399	loadk        r13   k79 ; k79 = 44
.line	1399	loadk        r14   k80 ; k80 = 240
.line	1399	loadk        r15   k81 ; k81 = 150
.line	1399	loadk        r16   k82 ; k82 = 28
.line	1399	loadk        r17   k83 ; k83 = 125
.line	1399	loadk        r18   k47 ; k47 = 18
.line	1399	loadk        r19   k84 ; k84 = 64
.line	1399	loadk        r20   k68 ; k68 = 15
.line	1399	loadk        r21   k85 ; k85 = 4
.line	1399	loadk        r22   k86 ; k86 = 255
.line	1399	loadk        r23   k87 ; k87 = 90
.line	1399	loadk        r24   k88 ; k88 = 78
.line	1399	loadk        r25   k87 ; k87 = 90
.line	1399	loadk        r26   k89 ; k89 = 190
.line	1399	loadk        r27   k22 ; k22 = 38
.line	1399	loadk        r28   k90 ; k90 = 81
.line	1399	loadk        r29   k91 ; k91 = 16
.line	1399	loadk        r30   k92 ; k92 = 73
.line	1399	loadk        r31   k93 ; k93 = 159
.line	1399	loadk        r32   k61 ; k61 = 69
.line	1399	loadk        r33   k72 ; k72 = 67
.line	1399	loadk        r34   k94 ; k94 = 47
.line	1399	loadk        r35   k95 ; k95 = 3
.line	1399	loadk        r36   k42 ; k42 = 92
.line	1399	loadk        r37   k54 ; k54 = 8
.line	1399	loadk        r38   k96 ; k96 = 134
.line	1399	loadk        r39   k97 ; k97 = 109
.line	1399	loadk        r40   k98 ; k98 = 22
.line	1399	loadk        r41   k34 ; k34 = 29
.line	1399	loadk        r42   k99 ; k99 = 175
.line	1399	loadk        r43  k100 ; k100 = 115
.line	1399	loadk        r44  k101 ; k101 = 108
.line	1399	loadk        r45   k82 ; k82 = 28
.line	1399	loadk        r46  k102 ; k102 = 13
.line	1399	loadk        r47  k103 ; k103 = 198
.line	1399	loadk        r48  k104 ; k104 = 66
.line	1399	loadk        r49  k105 ; k105 = 53
.line	1399	call          r9    41     2
.line	1399	getupval     r10    u1
.line	1399	loadk        r11   k16 ; k16 = 24
.line	1399	loadk        r12   k61 ; k61 = 69
.line	1399	call         r10     3     0
.line	1399	setlist       r7     0     1
.line	1399	call          r6     2     2
.line	1399	gettabup      r7    u0   k73 ; k73 = "tostring"
.line	1399	move          r8    r3
.line	1399	call          r7     2     2
.line	1399	gettabup      r8    u0   k73 ; k73 = "tostring"
.line	1399	move          r9    r2
.line	1399	call          r8     2     2
.line	1399	gettabup      r9    u0   k73 ; k73 = "tostring"
.line	1399	gettable     r10    r1   k75 ; k75 = "CurrentCount"
.line	1399	call          r9     2     2
.line	1399	gettabup     r10    u0   k73 ; k73 = "tostring"
.line	1399	gettable     r11    r1  k106 ; k106 = "ExpectedCount"
.line	1399	call         r10     2     0
.line	1399	call          r5     0     2
.label	l238
.line	1399	call          r4     2     1
.line	1399	loadbool      r4     1     0
.line	1399	return        r4     2
.line	1399	return        r0     1
.line	1399	move          r0    r0
.line	1399	return        r0     1

.function	main/f67

.source	null
.linedefined	1414
.lastlinedefined	1439
.numparams	2
.is_vararg	0
.maxstacksize	52

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"CustomUIData"
.constant	k1	"print"
.constant	k2	"bWriteLog"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	126
.constant	k6	68
.constant	k7	7
.constant	k8	41
.constant	k9	164
.constant	k10	170
.constant	k11	39
.constant	k12	95
.constant	k13	24
.constant	k14	91
.constant	k15	26
.constant	k16	31
.constant	k17	217
.constant	k18	83
.constant	k19	38
.constant	k20	54
.constant	k21	137
.constant	k22	103
.constant	k23	102
.constant	k24	25
.constant	k25	99
.constant	k26	156
.constant	k27	76
.constant	k28	122
.constant	k29	113
.constant	k30	124
.constant	k31	12
.constant	k32	18
.constant	k33	202
.constant	k34	74
.constant	k35	32
.constant	k36	14
.constant	k37	179
.constant	k38	96
.constant	k39	27
.constant	k40	150
.constant	k41	110
.constant	k42	79
.constant	k43	104
.constant	k44	147
.constant	k45	162
.constant	k46	63
.constant	k47	58
.constant	k48	93
.constant	k49	5
.constant	k50	197
.constant	k51	17
.constant	k52	174
.constant	k53	50
.constant	k54	211
.constant	k55	"GetTreeSubsystem"
.constant	k56	"BuildCanvasSubtree"
.constant	k57	132
.constant	k58	177
.constant	k59	52
.constant	k60	8
.constant	k61	11
.constant	k62	207
.constant	k63	77
.constant	k64	160
.constant	k65	22
.constant	k66	65
.constant	k67	133
.constant	k68	64
.constant	k69	23
.constant	k70	195
.constant	k71	0
.constant	k72	"CanvasReadyState"
.constant	k73	"ReadyChildren"
.constant	k74	"pairs"
.constant	k75	1
.constant	k76	"string"
.constant	k77	"format"
.constant	k78	180
.constant	k79	34
.constant	k80	90
.constant	k81	10
.constant	k82	3
.constant	k83	107
.constant	k84	62
.constant	k85	56
.constant	k86	116
.constant	k87	105
.constant	k88	151
.constant	k89	28
.constant	k90	47
.constant	k91	30
.constant	k92	19
.constant	k93	66
.constant	k94	44
.constant	k95	178
.constant	k96	108
.constant	k97	13
.constant	k98	198
.constant	k99	"tostring"

.line	1414	gettable      r2    r0    k0 ; k0 = "CustomUIData"
.line	1414	test          r2     0
.line	1414	jmp            0    l6
.line	1414	gettable      r2    r0    k0 ; k0 = "CustomUIData"
.line	1414	gettable      r2    r2    r1
.label	l6
.line	1414	test          r2     1
.line	1414	jmp            0   l89
.line	1414	gettabup      r3    u0    k1 ; k1 = "print"
.line	1414	gettabup      r4    u0    k2 ; k2 = "bWriteLog"
.line	1414	test          r4     0
.line	1414	jmp            0   l86
.line	1414	gettabup      r4    u0    k3 ; k3 = "table"
.line	1414	gettable      r4    r4    k4 ; k4 = "concat"
.line	1414	newtable      r5     1     0
.line	1414	getupval      r6    u1
.line	1414	loadk         r7    k5 ; k5 = 126
.line	1414	loadk         r8    k6 ; k6 = 68
.line	1414	loadk         r9    k7 ; k7 = 7
.line	1414	loadk        r10    k8 ; k8 = 41
.line	1414	loadk        r11    k9 ; k9 = 164
.line	1414	loadk        r12   k10 ; k10 = 170
.line	1414	loadk        r13   k11 ; k11 = 39
.line	1414	loadk        r14   k12 ; k12 = 95
.line	1414	loadk        r15   k13 ; k13 = 24
.line	1414	loadk        r16   k14 ; k14 = 91
.line	1414	loadk        r17   k15 ; k15 = 26
.line	1414	loadk        r18   k16 ; k16 = 31
.line	1414	loadk        r19   k17 ; k17 = 217
.line	1414	loadk        r20   k18 ; k18 = 83
.line	1414	loadk        r21   k19 ; k19 = 38
.line	1414	loadk        r22   k20 ; k20 = 54
.line	1414	loadk        r23   k21 ; k21 = 137
.line	1414	loadk        r24   k22 ; k22 = 103
.line	1414	loadk        r25   k23 ; k23 = 102
.line	1414	loadk        r26   k24 ; k24 = 25
.line	1414	loadk        r27   k25 ; k25 = 99
.line	1414	loadk        r28   k26 ; k26 = 156
.line	1414	loadk        r29   k27 ; k27 = 76
.line	1414	loadk        r30   k28 ; k28 = 122
.line	1414	loadk        r31   k29 ; k29 = 113
.line	1414	loadk        r32   k30 ; k30 = 124
.line	1414	loadk        r33   k31 ; k31 = 12
.line	1414	loadk        r34   k32 ; k32 = 18
.line	1414	loadk        r35   k33 ; k33 = 202
.line	1414	loadk        r36   k34 ; k34 = 74
.line	1414	loadk        r37   k35 ; k35 = 32
.line	1414	loadk        r38   k36 ; k36 = 14
.line	1414	loadk        r39   k37 ; k37 = 179
.line	1414	loadk        r40   k38 ; k38 = 96
.line	1414	loadk        r41   k25 ; k25 = 99
.line	1414	loadk        r42   k39 ; k39 = 27
.line	1414	loadk        r43   k25 ; k25 = 99
.line	1414	loadk        r44   k40 ; k40 = 150
.line	1414	loadk        r45   k18 ; k18 = 83
.line	1414	loadk        r46   k41 ; k41 = 110
.line	1414	call          r6    41     2
.line	1414	getupval      r7    u1
.line	1414	loadk         r8   k42 ; k42 = 79
.line	1414	loadk         r9   k18 ; k18 = 83
.line	1414	loadk        r10    k7 ; k7 = 7
.line	1414	loadk        r11   k43 ; k43 = 104
.line	1414	loadk        r12   k44 ; k44 = 147
.line	1414	loadk        r13   k45 ; k45 = 162
.line	1414	loadk        r14   k46 ; k46 = 63
.line	1414	loadk        r15   k27 ; k27 = 76
.line	1414	loadk        r16   k47 ; k47 = 58
.line	1414	loadk        r17   k48 ; k48 = 93
.line	1414	loadk        r18   k35 ; k35 = 32
.line	1414	loadk        r19   k49 ; k49 = 5
.line	1414	loadk        r20   k50 ; k50 = 197
.line	1414	loadk        r21   k34 ; k34 = 74
.line	1414	loadk        r22   k32 ; k32 = 18
.line	1414	loadk        r23   k51 ; k51 = 17
.line	1414	loadk        r24   k52 ; k52 = 174
.line	1414	loadk        r25   k25 ; k25 = 99
.line	1414	loadk        r26   k53 ; k53 = 50
.line	1414	loadk        r27   k51 ; k51 = 17
.line	1414	loadk        r28   k18 ; k18 = 83
.line	1414	loadk        r29   k54 ; k54 = 211
.line	1414	loadk        r30   k42 ; k42 = 79
.line	1414	loadk        r31   k25 ; k25 = 99
.line	1414	loadk        r32   k11 ; k11 = 39
.line	1414	call          r7    26     0
.line	1414	setlist       r5     0     1
.line	1414	call          r4     2     2
.label	l86
.line	1414	move          r5    r1
.line	1414	call          r3     3     1
.line	1414	return        r0     1
.label	l89
.line	1414	self          r3    r0   k55 ; k55 = "GetTreeSubsystem"
.line	1414	call          r3     2     2
.line	1414	test          r3     0
.line	1414	jmp            0   l96
.line	1414	gettable      r4    r3   k56 ; k56 = "BuildCanvasSubtree"
.line	1414	test          r4     1
.line	1414	jmp            0  l181
.label	l96
.line	1414	gettabup      r4    u0    k1 ; k1 = "print"
.line	1414	gettabup      r5    u0    k2 ; k2 = "bWriteLog"
.line	1414	test          r5     0
.line	1414	jmp            0  l178
.line	1414	gettabup      r5    u0    k3 ; k3 = "table"
.line	1414	gettable      r5    r5    k4 ; k4 = "concat"
.line	1414	newtable      r6     1     0
.line	1414	getupval      r7    u1
.line	1414	loadk         r8    k5 ; k5 = 126
.line	1414	loadk         r9    k6 ; k6 = 68
.line	1414	loadk        r10    k7 ; k7 = 7
.line	1414	loadk        r11    k8 ; k8 = 41
.line	1414	loadk        r12    k9 ; k9 = 164
.line	1414	loadk        r13   k10 ; k10 = 170
.line	1414	loadk        r14   k11 ; k11 = 39
.line	1414	loadk        r15   k12 ; k12 = 95
.line	1414	loadk        r16   k13 ; k13 = 24
.line	1414	loadk        r17   k14 ; k14 = 91
.line	1414	loadk        r18   k15 ; k15 = 26
.line	1414	loadk        r19   k16 ; k16 = 31
.line	1414	loadk        r20   k17 ; k17 = 217
.line	1414	loadk        r21   k18 ; k18 = 83
.line	1414	loadk        r22   k19 ; k19 = 38
.line	1414	loadk        r23   k20 ; k20 = 54
.line	1414	loadk        r24   k21 ; k21 = 137
.line	1414	loadk        r25   k22 ; k22 = 103
.line	1414	loadk        r26   k23 ; k23 = 102
.line	1414	loadk        r27   k24 ; k24 = 25
.line	1414	loadk        r28   k25 ; k25 = 99
.line	1414	loadk        r29   k26 ; k26 = 156
.line	1414	loadk        r30   k27 ; k27 = 76
.line	1414	loadk        r31   k28 ; k28 = 122
.line	1414	loadk        r32   k29 ; k29 = 113
.line	1414	loadk        r33   k30 ; k30 = 124
.line	1414	loadk        r34   k31 ; k31 = 12
.line	1414	loadk        r35   k32 ; k32 = 18
.line	1414	loadk        r36   k33 ; k33 = 202
.line	1414	loadk        r37   k34 ; k34 = 74
.line	1414	loadk        r38   k35 ; k35 = 32
.line	1414	loadk        r39   k36 ; k36 = 14
.line	1414	loadk        r40   k37 ; k37 = 179
.line	1414	loadk        r41   k38 ; k38 = 96
.line	1414	loadk        r42   k25 ; k25 = 99
.line	1414	loadk        r43   k39 ; k39 = 27
.line	1414	loadk        r44   k25 ; k25 = 99
.line	1414	loadk        r45   k40 ; k40 = 150
.line	1414	loadk        r46   k18 ; k18 = 83
.line	1414	loadk        r47   k41 ; k41 = 110
.line	1414	call          r7    41     2
.line	1414	getupval      r8    u1
.line	1414	loadk         r9   k42 ; k42 = 79
.line	1414	loadk        r10   k18 ; k18 = 83
.line	1414	loadk        r11    k7 ; k7 = 7
.line	1414	loadk        r12   k43 ; k43 = 104
.line	1414	loadk        r13   k57 ; k57 = 132
.line	1414	loadk        r14   k58 ; k58 = 177
.line	1414	loadk        r15   k59 ; k59 = 52
.line	1414	loadk        r16   k12 ; k12 = 95
.line	1414	loadk        r17   k60 ; k60 = 8
.line	1414	loadk        r18   k14 ; k14 = 91
.line	1414	loadk        r19   k61 ; k61 = 11
.line	1414	loadk        r20   k13 ; k13 = 24
.line	1414	loadk        r21   k62 ; k62 = 207
.line	1414	loadk        r22   k63 ; k63 = 77
.line	1414	loadk        r23    k7 ; k7 = 7
.line	1414	loadk        r24   k15 ; k15 = 26
.line	1414	loadk        r25   k64 ; k64 = 160
.line	1414	loadk        r26   k19 ; k19 = 38
.line	1414	loadk        r27   k22 ; k22 = 103
.line	1414	loadk        r28   k65 ; k65 = 22
.line	1414	loadk        r29   k66 ; k66 = 65
.line	1414	loadk        r30   k67 ; k67 = 133
.line	1414	loadk        r31   k68 ; k68 = 64
.line	1414	loadk        r32   k25 ; k25 = 99
.line	1414	loadk        r33   k11 ; k11 = 39
.line	1414	loadk        r34   k12 ; k12 = 95
.line	1414	loadk        r35   k39 ; k39 = 27
.line	1414	loadk        r36   k69 ; k69 = 23
.line	1414	loadk        r37   k70 ; k70 = 195
.line	1414	call          r8    30     0
.line	1414	setlist       r6     0     1
.line	1414	call          r5     2     2
.label	l178
.line	1414	move          r6    r1
.line	1414	call          r4     3     1
.line	1414	return        r0     1
.label	l181
.line	1414	newtable      r4     0     0
.line	1414	loadk         r5   k71 ; k71 = 0
.line	1414	gettable      r6    r0   k72 ; k72 = "CanvasReadyState"
.line	1414	test          r6     0
.line	1414	jmp            0  l188
.line	1414	gettable      r6    r0   k72 ; k72 = "CanvasReadyState"
.line	1414	gettable      r6    r6    r1
.label	l188
.line	1414	test          r6     0
.line	1414	jmp            0  l205
.line	1414	gettable      r7    r6   k73 ; k73 = "ReadyChildren"
.line	1414	test          r7     0
.line	1414	jmp            0  l205
.line	1414	gettabup      r7    u0   k74 ; k74 = "pairs"
.line	1414	gettable      r8    r6   k73 ; k73 = "ReadyChildren"
.line	1414	call          r7     2     4
.line	1414	jmp            0  l203
.line	1414	gettable     r11    r0    k0 ; k0 = "CustomUIData"
.line	1414	gettable     r11   r11   r10
.line	1414	test         r11     0
.line	1414	jmp            0  l203
.line	1414	settable      r4   r10   r11
.line	1414	add           r5    r5   k75 ; k75 = 1
.label	l203
.line	1414	move          r0    r0
.line	1414	move          r0    r0
.label	l205
.line	1414	gettabup      r7    u0    k1 ; k1 = "print"
.line	1414	gettabup      r8    u0    k2 ; k2 = "bWriteLog"
.line	1414	test          r8     0
.line	1414	jmp            0  l306
.line	1414	gettabup      r8    u0   k76 ; k76 = "string"
.line	1414	gettable      r8    r8   k77 ; k77 = "format"
.line	1414	gettabup      r9    u0    k3 ; k3 = "table"
.line	1414	gettable      r9    r9    k4 ; k4 = "concat"
.line	1414	newtable     r10     1     0
.line	1414	getupval     r11    u1
.line	1414	loadk        r12    k5 ; k5 = 126
.line	1414	loadk        r13    k6 ; k6 = 68
.line	1414	loadk        r14    k7 ; k7 = 7
.line	1414	loadk        r15    k8 ; k8 = 41
.line	1414	loadk        r16    k9 ; k9 = 164
.line	1414	loadk        r17   k10 ; k10 = 170
.line	1414	loadk        r18   k11 ; k11 = 39
.line	1414	loadk        r19   k12 ; k12 = 95
.line	1414	loadk        r20   k13 ; k13 = 24
.line	1414	loadk        r21   k14 ; k14 = 91
.line	1414	loadk        r22   k15 ; k15 = 26
.line	1414	loadk        r23   k16 ; k16 = 31
.line	1414	loadk        r24   k17 ; k17 = 217
.line	1414	loadk        r25   k18 ; k18 = 83
.line	1414	loadk        r26   k19 ; k19 = 38
.line	1414	loadk        r27   k20 ; k20 = 54
.line	1414	loadk        r28   k21 ; k21 = 137
.line	1414	loadk        r29   k22 ; k22 = 103
.line	1414	loadk        r30   k23 ; k23 = 102
.line	1414	loadk        r31   k24 ; k24 = 25
.line	1414	loadk        r32   k25 ; k25 = 99
.line	1414	loadk        r33   k26 ; k26 = 156
.line	1414	loadk        r34   k27 ; k27 = 76
.line	1414	loadk        r35   k28 ; k28 = 122
.line	1414	loadk        r36   k29 ; k29 = 113
.line	1414	loadk        r37   k30 ; k30 = 124
.line	1414	loadk        r38   k31 ; k31 = 12
.line	1414	loadk        r39   k32 ; k32 = 18
.line	1414	loadk        r40   k33 ; k33 = 202
.line	1414	loadk        r41   k34 ; k34 = 74
.line	1414	loadk        r42   k35 ; k35 = 32
.line	1414	loadk        r43   k36 ; k36 = 14
.line	1414	loadk        r44   k37 ; k37 = 179
.line	1414	loadk        r45   k38 ; k38 = 96
.line	1414	loadk        r46   k25 ; k25 = 99
.line	1414	loadk        r47   k39 ; k39 = 27
.line	1414	loadk        r48   k25 ; k25 = 99
.line	1414	loadk        r49   k40 ; k40 = 150
.line	1414	loadk        r50   k18 ; k18 = 83
.line	1414	loadk        r51   k41 ; k41 = 110
.line	1414	call         r11    41     2
.line	1414	getupval     r12    u1
.line	1414	loadk        r13   k42 ; k42 = 79
.line	1414	loadk        r14   k18 ; k18 = 83
.line	1414	loadk        r15    k7 ; k7 = 7
.line	1414	loadk        r16   k43 ; k43 = 104
.line	1414	loadk        r17   k78 ; k78 = 180
.line	1414	loadk        r18   k10 ; k10 = 170
.line	1414	loadk        r19   k79 ; k79 = 34
.line	1414	loadk        r20   k34 ; k34 = 74
.line	1414	loadk        r21   k47 ; k47 = 58
.line	1414	loadk        r22   k80 ; k80 = 90
.line	1414	loadk        r23   k81 ; k81 = 10
.line	1414	loadk        r24   k82 ; k82 = 3
.line	1414	loadk        r25   k40 ; k40 = 150
.line	1414	loadk        r26   k83 ; k83 = 107
.line	1414	loadk        r27   k84 ; k84 = 62
.line	1414	loadk        r28   k85 ; k85 = 56
.line	1414	loadk        r29   k57 ; k57 = 132
.line	1414	loadk        r30   k43 ; k43 = 104
.line	1414	loadk        r31   k86 ; k86 = 116
.line	1414	loadk        r32   k69 ; k69 = 23
.line	1414	loadk        r33   k87 ; k87 = 105
.line	1414	loadk        r34   k88 ; k88 = 151
.line	1414	loadk        r35   k89 ; k89 = 28
.line	1414	loadk        r36   k90 ; k90 = 47
.line	1414	loadk        r37   k85 ; k85 = 56
.line	1414	loadk        r38   k91 ; k91 = 30
.line	1414	loadk        r39   k47 ; k47 = 58
.line	1414	loadk        r40   k92 ; k92 = 19
.line	1414	loadk        r41   k62 ; k62 = 207
.line	1414	loadk        r42   k93 ; k93 = 66
.line	1414	loadk        r43    k7 ; k7 = 7
.line	1414	loadk        r44   k94 ; k94 = 44
.line	1414	loadk        r45   k95 ; k95 = 178
.line	1414	loadk        r46   k25 ; k25 = 99
.line	1414	loadk        r47   k96 ; k96 = 108
.line	1414	loadk        r48   k89 ; k89 = 28
.line	1414	loadk        r49   k97 ; k97 = 13
.line	1414	loadk        r50   k98 ; k98 = 198
.line	1414	loadk        r51   k93 ; k93 = 66
.line	1414	call         r12    40     0
.line	1414	setlist      r10     0     1
.line	1414	call          r9     2     2
.line	1414	gettabup     r10    u0   k99 ; k99 = "tostring"
.line	1414	move         r11    r1
.line	1414	call         r10     2     2
.line	1414	gettabup     r11    u0   k99 ; k99 = "tostring"
.line	1414	move         r12    r5
.line	1414	call         r11     2     0
.line	1414	call          r8     0     2
.label	l306
.line	1414	call          r7     2     1
.line	1414	self          r7    r3   k56 ; k56 = "BuildCanvasSubtree"
.line	1414	move          r9    r1
.line	1414	move         r10    r2
.line	1414	move         r11    r4
.line	1414	call          r7     5     1
.line	1414	return        r0     1
.line	1414	move          r0    r0
.line	1414	move          r0    r0
.line	1414	move          r0    r0
.line	1414	move          r0    r0
.line	1414	return        r0     1

.function	main/f68

.source	null
.linedefined	1441
.lastlinedefined	1471
.numparams	2
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"CanvasBuilt"
.constant	k1	"GetWidgetObjectByRuntimeId"
.constant	k2	"RuntimeMap"
.constant	k3	"Game"
.constant	k4	"IsValid"
.constant	k5	"Widget"
.constant	k6	"print"
.constant	k7	"bWriteLog"
.constant	k8	"table"
.constant	k9	"concat"
.constant	k10	126
.constant	k11	68
.constant	k12	7
.constant	k13	41
.constant	k14	164
.constant	k15	170
.constant	k16	39
.constant	k17	95
.constant	k18	24
.constant	k19	91
.constant	k20	26
.constant	k21	31
.constant	k22	217
.constant	k23	83
.constant	k24	38
.constant	k25	54
.constant	k26	137
.constant	k27	103
.constant	k28	102
.constant	k29	25
.constant	k30	99
.constant	k31	156
.constant	k32	76
.constant	k33	122
.constant	k34	113
.constant	k35	106
.constant	k36	11
.constant	k37	18
.constant	k38	193
.constant	k39	73
.constant	k40	6
.constant	k41	29
.constant	k42	158
.constant	k43	119
.constant	k44	108
.constant	k45	30
.constant	k46	81
.constant	k47	144
.constant	k48	127
.constant	k49	92
.constant	k50	82
.constant	k51	27
.constant	k52	104
.constant	k53	163
.constant	k54	168
.constant	k55	56
.constant	k56	74
.constant	k57	118
.constant	k58	79
.constant	k59	5
.constant	k60	211
.constant	k61	23
.constant	k62	224
.constant	k63	100
.constant	k64	17
.constant	k65	135
.constant	k66	nil
.constant	k67	"CanvasReadyState"
.constant	k68	64
.constant	k69	70
.constant	k70	80
.constant	k71	13
.constant	k72	180
.constant	k73	"CurrentCount"
.constant	k74	0
.constant	k75	"ExpectedCount"
.constant	k76	"string"
.constant	k77	"format"
.constant	k78	167
.constant	k79	162
.constant	k80	78
.constant	k81	50
.constant	k82	14
.constant	k83	75
.constant	k84	227
.constant	k85	115
.constant	k86	52
.constant	k87	96
.constant	k88	125
.constant	k89	49
.constant	k90	206
.constant	k91	4
.constant	k92	121
.constant	k93	107
.constant	k94	110
.constant	k95	20
.constant	k96	28
.constant	k97	174
.constant	k98	43
.constant	k99	198
.constant	k100	66
.constant	k101	"tostring"
.constant	k102	true
.constant	k103	177
.constant	k104	93
.constant	k105	60
.constant	k106	202
.constant	k107	32
.constant	k108	120
.constant	k109	85
.constant	k110	21
.constant	k111	63
.constant	k112	"BuildCanvasSubtree"
.constant	k113	"Client"
.constant	k114	"OnCanvasReady"

.line	1441	test          r1     1
.line	1441	jmp            0    l4
.line	1441	return        r0     1
.label	l4
.line	1441	gettable      r2    r0    k0 ; k0 = "CanvasBuilt"
.line	1441	test          r2     0
.line	1441	jmp            0  l111
.line	1441	gettable      r2    r0    k0 ; k0 = "CanvasBuilt"
.line	1441	gettable      r2    r2    r1
.line	1441	test          r2     0
.line	1441	jmp            0  l111
.line	1441	self          r2    r0    k1 ; k1 = "GetWidgetObjectByRun" (truncated)
.line	1441	move          r4    r1
.line	1441	call          r2     3     2
.line	1441	testset       r3    r2     0
.line	1441	jmp            0   l29
.line	1441	gettable      r3    r2    k2 ; k2 = "RuntimeMap"
.line	1441	test          r3     0
.line	1441	jmp            0   l29
.line	1441	gettable      r3    r2    k2 ; k2 = "RuntimeMap"
.line	1441	gettable      r3    r3    r1
.line	1441	test          r3     0
.line	1441	jmp            0   l29
.line	1441	gettabup      r3    u0    k3 ; k3 = "Game"
.line	1441	self          r3    r3    k4 ; k4 = "IsValid"
.line	1441	gettable      r5    r2    k2 ; k2 = "RuntimeMap"
.line	1441	gettable      r5    r5    r1
.line	1441	gettable      r5    r5    k5 ; k5 = "Widget"
.line	1441	call          r3     3     2
.label	l29
.line	1441	test          r3     0
.line	1441	jmp            0  l109
.line	1441	gettabup      r4    u0    k6 ; k6 = "print"
.line	1441	gettabup      r5    u0    k7 ; k7 = "bWriteLog"
.line	1441	test          r5     0
.line	1441	jmp            0  l106
.line	1441	gettabup      r5    u0    k8 ; k8 = "table"
.line	1441	gettable      r5    r5    k9 ; k9 = "concat"
.line	1441	newtable      r6     1     0
.line	1441	getupval      r7    u1
.line	1441	loadk         r8   k10 ; k10 = 126
.line	1441	loadk         r9   k11 ; k11 = 68
.line	1441	loadk        r10   k12 ; k12 = 7
.line	1441	loadk        r11   k13 ; k13 = 41
.line	1441	loadk        r12   k14 ; k14 = 164
.line	1441	loadk        r13   k15 ; k15 = 170
.line	1441	loadk        r14   k16 ; k16 = 39
.line	1441	loadk        r15   k17 ; k17 = 95
.line	1441	loadk        r16   k18 ; k18 = 24
.line	1441	loadk        r17   k19 ; k19 = 91
.line	1441	loadk        r18   k20 ; k20 = 26
.line	1441	loadk        r19   k21 ; k21 = 31
.line	1441	loadk        r20   k22 ; k22 = 217
.line	1441	loadk        r21   k23 ; k23 = 83
.line	1441	loadk        r22   k24 ; k24 = 38
.line	1441	loadk        r23   k25 ; k25 = 54
.line	1441	loadk        r24   k26 ; k26 = 137
.line	1441	loadk        r25   k27 ; k27 = 103
.line	1441	loadk        r26   k28 ; k28 = 102
.line	1441	loadk        r27   k29 ; k29 = 25
.line	1441	loadk        r28   k30 ; k30 = 99
.line	1441	loadk        r29   k31 ; k31 = 156
.line	1441	loadk        r30   k32 ; k32 = 76
.line	1441	loadk        r31   k33 ; k33 = 122
.line	1441	loadk        r32   k34 ; k34 = 113
.line	1441	loadk        r33   k35 ; k35 = 106
.line	1441	loadk        r34   k36 ; k36 = 11
.line	1441	loadk        r35   k37 ; k37 = 18
.line	1441	loadk        r36   k38 ; k38 = 193
.line	1441	loadk        r37   k39 ; k39 = 73
.line	1441	loadk        r38   k40 ; k40 = 6
.line	1441	loadk        r39   k41 ; k41 = 29
.line	1441	loadk        r40   k42 ; k42 = 158
.line	1441	loadk        r41   k43 ; k43 = 119
.line	1441	loadk        r42   k44 ; k44 = 108
.line	1441	loadk        r43   k45 ; k45 = 30
.line	1441	loadk        r44   k46 ; k46 = 81
.line	1441	loadk        r45   k47 ; k47 = 144
.line	1441	loadk        r46   k30 ; k30 = 99
.line	1441	loadk        r47   k48 ; k48 = 127
.line	1441	call          r7    41     2
.line	1441	getupval      r8    u1
.line	1441	loadk         r9   k49 ; k49 = 92
.line	1441	loadk        r10   k50 ; k50 = 82
.line	1441	loadk        r11   k51 ; k51 = 27
.line	1441	loadk        r12   k52 ; k52 = 104
.line	1441	loadk        r13   k53 ; k53 = 163
.line	1441	loadk        r14   k54 ; k54 = 168
.line	1441	loadk        r15   k55 ; k55 = 56
.line	1441	loadk        r16   k56 ; k56 = 74
.line	1441	loadk        r17   k57 ; k57 = 118
.line	1441	loadk        r18   k58 ; k58 = 79
.line	1441	loadk        r19   k59 ; k59 = 5
.line	1441	loadk        r20   k29 ; k29 = 25
.line	1441	loadk        r21   k60 ; k60 = 211
.line	1441	loadk        r22   k17 ; k17 = 95
.line	1441	loadk        r23   k61 ; k61 = 23
.line	1441	loadk        r24   k40 ; k40 = 6
.line	1441	loadk        r25   k62 ; k62 = 224
.line	1441	loadk        r26   k63 ; k63 = 100
.line	1441	loadk        r27   k27 ; k27 = 103
.line	1441	loadk        r28   k64 ; k64 = 17
.line	1441	loadk        r29   k32 ; k32 = 76
.line	1441	loadk        r30   k65 ; k65 = 135
.line	1441	call          r8    23     0
.line	1441	setlist       r6     0     1
.line	1441	call          r5     2     2
.label	l106
.line	1441	move          r6    r1
.line	1441	call          r4     3     1
.line	1441	return        r0     1
.label	l109
.line	1441	gettable      r4    r0    k0 ; k0 = "CanvasBuilt"
.line	1441	settable      r4    r1   k66 ; k66 = nil
.label	l111
.line	1441	gettable      r2    r0   k67 ; k67 = "CanvasReadyState"
.line	1441	test          r2     0
.line	1441	jmp            0  l116
.line	1441	gettable      r2    r0   k67 ; k67 = "CanvasReadyState"
.line	1441	gettable      r2    r2    r1
.label	l116
.line	1441	test          r2     1
.line	1441	jmp            0  l191
.line	1441	gettabup      r3    u0    k6 ; k6 = "print"
.line	1441	gettabup      r4    u0    k7 ; k7 = "bWriteLog"
.line	1441	test          r4     0
.line	1441	jmp            0  l188
.line	1441	gettabup      r4    u0    k8 ; k8 = "table"
.line	1441	gettable      r4    r4    k9 ; k9 = "concat"
.line	1441	newtable      r5     1     0
.line	1441	getupval      r6    u1
.line	1441	loadk         r7   k10 ; k10 = 126
.line	1441	loadk         r8   k11 ; k11 = 68
.line	1441	loadk         r9   k12 ; k12 = 7
.line	1441	loadk        r10   k13 ; k13 = 41
.line	1441	loadk        r11   k14 ; k14 = 164
.line	1441	loadk        r12   k15 ; k15 = 170
.line	1441	loadk        r13   k16 ; k16 = 39
.line	1441	loadk        r14   k17 ; k17 = 95
.line	1441	loadk        r15   k18 ; k18 = 24
.line	1441	loadk        r16   k19 ; k19 = 91
.line	1441	loadk        r17   k20 ; k20 = 26
.line	1441	loadk        r18   k21 ; k21 = 31
.line	1441	loadk        r19   k22 ; k22 = 217
.line	1441	loadk        r20   k23 ; k23 = 83
.line	1441	loadk        r21   k24 ; k24 = 38
.line	1441	loadk        r22   k25 ; k25 = 54
.line	1441	loadk        r23   k26 ; k26 = 137
.line	1441	loadk        r24   k27 ; k27 = 103
.line	1441	loadk        r25   k28 ; k28 = 102
.line	1441	loadk        r26   k29 ; k29 = 25
.line	1441	loadk        r27   k30 ; k30 = 99
.line	1441	loadk        r28   k31 ; k31 = 156
.line	1441	loadk        r29   k32 ; k32 = 76
.line	1441	loadk        r30   k33 ; k33 = 122
.line	1441	loadk        r31   k34 ; k34 = 113
.line	1441	loadk        r32   k35 ; k35 = 106
.line	1441	loadk        r33   k36 ; k36 = 11
.line	1441	loadk        r34   k37 ; k37 = 18
.line	1441	loadk        r35   k38 ; k38 = 193
.line	1441	loadk        r36   k39 ; k39 = 73
.line	1441	loadk        r37   k40 ; k40 = 6
.line	1441	loadk        r38   k41 ; k41 = 29
.line	1441	loadk        r39   k42 ; k42 = 158
.line	1441	loadk        r40   k43 ; k43 = 119
.line	1441	loadk        r41   k44 ; k44 = 108
.line	1441	loadk        r42   k45 ; k45 = 30
.line	1441	loadk        r43   k46 ; k46 = 81
.line	1441	loadk        r44   k47 ; k47 = 144
.line	1441	loadk        r45   k30 ; k30 = 99
.line	1441	loadk        r46   k48 ; k48 = 127
.line	1441	call          r6    41     2
.line	1441	getupval      r7    u1
.line	1441	loadk         r8   k49 ; k49 = 92
.line	1441	loadk         r9   k50 ; k50 = 82
.line	1441	loadk        r10   k51 ; k51 = 27
.line	1441	loadk        r11   k52 ; k52 = 104
.line	1441	loadk        r12   k53 ; k53 = 163
.line	1441	loadk        r13   k54 ; k54 = 168
.line	1441	loadk        r14   k55 ; k55 = 56
.line	1441	loadk        r15   k56 ; k56 = 74
.line	1441	loadk        r16   k57 ; k57 = 118
.line	1441	loadk        r17   k68 ; k68 = 64
.line	1441	loadk        r18   k40 ; k40 = 6
.line	1441	loadk        r19   k69 ; k69 = 70
.line	1441	loadk        r20   k60 ; k60 = 211
.line	1441	loadk        r21   k70 ; k70 = 80
.line	1441	loadk        r22   k12 ; k12 = 7
.line	1441	loadk        r23   k71 ; k71 = 13
.line	1441	loadk        r24   k72 ; k72 = 180
.line	1441	call          r7    18     0
.line	1441	setlist       r5     0     1
.line	1441	call          r4     2     2
.label	l188
.line	1441	move          r5    r1
.line	1441	call          r3     3     1
.line	1441	return        r0     1
.label	l191
.line	1441	gettable      r3    r2   k73 ; k73 = "CurrentCount"
.line	1441	test          r3     1
.line	1441	jmp            0  l195
.line	1441	loadk         r3   k74 ; k74 = 0
.label	l195
.line	1441	gettable      r4    r2   k75 ; k75 = "ExpectedCount"
.line	1441	test          r4     1
.line	1441	jmp            0  l199
.line	1441	loadk         r4   k74 ; k74 = 0
.label	l199
.line	1441	lt             0    r3    r4
.line	1441	jmp            0  l307
.line	1441	gettabup      r5    u0    k6 ; k6 = "print"
.line	1441	gettabup      r6    u0    k7 ; k7 = "bWriteLog"
.line	1441	test          r6     0
.line	1441	jmp            0  l305
.line	1441	gettabup      r6    u0   k76 ; k76 = "string"
.line	1441	gettable      r6    r6   k77 ; k77 = "format"
.line	1441	gettabup      r7    u0    k8 ; k8 = "table"
.line	1441	gettable      r7    r7    k9 ; k9 = "concat"
.line	1441	newtable      r8     1     0
.line	1441	getupval      r9    u1
.line	1441	loadk        r10   k10 ; k10 = 126
.line	1441	loadk        r11   k11 ; k11 = 68
.line	1441	loadk        r12   k12 ; k12 = 7
.line	1441	loadk        r13   k13 ; k13 = 41
.line	1441	loadk        r14   k14 ; k14 = 164
.line	1441	loadk        r15   k15 ; k15 = 170
.line	1441	loadk        r16   k16 ; k16 = 39
.line	1441	loadk        r17   k17 ; k17 = 95
.line	1441	loadk        r18   k18 ; k18 = 24
.line	1441	loadk        r19   k19 ; k19 = 91
.line	1441	loadk        r20   k20 ; k20 = 26
.line	1441	loadk        r21   k21 ; k21 = 31
.line	1441	loadk        r22   k22 ; k22 = 217
.line	1441	loadk        r23   k23 ; k23 = 83
.line	1441	loadk        r24   k24 ; k24 = 38
.line	1441	loadk        r25   k25 ; k25 = 54
.line	1441	loadk        r26   k26 ; k26 = 137
.line	1441	loadk        r27   k27 ; k27 = 103
.line	1441	loadk        r28   k28 ; k28 = 102
.line	1441	loadk        r29   k29 ; k29 = 25
.line	1441	loadk        r30   k30 ; k30 = 99
.line	1441	loadk        r31   k31 ; k31 = 156
.line	1441	loadk        r32   k32 ; k32 = 76
.line	1441	loadk        r33   k33 ; k33 = 122
.line	1441	loadk        r34   k34 ; k34 = 113
.line	1441	loadk        r35   k35 ; k35 = 106
.line	1441	loadk        r36   k36 ; k36 = 11
.line	1441	loadk        r37   k37 ; k37 = 18
.line	1441	loadk        r38   k38 ; k38 = 193
.line	1441	loadk        r39   k39 ; k39 = 73
.line	1441	loadk        r40   k40 ; k40 = 6
.line	1441	loadk        r41   k41 ; k41 = 29
.line	1441	loadk        r42   k42 ; k42 = 158
.line	1441	loadk        r43   k43 ; k43 = 119
.line	1441	loadk        r44   k44 ; k44 = 108
.line	1441	loadk        r45   k45 ; k45 = 30
.line	1441	loadk        r46   k46 ; k46 = 81
.line	1441	loadk        r47   k47 ; k47 = 144
.line	1441	loadk        r48   k30 ; k30 = 99
.line	1441	loadk        r49   k48 ; k48 = 127
.line	1441	call          r9    41     2
.line	1441	getupval     r10    u1
.line	1441	loadk        r11   k49 ; k49 = 92
.line	1441	loadk        r12   k50 ; k50 = 82
.line	1441	loadk        r13   k51 ; k51 = 27
.line	1441	loadk        r14   k52 ; k52 = 104
.line	1441	loadk        r15   k78 ; k78 = 167
.line	1441	loadk        r16   k79 ; k79 = 162
.line	1441	loadk        r17   k55 ; k55 = 56
.line	1441	loadk        r18   k80 ; k80 = 78
.line	1441	loadk        r19   k81 ; k81 = 50
.line	1441	loadk        r20   k68 ; k68 = 64
.line	1441	loadk        r21   k82 ; k82 = 14
.line	1441	loadk        r22   k83 ; k83 = 75
.line	1441	loadk        r23   k84 ; k84 = 227
.line	1441	loadk        r24   k85 ; k85 = 115
.line	1441	loadk        r25   k86 ; k86 = 52
.line	1441	loadk        r26   k25 ; k25 = 54
.line	1441	loadk        r27   k53 ; k53 = 163
.line	1441	loadk        r28   k87 ; k87 = 96
.line	1441	loadk        r29   k88 ; k88 = 125
.line	1441	loadk        r30   k89 ; k89 = 49
.line	1441	loadk        r31   k11 ; k11 = 68
.line	1441	loadk        r32   k90 ; k90 = 206
.line	1441	loadk        r33   k91 ; k91 = 4
.line	1441	loadk        r34   k92 ; k92 = 121
.line	1441	loadk        r35   k93 ; k93 = 107
.line	1441	loadk        r36   k94 ; k94 = 110
.line	1441	loadk        r37   k36 ; k36 = 11
.line	1441	loadk        r38   k95 ; k95 = 20
.line	1441	loadk        r39   k38 ; k38 = 193
.line	1441	loadk        r40   k49 ; k49 = 92
.line	1441	loadk        r41   k40 ; k40 = 6
.line	1441	loadk        r42   k96 ; k96 = 28
.line	1441	loadk        r43   k97 ; k97 = 174
.line	1441	loadk        r44   k98 ; k98 = 43
.line	1441	loadk        r45   k16 ; k16 = 39
.line	1441	loadk        r46   k51 ; k51 = 27
.line	1441	loadk        r47   k21 ; k21 = 31
.line	1441	loadk        r48   k99 ; k99 = 198
.line	1441	loadk        r49  k100 ; k100 = 66
.line	1441	call         r10    40     0
.line	1441	setlist       r8     0     1
.line	1441	call          r7     2     2
.line	1441	gettabup      r8    u0  k101 ; k101 = "tostring"
.line	1441	move          r9    r1
.line	1441	call          r8     2     2
.line	1441	gettabup      r9    u0  k101 ; k101 = "tostring"
.line	1441	move         r10    r3
.line	1441	call          r9     2     2
.line	1441	gettabup     r10    u0  k101 ; k101 = "tostring"
.line	1441	move         r11    r4
.line	1441	call         r10     2     0
.line	1441	call          r6     0     2
.label	l305
.line	1441	call          r5     2     1
.line	1441	return        r0     1
.label	l307
.line	1441	gettable      r5    r0    k0 ; k0 = "CanvasBuilt"
.line	1441	settable      r5    r1  k102 ; k102 = true
.line	1441	gettabup      r5    u0    k6 ; k6 = "print"
.line	1441	gettabup      r6    u0    k7 ; k7 = "bWriteLog"
.line	1441	test          r6     0
.line	1441	jmp            0  l417
.line	1441	gettabup      r6    u0   k76 ; k76 = "string"
.line	1441	gettable      r6    r6   k77 ; k77 = "format"
.line	1441	gettabup      r7    u0    k8 ; k8 = "table"
.line	1441	gettable      r7    r7    k9 ; k9 = "concat"
.line	1441	newtable      r8     2     0
.line	1441	getupval      r9    u1
.line	1441	loadk        r10   k10 ; k10 = 126
.line	1441	loadk        r11   k11 ; k11 = 68
.line	1441	loadk        r12   k12 ; k12 = 7
.line	1441	loadk        r13   k13 ; k13 = 41
.line	1441	loadk        r14   k14 ; k14 = 164
.line	1441	loadk        r15   k15 ; k15 = 170
.line	1441	loadk        r16   k16 ; k16 = 39
.line	1441	loadk        r17   k17 ; k17 = 95
.line	1441	loadk        r18   k18 ; k18 = 24
.line	1441	loadk        r19   k19 ; k19 = 91
.line	1441	loadk        r20   k20 ; k20 = 26
.line	1441	loadk        r21   k21 ; k21 = 31
.line	1441	loadk        r22   k22 ; k22 = 217
.line	1441	loadk        r23   k23 ; k23 = 83
.line	1441	loadk        r24   k24 ; k24 = 38
.line	1441	loadk        r25   k25 ; k25 = 54
.line	1441	loadk        r26   k26 ; k26 = 137
.line	1441	loadk        r27   k27 ; k27 = 103
.line	1441	loadk        r28   k28 ; k28 = 102
.line	1441	loadk        r29   k29 ; k29 = 25
.line	1441	loadk        r30   k30 ; k30 = 99
.line	1441	loadk        r31   k31 ; k31 = 156
.line	1441	loadk        r32   k32 ; k32 = 76
.line	1441	loadk        r33   k33 ; k33 = 122
.line	1441	loadk        r34   k34 ; k34 = 113
.line	1441	loadk        r35   k35 ; k35 = 106
.line	1441	loadk        r36   k36 ; k36 = 11
.line	1441	loadk        r37   k37 ; k37 = 18
.line	1441	loadk        r38   k38 ; k38 = 193
.line	1441	loadk        r39   k39 ; k39 = 73
.line	1441	loadk        r40   k40 ; k40 = 6
.line	1441	loadk        r41   k41 ; k41 = 29
.line	1441	loadk        r42   k42 ; k42 = 158
.line	1441	loadk        r43   k43 ; k43 = 119
.line	1441	loadk        r44   k44 ; k44 = 108
.line	1441	loadk        r45   k45 ; k45 = 30
.line	1441	loadk        r46   k46 ; k46 = 81
.line	1441	loadk        r47   k47 ; k47 = 144
.line	1441	loadk        r48   k30 ; k30 = 99
.line	1441	loadk        r49   k48 ; k48 = 127
.line	1441	call          r9    41     2
.line	1441	getupval     r10    u1
.line	1441	loadk        r11   k49 ; k49 = 92
.line	1441	loadk        r12   k50 ; k50 = 82
.line	1441	loadk        r13   k51 ; k51 = 27
.line	1441	loadk        r14   k52 ; k52 = 104
.line	1441	loadk        r15   k14 ; k14 = 164
.line	1441	loadk        r16  k103 ; k103 = 177
.line	1441	loadk        r17   k55 ; k55 = 56
.line	1441	loadk        r18  k104 ; k104 = 93
.line	1441	loadk        r19  k105 ; k105 = 60
.line	1441	loadk        r20   k83 ; k83 = 75
.line	1441	loadk        r21   k51 ; k51 = 27
.line	1441	loadk        r22   k83 ; k83 = 75
.line	1441	loadk        r23   k84 ; k84 = 227
.line	1441	loadk        r24   k85 ; k85 = 115
.line	1441	loadk        r25   k86 ; k86 = 52
.line	1441	loadk        r26   k25 ; k25 = 54
.line	1441	loadk        r27   k53 ; k53 = 163
.line	1441	loadk        r28   k87 ; k87 = 96
.line	1441	loadk        r29   k88 ; k88 = 125
.line	1441	loadk        r30   k89 ; k89 = 49
.line	1441	loadk        r31   k11 ; k11 = 68
.line	1441	loadk        r32   k90 ; k90 = 206
.line	1441	loadk        r33   k91 ; k91 = 4
.line	1441	loadk        r34   k92 ; k92 = 121
.line	1441	loadk        r35   k93 ; k93 = 107
.line	1441	loadk        r36   k88 ; k88 = 125
.line	1441	loadk        r37   k64 ; k64 = 17
.line	1441	loadk        r38   k37 ; k37 = 18
.line	1441	loadk        r39  k106 ; k106 = 202
.line	1441	loadk        r40   k56 ; k56 = 74
.line	1441	loadk        r41  k107 ; k107 = 32
.line	1441	loadk        r42   k74 ; k74 = 0
.line	1441	loadk        r43   k54 ; k54 = 168
.line	1441	loadk        r44  k108 ; k108 = 120
.line	1441	loadk        r45   k57 ; k57 = 118
.line	1441	loadk        r46  k109 ; k109 = 85
.line	1441	loadk        r47  k110 ; k110 = 21
.line	1441	loadk        r48   k47 ; k47 = 144
.line	1441	loadk        r49   k45 ; k45 = 30
.line	1441	loadk        r50  k111 ; k111 = 63
.line	1441	call         r10    41     2
.line	1441	getupval     r11    u1
.line	1441	loadk        r12   k80 ; k80 = 78
.line	1441	call         r11     2     0
.line	1441	setlist       r8     0     1
.line	1441	call          r7     2     2
.line	1441	gettabup      r8    u0  k101 ; k101 = "tostring"
.line	1441	move          r9    r1
.line	1441	call          r8     2     2
.line	1441	gettabup      r9    u0  k101 ; k101 = "tostring"
.line	1441	move         r10    r3
.line	1441	call          r9     2     2
.line	1441	gettabup     r10    u0  k101 ; k101 = "tostring"
.line	1441	move         r11    r4
.line	1441	call         r10     2     0
.line	1441	call          r6     0     2
.label	l417
.line	1441	call          r5     2     1
.line	1441	self          r5    r0  k112 ; k112 = "BuildCanvasSubtree"
.line	1441	move          r7    r1
.line	1441	call          r5     3     1
.line	1441	gettabup      r5    u0  k113 ; k113 = "Client"
.line	1441	test          r5     0
.line	1441	jmp            0  l427
.line	1441	self          r5    r0  k114 ; k114 = "OnCanvasReady"
.line	1441	move          r7    r1
.line	1441	call          r5     3     1
.label	l427
.line	1441	return        r0     1
.line	1441	move          r0    r0
.line	1441	move          r0    r0
.line	1441	move          r0    r0
.line	1441	move          r0    r0
.line	1441	return        r0     1

.function	main/f69

.source	null
.linedefined	1473
.lastlinedefined	1519
.numparams	3
.is_vararg	0
.maxstacksize	54

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"CustomUIData"
.constant	k1	"print"
.constant	k2	"bWriteLog"
.constant	k3	"string"
.constant	k4	"format"
.constant	k5	"table"
.constant	k6	"concat"
.constant	k7	126
.constant	k8	68
.constant	k9	7
.constant	k10	41
.constant	k11	164
.constant	k12	170
.constant	k13	39
.constant	k14	95
.constant	k15	24
.constant	k16	91
.constant	k17	26
.constant	k18	31
.constant	k19	217
.constant	k20	83
.constant	k21	38
.constant	k22	54
.constant	k23	137
.constant	k24	103
.constant	k25	102
.constant	k26	25
.constant	k27	99
.constant	k28	156
.constant	k29	76
.constant	k30	122
.constant	k31	113
.constant	k32	27
.constant	k33	10
.constant	k34	207
.constant	k35	64
.constant	k36	21
.constant	k37	14
.constant	k38	175
.constant	k39	127
.constant	k40	6
.constant	k41	206
.constant	k42	104
.constant	k43	82
.constant	k44	93
.constant	k45	240
.constant	k46	138
.constant	k47	63
.constant	k48	73
.constant	k49	47
.constant	k50	79
.constant	k51	8
.constant	k52	211
.constant	k53	30
.constant	k54	12
.constant	k55	237
.constant	k56	123
.constant	k57	20
.constant	k58	0
.constant	k59	186
.constant	k60	69
.constant	k61	55
.constant	k62	110
.constant	k63	77
.constant	k64	"tostring"
.constant	k65	"CanvasReadyState"
.constant	k66	"CanvasBuilt"
.constant	k67	"UMGCanvasInfo"
.constant	k68	nil
.constant	k69	"ExpectedCount"
.constant	k70	"ReadyChildren"
.constant	k71	"CurrentCount"
.constant	k72	"GetExpectedChildCountFromInstance"
.constant	k73	197
.constant	k74	13
.constant	k75	188
.constant	k76	101
.constant	k77	85
.constant	k78	130
.constant	k79	29
.constant	k80	15
.constant	k81	153
.constant	k82	173
.constant	k83	18
.constant	k84	74
.constant	k85	84
.constant	k86	78
.constant	k87	189
.constant	k88	151
.constant	k89	28
.constant	k90	56
.constant	k91	212
.constant	k92	23
.constant	k93	59
.constant	k94	180
.constant	k95	144
.constant	k96	"pairs"
.constant	k97	"CustomUIBase"
.constant	k98	"GetCanvasIDOfWidget"
.constant	k99	"AddReadyChild"
.constant	k100	1
.constant	k101	128
.constant	k102	94
.constant	k103	118
.constant	k104	81
.constant	k105	60
.constant	k106	150
.constant	k107	125
.constant	k108	4
.constant	k109	255
.constant	k110	90
.constant	k111	190
.constant	k112	67
.constant	k113	46
.constant	k114	194
.constant	k115	19
.constant	k116	70
.constant	k117	253
.constant	k118	119
.constant	k119	66
.constant	k120	134
.constant	k121	17
.constant	k122	245
.constant	k123	176
.constant	k124	3
.constant	k125	185
.constant	k126	114
.constant	k127	135
.constant	k128	88
.constant	k129	116
.constant	k130	22
.constant	k131	33
.constant	k132	32
.constant	k133	53
.constant	k134	115
.constant	k135	187
.constant	k136	97
.constant	k137	49
.constant	k138	100
.constant	k139	121
.constant	k140	107
.constant	k141	9
.constant	k142	149
.constant	k143	80
.constant	k144	105
.constant	k145	"TriggerCanvasReady"

.line	1473	gettable      r3    r0    k0 ; k0 = "CustomUIData"
.line	1473	gettable      r3    r3    r1
.line	1473	test          r3     1
.line	1473	jmp            0   l93
.line	1473	gettabup      r4    u0    k1 ; k1 = "print"
.line	1473	gettabup      r5    u0    k2 ; k2 = "bWriteLog"
.line	1473	test          r5     0
.line	1473	jmp            0   l91
.line	1473	gettabup      r5    u0    k3 ; k3 = "string"
.line	1473	gettable      r5    r5    k4 ; k4 = "format"
.line	1473	gettabup      r6    u0    k5 ; k5 = "table"
.line	1473	gettable      r6    r6    k6 ; k6 = "concat"
.line	1473	newtable      r7     1     0
.line	1473	getupval      r8    u1
.line	1473	loadk         r9    k7 ; k7 = 126
.line	1473	loadk        r10    k8 ; k8 = 68
.line	1473	loadk        r11    k9 ; k9 = 7
.line	1473	loadk        r12   k10 ; k10 = 41
.line	1473	loadk        r13   k11 ; k11 = 164
.line	1473	loadk        r14   k12 ; k12 = 170
.line	1473	loadk        r15   k13 ; k13 = 39
.line	1473	loadk        r16   k14 ; k14 = 95
.line	1473	loadk        r17   k15 ; k15 = 24
.line	1473	loadk        r18   k16 ; k16 = 91
.line	1473	loadk        r19   k17 ; k17 = 26
.line	1473	loadk        r20   k18 ; k18 = 31
.line	1473	loadk        r21   k19 ; k19 = 217
.line	1473	loadk        r22   k20 ; k20 = 83
.line	1473	loadk        r23   k21 ; k21 = 38
.line	1473	loadk        r24   k22 ; k22 = 54
.line	1473	loadk        r25   k23 ; k23 = 137
.line	1473	loadk        r26   k24 ; k24 = 103
.line	1473	loadk        r27   k25 ; k25 = 102
.line	1473	loadk        r28   k26 ; k26 = 25
.line	1473	loadk        r29   k27 ; k27 = 99
.line	1473	loadk        r30   k28 ; k28 = 156
.line	1473	loadk        r31   k29 ; k29 = 76
.line	1473	loadk        r32   k30 ; k30 = 122
.line	1473	loadk        r33   k31 ; k31 = 113
.line	1473	loadk        r34   k32 ; k32 = 27
.line	1473	loadk        r35   k33 ; k33 = 10
.line	1473	loadk        r36   k16 ; k16 = 91
.line	1473	loadk        r37   k34 ; k34 = 207
.line	1473	loadk        r38   k35 ; k35 = 64
.line	1473	loadk        r39   k36 ; k36 = 21
.line	1473	loadk        r40   k37 ; k37 = 14
.line	1473	loadk        r41   k38 ; k38 = 175
.line	1473	loadk        r42   k39 ; k39 = 127
.line	1473	loadk        r43   k27 ; k27 = 99
.line	1473	loadk        r44   k40 ; k40 = 6
.line	1473	loadk        r45    k8 ; k8 = 68
.line	1473	loadk        r46   k41 ; k41 = 206
.line	1473	loadk        r47   k20 ; k20 = 83
.line	1473	loadk        r48   k42 ; k42 = 104
.line	1473	call          r8    41     2
.line	1473	getupval      r9    u1
.line	1473	loadk        r10   k43 ; k43 = 82
.line	1473	loadk        r11   k44 ; k44 = 93
.line	1473	loadk        r12    k9 ; k9 = 7
.line	1473	loadk        r13   k21 ; k21 = 38
.line	1473	loadk        r14   k45 ; k45 = 240
.line	1473	loadk        r15   k46 ; k46 = 138
.line	1473	loadk        r16   k47 ; k47 = 63
.line	1473	loadk        r17   k48 ; k48 = 73
.line	1473	loadk        r18   k49 ; k49 = 47
.line	1473	loadk        r19   k50 ; k50 = 79
.line	1473	loadk        r20    k9 ; k9 = 7
.line	1473	loadk        r21   k51 ; k51 = 8
.line	1473	loadk        r22   k52 ; k52 = 211
.line	1473	loadk        r23   k53 ; k53 = 30
.line	1473	loadk        r24   k17 ; k17 = 26
.line	1473	loadk        r25   k54 ; k54 = 12
.line	1473	loadk        r26   k55 ; k55 = 237
.line	1473	loadk        r27   k42 ; k42 = 104
.line	1473	loadk        r28   k56 ; k56 = 123
.line	1473	loadk        r29   k57 ; k57 = 20
.line	1473	loadk        r30   k58 ; k58 = 0
.line	1473	loadk        r31   k59 ; k59 = 186
.line	1473	loadk        r32   k60 ; k60 = 69
.line	1473	loadk        r33   k61 ; k61 = 55
.line	1473	loadk        r34   k62 ; k62 = 110
.line	1473	loadk        r35   k63 ; k63 = 77
.line	1473	call          r9    27     0
.line	1473	setlist       r7     0     1
.line	1473	call          r6     2     2
.line	1473	move          r7    r2
.line	1473	gettabup      r8    u0   k64 ; k64 = "tostring"
.line	1473	move          r9    r1
.line	1473	call          r8     2     0
.line	1473	call          r5     0     2
.label	l91
.line	1473	call          r4     2     1
.line	1473	return        r0     1
.label	l93
.line	1473	gettable      r4    r0   k65 ; k65 = "CanvasReadyState"
.line	1473	test          r4     1
.line	1473	jmp            0   l97
.line	1473	newtable      r4     0     0
.label	l97
.line	1473	settable      r0   k65    r4 ; k65 = "CanvasReadyState"
.line	1473	gettable      r4    r0   k66 ; k66 = "CanvasBuilt"
.line	1473	test          r4     1
.line	1473	jmp            0  l102
.line	1473	newtable      r4     0     0
.label	l102
.line	1473	settable      r0   k66    r4 ; k66 = "CanvasBuilt"
.line	1473	loadnil       r4     0
.line	1473	gettable      r5    r3   k67 ; k67 = "UMGCanvasInfo"
.line	1473	test          r5     0
.line	1473	jmp            0  l381
.line	1473	gettable      r5    r0   k65 ; k65 = "CanvasReadyState"
.line	1473	gettable      r5    r5    r1
.line	1473	eq             1    r5   k68 ; k68 = nil
.line	1473	jmp            0  l112
.line	1473	loadbool      r6     0     1
.label	l112
.line	1473	loadbool      r6     1     0
.line	1473	test          r5     1
.line	1473	jmp            0  l123
.line	1473	newtable      r7     0     3
.line	1473	settable      r7   k69   k58 ; k58 = 0
.line	1473	newtable      r8     0     0
.line	1473	settable      r7   k70    r8 ; k70 = "ReadyChildren"
.line	1473	settable      r7   k71   k58 ; k58 = 0
.line	1473	move          r5    r7
.line	1473	gettable      r7    r0   k65 ; k65 = "CanvasReadyState"
.line	1473	settable      r7    r1    r5
.label	l123
.line	1473	self          r7    r0   k72 ; k72 = "GetExpectedChildCoun" (truncated)
.line	1473	move          r9    r3
.line	1473	call          r7     3     2
.line	1473	settable      r5   k69    r7 ; k69 = "ExpectedCount"
.line	1473	gettabup      r7    u0    k1 ; k1 = "print"
.line	1473	gettabup      r8    u0    k2 ; k2 = "bWriteLog"
.line	1473	test          r8     0
.line	1473	jmp            0  l231
.line	1473	gettabup      r8    u0    k3 ; k3 = "string"
.line	1473	gettable      r8    r8    k4 ; k4 = "format"
.line	1473	gettabup      r9    u0    k5 ; k5 = "table"
.line	1473	gettable      r9    r9    k6 ; k6 = "concat"
.line	1473	newtable     r10     1     0
.line	1473	getupval     r11    u1
.line	1473	loadk        r12    k7 ; k7 = 126
.line	1473	loadk        r13    k8 ; k8 = 68
.line	1473	loadk        r14    k9 ; k9 = 7
.line	1473	loadk        r15   k10 ; k10 = 41
.line	1473	loadk        r16   k11 ; k11 = 164
.line	1473	loadk        r17   k12 ; k12 = 170
.line	1473	loadk        r18   k13 ; k13 = 39
.line	1473	loadk        r19   k14 ; k14 = 95
.line	1473	loadk        r20   k15 ; k15 = 24
.line	1473	loadk        r21   k16 ; k16 = 91
.line	1473	loadk        r22   k17 ; k17 = 26
.line	1473	loadk        r23   k18 ; k18 = 31
.line	1473	loadk        r24   k19 ; k19 = 217
.line	1473	loadk        r25   k20 ; k20 = 83
.line	1473	loadk        r26   k21 ; k21 = 38
.line	1473	loadk        r27   k22 ; k22 = 54
.line	1473	loadk        r28   k23 ; k23 = 137
.line	1473	loadk        r29   k24 ; k24 = 103
.line	1473	loadk        r30   k25 ; k25 = 102
.line	1473	loadk        r31   k26 ; k26 = 25
.line	1473	loadk        r32   k27 ; k27 = 99
.line	1473	loadk        r33   k28 ; k28 = 156
.line	1473	loadk        r34   k29 ; k29 = 76
.line	1473	loadk        r35   k30 ; k30 = 122
.line	1473	loadk        r36   k31 ; k31 = 113
.line	1473	loadk        r37   k32 ; k32 = 27
.line	1473	loadk        r38   k33 ; k33 = 10
.line	1473	loadk        r39   k16 ; k16 = 91
.line	1473	loadk        r40   k73 ; k73 = 197
.line	1473	loadk        r41   k50 ; k50 = 79
.line	1473	loadk        r42   k74 ; k74 = 13
.line	1473	loadk        r43   k26 ; k26 = 25
.line	1473	loadk        r44   k75 ; k75 = 188
.line	1473	loadk        r45   k76 ; k76 = 101
.line	1473	loadk        r46   k49 ; k49 = 47
.line	1473	loadk        r47   k17 ; k17 = 26
.line	1473	loadk        r48   k77 ; k77 = 85
.line	1473	loadk        r49   k78 ; k78 = 130
.line	1473	loadk        r50   k77 ; k77 = 85
.line	1473	loadk        r51   k27 ; k27 = 99
.line	1473	call         r11    41     2
.line	1473	getupval     r12    u1
.line	1473	loadk        r13   k79 ; k79 = 29
.line	1473	loadk        r14   k27 ; k27 = 99
.line	1473	loadk        r15   k49 ; k49 = 47
.line	1473	loadk        r16   k80 ; k80 = 15
.line	1473	loadk        r17   k81 ; k81 = 153
.line	1473	loadk        r18   k82 ; k82 = 173
.line	1473	loadk        r19   k61 ; k61 = 55
.line	1473	loadk        r20   k77 ; k77 = 85
.line	1473	loadk        r21   k83 ; k83 = 18
.line	1473	loadk        r22   k84 ; k84 = 74
.line	1473	loadk        r23   k85 ; k85 = 84
.line	1473	loadk        r24   k86 ; k86 = 78
.line	1473	loadk        r25   k73 ; k73 = 197
.line	1473	loadk        r26   k53 ; k53 = 30
.line	1473	loadk        r27   k22 ; k22 = 54
.line	1473	loadk        r28    k9 ; k9 = 7
.line	1473	loadk        r29   k87 ; k87 = 189
.line	1473	loadk        r30   k27 ; k27 = 99
.line	1473	loadk        r31   k31 ; k31 = 113
.line	1473	loadk        r32   k54 ; k54 = 12
.line	1473	loadk        r33   k60 ; k60 = 69
.line	1473	loadk        r34   k88 ; k88 = 151
.line	1473	loadk        r35   k89 ; k89 = 28
.line	1473	loadk        r36   k49 ; k49 = 47
.line	1473	loadk        r37   k90 ; k90 = 56
.line	1473	loadk        r38   k53 ; k53 = 30
.line	1473	loadk        r39   k47 ; k47 = 63
.line	1473	loadk        r40   k83 ; k83 = 18
.line	1473	loadk        r41   k91 ; k91 = 212
.line	1473	loadk        r42   k44 ; k44 = 93
.line	1473	loadk        r43   k92 ; k92 = 23
.line	1473	loadk        r44   k93 ; k93 = 59
.line	1473	loadk        r45   k94 ; k94 = 180
.line	1473	loadk        r46   k56 ; k56 = 123
.line	1473	loadk        r47   k24 ; k24 = 103
.line	1473	loadk        r48   k77 ; k77 = 85
.line	1473	loadk        r49   k36 ; k36 = 21
.line	1473	loadk        r50   k95 ; k95 = 144
.line	1473	call         r12    39     0
.line	1473	setlist      r10     0     1
.line	1473	call          r9     2     2
.line	1473	move         r10    r2
.line	1473	gettabup     r11    u0   k64 ; k64 = "tostring"
.line	1473	move         r12    r1
.line	1473	call         r11     2     2
.line	1473	gettabup     r12    u0   k64 ; k64 = "tostring"
.line	1473	gettable     r13    r5   k69 ; k69 = "ExpectedCount"
.line	1473	call         r12     2     2
.line	1473	gettabup     r13    u0   k64 ; k64 = "tostring"
.line	1473	move         r14    r6
.line	1473	call         r13     2     0
.line	1473	call          r8     0     2
.label	l231
.line	1473	call          r7     2     1
.line	1473	loadk         r7   k58 ; k58 = 0
.line	1473	gettabup      r8    u0   k96 ; k96 = "pairs"
.line	1473	gettable      r9    r0    k0 ; k0 = "CustomUIData"
.line	1473	call          r8     2     4
.line	1473	jmp            0  l259
.line	1473	eq             1   r11    r1
.line	1473	jmp            0  l259
.line	1473	gettable     r13    r0    k0 ; k0 = "CustomUIData"
.line	1473	gettable     r13   r13   r11
.line	1473	test         r13     0
.line	1473	jmp            0  l259
.line	1473	gettable     r14   r13   k97 ; k97 = "CustomUIBase"
.line	1473	test         r14     0
.line	1473	jmp            0  l259
.line	1473	self         r14    r0   k98 ; k98 = "GetCanvasIDOfWidget"
.line	1473	move         r16   r13
.line	1473	call         r14     3     2
.line	1473	eq             0   r14    r1
.line	1473	jmp            0  l259
.line	1473	self         r14    r0   k99 ; k99 = "AddReadyChild"
.line	1473	move         r16    r5
.line	1473	move         r17   r11
.line	1473	move         r18    r1
.line	1473	call         r14     5     2
.line	1473	test         r14     0
.line	1473	jmp            0  l259
.line	1473	add           r7    r7  k100 ; k100 = 1
.label	l259
.line	1473	move          r0    r0
.line	1473	move          r0    r0
.line	1473	gettabup      r8    u0    k1 ; k1 = "print"
.line	1473	gettabup      r9    u0    k2 ; k2 = "bWriteLog"
.line	1473	test          r9     0
.line	1473	jmp            0  l378
.line	1473	gettabup      r9    u0    k3 ; k3 = "string"
.line	1473	gettable      r9    r9    k4 ; k4 = "format"
.line	1473	gettabup     r10    u0    k5 ; k5 = "table"
.line	1473	gettable     r10   r10    k6 ; k6 = "concat"
.line	1473	newtable     r11     2     0
.line	1473	getupval     r12    u1
.line	1473	loadk        r13    k7 ; k7 = 126
.line	1473	loadk        r14    k8 ; k8 = 68
.line	1473	loadk        r15    k9 ; k9 = 7
.line	1473	loadk        r16   k10 ; k10 = 41
.line	1473	loadk        r17   k11 ; k11 = 164
.line	1473	loadk        r18   k12 ; k12 = 170
.line	1473	loadk        r19   k13 ; k13 = 39
.line	1473	loadk        r20   k14 ; k14 = 95
.line	1473	loadk        r21   k15 ; k15 = 24
.line	1473	loadk        r22   k16 ; k16 = 91
.line	1473	loadk        r23   k17 ; k17 = 26
.line	1473	loadk        r24   k18 ; k18 = 31
.line	1473	loadk        r25   k19 ; k19 = 217
.line	1473	loadk        r26   k20 ; k20 = 83
.line	1473	loadk        r27   k21 ; k21 = 38
.line	1473	loadk        r28   k22 ; k22 = 54
.line	1473	loadk        r29   k23 ; k23 = 137
.line	1473	loadk        r30   k24 ; k24 = 103
.line	1473	loadk        r31   k25 ; k25 = 102
.line	1473	loadk        r32   k26 ; k26 = 25
.line	1473	loadk        r33   k27 ; k27 = 99
.line	1473	loadk        r34   k28 ; k28 = 156
.line	1473	loadk        r35   k29 ; k29 = 76
.line	1473	loadk        r36   k30 ; k30 = 122
.line	1473	loadk        r37   k31 ; k31 = 113
.line	1473	loadk        r38   k32 ; k32 = 27
.line	1473	loadk        r39   k33 ; k33 = 10
.line	1473	loadk        r40   k16 ; k16 = 91
.line	1473	loadk        r41   k73 ; k73 = 197
.line	1473	loadk        r42   k50 ; k50 = 79
.line	1473	loadk        r43   k74 ; k74 = 13
.line	1473	loadk        r44   k26 ; k26 = 25
.line	1473	loadk        r45   k75 ; k75 = 188
.line	1473	loadk        r46   k76 ; k76 = 101
.line	1473	loadk        r47   k49 ; k49 = 47
.line	1473	loadk        r48   k17 ; k17 = 26
.line	1473	loadk        r49   k77 ; k77 = 85
.line	1473	loadk        r50  k101 ; k101 = 128
.line	1473	loadk        r51  k102 ; k102 = 94
.line	1473	loadk        r52  k103 ; k103 = 118
.line	1473	call         r12    41     2
.line	1473	getupval     r13    u1
.line	1473	loadk        r14  k104 ; k104 = 81
.line	1473	loadk        r15   k20 ; k20 = 83
.line	1473	loadk        r16  k100 ; k100 = 1
.line	1473	loadk        r17  k105 ; k105 = 60
.line	1473	loadk        r18   k45 ; k45 = 240
.line	1473	loadk        r19  k106 ; k106 = 150
.line	1473	loadk        r20   k89 ; k89 = 28
.line	1473	loadk        r21  k107 ; k107 = 125
.line	1473	loadk        r22   k83 ; k83 = 18
.line	1473	loadk        r23   k35 ; k35 = 64
.line	1473	loadk        r24   k80 ; k80 = 15
.line	1473	loadk        r25  k108 ; k108 = 4
.line	1473	loadk        r26  k109 ; k109 = 255
.line	1473	loadk        r27  k110 ; k110 = 90
.line	1473	loadk        r28   k86 ; k86 = 78
.line	1473	loadk        r29  k110 ; k110 = 90
.line	1473	loadk        r30  k111 ; k111 = 190
.line	1473	loadk        r31   k21 ; k21 = 38
.line	1473	loadk        r32   k35 ; k35 = 64
.line	1473	loadk        r33   k79 ; k79 = 29
.line	1473	loadk        r34  k112 ; k112 = 67
.line	1473	loadk        r35   k28 ; k28 = 156
.line	1473	loadk        r36   k63 ; k63 = 77
.line	1473	loadk        r37   k25 ; k25 = 102
.line	1473	loadk        r38  k113 ; k113 = 46
.line	1473	loadk        r39   k44 ; k44 = 93
.line	1473	loadk        r40   k74 ; k74 = 13
.line	1473	loadk        r41   k53 ; k53 = 30
.line	1473	loadk        r42  k114 ; k114 = 194
.line	1473	loadk        r43  k115 ; k115 = 19
.line	1473	loadk        r44  k116 ; k116 = 70
.line	1473	loadk        r45   k89 ; k89 = 28
.line	1473	loadk        r46  k117 ; k117 = 253
.line	1473	loadk        r47   k77 ; k77 = 85
.line	1473	loadk        r48  k118 ; k118 = 119
.line	1473	loadk        r49   k17 ; k17 = 26
.line	1473	loadk        r50  k119 ; k119 = 66
.line	1473	loadk        r51  k120 ; k120 = 134
.line	1473	loadk        r52   k14 ; k14 = 95
.line	1473	loadk        r53   k62 ; k62 = 110
.line	1473	call         r13    41     2
.line	1473	getupval     r14    u1
.line	1473	loadk        r15   k58 ; k58 = 0
.line	1473	loadk        r16  k115 ; k115 = 19
.line	1473	loadk        r17  k121 ; k121 = 17
.line	1473	loadk        r18   k24 ; k24 = 103
.line	1473	loadk        r19  k122 ; k122 = 245
.line	1473	loadk        r20  k123 ; k123 = 176
.line	1473	call         r14     7     0
.line	1473	setlist      r11     0     1
.line	1473	call         r10     2     2
.line	1473	move         r11    r2
.line	1473	gettabup     r12    u0   k64 ; k64 = "tostring"
.line	1473	move         r13    r1
.line	1473	call         r12     2     2
.line	1473	gettabup     r13    u0   k64 ; k64 = "tostring"
.line	1473	move         r14    r7
.line	1473	call         r13     2     2
.line	1473	gettabup     r14    u0   k64 ; k64 = "tostring"
.line	1473	gettable     r15    r5   k71 ; k71 = "CurrentCount"
.line	1473	call         r14     2     2
.line	1473	gettabup     r15    u0   k64 ; k64 = "tostring"
.line	1473	gettable     r16    r5   k69 ; k69 = "ExpectedCount"
.line	1473	call         r15     2     0
.line	1473	call          r9     0     2
.label	l378
.line	1473	call          r8     2     1
.line	1473	move          r4    r1
.line	1473	jmp            0  l507
.label	l381
.line	1473	gettable      r5    r3   k97 ; k97 = "CustomUIBase"
.line	1473	test          r5     0
.line	1473	jmp            0  l507
.line	1473	self          r5    r0   k98 ; k98 = "GetCanvasIDOfWidget"
.line	1473	move          r7    r3
.line	1473	call          r5     3     2
.line	1473	testset       r6    r5     0
.line	1473	jmp            0  l391
.line	1473	gettable      r6    r0   k65 ; k65 = "CanvasReadyState"
.line	1473	gettable      r6    r6    r5
.label	l391
.line	1473	test          r6     0
.line	1473	jmp            0  l400
.line	1473	self          r7    r0   k99 ; k99 = "AddReadyChild"
.line	1473	move          r9    r6
.line	1473	move         r10    r1
.line	1473	move         r11    r5
.line	1473	call          r7     5     1
.line	1473	move          r4    r5
.line	1473	jmp            0  l507
.label	l400
.line	1473	gettabup      r7    u0    k1 ; k1 = "print"
.line	1473	gettabup      r8    u0    k2 ; k2 = "bWriteLog"
.line	1473	test          r8     0
.line	1473	jmp            0  l506
.line	1473	gettabup      r8    u0    k3 ; k3 = "string"
.line	1473	gettable      r8    r8    k4 ; k4 = "format"
.line	1473	gettabup      r9    u0    k5 ; k5 = "table"
.line	1473	gettable      r9    r9    k6 ; k6 = "concat"
.line	1473	newtable     r10     2     0
.line	1473	getupval     r11    u1
.line	1473	loadk        r12    k7 ; k7 = 126
.line	1473	loadk        r13    k8 ; k8 = 68
.line	1473	loadk        r14    k9 ; k9 = 7
.line	1473	loadk        r15   k10 ; k10 = 41
.line	1473	loadk        r16   k11 ; k11 = 164
.line	1473	loadk        r17   k12 ; k12 = 170
.line	1473	loadk        r18   k13 ; k13 = 39
.line	1473	loadk        r19   k14 ; k14 = 95
.line	1473	loadk        r20   k15 ; k15 = 24
.line	1473	loadk        r21   k16 ; k16 = 91
.line	1473	loadk        r22   k17 ; k17 = 26
.line	1473	loadk        r23   k18 ; k18 = 31
.line	1473	loadk        r24   k19 ; k19 = 217
.line	1473	loadk        r25   k20 ; k20 = 83
.line	1473	loadk        r26   k21 ; k21 = 38
.line	1473	loadk        r27   k22 ; k22 = 54
.line	1473	loadk        r28   k23 ; k23 = 137
.line	1473	loadk        r29   k24 ; k24 = 103
.line	1473	loadk        r30   k25 ; k25 = 102
.line	1473	loadk        r31   k26 ; k26 = 25
.line	1473	loadk        r32   k27 ; k27 = 99
.line	1473	loadk        r33   k28 ; k28 = 156
.line	1473	loadk        r34   k29 ; k29 = 76
.line	1473	loadk        r35   k30 ; k30 = 122
.line	1473	loadk        r36   k31 ; k31 = 113
.line	1473	loadk        r37   k32 ; k32 = 27
.line	1473	loadk        r38   k33 ; k33 = 10
.line	1473	loadk        r39   k16 ; k16 = 91
.line	1473	loadk        r40   k73 ; k73 = 197
.line	1473	loadk        r41  k116 ; k116 = 70
.line	1473	loadk        r42   k33 ; k33 = 10
.line	1473	loadk        r43  k124 ; k124 = 3
.line	1473	loadk        r44  k125 ; k125 = 185
.line	1473	loadk        r45   k93 ; k93 = 59
.line	1473	loadk        r46  k126 ; k126 = 114
.line	1473	loadk        r47   k74 ; k74 = 13
.line	1473	loadk        r48  k102 ; k102 = 94
.line	1473	loadk        r49  k127 ; k127 = 135
.line	1473	loadk        r50  k128 ; k128 = 88
.line	1473	loadk        r51  k129 ; k129 = 116
.line	1473	call         r11    41     2
.line	1473	getupval     r12    u1
.line	1473	loadk        r13  k110 ; k110 = 90
.line	1473	loadk        r14  k130 ; k130 = 22
.line	1473	loadk        r15  k131 ; k131 = 33
.line	1473	loadk        r16  k132 ; k132 = 32
.line	1473	loadk        r17  k125 ; k125 = 185
.line	1473	loadk        r18   k38 ; k38 = 175
.line	1473	loadk        r19  k133 ; k133 = 53
.line	1473	loadk        r20  k134 ; k134 = 115
.line	1473	loadk        r21   k47 ; k47 = 63
.line	1473	loadk        r22  k115 ; k115 = 19
.line	1473	loadk        r23   k29 ; k29 = 76
.line	1473	loadk        r24   k15 ; k15 = 24
.line	1473	loadk        r25  k106 ; k106 = 150
.line	1473	loadk        r26  k107 ; k107 = 125
.line	1473	loadk        r27   k83 ; k83 = 18
.line	1473	loadk        r28  k121 ; k121 = 17
.line	1473	loadk        r29  k135 ; k135 = 187
.line	1473	loadk        r30   k24 ; k24 = 103
.line	1473	loadk        r31  k136 ; k136 = 97
.line	1473	loadk        r32  k137 ; k137 = 49
.line	1473	loadk        r33  k138 ; k138 = 100
.line	1473	loadk        r34   k41 ; k41 = 206
.line	1473	loadk        r35  k108 ; k108 = 4
.line	1473	loadk        r36  k139 ; k139 = 121
.line	1473	loadk        r37  k140 ; k140 = 107
.line	1473	loadk        r38  k130 ; k130 = 22
.line	1473	loadk        r39   k37 ; k37 = 14
.line	1473	loadk        r40   k17 ; k17 = 26
.line	1473	loadk        r41   k34 ; k34 = 207
.line	1473	loadk        r42  k110 ; k110 = 90
.line	1473	loadk        r43   k33 ; k33 = 10
.line	1473	loadk        r44  k100 ; k100 = 1
.line	1473	loadk        r45   k59 ; k59 = 186
.line	1473	loadk        r46   k93 ; k93 = 59
.line	1473	loadk        r47  k136 ; k136 = 97
.line	1473	loadk        r48  k141 ; k141 = 9
.line	1473	loadk        r49  k102 ; k102 = 94
.line	1473	loadk        r50  k142 ; k142 = 149
.line	1473	loadk        r51  k143 ; k143 = 80
.line	1473	loadk        r52  k144 ; k144 = 105
.line	1473	call         r12    41     2
.line	1473	getupval     r13    u1
.line	1473	loadk        r14   k57 ; k57 = 20
.line	1473	call         r13     2     0
.line	1473	setlist      r10     0     1
.line	1473	call          r9     2     2
.line	1473	move         r10    r2
.line	1473	gettabup     r11    u0   k64 ; k64 = "tostring"
.line	1473	move         r12    r1
.line	1473	call         r11     2     2
.line	1473	gettabup     r12    u0   k64 ; k64 = "tostring"
.line	1473	move         r13    r5
.line	1473	call         r12     2     0
.line	1473	call          r8     0     2
.label	l506
.line	1473	call          r7     2     1
.label	l507
.line	1473	test          r4     0
.line	1473	jmp            0  l512
.line	1473	self          r5    r0  k145 ; k145 = "TriggerCanvasReady"
.line	1473	move          r7    r4
.line	1473	call          r5     3     1
.label	l512
.line	1473	return        r0     1
.line	1473	move          r0    r0
.line	1473	move          r0    r0
.line	1473	move          r0    r0
.line	1473	move          r0    r0
.line	1473	return        r0     1

.function	main/f70

.source	null
.linedefined	1521
.lastlinedefined	1523
.numparams	2
.is_vararg	0
.maxstacksize	23

.upvalue	"_ENV"	1	true

.constant	k0	"_DispatchCanvasReady"
.constant	k1	114
.constant	k2	88
.constant	k3	44
.constant	k4	39
.constant	k5	180
.constant	k6	166
.constant	k7	30
.constant	k8	49
.constant	k9	75
.constant	k10	10
.constant	k11	31
.constant	k12	228
.constant	k13	91
.constant	k14	18
.constant	k15	27

.line	1521	self          r2    r0    k0 ; k0 = "_DispatchCanvasReady"
.line	1521	move          r4    r1
.line	1521	getupval      r5    u0
.line	1521	loadk         r6    k1 ; k1 = 114
.line	1521	loadk         r7    k2 ; k2 = 88
.line	1521	loadk         r8    k3 ; k3 = 44
.line	1521	loadk         r9    k4 ; k4 = 39
.line	1521	loadk        r10    k5 ; k5 = 180
.line	1521	loadk        r11    k6 ; k6 = 166
.line	1521	loadk        r12    k7 ; k7 = 30
.line	1521	loadk        r13    k2 ; k2 = 88
.line	1521	loadk        r14    k8 ; k8 = 49
.line	1521	loadk        r15    k9 ; k9 = 75
.line	1521	loadk        r16   k10 ; k10 = 10
.line	1521	loadk        r17   k11 ; k11 = 31
.line	1521	loadk        r18   k12 ; k12 = 228
.line	1521	loadk        r19   k13 ; k13 = 91
.line	1521	loadk        r20   k14 ; k14 = 18
.line	1521	loadk        r21   k15 ; k15 = 27
.line	1521	loadk        r22    k5 ; k5 = 180
.line	1521	call          r5    18     2
.line	1521	call          r2     4     1
.line	1521	return        r0     1
.line	1521	move          r0    r0
.line	1521	move          r0    r0
.line	1521	return        r0     1

.function	main/f71

.source	null
.linedefined	1525
.lastlinedefined	1527
.numparams	2
.is_vararg	0
.maxstacksize	21

.upvalue	"_ENV"	1	true

.constant	k0	"_DispatchCanvasReady"
.constant	k1	114
.constant	k2	88
.constant	k3	44
.constant	k4	39
.constant	k5	180
.constant	k6	166
.constant	k7	21
.constant	k8	91
.constant	k9	47
.constant	k10	79
.constant	k11	59
.constant	k12	14
.constant	k13	215
.constant	k14	90
.constant	k15	10

.line	1525	self          r2    r0    k0 ; k0 = "_DispatchCanvasReady"
.line	1525	move          r4    r1
.line	1525	getupval      r5    u0
.line	1525	loadk         r6    k1 ; k1 = 114
.line	1525	loadk         r7    k2 ; k2 = 88
.line	1525	loadk         r8    k3 ; k3 = 44
.line	1525	loadk         r9    k4 ; k4 = 39
.line	1525	loadk        r10    k5 ; k5 = 180
.line	1525	loadk        r11    k6 ; k6 = 166
.line	1525	loadk        r12    k7 ; k7 = 21
.line	1525	loadk        r13    k8 ; k8 = 91
.line	1525	loadk        r14    k9 ; k9 = 47
.line	1525	loadk        r15   k10 ; k10 = 79
.line	1525	loadk        r16   k11 ; k11 = 59
.line	1525	loadk        r17   k12 ; k12 = 14
.line	1525	loadk        r18   k13 ; k13 = 215
.line	1525	loadk        r19   k14 ; k14 = 90
.line	1525	loadk        r20   k15 ; k15 = 10
.line	1525	call          r5    16     2
.line	1525	call          r2     4     1
.line	1525	return        r0     1
.line	1525	move          r0    r0
.line	1525	move          r0    r0
.line	1525	move          r0    r0
.line	1525	move          r0    r0
.line	1525	return        r0     1

.function	main/f72

.source	null
.linedefined	1529
.lastlinedefined	1566
.numparams	4
.is_vararg	0
.maxstacksize	42

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	94
.constant	k2	89
.constant	k3	15
.constant	k4	37
.constant	k5	191
.constant	k6	173
.constant	k7	127
.constant	k8	121
.constant	k9	46
.constant	k10	93
.constant	k11	29
.constant	k12	4
.constant	k13	219
.constant	k14	0
.constant	k15	12
.constant	k16	168
.constant	k17	114
.constant	k18	60
.constant	k19	59
.constant	k20	85
.constant	k21	128
.constant	k22	101
.constant	k23	38
.constant	k24	10
.constant	k25	8
.constant	k26	195
.constant	k27	90
.constant	k28	39
.constant	k29	187
.constant	k30	108
.constant	k31	13
.constant	k32	"DownloadType"
.constant	k33	"CustomAssetDownloadType"
.constant	k34	"DownloadAndLoad"
.constant	k35	"CustomAssetMgr"
.constant	k36	"DownloadCustomAsset"

.line	1529	gettabup      r4    u0    k0 ; k0 = "require"
.line	1529	getupval      r5    u1
.line	1529	loadk         r6    k1 ; k1 = 94
.line	1529	loadk         r7    k2 ; k2 = 89
.line	1529	loadk         r8    k3 ; k3 = 15
.line	1529	loadk         r9    k4 ; k4 = 37
.line	1529	loadk        r10    k5 ; k5 = 191
.line	1529	loadk        r11    k6 ; k6 = 173
.line	1529	loadk        r12    k7 ; k7 = 127
.line	1529	loadk        r13    k8 ; k8 = 121
.line	1529	loadk        r14    k9 ; k9 = 46
.line	1529	loadk        r15   k10 ; k10 = 93
.line	1529	loadk        r16   k11 ; k11 = 29
.line	1529	loadk        r17   k12 ; k12 = 4
.line	1529	loadk        r18   k13 ; k13 = 219
.line	1529	loadk        r19    k7 ; k7 = 127
.line	1529	loadk        r20   k14 ; k14 = 0
.line	1529	loadk        r21   k15 ; k15 = 12
.line	1529	loadk        r22   k16 ; k16 = 168
.line	1529	loadk        r23   k17 ; k17 = 114
.line	1529	loadk        r24   k18 ; k18 = 60
.line	1529	loadk        r25   k19 ; k19 = 59
.line	1529	loadk        r26   k20 ; k20 = 85
.line	1529	loadk        r27   k21 ; k21 = 128
.line	1529	loadk        r28   k20 ; k20 = 85
.line	1529	loadk        r29   k22 ; k22 = 101
.line	1529	loadk        r30   k23 ; k23 = 38
.line	1529	loadk        r31    k7 ; k7 = 127
.line	1529	loadk        r32   k24 ; k24 = 10
.line	1529	loadk        r33   k25 ; k25 = 8
.line	1529	loadk        r34   k26 ; k26 = 195
.line	1529	loadk        r35   k27 ; k27 = 90
.line	1529	loadk        r36   k28 ; k28 = 39
.line	1529	loadk        r37   k24 ; k24 = 10
.line	1529	loadk        r38   k29 ; k29 = 187
.line	1529	loadk        r39    k7 ; k7 = 127
.line	1529	loadk        r40   k30 ; k30 = 108
.line	1529	loadk        r41   k31 ; k31 = 13
.line	1529	call          r5    37     2
.line	1529	call          r4     2     2
.line	1529	newtable      r5     0     1
.line	1529	gettable      r6    r4   k33 ; k33 = "CustomAssetDownloadT" (truncated)
.line	1529	gettable      r6    r6   k34 ; k34 = "DownloadAndLoad"
.line	1529	settable      r5   k32    r6 ; k32 = "DownloadType"
.line	1529	gettabup      r6    u0   k35 ; k35 = "CustomAssetMgr"
.line	1529	self          r6    r6   k36 ; k36 = "DownloadCustomAsset"
.line	1529	move          r8    r1
.line	1529	loadbool      r9     0     0
.line	1529	move         r10    r5
.line	1529	closure      r11    f0
.line	1529	call          r6     6     1
.line	1529	return        r0     1
.line	1529	move          r0    r0
.line	1529	move          r0    r0
.line	1529	move          r0    r0
.line	1529	move          r0    r0
.line	1529	return        r0     1

.function	main/f72/f0

.source	null
.linedefined	1534
.lastlinedefined	1565
.numparams	1
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	false
.upvalue	"U3"	1	true
.upvalue	"U4"	2	true
.upvalue	"U5"	3	true

.constant	k0	"_CancelledAsyncSeqs"
.constant	k1	nil
.constant	k2	"print"
.constant	k3	"bWriteLog"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	126
.constant	k7	68
.constant	k8	7
.constant	k9	41
.constant	k10	164
.constant	k11	170
.constant	k12	39
.constant	k13	95
.constant	k14	24
.constant	k15	91
.constant	k16	26
.constant	k17	31
.constant	k18	217
.constant	k19	83
.constant	k20	38
.constant	k21	54
.constant	k22	137
.constant	k23	103
.constant	k24	102
.constant	k25	25
.constant	k26	99
.constant	k27	156
.constant	k28	76
.constant	k29	122
.constant	k30	113
.constant	k31	97
.constant	k32	61
.constant	k33	20
.constant	k34	209
.constant	k35	64
.constant	k36	15
.constant	k37	0
.constant	k38	188
.constant	k39	114
.constant	k40	67
.constant	k41	6
.constant	k42	84
.constant	k43	182
.constant	k44	106
.constant	k45	92
.constant	k46	85
.constant	k47	9
.constant	k48	1
.constant	k49	190
.constant	k50	176
.constant	k51	37
.constant	k52	53
.constant	k53	77
.constant	k54	12
.constant	k55	63
.constant	k56	196
.constant	k57	22
.constant	k58	174
.constant	k59	105
.constant	k60	127
.constant	k61	8
.constant	k62	13
.constant	k63	144
.constant	k64	111
.constant	k65	42
.constant	k66	28
.constant	k67	"tostring"
.constant	k68	124
.constant	k69	69
.constant	k70	27
.constant	k71	179
.constant	k72	52
.constant	k73	75
.constant	k74	159
.constant	k75	47
.constant	k76	"GetOwner"
.constant	k77	"slua"
.constant	k78	"isValid"
.constant	k79	162
.constant	k80	29
.constant	k81	82
.constant	k82	222
.constant	k83	72
.constant	k84	100
.constant	k85	21
.constant	k86	18
.constant	k87	194
.constant	k88	169
.constant	k89	101
.constant	k90	110
.constant	k91	88
.constant	k92	202
.constant	k93	"require"
.constant	k94	87
.constant	k95	45
.constant	k96	48
.constant	k97	65
.constant	k98	245
.constant	k99	30
.constant	k100	185
.constant	k101	98
.constant	k102	146
.constant	k103	16
.constant	k104	199
.constant	k105	43
.constant	k106	70
.constant	k107	138
.constant	k108	123
.constant	k109	79
.constant	k110	35
.constant	k111	59
.constant	k112	163
.constant	k113	166
.constant	k114	5
.constant	k115	"UnPackBinaryAsset"
.constant	k116	"type"
.constant	k117	73
.constant	k118	36
.constant	k119	181
.constant	k120	"InstanceTree"
.constant	k121	"next"
.constant	k122	184
.constant	k123	104
.constant	k124	152
.constant	k125	108
.constant	k126	132
.constant	k127	157
.constant	k128	66
.constant	k129	134
.constant	k130	14

.line	1534	gettabup      r1    u0    k0 ; k0 = "_CancelledAsyncSeqs"
.line	1534	eq             0    r1    k1 ; k1 = nil
.line	1534	jmp            0  l107
.line	1534	gettabup      r1    u1    k2 ; k2 = "print"
.line	1534	gettabup      r2    u1    k3 ; k3 = "bWriteLog"
.line	1534	test          r2     0
.line	1534	jmp            0   l85
.line	1534	gettabup      r2    u1    k4 ; k4 = "table"
.line	1534	gettable      r2    r2    k5 ; k5 = "concat"
.line	1534	newtable      r3     1     0
.line	1534	getupval      r4    u2
.line	1534	loadk         r5    k6 ; k6 = 126
.line	1534	loadk         r6    k7 ; k7 = 68
.line	1534	loadk         r7    k8 ; k8 = 7
.line	1534	loadk         r8    k9 ; k9 = 41
.line	1534	loadk         r9   k10 ; k10 = 164
.line	1534	loadk        r10   k11 ; k11 = 170
.line	1534	loadk        r11   k12 ; k12 = 39
.line	1534	loadk        r12   k13 ; k13 = 95
.line	1534	loadk        r13   k14 ; k14 = 24
.line	1534	loadk        r14   k15 ; k15 = 91
.line	1534	loadk        r15   k16 ; k16 = 26
.line	1534	loadk        r16   k17 ; k17 = 31
.line	1534	loadk        r17   k18 ; k18 = 217
.line	1534	loadk        r18   k19 ; k19 = 83
.line	1534	loadk        r19   k20 ; k20 = 38
.line	1534	loadk        r20   k21 ; k21 = 54
.line	1534	loadk        r21   k22 ; k22 = 137
.line	1534	loadk        r22   k23 ; k23 = 103
.line	1534	loadk        r23   k24 ; k24 = 102
.line	1534	loadk        r24   k25 ; k25 = 25
.line	1534	loadk        r25   k26 ; k26 = 99
.line	1534	loadk        r26   k27 ; k27 = 156
.line	1534	loadk        r27   k28 ; k28 = 76
.line	1534	loadk        r28   k29 ; k29 = 122
.line	1534	loadk        r29   k30 ; k30 = 113
.line	1534	loadk        r30   k31 ; k31 = 97
.line	1534	loadk        r31   k32 ; k32 = 61
.line	1534	loadk        r32   k33 ; k33 = 20
.line	1534	loadk        r33   k34 ; k34 = 209
.line	1534	loadk        r34   k35 ; k35 = 64
.line	1534	loadk        r35   k36 ; k36 = 15
.line	1534	loadk        r36   k37 ; k37 = 0
.line	1534	loadk        r37   k38 ; k38 = 188
.line	1534	loadk        r38   k39 ; k39 = 114
.line	1534	loadk        r39   k40 ; k40 = 67
.line	1534	loadk        r40   k41 ; k41 = 6
.line	1534	loadk        r41   k42 ; k42 = 84
.line	1534	loadk        r42   k43 ; k43 = 182
.line	1534	loadk        r43   k13 ; k13 = 95
.line	1534	loadk        r44   k44 ; k44 = 106
.line	1534	call          r4    41     2
.line	1534	getupval      r5    u2
.line	1534	loadk         r6   k45 ; k45 = 92
.line	1534	loadk         r7   k46 ; k46 = 85
.line	1534	loadk         r8   k47 ; k47 = 9
.line	1534	loadk         r9   k48 ; k48 = 1
.line	1534	loadk        r10   k49 ; k49 = 190
.line	1534	loadk        r11   k50 ; k50 = 176
.line	1534	loadk        r12   k51 ; k51 = 37
.line	1534	loadk        r13   k15 ; k15 = 91
.line	1534	loadk        r14   k52 ; k52 = 53
.line	1534	loadk        r15   k53 ; k53 = 77
.line	1534	loadk        r16   k54 ; k54 = 12
.line	1534	loadk        r17   k55 ; k55 = 63
.line	1534	loadk        r18   k56 ; k56 = 196
.line	1534	loadk        r19   k15 ; k15 = 91
.line	1534	loadk        r20   k57 ; k57 = 22
.line	1534	loadk        r21   k13 ; k13 = 95
.line	1534	loadk        r22   k58 ; k58 = 174
.line	1534	loadk        r23   k59 ; k59 = 105
.line	1534	loadk        r24   k60 ; k60 = 127
.line	1534	loadk        r25   k61 ; k61 = 8
.line	1534	loadk        r26   k62 ; k62 = 13
.line	1534	loadk        r27   k63 ; k63 = 144
.line	1534	loadk        r28   k53 ; k53 = 77
.line	1534	loadk        r29   k64 ; k64 = 111
.line	1534	loadk        r30   k65 ; k65 = 42
.line	1534	loadk        r31   k28 ; k28 = 76
.line	1534	loadk        r32   k66 ; k66 = 28
.line	1534	loadk        r33   k17 ; k17 = 31
.line	1534	call          r5    29     0
.line	1534	setlist       r3     0     1
.line	1534	call          r2     2     2
.label	l85
.line	1534	gettabup      r3    u1   k67 ; k67 = "tostring"
.line	1534	getupval      r4    u3
.line	1534	call          r3     2     2
.line	1534	getupval      r4    u2
.line	1534	loadk         r5   k68 ; k68 = 124
.line	1534	loadk         r6   k69 ; k69 = 69
.line	1534	loadk         r7   k70 ; k70 = 27
.line	1534	loadk         r8   k20 ; k20 = 38
.line	1534	loadk         r9   k71 ; k71 = 179
.line	1534	loadk        r10   k63 ; k63 = 144
.line	1534	loadk        r11   k72 ; k72 = 52
.line	1534	loadk        r12   k73 ; k73 = 75
.line	1534	loadk        r13   k31 ; k31 = 97
.line	1534	call          r4    10     2
.line	1534	gettabup      r5    u1   k67 ; k67 = "tostring"
.line	1534	getupval      r6    u4
.line	1534	call          r5     2     0
.line	1534	call          r1     0     1
.line	1534	getupval      r1    u5
.line	1534	loadnil       r2     0
.line	1534	call          r1     2     1
.line	1534	return        r0     1
.label	l107
.line	1534	gettabup      r1    u0    k0 ; k0 = "_CancelledAsyncSeqs"
.line	1534	getupval      r2    u4
.line	1534	gettable      r1    r1    r2
.line	1534	test          r1     0
.line	1534	jmp            0  l212
.line	1534	gettabup      r1    u1    k2 ; k2 = "print"
.line	1534	gettabup      r2    u1    k3 ; k3 = "bWriteLog"
.line	1534	test          r2     0
.line	1534	jmp            0  l190
.line	1534	gettabup      r2    u1    k4 ; k4 = "table"
.line	1534	gettable      r2    r2    k5 ; k5 = "concat"
.line	1534	newtable      r3     1     0
.line	1534	getupval      r4    u2
.line	1534	loadk         r5    k6 ; k6 = 126
.line	1534	loadk         r6    k7 ; k7 = 68
.line	1534	loadk         r7    k8 ; k8 = 7
.line	1534	loadk         r8    k9 ; k9 = 41
.line	1534	loadk         r9   k10 ; k10 = 164
.line	1534	loadk        r10   k11 ; k11 = 170
.line	1534	loadk        r11   k12 ; k12 = 39
.line	1534	loadk        r12   k13 ; k13 = 95
.line	1534	loadk        r13   k14 ; k14 = 24
.line	1534	loadk        r14   k15 ; k15 = 91
.line	1534	loadk        r15   k16 ; k16 = 26
.line	1534	loadk        r16   k17 ; k17 = 31
.line	1534	loadk        r17   k18 ; k18 = 217
.line	1534	loadk        r18   k19 ; k19 = 83
.line	1534	loadk        r19   k20 ; k20 = 38
.line	1534	loadk        r20   k21 ; k21 = 54
.line	1534	loadk        r21   k22 ; k22 = 137
.line	1534	loadk        r22   k23 ; k23 = 103
.line	1534	loadk        r23   k24 ; k24 = 102
.line	1534	loadk        r24   k25 ; k25 = 25
.line	1534	loadk        r25   k26 ; k26 = 99
.line	1534	loadk        r26   k27 ; k27 = 156
.line	1534	loadk        r27   k28 ; k28 = 76
.line	1534	loadk        r28   k29 ; k29 = 122
.line	1534	loadk        r29   k30 ; k30 = 113
.line	1534	loadk        r30   k31 ; k31 = 97
.line	1534	loadk        r31   k32 ; k32 = 61
.line	1534	loadk        r32   k33 ; k33 = 20
.line	1534	loadk        r33   k34 ; k34 = 209
.line	1534	loadk        r34   k35 ; k35 = 64
.line	1534	loadk        r35   k36 ; k36 = 15
.line	1534	loadk        r36   k37 ; k37 = 0
.line	1534	loadk        r37   k38 ; k38 = 188
.line	1534	loadk        r38   k39 ; k39 = 114
.line	1534	loadk        r39   k40 ; k40 = 67
.line	1534	loadk        r40   k41 ; k41 = 6
.line	1534	loadk        r41   k42 ; k42 = 84
.line	1534	loadk        r42   k43 ; k43 = 182
.line	1534	loadk        r43   k13 ; k13 = 95
.line	1534	loadk        r44   k44 ; k44 = 106
.line	1534	call          r4    41     2
.line	1534	getupval      r5    u2
.line	1534	loadk         r6   k45 ; k45 = 92
.line	1534	loadk         r7   k46 ; k46 = 85
.line	1534	loadk         r8   k47 ; k47 = 9
.line	1534	loadk         r9   k48 ; k48 = 1
.line	1534	loadk        r10   k49 ; k49 = 190
.line	1534	loadk        r11   k50 ; k50 = 176
.line	1534	loadk        r12   k51 ; k51 = 37
.line	1534	loadk        r13   k15 ; k15 = 91
.line	1534	loadk        r14   k52 ; k52 = 53
.line	1534	loadk        r15   k53 ; k53 = 77
.line	1534	loadk        r16   k54 ; k54 = 12
.line	1534	loadk        r17   k55 ; k55 = 63
.line	1534	loadk        r18   k56 ; k56 = 196
.line	1534	loadk        r19   k15 ; k15 = 91
.line	1534	loadk        r20   k57 ; k57 = 22
.line	1534	loadk        r21   k13 ; k13 = 95
.line	1534	loadk        r22   k58 ; k58 = 174
.line	1534	loadk        r23   k23 ; k23 = 103
.line	1534	loadk        r24   k68 ; k68 = 124
.line	1534	loadk        r25   k70 ; k70 = 27
.line	1534	loadk        r26   k69 ; k69 = 69
.line	1534	loadk        r27   k74 ; k74 = 159
.line	1534	loadk        r28   k53 ; k53 = 77
.line	1534	loadk        r29   k64 ; k64 = 111
.line	1534	loadk        r30   k75 ; k75 = 47
.line	1534	call          r5    26     0
.line	1534	setlist       r3     0     1
.line	1534	call          r2     2     2
.label	l190
.line	1534	gettabup      r3    u1   k67 ; k67 = "tostring"
.line	1534	getupval      r4    u3
.line	1534	call          r3     2     2
.line	1534	getupval      r4    u2
.line	1534	loadk         r5   k68 ; k68 = 124
.line	1534	loadk         r6   k69 ; k69 = 69
.line	1534	loadk         r7   k70 ; k70 = 27
.line	1534	loadk         r8   k20 ; k20 = 38
.line	1534	loadk         r9   k71 ; k71 = 179
.line	1534	loadk        r10   k63 ; k63 = 144
.line	1534	loadk        r11   k72 ; k72 = 52
.line	1534	loadk        r12   k73 ; k73 = 75
.line	1534	loadk        r13   k31 ; k31 = 97
.line	1534	call          r4    10     2
.line	1534	gettabup      r5    u1   k67 ; k67 = "tostring"
.line	1534	getupval      r6    u4
.line	1534	call          r5     2     0
.line	1534	call          r1     0     1
.line	1534	gettabup      r1    u0    k0 ; k0 = "_CancelledAsyncSeqs"
.line	1534	getupval      r2    u4
.line	1534	settable      r1    r2    k1 ; k1 = nil
.line	1534	return        r0     1
.label	l212
.line	1534	getupval      r1    u0
.line	1534	self          r1    r1   k76 ; k76 = "GetOwner"
.line	1534	call          r1     2     2
.line	1534	gettabup      r2    u1   k77 ; k77 = "slua"
.line	1534	gettable      r2    r2   k78 ; k78 = "isValid"
.line	1534	move          r3    r1
.line	1534	call          r2     2     2
.line	1534	test          r2     1
.line	1534	jmp            0  l311
.line	1534	gettabup      r2    u1    k2 ; k2 = "print"
.line	1534	gettabup      r3    u1    k3 ; k3 = "bWriteLog"
.line	1534	test          r3     0
.line	1534	jmp            0  l303
.line	1534	gettabup      r3    u1    k4 ; k4 = "table"
.line	1534	gettable      r3    r3    k5 ; k5 = "concat"
.line	1534	newtable      r4     1     0
.line	1534	getupval      r5    u2
.line	1534	loadk         r6    k6 ; k6 = 126
.line	1534	loadk         r7    k7 ; k7 = 68
.line	1534	loadk         r8    k8 ; k8 = 7
.line	1534	loadk         r9    k9 ; k9 = 41
.line	1534	loadk        r10   k10 ; k10 = 164
.line	1534	loadk        r11   k11 ; k11 = 170
.line	1534	loadk        r12   k12 ; k12 = 39
.line	1534	loadk        r13   k13 ; k13 = 95
.line	1534	loadk        r14   k14 ; k14 = 24
.line	1534	loadk        r15   k15 ; k15 = 91
.line	1534	loadk        r16   k16 ; k16 = 26
.line	1534	loadk        r17   k17 ; k17 = 31
.line	1534	loadk        r18   k18 ; k18 = 217
.line	1534	loadk        r19   k19 ; k19 = 83
.line	1534	loadk        r20   k20 ; k20 = 38
.line	1534	loadk        r21   k21 ; k21 = 54
.line	1534	loadk        r22   k22 ; k22 = 137
.line	1534	loadk        r23   k23 ; k23 = 103
.line	1534	loadk        r24   k24 ; k24 = 102
.line	1534	loadk        r25   k25 ; k25 = 25
.line	1534	loadk        r26   k26 ; k26 = 99
.line	1534	loadk        r27   k27 ; k27 = 156
.line	1534	loadk        r28   k28 ; k28 = 76
.line	1534	loadk        r29   k29 ; k29 = 122
.line	1534	loadk        r30   k30 ; k30 = 113
.line	1534	loadk        r31   k31 ; k31 = 97
.line	1534	loadk        r32   k32 ; k32 = 61
.line	1534	loadk        r33   k33 ; k33 = 20
.line	1534	loadk        r34   k34 ; k34 = 209
.line	1534	loadk        r35   k35 ; k35 = 64
.line	1534	loadk        r36   k36 ; k36 = 15
.line	1534	loadk        r37   k37 ; k37 = 0
.line	1534	loadk        r38   k38 ; k38 = 188
.line	1534	loadk        r39   k39 ; k39 = 114
.line	1534	loadk        r40   k40 ; k40 = 67
.line	1534	loadk        r41   k41 ; k41 = 6
.line	1534	loadk        r42   k42 ; k42 = 84
.line	1534	loadk        r43   k43 ; k43 = 182
.line	1534	loadk        r44   k13 ; k13 = 95
.line	1534	loadk        r45   k44 ; k44 = 106
.line	1534	call          r5    41     2
.line	1534	getupval      r6    u2
.line	1534	loadk         r7   k45 ; k45 = 92
.line	1534	loadk         r8   k46 ; k46 = 85
.line	1534	loadk         r9   k47 ; k47 = 9
.line	1534	loadk        r10   k48 ; k48 = 1
.line	1534	loadk        r11   k49 ; k49 = 190
.line	1534	loadk        r12   k50 ; k50 = 176
.line	1534	loadk        r13   k51 ; k51 = 37
.line	1534	loadk        r14   k15 ; k15 = 91
.line	1534	loadk        r15   k52 ; k52 = 53
.line	1534	loadk        r16   k53 ; k53 = 77
.line	1534	loadk        r17   k54 ; k54 = 12
.line	1534	loadk        r18   k55 ; k55 = 63
.line	1534	loadk        r19   k56 ; k56 = 196
.line	1534	loadk        r20   k15 ; k15 = 91
.line	1534	loadk        r21   k57 ; k57 = 22
.line	1534	loadk        r22   k13 ; k13 = 95
.line	1534	loadk        r23   k79 ; k79 = 162
.line	1534	loadk        r24   k30 ; k30 = 113
.line	1534	loadk        r25   k68 ; k68 = 124
.line	1534	loadk        r26   k80 ; k80 = 29
.line	1534	loadk        r27   k81 ; k81 = 82
.line	1534	loadk        r28   k82 ; k82 = 222
.line	1534	loadk        r29   k83 ; k83 = 72
.line	1534	loadk        r30   k84 ; k84 = 100
.line	1534	loadk        r31   k32 ; k32 = 61
.line	1534	loadk        r32   k13 ; k13 = 95
.line	1534	loadk        r33   k85 ; k85 = 21
.line	1534	loadk        r34   k86 ; k86 = 18
.line	1534	loadk        r35   k87 ; k87 = 194
.line	1534	call          r6    30     0
.line	1534	setlist       r4     0     1
.line	1534	call          r3     2     2
.label	l303
.line	1534	gettabup      r4    u1   k67 ; k67 = "tostring"
.line	1534	getupval      r5    u3
.line	1534	call          r4     2     0
.line	1534	call          r2     0     1
.line	1534	getupval      r2    u5
.line	1534	loadnil       r3     0
.line	1534	call          r2     2     1
.line	1534	return        r0     1
.label	l311
.line	1534	eq             0    r0    k1 ; k1 = nil
.line	1534	jmp            0  l405
.line	1534	gettabup      r2    u1    k2 ; k2 = "print"
.line	1534	gettabup      r3    u1    k3 ; k3 = "bWriteLog"
.line	1534	test          r3     0
.line	1534	jmp            0  l397
.line	1534	gettabup      r3    u1    k4 ; k4 = "table"
.line	1534	gettable      r3    r3    k5 ; k5 = "concat"
.line	1534	newtable      r4     1     0
.line	1534	getupval      r5    u2
.line	1534	loadk         r6    k6 ; k6 = 126
.line	1534	loadk         r7    k7 ; k7 = 68
.line	1534	loadk         r8    k8 ; k8 = 7
.line	1534	loadk         r9    k9 ; k9 = 41
.line	1534	loadk        r10   k10 ; k10 = 164
.line	1534	loadk        r11   k11 ; k11 = 170
.line	1534	loadk        r12   k12 ; k12 = 39
.line	1534	loadk        r13   k13 ; k13 = 95
.line	1534	loadk        r14   k14 ; k14 = 24
.line	1534	loadk        r15   k15 ; k15 = 91
.line	1534	loadk        r16   k16 ; k16 = 26
.line	1534	loadk        r17   k17 ; k17 = 31
.line	1534	loadk        r18   k18 ; k18 = 217
.line	1534	loadk        r19   k19 ; k19 = 83
.line	1534	loadk        r20   k20 ; k20 = 38
.line	1534	loadk        r21   k21 ; k21 = 54
.line	1534	loadk        r22   k22 ; k22 = 137
.line	1534	loadk        r23   k23 ; k23 = 103
.line	1534	loadk        r24   k24 ; k24 = 102
.line	1534	loadk        r25   k25 ; k25 = 25
.line	1534	loadk        r26   k26 ; k26 = 99
.line	1534	loadk        r27   k27 ; k27 = 156
.line	1534	loadk        r28   k28 ; k28 = 76
.line	1534	loadk        r29   k29 ; k29 = 122
.line	1534	loadk        r30   k30 ; k30 = 113
.line	1534	loadk        r31   k31 ; k31 = 97
.line	1534	loadk        r32   k32 ; k32 = 61
.line	1534	loadk        r33   k33 ; k33 = 20
.line	1534	loadk        r34   k34 ; k34 = 209
.line	1534	loadk        r35   k35 ; k35 = 64
.line	1534	loadk        r36   k36 ; k36 = 15
.line	1534	loadk        r37   k37 ; k37 = 0
.line	1534	loadk        r38   k38 ; k38 = 188
.line	1534	loadk        r39   k39 ; k39 = 114
.line	1534	loadk        r40   k40 ; k40 = 67
.line	1534	loadk        r41   k41 ; k41 = 6
.line	1534	loadk        r42   k42 ; k42 = 84
.line	1534	loadk        r43   k43 ; k43 = 182
.line	1534	loadk        r44   k13 ; k13 = 95
.line	1534	loadk        r45   k44 ; k44 = 106
.line	1534	call          r5    41     2
.line	1534	getupval      r6    u2
.line	1534	loadk         r7   k45 ; k45 = 92
.line	1534	loadk         r8   k46 ; k46 = 85
.line	1534	loadk         r9   k47 ; k47 = 9
.line	1534	loadk        r10   k48 ; k48 = 1
.line	1534	loadk        r11   k49 ; k49 = 190
.line	1534	loadk        r12   k50 ; k50 = 176
.line	1534	loadk        r13   k51 ; k51 = 37
.line	1534	loadk        r14   k15 ; k15 = 91
.line	1534	loadk        r15   k52 ; k52 = 53
.line	1534	loadk        r16   k53 ; k53 = 77
.line	1534	loadk        r17   k54 ; k54 = 12
.line	1534	loadk        r18   k55 ; k55 = 63
.line	1534	loadk        r19   k56 ; k56 = 196
.line	1534	loadk        r20   k15 ; k15 = 91
.line	1534	loadk        r21   k57 ; k57 = 22
.line	1534	loadk        r22   k13 ; k13 = 95
.line	1534	loadk        r23   k88 ; k88 = 169
.line	1534	loadk        r24   k59 ; k59 = 105
.line	1534	loadk        r25   k89 ; k89 = 101
.line	1534	loadk        r26   k57 ; k57 = 22
.line	1534	loadk        r27   k28 ; k28 = 76
.line	1534	loadk        r28   k27 ; k27 = 156
.line	1534	loadk        r29   k35 ; k35 = 64
.line	1534	loadk        r30   k90 ; k90 = 110
.line	1534	loadk        r31   k24 ; k24 = 102
.line	1534	loadk        r32   k91 ; k91 = 88
.line	1534	loadk        r33   k14 ; k14 = 24
.line	1534	loadk        r34   k86 ; k86 = 18
.line	1534	loadk        r35   k92 ; k92 = 202
.line	1534	loadk        r36   k73 ; k73 = 75
.line	1534	loadk        r37    k8 ; k8 = 7
.line	1534	call          r6    32     0
.line	1534	setlist       r4     0     1
.line	1534	call          r3     2     2
.label	l397
.line	1534	gettabup      r4    u1   k67 ; k67 = "tostring"
.line	1534	getupval      r5    u3
.line	1534	call          r4     2     0
.line	1534	call          r2     0     1
.line	1534	getupval      r2    u5
.line	1534	loadnil       r3     0
.line	1534	call          r2     2     1
.line	1534	return        r0     1
.label	l405
.line	1534	gettabup      r2    u1   k93 ; k93 = "require"
.line	1534	gettabup      r3    u1    k4 ; k4 = "table"
.line	1534	gettable      r3    r3    k5 ; k5 = "concat"
.line	1534	newtable      r4     1     0
.line	1534	getupval      r5    u2
.line	1534	loadk         r6   k29 ; k29 = 122
.line	1534	loadk         r7   k94 ; k94 = 87
.line	1534	loadk         r8   k36 ; k36 = 15
.line	1534	loadk         r9   k95 ; k95 = 45
.line	1534	loadk        r10   k27 ; k27 = 156
.line	1534	loadk        r11   k43 ; k43 = 182
.line	1534	loadk        r12   k96 ; k96 = 48
.line	1534	loadk        r13   k33 ; k33 = 20
.line	1534	loadk        r14   k57 ; k57 = 22
.line	1534	loadk        r15   k97 ; k97 = 65
.line	1534	loadk        r16   k62 ; k62 = 13
.line	1534	loadk        r17   k69 ; k69 = 69
.line	1534	loadk        r18   k98 ; k98 = 245
.line	1534	loadk        r19   k28 ; k28 = 76
.line	1534	loadk        r20   k57 ; k57 = 22
.line	1534	loadk        r21   k99 ; k99 = 30
.line	1534	loadk        r22  k100 ; k100 = 185
.line	1534	loadk        r23   k64 ; k64 = 111
.line	1534	loadk        r24   k84 ; k84 = 100
.line	1534	loadk        r25   k80 ; k80 = 29
.line	1534	loadk        r26  k101 ; k101 = 98
.line	1534	loadk        r27  k102 ; k102 = 146
.line	1534	loadk        r28   k81 ; k81 = 82
.line	1534	loadk        r29   k64 ; k64 = 111
.line	1534	loadk        r30   k89 ; k89 = 101
.line	1534	loadk        r31   k68 ; k68 = 124
.line	1534	loadk        r32  k103 ; k103 = 16
.line	1534	loadk        r33   k85 ; k85 = 21
.line	1534	loadk        r34  k104 ; k104 = 199
.line	1534	loadk        r35   k45 ; k45 = 92
.line	1534	loadk        r36   k16 ; k16 = 26
.line	1534	loadk        r37  k105 ; k105 = 43
.line	1534	loadk        r38   k38 ; k38 = 188
.line	1534	loadk        r39  k101 ; k101 = 98
.line	1534	loadk        r40   k26 ; k26 = 99
.line	1534	loadk        r41  k106 ; k106 = 70
.line	1534	loadk        r42   k39 ; k39 = 114
.line	1534	loadk        r43  k107 ; k107 = 138
.line	1534	loadk        r44   k13 ; k13 = 95
.line	1534	loadk        r45  k108 ; k108 = 123
.line	1534	call          r5    41     2
.line	1534	getupval      r6    u2
.line	1534	loadk         r7  k109 ; k109 = 79
.line	1534	loadk         r8  k109 ; k109 = 79
.line	1534	loadk         r9  k110 ; k110 = 35
.line	1534	loadk        r10  k111 ; k111 = 59
.line	1534	loadk        r11  k112 ; k112 = 163
.line	1534	loadk        r12  k113 ; k113 = 166
.line	1534	loadk        r13   k51 ; k51 = 37
.line	1534	loadk        r14   k90 ; k90 = 110
.line	1534	loadk        r15   k72 ; k72 = 52
.line	1534	loadk        r16   k97 ; k97 = 65
.line	1534	loadk        r17  k114 ; k114 = 5
.line	1534	call          r6    12     0
.line	1534	setlist       r4     0     1
.line	1534	call          r3     2     2
.line	1534	call          r2     2     2
.line	1534	gettable      r3    r2  k115 ; k115 = "UnPackBinaryAsset"
.line	1534	move          r4    r0
.line	1534	call          r3     2     4
.line	1534	gettabup      r6    u1  k116 ; k116 = "type"
.line	1534	move          r7    r3
.line	1534	call          r6     2     2
.line	1534	getupval      r7    u2
.line	1534	loadk         r8  k117 ; k117 = 73
.line	1534	loadk         r9   k94 ; k94 = 87
.line	1534	loadk        r10   k37 ; k37 = 0
.line	1534	loadk        r11  k118 ; k118 = 36
.line	1534	loadk        r12  k119 ; k119 = 181
.line	1534	call          r7     6     2
.line	1534	eq             0    r6    r7
.line	1534	jmp            0  l499
.line	1534	gettabup      r6    u1  k116 ; k116 = "type"
.line	1534	gettable      r7    r3  k120 ; k120 = "InstanceTree"
.line	1534	call          r6     2     2
.line	1534	getupval      r7    u2
.line	1534	loadk         r8  k117 ; k117 = 73
.line	1534	loadk         r9   k94 ; k94 = 87
.line	1534	loadk        r10   k37 ; k37 = 0
.line	1534	loadk        r11  k118 ; k118 = 36
.line	1534	loadk        r12  k119 ; k119 = 181
.line	1534	call          r7     6     2
.line	1534	eq             0    r6    r7
.line	1534	jmp            0  l499
.line	1534	gettabup      r6    u1  k121 ; k121 = "next"
.line	1534	gettable      r7    r3  k120 ; k120 = "InstanceTree"
.line	1534	call          r6     2     2
.line	1534	eq             0    r6    k1 ; k1 = nil
.line	1534	jmp            0  l589
.label	l499
.line	1534	gettabup      r6    u1    k2 ; k2 = "print"
.line	1534	gettabup      r7    u1    k3 ; k3 = "bWriteLog"
.line	1534	test          r7     0
.line	1534	jmp            0  l581
.line	1534	gettabup      r7    u1    k4 ; k4 = "table"
.line	1534	gettable      r7    r7    k5 ; k5 = "concat"
.line	1534	newtable      r8     1     0
.line	1534	getupval      r9    u2
.line	1534	loadk        r10    k6 ; k6 = 126
.line	1534	loadk        r11    k7 ; k7 = 68
.line	1534	loadk        r12    k8 ; k8 = 7
.line	1534	loadk        r13    k9 ; k9 = 41
.line	1534	loadk        r14   k10 ; k10 = 164
.line	1534	loadk        r15   k11 ; k11 = 170
.line	1534	loadk        r16   k12 ; k12 = 39
.line	1534	loadk        r17   k13 ; k13 = 95
.line	1534	loadk        r18   k14 ; k14 = 24
.line	1534	loadk        r19   k15 ; k15 = 91
.line	1534	loadk        r20   k16 ; k16 = 26
.line	1534	loadk        r21   k17 ; k17 = 31
.line	1534	loadk        r22   k18 ; k18 = 217
.line	1534	loadk        r23   k19 ; k19 = 83
.line	1534	loadk        r24   k20 ; k20 = 38
.line	1534	loadk        r25   k21 ; k21 = 54
.line	1534	loadk        r26   k22 ; k22 = 137
.line	1534	loadk        r27   k23 ; k23 = 103
.line	1534	loadk        r28   k24 ; k24 = 102
.line	1534	loadk        r29   k25 ; k25 = 25
.line	1534	loadk        r30   k26 ; k26 = 99
.line	1534	loadk        r31   k27 ; k27 = 156
.line	1534	loadk        r32   k28 ; k28 = 76
.line	1534	loadk        r33   k29 ; k29 = 122
.line	1534	loadk        r34   k30 ; k30 = 113
.line	1534	loadk        r35   k31 ; k31 = 97
.line	1534	loadk        r36   k32 ; k32 = 61
.line	1534	loadk        r37   k33 ; k33 = 20
.line	1534	loadk        r38   k34 ; k34 = 209
.line	1534	loadk        r39   k35 ; k35 = 64
.line	1534	loadk        r40   k36 ; k36 = 15
.line	1534	loadk        r41   k37 ; k37 = 0
.line	1534	loadk        r42   k38 ; k38 = 188
.line	1534	loadk        r43   k39 ; k39 = 114
.line	1534	loadk        r44   k40 ; k40 = 67
.line	1534	loadk        r45   k41 ; k41 = 6
.line	1534	loadk        r46   k42 ; k42 = 84
.line	1534	loadk        r47   k43 ; k43 = 182
.line	1534	loadk        r48   k13 ; k13 = 95
.line	1534	loadk        r49   k44 ; k44 = 106
.line	1534	call          r9    41     2
.line	1534	getupval     r10    u2
.line	1534	loadk        r11   k45 ; k45 = 92
.line	1534	loadk        r12   k46 ; k46 = 85
.line	1534	loadk        r13   k47 ; k47 = 9
.line	1534	loadk        r14   k48 ; k48 = 1
.line	1534	loadk        r15   k49 ; k49 = 190
.line	1534	loadk        r16   k50 ; k50 = 176
.line	1534	loadk        r17   k51 ; k51 = 37
.line	1534	loadk        r18   k15 ; k15 = 91
.line	1534	loadk        r19   k52 ; k52 = 53
.line	1534	loadk        r20   k53 ; k53 = 77
.line	1534	loadk        r21   k54 ; k54 = 12
.line	1534	loadk        r22   k55 ; k55 = 63
.line	1534	loadk        r23   k56 ; k56 = 196
.line	1534	loadk        r24   k15 ; k15 = 91
.line	1534	loadk        r25   k57 ; k57 = 22
.line	1534	loadk        r26   k13 ; k13 = 95
.line	1534	loadk        r27  k122 ; k122 = 184
.line	1534	loadk        r28  k123 ; k123 = 104
.line	1534	loadk        r29  k101 ; k101 = 98
.line	1534	loadk        r30   k25 ; k25 = 25
.line	1534	loadk        r31   k40 ; k40 = 67
.line	1534	loadk        r32  k124 ; k124 = 152
.line	1534	loadk        r33   k54 ; k54 = 12
.line	1534	loadk        r34  k125 ; k125 = 108
.line	1534	loadk        r35   k65 ; k65 = 42
.line	1534	loadk        r36   k94 ; k94 = 87
.line	1534	loadk        r37   k85 ; k85 = 21
.line	1534	loadk        r38   k99 ; k99 = 30
.line	1534	loadk        r39   k87 ; k87 = 194
.line	1534	call         r10    30     0
.line	1534	setlist       r8     0     1
.line	1534	call          r7     2     2
.label	l581
.line	1534	gettabup      r8    u1   k67 ; k67 = "tostring"
.line	1534	getupval      r9    u3
.line	1534	call          r8     2     0
.line	1534	call          r6     0     1
.line	1534	getupval      r6    u5
.line	1534	loadnil       r7     0
.line	1534	call          r6     2     1
.line	1534	return        r0     1
.label	l589
.line	1534	gettabup      r6    u1    k2 ; k2 = "print"
.line	1534	gettabup      r7    u1    k3 ; k3 = "bWriteLog"
.line	1534	test          r7     0
.line	1534	jmp            0  l676
.line	1534	gettabup      r7    u1    k4 ; k4 = "table"
.line	1534	gettable      r7    r7    k5 ; k5 = "concat"
.line	1534	newtable      r8     1     0
.line	1534	getupval      r9    u2
.line	1534	loadk        r10    k6 ; k6 = 126
.line	1534	loadk        r11    k7 ; k7 = 68
.line	1534	loadk        r12    k8 ; k8 = 7
.line	1534	loadk        r13    k9 ; k9 = 41
.line	1534	loadk        r14   k10 ; k10 = 164
.line	1534	loadk        r15   k11 ; k11 = 170
.line	1534	loadk        r16   k12 ; k12 = 39
.line	1534	loadk        r17   k13 ; k13 = 95
.line	1534	loadk        r18   k14 ; k14 = 24
.line	1534	loadk        r19   k15 ; k15 = 91
.line	1534	loadk        r20   k16 ; k16 = 26
.line	1534	loadk        r21   k17 ; k17 = 31
.line	1534	loadk        r22   k18 ; k18 = 217
.line	1534	loadk        r23   k19 ; k19 = 83
.line	1534	loadk        r24   k20 ; k20 = 38
.line	1534	loadk        r25   k21 ; k21 = 54
.line	1534	loadk        r26   k22 ; k22 = 137
.line	1534	loadk        r27   k23 ; k23 = 103
.line	1534	loadk        r28   k24 ; k24 = 102
.line	1534	loadk        r29   k25 ; k25 = 25
.line	1534	loadk        r30   k26 ; k26 = 99
.line	1534	loadk        r31   k27 ; k27 = 156
.line	1534	loadk        r32   k28 ; k28 = 76
.line	1534	loadk        r33   k29 ; k29 = 122
.line	1534	loadk        r34   k30 ; k30 = 113
.line	1534	loadk        r35   k31 ; k31 = 97
.line	1534	loadk        r36   k32 ; k32 = 61
.line	1534	loadk        r37   k33 ; k33 = 20
.line	1534	loadk        r38   k34 ; k34 = 209
.line	1534	loadk        r39   k35 ; k35 = 64
.line	1534	loadk        r40   k36 ; k36 = 15
.line	1534	loadk        r41   k37 ; k37 = 0
.line	1534	loadk        r42   k38 ; k38 = 188
.line	1534	loadk        r43   k39 ; k39 = 114
.line	1534	loadk        r44   k40 ; k40 = 67
.line	1534	loadk        r45   k41 ; k41 = 6
.line	1534	loadk        r46   k42 ; k42 = 84
.line	1534	loadk        r47   k43 ; k43 = 182
.line	1534	loadk        r48   k13 ; k13 = 95
.line	1534	loadk        r49   k44 ; k44 = 106
.line	1534	call          r9    41     2
.line	1534	getupval     r10    u2
.line	1534	loadk        r11   k45 ; k45 = 92
.line	1534	loadk        r12   k46 ; k46 = 85
.line	1534	loadk        r13   k47 ; k47 = 9
.line	1534	loadk        r14   k48 ; k48 = 1
.line	1534	loadk        r15   k49 ; k49 = 190
.line	1534	loadk        r16   k50 ; k50 = 176
.line	1534	loadk        r17   k51 ; k51 = 37
.line	1534	loadk        r18   k15 ; k15 = 91
.line	1534	loadk        r19   k52 ; k52 = 53
.line	1534	loadk        r20   k53 ; k53 = 77
.line	1534	loadk        r21   k54 ; k54 = 12
.line	1534	loadk        r22   k55 ; k55 = 63
.line	1534	loadk        r23   k56 ; k56 = 196
.line	1534	loadk        r24   k15 ; k15 = 91
.line	1534	loadk        r25   k57 ; k57 = 22
.line	1534	loadk        r26   k13 ; k13 = 95
.line	1534	loadk        r27  k126 ; k126 = 132
.line	1534	loadk        r28  k123 ; k123 = 104
.line	1534	loadk        r29   k31 ; k31 = 97
.line	1534	loadk        r30   k54 ; k54 = 12
.line	1534	loadk        r31   k97 ; k97 = 65
.line	1534	loadk        r32  k127 ; k127 = 157
.line	1534	loadk        r33  k128 ; k128 = 66
.line	1534	loadk        r34   k64 ; k64 = 111
.line	1534	loadk        r35   k17 ; k17 = 31
.line	1534	loadk        r36   k28 ; k28 = 76
.line	1534	loadk        r37   k66 ; k66 = 28
.line	1534	loadk        r38   k99 ; k99 = 30
.line	1534	loadk        r39  k129 ; k129 = 134
.line	1534	loadk        r40   k45 ; k45 = 92
.line	1534	loadk        r41   k41 ; k41 = 6
.line	1534	loadk        r42  k130 ; k130 = 14
.line	1534	loadk        r43  k100 ; k100 = 185
.line	1534	loadk        r44   k64 ; k64 = 111
.line	1534	call         r10    35     0
.line	1534	setlist       r8     0     1
.line	1534	call          r7     2     2
.label	l676
.line	1534	gettabup      r8    u1   k67 ; k67 = "tostring"
.line	1534	getupval      r9    u3
.line	1534	call          r8     2     0
.line	1534	call          r6     0     1
.line	1534	getupval      r6    u5
.line	1534	gettable      r7    r3  k120 ; k120 = "InstanceTree"
.line	1534	call          r6     2     1
.line	1534	return        r0     1
.line	1534	move          r0    r0
.line	1534	move          r0    r0
.line	1534	move          r0    r0
.line	1534	gettabup      r0    u0  k111 ; k111 = 59
.line	1534	return        r0     1

.function	main/f73

.source	null
.linedefined	1568
.lastlinedefined	1614
.numparams	5
.is_vararg	0
.maxstacksize	52

.upvalue	"_ENV"	1	true
.upvalue	"U1"	0	false

.constant	k0	nil
.constant	k1	"print"
.constant	k2	"bWriteLog"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	126
.constant	k6	68
.constant	k7	7
.constant	k8	41
.constant	k9	164
.constant	k10	170
.constant	k11	39
.constant	k12	95
.constant	k13	24
.constant	k14	91
.constant	k15	26
.constant	k16	31
.constant	k17	217
.constant	k18	83
.constant	k19	38
.constant	k20	54
.constant	k21	137
.constant	k22	103
.constant	k23	102
.constant	k24	25
.constant	k25	99
.constant	k26	156
.constant	k27	76
.constant	k28	122
.constant	k29	113
.constant	k30	114
.constant	k31	22
.constant	k32	194
.constant	k33	123
.constant	k34	46
.constant	k35	40
.constant	k36	101
.constant	k37	6
.constant	k38	195
.constant	k39	112
.constant	k40	105
.constant	k41	78
.constant	k42	30
.constant	k43	177
.constant	k44	175
.constant	k45	36
.constant	k46	71
.constant	k47	75
.constant	k48	223
.constant	k49	80
.constant	k50	5
.constant	k51	161
.constant	k52	111
.constant	k53	118
.constant	k54	"type"
.constant	k55	67
.constant	k56	15
.constant	k57	42
.constant	k58	181
.constant	k59	66
.constant	k60	16
.constant	k61	33
.constant	k62	190
.constant	k63	"CustomAssetMgr"
.constant	k64	"IsCustomAssetKey"
.constant	k65	"tonumber"
.constant	k66	216
.constant	k67	11
.constant	k68	165
.constant	k69	96
.constant	k70	88
.constant	k71	134
.constant	k72	82
.constant	k73	56
.constant	k74	8
.constant	k75	213
.constant	k76	23
.constant	k77	184
.constant	k78	34
.constant	k79	145
.constant	k80	17
.constant	k81	121
.constant	k82	92
.constant	k83	20
.constant	k84	163
.constant	k85	227
.constant	k86	4
.constant	k87	18
.constant	k88	106
.constant	k89	"tostring"
.constant	k90	90
.constant	k91	27
.constant	k92	211
.constant	k93	187
.constant	k94	201
.constant	k95	"GetCreativeEntityManager"
.constant	k96	"slua"
.constant	k97	"isValid"
.constant	k98	"UUID2Key"
.constant	k99	100
.constant	k100	79
.constant	k101	116
.constant	k102	58
.constant	k103	176
.constant	k104	62
.constant	k105	86
.constant	k106	45
.constant	k107	73
.constant	k108	13
.constant	k109	215
.constant	k110	87
.constant	k111	169
.constant	k112	183
.constant	k113	"HasAuthority"
.constant	k114	"CreateUMGByCanvasID"
.constant	k115	"CreateUMGByCustomAssetKey"
.constant	k116	"ClientLoadUMGByCanvasID"
.constant	k117	"ClientLoadUMGRes"

.line	1568	eq             1    r1    k0 ; k0 = nil
.line	1568	jmp            0    l7
.line	1568	getupval      r5    u0
.line	1568	call          r5     1     2
.line	1568	eq             0    r1    r5
.line	1568	jmp            0   l85
.label	l7
.line	1568	gettabup      r5    u1    k1 ; k1 = "print"
.line	1568	gettabup      r6    u1    k2 ; k2 = "bWriteLog"
.line	1568	test          r6     0
.line	1568	jmp            0   l79
.line	1568	gettabup      r6    u1    k3 ; k3 = "table"
.line	1568	gettable      r6    r6    k4 ; k4 = "concat"
.line	1568	newtable      r7     1     0
.line	1568	getupval      r8    u0
.line	1568	loadk         r9    k5 ; k5 = 126
.line	1568	loadk        r10    k6 ; k6 = 68
.line	1568	loadk        r11    k7 ; k7 = 7
.line	1568	loadk        r12    k8 ; k8 = 41
.line	1568	loadk        r13    k9 ; k9 = 164
.line	1568	loadk        r14   k10 ; k10 = 170
.line	1568	loadk        r15   k11 ; k11 = 39
.line	1568	loadk        r16   k12 ; k12 = 95
.line	1568	loadk        r17   k13 ; k13 = 24
.line	1568	loadk        r18   k14 ; k14 = 91
.line	1568	loadk        r19   k15 ; k15 = 26
.line	1568	loadk        r20   k16 ; k16 = 31
.line	1568	loadk        r21   k17 ; k17 = 217
.line	1568	loadk        r22   k18 ; k18 = 83
.line	1568	loadk        r23   k19 ; k19 = 38
.line	1568	loadk        r24   k20 ; k20 = 54
.line	1568	loadk        r25   k21 ; k21 = 137
.line	1568	loadk        r26   k22 ; k22 = 103
.line	1568	loadk        r27   k23 ; k23 = 102
.line	1568	loadk        r28   k24 ; k24 = 25
.line	1568	loadk        r29   k25 ; k25 = 99
.line	1568	loadk        r30   k26 ; k26 = 156
.line	1568	loadk        r31   k27 ; k27 = 76
.line	1568	loadk        r32   k28 ; k28 = 122
.line	1568	loadk        r33   k29 ; k29 = 113
.line	1568	loadk        r34   k30 ; k30 = 114
.line	1568	loadk        r35   k31 ; k31 = 22
.line	1568	loadk        r36   k15 ; k15 = 26
.line	1568	loadk        r37   k32 ; k32 = 194
.line	1568	loadk        r38   k33 ; k33 = 123
.line	1568	loadk        r39   k34 ; k34 = 46
.line	1568	loadk        r40   k35 ; k35 = 40
.line	1568	loadk        r41   k26 ; k26 = 156
.line	1568	loadk        r42   k36 ; k36 = 101
.line	1568	loadk        r43   k33 ; k33 = 123
.line	1568	loadk        r44   k37 ; k37 = 6
.line	1568	loadk        r45   k18 ; k18 = 83
.line	1568	loadk        r46   k38 ; k38 = 195
.line	1568	loadk        r47   k39 ; k39 = 112
.line	1568	loadk        r48   k40 ; k40 = 105
.line	1568	call          r8    41     2
.line	1568	getupval      r9    u0
.line	1568	loadk        r10   k41 ; k41 = 78
.line	1568	loadk        r11   k18 ; k18 = 83
.line	1568	loadk        r12   k31 ; k31 = 22
.line	1568	loadk        r13   k42 ; k42 = 30
.line	1568	loadk        r14   k43 ; k43 = 177
.line	1568	loadk        r15   k44 ; k44 = 175
.line	1568	loadk        r16   k45 ; k45 = 36
.line	1568	loadk        r17   k12 ; k12 = 95
.line	1568	loadk        r18   k33 ; k33 = 123
.line	1568	loadk        r19   k46 ; k46 = 71
.line	1568	loadk        r20   k15 ; k15 = 26
.line	1568	loadk        r21   k47 ; k47 = 75
.line	1568	loadk        r22   k48 ; k48 = 223
.line	1568	loadk        r23   k49 ; k49 = 80
.line	1568	loadk        r24   k50 ; k50 = 5
.line	1568	loadk        r25   k42 ; k42 = 30
.line	1568	loadk        r26   k51 ; k51 = 161
.line	1568	loadk        r27   k52 ; k52 = 111
.line	1568	loadk        r28   k53 ; k53 = 118
.line	1568	call          r9    20     0
.line	1568	setlist       r7     0     1
.line	1568	call          r6     2     2
.label	l79
.line	1568	call          r5     2     1
.line	1568	move          r5    r3
.line	1568	loadnil       r6     0
.line	1568	call          r5     2     1
.line	1568	loadnil       r5     0
.line	1568	return        r5     2
.label	l85
.line	1568	loadnil       r5     0
.line	1568	gettabup      r6    u1   k54 ; k54 = "type"
.line	1568	move          r7    r1
.line	1568	call          r6     2     2
.line	1568	getupval      r7    u0
.line	1568	loadk         r8   k18 ; k18 = 83
.line	1568	loadk         r9   k55 ; k55 = 67
.line	1568	loadk        r10   k56 ; k56 = 15
.line	1568	loadk        r11   k57 ; k57 = 42
.line	1568	loadk        r12   k58 ; k58 = 181
.line	1568	loadk        r13   k43 ; k43 = 177
.line	1568	call          r7     7     2
.line	1568	eq             0    r6    r7
.line	1568	jmp            0  l101
.line	1568	move          r5    r1
.line	1568	jmp            0  l331
.label	l101
.line	1568	gettabup      r6    u1   k54 ; k54 = "type"
.line	1568	move          r7    r1
.line	1568	call          r6     2     2
.line	1568	getupval      r7    u0
.line	1568	loadk         r8   k41 ; k41 = 78
.line	1568	loadk         r9   k59 ; k59 = 66
.line	1568	loadk        r10   k60 ; k60 = 16
.line	1568	loadk        r11   k61 ; k61 = 33
.line	1568	loadk        r12   k62 ; k62 = 190
.line	1568	loadk        r13    k9 ; k9 = 164
.line	1568	call          r7     7     2
.line	1568	eq             0    r6    r7
.line	1568	jmp            0  l246
.line	1568	gettabup      r6    u1   k63 ; k63 = "CustomAssetMgr"
.line	1568	test          r6     0
.line	1568	jmp            0  l123
.line	1568	gettabup      r6    u1   k63 ; k63 = "CustomAssetMgr"
.line	1568	self          r6    r6   k64 ; k64 = "IsCustomAssetKey"
.line	1568	move          r8    r1
.line	1568	call          r6     3     2
.line	1568	test          r6     1
.line	1568	jmp            0  l331
.label	l123
.line	1568	gettabup      r6    u1   k65 ; k65 = "tonumber"
.line	1568	move          r7    r1
.line	1568	call          r6     2     2
.line	1568	move          r5    r6
.line	1568	eq             0    r5    k0 ; k0 = nil
.line	1568	jmp            0  l331
.line	1568	gettabup      r6    u1    k1 ; k1 = "print"
.line	1568	gettabup      r7    u1    k2 ; k2 = "bWriteLog"
.line	1568	test          r7     0
.line	1568	jmp            0  l239
.line	1568	gettabup      r7    u1    k3 ; k3 = "table"
.line	1568	gettable      r7    r7    k4 ; k4 = "concat"
.line	1568	newtable      r8     2     0
.line	1568	getupval      r9    u0
.line	1568	loadk        r10    k5 ; k5 = 126
.line	1568	loadk        r11    k6 ; k6 = 68
.line	1568	loadk        r12    k7 ; k7 = 7
.line	1568	loadk        r13    k8 ; k8 = 41
.line	1568	loadk        r14    k9 ; k9 = 164
.line	1568	loadk        r15   k10 ; k10 = 170
.line	1568	loadk        r16   k11 ; k11 = 39
.line	1568	loadk        r17   k12 ; k12 = 95
.line	1568	loadk        r18   k13 ; k13 = 24
.line	1568	loadk        r19   k14 ; k14 = 91
.line	1568	loadk        r20   k15 ; k15 = 26
.line	1568	loadk        r21   k16 ; k16 = 31
.line	1568	loadk        r22   k17 ; k17 = 217
.line	1568	loadk        r23   k18 ; k18 = 83
.line	1568	loadk        r24   k19 ; k19 = 38
.line	1568	loadk        r25   k20 ; k20 = 54
.line	1568	loadk        r26   k21 ; k21 = 137
.line	1568	loadk        r27   k22 ; k22 = 103
.line	1568	loadk        r28   k23 ; k23 = 102
.line	1568	loadk        r29   k24 ; k24 = 25
.line	1568	loadk        r30   k25 ; k25 = 99
.line	1568	loadk        r31   k26 ; k26 = 156
.line	1568	loadk        r32   k27 ; k27 = 76
.line	1568	loadk        r33   k28 ; k28 = 122
.line	1568	loadk        r34   k29 ; k29 = 113
.line	1568	loadk        r35   k30 ; k30 = 114
.line	1568	loadk        r36   k31 ; k31 = 22
.line	1568	loadk        r37   k15 ; k15 = 26
.line	1568	loadk        r38   k32 ; k32 = 194
.line	1568	loadk        r39   k33 ; k33 = 123
.line	1568	loadk        r40   k34 ; k34 = 46
.line	1568	loadk        r41   k35 ; k35 = 40
.line	1568	loadk        r42   k26 ; k26 = 156
.line	1568	loadk        r43   k36 ; k36 = 101
.line	1568	loadk        r44   k33 ; k33 = 123
.line	1568	loadk        r45   k37 ; k37 = 6
.line	1568	loadk        r46   k18 ; k18 = 83
.line	1568	loadk        r47   k38 ; k38 = 195
.line	1568	loadk        r48   k39 ; k39 = 112
.line	1568	loadk        r49   k40 ; k40 = 105
.line	1568	call          r9    41     2
.line	1568	getupval     r10    u0
.line	1568	loadk        r11   k41 ; k41 = 78
.line	1568	loadk        r12   k18 ; k18 = 83
.line	1568	loadk        r13   k31 ; k31 = 22
.line	1568	loadk        r14   k42 ; k42 = 30
.line	1568	loadk        r15   k43 ; k43 = 177
.line	1568	loadk        r16   k44 ; k44 = 175
.line	1568	loadk        r17   k45 ; k45 = 36
.line	1568	loadk        r18   k12 ; k12 = 95
.line	1568	loadk        r19   k33 ; k33 = 123
.line	1568	loadk        r20   k46 ; k46 = 71
.line	1568	loadk        r21   k15 ; k15 = 26
.line	1568	loadk        r22   k47 ; k47 = 75
.line	1568	loadk        r23   k66 ; k66 = 216
.line	1568	loadk        r24   k14 ; k14 = 91
.line	1568	loadk        r25   k15 ; k15 = 26
.line	1568	loadk        r26   k67 ; k67 = 11
.line	1568	loadk        r27   k68 ; k68 = 165
.line	1568	loadk        r28   k25 ; k25 = 99
.line	1568	loadk        r29   k69 ; k69 = 96
.line	1568	loadk        r30   k70 ; k70 = 88
.line	1568	loadk        r31   k25 ; k25 = 99
.line	1568	loadk        r32   k71 ; k71 = 134
.line	1568	loadk        r33   k72 ; k72 = 82
.line	1568	loadk        r34    k5 ; k5 = 126
.line	1568	loadk        r35   k45 ; k45 = 36
.line	1568	loadk        r36   k18 ; k18 = 83
.line	1568	loadk        r37   k73 ; k73 = 56
.line	1568	loadk        r38   k74 ; k74 = 8
.line	1568	loadk        r39   k75 ; k75 = 213
.line	1568	loadk        r40   k47 ; k47 = 75
.line	1568	loadk        r41   k76 ; k76 = 23
.line	1568	loadk        r42   k45 ; k45 = 36
.line	1568	loadk        r43   k77 ; k77 = 184
.line	1568	loadk        r44   k52 ; k52 = 111
.line	1568	loadk        r45   k78 ; k78 = 34
.line	1568	loadk        r46   k37 ; k37 = 6
.line	1568	loadk        r47   k12 ; k12 = 95
.line	1568	loadk        r48   k79 ; k79 = 145
.line	1568	loadk        r49   k80 ; k80 = 17
.line	1568	loadk        r50   k81 ; k81 = 121
.line	1568	call         r10    41     2
.line	1568	getupval     r11    u0
.line	1568	loadk        r12   k82 ; k82 = 92
.line	1568	loadk        r13   k70 ; k70 = 88
.line	1568	loadk        r14   k83 ; k83 = 20
.line	1568	loadk        r15    k8 ; k8 = 41
.line	1568	loadk        r16   k84 ; k84 = 163
.line	1568	loadk        r17   k85 ; k85 = 227
.line	1568	loadk        r18   k86 ; k86 = 4
.line	1568	loadk        r19   k52 ; k52 = 111
.line	1568	loadk        r20   k87 ; k87 = 18
.line	1568	loadk        r21   k88 ; k88 = 106
.line	1568	loadk        r22   k18 ; k18 = 83
.line	1568	call         r11    12     0
.line	1568	setlist       r8     0     1
.line	1568	call          r7     2     2
.line	1568	gettabup      r8    u1   k89 ; k89 = "tostring"
.line	1568	move          r9    r1
.line	1568	call          r8     2     2
.line	1568	concat        r7    r7    r8
.label	l239
.line	1568	call          r6     2     1
.line	1568	move          r6    r3
.line	1568	loadnil       r7     0
.line	1568	call          r6     2     1
.line	1568	loadnil       r6     0
.line	1568	return        r6     2
.line	1568	jmp            0  l331
.label	l246
.line	1568	gettabup      r6    u1    k1 ; k1 = "print"
.line	1568	gettabup      r7    u1    k2 ; k2 = "bWriteLog"
.line	1568	test          r7     0
.line	1568	jmp            0  l325
.line	1568	gettabup      r7    u1    k3 ; k3 = "table"
.line	1568	gettable      r7    r7    k4 ; k4 = "concat"
.line	1568	newtable      r8     1     0
.line	1568	getupval      r9    u0
.line	1568	loadk        r10    k5 ; k5 = 126
.line	1568	loadk        r11    k6 ; k6 = 68
.line	1568	loadk        r12    k7 ; k7 = 7
.line	1568	loadk        r13    k8 ; k8 = 41
.line	1568	loadk        r14    k9 ; k9 = 164
.line	1568	loadk        r15   k10 ; k10 = 170
.line	1568	loadk        r16   k11 ; k11 = 39
.line	1568	loadk        r17   k12 ; k12 = 95
.line	1568	loadk        r18   k13 ; k13 = 24
.line	1568	loadk        r19   k14 ; k14 = 91
.line	1568	loadk        r20   k15 ; k15 = 26
.line	1568	loadk        r21   k16 ; k16 = 31
.line	1568	loadk        r22   k17 ; k17 = 217
.line	1568	loadk        r23   k18 ; k18 = 83
.line	1568	loadk        r24   k19 ; k19 = 38
.line	1568	loadk        r25   k20 ; k20 = 54
.line	1568	loadk        r26   k21 ; k21 = 137
.line	1568	loadk        r27   k22 ; k22 = 103
.line	1568	loadk        r28   k23 ; k23 = 102
.line	1568	loadk        r29   k24 ; k24 = 25
.line	1568	loadk        r30   k25 ; k25 = 99
.line	1568	loadk        r31   k26 ; k26 = 156
.line	1568	loadk        r32   k27 ; k27 = 76
.line	1568	loadk        r33   k28 ; k28 = 122
.line	1568	loadk        r34   k29 ; k29 = 113
.line	1568	loadk        r35   k30 ; k30 = 114
.line	1568	loadk        r36   k31 ; k31 = 22
.line	1568	loadk        r37   k15 ; k15 = 26
.line	1568	loadk        r38   k32 ; k32 = 194
.line	1568	loadk        r39   k33 ; k33 = 123
.line	1568	loadk        r40   k34 ; k34 = 46
.line	1568	loadk        r41   k35 ; k35 = 40
.line	1568	loadk        r42   k26 ; k26 = 156
.line	1568	loadk        r43   k36 ; k36 = 101
.line	1568	loadk        r44   k33 ; k33 = 123
.line	1568	loadk        r45   k37 ; k37 = 6
.line	1568	loadk        r46   k18 ; k18 = 83
.line	1568	loadk        r47   k38 ; k38 = 195
.line	1568	loadk        r48   k39 ; k39 = 112
.line	1568	loadk        r49   k40 ; k40 = 105
.line	1568	call          r9    41     2
.line	1568	getupval     r10    u0
.line	1568	loadk        r11   k41 ; k41 = 78
.line	1568	loadk        r12   k18 ; k18 = 83
.line	1568	loadk        r13   k31 ; k31 = 22
.line	1568	loadk        r14   k42 ; k42 = 30
.line	1568	loadk        r15   k43 ; k43 = 177
.line	1568	loadk        r16   k44 ; k44 = 175
.line	1568	loadk        r17   k45 ; k45 = 36
.line	1568	loadk        r18   k12 ; k12 = 95
.line	1568	loadk        r19   k33 ; k33 = 123
.line	1568	loadk        r20   k90 ; k90 = 90
.line	1568	loadk        r21   k60 ; k60 = 16
.line	1568	loadk        r22   k91 ; k91 = 27
.line	1568	loadk        r23   k92 ; k92 = 211
.line	1568	loadk        r24   k42 ; k42 = 30
.line	1568	loadk        r25   k15 ; k15 = 26
.line	1568	loadk        r26   k80 ; k80 = 17
.line	1568	loadk        r27   k93 ; k93 = 187
.line	1568	loadk        r28   k22 ; k22 = 103
.line	1568	loadk        r29    k5 ; k5 = 126
.line	1568	loadk        r30   k80 ; k80 = 17
.line	1568	loadk        r31    k6 ; k6 = 68
.line	1568	loadk        r32   k94 ; k94 = 201
.line	1568	call         r10    23     0
.line	1568	setlist       r8     0     1
.line	1568	call          r7     2     2
.line	1568	gettabup      r8    u1   k54 ; k54 = "type"
.line	1568	move          r9    r1
.line	1568	call          r8     2     2
.line	1568	concat        r7    r7    r8
.label	l325
.line	1568	call          r6     2     1
.line	1568	move          r6    r3
.line	1568	loadnil       r7     0
.line	1568	call          r6     2     1
.line	1568	loadnil       r6     0
.line	1568	return        r6     2
.label	l331
.line	1568	loadnil       r6     0
.line	1568	eq             1    r5    k0 ; k0 = nil
.line	1568	jmp            0  l434
.line	1568	gettabup      r7    u1   k95 ; k95 = "GetCreativeEntityMan" (truncated)
.line	1568	call          r7     1     2
.line	1568	gettabup      r8    u1   k96 ; k96 = "slua"
.line	1568	gettable      r8    r8   k97 ; k97 = "isValid"
.line	1568	move          r9    r7
.line	1568	call          r8     2     2
.line	1568	test          r8     0
.line	1568	jmp            0  l346
.line	1568	self          r8    r7   k98 ; k98 = "UUID2Key"
.line	1568	move         r10    r5
.line	1568	call          r8     3     2
.line	1568	move          r6    r8
.label	l346
.line	1568	eq             0    r6    k0 ; k0 = nil
.line	1568	jmp            0  l434
.line	1568	gettabup      r8    u1    k1 ; k1 = "print"
.line	1568	gettabup      r9    u1    k2 ; k2 = "bWriteLog"
.line	1568	test          r9     0
.line	1568	jmp            0  l428
.line	1568	gettabup      r9    u1    k3 ; k3 = "table"
.line	1568	gettable      r9    r9    k4 ; k4 = "concat"
.line	1568	newtable     r10     1     0
.line	1568	getupval     r11    u0
.line	1568	loadk        r12    k5 ; k5 = 126
.line	1568	loadk        r13    k6 ; k6 = 68
.line	1568	loadk        r14    k7 ; k7 = 7
.line	1568	loadk        r15    k8 ; k8 = 41
.line	1568	loadk        r16    k9 ; k9 = 164
.line	1568	loadk        r17   k10 ; k10 = 170
.line	1568	loadk        r18   k11 ; k11 = 39
.line	1568	loadk        r19   k12 ; k12 = 95
.line	1568	loadk        r20   k13 ; k13 = 24
.line	1568	loadk        r21   k14 ; k14 = 91
.line	1568	loadk        r22   k15 ; k15 = 26
.line	1568	loadk        r23   k16 ; k16 = 31
.line	1568	loadk        r24   k17 ; k17 = 217
.line	1568	loadk        r25   k18 ; k18 = 83
.line	1568	loadk        r26   k19 ; k19 = 38
.line	1568	loadk        r27   k20 ; k20 = 54
.line	1568	loadk        r28   k21 ; k21 = 137
.line	1568	loadk        r29   k22 ; k22 = 103
.line	1568	loadk        r30   k23 ; k23 = 102
.line	1568	loadk        r31   k24 ; k24 = 25
.line	1568	loadk        r32   k25 ; k25 = 99
.line	1568	loadk        r33   k26 ; k26 = 156
.line	1568	loadk        r34   k27 ; k27 = 76
.line	1568	loadk        r35   k28 ; k28 = 122
.line	1568	loadk        r36   k29 ; k29 = 113
.line	1568	loadk        r37   k30 ; k30 = 114
.line	1568	loadk        r38   k31 ; k31 = 22
.line	1568	loadk        r39   k15 ; k15 = 26
.line	1568	loadk        r40   k32 ; k32 = 194
.line	1568	loadk        r41   k33 ; k33 = 123
.line	1568	loadk        r42   k34 ; k34 = 46
.line	1568	loadk        r43   k35 ; k35 = 40
.line	1568	loadk        r44   k26 ; k26 = 156
.line	1568	loadk        r45   k36 ; k36 = 101
.line	1568	loadk        r46   k33 ; k33 = 123
.line	1568	loadk        r47   k37 ; k37 = 6
.line	1568	loadk        r48   k18 ; k18 = 83
.line	1568	loadk        r49   k38 ; k38 = 195
.line	1568	loadk        r50   k99 ; k99 = 100
.line	1568	loadk        r51  k100 ; k100 = 79
.line	1568	call         r11    41     2
.line	1568	getupval     r12    u0
.line	1568	loadk        r13  k101 ; k101 = 116
.line	1568	loadk        r14   k30 ; k30 = 114
.line	1568	loadk        r15   k59 ; k59 = 66
.line	1568	loadk        r16  k102 ; k102 = 58
.line	1568	loadk        r17   k58 ; k58 = 181
.line	1568	loadk        r18  k103 ; k103 = 176
.line	1568	loadk        r19  k104 ; k104 = 62
.line	1568	loadk        r20  k105 ; k105 = 86
.line	1568	loadk        r21  k106 ; k106 = 45
.line	1568	loadk        r22   k47 ; k47 = 75
.line	1568	loadk        r23  k107 ; k107 = 73
.line	1568	loadk        r24  k108 ; k108 = 13
.line	1568	loadk        r25  k109 ; k109 = 215
.line	1568	loadk        r26  k110 ; k110 = 87
.line	1568	loadk        r27   k16 ; k16 = 31
.line	1568	loadk        r28   k15 ; k15 = 26
.line	1568	loadk        r29  k111 ; k111 = 169
.line	1568	loadk        r30   k19 ; k19 = 38
.line	1568	loadk        r31   k46 ; k46 = 71
.line	1568	loadk        r32  k106 ; k106 = 45
.line	1568	loadk        r33   k40 ; k40 = 105
.line	1568	loadk        r34  k112 ; k112 = 183
.line	1568	loadk        r35   k91 ; k91 = 27
.line	1568	call         r12    24     0
.line	1568	setlist      r10     0     1
.line	1568	call          r9     2     2
.line	1568	gettabup     r10    u1   k89 ; k89 = "tostring"
.line	1568	move         r11    r5
.line	1568	call         r10     2     2
.line	1568	concat        r9    r9   r10
.label	l428
.line	1568	call          r8     2     1
.line	1568	move          r8    r3
.line	1568	loadnil       r9     0
.line	1568	call          r8     2     1
.line	1568	loadnil       r8     0
.line	1568	return        r8     2
.label	l434
.line	1568	self          r7    r0  k113 ; k113 = "HasAuthority"
.line	1568	call          r7     2     2
.line	1568	test          r7     0
.line	1568	jmp            0  l454
.line	1568	eq             1    r6    k0 ; k0 = nil
.line	1568	jmp            0  l447
.line	1568	self          r7    r0  k114 ; k114 = "CreateUMGByCanvasID"
.line	1568	move          r9    r6
.line	1568	move         r10    r2
.line	1568	move         r11    r3
.line	1568	move         r12    r4
.line	1568	tailcall      r7     6
.line	1568	return        r7     0
.label	l447
.line	1568	self          r7    r0  k115 ; k115 = "CreateUMGByCustomAss" (truncated)
.line	1568	move          r9    r1
.line	1568	move         r10    r2
.line	1568	move         r11    r3
.line	1568	tailcall      r7     5
.line	1568	return        r7     0
.line	1568	jmp            0  l469
.label	l454
.line	1568	eq             1    r6    k0 ; k0 = nil
.line	1568	jmp            0  l463
.line	1568	self          r7    r0  k116 ; k116 = "ClientLoadUMGByCanva" (truncated)
.line	1568	move          r9    r6
.line	1568	move         r10    r2
.line	1568	move         r11    r3
.line	1568	move         r12    r4
.line	1568	tailcall      r7     6
.line	1568	return        r7     0
.label	l463
.line	1568	self          r7    r0  k117 ; k117 = "ClientLoadUMGRes"
.line	1568	move          r9    r1
.line	1568	move         r10    r2
.line	1568	move         r11    r3
.line	1568	tailcall      r7     5
.line	1568	return        r7     0
.label	l469
.line	1568	return        r0     1
.line	1568	move          r0    r0
.line	1568	move          r0    r0
.line	1568	move          r0    r0
.line	1568	move          r0    r0
.line	1568	return        r0     1

.function	main/f74

.source	null
.linedefined	1616
.lastlinedefined	1640
.numparams	4
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"HasAuthority"
.constant	k1	"print"
.constant	k2	"bWriteLog"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	126
.constant	k6	68
.constant	k7	7
.constant	k8	41
.constant	k9	164
.constant	k10	170
.constant	k11	39
.constant	k12	95
.constant	k13	24
.constant	k14	91
.constant	k15	26
.constant	k16	31
.constant	k17	217
.constant	k18	83
.constant	k19	38
.constant	k20	54
.constant	k21	137
.constant	k22	103
.constant	k23	102
.constant	k24	25
.constant	k25	99
.constant	k26	156
.constant	k27	76
.constant	k28	122
.constant	k29	113
.constant	k30	125
.constant	k31	11
.constant	k32	30
.constant	k33	199
.constant	k34	90
.constant	k35	6
.constant	k36	58
.constant	k37	144
.constant	k38	81
.constant	k39	64
.constant	k40	17
.constant	k41	115
.constant	k42	150
.constant	k43	66
.constant	k44	110
.constant	k45	82
.constant	k46	35
.constant	k47	59
.constant	k48	163
.constant	k49	166
.constant	k50	37
.constant	k51	62
.constant	k52	87
.constant	k53	73
.constant	k54	221
.constant	k55	3
.constant	k56	105
.constant	k57	63
.constant	k58	85
.constant	k59	135
.constant	k60	101
.constant	k61	57
.constant	k62	13
.constant	k63	2
.constant	k64	"tostring"
.constant	k65	"type"
.constant	k66	78
.constant	k67	16
.constant	k68	33
.constant	k69	190
.constant	k70	40
.constant	k71	195
.constant	k72	77
.constant	k73	160
.constant	k74	71
.constant	k75	97
.constant	k76	69
.constant	k77	106
.constant	k78	111
.constant	k79	50
.constant	k80	8
.constant	k81	134
.constant	k82	188
.constant	k83	107
.constant	k84	12
.constant	k85	"CustomAssetMgr"
.constant	k86	nil
.constant	k87	108
.constant	k88	109
.constant	k89	10
.constant	k90	"_AsyncLoadSeq"
.constant	k91	0
.constant	k92	1
.constant	k93	9
.constant	k94	211
.constant	k95	89
.constant	k96	124
.constant	k97	27
.constant	k98	179
.constant	k99	52
.constant	k100	75
.constant	k101	"_DownloadAndUnpackInstanceTree"

.line	1616	self          r4    r0    k0 ; k0 = "HasAuthority"
.line	1616	call          r4     2     2
.line	1616	test          r4     1
.line	1616	jmp            0   l95
.line	1616	gettabup      r4    u0    k1 ; k1 = "print"
.line	1616	gettabup      r5    u0    k2 ; k2 = "bWriteLog"
.line	1616	test          r5     0
.line	1616	jmp            0   l86
.line	1616	gettabup      r5    u0    k3 ; k3 = "table"
.line	1616	gettable      r5    r5    k4 ; k4 = "concat"
.line	1616	newtable      r6     1     0
.line	1616	getupval      r7    u1
.line	1616	loadk         r8    k5 ; k5 = 126
.line	1616	loadk         r9    k6 ; k6 = 68
.line	1616	loadk        r10    k7 ; k7 = 7
.line	1616	loadk        r11    k8 ; k8 = 41
.line	1616	loadk        r12    k9 ; k9 = 164
.line	1616	loadk        r13   k10 ; k10 = 170
.line	1616	loadk        r14   k11 ; k11 = 39
.line	1616	loadk        r15   k12 ; k12 = 95
.line	1616	loadk        r16   k13 ; k13 = 24
.line	1616	loadk        r17   k14 ; k14 = 91
.line	1616	loadk        r18   k15 ; k15 = 26
.line	1616	loadk        r19   k16 ; k16 = 31
.line	1616	loadk        r20   k17 ; k17 = 217
.line	1616	loadk        r21   k18 ; k18 = 83
.line	1616	loadk        r22   k19 ; k19 = 38
.line	1616	loadk        r23   k20 ; k20 = 54
.line	1616	loadk        r24   k21 ; k21 = 137
.line	1616	loadk        r25   k22 ; k22 = 103
.line	1616	loadk        r26   k23 ; k23 = 102
.line	1616	loadk        r27   k24 ; k24 = 25
.line	1616	loadk        r28   k25 ; k25 = 99
.line	1616	loadk        r29   k26 ; k26 = 156
.line	1616	loadk        r30   k27 ; k27 = 76
.line	1616	loadk        r31   k28 ; k28 = 122
.line	1616	loadk        r32   k29 ; k29 = 113
.line	1616	loadk        r33   k30 ; k30 = 125
.line	1616	loadk        r34   k31 ; k31 = 11
.line	1616	loadk        r35   k32 ; k32 = 30
.line	1616	loadk        r36   k33 ; k33 = 199
.line	1616	loadk        r37   k34 ; k34 = 90
.line	1616	loadk        r38   k35 ; k35 = 6
.line	1616	loadk        r39   k36 ; k36 = 58
.line	1616	loadk        r40   k37 ; k37 = 144
.line	1616	loadk        r41   k38 ; k38 = 81
.line	1616	loadk        r42   k39 ; k39 = 64
.line	1616	loadk        r43   k40 ; k40 = 17
.line	1616	loadk        r44   k41 ; k41 = 115
.line	1616	loadk        r45   k42 ; k42 = 150
.line	1616	loadk        r46   k43 ; k43 = 66
.line	1616	loadk        r47   k44 ; k44 = 110
.line	1616	call          r7    41     2
.line	1616	getupval      r8    u1
.line	1616	loadk         r9   k45 ; k45 = 82
.line	1616	loadk        r10   k14 ; k14 = 91
.line	1616	loadk        r11   k46 ; k46 = 35
.line	1616	loadk        r12   k47 ; k47 = 59
.line	1616	loadk        r13   k48 ; k48 = 163
.line	1616	loadk        r14   k49 ; k49 = 166
.line	1616	loadk        r15   k50 ; k50 = 37
.line	1616	loadk        r16   k29 ; k29 = 113
.line	1616	loadk        r17   k51 ; k51 = 62
.line	1616	loadk        r18   k52 ; k52 = 87
.line	1616	loadk        r19   k53 ; k53 = 73
.line	1616	loadk        r20   k13 ; k13 = 24
.line	1616	loadk        r21   k54 ; k54 = 221
.line	1616	loadk        r22   k52 ; k52 = 87
.line	1616	loadk        r23   k55 ; k55 = 3
.line	1616	loadk        r24   k45 ; k45 = 82
.line	1616	loadk        r25   k48 ; k48 = 163
.line	1616	loadk        r26   k56 ; k56 = 105
.line	1616	loadk        r27   k57 ; k57 = 63
.line	1616	loadk        r28   k24 ; k24 = 25
.line	1616	loadk        r29   k58 ; k58 = 85
.line	1616	loadk        r30   k59 ; k59 = 135
.line	1616	loadk        r31   k53 ; k53 = 73
.line	1616	loadk        r32   k60 ; k60 = 101
.line	1616	loadk        r33   k61 ; k61 = 57
.line	1616	loadk        r34   k52 ; k52 = 87
.line	1616	loadk        r35   k62 ; k62 = 13
.line	1616	loadk        r36   k63 ; k63 = 2
.line	1616	call          r8    29     0
.line	1616	setlist       r6     0     1
.line	1616	call          r5     2     2
.label	l86
.line	1616	gettabup      r6    u0   k64 ; k64 = "tostring"
.line	1616	move          r7    r1
.line	1616	call          r6     2     0
.line	1616	call          r4     0     1
.line	1616	move          r4    r3
.line	1616	loadnil       r5     0
.line	1616	call          r4     2     1
.line	1616	loadnil       r4     0
.line	1616	return        r4     2
.label	l95
.line	1616	gettabup      r4    u0   k65 ; k65 = "type"
.line	1616	move          r5    r1
.line	1616	call          r4     2     2
.line	1616	getupval      r5    u1
.line	1616	loadk         r6   k66 ; k66 = 78
.line	1616	loadk         r7   k43 ; k43 = 66
.line	1616	loadk         r8   k67 ; k67 = 16
.line	1616	loadk         r9   k68 ; k68 = 33
.line	1616	loadk        r10   k69 ; k69 = 190
.line	1616	loadk        r11    k9 ; k9 = 164
.line	1616	call          r5     7     2
.line	1616	eq             0    r4    r5
.line	1616	jmp            0  l112
.line	1616	getupval      r4    u1
.line	1616	call          r4     1     2
.line	1616	eq             0    r1    r4
.line	1616	jmp            0  l207
.label	l112
.line	1616	gettabup      r4    u0    k1 ; k1 = "print"
.line	1616	gettabup      r5    u0    k2 ; k2 = "bWriteLog"
.line	1616	test          r5     0
.line	1616	jmp            0  l201
.line	1616	gettabup      r5    u0    k3 ; k3 = "table"
.line	1616	gettable      r5    r5    k4 ; k4 = "concat"
.line	1616	newtable      r6     1     0
.line	1616	getupval      r7    u1
.line	1616	loadk         r8    k5 ; k5 = 126
.line	1616	loadk         r9    k6 ; k6 = 68
.line	1616	loadk        r10    k7 ; k7 = 7
.line	1616	loadk        r11    k8 ; k8 = 41
.line	1616	loadk        r12    k9 ; k9 = 164
.line	1616	loadk        r13   k10 ; k10 = 170
.line	1616	loadk        r14   k11 ; k11 = 39
.line	1616	loadk        r15   k12 ; k12 = 95
.line	1616	loadk        r16   k13 ; k13 = 24
.line	1616	loadk        r17   k14 ; k14 = 91
.line	1616	loadk        r18   k15 ; k15 = 26
.line	1616	loadk        r19   k16 ; k16 = 31
.line	1616	loadk        r20   k17 ; k17 = 217
.line	1616	loadk        r21   k18 ; k18 = 83
.line	1616	loadk        r22   k19 ; k19 = 38
.line	1616	loadk        r23   k20 ; k20 = 54
.line	1616	loadk        r24   k21 ; k21 = 137
.line	1616	loadk        r25   k22 ; k22 = 103
.line	1616	loadk        r26   k23 ; k23 = 102
.line	1616	loadk        r27   k24 ; k24 = 25
.line	1616	loadk        r28   k25 ; k25 = 99
.line	1616	loadk        r29   k26 ; k26 = 156
.line	1616	loadk        r30   k27 ; k27 = 76
.line	1616	loadk        r31   k28 ; k28 = 122
.line	1616	loadk        r32   k29 ; k29 = 113
.line	1616	loadk        r33   k30 ; k30 = 125
.line	1616	loadk        r34   k31 ; k31 = 11
.line	1616	loadk        r35   k32 ; k32 = 30
.line	1616	loadk        r36   k33 ; k33 = 199
.line	1616	loadk        r37   k34 ; k34 = 90
.line	1616	loadk        r38   k35 ; k35 = 6
.line	1616	loadk        r39   k36 ; k36 = 58
.line	1616	loadk        r40   k37 ; k37 = 144
.line	1616	loadk        r41   k38 ; k38 = 81
.line	1616	loadk        r42   k39 ; k39 = 64
.line	1616	loadk        r43   k40 ; k40 = 17
.line	1616	loadk        r44   k41 ; k41 = 115
.line	1616	loadk        r45   k42 ; k42 = 150
.line	1616	loadk        r46   k43 ; k43 = 66
.line	1616	loadk        r47   k44 ; k44 = 110
.line	1616	call          r7    41     2
.line	1616	getupval      r8    u1
.line	1616	loadk         r9   k45 ; k45 = 82
.line	1616	loadk        r10   k14 ; k14 = 91
.line	1616	loadk        r11   k46 ; k46 = 35
.line	1616	loadk        r12   k47 ; k47 = 59
.line	1616	loadk        r13   k48 ; k48 = 163
.line	1616	loadk        r14   k49 ; k49 = 166
.line	1616	loadk        r15   k50 ; k50 = 37
.line	1616	loadk        r16   k29 ; k29 = 113
.line	1616	loadk        r17   k51 ; k51 = 62
.line	1616	loadk        r18   k52 ; k52 = 87
.line	1616	loadk        r19   k53 ; k53 = 73
.line	1616	loadk        r20   k70 ; k70 = 40
.line	1616	loadk        r21   k71 ; k71 = 195
.line	1616	loadk        r22   k72 ; k72 = 77
.line	1616	loadk        r23    k7 ; k7 = 7
.line	1616	loadk        r24   k67 ; k67 = 16
.line	1616	loadk        r25   k73 ; k73 = 160
.line	1616	loadk        r26   k74 ; k74 = 71
.line	1616	loadk        r27   k75 ; k75 = 97
.line	1616	loadk        r28   k31 ; k31 = 11
.line	1616	loadk        r29   k76 ; k76 = 69
.line	1616	loadk        r30   k59 ; k59 = 135
.line	1616	loadk        r31   k77 ; k77 = 106
.line	1616	loadk        r32   k78 ; k78 = 111
.line	1616	loadk        r33   k79 ; k79 = 50
.line	1616	loadk        r34   k32 ; k32 = 30
.line	1616	loadk        r35   k67 ; k67 = 16
.line	1616	loadk        r36   k80 ; k80 = 8
.line	1616	loadk        r37   k81 ; k81 = 134
.line	1616	loadk        r38   k74 ; k74 = 71
.line	1616	loadk        r39   k62 ; k62 = 13
.line	1616	loadk        r40   k24 ; k24 = 25
.line	1616	loadk        r41   k82 ; k82 = 188
.line	1616	loadk        r42   k28 ; k28 = 122
.line	1616	loadk        r43   k83 ; k83 = 107
.line	1616	loadk        r44   k84 ; k84 = 12
.line	1616	call          r8    37     0
.line	1616	setlist       r6     0     1
.line	1616	call          r5     2     2
.label	l201
.line	1616	call          r4     2     1
.line	1616	move          r4    r3
.line	1616	loadnil       r5     0
.line	1616	call          r4     2     1
.line	1616	loadnil       r4     0
.line	1616	return        r4     2
.label	l207
.line	1616	gettabup      r4    u0   k85 ; k85 = "CustomAssetMgr"
.line	1616	eq             0    r4   k86 ; k86 = nil
.line	1616	jmp            0  l301
.line	1616	gettabup      r4    u0    k1 ; k1 = "print"
.line	1616	gettabup      r5    u0    k2 ; k2 = "bWriteLog"
.line	1616	test          r5     0
.line	1616	jmp            0  l295
.line	1616	gettabup      r5    u0    k3 ; k3 = "table"
.line	1616	gettable      r5    r5    k4 ; k4 = "concat"
.line	1616	newtable      r6     1     0
.line	1616	getupval      r7    u1
.line	1616	loadk         r8    k5 ; k5 = 126
.line	1616	loadk         r9    k6 ; k6 = 68
.line	1616	loadk        r10    k7 ; k7 = 7
.line	1616	loadk        r11    k8 ; k8 = 41
.line	1616	loadk        r12    k9 ; k9 = 164
.line	1616	loadk        r13   k10 ; k10 = 170
.line	1616	loadk        r14   k11 ; k11 = 39
.line	1616	loadk        r15   k12 ; k12 = 95
.line	1616	loadk        r16   k13 ; k13 = 24
.line	1616	loadk        r17   k14 ; k14 = 91
.line	1616	loadk        r18   k15 ; k15 = 26
.line	1616	loadk        r19   k16 ; k16 = 31
.line	1616	loadk        r20   k17 ; k17 = 217
.line	1616	loadk        r21   k18 ; k18 = 83
.line	1616	loadk        r22   k19 ; k19 = 38
.line	1616	loadk        r23   k20 ; k20 = 54
.line	1616	loadk        r24   k21 ; k21 = 137
.line	1616	loadk        r25   k22 ; k22 = 103
.line	1616	loadk        r26   k23 ; k23 = 102
.line	1616	loadk        r27   k24 ; k24 = 25
.line	1616	loadk        r28   k25 ; k25 = 99
.line	1616	loadk        r29   k26 ; k26 = 156
.line	1616	loadk        r30   k27 ; k27 = 76
.line	1616	loadk        r31   k28 ; k28 = 122
.line	1616	loadk        r32   k29 ; k29 = 113
.line	1616	loadk        r33   k30 ; k30 = 125
.line	1616	loadk        r34   k31 ; k31 = 11
.line	1616	loadk        r35   k32 ; k32 = 30
.line	1616	loadk        r36   k33 ; k33 = 199
.line	1616	loadk        r37   k34 ; k34 = 90
.line	1616	loadk        r38   k35 ; k35 = 6
.line	1616	loadk        r39   k36 ; k36 = 58
.line	1616	loadk        r40   k37 ; k37 = 144
.line	1616	loadk        r41   k38 ; k38 = 81
.line	1616	loadk        r42   k39 ; k39 = 64
.line	1616	loadk        r43   k40 ; k40 = 17
.line	1616	loadk        r44   k41 ; k41 = 115
.line	1616	loadk        r45   k42 ; k42 = 150
.line	1616	loadk        r46   k43 ; k43 = 66
.line	1616	loadk        r47   k44 ; k44 = 110
.line	1616	call          r7    41     2
.line	1616	getupval      r8    u1
.line	1616	loadk         r9   k45 ; k45 = 82
.line	1616	loadk        r10   k14 ; k14 = 91
.line	1616	loadk        r11   k46 ; k46 = 35
.line	1616	loadk        r12   k47 ; k47 = 59
.line	1616	loadk        r13   k48 ; k48 = 163
.line	1616	loadk        r14   k49 ; k49 = 166
.line	1616	loadk        r15   k50 ; k50 = 37
.line	1616	loadk        r16   k29 ; k29 = 113
.line	1616	loadk        r17   k51 ; k51 = 62
.line	1616	loadk        r18   k52 ; k52 = 87
.line	1616	loadk        r19   k53 ; k53 = 73
.line	1616	loadk        r20   k70 ; k70 = 40
.line	1616	loadk        r21   k71 ; k71 = 195
.line	1616	loadk        r22   k72 ; k72 = 77
.line	1616	loadk        r23    k7 ; k7 = 7
.line	1616	loadk        r24   k67 ; k67 = 16
.line	1616	loadk        r25   k73 ; k73 = 160
.line	1616	loadk        r26   k74 ; k74 = 71
.line	1616	loadk        r27   k75 ; k75 = 97
.line	1616	loadk        r28   k31 ; k31 = 11
.line	1616	loadk        r29   k76 ; k76 = 69
.line	1616	loadk        r30   k59 ; k59 = 135
.line	1616	loadk        r31   k87 ; k87 = 108
.line	1616	loadk        r32   k88 ; k88 = 109
.line	1616	loadk        r33   k61 ; k61 = 57
.line	1616	loadk        r34   k32 ; k32 = 30
.line	1616	loadk        r35   k67 ; k67 = 16
.line	1616	loadk        r36   k80 ; k80 = 8
.line	1616	loadk        r37   k81 ; k81 = 134
.line	1616	loadk        r38   k39 ; k39 = 64
.line	1616	loadk        r39   k89 ; k89 = 10
.line	1616	loadk        r40   k55 ; k55 = 3
.line	1616	call          r8    33     0
.line	1616	setlist       r6     0     1
.line	1616	call          r5     2     2
.label	l295
.line	1616	call          r4     2     1
.line	1616	move          r4    r3
.line	1616	loadnil       r5     0
.line	1616	call          r4     2     1
.line	1616	loadnil       r4     0
.line	1616	return        r4     2
.label	l301
.line	1616	gettable      r4    r0   k90 ; k90 = "_AsyncLoadSeq"
.line	1616	test          r4     1
.line	1616	jmp            0  l305
.line	1616	loadk         r4   k91 ; k91 = 0
.label	l305
.line	1616	add           r4    r4   k92 ; k92 = 1
.line	1616	settable      r0   k90    r4 ; k90 = "_AsyncLoadSeq"
.line	1616	gettable      r4    r0   k90 ; k90 = "_AsyncLoadSeq"
.line	1616	gettabup      r5    u0    k1 ; k1 = "print"
.line	1616	gettabup      r6    u0    k2 ; k2 = "bWriteLog"
.line	1616	test          r6     0
.line	1616	jmp            0  l377
.line	1616	gettabup      r6    u0    k3 ; k3 = "table"
.line	1616	gettable      r6    r6    k4 ; k4 = "concat"
.line	1616	newtable      r7     1     0
.line	1616	getupval      r8    u1
.line	1616	loadk         r9    k5 ; k5 = 126
.line	1616	loadk        r10    k6 ; k6 = 68
.line	1616	loadk        r11    k7 ; k7 = 7
.line	1616	loadk        r12    k8 ; k8 = 41
.line	1616	loadk        r13    k9 ; k9 = 164
.line	1616	loadk        r14   k10 ; k10 = 170
.line	1616	loadk        r15   k11 ; k11 = 39
.line	1616	loadk        r16   k12 ; k12 = 95
.line	1616	loadk        r17   k13 ; k13 = 24
.line	1616	loadk        r18   k14 ; k14 = 91
.line	1616	loadk        r19   k15 ; k15 = 26
.line	1616	loadk        r20   k16 ; k16 = 31
.line	1616	loadk        r21   k17 ; k17 = 217
.line	1616	loadk        r22   k18 ; k18 = 83
.line	1616	loadk        r23   k19 ; k19 = 38
.line	1616	loadk        r24   k20 ; k20 = 54
.line	1616	loadk        r25   k21 ; k21 = 137
.line	1616	loadk        r26   k22 ; k22 = 103
.line	1616	loadk        r27   k23 ; k23 = 102
.line	1616	loadk        r28   k24 ; k24 = 25
.line	1616	loadk        r29   k25 ; k25 = 99
.line	1616	loadk        r30   k26 ; k26 = 156
.line	1616	loadk        r31   k27 ; k27 = 76
.line	1616	loadk        r32   k28 ; k28 = 122
.line	1616	loadk        r33   k29 ; k29 = 113
.line	1616	loadk        r34   k30 ; k30 = 125
.line	1616	loadk        r35   k31 ; k31 = 11
.line	1616	loadk        r36   k32 ; k32 = 30
.line	1616	loadk        r37   k33 ; k33 = 199
.line	1616	loadk        r38   k34 ; k34 = 90
.line	1616	loadk        r39   k35 ; k35 = 6
.line	1616	loadk        r40   k36 ; k36 = 58
.line	1616	loadk        r41   k37 ; k37 = 144
.line	1616	loadk        r42   k38 ; k38 = 81
.line	1616	loadk        r43   k39 ; k39 = 64
.line	1616	loadk        r44   k40 ; k40 = 17
.line	1616	loadk        r45   k41 ; k41 = 115
.line	1616	loadk        r46   k42 ; k42 = 150
.line	1616	loadk        r47   k43 ; k43 = 66
.line	1616	loadk        r48   k44 ; k44 = 110
.line	1616	call          r8    41     2
.line	1616	getupval      r9    u1
.line	1616	loadk        r10   k45 ; k45 = 82
.line	1616	loadk        r11   k14 ; k14 = 91
.line	1616	loadk        r12   k46 ; k46 = 35
.line	1616	loadk        r13   k47 ; k47 = 59
.line	1616	loadk        r14   k48 ; k48 = 163
.line	1616	loadk        r15   k49 ; k49 = 166
.line	1616	loadk        r16   k50 ; k50 = 37
.line	1616	loadk        r17   k29 ; k29 = 113
.line	1616	loadk        r18   k51 ; k51 = 62
.line	1616	loadk        r19   k52 ; k52 = 87
.line	1616	loadk        r20   k53 ; k53 = 73
.line	1616	loadk        r21   k93 ; k93 = 9
.line	1616	loadk        r22   k94 ; k94 = 211
.line	1616	loadk        r23   k95 ; k95 = 89
.line	1616	loadk        r24   k15 ; k15 = 26
.line	1616	loadk        r25   k40 ; k40 = 17
.line	1616	call          r9    17     0
.line	1616	setlist       r7     0     1
.line	1616	call          r6     2     2
.label	l377
.line	1616	gettabup      r7    u0   k64 ; k64 = "tostring"
.line	1616	move          r8    r1
.line	1616	call          r7     2     2
.line	1616	getupval      r8    u1
.line	1616	loadk         r9   k96 ; k96 = 124
.line	1616	loadk        r10   k76 ; k76 = 69
.line	1616	loadk        r11   k97 ; k97 = 27
.line	1616	loadk        r12   k19 ; k19 = 38
.line	1616	loadk        r13   k98 ; k98 = 179
.line	1616	loadk        r14   k37 ; k37 = 144
.line	1616	loadk        r15   k99 ; k99 = 52
.line	1616	loadk        r16  k100 ; k100 = 75
.line	1616	loadk        r17   k75 ; k75 = 97
.line	1616	call          r8    10     2
.line	1616	gettabup      r9    u0   k64 ; k64 = "tostring"
.line	1616	move         r10    r4
.line	1616	call          r9     2     0
.line	1616	call          r5     0     1
.line	1616	self          r5    r0  k101 ; k101 = "_DownloadAndUnpackIn" (truncated)
.line	1616	move          r7    r1
.line	1616	move          r8    r4
.line	1616	closure       r9    f0
.line	1616	call          r5     5     1
.line	1616	return        r4     2
.line	1616	return        r0     1
.line	1616	move          r0    r0
.line	1616	move          r0    r0
.line	1616	move          r0    r0
.line	1616	return        r0     1

.function	main/f74/f0

.source	null
.linedefined	1635
.lastlinedefined	1638
.numparams	1
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	true
.upvalue	"U1"	1	true
.upvalue	"U2"	2	true
.upvalue	"U3"	3	true

.constant	k0	"_BuildAndSpawnUMGFromBinTable"

.line	1635	getupval      r1    u0
.line	1635	self          r1    r1    k0 ; k0 = "_BuildAndSpawnUMGFro" (truncated)
.line	1635	move          r3    r0
.line	1635	getupval      r4    u1
.line	1635	getupval      r5    u2
.line	1635	call          r1     5     2
.line	1635	getupval      r2    u3
.line	1635	move          r3    r1
.line	1635	call          r2     2     1
.line	1635	return        r0     1
.line	1635	move          r0    r0
.line	1635	move          r0    r0
.line	1635	move          r0    r0
.line	1635	move          r0    r0
.line	1635	return        r0     1

.function	main/f75

.source	null
.linedefined	1642
.lastlinedefined	1653
.numparams	1
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false

.constant	k0	0
.constant	k1	"pairs"
.constant	k2	"CustomUIData"
.constant	k3	"UMGCanvasInfo"
.constant	k4	"SortOrder"
.constant	k5	1

.line	1642	loadk         r1    k0 ; k0 = 0
.line	1642	gettabup      r2    u0    k1 ; k1 = "pairs"
.line	1642	gettable      r3    r0    k2 ; k2 = "CustomUIData"
.line	1642	call          r2     2     4
.line	1642	jmp            0   l19
.line	1642	test          r6     0
.line	1642	jmp            0   l19
.line	1642	gettable      r7    r6    k3 ; k3 = "UMGCanvasInfo"
.line	1642	test          r7     0
.line	1642	jmp            0   l19
.line	1642	gettable      r7    r6    k3 ; k3 = "UMGCanvasInfo"
.line	1642	gettable      r7    r7    k4 ; k4 = "SortOrder"
.line	1642	test          r7     1
.line	1642	jmp            0   l16
.line	1642	loadk         r7    k0 ; k0 = 0
.label	l16
.line	1642	lt             0    r1    r7
.line	1642	jmp            0   l19
.line	1642	move          r1    r7
.label	l19
.line	1642	move          r0    r0
.line	1642	move          r0    r0
.line	1642	add           r2    r1    k5 ; k5 = 1
.line	1642	return        r2     2
.line	1642	return        r0     1
.line	1642	move          r0    r0
.line	1642	move          r0    r0
.line	1642	return        r0     1

.function	main/f76

.source	null
.linedefined	1655
.lastlinedefined	1734
.numparams	4
.is_vararg	0
.maxstacksize	64

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	3	true

.constant	k0	"type"
.constant	k1	73
.constant	k2	87
.constant	k3	0
.constant	k4	36
.constant	k5	181
.constant	k6	"next"
.constant	k7	nil
.constant	k8	"print"
.constant	k9	"bWriteLog"
.constant	k10	"table"
.constant	k11	"concat"
.constant	k12	126
.constant	k13	68
.constant	k14	7
.constant	k15	41
.constant	k16	164
.constant	k17	170
.constant	k18	39
.constant	k19	95
.constant	k20	24
.constant	k21	91
.constant	k22	26
.constant	k23	31
.constant	k24	217
.constant	k25	83
.constant	k26	38
.constant	k27	54
.constant	k28	137
.constant	k29	103
.constant	k30	102
.constant	k31	25
.constant	k32	99
.constant	k33	156
.constant	k34	76
.constant	k35	122
.constant	k36	113
.constant	k37	97
.constant	k38	59
.constant	k39	14
.constant	k40	207
.constant	k41	66
.constant	k42	43
.constant	k43	120
.constant	k44	5
.constant	k45	89
.constant	k46	128
.constant	k47	114
.constant	k48	123
.constant	k49	64
.constant	k50	3
.constant	k51	150
.constant	k52	177
.constant	k53	62
.constant	k54	71
.constant	k55	63
.constant	k56	215
.constant	k57	92
.constant	k58	237
.constant	k59	127
.constant	k60	8
.constant	k61	84
.constant	k62	138
.constant	k63	1
.constant	k64	72
.constant	k65	34
.constant	k66	80
.constant	k67	45
.constant	k68	196
.constant	k69	6
.constant	k70	"tostring"
.constant	k71	"GetOwner"
.constant	k72	"slua"
.constant	k73	"isValid"
.constant	k74	"GetInstanceManager"
.constant	k75	"pairs"
.constant	k76	"GetObjectValue"
.constant	k77	179
.constant	k78	183
.constant	k79	22
.constant	k80	52
.constant	k81	69
.constant	k82	245
.constant	k83	86
.constant	k84	19
.constant	k85	169
.constant	k86	116
.constant	k87	119
.constant	k88	true
.constant	k89	"CustomUIBase"
.constant	k90	104
.constant	k91	125
.constant	k92	88
.constant	k93	154
.constant	k94	109
.constant	k95	46
.constant	k96	74
.constant	k97	18
.constant	k98	200
.constant	k99	33
.constant	k100	10
.constant	k101	134
.constant	k102	"GetGameCanvasSize"
.constant	k103	"X"
.constant	k104	"Y"
.constant	k105	"Width"
.constant	k106	"Height"
.constant	k107	"require"
.constant	k108	15
.constant	k109	182
.constant	k110	48
.constant	k111	20
.constant	k112	65
.constant	k113	13
.constant	k114	30
.constant	k115	185
.constant	k116	111
.constant	k117	100
.constant	k118	29
.constant	k119	98
.constant	k120	146
.constant	k121	82
.constant	k122	101
.constant	k123	21
.constant	k124	195
.constant	k125	23
.constant	k126	158
.constant	k127	9
.constant	k128	67
.constant	k129	17
.constant	k130	60
.constant	k131	191
.constant	k132	174
.constant	k133	4
.constant	k134	115
.constant	k135	117
.constant	k136	28
.constant	k137	194
.constant	k138	81
.constant	k139	42
.constant	k140	132
.constant	k141	118
.constant	k142	135
.constant	k143	56
.constant	k144	199
.constant	k145	"CalculateWidgetGroupBoundingBox"
.constant	k146	"math"
.constant	k147	"max"
.constant	k148	"ceil"
.constant	k149	"string"
.constant	k150	"format"
.constant	k151	211
.constant	k152	55
.constant	k153	110
.constant	k154	77
.constant	k155	51
.constant	k156	155
.constant	k157	11
.constant	k158	16
.constant	k159	79
.constant	k160	85
.constant	k161	151
.constant	k162	176
.constant	k163	40
.constant	k164	75
.constant	k165	240
.constant	k166	35
.constant	k167	157
.constant	k168	121
.constant	k169	94
.constant	k170	133
.constant	k171	216
.constant	k172	168
.constant	k173	226
.constant	k174	"MakeHashByFNV1a32"
.constant	k175	12
.constant	k176	153
.constant	k177	"InstanceId"
.constant	k178	"AssetId"
.constant	k179	5200001
.constant	k180	"AssetCategory"
.constant	k181	"E_AssetType"
.constant	k182	"UMGInfo"
.constant	k183	"UMGCanvasInfo"
.constant	k184	"CanvasName"
.constant	k185	"CanvasType"
.constant	k186	"UMGCanvasType"
.constant	k187	"Dynamic"
.constant	k188	"Visible"
.constant	k189	"EditModeVisible"
.constant	k190	"CanvasWidth"
.constant	k191	"CanvasHeight"
.constant	k192	"SortOrder"
.constant	k193	"_GetTopCanvasSortOrder"
.constant	k194	"CDOInstanceID"
.constant	k195	"AllWidgets"
.constant	k196	"overrides"
.constant	k197	"Tag"
.constant	k198	"ObjectGroup"
.constant	k199	"Children"
.constant	k200	"CanvasID"

.line	1655	gettabup      r4    u0    k0 ; k0 = "type"
.line	1655	move          r5    r1
.line	1655	call          r4     2     2
.line	1655	getupval      r5    u1
.line	1655	loadk         r6    k1 ; k1 = 73
.line	1655	loadk         r7    k2 ; k2 = 87
.line	1655	loadk         r8    k3 ; k3 = 0
.line	1655	loadk         r9    k4 ; k4 = 36
.line	1655	loadk        r10    k5 ; k5 = 181
.line	1655	call          r5     6     2
.line	1655	eq             0    r4    r5
.line	1655	jmp            0   l18
.line	1655	gettabup      r4    u0    k6 ; k6 = "next"
.line	1655	move          r5    r1
.line	1655	call          r4     2     2
.line	1655	eq             0    r4    k7 ; k7 = nil
.line	1655	jmp            0  l108
.label	l18
.line	1655	gettabup      r4    u0    k8 ; k8 = "print"
.line	1655	gettabup      r5    u0    k9 ; k9 = "bWriteLog"
.line	1655	test          r5     0
.line	1655	jmp            0  l102
.line	1655	gettabup      r5    u0   k10 ; k10 = "table"
.line	1655	gettable      r5    r5   k11 ; k11 = "concat"
.line	1655	newtable      r6     1     0
.line	1655	getupval      r7    u1
.line	1655	loadk         r8   k12 ; k12 = 126
.line	1655	loadk         r9   k13 ; k13 = 68
.line	1655	loadk        r10   k14 ; k14 = 7
.line	1655	loadk        r11   k15 ; k15 = 41
.line	1655	loadk        r12   k16 ; k16 = 164
.line	1655	loadk        r13   k17 ; k17 = 170
.line	1655	loadk        r14   k18 ; k18 = 39
.line	1655	loadk        r15   k19 ; k19 = 95
.line	1655	loadk        r16   k20 ; k20 = 24
.line	1655	loadk        r17   k21 ; k21 = 91
.line	1655	loadk        r18   k22 ; k22 = 26
.line	1655	loadk        r19   k23 ; k23 = 31
.line	1655	loadk        r20   k24 ; k24 = 217
.line	1655	loadk        r21   k25 ; k25 = 83
.line	1655	loadk        r22   k26 ; k26 = 38
.line	1655	loadk        r23   k27 ; k27 = 54
.line	1655	loadk        r24   k28 ; k28 = 137
.line	1655	loadk        r25   k29 ; k29 = 103
.line	1655	loadk        r26   k30 ; k30 = 102
.line	1655	loadk        r27   k31 ; k31 = 25
.line	1655	loadk        r28   k32 ; k32 = 99
.line	1655	loadk        r29   k33 ; k33 = 156
.line	1655	loadk        r30   k34 ; k34 = 76
.line	1655	loadk        r31   k35 ; k35 = 122
.line	1655	loadk        r32   k36 ; k36 = 113
.line	1655	loadk        r33   k37 ; k37 = 97
.line	1655	loadk        r34   k38 ; k38 = 59
.line	1655	loadk        r35   k39 ; k39 = 14
.line	1655	loadk        r36   k40 ; k40 = 207
.line	1655	loadk        r37   k41 ; k41 = 66
.line	1655	loadk        r38   k14 ; k14 = 7
.line	1655	loadk        r39   k42 ; k42 = 43
.line	1655	loadk        r40   k16 ; k16 = 164
.line	1655	loadk        r41   k43 ; k43 = 120
.line	1655	loadk        r42   k32 ; k32 = 99
.line	1655	loadk        r43   k44 ; k44 = 5
.line	1655	loadk        r44   k45 ; k45 = 89
.line	1655	loadk        r45   k46 ; k46 = 128
.line	1655	loadk        r46   k47 ; k47 = 114
.line	1655	loadk        r47   k48 ; k48 = 123
.line	1655	call          r7    41     2
.line	1655	getupval      r8    u1
.line	1655	loadk         r9   k25 ; k25 = 83
.line	1655	loadk        r10   k49 ; k49 = 64
.line	1655	loadk        r11   k50 ; k50 = 3
.line	1655	loadk        r12   k38 ; k38 = 59
.line	1655	loadk        r13   k51 ; k51 = 150
.line	1655	loadk        r14   k52 ; k52 = 177
.line	1655	loadk        r15   k53 ; k53 = 62
.line	1655	loadk        r16    k2 ; k2 = 87
.line	1655	loadk        r17   k31 ; k31 = 25
.line	1655	loadk        r18   k54 ; k54 = 71
.line	1655	loadk        r19   k14 ; k14 = 7
.line	1655	loadk        r20   k55 ; k55 = 63
.line	1655	loadk        r21   k56 ; k56 = 215
.line	1655	loadk        r22   k57 ; k57 = 92
.line	1655	loadk        r23   k23 ; k23 = 31
.line	1655	loadk        r24   k22 ; k22 = 26
.line	1655	loadk        r25   k58 ; k58 = 237
.line	1655	loadk        r26   k32 ; k32 = 99
.line	1655	loadk        r27   k59 ; k59 = 127
.line	1655	loadk        r28   k60 ; k60 = 8
.line	1655	loadk        r29   k61 ; k61 = 84
.line	1655	loadk        r30   k62 ; k62 = 138
.line	1655	loadk        r31   k63 ; k63 = 1
.line	1655	loadk        r32   k64 ; k64 = 72
.line	1655	loadk        r33   k65 ; k65 = 34
.line	1655	loadk        r34   k66 ; k66 = 80
.line	1655	loadk        r35   k67 ; k67 = 45
.line	1655	loadk        r36   k22 ; k22 = 26
.line	1655	loadk        r37   k68 ; k68 = 196
.line	1655	loadk        r38   k41 ; k41 = 66
.line	1655	loadk        r39   k69 ; k69 = 6
.line	1655	call          r8    32     0
.line	1655	setlist       r6     0     1
.line	1655	call          r5     2     2
.label	l102
.line	1655	gettabup      r6    u0   k70 ; k70 = "tostring"
.line	1655	move          r7    r2
.line	1655	call          r6     2     0
.line	1655	call          r4     0     1
.line	1655	loadnil       r4     0
.line	1655	return        r4     2
.label	l108
.line	1655	self          r4    r0   k71 ; k71 = "GetOwner"
.line	1655	call          r4     2     2
.line	1655	gettabup      r5    u0   k72 ; k72 = "slua"
.line	1655	gettable      r5    r5   k73 ; k73 = "isValid"
.line	1655	move          r6    r4
.line	1655	call          r5     2     2
.line	1655	test          r5     1
.line	1655	jmp            0  l118
.line	1655	loadnil       r5     0
.line	1655	return        r5     2
.label	l118
.line	1655	gettabup      r5    u0   k74 ; k74 = "GetInstanceManager"
.line	1655	call          r5     1     2
.line	1655	newtable      r6     0     0
.line	1655	test          r5     0
.line	1655	jmp            0  l164
.line	1655	gettabup      r7    u0   k75 ; k75 = "pairs"
.line	1655	move          r8    r1
.line	1655	call          r7     2     4
.line	1655	jmp            0  l162
.line	1655	self         r12    r5   k76 ; k76 = "GetObjectValue"
.line	1655	loadnil      r14     0
.line	1655	getupval     r15    u1
.line	1655	loadk        r16   k47 ; k47 = 114
.line	1655	loadk        r17   k61 ; k61 = 84
.line	1655	loadk        r18   k60 ; k60 = 8
.line	1655	loadk        r19   k67 ; k67 = 45
.line	1655	loadk        r20   k77 ; k77 = 179
.line	1655	loadk        r21   k78 ; k78 = 183
.line	1655	loadk        r22   k79 ; k79 = 22
.line	1655	loadk        r23   k64 ; k64 = 72
.line	1655	loadk        r24   k80 ; k80 = 52
.line	1655	loadk        r25   k21 ; k21 = 91
.line	1655	loadk        r26   k31 ; k31 = 25
.line	1655	loadk        r27   k81 ; k81 = 69
.line	1655	loadk        r28   k82 ; k82 = 245
.line	1655	loadk        r29   k83 ; k83 = 86
.line	1655	loadk        r30   k22 ; k22 = 26
.line	1655	loadk        r31   k84 ; k84 = 19
.line	1655	loadk        r32   k85 ; k85 = 169
.line	1655	loadk        r33   k86 ; k86 = 116
.line	1655	loadk        r34   k87 ; k87 = 119
.line	1655	loadk        r35   k79 ; k79 = 22
.line	1655	call         r15    21     2
.line	1655	move         r16   r11
.line	1655	call         r12     5     2
.line	1655	test         r12     0
.line	1655	jmp            0  l162
.line	1655	loadk        r13   k63 ; k63 = 1
.line	1655	len          r14   r12
.line	1655	loadk        r15   k63 ; k63 = 1
.line	1655	move          r0    r0
.line	1655	gettable     r17   r12   r16
.line	1655	settable      r6   r17   k88 ; k88 = true
.line	1655	move          r0    r0
.label	l162
.line	1655	move          r0    r0
.line	1655	move          r0    r0
.label	l164
.line	1655	newtable      r7     0     0
.line	1655	newtable      r8     0     0
.line	1655	gettabup      r9    u0   k75 ; k75 = "pairs"
.line	1655	move         r10    r1
.line	1655	call          r9     2     4
.line	1655	jmp            0  l184
.line	1655	test         r13     0
.line	1655	jmp            0  l184
.line	1655	gettable     r14   r13   k89 ; k89 = "CustomUIBase"
.line	1655	test         r14     0
.line	1655	jmp            0  l184
.line	1655	len          r14    r7
.line	1655	add          r14   r14   k63 ; k63 = 1
.line	1655	settable      r7   r14   r12
.line	1655	gettable     r14    r6   r12
.line	1655	test         r14     1
.line	1655	jmp            0  l184
.line	1655	len          r14    r8
.line	1655	add          r14   r14   k63 ; k63 = 1
.line	1655	settable      r8   r14   r12
.label	l184
.line	1655	move          r0    r0
.line	1655	move          r0    r0
.line	1655	len           r9    r7
.line	1655	eq             0    r9    k3 ; k3 = 0
.line	1655	jmp            0  l286
.line	1655	gettabup      r9    u0    k8 ; k8 = "print"
.line	1655	gettabup     r10    u0    k9 ; k9 = "bWriteLog"
.line	1655	test         r10     0
.line	1655	jmp            0  l280
.line	1655	gettabup     r10    u0   k10 ; k10 = "table"
.line	1655	gettable     r10   r10   k11 ; k11 = "concat"
.line	1655	newtable     r11     1     0
.line	1655	getupval     r12    u1
.line	1655	loadk        r13   k12 ; k12 = 126
.line	1655	loadk        r14   k13 ; k13 = 68
.line	1655	loadk        r15   k14 ; k14 = 7
.line	1655	loadk        r16   k15 ; k15 = 41
.line	1655	loadk        r17   k16 ; k16 = 164
.line	1655	loadk        r18   k17 ; k17 = 170
.line	1655	loadk        r19   k18 ; k18 = 39
.line	1655	loadk        r20   k19 ; k19 = 95
.line	1655	loadk        r21   k20 ; k20 = 24
.line	1655	loadk        r22   k21 ; k21 = 91
.line	1655	loadk        r23   k22 ; k22 = 26
.line	1655	loadk        r24   k23 ; k23 = 31
.line	1655	loadk        r25   k24 ; k24 = 217
.line	1655	loadk        r26   k25 ; k25 = 83
.line	1655	loadk        r27   k26 ; k26 = 38
.line	1655	loadk        r28   k27 ; k27 = 54
.line	1655	loadk        r29   k28 ; k28 = 137
.line	1655	loadk        r30   k29 ; k29 = 103
.line	1655	loadk        r31   k30 ; k30 = 102
.line	1655	loadk        r32   k31 ; k31 = 25
.line	1655	loadk        r33   k32 ; k32 = 99
.line	1655	loadk        r34   k33 ; k33 = 156
.line	1655	loadk        r35   k34 ; k34 = 76
.line	1655	loadk        r36   k35 ; k35 = 122
.line	1655	loadk        r37   k36 ; k36 = 113
.line	1655	loadk        r38   k37 ; k37 = 97
.line	1655	loadk        r39   k38 ; k38 = 59
.line	1655	loadk        r40   k39 ; k39 = 14
.line	1655	loadk        r41   k40 ; k40 = 207
.line	1655	loadk        r42   k41 ; k41 = 66
.line	1655	loadk        r43   k14 ; k14 = 7
.line	1655	loadk        r44   k42 ; k42 = 43
.line	1655	loadk        r45   k16 ; k16 = 164
.line	1655	loadk        r46   k43 ; k43 = 120
.line	1655	loadk        r47   k32 ; k32 = 99
.line	1655	loadk        r48   k44 ; k44 = 5
.line	1655	loadk        r49   k45 ; k45 = 89
.line	1655	loadk        r50   k46 ; k46 = 128
.line	1655	loadk        r51   k47 ; k47 = 114
.line	1655	loadk        r52   k48 ; k48 = 123
.line	1655	call         r12    41     2
.line	1655	getupval     r13    u1
.line	1655	loadk        r14   k25 ; k25 = 83
.line	1655	loadk        r15   k49 ; k49 = 64
.line	1655	loadk        r16   k50 ; k50 = 3
.line	1655	loadk        r17   k38 ; k38 = 59
.line	1655	loadk        r18   k51 ; k51 = 150
.line	1655	loadk        r19   k52 ; k52 = 177
.line	1655	loadk        r20   k53 ; k53 = 62
.line	1655	loadk        r21    k2 ; k2 = 87
.line	1655	loadk        r22   k31 ; k31 = 25
.line	1655	loadk        r23   k54 ; k54 = 71
.line	1655	loadk        r24   k14 ; k14 = 7
.line	1655	loadk        r25   k55 ; k55 = 63
.line	1655	loadk        r26   k56 ; k56 = 215
.line	1655	loadk        r27   k57 ; k57 = 92
.line	1655	loadk        r28   k23 ; k23 = 31
.line	1655	loadk        r29   k22 ; k22 = 26
.line	1655	loadk        r30   k58 ; k58 = 237
.line	1655	loadk        r31   k90 ; k90 = 104
.line	1655	loadk        r32   k91 ; k91 = 125
.line	1655	loadk        r33   k92 ; k92 = 88
.line	1655	loadk        r34    k2 ; k2 = 87
.line	1655	loadk        r35   k93 ; k93 = 154
.line	1655	loadk        r36   k81 ; k81 = 69
.line	1655	loadk        r37   k94 ; k94 = 109
.line	1655	loadk        r38   k95 ; k95 = 46
.line	1655	loadk        r39   k96 ; k96 = 74
.line	1655	loadk        r40   k45 ; k45 = 89
.line	1655	loadk        r41   k97 ; k97 = 18
.line	1655	loadk        r42   k98 ; k98 = 200
.line	1655	loadk        r43   k39 ; k39 = 14
.line	1655	loadk        r44   k99 ; k99 = 33
.line	1655	loadk        r45   k69 ; k69 = 6
.line	1655	loadk        r46   k77 ; k77 = 179
.line	1655	loadk        r47   k41 ; k41 = 66
.line	1655	loadk        r48   k32 ; k32 = 99
.line	1655	loadk        r49  k100 ; k100 = 10
.line	1655	loadk        r50   k57 ; k57 = 92
.line	1655	loadk        r51  k101 ; k101 = 134
.line	1655	call         r13    39     0
.line	1655	setlist      r11     0     1
.line	1655	call         r10     2     2
.label	l280
.line	1655	gettabup     r11    u0   k70 ; k70 = "tostring"
.line	1655	move         r12    r2
.line	1655	call         r11     2     0
.line	1655	call          r9     0     1
.line	1655	loadnil       r9     0
.line	1655	return        r9     2
.label	l286
.line	1655	self          r9    r0  k102 ; k102 = "GetGameCanvasSize"
.line	1655	call          r9     2     2
.line	1655	newtable     r10     0     4
.line	1655	settable     r10  k103    k3 ; k3 = 0
.line	1655	settable     r10  k104    k3 ; k3 = 0
.line	1655	gettable     r11    r9  k103 ; k103 = "X"
.line	1655	settable     r10  k105   r11 ; k105 = "Width"
.line	1655	gettable     r11    r9  k104 ; k104 = "Y"
.line	1655	settable     r10  k106   r11 ; k106 = "Height"
.line	1655	gettabup     r11    u0  k107 ; k107 = "require"
.line	1655	gettabup     r12    u0   k10 ; k10 = "table"
.line	1655	gettable     r12   r12   k11 ; k11 = "concat"
.line	1655	newtable     r13     1     0
.line	1655	getupval     r14    u1
.line	1655	loadk        r15   k35 ; k35 = 122
.line	1655	loadk        r16    k2 ; k2 = 87
.line	1655	loadk        r17  k108 ; k108 = 15
.line	1655	loadk        r18   k67 ; k67 = 45
.line	1655	loadk        r19   k33 ; k33 = 156
.line	1655	loadk        r20  k109 ; k109 = 182
.line	1655	loadk        r21  k110 ; k110 = 48
.line	1655	loadk        r22  k111 ; k111 = 20
.line	1655	loadk        r23   k79 ; k79 = 22
.line	1655	loadk        r24  k112 ; k112 = 65
.line	1655	loadk        r25  k113 ; k113 = 13
.line	1655	loadk        r26   k81 ; k81 = 69
.line	1655	loadk        r27   k82 ; k82 = 245
.line	1655	loadk        r28   k34 ; k34 = 76
.line	1655	loadk        r29   k79 ; k79 = 22
.line	1655	loadk        r30  k114 ; k114 = 30
.line	1655	loadk        r31  k115 ; k115 = 185
.line	1655	loadk        r32  k116 ; k116 = 111
.line	1655	loadk        r33  k117 ; k117 = 100
.line	1655	loadk        r34  k118 ; k118 = 29
.line	1655	loadk        r35  k119 ; k119 = 98
.line	1655	loadk        r36  k120 ; k120 = 146
.line	1655	loadk        r37  k121 ; k121 = 82
.line	1655	loadk        r38  k116 ; k116 = 111
.line	1655	loadk        r39  k122 ; k122 = 101
.line	1655	loadk        r40   k91 ; k91 = 125
.line	1655	loadk        r41  k123 ; k123 = 21
.line	1655	loadk        r42   k97 ; k97 = 18
.line	1655	loadk        r43  k124 ; k124 = 195
.line	1655	loadk        r44   k49 ; k49 = 64
.line	1655	loadk        r45  k125 ; k125 = 23
.line	1655	loadk        r46  k112 ; k112 = 65
.line	1655	loadk        r47  k126 ; k126 = 158
.line	1655	loadk        r48  k117 ; k117 = 100
.line	1655	loadk        r49   k29 ; k29 = 103
.line	1655	loadk        r50  k127 ; k127 = 9
.line	1655	loadk        r51   k13 ; k13 = 68
.line	1655	loadk        r52   k62 ; k62 = 138
.line	1655	loadk        r53   k54 ; k54 = 71
.line	1655	loadk        r54   k59 ; k59 = 127
.line	1655	call         r14    41     2
.line	1655	getupval     r15    u1
.line	1655	loadk        r16   k12 ; k12 = 126
.line	1655	loadk        r17  k128 ; k128 = 67
.line	1655	loadk        r18  k129 ; k129 = 17
.line	1655	loadk        r19  k130 ; k130 = 60
.line	1655	loadk        r20  k131 ; k131 = 191
.line	1655	loadk        r21  k132 ; k132 = 174
.line	1655	loadk        r22  k133 ; k133 = 4
.line	1655	loadk        r23  k134 ; k134 = 115
.line	1655	loadk        r24  k135 ; k135 = 117
.line	1655	loadk        r25   k94 ; k94 = 109
.line	1655	loadk        r26  k136 ; k136 = 28
.line	1655	loadk        r27   k20 ; k20 = 24
.line	1655	loadk        r28  k137 ; k137 = 194
.line	1655	loadk        r29  k138 ; k138 = 81
.line	1655	loadk        r30  k114 ; k114 = 30
.line	1655	loadk        r31  k139 ; k139 = 42
.line	1655	loadk        r32  k140 ; k140 = 132
.line	1655	loadk        r33   k54 ; k54 = 71
.line	1655	loadk        r34  k141 ; k141 = 118
.line	1655	loadk        r35   k31 ; k31 = 25
.line	1655	loadk        r36   k66 ; k66 = 80
.line	1655	loadk        r37  k142 ; k142 = 135
.line	1655	loadk        r38   k49 ; k49 = 64
.line	1655	loadk        r39   k12 ; k12 = 126
.line	1655	loadk        r40   k65 ; k65 = 34
.line	1655	loadk        r41  k138 ; k138 = 81
.line	1655	loadk        r42  k125 ; k125 = 23
.line	1655	loadk        r43  k143 ; k143 = 56
.line	1655	loadk        r44  k144 ; k144 = 199
.line	1655	loadk        r45   k41 ; k41 = 66
.line	1655	loadk        r46    k3 ; k3 = 0
.line	1655	loadk        r47   k22 ; k22 = 26
.line	1655	loadk        r48   k52 ; k52 = 177
.line	1655	loadk        r49   k87 ; k87 = 119
.line	1655	loadk        r50  k141 ; k141 = 118
.line	1655	loadk        r51   k14 ; k14 = 7
.line	1655	loadk        r52   k41 ; k41 = 66
.line	1655	call         r15    38     0
.line	1655	setlist      r13     0     1
.line	1655	call         r12     2     2
.line	1655	call         r11     2     2
.line	1655	gettable     r12   r11  k145 ; k145 = "CalculateWidgetGroup" (truncated)
.line	1655	move         r13    r1
.line	1655	move         r14   r10
.line	1655	call         r12     3     5
.line	1655	gettabup     r16    u0  k146 ; k146 = "math"
.line	1655	gettable     r16   r16  k147 ; k147 = "max"
.line	1655	loadk        r17   k63 ; k63 = 1
.line	1655	gettabup     r18    u0  k146 ; k146 = "math"
.line	1655	gettable     r18   r18  k148 ; k148 = "ceil"
.line	1655	sub          r19   r14   r12
.line	1655	call         r18     2     0
.line	1655	call         r16     0     2
.line	1655	gettabup     r17    u0  k146 ; k146 = "math"
.line	1655	gettable     r17   r17  k147 ; k147 = "max"
.line	1655	loadk        r18   k63 ; k63 = 1
.line	1655	gettabup     r19    u0  k146 ; k146 = "math"
.line	1655	gettable     r19   r19  k148 ; k148 = "ceil"
.line	1655	sub          r20   r15   r13
.line	1655	call         r19     2     0
.line	1655	call         r17     0     2
.line	1655	gettabup     r18    u0    k8 ; k8 = "print"
.line	1655	gettabup     r19    u0    k9 ; k9 = "bWriteLog"
.line	1655	test         r19     0
.line	1655	jmp            0  l532
.line	1655	gettabup     r19    u0  k149 ; k149 = "string"
.line	1655	gettable     r19   r19  k150 ; k150 = "format"
.line	1655	gettabup     r20    u0   k10 ; k10 = "table"
.line	1655	gettable     r20   r20   k11 ; k11 = "concat"
.line	1655	newtable     r21     2     0
.line	1655	getupval     r22    u1
.line	1655	loadk        r23   k12 ; k12 = 126
.line	1655	loadk        r24   k13 ; k13 = 68
.line	1655	loadk        r25   k14 ; k14 = 7
.line	1655	loadk        r26   k15 ; k15 = 41
.line	1655	loadk        r27   k16 ; k16 = 164
.line	1655	loadk        r28   k17 ; k17 = 170
.line	1655	loadk        r29   k18 ; k18 = 39
.line	1655	loadk        r30   k19 ; k19 = 95
.line	1655	loadk        r31   k20 ; k20 = 24
.line	1655	loadk        r32   k21 ; k21 = 91
.line	1655	loadk        r33   k22 ; k22 = 26
.line	1655	loadk        r34   k23 ; k23 = 31
.line	1655	loadk        r35   k24 ; k24 = 217
.line	1655	loadk        r36   k25 ; k25 = 83
.line	1655	loadk        r37   k26 ; k26 = 38
.line	1655	loadk        r38   k27 ; k27 = 54
.line	1655	loadk        r39   k28 ; k28 = 137
.line	1655	loadk        r40   k29 ; k29 = 103
.line	1655	loadk        r41   k30 ; k30 = 102
.line	1655	loadk        r42   k31 ; k31 = 25
.line	1655	loadk        r43   k32 ; k32 = 99
.line	1655	loadk        r44   k33 ; k33 = 156
.line	1655	loadk        r45   k34 ; k34 = 76
.line	1655	loadk        r46   k35 ; k35 = 122
.line	1655	loadk        r47   k36 ; k36 = 113
.line	1655	loadk        r48   k37 ; k37 = 97
.line	1655	loadk        r49   k38 ; k38 = 59
.line	1655	loadk        r50   k39 ; k39 = 14
.line	1655	loadk        r51   k40 ; k40 = 207
.line	1655	loadk        r52   k41 ; k41 = 66
.line	1655	loadk        r53   k14 ; k14 = 7
.line	1655	loadk        r54   k42 ; k42 = 43
.line	1655	loadk        r55   k16 ; k16 = 164
.line	1655	loadk        r56   k43 ; k43 = 120
.line	1655	loadk        r57   k32 ; k32 = 99
.line	1655	loadk        r58   k44 ; k44 = 5
.line	1655	loadk        r59   k45 ; k45 = 89
.line	1655	loadk        r60   k46 ; k46 = 128
.line	1655	loadk        r61   k47 ; k47 = 114
.line	1655	loadk        r62   k48 ; k48 = 123
.line	1655	call         r22    41     2
.line	1655	getupval     r23    u1
.line	1655	loadk        r24   k25 ; k25 = 83
.line	1655	loadk        r25   k49 ; k49 = 64
.line	1655	loadk        r26   k50 ; k50 = 3
.line	1655	loadk        r27   k38 ; k38 = 59
.line	1655	loadk        r28   k51 ; k51 = 150
.line	1655	loadk        r29   k52 ; k52 = 177
.line	1655	loadk        r30   k53 ; k53 = 62
.line	1655	loadk        r31    k2 ; k2 = 87
.line	1655	loadk        r32   k31 ; k31 = 25
.line	1655	loadk        r33   k54 ; k54 = 71
.line	1655	loadk        r34   k14 ; k14 = 7
.line	1655	loadk        r35   k55 ; k55 = 63
.line	1655	loadk        r36   k56 ; k56 = 215
.line	1655	loadk        r37   k57 ; k57 = 92
.line	1655	loadk        r38   k23 ; k23 = 31
.line	1655	loadk        r39   k22 ; k22 = 26
.line	1655	loadk        r40   k58 ; k58 = 237
.line	1655	loadk        r41   k13 ; k13 = 68
.line	1655	loadk        r42   k66 ; k66 = 80
.line	1655	loadk        r43  k125 ; k125 = 23
.line	1655	loadk        r44   k92 ; k92 = 88
.line	1655	loadk        r45  k151 ; k151 = 211
.line	1655	loadk        r46  k141 ; k141 = 118
.line	1655	loadk        r47  k152 ; k152 = 55
.line	1655	loadk        r48  k153 ; k153 = 110
.line	1655	loadk        r49  k154 ; k154 = 77
.line	1655	loadk        r50   k45 ; k45 = 89
.line	1655	loadk        r51  k155 ; k155 = 51
.line	1655	loadk        r52  k156 ; k156 = 155
.line	1655	loadk        r53  k157 ; k157 = 11
.line	1655	loadk        r54  k158 ; k158 = 16
.line	1655	loadk        r55  k159 ; k159 = 79
.line	1655	loadk        r56   k62 ; k62 = 138
.line	1655	loadk        r57   k59 ; k59 = 127
.line	1655	loadk        r58   k30 ; k30 = 102
.line	1655	loadk        r59  k108 ; k108 = 15
.line	1655	loadk        r60  k160 ; k160 = 85
.line	1655	loadk        r61  k161 ; k161 = 151
.line	1655	loadk        r62   k47 ; k47 = 114
.line	1655	loadk        r63  k135 ; k135 = 117
.line	1655	call         r23    41     2
.line	1655	getupval     r24    u1
.line	1655	loadk        r25   k64 ; k64 = 72
.line	1655	loadk        r26   k92 ; k92 = 88
.line	1655	loadk        r27   k79 ; k79 = 22
.line	1655	loadk        r28  k135 ; k135 = 117
.line	1655	loadk        r29   k82 ; k82 = 245
.line	1655	loadk        r30  k162 ; k162 = 176
.line	1655	loadk        r31   k36 ; k36 = 113
.line	1655	loadk        r32   k90 ; k90 = 104
.line	1655	loadk        r33   k80 ; k80 = 52
.line	1655	loadk        r34  k112 ; k112 = 65
.line	1655	loadk        r35  k118 ; k118 = 29
.line	1655	loadk        r36  k163 ; k163 = 40
.line	1655	loadk        r37   k24 ; k24 = 217
.line	1655	loadk        r38  k164 ; k164 = 75
.line	1655	loadk        r39  k118 ; k118 = 29
.line	1655	loadk        r40  k157 ; k157 = 11
.line	1655	loadk        r41  k165 ; k165 = 240
.line	1655	loadk        r42  k166 ; k166 = 35
.line	1655	loadk        r43   k37 ; k37 = 97
.line	1655	call         r24    20     0
.line	1655	setlist      r21     0     1
.line	1655	call         r20     2     2
.line	1655	gettabup     r21    u0   k70 ; k70 = "tostring"
.line	1655	move         r22   r16
.line	1655	call         r21     2     2
.line	1655	gettabup     r22    u0   k70 ; k70 = "tostring"
.line	1655	move         r23   r17
.line	1655	call         r22     2     2
.line	1655	gettabup     r23    u0   k70 ; k70 = "tostring"
.line	1655	len          r24    r7
.line	1655	call         r23     2     2
.line	1655	gettabup     r24    u0   k70 ; k70 = "tostring"
.line	1655	len          r25    r8
.line	1655	call         r24     2     0
.line	1655	call         r19     0     2
.label	l532
.line	1655	call         r18     2     1
.line	1655	gettabup     r18    u0  k107 ; k107 = "require"
.line	1655	gettabup     r19    u0   k10 ; k10 = "table"
.line	1655	gettable     r19   r19   k11 ; k11 = "concat"
.line	1655	newtable     r20     1     0
.line	1655	getupval     r21    u1
.line	1655	loadk        r22   k35 ; k35 = 122
.line	1655	loadk        r23    k2 ; k2 = 87
.line	1655	loadk        r24  k108 ; k108 = 15
.line	1655	loadk        r25   k67 ; k67 = 45
.line	1655	loadk        r26   k33 ; k33 = 156
.line	1655	loadk        r27  k109 ; k109 = 182
.line	1655	loadk        r28  k110 ; k110 = 48
.line	1655	loadk        r29  k111 ; k111 = 20
.line	1655	loadk        r30   k79 ; k79 = 22
.line	1655	loadk        r31  k112 ; k112 = 65
.line	1655	loadk        r32  k113 ; k113 = 13
.line	1655	loadk        r33   k81 ; k81 = 69
.line	1655	loadk        r34   k82 ; k82 = 245
.line	1655	loadk        r35   k34 ; k34 = 76
.line	1655	loadk        r36   k79 ; k79 = 22
.line	1655	loadk        r37  k114 ; k114 = 30
.line	1655	loadk        r38  k115 ; k115 = 185
.line	1655	loadk        r39  k116 ; k116 = 111
.line	1655	loadk        r40  k117 ; k117 = 100
.line	1655	loadk        r41  k118 ; k118 = 29
.line	1655	loadk        r42  k119 ; k119 = 98
.line	1655	loadk        r43  k120 ; k120 = 146
.line	1655	loadk        r44  k121 ; k121 = 82
.line	1655	loadk        r45  k116 ; k116 = 111
.line	1655	loadk        r46  k122 ; k122 = 101
.line	1655	loadk        r47   k91 ; k91 = 125
.line	1655	loadk        r48  k123 ; k123 = 21
.line	1655	loadk        r49   k97 ; k97 = 18
.line	1655	loadk        r50  k124 ; k124 = 195
.line	1655	loadk        r51   k49 ; k49 = 64
.line	1655	loadk        r52  k125 ; k125 = 23
.line	1655	loadk        r53  k112 ; k112 = 65
.line	1655	loadk        r54  k126 ; k126 = 158
.line	1655	loadk        r55  k117 ; k117 = 100
.line	1655	loadk        r56   k29 ; k29 = 103
.line	1655	loadk        r57  k127 ; k127 = 9
.line	1655	loadk        r58   k13 ; k13 = 68
.line	1655	loadk        r59   k62 ; k62 = 138
.line	1655	loadk        r60   k54 ; k54 = 71
.line	1655	loadk        r61   k59 ; k59 = 127
.line	1655	call         r21    41     2
.line	1655	getupval     r22    u1
.line	1655	loadk        r23   k12 ; k12 = 126
.line	1655	loadk        r24  k128 ; k128 = 67
.line	1655	loadk        r25  k129 ; k129 = 17
.line	1655	loadk        r26  k130 ; k130 = 60
.line	1655	loadk        r27  k131 ; k131 = 191
.line	1655	loadk        r28  k132 ; k132 = 174
.line	1655	loadk        r29  k133 ; k133 = 4
.line	1655	loadk        r30  k134 ; k134 = 115
.line	1655	loadk        r31  k135 ; k135 = 117
.line	1655	loadk        r32   k94 ; k94 = 109
.line	1655	loadk        r33  k136 ; k136 = 28
.line	1655	loadk        r34   k20 ; k20 = 24
.line	1655	loadk        r35  k137 ; k137 = 194
.line	1655	loadk        r36  k138 ; k138 = 81
.line	1655	loadk        r37  k114 ; k114 = 30
.line	1655	loadk        r38  k139 ; k139 = 42
.line	1655	loadk        r39  k140 ; k140 = 132
.line	1655	loadk        r40   k41 ; k41 = 66
.line	1655	loadk        r41   k87 ; k87 = 119
.line	1655	loadk        r42  k114 ; k114 = 30
.line	1655	loadk        r43    k1 ; k1 = 73
.line	1655	loadk        r44  k167 ; k167 = 157
.line	1655	loadk        r45   k13 ; k13 = 68
.line	1655	call         r22    24     0
.line	1655	setlist      r20     0     1
.line	1655	call         r19     2     2
.line	1655	call         r18     2     2
.line	1655	gettabup     r19    u0  k107 ; k107 = "require"
.line	1655	gettabup     r20    u0   k10 ; k10 = "table"
.line	1655	gettable     r20   r20   k11 ; k11 = "concat"
.line	1655	newtable     r21     1     0
.line	1655	getupval     r22    u1
.line	1655	loadk        r23   k35 ; k35 = 122
.line	1655	loadk        r24    k2 ; k2 = 87
.line	1655	loadk        r25  k108 ; k108 = 15
.line	1655	loadk        r26   k67 ; k67 = 45
.line	1655	loadk        r27   k33 ; k33 = 156
.line	1655	loadk        r28  k109 ; k109 = 182
.line	1655	loadk        r29  k110 ; k110 = 48
.line	1655	loadk        r30  k111 ; k111 = 20
.line	1655	loadk        r31   k79 ; k79 = 22
.line	1655	loadk        r32  k112 ; k112 = 65
.line	1655	loadk        r33  k113 ; k113 = 13
.line	1655	loadk        r34   k81 ; k81 = 69
.line	1655	loadk        r35   k82 ; k82 = 245
.line	1655	loadk        r36   k34 ; k34 = 76
.line	1655	loadk        r37   k79 ; k79 = 22
.line	1655	loadk        r38  k114 ; k114 = 30
.line	1655	loadk        r39  k115 ; k115 = 185
.line	1655	loadk        r40  k116 ; k116 = 111
.line	1655	loadk        r41  k117 ; k117 = 100
.line	1655	loadk        r42  k118 ; k118 = 29
.line	1655	loadk        r43  k119 ; k119 = 98
.line	1655	loadk        r44  k120 ; k120 = 146
.line	1655	loadk        r45  k121 ; k121 = 82
.line	1655	loadk        r46  k116 ; k116 = 111
.line	1655	loadk        r47  k122 ; k122 = 101
.line	1655	loadk        r48  k168 ; k168 = 121
.line	1655	loadk        r49   k20 ; k20 = 24
.line	1655	loadk        r50   k79 ; k79 = 22
.line	1655	loadk        r51  k124 ; k124 = 195
.line	1655	loadk        r52  k169 ; k169 = 94
.line	1655	loadk        r53  k108 ; k108 = 15
.line	1655	loadk        r54   k39 ; k39 = 14
.line	1655	loadk        r55   k16 ; k16 = 164
.line	1655	loadk        r56  k143 ; k143 = 56
.line	1655	loadk        r57  k112 ; k112 = 65
.line	1655	loadk        r58   k14 ; k14 = 7
.line	1655	loadk        r59  k169 ; k169 = 94
.line	1655	loadk        r60  k170 ; k170 = 133
.line	1655	loadk        r61   k92 ; k92 = 88
.line	1655	loadk        r62   k91 ; k91 = 125
.line	1655	call         r22    41     2
.line	1655	getupval     r23    u1
.line	1655	loadk        r24   k84 ; k84 = 19
.line	1655	loadk        r25   k87 ; k87 = 119
.line	1655	loadk        r26  k129 ; k129 = 17
.line	1655	loadk        r27   k38 ; k38 = 59
.line	1655	loadk        r28    k5 ; k5 = 181
.line	1655	loadk        r29   k78 ; k78 = 183
.line	1655	loadk        r30   k59 ; k59 = 127
.line	1655	loadk        r31  k168 ; k168 = 121
.line	1655	loadk        r32   k80 ; k80 = 52
.line	1655	loadk        r33  k128 ; k128 = 67
.line	1655	loadk        r34  k133 ; k133 = 4
.line	1655	loadk        r35  k133 ; k133 = 4
.line	1655	loadk        r36  k171 ; k171 = 216
.line	1655	loadk        r37  k158 ; k158 = 16
.line	1655	loadk        r38  k110 ; k110 = 48
.line	1655	loadk        r39  k113 ; k113 = 13
.line	1655	loadk        r40  k172 ; k172 = 168
.line	1655	loadk        r41   k29 ; k29 = 103
.line	1655	loadk        r42   k30 ; k30 = 102
.line	1655	loadk        r43  k129 ; k129 = 17
.line	1655	loadk        r44   k83 ; k83 = 86
.line	1655	loadk        r45   k51 ; k51 = 150
.line	1655	loadk        r46   k30 ; k30 = 102
.line	1655	loadk        r47   k30 ; k30 = 102
.line	1655	loadk        r48    k4 ; k4 = 36
.line	1655	loadk        r49   k57 ; k57 = 92
.line	1655	loadk        r50   k20 ; k20 = 24
.line	1655	loadk        r51  k125 ; k125 = 23
.line	1655	loadk        r52  k173 ; k173 = 226
.line	1655	loadk        r53  k164 ; k164 = 75
.line	1655	loadk        r54   k44 ; k44 = 5
.line	1655	loadk        r55   k69 ; k69 = 6
.line	1655	loadk        r56   k77 ; k77 = 179
.line	1655	loadk        r57  k134 ; k134 = 115
.line	1655	call         r23    35     0
.line	1655	setlist      r21     0     1
.line	1655	call         r20     2     2
.line	1655	call         r19     2     2
.line	1655	getupval     r20    u2
.line	1655	self         r20   r20  k174 ; k174 = "MakeHashByFNV1a32"
.line	1655	getupval     r22    u1
.line	1655	loadk        r23  k168 ; k168 = 121
.line	1655	loadk        r24  k159 ; k159 = 79
.line	1655	loadk        r25  k175 ; k175 = 12
.line	1655	loadk        r26  k118 ; k118 = 29
.line	1655	loadk        r27  k176 ; k176 = 153
.line	1655	loadk        r28   k46 ; k46 = 128
.line	1655	loadk        r29  k110 ; k110 = 48
.line	1655	loadk        r30   k61 ; k61 = 84
.line	1655	loadk        r31   k67 ; k67 = 45
.line	1655	loadk        r32  k159 ; k159 = 79
.line	1655	loadk        r33   k22 ; k22 = 26
.line	1655	loadk        r34   k80 ; k80 = 52
.line	1655	call         r22    13     2
.line	1655	gettabup     r23    u0   k70 ; k70 = "tostring"
.line	1655	move         r24    r2
.line	1655	call         r23     2     2
.line	1655	concat       r22   r22   r23
.line	1655	call         r20     3     2
.line	1655	newtable     r21     0     5
.line	1655	settable     r21  k177   r20 ; k177 = "InstanceId"
.line	1655	settable     r21  k178  k179 ; k179 = 5200001
.line	1655	gettable     r22   r19  k181 ; k181 = "E_AssetType"
.line	1655	gettable     r22   r22  k182 ; k182 = "UMGInfo"
.line	1655	settable     r21  k180   r22 ; k180 = "AssetCategory"
.line	1655	newtable     r22     0    10
.line	1655	getupval     r23    u1
.line	1655	call         r23     1     2
.line	1655	settable     r22  k184   r23 ; k184 = "CanvasName"
.line	1655	gettable     r23   r18  k186 ; k186 = "UMGCanvasType"
.line	1655	gettable     r23   r23  k187 ; k187 = "Dynamic"
.line	1655	settable     r22  k185   r23 ; k185 = "CanvasType"
.line	1655	settable     r22  k188   k88 ; k88 = true
.line	1655	settable     r22  k189   k88 ; k88 = true
.line	1655	settable     r22  k190   r16 ; k190 = "CanvasWidth"
.line	1655	settable     r22  k191   r17 ; k191 = "CanvasHeight"
.line	1655	self         r23    r0  k193 ; k193 = "_GetTopCanvasSortOrd" (truncated)
.line	1655	call         r23     2     2
.line	1655	settable     r22  k192   r23 ; k192 = "SortOrder"
.line	1655	settable     r22  k194   r20 ; k194 = "CDOInstanceID"
.line	1655	newtable     r23     0     1
.line	1655	settable     r23  k196    r7 ; k196 = "overrides"
.line	1655	settable     r22  k195   r23 ; k195 = "AllWidgets"
.line	1655	settable     r22  k197    r3 ; k197 = "Tag"
.line	1655	settable     r21  k183   r22 ; k183 = "UMGCanvasInfo"
.line	1655	newtable     r22     0     1
.line	1655	newtable     r23     0     1
.line	1655	settable     r23  k196    r8 ; k196 = "overrides"
.line	1655	settable     r22  k199   r23 ; k199 = "Children"
.line	1655	settable     r21  k198   r22 ; k198 = "ObjectGroup"
.line	1655	settable      r1   r20   r21
.line	1655	loadk        r22   k63 ; k63 = 1
.line	1655	len          r23    r7
.line	1655	loadk        r24   k63 ; k63 = 1
.line	1655	move          r0    r0
.line	1655	gettable     r26    r7   r25
.line	1655	gettable     r27    r1   r26
.line	1655	test         r27     0
.line	1655	jmp            0  l758
.line	1655	gettable     r28   r27   k89 ; k89 = "CustomUIBase"
.line	1655	test         r28     0
.line	1655	jmp            0  l758
.line	1655	gettable     r28   r27   k89 ; k89 = "CustomUIBase"
.line	1655	settable     r28  k200   r20 ; k200 = "CanvasID"
.label	l758
.line	1655	move          r0    r0
.line	1655	return       r20     2
.line	1655	return        r0     1
.line	1655	move          r0    r0
.line	1655	move          r0    r0
.line	1655	move          r0    r0
.line	1655	move          r0    r0
.line	1655	return        r0     1

.function	main/f77

.source	null
.linedefined	1736
.lastlinedefined	1748
.numparams	4
.is_vararg	0
.maxstacksize	52

.upvalue	"_ENV"	1	true
.upvalue	"U1"	0	false

.constant	k0	"_BuildDynamicCanvasFromBinTable"
.constant	k1	"CreateRuntimeInstance"
.constant	k2	110
.constant	k3	"print"
.constant	k4	"bWriteLog"
.constant	k5	"table"
.constant	k6	"concat"
.constant	k7	126
.constant	k8	68
.constant	k9	7
.constant	k10	41
.constant	k11	164
.constant	k12	170
.constant	k13	39
.constant	k14	95
.constant	k15	24
.constant	k16	91
.constant	k17	26
.constant	k18	31
.constant	k19	217
.constant	k20	83
.constant	k21	38
.constant	k22	54
.constant	k23	137
.constant	k24	103
.constant	k25	102
.constant	k26	25
.constant	k27	99
.constant	k28	156
.constant	k29	76
.constant	k30	122
.constant	k31	113
.constant	k32	97
.constant	k33	59
.constant	k34	14
.constant	k35	207
.constant	k36	66
.constant	k37	46
.constant	k38	179
.constant	k39	114
.constant	k40	81
.constant	k41	148
.constant	k42	79
.constant	k43	112
.constant	k44	36
.constant	k45	58
.constant	k46	191
.constant	k47	174
.constant	k48	19
.constant	k49	53
.constant	k50	8
.constant	k51	9
.constant	k52	218
.constant	k53	60
.constant	k54	115
.constant	k55	12
.constant	k56	69
.constant	k57	161
.constant	k58	84
.constant	k59	100
.constant	k60	63
.constant	k61	87
.constant	k62	20
.constant	k63	30
.constant	k64	239
.constant	k65	64
.constant	k66	16
.constant	k67	27
.constant	k68	188
.constant	k69	120
.constant	k70	13
.constant	k71	133
.constant	k72	80
.constant	k73	6
.constant	k74	"tostring"
.constant	k75	"string"
.constant	k76	"format"
.constant	k77	162
.constant	k78	104
.constant	k79	119
.constant	k80	88
.constant	k81	134
.constant	k82	82
.constant	k83	56
.constant	k84	213
.constant	k85	75
.constant	k86	23
.constant	k87	184
.constant	k88	111
.constant	k89	77
.constant	k90	67
.constant	k91	195
.constant	k92	11
.constant	k93	37
.constant	k94	181
.constant	k95	128
.constant	k96	48
.constant	k97	45
.constant	k98	34
.constant	k99	210
.constant	k100	3
.constant	k101	86
.constant	k102	237
.constant	k103	29
.constant	k104	214

.line	1736	self          r4    r0    k0 ; k0 = "_BuildDynamicCanvasF" (truncated)
.line	1736	move          r6    r1
.line	1736	move          r7    r2
.line	1736	move          r8    r3
.line	1736	call          r4     5     2
.line	1736	test          r4     1
.line	1736	jmp            0   l10
.line	1736	loadnil       r5     0
.line	1736	return        r5     2
.label	l10
.line	1736	self          r5    r0    k1 ; k1 = "CreateRuntimeInstanc" (truncated)
.line	1736	move          r7    r4
.line	1736	move          r8    r1
.line	1736	getupval      r9    u0
.line	1736	loadk        r10    k2 ; k2 = 110
.line	1736	call          r9     2     2
.line	1736	call          r5     5     2
.line	1736	test          r5     1
.line	1736	jmp            0  l123
.line	1736	gettabup      r6    u1    k3 ; k3 = "print"
.line	1736	gettabup      r7    u1    k4 ; k4 = "bWriteLog"
.line	1736	test          r7     0
.line	1736	jmp            0  l117
.line	1736	gettabup      r7    u1    k5 ; k5 = "table"
.line	1736	gettable      r7    r7    k6 ; k6 = "concat"
.line	1736	newtable      r8     2     0
.line	1736	getupval      r9    u0
.line	1736	loadk        r10    k7 ; k7 = 126
.line	1736	loadk        r11    k8 ; k8 = 68
.line	1736	loadk        r12    k9 ; k9 = 7
.line	1736	loadk        r13   k10 ; k10 = 41
.line	1736	loadk        r14   k11 ; k11 = 164
.line	1736	loadk        r15   k12 ; k12 = 170
.line	1736	loadk        r16   k13 ; k13 = 39
.line	1736	loadk        r17   k14 ; k14 = 95
.line	1736	loadk        r18   k15 ; k15 = 24
.line	1736	loadk        r19   k16 ; k16 = 91
.line	1736	loadk        r20   k17 ; k17 = 26
.line	1736	loadk        r21   k18 ; k18 = 31
.line	1736	loadk        r22   k19 ; k19 = 217
.line	1736	loadk        r23   k20 ; k20 = 83
.line	1736	loadk        r24   k21 ; k21 = 38
.line	1736	loadk        r25   k22 ; k22 = 54
.line	1736	loadk        r26   k23 ; k23 = 137
.line	1736	loadk        r27   k24 ; k24 = 103
.line	1736	loadk        r28   k25 ; k25 = 102
.line	1736	loadk        r29   k26 ; k26 = 25
.line	1736	loadk        r30   k27 ; k27 = 99
.line	1736	loadk        r31   k28 ; k28 = 156
.line	1736	loadk        r32   k29 ; k29 = 76
.line	1736	loadk        r33   k30 ; k30 = 122
.line	1736	loadk        r34   k31 ; k31 = 113
.line	1736	loadk        r35   k32 ; k32 = 97
.line	1736	loadk        r36   k33 ; k33 = 59
.line	1736	loadk        r37   k34 ; k34 = 14
.line	1736	loadk        r38   k35 ; k35 = 207
.line	1736	loadk        r39   k36 ; k36 = 66
.line	1736	loadk        r40    k9 ; k9 = 7
.line	1736	loadk        r41   k37 ; k37 = 46
.line	1736	loadk        r42   k38 ; k38 = 179
.line	1736	loadk        r43   k39 ; k39 = 114
.line	1736	loadk        r44   k40 ; k40 = 81
.line	1736	loadk        r45   k15 ; k15 = 24
.line	1736	loadk        r46   k40 ; k40 = 81
.line	1736	loadk        r47   k41 ; k41 = 148
.line	1736	loadk        r48   k14 ; k14 = 95
.line	1736	loadk        r49   k42 ; k42 = 79
.line	1736	call          r9    41     2
.line	1736	getupval     r10    u0
.line	1736	loadk        r11   k43 ; k43 = 112
.line	1736	loadk        r12   k31 ; k31 = 113
.line	1736	loadk        r13   k44 ; k44 = 36
.line	1736	loadk        r14   k45 ; k45 = 58
.line	1736	loadk        r15   k46 ; k46 = 191
.line	1736	loadk        r16   k47 ; k47 = 174
.line	1736	loadk        r17   k48 ; k48 = 19
.line	1736	loadk        r18   k20 ; k20 = 83
.line	1736	loadk        r19   k49 ; k49 = 53
.line	1736	loadk        r20   k30 ; k30 = 122
.line	1736	loadk        r21   k50 ; k50 = 8
.line	1736	loadk        r22   k51 ; k51 = 9
.line	1736	loadk        r23   k52 ; k52 = 218
.line	1736	loadk        r24   k16 ; k16 = 91
.line	1736	loadk        r25   k20 ; k20 = 83
.line	1736	loadk        r26   k53 ; k53 = 60
.line	1736	loadk        r27   k46 ; k46 = 191
.line	1736	loadk        r28   k27 ; k27 = 99
.line	1736	loadk        r29   k54 ; k54 = 115
.line	1736	loadk        r30   k55 ; k55 = 12
.line	1736	loadk        r31   k56 ; k56 = 69
.line	1736	loadk        r32   k57 ; k57 = 161
.line	1736	loadk        r33   k58 ; k58 = 84
.line	1736	loadk        r34   k59 ; k59 = 100
.line	1736	loadk        r35   k60 ; k60 = 63
.line	1736	loadk        r36   k61 ; k61 = 87
.line	1736	loadk        r37   k62 ; k62 = 20
.line	1736	loadk        r38   k63 ; k63 = 30
.line	1736	loadk        r39   k64 ; k64 = 239
.line	1736	loadk        r40   k65 ; k65 = 64
.line	1736	loadk        r41   k66 ; k66 = 16
.line	1736	loadk        r42   k67 ; k67 = 27
.line	1736	loadk        r43   k68 ; k68 = 188
.line	1736	loadk        r44   k69 ; k69 = 120
.line	1736	loadk        r45   k32 ; k32 = 97
.line	1736	loadk        r46   k70 ; k70 = 13
.line	1736	loadk        r47   k66 ; k66 = 16
.line	1736	loadk        r48   k71 ; k71 = 133
.line	1736	loadk        r49   k72 ; k72 = 80
.line	1736	loadk        r50   k54 ; k54 = 115
.line	1736	call         r10    41     2
.line	1736	getupval     r11    u0
.line	1736	loadk        r12   k40 ; k40 = 81
.line	1736	loadk        r13   k20 ; k20 = 83
.line	1736	loadk        r14   k73 ; k73 = 6
.line	1736	call         r11     4     0
.line	1736	setlist       r8     0     1
.line	1736	call          r7     2     2
.label	l117
.line	1736	gettabup      r8    u1   k74 ; k74 = "tostring"
.line	1736	move          r9    r2
.line	1736	call          r8     2     0
.line	1736	call          r6     0     1
.line	1736	loadnil       r6     0
.line	1736	return        r6     2
.label	l123
.line	1736	gettabup      r6    u1    k3 ; k3 = "print"
.line	1736	gettabup      r7    u1    k4 ; k4 = "bWriteLog"
.line	1736	test          r7     0
.line	1736	jmp            0  l253
.line	1736	gettabup      r7    u1   k75 ; k75 = "string"
.line	1736	gettable      r7    r7   k76 ; k76 = "format"
.line	1736	gettabup      r8    u1    k5 ; k5 = "table"
.line	1736	gettable      r8    r8    k6 ; k6 = "concat"
.line	1736	newtable      r9     2     0
.line	1736	getupval     r10    u0
.line	1736	loadk        r11    k7 ; k7 = 126
.line	1736	loadk        r12    k8 ; k8 = 68
.line	1736	loadk        r13    k9 ; k9 = 7
.line	1736	loadk        r14   k10 ; k10 = 41
.line	1736	loadk        r15   k11 ; k11 = 164
.line	1736	loadk        r16   k12 ; k12 = 170
.line	1736	loadk        r17   k13 ; k13 = 39
.line	1736	loadk        r18   k14 ; k14 = 95
.line	1736	loadk        r19   k15 ; k15 = 24
.line	1736	loadk        r20   k16 ; k16 = 91
.line	1736	loadk        r21   k17 ; k17 = 26
.line	1736	loadk        r22   k18 ; k18 = 31
.line	1736	loadk        r23   k19 ; k19 = 217
.line	1736	loadk        r24   k20 ; k20 = 83
.line	1736	loadk        r25   k21 ; k21 = 38
.line	1736	loadk        r26   k22 ; k22 = 54
.line	1736	loadk        r27   k23 ; k23 = 137
.line	1736	loadk        r28   k24 ; k24 = 103
.line	1736	loadk        r29   k25 ; k25 = 102
.line	1736	loadk        r30   k26 ; k26 = 25
.line	1736	loadk        r31   k27 ; k27 = 99
.line	1736	loadk        r32   k28 ; k28 = 156
.line	1736	loadk        r33   k29 ; k29 = 76
.line	1736	loadk        r34   k30 ; k30 = 122
.line	1736	loadk        r35   k31 ; k31 = 113
.line	1736	loadk        r36   k32 ; k32 = 97
.line	1736	loadk        r37   k33 ; k33 = 59
.line	1736	loadk        r38   k34 ; k34 = 14
.line	1736	loadk        r39   k35 ; k35 = 207
.line	1736	loadk        r40   k36 ; k36 = 66
.line	1736	loadk        r41    k9 ; k9 = 7
.line	1736	loadk        r42   k37 ; k37 = 46
.line	1736	loadk        r43   k38 ; k38 = 179
.line	1736	loadk        r44   k39 ; k39 = 114
.line	1736	loadk        r45   k40 ; k40 = 81
.line	1736	loadk        r46   k15 ; k15 = 24
.line	1736	loadk        r47   k40 ; k40 = 81
.line	1736	loadk        r48   k41 ; k41 = 148
.line	1736	loadk        r49   k14 ; k14 = 95
.line	1736	loadk        r50   k42 ; k42 = 79
.line	1736	call         r10    41     2
.line	1736	getupval     r11    u0
.line	1736	loadk        r12   k43 ; k43 = 112
.line	1736	loadk        r13   k31 ; k31 = 113
.line	1736	loadk        r14   k44 ; k44 = 36
.line	1736	loadk        r15   k45 ; k45 = 58
.line	1736	loadk        r16   k46 ; k46 = 191
.line	1736	loadk        r17   k47 ; k47 = 174
.line	1736	loadk        r18   k48 ; k48 = 19
.line	1736	loadk        r19   k20 ; k20 = 83
.line	1736	loadk        r20   k49 ; k49 = 53
.line	1736	loadk        r21   k30 ; k30 = 122
.line	1736	loadk        r22   k50 ; k50 = 8
.line	1736	loadk        r23   k51 ; k51 = 9
.line	1736	loadk        r24   k52 ; k52 = 218
.line	1736	loadk        r25   k16 ; k16 = 91
.line	1736	loadk        r26   k20 ; k20 = 83
.line	1736	loadk        r27   k67 ; k67 = 27
.line	1736	loadk        r28   k77 ; k77 = 162
.line	1736	loadk        r29   k78 ; k78 = 104
.line	1736	loadk        r30   k79 ; k79 = 119
.line	1736	loadk        r31   k80 ; k80 = 88
.line	1736	loadk        r32   k27 ; k27 = 99
.line	1736	loadk        r33   k81 ; k81 = 134
.line	1736	loadk        r34   k82 ; k82 = 82
.line	1736	loadk        r35    k7 ; k7 = 126
.line	1736	loadk        r36   k44 ; k44 = 36
.line	1736	loadk        r37   k20 ; k20 = 83
.line	1736	loadk        r38   k83 ; k83 = 56
.line	1736	loadk        r39   k50 ; k50 = 8
.line	1736	loadk        r40   k84 ; k84 = 213
.line	1736	loadk        r41   k85 ; k85 = 75
.line	1736	loadk        r42   k86 ; k86 = 23
.line	1736	loadk        r43   k44 ; k44 = 36
.line	1736	loadk        r44   k87 ; k87 = 184
.line	1736	loadk        r45   k88 ; k88 = 111
.line	1736	loadk        r46   k60 ; k60 = 63
.line	1736	loadk        r47   k89 ; k89 = 77
.line	1736	loadk        r48   k90 ; k90 = 67
.line	1736	loadk        r49   k91 ; k91 = 195
.line	1736	loadk        r50   k27 ; k27 = 99
.line	1736	loadk        r51   k88 ; k88 = 111
.line	1736	call         r11    41     2
.line	1736	getupval     r12    u0
.line	1736	loadk        r13   k20 ; k20 = 83
.line	1736	loadk        r14   k36 ; k36 = 66
.line	1736	loadk        r15   k92 ; k92 = 11
.line	1736	loadk        r16   k93 ; k93 = 37
.line	1736	loadk        r17   k94 ; k94 = 181
.line	1736	loadk        r18   k95 ; k95 = 128
.line	1736	loadk        r19   k96 ; k96 = 48
.line	1736	loadk        r20   k58 ; k58 = 84
.line	1736	loadk        r21   k97 ; k97 = 45
.line	1736	loadk        r22   k42 ; k42 = 79
.line	1736	loadk        r23   k17 ; k17 = 26
.line	1736	loadk        r24   k98 ; k98 = 34
.line	1736	loadk        r25   k99 ; k99 = 210
.line	1736	loadk        r26  k100 ; k100 = 3
.line	1736	loadk        r27  k101 ; k101 = 86
.line	1736	loadk        r28   k55 ; k55 = 12
.line	1736	loadk        r29  k102 ; k102 = 237
.line	1736	loadk        r30   k82 ; k82 = 82
.line	1736	loadk        r31   k54 ; k54 = 115
.line	1736	loadk        r32   k18 ; k18 = 31
.line	1736	loadk        r33  k103 ; k103 = 29
.line	1736	loadk        r34  k104 ; k104 = 214
.line	1736	loadk        r35   k82 ; k82 = 82
.line	1736	call         r12    24     0
.line	1736	setlist       r9     0     1
.line	1736	call          r8     2     2
.line	1736	gettabup      r9    u1   k74 ; k74 = "tostring"
.line	1736	move         r10    r2
.line	1736	call          r9     2     2
.line	1736	gettabup     r10    u1   k74 ; k74 = "tostring"
.line	1736	move         r11    r5
.line	1736	call         r10     2     2
.line	1736	gettabup     r11    u1   k74 ; k74 = "tostring"
.line	1736	move         r12    r3
.line	1736	call         r11     2     0
.line	1736	call          r7     0     2
.label	l253
.line	1736	call          r6     2     1
.line	1736	return        r5     2
.line	1736	return        r0     1
.line	1736	move          r0    r0
.line	1736	move          r0    r0
.line	1736	move          r0    r0
.line	1736	move          r0    r0
.line	1736	return        r0     1

.function	main/f78

.source	null
.linedefined	1750
.lastlinedefined	1768
.numparams	4
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"pcall"
.constant	k1	"require"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	94
.constant	k5	90
.constant	k6	11
.constant	k7	45
.constant	k8	190
.constant	k9	183
.constant	k10	127
.constant	k11	73
.constant	k12	55
.constant	k13	91
.constant	k14	8
.constant	k15	69
.constant	k16	218
.constant	k17	81
.constant	k18	20
.constant	k19	22
.constant	k20	174
.constant	k21	40
.constant	k22	103
.constant	k23	31
.constant	k24	67
.constant	k25	221
.constant	k26	84
.constant	k27	109
.constant	k28	97
.constant	k29	30
.constant	k30	203
.constant	k31	113
.constant	k32	17
.constant	k33	10
.constant	k34	173
.constant	k35	121
.constant	k36	112
.constant	k37	28
.constant	k38	111
.constant	k39	150
.constant	k40	115
.constant	k41	"print"
.constant	k42	102
.constant	k43	117
.constant	k44	14
.constant	k45	33
.constant	k46	181
.constant	k47	37
.constant	k48	18
.constant	k49	98
.constant	k50	6
.constant	k51	210
.constant	k52	99
.constant	k53	83
.constant	k54	56
.constant	k55	136
.constant	k56	75
.constant	k57	50
.constant	k58	131
.constant	k59	78
.constant	k60	120
.constant	k61	63
.constant	k62	16
.constant	k63	207
.constant	k64	19
.constant	k65	185
.constant	k66	44
.constant	k67	34
.constant	k68	29
.constant	k69	87
.constant	k70	128
.constant	k71	110
.constant	k72	125
.constant	k73	88
.constant	k74	61
.constant	k75	58
.constant	k76	179
.constant	k77	62
.constant	k78	72
.constant	k79	47
.constant	k80	223
.constant	k81	82
.constant	k82	0
.constant	k83	95
.constant	k84	184
.constant	k85	104
.constant	k86	65
.constant	k87	154
.constant	k88	77
.constant	k89	107
.constant	k90	41
.constant	k91	"CGameState"
.constant	k92	"slua"
.constant	k93	"isValid"
.constant	k94	"GetMainModID"
.constant	k95	"tonumber"
.constant	k96	"Report"
.constant	k97	"EnumMessageType"
.constant	k98	"ClientUILoadResult"
.constant	k99	"source"
.constant	k100	"tostring"
.constant	k101	"key"
.constant	k102	"result"
.constant	k103	93
.constant	k104	36
.constant	k105	167

.line	1750	gettabup      r4    u0    k0 ; k0 = "pcall"
.line	1750	gettabup      r5    u0    k1 ; k1 = "require"
.line	1750	gettabup      r6    u0    k2 ; k2 = "table"
.line	1750	gettable      r6    r6    k3 ; k3 = "concat"
.line	1750	newtable      r7     1     0
.line	1750	getupval      r8    u1
.line	1750	loadk         r9    k4 ; k4 = 94
.line	1750	loadk        r10    k5 ; k5 = 90
.line	1750	loadk        r11    k6 ; k6 = 11
.line	1750	loadk        r12    k7 ; k7 = 45
.line	1750	loadk        r13    k8 ; k8 = 190
.line	1750	loadk        r14    k9 ; k9 = 183
.line	1750	loadk        r15   k10 ; k10 = 127
.line	1750	loadk        r16   k11 ; k11 = 73
.line	1750	loadk        r17   k12 ; k12 = 55
.line	1750	loadk        r18   k13 ; k13 = 91
.line	1750	loadk        r19   k14 ; k14 = 8
.line	1750	loadk        r20   k15 ; k15 = 69
.line	1750	loadk        r21   k16 ; k16 = 218
.line	1750	loadk        r22   k17 ; k17 = 81
.line	1750	loadk        r23   k18 ; k18 = 20
.line	1750	loadk        r24   k19 ; k19 = 22
.line	1750	loadk        r25   k20 ; k20 = 174
.line	1750	loadk        r26   k21 ; k21 = 40
.line	1750	loadk        r27   k22 ; k22 = 103
.line	1750	loadk        r28   k23 ; k23 = 31
.line	1750	loadk        r29   k24 ; k24 = 67
.line	1750	loadk        r30   k25 ; k25 = 221
.line	1750	loadk        r31   k26 ; k26 = 84
.line	1750	loadk        r32   k27 ; k27 = 109
.line	1750	loadk        r33   k21 ; k21 = 40
.line	1750	loadk        r34   k28 ; k28 = 97
.line	1750	loadk        r35   k29 ; k29 = 30
.line	1750	loadk        r36   k29 ; k29 = 30
.line	1750	loadk        r37   k30 ; k30 = 203
.line	1750	loadk        r38   k31 ; k31 = 113
.line	1750	loadk        r39   k32 ; k32 = 17
.line	1750	loadk        r40   k33 ; k33 = 10
.line	1750	loadk        r41   k34 ; k34 = 173
.line	1750	loadk        r42   k35 ; k35 = 121
.line	1750	loadk        r43   k36 ; k36 = 112
.line	1750	loadk        r44   k37 ; k37 = 28
.line	1750	loadk        r45   k38 ; k38 = 111
.line	1750	loadk        r46   k39 ; k39 = 150
.line	1750	loadk        r47   k15 ; k15 = 69
.line	1750	loadk        r48   k40 ; k40 = 115
.line	1750	call          r8    41     2
.line	1750	getupval      r9    u1
.line	1750	loadk        r10   k17 ; k17 = 81
.line	1750	loadk        r11   k15 ; k15 = 69
.line	1750	call          r9     3     0
.line	1750	setlist       r7     0     1
.line	1750	call          r6     2     2
.line	1750	call          r4     3     3
.line	1750	test          r4     0
.line	1750	jmp            0   l59
.line	1750	test          r5     1
.line	1750	jmp            0  l138
.label	l59
.line	1750	gettabup      r6    u0   k41 ; k41 = "print"
.line	1750	gettabup      r7    u0    k2 ; k2 = "table"
.line	1750	gettable      r7    r7    k3 ; k3 = "concat"
.line	1750	newtable      r8     1     0
.line	1750	getupval      r9    u1
.line	1750	loadk        r10   k42 ; k42 = 102
.line	1750	loadk        r11   k43 ; k43 = 117
.line	1750	loadk        r12   k44 ; k44 = 14
.line	1750	loadk        r13   k45 ; k45 = 33
.line	1750	loadk        r14   k46 ; k46 = 181
.line	1750	loadk        r15   k34 ; k34 = 173
.line	1750	loadk        r16   k47 ; k47 = 37
.line	1750	loadk        r17   k38 ; k38 = 111
.line	1750	loadk        r18   k48 ; k48 = 18
.line	1750	loadk        r19   k49 ; k49 = 98
.line	1750	loadk        r20   k50 ; k50 = 6
.line	1750	loadk        r21   k33 ; k33 = 10
.line	1750	loadk        r22   k51 ; k51 = 210
.line	1750	loadk        r23   k52 ; k52 = 99
.line	1750	loadk        r24   k53 ; k53 = 83
.line	1750	loadk        r25   k54 ; k54 = 56
.line	1750	loadk        r26   k55 ; k55 = 136
.line	1750	loadk        r27   k56 ; k56 = 75
.line	1750	loadk        r28   k57 ; k57 = 50
.line	1750	loadk        r29   k33 ; k33 = 10
.line	1750	loadk        r30   k15 ; k15 = 69
.line	1750	loadk        r31   k58 ; k58 = 131
.line	1750	loadk        r32   k59 ; k59 = 78
.line	1750	loadk        r33   k60 ; k60 = 120
.line	1750	loadk        r34   k61 ; k61 = 63
.line	1750	loadk        r35   k29 ; k29 = 30
.line	1750	loadk        r36   k33 ; k33 = 10
.line	1750	loadk        r37   k62 ; k62 = 16
.line	1750	loadk        r38   k63 ; k63 = 207
.line	1750	loadk        r39    k4 ; k4 = 94
.line	1750	loadk        r40   k64 ; k64 = 19
.line	1750	loadk        r41   k33 ; k33 = 10
.line	1750	loadk        r42   k65 ; k65 = 185
.line	1750	loadk        r43   k66 ; k66 = 44
.line	1750	loadk        r44   k67 ; k67 = 34
.line	1750	loadk        r45   k68 ; k68 = 29
.line	1750	loadk        r46   k69 ; k69 = 87
.line	1750	loadk        r47   k70 ; k70 = 128
.line	1750	loadk        r48   k71 ; k71 = 110
.line	1750	loadk        r49   k72 ; k72 = 125
.line	1750	call          r9    41     2
.line	1750	getupval     r10    u1
.line	1750	loadk        r11   k73 ; k73 = 88
.line	1750	loadk        r12   k13 ; k13 = 91
.line	1750	loadk        r13   k74 ; k74 = 61
.line	1750	loadk        r14   k75 ; k75 = 58
.line	1750	loadk        r15   k46 ; k46 = 181
.line	1750	loadk        r16   k76 ; k76 = 179
.line	1750	loadk        r17   k77 ; k77 = 62
.line	1750	loadk        r18   k78 ; k78 = 72
.line	1750	loadk        r19   k79 ; k79 = 47
.line	1750	loadk        r20   k31 ; k31 = 113
.line	1750	loadk        r21   k37 ; k37 = 28
.line	1750	loadk        r22   k23 ; k23 = 31
.line	1750	loadk        r23   k80 ; k80 = 223
.line	1750	loadk        r24   k81 ; k81 = 82
.line	1750	loadk        r25   k82 ; k82 = 0
.line	1750	loadk        r26   k83 ; k83 = 95
.line	1750	loadk        r27   k84 ; k84 = 184
.line	1750	loadk        r28   k85 ; k85 = 104
.line	1750	loadk        r29   k40 ; k40 = 115
.line	1750	loadk        r30   k44 ; k44 = 14
.line	1750	loadk        r31   k86 ; k86 = 65
.line	1750	loadk        r32   k87 ; k87 = 154
.line	1750	loadk        r33   k88 ; k88 = 77
.line	1750	loadk        r34   k89 ; k89 = 107
.line	1750	loadk        r35   k90 ; k90 = 41
.line	1750	loadk        r36   k81 ; k81 = 82
.line	1750	loadk        r37   k37 ; k37 = 28
.line	1750	call         r10    28     0
.line	1750	setlist       r8     0     1
.line	1750	call          r7     2     2
.line	1750	call          r6     2     1
.line	1750	return        r0     1
.label	l138
.line	1750	loadnil       r6     0
.line	1750	gettabup      r7    u0   k91 ; k91 = "CGameState"
.line	1750	test          r7     0
.line	1750	jmp            0  l162
.line	1750	gettabup      r7    u0   k92 ; k92 = "slua"
.line	1750	gettable      r7    r7   k93 ; k93 = "isValid"
.line	1750	gettabup      r8    u0   k91 ; k91 = "CGameState"
.line	1750	call          r7     2     2
.line	1750	test          r7     0
.line	1750	jmp            0  l162
.line	1750	gettabup      r7    u0   k91 ; k91 = "CGameState"
.line	1750	gettable      r7    r7   k94 ; k94 = "GetMainModID"
.line	1750	test          r7     0
.line	1750	jmp            0  l162
.line	1750	gettabup      r7    u0   k95 ; k95 = "tonumber"
.line	1750	gettabup      r8    u0   k91 ; k91 = "CGameState"
.line	1750	self          r8    r8   k94 ; k94 = "GetMainModID"
.line	1750	call          r8     2     0
.line	1750	call          r7     0     2
.line	1750	test          r7     0
.line	1750	jmp            0  l162
.line	1750	lt             0   k82    r7 ; k82 = 0
.line	1750	jmp            0  l162
.line	1750	move          r6    r7
.label	l162
.line	1750	gettable      r7    r5   k96 ; k96 = "Report"
.line	1750	gettable      r8    r5   k97 ; k97 = "EnumMessageType"
.line	1750	gettable      r8    r8   k98 ; k98 = "ClientUILoadResult"
.line	1750	move          r9    r6
.line	1750	newtable     r10     0     3
.line	1750	gettabup     r11    u0  k100 ; k100 = "tostring"
.line	1750	move         r12    r1
.line	1750	call         r11     2     2
.line	1750	settable     r10   k99   r11 ; k99 = "source"
.line	1750	gettabup     r11    u0  k100 ; k100 = "tostring"
.line	1750	move         r12    r2
.line	1750	call         r11     2     2
.line	1750	settable     r10  k101   r11 ; k101 = "key"
.line	1750	test          r3     0
.line	1750	jmp            0  l183
.line	1750	getupval     r11    u1
.line	1750	loadk        r12   k81 ; k81 = 82
.line	1750	loadk        r13  k103 ; k103 = 93
.line	1750	call         r11     3     2
.line	1750	test         r11     1
.line	1750	jmp            0  l191
.label	l183
.line	1750	getupval     r11    u1
.line	1750	loadk        r12   k13 ; k13 = 91
.line	1750	loadk        r13   k69 ; k69 = 87
.line	1750	loadk        r14    k6 ; k6 = 11
.line	1750	loadk        r15  k104 ; k104 = 36
.line	1750	loadk        r16   k46 ; k46 = 181
.line	1750	loadk        r17  k105 ; k105 = 167
.line	1750	call         r11     7     2
.label	l191
.line	1750	settable     r10  k102   r11 ; k102 = "result"
.line	1750	call          r7     4     1
.line	1750	return        r0     1
.line	1750	move          r0    r0
.line	1750	return        r0     1

.function	main/f79

.source	null
.linedefined	1770
.lastlinedefined	1775
.numparams	4
.is_vararg	0
.maxstacksize	5

.line	1770	closure       r4    f0
.line	1770	return        r4     2
.line	1770	return        r0     1
.line	1770	move          r0    r0
.line	1770	move          r0    r0
.line	1770	move          r0    r0
.line	1770	move          r0    r0
.line	1770	return        r0     1

.function	main/f79/f0

.source	null
.linedefined	1771
.lastlinedefined	1774
.numparams	1
.is_vararg	1
.maxstacksize	6

.upvalue	"_ENV"	0	true
.upvalue	"U1"	1	true
.upvalue	"U2"	2	true
.upvalue	"U3"	3	true

.constant	k0	"ReportClientUILoadResultToGEM"
.constant	k1	nil

.line	1771	getupval      r1    u0
.line	1771	self          r1    r1    k0 ; k0 = "ReportClientUILoadRe" (truncated)
.line	1771	getupval      r3    u1
.line	1771	getupval      r4    u2
.line	1771	eq             0    r0    k1 ; k1 = nil
.line	1771	jmp            0    l8
.line	1771	loadbool      r5     0     1
.label	l8
.line	1771	loadbool      r5     1     0
.line	1771	call          r1     5     1
.line	1771	getupval      r1    u3
.line	1771	move          r2    r0
.line	1771	vararg        r3     0
.line	1771	call          r1     0     1
.line	1771	return        r0     1
.line	1771	move          r0    r0
.line	1771	return        r0     1

.function	main/f80

.source	null
.linedefined	1777
.lastlinedefined	1832
.numparams	4
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"HasAuthority"
.constant	k1	"print"
.constant	k2	"bWriteLog"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	126
.constant	k6	68
.constant	k7	7
.constant	k8	41
.constant	k9	164
.constant	k10	170
.constant	k11	39
.constant	k12	95
.constant	k13	24
.constant	k14	91
.constant	k15	26
.constant	k16	31
.constant	k17	217
.constant	k18	83
.constant	k19	38
.constant	k20	54
.constant	k21	137
.constant	k22	103
.constant	k23	102
.constant	k24	25
.constant	k25	99
.constant	k26	156
.constant	k27	76
.constant	k28	122
.constant	k29	113
.constant	k30	125
.constant	k31	21
.constant	k32	18
.constant	k33	195
.constant	k34	64
.constant	k35	23
.constant	k36	35
.constant	k37	178
.constant	k38	119
.constant	k39	61
.constant	k40	127
.constant	k41	78
.constant	k42	22
.constant	k43	17
.constant	k44	185
.constant	k45	179
.constant	k46	124
.constant	k47	82
.constant	k48	58
.constant	k49	93
.constant	k50	10
.constant	k51	74
.constant	k52	27
.constant	k53	16
.constant	k54	191
.constant	k55	111
.constant	k56	1
.constant	k57	"tostring"
.constant	k58	"WrapClientUILoadCallbackForReport"
.constant	k59	90
.constant	k60	11
.constant	k61	45
.constant	k62	190
.constant	k63	183
.constant	k64	29
.constant	k65	85
.constant	k66	60
.constant	k67	241
.constant	k68	108
.constant	k69	12
.constant	k70	"type"
.constant	k71	66
.constant	k72	33
.constant	k73	163
.constant	k74	62
.constant	k75	87
.constant	k76	14
.constant	k77	194
.constant	k78	117
.constant	k79	6
.constant	k80	237
.constant	k81	97
.constant	k82	88
.constant	k83	73
.constant	k84	157
.constant	k85	107
.constant	k86	"CustomAssetMgr"
.constant	k87	nil
.constant	k88	115
.constant	k89	20
.constant	k90	13
.constant	k91	154
.constant	k92	77
.constant	k93	"_AsyncLoadSeq"
.constant	k94	0
.constant	k95	63
.constant	k96	69
.constant	k97	144
.constant	k98	52
.constant	k99	75
.constant	k100	"_DownloadAndUnpackInstanceTree"

.line	1777	self          r4    r0    k0 ; k0 = "HasAuthority"
.line	1777	call          r4     2     2
.line	1777	test          r4     0
.line	1777	jmp            0   l87
.line	1777	gettabup      r4    u0    k1 ; k1 = "print"
.line	1777	gettabup      r5    u0    k2 ; k2 = "bWriteLog"
.line	1777	test          r5     0
.line	1777	jmp            0   l78
.line	1777	gettabup      r5    u0    k3 ; k3 = "table"
.line	1777	gettable      r5    r5    k4 ; k4 = "concat"
.line	1777	newtable      r6     1     0
.line	1777	getupval      r7    u1
.line	1777	loadk         r8    k5 ; k5 = 126
.line	1777	loadk         r9    k6 ; k6 = 68
.line	1777	loadk        r10    k7 ; k7 = 7
.line	1777	loadk        r11    k8 ; k8 = 41
.line	1777	loadk        r12    k9 ; k9 = 164
.line	1777	loadk        r13   k10 ; k10 = 170
.line	1777	loadk        r14   k11 ; k11 = 39
.line	1777	loadk        r15   k12 ; k12 = 95
.line	1777	loadk        r16   k13 ; k13 = 24
.line	1777	loadk        r17   k14 ; k14 = 91
.line	1777	loadk        r18   k15 ; k15 = 26
.line	1777	loadk        r19   k16 ; k16 = 31
.line	1777	loadk        r20   k17 ; k17 = 217
.line	1777	loadk        r21   k18 ; k18 = 83
.line	1777	loadk        r22   k19 ; k19 = 38
.line	1777	loadk        r23   k20 ; k20 = 54
.line	1777	loadk        r24   k21 ; k21 = 137
.line	1777	loadk        r25   k22 ; k22 = 103
.line	1777	loadk        r26   k23 ; k23 = 102
.line	1777	loadk        r27   k24 ; k24 = 25
.line	1777	loadk        r28   k25 ; k25 = 99
.line	1777	loadk        r29   k26 ; k26 = 156
.line	1777	loadk        r30   k27 ; k27 = 76
.line	1777	loadk        r31   k28 ; k28 = 122
.line	1777	loadk        r32   k29 ; k29 = 113
.line	1777	loadk        r33   k30 ; k30 = 125
.line	1777	loadk        r34   k31 ; k31 = 21
.line	1777	loadk        r35   k32 ; k32 = 18
.line	1777	loadk        r36   k33 ; k33 = 195
.line	1777	loadk        r37   k34 ; k34 = 64
.line	1777	loadk        r38   k35 ; k35 = 23
.line	1777	loadk        r39   k36 ; k36 = 35
.line	1777	loadk        r40   k37 ; k37 = 178
.line	1777	loadk        r41   k38 ; k38 = 119
.line	1777	loadk        r42   k23 ; k23 = 102
.line	1777	loadk        r43   k39 ; k39 = 61
.line	1777	loadk        r44   k30 ; k30 = 125
.line	1777	loadk        r45    k9 ; k9 = 164
.line	1777	loadk        r46   k25 ; k25 = 99
.line	1777	loadk        r47   k40 ; k40 = 127
.line	1777	call          r7    41     2
.line	1777	getupval      r8    u1
.line	1777	loadk         r9   k41 ; k41 = 78
.line	1777	loadk        r10   k42 ; k42 = 22
.line	1777	loadk        r11   k43 ; k43 = 17
.line	1777	loadk        r12   k36 ; k36 = 35
.line	1777	loadk        r13   k44 ; k44 = 185
.line	1777	loadk        r14   k45 ; k45 = 179
.line	1777	loadk        r15   k46 ; k46 = 124
.line	1777	loadk        r16   k47 ; k47 = 82
.line	1777	loadk        r17   k48 ; k48 = 58
.line	1777	loadk        r18   k49 ; k49 = 93
.line	1777	loadk        r19    k6 ; k6 = 68
.line	1777	loadk        r20   k50 ; k50 = 10
.line	1777	loadk        r21   k33 ; k33 = 195
.line	1777	loadk        r22   k51 ; k51 = 74
.line	1777	loadk        r23   k52 ; k52 = 27
.line	1777	loadk        r24   k53 ; k53 = 16
.line	1777	loadk        r25   k54 ; k54 = 191
.line	1777	loadk        r26   k55 ; k55 = 111
.line	1777	loadk        r27   k23 ; k23 = 102
.line	1777	loadk        r28   k56 ; k56 = 1
.line	1777	call          r8    21     0
.line	1777	setlist       r6     0     1
.line	1777	call          r5     2     2
.label	l78
.line	1777	gettabup      r6    u0   k57 ; k57 = "tostring"
.line	1777	move          r7    r1
.line	1777	call          r6     2     0
.line	1777	call          r4     0     1
.line	1777	move          r4    r3
.line	1777	loadnil       r5     0
.line	1777	call          r4     2     1
.line	1777	loadnil       r4     0
.line	1777	return        r4     2
.label	l87
.line	1777	self          r4    r0   k58 ; k58 = "WrapClientUILoadCall" (truncated)
.line	1777	getupval      r6    u1
.line	1777	loadk         r7    k5 ; k5 = 126
.line	1777	loadk         r8   k59 ; k59 = 90
.line	1777	loadk         r9   k60 ; k60 = 11
.line	1777	loadk        r10   k61 ; k61 = 45
.line	1777	loadk        r11   k62 ; k62 = 190
.line	1777	loadk        r12   k63 ; k63 = 183
.line	1777	loadk        r13   k64 ; k64 = 29
.line	1777	loadk        r14   k65 ; k65 = 85
.line	1777	loadk        r15   k48 ; k48 = 58
.line	1777	loadk        r16   k51 ; k51 = 74
.line	1777	loadk        r17   k66 ; k66 = 60
.line	1777	loadk        r18   k19 ; k19 = 38
.line	1777	loadk        r19   k67 ; k67 = 241
.line	1777	loadk        r20   k68 ; k68 = 108
.line	1777	loadk        r21   k42 ; k42 = 22
.line	1777	loadk        r22   k69 ; k69 = 12
.line	1777	call          r6    17     2
.line	1777	move          r7    r1
.line	1777	move          r8    r3
.line	1777	call          r4     5     2
.line	1777	move          r3    r4
.line	1777	gettabup      r4    u0   k70 ; k70 = "type"
.line	1777	move          r5    r1
.line	1777	call          r4     2     2
.line	1777	getupval      r5    u1
.line	1777	loadk         r6   k41 ; k41 = 78
.line	1777	loadk         r7   k71 ; k71 = 66
.line	1777	loadk         r8   k53 ; k53 = 16
.line	1777	loadk         r9   k72 ; k72 = 33
.line	1777	loadk        r10   k62 ; k62 = 190
.line	1777	loadk        r11    k9 ; k9 = 164
.line	1777	call          r5     7     2
.line	1777	eq             0    r4    r5
.line	1777	jmp            0  l127
.line	1777	getupval      r4    u1
.line	1777	call          r4     1     2
.line	1777	eq             0    r1    r4
.line	1777	jmp            0  l213
.label	l127
.line	1777	gettabup      r4    u0    k1 ; k1 = "print"
.line	1777	gettabup      r5    u0    k2 ; k2 = "bWriteLog"
.line	1777	test          r5     0
.line	1777	jmp            0  l207
.line	1777	gettabup      r5    u0    k3 ; k3 = "table"
.line	1777	gettable      r5    r5    k4 ; k4 = "concat"
.line	1777	newtable      r6     1     0
.line	1777	getupval      r7    u1
.line	1777	loadk         r8    k5 ; k5 = 126
.line	1777	loadk         r9    k6 ; k6 = 68
.line	1777	loadk        r10    k7 ; k7 = 7
.line	1777	loadk        r11    k8 ; k8 = 41
.line	1777	loadk        r12    k9 ; k9 = 164
.line	1777	loadk        r13   k10 ; k10 = 170
.line	1777	loadk        r14   k11 ; k11 = 39
.line	1777	loadk        r15   k12 ; k12 = 95
.line	1777	loadk        r16   k13 ; k13 = 24
.line	1777	loadk        r17   k14 ; k14 = 91
.line	1777	loadk        r18   k15 ; k15 = 26
.line	1777	loadk        r19   k16 ; k16 = 31
.line	1777	loadk        r20   k17 ; k17 = 217
.line	1777	loadk        r21   k18 ; k18 = 83
.line	1777	loadk        r22   k19 ; k19 = 38
.line	1777	loadk        r23   k20 ; k20 = 54
.line	1777	loadk        r24   k21 ; k21 = 137
.line	1777	loadk        r25   k22 ; k22 = 103
.line	1777	loadk        r26   k23 ; k23 = 102
.line	1777	loadk        r27   k24 ; k24 = 25
.line	1777	loadk        r28   k25 ; k25 = 99
.line	1777	loadk        r29   k26 ; k26 = 156
.line	1777	loadk        r30   k27 ; k27 = 76
.line	1777	loadk        r31   k28 ; k28 = 122
.line	1777	loadk        r32   k29 ; k29 = 113
.line	1777	loadk        r33   k30 ; k30 = 125
.line	1777	loadk        r34   k31 ; k31 = 21
.line	1777	loadk        r35   k32 ; k32 = 18
.line	1777	loadk        r36   k33 ; k33 = 195
.line	1777	loadk        r37   k34 ; k34 = 64
.line	1777	loadk        r38   k35 ; k35 = 23
.line	1777	loadk        r39   k36 ; k36 = 35
.line	1777	loadk        r40   k37 ; k37 = 178
.line	1777	loadk        r41   k38 ; k38 = 119
.line	1777	loadk        r42   k23 ; k23 = 102
.line	1777	loadk        r43   k39 ; k39 = 61
.line	1777	loadk        r44   k30 ; k30 = 125
.line	1777	loadk        r45    k9 ; k9 = 164
.line	1777	loadk        r46   k25 ; k25 = 99
.line	1777	loadk        r47   k40 ; k40 = 127
.line	1777	call          r7    41     2
.line	1777	getupval      r8    u1
.line	1777	loadk         r9   k41 ; k41 = 78
.line	1777	loadk        r10   k42 ; k42 = 22
.line	1777	loadk        r11   k72 ; k72 = 33
.line	1777	loadk        r12   k39 ; k39 = 61
.line	1777	loadk        r13   k73 ; k73 = 163
.line	1777	loadk        r14   k63 ; k63 = 183
.line	1777	loadk        r15   k74 ; k74 = 62
.line	1777	loadk        r16   k75 ; k75 = 87
.line	1777	loadk        r17   k15 ; k15 = 26
.line	1777	loadk        r18   k49 ; k49 = 93
.line	1777	loadk        r19   k15 ; k15 = 26
.line	1777	loadk        r20   k76 ; k76 = 14
.line	1777	loadk        r21   k77 ; k77 = 194
.line	1777	loadk        r22   k78 ; k78 = 117
.line	1777	loadk        r23   k42 ; k42 = 22
.line	1777	loadk        r24   k79 ; k79 = 6
.line	1777	loadk        r25   k80 ; k80 = 237
.line	1777	loadk        r26   k55 ; k55 = 111
.line	1777	loadk        r27   k81 ; k81 = 97
.line	1777	loadk        r28   k82 ; k82 = 88
.line	1777	loadk        r29   k83 ; k83 = 73
.line	1777	loadk        r30   k84 ; k84 = 157
.line	1777	loadk        r31   k75 ; k75 = 87
.line	1777	loadk        r32   k85 ; k85 = 107
.line	1777	loadk        r33   k11 ; k11 = 39
.line	1777	loadk        r34   k75 ; k75 = 87
.line	1777	loadk        r35   k64 ; k64 = 29
.line	1777	call          r8    28     0
.line	1777	setlist       r6     0     1
.line	1777	call          r5     2     2
.label	l207
.line	1777	call          r4     2     1
.line	1777	move          r4    r3
.line	1777	loadnil       r5     0
.line	1777	call          r4     2     1
.line	1777	loadnil       r4     0
.line	1777	return        r4     2
.label	l213
.line	1777	gettabup      r4    u0   k86 ; k86 = "CustomAssetMgr"
.line	1777	eq             0    r4   k87 ; k87 = nil
.line	1777	jmp            0  l298
.line	1777	gettabup      r4    u0    k1 ; k1 = "print"
.line	1777	gettabup      r5    u0    k2 ; k2 = "bWriteLog"
.line	1777	test          r5     0
.line	1777	jmp            0  l292
.line	1777	gettabup      r5    u0    k3 ; k3 = "table"
.line	1777	gettable      r5    r5    k4 ; k4 = "concat"
.line	1777	newtable      r6     1     0
.line	1777	getupval      r7    u1
.line	1777	loadk         r8    k5 ; k5 = 126
.line	1777	loadk         r9    k6 ; k6 = 68
.line	1777	loadk        r10    k7 ; k7 = 7
.line	1777	loadk        r11    k8 ; k8 = 41
.line	1777	loadk        r12    k9 ; k9 = 164
.line	1777	loadk        r13   k10 ; k10 = 170
.line	1777	loadk        r14   k11 ; k11 = 39
.line	1777	loadk        r15   k12 ; k12 = 95
.line	1777	loadk        r16   k13 ; k13 = 24
.line	1777	loadk        r17   k14 ; k14 = 91
.line	1777	loadk        r18   k15 ; k15 = 26
.line	1777	loadk        r19   k16 ; k16 = 31
.line	1777	loadk        r20   k17 ; k17 = 217
.line	1777	loadk        r21   k18 ; k18 = 83
.line	1777	loadk        r22   k19 ; k19 = 38
.line	1777	loadk        r23   k20 ; k20 = 54
.line	1777	loadk        r24   k21 ; k21 = 137
.line	1777	loadk        r25   k22 ; k22 = 103
.line	1777	loadk        r26   k23 ; k23 = 102
.line	1777	loadk        r27   k24 ; k24 = 25
.line	1777	loadk        r28   k25 ; k25 = 99
.line	1777	loadk        r29   k26 ; k26 = 156
.line	1777	loadk        r30   k27 ; k27 = 76
.line	1777	loadk        r31   k28 ; k28 = 122
.line	1777	loadk        r32   k29 ; k29 = 113
.line	1777	loadk        r33   k30 ; k30 = 125
.line	1777	loadk        r34   k31 ; k31 = 21
.line	1777	loadk        r35   k32 ; k32 = 18
.line	1777	loadk        r36   k33 ; k33 = 195
.line	1777	loadk        r37   k34 ; k34 = 64
.line	1777	loadk        r38   k35 ; k35 = 23
.line	1777	loadk        r39   k36 ; k36 = 35
.line	1777	loadk        r40   k37 ; k37 = 178
.line	1777	loadk        r41   k38 ; k38 = 119
.line	1777	loadk        r42   k23 ; k23 = 102
.line	1777	loadk        r43   k39 ; k39 = 61
.line	1777	loadk        r44   k30 ; k30 = 125
.line	1777	loadk        r45    k9 ; k9 = 164
.line	1777	loadk        r46   k25 ; k25 = 99
.line	1777	loadk        r47   k40 ; k40 = 127
.line	1777	call          r7    41     2
.line	1777	getupval      r8    u1
.line	1777	loadk         r9   k41 ; k41 = 78
.line	1777	loadk        r10   k42 ; k42 = 22
.line	1777	loadk        r11   k72 ; k72 = 33
.line	1777	loadk        r12   k39 ; k39 = 61
.line	1777	loadk        r13   k73 ; k73 = 163
.line	1777	loadk        r14   k63 ; k63 = 183
.line	1777	loadk        r15   k74 ; k74 = 62
.line	1777	loadk        r16   k75 ; k75 = 87
.line	1777	loadk        r17   k15 ; k15 = 26
.line	1777	loadk        r18   k49 ; k49 = 93
.line	1777	loadk        r19   k15 ; k15 = 26
.line	1777	loadk        r20   k76 ; k76 = 14
.line	1777	loadk        r21   k77 ; k77 = 194
.line	1777	loadk        r22   k88 ; k88 = 115
.line	1777	loadk        r23   k89 ; k89 = 20
.line	1777	loadk        r24   k90 ; k90 = 13
.line	1777	loadk        r25   k80 ; k80 = 237
.line	1777	loadk        r26   k55 ; k55 = 111
.line	1777	loadk        r27   k81 ; k81 = 97
.line	1777	loadk        r28   k82 ; k82 = 88
.line	1777	loadk        r29   k41 ; k41 = 78
.line	1777	loadk        r30   k91 ; k91 = 154
.line	1777	loadk        r31   k92 ; k92 = 77
.line	1777	call          r8    24     0
.line	1777	setlist       r6     0     1
.line	1777	call          r5     2     2
.label	l292
.line	1777	call          r4     2     1
.line	1777	move          r4    r3
.line	1777	loadnil       r5     0
.line	1777	call          r4     2     1
.line	1777	loadnil       r4     0
.line	1777	return        r4     2
.label	l298
.line	1777	gettable      r4    r0   k93 ; k93 = "_AsyncLoadSeq"
.line	1777	test          r4     1
.line	1777	jmp            0  l302
.line	1777	loadk         r4   k94 ; k94 = 0
.label	l302
.line	1777	add           r4    r4   k56 ; k56 = 1
.line	1777	settable      r0   k93    r4 ; k93 = "_AsyncLoadSeq"
.line	1777	gettable      r4    r0   k93 ; k93 = "_AsyncLoadSeq"
.line	1777	gettabup      r5    u0    k1 ; k1 = "print"
.line	1777	gettabup      r6    u0    k2 ; k2 = "bWriteLog"
.line	1777	test          r6     0
.line	1777	jmp            0  l365
.line	1777	gettabup      r6    u0    k3 ; k3 = "table"
.line	1777	gettable      r6    r6    k4 ; k4 = "concat"
.line	1777	newtable      r7     1     0
.line	1777	getupval      r8    u1
.line	1777	loadk         r9    k5 ; k5 = 126
.line	1777	loadk        r10    k6 ; k6 = 68
.line	1777	loadk        r11    k7 ; k7 = 7
.line	1777	loadk        r12    k8 ; k8 = 41
.line	1777	loadk        r13    k9 ; k9 = 164
.line	1777	loadk        r14   k10 ; k10 = 170
.line	1777	loadk        r15   k11 ; k11 = 39
.line	1777	loadk        r16   k12 ; k12 = 95
.line	1777	loadk        r17   k13 ; k13 = 24
.line	1777	loadk        r18   k14 ; k14 = 91
.line	1777	loadk        r19   k15 ; k15 = 26
.line	1777	loadk        r20   k16 ; k16 = 31
.line	1777	loadk        r21   k17 ; k17 = 217
.line	1777	loadk        r22   k18 ; k18 = 83
.line	1777	loadk        r23   k19 ; k19 = 38
.line	1777	loadk        r24   k20 ; k20 = 54
.line	1777	loadk        r25   k21 ; k21 = 137
.line	1777	loadk        r26   k22 ; k22 = 103
.line	1777	loadk        r27   k23 ; k23 = 102
.line	1777	loadk        r28   k24 ; k24 = 25
.line	1777	loadk        r29   k25 ; k25 = 99
.line	1777	loadk        r30   k26 ; k26 = 156
.line	1777	loadk        r31   k27 ; k27 = 76
.line	1777	loadk        r32   k28 ; k28 = 122
.line	1777	loadk        r33   k29 ; k29 = 113
.line	1777	loadk        r34   k30 ; k30 = 125
.line	1777	loadk        r35   k31 ; k31 = 21
.line	1777	loadk        r36   k32 ; k32 = 18
.line	1777	loadk        r37   k33 ; k33 = 195
.line	1777	loadk        r38   k34 ; k34 = 64
.line	1777	loadk        r39   k35 ; k35 = 23
.line	1777	loadk        r40   k36 ; k36 = 35
.line	1777	loadk        r41   k37 ; k37 = 178
.line	1777	loadk        r42   k38 ; k38 = 119
.line	1777	loadk        r43   k23 ; k23 = 102
.line	1777	loadk        r44   k39 ; k39 = 61
.line	1777	loadk        r45   k30 ; k30 = 125
.line	1777	loadk        r46    k9 ; k9 = 164
.line	1777	loadk        r47   k25 ; k25 = 99
.line	1777	loadk        r48   k40 ; k40 = 127
.line	1777	call          r8    41     2
.line	1777	getupval      r9    u1
.line	1777	loadk        r10   k41 ; k41 = 78
.line	1777	loadk        r11   k42 ; k42 = 22
.line	1777	loadk        r12   k94 ; k94 = 0
.line	1777	loadk        r13   k61 ; k61 = 45
.line	1777	loadk        r14   k63 ; k63 = 183
.line	1777	loadk        r15   k10 ; k10 = 170
.line	1777	loadk        r16   k95 ; k95 = 63
.line	1777	call          r9     8     0
.line	1777	setlist       r7     0     1
.line	1777	call          r6     2     2
.label	l365
.line	1777	gettabup      r7    u0   k57 ; k57 = "tostring"
.line	1777	move          r8    r1
.line	1777	call          r7     2     2
.line	1777	getupval      r8    u1
.line	1777	loadk         r9   k46 ; k46 = 124
.line	1777	loadk        r10   k96 ; k96 = 69
.line	1777	loadk        r11   k52 ; k52 = 27
.line	1777	loadk        r12   k19 ; k19 = 38
.line	1777	loadk        r13   k45 ; k45 = 179
.line	1777	loadk        r14   k97 ; k97 = 144
.line	1777	loadk        r15   k98 ; k98 = 52
.line	1777	loadk        r16   k99 ; k99 = 75
.line	1777	loadk        r17   k81 ; k81 = 97
.line	1777	call          r8    10     2
.line	1777	gettabup      r9    u0   k57 ; k57 = "tostring"
.line	1777	move         r10    r4
.line	1777	call          r9     2     0
.line	1777	call          r5     0     1
.line	1777	self          r5    r0  k100 ; k100 = "_DownloadAndUnpackIn" (truncated)
.line	1777	move          r7    r1
.line	1777	move          r8    r4
.line	1777	closure       r9    f0
.line	1777	call          r5     5     1
.line	1777	return        r4     2
.line	1777	return        r0     1
.line	1777	move          r0    r0
.line	1777	move          r0    r0
.line	1777	move          r0    r0
.line	1777	return        r0     1

.function	main/f80/f0

.source	null
.linedefined	1797
.lastlinedefined	1830
.numparams	1
.is_vararg	0
.maxstacksize	53

.upvalue	"_ENV"	0	true
.upvalue	"U1"	1	true
.upvalue	"U2"	2	true
.upvalue	"U3"	0	false
.upvalue	"U4"	1	false
.upvalue	"U5"	3	true

.constant	k0	"_BuildDynamicCanvasFromBinTable"
.constant	k1	"print"
.constant	k2	"bWriteLog"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	126
.constant	k6	68
.constant	k7	7
.constant	k8	41
.constant	k9	164
.constant	k10	170
.constant	k11	39
.constant	k12	95
.constant	k13	24
.constant	k14	91
.constant	k15	26
.constant	k16	31
.constant	k17	217
.constant	k18	83
.constant	k19	38
.constant	k20	54
.constant	k21	137
.constant	k22	103
.constant	k23	102
.constant	k24	25
.constant	k25	99
.constant	k26	156
.constant	k27	76
.constant	k28	122
.constant	k29	113
.constant	k30	125
.constant	k31	21
.constant	k32	18
.constant	k33	195
.constant	k34	64
.constant	k35	23
.constant	k36	35
.constant	k37	178
.constant	k38	119
.constant	k39	61
.constant	k40	127
.constant	k41	78
.constant	k42	22
.constant	k43	0
.constant	k44	185
.constant	k45	175
.constant	k46	53
.constant	k47	56
.constant	k48	79
.constant	k49	29
.constant	k50	215
.constant	k51	77
.constant	k52	94
.constant	k53	172
.constant	k54	111
.constant	k55	"tostring"
.constant	k56	"CDORuntimeCount"
.constant	k57	1
.constant	k58	"CloneCDOToRuntime"
.constant	k59	36
.constant	k60	191
.constant	k61	173
.constant	k62	52
.constant	k63	211
.constant	k64	90
.constant	k65	"RegisterCanvasReadyCallback"
.constant	k66	"pairs"
.constant	k67	"CustomUIData"
.constant	k68	"RegisterInstanceIndex"
.constant	k69	"NotifyTalentNodeLanded"
.constant	k70	"ClientTryLoadCustomUIObject"
.constant	k71	"PendingLoadRuntimeIds"
.constant	k72	"GetWidgetObjectByRuntimeId"
.constant	k73	nil
.constant	k74	"FireCanvasReadyCallbacks"
.constant	k75	"string"
.constant	k76	"format"
.constant	k77	14
.constant	k78	190
.constant	k79	167
.constant	k80	123
.constant	k81	109
.constant	k82	28
.constant	k83	194
.constant	k84	81
.constant	k85	30
.constant	k86	62
.constant	k87	117
.constant	k88	12
.constant	k89	107
.constant	k90	150
.constant	k91	88
.constant	k92	55
.constant	k93	110
.constant	k94	89
.constant	k95	6
.constant	k96	176
.constant	k97	115
.constant	k98	65
.constant	k99	9
.constant	k100	149
.constant	k101	80
.constant	k102	105
.constant	k103	116
.constant	k104	82
.constant	k105	163
.constant	k106	227
.constant	k107	5
.constant	k108	60
.constant	k109	19

.line	1797	getupval      r1    u0
.line	1797	self          r1    r1    k0 ; k0 = "_BuildDynamicCanvasF" (truncated)
.line	1797	move          r3    r0
.line	1797	getupval      r4    u1
.line	1797	getupval      r5    u2
.line	1797	call          r1     5     2
.line	1797	test          r1     1
.line	1797	jmp            0   l91
.line	1797	gettabup      r2    u3    k1 ; k1 = "print"
.line	1797	gettabup      r3    u3    k2 ; k2 = "bWriteLog"
.line	1797	test          r3     0
.line	1797	jmp            0   l83
.line	1797	gettabup      r3    u3    k3 ; k3 = "table"
.line	1797	gettable      r3    r3    k4 ; k4 = "concat"
.line	1797	newtable      r4     1     0
.line	1797	getupval      r5    u4
.line	1797	loadk         r6    k5 ; k5 = 126
.line	1797	loadk         r7    k6 ; k6 = 68
.line	1797	loadk         r8    k7 ; k7 = 7
.line	1797	loadk         r9    k8 ; k8 = 41
.line	1797	loadk        r10    k9 ; k9 = 164
.line	1797	loadk        r11   k10 ; k10 = 170
.line	1797	loadk        r12   k11 ; k11 = 39
.line	1797	loadk        r13   k12 ; k12 = 95
.line	1797	loadk        r14   k13 ; k13 = 24
.line	1797	loadk        r15   k14 ; k14 = 91
.line	1797	loadk        r16   k15 ; k15 = 26
.line	1797	loadk        r17   k16 ; k16 = 31
.line	1797	loadk        r18   k17 ; k17 = 217
.line	1797	loadk        r19   k18 ; k18 = 83
.line	1797	loadk        r20   k19 ; k19 = 38
.line	1797	loadk        r21   k20 ; k20 = 54
.line	1797	loadk        r22   k21 ; k21 = 137
.line	1797	loadk        r23   k22 ; k22 = 103
.line	1797	loadk        r24   k23 ; k23 = 102
.line	1797	loadk        r25   k24 ; k24 = 25
.line	1797	loadk        r26   k25 ; k25 = 99
.line	1797	loadk        r27   k26 ; k26 = 156
.line	1797	loadk        r28   k27 ; k27 = 76
.line	1797	loadk        r29   k28 ; k28 = 122
.line	1797	loadk        r30   k29 ; k29 = 113
.line	1797	loadk        r31   k30 ; k30 = 125
.line	1797	loadk        r32   k31 ; k31 = 21
.line	1797	loadk        r33   k32 ; k32 = 18
.line	1797	loadk        r34   k33 ; k33 = 195
.line	1797	loadk        r35   k34 ; k34 = 64
.line	1797	loadk        r36   k35 ; k35 = 23
.line	1797	loadk        r37   k36 ; k36 = 35
.line	1797	loadk        r38   k37 ; k37 = 178
.line	1797	loadk        r39   k38 ; k38 = 119
.line	1797	loadk        r40   k23 ; k23 = 102
.line	1797	loadk        r41   k39 ; k39 = 61
.line	1797	loadk        r42   k30 ; k30 = 125
.line	1797	loadk        r43    k9 ; k9 = 164
.line	1797	loadk        r44   k25 ; k25 = 99
.line	1797	loadk        r45   k40 ; k40 = 127
.line	1797	call          r5    41     2
.line	1797	getupval      r6    u4
.line	1797	loadk         r7   k41 ; k41 = 78
.line	1797	loadk         r8   k42 ; k42 = 22
.line	1797	loadk         r9   k43 ; k43 = 0
.line	1797	loadk        r10   k39 ; k39 = 61
.line	1797	loadk        r11   k44 ; k44 = 185
.line	1797	loadk        r12   k45 ; k45 = 175
.line	1797	loadk        r13   k46 ; k46 = 53
.line	1797	loadk        r14   k35 ; k35 = 23
.line	1797	loadk        r15   k47 ; k47 = 56
.line	1797	loadk        r16   k48 ; k48 = 79
.line	1797	loadk        r17    k7 ; k7 = 7
.line	1797	loadk        r18   k49 ; k49 = 29
.line	1797	loadk        r19   k50 ; k50 = 215
.line	1797	loadk        r20   k51 ; k51 = 77
.line	1797	loadk        r21   k52 ; k52 = 94
.line	1797	loadk        r22   k24 ; k24 = 25
.line	1797	loadk        r23   k53 ; k53 = 172
.line	1797	loadk        r24   k54 ; k54 = 111
.line	1797	loadk        r25    k5 ; k5 = 126
.line	1797	loadk        r26   k49 ; k49 = 29
.line	1797	loadk        r27    k6 ; k6 = 68
.line	1797	call          r6    22     0
.line	1797	setlist       r4     0     1
.line	1797	call          r3     2     2
.label	l83
.line	1797	gettabup      r4    u3   k55 ; k55 = "tostring"
.line	1797	getupval      r5    u1
.line	1797	call          r4     2     0
.line	1797	call          r2     0     1
.line	1797	getupval      r2    u5
.line	1797	loadnil       r3     0
.line	1797	call          r2     2     1
.line	1797	return        r0     1
.label	l91
.line	1797	gettabup      r2    u0   k56 ; k56 = "CDORuntimeCount"
.line	1797	gettable      r2    r2    r1
.line	1797	test          r2     1
.line	1797	jmp            0   l96
.line	1797	loadk         r2   k43 ; k43 = 0
.label	l96
.line	1797	add           r2    r2   k57 ; k57 = 1
.line	1797	getupval      r3    u0
.line	1797	self          r3    r3   k58 ; k58 = "CloneCDOToRuntime"
.line	1797	move          r5    r1
.line	1797	move          r6    r0
.line	1797	move          r7    r2
.line	1797	getupval      r8    u4
.line	1797	loadk         r9    k5 ; k5 = 126
.line	1797	call          r8     2     2
.line	1797	call          r3     6     3
.line	1797	testset       r5    r3     0
.line	1797	jmp            0  l109
.line	1797	gettable      r5    r3    r1
.label	l109
.line	1797	test          r5     0
.line	1797	jmp            0  l116
.line	1797	test          r4     0
.line	1797	jmp            0  l116
.line	1797	gettable      r6    r4    r5
.line	1797	test          r6     1
.line	1797	jmp            0  l191
.label	l116
.line	1797	gettabup      r6    u3    k1 ; k1 = "print"
.line	1797	gettabup      r7    u3    k2 ; k2 = "bWriteLog"
.line	1797	test          r7     0
.line	1797	jmp            0  l183
.line	1797	gettabup      r7    u3    k3 ; k3 = "table"
.line	1797	gettable      r7    r7    k4 ; k4 = "concat"
.line	1797	newtable      r8     1     0
.line	1797	getupval      r9    u4
.line	1797	loadk        r10    k5 ; k5 = 126
.line	1797	loadk        r11    k6 ; k6 = 68
.line	1797	loadk        r12    k7 ; k7 = 7
.line	1797	loadk        r13    k8 ; k8 = 41
.line	1797	loadk        r14    k9 ; k9 = 164
.line	1797	loadk        r15   k10 ; k10 = 170
.line	1797	loadk        r16   k11 ; k11 = 39
.line	1797	loadk        r17   k12 ; k12 = 95
.line	1797	loadk        r18   k13 ; k13 = 24
.line	1797	loadk        r19   k14 ; k14 = 91
.line	1797	loadk        r20   k15 ; k15 = 26
.line	1797	loadk        r21   k16 ; k16 = 31
.line	1797	loadk        r22   k17 ; k17 = 217
.line	1797	loadk        r23   k18 ; k18 = 83
.line	1797	loadk        r24   k19 ; k19 = 38
.line	1797	loadk        r25   k20 ; k20 = 54
.line	1797	loadk        r26   k21 ; k21 = 137
.line	1797	loadk        r27   k22 ; k22 = 103
.line	1797	loadk        r28   k23 ; k23 = 102
.line	1797	loadk        r29   k24 ; k24 = 25
.line	1797	loadk        r30   k25 ; k25 = 99
.line	1797	loadk        r31   k26 ; k26 = 156
.line	1797	loadk        r32   k27 ; k27 = 76
.line	1797	loadk        r33   k28 ; k28 = 122
.line	1797	loadk        r34   k29 ; k29 = 113
.line	1797	loadk        r35   k30 ; k30 = 125
.line	1797	loadk        r36   k31 ; k31 = 21
.line	1797	loadk        r37   k32 ; k32 = 18
.line	1797	loadk        r38   k33 ; k33 = 195
.line	1797	loadk        r39   k34 ; k34 = 64
.line	1797	loadk        r40   k35 ; k35 = 23
.line	1797	loadk        r41   k36 ; k36 = 35
.line	1797	loadk        r42   k37 ; k37 = 178
.line	1797	loadk        r43   k38 ; k38 = 119
.line	1797	loadk        r44   k23 ; k23 = 102
.line	1797	loadk        r45   k39 ; k39 = 61
.line	1797	loadk        r46   k30 ; k30 = 125
.line	1797	loadk        r47    k9 ; k9 = 164
.line	1797	loadk        r48   k25 ; k25 = 99
.line	1797	loadk        r49   k40 ; k40 = 127
.line	1797	call          r9    41     2
.line	1797	getupval     r10    u4
.line	1797	loadk        r11   k41 ; k41 = 78
.line	1797	loadk        r12   k42 ; k42 = 22
.line	1797	loadk        r13   k57 ; k57 = 1
.line	1797	loadk        r14   k59 ; k59 = 36
.line	1797	loadk        r15   k60 ; k60 = 191
.line	1797	loadk        r16   k61 ; k61 = 173
.line	1797	loadk        r17   k62 ; k62 = 52
.line	1797	loadk        r18   k35 ; k35 = 23
.line	1797	loadk        r19   k39 ; k39 = 61
.line	1797	loadk        r20   k48 ; k48 = 79
.line	1797	loadk        r21   k43 ; k43 = 0
.line	1797	loadk        r22    k7 ; k7 = 7
.line	1797	loadk        r23   k63 ; k63 = 211
.line	1797	loadk        r24   k64 ; k64 = 90
.line	1797	call         r10    15     0
.line	1797	setlist       r8     0     1
.line	1797	call          r7     2     2
.label	l183
.line	1797	gettabup      r8    u3   k55 ; k55 = "tostring"
.line	1797	getupval      r9    u1
.line	1797	call          r8     2     0
.line	1797	call          r6     0     1
.line	1797	getupval      r6    u5
.line	1797	loadnil       r7     0
.line	1797	call          r6     2     1
.line	1797	return        r0     1
.label	l191
.line	1797	gettabup      r6    u0   k56 ; k56 = "CDORuntimeCount"
.line	1797	settable      r6    r1    r2
.line	1797	gettable      r6    r4    r5
.line	1797	getupval      r7    u0
.line	1797	self          r7    r7   k65 ; k65 = "RegisterCanvasReadyC" (truncated)
.line	1797	move          r9    r5
.line	1797	getupval     r10    u5
.line	1797	call          r7     4     1
.line	1797	gettabup      r7    u3   k66 ; k66 = "pairs"
.line	1797	move          r8    r4
.line	1797	call          r7     2     4
.line	1797	jmp            0  l222
.line	1797	eq             1   r10    r5
.line	1797	jmp            0  l222
.line	1797	gettabup     r12    u0   k67 ; k67 = "CustomUIData"
.line	1797	settable     r12   r10   r11
.line	1797	getupval     r12    u0
.line	1797	self         r12   r12   k68 ; k68 = "RegisterInstanceInde" (truncated)
.line	1797	move         r14   r10
.line	1797	move         r15   r11
.line	1797	call         r12     4     1
.line	1797	getupval     r12    u0
.line	1797	self         r12   r12   k69 ; k69 = "NotifyTalentNodeLand" (truncated)
.line	1797	move         r14   r10
.line	1797	move         r15   r11
.line	1797	call         r12     4     1
.line	1797	getupval     r12    u0
.line	1797	self         r12   r12   k70 ; k70 = "ClientTryLoadCustomU" (truncated)
.line	1797	move         r14   r10
.line	1797	move         r15   r11
.line	1797	call         r12     4     1
.label	l222
.line	1797	move          r0    r0
.line	1797	move          r0    r0
.line	1797	gettabup      r7    u0   k67 ; k67 = "CustomUIData"
.line	1797	settable      r7    r5    r6
.line	1797	getupval      r7    u0
.line	1797	self          r7    r7   k68 ; k68 = "RegisterInstanceInde" (truncated)
.line	1797	move          r9    r5
.line	1797	move         r10    r6
.line	1797	call          r7     4     1
.line	1797	getupval      r7    u0
.line	1797	self          r7    r7   k70 ; k70 = "ClientTryLoadCustomU" (truncated)
.line	1797	move          r9    r5
.line	1797	move         r10    r6
.line	1797	call          r7     4     1
.line	1797	gettabup      r7    u0   k71 ; k71 = "PendingLoadRuntimeId" (truncated)
.line	1797	test          r7     0
.line	1797	jmp            0  l243
.line	1797	gettabup      r7    u0   k71 ; k71 = "PendingLoadRuntimeId" (truncated)
.line	1797	gettable      r7    r7    r5
.line	1797	test          r7     1
.line	1797	jmp            0  l254
.label	l243
.line	1797	getupval      r7    u0
.line	1797	self          r7    r7   k72 ; k72 = "GetWidgetObjectByRun" (truncated)
.line	1797	move          r9    r5
.line	1797	call          r7     3     2
.line	1797	eq             0    r7   k73 ; k73 = nil
.line	1797	jmp            0  l254
.line	1797	getupval      r7    u0
.line	1797	self          r7    r7   k74 ; k74 = "FireCanvasReadyCallb" (truncated)
.line	1797	move          r9    r5
.line	1797	loadnil      r10     0
.line	1797	call          r7     4     1
.label	l254
.line	1797	gettabup      r7    u3    k1 ; k1 = "print"
.line	1797	gettabup      r8    u3    k2 ; k2 = "bWriteLog"
.line	1797	test          r8     0
.line	1797	jmp            0  l373
.line	1797	gettabup      r8    u3   k75 ; k75 = "string"
.line	1797	gettable      r8    r8   k76 ; k76 = "format"
.line	1797	gettabup      r9    u3    k3 ; k3 = "table"
.line	1797	gettable      r9    r9    k4 ; k4 = "concat"
.line	1797	newtable     r10     2     0
.line	1797	getupval     r11    u4
.line	1797	loadk        r12    k5 ; k5 = 126
.line	1797	loadk        r13    k6 ; k6 = 68
.line	1797	loadk        r14    k7 ; k7 = 7
.line	1797	loadk        r15    k8 ; k8 = 41
.line	1797	loadk        r16    k9 ; k9 = 164
.line	1797	loadk        r17   k10 ; k10 = 170
.line	1797	loadk        r18   k11 ; k11 = 39
.line	1797	loadk        r19   k12 ; k12 = 95
.line	1797	loadk        r20   k13 ; k13 = 24
.line	1797	loadk        r21   k14 ; k14 = 91
.line	1797	loadk        r22   k15 ; k15 = 26
.line	1797	loadk        r23   k16 ; k16 = 31
.line	1797	loadk        r24   k17 ; k17 = 217
.line	1797	loadk        r25   k18 ; k18 = 83
.line	1797	loadk        r26   k19 ; k19 = 38
.line	1797	loadk        r27   k20 ; k20 = 54
.line	1797	loadk        r28   k21 ; k21 = 137
.line	1797	loadk        r29   k22 ; k22 = 103
.line	1797	loadk        r30   k23 ; k23 = 102
.line	1797	loadk        r31   k24 ; k24 = 25
.line	1797	loadk        r32   k25 ; k25 = 99
.line	1797	loadk        r33   k26 ; k26 = 156
.line	1797	loadk        r34   k27 ; k27 = 76
.line	1797	loadk        r35   k28 ; k28 = 122
.line	1797	loadk        r36   k29 ; k29 = 113
.line	1797	loadk        r37   k30 ; k30 = 125
.line	1797	loadk        r38   k31 ; k31 = 21
.line	1797	loadk        r39   k32 ; k32 = 18
.line	1797	loadk        r40   k33 ; k33 = 195
.line	1797	loadk        r41   k34 ; k34 = 64
.line	1797	loadk        r42   k35 ; k35 = 23
.line	1797	loadk        r43   k36 ; k36 = 35
.line	1797	loadk        r44   k37 ; k37 = 178
.line	1797	loadk        r45   k38 ; k38 = 119
.line	1797	loadk        r46   k23 ; k23 = 102
.line	1797	loadk        r47   k39 ; k39 = 61
.line	1797	loadk        r48   k30 ; k30 = 125
.line	1797	loadk        r49    k9 ; k9 = 164
.line	1797	loadk        r50   k25 ; k25 = 99
.line	1797	loadk        r51   k40 ; k40 = 127
.line	1797	call         r11    41     2
.line	1797	getupval     r12    u4
.line	1797	loadk        r13   k41 ; k41 = 78
.line	1797	loadk        r14   k42 ; k42 = 22
.line	1797	loadk        r15   k77 ; k77 = 14
.line	1797	loadk        r16    k8 ; k8 = 41
.line	1797	loadk        r17   k78 ; k78 = 190
.line	1797	loadk        r18   k79 ; k79 = 167
.line	1797	loadk        r19   k62 ; k62 = 52
.line	1797	loadk        r20   k52 ; k52 = 94
.line	1797	loadk        r21   k80 ; k80 = 123
.line	1797	loadk        r22   k81 ; k81 = 109
.line	1797	loadk        r23   k82 ; k82 = 28
.line	1797	loadk        r24   k13 ; k13 = 24
.line	1797	loadk        r25   k83 ; k83 = 194
.line	1797	loadk        r26   k84 ; k84 = 81
.line	1797	loadk        r27   k85 ; k85 = 30
.line	1797	loadk        r28   k86 ; k86 = 62
.line	1797	loadk        r29   k78 ; k78 = 190
.line	1797	loadk        r30   k87 ; k87 = 117
.line	1797	loadk        r31   k38 ; k38 = 119
.line	1797	loadk        r32   k88 ; k88 = 12
.line	1797	loadk        r33   k89 ; k89 = 107
.line	1797	loadk        r34   k90 ; k90 = 150
.line	1797	loadk        r35   k91 ; k91 = 88
.line	1797	loadk        r36   k92 ; k92 = 55
.line	1797	loadk        r37   k93 ; k93 = 110
.line	1797	loadk        r38   k51 ; k51 = 77
.line	1797	loadk        r39   k94 ; k94 = 89
.line	1797	loadk        r40    k8 ; k8 = 41
.line	1797	loadk        r41   k63 ; k63 = 211
.line	1797	loadk        r42   k34 ; k34 = 64
.line	1797	loadk        r43   k35 ; k35 = 23
.line	1797	loadk        r44   k95 ; k95 = 6
.line	1797	loadk        r45   k96 ; k96 = 176
.line	1797	loadk        r46   k97 ; k97 = 115
.line	1797	loadk        r47   k98 ; k98 = 65
.line	1797	loadk        r48   k99 ; k99 = 9
.line	1797	loadk        r49   k52 ; k52 = 94
.line	1797	loadk        r50  k100 ; k100 = 149
.line	1797	loadk        r51  k101 ; k101 = 80
.line	1797	loadk        r52  k102 ; k102 = 105
.line	1797	call         r12    41     2
.line	1797	getupval     r13    u4
.line	1797	loadk        r14  k103 ; k103 = 116
.line	1797	loadk        r15  k104 ; k104 = 82
.line	1797	loadk        r16   k12 ; k12 = 95
.line	1797	loadk        r17   k81 ; k81 = 109
.line	1797	loadk        r18  k105 ; k105 = 163
.line	1797	loadk        r19  k106 ; k106 = 227
.line	1797	loadk        r20  k107 ; k107 = 5
.line	1797	loadk        r21   k14 ; k14 = 91
.line	1797	loadk        r22  k108 ; k108 = 60
.line	1797	loadk        r23  k109 ; k109 = 19
.line	1797	loadk        r24   k27 ; k27 = 76
.line	1797	loadk        r25   k13 ; k13 = 24
.line	1797	call         r13    13     0
.line	1797	setlist      r10     0     1
.line	1797	call          r9     2     2
.line	1797	gettabup     r10    u3   k55 ; k55 = "tostring"
.line	1797	getupval     r11    u1
.line	1797	call         r10     2     2
.line	1797	gettabup     r11    u3   k55 ; k55 = "tostring"
.line	1797	move         r12    r5
.line	1797	call         r11     2     2
.line	1797	gettabup     r12    u3   k55 ; k55 = "tostring"
.line	1797	getupval     r13    u2
.line	1797	call         r12     2     0
.line	1797	call          r8     0     2
.label	l373
.line	1797	call          r7     2     1
.line	1797	return        r0     1
.line	1797	move          r0    r0
.line	1797	move          r0    r0
.line	1797	move          r0    r0
.line	1797	return        r0     1

.function	main/f81

.source	null
.linedefined	1834
.lastlinedefined	1859
.numparams	2
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"GetCreativeUMGInfoManager"
.constant	k1	nil
.constant	k2	"tostring"
.constant	k3	"tonumber"
.constant	k4	"GetUMGInfoTree"
.constant	k5	"next"
.constant	k6	"print"
.constant	k7	"bWriteLog"
.constant	k8	"table"
.constant	k9	"concat"
.constant	k10	126
.constant	k11	68
.constant	k12	7
.constant	k13	41
.constant	k14	164
.constant	k15	170
.constant	k16	39
.constant	k17	95
.constant	k18	24
.constant	k19	91
.constant	k20	26
.constant	k21	31
.constant	k22	217
.constant	k23	83
.constant	k24	38
.constant	k25	54
.constant	k26	137
.constant	k27	103
.constant	k28	102
.constant	k29	25
.constant	k30	99
.constant	k31	156
.constant	k32	76
.constant	k33	122
.constant	k34	113
.constant	k35	97
.constant	k36	62
.constant	k37	30
.constant	k38	210
.constant	k39	2
.constant	k40	158
.constant	k41	119
.constant	k42	108
.constant	k43	81
.constant	k44	144
.constant	k45	98
.constant	k46	117
.constant	k47	72
.constant	k48	1
.constant	k49	45
.constant	k50	240
.constant	k51	36
.constant	k52	88
.constant	k53	15
.constant	k54	92
.constant	k55	12
.constant	k56	14
.constant	k57	150
.constant	k58	190
.constant	k59	111
.constant	k60	124
.constant	k61	"UMGCanvasInfo"
.constant	k62	"CustomUIBase"
.constant	k63	173
.constant	k64	78
.constant	k65	123
.constant	k66	79
.constant	k67	73
.constant	k68	8
.constant	k69	215
.constant	k70	80
.constant	k71	5

.line	1834	gettabup      r2    u0    k0 ; k0 = "GetCreativeUMGInfoMa" (truncated)
.line	1834	call          r2     1     2
.line	1834	eq             0    r2    k1 ; k1 = nil
.line	1834	jmp            0    l7
.line	1834	loadnil       r3     0
.line	1834	return        r3     2
.label	l7
.line	1834	gettabup      r3    u0    k2 ; k2 = "tostring"
.line	1834	move          r4    r1
.line	1834	call          r3     2     2
.line	1834	gettabup      r4    u0    k3 ; k3 = "tonumber"
.line	1834	move          r5    r3
.line	1834	call          r4     2     2
.line	1834	self          r5    r2    k4 ; k4 = "GetUMGInfoTree"
.line	1834	move          r7    r3
.line	1834	call          r5     3     2
.line	1834	test          r5     1
.line	1834	jmp            0   l24
.line	1834	eq             1    r4    k1 ; k1 = nil
.line	1834	jmp            0   l24
.line	1834	self          r6    r2    k4 ; k4 = "GetUMGInfoTree"
.line	1834	move          r8    r4
.line	1834	call          r6     3     2
.line	1834	move          r5    r6
.label	l24
.line	1834	test          r5     0
.line	1834	jmp            0   l31
.line	1834	gettabup      r6    u0    k5 ; k5 = "next"
.line	1834	move          r7    r5
.line	1834	call          r6     2     2
.line	1834	test          r6     1
.line	1834	jmp            0  l108
.label	l31
.line	1834	gettabup      r6    u0    k6 ; k6 = "print"
.line	1834	gettabup      r7    u0    k7 ; k7 = "bWriteLog"
.line	1834	test          r7     0
.line	1834	jmp            0  l104
.line	1834	gettabup      r7    u0    k8 ; k8 = "table"
.line	1834	gettable      r7    r7    k9 ; k9 = "concat"
.line	1834	newtable      r8     1     0
.line	1834	getupval      r9    u1
.line	1834	loadk        r10   k10 ; k10 = 126
.line	1834	loadk        r11   k11 ; k11 = 68
.line	1834	loadk        r12   k12 ; k12 = 7
.line	1834	loadk        r13   k13 ; k13 = 41
.line	1834	loadk        r14   k14 ; k14 = 164
.line	1834	loadk        r15   k15 ; k15 = 170
.line	1834	loadk        r16   k16 ; k16 = 39
.line	1834	loadk        r17   k17 ; k17 = 95
.line	1834	loadk        r18   k18 ; k18 = 24
.line	1834	loadk        r19   k19 ; k19 = 91
.line	1834	loadk        r20   k20 ; k20 = 26
.line	1834	loadk        r21   k21 ; k21 = 31
.line	1834	loadk        r22   k22 ; k22 = 217
.line	1834	loadk        r23   k23 ; k23 = 83
.line	1834	loadk        r24   k24 ; k24 = 38
.line	1834	loadk        r25   k25 ; k25 = 54
.line	1834	loadk        r26   k26 ; k26 = 137
.line	1834	loadk        r27   k27 ; k27 = 103
.line	1834	loadk        r28   k28 ; k28 = 102
.line	1834	loadk        r29   k29 ; k29 = 25
.line	1834	loadk        r30   k30 ; k30 = 99
.line	1834	loadk        r31   k31 ; k31 = 156
.line	1834	loadk        r32   k32 ; k32 = 76
.line	1834	loadk        r33   k33 ; k33 = 122
.line	1834	loadk        r34   k34 ; k34 = 113
.line	1834	loadk        r35   k35 ; k35 = 97
.line	1834	loadk        r36   k36 ; k36 = 62
.line	1834	loadk        r37   k37 ; k37 = 30
.line	1834	loadk        r38   k38 ; k38 = 210
.line	1834	loadk        r39   k30 ; k30 = 99
.line	1834	loadk        r40   k39 ; k39 = 2
.line	1834	loadk        r41   k21 ; k21 = 31
.line	1834	loadk        r42   k40 ; k40 = 158
.line	1834	loadk        r43   k41 ; k41 = 119
.line	1834	loadk        r44   k42 ; k42 = 108
.line	1834	loadk        r45   k37 ; k37 = 30
.line	1834	loadk        r46   k43 ; k43 = 81
.line	1834	loadk        r47   k44 ; k44 = 144
.line	1834	loadk        r48   k45 ; k45 = 98
.line	1834	loadk        r49   k46 ; k46 = 117
.line	1834	call          r9    41     2
.line	1834	getupval     r10    u1
.line	1834	loadk        r11   k47 ; k47 = 72
.line	1834	loadk        r12   k11 ; k11 = 68
.line	1834	loadk        r13   k48 ; k48 = 1
.line	1834	loadk        r14   k49 ; k49 = 45
.line	1834	loadk        r15   k50 ; k50 = 240
.line	1834	loadk        r16   k44 ; k44 = 144
.line	1834	loadk        r17   k51 ; k51 = 36
.line	1834	loadk        r18   k52 ; k52 = 88
.line	1834	loadk        r19   k53 ; k53 = 15
.line	1834	loadk        r20   k54 ; k54 = 92
.line	1834	loadk        r21   k55 ; k55 = 12
.line	1834	loadk        r22   k56 ; k56 = 14
.line	1834	loadk        r23   k57 ; k57 = 150
.line	1834	loadk        r24   k23 ; k23 = 83
.line	1834	loadk        r25   k20 ; k20 = 26
.line	1834	loadk        r26   k55 ; k55 = 12
.line	1834	loadk        r27   k58 ; k58 = 190
.line	1834	loadk        r28   k59 ; k59 = 111
.line	1834	loadk        r29   k60 ; k60 = 124
.line	1834	loadk        r30   k21 ; k21 = 31
.line	1834	call         r10    21     0
.line	1834	setlist       r8     0     1
.line	1834	call          r7     2     2
.label	l104
.line	1834	move          r8    r3
.line	1834	call          r6     3     1
.line	1834	loadnil       r6     0
.line	1834	return        r6     2
.label	l108
.line	1834	gettable      r6    r5    r3
.line	1834	test          r6     1
.line	1834	jmp            0  l114
.line	1834	eq             1    r4    k1 ; k1 = nil
.line	1834	jmp            0  l114
.line	1834	gettable      r6    r5    r4
.label	l114
.line	1834	test          r6     0
.line	1834	jmp            0  l122
.line	1834	gettable      r7    r6   k61 ; k61 = "UMGCanvasInfo"
.line	1834	test          r7     0
.line	1834	jmp            0  l122
.line	1834	gettable      r7    r6   k62 ; k62 = "CustomUIBase"
.line	1834	eq             1    r7    k1 ; k1 = nil
.line	1834	jmp            0  l196
.label	l122
.line	1834	gettabup      r7    u0    k6 ; k6 = "print"
.line	1834	gettabup      r8    u0    k7 ; k7 = "bWriteLog"
.line	1834	test          r8     0
.line	1834	jmp            0  l192
.line	1834	gettabup      r8    u0    k8 ; k8 = "table"
.line	1834	gettable      r8    r8    k9 ; k9 = "concat"
.line	1834	newtable      r9     1     0
.line	1834	getupval     r10    u1
.line	1834	loadk        r11   k10 ; k10 = 126
.line	1834	loadk        r12   k11 ; k11 = 68
.line	1834	loadk        r13   k12 ; k12 = 7
.line	1834	loadk        r14   k13 ; k13 = 41
.line	1834	loadk        r15   k14 ; k14 = 164
.line	1834	loadk        r16   k15 ; k15 = 170
.line	1834	loadk        r17   k16 ; k16 = 39
.line	1834	loadk        r18   k17 ; k17 = 95
.line	1834	loadk        r19   k18 ; k18 = 24
.line	1834	loadk        r20   k19 ; k19 = 91
.line	1834	loadk        r21   k20 ; k20 = 26
.line	1834	loadk        r22   k21 ; k21 = 31
.line	1834	loadk        r23   k22 ; k22 = 217
.line	1834	loadk        r24   k23 ; k23 = 83
.line	1834	loadk        r25   k24 ; k24 = 38
.line	1834	loadk        r26   k25 ; k25 = 54
.line	1834	loadk        r27   k26 ; k26 = 137
.line	1834	loadk        r28   k27 ; k27 = 103
.line	1834	loadk        r29   k28 ; k28 = 102
.line	1834	loadk        r30   k29 ; k29 = 25
.line	1834	loadk        r31   k30 ; k30 = 99
.line	1834	loadk        r32   k31 ; k31 = 156
.line	1834	loadk        r33   k32 ; k32 = 76
.line	1834	loadk        r34   k33 ; k33 = 122
.line	1834	loadk        r35   k34 ; k34 = 113
.line	1834	loadk        r36   k35 ; k35 = 97
.line	1834	loadk        r37   k36 ; k36 = 62
.line	1834	loadk        r38   k37 ; k37 = 30
.line	1834	loadk        r39   k38 ; k38 = 210
.line	1834	loadk        r40   k30 ; k30 = 99
.line	1834	loadk        r41   k39 ; k39 = 2
.line	1834	loadk        r42   k21 ; k21 = 31
.line	1834	loadk        r43   k40 ; k40 = 158
.line	1834	loadk        r44   k41 ; k41 = 119
.line	1834	loadk        r45   k42 ; k42 = 108
.line	1834	loadk        r46   k37 ; k37 = 30
.line	1834	loadk        r47   k43 ; k43 = 81
.line	1834	loadk        r48   k44 ; k44 = 144
.line	1834	loadk        r49   k45 ; k45 = 98
.line	1834	loadk        r50   k46 ; k46 = 117
.line	1834	call         r10    41     2
.line	1834	getupval     r11    u1
.line	1834	loadk        r12   k47 ; k47 = 72
.line	1834	loadk        r13   k11 ; k11 = 68
.line	1834	loadk        r14   k48 ; k48 = 1
.line	1834	loadk        r15   k49 ; k49 = 45
.line	1834	loadk        r16   k50 ; k50 = 240
.line	1834	loadk        r17   k63 ; k63 = 173
.line	1834	loadk        r18   k36 ; k36 = 62
.line	1834	loadk        r19   k64 ; k64 = 78
.line	1834	loadk        r20   k65 ; k65 = 123
.line	1834	loadk        r21   k66 ; k66 = 79
.line	1834	loadk        r22   k67 ; k67 = 73
.line	1834	loadk        r23   k68 ; k68 = 8
.line	1834	loadk        r24   k69 ; k69 = 215
.line	1834	loadk        r25   k70 ; k70 = 80
.line	1834	loadk        r26   k71 ; k71 = 5
.line	1834	loadk        r27   k37 ; k37 = 30
.line	1834	loadk        r28   k58 ; k58 = 190
.line	1834	call         r11    18     0
.line	1834	setlist       r9     0     1
.line	1834	call          r8     2     2
.label	l192
.line	1834	move          r9    r3
.line	1834	call          r7     3     1
.line	1834	loadnil       r7     0
.line	1834	return        r7     2
.label	l196
.line	1834	gettable      r7    r5    r3
.line	1834	eq             1    r7    k1 ; k1 = nil
.line	1834	jmp            0  l201
.line	1834	testset       r7    r3     1
.line	1834	jmp            0  l202
.label	l201
.line	1834	move          r7    r4
.label	l202
.line	1834	move          r8    r5
.line	1834	move          r9    r7
.line	1834	return        r8     3
.line	1834	return        r0     1
.line	1834	move          r0    r0
.line	1834	move          r0    r0
.line	1834	return        r0     1

.function	main/f82

.source	null
.linedefined	1861
.lastlinedefined	1880
.numparams	5
.is_vararg	0
.maxstacksize	53

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"HasAuthority"
.constant	k1	"print"
.constant	k2	"bWriteLog"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	126
.constant	k6	68
.constant	k7	7
.constant	k8	41
.constant	k9	164
.constant	k10	170
.constant	k11	39
.constant	k12	95
.constant	k13	24
.constant	k14	91
.constant	k15	26
.constant	k16	31
.constant	k17	217
.constant	k18	83
.constant	k19	38
.constant	k20	54
.constant	k21	137
.constant	k22	103
.constant	k23	102
.constant	k24	25
.constant	k25	99
.constant	k26	156
.constant	k27	76
.constant	k28	122
.constant	k29	113
.constant	k30	125
.constant	k31	11
.constant	k32	30
.constant	k33	199
.constant	k34	90
.constant	k35	6
.constant	k36	58
.constant	k37	144
.constant	k38	81
.constant	k39	64
.constant	k40	17
.constant	k41	115
.constant	k42	130
.constant	k43	108
.constant	k44	92
.constant	k45	69
.constant	k46	43
.constant	k47	12
.constant	k48	240
.constant	k49	176
.constant	k50	3
.constant	k51	4
.constant	k52	155
.constant	k53	165
.constant	k54	105
.constant	k55	96
.constant	k56	84
.constant	k57	138
.constant	k58	"tostring"
.constant	k59	"_AsyncLoadSeq"
.constant	k60	0
.constant	k61	1
.constant	k62	"_GetMapCanvasSource"
.constant	k63	"CreateRuntimeInstance"
.constant	k64	110
.constant	k65	160
.constant	k66	61
.constant	k67	85
.constant	k68	53
.constant	k69	75
.constant	k70	13
.constant	k71	215
.constant	k72	87
.constant	k73	169

.line	1861	self          r5    r0    k0 ; k0 = "HasAuthority"
.line	1861	call          r5     2     2
.line	1861	test          r5     1
.line	1861	jmp            0   l89
.line	1861	gettabup      r5    u0    k1 ; k1 = "print"
.line	1861	gettabup      r6    u0    k2 ; k2 = "bWriteLog"
.line	1861	test          r6     0
.line	1861	jmp            0   l80
.line	1861	gettabup      r6    u0    k3 ; k3 = "table"
.line	1861	gettable      r6    r6    k4 ; k4 = "concat"
.line	1861	newtable      r7     1     0
.line	1861	getupval      r8    u1
.line	1861	loadk         r9    k5 ; k5 = 126
.line	1861	loadk        r10    k6 ; k6 = 68
.line	1861	loadk        r11    k7 ; k7 = 7
.line	1861	loadk        r12    k8 ; k8 = 41
.line	1861	loadk        r13    k9 ; k9 = 164
.line	1861	loadk        r14   k10 ; k10 = 170
.line	1861	loadk        r15   k11 ; k11 = 39
.line	1861	loadk        r16   k12 ; k12 = 95
.line	1861	loadk        r17   k13 ; k13 = 24
.line	1861	loadk        r18   k14 ; k14 = 91
.line	1861	loadk        r19   k15 ; k15 = 26
.line	1861	loadk        r20   k16 ; k16 = 31
.line	1861	loadk        r21   k17 ; k17 = 217
.line	1861	loadk        r22   k18 ; k18 = 83
.line	1861	loadk        r23   k19 ; k19 = 38
.line	1861	loadk        r24   k20 ; k20 = 54
.line	1861	loadk        r25   k21 ; k21 = 137
.line	1861	loadk        r26   k22 ; k22 = 103
.line	1861	loadk        r27   k23 ; k23 = 102
.line	1861	loadk        r28   k24 ; k24 = 25
.line	1861	loadk        r29   k25 ; k25 = 99
.line	1861	loadk        r30   k26 ; k26 = 156
.line	1861	loadk        r31   k27 ; k27 = 76
.line	1861	loadk        r32   k28 ; k28 = 122
.line	1861	loadk        r33   k29 ; k29 = 113
.line	1861	loadk        r34   k30 ; k30 = 125
.line	1861	loadk        r35   k31 ; k31 = 11
.line	1861	loadk        r36   k32 ; k32 = 30
.line	1861	loadk        r37   k33 ; k33 = 199
.line	1861	loadk        r38   k34 ; k34 = 90
.line	1861	loadk        r39   k35 ; k35 = 6
.line	1861	loadk        r40   k36 ; k36 = 58
.line	1861	loadk        r41   k37 ; k37 = 144
.line	1861	loadk        r42   k38 ; k38 = 81
.line	1861	loadk        r43   k39 ; k39 = 64
.line	1861	loadk        r44   k40 ; k40 = 17
.line	1861	loadk        r45   k41 ; k41 = 115
.line	1861	loadk        r46   k42 ; k42 = 130
.line	1861	loadk        r47   k12 ; k12 = 95
.line	1861	loadk        r48   k43 ; k43 = 108
.line	1861	call          r8    41     2
.line	1861	getupval      r9    u1
.line	1861	loadk        r10   k44 ; k44 = 92
.line	1861	loadk        r11   k45 ; k45 = 69
.line	1861	loadk        r12   k46 ; k46 = 43
.line	1861	loadk        r13   k47 ; k47 = 12
.line	1861	loadk        r14   k48 ; k48 = 240
.line	1861	loadk        r15   k49 ; k49 = 176
.line	1861	loadk        r16   k36 ; k36 = 58
.line	1861	loadk        r17   k18 ; k18 = 83
.line	1861	loadk        r18   k46 ; k46 = 43
.line	1861	loadk        r19   k50 ; k50 = 3
.line	1861	loadk        r20    k7 ; k7 = 7
.line	1861	loadk        r21   k51 ; k51 = 4
.line	1861	loadk        r22   k52 ; k52 = 155
.line	1861	loadk        r23   k12 ; k12 = 95
.line	1861	loadk        r24   k35 ; k35 = 6
.line	1861	loadk        r25   k31 ; k31 = 11
.line	1861	loadk        r26   k53 ; k53 = 165
.line	1861	loadk        r27   k54 ; k54 = 105
.line	1861	loadk        r28   k55 ; k55 = 96
.line	1861	loadk        r29   k40 ; k40 = 17
.line	1861	loadk        r30   k56 ; k56 = 84
.line	1861	loadk        r31   k57 ; k57 = 138
.line	1861	call          r9    23     0
.line	1861	setlist       r7     0     1
.line	1861	call          r6     2     2
.label	l80
.line	1861	gettabup      r7    u0   k58 ; k58 = "tostring"
.line	1861	move          r8    r1
.line	1861	call          r7     2     0
.line	1861	call          r5     0     1
.line	1861	move          r5    r3
.line	1861	loadnil       r6     0
.line	1861	call          r5     2     1
.line	1861	loadnil       r5     0
.line	1861	return        r5     2
.label	l89
.line	1861	gettable      r5    r0   k59 ; k59 = "_AsyncLoadSeq"
.line	1861	test          r5     1
.line	1861	jmp            0   l93
.line	1861	loadk         r5   k60 ; k60 = 0
.label	l93
.line	1861	add           r5    r5   k61 ; k61 = 1
.line	1861	settable      r0   k59    r5 ; k59 = "_AsyncLoadSeq"
.line	1861	gettable      r5    r0   k59 ; k59 = "_AsyncLoadSeq"
.line	1861	self          r6    r0   k62 ; k62 = "_GetMapCanvasSource"
.line	1861	move          r8    r1
.line	1861	call          r6     3     3
.line	1861	test          r6     1
.line	1861	jmp            0  l105
.line	1861	move          r8    r3
.line	1861	loadnil       r9     0
.line	1861	call          r8     2     1
.line	1861	return        r5     2
.label	l105
.line	1861	self          r8    r0   k63 ; k63 = "CreateRuntimeInstanc" (truncated)
.line	1861	move         r10    r7
.line	1861	move         r11    r6
.line	1861	getupval     r12    u1
.line	1861	loadk        r13   k64 ; k64 = 110
.line	1861	call         r12     2     2
.line	1861	test          r4     0
.line	1861	jmp            0  l115
.line	1861	testset      r13    r2     1
.line	1861	jmp            0  l116
.label	l115
.line	1861	loadnil      r13     0
.label	l116
.line	1861	call          r8     6     2
.line	1861	test          r8     1
.line	1861	jmp            0  l193
.line	1861	gettabup      r9    u0    k1 ; k1 = "print"
.line	1861	gettabup     r10    u0    k2 ; k2 = "bWriteLog"
.line	1861	test         r10     0
.line	1861	jmp            0  l189
.line	1861	gettabup     r10    u0    k3 ; k3 = "table"
.line	1861	gettable     r10   r10    k4 ; k4 = "concat"
.line	1861	newtable     r11     1     0
.line	1861	getupval     r12    u1
.line	1861	loadk        r13    k5 ; k5 = 126
.line	1861	loadk        r14    k6 ; k6 = 68
.line	1861	loadk        r15    k7 ; k7 = 7
.line	1861	loadk        r16    k8 ; k8 = 41
.line	1861	loadk        r17    k9 ; k9 = 164
.line	1861	loadk        r18   k10 ; k10 = 170
.line	1861	loadk        r19   k11 ; k11 = 39
.line	1861	loadk        r20   k12 ; k12 = 95
.line	1861	loadk        r21   k13 ; k13 = 24
.line	1861	loadk        r22   k14 ; k14 = 91
.line	1861	loadk        r23   k15 ; k15 = 26
.line	1861	loadk        r24   k16 ; k16 = 31
.line	1861	loadk        r25   k17 ; k17 = 217
.line	1861	loadk        r26   k18 ; k18 = 83
.line	1861	loadk        r27   k19 ; k19 = 38
.line	1861	loadk        r28   k20 ; k20 = 54
.line	1861	loadk        r29   k21 ; k21 = 137
.line	1861	loadk        r30   k22 ; k22 = 103
.line	1861	loadk        r31   k23 ; k23 = 102
.line	1861	loadk        r32   k24 ; k24 = 25
.line	1861	loadk        r33   k25 ; k25 = 99
.line	1861	loadk        r34   k26 ; k26 = 156
.line	1861	loadk        r35   k27 ; k27 = 76
.line	1861	loadk        r36   k28 ; k28 = 122
.line	1861	loadk        r37   k29 ; k29 = 113
.line	1861	loadk        r38   k30 ; k30 = 125
.line	1861	loadk        r39   k31 ; k31 = 11
.line	1861	loadk        r40   k32 ; k32 = 30
.line	1861	loadk        r41   k33 ; k33 = 199
.line	1861	loadk        r42   k34 ; k34 = 90
.line	1861	loadk        r43   k35 ; k35 = 6
.line	1861	loadk        r44   k36 ; k36 = 58
.line	1861	loadk        r45   k37 ; k37 = 144
.line	1861	loadk        r46   k38 ; k38 = 81
.line	1861	loadk        r47   k39 ; k39 = 64
.line	1861	loadk        r48   k40 ; k40 = 17
.line	1861	loadk        r49   k41 ; k41 = 115
.line	1861	loadk        r50   k42 ; k42 = 130
.line	1861	loadk        r51   k12 ; k12 = 95
.line	1861	loadk        r52   k43 ; k43 = 108
.line	1861	call         r12    41     2
.line	1861	getupval     r13    u1
.line	1861	loadk        r14   k44 ; k44 = 92
.line	1861	loadk        r15   k45 ; k45 = 69
.line	1861	loadk        r16   k46 ; k46 = 43
.line	1861	loadk        r17   k47 ; k47 = 12
.line	1861	loadk        r18   k48 ; k48 = 240
.line	1861	loadk        r19   k65 ; k65 = 160
.line	1861	loadk        r20   k66 ; k66 = 61
.line	1861	loadk        r21   k67 ; k67 = 85
.line	1861	loadk        r22   k68 ; k68 = 53
.line	1861	loadk        r23   k69 ; k69 = 75
.line	1861	loadk        r24    k6 ; k6 = 68
.line	1861	loadk        r25   k70 ; k70 = 13
.line	1861	loadk        r26   k71 ; k71 = 215
.line	1861	loadk        r27   k72 ; k72 = 87
.line	1861	loadk        r28   k16 ; k16 = 31
.line	1861	loadk        r29   k15 ; k15 = 26
.line	1861	loadk        r30   k73 ; k73 = 169
.line	1861	call         r13    18     0
.line	1861	setlist      r11     0     1
.line	1861	call         r10     2     2
.label	l189
.line	1861	gettabup     r11    u0   k58 ; k58 = "tostring"
.line	1861	move         r12    r1
.line	1861	call         r11     2     0
.line	1861	call          r9     0     1
.label	l193
.line	1861	move          r9    r3
.line	1861	move         r10    r8
.line	1861	call          r9     2     1
.line	1861	return        r5     2
.line	1861	return        r0     1
.line	1861	move          r0    r0
.line	1861	move          r0    r0
.line	1861	return        r0     1

.function	main/f83

.source	null
.linedefined	1882
.lastlinedefined	1938
.numparams	6
.is_vararg	0
.maxstacksize	61

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"HasAuthority"
.constant	k1	"print"
.constant	k2	"bWriteLog"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	126
.constant	k6	68
.constant	k7	7
.constant	k8	41
.constant	k9	164
.constant	k10	170
.constant	k11	39
.constant	k12	95
.constant	k13	24
.constant	k14	91
.constant	k15	26
.constant	k16	31
.constant	k17	217
.constant	k18	83
.constant	k19	38
.constant	k20	54
.constant	k21	137
.constant	k22	103
.constant	k23	102
.constant	k24	25
.constant	k25	99
.constant	k26	156
.constant	k27	76
.constant	k28	122
.constant	k29	113
.constant	k30	125
.constant	k31	21
.constant	k32	18
.constant	k33	195
.constant	k34	64
.constant	k35	23
.constant	k36	35
.constant	k37	178
.constant	k38	119
.constant	k39	61
.constant	k40	115
.constant	k41	87
.constant	k42	12
.constant	k43	62
.constant	k44	177
.constant	k45	176
.constant	k46	123
.constant	k47	93
.constant	k48	2
.constant	k49	198
.constant	k50	19
.constant	k51	27
.constant	k52	30
.constant	k53	190
.constant	k54	43
.constant	k55	13
.constant	k56	84
.constant	k57	155
.constant	k58	78
.constant	k59	120
.constant	k60	34
.constant	k61	74
.constant	k62	0
.constant	k63	"tostring"
.constant	k64	"require"
.constant	k65	15
.constant	k66	45
.constant	k67	182
.constant	k68	48
.constant	k69	20
.constant	k70	22
.constant	k71	65
.constant	k72	69
.constant	k73	245
.constant	k74	185
.constant	k75	111
.constant	k76	100
.constant	k77	29
.constant	k78	98
.constant	k79	146
.constant	k80	82
.constant	k81	101
.constant	k82	158
.constant	k83	9
.constant	k84	138
.constant	k85	71
.constant	k86	127
.constant	k87	67
.constant	k88	17
.constant	k89	60
.constant	k90	191
.constant	k91	174
.constant	k92	4
.constant	k93	117
.constant	k94	109
.constant	k95	28
.constant	k96	194
.constant	k97	81
.constant	k98	42
.constant	k99	132
.constant	k100	118
.constant	k101	80
.constant	k102	135
.constant	k103	56
.constant	k104	199
.constant	k105	66
.constant	k106	"ClearParentBoundsCache"
.constant	k107	"WrapClientUILoadCallbackForReport"
.constant	k108	90
.constant	k109	11
.constant	k110	183
.constant	k111	85
.constant	k112	58
.constant	k113	241
.constant	k114	157
.constant	k115	116
.constant	k116	14
.constant	k117	73
.constant	k118	150
.constant	k119	86
.constant	k120	124
.constant	k121	10
.constant	k122	172
.constant	k123	104
.constant	k124	186
.constant	k125	"_AsyncLoadSeq"
.constant	k126	1
.constant	k127	"_GetMapCanvasSource"
.constant	k128	"CDORuntimeCount"
.constant	k129	"CloneCDOToRuntime"
.constant	k130	77
.constant	k131	5
.constant	k132	216
.constant	k133	94
.constant	k134	"PreviewRuntimeIds"
.constant	k135	"PreviewSeqToIds"
.constant	k136	"pairs"
.constant	k137	true
.constant	k138	"UMGCanvasInfo"
.constant	k139	"Tag"
.constant	k140	"RegisterCanvasReadyCallback"
.constant	k141	"CustomUIData"
.constant	k142	"RegisterInstanceIndex"
.constant	k143	"NotifyTalentNodeLanded"
.constant	k144	"ClientTryLoadCustomUIObject"
.constant	k145	"PendingLoadRuntimeIds"
.constant	k146	"GetWidgetObjectByRuntimeId"
.constant	k147	nil
.constant	k148	"FireCanvasReadyCallbacks"
.constant	k149	"string"
.constant	k150	"format"
.constant	k151	8
.constant	k152	210
.constant	k153	142
.constant	k154	128
.constant	k155	244
.constant	k156	180
.constant	k157	141
.constant	k158	6
.constant	k159	110
.constant	k160	197
.constant	k161	47

.line	1882	self          r6    r0    k0 ; k0 = "HasAuthority"
.line	1882	call          r6     2     2
.line	1882	test          r6     0
.line	1882	jmp            0   l94
.line	1882	gettabup      r6    u0    k1 ; k1 = "print"
.line	1882	gettabup      r7    u0    k2 ; k2 = "bWriteLog"
.line	1882	test          r7     0
.line	1882	jmp            0   l85
.line	1882	gettabup      r7    u0    k3 ; k3 = "table"
.line	1882	gettable      r7    r7    k4 ; k4 = "concat"
.line	1882	newtable      r8     1     0
.line	1882	getupval      r9    u1
.line	1882	loadk        r10    k5 ; k5 = 126
.line	1882	loadk        r11    k6 ; k6 = 68
.line	1882	loadk        r12    k7 ; k7 = 7
.line	1882	loadk        r13    k8 ; k8 = 41
.line	1882	loadk        r14    k9 ; k9 = 164
.line	1882	loadk        r15   k10 ; k10 = 170
.line	1882	loadk        r16   k11 ; k11 = 39
.line	1882	loadk        r17   k12 ; k12 = 95
.line	1882	loadk        r18   k13 ; k13 = 24
.line	1882	loadk        r19   k14 ; k14 = 91
.line	1882	loadk        r20   k15 ; k15 = 26
.line	1882	loadk        r21   k16 ; k16 = 31
.line	1882	loadk        r22   k17 ; k17 = 217
.line	1882	loadk        r23   k18 ; k18 = 83
.line	1882	loadk        r24   k19 ; k19 = 38
.line	1882	loadk        r25   k20 ; k20 = 54
.line	1882	loadk        r26   k21 ; k21 = 137
.line	1882	loadk        r27   k22 ; k22 = 103
.line	1882	loadk        r28   k23 ; k23 = 102
.line	1882	loadk        r29   k24 ; k24 = 25
.line	1882	loadk        r30   k25 ; k25 = 99
.line	1882	loadk        r31   k26 ; k26 = 156
.line	1882	loadk        r32   k27 ; k27 = 76
.line	1882	loadk        r33   k28 ; k28 = 122
.line	1882	loadk        r34   k29 ; k29 = 113
.line	1882	loadk        r35   k30 ; k30 = 125
.line	1882	loadk        r36   k31 ; k31 = 21
.line	1882	loadk        r37   k32 ; k32 = 18
.line	1882	loadk        r38   k33 ; k33 = 195
.line	1882	loadk        r39   k34 ; k34 = 64
.line	1882	loadk        r40   k35 ; k35 = 23
.line	1882	loadk        r41   k36 ; k36 = 35
.line	1882	loadk        r42   k37 ; k37 = 178
.line	1882	loadk        r43   k38 ; k38 = 119
.line	1882	loadk        r44   k23 ; k23 = 102
.line	1882	loadk        r45   k39 ; k39 = 61
.line	1882	loadk        r46   k30 ; k30 = 125
.line	1882	loadk        r47    k9 ; k9 = 164
.line	1882	loadk        r48   k40 ; k40 = 115
.line	1882	loadk        r49   k25 ; k25 = 99
.line	1882	call          r9    41     2
.line	1882	getupval     r10    u1
.line	1882	loadk        r11    k5 ; k5 = 126
.line	1882	loadk        r12   k41 ; k41 = 87
.line	1882	loadk        r13   k42 ; k42 = 12
.line	1882	loadk        r14   k43 ; k43 = 62
.line	1882	loadk        r15   k44 ; k44 = 177
.line	1882	loadk        r16   k45 ; k45 = 176
.line	1882	loadk        r17   k13 ; k13 = 24
.line	1882	loadk        r18    k5 ; k5 = 126
.line	1882	loadk        r19   k46 ; k46 = 123
.line	1882	loadk        r20   k47 ; k47 = 93
.line	1882	loadk        r21   k48 ; k48 = 2
.line	1882	loadk        r22   k48 ; k48 = 2
.line	1882	loadk        r23   k49 ; k49 = 198
.line	1882	loadk        r24   k50 ; k50 = 19
.line	1882	loadk        r25   k51 ; k51 = 27
.line	1882	loadk        r26   k52 ; k52 = 30
.line	1882	loadk        r27   k53 ; k53 = 190
.line	1882	loadk        r28   k54 ; k54 = 43
.line	1882	loadk        r29   k40 ; k40 = 115
.line	1882	loadk        r30   k55 ; k55 = 13
.line	1882	loadk        r31   k56 ; k56 = 84
.line	1882	loadk        r32   k57 ; k57 = 155
.line	1882	loadk        r33   k58 ; k58 = 78
.line	1882	loadk        r34   k59 ; k59 = 120
.line	1882	loadk        r35   k60 ; k60 = 34
.line	1882	loadk        r36   k61 ; k61 = 74
.line	1882	loadk        r37   k62 ; k62 = 0
.line	1882	call         r10    28     0
.line	1882	setlist       r8     0     1
.line	1882	call          r7     2     2
.label	l85
.line	1882	gettabup      r8    u0   k63 ; k63 = "tostring"
.line	1882	move          r9    r1
.line	1882	call          r8     2     0
.line	1882	call          r6     0     1
.line	1882	move          r6    r3
.line	1882	loadnil       r7     0
.line	1882	call          r6     2     1
.line	1882	loadnil       r6     0
.line	1882	return        r6     2
.label	l94
.line	1882	gettabup      r6    u0   k64 ; k64 = "require"
.line	1882	gettabup      r7    u0    k3 ; k3 = "table"
.line	1882	gettable      r7    r7    k4 ; k4 = "concat"
.line	1882	newtable      r8     1     0
.line	1882	getupval      r9    u1
.line	1882	loadk        r10   k28 ; k28 = 122
.line	1882	loadk        r11   k41 ; k41 = 87
.line	1882	loadk        r12   k65 ; k65 = 15
.line	1882	loadk        r13   k66 ; k66 = 45
.line	1882	loadk        r14   k26 ; k26 = 156
.line	1882	loadk        r15   k67 ; k67 = 182
.line	1882	loadk        r16   k68 ; k68 = 48
.line	1882	loadk        r17   k69 ; k69 = 20
.line	1882	loadk        r18   k70 ; k70 = 22
.line	1882	loadk        r19   k71 ; k71 = 65
.line	1882	loadk        r20   k55 ; k55 = 13
.line	1882	loadk        r21   k72 ; k72 = 69
.line	1882	loadk        r22   k73 ; k73 = 245
.line	1882	loadk        r23   k27 ; k27 = 76
.line	1882	loadk        r24   k70 ; k70 = 22
.line	1882	loadk        r25   k52 ; k52 = 30
.line	1882	loadk        r26   k74 ; k74 = 185
.line	1882	loadk        r27   k75 ; k75 = 111
.line	1882	loadk        r28   k76 ; k76 = 100
.line	1882	loadk        r29   k77 ; k77 = 29
.line	1882	loadk        r30   k78 ; k78 = 98
.line	1882	loadk        r31   k79 ; k79 = 146
.line	1882	loadk        r32   k80 ; k80 = 82
.line	1882	loadk        r33   k75 ; k75 = 111
.line	1882	loadk        r34   k81 ; k81 = 101
.line	1882	loadk        r35   k30 ; k30 = 125
.line	1882	loadk        r36   k31 ; k31 = 21
.line	1882	loadk        r37   k32 ; k32 = 18
.line	1882	loadk        r38   k33 ; k33 = 195
.line	1882	loadk        r39   k34 ; k34 = 64
.line	1882	loadk        r40   k35 ; k35 = 23
.line	1882	loadk        r41   k71 ; k71 = 65
.line	1882	loadk        r42   k82 ; k82 = 158
.line	1882	loadk        r43   k76 ; k76 = 100
.line	1882	loadk        r44   k22 ; k22 = 103
.line	1882	loadk        r45   k83 ; k83 = 9
.line	1882	loadk        r46    k6 ; k6 = 68
.line	1882	loadk        r47   k84 ; k84 = 138
.line	1882	loadk        r48   k85 ; k85 = 71
.line	1882	loadk        r49   k86 ; k86 = 127
.line	1882	call          r9    41     2
.line	1882	getupval     r10    u1
.line	1882	loadk        r11    k5 ; k5 = 126
.line	1882	loadk        r12   k87 ; k87 = 67
.line	1882	loadk        r13   k88 ; k88 = 17
.line	1882	loadk        r14   k89 ; k89 = 60
.line	1882	loadk        r15   k90 ; k90 = 191
.line	1882	loadk        r16   k91 ; k91 = 174
.line	1882	loadk        r17   k92 ; k92 = 4
.line	1882	loadk        r18   k40 ; k40 = 115
.line	1882	loadk        r19   k93 ; k93 = 117
.line	1882	loadk        r20   k94 ; k94 = 109
.line	1882	loadk        r21   k95 ; k95 = 28
.line	1882	loadk        r22   k13 ; k13 = 24
.line	1882	loadk        r23   k96 ; k96 = 194
.line	1882	loadk        r24   k97 ; k97 = 81
.line	1882	loadk        r25   k52 ; k52 = 30
.line	1882	loadk        r26   k98 ; k98 = 42
.line	1882	loadk        r27   k99 ; k99 = 132
.line	1882	loadk        r28   k85 ; k85 = 71
.line	1882	loadk        r29  k100 ; k100 = 118
.line	1882	loadk        r30   k24 ; k24 = 25
.line	1882	loadk        r31  k101 ; k101 = 80
.line	1882	loadk        r32  k102 ; k102 = 135
.line	1882	loadk        r33   k34 ; k34 = 64
.line	1882	loadk        r34    k5 ; k5 = 126
.line	1882	loadk        r35   k60 ; k60 = 34
.line	1882	loadk        r36   k97 ; k97 = 81
.line	1882	loadk        r37   k35 ; k35 = 23
.line	1882	loadk        r38  k103 ; k103 = 56
.line	1882	loadk        r39  k104 ; k104 = 199
.line	1882	loadk        r40  k105 ; k105 = 66
.line	1882	loadk        r41   k62 ; k62 = 0
.line	1882	loadk        r42   k15 ; k15 = 26
.line	1882	loadk        r43   k44 ; k44 = 177
.line	1882	loadk        r44   k38 ; k38 = 119
.line	1882	loadk        r45  k100 ; k100 = 118
.line	1882	loadk        r46    k7 ; k7 = 7
.line	1882	loadk        r47  k105 ; k105 = 66
.line	1882	call         r10    38     0
.line	1882	setlist       r8     0     1
.line	1882	call          r7     2     2
.line	1882	call          r6     2     2
.line	1882	gettable      r7    r6  k106 ; k106 = "ClearParentBoundsCac" (truncated)
.line	1882	call          r7     1     1
.line	1882	self          r7    r0  k107 ; k107 = "WrapClientUILoadCall" (truncated)
.line	1882	test          r5     0
.line	1882	jmp            0  l214
.line	1882	getupval      r9    u1
.line	1882	loadk        r10    k5 ; k5 = 126
.line	1882	loadk        r11  k108 ; k108 = 90
.line	1882	loadk        r12  k109 ; k109 = 11
.line	1882	loadk        r13   k66 ; k66 = 45
.line	1882	loadk        r14   k53 ; k53 = 190
.line	1882	loadk        r15  k110 ; k110 = 183
.line	1882	loadk        r16   k77 ; k77 = 29
.line	1882	loadk        r17  k111 ; k111 = 85
.line	1882	loadk        r18  k112 ; k112 = 58
.line	1882	loadk        r19   k61 ; k61 = 74
.line	1882	loadk        r20   k89 ; k89 = 60
.line	1882	loadk        r21   k19 ; k19 = 38
.line	1882	loadk        r22  k113 ; k113 = 241
.line	1882	loadk        r23   k59 ; k59 = 120
.line	1882	loadk        r24   k95 ; k95 = 28
.line	1882	loadk        r25   k55 ; k55 = 13
.line	1882	loadk        r26  k114 ; k114 = 157
.line	1882	loadk        r27  k115 ; k115 = 116
.line	1882	loadk        r28   k38 ; k38 = 119
.line	1882	loadk        r29  k116 ; k116 = 14
.line	1882	loadk        r30  k117 ; k117 = 73
.line	1882	loadk        r31  k118 ; k118 = 150
.line	1882	loadk        r32  k119 ; k119 = 86
.line	1882	call          r9    24     2
.line	1882	test          r9     1
.line	1882	jmp            0  l239
.label	l214
.line	1882	getupval      r9    u1
.line	1882	loadk        r10    k5 ; k5 = 126
.line	1882	loadk        r11  k108 ; k108 = 90
.line	1882	loadk        r12  k109 ; k109 = 11
.line	1882	loadk        r13   k66 ; k66 = 45
.line	1882	loadk        r14   k53 ; k53 = 190
.line	1882	loadk        r15  k110 ; k110 = 183
.line	1882	loadk        r16   k77 ; k77 = 29
.line	1882	loadk        r17  k111 ; k111 = 85
.line	1882	loadk        r18  k112 ; k112 = 58
.line	1882	loadk        r19   k61 ; k61 = 74
.line	1882	loadk        r20   k89 ; k89 = 60
.line	1882	loadk        r21   k19 ; k19 = 38
.line	1882	loadk        r22  k113 ; k113 = 241
.line	1882	loadk        r23  k120 ; k120 = 124
.line	1882	loadk        r24  k121 ; k121 = 10
.line	1882	loadk        r25   k89 ; k89 = 60
.line	1882	loadk        r26  k122 ; k122 = 172
.line	1882	loadk        r27  k123 ; k123 = 104
.line	1882	loadk        r28   k76 ; k76 = 100
.line	1882	loadk        r29   k24 ; k24 = 25
.line	1882	loadk        r30   k18 ; k18 = 83
.line	1882	loadk        r31  k124 ; k124 = 186
.line	1882	loadk        r32   k81 ; k81 = 101
.line	1882	call          r9    24     2
.label	l239
.line	1882	move         r10    r1
.line	1882	move         r11    r3
.line	1882	call          r7     5     2
.line	1882	move          r3    r7
.line	1882	gettable      r7    r0  k125 ; k125 = "_AsyncLoadSeq"
.line	1882	test          r7     1
.line	1882	jmp            0  l247
.line	1882	loadk         r7   k62 ; k62 = 0
.label	l247
.line	1882	add           r7    r7  k126 ; k126 = 1
.line	1882	settable      r0  k125    r7 ; k125 = "_AsyncLoadSeq"
.line	1882	gettable      r7    r0  k125 ; k125 = "_AsyncLoadSeq"
.line	1882	self          r8    r0  k127 ; k127 = "_GetMapCanvasSource"
.line	1882	move         r10    r1
.line	1882	call          r8     3     3
.line	1882	test          r8     1
.line	1882	jmp            0  l259
.line	1882	move         r10    r3
.line	1882	loadnil      r11     0
.line	1882	call         r10     2     1
.line	1882	return        r7     2
.label	l259
.line	1882	gettable     r10    r0  k128 ; k128 = "CDORuntimeCount"
.line	1882	gettable     r10   r10    r9
.line	1882	test         r10     1
.line	1882	jmp            0  l264
.line	1882	loadk        r10   k62 ; k62 = 0
.label	l264
.line	1882	add          r10   r10  k126 ; k126 = 1
.line	1882	self         r11    r0  k129 ; k129 = "CloneCDOToRuntime"
.line	1882	move         r13    r9
.line	1882	move         r14    r8
.line	1882	move         r15   r10
.line	1882	getupval     r16    u1
.line	1882	loadk        r17    k5 ; k5 = 126
.line	1882	call         r16     2     2
.line	1882	call         r11     6     3
.line	1882	testset      r13   r11     0
.line	1882	jmp            0  l276
.line	1882	gettable     r13   r11    r9
.label	l276
.line	1882	test         r13     0
.line	1882	jmp            0  l283
.line	1882	test         r12     0
.line	1882	jmp            0  l283
.line	1882	gettable     r14   r12   r13
.line	1882	test         r14     1
.line	1882	jmp            0  l365
.label	l283
.line	1882	gettabup     r14    u0    k1 ; k1 = "print"
.line	1882	gettabup     r15    u0    k2 ; k2 = "bWriteLog"
.line	1882	test         r15     0
.line	1882	jmp            0  l357
.line	1882	gettabup     r15    u0    k3 ; k3 = "table"
.line	1882	gettable     r15   r15    k4 ; k4 = "concat"
.line	1882	newtable     r16     1     0
.line	1882	getupval     r17    u1
.line	1882	loadk        r18    k5 ; k5 = 126
.line	1882	loadk        r19    k6 ; k6 = 68
.line	1882	loadk        r20    k7 ; k7 = 7
.line	1882	loadk        r21    k8 ; k8 = 41
.line	1882	loadk        r22    k9 ; k9 = 164
.line	1882	loadk        r23   k10 ; k10 = 170
.line	1882	loadk        r24   k11 ; k11 = 39
.line	1882	loadk        r25   k12 ; k12 = 95
.line	1882	loadk        r26   k13 ; k13 = 24
.line	1882	loadk        r27   k14 ; k14 = 91
.line	1882	loadk        r28   k15 ; k15 = 26
.line	1882	loadk        r29   k16 ; k16 = 31
.line	1882	loadk        r30   k17 ; k17 = 217
.line	1882	loadk        r31   k18 ; k18 = 83
.line	1882	loadk        r32   k19 ; k19 = 38
.line	1882	loadk        r33   k20 ; k20 = 54
.line	1882	loadk        r34   k21 ; k21 = 137
.line	1882	loadk        r35   k22 ; k22 = 103
.line	1882	loadk        r36   k23 ; k23 = 102
.line	1882	loadk        r37   k24 ; k24 = 25
.line	1882	loadk        r38   k25 ; k25 = 99
.line	1882	loadk        r39   k26 ; k26 = 156
.line	1882	loadk        r40   k27 ; k27 = 76
.line	1882	loadk        r41   k28 ; k28 = 122
.line	1882	loadk        r42   k29 ; k29 = 113
.line	1882	loadk        r43   k30 ; k30 = 125
.line	1882	loadk        r44   k31 ; k31 = 21
.line	1882	loadk        r45   k32 ; k32 = 18
.line	1882	loadk        r46   k33 ; k33 = 195
.line	1882	loadk        r47   k34 ; k34 = 64
.line	1882	loadk        r48   k35 ; k35 = 23
.line	1882	loadk        r49   k36 ; k36 = 35
.line	1882	loadk        r50   k37 ; k37 = 178
.line	1882	loadk        r51   k38 ; k38 = 119
.line	1882	loadk        r52   k23 ; k23 = 102
.line	1882	loadk        r53   k39 ; k39 = 61
.line	1882	loadk        r54   k30 ; k30 = 125
.line	1882	loadk        r55    k9 ; k9 = 164
.line	1882	loadk        r56   k40 ; k40 = 115
.line	1882	loadk        r57   k25 ; k25 = 99
.line	1882	call         r17    41     2
.line	1882	getupval     r18    u1
.line	1882	loadk        r19    k5 ; k5 = 126
.line	1882	loadk        r20   k41 ; k41 = 87
.line	1882	loadk        r21   k42 ; k42 = 12
.line	1882	loadk        r22   k43 ; k43 = 62
.line	1882	loadk        r23   k44 ; k44 = 177
.line	1882	loadk        r24   k45 ; k45 = 176
.line	1882	loadk        r25   k13 ; k13 = 24
.line	1882	loadk        r26    k5 ; k5 = 126
.line	1882	loadk        r27   k46 ; k46 = 123
.line	1882	loadk        r28  k130 ; k130 = 77
.line	1882	loadk        r29  k131 ; k131 = 5
.line	1882	loadk        r30   k92 ; k92 = 4
.line	1882	loadk        r31  k132 ; k132 = 216
.line	1882	loadk        r32   k14 ; k14 = 91
.line	1882	loadk        r33  k133 ; k133 = 94
.line	1882	loadk        r34   k24 ; k24 = 25
.line	1882	loadk        r35  k122 ; k122 = 172
.line	1882	loadk        r36   k75 ; k75 = 111
.line	1882	loadk        r37    k5 ; k5 = 126
.line	1882	loadk        r38   k77 ; k77 = 29
.line	1882	loadk        r39    k6 ; k6 = 68
.line	1882	call         r18    22     0
.line	1882	setlist      r16     0     1
.line	1882	call         r15     2     2
.label	l357
.line	1882	gettabup     r16    u0   k63 ; k63 = "tostring"
.line	1882	move         r17    r1
.line	1882	call         r16     2     0
.line	1882	call         r14     0     1
.line	1882	move         r14    r3
.line	1882	loadnil      r15     0
.line	1882	call         r14     2     1
.line	1882	return        r7     2
.label	l365
.line	1882	gettable     r14    r0  k128 ; k128 = "CDORuntimeCount"
.line	1882	settable     r14    r9   r10
.line	1882	gettable     r14   r12   r13
.line	1882	test          r5     0
.line	1882	jmp            0  l394
.line	1882	gettable     r15    r0  k134 ; k134 = "PreviewRuntimeIds"
.line	1882	test         r15     1
.line	1882	jmp            0  l374
.line	1882	newtable     r15     0     0
.label	l374
.line	1882	settable      r0  k134   r15 ; k134 = "PreviewRuntimeIds"
.line	1882	gettable     r15    r0  k135 ; k135 = "PreviewSeqToIds"
.line	1882	test         r15     1
.line	1882	jmp            0  l379
.line	1882	newtable     r15     0     0
.label	l379
.line	1882	settable      r0  k135   r15 ; k135 = "PreviewSeqToIds"
.line	1882	newtable     r15     0     0
.line	1882	gettabup     r16    u0  k136 ; k136 = "pairs"
.line	1882	move         r17   r12
.line	1882	call         r16     2     4
.line	1882	jmp            0  l390
.line	1882	gettable     r20    r0  k134 ; k134 = "PreviewRuntimeIds"
.line	1882	settable     r20   r19  k137 ; k137 = true
.line	1882	len          r20   r15
.line	1882	add          r20   r20  k126 ; k126 = 1
.line	1882	settable     r15   r20   r19
.label	l390
.line	1882	move          r0    r0
.line	1882	move          r0    r0
.line	1882	gettable     r16    r0  k135 ; k135 = "PreviewSeqToIds"
.line	1882	settable     r16    r7   r15
.label	l394
.line	1882	test          r4     0
.line	1882	jmp            0  l405
.line	1882	getupval     r15    u1
.line	1882	call         r15     1     2
.line	1882	eq             1    r2   r15
.line	1882	jmp            0  l405
.line	1882	gettable     r15   r14  k138 ; k138 = "UMGCanvasInfo"
.line	1882	test         r15     0
.line	1882	jmp            0  l405
.line	1882	gettable     r15   r14  k138 ; k138 = "UMGCanvasInfo"
.line	1882	settable     r15  k139    r2 ; k139 = "Tag"
.label	l405
.line	1882	self         r15    r0  k140 ; k140 = "RegisterCanvasReadyC" (truncated)
.line	1882	move         r17   r13
.line	1882	move         r18    r3
.line	1882	call         r15     4     1
.line	1882	gettabup     r15    u0  k136 ; k136 = "pairs"
.line	1882	move         r16   r12
.line	1882	call         r15     2     4
.line	1882	jmp            0  l429
.line	1882	eq             1   r18   r13
.line	1882	jmp            0  l429
.line	1882	gettable     r20    r0  k141 ; k141 = "CustomUIData"
.line	1882	settable     r20   r18   r19
.line	1882	self         r20    r0  k142 ; k142 = "RegisterInstanceInde" (truncated)
.line	1882	move         r22   r18
.line	1882	move         r23   r19
.line	1882	call         r20     4     1
.line	1882	self         r20    r0  k143 ; k143 = "NotifyTalentNodeLand" (truncated)
.line	1882	move         r22   r18
.line	1882	move         r23   r19
.line	1882	call         r20     4     1
.line	1882	self         r20    r0  k144 ; k144 = "ClientTryLoadCustomU" (truncated)
.line	1882	move         r22   r18
.line	1882	move         r23   r19
.line	1882	call         r20     4     1
.label	l429
.line	1882	move          r0    r0
.line	1882	move          r0    r0
.line	1882	gettable     r15    r0  k141 ; k141 = "CustomUIData"
.line	1882	settable     r15   r13   r14
.line	1882	self         r15    r0  k142 ; k142 = "RegisterInstanceInde" (truncated)
.line	1882	move         r17   r13
.line	1882	move         r18   r14
.line	1882	call         r15     4     1
.line	1882	self         r15    r0  k144 ; k144 = "ClientTryLoadCustomU" (truncated)
.line	1882	move         r17   r13
.line	1882	move         r18   r14
.line	1882	call         r15     4     1
.line	1882	gettable     r15    r0  k145 ; k145 = "PendingLoadRuntimeId" (truncated)
.line	1882	test         r15     0
.line	1882	jmp            0  l448
.line	1882	gettable     r15    r0  k145 ; k145 = "PendingLoadRuntimeId" (truncated)
.line	1882	gettable     r15   r15   r13
.line	1882	test         r15     1
.line	1882	jmp            0  l457
.label	l448
.line	1882	self         r15    r0  k146 ; k146 = "GetWidgetObjectByRun" (truncated)
.line	1882	move         r17   r13
.line	1882	call         r15     3     2
.line	1882	eq             0   r15  k147 ; k147 = nil
.line	1882	jmp            0  l457
.line	1882	self         r15    r0  k148 ; k148 = "FireCanvasReadyCallb" (truncated)
.line	1882	move         r17   r13
.line	1882	loadnil      r18     0
.line	1882	call         r15     4     1
.label	l457
.line	1882	gettabup     r15    u0    k1 ; k1 = "print"
.line	1882	gettabup     r16    u0    k2 ; k2 = "bWriteLog"
.line	1882	test         r16     0
.line	1882	jmp            0  l595
.line	1882	gettabup     r16    u0  k149 ; k149 = "string"
.line	1882	gettable     r16   r16  k150 ; k150 = "format"
.line	1882	gettabup     r17    u0    k3 ; k3 = "table"
.line	1882	gettable     r17   r17    k4 ; k4 = "concat"
.line	1882	newtable     r18     2     0
.line	1882	getupval     r19    u1
.line	1882	loadk        r20    k5 ; k5 = 126
.line	1882	loadk        r21    k6 ; k6 = 68
.line	1882	loadk        r22    k7 ; k7 = 7
.line	1882	loadk        r23    k8 ; k8 = 41
.line	1882	loadk        r24    k9 ; k9 = 164
.line	1882	loadk        r25   k10 ; k10 = 170
.line	1882	loadk        r26   k11 ; k11 = 39
.line	1882	loadk        r27   k12 ; k12 = 95
.line	1882	loadk        r28   k13 ; k13 = 24
.line	1882	loadk        r29   k14 ; k14 = 91
.line	1882	loadk        r30   k15 ; k15 = 26
.line	1882	loadk        r31   k16 ; k16 = 31
.line	1882	loadk        r32   k17 ; k17 = 217
.line	1882	loadk        r33   k18 ; k18 = 83
.line	1882	loadk        r34   k19 ; k19 = 38
.line	1882	loadk        r35   k20 ; k20 = 54
.line	1882	loadk        r36   k21 ; k21 = 137
.line	1882	loadk        r37   k22 ; k22 = 103
.line	1882	loadk        r38   k23 ; k23 = 102
.line	1882	loadk        r39   k24 ; k24 = 25
.line	1882	loadk        r40   k25 ; k25 = 99
.line	1882	loadk        r41   k26 ; k26 = 156
.line	1882	loadk        r42   k27 ; k27 = 76
.line	1882	loadk        r43   k28 ; k28 = 122
.line	1882	loadk        r44   k29 ; k29 = 113
.line	1882	loadk        r45   k30 ; k30 = 125
.line	1882	loadk        r46   k31 ; k31 = 21
.line	1882	loadk        r47   k32 ; k32 = 18
.line	1882	loadk        r48   k33 ; k33 = 195
.line	1882	loadk        r49   k34 ; k34 = 64
.line	1882	loadk        r50   k35 ; k35 = 23
.line	1882	loadk        r51   k36 ; k36 = 35
.line	1882	loadk        r52   k37 ; k37 = 178
.line	1882	loadk        r53   k38 ; k38 = 119
.line	1882	loadk        r54   k23 ; k23 = 102
.line	1882	loadk        r55   k39 ; k39 = 61
.line	1882	loadk        r56   k30 ; k30 = 125
.line	1882	loadk        r57    k9 ; k9 = 164
.line	1882	loadk        r58   k40 ; k40 = 115
.line	1882	loadk        r59   k25 ; k25 = 99
.line	1882	call         r19    41     2
.line	1882	getupval     r20    u1
.line	1882	loadk        r21    k5 ; k5 = 126
.line	1882	loadk        r22   k41 ; k41 = 87
.line	1882	loadk        r23   k42 ; k42 = 12
.line	1882	loadk        r24   k43 ; k43 = 62
.line	1882	loadk        r25   k44 ; k44 = 177
.line	1882	loadk        r26   k45 ; k45 = 176
.line	1882	loadk        r27   k13 ; k13 = 24
.line	1882	loadk        r28    k5 ; k5 = 126
.line	1882	loadk        r29   k46 ; k46 = 123
.line	1882	loadk        r30  k105 ; k105 = 66
.line	1882	loadk        r31  k151 ; k151 = 8
.line	1882	loadk        r32  k131 ; k131 = 5
.line	1882	loadk        r33  k152 ; k152 = 210
.line	1882	loadk        r34   k14 ; k14 = 91
.line	1882	loadk        r35   k35 ; k35 = 23
.line	1882	loadk        r36   k12 ; k12 = 95
.line	1882	loadk        r37  k153 ; k153 = 142
.line	1882	loadk        r38   k22 ; k22 = 103
.line	1882	loadk        r39  k120 ; k120 = 124
.line	1882	loadk        r40  k116 ; k116 = 14
.line	1882	loadk        r41   k71 ; k71 = 65
.line	1882	loadk        r42  k154 ; k154 = 128
.line	1882	loadk        r43  k123 ; k123 = 104
.line	1882	loadk        r44   k58 ; k58 = 78
.line	1882	loadk        r45  k100 ; k100 = 118
.line	1882	loadk        r46   k51 ; k51 = 27
.line	1882	loadk        r47  k121 ; k121 = 10
.line	1882	loadk        r48   k14 ; k14 = 91
.line	1882	loadk        r49  k155 ; k155 = 244
.line	1882	loadk        r50   k14 ; k14 = 91
.line	1882	loadk        r51   k55 ; k55 = 13
.line	1882	loadk        r52   k51 ; k51 = 27
.line	1882	loadk        r53  k156 ; k156 = 180
.line	1882	loadk        r54   k46 ; k46 = 123
.line	1882	loadk        r55   k22 ; k22 = 103
.line	1882	loadk        r56   k54 ; k54 = 43
.line	1882	loadk        r57   k97 ; k97 = 81
.line	1882	loadk        r58  k157 ; k157 = 141
.line	1882	loadk        r59   k85 ; k85 = 71
.line	1882	loadk        r60   k46 ; k46 = 123
.line	1882	call         r20    41     2
.line	1882	getupval     r21    u1
.line	1882	loadk        r22   k58 ; k58 = 78
.line	1882	loadk        r23   k86 ; k86 = 127
.line	1882	loadk        r24  k158 ; k158 = 6
.line	1882	loadk        r25   k93 ; k93 = 117
.line	1882	loadk        r26   k73 ; k73 = 245
.line	1882	loadk        r27   k45 ; k45 = 176
.line	1882	loadk        r28   k29 ; k29 = 113
.line	1882	loadk        r29  k159 ; k159 = 110
.line	1882	loadk        r30  k112 ; k112 = 58
.line	1882	loadk        r31  k117 ; k117 = 73
.line	1882	loadk        r32   k56 ; k56 = 84
.line	1882	loadk        r33   k58 ; k58 = 78
.line	1882	loadk        r34  k160 ; k160 = 197
.line	1882	loadk        r35   k52 ; k52 = 30
.line	1882	loadk        r36   k88 ; k88 = 17
.line	1882	loadk        r37  k161 ; k161 = 47
.line	1882	loadk        r38   k90 ; k90 = 191
.line	1882	loadk        r39   k25 ; k25 = 99
.line	1882	loadk        r40   k76 ; k76 = 100
.line	1882	loadk        r41   k88 ; k88 = 17
.line	1882	loadk        r42   k72 ; k72 = 69
.line	1882	loadk        r43   k99 ; k99 = 132
.line	1882	loadk        r44   k95 ; k95 = 28
.line	1882	loadk        r45  k161 ; k161 = 47
.line	1882	loadk        r46  k103 ; k103 = 56
.line	1882	call         r21    26     0
.line	1882	setlist      r18     0     1
.line	1882	call         r17     2     2
.line	1882	gettabup     r18    u0   k63 ; k63 = "tostring"
.line	1882	move         r19    r1
.line	1882	call         r18     2     2
.line	1882	gettabup     r19    u0   k63 ; k63 = "tostring"
.line	1882	move         r20   r13
.line	1882	call         r19     2     2
.line	1882	gettabup     r20    u0   k63 ; k63 = "tostring"
.line	1882	move         r21    r2
.line	1882	call         r20     2     2
.line	1882	gettabup     r21    u0   k63 ; k63 = "tostring"
.line	1882	eq             1    r5  k137 ; k137 = true
.line	1882	jmp            0  l592
.line	1882	loadbool     r22     0     1
.label	l592
.line	1882	loadbool     r22     1     0
.line	1882	call         r21     2     0
.line	1882	call         r16     0     2
.label	l595
.line	1882	call         r15     2     1
.line	1882	return        r7     2
.line	1882	return        r0     1
.line	1882	move          r0    r0
.line	1882	move          r0    r0
.line	1882	return        r0     1

.function	main/f84

.source	null
.linedefined	1940
.lastlinedefined	1972
.numparams	4
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"HasAuthority"
.constant	k1	"print"
.constant	k2	"bWriteLog"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	126
.constant	k6	68
.constant	k7	7
.constant	k8	41
.constant	k9	164
.constant	k10	170
.constant	k11	39
.constant	k12	95
.constant	k13	24
.constant	k14	91
.constant	k15	26
.constant	k16	31
.constant	k17	217
.constant	k18	83
.constant	k19	38
.constant	k20	54
.constant	k21	137
.constant	k22	103
.constant	k23	102
.constant	k24	25
.constant	k25	99
.constant	k26	156
.constant	k27	76
.constant	k28	122
.constant	k29	113
.constant	k30	125
.constant	k31	21
.constant	k32	18
.constant	k33	195
.constant	k34	64
.constant	k35	23
.constant	k36	35
.constant	k37	178
.constant	k38	119
.constant	k39	61
.constant	k40	117
.constant	k41	79
.constant	k42	16
.constant	k43	45
.constant	k44	166
.constant	k45	52
.constant	k46	77
.constant	k47	123
.constant	k48	93
.constant	k49	2
.constant	k50	198
.constant	k51	19
.constant	k52	27
.constant	k53	30
.constant	k54	190
.constant	k55	43
.constant	k56	115
.constant	k57	13
.constant	k58	84
.constant	k59	155
.constant	k60	78
.constant	k61	120
.constant	k62	34
.constant	k63	74
.constant	k64	0
.constant	k65	"tostring"
.constant	k66	nil
.constant	k67	111
.constant	k68	211
.constant	k69	37
.constant	k70	161
.constant	k71	88
.constant	k72	73
.constant	k73	128
.constant	k74	1
.constant	k75	72
.constant	k76	207
.constant	k77	"tonumber"
.constant	k78	100
.constant	k79	36
.constant	k80	89
.constant	k81	134
.constant	k82	171
.constant	k83	101
.constant	k84	182
.constant	k85	94
.constant	k86	"GetCreativeEntityManager"
.constant	k87	"slua"
.constant	k88	"isValid"
.constant	k89	"UUID2Key"
.constant	k90	60
.constant	k91	242
.constant	k92	105
.constant	k93	14
.constant	k94	69
.constant	k95	71
.constant	k96	107
.constant	k97	82
.constant	k98	28
.constant	k99	153
.constant	k100	44
.constant	k101	12
.constant	k102	223
.constant	k103	80
.constant	k104	87
.constant	k105	5
.constant	k106	114
.constant	k107	"ClientLoadUMGByCanvasID"

.line	1940	test          r3     1
.line	1940	jmp            0    l5
.line	1940	closure       r4    f0
.line	1940	move          r3    r4
.label	l5
.line	1940	self          r4    r0    k0 ; k0 = "HasAuthority"
.line	1940	call          r4     2     2
.line	1940	test          r4     0
.line	1940	jmp            0   l98
.line	1940	gettabup      r4    u0    k1 ; k1 = "print"
.line	1940	gettabup      r5    u0    k2 ; k2 = "bWriteLog"
.line	1940	test          r5     0
.line	1940	jmp            0   l89
.line	1940	gettabup      r5    u0    k3 ; k3 = "table"
.line	1940	gettable      r5    r5    k4 ; k4 = "concat"
.line	1940	newtable      r6     1     0
.line	1940	getupval      r7    u1
.line	1940	loadk         r8    k5 ; k5 = 126
.line	1940	loadk         r9    k6 ; k6 = 68
.line	1940	loadk        r10    k7 ; k7 = 7
.line	1940	loadk        r11    k8 ; k8 = 41
.line	1940	loadk        r12    k9 ; k9 = 164
.line	1940	loadk        r13   k10 ; k10 = 170
.line	1940	loadk        r14   k11 ; k11 = 39
.line	1940	loadk        r15   k12 ; k12 = 95
.line	1940	loadk        r16   k13 ; k13 = 24
.line	1940	loadk        r17   k14 ; k14 = 91
.line	1940	loadk        r18   k15 ; k15 = 26
.line	1940	loadk        r19   k16 ; k16 = 31
.line	1940	loadk        r20   k17 ; k17 = 217
.line	1940	loadk        r21   k18 ; k18 = 83
.line	1940	loadk        r22   k19 ; k19 = 38
.line	1940	loadk        r23   k20 ; k20 = 54
.line	1940	loadk        r24   k21 ; k21 = 137
.line	1940	loadk        r25   k22 ; k22 = 103
.line	1940	loadk        r26   k23 ; k23 = 102
.line	1940	loadk        r27   k24 ; k24 = 25
.line	1940	loadk        r28   k25 ; k25 = 99
.line	1940	loadk        r29   k26 ; k26 = 156
.line	1940	loadk        r30   k27 ; k27 = 76
.line	1940	loadk        r31   k28 ; k28 = 122
.line	1940	loadk        r32   k29 ; k29 = 113
.line	1940	loadk        r33   k30 ; k30 = 125
.line	1940	loadk        r34   k31 ; k31 = 21
.line	1940	loadk        r35   k32 ; k32 = 18
.line	1940	loadk        r36   k33 ; k33 = 195
.line	1940	loadk        r37   k34 ; k34 = 64
.line	1940	loadk        r38   k35 ; k35 = 23
.line	1940	loadk        r39   k36 ; k36 = 35
.line	1940	loadk        r40   k37 ; k37 = 178
.line	1940	loadk        r41   k38 ; k38 = 119
.line	1940	loadk        r42   k23 ; k23 = 102
.line	1940	loadk        r43   k39 ; k39 = 61
.line	1940	loadk        r44   k30 ; k30 = 125
.line	1940	loadk        r45    k9 ; k9 = 164
.line	1940	loadk        r46   k38 ; k38 = 119
.line	1940	loadk        r47   k40 ; k40 = 117
.line	1940	call          r7    41     2
.line	1940	getupval      r8    u1
.line	1940	loadk         r9   k41 ; k41 = 79
.line	1940	loadk        r10   k23 ; k23 = 102
.line	1940	loadk        r11   k42 ; k42 = 16
.line	1940	loadk        r12   k43 ; k43 = 45
.line	1940	loadk        r13   k44 ; k44 = 166
.line	1940	loadk        r14   k10 ; k10 = 170
.line	1940	loadk        r15   k45 ; k45 = 52
.line	1940	loadk        r16   k46 ; k46 = 77
.line	1940	loadk        r17   k47 ; k47 = 123
.line	1940	loadk        r18   k48 ; k48 = 93
.line	1940	loadk        r19   k49 ; k49 = 2
.line	1940	loadk        r20   k49 ; k49 = 2
.line	1940	loadk        r21   k50 ; k50 = 198
.line	1940	loadk        r22   k51 ; k51 = 19
.line	1940	loadk        r23   k52 ; k52 = 27
.line	1940	loadk        r24   k53 ; k53 = 30
.line	1940	loadk        r25   k54 ; k54 = 190
.line	1940	loadk        r26   k55 ; k55 = 43
.line	1940	loadk        r27   k56 ; k56 = 115
.line	1940	loadk        r28   k57 ; k57 = 13
.line	1940	loadk        r29   k58 ; k58 = 84
.line	1940	loadk        r30   k59 ; k59 = 155
.line	1940	loadk        r31   k60 ; k60 = 78
.line	1940	loadk        r32   k61 ; k61 = 120
.line	1940	loadk        r33   k62 ; k62 = 34
.line	1940	loadk        r34   k63 ; k63 = 74
.line	1940	loadk        r35   k64 ; k64 = 0
.line	1940	call          r8    28     0
.line	1940	setlist       r6     0     1
.line	1940	call          r5     2     2
.label	l89
.line	1940	gettabup      r6    u0   k65 ; k65 = "tostring"
.line	1940	move          r7    r1
.line	1940	call          r6     2     0
.line	1940	call          r4     0     1
.line	1940	move          r4    r3
.line	1940	loadnil       r5     0
.line	1940	call          r4     2     1
.line	1940	loadnil       r4     0
.line	1940	return        r4     2
.label	l98
.line	1940	eq             1    r1   k66 ; k66 = nil
.line	1940	jmp            0  l104
.line	1940	getupval      r4    u1
.line	1940	call          r4     1     2
.line	1940	eq             0    r1    r4
.line	1940	jmp            0  l193
.label	l104
.line	1940	gettabup      r4    u0    k1 ; k1 = "print"
.line	1940	gettabup      r5    u0    k2 ; k2 = "bWriteLog"
.line	1940	test          r5     0
.line	1940	jmp            0  l187
.line	1940	gettabup      r5    u0    k3 ; k3 = "table"
.line	1940	gettable      r5    r5    k4 ; k4 = "concat"
.line	1940	newtable      r6     1     0
.line	1940	getupval      r7    u1
.line	1940	loadk         r8    k5 ; k5 = 126
.line	1940	loadk         r9    k6 ; k6 = 68
.line	1940	loadk        r10    k7 ; k7 = 7
.line	1940	loadk        r11    k8 ; k8 = 41
.line	1940	loadk        r12    k9 ; k9 = 164
.line	1940	loadk        r13   k10 ; k10 = 170
.line	1940	loadk        r14   k11 ; k11 = 39
.line	1940	loadk        r15   k12 ; k12 = 95
.line	1940	loadk        r16   k13 ; k13 = 24
.line	1940	loadk        r17   k14 ; k14 = 91
.line	1940	loadk        r18   k15 ; k15 = 26
.line	1940	loadk        r19   k16 ; k16 = 31
.line	1940	loadk        r20   k17 ; k17 = 217
.line	1940	loadk        r21   k18 ; k18 = 83
.line	1940	loadk        r22   k19 ; k19 = 38
.line	1940	loadk        r23   k20 ; k20 = 54
.line	1940	loadk        r24   k21 ; k21 = 137
.line	1940	loadk        r25   k22 ; k22 = 103
.line	1940	loadk        r26   k23 ; k23 = 102
.line	1940	loadk        r27   k24 ; k24 = 25
.line	1940	loadk        r28   k25 ; k25 = 99
.line	1940	loadk        r29   k26 ; k26 = 156
.line	1940	loadk        r30   k27 ; k27 = 76
.line	1940	loadk        r31   k28 ; k28 = 122
.line	1940	loadk        r32   k29 ; k29 = 113
.line	1940	loadk        r33   k30 ; k30 = 125
.line	1940	loadk        r34   k31 ; k31 = 21
.line	1940	loadk        r35   k32 ; k32 = 18
.line	1940	loadk        r36   k33 ; k33 = 195
.line	1940	loadk        r37   k34 ; k34 = 64
.line	1940	loadk        r38   k35 ; k35 = 23
.line	1940	loadk        r39   k36 ; k36 = 35
.line	1940	loadk        r40   k37 ; k37 = 178
.line	1940	loadk        r41   k38 ; k38 = 119
.line	1940	loadk        r42   k23 ; k23 = 102
.line	1940	loadk        r43   k39 ; k39 = 61
.line	1940	loadk        r44   k30 ; k30 = 125
.line	1940	loadk        r45    k9 ; k9 = 164
.line	1940	loadk        r46   k38 ; k38 = 119
.line	1940	loadk        r47   k40 ; k40 = 117
.line	1940	call          r7    41     2
.line	1940	getupval      r8    u1
.line	1940	loadk         r9   k41 ; k41 = 79
.line	1940	loadk        r10   k23 ; k23 = 102
.line	1940	loadk        r11   k42 ; k42 = 16
.line	1940	loadk        r12   k43 ; k43 = 45
.line	1940	loadk        r13   k44 ; k44 = 166
.line	1940	loadk        r14   k10 ; k10 = 170
.line	1940	loadk        r15   k45 ; k45 = 52
.line	1940	loadk        r16   k46 ; k46 = 77
.line	1940	loadk        r17   k47 ; k47 = 123
.line	1940	loadk        r18   k67 ; k67 = 111
.line	1940	loadk        r19   k15 ; k15 = 26
.line	1940	loadk        r20   k13 ; k13 = 24
.line	1940	loadk        r21   k68 ; k68 = 211
.line	1940	loadk        r22   k63 ; k63 = 74
.line	1940	loadk        r23   k69 ; k69 = 37
.line	1940	loadk        r24   k53 ; k53 = 30
.line	1940	loadk        r25   k70 ; k70 = 161
.line	1940	loadk        r26   k56 ; k56 = 115
.line	1940	loadk        r27   k38 ; k38 = 119
.line	1940	loadk        r28   k71 ; k71 = 88
.line	1940	loadk        r29   k72 ; k72 = 73
.line	1940	loadk        r30   k73 ; k73 = 128
.line	1940	loadk        r31   k74 ; k74 = 1
.line	1940	loadk        r32   k25 ; k25 = 99
.line	1940	loadk        r33   k69 ; k69 = 37
.line	1940	loadk        r34   k75 ; k75 = 72
.line	1940	loadk        r35   k13 ; k13 = 24
.line	1940	loadk        r36   k35 ; k35 = 23
.line	1940	loadk        r37   k76 ; k76 = 207
.line	1940	loadk        r38   k63 ; k63 = 74
.line	1940	call          r8    31     0
.line	1940	setlist       r6     0     1
.line	1940	call          r5     2     2
.label	l187
.line	1940	call          r4     2     1
.line	1940	move          r4    r3
.line	1940	loadnil       r5     0
.line	1940	call          r4     2     1
.line	1940	loadnil       r4     0
.line	1940	return        r4     2
.label	l193
.line	1940	gettabup      r4    u0   k77 ; k77 = "tonumber"
.line	1940	move          r5    r1
.line	1940	call          r4     2     2
.line	1940	eq             0    r4   k66 ; k66 = nil
.line	1940	jmp            0  l304
.line	1940	gettabup      r5    u0    k1 ; k1 = "print"
.line	1940	gettabup      r6    u0    k2 ; k2 = "bWriteLog"
.line	1940	test          r6     0
.line	1940	jmp            0  l298
.line	1940	gettabup      r6    u0    k3 ; k3 = "table"
.line	1940	gettable      r6    r6    k4 ; k4 = "concat"
.line	1940	newtable      r7     2     0
.line	1940	getupval      r8    u1
.line	1940	loadk         r9    k5 ; k5 = 126
.line	1940	loadk        r10    k6 ; k6 = 68
.line	1940	loadk        r11    k7 ; k7 = 7
.line	1940	loadk        r12    k8 ; k8 = 41
.line	1940	loadk        r13    k9 ; k9 = 164
.line	1940	loadk        r14   k10 ; k10 = 170
.line	1940	loadk        r15   k11 ; k11 = 39
.line	1940	loadk        r16   k12 ; k12 = 95
.line	1940	loadk        r17   k13 ; k13 = 24
.line	1940	loadk        r18   k14 ; k14 = 91
.line	1940	loadk        r19   k15 ; k15 = 26
.line	1940	loadk        r20   k16 ; k16 = 31
.line	1940	loadk        r21   k17 ; k17 = 217
.line	1940	loadk        r22   k18 ; k18 = 83
.line	1940	loadk        r23   k19 ; k19 = 38
.line	1940	loadk        r24   k20 ; k20 = 54
.line	1940	loadk        r25   k21 ; k21 = 137
.line	1940	loadk        r26   k22 ; k22 = 103
.line	1940	loadk        r27   k23 ; k23 = 102
.line	1940	loadk        r28   k24 ; k24 = 25
.line	1940	loadk        r29   k25 ; k25 = 99
.line	1940	loadk        r30   k26 ; k26 = 156
.line	1940	loadk        r31   k27 ; k27 = 76
.line	1940	loadk        r32   k28 ; k28 = 122
.line	1940	loadk        r33   k29 ; k29 = 113
.line	1940	loadk        r34   k30 ; k30 = 125
.line	1940	loadk        r35   k31 ; k31 = 21
.line	1940	loadk        r36   k32 ; k32 = 18
.line	1940	loadk        r37   k33 ; k33 = 195
.line	1940	loadk        r38   k34 ; k34 = 64
.line	1940	loadk        r39   k35 ; k35 = 23
.line	1940	loadk        r40   k36 ; k36 = 35
.line	1940	loadk        r41   k37 ; k37 = 178
.line	1940	loadk        r42   k38 ; k38 = 119
.line	1940	loadk        r43   k23 ; k23 = 102
.line	1940	loadk        r44   k39 ; k39 = 61
.line	1940	loadk        r45   k30 ; k30 = 125
.line	1940	loadk        r46    k9 ; k9 = 164
.line	1940	loadk        r47   k38 ; k38 = 119
.line	1940	loadk        r48   k40 ; k40 = 117
.line	1940	call          r8    41     2
.line	1940	getupval      r9    u1
.line	1940	loadk        r10   k41 ; k41 = 79
.line	1940	loadk        r11   k23 ; k23 = 102
.line	1940	loadk        r12   k42 ; k42 = 16
.line	1940	loadk        r13   k43 ; k43 = 45
.line	1940	loadk        r14   k44 ; k44 = 166
.line	1940	loadk        r15   k10 ; k10 = 170
.line	1940	loadk        r16   k45 ; k45 = 52
.line	1940	loadk        r17   k46 ; k46 = 77
.line	1940	loadk        r18   k47 ; k47 = 123
.line	1940	loadk        r19   k67 ; k67 = 111
.line	1940	loadk        r20   k15 ; k15 = 26
.line	1940	loadk        r21   k13 ; k13 = 24
.line	1940	loadk        r22   k68 ; k68 = 211
.line	1940	loadk        r23   k63 ; k63 = 74
.line	1940	loadk        r24   k69 ; k69 = 37
.line	1940	loadk        r25   k53 ; k53 = 30
.line	1940	loadk        r26   k70 ; k70 = 161
.line	1940	loadk        r27   k56 ; k56 = 115
.line	1940	loadk        r28   k38 ; k38 = 119
.line	1940	loadk        r29   k71 ; k71 = 88
.line	1940	loadk        r30   k72 ; k72 = 73
.line	1940	loadk        r31   k73 ; k73 = 128
.line	1940	loadk        r32   k74 ; k74 = 1
.line	1940	loadk        r33   k78 ; k78 = 100
.line	1940	loadk        r34   k79 ; k79 = 36
.line	1940	loadk        r35   k63 ; k63 = 74
.line	1940	loadk        r36   k80 ; k80 = 89
.line	1940	loadk        r37   k15 ; k15 = 26
.line	1940	loadk        r38   k81 ; k81 = 134
.line	1940	loadk        r39   k46 ; k46 = 77
.line	1940	loadk        r40   k49 ; k49 = 2
.line	1940	loadk        r41   k74 ; k74 = 1
.line	1940	loadk        r42   k82 ; k82 = 171
.line	1940	loadk        r43   k38 ; k38 = 119
.line	1940	loadk        r44   k29 ; k29 = 113
.line	1940	loadk        r45   k75 ; k75 = 72
.line	1940	loadk        r46   k83 ; k83 = 101
.line	1940	loadk        r47   k84 ; k84 = 182
.line	1940	loadk        r48   k61 ; k61 = 120
.line	1940	loadk        r49   k85 ; k85 = 94
.line	1940	call          r9    41     2
.line	1940	getupval     r10    u1
.line	1940	loadk        r11    k7 ; k7 = 7
.line	1940	call         r10     2     0
.line	1940	setlist       r7     0     1
.line	1940	call          r6     2     2
.line	1940	gettabup      r7    u0   k65 ; k65 = "tostring"
.line	1940	move          r8    r1
.line	1940	call          r7     2     2
.line	1940	concat        r6    r6    r7
.label	l298
.line	1940	call          r5     2     1
.line	1940	move          r5    r3
.line	1940	loadnil       r6     0
.line	1940	call          r5     2     1
.line	1940	loadnil       r5     0
.line	1940	return        r5     2
.label	l304
.line	1940	gettabup      r5    u0   k86 ; k86 = "GetCreativeEntityMan" (truncated)
.line	1940	call          r5     1     2
.line	1940	gettabup      r6    u0   k87 ; k87 = "slua"
.line	1940	gettable      r6    r6   k88 ; k88 = "isValid"
.line	1940	move          r7    r5
.line	1940	call          r6     2     2
.line	1940	test          r6     0
.line	1940	jmp            0  l317
.line	1940	self          r6    r5   k89 ; k89 = "UUID2Key"
.line	1940	move          r8    r4
.line	1940	call          r6     3     2
.line	1940	test          r6     1
.line	1940	jmp            0  l318
.label	l317
.line	1940	loadnil       r6     0
.label	l318
.line	1940	eq             0    r6   k66 ; k66 = nil
.line	1940	jmp            0  l417
.line	1940	gettabup      r7    u0    k1 ; k1 = "print"
.line	1940	gettabup      r8    u0    k2 ; k2 = "bWriteLog"
.line	1940	test          r8     0
.line	1940	jmp            0  l411
.line	1940	gettabup      r8    u0    k3 ; k3 = "table"
.line	1940	gettable      r8    r8    k4 ; k4 = "concat"
.line	1940	newtable      r9     1     0
.line	1940	getupval     r10    u1
.line	1940	loadk        r11    k5 ; k5 = 126
.line	1940	loadk        r12    k6 ; k6 = 68
.line	1940	loadk        r13    k7 ; k7 = 7
.line	1940	loadk        r14    k8 ; k8 = 41
.line	1940	loadk        r15    k9 ; k9 = 164
.line	1940	loadk        r16   k10 ; k10 = 170
.line	1940	loadk        r17   k11 ; k11 = 39
.line	1940	loadk        r18   k12 ; k12 = 95
.line	1940	loadk        r19   k13 ; k13 = 24
.line	1940	loadk        r20   k14 ; k14 = 91
.line	1940	loadk        r21   k15 ; k15 = 26
.line	1940	loadk        r22   k16 ; k16 = 31
.line	1940	loadk        r23   k17 ; k17 = 217
.line	1940	loadk        r24   k18 ; k18 = 83
.line	1940	loadk        r25   k19 ; k19 = 38
.line	1940	loadk        r26   k20 ; k20 = 54
.line	1940	loadk        r27   k21 ; k21 = 137
.line	1940	loadk        r28   k22 ; k22 = 103
.line	1940	loadk        r29   k23 ; k23 = 102
.line	1940	loadk        r30   k24 ; k24 = 25
.line	1940	loadk        r31   k25 ; k25 = 99
.line	1940	loadk        r32   k26 ; k26 = 156
.line	1940	loadk        r33   k27 ; k27 = 76
.line	1940	loadk        r34   k28 ; k28 = 122
.line	1940	loadk        r35   k29 ; k29 = 113
.line	1940	loadk        r36   k30 ; k30 = 125
.line	1940	loadk        r37   k31 ; k31 = 21
.line	1940	loadk        r38   k32 ; k32 = 18
.line	1940	loadk        r39   k33 ; k33 = 195
.line	1940	loadk        r40   k34 ; k34 = 64
.line	1940	loadk        r41   k35 ; k35 = 23
.line	1940	loadk        r42   k36 ; k36 = 35
.line	1940	loadk        r43   k37 ; k37 = 178
.line	1940	loadk        r44   k38 ; k38 = 119
.line	1940	loadk        r45   k23 ; k23 = 102
.line	1940	loadk        r46   k39 ; k39 = 61
.line	1940	loadk        r47   k30 ; k30 = 125
.line	1940	loadk        r48    k9 ; k9 = 164
.line	1940	loadk        r49   k38 ; k38 = 119
.line	1940	loadk        r50   k40 ; k40 = 117
.line	1940	call         r10    41     2
.line	1940	getupval     r11    u1
.line	1940	loadk        r12   k41 ; k41 = 79
.line	1940	loadk        r13   k23 ; k23 = 102
.line	1940	loadk        r14   k42 ; k42 = 16
.line	1940	loadk        r15   k43 ; k43 = 45
.line	1940	loadk        r16   k44 ; k44 = 166
.line	1940	loadk        r17   k10 ; k10 = 170
.line	1940	loadk        r18   k45 ; k45 = 52
.line	1940	loadk        r19   k46 ; k46 = 77
.line	1940	loadk        r20   k47 ; k47 = 123
.line	1940	loadk        r21   k47 ; k47 = 123
.line	1940	loadk        r22   k90 ; k90 = 60
.line	1940	loadk        r23   k62 ; k62 = 34
.line	1940	loadk        r24   k91 ; k91 = 242
.line	1940	loadk        r25   k53 ; k53 = 30
.line	1940	loadk        r26   k74 ; k74 = 1
.line	1940	loadk        r27   k15 ; k15 = 26
.line	1940	loadk        r28   k54 ; k54 = 190
.line	1940	loadk        r29   k92 ; k92 = 105
.line	1940	loadk        r30    k5 ; k5 = 126
.line	1940	loadk        r31   k93 ; k93 = 14
.line	1940	loadk        r32   k94 ; k94 = 69
.line	1940	loadk        r33   k68 ; k68 = 211
.line	1940	loadk        r34   k95 ; k95 = 71
.line	1940	loadk        r35   k96 ; k96 = 107
.line	1940	loadk        r36   k62 ; k62 = 34
.line	1940	loadk        r37   k97 ; k97 = 82
.line	1940	loadk        r38   k98 ; k98 = 28
.line	1940	loadk        r39   k16 ; k16 = 31
.line	1940	loadk        r40   k81 ; k81 = 134
.line	1940	loadk        r41   k47 ; k47 = 123
.line	1940	loadk        r42   k20 ; k20 = 54
.line	1940	loadk        r43   k19 ; k19 = 38
.line	1940	loadk        r44   k99 ; k99 = 153
.line	1940	loadk        r45  k100 ; k100 = 44
.line	1940	call         r11    35     0
.line	1940	setlist       r9     0     1
.line	1940	call          r8     2     2
.line	1940	gettabup      r9    u0   k65 ; k65 = "tostring"
.line	1940	move         r10    r4
.line	1940	call          r9     2     2
.line	1940	concat        r8    r8    r9
.label	l411
.line	1940	call          r7     2     1
.line	1940	move          r7    r3
.line	1940	loadnil       r8     0
.line	1940	call          r7     2     1
.line	1940	loadnil       r7     0
.line	1940	return        r7     2
.label	l417
.line	1940	gettabup      r7    u0    k1 ; k1 = "print"
.line	1940	gettabup      r8    u0    k2 ; k2 = "bWriteLog"
.line	1940	test          r8     0
.line	1940	jmp            0  l484
.line	1940	gettabup      r8    u0    k3 ; k3 = "table"
.line	1940	gettable      r8    r8    k4 ; k4 = "concat"
.line	1940	newtable      r9     1     0
.line	1940	getupval     r10    u1
.line	1940	loadk        r11    k5 ; k5 = 126
.line	1940	loadk        r12    k6 ; k6 = 68
.line	1940	loadk        r13    k7 ; k7 = 7
.line	1940	loadk        r14    k8 ; k8 = 41
.line	1940	loadk        r15    k9 ; k9 = 164
.line	1940	loadk        r16   k10 ; k10 = 170
.line	1940	loadk        r17   k11 ; k11 = 39
.line	1940	loadk        r18   k12 ; k12 = 95
.line	1940	loadk        r19   k13 ; k13 = 24
.line	1940	loadk        r20   k14 ; k14 = 91
.line	1940	loadk        r21   k15 ; k15 = 26
.line	1940	loadk        r22   k16 ; k16 = 31
.line	1940	loadk        r23   k17 ; k17 = 217
.line	1940	loadk        r24   k18 ; k18 = 83
.line	1940	loadk        r25   k19 ; k19 = 38
.line	1940	loadk        r26   k20 ; k20 = 54
.line	1940	loadk        r27   k21 ; k21 = 137
.line	1940	loadk        r28   k22 ; k22 = 103
.line	1940	loadk        r29   k23 ; k23 = 102
.line	1940	loadk        r30   k24 ; k24 = 25
.line	1940	loadk        r31   k25 ; k25 = 99
.line	1940	loadk        r32   k26 ; k26 = 156
.line	1940	loadk        r33   k27 ; k27 = 76
.line	1940	loadk        r34   k28 ; k28 = 122
.line	1940	loadk        r35   k29 ; k29 = 113
.line	1940	loadk        r36   k30 ; k30 = 125
.line	1940	loadk        r37   k31 ; k31 = 21
.line	1940	loadk        r38   k32 ; k32 = 18
.line	1940	loadk        r39   k33 ; k33 = 195
.line	1940	loadk        r40   k34 ; k34 = 64
.line	1940	loadk        r41   k35 ; k35 = 23
.line	1940	loadk        r42   k36 ; k36 = 35
.line	1940	loadk        r43   k37 ; k37 = 178
.line	1940	loadk        r44   k38 ; k38 = 119
.line	1940	loadk        r45   k23 ; k23 = 102
.line	1940	loadk        r46   k39 ; k39 = 61
.line	1940	loadk        r47   k30 ; k30 = 125
.line	1940	loadk        r48    k9 ; k9 = 164
.line	1940	loadk        r49   k38 ; k38 = 119
.line	1940	loadk        r50   k40 ; k40 = 117
.line	1940	call         r10    41     2
.line	1940	getupval     r11    u1
.line	1940	loadk        r12   k41 ; k41 = 79
.line	1940	loadk        r13   k23 ; k23 = 102
.line	1940	loadk        r14   k42 ; k42 = 16
.line	1940	loadk        r15   k43 ; k43 = 45
.line	1940	loadk        r16   k44 ; k44 = 166
.line	1940	loadk        r17   k10 ; k10 = 170
.line	1940	loadk        r18   k45 ; k45 = 52
.line	1940	loadk        r19   k46 ; k46 = 77
.line	1940	loadk        r20   k47 ; k47 = 123
.line	1940	loadk        r21   k27 ; k27 = 76
.line	1940	loadk        r22  k101 ; k101 = 12
.line	1940	loadk        r23  k101 ; k101 = 12
.line	1940	loadk        r24  k102 ; k102 = 223
.line	1940	loadk        r25  k103 ; k103 = 80
.line	1940	call         r11    15     0
.line	1940	setlist       r9     0     1
.line	1940	call          r8     2     2
.label	l484
.line	1940	gettabup      r9    u0   k65 ; k65 = "tostring"
.line	1940	move         r10    r1
.line	1940	call          r9     2     2
.line	1940	getupval     r10    u1
.line	1940	loadk        r11   k92 ; k92 = 105
.line	1940	loadk        r12  k104 ; k104 = 87
.line	1940	loadk        r13  k105 ; k105 = 5
.line	1940	loadk        r14  k106 ; k106 = 114
.line	1940	call         r10     5     2
.line	1940	gettabup     r11    u0   k65 ; k65 = "tostring"
.line	1940	move         r12    r2
.line	1940	call         r11     2     0
.line	1940	call          r7     0     1
.line	1940	closure       r7    f1
.line	1940	self          r8    r0  k107 ; k107 = "ClientLoadUMGByCanva" (truncated)
.line	1940	move         r10    r6
.line	1940	move         r11    r2
.line	1940	move         r12    r7
.line	1940	loadbool     r13     1     0
.line	1940	loadbool     r14     1     0
.line	1940	tailcall      r8     7
.line	1940	return        r8     0
.line	1940	return        r0     1
.line	1940	move          r0    r0
.line	1940	move          r0    r0
.line	1940	return        r0     1

.function	main/f84/f0

.source	null
.linedefined	1941
.lastlinedefined	1942
.numparams	0
.is_vararg	0
.maxstacksize	2

.line	1941	return        r0     1
.line	1941	move          r0    r0
.line	1941	move          r0    r0
.line	1941	move          r0    r0
.line	1941	move          r0    r0
.line	1941	return        r0     1

.function	main/f84/f1

.source	null
.linedefined	1967
.lastlinedefined	1970
.numparams	2
.is_vararg	1
.maxstacksize	6

.upvalue	"_ENV"	0	true
.upvalue	"U1"	3	true

.constant	k0	"_ClearPreviewSeq"

.line	1967	getupval      r2    u0
.line	1967	self          r2    r2    k0 ; k0 = "_ClearPreviewSeq"
.line	1967	move          r4    r1
.line	1967	call          r2     3     1
.line	1967	getupval      r2    u1
.line	1967	move          r3    r0
.line	1967	move          r4    r1
.line	1967	vararg        r5     0
.line	1967	call          r2     0     1
.line	1967	return        r0     1
.line	1967	move          r0    r0
.line	1967	move          r0    r0
.line	1967	return        r0     1

.function	main/f85

.source	null
.linedefined	1974
.lastlinedefined	1986
.numparams	2
.is_vararg	0
.maxstacksize	12

.upvalue	"_ENV"	0	false

.constant	k0	nil
.constant	k1	"PreviewSeqToIds"
.constant	k2	"pairs"
.constant	k3	1

.line	1974	eq             1    r1    k0 ; k0 = nil
.line	1974	jmp            0    l6
.line	1974	gettable      r2    r0    k1 ; k1 = "PreviewSeqToIds"
.line	1974	eq             0    r2    k0 ; k0 = nil
.line	1974	jmp            0    l7
.label	l6
.line	1974	return        r0     1
.label	l7
.line	1974	gettabup      r2    u0    k2 ; k2 = "pairs"
.line	1974	gettable      r3    r0    k1 ; k1 = "PreviewSeqToIds"
.line	1974	call          r2     2     4
.line	1974	jmp            0   l22
.line	1974	loadk         r7    k3 ; k3 = 1
.line	1974	len           r8    r6
.line	1974	loadk         r9    k3 ; k3 = 1
.line	1974	move          r0    r0
.line	1974	gettable     r11    r6   r10
.line	1974	eq             0   r11    r1
.line	1974	jmp            0   l21
.line	1974	gettable     r11    r0    k1 ; k1 = "PreviewSeqToIds"
.line	1974	settable     r11    r5    k0 ; k0 = nil
.line	1974	return        r0     1
.label	l21
.line	1974	move          r0    r0
.label	l22
.line	1974	move          r0    r0
.line	1974	move          r0    r0
.line	1974	return        r0     1
.line	1974	move          r0    r0
.line	1974	return        r0     1

.function	main/f86

.source	null
.linedefined	1988
.lastlinedefined	2018
.numparams	3
.is_vararg	0
.maxstacksize	11

.upvalue	"_ENV"	1	true

.constant	k0	"HasAuthority"
.constant	k1	nil
.constant	k2	"PreviewSeqToIds"
.constant	k3	"PreviewRuntimeIds"
.constant	k4	1
.constant	k5	"CustomUIData"
.constant	k6	"UMGCanvasInfo"
.constant	k7	"AllWidgets"
.constant	k8	"overrides"
.constant	k9	"ClientRemoveUMGByRuntimeID"

.line	1988	self          r3    r0    k0 ; k0 = "HasAuthority"
.line	1988	call          r3     2     2
.line	1988	test          r3     0
.line	1988	jmp            0    l6
.line	1988	return        r0     1
.label	l6
.line	1988	eq             1    r2    k1 ; k1 = nil
.line	1988	jmp            0   l28
.line	1988	gettable      r3    r0    k2 ; k2 = "PreviewSeqToIds"
.line	1988	test          r3     0
.line	1988	jmp            0   l28
.line	1988	gettable      r3    r0    k2 ; k2 = "PreviewSeqToIds"
.line	1988	gettable      r3    r3    r2
.line	1988	test          r3     0
.line	1988	jmp            0   l26
.line	1988	gettable      r4    r0    k3 ; k3 = "PreviewRuntimeIds"
.line	1988	test          r4     0
.line	1988	jmp            0   l26
.line	1988	loadk         r4    k4 ; k4 = 1
.line	1988	len           r5    r3
.line	1988	loadk         r6    k4 ; k4 = 1
.line	1988	move          r0    r0
.line	1988	gettable      r8    r0    k3 ; k3 = "PreviewRuntimeIds"
.line	1988	gettable      r9    r3    r7
.line	1988	settable      r8    r9    k1 ; k1 = nil
.line	1988	move          r0    r0
.label	l26
.line	1988	gettable      r4    r0    k2 ; k2 = "PreviewSeqToIds"
.line	1988	settable      r4    r2    k1 ; k1 = nil
.label	l28
.line	1988	eq             1    r1    k1 ; k1 = nil
.line	1988	jmp            0   l66
.line	1988	getupval      r3    u0
.line	1988	call          r3     1     2
.line	1988	eq             1    r1    r3
.line	1988	jmp            0   l66
.line	1988	gettable      r3    r0    k3 ; k3 = "PreviewRuntimeIds"
.line	1988	test          r3     0
.line	1988	jmp            0   l66
.line	1988	gettable      r3    r0    k5 ; k5 = "CustomUIData"
.line	1988	gettable      r3    r3    r1
.line	1988	testset       r4    r3     0
.line	1988	jmp            0   l46
.line	1988	gettable      r4    r3    k6 ; k6 = "UMGCanvasInfo"
.line	1988	test          r4     0
.line	1988	jmp            0   l46
.line	1988	gettable      r4    r3    k6 ; k6 = "UMGCanvasInfo"
.line	1988	gettable      r4    r4    k7 ; k7 = "AllWidgets"
.label	l46
.line	1988	test          r4     0
.line	1988	jmp            0   l52
.line	1988	gettable      r5    r4    k8 ; k8 = "overrides"
.line	1988	test          r5     0
.line	1988	jmp            0   l52
.line	1988	gettable      r4    r4    k8 ; k8 = "overrides"
.label	l52
.line	1988	test          r4     0
.line	1988	jmp            0   l64
.line	1988	loadk         r5    k4 ; k4 = 1
.line	1988	len           r6    r4
.line	1988	loadk         r7    k4 ; k4 = 1
.line	1988	move          r0    r0
.line	1988	gettable      r9    r4    r8
.line	1988	test          r9     0
.line	1988	jmp            0   l63
.line	1988	gettable     r10    r0    k3 ; k3 = "PreviewRuntimeIds"
.line	1988	settable     r10    r9    k1 ; k1 = nil
.label	l63
.line	1988	move          r0    r0
.label	l64
.line	1988	gettable      r5    r0    k3 ; k3 = "PreviewRuntimeIds"
.line	1988	settable      r5    r1    k1 ; k1 = nil
.label	l66
.line	1988	self          r3    r0    k9 ; k9 = "ClientRemoveUMGByRun" (truncated)
.line	1988	move          r5    r1
.line	1988	move          r6    r2
.line	1988	call          r3     4     1
.line	1988	return        r0     1
.line	1988	move          r0    r0
.line	1988	move          r0    r0
.line	1988	move          r0    r0
.line	1988	move          r0    r0
.line	1988	return        r0     1

.function	main/f87

.source	null
.linedefined	2020
.lastlinedefined	2047
.numparams	3
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"HasAuthority"
.constant	k1	"print"
.constant	k2	"bWriteLog"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	126
.constant	k6	68
.constant	k7	7
.constant	k8	41
.constant	k9	164
.constant	k10	170
.constant	k11	39
.constant	k12	95
.constant	k13	24
.constant	k14	91
.constant	k15	26
.constant	k16	31
.constant	k17	217
.constant	k18	83
.constant	k19	38
.constant	k20	54
.constant	k21	137
.constant	k22	103
.constant	k23	102
.constant	k24	25
.constant	k25	99
.constant	k26	156
.constant	k27	76
.constant	k28	122
.constant	k29	113
.constant	k30	108
.constant	k31	28
.constant	k32	22
.constant	k33	201
.constant	k34	88
.constant	k35	6
.constant	k36	58
.constant	k37	144
.constant	k38	81
.constant	k39	64
.constant	k40	17
.constant	k41	98
.constant	k42	150
.constant	k43	110
.constant	k44	84
.constant	k45	1
.constant	k46	148
.constant	k47	227
.constant	k48	34
.constant	k49	50
.constant	k50	94
.constant	k51	5
.constant	k52	19
.constant	k53	18
.constant	k54	10
.constant	k55	185
.constant	k56	125
.constant	k57	73
.constant	k58	135
.constant	k59	"tostring"
.constant	k60	"_CancelledAsyncSeqs"
.constant	k61	true
.constant	k62	53
.constant	k63	77
.constant	k64	12
.constant	k65	127
.constant	k66	0
.constant	k67	163
.constant	k68	101
.constant	k69	65
.constant	k70	29
.constant	k71	nil
.constant	k72	3
.constant	k73	79
.constant	k74	90
.constant	k75	211
.constant	k76	119
.constant	k77	55
.constant	k78	117
.constant	k79	78
.constant	k80	133
.constant	k81	"CustomUIData"
.constant	k82	56
.constant	k83	40
.constant	k84	8
.constant	k85	213
.constant	k86	162
.constant	k87	114
.constant	k88	30
.constant	k89	134
.constant	k90	"UMGCanvasInfo"
.constant	k91	37
.constant	k92	87
.constant	k93	105
.constant	k94	74
.constant	k95	16
.constant	k96	195
.constant	k97	14
.constant	k98	179
.constant	k99	96
.constant	k100	27
.constant	k101	4
.constant	k102	207
.constant	k103	"DestroyRuntimeInstance"

.line	2020	self          r3    r0    k0 ; k0 = "HasAuthority"
.line	2020	call          r3     2     2
.line	2020	test          r3     1
.line	2020	jmp            0   l86
.line	2020	gettabup      r3    u0    k1 ; k1 = "print"
.line	2020	gettabup      r4    u0    k2 ; k2 = "bWriteLog"
.line	2020	test          r4     0
.line	2020	jmp            0   l81
.line	2020	gettabup      r4    u0    k3 ; k3 = "table"
.line	2020	gettable      r4    r4    k4 ; k4 = "concat"
.line	2020	newtable      r5     1     0
.line	2020	getupval      r6    u1
.line	2020	loadk         r7    k5 ; k5 = 126
.line	2020	loadk         r8    k6 ; k6 = 68
.line	2020	loadk         r9    k7 ; k7 = 7
.line	2020	loadk        r10    k8 ; k8 = 41
.line	2020	loadk        r11    k9 ; k9 = 164
.line	2020	loadk        r12   k10 ; k10 = 170
.line	2020	loadk        r13   k11 ; k11 = 39
.line	2020	loadk        r14   k12 ; k12 = 95
.line	2020	loadk        r15   k13 ; k13 = 24
.line	2020	loadk        r16   k14 ; k14 = 91
.line	2020	loadk        r17   k15 ; k15 = 26
.line	2020	loadk        r18   k16 ; k16 = 31
.line	2020	loadk        r19   k17 ; k17 = 217
.line	2020	loadk        r20   k18 ; k18 = 83
.line	2020	loadk        r21   k19 ; k19 = 38
.line	2020	loadk        r22   k20 ; k20 = 54
.line	2020	loadk        r23   k21 ; k21 = 137
.line	2020	loadk        r24   k22 ; k22 = 103
.line	2020	loadk        r25   k23 ; k23 = 102
.line	2020	loadk        r26   k24 ; k24 = 25
.line	2020	loadk        r27   k25 ; k25 = 99
.line	2020	loadk        r28   k26 ; k26 = 156
.line	2020	loadk        r29   k27 ; k27 = 76
.line	2020	loadk        r30   k28 ; k28 = 122
.line	2020	loadk        r31   k29 ; k29 = 113
.line	2020	loadk        r32   k30 ; k30 = 108
.line	2020	loadk        r33   k31 ; k31 = 28
.line	2020	loadk        r34   k32 ; k32 = 22
.line	2020	loadk        r35   k33 ; k33 = 201
.line	2020	loadk        r36   k34 ; k34 = 88
.line	2020	loadk        r37   k35 ; k35 = 6
.line	2020	loadk        r38   k36 ; k36 = 58
.line	2020	loadk        r39   k37 ; k37 = 144
.line	2020	loadk        r40   k38 ; k38 = 81
.line	2020	loadk        r41   k39 ; k39 = 64
.line	2020	loadk        r42   k40 ; k40 = 17
.line	2020	loadk        r43   k41 ; k41 = 98
.line	2020	loadk        r44   k42 ; k42 = 150
.line	2020	loadk        r45   k12 ; k12 = 95
.line	2020	loadk        r46   k43 ; k43 = 110
.line	2020	call          r6    41     2
.line	2020	getupval      r7    u1
.line	2020	loadk         r8   k44 ; k44 = 84
.line	2020	loadk         r9   k14 ; k14 = 91
.line	2020	loadk        r10    k7 ; k7 = 7
.line	2020	loadk        r11   k45 ; k45 = 1
.line	2020	loadk        r12   k46 ; k46 = 148
.line	2020	loadk        r13   k47 ; k47 = 227
.line	2020	loadk        r14   k48 ; k48 = 34
.line	2020	loadk        r15   k38 ; k38 = 81
.line	2020	loadk        r16   k49 ; k49 = 50
.line	2020	loadk        r17   k50 ; k50 = 94
.line	2020	loadk        r18    k6 ; k6 = 68
.line	2020	loadk        r19   k51 ; k51 = 5
.line	2020	loadk        r20   k17 ; k17 = 217
.line	2020	loadk        r21   k52 ; k52 = 19
.line	2020	loadk        r22   k53 ; k53 = 18
.line	2020	loadk        r23   k54 ; k54 = 10
.line	2020	loadk        r24   k55 ; k55 = 185
.line	2020	loadk        r25   k43 ; k43 = 110
.line	2020	loadk        r26   k56 ; k56 = 125
.line	2020	loadk        r27   k54 ; k54 = 10
.line	2020	loadk        r28   k57 ; k57 = 73
.line	2020	loadk        r29   k58 ; k58 = 135
.line	2020	loadk        r30   k34 ; k34 = 88
.line	2020	call          r7    24     0
.line	2020	setlist       r5     0     1
.line	2020	call          r4     2     2
.label	l81
.line	2020	gettabup      r5    u0   k59 ; k59 = "tostring"
.line	2020	move          r6    r1
.line	2020	call          r5     2     0
.line	2020	call          r3     0     1
.line	2020	return        r0     1
.label	l86
.line	2020	test          r2     0
.line	2020	jmp            0  l168
.line	2020	gettable      r3    r0   k60 ; k60 = "_CancelledAsyncSeqs"
.line	2020	settable      r3    r2   k61 ; k61 = true
.line	2020	gettabup      r3    u0    k1 ; k1 = "print"
.line	2020	gettabup      r4    u0    k2 ; k2 = "bWriteLog"
.line	2020	test          r4     0
.line	2020	jmp            0  l164
.line	2020	gettabup      r4    u0    k3 ; k3 = "table"
.line	2020	gettable      r4    r4    k4 ; k4 = "concat"
.line	2020	newtable      r5     1     0
.line	2020	getupval      r6    u1
.line	2020	loadk         r7    k5 ; k5 = 126
.line	2020	loadk         r8    k6 ; k6 = 68
.line	2020	loadk         r9    k7 ; k7 = 7
.line	2020	loadk        r10    k8 ; k8 = 41
.line	2020	loadk        r11    k9 ; k9 = 164
.line	2020	loadk        r12   k10 ; k10 = 170
.line	2020	loadk        r13   k11 ; k11 = 39
.line	2020	loadk        r14   k12 ; k12 = 95
.line	2020	loadk        r15   k13 ; k13 = 24
.line	2020	loadk        r16   k14 ; k14 = 91
.line	2020	loadk        r17   k15 ; k15 = 26
.line	2020	loadk        r18   k16 ; k16 = 31
.line	2020	loadk        r19   k17 ; k17 = 217
.line	2020	loadk        r20   k18 ; k18 = 83
.line	2020	loadk        r21   k19 ; k19 = 38
.line	2020	loadk        r22   k20 ; k20 = 54
.line	2020	loadk        r23   k21 ; k21 = 137
.line	2020	loadk        r24   k22 ; k22 = 103
.line	2020	loadk        r25   k23 ; k23 = 102
.line	2020	loadk        r26   k24 ; k24 = 25
.line	2020	loadk        r27   k25 ; k25 = 99
.line	2020	loadk        r28   k26 ; k26 = 156
.line	2020	loadk        r29   k27 ; k27 = 76
.line	2020	loadk        r30   k28 ; k28 = 122
.line	2020	loadk        r31   k29 ; k29 = 113
.line	2020	loadk        r32   k30 ; k30 = 108
.line	2020	loadk        r33   k31 ; k31 = 28
.line	2020	loadk        r34   k32 ; k32 = 22
.line	2020	loadk        r35   k33 ; k33 = 201
.line	2020	loadk        r36   k34 ; k34 = 88
.line	2020	loadk        r37   k35 ; k35 = 6
.line	2020	loadk        r38   k36 ; k36 = 58
.line	2020	loadk        r39   k37 ; k37 = 144
.line	2020	loadk        r40   k38 ; k38 = 81
.line	2020	loadk        r41   k39 ; k39 = 64
.line	2020	loadk        r42   k40 ; k40 = 17
.line	2020	loadk        r43   k41 ; k41 = 98
.line	2020	loadk        r44   k42 ; k42 = 150
.line	2020	loadk        r45   k12 ; k12 = 95
.line	2020	loadk        r46   k43 ; k43 = 110
.line	2020	call          r6    41     2
.line	2020	getupval      r7    u1
.line	2020	loadk         r8   k44 ; k44 = 84
.line	2020	loadk         r9   k14 ; k14 = 91
.line	2020	loadk        r10    k7 ; k7 = 7
.line	2020	loadk        r11   k45 ; k45 = 1
.line	2020	loadk        r12   k46 ; k46 = 148
.line	2020	loadk        r13   k47 ; k47 = 227
.line	2020	loadk        r14   k49 ; k49 = 50
.line	2020	loadk        r15   k14 ; k14 = 91
.line	2020	loadk        r16   k62 ; k62 = 53
.line	2020	loadk        r17   k63 ; k63 = 77
.line	2020	loadk        r18   k64 ; k64 = 12
.line	2020	loadk        r19    k7 ; k7 = 7
.line	2020	loadk        r20   k42 ; k42 = 150
.line	2020	loadk        r21   k65 ; k65 = 127
.line	2020	loadk        r22   k66 ; k66 = 0
.line	2020	loadk        r23   k35 ; k35 = 6
.line	2020	loadk        r24   k67 ; k67 = 163
.line	2020	loadk        r25   k68 ; k68 = 101
.line	2020	loadk        r26   k69 ; k69 = 65
.line	2020	loadk        r27   k70 ; k70 = 29
.line	2020	loadk        r28   k38 ; k38 = 81
.line	2020	call          r7    22     0
.line	2020	setlist       r5     0     1
.line	2020	call          r4     2     2
.label	l164
.line	2020	gettabup      r5    u0   k59 ; k59 = "tostring"
.line	2020	move          r6    r2
.line	2020	call          r5     2     0
.line	2020	call          r3     0     1
.label	l168
.line	2020	eq             1    r1   k71 ; k71 = nil
.line	2020	jmp            0  l174
.line	2020	getupval      r3    u1
.line	2020	call          r3     1     2
.line	2020	eq             0    r1    r3
.line	2020	jmp            0  l255
.label	l174
.line	2020	gettabup      r3    u0    k1 ; k1 = "print"
.line	2020	gettabup      r4    u0    k2 ; k2 = "bWriteLog"
.line	2020	test          r4     0
.line	2020	jmp            0  l253
.line	2020	gettabup      r4    u0    k3 ; k3 = "table"
.line	2020	gettable      r4    r4    k4 ; k4 = "concat"
.line	2020	newtable      r5     1     0
.line	2020	getupval      r6    u1
.line	2020	loadk         r7    k5 ; k5 = 126
.line	2020	loadk         r8    k6 ; k6 = 68
.line	2020	loadk         r9    k7 ; k7 = 7
.line	2020	loadk        r10    k8 ; k8 = 41
.line	2020	loadk        r11    k9 ; k9 = 164
.line	2020	loadk        r12   k10 ; k10 = 170
.line	2020	loadk        r13   k11 ; k11 = 39
.line	2020	loadk        r14   k12 ; k12 = 95
.line	2020	loadk        r15   k13 ; k13 = 24
.line	2020	loadk        r16   k14 ; k14 = 91
.line	2020	loadk        r17   k15 ; k15 = 26
.line	2020	loadk        r18   k16 ; k16 = 31
.line	2020	loadk        r19   k17 ; k17 = 217
.line	2020	loadk        r20   k18 ; k18 = 83
.line	2020	loadk        r21   k19 ; k19 = 38
.line	2020	loadk        r22   k20 ; k20 = 54
.line	2020	loadk        r23   k21 ; k21 = 137
.line	2020	loadk        r24   k22 ; k22 = 103
.line	2020	loadk        r25   k23 ; k23 = 102
.line	2020	loadk        r26   k24 ; k24 = 25
.line	2020	loadk        r27   k25 ; k25 = 99
.line	2020	loadk        r28   k26 ; k26 = 156
.line	2020	loadk        r29   k27 ; k27 = 76
.line	2020	loadk        r30   k28 ; k28 = 122
.line	2020	loadk        r31   k29 ; k29 = 113
.line	2020	loadk        r32   k30 ; k30 = 108
.line	2020	loadk        r33   k31 ; k31 = 28
.line	2020	loadk        r34   k32 ; k32 = 22
.line	2020	loadk        r35   k33 ; k33 = 201
.line	2020	loadk        r36   k34 ; k34 = 88
.line	2020	loadk        r37   k35 ; k35 = 6
.line	2020	loadk        r38   k36 ; k36 = 58
.line	2020	loadk        r39   k37 ; k37 = 144
.line	2020	loadk        r40   k38 ; k38 = 81
.line	2020	loadk        r41   k39 ; k39 = 64
.line	2020	loadk        r42   k40 ; k40 = 17
.line	2020	loadk        r43   k41 ; k41 = 98
.line	2020	loadk        r44   k42 ; k42 = 150
.line	2020	loadk        r45   k12 ; k12 = 95
.line	2020	loadk        r46   k43 ; k43 = 110
.line	2020	call          r6    41     2
.line	2020	getupval      r7    u1
.line	2020	loadk         r8   k44 ; k44 = 84
.line	2020	loadk         r9   k14 ; k14 = 91
.line	2020	loadk        r10    k7 ; k7 = 7
.line	2020	loadk        r11   k45 ; k45 = 1
.line	2020	loadk        r12   k46 ; k46 = 148
.line	2020	loadk        r13   k47 ; k47 = 227
.line	2020	loadk        r14   k72 ; k72 = 3
.line	2020	loadk        r15   k73 ; k73 = 79
.line	2020	loadk        r16   k62 ; k62 = 53
.line	2020	loadk        r17   k74 ; k74 = 90
.line	2020	loadk        r18   k66 ; k66 = 0
.line	2020	loadk        r19   k35 ; k35 = 6
.line	2020	loadk        r20   k75 ; k75 = 211
.line	2020	loadk        r21   k76 ; k76 = 119
.line	2020	loadk        r22   k77 ; k77 = 55
.line	2020	loadk        r23   k12 ; k12 = 95
.line	2020	loadk        r24    k9 ; k9 = 164
.line	2020	loadk        r25   k78 ; k78 = 117
.line	2020	loadk        r26   k49 ; k49 = 50
.line	2020	loadk        r27   k40 ; k40 = 17
.line	2020	loadk        r28   k79 ; k79 = 78
.line	2020	loadk        r29   k80 ; k80 = 133
.line	2020	loadk        r30   k39 ; k39 = 64
.line	2020	loadk        r31   k23 ; k23 = 102
.line	2020	loadk        r32   k48 ; k48 = 34
.line	2020	loadk        r33   k74 ; k74 = 90
.line	2020	call          r7    27     0
.line	2020	setlist       r5     0     1
.line	2020	call          r4     2     2
.label	l253
.line	2020	call          r3     2     1
.line	2020	return        r0     1
.label	l255
.line	2020	gettable      r3    r0   k81 ; k81 = "CustomUIData"
.line	2020	gettable      r3    r3    r1
.line	2020	test          r3     1
.line	2020	jmp            0  l341
.line	2020	gettabup      r4    u0    k1 ; k1 = "print"
.line	2020	gettabup      r5    u0    k2 ; k2 = "bWriteLog"
.line	2020	test          r5     0
.line	2020	jmp            0  l336
.line	2020	gettabup      r5    u0    k3 ; k3 = "table"
.line	2020	gettable      r5    r5    k4 ; k4 = "concat"
.line	2020	newtable      r6     1     0
.line	2020	getupval      r7    u1
.line	2020	loadk         r8    k5 ; k5 = 126
.line	2020	loadk         r9    k6 ; k6 = 68
.line	2020	loadk        r10    k7 ; k7 = 7
.line	2020	loadk        r11    k8 ; k8 = 41
.line	2020	loadk        r12    k9 ; k9 = 164
.line	2020	loadk        r13   k10 ; k10 = 170
.line	2020	loadk        r14   k11 ; k11 = 39
.line	2020	loadk        r15   k12 ; k12 = 95
.line	2020	loadk        r16   k13 ; k13 = 24
.line	2020	loadk        r17   k14 ; k14 = 91
.line	2020	loadk        r18   k15 ; k15 = 26
.line	2020	loadk        r19   k16 ; k16 = 31
.line	2020	loadk        r20   k17 ; k17 = 217
.line	2020	loadk        r21   k18 ; k18 = 83
.line	2020	loadk        r22   k19 ; k19 = 38
.line	2020	loadk        r23   k20 ; k20 = 54
.line	2020	loadk        r24   k21 ; k21 = 137
.line	2020	loadk        r25   k22 ; k22 = 103
.line	2020	loadk        r26   k23 ; k23 = 102
.line	2020	loadk        r27   k24 ; k24 = 25
.line	2020	loadk        r28   k25 ; k25 = 99
.line	2020	loadk        r29   k26 ; k26 = 156
.line	2020	loadk        r30   k27 ; k27 = 76
.line	2020	loadk        r31   k28 ; k28 = 122
.line	2020	loadk        r32   k29 ; k29 = 113
.line	2020	loadk        r33   k30 ; k30 = 108
.line	2020	loadk        r34   k31 ; k31 = 28
.line	2020	loadk        r35   k32 ; k32 = 22
.line	2020	loadk        r36   k33 ; k33 = 201
.line	2020	loadk        r37   k34 ; k34 = 88
.line	2020	loadk        r38   k35 ; k35 = 6
.line	2020	loadk        r39   k36 ; k36 = 58
.line	2020	loadk        r40   k37 ; k37 = 144
.line	2020	loadk        r41   k38 ; k38 = 81
.line	2020	loadk        r42   k39 ; k39 = 64
.line	2020	loadk        r43   k40 ; k40 = 17
.line	2020	loadk        r44   k41 ; k41 = 98
.line	2020	loadk        r45   k42 ; k42 = 150
.line	2020	loadk        r46   k12 ; k12 = 95
.line	2020	loadk        r47   k43 ; k43 = 110
.line	2020	call          r7    41     2
.line	2020	getupval      r8    u1
.line	2020	loadk         r9   k44 ; k44 = 84
.line	2020	loadk        r10   k14 ; k14 = 91
.line	2020	loadk        r11    k7 ; k7 = 7
.line	2020	loadk        r12   k45 ; k45 = 1
.line	2020	loadk        r13   k46 ; k46 = 148
.line	2020	loadk        r14   k47 ; k47 = 227
.line	2020	loadk        r15   k82 ; k82 = 56
.line	2020	loadk        r16   k44 ; k44 = 84
.line	2020	loadk        r17   k83 ; k83 = 40
.line	2020	loadk        r18   k74 ; k74 = 90
.line	2020	loadk        r19   k84 ; k84 = 8
.line	2020	loadk        r20   k51 ; k51 = 5
.line	2020	loadk        r21   k85 ; k85 = 213
.line	2020	loadk        r22   k14 ; k14 = 91
.line	2020	loadk        r23   k18 ; k18 = 83
.line	2020	loadk        r24   k40 ; k40 = 17
.line	2020	loadk        r25   k86 ; k86 = 162
.line	2020	loadk        r26   k87 ; k87 = 114
.line	2020	loadk        r27   k49 ; k49 = 50
.line	2020	loadk        r28   k88 ; k88 = 30
.line	2020	loadk        r29   k73 ; k73 = 79
.line	2020	loadk        r30   k89 ; k89 = 134
.line	2020	loadk        r31   k73 ; k73 = 79
.line	2020	loadk        r32   k43 ; k43 = 110
.line	2020	call          r8    25     0
.line	2020	setlist       r6     0     1
.line	2020	call          r5     2     2
.label	l336
.line	2020	gettabup      r6    u0   k59 ; k59 = "tostring"
.line	2020	move          r7    r1
.line	2020	call          r6     2     0
.line	2020	call          r4     0     1
.line	2020	return        r0     1
.label	l341
.line	2020	test          r2     0
.line	2020	jmp            0  l345
.line	2020	gettable      r4    r0   k60 ; k60 = "_CancelledAsyncSeqs"
.line	2020	settable      r4    r2   k71 ; k71 = nil
.label	l345
.line	2020	gettable      r4    r3   k90 ; k90 = "UMGCanvasInfo"
.line	2020	test          r4     1
.line	2020	jmp            0  l442
.line	2020	gettabup      r4    u0    k1 ; k1 = "print"
.line	2020	gettabup      r5    u0    k2 ; k2 = "bWriteLog"
.line	2020	test          r5     0
.line	2020	jmp            0  l437
.line	2020	gettabup      r5    u0    k3 ; k3 = "table"
.line	2020	gettable      r5    r5    k4 ; k4 = "concat"
.line	2020	newtable      r6     1     0
.line	2020	getupval      r7    u1
.line	2020	loadk         r8    k5 ; k5 = 126
.line	2020	loadk         r9    k6 ; k6 = 68
.line	2020	loadk        r10    k7 ; k7 = 7
.line	2020	loadk        r11    k8 ; k8 = 41
.line	2020	loadk        r12    k9 ; k9 = 164
.line	2020	loadk        r13   k10 ; k10 = 170
.line	2020	loadk        r14   k11 ; k11 = 39
.line	2020	loadk        r15   k12 ; k12 = 95
.line	2020	loadk        r16   k13 ; k13 = 24
.line	2020	loadk        r17   k14 ; k14 = 91
.line	2020	loadk        r18   k15 ; k15 = 26
.line	2020	loadk        r19   k16 ; k16 = 31
.line	2020	loadk        r20   k17 ; k17 = 217
.line	2020	loadk        r21   k18 ; k18 = 83
.line	2020	loadk        r22   k19 ; k19 = 38
.line	2020	loadk        r23   k20 ; k20 = 54
.line	2020	loadk        r24   k21 ; k21 = 137
.line	2020	loadk        r25   k22 ; k22 = 103
.line	2020	loadk        r26   k23 ; k23 = 102
.line	2020	loadk        r27   k24 ; k24 = 25
.line	2020	loadk        r28   k25 ; k25 = 99
.line	2020	loadk        r29   k26 ; k26 = 156
.line	2020	loadk        r30   k27 ; k27 = 76
.line	2020	loadk        r31   k28 ; k28 = 122
.line	2020	loadk        r32   k29 ; k29 = 113
.line	2020	loadk        r33   k30 ; k30 = 108
.line	2020	loadk        r34   k31 ; k31 = 28
.line	2020	loadk        r35   k32 ; k32 = 22
.line	2020	loadk        r36   k33 ; k33 = 201
.line	2020	loadk        r37   k34 ; k34 = 88
.line	2020	loadk        r38   k35 ; k35 = 6
.line	2020	loadk        r39   k36 ; k36 = 58
.line	2020	loadk        r40   k37 ; k37 = 144
.line	2020	loadk        r41   k38 ; k38 = 81
.line	2020	loadk        r42   k39 ; k39 = 64
.line	2020	loadk        r43   k40 ; k40 = 17
.line	2020	loadk        r44   k41 ; k41 = 98
.line	2020	loadk        r45   k42 ; k42 = 150
.line	2020	loadk        r46   k12 ; k12 = 95
.line	2020	loadk        r47   k43 ; k43 = 110
.line	2020	call          r7    41     2
.line	2020	getupval      r8    u1
.line	2020	loadk         r9   k44 ; k44 = 84
.line	2020	loadk        r10   k14 ; k14 = 91
.line	2020	loadk        r11    k7 ; k7 = 7
.line	2020	loadk        r12   k45 ; k45 = 1
.line	2020	loadk        r13   k46 ; k46 = 148
.line	2020	loadk        r14   k47 ; k47 = 227
.line	2020	loadk        r15   k91 ; k91 = 37
.line	2020	loadk        r16   k14 ; k14 = 91
.line	2020	loadk        r17    k8 ; k8 = 41
.line	2020	loadk        r18   k57 ; k57 = 73
.line	2020	loadk        r19   k64 ; k64 = 12
.line	2020	loadk        r20   k16 ; k16 = 31
.line	2020	loadk        r21   k42 ; k42 = 150
.line	2020	loadk        r22   k92 ; k92 = 87
.line	2020	loadk        r23   k66 ; k66 = 0
.line	2020	loadk        r24   k12 ; k12 = 95
.line	2020	loadk        r25   k67 ; k67 = 163
.line	2020	loadk        r26   k93 ; k93 = 105
.line	2020	loadk        r27   k23 ; k23 = 102
.line	2020	loadk        r28   k34 ; k34 = 88
.line	2020	loadk        r29   k69 ; k69 = 65
.line	2020	loadk        r30   k75 ; k75 = 211
.line	2020	loadk        r31   k18 ; k18 = 83
.line	2020	loadk        r32   k65 ; k65 = 127
.line	2020	loadk        r33   k91 ; k91 = 37
.line	2020	loadk        r34   k94 ; k94 = 74
.line	2020	loadk        r35   k95 ; k95 = 16
.line	2020	loadk        r36   k32 ; k32 = 22
.line	2020	loadk        r37   k96 ; k96 = 195
.line	2020	loadk        r38   k97 ; k97 = 14
.line	2020	loadk        r39   k66 ; k66 = 0
.line	2020	loadk        r40   k97 ; k97 = 14
.line	2020	loadk        r41   k98 ; k98 = 179
.line	2020	loadk        r42   k99 ; k99 = 96
.line	2020	loadk        r43   k25 ; k25 = 99
.line	2020	loadk        r44  k100 ; k100 = 27
.line	2020	call          r8    37     0
.line	2020	setlist       r6     0     1
.line	2020	call          r5     2     2
.label	l437
.line	2020	gettabup      r6    u0   k59 ; k59 = "tostring"
.line	2020	move          r7    r1
.line	2020	call          r6     2     0
.line	2020	call          r4     0     1
.line	2020	return        r0     1
.label	l442
.line	2020	gettabup      r4    u0    k1 ; k1 = "print"
.line	2020	gettabup      r5    u0    k2 ; k2 = "bWriteLog"
.line	2020	test          r5     0
.line	2020	jmp            0  l508
.line	2020	gettabup      r5    u0    k3 ; k3 = "table"
.line	2020	gettable      r5    r5    k4 ; k4 = "concat"
.line	2020	newtable      r6     1     0
.line	2020	getupval      r7    u1
.line	2020	loadk         r8    k5 ; k5 = 126
.line	2020	loadk         r9    k6 ; k6 = 68
.line	2020	loadk        r10    k7 ; k7 = 7
.line	2020	loadk        r11    k8 ; k8 = 41
.line	2020	loadk        r12    k9 ; k9 = 164
.line	2020	loadk        r13   k10 ; k10 = 170
.line	2020	loadk        r14   k11 ; k11 = 39
.line	2020	loadk        r15   k12 ; k12 = 95
.line	2020	loadk        r16   k13 ; k13 = 24
.line	2020	loadk        r17   k14 ; k14 = 91
.line	2020	loadk        r18   k15 ; k15 = 26
.line	2020	loadk        r19   k16 ; k16 = 31
.line	2020	loadk        r20   k17 ; k17 = 217
.line	2020	loadk        r21   k18 ; k18 = 83
.line	2020	loadk        r22   k19 ; k19 = 38
.line	2020	loadk        r23   k20 ; k20 = 54
.line	2020	loadk        r24   k21 ; k21 = 137
.line	2020	loadk        r25   k22 ; k22 = 103
.line	2020	loadk        r26   k23 ; k23 = 102
.line	2020	loadk        r27   k24 ; k24 = 25
.line	2020	loadk        r28   k25 ; k25 = 99
.line	2020	loadk        r29   k26 ; k26 = 156
.line	2020	loadk        r30   k27 ; k27 = 76
.line	2020	loadk        r31   k28 ; k28 = 122
.line	2020	loadk        r32   k29 ; k29 = 113
.line	2020	loadk        r33   k30 ; k30 = 108
.line	2020	loadk        r34   k31 ; k31 = 28
.line	2020	loadk        r35   k32 ; k32 = 22
.line	2020	loadk        r36   k33 ; k33 = 201
.line	2020	loadk        r37   k34 ; k34 = 88
.line	2020	loadk        r38   k35 ; k35 = 6
.line	2020	loadk        r39   k36 ; k36 = 58
.line	2020	loadk        r40   k37 ; k37 = 144
.line	2020	loadk        r41   k38 ; k38 = 81
.line	2020	loadk        r42   k39 ; k39 = 64
.line	2020	loadk        r43   k40 ; k40 = 17
.line	2020	loadk        r44   k41 ; k41 = 98
.line	2020	loadk        r45   k42 ; k42 = 150
.line	2020	loadk        r46   k12 ; k12 = 95
.line	2020	loadk        r47   k43 ; k43 = 110
.line	2020	call          r7    41     2
.line	2020	getupval      r8    u1
.line	2020	loadk         r9   k44 ; k44 = 84
.line	2020	loadk        r10   k14 ; k14 = 91
.line	2020	loadk        r11    k7 ; k7 = 7
.line	2020	loadk        r12   k45 ; k45 = 1
.line	2020	loadk        r13   k46 ; k46 = 148
.line	2020	loadk        r14   k47 ; k47 = 227
.line	2020	loadk        r15   k62 ; k62 = 53
.line	2020	loadk        r16   k12 ; k12 = 95
.line	2020	loadk        r17   k83 ; k83 = 40
.line	2020	loadk        r18   k74 ; k74 = 90
.line	2020	loadk        r19  k100 ; k100 = 27
.line	2020	loadk        r20  k101 ; k101 = 4
.line	2020	loadk        r21  k102 ; k102 = 207
.line	2020	call          r8    14     0
.line	2020	setlist       r6     0     1
.line	2020	call          r5     2     2
.label	l508
.line	2020	gettabup      r6    u0   k59 ; k59 = "tostring"
.line	2020	move          r7    r1
.line	2020	call          r6     2     0
.line	2020	call          r4     0     1
.line	2020	self          r4    r0  k103 ; k103 = "DestroyRuntimeInstan" (truncated)
.line	2020	move          r6    r1
.line	2020	call          r4     3     1
.line	2020	return        r0     1
.line	2020	move          r0    r0
.line	2020	move          r0    r0
.line	2020	return        r0     1

.function	main/f88

.source	null
.linedefined	2049
.lastlinedefined	2091
.numparams	3
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"HasAuthority"
.constant	k1	"print"
.constant	k2	"bWriteLog"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	126
.constant	k6	68
.constant	k7	7
.constant	k8	41
.constant	k9	164
.constant	k10	170
.constant	k11	39
.constant	k12	95
.constant	k13	24
.constant	k14	91
.constant	k15	26
.constant	k16	31
.constant	k17	217
.constant	k18	83
.constant	k19	38
.constant	k20	54
.constant	k21	137
.constant	k22	103
.constant	k23	102
.constant	k24	25
.constant	k25	99
.constant	k26	156
.constant	k27	76
.constant	k28	122
.constant	k29	113
.constant	k30	125
.constant	k31	21
.constant	k32	18
.constant	k33	195
.constant	k34	64
.constant	k35	23
.constant	k36	61
.constant	k37	184
.constant	k38	123
.constant	k39	109
.constant	k40	30
.constant	k41	85
.constant	k42	182
.constant	k43	124
.constant	k44	93
.constant	k45	127
.constant	k46	79
.constant	k47	48
.constant	k48	190
.constant	k49	183
.constant	k50	56
.constant	k51	87
.constant	k52	62
.constant	k53	45
.constant	k54	75
.constant	k55	197
.constant	k56	15
.constant	k57	224
.constant	k58	110
.constant	k59	115
.constant	k60	11
.constant	k61	13
.constant	k62	146
.constant	k63	84
.constant	k64	35
.constant	k65	81
.constant	k66	210
.constant	k67	"tostring"
.constant	k68	"_CancelledAsyncSeqs"
.constant	k69	true
.constant	k70	213
.constant	k71	29
.constant	k72	28
.constant	k73	168
.constant	k74	106
.constant	k75	50
.constant	k76	57
.constant	k77	138
.constant	k78	105
.constant	k79	8
.constant	k80	nil
.constant	k81	228
.constant	k82	107
.constant	k83	119
.constant	k84	49
.constant	k85	100
.constant	k86	211
.constant	k87	72
.constant	k88	121
.constant	k89	199
.constant	k90	66
.constant	k91	10
.constant	k92	"CustomUIData"
.constant	k93	223
.constant	k94	80
.constant	k95	0
.constant	k96	172
.constant	k97	104
.constant	k98	157
.constant	k99	78
.constant	k100	88
.constant	k101	22
.constant	k102	14
.constant	k103	200
.constant	k104	74
.constant	k105	"UMGCanvasInfo"
.constant	k106	194
.constant	k107	1
.constant	k108	114
.constant	k109	17
.constant	k110	101
.constant	k111	63
.constant	k112	212
.constant	k113	27
.constant	k114	180
.constant	k115	130
.constant	k116	108
.constant	k117	92
.constant	k118	69
.constant	k119	191
.constant	k120	"AllWidgets"
.constant	k121	"overrides"
.constant	k122	"OnReceivePreCustomUIDataRemove"

.line	2049	self          r3    r0    k0 ; k0 = "HasAuthority"
.line	2049	call          r3     2     2
.line	2049	test          r3     0
.line	2049	jmp            0   l93
.line	2049	gettabup      r3    u0    k1 ; k1 = "print"
.line	2049	gettabup      r4    u0    k2 ; k2 = "bWriteLog"
.line	2049	test          r4     0
.line	2049	jmp            0   l88
.line	2049	gettabup      r4    u0    k3 ; k3 = "table"
.line	2049	gettable      r4    r4    k4 ; k4 = "concat"
.line	2049	newtable      r5     1     0
.line	2049	getupval      r6    u1
.line	2049	loadk         r7    k5 ; k5 = 126
.line	2049	loadk         r8    k6 ; k6 = 68
.line	2049	loadk         r9    k7 ; k7 = 7
.line	2049	loadk        r10    k8 ; k8 = 41
.line	2049	loadk        r11    k9 ; k9 = 164
.line	2049	loadk        r12   k10 ; k10 = 170
.line	2049	loadk        r13   k11 ; k11 = 39
.line	2049	loadk        r14   k12 ; k12 = 95
.line	2049	loadk        r15   k13 ; k13 = 24
.line	2049	loadk        r16   k14 ; k14 = 91
.line	2049	loadk        r17   k15 ; k15 = 26
.line	2049	loadk        r18   k16 ; k16 = 31
.line	2049	loadk        r19   k17 ; k17 = 217
.line	2049	loadk        r20   k18 ; k18 = 83
.line	2049	loadk        r21   k19 ; k19 = 38
.line	2049	loadk        r22   k20 ; k20 = 54
.line	2049	loadk        r23   k21 ; k21 = 137
.line	2049	loadk        r24   k22 ; k22 = 103
.line	2049	loadk        r25   k23 ; k23 = 102
.line	2049	loadk        r26   k24 ; k24 = 25
.line	2049	loadk        r27   k25 ; k25 = 99
.line	2049	loadk        r28   k26 ; k26 = 156
.line	2049	loadk        r29   k27 ; k27 = 76
.line	2049	loadk        r30   k28 ; k28 = 122
.line	2049	loadk        r31   k29 ; k29 = 113
.line	2049	loadk        r32   k30 ; k30 = 125
.line	2049	loadk        r33   k31 ; k31 = 21
.line	2049	loadk        r34   k32 ; k32 = 18
.line	2049	loadk        r35   k33 ; k33 = 195
.line	2049	loadk        r36   k34 ; k34 = 64
.line	2049	loadk        r37   k35 ; k35 = 23
.line	2049	loadk        r38   k36 ; k36 = 61
.line	2049	loadk        r39   k37 ; k37 = 184
.line	2049	loadk        r40   k38 ; k38 = 123
.line	2049	loadk        r41   k39 ; k39 = 109
.line	2049	loadk        r42   k40 ; k40 = 30
.line	2049	loadk        r43   k41 ; k41 = 85
.line	2049	loadk        r44   k42 ; k42 = 182
.line	2049	loadk        r45   k43 ; k43 = 124
.line	2049	loadk        r46   k44 ; k44 = 93
.line	2049	call          r6    41     2
.line	2049	getupval      r7    u1
.line	2049	loadk         r8   k45 ; k45 = 127
.line	2049	loadk         r9   k46 ; k46 = 79
.line	2049	loadk        r10   k47 ; k47 = 48
.line	2049	loadk        r11   k36 ; k36 = 61
.line	2049	loadk        r12   k48 ; k48 = 190
.line	2049	loadk        r13   k49 ; k49 = 183
.line	2049	loadk        r14   k50 ; k50 = 56
.line	2049	loadk        r15   k51 ; k51 = 87
.line	2049	loadk        r16   k52 ; k52 = 62
.line	2049	loadk        r17   k22 ; k22 = 103
.line	2049	loadk        r18   k53 ; k53 = 45
.line	2049	loadk        r19   k54 ; k54 = 75
.line	2049	loadk        r20   k55 ; k55 = 197
.line	2049	loadk        r21   k41 ; k41 = 85
.line	2049	loadk        r22   k15 ; k15 = 26
.line	2049	loadk        r23   k56 ; k56 = 15
.line	2049	loadk        r24   k57 ; k57 = 224
.line	2049	loadk        r25   k58 ; k58 = 110
.line	2049	loadk        r26   k59 ; k59 = 115
.line	2049	loadk        r27   k60 ; k60 = 11
.line	2049	loadk        r28   k61 ; k61 = 13
.line	2049	loadk        r29   k62 ; k62 = 146
.line	2049	loadk        r30   k63 ; k63 = 84
.line	2049	loadk        r31    k5 ; k5 = 126
.line	2049	loadk        r32   k64 ; k64 = 35
.line	2049	loadk        r33   k65 ; k65 = 81
.line	2049	loadk        r34   k60 ; k60 = 11
.line	2049	loadk        r35   k32 ; k32 = 18
.line	2049	loadk        r36   k66 ; k66 = 210
.line	2049	loadk        r37   k51 ; k51 = 87
.line	2049	call          r7    31     0
.line	2049	setlist       r5     0     1
.line	2049	call          r4     2     2
.label	l88
.line	2049	gettabup      r5    u0   k67 ; k67 = "tostring"
.line	2049	move          r6    r1
.line	2049	call          r5     2     0
.line	2049	call          r3     0     1
.line	2049	return        r0     1
.label	l93
.line	2049	test          r2     0
.line	2049	jmp            0  l181
.line	2049	gettable      r3    r0   k68 ; k68 = "_CancelledAsyncSeqs"
.line	2049	settable      r3    r2   k69 ; k69 = true
.line	2049	gettabup      r3    u0    k1 ; k1 = "print"
.line	2049	gettabup      r4    u0    k2 ; k2 = "bWriteLog"
.line	2049	test          r4     0
.line	2049	jmp            0  l177
.line	2049	gettabup      r4    u0    k3 ; k3 = "table"
.line	2049	gettable      r4    r4    k4 ; k4 = "concat"
.line	2049	newtable      r5     1     0
.line	2049	getupval      r6    u1
.line	2049	loadk         r7    k5 ; k5 = 126
.line	2049	loadk         r8    k6 ; k6 = 68
.line	2049	loadk         r9    k7 ; k7 = 7
.line	2049	loadk        r10    k8 ; k8 = 41
.line	2049	loadk        r11    k9 ; k9 = 164
.line	2049	loadk        r12   k10 ; k10 = 170
.line	2049	loadk        r13   k11 ; k11 = 39
.line	2049	loadk        r14   k12 ; k12 = 95
.line	2049	loadk        r15   k13 ; k13 = 24
.line	2049	loadk        r16   k14 ; k14 = 91
.line	2049	loadk        r17   k15 ; k15 = 26
.line	2049	loadk        r18   k16 ; k16 = 31
.line	2049	loadk        r19   k17 ; k17 = 217
.line	2049	loadk        r20   k18 ; k18 = 83
.line	2049	loadk        r21   k19 ; k19 = 38
.line	2049	loadk        r22   k20 ; k20 = 54
.line	2049	loadk        r23   k21 ; k21 = 137
.line	2049	loadk        r24   k22 ; k22 = 103
.line	2049	loadk        r25   k23 ; k23 = 102
.line	2049	loadk        r26   k24 ; k24 = 25
.line	2049	loadk        r27   k25 ; k25 = 99
.line	2049	loadk        r28   k26 ; k26 = 156
.line	2049	loadk        r29   k27 ; k27 = 76
.line	2049	loadk        r30   k28 ; k28 = 122
.line	2049	loadk        r31   k29 ; k29 = 113
.line	2049	loadk        r32   k30 ; k30 = 125
.line	2049	loadk        r33   k31 ; k31 = 21
.line	2049	loadk        r34   k32 ; k32 = 18
.line	2049	loadk        r35   k33 ; k33 = 195
.line	2049	loadk        r36   k34 ; k34 = 64
.line	2049	loadk        r37   k35 ; k35 = 23
.line	2049	loadk        r38   k36 ; k36 = 61
.line	2049	loadk        r39   k37 ; k37 = 184
.line	2049	loadk        r40   k38 ; k38 = 123
.line	2049	loadk        r41   k39 ; k39 = 109
.line	2049	loadk        r42   k40 ; k40 = 30
.line	2049	loadk        r43   k41 ; k41 = 85
.line	2049	loadk        r44   k42 ; k42 = 182
.line	2049	loadk        r45   k43 ; k43 = 124
.line	2049	loadk        r46   k44 ; k44 = 93
.line	2049	call          r6    41     2
.line	2049	getupval      r7    u1
.line	2049	loadk         r8   k45 ; k45 = 127
.line	2049	loadk         r9   k46 ; k46 = 79
.line	2049	loadk        r10   k47 ; k47 = 48
.line	2049	loadk        r11   k36 ; k36 = 61
.line	2049	loadk        r12   k48 ; k48 = 190
.line	2049	loadk        r13   k49 ; k49 = 183
.line	2049	loadk        r14   k50 ; k50 = 56
.line	2049	loadk        r15   k51 ; k51 = 87
.line	2049	loadk        r16   k52 ; k52 = 62
.line	2049	loadk        r17   k22 ; k22 = 103
.line	2049	loadk        r18   k53 ; k53 = 45
.line	2049	loadk        r19   k54 ; k54 = 75
.line	2049	loadk        r20   k70 ; k70 = 213
.line	2049	loadk        r21   k12 ; k12 = 95
.line	2049	loadk        r22   k71 ; k71 = 29
.line	2049	loadk        r23   k72 ; k72 = 28
.line	2049	loadk        r24   k73 ; k73 = 168
.line	2049	loadk        r25   k74 ; k74 = 106
.line	2049	loadk        r26   k75 ; k75 = 50
.line	2049	loadk        r27   k76 ; k76 = 57
.line	2049	loadk        r28   k18 ; k18 = 83
.line	2049	loadk        r29   k77 ; k77 = 138
.line	2049	loadk        r30   k46 ; k46 = 79
.line	2049	loadk        r31   k78 ; k78 = 105
.line	2049	loadk        r32   k13 ; k13 = 24
.line	2049	loadk        r33   k14 ; k14 = 91
.line	2049	loadk        r34   k79 ; k79 = 8
.line	2049	call          r7    28     0
.line	2049	setlist       r5     0     1
.line	2049	call          r4     2     2
.label	l177
.line	2049	gettabup      r5    u0   k67 ; k67 = "tostring"
.line	2049	move          r6    r2
.line	2049	call          r5     2     0
.line	2049	call          r3     0     1
.label	l181
.line	2049	eq             1    r1   k80 ; k80 = nil
.line	2049	jmp            0  l187
.line	2049	getupval      r3    u1
.line	2049	call          r3     1     2
.line	2049	eq             0    r1    r3
.line	2049	jmp            0  l274
.label	l187
.line	2049	gettabup      r3    u0    k1 ; k1 = "print"
.line	2049	gettabup      r4    u0    k2 ; k2 = "bWriteLog"
.line	2049	test          r4     0
.line	2049	jmp            0  l272
.line	2049	gettabup      r4    u0    k3 ; k3 = "table"
.line	2049	gettable      r4    r4    k4 ; k4 = "concat"
.line	2049	newtable      r5     1     0
.line	2049	getupval      r6    u1
.line	2049	loadk         r7    k5 ; k5 = 126
.line	2049	loadk         r8    k6 ; k6 = 68
.line	2049	loadk         r9    k7 ; k7 = 7
.line	2049	loadk        r10    k8 ; k8 = 41
.line	2049	loadk        r11    k9 ; k9 = 164
.line	2049	loadk        r12   k10 ; k10 = 170
.line	2049	loadk        r13   k11 ; k11 = 39
.line	2049	loadk        r14   k12 ; k12 = 95
.line	2049	loadk        r15   k13 ; k13 = 24
.line	2049	loadk        r16   k14 ; k14 = 91
.line	2049	loadk        r17   k15 ; k15 = 26
.line	2049	loadk        r18   k16 ; k16 = 31
.line	2049	loadk        r19   k17 ; k17 = 217
.line	2049	loadk        r20   k18 ; k18 = 83
.line	2049	loadk        r21   k19 ; k19 = 38
.line	2049	loadk        r22   k20 ; k20 = 54
.line	2049	loadk        r23   k21 ; k21 = 137
.line	2049	loadk        r24   k22 ; k22 = 103
.line	2049	loadk        r25   k23 ; k23 = 102
.line	2049	loadk        r26   k24 ; k24 = 25
.line	2049	loadk        r27   k25 ; k25 = 99
.line	2049	loadk        r28   k26 ; k26 = 156
.line	2049	loadk        r29   k27 ; k27 = 76
.line	2049	loadk        r30   k28 ; k28 = 122
.line	2049	loadk        r31   k29 ; k29 = 113
.line	2049	loadk        r32   k30 ; k30 = 125
.line	2049	loadk        r33   k31 ; k31 = 21
.line	2049	loadk        r34   k32 ; k32 = 18
.line	2049	loadk        r35   k33 ; k33 = 195
.line	2049	loadk        r36   k34 ; k34 = 64
.line	2049	loadk        r37   k35 ; k35 = 23
.line	2049	loadk        r38   k36 ; k36 = 61
.line	2049	loadk        r39   k37 ; k37 = 184
.line	2049	loadk        r40   k38 ; k38 = 123
.line	2049	loadk        r41   k39 ; k39 = 109
.line	2049	loadk        r42   k40 ; k40 = 30
.line	2049	loadk        r43   k41 ; k41 = 85
.line	2049	loadk        r44   k42 ; k42 = 182
.line	2049	loadk        r45   k43 ; k43 = 124
.line	2049	loadk        r46   k44 ; k44 = 93
.line	2049	call          r6    41     2
.line	2049	getupval      r7    u1
.line	2049	loadk         r8   k45 ; k45 = 127
.line	2049	loadk         r9   k46 ; k46 = 79
.line	2049	loadk        r10   k47 ; k47 = 48
.line	2049	loadk        r11   k36 ; k36 = 61
.line	2049	loadk        r12   k48 ; k48 = 190
.line	2049	loadk        r13   k49 ; k49 = 183
.line	2049	loadk        r14   k50 ; k50 = 56
.line	2049	loadk        r15   k51 ; k51 = 87
.line	2049	loadk        r16   k52 ; k52 = 62
.line	2049	loadk        r17   k22 ; k22 = 103
.line	2049	loadk        r18   k53 ; k53 = 45
.line	2049	loadk        r19   k54 ; k54 = 75
.line	2049	loadk        r20   k81 ; k81 = 228
.line	2049	loadk        r21   k54 ; k54 = 75
.line	2049	loadk        r22   k71 ; k71 = 29
.line	2049	loadk        r23   k60 ; k60 = 11
.line	2049	loadk        r24    k9 ; k9 = 164
.line	2049	loadk        r25   k82 ; k82 = 107
.line	2049	loadk        r26   k83 ; k83 = 119
.line	2049	loadk        r27   k84 ; k84 = 49
.line	2049	loadk        r28   k85 ; k85 = 100
.line	2049	loadk        r29   k86 ; k86 = 211
.line	2049	loadk        r30   k87 ; k87 = 72
.line	2049	loadk        r31   k88 ; k88 = 121
.line	2049	loadk        r32   k82 ; k82 = 107
.line	2049	loadk        r33   k51 ; k51 = 87
.line	2049	loadk        r34   k35 ; k35 = 23
.line	2049	loadk        r35   k61 ; k61 = 13
.line	2049	loadk        r36   k89 ; k89 = 199
.line	2049	loadk        r37   k90 ; k90 = 66
.line	2049	loadk        r38   k91 ; k91 = 10
.line	2049	loadk        r39   k60 ; k60 = 11
.line	2049	call          r7    33     0
.line	2049	setlist       r5     0     1
.line	2049	call          r4     2     2
.label	l272
.line	2049	call          r3     2     1
.line	2049	return        r0     1
.label	l274
.line	2049	gettable      r3    r0   k92 ; k92 = "CustomUIData"
.line	2049	gettable      r3    r3    r1
.line	2049	test          r3     1
.line	2049	jmp            0  l366
.line	2049	gettabup      r4    u0    k1 ; k1 = "print"
.line	2049	gettabup      r5    u0    k2 ; k2 = "bWriteLog"
.line	2049	test          r5     0
.line	2049	jmp            0  l361
.line	2049	gettabup      r5    u0    k3 ; k3 = "table"
.line	2049	gettable      r5    r5    k4 ; k4 = "concat"
.line	2049	newtable      r6     1     0
.line	2049	getupval      r7    u1
.line	2049	loadk         r8    k5 ; k5 = 126
.line	2049	loadk         r9    k6 ; k6 = 68
.line	2049	loadk        r10    k7 ; k7 = 7
.line	2049	loadk        r11    k8 ; k8 = 41
.line	2049	loadk        r12    k9 ; k9 = 164
.line	2049	loadk        r13   k10 ; k10 = 170
.line	2049	loadk        r14   k11 ; k11 = 39
.line	2049	loadk        r15   k12 ; k12 = 95
.line	2049	loadk        r16   k13 ; k13 = 24
.line	2049	loadk        r17   k14 ; k14 = 91
.line	2049	loadk        r18   k15 ; k15 = 26
.line	2049	loadk        r19   k16 ; k16 = 31
.line	2049	loadk        r20   k17 ; k17 = 217
.line	2049	loadk        r21   k18 ; k18 = 83
.line	2049	loadk        r22   k19 ; k19 = 38
.line	2049	loadk        r23   k20 ; k20 = 54
.line	2049	loadk        r24   k21 ; k21 = 137
.line	2049	loadk        r25   k22 ; k22 = 103
.line	2049	loadk        r26   k23 ; k23 = 102
.line	2049	loadk        r27   k24 ; k24 = 25
.line	2049	loadk        r28   k25 ; k25 = 99
.line	2049	loadk        r29   k26 ; k26 = 156
.line	2049	loadk        r30   k27 ; k27 = 76
.line	2049	loadk        r31   k28 ; k28 = 122
.line	2049	loadk        r32   k29 ; k29 = 113
.line	2049	loadk        r33   k30 ; k30 = 125
.line	2049	loadk        r34   k31 ; k31 = 21
.line	2049	loadk        r35   k32 ; k32 = 18
.line	2049	loadk        r36   k33 ; k33 = 195
.line	2049	loadk        r37   k34 ; k34 = 64
.line	2049	loadk        r38   k35 ; k35 = 23
.line	2049	loadk        r39   k36 ; k36 = 61
.line	2049	loadk        r40   k37 ; k37 = 184
.line	2049	loadk        r41   k38 ; k38 = 123
.line	2049	loadk        r42   k39 ; k39 = 109
.line	2049	loadk        r43   k40 ; k40 = 30
.line	2049	loadk        r44   k41 ; k41 = 85
.line	2049	loadk        r45   k42 ; k42 = 182
.line	2049	loadk        r46   k43 ; k43 = 124
.line	2049	loadk        r47   k44 ; k44 = 93
.line	2049	call          r7    41     2
.line	2049	getupval      r8    u1
.line	2049	loadk         r9   k45 ; k45 = 127
.line	2049	loadk        r10   k46 ; k46 = 79
.line	2049	loadk        r11   k47 ; k47 = 48
.line	2049	loadk        r12   k36 ; k36 = 61
.line	2049	loadk        r13   k48 ; k48 = 190
.line	2049	loadk        r14   k49 ; k49 = 183
.line	2049	loadk        r15   k50 ; k50 = 56
.line	2049	loadk        r16   k51 ; k51 = 87
.line	2049	loadk        r17   k52 ; k52 = 62
.line	2049	loadk        r18   k22 ; k22 = 103
.line	2049	loadk        r19   k53 ; k53 = 45
.line	2049	loadk        r20   k54 ; k54 = 75
.line	2049	loadk        r21   k93 ; k93 = 223
.line	2049	loadk        r22   k94 ; k94 = 80
.line	2049	loadk        r23   k95 ; k95 = 0
.line	2049	loadk        r24   k60 ; k60 = 11
.line	2049	loadk        r25   k96 ; k96 = 172
.line	2049	loadk        r26   k97 ; k97 = 104
.line	2049	loadk        r27   k29 ; k29 = 113
.line	2049	loadk        r28   k71 ; k71 = 29
.line	2049	loadk        r29   k95 ; k95 = 0
.line	2049	loadk        r30   k98 ; k98 = 157
.line	2049	loadk        r31   k99 ; k99 = 78
.line	2049	loadk        r32    k5 ; k5 = 126
.line	2049	loadk        r33   k82 ; k82 = 107
.line	2049	loadk        r34  k100 ; k100 = 88
.line	2049	loadk        r35  k101 ; k101 = 22
.line	2049	loadk        r36  k102 ; k102 = 14
.line	2049	loadk        r37  k103 ; k103 = 200
.line	2049	loadk        r38  k104 ; k104 = 74
.line	2049	call          r8    31     0
.line	2049	setlist       r6     0     1
.line	2049	call          r5     2     2
.label	l361
.line	2049	gettabup      r6    u0   k67 ; k67 = "tostring"
.line	2049	move          r7    r1
.line	2049	call          r6     2     0
.line	2049	call          r4     0     1
.line	2049	return        r0     1
.label	l366
.line	2049	test          r2     0
.line	2049	jmp            0  l370
.line	2049	gettable      r4    r0   k68 ; k68 = "_CancelledAsyncSeqs"
.line	2049	settable      r4    r2   k80 ; k80 = nil
.label	l370
.line	2049	gettable      r4    r3  k105 ; k105 = "UMGCanvasInfo"
.line	2049	test          r4     1
.line	2049	jmp            0  l475
.line	2049	gettabup      r4    u0    k1 ; k1 = "print"
.line	2049	gettabup      r5    u0    k2 ; k2 = "bWriteLog"
.line	2049	test          r5     0
.line	2049	jmp            0  l470
.line	2049	gettabup      r5    u0    k3 ; k3 = "table"
.line	2049	gettable      r5    r5    k4 ; k4 = "concat"
.line	2049	newtable      r6     2     0
.line	2049	getupval      r7    u1
.line	2049	loadk         r8    k5 ; k5 = 126
.line	2049	loadk         r9    k6 ; k6 = 68
.line	2049	loadk        r10    k7 ; k7 = 7
.line	2049	loadk        r11    k8 ; k8 = 41
.line	2049	loadk        r12    k9 ; k9 = 164
.line	2049	loadk        r13   k10 ; k10 = 170
.line	2049	loadk        r14   k11 ; k11 = 39
.line	2049	loadk        r15   k12 ; k12 = 95
.line	2049	loadk        r16   k13 ; k13 = 24
.line	2049	loadk        r17   k14 ; k14 = 91
.line	2049	loadk        r18   k15 ; k15 = 26
.line	2049	loadk        r19   k16 ; k16 = 31
.line	2049	loadk        r20   k17 ; k17 = 217
.line	2049	loadk        r21   k18 ; k18 = 83
.line	2049	loadk        r22   k19 ; k19 = 38
.line	2049	loadk        r23   k20 ; k20 = 54
.line	2049	loadk        r24   k21 ; k21 = 137
.line	2049	loadk        r25   k22 ; k22 = 103
.line	2049	loadk        r26   k23 ; k23 = 102
.line	2049	loadk        r27   k24 ; k24 = 25
.line	2049	loadk        r28   k25 ; k25 = 99
.line	2049	loadk        r29   k26 ; k26 = 156
.line	2049	loadk        r30   k27 ; k27 = 76
.line	2049	loadk        r31   k28 ; k28 = 122
.line	2049	loadk        r32   k29 ; k29 = 113
.line	2049	loadk        r33   k30 ; k30 = 125
.line	2049	loadk        r34   k31 ; k31 = 21
.line	2049	loadk        r35   k32 ; k32 = 18
.line	2049	loadk        r36   k33 ; k33 = 195
.line	2049	loadk        r37   k34 ; k34 = 64
.line	2049	loadk        r38   k35 ; k35 = 23
.line	2049	loadk        r39   k36 ; k36 = 61
.line	2049	loadk        r40   k37 ; k37 = 184
.line	2049	loadk        r41   k38 ; k38 = 123
.line	2049	loadk        r42   k39 ; k39 = 109
.line	2049	loadk        r43   k40 ; k40 = 30
.line	2049	loadk        r44   k41 ; k41 = 85
.line	2049	loadk        r45   k42 ; k42 = 182
.line	2049	loadk        r46   k43 ; k43 = 124
.line	2049	loadk        r47   k44 ; k44 = 93
.line	2049	call          r7    41     2
.line	2049	getupval      r8    u1
.line	2049	loadk         r9   k45 ; k45 = 127
.line	2049	loadk        r10   k46 ; k46 = 79
.line	2049	loadk        r11   k47 ; k47 = 48
.line	2049	loadk        r12   k36 ; k36 = 61
.line	2049	loadk        r13   k48 ; k48 = 190
.line	2049	loadk        r14   k49 ; k49 = 183
.line	2049	loadk        r15   k50 ; k50 = 56
.line	2049	loadk        r16   k51 ; k51 = 87
.line	2049	loadk        r17   k52 ; k52 = 62
.line	2049	loadk        r18   k22 ; k22 = 103
.line	2049	loadk        r19   k53 ; k53 = 45
.line	2049	loadk        r20   k54 ; k54 = 75
.line	2049	loadk        r21  k106 ; k106 = 194
.line	2049	loadk        r22   k12 ; k12 = 95
.line	2049	loadk        r23  k107 ; k107 = 1
.line	2049	loadk        r24   k13 ; k13 = 24
.line	2049	loadk        r25   k73 ; k73 = 168
.line	2049	loadk        r26  k108 ; k108 = 114
.line	2049	loadk        r27   k75 ; k75 = 50
.line	2049	loadk        r28  k109 ; k109 = 17
.line	2049	loadk        r29   k18 ; k18 = 83
.line	2049	loadk        r30   k86 ; k86 = 211
.line	2049	loadk        r31   k46 ; k46 = 79
.line	2049	loadk        r32  k110 ; k110 = 101
.line	2049	loadk        r33  k111 ; k111 = 63
.line	2049	loadk        r34   k40 ; k40 = 30
.line	2049	loadk        r35   k13 ; k13 = 24
.line	2049	loadk        r36   k14 ; k14 = 91
.line	2049	loadk        r37  k112 ; k112 = 212
.line	2049	loadk        r38   k14 ; k14 = 91
.line	2049	loadk        r39   k61 ; k61 = 13
.line	2049	loadk        r40  k113 ; k113 = 27
.line	2049	loadk        r41  k114 ; k114 = 180
.line	2049	loadk        r42   k38 ; k38 = 123
.line	2049	loadk        r43   k22 ; k22 = 103
.line	2049	loadk        r44   k87 ; k87 = 72
.line	2049	loadk        r45   k18 ; k18 = 83
.line	2049	loadk        r46  k115 ; k115 = 130
.line	2049	loadk        r47   k12 ; k12 = 95
.line	2049	loadk        r48  k116 ; k116 = 108
.line	2049	call          r8    41     2
.line	2049	getupval      r9    u1
.line	2049	loadk        r10  k117 ; k117 = 92
.line	2049	loadk        r11  k118 ; k118 = 69
.line	2049	call          r9     3     0
.line	2049	setlist       r6     0     1
.line	2049	call          r5     2     2
.label	l470
.line	2049	gettabup      r6    u0   k67 ; k67 = "tostring"
.line	2049	move          r7    r1
.line	2049	call          r6     2     0
.line	2049	call          r4     0     1
.line	2049	return        r0     1
.label	l475
.line	2049	gettabup      r4    u0    k1 ; k1 = "print"
.line	2049	gettabup      r5    u0    k2 ; k2 = "bWriteLog"
.line	2049	test          r5     0
.line	2049	jmp            0  l547
.line	2049	gettabup      r5    u0    k3 ; k3 = "table"
.line	2049	gettable      r5    r5    k4 ; k4 = "concat"
.line	2049	newtable      r6     1     0
.line	2049	getupval      r7    u1
.line	2049	loadk         r8    k5 ; k5 = 126
.line	2049	loadk         r9    k6 ; k6 = 68
.line	2049	loadk        r10    k7 ; k7 = 7
.line	2049	loadk        r11    k8 ; k8 = 41
.line	2049	loadk        r12    k9 ; k9 = 164
.line	2049	loadk        r13   k10 ; k10 = 170
.line	2049	loadk        r14   k11 ; k11 = 39
.line	2049	loadk        r15   k12 ; k12 = 95
.line	2049	loadk        r16   k13 ; k13 = 24
.line	2049	loadk        r17   k14 ; k14 = 91
.line	2049	loadk        r18   k15 ; k15 = 26
.line	2049	loadk        r19   k16 ; k16 = 31
.line	2049	loadk        r20   k17 ; k17 = 217
.line	2049	loadk        r21   k18 ; k18 = 83
.line	2049	loadk        r22   k19 ; k19 = 38
.line	2049	loadk        r23   k20 ; k20 = 54
.line	2049	loadk        r24   k21 ; k21 = 137
.line	2049	loadk        r25   k22 ; k22 = 103
.line	2049	loadk        r26   k23 ; k23 = 102
.line	2049	loadk        r27   k24 ; k24 = 25
.line	2049	loadk        r28   k25 ; k25 = 99
.line	2049	loadk        r29   k26 ; k26 = 156
.line	2049	loadk        r30   k27 ; k27 = 76
.line	2049	loadk        r31   k28 ; k28 = 122
.line	2049	loadk        r32   k29 ; k29 = 113
.line	2049	loadk        r33   k30 ; k30 = 125
.line	2049	loadk        r34   k31 ; k31 = 21
.line	2049	loadk        r35   k32 ; k32 = 18
.line	2049	loadk        r36   k33 ; k33 = 195
.line	2049	loadk        r37   k34 ; k34 = 64
.line	2049	loadk        r38   k35 ; k35 = 23
.line	2049	loadk        r39   k36 ; k36 = 61
.line	2049	loadk        r40   k37 ; k37 = 184
.line	2049	loadk        r41   k38 ; k38 = 123
.line	2049	loadk        r42   k39 ; k39 = 109
.line	2049	loadk        r43   k40 ; k40 = 30
.line	2049	loadk        r44   k41 ; k41 = 85
.line	2049	loadk        r45   k42 ; k42 = 182
.line	2049	loadk        r46   k43 ; k43 = 124
.line	2049	loadk        r47   k44 ; k44 = 93
.line	2049	call          r7    41     2
.line	2049	getupval      r8    u1
.line	2049	loadk         r9   k45 ; k45 = 127
.line	2049	loadk        r10   k46 ; k46 = 79
.line	2049	loadk        r11   k47 ; k47 = 48
.line	2049	loadk        r12   k36 ; k36 = 61
.line	2049	loadk        r13   k48 ; k48 = 190
.line	2049	loadk        r14   k49 ; k49 = 183
.line	2049	loadk        r15   k50 ; k50 = 56
.line	2049	loadk        r16   k51 ; k51 = 87
.line	2049	loadk        r17   k52 ; k52 = 62
.line	2049	loadk        r18   k22 ; k22 = 103
.line	2049	loadk        r19   k53 ; k53 = 45
.line	2049	loadk        r20   k54 ; k54 = 75
.line	2049	loadk        r21   k66 ; k66 = 210
.line	2049	loadk        r22   k14 ; k14 = 91
.line	2049	loadk        r23   k95 ; k95 = 0
.line	2049	loadk        r24   k60 ; k60 = 11
.line	2049	loadk        r25  k119 ; k119 = 191
.line	2049	loadk        r26   k78 ; k78 = 105
.line	2049	loadk        r27   k82 ; k82 = 107
.line	2049	call          r8    20     0
.line	2049	setlist       r6     0     1
.line	2049	call          r5     2     2
.label	l547
.line	2049	gettabup      r6    u0   k67 ; k67 = "tostring"
.line	2049	move          r7    r1
.line	2049	call          r6     2     0
.line	2049	call          r4     0     1
.line	2049	newtable      r4     1     0
.line	2049	move          r5    r1
.line	2049	setlist       r4     1     1
.line	2049	gettable      r5    r3  k105 ; k105 = "UMGCanvasInfo"
.line	2049	gettable      r5    r5  k120 ; k120 = "AllWidgets"
.line	2049	test          r5     0
.line	2049	jmp            0  l562
.line	2049	gettable      r6    r5  k121 ; k121 = "overrides"
.line	2049	test          r6     0
.line	2049	jmp            0  l562
.line	2049	gettable      r5    r5  k121 ; k121 = "overrides"
.label	l562
.line	2049	test          r5     0
.line	2049	jmp            0  l575
.line	2049	loadk         r6  k107 ; k107 = 1
.line	2049	len           r7    r5
.line	2049	loadk         r8  k107 ; k107 = 1
.line	2049	move          r0    r0
.line	2049	gettable     r10    r5    r9
.line	2049	test         r10     0
.line	2049	jmp            0  l574
.line	2049	len          r11    r4
.line	2049	add          r11   r11  k107 ; k107 = 1
.line	2049	settable      r4   r11   r10
.label	l574
.line	2049	move          r0    r0
.label	l575
.line	2049	loadk         r6  k107 ; k107 = 1
.line	2049	len           r7    r4
.line	2049	loadk         r8  k107 ; k107 = 1
.line	2049	move          r0    r0
.line	2049	self         r10    r0  k122 ; k122 = "OnReceivePreCustomUI" (truncated)
.line	2049	gettable     r12    r4    r9
.line	2049	call         r10     3     1
.line	2049	move          r0    r0
.line	2049	return        r0     1
.line	2049	move          r0    r0
.line	2049	move          r0    r0
.line	2049	gettabup      r2    u0   k33 ; k33 = 195
.line	2049	move          r0    r0
.line	2049	return        r0     1

.function	main/f89

.source	"=[V12L:e8d8142c4c74863c:0697651d5704b1b4]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f90

.source	"=[V11_@Black_MagicYT BlackMagiYT_LBIND_00]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_0_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f91

.source	"=[V11_@Black_MagicYT BlackMagiYT_SYSC_01]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_1_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f92

.source	"=[V11_@Black_MagicYT BlackMagiYT_MRGE_02]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_2_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f93

.source	"=[V11_@Black_MagicYT BlackMagiYT_POOL_03]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_3_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

