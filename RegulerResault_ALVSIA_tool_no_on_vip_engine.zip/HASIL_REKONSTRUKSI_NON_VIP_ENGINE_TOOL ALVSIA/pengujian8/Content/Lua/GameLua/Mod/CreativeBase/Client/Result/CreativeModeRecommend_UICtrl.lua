do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(172, 72, 0, 215, 89)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 231, 163, 137, 248, 199, 77, 117, 124, 241, 173, 132, 68, 192, 60, 244, 122, 219, 163))), nil, {
  ["ctor"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_.ModInfo = require((table.concat({
        U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 209, 122, 197, 163, 128, 219, 208, 86, 42, 76, 225, 190, 154, 8, 248),
        U1(189, 65, 0, 208, 67, 173, 35, 214, 109, 226, 110, 237, 162, 137, 203, 200, 75, 109)
      }))):GetPartOfModInfo()
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.ModInfo.base.mod_id) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.ModInfo.base.mod_id).pub_mod_meta and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.ModInfo.base.mod_id).pub_mod_meta.setting then
        _ARG_0_.ModInfo.setting = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.ModInfo.base.mod_id).pub_mod_meta.setting
      else
      end
      _ARG_0_.bOutcomeUI = _ARG_2_
      _ARG_0_.bisEditResult = (CGameState and CGameState.GetInitializeGameType and CGameState:GetInitializeGameType() or nil) ~= nil and (CGameState and CGameState.GetInitializeGameType and CGameState:GetInitializeGameType() or nil) == U2.CreativeModeGameType_Editor
      if Client.IsEditor() then
      end
      _ARG_0_.BackupResultData = _ARG_3_
      _ARG_0_.FollowState = 0
      _ARG_0_.presetVoteScore = 0
      _ARG_0_.BisFirstSelcted = true
      _ARG_0_.BeforeOffset = 0
      _ARG_0_.ScrollInfor = {}
      _ARG_0_.SendModTime = nil
      _ARG_0_.bCollect = false
      _ARG_0_.ShareExtraInfo = {}
      _ARG_0_.EggTipsUI = nil
      _ARG_0_.EggTipsTimer = nil
      _ARG_0_.EggItemScrollBox = nil
      do return end
      _ARG_0_ = U1.Comment
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 93, 248, 82, 198, 175, 132, 222, 208, 67, 109, 123, 225))
      U2.__super.OnInitialize(_ARG_0_)
      _ARG_0_.UIRoot.Button_Back:SetWidgetVisibility(_ARG_0_.bOutcomeUI and UEnums.ESlateVisibility.SelfHitTestInvisible or UEnums.ESlateVisibility.Collapsed)
      if not _ARG_0_.bisEditResult then
        _ARG_0_.share_ui = _ARG_0_:CreateChildWindow(U1(140, 69, 15, 210, 75, 168, 22, 250, 108, 227, 103, 231, 153, 144, 194, 211, 94, 96, 116), UIManager.UI_Config_InGame.CreativeMode_DetailOperate_Item_UIBP)
      end
      _ARG_0_:_InitRecommendMods()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      __super.RegistEvents(_ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Attention, _ARG_0_.OnClickButtonAttention, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Attention1, _ARG_0_.OnClickButtonAttention, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Report, _ARG_0_.OnClickButtonReport, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Report_1, _ARG_0_.OnClickButtonReport, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Back, _ARG_0_.OnClickButtonBack, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Exit, _ARG_0_.OnClickButtonExit, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Gift, _ARG_0_.OnClickButtonGift, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Add, _ARG_0_.OnClickButtonAddTag, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Add1, _ARG_0_.OnClickButtonAddTag, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Again, _ARG_0_.OnClickButtonAgain, _ARG_0_)
      if _ARG_0_.UIRoot.Button_Share then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Share, _ARG_0_.OnClickButtonShare, _ARG_0_)
      else
        U1.print(U1.bWriteLog and U1.table.concat({
          U2(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 64, 243, 124, 193, 181, 132, 242, 199, 74, 106, 117, 247, 234, 214, 6, 249),
          U2(186, 80, 21, 203, 68, 132, 21, 243, 99, 244, 110, 152, 184, 143, 211, 129, 89, 123, 100, 250, 190, 199, 22, 216, 121, 255, 107, 136, 164, 153, 217, 213)
        }))
      end
      if _ARG_0_.UIRoot.Button_Like then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Like, _ARG_0_.OnClickButtonCollect, _ARG_0_)
      else
        U1.print(U1.bWriteLog and U1.table.concat({
          U2(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 64, 243, 124, 193, 181, 132, 242, 199, 74, 106, 117, 247, 234, 214, 6, 249),
          U2(186, 80, 21, 203, 68, 132, 10, 242, 105, 227, 43, 214, 185, 148, 135, 199, 80, 97, 127, 240, 246, 203, 69, 192, 123, 230, 59, 202, 175, 158, 211)
        }))
      end
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_UPDATE_COLLECT, _ARG_0_.OnUpdateCollect, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_GET_MINE_MODS, _ARG_0_.OnGetAllMetaKey, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.LoopScrollGrid_Mod, U2(128, 74, 52, 215, 79, 169, 21, 248, 112, 233, 103, 212, 179, 132), _ARG_0_.OnUserScrolled, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.LoopScrollGrid_Mod, U2(128, 74, 36, 202, 78, 136, 37, 233, 109, 234, 103), _ARG_0_.OnEndScroll, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Anim_Step_On, U2(128, 74, 32, 202, 67, 182, 39, 239, 107, 233, 101, 254, 191, 142, 206, 210, 87, 113, 117), _ARG_0_._OnClickEditComment, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Anim_Up, U2(128, 74, 32, 202, 67, 182, 39, 239, 107, 233, 101, 254, 191, 142, 206, 210, 87, 113, 117), _ARG_0_._OnClickEditComment, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_AUTHOR_SUMMARY_RSP, _ARG_0_._SetModInfo, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Edit, _ARG_0_._OnClickEditComment, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_2, _ARG_0_.OnClickCommentMask, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_QUERY_COMMENTS_DATA_RSP, _ARG_0_._OnCommentUpdate, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_POST_COMMENT_RSP, _ARG_0_._OnCommentUpdate, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_GET_COMMENT_STATE_RSP, _ARG_0_.OnCommentStateRsp, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_StepOn, _ARG_0_.OnClickVoteButton, _ARG_0_, 1)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Good, _ARG_0_.OnClickVoteButton, _ARG_0_, 5)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_UPDATE_AUTHOR_FOLLOW_STATUS, _ARG_0_.OnUpdateFollowStatus, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_EXCEED_FOLLOW_LIMIT, _ARG_0_.OnExceedFollowLimit, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_GET_RESULT_RECOMMEND_ID_LIST, _ARG_0_.OnGetRecommendModIdList, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_GET_RESULT_PROMOTION_ID_LIST, _ARG_0_.OnGetRecommendModIdList, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_SELECT_MOD, _ARG_0_.OnClickButtonExit, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_GET_PLAYER_VOTE_DATA, _ARG_0_.OnGetPlayerVoteData, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_GET_COMMENT_STATE_RSP, _ARG_0_.OnCommentStateRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_PERSON_SPACE, U1.EVENTID_POPULARITY_PSPACE_SEND_GIFT_RSP, _ARG_0_.PlayGiftAnim, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_WOW_PASS, U1.EVENTID_WOW_PASS_HIDE_TAB, _ARG_0_._SetModInfo, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_WOW_PASS, U1.EVENTID_WOW_PASS_SEASON_ID, _ARG_0_._SetModInfo, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_CAN_FREE_REVIEW_RSP, _ARG_0_.OnCanFreeReviewRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_APPRECIATION_TASK_SYNC, _ARG_0_.InitAppreciationGroupEmphasisItem, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostInitialize"] = function(_ARG_0_)
    do
      __super.OnPostInitialize(_ARG_0_)
      U1.PufferDownloader.EnableDownloadInBattle()
      _ARG_0_.UIRoot.NamedSlot_Tips:SetWidgetVisibility(U1.UEnums.ESlateVisibility.Visible)
      _ARG_0_:PlayUserWidgetAnimation(_ARG_0_.UIRoot.Anim_Tips, 0, 1, 0, 1)
      _ARG_0_:RequestFreeReviewStatus()
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.UGC_AppreciationGroup_Emphasis_Item_UIBP.Button_Appreciation, _ARG_0_.OnClickReviewerEvaluateItem, _ARG_0_)
      _ARG_0_:InitAppreciationGroupEmphasisItem()
      if U1.LocUtil.IsClientTextMirror() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RequestFreeReviewStatus"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitAppreciationGroupEmphasisItem"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_ugc_appreciation_group):GetReviewerLevelInfo() then
        if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_ugc_appreciation_group):GetReviewerLevelInfo() then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshEvaluateItemMutualExclusion"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCanFreeReviewRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_0_.ModInfo or _ARG_0_.ModInfo.base.mod_id ~= _ARG_4_ then
        return
      end
      _ARG_0_:RefreshEvaluateItemMutualExclusion()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      if _ARG_0_.SendModTime then
        _ARG_0_.SendModTime = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnAndroidBack"] = function(_ARG_0_)
    do
      if _ARG_0_.bOutcomeUI then
        _ARG_0_:OnClickButtonBack()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShow"] = function(_ARG_0_)
    do
      __super.OnShow(_ARG_0_)
      U1.printf((U2(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 93, 248, 72, 192, 169, 135)))
      _ARG_0_:AddTimer(0, function()
        if UIRoot then
          _ENV:PlayUserWidgetAnimation(UIRoot.Anim_Fadein, 0, 1, 0, 1)
        end
        return
      end)
      _ARG_0_:_SetModInfo()
      if not _ARG_0_:_InitComment() then
        if U1.slua.isValid((U1.require((U2(136, 69, 12, 193, 102, 174, 39, 181, 69, 231, 102, 221, 149, 143, 213, 196, 17, 80, 112, 224, 187, 197, 113, 202, 127, 243, 107, 196, 167, 137, 243, 208, 91, 101))).GetPlayerState())) then
          if U1.require((U2(136, 69, 12, 193, 102, 174, 39, 181, 69, 231, 102, 221, 149, 143, 213, 196, 17, 80, 112, 224, 187, 197, 113, 202, 127, 243, 107, 196, 167, 137, 243, 208, 91, 101))).GetPlayerState().IsTeamGameOver ~= nil and not U1.require((U2(136, 69, 12, 193, 102, 174, 39, 181, 69, 231, 102, 221, 149, 143, 213, 196, 17, 80, 112, 224, 187, 197, 113, 202, 127, 243, 107, 196, 167, 137, 243, 208, 91, 101))).GetPlayerState():IsTeamGameOver() then
            if not (U1.CGameState and U1.CGameState:GetCurrentStateComponent() or nil):GetGameProcessOver() then
              if U1.require((U1.table.concat({
                U2(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 213, 119, 193, 163, 158, 195, 159, 108, 107, 108, 233, 175, 149, 82, 149),
                U2(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 149, 143, 202, 204, 90, 122, 101, 193, 174, 130, 90, 194, 102, 239)
              }))) then
              end
            else
            end
          else
          end
        else
        end
      end
      if not (U1.CGameState and U1.CGameState.RoomType and U1.CGameState.RoomType == U2(186, 67, 2)) and 0 < (_ARG_0_:GetModID() or 0) then
        _ARG_0_.bShowRecommendList = false
      end
      if U1.CGameState.PlayerTagType ~= nil and U1.CGameState.PlayerTagType ~= 0 and not (_ARG_0_.ModInfo.base.uid == U1.tonumber(U1.DataMgr.roleData.uid)) then
        if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_player_vote_tag):GetOrSendUgcQueryModVoteReq(_ARG_0_.ModInfo.mod_id) then
          _ARG_0_.lastVoteTime = U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_player_vote_tag):GetOrSendUgcQueryModVoteReq(_ARG_0_.ModInfo.mod_id).last_vote_time
        else
          _ARG_0_.bWaitingVoteData = true
        end
      end
      do return end
      _ARG_0_ = GetCurrentStateComponent
    end
  end,
  ["CheckBackUserAddFriend"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_return_recommend_friend):IsNeedShowRecUI() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsVotedLastDay"] = function(_ARG_0_)
    do
      if require((U1(172, 72, 8, 193, 68, 175, 104, 248, 109, 235, 102, 215, 184, 206, 211, 200, 82, 113, 78, 225, 174, 130, 90))).WithinInNDay(_ARG_0_.lastVoteTime, 1) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGetPlayerVoteData"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and table.concat({
        U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 93, 248, 92, 205, 178, 160, 219, 208, 86, 97, 115, 210, 165, 143, 67, 255),
        U1(174, 80, 0, 132, 92, 180, 50, 254, 75, 232, 109, 215, 246)
      }) .. tostring(_ARG_3_) .. U1(239, 87, 4, 200, 76, 245, 36, 204, 99, 239, 127, 209, 184, 135, 241, 206, 75, 113, 85, 245, 174, 138, 22) .. tostring(_ARG_0_.bWaitingVoteData))
      if _ARG_0_.bWaitingVoteData then
        _ARG_0_.lastVoteTime = _ARG_3_ and _ARG_3_.last_vote_time or 0
        _ARG_0_.bWaitingVoteData = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateFollowStatus"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 93, 248, 78, 216, 162, 145, 195, 212, 105, 107, 109, 232, 165, 140, 117, 207),
        U1(174, 80, 20, 215)
      }))
      if _ARG_3_ ~= _ARG_0_.ModInfo.base.uid then
        log(bWriteLog and table.concat({
          U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 93, 248, 78, 216, 162, 145, 195, 212, 105, 107, 109, 232, 165, 140, 117, 207),
          U1(174, 80, 20, 215, 10, 186, 51, 239, 106, 233, 121, 231, 163, 137, 195, 129, 2, 52)
        }) .. tostring(_ARG_3_) .. U1(227, 4, 3, 197, 89, 190, 104, 238, 107, 226, 43, 133, 246) .. tostring(_ARG_0_.ModInfo.base.uid))
        return
      end
      if tonumber(_ARG_0_.ModInfo.base.uid) == tonumber(DataMgr.roleData.uid) then
      elseif not (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor):GetAuthorFollowStatus(_ARG_0_.ModInfo.base.uid) or 0) then
      else
        _ARG_0_.FollowState = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor):GetAuthorFollowStatus(_ARG_0_.ModInfo.base.uid) or 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnExceedFollowLimit"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if tonumber(_ARG_0_.ModInfo.base.uid) == tonumber(_ARG_3_) then
        _ARG_0_.FollowState = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGetRecommendModIdList"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 93, 248, 92, 205, 178, 162, 210, 210, 64, 105, 108, 225, 164, 159, 107, 212),
        U1(171, 109, 5, 232, 67, 168, 50)
      }))
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetResultRecommandList() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetResultRecommandList() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetResultRecommandList() > 0 or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):OnGetPromotionRecommendList() and #ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):OnGetPromotionRecommendList() > 0 or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_new_process):GetOtherModIdList(_ARG_0_.ModInfo.mod_id) and 0 < #ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_new_process):GetOtherModIdList(_ARG_0_.ModInfo.mod_id) then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetResultRecommandList() then
          goto lbl_307
          ::lbl_307::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):OnGetPromotionRecommendList() then
          goto lbl_320
          ::lbl_320::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        else
        end
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_new_process):GetOtherModIdList(_ARG_0_.ModInfo.mod_id) and 0 < #ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_new_process):GetOtherModIdList(_ARG_0_.ModInfo.mod_id) then
          goto lbl_489
          ::lbl_489::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGetBatchModInfoList"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      printf(table.concat({
        U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 93, 248, 92, 205, 178, 178, 214, 197, 76, 108, 76, 235, 174, 178, 72, 221),
        U1(160, 104, 8, 215, 94, 251, 42, 242, 113, 210, 114, 200, 179, 192, 130, 210)
      }), _ARG_1_)
      if not require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 100, 243, 185, 197, 67, 204, 113, 201, 118, 201, 165, 130, 216, 194))).CheckMetaType(_ARG_2_, require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 100, 243, 185, 197, 67, 204, 113, 201, 118, 201, 165, 130, 216, 194))).ENUM_MODE_TYPE.ResultRecommend) then
        return
      end
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      _ARG_0_.RecommendModList = {}
      goto lbl_428
      ::lbl_428::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):OnGetPromotionRecommendList() then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_new_process):GetOtherModIdList(_ARG_0_.ModInfo.mod_id) and #ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_new_process):GetOtherModIdList(_ARG_0_.ModInfo.mod_id) > 0 then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.RecommendModList and #_ARG_0_.RecommendModList > 0 then
        if not _ARG_0_.bShowRecommendList then
          _ARG_0_.bShowRecommendList = true
        end
        if _ARG_0_.SendModTime then
          _ARG_0_.SendModTime = nil
        end
        _ARG_0_.SendModTime = require((U1(172, 75, 12, 201, 69, 181, 104, 239, 107, 235, 110, 231, 162, 137, 196, 202, 90, 102))).AddTimerOnce(0.5, function()
          _ENV:ScrollShowMod(true, RecommendModWidgetList, 0)
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUserScrolled"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:ScrollShowMod(false, _ARG_0_.RecommendModWidgetList, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEndScroll"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ScrollShowMod"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_1_ then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _ARG_0_.BeforeOffset = 0
      elseif math.floor(_ARG_2_.UIRoot.ItemSize.X) <= _ARG_3_ + (_ARG_2_.UIRoot:GetViewSize().X - 10) % math.floor(_ARG_2_.UIRoot.ItemSize.X) - _ARG_0_.BeforeOffset then
        _ARG_0_.BeforeOffset = _ARG_3_ + (_ARG_2_.UIRoot:GetViewSize().X - 10) % math.floor(_ARG_2_.UIRoot.ItemSize.X)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SendModReachTLog"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 65, 243, 117, 204, 139, 159, 211, 227, 74, 101, 98, 236, 158, 183, 73, 220),
          U1(239, 73, 14, 192, 99, 181, 32, 244, 34, 239, 120, 152, 184, 137, 203)
        }))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetModInfo"] = function(_ARG_0_)
    do
      if not (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUgcFilterTag):GetIDtoTags(_ARG_0_.ModInfo.setting.tag_v2, 1) or {}) then
        return
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_.UIRoot[U1(154, 99, 34, 251, 126, 186, 33, 196, 75, 242, 110, 213, 137) .. 8] then
        if (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUgcFilterTag):GetIDtoTags(_ARG_0_.ModInfo.setting.tag_v2, 1) or {})[8] then
        else
        end
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_0_.UIRoot[U1(154, 99, 34, 251, 126, 186, 33, 196, 75, 242, 110, 213, 137, 181, 238, 227, 111, 75, 33) .. 8] then
        if (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUgcFilterTag):GetIDtoTags(_ARG_0_.ModInfo.setting.tag_v2, 1) or {})[8] then
        else
        end
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_.AuthorId = _ARG_0_.ModInfo.base.uid
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor):GetAuthorFollowStatus(_ARG_0_.ModInfo.base.uid) == nil then
      end
      if tonumber(_ARG_0_.ModInfo.base.uid) == tonumber(DataMgr.roleData.uid) then
      elseif not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor):GetAuthorFollowStatus(_ARG_0_.ModInfo.base.uid) then
      else
        _ARG_0_.FollowState = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor):GetAuthorFollowStatus(_ARG_0_.ModInfo.base.uid)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitTag"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ then
        log_warning(bWriteLog and table.concat({
          U1(148, 65, 5, 211, 75, 169, 34, 198, 34, 197, 121, 221, 183, 148, 206, 215, 90, 89, 126, 240, 191, 185, 83, 200, 125, 251, 118, 205, 168, 148, 226, 248, 21, 77, 111, 237, 190, 175, 71, 220),
          U1(239, 83, 8, 192, 77, 190, 50, 187, 107, 245, 43, 214, 191, 140)
        }))
        return
      end
      if not _ARG_2_ then
        log_warning(bWriteLog and table.concat({
          U1(148, 65, 5, 211, 75, 169, 34, 198, 34, 197, 121, 221, 183, 148, 206, 215, 90, 89, 126, 240, 191, 185, 83, 200, 125, 251, 118, 205, 168, 148, 226, 248, 21, 77, 111, 237, 190, 175, 71, 220),
          U1(239, 71, 14, 202, 76, 178, 33, 187, 107, 245, 43, 214, 191, 140, 135, 213, 94, 115, 49)
        }))
        _ARG_1_:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        return
      end
      _ARG_1_.TextBlock_Name:SetText(_ARG_2_.Name)
      if _ARG_0_.ModInfo.base.wow_pass_season_id and _ARG_0_.ModInfo.base.wow_pass_season_id > 0 and _ARG_0_.ModInfo.base.wow_pass_season_id == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCRank):GetSeason_id() then
      elseif _ARG_0_.ModInfo.base.uid and _ARG_0_.ModInfo.base.uid == tonumber(DataMgr.roleData.uid) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_WOWPass):IsBuyElite() then
      elseif _ARG_2_.PrimaryType and _ARG_2_.PrimaryType ~= 0 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitPlayerAddTagButton"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonAttention"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 93, 248, 88, 196, 175, 147, 220, 243, 90, 112, 117, 235, 164, 186, 82, 207),
        U1(170, 74, 21, 205, 69, 181)
      }))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not require((U1(172, 72, 8, 193, 68, 175, 104, 248, 109, 235, 102, 215, 184, 206, 210, 200, 96, 97, 101, 253, 182))).CanClickNow(require((U1(172, 72, 8, 193, 68, 175, 104, 248, 109, 235, 102, 215, 184, 206, 210, 200, 96, 97, 101, 253, 182))).ClickFrequencyLimit.UGCAuthorFollow) then
        return
      end
      if _ARG_0_.FollowState == 0 then
        _ARG_0_.FollowState = 1
      elseif _ARG_0_.FollowState == 1 then
        _ARG_0_.FollowState = 0
      end
      if _ARG_0_.FollowState == 1 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonReport"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if UIManager.UI_Config_InGame.BattleReportBug then
        UIManager.ShowUI(UIManager.UI_Config_InGame.BattleReportBug, {
          mod_id = _ARG_0_.ModInfo.mod_id,
          bOutcomeUI = _ARG_0_.bOutcomeUI
        })
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonBack"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:Hide()
      if UIManager then
        if UIManager.GetUI(UIManager.UI_Config_InGame.CreativeModeIntegralResult_UI) then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonExit"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:CloseSelf()
      print(bWriteLog and U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 93, 248, 89, 220, 168, 178, 214, 210, 68, 71, 109, 237, 169, 144))
      if _ARG_0_.bisEditResult then
        if SubsystemMgr then
          if SubsystemMgr:Get((U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 212, 212, 83, 96, 66, 225, 184, 152, 79, 216, 102, 243, 118))) then
          end
          if slua.isValid((slua_GameFrontendHUD:GetPlayerController())) and slua.isValid(slua_GameFrontendHUD:GetPlayerController().PlayerState) and slua_GameFrontendHUD:GetPlayerController().PlayerState.AuditDemoFeature and slua_GameFrontendHUD:GetPlayerController().PlayerState.AuditDemoFeature.CheckShowPassTip then
          end
        end
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_creativewow):ReturnLobbyChangeToReturnCWoW() then
      elseif SubsystemMgr and SubsystemMgr:Get((U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 212, 212, 83, 96, 66, 225, 184, 152, 79, 216, 102, 243, 118))) then
      end
      return
    end
  end,
  ["OnClickButtonGift"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonAddTag"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonAgain"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetShareModId"] = function(_ARG_0_)
    do
      do return _ARG_0_.ModInfo and _ARG_0_.ModInfo.mod_id or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonShare"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_0_:GetShareModId() then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_share) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonCollect"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not require((U1(172, 72, 8, 193, 68, 175, 104, 248, 109, 235, 102, 215, 184, 206, 210, 200, 96, 97, 101, 253, 182))).CanClickNow(require((U1(172, 72, 8, 193, 68, 175, 104, 248, 109, 235, 102, 215, 184, 206, 210, 200, 96, 97, 101, 253, 182))).ClickFrequencyLimit.StoreCollectionBtn) then
        return
      end
      if not _ARG_0_:GetShareModId() then
        return
      end
      _ARG_0_.bCollect = not _ARG_0_.bCollect
      if _ARG_0_.bCollect then
      else
      end
      if _ARG_0_.bCollect and require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 100, 243, 185, 197, 67, 204, 113, 201, 118, 201, 165, 130, 216, 194))) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Logic_UGC_TLog) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateCollect"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_0_:GetShareModId() ~= _ARG_3_ then
        return
      end
      _ARG_0_.bCollect = _ARG_4_ == true
      _ARG_0_:RefreshCollectState()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshCollectState"] = function(_ARG_0_)
    do
      if not (_ARG_0_.UIRoot and _ARG_0_.UIRoot.Image_Collection) or not (_ARG_0_.UIRoot and _ARG_0_.UIRoot.Image_Collection).SetActiveColorIndex then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGetAllMetaKey"] = function(_ARG_0_)
    do
      if not _ARG_0_:GetShareModId() then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCSocial) then
        _ARG_0_.bCollect = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCSocial):IsCollect((_ARG_0_:GetShareModId())) == true
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnAuthorInfoClickCallback"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_0_.ModInfo.base.uid or _ARG_0_.ModInfo.base.uid == tonumber(DataMgr.roleData.uid) then
        if IsWoWEditor then
          UIManager.AndroidBackToLobby()
        else
          UIManager.ShowUI(UIManager.UI_Config.ugc_mine_main)
        end
      else
        UIManager.ShowUI(UIManager.UI_Config.ugc_guest_work_panel, _ARG_0_.ModInfo.base.uid)
      end
      EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_SHOW_GUEST)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_InitComment"] = function(_ARG_0_)
    do
      if not _ARG_0_.UIRoot or not _ARG_0_.UIRoot.CanvasPanel_Evaluate then
        return false
      end
      _ARG_0_:ReqCommentState()
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_my_comment):GetUserCommentScoreAndStateInGame() then
      else
        if require((table.concat({
          U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 209, 122, 197, 163, 128, 219, 208, 86, 42, 66, 235, 167, 150, 73, 213),
          U1(225, 103, 19, 193, 75, 175, 47, 237, 103, 203, 106, 214, 183, 135, 194, 211, 107, 123, 126, 248, 169)
        }))):GetGameParameterManager() == nil then
        elseif require((table.concat({
          U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 209, 122, 197, 163, 128, 219, 208, 86, 42, 66, 235, 167, 150, 73, 213),
          U1(225, 103, 19, 193, 75, 175, 47, 237, 103, 203, 106, 214, 183, 135, 194, 211, 107, 123, 126, 248, 169)
        }))):GetGameParameterManager():GetGameParameter((U1(130, 75, 5, 237, 78))) ~= nil then
        end
        if require((table.concat({
          U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 209, 122, 197, 163, 128, 219, 208, 86, 42, 66, 235, 167, 150, 73, 213),
          U1(225, 103, 19, 193, 75, 175, 47, 237, 103, 203, 106, 214, 183, 135, 194, 211, 107, 123, 126, 248, 169)
        }))):GetGameParameterManager():GetGameParameter((U1(130, 75, 5, 237, 78))).Value or _ARG_0_:GetShareModId() then
        end
      end
      if require((table.concat({
        U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 213, 119, 193, 163, 158, 195, 159, 108, 107, 108, 233, 175, 149, 82, 149),
        U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 149, 143, 202, 204, 90, 122, 101, 193, 174, 130, 90, 194, 102, 239)
      }))) then
      end
      do return (require((table.concat({
        U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 213, 119, 193, 163, 158, 195, 159, 108, 107, 108, 233, 175, 149, 82, 149),
        U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 149, 143, 202, 204, 90, 122, 101, 193, 174, 130, 90, 194, 102, 239)
      }))).CheckLeaveGamePopup()) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_InitRecommendMods"] = function(_ARG_0_)
    do
      _ARG_0_.RecommendModWidgetList = _ARG_0_:InitChildClassScrollBox(_ARG_0_.UIRoot.LoopScrollGrid_Mod, table.concat({
        U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 213, 119, 193, 163, 158, 195, 159, 125, 97, 114, 241, 166, 143, 8, 248),
        U1(189, 65, 0, 208, 67, 173, 35, 214, 109, 226, 110, 234, 179, 131, 200, 204, 82, 113, 127, 240, 133, 162, 66, 206, 127, 201, 78, 225, 133, 132, 197, 221)
      }), nil, require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 100, 243, 185, 197, 85, 196, 124, 240, 114, 207, 153, 133, 208, 210))).Source_Open_Detail.InGameResultRecommend)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnClickEditComment"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 77, 217, 117, 235, 170, 153, 212, 218, 106, 96, 104, 240, 137, 148, 75, 214),
        U1(170, 74, 21)
      }))
      _ARG_0_.UIRoot.Image_0:SetColorAndOpacity(FLinearColor(1, 1, 1, 0.7))
      if _ARG_0_.ModId == nil then
        if require((table.concat({
          U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 209, 122, 197, 163, 128, 219, 208, 86, 42, 66, 235, 167, 150, 73, 213),
          U1(225, 103, 19, 193, 75, 175, 47, 237, 103, 203, 106, 214, 183, 135, 194, 211, 107, 123, 126, 248, 169)
        }))):GetGameParameterManager() == nil then
          return
        end
        if require((table.concat({
          U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 209, 122, 197, 163, 128, 219, 208, 86, 42, 66, 235, 167, 150, 73, 213),
          U1(225, 103, 19, 193, 75, 175, 47, 237, 103, 203, 106, 214, 183, 135, 194, 211, 107, 123, 126, 248, 169)
        }))):GetGameParameterManager():GetGameParameter((U1(130, 75, 5, 237, 78))) == nil then
          return
        end
        _ARG_0_.ModId = require((table.concat({
          U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 209, 122, 197, 163, 128, 219, 208, 86, 42, 66, 235, 167, 150, 73, 213),
          U1(225, 103, 19, 193, 75, 175, 47, 237, 103, 203, 106, 214, 183, 135, 194, 211, 107, 123, 126, 248, 169)
        }))):GetGameParameterManager():GetGameParameter((U1(130, 75, 5, 237, 78))).Value
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_my_comment):GetUserCommentData(_ARG_0_.ModId) == nil then
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_my_comment):CheckHasCommentedToday((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_my_comment):GetUserCommentData(_ARG_0_.ModId))) then
        return
      end
      ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_my_comment):GetUserCommentData(_ARG_0_.ModId).isEscape = not _ARG_0_.bOutcomeUI
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickReviewerEvaluateItem"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_0_.ModId == nil then
        if require((table.concat({
          U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 209, 122, 197, 163, 128, 219, 208, 86, 42, 66, 235, 167, 150, 73, 213),
          U1(225, 103, 19, 193, 75, 175, 47, 237, 103, 203, 106, 214, 183, 135, 194, 211, 107, 123, 126, 248, 169)
        }))):GetGameParameterManager() == nil then
          return
        end
        if require((table.concat({
          U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 209, 122, 197, 163, 128, 219, 208, 86, 42, 66, 235, 167, 150, 73, 213),
          U1(225, 103, 19, 193, 75, 175, 47, 237, 103, 203, 106, 214, 183, 135, 194, 211, 107, 123, 126, 248, 169)
        }))):GetGameParameterManager():GetGameParameter((U1(130, 75, 5, 237, 78))) == nil then
          return
        end
        _ARG_0_.ModId = require((table.concat({
          U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 209, 122, 197, 163, 128, 219, 208, 86, 42, 66, 235, 167, 150, 73, 213),
          U1(225, 103, 19, 193, 75, 175, 47, 237, 103, 203, 106, 214, 183, 135, 194, 211, 107, 123, 126, 248, 169)
        }))):GetGameParameterManager():GetGameParameter((U1(130, 75, 5, 237, 78))).Value
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_my_comment):CheckHasCommentedToday((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_my_comment):GetUserCommentData(_ARG_0_.ModId))) then
        return
      end
      if not ((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):BatchGetModInfo({
        _ARG_0_.ModId
      }) or {})[_ARG_0_.ModId] and (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):BatchGetModInfo({
        _ARG_0_.ModId
      }) or {})[_ARG_0_.ModId].pub_mod_meta) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnCommentUpdate"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 77, 217, 117, 235, 169, 157, 218, 212, 65, 112, 84, 244, 174, 154, 82, 222))
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_my_comment):GetUserCommentScoreAndStateInGame() then
        if not (ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_ugc_appreciation_group):IsReviewer() or ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_ugc_appreciation_group):GetCanFreeReview(_ARG_0_.ModInfo.base.mod_id) == true) then
        end
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_my_comment):GetUserCommentScoreAndStateInGame() then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetCommentScore"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.UIRoot.WidgetSwitcher_Star:SetActiveWidgetIndex(0 < _ARG_1_ and 1 or 0)
      _ARG_0_.UIRoot.WidgetSwitcher_Star1:SetActiveWidgetIndex(1 < _ARG_1_ and 1 or 0)
      _ARG_0_.UIRoot.WidgetSwitcher_Star2:SetActiveWidgetIndex(2 < _ARG_1_ and 1 or 0)
      _ARG_0_.UIRoot.WidgetSwitcher_Star3:SetActiveWidgetIndex(3 < _ARG_1_ and 1 or 0)
      _ARG_0_.UIRoot.WidgetSwitcher_Star4:SetActiveWidgetIndex(4 < _ARG_1_ and 1 or 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetCommentVoteScore"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.UIRoot.WidgetSwitcher_2:SetActiveWidgetIndex(_ARG_1_ == 1 and 1 or 0)
      _ARG_0_.UIRoot.WidgetSwitcher_Good:SetActiveWidgetIndex(_ARG_1_ == 5 and 1 or 0)
      _ARG_0_.UIRoot.Image_0:SetColorAndOpacity(FLinearColor(1, 1, 1, 0.7))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetModID"] = function(_ARG_0_)
    do
      if not _ARG_0_.ModId then
        if require((table.concat({
          U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 209, 122, 197, 163, 128, 219, 208, 86, 42, 66, 235, 167, 150, 73, 213),
          U1(225, 103, 19, 193, 75, 175, 47, 237, 103, 203, 106, 214, 183, 135, 194, 211, 107, 123, 126, 248, 169)
        }))):GetGameParameterManager() == nil then
          return
        end
        if require((table.concat({
          U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 209, 122, 197, 163, 128, 219, 208, 86, 42, 66, 235, 167, 150, 73, 213),
          U1(225, 103, 19, 193, 75, 175, 47, 237, 103, 203, 106, 214, 183, 135, 194, 211, 107, 123, 126, 248, 169)
        }))):GetGameParameterManager():GetGameParameter((U1(130, 75, 5, 237, 78))) == nil then
          return
        end
        _ARG_0_.ModId = require((table.concat({
          U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 209, 122, 197, 163, 128, 219, 208, 86, 42, 66, 235, 167, 150, 73, 213),
          U1(225, 103, 19, 193, 75, 175, 47, 237, 103, 203, 106, 214, 183, 135, 194, 211, 107, 123, 126, 248, 169)
        }))):GetGameParameterManager():GetGameParameter((U1(130, 75, 5, 237, 78))).Value
      end
      do return _ARG_0_.ModId end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickVoteButton"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_0_:OnCheckHasCommentedToday() then
        log(bWriteLog and table.concat({
          U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 93, 248, 88, 196, 175, 147, 220, 231, 64, 112, 100, 198, 191, 143, 82, 212),
          U1(161, 4, 7, 197, 67, 183, 35, 255, 44)
        }))
        U2.BattleNormalTipsByTextID(8501099)
        return
      end
      if _ARG_1_ == 1 then
        _ARG_0_.presetVoteScore = 1
      else
        _ARG_0_.presetVoteScore = 5
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCheckHasCommentedToday"] = function(_ARG_0_)
    do
      if _ARG_0_.ModId == nil then
        if require((table.concat({
          U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 209, 122, 197, 163, 128, 219, 208, 86, 42, 66, 235, 167, 150, 73, 213),
          U1(225, 103, 19, 193, 75, 175, 47, 237, 103, 203, 106, 214, 183, 135, 194, 211, 107, 123, 126, 248, 169)
        }))):GetGameParameterManager() == nil then
          return false
        end
        if require((table.concat({
          U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 209, 122, 197, 163, 128, 219, 208, 86, 42, 66, 235, 167, 150, 73, 213),
          U1(225, 103, 19, 193, 75, 175, 47, 237, 103, 203, 106, 214, 183, 135, 194, 211, 107, 123, 126, 248, 169)
        }))):GetGameParameterManager():GetGameParameter((U1(130, 75, 5, 237, 78))) == nil then
          return false
        end
        _ARG_0_.ModId = require((table.concat({
          U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 209, 122, 197, 163, 128, 219, 208, 86, 42, 66, 235, 167, 150, 73, 213),
          U1(225, 103, 19, 193, 75, 175, 47, 237, 103, 203, 106, 214, 183, 135, 194, 211, 107, 123, 126, 248, 169)
        }))):GetGameParameterManager():GetGameParameter((U1(130, 75, 5, 237, 78))).Value
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_my_comment):GetUserCommentData(_ARG_0_.ModId) == nil then
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_my_comment):CheckHasCommentedToday((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_my_comment):GetUserCommentData(_ARG_0_.ModId))) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TLogReport"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqCommentState"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.Button_2:SetWidgetVisibility(Visible)
      _ARG_0_.UIRoot.NamedSlot_Tips:SetWidgetVisibility(U1.UEnums.ESlateVisibility.Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCommentStateRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ and _ARG_3_ ~= _ENV() then
        U1.log(U1.bWriteLog and U1.table.concat({
          _ENV(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 93, 248, 88, 199, 171, 157, 210, 223, 91, 87, 117, 229, 190, 158, 116, 200),
          _ENV(191, 4, 91, 158, 111, 169, 52, 244, 112, 210, 98, 200, 165)
        }) .. U1.tostring(_ARG_3_))
        _ARG_0_.CommentErrorTipsKey = _ARG_3_
      else
        _ARG_0_.UIRoot.Button_2:SetWidgetVisibility(U1.UEnums.ESlateVisibility.Collapsed)
        _ARG_0_.UIRoot.NamedSlot_Tips:SetWidgetVisibility(U1.UEnums.ESlateVisibility.Visible)
        U1.log(U1.bWriteLog and U1.table.concat({
          _ENV(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 93, 248, 88, 199, 171, 157, 210, 223, 91, 87, 117, 229, 190, 158, 116, 200),
          _ENV(191, 4, 21, 214, 95, 190)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_3_ = _ENV[95]
    end
  end,
  ["OnClickCommentMask"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      log(bWriteLog and table.concat({
        U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 93, 248, 88, 196, 175, 147, 220, 242, 64, 105, 108, 225, 164, 143, 107, 218),
        U1(188, 79)
      }))
      if _ARG_0_.CommentErrorTipsKey and _ARG_0_.CommentErrorTipsKey ~= U1() then
        ShowNotice(_ARG_0_.CommentErrorTipsKey)
      else
        ShowNotice(LocUtil.GetLocalizeResStr(79284))
        log(bWriteLog and table.concat({
          U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 93, 248, 88, 196, 175, 147, 220, 242, 64, 105, 108, 225, 164, 143, 107, 218),
          U1(188, 79, 142, 24, 176, 149, 9, 187, 86, 207, 91, 235)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayGiftAnim"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_3_ then
        return
      end
      log_tree(bWriteLog and table.concat({
        U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 66, 250, 122, 209, 129, 153, 209, 197, 110, 106, 104, 233, 230, 219, 79, 213),
        U1(169, 75, 65, 205, 89, 225)
      }), _ARG_3_)
      if require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).BlockSocialAnimGiftSourceCfg[_ARG_3_.gift_source] then
        return
      end
      if require((table.concat({
        U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 181, 143, 201, 199, 86, 115, 63, 215, 182, 130, 83, 197, 102, 219, 122, 203, 180, 159, 196, 159, 127, 113, 99, 232, 163, 136, 78, 233),
        U1(170, 67, 8, 203, 68, 150, 39, 248, 112, 233, 120)
      }))).IsFITVersion() and require((table.concat({
        U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 117, 251, 173, 133, 90, 196, 115, 242, 53, 216, 179, 150, 209, 212, 93, 42, 113, 241, 172, 157, 67, 201),
        U1(144, 73, 0, 202, 75, 188, 35, 233)
      }))).ShowDownloadTips(require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 117, 251, 173, 133, 90, 196, 115, 242, 53, 216, 179, 150, 209, 212, 93, 91, 98, 235, 164, 136, 82))).ENUM_DownloadType.ODPACK, {
        require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 117, 251, 173, 133, 90, 196, 115, 242, 53, 216, 179, 150, 209, 212, 93, 91, 98, 235, 164, 136, 82))).EODPackID.SocialLobby
      }) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayGiftAnimByType"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 66, 250, 122, 209, 129, 153, 209, 197, 110, 106, 104, 233, 136, 130, 114, 194),
        U1(191, 65, 91)
      }) .. tostring(_ARG_1_))
      if require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 199, 125, 241, 114, 203, 153, 134, 222, 213, 74, 107, 94, 227, 163, 157, 82))).IsVideoGift(_ARG_1_) and require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 199, 125, 241, 114, 203, 153, 134, 222, 213, 74, 107, 94, 227, 163, 157, 82))).CheckVideoGiftValid(_ARG_1_) then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_gift_download):IsGiftResourceDownloaded(_ARG_1_) then
        return
      end
      if _ARG_0_.UIRoot.animation then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckWowGiftTips"] = function(_ARG_0_)
    do
      if not _ARG_0_.UIRoot.CanvasPanel_37 then
      end
      if not (require((table.concat({
        U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
        U1(188)
      }))).LoadFileToTable_N(require((table.concat({
        U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
        U1(188)
      }))).ePlayerPrefsType.eUGCWowGiftTips) or {} or {})[require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame] then
        ;(require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))).LoadFileToTable_N(require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))).ePlayerPrefsType.eUGCWowGiftTips) or {} or {})[require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame] = {}
      end
      if (require((table.concat({
        U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
        U1(188)
      }))).LoadFileToTable_N(require((table.concat({
        U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
        U1(188)
      }))).ePlayerPrefsType.eUGCWowGiftTips) or {} or {})[require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame].Time and os.time({
        year = os.date(U1(234, 125), (require((U1(172, 72, 8, 193, 68, 175, 104, 248, 109, 235, 102, 215, 184, 206, 211, 200, 82, 113, 78, 225, 174, 130, 90))).GetServerTimeInSec())),
        month = os.date(U1(234, 73), (require((U1(172, 72, 8, 193, 68, 175, 104, 248, 109, 235, 102, 215, 184, 206, 211, 200, 82, 113, 78, 225, 174, 130, 90))).GetServerTimeInSec())),
        day = os.date(U1(234, 64), (require((U1(172, 72, 8, 193, 68, 175, 104, 248, 109, 235, 102, 215, 184, 206, 211, 200, 82, 113, 78, 225, 174, 130, 90))).GetServerTimeInSec())),
        hour = 0,
        min = 0,
        sec = 0
      }) <= (require((table.concat({
        U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
        U1(188)
      }))).LoadFileToTable_N(require((table.concat({
        U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
        U1(188)
      }))).ePlayerPrefsType.eUGCWowGiftTips) or {} or {})[require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame].Time then
        if (require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))).LoadFileToTable_N(require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))).ePlayerPrefsType.eUGCWowGiftTips) or {} or {})[require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame].Count and (require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))).LoadFileToTable_N(require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))).ePlayerPrefsType.eUGCWowGiftTips) or {} or {})[require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame].Count >= 3 then
        end
      end
      if false then
        if (require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))).LoadFileToTable_N(require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))).ePlayerPrefsType.eUGCWowGiftTips) or {} or {})[require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame].Time and os.time({
          year = os.date(U1(234, 125), (require((U1(172, 72, 8, 193, 68, 175, 104, 248, 109, 235, 102, 215, 184, 206, 211, 200, 82, 113, 78, 225, 174, 130, 90))).GetServerTimeInSec())),
          month = os.date(U1(234, 73), (require((U1(172, 72, 8, 193, 68, 175, 104, 248, 109, 235, 102, 215, 184, 206, 211, 200, 82, 113, 78, 225, 174, 130, 90))).GetServerTimeInSec())),
          day = os.date(U1(234, 64), (require((U1(172, 72, 8, 193, 68, 175, 104, 248, 109, 235, 102, 215, 184, 206, 211, 200, 82, 113, 78, 225, 174, 130, 90))).GetServerTimeInSec())),
          hour = 0,
          min = 0,
          sec = 0
        }) <= (require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))).LoadFileToTable_N(require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))).ePlayerPrefsType.eUGCWowGiftTips) or {} or {})[require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame].Time then
          ;(require((table.concat({
            U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
            U1(188)
          }))).LoadFileToTable_N(require((table.concat({
            U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
            U1(188)
          }))).ePlayerPrefsType.eUGCWowGiftTips) or {} or {})[require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame].Count = (tonumber((require((table.concat({
            U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
            U1(188)
          }))).LoadFileToTable_N(require((table.concat({
            U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
            U1(188)
          }))).ePlayerPrefsType.eUGCWowGiftTips) or {} or {})[require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame].Count) or 1) + 1
        else
          ;(require((table.concat({
            U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
            U1(188)
          }))).LoadFileToTable_N(require((table.concat({
            U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
            U1(188)
          }))).ePlayerPrefsType.eUGCWowGiftTips) or {} or {})[require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame].Count = 1
        end
        ;(require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))).LoadFileToTable_N(require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))).ePlayerPrefsType.eUGCWowGiftTips) or {} or {})[require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame].Time = require((U1(172, 72, 8, 193, 68, 175, 104, 248, 109, 235, 102, 215, 184, 206, 211, 200, 82, 113, 78, 225, 174, 130, 90))).GetServerTimeInSec(), require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))), require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))).LoadFileToTable_N(require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))).ePlayerPrefsType.eUGCWowGiftTips) or {} or {}, os.time({
          year = os.date(U1(234, 125), (require((U1(172, 72, 8, 193, 68, 175, 104, 248, 109, 235, 102, 215, 184, 206, 211, 200, 82, 113, 78, 225, 174, 130, 90))).GetServerTimeInSec())),
          month = os.date(U1(234, 73), (require((U1(172, 72, 8, 193, 68, 175, 104, 248, 109, 235, 102, 215, 184, 206, 211, 200, 82, 113, 78, 225, 174, 130, 90))).GetServerTimeInSec())),
          day = os.date(U1(234, 64), (require((U1(172, 72, 8, 193, 68, 175, 104, 248, 109, 235, 102, 215, 184, 206, 211, 200, 82, 113, 78, 225, 174, 130, 90))).GetServerTimeInSec())),
          hour = 0,
          min = 0,
          sec = 0
        }), (require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))).LoadFileToTable_N(require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))).ePlayerPrefsType.eUGCWowGiftTips) or {} or {})[require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame]
        if not _ARG_0_.tipsUI then
          _ARG_0_.tipsUI = _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.CanvasPanel_37, UIManager.UI_Config.Common_Tips_Top_UIBP, (LocUtil.LocalizeResFormat(68738)))
        end
        if _ARG_0_.tipsTimer then
          _ARG_0_.tipsTimer = nil
        end
        _ARG_0_.tipsTimer = _ARG_0_:AddTimerOnce(5, function()
          _ENV:CloseReturnGiveTips()
          return
        end)
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseReturnGiveTips"] = function(_ARG_0_)
    do
      if _ARG_0_.tipsUI then
        _ARG_0_.tipsUI:CloseSelf()
        _ARG_0_.tipsUI = nil
        log(bWriteLog and table.concat({
          U1(140, 86, 4, 197, 94, 178, 48, 254, 79, 233, 111, 221, 132, 133, 196, 206, 82, 121, 116, 250, 190, 190, 127, 145, 81, 254, 126, 203, 173, 167, 216, 198, 104, 109, 103, 240, 158, 146, 86, 200),
          U1(239, 103, 13, 203, 89, 190, 124)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshEggAward"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 149, 146, 194, 192, 75, 125, 103, 241, 152, 138, 69, 206, 60, 213, 119, 193, 163, 158, 195, 159, 125, 97, 114, 241, 166, 143, 8, 248),
        U1(189, 65, 0, 208, 67, 173, 35, 214, 109, 226, 110, 234, 179, 147, 210, 205, 75, 81, 118, 243, 143, 159, 95, 199)
      }))).GetEggAward(_ARG_0_.BackupResultData and _ARG_0_.BackupResultData.battleResult) then
        return false
      end
      if (_ARG_0_.UIRoot.CreativeMode_Recommend_Item_02_UIBP and (_ARG_0_.UIRoot.CreativeMode_Recommend_Item_02_UIBP.UIRoot or _ARG_0_.UIRoot.CreativeMode_Recommend_Item_02_UIBP) or nil) and (_ARG_0_.UIRoot.CreativeMode_Recommend_Item_02_UIBP and (_ARG_0_.UIRoot.CreativeMode_Recommend_Item_02_UIBP.UIRoot or _ARG_0_.UIRoot.CreativeMode_Recommend_Item_02_UIBP) or nil).LoopScrollBox_Task then
        if not _ARG_0_.EggItemScrollBox then
          _ARG_0_.EggItemScrollBox = _ARG_0_:InitChildClassScrollBox((_ARG_0_.UIRoot.CreativeMode_Recommend_Item_02_UIBP and (_ARG_0_.UIRoot.CreativeMode_Recommend_Item_02_UIBP.UIRoot or _ARG_0_.UIRoot.CreativeMode_Recommend_Item_02_UIBP) or nil).LoopScrollBox_Task, U2)
        end
        if _ARG_0_.EggItemScrollBox then
        end
      else
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowEggTips"] = function(_ARG_0_, _ARG_1_)
    do
      if #require((table.concat({
        U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 148, 129, 212, 196, 114, 123, 117, 186, 153, 135, 95, 206, 124, 226, 53, 234, 167, 132, 195, 221, 74, 86, 100, 247, 191, 151, 82, 149),
        U1(141, 69, 21, 208, 70, 190, 20, 254, 113, 243, 103, 204, 147, 135, 192, 244, 75, 125, 125)
      }))).BuildGuideTipsQueue({
        itemId = _ARG_1_.items[1].itemId,
        qualityId = _ARG_1_.topQuality,
        firstObtained = _ARG_1_.bFirst
      }) <= 0 then
        return
      end
      _ARG_0_.GuideTipsQueue = require((table.concat({
        U1(136, 69, 12, 193, 102, 174, 39, 181, 79, 233, 111, 150, 148, 129, 212, 196, 114, 123, 117, 186, 153, 135, 95, 206, 124, 226, 53, 234, 167, 132, 195, 221, 74, 86, 100, 247, 191, 151, 82, 149),
        U1(141, 69, 21, 208, 70, 190, 20, 254, 113, 243, 103, 204, 147, 135, 192, 244, 75, 125, 125)
      }))).BuildGuideTipsQueue({
        itemId = _ARG_1_.items[1].itemId,
        qualityId = _ARG_1_.topQuality,
        firstObtained = _ARG_1_.bFirst
      }), _ARG_0_:CloseEggTips()
      _ARG_0_.GuideTipsIndex = 1
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowNextGuideTip"] = function(_ARG_0_)
    do
      if not _ARG_0_.GuideTipsQueue then
        return
      end
      if not (_ARG_0_.EggItemScrollBox and _ARG_0_.EggItemScrollBox:GetIndexOfItem(1) and (_ARG_0_.EggItemScrollBox and _ARG_0_.EggItemScrollBox:GetIndexOfItem(1)).UIRoot and (_ARG_0_.EggItemScrollBox and _ARG_0_.EggItemScrollBox:GetIndexOfItem(1)).UIRoot.Lua_CommonItems) then
        _ARG_0_.EggTipsRetry = (_ARG_0_.EggTipsRetry or 0) + 1
        if _ARG_0_.EggTipsRetry <= U2 then
          _ARG_0_.EggTipsTimer = _ARG_0_:AddTimerOnce(0.1, function()
            EggTipsTimer = nil
            _ENV:ShowNextGuideTip()
            return
          end)
        end
        return
      end
      _ARG_0_.EggTipsRetry = 0
      if not pcall(function()
        do return _ENV:CreateChildWindow(U1.CanvasPanel_ItemBase, U2.UIManager.UI_Config.Common_Settlement_Tips_UIBP, {
          widget = U1:GetItemUIRoot(),
          text = U3[GuideTipsIndex],
          relativePos = U4(157, 77, 6, 204, 94),
          offsetX = 20
        }) end
        return
      end) or not pcall(function()
        do return _ENV:CreateChildWindow(U1.CanvasPanel_ItemBase, U2.UIManager.UI_Config.Common_Settlement_Tips_UIBP, {
          widget = U1:GetItemUIRoot(),
          text = U3[GuideTipsIndex],
          relativePos = U4(157, 77, 6, 204, 94),
          offsetX = 20
        }) end
        return
      end) then
        return
      end
      _ARG_0_.EggTipsUI = pcall(function()
        do return _ENV:CreateChildWindow(U1.CanvasPanel_ItemBase, U2.UIManager.UI_Config.Common_Settlement_Tips_UIBP, {
          widget = U1:GetItemUIRoot(),
          text = U3[GuideTipsIndex],
          relativePos = U4(157, 77, 6, 204, 94),
          offsetX = 20
        }) end
        return
      end)
      _ARG_0_.GuideTipsIndex = _ARG_0_.GuideTipsIndex + 1
      _ARG_0_.EggTipsTimer = _ARG_0_:AddTimerOnce(U3, function()
        EggTipsTimer = nil
        if GuideTipsQueue and GuideTipsIndex <= #GuideTipsQueue then
          _ENV:ShowNextGuideTip()
        else
          _ENV:CloseEggTips()
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseGuideTipsUI"] = function(_ARG_0_)
    do
      if _ARG_0_.EggTipsUI then
        _ARG_0_.EggTipsUI:CloseSelf()
        _ARG_0_.EggTipsUI = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseEggTips"] = function(_ARG_0_)
    do
      if _ARG_0_.EggTipsTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.EggTipsTimer)
        _ARG_0_.EggTipsTimer = nil
      end
      _ARG_0_.GuideTipsQueue = nil
      _ARG_0_.EggTipsRetry = 0
      _ARG_0_:CloseGuideTipsUI()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGiftRSP"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not _ARG_1_.gift_source then
        return
      end
      if _ARG_1_.gift_source == require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).GiftSourceType.UGCModBattleResult then
        if not (require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))).LoadFileToTable_N(require((table.concat({
          U1(172, 72, 8, 193, 68, 175, 104, 247, 109, 225, 98, 219, 248, 172, 200, 198, 86, 119, 65, 248, 187, 146, 83, 217, 66, 228, 126, 206, 181, 222, 199, 221, 78, 125, 100, 246, 186, 137, 67, 221),
          U1(188)
        }))).ePlayerPrefsType.eUGCWowGiftTips) or {}) then
        else
        end
        if ({
          [require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame] = {},
          [require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame] = {},
          [require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame4Count] = {}
        })[require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame].IsDone then
          return
        end
        if ({
          [require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame] = {},
          [require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame] = {},
          [require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame4Count] = {}
        })[require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame4Count] and ({
          [require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame] = {},
          [require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame] = {},
          [require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame4Count] = {}
        })[require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame4Count].IsDone then
          return
        end
        ;({
          [require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame] = {},
          [require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame] = {},
          [require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame4Count] = {}
        })[require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame].IsDone = true
        ;({
          [require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame] = {},
          [require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame] = {},
          [require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame4Count] = {}
        })[require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 118, 253, 188, 159, 24, 204, 123, 240, 111, 247, 165, 159, 217, 194, 91))).EWowPageType.InGame4Count].IsDone = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckToiletSwitch"] = function(_ARG_0_)
    do
      if not LobbySystem.CheckOpen(BP_UGC_Gift_TOILET_SWITCH) and require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 100, 243, 185, 197, 67, 223, 123, 250, 68, 221, 161, 147))).IsModWithEvent(_ARG_0_.ModInfo, require((U1(172, 72, 8, 193, 68, 175, 104, 232, 110, 243, 106, 150, 186, 143, 192, 200, 92, 58, 100, 243, 185, 197, 67, 204, 113, 201, 118, 201, 165, 130, 216, 194))).ENUM_EventElementID.Skibidi_Toilet) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPubPrivateUI"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
