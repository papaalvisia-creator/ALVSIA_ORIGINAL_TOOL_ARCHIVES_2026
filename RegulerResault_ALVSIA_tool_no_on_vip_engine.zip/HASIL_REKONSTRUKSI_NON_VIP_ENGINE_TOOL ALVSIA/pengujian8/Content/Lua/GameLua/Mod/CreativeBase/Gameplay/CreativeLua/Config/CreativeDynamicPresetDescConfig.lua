local table_pool = require("common.table_pool")
local TableUtil = require("common.table_util")
local _TablePool = table_pool.Create()
local CreativeCustomParameterConfig = require("GameLua.Mod.CreativeBase.Gameplay.CustomParameter.CreativeCustomParameterConfig")
local CreativeGlobalDefine = require("GameLua.Mod.CreativeBase.Gameplay.Config.Asset.Common.CreativeGlobalDefine")
local Enum_ParameterType = CreativeGlobalDefine.Enum_ParameterType
local Utility = require("GameLua.Mod.CreativeBase.Gameplay.Meta.CreativeModeUtility")
require("common.macros.item_macros")
local CreativeDynamicPresetDescConfig = {}
CreativeDynamicPresetDescConfig.DefaultIconName = "Blocky_Icon_Action"
local Enum_DynamicType = {
  CreativeInstance = 1,
  CreativeAsset = 2,
  SkillPreset = 3,
  BuffPreset = 4,
  PlayerCustomVar_Number = 5,
  PlayerCustomVar_Int = 6,
  PlayerCustomVar_Bool = 7,
  GlobalCustomVar_Number = 8,
  GlobalCustomVar_Int = 9,
  GlobalCustomVar_Bool = 10,
  PickupPreset = 11,
  ItemPreset = 12,
  EffectPreset = 13,
  MonsterPreset = 14,
  ArmedAIPreset = 15,
  SignalEventPreset = 16,
  SignalFunctionPreset = 17,
  VehiclePreset = 18,
  SoundPreset = 19,
  CustomUIInstance = 20,
  WeatherPreset = 21,
  ColorPreset = 22,
  ImagePreset = 23,
  CharacterAnimationPreset = 24,
  CreativeSpawnerInstance = 25,
  PresetCustomParameter = 26,
  CreativeProjectilePreset = 27,
  CustomItemPreset = 28,
  DropGroupPreset = 29,
  MonsterAnimPreset = 30,
  NPCAnimPreset = 31,
  TreasurePreset = 32,
  GameTaskPreset = 33,
  EmptySkillPreset = 34,
  ThrowSkillPreset = 35,
  BuildSkillPreset = 36,
  NPCPreset = 37,
  CustomEventDefPreset = 38,
  BankProductPreset = 39,
  PropPreset = 40,
  ArmedAIAnimationPreset = 41,
  PropShopPreset = 42,
  CustomTLogEventNamePreset = 43,
  CustomCreativeAsset = 44,
  PropPreset_Count = 45,
  ActorPreset = 46,
  ComponentPreset = 47,
  ModelPreset = 48,
  GameplayButtonPreset = 49,
  CreativeDynamicAsset = 50,
  UMGResPreset = 51,
  UMGCanvasPreset = 52,
  HomeLandAsset = 53,
  CreativeGroupAsset = 54,
  NativeControlTypePreset = 55,
  TriggerAreaPreset = 56,
  PlayerCustomVar_String = 57,
  GlobalCustomVar_String = 58,
  LevelPreset = 59,
  SkeletalModelPreset = 60,
  SkeletalAnimPreset = 61,
  TransDuckSkin = 62,
  GameDeviceParameter = 63,
  PlayerCharacterVariable = 64,
  AnimationGraphPreset = 65,
  PlayerCustomVar_Struct = 66,
  GlobalCustomVar_Struct = 67,
  BlackStruct = 68,
  TeamTypePreset = 69,
  ProfessionTypePreset = 70
}
CreativeDynamicPresetDescConfig.Enum_DynamicType = Enum_DynamicType
CreativeDynamicPresetDescConfig.CreativeInstanceDynamicType = {
  [Enum_DynamicType.CreativeInstance] = true,
  [Enum_DynamicType.CreativeSpawnerInstance] = true
}
local Enum_DynamicTypeCatetory = {
  CreativeInstance = "CreativeInstance",
  CreativeAsset = "CreativeAsset",
  Preset = "Preset"
}
local Enum_VariableTypeName = {
  Player = "Player",
  CreativeInstance = "CreativeInstance",
  CreativeSpawnerInstance = "CreativeSpawnerInstance",
  CreativeAsset = "CreativeAsset",
  SkillPreset = "SkillPreset",
  EmptySkillPreset = "EmptySkillPreset",
  ThrowSkillPreset = "ThrowSkillPreset",
  BuildSkillPreset = "BuildSkillPreset",
  Skill = "Skill",
  BuffPreset = "BuffPreset",
  PickupPreset = "PickupPreset",
  PickUpInstance = "PickUpInstance",
  ItemPreset = "ItemPreset",
  Item = "Item",
  Vehicle = "Vehicle",
  VehiclePreset = "VehiclePreset",
  EffectPreset = "EffectPreset",
  Monster = "Monster",
  MonsterPreset = "MonsterPreset",
  ArmedAI = "ArmedAI",
  ArmedAIPreset = "ArmedAIPreset",
  SignalEventPreset = "SignalEventPreset",
  SignalFunctionPreset = "SignalFunctionPreset",
  TriggerArea = "TriggerArea",
  MarkPoint = "MarkPoint",
  Timer = "Timer",
  SoundPreset = "SoundPreset",
  CustomUIInstance = "CustomUIInstance",
  WeatherPreset = "WeatherPreset",
  BankProductPreset = "BankProductPreset",
  BankProduct = "BankProduct",
  PlayerCustomVar_Number = "PlayerCustomVar_Number",
  PlayerCustomVar_Int = "PlayerCustomVar_Int",
  PlayerCustomVar_Bool = "PlayerCustomVar_Bool",
  PlayerCustomVar_String = "PlayerCustomVar_String",
  PlayerCustomVar_Struct = "PlayerCustomVar_Struct",
  GlobalCustomVar_Number = "GlobalCustomVar_Number",
  GlobalCustomVar_Int = "GlobalCustomVar_Int",
  GlobalCustomVar_Bool = "GlobalCustomVar_Bool",
  GlobalCustomVar_String = "GlobalCustomVar_String",
  GlobalCustomVar_Struct = "GlobalCustomVar_Struct",
  BlackStruct = "BlackStruct",
  ColorPreset = "Color",
  ImagePreset = "ImagePreset",
  CharacterAnimationPreset = "CharacterAnimationPreset",
  PresetCustomParameter = "PresetCustomParameter",
  CreativeProjectilePreset = "CreativeProjectilePreset",
  DropGroupPreset = "DropGroupPreset",
  MonsterAnimPreset = "MonsterAnimPreset",
  NPCAnimPreset = "NPCAnimPreset",
  TreasurePreset = "TreasurePreset",
  GameTaskPreset = "TaskTemplate",
  NPCPreset = "NPCPreset",
  NPC = "NPC",
  CustomEventDefPreset = "CustomEventName",
  PropPreset = "PropPreset",
  ArmedAIAnimationPreset = "ArmedAIAnimationPreset",
  PropShopPreset = "PropShopPreset",
  CustomTLogEventNamePreset = "CustomTLogEventNamePreset",
  PropPreset_Count = "PropPreset_Count",
  ActorPreset = "ActorPreset",
  ComponentPreset = "ComponentPreset",
  ModelPreset = "ModelPreset",
  GameplayButtonPreset = "GameplayButtonPreset",
  UMGResPreset = "UMGPreset",
  UMGCanvasPreset = "UMGCanvasPreset",
  CreativeGroupAsset = "CreativeGroupAsset",
  TriggerAreaPreset = "TriggerAreaPreset",
  NativeControlTypePreset = "NativeControlTypePreset",
  LevelPreset = "LevelPreset",
  SkeletalModelPreset = "SkeletalModelPreset",
  SkeletalAnimPreset = "SkeletalAnimPreset",
  TransSkinID = "TransSkinID",
  GameDeviceParameter = "GameDeviceParameter",
  PlayerCharacterVariable = "PlayerCharacterVariable",
  AnimationGraphPreset = "AnimationGraphPreset",
  TeamTypePreset = "TeamTypePreset",
  ProfessionTypePreset = "ProfessionTypePreset"
}
CreativeDynamicPresetDescConfig.Enum_VariableTypeName = Enum_VariableTypeName
CreativeDynamicPresetDescConfig.AbandonedAsset = {
  [3101103] = true,
  [3101090] = true
}
local PresetDescsDefine = {
  PresetTitle = "",
  PresetValue = "",
  PresetIcon = "",
  OverrideCatetory = "",
  OverrideKeyName = "",
  IsCustomVar = false,
  IsCustomArrayVar = false,
  CustomVarType = "",
  TypeSyncValueTypeName = "",
  bTypeSyncValueIsArray = false,
  PresetExclude = false,
  isValidityPreset = false,
  NeedSelectCheck = false,
  CustomExtraData = "",
  ResInfo = nil
}
local _PresetDescInfos = {}
local _CachePresetDescInfoNum = 0

function CreativeDynamicPresetDescConfig.GetPresetDescInfo()
  local NewPresetDesc
  if 0 < _CachePresetDescInfoNum then
    NewPresetDesc = _PresetDescInfos[_CachePresetDescInfoNum]
    _PresetDescInfos[_CachePresetDescInfoNum] = nil
    _CachePresetDescInfoNum = _CachePresetDescInfoNum - 1
  else
    NewPresetDesc = Utility:DeepCopy(PresetDescsDefine, _TablePool:Get())
  end
  return NewPresetDesc
end

function CreativeDynamicPresetDescConfig.ReturnPresetDescInfo(PresetDesc)
  PresetDesc = Utility:DeepCopy(PresetDescsDefine, PresetDesc)
  table.insert(_PresetDescInfos, PresetDesc)
  _CachePresetDescInfoNum = _CachePresetDescInfoNum + 1
end

function CreativeDynamicPresetDescConfig.ReturnPresetDescInfos(PresetDescs)
  if PresetDescs then
    for i = #PresetDescs, 1, -1 do
      CreativeDynamicPresetDescConfig.ReturnPresetDescInfo(PresetDescs[i])
      PresetDescs[i] = nil
    end
    _TablePool:Recycle(PresetDescs)
  end
end

local TransDuckSkinPresetConfigs = {
  {
    PresetValue = 1,
    SkinID = 150023,
    TitleID = 88421
  },
  {
    PresetValue = 2,
    SkinID = 150024,
    TitleID = 88422
  },
  {
    PresetValue = 3,
    SkinID = 150025,
    TitleID = 88423
  },
  {
    PresetValue = 4,
    SkinID = 150026,
    TitleID = 88417
  },
  {
    PresetValue = 5,
    SkinID = 150027,
    TitleID = 88418
  },
  {
    PresetValue = 6,
    SkinID = 150028,
    TitleID = 88424
  },
  {
    PresetValue = 7,
    SkinID = 150029,
    TitleID = 88419
  },
  {
    PresetValue = 8,
    SkinID = 150030,
    TitleID = 88425
  },
  {
    PresetValue = 9,
    SkinID = 150031,
    TitleID = 88420
  }
}
local TransDuckSkinIDByPresetValue = {}
for _, PresetConfig in ipairs(TransDuckSkinPresetConfigs) do
  TransDuckSkinIDByPresetValue[PresetConfig.PresetValue] = PresetConfig.SkinID
end

function CreativeDynamicPresetDescConfig.ResolveTransDuckSkinID(SkinPresetValue)
  if type(SkinPresetValue) ~= "number" then
    return nil
  end
  return TransDuckSkinIDByPresetValue[SkinPresetValue]
end

function CreativeDynamicPresetDescConfig.GetTransDuckSkinPresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  for _, PresetConfig in ipairs(TransDuckSkinPresetConfigs) do
    local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
    NewPresetDesc.PresetTitle = LocUtil.GetLocalizeResStr(PresetConfig.TitleID)
    NewPresetDesc.PresetValue = PresetConfig.PresetValue
    table.insert(OutPresetDescs, NewPresetDesc)
  end
  return OutPresetDescs
end

local DynamicTypeConfigDefine = {
  FullyStaticConfig = false,
  bNeedPreInit = false,
  Catetory = "",
  VariableTypeName = "",
  PresetDescsGetHandle = nil,
  PresetValueGetHandle = nil,
  CanSelectCheckHandle = nil,
  RegisterNeedChangeEventHandle = nil
}
local _EntityManager

function CreativeDynamicPresetDescConfig.GetCreativeEntityManager()
  if not slua.isValid(_EntityManager) then
    _EntityManager = GetCreativeEntityManager()
  end
  return _EntityManager
end

function CreativeDynamicPresetDescConfig.GetIconName(IconPath)
  if IconPath == nil or IconPath == "" then
    return ""
  end
  return IconPath
end

local ExpiredIconPath = CreativeDynamicPresetDescConfig.GetIconName("/Game/Mod/CreativeBase/Arts/NoAtlas/Icon/Logic/ZD_Iocn_Mosaic.ZD_Iocn_Mosaic")

function CreativeDynamicPresetDescConfig.SetExpiredPresetDesc(PresetDesc)
  PresetDesc.PresetExclude = true
  PresetDesc.PresetIcon = ExpiredIconPath
end

local CustomAssetKeyPrefix = "--[[CustomAssetKey]]'"
local CustomAssetKeyPrefixLen = #CustomAssetKeyPrefix
local CustomAssetKeySuffix = "'"
local CustomAssetKeySuffixLen = #CustomAssetKeySuffix

function CreativeDynamicPresetDescConfig.GenerateCustomAseetKeyPresetValue(CustomAssetKey)
  return CustomAssetKeyPrefix .. tostring(CustomAssetKey) .. CustomAssetKeySuffix
end

function CreativeDynamicPresetDescConfig.ParsePresetValueToCustomAssetKey(PresetValue)
  local tryNumber = tonumber(PresetValue)
  if tryNumber and slua.isValid(CustomAssetMgr) then
    local CustomAssetKey = CustomAssetMgr:GetCustomAssetKeyByHashID(tryNumber)
    if CustomAssetKey and 0 < #CustomAssetKey then
      return CustomAssetKey
    end
  end
  if type(PresetValue) == "string" then
    if string.sub(PresetValue, 1, CustomAssetKeyPrefixLen) == CustomAssetKeyPrefix and string.sub(PresetValue, -CustomAssetKeySuffixLen) == CustomAssetKeySuffix then
      return string.sub(PresetValue, CustomAssetKeyPrefixLen + 1, -(CustomAssetKeySuffixLen + 1))
    end
    if slua.isValid(CustomAssetMgr) and CustomAssetMgr:IsCustomAssetKey(PresetValue, false) then
      return PresetValue
    end
    return nil
  end
  return nil
end

function CreativeDynamicPresetDescConfig.CustomAssetSelectCheck(PresetValue, uPresetDesc)
  local CreativeCustomAssetSubSystem = SubsystemMgr:Get("CreativeCustomAssetSubSystem")
  local CustomAssetDefine = require("common.CustomAsset.CustomAssetDefine")
  if CreativeCustomAssetSubSystem ~= nil then
    local CustomKey = CreativeDynamicPresetDescConfig.ParsePresetValueToCustomAssetKey(PresetValue)
    if CreativeCustomAssetSubSystem:CheckCanAddCustomAsset(CustomKey) ~= CustomAssetDefine.CustomAssetDependLimitType.None then
      CreativeCustomAssetSubSystem:ShowDependLimitUI(CustomAssetDefine.CustomAssetDependLimitDisplayType.CommonTips)
      return 1
    else
      CreativeCustomAssetSubSystem:CacheNewCustomAsset(CustomKey)
    end
  else
    return 1
  end
  return 0
end

function CreativeDynamicPresetDescConfig.CustomModelSelectCheck(PresetValue, uPresetDesc)
  local AssetMgr = GetAssetManager and GetAssetManager() or nil
  if not AssetMgr then
    return 0
  end
  local CreativeCustomAssetSubSystem = SubsystemMgr:Get("CreativeCustomAssetSubSystem")
  local CustomAssetDefine = require("common.CustomAsset.CustomAssetDefine")
  local CreativeAssetConfig = AssetMgr:GetAssetInfo(PresetValue)
  if CreativeAssetConfig then
    local CustomModelConfig = CreativeAssetConfig.CustomModel
    if CustomModelConfig then
      local CustomAssetKey = CustomModelConfig.CustomAssetKey
      if CreativeCustomAssetSubSystem:CheckCanAddCustomAsset(CustomAssetKey) ~= CustomAssetDefine.CustomAssetDependLimitType.None then
        CreativeCustomAssetSubSystem:ShowDependLimitUI(CustomAssetDefine.CustomAssetDependLimitDisplayType.CommonTips)
        return 1
      else
        CreativeCustomAssetSubSystem:CacheNewCustomAsset(CustomAssetKey)
      end
    end
  end
  return 0
end

function CreativeDynamicPresetDescConfig.GetUUIDByKey(Key, EntityType, EntitySubType)
  local EntityManager = CreativeDynamicPresetDescConfig.GetCreativeEntityManager()
  return EntityManager:CreateEntityIfNotExistsFromKey(Key, EntityType, EntitySubType)
end

function CreativeDynamicPresetDescConfig.GetKeyByUUID(UUID)
  local EntityManager = CreativeDynamicPresetDescConfig.GetCreativeEntityManager()
  return EntityManager:UUID2Key(UUID)
end

function CreativeDynamicPresetDescConfig.GetCreativeInstancePresetValue(InstanceID)
  local EEntityType = import("EEntityType")
  return CreativeDynamicPresetDescConfig.GetUUIDByKey(tonumber(InstanceID), EEntityType.BuildingInstance, 0)
end

function CreativeDynamicPresetDescConfig.GetCreativeInstancePresetDescConfigs(bIsDs, EditParamem, FilterInstanceIDMap)
  local OutPresetDescs = _TablePool:Get()
  local InstanceMgr = GetInstanceManager and GetInstanceManager() or nil
  local AssetMgr = GetAssetManager and GetAssetManager() or nil
  if InstanceMgr and AssetMgr then
    local CreativeModeCustomObjectNameUtil = require("GameLua.Mod.CreativeBase.Gameplay.Common.CreativeModeCustomObjectName.CreativeModeCustomObjectNameUtil")
    local Utility = require("GameLua.Mod.CreativeBase.Gameplay.Meta.CreativeModeUtility")
    local InstanceTree = InstanceMgr:GetInstanceTree()
    for InstanceID, InstanceInfo in pairs(InstanceTree) do
      local bCanExport = false
      if FilterInstanceIDMap == nil or FilterInstanceIDMap[InstanceID] == true then
        bCanExport = true
      end
      if bCanExport then
        local baseAssetId, showAssetId = Utility:GetAssetIDForShow(InstanceInfo)
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetTitle = CreativeModeCustomObjectNameUtil.GetInstanceName(InstanceID)
        NewPresetDesc.PresetValue = CreativeDynamicPresetDescConfig.GetCreativeInstancePresetValue(InstanceID)
        NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(AssetMgr:GetAssetDescInfo(showAssetId, "Icon"))
        NewPresetDesc.ResInfo = _TablePool:Get()
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
    local SourceTree, bFromUMGInfoMap = CreativeDynamicPresetDescConfig.GetCustomUIDataTraverseSource()
    if bFromUMGInfoMap and SourceTree then
      for _, SubTree in pairs(SourceTree) do
        for InstanceID, InstanceInfo in pairs(SubTree) do
          if InstanceInfo and (InstanceInfo.CustomUIBase or InstanceInfo.UMGCanvasInfo) and InstanceTree[InstanceID] == nil and InstanceTree[tonumber(InstanceID)] == nil and (FilterInstanceIDMap == nil or FilterInstanceIDMap[InstanceID] == true or FilterInstanceIDMap[tonumber(InstanceID)] == true) then
            local _, showAssetId = Utility:GetAssetIDForShow(InstanceInfo)
            local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
            NewPresetDesc.PresetTitle = CreativeModeCustomObjectNameUtil.GetInstanceName(InstanceID, InstanceInfo)
            NewPresetDesc.PresetValue = CreativeDynamicPresetDescConfig.GetCreativeInstancePresetValue(InstanceID)
            NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(AssetMgr:GetAssetDescInfo(showAssetId, "Icon"))
            NewPresetDesc.ResInfo = _TablePool:Get()
            table.insert(OutPresetDescs, NewPresetDesc)
          end
        end
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetCreativeSpawnerInstancePresetValue(InstanceID)
  local EEntityType = import("EEntityType")
  return "GetInstanceObjectUUID(" .. tostring(CreativeDynamicPresetDescConfig.GetUUIDByKey(tonumber(InstanceID), EEntityType.BuildingInstance, 0)) .. ")"
end

function CreativeDynamicPresetDescConfig.GetCreativeSpawnerInstancePresetDescConfigs(bIsDs, EditParamem, FilterInstanceIDMap)
  local OutPresetDescs = _TablePool:Get()
  local InstanceMgr = GetInstanceManager and GetInstanceManager() or nil
  local AssetMgr = GetAssetManager and GetAssetManager() or nil
  if InstanceMgr and AssetMgr then
    local CreativeModeCustomObjectNameUtil = require("GameLua.Mod.CreativeBase.Gameplay.Common.CreativeModeCustomObjectName.CreativeModeCustomObjectNameUtil")
    local Utility = require("GameLua.Mod.CreativeBase.Gameplay.Meta.CreativeModeUtility")
    local EEntityType = import("EEntityType")
    local InstanceTree = InstanceMgr:GetInstanceTree()
    for InstanceID, InstanceInfo in pairs(InstanceTree) do
      local bCanExport = false
      if FilterInstanceIDMap == nil or FilterInstanceIDMap[InstanceID] == true then
        bCanExport = true
      end
      if bCanExport then
        local baseAssetId, showAssetId = Utility:GetAssetIDForShow(InstanceInfo)
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetTitle = CreativeModeCustomObjectNameUtil.GetInstanceName(InstanceID)
        NewPresetDesc.PresetValue = CreativeDynamicPresetDescConfig.GetCreativeSpawnerInstancePresetValue(InstanceID)
        NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(AssetMgr:GetAssetDescInfo(showAssetId, "Icon"))
        NewPresetDesc.ResInfo = _TablePool:Get()
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  return OutPresetDescs
end

local Enum_AssetPresetCatetory = {
  [1] = 8700146,
  [2] = 8700142,
  [3] = 8700143,
  [4] = 8700144,
  [5] = 8700145,
  [6] = 8700221,
  [9] = 99010290,
  [11] = 99010149,
  [1001] = 8700300
}

local function _GetAssetPresetDescConfigsImpl(bIsDynamicAsset)
  local OutPresetDescs = _TablePool:Get()
  local AssetMgr = GetAssetManager and GetAssetManager() or nil
  if AssetMgr then
    local AllAssetID = bIsDynamicAsset and AssetMgr:GetAllDynamicAssetIds() or AssetMgr:GetAssetAllIds()
    if not AllAssetID then
      return OutPresetDescs
    end
    local CreativeExpiredAssetConfig = require("GameLua.Mod.BaseMod.GamePlay.Config.CreativeExpiredAssetConfig")
    for i = 1, #AllAssetID do
      local AssetID = AllAssetID[i]
      local bIsGroup = AssetMgr:IsGroupAsset(AssetID)
      local bIsHideAsset = AssetMgr:IsHideAsset(AssetID)
      local bIsUIPreset = AssetMgr:IsUIAsset(AssetID)
      local bIsCurVersionExpired = CreativeExpiredAssetConfig.IsCurVersionExpired(AssetID)
      if not bIsGroup and not bIsHideAsset and not bIsCurVersionExpired and not bIsUIPreset then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetTitle = AssetMgr:GetAssetDescInfo(AssetID, "Name")
        NewPresetDesc.PresetValue = AssetID
        if NewPresetDesc.PresetTitle == nil or NewPresetDesc.PresetTitle == "" then
          NewPresetDesc.PresetTitle = tostring(AssetID)
        end
        NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(AssetMgr:GetAssetDescInfo(AssetID, "Icon"))
        NewPresetDesc.PresetTags = CreativeDynamicPresetDescConfig.GetPresetTagsByAssetId(AssetID)
        local TabID = AssetMgr:GetAssetDescInfo(AssetID, "TabID")
        if TabID and TabID ~= "" then
          local tabConfig = CDataTable.GetTableData("UGCAssetTabConfig", TabID)
          if tabConfig then
            if Enum_AssetPresetCatetory[tabConfig.AssetType] ~= nil then
              NewPresetDesc.OverrideCatetory = Enum_AssetPresetCatetory[tabConfig.AssetType]
            end
            if tabConfig.AssetType and tabConfig.AssetType == 11 then
              goto lbl_208
            end
          end
        end
        if bIsDynamicAsset then
          local ThisCustomModelAssetKey
          local CreativeAssetConfig = AssetMgr:GetAssetInfo(AssetID)
          if CreativeAssetConfig then
            local CustomModelConfig = CreativeAssetConfig.CustomModel
            if CustomModelConfig then
              local CustomAssetKey = CustomModelConfig.CustomAssetKey
              if type(CustomAssetKey) == "string" and CustomAssetKey ~= "" then
                ThisCustomModelAssetKey = CustomAssetKey
              end
            end
          end
          NewPresetDesc.ResInfo = _TablePool:Get()
          if ThisCustomModelAssetKey then
            NewPresetDesc.NeedSelectCheck = true
            NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
            local _ResIDArr = _TablePool:Get()
            NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.CustomModel] = _ResIDArr
            table.insert(_ResIDArr, ThisCustomModelAssetKey)
          else
            NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
            table.insert(NewPresetDesc.ResInfo.AssetIDs, NewPresetDesc.PresetValue)
          end
        else
          local AssetConfig = CDataTable.GetTableData("UGCAssetConfig", AssetID)
          if AssetConfig then
            NewPresetDesc.ResInfo = _TablePool:Get()
            NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
            table.insert(NewPresetDesc.ResInfo.AssetIDs, NewPresetDesc.PresetValue)
          end
        end
        if NewPresetDesc.OverrideCatetory == "" then
          print(bWriteLog and "CreativeDynamicPresetDescConfig._GetAssetPresetDescConfigsImpl OverrideCatetory is nil AssetID:" .. tostring(AssetID))
        end
        table.insert(OutPresetDescs, NewPresetDesc)
      end
      ::lbl_208::
    end
  end
  table.sort(OutPresetDescs, function(l, r)
    local AssetID_l = l.PresetValue
    local AssetID_r = r.PresetValue
    local aConfig = CDataTable.GetTableData("UGCAssetConfig", AssetID_l)
    local bConfig = CDataTable.GetTableData("UGCAssetConfig", AssetID_r)
    if aConfig and bConfig then
      if aConfig.TabID ~= bConfig.TabID then
        return aConfig.TabID < bConfig.TabID
      end
      if aConfig.SortWeight ~= bConfig.SortWeight then
        return aConfig.SortWeight < bConfig.SortWeight
      end
    end
    return AssetID_l < AssetID_r
  end)
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetCreativeAssetPresetDescConfigs()
  return _GetAssetPresetDescConfigsImpl(false)
end

function CreativeDynamicPresetDescConfig.GetCreativeDynamicAssetPresetDescConfigs()
  return _GetAssetPresetDescConfigsImpl(true)
end

function CreativeDynamicPresetDescConfig.GetCreativeHomeLandAssetPresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local AssetMgr = GetAssetManager and GetAssetManager() or nil
  if AssetMgr then
    local AllAssetID = AssetMgr:GetAllHomeLandAssetIds()
    if not AllAssetID then
      return OutPresetDescs
    end
    local CreativeExpiredAssetConfig = require("GameLua.Mod.BaseMod.GamePlay.Config.CreativeExpiredAssetConfig")
    for i = 1, #AllAssetID do
      local AssetID = AllAssetID[i]
      local bIsGroup = AssetMgr:IsGroupAsset(AssetID)
      local bIsHideAsset = AssetMgr:IsHideAsset(AssetID)
      local bIsUIPreset = AssetMgr:IsUIAsset(AssetID)
      local bIsCurVersionExpired = CreativeExpiredAssetConfig.IsCurVersionExpired(AssetID)
      if not bIsGroup and not bIsHideAsset and not bIsCurVersionExpired and not bIsUIPreset then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetTitle = AssetMgr:GetAssetDescInfo(AssetID, "Name")
        NewPresetDesc.PresetValue = AssetID
        if NewPresetDesc.PresetTitle == nil or NewPresetDesc.PresetTitle == "" then
          NewPresetDesc.PresetTitle = tostring(AssetID)
        end
        NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(AssetMgr:GetAssetDescInfo(AssetID, "Icon"))
        NewPresetDesc.PresetTags = CreativeDynamicPresetDescConfig.GetPresetTagsByAssetId(AssetID)
        NewPresetDesc.OverrideCatetory = Enum_AssetPresetCatetory[11]
        local AssetConfig = CDataTable.GetTableData("UGCAssetConfig", AssetID)
        if AssetConfig then
          NewPresetDesc.ResInfo = _TablePool:Get()
          NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
          table.insert(NewPresetDesc.ResInfo.AssetIDs, NewPresetDesc.PresetValue)
        end
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  table.sort(OutPresetDescs, function(l, r)
    local AssetID_l = l.PresetValue
    local AssetID_r = r.PresetValue
    local aConfig = CDataTable.GetTableData("UGCAssetConfig", AssetID_l)
    local bConfig = CDataTable.GetTableData("UGCAssetConfig", AssetID_r)
    if aConfig and bConfig then
      if aConfig.TabID ~= bConfig.TabID then
        return aConfig.TabID < bConfig.TabID
      end
      if aConfig.SortWeight ~= bConfig.SortWeight then
        return aConfig.SortWeight < bConfig.SortWeight
      end
    end
    return AssetID_l < AssetID_r
  end)
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetCreativeCustomCreativeAssetPresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local AssetMgr = GetAssetManager and GetAssetManager() or nil
  if AssetMgr then
    local CreativeExpiredAssetConfig = require("GameLua.Mod.BaseMod.GamePlay.Config.CreativeExpiredAssetConfig")
    local AllAssetID = AssetMgr:GetAllCustomPresetIds()
    for i = 1, #AllAssetID do
      local AssetID = AllAssetID[i]
      local bIsGroup = AssetMgr:IsGroupAsset(AssetID)
      local bIsHideAsset = AssetMgr:IsHideAsset(AssetID)
      local bIsCurVersionExpired = CreativeExpiredAssetConfig.IsCurVersionExpired(AssetID)
      if not bIsGroup and not bIsHideAsset and not bIsCurVersionExpired then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetTitle = AssetMgr:GetAssetDescInfo(AssetID, "Name")
        NewPresetDesc.PresetValue = AssetID
        if NewPresetDesc.PresetTitle == nil or NewPresetDesc.PresetTitle == "" then
          NewPresetDesc.PresetTitle = tostring(AssetID)
        end
        NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(AssetMgr:GetAssetDescInfo(AssetID, "Icon"))
        NewPresetDesc.PresetTags = CreativeDynamicPresetDescConfig.GetPresetTagsByAssetId(AssetID)
        local AssetInfo = AssetMgr:GetAssetInfo(AssetID)
        local SourceAssetID = AssetID
        if AssetInfo and AssetInfo.CustomPreset then
          SourceAssetID = AssetInfo.CustomPreset.SourceAssetID
        end
        local TabID = AssetMgr:GetAssetDescInfo(SourceAssetID, "TabID")
        if TabID and TabID ~= "" then
          local tabConfig = CDataTable.GetTableData("UGCAssetTabConfig", TabID)
          if tabConfig and (tabConfig.AssetType == 1 or tabConfig.AssetType == 2 or tabConfig.AssetType == 3) then
            NewPresetDesc.OverrideCatetory = Enum_AssetPresetCatetory[1001]
          end
        end
        local AssetConfig = CDataTable.GetTableData("UGCAssetConfig", SourceAssetID)
        if AssetConfig then
          NewPresetDesc.ResInfo = _TablePool:Get()
          NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
          table.insert(NewPresetDesc.ResInfo.AssetIDs, NewPresetDesc.PresetValue)
        end
        if NewPresetDesc.OverrideCatetory == "" then
          print(bWriteLog and "CreativeDynamicPresetDescConfig.GetCreativeCustomCreativeAssetPresetDescConfigs NewPresetDesc.OverrideCatetory is nil AssetID:" .. tostring(AssetID))
        end
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  table.sort(OutPresetDescs, function(l, r)
    local AssetID_l = l.PresetValue
    local AssetID_r = r.PresetValue
    local aConfig = CDataTable.GetTableData("UGCAssetConfig", AssetID_l)
    local bConfig = CDataTable.GetTableData("UGCAssetConfig", AssetID_r)
    if aConfig and bConfig then
      if aConfig.TabID ~= bConfig.TabID then
        return aConfig.TabID < bConfig.TabID
      end
      if aConfig.SortWeight ~= bConfig.SortWeight then
        return aConfig.SortWeight < bConfig.SortWeight
      end
    end
    return AssetID_l < AssetID_r
  end)
  return OutPresetDescs
end

local Enum_SkillPresetCatetory = {
  [0] = 8500587,
  [1] = 66506,
  [2] = 66440,
  [3] = 8600285,
  [4] = 2026902001
}

function CreativeDynamicPresetDescConfig.GetSkillPresetDescConfigs(ExCludeDeprecated)
  local OutPresetDescs = _TablePool:Get()
  local ESkillIconStatus = import("ESkillIconStatus")
  local GamePlayTools = require("GameLua.Mod.BaseMod.Common.GamePlayTools")
  local SkillLuaConfigs = GamePlayTools.GetCurrentConfig("SkillConfig")
  local AssetMgr = GetAssetManager()
  local CustomSkillPresetDescs = CreativeDynamicPresetDescConfig.GetCustomSkillPresetDescConfigsFunc(Enum_DynamicType.SkillPreset)
  for _, CustomSkillPresetDesc in ipairs(CustomSkillPresetDescs) do
    local SkillID = CustomSkillPresetDesc.PresetValue
    if AssetMgr:IsResIDExpired(CreativeGlobalDefine.ResType.Skill, SkillID) then
      CreativeDynamicPresetDescConfig.SetExpiredPresetDesc(CustomSkillPresetDesc)
      if not ExCludeDeprecated then
        table.insert(OutPresetDescs, CustomSkillPresetDesc)
      else
        print(bWriteLog and "CreativeDynamicPresetDescConfig.GetSkillPresetDescConfigs ExcludeDeprecated CustomSkillID:" .. tostring(SkillID))
      end
    else
      table.insert(OutPresetDescs, CustomSkillPresetDesc)
    end
  end
  local CreativeCustomSkillSubsystem = SubsystemMgr:Get("CreativeCustomSkillSubsystem")
  local CreativeOptionsDefine = require("GameLua.Mod.CreativeBase.Gameplay.Config.Asset.Common.CreativeOptionsDefine")
  local SkillIDList = CreativeOptionsDefine.SkillOptionDefinition.GetFieldList("SkillID", true)
  local SkillOptionMap = CreativeOptionsDefine.SkillOptionDefinition.GetSkillMap()
  for _, SkillID in ipairs(SkillIDList) do
    local SkillConfig = CDataTable.GetTableData("SkillTable", SkillID)
    if SkillConfig then
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetValue = SkillID
      NewPresetDesc.PresetTitle = SkillConfig and SkillConfig.NameLocalize or ""
      if AssetMgr:IsResIDExpired(CreativeGlobalDefine.ResType.Skill, SkillID) then
        CreativeDynamicPresetDescConfig.SetExpiredPresetDesc(NewPresetDesc)
      else
        local IconPath
        local SkillLuaConfig = SkillLuaConfigs[SkillID]
        if SkillLuaConfig and SkillLuaConfig.SkillWidgetParams and SkillLuaConfig.SkillWidgetParams.SkillIcon then
          local IconParam = SkillLuaConfig.SkillWidgetParams.SkillIcon[ESkillIconStatus.IconBtnNormal]
          if type(IconParam) == "string" then
            IconPath = IconParam
          elseif type(IconParam) == "table" then
            IconPath = IconParam.IconPath
          end
        else
          IconPath = "/Game/UMG/Texture_200/Atlas/CreativeMode/Frames/Tab_Icon_Delete_png.Tab_Icon_Delete_png"
        end
        NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(IconPath)
      end
      local BlockyDirectCastSkillCfg = CDataTable.GetTableData("BlockyLuaDirectCastSkillConfig", SkillID)
      if BlockyDirectCastSkillCfg then
        NewPresetDesc.OverrideCatetory = Enum_SkillPresetCatetory[4]
      else
        local SkillOption = SkillOptionMap[SkillID]
        if SkillOption then
          local Catetory = SkillOption.Catetory or 0
          NewPresetDesc.OverrideCatetory = Enum_SkillPresetCatetory[Catetory]
        else
          NewPresetDesc.OverrideCatetory = Enum_SkillPresetCatetory[0]
        end
      end
      NewPresetDesc.ResInfo = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill] = _TablePool:Get()
      table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill], NewPresetDesc.PresetValue)
      if CreativeCustomSkillSubsystem then
        local ResMap, _ = CreativeCustomSkillSubsystem:GetOneDependsBySkillID(NewPresetDesc.PresetValue)
        if ResMap then
          for ResType, ResList in pairs(ResMap) do
            if NewPresetDesc.ResInfo.ResIDs[ResType] == nil then
              NewPresetDesc.ResInfo.ResIDs[ResType] = {}
            end
            for _, ResID in pairs(ResList) do
              table.insert(NewPresetDesc.ResInfo.ResIDs[ResType], ResID)
            end
          end
        end
      end
      if ExCludeDeprecated and AssetMgr:IsResIDExpired(CreativeGlobalDefine.ResType.Skill, SkillID) then
        print(bWriteLog and "CreativeDynamicPresetDescConfig.GetSkillPresetDescConfigs ExcludeDeprecated SkillID:" .. tostring(SkillID))
      else
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  local ReplaceSkillList = CreativeOptionsDefine.ReplaceSkillOptionDefinition.Skills
  local CreativeCSConfig_Skill = require("GameLua.Mod.CreativeBase.Gameplay.CustomSkill.Config.CreativeCSConfig_Skill")
  local UGCLuaGlobalDefine = require("GameLua.Mod.CreativeBase.Gameplay.CreativeLua.Both.UGCLuaGlobalDefine")
  local BlockyluaEnable = UGCLuaGlobalDefine.GetBlockyluaEnable()
  for SkillID, v in pairs(ReplaceSkillList) do
    if CreativeCSConfig_Skill.ReplaceSkillCodeRequiredConfig[SkillID] == nil or BlockyluaEnable then
      local SkillConfig = CDataTable.GetTableData("SkillTable", SkillID)
      if SkillConfig then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetValue = SkillID
        NewPresetDesc.PresetTitle = SkillConfig and SkillConfig.NameLocalize or ""
        if AssetMgr:IsResIDExpired(CreativeGlobalDefine.ResType.Skill, SkillID) then
          CreativeDynamicPresetDescConfig.SetExpiredPresetDesc(NewPresetDesc)
        else
          local IconPath
          local SkillLuaConfig = SkillLuaConfigs[SkillID]
          if SkillLuaConfig and SkillLuaConfig.SkillWidgetParams and SkillLuaConfig.SkillWidgetParams.SkillIcon then
            local IconParam = SkillLuaConfig.SkillWidgetParams.SkillIcon[ESkillIconStatus.IconBtnNormal]
            if type(IconParam) == "string" then
              IconPath = IconParam
            elseif type(IconParam) == "table" then
              IconPath = IconParam.IconPath
            end
          else
            IconPath = "/Game/UMG/Texture_200/Atlas/CreativeMode/Frames/Tab_Icon_Delete_png.Tab_Icon_Delete_png"
          end
          NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(IconPath)
        end
        NewPresetDesc.OverrideCatetory = Enum_SkillPresetCatetory[0]
        if CreativeCustomSkillSubsystem then
          local ResMap, _ = CreativeCustomSkillSubsystem:GetOneDependsBySkillID(NewPresetDesc.PresetValue)
          if ResMap then
            for ResType, ResList in pairs(ResMap) do
              if NewPresetDesc.ResInfo.ResIDs[ResType] == nil then
                NewPresetDesc.ResInfo.ResIDs[ResType] = {}
              end
              for _, ResID in pairs(ResList) do
                table.insert(NewPresetDesc.ResInfo.ResIDs[ResType], ResID)
              end
            end
          end
        end
        if ExCludeDeprecated and AssetMgr:IsResIDExpired(CreativeGlobalDefine.ResType.Skill, SkillID) then
          print(bWriteLog and "CreativeDynamicPresetDescConfig.GetSkillPresetDescConfigs ExcludeDeprecated ReplaceSkillID:" .. tostring(SkillID))
        else
          table.insert(OutPresetDescs, NewPresetDesc)
        end
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetEmptySkillPresetDescConfigs()
  return CreativeDynamicPresetDescConfig.GetCustomSkillPresetDescConfigsFunc(Enum_DynamicType.EmptySkillPreset)
end

function CreativeDynamicPresetDescConfig.GetThrowSkillPresetDescConfigs()
  return CreativeDynamicPresetDescConfig.GetCustomSkillPresetDescConfigsFunc(Enum_DynamicType.ThrowSkillPreset)
end

function CreativeDynamicPresetDescConfig.GetBuildSkillSkillPresetDescConfigs()
  return CreativeDynamicPresetDescConfig.GetCustomSkillPresetDescConfigsFunc(Enum_DynamicType.BuildSkillPreset)
end

function CreativeDynamicPresetDescConfig.GetBuffPresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local CreativeCustomBuffSubsystem = SubsystemMgr:Get("CreativeCustomBuffSubsystem")
  if CreativeCustomBuffSubsystem then
    local CustomBuffList = CreativeCustomBuffSubsystem:GetCustomBuffListForDevice()
    for i, CustomBuff in ipairs(CustomBuffList) do
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetValue = CreativeCustomBuffSubsystem:GetCustomBuffID(CustomBuff)
      local Name, bIsCustomName = CreativeCustomBuffSubsystem:GetCustomBuffName(CustomBuff)
      if bIsCustomName then
        NewPresetDesc.PresetTitle = Name
      else
        NewPresetDesc.PresetTitle = LocUtil.GetLocalizeResStr(Name)
      end
      local IconPath = CreativeCustomBuffSubsystem:GetCustomBuffIcon(CustomBuff)
      NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(IconPath)
      local Catetory = CreativeCustomBuffSubsystem:GetCustomBuffCatetory(CustomBuff)
      if Catetory and Catetory ~= 0 then
        NewPresetDesc.OverrideCatetory = Catetory
      else
        NewPresetDesc.OverrideCatetory = 17004002
      end
      NewPresetDesc.ResInfo = _TablePool:Get()
      NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
      table.insert(NewPresetDesc.ResInfo.AssetIDs, 3101042)
      NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Buff] = _TablePool:Get()
      table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Buff], CreativeCustomBuffSubsystem:GetTemplateBuffIDByConfigID(NewPresetDesc.PresetValue))
      table.insert(OutPresetDescs, NewPresetDesc)
    end
    local TemplateBuffList = CreativeCustomBuffSubsystem:GetTemplateBuffListForDevice(true)
    for i, Buff in ipairs(TemplateBuffList) do
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetValue = CreativeCustomBuffSubsystem:GetTemplateBuffID(Buff)
      local Name, bIsCustomName = CreativeCustomBuffSubsystem:GetTemplateBuffName(Buff)
      if bIsCustomName then
        NewPresetDesc.PresetTitle = Name
      else
        NewPresetDesc.PresetTitle = LocUtil.GetLocalizeResStr(Name)
      end
      local IconPath = CreativeCustomBuffSubsystem:GetTemplateBuffIcon(Buff)
      NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(IconPath)
      local Catetory = CreativeCustomBuffSubsystem:GetTemplateBuffCatetory(Buff)
      if Catetory and Catetory ~= 0 then
        NewPresetDesc.OverrideCatetory = Catetory
      else
        NewPresetDesc.OverrideCatetory = 17004002
      end
      NewPresetDesc.ResInfo = _TablePool:Get()
      NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
      table.insert(NewPresetDesc.ResInfo.AssetIDs, 3101042)
      NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Buff] = _TablePool:Get()
      table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Buff], CreativeCustomBuffSubsystem:GetTemplateBuffIDByConfigID(NewPresetDesc.PresetValue))
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetParameterTypeAndAttributionTypeByDynamicType(DynamicType)
  if DynamicType == Enum_DynamicType.PlayerCustomVar_Number then
    return Enum_ParameterType.Number, CreativeCustomParameterConfig.Enum_CustomParameterAttributionType.Player
  elseif DynamicType == Enum_DynamicType.PlayerCustomVar_Int then
    return Enum_ParameterType.Integer, CreativeCustomParameterConfig.Enum_CustomParameterAttributionType.Player
  elseif DynamicType == Enum_DynamicType.PlayerCustomVar_Bool then
    return Enum_ParameterType.Boolean, CreativeCustomParameterConfig.Enum_CustomParameterAttributionType.Player
  elseif DynamicType == Enum_DynamicType.GlobalCustomVar_Number then
    return Enum_ParameterType.Number, CreativeCustomParameterConfig.Enum_CustomParameterAttributionType.Global
  elseif DynamicType == Enum_DynamicType.GlobalCustomVar_Int then
    return Enum_ParameterType.Integer, CreativeCustomParameterConfig.Enum_CustomParameterAttributionType.Global
  elseif DynamicType == Enum_DynamicType.GlobalCustomVar_Bool then
    return Enum_ParameterType.Boolean, CreativeCustomParameterConfig.Enum_CustomParameterAttributionType.Global
  elseif DynamicType == Enum_DynamicType.PlayerCustomVar_String then
    return Enum_ParameterType.String, CreativeCustomParameterConfig.Enum_CustomParameterAttributionType.Player
  elseif DynamicType == Enum_DynamicType.GlobalCustomVar_String then
    return Enum_ParameterType.String, CreativeCustomParameterConfig.Enum_CustomParameterAttributionType.Global
  elseif DynamicType == Enum_DynamicType.PlayerCustomVar_Struct then
    return Enum_ParameterType.Struct, CreativeCustomParameterConfig.Enum_CustomParameterAttributionType.Player
  elseif DynamicType == Enum_DynamicType.GlobalCustomVar_Struct then
    return Enum_ParameterType.Struct, CreativeCustomParameterConfig.Enum_CustomParameterAttributionType.Global
  end
end

function CreativeDynamicPresetDescConfig.GetBlackStructPresetValue(StructName, FieldName)
  if StructName == nil or StructName == "" or FieldName == nil or FieldName == "" then
    return ""
  end
  return tostring(StructName) .. "." .. tostring(FieldName)
end

function CreativeDynamicPresetDescConfig.GetBlackStructPresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local CustomParameterManager = GetCustomParameterManager and GetCustomParameterManager() or nil
  if not CustomParameterManager then
    return OutPresetDescs
  end
  local MemberTypeNameMap = {
    [Enum_ParameterType.Integer] = "Int",
    [Enum_ParameterType.Number] = "Float",
    [Enum_ParameterType.Boolean] = "Bool",
    [Enum_ParameterType.String] = "String"
  }
  local AttributionTypes = {
    CreativeCustomParameterConfig.Enum_CustomParameterAttributionType.Global,
    CreativeCustomParameterConfig.Enum_CustomParameterAttributionType.Player
  }
  local AddedPresetValueMap = {}
  for _, AttributionType in ipairs(AttributionTypes) do
    local CustomParamDefineList = CustomParameterManager:GetCustomParameterDefineNodeList(AttributionType, Enum_ParameterType.Struct)
    for i = 1, #CustomParamDefineList do
      local OneParameterDefine = CustomParamDefineList[i]
      local StructName = OneParameterDefine.ParameterName
      local StructSchema = OneParameterDefine.PrarmeterStruct
      if StructName ~= nil and StructName ~= "" and type(StructSchema) == "table" then
        for _, Member in ipairs(StructSchema) do
          local FieldName = Member.ParameterName or Member.ParameterKey
          local TypeName = MemberTypeNameMap[Member.ParameterType]
          if FieldName ~= nil and FieldName ~= "" and TypeName ~= nil then
            local PresetValue = CreativeDynamicPresetDescConfig.GetBlackStructPresetValue(StructName, FieldName)
            if AddedPresetValueMap[PresetValue] ~= true then
              AddedPresetValueMap[PresetValue] = true
              local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
              NewPresetDesc.PresetTitle = PresetValue
              NewPresetDesc.PresetValue = PresetValue
              NewPresetDesc.TypeSyncValueTypeName = TypeName
              NewPresetDesc.bTypeSyncValueIsArray = false
              NewPresetDesc.ResInfo = _TablePool:Get()
              table.insert(OutPresetDescs, NewPresetDesc)
            end
          end
        end
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetCreativeCustomVarDescConfigs(DynamicType)
  local ParameterType, AttributionType = CreativeDynamicPresetDescConfig.GetParameterTypeAndAttributionTypeByDynamicType(DynamicType)
  local OutPresetDescs = _TablePool:Get()
  local CustomParameterManager = GetCustomParameterManager and GetCustomParameterManager() or nil
  if CustomParameterManager then
    local CustomParamDefineList = CustomParameterManager:GetCustomParameterDefineNodeList(AttributionType, ParameterType)
    for i = 1, #CustomParamDefineList do
      local OneParameterDefine = CustomParamDefineList[i]
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetTitle = OneParameterDefine.ParameterName
      NewPresetDesc.PresetValue = OneParameterDefine.ParameterID
      NewPresetDesc.ResInfo = _TablePool:Get()
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetPickupPresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local CreativeModePickupConfig = CDataTable.GetTable("CreativeModePickupConfig")
  if CreativeModePickupConfig then
    for i, v in pairs(CreativeModePickupConfig) do
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetValue = v.ID
      NewPresetDesc.PresetTitle = LocUtil.GetLocalizeResStr(v.NameID)
      local IconPath = v.Icon
      NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(IconPath)
      NewPresetDesc.ResInfo = _TablePool:Get()
      NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
      table.insert(NewPresetDesc.ResInfo.AssetIDs, 3101040)
      NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Pickup] = _TablePool:Get()
      table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Pickup], NewPresetDesc.PresetValue)
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  local AssetMgr = GetAssetManager and GetAssetManager() or nil
  if AssetMgr then
    local CreativeSceneInstanceSelectCfg = require("GameLua.Mod.CreativeBase.Client.CreativeModeEditMainCtrl.InstanceSelect.CreativeSceneInstanceSelectCfg")
    local AllAssetID = AssetMgr:GetAllCustomPresetIds()
    for i = 1, #AllAssetID do
      local AssetID = AllAssetID[i]
      local AssetInfo = AssetMgr:GetAssetInfo(AssetID)
      local SourceAssetID = AssetID
      if AssetInfo and AssetInfo.CustomPreset then
        SourceAssetID = AssetInfo.CustomPreset.SourceAssetID
      end
      if CreativeSceneInstanceSelectCfg.isPickDrop(SourceAssetID) then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetTitle = AssetMgr:GetAssetDescInfo(AssetID, "Name")
        NewPresetDesc.PresetValue = AssetID
        if NewPresetDesc.PresetTitle == nil or NewPresetDesc.PresetTitle == "" then
          NewPresetDesc.PresetTitle = tostring(AssetID)
        end
        NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(AssetMgr:GetAssetDescInfo(AssetID, "Icon"))
        NewPresetDesc.ResInfo = _TablePool:Get()
        NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
        table.insert(NewPresetDesc.ResInfo.AssetIDs, 3101040)
        NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Pickup] = _TablePool:Get()
        table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Pickup], NewPresetDesc.PresetValue)
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetBankProductPresetDescConfigs()
  local Cfg = {
    [1] = {
      PresetValue = 3101084,
      PresetTitle = LocUtil.GetLocalizeResStr(8810076),
      PresetIcon = "/Game/Library/CreativeDL/IG3600/Arts/Icon_LD/Logic/Icon_ScreamingChicken01_128.Icon_ScreamingChicken01_128",
      PresetJsonKeyName = "copperChicken"
    },
    [2] = {
      PresetValue = 3101085,
      PresetTitle = LocUtil.GetLocalizeResStr(8810077),
      PresetIcon = "/Game/Library/CreativeDL/IG3600/Arts/Icon_LD/Logic/Icon_ScreamingChicken03_128.Icon_ScreamingChicken03_128",
      PresetJsonKeyName = "silverChicken"
    },
    [3] = {
      PresetValue = 3101086,
      PresetTitle = LocUtil.GetLocalizeResStr(8810078),
      PresetIcon = "/Game/Library/CreativeDL/IG3600/Arts/Icon_LD/Logic/Icon_ScreamingChicken02_128.Icon_ScreamingChicken02_128",
      PresetJsonKeyName = "goldenChicken"
    },
    [4] = {
      PresetValue = 3101094,
      PresetTitle = LocUtil.GetLocalizeResStr(8810079),
      PresetIcon = "/Game/Library/CreativeDL/IG3600/Arts/Icon_LD/Logic/Icon_RedFlag_128.Icon_RedFlag_128",
      PresetJsonKeyName = "RedChicken"
    },
    [5] = {
      PresetValue = 3101095,
      PresetTitle = LocUtil.GetLocalizeResStr(8810080),
      PresetIcon = "/Game/Library/CreativeDL/IG3600/Arts/Icon_LD/Logic/Icon_GreenFlag_128.Icon_GreenFlag_128",
      PresetJsonKeyName = "GreenChicken"
    },
    [6] = {
      PresetValue = 3101096,
      PresetTitle = LocUtil.GetLocalizeResStr(8810081),
      PresetIcon = "/Game/Library/CreativeDL/IG3600/Arts/Icon_LD/Logic/Icon_BlueFlag_128.Icon_BlueFlag_128",
      PresetJsonKeyName = "BlueChicken"
    },
    [7] = {
      PresetValue = 3101098,
      PresetTitle = LocUtil.GetLocalizeResStr(8810082),
      PresetIcon = "/Game/Library/CreativeDL/IG3600/Arts/Icon_LD/Logic/Icon_Rugby_128.Icon_Rugby_128",
      PresetJsonKeyName = "rugbyBall"
    }
  }
  local OutPresetDescs = _TablePool:Get()
  for i, v in pairs(Cfg) do
    local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
    NewPresetDesc.PresetValue = v.PresetValue
    NewPresetDesc.PresetTitle = v.PresetTitle
    NewPresetDesc.PresetIcon = v.PresetIcon
    if v.PresetJsonKeyName ~= nil and v.PresetJsonKeyName ~= "" then
      NewPresetDesc.OverrideKeyName = v.PresetJsonKeyName
    end
    NewPresetDesc.ResInfo = _TablePool:Get()
    NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
    table.insert(NewPresetDesc.ResInfo.AssetIDs, v.PresetValue)
    NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
    NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.BankProduct] = _TablePool:Get()
    table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.BankProduct], i)
    table.insert(OutPresetDescs, NewPresetDesc)
  end
  local AssetMgr = GetAssetManager and GetAssetManager() or nil
  if AssetMgr then
    local AllAssetID = AssetMgr:GetAllCustomPresetIds()
    local CreativeSceneInstanceSelectCfg = require("GameLua.Mod.CreativeBase.Client.CreativeModeEditMainCtrl.InstanceSelect.CreativeSceneInstanceSelectCfg")
    for i = 1, #AllAssetID do
      local AssetID = AllAssetID[i]
      local AssetInfo = AssetMgr:GetAssetInfo(AssetID)
      local SourceAssetID = AssetID
      if AssetInfo and AssetInfo.CustomPreset then
        SourceAssetID = AssetInfo.CustomPreset.SourceAssetID
      end
      if CreativeSceneInstanceSelectCfg.isFightObj(SourceAssetID) then
        local CfgIndex = 0
        for i, v in pairs(Cfg) do
          if v.PresetValue == SourceAssetID then
            CfgIndex = i
            break
          end
        end
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetTitle = AssetMgr:GetAssetDescInfo(AssetID, "Name")
        NewPresetDesc.PresetValue = AssetID
        if NewPresetDesc.PresetTitle == nil or NewPresetDesc.PresetTitle == "" then
          NewPresetDesc.PresetTitle = tostring(AssetID)
        end
        NewPresetDesc.PresetIcon = Cfg[CfgIndex].PresetIcon
        NewPresetDesc.ResInfo = _TablePool:Get()
        NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
        table.insert(NewPresetDesc.ResInfo.AssetIDs, NewPresetDesc.PresetValue)
        NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.BankProduct] = _TablePool:Get()
        table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.BankProduct], CfgIndex)
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  return OutPresetDescs
end

local Enum_ItemPresetCatetory = {
  [1] = 8340314,
  [2] = 8340313,
  [3] = 8340315,
  [4] = 8202307,
  [5] = 8340305,
  [6] = 8340306,
  [7] = 8340206,
  [8] = 8700009
}

function CreativeDynamicPresetDescConfig.GetItemPresetDescConfigs(ExCludeDeprecated)
  local OutPresetDescs = _TablePool:Get()
  local CreativeModeItemConfig = CDataTable.GetTable("CreativeModeDeviceCreateTable")
  local CustomItemsSubsystem = SubsystemMgr:Get("CreativeCustomItemsSubsystem")
  if CreativeModeItemConfig and CustomItemsSubsystem then
    local AssetMgr = GetAssetManager()
    for i, v in pairs(CreativeModeItemConfig) do
      local ItemConfig = CDataTable.GetTableData("Item", v.ItemID)
      if ItemConfig then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetValue = ItemConfig.ItemID
        NewPresetDesc.PresetTitle = ItemConfig.ItemName
        if AssetMgr:IsResIDExpired(CreativeGlobalDefine.ResType.Item, ItemConfig.ItemID) then
          CreativeDynamicPresetDescConfig.SetExpiredPresetDesc(NewPresetDesc)
        else
          local IconPath = ItemConfig.ItemSmallIcon
          NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(IconPath)
        end
        if Enum_ItemPresetCatetory[v.ItemType] ~= nil then
          NewPresetDesc.OverrideCatetory = Enum_ItemPresetCatetory[v.ItemType]
        end
        if NewPresetDesc.OverrideCatetory == "" then
          print(bWriteLog and "CreativeDynamicPresetDescConfig.GetItemPresetDescConfigs NewPresetDesc.OverrideCatetory is nil ItemID:" .. tostring(v.ItemID))
        end
        local LimitedRemainingDays = AssetMgr:GetResIDLimitedRemainingDays(CreativeGlobalDefine.ResType.Item, ItemConfig.ItemID)
        NewPresetDesc.isValidityPreset = LimitedRemainingDays ~= nil
        NewPresetDesc.ResInfo = _TablePool:Get()
        NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
        table.insert(NewPresetDesc.ResInfo.AssetIDs, 3101021)
        NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Item] = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill] = _TablePool:Get()
        local DependItemID, DependSkillID = CustomItemsSubsystem:GetActualItemIDAndSkillIDByItemID(ItemConfig.ItemID)
        if 0 < DependItemID then
          table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Item], DependItemID)
        end
        if 0 < DependSkillID then
          table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill], DependSkillID)
        end
        if ExCludeDeprecated and AssetMgr:IsResIDExpired(CreativeGlobalDefine.ResType.Item, ItemConfig.ItemID) then
          print(bWriteLog and "CreativeDynamicPresetDescConfig.GetItemPresetDescConfigs ExcludeDeprecated ItemID:" .. tostring(v.ItemID))
        else
          table.insert(OutPresetDescs, NewPresetDesc)
        end
      end
    end
  end
  return OutPresetDescs
end

local Enum_CustomItemPresetCatetory = {}

function CreativeDynamicPresetDescConfig.GetDynamicItemOverrideCatetory(ItemType, ItemSubType)
  if Enum_CustomItemPresetCatetory[ItemType] ~= nil then
    if Enum_CustomItemPresetCatetory[ItemType][ItemSubType] ~= nil then
      return Enum_CustomItemPresetCatetory[ItemType][ItemSubType]
    end
    if Enum_CustomItemPresetCatetory[ItemType][0] ~= nil then
      return Enum_CustomItemPresetCatetory[ItemType][0]
    end
  end
  return 8700009
end

function CreativeDynamicPresetDescConfig.GetDynamicItemPresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local CustomWeaponSubsystem = SubsystemMgr:Get("CreativeCustomWeaponSubsystem")
  local CustomItemsSubsystem = SubsystemMgr:Get("CreativeCustomItemsSubsystem")
  if CustomWeaponSubsystem ~= nil then
    local TWeaponList, CWeaponList = CustomWeaponSubsystem:GetWeaponList()
    if TWeaponList then
      for i, v in pairs(TWeaponList) do
        local ItemConfig = CDataTable.GetTableData("Item", v.Data.ItemId)
        if ItemConfig then
          local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
          NewPresetDesc.PresetValue = v.Data.ItemId
          NewPresetDesc.PresetTitle = v.Data.Name
          local IconPath = ItemConfig.ItemSmallIcon
          NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(IconPath)
          NewPresetDesc.OverrideCatetory = CreativeDynamicPresetDescConfig.GetDynamicItemOverrideCatetory(v.Config.ItemType, v.Config.ItemSubType)
          NewPresetDesc.ResInfo = _TablePool:Get()
          NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
          NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Item] = _TablePool:Get()
          NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill] = _TablePool:Get()
          local DependItemID, DependSkillID = CustomItemsSubsystem:GetActualItemIDAndSkillIDByItemID(v.Data.ItemId)
          if 0 < DependItemID then
            table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Item], DependItemID)
          end
          if 0 < DependSkillID then
            table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill], DependSkillID)
          end
          table.insert(OutPresetDescs, NewPresetDesc)
        end
      end
    end
    if CWeaponList then
      for i, v in pairs(CWeaponList) do
        local ItemConfig = CDataTable.GetTableData("Item", v.Data.ItemId)
        if ItemConfig then
          local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
          NewPresetDesc.PresetValue = v.Data.OverrideItemId
          NewPresetDesc.PresetTitle = v.Data.Name
          local IconPath = v.Data.Icon and CustomWeaponSubsystem:GetIcon(v.Data.Icon, true) or ItemConfig.ItemSmallIcon
          NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(IconPath)
          NewPresetDesc.OverrideCatetory = CreativeDynamicPresetDescConfig.GetDynamicItemOverrideCatetory(v.Config.ItemType, v.Config.ItemSubType)
          NewPresetDesc.ResInfo = _TablePool:Get()
          NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
          NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Item] = _TablePool:Get()
          NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill] = _TablePool:Get()
          local DependItemID, DependSkillID = CustomItemsSubsystem:GetActualItemIDAndSkillIDByItemID(v.Data.ItemId)
          if 0 < DependItemID then
            table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Item], DependItemID)
          end
          if 0 < DependSkillID then
            table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill], DependSkillID)
          end
          table.insert(OutPresetDescs, NewPresetDesc)
        end
      end
    end
  end
  local TItemsList, CItemsList = CustomItemsSubsystem:GetItemList()
  if TItemsList then
    for i, v in pairs(TItemsList) do
      local ItemConfig = CDataTable.GetTableData("Item", v.Data.ItemId)
      if ItemConfig then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetValue = v.Data.ItemId
        NewPresetDesc.PresetTitle = v.Data.Name
        local IconPath = ItemConfig.ItemSmallIcon
        NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(IconPath)
        NewPresetDesc.OverrideCatetory = CreativeDynamicPresetDescConfig.GetDynamicItemOverrideCatetory(v.Config.ItemType, v.Config.ItemSubType)
        NewPresetDesc.ResInfo = _TablePool:Get()
        NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
        table.insert(NewPresetDesc.ResInfo.AssetIDs, 3101021)
        NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Item] = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill] = _TablePool:Get()
        local DependItemID, DependSkillID = CustomItemsSubsystem:GetActualItemIDAndSkillIDByItemID(v.Data.ItemId)
        if 0 < DependItemID then
          table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Item], DependItemID)
        end
        if 0 < DependSkillID then
          table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill], DependSkillID)
        end
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  if CItemsList then
    for i, v in pairs(CItemsList) do
      local ItemConfig = CDataTable.GetTableData("Item", v.Data.ItemId)
      if ItemConfig then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetValue = v.Data.OverrideItemId
        NewPresetDesc.PresetTitle = v.Data.Name
        local IconPath = v.Data.Icon and CustomItemsSubsystem:GetIcon(v.Data.Icon) or ItemConfig.ItemSmallIcon
        NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(IconPath)
        NewPresetDesc.OverrideCatetory = CreativeDynamicPresetDescConfig.GetDynamicItemOverrideCatetory(v.Config.ItemType, v.Config.ItemSubType)
        NewPresetDesc.ResInfo = _TablePool:Get()
        NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
        table.insert(NewPresetDesc.ResInfo.AssetIDs, 3101021)
        NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Item] = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill] = _TablePool:Get()
        local DependItemID, DependSkillID = CustomItemsSubsystem:GetActualItemIDAndSkillIDByItemID(v.Data.ItemId)
        if 0 < DependItemID then
          table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Item], DependItemID)
        end
        if 0 < DependSkillID then
          table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill], DependSkillID)
        end
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetEffectPresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local ParticleSubsys = SubsystemMgr:Get("CreativeModeParticleSystemSubSystem")
  if ParticleSubsys == nil then
    return OutPresetDescs
  end
  local CategoryType = {
    [0] = 8500587,
    [1] = 28150768
  }
  local CreativeModeParticleConfig = require("GameLua.Mod.CreativeBase.Gameplay.Config.CreativeModeParticleConfig")
  for ParticleID, v in pairs(CreativeModeParticleConfig.Particles) do
    local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
    NewPresetDesc.PresetValue = ParticleID
    NewPresetDesc.SortOrder = ParticleID
    NewPresetDesc.PresetTitle = LocUtil.GetLocalizeResStr(v.ParticleName) or v.ParticleName
    local IconPath = v.IconPath
    NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(IconPath)
    NewPresetDesc.PresetAnimationPath = v.AnimationPath
    NewPresetDesc.PresetSoundPath = v.SoundPath
    NewPresetDesc.OverrideCatetory = CategoryType[0]
    NewPresetDesc.ResInfo = _TablePool:Get()
    NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
    table.insert(NewPresetDesc.ResInfo.AssetIDs, 3205010)
    NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
    NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Effect] = _TablePool:Get()
    table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Effect], NewPresetDesc.PresetValue)
    table.insert(OutPresetDescs, NewPresetDesc)
  end
  local CreativeManagerTools = require("GameLua.Mod.CreativeBase.Gameplay.Common.CreativeManagerTools")
  local CreativeModeParticleTemplateConfig = require("GameLua.Mod.CreativeBase.Gameplay.Config.CreativeModeParticleTemplateConfig")
  local GameParameterMgr = CreativeManagerTools:GetGameParameterManager()
  local ParticleGameParameter = GameParameterMgr:GetGameParameter("CustomParticleConfig")
  if ParticleGameParameter then
    local ParticleConfigs = ParticleGameParameter.Value or {}
    for _, Config in ipairs(ParticleConfigs) do
      local TemplateConfig = CreativeModeParticleTemplateConfig.GetTemplate(Config.DefaultConfigId)
      if TemplateConfig and (Config.ConfigId ~= Config.DefaultConfigId or TemplateConfig.bCreateOfficialResource) then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetValue = Config.ConfigId
        NewPresetDesc.SortOrder = Config.ConfigId
        local ParticleName = Config.ParticleName
        if not ParticleName or #ParticleName == 0 then
          ParticleName = LocUtil.GetLocalizeResStr(TemplateConfig.ParticleName)
        end
        NewPresetDesc.PresetTitle = ParticleName
        local IconPath = TemplateConfig and TemplateConfig.IconPath or ""
        NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(IconPath)
        NewPresetDesc.OverrideCatetory = CategoryType[1]
        NewPresetDesc.ResInfo = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Effect] = _TablePool:Get()
        table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Effect], NewPresetDesc.PresetValue)
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetSoundPresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local CreativeModeAudioSubsystem = SubsystemMgr:Get("CreativeModeAudioSubsystem")
  if CreativeModeAudioSubsystem == nil then
    return OutPresetDescs
  end
  local AudioConfigs, CustomAudioConfig = CreativeModeAudioSubsystem:GetAllAudioConfigs(nil, true, true)
  local LimitStateMap = CreativeModeAudioSubsystem:GetLimitStateMap()
  local CategoryType = {
    [0] = 8500587,
    [1] = 8888685,
    [2] = 99009831,
    [3] = 99009830
  }
  local CustomAssetDefine = require("common.CustomAsset.CustomAssetDefine")
  local CustomAssetCategoryType = CustomAssetDefine.CustomAssetCategoryType
  
  local function IterAudioConfig(Configs, bCustomAsset)
    for index, config in pairs(Configs) do
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.NeedSelectCheck = bCustomAsset
      NewPresetDesc.PresetValue = config.AudioID
      NewPresetDesc.SortOrder = config.AudioID
      NewPresetDesc.PresetTitle = LocUtil.GetLocalizeResStr(config.AudioNameKey) or config.AudioNameKey
      if NewPresetDesc.PresetTitle == "" then
        NewPresetDesc.PresetTitle = config.AudioNameKey
      end
      if bCustomAsset then
        local Category = CreativeModeAudioSubsystem:GetCustomAssetAudioCategory(config.Meta)
        if Category == CustomAssetCategoryType.MyShares then
          NewPresetDesc.OverrideCatetory = CategoryType[1]
        elseif Category == CustomAssetCategoryType.MyFavorites then
          NewPresetDesc.OverrideCatetory = CategoryType[2]
        elseif Category == CustomAssetCategoryType.Private then
          NewPresetDesc.OverrideCatetory = CategoryType[3]
        end
      else
        NewPresetDesc.OverrideCatetory = CategoryType[0]
      end
      if LimitStateMap[config.AudioID] == CreativeGlobalDefine.AssetParamExpiredState.Expired then
        CreativeDynamicPresetDescConfig.SetExpiredPresetDesc(NewPresetDesc)
      end
      NewPresetDesc.ResInfo = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Audio] = _TablePool:Get()
      table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Audio], NewPresetDesc.PresetValue)
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  
  IterAudioConfig(AudioConfigs)
  local PublishRegionMacros = Client and require("client.slua.config.ClientMacros.PublishRegionMacros")
  if not PublishRegionMacros or not PublishRegionMacros.IsBlueholeOperationRegion() then
    IterAudioConfig(CustomAudioConfig, true)
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetMonsterPresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local CreativeModeCustomMonsterSubsystem = SubsystemMgr:Get("CreativeModeCustomMonsterSubsystem")
  if CreativeModeCustomMonsterSubsystem then
    local CreativeMonsterConfig = require("GameLua.Mod.CreativeBase.Client.Config.CreativeModeMonsterConfig")
    local CreativeManagerTools = require("GameLua.Mod.CreativeBase.Gameplay.Common.CreativeManagerTools")
    local GameParameterMgr = CreativeManagerTools:GetGameParameterManager()
    local MonsterGameProps = GameParameterMgr:GetGameParameter("CustomMonsterConfig").Value
    local CreativeCustomSkillSubsystem = SubsystemMgr:Get("CreativeCustomSkillSubsystem")
    local CreativeModeItemDropSubsystem = SubsystemMgr:Get("CreativeModeItemDropSubsystem")
    local CustomItemsSubsystem = SubsystemMgr:Get("CreativeCustomItemsSubsystem")
    local Ret = {}
    local AssetMgr = GetAssetManager()
    for _, MonsterProp in pairs(MonsterGameProps) do
      local MonsterConfig = CreativeMonsterConfig.GetDefaultMonsterConfig(MonsterProp.DefaultConfigId)
      if MonsterConfig then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetValue = MonsterProp.ConfigId
        local Name = CreativeModeCustomMonsterSubsystem:GetRawMonsterName(MonsterProp.ConfigId)
        NewPresetDesc.PresetTitle = Name
        if AssetMgr:IsResIDExpired(CreativeGlobalDefine.ResType.Monster, MonsterConfig.MonsterID) then
          CreativeDynamicPresetDescConfig.SetExpiredPresetDesc(NewPresetDesc)
        else
          local IconPath = MonsterConfig.IconTexturePath
          NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(IconPath)
        end
        NewPresetDesc.ResInfo = _TablePool:Get()
        NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
        table.insert(NewPresetDesc.ResInfo.AssetIDs, 3101043)
        NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Monster] = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Item] = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill] = _TablePool:Get()
        table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Monster], CreativeModeCustomMonsterSubsystem:GetMonsterIDByConfigID(MonsterProp.DefaultConfigId))
        local MonsterTemplateCfg = CreativeModeCustomMonsterSubsystem:GetCustomMonsterConfig(MonsterProp.DefaultConfigId)
        if MonsterTemplateCfg and MonsterTemplateCfg.MonsterCustomSkill then
          for __, CustomSkillCfg in pairs(MonsterTemplateCfg.MonsterCustomSkill) do
            if CustomSkillCfg and CreativeCustomSkillSubsystem then
              local SkillResMap, _ = CreativeCustomSkillSubsystem:GetOneDependsBySkillID(CustomSkillCfg.CustomSkillID)
              if SkillResMap then
                for ResType, ResList in pairs(SkillResMap) do
                  if NewPresetDesc.ResInfo.ResIDs[ResType] == nil then
                    NewPresetDesc.ResInfo.ResIDs[ResType] = {}
                  end
                  for _, ResID in pairs(ResList) do
                    table.insert(NewPresetDesc.ResInfo.ResIDs[ResType], ResID)
                  end
                end
              end
            end
          end
        elseif MonsterTemplateCfg and MonsterTemplateCfg.DropItemConfigs then
          for _, CfgIndex in pairs(MonsterTemplateCfg.DropItemConfigs) do
            local items = CreativeModeItemDropSubsystem:GetAllDropItemList(CfgIndex)
            for i, item in pairs(items) do
              local DependItemID, DependSkillID = CustomItemsSubsystem:GetActualItemIDAndSkillIDByItemID(item.ItemId)
              if 0 < DependItemID then
                table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Item], DependItemID)
              end
              if 0 < DependSkillID then
                table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill], DependSkillID)
              end
            end
          end
        end
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetArmedAIPresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local AssetMgr = GetAssetManager()
  local CreativeModeCustomFakePlayerSubsystem = SubsystemMgr:Get("CreativeModeCustomFakePlayerSubsystem")
  if CreativeModeCustomFakePlayerSubsystem then
    local CreativeFakePlayerConfig = require("GameLua.Mod.CreativeBase.Client.Config.CreativeFakePlayerConfig")
    local AllFakePlayerConfig = CreativeModeCustomFakePlayerSubsystem:GetAllFakePlayerConfig(true)
    for _, FakePlayerConfig in pairs(AllFakePlayerConfig) do
      local FakePlayerProp = FakePlayerConfig.Property
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetValue = FakePlayerProp.ConfigId
      local Name = CreativeModeCustomFakePlayerSubsystem:GetRawFakePlayerName(FakePlayerProp.ConfigId)
      NewPresetDesc.PresetTitle = Name
      local FakePlayerID = CreativeFakePlayerConfig.GetFakePlayerIDByIndex(FakePlayerProp.DefaultConfigId)
      if AssetMgr:IsResIDExpired(CreativeGlobalDefine.ResType.ArmedAI, FakePlayerID) then
        CreativeDynamicPresetDescConfig.SetExpiredPresetDesc(NewPresetDesc)
      else
        local IconPath = FakePlayerConfig.IconTexturePath
        NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(IconPath)
      end
      NewPresetDesc.ResInfo = _TablePool:Get()
      NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
      local AICategory
      local fakePlayerCfg = CreativeModeCustomFakePlayerSubsystem:GetCustomFakePlayerConfigWithDefault(FakePlayerProp.DefaultConfigId)
      if fakePlayerCfg then
        AICategory = fakePlayerCfg.AICategory
      end
      if CreativeFakePlayerConfig.IsTower(AICategory) then
        table.insert(NewPresetDesc.ResInfo.AssetIDs, 3101101)
      else
        table.insert(NewPresetDesc.ResInfo.AssetIDs, 3101060)
      end
      NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.ArmedAI] = _TablePool:Get()
      table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.ArmedAI], FakePlayerID)
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetWeatherDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local WeatherIdConfig = require("GameLua.Mod.CreativeBase.Gameplay.Config.Asset.Logic.EnvironmentManager.WeatherIdConfig")
  local WeatherIds = WeatherIdConfig.GetWeatherIds()
  local WeatherNames = WeatherIdConfig.GetWeatherNames()
  for i = 1, #WeatherIds do
    local Id = WeatherIds[i]
    local Name = WeatherNames[i]
    local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
    NewPresetDesc.PresetValue = Id
    NewPresetDesc.PresetTitle = Name
    if Client ~= nil or IsEditor then
      NewPresetDesc.PresetTitle = LocUtil.GetLocalizeResStr(Name)
    else
      NewPresetDesc.PresetTitle = Name
    end
    table.insert(OutPresetDescs, NewPresetDesc)
  end
  OutPresetDescs.ResInfo = _TablePool:Get()
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetSignalEventPresetDescConfigs(bIsDs, EditParamem, GetParamem, bIsScriptGenerator)
  local OutPresetDescs = _TablePool:Get()
  local CreativeObjectSignalConfig = require("GameLua.Mod.CreativeBase.Gameplay.Config.CreativeObjectSignalConfig")
  local CreativeModeUIUtils = require("GameLua.Mod.CreativeBase.Client.CreativeModeUIUtils")
  local AssetMgr = GetAssetManager and GetAssetManager() or nil
  if AssetMgr then
    local AllAssetID = AssetMgr:GetAssetAllIds()
    for i = 1, #AllAssetID do
      local AssetID = AllAssetID[i]
      if not CreativeDynamicPresetDescConfig.AbandonedAsset[AssetID] then
        local AssetName
        if bIsScriptGenerator == true then
          AssetName = AssetMgr:GetAssetDescInfo(AssetID, "Name")
        end
        local SignalConfig = CreativeObjectSignalConfig.GetOneObjectSignalConfig(AssetID)
        if SignalConfig and SignalConfig.Event then
          for eventKey, eventValue in pairs(SignalConfig.Event) do
            if eventValue.IsBranchEvent and bIsScriptGenerator ~= true then
              if eventValue.GetAllBranchEvents then
                local AllBranchEvents = eventValue.GetAllBranchEvents()
                for _, m in ipairs(AllBranchEvents) do
                  local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
                  if bIsDs then
                    NewPresetDesc.PresetTitle = ""
                  else
                    NewPresetDesc.PresetTitle = CreativeModeUIUtils.GetEventTitle(eventValue, m, false)
                  end
                  NewPresetDesc.PresetValue = CreativeDynamicPresetDescConfig.GetSignalPresetValue(AssetID, eventKey, m)
                  NewPresetDesc.ResInfo = _TablePool:Get()
                  NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
                  table.insert(NewPresetDesc.ResInfo.AssetIDs, AssetID)
                  table.insert(OutPresetDescs, NewPresetDesc)
                end
              end
            else
              local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
              if bIsDs then
                NewPresetDesc.PresetTitle = ""
              elseif bIsScriptGenerator == true then
                NewPresetDesc.PresetTitle = LocUtil.GetLocalizeResStr(eventValue.EventTitle) .. "(" .. tostring(AssetName) .. ")"
              else
                NewPresetDesc.PresetTitle = LocUtil.GetLocalizeResStr(eventValue.EventTitle)
              end
              if bIsScriptGenerator == true then
                NewPresetDesc.PresetValue = eventKey
              else
                NewPresetDesc.PresetValue = CreativeDynamicPresetDescConfig.GetSignalPresetValue(AssetID, eventKey)
              end
              NewPresetDesc.ResInfo = _TablePool:Get()
              NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
              table.insert(NewPresetDesc.ResInfo.AssetIDs, AssetID)
              table.insert(OutPresetDescs, NewPresetDesc)
            end
          end
        end
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetSignalFunctionPresetDescConfigs(bIsDs, EditParamem, GetParamem, bIsScriptGenerator)
  local OutPresetDescs = _TablePool:Get()
  local CreativeObjectSignalConfig = require("GameLua.Mod.CreativeBase.Gameplay.Config.CreativeObjectSignalConfig")
  local CreativeModeUIUtils = require("GameLua.Mod.CreativeBase.Client.CreativeModeUIUtils")
  local AssetMgr = GetAssetManager and GetAssetManager() or nil
  if AssetMgr then
    local AllAssetID = AssetMgr:GetAssetAllIds()
    for i = 1, #AllAssetID do
      local AssetID = AllAssetID[i]
      if not CreativeDynamicPresetDescConfig.AbandonedAsset[AssetID] then
        local AssetName
        if bIsScriptGenerator == true then
          AssetName = AssetMgr:GetAssetDescInfo(AssetID, "Name")
        end
        local SignalConfig = CreativeObjectSignalConfig.GetOneObjectSignalConfig(AssetID)
        if SignalConfig and SignalConfig.Function then
          for _, v in pairs(SignalConfig.Function) do
            local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
            if bIsDs then
              NewPresetDesc.PresetTitle = ""
            elseif bIsScriptGenerator == true then
              NewPresetDesc.PresetTitle = CreativeModeUIUtils.GetFunctionTitle(v) .. "(" .. tostring(AssetName) .. ")"
            else
              NewPresetDesc.PresetTitle = CreativeModeUIUtils.GetFunctionTitle(v)
            end
            if bIsScriptGenerator == true then
              NewPresetDesc.PresetValue = v.FunctionName
            else
              NewPresetDesc.PresetValue = CreativeDynamicPresetDescConfig.GetSignalPresetValue(AssetID, v.FunctionName)
            end
            NewPresetDesc.ResInfo = _TablePool:Get()
            NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
            table.insert(NewPresetDesc.ResInfo.AssetIDs, AssetID)
            table.insert(OutPresetDescs, NewPresetDesc)
          end
        end
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetVehiclePresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local CreativeUGCLuaVehicleDefine = require("GameLua.Mod.CreativeBase.Gameplay.CreativeLua.Both.UGCLuaVehicleDefine")
  if CreativeUGCLuaVehicleDefine then
    for _, VehicleType in pairs(CreativeUGCLuaVehicleDefine.Enum_UGCLuaVehicleType) do
      local VehicleDefine = CreativeUGCLuaVehicleDefine.UGCLuaVehicleInfos[VehicleType]
      if VehicleDefine then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetValue = VehicleType
        local VehicleNameId = tonumber(VehicleDefine.VehicleName)
        if VehicleNameId then
          NewPresetDesc.PresetTitle = LocUtil.GetLocalizeResStr(VehicleNameId)
        else
          NewPresetDesc.PresetTitle = VehicleDefine.VehicleName
        end
        if VehicleDefine.PresetJsonKeyName ~= nil and VehicleDefine.PresetJsonKeyName ~= "" then
          NewPresetDesc.OverrideKeyName = VehicleDefine.PresetJsonKeyName
        end
        NewPresetDesc.ResInfo = _TablePool:Get()
        NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
        table.insert(NewPresetDesc.ResInfo.AssetIDs, VehicleDefine.DependeAssetID)
        NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Vehicle] = _TablePool:Get()
        table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Vehicle], NewPresetDesc.PresetValue)
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetSignalPresetValue(AssetID, Value, BranchKey)
  if AssetID == nil or Value == nil then
    return ""
  end
  if BranchKey then
    return "--[[" .. AssetID .. "]]\"" .. Value .. "\"" .. "," .. BranchKey
  end
  return "--[[" .. AssetID .. "]]\"" .. Value .. "\""
end

function CreativeDynamicPresetDescConfig.GetCustomUIDataTraverseSource()
  if _G.EnableUMGInfoManager then
    local UMGInfoManager = GetCreativeUMGInfoManager and GetCreativeUMGInfoManager() or nil
    local AllUMGInfoTree = UMGInfoManager and UMGInfoManager:GetAllUMGInfoTree() or nil
    if AllUMGInfoTree and next(AllUMGInfoTree) then
      return AllUMGInfoTree, true
    end
  end
  local InstanceMgr = GetInstanceManager and GetInstanceManager() or nil
  if InstanceMgr then
    return InstanceMgr:GetInstanceTree(), false
  end
  return nil, false
end

function CreativeDynamicPresetDescConfig.GetCustomUIInstancePresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local InstanceMgr = GetInstanceManager and GetInstanceManager() or nil
  local AssetMgr = GetAssetManager and GetAssetManager() or nil
  if InstanceMgr and AssetMgr then
    local CustomUIDefine = require("GameLua.Mod.CreativeBase.Client.CreativeCustomUI.CustomUIDefine")
    local CreativeModeCustomObjectNameUtil = require("GameLua.Mod.CreativeBase.Gameplay.Common.CreativeModeCustomObjectName.CreativeModeCustomObjectNameUtil")
    local Utility = require("GameLua.Mod.CreativeBase.Gameplay.Meta.CreativeModeUtility")
    local EEntityType = import("EEntityType")
    
    local function ExportOneUIInstance(InstanceID, InstanceInfo)
      local _, showAssetId = Utility:GetAssetIDForShow(InstanceInfo)
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetTitle = CreativeModeCustomObjectNameUtil.GetInstanceName(InstanceID, InstanceInfo)
      NewPresetDesc.PresetValue = CreativeDynamicPresetDescConfig.GetUUIDByKey(tonumber(InstanceID), EEntityType.BuildingInstance, 0)
      local AssetInfo = CustomUIDefine.GetAssetInfo(showAssetId)
      local ImageIndex = InstanceMgr:GetInstanceValue(InstanceID, "CustomUIButton.NormalImage", false, InstanceInfo)
      ImageIndex = ImageIndex or InstanceMgr:GetInstanceValue(InstanceID, "CustomUIImage.Image", false, InstanceInfo)
      if ImageIndex then
        local CreativeModeSelectorIconConfig = require("GameLua.Mod.CreativeBase.Gameplay.Config.CreativeModeSelectorIconConfig")
        NewPresetDesc.PresetIcon = CreativeModeSelectorIconConfig.GetTexturePathById(ImageIndex)
      elseif AssetInfo and AssetInfo.Image then
        NewPresetDesc.PresetIcon = AssetInfo.Image
      else
        NewPresetDesc.PresetIcon = ""
      end
      NewPresetDesc.ResInfo = _TablePool:Get()
      NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
      table.insert(NewPresetDesc.ResInfo.AssetIDs, showAssetId)
      NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
      if ImageIndex then
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Image] = _TablePool:Get()
        table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Image], ImageIndex)
      end
      table.insert(OutPresetDescs, NewPresetDesc)
    end
    
    local SourceTree, bFromUMGInfoMap = CreativeDynamicPresetDescConfig.GetCustomUIDataTraverseSource()
    if bFromUMGInfoMap then
      for UMGInfoID, SubTree in pairs(SourceTree) do
        local UMGInfoInstance = SubTree[tostring(UMGInfoID)]
        if UMGInfoInstance and UMGInfoInstance.UMGCanvasInfo then
          local CanvasType = UMGInfoInstance.UMGCanvasInfo.CanvasType
          if CanvasType == CustomUIDefine.UMGCanvasType.Default or CanvasType == CustomUIDefine.UMGCanvasType.Game then
            for InstanceID, InstanceInfo in pairs(SubTree) do
              if InstanceInfo and InstanceInfo.CustomUIBase then
                ExportOneUIInstance(InstanceID, InstanceInfo)
              end
            end
          end
        end
      end
    else
      for InstanceID, InstanceInfo in pairs(SourceTree) do
        if InstanceInfo.CustomUIBase then
          ExportOneUIInstance(InstanceID, InstanceInfo)
        end
      end
    end
  end
  return OutPresetDescs
end

local Enum_ImagePresetCategory = {
  [0] = 18710105,
  [1] = 8888685,
  [2] = 99009831,
  [3] = 99009830
}

function CreativeDynamicPresetDescConfig.GetImagePresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local CreativeModeSelectorIconConfig = require("GameLua.Mod.CreativeBase.Gameplay.Config.CreativeModeSelectorIconConfig")
  local IconConfig = CreativeModeSelectorIconConfig.GetOptionValue()
  if IconConfig then
    local function GetTags(Tags_a)
      local Tags = {}
      
      if Tags_a then
        for key, Tag in pairs(Tags_a) do
          table.insert(Tags, Tag)
        end
      end
      return Tags
    end
    
    local CreativeModeUIUtils = require("GameLua.Mod.CreativeBase.Client.CreativeModeUIUtils")
    local CustomAssetMetaMap = {}
    do
      local logic_ugc_prefab_mall_asset_mgr = Client and require("client.slua.logic.ugc.PrefabMall.logic_ugc_prefab_mall_asset_mgr")
      local CustomAssetDefine = require("common.CustomAsset.CustomAssetDefine")
      local PrefabType = CustomAssetDefine.ENUM_PREFAB_TYPE
      if logic_ugc_prefab_mall_asset_mgr then
        local CustomIconMetaList = logic_ugc_prefab_mall_asset_mgr:GetMyPrefabMallMeta(nil, PrefabType.IMAGE, true, nil)
        if CustomIconMetaList and type(CustomIconMetaList) == "table" then
          for _, CustomIconMeta in pairs(CustomIconMetaList) do
            CustomAssetMetaMap[CustomIconMeta.AssetKeyHasId] = CustomIconMeta
          end
        end
      end
    end
    local OfficialID = 0
    local PublishID = 1
    local CollectID = 2
    local PrivateID = 3
    local LogicUGCPrefabMall = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_ugc_prefab_mall)
    
    local function IsPublishedAsset(MetaData)
      if MetaData == nil then
        return false
      end
      return LogicUGCPrefabMall:IsInMyShares(MetaData.PrefabId)
    end
    
    local function IsCollectAsset(MetaData)
      if MetaData == nil then
        return false
      end
      return LogicUGCPrefabMall:IsInMyFavorites(MetaData.PrefabId)
    end
    
    local function IsPrivateAsset(MetaData)
      if MetaData == nil then
        return false
      end
      return MetaData.Slot ~= 0
    end
    
    local PublishRegionMacros = Client and require("client.slua.config.ClientMacros.PublishRegionMacros")
    local bBluehole = PublishRegionMacros and PublishRegionMacros.IsBlueholeOperationRegion()
    for _, TexID in ipairs(IconConfig) do
      local TexName = CreativeModeSelectorIconConfig.GetTextureNameById(TexID)
      local TexPath = CreativeModeSelectorIconConfig.GetTexturePathById(TexID)
      local IsDynamic = CreativeModeSelectorIconConfig.IsDynamicTexture(TexID)
      local TexTags = CreativeModeSelectorIconConfig.GetTextureTags(TexID)
      local OverrideCatetory = Enum_ImagePresetCategory[OfficialID]
      if not IsDynamic then
        local bSuc, LocalizedName = pcall(CreativeModeUIUtils.GetLocalizeResStr, TexName)
        if bSuc then
          TexName = LocalizedName
        end
      end
      local bSkip = false
      if IsDynamic and CustomAssetMetaMap[TexID] then
        if bBluehole then
          bSkip = true
        else
          local MetaData = CustomAssetMetaMap[TexID]
          if IsPublishedAsset(MetaData) then
            OverrideCatetory = Enum_ImagePresetCategory[PublishID]
          elseif IsCollectAsset(MetaData) then
            OverrideCatetory = Enum_ImagePresetCategory[CollectID]
          elseif IsPrivateAsset(MetaData) then
            OverrideCatetory = Enum_ImagePresetCategory[PrivateID]
          else
            print(bWriteLog and "CreativeDynamicPresetDescConfig.GetImagePresetDescConfigs TexID:" .. tostring(TexID) .. " OverrideCategory is error")
            OverrideCatetory = Enum_ImagePresetCategory[PrivateID]
          end
        end
      end
      if not bSkip then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.NeedSelectCheck = IsDynamic
        NewPresetDesc.PresetTitle = TexName
        NewPresetDesc.PresetValue = TexID
        NewPresetDesc.PresetIcon = TexPath
        NewPresetDesc.PresetTags = GetTags(TexTags)
        NewPresetDesc.OverrideCatetory = OverrideCatetory
        local AssetMgr = GetAssetManager and GetAssetManager() or nil
        if AssetMgr and not IsDynamic then
          local LimitedRemainingDays = AssetMgr:GetResIDLimitedRemainingDays(CreativeGlobalDefine.ResType.Image, TexID)
          NewPresetDesc.isValidityPreset = LimitedRemainingDays ~= nil
        end
        NewPresetDesc.ResInfo = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Image] = _TablePool:Get()
        table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Image], NewPresetDesc.PresetValue)
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  return OutPresetDescs
end

local Enum_AnimPresetCategory = {
  [0] = 4656,
  [1] = 46186,
  [2] = 99009881
}

function CreativeDynamicPresetDescConfig.GetOfficialCharacterAnimationPresetConfig()
  local OutPresetDescs = _TablePool:Get()
  local CustomEmoteAnimTable = CDataTable.GetTable("UGCCustomSkillEmoteConfig")
  if CustomEmoteAnimTable then
    for _, Config in pairs(CustomEmoteAnimTable) do
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetTitle = Config.EmoteName
      NewPresetDesc.PresetValue = Config.ID
      local OverrideCatetory = 0
      if Config.IsEmote == false then
        OverrideCatetory = 1
      end
      NewPresetDesc.OverrideCatetory = Enum_AnimPresetCategory[OverrideCatetory]
      NewPresetDesc.ResInfo = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill_Emo] = _TablePool:Get()
      table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill_Emo], NewPresetDesc.PresetValue)
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetCharacterAnimationPresetConfig(bIsDs, EditParamem, GetParamem, bIsScriptGenerator)
  local OutPresetDescs = CreativeDynamicPresetDescConfig.GetOfficialCharacterAnimationPresetConfig() or _TablePool:Get()
  local CreativeAnimationSubsystem = SubsystemMgr:Get("CreativeAnimationSubsystem")
  if CreativeAnimationSubsystem and CreativeAnimationSubsystem:CanUseAIGCAnimOnPlayerCharacterInCurrentContext() then
    local AIGCAnimMetas = CreativeAnimationSubsystem:GetAccessibleAIGCAnimMetaList()
    if AIGCAnimMetas and type(AIGCAnimMetas) == "table" then
      for _, AIGCAnimMeta in pairs(AIGCAnimMetas) do
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        local TranslatedName = AIGCAnimMeta.Name
        local LogicUGCTrans = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCTrans)
        TranslatedName = LogicUGCTrans and LogicUGCTrans:GetTransByStrWithState(AIGCAnimMeta.Name) or TranslatedName
        NewPresetDesc.PresetTitle = TranslatedName or AIGCAnimMeta.Name
        local CustomAssetKey = AIGCAnimMeta.CustomAssetKey
        if bIsScriptGenerator then
          NewPresetDesc.PresetValue = CustomAssetKey
        else
          NewPresetDesc.PresetValue = CreativeDynamicPresetDescConfig.GenerateCustomAseetKeyPresetValue(CustomAssetKey)
        end
        NewPresetDesc.OverrideCatetory = Enum_AnimPresetCategory[2]
        NewPresetDesc.NeedSelectCheck = true
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetArmedAIAnimationPresetConfig(bIsDs, EditParamem, GetParamem, bIsScriptGenerator)
  local OutPresetDescs = CreativeDynamicPresetDescConfig.GetOfficialCharacterAnimationPresetConfig() or _TablePool:Get()
  local CreativeAnimationSubsystem = SubsystemMgr:Get("CreativeAnimationSubsystem")
  if CreativeAnimationSubsystem then
    local AIGCAnimMetas = CreativeAnimationSubsystem:GetAccessibleAIGCAnimMetaList()
    if AIGCAnimMetas and type(AIGCAnimMetas) == "table" then
      for _, AIGCAnimMeta in pairs(AIGCAnimMetas) do
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        local TranslatedName = AIGCAnimMeta.Name
        local LogicUGCTrans = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCTrans)
        TranslatedName = LogicUGCTrans and LogicUGCTrans:GetTransByStrWithState(AIGCAnimMeta.Name) or TranslatedName
        NewPresetDesc.PresetTitle = TranslatedName or AIGCAnimMeta.Name
        local CustomAssetKey = AIGCAnimMeta.CustomAssetKey
        if bIsScriptGenerator then
          NewPresetDesc.PresetValue = CustomAssetKey
        else
          NewPresetDesc.PresetValue = CreativeDynamicPresetDescConfig.GenerateCustomAseetKeyPresetValue(CustomAssetKey)
        end
        NewPresetDesc.OverrideCatetory = Enum_AnimPresetCategory[2]
        NewPresetDesc.NeedSelectCheck = true
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetPresetCustomParameters(bIsDs, EditParamem)
  local OutPresetDescs = _TablePool:Get()
  local AssetManager = GetAssetManager()
  local PresetDatas = AssetManager:GetCustomPresetConfigData()
  local ExtraData = {PresetID = -1, AttributeIndex = -1}
  for _, Data in pairs(PresetDatas) do
    for i, Value in ipairs(Data.CustomPreset.CustomAttributes.overrides) do
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetTitle = Value.CustomAttributesName
      NewPresetDesc.PresetValue = CreativeDynamicPresetDescConfig.GetPresetParamsPresetValue(Data.CustomPreset.PresetID, Value.CustomAttributesName)
      NewPresetDesc.IsCustomVar = CreativeDynamicPresetDescConfig.GetPresetParamsIsCustomVar(Data, EditParamem)
      NewPresetDesc.CustomVarType = CreativeDynamicPresetDescConfig.GetPresetParamsType(Value)
      NewPresetDesc.IsCustomArrayVar = Value.IsArray == true
      ExtraData.PresetID = Data.CustomPreset.PresetID
      ExtraData.AttributeIndex = i
      print(bWriteLog and "CreativeDynamicPresetDescConfig.GetPresetCustomParameters PresetValue:" .. tostring(NewPresetDesc.PresetValue) .. " i:" .. tostring(i))
      log_tree("ExtraData:", ExtraData)
      local PBUtility = require("GameLua.Mod.CreativeBase.BinaryData.CreativeModePbUtility")
      NewPresetDesc.CustomExtraData = PBUtility.TablePackToPbBufferByMsg(ExtraData, PBUtility.ProtoMessageMap.BlockyLuaPresetExtraDataInfo, nil, true)
      NewPresetDesc.ResInfo = _TablePool:Get()
      NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
      table.insert(NewPresetDesc.ResInfo.AssetIDs, Data.CustomPreset.SourceAssetID)
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetGameDeviceParameterPresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local Cfg = CDataTable.GetTable("BlockyLuaLogicDeviceParameterChangeConfig")
  local AssetManager = GetAssetManager and GetAssetManager() or nil
  if Cfg then
    for _, Config in pairs(Cfg) do
      if Config.Key ~= nil and Config.Key ~= "" and Config.AssetID ~= nil and Config.BlockyLuaParameterType ~= nil and Config.BlockyLuaParameterType ~= "" then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        if AssetManager and AssetManager.GetAssetConfigFieldDisplayText then
          NewPresetDesc.PresetTitle = AssetManager:GetAssetConfigFieldDisplayText(tonumber(Config.AssetID), Config.Key)
        end
        if NewPresetDesc.PresetTitle == nil or NewPresetDesc.PresetTitle == "" then
          NewPresetDesc.PresetTitle = Config.Key
        end
        NewPresetDesc.PresetValue = CreativeDynamicPresetDescConfig.GetGameDeviceParameterPresetValue(Config.AssetID, Config.Key)
        NewPresetDesc.TypeSyncValueTypeName = Config.BlockyLuaParameterType
        NewPresetDesc.bTypeSyncValueIsArray = Config.isArray == true or tonumber(Config.isArray) == 1
        NewPresetDesc.ResInfo = _TablePool:Get()
        NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetPlayerCharacterVariablePresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local CreativeActorEditorDefine = require("GameLua.Mod.CreativeBase.Gameplay.Config.CreativeActor.CreativeActorEditorDefine")
  local CreativeCustomPresetDefine = require("GameLua.Mod.CreativeBase.Gameplay.Config.Asset.Common.CreativeCustomPresetDefine")
  local ActorID = CreativeActorEditorDefine.Enum_DefaultAbstractClassID.ClassicPlayerState
  local ActorDataMgr = GetCreativeActorDataManager and GetCreativeActorDataManager() or nil
  local ActorProxy = ActorDataMgr and ActorDataMgr:GetActorDataProxyByID(ActorID) or nil
  local Fields = ActorProxy and ActorProxy.Fields or nil
  if type(Fields) == "table" then
    for Key, Raw in pairs(Fields) do
      local TypeName = Raw and Raw.Type and CreativeCustomPresetDefine.EAttributeTypeToVarType[Raw.Type]
      if Key ~= nil and Key ~= "" and TypeName ~= nil and TypeName ~= "" then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetTitle = Key
        NewPresetDesc.PresetValue = CreativeDynamicPresetDescConfig.GetPlayerCharacterVariablePresetValue(Key)
        NewPresetDesc.TypeSyncValueTypeName = TypeName
        NewPresetDesc.bTypeSyncValueIsArray = Raw.IsArray == true
        NewPresetDesc.ResInfo = _TablePool:Get()
        NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetDropGroupPreset()
  local OutPresetDescs = _TablePool:Get()
  local CreativeModeItemDropSubsystem = SubsystemMgr:Get("CreativeModeItemDropSubsystem")
  if CreativeModeItemDropSubsystem then
    local CreativeManagerTools = require("GameLua.Mod.CreativeBase.Gameplay.Common.CreativeManagerTools")
    local GameParameterMgr = CreativeManagerTools:GetGameParameterManager()
    local CustomItemsSubsystem = SubsystemMgr:Get("CreativeCustomItemsSubsystem")
    local ItemDropConfigs = CreativeModeItemDropSubsystem:GetDropConfigInfos()
    if ItemDropConfigs == nil then
      CreativeModeItemDropSubsystem:LoadDropConfig()
      ItemDropConfigs = CreativeModeItemDropSubsystem:GetDropConfigInfos()
    end
    if ItemDropConfigs ~= nil then
      for Index, Cfg in ipairs(ItemDropConfigs) do
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetValue = Cfg.ConfigId
        if tonumber(Cfg.ConfigName) == nil then
          NewPresetDesc.PresetTitle = Cfg.ConfigName
        else
          local name = LocUtil.GetLocalizeResStr(tonumber(Cfg.ConfigName))
          if name and name ~= "" then
            NewPresetDesc.PresetTitle = name
          else
            NewPresetDesc.PresetTitle = Cfg.ConfigName
          end
        end
        NewPresetDesc.ResInfo = _TablePool:Get()
        NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
        table.insert(NewPresetDesc.ResInfo.AssetIDs, 3101021)
        NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Item] = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill] = _TablePool:Get()
        local items = CreativeModeItemDropSubsystem:GetAllDropItemList(Cfg.ConfigId)
        for i, item in pairs(items) do
          local DependItemID, DependSkillID = CustomItemsSubsystem:GetActualItemIDAndSkillIDByItemID(item.ItemId)
          if 0 < DependItemID then
            table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Item], DependItemID)
          end
          if 0 < DependSkillID then
            table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill], DependSkillID)
          end
        end
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetProjectilePreset()
  local CreativeModeProjectileDefine = require("GameLua.Mod.CreativeBase.Gameplay.Subsystem.Projectile.CreativeModeProjectileDefine")
  local OutPresetDescs = _TablePool:Get()
  local AssetManager = GetAssetManager()
  
  local function GetNewPresetFunc(PresetTitle, AssetID)
    local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
    NewPresetDesc.PresetTitle = PresetTitle
    NewPresetDesc.PresetValue = AssetID
    if Client then
      local CreativeModeUIUtils = require("GameLua.Mod.CreativeBase.Client.CreativeModeUIUtils")
      NewPresetDesc.PresetIcon = CreativeModeUIUtils.GetAssetSmallIcon(AssetID)
    else
      NewPresetDesc.PresetIcon = ""
    end
    local AssetData = AssetManager:GetAsset(AssetID)
    local DependResIDs
    if AssetData then
      DependResIDs = CreativeModeProjectileDefine.CollectMetaDependResIDs(AssetData)
    end
    NewPresetDesc.ResInfo = _TablePool:Get()
    NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
    NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
    table.insert(NewPresetDesc.ResInfo.AssetIDs, AssetID)
    if DependResIDs then
      for ResType, ResList in pairs(DependResIDs) do
        for _, ResID in pairs(ResList) do
          if not NewPresetDesc.ResInfo.ResIDs[ResType] then
            NewPresetDesc.ResInfo.ResIDs[ResType] = _TablePool:Get()
          end
          table.insert(NewPresetDesc.ResInfo.ResIDs[ResType], ResID)
        end
      end
    end
    return NewPresetDesc
  end
  
  for AssetId, _ in pairs(CreativeModeProjectileDefine.AssetIdConfig) do
    table.insert(OutPresetDescs, GetNewPresetFunc(AssetManager:GetAssetDescInfo(AssetId, "Name"), AssetId))
  end
  local PresetDatas = AssetManager:GetCustomPresetConfigData()
  for _, Data in pairs(PresetDatas) do
    if CreativeModeProjectileDefine.AssetIdConfig[Data.CustomPreset.SourceAssetID] ~= nil and AssetManager:GetSubstituteAssetID(Data.CustomPreset.SourceAssetID) ~= Data.CustomPreset.PresetID then
      local NewPresetDesc = GetNewPresetFunc(Data.CustomPreset.Name, Data.CustomPreset.PresetID)
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetMonsterAnimationPresetConfig()
  local OutPresetDescs = _TablePool:Get()
  local Cfg = CDataTable.GetTable("UGCCustomSkillMonsterAnimCfg")
  if Cfg then
    for _, Config in pairs(Cfg) do
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetTitle = Config.AnimName
      NewPresetDesc.PresetValue = Config.ID
      NewPresetDesc.OverrideCatetory = Config.MonsterNameID
      NewPresetDesc.ResInfo = _TablePool:Get()
      NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Monster] = _TablePool:Get()
      table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Monster], Config.MonsterID)
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetNPCAnimationPresetConfig()
  local OutPresetDescs = _TablePool:Get()
  local CreativeNPCDefine = require("GameLua.Mod.CreativeBase.Gameplay.Config.Asset.Common.CreativeNPCDefine")
  local Cfg = CreativeNPCDefine.NPCAnimationConfig
  if Cfg then
    for _, Config in pairs(Cfg) do
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetTitle = LocUtil.GetLocalizeResStr(Config.AnimationNameID)
      NewPresetDesc.PresetValue = Config.AnimID
      NewPresetDesc.PresetAnimationPath = Config.AnimationPath
      NewPresetDesc.OverrideCatetory = Config.NPCNameID
      NewPresetDesc.ResInfo = _TablePool:Get()
      NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.NPC] = _TablePool:Get()
      table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.NPC], Config.NPCID)
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetNPCPresetConfig()
  local OutPresetDescs = _TablePool:Get()
  local CreativeNPCDefine = require("GameLua.Mod.CreativeBase.Gameplay.Config.Asset.Common.CreativeNPCDefine")
  local Cfg = CreativeNPCDefine.NPCConfig
  if Cfg then
    for _, Config in pairs(Cfg) do
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetTitle = LocUtil.GetLocalizeResStr(Config.NPCNameID)
      NewPresetDesc.PresetValue = Config.NPCID
      NewPresetDesc.ResInfo = _TablePool:Get()
      NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.NPC] = _TablePool:Get()
      table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.NPC], Config.NPCID)
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetCustomEventDefPresetConfig()
  local OutPresetDescs = _TablePool:Get()
  local CreativeModeCustomEventDefSubSystem = SubsystemMgr:Get("CreativeModeCustomEventDefSubSystem")
  if CreativeModeCustomEventDefSubSystem then
    local CreativeModeUIUtils = require("GameLua.Mod.CreativeBase.Client.CreativeModeUIUtils")
    local AllEvents = CreativeModeCustomEventDefSubSystem:GetCustomEventDef()
    local ConvertHash = func
    for _, Event in ipairs(AllEvents) do
      local EventId = CreativeModeCustomEventDefSubSystem:ConvertToBlockyLuaId(Event)
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetTitle = CreativeModeUIUtils.GetLocalizeResStr(Event)
      NewPresetDesc.PresetValue = string.format("\"CustomEvent_%s\"", EventId)
      NewPresetDesc.ResInfo = _TablePool:Get()
      NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetGameplayButtonPresetConfig()
  local OutPresetDescs = _TablePool:Get()
  local UGCLuaGlobalDefine = require("GameLua.Mod.CreativeBase.Gameplay.CreativeLua.Both.UGCLuaGlobalDefine")
  local GameplayButtonTypeNameID = UGCLuaGlobalDefine.GameplayButtonTypeNameID
  for EnumValue, NameID in pairs(GameplayButtonTypeNameID) do
    local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
    NewPresetDesc.PresetTitle = LocUtil.GetLocalizeResStr(NameID)
    NewPresetDesc.PresetValue = EnumValue
    NewPresetDesc.ResInfo = _TablePool:Get()
    NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
    NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
    table.insert(OutPresetDescs, NewPresetDesc)
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetTreasurePresetConfig()
  local CreativeModeTreasureConfig = require("GameLua.Mod.CreativeBase.Gameplay.Config.CreativeModeTreasureConfig")
  local AssetManager = GetAssetManager()
  local OutPresetDescs = _TablePool:Get()
  
  local function GetNewPresetFunc(Title, AssetID)
    local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
    NewPresetDesc.PresetValue = AssetID
    NewPresetDesc.PresetTitle = Title
    if Client then
      local CreativeModeUIUtils = require("GameLua.Mod.CreativeBase.Client.CreativeModeUIUtils")
      NewPresetDesc.PresetIcon = CreativeModeUIUtils.GetAssetSmallIcon(AssetID)
    else
      NewPresetDesc.PresetIcon = ""
    end
    NewPresetDesc.ResInfo = _TablePool:Get()
    NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
    table.insert(NewPresetDesc.ResInfo.AssetIDs, AssetID)
    return NewPresetDesc
  end
  
  local ExistAssetIDs = {}
  for i, v in ipairs(CreativeModeTreasureConfig.TreasurePresetConfig) do
    local NewPresetDesc = GetNewPresetFunc(AssetManager:GetAssetDescInfo(v, "Name"), v)
    table.insert(OutPresetDescs, NewPresetDesc)
    ExistAssetIDs[v] = true
  end
  local PresetDatas = AssetManager:GetCustomPresetConfigData()
  for _, Data in pairs(PresetDatas) do
    if ExistAssetIDs[Data.CustomPreset.SourceAssetID] and AssetManager:GetSubstituteAssetID(Data.CustomPreset.SourceAssetID) ~= Data.CustomPreset.PresetID then
      local NewPresetDesc = GetNewPresetFunc(Data.CustomPreset.Name, Data.CustomPreset.PresetID)
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetGameTaskPresetConfig(bIsDs, EditParamem, GetParamem, bIsScriptGenerator)
  local OutPresetDescs = _TablePool:Get()
  local GameTaskMgr = _G.GetCreativeModeGameTaskManager()
  if GameTaskMgr ~= nil then
    local TaskTemplatePresetIDs = GameTaskMgr:GetTaskTemplatePresetIDs()
    for i = 1, #TaskTemplatePresetIDs do
      local TaskTemplatePresetID = TaskTemplatePresetIDs[i]
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      local TaskConfig = GameTaskMgr.EditorDataFeature:GetTaskConfigByGUID(TaskTemplatePresetID)
      if TaskConfig ~= nil then
        NewPresetDesc.PresetTitle = TaskConfig.BasicInfo.TaskName
        NewPresetDesc.ResInfo = _TablePool:Get()
      end
      if bIsScriptGenerator == true then
        NewPresetDesc.PresetValue = tostring(TaskTemplatePresetID)
      else
        NewPresetDesc.PresetValue = "\"" .. tostring(TaskTemplatePresetID) .. "\""
      end
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetLevelPresetConfig(bIsDs, EditParamem, GetParamem, bIsScriptGenerator)
  local OutPresetDescs = _TablePool:Get()
  if Client then
    local LogicUGCMultiLevel = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_ugc_multi_level)
    if LogicUGCMultiLevel == nil then
      return OutPresetDescs
    end
    local AllLevelData = LogicUGCMultiLevel:GetAllLevelData()
    if AllLevelData == nil then
      return OutPresetDescs
    end
    for i = 1, #AllLevelData do
      local LevelData = AllLevelData[i]
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetTitle = LevelData.LevelName or ""
      NewPresetDesc.PresetValue = LevelData.LevelID
      NewPresetDesc.ResInfo = _TablePool:Get()
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetPropPresetByCostType(PropCostType)
  local OutPresetDescs = _TablePool:Get()
  local GameParameterMgr = GetGameParameterManager()
  local PropList = GameParameterMgr:GetGameParameter("CreativePropInfo").Value
  local ShopList = {}
  if Client and UIManager.IsUIShow(UIManager.UI_Config_InGame.PropShopMapStoreUIBP) then
    local CreativePropShopSubSystem = SubsystemMgr:Get("CreativePropShopSubSystem")
    ShopList = CreativePropShopSubSystem.ShopClientTempValue
  else
    ShopList = GameParameterMgr:GetGameParameter("CreativePropShopConfig").Value
  end
  local PropInShop = {}
  for _, ShopData in ipairs(ShopList) do
    for i, v in ipairs(ShopData.PropID) do
      PropInShop[v] = true
    end
  end
  local CreativeModeSelectorIconConfig = require("GameLua.Mod.CreativeBase.Gameplay.Config.CreativeModeSelectorIconConfig")
  local CreativeCustomSkillSubsystem = SubsystemMgr:Get("CreativeCustomSkillSubsystem")
  local CreativeCustomBuffSubsystem = SubsystemMgr:Get("CreativeCustomBuffSubsystem")
  for _, PropData in ipairs(PropList) do
    if PropInShop[PropData.PropID] and (PropCostType == nil or PropCostType == PropData.PropCostType) then
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetTitle = PropData.PropName
      NewPresetDesc.PresetValue = PropData.PropID
      NewPresetDesc.PresetIcon = CreativeModeSelectorIconConfig.GetTexturePathById(PropData.PropIcon) or ""
      NewPresetDesc.ResInfo = _TablePool:Get()
      NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Buff] = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill] = _TablePool:Get()
      for i, v in ipairs(PropData.BuffList) do
        table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Buff], CreativeCustomBuffSubsystem:GetTemplateBuffIDByConfigID(v))
      end
      if CreativeCustomSkillSubsystem ~= nil then
        for i, v in ipairs(PropData.SkillList) do
          table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill], v)
          local ResMap, _ = CreativeCustomSkillSubsystem:GetOneDependsBySkillID(v)
          if ResMap then
            for ResType, ResList in pairs(ResMap) do
              if NewPresetDesc.ResInfo.ResIDs[ResType] == nil then
                NewPresetDesc.ResInfo.ResIDs[ResType] = {}
              end
              for _, ResID in pairs(ResList) do
                table.insert(NewPresetDesc.ResInfo.ResIDs[ResType], ResID)
              end
            end
          end
        end
      end
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetPropPresetConfig()
  return CreativeDynamicPresetDescConfig.GetPropPresetByCostType()
end

function CreativeDynamicPresetDescConfig.GetPropPreset_CountConfig()
  local CreativePropShopConfig = require("client.slua.logic.ugc.CreativeConfig.CreativePropShopConfig")
  return CreativeDynamicPresetDescConfig.GetPropPresetByCostType(CreativePropShopConfig.CostType.Count)
end

function CreativeDynamicPresetDescConfig.GetShopPresetConfig()
  local OutPresetDescs = _TablePool:Get()
  local GameParameterMgr = GetGameParameterManager()
  local ShopList = GameParameterMgr:GetGameParameter("CreativePropShopConfig").Value
  local CreativeModeSelectorIconConfig = require("GameLua.Mod.CreativeBase.Gameplay.Config.CreativeModeSelectorIconConfig")
  for _, ShopData in ipairs(ShopList) do
    local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
    NewPresetDesc.PresetTitle = ShopData.ShopName
    NewPresetDesc.PresetValue = ShopData.ShopID
    NewPresetDesc.ResInfo = _TablePool:Get()
    NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
    NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
    table.insert(OutPresetDescs, NewPresetDesc)
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetCustomTLogEventNamePresetConfig()
  local OutPresetDescs = _TablePool:Get()
  local CreativeNPCDefinePlayerTlogDefine = require("GameLua.Mod.CreativeBase.Gameplay.Config.Asset.Common.CreativeNPCDefinePlayerTlogDefine")
  local Cfg = CreativeNPCDefinePlayerTlogDefine.TlogConfig
  if Cfg then
    for _, Config in pairs(Cfg) do
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetTitle = LocUtil.GetLocalizeResStr(Config.TlogNameID)
      NewPresetDesc.PresetValue = Config.TlogID
      NewPresetDesc.ResInfo = _TablePool:Get()
      NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetNativeControlTypePresetConfig()
  local OutPresetDescs = _TablePool:Get()
  local NativeControlTypeConfig = require("GameLua.Mod.CreativeBase.Gameplay.Config.NativeControlTypeConfig")
  local ControlTypeNameMap = NativeControlTypeConfig.ControlTypeNameMap
  for controlTypeValue = NativeControlTypeConfig.CONTROL_TYPE_MIN, NativeControlTypeConfig.CONTROL_TYPE_MAX do
    local Title = ControlTypeNameMap[controlTypeValue]
    if Title then
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetTitle = LocUtil.GetLocalizeResStr(Title)
      NewPresetDesc.PresetValue = controlTypeValue
      NewPresetDesc.ResInfo = _TablePool:Get()
      NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetActorPresetConfig()
  local CreativeActorEditorDefine = require("GameLua.Mod.CreativeBase.Gameplay.Config.CreativeActor.CreativeActorEditorDefine")
  local OutPresetDescs = _TablePool:Get()
  local CreativeActorDataManager = GetCreativeActorDataManager()
  if CreativeActorDataManager ~= nil then
    for _, ActorID in pairs(CreativeActorEditorDefine.Enum_ActorID) do
      local ActorDataProxy = CreativeActorDataManager:GetActorDataProxyByID(ActorID)
      if ActorDataProxy ~= nil and ActorDataProxy.bAbstractClass ~= true then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetTitle = ActorDataProxy.DisplayName
        NewPresetDesc.PresetValue = ActorDataProxy.ActorID
        NewPresetDesc.ResInfo = _TablePool:Get()
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
    local UserActorIDs = CreativeActorDataManager:GetAllUserActorIDs()
    for i = 1, #UserActorIDs do
      local UserActorID = UserActorIDs[i]
      local ActorDataProxy = CreativeActorDataManager:GetActorDataProxyByID(UserActorID)
      if ActorDataProxy ~= nil and ActorDataProxy.bAbstractClass ~= true then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetTitle = ActorDataProxy.DisplayName
        NewPresetDesc.PresetValue = ActorDataProxy.ActorID
        NewPresetDesc.ResInfo = _TablePool:Get()
        local AssetIDs, ResIDs = CreativeActorDataManager:CollectAllDependsFromActorID(UserActorID)
        if AssetIDs ~= nil then
          NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
          for j = 1, #AssetIDs do
            table.insert(NewPresetDesc.ResInfo.AssetIDs, AssetIDs[j])
          end
        end
        if ResIDs ~= nil then
          NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
          for ResType, ResIDArr in pairs(ResIDs) do
            local _ResIDArr = _TablePool:Get()
            NewPresetDesc.ResInfo.ResIDs[ResType] = _ResIDArr
            for j = 1, #ResIDArr do
              table.insert(_ResIDArr, ResIDArr[j])
            end
          end
        end
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetComponentPresetConfig()
  local CreativeActorEditorDefine = require("GameLua.Mod.CreativeBase.Gameplay.Config.CreativeActor.CreativeActorEditorDefine")
  local OutPresetDescs = _TablePool:Get()
  local CreativeActorDataManager = GetCreativeActorDataManager()
  if CreativeActorDataManager ~= nil then
    for _, ComponentID in pairs(CreativeActorEditorDefine.Enum_ComponentID) do
      local ComponentDataProxy = CreativeActorDataManager:GetComponentDataProxyByID(ComponentID)
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetTitle = ComponentDataProxy.DisplayName
      NewPresetDesc.PresetValue = ComponentDataProxy.ComponentID
      NewPresetDesc.ResInfo = _TablePool:Get()
      table.insert(OutPresetDescs, NewPresetDesc)
    end
    local UserComponentIDs = CreativeActorDataManager:GetAllUserComponentIDs()
    for i = 1, #UserComponentIDs do
      local UserComponentID = UserComponentIDs[i]
      local ComponentDataProxy = CreativeActorDataManager:GetComponentDataProxyByID(UserComponentID)
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetTitle = ComponentDataProxy.DisplayName
      NewPresetDesc.PresetValue = ComponentDataProxy.ComponentID
      NewPresetDesc.ResInfo = _TablePool:Get()
      local AssetIDs, ResIDs = CreativeActorDataManager:CollectAllDependsFromComponentID(UserComponentID)
      if AssetIDs ~= nil then
        NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
        for j = 1, #AssetIDs do
          table.insert(NewPresetDesc.ResInfo.AssetIDs, AssetIDs[j])
        end
      end
      if ResIDs ~= nil then
        NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
        for ResType, ResIDArr in pairs(ResIDs) do
          local _ResIDArr = _TablePool:Get()
          NewPresetDesc.ResInfo.ResIDs[ResType] = _ResIDArr
          for j = 1, #ResIDArr do
            table.insert(_ResIDArr, ResIDArr[j])
          end
        end
      end
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetModelPresetConfig()
  local OutPresetDescs = _TablePool:Get()
  local ModelDataSubsystem = SubsystemMgr:Get("CreativeModelDataSubsystem")
  if ModelDataSubsystem then
    local ModelOptionList = ModelDataSubsystem:GetModelOptionList()
    if ModelOptionList ~= nil then
      for i = 1, #ModelOptionList do
        local ModelOptionInfo = ModelOptionList[i]
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetTitle = ModelOptionInfo.Title
        NewPresetDesc.PresetValue = ModelOptionInfo.Value
        NewPresetDesc.ResInfo = _TablePool:Get()
        if ModelOptionInfo.bIsSingleMeshAsset then
          NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
          table.insert(NewPresetDesc.ResInfo.AssetIDs, tonumber(ModelOptionInfo.Value))
        else
          NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
          local _ResIDArr = _TablePool:Get()
          NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.CustomModel] = _ResIDArr
          table.insert(_ResIDArr, ModelOptionInfo.Value)
        end
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  return OutPresetDescs
end

local CustomAssetSkeletalMeshDefine = require("common.CustomAsset.CustomSkeletalMesh.CustomAssetSkeletalMeshDefine")
local EOfficialSkeletonPreset = CustomAssetSkeletalMeshDefine.EOfficialSkeletonPreset
local SkeletonPresetDisplayName = {
  [EOfficialSkeletonPreset.MonsterHumanoid] = 2026060760,
  [EOfficialSkeletonPreset.MonsterQuadruped] = 2026060761,
  [EOfficialSkeletonPreset.YellowDuck] = "B.Duck"
}

local function _GetSkeletonPresetName(SkelPreset)
  local Name = SkelPreset and SkeletonPresetDisplayName[SkelPreset] or nil
  if Name == nil then
    return ""
  end
  if type(Name) == "number" and LocUtil and LocUtil.GetLocalizeResStr then
    local Str = LocUtil.GetLocalizeResStr(Name)
    return Str and Str ~= "" and Str or tostring(Name)
  end
  return tostring(Name)
end

local function _AppendSkeletonName(Title, SkelPreset)
  local SkelName = _GetSkeletonPresetName(SkelPreset)
  if SkelName == "" then
    return Title
  end
  return Title .. " [" .. SkelName .. "]"
end

function CreativeDynamicPresetDescConfig.GetSkeletalModelPresetConfig()
  local OutPresetDescs = _TablePool:Get()
  local CreativeSkeletalModelPresetConfig = require("GameLua.Mod.CreativeBase.Gameplay.Animation.CreativeSkeletalModelPresetConfig")
  local OfficialMeshPresets = CreativeSkeletalModelPresetConfig.OfficialMeshPresets
  if OfficialMeshPresets == nil then
    return OutPresetDescs
  end
  for SkeletonPreset, EntryList in pairs(OfficialMeshPresets) do
    if type(EntryList) == "table" then
      for i = 1, #EntryList do
        local Entry = EntryList[i]
        if Entry and Entry.OfficialPresetID ~= nil then
          local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
          local Title
          if type(Entry.Name) == "number" and LocUtil and LocUtil.GetLocalizeResStr then
            Title = LocUtil.GetLocalizeResStr(Entry.Name)
          end
          if Title == nil or Title == "" then
            Title = Entry.Id or Entry.AssetPath or tostring(Entry.OfficialPresetID)
          end
          NewPresetDesc.PresetTitle = _AppendSkeletonName(Title, SkeletonPreset)
          NewPresetDesc.PresetValue = tostring(Entry.OfficialPresetID)
          if Entry.IconPath ~= nil and Entry.IconPath ~= "" then
            NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(Entry.IconPath)
          end
          NewPresetDesc.ResInfo = _TablePool:Get()
          NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
          NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.SkeletalMeshPresetID] = _TablePool:Get()
          table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.SkeletalMeshPresetID], NewPresetDesc.PresetValue)
          table.insert(OutPresetDescs, NewPresetDesc)
        end
      end
    end
  end
  local logic_ugc_prefab_mall_asset_mgr = Client and require("client.slua.logic.ugc.PrefabMall.logic_ugc_prefab_mall_asset_mgr") or nil
  if logic_ugc_prefab_mall_asset_mgr then
    local CustomAssetDefine = require("common.CustomAsset.CustomAssetDefine")
    local PrefabType = CustomAssetDefine.ENUM_PREFAB_TYPE
    local CustomIconMetaList = logic_ugc_prefab_mall_asset_mgr:GetMyPrefabMallMeta(nil, PrefabType.SKELETALMESH, true, nil)
    if CustomIconMetaList and type(CustomIconMetaList) == "table" then
      for _, CustomIconMeta in pairs(CustomIconMetaList) do
        local CustomAssetKey = CustomIconMeta.CustomAssetKey
        if type(CustomAssetKey) == "string" and CustomAssetKey ~= "" then
          local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
          NewPresetDesc.PresetValue = CustomAssetKey
          local Name = CustomIconMeta.Name
          if Name == nil or Name == "" then
            Name = tostring(CustomAssetKey)
          end
          local SkelPreset
          local SkelMeshDataSubsystem = SubsystemMgr and SubsystemMgr:Get("CreativeSkeletalMeshDataSubsystem") or nil
          if SkelMeshDataSubsystem and SkelMeshDataSubsystem.GetSkeletonPresetFromMeta then
            SkelPreset = SkelMeshDataSubsystem:GetSkeletonPresetFromMeta(CustomIconMeta)
          end
          NewPresetDesc.PresetTitle = _AppendSkeletonName(Name, SkelPreset)
          local IconPath = CustomIconMeta.Pic_Full_Url
          if IconPath == nil or IconPath == "" then
            IconPath = CustomAssetDefine.DefaultActorIcon
          end
          NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(IconPath)
          NewPresetDesc.NeedSelectCheck = true
          NewPresetDesc.SkeletonType = CustomIconMeta.SkeletonType
          NewPresetDesc.ResInfo = _TablePool:Get()
          NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
          NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.SkeletalMeshPresetID] = _TablePool:Get()
          table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.SkeletalMeshPresetID], CustomAssetKey)
          table.insert(OutPresetDescs, NewPresetDesc)
        end
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetSkeletalAnimPresetConfig()
  local OutPresetDescs = _TablePool:Get()
  local CreativeModeCharacterAnimationConfig = require("GameLua.Mod.CreativeBase.Gameplay.Animation.CreativeModeCharacterAnimationConfig")
  local AnimAssetList = CreativeModeCharacterAnimationConfig.OfficialAnimAssetList
  if AnimAssetList == nil then
    return OutPresetDescs
  end
  for i = 1, #AnimAssetList do
    local Entry = AnimAssetList[i]
    if Entry and Entry.OfficialPresetID ~= nil and Entry.AssetPath ~= nil and Entry.AssetPath ~= "" and not Entry.bBlocked then
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      local Title
      if type(Entry.Name) == "number" and LocUtil and LocUtil.GetLocalizeResStr then
        Title = LocUtil.GetLocalizeResStr(Entry.Name)
      end
      if Title == nil or Title == "" then
        Title = string.match(Entry.AssetPath, "([^/]+)%.[^/%.]+$") or string.match(Entry.AssetPath, "([^/]+)$") or Entry.AssetPath
      end
      NewPresetDesc.PresetTitle = _AppendSkeletonName(Title, Entry.SkeletonPreset)
      NewPresetDesc.PresetValue = tostring(Entry.OfficialPresetID)
      NewPresetDesc.ResInfo = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
      NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.AnimationPresetID] = _TablePool:Get()
      table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.AnimationPresetID], NewPresetDesc.PresetValue)
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  local logic_ugc_prefab_mall_asset_mgr = Client and require("client.slua.logic.ugc.PrefabMall.logic_ugc_prefab_mall_asset_mgr") or nil
  if logic_ugc_prefab_mall_asset_mgr then
    local CustomAssetDefine = require("common.CustomAsset.CustomAssetDefine")
    local PrefabType = CustomAssetDefine.ENUM_PREFAB_TYPE
    local CustomIconMetaList = logic_ugc_prefab_mall_asset_mgr:GetMyPrefabMallMeta(nil, PrefabType.SKELETALANIM, true, nil)
    if CustomIconMetaList and type(CustomIconMetaList) == "table" then
      for _, CustomIconMeta in pairs(CustomIconMetaList) do
        local CustomAssetKey = CustomIconMeta.CustomAssetKey
        if type(CustomAssetKey) == "string" and CustomAssetKey ~= "" then
          local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
          NewPresetDesc.PresetValue = CustomAssetKey
          local Name = CustomIconMeta.Name
          if Name == nil or Name == "" then
            Name = tostring(CustomAssetKey)
          end
          local SkelPreset
          local SkelMeshDataSubsystem = SubsystemMgr and SubsystemMgr:Get("CreativeSkeletalMeshDataSubsystem") or nil
          if SkelMeshDataSubsystem and SkelMeshDataSubsystem.GetSkeletonPresetFromMeta then
            SkelPreset = SkelMeshDataSubsystem:GetSkeletonPresetFromMeta(CustomIconMeta)
          end
          NewPresetDesc.PresetTitle = _AppendSkeletonName(Name, SkelPreset)
          NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(CustomIconMeta.Pic_Full_Url)
          NewPresetDesc.NeedSelectCheck = true
          NewPresetDesc.ResInfo = _TablePool:Get()
          NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
          NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.AnimationPresetID] = _TablePool:Get()
          table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.AnimationPresetID], CustomAssetKey)
          table.insert(OutPresetDescs, NewPresetDesc)
        end
      end
    end
  end
  return OutPresetDescs
end

local function _SetAnimGraphResInfo(PresetDesc, ConfigId)
  if type(PresetDesc) ~= "table" or type(ConfigId) ~= "number" then
    return
  end
  PresetDesc.ResInfo = _TablePool:Get()
  PresetDesc.ResInfo.ResIDs = _TablePool:Get()
  local ResIDArr = _TablePool:Get()
  PresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.AnimInstancePresetID] = ResIDArr
  table.insert(ResIDArr, ConfigId)
end

function CreativeDynamicPresetDescConfig.GetAnimationGraphPresetConfig()
  local OutPresetDescs = _TablePool:Get()
  local CreativeAnimGraphTemplates = require("GameLua.Mod.CreativeBase.Gameplay.AnimGraph.CreativeAnimGraphTemplates")
  local TemplateList = CreativeAnimGraphTemplates.TemplateList
  if type(TemplateList) == "table" then
    for i = 1, #TemplateList do
      local Template = TemplateList[i]
      if Template and type(Template.PresetId) == "number" then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetTitle = CreativeAnimGraphTemplates.GetPresetDisplayName(Template.PresetId)
        NewPresetDesc.PresetValue = tostring(Template.PresetId)
        NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.DefaultIconName
        _SetAnimGraphResInfo(NewPresetDesc, Template.PresetId)
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  local ConfigSubsystem = SubsystemMgr and SubsystemMgr:Get("CreativeAnimGraphConfigSubsystem") or nil
  if ConfigSubsystem then
    local Entries = ConfigSubsystem:GetAllAnimGraphEntries()
    if type(Entries) == "table" then
      for _, Entry in ipairs(Entries) do
        local ConfigId = Entry.ConfigId
        if type(ConfigId) == "number" and 0 < ConfigId and ConfigId < CreativeAnimGraphTemplates.PRESET_ID_BASE then
          local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
          local GraphName = Entry.GraphName
          if GraphName == nil or GraphName == "" then
            GraphName = tostring(ConfigId)
          end
          NewPresetDesc.PresetTitle = GraphName
          NewPresetDesc.PresetValue = tostring(ConfigId)
          NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.DefaultIconName
          _SetAnimGraphResInfo(NewPresetDesc, ConfigId)
          table.insert(OutPresetDescs, NewPresetDesc)
        end
      end
    end
  end
  return OutPresetDescs
end

local CategoryType = {
  [0] = 8500587,
  [1] = 8888685,
  [2] = 99009831,
  [3] = 99009830
}

function CreativeDynamicPresetDescConfig.GetUMGResPresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local logic_ugc_prefab_mall_asset_mgr = Client and require("client.slua.logic.ugc.PrefabMall.logic_ugc_prefab_mall_asset_mgr")
  local CustomAssetDefine = require("common.CustomAsset.CustomAssetDefine")
  local PrefabType = CustomAssetDefine.ENUM_PREFAB_TYPE
  if logic_ugc_prefab_mall_asset_mgr then
    local CustomIconMetaList = logic_ugc_prefab_mall_asset_mgr:GetMyPrefabMallMeta(nil, PrefabType.CUSTOMUI, nil, nil)
    if CustomIconMetaList and type(CustomIconMetaList) == "table" then
      for _, CustomIconMeta in pairs(CustomIconMetaList) do
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetTitle = CustomIconMeta.Name
        NewPresetDesc.PresetValue = CustomIconMeta.CustomAssetKey
        NewPresetDesc.ResInfo = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Image] = _TablePool:Get()
        local DepCustomAssetKeys = CustomIconMeta.DepCustomAssetKeys
        if DepCustomAssetKeys and next(DepCustomAssetKeys) then
          for _, AssetKey in pairs(DepCustomAssetKeys) do
            local AssetInfo = CustomAssetMgr:GetCustomAssetInfo(AssetKey)
            if AssetInfo and AssetInfo.AssetType == CustomAssetDefine.Enum_CustomAssetType.Image then
              local HashID = CustomAssetMgr:GetHashIDByCustomAssetKey(AssetKey)
              if HashID and 0 < HashID then
                table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Image], HashID)
              end
            end
          end
        end
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  return OutPresetDescs
end

local Enum_CreativeGroupAssetPresetCatetory = {
  [1] = 9854073,
  [2] = 9854071,
  [3] = 9854072
}

function CreativeDynamicPresetDescConfig.GetCreativeGroupAssetPresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local logic_ugc_prefab_mall_asset_mgr = Client and require("client.slua.logic.ugc.PrefabMall.logic_ugc_prefab_mall_asset_mgr")
  local CustomAssetDefine = require("common.CustomAsset.CustomAssetDefine")
  local BitmapUtil = require("client.slua.logic.ugc.PrefabMall.Config.PrefabMallBitmapUtil")
  local PrefabType = CustomAssetDefine.ENUM_PREFAB_TYPE
  if logic_ugc_prefab_mall_asset_mgr then
    for TabIndex, Catetory in pairs(Enum_CreativeGroupAssetPresetCatetory) do
      local CustomPrefabMetaList = logic_ugc_prefab_mall_asset_mgr:GetMyPrefabMallMeta(TabIndex, PrefabType.PREFAB, nil, nil)
      if CustomPrefabMetaList and type(CustomPrefabMetaList) == "table" then
        for _, MetaData in pairs(CustomPrefabMetaList) do
          local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
          NewPresetDesc.PresetTitle = MetaData.Name
          NewPresetDesc.PresetValue = MetaData.CustomAssetKey
          NewPresetDesc.ResInfo = _TablePool:Get()
          NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
          local AssetIDsInMeta = MetaData.AssetIds
          for k, v in pairs(AssetIDsInMeta) do
            table.insert(NewPresetDesc.ResInfo.AssetIDs, v)
          end
          NewPresetDesc.ResInfo.FeatureIDs = _TablePool:Get()
          local FeatureIDsInMeta = MetaData.FeatureResIds
          for k, v in pairs(FeatureIDsInMeta) do
            table.insert(NewPresetDesc.ResInfo.FeatureIDs, v)
          end
          NewPresetDesc.ResInfo.CustomAssetKeys = _TablePool:Get()
          local CustomAssetKeysInMeta = MetaData.DepCustomAssetKeys
          if CustomAssetKeysInMeta and next(CustomAssetKeysInMeta) then
            for k, v in pairs(CustomAssetKeysInMeta) do
              table.insert(NewPresetDesc.ResInfo.CustomAssetKeys, v)
            end
          end
          NewPresetDesc.OverrideCatetory = Catetory
          table.insert(OutPresetDescs, NewPresetDesc)
        end
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetUMGCanvasPresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local InstanceMgr = GetInstanceManager and GetInstanceManager() or nil
  if InstanceMgr then
    local EEntityType = import("EEntityType")
    local CustomUIDefine = require("GameLua.Mod.CreativeBase.Client.CreativeCustomUI.CustomUIDefine")
    
    local function ExportOneCanvas(InstanceID, UMGCanvasInfo)
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetTitle = UMGCanvasInfo.CanvasName
      NewPresetDesc.PresetValue = CreativeDynamicPresetDescConfig.GetUUIDByKey(tonumber(InstanceID), EEntityType.BuildingInstance, 0)
      table.insert(OutPresetDescs, NewPresetDesc)
    end
    
    local SourceTree, bFromUMGInfoMap = CreativeDynamicPresetDescConfig.GetCustomUIDataTraverseSource()
    if bFromUMGInfoMap then
      for UMGInfoID, SubTree in pairs(SourceTree) do
        local UMGInfoInstance = SubTree[tostring(UMGInfoID)]
        if UMGInfoInstance and UMGInfoInstance.UMGCanvasInfo then
          ExportOneCanvas(UMGInfoID, UMGInfoInstance.UMGCanvasInfo)
        end
      end
    else
      for InstanceID, InstanceInfo in pairs(SourceTree) do
        local UMGCanvasInfo = InstanceInfo.UMGCanvasInfo
        if UMGCanvasInfo then
          ExportOneCanvas(InstanceID, UMGCanvasInfo)
        end
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetTriggerAreaPresetDescConfigs()
  local Cfg = {
    [1] = {
      PresetValue = 3101082,
      PresetJsonKeyName = "triggerArea"
    }
  }
  local OutPresetDescs = _TablePool:Get()
  local AssetMgr = GetAssetManager and GetAssetManager() or nil
  for i, v in pairs(Cfg) do
    if AssetMgr and AssetMgr:GetSubstituteAssetID(v.PresetValue) then
    else
      local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
      NewPresetDesc.PresetValue = v.PresetValue
      local AssetConfig = CDataTable.GetTableData("UGCAssetConfig", v.PresetValue)
      if AssetConfig then
        NewPresetDesc.PresetTitle = AssetConfig.Name
        NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(AssetConfig.Icon)
      end
      if v.PresetJsonKeyName ~= nil and v.PresetJsonKeyName ~= "" then
        NewPresetDesc.OverrideKeyName = v.PresetJsonKeyName
      end
      NewPresetDesc.ResInfo = _TablePool:Get()
      NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
      table.insert(NewPresetDesc.ResInfo.AssetIDs, v.PresetValue)
      table.insert(OutPresetDescs, NewPresetDesc)
    end
  end
  if AssetMgr then
    local AllAssetID = AssetMgr:GetAllCustomPresetIds(true)
    local CreativeSceneInstanceSelectCfg = require("GameLua.Mod.CreativeBase.Client.CreativeModeEditMainCtrl.InstanceSelect.CreativeSceneInstanceSelectCfg")
    for i = 1, #AllAssetID do
      local AssetID = AllAssetID[i]
      local AssetInfo = AssetMgr:GetAssetInfo(AssetID)
      local SourceAssetID = AssetID
      if AssetInfo and AssetInfo.CustomPreset then
        SourceAssetID = AssetInfo.CustomPreset.SourceAssetID
      end
      if CreativeSceneInstanceSelectCfg.isTriggerRegion(SourceAssetID) then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetTitle = AssetMgr:GetAssetDescInfo(AssetID, "Name")
        NewPresetDesc.PresetValue = AssetID
        if NewPresetDesc.PresetTitle == nil or NewPresetDesc.PresetTitle == "" then
          NewPresetDesc.PresetTitle = tostring(AssetID)
        end
        NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(AssetMgr:GetAssetDescInfo(AssetID, "Icon"))
        NewPresetDesc.ResInfo = _TablePool:Get()
        NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
        table.insert(NewPresetDesc.ResInfo.AssetIDs, NewPresetDesc.PresetValue)
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetTeamTypePresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local AllTeamDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
  AllTeamDesc.PresetValue = 0
  AllTeamDesc.PresetTitle = LocUtil.GetLocalizeResStr(8100102)
  table.insert(OutPresetDescs, AllTeamDesc)
  for i = 1, 50 do
    local TeamDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
    TeamDesc.PresetValue = i
    TeamDesc.PresetTitle = LocUtil.LocalizeResFormat(6440, tostring(i))
    table.insert(OutPresetDescs, TeamDesc)
  end
  return OutPresetDescs
end

function CreativeDynamicPresetDescConfig.GetProfessionTypePresetDescConfigs()
  local OutPresetDescs = _TablePool:Get()
  local NoneProfessionDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
  NoneProfessionDesc.PresetValue = -1
  NoneProfessionDesc.PresetTitle = LocUtil.GetLocalizeResStr(8202223)
  table.insert(OutPresetDescs, NoneProfessionDesc)
  local AllProfessionDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
  AllProfessionDesc.PresetValue = 0
  AllProfessionDesc.PresetTitle = LocUtil.GetLocalizeResStr(8202224)
  table.insert(OutPresetDescs, AllProfessionDesc)
  for i = 1, 50 do
    local ProfessionDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
    ProfessionDesc.PresetValue = i
    ProfessionDesc.PresetTitle = string.format("Class%d", i)
    table.insert(OutPresetDescs, ProfessionDesc)
  end
  return OutPresetDescs
end

CreativeDynamicPresetDescConfig.AllDynamicTypeConfigs = {
  [Enum_DynamicType.TransDuckSkin] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.TransSkinID,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetTransDuckSkinPresetDescConfigs
  },
  [Enum_DynamicType.CreativeInstance] = {
    FullyStaticConfig = true,
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.CreativeInstance,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetCreativeInstancePresetDescConfigs,
    PresetValueGetHandle = CreativeDynamicPresetDescConfig.GetCreativeInstancePresetValue
  },
  [Enum_DynamicType.CreativeSpawnerInstance] = {
    FullyStaticConfig = true,
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.CreativeSpawnerInstance,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetCreativeSpawnerInstancePresetDescConfigs,
    PresetValueGetHandle = CreativeDynamicPresetDescConfig.GetCreativeSpawnerInstancePresetValue
  },
  [Enum_DynamicType.CreativeAsset] = {
    FullyStaticConfig = true,
    bNeedPreInit = true,
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.CreativeAsset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetCreativeAssetPresetDescConfigs
  },
  [Enum_DynamicType.CustomCreativeAsset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.CreativeAsset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetCreativeCustomCreativeAssetPresetDescConfigs
  },
  [Enum_DynamicType.HomeLandAsset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.CreativeAsset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetCreativeHomeLandAssetPresetDescConfigs
  },
  [Enum_DynamicType.CreativeDynamicAsset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.CreativeAsset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetCreativeDynamicAssetPresetDescConfigs,
    CanSelectCheckHandle = function(PresetValue, uPresetDesc)
      log_format("CanSelectCheckHandle ReceiveBlockyluaPresetSelectCheck PresetValue:" .. tostring(PresetValue) .. " uPresetDesc:" .. tostring(uPresetDesc))
      return CreativeDynamicPresetDescConfig.CustomModelSelectCheck(PresetValue, uPresetDesc)
    end
  },
  [Enum_DynamicType.SkillPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.SkillPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetSkillPresetDescConfigs
  },
  [Enum_DynamicType.EmptySkillPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.EmptySkillPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetEmptySkillPresetDescConfigs
  },
  [Enum_DynamicType.ThrowSkillPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.ThrowSkillPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetThrowSkillPresetDescConfigs
  },
  [Enum_DynamicType.BuildSkillPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.BuildSkillPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetBuildSkillSkillPresetDescConfigs
  },
  [Enum_DynamicType.BuffPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.BuffPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetBuffPresetDescConfigs
  },
  [Enum_DynamicType.CustomUIInstance] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.CustomUIInstance,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetCustomUIInstancePresetDescConfigs
  },
  [Enum_DynamicType.WeatherPreset] = {
    FullyStaticConfig = true,
    bNeedPreInit = true,
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.WeatherPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetWeatherDescConfigs
  },
  [Enum_DynamicType.PlayerCustomVar_Number] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.PlayerCustomVar_Number,
    PresetDescsGetHandle = function()
      return CreativeDynamicPresetDescConfig.GetCreativeCustomVarDescConfigs(Enum_DynamicType.PlayerCustomVar_Number)
    end
  },
  [Enum_DynamicType.PlayerCustomVar_Int] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.PlayerCustomVar_Int,
    PresetDescsGetHandle = function()
      return CreativeDynamicPresetDescConfig.GetCreativeCustomVarDescConfigs(Enum_DynamicType.PlayerCustomVar_Int)
    end
  },
  [Enum_DynamicType.PlayerCustomVar_Bool] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.PlayerCustomVar_Bool,
    PresetDescsGetHandle = function()
      return CreativeDynamicPresetDescConfig.GetCreativeCustomVarDescConfigs(Enum_DynamicType.PlayerCustomVar_Bool)
    end
  },
  [Enum_DynamicType.GlobalCustomVar_Number] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.GlobalCustomVar_Number,
    PresetDescsGetHandle = function()
      return CreativeDynamicPresetDescConfig.GetCreativeCustomVarDescConfigs(Enum_DynamicType.GlobalCustomVar_Number)
    end
  },
  [Enum_DynamicType.GlobalCustomVar_Int] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.GlobalCustomVar_Int,
    PresetDescsGetHandle = function()
      return CreativeDynamicPresetDescConfig.GetCreativeCustomVarDescConfigs(Enum_DynamicType.GlobalCustomVar_Int)
    end
  },
  [Enum_DynamicType.GlobalCustomVar_Bool] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.GlobalCustomVar_Bool,
    PresetDescsGetHandle = function()
      return CreativeDynamicPresetDescConfig.GetCreativeCustomVarDescConfigs(Enum_DynamicType.GlobalCustomVar_Bool)
    end
  },
  [Enum_DynamicType.PlayerCustomVar_String] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.PlayerCustomVar_String,
    PresetDescsGetHandle = function()
      return CreativeDynamicPresetDescConfig.GetCreativeCustomVarDescConfigs(Enum_DynamicType.PlayerCustomVar_String)
    end
  },
  [Enum_DynamicType.GlobalCustomVar_String] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.GlobalCustomVar_String,
    PresetDescsGetHandle = function()
      return CreativeDynamicPresetDescConfig.GetCreativeCustomVarDescConfigs(Enum_DynamicType.GlobalCustomVar_String)
    end
  },
  [Enum_DynamicType.PlayerCustomVar_Struct] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.PlayerCustomVar_Struct,
    PresetDescsGetHandle = function()
      return CreativeDynamicPresetDescConfig.GetCreativeCustomVarDescConfigs(Enum_DynamicType.PlayerCustomVar_Struct)
    end
  },
  [Enum_DynamicType.GlobalCustomVar_Struct] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.GlobalCustomVar_Struct,
    PresetDescsGetHandle = function()
      return CreativeDynamicPresetDescConfig.GetCreativeCustomVarDescConfigs(Enum_DynamicType.GlobalCustomVar_Struct)
    end
  },
  [Enum_DynamicType.BlackStruct] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.BlackStruct,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetBlackStructPresetDescConfigs
  },
  [Enum_DynamicType.PickupPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.PickupPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetPickupPresetDescConfigs
  },
  [Enum_DynamicType.ItemPreset] = {
    FullyStaticConfig = true,
    bNeedPreInit = true,
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.ItemPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetItemPresetDescConfigs
  },
  [Enum_DynamicType.CustomItemPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.ItemPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetDynamicItemPresetDescConfigs
  },
  [Enum_DynamicType.EffectPreset] = {
    FullyStaticConfig = false,
    bNeedPreInit = true,
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.EffectPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetEffectPresetDescConfigs,
    CanSelectCheckHandle = function(PresetValue, uPresetDesc)
      print(bWriteLog and "CanSelectCheckHandle ReceiveBlockyluaPresetSelectCheck PresetValue:" .. tostring(PresetValue) .. " uPresetDesc:" .. tostring(uPresetDesc))
      return CreativeDynamicPresetDescConfig.CustomAssetSelectCheck(PresetValue, uPresetDesc)
    end
  },
  [Enum_DynamicType.SoundPreset] = {
    FullyStaticConfig = false,
    bNeedPreInit = true,
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.SoundPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetSoundPresetDescConfigs,
    CanSelectCheckHandle = function(PresetValue, uPresetDesc)
      print(bWriteLog and "CanSelectCheckHandle ReceiveBlockyluaPresetSelectCheck PresetValue:" .. tostring(PresetValue) .. " uPresetDesc:" .. tostring(uPresetDesc))
      return CreativeDynamicPresetDescConfig.CustomAssetSelectCheck(PresetValue, uPresetDesc)
    end
  },
  [Enum_DynamicType.MonsterPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.MonsterPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetMonsterPresetDescConfigs
  },
  [Enum_DynamicType.ArmedAIPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.ArmedAIPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetArmedAIPresetDescConfigs
  },
  [Enum_DynamicType.SignalEventPreset] = {
    FullyStaticConfig = true,
    bNeedPreInit = true,
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.SignalEventPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetSignalEventPresetDescConfigs
  },
  [Enum_DynamicType.SignalFunctionPreset] = {
    FullyStaticConfig = true,
    bNeedPreInit = true,
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.SignalFunctionPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetSignalFunctionPresetDescConfigs
  },
  [Enum_DynamicType.VehiclePreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.VehiclePreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetVehiclePresetDescConfigs
  },
  [Enum_DynamicType.ImagePreset] = {
    bNeedPreInit = true,
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.ImagePreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetImagePresetDescConfigs,
    CanSelectCheckHandle = function(PresetValue, uPresetDesc)
      print(bWriteLog and "CanSelectCheckHandle ReceiveBlockyluaPresetSelectCheck PresetValue:" .. tostring(PresetValue) .. " uPresetDesc:" .. tostring(uPresetDesc))
      return CreativeDynamicPresetDescConfig.CustomAssetSelectCheck(PresetValue, uPresetDesc)
    end
  },
  [Enum_DynamicType.CharacterAnimationPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.CharacterAnimationPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetCharacterAnimationPresetConfig
  },
  [Enum_DynamicType.PresetCustomParameter] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.PresetCustomParameter,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetPresetCustomParameters
  },
  [Enum_DynamicType.GameDeviceParameter] = {
    FullyStaticConfig = true,
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.GameDeviceParameter,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetGameDeviceParameterPresetDescConfigs
  },
  [Enum_DynamicType.PlayerCharacterVariable] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.PlayerCharacterVariable,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetPlayerCharacterVariablePresetDescConfigs
  },
  [Enum_DynamicType.CreativeProjectilePreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.CreativeProjectilePreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetProjectilePreset
  },
  [Enum_DynamicType.DropGroupPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.DropGroupPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetDropGroupPreset
  },
  [Enum_DynamicType.MonsterAnimPreset] = {
    FullyStaticConfig = true,
    bNeedPreInit = true,
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.MonsterAnimPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetMonsterAnimationPresetConfig
  },
  [Enum_DynamicType.NPCAnimPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.NPCAnimPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetNPCAnimationPresetConfig
  },
  [Enum_DynamicType.NPCPreset] = {
    FullyStaticConfig = true,
    bNeedPreInit = true,
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.NPCPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetNPCPresetConfig
  },
  [Enum_DynamicType.TreasurePreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.TreasurePreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetTreasurePresetConfig
  },
  [Enum_DynamicType.GameTaskPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.GameTaskPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetGameTaskPresetConfig
  },
  [Enum_DynamicType.CustomEventDefPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.CustomEventDefPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetCustomEventDefPresetConfig
  },
  [Enum_DynamicType.BankProductPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.BankProductPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetBankProductPresetDescConfigs
  },
  [Enum_DynamicType.PropPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.PropPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetPropPresetConfig
  },
  [Enum_DynamicType.ArmedAIAnimationPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.ArmedAIAnimationPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetArmedAIAnimationPresetConfig,
    CanSelectCheckHandle = function(PresetValue, uPresetDesc)
      print(bWriteLog and "CanSelectCheckHandle ReceiveBlockyluaPresetSelectCheck PresetValue:" .. tostring(PresetValue) .. " uPresetDesc:" .. tostring(uPresetDesc))
      return CreativeDynamicPresetDescConfig.CustomAssetSelectCheck(PresetValue, uPresetDesc)
    end
  },
  [Enum_DynamicType.PropShopPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.PropShopPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetShopPresetConfig
  },
  [Enum_DynamicType.CustomTLogEventNamePreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.CustomTLogEventNamePreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetCustomTLogEventNamePresetConfig
  },
  [Enum_DynamicType.PropPreset_Count] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.PropPreset_Count,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetPropPreset_CountConfig
  },
  [Enum_DynamicType.ActorPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.ActorPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetActorPresetConfig
  },
  [Enum_DynamicType.ComponentPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.ComponentPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetComponentPresetConfig
  },
  [Enum_DynamicType.ModelPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.ModelPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetModelPresetConfig
  },
  [Enum_DynamicType.SkeletalModelPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.SkeletalModelPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetSkeletalModelPresetConfig,
    CanSelectCheckHandle = function(PresetValue, uPresetDesc)
      print(bWriteLog and "CanSelectCheckHandle SkeletalModelPreset ReceiveBlockyluaPresetSelectCheck PresetValue:" .. tostring(PresetValue) .. " uPresetDesc:" .. tostring(uPresetDesc))
      return CreativeDynamicPresetDescConfig.CustomAssetSelectCheck(PresetValue, uPresetDesc)
    end
  },
  [Enum_DynamicType.SkeletalAnimPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.SkeletalAnimPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetSkeletalAnimPresetConfig
  },
  [Enum_DynamicType.AnimationGraphPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.AnimationGraphPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetAnimationGraphPresetConfig
  },
  [Enum_DynamicType.GameplayButtonPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.GameplayButtonPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetGameplayButtonPresetConfig
  },
  [Enum_DynamicType.UMGResPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.UMGResPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetUMGResPresetDescConfigs,
    CanSelectCheckHandle = function(PresetValue, uPresetDesc)
      print(bWriteLog and "CanSelectCheckHandle UMGResPreset ReceiveBlockyluaPresetSelectCheck PresetValue:" .. tostring(PresetValue) .. " uPresetDesc:" .. tostring(uPresetDesc))
      return CreativeDynamicPresetDescConfig.CustomAssetSelectCheck(PresetValue, uPresetDesc)
    end
  },
  [Enum_DynamicType.UMGCanvasPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.UMGCanvasPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetUMGCanvasPresetDescConfigs
  },
  [Enum_DynamicType.CreativeGroupAsset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.CreativeGroupAsset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetCreativeGroupAssetPresetDescConfigs,
    CanSelectCheckHandle = function(PresetValue, uPresetDesc)
      print(bWriteLog and "CanSelectCheckHandle CreativeGroupAsset ReceiveBlockyluaPresetSelectCheck PresetValue:" .. tostring(PresetValue) .. " uPresetDesc:" .. tostring(uPresetDesc))
      return CreativeDynamicPresetDescConfig.CustomAssetSelectCheck(PresetValue, uPresetDesc)
    end
  },
  [Enum_DynamicType.NativeControlTypePreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.NativeControlTypePreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetNativeControlTypePresetConfig
  },
  [Enum_DynamicType.TriggerAreaPreset] = {
    FullyStaticConfig = false,
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.TriggerAreaPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetTriggerAreaPresetDescConfigs
  },
  [Enum_DynamicType.LevelPreset] = {
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.LevelPreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetLevelPresetConfig
  },
  [Enum_DynamicType.TeamTypePreset] = {
    FullyStaticConfig = true,
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.TeamTypePreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetTeamTypePresetDescConfigs
  },
  [Enum_DynamicType.ProfessionTypePreset] = {
    FullyStaticConfig = true,
    Catetory = Enum_DynamicTypeCatetory.Preset,
    VariableTypeName = Enum_VariableTypeName.ProfessionTypePreset,
    PresetDescsGetHandle = CreativeDynamicPresetDescConfig.GetProfessionTypePresetDescConfigs
  }
}

function CreativeDynamicPresetDescConfig.GetPresetTagsByAssetId(AssetID)
  local Tags = {}
  local assetCfg = CDataTable.GetTableData("UGCAssetConfig", AssetID)
  if assetCfg then
    for key, Tag in pairs(assetCfg.Tags_a) do
      table.insert(Tags, Tag)
    end
  end
  return Tags
end

function CreativeDynamicPresetDescConfig.GetDynamicTypeByVariableTypeName(VariableTypeName)
  for DynamicType, DynamicTypeConfig in pairs(CreativeDynamicPresetDescConfig.AllDynamicTypeConfigs) do
    if DynamicTypeConfig.VariableTypeName == VariableTypeName then
      return DynamicType
    end
  end
  return nil
end

function CreativeDynamicPresetDescConfig.CheckCanShowFilterBtn(TypeName)
  local TagConfigs = CDataTable.GetTable("UGCAssetTagConfig")
  if TagConfigs then
    for key, value in pairs(TagConfigs) do
      if value.PresetType == TypeName then
        return true
      end
    end
  end
  return false
end

function CreativeDynamicPresetDescConfig.GetPresetParamsPresetValue(AssetID, ParamName)
  if AssetID == nil or ParamName == nil then
    return ""
  end
  return "--[[" .. AssetID .. "]]\"" .. ParamName .. "\""
end

function CreativeDynamicPresetDescConfig.GetGameDeviceParameterPresetValue(AssetID, ParamKey)
  if AssetID == nil or ParamKey == nil then
    return ""
  end
  return "--[[" .. AssetID .. "]]\"" .. ParamKey .. "\""
end

function CreativeDynamicPresetDescConfig.GetPlayerCharacterVariablePresetValue(VariableName)
  if VariableName == nil then
    return ""
  end
  return "\"" .. VariableName .. "\""
end

function CreativeDynamicPresetDescConfig.GetPresetParamsIsCustomVar(PresetData, EditParamem)
  if EditParamem.CustomVarVisable ~= true then
    return false
  end
  local EditCodeOwnerID = EditParamem.EditCodeOwnerID
  if EditCodeOwnerID <= 0 then
    return false
  end
  if EditCodeOwnerID ~= PresetData.AssetId then
    return false
  end
  return true
end

function CreativeDynamicPresetDescConfig.GetPresetParamsType(CustomAttributes)
  local CreativeCustomPresetDefine = require("GameLua.Mod.CreativeBase.Gameplay.Config.Asset.Common.CreativeCustomPresetDefine")
  if CreativeCustomPresetDefine.EAttributeTypeToVarType[CustomAttributes.Type] ~= nil then
    return CreativeCustomPresetDefine.EAttributeTypeToVarType[CustomAttributes.Type]
  end
  return ""
end

function CreativeDynamicPresetDescConfig.CallPresetDescsGetHandle(GetHandle, OutHandle, bIsDs, EditParamem, GetParamem, bIsScriptGenerator, ...)
  local PresetDescConfigs
  if GetHandle then
    local OutPresetDescs = GetHandle(bIsDs, EditParamem, GetParamem, bIsScriptGenerator)
    if OutPresetDescs then
      PresetDescConfigs = OutPresetDescs
    end
  end
  OutHandle(PresetDescConfigs, ...)
  CreativeDynamicPresetDescConfig.ReturnPresetDescInfos(PresetDescConfigs)
end

function CreativeDynamicPresetDescConfig.GetCustomSkillPresetDescConfigsFunc(DynamicType)
  local OutPresetDescs = _TablePool:Get()
  local ESkillIconStatus = import("ESkillIconStatus")
  local GamePlayTools = require("GameLua.Mod.BaseMod.Common.GamePlayTools")
  local SkillLuaConfigs = GamePlayTools.GetCurrentConfig("SkillConfig")
  local CreativeCSConfig_Skill = require("GameLua.Mod.CreativeBase.Gameplay.CustomSkill.Config.CreativeCSConfig_Skill")
  
  local function IsValidSkillTemplateTypeFunc(TemplateSkillID, DynamicType)
    if DynamicType == Enum_DynamicType.SkillPreset then
      return true
    end
    if not TemplateSkillID then
      return false
    end
    if DynamicType == Enum_DynamicType.EmptySkillPreset and TemplateSkillID == CreativeCSConfig_Skill.EmptyTemplateSkillID then
      return true
    end
    if DynamicType == Enum_DynamicType.ThrowSkillPreset and (TemplateSkillID == CreativeCSConfig_Skill.ThrowReadyTemplateSkillID or TemplateSkillID == CreativeCSConfig_Skill.ThrowTemplateSkillID) then
      return true
    end
    if DynamicType == Enum_DynamicType.BuildSkillPreset and TemplateSkillID == CreativeCSConfig_Skill.BuildTemplateSkillID then
      return true
    end
    return false
  end
  
  local CreativeCustomSkillSubsystem = SubsystemMgr:Get("CreativeCustomSkillSubsystem")
  local CreativeCSConfig_Skill = require("GameLua.Mod.CreativeBase.Gameplay.CustomSkill.Config.CreativeCSConfig_Skill")
  if CreativeCustomSkillSubsystem then
    local CustomSkillList = CreativeCustomSkillSubsystem:GetCustomSkillList()
    for i, CustomSkill in ipairs(CustomSkillList) do
      local SkillConfig = CreativeCSConfig_Skill.Templates[CustomSkill.SkillId] or CreativeCSConfig_Skill.Templates[CustomSkill.TemplateId]
      local TemplateSkillID
      if SkillConfig then
        TemplateSkillID = SkillConfig.TemplateID or SkillConfig.SkillID
      end
      if IsValidSkillTemplateTypeFunc(TemplateSkillID, DynamicType) then
        local NewPresetDesc = CreativeDynamicPresetDescConfig.GetPresetDescInfo()
        NewPresetDesc.PresetValue = CustomSkill.SkillId
        local CreativeCustomSkill_Util = require("GameLua.Mod.CreativeBase.Gameplay.CustomSkill.CreativeCustomSkill_Util")
        NewPresetDesc.PresetTitle = CreativeCustomSkill_Util.GetSkillName(CustomSkill.SkillName, CustomSkill.SkillId, CustomSkill.TemplateId)
        local IconPath
        if CustomSkill.SkillIcon > 0 then
          local CreativeModeSelectorIconConfig = require("GameLua.Mod.CreativeBase.Gameplay.Config.CreativeModeSelectorIconConfig")
          IconPath = CreativeModeSelectorIconConfig.GetTexturePathById(CustomSkill.SkillIcon)
        else
          local SkillLuaConfig = SkillLuaConfigs[CustomSkill.TemplateId]
          if SkillLuaConfig and SkillLuaConfig.SkillWidgetParams and SkillLuaConfig.SkillWidgetParams.SkillIcon then
            local IconParam = SkillLuaConfig.SkillWidgetParams.SkillIcon[ESkillIconStatus.IconBtnNormal]
            if type(IconParam) == "string" then
              IconPath = IconParam
            elseif type(IconParam) == "table" then
              IconPath = IconParam.IconPath
            end
          else
            IconPath = "/Game/UMG/Texture_200/Atlas/CreativeMode/Frames/Tab_Icon_Delete_png.Tab_Icon_Delete_png"
          end
        end
        NewPresetDesc.PresetIcon = CreativeDynamicPresetDescConfig.GetIconName(IconPath)
        NewPresetDesc.OverrideCatetory = Enum_SkillPresetCatetory[3]
        NewPresetDesc.ResInfo = _TablePool:Get()
        NewPresetDesc.ResInfo.AssetIDs = _TablePool:Get()
        table.insert(NewPresetDesc.ResInfo.AssetIDs, 3101028)
        NewPresetDesc.ResInfo.ResIDs = _TablePool:Get()
        NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill] = _TablePool:Get()
        table.insert(NewPresetDesc.ResInfo.ResIDs[CreativeGlobalDefine.ResType.Skill], NewPresetDesc.PresetValue)
        local ResMap, _ = CreativeCustomSkillSubsystem:GetOneDependsBySkillID(NewPresetDesc.PresetValue)
        if ResMap then
          for ResType, ResList in pairs(ResMap) do
            if NewPresetDesc.ResInfo.ResIDs[ResType] == nil then
              NewPresetDesc.ResInfo.ResIDs[ResType] = {}
            end
            for _, ResID in pairs(ResList) do
              table.insert(NewPresetDesc.ResInfo.ResIDs[ResType], ResID)
            end
          end
        end
        table.insert(OutPresetDescs, NewPresetDesc)
      end
    end
  end
  return OutPresetDescs
end

CreativeDynamicPresetDescConfig.LatestPresetCacheDynamicType = {
  [Enum_DynamicType.CreativeInstance] = true,
  [Enum_DynamicType.CustomUIInstance] = true,
  [Enum_DynamicType.UMGCanvasPreset] = true,
  [Enum_DynamicType.PlayerCustomVar_Number] = true,
  [Enum_DynamicType.PlayerCustomVar_Int] = true,
  [Enum_DynamicType.PlayerCustomVar_Bool] = true,
  [Enum_DynamicType.PlayerCustomVar_String] = true,
  [Enum_DynamicType.GlobalCustomVar_Number] = true,
  [Enum_DynamicType.GlobalCustomVar_Int] = true,
  [Enum_DynamicType.GlobalCustomVar_Bool] = true,
  [Enum_DynamicType.GlobalCustomVar_String] = true
}
return CreativeDynamicPresetDescConfig
