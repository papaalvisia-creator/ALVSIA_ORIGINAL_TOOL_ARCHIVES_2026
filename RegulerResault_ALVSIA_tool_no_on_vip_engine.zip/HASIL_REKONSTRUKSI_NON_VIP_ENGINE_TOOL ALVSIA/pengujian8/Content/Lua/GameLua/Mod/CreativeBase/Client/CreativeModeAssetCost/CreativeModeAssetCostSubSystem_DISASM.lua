.version	5.3

.format	0
.int_size	4
.size_t_size	4
.instruction_size	4
.integer_format	8
.float_format	8
.endianness	LITTLE

.function	main

.source	null
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	1
.maxstacksize	81

.upvalue	"_ENV"	0	true

.constant	k0	42
.constant	k1	254
.constant	k2	79
.constant	k3	48
.constant	k4	160
.constant	k5	196
.constant	k6	47
.constant	k7	32
.constant	k8	190
.constant	k9	71
.constant	k10	81
.constant	k11	29
.constant	k12	49
.constant	k13	222
.constant	k14	65
.constant	k15	87
.constant	k16	"require"
.constant	k17	"table"
.constant	k18	"concat"
.constant	k19	106
.constant	k20	185
.constant	k21	103
.constant	k22	111
.constant	k23	19
.constant	k24	143
.constant	k25	238
.constant	k26	12
.constant	k27	54
.constant	k28	8
.constant	k29	9
.constant	k30	157
.constant	k31	169
.constant	k32	129
.constant	k33	1
.constant	k34	145
.constant	k35	55
.constant	k36	237
.constant	k37	149
.constant	k38	127
.constant	k39	14
.constant	k40	60
.constant	k41	63
.constant	k42	36
.constant	k43	132
.constant	k44	180
.constant	k45	214
.constant	k46	41
.constant	k47	27
.constant	k48	173
.constant	k49	231
.constant	k50	135
.constant	k51	3
.constant	k52	155
.constant	k53	120
.constant	k54	66
.constant	k55	18
.constant	k56	182
.constant	k57	20
.constant	k58	37
.constant	k59	23
.constant	k60	140
.constant	k61	253
.constant	k62	184
.constant	k63	137
.constant	k64	13
.constant	k65	189
.constant	k66	221
.constant	k67	150
.constant	k68	39
.constant	k69	17
.constant	k70	183
.constant	k71	163
.constant	k72	95
.constant	k73	107
.constant	k74	74
.constant	k75	16
.constant	k76	139
.constant	k77	141
.constant	k78	46
.constant	k79	61
.constant	k80	62
.constant	k81	45
.constant	k82	148
.constant	k83	230
.constant	k84	6
.constant	k85	56
.constant	k86	43
.constant	k87	138
.constant	k88	234
.constant	k89	243
.constant	k90	172
.constant	k91	178
.constant	k92	217
.constant	k93	44
.constant	k94	59
.constant	k95	153
.constant	k96	"import"
.constant	k97	104
.constant	k98	5
.constant	k99	251
.constant	k100	154
.constant	k101	161
.constant	k102	51
.constant	k103	255
.constant	k104	35
.constant	k105	126
.constant	k106	52
.constant	k107	134
.constant	k108	177
.constant	k109	130
.constant	k110	40
.constant	k111	166
.constant	k112	250
.constant	k113	91
.constant	k114	121
.constant	k115	70
.constant	k116	192
.constant	k117	131
.constant	k118	187
.constant	k119	165
.constant	k120	219
.constant	k121	33
.constant	k122	38
.constant	k123	11
.constant	k124	249
.constant	k125	164
.constant	k126	15
.constant	k127	156
.constant	k128	30
.constant	k129	142
.constant	k130	246
.constant	k131	191
.constant	k132	21
.constant	k133	241
.constant	k134	158
.constant	k135	174
.constant	k136	225
.constant	k137	"GetDefaultGridLevelsConfig"
.constant	k138	"CellWidth"
.constant	k139	10000
.constant	k140	100
.constant	k141	0.5
.constant	k142	"X"
.constant	k143	0
.constant	k144	"Y"
.constant	k145	"Z"
.constant	k146	"FourMaps_Main"
.constant	k147	"Baltic_Main"
.constant	k148	2
.constant	k149	"Creative_Mid_Flat_100_Main"
.constant	k150	"Creative_Mid_Flat_500_Main"
.constant	k151	4
.constant	k152	"Creative_Main"
.constant	k153	0.036
.constant	k154	"FLinearColor"
.constant	k155	"FColor"
.constant	k156	1000
.constant	k157	117
.constant	k158	252
.constant	k159	76
.constant	k160	77
.constant	k161	247
.constant	k162	206
.constant	k163	102
.constant	k164	96
.constant	k165	31
.constant	k166	128
.constant	k167	233
.constant	k168	"FromSRGBColor"
.constant	k169	248
.constant	k170	204
.constant	k171	207
.constant	k172	"FSlateColor"
.constant	k173	"math"
.constant	k174	"OnUGCSubSystemInit"
.constant	k175	"OnInitEditor"
.constant	k176	"OnReleaseEditor"
.constant	k177	"OnInitGame"
.constant	k178	"_RegisterApplyFPSLimitListeners"
.constant	k179	"OnReleaseGame"
.constant	k180	"OnUGCSubSystemRelease"
.constant	k181	"GetInstanceManager"
.constant	k182	"GetAssetManager"
.constant	k183	"InitCostSetting"
.constant	k184	"OnGameTypeChangePreHandle"
.constant	k185	"ExtremeModeChange"
.constant	k186	"UnlimitedModeChange"
.constant	k187	"_OnGameParameterLoadedApplyFPSLimit"
.constant	k188	"SetAssetCostEnable"
.constant	k189	"IsAssetCostEnable"
.constant	k190	"AddIgnoreInstanceID"
.constant	k191	"RemoveIgnoreInstanceID"
.constant	k192	"GetCellIndex"
.constant	k193	"GetCurBuildingLocationAndAssetID"
.constant	k194	"GetInstanceEditSubSystem"
.constant	k195	"GetBuildSubSystem"
.constant	k196	"RecordRepeatedCompute"
.constant	k197	"RemoveRepeatedCompute"
.constant	k198	"ResetRepeatedComputeCostMap"
.constant	k199	"CheckHasRepeatedCompute"
.constant	k200	"UniqueAssetId"
.constant	k201	"CalcGroupAssetCost"
.constant	k202	"CalcDestructibleMeshCost"
.constant	k203	"GetDeltaCostByAssetId"
.constant	k204	"GetPixelAssetDelatCostInAffectedGrid"
.constant	k205	"GetCurAssetCost"
.constant	k206	"UnlimitAssetCost"
.constant	k207	"GetCurAssetCostMax"
.constant	k208	"InitInstanceCost"
.constant	k209	"GetGridAssetCost"
.constant	k210	"GetGridAssetCostByAxisIndex"
.constant	k211	"GetGridAssetCostByIndex"
.constant	k212	"UpdateGridAssetCost"
.constant	k213	"ClearDelayUpdateGridAssetCostTimer"
.constant	k214	"DelayCalGridAssetCost"
.constant	k215	"CalGridAssetCost"
.constant	k216	"UpdateAffectedGridAssetCost"
.constant	k217	"GetNearCellIndexList"
.constant	k218	"CalGridNoAlwaysLoadAssetCost"
.constant	k219	"CalGridNoAlwaysLoadAssetCostDelta"
.constant	k220	"CalAlwaysLoadAssetCost"
.constant	k221	"InitMapInitAssetCost"
.constant	k222	"GetMapInitAssetCost"
.constant	k223	"ClearInstanceCostInfoMap"
.constant	k224	"GetInstanceCostInfo"
.constant	k225	"TryGetDynamicUserActorLiveCost"
.constant	k226	"AddOrUpdateInstanceCostInfo"
.constant	k227	"RemoveInstanceCostInfo"
.constant	k228	"GetInstanceAssetCost"
.constant	k229	"CacheMaximumCost"
.constant	k230	"GetMaximumCost"
.constant	k231	"AllCellAssetCostCheck"
.constant	k232	"GetAffectedGrid"
.constant	k233	"CheckCurCellAssetCostCanPlace"
.constant	k234	"CheckCurCellAssetCostCanModifyMat"
.constant	k235	"PlaceAssetCostCheck"
.constant	k236	"GetAssetCostCellSize"
.constant	k237	"GetInstanceDefaultCost"
.constant	k238	"GetInstanceDefaultMaxCost"
.constant	k239	"_OnCustomUIEditorEnter"
.constant	k240	"_OnCustomUIEditorExit"
.constant	k241	"_MarkCustomUICostDirty"
.constant	k242	"_RecomputeCustomUICost"
.constant	k243	"OnInstanceAdded"
.constant	k244	"OnInstanceRemoved"
.constant	k245	"OnInstanceChanged"
.constant	k246	"OnGroupManipulatorChanged"
.constant	k247	"OnObjectGroupChanged"
.constant	k248	"OnObjectInstanceCostChanged"
.constant	k249	"OnInstanceIsPrefabChangeHandle"
.constant	k250	"OnInstanceTransformChangeHandle"
.constant	k251	"OnInstanceMaterialIdChangeHandle"
.constant	k252	L"OnInstanceDestructibleMeshParamChangeHandle"
.constant	k253	"InstanceChangedUpdate"
.constant	k254	"GetCurGridInstances"
.constant	k255	"AssetCountLimitInstanceChange"
.constant	k256	"CheckAssetCountLimitPlace"
.constant	k257	"CheckAssetCountLimitPlaceByInstance"
.constant	k258	"GetAssetCostColor"
.constant	k259	"GetGridAssetCostColorByIndex"
.constant	k260	"GridAssetCostFColor"
.constant	k261	"BarCostColor"
.constant	k262	"BarCostColorByKey"
.constant	k263	"GetLevelPercents"
.constant	k264	"GetTexGridPixelNum"
.constant	k265	"GetGridTexture"
.constant	k266	"GetGridColors"
.constant	k267	"ModifyAllGridColor"
.constant	k268	"ModifyGridColor"
.constant	k269	"DelayUpdateGridColors"
.constant	k270	"ClearDelayUpdateGridColorsTimer"
.constant	k271	"UpdateGridColors"
.constant	k272	"SetGridAreaToFull"
.constant	k273	"GetAllGroupManipulator"
.constant	k274	"InitGroupManipulatorMutexLists"
.constant	k275	"SetGroupManipulatorMutexList"
.constant	k276	"IsInMutexList"
.constant	k277	"CalcMutexListCost"
.constant	k278	"IsInstanceNoNeed"
.constant	k279	"IsExtremeMap"
.constant	k280	"GetMapCellCount"
.constant	k281	"GetMapCellSize"
.constant	k282	"GetMapCenterPos"
.constant	k283	"GetMapCellHalfCount"
.constant	k284	"CacheEntireMapGridWidget"
.constant	k285	"GetEntireMapStatShow"
.constant	k286	"SwitchEntireMapStatShow"
.constant	k287	"IsPlayTest"
.constant	k288	"require"
.constant	k289	78
.constant	k290	180
.constant	k291	107
.constant	k292	39
.constant	k293	80
.constant	k294	"table"
.constant	k295	"concat"
.constant	k296	106
.constant	k297	185
.constant	k298	103
.constant	k299	49
.constant	k300	111
.constant	k301	19
.constant	k302	143
.constant	k303	238
.constant	k304	12
.constant	k305	54
.constant	k306	8
.constant	k307	9
.constant	k308	157
.constant	k309	169
.constant	k310	129
.constant	k311	1
.constant	k312	145
.constant	k313	55
.constant	k314	237
.constant	k315	149
.constant	k316	127
.constant	k317	14
.constant	k318	29
.constant	k319	60
.constant	k320	63
.constant	k321	36
.constant	k322	132
.constant	k323	214
.constant	k324	57
.constant	k325	161
.constant	k326	53
.constant	k327	247
.constant	k328	147
.constant	k329	89
.constant	k330	189
.constant	k331	122
.constant	k332	96
.constant	k333	20
.constant	k334	139
.constant	k335	48
.constant	k336	26
.constant	k337	7
.constant	k338	43
.constant	k339	156
.constant	k340	234
.constant	k341	142
.constant	k342	24
.constant	k343	23
.constant	k344	170
.constant	k345	37
.constant	k346	11
.constant	k347	34

.line	0	newtable      r0    16     0
.line	0	loadk         r1    k0 ; k0 = 42
.line	0	loadk         r2    k1 ; k1 = 254
.line	0	loadk         r3    k2 ; k2 = 79
.line	0	loadk         r4    k3 ; k3 = 48
.line	0	loadk         r5    k4 ; k4 = 160
.line	0	loadk         r6    k5 ; k5 = 196
.line	0	loadk         r7    k6 ; k6 = 47
.line	0	loadk         r8    k7 ; k7 = 32
.line	0	loadk         r9    k8 ; k8 = 190
.line	0	loadk        r10    k9 ; k9 = 71
.line	0	loadk        r11   k10 ; k10 = 81
.line	0	loadk        r12   k11 ; k11 = 29
.line	0	loadk        r13   k12 ; k12 = 49
.line	0	loadk        r14   k13 ; k13 = 222
.line	0	loadk        r15   k14 ; k14 = 65
.line	0	loadk        r16   k15 ; k15 = 87
.line	0	setlist       r0    16     1
.line	0	closure       r1    f0
.line	0	newtable      r2     0     0
.line	0	gettabup      r3    u0   k16 ; k16 = "require"
.line	0	gettabup      r4    u0   k17 ; k17 = "table"
.line	0	gettable      r4    r4   k18 ; k18 = "concat"
.line	0	newtable      r5     1     0
.line	0	move          r6    r1
.line	0	loadk         r7   k19 ; k19 = 106
.line	0	loadk         r8   k20 ; k20 = 185
.line	0	loadk         r9   k21 ; k21 = 103
.line	0	loadk        r10   k12 ; k12 = 49
.line	0	loadk        r11   k22 ; k22 = 111
.line	0	loadk        r12   k23 ; k23 = 19
.line	0	loadk        r13   k24 ; k24 = 143
.line	0	loadk        r14   k25 ; k25 = 238
.line	0	loadk        r15   k26 ; k26 = 12
.line	0	loadk        r16   k27 ; k27 = 54
.line	0	loadk        r17   k28 ; k28 = 8
.line	0	loadk        r18   k22 ; k22 = 111
.line	0	loadk        r19   k29 ; k29 = 9
.line	0	loadk        r20   k27 ; k27 = 54
.line	0	loadk        r21   k30 ; k30 = 157
.line	0	loadk        r22   k25 ; k25 = 238
.line	0	loadk        r23   k31 ; k31 = 169
.line	0	loadk        r24   k32 ; k32 = 129
.line	0	loadk        r25   k26 ; k26 = 12
.line	0	loadk        r26   k33 ; k33 = 1
.line	0	loadk        r27   k34 ; k34 = 145
.line	0	loadk        r28   k35 ; k35 = 55
.line	0	loadk        r29   k36 ; k36 = 237
.line	0	loadk        r30   k37 ; k37 = 149
.line	0	loadk        r31   k38 ; k38 = 127
.line	0	loadk        r32   k39 ; k39 = 14
.line	0	loadk        r33   k11 ; k11 = 29
.line	0	loadk        r34   k40 ; k40 = 60
.line	0	loadk        r35   k41 ; k41 = 63
.line	0	loadk        r36   k42 ; k42 = 36
.line	0	loadk        r37   k43 ; k43 = 132
.line	0	loadk        r38    k1 ; k1 = 254
.line	0	loadk        r39   k44 ; k44 = 180
.line	0	loadk        r40   k45 ; k45 = 214
.line	0	loadk        r41   k46 ; k46 = 41
.line	0	loadk        r42   k47 ; k47 = 27
.line	0	loadk        r43   k48 ; k48 = 173
.line	0	loadk        r44    k7 ; k7 = 32
.line	0	loadk        r45   k49 ; k49 = 231
.line	0	loadk        r46   k50 ; k50 = 135
.line	0	call          r6    41     2
.line	0	move          r7    r1
.line	0	loadk         r8   k51 ; k51 = 3
.line	0	loadk         r9   k52 ; k52 = 155
.line	0	loadk        r10   k53 ; k53 = 120
.line	0	loadk        r11   k12 ; k12 = 49
.line	0	loadk        r12   k54 ; k54 = 66
.line	0	loadk        r13   k55 ; k55 = 18
.line	0	loadk        r14   k50 ; k50 = 135
.line	0	loadk        r15   k56 ; k56 = 182
.line	0	loadk        r16   k42 ; k42 = 36
.line	0	loadk        r17   k57 ; k57 = 20
.line	0	loadk        r18   k51 ; k51 = 3
.line	0	loadk        r19   k58 ; k58 = 37
.line	0	loadk        r20    k6 ; k6 = 47
.line	0	loadk        r21   k59 ; k59 = 23
.line	0	loadk        r22   k60 ; k60 = 140
.line	0	loadk        r23   k61 ; k61 = 253
.line	0	loadk        r24   k62 ; k62 = 184
.line	0	loadk        r25   k63 ; k63 = 137
.line	0	loadk        r26   k59 ; k59 = 23
.line	0	loadk        r27   k64 ; k64 = 13
.line	0	loadk        r28   k65 ; k65 = 189
.line	0	loadk        r29   k12 ; k12 = 49
.line	0	loadk        r30   k66 ; k66 = 221
.line	0	loadk        r31   k67 ; k67 = 150
.line	0	loadk        r32   k27 ; k27 = 54
.line	0	call          r7    26     0
.line	0	setlist       r5     0     1
.line	0	call          r4     2     2
.line	0	call          r3     2     2
.line	0	gettabup      r4    u0   k16 ; k16 = "require"
.line	0	gettabup      r5    u0   k17 ; k17 = "table"
.line	0	gettable      r5    r5   k18 ; k18 = "concat"
.line	0	newtable      r6     1     0
.line	0	move          r7    r1
.line	0	loadk         r8   k19 ; k19 = 106
.line	0	loadk         r9   k20 ; k20 = 185
.line	0	loadk        r10   k21 ; k21 = 103
.line	0	loadk        r11   k12 ; k12 = 49
.line	0	loadk        r12   k22 ; k22 = 111
.line	0	loadk        r13   k23 ; k23 = 19
.line	0	loadk        r14   k24 ; k24 = 143
.line	0	loadk        r15   k25 ; k25 = 238
.line	0	loadk        r16   k26 ; k26 = 12
.line	0	loadk        r17   k27 ; k27 = 54
.line	0	loadk        r18   k28 ; k28 = 8
.line	0	loadk        r19   k22 ; k22 = 111
.line	0	loadk        r20   k29 ; k29 = 9
.line	0	loadk        r21   k27 ; k27 = 54
.line	0	loadk        r22   k30 ; k30 = 157
.line	0	loadk        r23   k25 ; k25 = 238
.line	0	loadk        r24   k31 ; k31 = 169
.line	0	loadk        r25   k32 ; k32 = 129
.line	0	loadk        r26   k26 ; k26 = 12
.line	0	loadk        r27   k33 ; k33 = 1
.line	0	loadk        r28   k34 ; k34 = 145
.line	0	loadk        r29   k35 ; k35 = 55
.line	0	loadk        r30   k36 ; k36 = 237
.line	0	loadk        r31   k37 ; k37 = 149
.line	0	loadk        r32   k38 ; k38 = 127
.line	0	loadk        r33   k39 ; k39 = 14
.line	0	loadk        r34   k11 ; k11 = 29
.line	0	loadk        r35   k40 ; k40 = 60
.line	0	loadk        r36   k41 ; k41 = 63
.line	0	loadk        r37   k42 ; k42 = 36
.line	0	loadk        r38   k43 ; k43 = 132
.line	0	loadk        r39    k1 ; k1 = 254
.line	0	loadk        r40   k44 ; k44 = 180
.line	0	loadk        r41   k45 ; k45 = 214
.line	0	loadk        r42   k68 ; k68 = 39
.line	0	loadk        r43   k69 ; k69 = 17
.line	0	loadk        r44   k70 ; k70 = 183
.line	0	loadk        r45   k68 ; k68 = 39
.line	0	loadk        r46    k4 ; k4 = 160
.line	0	loadk        r47   k71 ; k71 = 163
.line	0	call          r7    41     2
.line	0	move          r8    r1
.line	0	loadk         r9   k72 ; k72 = 95
.line	0	loadk        r10   k65 ; k65 = 189
.line	0	loadk        r11   k73 ; k73 = 107
.line	0	loadk        r12    k7 ; k7 = 32
.line	0	loadk        r13   k74 ; k74 = 74
.line	0	loadk        r14   k75 ; k75 = 16
.line	0	loadk        r15   k76 ; k76 = 139
.line	0	loadk        r16   k77 ; k77 = 141
.line	0	loadk        r17   k78 ; k78 = 46
.line	0	loadk        r18   k79 ; k79 = 61
.line	0	loadk        r19   k29 ; k29 = 9
.line	0	loadk        r20   k57 ; k57 = 20
.line	0	loadk        r21   k80 ; k80 = 62
.line	0	loadk        r22   k81 ; k81 = 45
.line	0	loadk        r23   k82 ; k82 = 148
.line	0	loadk        r24   k83 ; k83 = 230
.line	0	loadk        r25   k31 ; k31 = 169
.line	0	loadk        r26   k34 ; k34 = 145
.line	0	call          r8    19     0
.line	0	setlist       r6     0     1
.line	0	call          r5     2     2
.line	0	call          r4     2     2
.line	0	gettabup      r5    u0   k16 ; k16 = "require"
.line	0	move          r6    r1
.line	0	loadk         r7   k19 ; k19 = 106
.line	0	loadk         r8   k20 ; k20 = 185
.line	0	loadk         r9   k21 ; k21 = 103
.line	0	loadk        r10   k12 ; k12 = 49
.line	0	loadk        r11   k22 ; k22 = 111
.line	0	loadk        r12   k23 ; k23 = 19
.line	0	loadk        r13   k24 ; k24 = 143
.line	0	loadk        r14   k25 ; k25 = 238
.line	0	loadk        r15   k84 ; k84 = 6
.line	0	loadk        r16   k85 ; k85 = 56
.line	0	loadk        r17   k33 ; k33 = 1
.line	0	loadk        r18   k42 ; k42 = 36
.line	0	loadk        r19   k29 ; k29 = 9
.line	0	loadk        r20   k86 ; k86 = 43
.line	0	loadk        r21   k87 ; k87 = 138
.line	0	loadk        r22   k88 ; k88 = 234
.line	0	loadk        r23   k89 ; k89 = 243
.line	0	loadk        r24   k90 ; k90 = 172
.line	0	loadk        r25   k47 ; k47 = 27
.line	0	loadk        r26   k75 ; k75 = 16
.line	0	loadk        r27   k91 ; k91 = 178
.line	0	loadk        r28   k53 ; k53 = 120
.line	0	loadk        r29   k92 ; k92 = 217
.line	0	loadk        r30   k34 ; k34 = 145
.line	0	loadk        r31   k40 ; k40 = 60
.line	0	loadk        r32   k93 ; k93 = 44
.line	0	loadk        r33   k26 ; k26 = 12
.line	0	loadk        r34   k79 ; k79 = 61
.line	0	loadk        r35   k94 ; k94 = 59
.line	0	loadk        r36   k81 ; k81 = 45
.line	0	loadk        r37   k90 ; k90 = 172
.line	0	loadk        r38    k1 ; k1 = 254
.line	0	loadk        r39   k20 ; k20 = 185
.line	0	loadk        r40   k95 ; k95 = 153
.line	0	call          r6    35     2
.line	0	call          r5     2     2
.line	0	gettabup      r6    u0   k96 ; k96 = "import"
.line	0	move          r7    r1
.line	0	loadk         r8   k97 ; k97 = 104
.line	0	loadk         r9   k52 ; k52 = 155
.line	0	loadk        r10   k53 ; k53 = 120
.line	0	loadk        r11   k12 ; k12 = 49
.line	0	loadk        r12   k54 ; k54 = 66
.line	0	loadk        r13   k55 ; k55 = 18
.line	0	loadk        r14   k50 ; k50 = 135
.line	0	loadk        r15   k56 ; k56 = 182
.line	0	loadk        r16   k42 ; k42 = 36
.line	0	loadk        r17   k57 ; k57 = 20
.line	0	loadk        r18   k51 ; k51 = 3
.line	0	loadk        r19   k58 ; k58 = 37
.line	0	loadk        r20    k6 ; k6 = 47
.line	0	loadk        r21   k98 ; k98 = 5
.line	0	loadk        r22   k52 ; k52 = 155
.line	0	loadk        r23   k99 ; k99 = 251
.line	0	loadk        r24   k91 ; k91 = 178
.line	0	loadk        r25  k100 ; k100 = 154
.line	0	loadk        r26   k46 ; k46 = 41
.line	0	loadk        r27   k75 ; k75 = 16
.line	0	loadk        r28  k101 ; k101 = 161
.line	0	loadk        r29  k102 ; k102 = 51
.line	0	loadk        r30  k103 ; k103 = 255
.line	0	loadk        r31   k30 ; k30 = 157
.line	0	loadk        r32   k85 ; k85 = 56
.line	0	loadk        r33   k68 ; k68 = 39
.line	0	loadk        r34   k47 ; k47 = 27
.line	0	loadk        r35   k98 ; k98 = 5
.line	0	loadk        r36  k104 ; k104 = 35
.line	0	loadk        r37   k42 ; k42 = 36
.line	0	loadk        r38   k77 ; k77 = 141
.line	0	call          r7    32     2
.line	0	call          r6     2     2
.line	0	gettabup      r7    u0   k96 ; k96 = "import"
.line	0	move          r8    r1
.line	0	loadk         r9  k105 ; k105 = 126
.line	0	loadk        r10   k60 ; k60 = 140
.line	0	loadk        r11    k2 ; k2 = 79
.line	0	loadk        r12   k93 ; k93 = 44
.line	0	loadk        r13   k15 ; k15 = 87
.line	0	loadk        r14   k57 ; k57 = 20
.line	0	loadk        r15   k24 ; k24 = 143
.line	0	loadk        r16   k77 ; k77 = 141
.line	0	loadk        r17    k7 ; k7 = 32
.line	0	loadk        r18   k46 ; k46 = 41
.line	0	loadk        r19    k0 ; k0 = 42
.line	0	loadk        r20  k106 ; k106 = 52
.line	0	loadk        r21   k42 ; k42 = 36
.line	0	loadk        r22   k68 ; k68 = 39
.line	0	loadk        r23   k60 ; k60 = 140
.line	0	loadk        r24   k83 ; k83 = 230
.line	0	loadk        r25   k91 ; k91 = 178
.line	0	loadk        r26  k107 ; k107 = 134
.line	0	loadk        r27   k27 ; k27 = 54
.line	0	loadk        r28   k64 ; k64 = 13
.line	0	loadk        r29  k108 ; k108 = 177
.line	0	loadk        r30   k42 ; k42 = 36
.line	0	loadk        r31  k103 ; k103 = 255
.line	0	loadk        r32  k109 ; k109 = 130
.line	0	loadk        r33  k110 ; k110 = 40
.line	0	call          r8    26     2
.line	0	call          r7     2     2
.line	0	gettabup      r8    u0   k16 ; k16 = "require"
.line	0	gettabup      r9    u0   k17 ; k17 = "table"
.line	0	gettable      r9    r9   k18 ; k18 = "concat"
.line	0	newtable     r10     1     0
.line	0	move         r11    r1
.line	0	loadk        r12   k19 ; k19 = 106
.line	0	loadk        r13   k20 ; k20 = 185
.line	0	loadk        r14   k21 ; k21 = 103
.line	0	loadk        r15   k12 ; k12 = 49
.line	0	loadk        r16   k22 ; k22 = 111
.line	0	loadk        r17   k23 ; k23 = 19
.line	0	loadk        r18   k24 ; k24 = 143
.line	0	loadk        r19   k25 ; k25 = 238
.line	0	loadk        r20   k26 ; k26 = 12
.line	0	loadk        r21   k27 ; k27 = 54
.line	0	loadk        r22   k28 ; k28 = 8
.line	0	loadk        r23   k22 ; k22 = 111
.line	0	loadk        r24   k29 ; k29 = 9
.line	0	loadk        r25   k27 ; k27 = 54
.line	0	loadk        r26   k30 ; k30 = 157
.line	0	loadk        r27   k25 ; k25 = 238
.line	0	loadk        r28   k31 ; k31 = 169
.line	0	loadk        r29   k32 ; k32 = 129
.line	0	loadk        r30   k26 ; k26 = 12
.line	0	loadk        r31   k33 ; k33 = 1
.line	0	loadk        r32   k34 ; k34 = 145
.line	0	loadk        r33   k35 ; k35 = 55
.line	0	loadk        r34   k36 ; k36 = 237
.line	0	loadk        r35   k37 ; k37 = 149
.line	0	loadk        r36   k38 ; k38 = 127
.line	0	loadk        r37   k39 ; k39 = 14
.line	0	loadk        r38   k11 ; k11 = 29
.line	0	loadk        r39   k40 ; k40 = 60
.line	0	loadk        r40   k41 ; k41 = 63
.line	0	loadk        r41   k42 ; k42 = 36
.line	0	loadk        r42   k43 ; k43 = 132
.line	0	loadk        r43    k1 ; k1 = 254
.line	0	loadk        r44   k44 ; k44 = 180
.line	0	loadk        r45   k45 ; k45 = 214
.line	0	loadk        r46   k46 ; k46 = 41
.line	0	loadk        r47   k84 ; k84 = 6
.line	0	loadk        r48  k111 ; k111 = 166
.line	0	loadk        r49   k68 ; k68 = 39
.line	0	loadk        r50  k112 ; k112 = 250
.line	0	loadk        r51   k63 ; k63 = 137
.line	0	call         r11    41     2
.line	0	move         r12    r1
.line	0	loadk        r13  k113 ; k113 = 91
.line	0	loadk        r14   k65 ; k65 = 189
.line	0	loadk        r15    k9 ; k9 = 71
.line	0	loadk        r16   k94 ; k94 = 59
.line	0	loadk        r17    k9 ; k9 = 71
.line	0	loadk        r18   k51 ; k51 = 3
.line	0	loadk        r19   k31 ; k31 = 169
.line	0	loadk        r20  k101 ; k101 = 161
.line	0	loadk        r21   k93 ; k93 = 44
.line	0	loadk        r22   k40 ; k40 = 60
.line	0	loadk        r23    k6 ; k6 = 47
.line	0	loadk        r24   k68 ; k68 = 39
.line	0	loadk        r25   k81 ; k81 = 45
.line	0	call         r12    14     0
.line	0	setlist      r10     0     1
.line	0	call          r9     2     2
.line	0	call          r8     2     2
.line	0	gettabup      r9    u0   k16 ; k16 = "require"
.line	0	gettabup     r10    u0   k17 ; k17 = "table"
.line	0	gettable     r10   r10   k18 ; k18 = "concat"
.line	0	newtable     r11     1     0
.line	0	move         r12    r1
.line	0	loadk        r13   k19 ; k19 = 106
.line	0	loadk        r14   k20 ; k20 = 185
.line	0	loadk        r15   k21 ; k21 = 103
.line	0	loadk        r16   k12 ; k12 = 49
.line	0	loadk        r17   k22 ; k22 = 111
.line	0	loadk        r18   k23 ; k23 = 19
.line	0	loadk        r19   k24 ; k24 = 143
.line	0	loadk        r20   k25 ; k25 = 238
.line	0	loadk        r21   k26 ; k26 = 12
.line	0	loadk        r22   k27 ; k27 = 54
.line	0	loadk        r23   k28 ; k28 = 8
.line	0	loadk        r24   k22 ; k22 = 111
.line	0	loadk        r25   k29 ; k29 = 9
.line	0	loadk        r26   k27 ; k27 = 54
.line	0	loadk        r27   k30 ; k30 = 157
.line	0	loadk        r28   k25 ; k25 = 238
.line	0	loadk        r29   k31 ; k31 = 169
.line	0	loadk        r30   k32 ; k32 = 129
.line	0	loadk        r31   k26 ; k26 = 12
.line	0	loadk        r32   k33 ; k33 = 1
.line	0	loadk        r33   k34 ; k34 = 145
.line	0	loadk        r34   k35 ; k35 = 55
.line	0	loadk        r35   k36 ; k36 = 237
.line	0	loadk        r36   k37 ; k37 = 149
.line	0	loadk        r37   k38 ; k38 = 127
.line	0	loadk        r38   k39 ; k39 = 14
.line	0	loadk        r39   k11 ; k11 = 29
.line	0	loadk        r40   k40 ; k40 = 60
.line	0	loadk        r41   k41 ; k41 = 63
.line	0	loadk        r42   k42 ; k42 = 36
.line	0	loadk        r43   k43 ; k43 = 132
.line	0	loadk        r44    k1 ; k1 = 254
.line	0	loadk        r45   k44 ; k44 = 180
.line	0	loadk        r46   k45 ; k45 = 214
.line	0	loadk        r47   k46 ; k46 = 41
.line	0	loadk        r48   k47 ; k47 = 27
.line	0	loadk        r49   k48 ; k48 = 173
.line	0	loadk        r50    k7 ; k7 = 32
.line	0	loadk        r51   k49 ; k49 = 231
.line	0	loadk        r52   k50 ; k50 = 135
.line	0	call         r12    41     2
.line	0	move         r13    r1
.line	0	loadk        r14   k51 ; k51 = 3
.line	0	loadk        r15   k95 ; k95 = 153
.line	0	loadk        r16  k114 ; k114 = 121
.line	0	loadk        r17   k68 ; k68 = 39
.line	0	loadk        r18  k115 ; k115 = 70
.line	0	loadk        r19   k55 ; k55 = 18
.line	0	loadk        r20  k116 ; k116 = 192
.line	0	loadk        r21  k117 ; k117 = 131
.line	0	loadk        r22   k78 ; k78 = 46
.line	0	loadk        r23  k106 ; k106 = 52
.line	0	loadk        r24   k33 ; k33 = 1
.line	0	loadk        r25   k78 ; k78 = 46
.line	0	loadk        r26   k42 ; k42 = 36
.line	0	loadk        r27   k19 ; k19 = 106
.line	0	loadk        r28  k118 ; k118 = 187
.line	0	loadk        r29   k61 ; k61 = 253
.line	0	loadk        r30   k62 ; k62 = 184
.line	0	loadk        r31   k63 ; k63 = 137
.line	0	loadk        r32   k39 ; k39 = 14
.line	0	loadk        r33   k64 ; k64 = 13
.line	0	loadk        r34  k119 ; k119 = 165
.line	0	loadk        r35  k102 ; k102 = 51
.line	0	loadk        r36  k120 ; k120 = 219
.line	0	loadk        r37   k30 ; k30 = 157
.line	0	loadk        r38  k121 ; k121 = 33
.line	0	loadk        r39  k122 ; k122 = 38
.line	0	loadk        r40  k123 ; k123 = 11
.line	0	loadk        r41  k106 ; k106 = 52
.line	0	loadk        r42  k110 ; k110 = 40
.line	0	loadk        r43   k75 ; k75 = 16
.line	0	loadk        r44   k77 ; k77 = 141
.line	0	loadk        r45  k124 ; k124 = 249
.line	0	loadk        r46  k125 ; k125 = 164
.line	0	loadk        r47   k67 ; k67 = 150
.line	0	loadk        r48  k126 ; k126 = 15
.line	0	call         r13    36     0
.line	0	setlist      r11     0     1
.line	0	call         r10     2     2
.line	0	call          r9     2     2
.line	0	gettabup     r10    u0   k16 ; k16 = "require"
.line	0	gettabup     r11    u0   k17 ; k17 = "table"
.line	0	gettable     r11   r11   k18 ; k18 = "concat"
.line	0	newtable     r12     1     0
.line	0	move         r13    r1
.line	0	loadk        r14   k19 ; k19 = 106
.line	0	loadk        r15   k20 ; k20 = 185
.line	0	loadk        r16   k21 ; k21 = 103
.line	0	loadk        r17   k12 ; k12 = 49
.line	0	loadk        r18   k22 ; k22 = 111
.line	0	loadk        r19   k23 ; k23 = 19
.line	0	loadk        r20   k24 ; k24 = 143
.line	0	loadk        r21   k25 ; k25 = 238
.line	0	loadk        r22   k26 ; k26 = 12
.line	0	loadk        r23   k27 ; k27 = 54
.line	0	loadk        r24   k28 ; k28 = 8
.line	0	loadk        r25   k22 ; k22 = 111
.line	0	loadk        r26   k29 ; k29 = 9
.line	0	loadk        r27   k27 ; k27 = 54
.line	0	loadk        r28   k30 ; k30 = 157
.line	0	loadk        r29   k25 ; k25 = 238
.line	0	loadk        r30   k31 ; k31 = 169
.line	0	loadk        r31   k32 ; k32 = 129
.line	0	loadk        r32   k26 ; k26 = 12
.line	0	loadk        r33   k33 ; k33 = 1
.line	0	loadk        r34   k34 ; k34 = 145
.line	0	loadk        r35   k35 ; k35 = 55
.line	0	loadk        r36   k36 ; k36 = 237
.line	0	loadk        r37   k37 ; k37 = 149
.line	0	loadk        r38   k38 ; k38 = 127
.line	0	loadk        r39   k39 ; k39 = 14
.line	0	loadk        r40   k11 ; k11 = 29
.line	0	loadk        r41   k40 ; k40 = 60
.line	0	loadk        r42   k41 ; k41 = 63
.line	0	loadk        r43   k42 ; k42 = 36
.line	0	loadk        r44   k43 ; k43 = 132
.line	0	loadk        r45    k1 ; k1 = 254
.line	0	loadk        r46   k44 ; k44 = 180
.line	0	loadk        r47   k45 ; k45 = 214
.line	0	loadk        r48   k46 ; k46 = 41
.line	0	loadk        r49   k47 ; k47 = 27
.line	0	loadk        r50   k48 ; k48 = 173
.line	0	loadk        r51    k7 ; k7 = 32
.line	0	loadk        r52   k49 ; k49 = 231
.line	0	loadk        r53   k50 ; k50 = 135
.line	0	call         r13    41     2
.line	0	move         r14    r1
.line	0	loadk        r15   k51 ; k51 = 3
.line	0	loadk        r16   k95 ; k95 = 153
.line	0	loadk        r17  k114 ; k114 = 121
.line	0	loadk        r18   k68 ; k68 = 39
.line	0	loadk        r19  k115 ; k115 = 70
.line	0	loadk        r20   k55 ; k55 = 18
.line	0	loadk        r21  k116 ; k116 = 192
.line	0	loadk        r22  k117 ; k117 = 131
.line	0	loadk        r23   k78 ; k78 = 46
.line	0	loadk        r24  k106 ; k106 = 52
.line	0	loadk        r25   k33 ; k33 = 1
.line	0	loadk        r26   k78 ; k78 = 46
.line	0	loadk        r27   k42 ; k42 = 36
.line	0	loadk        r28   k19 ; k19 = 106
.line	0	loadk        r29  k118 ; k118 = 187
.line	0	loadk        r30   k61 ; k61 = 253
.line	0	loadk        r31   k62 ; k62 = 184
.line	0	loadk        r32   k63 ; k63 = 137
.line	0	loadk        r33   k39 ; k39 = 14
.line	0	loadk        r34   k64 ; k64 = 13
.line	0	loadk        r35  k119 ; k119 = 165
.line	0	loadk        r36  k102 ; k102 = 51
.line	0	loadk        r37   k92 ; k92 = 217
.line	0	loadk        r38  k127 ; k127 = 156
.line	0	loadk        r39   k80 ; k80 = 62
.line	0	loadk        r40   k86 ; k86 = 43
.line	0	loadk        r41   k11 ; k11 = 29
.line	0	loadk        r42   k79 ; k79 = 61
.line	0	loadk        r43  k128 ; k128 = 30
.line	0	loadk        r44   k12 ; k12 = 49
.line	0	loadk        r45  k129 ; k129 = 142
.line	0	loadk        r46  k130 ; k130 = 246
.line	0	loadk        r47   k71 ; k71 = 163
.line	0	loadk        r48   k30 ; k30 = 157
.line	0	call         r14    35     0
.line	0	setlist      r12     0     1
.line	0	call         r11     2     2
.line	0	call         r10     2     2
.line	0	gettabup     r11    u0   k16 ; k16 = "require"
.line	0	gettabup     r12    u0   k17 ; k17 = "table"
.line	0	gettable     r12   r12   k18 ; k18 = "concat"
.line	0	newtable     r13     1     0
.line	0	move         r14    r1
.line	0	loadk        r15   k19 ; k19 = 106
.line	0	loadk        r16   k20 ; k20 = 185
.line	0	loadk        r17   k21 ; k21 = 103
.line	0	loadk        r18   k12 ; k12 = 49
.line	0	loadk        r19   k22 ; k22 = 111
.line	0	loadk        r20   k23 ; k23 = 19
.line	0	loadk        r21   k24 ; k24 = 143
.line	0	loadk        r22   k25 ; k25 = 238
.line	0	loadk        r23   k26 ; k26 = 12
.line	0	loadk        r24   k27 ; k27 = 54
.line	0	loadk        r25   k28 ; k28 = 8
.line	0	loadk        r26   k22 ; k22 = 111
.line	0	loadk        r27   k29 ; k29 = 9
.line	0	loadk        r28   k27 ; k27 = 54
.line	0	loadk        r29   k30 ; k30 = 157
.line	0	loadk        r30   k25 ; k25 = 238
.line	0	loadk        r31   k31 ; k31 = 169
.line	0	loadk        r32   k32 ; k32 = 129
.line	0	loadk        r33   k26 ; k26 = 12
.line	0	loadk        r34   k33 ; k33 = 1
.line	0	loadk        r35   k34 ; k34 = 145
.line	0	loadk        r36   k35 ; k35 = 55
.line	0	loadk        r37   k36 ; k36 = 237
.line	0	loadk        r38   k37 ; k37 = 149
.line	0	loadk        r39   k38 ; k38 = 127
.line	0	loadk        r40   k39 ; k39 = 14
.line	0	loadk        r41   k11 ; k11 = 29
.line	0	loadk        r42   k40 ; k40 = 60
.line	0	loadk        r43   k41 ; k41 = 63
.line	0	loadk        r44   k42 ; k42 = 36
.line	0	loadk        r45   k43 ; k43 = 132
.line	0	loadk        r46    k1 ; k1 = 254
.line	0	loadk        r47   k44 ; k44 = 180
.line	0	loadk        r48   k45 ; k45 = 214
.line	0	loadk        r49   k46 ; k46 = 41
.line	0	loadk        r50   k47 ; k47 = 27
.line	0	loadk        r51   k48 ; k48 = 173
.line	0	loadk        r52    k7 ; k7 = 32
.line	0	loadk        r53   k49 ; k49 = 231
.line	0	loadk        r54   k50 ; k50 = 135
.line	0	call         r14    41     2
.line	0	move         r15    r1
.line	0	loadk        r16   k51 ; k51 = 3
.line	0	loadk        r17   k52 ; k52 = 155
.line	0	loadk        r18   k53 ; k53 = 120
.line	0	loadk        r19   k12 ; k12 = 49
.line	0	loadk        r20   k54 ; k54 = 66
.line	0	loadk        r21   k55 ; k55 = 18
.line	0	loadk        r22   k50 ; k50 = 135
.line	0	loadk        r23   k56 ; k56 = 182
.line	0	loadk        r24   k42 ; k42 = 36
.line	0	loadk        r25   k57 ; k57 = 20
.line	0	loadk        r26   k51 ; k51 = 3
.line	0	loadk        r27   k58 ; k58 = 37
.line	0	loadk        r28    k6 ; k6 = 47
.line	0	loadk        r29   k29 ; k29 = 9
.line	0	loadk        r30   k95 ; k95 = 153
.line	0	loadk        r31   k99 ; k99 = 251
.line	0	loadk        r32   k62 ; k62 = 184
.line	0	loadk        r33  k100 ; k100 = 154
.line	0	loadk        r34   k23 ; k23 = 19
.line	0	loadk        r35   k98 ; k98 = 5
.line	0	loadk        r36  k131 ; k131 = 191
.line	0	loadk        r37  k132 ; k132 = 21
.line	0	loadk        r38  k133 ; k133 = 241
.line	0	loadk        r39  k134 ; k134 = 158
.line	0	loadk        r40   k35 ; k35 = 55
.line	0	loadk        r41    k7 ; k7 = 32
.line	0	loadk        r42   k47 ; k47 = 27
.line	0	call         r15    28     0
.line	0	setlist      r13     0     1
.line	0	call         r12     2     2
.line	0	call         r11     2     2
.line	0	gettabup     r12    u0   k16 ; k16 = "require"
.line	0	gettabup     r13    u0   k17 ; k17 = "table"
.line	0	gettable     r13   r13   k18 ; k18 = "concat"
.line	0	newtable     r14     1     0
.line	0	move         r15    r1
.line	0	loadk        r16   k19 ; k19 = 106
.line	0	loadk        r17   k20 ; k20 = 185
.line	0	loadk        r18   k21 ; k21 = 103
.line	0	loadk        r19   k12 ; k12 = 49
.line	0	loadk        r20   k22 ; k22 = 111
.line	0	loadk        r21   k23 ; k23 = 19
.line	0	loadk        r22   k24 ; k24 = 143
.line	0	loadk        r23   k25 ; k25 = 238
.line	0	loadk        r24   k26 ; k26 = 12
.line	0	loadk        r25   k27 ; k27 = 54
.line	0	loadk        r26   k28 ; k28 = 8
.line	0	loadk        r27   k22 ; k22 = 111
.line	0	loadk        r28   k29 ; k29 = 9
.line	0	loadk        r29   k27 ; k27 = 54
.line	0	loadk        r30   k30 ; k30 = 157
.line	0	loadk        r31   k25 ; k25 = 238
.line	0	loadk        r32   k31 ; k31 = 169
.line	0	loadk        r33   k32 ; k32 = 129
.line	0	loadk        r34   k26 ; k26 = 12
.line	0	loadk        r35   k33 ; k33 = 1
.line	0	loadk        r36   k34 ; k34 = 145
.line	0	loadk        r37   k35 ; k35 = 55
.line	0	loadk        r38   k36 ; k36 = 237
.line	0	loadk        r39   k37 ; k37 = 149
.line	0	loadk        r40   k38 ; k38 = 127
.line	0	loadk        r41   k39 ; k39 = 14
.line	0	loadk        r42   k11 ; k11 = 29
.line	0	loadk        r43   k40 ; k40 = 60
.line	0	loadk        r44   k41 ; k41 = 63
.line	0	loadk        r45   k42 ; k42 = 36
.line	0	loadk        r46   k43 ; k43 = 132
.line	0	loadk        r47    k1 ; k1 = 254
.line	0	loadk        r48   k44 ; k44 = 180
.line	0	loadk        r49   k45 ; k45 = 214
.line	0	loadk        r50   k46 ; k46 = 41
.line	0	loadk        r51   k47 ; k47 = 27
.line	0	loadk        r52  k135 ; k135 = 174
.line	0	loadk        r53   k86 ; k86 = 43
.line	0	loadk        r54  k136 ; k136 = 225
.line	0	loadk        r55  k129 ; k129 = 142
.line	0	call         r15    41     2
.line	0	move         r16    r1
.line	0	loadk        r17   k51 ; k51 = 3
.line	0	loadk        r18   k52 ; k52 = 155
.line	0	loadk        r19   k53 ; k53 = 120
.line	0	loadk        r20   k12 ; k12 = 49
.line	0	loadk        r21   k54 ; k54 = 66
.line	0	loadk        r22   k55 ; k55 = 18
.line	0	loadk        r23   k50 ; k50 = 135
.line	0	loadk        r24   k56 ; k56 = 182
.line	0	loadk        r25   k42 ; k42 = 36
.line	0	loadk        r26   k57 ; k57 = 20
.line	0	loadk        r27   k64 ; k64 = 13
.line	0	loadk        r28    k6 ; k6 = 47
.line	0	loadk        r29   k86 ; k86 = 43
.line	0	loadk        r30  k104 ; k104 = 35
.line	0	loadk        r31   k30 ; k30 = 157
.line	0	loadk        r32   k61 ; k61 = 253
.line	0	loadk        r33   k63 ; k63 = 137
.line	0	loadk        r34   k50 ; k50 = 135
.line	0	loadk        r35  k132 ; k132 = 21
.line	0	loadk        r36   k28 ; k28 = 8
.line	0	loadk        r37    k4 ; k4 = 160
.line	0	call         r16    22     0
.line	0	setlist      r14     0     1
.line	0	call         r13     2     2
.line	0	call         r12     2     2
.line	0	gettable     r13    r3  k137 ; k137 = "GetDefaultGridLevels" (truncated)
.line	0	call         r13     1     2
.line	0	gettable     r14   r13  k138 ; k138 = "CellWidth"
.line	0	loadbool     r15     0     0
.line	0	loadk        r16  k139 ; k139 = 10000
.line	0	loadk        r17   k40 ; k40 = 60
.line	0	loadk        r18  k140 ; k140 = 100
.line	0	loadk        r19  k141 ; k141 = 0.5
.line	0	loadk        r20   k12 ; k12 = 49
.line	0	loadk        r21   k23 ; k23 = 19
.line	0	newtable     r22     0     3
.line	0	settable     r22  k142  k143 ; k143 = 0
.line	0	settable     r22  k144  k143 ; k143 = 0
.line	0	settable     r22  k145  k143 ; k143 = 0
.line	0	loadbool     r23     0     0
.line	0	closure      r24    f1
.line	0	newtable     r25     0     5
.line	0	settable     r25  k146   k33 ; k33 = 1
.line	0	settable     r25  k147  k148 ; k148 = 2
.line	0	settable     r25  k149   k51 ; k51 = 3
.line	0	settable     r25  k150  k151 ; k151 = 4
.line	0	settable     r25  k152   k98 ; k98 = 5
.line	0	loadk        r26  k140 ; k140 = 100
.line	0	loadk        r27   k98 ; k98 = 5
.line	0	loadk        r28  k153 ; k153 = 0.036
.line	0	gettabup     r29    u0  k154 ; k154 = "FLinearColor"
.line	0	loadk        r30   k33 ; k33 = 1
.line	0	loadk        r31   k33 ; k33 = 1
.line	0	loadk        r32   k33 ; k33 = 1
.line	0	loadk        r33   k33 ; k33 = 1
.line	0	call         r29     5     2
.line	0	gettabup     r30    u0  k155 ; k155 = "FColor"
.line	0	loadk        r31  k143 ; k143 = 0
.line	0	loadk        r32  k103 ; k103 = 255
.line	0	loadk        r33   k98 ; k98 = 5
.line	0	loadk        r34   k53 ; k53 = 120
.line	0	call         r30     5     2
.line	0	newtable     r31     4     0
.line	0	loadk        r32  k128 ; k128 = 30
.line	0	loadk        r33  k115 ; k115 = 70
.line	0	loadk        r34  k140 ; k140 = 100
.line	0	loadk        r35  k156 ; k156 = 1000
.line	0	setlist      r31     4     1
.line	0	newtable     r32     0     5
.line	0	gettabup     r33    u0  k155 ; k155 = "FColor"
.line	0	loadk        r34  k157 ; k157 = 117
.line	0	loadk        r35  k158 ; k158 = 252
.line	0	loadk        r36  k159 ; k159 = 76
.line	0	loadk        r37  k160 ; k160 = 77
.line	0	call         r33     5     2
.line	0	settable     r32   k33   r33 ; k33 = 1
.line	0	gettabup     r33    u0  k155 ; k155 = "FColor"
.line	0	loadk        r34  k161 ; k161 = 247
.line	0	loadk        r35  k162 ; k162 = 206
.line	0	loadk        r36  k115 ; k115 = 70
.line	0	loadk        r37  k163 ; k163 = 102
.line	0	call         r33     5     2
.line	0	settable     r32  k148   r33 ; k148 = 2
.line	0	gettabup     r33    u0  k155 ; k155 = "FColor"
.line	0	loadk        r34  k124 ; k124 = 249
.line	0	loadk        r35  k164 ; k164 = 96
.line	0	loadk        r36  k165 ; k165 = 31
.line	0	loadk        r37  k166 ; k166 = 128
.line	0	call         r33     5     2
.line	0	settable     r32   k51   r33 ; k51 = 3
.line	0	gettabup     r33    u0  k155 ; k155 = "FColor"
.line	0	loadk        r34  k167 ; k167 = 233
.line	0	loadk        r35  k143 ; k143 = 0
.line	0	loadk        r36  k143 ; k143 = 0
.line	0	loadk        r37  k166 ; k166 = 128
.line	0	call         r33     5     2
.line	0	settable     r32  k151   r33 ; k151 = 4
.line	0	gettabup     r33    u0  k155 ; k155 = "FColor"
.line	0	loadk        r34  k167 ; k167 = 233
.line	0	loadk        r35  k143 ; k143 = 0
.line	0	loadk        r36  k143 ; k143 = 0
.line	0	loadk        r37  k166 ; k166 = 128
.line	0	call         r33     5     2
.line	0	settable     r32   k98   r33 ; k98 = 5
.line	0	newtable     r33     0     5
.line	0	gettabup     r34    u0  k154 ; k154 = "FLinearColor"
.line	0	gettable     r34   r34  k168 ; k168 = "FromSRGBColor"
.line	0	gettabup     r35    u0  k155 ; k155 = "FColor"
.line	0	loadk        r36   k81 ; k81 = 45
.line	0	loadk        r37  k169 ; k169 = 248
.line	0	loadk        r38   k55 ; k55 = 18
.line	0	loadk        r39  k170 ; k170 = 204
.line	0	call         r35     5     0
.line	0	call         r34     0     2
.line	0	settable     r33   k33   r34 ; k33 = 1
.line	0	gettabup     r34    u0  k154 ; k154 = "FLinearColor"
.line	0	gettable     r34   r34  k168 ; k168 = "FromSRGBColor"
.line	0	gettabup     r35    u0  k155 ; k155 = "FColor"
.line	0	loadk        r36   k36 ; k36 = 237
.line	0	loadk        r37   k30 ; k30 = 157
.line	0	loadk        r38  k126 ; k126 = 15
.line	0	loadk        r39  k170 ; k170 = 204
.line	0	call         r35     5     0
.line	0	call         r34     0     2
.line	0	settable     r33  k148   r34 ; k148 = 2
.line	0	gettabup     r34    u0  k154 ; k154 = "FLinearColor"
.line	0	gettable     r34   r34  k168 ; k168 = "FromSRGBColor"
.line	0	gettabup     r35    u0  k155 ; k155 = "FColor"
.line	0	loadk        r36  k133 ; k133 = 241
.line	0	loadk        r37   k11 ; k11 = 29
.line	0	loadk        r38   k51 ; k51 = 3
.line	0	loadk        r39  k170 ; k170 = 204
.line	0	call         r35     5     0
.line	0	call         r34     0     2
.line	0	settable     r33   k51   r34 ; k51 = 3
.line	0	gettabup     r34    u0  k154 ; k154 = "FLinearColor"
.line	0	gettable     r34   r34  k168 ; k168 = "FromSRGBColor"
.line	0	gettabup     r35    u0  k155 ; k155 = "FColor"
.line	0	loadk        r36  k171 ; k171 = 207
.line	0	loadk        r37  k143 ; k143 = 0
.line	0	loadk        r38  k143 ; k143 = 0
.line	0	loadk        r39  k170 ; k170 = 204
.line	0	call         r35     5     0
.line	0	call         r34     0     2
.line	0	settable     r33  k151   r34 ; k151 = 4
.line	0	gettabup     r34    u0  k154 ; k154 = "FLinearColor"
.line	0	gettable     r34   r34  k168 ; k168 = "FromSRGBColor"
.line	0	gettabup     r35    u0  k155 ; k155 = "FColor"
.line	0	loadk        r36  k171 ; k171 = 207
.line	0	loadk        r37  k143 ; k143 = 0
.line	0	loadk        r38  k143 ; k143 = 0
.line	0	loadk        r39  k170 ; k170 = 204
.line	0	call         r35     5     0
.line	0	call         r34     0     2
.line	0	settable     r33   k98   r34 ; k98 = 5
.line	0	newtable     r34     0     5
.line	0	gettabup     r35    u0  k172 ; k172 = "FSlateColor"
.line	0	gettable     r36   r33   k33 ; k33 = 1
.line	0	call         r35     2     2
.line	0	settable     r34   k33   r35 ; k33 = 1
.line	0	gettabup     r35    u0  k172 ; k172 = "FSlateColor"
.line	0	gettable     r36   r33  k148 ; k148 = 2
.line	0	call         r35     2     2
.line	0	settable     r34  k148   r35 ; k148 = 2
.line	0	gettabup     r35    u0  k172 ; k172 = "FSlateColor"
.line	0	gettable     r36   r33   k51 ; k51 = 3
.line	0	call         r35     2     2
.line	0	settable     r34   k51   r35 ; k51 = 3
.line	0	gettabup     r35    u0  k172 ; k172 = "FSlateColor"
.line	0	gettable     r36   r33  k151 ; k151 = 4
.line	0	call         r35     2     2
.line	0	settable     r34  k151   r35 ; k151 = 4
.line	0	gettabup     r35    u0  k172 ; k172 = "FSlateColor"
.line	0	gettable     r36   r33   k98 ; k98 = 5
.line	0	call         r35     2     2
.line	0	settable     r34   k98   r35 ; k98 = 5
.line	0	gettabup     r35    u0  k173 ; k173 = "math"
.line	0	closure      r36    f2
.line	0	settable      r2  k174   r36 ; k174 = "OnUGCSubSystemInit"
.line	0	closure      r36    f3
.line	0	settable      r2  k175   r36 ; k175 = "OnInitEditor"
.line	0	closure      r36    f4
.line	0	settable      r2  k176   r36 ; k176 = "OnReleaseEditor"
.line	0	closure      r36    f5
.line	0	settable      r2  k177   r36 ; k177 = "OnInitGame"
.line	0	closure      r36    f6
.line	0	settable      r2  k178   r36 ; k178 = "_RegisterApplyFPSLim" (truncated)
.line	0	closure      r36    f7
.line	0	settable      r2  k179   r36 ; k179 = "OnReleaseGame"
.line	0	closure      r36    f8
.line	0	settable      r2  k180   r36 ; k180 = "OnUGCSubSystemReleas" (truncated)
.line	0	closure      r36    f9
.line	0	settable      r2  k181   r36 ; k181 = "GetInstanceManager"
.line	0	closure      r36   f10
.line	0	settable      r2  k182   r36 ; k182 = "GetAssetManager"
.line	0	closure      r36   f11
.line	0	settable      r2  k183   r36 ; k183 = "InitCostSetting"
.line	0	closure      r36   f12
.line	0	settable      r2  k184   r36 ; k184 = "OnGameTypeChangePreH" (truncated)
.line	0	closure      r36   f13
.line	0	settable      r2  k185   r36 ; k185 = "ExtremeModeChange"
.line	0	closure      r36   f14
.line	0	settable      r2  k186   r36 ; k186 = "UnlimitedModeChange"
.line	0	closure      r36   f15
.line	0	settable      r2  k187   r36 ; k187 = "_OnGameParameterLoad" (truncated)
.line	0	closure      r36   f16
.line	0	settable      r2  k188   r36 ; k188 = "SetAssetCostEnable"
.line	0	closure      r36   f17
.line	0	settable      r2  k189   r36 ; k189 = "IsAssetCostEnable"
.line	0	closure      r36   f18
.line	0	settable      r2  k190   r36 ; k190 = "AddIgnoreInstanceID"
.line	0	closure      r36   f19
.line	0	settable      r2  k191   r36 ; k191 = "RemoveIgnoreInstance" (truncated)
.line	0	closure      r36   f20
.line	0	settable      r2  k192   r36 ; k192 = "GetCellIndex"
.line	0	closure      r36   f21
.line	0	settable      r2  k193   r36 ; k193 = "GetCurBuildingLocati" (truncated)
.line	0	closure      r36   f22
.line	0	settable      r2  k194   r36 ; k194 = "GetInstanceEditSubSy" (truncated)
.line	0	closure      r36   f23
.line	0	settable      r2  k195   r36 ; k195 = "GetBuildSubSystem"
.line	0	closure      r36   f24
.line	0	settable      r2  k196   r36 ; k196 = "RecordRepeatedComput" (truncated)
.line	0	closure      r36   f25
.line	0	settable      r2  k197   r36 ; k197 = "RemoveRepeatedComput" (truncated)
.line	0	closure      r36   f26
.line	0	settable      r2  k198   r36 ; k198 = "ResetRepeatedCompute" (truncated)
.line	0	closure      r36   f27
.line	0	settable      r2  k199   r36 ; k199 = "CheckHasRepeatedComp" (truncated)
.line	0	closure      r36   f28
.line	0	settable      r2  k200   r36 ; k200 = "UniqueAssetId"
.line	0	closure      r36   f29
.line	0	settable      r2  k201   r36 ; k201 = "CalcGroupAssetCost"
.line	0	closure      r36   f30
.line	0	settable      r2  k202   r36 ; k202 = "CalcDestructibleMesh" (truncated)
.line	0	closure      r36   f31
.line	0	settable      r2  k203   r36 ; k203 = "GetDeltaCostByAssetI" (truncated)
.line	0	closure      r36   f32
.line	0	settable      r2  k204   r36 ; k204 = "GetPixelAssetDelatCo" (truncated)
.line	0	closure      r36   f33
.line	0	settable      r2  k205   r36 ; k205 = "GetCurAssetCost"
.line	0	closure      r36   f34
.line	0	settable      r2  k206   r36 ; k206 = "UnlimitAssetCost"
.line	0	closure      r36   f35
.line	0	settable      r2  k207   r36 ; k207 = "GetCurAssetCostMax"
.line	0	closure      r36   f36
.line	0	settable      r2  k208   r36 ; k208 = "InitInstanceCost"
.line	0	closure      r36   f37
.line	0	settable      r2  k209   r36 ; k209 = "GetGridAssetCost"
.line	0	closure      r36   f38
.line	0	settable      r2  k210   r36 ; k210 = "GetGridAssetCostByAx" (truncated)
.line	0	closure      r36   f39
.line	0	settable      r2  k211   r36 ; k211 = "GetGridAssetCostByIn" (truncated)
.line	0	closure      r36   f40
.line	0	settable      r2  k212   r36 ; k212 = "UpdateGridAssetCost"
.line	0	closure      r36   f41
.line	0	settable      r2  k213   r36 ; k213 = "ClearDelayUpdateGrid" (truncated)
.line	0	closure      r36   f42
.line	0	settable      r2  k214   r36 ; k214 = "DelayCalGridAssetCos" (truncated)
.line	0	closure      r36   f43
.line	0	settable      r2  k215   r36 ; k215 = "CalGridAssetCost"
.line	0	closure      r36   f44
.line	0	settable      r2  k216   r36 ; k216 = "UpdateAffectedGridAs" (truncated)
.line	0	closure      r36   f45
.line	0	settable      r2  k217   r36 ; k217 = "GetNearCellIndexList"
.line	0	closure      r36   f46
.line	0	settable      r2  k218   r36 ; k218 = "CalGridNoAlwaysLoadA" (truncated)
.line	0	closure      r36   f47
.line	0	settable      r2  k219   r36 ; k219 = "CalGridNoAlwaysLoadA" (truncated)
.line	0	closure      r36   f48
.line	0	settable      r2  k220   r36 ; k220 = "CalAlwaysLoadAssetCo" (truncated)
.line	0	closure      r36   f49
.line	0	settable      r2  k221   r36 ; k221 = "InitMapInitAssetCost"
.line	0	closure      r36   f50
.line	0	settable      r2  k222   r36 ; k222 = "GetMapInitAssetCost"
.line	0	closure      r36   f51
.line	0	settable      r2  k223   r36 ; k223 = "ClearInstanceCostInf" (truncated)
.line	0	closure      r36   f52
.line	0	settable      r2  k224   r36 ; k224 = "GetInstanceCostInfo"
.line	0	closure      r36   f53
.line	0	settable      r2  k225   r36 ; k225 = "TryGetDynamicUserAct" (truncated)
.line	0	closure      r36   f54
.line	0	settable      r2  k226   r36 ; k226 = "AddOrUpdateInstanceC" (truncated)
.line	0	closure      r36   f55
.line	0	settable      r2  k227   r36 ; k227 = "RemoveInstanceCostIn" (truncated)
.line	0	closure      r36   f56
.line	0	settable      r2  k228   r36 ; k228 = "GetInstanceAssetCost"
.line	0	closure      r36   f57
.line	0	settable      r2  k229   r36 ; k229 = "CacheMaximumCost"
.line	0	closure      r36   f58
.line	0	settable      r2  k230   r36 ; k230 = "GetMaximumCost"
.line	0	closure      r36   f59
.line	0	settable      r2  k231   r36 ; k231 = "AllCellAssetCostChec" (truncated)
.line	0	closure      r36   f60
.line	0	settable      r2  k232   r36 ; k232 = "GetAffectedGrid"
.line	0	closure      r36   f61
.line	0	settable      r2  k233   r36 ; k233 = "CheckCurCellAssetCos" (truncated)
.line	0	closure      r36   f62
.line	0	settable      r2  k234   r36 ; k234 = "CheckCurCellAssetCos" (truncated)
.line	0	closure      r36   f63
.line	0	settable      r2  k235   r36 ; k235 = "PlaceAssetCostCheck"
.line	0	closure      r36   f64
.line	0	settable      r2  k236   r36 ; k236 = "GetAssetCostCellSize"
.line	0	closure      r36   f65
.line	0	settable      r2  k237   r36 ; k237 = "GetInstanceDefaultCo" (truncated)
.line	0	closure      r36   f66
.line	0	settable      r2  k238   r36 ; k238 = "GetInstanceDefaultMa" (truncated)
.line	0	closure      r36   f67
.line	0	settable      r2  k239   r36 ; k239 = "_OnCustomUIEditorEnt" (truncated)
.line	0	closure      r36   f68
.line	0	settable      r2  k240   r36 ; k240 = "_OnCustomUIEditorExi" (truncated)
.line	0	closure      r36   f69
.line	0	settable      r2  k241   r36 ; k241 = "_MarkCustomUICostDir" (truncated)
.line	0	closure      r36   f70
.line	0	settable      r2  k242   r36 ; k242 = "_RecomputeCustomUICo" (truncated)
.line	0	closure      r36   f71
.line	0	settable      r2  k243   r36 ; k243 = "OnInstanceAdded"
.line	0	closure      r36   f72
.line	0	settable      r2  k244   r36 ; k244 = "OnInstanceRemoved"
.line	0	closure      r36   f73
.line	0	settable      r2  k245   r36 ; k245 = "OnInstanceChanged"
.line	0	closure      r36   f74
.line	0	settable      r2  k246   r36 ; k246 = "OnGroupManipulatorCh" (truncated)
.line	0	closure      r36   f75
.line	0	settable      r2  k247   r36 ; k247 = "OnObjectGroupChanged"
.line	0	closure      r36   f76
.line	0	settable      r2  k248   r36 ; k248 = "OnObjectInstanceCost" (truncated)
.line	0	closure      r36   f77
.line	0	settable      r2  k249   r36 ; k249 = "OnInstanceIsPrefabCh" (truncated)
.line	0	closure      r36   f78
.line	0	settable      r2  k250   r36 ; k250 = "OnInstanceTransformC" (truncated)
.line	0	closure      r36   f79
.line	0	settable      r2  k251   r36 ; k251 = "OnInstanceMaterialId" (truncated)
.line	0	closure      r36   f80
.line	0	settable      r2  k252   r36 ; k252 = L"OnInstanceDestructib" (truncated)
.line	0	closure      r36   f81
.line	0	settable      r2  k253   r36 ; k253 = "InstanceChangedUpdat" (truncated)
.line	0	closure      r36   f82
.line	0	settable      r2  k254   r36 ; k254 = "GetCurGridInstances"
.line	0	closure      r36   f83
.line	0	settable      r2  k255   r36 ; k255 = "AssetCountLimitInsta" (truncated)
.line	0	loadk        r36  k256 ; k256 = "CheckAssetCountLimit" (truncated)
.line	0	closure      r37   f84
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k257 ; k257 = "CheckAssetCountLimit" (truncated)
.line	0	closure      r37   f85
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k258 ; k258 = "GetAssetCostColor"
.line	0	closure      r37   f86
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k259 ; k259 = "GetGridAssetCostColo" (truncated)
.line	0	closure      r37   f87
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k260 ; k260 = "GridAssetCostFColor"
.line	0	closure      r37   f88
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k261 ; k261 = "BarCostColor"
.line	0	closure      r37   f89
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k262 ; k262 = "BarCostColorByKey"
.line	0	closure      r37   f90
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k263 ; k263 = "GetLevelPercents"
.line	0	closure      r37   f91
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k264 ; k264 = "GetTexGridPixelNum"
.line	0	closure      r37   f92
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k265 ; k265 = "GetGridTexture"
.line	0	closure      r37   f93
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k266 ; k266 = "GetGridColors"
.line	0	closure      r37   f94
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k267 ; k267 = "ModifyAllGridColor"
.line	0	closure      r37   f95
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k268 ; k268 = "ModifyGridColor"
.line	0	closure      r37   f96
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k269 ; k269 = "DelayUpdateGridColor" (truncated)
.line	0	closure      r37   f97
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k270 ; k270 = "ClearDelayUpdateGrid" (truncated)
.line	0	closure      r37   f98
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k271 ; k271 = "UpdateGridColors"
.line	0	closure      r37   f99
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k272 ; k272 = "SetGridAreaToFull"
.line	0	closure      r37  f100
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k273 ; k273 = "GetAllGroupManipulat" (truncated)
.line	0	closure      r37  f101
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k274 ; k274 = "InitGroupManipulator" (truncated)
.line	0	closure      r37  f102
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k275 ; k275 = "SetGroupManipulatorM" (truncated)
.line	0	closure      r37  f103
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k276 ; k276 = "IsInMutexList"
.line	0	closure      r37  f104
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k277 ; k277 = "CalcMutexListCost"
.line	0	closure      r37  f105
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k278 ; k278 = "IsInstanceNoNeed"
.line	0	closure      r37  f106
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k279 ; k279 = "IsExtremeMap"
.line	0	closure      r37  f107
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k280 ; k280 = "GetMapCellCount"
.line	0	closure      r37  f108
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k281 ; k281 = "GetMapCellSize"
.line	0	closure      r37  f109
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k282 ; k282 = "GetMapCenterPos"
.line	0	closure      r37  f110
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k283 ; k283 = "GetMapCellHalfCount"
.line	0	closure      r37  f111
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k284 ; k284 = "CacheEntireMapGridWi" (truncated)
.line	0	closure      r37  f112
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k285 ; k285 = "GetEntireMapStatShow"
.line	0	closure      r37  f113
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k286 ; k286 = "SwitchEntireMapStatS" (truncated)
.line	0	closure      r37  f114
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k287 ; k287 = "IsPlayTest"
.line	0	closure      r37  f115
.line	0	settable      r2   r36   r37
.line	0	loadk        r36  k288 ; k288 = "require"
.line	0	gettabup     r36    u0   r36
.line	0	move         r37    r1
.line	0	loadk        r38  k289 ; k289 = 78
.line	0	loadk        r39  k290 ; k290 = 180
.line	0	loadk        r40  k291 ; k291 = 107
.line	0	loadk        r41  k292 ; k292 = 39
.line	0	loadk        r42  k293 ; k293 = 80
.line	0	call         r37     6     2
.line	0	call         r36     2     2
.line	0	loadk        r37  k288 ; k288 = "require"
.line	0	gettabup     r37    u0   r37
.line	0	loadk        r38  k294 ; k294 = "table"
.line	0	gettabup     r38    u0   r38
.line	0	loadk        r39  k295 ; k295 = "concat"
.line	0	gettable     r38   r38   r39
.line	0	newtable     r39     1     0
.line	0	move         r40    r1
.line	0	loadk        r41  k296 ; k296 = 106
.line	0	loadk        r42  k297 ; k297 = 185
.line	0	loadk        r43  k298 ; k298 = 103
.line	0	loadk        r44  k299 ; k299 = 49
.line	0	loadk        r45  k300 ; k300 = 111
.line	0	loadk        r46  k301 ; k301 = 19
.line	0	loadk        r47  k302 ; k302 = 143
.line	0	loadk        r48  k303 ; k303 = 238
.line	0	loadk        r49  k304 ; k304 = 12
.line	0	loadk        r50  k305 ; k305 = 54
.line	0	loadk        r51  k306 ; k306 = 8
.line	0	loadk        r52  k300 ; k300 = 111
.line	0	loadk        r53  k307 ; k307 = 9
.line	0	loadk        r54  k305 ; k305 = 54
.line	0	loadk        r55  k308 ; k308 = 157
.line	0	loadk        r56  k303 ; k303 = 238
.line	0	loadk        r57  k309 ; k309 = 169
.line	0	loadk        r58  k310 ; k310 = 129
.line	0	loadk        r59  k304 ; k304 = 12
.line	0	loadk        r60  k311 ; k311 = 1
.line	0	loadk        r61  k312 ; k312 = 145
.line	0	loadk        r62  k313 ; k313 = 55
.line	0	loadk        r63  k314 ; k314 = 237
.line	0	loadk        r64  k315 ; k315 = 149
.line	0	loadk        r65  k316 ; k316 = 127
.line	0	loadk        r66  k317 ; k317 = 14
.line	0	loadk        r67  k318 ; k318 = 29
.line	0	loadk        r68  k319 ; k319 = 60
.line	0	loadk        r69  k320 ; k320 = 63
.line	0	loadk        r70  k321 ; k321 = 36
.line	0	loadk        r71  k322 ; k322 = 132
.line	0	loadk        r72    k1 ; k1 = 254
.line	0	loadk        r73  k290 ; k290 = 180
.line	0	loadk        r74  k323 ; k323 = 214
.line	0	loadk        r75  k324 ; k324 = 57
.line	0	loadk        r76  k311 ; k311 = 1
.line	0	loadk        r77  k325 ; k325 = 161
.line	0	loadk        r78  k326 ; k326 = 53
.line	0	loadk        r79  k327 ; k327 = 247
.line	0	loadk        r80  k328 ; k328 = 147
.line	0	call         r40    41     2
.line	0	move         r41    r1
.line	0	loadk        r42  k329 ; k329 = 89
.line	0	loadk        r43  k330 ; k330 = 189
.line	0	loadk        r44  k298 ; k298 = 103
.line	0	loadk        r45  k331 ; k331 = 122
.line	0	loadk        r46  k332 ; k332 = 96
.line	0	loadk        r47  k333 ; k333 = 20
.line	0	loadk        r48  k334 ; k334 = 139
.line	0	loadk        r49  k325 ; k325 = 161
.line	0	loadk        r50  k326 ; k326 = 53
.line	0	loadk        r51  k335 ; k335 = 48
.line	0	loadk        r52  k336 ; k336 = 26
.line	0	loadk        r53  k321 ; k321 = 36
.line	0	loadk        r54  k337 ; k337 = 7
.line	0	loadk        r55  k338 ; k338 = 43
.line	0	loadk        r56  k339 ; k339 = 156
.line	0	loadk        r57  k340 ; k340 = 234
.line	0	loadk        r58  k341 ; k341 = 142
.line	0	loadk        r59  k308 ; k308 = 157
.line	0	loadk        r60  k342 ; k342 = 24
.line	0	loadk        r61  k343 ; k343 = 23
.line	0	loadk        r62  k344 ; k344 = 170
.line	0	loadk        r63  k345 ; k345 = 37
.line	0	loadk        r64  k340 ; k340 = 234
.line	0	loadk        r65  k315 ; k315 = 149
.line	0	loadk        r66  k319 ; k319 = 60
.line	0	loadk        r67  k346 ; k346 = 11
.line	0	loadk        r68  k318 ; k318 = 29
.line	0	loadk        r69  k347 ; k347 = 34
.line	0	loadk        r70  k320 ; k320 = 63
.line	0	call         r41    30     0
.line	0	setlist      r39     0     1
.line	0	call         r38     2     2
.line	0	call         r37     2     2
.line	0	move         r38   r36
.line	0	move         r39   r37
.line	0	loadnil      r40     0
.line	0	move         r41    r2
.line	0	tailcall     r38     4
.line	0	return       r38     0
.line	0	return        r0     1
.line	0	gettabup      r2    u0  k215 ; k215 = "CalGridAssetCost"
.line	0	move          r0    r0
.line	0	gettabup      r1    u1  k163 ; k163 = 102
.line	0	return        r0     1

.function	main/f0

.source	null
.linedefined	2
.lastlinedefined	9
.numparams	0
.is_vararg	1
.maxstacksize	9

.upvalue	"_ENV"	0	false
.upvalue	"U1"	0	true

.constant	k0	1
.constant	k1	"string"
.constant	k2	"char"
.constant	k3	16
.constant	k4	31
.constant	k5	7
.constant	k6	256
.constant	k7	"table"
.constant	k8	"concat"

.line	2	newtable      r0     0     0
.line	2	vararg        r1     0
.line	2	setlist       r0     0     1
.line	2	newtable      r1     0     0
.line	2	loadk         r2    k0 ; k0 = 1
.line	2	len           r3    r0
.line	2	loadk         r4    k0 ; k0 = 1
.line	2	move          r0    r0
.line	2	gettabup      r6    u0    k1 ; k1 = "string"
.line	2	gettable      r6    r6    k2 ; k2 = "char"
.line	2	gettable      r7    r0    r5
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mod           r8    r8    k3 ; k3 = 16
.line	2	add           r8    r8    k0 ; k0 = 1
.line	2	gettabup      r8    u1    r8
.line	2	bxor          r7    r7    r8
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mul           r8    r8    k4 ; k4 = 31
.line	2	add           r8    r8    k5 ; k5 = 7
.line	2	mod           r8    r8    k6 ; k6 = 256
.line	2	bxor          r7    r7    r8
.line	2	mod           r7    r7    k6 ; k6 = 256
.line	2	call          r6     2     2
.line	2	settable      r1    r5    r6
.line	2	move          r0    r0
.line	2	gettabup      r2    u0    k7 ; k7 = "table"
.line	2	gettable      r2    r2    k8 ; k8 = "concat"
.line	2	move          r3    r1
.line	2	tailcall      r2     2
.line	2	return        r2     0
.line	2	return        r0     1
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	return        r0     1

.function	main/f1

.source	null
.linedefined	50
.lastlinedefined	54
.numparams	0
.is_vararg	1
.maxstacksize	2

.upvalue	"_ENV"	23	true
.upvalue	"U1"	0	false

.constant	k0	"printf"

.line	50	getupval      r0    u0
.line	50	test          r0     0
.line	50	jmp            0    l7
.line	50	gettabup      r0    u1    k0 ; k0 = "printf"
.line	50	vararg        r1     0
.line	50	call          r0     0     1
.label	l7
.line	50	return        r0     1
.line	50	move          r0    r0
.line	50	move          r0    r0
.line	50	move          r0    r0
.line	50	return        r0     1

.function	main/f2

.source	null
.linedefined	96
.lastlinedefined	105
.numparams	1
.is_vararg	0
.maxstacksize	21

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"bIsShipping"
.constant	k1	"Client"
.constant	k2	"IsShipping"
.constant	k3	"_CacheMaximumCost"
.constant	k4	0
.constant	k5	"AddCommonEvent"
.constant	k6	"EVENTTYPE_CREATIVE"
.constant	k7	"EVENTID_GAMETYPE_CHANGED_PRE"
.constant	k8	"OnGameTypeChangePreHandle"
.constant	k9	"GetGameParameterManager"
.constant	k10	"AddGameParameterListener"
.constant	k11	79
.constant	k12	145
.constant	k13	121
.constant	k14	17
.constant	k15	91
.constant	k16	18
.constant	k17	156
.constant	k18	165
.constant	k19	44
.constant	k20	60
.constant	k21	33
.constant	k22	46
.constant	k23	"ExtremeModeChange"
.constant	k24	1
.constant	k25	77
.constant	k26	10
.constant	k27	135
.constant	k28	173
.constant	k29	40
.constant	k30	45
.constant	k31	9
.constant	k32	37
.constant	k33	7
.constant	k34	43
.constant	k35	234
.constant	k36	"UnlimitedModeChange"

.line	96	gettabup      r1    u0    k1 ; k1 = "Client"
.line	96	gettable      r1    r1    k2 ; k2 = "IsShipping"
.line	96	call          r1     1     2
.line	96	settable      r0    k0    r1 ; k0 = "bIsShipping"
.line	96	settable      r0    k3    k4 ; k4 = 0
.line	96	self          r1    r0    k5 ; k5 = "AddCommonEvent"
.line	96	gettabup      r3    u0    k6 ; k6 = "EVENTTYPE_CREATIVE"
.line	96	gettabup      r4    u0    k7 ; k7 = "EVENTID_GAMETYPE_CHA" (truncated)
.line	96	gettable      r5    r0    k8 ; k8 = "OnGameTypeChangePreH" (truncated)
.line	96	move          r6    r0
.line	96	call          r1     6     1
.line	96	gettabup      r1    u0    k9 ; k9 = "GetGameParameterMana" (truncated)
.line	96	call          r1     1     2
.line	96	test          r1     0
.line	96	jmp            0   l58
.line	96	self          r2    r1   k10 ; k10 = "AddGameParameterList" (truncated)
.line	96	getupval      r4    u1
.line	96	loadk         r5   k11 ; k11 = 79
.line	96	loadk         r6   k12 ; k12 = 145
.line	96	loadk         r7   k13 ; k13 = 121
.line	96	loadk         r8   k14 ; k14 = 17
.line	96	loadk         r9   k15 ; k15 = 91
.line	96	loadk        r10   k16 ; k16 = 18
.line	96	loadk        r11   k17 ; k17 = 156
.line	96	loadk        r12   k18 ; k18 = 165
.line	96	loadk        r13   k19 ; k19 = 44
.line	96	loadk        r14   k20 ; k20 = 60
.line	96	loadk        r15   k21 ; k21 = 33
.line	96	loadk        r16   k22 ; k22 = 46
.line	96	loadk        r17   k22 ; k22 = 46
.line	96	loadk        r18   k21 ; k21 = 33
.line	96	call          r4    15     2
.line	96	gettable      r5    r0   k23 ; k23 = "ExtremeModeChange"
.line	96	move          r6    r0
.line	96	call          r2     5     1
.line	96	self          r2    r1   k10 ; k10 = "AddGameParameterList" (truncated)
.line	96	getupval      r4    u1
.line	96	loadk         r5   k11 ; k11 = 79
.line	96	loadk         r6   k12 ; k12 = 145
.line	96	loadk         r7   k13 ; k13 = 121
.line	96	loadk         r8   k24 ; k24 = 1
.line	96	loadk         r9   k25 ; k25 = 77
.line	96	loadk        r10   k26 ; k26 = 10
.line	96	loadk        r11   k27 ; k27 = 135
.line	96	loadk        r12   k28 ; k28 = 173
.line	96	loadk        r13   k29 ; k29 = 40
.line	96	loadk        r14   k30 ; k30 = 45
.line	96	loadk        r15   k31 ; k31 = 9
.line	96	loadk        r16   k32 ; k32 = 37
.line	96	loadk        r17   k33 ; k33 = 7
.line	96	loadk        r18   k34 ; k34 = 43
.line	96	loadk        r19   k17 ; k17 = 156
.line	96	loadk        r20   k35 ; k35 = 234
.line	96	call          r4    17     2
.line	96	gettable      r5    r0   k36 ; k36 = "UnlimitedModeChange"
.line	96	move          r6    r0
.line	96	call          r2     5     1
.label	l58
.line	96	return        r0     1
.line	96	move          r0    r0
.line	96	move          r0    r0
.line	96	move          r0    r0
.line	96	move          r0    r0
.line	96	return        r0     1

.function	main/f3

.source	null
.linedefined	107
.lastlinedefined	152
.numparams	1
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	2	true
.upvalue	"U1"	15	true
.upvalue	"U2"	24	true
.upvalue	"U3"	0	false
.upvalue	"U4"	1	true
.upvalue	"U5"	7	true
.upvalue	"U6"	35	true
.upvalue	"U7"	14	true

.constant	k0	"__super"
.constant	k1	"OnInitEditor"
.constant	k2	"bWriteLog"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	110
.constant	k6	170
.constant	k7	111
.constant	k8	53
.constant	k9	87
.constant	k10	15
.constant	k11	152
.constant	k12	165
.constant	k13	12
.constant	k14	54
.constant	k15	8
.constant	k16	36
.constant	k17	11
.constant	k18	55
.constant	k19	139
.constant	k20	234
.constant	k21	169
.constant	k22	171
.constant	k23	21
.constant	k24	23
.constant	k25	167
.constant	k26	5
.constant	k27	235
.constant	k28	146
.constant	k29	2
.constant	k30	48
.constant	k31	37
.constant	k32	63
.constant	k33	57
.constant	k34	210
.constant	k35	208
.constant	k36	163
.constant	k37	177
.constant	k38	4
.constant	k39	29
.constant	k40	183
.constant	k41	3
.constant	k42	137
.constant	k43	89
.constant	k44	120
.constant	k45	"AddCommonEvent"
.constant	k46	"EVENTTYPE_CREATIVE"
.constant	k47	"EVENTID_INSTANCES_EDIT_ADDED"
.constant	k48	"OnInstanceAdded"
.constant	k49	"EVENTID_INSTANCES_EDIT_REMOVED"
.constant	k50	"OnInstanceRemoved"
.constant	k51	"CustomUICost"
.constant	k52	0
.constant	k53	"_bCustomUIEditorOpen"
.constant	k54	false
.constant	k55	"EVENTID_CUSTOMUI_ENTER_EDITOR"
.constant	k56	"_OnCustomUIEditorEnter"
.constant	k57	"EVENTID_CUSTOMUI_EXIT_EDITOR"
.constant	k58	"_OnCustomUIEditorExit"
.constant	k59	"EVENTID_UMGINFO_MAP_CHANGED"
.constant	k60	"_MarkCustomUICostDirty"
.constant	k61	"slua_GameFrontendHUD"
.constant	k62	"GetPlayerController"
.constant	k63	"GetLevelLandscapeBounds"
.constant	k64	"MapCenterPos"
.constant	k65	"GetLandscapeMidPoint"
.constant	k66	"MapCellSize"
.constant	k67	"floor"
.constant	k68	"ceil"
.constant	k69	"huge"
.constant	k70	"string"
.constant	k71	"format"
.constant	k72	116
.constant	k73	74
.constant	k74	161
.constant	k75	45
.constant	k76	97
.constant	k77	7
.constant	k78	136
.constant	k79	204
.constant	k80	184
.constant	k81	132
.constant	k82	22
.constant	k83	186
.constant	k84	44
.constant	k85	251
.constant	k86	202
.constant	k87	58
.constant	k88	92
.constant	k89	34
.constant	k90	141
.constant	k91	243
.constant	k92	128
.constant	k93	30
.constant	k94	17
.constant	k95	173
.constant	k96	50
.constant	k97	180
.constant	k98	197
.constant	k99	94
.constant	k100	244
.constant	k101	42
.constant	k102	66
.constant	k103	10
.constant	k104	130
.constant	k105	162
.constant	k106	32
.constant	k107	9
.constant	k108	1
.constant	k109	195
.constant	k110	187
.constant	k111	51
.constant	k112	62
.constant	k113	150
.constant	k114	"tostring"
.constant	k115	"MapCellHalfCount"
.constant	k116	"max"
.constant	k117	"MapCellCount"
.constant	k118	28
.constant	k119	20
.constant	k120	47
.constant	k121	140
.constant	k122	175
.constant	k123	248
.constant	k124	155
.constant	k125	90
.constant	k126	39
.constant	k127	182
.constant	k128	242
.constant	k129	56
.constant	k130	25
.constant	k131	113
.constant	k132	127
.constant	k133	200
.constant	k134	220
.constant	k135	227
.constant	k136	99
.constant	k137	253
.constant	k138	192
.constant	k139	101
.constant	k140	185
.constant	k141	102
.constant	k142	96
.constant	k143	174
.constant	k144	121
.constant	k145	73
.constant	k146	106
.constant	k147	157
.constant	k148	225
.constant	k149	68
.constant	k150	118
.constant	k151	131
.constant	k152	41
.constant	k153	"X"
.constant	k154	"Y"
.constant	k155	"StreamAffectCount"
.constant	k156	"bShowEntireMapStat"
.constant	k157	true
.constant	k158	"DelayUpdateGridColorsTime"
.constant	k159	0.3
.constant	k160	"DelayUpdateGridColorsTimerID"
.constant	k161	-1
.constant	k162	"DelayUpdateGridAssetCostTime"
.constant	k163	0.25
.constant	k164	"DelayUpdateGridAssetCostTimerIDMap"
.constant	k165	"IgnoreInstanceIDMap"
.constant	k166	"InitCostSetting"
.constant	k167	"InitInstanceCost"
.constant	k168	"InitMapInitAssetCost"
.constant	k169	"InitGroupManipulatorMutexLists"
.constant	k170	"GetGridTexture"
.constant	k171	"_RecomputeCustomUICost"
.constant	k172	"UpdateGridAssetCost"
.constant	k173	"SetAssetCostEnable"
.constant	k174	"AddInstanceValueListener"
.constant	k175	79
.constant	k176	145
.constant	k177	81
.constant	k178	35
.constant	k179	"OnInstanceIsPrefabChangeHandle"
.constant	k180	107
.constant	k181	80
.constant	k182	129
.constant	k183	178
.constant	k184	"OnInstanceTransformChangeHandle"
.constant	k185	126
.constant	k186	49
.constant	k187	143
.constant	k188	172
.constant	k189	61
.constant	k190	"OnInstanceMaterialIdChangeHandle"
.constant	k191	33
.constant	k192	83
.constant	k193	43
.constant	k194	40
.constant	k195	151
.constant	k196	"OnGroupManipulatorChanged"
.constant	k197	98
.constant	k198	64
.constant	k199	18
.constant	k200	46
.constant	k201	"OnObjectGroupChanged"
.constant	k202	100
.constant	k203	31
.constant	k204	"OnObjectInstanceCostChanged"
.constant	k205	105
.constant	k206	189
.constant	k207	19
.constant	k208	59
.constant	k209	231
.constant	k210	190
.constant	k211	L"OnInstanceDestructibleMeshParamChangeHandle"

.line	107	gettabup      r1    u0    k0 ; k0 = "__super"
.line	107	gettable      r1    r1    k1 ; k1 = "OnInitEditor"
.line	107	move          r2    r0
.line	107	call          r1     2     1
.line	107	loadbool      r1     0     0
.line	107	setupval      r1    u1
.line	107	getupval      r1    u2
.line	107	gettabup      r2    u3    k2 ; k2 = "bWriteLog"
.line	107	test          r2     0
.line	107	jmp            0   l63
.line	107	gettabup      r2    u3    k3 ; k3 = "table"
.line	107	gettable      r2    r2    k4 ; k4 = "concat"
.line	107	newtable      r3     1     0
.line	107	getupval      r4    u4
.line	107	loadk         r5    k5 ; k5 = 110
.line	107	loadk         r6    k6 ; k6 = 170
.line	107	loadk         r7    k7 ; k7 = 111
.line	107	loadk         r8    k8 ; k8 = 53
.line	107	loadk         r9    k9 ; k9 = 87
.line	107	loadk        r10   k10 ; k10 = 15
.line	107	loadk        r11   k11 ; k11 = 152
.line	107	loadk        r12   k12 ; k12 = 165
.line	107	loadk        r13   k13 ; k13 = 12
.line	107	loadk        r14   k14 ; k14 = 54
.line	107	loadk        r15   k15 ; k15 = 8
.line	107	loadk        r16   k16 ; k16 = 36
.line	107	loadk        r17   k17 ; k17 = 11
.line	107	loadk        r18   k18 ; k18 = 55
.line	107	loadk        r19   k19 ; k19 = 139
.line	107	loadk        r20   k20 ; k20 = 234
.line	107	loadk        r21   k21 ; k21 = 169
.line	107	loadk        r22   k22 ; k22 = 171
.line	107	loadk        r23   k23 ; k23 = 21
.line	107	loadk        r24   k24 ; k24 = 23
.line	107	loadk        r25   k25 ; k25 = 167
.line	107	loadk        r26   k26 ; k26 = 5
.line	107	loadk        r27   k27 ; k27 = 235
.line	107	loadk        r28   k28 ; k28 = 146
.line	107	loadk        r29   k29 ; k29 = 2
.line	107	loadk        r30   k30 ; k30 = 48
.line	107	loadk        r31   k10 ; k10 = 15
.line	107	loadk        r32   k31 ; k31 = 37
.line	107	loadk        r33   k32 ; k32 = 63
.line	107	loadk        r34   k33 ; k33 = 57
.line	107	loadk        r35   k34 ; k34 = 210
.line	107	loadk        r36   k35 ; k35 = 208
.line	107	loadk        r37   k36 ; k36 = 163
.line	107	loadk        r38   k37 ; k37 = 177
.line	107	loadk        r39   k38 ; k38 = 4
.line	107	loadk        r40   k39 ; k39 = 29
.line	107	loadk        r41   k40 ; k40 = 183
.line	107	loadk        r42   k41 ; k41 = 3
.line	107	loadk        r43   k20 ; k20 = 234
.line	107	loadk        r44   k42 ; k42 = 137
.line	107	call          r4    41     2
.line	107	getupval      r5    u4
.line	107	loadk         r6   k43 ; k43 = 89
.line	107	loadk         r7   k40 ; k40 = 183
.line	107	loadk         r8   k44 ; k44 = 120
.line	107	call          r5     4     0
.line	107	setlist       r3     0     1
.line	107	call          r2     2     2
.label	l63
.line	107	call          r1     2     1
.line	107	self          r1    r0   k45 ; k45 = "AddCommonEvent"
.line	107	gettabup      r3    u3   k46 ; k46 = "EVENTTYPE_CREATIVE"
.line	107	gettabup      r4    u3   k47 ; k47 = "EVENTID_INSTANCES_ED" (truncated)
.line	107	gettable      r5    r0   k48 ; k48 = "OnInstanceAdded"
.line	107	move          r6    r0
.line	107	call          r1     6     1
.line	107	self          r1    r0   k45 ; k45 = "AddCommonEvent"
.line	107	gettabup      r3    u3   k46 ; k46 = "EVENTTYPE_CREATIVE"
.line	107	gettabup      r4    u3   k49 ; k49 = "EVENTID_INSTANCES_ED" (truncated)
.line	107	gettable      r5    r0   k50 ; k50 = "OnInstanceRemoved"
.line	107	move          r6    r0
.line	107	call          r1     6     1
.line	107	settable      r0   k51   k52 ; k52 = 0
.line	107	settable      r0   k53   k54 ; k54 = false
.line	107	self          r1    r0   k45 ; k45 = "AddCommonEvent"
.line	107	gettabup      r3    u3   k46 ; k46 = "EVENTTYPE_CREATIVE"
.line	107	gettabup      r4    u3   k55 ; k55 = "EVENTID_CUSTOMUI_ENT" (truncated)
.line	107	gettable      r5    r0   k56 ; k56 = "_OnCustomUIEditorEnt" (truncated)
.line	107	move          r6    r0
.line	107	call          r1     6     1
.line	107	self          r1    r0   k45 ; k45 = "AddCommonEvent"
.line	107	gettabup      r3    u3   k46 ; k46 = "EVENTTYPE_CREATIVE"
.line	107	gettabup      r4    u3   k57 ; k57 = "EVENTID_CUSTOMUI_EXI" (truncated)
.line	107	gettable      r5    r0   k58 ; k58 = "_OnCustomUIEditorExi" (truncated)
.line	107	move          r6    r0
.line	107	call          r1     6     1
.line	107	self          r1    r0   k45 ; k45 = "AddCommonEvent"
.line	107	gettabup      r3    u3   k46 ; k46 = "EVENTTYPE_CREATIVE"
.line	107	gettabup      r4    u3   k59 ; k59 = "EVENTID_UMGINFO_MAP_" (truncated)
.line	107	gettable      r5    r0   k60 ; k60 = "_MarkCustomUICostDir" (truncated)
.line	107	move          r6    r0
.line	107	call          r1     6     1
.line	107	gettabup      r1    u3   k61 ; k61 = "slua_GameFrontendHUD"
.line	107	self          r1    r1   k62 ; k62 = "GetPlayerController"
.line	107	call          r1     2     2
.line	107	gettabup      r2    u5   k63 ; k63 = "GetLevelLandscapeBou" (truncated)
.line	107	move          r3    r1
.line	107	call          r2     2     2
.line	107	div           r3    r2   k29 ; k29 = 2
.line	107	gettabup      r4    u5   k65 ; k65 = "GetLandscapeMidPoint"
.line	107	move          r5    r1
.line	107	call          r4     2     2
.line	107	settable      r0   k64    r4 ; k64 = "MapCenterPos"
.line	107	gettabup      r4    u6   k67 ; k67 = "floor"
.line	107	gettabup      r5    u6   k68 ; k68 = "ceil"
.line	107	getupval      r6    u7
.line	107	div           r6    r3    r6
.line	107	call          r5     2     2
.line	107	div           r5    r3    r5
.line	107	call          r4     2     2
.line	107	settable      r0   k66    r4 ; k66 = "MapCellSize"
.line	107	gettable      r4    r0   k66 ; k66 = "MapCellSize"
.line	107	test          r4     0
.line	107	jmp            0  l125
.line	107	gettable      r4    r0   k66 ; k66 = "MapCellSize"
.line	107	lt             0   k52    r4 ; k52 = 0
.line	107	jmp            0  l125
.line	107	gettable      r4    r0   k66 ; k66 = "MapCellSize"
.line	107	gettabup      r5    u6   k69 ; k69 = "huge"
.line	107	lt             1    r4    r5
.line	107	jmp            0  l253
.label	l125
.line	107	getupval      r4    u2
.line	107	gettabup      r5    u3    k2 ; k2 = "bWriteLog"
.line	107	test          r5     0
.line	107	jmp            0  l250
.line	107	gettabup      r5    u3   k70 ; k70 = "string"
.line	107	gettable      r5    r5   k71 ; k71 = "format"
.line	107	gettabup      r6    u3    k3 ; k3 = "table"
.line	107	gettable      r6    r6    k4 ; k4 = "concat"
.line	107	newtable      r7     2     0
.line	107	getupval      r8    u4
.line	107	loadk         r9    k5 ; k5 = 110
.line	107	loadk        r10    k6 ; k6 = 170
.line	107	loadk        r11    k7 ; k7 = 111
.line	107	loadk        r12    k8 ; k8 = 53
.line	107	loadk        r13    k9 ; k9 = 87
.line	107	loadk        r14   k10 ; k10 = 15
.line	107	loadk        r15   k11 ; k11 = 152
.line	107	loadk        r16   k12 ; k12 = 165
.line	107	loadk        r17   k13 ; k13 = 12
.line	107	loadk        r18   k14 ; k14 = 54
.line	107	loadk        r19   k15 ; k15 = 8
.line	107	loadk        r20   k16 ; k16 = 36
.line	107	loadk        r21   k17 ; k17 = 11
.line	107	loadk        r22   k18 ; k18 = 55
.line	107	loadk        r23   k19 ; k19 = 139
.line	107	loadk        r24   k20 ; k20 = 234
.line	107	loadk        r25   k21 ; k21 = 169
.line	107	loadk        r26   k22 ; k22 = 171
.line	107	loadk        r27   k23 ; k23 = 21
.line	107	loadk        r28   k24 ; k24 = 23
.line	107	loadk        r29   k25 ; k25 = 167
.line	107	loadk        r30   k26 ; k26 = 5
.line	107	loadk        r31   k27 ; k27 = 235
.line	107	loadk        r32   k28 ; k28 = 146
.line	107	loadk        r33   k29 ; k29 = 2
.line	107	loadk        r34   k30 ; k30 = 48
.line	107	loadk        r35   k10 ; k10 = 15
.line	107	loadk        r36   k31 ; k31 = 37
.line	107	loadk        r37   k32 ; k32 = 63
.line	107	loadk        r38   k33 ; k33 = 57
.line	107	loadk        r39   k34 ; k34 = 210
.line	107	loadk        r40   k35 ; k35 = 208
.line	107	loadk        r41   k36 ; k36 = 163
.line	107	loadk        r42   k37 ; k37 = 177
.line	107	loadk        r43   k38 ; k38 = 4
.line	107	loadk        r44   k39 ; k39 = 29
.line	107	loadk        r45   k40 ; k40 = 183
.line	107	loadk        r46   k41 ; k41 = 3
.line	107	loadk        r47   k20 ; k20 = 234
.line	107	loadk        r48   k42 ; k42 = 137
.line	107	call          r8    41     2
.line	107	getupval      r9    u4
.line	107	loadk        r10   k43 ; k43 = 89
.line	107	loadk        r11   k40 ; k40 = 183
.line	107	loadk        r12   k44 ; k44 = 120
.line	107	loadk        r13   k72 ; k72 = 116
.line	107	loadk        r14   k73 ; k73 = 74
.line	107	loadk        r15   k15 ; k15 = 8
.line	107	loadk        r16   k11 ; k11 = 152
.line	107	loadk        r17   k74 ; k74 = 161
.line	107	loadk        r18   k75 ; k75 = 45
.line	107	loadk        r19   k30 ; k30 = 48
.line	107	loadk        r20   k15 ; k15 = 8
.line	107	loadk        r21   k76 ; k76 = 97
.line	107	loadk        r22   k77 ; k77 = 7
.line	107	loadk        r23   k31 ; k31 = 37
.line	107	loadk        r24   k78 ; k78 = 136
.line	107	loadk        r25   k79 ; k79 = 204
.line	107	loadk        r26   k80 ; k80 = 184
.line	107	loadk        r27   k81 ; k81 = 132
.line	107	loadk        r28   k82 ; k82 = 22
.line	107	loadk        r29   k18 ; k18 = 55
.line	107	loadk        r30   k83 ; k83 = 186
.line	107	loadk        r31   k84 ; k84 = 44
.line	107	loadk        r32   k85 ; k85 = 251
.line	107	loadk        r33   k86 ; k86 = 202
.line	107	loadk        r34   k72 ; k72 = 116
.line	107	loadk        r35   k87 ; k87 = 58
.line	107	loadk        r36   k88 ; k88 = 92
.line	107	loadk        r37   k39 ; k39 = 29
.line	107	loadk        r38   k32 ; k32 = 63
.line	107	loadk        r39   k89 ; k89 = 34
.line	107	loadk        r40   k90 ; k90 = 141
.line	107	loadk        r41   k91 ; k91 = 243
.line	107	loadk        r42   k78 ; k78 = 136
.line	107	loadk        r43   k92 ; k92 = 128
.line	107	loadk        r44   k93 ; k93 = 30
.line	107	loadk        r45   k94 ; k94 = 17
.line	107	loadk        r46   k95 ; k95 = 173
.line	107	loadk        r47   k96 ; k96 = 50
.line	107	loadk        r48   k97 ; k97 = 180
.line	107	loadk        r49   k98 ; k98 = 197
.line	107	call          r9    41     2
.line	107	getupval     r10    u4
.line	107	loadk        r11   k99 ; k99 = 94
.line	107	loadk        r12  k100 ; k100 = 244
.line	107	loadk        r13  k101 ; k101 = 42
.line	107	loadk        r14   k96 ; k96 = 50
.line	107	loadk        r15  k102 ; k102 = 66
.line	107	loadk        r16  k103 ; k103 = 10
.line	107	loadk        r17  k104 ; k104 = 130
.line	107	loadk        r18  k105 ; k105 = 162
.line	107	loadk        r19  k106 ; k106 = 32
.line	107	loadk        r20   k87 ; k87 = 58
.line	107	loadk        r21   k77 ; k77 = 7
.line	107	loadk        r22   k76 ; k76 = 97
.line	107	loadk        r23  k107 ; k107 = 9
.line	107	loadk        r24  k108 ; k108 = 1
.line	107	loadk        r25   k97 ; k97 = 180
.line	107	loadk        r26  k109 ; k109 = 195
.line	107	loadk        r27  k104 ; k104 = 130
.line	107	loadk        r28  k110 ; k110 = 187
.line	107	loadk        r29  k111 ; k111 = 51
.line	107	loadk        r30  k112 ; k112 = 62
.line	107	loadk        r31  k113 ; k113 = 150
.line	107	call         r10    22     0
.line	107	setlist       r7     0     1
.line	107	call          r6     2     2
.line	107	gettabup      r7    u3  k114 ; k114 = "tostring"
.line	107	gettable      r8    r0   k66 ; k66 = "MapCellSize"
.line	107	call          r7     2     2
.line	107	gettabup      r8    u3  k114 ; k114 = "tostring"
.line	107	move          r9    r2
.line	107	call          r8     2     0
.line	107	call          r5     0     2
.label	l250
.line	107	call          r4     2     1
.line	107	getupval      r4    u7
.line	107	settable      r0   k66    r4 ; k66 = "MapCellSize"
.label	l253
.line	107	gettabup      r4    u6  k116 ; k116 = "max"
.line	107	gettabup      r5    u6   k67 ; k67 = "floor"
.line	107	gettable      r6    r0   k66 ; k66 = "MapCellSize"
.line	107	div           r6    r3    r6
.line	107	call          r5     2     2
.line	107	loadk         r6  k108 ; k108 = 1
.line	107	call          r4     3     2
.line	107	settable      r0  k115    r4 ; k115 = "MapCellHalfCount"
.line	107	gettable      r4    r0  k115 ; k115 = "MapCellHalfCount"
.line	107	mul           r4    r4   k29 ; k29 = 2
.line	107	settable      r0  k117    r4 ; k117 = "MapCellCount"
.line	107	getupval      r4    u2
.line	107	gettabup      r5    u3    k2 ; k2 = "bWriteLog"
.line	107	test          r5     0
.line	107	jmp            0  l388
.line	107	gettabup      r5    u3    k3 ; k3 = "table"
.line	107	gettable      r5    r5    k4 ; k4 = "concat"
.line	107	newtable      r6     2     0
.line	107	getupval      r7    u4
.line	107	loadk         r8    k5 ; k5 = 110
.line	107	loadk         r9    k6 ; k6 = 170
.line	107	loadk        r10    k7 ; k7 = 111
.line	107	loadk        r11    k8 ; k8 = 53
.line	107	loadk        r12    k9 ; k9 = 87
.line	107	loadk        r13   k10 ; k10 = 15
.line	107	loadk        r14   k11 ; k11 = 152
.line	107	loadk        r15   k12 ; k12 = 165
.line	107	loadk        r16   k13 ; k13 = 12
.line	107	loadk        r17   k14 ; k14 = 54
.line	107	loadk        r18   k15 ; k15 = 8
.line	107	loadk        r19   k16 ; k16 = 36
.line	107	loadk        r20   k17 ; k17 = 11
.line	107	loadk        r21   k18 ; k18 = 55
.line	107	loadk        r22   k19 ; k19 = 139
.line	107	loadk        r23   k20 ; k20 = 234
.line	107	loadk        r24   k21 ; k21 = 169
.line	107	loadk        r25   k22 ; k22 = 171
.line	107	loadk        r26   k23 ; k23 = 21
.line	107	loadk        r27   k24 ; k24 = 23
.line	107	loadk        r28   k25 ; k25 = 167
.line	107	loadk        r29   k26 ; k26 = 5
.line	107	loadk        r30   k27 ; k27 = 235
.line	107	loadk        r31   k28 ; k28 = 146
.line	107	loadk        r32   k29 ; k29 = 2
.line	107	loadk        r33   k30 ; k30 = 48
.line	107	loadk        r34   k10 ; k10 = 15
.line	107	loadk        r35   k31 ; k31 = 37
.line	107	loadk        r36   k32 ; k32 = 63
.line	107	loadk        r37   k33 ; k33 = 57
.line	107	loadk        r38   k34 ; k34 = 210
.line	107	loadk        r39   k35 ; k35 = 208
.line	107	loadk        r40   k36 ; k36 = 163
.line	107	loadk        r41   k37 ; k37 = 177
.line	107	loadk        r42   k38 ; k38 = 4
.line	107	loadk        r43   k39 ; k39 = 29
.line	107	loadk        r44   k40 ; k40 = 183
.line	107	loadk        r45   k41 ; k41 = 3
.line	107	loadk        r46   k20 ; k20 = 234
.line	107	loadk        r47   k42 ; k42 = 137
.line	107	call          r7    41     2
.line	107	getupval      r8    u4
.line	107	loadk         r9   k43 ; k43 = 89
.line	107	loadk        r10   k40 ; k40 = 183
.line	107	loadk        r11   k44 ; k44 = 120
.line	107	loadk        r12   k72 ; k72 = 116
.line	107	loadk        r13    k7 ; k7 = 111
.line	107	loadk        r14   k41 ; k41 = 3
.line	107	loadk        r15   k11 ; k11 = 152
.line	107	loadk        r16   k12 ; k12 = 165
.line	107	loadk        r17   k75 ; k75 = 45
.line	107	loadk        r18  k118 ; k118 = 28
.line	107	loadk        r19  k119 ; k119 = 20
.line	107	loadk        r20    k8 ; k8 = 53
.line	107	loadk        r21  k120 ; k120 = 47
.line	107	loadk        r22  k101 ; k101 = 42
.line	107	loadk        r23  k121 ; k121 = 140
.line	107	loadk        r24  k122 ; k122 = 175
.line	107	loadk        r25  k123 ; k123 = 248
.line	107	loadk        r26  k124 ; k124 = 155
.line	107	loadk        r27  k125 ; k125 = 90
.line	107	loadk        r28  k126 ; k126 = 39
.line	107	loadk        r29  k127 ; k127 = 182
.line	107	loadk        r30   k87 ; k87 = 58
.line	107	loadk        r31  k128 ; k128 = 242
.line	107	loadk        r32   k36 ; k36 = 163
.line	107	loadk        r33  k129 ; k129 = 56
.line	107	loadk        r34  k111 ; k111 = 51
.line	107	loadk        r35  k130 ; k130 = 25
.line	107	loadk        r36  k131 ; k131 = 113
.line	107	loadk        r37  k132 ; k132 = 127
.line	107	loadk        r38  k126 ; k126 = 39
.line	107	loadk        r39  k133 ; k133 = 200
.line	107	loadk        r40  k134 ; k134 = 220
.line	107	loadk        r41  k105 ; k105 = 162
.line	107	loadk        r42   k90 ; k90 = 141
.line	107	loadk        r43   k38 ; k38 = 4
.line	107	loadk        r44   k52 ; k52 = 0
.line	107	loadk        r45  k135 ; k135 = 227
.line	107	loadk        r46  k136 ; k136 = 99
.line	107	loadk        r47  k137 ; k137 = 253
.line	107	loadk        r48  k138 ; k138 = 192
.line	107	call          r8    41     2
.line	107	getupval      r9    u4
.line	107	loadk        r10  k139 ; k139 = 101
.line	107	loadk        r11  k140 ; k140 = 185
.line	107	loadk        r12  k141 ; k141 = 102
.line	107	loadk        r13   k96 ; k96 = 50
.line	107	loadk        r14  k142 ; k142 = 96
.line	107	loadk        r15  k107 ; k107 = 9
.line	107	loadk        r16  k124 ; k124 = 155
.line	107	loadk        r17  k143 ; k143 = 174
.line	107	loadk        r18    k8 ; k8 = 53
.line	107	loadk        r19  k144 ; k144 = 121
.line	107	loadk        r20  k145 ; k145 = 73
.line	107	loadk        r21   k96 ; k96 = 50
.line	107	loadk        r22  k146 ; k146 = 106
.line	107	loadk        r23   k77 ; k77 = 7
.line	107	loadk        r24  k147 ; k147 = 157
.line	107	loadk        r25  k148 ; k148 = 225
.line	107	loadk        r26   k21 ; k21 = 169
.line	107	loadk        r27   k90 ; k90 = 141
.line	107	loadk        r28   k15 ; k15 = 8
.line	107	loadk        r29  k149 ; k149 = 68
.line	107	loadk        r30   k22 ; k22 = 171
.line	107	loadk        r31  k150 ; k150 = 118
.line	107	loadk        r32  k110 ; k110 = 187
.line	107	loadk        r33  k151 ; k151 = 131
.line	107	loadk        r34  k131 ; k131 = 113
.line	107	loadk        r35   k30 ; k30 = 48
.line	107	loadk        r36   k88 ; k88 = 92
.line	107	loadk        r37   k72 ; k72 = 116
.line	107	loadk        r38  k152 ; k152 = 41
.line	107	call          r9    30     0
.line	107	setlist       r6     0     1
.line	107	call          r5     2     2
.label	l388
.line	107	gettabup      r6    u3  k114 ; k114 = "tostring"
.line	107	move          r7    r2
.line	107	call          r6     2     2
.line	107	gettabup      r7    u3  k114 ; k114 = "tostring"
.line	107	gettable      r8    r0   k66 ; k66 = "MapCellSize"
.line	107	call          r7     2     2
.line	107	gettable      r8    r0  k117 ; k117 = "MapCellCount"
.line	107	gettable      r9    r0  k115 ; k115 = "MapCellHalfCount"
.line	107	gettable     r10    r0   k64 ; k64 = "MapCenterPos"
.line	107	gettable     r10   r10  k153 ; k153 = "X"
.line	107	gettable     r11    r0   k64 ; k64 = "MapCenterPos"
.line	107	gettable     r11   r11  k154 ; k154 = "Y"
.line	107	call          r4     8     1
.line	107	settable      r0  k155  k108 ; k108 = 1
.line	107	settable      r0  k156  k157 ; k157 = true
.line	107	settable      r0  k158  k159 ; k159 = 0.3
.line	107	settable      r0  k160  k161 ; k161 = -1
.line	107	settable      r0  k162  k163 ; k163 = 0.25
.line	107	newtable      r4     0     0
.line	107	settable      r0  k164    r4 ; k164 = "DelayUpdateGridAsset" (truncated)
.line	107	newtable      r4     0     0
.line	107	settable      r0  k165    r4 ; k165 = "IgnoreInstanceIDMap"
.line	107	self          r4    r0  k166 ; k166 = "InitCostSetting"
.line	107	call          r4     2     1
.line	107	self          r4    r0  k167 ; k167 = "InitInstanceCost"
.line	107	call          r4     2     1
.line	107	self          r4    r0  k168 ; k168 = "InitMapInitAssetCost"
.line	107	call          r4     2     1
.line	107	self          r4    r0  k169 ; k169 = "InitGroupManipulator" (truncated)
.line	107	call          r4     2     1
.line	107	self          r4    r0  k170 ; k170 = "GetGridTexture"
.line	107	call          r4     2     1
.line	107	self          r4    r0  k171 ; k171 = "_RecomputeCustomUICo" (truncated)
.line	107	call          r4     2     1
.line	107	self          r4    r0  k172 ; k172 = "UpdateGridAssetCost"
.line	107	call          r4     2     1
.line	107	self          r4    r0  k173 ; k173 = "SetAssetCostEnable"
.line	107	loadbool      r6     1     0
.line	107	call          r4     3     1
.line	107	self          r4    r0  k174 ; k174 = "AddInstanceValueList" (truncated)
.line	107	getupval      r6    u4
.line	107	loadk         r7  k175 ; k175 = 79
.line	107	loadk         r8  k176 ; k176 = 145
.line	107	loadk         r9  k144 ; k144 = 121
.line	107	loadk        r10   k38 ; k38 = 4
.line	107	loadk        r11  k177 ; k177 = 81
.line	107	loadk        r12   k41 ; k41 = 3
.line	107	loadk        r13   k78 ; k78 = 136
.line	107	loadk        r14   k74 ; k74 = 161
.line	107	loadk        r15  k178 ; k178 = 35
.line	107	call          r6    10     2
.line	107	loadbool      r7     1     0
.line	107	gettable      r8    r0  k179 ; k179 = "OnInstanceIsPrefabCh" (truncated)
.line	107	move          r9    r0
.line	107	call          r4     6     1
.line	107	self          r4    r0  k174 ; k174 = "AddInstanceValueList" (truncated)
.line	107	getupval      r6    u4
.line	107	loadk         r7  k144 ; k144 = 121
.line	107	loadk         r8    k6 ; k6 = 170
.line	107	loadk         r9  k180 ; k180 = 107
.line	107	loadk        r10   k87 ; k87 = 58
.line	107	loadk        r11  k181 ; k181 = 80
.line	107	loadk        r12   k52 ; k52 = 0
.line	107	loadk        r13  k182 ; k182 = 129
.line	107	loadk        r14  k183 ; k183 = 178
.line	107	loadk        r15   k84 ; k84 = 44
.line	107	call          r6    10     2
.line	107	loadbool      r7     1     0
.line	107	gettable      r8    r0  k184 ; k184 = "OnInstanceTransformC" (truncated)
.line	107	move          r9    r0
.line	107	call          r4     6     1
.line	107	self          r4    r0  k174 ; k174 = "AddInstanceValueList" (truncated)
.line	107	getupval      r6    u4
.line	107	loadk         r7  k142 ; k142 = 96
.line	107	loadk         r8  k140 ; k140 = 185
.line	107	loadk         r9  k185 ; k185 = 126
.line	107	loadk        r10  k186 ; k186 = 49
.line	107	loadk        r11  k177 ; k177 = 81
.line	107	loadk        r12   k10 ; k10 = 15
.line	107	loadk        r13  k187 ; k187 = 143
.line	107	loadk        r14  k188 ; k188 = 172
.line	107	loadk        r15   k15 ; k15 = 8
.line	107	loadk        r16  k189 ; k189 = 61
.line	107	call          r6    11     2
.line	107	loadbool      r7     1     0
.line	107	gettable      r8    r0  k190 ; k190 = "OnInstanceMaterialId" (truncated)
.line	107	move          r9    r0
.line	107	call          r4     6     1
.line	107	self          r4    r0  k174 ; k174 = "AddInstanceValueList" (truncated)
.line	107	getupval      r6    u4
.line	107	loadk         r7  k146 ; k146 = 106
.line	107	loadk         r8    k6 ; k6 = 170
.line	107	loadk         r9  k139 ; k139 = 101
.line	107	loadk        r10  k191 ; k191 = 33
.line	107	loadk        r11  k192 ; k192 = 83
.line	107	loadk        r12  k193 ; k193 = 43
.line	107	loadk        r13  k187 ; k187 = 143
.line	107	loadk        r14  k143 ; k143 = 174
.line	107	loadk        r15  k194 ; k194 = 40
.line	107	loadk        r16  k152 ; k152 = 41
.line	107	loadk        r17  k130 ; k130 = 25
.line	107	loadk        r18   k75 ; k75 = 45
.line	107	loadk        r19  k193 ; k193 = 43
.line	107	loadk        r20   k30 ; k30 = 48
.line	107	loadk        r21  k195 ; k195 = 151
.line	107	loadk        r22  k137 ; k137 = 253
.line	107	call          r6    17     2
.line	107	loadbool      r7     1     0
.line	107	gettable      r8    r0  k196 ; k196 = "OnGroupManipulatorCh" (truncated)
.line	107	move          r9    r0
.line	107	call          r4     6     1
.line	107	self          r4    r0  k174 ; k174 = "AddInstanceValueList" (truncated)
.line	107	getupval      r6    u4
.line	107	loadk         r7  k197 ; k197 = 98
.line	107	loadk         r8   k83 ; k83 = 186
.line	107	loadk         r9  k142 ; k142 = 96
.line	107	loadk        r10  k186 ; k186 = 49
.line	107	loadk        r11  k198 ; k198 = 64
.line	107	loadk        r12  k199 ; k199 = 18
.line	107	loadk        r13   k21 ; k21 = 169
.line	107	loadk        r14  k183 ; k183 = 178
.line	107	loadk        r15  k200 ; k200 = 46
.line	107	loadk        r16   k84 ; k84 = 44
.line	107	loadk        r17  k118 ; k118 = 28
.line	107	call          r6    12     2
.line	107	loadbool      r7     1     0
.line	107	gettable      r8    r0  k201 ; k201 = "OnObjectGroupChanged"
.line	107	move          r9    r0
.line	107	call          r4     6     1
.line	107	self          r4    r0  k174 ; k174 = "AddInstanceValueList" (truncated)
.line	107	getupval      r6    u4
.line	107	loadk         r7  k202 ; k202 = 100
.line	107	loadk         r8  k127 ; k127 = 182
.line	107	loadk         r9  k144 ; k144 = 121
.line	107	loadk        r10  k106 ; k106 = 32
.line	107	loadk        r11  k102 ; k102 = 66
.line	107	loadk        r12   k15 ; k15 = 8
.line	107	loadk        r13   k90 ; k90 = 141
.line	107	loadk        r14   k12 ; k12 = 165
.line	107	loadk        r15   k29 ; k29 = 2
.line	107	loadk        r16   k14 ; k14 = 54
.line	107	loadk        r17  k203 ; k203 = 31
.line	107	loadk        r18    k8 ; k8 = 53
.line	107	call          r6    13     2
.line	107	loadbool      r7     1     0
.line	107	gettable      r8    r0  k204 ; k204 = "OnObjectInstanceCost" (truncated)
.line	107	move          r9    r0
.line	107	call          r4     6     1
.line	107	self          r4    r0  k174 ; k174 = "AddInstanceValueList" (truncated)
.line	107	getupval      r6    u4
.line	107	loadk         r7  k205 ; k205 = 105
.line	107	loadk         r8  k206 ; k206 = 189
.line	107	loadk         r9  k144 ; k144 = 121
.line	107	loadk        r10  k106 ; k106 = 32
.line	107	loadk        r11  k177 ; k177 = 81
.line	107	loadk        r12  k207 ; k207 = 19
.line	107	loadk        r13   k90 ; k90 = 141
.line	107	loadk        r14   k97 ; k97 = 180
.line	107	loadk        r15  k194 ; k194 = 40
.line	107	loadk        r16  k208 ; k208 = 59
.line	107	loadk        r17   k52 ; k52 = 0
.line	107	loadk        r18   k16 ; k16 = 36
.line	107	loadk        r19   k77 ; k77 = 7
.line	107	loadk        r20  k191 ; k191 = 33
.line	107	loadk        r21   k19 ; k19 = 139
.line	107	loadk        r22  k209 ; k209 = 231
.line	107	loadk        r23   k90 ; k90 = 141
.line	107	loadk        r24   k42 ; k42 = 137
.line	107	loadk        r25   k15 ; k15 = 8
.line	107	loadk        r26   k26 ; k26 = 5
.line	107	loadk        r27  k210 ; k210 = 190
.line	107	call          r6    22     2
.line	107	loadbool      r7     1     0
.line	107	gettable      r8    r0  k211 ; k211 = L"OnInstanceDestructib" (truncated)
.line	107	move          r9    r0
.line	107	call          r4     6     1
.line	107	return        r0     1
.line	107	gettabup      r0    u0  k134 ; k134 = 220
.line	107	return        r0     1

.function	main/f4

.source	null
.linedefined	154
.lastlinedefined	179
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	24	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	2	true

.constant	k0	"bWriteLog"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	110
.constant	k4	170
.constant	k5	111
.constant	k6	53
.constant	k7	87
.constant	k8	15
.constant	k9	152
.constant	k10	165
.constant	k11	12
.constant	k12	54
.constant	k13	8
.constant	k14	36
.constant	k15	11
.constant	k16	55
.constant	k17	139
.constant	k18	234
.constant	k19	169
.constant	k20	171
.constant	k21	21
.constant	k22	23
.constant	k23	167
.constant	k24	5
.constant	k25	235
.constant	k26	146
.constant	k27	2
.constant	k28	48
.constant	k29	37
.constant	k30	63
.constant	k31	57
.constant	k32	210
.constant	k33	208
.constant	k34	163
.constant	k35	24
.constant	k36	166
.constant	k37	39
.constant	k38	253
.constant	k39	133
.constant	k40	104
.constant	k41	188
.constant	k42	99
.constant	k43	32
.constant	k44	76
.constant	k45	20
.constant	k46	"RemoveCommonEvent"
.constant	k47	"EVENTTYPE_CREATIVE"
.constant	k48	"EVENTID_INSTANCES_EDIT_ADDED"
.constant	k49	"EVENTID_INSTANCES_EDIT_REMOVED"
.constant	k50	"EVENTID_INSTANCES_EDIT_CHANGED"
.constant	k51	"EVENTID_CUSTOMUI_ENTER_EDITOR"
.constant	k52	"EVENTID_CUSTOMUI_EXIT_EDITOR"
.constant	k53	"EVENTID_UMGINFO_MAP_CHANGED"
.constant	k54	"_CustomUICostTimerID"
.constant	k55	"RemoveGameTimer"
.constant	k56	nil
.constant	k57	"ClearDelayUpdateGridColorsTimer"
.constant	k58	"ClearDelayUpdateGridAssetCostTimer"
.constant	k59	"RepeatedComputeCostMap"
.constant	k60	"InstanceGrid"
.constant	k61	"InstanceGridCost"
.constant	k62	"InstanceGridCombineCost"
.constant	k63	"AlwaysLoadInstancesCost"
.constant	k64	0
.constant	k65	"bShowEntireMapStat"
.constant	k66	"NearGridIndexList"
.constant	k67	"ChangedInstances"
.constant	k68	"IgnoreInstanceIDMap"
.constant	k69	"__super"
.constant	k70	"OnReleaseEditor"
.constant	k71	"SetAssetCostEnable"

.line	154	getupval      r1    u0
.line	154	gettabup      r2    u1    k0 ; k0 = "bWriteLog"
.line	154	test          r2     0
.line	154	jmp            0   l60
.line	154	gettabup      r2    u1    k1 ; k1 = "table"
.line	154	gettable      r2    r2    k2 ; k2 = "concat"
.line	154	newtable      r3     1     0
.line	154	getupval      r4    u2
.line	154	loadk         r5    k3 ; k3 = 110
.line	154	loadk         r6    k4 ; k4 = 170
.line	154	loadk         r7    k5 ; k5 = 111
.line	154	loadk         r8    k6 ; k6 = 53
.line	154	loadk         r9    k7 ; k7 = 87
.line	154	loadk        r10    k8 ; k8 = 15
.line	154	loadk        r11    k9 ; k9 = 152
.line	154	loadk        r12   k10 ; k10 = 165
.line	154	loadk        r13   k11 ; k11 = 12
.line	154	loadk        r14   k12 ; k12 = 54
.line	154	loadk        r15   k13 ; k13 = 8
.line	154	loadk        r16   k14 ; k14 = 36
.line	154	loadk        r17   k15 ; k15 = 11
.line	154	loadk        r18   k16 ; k16 = 55
.line	154	loadk        r19   k17 ; k17 = 139
.line	154	loadk        r20   k18 ; k18 = 234
.line	154	loadk        r21   k19 ; k19 = 169
.line	154	loadk        r22   k20 ; k20 = 171
.line	154	loadk        r23   k21 ; k21 = 21
.line	154	loadk        r24   k22 ; k22 = 23
.line	154	loadk        r25   k23 ; k23 = 167
.line	154	loadk        r26   k24 ; k24 = 5
.line	154	loadk        r27   k25 ; k25 = 235
.line	154	loadk        r28   k26 ; k26 = 146
.line	154	loadk        r29   k27 ; k27 = 2
.line	154	loadk        r30   k28 ; k28 = 48
.line	154	loadk        r31    k8 ; k8 = 15
.line	154	loadk        r32   k29 ; k29 = 37
.line	154	loadk        r33   k30 ; k30 = 63
.line	154	loadk        r34   k31 ; k31 = 57
.line	154	loadk        r35   k32 ; k32 = 210
.line	154	loadk        r36   k33 ; k33 = 208
.line	154	loadk        r37   k34 ; k34 = 163
.line	154	loadk        r38    k4 ; k4 = 170
.line	154	loadk        r39    k8 ; k8 = 15
.line	154	loadk        r40   k35 ; k35 = 24
.line	154	loadk        r41   k36 ; k36 = 166
.line	154	loadk        r42   k37 ; k37 = 39
.line	154	loadk        r43   k38 ; k38 = 253
.line	154	loadk        r44   k39 ; k39 = 133
.line	154	call          r4    41     2
.line	154	getupval      r5    u2
.line	154	loadk         r6   k40 ; k40 = 104
.line	154	loadk         r7   k41 ; k41 = 188
.line	154	loadk         r8   k42 ; k42 = 99
.line	154	loadk         r9   k43 ; k43 = 32
.line	154	loadk        r10   k44 ; k44 = 76
.line	154	loadk        r11   k45 ; k45 = 20
.line	154	call          r5     7     0
.line	154	setlist       r3     0     1
.line	154	call          r2     2     2
.label	l60
.line	154	call          r1     2     1
.line	154	self          r1    r0   k46 ; k46 = "RemoveCommonEvent"
.line	154	gettabup      r3    u1   k47 ; k47 = "EVENTTYPE_CREATIVE"
.line	154	gettabup      r4    u1   k48 ; k48 = "EVENTID_INSTANCES_ED" (truncated)
.line	154	call          r1     4     1
.line	154	self          r1    r0   k46 ; k46 = "RemoveCommonEvent"
.line	154	gettabup      r3    u1   k47 ; k47 = "EVENTTYPE_CREATIVE"
.line	154	gettabup      r4    u1   k49 ; k49 = "EVENTID_INSTANCES_ED" (truncated)
.line	154	call          r1     4     1
.line	154	self          r1    r0   k46 ; k46 = "RemoveCommonEvent"
.line	154	gettabup      r3    u1   k47 ; k47 = "EVENTTYPE_CREATIVE"
.line	154	gettabup      r4    u1   k50 ; k50 = "EVENTID_INSTANCES_ED" (truncated)
.line	154	call          r1     4     1
.line	154	self          r1    r0   k46 ; k46 = "RemoveCommonEvent"
.line	154	gettabup      r3    u1   k47 ; k47 = "EVENTTYPE_CREATIVE"
.line	154	gettabup      r4    u1   k51 ; k51 = "EVENTID_CUSTOMUI_ENT" (truncated)
.line	154	call          r1     4     1
.line	154	self          r1    r0   k46 ; k46 = "RemoveCommonEvent"
.line	154	gettabup      r3    u1   k47 ; k47 = "EVENTTYPE_CREATIVE"
.line	154	gettabup      r4    u1   k52 ; k52 = "EVENTID_CUSTOMUI_EXI" (truncated)
.line	154	call          r1     4     1
.line	154	self          r1    r0   k46 ; k46 = "RemoveCommonEvent"
.line	154	gettabup      r3    u1   k47 ; k47 = "EVENTTYPE_CREATIVE"
.line	154	gettabup      r4    u1   k53 ; k53 = "EVENTID_UMGINFO_MAP_" (truncated)
.line	154	call          r1     4     1
.line	154	gettable      r1    r0   k54 ; k54 = "_CustomUICostTimerID"
.line	154	test          r1     0
.line	154	jmp            0   l92
.line	154	self          r1    r0   k55 ; k55 = "RemoveGameTimer"
.line	154	gettable      r3    r0   k54 ; k54 = "_CustomUICostTimerID"
.line	154	call          r1     3     1
.line	154	settable      r0   k54   k56 ; k56 = nil
.label	l92
.line	154	self          r1    r0   k57 ; k57 = "ClearDelayUpdateGrid" (truncated)
.line	154	call          r1     2     1
.line	154	self          r1    r0   k58 ; k58 = "ClearDelayUpdateGrid" (truncated)
.line	154	call          r1     2     1
.line	154	settable      r0   k59   k56 ; k56 = nil
.line	154	settable      r0   k60   k56 ; k56 = nil
.line	154	settable      r0   k61   k56 ; k56 = nil
.line	154	settable      r0   k62   k56 ; k56 = nil
.line	154	settable      r0   k63   k64 ; k64 = 0
.line	154	settable      r0   k65   k56 ; k56 = nil
.line	154	settable      r0   k66   k56 ; k56 = nil
.line	154	settable      r0   k67   k56 ; k56 = nil
.line	154	newtable      r1     0     0
.line	154	settable      r0   k68    r1 ; k68 = "IgnoreInstanceIDMap"
.line	154	gettabup      r1    u3   k69 ; k69 = "__super"
.line	154	gettable      r1    r1   k70 ; k70 = "OnReleaseEditor"
.line	154	move          r2    r0
.line	154	call          r1     2     1
.line	154	self          r1    r0   k71 ; k71 = "SetAssetCostEnable"
.line	154	loadbool      r3     0     0
.line	154	call          r1     3     1
.line	154	return        r0     1
.line	154	move          r0    r0
.line	154	move          r0    r0
.line	154	move          r0    r0
.line	154	return        r0     1

.function	main/f5

.source	null
.linedefined	181
.lastlinedefined	187
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	2	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"__super"
.constant	k1	"OnInitGame"
.constant	k2	"print"
.constant	k3	"bWriteLog"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	110
.constant	k7	170
.constant	k8	111
.constant	k9	53
.constant	k10	87
.constant	k11	15
.constant	k12	152
.constant	k13	165
.constant	k14	12
.constant	k15	54
.constant	k16	8
.constant	k17	36
.constant	k18	11
.constant	k19	55
.constant	k20	139
.constant	k21	234
.constant	k22	169
.constant	k23	171
.constant	k24	21
.constant	k25	23
.constant	k26	167
.constant	k27	5
.constant	k28	235
.constant	k29	146
.constant	k30	2
.constant	k31	48
.constant	k32	37
.constant	k33	63
.constant	k34	57
.constant	k35	210
.constant	k36	208
.constant	k37	163
.constant	k38	177
.constant	k39	4
.constant	k40	29
.constant	k41	183
.constant	k42	1
.constant	k43	239
.constant	k44	141
.constant	k45	72
.constant	k46	"IsDedicatedServer"
.constant	k47	"IsPlayTest"
.constant	k48	"_RegisterApplyFPSLimitListeners"

.line	181	gettabup      r1    u0    k0 ; k0 = "__super"
.line	181	gettable      r1    r1    k1 ; k1 = "OnInitGame"
.line	181	move          r2    r0
.line	181	call          r1     2     1
.line	181	gettabup      r1    u1    k2 ; k2 = "print"
.line	181	gettabup      r2    u1    k3 ; k3 = "bWriteLog"
.line	181	test          r2     0
.line	181	jmp            0   l59
.line	181	gettabup      r2    u1    k4 ; k4 = "table"
.line	181	gettable      r2    r2    k5 ; k5 = "concat"
.line	181	newtable      r3     1     0
.line	181	getupval      r4    u2
.line	181	loadk         r5    k6 ; k6 = 110
.line	181	loadk         r6    k7 ; k7 = 170
.line	181	loadk         r7    k8 ; k8 = 111
.line	181	loadk         r8    k9 ; k9 = 53
.line	181	loadk         r9   k10 ; k10 = 87
.line	181	loadk        r10   k11 ; k11 = 15
.line	181	loadk        r11   k12 ; k12 = 152
.line	181	loadk        r12   k13 ; k13 = 165
.line	181	loadk        r13   k14 ; k14 = 12
.line	181	loadk        r14   k15 ; k15 = 54
.line	181	loadk        r15   k16 ; k16 = 8
.line	181	loadk        r16   k17 ; k17 = 36
.line	181	loadk        r17   k18 ; k18 = 11
.line	181	loadk        r18   k19 ; k19 = 55
.line	181	loadk        r19   k20 ; k20 = 139
.line	181	loadk        r20   k21 ; k21 = 234
.line	181	loadk        r21   k22 ; k22 = 169
.line	181	loadk        r22   k23 ; k23 = 171
.line	181	loadk        r23   k24 ; k24 = 21
.line	181	loadk        r24   k25 ; k25 = 23
.line	181	loadk        r25   k26 ; k26 = 167
.line	181	loadk        r26   k27 ; k27 = 5
.line	181	loadk        r27   k28 ; k28 = 235
.line	181	loadk        r28   k29 ; k29 = 146
.line	181	loadk        r29   k30 ; k30 = 2
.line	181	loadk        r30   k31 ; k31 = 48
.line	181	loadk        r31   k11 ; k11 = 15
.line	181	loadk        r32   k32 ; k32 = 37
.line	181	loadk        r33   k33 ; k33 = 63
.line	181	loadk        r34   k34 ; k34 = 57
.line	181	loadk        r35   k35 ; k35 = 210
.line	181	loadk        r36   k36 ; k36 = 208
.line	181	loadk        r37   k37 ; k37 = 163
.line	181	loadk        r38   k38 ; k38 = 177
.line	181	loadk        r39   k39 ; k39 = 4
.line	181	loadk        r40   k40 ; k40 = 29
.line	181	loadk        r41   k41 ; k41 = 183
.line	181	loadk        r42   k42 ; k42 = 1
.line	181	loadk        r43   k43 ; k43 = 239
.line	181	loadk        r44   k44 ; k44 = 141
.line	181	call          r4    41     2
.line	181	getupval      r5    u2
.line	181	loadk         r6   k45 ; k45 = 72
.line	181	call          r5     2     0
.line	181	setlist       r3     0     1
.line	181	call          r2     2     2
.label	l59
.line	181	call          r1     2     1
.line	181	self          r1    r0   k46 ; k46 = "IsDedicatedServer"
.line	181	call          r1     2     2
.line	181	test          r1     1
.line	181	jmp            0   l70
.line	181	self          r1    r0   k47 ; k47 = "IsPlayTest"
.line	181	call          r1     2     2
.line	181	test          r1     1
.line	181	jmp            0   l70
.line	181	self          r1    r0   k48 ; k48 = "_RegisterApplyFPSLim" (truncated)
.line	181	call          r1     2     1
.label	l70
.line	181	return        r0     1
.line	181	move          r0    r0
.line	181	return        r0     1

.function	main/f6

.source	null
.linedefined	189
.lastlinedefined	207
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"GetGameParameterManager"
.constant	k1	"print"
.constant	k2	"bWriteLog"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	110
.constant	k6	170
.constant	k7	111
.constant	k8	53
.constant	k9	87
.constant	k10	15
.constant	k11	152
.constant	k12	165
.constant	k13	12
.constant	k14	54
.constant	k15	8
.constant	k16	36
.constant	k17	11
.constant	k18	55
.constant	k19	139
.constant	k20	234
.constant	k21	169
.constant	k22	171
.constant	k23	21
.constant	k24	23
.constant	k25	167
.constant	k26	5
.constant	k27	235
.constant	k28	146
.constant	k29	2
.constant	k30	48
.constant	k31	37
.constant	k32	63
.constant	k33	57
.constant	k34	210
.constant	k35	192
.constant	k36	159
.constant	k37	157
.constant	k38	13
.constant	k39	29
.constant	k40	176
.constant	k41	50
.constant	k42	108
.constant	k43	168
.constant	k44	122
.constant	k45	56
.constant	k46	90
.constant	k47	32
.constant	k48	190
.constant	k49	147
.constant	k50	1
.constant	k51	40
.constant	k52	62
.constant	k53	145
.constant	k54	252
.constant	k55	141
.constant	k56	20
.constant	k57	161
.constant	k58	183
.constant	k59	25
.constant	k60	59
.constant	k61	38
.constant	k62	137
.constant	k63	242
.constant	k64	140
.constant	k65	6
.constant	k66	142
.constant	k67	39
.constant	k68	224
.constant	k69	129
.constant	k70	74
.constant	k71	189
.constant	k72	120
.constant	k73	116
.constant	k74	206
.constant	k75	174
.constant	k76	"_ApplyFPSListenerID"
.constant	k77	"AddGameParameterListener"
.constant	k78	79
.constant	k79	121
.constant	k80	17
.constant	k81	91
.constant	k82	18
.constant	k83	156
.constant	k84	44
.constant	k85	60
.constant	k86	33
.constant	k87	46
.constant	k88	"_ApplyFPSListenerID2"
.constant	k89	96
.constant	k90	185
.constant	k91	114
.constant	k92	76
.constant	k93	154

.line	189	gettabup      r1    u0    k0 ; k0 = "GetGameParameterMana" (truncated)
.line	189	test          r1     0
.line	189	jmp            0    l6
.line	189	gettabup      r1    u0    k0 ; k0 = "GetGameParameterMana" (truncated)
.line	189	call          r1     1     2
.label	l6
.line	189	test          r1     1
.line	189	jmp            0  l115
.line	189	gettabup      r2    u0    k1 ; k1 = "print"
.line	189	gettabup      r3    u0    k2 ; k2 = "bWriteLog"
.line	189	test          r3     0
.line	189	jmp            0  l113
.line	189	gettabup      r3    u0    k3 ; k3 = "table"
.line	189	gettable      r3    r3    k4 ; k4 = "concat"
.line	189	newtable      r4     2     0
.line	189	getupval      r5    u1
.line	189	loadk         r6    k5 ; k5 = 110
.line	189	loadk         r7    k6 ; k6 = 170
.line	189	loadk         r8    k7 ; k7 = 111
.line	189	loadk         r9    k8 ; k8 = 53
.line	189	loadk        r10    k9 ; k9 = 87
.line	189	loadk        r11   k10 ; k10 = 15
.line	189	loadk        r12   k11 ; k11 = 152
.line	189	loadk        r13   k12 ; k12 = 165
.line	189	loadk        r14   k13 ; k13 = 12
.line	189	loadk        r15   k14 ; k14 = 54
.line	189	loadk        r16   k15 ; k15 = 8
.line	189	loadk        r17   k16 ; k16 = 36
.line	189	loadk        r18   k17 ; k17 = 11
.line	189	loadk        r19   k18 ; k18 = 55
.line	189	loadk        r20   k19 ; k19 = 139
.line	189	loadk        r21   k20 ; k20 = 234
.line	189	loadk        r22   k21 ; k21 = 169
.line	189	loadk        r23   k22 ; k22 = 171
.line	189	loadk        r24   k23 ; k23 = 21
.line	189	loadk        r25   k24 ; k24 = 23
.line	189	loadk        r26   k25 ; k25 = 167
.line	189	loadk        r27   k26 ; k26 = 5
.line	189	loadk        r28   k27 ; k27 = 235
.line	189	loadk        r29   k28 ; k28 = 146
.line	189	loadk        r30   k29 ; k29 = 2
.line	189	loadk        r31   k30 ; k30 = 48
.line	189	loadk        r32   k10 ; k10 = 15
.line	189	loadk        r33   k31 ; k31 = 37
.line	189	loadk        r34   k32 ; k32 = 63
.line	189	loadk        r35   k33 ; k33 = 57
.line	189	loadk        r36   k34 ; k34 = 210
.line	189	loadk        r37   k35 ; k35 = 192
.line	189	loadk        r38   k36 ; k36 = 159
.line	189	loadk        r39   k37 ; k37 = 157
.line	189	loadk        r40   k38 ; k38 = 13
.line	189	loadk        r41   k39 ; k39 = 29
.line	189	loadk        r42   k40 ; k40 = 176
.line	189	loadk        r43   k41 ; k41 = 50
.line	189	loadk        r44   k27 ; k27 = 235
.line	189	loadk        r45   k28 ; k28 = 146
.line	189	call          r5    41     2
.line	189	getupval      r6    u1
.line	189	loadk         r7   k42 ; k42 = 108
.line	189	loadk         r8   k43 ; k43 = 168
.line	189	loadk         r9   k44 ; k44 = 122
.line	189	loadk        r10   k45 ; k45 = 56
.line	189	loadk        r11   k46 ; k46 = 90
.line	189	loadk        r12   k47 ; k47 = 32
.line	189	loadk        r13   k48 ; k48 = 190
.line	189	loadk        r14   k49 ; k49 = 147
.line	189	loadk        r15   k38 ; k38 = 13
.line	189	loadk        r16   k30 ; k30 = 48
.line	189	loadk        r17   k50 ; k50 = 1
.line	189	loadk        r18   k51 ; k51 = 40
.line	189	loadk        r19   k52 ; k52 = 62
.line	189	loadk        r20   k15 ; k15 = 8
.line	189	loadk        r21   k53 ; k53 = 145
.line	189	loadk        r22   k54 ; k54 = 252
.line	189	loadk        r23   k21 ; k21 = 169
.line	189	loadk        r24   k55 ; k55 = 141
.line	189	loadk        r25   k56 ; k56 = 20
.line	189	loadk        r26   k50 ; k50 = 1
.line	189	loadk        r27   k57 ; k57 = 161
.line	189	loadk        r28   k31 ; k31 = 37
.line	189	loadk        r29   k48 ; k48 = 190
.line	189	loadk        r30   k58 ; k58 = 183
.line	189	loadk        r31   k30 ; k30 = 48
.line	189	loadk        r32   k16 ; k16 = 36
.line	189	loadk        r33   k59 ; k59 = 25
.line	189	loadk        r34   k50 ; k50 = 1
.line	189	loadk        r35   k60 ; k60 = 59
.line	189	loadk        r36   k61 ; k61 = 38
.line	189	loadk        r37   k62 ; k62 = 137
.line	189	loadk        r38   k63 ; k63 = 242
.line	189	loadk        r39   k43 ; k43 = 168
.line	189	loadk        r40   k64 ; k64 = 140
.line	189	loadk        r41   k10 ; k10 = 15
.line	189	loadk        r42   k65 ; k65 = 6
.line	189	loadk        r43   k66 ; k66 = 142
.line	189	loadk        r44   k67 ; k67 = 39
.line	189	loadk        r45   k68 ; k68 = 224
.line	189	loadk        r46   k69 ; k69 = 129
.line	189	call          r6    41     2
.line	189	getupval      r7    u1
.line	189	loadk         r8   k70 ; k70 = 74
.line	189	loadk         r9   k71 ; k71 = 189
.line	189	loadk        r10   k72 ; k72 = 120
.line	189	loadk        r11   k73 ; k73 = 116
.line	189	loadk        r12   k70 ; k70 = 74
.line	189	loadk        r13   k23 ; k23 = 21
.line	189	loadk        r14   k74 ; k74 = 206
.line	189	loadk        r15   k75 ; k75 = 174
.line	189	loadk        r16   k51 ; k51 = 40
.line	189	loadk        r17    k8 ; k8 = 53
.line	189	call          r7    11     0
.line	189	setlist       r4     0     1
.line	189	call          r3     2     2
.label	l113
.line	189	call          r2     2     1
.line	189	return        r0     1
.label	l115
.line	189	closure       r2    f0
.line	189	self          r3    r1   k77 ; k77 = "AddGameParameterList" (truncated)
.line	189	getupval      r5    u1
.line	189	loadk         r6   k78 ; k78 = 79
.line	189	loadk         r7   k53 ; k53 = 145
.line	189	loadk         r8   k79 ; k79 = 121
.line	189	loadk         r9   k80 ; k80 = 17
.line	189	loadk        r10   k81 ; k81 = 91
.line	189	loadk        r11   k82 ; k82 = 18
.line	189	loadk        r12   k83 ; k83 = 156
.line	189	loadk        r13   k12 ; k12 = 165
.line	189	loadk        r14   k84 ; k84 = 44
.line	189	loadk        r15   k85 ; k85 = 60
.line	189	loadk        r16   k86 ; k86 = 33
.line	189	loadk        r17   k87 ; k87 = 46
.line	189	loadk        r18   k87 ; k87 = 46
.line	189	loadk        r19   k86 ; k86 = 33
.line	189	call          r5    15     2
.line	189	move          r6    r2
.line	189	call          r3     4     2
.line	189	settable      r0   k76    r3 ; k76 = "_ApplyFPSListenerID"
.line	189	self          r3    r1   k77 ; k77 = "AddGameParameterList" (truncated)
.line	189	getupval      r5    u1
.line	189	loadk         r6   k89 ; k89 = 96
.line	189	loadk         r7   k90 ; k90 = 185
.line	189	loadk         r8   k91 ; k91 = 114
.line	189	loadk         r9   k24 ; k24 = 23
.line	189	loadk        r10   k92 ; k92 = 76
.line	189	loadk        r11   k23 ; k23 = 21
.line	189	loadk        r12   k93 ; k93 = 154
.line	189	call          r5     8     2
.line	189	move          r6    r2
.line	189	call          r3     4     2
.line	189	settable      r0   k88    r3 ; k88 = "_ApplyFPSListenerID2"
.line	189	return        r0     1
.line	189	move          r0    r0
.line	189	move          r0    r0
.line	189	return        r0     1

.function	main/f6/f0

.source	null
.linedefined	195
.lastlinedefined	204
.numparams	0
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	0	true

.constant	k0	"_ApplyFPSLimitTimerID"
.constant	k1	-1
.constant	k2	"RemoveGameTimer"
.constant	k3	"AddGameTimer"
.constant	k4	0.1

.line	195	gettabup      r0    u0    k0 ; k0 = "_ApplyFPSLimitTimerI" (truncated)
.line	195	test          r0     0
.line	195	jmp            0   l12
.line	195	gettabup      r0    u0    k0 ; k0 = "_ApplyFPSLimitTimerI" (truncated)
.line	195	eq             1    r0    k1 ; k1 = -1
.line	195	jmp            0   l12
.line	195	getupval      r0    u0
.line	195	self          r0    r0    k2 ; k2 = "RemoveGameTimer"
.line	195	gettabup      r2    u0    k0 ; k0 = "_ApplyFPSLimitTimerI" (truncated)
.line	195	call          r0     3     1
.line	195	settabup      u0    k0    k1 ; k1 = -1
.label	l12
.line	195	getupval      r0    u0
.line	195	self          r0    r0    k3 ; k3 = "AddGameTimer"
.line	195	loadk         r2    k4 ; k4 = 0.1
.line	195	loadbool      r3     0     0
.line	195	closure       r4    f0
.line	195	call          r0     5     2
.line	195	settabup      u0    k0    r0 ; k0 = "_ApplyFPSLimitTimerI" (truncated)
.line	195	return        r0     1
.line	195	move          r0    r0
.line	195	move          r0    r0
.line	195	move          r0    r0
.line	195	move          r0    r0
.line	195	return        r0     1

.function	main/f6/f0/f0

.source	null
.linedefined	200
.lastlinedefined	203
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	false

.constant	k0	"_ApplyFPSLimitTimerID"
.constant	k1	-1
.constant	k2	"_OnGameParameterLoadedApplyFPSLimit"

.line	200	settabup      u0    k0    k1 ; k1 = -1
.line	200	getupval      r0    u0
.line	200	self          r0    r0    k2 ; k2 = "_OnGameParameterLoad" (truncated)
.line	200	call          r0     2     1
.line	200	return        r0     1
.line	200	move          r0    r0
.line	200	move          r0    r0
.line	200	return        r0     1

.function	main/f7

.source	null
.linedefined	209
.lastlinedefined	236
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"IsDedicatedServer"
.constant	k1	"GetGameParameterManager"
.constant	k2	"_ApplyFPSListenerID"
.constant	k3	"RemoveGameParameterListener"
.constant	k4	nil
.constant	k5	"_ApplyFPSListenerID2"
.constant	k6	"_ApplyFPSLimitTimerID"
.constant	k7	-1
.constant	k8	"RemoveGameTimer"
.constant	k9	"_CacheFPSLimit"
.constant	k10	"print"
.constant	k11	"bWriteLog"
.constant	k12	"table"
.constant	k13	"concat"
.constant	k14	110
.constant	k15	170
.constant	k16	111
.constant	k17	53
.constant	k18	87
.constant	k19	15
.constant	k20	152
.constant	k21	165
.constant	k22	12
.constant	k23	54
.constant	k24	8
.constant	k25	36
.constant	k26	11
.constant	k27	55
.constant	k28	139
.constant	k29	234
.constant	k30	169
.constant	k31	171
.constant	k32	21
.constant	k33	23
.constant	k34	167
.constant	k35	5
.constant	k36	235
.constant	k37	146
.constant	k38	2
.constant	k39	48
.constant	k40	37
.constant	k41	63
.constant	k42	57
.constant	k43	210
.constant	k44	192
.constant	k45	142
.constant	k46	153
.constant	k47	9
.constant	k48	28
.constant	k49	166
.constant	k50	0
.constant	k51	222
.constant	k52	179
.constant	k53	97
.constant	k54	177
.constant	k55	103
.constant	k56	61
.constant	k57	70
.constant	k58	211
.constant	k59	224
.constant	k60	"require"
.constant	k61	78
.constant	k62	180
.constant	k63	99
.constant	k64	49
.constant	k65	77
.constant	k66	18
.constant	k67	163
.constant	k68	46
.constant	k69	52
.constant	k70	1
.constant	k71	106
.constant	k72	141
.constant	k73	230
.constant	k74	130
.constant	k75	157
.constant	k76	14
.constant	k77	13
.constant	k78	191
.constant	k79	"GetGameInstance"
.constant	k80	"slua"
.constant	k81	"isValid"
.constant	k82	"ExecuteCMD"
.constant	k83	89
.constant	k84	246
.constant	k85	71
.constant	k86	91
.constant	k87	32
.constant	k88	190
.constant	k89	147

.line	209	self          r1    r0    k0 ; k0 = "IsDedicatedServer"
.line	209	call          r1     2     2
.line	209	test          r1     1
.line	209	jmp            0  l150
.line	209	gettabup      r1    u0    k1 ; k1 = "GetGameParameterMana" (truncated)
.line	209	test          r1     0
.line	209	jmp            0   l10
.line	209	gettabup      r1    u0    k1 ; k1 = "GetGameParameterMana" (truncated)
.line	209	call          r1     1     2
.label	l10
.line	209	test          r1     0
.line	209	jmp            0   l26
.line	209	gettable      r2    r0    k2 ; k2 = "_ApplyFPSListenerID"
.line	209	test          r2     0
.line	209	jmp            0   l19
.line	209	self          r2    r1    k3 ; k3 = "RemoveGameParameterL" (truncated)
.line	209	gettable      r4    r0    k2 ; k2 = "_ApplyFPSListenerID"
.line	209	call          r2     3     1
.line	209	settable      r0    k2    k4 ; k4 = nil
.label	l19
.line	209	gettable      r2    r0    k5 ; k5 = "_ApplyFPSListenerID2"
.line	209	test          r2     0
.line	209	jmp            0   l26
.line	209	self          r2    r1    k3 ; k3 = "RemoveGameParameterL" (truncated)
.line	209	gettable      r4    r0    k5 ; k5 = "_ApplyFPSListenerID2"
.line	209	call          r2     3     1
.line	209	settable      r0    k5    k4 ; k4 = nil
.label	l26
.line	209	gettable      r2    r0    k6 ; k6 = "_ApplyFPSLimitTimerI" (truncated)
.line	209	test          r2     0
.line	209	jmp            0   l36
.line	209	gettable      r2    r0    k6 ; k6 = "_ApplyFPSLimitTimerI" (truncated)
.line	209	eq             1    r2    k7 ; k7 = -1
.line	209	jmp            0   l36
.line	209	self          r2    r0    k8 ; k8 = "RemoveGameTimer"
.line	209	gettable      r4    r0    k6 ; k6 = "_ApplyFPSLimitTimerI" (truncated)
.line	209	call          r2     3     1
.line	209	settable      r0    k6    k7 ; k7 = -1
.label	l36
.line	209	gettable      r2    r0    k9 ; k9 = "_CacheFPSLimit"
.line	209	test          r2     0
.line	209	jmp            0  l150
.line	209	gettabup      r2    u0   k10 ; k10 = "print"
.line	209	gettabup      r3    u0   k11 ; k11 = "bWriteLog"
.line	209	test          r3     0
.line	209	jmp            0  l102
.line	209	gettabup      r3    u0   k12 ; k12 = "table"
.line	209	gettable      r3    r3   k13 ; k13 = "concat"
.line	209	newtable      r4     1     0
.line	209	getupval      r5    u1
.line	209	loadk         r6   k14 ; k14 = 110
.line	209	loadk         r7   k15 ; k15 = 170
.line	209	loadk         r8   k16 ; k16 = 111
.line	209	loadk         r9   k17 ; k17 = 53
.line	209	loadk        r10   k18 ; k18 = 87
.line	209	loadk        r11   k19 ; k19 = 15
.line	209	loadk        r12   k20 ; k20 = 152
.line	209	loadk        r13   k21 ; k21 = 165
.line	209	loadk        r14   k22 ; k22 = 12
.line	209	loadk        r15   k23 ; k23 = 54
.line	209	loadk        r16   k24 ; k24 = 8
.line	209	loadk        r17   k25 ; k25 = 36
.line	209	loadk        r18   k26 ; k26 = 11
.line	209	loadk        r19   k27 ; k27 = 55
.line	209	loadk        r20   k28 ; k28 = 139
.line	209	loadk        r21   k29 ; k29 = 234
.line	209	loadk        r22   k30 ; k30 = 169
.line	209	loadk        r23   k31 ; k31 = 171
.line	209	loadk        r24   k32 ; k32 = 21
.line	209	loadk        r25   k33 ; k33 = 23
.line	209	loadk        r26   k34 ; k34 = 167
.line	209	loadk        r27   k35 ; k35 = 5
.line	209	loadk        r28   k36 ; k36 = 235
.line	209	loadk        r29   k37 ; k37 = 146
.line	209	loadk        r30   k38 ; k38 = 2
.line	209	loadk        r31   k39 ; k39 = 48
.line	209	loadk        r32   k19 ; k19 = 15
.line	209	loadk        r33   k40 ; k40 = 37
.line	209	loadk        r34   k41 ; k41 = 63
.line	209	loadk        r35   k42 ; k42 = 57
.line	209	loadk        r36   k43 ; k43 = 210
.line	209	loadk        r37   k44 ; k44 = 192
.line	209	loadk        r38   k45 ; k45 = 142
.line	209	loadk        r39   k46 ; k46 = 153
.line	209	loadk        r40   k47 ; k47 = 9
.line	209	loadk        r41   k48 ; k48 = 28
.line	209	loadk        r42   k49 ; k49 = 166
.line	209	loadk        r43   k50 ; k50 = 0
.line	209	loadk        r44   k51 ; k51 = 222
.line	209	loadk        r45   k52 ; k52 = 179
.line	209	call          r5    41     2
.line	209	getupval      r6    u1
.line	209	loadk         r7   k53 ; k53 = 97
.line	209	loadk         r8   k54 ; k54 = 177
.line	209	loadk         r9   k55 ; k55 = 103
.line	209	loadk        r10   k56 ; k56 = 61
.line	209	loadk        r11   k18 ; k18 = 87
.line	209	loadk        r12   k57 ; k57 = 70
.line	209	loadk        r13   k58 ; k58 = 211
.line	209	loadk        r14   k59 ; k59 = 224
.line	209	call          r6     9     0
.line	209	setlist       r4     0     1
.line	209	call          r3     2     2
.line	209	gettable      r4    r0    k9 ; k9 = "_CacheFPSLimit"
.line	209	concat        r3    r3    r4
.label	l102
.line	209	call          r2     2     1
.line	209	gettabup      r2    u0   k60 ; k60 = "require"
.line	209	getupval      r3    u1
.line	209	loadk         r4   k61 ; k61 = 78
.line	209	loadk         r5   k62 ; k62 = 180
.line	209	loadk         r6   k63 ; k63 = 99
.line	209	loadk         r7   k64 ; k64 = 49
.line	209	loadk         r8   k65 ; k65 = 77
.line	209	loadk         r9   k66 ; k66 = 18
.line	209	loadk        r10   k44 ; k44 = 192
.line	209	loadk        r11   k67 ; k67 = 163
.line	209	loadk        r12   k68 ; k68 = 46
.line	209	loadk        r13   k69 ; k69 = 52
.line	209	loadk        r14   k70 ; k70 = 1
.line	209	loadk        r15   k68 ; k68 = 46
.line	209	loadk        r16   k25 ; k25 = 36
.line	209	loadk        r17   k71 ; k71 = 106
.line	209	loadk        r18   k72 ; k72 = 141
.line	209	loadk        r19   k73 ; k73 = 230
.line	209	loadk        r20   k74 ; k74 = 130
.line	209	loadk        r21   k75 ; k75 = 157
.line	209	loadk        r22   k76 ; k76 = 14
.line	209	loadk        r23   k77 ; k77 = 13
.line	209	loadk        r24   k78 ; k78 = 191
.line	209	call          r3    22     2
.line	209	call          r2     2     2
.line	209	gettable      r3    r2   k79 ; k79 = "GetGameInstance"
.line	209	call          r3     1     2
.line	209	gettabup      r4    u0   k80 ; k80 = "slua"
.line	209	gettable      r4    r4   k81 ; k81 = "isValid"
.line	209	move          r5    r3
.line	209	call          r4     2     2
.line	209	test          r4     0
.line	209	jmp            0  l149
.line	209	self          r4    r3   k82 ; k82 = "ExecuteCMD"
.line	209	getupval      r6    u1
.line	209	loadk         r7   k83 ; k83 = 89
.line	209	loadk         r8   k84 ; k84 = 246
.line	209	loadk         r9   k85 ; k85 = 71
.line	209	loadk        r10   k17 ; k17 = 53
.line	209	loadk        r11   k86 ; k86 = 91
.line	209	loadk        r12   k87 ; k87 = 32
.line	209	loadk        r13   k88 ; k88 = 190
.line	209	loadk        r14   k89 ; k89 = 147
.line	209	call          r6     9     2
.line	209	gettable      r7    r0    k9 ; k9 = "_CacheFPSLimit"
.line	209	call          r4     4     1
.label	l149
.line	209	settable      r0    k9    k4 ; k4 = nil
.label	l150
.line	209	return        r0     1
.line	209	move          r0    r0
.line	209	move          r0    r0
.line	209	return        r0     1

.function	main/f8

.source	null
.linedefined	238
.lastlinedefined	240
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	"EntireGridWidget"
.constant	k1	nil

.line	238	settable      r0    k0    k1 ; k1 = nil
.line	238	return        r0     1
.line	238	move          r0    r0
.line	238	move          r0    r0
.line	238	move          r0    r0
.line	238	return        r0     1

.function	main/f9

.source	null
.linedefined	242
.lastlinedefined	247
.numparams	1
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	false

.constant	k0	"InstanceManager"
.constant	k1	nil
.constant	k2	"GetInstanceManager"

.line	242	gettable      r1    r0    k0 ; k0 = "InstanceManager"
.line	242	eq             0    r1    k1 ; k1 = nil
.line	242	jmp            0    l7
.line	242	gettabup      r1    u0    k2 ; k2 = "GetInstanceManager"
.line	242	call          r1     1     2
.line	242	settable      r0    k0    r1 ; k0 = "InstanceManager"
.label	l7
.line	242	gettable      r1    r0    k0 ; k0 = "InstanceManager"
.line	242	return        r1     2
.line	242	return        r0     1
.line	242	move          r0    r0
.line	242	move          r0    r0
.line	242	move          r0    r0
.line	242	move          r0    r0
.line	242	return        r0     1

.function	main/f10

.source	null
.linedefined	249
.lastlinedefined	254
.numparams	1
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	false

.constant	k0	"AssetManager"
.constant	k1	nil
.constant	k2	"GetAssetManager"

.line	249	gettable      r1    r0    k0 ; k0 = "AssetManager"
.line	249	eq             0    r1    k1 ; k1 = nil
.line	249	jmp            0    l7
.line	249	gettabup      r1    u0    k2 ; k2 = "GetAssetManager"
.line	249	call          r1     1     2
.line	249	settable      r0    k0    r1 ; k0 = "AssetManager"
.label	l7
.line	249	gettable      r1    r0    k0 ; k0 = "AssetManager"
.line	249	return        r1     2
.line	249	return        r0     1
.line	249	move          r0    r0
.line	249	return        r0     1

.function	main/f11

.source	null
.linedefined	256
.lastlinedefined	266
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	"InstacneCostInfoMap"
.constant	k1	"RepeatedComputeCostMap"
.constant	k2	"MapInitAssetCost"
.constant	k3	nil
.constant	k4	"InstanceGrid"
.constant	k5	"InstanceGridCost"
.constant	k6	"AlwaysLoadInstances"
.constant	k7	"AlwaysLoadInstancesCost"
.constant	k8	0
.constant	k9	"InstanceGridCombineCost"
.constant	k10	"NearGridIndexList"

.line	256	newtable      r1     0     0
.line	256	settable      r0    k0    r1 ; k0 = "InstacneCostInfoMap"
.line	256	newtable      r1     0     0
.line	256	settable      r0    k1    r1 ; k1 = "RepeatedComputeCostM" (truncated)
.line	256	settable      r0    k2    k3 ; k3 = nil
.line	256	newtable      r1     0     0
.line	256	settable      r0    k4    r1 ; k4 = "InstanceGrid"
.line	256	newtable      r1     0     0
.line	256	settable      r0    k5    r1 ; k5 = "InstanceGridCost"
.line	256	newtable      r1     0     0
.line	256	settable      r0    k6    r1 ; k6 = "AlwaysLoadInstances"
.line	256	settable      r0    k7    k8 ; k8 = 0
.line	256	newtable      r1     0     0
.line	256	settable      r0    k9    r1 ; k9 = "InstanceGridCombineC" (truncated)
.line	256	newtable      r1     0     0
.line	256	settable      r0   k10    r1 ; k10 = "NearGridIndexList"
.line	256	return        r0     1
.line	256	move          r0    r0
.line	256	move          r0    r0
.line	256	move          r0    r0
.line	256	return        r0     1

.function	main/f12

.source	null
.linedefined	268
.lastlinedefined	274
.numparams	5
.is_vararg	0
.maxstacksize	28

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"import"
.constant	k1	104
.constant	k2	155
.constant	k3	120
.constant	k4	49
.constant	k5	66
.constant	k6	18
.constant	k7	135
.constant	k8	182
.constant	k9	36
.constant	k10	20
.constant	k11	3
.constant	k12	37
.constant	k13	47
.constant	k14	153
.constant	k15	226
.constant	k16	184
.constant	k17	188
.constant	k18	"CreativeModeGameType_Editor"
.constant	k19	"CreativeModeGameType_Game"
.constant	k20	"CacheMaximumCost"
.constant	k21	"DynamicCountLimitAssets"
.constant	k22	nil

.line	268	gettabup      r5    u0    k0 ; k0 = "import"
.line	268	getupval      r6    u1
.line	268	loadk         r7    k1 ; k1 = 104
.line	268	loadk         r8    k2 ; k2 = 155
.line	268	loadk         r9    k3 ; k3 = 120
.line	268	loadk        r10    k4 ; k4 = 49
.line	268	loadk        r11    k5 ; k5 = 66
.line	268	loadk        r12    k6 ; k6 = 18
.line	268	loadk        r13    k7 ; k7 = 135
.line	268	loadk        r14    k8 ; k8 = 182
.line	268	loadk        r15    k9 ; k9 = 36
.line	268	loadk        r16   k10 ; k10 = 20
.line	268	loadk        r17   k11 ; k11 = 3
.line	268	loadk        r18   k12 ; k12 = 37
.line	268	loadk        r19   k13 ; k13 = 47
.line	268	loadk        r20   k11 ; k11 = 3
.line	268	loadk        r21   k14 ; k14 = 153
.line	268	loadk        r22   k15 ; k15 = 226
.line	268	loadk        r23   k16 ; k16 = 184
.line	268	loadk        r24   k17 ; k17 = 188
.line	268	loadk        r25   k11 ; k11 = 3
.line	268	loadk        r26   k10 ; k10 = 20
.line	268	loadk        r27    k8 ; k8 = 182
.line	268	call          r6    22     2
.line	268	call          r5     2     2
.line	268	gettable      r6    r5   k18 ; k18 = "CreativeModeGameType" (truncated)
.line	268	eq             0    r3    r6
.line	268	jmp            0   l34
.line	268	gettable      r6    r5   k19 ; k19 = "CreativeModeGameType" (truncated)
.line	268	eq             0    r4    r6
.line	268	jmp            0   l34
.line	268	self          r6    r0   k20 ; k20 = "CacheMaximumCost"
.line	268	call          r6     2     1
.label	l34
.line	268	settable      r0   k21   k22 ; k22 = nil
.line	268	return        r0     1
.line	268	move          r0    r0
.line	268	move          r0    r0
.line	268	move          r0    r0
.line	268	return        r0     1

.function	main/f13

.source	null
.linedefined	276
.lastlinedefined	281
.numparams	2
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	0	false

.constant	k0	"CellCostMax"
.constant	k1	nil
.constant	k2	"LevelPercentConfig"
.constant	k3	"GetCurAssetCostMax"
.constant	k4	"EventSystem"
.constant	k5	"postEvent"
.constant	k6	"EVENTTYPE_CREATIVE"
.constant	k7	"EVENTID_ASSET_COST_EXTREMEMODE_CHANGED"
.constant	k8	"Value"

.line	276	settable      r0    k0    k1 ; k1 = nil
.line	276	settable      r0    k2    k1 ; k1 = nil
.line	276	self          r2    r0    k3 ; k3 = "GetCurAssetCostMax"
.line	276	call          r2     2     1
.line	276	gettabup      r2    u0    k4 ; k4 = "EventSystem"
.line	276	self          r2    r2    k5 ; k5 = "postEvent"
.line	276	gettabup      r4    u0    k6 ; k6 = "EVENTTYPE_CREATIVE"
.line	276	gettabup      r5    u0    k7 ; k7 = "EVENTID_ASSET_COST_E" (truncated)
.line	276	gettable      r6    r1    k8 ; k8 = "Value"
.line	276	call          r2     5     1
.line	276	return        r0     1
.line	276	move          r0    r0
.line	276	move          r0    r0
.line	276	move          r0    r0
.line	276	move          r0    r0
.line	276	return        r0     1

.function	main/f14

.source	null
.linedefined	283
.lastlinedefined	288
.numparams	2
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	0	false

.constant	k0	"CellCostMax"
.constant	k1	nil
.constant	k2	"LevelPercentConfig"
.constant	k3	"GetCurAssetCostMax"
.constant	k4	"EventSystem"
.constant	k5	"postEvent"
.constant	k6	"EVENTTYPE_CREATIVE"
.constant	k7	"EVENTID_ASSET_COST_UNLIMITEDMODE_CHANGED"
.constant	k8	"Value"

.line	283	settable      r0    k0    k1 ; k1 = nil
.line	283	settable      r0    k2    k1 ; k1 = nil
.line	283	self          r2    r0    k3 ; k3 = "GetCurAssetCostMax"
.line	283	call          r2     2     1
.line	283	gettabup      r2    u0    k4 ; k4 = "EventSystem"
.line	283	self          r2    r2    k5 ; k5 = "postEvent"
.line	283	gettabup      r4    u0    k6 ; k6 = "EVENTTYPE_CREATIVE"
.line	283	gettabup      r5    u0    k7 ; k7 = "EVENTID_ASSET_COST_U" (truncated)
.line	283	gettable      r6    r1    k8 ; k8 = "Value"
.line	283	call          r2     5     1
.line	283	return        r0     1
.line	283	move          r0    r0
.line	283	move          r0    r0
.line	283	move          r0    r0
.line	283	move          r0    r0
.line	283	return        r0     1

.function	main/f15

.source	null
.linedefined	290
.lastlinedefined	308
.numparams	1
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"IsExtremeMap"
.constant	k1	"print"
.constant	k2	"bWriteLog"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	110
.constant	k6	170
.constant	k7	111
.constant	k8	53
.constant	k9	87
.constant	k10	15
.constant	k11	152
.constant	k12	165
.constant	k13	12
.constant	k14	54
.constant	k15	8
.constant	k16	36
.constant	k17	11
.constant	k18	55
.constant	k19	139
.constant	k20	234
.constant	k21	169
.constant	k22	171
.constant	k23	21
.constant	k24	23
.constant	k25	167
.constant	k26	5
.constant	k27	235
.constant	k28	146
.constant	k29	2
.constant	k30	48
.constant	k31	37
.constant	k32	63
.constant	k33	57
.constant	k34	210
.constant	k35	192
.constant	k36	130
.constant	k37	150
.constant	k38	45
.constant	k39	174
.constant	k40	35
.constant	k41	222
.constant	k42	129
.constant	k43	95
.constant	k44	185
.constant	k45	103
.constant	k46	49
.constant	k47	3
.constant	k48	156
.constant	k49	140
.constant	k50	46
.constant	k51	56
.constant	k52	136
.constant	k53	255
.constant	k54	177
.constant	k55	145
.constant	k56	60
.constant	k57	52
.constant	k58	128
.constant	k59	26
.constant	k60	247
.constant	k61	157
.constant	k62	61
.constant	k63	92
.constant	k64	32
.constant	k65	200
.constant	k66	218
.constant	k67	181
.constant	k68	24
.constant	k69	17
.constant	k70	173
.constant	k71	76
.constant	k72	168
.constant	k73	51
.constant	k74	19
.constant	k75	39
.constant	k76	231
.constant	k77	138
.constant	k78	25
.constant	k79	166
.constant	k80	225
.constant	k81	132
.constant	k82	72
.constant	k83	"require"
.constant	k84	78
.constant	k85	180
.constant	k86	99
.constant	k87	77
.constant	k88	18
.constant	k89	172
.constant	k90	62
.constant	k91	34
.constant	k92	100
.constant	k93	151
.constant	k94	232
.constant	k95	42
.constant	k96	178
.constant	k97	47
.constant	k98	251
.constant	k99	1
.constant	k100	59
.constant	k101	41
.constant	k102	122
.constant	k103	243
.constant	k104	6
.constant	k105	179
.constant	k106	134
.constant	k107	94
.constant	k108	"LoadFileToTable_N"
.constant	k109	"ePlayerPrefsType"
.constant	k110	"eUGCPerformanceSetting"
.constant	k111	163
.constant	k112	106
.constant	k113	141
.constant	k114	230
.constant	k115	14
.constant	k116	13
.constant	k117	191
.constant	k118	"GetGameInstance"
.constant	k119	"import"
.constant	k120	102
.constant	k121	121
.constant	k122	70
.constant	k123	189
.constant	k124	50
.constant	k125	9
.constant	k126	44
.constant	k127	154
.constant	k128	253
.constant	k129	188
.constant	k130	"_CacheFPSLimit"
.constant	k131	"GetConsoleVariableFloatValue"
.constant	k132	89
.constant	k133	246
.constant	k134	71
.constant	k135	91
.constant	k136	190
.constant	k137	147
.constant	k138	"bIsHighPerformance"
.constant	k139	160
.constant	k140	144
.constant	k141	58
.constant	k142	64
.constant	k143	"ExecuteCMD"
.constant	k144	30

.line	290	self          r1    r0    k0 ; k0 = "IsExtremeMap"
.line	290	call          r1     2     2
.line	290	test          r1     1
.line	290	jmp            0  l104
.line	290	gettabup      r1    u0    k1 ; k1 = "print"
.line	290	gettabup      r2    u0    k2 ; k2 = "bWriteLog"
.line	290	test          r2     0
.line	290	jmp            0  l102
.line	290	gettabup      r2    u0    k3 ; k3 = "table"
.line	290	gettable      r2    r2    k4 ; k4 = "concat"
.line	290	newtable      r3     2     0
.line	290	getupval      r4    u1
.line	290	loadk         r5    k5 ; k5 = 110
.line	290	loadk         r6    k6 ; k6 = 170
.line	290	loadk         r7    k7 ; k7 = 111
.line	290	loadk         r8    k8 ; k8 = 53
.line	290	loadk         r9    k9 ; k9 = 87
.line	290	loadk        r10   k10 ; k10 = 15
.line	290	loadk        r11   k11 ; k11 = 152
.line	290	loadk        r12   k12 ; k12 = 165
.line	290	loadk        r13   k13 ; k13 = 12
.line	290	loadk        r14   k14 ; k14 = 54
.line	290	loadk        r15   k15 ; k15 = 8
.line	290	loadk        r16   k16 ; k16 = 36
.line	290	loadk        r17   k17 ; k17 = 11
.line	290	loadk        r18   k18 ; k18 = 55
.line	290	loadk        r19   k19 ; k19 = 139
.line	290	loadk        r20   k20 ; k20 = 234
.line	290	loadk        r21   k21 ; k21 = 169
.line	290	loadk        r22   k22 ; k22 = 171
.line	290	loadk        r23   k23 ; k23 = 21
.line	290	loadk        r24   k24 ; k24 = 23
.line	290	loadk        r25   k25 ; k25 = 167
.line	290	loadk        r26   k26 ; k26 = 5
.line	290	loadk        r27   k27 ; k27 = 235
.line	290	loadk        r28   k28 ; k28 = 146
.line	290	loadk        r29   k29 ; k29 = 2
.line	290	loadk        r30   k30 ; k30 = 48
.line	290	loadk        r31   k10 ; k10 = 15
.line	290	loadk        r32   k31 ; k31 = 37
.line	290	loadk        r33   k32 ; k32 = 63
.line	290	loadk        r34   k33 ; k33 = 57
.line	290	loadk        r35   k34 ; k34 = 210
.line	290	loadk        r36   k35 ; k35 = 192
.line	290	loadk        r37   k36 ; k36 = 130
.line	290	loadk        r38   k37 ; k37 = 150
.line	290	loadk        r39   k38 ; k38 = 45
.line	290	loadk        r40   k23 ; k23 = 21
.line	290	loadk        r41   k39 ; k39 = 174
.line	290	loadk        r42   k40 ; k40 = 35
.line	290	loadk        r43   k41 ; k41 = 222
.line	290	loadk        r44   k42 ; k42 = 129
.line	290	call          r4    41     2
.line	290	getupval      r5    u1
.line	290	loadk         r6   k43 ; k43 = 95
.line	290	loadk         r7   k44 ; k44 = 185
.line	290	loadk         r8   k45 ; k45 = 103
.line	290	loadk         r9   k46 ; k46 = 49
.line	290	loadk        r10    k9 ; k9 = 87
.line	290	loadk        r11   k47 ; k47 = 3
.line	290	loadk        r12   k48 ; k48 = 156
.line	290	loadk        r13   k49 ; k49 = 140
.line	290	loadk        r14   k50 ; k50 = 46
.line	290	loadk        r15   k51 ; k51 = 56
.line	290	loadk        r16   k15 ; k15 = 8
.line	290	loadk        r17   k16 ; k16 = 36
.line	290	loadk        r18   k50 ; k50 = 46
.line	290	loadk        r19   k26 ; k26 = 5
.line	290	loadk        r20   k52 ; k52 = 136
.line	290	loadk        r21   k53 ; k53 = 255
.line	290	loadk        r22   k54 ; k54 = 177
.line	290	loadk        r23   k55 ; k55 = 145
.line	290	loadk        r24   k56 ; k56 = 60
.line	290	loadk        r25   k57 ; k57 = 52
.line	290	loadk        r26   k58 ; k58 = 128
.line	290	loadk        r27   k59 ; k59 = 26
.line	290	loadk        r28   k60 ; k60 = 247
.line	290	loadk        r29   k61 ; k61 = 157
.line	290	loadk        r30   k51 ; k51 = 56
.line	290	loadk        r31   k62 ; k62 = 61
.line	290	loadk        r32   k63 ; k63 = 92
.line	290	loadk        r33   k32 ; k32 = 63
.line	290	loadk        r34    k8 ; k8 = 53
.line	290	loadk        r35   k64 ; k64 = 32
.line	290	loadk        r36   k65 ; k65 = 200
.line	290	loadk        r37   k66 ; k66 = 218
.line	290	loadk        r38   k67 ; k67 = 181
.line	290	loadk        r39   k49 ; k49 = 140
.line	290	loadk        r40   k68 ; k68 = 24
.line	290	loadk        r41   k69 ; k69 = 17
.line	290	loadk        r42   k39 ; k39 = 174
.line	290	loadk        r43   k40 ; k40 = 35
.line	290	loadk        r44   k39 ; k39 = 174
.line	290	loadk        r45   k70 ; k70 = 173
.line	290	call          r5    41     2
.line	290	getupval      r6    u1
.line	290	loadk         r7   k71 ; k71 = 76
.line	290	loadk         r8   k72 ; k72 = 168
.line	290	call          r6     3     0
.line	290	setlist       r3     0     1
.line	290	call          r2     2     2
.label	l102
.line	290	call          r1     2     1
.line	290	return        r0     1
.label	l104
.line	290	gettabup      r1    u0    k1 ; k1 = "print"
.line	290	gettabup      r2    u0    k2 ; k2 = "bWriteLog"
.line	290	test          r2     0
.line	290	jmp            0  l200
.line	290	gettabup      r2    u0    k3 ; k3 = "table"
.line	290	gettable      r2    r2    k4 ; k4 = "concat"
.line	290	newtable      r3     2     0
.line	290	getupval      r4    u1
.line	290	loadk         r5    k5 ; k5 = 110
.line	290	loadk         r6    k6 ; k6 = 170
.line	290	loadk         r7    k7 ; k7 = 111
.line	290	loadk         r8    k8 ; k8 = 53
.line	290	loadk         r9    k9 ; k9 = 87
.line	290	loadk        r10   k10 ; k10 = 15
.line	290	loadk        r11   k11 ; k11 = 152
.line	290	loadk        r12   k12 ; k12 = 165
.line	290	loadk        r13   k13 ; k13 = 12
.line	290	loadk        r14   k14 ; k14 = 54
.line	290	loadk        r15   k15 ; k15 = 8
.line	290	loadk        r16   k16 ; k16 = 36
.line	290	loadk        r17   k17 ; k17 = 11
.line	290	loadk        r18   k18 ; k18 = 55
.line	290	loadk        r19   k19 ; k19 = 139
.line	290	loadk        r20   k20 ; k20 = 234
.line	290	loadk        r21   k21 ; k21 = 169
.line	290	loadk        r22   k22 ; k22 = 171
.line	290	loadk        r23   k23 ; k23 = 21
.line	290	loadk        r24   k24 ; k24 = 23
.line	290	loadk        r25   k25 ; k25 = 167
.line	290	loadk        r26   k26 ; k26 = 5
.line	290	loadk        r27   k27 ; k27 = 235
.line	290	loadk        r28   k28 ; k28 = 146
.line	290	loadk        r29   k29 ; k29 = 2
.line	290	loadk        r30   k30 ; k30 = 48
.line	290	loadk        r31   k10 ; k10 = 15
.line	290	loadk        r32   k31 ; k31 = 37
.line	290	loadk        r33   k32 ; k32 = 63
.line	290	loadk        r34   k33 ; k33 = 57
.line	290	loadk        r35   k34 ; k34 = 210
.line	290	loadk        r36   k35 ; k35 = 192
.line	290	loadk        r37   k36 ; k36 = 130
.line	290	loadk        r38   k37 ; k37 = 150
.line	290	loadk        r39   k38 ; k38 = 45
.line	290	loadk        r40   k23 ; k23 = 21
.line	290	loadk        r41   k39 ; k39 = 174
.line	290	loadk        r42   k40 ; k40 = 35
.line	290	loadk        r43   k41 ; k41 = 222
.line	290	loadk        r44   k42 ; k42 = 129
.line	290	call          r4    41     2
.line	290	getupval      r5    u1
.line	290	loadk         r6   k43 ; k43 = 95
.line	290	loadk         r7   k44 ; k44 = 185
.line	290	loadk         r8   k45 ; k45 = 103
.line	290	loadk         r9   k46 ; k46 = 49
.line	290	loadk        r10    k9 ; k9 = 87
.line	290	loadk        r11   k47 ; k47 = 3
.line	290	loadk        r12   k48 ; k48 = 156
.line	290	loadk        r13   k49 ; k49 = 140
.line	290	loadk        r14   k50 ; k50 = 46
.line	290	loadk        r15   k51 ; k51 = 56
.line	290	loadk        r16   k15 ; k15 = 8
.line	290	loadk        r17   k16 ; k16 = 36
.line	290	loadk        r18   k50 ; k50 = 46
.line	290	loadk        r19   k26 ; k26 = 5
.line	290	loadk        r20   k52 ; k52 = 136
.line	290	loadk        r21   k53 ; k53 = 255
.line	290	loadk        r22   k54 ; k54 = 177
.line	290	loadk        r23   k55 ; k55 = 145
.line	290	loadk        r24   k56 ; k56 = 60
.line	290	loadk        r25   k57 ; k57 = 52
.line	290	loadk        r26   k58 ; k58 = 128
.line	290	loadk        r27   k59 ; k59 = 26
.line	290	loadk        r28   k60 ; k60 = 247
.line	290	loadk        r29   k61 ; k61 = 157
.line	290	loadk        r30   k51 ; k51 = 56
.line	290	loadk        r31   k62 ; k62 = 61
.line	290	loadk        r32   k63 ; k63 = 92
.line	290	loadk        r33   k73 ; k73 = 51
.line	290	loadk        r34   k74 ; k74 = 19
.line	290	loadk        r35   k75 ; k75 = 39
.line	290	loadk        r36   k70 ; k70 = 173
.line	290	loadk        r37   k76 ; k76 = 231
.line	290	loadk        r38   k44 ; k44 = 185
.line	290	loadk        r39   k77 ; k77 = 138
.line	290	loadk        r40   k10 ; k10 = 15
.line	290	loadk        r41   k78 ; k78 = 25
.line	290	loadk        r42   k79 ; k79 = 166
.line	290	loadk        r43   k17 ; k17 = 11
.line	290	loadk        r44   k80 ; k80 = 225
.line	290	loadk        r45   k81 ; k81 = 132
.line	290	call          r5    41     2
.line	290	getupval      r6    u1
.line	290	loadk         r7   k82 ; k82 = 72
.line	290	call          r6     2     0
.line	290	setlist       r3     0     1
.line	290	call          r2     2     2
.label	l200
.line	290	call          r1     2     1
.line	290	gettabup      r1    u0   k83 ; k83 = "require"
.line	290	gettabup      r2    u0    k3 ; k3 = "table"
.line	290	gettable      r2    r2    k4 ; k4 = "concat"
.line	290	newtable      r3     1     0
.line	290	getupval      r4    u1
.line	290	loadk         r5   k84 ; k84 = 78
.line	290	loadk         r6   k85 ; k85 = 180
.line	290	loadk         r7   k86 ; k86 = 99
.line	290	loadk         r8   k46 ; k46 = 49
.line	290	loadk         r9   k87 ; k87 = 77
.line	290	loadk        r10   k88 ; k88 = 18
.line	290	loadk        r11   k35 ; k35 = 192
.line	290	loadk        r12   k89 ; k89 = 172
.line	290	loadk        r13   k50 ; k50 = 46
.line	290	loadk        r14   k90 ; k90 = 62
.line	290	loadk        r15   k26 ; k26 = 5
.line	290	loadk        r16   k91 ; k91 = 34
.line	290	loadk        r17   k92 ; k92 = 100
.line	290	loadk        r18   k15 ; k15 = 8
.line	290	loadk        r19   k93 ; k93 = 151
.line	290	loadk        r20   k94 ; k94 = 232
.line	290	loadk        r21   k85 ; k85 = 180
.line	290	loadk        r22   k19 ; k19 = 139
.line	290	loadk        r23   k95 ; k95 = 42
.line	290	loadk        r24   k15 ; k15 = 8
.line	290	loadk        r25   k96 ; k96 = 178
.line	290	loadk        r26   k97 ; k97 = 47
.line	290	loadk        r27   k98 ; k98 = 251
.line	290	loadk        r28   k36 ; k36 = 130
.line	290	loadk        r29   k99 ; k99 = 1
.line	290	loadk        r30  k100 ; k100 = 59
.line	290	loadk        r31   k78 ; k78 = 25
.line	290	loadk        r32   k18 ; k18 = 55
.line	290	loadk        r33  k101 ; k101 = 41
.line	290	loadk        r34  k102 ; k102 = 122
.line	290	loadk        r35   k11 ; k11 = 152
.line	290	loadk        r36  k103 ; k103 = 243
.line	290	loadk        r37   k89 ; k89 = 172
.line	290	loadk        r38   k42 ; k42 = 129
.line	290	loadk        r39   k10 ; k10 = 15
.line	290	loadk        r40  k104 ; k104 = 6
.line	290	loadk        r41  k105 ; k105 = 179
.line	290	loadk        r42   k57 ; k57 = 52
.line	290	loadk        r43   k27 ; k27 = 235
.line	290	loadk        r44  k106 ; k106 = 134
.line	290	call          r4    41     2
.line	290	getupval      r5    u1
.line	290	loadk         r6  k107 ; k107 = 94
.line	290	call          r5     2     0
.line	290	setlist       r3     0     1
.line	290	call          r2     2     2
.line	290	call          r1     2     2
.line	290	gettable      r2    r1  k108 ; k108 = "LoadFileToTable_N"
.line	290	gettable      r3    r1  k109 ; k109 = "ePlayerPrefsType"
.line	290	gettable      r3    r3  k110 ; k110 = "eUGCPerformanceSetti" (truncated)
.line	290	call          r2     2     2
.line	290	gettabup      r3    u0   k83 ; k83 = "require"
.line	290	getupval      r4    u1
.line	290	loadk         r5   k84 ; k84 = 78
.line	290	loadk         r6   k85 ; k85 = 180
.line	290	loadk         r7   k86 ; k86 = 99
.line	290	loadk         r8   k46 ; k46 = 49
.line	290	loadk         r9   k87 ; k87 = 77
.line	290	loadk        r10   k88 ; k88 = 18
.line	290	loadk        r11   k35 ; k35 = 192
.line	290	loadk        r12  k111 ; k111 = 163
.line	290	loadk        r13   k50 ; k50 = 46
.line	290	loadk        r14   k57 ; k57 = 52
.line	290	loadk        r15   k99 ; k99 = 1
.line	290	loadk        r16   k50 ; k50 = 46
.line	290	loadk        r17   k16 ; k16 = 36
.line	290	loadk        r18  k112 ; k112 = 106
.line	290	loadk        r19  k113 ; k113 = 141
.line	290	loadk        r20  k114 ; k114 = 230
.line	290	loadk        r21   k36 ; k36 = 130
.line	290	loadk        r22   k61 ; k61 = 157
.line	290	loadk        r23  k115 ; k115 = 14
.line	290	loadk        r24  k116 ; k116 = 13
.line	290	loadk        r25  k117 ; k117 = 191
.line	290	call          r4    22     2
.line	290	call          r3     2     2
.line	290	gettable      r4    r3  k118 ; k118 = "GetGameInstance"
.line	290	call          r4     1     2
.line	290	gettabup      r5    u0  k119 ; k119 = "import"
.line	290	getupval      r6    u1
.line	290	loadk         r7  k120 ; k120 = 102
.line	290	loadk         r8   k54 ; k54 = 177
.line	290	loadk         r9  k121 ; k121 = 121
.line	290	loadk        r10   k33 ; k33 = 57
.line	290	loadk        r11  k122 ; k122 = 70
.line	290	loadk        r12   k88 ; k88 = 18
.line	290	loadk        r13  k123 ; k123 = 189
.line	290	loadk        r14   k44 ; k44 = 185
.line	290	loadk        r15  k124 ; k124 = 50
.line	290	loadk        r16   k38 ; k38 = 45
.line	290	loadk        r17  k125 ; k125 = 9
.line	290	loadk        r18  k126 ; k126 = 44
.line	290	loadk        r19  k104 ; k104 = 6
.line	290	loadk        r20   k38 ; k38 = 45
.line	290	loadk        r21  k127 ; k127 = 154
.line	290	loadk        r22  k128 ; k128 = 253
.line	290	loadk        r23  k129 ; k129 = 188
.line	290	loadk        r24  k127 ; k127 = 154
.line	290	loadk        r25   k47 ; k47 = 3
.line	290	call          r6    20     2
.line	290	call          r5     2     2
.line	290	gettable      r6    r5  k131 ; k131 = "GetConsoleVariableFl" (truncated)
.line	290	getupval      r7    u1
.line	290	loadk         r8  k132 ; k132 = 89
.line	290	loadk         r9  k133 ; k133 = 246
.line	290	loadk        r10  k134 ; k134 = 71
.line	290	loadk        r11    k8 ; k8 = 53
.line	290	loadk        r12  k135 ; k135 = 91
.line	290	loadk        r13   k64 ; k64 = 32
.line	290	loadk        r14  k136 ; k136 = 190
.line	290	loadk        r15  k137 ; k137 = 147
.line	290	call          r7     9     2
.line	290	call          r6     2     2
.line	290	settable      r0  k130    r6 ; k130 = "_CacheFPSLimit"
.line	290	test          r2     0
.line	290	jmp            0  l440
.line	290	gettable      r6    r2  k138 ; k138 = "bIsHighPerformance"
.line	290	test          r6     0
.line	290	jmp            0  l440
.line	290	gettabup      r6    u0    k1 ; k1 = "print"
.line	290	gettabup      r7    u0    k2 ; k2 = "bWriteLog"
.line	290	test          r7     0
.line	290	jmp            0  l425
.line	290	gettabup      r7    u0    k3 ; k3 = "table"
.line	290	gettable      r7    r7    k4 ; k4 = "concat"
.line	290	newtable      r8     2     0
.line	290	getupval      r9    u1
.line	290	loadk        r10    k5 ; k5 = 110
.line	290	loadk        r11    k6 ; k6 = 170
.line	290	loadk        r12    k7 ; k7 = 111
.line	290	loadk        r13    k8 ; k8 = 53
.line	290	loadk        r14    k9 ; k9 = 87
.line	290	loadk        r15   k10 ; k10 = 15
.line	290	loadk        r16   k11 ; k11 = 152
.line	290	loadk        r17   k12 ; k12 = 165
.line	290	loadk        r18   k13 ; k13 = 12
.line	290	loadk        r19   k14 ; k14 = 54
.line	290	loadk        r20   k15 ; k15 = 8
.line	290	loadk        r21   k16 ; k16 = 36
.line	290	loadk        r22   k17 ; k17 = 11
.line	290	loadk        r23   k18 ; k18 = 55
.line	290	loadk        r24   k19 ; k19 = 139
.line	290	loadk        r25   k20 ; k20 = 234
.line	290	loadk        r26   k21 ; k21 = 169
.line	290	loadk        r27   k22 ; k22 = 171
.line	290	loadk        r28   k23 ; k23 = 21
.line	290	loadk        r29   k24 ; k24 = 23
.line	290	loadk        r30   k25 ; k25 = 167
.line	290	loadk        r31   k26 ; k26 = 5
.line	290	loadk        r32   k27 ; k27 = 235
.line	290	loadk        r33   k28 ; k28 = 146
.line	290	loadk        r34   k29 ; k29 = 2
.line	290	loadk        r35   k30 ; k30 = 48
.line	290	loadk        r36   k10 ; k10 = 15
.line	290	loadk        r37   k31 ; k31 = 37
.line	290	loadk        r38   k32 ; k32 = 63
.line	290	loadk        r39   k33 ; k33 = 57
.line	290	loadk        r40   k34 ; k34 = 210
.line	290	loadk        r41   k35 ; k35 = 192
.line	290	loadk        r42   k36 ; k36 = 130
.line	290	loadk        r43   k37 ; k37 = 150
.line	290	loadk        r44   k38 ; k38 = 45
.line	290	loadk        r45   k23 ; k23 = 21
.line	290	loadk        r46   k39 ; k39 = 174
.line	290	loadk        r47   k40 ; k40 = 35
.line	290	loadk        r48   k41 ; k41 = 222
.line	290	loadk        r49   k42 ; k42 = 129
.line	290	call          r9    41     2
.line	290	getupval     r10    u1
.line	290	loadk        r11   k43 ; k43 = 95
.line	290	loadk        r12   k44 ; k44 = 185
.line	290	loadk        r13   k45 ; k45 = 103
.line	290	loadk        r14   k46 ; k46 = 49
.line	290	loadk        r15    k9 ; k9 = 87
.line	290	loadk        r16   k47 ; k47 = 3
.line	290	loadk        r17   k48 ; k48 = 156
.line	290	loadk        r18   k49 ; k49 = 140
.line	290	loadk        r19   k50 ; k50 = 46
.line	290	loadk        r20   k51 ; k51 = 56
.line	290	loadk        r21   k15 ; k15 = 8
.line	290	loadk        r22   k16 ; k16 = 36
.line	290	loadk        r23   k50 ; k50 = 46
.line	290	loadk        r24   k26 ; k26 = 5
.line	290	loadk        r25   k52 ; k52 = 136
.line	290	loadk        r26   k53 ; k53 = 255
.line	290	loadk        r27   k54 ; k54 = 177
.line	290	loadk        r28   k55 ; k55 = 145
.line	290	loadk        r29   k56 ; k56 = 60
.line	290	loadk        r30   k57 ; k57 = 52
.line	290	loadk        r31   k58 ; k58 = 128
.line	290	loadk        r32   k59 ; k59 = 26
.line	290	loadk        r33   k60 ; k60 = 247
.line	290	loadk        r34   k61 ; k61 = 157
.line	290	loadk        r35   k51 ; k51 = 56
.line	290	loadk        r36   k62 ; k62 = 61
.line	290	loadk        r37   k63 ; k63 = 92
.line	290	loadk        r38   k73 ; k73 = 51
.line	290	loadk        r39   k74 ; k74 = 19
.line	290	loadk        r40   k75 ; k75 = 39
.line	290	loadk        r41  k139 ; k139 = 160
.line	290	loadk        r42  k133 ; k133 = 246
.line	290	loadk        r43    k6 ; k6 = 170
.line	290	loadk        r44  k140 ; k140 = 144
.line	290	loadk        r45  k141 ; k141 = 58
.line	290	loadk        r46   k69 ; k69 = 17
.line	290	loadk        r47   k54 ; k54 = 177
.line	290	loadk        r48   k64 ; k64 = 32
.line	290	loadk        r49   k80 ; k80 = 225
.line	290	loadk        r50   k28 ; k28 = 146
.line	290	call         r10    41     2
.line	290	getupval     r11    u1
.line	290	loadk        r12  k142 ; k142 = 64
.line	290	loadk        r13   k44 ; k44 = 185
.line	290	loadk        r14   k92 ; k92 = 100
.line	290	loadk        r15   k18 ; k18 = 55
.line	290	loadk        r16  k122 ; k122 = 70
.line	290	call         r11     6     0
.line	290	setlist       r8     0     1
.line	290	call          r7     2     2
.label	l425
.line	290	call          r6     2     1
.line	290	self          r6    r4  k143 ; k143 = "ExecuteCMD"
.line	290	getupval      r8    u1
.line	290	loadk         r9  k132 ; k132 = 89
.line	290	loadk        r10  k133 ; k133 = 246
.line	290	loadk        r11  k134 ; k134 = 71
.line	290	loadk        r12    k8 ; k8 = 53
.line	290	loadk        r13  k135 ; k135 = 91
.line	290	loadk        r14   k64 ; k64 = 32
.line	290	loadk        r15  k136 ; k136 = 190
.line	290	loadk        r16  k137 ; k137 = 147
.line	290	call          r8     9     2
.line	290	loadk         r9   k56 ; k56 = 60
.line	290	call          r6     4     1
.line	290	return        r0     1
.label	l440
.line	290	self          r6    r4  k143 ; k143 = "ExecuteCMD"
.line	290	getupval      r8    u1
.line	290	loadk         r9  k132 ; k132 = 89
.line	290	loadk        r10  k133 ; k133 = 246
.line	290	loadk        r11  k134 ; k134 = 71
.line	290	loadk        r12    k8 ; k8 = 53
.line	290	loadk        r13  k135 ; k135 = 91
.line	290	loadk        r14   k64 ; k64 = 32
.line	290	loadk        r15  k136 ; k136 = 190
.line	290	loadk        r16  k137 ; k137 = 147
.line	290	call          r8     9     2
.line	290	loadk         r9  k144 ; k144 = 30
.line	290	call          r6     4     1
.line	290	return        r0     1
.line	290	move          r0    r0
.line	290	move          r0    r0
.line	290	gettabup      r0    u0  k119 ; k119 = "import"
.line	290	return        r0     1

.function	main/f16

.source	null
.linedefined	310
.lastlinedefined	327
.numparams	3
.is_vararg	0
.maxstacksize	8

.constant	k0	"bForceEnable"
.constant	k1	nil
.constant	k2	"bEnableAssetCost"
.constant	k3	"InstanceChangeTimerId"
.constant	k4	"AddGameTimer"
.constant	k5	0.5
.constant	k6	"RemoveGameTimer"

.line	310	test          r2     0
.line	310	jmp            0    l4
.line	310	settable      r0    k0    r1 ; k0 = "bForceEnable"
.label	l4
.line	310	gettable      r3    r0    k0 ; k0 = "bForceEnable"
.line	310	eq             1    r3    k1 ; k1 = nil
.line	310	jmp            0   l12
.line	310	testset       r3    r1     0
.line	310	jmp            0   l10
.line	310	gettable      r3    r0    k0 ; k0 = "bForceEnable"
.label	l10
.line	310	settable      r0    k2    r3 ; k2 = "bEnableAssetCost"
.line	310	jmp            0   l13
.label	l12
.line	310	settable      r0    k2    r1 ; k2 = "bEnableAssetCost"
.label	l13
.line	310	gettable      r3    r0    k2 ; k2 = "bEnableAssetCost"
.line	310	test          r3     0
.line	310	jmp            0   l23
.line	310	self          r3    r0    k4 ; k4 = "AddGameTimer"
.line	310	loadk         r5    k5 ; k5 = 0.5
.line	310	loadbool      r6     1     0
.line	310	closure       r7    f0
.line	310	call          r3     5     2
.line	310	settable      r0    k3    r3 ; k3 = "InstanceChangeTimerI" (truncated)
.line	310	jmp            0   l30
.label	l23
.line	310	gettable      r3    r0    k3 ; k3 = "InstanceChangeTimerI" (truncated)
.line	310	test          r3     0
.line	310	jmp            0   l30
.line	310	self          r3    r0    k6 ; k6 = "RemoveGameTimer"
.line	310	gettable      r5    r0    k3 ; k3 = "InstanceChangeTimerI" (truncated)
.line	310	call          r3     3     1
.line	310	settable      r0    k3    k1 ; k1 = nil
.label	l30
.line	310	return        r0     1
.line	310	move          r0    r0
.line	310	move          r0    r0
.line	310	move          r0    r0
.line	310	return        r0     1

.function	main/f16/f0

.source	null
.linedefined	320
.lastlinedefined	322
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	true

.constant	k0	"InstanceChangedUpdate"

.line	320	getupval      r0    u0
.line	320	self          r0    r0    k0 ; k0 = "InstanceChangedUpdat" (truncated)
.line	320	call          r0     2     1
.line	320	return        r0     1
.line	320	move          r0    r0
.line	320	move          r0    r0
.line	320	move          r0    r0
.line	320	move          r0    r0
.line	320	return        r0     1

.function	main/f17

.source	null
.linedefined	329
.lastlinedefined	331
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	"bEnableAssetCost"

.line	329	gettable      r1    r0    k0 ; k0 = "bEnableAssetCost"
.line	329	return        r1     2
.line	329	return        r0     1
.line	329	move          r0    r0
.line	329	move          r0    r0
.line	329	return        r0     1

.function	main/f18

.source	null
.linedefined	333
.lastlinedefined	338
.numparams	2
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	24	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"bWriteLog"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	110
.constant	k4	170
.constant	k5	111
.constant	k6	53
.constant	k7	87
.constant	k8	15
.constant	k9	152
.constant	k10	165
.constant	k11	12
.constant	k12	54
.constant	k13	8
.constant	k14	36
.constant	k15	11
.constant	k16	55
.constant	k17	139
.constant	k18	234
.constant	k19	169
.constant	k20	171
.constant	k21	21
.constant	k22	23
.constant	k23	167
.constant	k24	5
.constant	k25	235
.constant	k26	146
.constant	k27	2
.constant	k28	48
.constant	k29	37
.constant	k30	63
.constant	k31	57
.constant	k32	210
.constant	k33	222
.constant	k34	156
.constant	k35	35
.constant	k36	19
.constant	k37	173
.constant	k38	41
.constant	k39	252
.constant	k40	133
.constant	k41	100
.constant	k42	182
.constant	k43	121
.constant	k44	32
.constant	k45	66
.constant	k46	141
.constant	k47	29
.constant	k48	76
.constant	k49	140
.constant	k50	238
.constant	k51	179
.constant	k52	31
.constant	k53	45
.constant	k54	151
.constant	k55	108
.constant	k56	"tostring"
.constant	k57	"IgnoreInstanceIDMap"
.constant	k58	nil
.constant	k59	true

.line	333	getupval      r2    u0
.line	333	gettabup      r3    u1    k0 ; k0 = "bWriteLog"
.line	333	test          r3     0
.line	333	jmp            0   l80
.line	333	gettabup      r3    u1    k1 ; k1 = "table"
.line	333	gettable      r3    r3    k2 ; k2 = "concat"
.line	333	newtable      r4     1     0
.line	333	getupval      r5    u2
.line	333	loadk         r6    k3 ; k3 = 110
.line	333	loadk         r7    k4 ; k4 = 170
.line	333	loadk         r8    k5 ; k5 = 111
.line	333	loadk         r9    k6 ; k6 = 53
.line	333	loadk        r10    k7 ; k7 = 87
.line	333	loadk        r11    k8 ; k8 = 15
.line	333	loadk        r12    k9 ; k9 = 152
.line	333	loadk        r13   k10 ; k10 = 165
.line	333	loadk        r14   k11 ; k11 = 12
.line	333	loadk        r15   k12 ; k12 = 54
.line	333	loadk        r16   k13 ; k13 = 8
.line	333	loadk        r17   k14 ; k14 = 36
.line	333	loadk        r18   k15 ; k15 = 11
.line	333	loadk        r19   k16 ; k16 = 55
.line	333	loadk        r20   k17 ; k17 = 139
.line	333	loadk        r21   k18 ; k18 = 234
.line	333	loadk        r22   k19 ; k19 = 169
.line	333	loadk        r23   k20 ; k20 = 171
.line	333	loadk        r24   k21 ; k21 = 21
.line	333	loadk        r25   k22 ; k22 = 23
.line	333	loadk        r26   k23 ; k23 = 167
.line	333	loadk        r27   k24 ; k24 = 5
.line	333	loadk        r28   k25 ; k25 = 235
.line	333	loadk        r29   k26 ; k26 = 146
.line	333	loadk        r30   k27 ; k27 = 2
.line	333	loadk        r31   k28 ; k28 = 48
.line	333	loadk        r32    k8 ; k8 = 15
.line	333	loadk        r33   k29 ; k29 = 37
.line	333	loadk        r34   k30 ; k30 = 63
.line	333	loadk        r35   k31 ; k31 = 57
.line	333	loadk        r36   k32 ; k32 = 210
.line	333	loadk        r37   k33 ; k33 = 222
.line	333	loadk        r38   k19 ; k19 = 169
.line	333	loadk        r39   k34 ; k34 = 156
.line	333	loadk        r40   k35 ; k35 = 35
.line	333	loadk        r41   k36 ; k36 = 19
.line	333	loadk        r42   k37 ; k37 = 173
.line	333	loadk        r43   k38 ; k38 = 41
.line	333	loadk        r44   k39 ; k39 = 252
.line	333	loadk        r45   k40 ; k40 = 133
.line	333	call          r5    41     2
.line	333	getupval      r6    u2
.line	333	loadk         r7   k41 ; k41 = 100
.line	333	loadk         r8   k42 ; k42 = 182
.line	333	loadk         r9   k43 ; k43 = 121
.line	333	loadk        r10   k44 ; k44 = 32
.line	333	loadk        r11   k45 ; k45 = 66
.line	333	loadk        r12   k13 ; k13 = 8
.line	333	loadk        r13   k46 ; k46 = 141
.line	333	loadk        r14   k10 ; k10 = 165
.line	333	loadk        r15   k13 ; k13 = 8
.line	333	loadk        r16   k47 ; k47 = 29
.line	333	loadk        r17   k48 ; k48 = 76
.line	333	loadk        r18   k13 ; k13 = 8
.line	333	loadk        r19   k14 ; k14 = 36
.line	333	loadk        r20   k16 ; k16 = 55
.line	333	loadk        r21   k49 ; k49 = 140
.line	333	loadk        r22   k50 ; k50 = 238
.line	333	loadk        r23   k51 ; k51 = 179
.line	333	loadk        r24   k17 ; k17 = 139
.line	333	loadk        r25   k52 ; k52 = 31
.line	333	loadk        r26   k53 ; k53 = 45
.line	333	loadk        r27   k54 ; k54 = 151
.line	333	loadk        r28   k55 ; k55 = 108
.line	333	call          r6    23     0
.line	333	setlist       r4     0     1
.line	333	call          r3     2     2
.line	333	gettabup      r4    u1   k56 ; k56 = "tostring"
.line	333	move          r5    r1
.line	333	call          r4     2     2
.line	333	concat        r3    r3    r4
.label	l80
.line	333	call          r2     2     1
.line	333	gettable      r2    r0   k57 ; k57 = "IgnoreInstanceIDMap"
.line	333	eq             1    r2   k58 ; k58 = nil
.line	333	jmp            0   l90
.line	333	gettable      r2    r0   k57 ; k57 = "IgnoreInstanceIDMap"
.line	333	gettable      r2    r2    r1
.line	333	eq             0    r2   k58 ; k58 = nil
.line	333	jmp            0   l90
.line	333	gettable      r2    r0   k57 ; k57 = "IgnoreInstanceIDMap"
.line	333	settable      r2    r1   k59 ; k59 = true
.label	l90
.line	333	return        r0     1
.line	333	move          r0    r0
.line	333	move          r0    r0
.line	333	move          r0    r0
.line	333	move          r0    r0
.line	333	return        r0     1

.function	main/f19

.source	null
.linedefined	340
.lastlinedefined	345
.numparams	2
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	24	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"bWriteLog"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	110
.constant	k4	170
.constant	k5	111
.constant	k6	53
.constant	k7	87
.constant	k8	15
.constant	k9	152
.constant	k10	165
.constant	k11	12
.constant	k12	54
.constant	k13	8
.constant	k14	36
.constant	k15	11
.constant	k16	55
.constant	k17	139
.constant	k18	234
.constant	k19	169
.constant	k20	171
.constant	k21	21
.constant	k22	23
.constant	k23	167
.constant	k24	5
.constant	k25	235
.constant	k26	146
.constant	k27	2
.constant	k28	48
.constant	k29	37
.constant	k30	63
.constant	k31	57
.constant	k32	210
.constant	k33	205
.constant	k34	168
.constant	k35	149
.constant	k36	166
.constant	k37	233
.constant	k38	142
.constant	k39	66
.constant	k40	29
.constant	k41	77
.constant	k42	154
.constant	k43	161
.constant	k44	47
.constant	k45	58
.constant	k46	9
.constant	k47	14
.constant	k48	100
.constant	k49	177
.constant	k50	225
.constant	k51	174
.constant	k52	156
.constant	k53	27
.constant	k54	10
.constant	k55	176
.constant	k56	51
.constant	k57	215
.constant	k58	180
.constant	k59	107
.constant	k60	"tostring"
.constant	k61	"IgnoreInstanceIDMap"
.constant	k62	nil
.constant	k63	true

.line	340	getupval      r2    u0
.line	340	gettabup      r3    u1    k0 ; k0 = "bWriteLog"
.line	340	test          r3     0
.line	340	jmp            0   l83
.line	340	gettabup      r3    u1    k1 ; k1 = "table"
.line	340	gettable      r3    r3    k2 ; k2 = "concat"
.line	340	newtable      r4     1     0
.line	340	getupval      r5    u2
.line	340	loadk         r6    k3 ; k3 = 110
.line	340	loadk         r7    k4 ; k4 = 170
.line	340	loadk         r8    k5 ; k5 = 111
.line	340	loadk         r9    k6 ; k6 = 53
.line	340	loadk        r10    k7 ; k7 = 87
.line	340	loadk        r11    k8 ; k8 = 15
.line	340	loadk        r12    k9 ; k9 = 152
.line	340	loadk        r13   k10 ; k10 = 165
.line	340	loadk        r14   k11 ; k11 = 12
.line	340	loadk        r15   k12 ; k12 = 54
.line	340	loadk        r16   k13 ; k13 = 8
.line	340	loadk        r17   k14 ; k14 = 36
.line	340	loadk        r18   k15 ; k15 = 11
.line	340	loadk        r19   k16 ; k16 = 55
.line	340	loadk        r20   k17 ; k17 = 139
.line	340	loadk        r21   k18 ; k18 = 234
.line	340	loadk        r22   k19 ; k19 = 169
.line	340	loadk        r23   k20 ; k20 = 171
.line	340	loadk        r24   k21 ; k21 = 21
.line	340	loadk        r25   k22 ; k22 = 23
.line	340	loadk        r26   k23 ; k23 = 167
.line	340	loadk        r27   k24 ; k24 = 5
.line	340	loadk        r28   k25 ; k25 = 235
.line	340	loadk        r29   k26 ; k26 = 146
.line	340	loadk        r30   k27 ; k27 = 2
.line	340	loadk        r31   k28 ; k28 = 48
.line	340	loadk        r32    k8 ; k8 = 15
.line	340	loadk        r33   k29 ; k29 = 37
.line	340	loadk        r34   k30 ; k30 = 63
.line	340	loadk        r35   k31 ; k31 = 57
.line	340	loadk        r36   k32 ; k32 = 210
.line	340	loadk        r37   k33 ; k33 = 205
.line	340	loadk        r38   k34 ; k34 = 168
.line	340	loadk        r39   k35 ; k35 = 149
.line	340	loadk        r40   k24 ; k24 = 5
.line	340	loadk        r41   k27 ; k27 = 2
.line	340	loadk        r42   k36 ; k36 = 166
.line	340	loadk        r43    k8 ; k8 = 15
.line	340	loadk        r44   k37 ; k37 = 233
.line	340	loadk        r45   k38 ; k38 = 142
.line	340	call          r5    41     2
.line	340	getupval      r6    u2
.line	340	loadk         r7   k39 ; k39 = 66
.line	340	loadk         r8    k4 ; k4 = 170
.line	340	loadk         r9    k5 ; k5 = 111
.line	340	loadk        r10   k40 ; k40 = 29
.line	340	loadk        r11   k41 ; k41 = 77
.line	340	loadk        r12   k21 ; k21 = 21
.line	340	loadk        r13   k42 ; k42 = 154
.line	340	loadk        r14   k43 ; k43 = 161
.line	340	loadk        r15   k44 ; k44 = 47
.line	340	loadk        r16   k45 ; k45 = 58
.line	340	loadk        r17   k46 ; k46 = 9
.line	340	loadk        r18   k13 ; k13 = 8
.line	340	loadk        r19   k47 ; k47 = 14
.line	340	loadk        r20   k48 ; k48 = 100
.line	340	loadk        r21   k49 ; k49 = 177
.line	340	loadk        r22   k50 ; k50 = 225
.line	340	loadk        r23   k51 ; k51 = 174
.line	340	loadk        r24   k52 ; k52 = 156
.line	340	loadk        r25   k53 ; k53 = 27
.line	340	loadk        r26   k54 ; k54 = 10
.line	340	loadk        r27   k55 ; k55 = 176
.line	340	loadk        r28   k56 ; k56 = 51
.line	340	loadk        r29   k57 ; k57 = 215
.line	340	loadk        r30   k58 ; k58 = 180
.line	340	loadk        r31   k59 ; k59 = 107
.line	340	call          r6    26     0
.line	340	setlist       r4     0     1
.line	340	call          r3     2     2
.line	340	gettabup      r4    u1   k60 ; k60 = "tostring"
.line	340	move          r5    r1
.line	340	call          r4     2     2
.line	340	concat        r3    r3    r4
.label	l83
.line	340	call          r2     2     1
.line	340	gettable      r2    r0   k61 ; k61 = "IgnoreInstanceIDMap"
.line	340	eq             1    r2   k62 ; k62 = nil
.line	340	jmp            0   l93
.line	340	gettable      r2    r0   k61 ; k61 = "IgnoreInstanceIDMap"
.line	340	gettable      r2    r2    r1
.line	340	eq             0    r2   k63 ; k63 = true
.line	340	jmp            0   l93
.line	340	gettable      r2    r0   k61 ; k61 = "IgnoreInstanceIDMap"
.line	340	settable      r2    r1   k62 ; k62 = nil
.label	l93
.line	340	return        r0     1
.line	340	move          r0    r0
.line	340	move          r0    r0
.line	340	move          r0    r0
.line	340	return        r0     1

.function	main/f20

.source	null
.linedefined	347
.lastlinedefined	360
.numparams	2
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	35	true
.upvalue	"U1"	24	true
.upvalue	"U2"	0	false
.upvalue	"U3"	1	true

.constant	k0	"MapCenterPos"
.constant	k1	"MapCellCount"
.constant	k2	"floor"
.constant	k3	"X"
.constant	k4	"MapCellSize"
.constant	k5	"Y"
.constant	k6	"MapCellHalfCount"
.constant	k7	"huge"
.constant	k8	"bWriteLog"
.constant	k9	"string"
.constant	k10	"format"
.constant	k11	"table"
.constant	k12	"concat"
.constant	k13	110
.constant	k14	170
.constant	k15	111
.constant	k16	53
.constant	k17	87
.constant	k18	15
.constant	k19	152
.constant	k20	165
.constant	k21	12
.constant	k22	54
.constant	k23	8
.constant	k24	36
.constant	k25	11
.constant	k26	55
.constant	k27	139
.constant	k28	234
.constant	k29	169
.constant	k30	171
.constant	k31	21
.constant	k32	23
.constant	k33	167
.constant	k34	5
.constant	k35	235
.constant	k36	146
.constant	k37	2
.constant	k38	48
.constant	k39	37
.constant	k40	63
.constant	k41	57
.constant	k42	210
.constant	k43	216
.constant	k44	168
.constant	k45	140
.constant	k46	41
.constant	k47	17
.constant	k48	175
.constant	k49	42
.constant	k50	199
.constant	k51	142
.constant	k52	73
.constant	k53	189
.constant	k54	114
.constant	k55	116
.constant	k56	74
.constant	k57	161
.constant	k58	45
.constant	k59	97
.constant	k60	38
.constant	k61	43
.constant	k62	155
.constant	k63	133
.constant	k64	95
.constant	k65	243
.constant	k66	164
.constant	k67	213
.constant	k68	34
.constant	k69	"tostring"
.constant	k70	-1
.constant	k71	83
.constant	k72	7
.constant	k73	156
.constant	k74	44
.constant	k75	121
.constant	k76	9
.constant	k77	51
.constant	k78	56
.constant	k79	138
.constant	k80	174
.constant	k81	252
.constant	k82	0

.line	347	test          r1     0
.line	347	jmp            0  l132
.line	347	gettable      r2    r0    k0 ; k0 = "MapCenterPos"
.line	347	test          r2     0
.line	347	jmp            0  l132
.line	347	gettable      r2    r0    k1 ; k1 = "MapCellCount"
.line	347	test          r2     0
.line	347	jmp            0  l132
.line	347	gettabup      r2    u0    k2 ; k2 = "floor"
.line	347	gettable      r3    r1    k3 ; k3 = "X"
.line	347	gettable      r4    r0    k0 ; k0 = "MapCenterPos"
.line	347	gettable      r4    r4    k3 ; k3 = "X"
.line	347	sub           r3    r3    r4
.line	347	gettable      r4    r0    k4 ; k4 = "MapCellSize"
.line	347	div           r3    r3    r4
.line	347	call          r2     2     2
.line	347	gettabup      r3    u0    k2 ; k2 = "floor"
.line	347	gettable      r4    r1    k5 ; k5 = "Y"
.line	347	gettable      r5    r0    k0 ; k0 = "MapCenterPos"
.line	347	gettable      r5    r5    k5 ; k5 = "Y"
.line	347	sub           r4    r4    r5
.line	347	gettable      r5    r0    k4 ; k4 = "MapCellSize"
.line	347	div           r4    r4    r5
.line	347	call          r3     2     2
.line	347	gettable      r4    r0    k1 ; k1 = "MapCellCount"
.line	347	gettable      r5    r0    k6 ; k6 = "MapCellHalfCount"
.line	347	add           r5    r3    r5
.line	347	mul           r4    r4    r5
.line	347	add           r4    r4    r2
.line	347	gettable      r5    r0    k6 ; k6 = "MapCellHalfCount"
.line	347	add           r4    r4    r5
.line	347	eq             0    r4    r4
.line	347	jmp            0   l41
.line	347	gettabup      r5    u0    k7 ; k7 = "huge"
.line	347	eq             1    r4    r5
.line	347	jmp            0   l41
.line	347	gettabup      r5    u0    k7 ; k7 = "huge"
.line	347	unm           r5    r5
.line	347	eq             0    r4    r5
.line	347	jmp            0  l131
.label	l41
.line	347	getupval      r5    u1
.line	347	gettabup      r6    u2    k8 ; k8 = "bWriteLog"
.line	347	test          r6     0
.line	347	jmp            0  l128
.line	347	gettabup      r6    u2    k9 ; k9 = "string"
.line	347	gettable      r6    r6   k10 ; k10 = "format"
.line	347	gettabup      r7    u2   k11 ; k11 = "table"
.line	347	gettable      r7    r7   k12 ; k12 = "concat"
.line	347	newtable      r8     1     0
.line	347	getupval      r9    u3
.line	347	loadk        r10   k13 ; k13 = 110
.line	347	loadk        r11   k14 ; k14 = 170
.line	347	loadk        r12   k15 ; k15 = 111
.line	347	loadk        r13   k16 ; k16 = 53
.line	347	loadk        r14   k17 ; k17 = 87
.line	347	loadk        r15   k18 ; k18 = 15
.line	347	loadk        r16   k19 ; k19 = 152
.line	347	loadk        r17   k20 ; k20 = 165
.line	347	loadk        r18   k21 ; k21 = 12
.line	347	loadk        r19   k22 ; k22 = 54
.line	347	loadk        r20   k23 ; k23 = 8
.line	347	loadk        r21   k24 ; k24 = 36
.line	347	loadk        r22   k25 ; k25 = 11
.line	347	loadk        r23   k26 ; k26 = 55
.line	347	loadk        r24   k27 ; k27 = 139
.line	347	loadk        r25   k28 ; k28 = 234
.line	347	loadk        r26   k29 ; k29 = 169
.line	347	loadk        r27   k30 ; k30 = 171
.line	347	loadk        r28   k31 ; k31 = 21
.line	347	loadk        r29   k32 ; k32 = 23
.line	347	loadk        r30   k33 ; k33 = 167
.line	347	loadk        r31   k34 ; k34 = 5
.line	347	loadk        r32   k35 ; k35 = 235
.line	347	loadk        r33   k36 ; k36 = 146
.line	347	loadk        r34   k37 ; k37 = 2
.line	347	loadk        r35   k38 ; k38 = 48
.line	347	loadk        r36   k18 ; k18 = 15
.line	347	loadk        r37   k39 ; k39 = 37
.line	347	loadk        r38   k40 ; k40 = 63
.line	347	loadk        r39   k41 ; k41 = 57
.line	347	loadk        r40   k42 ; k42 = 210
.line	347	loadk        r41   k43 ; k43 = 216
.line	347	loadk        r42   k44 ; k44 = 168
.line	347	loadk        r43   k45 ; k45 = 140
.line	347	loadk        r44   k46 ; k46 = 41
.line	347	loadk        r45   k47 ; k47 = 17
.line	347	loadk        r46   k48 ; k48 = 175
.line	347	loadk        r47   k49 ; k49 = 42
.line	347	loadk        r48   k50 ; k50 = 199
.line	347	loadk        r49   k51 ; k51 = 142
.line	347	call          r9    41     2
.line	347	getupval     r10    u3
.line	347	loadk        r11   k52 ; k52 = 73
.line	347	loadk        r12   k53 ; k53 = 189
.line	347	loadk        r13   k54 ; k54 = 114
.line	347	loadk        r14   k55 ; k55 = 116
.line	347	loadk        r15   k56 ; k56 = 74
.line	347	loadk        r16   k23 ; k23 = 8
.line	347	loadk        r17   k19 ; k19 = 152
.line	347	loadk        r18   k57 ; k57 = 161
.line	347	loadk        r19   k58 ; k58 = 45
.line	347	loadk        r20   k38 ; k38 = 48
.line	347	loadk        r21   k23 ; k23 = 8
.line	347	loadk        r22   k59 ; k59 = 97
.line	347	loadk        r23   k60 ; k60 = 38
.line	347	loadk        r24   k61 ; k61 = 43
.line	347	loadk        r25   k62 ; k62 = 155
.line	347	loadk        r26   k48 ; k48 = 175
.line	347	loadk        r27   k63 ; k63 = 133
.line	347	loadk        r28   k42 ; k42 = 210
.line	347	loadk        r29   k64 ; k64 = 95
.line	347	loadk        r30   k32 ; k32 = 23
.line	347	loadk        r31   k65 ; k65 = 243
.line	347	loadk        r32   k18 ; k18 = 15
.line	347	loadk        r33   k66 ; k66 = 164
.line	347	loadk        r34   k67 ; k67 = 213
.line	347	loadk        r35   k68 ; k68 = 34
.line	347	call         r10    26     0
.line	347	setlist       r8     0     1
.line	347	call          r7     2     2
.line	347	gettabup      r8    u2   k69 ; k69 = "tostring"
.line	347	gettable      r9    r1    k3 ; k3 = "X"
.line	347	call          r8     2     2
.line	347	gettabup      r9    u2   k69 ; k69 = "tostring"
.line	347	gettable     r10    r1    k5 ; k5 = "Y"
.line	347	call          r9     2     0
.line	347	call          r6     0     2
.label	l128
.line	347	call          r5     2     1
.line	347	loadk         r5   k70 ; k70 = -1
.line	347	return        r5     2
.label	l131
.line	347	return        r4     2
.label	l132
.line	347	getupval      r2    u1
.line	347	gettabup      r3    u2    k8 ; k8 = "bWriteLog"
.line	347	test          r3     0
.line	347	jmp            0  l202
.line	347	gettabup      r3    u2   k11 ; k11 = "table"
.line	347	gettable      r3    r3   k12 ; k12 = "concat"
.line	347	newtable      r4     1     0
.line	347	getupval      r5    u3
.line	347	loadk         r6   k13 ; k13 = 110
.line	347	loadk         r7   k14 ; k14 = 170
.line	347	loadk         r8   k15 ; k15 = 111
.line	347	loadk         r9   k16 ; k16 = 53
.line	347	loadk        r10   k17 ; k17 = 87
.line	347	loadk        r11   k18 ; k18 = 15
.line	347	loadk        r12   k19 ; k19 = 152
.line	347	loadk        r13   k20 ; k20 = 165
.line	347	loadk        r14   k21 ; k21 = 12
.line	347	loadk        r15   k22 ; k22 = 54
.line	347	loadk        r16   k23 ; k23 = 8
.line	347	loadk        r17   k24 ; k24 = 36
.line	347	loadk        r18   k25 ; k25 = 11
.line	347	loadk        r19   k26 ; k26 = 55
.line	347	loadk        r20   k27 ; k27 = 139
.line	347	loadk        r21   k28 ; k28 = 234
.line	347	loadk        r22   k29 ; k29 = 169
.line	347	loadk        r23   k30 ; k30 = 171
.line	347	loadk        r24   k31 ; k31 = 21
.line	347	loadk        r25   k32 ; k32 = 23
.line	347	loadk        r26   k33 ; k33 = 167
.line	347	loadk        r27   k34 ; k34 = 5
.line	347	loadk        r28   k35 ; k35 = 235
.line	347	loadk        r29   k36 ; k36 = 146
.line	347	loadk        r30   k37 ; k37 = 2
.line	347	loadk        r31   k38 ; k38 = 48
.line	347	loadk        r32   k18 ; k18 = 15
.line	347	loadk        r33   k39 ; k39 = 37
.line	347	loadk        r34   k40 ; k40 = 63
.line	347	loadk        r35   k41 ; k41 = 57
.line	347	loadk        r36   k42 ; k42 = 210
.line	347	loadk        r37   k43 ; k43 = 216
.line	347	loadk        r38   k44 ; k44 = 168
.line	347	loadk        r39   k45 ; k45 = 140
.line	347	loadk        r40   k46 ; k46 = 41
.line	347	loadk        r41   k47 ; k47 = 17
.line	347	loadk        r42   k48 ; k48 = 175
.line	347	loadk        r43   k49 ; k49 = 42
.line	347	loadk        r44   k50 ; k50 = 199
.line	347	loadk        r45   k51 ; k51 = 142
.line	347	call          r5    41     2
.line	347	getupval      r6    u3
.line	347	loadk         r7   k52 ; k52 = 73
.line	347	loadk         r8   k53 ; k53 = 189
.line	347	loadk         r9   k54 ; k54 = 114
.line	347	loadk        r10   k55 ; k55 = 116
.line	347	loadk        r11   k71 ; k71 = 83
.line	347	loadk        r12   k72 ; k72 = 7
.line	347	loadk        r13   k73 ; k73 = 156
.line	347	loadk        r14   k57 ; k57 = 161
.line	347	loadk        r15   k74 ; k74 = 44
.line	347	loadk        r16   k75 ; k75 = 121
.line	347	loadk        r17   k76 ; k76 = 9
.line	347	loadk        r18   k77 ; k77 = 51
.line	347	loadk        r19   k78 ; k78 = 56
.line	347	loadk        r20   k61 ; k61 = 43
.line	347	loadk        r21   k79 ; k79 = 138
.line	347	loadk        r22   k80 ; k80 = 174
.line	347	loadk        r23   k81 ; k81 = 252
.line	347	call          r6    18     0
.line	347	setlist       r4     0     1
.line	347	call          r3     2     2
.label	l202
.line	347	call          r2     2     1
.line	347	loadk         r2   k82 ; k82 = 0
.line	347	return        r2     2
.line	347	return        r0     1
.line	347	move          r0    r0
.line	347	move          r0    r0
.line	347	move          r0    r0
.line	347	return        r0     1

.function	main/f21

.source	null
.linedefined	362
.lastlinedefined	387
.numparams	2
.is_vararg	0
.maxstacksize	9

.upvalue	"_ENV"	4	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"GetPlayerCharacter"
.constant	k1	"slua"
.constant	k2	"isValid"
.constant	k3	"GetAbilitySystemComponent"
.constant	k4	"GetBuildingInstanceID"
.constant	k5	"GetInstanceEditSubSystem"
.constant	k6	"GetCurSelectInstanceId"
.constant	k7	"GetObjectManager"
.constant	k8	"LuaGetObject"
.constant	k9	"GetActorLocation_LuaCache"
.constant	k10	"GetAssetId"
.constant	k11	nil
.constant	k12	"K2_GetActorLocation"

.line	362	loadnil       r2     2
.line	362	gettabup      r5    u0    k0 ; k0 = "GetPlayerCharacter"
.line	362	call          r5     1     2
.line	362	test          r1     0
.line	362	jmp            0    l8
.line	362	move          r4    r1
.line	362	jmp            0   l28
.label	l8
.line	362	gettabup      r6    u1    k1 ; k1 = "slua"
.line	362	gettable      r6    r6    k2 ; k2 = "isValid"
.line	362	move          r7    r5
.line	362	call          r6     2     2
.line	362	test          r6     0
.line	362	jmp            0   l28
.line	362	gettable      r6    r5    k3 ; k3 = "GetAbilitySystemComp" (truncated)
.line	362	test          r6     0
.line	362	jmp            0   l28
.line	362	self          r6    r5    k3 ; k3 = "GetAbilitySystemComp" (truncated)
.line	362	call          r6     2     2
.line	362	gettabup      r7    u1    k1 ; k1 = "slua"
.line	362	gettable      r7    r7    k2 ; k2 = "isValid"
.line	362	move          r8    r6
.line	362	call          r7     2     2
.line	362	test          r7     0
.line	362	jmp            0   l28
.line	362	self          r7    r6    k4 ; k4 = "GetBuildingInstanceI" (truncated)
.line	362	call          r7     2     2
.line	362	move          r4    r7
.label	l28
.line	362	test          r4     0
.line	362	jmp            0   l34
.line	362	getupval      r6    u2
.line	362	call          r6     1     2
.line	362	eq             0    r4    r6
.line	362	jmp            0   l39
.label	l34
.line	362	self          r6    r0    k5 ; k5 = "GetInstanceEditSubSy" (truncated)
.line	362	call          r6     2     2
.line	362	self          r6    r6    k6 ; k6 = "GetCurSelectInstance" (truncated)
.line	362	call          r6     2     2
.line	362	move          r4    r6
.label	l39
.line	362	test          r4     0
.line	362	jmp            0   l58
.line	362	gettabup      r6    u1    k7 ; k7 = "GetObjectManager"
.line	362	call          r6     1     2
.line	362	self          r6    r6    k8 ; k8 = "LuaGetObject"
.line	362	move          r8    r4
.line	362	call          r6     3     2
.line	362	gettabup      r7    u1    k1 ; k1 = "slua"
.line	362	gettable      r7    r7    k2 ; k2 = "isValid"
.line	362	move          r8    r6
.line	362	call          r7     2     2
.line	362	test          r7     0
.line	362	jmp            0   l58
.line	362	self          r7    r6    k9 ; k9 = "GetActorLocation_Lua" (truncated)
.line	362	call          r7     2     2
.line	362	move          r2    r7
.line	362	self          r7    r6   k10 ; k10 = "GetAssetId"
.line	362	call          r7     2     2
.line	362	move          r3    r7
.label	l58
.line	362	eq             0    r3   k11 ; k11 = nil
.line	362	jmp            0   l69
.line	362	gettabup      r6    u1    k1 ; k1 = "slua"
.line	362	gettable      r6    r6    k2 ; k2 = "isValid"
.line	362	move          r7    r5
.line	362	call          r6     2     2
.line	362	test          r6     0
.line	362	jmp            0   l69
.line	362	self          r6    r5   k12 ; k12 = "K2_GetActorLocation"
.line	362	call          r6     2     2
.line	362	move          r2    r6
.label	l69
.line	362	move          r6    r2
.line	362	move          r7    r3
.line	362	move          r8    r4
.line	362	return        r6     4
.line	362	return        r0     1
.line	362	move          r0    r0
.line	362	move          r0    r0
.line	362	return        r0     1

.function	main/f22

.source	null
.linedefined	389
.lastlinedefined	394
.numparams	1
.is_vararg	0
.maxstacksize	38

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"InstanceEditSubSystem"
.constant	k1	"SubsystemMgr"
.constant	k2	"Get"
.constant	k3	110
.constant	k4	170
.constant	k5	111
.constant	k6	53
.constant	k7	87
.constant	k8	15
.constant	k9	152
.constant	k10	165
.constant	k11	12
.constant	k12	54
.constant	k13	8
.constant	k14	36
.constant	k15	3
.constant	k16	42
.constant	k17	139
.constant	k18	251
.constant	k19	188
.constant	k20	134
.constant	k21	25
.constant	k22	1
.constant	k23	160
.constant	k24	19
.constant	k25	250
.constant	k26	153
.constant	k27	37
.constant	k28	26
.constant	k29	9
.constant	k30	51
.constant	k31	45
.constant	k32	155
.constant	k33	235
.constant	k34	168
.constant	k35	149

.line	389	gettable      r1    r0    k0 ; k0 = "InstanceEditSubSyste" (truncated)
.line	389	test          r1     1
.line	389	jmp            0   l44
.line	389	gettabup      r1    u0    k1 ; k1 = "SubsystemMgr"
.line	389	self          r1    r1    k2 ; k2 = "Get"
.line	389	getupval      r3    u1
.line	389	loadk         r4    k3 ; k3 = 110
.line	389	loadk         r5    k4 ; k4 = 170
.line	389	loadk         r6    k5 ; k5 = 111
.line	389	loadk         r7    k6 ; k6 = 53
.line	389	loadk         r8    k7 ; k7 = 87
.line	389	loadk         r9    k8 ; k8 = 15
.line	389	loadk        r10    k9 ; k9 = 152
.line	389	loadk        r11   k10 ; k10 = 165
.line	389	loadk        r12   k11 ; k11 = 12
.line	389	loadk        r13   k12 ; k12 = 54
.line	389	loadk        r14   k13 ; k13 = 8
.line	389	loadk        r15   k14 ; k14 = 36
.line	389	loadk        r16   k15 ; k15 = 3
.line	389	loadk        r17   k16 ; k16 = 42
.line	389	loadk        r18   k17 ; k17 = 139
.line	389	loadk        r19   k18 ; k18 = 251
.line	389	loadk        r20   k19 ; k19 = 188
.line	389	loadk        r21   k20 ; k20 = 134
.line	389	loadk        r22   k21 ; k21 = 25
.line	389	loadk        r23   k22 ; k22 = 1
.line	389	loadk        r24   k23 ; k23 = 160
.line	389	loadk        r25   k24 ; k24 = 19
.line	389	loadk        r26   k25 ; k25 = 250
.line	389	loadk        r27   k26 ; k26 = 153
.line	389	loadk        r28   k27 ; k27 = 37
.line	389	loadk        r29   k28 ; k28 = 26
.line	389	loadk        r30   k29 ; k29 = 9
.line	389	loadk        r31   k30 ; k30 = 51
.line	389	loadk        r32   k29 ; k29 = 9
.line	389	loadk        r33   k31 ; k31 = 45
.line	389	loadk        r34   k32 ; k32 = 155
.line	389	loadk        r35   k33 ; k33 = 235
.line	389	loadk        r36   k34 ; k34 = 168
.line	389	loadk        r37   k35 ; k35 = 149
.line	389	call          r3    35     2
.line	389	call          r1     3     2
.line	389	settable      r0    k0    r1 ; k0 = "InstanceEditSubSyste" (truncated)
.label	l44
.line	389	gettable      r1    r0    k0 ; k0 = "InstanceEditSubSyste" (truncated)
.line	389	return        r1     2
.line	389	return        r0     1
.line	389	move          r0    r0
.line	389	move          r0    r0
.line	389	move          r0    r0
.line	389	return        r0     1

.function	main/f23

.source	null
.linedefined	396
.lastlinedefined	401
.numparams	1
.is_vararg	0
.maxstacksize	34

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"BuildSubSystem"
.constant	k1	"SubsystemMgr"
.constant	k2	"Get"
.constant	k3	110
.constant	k4	170
.constant	k5	111
.constant	k6	53
.constant	k7	87
.constant	k8	15
.constant	k9	152
.constant	k10	165
.constant	k11	12
.constant	k12	54
.constant	k13	8
.constant	k14	36
.constant	k15	32
.constant	k16	145
.constant	k17	251
.constant	k18	159
.constant	k19	157
.constant	k20	19
.constant	k21	183
.constant	k22	5
.constant	k23	235
.constant	k24	146
.constant	k25	2
.constant	k26	48
.constant	k27	37
.constant	k28	63
.constant	k29	57

.line	396	gettable      r1    r0    k0 ; k0 = "BuildSubSystem"
.line	396	test          r1     1
.line	396	jmp            0   l40
.line	396	gettabup      r1    u0    k1 ; k1 = "SubsystemMgr"
.line	396	self          r1    r1    k2 ; k2 = "Get"
.line	396	getupval      r3    u1
.line	396	loadk         r4    k3 ; k3 = 110
.line	396	loadk         r5    k4 ; k4 = 170
.line	396	loadk         r6    k5 ; k5 = 111
.line	396	loadk         r7    k6 ; k6 = 53
.line	396	loadk         r8    k7 ; k7 = 87
.line	396	loadk         r9    k8 ; k8 = 15
.line	396	loadk        r10    k9 ; k9 = 152
.line	396	loadk        r11   k10 ; k10 = 165
.line	396	loadk        r12   k11 ; k11 = 12
.line	396	loadk        r13   k12 ; k12 = 54
.line	396	loadk        r14   k13 ; k13 = 8
.line	396	loadk        r15   k14 ; k14 = 36
.line	396	loadk        r16    k8 ; k8 = 15
.line	396	loadk        r17   k15 ; k15 = 32
.line	396	loadk        r18   k16 ; k16 = 145
.line	396	loadk        r19   k17 ; k17 = 251
.line	396	loadk        r20   k18 ; k18 = 159
.line	396	loadk        r21   k19 ; k19 = 157
.line	396	loadk        r22   k20 ; k20 = 19
.line	396	loadk        r23   k13 ; k13 = 8
.line	396	loadk        r24   k21 ; k21 = 183
.line	396	loadk        r25   k22 ; k22 = 5
.line	396	loadk        r26   k23 ; k23 = 235
.line	396	loadk        r27   k24 ; k24 = 146
.line	396	loadk        r28   k25 ; k25 = 2
.line	396	loadk        r29   k26 ; k26 = 48
.line	396	loadk        r30    k8 ; k8 = 15
.line	396	loadk        r31   k27 ; k27 = 37
.line	396	loadk        r32   k28 ; k28 = 63
.line	396	loadk        r33   k29 ; k29 = 57
.line	396	call          r3    31     2
.line	396	call          r1     3     2
.line	396	settable      r0    k0    r1 ; k0 = "BuildSubSystem"
.label	l40
.line	396	gettable      r1    r0    k0 ; k0 = "BuildSubSystem"
.line	396	return        r1     2
.line	396	return        r0     1
.line	396	move          r0    r0
.line	396	move          r0    r0
.line	396	return        r0     1

.function	main/f24

.source	null
.linedefined	403
.lastlinedefined	422
.numparams	2
.is_vararg	0
.maxstacksize	9

.constant	k0	nil
.constant	k1	"bIsPrefab"
.constant	k2	true
.constant	k3	"GridIndex"
.constant	k4	"UniqueAssetId"
.constant	k5	"EmpowerAssetID"
.constant	k6	"AssetID"
.constant	k7	"MaterialId"
.constant	k8	"RepeatedComputeCostMap"
.constant	k9	0
.constant	k10	1

.line	403	eq             1    r1    k0 ; k0 = nil
.line	403	jmp            0    l6
.line	403	gettable      r2    r1    k1 ; k1 = "bIsPrefab"
.line	403	eq             0    r2    k2 ; k2 = true
.line	403	jmp            0    l7
.label	l6
.line	403	return        r0     1
.label	l7
.line	403	gettable      r2    r1    k3 ; k3 = "GridIndex"
.line	403	gettable      r3    r1    k4 ; k4 = "UniqueAssetId"
.line	403	eq             0    r3    k0 ; k0 = nil
.line	403	jmp            0   l20
.line	403	gettable      r4    r1    k5 ; k5 = "EmpowerAssetID"
.line	403	test          r4     1
.line	403	jmp            0   l15
.line	403	gettable      r4    r1    k6 ; k6 = "AssetID"
.label	l15
.line	403	self          r5    r0    k4 ; k4 = "UniqueAssetId"
.line	403	move          r7    r4
.line	403	gettable      r8    r1    k7 ; k7 = "MaterialId"
.line	403	call          r5     4     2
.line	403	move          r3    r5
.label	l20
.line	403	gettable      r4    r0    k8 ; k8 = "RepeatedComputeCostM" (truncated)
.line	403	gettable      r4    r4    r2
.line	403	eq             0    r4    k0 ; k0 = nil
.line	403	jmp            0   l28
.line	403	newtable      r5     0     0
.line	403	move          r4    r5
.line	403	gettable      r5    r0    k8 ; k8 = "RepeatedComputeCostM" (truncated)
.line	403	settable      r5    r2    r4
.label	l28
.line	403	gettable      r5    r4    r3
.line	403	eq             0    r5    k0 ; k0 = nil
.line	403	jmp            0   l32
.line	403	settable      r4    r3    k9 ; k9 = 0
.label	l32
.line	403	gettable      r5    r4    r3
.line	403	add           r5    r5   k10 ; k10 = 1
.line	403	settable      r4    r3    r5
.line	403	return        r0     1
.line	403	move          r0    r0
.line	403	move          r0    r0
.line	403	return        r0     1

.function	main/f25

.source	null
.linedefined	424
.lastlinedefined	442
.numparams	2
.is_vararg	0
.maxstacksize	9

.constant	k0	nil
.constant	k1	"bIsPrefab"
.constant	k2	true
.constant	k3	"GridIndex"
.constant	k4	"UniqueAssetId"
.constant	k5	"EmpowerAssetID"
.constant	k6	"AssetID"
.constant	k7	"MaterialId"
.constant	k8	"RepeatedComputeCostMap"
.constant	k9	1
.constant	k10	0

.line	424	eq             1    r1    k0 ; k0 = nil
.line	424	jmp            0    l6
.line	424	gettable      r2    r1    k1 ; k1 = "bIsPrefab"
.line	424	eq             0    r2    k2 ; k2 = true
.line	424	jmp            0    l7
.label	l6
.line	424	return        r0     1
.label	l7
.line	424	gettable      r2    r1    k3 ; k3 = "GridIndex"
.line	424	gettable      r3    r1    k4 ; k4 = "UniqueAssetId"
.line	424	eq             0    r3    k0 ; k0 = nil
.line	424	jmp            0   l20
.line	424	gettable      r4    r1    k5 ; k5 = "EmpowerAssetID"
.line	424	test          r4     1
.line	424	jmp            0   l15
.line	424	gettable      r4    r1    k6 ; k6 = "AssetID"
.label	l15
.line	424	self          r5    r0    k4 ; k4 = "UniqueAssetId"
.line	424	move          r7    r4
.line	424	gettable      r8    r1    k7 ; k7 = "MaterialId"
.line	424	call          r5     4     2
.line	424	move          r3    r5
.label	l20
.line	424	gettable      r4    r0    k8 ; k8 = "RepeatedComputeCostM" (truncated)
.line	424	gettable      r5    r4    r2
.line	424	eq             1    r5    k0 ; k0 = nil
.line	424	jmp            0   l28
.line	424	gettable      r5    r4    r2
.line	424	gettable      r5    r5    r3
.line	424	eq             0    r5    k0 ; k0 = nil
.line	424	jmp            0   l29
.label	l28
.line	424	return        r0     1
.label	l29
.line	424	gettable      r5    r4    r2
.line	424	gettable      r6    r4    r2
.line	424	gettable      r6    r6    r3
.line	424	sub           r6    r6    k9 ; k9 = 1
.line	424	settable      r5    r3    r6
.line	424	gettable      r5    r4    r2
.line	424	gettable      r5    r5    r3
.line	424	le             0    r5   k10 ; k10 = 0
.line	424	jmp            0   l40
.line	424	gettable      r5    r4    r2
.line	424	settable      r5    r3   k10 ; k10 = 0
.label	l40
.line	424	return        r0     1
.line	424	move          r0    r0
.line	424	move          r0    r0
.line	424	move          r0    r0
.line	424	return        r0     1

.function	main/f26

.source	null
.linedefined	444
.lastlinedefined	458
.numparams	3
.is_vararg	0
.maxstacksize	5

.constant	k0	"RepeatedComputeCostMap"
.constant	k1	nil
.constant	k2	0

.line	444	gettable      r3    r0    k0 ; k0 = "RepeatedComputeCostM" (truncated)
.line	444	eq             0    r1    k1 ; k1 = nil
.line	444	jmp            0    l7
.line	444	newtable      r4     0     0
.line	444	move          r3    r4
.line	444	return        r0     1
.label	l7
.line	444	eq             0    r2    k1 ; k1 = nil
.line	444	jmp            0   l12
.line	444	newtable      r4     0     0
.line	444	settable      r3    r1    r4
.line	444	return        r0     1
.label	l12
.line	444	gettable      r4    r3    r1
.line	444	test          r4     1
.line	444	jmp            0   l17
.line	444	newtable      r4     0     0
.line	444	settable      r3    r1    r4
.label	l17
.line	444	gettable      r4    r3    r1
.line	444	settable      r4    r2    k2 ; k2 = 0
.line	444	return        r0     1
.line	444	move          r0    r0
.line	444	move          r0    r0
.line	444	move          r0    r0
.line	444	move          r0    r0
.line	444	return        r0     1

.function	main/f27

.source	null
.linedefined	460
.lastlinedefined	464
.numparams	3
.is_vararg	0
.maxstacksize	4

.constant	k0	"RepeatedComputeCostMap"
.constant	k1	nil
.constant	k2	0

.line	460	gettable      r3    r0    k0 ; k0 = "RepeatedComputeCostM" (truncated)
.line	460	gettable      r3    r3    r1
.line	460	test          r3     0
.line	460	jmp            0   l17
.line	460	gettable      r3    r0    k0 ; k0 = "RepeatedComputeCostM" (truncated)
.line	460	gettable      r3    r3    r1
.line	460	gettable      r3    r3    r2
.line	460	eq             1    r3    k1 ; k1 = nil
.line	460	jmp            0   l17
.line	460	gettable      r3    r0    k0 ; k0 = "RepeatedComputeCostM" (truncated)
.line	460	gettable      r3    r3    r1
.line	460	gettable      r3    r3    r2
.line	460	lt             0    k2    r3 ; k2 = 0
.line	460	jmp            0   l17
.line	460	loadbool      r3     1     0
.line	460	return        r3     2
.label	l17
.line	460	return        r0     1
.line	460	move          r0    r0
.line	460	move          r0    r0
.line	460	move          r0    r0
.line	460	return        r0     1

.function	main/f28

.source	null
.linedefined	466
.lastlinedefined	478
.numparams	3
.is_vararg	0
.maxstacksize	12

.upvalue	"_ENV"	11	true
.upvalue	"U1"	4	true

.constant	k0	0
.constant	k1	"bColorISMEnable"
.constant	k2	"GetMaterialTextureId"
.constant	k3	"HSBDefine"
.constant	k4	"MAX_RGB"
.constant	k5	"GetMaterialIdFromCustomInfo"
.constant	k6	100000000

.line	466	testset       r3    r2     1
.line	466	jmp            0    l4
.line	466	loadk         r3    k0 ; k0 = 0
.label	l4
.line	466	gettabup      r4    u0    k1 ; k1 = "bColorISMEnable"
.line	466	test          r4     1
.line	466	jmp            0    l7
.label	l7
.line	466	getupval      r4    u1
.line	466	self          r4    r4    k2 ; k2 = "GetMaterialTextureId"
.line	466	move          r6    r3
.line	466	call          r4     3     2
.line	466	eq             1    r4    k0 ; k0 = 0
.line	466	jmp            0   l23
.line	466	gettabup      r5    u0    k3 ; k3 = "HSBDefine"
.line	466	gettable      r5    r5    k4 ; k4 = "MAX_RGB"
.line	466	getupval      r6    u1
.line	466	self          r6    r6    k5 ; k5 = "GetMaterialIdFromCus" (truncated)
.line	466	move          r8    r4
.line	466	move          r9    r5
.line	466	move         r10    r5
.line	466	move         r11    r5
.line	466	call          r6     6     2
.line	466	move          r3    r6
.label	l23
.line	466	mul           r4    k6    r3 ; k6 = 100000000
.line	466	add           r4    r1    r4
.line	466	return        r4     2
.line	466	return        r0     1
.line	466	move          r0    r0
.line	466	return        r0     1

.function	main/f29

.source	null
.linedefined	480
.lastlinedefined	540
.numparams	4
.is_vararg	0
.maxstacksize	26

.upvalue	"_ENV"	19	true
.upvalue	"U1"	0	false
.upvalue	"U2"	6	true

.constant	k0	0
.constant	k1	"GetInstanceManager"
.constant	k2	"GetInstance"
.constant	k3	"ObjectGroup"
.constant	k4	"Children"
.constant	k5	"overrides"
.constant	k6	"AssetId"
.constant	k7	"GetAssetManager"
.constant	k8	"GetDefaultUIGroupAssetId"
.constant	k9	true
.constant	k10	1
.constant	k11	"GetInstanceCostInfo"
.constant	k12	"EmpowerAssetID"
.constant	k13	"AssetID"
.constant	k14	"GetDeltaCostByAssetId"
.constant	k15	"GridIndex"
.constant	k16	"ipairs"
.constant	k17	"bCanBatch"
.constant	k18	"MaterialId"
.constant	k19	"UniqueAssetId"
.constant	k20	nil
.constant	k21	"StreamingType"
.constant	k22	L"CreativeModeActorStreamingType_AlwaysLoad"
.constant	k23	2

.line	480	loadk         r4    k0 ; k0 = 0
.line	480	loadk         r5    k0 ; k0 = 0
.line	480	newtable      r6     2     0
.line	480	loadk         r7    k0 ; k0 = 0
.line	480	loadk         r8    k0 ; k0 = 0
.line	480	setlist       r6     2     1
.line	480	newtable      r7     0     0
.line	480	newtable      r8     0     0
.line	480	self          r9    r0    k1 ; k1 = "GetInstanceManager"
.line	480	call          r9     2     2
.line	480	self          r9    r9    k2 ; k2 = "GetInstance"
.line	480	move         r11    r2
.line	480	call          r9     3     2
.line	480	test          r9     0
.line	480	jmp            0  l151
.line	480	gettable     r10    r9    k3 ; k3 = "ObjectGroup"
.line	480	test         r10     0
.line	480	jmp            0  l151
.line	480	gettable     r10    r9    k3 ; k3 = "ObjectGroup"
.line	480	gettable     r10   r10    k4 ; k4 = "Children"
.line	480	test         r10     0
.line	480	jmp            0  l151
.line	480	gettable     r10    r9    k3 ; k3 = "ObjectGroup"
.line	480	gettable     r10   r10    k4 ; k4 = "Children"
.line	480	gettable     r10   r10    k5 ; k5 = "overrides"
.line	480	test         r10     0
.line	480	jmp            0  l151
.line	480	gettable     r10    r9    k6 ; k6 = "AssetId"
.line	480	self         r11    r0    k7 ; k7 = "GetAssetManager"
.line	480	call         r11     2     2
.line	480	self         r11   r11    k8 ; k8 = "GetDefaultUIGroupAss" (truncated)
.line	480	call         r11     2     2
.line	480	eq             1   r10   r11
.line	480	jmp            0  l151
.line	480	gettable     r10    r9    k3 ; k3 = "ObjectGroup"
.line	480	gettable     r10   r10    k4 ; k4 = "Children"
.line	480	gettable      r7   r10    k5 ; k5 = "overrides"
.line	480	eq             0    r3    k9 ; k9 = true
.line	480	jmp            0   l72
.line	480	gettable     r10    r7   k10 ; k10 = 1
.line	480	self         r11    r0   k11 ; k11 = "GetInstanceCostInfo"
.line	480	move         r13   r10
.line	480	call         r11     3     2
.line	480	test         r11     0
.line	480	jmp            0   l72
.line	480	gettable     r12   r11   k12 ; k12 = "EmpowerAssetID"
.line	480	test         r12     1
.line	480	jmp            0   l50
.line	480	gettable     r12   r11   k13 ; k13 = "AssetID"
.label	l50
.line	480	self         r13    r0   k14 ; k14 = "GetDeltaCostByAssetI" (truncated)
.line	480	gettable     r15   r11   k15 ; k15 = "GridIndex"
.line	480	move         r16   r12
.line	480	move         r17   r10
.line	480	loadbool     r18     1     0
.line	480	call         r13     6     4
.line	480	loadbool     r16     1     0
.line	480	len          r17    r7
.line	480	mul           r4   r13   r17
.line	480	move          r5   r14
.line	480	gettable     r17   r11   k15 ; k15 = "GridIndex"
.line	480	eq             1   r17    r1
.line	480	jmp            0   l67
.line	480	getupval     r17    u0
.line	480	mul           r4    r4   r17
.line	480	getupval     r17    u0
.line	480	mul           r5    r5   r17
.label	l67
.line	480	move         r17    r4
.line	480	move         r18    r5
.line	480	move         r19    r7
.line	480	move         r20    r6
.line	480	return       r17     5
.label	l72
.line	480	gettabup     r10    u1   k16 ; k16 = "ipairs"
.line	480	move         r11    r7
.line	480	call         r10     2     4
.line	480	jmp            0  l149
.line	480	eq             1    r2   r14
.line	480	jmp            0  l149
.line	480	self         r15    r0   k11 ; k11 = "GetInstanceCostInfo"
.line	480	move         r17   r14
.line	480	call         r15     3     2
.line	480	test         r15     0
.line	480	jmp            0  l149
.line	480	gettable     r16   r15   k12 ; k12 = "EmpowerAssetID"
.line	480	test         r16     1
.line	480	jmp            0   l87
.line	480	gettable     r16   r15   k13 ; k13 = "AssetID"
.label	l87
.line	480	self         r17    r0   k14 ; k14 = "GetDeltaCostByAssetI" (truncated)
.line	480	gettable     r19   r15   k15 ; k15 = "GridIndex"
.line	480	move         r20   r16
.line	480	move         r21   r14
.line	480	loadbool     r22     1     0
.line	480	call         r17     6     4
.line	480	gettable     r20   r15   k17 ; k17 = "bCanBatch"
.line	480	test         r19     1
.line	480	jmp            0  l124
.line	480	test         r20     0
.line	480	jmp            0  l124
.line	480	test         r15     0
.line	480	jmp            0  l103
.line	480	gettable     r21   r15   k18 ; k18 = "MaterialId"
.line	480	test         r21     1
.line	480	jmp            0  l104
.label	l103
.line	480	loadk        r21    k0 ; k0 = 0
.label	l104
.line	480	self         r22    r0   k19 ; k19 = "UniqueAssetId"
.line	480	move         r24   r16
.line	480	move         r25   r21
.line	480	call         r22     4     2
.line	480	gettable     r23   r15   k15 ; k15 = "GridIndex"
.line	480	gettable     r23    r8   r23
.line	480	eq             0   r23   k20 ; k20 = nil
.line	480	jmp            0  l115
.line	480	gettable     r23   r15   k15 ; k15 = "GridIndex"
.line	480	newtable     r24     0     0
.line	480	settable      r8   r23   r24
.label	l115
.line	480	gettable     r23   r15   k15 ; k15 = "GridIndex"
.line	480	gettable     r23    r8   r23
.line	480	gettable     r23   r23   r22
.line	480	test         r23     0
.line	480	jmp            0  l121
.line	480	loadk        r18    k0 ; k0 = 0
.label	l121
.line	480	gettable     r23   r15   k15 ; k15 = "GridIndex"
.line	480	gettable     r23    r8   r23
.line	480	settable     r23   r22    k9 ; k9 = true
.label	l124
.line	480	loadnil      r21     0
.line	480	gettable     r22   r15   k15 ; k15 = "GridIndex"
.line	480	eq             1    r1   r22
.line	480	jmp            0  l132
.line	480	gettable     r22   r15   k21 ; k21 = "StreamingType"
.line	480	gettabup     r23    u2   k22 ; k22 = L"CreativeModeActorStr" (truncated)
.line	480	eq             0   r22   r23
.line	480	jmp            0  l134
.label	l132
.line	480	loadk        r21   k10 ; k10 = 1
.line	480	jmp            0  l135
.label	l134
.line	480	getupval     r21    u0
.label	l135
.line	480	mul          r22   r17   r21
.line	480	add           r4    r4   r22
.line	480	mul          r22   r18   r21
.line	480	add           r5    r5   r22
.line	480	gettable     r22   r15   k21 ; k21 = "StreamingType"
.line	480	gettabup     r23    u2   k22 ; k22 = L"CreativeModeActorStr" (truncated)
.line	480	eq             0   r22   r23
.line	480	jmp            0  l149
.line	480	gettable     r22    r6   k10 ; k10 = 1
.line	480	add          r22   r22   r17
.line	480	settable      r6   k10   r22 ; k10 = 1
.line	480	gettable     r22    r6   k23 ; k23 = 2
.line	480	add          r22   r22   r18
.line	480	settable      r6   k23   r22 ; k23 = 2
.label	l149
.line	480	move          r0    r0
.line	480	move          r0    r0
.label	l151
.line	480	move         r10    r4
.line	480	move         r11    r5
.line	480	move         r12    r7
.line	480	move         r13    r6
.line	480	return       r10     5
.line	480	return        r0     1
.line	480	move          r0    r0
.line	480	move          r0    r0
.line	480	return        r0     1

.function	main/f30

.source	null
.linedefined	542
.lastlinedefined	558
.numparams	3
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	17	true

.constant	k0	"DestructibleMeshParam"
.constant	k1	"TriCost"
.constant	k2	"AssetCost"
.constant	k3	2
.constant	k4	"DCCost"
.constant	k5	"EnableAutoRefresh"
.constant	k6	5
.constant	k7	"BrokenEffect"
.constant	k8	1

.line	542	test          r1     0
.line	542	jmp            0    l8
.line	542	test          r2     0
.line	542	jmp            0    l8
.line	542	gettable      r3    r2    k0 ; k0 = "DestructibleMeshPara" (truncated)
.line	542	test          r3     1
.line	542	jmp            0   l11
.label	l8
.line	542	getupval      r3    u0
.line	542	getupval      r4    u0
.line	542	return        r3     3
.label	l11
.line	542	gettable      r3    r2    k0 ; k0 = "DestructibleMeshPara" (truncated)
.line	542	gettable      r4    r1    k1 ; k1 = "TriCost"
.line	542	test          r4     1
.line	542	jmp            0   l16
.line	542	gettable      r4    r1    k2 ; k2 = "AssetCost"
.label	l16
.line	542	mul           r4    r4    k3 ; k3 = 2
.line	542	gettable      r5    r1    k4 ; k4 = "DCCost"
.line	542	test          r5     1
.line	542	jmp            0   l21
.line	542	gettable      r5    r1    k2 ; k2 = "AssetCost"
.label	l21
.line	542	mul           r5    r5    k3 ; k3 = 2
.line	542	gettable      r6    r3    k5 ; k5 = "EnableAutoRefresh"
.line	542	test          r6     0
.line	542	jmp            0   l27
.line	542	add           r4    r4    k6 ; k6 = 5
.line	542	add           r5    r5    k6 ; k6 = 5
.label	l27
.line	542	gettable      r6    r3    k7 ; k7 = "BrokenEffect"
.line	542	eq             1    r6    k3 ; k3 = 2
.line	542	jmp            0   l32
.line	542	add           r4    r4    k8 ; k8 = 1
.line	542	add           r5    r5    k8 ; k8 = 1
.label	l32
.line	542	move          r6    r4
.line	542	move          r7    r5
.line	542	return        r6     3
.line	542	return        r0     1
.line	542	move          r0    r0
.line	542	move          r0    r0
.line	542	move          r0    r0
.line	542	return        r0     1

.function	main/f31

.source	null
.linedefined	560
.lastlinedefined	619
.numparams	6
.is_vararg	0
.maxstacksize	54

.upvalue	"_ENV"	17	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"GetAssetManager"
.constant	k1	0
.constant	k2	"GetAsset"
.constant	k3	"IsGroupAsset"
.constant	k4	"IsPixelGroupAsset"
.constant	k5	"CalcGroupAssetCost"
.constant	k6	"GetInstanceCostInfo"
.constant	k7	"print"
.constant	k8	"bWriteLog"
.constant	k9	"table"
.constant	k10	"concat"
.constant	k11	106
.constant	k12	189
.constant	k13	126
.constant	k14	16
.constant	k15	70
.constant	k16	10
.constant	k17	154
.constant	k18	161
.constant	k19	2
.constant	k20	54
.constant	k21	31
.constant	k22	53
.constant	k23	8
.constant	k24	61
.constant	k25	185
.constant	k26	252
.constant	k27	174
.constant	k28	141
.constant	k29	14
.constant	k30	45
.constant	k31	183
.constant	k32	108
.constant	k33	215
.constant	k34	158
.constant	k35	34
.constant	k36	29
.constant	k37	63
.constant	k38	57
.constant	k39	49
.constant	k40	171
.constant	k41	240
.constant	k42	190
.constant	k43	140
.constant	k44	35
.constant	k45	26
.constant	k46	165
.constant	k47	41
.constant	k48	137
.constant	k49	94
.constant	k50	248
.constant	k51	100
.constant	k52	79
.constant	k53	135
.constant	k54	50
.constant	k55	13
.constant	k56	47
.constant	k57	33
.constant	k58	177
.constant	k59	235
.constant	k60	253
.constant	k61	213
.constant	k62	90
.constant	k63	"tostring"
.constant	k64	"EmpowerAssetID"
.constant	k65	"TriCost"
.constant	k66	"DCCost"
.constant	k67	"RepeatedCost"
.constant	k68	"StreamingType"
.constant	k69	"bCanBatch"
.constant	k70	nil
.constant	k71	"UniqueAssetId"
.constant	k72	"MaterialId"
.constant	k73	"CheckHasRepeatedCompute"

.line	560	self          r6    r0    k0 ; k0 = "GetAssetManager"
.line	560	call          r6     2     2
.line	560	test          r6     1
.line	560	jmp            0    l8
.line	560	loadk         r6    k1 ; k1 = 0
.line	560	loadk         r7    k1 ; k1 = 0
.line	560	return        r6     3
.label	l8
.line	560	getupval      r6    u0
.line	560	getupval      r7    u0
.line	560	gettabup      r8    u1    k0 ; k0 = "GetAssetManager"
.line	560	call          r8     1     2
.line	560	self          r8    r8    k2 ; k2 = "GetAsset"
.line	560	move         r10    r2
.line	560	loadbool     r11     1     0
.line	560	call          r8     4     2
.line	560	test          r8     0
.line	560	jmp            0   l58
.line	560	gettabup      r9    u1    k0 ; k0 = "GetAssetManager"
.line	560	call          r9     1     2
.line	560	self          r9    r9    k3 ; k3 = "IsGroupAsset"
.line	560	move         r11    r2
.line	560	loadbool     r12     1     0
.line	560	call          r9     4     2
.line	560	test          r9     0
.line	560	jmp            0   l58
.line	560	loadk         r9    k1 ; k1 = 0
.line	560	loadk        r10    k1 ; k1 = 0
.line	560	loadnil      r11     1
.line	560	loadbool     r13     0     0
.line	560	gettabup     r14    u1    k0 ; k0 = "GetAssetManager"
.line	560	call         r14     1     2
.line	560	self         r14   r14    k4 ; k4 = "IsPixelGroupAsset"
.line	560	move         r16    r2
.line	560	call         r14     3     2
.line	560	move         r13   r14
.line	560	test          r4     0
.line	560	jmp            0   l47
.line	560	self         r14    r0    k5 ; k5 = "CalcGroupAssetCost"
.line	560	move         r16    r1
.line	560	move         r17    r3
.line	560	move         r18   r13
.line	560	call         r14     5     5
.line	560	move         r12   r17
.line	560	move         r11   r16
.line	560	move         r10   r15
.line	560	move          r9   r14
.label	l47
.line	560	test          r9     1
.line	560	jmp            0   l50
.line	560	getupval      r9    u0
.label	l50
.line	560	test         r10     1
.line	560	jmp            0   l53
.line	560	getupval     r10    u0
.label	l53
.line	560	move         r14    r9
.line	560	move         r15   r10
.line	560	loadbool     r16     0     0
.line	560	move         r17   r12
.line	560	return       r14     5
.label	l58
.line	560	self          r9    r0    k6 ; k6 = "GetInstanceCostInfo"
.line	560	move         r11    r3
.line	560	call          r9     3     2
.line	560	test          r9     1
.line	560	jmp            0  l143
.line	560	gettabup     r10    u1    k7 ; k7 = "print"
.line	560	gettabup     r11    u1    k8 ; k8 = "bWriteLog"
.line	560	test         r11     0
.line	560	jmp            0  l139
.line	560	gettabup     r11    u1    k9 ; k9 = "table"
.line	560	gettable     r11   r11   k10 ; k10 = "concat"
.line	560	newtable     r12     1     0
.line	560	getupval     r13    u2
.line	560	loadk        r14   k11 ; k11 = 106
.line	560	loadk        r15   k12 ; k12 = 189
.line	560	loadk        r16   k13 ; k13 = 126
.line	560	loadk        r17   k14 ; k14 = 16
.line	560	loadk        r18   k15 ; k15 = 70
.line	560	loadk        r19   k16 ; k16 = 10
.line	560	loadk        r20   k17 ; k17 = 154
.line	560	loadk        r21   k18 ; k18 = 161
.line	560	loadk        r22   k19 ; k19 = 2
.line	560	loadk        r23   k20 ; k20 = 54
.line	560	loadk        r24   k21 ; k21 = 31
.line	560	loadk        r25   k22 ; k22 = 53
.line	560	loadk        r26   k23 ; k23 = 8
.line	560	loadk        r27   k24 ; k24 = 61
.line	560	loadk        r28   k25 ; k25 = 185
.line	560	loadk        r29   k26 ; k26 = 252
.line	560	loadk        r30   k27 ; k27 = 174
.line	560	loadk        r31   k28 ; k28 = 141
.line	560	loadk        r32   k29 ; k29 = 14
.line	560	loadk        r33   k30 ; k30 = 45
.line	560	loadk        r34   k31 ; k31 = 183
.line	560	loadk        r35   k32 ; k32 = 108
.line	560	loadk        r36   k33 ; k33 = 215
.line	560	loadk        r37   k34 ; k34 = 158
.line	560	loadk        r38   k35 ; k35 = 34
.line	560	loadk        r39   k24 ; k24 = 61
.line	560	loadk        r40   k36 ; k36 = 29
.line	560	loadk        r41   k37 ; k37 = 63
.line	560	loadk        r42   k38 ; k38 = 57
.line	560	loadk        r43   k39 ; k39 = 49
.line	560	loadk        r44   k40 ; k40 = 171
.line	560	loadk        r45   k41 ; k41 = 240
.line	560	loadk        r46   k42 ; k42 = 190
.line	560	loadk        r47   k43 ; k43 = 140
.line	560	loadk        r48   k44 ; k44 = 35
.line	560	loadk        r49   k45 ; k45 = 26
.line	560	loadk        r50   k46 ; k46 = 165
.line	560	loadk        r51   k47 ; k47 = 41
.line	560	loadk        r52   k27 ; k27 = 174
.line	560	loadk        r53   k48 ; k48 = 137
.line	560	call         r13    41     2
.line	560	getupval     r14    u2
.line	560	loadk        r15   k49 ; k49 = 94
.line	560	loadk        r16   k50 ; k50 = 248
.line	560	loadk        r17   k51 ; k51 = 100
.line	560	loadk        r18   k24 ; k24 = 61
.line	560	loadk        r19   k52 ; k52 = 79
.line	560	loadk        r20   k15 ; k15 = 70
.line	560	loadk        r21   k53 ; k53 = 135
.line	560	loadk        r22   k27 ; k27 = 174
.line	560	loadk        r23   k54 ; k54 = 50
.line	560	loadk        r24   k30 ; k30 = 45
.line	560	loadk        r25   k55 ; k55 = 13
.line	560	loadk        r26   k56 ; k56 = 47
.line	560	loadk        r27   k47 ; k47 = 41
.line	560	loadk        r28   k57 ; k57 = 33
.line	560	loadk        r29   k58 ; k58 = 177
.line	560	loadk        r30   k59 ; k59 = 235
.line	560	loadk        r31   k60 ; k60 = 253
.line	560	loadk        r32   k61 ; k61 = 213
.line	560	loadk        r33   k62 ; k62 = 90
.line	560	call         r14    20     0
.line	560	setlist      r12     0     1
.line	560	call         r11     2     2
.line	560	gettabup     r12    u1   k63 ; k63 = "tostring"
.line	560	move         r13    r3
.line	560	call         r12     2     2
.line	560	concat       r11   r11   r12
.label	l139
.line	560	call         r10     2     1
.line	560	move         r10    r6
.line	560	move         r11    r7
.line	560	return       r10     3
.label	l143
.line	560	gettable     r10    r9   k64 ; k64 = "EmpowerAssetID"
.line	560	test         r10     0
.line	560	jmp            0  l154
.line	560	gettable      r2    r9   k64 ; k64 = "EmpowerAssetID"
.line	560	gettabup     r10    u1    k0 ; k0 = "GetAssetManager"
.line	560	call         r10     1     2
.line	560	self         r10   r10    k2 ; k2 = "GetAsset"
.line	560	move         r12    r2
.line	560	loadbool     r13     1     0
.line	560	call         r10     4     2
.line	560	move          r8   r10
.label	l154
.line	560	gettable     r10    r9   k65 ; k65 = "TriCost"
.line	560	gettable     r11    r9   k66 ; k66 = "DCCost"
.line	560	move         r12   r10
.line	560	loadk        r13    k1 ; k1 = 0
.line	560	loadnil      r14     0
.line	560	loadbool     r15     0     0
.line	560	test          r8     0
.line	560	jmp            0  l171
.line	560	gettable     r16    r8   k67 ; k67 = "RepeatedCost"
.line	560	test         r16     0
.line	560	jmp            0  l168
.line	560	gettable     r12    r8   k67 ; k67 = "RepeatedCost"
.line	560	gettable     r13    r8   k67 ; k67 = "RepeatedCost"
.line	560	jmp            0  l170
.label	l168
.line	560	move         r12   r10
.line	560	loadk        r13    k1 ; k1 = 0
.label	l170
.line	560	gettable     r14    r8   k68 ; k68 = "StreamingType"
.label	l171
.line	560	gettable     r16    r9   k69 ; k69 = "bCanBatch"
.line	560	loadnil      r17     0
.line	560	eq             0    r5   k70 ; k70 = nil
.line	560	jmp            0  l180
.line	560	gettable     r18    r9   k71 ; k71 = "UniqueAssetId"
.line	560	test         r18     0
.line	560	jmp            0  l180
.line	560	gettable     r17    r9   k71 ; k71 = "UniqueAssetId"
.line	560	jmp            0  l190
.label	l180
.line	560	self         r18    r0   k71 ; k71 = "UniqueAssetId"
.line	560	move         r20    r2
.line	560	testset      r21    r5     1
.line	560	jmp            0  l188
.line	560	gettable     r21    r9   k72 ; k72 = "MaterialId"
.line	560	test         r21     1
.line	560	jmp            0  l188
.line	560	loadk        r21    k1 ; k1 = 0
.label	l188
.line	560	call         r18     4     2
.line	560	move         r17   r18
.label	l190
.line	560	loadbool     r18     0     0
.line	560	self         r19    r0   k73 ; k73 = "CheckHasRepeatedComp" (truncated)
.line	560	move         r21    r1
.line	560	move         r22   r17
.line	560	call         r19     4     2
.line	560	test         r19     0
.line	560	jmp            0  l207
.line	560	test         r16     0
.line	560	jmp            0  l207
.line	560	testset       r6   r12     1
.line	560	jmp            0  l202
.line	560	getupval      r6    u0
.label	l202
.line	560	testset       r7   r13     1
.line	560	jmp            0  l205
.line	560	getupval      r7    u0
.label	l205
.line	560	loadbool     r18     1     0
.line	560	jmp            0  l213
.label	l207
.line	560	testset       r6   r10     1
.line	560	jmp            0  l210
.line	560	getupval      r6    u0
.label	l210
.line	560	testset       r7   r11     1
.line	560	jmp            0  l213
.line	560	getupval      r7    u0
.label	l213
.line	560	move         r19    r6
.line	560	move         r20    r7
.line	560	move         r21   r18
.line	560	return       r19     4
.line	560	return        r0     1
.line	560	move          r0    r0
.line	560	move          r0    r0
.line	560	move          r0    r0
.line	560	return        r0     1

.function	main/f32

.source	null
.linedefined	621
.lastlinedefined	651
.numparams	4
.is_vararg	0
.maxstacksize	22

.upvalue	"_ENV"	0	false
.upvalue	"U1"	19	true

.constant	k0	0
.constant	k1	"GetInstanceManager"
.constant	k2	"GetInstance"
.constant	k3	"ObjectGroup"
.constant	k4	"Children"
.constant	k5	"overrides"
.constant	k6	"AssetId"
.constant	k7	"GetAssetManager"
.constant	k8	"GetDefaultUIGroupAssetId"
.constant	k9	1
.constant	k10	"GetInstanceCostInfo"
.constant	k11	"EmpowerAssetID"
.constant	k12	"AssetID"
.constant	k13	"GetDeltaCostByAssetId"
.constant	k14	"GridIndex"
.constant	k15	"pairs"

.line	621	loadk         r4    k0 ; k0 = 0
.line	621	loadk         r5    k0 ; k0 = 0
.line	621	loadk         r6    k0 ; k0 = 0
.line	621	loadk         r7    k0 ; k0 = 0
.line	621	loadk         r8    k0 ; k0 = 0
.line	621	loadk         r9    k0 ; k0 = 0
.line	621	loadnil      r10     0
.line	621	self         r11    r0    k1 ; k1 = "GetInstanceManager"
.line	621	call         r11     2     2
.line	621	self         r11   r11    k2 ; k2 = "GetInstance"
.line	621	move         r13    r2
.line	621	call         r11     3     2
.line	621	test         r11     0
.line	621	jmp            0   l59
.line	621	gettable     r12   r11    k3 ; k3 = "ObjectGroup"
.line	621	test         r12     0
.line	621	jmp            0   l59
.line	621	gettable     r12   r11    k3 ; k3 = "ObjectGroup"
.line	621	gettable     r12   r12    k4 ; k4 = "Children"
.line	621	test         r12     0
.line	621	jmp            0   l59
.line	621	gettable     r12   r11    k3 ; k3 = "ObjectGroup"
.line	621	gettable     r12   r12    k4 ; k4 = "Children"
.line	621	gettable     r12   r12    k5 ; k5 = "overrides"
.line	621	test         r12     0
.line	621	jmp            0   l59
.line	621	gettable     r12   r11    k6 ; k6 = "AssetId"
.line	621	self         r13    r0    k7 ; k7 = "GetAssetManager"
.line	621	call         r13     2     2
.line	621	self         r13   r13    k8 ; k8 = "GetDefaultUIGroupAss" (truncated)
.line	621	call         r13     2     2
.line	621	eq             1   r12   r13
.line	621	jmp            0   l59
.line	621	gettable     r12   r11    k3 ; k3 = "ObjectGroup"
.line	621	gettable     r12   r12    k4 ; k4 = "Children"
.line	621	gettable     r12   r12    k5 ; k5 = "overrides"
.line	621	loadk        r13    k0 ; k0 = 0
.line	621	len          r14   r12
.line	621	lt             0    k0   r14 ; k0 = 0
.line	621	jmp            0   l42
.line	621	gettable     r13   r12    k9 ; k9 = 1
.label	l42
.line	621	self         r14    r0   k10 ; k10 = "GetInstanceCostInfo"
.line	621	move         r16   r13
.line	621	call         r14     3     2
.line	621	test         r14     0
.line	621	jmp            0   l59
.line	621	gettable     r15   r14   k11 ; k11 = "EmpowerAssetID"
.line	621	test         r15     1
.line	621	jmp            0   l51
.line	621	gettable     r15   r14   k12 ; k12 = "AssetID"
.label	l51
.line	621	self         r16    r0   k13 ; k13 = "GetDeltaCostByAssetI" (truncated)
.line	621	gettable     r18   r14   k14 ; k14 = "GridIndex"
.line	621	move         r19   r15
.line	621	move         r20   r13
.line	621	loadbool     r21     1     0
.line	621	call         r16     6     3
.line	621	move          r7   r17
.line	621	move          r6   r16
.label	l59
.line	621	gettabup     r12    u0   k15 ; k15 = "pairs"
.line	621	move         r13    r3
.line	621	call         r12     2     4
.line	621	jmp            0   l67
.line	621	lt             0    r9   r16
.line	621	jmp            0   l66
.line	621	move          r9   r16
.label	l66
.line	621	add           r8    r8   r16
.label	l67
.line	621	move          r0    r0
.line	621	move          r0    r0
.line	621	move          r5    r7
.line	621	sub          r12    r8    r9
.line	621	getupval     r13    u1
.line	621	mul          r12   r12   r13
.line	621	add          r12   r12    r9
.line	621	mul           r4    r6   r12
.line	621	move         r12    r4
.line	621	move         r13    r5
.line	621	return       r12     3
.line	621	return        r0     1
.line	621	move          r0    r0
.line	621	move          r0    r0
.line	621	move          r0    r0
.line	621	move          r0    r0
.line	621	return        r0     1

.function	main/f33

.source	null
.linedefined	653
.lastlinedefined	671
.numparams	1
.is_vararg	0
.maxstacksize	17

.upvalue	"_ENV"	35	true

.constant	k0	"GetCurBuildingLocationAndAssetID"
.constant	k1	0
.constant	k2	nil
.constant	k3	"GetGridAssetCost"
.constant	k4	"max"
.constant	k5	"GetCellIndex"
.constant	k6	"GetDeltaCostByAssetId"

.line	653	self          r1    r0    k0 ; k0 = "GetCurBuildingLocati" (truncated)
.line	653	call          r1     2     4
.line	653	loadk         r4    k1 ; k1 = 0
.line	653	loadk         r5    k1 ; k1 = 0
.line	653	loadk         r6    k1 ; k1 = 0
.line	653	loadk         r7    k1 ; k1 = 0
.line	653	loadk         r8    k1 ; k1 = 0
.line	653	loadk         r9    k1 ; k1 = 0
.line	653	eq             1    r1    k2 ; k2 = nil
.line	653	jmp            0   l21
.line	653	self         r10    r0    k3 ; k3 = "GetGridAssetCost"
.line	653	move         r12    r1
.line	653	call         r10     3     3
.line	653	move          r7   r11
.line	653	move          r6   r10
.line	653	gettabup     r10    u0    k4 ; k4 = "max"
.line	653	move         r11    r6
.line	653	move         r12    r7
.line	653	call         r10     3     2
.line	653	move          r4   r10
.label	l21
.line	653	eq             1    r2    k2 ; k2 = nil
.line	653	jmp            0   l41
.line	653	self         r10    r0    k5 ; k5 = "GetCellIndex"
.line	653	move         r12    r1
.line	653	call         r10     3     2
.line	653	self         r11    r0    k6 ; k6 = "GetDeltaCostByAssetI" (truncated)
.line	653	move         r13   r10
.line	653	move         r14    r2
.line	653	move         r15    r3
.line	653	loadbool     r16     1     0
.line	653	call         r11     6     3
.line	653	move          r9   r12
.line	653	move          r8   r11
.line	653	add          r11    r6    r8
.line	653	add          r12    r7    r9
.line	653	gettabup     r13    u0    k4 ; k4 = "max"
.line	653	move         r14   r11
.line	653	move         r15   r12
.line	653	call         r13     3     2
.line	653	sub           r5   r13    r4
.label	l41
.line	653	move         r10    r4
.line	653	move         r11    r5
.line	653	move         r12    r6
.line	653	move         r13    r8
.line	653	move         r14    r7
.line	653	move         r15    r9
.line	653	return       r10     7
.line	653	return        r0     1
.line	653	move          r0    r0
.line	653	move          r0    r0
.line	653	move          r0    r0
.line	653	return        r0     1

.function	main/f34

.source	null
.linedefined	673
.lastlinedefined	678
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	15	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	110
.constant	k5	170
.constant	k6	111
.constant	k7	53
.constant	k8	87
.constant	k9	15
.constant	k10	152
.constant	k11	165
.constant	k12	12
.constant	k13	54
.constant	k14	8
.constant	k15	36
.constant	k16	11
.constant	k17	55
.constant	k18	139
.constant	k19	234
.constant	k20	169
.constant	k21	171
.constant	k22	21
.constant	k23	23
.constant	k24	167
.constant	k25	5
.constant	k26	235
.constant	k27	146
.constant	k28	2
.constant	k29	48
.constant	k30	37
.constant	k31	63
.constant	k32	57
.constant	k33	210
.constant	k34	202
.constant	k35	163
.constant	k36	148
.constant	k37	3
.constant	k38	25
.constant	k39	50
.constant	k40	207
.constant	k41	147
.constant	k42	94
.constant	k43	189
.constant	k44	126
.constant	k45	76
.constant	k46	154
.constant	k47	"bIsShipping"

.line	673	gettabup      r1    u0    k0 ; k0 = "print"
.line	673	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	673	test          r2     0
.line	673	jmp            0   l61
.line	673	gettabup      r2    u0    k2 ; k2 = "table"
.line	673	gettable      r2    r2    k3 ; k3 = "concat"
.line	673	newtable      r3     1     0
.line	673	getupval      r4    u1
.line	673	loadk         r5    k4 ; k4 = 110
.line	673	loadk         r6    k5 ; k5 = 170
.line	673	loadk         r7    k6 ; k6 = 111
.line	673	loadk         r8    k7 ; k7 = 53
.line	673	loadk         r9    k8 ; k8 = 87
.line	673	loadk        r10    k9 ; k9 = 15
.line	673	loadk        r11   k10 ; k10 = 152
.line	673	loadk        r12   k11 ; k11 = 165
.line	673	loadk        r13   k12 ; k12 = 12
.line	673	loadk        r14   k13 ; k13 = 54
.line	673	loadk        r15   k14 ; k14 = 8
.line	673	loadk        r16   k15 ; k15 = 36
.line	673	loadk        r17   k16 ; k16 = 11
.line	673	loadk        r18   k17 ; k17 = 55
.line	673	loadk        r19   k18 ; k18 = 139
.line	673	loadk        r20   k19 ; k19 = 234
.line	673	loadk        r21   k20 ; k20 = 169
.line	673	loadk        r22   k21 ; k21 = 171
.line	673	loadk        r23   k22 ; k22 = 21
.line	673	loadk        r24   k23 ; k23 = 23
.line	673	loadk        r25   k24 ; k24 = 167
.line	673	loadk        r26   k25 ; k25 = 5
.line	673	loadk        r27   k26 ; k26 = 235
.line	673	loadk        r28   k27 ; k27 = 146
.line	673	loadk        r29   k28 ; k28 = 2
.line	673	loadk        r30   k29 ; k29 = 48
.line	673	loadk        r31    k9 ; k9 = 15
.line	673	loadk        r32   k30 ; k30 = 37
.line	673	loadk        r33   k31 ; k31 = 63
.line	673	loadk        r34   k32 ; k32 = 57
.line	673	loadk        r35   k33 ; k33 = 210
.line	673	loadk        r36   k34 ; k34 = 202
.line	673	loadk        r37   k35 ; k35 = 163
.line	673	loadk        r38   k36 ; k36 = 148
.line	673	loadk        r39   k37 ; k37 = 3
.line	673	loadk        r40   k38 ; k38 = 25
.line	673	loadk        r41    k5 ; k5 = 170
.line	673	loadk        r42   k39 ; k39 = 50
.line	673	loadk        r43   k40 ; k40 = 207
.line	673	loadk        r44   k41 ; k41 = 147
.line	673	call          r4    41     2
.line	673	getupval      r5    u1
.line	673	loadk         r6   k42 ; k42 = 94
.line	673	loadk         r7   k43 ; k43 = 189
.line	673	loadk         r8   k44 ; k44 = 126
.line	673	loadk         r9   k23 ; k23 = 23
.line	673	loadk        r10   k45 ; k45 = 76
.line	673	loadk        r11   k22 ; k22 = 21
.line	673	loadk        r12   k46 ; k46 = 154
.line	673	call          r5     8     0
.line	673	setlist       r3     0     1
.line	673	call          r2     2     2
.label	l61
.line	673	call          r1     2     1
.line	673	gettable      r1    r0   k47 ; k47 = "bIsShipping"
.line	673	test          r1     1
.line	673	jmp            0   l67
.line	673	loadbool      r1     1     0
.line	673	setupval      r1    u2
.label	l67
.line	673	return        r0     1
.line	673	move          r0    r0
.line	673	move          r0    r0
.line	673	return        r0     1

.function	main/f35

.source	null
.linedefined	680
.lastlinedefined	717
.numparams	1
.is_vararg	0
.maxstacksize	24

.upvalue	"_ENV"	15	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	16	true

.constant	k0	"bIsShipping"
.constant	k1	999999
.constant	k2	"CellCostMax"
.constant	k3	nil
.constant	k4	"CDataTable"
.constant	k5	"GetTable"
.constant	k6	120
.constant	k7	159
.constant	k8	73
.constant	k9	4
.constant	k10	70
.constant	k11	20
.constant	k12	136
.constant	k13	175
.constant	k14	51
.constant	k15	52
.constant	k16	13
.constant	k17	47
.constant	k18	41
.constant	k19	33
.constant	k20	187
.constant	k21	224
.constant	k22	174
.constant	k23	156
.constant	k24	57
.constant	k25	2
.constant	k26	180
.constant	k27	"GetGameParameterManager"
.constant	k28	"GetGameParameter"
.constant	k29	79
.constant	k30	145
.constant	k31	121
.constant	k32	17
.constant	k33	91
.constant	k34	18
.constant	k35	165
.constant	k36	44
.constant	k37	60
.constant	k38	46
.constant	k39	"Value"
.constant	k40	1
.constant	k41	77
.constant	k42	10
.constant	k43	135
.constant	k44	173
.constant	k45	40
.constant	k46	45
.constant	k47	9
.constant	k48	37
.constant	k49	7
.constant	k50	43
.constant	k51	234
.constant	k52	5
.constant	k53	"MaxCost"
.constant	k54	0
.constant	k55	"ipairs"
.constant	k56	3

.line	680	gettable      r1    r0    k0 ; k0 = "bIsShipping"
.line	680	test          r1     1
.line	680	jmp            0    l9
.line	680	getupval      r1    u0
.line	680	test          r1     0
.line	680	jmp            0    l9
.line	680	loadk         r1    k1 ; k1 = 999999
.line	680	return        r1     2
.label	l9
.line	680	gettable      r1    r0    k2 ; k2 = "CellCostMax"
.line	680	eq             0    r1    k3 ; k3 = nil
.line	680	jmp            0  l118
.line	680	gettabup      r1    u1    k4 ; k4 = "CDataTable"
.line	680	gettable      r1    r1    k5 ; k5 = "GetTable"
.line	680	getupval      r2    u2
.line	680	loadk         r3    k6 ; k6 = 120
.line	680	loadk         r4    k7 ; k7 = 159
.line	680	loadk         r5    k8 ; k8 = 73
.line	680	loadk         r6    k9 ; k9 = 4
.line	680	loadk         r7   k10 ; k10 = 70
.line	680	loadk         r8   k11 ; k11 = 20
.line	680	loadk         r9   k12 ; k12 = 136
.line	680	loadk        r10   k13 ; k13 = 175
.line	680	loadk        r11   k14 ; k14 = 51
.line	680	loadk        r12   k15 ; k15 = 52
.line	680	loadk        r13   k16 ; k16 = 13
.line	680	loadk        r14   k17 ; k17 = 47
.line	680	loadk        r15   k18 ; k18 = 41
.line	680	loadk        r16   k19 ; k19 = 33
.line	680	loadk        r17   k20 ; k20 = 187
.line	680	loadk        r18   k21 ; k21 = 224
.line	680	loadk        r19   k22 ; k22 = 174
.line	680	loadk        r20   k23 ; k23 = 156
.line	680	loadk        r21   k24 ; k24 = 57
.line	680	loadk        r22   k25 ; k25 = 2
.line	680	loadk        r23   k26 ; k26 = 180
.line	680	call          r2    22     2
.line	680	call          r1     2     2
.line	680	test          r1     0
.line	680	jmp            0  l116
.line	680	loadbool      r2     0     0
.line	680	loadbool      r3     0     0
.line	680	gettabup      r4    u1   k27 ; k27 = "GetGameParameterMana" (truncated)
.line	680	call          r4     1     2
.line	680	test          r4     0
.line	680	jmp            0   l86
.line	680	self          r5    r4   k28 ; k28 = "GetGameParameter"
.line	680	getupval      r7    u2
.line	680	loadk         r8   k29 ; k29 = 79
.line	680	loadk         r9   k30 ; k30 = 145
.line	680	loadk        r10   k31 ; k31 = 121
.line	680	loadk        r11   k32 ; k32 = 17
.line	680	loadk        r12   k33 ; k33 = 91
.line	680	loadk        r13   k34 ; k34 = 18
.line	680	loadk        r14   k23 ; k23 = 156
.line	680	loadk        r15   k35 ; k35 = 165
.line	680	loadk        r16   k36 ; k36 = 44
.line	680	loadk        r17   k37 ; k37 = 60
.line	680	loadk        r18   k19 ; k19 = 33
.line	680	loadk        r19   k38 ; k38 = 46
.line	680	loadk        r20   k38 ; k38 = 46
.line	680	loadk        r21   k19 ; k19 = 33
.line	680	call          r7    15     2
.line	680	call          r5     3     2
.line	680	gettable      r2    r5   k39 ; k39 = "Value"
.line	680	self          r5    r4   k28 ; k28 = "GetGameParameter"
.line	680	getupval      r7    u2
.line	680	loadk         r8   k29 ; k29 = 79
.line	680	loadk         r9   k30 ; k30 = 145
.line	680	loadk        r10   k31 ; k31 = 121
.line	680	loadk        r11   k40 ; k40 = 1
.line	680	loadk        r12   k41 ; k41 = 77
.line	680	loadk        r13   k42 ; k42 = 10
.line	680	loadk        r14   k43 ; k43 = 135
.line	680	loadk        r15   k44 ; k44 = 173
.line	680	loadk        r16   k45 ; k45 = 40
.line	680	loadk        r17   k46 ; k46 = 45
.line	680	loadk        r18   k47 ; k47 = 9
.line	680	loadk        r19   k48 ; k48 = 37
.line	680	loadk        r20   k49 ; k49 = 7
.line	680	loadk        r21   k50 ; k50 = 43
.line	680	loadk        r22   k23 ; k23 = 156
.line	680	loadk        r23   k51 ; k51 = 234
.line	680	call          r7    17     2
.line	680	call          r5     3     2
.line	680	gettable      r3    r5   k39 ; k39 = "Value"
.label	l86
.line	680	test          r3     0
.line	680	jmp            0   l92
.line	680	gettable      r5    r1   k52 ; k52 = 5
.line	680	gettable      r5    r5   k53 ; k53 = "MaxCost"
.line	680	settable      r0    k2    r5 ; k2 = "CellCostMax"
.line	680	jmp            0  l118
.label	l92
.line	680	test          r2     0
.line	680	jmp            0  l101
.line	680	gettable      r5    r1    k9 ; k9 = 4
.line	680	test          r5     0
.line	680	jmp            0  l118
.line	680	gettable      r5    r1    k9 ; k9 = 4
.line	680	gettable      r5    r5   k53 ; k53 = "MaxCost"
.line	680	settable      r0    k2    r5 ; k2 = "CellCostMax"
.line	680	jmp            0  l118
.label	l101
.line	680	loadk         r5   k54 ; k54 = 0
.line	680	gettabup      r6    u1   k55 ; k55 = "ipairs"
.line	680	move          r7    r1
.line	680	call          r6     2     4
.line	680	jmp            0  l112
.line	680	lt             1   k56    r9 ; k56 = 3
.line	680	jmp            0  l114
.line	680	gettable     r11   r10   k53 ; k53 = "MaxCost"
.line	680	lt             0    r5   r11
.line	680	jmp            0  l112
.line	680	gettable      r5   r10   k53 ; k53 = "MaxCost"
.label	l112
.line	680	move          r0    r0
.line	680	move          r0    r0
.label	l114
.line	680	settable      r0    k2    r5 ; k2 = "CellCostMax"
.line	680	jmp            0  l118
.label	l116
.line	680	getupval      r2    u3
.line	680	settable      r0    k2    r2 ; k2 = "CellCostMax"
.label	l118
.line	680	gettable      r1    r0    k2 ; k2 = "CellCostMax"
.line	680	return        r1     2
.line	680	return        r0     1
.line	680	move          r0    r0
.line	680	move          r0    r0
.line	680	move          r0    r0
.line	680	return        r0     1

.function	main/f36

.source	null
.linedefined	719
.lastlinedefined	749
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	6	true

.constant	k0	"GetInstanceManager"
.constant	k1	nil
.constant	k2	"print"
.constant	k3	"bWriteLog"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	110
.constant	k7	170
.constant	k8	111
.constant	k9	53
.constant	k10	87
.constant	k11	15
.constant	k12	152
.constant	k13	165
.constant	k14	12
.constant	k15	54
.constant	k16	8
.constant	k17	36
.constant	k18	11
.constant	k19	55
.constant	k20	139
.constant	k21	234
.constant	k22	169
.constant	k23	171
.constant	k24	21
.constant	k25	23
.constant	k26	167
.constant	k27	5
.constant	k28	235
.constant	k29	146
.constant	k30	2
.constant	k31	48
.constant	k32	37
.constant	k33	63
.constant	k34	57
.constant	k35	210
.constant	k36	214
.constant	k37	163
.constant	k38	145
.constant	k39	30
.constant	k40	61
.constant	k41	173
.constant	k42	250
.constant	k43	129
.constant	k44	67
.constant	k45	187
.constant	k46	76
.constant	k47	154
.constant	k48	224
.constant	k49	6
.constant	k50	60
.constant	k51	24
.constant	k52	140
.constant	k53	238
.constant	k54	179
.constant	k55	31
.constant	k56	41
.constant	k57	178
.constant	k58	56
.constant	k59	255
.constant	k60	151
.constant	k61	52
.constant	k62	59
.constant	k63	92
.constant	k64	116
.constant	k65	134
.constant	k66	246
.constant	k67	161
.constant	k68	217
.constant	k69	75
.constant	k70	"GetInstanceTreeData"
.constant	k71	"pairs"
.constant	k72	"AddOrUpdateInstanceCostInfo"
.constant	k73	"StreamingType"
.constant	k74	L"CreativeModeActorStreamingType_AlwaysLoad"
.constant	k75	"AlwaysLoadInstances"
.constant	k76	true
.constant	k77	"GetInstanceAssetCost"
.constant	k78	"AlwaysLoadInstancesCost"
.constant	k79	"GridIndex"
.constant	k80	0
.constant	k81	"InstanceGrid"
.constant	k82	"triCost"
.constant	k83	"dcCost"
.constant	k84	"InstanceGridCost"
.constant	k85	"RecordRepeatedCompute"
.constant	k86	"AssetCountLimitInstanceChange"
.constant	k87	"AssetId"
.constant	k88	155
.constant	k89	120
.constant	k90	49
.constant	k91	66
.constant	k92	18
.constant	k93	135
.constant	k94	182
.constant	k95	20
.constant	k96	3
.constant	k97	47
.constant	k98	252
.constant	k99	184
.constant	k100	156
.constant	k101	160
.constant	k102	34
.constant	k103	205
.constant	k104	133
.constant	k105	51
.constant	k106	26
.constant	k107	46
.constant	k108	247
.constant	k109	177
.constant	k110	4
.constant	k111	29
.constant	k112	183
.constant	k113	147
.constant	k114	89
.constant	k115	185
.constant	k116	100
.constant	k117	70
.constant	k118	121
.constant	k119	40
.constant	k120	33

.line	719	gettabup      r1    u0    k0 ; k0 = "GetInstanceManager"
.line	719	call          r1     1     2
.line	719	eq             0    r1    k1 ; k1 = nil
.line	719	jmp            0   l95
.line	719	gettabup      r2    u0    k2 ; k2 = "print"
.line	719	gettabup      r3    u0    k3 ; k3 = "bWriteLog"
.line	719	test          r3     0
.line	719	jmp            0   l93
.line	719	gettabup      r3    u0    k4 ; k4 = "table"
.line	719	gettable      r3    r3    k5 ; k5 = "concat"
.line	719	newtable      r4     1     0
.line	719	getupval      r5    u1
.line	719	loadk         r6    k6 ; k6 = 110
.line	719	loadk         r7    k7 ; k7 = 170
.line	719	loadk         r8    k8 ; k8 = 111
.line	719	loadk         r9    k9 ; k9 = 53
.line	719	loadk        r10   k10 ; k10 = 87
.line	719	loadk        r11   k11 ; k11 = 15
.line	719	loadk        r12   k12 ; k12 = 152
.line	719	loadk        r13   k13 ; k13 = 165
.line	719	loadk        r14   k14 ; k14 = 12
.line	719	loadk        r15   k15 ; k15 = 54
.line	719	loadk        r16   k16 ; k16 = 8
.line	719	loadk        r17   k17 ; k17 = 36
.line	719	loadk        r18   k18 ; k18 = 11
.line	719	loadk        r19   k19 ; k19 = 55
.line	719	loadk        r20   k20 ; k20 = 139
.line	719	loadk        r21   k21 ; k21 = 234
.line	719	loadk        r22   k22 ; k22 = 169
.line	719	loadk        r23   k23 ; k23 = 171
.line	719	loadk        r24   k24 ; k24 = 21
.line	719	loadk        r25   k25 ; k25 = 23
.line	719	loadk        r26   k26 ; k26 = 167
.line	719	loadk        r27   k27 ; k27 = 5
.line	719	loadk        r28   k28 ; k28 = 235
.line	719	loadk        r29   k29 ; k29 = 146
.line	719	loadk        r30   k30 ; k30 = 2
.line	719	loadk        r31   k31 ; k31 = 48
.line	719	loadk        r32   k11 ; k11 = 15
.line	719	loadk        r33   k32 ; k32 = 37
.line	719	loadk        r34   k33 ; k33 = 63
.line	719	loadk        r35   k34 ; k34 = 57
.line	719	loadk        r36   k35 ; k35 = 210
.line	719	loadk        r37   k36 ; k36 = 214
.line	719	loadk        r38   k37 ; k37 = 163
.line	719	loadk        r39   k38 ; k38 = 145
.line	719	loadk        r40   k39 ; k39 = 30
.line	719	loadk        r41   k40 ; k40 = 61
.line	719	loadk        r42   k41 ; k41 = 173
.line	719	loadk        r43    k9 ; k9 = 53
.line	719	loadk        r44   k42 ; k42 = 250
.line	719	loadk        r45   k43 ; k43 = 129
.line	719	call          r5    41     2
.line	719	getupval      r6    u1
.line	719	loadk         r7   k44 ; k44 = 67
.line	719	loadk         r8   k45 ; k45 = 187
.line	719	loadk         r9    k8 ; k8 = 111
.line	719	loadk        r10   k25 ; k25 = 23
.line	719	loadk        r11   k46 ; k46 = 76
.line	719	loadk        r12   k24 ; k24 = 21
.line	719	loadk        r13   k47 ; k47 = 154
.line	719	loadk        r14   k48 ; k48 = 224
.line	719	loadk        r15   k49 ; k49 = 6
.line	719	loadk        r16   k50 ; k50 = 60
.line	719	loadk        r17   k51 ; k51 = 24
.line	719	loadk        r18   k16 ; k16 = 8
.line	719	loadk        r19   k17 ; k17 = 36
.line	719	loadk        r20   k19 ; k19 = 55
.line	719	loadk        r21   k52 ; k52 = 140
.line	719	loadk        r22   k53 ; k53 = 238
.line	719	loadk        r23   k54 ; k54 = 179
.line	719	loadk        r24   k20 ; k20 = 139
.line	719	loadk        r25   k55 ; k55 = 31
.line	719	loadk        r26   k56 ; k56 = 41
.line	719	loadk        r27   k57 ; k57 = 178
.line	719	loadk        r28   k58 ; k58 = 56
.line	719	loadk        r29   k59 ; k59 = 255
.line	719	loadk        r30   k60 ; k60 = 151
.line	719	loadk        r31   k61 ; k61 = 52
.line	719	loadk        r32   k62 ; k62 = 59
.line	719	loadk        r33   k63 ; k63 = 92
.line	719	loadk        r34   k58 ; k58 = 56
.line	719	loadk        r35   k56 ; k56 = 41
.line	719	loadk        r36   k64 ; k64 = 116
.line	719	loadk        r37   k65 ; k65 = 134
.line	719	loadk        r38   k66 ; k66 = 246
.line	719	loadk        r39   k67 ; k67 = 161
.line	719	loadk        r40   k68 ; k68 = 217
.line	719	loadk        r41   k69 ; k69 = 75
.line	719	call          r6    36     0
.line	719	setlist       r4     0     1
.line	719	call          r3     2     2
.label	l93
.line	719	call          r2     2     1
.line	719	return        r0     1
.label	l95
.line	719	self          r2    r1   k70 ; k70 = "GetInstanceTreeData"
.line	719	call          r2     2     2
.line	719	gettabup      r3    u0   k71 ; k71 = "pairs"
.line	719	move          r4    r2
.line	719	call          r3     2     4
.line	719	jmp            0  l171
.line	719	test          r7     0
.line	719	jmp            0  l171
.line	719	self          r8    r0   k72 ; k72 = "AddOrUpdateInstanceC" (truncated)
.line	719	move         r10    r6
.line	719	move         r11    r7
.line	719	call          r8     4     2
.line	719	gettable      r9    r8   k73 ; k73 = "StreamingType"
.line	719	gettabup     r10    u2   k74 ; k74 = L"CreativeModeActorStr" (truncated)
.line	719	eq             0    r9   r10
.line	719	jmp            0  l120
.line	719	gettable      r9    r0   k75 ; k75 = "AlwaysLoadInstances"
.line	719	settable      r9    r6   k76 ; k76 = true
.line	719	self          r9    r0   k77 ; k77 = "GetInstanceAssetCost"
.line	719	move         r11    r6
.line	719	call          r9     3     3
.line	719	gettable     r11    r0   k78 ; k78 = "AlwaysLoadInstancesC" (truncated)
.line	719	add          r11   r11    r9
.line	719	settable      r0   k78   r11 ; k78 = "AlwaysLoadInstancesC" (truncated)
.line	719	jmp            0  l163
.label	l120
.line	719	gettable      r9    r8   k79 ; k79 = "GridIndex"
.line	719	le             0   k80    r9 ; k80 = 0
.line	719	jmp            0  l163
.line	719	gettable      r9    r0   k81 ; k81 = "InstanceGrid"
.line	719	gettable     r10    r8   k79 ; k79 = "GridIndex"
.line	719	gettable      r9    r9   r10
.line	719	eq             0    r9    k1 ; k1 = nil
.line	719	jmp            0  l138
.line	719	gettable      r9    r0   k81 ; k81 = "InstanceGrid"
.line	719	gettable     r10    r8   k79 ; k79 = "GridIndex"
.line	719	newtable     r11     0     0
.line	719	settable      r9   r10   r11
.line	719	newtable      r9     0     2
.line	719	settable      r9   k82   k80 ; k80 = 0
.line	719	settable      r9   k83   k80 ; k80 = 0
.line	719	gettable     r10    r0   k84 ; k84 = "InstanceGridCost"
.line	719	gettable     r11    r8   k79 ; k79 = "GridIndex"
.line	719	settable     r10   r11    r9
.label	l138
.line	719	gettable      r9    r0   k81 ; k81 = "InstanceGrid"
.line	719	gettable     r10    r8   k79 ; k79 = "GridIndex"
.line	719	gettable      r9    r9   r10
.line	719	settable      r9    r6   k76 ; k76 = true
.line	719	self          r9    r0   k77 ; k77 = "GetInstanceAssetCost"
.line	719	move         r11    r6
.line	719	call          r9     3     3
.line	719	gettable     r11    r0   k84 ; k84 = "InstanceGridCost"
.line	719	gettable     r12    r8   k79 ; k79 = "GridIndex"
.line	719	gettable     r11   r11   r12
.line	719	gettable     r12    r0   k84 ; k84 = "InstanceGridCost"
.line	719	gettable     r13    r8   k79 ; k79 = "GridIndex"
.line	719	gettable     r12   r12   r13
.line	719	gettable     r12   r12   k82 ; k82 = "triCost"
.line	719	add          r12   r12    r9
.line	719	settable     r11   k82   r12 ; k82 = "triCost"
.line	719	gettable     r11    r0   k84 ; k84 = "InstanceGridCost"
.line	719	gettable     r12    r8   k79 ; k79 = "GridIndex"
.line	719	gettable     r11   r11   r12
.line	719	gettable     r12    r0   k84 ; k84 = "InstanceGridCost"
.line	719	gettable     r13    r8   k79 ; k79 = "GridIndex"
.line	719	gettable     r12   r12   r13
.line	719	gettable     r12   r12   k83 ; k83 = "dcCost"
.line	719	add          r12   r12   r10
.line	719	settable     r11   k83   r12 ; k83 = "dcCost"
.label	l163
.line	719	self          r9    r0   k85 ; k85 = "RecordRepeatedComput" (truncated)
.line	719	move         r11    r8
.line	719	call          r9     3     1
.line	719	self          r9    r0   k86 ; k86 = "AssetCountLimitInsta" (truncated)
.line	719	gettable     r11    r7   k87 ; k87 = "AssetId"
.line	719	loadbool     r12     1     0
.line	719	move         r13    r6
.line	719	call          r9     5     1
.label	l171
.line	719	move          r0    r0
.line	719	move          r0    r0
.line	719	gettabup      r3    u0    k2 ; k2 = "print"
.line	719	gettabup      r4    u0    k3 ; k3 = "bWriteLog"
.line	719	test          r4     0
.line	719	jmp            0  l240
.line	719	gettabup      r4    u0    k4 ; k4 = "table"
.line	719	gettable      r4    r4    k5 ; k5 = "concat"
.line	719	newtable      r5     1     0
.line	719	getupval      r6    u1
.line	719	loadk         r7    k6 ; k6 = 110
.line	719	loadk         r8   k88 ; k88 = 155
.line	719	loadk         r9   k89 ; k89 = 120
.line	719	loadk        r10   k90 ; k90 = 49
.line	719	loadk        r11   k91 ; k91 = 66
.line	719	loadk        r12   k92 ; k92 = 18
.line	719	loadk        r13   k93 ; k93 = 135
.line	719	loadk        r14   k94 ; k94 = 182
.line	719	loadk        r15   k17 ; k17 = 36
.line	719	loadk        r16   k95 ; k95 = 20
.line	719	loadk        r17   k96 ; k96 = 3
.line	719	loadk        r18   k32 ; k32 = 37
.line	719	loadk        r19   k97 ; k97 = 47
.line	719	loadk        r20   k27 ; k27 = 5
.line	719	loadk        r21   k20 ; k20 = 139
.line	719	loadk        r22   k98 ; k98 = 252
.line	719	loadk        r23   k99 ; k99 = 184
.line	719	loadk        r24  k100 ; k100 = 156
.line	719	loadk        r25   k34 ; k34 = 57
.line	719	loadk        r26   k18 ; k18 = 11
.line	719	loadk        r27  k101 ; k101 = 160
.line	719	loadk        r28  k102 ; k102 = 34
.line	719	loadk        r29  k103 ; k103 = 205
.line	719	loadk        r30  k104 ; k104 = 133
.line	719	loadk        r31  k105 ; k105 = 51
.line	719	loadk        r32  k106 ; k106 = 26
.line	719	loadk        r33   k27 ; k27 = 5
.line	719	loadk        r34  k102 ; k102 = 34
.line	719	loadk        r35  k107 ; k107 = 46
.line	719	loadk        r36   k90 ; k90 = 49
.line	719	loadk        r37  k104 ; k104 = 133
.line	719	loadk        r38   k13 ; k13 = 165
.line	719	loadk        r39  k108 ; k108 = 247
.line	719	loadk        r40  k109 ; k109 = 177
.line	719	loadk        r41  k110 ; k110 = 4
.line	719	loadk        r42  k111 ; k111 = 29
.line	719	loadk        r43  k112 ; k112 = 183
.line	719	loadk        r44   k11 ; k11 = 15
.line	719	loadk        r45   k48 ; k48 = 224
.line	719	loadk        r46  k113 ; k113 = 147
.line	719	call          r6    41     2
.line	719	getupval      r7    u1
.line	719	loadk         r8  k114 ; k114 = 89
.line	719	loadk         r9  k115 ; k115 = 185
.line	719	loadk        r10  k116 ; k116 = 100
.line	719	loadk        r11   k19 ; k19 = 55
.line	719	loadk        r12  k117 ; k117 = 70
.line	719	loadk        r13   k32 ; k32 = 37
.line	719	loadk        r14   k43 ; k43 = 129
.line	719	loadk        r15   k54 ; k54 = 179
.line	719	loadk        r16    k9 ; k9 = 53
.line	719	loadk        r17  k118 ; k118 = 121
.line	719	loadk        r18  k119 ; k119 = 40
.line	719	loadk        r19  k107 ; k107 = 46
.line	719	loadk        r20   k17 ; k17 = 36
.line	719	loadk        r21  k120 ; k120 = 33
.line	719	call          r7    15     0
.line	719	setlist       r5     0     1
.line	719	call          r4     2     2
.label	l240
.line	719	call          r3     2     1
.line	719	return        r0     1
.line	719	move          r0    r0
.line	719	return        r0     1

.function	main/f37

.source	null
.linedefined	751
.lastlinedefined	754
.numparams	2
.is_vararg	0
.maxstacksize	6

.constant	k0	"GetCellIndex"
.constant	k1	"GetGridAssetCostByIndex"

.line	751	self          r2    r0    k0 ; k0 = "GetCellIndex"
.line	751	move          r4    r1
.line	751	call          r2     3     2
.line	751	self          r3    r0    k1 ; k1 = "GetGridAssetCostByIn" (truncated)
.line	751	move          r5    r2
.line	751	tailcall      r3     3
.line	751	return        r3     0
.line	751	return        r0     1
.line	751	move          r0    r0
.line	751	move          r0    r0
.line	751	return        r0     1

.function	main/f38

.source	null
.linedefined	756
.lastlinedefined	759
.numparams	3
.is_vararg	0
.maxstacksize	7

.constant	k0	"MapCellCount"
.constant	k1	"GetGridAssetCostByIndex"

.line	756	gettable      r3    r0    k0 ; k0 = "MapCellCount"
.line	756	mul           r3    r3    r2
.line	756	add           r3    r3    r1
.line	756	self          r4    r0    k1 ; k1 = "GetGridAssetCostByIn" (truncated)
.line	756	move          r6    r3
.line	756	tailcall      r4     3
.line	756	return        r4     0
.line	756	return        r0     1
.line	756	move          r0    r0
.line	756	return        r0     1

.function	main/f39

.source	null
.linedefined	761
.lastlinedefined	772
.numparams	2
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	35	true

.constant	k0	"InstanceGridCombineCost"
.constant	k1	"CustomUICost"
.constant	k2	0
.constant	k3	"floor"
.constant	k4	"AlwaysLoadInstancesCost"
.constant	k5	"triCost"
.constant	k6	"dcCost"

.line	761	gettable      r2    r0    k0 ; k0 = "InstanceGridCombineC" (truncated)
.line	761	test          r2     0
.line	761	jmp            0   l39
.line	761	gettable      r2    r0    k0 ; k0 = "InstanceGridCombineC" (truncated)
.line	761	gettable      r2    r2    r1
.line	761	test          r2     0
.line	761	jmp            0   l39
.line	761	gettable      r3    r0    k1 ; k1 = "CustomUICost"
.line	761	test          r3     1
.line	761	jmp            0   l12
.line	761	loadk         r3    k2 ; k2 = 0
.label	l12
.line	761	gettabup      r4    u0    k3 ; k3 = "floor"
.line	761	gettable      r5    r0    k4 ; k4 = "AlwaysLoadInstancesC" (truncated)
.line	761	test          r5     1
.line	761	jmp            0   l17
.line	761	loadk         r5    k2 ; k2 = 0
.label	l17
.line	761	add           r5    r5    r3
.line	761	gettable      r6    r2    k5 ; k5 = "triCost"
.line	761	test          r6     1
.line	761	jmp            0   l22
.line	761	loadk         r6    k2 ; k2 = 0
.label	l22
.line	761	add           r5    r5    r6
.line	761	call          r4     2     2
.line	761	gettabup      r5    u0    k3 ; k3 = "floor"
.line	761	gettable      r6    r0    k4 ; k4 = "AlwaysLoadInstancesC" (truncated)
.line	761	test          r6     1
.line	761	jmp            0   l29
.line	761	loadk         r6    k2 ; k2 = 0
.label	l29
.line	761	add           r6    r6    r3
.line	761	gettable      r7    r2    k6 ; k6 = "dcCost"
.line	761	test          r7     1
.line	761	jmp            0   l34
.line	761	loadk         r7    k2 ; k2 = 0
.label	l34
.line	761	add           r6    r6    r7
.line	761	call          r5     2     2
.line	761	move          r6    r4
.line	761	move          r7    r5
.line	761	return        r6     3
.label	l39
.line	761	loadk         r2    k2 ; k2 = 0
.line	761	loadk         r3    k2 ; k2 = 0
.line	761	return        r2     3
.line	761	return        r0     1
.line	761	move          r0    r0
.line	761	return        r0     1

.function	main/f40

.source	null
.linedefined	774
.lastlinedefined	782
.numparams	1
.is_vararg	0
.maxstacksize	8

.constant	k0	"MapCellCount"
.constant	k1	0
.constant	k2	1
.constant	k3	"DelayCalGridAssetCost"
.constant	k4	"ModifyAllGridColor"
.constant	k5	"DelayUpdateGridColors"

.line	774	gettable      r1    r0    k0 ; k0 = "MapCellCount"
.line	774	test          r1     0
.line	774	jmp            0   l15
.line	774	loadk         r1    k1 ; k1 = 0
.line	774	gettable      r2    r0    k0 ; k0 = "MapCellCount"
.line	774	gettable      r3    r0    k0 ; k0 = "MapCellCount"
.line	774	mul           r2    r2    r3
.line	774	sub           r2    r2    k2 ; k2 = 1
.line	774	loadk         r3    k2 ; k2 = 1
.line	774	move          r0    r0
.line	774	self          r5    r0    k3 ; k3 = "DelayCalGridAssetCos" (truncated)
.line	774	move          r7    r4
.line	774	call          r5     3     1
.line	774	move          r0    r0
.label	l15
.line	774	self          r1    r0    k4 ; k4 = "ModifyAllGridColor"
.line	774	call          r1     2     1
.line	774	self          r1    r0    k5 ; k5 = "DelayUpdateGridColor" (truncated)
.line	774	call          r1     2     1
.line	774	return        r0     1
.line	774	move          r0    r0
.line	774	move          r0    r0
.line	774	return        r0     1

.function	main/f41

.source	null
.linedefined	784
.lastlinedefined	789
.numparams	1
.is_vararg	0
.maxstacksize	9

.upvalue	"_ENV"	0	false

.constant	k0	"pairs"
.constant	k1	"DelayUpdateGridAssetCostTimerIDMap"
.constant	k2	"RemoveGameTimer"
.constant	k3	-1

.line	784	gettabup      r1    u0    k0 ; k0 = "pairs"
.line	784	gettable      r2    r0    k1 ; k1 = "DelayUpdateGridAsset" (truncated)
.line	784	call          r1     2     4
.line	784	jmp            0   l10
.line	784	self          r6    r0    k2 ; k2 = "RemoveGameTimer"
.line	784	move          r8    r5
.line	784	call          r6     3     1
.line	784	gettable      r6    r0    k1 ; k1 = "DelayUpdateGridAsset" (truncated)
.line	784	settable      r6    r4    k3 ; k3 = -1
.label	l10
.line	784	move          r0    r0
.line	784	move          r0    r0
.line	784	return        r0     1
.line	784	move          r0    r0
.line	784	move          r0    r0
.line	784	move          r0    r0
.line	784	return        r0     1

.function	main/f42

.source	null
.linedefined	791
.lastlinedefined	799
.numparams	2
.is_vararg	0
.maxstacksize	8

.constant	k0	"DelayUpdateGridAssetCostTimerIDMap"
.constant	k1	-1
.constant	k2	nil
.constant	k3	"AddGameTimer"
.constant	k4	"DelayUpdateGridAssetCostTime"

.line	791	gettable      r2    r0    k0 ; k0 = "DelayUpdateGridAsset" (truncated)
.line	791	gettable      r2    r2    r1
.line	791	eq             1    r2    k1 ; k1 = -1
.line	791	jmp            0   l10
.line	791	gettable      r2    r0    k0 ; k0 = "DelayUpdateGridAsset" (truncated)
.line	791	gettable      r2    r2    r1
.line	791	eq             1    r2    k2 ; k2 = nil
.line	791	jmp            0   l10
.line	791	return        r0     1
.label	l10
.line	791	gettable      r2    r0    k0 ; k0 = "DelayUpdateGridAsset" (truncated)
.line	791	self          r3    r0    k3 ; k3 = "AddGameTimer"
.line	791	gettable      r5    r0    k4 ; k4 = "DelayUpdateGridAsset" (truncated)
.line	791	loadbool      r6     0     0
.line	791	closure       r7    f0
.line	791	call          r3     5     2
.line	791	settable      r2    r1    r3
.line	791	return        r0     1
.line	791	move          r0    r0
.line	791	return        r0     1

.function	main/f42/f0

.source	null
.linedefined	795
.lastlinedefined	798
.numparams	0
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	0	true
.upvalue	"U1"	1	true

.constant	k0	"CalGridAssetCost"
.constant	k1	"DelayUpdateGridAssetCostTimerIDMap"
.constant	k2	-1

.line	795	getupval      r0    u0
.line	795	self          r0    r0    k0 ; k0 = "CalGridAssetCost"
.line	795	getupval      r2    u1
.line	795	call          r0     3     1
.line	795	gettabup      r0    u0    k1 ; k1 = "DelayUpdateGridAsset" (truncated)
.line	795	getupval      r1    u1
.line	795	settable      r0    r1    k2 ; k2 = -1
.line	795	return        r0     1
.line	795	move          r0    r0
.line	795	return        r0     1

.function	main/f43

.source	null
.linedefined	801
.lastlinedefined	829
.numparams	2
.is_vararg	0
.maxstacksize	14

.upvalue	"_ENV"	0	false
.upvalue	"U1"	19	true
.upvalue	"U2"	35	true

.constant	k0	"GetNearCellIndexList"
.constant	k1	0
.constant	k2	"ipairs"
.constant	k3	"InstanceGridCost"
.constant	k4	"triCost"
.constant	k5	"dcCost"
.constant	k6	"GetMapInitAssetCost"
.constant	k7	"InstanceGridCombineCost"
.constant	k8	nil
.constant	k9	"max"
.constant	k10	"ModifyGridColor"

.line	801	self          r2    r0    k0 ; k0 = "GetNearCellIndexList"
.line	801	move          r4    r1
.line	801	call          r2     3     2
.line	801	loadk         r3    k1 ; k1 = 0
.line	801	loadk         r4    k1 ; k1 = 0
.line	801	loadk         r5    k1 ; k1 = 0
.line	801	gettabup      r6    u0    k2 ; k2 = "ipairs"
.line	801	move          r7    r2
.line	801	call          r6     2     4
.line	801	jmp            0   l33
.line	801	gettable     r11    r0    k3 ; k3 = "InstanceGridCost"
.line	801	gettable     r11   r11   r10
.line	801	test         r11     0
.line	801	jmp            0   l29
.line	801	gettable     r11    r0    k3 ; k3 = "InstanceGridCost"
.line	801	gettable     r11   r11   r10
.line	801	gettable     r11   r11    k4 ; k4 = "triCost"
.line	801	test         r11     1
.line	801	jmp            0   l21
.line	801	loadk        r11    k1 ; k1 = 0
.label	l21
.line	801	add           r3    r3   r11
.line	801	gettable     r11    r0    k3 ; k3 = "InstanceGridCost"
.line	801	gettable     r11   r11   r10
.line	801	gettable     r11   r11    k5 ; k5 = "dcCost"
.line	801	test         r11     1
.line	801	jmp            0   l28
.line	801	loadk        r11    k1 ; k1 = 0
.label	l28
.line	801	add           r4    r4   r11
.label	l29
.line	801	self         r11    r0    k6 ; k6 = "GetMapInitAssetCost"
.line	801	move         r13   r10
.line	801	call         r11     3     2
.line	801	add           r5    r5   r11
.label	l33
.line	801	move          r0    r0
.line	801	move          r0    r0
.line	801	self          r6    r0    k6 ; k6 = "GetMapInitAssetCost"
.line	801	move          r8    r1
.line	801	call          r6     3     2
.line	801	add           r5    r5    r6
.line	801	getupval      r6    u1
.line	801	mul           r6    r3    r6
.line	801	add           r6    r6    r5
.line	801	getupval      r7    u1
.line	801	mul           r7    r4    r7
.line	801	add           r7    r7    r5
.line	801	gettable      r8    r0    k3 ; k3 = "InstanceGridCost"
.line	801	gettable      r8    r8    r1
.line	801	test          r8     0
.line	801	jmp            0   l63
.line	801	gettable      r8    r0    k3 ; k3 = "InstanceGridCost"
.line	801	gettable      r8    r8    r1
.line	801	gettable      r8    r8    k4 ; k4 = "triCost"
.line	801	test          r8     1
.line	801	jmp            0   l55
.line	801	loadk         r8    k1 ; k1 = 0
.label	l55
.line	801	add           r6    r6    r8
.line	801	gettable      r8    r0    k3 ; k3 = "InstanceGridCost"
.line	801	gettable      r8    r8    r1
.line	801	gettable      r8    r8    k5 ; k5 = "dcCost"
.line	801	test          r8     1
.line	801	jmp            0   l62
.line	801	loadk         r8    k1 ; k1 = 0
.label	l62
.line	801	add           r7    r7    r8
.label	l63
.line	801	gettable      r8    r0    k7 ; k7 = "InstanceGridCombineC" (truncated)
.line	801	gettable      r8    r8    r1
.line	801	eq             1    r8    k8 ; k8 = nil
.line	801	jmp            0   l73
.line	801	gettabup      r9    u2    k9 ; k9 = "max"
.line	801	gettable     r10    r8    k4 ; k4 = "triCost"
.line	801	gettable     r11    r8    k5 ; k5 = "dcCost"
.line	801	call          r9     3     2
.line	801	test          r9     1
.line	801	jmp            0   l74
.label	l73
.line	801	loadk         r9    k1 ; k1 = 0
.label	l74
.line	801	gettable     r10    r0    k7 ; k7 = "InstanceGridCombineC" (truncated)
.line	801	gettable     r11    r0    k7 ; k7 = "InstanceGridCombineC" (truncated)
.line	801	gettable     r11   r11    r1
.line	801	test         r11     1
.line	801	jmp            0   l80
.line	801	newtable     r11     0     0
.label	l80
.line	801	settable     r10    r1   r11
.line	801	gettable     r10    r0    k7 ; k7 = "InstanceGridCombineC" (truncated)
.line	801	gettable     r10   r10    r1
.line	801	settable     r10    k4    r6 ; k4 = "triCost"
.line	801	gettable     r10    r0    k7 ; k7 = "InstanceGridCombineC" (truncated)
.line	801	gettable     r10   r10    r1
.line	801	settable     r10    k5    r7 ; k5 = "dcCost"
.line	801	gettabup     r10    u2    k9 ; k9 = "max"
.line	801	move         r11    r6
.line	801	move         r12    r7
.line	801	call         r10     3     2
.line	801	eq             1    r9   r10
.line	801	jmp            0   l96
.line	801	self         r11    r0   k10 ; k10 = "ModifyGridColor"
.line	801	move         r13    r1
.line	801	call         r11     3     1
.label	l96
.line	801	return        r0     1
.line	801	move          r0    r0
.line	801	move          r0    r0
.line	801	move          r0    r0
.line	801	return        r0     1

.function	main/f44

.source	null
.linedefined	831
.lastlinedefined	837
.numparams	2
.is_vararg	0
.maxstacksize	11

.upvalue	"_ENV"	0	false

.constant	k0	"GetNearCellIndexList"
.constant	k1	"ipairs"
.constant	k2	"DelayCalGridAssetCost"

.line	831	self          r2    r0    k0 ; k0 = "GetNearCellIndexList"
.line	831	move          r4    r1
.line	831	call          r2     3     2
.line	831	gettabup      r3    u0    k1 ; k1 = "ipairs"
.line	831	move          r4    r2
.line	831	call          r3     2     4
.line	831	jmp            0   l11
.line	831	self          r8    r0    k2 ; k2 = "DelayCalGridAssetCos" (truncated)
.line	831	move         r10    r7
.line	831	call          r8     3     1
.label	l11
.line	831	move          r0    r0
.line	831	move          r0    r0
.line	831	self          r3    r0    k2 ; k2 = "DelayCalGridAssetCos" (truncated)
.line	831	move          r5    r1
.line	831	call          r3     3     1
.line	831	return        r0     1
.line	831	move          r0    r0
.line	831	return        r0     1

.function	main/f45

.source	null
.linedefined	839
.lastlinedefined	863
.numparams	2
.is_vararg	0
.maxstacksize	16

.upvalue	"_ENV"	35	true
.upvalue	"U1"	0	false

.constant	k0	"NearGridIndexList"
.constant	k1	0
.constant	k2	"MapCellCount"
.constant	k3	"floor"
.constant	k4	"StreamAffectCount"
.constant	k5	1
.constant	k6	"table"
.constant	k7	"insert"

.line	839	gettable      r2    r0    k0 ; k0 = "NearGridIndexList"
.line	839	test          r2     1
.line	839	jmp            0    l6
.line	839	newtable      r2     0     0
.line	839	settable      r0    k0    r2 ; k0 = "NearGridIndexList"
.label	l6
.line	839	gettable      r2    r0    k0 ; k0 = "NearGridIndexList"
.line	839	gettable      r2    r2    r1
.line	839	test          r2     1
.line	839	jmp            0   l13
.line	839	gettable      r2    r0    k0 ; k0 = "NearGridIndexList"
.line	839	newtable      r3     0     0
.line	839	settable      r2    r1    r3
.label	l13
.line	839	gettable      r2    r0    k0 ; k0 = "NearGridIndexList"
.line	839	gettable      r2    r2    r1
.line	839	len           r2    r2
.line	839	eq             0    r2    k1 ; k1 = 0
.line	839	jmp            0   l59
.line	839	gettable      r2    r0    k2 ; k2 = "MapCellCount"
.line	839	mod           r2    r1    r2
.line	839	gettabup      r3    u0    k3 ; k3 = "floor"
.line	839	gettable      r4    r0    k2 ; k2 = "MapCellCount"
.line	839	div           r4    r1    r4
.line	839	call          r3     2     2
.line	839	gettable      r4    r0    k4 ; k4 = "StreamAffectCount"
.line	839	sub           r4    r2    r4
.line	839	gettable      r5    r0    k4 ; k4 = "StreamAffectCount"
.line	839	add           r5    r2    r5
.line	839	loadk         r6    k5 ; k5 = 1
.line	839	move          r0    r0
.line	839	le             0    k1    r7 ; k1 = 0
.line	839	jmp            0   l58
.line	839	gettable      r8    r0    k2 ; k2 = "MapCellCount"
.line	839	lt             0    r7    r8
.line	839	jmp            0   l58
.line	839	gettable      r8    r0    k4 ; k4 = "StreamAffectCount"
.line	839	sub           r8    r3    r8
.line	839	gettable      r9    r0    k4 ; k4 = "StreamAffectCount"
.line	839	add           r9    r3    r9
.line	839	loadk        r10    k5 ; k5 = 1
.line	839	move          r0    r0
.line	839	le             0    k1   r11 ; k1 = 0
.line	839	jmp            0   l57
.line	839	gettable     r12    r0    k2 ; k2 = "MapCellCount"
.line	839	lt             0   r11   r12
.line	839	jmp            0   l57
.line	839	gettable     r12    r0    k2 ; k2 = "MapCellCount"
.line	839	mul          r12   r11   r12
.line	839	add          r12   r12    r7
.line	839	eq             1   r12    r1
.line	839	jmp            0   l57
.line	839	gettabup     r13    u1    k6 ; k6 = "table"
.line	839	gettable     r13   r13    k7 ; k7 = "insert"
.line	839	gettable     r14    r0    k0 ; k0 = "NearGridIndexList"
.line	839	gettable     r14   r14    r1
.line	839	move         r15   r12
.line	839	call         r13     3     1
.label	l57
.line	839	move          r0    r0
.label	l58
.line	839	move          r0    r0
.label	l59
.line	839	gettable      r2    r0    k0 ; k0 = "NearGridIndexList"
.line	839	gettable      r2    r2    r1
.line	839	return        r2     2
.line	839	return        r0     1
.line	839	move          r0    r0
.line	839	return        r0     1

.function	main/f46

.source	null
.linedefined	865
.lastlinedefined	883
.numparams	2
.is_vararg	0
.maxstacksize	15

.upvalue	"_ENV"	0	false

.constant	k0	"InstanceGrid"
.constant	k1	"InstanceGridCost"
.constant	k2	"triCost"
.constant	k3	0
.constant	k4	"dcCost"
.constant	k5	"ResetRepeatedComputeCostMap"
.constant	k6	"pairs"
.constant	k7	"GetInstanceAssetCost"
.constant	k8	"GetInstanceCostInfo"
.constant	k9	"RecordRepeatedCompute"

.line	865	gettable      r2    r0    k0 ; k0 = "InstanceGrid"
.line	865	test          r2     0
.line	865	jmp            0   l42
.line	865	gettable      r2    r0    k1 ; k1 = "InstanceGridCost"
.line	865	test          r2     0
.line	865	jmp            0   l42
.line	865	gettable      r2    r0    k0 ; k0 = "InstanceGrid"
.line	865	gettable      r2    r2    r1
.line	865	test          r2     0
.line	865	jmp            0   l42
.line	865	newtable      r3     0     2
.line	865	settable      r3    k2    k3 ; k3 = 0
.line	865	settable      r3    k4    k3 ; k3 = 0
.line	865	gettable      r4    r0    k1 ; k1 = "InstanceGridCost"
.line	865	settable      r4    r1    r3
.line	865	self          r4    r0    k5 ; k5 = "ResetRepeatedCompute" (truncated)
.line	865	move          r6    r1
.line	865	call          r4     3     1
.line	865	gettabup      r4    u0    k6 ; k6 = "pairs"
.line	865	move          r5    r2
.line	865	call          r4     2     4
.line	865	jmp            0   l40
.line	865	test          r8     0
.line	865	jmp            0   l40
.line	865	self          r9    r0    k7 ; k7 = "GetInstanceAssetCost"
.line	865	move         r11    r7
.line	865	call          r9     3     3
.line	865	gettable     r11    r3    k2 ; k2 = "triCost"
.line	865	add          r11   r11    r9
.line	865	settable      r3    k2   r11 ; k2 = "triCost"
.line	865	gettable     r11    r3    k4 ; k4 = "dcCost"
.line	865	add          r11   r11   r10
.line	865	settable      r3    k4   r11 ; k4 = "dcCost"
.line	865	self         r11    r0    k8 ; k8 = "GetInstanceCostInfo"
.line	865	move         r13    r7
.line	865	call         r11     3     2
.line	865	self         r12    r0    k9 ; k9 = "RecordRepeatedComput" (truncated)
.line	865	move         r14   r11
.line	865	call         r12     3     1
.label	l40
.line	865	move          r0    r0
.line	865	move          r0    r0
.label	l42
.line	865	return        r0     1
.line	865	move          r0    r0
.line	865	move          r0    r0
.line	865	move          r0    r0
.line	865	move          r0    r0
.line	865	return        r0     1

.function	main/f47

.source	null
.linedefined	885
.lastlinedefined	907
.numparams	4
.is_vararg	0
.maxstacksize	11

.constant	k0	"InstanceGrid"
.constant	k1	"InstanceGridCost"
.constant	k2	"GridIndex"
.constant	k3	true
.constant	k4	"GetInstanceAssetCost"
.constant	k5	"triCost"
.constant	k6	"dcCost"
.constant	k7	"RecordRepeatedCompute"
.constant	k8	"RemoveRepeatedCompute"
.constant	k9	false

.line	885	gettable      r4    r0    k0 ; k0 = "InstanceGrid"
.line	885	test          r4     0
.line	885	jmp            0   l62
.line	885	gettable      r4    r0    k1 ; k1 = "InstanceGridCost"
.line	885	test          r4     0
.line	885	jmp            0   l62
.line	885	gettable      r4    r2    k2 ; k2 = "GridIndex"
.line	885	gettable      r5    r0    k0 ; k0 = "InstanceGrid"
.line	885	gettable      r5    r5    r4
.line	885	test          r5     0
.line	885	jmp            0   l62
.line	885	gettable      r5    r0    k0 ; k0 = "InstanceGrid"
.line	885	gettable      r5    r5    r4
.line	885	gettable      r5    r5    r1
.line	885	test          r5     1
.line	885	jmp            0   l37
.line	885	test          r3     0
.line	885	jmp            0   l37
.line	885	gettable      r5    r0    k0 ; k0 = "InstanceGrid"
.line	885	gettable      r5    r5    r4
.line	885	settable      r5    r1    k3 ; k3 = true
.line	885	self          r5    r0    k4 ; k4 = "GetInstanceAssetCost"
.line	885	move          r7    r1
.line	885	move          r8    r2
.line	885	call          r5     4     3
.line	885	gettable      r7    r0    k1 ; k1 = "InstanceGridCost"
.line	885	gettable      r7    r7    r4
.line	885	gettable      r8    r7    k5 ; k5 = "triCost"
.line	885	add           r8    r8    r5
.line	885	settable      r7    k5    r8 ; k5 = "triCost"
.line	885	gettable      r8    r7    k6 ; k6 = "dcCost"
.line	885	add           r8    r8    r6
.line	885	settable      r7    k6    r8 ; k6 = "dcCost"
.line	885	self          r8    r0    k7 ; k7 = "RecordRepeatedComput" (truncated)
.line	885	move         r10    r2
.line	885	call          r8     3     1
.label	l37
.line	885	gettable      r5    r0    k0 ; k0 = "InstanceGrid"
.line	885	gettable      r5    r5    r4
.line	885	gettable      r5    r5    r1
.line	885	test          r5     0
.line	885	jmp            0   l62
.line	885	test          r3     1
.line	885	jmp            0   l62
.line	885	self          r5    r0    k8 ; k8 = "RemoveRepeatedComput" (truncated)
.line	885	move          r7    r2
.line	885	call          r5     3     1
.line	885	gettable      r5    r0    k0 ; k0 = "InstanceGrid"
.line	885	gettable      r5    r5    r4
.line	885	settable      r5    r1    k9 ; k9 = false
.line	885	self          r5    r0    k4 ; k4 = "GetInstanceAssetCost"
.line	885	move          r7    r1
.line	885	move          r8    r2
.line	885	call          r5     4     3
.line	885	gettable      r7    r0    k1 ; k1 = "InstanceGridCost"
.line	885	gettable      r7    r7    r4
.line	885	gettable      r8    r7    k5 ; k5 = "triCost"
.line	885	sub           r8    r8    r5
.line	885	settable      r7    k5    r8 ; k5 = "triCost"
.line	885	gettable      r8    r7    k6 ; k6 = "dcCost"
.line	885	sub           r8    r8    r6
.line	885	settable      r7    k6    r8 ; k6 = "dcCost"
.label	l62
.line	885	return        r0     1
.line	885	move          r0    r0
.line	885	move          r0    r0
.line	885	return        r0     1

.function	main/f48

.source	null
.linedefined	909
.lastlinedefined	922
.numparams	1
.is_vararg	0
.maxstacksize	12

.upvalue	"_ENV"	0	false

.constant	k0	"AlwaysLoadInstancesCost"
.constant	k1	0
.constant	k2	"AlwaysLoadInstances"
.constant	k3	"ResetRepeatedComputeCostMap"
.constant	k4	"pairs"
.constant	k5	"GetInstanceAssetCost"
.constant	k6	"GetInstanceCostInfo"
.constant	k7	"RecordRepeatedCompute"

.line	909	settable      r0    k0    k1 ; k1 = 0
.line	909	gettable      r1    r0    k2 ; k2 = "AlwaysLoadInstances"
.line	909	test          r1     0
.line	909	jmp            0   l27
.line	909	self          r1    r0    k3 ; k3 = "ResetRepeatedCompute" (truncated)
.line	909	call          r1     2     1
.line	909	gettabup      r1    u0    k4 ; k4 = "pairs"
.line	909	gettable      r2    r0    k2 ; k2 = "AlwaysLoadInstances"
.line	909	call          r1     2     4
.line	909	jmp            0   l25
.line	909	test          r5     0
.line	909	jmp            0   l25
.line	909	self          r6    r0    k5 ; k5 = "GetInstanceAssetCost"
.line	909	move          r8    r4
.line	909	call          r6     3     3
.line	909	gettable      r8    r0    k0 ; k0 = "AlwaysLoadInstancesC" (truncated)
.line	909	add           r8    r8    r6
.line	909	settable      r0    k0    r8 ; k0 = "AlwaysLoadInstancesC" (truncated)
.line	909	self          r8    r0    k6 ; k6 = "GetInstanceCostInfo"
.line	909	move         r10    r4
.line	909	call          r8     3     2
.line	909	self          r9    r0    k7 ; k7 = "RecordRepeatedComput" (truncated)
.line	909	move         r11    r8
.line	909	call          r9     3     1
.label	l25
.line	909	move          r0    r0
.line	909	move          r0    r0
.label	l27
.line	909	return        r0     1
.line	909	move          r0    r0
.line	909	move          r0    r0
.line	909	move          r0    r0
.line	909	return        r0     1

.function	main/f49

.source	null
.linedefined	924
.lastlinedefined	954
.numparams	1
.is_vararg	0
.maxstacksize	27

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	25	true
.upvalue	"U3"	35	true
.upvalue	"U4"	26	true
.upvalue	"U5"	27	true
.upvalue	"U6"	28	true

.constant	k0	"MapInitAssetCost"
.constant	k1	"import"
.constant	k2	106
.constant	k3	185
.constant	k4	103
.constant	k5	49
.constant	k6	83
.constant	k7	10
.constant	k8	143
.constant	k9	18
.constant	k10	45
.constant	k11	13
.constant	k12	53
.constant	k13	35
.constant	k14	39
.constant	k15	139
.constant	k16	"require"
.constant	k17	78
.constant	k18	180
.constant	k19	99
.constant	k20	77
.constant	k21	192
.constant	k22	163
.constant	k23	46
.constant	k24	52
.constant	k25	1
.constant	k26	36
.constant	k27	141
.constant	k28	230
.constant	k29	130
.constant	k30	157
.constant	k31	14
.constant	k32	191
.constant	k33	"GetCurrentLevelName"
.constant	k34	"GetGameInstance"
.constant	k35	0
.constant	k36	"CDataTable"
.constant	k37	"GetTable"
.constant	k38	120
.constant	k39	159
.constant	k40	73
.constant	k41	25
.constant	k42	66
.constant	k43	22
.constant	k44	167
.constant	k45	174
.constant	k46	40
.constant	k47	47
.constant	k48	57
.constant	k49	48
.constant	k50	187
.constant	k51	224
.constant	k52	179
.constant	k53	142
.constant	k54	19
.constant	k55	3
.constant	k56	"X"
.constant	k57	"Y"
.constant	k58	"Z"
.constant	k59	183
.constant	k60	76
.constant	k61	8
.constant	k62	43
.constant	k63	5
.constant	k64	27
.constant	k65	251
.constant	k66	132
.constant	k67	"pairs"
.constant	k68	"MappingID"
.constant	k69	"Split"
.constant	k70	"CellCenter"
.constant	k71	2
.constant	k72	"GetCellIndex"
.constant	k73	"ceil"
.constant	k74	"NumTriangles"
.constant	k75	100
.constant	k76	"NumMeshType"

.line	924	gettable      r1    r0    k0 ; k0 = "MapInitAssetCost"
.line	924	test          r1     0
.line	924	jmp            0    l5
.line	924	return        r0     1
.label	l5
.line	924	newtable      r1     0     0
.line	924	settable      r0    k0    r1 ; k0 = "MapInitAssetCost"
.line	924	gettabup      r1    u0    k1 ; k1 = "import"
.line	924	getupval      r2    u1
.line	924	loadk         r3    k2 ; k2 = 106
.line	924	loadk         r4    k3 ; k3 = 185
.line	924	loadk         r5    k4 ; k4 = 103
.line	924	loadk         r6    k5 ; k5 = 49
.line	924	loadk         r7    k6 ; k6 = 83
.line	924	loadk         r8    k7 ; k7 = 10
.line	924	loadk         r9    k8 ; k8 = 143
.line	924	loadk        r10    k3 ; k3 = 185
.line	924	loadk        r11    k9 ; k9 = 18
.line	924	loadk        r12   k10 ; k10 = 45
.line	924	loadk        r13   k11 ; k11 = 13
.line	924	loadk        r14   k12 ; k12 = 53
.line	924	loadk        r15   k13 ; k13 = 35
.line	924	loadk        r16   k14 ; k14 = 39
.line	924	loadk        r17   k15 ; k15 = 139
.line	924	call          r2    16     2
.line	924	call          r1     2     2
.line	924	gettabup      r2    u0   k16 ; k16 = "require"
.line	924	getupval      r3    u1
.line	924	loadk         r4   k17 ; k17 = 78
.line	924	loadk         r5   k18 ; k18 = 180
.line	924	loadk         r6   k19 ; k19 = 99
.line	924	loadk         r7    k5 ; k5 = 49
.line	924	loadk         r8   k20 ; k20 = 77
.line	924	loadk         r9    k9 ; k9 = 18
.line	924	loadk        r10   k21 ; k21 = 192
.line	924	loadk        r11   k22 ; k22 = 163
.line	924	loadk        r12   k23 ; k23 = 46
.line	924	loadk        r13   k24 ; k24 = 52
.line	924	loadk        r14   k25 ; k25 = 1
.line	924	loadk        r15   k23 ; k23 = 46
.line	924	loadk        r16   k26 ; k26 = 36
.line	924	loadk        r17    k2 ; k2 = 106
.line	924	loadk        r18   k27 ; k27 = 141
.line	924	loadk        r19   k28 ; k28 = 230
.line	924	loadk        r20   k29 ; k29 = 130
.line	924	loadk        r21   k30 ; k30 = 157
.line	924	loadk        r22   k31 ; k31 = 14
.line	924	loadk        r23   k11 ; k11 = 13
.line	924	loadk        r24   k32 ; k32 = 191
.line	924	call          r3    22     2
.line	924	call          r2     2     2
.line	924	gettable      r3    r1   k33 ; k33 = "GetCurrentLevelName"
.line	924	gettable      r4    r2   k34 ; k34 = "GetGameInstance"
.line	924	call          r4     1     2
.line	924	loadbool      r5     1     0
.line	924	call          r3     3     2
.line	924	gettabup      r4    u2    r3
.line	924	test          r4     1
.line	924	jmp            0   l60
.line	924	loadk         r4   k35 ; k35 = 0
.label	l60
.line	924	eq             1    r4   k35 ; k35 = 0
.line	924	jmp            0  l157
.line	924	gettabup      r5    u0   k36 ; k36 = "CDataTable"
.line	924	gettable      r5    r5   k37 ; k37 = "GetTable"
.line	924	getupval      r6    u1
.line	924	loadk         r7   k38 ; k38 = 120
.line	924	loadk         r8   k39 ; k39 = 159
.line	924	loadk         r9   k40 ; k40 = 73
.line	924	loadk        r10   k41 ; k41 = 25
.line	924	loadk        r11   k42 ; k42 = 66
.line	924	loadk        r12   k43 ; k43 = 22
.line	924	loadk        r13   k44 ; k44 = 167
.line	924	loadk        r14   k45 ; k45 = 174
.line	924	loadk        r15   k46 ; k46 = 40
.line	924	loadk        r16   k10 ; k10 = 45
.line	924	loadk        r17   k47 ; k47 = 47
.line	924	loadk        r18   k23 ; k23 = 46
.line	924	loadk        r19   k48 ; k48 = 57
.line	924	loadk        r20   k49 ; k49 = 48
.line	924	loadk        r21   k50 ; k50 = 187
.line	924	loadk        r22   k51 ; k51 = 224
.line	924	loadk        r23   k52 ; k52 = 179
.line	924	loadk        r24   k53 ; k53 = 142
.line	924	loadk        r25   k54 ; k54 = 19
.line	924	loadk        r26   k55 ; k55 = 3
.line	924	call          r6    21     2
.line	924	call          r5     2     2
.line	924	newtable      r6     0     3
.line	924	settable      r6   k56   k35 ; k35 = 0
.line	924	settable      r6   k57   k35 ; k35 = 0
.line	924	settable      r6   k58   k35 ; k35 = 0
.line	924	gettabup      r7    u0   k16 ; k16 = "require"
.line	924	getupval      r8    u1
.line	924	loadk         r9   k17 ; k17 = 78
.line	924	loadk        r10   k59 ; k59 = 183
.line	924	loadk        r11    k4 ; k4 = 103
.line	924	loadk        r12   k48 ; k48 = 57
.line	924	loadk        r13   k60 ; k60 = 76
.line	924	loadk        r14   k61 ; k61 = 8
.line	924	loadk        r15   k21 ; k21 = 192
.line	924	loadk        r16   k52 ; k52 = 179
.line	924	loadk        r17   k12 ; k12 = 53
.line	924	loadk        r18   k62 ; k62 = 43
.line	924	loadk        r19   k63 ; k63 = 5
.line	924	loadk        r20   k47 ; k47 = 47
.line	924	loadk        r21   k10 ; k10 = 45
.line	924	loadk        r22   k64 ; k64 = 27
.line	924	loadk        r23   k27 ; k27 = 141
.line	924	loadk        r24   k65 ; k65 = 251
.line	924	loadk        r25   k18 ; k18 = 180
.line	924	loadk        r26   k66 ; k66 = 132
.line	924	call          r8    19     2
.line	924	call          r7     2     2
.line	924	gettabup      r8    u0   k67 ; k67 = "pairs"
.line	924	move          r9    r5
.line	924	call          r8     2     4
.line	924	jmp            0  l155
.line	924	gettable     r13   r12   k68 ; k68 = "MappingID"
.line	924	eq             0   r13    r4
.line	924	jmp            0  l155
.line	924	gettable     r13    r7   k69 ; k69 = "Split"
.line	924	gettable     r14   r12   k70 ; k70 = "CellCenter"
.line	924	getupval     r15    u1
.line	924	loadk        r16   k43 ; k43 = 22
.line	924	call         r15     2     2
.line	924	call         r13     3     2
.line	924	test         r13     0
.line	924	jmp            0  l138
.line	924	gettable     r14   r13   k25 ; k25 = 1
.line	924	test         r14     1
.line	924	jmp            0  l132
.line	924	loadk        r14   k35 ; k35 = 0
.label	l132
.line	924	settable      r6   k56   r14 ; k56 = "X"
.line	924	gettable     r14   r13   k71 ; k71 = 2
.line	924	test         r14     1
.line	924	jmp            0  l137
.line	924	loadk        r14   k35 ; k35 = 0
.label	l137
.line	924	settable      r6   k57   r14 ; k57 = "Y"
.label	l138
.line	924	self         r14    r0   k72 ; k72 = "GetCellIndex"
.line	924	move         r16    r6
.line	924	call         r14     3     2
.line	924	gettabup     r15    u3   k73 ; k73 = "ceil"
.line	924	gettable     r16   r12   k74 ; k74 = "NumTriangles"
.line	924	div          r16   r16   k75 ; k75 = 100
.line	924	call         r15     2     2
.line	924	gettable     r16    r0    k0 ; k0 = "MapInitAssetCost"
.line	924	getupval     r17    u4
.line	924	gettable     r18   r12   k76 ; k76 = "NumMeshType"
.line	924	mul          r17   r17   r18
.line	924	getupval     r18    u5
.line	924	mul          r18   r15   r18
.line	924	add          r17   r17   r18
.line	924	getupval     r18    u6
.line	924	mul          r17   r17   r18
.line	924	settable     r16   r14   r17
.label	l155
.line	924	move          r0    r0
.line	924	move          r0    r0
.label	l157
.line	924	return        r0     1
.line	924	move          r0    r0
.line	924	move          r0    r0
.line	924	return        r0     1

.function	main/f50

.source	null
.linedefined	956
.lastlinedefined	961
.numparams	2
.is_vararg	0
.maxstacksize	4

.constant	k0	"MapInitAssetCost"
.constant	k1	nil
.constant	k2	"InitMapInitAssetCost"
.constant	k3	0

.line	956	gettable      r2    r0    k0 ; k0 = "MapInitAssetCost"
.line	956	eq             0    r2    k1 ; k1 = nil
.line	956	jmp            0    l6
.line	956	self          r2    r0    k2 ; k2 = "InitMapInitAssetCost"
.line	956	call          r2     2     1
.label	l6
.line	956	gettable      r2    r0    k0 ; k0 = "MapInitAssetCost"
.line	956	gettable      r2    r2    r1
.line	956	test          r2     1
.line	956	jmp            0   l11
.line	956	loadk         r2    k3 ; k3 = 0
.label	l11
.line	956	return        r2     2
.line	956	return        r0     1
.line	956	move          r0    r0
.line	956	return        r0     1

.function	main/f51

.source	null
.linedefined	963
.lastlinedefined	967
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	"InstacneCostInfoMap"
.constant	k1	nil

.line	963	gettable      r1    r0    k0 ; k0 = "InstacneCostInfoMap"
.line	963	eq             1    r1    k1 ; k1 = nil
.line	963	jmp            0    l6
.line	963	newtable      r1     0     0
.line	963	settable      r0    k0    r1 ; k0 = "InstacneCostInfoMap"
.label	l6
.line	963	return        r0     1
.line	963	move          r0    r0
.line	963	move          r0    r0
.line	963	return        r0     1

.function	main/f52

.source	null
.linedefined	969
.lastlinedefined	974
.numparams	2
.is_vararg	0
.maxstacksize	3

.constant	k0	"InstacneCostInfoMap"
.constant	k1	nil

.line	969	gettable      r2    r0    k0 ; k0 = "InstacneCostInfoMap"
.line	969	eq             1    r2    k1 ; k1 = nil
.line	969	jmp            0   l11
.line	969	gettable      r2    r0    k0 ; k0 = "InstacneCostInfoMap"
.line	969	gettable      r2    r2    r1
.line	969	test          r2     0
.line	969	jmp            0   l11
.line	969	gettable      r2    r0    k0 ; k0 = "InstacneCostInfoMap"
.line	969	gettable      r2    r2    r1
.line	969	return        r2     2
.label	l11
.line	969	loadnil       r2     0
.line	969	return        r2     2
.line	969	return        r0     1
.line	969	move          r0    r0
.line	969	move          r0    r0
.line	969	move          r0    r0
.line	969	return        r0     1

.function	main/f53

.source	null
.linedefined	976
.lastlinedefined	1003
.numparams	3
.is_vararg	0
.maxstacksize	15

.upvalue	"_ENV"	10	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	nil
.constant	k1	"AssetCategory"
.constant	k2	"E_AssetType"
.constant	k3	"UserActor"
.constant	k4	"GetAssetManager"
.constant	k5	"IsDynamicAsset"
.constant	k6	"ActorID"
.constant	k7	0
.constant	k8	"CustomActor"
.constant	k9	"GetCreativeActorDataManager"
.constant	k10	"GetActorCost"
.constant	k11	"type"
.constant	k12	67
.constant	k13	173
.constant	k14	103
.constant	k15	54
.constant	k16	70
.constant	k17	20

.line	976	eq             1    r1    k0 ; k0 = nil
.line	976	jmp            0    l5
.line	976	eq             0    r2    k0 ; k0 = nil
.line	976	jmp            0    l7
.label	l5
.line	976	loadnil       r3     0
.line	976	return        r3     2
.label	l7
.line	976	gettable      r3    r1    k1 ; k1 = "AssetCategory"
.line	976	gettabup      r4    u0    k2 ; k2 = "E_AssetType"
.line	976	gettable      r4    r4    k3 ; k3 = "UserActor"
.line	976	eq             1    r3    r4
.line	976	jmp            0   l14
.line	976	loadnil       r3     0
.line	976	return        r3     2
.label	l14
.line	976	gettabup      r3    u1    k4 ; k4 = "GetAssetManager"
.line	976	call          r3     1     2
.line	976	eq             1    r3    k0 ; k0 = nil
.line	976	jmp            0   l23
.line	976	self          r4    r3    k5 ; k5 = "IsDynamicAsset"
.line	976	move          r6    r2
.line	976	call          r4     3     2
.line	976	test          r4     1
.line	976	jmp            0   l25
.label	l23
.line	976	loadnil       r4     0
.line	976	return        r4     2
.label	l25
.line	976	gettable      r4    r1    k6 ; k6 = "ActorID"
.line	976	eq             1    r4    k0 ; k0 = nil
.line	976	jmp            0   l30
.line	976	eq             0    r4    k7 ; k7 = 0
.line	976	jmp            0   l35
.label	l30
.line	976	gettable      r5    r1    k8 ; k8 = "CustomActor"
.line	976	eq             1    r5    k0 ; k0 = nil
.line	976	jmp            0   l35
.line	976	gettable      r5    r1    k8 ; k8 = "CustomActor"
.line	976	gettable      r4    r5    k6 ; k6 = "ActorID"
.label	l35
.line	976	eq             1    r4    k0 ; k0 = nil
.line	976	jmp            0   l42
.line	976	eq             1    r4    k7 ; k7 = 0
.line	976	jmp            0   l42
.line	976	gettabup      r5    u1    k9 ; k9 = "GetCreativeActorData" (truncated)
.line	976	test          r5     1
.line	976	jmp            0   l44
.label	l42
.line	976	loadnil       r5     0
.line	976	return        r5     2
.label	l44
.line	976	gettabup      r5    u1    k9 ; k9 = "GetCreativeActorData" (truncated)
.line	976	call          r5     1     2
.line	976	eq             0    r5    k0 ; k0 = nil
.line	976	jmp            0   l50
.line	976	loadnil       r6     0
.line	976	return        r6     2
.label	l50
.line	976	self          r6    r5   k10 ; k10 = "GetActorCost"
.line	976	move          r8    r4
.line	976	call          r6     3     2
.line	976	gettabup      r7    u1   k11 ; k11 = "type"
.line	976	move          r8    r6
.line	976	call          r7     2     2
.line	976	getupval      r8    u2
.line	976	loadk         r9   k12 ; k12 = 67
.line	976	loadk        r10   k13 ; k13 = 173
.line	976	loadk        r11   k14 ; k14 = 103
.line	976	loadk        r12   k15 ; k15 = 54
.line	976	loadk        r13   k16 ; k16 = 70
.line	976	loadk        r14   k17 ; k17 = 20
.line	976	call          r8     7     2
.line	976	eq             1    r7    r8
.line	976	jmp            0   l68
.line	976	loadnil       r7     0
.line	976	return        r7     2
.label	l68
.line	976	return        r6     2
.line	976	return        r0     1
.line	976	move          r0    r0
.line	976	move          r0    r0
.line	976	move          r0    r0
.line	976	return        r0     1

.function	main/f54

.source	null
.linedefined	1005
.lastlinedefined	1089
.numparams	3
.is_vararg	0
.maxstacksize	14

.upvalue	"_ENV"	0	false
.upvalue	"U1"	6	true
.upvalue	"U2"	3	true
.upvalue	"U3"	17	true
.upvalue	"U4"	9	true

.constant	k0	"slua"
.constant	k1	"isValid"
.constant	k2	"GetInstanceManager"
.constant	k3	"InstacneCostInfoMap"
.constant	k4	nil
.constant	k5	"GetInstanceCostInfo"
.constant	k6	"AssetID"
.constant	k7	-1
.constant	k8	"bIsPrefab"
.constant	k9	false
.constant	k10	"GridIndex"
.constant	k11	"StreamingType"
.constant	k12	"CreativeModeActorStreamingType_Grid"
.constant	k13	"AssetCost"
.constant	k14	"InstanceCost"
.constant	k15	0
.constant	k16	"GetInstance"
.constant	k17	"AssetId"
.constant	k18	"MaterialId"
.constant	k19	"UniqueAssetId"
.constant	k20	"Transform"
.constant	k21	"Location"
.constant	k22	"GetCellIndex"
.constant	k23	"GetObjectStreamingType"
.constant	k24	"GetAssetManager"
.constant	k25	"GetAssetInfo"
.constant	k26	"GetBuildSubSystem"
.constant	k27	"IsGroupAsset"
.constant	k28	"bCanBatch"
.constant	k29	"CheckObjectCanBatchByAssetID"
.constant	k30	"DestructibleMeshParam"
.constant	k31	"EnableDestructibleMesh"
.constant	k32	"bEnableDestructibleMesh"
.constant	k33	"TriCost"
.constant	k34	"DCCost"
.constant	k35	"TryGetDynamicUserActorLiveCost"
.constant	k36	"IsEmpowerAsset"
.constant	k37	"GetEmpowerAssetID"
.constant	k38	"GetAsset"
.constant	k39	"ObbyParam"
.constant	k40	60
.constant	k41	"EmpowerAssetID"
.constant	k42	true
.constant	k43	"CalcDestructibleMeshCost"
.constant	k44	"CustomUIBase"
.constant	k45	"GetCustomUICost"

.line	1005	gettabup      r3    u0    k0 ; k0 = "slua"
.line	1005	gettable      r3    r3    k1 ; k1 = "isValid"
.line	1005	gettabup      r4    u0    k2 ; k2 = "GetInstanceManager"
.line	1005	call          r4     1     0
.line	1005	call          r3     0     2
.line	1005	test          r3     0
.line	1005	jmp            0   l11
.line	1005	gettable      r3    r0    k3 ; k3 = "InstacneCostInfoMap"
.line	1005	eq             0    r3    k4 ; k4 = nil
.line	1005	jmp            0   l13
.label	l11
.line	1005	loadnil       r3     0
.line	1005	return        r3     2
.label	l13
.line	1005	self          r3    r0    k5 ; k5 = "GetInstanceCostInfo"
.line	1005	move          r5    r1
.line	1005	call          r3     3     2
.line	1005	eq             0    r3    k4 ; k4 = nil
.line	1005	jmp            0   l27
.line	1005	newtable      r4     0     6
.line	1005	settable      r4    k6    k7 ; k7 = -1
.line	1005	settable      r4    k8    k9 ; k9 = false
.line	1005	settable      r4   k10    k7 ; k7 = -1
.line	1005	gettabup      r5    u1   k12 ; k12 = "CreativeModeActorStr" (truncated)
.line	1005	settable      r4   k11    r5 ; k11 = "StreamingType"
.line	1005	settable      r4   k13    k4 ; k4 = nil
.line	1005	settable      r4   k14   k15 ; k15 = 0
.line	1005	move          r3    r4
.label	l27
.line	1005	eq             0    r2    k4 ; k4 = nil
.line	1005	jmp            0   l35
.line	1005	gettabup      r4    u0    k2 ; k2 = "GetInstanceManager"
.line	1005	call          r4     1     2
.line	1005	self          r4    r4   k16 ; k16 = "GetInstance"
.line	1005	move          r6    r1
.line	1005	call          r4     3     2
.line	1005	move          r2    r4
.label	l35
.line	1005	test          r2     0
.line	1005	jmp            0  l214
.line	1005	gettable      r4    r2   k17 ; k17 = "AssetId"
.line	1005	settable      r3    k6    r4 ; k6 = "AssetID"
.line	1005	gettable      r4    r2    k8 ; k8 = "bIsPrefab"
.line	1005	settable      r3    k8    r4 ; k8 = "bIsPrefab"
.line	1005	gettable      r4    r2   k18 ; k18 = "MaterialId"
.line	1005	settable      r3   k18    r4 ; k18 = "MaterialId"
.line	1005	settable      r3   k19    k4 ; k4 = nil
.line	1005	gettable      r4    r2   k20 ; k20 = "Transform"
.line	1005	test          r4     0
.line	1005	jmp            0   l56
.line	1005	gettable      r4    r2   k20 ; k20 = "Transform"
.line	1005	gettable      r4    r4   k21 ; k21 = "Location"
.line	1005	test          r4     0
.line	1005	jmp            0   l56
.line	1005	self          r4    r0   k22 ; k22 = "GetCellIndex"
.line	1005	gettable      r6    r2   k20 ; k20 = "Transform"
.line	1005	gettable      r6    r6   k21 ; k21 = "Location"
.line	1005	call          r4     3     2
.line	1005	settable      r3   k10    r4 ; k10 = "GridIndex"
.label	l56
.line	1005	gettabup      r4    u0    k2 ; k2 = "GetInstanceManager"
.line	1005	call          r4     1     2
.line	1005	self          r4    r4   k23 ; k23 = "GetObjectStreamingTy" (truncated)
.line	1005	move          r6    r1
.line	1005	call          r4     3     2
.line	1005	settable      r3   k11    r4 ; k11 = "StreamingType"
.line	1005	gettabup      r4    u0   k24 ; k24 = "GetAssetManager"
.line	1005	call          r4     1     2
.line	1005	self          r4    r4   k25 ; k25 = "GetAssetInfo"
.line	1005	gettable      r6    r2   k17 ; k17 = "AssetId"
.line	1005	call          r4     3     2
.line	1005	test          r4     1
.line	1005	jmp            0   l70
.line	1005	return        r3     2
.label	l70
.line	1005	gettable      r5    r4   k13 ; k13 = "AssetCost"
.line	1005	settable      r3   k13    r5 ; k13 = "AssetCost"
.line	1005	self          r5    r0   k26 ; k26 = "GetBuildSubSystem"
.line	1005	call          r5     2     2
.line	1005	self          r5    r5   k27 ; k27 = "IsGroupAsset"
.line	1005	gettable      r7    r2   k17 ; k17 = "AssetId"
.line	1005	call          r5     3     2
.line	1005	test          r5     0
.line	1005	jmp            0   l80
.line	1005	settable      r3   k13   k15 ; k15 = 0
.label	l80
.line	1005	gettable      r5    r2   k14 ; k14 = "InstanceCost"
.line	1005	settable      r3   k14    r5 ; k14 = "InstanceCost"
.line	1005	gettabup      r5    u2   k29 ; k29 = "CheckObjectCanBatchB" (truncated)
.line	1005	gettable      r6    r3    k6 ; k6 = "AssetID"
.line	1005	call          r5     2     2
.line	1005	settable      r3   k28    r5 ; k28 = "bCanBatch"
.line	1005	gettable      r5    r2   k30 ; k30 = "DestructibleMeshPara" (truncated)
.line	1005	test          r5     0
.line	1005	jmp            0   l96
.line	1005	gettable      r5    r2   k30 ; k30 = "DestructibleMeshPara" (truncated)
.line	1005	gettable      r5    r5   k31 ; k31 = "EnableDestructibleMe" (truncated)
.line	1005	test          r5     0
.line	1005	jmp            0   l96
.line	1005	gettable      r5    r2   k30 ; k30 = "DestructibleMeshPara" (truncated)
.line	1005	gettable      r5    r5   k31 ; k31 = "EnableDestructibleMe" (truncated)
.line	1005	settable      r3   k32    r5 ; k32 = "bEnableDestructibleM" (truncated)
.label	l96
.line	1005	gettable      r5    r4   k33 ; k33 = "TriCost"
.line	1005	test          r5     1
.line	1005	jmp            0  l103
.line	1005	gettable      r5    r4   k13 ; k13 = "AssetCost"
.line	1005	test          r5     1
.line	1005	jmp            0  l103
.line	1005	getupval      r5    u3
.label	l103
.line	1005	gettable      r6    r4   k34 ; k34 = "DCCost"
.line	1005	test          r6     1
.line	1005	jmp            0  l110
.line	1005	gettable      r6    r4   k13 ; k13 = "AssetCost"
.line	1005	test          r6     1
.line	1005	jmp            0  l110
.line	1005	getupval      r6    u3
.label	l110
.line	1005	self          r7    r0   k35 ; k35 = "TryGetDynamicUserAct" (truncated)
.line	1005	move          r9    r4
.line	1005	gettable     r10    r2   k17 ; k17 = "AssetId"
.line	1005	call          r7     4     2
.line	1005	eq             1    r7    k4 ; k4 = nil
.line	1005	jmp            0  l119
.line	1005	move          r5    r7
.line	1005	move          r6    r7
.line	1005	settable      r3   k13    r7 ; k13 = "AssetCost"
.label	l119
.line	1005	loadnil       r8     0
.line	1005	gettabup      r9    u4   k36 ; k36 = "IsEmpowerAsset"
.line	1005	gettable     r10    r4   k17 ; k17 = "AssetId"
.line	1005	call          r9     2     2
.line	1005	test          r9     0
.line	1005	jmp            0  l168
.line	1005	gettabup      r9    u4   k37 ; k37 = "GetEmpowerAssetID"
.line	1005	move         r10    r2
.line	1005	call          r9     2     2
.line	1005	gettabup     r10    u0   k24 ; k24 = "GetAssetManager"
.line	1005	call         r10     1     2
.line	1005	self         r10   r10   k38 ; k38 = "GetAsset"
.line	1005	move         r12    r9
.line	1005	loadbool     r13     1     0
.line	1005	call         r10     4     2
.line	1005	move          r8   r10
.line	1005	gettable     r10    r2   k39 ; k39 = "ObbyParam"
.line	1005	test         r10     0
.line	1005	jmp            0  l148
.line	1005	test          r8     0
.line	1005	jmp            0  l148
.line	1005	gettable     r10    r8   k13 ; k13 = "AssetCost"
.line	1005	test         r10     0
.line	1005	jmp            0  l148
.line	1005	gettable     r10    r8   k13 ; k13 = "AssetCost"
.line	1005	lt             0   k40   r10 ; k40 = 60
.line	1005	jmp            0  l148
.line	1005	gettable      r5    r8   k13 ; k13 = "AssetCost"
.line	1005	gettable      r6    r8   k13 ; k13 = "AssetCost"
.label	l148
.line	1005	test          r8     0
.line	1005	jmp            0  l155
.line	1005	gettable     r10    r2   k30 ; k30 = "DestructibleMeshPara" (truncated)
.line	1005	test         r10     0
.line	1005	jmp            0  l155
.line	1005	gettable      r5    r8   k33 ; k33 = "TriCost"
.line	1005	gettable      r6    r8   k34 ; k34 = "DCCost"
.label	l155
.line	1005	settable      r3   k41    r9 ; k41 = "EmpowerAssetID"
.line	1005	test          r2     0
.line	1005	jmp            0  l167
.line	1005	gettable     r10    r2   k30 ; k30 = "DestructibleMeshPara" (truncated)
.line	1005	test         r10     0
.line	1005	jmp            0  l167
.line	1005	gettable     r10    r2   k30 ; k30 = "DestructibleMeshPara" (truncated)
.line	1005	gettable     r10   r10   k31 ; k31 = "EnableDestructibleMe" (truncated)
.line	1005	test         r10     0
.line	1005	jmp            0  l167
.line	1005	settable      r3   k28   k42 ; k42 = true
.line	1005	jmp            0  l168
.label	l167
.line	1005	settable      r3   k28    k9 ; k9 = false
.label	l168
.line	1005	test          r2     0
.line	1005	jmp            0  l185
.line	1005	gettable      r9    r2   k30 ; k30 = "DestructibleMeshPara" (truncated)
.line	1005	test          r9     0
.line	1005	jmp            0  l185
.line	1005	gettable      r9    r2   k30 ; k30 = "DestructibleMeshPara" (truncated)
.line	1005	gettable      r9    r9   k31 ; k31 = "EnableDestructibleMe" (truncated)
.line	1005	test          r9     0
.line	1005	jmp            0  l185
.line	1005	self          r9    r0   k43 ; k43 = "CalcDestructibleMesh" (truncated)
.line	1005	testset      r11    r8     1
.line	1005	jmp            0  l181
.line	1005	move         r11    r4
.label	l181
.line	1005	move         r12    r2
.line	1005	call          r9     4     3
.line	1005	move          r6   r10
.line	1005	move          r5    r9
.label	l185
.line	1005	testset       r9    r5     1
.line	1005	jmp            0  l188
.line	1005	getupval      r9    u3
.label	l188
.line	1005	settable      r3   k33    r9 ; k33 = "TriCost"
.line	1005	testset       r9    r6     1
.line	1005	jmp            0  l192
.line	1005	getupval      r9    u3
.label	l192
.line	1005	settable      r3   k34    r9 ; k34 = "DCCost"
.line	1005	gettable      r9    r2   k44 ; k44 = "CustomUIBase"
.line	1005	test          r9     0
.line	1005	jmp            0  l203
.line	1005	gettabup      r9    u0    k2 ; k2 = "GetInstanceManager"
.line	1005	call          r9     1     2
.line	1005	self          r9    r9   k45 ; k45 = "GetCustomUICost"
.line	1005	move         r11    r2
.line	1005	call          r9     3     2
.line	1005	settable      r3   k33    r9 ; k33 = "TriCost"
.line	1005	settable      r3   k34    r9 ; k34 = "DCCost"
.label	l203
.line	1005	gettable      r9    r3   k41 ; k41 = "EmpowerAssetID"
.line	1005	test          r9     1
.line	1005	jmp            0  l207
.line	1005	gettable      r9    r3    k6 ; k6 = "AssetID"
.label	l207
.line	1005	test          r9     0
.line	1005	jmp            0  l214
.line	1005	self         r10    r0   k19 ; k19 = "UniqueAssetId"
.line	1005	move         r12    r9
.line	1005	gettable     r13    r3   k18 ; k18 = "MaterialId"
.line	1005	call         r10     4     2
.line	1005	settable      r3   k19   r10 ; k19 = "UniqueAssetId"
.label	l214
.line	1005	gettable      r4    r0    k3 ; k3 = "InstacneCostInfoMap"
.line	1005	settable      r4    r1    r3
.line	1005	return        r3     2
.line	1005	return        r0     1
.line	1005	move          r0    r0
.line	1005	return        r0     1

.function	main/f55

.source	null
.linedefined	1091
.lastlinedefined	1098
.numparams	2
.is_vararg	0
.maxstacksize	4

.constant	k0	"InstacneCostInfoMap"
.constant	k1	nil

.line	1091	gettable      r2    r0    k0 ; k0 = "InstacneCostInfoMap"
.line	1091	eq             1    r2    k1 ; k1 = nil
.line	1091	jmp            0   l13
.line	1091	gettable      r2    r0    k0 ; k0 = "InstacneCostInfoMap"
.line	1091	gettable      r2    r2    r1
.line	1091	test          r2     0
.line	1091	jmp            0   l13
.line	1091	gettable      r2    r0    k0 ; k0 = "InstacneCostInfoMap"
.line	1091	gettable      r2    r2    r1
.line	1091	gettable      r3    r0    k0 ; k0 = "InstacneCostInfoMap"
.line	1091	settable      r3    r1    k1 ; k1 = nil
.line	1091	return        r2     2
.label	l13
.line	1091	loadnil       r2     0
.line	1091	return        r2     2
.line	1091	return        r0     1
.line	1091	move          r0    r0
.line	1091	move          r0    r0
.line	1091	move          r0    r0
.line	1091	move          r0    r0
.line	1091	return        r0     1

.function	main/f56

.source	null
.linedefined	1100
.lastlinedefined	1118
.numparams	3
.is_vararg	0
.maxstacksize	13

.upvalue	"_ENV"	17	true

.constant	k0	"InstacneCostInfoMap"
.constant	k1	"bIsPrefab"
.constant	k2	0
.constant	k3	"IsInstanceNoNeed"
.constant	k4	"GridIndex"
.constant	k5	"GetDeltaCostByAssetId"
.constant	k6	"AssetID"
.constant	k7	"MaterialId"

.line	1100	gettable      r3    r0    k0 ; k0 = "InstacneCostInfoMap"
.line	1100	test          r3     1
.line	1100	jmp            0    l7
.line	1100	getupval      r3    u0
.line	1100	getupval      r4    u0
.line	1100	return        r3     3
.label	l7
.line	1100	getupval      r3    u0
.line	1100	getupval      r4    u0
.line	1100	test          r2     1
.line	1100	jmp            0   l13
.line	1100	gettable      r5    r0    k0 ; k0 = "InstacneCostInfoMap"
.line	1100	gettable      r2    r5    r1
.label	l13
.line	1100	test          r2     0
.line	1100	jmp            0   l39
.line	1100	gettable      r5    r2    k1 ; k1 = "bIsPrefab"
.line	1100	test          r5     0
.line	1100	jmp            0   l21
.line	1100	loadk         r5    k2 ; k2 = 0
.line	1100	loadk         r6    k2 ; k2 = 0
.line	1100	return        r5     3
.label	l21
.line	1100	self          r5    r0    k3 ; k3 = "IsInstanceNoNeed"
.line	1100	move          r7    r1
.line	1100	call          r5     3     2
.line	1100	test          r5     0
.line	1100	jmp            0   l29
.line	1100	loadk         r5    k2 ; k2 = 0
.line	1100	loadk         r6    k2 ; k2 = 0
.line	1100	return        r5     3
.label	l29
.line	1100	gettable      r5    r2    k4 ; k4 = "GridIndex"
.line	1100	self          r6    r0    k5 ; k5 = "GetDeltaCostByAssetI" (truncated)
.line	1100	move          r8    r5
.line	1100	gettable      r9    r2    k6 ; k6 = "AssetID"
.line	1100	move         r10    r1
.line	1100	loadbool     r11     0     0
.line	1100	gettable     r12    r2    k7 ; k7 = "MaterialId"
.line	1100	call          r6     7     3
.line	1100	move          r4    r7
.line	1100	move          r3    r6
.label	l39
.line	1100	move          r5    r3
.line	1100	move          r6    r4
.line	1100	return        r5     3
.line	1100	return        r0     1
.line	1100	move          r0    r0
.line	1100	return        r0     1

.function	main/f57

.source	null
.linedefined	1120
.lastlinedefined	1123
.numparams	1
.is_vararg	0
.maxstacksize	5

.constant	k0	"AllCellAssetCostCheck"
.constant	k1	"_CacheMaximumCost"

.line	1120	self          r1    r0    k0 ; k0 = "AllCellAssetCostChec" (truncated)
.line	1120	call          r1     2     5
.line	1120	settable      r0    k1    r2 ; k1 = "_CacheMaximumCost"
.line	1120	return        r0     1
.line	1120	move          r0    r0
.line	1120	move          r0    r0
.line	1120	return        r0     1

.function	main/f58

.source	null
.linedefined	1125
.lastlinedefined	1134
.numparams	1
.is_vararg	0
.maxstacksize	25

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"CGameState"
.constant	k1	"GetCurrentGameType"
.constant	k2	"import"
.constant	k3	104
.constant	k4	155
.constant	k5	120
.constant	k6	49
.constant	k7	66
.constant	k8	18
.constant	k9	135
.constant	k10	182
.constant	k11	36
.constant	k12	20
.constant	k13	3
.constant	k14	37
.constant	k15	47
.constant	k16	153
.constant	k17	226
.constant	k18	184
.constant	k19	188
.constant	k20	"CreativeModeGameType_Game"
.constant	k21	"_CacheMaximumCost"
.constant	k22	"AllCellAssetCostCheck"

.line	1125	gettabup      r1    u0    k0 ; k0 = "CGameState"
.line	1125	self          r1    r1    k1 ; k1 = "GetCurrentGameType"
.line	1125	call          r1     2     2
.line	1125	gettabup      r2    u0    k2 ; k2 = "import"
.line	1125	getupval      r3    u1
.line	1125	loadk         r4    k3 ; k3 = 104
.line	1125	loadk         r5    k4 ; k4 = 155
.line	1125	loadk         r6    k5 ; k5 = 120
.line	1125	loadk         r7    k6 ; k6 = 49
.line	1125	loadk         r8    k7 ; k7 = 66
.line	1125	loadk         r9    k8 ; k8 = 18
.line	1125	loadk        r10    k9 ; k9 = 135
.line	1125	loadk        r11   k10 ; k10 = 182
.line	1125	loadk        r12   k11 ; k11 = 36
.line	1125	loadk        r13   k12 ; k12 = 20
.line	1125	loadk        r14   k13 ; k13 = 3
.line	1125	loadk        r15   k14 ; k14 = 37
.line	1125	loadk        r16   k15 ; k15 = 47
.line	1125	loadk        r17   k13 ; k13 = 3
.line	1125	loadk        r18   k16 ; k16 = 153
.line	1125	loadk        r19   k17 ; k17 = 226
.line	1125	loadk        r20   k18 ; k18 = 184
.line	1125	loadk        r21   k19 ; k19 = 188
.line	1125	loadk        r22   k13 ; k13 = 3
.line	1125	loadk        r23   k12 ; k12 = 20
.line	1125	loadk        r24   k10 ; k10 = 182
.line	1125	call          r3    22     2
.line	1125	call          r2     2     2
.line	1125	gettable      r3    r2   k20 ; k20 = "CreativeModeGameType" (truncated)
.line	1125	eq             0    r1    r3
.line	1125	jmp            0   l35
.line	1125	gettable      r3    r0   k21 ; k21 = "_CacheMaximumCost"
.line	1125	return        r3     2
.line	1125	jmp            0   l41
.label	l35
.line	1125	self          r3    r0   k22 ; k22 = "AllCellAssetCostChec" (truncated)
.line	1125	call          r3     2     5
.line	1125	move          r7    r4
.line	1125	move          r8    r5
.line	1125	move          r9    r6
.line	1125	return        r7     4
.label	l41
.line	1125	return        r0     1
.line	1125	move          r0    r0
.line	1125	move          r0    r0
.line	1125	move          r0    r0
.line	1125	move          r0    r0
.line	1125	return        r0     1

.function	main/f59

.source	null
.linedefined	1136
.lastlinedefined	1156
.numparams	1
.is_vararg	0
.maxstacksize	16

.upvalue	"_ENV"	35	true

.constant	k0	0
.constant	k1	"MapCellCount"
.constant	k2	1
.constant	k3	"GetGridAssetCostByIndex"
.constant	k4	"max"
.constant	k5	"GetCurAssetCostMax"
.constant	k6	true

.line	1136	loadk         r1    k0 ; k0 = 0
.line	1136	loadk         r2    k0 ; k0 = 0
.line	1136	loadk         r3    k0 ; k0 = 0
.line	1136	gettable      r4    r0    k1 ; k1 = "MapCellCount"
.line	1136	test          r4     0
.line	1136	jmp            0   l40
.line	1136	loadk         r4    k0 ; k0 = 0
.line	1136	gettable      r5    r0    k1 ; k1 = "MapCellCount"
.line	1136	gettable      r6    r0    k1 ; k1 = "MapCellCount"
.line	1136	mul           r5    r5    r6
.line	1136	sub           r5    r5    k2 ; k2 = 1
.line	1136	loadk         r6    k2 ; k2 = 1
.line	1136	move          r0    r0
.line	1136	self          r8    r0    k3 ; k3 = "GetGridAssetCostByIn" (truncated)
.line	1136	move         r10    r7
.line	1136	call          r8     3     3
.line	1136	gettabup     r10    u0    k4 ; k4 = "max"
.line	1136	move         r11    r8
.line	1136	move         r12    r9
.line	1136	call         r10     3     2
.line	1136	lt             0    r1   r10
.line	1136	jmp            0   l26
.line	1136	move          r1   r10
.line	1136	move          r2    r8
.line	1136	move          r3    r9
.label	l26
.line	1136	self         r11    r0    k5 ; k5 = "GetCurAssetCostMax"
.line	1136	call         r11     2     2
.line	1136	lt             1   r11   r10
.line	1136	jmp            0   l31
.line	1136	loadbool     r11     0     1
.label	l31
.line	1136	loadbool     r11     1     0
.line	1136	eq             0   r11    k6 ; k6 = true
.line	1136	jmp            0   l39
.line	1136	loadbool     r12     0     0
.line	1136	move         r13    r1
.line	1136	move         r14    r2
.line	1136	move         r15    r3
.line	1136	return       r12     5
.label	l39
.line	1136	move          r0    r0
.label	l40
.line	1136	loadbool      r4     1     0
.line	1136	move          r5    r1
.line	1136	move          r6    r2
.line	1136	move          r7    r3
.line	1136	return        r4     5
.line	1136	return        r0     1
.line	1136	move          r0    r0
.line	1136	return        r0     1

.function	main/f60

.source	null
.linedefined	1158
.lastlinedefined	1184
.numparams	3
.is_vararg	0
.maxstacksize	38

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	0
.constant	k1	nil
.constant	k2	"GetInstanceManager"
.constant	k3	"GetInstance"
.constant	k4	"ObjectGroup"
.constant	k5	"Children"
.constant	k6	"overrides"
.constant	k7	"AssetId"
.constant	k8	"GetAssetManager"
.constant	k9	"GetDefaultUIGroupAssetId"
.constant	k10	"pairs"
.constant	k11	"Transform"
.constant	k12	"Location"
.constant	k13	"GetCellIndex"
.constant	k14	1
.constant	k15	"print"
.constant	k16	"bWriteLog"
.constant	k17	106
.constant	k18	189
.constant	k19	126
.constant	k20	21
.constant	k21	69
.constant	k22	139
.constant	k23	163
.constant	k24	53
.constant	k25	60
.constant	k26	8
.constant	k27	6
.constant	k28	56
.constant	k29	45
.constant	k30	156
.constant	k31	181
.constant	k32	253
.constant	k33	129
.constant	k34	20
.constant	k35	23
.constant	k36	167
.constant	k37	55
.constant	k38	240
.constant	k39	147
.constant	k40	52
.constant	k41	24
.constant	k42	113
.constant	k43	103
.constant	k44	116
.constant	k45	"tostring"
.constant	k46	13
.constant	k47	153
.constant	k48	108
.constant	k49	50
.constant	k50	70
.constant	k51	5
.constant	k52	154
.constant	k53	165
.constant	k54	37
.constant	k55	30
.constant	k56	40
.constant	k57	46
.constant	k58	7
.constant	k59	151
.constant	k60	250
.constant	k61	179
.constant	k62	90
.constant	k63	89
.constant	k64	243

.line	1158	newtable      r3     0     0
.line	1158	newtable      r4     0     0
.line	1158	loadk         r5    k0 ; k0 = 0
.line	1158	eq             0    r2    k1 ; k1 = nil
.line	1158	jmp            0   l12
.line	1158	self          r6    r0    k2 ; k2 = "GetInstanceManager"
.line	1158	call          r6     2     2
.line	1158	self          r6    r6    k3 ; k3 = "GetInstance"
.line	1158	move          r8    r1
.line	1158	call          r6     3     2
.line	1158	move          r2    r6
.label	l12
.line	1158	test          r2     0
.line	1158	jmp            0   l71
.line	1158	gettable      r6    r2    k4 ; k4 = "ObjectGroup"
.line	1158	test          r6     0
.line	1158	jmp            0   l71
.line	1158	gettable      r6    r2    k4 ; k4 = "ObjectGroup"
.line	1158	gettable      r6    r6    k5 ; k5 = "Children"
.line	1158	test          r6     0
.line	1158	jmp            0   l71
.line	1158	gettable      r6    r2    k4 ; k4 = "ObjectGroup"
.line	1158	gettable      r6    r6    k5 ; k5 = "Children"
.line	1158	gettable      r6    r6    k6 ; k6 = "overrides"
.line	1158	test          r6     0
.line	1158	jmp            0   l71
.line	1158	gettable      r6    r2    k7 ; k7 = "AssetId"
.line	1158	self          r7    r0    k8 ; k8 = "GetAssetManager"
.line	1158	call          r7     2     2
.line	1158	self          r7    r7    k9 ; k9 = "GetDefaultUIGroupAss" (truncated)
.line	1158	call          r7     2     2
.line	1158	eq             1    r6    r7
.line	1158	jmp            0   l71
.line	1158	gettable      r6    r2    k4 ; k4 = "ObjectGroup"
.line	1158	gettable      r6    r6    k5 ; k5 = "Children"
.line	1158	gettable      r3    r6    k6 ; k6 = "overrides"
.line	1158	gettabup      r6    u0   k10 ; k10 = "pairs"
.line	1158	move          r7    r3
.line	1158	call          r6     2     4
.line	1158	jmp            0   l69
.line	1158	self         r11    r0    k2 ; k2 = "GetInstanceManager"
.line	1158	call         r11     2     2
.line	1158	self         r11   r11    k3 ; k3 = "GetInstance"
.line	1158	move         r13   r10
.line	1158	call         r11     3     2
.line	1158	test         r11     0
.line	1158	jmp            0   l69
.line	1158	gettable     r12   r11   k11 ; k11 = "Transform"
.line	1158	test         r12     0
.line	1158	jmp            0   l69
.line	1158	gettable     r12   r11   k11 ; k11 = "Transform"
.line	1158	gettable     r12   r12   k12 ; k12 = "Location"
.line	1158	test         r12     0
.line	1158	jmp            0   l69
.line	1158	self         r12    r0   k13 ; k13 = "GetCellIndex"
.line	1158	gettable     r14   r11   k11 ; k11 = "Transform"
.line	1158	gettable     r14   r14   k12 ; k12 = "Location"
.line	1158	call         r12     3     2
.line	1158	test         r12     0
.line	1158	jmp            0   l66
.line	1158	gettable     r13    r4   r12
.line	1158	eq             0   r13    k1 ; k1 = nil
.line	1158	jmp            0   l66
.line	1158	settable      r4   r12   k14 ; k14 = 1
.line	1158	add           r5    r5   k14 ; k14 = 1
.line	1158	jmp            0   l69
.label	l66
.line	1158	gettable     r13    r4   r12
.line	1158	add          r13   r13   k14 ; k14 = 1
.line	1158	settable      r4   r12   r13
.label	l69
.line	1158	move          r0    r0
.line	1158	move          r0    r0
.label	l71
.line	1158	lt             0   k14    r5 ; k14 = 1
.line	1158	jmp            0  l140
.line	1158	gettabup      r6    u0   k15 ; k15 = "print"
.line	1158	gettabup      r7    u0   k16 ; k16 = "bWriteLog"
.line	1158	test          r7     0
.line	1158	jmp            0  l139
.line	1158	getupval      r7    u1
.line	1158	loadk         r8   k17 ; k17 = 106
.line	1158	loadk         r9   k18 ; k18 = 189
.line	1158	loadk        r10   k19 ; k19 = 126
.line	1158	loadk        r11   k20 ; k20 = 21
.line	1158	loadk        r12   k21 ; k21 = 69
.line	1158	loadk        r13    k0 ; k0 = 0
.line	1158	loadk        r14   k22 ; k22 = 139
.line	1158	loadk        r15   k23 ; k23 = 163
.line	1158	loadk        r16   k24 ; k24 = 53
.line	1158	loadk        r17   k25 ; k25 = 60
.line	1158	loadk        r18   k26 ; k26 = 8
.line	1158	loadk        r19   k27 ; k27 = 6
.line	1158	loadk        r20   k28 ; k28 = 56
.line	1158	loadk        r21   k29 ; k29 = 45
.line	1158	loadk        r22   k30 ; k30 = 156
.line	1158	loadk        r23   k31 ; k31 = 181
.line	1158	loadk        r24   k32 ; k32 = 253
.line	1158	loadk        r25   k33 ; k33 = 129
.line	1158	loadk        r26   k34 ; k34 = 20
.line	1158	loadk        r27   k35 ; k35 = 23
.line	1158	loadk        r28   k36 ; k36 = 167
.line	1158	loadk        r29   k37 ; k37 = 55
.line	1158	loadk        r30   k38 ; k38 = 240
.line	1158	loadk        r31   k39 ; k39 = 147
.line	1158	loadk        r32   k40 ; k40 = 52
.line	1158	loadk        r33    k0 ; k0 = 0
.line	1158	loadk        r34   k41 ; k41 = 24
.line	1158	loadk        r35   k42 ; k42 = 113
.line	1158	loadk        r36   k43 ; k43 = 103
.line	1158	loadk        r37   k44 ; k44 = 116
.line	1158	call          r7    31     2
.line	1158	gettabup      r8    u0   k45 ; k45 = "tostring"
.line	1158	move          r9    r1
.line	1158	call          r8     2     2
.line	1158	getupval      r9    u1
.line	1158	loadk        r10   k46 ; k46 = 13
.line	1158	loadk        r11   k47 ; k47 = 153
.line	1158	loadk        r12   k48 ; k48 = 108
.line	1158	loadk        r13   k49 ; k49 = 50
.line	1158	loadk        r14   k50 ; k50 = 70
.line	1158	loadk        r15   k51 ; k51 = 5
.line	1158	loadk        r16   k52 ; k52 = 154
.line	1158	loadk        r17   k53 ; k53 = 165
.line	1158	loadk        r18   k54 ; k54 = 37
.line	1158	loadk        r19   k55 ; k55 = 30
.line	1158	loadk        r20   k55 ; k55 = 30
.line	1158	loadk        r21   k56 ; k56 = 40
.line	1158	loadk        r22   k57 ; k57 = 46
.line	1158	loadk        r23   k58 ; k58 = 7
.line	1158	loadk        r24   k59 ; k59 = 151
.line	1158	loadk        r25   k60 ; k60 = 250
.line	1158	loadk        r26   k61 ; k61 = 179
.line	1158	loadk        r27   k30 ; k30 = 156
.line	1158	loadk        r28   k62 ; k62 = 90
.line	1158	loadk        r29   k63 ; k63 = 89
.line	1158	loadk        r30   k64 ; k64 = 243
.line	1158	call          r9    22     2
.line	1158	gettabup     r10    u0   k45 ; k45 = "tostring"
.line	1158	move         r11    r5
.line	1158	call         r10     2     2
.line	1158	concat        r7    r7   r10
.label	l139
.line	1158	call          r6     2     1
.label	l140
.line	1158	move          r6    r4
.line	1158	move          r7    r5
.line	1158	return        r6     3
.line	1158	return        r0     1
.line	1158	move          r0    r0
.line	1158	return        r0     1

.function	main/f61

.source	null
.linedefined	1186
.lastlinedefined	1264
.numparams	2
.is_vararg	0
.maxstacksize	33

.upvalue	"_ENV"	0	false
.upvalue	"U1"	6	true
.upvalue	"U2"	19	true

.constant	k0	"GetCurBuildingLocationAndAssetID"
.constant	k1	0
.constant	k2	nil
.constant	k3	"GetCellIndex"
.constant	k4	"GetGridAssetCostByIndex"
.constant	k5	"slua"
.constant	k6	"isValid"
.constant	k7	"GetAssetManager"
.constant	k8	false
.constant	k9	"IsGroupAsset"
.constant	k10	"GetInstanceManager"
.constant	k11	"GetInstance"
.constant	k12	"GetAffectedGrid"
.constant	k13	1
.constant	k14	"IsPixelGroupAsset"
.constant	k15	"GetPixelAssetDelatCostInAffectedGrid"
.constant	k16	"GetDeltaCostByAssetId"
.constant	k17	"pairs"
.constant	k18	"PlaceAssetCostCheck"
.constant	k19	2
.constant	k20	"GetMaximumCost"
.constant	k21	"GetObjectStreamingType"
.constant	k22	L"CreativeModeActorStreamingType_AlwaysLoad"
.constant	k23	"GetNearCellIndexList"
.constant	k24	"ipairs"

.line	1186	self          r2    r0    k0 ; k0 = "GetCurBuildingLocati" (truncated)
.line	1186	move          r4    r1
.line	1186	call          r2     3     4
.line	1186	loadk         r5    k1 ; k1 = 0
.line	1186	loadk         r6    k1 ; k1 = 0
.line	1186	loadk         r7    k1 ; k1 = 0
.line	1186	loadk         r8    k1 ; k1 = 0
.line	1186	loadnil       r9     3
.line	1186	loadk        r13    k1 ; k1 = 0
.line	1186	eq             1    r2    k2 ; k2 = nil
.line	1186	jmp            0   l21
.line	1186	self         r14    r0    k3 ; k3 = "GetCellIndex"
.line	1186	move         r16    r2
.line	1186	call         r14     3     2
.line	1186	move         r11   r14
.line	1186	self         r14    r0    k4 ; k4 = "GetGridAssetCostByIn" (truncated)
.line	1186	move         r16   r11
.line	1186	call         r14     3     3
.line	1186	move          r6   r15
.line	1186	move          r5   r14
.label	l21
.line	1186	eq             1    r3    k2 ; k2 = nil
.line	1186	jmp            0  l112
.line	1186	gettabup     r14    u0    k5 ; k5 = "slua"
.line	1186	gettable     r14   r14    k6 ; k6 = "isValid"
.line	1186	self         r15    r0    k7 ; k7 = "GetAssetManager"
.line	1186	call         r15     2     0
.line	1186	call         r14     0     2
.line	1186	eq             0   r14    k8 ; k8 = false
.line	1186	jmp            0   l33
.line	1186	loadbool     r14     0     0
.line	1186	loadbool     r15     0     0
.line	1186	return       r14     3
.label	l33
.line	1186	self         r14    r0    k7 ; k7 = "GetAssetManager"
.line	1186	call         r14     2     2
.line	1186	self         r14   r14    k9 ; k9 = "IsGroupAsset"
.line	1186	move         r16    r3
.line	1186	loadbool     r17     1     0
.line	1186	call         r14     4     2
.line	1186	test         r14     0
.line	1186	jmp            0  l102
.line	1186	self         r15    r0   k10 ; k10 = "GetInstanceManager"
.line	1186	call         r15     2     2
.line	1186	self         r15   r15   k11 ; k11 = "GetInstance"
.line	1186	move         r17    r4
.line	1186	call         r15     3     2
.line	1186	self         r16    r0   k12 ; k12 = "GetAffectedGrid"
.line	1186	move         r18    r4
.line	1186	move         r19   r15
.line	1186	call         r16     4     3
.line	1186	move         r13   r17
.line	1186	move         r12   r16
.line	1186	lt             0   k13   r13 ; k13 = 1
.line	1186	jmp            0   l69
.line	1186	self         r16    r0    k7 ; k7 = "GetAssetManager"
.line	1186	call         r16     2     2
.line	1186	self         r16   r16   k14 ; k14 = "IsPixelGroupAsset"
.line	1186	move         r18    r3
.line	1186	call         r16     3     2
.line	1186	test         r16     0
.line	1186	jmp            0   l69
.line	1186	self         r16    r0   k15 ; k15 = "GetPixelAssetDelatCo" (truncated)
.line	1186	move         r18    r3
.line	1186	move         r19    r4
.line	1186	move         r20   r12
.line	1186	call         r16     5     3
.line	1186	move          r8   r17
.line	1186	move          r7   r16
.line	1186	jmp            0   l79
.label	l69
.line	1186	self         r16    r0   k16 ; k16 = "GetDeltaCostByAssetI" (truncated)
.line	1186	move         r18   r11
.line	1186	move         r19    r3
.line	1186	move         r20    r4
.line	1186	loadbool     r21     1     0
.line	1186	call         r16     6     5
.line	1186	move         r10   r19
.line	1186	move          r9   r18
.line	1186	move          r8   r17
.line	1186	move          r7   r16
.label	l79
.line	1186	move         r16    r7
.line	1186	move         r17    r8
.line	1186	gettabup     r18    u0   k17 ; k17 = "pairs"
.line	1186	move         r19   r12
.line	1186	call         r18     2     4
.line	1186	jmp            0   l97
.line	1186	self         r23    r0   k16 ; k16 = "GetDeltaCostByAssetI" (truncated)
.line	1186	move         r25   r21
.line	1186	move         r26    r3
.line	1186	move         r27    r4
.line	1186	loadbool     r28     1     0
.line	1186	call         r23     6     3
.line	1186	lt             0   r16   r23
.line	1186	jmp            0   l94
.line	1186	move         r16   r23
.label	l94
.line	1186	lt             0   r17   r24
.line	1186	jmp            0   l97
.line	1186	move         r17   r24
.label	l97
.line	1186	move          r0    r0
.line	1186	move          r0    r0
.line	1186	move          r7   r16
.line	1186	move          r8   r17
.line	1186	jmp            0  l112
.label	l102
.line	1186	self         r15    r0   k16 ; k16 = "GetDeltaCostByAssetI" (truncated)
.line	1186	move         r17   r11
.line	1186	move         r18    r3
.line	1186	move         r19    r4
.line	1186	loadbool     r20     1     0
.line	1186	call         r15     6     5
.line	1186	move         r10   r18
.line	1186	move          r9   r17
.line	1186	move          r8   r16
.line	1186	move          r7   r15
.label	l112
.line	1186	self         r14    r0   k18 ; k18 = "PlaceAssetCostCheck"
.line	1186	move         r16    r5
.line	1186	move         r17    r7
.line	1186	move         r18    r6
.line	1186	move         r19    r8
.line	1186	call         r14     6     2
.line	1186	test         r14     1
.line	1186	jmp            0  l123
.line	1186	loadbool     r15     0     0
.line	1186	loadbool     r16     1     0
.line	1186	return       r15     3
.label	l123
.line	1186	loadbool     r15     0     0
.line	1186	test          r3     0
.line	1186	jmp            0  l163
.line	1186	self         r16    r0    k7 ; k7 = "GetAssetManager"
.line	1186	call         r16     2     2
.line	1186	self         r16   r16    k9 ; k9 = "IsGroupAsset"
.line	1186	move         r18    r3
.line	1186	loadbool     r19     1     0
.line	1186	call         r16     4     2
.line	1186	test         r16     0
.line	1186	jmp            0  l163
.line	1186	test         r10     0
.line	1186	jmp            0  l163
.line	1186	gettable     r16   r10   k13 ; k13 = 1
.line	1186	test         r16     1
.line	1186	jmp            0  l140
.line	1186	loadk        r16    k1 ; k1 = 0
.label	l140
.line	1186	gettable     r17   r10   k19 ; k19 = 2
.line	1186	test         r17     1
.line	1186	jmp            0  l144
.line	1186	loadk        r17    k1 ; k1 = 0
.label	l144
.line	1186	lt             1    k1   r16 ; k1 = 0
.line	1186	jmp            0  l148
.line	1186	lt             0    k1   r17 ; k1 = 0
.line	1186	jmp            0  l188
.label	l148
.line	1186	self         r18    r0   k20 ; k20 = "GetMaximumCost"
.line	1186	call         r18     2     4
.line	1186	self         r21    r0   k18 ; k18 = "PlaceAssetCostCheck"
.line	1186	move         r23   r19
.line	1186	move         r24   r16
.line	1186	move         r25   r20
.line	1186	move         r26   r17
.line	1186	call         r21     6     2
.line	1186	move         r14   r21
.line	1186	test         r14     1
.line	1186	jmp            0  l188
.line	1186	loadbool     r21     0     0
.line	1186	loadbool     r22     0     0
.line	1186	return       r21     3
.line	1186	jmp            0  l188
.label	l163
.line	1186	test          r4     0
.line	1186	jmp            0  l188
.line	1186	self         r16    r0   k10 ; k10 = "GetInstanceManager"
.line	1186	call         r16     2     2
.line	1186	self         r16   r16   k21 ; k21 = "GetObjectStreamingTy" (truncated)
.line	1186	move         r18    r4
.line	1186	call         r16     3     2
.line	1186	gettabup     r17    u1   k22 ; k22 = L"CreativeModeActorStr" (truncated)
.line	1186	eq             0   r16   r17
.line	1186	jmp            0  l188
.line	1186	loadbool     r15     1     0
.line	1186	self         r17    r0   k20 ; k20 = "GetMaximumCost"
.line	1186	call         r17     2     4
.line	1186	self         r20    r0   k18 ; k18 = "PlaceAssetCostCheck"
.line	1186	move         r22   r18
.line	1186	move         r23    r7
.line	1186	move         r24   r19
.line	1186	move         r25    r8
.line	1186	call         r20     6     2
.line	1186	move         r14   r20
.line	1186	test         r14     1
.line	1186	jmp            0  l188
.line	1186	loadbool     r20     0     0
.line	1186	loadbool     r21     0     0
.line	1186	return       r20     3
.label	l188
.line	1186	test         r15     1
.line	1186	jmp            0  l221
.line	1186	self         r16    r0    k3 ; k3 = "GetCellIndex"
.line	1186	move         r18    r2
.line	1186	call         r16     3     2
.line	1186	getupval     r17    u2
.line	1186	mul          r17    r7   r17
.line	1186	getupval     r18    u2
.line	1186	mul          r18    r8   r18
.line	1186	self         r19    r0   k23 ; k23 = "GetNearCellIndexList"
.line	1186	move         r21   r16
.line	1186	call         r19     3     2
.line	1186	gettabup     r20    u0   k24 ; k24 = "ipairs"
.line	1186	move         r21   r19
.line	1186	call         r20     2     4
.line	1186	jmp            0  l219
.line	1186	self         r25    r0    k4 ; k4 = "GetGridAssetCostByIn" (truncated)
.line	1186	move         r27   r24
.line	1186	call         r25     3     3
.line	1186	self         r27    r0   k18 ; k18 = "PlaceAssetCostCheck"
.line	1186	move         r29   r25
.line	1186	move         r30   r17
.line	1186	move         r31   r26
.line	1186	move         r32   r18
.line	1186	call         r27     6     2
.line	1186	move         r14   r27
.line	1186	test         r14     1
.line	1186	jmp            0  l219
.line	1186	loadbool     r27     0     0
.line	1186	loadbool     r28     0     0
.line	1186	return       r27     3
.label	l219
.line	1186	move          r0    r0
.line	1186	move          r0    r0
.label	l221
.line	1186	loadbool     r16     1     0
.line	1186	loadbool     r17     1     0
.line	1186	return       r16     3
.line	1186	return        r0     1
.line	1186	move          r0    r0
.line	1186	move          r0    r0
.line	1186	move          r0    r0
.line	1186	move          r0    r0
.line	1186	return        r0     1

.function	main/f62

.source	null
.linedefined	1266
.lastlinedefined	1315
.numparams	3
.is_vararg	0
.maxstacksize	29

.upvalue	"_ENV"	6	true
.upvalue	"U1"	19	true
.upvalue	"U2"	0	false

.constant	k0	"GetInstanceManager"
.constant	k1	"GetInstance"
.constant	k2	"Transform"
.constant	k3	"Location"
.constant	k4	"AssetId"
.constant	k5	0
.constant	k6	nil
.constant	k7	"GetGridAssetCost"
.constant	k8	"GetCellIndex"
.constant	k9	"GetDeltaCostByAssetId"
.constant	k10	"PlaceAssetCostCheck"
.constant	k11	"GetObjectStreamingType"
.constant	k12	L"CreativeModeActorStreamingType_AlwaysLoad"
.constant	k13	"GetMaximumCost"
.constant	k14	"GetNearCellIndexList"
.constant	k15	"ipairs"
.constant	k16	"GetGridAssetCostByIndex"

.line	1266	self          r3    r0    k0 ; k0 = "GetInstanceManager"
.line	1266	call          r3     2     2
.line	1266	self          r3    r3    k1 ; k1 = "GetInstance"
.line	1266	move          r5    r1
.line	1266	call          r3     3     2
.line	1266	test          r3     1
.line	1266	jmp            0    l9
.line	1266	return        r0     1
.label	l9
.line	1266	loadnil       r4     0
.line	1266	gettable      r5    r3    k2 ; k2 = "Transform"
.line	1266	test          r5     0
.line	1266	jmp            0   l15
.line	1266	gettable      r5    r3    k2 ; k2 = "Transform"
.line	1266	gettable      r4    r5    k3 ; k3 = "Location"
.label	l15
.line	1266	gettable      r5    r3    k4 ; k4 = "AssetId"
.line	1266	loadk         r6    k5 ; k5 = 0
.line	1266	loadk         r7    k5 ; k5 = 0
.line	1266	loadk         r8    k5 ; k5 = 0
.line	1266	loadk         r9    k5 ; k5 = 0
.line	1266	eq             1    r4    k6 ; k6 = nil
.line	1266	jmp            0   l27
.line	1266	self         r10    r0    k7 ; k7 = "GetGridAssetCost"
.line	1266	move         r12    r4
.line	1266	call         r10     3     3
.line	1266	move          r7   r11
.line	1266	move          r6   r10
.label	l27
.line	1266	eq             1    r5    k6 ; k6 = nil
.line	1266	jmp            0   l41
.line	1266	self         r10    r0    k8 ; k8 = "GetCellIndex"
.line	1266	move         r12    r4
.line	1266	call         r10     3     2
.line	1266	self         r11    r0    k9 ; k9 = "GetDeltaCostByAssetI" (truncated)
.line	1266	move         r13   r10
.line	1266	move         r14    r5
.line	1266	move         r15    r1
.line	1266	loadbool     r16     0     0
.line	1266	move         r17    r2
.line	1266	call         r11     7     3
.line	1266	move          r9   r12
.line	1266	move          r8   r11
.label	l41
.line	1266	self         r10    r0   k10 ; k10 = "PlaceAssetCostCheck"
.line	1266	move         r12    r6
.line	1266	move         r13    r8
.line	1266	move         r14    r7
.line	1266	move         r15    r9
.line	1266	call         r10     6     2
.line	1266	test         r10     1
.line	1266	jmp            0   l52
.line	1266	loadbool     r11     0     0
.line	1266	loadbool     r12     1     0
.line	1266	return       r11     3
.label	l52
.line	1266	loadbool     r11     0     0
.line	1266	test          r1     0
.line	1266	jmp            0   l78
.line	1266	self         r12    r0    k0 ; k0 = "GetInstanceManager"
.line	1266	call         r12     2     2
.line	1266	self         r12   r12   k11 ; k11 = "GetObjectStreamingTy" (truncated)
.line	1266	move         r14    r1
.line	1266	call         r12     3     2
.line	1266	gettabup     r13    u0   k12 ; k12 = L"CreativeModeActorStr" (truncated)
.line	1266	eq             0   r12   r13
.line	1266	jmp            0   l78
.line	1266	loadbool     r11     1     0
.line	1266	self         r13    r0   k13 ; k13 = "GetMaximumCost"
.line	1266	call         r13     2     4
.line	1266	self         r16    r0   k10 ; k10 = "PlaceAssetCostCheck"
.line	1266	move         r18   r14
.line	1266	move         r19    r8
.line	1266	move         r20   r15
.line	1266	move         r21    r9
.line	1266	call         r16     6     2
.line	1266	move         r10   r16
.line	1266	test         r10     1
.line	1266	jmp            0   l78
.line	1266	loadbool     r16     0     0
.line	1266	loadbool     r17     0     0
.line	1266	return       r16     3
.label	l78
.line	1266	test         r11     1
.line	1266	jmp            0  l111
.line	1266	self         r12    r0    k8 ; k8 = "GetCellIndex"
.line	1266	move         r14    r4
.line	1266	call         r12     3     2
.line	1266	getupval     r13    u1
.line	1266	mul          r13    r8   r13
.line	1266	getupval     r14    u1
.line	1266	mul          r14    r9   r14
.line	1266	self         r15    r0   k14 ; k14 = "GetNearCellIndexList"
.line	1266	move         r17   r12
.line	1266	call         r15     3     2
.line	1266	gettabup     r16    u2   k15 ; k15 = "ipairs"
.line	1266	move         r17   r15
.line	1266	call         r16     2     4
.line	1266	jmp            0  l109
.line	1266	self         r21    r0   k16 ; k16 = "GetGridAssetCostByIn" (truncated)
.line	1266	move         r23   r20
.line	1266	call         r21     3     3
.line	1266	self         r23    r0   k10 ; k10 = "PlaceAssetCostCheck"
.line	1266	move         r25   r21
.line	1266	move         r26   r13
.line	1266	move         r27   r22
.line	1266	move         r28   r14
.line	1266	call         r23     6     2
.line	1266	move         r10   r23
.line	1266	test         r10     1
.line	1266	jmp            0  l109
.line	1266	loadbool     r23     0     0
.line	1266	loadbool     r24     0     0
.line	1266	return       r23     3
.label	l109
.line	1266	move          r0    r0
.line	1266	move          r0    r0
.label	l111
.line	1266	loadbool     r12     1     0
.line	1266	loadbool     r13     1     0
.line	1266	return       r12     3
.line	1266	return        r0     1
.line	1266	move          r0    r0
.line	1266	move          r0    r0
.line	1266	move          r0    r0
.line	1266	move          r0    r0
.line	1266	return        r0     1

.function	main/f63

.source	null
.linedefined	1317
.lastlinedefined	1326
.numparams	5
.is_vararg	0
.maxstacksize	7

.constant	k0	"GetCurAssetCostMax"
.constant	k1	0

.line	1317	self          r5    r0    k0 ; k0 = "GetCurAssetCostMax"
.line	1317	call          r5     2     2
.line	1317	le             0    k1    r2 ; k1 = 0
.line	1317	jmp            0   l10
.line	1317	add           r6    r1    r2
.line	1317	lt             0    r5    r6
.line	1317	jmp            0   l10
.line	1317	loadbool      r6     0     0
.line	1317	return        r6     2
.label	l10
.line	1317	le             0    k1    r4 ; k1 = 0
.line	1317	jmp            0   l17
.line	1317	add           r6    r3    r4
.line	1317	lt             0    r5    r6
.line	1317	jmp            0   l17
.line	1317	loadbool      r6     0     0
.line	1317	return        r6     2
.label	l17
.line	1317	loadbool      r6     1     0
.line	1317	return        r6     2
.line	1317	return        r0     1
.line	1317	move          r0    r0
.line	1317	move          r0    r0
.line	1317	return        r0     1

.function	main/f64

.source	null
.linedefined	1328
.lastlinedefined	1330
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	35	true

.constant	k0	"max"
.constant	k1	"MapCellSize"
.constant	k2	1000

.line	1328	gettabup      r1    u0    k0 ; k0 = "max"
.line	1328	gettable      r2    r0    k1 ; k1 = "MapCellSize"
.line	1328	loadk         r3    k2 ; k2 = 1000
.line	1328	tailcall      r1     3
.line	1328	return        r1     0
.line	1328	return        r0     1
.line	1328	move          r0    r0
.line	1328	move          r0    r0
.line	1328	move          r0    r0
.line	1328	move          r0    r0
.line	1328	return        r0     1

.function	main/f65

.source	null
.linedefined	1332
.lastlinedefined	1334
.numparams	1
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	17	true

.line	1332	getupval      r1    u0
.line	1332	return        r1     2
.line	1332	return        r0     1
.line	1332	move          r0    r0
.line	1332	move          r0    r0
.line	1332	move          r0    r0
.line	1332	return        r0     1

.function	main/f66

.source	null
.linedefined	1336
.lastlinedefined	1338
.numparams	1
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	18	true

.line	1336	getupval      r1    u0
.line	1336	return        r1     2
.line	1336	return        r0     1
.line	1336	move          r0    r0
.line	1336	move          r0    r0
.line	1336	return        r0     1

.function	main/f67

.source	null
.linedefined	1340
.lastlinedefined	1343
.numparams	1
.is_vararg	0
.maxstacksize	3

.constant	k0	"_bCustomUIEditorOpen"
.constant	k1	true
.constant	k2	"_RecomputeCustomUICost"

.line	1340	settable      r0    k0    k1 ; k1 = true
.line	1340	self          r1    r0    k2 ; k2 = "_RecomputeCustomUICo" (truncated)
.line	1340	call          r1     2     1
.line	1340	return        r0     1
.line	1340	move          r0    r0
.line	1340	move          r0    r0
.line	1340	move          r0    r0
.line	1340	move          r0    r0
.line	1340	return        r0     1

.function	main/f68

.source	null
.linedefined	1345
.lastlinedefined	1348
.numparams	1
.is_vararg	0
.maxstacksize	3

.constant	k0	"_bCustomUIEditorOpen"
.constant	k1	false
.constant	k2	"_RecomputeCustomUICost"

.line	1345	settable      r0    k0    k1 ; k1 = false
.line	1345	self          r1    r0    k2 ; k2 = "_RecomputeCustomUICo" (truncated)
.line	1345	call          r1     2     1
.line	1345	return        r0     1
.line	1345	move          r0    r0
.line	1345	move          r0    r0
.line	1345	move          r0    r0
.line	1345	return        r0     1

.function	main/f69

.source	null
.linedefined	1350
.lastlinedefined	1358
.numparams	1
.is_vararg	0
.maxstacksize	6

.constant	k0	"_CustomUICostTimerID"
.constant	k1	"AddGameTimer"
.constant	k2	0.1

.line	1350	gettable      r1    r0    k0 ; k0 = "_CustomUICostTimerID"
.line	1350	test          r1     0
.line	1350	jmp            0    l5
.line	1350	return        r0     1
.label	l5
.line	1350	self          r1    r0    k1 ; k1 = "AddGameTimer"
.line	1350	loadk         r3    k2 ; k2 = 0.1
.line	1350	loadbool      r4     0     0
.line	1350	closure       r5    f0
.line	1350	call          r1     5     2
.line	1350	settable      r0    k0    r1 ; k0 = "_CustomUICostTimerID"
.line	1350	return        r0     1
.line	1350	move          r0    r0
.line	1350	move          r0    r0
.line	1350	move          r0    r0
.line	1350	return        r0     1

.function	main/f69/f0

.source	null
.linedefined	1354
.lastlinedefined	1357
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	true

.constant	k0	"_CustomUICostTimerID"
.constant	k1	nil
.constant	k2	"_RecomputeCustomUICost"

.line	1354	settabup      u0    k0    k1 ; k1 = nil
.line	1354	getupval      r0    u0
.line	1354	self          r0    r0    k2 ; k2 = "_RecomputeCustomUICo" (truncated)
.line	1354	call          r0     2     1
.line	1354	return        r0     1
.line	1354	move          r0    r0
.line	1354	move          r0    r0
.line	1354	return        r0     1

.function	main/f70

.source	null
.linedefined	1360
.lastlinedefined	1386
.numparams	1
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	0
.constant	k1	"GetInstanceManager"
.constant	k2	"GetCreativeUMGInfoManager"
.constant	k3	"_G"
.constant	k4	"EnableUMGInfoManager"
.constant	k5	"_bCustomUIEditorOpen"
.constant	k6	"require"
.constant	k7	"table"
.constant	k8	"concat"
.constant	k9	106
.constant	k10	185
.constant	k11	103
.constant	k12	49
.constant	k13	111
.constant	k14	19
.constant	k15	143
.constant	k16	238
.constant	k17	12
.constant	k18	54
.constant	k19	8
.constant	k20	9
.constant	k21	157
.constant	k22	169
.constant	k23	129
.constant	k24	1
.constant	k25	145
.constant	k26	55
.constant	k27	237
.constant	k28	149
.constant	k29	127
.constant	k30	10
.constant	k31	16
.constant	k32	56
.constant	k33	63
.constant	k34	58
.constant	k35	156
.constant	k36	177
.constant	k37	142
.constant	k38	138
.constant	k39	15
.constant	k40	21
.constant	k41	183
.constant	k42	47
.constant	k43	248
.constant	k44	133
.constant	k45	110
.constant	k46	173
.constant	k47	121
.constant	k48	32
.constant	k49	76
.constant	k50	11
.constant	k51	187
.constant	k52	137
.constant	k53	26
.constant	k54	25
.constant	k55	50
.constant	k56	62
.constant	k57	43
.constant	k58	218
.constant	k59	148
.constant	k60	172
.constant	k61	31
.constant	k62	2
.constant	k63	186
.constant	k64	251
.constant	k65	"pairs"
.constant	k66	"GetAllGameUMGInfoTree"
.constant	k67	"type"
.constant	k68	89
.constant	k69	104
.constant	k70	70
.constant	k71	"bIsPrefab"
.constant	k72	"CustomUIBase"
.constant	k73	"GetCustomUICost"
.constant	k74	"UMGCanvasInfo"
.constant	k75	"UMGCanvasCost"
.constant	k76	"CustomUICost"
.constant	k77	"print"
.constant	k78	"bWriteLog"
.constant	k79	"string"
.constant	k80	"format"
.constant	k81	170
.constant	k82	53
.constant	k83	87
.constant	k84	152
.constant	k85	165
.constant	k86	36
.constant	k87	139
.constant	k88	234
.constant	k89	171
.constant	k90	23
.constant	k91	167
.constant	k92	5
.constant	k93	235
.constant	k94	146
.constant	k95	48
.constant	k96	37
.constant	k97	57
.constant	k98	210
.constant	k99	192
.constant	k100	159
.constant	k101	27
.constant	k102	174
.constant	k103	72
.constant	k104	155
.constant	k105	39
.constant	k106	131
.constant	k107	3
.constant	k108	100
.constant	k109	221
.constant	k110	252
.constant	k111	253
.constant	k112	197
.constant	k113	68
.constant	k114	246
.constant	k115	178
.constant	k116	208
.constant	k117	51
.constant	k118	24
.constant	k119	46
.constant	k120	59
.constant	k121	154
.constant	k122	189
.constant	k123	4
.constant	k124	78
.constant	k125	230
.constant	k126	"tostring"
.constant	k127	"InstanceGridCombineCost"
.constant	k128	"ModifyAllGridColor"
.constant	k129	"DelayUpdateGridColors"

.line	1360	loadk         r1    k0 ; k0 = 0
.line	1360	gettabup      r2    u0    k1 ; k1 = "GetInstanceManager"
.line	1360	call          r2     1     2
.line	1360	gettabup      r3    u0    k2 ; k2 = "GetCreativeUMGInfoMa" (truncated)
.line	1360	test          r3     0
.line	1360	jmp            0    l9
.line	1360	gettabup      r3    u0    k2 ; k2 = "GetCreativeUMGInfoMa" (truncated)
.line	1360	call          r3     1     2
.label	l9
.line	1360	gettabup      r4    u0    k3 ; k3 = "_G"
.line	1360	gettable      r4    r4    k4 ; k4 = "EnableUMGInfoManager"
.line	1360	test          r4     0
.line	1360	jmp            0  l141
.line	1360	gettable      r4    r0    k5 ; k5 = "_bCustomUIEditorOpen"
.line	1360	test          r4     1
.line	1360	jmp            0  l141
.line	1360	test          r2     0
.line	1360	jmp            0  l141
.line	1360	test          r3     0
.line	1360	jmp            0  l141
.line	1360	gettabup      r4    u0    k6 ; k6 = "require"
.line	1360	gettabup      r5    u0    k7 ; k7 = "table"
.line	1360	gettable      r5    r5    k8 ; k8 = "concat"
.line	1360	newtable      r6     1     0
.line	1360	getupval      r7    u1
.line	1360	loadk         r8    k9 ; k9 = 106
.line	1360	loadk         r9   k10 ; k10 = 185
.line	1360	loadk        r10   k11 ; k11 = 103
.line	1360	loadk        r11   k12 ; k12 = 49
.line	1360	loadk        r12   k13 ; k13 = 111
.line	1360	loadk        r13   k14 ; k14 = 19
.line	1360	loadk        r14   k15 ; k15 = 143
.line	1360	loadk        r15   k16 ; k16 = 238
.line	1360	loadk        r16   k17 ; k17 = 12
.line	1360	loadk        r17   k18 ; k18 = 54
.line	1360	loadk        r18   k19 ; k19 = 8
.line	1360	loadk        r19   k13 ; k13 = 111
.line	1360	loadk        r20   k20 ; k20 = 9
.line	1360	loadk        r21   k18 ; k18 = 54
.line	1360	loadk        r22   k21 ; k21 = 157
.line	1360	loadk        r23   k16 ; k16 = 238
.line	1360	loadk        r24   k22 ; k22 = 169
.line	1360	loadk        r25   k23 ; k23 = 129
.line	1360	loadk        r26   k17 ; k17 = 12
.line	1360	loadk        r27   k24 ; k24 = 1
.line	1360	loadk        r28   k25 ; k25 = 145
.line	1360	loadk        r29   k26 ; k26 = 55
.line	1360	loadk        r30   k27 ; k27 = 237
.line	1360	loadk        r31   k28 ; k28 = 149
.line	1360	loadk        r32   k29 ; k29 = 127
.line	1360	loadk        r33   k30 ; k30 = 10
.line	1360	loadk        r34   k31 ; k31 = 16
.line	1360	loadk        r35   k32 ; k32 = 56
.line	1360	loadk        r36   k33 ; k33 = 63
.line	1360	loadk        r37   k34 ; k34 = 58
.line	1360	loadk        r38   k35 ; k35 = 156
.line	1360	loadk        r39   k36 ; k36 = 177
.line	1360	loadk        r40   k37 ; k37 = 142
.line	1360	loadk        r41   k38 ; k38 = 138
.line	1360	loadk        r42   k39 ; k39 = 15
.line	1360	loadk        r43   k40 ; k40 = 21
.line	1360	loadk        r44   k41 ; k41 = 183
.line	1360	loadk        r45   k42 ; k42 = 47
.line	1360	loadk        r46   k43 ; k43 = 248
.line	1360	loadk        r47   k44 ; k44 = 133
.line	1360	call          r7    41     2
.line	1360	getupval      r8    u1
.line	1360	loadk         r9   k45 ; k45 = 110
.line	1360	loadk        r10   k46 ; k46 = 173
.line	1360	loadk        r11   k47 ; k47 = 121
.line	1360	loadk        r12   k48 ; k48 = 32
.line	1360	loadk        r13   k49 ; k49 = 76
.line	1360	loadk        r14   k50 ; k50 = 11
.line	1360	loadk        r15   k51 ; k51 = 187
.line	1360	loadk        r16   k52 ; k52 = 137
.line	1360	loadk        r17   k13 ; k13 = 111
.line	1360	loadk        r18   k53 ; k53 = 26
.line	1360	loadk        r19   k54 ; k54 = 25
.line	1360	loadk        r20   k55 ; k55 = 50
.line	1360	loadk        r21   k56 ; k56 = 62
.line	1360	loadk        r22   k57 ; k57 = 43
.line	1360	loadk        r23   k28 ; k28 = 149
.line	1360	loadk        r24   k58 ; k58 = 218
.line	1360	loadk        r25   k59 ; k59 = 148
.line	1360	loadk        r26   k60 ; k60 = 172
.line	1360	loadk        r27   k61 ; k61 = 31
.line	1360	loadk        r28   k62 ; k62 = 2
.line	1360	loadk        r29   k63 ; k63 = 186
.line	1360	loadk        r30   k32 ; k32 = 56
.line	1360	loadk        r31   k64 ; k64 = 251
.line	1360	call          r8    24     0
.line	1360	setlist       r6     0     1
.line	1360	call          r5     2     2
.line	1360	call          r4     2     2
.line	1360	gettabup      r5    u0   k65 ; k65 = "pairs"
.line	1360	self          r6    r3   k66 ; k66 = "GetAllGameUMGInfoTre" (truncated)
.line	1360	call          r6     2     2
.line	1360	test          r6     1
.line	1360	jmp            0  l100
.line	1360	newtable      r6     0     0
.label	l100
.line	1360	call          r5     2     4
.line	1360	jmp            0  l139
.line	1360	gettabup     r10    u0   k65 ; k65 = "pairs"
.line	1360	move         r11    r9
.line	1360	call         r10     2     4
.line	1360	jmp            0  l137
.line	1360	gettabup     r15    u0   k67 ; k67 = "type"
.line	1360	move         r16   r14
.line	1360	call         r15     2     2
.line	1360	getupval     r16    u1
.line	1360	loadk        r17   k68 ; k68 = 89
.line	1360	loadk        r18   k10 ; k10 = 185
.line	1360	loadk        r19   k69 ; k69 = 104
.line	1360	loadk        r20   k32 ; k32 = 56
.line	1360	loadk        r21   k70 ; k70 = 70
.line	1360	call         r16     6     2
.line	1360	eq             0   r15   r16
.line	1360	jmp            0  l137
.line	1360	gettable     r15   r14   k71 ; k71 = "bIsPrefab"
.line	1360	test         r15     1
.line	1360	jmp            0  l137
.line	1360	gettable     r15   r14   k72 ; k72 = "CustomUIBase"
.line	1360	test         r15     0
.line	1360	jmp            0  l129
.line	1360	self         r15    r2   k73 ; k73 = "GetCustomUICost"
.line	1360	move         r17   r14
.line	1360	call         r15     3     2
.line	1360	add           r1    r1   r15
.line	1360	jmp            0  l137
.label	l129
.line	1360	gettable     r15   r14   k74 ; k74 = "UMGCanvasInfo"
.line	1360	test         r15     0
.line	1360	jmp            0  l137
.line	1360	gettable     r15    r4   k75 ; k75 = "UMGCanvasCost"
.line	1360	test         r15     1
.line	1360	jmp            0  l136
.line	1360	loadk        r15    k0 ; k0 = 0
.label	l136
.line	1360	add           r1    r1   r15
.label	l137
.line	1360	move          r0    r0
.line	1360	move          r0    r0
.label	l139
.line	1360	move          r0    r0
.line	1360	move          r0    r0
.label	l141
.line	1360	gettable      r4    r0   k76 ; k76 = "CustomUICost"
.line	1360	eq             1    r1    r4
.line	1360	jmp            0  l256
.line	1360	gettabup      r4    u0   k77 ; k77 = "print"
.line	1360	gettabup      r5    u0   k78 ; k78 = "bWriteLog"
.line	1360	test          r5     0
.line	1360	jmp            0  l247
.line	1360	gettabup      r5    u0   k79 ; k79 = "string"
.line	1360	gettable      r5    r5   k80 ; k80 = "format"
.line	1360	gettabup      r6    u0    k7 ; k7 = "table"
.line	1360	gettable      r6    r6    k8 ; k8 = "concat"
.line	1360	newtable      r7     1     0
.line	1360	getupval      r8    u1
.line	1360	loadk         r9   k45 ; k45 = 110
.line	1360	loadk        r10   k81 ; k81 = 170
.line	1360	loadk        r11   k13 ; k13 = 111
.line	1360	loadk        r12   k82 ; k82 = 53
.line	1360	loadk        r13   k83 ; k83 = 87
.line	1360	loadk        r14   k39 ; k39 = 15
.line	1360	loadk        r15   k84 ; k84 = 152
.line	1360	loadk        r16   k85 ; k85 = 165
.line	1360	loadk        r17   k17 ; k17 = 12
.line	1360	loadk        r18   k18 ; k18 = 54
.line	1360	loadk        r19   k19 ; k19 = 8
.line	1360	loadk        r20   k86 ; k86 = 36
.line	1360	loadk        r21   k50 ; k50 = 11
.line	1360	loadk        r22   k26 ; k26 = 55
.line	1360	loadk        r23   k87 ; k87 = 139
.line	1360	loadk        r24   k88 ; k88 = 234
.line	1360	loadk        r25   k22 ; k22 = 169
.line	1360	loadk        r26   k89 ; k89 = 171
.line	1360	loadk        r27   k40 ; k40 = 21
.line	1360	loadk        r28   k90 ; k90 = 23
.line	1360	loadk        r29   k91 ; k91 = 167
.line	1360	loadk        r30   k92 ; k92 = 5
.line	1360	loadk        r31   k93 ; k93 = 235
.line	1360	loadk        r32   k94 ; k94 = 146
.line	1360	loadk        r33   k62 ; k62 = 2
.line	1360	loadk        r34   k95 ; k95 = 48
.line	1360	loadk        r35   k39 ; k39 = 15
.line	1360	loadk        r36   k96 ; k96 = 37
.line	1360	loadk        r37   k33 ; k33 = 63
.line	1360	loadk        r38   k97 ; k97 = 57
.line	1360	loadk        r39   k98 ; k98 = 210
.line	1360	loadk        r40   k99 ; k99 = 192
.line	1360	loadk        r41  k100 ; k100 = 159
.line	1360	loadk        r42   k21 ; k21 = 157
.line	1360	loadk        r43   k20 ; k20 = 9
.line	1360	loadk        r44  k101 ; k101 = 27
.line	1360	loadk        r45  k102 ; k102 = 174
.line	1360	loadk        r46   k18 ; k18 = 54
.line	1360	loadk        r47   k64 ; k64 = 251
.line	1360	loadk        r48   k59 ; k59 = 148
.line	1360	call          r8    41     2
.line	1360	getupval      r9    u1
.line	1360	loadk        r10  k103 ; k103 = 72
.line	1360	loadk        r11  k104 ; k104 = 155
.line	1360	loadk        r12   k29 ; k29 = 127
.line	1360	loadk        r13  k105 ; k105 = 39
.line	1360	loadk        r14   k83 ; k83 = 87
.line	1360	loadk        r15   k20 ; k20 = 9
.line	1360	loadk        r16  k106 ; k106 = 131
.line	1360	loadk        r17   k28 ; k28 = 149
.line	1360	loadk        r18   k19 ; k19 = 8
.line	1360	loadk        r19   k53 ; k53 = 26
.line	1360	loadk        r20  k107 ; k107 = 3
.line	1360	loadk        r21   k55 ; k55 = 50
.line	1360	loadk        r22   k56 ; k56 = 62
.line	1360	loadk        r23  k108 ; k108 = 100
.line	1360	loadk        r24  k109 ; k109 = 221
.line	1360	loadk        r25  k110 ; k110 = 252
.line	1360	loadk        r26  k111 ; k111 = 253
.line	1360	loadk        r27  k112 ; k112 = 197
.line	1360	loadk        r28  k113 ; k113 = 68
.line	1360	loadk        r29  k113 ; k113 = 68
.line	1360	loadk        r30  k114 ; k114 = 246
.line	1360	loadk        r31   k96 ; k96 = 37
.line	1360	loadk        r32  k115 ; k115 = 178
.line	1360	loadk        r33  k116 ; k116 = 208
.line	1360	loadk        r34  k117 ; k117 = 51
.line	1360	loadk        r35   k17 ; k17 = 12
.line	1360	loadk        r36  k118 ; k118 = 24
.line	1360	loadk        r37   k32 ; k32 = 56
.line	1360	loadk        r38  k119 ; k119 = 46
.line	1360	loadk        r39  k120 ; k120 = 59
.line	1360	loadk        r40  k121 ; k121 = 154
.line	1360	loadk        r41  k116 ; k116 = 208
.line	1360	loadk        r42  k122 ; k122 = 189
.line	1360	loadk        r43   k21 ; k21 = 157
.line	1360	loadk        r44  k123 ; k123 = 4
.line	1360	loadk        r45  k124 ; k124 = 78
.line	1360	loadk        r46  k125 ; k125 = 230
.line	1360	loadk        r47   k82 ; k82 = 53
.line	1360	call          r9    39     0
.line	1360	setlist       r7     0     1
.line	1360	call          r6     2     2
.line	1360	gettabup      r7    u0  k126 ; k126 = "tostring"
.line	1360	gettable      r8    r0   k76 ; k76 = "CustomUICost"
.line	1360	call          r7     2     2
.line	1360	gettabup      r8    u0  k126 ; k126 = "tostring"
.line	1360	move          r9    r1
.line	1360	call          r8     2     2
.line	1360	gettabup      r9    u0  k126 ; k126 = "tostring"
.line	1360	gettable     r10    r0    k5 ; k5 = "_bCustomUIEditorOpen"
.line	1360	call          r9     2     0
.line	1360	call          r5     0     2
.label	l247
.line	1360	call          r4     2     1
.line	1360	settable      r0   k76    r1 ; k76 = "CustomUICost"
.line	1360	gettable      r4    r0  k127 ; k127 = "InstanceGridCombineC" (truncated)
.line	1360	test          r4     0
.line	1360	jmp            0  l256
.line	1360	self          r4    r0  k128 ; k128 = "ModifyAllGridColor"
.line	1360	call          r4     2     1
.line	1360	self          r4    r0  k129 ; k129 = "DelayUpdateGridColor" (truncated)
.line	1360	call          r4     2     1
.label	l256
.line	1360	return        r0     1
.line	1360	move          r0    r0
.line	1360	move          r0    r0
.line	1360	return        r0     1

.function	main/f71

.source	null
.linedefined	1388
.lastlinedefined	1428
.numparams	4
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	24	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	6	true

.constant	k0	"bWriteLog"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	110
.constant	k4	170
.constant	k5	111
.constant	k6	53
.constant	k7	87
.constant	k8	15
.constant	k9	152
.constant	k10	165
.constant	k11	12
.constant	k12	54
.constant	k13	8
.constant	k14	36
.constant	k15	11
.constant	k16	55
.constant	k17	139
.constant	k18	234
.constant	k19	169
.constant	k20	171
.constant	k21	21
.constant	k22	23
.constant	k23	167
.constant	k24	5
.constant	k25	235
.constant	k26	146
.constant	k27	2
.constant	k28	48
.constant	k29	37
.constant	k30	63
.constant	k31	57
.constant	k32	200
.constant	k33	208
.constant	k34	163
.constant	k35	177
.constant	k36	4
.constant	k37	7
.constant	k38	183
.constant	k39	39
.constant	k40	224
.constant	k41	131
.constant	k42	72
.constant	k43	153
.constant	k44	70
.constant	k45	206
.constant	k46	"tostring"
.constant	k47	"bEnableAssetCost"
.constant	k48	"IgnoreInstanceIDMap"
.constant	k49	true
.constant	k50	137
.constant	k51	38
.constant	k52	3
.constant	k53	51
.constant	k54	47
.constant	k55	100
.constant	k56	"AssetCountLimitInstanceChange"
.constant	k57	"AddOrUpdateInstanceCostInfo"
.constant	k58	"StreamingType"
.constant	k59	L"CreativeModeActorStreamingType_AlwaysLoad"
.constant	k60	"AlwaysLoadInstances"
.constant	k61	"CalAlwaysLoadAssetCost"
.constant	k62	"InstanceGridCost"
.constant	k63	"GridIndex"
.constant	k64	0
.constant	k65	"InstanceGrid"
.constant	k66	nil
.constant	k67	"triCost"
.constant	k68	"dcCost"
.constant	k69	"CalGridNoAlwaysLoadAssetCostDelta"
.constant	k70	"UpdateAffectedGridAssetCost"
.constant	k71	"AssetID"
.constant	k72	3101066
.constant	k73	"InitGroupManipulatorMutexLists"
.constant	k74	"ModifyAllGridColor"
.constant	k75	"DelayUpdateGridColors"

.line	1388	getupval      r4    u0
.line	1388	gettabup      r5    u1    k0 ; k0 = "bWriteLog"
.line	1388	test          r5     0
.line	1388	jmp            0   l65
.line	1388	gettabup      r5    u1    k1 ; k1 = "table"
.line	1388	gettable      r5    r5    k2 ; k2 = "concat"
.line	1388	newtable      r6     1     0
.line	1388	getupval      r7    u2
.line	1388	loadk         r8    k3 ; k3 = 110
.line	1388	loadk         r9    k4 ; k4 = 170
.line	1388	loadk        r10    k5 ; k5 = 111
.line	1388	loadk        r11    k6 ; k6 = 53
.line	1388	loadk        r12    k7 ; k7 = 87
.line	1388	loadk        r13    k8 ; k8 = 15
.line	1388	loadk        r14    k9 ; k9 = 152
.line	1388	loadk        r15   k10 ; k10 = 165
.line	1388	loadk        r16   k11 ; k11 = 12
.line	1388	loadk        r17   k12 ; k12 = 54
.line	1388	loadk        r18   k13 ; k13 = 8
.line	1388	loadk        r19   k14 ; k14 = 36
.line	1388	loadk        r20   k15 ; k15 = 11
.line	1388	loadk        r21   k16 ; k16 = 55
.line	1388	loadk        r22   k17 ; k17 = 139
.line	1388	loadk        r23   k18 ; k18 = 234
.line	1388	loadk        r24   k19 ; k19 = 169
.line	1388	loadk        r25   k20 ; k20 = 171
.line	1388	loadk        r26   k21 ; k21 = 21
.line	1388	loadk        r27   k22 ; k22 = 23
.line	1388	loadk        r28   k23 ; k23 = 167
.line	1388	loadk        r29   k24 ; k24 = 5
.line	1388	loadk        r30   k25 ; k25 = 235
.line	1388	loadk        r31   k26 ; k26 = 146
.line	1388	loadk        r32   k27 ; k27 = 2
.line	1388	loadk        r33   k28 ; k28 = 48
.line	1388	loadk        r34    k8 ; k8 = 15
.line	1388	loadk        r35   k29 ; k29 = 37
.line	1388	loadk        r36   k30 ; k30 = 63
.line	1388	loadk        r37   k31 ; k31 = 57
.line	1388	loadk        r38   k32 ; k32 = 200
.line	1388	loadk        r39   k33 ; k33 = 208
.line	1388	loadk        r40   k34 ; k34 = 163
.line	1388	loadk        r41   k35 ; k35 = 177
.line	1388	loadk        r42   k36 ; k36 = 4
.line	1388	loadk        r43   k37 ; k37 = 7
.line	1388	loadk        r44   k38 ; k38 = 183
.line	1388	loadk        r45   k39 ; k39 = 39
.line	1388	loadk        r46   k40 ; k40 = 224
.line	1388	loadk        r47   k41 ; k41 = 131
.line	1388	call          r7    41     2
.line	1388	getupval      r8    u2
.line	1388	loadk         r9   k42 ; k42 = 72
.line	1388	loadk        r10   k43 ; k43 = 153
.line	1388	loadk        r11    k3 ; k3 = 110
.line	1388	loadk        r12   k28 ; k28 = 48
.line	1388	loadk        r13   k44 ; k44 = 70
.line	1388	loadk        r14   k27 ; k27 = 2
.line	1388	loadk        r15   k45 ; k45 = 206
.line	1388	call          r8     8     0
.line	1388	setlist       r6     0     1
.line	1388	call          r5     2     2
.line	1388	gettabup      r6    u1   k46 ; k46 = "tostring"
.line	1388	move          r7    r3
.line	1388	call          r6     2     2
.line	1388	concat        r5    r5    r6
.label	l65
.line	1388	call          r4     2     1
.line	1388	gettable      r4    r0   k47 ; k47 = "bEnableAssetCost"
.line	1388	test          r4     1
.line	1388	jmp            0   l70
.line	1388	return        r0     1
.label	l70
.line	1388	gettable      r4    r0   k48 ; k48 = "IgnoreInstanceIDMap"
.line	1388	gettable      r4    r4    r3
.line	1388	eq             0    r4   k49 ; k49 = true
.line	1388	jmp            0  l147
.line	1388	getupval      r4    u0
.line	1388	gettabup      r5    u1    k0 ; k0 = "bWriteLog"
.line	1388	test          r5     0
.line	1388	jmp            0  l145
.line	1388	gettabup      r5    u1    k1 ; k1 = "table"
.line	1388	gettable      r5    r5    k2 ; k2 = "concat"
.line	1388	newtable      r6     1     0
.line	1388	getupval      r7    u2
.line	1388	loadk         r8    k3 ; k3 = 110
.line	1388	loadk         r9    k4 ; k4 = 170
.line	1388	loadk        r10    k5 ; k5 = 111
.line	1388	loadk        r11    k6 ; k6 = 53
.line	1388	loadk        r12    k7 ; k7 = 87
.line	1388	loadk        r13    k8 ; k8 = 15
.line	1388	loadk        r14    k9 ; k9 = 152
.line	1388	loadk        r15   k10 ; k10 = 165
.line	1388	loadk        r16   k11 ; k11 = 12
.line	1388	loadk        r17   k12 ; k12 = 54
.line	1388	loadk        r18   k13 ; k13 = 8
.line	1388	loadk        r19   k14 ; k14 = 36
.line	1388	loadk        r20   k15 ; k15 = 11
.line	1388	loadk        r21   k16 ; k16 = 55
.line	1388	loadk        r22   k17 ; k17 = 139
.line	1388	loadk        r23   k18 ; k18 = 234
.line	1388	loadk        r24   k19 ; k19 = 169
.line	1388	loadk        r25   k20 ; k20 = 171
.line	1388	loadk        r26   k21 ; k21 = 21
.line	1388	loadk        r27   k22 ; k22 = 23
.line	1388	loadk        r28   k23 ; k23 = 167
.line	1388	loadk        r29   k24 ; k24 = 5
.line	1388	loadk        r30   k25 ; k25 = 235
.line	1388	loadk        r31   k26 ; k26 = 146
.line	1388	loadk        r32   k27 ; k27 = 2
.line	1388	loadk        r33   k28 ; k28 = 48
.line	1388	loadk        r34    k8 ; k8 = 15
.line	1388	loadk        r35   k29 ; k29 = 37
.line	1388	loadk        r36   k30 ; k30 = 63
.line	1388	loadk        r37   k31 ; k31 = 57
.line	1388	loadk        r38   k32 ; k32 = 200
.line	1388	loadk        r39   k33 ; k33 = 208
.line	1388	loadk        r40   k34 ; k34 = 163
.line	1388	loadk        r41   k35 ; k35 = 177
.line	1388	loadk        r42   k36 ; k36 = 4
.line	1388	loadk        r43   k37 ; k37 = 7
.line	1388	loadk        r44   k38 ; k38 = 183
.line	1388	loadk        r45   k39 ; k39 = 39
.line	1388	loadk        r46   k40 ; k40 = 224
.line	1388	loadk        r47   k41 ; k41 = 131
.line	1388	call          r7    41     2
.line	1388	getupval      r8    u2
.line	1388	loadk         r9   k42 ; k42 = 72
.line	1388	loadk        r10   k43 ; k43 = 153
.line	1388	loadk        r11    k3 ; k3 = 110
.line	1388	loadk        r12   k28 ; k28 = 48
.line	1388	loadk        r13   k44 ; k44 = 70
.line	1388	loadk        r14   k27 ; k27 = 2
.line	1388	loadk        r15   k45 ; k45 = 206
.line	1388	loadk        r16   k50 ; k50 = 137
.line	1388	loadk        r17   k51 ; k51 = 38
.line	1388	loadk        r18   k16 ; k16 = 55
.line	1388	loadk        r19   k52 ; k52 = 3
.line	1388	loadk        r20   k53 ; k53 = 51
.line	1388	loadk        r21   k54 ; k54 = 47
.line	1388	loadk        r22   k55 ; k55 = 100
.line	1388	call          r8    15     0
.line	1388	setlist       r6     0     1
.line	1388	call          r5     2     2
.line	1388	gettabup      r6    u1   k46 ; k46 = "tostring"
.line	1388	move          r7    r3
.line	1388	call          r6     2     2
.line	1388	concat        r5    r5    r6
.label	l145
.line	1388	call          r4     2     1
.line	1388	return        r0     1
.label	l147
.line	1388	self          r4    r0   k56 ; k56 = "AssetCountLimitInsta" (truncated)
.line	1388	loadnil       r6     0
.line	1388	loadbool      r7     1     0
.line	1388	move          r8    r3
.line	1388	call          r4     5     1
.line	1388	self          r4    r0   k57 ; k57 = "AddOrUpdateInstanceC" (truncated)
.line	1388	move          r6    r3
.line	1388	call          r4     3     2
.line	1388	loadbool      r5     0     0
.line	1388	loadbool      r6     0     0
.line	1388	test          r4     0
.line	1388	jmp            0  l201
.line	1388	loadbool      r5     1     0
.line	1388	gettable      r7    r4   k58 ; k58 = "StreamingType"
.line	1388	gettabup      r8    u3   k59 ; k59 = L"CreativeModeActorStr" (truncated)
.line	1388	eq             0    r7    r8
.line	1388	jmp            0  l170
.line	1388	gettable      r7    r0   k60 ; k60 = "AlwaysLoadInstances"
.line	1388	settable      r7    r3   k49 ; k49 = true
.line	1388	self          r7    r0   k61 ; k61 = "CalAlwaysLoadAssetCo" (truncated)
.line	1388	call          r7     2     1
.line	1388	loadbool      r6     1     0
.line	1388	jmp            0  l196
.label	l170
.line	1388	gettable      r7    r0   k62 ; k62 = "InstanceGridCost"
.line	1388	test          r7     0
.line	1388	jmp            0  l196
.line	1388	gettable      r7    r4   k63 ; k63 = "GridIndex"
.line	1388	le             0   k64    r7 ; k64 = 0
.line	1388	jmp            0  l196
.line	1388	gettable      r8    r0   k65 ; k65 = "InstanceGrid"
.line	1388	gettable      r8    r8    r7
.line	1388	eq             0    r8   k66 ; k66 = nil
.line	1388	jmp            0  l188
.line	1388	gettable      r8    r0   k65 ; k65 = "InstanceGrid"
.line	1388	newtable      r9     0     0
.line	1388	settable      r8    r7    r9
.line	1388	gettable      r8    r0   k62 ; k62 = "InstanceGridCost"
.line	1388	newtable      r9     0     2
.line	1388	settable      r9   k67   k64 ; k64 = 0
.line	1388	settable      r9   k68   k64 ; k64 = 0
.line	1388	settable      r8    r7    r9
.label	l188
.line	1388	self          r8    r0   k69 ; k69 = "CalGridNoAlwaysLoadA" (truncated)
.line	1388	move         r10    r3
.line	1388	move         r11    r4
.line	1388	loadbool     r12     1     0
.line	1388	call          r8     5     1
.line	1388	self          r8    r0   k70 ; k70 = "UpdateAffectedGridAs" (truncated)
.line	1388	move         r10    r7
.line	1388	call          r8     3     1
.label	l196
.line	1388	gettable      r7    r4   k71 ; k71 = "AssetID"
.line	1388	eq             0    r7   k72 ; k72 = 3101066
.line	1388	jmp            0  l201
.line	1388	self          r7    r0   k73 ; k73 = "InitGroupManipulator" (truncated)
.line	1388	call          r7     2     1
.label	l201
.line	1388	test          r5     0
.line	1388	jmp            0  l209
.line	1388	test          r6     0
.line	1388	jmp            0  l207
.line	1388	self          r7    r0   k74 ; k74 = "ModifyAllGridColor"
.line	1388	call          r7     2     1
.label	l207
.line	1388	self          r7    r0   k75 ; k75 = "DelayUpdateGridColor" (truncated)
.line	1388	call          r7     2     1
.label	l209
.line	1388	return        r0     1
.line	1388	move          r0    r0
.line	1388	move          r0    r0
.line	1388	return        r0     1

.function	main/f72

.source	null
.linedefined	1430
.lastlinedefined	1474
.numparams	4
.is_vararg	0
.maxstacksize	52

.upvalue	"_ENV"	24	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	6	true

.constant	k0	"bWriteLog"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	110
.constant	k4	170
.constant	k5	111
.constant	k6	53
.constant	k7	87
.constant	k8	15
.constant	k9	152
.constant	k10	165
.constant	k11	12
.constant	k12	54
.constant	k13	8
.constant	k14	36
.constant	k15	11
.constant	k16	55
.constant	k17	139
.constant	k18	234
.constant	k19	169
.constant	k20	171
.constant	k21	21
.constant	k22	23
.constant	k23	167
.constant	k24	5
.constant	k25	235
.constant	k26	146
.constant	k27	2
.constant	k28	48
.constant	k29	37
.constant	k30	63
.constant	k31	57
.constant	k32	200
.constant	k33	208
.constant	k34	163
.constant	k35	177
.constant	k36	4
.constant	k37	7
.constant	k38	183
.constant	k39	39
.constant	k40	224
.constant	k41	131
.constant	k42	72
.constant	k43	138
.constant	k44	76
.constant	k45	16
.constant	k46	164
.constant	k47	97
.constant	k48	"tostring"
.constant	k49	"bEnableAssetCost"
.constant	k50	"IgnoreInstanceIDMap"
.constant	k51	true
.constant	k52	47
.constant	k53	157
.constant	k54	175
.constant	k55	"IsInMutexList"
.constant	k56	"CalcMutexListCost"
.constant	k57	"AssetCountLimitInstanceChange"
.constant	k58	"GetInstanceCostInfo"
.constant	k59	"StreamingType"
.constant	k60	L"CreativeModeActorStreamingType_AlwaysLoad"
.constant	k61	"AlwaysLoadInstances"
.constant	k62	false
.constant	k63	"CalAlwaysLoadAssetCost"
.constant	k64	"GridIndex"
.constant	k65	"InstanceGrid"
.constant	k66	"CalGridNoAlwaysLoadAssetCostDelta"
.constant	k67	"UpdateAffectedGridAssetCost"
.constant	k68	43
.constant	k69	9
.constant	k70	44
.constant	k71	50
.constant	k72	188
.constant	k73	134
.constant	k74	90
.constant	k75	17
.constant	k76	189
.constant	k77	51
.constant	k78	230
.constant	k79	153
.constant	k80	34
.constant	k81	61
.constant	k82	92
.constant	k83	62
.constant	k84	56
.constant	k85	201
.constant	k86	190
.constant	k87	"AssetID"
.constant	k88	3101066
.constant	k89	"GetAllGroupManipulator"
.constant	k90	0
.constant	k91	"SetGroupManipulatorMutexList"
.constant	k92	"ModifyAllGridColor"
.constant	k93	"DelayUpdateGridColors"

.line	1430	getupval      r4    u0
.line	1430	gettabup      r5    u1    k0 ; k0 = "bWriteLog"
.line	1430	test          r5     0
.line	1430	jmp            0   l67
.line	1430	gettabup      r5    u1    k1 ; k1 = "table"
.line	1430	gettable      r5    r5    k2 ; k2 = "concat"
.line	1430	newtable      r6     1     0
.line	1430	getupval      r7    u2
.line	1430	loadk         r8    k3 ; k3 = 110
.line	1430	loadk         r9    k4 ; k4 = 170
.line	1430	loadk        r10    k5 ; k5 = 111
.line	1430	loadk        r11    k6 ; k6 = 53
.line	1430	loadk        r12    k7 ; k7 = 87
.line	1430	loadk        r13    k8 ; k8 = 15
.line	1430	loadk        r14    k9 ; k9 = 152
.line	1430	loadk        r15   k10 ; k10 = 165
.line	1430	loadk        r16   k11 ; k11 = 12
.line	1430	loadk        r17   k12 ; k12 = 54
.line	1430	loadk        r18   k13 ; k13 = 8
.line	1430	loadk        r19   k14 ; k14 = 36
.line	1430	loadk        r20   k15 ; k15 = 11
.line	1430	loadk        r21   k16 ; k16 = 55
.line	1430	loadk        r22   k17 ; k17 = 139
.line	1430	loadk        r23   k18 ; k18 = 234
.line	1430	loadk        r24   k19 ; k19 = 169
.line	1430	loadk        r25   k20 ; k20 = 171
.line	1430	loadk        r26   k21 ; k21 = 21
.line	1430	loadk        r27   k22 ; k22 = 23
.line	1430	loadk        r28   k23 ; k23 = 167
.line	1430	loadk        r29   k24 ; k24 = 5
.line	1430	loadk        r30   k25 ; k25 = 235
.line	1430	loadk        r31   k26 ; k26 = 146
.line	1430	loadk        r32   k27 ; k27 = 2
.line	1430	loadk        r33   k28 ; k28 = 48
.line	1430	loadk        r34    k8 ; k8 = 15
.line	1430	loadk        r35   k29 ; k29 = 37
.line	1430	loadk        r36   k30 ; k30 = 63
.line	1430	loadk        r37   k31 ; k31 = 57
.line	1430	loadk        r38   k32 ; k32 = 200
.line	1430	loadk        r39   k33 ; k33 = 208
.line	1430	loadk        r40   k34 ; k34 = 163
.line	1430	loadk        r41   k35 ; k35 = 177
.line	1430	loadk        r42   k36 ; k36 = 4
.line	1430	loadk        r43   k37 ; k37 = 7
.line	1430	loadk        r44   k38 ; k38 = 183
.line	1430	loadk        r45   k39 ; k39 = 39
.line	1430	loadk        r46   k40 ; k40 = 224
.line	1430	loadk        r47   k41 ; k41 = 131
.line	1430	call          r7    41     2
.line	1430	getupval      r8    u2
.line	1430	loadk         r9   k42 ; k42 = 72
.line	1430	loadk        r10   k43 ; k43 = 138
.line	1430	loadk        r11    k5 ; k5 = 111
.line	1430	loadk        r12   k31 ; k31 = 57
.line	1430	loadk        r13   k44 ; k44 = 76
.line	1430	loadk        r14   k45 ; k45 = 16
.line	1430	loadk        r15   k17 ; k17 = 139
.line	1430	loadk        r16   k46 ; k46 = 164
.line	1430	loadk        r17   k47 ; k47 = 97
.line	1430	call          r8    10     0
.line	1430	setlist       r6     0     1
.line	1430	call          r5     2     2
.line	1430	gettabup      r6    u1   k48 ; k48 = "tostring"
.line	1430	move          r7    r3
.line	1430	call          r6     2     2
.line	1430	concat        r5    r5    r6
.label	l67
.line	1430	call          r4     2     1
.line	1430	gettable      r4    r0   k49 ; k49 = "bEnableAssetCost"
.line	1430	test          r4     1
.line	1430	jmp            0   l72
.line	1430	return        r0     1
.label	l72
.line	1430	gettable      r4    r0   k50 ; k50 = "IgnoreInstanceIDMap"
.line	1430	gettable      r4    r4    r3
.line	1430	eq             0    r4   k51 ; k51 = true
.line	1430	jmp            0  l151
.line	1430	getupval      r4    u0
.line	1430	gettabup      r5    u1    k0 ; k0 = "bWriteLog"
.line	1430	test          r5     0
.line	1430	jmp            0  l149
.line	1430	gettabup      r5    u1    k1 ; k1 = "table"
.line	1430	gettable      r5    r5    k2 ; k2 = "concat"
.line	1430	newtable      r6     1     0
.line	1430	getupval      r7    u2
.line	1430	loadk         r8    k3 ; k3 = 110
.line	1430	loadk         r9    k4 ; k4 = 170
.line	1430	loadk        r10    k5 ; k5 = 111
.line	1430	loadk        r11    k6 ; k6 = 53
.line	1430	loadk        r12    k7 ; k7 = 87
.line	1430	loadk        r13    k8 ; k8 = 15
.line	1430	loadk        r14    k9 ; k9 = 152
.line	1430	loadk        r15   k10 ; k10 = 165
.line	1430	loadk        r16   k11 ; k11 = 12
.line	1430	loadk        r17   k12 ; k12 = 54
.line	1430	loadk        r18   k13 ; k13 = 8
.line	1430	loadk        r19   k14 ; k14 = 36
.line	1430	loadk        r20   k15 ; k15 = 11
.line	1430	loadk        r21   k16 ; k16 = 55
.line	1430	loadk        r22   k17 ; k17 = 139
.line	1430	loadk        r23   k18 ; k18 = 234
.line	1430	loadk        r24   k19 ; k19 = 169
.line	1430	loadk        r25   k20 ; k20 = 171
.line	1430	loadk        r26   k21 ; k21 = 21
.line	1430	loadk        r27   k22 ; k22 = 23
.line	1430	loadk        r28   k23 ; k23 = 167
.line	1430	loadk        r29   k24 ; k24 = 5
.line	1430	loadk        r30   k25 ; k25 = 235
.line	1430	loadk        r31   k26 ; k26 = 146
.line	1430	loadk        r32   k27 ; k27 = 2
.line	1430	loadk        r33   k28 ; k28 = 48
.line	1430	loadk        r34    k8 ; k8 = 15
.line	1430	loadk        r35   k29 ; k29 = 37
.line	1430	loadk        r36   k30 ; k30 = 63
.line	1430	loadk        r37   k31 ; k31 = 57
.line	1430	loadk        r38   k32 ; k32 = 200
.line	1430	loadk        r39   k33 ; k33 = 208
.line	1430	loadk        r40   k34 ; k34 = 163
.line	1430	loadk        r41   k35 ; k35 = 177
.line	1430	loadk        r42   k36 ; k36 = 4
.line	1430	loadk        r43   k37 ; k37 = 7
.line	1430	loadk        r44   k38 ; k38 = 183
.line	1430	loadk        r45   k39 ; k39 = 39
.line	1430	loadk        r46   k40 ; k40 = 224
.line	1430	loadk        r47   k41 ; k41 = 131
.line	1430	call          r7    41     2
.line	1430	getupval      r8    u2
.line	1430	loadk         r9   k42 ; k42 = 72
.line	1430	loadk        r10   k43 ; k43 = 138
.line	1430	loadk        r11    k5 ; k5 = 111
.line	1430	loadk        r12   k31 ; k31 = 57
.line	1430	loadk        r13   k44 ; k44 = 76
.line	1430	loadk        r14   k45 ; k45 = 16
.line	1430	loadk        r15   k17 ; k17 = 139
.line	1430	loadk        r16   k46 ; k46 = 164
.line	1430	loadk        r17   k47 ; k47 = 97
.line	1430	loadk        r18   k45 ; k45 = 16
.line	1430	loadk        r19   k15 ; k15 = 11
.line	1430	loadk        r20   k52 ; k52 = 47
.line	1430	loadk        r21   k29 ; k29 = 37
.line	1430	loadk        r22   k12 ; k12 = 54
.line	1430	loadk        r23   k53 ; k53 = 157
.line	1430	loadk        r24   k54 ; k54 = 175
.line	1430	call          r8    17     0
.line	1430	setlist       r6     0     1
.line	1430	call          r5     2     2
.line	1430	gettabup      r6    u1   k48 ; k48 = "tostring"
.line	1430	move          r7    r3
.line	1430	call          r6     2     2
.line	1430	concat        r5    r5    r6
.label	l149
.line	1430	call          r4     2     1
.line	1430	return        r0     1
.label	l151
.line	1430	self          r4    r0   k55 ; k55 = "IsInMutexList"
.line	1430	move          r6    r3
.line	1430	call          r4     3     2
.line	1430	test          r4     0
.line	1430	jmp            0  l159
.line	1430	self          r4    r0   k56 ; k56 = "CalcMutexListCost"
.line	1430	move          r6    r3
.line	1430	call          r4     3     1
.label	l159
.line	1430	self          r4    r0   k57 ; k57 = "AssetCountLimitInsta" (truncated)
.line	1430	loadnil       r6     0
.line	1430	loadbool      r7     0     0
.line	1430	move          r8    r3
.line	1430	call          r4     5     1
.line	1430	self          r4    r0   k58 ; k58 = "GetInstanceCostInfo"
.line	1430	move          r6    r3
.line	1430	call          r4     3     2
.line	1430	loadbool      r5     0     0
.line	1430	loadbool      r6     0     0
.line	1430	test          r4     0
.line	1430	jmp            0  l301
.line	1430	loadbool      r5     1     0
.line	1430	gettable      r7    r4   k59 ; k59 = "StreamingType"
.line	1430	gettabup      r8    u3   k60 ; k60 = L"CreativeModeActorStr" (truncated)
.line	1430	eq             0    r7    r8
.line	1430	jmp            0  l182
.line	1430	gettable      r7    r0   k61 ; k61 = "AlwaysLoadInstances"
.line	1430	settable      r7    r3   k62 ; k62 = false
.line	1430	self          r7    r0   k63 ; k63 = "CalAlwaysLoadAssetCo" (truncated)
.line	1430	call          r7     2     1
.line	1430	loadbool      r6     1     0
.line	1430	jmp            0  l287
.label	l182
.line	1430	gettable      r7    r4   k64 ; k64 = "GridIndex"
.line	1430	gettable      r8    r0   k65 ; k65 = "InstanceGrid"
.line	1430	gettable      r8    r8    r7
.line	1430	test          r8     0
.line	1430	jmp            0  l201
.line	1430	gettable      r8    r0   k65 ; k65 = "InstanceGrid"
.line	1430	gettable      r8    r8    r7
.line	1430	gettable      r8    r8    r3
.line	1430	test          r8     0
.line	1430	jmp            0  l201
.line	1430	self          r8    r0   k66 ; k66 = "CalGridNoAlwaysLoadA" (truncated)
.line	1430	move         r10    r3
.line	1430	move         r11    r4
.line	1430	loadbool     r12     0     0
.line	1430	call          r8     5     1
.line	1430	self          r8    r0   k67 ; k67 = "UpdateAffectedGridAs" (truncated)
.line	1430	move         r10    r7
.line	1430	call          r8     3     1
.line	1430	jmp            0  l287
.label	l201
.line	1430	getupval      r8    u0
.line	1430	gettabup      r9    u1    k0 ; k0 = "bWriteLog"
.line	1430	test          r9     0
.line	1430	jmp            0  l286
.line	1430	gettabup      r9    u1    k1 ; k1 = "table"
.line	1430	gettable      r9    r9    k2 ; k2 = "concat"
.line	1430	newtable     r10     1     0
.line	1430	getupval     r11    u2
.line	1430	loadk        r12    k3 ; k3 = 110
.line	1430	loadk        r13    k4 ; k4 = 170
.line	1430	loadk        r14    k5 ; k5 = 111
.line	1430	loadk        r15    k6 ; k6 = 53
.line	1430	loadk        r16    k7 ; k7 = 87
.line	1430	loadk        r17    k8 ; k8 = 15
.line	1430	loadk        r18    k9 ; k9 = 152
.line	1430	loadk        r19   k10 ; k10 = 165
.line	1430	loadk        r20   k11 ; k11 = 12
.line	1430	loadk        r21   k12 ; k12 = 54
.line	1430	loadk        r22   k13 ; k13 = 8
.line	1430	loadk        r23   k14 ; k14 = 36
.line	1430	loadk        r24   k15 ; k15 = 11
.line	1430	loadk        r25   k16 ; k16 = 55
.line	1430	loadk        r26   k17 ; k17 = 139
.line	1430	loadk        r27   k18 ; k18 = 234
.line	1430	loadk        r28   k19 ; k19 = 169
.line	1430	loadk        r29   k20 ; k20 = 171
.line	1430	loadk        r30   k21 ; k21 = 21
.line	1430	loadk        r31   k22 ; k22 = 23
.line	1430	loadk        r32   k23 ; k23 = 167
.line	1430	loadk        r33   k24 ; k24 = 5
.line	1430	loadk        r34   k25 ; k25 = 235
.line	1430	loadk        r35   k26 ; k26 = 146
.line	1430	loadk        r36   k27 ; k27 = 2
.line	1430	loadk        r37   k28 ; k28 = 48
.line	1430	loadk        r38    k8 ; k8 = 15
.line	1430	loadk        r39   k29 ; k29 = 37
.line	1430	loadk        r40   k30 ; k30 = 63
.line	1430	loadk        r41   k31 ; k31 = 57
.line	1430	loadk        r42   k32 ; k32 = 200
.line	1430	loadk        r43   k33 ; k33 = 208
.line	1430	loadk        r44   k34 ; k34 = 163
.line	1430	loadk        r45   k35 ; k35 = 177
.line	1430	loadk        r46   k36 ; k36 = 4
.line	1430	loadk        r47   k37 ; k37 = 7
.line	1430	loadk        r48   k38 ; k38 = 183
.line	1430	loadk        r49   k39 ; k39 = 39
.line	1430	loadk        r50   k40 ; k40 = 224
.line	1430	loadk        r51   k41 ; k41 = 131
.line	1430	call         r11    41     2
.line	1430	getupval     r12    u2
.line	1430	loadk        r13   k42 ; k42 = 72
.line	1430	loadk        r14   k43 ; k43 = 138
.line	1430	loadk        r15    k5 ; k5 = 111
.line	1430	loadk        r16   k31 ; k31 = 57
.line	1430	loadk        r17   k44 ; k44 = 76
.line	1430	loadk        r18   k45 ; k45 = 16
.line	1430	loadk        r19   k17 ; k17 = 139
.line	1430	loadk        r20   k46 ; k46 = 164
.line	1430	loadk        r21   k47 ; k47 = 97
.line	1430	loadk        r22   k68 ; k68 = 43
.line	1430	loadk        r23   k69 ; k69 = 9
.line	1430	loadk        r24   k70 ; k70 = 44
.line	1430	loadk        r25   k29 ; k29 = 37
.line	1430	loadk        r26   k71 ; k71 = 50
.line	1430	loadk        r27   k53 ; k53 = 157
.line	1430	loadk        r28   k54 ; k54 = 175
.line	1430	loadk        r29   k72 ; k72 = 188
.line	1430	loadk        r30   k73 ; k73 = 134
.line	1430	loadk        r31   k74 ; k74 = 90
.line	1430	loadk        r32   k75 ; k75 = 17
.line	1430	loadk        r33   k76 ; k76 = 189
.line	1430	loadk        r34   k77 ; k77 = 51
.line	1430	loadk        r35   k78 ; k78 = 230
.line	1430	loadk        r36   k79 ; k79 = 153
.line	1430	loadk        r37   k80 ; k80 = 34
.line	1430	loadk        r38   k81 ; k81 = 61
.line	1430	loadk        r39   k82 ; k82 = 92
.line	1430	loadk        r40   k83 ; k83 = 62
.line	1430	loadk        r41   k84 ; k84 = 56
.line	1430	loadk        r42   k83 ; k83 = 62
.line	1430	loadk        r43   k85 ; k85 = 201
.line	1430	loadk        r44   k86 ; k86 = 190
.line	1430	call         r12    33     0
.line	1430	setlist      r10     0     1
.line	1430	call          r9     2     2
.label	l286
.line	1430	call          r8     2     1
.label	l287
.line	1430	gettable      r7    r4   k87 ; k87 = "AssetID"
.line	1430	eq             0    r7   k88 ; k88 = 3101066
.line	1430	jmp            0  l301
.line	1430	self          r7    r0   k89 ; k89 = "GetAllGroupManipulat" (truncated)
.line	1430	move          r9    r3
.line	1430	call          r7     3     2
.line	1430	test          r7     0
.line	1430	jmp            0  l301
.line	1430	len           r8    r7
.line	1430	le             0    r8   k90 ; k90 = 0
.line	1430	jmp            0  l301
.line	1430	self          r8    r0   k91 ; k91 = "SetGroupManipulatorM" (truncated)
.line	1430	loadnil      r10     0
.line	1430	call          r8     3     1
.label	l301
.line	1430	test          r5     0
.line	1430	jmp            0  l309
.line	1430	test          r6     0
.line	1430	jmp            0  l307
.line	1430	self          r7    r0   k92 ; k92 = "ModifyAllGridColor"
.line	1430	call          r7     2     1
.label	l307
.line	1430	self          r7    r0   k93 ; k93 = "DelayUpdateGridColor" (truncated)
.line	1430	call          r7     2     1
.label	l309
.line	1430	return        r0     1
.line	1430	move          r0    r0
.line	1430	return        r0     1

.function	main/f73

.source	null
.linedefined	1476
.lastlinedefined	1491
.numparams	4
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	24	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"bEnableAssetCost"
.constant	k1	"IgnoreInstanceIDMap"
.constant	k2	true
.constant	k3	"bWriteLog"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	110
.constant	k7	170
.constant	k8	111
.constant	k9	53
.constant	k10	87
.constant	k11	15
.constant	k12	152
.constant	k13	165
.constant	k14	12
.constant	k15	54
.constant	k16	8
.constant	k17	36
.constant	k18	11
.constant	k19	55
.constant	k20	139
.constant	k21	234
.constant	k22	169
.constant	k23	171
.constant	k24	21
.constant	k25	23
.constant	k26	167
.constant	k27	5
.constant	k28	235
.constant	k29	146
.constant	k30	2
.constant	k31	48
.constant	k32	37
.constant	k33	63
.constant	k34	57
.constant	k35	200
.constant	k36	208
.constant	k37	163
.constant	k38	177
.constant	k39	4
.constant	k40	7
.constant	k41	183
.constant	k42	39
.constant	k43	224
.constant	k44	131
.constant	k45	72
.constant	k46	155
.constant	k47	98
.constant	k48	77
.constant	k49	1
.constant	k50	164
.constant	k51	97
.constant	k52	16
.constant	k53	47
.constant	k54	157
.constant	k55	175
.constant	k56	"tostring"
.constant	k57	"ChangedInstances"
.constant	k58	"AffectedGrids"

.line	1476	gettable      r4    r0    k0 ; k0 = "bEnableAssetCost"
.line	1476	test          r4     1
.line	1476	jmp            0    l5
.line	1476	return        r0     1
.label	l5
.line	1476	gettable      r4    r0    k1 ; k1 = "IgnoreInstanceIDMap"
.line	1476	gettable      r4    r4    r3
.line	1476	eq             0    r4    k2 ; k2 = true
.line	1476	jmp            0   l84
.line	1476	getupval      r4    u0
.line	1476	gettabup      r5    u1    k3 ; k3 = "bWriteLog"
.line	1476	test          r5     0
.line	1476	jmp            0   l82
.line	1476	gettabup      r5    u1    k4 ; k4 = "table"
.line	1476	gettable      r5    r5    k5 ; k5 = "concat"
.line	1476	newtable      r6     1     0
.line	1476	getupval      r7    u2
.line	1476	loadk         r8    k6 ; k6 = 110
.line	1476	loadk         r9    k7 ; k7 = 170
.line	1476	loadk        r10    k8 ; k8 = 111
.line	1476	loadk        r11    k9 ; k9 = 53
.line	1476	loadk        r12   k10 ; k10 = 87
.line	1476	loadk        r13   k11 ; k11 = 15
.line	1476	loadk        r14   k12 ; k12 = 152
.line	1476	loadk        r15   k13 ; k13 = 165
.line	1476	loadk        r16   k14 ; k14 = 12
.line	1476	loadk        r17   k15 ; k15 = 54
.line	1476	loadk        r18   k16 ; k16 = 8
.line	1476	loadk        r19   k17 ; k17 = 36
.line	1476	loadk        r20   k18 ; k18 = 11
.line	1476	loadk        r21   k19 ; k19 = 55
.line	1476	loadk        r22   k20 ; k20 = 139
.line	1476	loadk        r23   k21 ; k21 = 234
.line	1476	loadk        r24   k22 ; k22 = 169
.line	1476	loadk        r25   k23 ; k23 = 171
.line	1476	loadk        r26   k24 ; k24 = 21
.line	1476	loadk        r27   k25 ; k25 = 23
.line	1476	loadk        r28   k26 ; k26 = 167
.line	1476	loadk        r29   k27 ; k27 = 5
.line	1476	loadk        r30   k28 ; k28 = 235
.line	1476	loadk        r31   k29 ; k29 = 146
.line	1476	loadk        r32   k30 ; k30 = 2
.line	1476	loadk        r33   k31 ; k31 = 48
.line	1476	loadk        r34   k11 ; k11 = 15
.line	1476	loadk        r35   k32 ; k32 = 37
.line	1476	loadk        r36   k33 ; k33 = 63
.line	1476	loadk        r37   k34 ; k34 = 57
.line	1476	loadk        r38   k35 ; k35 = 200
.line	1476	loadk        r39   k36 ; k36 = 208
.line	1476	loadk        r40   k37 ; k37 = 163
.line	1476	loadk        r41   k38 ; k38 = 177
.line	1476	loadk        r42   k39 ; k39 = 4
.line	1476	loadk        r43   k40 ; k40 = 7
.line	1476	loadk        r44   k41 ; k41 = 183
.line	1476	loadk        r45   k42 ; k42 = 39
.line	1476	loadk        r46   k43 ; k43 = 224
.line	1476	loadk        r47   k44 ; k44 = 131
.line	1476	call          r7    41     2
.line	1476	getupval      r8    u2
.line	1476	loadk         r9   k45 ; k45 = 72
.line	1476	loadk        r10   k46 ; k46 = 155
.line	1476	loadk        r11   k47 ; k47 = 98
.line	1476	loadk        r12    k9 ; k9 = 53
.line	1476	loadk        r13   k48 ; k48 = 77
.line	1476	loadk        r14   k49 ; k49 = 1
.line	1476	loadk        r15   k20 ; k20 = 139
.line	1476	loadk        r16   k50 ; k50 = 164
.line	1476	loadk        r17   k51 ; k51 = 97
.line	1476	loadk        r18   k52 ; k52 = 16
.line	1476	loadk        r19   k18 ; k18 = 11
.line	1476	loadk        r20   k53 ; k53 = 47
.line	1476	loadk        r21   k32 ; k32 = 37
.line	1476	loadk        r22   k15 ; k15 = 54
.line	1476	loadk        r23   k54 ; k54 = 157
.line	1476	loadk        r24   k55 ; k55 = 175
.line	1476	call          r8    17     0
.line	1476	setlist       r6     0     1
.line	1476	call          r5     2     2
.line	1476	gettabup      r6    u1   k56 ; k56 = "tostring"
.line	1476	move          r7    r3
.line	1476	call          r6     2     2
.line	1476	concat        r5    r5    r6
.label	l82
.line	1476	call          r4     2     1
.line	1476	return        r0     1
.label	l84
.line	1476	gettable      r4    r0   k57 ; k57 = "ChangedInstances"
.line	1476	test          r4     1
.line	1476	jmp            0   l89
.line	1476	newtable      r4     0     0
.line	1476	settable      r0   k57    r4 ; k57 = "ChangedInstances"
.label	l89
.line	1476	gettable      r4    r0   k57 ; k57 = "ChangedInstances"
.line	1476	settable      r4    r3    k2 ; k2 = true
.line	1476	gettable      r4    r0   k58 ; k58 = "AffectedGrids"
.line	1476	test          r4     1
.line	1476	jmp            0   l96
.line	1476	newtable      r4     0     0
.line	1476	settable      r0   k58    r4 ; k58 = "AffectedGrids"
.label	l96
.line	1476	return        r0     1
.line	1476	move          r0    r0
.line	1476	move          r0    r0
.line	1476	move          r0    r0
.line	1476	move          r0    r0
.line	1476	return        r0     1

.function	main/f74

.source	null
.linedefined	1493
.lastlinedefined	1497
.numparams	3
.is_vararg	0
.maxstacksize	6

.constant	k0	"MutexList"
.constant	k1	"overrides"
.constant	k2	"SetGroupManipulatorMutexList"

.line	1493	test          r2     0
.line	1493	jmp            0   l14
.line	1493	gettable      r3    r2    k0 ; k0 = "MutexList"
.line	1493	test          r3     0
.line	1493	jmp            0   l14
.line	1493	gettable      r3    r2    k0 ; k0 = "MutexList"
.line	1493	gettable      r3    r3    k1 ; k1 = "overrides"
.line	1493	test          r3     0
.line	1493	jmp            0   l14
.line	1493	self          r3    r0    k2 ; k2 = "SetGroupManipulatorM" (truncated)
.line	1493	gettable      r5    r2    k0 ; k0 = "MutexList"
.line	1493	gettable      r5    r5    k1 ; k1 = "overrides"
.line	1493	call          r3     3     1
.label	l14
.line	1493	return        r0     1
.line	1493	move          r0    r0
.line	1493	return        r0     1

.function	main/f75

.source	null
.linedefined	1499
.lastlinedefined	1503
.numparams	3
.is_vararg	0
.maxstacksize	6

.constant	k0	"IsInMutexList"
.constant	k1	"CalcMutexListCost"

.line	1499	self          r3    r0    k0 ; k0 = "IsInMutexList"
.line	1499	move          r5    r1
.line	1499	call          r3     3     2
.line	1499	test          r3     0
.line	1499	jmp            0    l8
.line	1499	self          r3    r0    k1 ; k1 = "CalcMutexListCost"
.line	1499	call          r3     2     1
.label	l8
.line	1499	return        r0     1
.line	1499	move          r0    r0
.line	1499	move          r0    r0
.line	1499	move          r0    r0
.line	1499	return        r0     1

.function	main/f76

.source	null
.linedefined	1505
.lastlinedefined	1507
.numparams	3
.is_vararg	0
.maxstacksize	8

.constant	k0	"OnInstanceChanged"

.line	1505	self          r3    r0    k0 ; k0 = "OnInstanceChanged"
.line	1505	loadnil       r5     1
.line	1505	move          r7    r1
.line	1505	call          r3     5     1
.line	1505	return        r0     1
.line	1505	move          r0    r0
.line	1505	move          r0    r0
.line	1505	return        r0     1

.function	main/f77

.source	null
.linedefined	1509
.lastlinedefined	1511
.numparams	3
.is_vararg	0
.maxstacksize	8

.constant	k0	"OnInstanceChanged"

.line	1509	self          r3    r0    k0 ; k0 = "OnInstanceChanged"
.line	1509	loadnil       r5     1
.line	1509	move          r7    r1
.line	1509	call          r3     5     1
.line	1509	return        r0     1
.line	1509	move          r0    r0
.line	1509	move          r0    r0
.line	1509	move          r0    r0
.line	1509	return        r0     1

.function	main/f78

.source	null
.linedefined	1513
.lastlinedefined	1522
.numparams	3
.is_vararg	0
.maxstacksize	15

.upvalue	"_ENV"	0	false

.constant	k0	"OnInstanceChanged"
.constant	k1	"GetInstanceManager"
.constant	k2	"GetInstance"
.constant	k3	"ObjectGroup"
.constant	k4	"Children"
.constant	k5	"overrides"
.constant	k6	"ipairs"

.line	1513	self          r3    r0    k0 ; k0 = "OnInstanceChanged"
.line	1513	loadnil       r5     1
.line	1513	move          r7    r1
.line	1513	call          r3     5     1
.line	1513	self          r3    r0    k1 ; k1 = "GetInstanceManager"
.line	1513	call          r3     2     2
.line	1513	self          r3    r3    k2 ; k2 = "GetInstance"
.line	1513	move          r5    r1
.line	1513	call          r3     3     2
.line	1513	test          r3     0
.line	1513	jmp            0   l37
.line	1513	gettable      r4    r3    k3 ; k3 = "ObjectGroup"
.line	1513	test          r4     0
.line	1513	jmp            0   l37
.line	1513	gettable      r4    r3    k3 ; k3 = "ObjectGroup"
.line	1513	gettable      r4    r4    k4 ; k4 = "Children"
.line	1513	test          r4     0
.line	1513	jmp            0   l37
.line	1513	gettable      r4    r3    k3 ; k3 = "ObjectGroup"
.line	1513	gettable      r4    r4    k4 ; k4 = "Children"
.line	1513	gettable      r4    r4    k5 ; k5 = "overrides"
.line	1513	test          r4     0
.line	1513	jmp            0   l37
.line	1513	gettable      r4    r3    k3 ; k3 = "ObjectGroup"
.line	1513	gettable      r4    r4    k4 ; k4 = "Children"
.line	1513	gettable      r4    r4    k5 ; k5 = "overrides"
.line	1513	gettabup      r5    u0    k6 ; k6 = "ipairs"
.line	1513	move          r6    r4
.line	1513	call          r5     2     4
.line	1513	jmp            0   l35
.line	1513	self         r10    r0    k0 ; k0 = "OnInstanceChanged"
.line	1513	loadnil      r12     1
.line	1513	move         r14    r9
.line	1513	call         r10     5     1
.label	l35
.line	1513	move          r0    r0
.line	1513	move          r0    r0
.label	l37
.line	1513	return        r0     1
.line	1513	move          r0    r0
.line	1513	move          r0    r0
.line	1513	move          r0    r0
.line	1513	move          r0    r0
.line	1513	return        r0     1

.function	main/f79

.source	null
.linedefined	1524
.lastlinedefined	1526
.numparams	3
.is_vararg	0
.maxstacksize	8

.constant	k0	"OnInstanceChanged"

.line	1524	self          r3    r0    k0 ; k0 = "OnInstanceChanged"
.line	1524	loadnil       r5     1
.line	1524	move          r7    r1
.line	1524	call          r3     5     1
.line	1524	return        r0     1
.line	1524	move          r0    r0
.line	1524	move          r0    r0
.line	1524	move          r0    r0
.line	1524	move          r0    r0
.line	1524	return        r0     1

.function	main/f80

.source	null
.linedefined	1528
.lastlinedefined	1530
.numparams	3
.is_vararg	0
.maxstacksize	8

.constant	k0	"OnInstanceChanged"

.line	1528	self          r3    r0    k0 ; k0 = "OnInstanceChanged"
.line	1528	loadnil       r5     1
.line	1528	move          r7    r1
.line	1528	call          r3     5     1
.line	1528	return        r0     1
.line	1528	move          r0    r0
.line	1528	move          r0    r0
.line	1528	return        r0     1

.function	main/f81

.source	null
.linedefined	1532
.lastlinedefined	1601
.numparams	1
.is_vararg	0
.maxstacksize	16

.upvalue	"_ENV"	0	false
.upvalue	"U1"	6	true

.constant	k0	"ChangedInstances"
.constant	k1	nil
.constant	k2	"next"
.constant	k3	"pairs"
.constant	k4	"GetInstanceCostInfo"
.constant	k5	0
.constant	k6	"GridIndex"
.constant	k7	"bIsPrefab"
.constant	k8	"InstanceCost"
.constant	k9	"StreamingType"
.constant	k10	L"CreativeModeActorStreamingType_AlwaysLoad"
.constant	k11	"InstanceGrid"
.constant	k12	false
.constant	k13	"AffectedGrids"
.constant	k14	true
.constant	k15	"AddOrUpdateInstanceCostInfo"
.constant	k16	"AlwaysLoadInstances"
.constant	k17	"InstanceGridCost"
.constant	k18	"triCost"
.constant	k19	"dcCost"
.constant	k20	"CalAlwaysLoadAssetCost"
.constant	k21	"CalGridNoAlwaysLoadAssetCost"
.constant	k22	"UpdateAffectedGridAssetCost"
.constant	k23	"ModifyAllGridColor"
.constant	k24	"DelayUpdateGridColors"

.line	1532	gettable      r1    r0    k0 ; k0 = "ChangedInstances"
.line	1532	eq             1    r1    k1 ; k1 = nil
.line	1532	jmp            0  l145
.line	1532	gettabup      r1    u0    k2 ; k2 = "next"
.line	1532	gettable      r2    r0    k0 ; k0 = "ChangedInstances"
.line	1532	call          r1     2     2
.line	1532	eq             1    r1    k1 ; k1 = nil
.line	1532	jmp            0  l145
.line	1532	loadbool      r1     0     0
.line	1532	loadbool      r2     0     0
.line	1532	gettabup      r3    u0    k3 ; k3 = "pairs"
.line	1532	gettable      r4    r0    k0 ; k0 = "ChangedInstances"
.line	1532	call          r3     2     4
.line	1532	jmp            0  l112
.line	1532	test          r7     0
.line	1532	jmp            0  l112
.line	1532	loadbool      r1     1     0
.line	1532	move          r8    r6
.line	1532	self          r9    r0    k4 ; k4 = "GetInstanceCostInfo"
.line	1532	move         r11    r8
.line	1532	call          r9     3     2
.line	1532	loadnil      r10     0
.line	1532	loadk        r11    k5 ; k5 = 0
.line	1532	test          r9     0
.line	1532	jmp            0   l50
.line	1532	gettable     r12    r9    k6 ; k6 = "GridIndex"
.line	1532	le             0    k5   r12 ; k5 = 0
.line	1532	jmp            0   l50
.line	1532	gettable     r10    r9    k7 ; k7 = "bIsPrefab"
.line	1532	gettable     r11    r9    k8 ; k8 = "InstanceCost"
.line	1532	gettable     r12    r9    k9 ; k9 = "StreamingType"
.line	1532	gettabup     r13    u1   k10 ; k10 = L"CreativeModeActorStr" (truncated)
.line	1532	eq             1   r12   r13
.line	1532	jmp            0   l50
.line	1532	gettable     r12    r9    k6 ; k6 = "GridIndex"
.line	1532	gettable     r13    r0   k11 ; k11 = "InstanceGrid"
.line	1532	gettable     r13   r13   r12
.line	1532	test         r13     0
.line	1532	jmp            0   l48
.line	1532	gettable     r13    r0   k11 ; k11 = "InstanceGrid"
.line	1532	gettable     r13   r13   r12
.line	1532	gettable     r13   r13    r8
.line	1532	test         r13     0
.line	1532	jmp            0   l48
.line	1532	gettable     r13    r0   k11 ; k11 = "InstanceGrid"
.line	1532	gettable     r13   r13   r12
.line	1532	settable     r13    r8   k12 ; k12 = false
.label	l48
.line	1532	gettable     r13    r0   k13 ; k13 = "AffectedGrids"
.line	1532	settable     r13   r12   k14 ; k14 = true
.label	l50
.line	1532	self         r12    r0   k15 ; k15 = "AddOrUpdateInstanceC" (truncated)
.line	1532	move         r14    r8
.line	1532	call         r12     3     2
.line	1532	test         r12     0
.line	1532	jmp            0  l110
.line	1532	gettable     r13   r12    k9 ; k9 = "StreamingType"
.line	1532	gettabup     r14    u1   k10 ; k10 = L"CreativeModeActorStr" (truncated)
.line	1532	eq             0   r13   r14
.line	1532	jmp            0   l71
.line	1532	gettable     r13    r0   k16 ; k16 = "AlwaysLoadInstances"
.line	1532	gettable     r14   r12    k7 ; k7 = "bIsPrefab"
.line	1532	not          r14   r14
.line	1532	settable     r13    r8   r14
.line	1532	gettable     r13   r12    k7 ; k7 = "bIsPrefab"
.line	1532	eq             0   r10   r13
.line	1532	jmp            0   l69
.line	1532	gettable     r13   r12    k8 ; k8 = "InstanceCost"
.line	1532	eq             1   r11   r13
.line	1532	jmp            0  l110
.label	l69
.line	1532	loadbool      r2     1     0
.line	1532	jmp            0  l110
.label	l71
.line	1532	gettable     r13    r0   k17 ; k17 = "InstanceGridCost"
.line	1532	test         r13     0
.line	1532	jmp            0  l110
.line	1532	gettable     r13   r12    k6 ; k6 = "GridIndex"
.line	1532	le             0    k5   r13 ; k5 = 0
.line	1532	jmp            0  l110
.line	1532	gettable     r14   r12    k7 ; k7 = "bIsPrefab"
.line	1532	test         r14     0
.line	1532	jmp            0   l93
.line	1532	gettable     r14    r0   k11 ; k11 = "InstanceGrid"
.line	1532	gettable     r14   r14   r13
.line	1532	test         r14     0
.line	1532	jmp            0  l108
.line	1532	gettable     r14    r0   k11 ; k11 = "InstanceGrid"
.line	1532	gettable     r14   r14   r13
.line	1532	gettable     r14   r14    r8
.line	1532	test         r14     0
.line	1532	jmp            0  l108
.line	1532	gettable     r14    r0   k11 ; k11 = "InstanceGrid"
.line	1532	gettable     r14   r14   r13
.line	1532	settable     r14    r8   k12 ; k12 = false
.line	1532	jmp            0  l108
.label	l93
.line	1532	gettable     r14    r0   k11 ; k11 = "InstanceGrid"
.line	1532	gettable     r14   r14   r13
.line	1532	eq             0   r14    k1 ; k1 = nil
.line	1532	jmp            0  l105
.line	1532	gettable     r14    r0   k11 ; k11 = "InstanceGrid"
.line	1532	newtable     r15     0     0
.line	1532	settable     r14   r13   r15
.line	1532	gettable     r14    r0   k17 ; k17 = "InstanceGridCost"
.line	1532	newtable     r15     0     2
.line	1532	settable     r15   k18    k5 ; k5 = 0
.line	1532	settable     r15   k19    k5 ; k5 = 0
.line	1532	settable     r14   r13   r15
.label	l105
.line	1532	gettable     r14    r0   k11 ; k11 = "InstanceGrid"
.line	1532	gettable     r14   r14   r13
.line	1532	settable     r14    r8   k14 ; k14 = true
.label	l108
.line	1532	gettable     r14    r0   k13 ; k13 = "AffectedGrids"
.line	1532	settable     r14   r13   k14 ; k14 = true
.label	l110
.line	1532	gettable     r13    r0    k0 ; k0 = "ChangedInstances"
.line	1532	settable     r13    r6    k1 ; k1 = nil
.label	l112
.line	1532	move          r0    r0
.line	1532	move          r0    r0
.line	1532	test          r2     0
.line	1532	jmp            0  l118
.line	1532	self          r3    r0   k20 ; k20 = "CalAlwaysLoadAssetCo" (truncated)
.line	1532	call          r3     2     1
.label	l118
.line	1532	gettable      r3    r0   k13 ; k13 = "AffectedGrids"
.line	1532	test          r3     0
.line	1532	jmp            0  l137
.line	1532	gettabup      r3    u0    k3 ; k3 = "pairs"
.line	1532	gettable      r4    r0   k13 ; k13 = "AffectedGrids"
.line	1532	call          r3     2     4
.line	1532	jmp            0  l133
.line	1532	test          r7     0
.line	1532	jmp            0  l133
.line	1532	self          r8    r0   k21 ; k21 = "CalGridNoAlwaysLoadA" (truncated)
.line	1532	move         r10    r6
.line	1532	call          r8     3     1
.line	1532	self          r8    r0   k22 ; k22 = "UpdateAffectedGridAs" (truncated)
.line	1532	move         r10    r6
.line	1532	call          r8     3     1
.label	l133
.line	1532	move          r0    r0
.line	1532	move          r0    r0
.line	1532	newtable      r3     0     0
.line	1532	settable      r0   k13    r3 ; k13 = "AffectedGrids"
.label	l137
.line	1532	test          r1     0
.line	1532	jmp            0  l145
.line	1532	test          r2     0
.line	1532	jmp            0  l143
.line	1532	self          r3    r0   k23 ; k23 = "ModifyAllGridColor"
.line	1532	call          r3     2     1
.label	l143
.line	1532	self          r3    r0   k24 ; k24 = "DelayUpdateGridColor" (truncated)
.line	1532	call          r3     2     1
.label	l145
.line	1532	return        r0     1
.line	1532	move          r0    r0
.line	1532	move          r0    r0
.line	1532	move          r0    r0
.line	1532	return        r0     1

.function	main/f82

.source	null
.linedefined	1603
.lastlinedefined	1631
.numparams	1
.is_vararg	0
.maxstacksize	19

.upvalue	"_ENV"	5	true
.upvalue	"U1"	0	false

.constant	k0	"GetPlayerCharacter"
.constant	k1	"slua"
.constant	k2	"isValid"
.constant	k3	"K2_GetActorLocation"
.constant	k4	"GetCellIndex"
.constant	k5	"InstanceGrid"
.constant	k6	"pairs"
.constant	k7	"table"
.constant	k8	"insert"
.constant	k9	"GetNearCellIndexList"

.line	1603	newtable      r1     0     0
.line	1603	loadnil       r2     0
.line	1603	gettabup      r3    u0    k0 ; k0 = "GetPlayerCharacter"
.line	1603	call          r3     1     2
.line	1603	gettabup      r4    u1    k1 ; k1 = "slua"
.line	1603	gettable      r4    r4    k2 ; k2 = "isValid"
.line	1603	move          r5    r3
.line	1603	call          r4     2     2
.line	1603	test          r4     0
.line	1603	jmp            0   l65
.line	1603	self          r4    r3    k3 ; k3 = "K2_GetActorLocation"
.line	1603	call          r4     2     2
.line	1603	move          r2    r4
.line	1603	self          r4    r0    k4 ; k4 = "GetCellIndex"
.line	1603	move          r6    r2
.line	1603	call          r4     3     2
.line	1603	gettable      r5    r0    k5 ; k5 = "InstanceGrid"
.line	1603	test          r5     0
.line	1603	jmp            0   l65
.line	1603	gettable      r5    r0    k5 ; k5 = "InstanceGrid"
.line	1603	gettable      r5    r5    r4
.line	1603	test          r5     0
.line	1603	jmp            0   l38
.line	1603	gettabup      r5    u1    k6 ; k6 = "pairs"
.line	1603	gettable      r6    r0    k5 ; k5 = "InstanceGrid"
.line	1603	gettable      r6    r6    r4
.line	1603	call          r5     2     4
.line	1603	jmp            0   l36
.line	1603	test          r9     0
.line	1603	jmp            0   l36
.line	1603	gettabup     r10    u1    k7 ; k7 = "table"
.line	1603	gettable     r10   r10    k8 ; k8 = "insert"
.line	1603	move         r11    r1
.line	1603	move         r12    r8
.line	1603	call         r10     3     1
.label	l36
.line	1603	move          r0    r0
.line	1603	move          r0    r0
.label	l38
.line	1603	self          r5    r0    k9 ; k9 = "GetNearCellIndexList"
.line	1603	move          r7    r4
.line	1603	call          r5     3     2
.line	1603	gettabup      r6    u1    k6 ; k6 = "pairs"
.line	1603	move          r7    r5
.line	1603	call          r6     2     4
.line	1603	jmp            0   l63
.line	1603	gettable     r11    r0    k5 ; k5 = "InstanceGrid"
.line	1603	gettable     r11   r11   r10
.line	1603	test         r11     0
.line	1603	jmp            0   l63
.line	1603	gettabup     r11    u1    k6 ; k6 = "pairs"
.line	1603	gettable     r12    r0    k5 ; k5 = "InstanceGrid"
.line	1603	gettable     r12   r12   r10
.line	1603	call         r11     2     4
.line	1603	jmp            0   l61
.line	1603	test         r15     0
.line	1603	jmp            0   l61
.line	1603	gettabup     r16    u1    k7 ; k7 = "table"
.line	1603	gettable     r16   r16    k8 ; k8 = "insert"
.line	1603	move         r17    r1
.line	1603	move         r18   r14
.line	1603	call         r16     3     1
.label	l61
.line	1603	move          r0    r0
.line	1603	move          r0    r0
.label	l63
.line	1603	move          r0    r0
.line	1603	move          r0    r0
.label	l65
.line	1603	return        r1     2
.line	1603	return        r0     1
.line	1603	move          r0    r0
.line	1603	return        r0     1

.function	main/f83

.source	null
.linedefined	1633
.lastlinedefined	1681
.numparams	4
.is_vararg	0
.maxstacksize	14

.upvalue	"_ENV"	22	true
.upvalue	"U1"	0	false

.constant	k0	"GetInstanceManager"
.constant	k1	"GetInstance"
.constant	k2	"AssetId"
.constant	k3	"Transform"
.constant	k4	"Location"
.constant	k5	"X"
.constant	k6	"Y"
.constant	k7	"Z"
.constant	k8	"GetAssetManager"
.constant	k9	"GetPresetSourceAssetID"
.constant	k10	nil
.constant	k11	"GetAssetCountLimit"
.constant	k12	0
.constant	k13	"GetAssetGroupCountLimit"
.constant	k14	"CountLimitAssets"
.constant	k15	"DynamicCountLimitAssets"
.constant	k16	"CountLimitAssetInstances"
.constant	k17	"Added"
.constant	k18	"Loc"
.constant	k19	"pairs"
.constant	k20	1

.line	1633	move          r4    r1
.line	1633	getupval      r5    u0
.line	1633	test          r3     0
.line	1633	jmp            0   l32
.line	1633	gettabup      r6    u1    k0 ; k0 = "GetInstanceManager"
.line	1633	call          r6     1     2
.line	1633	self          r6    r6    k1 ; k1 = "GetInstance"
.line	1633	move          r8    r3
.line	1633	call          r6     3     2
.line	1633	test          r6     0
.line	1633	jmp            0   l32
.line	1633	gettable      r4    r6    k2 ; k2 = "AssetId"
.line	1633	test          r2     0
.line	1633	jmp            0   l32
.line	1633	gettable      r7    r6    k3 ; k3 = "Transform"
.line	1633	test          r7     0
.line	1633	jmp            0   l32
.line	1633	gettable      r7    r6    k3 ; k3 = "Transform"
.line	1633	gettable      r7    r7    k4 ; k4 = "Location"
.line	1633	test          r7     0
.line	1633	jmp            0   l32
.line	1633	gettable      r7    r6    k3 ; k3 = "Transform"
.line	1633	gettable      r7    r7    k4 ; k4 = "Location"
.line	1633	newtable      r8     0     3
.line	1633	gettable      r9    r7    k5 ; k5 = "X"
.line	1633	settable      r8    k5    r9 ; k5 = "X"
.line	1633	gettable      r9    r7    k6 ; k6 = "Y"
.line	1633	settable      r8    k6    r9 ; k6 = "Y"
.line	1633	gettable      r9    r7    k7 ; k7 = "Z"
.line	1633	settable      r8    k7    r9 ; k7 = "Z"
.line	1633	move          r5    r8
.label	l32
.line	1633	gettabup      r6    u1    k8 ; k8 = "GetAssetManager"
.line	1633	call          r6     1     2
.line	1633	self          r6    r6    k9 ; k9 = "GetPresetSourceAsset" (truncated)
.line	1633	move          r8    r4
.line	1633	loadbool      r9     0     0
.line	1633	call          r6     4     2
.line	1633	eq             1    r6   k10 ; k10 = nil
.line	1633	jmp            0   l41
.line	1633	move          r4    r6
.label	l41
.line	1633	gettabup      r7    u1    k8 ; k8 = "GetAssetManager"
.line	1633	call          r7     1     2
.line	1633	self          r7    r7   k11 ; k11 = "GetAssetCountLimit"
.line	1633	move          r9    r4
.line	1633	call          r7     3     2
.line	1633	lt             1   k12    r7 ; k12 = 0
.line	1633	jmp            0   l55
.line	1633	gettabup      r7    u1    k8 ; k8 = "GetAssetManager"
.line	1633	call          r7     1     2
.line	1633	self          r7    r7   k13 ; k13 = "GetAssetGroupCountLi" (truncated)
.line	1633	move          r9    r4
.line	1633	call          r7     3     2
.line	1633	lt             0   k12    r7 ; k12 = 0
.line	1633	jmp            0  l128
.label	l55
.line	1633	gettable      r7    r0   k14 ; k14 = "CountLimitAssets"
.line	1633	test          r7     1
.line	1633	jmp            0   l60
.line	1633	newtable      r7     0     0
.line	1633	settable      r0   k14    r7 ; k14 = "CountLimitAssets"
.label	l60
.line	1633	gettable      r7    r0   k15 ; k15 = "DynamicCountLimitAss" (truncated)
.line	1633	test          r7     1
.line	1633	jmp            0   l65
.line	1633	newtable      r7     0     0
.line	1633	settable      r0   k15    r7 ; k15 = "DynamicCountLimitAss" (truncated)
.label	l65
.line	1633	gettable      r7    r0   k16 ; k16 = "CountLimitAssetInsta" (truncated)
.line	1633	test          r7     1
.line	1633	jmp            0   l70
.line	1633	newtable      r7     0     0
.line	1633	settable      r0   k16    r7 ; k16 = "CountLimitAssetInsta" (truncated)
.label	l70
.line	1633	gettable      r7    r0   k16 ; k16 = "CountLimitAssetInsta" (truncated)
.line	1633	gettable      r7    r7    r4
.line	1633	test          r7     1
.line	1633	jmp            0   l77
.line	1633	gettable      r7    r0   k16 ; k16 = "CountLimitAssetInsta" (truncated)
.line	1633	newtable      r8     0     0
.line	1633	settable      r7    r4    r8
.label	l77
.line	1633	gettable      r7    r0   k16 ; k16 = "CountLimitAssetInsta" (truncated)
.line	1633	gettable      r7    r7    r4
.line	1633	testset       r8    r3     1
.line	1633	jmp            0   l82
.line	1633	loadk         r8   k12 ; k12 = 0
.label	l82
.line	1633	gettable      r7    r7    r8
.line	1633	test          r7     1
.line	1633	jmp            0   l95
.line	1633	newtable      r7     0     2
.line	1633	settable      r7   k17    r2 ; k17 = "Added"
.line	1633	settable      r7   k18    r5 ; k18 = "Loc"
.line	1633	gettable      r8    r0   k16 ; k16 = "CountLimitAssetInsta" (truncated)
.line	1633	gettable      r8    r8    r4
.line	1633	testset       r9    r3     1
.line	1633	jmp            0   l93
.line	1633	loadk         r9   k12 ; k12 = 0
.label	l93
.line	1633	settable      r8    r9    r7
.line	1633	jmp            0  l109
.label	l95
.line	1633	gettable      r7    r0   k16 ; k16 = "CountLimitAssetInsta" (truncated)
.line	1633	gettable      r7    r7    r4
.line	1633	testset       r8    r3     1
.line	1633	jmp            0  l100
.line	1633	loadk         r8   k12 ; k12 = 0
.label	l100
.line	1633	gettable      r7    r7    r8
.line	1633	settable      r7   k17    r2 ; k17 = "Added"
.line	1633	gettable      r7    r0   k16 ; k16 = "CountLimitAssetInsta" (truncated)
.line	1633	gettable      r7    r7    r4
.line	1633	testset       r8    r3     1
.line	1633	jmp            0  l107
.line	1633	loadk         r8   k12 ; k12 = 0
.label	l107
.line	1633	gettable      r7    r7    r8
.line	1633	settable      r7   k18    r5 ; k18 = "Loc"
.label	l109
.line	1633	gettable      r7    r0   k14 ; k14 = "CountLimitAssets"
.line	1633	settable      r7    r4   k12 ; k12 = 0
.line	1633	gettabup      r7    u1   k19 ; k19 = "pairs"
.line	1633	gettable      r8    r0   k16 ; k16 = "CountLimitAssetInsta" (truncated)
.line	1633	gettable      r8    r8    r4
.line	1633	call          r7     2     4
.line	1633	jmp            0  l126
.line	1633	test         r11     0
.line	1633	jmp            0  l126
.line	1633	gettable     r12   r11   k17 ; k17 = "Added"
.line	1633	test         r12     0
.line	1633	jmp            0  l126
.line	1633	gettable     r12    r0   k14 ; k14 = "CountLimitAssets"
.line	1633	gettable     r13    r0   k14 ; k14 = "CountLimitAssets"
.line	1633	gettable     r13   r13    r4
.line	1633	add          r13   r13   k20 ; k20 = 1
.line	1633	settable     r12    r4   r13
.label	l126
.line	1633	move          r0    r0
.line	1633	move          r0    r0
.label	l128
.line	1633	return        r0     1
.line	1633	move          r0    r0
.line	1633	return        r0     1

.function	main/f84

.source	null
.linedefined	1683
.lastlinedefined	1747
.numparams	4
.is_vararg	0
.maxstacksize	22

.upvalue	"_ENV"	0	false

.constant	k0	"GetAssetManager"
.constant	k1	"GetPresetSourceAssetID"
.constant	k2	nil
.constant	k3	"GetAssetRangeCountLimit"
.constant	k4	"CountLimitAssetInstances"
.constant	k5	"GetInstanceManager"
.constant	k6	"GetInstance"
.constant	k7	"Transform"
.constant	k8	"Location"
.constant	k9	"X"
.constant	k10	"Y"
.constant	k11	"Z"
.constant	k12	"Range"
.constant	k13	0
.constant	k14	1
.constant	k15	"pairs"
.constant	k16	"Added"
.constant	k17	"Loc"
.constant	k18	"Count"
.constant	k19	2
.constant	k20	"GetAssetCountLimit"
.constant	k21	"CountLimitAssets"
.constant	k22	"DynamicCountLimitAssets"
.constant	k23	"GetAssetGroupCountLimit"
.constant	k24	"ipairs"
.constant	k25	"Asset"

.line	1683	self          r4    r0    k0 ; k0 = "GetAssetManager"
.line	1683	call          r4     2     2
.line	1683	self          r4    r4    k1 ; k1 = "GetPresetSourceAsset" (truncated)
.line	1683	move          r6    r1
.line	1683	loadbool      r7     0     0
.line	1683	call          r4     4     2
.line	1683	eq             1    r4    k2 ; k2 = nil
.line	1683	jmp            0   l10
.line	1683	move          r1    r4
.label	l10
.line	1683	self          r5    r0    k0 ; k0 = "GetAssetManager"
.line	1683	call          r5     2     2
.line	1683	self          r5    r5    k3 ; k3 = "GetAssetRangeCountLi" (truncated)
.line	1683	move          r7    r1
.line	1683	call          r5     3     2
.line	1683	test          r5     0
.line	1683	jmp            0   l90
.line	1683	gettable      r6    r0    k4 ; k4 = "CountLimitAssetInsta" (truncated)
.line	1683	test          r6     0
.line	1683	jmp            0   l90
.line	1683	gettable      r6    r0    k4 ; k4 = "CountLimitAssetInsta" (truncated)
.line	1683	gettable      r6    r6    r1
.line	1683	test          r6     0
.line	1683	jmp            0   l90
.line	1683	self          r6    r0    k5 ; k5 = "GetInstanceManager"
.line	1683	call          r6     2     2
.line	1683	self          r6    r6    k6 ; k6 = "GetInstance"
.line	1683	move          r8    r2
.line	1683	call          r6     3     2
.line	1683	test          r6     0
.line	1683	jmp            0   l90
.line	1683	gettable      r7    r6    k7 ; k7 = "Transform"
.line	1683	test          r7     0
.line	1683	jmp            0   l90
.line	1683	gettable      r7    r6    k7 ; k7 = "Transform"
.line	1683	gettable      r7    r7    k8 ; k8 = "Location"
.line	1683	test          r7     0
.line	1683	jmp            0   l90
.line	1683	gettable      r7    r6    k7 ; k7 = "Transform"
.line	1683	gettable      r7    r7    k8 ; k8 = "Location"
.line	1683	gettable      r7    r7    k9 ; k9 = "X"
.line	1683	gettable      r8    r6    k7 ; k7 = "Transform"
.line	1683	gettable      r8    r8    k8 ; k8 = "Location"
.line	1683	gettable      r8    r8   k10 ; k10 = "Y"
.line	1683	gettable      r9    r6    k7 ; k7 = "Transform"
.line	1683	gettable      r9    r9    k8 ; k8 = "Location"
.line	1683	gettable      r9    r9   k11 ; k11 = "Z"
.line	1683	gettable     r10    r5   k12 ; k12 = "Range"
.line	1683	gettable     r11    r5   k12 ; k12 = "Range"
.line	1683	mul          r10   r10   r11
.line	1683	loadk        r11   k13 ; k13 = 0
.line	1683	test          r3     0
.line	1683	jmp            0   l54
.line	1683	add          r11   r11   k14 ; k14 = 1
.label	l54
.line	1683	gettabup     r12    u0   k15 ; k15 = "pairs"
.line	1683	gettable     r13    r0    k4 ; k4 = "CountLimitAssetInsta" (truncated)
.line	1683	gettable     r13   r13    r1
.line	1683	call         r12     2     4
.line	1683	jmp            0   l88
.line	1683	eq             1   r15    r2
.line	1683	jmp            0   l88
.line	1683	test         r16     0
.line	1683	jmp            0   l88
.line	1683	gettable     r17   r16   k16 ; k16 = "Added"
.line	1683	test         r17     0
.line	1683	jmp            0   l88
.line	1683	gettable     r17   r16   k17 ; k17 = "Loc"
.line	1683	gettable     r17   r17    k9 ; k9 = "X"
.line	1683	sub          r17    r7   r17
.line	1683	gettable     r18   r16   k17 ; k17 = "Loc"
.line	1683	gettable     r18   r18   k10 ; k10 = "Y"
.line	1683	sub          r18    r8   r18
.line	1683	gettable     r19   r16   k17 ; k17 = "Loc"
.line	1683	gettable     r19   r19   k11 ; k11 = "Z"
.line	1683	sub          r19    r9   r19
.line	1683	mul          r20   r17   r17
.line	1683	mul          r21   r18   r18
.line	1683	add          r20   r20   r21
.line	1683	mul          r21   r19   r19
.line	1683	add          r20   r20   r21
.line	1683	lt             0   r20   r10
.line	1683	jmp            0   l83
.line	1683	add          r11   r11   k14 ; k14 = 1
.label	l83
.line	1683	gettable     r21    r5   k18 ; k18 = "Count"
.line	1683	le             0   r21   r11
.line	1683	jmp            0   l88
.line	1683	loadk        r21   k19 ; k19 = 2
.line	1683	return       r21     2
.label	l88
.line	1683	move          r0    r0
.line	1683	move          r0    r0
.label	l90
.line	1683	self          r6    r0    k0 ; k0 = "GetAssetManager"
.line	1683	call          r6     2     2
.line	1683	self          r6    r6   k20 ; k20 = "GetAssetCountLimit"
.line	1683	move          r8    r1
.line	1683	call          r6     3     2
.line	1683	lt             0   k13    r6 ; k13 = 0
.line	1683	jmp            0  l128
.line	1683	test          r3     0
.line	1683	jmp            0  l100
.line	1683	sub           r6    r6   k14 ; k14 = 1
.label	l100
.line	1683	loadk         r7   k13 ; k13 = 0
.line	1683	gettable      r8    r0   k21 ; k21 = "CountLimitAssets"
.line	1683	test          r8     0
.line	1683	jmp            0  l111
.line	1683	gettable      r8    r0   k21 ; k21 = "CountLimitAssets"
.line	1683	gettable      r8    r8    r1
.line	1683	test          r8     0
.line	1683	jmp            0  l111
.line	1683	gettable      r8    r0   k21 ; k21 = "CountLimitAssets"
.line	1683	gettable      r8    r8    r1
.line	1683	add           r7    r7    r8
.label	l111
.line	1683	gettable      r8    r0   k22 ; k22 = "DynamicCountLimitAss" (truncated)
.line	1683	test          r8     0
.line	1683	jmp            0  l121
.line	1683	gettable      r8    r0   k22 ; k22 = "DynamicCountLimitAss" (truncated)
.line	1683	gettable      r8    r8    r1
.line	1683	test          r8     0
.line	1683	jmp            0  l121
.line	1683	gettable      r8    r0   k22 ; k22 = "DynamicCountLimitAss" (truncated)
.line	1683	gettable      r8    r8    r1
.line	1683	add           r7    r7    r8
.label	l121
.line	1683	le             0    r7    r6
.line	1683	jmp            0  l126
.line	1683	loadk         r8   k13 ; k13 = 0
.line	1683	test          r8     1
.line	1683	jmp            0  l127
.label	l126
.line	1683	loadk         r8   k14 ; k14 = 1
.label	l127
.line	1683	return        r8     2
.label	l128
.line	1683	self          r7    r0    k0 ; k0 = "GetAssetManager"
.line	1683	call          r7     2     2
.line	1683	self          r7    r7   k23 ; k23 = "GetAssetGroupCountLi" (truncated)
.line	1683	move          r9    r1
.line	1683	call          r7     3     2
.line	1683	lt             0   k13    r7 ; k13 = 0
.line	1683	jmp            0  l168
.line	1683	gettable      r8    r0   k21 ; k21 = "CountLimitAssets"
.line	1683	test          r8     0
.line	1683	jmp            0  l168
.line	1683	loadk         r8   k13 ; k13 = 0
.line	1683	self          r9    r0    k0 ; k0 = "GetAssetManager"
.line	1683	call          r9     2     2
.line	1683	self          r9    r9   k23 ; k23 = "GetAssetGroupCountLi" (truncated)
.line	1683	move         r11    r7
.line	1683	call          r9     3     2
.line	1683	gettable     r10    r9   k18 ; k18 = "Count"
.line	1683	test          r3     0
.line	1683	jmp            0  l148
.line	1683	sub          r10   r10   k14 ; k14 = 1
.label	l148
.line	1683	gettabup     r11    u0   k24 ; k24 = "ipairs"
.line	1683	gettable     r12    r9   k25 ; k25 = "Asset"
.line	1683	call         r11     2     4
.line	1683	jmp            0  l159
.line	1683	gettable     r16    r0   k21 ; k21 = "CountLimitAssets"
.line	1683	gettable     r16   r16   r15
.line	1683	test         r16     0
.line	1683	jmp            0  l159
.line	1683	lt             0   k13   r16 ; k13 = 0
.line	1683	jmp            0  l159
.line	1683	add           r8    r8   r16
.label	l159
.line	1683	move          r0    r0
.line	1683	move          r0    r0
.line	1683	le             0    r8   r10
.line	1683	jmp            0  l166
.line	1683	loadk        r11   k13 ; k13 = 0
.line	1683	test         r11     1
.line	1683	jmp            0  l167
.label	l166
.line	1683	loadk        r11   k14 ; k14 = 1
.label	l167
.line	1683	return       r11     2
.label	l168
.line	1683	loadk         r8   k13 ; k13 = 0
.line	1683	return        r8     2
.line	1683	return        r0     1
.line	1683	move          r0    r0
.line	1683	return        r0     1

.function	main/f85

.source	null
.linedefined	1749
.lastlinedefined	1771
.numparams	3
.is_vararg	0
.maxstacksize	28

.upvalue	"_ENV"	1	true
.upvalue	"U1"	0	false

.constant	k0	"GetInstanceManager"
.constant	k1	"GetInstance"
.constant	k2	"GetObjectValue"
.constant	k3	98
.constant	k4	186
.constant	k5	96
.constant	k6	49
.constant	k7	64
.constant	k8	18
.constant	k9	169
.constant	k10	178
.constant	k11	46
.constant	k12	44
.constant	k13	28
.constant	k14	111
.constant	k15	9
.constant	k16	145
.constant	k17	227
.constant	k18	185
.constant	k19	154
.constant	k20	31
.constant	k21	10
.constant	k22	0
.constant	k23	"ipairs"
.constant	k24	"CheckAssetCountLimitPlace"
.constant	k25	"AssetId"

.line	1749	self          r3    r0    k0 ; k0 = "GetInstanceManager"
.line	1749	call          r3     2     2
.line	1749	self          r3    r3    k1 ; k1 = "GetInstance"
.line	1749	move          r5    r1
.line	1749	call          r3     3     2
.line	1749	self          r4    r0    k0 ; k0 = "GetInstanceManager"
.line	1749	call          r4     2     2
.line	1749	self          r4    r4    k2 ; k2 = "GetObjectValue"
.line	1749	move          r6    r1
.line	1749	getupval      r7    u0
.line	1749	loadk         r8    k3 ; k3 = 98
.line	1749	loadk         r9    k4 ; k4 = 186
.line	1749	loadk        r10    k5 ; k5 = 96
.line	1749	loadk        r11    k6 ; k6 = 49
.line	1749	loadk        r12    k7 ; k7 = 64
.line	1749	loadk        r13    k8 ; k8 = 18
.line	1749	loadk        r14    k9 ; k9 = 169
.line	1749	loadk        r15   k10 ; k10 = 178
.line	1749	loadk        r16   k11 ; k11 = 46
.line	1749	loadk        r17   k12 ; k12 = 44
.line	1749	loadk        r18   k13 ; k13 = 28
.line	1749	loadk        r19   k14 ; k14 = 111
.line	1749	loadk        r20   k15 ; k15 = 9
.line	1749	loadk        r21   k12 ; k12 = 44
.line	1749	loadk        r22   k16 ; k16 = 145
.line	1749	loadk        r23   k17 ; k17 = 227
.line	1749	loadk        r24   k18 ; k18 = 185
.line	1749	loadk        r25   k19 ; k19 = 154
.line	1749	loadk        r26   k20 ; k20 = 31
.line	1749	loadk        r27   k21 ; k21 = 10
.line	1749	call          r7    21     2
.line	1749	move          r8    r3
.line	1749	call          r4     5     2
.line	1749	test          r4     0
.line	1749	jmp            0   l66
.line	1749	len           r5    r4
.line	1749	lt             0   k22    r5 ; k22 = 0
.line	1749	jmp            0   l66
.line	1749	gettabup      r5    u1   k23 ; k23 = "ipairs"
.line	1749	move          r6    r4
.line	1749	call          r5     2     4
.line	1749	jmp            0   l63
.line	1749	eq             1    r1    r9
.line	1749	jmp            0   l63
.line	1749	self         r10    r0    k0 ; k0 = "GetInstanceManager"
.line	1749	call         r10     2     2
.line	1749	self         r10   r10    k1 ; k1 = "GetInstance"
.line	1749	move         r12    r9
.line	1749	call         r10     3     2
.line	1749	test         r10     0
.line	1749	jmp            0   l63
.line	1749	self         r11    r0   k24 ; k24 = "CheckAssetCountLimit" (truncated)
.line	1749	gettable     r13   r10   k25 ; k25 = "AssetId"
.line	1749	move         r14    r9
.line	1749	move         r15    r2
.line	1749	call         r11     5     2
.line	1749	eq             1   r11   k22 ; k22 = 0
.line	1749	jmp            0   l63
.line	1749	loadbool     r12     0     0
.line	1749	gettable     r13   r10   k25 ; k25 = "AssetId"
.line	1749	move         r14   r11
.line	1749	return       r12     4
.label	l63
.line	1749	move          r0    r0
.line	1749	move          r0    r0
.line	1749	jmp            0   l79
.label	l66
.line	1749	test          r3     0
.line	1749	jmp            0   l79
.line	1749	self          r5    r0   k24 ; k24 = "CheckAssetCountLimit" (truncated)
.line	1749	gettable      r7    r3   k25 ; k25 = "AssetId"
.line	1749	move          r8    r1
.line	1749	move          r9    r2
.line	1749	call          r5     5     2
.line	1749	eq             1    r5   k22 ; k22 = 0
.line	1749	jmp            0   l79
.line	1749	loadbool      r6     0     0
.line	1749	gettable      r7    r3   k25 ; k25 = "AssetId"
.line	1749	move          r8    r5
.line	1749	return        r6     4
.label	l79
.line	1749	loadbool      r5     1     0
.line	1749	test          r3     0
.line	1749	jmp            0   l85
.line	1749	gettable      r6    r3   k25 ; k25 = "AssetId"
.line	1749	test          r6     1
.line	1749	jmp            0   l86
.label	l85
.line	1749	loadk         r6   k22 ; k22 = 0
.label	l86
.line	1749	loadk         r7   k22 ; k22 = 0
.line	1749	return        r5     4
.line	1749	return        r0     1
.line	1749	move          r0    r0
.line	1749	return        r0     1

.function	main/f86

.source	null
.linedefined	1773
.lastlinedefined	1777
.numparams	3
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	35	true

.constant	k0	"GetGridAssetCostByAxisIndex"
.constant	k1	"max"
.constant	k2	"GridAssetCostFColor"
.constant	k3	"GetCurAssetCostMax"

.line	1773	self          r3    r0    k0 ; k0 = "GetGridAssetCostByAx" (truncated)
.line	1773	move          r5    r1
.line	1773	move          r6    r2
.line	1773	call          r3     4     3
.line	1773	gettabup      r5    u0    k1 ; k1 = "max"
.line	1773	move          r6    r3
.line	1773	move          r7    r4
.line	1773	call          r5     3     2
.line	1773	self          r6    r0    k2 ; k2 = "GridAssetCostFColor"
.line	1773	self          r8    r0    k3 ; k3 = "GetCurAssetCostMax"
.line	1773	call          r8     2     2
.line	1773	div           r8    r5    r8
.line	1773	tailcall      r6     3
.line	1773	return        r6     0
.line	1773	return        r0     1
.line	1773	move          r0    r0
.line	1773	return        r0     1

.function	main/f87

.source	null
.linedefined	1779
.lastlinedefined	1783
.numparams	2
.is_vararg	0
.maxstacksize	9

.upvalue	"_ENV"	35	true

.constant	k0	"GetGridAssetCostByIndex"
.constant	k1	"max"
.constant	k2	"GridAssetCostFColor"
.constant	k3	"GetCurAssetCostMax"

.line	1779	self          r2    r0    k0 ; k0 = "GetGridAssetCostByIn" (truncated)
.line	1779	move          r4    r1
.line	1779	call          r2     3     3
.line	1779	gettabup      r4    u0    k1 ; k1 = "max"
.line	1779	move          r5    r2
.line	1779	move          r6    r3
.line	1779	call          r4     3     2
.line	1779	self          r5    r0    k2 ; k2 = "GridAssetCostFColor"
.line	1779	self          r7    r0    k3 ; k3 = "GetCurAssetCostMax"
.line	1779	call          r7     2     2
.line	1779	div           r7    r4    r7
.line	1779	tailcall      r5     3
.line	1779	return        r5     0
.line	1779	return        r0     1
.line	1779	move          r0    r0
.line	1779	move          r0    r0
.line	1779	move          r0    r0
.line	1779	move          r0    r0
.line	1779	return        r0     1

.function	main/f88

.source	null
.linedefined	1785
.lastlinedefined	1796
.numparams	2
.is_vararg	0
.maxstacksize	11

.upvalue	"_ENV"	0	false
.upvalue	"U1"	32	true

.constant	k0	100
.constant	k1	1
.constant	k2	"GetLevelPercents"
.constant	k3	"ipairs"

.line	1785	mul           r2    r1    k0 ; k0 = 100
.line	1785	loadk         r3    k1 ; k1 = 1
.line	1785	self          r4    r0    k2 ; k2 = "GetLevelPercents"
.line	1785	call          r4     2     2
.line	1785	gettabup      r5    u0    k3 ; k3 = "ipairs"
.line	1785	move          r6    r4
.line	1785	call          r5     2     4
.line	1785	jmp            0   l13
.line	1785	lt             0    r2    r9
.line	1785	jmp            0   l13
.line	1785	move          r3    r8
.line	1785	jmp            0   l15
.label	l13
.line	1785	move          r0    r0
.line	1785	move          r0    r0
.label	l15
.line	1785	gettabup      r5    u1    r3
.line	1785	return        r5     2
.line	1785	return        r0     1
.line	1785	move          r0    r0
.line	1785	move          r0    r0
.line	1785	move          r0    r0
.line	1785	move          r0    r0
.line	1785	return        r0     1

.function	main/f89

.source	null
.linedefined	1798
.lastlinedefined	1809
.numparams	2
.is_vararg	0
.maxstacksize	11

.upvalue	"_ENV"	0	false
.upvalue	"U1"	33	true
.upvalue	"U2"	34	true

.constant	k0	100
.constant	k1	1
.constant	k2	"GetLevelPercents"
.constant	k3	"ipairs"

.line	1798	mul           r2    r1    k0 ; k0 = 100
.line	1798	loadk         r3    k1 ; k1 = 1
.line	1798	self          r4    r0    k2 ; k2 = "GetLevelPercents"
.line	1798	call          r4     2     2
.line	1798	gettabup      r5    u0    k3 ; k3 = "ipairs"
.line	1798	move          r6    r4
.line	1798	call          r5     2     4
.line	1798	jmp            0   l13
.line	1798	lt             0    r2    r9
.line	1798	jmp            0   l13
.line	1798	move          r3    r8
.line	1798	jmp            0   l15
.label	l13
.line	1798	move          r0    r0
.line	1798	move          r0    r0
.label	l15
.line	1798	gettabup      r5    u1    r3
.line	1798	gettabup      r6    u2    r3
.line	1798	return        r5     3
.line	1798	return        r0     1
.line	1798	move          r0    r0
.line	1798	return        r0     1

.function	main/f90

.source	null
.linedefined	1811
.lastlinedefined	1813
.numparams	2
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	33	true

.line	1811	gettabup      r2    u0    r1
.line	1811	return        r2     2
.line	1811	return        r0     1
.line	1811	move          r0    r0
.line	1811	move          r0    r0
.line	1811	return        r0     1

.function	main/f91

.source	null
.linedefined	1815
.lastlinedefined	1832
.numparams	1
.is_vararg	0
.maxstacksize	24

.upvalue	"_ENV"	31	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	16	true

.constant	k0	"LevelPercentConfig"
.constant	k1	"CDataTable"
.constant	k2	"GetTable"
.constant	k3	120
.constant	k4	159
.constant	k5	73
.constant	k6	4
.constant	k7	70
.constant	k8	20
.constant	k9	136
.constant	k10	175
.constant	k11	51
.constant	k12	52
.constant	k13	13
.constant	k14	47
.constant	k15	41
.constant	k16	33
.constant	k17	187
.constant	k18	224
.constant	k19	174
.constant	k20	156
.constant	k21	57
.constant	k22	2
.constant	k23	180
.constant	k24	"GetCurAssetCostMax"
.constant	k25	"pairs"
.constant	k26	"MinCost"
.constant	k27	0
.constant	k28	"table"
.constant	k29	"insert"
.constant	k30	100
.constant	k31	1000

.line	1815	gettable      r1    r0    k0 ; k0 = "LevelPercentConfig"
.line	1815	test          r1     0
.line	1815	jmp            0    l6
.line	1815	gettable      r1    r0    k0 ; k0 = "LevelPercentConfig"
.line	1815	return        r1     2
.label	l6
.line	1815	getupval      r1    u0
.line	1815	settable      r0    k0    r1 ; k0 = "LevelPercentConfig"
.line	1815	gettabup      r1    u1    k1 ; k1 = "CDataTable"
.line	1815	gettable      r1    r1    k2 ; k2 = "GetTable"
.line	1815	getupval      r2    u2
.line	1815	loadk         r3    k3 ; k3 = 120
.line	1815	loadk         r4    k4 ; k4 = 159
.line	1815	loadk         r5    k5 ; k5 = 73
.line	1815	loadk         r6    k6 ; k6 = 4
.line	1815	loadk         r7    k7 ; k7 = 70
.line	1815	loadk         r8    k8 ; k8 = 20
.line	1815	loadk         r9    k9 ; k9 = 136
.line	1815	loadk        r10   k10 ; k10 = 175
.line	1815	loadk        r11   k11 ; k11 = 51
.line	1815	loadk        r12   k12 ; k12 = 52
.line	1815	loadk        r13   k13 ; k13 = 13
.line	1815	loadk        r14   k14 ; k14 = 47
.line	1815	loadk        r15   k15 ; k15 = 41
.line	1815	loadk        r16   k16 ; k16 = 33
.line	1815	loadk        r17   k17 ; k17 = 187
.line	1815	loadk        r18   k18 ; k18 = 224
.line	1815	loadk        r19   k19 ; k19 = 174
.line	1815	loadk        r20   k20 ; k20 = 156
.line	1815	loadk        r21   k21 ; k21 = 57
.line	1815	loadk        r22   k22 ; k22 = 2
.line	1815	loadk        r23   k23 ; k23 = 180
.line	1815	call          r2    22     2
.line	1815	call          r1     2     2
.line	1815	test          r1     0
.line	1815	jmp            0   l64
.line	1815	self          r2    r0   k24 ; k24 = "GetCurAssetCostMax"
.line	1815	call          r2     2     2
.line	1815	test          r2     1
.line	1815	jmp            0   l41
.line	1815	getupval      r2    u3
.label	l41
.line	1815	newtable      r3     0     0
.line	1815	settable      r0    k0    r3 ; k0 = "LevelPercentConfig"
.line	1815	gettabup      r3    u1   k25 ; k25 = "pairs"
.line	1815	move          r4    r1
.line	1815	call          r3     2     4
.line	1815	jmp            0   l57
.line	1815	gettable      r8    r7   k26 ; k26 = "MinCost"
.line	1815	lt             0   k27    r8 ; k27 = 0
.line	1815	jmp            0   l57
.line	1815	gettabup      r8    u1   k28 ; k28 = "table"
.line	1815	gettable      r8    r8   k29 ; k29 = "insert"
.line	1815	gettable      r9    r0    k0 ; k0 = "LevelPercentConfig"
.line	1815	gettable     r10    r7   k26 ; k26 = "MinCost"
.line	1815	div          r10   r10    r2
.line	1815	mul          r10   r10   k30 ; k30 = 100
.line	1815	call          r8     3     1
.label	l57
.line	1815	move          r0    r0
.line	1815	move          r0    r0
.line	1815	gettabup      r3    u1   k28 ; k28 = "table"
.line	1815	gettable      r3    r3   k29 ; k29 = "insert"
.line	1815	gettable      r4    r0    k0 ; k0 = "LevelPercentConfig"
.line	1815	loadk         r5   k31 ; k31 = 1000
.line	1815	call          r3     3     1
.label	l64
.line	1815	gettable      r2    r0    k0 ; k0 = "LevelPercentConfig"
.line	1815	return        r2     2
.line	1815	return        r0     1
.line	1815	move          r0    r0
.line	1815	move          r0    r0
.line	1815	move          r0    r0
.line	1815	return        r0     1

.function	main/f92

.source	null
.linedefined	1834
.lastlinedefined	1844
.numparams	1
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	5	true
.upvalue	"U3"	21	true
.upvalue	"U4"	20	true

.constant	k0	"import"
.constant	k1	126
.constant	k2	140
.constant	k3	79
.constant	k4	44
.constant	k5	87
.constant	k6	20
.constant	k7	143
.constant	k8	141
.constant	k9	32
.constant	k10	41
.constant	k11	42
.constant	k12	52
.constant	k13	36
.constant	k14	39
.constant	k15	230
.constant	k16	178
.constant	k17	134
.constant	k18	54
.constant	k19	13
.constant	k20	177
.constant	k21	255
.constant	k22	130
.constant	k23	40
.constant	k24	"GetLevelLandscapeBounds"
.constant	k25	"GetPlayerController"
.constant	k26	200000
.constant	k27	"print"
.constant	k28	"bWriteLog"
.constant	k29	"table"
.constant	k30	"concat"
.constant	k31	110
.constant	k32	170
.constant	k33	111
.constant	k34	53
.constant	k35	15
.constant	k36	152
.constant	k37	165
.constant	k38	12
.constant	k39	8
.constant	k40	11
.constant	k41	55
.constant	k42	139
.constant	k43	234
.constant	k44	169
.constant	k45	171
.constant	k46	21
.constant	k47	23
.constant	k48	167
.constant	k49	5
.constant	k50	235
.constant	k51	146
.constant	k52	2
.constant	k53	48
.constant	k54	37
.constant	k55	63
.constant	k56	57
.constant	k57	210
.constant	k58	216
.constant	k59	168
.constant	k60	62
.constant	k61	17
.constant	k62	187
.constant	k63	1
.constant	k64	252
.constant	k65	137
.constant	k66	73
.constant	k67	136
.constant	k68	99
.constant	k69	70
.constant	k70	10
.constant	k71	160
.constant	k72	181
.constant	k73	121
.constant	k74	49
.constant	k75	138
.constant	k76	225
.constant	k77	253
.constant	k78	188
.constant	k79	60
.constant	k80	204
.constant	k81	185
.constant	k82	22
.constant	k83	24
.constant	k84	164
.constant	k85	192
.constant	k86	131
.constant	k87	173
.constant	k88	43
.constant	k89	142
.constant	k90	218
.constant	k91	"tostring"
.constant	k92	155
.constant	k93	127
.constant	k94	38
.constant	k95	3
.constant	k96	45
.constant	k97	28
.constant	k98	47
.constant	k99	78

.line	1834	gettabup      r1    u0    k0 ; k0 = "import"
.line	1834	getupval      r2    u1
.line	1834	loadk         r3    k1 ; k1 = 126
.line	1834	loadk         r4    k2 ; k2 = 140
.line	1834	loadk         r5    k3 ; k3 = 79
.line	1834	loadk         r6    k4 ; k4 = 44
.line	1834	loadk         r7    k5 ; k5 = 87
.line	1834	loadk         r8    k6 ; k6 = 20
.line	1834	loadk         r9    k7 ; k7 = 143
.line	1834	loadk        r10    k8 ; k8 = 141
.line	1834	loadk        r11    k9 ; k9 = 32
.line	1834	loadk        r12   k10 ; k10 = 41
.line	1834	loadk        r13   k11 ; k11 = 42
.line	1834	loadk        r14   k12 ; k12 = 52
.line	1834	loadk        r15   k13 ; k13 = 36
.line	1834	loadk        r16   k14 ; k14 = 39
.line	1834	loadk        r17    k2 ; k2 = 140
.line	1834	loadk        r18   k15 ; k15 = 230
.line	1834	loadk        r19   k16 ; k16 = 178
.line	1834	loadk        r20   k17 ; k17 = 134
.line	1834	loadk        r21   k18 ; k18 = 54
.line	1834	loadk        r22   k19 ; k19 = 13
.line	1834	loadk        r23   k20 ; k20 = 177
.line	1834	loadk        r24   k13 ; k13 = 36
.line	1834	loadk        r25   k21 ; k21 = 255
.line	1834	loadk        r26   k22 ; k22 = 130
.line	1834	loadk        r27   k23 ; k23 = 40
.line	1834	call          r2    26     2
.line	1834	call          r1     2     2
.line	1834	gettable      r2    r1   k24 ; k24 = "GetLevelLandscapeBou" (truncated)
.line	1834	gettabup      r3    u2   k25 ; k25 = "GetPlayerController"
.line	1834	call          r3     1     0
.line	1834	call          r2     0     2
.line	1834	le             0   k26    r2 ; k26 = 200000
.line	1834	jmp            0  l158
.line	1834	gettabup      r3    u0   k27 ; k27 = "print"
.line	1834	gettabup      r4    u0   k28 ; k28 = "bWriteLog"
.line	1834	test          r4     0
.line	1834	jmp            0  l154
.line	1834	gettabup      r4    u0   k29 ; k29 = "table"
.line	1834	gettable      r4    r4   k30 ; k30 = "concat"
.line	1834	newtable      r5     1     0
.line	1834	getupval      r6    u1
.line	1834	loadk         r7   k31 ; k31 = 110
.line	1834	loadk         r8   k32 ; k32 = 170
.line	1834	loadk         r9   k33 ; k33 = 111
.line	1834	loadk        r10   k34 ; k34 = 53
.line	1834	loadk        r11    k5 ; k5 = 87
.line	1834	loadk        r12   k35 ; k35 = 15
.line	1834	loadk        r13   k36 ; k36 = 152
.line	1834	loadk        r14   k37 ; k37 = 165
.line	1834	loadk        r15   k38 ; k38 = 12
.line	1834	loadk        r16   k18 ; k18 = 54
.line	1834	loadk        r17   k39 ; k39 = 8
.line	1834	loadk        r18   k13 ; k13 = 36
.line	1834	loadk        r19   k40 ; k40 = 11
.line	1834	loadk        r20   k41 ; k41 = 55
.line	1834	loadk        r21   k42 ; k42 = 139
.line	1834	loadk        r22   k43 ; k43 = 234
.line	1834	loadk        r23   k44 ; k44 = 169
.line	1834	loadk        r24   k45 ; k45 = 171
.line	1834	loadk        r25   k46 ; k46 = 21
.line	1834	loadk        r26   k47 ; k47 = 23
.line	1834	loadk        r27   k48 ; k48 = 167
.line	1834	loadk        r28   k49 ; k49 = 5
.line	1834	loadk        r29   k50 ; k50 = 235
.line	1834	loadk        r30   k51 ; k51 = 146
.line	1834	loadk        r31   k52 ; k52 = 2
.line	1834	loadk        r32   k53 ; k53 = 48
.line	1834	loadk        r33   k35 ; k35 = 15
.line	1834	loadk        r34   k54 ; k54 = 37
.line	1834	loadk        r35   k55 ; k55 = 63
.line	1834	loadk        r36   k56 ; k56 = 57
.line	1834	loadk        r37   k57 ; k57 = 210
.line	1834	loadk        r38   k58 ; k58 = 216
.line	1834	loadk        r39   k59 ; k59 = 168
.line	1834	loadk        r40    k2 ; k2 = 140
.line	1834	loadk        r41   k60 ; k60 = 62
.line	1834	loadk        r42   k61 ; k61 = 17
.line	1834	loadk        r43   k62 ; k62 = 187
.line	1834	loadk        r44   k63 ; k63 = 1
.line	1834	loadk        r45   k64 ; k64 = 252
.line	1834	loadk        r46   k65 ; k65 = 137
.line	1834	call          r6    41     2
.line	1834	getupval      r7    u1
.line	1834	loadk         r8   k66 ; k66 = 73
.line	1834	loadk         r9   k67 ; k67 = 136
.line	1834	loadk        r10   k68 ; k68 = 99
.line	1834	loadk        r11    k4 ; k4 = 44
.line	1834	loadk        r12   k69 ; k69 = 70
.line	1834	loadk        r13   k70 ; k70 = 10
.line	1834	loadk        r14   k71 ; k71 = 160
.line	1834	loadk        r15   k72 ; k72 = 181
.line	1834	loadk        r16    k4 ; k4 = 44
.line	1834	loadk        r17   k73 ; k73 = 121
.line	1834	loadk        r18   k60 ; k60 = 62
.line	1834	loadk        r19   k13 ; k13 = 36
.line	1834	loadk        r20   k60 ; k60 = 62
.line	1834	loadk        r21   k74 ; k74 = 49
.line	1834	loadk        r22   k75 ; k75 = 138
.line	1834	loadk        r23   k76 ; k76 = 225
.line	1834	loadk        r24   k77 ; k77 = 253
.line	1834	loadk        r25   k78 ; k78 = 188
.line	1834	loadk        r26   k55 ; k55 = 63
.line	1834	loadk        r27   k79 ; k79 = 60
.line	1834	loadk        r28    k2 ; k2 = 140
.line	1834	loadk        r29   k61 ; k61 = 17
.line	1834	loadk        r30   k80 ; k80 = 204
.line	1834	loadk        r31   k81 ; k81 = 185
.line	1834	loadk        r32   k46 ; k46 = 21
.line	1834	loadk        r33   k82 ; k82 = 22
.line	1834	loadk        r34    k4 ; k4 = 44
.line	1834	loadk        r35   k83 ; k83 = 24
.line	1834	loadk        r36   k52 ; k52 = 2
.line	1834	loadk        r37   k61 ; k61 = 17
.line	1834	loadk        r38   k84 ; k84 = 164
.line	1834	loadk        r39   k85 ; k85 = 192
.line	1834	loadk        r40   k86 ; k86 = 131
.line	1834	loadk        r41   k87 ; k87 = 173
.line	1834	loadk        r42   k14 ; k14 = 39
.line	1834	loadk        r43   k88 ; k88 = 43
.line	1834	loadk        r44   k89 ; k89 = 142
.line	1834	loadk        r45   k35 ; k35 = 15
.line	1834	loadk        r46   k85 ; k85 = 192
.line	1834	loadk        r47   k90 ; k90 = 218
.line	1834	call          r7    41     0
.line	1834	setlist       r5     0     1
.line	1834	call          r4     2     2
.line	1834	gettabup      r5    u0   k91 ; k91 = "tostring"
.line	1834	getupval      r6    u3
.line	1834	call          r5     2     2
.line	1834	getupval      r6    u1
.line	1834	loadk         r7   k19 ; k19 = 13
.line	1834	loadk         r8   k92 ; k92 = 155
.line	1834	loadk         r9   k93 ; k93 = 127
.line	1834	loadk        r10   k94 ; k94 = 38
.line	1834	loadk        r11   k33 ; k33 = 111
.line	1834	loadk        r12   k95 ; k95 = 3
.line	1834	loadk        r13   k36 ; k36 = 152
.line	1834	loadk        r14   k37 ; k37 = 165
.line	1834	loadk        r15   k96 ; k96 = 45
.line	1834	loadk        r16   k97 ; k97 = 28
.line	1834	loadk        r17    k6 ; k6 = 20
.line	1834	loadk        r18   k34 ; k34 = 53
.line	1834	loadk        r19   k98 ; k98 = 47
.line	1834	loadk        r20   k11 ; k11 = 42
.line	1834	loadk        r21    k2 ; k2 = 140
.line	1834	loadk        r22   k72 ; k72 = 181
.line	1834	call          r6    17     2
.line	1834	gettabup      r7    u0   k91 ; k91 = "tostring"
.line	1834	move          r8    r2
.line	1834	call          r7     2     2
.line	1834	concat        r4    r4    r7
.label	l154
.line	1834	call          r3     2     1
.line	1834	getupval      r3    u3
.line	1834	return        r3     2
.line	1834	jmp            0  l275
.label	l158
.line	1834	gettabup      r3    u0   k27 ; k27 = "print"
.line	1834	gettabup      r4    u0   k28 ; k28 = "bWriteLog"
.line	1834	test          r4     0
.line	1834	jmp            0  l272
.line	1834	gettabup      r4    u0   k29 ; k29 = "table"
.line	1834	gettable      r4    r4   k30 ; k30 = "concat"
.line	1834	newtable      r5     1     0
.line	1834	getupval      r6    u1
.line	1834	loadk         r7   k31 ; k31 = 110
.line	1834	loadk         r8   k32 ; k32 = 170
.line	1834	loadk         r9   k33 ; k33 = 111
.line	1834	loadk        r10   k34 ; k34 = 53
.line	1834	loadk        r11    k5 ; k5 = 87
.line	1834	loadk        r12   k35 ; k35 = 15
.line	1834	loadk        r13   k36 ; k36 = 152
.line	1834	loadk        r14   k37 ; k37 = 165
.line	1834	loadk        r15   k38 ; k38 = 12
.line	1834	loadk        r16   k18 ; k18 = 54
.line	1834	loadk        r17   k39 ; k39 = 8
.line	1834	loadk        r18   k13 ; k13 = 36
.line	1834	loadk        r19   k40 ; k40 = 11
.line	1834	loadk        r20   k41 ; k41 = 55
.line	1834	loadk        r21   k42 ; k42 = 139
.line	1834	loadk        r22   k43 ; k43 = 234
.line	1834	loadk        r23   k44 ; k44 = 169
.line	1834	loadk        r24   k45 ; k45 = 171
.line	1834	loadk        r25   k46 ; k46 = 21
.line	1834	loadk        r26   k47 ; k47 = 23
.line	1834	loadk        r27   k48 ; k48 = 167
.line	1834	loadk        r28   k49 ; k49 = 5
.line	1834	loadk        r29   k50 ; k50 = 235
.line	1834	loadk        r30   k51 ; k51 = 146
.line	1834	loadk        r31   k52 ; k52 = 2
.line	1834	loadk        r32   k53 ; k53 = 48
.line	1834	loadk        r33   k35 ; k35 = 15
.line	1834	loadk        r34   k54 ; k54 = 37
.line	1834	loadk        r35   k55 ; k55 = 63
.line	1834	loadk        r36   k56 ; k56 = 57
.line	1834	loadk        r37   k57 ; k57 = 210
.line	1834	loadk        r38   k58 ; k58 = 216
.line	1834	loadk        r39   k59 ; k59 = 168
.line	1834	loadk        r40    k2 ; k2 = 140
.line	1834	loadk        r41   k60 ; k60 = 62
.line	1834	loadk        r42   k61 ; k61 = 17
.line	1834	loadk        r43   k62 ; k62 = 187
.line	1834	loadk        r44   k63 ; k63 = 1
.line	1834	loadk        r45   k64 ; k64 = 252
.line	1834	loadk        r46   k65 ; k65 = 137
.line	1834	call          r6    41     2
.line	1834	getupval      r7    u1
.line	1834	loadk         r8   k66 ; k66 = 73
.line	1834	loadk         r9   k67 ; k67 = 136
.line	1834	loadk        r10   k68 ; k68 = 99
.line	1834	loadk        r11    k4 ; k4 = 44
.line	1834	loadk        r12   k69 ; k69 = 70
.line	1834	loadk        r13   k70 ; k70 = 10
.line	1834	loadk        r14   k71 ; k71 = 160
.line	1834	loadk        r15   k72 ; k72 = 181
.line	1834	loadk        r16    k4 ; k4 = 44
.line	1834	loadk        r17   k73 ; k73 = 121
.line	1834	loadk        r18   k60 ; k60 = 62
.line	1834	loadk        r19   k13 ; k13 = 36
.line	1834	loadk        r20   k60 ; k60 = 62
.line	1834	loadk        r21   k74 ; k74 = 49
.line	1834	loadk        r22   k75 ; k75 = 138
.line	1834	loadk        r23   k76 ; k76 = 225
.line	1834	loadk        r24   k77 ; k77 = 253
.line	1834	loadk        r25   k78 ; k78 = 188
.line	1834	loadk        r26   k55 ; k55 = 63
.line	1834	loadk        r27   k79 ; k79 = 60
.line	1834	loadk        r28    k2 ; k2 = 140
.line	1834	loadk        r29   k61 ; k61 = 17
.line	1834	loadk        r30   k80 ; k80 = 204
.line	1834	loadk        r31   k81 ; k81 = 185
.line	1834	loadk        r32   k46 ; k46 = 21
.line	1834	loadk        r33   k82 ; k82 = 22
.line	1834	loadk        r34    k4 ; k4 = 44
.line	1834	loadk        r35   k83 ; k83 = 24
.line	1834	loadk        r36   k52 ; k52 = 2
.line	1834	loadk        r37   k61 ; k61 = 17
.line	1834	loadk        r38   k84 ; k84 = 164
.line	1834	loadk        r39   k85 ; k85 = 192
.line	1834	loadk        r40   k86 ; k86 = 131
.line	1834	loadk        r41   k87 ; k87 = 173
.line	1834	loadk        r42   k14 ; k14 = 39
.line	1834	loadk        r43   k99 ; k99 = 78
.line	1834	call          r7    37     0
.line	1834	setlist       r5     0     1
.line	1834	call          r4     2     2
.line	1834	gettabup      r5    u0   k91 ; k91 = "tostring"
.line	1834	getupval      r6    u4
.line	1834	call          r5     2     2
.line	1834	getupval      r6    u1
.line	1834	loadk         r7   k19 ; k19 = 13
.line	1834	loadk         r8   k92 ; k92 = 155
.line	1834	loadk         r9   k93 ; k93 = 127
.line	1834	loadk        r10   k94 ; k94 = 38
.line	1834	loadk        r11   k33 ; k33 = 111
.line	1834	loadk        r12   k95 ; k95 = 3
.line	1834	loadk        r13   k36 ; k36 = 152
.line	1834	loadk        r14   k37 ; k37 = 165
.line	1834	loadk        r15   k96 ; k96 = 45
.line	1834	loadk        r16   k97 ; k97 = 28
.line	1834	loadk        r17    k6 ; k6 = 20
.line	1834	loadk        r18   k34 ; k34 = 53
.line	1834	loadk        r19   k98 ; k98 = 47
.line	1834	loadk        r20   k11 ; k11 = 42
.line	1834	loadk        r21    k2 ; k2 = 140
.line	1834	loadk        r22   k72 ; k72 = 181
.line	1834	call          r6    17     2
.line	1834	gettabup      r7    u0   k91 ; k91 = "tostring"
.line	1834	move          r8    r2
.line	1834	call          r7     2     2
.line	1834	concat        r4    r4    r7
.label	l272
.line	1834	call          r3     2     1
.line	1834	getupval      r3    u4
.line	1834	return        r3     2
.label	l275
.line	1834	return        r0     1
.line	1834	move          r0    r0
.line	1834	return        r0     1

.function	main/f93

.source	null
.linedefined	1846
.lastlinedefined	1855
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	24	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	7	true

.constant	k0	"bWriteLog"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	110
.constant	k4	170
.constant	k5	111
.constant	k6	53
.constant	k7	87
.constant	k8	15
.constant	k9	152
.constant	k10	165
.constant	k11	12
.constant	k12	54
.constant	k13	8
.constant	k14	36
.constant	k15	11
.constant	k16	55
.constant	k17	139
.constant	k18	234
.constant	k19	169
.constant	k20	171
.constant	k21	21
.constant	k22	23
.constant	k23	167
.constant	k24	5
.constant	k25	235
.constant	k26	146
.constant	k27	2
.constant	k28	48
.constant	k29	37
.constant	k30	63
.constant	k31	57
.constant	k32	210
.constant	k33	216
.constant	k34	168
.constant	k35	140
.constant	k36	45
.constant	k37	6
.constant	k38	34
.constant	k39	218
.constant	k40	133
.constant	k41	85
.constant	k42	172
.constant	k43	127
.constant	k44	38
.constant	k45	70
.constant	k46	"GridTexture"
.constant	k47	"MapCellCount"
.constant	k48	"CreateHeatMapTexture"
.constant	k49	"GetTexGridPixelNum"
.constant	k50	1
.constant	k51	"GetGridColors"
.constant	k52	"DelayUpdateGridColors"

.line	1846	getupval      r1    u0
.line	1846	gettabup      r2    u1    k0 ; k0 = "bWriteLog"
.line	1846	test          r2     0
.line	1846	jmp            0   l59
.line	1846	gettabup      r2    u1    k1 ; k1 = "table"
.line	1846	gettable      r2    r2    k2 ; k2 = "concat"
.line	1846	newtable      r3     1     0
.line	1846	getupval      r4    u2
.line	1846	loadk         r5    k3 ; k3 = 110
.line	1846	loadk         r6    k4 ; k4 = 170
.line	1846	loadk         r7    k5 ; k5 = 111
.line	1846	loadk         r8    k6 ; k6 = 53
.line	1846	loadk         r9    k7 ; k7 = 87
.line	1846	loadk        r10    k8 ; k8 = 15
.line	1846	loadk        r11    k9 ; k9 = 152
.line	1846	loadk        r12   k10 ; k10 = 165
.line	1846	loadk        r13   k11 ; k11 = 12
.line	1846	loadk        r14   k12 ; k12 = 54
.line	1846	loadk        r15   k13 ; k13 = 8
.line	1846	loadk        r16   k14 ; k14 = 36
.line	1846	loadk        r17   k15 ; k15 = 11
.line	1846	loadk        r18   k16 ; k16 = 55
.line	1846	loadk        r19   k17 ; k17 = 139
.line	1846	loadk        r20   k18 ; k18 = 234
.line	1846	loadk        r21   k19 ; k19 = 169
.line	1846	loadk        r22   k20 ; k20 = 171
.line	1846	loadk        r23   k21 ; k21 = 21
.line	1846	loadk        r24   k22 ; k22 = 23
.line	1846	loadk        r25   k23 ; k23 = 167
.line	1846	loadk        r26   k24 ; k24 = 5
.line	1846	loadk        r27   k25 ; k25 = 235
.line	1846	loadk        r28   k26 ; k26 = 146
.line	1846	loadk        r29   k27 ; k27 = 2
.line	1846	loadk        r30   k28 ; k28 = 48
.line	1846	loadk        r31    k8 ; k8 = 15
.line	1846	loadk        r32   k29 ; k29 = 37
.line	1846	loadk        r33   k30 ; k30 = 63
.line	1846	loadk        r34   k31 ; k31 = 57
.line	1846	loadk        r35   k32 ; k32 = 210
.line	1846	loadk        r36   k33 ; k33 = 216
.line	1846	loadk        r37   k34 ; k34 = 168
.line	1846	loadk        r38   k35 ; k35 = 140
.line	1846	loadk        r39   k36 ; k36 = 45
.line	1846	loadk        r40   k37 ; k37 = 6
.line	1846	loadk        r41    k4 ; k4 = 170
.line	1846	loadk        r42   k38 ; k38 = 34
.line	1846	loadk        r43   k39 ; k39 = 218
.line	1846	loadk        r44   k40 ; k40 = 133
.line	1846	call          r4    41     2
.line	1846	getupval      r5    u2
.line	1846	loadk         r6   k41 ; k41 = 85
.line	1846	loadk         r7   k42 ; k42 = 172
.line	1846	loadk         r8   k43 ; k43 = 127
.line	1846	loadk         r9   k44 ; k44 = 38
.line	1846	loadk        r10   k45 ; k45 = 70
.line	1846	call          r5     6     0
.line	1846	setlist       r3     0     1
.line	1846	call          r2     2     2
.label	l59
.line	1846	call          r1     2     1
.line	1846	gettable      r1    r0   k46 ; k46 = "GridTexture"
.line	1846	test          r1     1
.line	1846	jmp            0   l78
.line	1846	gettable      r1    r0   k47 ; k47 = "MapCellCount"
.line	1846	test          r1     0
.line	1846	jmp            0   l78
.line	1846	gettable      r1    r0   k47 ; k47 = "MapCellCount"
.line	1846	gettabup      r2    u3   k48 ; k48 = "CreateHeatMapTexture"
.line	1846	move          r3    r1
.line	1846	self          r4    r0   k49 ; k49 = "GetTexGridPixelNum"
.line	1846	call          r4     2     2
.line	1846	loadk         r5   k50 ; k50 = 1
.line	1846	call          r2     4     2
.line	1846	settable      r0   k46    r2 ; k46 = "GridTexture"
.line	1846	self          r2    r0   k51 ; k51 = "GetGridColors"
.line	1846	call          r2     2     1
.line	1846	self          r2    r0   k52 ; k52 = "DelayUpdateGridColor" (truncated)
.line	1846	call          r2     2     1
.label	l78
.line	1846	gettable      r1    r0   k46 ; k46 = "GridTexture"
.line	1846	return        r1     2
.line	1846	return        r0     1
.line	1846	move          r0    r0
.line	1846	move          r0    r0
.line	1846	move          r0    r0
.line	1846	move          r0    r0
.line	1846	return        r0     1

.function	main/f94

.source	null
.linedefined	1857
.lastlinedefined	1871
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	24	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	30	true

.constant	k0	"bWriteLog"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	110
.constant	k4	170
.constant	k5	111
.constant	k6	53
.constant	k7	87
.constant	k8	15
.constant	k9	152
.constant	k10	165
.constant	k11	12
.constant	k12	54
.constant	k13	8
.constant	k14	36
.constant	k15	11
.constant	k16	55
.constant	k17	139
.constant	k18	234
.constant	k19	169
.constant	k20	171
.constant	k21	21
.constant	k22	23
.constant	k23	167
.constant	k24	5
.constant	k25	235
.constant	k26	146
.constant	k27	2
.constant	k28	48
.constant	k29	37
.constant	k30	63
.constant	k31	57
.constant	k32	210
.constant	k33	216
.constant	k34	168
.constant	k35	140
.constant	k36	45
.constant	k37	6
.constant	k38	34
.constant	k39	205
.constant	k40	143
.constant	k41	65
.constant	k42	183
.constant	k43	120
.constant	k44	39
.constant	k45	"GridColors"
.constant	k46	"import"
.constant	k47	102
.constant	k48	59
.constant	k49	81
.constant	k50	"MapCellCount"
.constant	k51	"slua"
.constant	k52	"Array"
.constant	k53	"UEnums"
.constant	k54	"EPropertyClass"
.constant	k55	"Struct"
.constant	k56	1
.constant	k57	"Add"
.constant	k58	"NeedColorTextureUpdate"
.constant	k59	true

.line	1857	getupval      r1    u0
.line	1857	gettabup      r2    u1    k0 ; k0 = "bWriteLog"
.line	1857	test          r2     0
.line	1857	jmp            0   l58
.line	1857	gettabup      r2    u1    k1 ; k1 = "table"
.line	1857	gettable      r2    r2    k2 ; k2 = "concat"
.line	1857	newtable      r3     1     0
.line	1857	getupval      r4    u2
.line	1857	loadk         r5    k3 ; k3 = 110
.line	1857	loadk         r6    k4 ; k4 = 170
.line	1857	loadk         r7    k5 ; k5 = 111
.line	1857	loadk         r8    k6 ; k6 = 53
.line	1857	loadk         r9    k7 ; k7 = 87
.line	1857	loadk        r10    k8 ; k8 = 15
.line	1857	loadk        r11    k9 ; k9 = 152
.line	1857	loadk        r12   k10 ; k10 = 165
.line	1857	loadk        r13   k11 ; k11 = 12
.line	1857	loadk        r14   k12 ; k12 = 54
.line	1857	loadk        r15   k13 ; k13 = 8
.line	1857	loadk        r16   k14 ; k14 = 36
.line	1857	loadk        r17   k15 ; k15 = 11
.line	1857	loadk        r18   k16 ; k16 = 55
.line	1857	loadk        r19   k17 ; k17 = 139
.line	1857	loadk        r20   k18 ; k18 = 234
.line	1857	loadk        r21   k19 ; k19 = 169
.line	1857	loadk        r22   k20 ; k20 = 171
.line	1857	loadk        r23   k21 ; k21 = 21
.line	1857	loadk        r24   k22 ; k22 = 23
.line	1857	loadk        r25   k23 ; k23 = 167
.line	1857	loadk        r26   k24 ; k24 = 5
.line	1857	loadk        r27   k25 ; k25 = 235
.line	1857	loadk        r28   k26 ; k26 = 146
.line	1857	loadk        r29   k27 ; k27 = 2
.line	1857	loadk        r30   k28 ; k28 = 48
.line	1857	loadk        r31    k8 ; k8 = 15
.line	1857	loadk        r32   k29 ; k29 = 37
.line	1857	loadk        r33   k30 ; k30 = 63
.line	1857	loadk        r34   k31 ; k31 = 57
.line	1857	loadk        r35   k32 ; k32 = 210
.line	1857	loadk        r36   k33 ; k33 = 216
.line	1857	loadk        r37   k34 ; k34 = 168
.line	1857	loadk        r38   k35 ; k35 = 140
.line	1857	loadk        r39   k36 ; k36 = 45
.line	1857	loadk        r40   k37 ; k37 = 6
.line	1857	loadk        r41    k4 ; k4 = 170
.line	1857	loadk        r42   k38 ; k38 = 34
.line	1857	loadk        r43   k39 ; k39 = 205
.line	1857	loadk        r44   k40 ; k40 = 143
.line	1857	call          r4    41     2
.line	1857	getupval      r5    u2
.line	1857	loadk         r6   k41 ; k41 = 65
.line	1857	loadk         r7   k42 ; k42 = 183
.line	1857	loadk         r8   k43 ; k43 = 120
.line	1857	loadk         r9   k44 ; k44 = 39
.line	1857	call          r5     5     0
.line	1857	setlist       r3     0     1
.line	1857	call          r2     2     2
.label	l58
.line	1857	call          r1     2     1
.line	1857	gettable      r1    r0   k45 ; k45 = "GridColors"
.line	1857	test          r1     1
.line	1857	jmp            0   l93
.line	1857	gettabup      r1    u1   k46 ; k46 = "import"
.line	1857	getupval      r2    u2
.line	1857	loadk         r3    k3 ; k3 = 110
.line	1857	loadk         r4   k42 ; k42 = 183
.line	1857	loadk         r5   k47 ; k47 = 102
.line	1857	loadk         r6   k48 ; k48 = 59
.line	1857	loadk         r7   k49 ; k49 = 81
.line	1857	call          r2     6     2
.line	1857	call          r1     2     2
.line	1857	gettable      r2    r0   k50 ; k50 = "MapCellCount"
.line	1857	gettabup      r3    u1   k51 ; k51 = "slua"
.line	1857	gettable      r3    r3   k52 ; k52 = "Array"
.line	1857	gettabup      r4    u1   k53 ; k53 = "UEnums"
.line	1857	gettable      r4    r4   k54 ; k54 = "EPropertyClass"
.line	1857	gettable      r4    r4   k55 ; k55 = "Struct"
.line	1857	move          r5    r1
.line	1857	call          r3     3     2
.line	1857	settable      r0   k45    r3 ; k45 = "GridColors"
.line	1857	gettable      r3    r0   k45 ; k45 = "GridColors"
.line	1857	test          r3     0
.line	1857	jmp            0   l92
.line	1857	loadk         r3   k56 ; k56 = 1
.line	1857	mul           r4    r2    r2
.line	1857	loadk         r5   k56 ; k56 = 1
.line	1857	move          r0    r0
.line	1857	gettable      r7    r0   k45 ; k45 = "GridColors"
.line	1857	self          r7    r7   k57 ; k57 = "Add"
.line	1857	getupval      r9    u3
.line	1857	call          r7     3     1
.line	1857	move          r0    r0
.label	l92
.line	1857	settable      r0   k58   k59 ; k59 = true
.label	l93
.line	1857	gettable      r1    r0   k45 ; k45 = "GridColors"
.line	1857	return        r1     2
.line	1857	return        r0     1
.line	1857	move          r0    r0
.line	1857	return        r0     1

.function	main/f95

.source	null
.linedefined	1873
.lastlinedefined	1882
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	24	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"bWriteLog"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	110
.constant	k4	170
.constant	k5	111
.constant	k6	53
.constant	k7	87
.constant	k8	15
.constant	k9	152
.constant	k10	165
.constant	k11	12
.constant	k12	54
.constant	k13	8
.constant	k14	36
.constant	k15	11
.constant	k16	55
.constant	k17	139
.constant	k18	234
.constant	k19	169
.constant	k20	171
.constant	k21	21
.constant	k22	23
.constant	k23	167
.constant	k24	5
.constant	k25	235
.constant	k26	146
.constant	k27	2
.constant	k28	48
.constant	k29	37
.constant	k30	63
.constant	k31	57
.constant	k32	210
.constant	k33	162
.constant	k34	156
.constant	k35	3
.constant	k36	18
.constant	k37	186
.constant	k38	7
.constant	k39	226
.constant	k40	140
.constant	k41	106
.constant	k42	99
.constant	k43	96
.constant	k44	9
.constant	k45	130
.constant	k46	175
.constant	k47	51
.constant	k48	"GridColors"
.constant	k49	"Num"
.constant	k50	0
.constant	k51	1
.constant	k52	"GetGridAssetCostColorByIndex"
.constant	k53	"Set"
.constant	k54	"NeedColorTextureUpdate"
.constant	k55	true

.line	1873	getupval      r1    u0
.line	1873	gettabup      r2    u1    k0 ; k0 = "bWriteLog"
.line	1873	test          r2     0
.line	1873	jmp            0   l63
.line	1873	gettabup      r2    u1    k1 ; k1 = "table"
.line	1873	gettable      r2    r2    k2 ; k2 = "concat"
.line	1873	newtable      r3     1     0
.line	1873	getupval      r4    u2
.line	1873	loadk         r5    k3 ; k3 = 110
.line	1873	loadk         r6    k4 ; k4 = 170
.line	1873	loadk         r7    k5 ; k5 = 111
.line	1873	loadk         r8    k6 ; k6 = 53
.line	1873	loadk         r9    k7 ; k7 = 87
.line	1873	loadk        r10    k8 ; k8 = 15
.line	1873	loadk        r11    k9 ; k9 = 152
.line	1873	loadk        r12   k10 ; k10 = 165
.line	1873	loadk        r13   k11 ; k11 = 12
.line	1873	loadk        r14   k12 ; k12 = 54
.line	1873	loadk        r15   k13 ; k13 = 8
.line	1873	loadk        r16   k14 ; k14 = 36
.line	1873	loadk        r17   k15 ; k15 = 11
.line	1873	loadk        r18   k16 ; k16 = 55
.line	1873	loadk        r19   k17 ; k17 = 139
.line	1873	loadk        r20   k18 ; k18 = 234
.line	1873	loadk        r21   k19 ; k19 = 169
.line	1873	loadk        r22   k20 ; k20 = 171
.line	1873	loadk        r23   k21 ; k21 = 21
.line	1873	loadk        r24   k22 ; k22 = 23
.line	1873	loadk        r25   k23 ; k23 = 167
.line	1873	loadk        r26   k24 ; k24 = 5
.line	1873	loadk        r27   k25 ; k25 = 235
.line	1873	loadk        r28   k26 ; k26 = 146
.line	1873	loadk        r29   k27 ; k27 = 2
.line	1873	loadk        r30   k28 ; k28 = 48
.line	1873	loadk        r31    k8 ; k8 = 15
.line	1873	loadk        r32   k29 ; k29 = 37
.line	1873	loadk        r33   k30 ; k30 = 63
.line	1873	loadk        r34   k31 ; k31 = 57
.line	1873	loadk        r35   k32 ; k32 = 210
.line	1873	loadk        r36   k32 ; k32 = 210
.line	1873	loadk        r37   k33 ; k33 = 162
.line	1873	loadk        r38   k34 ; k34 = 156
.line	1873	loadk        r39   k35 ; k35 = 3
.line	1873	loadk        r40   k36 ; k36 = 18
.line	1873	loadk        r41   k37 ; k37 = 186
.line	1873	loadk        r42   k38 ; k38 = 7
.line	1873	loadk        r43   k39 ; k39 = 226
.line	1873	loadk        r44   k40 ; k40 = 140
.line	1873	call          r4    41     2
.line	1873	getupval      r5    u2
.line	1873	loadk         r6   k41 ; k41 = 106
.line	1873	loadk         r7    k4 ; k4 = 170
.line	1873	loadk         r8   k42 ; k42 = 99
.line	1873	loadk         r9   k28 ; k28 = 48
.line	1873	loadk        r10   k43 ; k43 = 96
.line	1873	loadk        r11   k44 ; k44 = 9
.line	1873	loadk        r12   k45 ; k45 = 130
.line	1873	loadk        r13   k46 ; k46 = 175
.line	1873	loadk        r14   k47 ; k47 = 51
.line	1873	call          r5    10     0
.line	1873	setlist       r3     0     1
.line	1873	call          r2     2     2
.label	l63
.line	1873	call          r1     2     1
.line	1873	gettable      r1    r0   k48 ; k48 = "GridColors"
.line	1873	test          r1     0
.line	1873	jmp            0   l89
.line	1873	gettable      r1    r0   k48 ; k48 = "GridColors"
.line	1873	self          r1    r1   k49 ; k49 = "Num"
.line	1873	call          r1     2     2
.line	1873	lt             0   k50    r1 ; k50 = 0
.line	1873	jmp            0   l89
.line	1873	loadk         r1   k50 ; k50 = 0
.line	1873	gettable      r2    r0   k48 ; k48 = "GridColors"
.line	1873	self          r2    r2   k49 ; k49 = "Num"
.line	1873	call          r2     2     2
.line	1873	sub           r2    r2   k51 ; k51 = 1
.line	1873	loadk         r3   k51 ; k51 = 1
.line	1873	move          r0    r0
.line	1873	self          r5    r0   k52 ; k52 = "GetGridAssetCostColo" (truncated)
.line	1873	move          r7    r4
.line	1873	call          r5     3     2
.line	1873	gettable      r6    r0   k48 ; k48 = "GridColors"
.line	1873	self          r6    r6   k53 ; k53 = "Set"
.line	1873	move          r8    r4
.line	1873	move          r9    r5
.line	1873	call          r6     4     1
.line	1873	settable      r0   k54   k55 ; k55 = true
.line	1873	move          r0    r0
.label	l89
.line	1873	return        r0     1
.line	1873	move          r0    r0
.line	1873	move          r0    r0
.line	1873	move          r0    r0
.line	1873	move          r0    r0
.line	1873	return        r0     1

.function	main/f96

.source	null
.linedefined	1884
.lastlinedefined	1891
.numparams	2
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	24	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"bWriteLog"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	110
.constant	k4	170
.constant	k5	111
.constant	k6	53
.constant	k7	87
.constant	k8	15
.constant	k9	152
.constant	k10	165
.constant	k11	12
.constant	k12	54
.constant	k13	8
.constant	k14	36
.constant	k15	11
.constant	k16	55
.constant	k17	139
.constant	k18	234
.constant	k19	169
.constant	k20	171
.constant	k21	21
.constant	k22	23
.constant	k23	167
.constant	k24	5
.constant	k25	235
.constant	k26	146
.constant	k27	2
.constant	k28	48
.constant	k29	37
.constant	k30	63
.constant	k31	57
.constant	k32	210
.constant	k33	162
.constant	k34	156
.constant	k35	3
.constant	k36	18
.constant	k37	186
.constant	k38	1
.constant	k39	252
.constant	k40	137
.constant	k41	73
.constant	k42	155
.constant	k43	101
.constant	k44	56
.constant	k45	76
.constant	k46	20
.constant	k47	206
.constant	k48	51
.constant	k49	32
.constant	k50	157
.constant	k51	247
.constant	k52	253
.constant	k53	205
.constant	k54	9
.constant	k55	"tostring"
.constant	k56	"GridColors"
.constant	k57	"Num"
.constant	k58	0
.constant	k59	"GetGridAssetCostColorByIndex"
.constant	k60	"Set"
.constant	k61	"NeedColorTextureUpdate"
.constant	k62	true

.line	1884	getupval      r2    u0
.line	1884	gettabup      r3    u1    k0 ; k0 = "bWriteLog"
.line	1884	test          r3     0
.line	1884	jmp            0   l73
.line	1884	gettabup      r3    u1    k1 ; k1 = "table"
.line	1884	gettable      r3    r3    k2 ; k2 = "concat"
.line	1884	newtable      r4     1     0
.line	1884	getupval      r5    u2
.line	1884	loadk         r6    k3 ; k3 = 110
.line	1884	loadk         r7    k4 ; k4 = 170
.line	1884	loadk         r8    k5 ; k5 = 111
.line	1884	loadk         r9    k6 ; k6 = 53
.line	1884	loadk        r10    k7 ; k7 = 87
.line	1884	loadk        r11    k8 ; k8 = 15
.line	1884	loadk        r12    k9 ; k9 = 152
.line	1884	loadk        r13   k10 ; k10 = 165
.line	1884	loadk        r14   k11 ; k11 = 12
.line	1884	loadk        r15   k12 ; k12 = 54
.line	1884	loadk        r16   k13 ; k13 = 8
.line	1884	loadk        r17   k14 ; k14 = 36
.line	1884	loadk        r18   k15 ; k15 = 11
.line	1884	loadk        r19   k16 ; k16 = 55
.line	1884	loadk        r20   k17 ; k17 = 139
.line	1884	loadk        r21   k18 ; k18 = 234
.line	1884	loadk        r22   k19 ; k19 = 169
.line	1884	loadk        r23   k20 ; k20 = 171
.line	1884	loadk        r24   k21 ; k21 = 21
.line	1884	loadk        r25   k22 ; k22 = 23
.line	1884	loadk        r26   k23 ; k23 = 167
.line	1884	loadk        r27   k24 ; k24 = 5
.line	1884	loadk        r28   k25 ; k25 = 235
.line	1884	loadk        r29   k26 ; k26 = 146
.line	1884	loadk        r30   k27 ; k27 = 2
.line	1884	loadk        r31   k28 ; k28 = 48
.line	1884	loadk        r32    k8 ; k8 = 15
.line	1884	loadk        r33   k29 ; k29 = 37
.line	1884	loadk        r34   k30 ; k30 = 63
.line	1884	loadk        r35   k31 ; k31 = 57
.line	1884	loadk        r36   k32 ; k32 = 210
.line	1884	loadk        r37   k32 ; k32 = 210
.line	1884	loadk        r38   k33 ; k33 = 162
.line	1884	loadk        r39   k34 ; k34 = 156
.line	1884	loadk        r40   k35 ; k35 = 3
.line	1884	loadk        r41   k36 ; k36 = 18
.line	1884	loadk        r42   k37 ; k37 = 186
.line	1884	loadk        r43   k38 ; k38 = 1
.line	1884	loadk        r44   k39 ; k39 = 252
.line	1884	loadk        r45   k40 ; k40 = 137
.line	1884	call          r5    41     2
.line	1884	getupval      r6    u2
.line	1884	loadk         r7   k41 ; k41 = 73
.line	1884	loadk         r8   k42 ; k42 = 155
.line	1884	loadk         r9   k43 ; k43 = 101
.line	1884	loadk        r10   k44 ; k44 = 56
.line	1884	loadk        r11   k45 ; k45 = 76
.line	1884	loadk        r12   k46 ; k46 = 20
.line	1884	loadk        r13   k47 ; k47 = 206
.line	1884	loadk        r14   k23 ; k23 = 167
.line	1884	loadk        r15   k48 ; k48 = 51
.line	1884	loadk        r16   k28 ; k28 = 48
.line	1884	loadk        r17   k13 ; k13 = 8
.line	1884	loadk        r18   k13 ; k13 = 8
.line	1884	loadk        r19   k14 ; k14 = 36
.line	1884	loadk        r20   k49 ; k49 = 32
.line	1884	loadk        r21   k50 ; k50 = 157
.line	1884	loadk        r22   k51 ; k51 = 247
.line	1884	loadk        r23   k52 ; k52 = 253
.line	1884	loadk        r24   k53 ; k53 = 205
.line	1884	loadk        r25   k54 ; k54 = 9
.line	1884	call          r6    20     0
.line	1884	setlist       r4     0     1
.line	1884	call          r3     2     2
.label	l73
.line	1884	gettabup      r4    u1   k55 ; k55 = "tostring"
.line	1884	move          r5    r1
.line	1884	call          r4     2     0
.line	1884	call          r2     0     1
.line	1884	gettable      r2    r0   k56 ; k56 = "GridColors"
.line	1884	test          r2     0
.line	1884	jmp            0   l96
.line	1884	gettable      r2    r0   k56 ; k56 = "GridColors"
.line	1884	self          r2    r2   k57 ; k57 = "Num"
.line	1884	call          r2     2     2
.line	1884	lt             0    r1    r2
.line	1884	jmp            0   l96
.line	1884	le             0   k58    r1 ; k58 = 0
.line	1884	jmp            0   l96
.line	1884	self          r2    r0   k59 ; k59 = "GetGridAssetCostColo" (truncated)
.line	1884	move          r4    r1
.line	1884	call          r2     3     2
.line	1884	gettable      r3    r0   k56 ; k56 = "GridColors"
.line	1884	self          r3    r3   k60 ; k60 = "Set"
.line	1884	move          r5    r1
.line	1884	move          r6    r2
.line	1884	call          r3     4     1
.line	1884	settable      r0   k61   k62 ; k62 = true
.label	l96
.line	1884	return        r0     1
.line	1884	move          r0    r0
.line	1884	return        r0     1

.function	main/f97

.source	null
.linedefined	1893
.lastlinedefined	1901
.numparams	1
.is_vararg	0
.maxstacksize	6

.constant	k0	"DelayUpdateGridColorsTimerID"
.constant	k1	-1
.constant	k2	"AddGameTimer"
.constant	k3	"DelayUpdateGridColorsTime"

.line	1893	gettable      r1    r0    k0 ; k0 = "DelayUpdateGridColor" (truncated)
.line	1893	eq             1    r1    k1 ; k1 = -1
.line	1893	jmp            0    l5
.line	1893	return        r0     1
.label	l5
.line	1893	self          r1    r0    k2 ; k2 = "AddGameTimer"
.line	1893	gettable      r3    r0    k3 ; k3 = "DelayUpdateGridColor" (truncated)
.line	1893	loadbool      r4     0     0
.line	1893	closure       r5    f0
.line	1893	call          r1     5     2
.line	1893	settable      r0    k0    r1 ; k0 = "DelayUpdateGridColor" (truncated)
.line	1893	return        r0     1
.line	1893	move          r0    r0
.line	1893	move          r0    r0
.line	1893	return        r0     1

.function	main/f97/f0

.source	null
.linedefined	1897
.lastlinedefined	1900
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	true

.constant	k0	"DelayUpdateGridColorsTimerID"
.constant	k1	-1
.constant	k2	"UpdateGridColors"

.line	1897	settabup      u0    k0    k1 ; k1 = -1
.line	1897	getupval      r0    u0
.line	1897	self          r0    r0    k2 ; k2 = "UpdateGridColors"
.line	1897	call          r0     2     1
.line	1897	return        r0     1
.line	1897	move          r0    r0
.line	1897	move          r0    r0
.line	1897	return        r0     1

.function	main/f98

.source	null
.linedefined	1903
.lastlinedefined	1908
.numparams	1
.is_vararg	0
.maxstacksize	4

.constant	k0	"DelayUpdateGridColorsTimerID"
.constant	k1	-1
.constant	k2	"RemoveGameTimer"

.line	1903	gettable      r1    r0    k0 ; k0 = "DelayUpdateGridColor" (truncated)
.line	1903	test          r1     0
.line	1903	jmp            0   l11
.line	1903	gettable      r1    r0    k0 ; k0 = "DelayUpdateGridColor" (truncated)
.line	1903	eq             1    r1    k1 ; k1 = -1
.line	1903	jmp            0   l11
.line	1903	self          r1    r0    k2 ; k2 = "RemoveGameTimer"
.line	1903	gettable      r3    r0    k0 ; k0 = "DelayUpdateGridColor" (truncated)
.line	1903	call          r1     3     1
.line	1903	settable      r0    k0    k1 ; k1 = -1
.label	l11
.line	1903	return        r0     1
.line	1903	move          r0    r0
.line	1903	return        r0     1

.function	main/f99

.source	null
.linedefined	1910
.lastlinedefined	1919
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	24	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	7	true
.upvalue	"U4"	29	true

.constant	k0	"bWriteLog"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	110
.constant	k4	170
.constant	k5	111
.constant	k6	53
.constant	k7	87
.constant	k8	15
.constant	k9	152
.constant	k10	165
.constant	k11	12
.constant	k12	54
.constant	k13	8
.constant	k14	36
.constant	k15	11
.constant	k16	55
.constant	k17	139
.constant	k18	234
.constant	k19	169
.constant	k20	171
.constant	k21	21
.constant	k22	23
.constant	k23	167
.constant	k24	5
.constant	k25	235
.constant	k26	146
.constant	k27	2
.constant	k28	48
.constant	k29	37
.constant	k30	63
.constant	k31	57
.constant	k32	210
.constant	k33	202
.constant	k34	189
.constant	k35	156
.constant	k36	0
.constant	k37	166
.constant	k38	1
.constant	k39	252
.constant	k40	137
.constant	k41	73
.constant	k42	155
.constant	k43	101
.constant	k44	56
.constant	k45	76
.constant	k46	20
.constant	k47	157
.constant	k48	"GridColors"
.constant	k49	"NeedColorTextureUpdate"
.constant	k50	224
.constant	k51	25
.constant	k52	49
.constant	k53	46
.constant	k54	140
.constant	k55	"MapCellCount"
.constant	k56	"UpdateHeatMapTexture"
.constant	k57	"GridTexture"
.constant	k58	"ToFColor"
.constant	k59	"EventSystem"
.constant	k60	"postEvent"
.constant	k61	"EVENTTYPE_CREATIVE"
.constant	k62	"EVENTID_ASSET_COST_GRID_COLOR_CHANGED"
.constant	k63	false

.line	1910	getupval      r1    u0
.line	1910	gettabup      r2    u1    k0 ; k0 = "bWriteLog"
.line	1910	test          r2     0
.line	1910	jmp            0   l61
.line	1910	gettabup      r2    u1    k1 ; k1 = "table"
.line	1910	gettable      r2    r2    k2 ; k2 = "concat"
.line	1910	newtable      r3     1     0
.line	1910	getupval      r4    u2
.line	1910	loadk         r5    k3 ; k3 = 110
.line	1910	loadk         r6    k4 ; k4 = 170
.line	1910	loadk         r7    k5 ; k5 = 111
.line	1910	loadk         r8    k6 ; k6 = 53
.line	1910	loadk         r9    k7 ; k7 = 87
.line	1910	loadk        r10    k8 ; k8 = 15
.line	1910	loadk        r11    k9 ; k9 = 152
.line	1910	loadk        r12   k10 ; k10 = 165
.line	1910	loadk        r13   k11 ; k11 = 12
.line	1910	loadk        r14   k12 ; k12 = 54
.line	1910	loadk        r15   k13 ; k13 = 8
.line	1910	loadk        r16   k14 ; k14 = 36
.line	1910	loadk        r17   k15 ; k15 = 11
.line	1910	loadk        r18   k16 ; k16 = 55
.line	1910	loadk        r19   k17 ; k17 = 139
.line	1910	loadk        r20   k18 ; k18 = 234
.line	1910	loadk        r21   k19 ; k19 = 169
.line	1910	loadk        r22   k20 ; k20 = 171
.line	1910	loadk        r23   k21 ; k21 = 21
.line	1910	loadk        r24   k22 ; k22 = 23
.line	1910	loadk        r25   k23 ; k23 = 167
.line	1910	loadk        r26   k24 ; k24 = 5
.line	1910	loadk        r27   k25 ; k25 = 235
.line	1910	loadk        r28   k26 ; k26 = 146
.line	1910	loadk        r29   k27 ; k27 = 2
.line	1910	loadk        r30   k28 ; k28 = 48
.line	1910	loadk        r31    k8 ; k8 = 15
.line	1910	loadk        r32   k29 ; k29 = 37
.line	1910	loadk        r33   k30 ; k30 = 63
.line	1910	loadk        r34   k31 ; k31 = 57
.line	1910	loadk        r35   k32 ; k32 = 210
.line	1910	loadk        r36   k33 ; k33 = 202
.line	1910	loadk        r37   k34 ; k34 = 189
.line	1910	loadk        r38   k35 ; k35 = 156
.line	1910	loadk        r39   k15 ; k15 = 11
.line	1910	loadk        r40   k36 ; k36 = 0
.line	1910	loadk        r41   k37 ; k37 = 166
.line	1910	loadk        r42   k38 ; k38 = 1
.line	1910	loadk        r43   k39 ; k39 = 252
.line	1910	loadk        r44   k40 ; k40 = 137
.line	1910	call          r4    41     2
.line	1910	getupval      r5    u2
.line	1910	loadk         r6   k41 ; k41 = 73
.line	1910	loadk         r7   k42 ; k42 = 155
.line	1910	loadk         r8   k43 ; k43 = 101
.line	1910	loadk         r9   k44 ; k44 = 56
.line	1910	loadk        r10   k45 ; k45 = 76
.line	1910	loadk        r11   k46 ; k46 = 20
.line	1910	loadk        r12   k47 ; k47 = 157
.line	1910	call          r5     8     0
.line	1910	setlist       r3     0     1
.line	1910	call          r2     2     2
.label	l61
.line	1910	call          r1     2     1
.line	1910	gettable      r1    r0   k48 ; k48 = "GridColors"
.line	1910	test          r1     0
.line	1910	jmp            0  l159
.line	1910	gettable      r1    r0   k49 ; k49 = "NeedColorTextureUpda" (truncated)
.line	1910	test          r1     0
.line	1910	jmp            0  l159
.line	1910	getupval      r1    u0
.line	1910	gettabup      r2    u1    k0 ; k0 = "bWriteLog"
.line	1910	test          r2     0
.line	1910	jmp            0  l137
.line	1910	gettabup      r2    u1    k1 ; k1 = "table"
.line	1910	gettable      r2    r2    k2 ; k2 = "concat"
.line	1910	newtable      r3     1     0
.line	1910	getupval      r4    u2
.line	1910	loadk         r5    k3 ; k3 = 110
.line	1910	loadk         r6    k4 ; k4 = 170
.line	1910	loadk         r7    k5 ; k5 = 111
.line	1910	loadk         r8    k6 ; k6 = 53
.line	1910	loadk         r9    k7 ; k7 = 87
.line	1910	loadk        r10    k8 ; k8 = 15
.line	1910	loadk        r11    k9 ; k9 = 152
.line	1910	loadk        r12   k10 ; k10 = 165
.line	1910	loadk        r13   k11 ; k11 = 12
.line	1910	loadk        r14   k12 ; k12 = 54
.line	1910	loadk        r15   k13 ; k13 = 8
.line	1910	loadk        r16   k14 ; k14 = 36
.line	1910	loadk        r17   k15 ; k15 = 11
.line	1910	loadk        r18   k16 ; k16 = 55
.line	1910	loadk        r19   k17 ; k17 = 139
.line	1910	loadk        r20   k18 ; k18 = 234
.line	1910	loadk        r21   k19 ; k19 = 169
.line	1910	loadk        r22   k20 ; k20 = 171
.line	1910	loadk        r23   k21 ; k21 = 21
.line	1910	loadk        r24   k22 ; k22 = 23
.line	1910	loadk        r25   k23 ; k23 = 167
.line	1910	loadk        r26   k24 ; k24 = 5
.line	1910	loadk        r27   k25 ; k25 = 235
.line	1910	loadk        r28   k26 ; k26 = 146
.line	1910	loadk        r29   k27 ; k27 = 2
.line	1910	loadk        r30   k28 ; k28 = 48
.line	1910	loadk        r31    k8 ; k8 = 15
.line	1910	loadk        r32   k29 ; k29 = 37
.line	1910	loadk        r33   k30 ; k30 = 63
.line	1910	loadk        r34   k31 ; k31 = 57
.line	1910	loadk        r35   k32 ; k32 = 210
.line	1910	loadk        r36   k33 ; k33 = 202
.line	1910	loadk        r37   k34 ; k34 = 189
.line	1910	loadk        r38   k35 ; k35 = 156
.line	1910	loadk        r39   k15 ; k15 = 11
.line	1910	loadk        r40   k36 ; k36 = 0
.line	1910	loadk        r41   k37 ; k37 = 166
.line	1910	loadk        r42   k38 ; k38 = 1
.line	1910	loadk        r43   k39 ; k39 = 252
.line	1910	loadk        r44   k40 ; k40 = 137
.line	1910	call          r4    41     2
.line	1910	getupval      r5    u2
.line	1910	loadk         r6   k41 ; k41 = 73
.line	1910	loadk         r7   k42 ; k42 = 155
.line	1910	loadk         r8   k43 ; k43 = 101
.line	1910	loadk         r9   k44 ; k44 = 56
.line	1910	loadk        r10   k45 ; k45 = 76
.line	1910	loadk        r11   k46 ; k46 = 20
.line	1910	loadk        r12   k47 ; k47 = 157
.line	1910	loadk        r13   k50 ; k50 = 224
.line	1910	loadk        r14   k29 ; k29 = 37
.line	1910	loadk        r15   k12 ; k12 = 54
.line	1910	loadk        r16   k51 ; k51 = 25
.line	1910	loadk        r17   k52 ; k52 = 49
.line	1910	loadk        r18   k53 ; k53 = 46
.line	1910	loadk        r19   k29 ; k29 = 37
.line	1910	loadk        r20   k54 ; k54 = 140
.line	1910	loadk        r21   k18 ; k18 = 234
.line	1910	call          r5    17     0
.line	1910	setlist       r3     0     1
.line	1910	call          r2     2     2
.label	l137
.line	1910	call          r1     2     1
.line	1910	gettable      r1    r0   k55 ; k55 = "MapCellCount"
.line	1910	gettabup      r2    u3   k56 ; k56 = "UpdateHeatMapTexture"
.line	1910	gettable      r3    r0   k57 ; k57 = "GridTexture"
.line	1910	move          r4    r1
.line	1910	loadk         r5   k38 ; k38 = 1
.line	1910	getupval      r6    u4
.line	1910	self          r6    r6   k58 ; k58 = "ToFColor"
.line	1910	loadbool      r8     0     0
.line	1910	call          r6     3     2
.line	1910	gettable      r7    r0   k48 ; k48 = "GridColors"
.line	1910	loadk         r8   k36 ; k36 = 0
.line	1910	loadk         r9   k36 ; k36 = 0
.line	1910	sub          r10    r1   k38 ; k38 = 1
.line	1910	sub          r11    r1   k38 ; k38 = 1
.line	1910	call          r2    10     1
.line	1910	gettabup      r2    u1   k59 ; k59 = "EventSystem"
.line	1910	self          r2    r2   k60 ; k60 = "postEvent"
.line	1910	gettabup      r4    u1   k61 ; k61 = "EVENTTYPE_CREATIVE"
.line	1910	gettabup      r5    u1   k62 ; k62 = "EVENTID_ASSET_COST_G" (truncated)
.line	1910	call          r2     4     1
.line	1910	settable      r0   k49   k63 ; k63 = false
.label	l159
.line	1910	return        r0     1
.line	1910	move          r0    r0
.line	1910	move          r0    r0
.line	1910	gettabup      r0    u1   k56 ; k56 = "UpdateHeatMapTexture"
.line	1910	return        r0     1

.function	main/f100

.source	null
.linedefined	1921
.lastlinedefined	1952
.numparams	2
.is_vararg	0
.maxstacksize	12

.upvalue	"_ENV"	0	false
.upvalue	"U1"	32	true

.constant	k0	"GridColors"
.constant	k1	"CurFullCostIndex"
.constant	k2	"ModifyGridColor"
.constant	k3	"GetNearCellIndexList"
.constant	k4	"pairs"
.constant	k5	"Num"
.constant	k6	0
.constant	k7	nil
.constant	k8	"Set"
.constant	k9	4
.constant	k10	"NeedColorTextureUpdate"
.constant	k11	true
.constant	k12	"DelayUpdateGridColors"

.line	1921	gettable      r2    r0    k0 ; k0 = "GridColors"
.line	1921	test          r2     0
.line	1921	jmp            0   l74
.line	1921	gettable      r2    r0    k1 ; k1 = "CurFullCostIndex"
.line	1921	test          r2     0
.line	1921	jmp            0   l35
.line	1921	gettable      r2    r0    k1 ; k1 = "CurFullCostIndex"
.line	1921	eq             1    r2    r1
.line	1921	jmp            0   l34
.line	1921	self          r2    r0    k2 ; k2 = "ModifyGridColor"
.line	1921	gettable      r4    r0    k1 ; k1 = "CurFullCostIndex"
.line	1921	call          r2     3     1
.line	1921	self          r2    r0    k3 ; k3 = "GetNearCellIndexList"
.line	1921	gettable      r4    r0    k1 ; k1 = "CurFullCostIndex"
.line	1921	call          r2     3     2
.line	1921	gettabup      r3    u0    k4 ; k4 = "pairs"
.line	1921	move          r4    r2
.line	1921	call          r3     2     4
.line	1921	jmp            0   l30
.line	1921	gettable      r8    r0    k0 ; k0 = "GridColors"
.line	1921	self          r8    r8    k5 ; k5 = "Num"
.line	1921	call          r8     2     2
.line	1921	lt             0    r7    r8
.line	1921	jmp            0   l30
.line	1921	le             0    k6    r7 ; k6 = 0
.line	1921	jmp            0   l30
.line	1921	self          r8    r0    k2 ; k2 = "ModifyGridColor"
.line	1921	move         r10    r7
.line	1921	call          r8     3     1
.label	l30
.line	1921	move          r0    r0
.line	1921	move          r0    r0
.line	1921	settable      r0    k1    k7 ; k7 = nil
.line	1921	jmp            0   l35
.label	l34
.line	1921	return        r0     1
.label	l35
.line	1921	lt             0    k6    r1 ; k6 = 0
.line	1921	jmp            0   l72
.line	1921	settable      r0    k1    r1 ; k1 = "CurFullCostIndex"
.line	1921	gettable      r2    r0    k0 ; k0 = "GridColors"
.line	1921	self          r2    r2    k5 ; k5 = "Num"
.line	1921	call          r2     2     2
.line	1921	lt             0    r1    r2
.line	1921	jmp            0   l50
.line	1921	le             0    k6    r1 ; k6 = 0
.line	1921	jmp            0   l50
.line	1921	gettable      r2    r0    k0 ; k0 = "GridColors"
.line	1921	self          r2    r2    k8 ; k8 = "Set"
.line	1921	move          r4    r1
.line	1921	gettabup      r5    u1    k9 ; k9 = 4
.line	1921	call          r2     4     1
.label	l50
.line	1921	self          r2    r0    k3 ; k3 = "GetNearCellIndexList"
.line	1921	move          r4    r1
.line	1921	call          r2     3     2
.line	1921	gettabup      r3    u0    k4 ; k4 = "pairs"
.line	1921	move          r4    r2
.line	1921	call          r3     2     4
.line	1921	jmp            0   l69
.line	1921	gettable      r8    r0    k0 ; k0 = "GridColors"
.line	1921	self          r8    r8    k5 ; k5 = "Num"
.line	1921	call          r8     2     2
.line	1921	lt             0    r7    r8
.line	1921	jmp            0   l69
.line	1921	le             0    k6    r7 ; k6 = 0
.line	1921	jmp            0   l69
.line	1921	gettable      r8    r0    k0 ; k0 = "GridColors"
.line	1921	self          r8    r8    k8 ; k8 = "Set"
.line	1921	move         r10    r7
.line	1921	gettabup     r11    u1    k9 ; k9 = 4
.line	1921	call          r8     4     1
.label	l69
.line	1921	move          r0    r0
.line	1921	move          r0    r0
.line	1921	settable      r0   k10   k11 ; k11 = true
.label	l72
.line	1921	self          r2    r0   k12 ; k12 = "DelayUpdateGridColor" (truncated)
.line	1921	call          r2     2     1
.label	l74
.line	1921	return        r0     1
.line	1921	move          r0    r0
.line	1921	move          r0    r0
.line	1921	move          r0    r0
.line	1921	return        r0     1

.function	main/f101

.source	null
.linedefined	1954
.lastlinedefined	1963
.numparams	2
.is_vararg	0
.maxstacksize	12

.upvalue	"_ENV"	0	false

.constant	k0	"GetInstanceManager"
.constant	k1	"GetInstanceTree"
.constant	k2	"pairs"
.constant	k3	"AssetId"
.constant	k4	3101066
.constant	k5	"table"
.constant	k6	"insert"

.line	1954	newtable      r2     0     0
.line	1954	gettabup      r3    u0    k0 ; k0 = "GetInstanceManager"
.line	1954	call          r3     1     2
.line	1954	self          r3    r3    k1 ; k1 = "GetInstanceTree"
.line	1954	call          r3     2     2
.line	1954	gettabup      r4    u0    k2 ; k2 = "pairs"
.line	1954	move          r5    r3
.line	1954	call          r4     2     4
.line	1954	jmp            0   l22
.line	1954	test          r8     0
.line	1954	jmp            0   l22
.line	1954	gettable      r9    r8    k3 ; k3 = "AssetId"
.line	1954	eq             0    r9    k4 ; k4 = 3101066
.line	1954	jmp            0   l22
.line	1954	eq             1    r7    r1
.line	1954	jmp            0   l22
.line	1954	gettabup      r9    u0    k5 ; k5 = "table"
.line	1954	gettable      r9    r9    k6 ; k6 = "insert"
.line	1954	move         r10    r2
.line	1954	move         r11    r8
.line	1954	call          r9     3     1
.label	l22
.line	1954	move          r0    r0
.line	1954	move          r0    r0
.line	1954	return        r2     2
.line	1954	return        r0     1
.line	1954	move          r0    r0
.line	1954	move          r0    r0
.line	1954	move          r0    r0
.line	1954	move          r0    r0
.line	1954	return        r0     1

.function	main/f102

.source	null
.linedefined	1965
.lastlinedefined	1972
.numparams	1
.is_vararg	0
.maxstacksize	33

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"GetAllGroupManipulator"
.constant	k1	0
.constant	k2	1
.constant	k3	"GetInstanceManager"
.constant	k4	"GetInstanceValue"
.constant	k5	"InstanceId"
.constant	k6	106
.constant	k7	170
.constant	k8	101
.constant	k9	33
.constant	k10	83
.constant	k11	43
.constant	k12	143
.constant	k13	174
.constant	k14	40
.constant	k15	41
.constant	k16	25
.constant	k17	45
.constant	k18	48
.constant	k19	151
.constant	k20	253
.constant	k21	243
.constant	k22	165
.constant	k23	15
.constant	k24	16
.constant	k25	182
.constant	k26	46
.constant	k27	210
.constant	k28	153
.constant	k29	34
.constant	k30	61
.constant	k31	"SetGroupManipulatorMutexList"

.line	1965	self          r1    r0    k0 ; k0 = "GetAllGroupManipulat" (truncated)
.line	1965	call          r1     2     2
.line	1965	test          r1     0
.line	1965	jmp            0   l47
.line	1965	len           r2    r1
.line	1965	lt             0    k1    r2 ; k1 = 0
.line	1965	jmp            0   l47
.line	1965	gettable      r2    r1    k2 ; k2 = 1
.line	1965	gettabup      r3    u0    k3 ; k3 = "GetInstanceManager"
.line	1965	call          r3     1     2
.line	1965	self          r3    r3    k4 ; k4 = "GetInstanceValue"
.line	1965	gettable      r5    r2    k5 ; k5 = "InstanceId"
.line	1965	getupval      r6    u1
.line	1965	loadk         r7    k6 ; k6 = 106
.line	1965	loadk         r8    k7 ; k7 = 170
.line	1965	loadk         r9    k8 ; k8 = 101
.line	1965	loadk        r10    k9 ; k9 = 33
.line	1965	loadk        r11   k10 ; k10 = 83
.line	1965	loadk        r12   k11 ; k11 = 43
.line	1965	loadk        r13   k12 ; k12 = 143
.line	1965	loadk        r14   k13 ; k13 = 174
.line	1965	loadk        r15   k14 ; k14 = 40
.line	1965	loadk        r16   k15 ; k15 = 41
.line	1965	loadk        r17   k16 ; k16 = 25
.line	1965	loadk        r18   k17 ; k17 = 45
.line	1965	loadk        r19   k11 ; k11 = 43
.line	1965	loadk        r20   k18 ; k18 = 48
.line	1965	loadk        r21   k19 ; k19 = 151
.line	1965	loadk        r22   k20 ; k20 = 253
.line	1965	loadk        r23   k21 ; k21 = 243
.line	1965	loadk        r24   k22 ; k22 = 165
.line	1965	loadk        r25   k23 ; k23 = 15
.line	1965	loadk        r26   k24 ; k24 = 16
.line	1965	loadk        r27   k25 ; k25 = 182
.line	1965	loadk        r28   k26 ; k26 = 46
.line	1965	loadk        r29   k27 ; k27 = 210
.line	1965	loadk        r30   k28 ; k28 = 153
.line	1965	loadk        r31   k29 ; k29 = 34
.line	1965	loadk        r32   k30 ; k30 = 61
.line	1965	call          r6    27     2
.line	1965	loadbool      r7     1     0
.line	1965	move          r8    r2
.line	1965	call          r3     6     2
.line	1965	self          r4    r0   k31 ; k31 = "SetGroupManipulatorM" (truncated)
.line	1965	move          r6    r3
.line	1965	call          r4     3     1
.label	l47
.line	1965	return        r0     1
.line	1965	move          r0    r0
.line	1965	move          r0    r0
.line	1965	return        r0     1

.function	main/f103

.source	null
.linedefined	1974
.lastlinedefined	1985
.numparams	2
.is_vararg	0
.maxstacksize	13

.upvalue	"_ENV"	0	false

.constant	k0	"MutexLists"
.constant	k1	"MutexMap"
.constant	k2	0
.constant	k3	"ipairs"
.constant	k4	"List"
.constant	k5	true
.constant	k6	"CalcMutexListCost"

.line	1974	testset       r2    r1     1
.line	1974	jmp            0    l4
.line	1974	newtable      r2     0     0
.label	l4
.line	1974	settable      r0    k0    r2 ; k0 = "MutexLists"
.line	1974	newtable      r2     0     0
.line	1974	settable      r0    k1    r2 ; k1 = "MutexMap"
.line	1974	gettable      r2    r0    k0 ; k0 = "MutexLists"
.line	1974	len           r2    r2
.line	1974	lt             0    k2    r2 ; k2 = 0
.line	1974	jmp            0   l25
.line	1974	gettabup      r2    u0    k3 ; k3 = "ipairs"
.line	1974	gettable      r3    r0    k0 ; k0 = "MutexLists"
.line	1974	call          r2     2     4
.line	1974	jmp            0   l23
.line	1974	gettabup      r7    u0    k3 ; k3 = "ipairs"
.line	1974	gettable      r8    r6    k4 ; k4 = "List"
.line	1974	call          r7     2     4
.line	1974	jmp            0   l21
.line	1974	gettable     r12    r0    k1 ; k1 = "MutexMap"
.line	1974	settable     r12   r11    k5 ; k5 = true
.label	l21
.line	1974	move          r0    r0
.line	1974	move          r0    r0
.label	l23
.line	1974	move          r0    r0
.line	1974	move          r0    r0
.label	l25
.line	1974	self          r2    r0    k6 ; k6 = "CalcMutexListCost"
.line	1974	call          r2     2     1
.line	1974	return        r0     1
.line	1974	move          r0    r0
.line	1974	move          r0    r0
.line	1974	return        r0     1

.function	main/f104

.source	null
.linedefined	1987
.lastlinedefined	1993
.numparams	2
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	0	false

.constant	k0	"GetGroupManager"
.constant	k1	"GetGroupId"
.constant	k2	"MutexMap"

.line	1987	gettabup      r2    u0    k0 ; k0 = "GetGroupManager"
.line	1987	call          r2     1     2
.line	1987	self          r2    r2    k1 ; k1 = "GetGroupId"
.line	1987	move          r4    r1
.line	1987	call          r2     3     2
.line	1987	test          r2     0
.line	1987	jmp            0   l17
.line	1987	gettable      r3    r0    k2 ; k2 = "MutexMap"
.line	1987	test          r3     0
.line	1987	jmp            0   l17
.line	1987	gettable      r3    r0    k2 ; k2 = "MutexMap"
.line	1987	gettable      r3    r3    r2
.line	1987	test          r3     0
.line	1987	jmp            0   l17
.line	1987	loadbool      r3     1     0
.line	1987	return        r3     2
.label	l17
.line	1987	loadbool      r3     0     0
.line	1987	return        r3     2
.line	1987	return        r0     1
.line	1987	move          r0    r0
.line	1987	move          r0    r0
.line	1987	return        r0     1

.function	main/f105

.source	null
.linedefined	1995
.lastlinedefined	2042
.numparams	2
.is_vararg	0
.maxstacksize	23

.upvalue	"_ENV"	0	false
.upvalue	"U1"	35	true

.constant	k0	"NoNeedInstanceIds"
.constant	k1	"ipairs"
.constant	k2	"MutexLists"
.constant	k3	0
.constant	k4	"List"
.constant	k5	"CalcGroupAssetCost"
.constant	k6	"max"
.constant	k7	"pairs"
.constant	k8	nil
.constant	k9	"GetInstanceCostInfo"
.constant	k10	"GridIndex"
.constant	k11	true
.constant	k12	"CalAlwaysLoadAssetCost"
.constant	k13	"CalGridNoAlwaysLoadAssetCost"
.constant	k14	"UpdateAffectedGridAssetCost"
.constant	k15	"ModifyAllGridColor"
.constant	k16	"DelayUpdateGridColors"

.line	1995	newtable      r2     0     0
.line	1995	newtable      r3     0     0
.line	1995	gettable      r4    r0    k0 ; k0 = "NoNeedInstanceIds"
.line	1995	newtable      r5     0     0
.line	1995	settable      r0    k0    r5 ; k0 = "NoNeedInstanceIds"
.line	1995	gettabup      r5    u0    k1 ; k1 = "ipairs"
.line	1995	gettable      r6    r0    k2 ; k2 = "MutexLists"
.line	1995	call          r5     2     4
.line	1995	jmp            0   l36
.line	1995	loadk        r10    k3 ; k3 = 0
.line	1995	loadnil      r11     0
.line	1995	gettabup     r12    u0    k1 ; k1 = "ipairs"
.line	1995	gettable     r13    r9    k4 ; k4 = "List"
.line	1995	call         r12     2     4
.line	1995	jmp            0   l31
.line	1995	eq             1   r16    r1
.line	1995	jmp            0   l31
.line	1995	self         r17    r0    k5 ; k5 = "CalcGroupAssetCost"
.line	1995	loadnil      r19     0
.line	1995	move         r20   r16
.line	1995	call         r17     4     4
.line	1995	gettabup     r20    u1    k6 ; k6 = "max"
.line	1995	move         r21   r17
.line	1995	move         r22   r18
.line	1995	call         r20     3     2
.line	1995	lt             0   r10   r20
.line	1995	jmp            0   l30
.line	1995	move         r10   r20
.line	1995	move         r11   r16
.label	l30
.line	1995	settable      r3   r16   r19
.label	l31
.line	1995	move          r0    r0
.line	1995	move          r0    r0
.line	1995	test         r11     0
.line	1995	jmp            0   l36
.line	1995	settable      r2   r11   r10
.label	l36
.line	1995	move          r0    r0
.line	1995	move          r0    r0
.line	1995	gettabup      r5    u0    k7 ; k7 = "pairs"
.line	1995	move          r6    r3
.line	1995	call          r5     2     4
.line	1995	jmp            0   l56
.line	1995	gettable     r10    r2    r8
.line	1995	eq             0   r10    k8 ; k8 = nil
.line	1995	jmp            0   l56
.line	1995	gettabup     r10    u0    k7 ; k7 = "pairs"
.line	1995	move         r11    r9
.line	1995	call         r10     2     4
.line	1995	jmp            0   l54
.line	1995	self         r15    r0    k9 ; k9 = "GetInstanceCostInfo"
.line	1995	move         r17   r14
.line	1995	call         r15     3     2
.line	1995	gettable     r16    r0    k0 ; k0 = "NoNeedInstanceIds"
.line	1995	settable     r16   r14   r15
.label	l54
.line	1995	move          r0    r0
.line	1995	move          r0    r0
.label	l56
.line	1995	move          r0    r0
.line	1995	move          r0    r0
.line	1995	newtable      r5     0     0
.line	1995	eq             1    r4    k8 ; k8 = nil
.line	1995	jmp            0   l69
.line	1995	gettabup      r6    u0    k7 ; k7 = "pairs"
.line	1995	move          r7    r4
.line	1995	call          r6     2     4
.line	1995	jmp            0   l67
.line	1995	gettable     r11   r10   k10 ; k10 = "GridIndex"
.line	1995	settable      r5   r11   k11 ; k11 = true
.label	l67
.line	1995	move          r0    r0
.line	1995	move          r0    r0
.label	l69
.line	1995	gettabup      r6    u0    k7 ; k7 = "pairs"
.line	1995	gettable      r7    r0    k0 ; k0 = "NoNeedInstanceIds"
.line	1995	call          r6     2     4
.line	1995	jmp            0   l75
.line	1995	gettable     r11   r10   k10 ; k10 = "GridIndex"
.line	1995	settable      r5   r11   k11 ; k11 = true
.label	l75
.line	1995	move          r0    r0
.line	1995	move          r0    r0
.line	1995	self          r6    r0   k12 ; k12 = "CalAlwaysLoadAssetCo" (truncated)
.line	1995	call          r6     2     1
.line	1995	gettabup      r6    u0    k7 ; k7 = "pairs"
.line	1995	move          r7    r5
.line	1995	call          r6     2     4
.line	1995	jmp            0   l89
.line	1995	self         r11    r0   k13 ; k13 = "CalGridNoAlwaysLoadA" (truncated)
.line	1995	move         r13    r9
.line	1995	call         r11     3     1
.line	1995	self         r11    r0   k14 ; k14 = "UpdateAffectedGridAs" (truncated)
.line	1995	move         r13    r9
.line	1995	call         r11     3     1
.label	l89
.line	1995	move          r0    r0
.line	1995	move          r0    r0
.line	1995	self          r6    r0   k15 ; k15 = "ModifyAllGridColor"
.line	1995	call          r6     2     1
.line	1995	self          r6    r0   k16 ; k16 = "DelayUpdateGridColor" (truncated)
.line	1995	call          r6     2     1
.line	1995	return        r0     1
.line	1995	move          r0    r0
.line	1995	move          r0    r0
.line	1995	move          r0    r0
.line	1995	return        r0     1

.function	main/f106

.source	null
.linedefined	2044
.lastlinedefined	2049
.numparams	2
.is_vararg	0
.maxstacksize	3

.constant	k0	"NoNeedInstanceIds"

.line	2044	gettable      r2    r0    k0 ; k0 = "NoNeedInstanceIds"
.line	2044	test          r2     0
.line	2044	jmp            0   l10
.line	2044	gettable      r2    r0    k0 ; k0 = "NoNeedInstanceIds"
.line	2044	gettable      r2    r2    r1
.line	2044	test          r2     0
.line	2044	jmp            0   l10
.line	2044	loadbool      r2     1     0
.line	2044	return        r2     2
.label	l10
.line	2044	loadbool      r2     0     0
.line	2044	return        r2     2
.line	2044	return        r0     1
.line	2044	move          r0    r0
.line	2044	move          r0    r0
.line	2044	return        r0     1

.function	main/f107

.source	null
.linedefined	2051
.lastlinedefined	2076
.numparams	1
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	0
.constant	k1	"GetGameParameterManager"
.constant	k2	"GetGameParameter"
.constant	k3	79
.constant	k4	145
.constant	k5	121
.constant	k6	17
.constant	k7	91
.constant	k8	18
.constant	k9	156
.constant	k10	165
.constant	k11	44
.constant	k12	60
.constant	k13	33
.constant	k14	46
.constant	k15	"Value"
.constant	k16	96
.constant	k17	185
.constant	k18	114
.constant	k19	23
.constant	k20	76
.constant	k21	21
.constant	k22	154
.constant	k23	"print"
.constant	k24	"bWriteLog"
.constant	k25	"table"
.constant	k26	"concat"
.constant	k27	110
.constant	k28	170
.constant	k29	111
.constant	k30	53
.constant	k31	87
.constant	k32	15
.constant	k33	152
.constant	k34	12
.constant	k35	54
.constant	k36	8
.constant	k37	36
.constant	k38	11
.constant	k39	55
.constant	k40	139
.constant	k41	234
.constant	k42	169
.constant	k43	171
.constant	k44	167
.constant	k45	5
.constant	k46	235
.constant	k47	146
.constant	k48	2
.constant	k49	48
.constant	k50	37
.constant	k51	63
.constant	k52	57
.constant	k53	210
.constant	k54	214
.constant	k55	190
.constant	k56	189
.constant	k57	177
.constant	k58	35
.constant	k59	227
.constant	k60	133
.constant	k61	122
.constant	k62	116
.constant	k63	7
.constant	k64	150
.constant	k65	131
.constant	k66	42
.constant	k67	24
.constant	k68	97
.constant	k69	45
.constant	k70	148
.constant	k71	70
.constant	k72	30
.constant	k73	178
.constant	k74	52
.constant	k75	9
.constant	k76	32
.constant	k77	157
.constant	k78	208
.constant	k79	174
.constant	k80	159
.constant	k81	19
.constant	k82	16
.constant	k83	176
.constant	k84	62
.constant	k85	51
.constant	k86	141
.constant	k87	251
.constant	k88	160
.constant	k89	151
.constant	k90	14
.constant	k91	249
.constant	k92	137
.constant	k93	89
.constant	k94	187
.constant	k95	98
.constant	k96	69
.constant	k97	130
.constant	k98	179
.constant	k99	180
.constant	k100	109
.constant	k101	"CDataTable"
.constant	k102	"GetTable"
.constant	k103	120
.constant	k104	73
.constant	k105	4
.constant	k106	20
.constant	k107	136
.constant	k108	175
.constant	k109	13
.constant	k110	47
.constant	k111	41
.constant	k112	224
.constant	k113	"MinCost"

.line	2051	loadbool      r1     0     0
.line	2051	loadk         r2    k0 ; k0 = 0
.line	2051	gettabup      r3    u0    k1 ; k1 = "GetGameParameterMana" (truncated)
.line	2051	test          r3     0
.line	2051	jmp            0    l8
.line	2051	gettabup      r3    u0    k1 ; k1 = "GetGameParameterMana" (truncated)
.line	2051	call          r3     1     2
.label	l8
.line	2051	test          r3     0
.line	2051	jmp            0  l191
.line	2051	self          r4    r3    k2 ; k2 = "GetGameParameter"
.line	2051	getupval      r6    u1
.line	2051	loadk         r7    k3 ; k3 = 79
.line	2051	loadk         r8    k4 ; k4 = 145
.line	2051	loadk         r9    k5 ; k5 = 121
.line	2051	loadk        r10    k6 ; k6 = 17
.line	2051	loadk        r11    k7 ; k7 = 91
.line	2051	loadk        r12    k8 ; k8 = 18
.line	2051	loadk        r13    k9 ; k9 = 156
.line	2051	loadk        r14   k10 ; k10 = 165
.line	2051	loadk        r15   k11 ; k11 = 44
.line	2051	loadk        r16   k12 ; k12 = 60
.line	2051	loadk        r17   k13 ; k13 = 33
.line	2051	loadk        r18   k14 ; k14 = 46
.line	2051	loadk        r19   k14 ; k14 = 46
.line	2051	loadk        r20   k13 ; k13 = 33
.line	2051	call          r6    15     2
.line	2051	call          r4     3     2
.line	2051	test          r4     0
.line	2051	jmp            0   l33
.line	2051	gettable      r5    r4   k15 ; k15 = "Value"
.line	2051	testset       r1    r5     1
.line	2051	jmp            0   l34
.label	l33
.line	2051	loadbool      r1     0     0
.label	l34
.line	2051	self          r5    r3    k2 ; k2 = "GetGameParameter"
.line	2051	getupval      r7    u1
.line	2051	loadk         r8   k16 ; k16 = 96
.line	2051	loadk         r9   k17 ; k17 = 185
.line	2051	loadk        r10   k18 ; k18 = 114
.line	2051	loadk        r11   k19 ; k19 = 23
.line	2051	loadk        r12   k20 ; k20 = 76
.line	2051	loadk        r13   k21 ; k21 = 21
.line	2051	loadk        r14   k22 ; k22 = 154
.line	2051	call          r7     8     2
.line	2051	call          r5     3     2
.line	2051	test          r5     1
.line	2051	jmp            0  l117
.line	2051	gettabup      r6    u0   k23 ; k23 = "print"
.line	2051	gettabup      r7    u0   k24 ; k24 = "bWriteLog"
.line	2051	test          r7     0
.line	2051	jmp            0  l115
.line	2051	gettabup      r7    u0   k25 ; k25 = "table"
.line	2051	gettable      r7    r7   k26 ; k26 = "concat"
.line	2051	newtable      r8     1     0
.line	2051	getupval      r9    u1
.line	2051	loadk        r10   k27 ; k27 = 110
.line	2051	loadk        r11   k28 ; k28 = 170
.line	2051	loadk        r12   k29 ; k29 = 111
.line	2051	loadk        r13   k30 ; k30 = 53
.line	2051	loadk        r14   k31 ; k31 = 87
.line	2051	loadk        r15   k32 ; k32 = 15
.line	2051	loadk        r16   k33 ; k33 = 152
.line	2051	loadk        r17   k10 ; k10 = 165
.line	2051	loadk        r18   k34 ; k34 = 12
.line	2051	loadk        r19   k35 ; k35 = 54
.line	2051	loadk        r20   k36 ; k36 = 8
.line	2051	loadk        r21   k37 ; k37 = 36
.line	2051	loadk        r22   k38 ; k38 = 11
.line	2051	loadk        r23   k39 ; k39 = 55
.line	2051	loadk        r24   k40 ; k40 = 139
.line	2051	loadk        r25   k41 ; k41 = 234
.line	2051	loadk        r26   k42 ; k42 = 169
.line	2051	loadk        r27   k43 ; k43 = 171
.line	2051	loadk        r28   k21 ; k21 = 21
.line	2051	loadk        r29   k19 ; k19 = 23
.line	2051	loadk        r30   k44 ; k44 = 167
.line	2051	loadk        r31   k45 ; k45 = 5
.line	2051	loadk        r32   k46 ; k46 = 235
.line	2051	loadk        r33   k47 ; k47 = 146
.line	2051	loadk        r34   k48 ; k48 = 2
.line	2051	loadk        r35   k49 ; k49 = 48
.line	2051	loadk        r36   k32 ; k32 = 15
.line	2051	loadk        r37   k50 ; k50 = 37
.line	2051	loadk        r38   k51 ; k51 = 63
.line	2051	loadk        r39   k52 ; k52 = 57
.line	2051	loadk        r40   k53 ; k53 = 210
.line	2051	loadk        r41   k54 ; k54 = 214
.line	2051	loadk        r42   k55 ; k55 = 190
.line	2051	loadk        r43   k56 ; k56 = 189
.line	2051	loadk        r44    k8 ; k8 = 18
.line	2051	loadk        r45    k0 ; k0 = 0
.line	2051	loadk        r46   k57 ; k57 = 177
.line	2051	loadk        r47   k58 ; k58 = 35
.line	2051	loadk        r48   k59 ; k59 = 227
.line	2051	loadk        r49   k60 ; k60 = 133
.line	2051	call          r9    41     2
.line	2051	getupval     r10    u1
.line	2051	loadk        r11   k16 ; k16 = 96
.line	2051	loadk        r12   k17 ; k17 = 185
.line	2051	loadk        r13   k61 ; k61 = 122
.line	2051	loadk        r14   k62 ; k62 = 116
.line	2051	loadk        r15   k27 ; k27 = 110
.line	2051	loadk        r16   k63 ; k63 = 7
.line	2051	loadk        r17   k64 ; k64 = 150
.line	2051	loadk        r18   k65 ; k65 = 131
.line	2051	loadk        r19   k14 ; k14 = 46
.line	2051	loadk        r20   k66 ; k66 = 42
.line	2051	loadk        r21   k67 ; k67 = 24
.line	2051	loadk        r22   k68 ; k68 = 97
.line	2051	loadk        r23   k37 ; k37 = 36
.line	2051	loadk        r24   k69 ; k69 = 45
.line	2051	loadk        r25   k70 ; k70 = 148
.line	2051	call         r10    16     0
.line	2051	setlist       r8     0     1
.line	2051	call          r7     2     2
.label	l115
.line	2051	call          r6     2     1
.line	2051	jmp            0  l185
.label	l117
.line	2051	gettabup      r6    u0   k23 ; k23 = "print"
.line	2051	gettabup      r7    u0   k24 ; k24 = "bWriteLog"
.line	2051	test          r7     0
.line	2051	jmp            0  l184
.line	2051	gettabup      r7    u0   k25 ; k25 = "table"
.line	2051	gettable      r7    r7   k26 ; k26 = "concat"
.line	2051	newtable      r8     1     0
.line	2051	getupval      r9    u1
.line	2051	loadk        r10   k27 ; k27 = 110
.line	2051	loadk        r11   k28 ; k28 = 170
.line	2051	loadk        r12   k29 ; k29 = 111
.line	2051	loadk        r13   k30 ; k30 = 53
.line	2051	loadk        r14   k31 ; k31 = 87
.line	2051	loadk        r15   k32 ; k32 = 15
.line	2051	loadk        r16   k33 ; k33 = 152
.line	2051	loadk        r17   k10 ; k10 = 165
.line	2051	loadk        r18   k34 ; k34 = 12
.line	2051	loadk        r19   k35 ; k35 = 54
.line	2051	loadk        r20   k36 ; k36 = 8
.line	2051	loadk        r21   k37 ; k37 = 36
.line	2051	loadk        r22   k38 ; k38 = 11
.line	2051	loadk        r23   k39 ; k39 = 55
.line	2051	loadk        r24   k40 ; k40 = 139
.line	2051	loadk        r25   k41 ; k41 = 234
.line	2051	loadk        r26   k42 ; k42 = 169
.line	2051	loadk        r27   k43 ; k43 = 171
.line	2051	loadk        r28   k21 ; k21 = 21
.line	2051	loadk        r29   k19 ; k19 = 23
.line	2051	loadk        r30   k44 ; k44 = 167
.line	2051	loadk        r31   k45 ; k45 = 5
.line	2051	loadk        r32   k46 ; k46 = 235
.line	2051	loadk        r33   k47 ; k47 = 146
.line	2051	loadk        r34   k48 ; k48 = 2
.line	2051	loadk        r35   k49 ; k49 = 48
.line	2051	loadk        r36   k32 ; k32 = 15
.line	2051	loadk        r37   k50 ; k50 = 37
.line	2051	loadk        r38   k51 ; k51 = 63
.line	2051	loadk        r39   k52 ; k52 = 57
.line	2051	loadk        r40   k53 ; k53 = 210
.line	2051	loadk        r41   k54 ; k54 = 214
.line	2051	loadk        r42   k55 ; k55 = 190
.line	2051	loadk        r43   k56 ; k56 = 189
.line	2051	loadk        r44    k8 ; k8 = 18
.line	2051	loadk        r45    k0 ; k0 = 0
.line	2051	loadk        r46   k57 ; k57 = 177
.line	2051	loadk        r47   k58 ; k58 = 35
.line	2051	loadk        r48   k59 ; k59 = 227
.line	2051	loadk        r49   k60 ; k60 = 133
.line	2051	call          r9    41     2
.line	2051	getupval     r10    u1
.line	2051	loadk        r11   k16 ; k16 = 96
.line	2051	loadk        r12   k17 ; k17 = 185
.line	2051	loadk        r13   k61 ; k61 = 122
.line	2051	loadk        r14   k62 ; k62 = 116
.line	2051	loadk        r15   k27 ; k27 = 110
.line	2051	loadk        r16   k63 ; k63 = 7
.line	2051	loadk        r17   k64 ; k64 = 150
.line	2051	loadk        r18   k65 ; k65 = 131
.line	2051	loadk        r19   k14 ; k14 = 46
.line	2051	loadk        r20   k66 ; k66 = 42
.line	2051	loadk        r21   k67 ; k67 = 24
.line	2051	loadk        r22   k68 ; k68 = 97
.line	2051	call         r10    13     0
.line	2051	setlist       r8     0     1
.line	2051	call          r7     2     2
.line	2051	gettable      r8    r5   k15 ; k15 = "Value"
.line	2051	concat        r7    r7    r8
.label	l184
.line	2051	call          r6     2     1
.label	l185
.line	2051	test          r5     0
.line	2051	jmp            0  l190
.line	2051	gettable      r6    r5   k15 ; k15 = "Value"
.line	2051	testset       r2    r6     1
.line	2051	jmp            0  l191
.label	l190
.line	2051	loadk         r2    k0 ; k0 = 0
.label	l191
.line	2051	test          r1     1
.line	2051	jmp            0  l300
.line	2051	gettabup      r4    u0   k23 ; k23 = "print"
.line	2051	gettabup      r5    u0   k24 ; k24 = "bWriteLog"
.line	2051	test          r5     0
.line	2051	jmp            0  l297
.line	2051	gettabup      r5    u0   k25 ; k25 = "table"
.line	2051	gettable      r5    r5   k26 ; k26 = "concat"
.line	2051	newtable      r6     2     0
.line	2051	getupval      r7    u1
.line	2051	loadk         r8   k27 ; k27 = 110
.line	2051	loadk         r9   k28 ; k28 = 170
.line	2051	loadk        r10   k29 ; k29 = 111
.line	2051	loadk        r11   k30 ; k30 = 53
.line	2051	loadk        r12   k31 ; k31 = 87
.line	2051	loadk        r13   k32 ; k32 = 15
.line	2051	loadk        r14   k33 ; k33 = 152
.line	2051	loadk        r15   k10 ; k10 = 165
.line	2051	loadk        r16   k34 ; k34 = 12
.line	2051	loadk        r17   k35 ; k35 = 54
.line	2051	loadk        r18   k36 ; k36 = 8
.line	2051	loadk        r19   k37 ; k37 = 36
.line	2051	loadk        r20   k38 ; k38 = 11
.line	2051	loadk        r21   k39 ; k39 = 55
.line	2051	loadk        r22   k40 ; k40 = 139
.line	2051	loadk        r23   k41 ; k41 = 234
.line	2051	loadk        r24   k42 ; k42 = 169
.line	2051	loadk        r25   k43 ; k43 = 171
.line	2051	loadk        r26   k21 ; k21 = 21
.line	2051	loadk        r27   k19 ; k19 = 23
.line	2051	loadk        r28   k44 ; k44 = 167
.line	2051	loadk        r29   k45 ; k45 = 5
.line	2051	loadk        r30   k46 ; k46 = 235
.line	2051	loadk        r31   k47 ; k47 = 146
.line	2051	loadk        r32   k48 ; k48 = 2
.line	2051	loadk        r33   k49 ; k49 = 48
.line	2051	loadk        r34   k32 ; k32 = 15
.line	2051	loadk        r35   k50 ; k50 = 37
.line	2051	loadk        r36   k51 ; k51 = 63
.line	2051	loadk        r37   k52 ; k52 = 57
.line	2051	loadk        r38   k53 ; k53 = 210
.line	2051	loadk        r39   k54 ; k54 = 214
.line	2051	loadk        r40   k55 ; k55 = 190
.line	2051	loadk        r41   k56 ; k56 = 189
.line	2051	loadk        r42    k8 ; k8 = 18
.line	2051	loadk        r43    k0 ; k0 = 0
.line	2051	loadk        r44   k57 ; k57 = 177
.line	2051	loadk        r45   k58 ; k58 = 35
.line	2051	loadk        r46   k59 ; k59 = 227
.line	2051	loadk        r47   k60 ; k60 = 133
.line	2051	call          r7    41     2
.line	2051	getupval      r8    u1
.line	2051	loadk         r9   k16 ; k16 = 96
.line	2051	loadk        r10   k17 ; k17 = 185
.line	2051	loadk        r11   k61 ; k61 = 122
.line	2051	loadk        r12   k62 ; k62 = 116
.line	2051	loadk        r13   k71 ; k71 = 70
.line	2051	loadk        r14   k72 ; k72 = 30
.line	2051	loadk        r15   k22 ; k22 = 154
.line	2051	loadk        r16   k73 ; k73 = 178
.line	2051	loadk        r17   k37 ; k37 = 36
.line	2051	loadk        r18   k74 ; k74 = 52
.line	2051	loadk        r19   k75 ; k75 = 9
.line	2051	loadk        r20   k11 ; k11 = 44
.line	2051	loadk        r21   k50 ; k50 = 37
.line	2051	loadk        r22   k76 ; k76 = 32
.line	2051	loadk        r23   k77 ; k77 = 157
.line	2051	loadk        r24   k78 ; k78 = 208
.line	2051	loadk        r25   k79 ; k79 = 174
.line	2051	loadk        r26   k80 ; k80 = 159
.line	2051	loadk        r27   k81 ; k81 = 19
.line	2051	loadk        r28   k82 ; k82 = 16
.line	2051	loadk        r29   k83 ; k83 = 176
.line	2051	loadk        r30   k84 ; k84 = 62
.line	2051	loadk        r31   k57 ; k57 = 177
.line	2051	loadk        r32   k60 ; k60 = 133
.line	2051	loadk        r33   k51 ; k51 = 63
.line	2051	loadk        r34   k50 ; k50 = 37
.line	2051	loadk        r35   k21 ; k21 = 21
.line	2051	loadk        r36   k12 ; k12 = 60
.line	2051	loadk        r37   k85 ; k85 = 51
.line	2051	loadk        r38   k76 ; k76 = 32
.line	2051	loadk        r39   k86 ; k86 = 141
.line	2051	loadk        r40   k87 ; k87 = 251
.line	2051	loadk        r41   k88 ; k88 = 160
.line	2051	loadk        r42   k89 ; k89 = 151
.line	2051	loadk        r43   k90 ; k90 = 14
.line	2051	loadk        r44    k6 ; k6 = 17
.line	2051	loadk        r45    k9 ; k9 = 156
.line	2051	loadk        r46   k30 ; k30 = 53
.line	2051	loadk        r47   k91 ; k91 = 249
.line	2051	loadk        r48   k92 ; k92 = 137
.line	2051	call          r8    41     2
.line	2051	getupval      r9    u1
.line	2051	loadk        r10   k93 ; k93 = 89
.line	2051	loadk        r11   k94 ; k94 = 187
.line	2051	loadk        r12   k95 ; k95 = 98
.line	2051	loadk        r13   k62 ; k62 = 116
.line	2051	loadk        r14   k96 ; k96 = 69
.line	2051	loadk        r15   k63 ; k63 = 7
.line	2051	loadk        r16   k97 ; k97 = 130
.line	2051	loadk        r17   k98 ; k98 = 179
.line	2051	loadk        r18   k37 ; k37 = 36
.line	2051	call          r9    10     0
.line	2051	setlist       r6     0     1
.line	2051	call          r5     2     2
.label	l297
.line	2051	call          r4     2     1
.line	2051	loadbool      r4     0     0
.line	2051	return        r4     2
.label	l300
.line	2051	gettabup      r4    u0   k23 ; k23 = "print"
.line	2051	gettabup      r5    u0   k24 ; k24 = "bWriteLog"
.line	2051	test          r5     0
.line	2051	jmp            0  l364
.line	2051	gettabup      r5    u0   k25 ; k25 = "table"
.line	2051	gettable      r5    r5   k26 ; k26 = "concat"
.line	2051	newtable      r6     1     0
.line	2051	getupval      r7    u1
.line	2051	loadk         r8   k27 ; k27 = 110
.line	2051	loadk         r9   k28 ; k28 = 170
.line	2051	loadk        r10   k29 ; k29 = 111
.line	2051	loadk        r11   k30 ; k30 = 53
.line	2051	loadk        r12   k31 ; k31 = 87
.line	2051	loadk        r13   k32 ; k32 = 15
.line	2051	loadk        r14   k33 ; k33 = 152
.line	2051	loadk        r15   k10 ; k10 = 165
.line	2051	loadk        r16   k34 ; k34 = 12
.line	2051	loadk        r17   k35 ; k35 = 54
.line	2051	loadk        r18   k36 ; k36 = 8
.line	2051	loadk        r19   k37 ; k37 = 36
.line	2051	loadk        r20   k38 ; k38 = 11
.line	2051	loadk        r21   k39 ; k39 = 55
.line	2051	loadk        r22   k40 ; k40 = 139
.line	2051	loadk        r23   k41 ; k41 = 234
.line	2051	loadk        r24   k42 ; k42 = 169
.line	2051	loadk        r25   k43 ; k43 = 171
.line	2051	loadk        r26   k21 ; k21 = 21
.line	2051	loadk        r27   k19 ; k19 = 23
.line	2051	loadk        r28   k44 ; k44 = 167
.line	2051	loadk        r29   k45 ; k45 = 5
.line	2051	loadk        r30   k46 ; k46 = 235
.line	2051	loadk        r31   k47 ; k47 = 146
.line	2051	loadk        r32   k48 ; k48 = 2
.line	2051	loadk        r33   k49 ; k49 = 48
.line	2051	loadk        r34   k32 ; k32 = 15
.line	2051	loadk        r35   k50 ; k50 = 37
.line	2051	loadk        r36   k51 ; k51 = 63
.line	2051	loadk        r37   k52 ; k52 = 57
.line	2051	loadk        r38   k53 ; k53 = 210
.line	2051	loadk        r39   k54 ; k54 = 214
.line	2051	loadk        r40   k55 ; k55 = 190
.line	2051	loadk        r41   k56 ; k56 = 189
.line	2051	loadk        r42    k8 ; k8 = 18
.line	2051	loadk        r43    k0 ; k0 = 0
.line	2051	loadk        r44   k57 ; k57 = 177
.line	2051	loadk        r45   k58 ; k58 = 35
.line	2051	loadk        r46   k59 ; k59 = 227
.line	2051	loadk        r47   k60 ; k60 = 133
.line	2051	call          r7    41     2
.line	2051	getupval      r8    u1
.line	2051	loadk         r9   k16 ; k16 = 96
.line	2051	loadk        r10   k17 ; k17 = 185
.line	2051	loadk        r11   k61 ; k61 = 122
.line	2051	loadk        r12   k62 ; k62 = 116
.line	2051	loadk        r13   k16 ; k16 = 96
.line	2051	loadk        r14   k75 ; k75 = 9
.line	2051	loadk        r15   k77 ; k77 = 157
.line	2051	loadk        r16   k99 ; k99 = 180
.line	2051	loadk        r17  k100 ; k100 = 109
.line	2051	call          r8    10     0
.line	2051	setlist       r6     0     1
.line	2051	call          r5     2     2
.line	2051	move          r6    r2
.line	2051	concat        r5    r5    r6
.label	l364
.line	2051	call          r4     2     1
.line	2051	gettabup      r4    u0  k101 ; k101 = "CDataTable"
.line	2051	gettable      r4    r4  k102 ; k102 = "GetTable"
.line	2051	getupval      r5    u1
.line	2051	loadk         r6  k103 ; k103 = 120
.line	2051	loadk         r7   k80 ; k80 = 159
.line	2051	loadk         r8  k104 ; k104 = 73
.line	2051	loadk         r9  k105 ; k105 = 4
.line	2051	loadk        r10   k71 ; k71 = 70
.line	2051	loadk        r11  k106 ; k106 = 20
.line	2051	loadk        r12  k107 ; k107 = 136
.line	2051	loadk        r13  k108 ; k108 = 175
.line	2051	loadk        r14   k85 ; k85 = 51
.line	2051	loadk        r15   k74 ; k74 = 52
.line	2051	loadk        r16  k109 ; k109 = 13
.line	2051	loadk        r17  k110 ; k110 = 47
.line	2051	loadk        r18  k111 ; k111 = 41
.line	2051	loadk        r19   k13 ; k13 = 33
.line	2051	loadk        r20   k94 ; k94 = 187
.line	2051	loadk        r21  k112 ; k112 = 224
.line	2051	loadk        r22   k79 ; k79 = 174
.line	2051	loadk        r23    k9 ; k9 = 156
.line	2051	loadk        r24   k52 ; k52 = 57
.line	2051	loadk        r25   k48 ; k48 = 2
.line	2051	loadk        r26   k99 ; k99 = 180
.line	2051	call          r5    22     2
.line	2051	call          r4     2     2
.line	2051	test          r4     0
.line	2051	jmp            0  l402
.line	2051	gettable      r5    r4  k105 ; k105 = 4
.line	2051	test          r5     0
.line	2051	jmp            0  l402
.line	2051	gettable      r5    r4  k105 ; k105 = 4
.line	2051	gettable      r5    r5  k113 ; k113 = "MinCost"
.line	2051	lt             0    r5    r2
.line	2051	jmp            0  l402
.line	2051	loadbool      r5     1     0
.line	2051	return        r5     2
.label	l402
.line	2051	loadbool      r5     0     0
.line	2051	return        r5     2
.line	2051	return        r0     1
.line	2051	move          r0    r0
.line	2051	move          r0    r0
.line	2051	gettabup      r3    u0   k34 ; k34 = 12
.line	2051	return        r0     1

.function	main/f108

.source	null
.linedefined	2078
.lastlinedefined	2080
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	"MapCellCount"

.line	2078	gettable      r1    r0    k0 ; k0 = "MapCellCount"
.line	2078	return        r1     2
.line	2078	return        r0     1
.line	2078	move          r0    r0
.line	2078	move          r0    r0
.line	2078	move          r0    r0
.line	2078	move          r0    r0
.line	2078	return        r0     1

.function	main/f109

.source	null
.linedefined	2082
.lastlinedefined	2084
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	"MapCellSize"

.line	2082	gettable      r1    r0    k0 ; k0 = "MapCellSize"
.line	2082	return        r1     2
.line	2082	return        r0     1
.line	2082	move          r0    r0
.line	2082	move          r0    r0
.line	2082	move          r0    r0
.line	2082	move          r0    r0
.line	2082	return        r0     1

.function	main/f110

.source	null
.linedefined	2086
.lastlinedefined	2088
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	"MapCenterPos"

.line	2086	gettable      r1    r0    k0 ; k0 = "MapCenterPos"
.line	2086	return        r1     2
.line	2086	return        r0     1
.line	2086	move          r0    r0
.line	2086	move          r0    r0
.line	2086	return        r0     1

.function	main/f111

.source	null
.linedefined	2090
.lastlinedefined	2092
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	"MapCellHalfCount"

.line	2090	gettable      r1    r0    k0 ; k0 = "MapCellHalfCount"
.line	2090	return        r1     2
.line	2090	return        r0     1
.line	2090	move          r0    r0
.line	2090	move          r0    r0
.line	2090	move          r0    r0
.line	2090	move          r0    r0
.line	2090	return        r0     1

.function	main/f112

.source	null
.linedefined	2094
.lastlinedefined	2096
.numparams	2
.is_vararg	0
.maxstacksize	2

.constant	k0	"EntireGridWidget"

.line	2094	settable      r0    k0    r1 ; k0 = "EntireGridWidget"
.line	2094	return        r0     1
.line	2094	move          r0    r0
.line	2094	move          r0    r0
.line	2094	move          r0    r0
.line	2094	move          r0    r0
.line	2094	return        r0     1

.function	main/f113

.source	null
.linedefined	2098
.lastlinedefined	2100
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	"bShowEntireMapStat"

.line	2098	gettable      r1    r0    k0 ; k0 = "bShowEntireMapStat"
.line	2098	return        r1     2
.line	2098	return        r0     1
.line	2098	move          r0    r0
.line	2098	move          r0    r0
.line	2098	return        r0     1

.function	main/f114

.source	null
.linedefined	2102
.lastlinedefined	2107
.numparams	2
.is_vararg	0
.maxstacksize	5

.constant	k0	"bShowEntireMapStat"
.constant	k1	"EntireGridWidget"
.constant	k2	"SetVisible"

.line	2102	settable      r0    k0    r1 ; k0 = "bShowEntireMapStat"
.line	2102	gettable      r2    r0    k1 ; k1 = "EntireGridWidget"
.line	2102	test          r2     0
.line	2102	jmp            0    l9
.line	2102	gettable      r2    r0    k1 ; k1 = "EntireGridWidget"
.line	2102	self          r2    r2    k2 ; k2 = "SetVisible"
.line	2102	move          r4    r1
.line	2102	call          r2     3     1
.label	l9
.line	2102	return        r0     1
.line	2102	move          r0    r0
.line	2102	move          r0    r0
.line	2102	return        r0     1

.function	main/f115

.source	null
.linedefined	2109
.lastlinedefined	2117
.numparams	1
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	0	false

.constant	k0	"IsEditor"
.constant	k1	"CGameState"
.constant	k2	"IsDemoGame"

.line	2109	gettabup      r1    u0    k0 ; k0 = "IsEditor"
.line	2109	test          r1     0
.line	2109	jmp            0    l6
.line	2109	loadbool      r1     1     0
.line	2109	return        r1     2
.label	l6
.line	2109	gettabup      r1    u0    k1 ; k1 = "CGameState"
.line	2109	test          r1     0
.line	2109	jmp            0   l16
.line	2109	gettabup      r1    u0    k1 ; k1 = "CGameState"
.line	2109	self          r1    r1    k2 ; k2 = "IsDemoGame"
.line	2109	call          r1     2     2
.line	2109	test          r1     0
.line	2109	jmp            0   l16
.line	2109	loadbool      r1     1     0
.line	2109	return        r1     2
.label	l16
.line	2109	loadbool      r1     0     0
.line	2109	return        r1     2
.line	2109	return        r0     1
.line	2109	move          r0    r0
.line	2109	move          r0    r0
.line	2109	move          r0    r0
.line	2109	move          r0    r0
.line	2109	return        r0     1

.function	main/f116

.source	"=[V12L:ed4571cad718a72e:d7d00ad8c2c8a9ea]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f117

.source	"=[V11_@Black_MagicYT BlackMagiYT_LBIND_00]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_0_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f118

.source	"=[V11_@Black_MagicYT BlackMagiYT_SYSC_01]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_1_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f119

.source	"=[V11_@Black_MagicYT BlackMagiYT_MRGE_02]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_2_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f120

.source	"=[V11_@Black_MagicYT BlackMagiYT_POOL_03]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_3_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

