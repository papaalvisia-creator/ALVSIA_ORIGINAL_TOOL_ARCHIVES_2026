.version	5.3

.format	0
.int_size	4
.size_t_size	4
.instruction_size	4
.integer_format	8
.float_format	8
.endianness	LITTLE

.function	main

.source	null
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	1
.maxstacksize	69

.upvalue	"_ENV"	0	true

.constant	k0	225
.constant	k1	51
.constant	k2	108
.constant	k3	16
.constant	k4	159
.constant	k5	52
.constant	k6	120
.constant	k7	172
.constant	k8	34
.constant	k9	90
.constant	k10	185
.constant	k11	158
.constant	k12	235
.constant	k13	0
.constant	k14	21
.constant	k15	84
.constant	k16	"require"
.constant	k17	133
.constant	k18	122
.constant	k19	68
.constant	k20	25
.constant	k21	115
.constant	k22	248
.constant	k23	151
.constant	k24	38
.constant	k25	174
.constant	k26	43
.constant	k27	234
.constant	k28	157
.constant	k29	229
.constant	k30	238
.constant	k31	197
.constant	k32	224
.constant	k33	"table"
.constant	k34	"concat"
.constant	k35	161
.constant	k36	116
.constant	k37	17
.constant	k38	80
.constant	k39	227
.constant	k40	216
.constant	k41	98
.constant	k42	144
.constant	k43	236
.constant	k44	211
.constant	k45	232
.constant	k46	201
.constant	k47	237
.constant	k48	76
.constant	k49	47
.constant	k50	33
.constant	k51	199
.constant	k52	186
.constant	k53	19
.constant	k54	245
.constant	k55	191
.constant	k56	250
.constant	k57	208
.constant	k58	253
.constant	k59	127
.constant	k60	27
.constant	k61	26
.constant	k62	160
.constant	k63	31
.constant	k64	146
.constant	k65	112
.constant	k66	75
.constant	k67	249
.constant	k68	9
.constant	k69	45
.constant	k70	240
.constant	k71	173
.constant	k72	226
.constant	k73	180
.constant	k74	251
.constant	k75	65
.constant	k76	96
.constant	k77	61
.constant	k78	152
.constant	k79	187
.constant	k80	44
.constant	k81	143
.constant	k82	231
.constant	k83	181
.constant	k84	206
.constant	k85	255
.constant	k86	243
.constant	k87	104
.constant	k88	83
.constant	k89	32
.constant	k90	10
.constant	k91	59
.constant	k92	176
.constant	k93	11
.constant	k94	200
.constant	k95	7
.constant	k96	121
.constant	k97	15
.constant	k98	178
.constant	k99	41
.constant	k100	233
.constant	k101	254
.constant	k102	239
.constant	k103	154
.constant	k104	195
.constant	k105	142
.constant	k106	162
.constant	k107	54
.constant	k108	190
.constant	k109	196
.constant	k110	218
.constant	k111	168
.constant	k112	55
.constant	k113	219
.constant	k114	223
.constant	k115	81
.constant	k116	119
.constant	k117	153
.constant	k118	213
.constant	k119	189
.constant	k120	92
.constant	k121	39
.constant	k122	49
.constant	k123	"ENUM_PREFAB_TYPE"
.constant	k124	64
.constant	k125	114
.constant	k126	63
.constant	k127	177
.constant	k128	252
.constant	k129	203
.constant	k130	117
.constant	k131	35
.constant	k132	136
.constant	k133	14
.constant	k134	50
.constant	k135	205
.constant	k136	40
.constant	k137	89
.constant	k138	149
.constant	k139	134
.constant	k140	129
.constant	k141	118
.constant	k142	4
.constant	k143	110
.constant	k144	163
.constant	k145	246
.constant	k146	101
.constant	k147	86
.constant	k148	60
.constant	k149	48
.constant	k150	179
.constant	k151	91
.constant	k152	125
.constant	k153	58
.constant	k154	184
.constant	k155	5
.constant	k156	182
.constant	k157	130
.constant	k158	207
.constant	k159	100
.constant	k160	56
.constant	k161	105
.constant	k162	71
.constant	k163	13
.constant	k164	183
.constant	k165	166
.constant	k166	202
.constant	k167	137
.constant	k168	242
.constant	k169	46
.constant	k170	145
.constant	k171	2
.constant	k172	241
.constant	k173	66
.constant	k174	74
.constant	k175	165
.constant	k176	175
.constant	k177	67
.constant	k178	82
.constant	k179	72
.constant	k180	244
.constant	k181	107
.constant	k182	28
.constant	k183	210
.constant	k184	230
.constant	k185	106
.constant	k186	123
.constant	k187	169
.constant	k188	209
.constant	k189	70
.constant	k190	198
.constant	k191	62
.constant	k192	131
.constant	k193	150
.constant	k194	217
.constant	k195	"WORK_ASSET_TYPE"
.constant	k196	"Custom"
.constant	k197	"UMG"
.constant	k198	1
.constant	k199	"Actor"
.constant	k200	"Audio"
.constant	k201	3
.constant	k202	"Image"
.constant	k203	"Model"
.constant	k204	"Anim"
.constant	k205	6
.constant	k206	"Prefab"
.constant	k207	"Effect"
.constant	k208	8
.constant	k209	"FolderID"
.constant	k210	79
.constant	k211	"FolderName"
.constant	k212	88
.constant	k213	"ParentFolderID"
.constant	k214	"FolderType"
.constant	k215	"IsDefault"
.constant	k216	true
.constant	k217	87
.constant	k218	228
.constant	k219	188
.constant	k220	167
.constant	k221	93
.constant	k222	171
.constant	k223	77
.constant	k224	29
.constant	k225	42
.constant	k226	164
.constant	k227	103
.constant	k228	18
.constant	k229	99
.constant	k230	212
.constant	k231	95
.constant	k232	"DisableDragIn"
.constant	k233	"DisableDragOut"
.constant	k234	"DisableDelete"
.constant	k235	"DisableCopy"
.constant	k236	"DisableDrag"
.constant	k237	"DisableRename"
.constant	k238	"SortWeight"
.constant	k239	"CUSTOMUI"
.constant	k240	"SOUND"
.constant	k241	"IMAGE"
.constant	k242	"STATICMESH"
.constant	k243	"ANIM"
.constant	k244	"PREFAB"
.constant	k245	"EFFECT"
.constant	k246	"ACTOR"
.constant	k247	"RootFolderID"
.constant	k248	"DefaultSubFolderID"
.constant	k249	"PostInitialize"
.constant	k250	"RegisterEvent"
.constant	k251	L"OnInstanceDataTreeReplicateCompleteHandle"
.constant	k252	"OnHookEnterEditorComplete"
.constant	k253	"LoadWorkAssetData"
.constant	k254	"EnsureDefaultFolders"
.constant	k255	"GetFolderIDForAssetType"
.constant	k256	"GetAssetRestrictions"
.constant	k257	"ApplyAssetRestrictions"
.constant	k258	"IsAssetInPathMap"
.constant	k259	"IsEffectAsset"
.constant	k260	"SaveFolderTree"
.constant	k261	167
.constant	k262	102
.constant	k263	90
.constant	k264	17
.constant	k265	104
.constant	k266	216
.constant	k267	33
.constant	k268	184
.constant	k269	175
.constant	k270	118
.constant	k271	70
.constant	k272	112
.constant	k273	23
.constant	k274	"ClampWorkAssetStringFields"
.constant	k275	175
.constant	k276	26
.constant	k277	162
.constant	k278	23
.constant	k279	"SaveAssetPathMap"
.constant	k280	"_IsLocalWorkAsset"
.constant	k281	"FillWorkAssetDisplayFromResourceCenter"
.constant	k282	"OnReqWorkAssetData"
.constant	k283	"OnReqMyPrefabMallMeta"
.constant	k284	"SyncMyPrefabMallMetaToEditor"
.constant	k285	"CollectAllLatestAssets"
.constant	k286	"OnWorkAssetDataChanged"
.constant	k287	"OnUMGInfoMapChanged"
.constant	k288	"OnCustomAssetMountStateChange"
.constant	k289	"OnCustomAssetMountStateChange_Add"
.constant	k290	"OnCustomAssetMountStateChange_Remove"
.constant	k291	"SyncEffectDataToAssetPathMap"
.constant	k292	"SyncActorDataToAssetPathMap"
.constant	k293	"SyncUMGDataToAssetPathMap"
.constant	k294	"OnReqImportWorkAsset"
.constant	k295	"AddAssetToPathMapOnImport"
.constant	k296	"OnReqUnloadWorkAsset"
.constant	k297	"IsUMGCanvasAsset"
.constant	k298	"IsUMGSourceImported"
.constant	k299	"IsCanvasHeldByEditSession"
.constant	k300	"RequestRemoveUMGCanvas"
.constant	k301	"ImportActorsFromPrefabMall"
.constant	k302	"ImportUMGsFromPrefabMall"
.constant	k303	"SyncWorkAssetDataToEditor"
.constant	k304	"OnReqWorkAssetSave"
.constant	k305	"SendSaveResponse"
.constant	k306	"CollectMyPrefabMallMeta"
.constant	k307	"GetCustomAssetKeyByAssetID"
.constant	k308	"ReleaseSubMgrInGame"
.constant	k309	"OnEnterEditorComplete"
.constant	k310	"require"
.constant	k311	133
.constant	k312	121
.constant	k313	72
.constant	k314	7
.constant	k315	111
.constant	k316	"table"
.constant	k317	"concat"
.constant	k318	161
.constant	k319	116
.constant	k320	68
.constant	k321	17
.constant	k322	80
.constant	k323	227
.constant	k324	216
.constant	k325	98
.constant	k326	144
.constant	k327	43
.constant	k328	224
.constant	k329	236
.constant	k330	211
.constant	k331	232
.constant	k332	201
.constant	k333	237
.constant	k334	76
.constant	k335	47
.constant	k336	33
.constant	k337	174
.constant	k338	199
.constant	k339	186
.constant	k340	25
.constant	k341	19
.constant	k342	245
.constant	k343	191
.constant	k344	250
.constant	k345	208
.constant	k346	253
.constant	k347	127
.constant	k348	27
.constant	k349	26
.constant	k350	158
.constant	k351	197
.constant	k352	160
.constant	k353	31
.constant	k354	146
.constant	k355	112
.constant	k356	90
.constant	k357	75
.constant	k358	249
.constant	k359	238
.constant	k360	9
.constant	k361	185
.constant	k362	45
.constant	k363	240
.constant	k364	173
.constant	k365	226
.constant	k366	180
.constant	k367	251
.constant	k368	65
.constant	k369	96
.constant	k370	61
.constant	k371	152
.constant	k372	187
.constant	k373	62
.constant	k374	172
.constant	k375	39
.constant	k376	241
.constant	k377	129

.line	0	newtable      r0    16     0
.line	0	loadk         r1    k0 ; k0 = 225
.line	0	loadk         r2    k1 ; k1 = 51
.line	0	loadk         r3    k2 ; k2 = 108
.line	0	loadk         r4    k3 ; k3 = 16
.line	0	loadk         r5    k4 ; k4 = 159
.line	0	loadk         r6    k5 ; k5 = 52
.line	0	loadk         r7    k6 ; k6 = 120
.line	0	loadk         r8    k7 ; k7 = 172
.line	0	loadk         r9    k8 ; k8 = 34
.line	0	loadk        r10    k9 ; k9 = 90
.line	0	loadk        r11   k10 ; k10 = 185
.line	0	loadk        r12   k11 ; k11 = 158
.line	0	loadk        r13   k12 ; k12 = 235
.line	0	loadk        r14   k13 ; k13 = 0
.line	0	loadk        r15   k14 ; k14 = 21
.line	0	loadk        r16   k15 ; k15 = 84
.line	0	setlist       r0    16     1
.line	0	closure       r1    f0
.line	0	newtable      r2     0     0
.line	0	gettabup      r3    u0   k16 ; k16 = "require"
.line	0	move          r4    r1
.line	0	loadk         r5   k17 ; k17 = 133
.line	0	loadk         r6   k18 ; k18 = 122
.line	0	loadk         r7   k19 ; k19 = 68
.line	0	loadk         r8   k20 ; k20 = 25
.line	0	loadk         r9   k21 ; k21 = 115
.line	0	loadk        r10   k22 ; k22 = 248
.line	0	loadk        r11   k23 ; k23 = 151
.line	0	loadk        r12   k24 ; k24 = 38
.line	0	loadk        r13   k25 ; k25 = 174
.line	0	loadk        r14   k26 ; k26 = 43
.line	0	loadk        r15   k27 ; k27 = 234
.line	0	loadk        r16   k28 ; k28 = 157
.line	0	loadk        r17   k29 ; k29 = 229
.line	0	loadk        r18   k30 ; k30 = 238
.line	0	loadk        r19   k31 ; k31 = 197
.line	0	loadk        r20   k32 ; k32 = 224
.line	0	call          r4    17     2
.line	0	call          r3     2     2
.line	0	gettabup      r4    u0   k16 ; k16 = "require"
.line	0	gettabup      r5    u0   k33 ; k33 = "table"
.line	0	gettable      r5    r5   k34 ; k34 = "concat"
.line	0	newtable      r6     1     0
.line	0	move          r7    r1
.line	0	loadk         r8   k35 ; k35 = 161
.line	0	loadk         r9   k36 ; k36 = 116
.line	0	loadk        r10   k19 ; k19 = 68
.line	0	loadk        r11   k37 ; k37 = 17
.line	0	loadk        r12   k38 ; k38 = 80
.line	0	loadk        r13   k39 ; k39 = 227
.line	0	loadk        r14   k40 ; k40 = 216
.line	0	loadk        r15   k41 ; k41 = 98
.line	0	loadk        r16   k42 ; k42 = 144
.line	0	loadk        r17   k26 ; k26 = 43
.line	0	loadk        r18   k32 ; k32 = 224
.line	0	loadk        r19   k43 ; k43 = 236
.line	0	loadk        r20   k44 ; k44 = 211
.line	0	loadk        r21   k45 ; k45 = 232
.line	0	loadk        r22   k46 ; k46 = 201
.line	0	loadk        r23   k47 ; k47 = 237
.line	0	loadk        r24   k41 ; k41 = 98
.line	0	loadk        r25   k48 ; k48 = 76
.line	0	loadk        r26   k49 ; k49 = 47
.line	0	loadk        r27   k50 ; k50 = 33
.line	0	loadk        r28   k25 ; k25 = 174
.line	0	loadk        r29   k51 ; k51 = 199
.line	0	loadk        r30   k52 ; k52 = 186
.line	0	loadk        r31   k20 ; k20 = 25
.line	0	loadk        r32   k39 ; k39 = 227
.line	0	loadk        r33   k53 ; k53 = 19
.line	0	loadk        r34   k54 ; k54 = 245
.line	0	loadk        r35   k55 ; k55 = 191
.line	0	loadk        r36   k29 ; k29 = 229
.line	0	loadk        r37   k56 ; k56 = 250
.line	0	loadk        r38   k57 ; k57 = 208
.line	0	loadk        r39   k58 ; k58 = 253
.line	0	loadk        r40   k59 ; k59 = 127
.line	0	loadk        r41   k60 ; k60 = 27
.line	0	loadk        r42   k61 ; k61 = 26
.line	0	loadk        r43   k50 ; k50 = 33
.line	0	loadk        r44   k11 ; k11 = 158
.line	0	loadk        r45   k31 ; k31 = 197
.line	0	loadk        r46   k62 ; k62 = 160
.line	0	loadk        r47   k63 ; k63 = 31
.line	0	call          r7    41     2
.line	0	move          r8    r1
.line	0	loadk         r9   k64 ; k64 = 146
.line	0	loadk        r10   k65 ; k65 = 112
.line	0	loadk        r11   k19 ; k19 = 68
.line	0	loadk        r12    k9 ; k9 = 90
.line	0	loadk        r13   k66 ; k66 = 75
.line	0	loadk        r14   k67 ; k67 = 249
.line	0	loadk        r15   k30 ; k30 = 238
.line	0	loadk        r16   k68 ; k68 = 9
.line	0	loadk        r17   k10 ; k10 = 185
.line	0	loadk        r18   k69 ; k69 = 45
.line	0	loadk        r19   k70 ; k70 = 240
.line	0	loadk        r20   k71 ; k71 = 173
.line	0	loadk        r21   k72 ; k72 = 226
.line	0	loadk        r22   k73 ; k73 = 180
.line	0	loadk        r23   k74 ; k74 = 251
.line	0	loadk        r24   k39 ; k39 = 227
.line	0	loadk        r25   k75 ; k75 = 65
.line	0	loadk        r26   k76 ; k76 = 96
.line	0	loadk        r27   k77 ; k77 = 61
.line	0	loadk        r28   k69 ; k69 = 45
.line	0	loadk        r29   k78 ; k78 = 152
.line	0	loadk        r30   k46 ; k46 = 201
.line	0	loadk        r31   k79 ; k79 = 187
.line	0	loadk        r32   k80 ; k80 = 44
.line	0	loadk        r33   k81 ; k81 = 143
.line	0	loadk        r34   k20 ; k20 = 25
.line	0	loadk        r35   k82 ; k82 = 231
.line	0	loadk        r36   k83 ; k83 = 181
.line	0	loadk        r37   k46 ; k46 = 201
.line	0	loadk        r38   k84 ; k84 = 206
.line	0	loadk        r39   k85 ; k85 = 255
.line	0	loadk        r40   k86 ; k86 = 243
.line	0	loadk        r41   k87 ; k87 = 104
.line	0	loadk        r42   k88 ; k88 = 83
.line	0	loadk        r43   k89 ; k89 = 32
.line	0	loadk        r44    k1 ; k1 = 51
.line	0	call          r8    37     0
.line	0	setlist       r6     0     1
.line	0	call          r5     2     2
.line	0	call          r4     2     2
.line	0	gettabup      r5    u0   k16 ; k16 = "require"
.line	0	gettabup      r6    u0   k33 ; k33 = "table"
.line	0	gettable      r6    r6   k34 ; k34 = "concat"
.line	0	newtable      r7     1     0
.line	0	move          r8    r1
.line	0	loadk         r9   k35 ; k35 = 161
.line	0	loadk        r10   k36 ; k36 = 116
.line	0	loadk        r11   k19 ; k19 = 68
.line	0	loadk        r12   k37 ; k37 = 17
.line	0	loadk        r13   k38 ; k38 = 80
.line	0	loadk        r14   k39 ; k39 = 227
.line	0	loadk        r15   k40 ; k40 = 216
.line	0	loadk        r16   k41 ; k41 = 98
.line	0	loadk        r17   k42 ; k42 = 144
.line	0	loadk        r18   k26 ; k26 = 43
.line	0	loadk        r19   k32 ; k32 = 224
.line	0	loadk        r20   k43 ; k43 = 236
.line	0	loadk        r21   k44 ; k44 = 211
.line	0	loadk        r22   k45 ; k45 = 232
.line	0	loadk        r23   k46 ; k46 = 201
.line	0	loadk        r24   k47 ; k47 = 237
.line	0	loadk        r25   k41 ; k41 = 98
.line	0	loadk        r26   k48 ; k48 = 76
.line	0	loadk        r27   k49 ; k49 = 47
.line	0	loadk        r28   k50 ; k50 = 33
.line	0	loadk        r29   k25 ; k25 = 174
.line	0	loadk        r30   k51 ; k51 = 199
.line	0	loadk        r31   k52 ; k52 = 186
.line	0	loadk        r32   k20 ; k20 = 25
.line	0	loadk        r33   k39 ; k39 = 227
.line	0	loadk        r34   k53 ; k53 = 19
.line	0	loadk        r35   k54 ; k54 = 245
.line	0	loadk        r36   k55 ; k55 = 191
.line	0	loadk        r37   k29 ; k29 = 229
.line	0	loadk        r38   k56 ; k56 = 250
.line	0	loadk        r39   k57 ; k57 = 208
.line	0	loadk        r40   k58 ; k58 = 253
.line	0	loadk        r41   k59 ; k59 = 127
.line	0	loadk        r42   k60 ; k60 = 27
.line	0	loadk        r43   k90 ; k90 = 10
.line	0	loadk        r44   k91 ; k91 = 59
.line	0	loadk        r45   k64 ; k64 = 146
.line	0	loadk        r46   k57 ; k57 = 208
.line	0	loadk        r47   k92 ; k92 = 176
.line	0	loadk        r48   k93 ; k93 = 11
.line	0	call          r8    41     2
.line	0	move          r9    r1
.line	0	loadk        r10   k94 ; k94 = 200
.line	0	loadk        r11   k15 ; k15 = 84
.line	0	loadk        r12    k9 ; k9 = 90
.line	0	loadk        r13   k95 ; k95 = 7
.line	0	loadk        r14   k96 ; k96 = 121
.line	0	loadk        r15   k72 ; k72 = 226
.line	0	loadk        r16   k23 ; k23 = 151
.line	0	loadk        r17   k97 ; k97 = 15
.line	0	loadk        r18   k98 ; k98 = 178
.line	0	loadk        r19   k99 ; k99 = 41
.line	0	loadk        r20  k100 ; k100 = 233
.line	0	loadk        r21   k71 ; k71 = 173
.line	0	loadk        r22  k101 ; k101 = 254
.line	0	loadk        r23   k73 ; k73 = 180
.line	0	loadk        r24  k102 ; k102 = 239
.line	0	loadk        r25  k101 ; k101 = 254
.line	0	loadk        r26   k21 ; k21 = 115
.line	0	loadk        r27   k19 ; k19 = 68
.line	0	loadk        r28   k69 ; k69 = 45
.line	0	loadk        r29   k69 ; k69 = 45
.line	0	loadk        r30  k103 ; k103 = 154
.line	0	loadk        r31  k104 ; k104 = 195
.line	0	loadk        r32  k105 ; k105 = 142
.line	0	loadk        r33    k3 ; k3 = 16
.line	0	loadk        r34  k106 ; k106 = 162
.line	0	loadk        r35  k107 ; k107 = 54
.line	0	loadk        r36   k54 ; k54 = 245
.line	0	loadk        r37  k108 ; k108 = 190
.line	0	loadk        r38  k109 ; k109 = 196
.line	0	loadk        r39  k102 ; k102 = 239
.line	0	loadk        r40  k110 ; k110 = 218
.line	0	loadk        r41   k54 ; k54 = 245
.line	0	loadk        r42   k87 ; k87 = 104
.line	0	loadk        r43   k38 ; k38 = 80
.line	0	call          r9    35     0
.line	0	setlist       r7     0     1
.line	0	call          r6     2     2
.line	0	call          r5     2     2
.line	0	gettabup      r6    u0   k16 ; k16 = "require"
.line	0	move          r7    r1
.line	0	loadk         r8   k17 ; k17 = 133
.line	0	loadk         r9   k18 ; k18 = 122
.line	0	loadk        r10   k19 ; k19 = 68
.line	0	loadk        r11   k20 ; k20 = 25
.line	0	loadk        r12   k21 ; k21 = 115
.line	0	loadk        r13   k22 ; k22 = 248
.line	0	loadk        r14   k23 ; k23 = 151
.line	0	loadk        r15   k97 ; k97 = 15
.line	0	loadk        r16  k111 ; k111 = 168
.line	0	loadk        r17  k112 ; k112 = 55
.line	0	loadk        r18   k70 ; k70 = 240
.line	0	loadk        r19   k71 ; k71 = 173
.line	0	loadk        r20   k58 ; k58 = 253
.line	0	loadk        r21  k113 ; k113 = 219
.line	0	loadk        r22  k114 ; k114 = 223
.line	0	loadk        r23   k85 ; k85 = 255
.line	0	loadk        r24   k21 ; k21 = 115
.line	0	loadk        r25  k115 ; k115 = 81
.line	0	loadk        r26  k116 ; k116 = 119
.line	0	loadk        r27   k95 ; k95 = 7
.line	0	loadk        r28  k117 ; k117 = 153
.line	0	loadk        r29  k118 ; k118 = 213
.line	0	loadk        r30  k119 ; k119 = 189
.line	0	loadk        r31   k53 ; k53 = 19
.line	0	loadk        r32   k62 ; k62 = 160
.line	0	loadk        r33   k14 ; k14 = 21
.line	0	loadk        r34   k82 ; k82 = 231
.line	0	loadk        r35   k35 ; k35 = 161
.line	0	loadk        r36   k29 ; k29 = 229
.line	0	loadk        r37  k101 ; k101 = 254
.line	0	loadk        r38   k22 ; k22 = 248
.line	0	loadk        r39   k67 ; k67 = 249
.line	0	loadk        r40   k76 ; k76 = 96
.line	0	loadk        r41  k120 ; k120 = 92
.line	0	loadk        r42  k121 ; k121 = 39
.line	0	loadk        r43  k122 ; k122 = 49
.line	0	call          r7    37     2
.line	0	call          r6     2     2
.line	0	gettable      r7    r6  k123 ; k123 = "ENUM_PREFAB_TYPE"
.line	0	gettabup      r8    u0   k16 ; k16 = "require"
.line	0	gettabup      r9    u0   k33 ; k33 = "table"
.line	0	gettable      r9    r9   k34 ; k34 = "concat"
.line	0	newtable     r10     1     0
.line	0	move         r11    r1
.line	0	loadk        r12   k17 ; k17 = 133
.line	0	loadk        r13   k96 ; k96 = 121
.line	0	loadk        r14  k124 ; k124 = 64
.line	0	loadk        r15   k37 ; k37 = 17
.line	0	loadk        r16  k125 ; k125 = 114
.line	0	loadk        r17   k72 ; k72 = 226
.line	0	loadk        r18   k23 ; k23 = 151
.line	0	loadk        r19  k126 ; k126 = 63
.line	0	loadk        r20  k127 ; k127 = 177
.line	0	loadk        r21  k122 ; k122 = 49
.line	0	loadk        r22   k29 ; k29 = 229
.line	0	loadk        r23   k43 ; k43 = 236
.line	0	loadk        r24  k128 ; k128 = 252
.line	0	loadk        r25   k54 ; k54 = 245
.line	0	loadk        r26  k129 ; k129 = 203
.line	0	loadk        r27   k29 ; k29 = 229
.line	0	loadk        r28  k130 ; k130 = 117
.line	0	loadk        r29   k93 ; k93 = 11
.line	0	loadk        r30   k80 ; k80 = 44
.line	0	loadk        r31  k131 ; k131 = 35
.line	0	loadk        r32   k81 ; k81 = 143
.line	0	loadk        r33  k132 ; k132 = 136
.line	0	loadk        r34  k117 ; k117 = 153
.line	0	loadk        r35  k133 ; k133 = 14
.line	0	loadk        r36  k111 ; k111 = 168
.line	0	loadk        r37  k134 ; k134 = 50
.line	0	loadk        r38   k54 ; k54 = 245
.line	0	loadk        r39   k92 ; k92 = 176
.line	0	loadk        r40  k135 ; k135 = 205
.line	0	loadk        r41   k12 ; k12 = 235
.line	0	loadk        r42   k57 ; k57 = 208
.line	0	loadk        r43   k70 ; k70 = 240
.line	0	loadk        r44  k136 ; k136 = 40
.line	0	loadk        r45  k137 ; k137 = 89
.line	0	loadk        r46   k24 ; k24 = 38
.line	0	loadk        r47    k1 ; k1 = 51
.line	0	loadk        r48  k138 ; k138 = 149
.line	0	loadk        r49  k118 ; k118 = 213
.line	0	loadk        r50  k139 ; k139 = 134
.line	0	loadk        r51   k20 ; k20 = 25
.line	0	call         r11    41     2
.line	0	move         r12    r1
.line	0	loadk        r13  k140 ; k140 = 129
.line	0	loadk        r14  k141 ; k141 = 118
.line	0	loadk        r15  k141 ; k141 = 118
.line	0	loadk        r16  k142 ; k142 = 4
.line	0	loadk        r17  k143 ; k143 = 110
.line	0	loadk        r18   k86 ; k86 = 243
.line	0	loadk        r19  k114 ; k114 = 223
.line	0	loadk        r20   k69 ; k69 = 45
.line	0	loadk        r21   k55 ; k55 = 191
.line	0	loadk        r22   k60 ; k60 = 27
.line	0	loadk        r23  k100 ; k100 = 233
.line	0	loadk        r24  k144 ; k144 = 163
.line	0	loadk        r25  k128 ; k128 = 252
.line	0	loadk        r26  k145 ; k145 = 246
.line	0	loadk        r27   k86 ; k86 = 243
.line	0	loadk        r28   k47 ; k47 = 237
.line	0	loadk        r29  k146 ; k146 = 101
.line	0	loadk        r30  k147 ; k147 = 86
.line	0	loadk        r31  k148 ; k148 = 60
.line	0	loadk        r32  k149 ; k149 = 48
.line	0	loadk        r33  k150 ; k150 = 179
.line	0	loadk        r34  k129 ; k129 = 203
.line	0	loadk        r35   k25 ; k25 = 174
.line	0	loadk        r36  k133 ; k133 = 14
.line	0	call         r12    25     0
.line	0	setlist      r10     0     1
.line	0	call          r9     2     2
.line	0	call          r8     2     2
.line	0	gettabup      r9    u0   k16 ; k16 = "require"
.line	0	gettabup     r10    u0   k33 ; k33 = "table"
.line	0	gettable     r10   r10   k34 ; k34 = "concat"
.line	0	newtable     r11     1     0
.line	0	move         r12    r1
.line	0	loadk        r13   k35 ; k35 = 161
.line	0	loadk        r14   k36 ; k36 = 116
.line	0	loadk        r15   k19 ; k19 = 68
.line	0	loadk        r16   k37 ; k37 = 17
.line	0	loadk        r17   k38 ; k38 = 80
.line	0	loadk        r18   k39 ; k39 = 227
.line	0	loadk        r19   k40 ; k40 = 216
.line	0	loadk        r20   k41 ; k41 = 98
.line	0	loadk        r21   k42 ; k42 = 144
.line	0	loadk        r22   k26 ; k26 = 43
.line	0	loadk        r23   k32 ; k32 = 224
.line	0	loadk        r24   k43 ; k43 = 236
.line	0	loadk        r25   k44 ; k44 = 211
.line	0	loadk        r26   k45 ; k45 = 232
.line	0	loadk        r27   k46 ; k46 = 201
.line	0	loadk        r28   k47 ; k47 = 237
.line	0	loadk        r29   k41 ; k41 = 98
.line	0	loadk        r30   k48 ; k48 = 76
.line	0	loadk        r31   k49 ; k49 = 47
.line	0	loadk        r32   k50 ; k50 = 33
.line	0	loadk        r33   k25 ; k25 = 174
.line	0	loadk        r34   k51 ; k51 = 199
.line	0	loadk        r35   k52 ; k52 = 186
.line	0	loadk        r36   k20 ; k20 = 25
.line	0	loadk        r37   k39 ; k39 = 227
.line	0	loadk        r38   k53 ; k53 = 19
.line	0	loadk        r39   k54 ; k54 = 245
.line	0	loadk        r40   k55 ; k55 = 191
.line	0	loadk        r41   k29 ; k29 = 229
.line	0	loadk        r42   k56 ; k56 = 250
.line	0	loadk        r43   k57 ; k57 = 208
.line	0	loadk        r44   k58 ; k58 = 253
.line	0	loadk        r45   k59 ; k59 = 127
.line	0	loadk        r46   k60 ; k60 = 27
.line	0	loadk        r47   k90 ; k90 = 10
.line	0	loadk        r48   k91 ; k91 = 59
.line	0	loadk        r49   k64 ; k64 = 146
.line	0	loadk        r50   k57 ; k57 = 208
.line	0	loadk        r51   k92 ; k92 = 176
.line	0	loadk        r52   k93 ; k93 = 11
.line	0	call         r12    41     2
.line	0	move         r13    r1
.line	0	loadk        r14   k94 ; k94 = 200
.line	0	loadk        r15  k147 ; k147 = 86
.line	0	loadk        r16  k151 ; k151 = 91
.line	0	loadk        r17   k37 ; k37 = 17
.line	0	loadk        r18  k152 ; k152 = 125
.line	0	loadk        r19   k72 ; k72 = 226
.line	0	loadk        r20   k57 ; k57 = 208
.line	0	loadk        r21  k153 ; k153 = 58
.line	0	loadk        r22  k154 ; k154 = 184
.line	0	loadk        r23  k155 ; k155 = 5
.line	0	loadk        r24   k82 ; k82 = 231
.line	0	loadk        r25  k156 ; k156 = 182
.line	0	loadk        r26   k85 ; k85 = 255
.line	0	loadk        r27   k45 ; k45 = 232
.line	0	loadk        r28  k157 ; k157 = 130
.line	0	loadk        r29  k158 ; k158 = 207
.line	0	loadk        r30  k159 ; k159 = 100
.line	0	loadk        r31  k124 ; k124 = 64
.line	0	loadk        r32  k160 ; k160 = 56
.line	0	loadk        r33  k149 ; k149 = 48
.line	0	loadk        r34   k17 ; k17 = 133
.line	0	loadk        r35   k57 ; k57 = 208
.line	0	loadk        r36    k7 ; k7 = 172
.line	0	loadk        r37   k77 ; k77 = 61
.line	0	loadk        r38   k25 ; k25 = 174
.line	0	loadk        r39   k89 ; k89 = 32
.line	0	loadk        r40   k74 ; k74 = 251
.line	0	loadk        r41   k62 ; k62 = 160
.line	0	loadk        r42   k31 ; k31 = 197
.line	0	loadk        r43   k30 ; k30 = 238
.line	0	loadk        r44  k118 ; k118 = 213
.line	0	loadk        r45   k45 ; k45 = 232
.line	0	loadk        r46  k161 ; k161 = 105
.line	0	loadk        r47  k162 ; k162 = 71
.line	0	loadk        r48  k163 ; k163 = 13
.line	0	loadk        r49  k122 ; k122 = 49
.line	0	loadk        r50  k103 ; k103 = 154
.line	0	loadk        r51  k114 ; k114 = 223
.line	0	loadk        r52  k164 ; k164 = 183
.line	0	loadk        r53   k68 ; k68 = 9
.line	0	call         r13    41     0
.line	0	setlist      r11     0     1
.line	0	call         r10     2     2
.line	0	call          r9     2     2
.line	0	gettabup     r10    u0   k16 ; k16 = "require"
.line	0	gettabup     r11    u0   k33 ; k33 = "table"
.line	0	gettable     r11   r11   k34 ; k34 = "concat"
.line	0	newtable     r12     1     0
.line	0	move         r13    r1
.line	0	loadk        r14   k35 ; k35 = 161
.line	0	loadk        r15   k36 ; k36 = 116
.line	0	loadk        r16   k19 ; k19 = 68
.line	0	loadk        r17   k37 ; k37 = 17
.line	0	loadk        r18   k38 ; k38 = 80
.line	0	loadk        r19   k39 ; k39 = 227
.line	0	loadk        r20   k40 ; k40 = 216
.line	0	loadk        r21   k41 ; k41 = 98
.line	0	loadk        r22   k42 ; k42 = 144
.line	0	loadk        r23   k26 ; k26 = 43
.line	0	loadk        r24   k32 ; k32 = 224
.line	0	loadk        r25   k43 ; k43 = 236
.line	0	loadk        r26   k44 ; k44 = 211
.line	0	loadk        r27   k45 ; k45 = 232
.line	0	loadk        r28   k46 ; k46 = 201
.line	0	loadk        r29   k47 ; k47 = 237
.line	0	loadk        r30   k41 ; k41 = 98
.line	0	loadk        r31   k48 ; k48 = 76
.line	0	loadk        r32   k49 ; k49 = 47
.line	0	loadk        r33   k50 ; k50 = 33
.line	0	loadk        r34   k25 ; k25 = 174
.line	0	loadk        r35   k51 ; k51 = 199
.line	0	loadk        r36   k52 ; k52 = 186
.line	0	loadk        r37   k20 ; k20 = 25
.line	0	loadk        r38   k39 ; k39 = 227
.line	0	loadk        r39   k53 ; k53 = 19
.line	0	loadk        r40   k54 ; k54 = 245
.line	0	loadk        r41   k55 ; k55 = 191
.line	0	loadk        r42   k29 ; k29 = 229
.line	0	loadk        r43   k56 ; k56 = 250
.line	0	loadk        r44   k57 ; k57 = 208
.line	0	loadk        r45   k58 ; k58 = 253
.line	0	loadk        r46   k59 ; k59 = 127
.line	0	loadk        r47   k60 ; k60 = 27
.line	0	loadk        r48   k90 ; k90 = 10
.line	0	loadk        r49   k91 ; k91 = 59
.line	0	loadk        r50   k64 ; k64 = 146
.line	0	loadk        r51   k57 ; k57 = 208
.line	0	loadk        r52   k92 ; k92 = 176
.line	0	loadk        r53   k93 ; k93 = 11
.line	0	call         r13    41     2
.line	0	move         r14    r1
.line	0	loadk        r15   k94 ; k94 = 200
.line	0	loadk        r16  k147 ; k147 = 86
.line	0	loadk        r17  k151 ; k151 = 91
.line	0	loadk        r18   k37 ; k37 = 17
.line	0	loadk        r19  k152 ; k152 = 125
.line	0	loadk        r20   k72 ; k72 = 226
.line	0	loadk        r21   k57 ; k57 = 208
.line	0	loadk        r22  k153 ; k153 = 58
.line	0	loadk        r23  k154 ; k154 = 184
.line	0	loadk        r24   k68 ; k68 = 9
.line	0	loadk        r25   k12 ; k12 = 235
.line	0	loadk        r26  k165 ; k165 = 166
.line	0	loadk        r27   k54 ; k54 = 245
.line	0	loadk        r28  k166 ; k166 = 202
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30  k101 ; k101 = 254
.line	0	loadk        r31   k41 ; k41 = 98
.line	0	loadk        r32   k48 ; k48 = 76
.line	0	loadk        r33  k153 ; k153 = 58
.line	0	loadk        r34  k136 ; k136 = 40
.line	0	loadk        r35  k167 ; k167 = 137
.line	0	loadk        r36  k168 ; k168 = 242
.line	0	loadk        r37    k7 ; k7 = 172
.line	0	loadk        r38   k37 ; k37 = 17
.line	0	loadk        r39  k119 ; k119 = 189
.line	0	loadk        r40  k160 ; k160 = 56
.line	0	loadk        r41   k54 ; k54 = 245
.line	0	loadk        r42  k165 ; k165 = 166
.line	0	loadk        r43   k29 ; k29 = 229
.line	0	loadk        r44   k46 ; k46 = 201
.line	0	loadk        r45   k44 ; k44 = 211
.line	0	loadk        r46  k168 ; k168 = 242
.line	0	loadk        r47   k76 ; k76 = 96
.line	0	loadk        r48  k120 ; k120 = 92
.line	0	loadk        r49  k169 ; k169 = 46
.line	0	call         r14    36     0
.line	0	setlist      r12     0     1
.line	0	call         r11     2     2
.line	0	call         r10     2     2
.line	0	gettabup     r11    u0   k16 ; k16 = "require"
.line	0	gettabup     r12    u0   k33 ; k33 = "table"
.line	0	gettable     r12   r12   k34 ; k34 = "concat"
.line	0	newtable     r13     1     0
.line	0	move         r14    r1
.line	0	loadk        r15   k35 ; k35 = 161
.line	0	loadk        r16   k36 ; k36 = 116
.line	0	loadk        r17   k19 ; k19 = 68
.line	0	loadk        r18   k37 ; k37 = 17
.line	0	loadk        r19   k38 ; k38 = 80
.line	0	loadk        r20   k39 ; k39 = 227
.line	0	loadk        r21   k40 ; k40 = 216
.line	0	loadk        r22   k41 ; k41 = 98
.line	0	loadk        r23   k42 ; k42 = 144
.line	0	loadk        r24   k26 ; k26 = 43
.line	0	loadk        r25   k32 ; k32 = 224
.line	0	loadk        r26   k43 ; k43 = 236
.line	0	loadk        r27   k44 ; k44 = 211
.line	0	loadk        r28   k45 ; k45 = 232
.line	0	loadk        r29   k46 ; k46 = 201
.line	0	loadk        r30   k47 ; k47 = 237
.line	0	loadk        r31   k41 ; k41 = 98
.line	0	loadk        r32   k48 ; k48 = 76
.line	0	loadk        r33   k49 ; k49 = 47
.line	0	loadk        r34   k50 ; k50 = 33
.line	0	loadk        r35   k25 ; k25 = 174
.line	0	loadk        r36   k51 ; k51 = 199
.line	0	loadk        r37   k52 ; k52 = 186
.line	0	loadk        r38   k20 ; k20 = 25
.line	0	loadk        r39   k39 ; k39 = 227
.line	0	loadk        r40   k53 ; k53 = 19
.line	0	loadk        r41   k54 ; k54 = 245
.line	0	loadk        r42   k55 ; k55 = 191
.line	0	loadk        r43   k29 ; k29 = 229
.line	0	loadk        r44   k56 ; k56 = 250
.line	0	loadk        r45   k57 ; k57 = 208
.line	0	loadk        r46   k58 ; k58 = 253
.line	0	loadk        r47   k59 ; k59 = 127
.line	0	loadk        r48   k60 ; k60 = 27
.line	0	loadk        r49   k90 ; k90 = 10
.line	0	loadk        r50   k91 ; k91 = 59
.line	0	loadk        r51  k170 ; k170 = 145
.line	0	loadk        r52  k113 ; k113 = 219
.line	0	loadk        r53  k156 ; k156 = 182
.line	0	loadk        r54  k171 ; k171 = 2
.line	0	call         r14    41     2
.line	0	move         r15    r1
.line	0	loadk        r16   k94 ; k94 = 200
.line	0	loadk        r17  k147 ; k147 = 86
.line	0	loadk        r18  k151 ; k151 = 91
.line	0	loadk        r19   k37 ; k37 = 17
.line	0	loadk        r20  k152 ; k152 = 125
.line	0	loadk        r21   k72 ; k72 = 226
.line	0	loadk        r22   k57 ; k57 = 208
.line	0	loadk        r23  k153 ; k153 = 58
.line	0	loadk        r24  k154 ; k154 = 184
.line	0	loadk        r25   k68 ; k68 = 9
.line	0	loadk        r26   k29 ; k29 = 229
.line	0	loadk        r27    k7 ; k7 = 172
.line	0	loadk        r28  k172 ; k172 = 241
.line	0	loadk        r29   k58 ; k58 = 253
.line	0	loadk        r30   k46 ; k46 = 201
.line	0	loadk        r31  k101 ; k101 = 254
.line	0	loadk        r32  k173 ; k173 = 66
.line	0	loadk        r33  k174 ; k174 = 74
.line	0	loadk        r34  k107 ; k107 = 54
.line	0	loadk        r35  k136 ; k136 = 40
.line	0	loadk        r36    k4 ; k4 = 159
.line	0	call         r15    22     0
.line	0	setlist      r13     0     1
.line	0	call         r12     2     2
.line	0	call         r11     2     2
.line	0	move         r12    r1
.line	0	loadk        r13  k175 ; k175 = 165
.line	0	loadk        r14   k76 ; k76 = 96
.line	0	loadk        r15    k9 ; k9 = 90
.line	0	loadk        r16   k13 ; k13 = 0
.line	0	loadk        r17   k21 ; k21 = 115
.line	0	loadk        r18   k74 ; k74 = 251
.line	0	loadk        r19  k100 ; k100 = 233
.line	0	loadk        r20   k69 ; k69 = 45
.line	0	loadk        r21  k176 ; k176 = 175
.line	0	loadk        r22  k149 ; k149 = 48
.line	0	loadk        r23   k47 ; k47 = 237
.line	0	loadk        r24   k35 ; k35 = 161
.line	0	loadk        r25  k128 ; k128 = 252
.line	0	loadk        r26   k85 ; k85 = 255
.line	0	loadk        r27  k102 ; k102 = 239
.line	0	loadk        r28   k39 ; k39 = 227
.line	0	loadk        r29    k6 ; k6 = 120
.line	0	loadk        r30  k177 ; k177 = 67
.line	0	loadk        r31  k149 ; k149 = 48
.line	0	loadk        r32  k131 ; k131 = 35
.line	0	call         r12    21     2
.line	0	gettabup     r13    u0   k33 ; k33 = "table"
.line	0	gettable     r13   r13   k34 ; k34 = "concat"
.line	0	newtable     r14     1     0
.line	0	move         r15    r1
.line	0	loadk        r16   k46 ; k46 = 201
.line	0	loadk        r17  k178 ; k178 = 82
.line	0	loadk        r18  k179 ; k179 = 72
.line	0	loadk        r19   k20 ; k20 = 25
.line	0	loadk        r20   k96 ; k96 = 121
.line	0	loadk        r21   k10 ; k10 = 185
.line	0	loadk        r22  k180 ; k180 = 244
.line	0	loadk        r23  k131 ; k131 = 35
.line	0	loadk        r24   k10 ; k10 = 185
.line	0	loadk        r25  k181 ; k181 = 107
.line	0	loadk        r26   k51 ; k51 = 199
.line	0	loadk        r27   k92 ; k92 = 176
.line	0	loadk        r28   k54 ; k54 = 245
.line	0	loadk        r29   k74 ; k74 = 251
.line	0	loadk        r30   k40 ; k40 = 216
.line	0	loadk        r31   k29 ; k29 = 229
.line	0	loadk        r32   k76 ; k76 = 96
.line	0	loadk        r33  k124 ; k124 = 64
.line	0	loadk        r34  k182 ; k182 = 28
.line	0	loadk        r35   k89 ; k89 = 32
.line	0	loadk        r36   k17 ; k17 = 133
.line	0	loadk        r37  k183 ; k183 = 210
.line	0	loadk        r38  k184 ; k184 = 230
.line	0	loadk        r39   k77 ; k77 = 61
.line	0	loadk        r40   k55 ; k55 = 191
.line	0	loadk        r41   k89 ; k89 = 32
.line	0	loadk        r42   k82 ; k82 = 231
.line	0	loadk        r43   k58 ; k58 = 253
.line	0	loadk        r44   k84 ; k84 = 206
.line	0	loadk        r45   k29 ; k29 = 229
.line	0	loadk        r46   k58 ; k58 = 253
.line	0	loadk        r47   k45 ; k45 = 232
.line	0	loadk        r48  k185 ; k185 = 106
.line	0	loadk        r49   k15 ; k15 = 84
.line	0	loadk        r50  k153 ; k153 = 58
.line	0	loadk        r51  k186 ; k186 = 123
.line	0	loadk        r52  k187 ; k187 = 169
.line	0	loadk        r53  k188 ; k188 = 209
.line	0	loadk        r54   k52 ; k52 = 186
.line	0	loadk        r55    k1 ; k1 = 51
.line	0	call         r15    41     2
.line	0	move         r16    r1
.line	0	loadk        r17  k176 ; k176 = 175
.line	0	loadk        r18  k141 ; k141 = 118
.line	0	loadk        r19  k189 ; k189 = 70
.line	0	loadk        r20   k61 ; k61 = 26
.line	0	loadk        r21  k177 ; k177 = 67
.line	0	loadk        r22  k190 ; k190 = 198
.line	0	loadk        r23   k40 ; k40 = 216
.line	0	loadk        r24  k191 ; k191 = 62
.line	0	loadk        r25  k187 ; k187 = 169
.line	0	loadk        r26   k69 ; k69 = 45
.line	0	loadk        r27   k82 ; k82 = 231
.line	0	loadk        r28   k25 ; k25 = 174
.line	0	loadk        r29   k54 ; k54 = 245
.line	0	loadk        r30   k73 ; k73 = 180
.line	0	loadk        r31   k67 ; k67 = 249
.line	0	loadk        r32   k12 ; k12 = 235
.line	0	loadk        r33  k130 ; k130 = 117
.line	0	loadk        r34   k18 ; k18 = 122
.line	0	loadk        r35    k3 ; k3 = 16
.line	0	loadk        r36  k121 ; k121 = 39
.line	0	loadk        r37  k192 ; k192 = 131
.line	0	loadk        r38   k94 ; k94 = 200
.line	0	loadk        r39  k193 ; k193 = 150
.line	0	loadk        r40   k80 ; k80 = 44
.line	0	loadk        r41    k7 ; k7 = 172
.line	0	loadk        r42   k24 ; k24 = 38
.line	0	loadk        r43   k32 ; k32 = 224
.line	0	loadk        r44   k79 ; k79 = 187
.line	0	loadk        r45   k39 ; k39 = 227
.line	0	loadk        r46  k184 ; k184 = 230
.line	0	loadk        r47  k194 ; k194 = 217
.line	0	call         r16    32     0
.line	0	setlist      r14     0     1
.line	0	call         r13     2     2
.line	0	move         r14   r13
.line	0	gettable     r15    r6  k195 ; k195 = "WORK_ASSET_TYPE"
.line	0	newtable     r16     0     9
.line	0	settable     r16  k196   k13 ; k13 = 0
.line	0	settable     r16  k197  k198 ; k198 = 1
.line	0	settable     r16  k199  k171 ; k171 = 2
.line	0	settable     r16  k200  k201 ; k201 = 3
.line	0	settable     r16  k202  k142 ; k142 = 4
.line	0	settable     r16  k203  k155 ; k155 = 5
.line	0	settable     r16  k204  k205 ; k205 = 6
.line	0	settable     r16  k206   k95 ; k95 = 7
.line	0	settable     r16  k207  k208 ; k208 = 8
.line	0	newtable     r17    17     0
.line	0	newtable     r18     0     5
.line	0	move         r19    r1
.line	0	loadk        r20  k157 ; k157 = 130
.line	0	loadk        r21   k65 ; k65 = 112
.line	0	loadk        r22  k210 ; k210 = 79
.line	0	loadk        r23   k14 ; k14 = 21
.line	0	loadk        r24  k161 ; k161 = 105
.line	0	loadk        r25   k56 ; k56 = 250
.line	0	loadk        r26  k135 ; k135 = 205
.line	0	loadk        r27   k53 ; k53 = 19
.line	0	loadk        r28  k111 ; k111 = 168
.line	0	loadk        r29   k99 ; k99 = 41
.line	0	loadk        r30   k39 ; k39 = 227
.line	0	call         r19    12     2
.line	0	settable     r18  k209   r19 ; k209 = "FolderID"
.line	0	move         r19    r1
.line	0	loadk        r20  k150 ; k150 = 179
.line	0	loadk        r21  k212 ; k212 = 88
.line	0	loadk        r22  k143 ; k143 = 110
.line	0	call         r19     4     2
.line	0	settable     r18  k211   r19 ; k211 = "FolderName"
.line	0	move         r19    r1
.line	0	call         r19     1     2
.line	0	settable     r18  k213   r19 ; k213 = "ParentFolderID"
.line	0	gettable     r19   r16  k197 ; k197 = "UMG"
.line	0	settable     r18  k214   r19 ; k214 = "FolderType"
.line	0	settable     r18  k215  k216 ; k216 = true
.line	0	newtable     r19     0     5
.line	0	move         r20    r1
.line	0	loadk        r21  k157 ; k157 = 130
.line	0	loadk        r22   k65 ; k65 = 112
.line	0	loadk        r23  k210 ; k210 = 79
.line	0	loadk        r24   k14 ; k14 = 21
.line	0	loadk        r25  k161 ; k161 = 105
.line	0	loadk        r26   k56 ; k56 = 250
.line	0	loadk        r27  k135 ; k135 = 205
.line	0	loadk        r28   k53 ; k53 = 19
.line	0	loadk        r29  k111 ; k111 = 168
.line	0	loadk        r30   k99 ; k99 = 41
.line	0	loadk        r31   k39 ; k39 = 227
.line	0	loadk        r32   k28 ; k28 = 157
.line	0	loadk        r33   k39 ; k39 = 227
.line	0	loadk        r34  k102 ; k102 = 239
.line	0	loadk        r35   k84 ; k84 = 206
.line	0	loadk        r36   k45 ; k45 = 232
.line	0	loadk        r37   k59 ; k59 = 127
.line	0	loadk        r38  k217 ; k217 = 87
.line	0	call         r20    19     2
.line	0	settable     r19  k209   r20 ; k209 = "FolderID"
.line	0	move         r20    r1
.line	0	loadk        r21   k83 ; k83 = 181
.line	0	loadk        r22   k76 ; k76 = 96
.line	0	loadk        r23   k66 ; k66 = 75
.line	0	loadk        r24  k149 ; k149 = 48
.line	0	loadk        r25  k130 ; k130 = 117
.line	0	loadk        r26  k218 ; k218 = 228
.line	0	call         r20     7     2
.line	0	settable     r19  k211   r20 ; k211 = "FolderName"
.line	0	move         r20    r1
.line	0	loadk        r21  k157 ; k157 = 130
.line	0	loadk        r22   k65 ; k65 = 112
.line	0	loadk        r23  k210 ; k210 = 79
.line	0	loadk        r24   k14 ; k14 = 21
.line	0	loadk        r25  k161 ; k161 = 105
.line	0	loadk        r26   k56 ; k56 = 250
.line	0	loadk        r27  k135 ; k135 = 205
.line	0	loadk        r28   k53 ; k53 = 19
.line	0	loadk        r29  k111 ; k111 = 168
.line	0	loadk        r30   k99 ; k99 = 41
.line	0	loadk        r31   k39 ; k39 = 227
.line	0	call         r20    12     2
.line	0	settable     r19  k213   r20 ; k213 = "ParentFolderID"
.line	0	gettable     r20   r16  k197 ; k197 = "UMG"
.line	0	settable     r19  k214   r20 ; k214 = "FolderType"
.line	0	settable     r19  k215  k216 ; k216 = true
.line	0	newtable     r20     0     5
.line	0	move         r21    r1
.line	0	loadk        r22  k157 ; k157 = 130
.line	0	loadk        r23   k65 ; k65 = 112
.line	0	loadk        r24  k210 ; k210 = 79
.line	0	loadk        r25   k14 ; k14 = 21
.line	0	loadk        r26  k161 ; k161 = 105
.line	0	loadk        r27   k56 ; k56 = 250
.line	0	loadk        r28  k135 ; k135 = 205
.line	0	loadk        r29   k53 ; k53 = 19
.line	0	loadk        r30  k219 ; k219 = 188
.line	0	loadk        r31  k121 ; k121 = 39
.line	0	loadk        r32   k70 ; k70 = 240
.line	0	loadk        r33   k71 ; k71 = 173
.line	0	loadk        r34   k72 ; k72 = 226
.line	0	call         r21    14     2
.line	0	settable     r20  k209   r21 ; k209 = "FolderID"
.line	0	move         r21    r1
.line	0	loadk        r22  k220 ; k220 = 167
.line	0	loadk        r23  k141 ; k141 = 118
.line	0	loadk        r24  k221 ; k221 = 93
.line	0	loadk        r25   k60 ; k60 = 27
.line	0	loadk        r26  k143 ; k143 = 110
.line	0	call         r21     6     2
.line	0	settable     r20  k211   r21 ; k211 = "FolderName"
.line	0	move         r21    r1
.line	0	call         r21     1     2
.line	0	settable     r20  k213   r21 ; k213 = "ParentFolderID"
.line	0	gettable     r21   r16  k199 ; k199 = "Actor"
.line	0	settable     r20  k214   r21 ; k214 = "FolderType"
.line	0	settable     r20  k215  k216 ; k216 = true
.line	0	newtable     r21     0     5
.line	0	move         r22    r1
.line	0	loadk        r23  k157 ; k157 = 130
.line	0	loadk        r24   k65 ; k65 = 112
.line	0	loadk        r25  k210 ; k210 = 79
.line	0	loadk        r26   k14 ; k14 = 21
.line	0	loadk        r27  k161 ; k161 = 105
.line	0	loadk        r28   k56 ; k56 = 250
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30   k53 ; k53 = 19
.line	0	loadk        r31  k219 ; k219 = 188
.line	0	loadk        r32  k121 ; k121 = 39
.line	0	loadk        r33   k70 ; k70 = 240
.line	0	loadk        r34   k71 ; k71 = 173
.line	0	loadk        r35   k72 ; k72 = 226
.line	0	loadk        r36   k31 ; k31 = 197
.line	0	loadk        r37  k114 ; k114 = 223
.line	0	loadk        r38   k67 ; k67 = 249
.line	0	loadk        r39   k36 ; k36 = 116
.line	0	loadk        r40   k75 ; k75 = 65
.line	0	loadk        r41  k149 ; k149 = 48
.line	0	loadk        r42  k107 ; k107 = 54
.line	0	call         r22    21     2
.line	0	settable     r21  k209   r22 ; k209 = "FolderID"
.line	0	move         r22    r1
.line	0	loadk        r23   k83 ; k83 = 181
.line	0	loadk        r24   k76 ; k76 = 96
.line	0	loadk        r25   k66 ; k66 = 75
.line	0	loadk        r26  k149 ; k149 = 48
.line	0	loadk        r27  k130 ; k130 = 117
.line	0	loadk        r28  k218 ; k218 = 228
.line	0	call         r22     7     2
.line	0	settable     r21  k211   r22 ; k211 = "FolderName"
.line	0	move         r22    r1
.line	0	loadk        r23  k157 ; k157 = 130
.line	0	loadk        r24   k65 ; k65 = 112
.line	0	loadk        r25  k210 ; k210 = 79
.line	0	loadk        r26   k14 ; k14 = 21
.line	0	loadk        r27  k161 ; k161 = 105
.line	0	loadk        r28   k56 ; k56 = 250
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30   k53 ; k53 = 19
.line	0	loadk        r31  k219 ; k219 = 188
.line	0	loadk        r32  k121 ; k121 = 39
.line	0	loadk        r33   k70 ; k70 = 240
.line	0	loadk        r34   k71 ; k71 = 173
.line	0	loadk        r35   k72 ; k72 = 226
.line	0	call         r22    14     2
.line	0	settable     r21  k213   r22 ; k213 = "ParentFolderID"
.line	0	gettable     r22   r16  k199 ; k199 = "Actor"
.line	0	settable     r21  k214   r22 ; k214 = "FolderType"
.line	0	settable     r21  k215  k216 ; k216 = true
.line	0	newtable     r22     0     5
.line	0	move         r23    r1
.line	0	loadk        r24  k157 ; k157 = 130
.line	0	loadk        r25   k65 ; k65 = 112
.line	0	loadk        r26  k210 ; k210 = 79
.line	0	loadk        r27   k14 ; k14 = 21
.line	0	loadk        r28  k161 ; k161 = 105
.line	0	loadk        r29   k56 ; k56 = 250
.line	0	loadk        r30  k135 ; k135 = 205
.line	0	loadk        r31   k53 ; k53 = 19
.line	0	loadk        r32   k73 ; k73 = 180
.line	0	loadk        r33   k99 ; k99 = 41
.line	0	loadk        r34   k29 ; k29 = 229
.line	0	loadk        r35  k175 ; k175 = 165
.line	0	loadk        r36   k54 ; k54 = 245
.line	0	call         r23    14     2
.line	0	settable     r22  k209   r23 ; k209 = "FolderID"
.line	0	move         r23    r1
.line	0	loadk        r24  k176 ; k176 = 175
.line	0	loadk        r25    k6 ; k6 = 120
.line	0	loadk        r26  k179 ; k179 = 72
.line	0	loadk        r27   k53 ; k53 = 19
.line	0	loadk        r28   k96 ; k96 = 121
.line	0	call         r23     6     2
.line	0	settable     r22  k211   r23 ; k211 = "FolderName"
.line	0	move         r23    r1
.line	0	call         r23     1     2
.line	0	settable     r22  k213   r23 ; k213 = "ParentFolderID"
.line	0	gettable     r23   r16  k202 ; k202 = "Image"
.line	0	settable     r22  k214   r23 ; k214 = "FolderType"
.line	0	settable     r22  k215  k216 ; k216 = true
.line	0	newtable     r23     0     5
.line	0	move         r24    r1
.line	0	loadk        r25  k157 ; k157 = 130
.line	0	loadk        r26   k65 ; k65 = 112
.line	0	loadk        r27  k210 ; k210 = 79
.line	0	loadk        r28   k14 ; k14 = 21
.line	0	loadk        r29  k161 ; k161 = 105
.line	0	loadk        r30   k56 ; k56 = 250
.line	0	loadk        r31  k135 ; k135 = 205
.line	0	loadk        r32   k53 ; k53 = 19
.line	0	loadk        r33   k73 ; k73 = 180
.line	0	loadk        r34   k99 ; k99 = 41
.line	0	loadk        r35   k29 ; k29 = 229
.line	0	loadk        r36  k175 ; k175 = 165
.line	0	loadk        r37   k54 ; k54 = 245
.line	0	loadk        r38   k31 ; k31 = 197
.line	0	loadk        r39  k114 ; k114 = 223
.line	0	loadk        r40   k67 ; k67 = 249
.line	0	loadk        r41   k36 ; k36 = 116
.line	0	loadk        r42   k75 ; k75 = 65
.line	0	loadk        r43  k149 ; k149 = 48
.line	0	loadk        r44  k107 ; k107 = 54
.line	0	call         r24    21     2
.line	0	settable     r23  k209   r24 ; k209 = "FolderID"
.line	0	move         r24    r1
.line	0	loadk        r25   k83 ; k83 = 181
.line	0	loadk        r26   k76 ; k76 = 96
.line	0	loadk        r27   k66 ; k66 = 75
.line	0	loadk        r28  k149 ; k149 = 48
.line	0	loadk        r29  k130 ; k130 = 117
.line	0	loadk        r30  k218 ; k218 = 228
.line	0	call         r24     7     2
.line	0	settable     r23  k211   r24 ; k211 = "FolderName"
.line	0	move         r24    r1
.line	0	loadk        r25  k157 ; k157 = 130
.line	0	loadk        r26   k65 ; k65 = 112
.line	0	loadk        r27  k210 ; k210 = 79
.line	0	loadk        r28   k14 ; k14 = 21
.line	0	loadk        r29  k161 ; k161 = 105
.line	0	loadk        r30   k56 ; k56 = 250
.line	0	loadk        r31  k135 ; k135 = 205
.line	0	loadk        r32   k53 ; k53 = 19
.line	0	loadk        r33   k73 ; k73 = 180
.line	0	loadk        r34   k99 ; k99 = 41
.line	0	loadk        r35   k29 ; k29 = 229
.line	0	loadk        r36  k175 ; k175 = 165
.line	0	loadk        r37   k54 ; k54 = 245
.line	0	call         r24    14     2
.line	0	settable     r23  k213   r24 ; k213 = "ParentFolderID"
.line	0	gettable     r24   r16  k202 ; k202 = "Image"
.line	0	settable     r23  k214   r24 ; k214 = "FolderType"
.line	0	settable     r23  k215  k216 ; k216 = true
.line	0	newtable     r24     0     5
.line	0	move         r25    r1
.line	0	loadk        r26  k157 ; k157 = 130
.line	0	loadk        r27   k65 ; k65 = 112
.line	0	loadk        r28  k210 ; k210 = 79
.line	0	loadk        r29   k14 ; k14 = 21
.line	0	loadk        r30  k161 ; k161 = 105
.line	0	loadk        r31   k56 ; k56 = 250
.line	0	loadk        r32  k135 ; k135 = 205
.line	0	loadk        r33   k53 ; k53 = 19
.line	0	loadk        r34  k219 ; k219 = 188
.line	0	loadk        r35  k122 ; k122 = 49
.line	0	loadk        r36   k32 ; k32 = 224
.line	0	loadk        r37  k222 ; k222 = 171
.line	0	loadk        r38   k85 ; k85 = 255
.line	0	call         r25    14     2
.line	0	settable     r24  k209   r25 ; k209 = "FolderID"
.line	0	move         r25    r1
.line	0	loadk        r26  k220 ; k220 = 167
.line	0	loadk        r27   k76 ; k76 = 96
.line	0	loadk        r28  k223 ; k223 = 77
.line	0	loadk        r29  k224 ; k224 = 29
.line	0	loadk        r30   k21 ; k21 = 115
.line	0	call         r25     6     2
.line	0	settable     r24  k211   r25 ; k211 = "FolderName"
.line	0	move         r25    r1
.line	0	call         r25     1     2
.line	0	settable     r24  k213   r25 ; k213 = "ParentFolderID"
.line	0	gettable     r25   r16  k200 ; k200 = "Audio"
.line	0	settable     r24  k214   r25 ; k214 = "FolderType"
.line	0	settable     r24  k215  k216 ; k216 = true
.line	0	newtable     r25     0     5
.line	0	move         r26    r1
.line	0	loadk        r27  k157 ; k157 = 130
.line	0	loadk        r28   k65 ; k65 = 112
.line	0	loadk        r29  k210 ; k210 = 79
.line	0	loadk        r30   k14 ; k14 = 21
.line	0	loadk        r31  k161 ; k161 = 105
.line	0	loadk        r32   k56 ; k56 = 250
.line	0	loadk        r33  k135 ; k135 = 205
.line	0	loadk        r34   k53 ; k53 = 19
.line	0	loadk        r35  k219 ; k219 = 188
.line	0	loadk        r36  k122 ; k122 = 49
.line	0	loadk        r37   k32 ; k32 = 224
.line	0	loadk        r38  k222 ; k222 = 171
.line	0	loadk        r39   k85 ; k85 = 255
.line	0	loadk        r40   k31 ; k31 = 197
.line	0	loadk        r41  k114 ; k114 = 223
.line	0	loadk        r42   k67 ; k67 = 249
.line	0	loadk        r43   k36 ; k36 = 116
.line	0	loadk        r44   k75 ; k75 = 65
.line	0	loadk        r45  k149 ; k149 = 48
.line	0	loadk        r46  k107 ; k107 = 54
.line	0	call         r26    21     2
.line	0	settable     r25  k209   r26 ; k209 = "FolderID"
.line	0	move         r26    r1
.line	0	loadk        r27   k83 ; k83 = 181
.line	0	loadk        r28   k76 ; k76 = 96
.line	0	loadk        r29   k66 ; k66 = 75
.line	0	loadk        r30  k149 ; k149 = 48
.line	0	loadk        r31  k130 ; k130 = 117
.line	0	loadk        r32  k218 ; k218 = 228
.line	0	call         r26     7     2
.line	0	settable     r25  k211   r26 ; k211 = "FolderName"
.line	0	move         r26    r1
.line	0	loadk        r27  k157 ; k157 = 130
.line	0	loadk        r28   k65 ; k65 = 112
.line	0	loadk        r29  k210 ; k210 = 79
.line	0	loadk        r30   k14 ; k14 = 21
.line	0	loadk        r31  k161 ; k161 = 105
.line	0	loadk        r32   k56 ; k56 = 250
.line	0	loadk        r33  k135 ; k135 = 205
.line	0	loadk        r34   k53 ; k53 = 19
.line	0	loadk        r35  k219 ; k219 = 188
.line	0	loadk        r36  k122 ; k122 = 49
.line	0	loadk        r37   k32 ; k32 = 224
.line	0	loadk        r38  k222 ; k222 = 171
.line	0	loadk        r39   k85 ; k85 = 255
.line	0	call         r26    14     2
.line	0	settable     r25  k213   r26 ; k213 = "ParentFolderID"
.line	0	gettable     r26   r16  k200 ; k200 = "Audio"
.line	0	settable     r25  k214   r26 ; k214 = "FolderType"
.line	0	settable     r25  k215  k216 ; k216 = true
.line	0	newtable     r26     0     5
.line	0	move         r27    r1
.line	0	loadk        r28  k157 ; k157 = 130
.line	0	loadk        r29   k65 ; k65 = 112
.line	0	loadk        r30  k210 ; k210 = 79
.line	0	loadk        r31   k14 ; k14 = 21
.line	0	loadk        r32  k161 ; k161 = 105
.line	0	loadk        r33   k56 ; k56 = 250
.line	0	loadk        r34  k135 ; k135 = 205
.line	0	loadk        r35   k53 ; k53 = 19
.line	0	loadk        r36   k92 ; k92 = 176
.line	0	loadk        r37   k26 ; k26 = 43
.line	0	loadk        r38   k32 ; k32 = 224
.line	0	loadk        r39  k220 ; k220 = 167
.line	0	loadk        r40  k128 ; k128 = 252
.line	0	call         r27    14     2
.line	0	settable     r26  k209   r27 ; k209 = "FolderID"
.line	0	move         r27    r1
.line	0	loadk        r28  k222 ; k222 = 171
.line	0	loadk        r29   k18 ; k18 = 122
.line	0	loadk        r30  k223 ; k223 = 77
.line	0	loadk        r31   k37 ; k37 = 17
.line	0	loadk        r32   k65 ; k65 = 112
.line	0	call         r27     6     2
.line	0	settable     r26  k211   r27 ; k211 = "FolderName"
.line	0	move         r27    r1
.line	0	call         r27     1     2
.line	0	settable     r26  k213   r27 ; k213 = "ParentFolderID"
.line	0	gettable     r27   r16  k203 ; k203 = "Model"
.line	0	settable     r26  k214   r27 ; k214 = "FolderType"
.line	0	settable     r26  k215  k216 ; k216 = true
.line	0	newtable     r27     0     5
.line	0	move         r28    r1
.line	0	loadk        r29  k157 ; k157 = 130
.line	0	loadk        r30   k65 ; k65 = 112
.line	0	loadk        r31  k210 ; k210 = 79
.line	0	loadk        r32   k14 ; k14 = 21
.line	0	loadk        r33  k161 ; k161 = 105
.line	0	loadk        r34   k56 ; k56 = 250
.line	0	loadk        r35  k135 ; k135 = 205
.line	0	loadk        r36   k53 ; k53 = 19
.line	0	loadk        r37   k92 ; k92 = 176
.line	0	loadk        r38   k26 ; k26 = 43
.line	0	loadk        r39   k32 ; k32 = 224
.line	0	loadk        r40  k220 ; k220 = 167
.line	0	loadk        r41  k128 ; k128 = 252
.line	0	loadk        r42   k31 ; k31 = 197
.line	0	loadk        r43  k114 ; k114 = 223
.line	0	loadk        r44   k67 ; k67 = 249
.line	0	loadk        r45   k36 ; k36 = 116
.line	0	loadk        r46   k75 ; k75 = 65
.line	0	loadk        r47  k149 ; k149 = 48
.line	0	loadk        r48  k107 ; k107 = 54
.line	0	call         r28    21     2
.line	0	settable     r27  k209   r28 ; k209 = "FolderID"
.line	0	move         r28    r1
.line	0	loadk        r29   k83 ; k83 = 181
.line	0	loadk        r30   k76 ; k76 = 96
.line	0	loadk        r31   k66 ; k66 = 75
.line	0	loadk        r32  k149 ; k149 = 48
.line	0	loadk        r33  k130 ; k130 = 117
.line	0	loadk        r34  k218 ; k218 = 228
.line	0	call         r28     7     2
.line	0	settable     r27  k211   r28 ; k211 = "FolderName"
.line	0	move         r28    r1
.line	0	loadk        r29  k157 ; k157 = 130
.line	0	loadk        r30   k65 ; k65 = 112
.line	0	loadk        r31  k210 ; k210 = 79
.line	0	loadk        r32   k14 ; k14 = 21
.line	0	loadk        r33  k161 ; k161 = 105
.line	0	loadk        r34   k56 ; k56 = 250
.line	0	loadk        r35  k135 ; k135 = 205
.line	0	loadk        r36   k53 ; k53 = 19
.line	0	loadk        r37   k92 ; k92 = 176
.line	0	loadk        r38   k26 ; k26 = 43
.line	0	loadk        r39   k32 ; k32 = 224
.line	0	loadk        r40  k220 ; k220 = 167
.line	0	loadk        r41  k128 ; k128 = 252
.line	0	call         r28    14     2
.line	0	settable     r27  k213   r28 ; k213 = "ParentFolderID"
.line	0	gettable     r28   r16  k203 ; k203 = "Model"
.line	0	settable     r27  k214   r28 ; k214 = "FolderType"
.line	0	settable     r27  k215  k216 ; k216 = true
.line	0	newtable     r28     0     5
.line	0	move         r29    r1
.line	0	loadk        r30  k157 ; k157 = 130
.line	0	loadk        r31   k65 ; k65 = 112
.line	0	loadk        r32  k210 ; k210 = 79
.line	0	loadk        r33   k14 ; k14 = 21
.line	0	loadk        r34  k161 ; k161 = 105
.line	0	loadk        r35   k56 ; k56 = 250
.line	0	loadk        r36  k135 ; k135 = 205
.line	0	loadk        r37   k53 ; k53 = 19
.line	0	loadk        r38  k219 ; k219 = 188
.line	0	loadk        r39  k225 ; k225 = 42
.line	0	loadk        r40   k47 ; k47 = 237
.line	0	loadk        r41  k176 ; k176 = 175
.line	0	call         r29    13     2
.line	0	settable     r28  k209   r29 ; k209 = "FolderID"
.line	0	move         r29    r1
.line	0	loadk        r30  k220 ; k220 = 167
.line	0	loadk        r31  k186 ; k186 = 123
.line	0	loadk        r32  k124 ; k124 = 64
.line	0	loadk        r33   k20 ; k20 = 25
.line	0	call         r29     5     2
.line	0	settable     r28  k211   r29 ; k211 = "FolderName"
.line	0	move         r29    r1
.line	0	call         r29     1     2
.line	0	settable     r28  k213   r29 ; k213 = "ParentFolderID"
.line	0	gettable     r29   r16  k204 ; k204 = "Anim"
.line	0	settable     r28  k214   r29 ; k214 = "FolderType"
.line	0	settable     r28  k215  k216 ; k216 = true
.line	0	newtable     r29     0     5
.line	0	move         r30    r1
.line	0	loadk        r31  k157 ; k157 = 130
.line	0	loadk        r32   k65 ; k65 = 112
.line	0	loadk        r33  k210 ; k210 = 79
.line	0	loadk        r34   k14 ; k14 = 21
.line	0	loadk        r35  k161 ; k161 = 105
.line	0	loadk        r36   k56 ; k56 = 250
.line	0	loadk        r37  k135 ; k135 = 205
.line	0	loadk        r38   k53 ; k53 = 19
.line	0	loadk        r39  k219 ; k219 = 188
.line	0	loadk        r40  k225 ; k225 = 42
.line	0	loadk        r41   k47 ; k47 = 237
.line	0	loadk        r42  k176 ; k176 = 175
.line	0	loadk        r43  k158 ; k158 = 207
.line	0	loadk        r44  k100 ; k100 = 233
.line	0	loadk        r45  k194 ; k194 = 217
.line	0	loadk        r46   k30 ; k30 = 238
.line	0	loadk        r47  k125 ; k125 = 114
.line	0	loadk        r48   k48 ; k48 = 76
.line	0	loadk        r49   k26 ; k26 = 43
.line	0	call         r30    20     2
.line	0	settable     r29  k209   r30 ; k209 = "FolderID"
.line	0	move         r30    r1
.line	0	loadk        r31   k83 ; k83 = 181
.line	0	loadk        r32   k76 ; k76 = 96
.line	0	loadk        r33   k66 ; k66 = 75
.line	0	loadk        r34  k149 ; k149 = 48
.line	0	loadk        r35  k130 ; k130 = 117
.line	0	loadk        r36  k218 ; k218 = 228
.line	0	call         r30     7     2
.line	0	settable     r29  k211   r30 ; k211 = "FolderName"
.line	0	move         r30    r1
.line	0	loadk        r31  k157 ; k157 = 130
.line	0	loadk        r32   k65 ; k65 = 112
.line	0	loadk        r33  k210 ; k210 = 79
.line	0	loadk        r34   k14 ; k14 = 21
.line	0	loadk        r35  k161 ; k161 = 105
.line	0	loadk        r36   k56 ; k56 = 250
.line	0	loadk        r37  k135 ; k135 = 205
.line	0	loadk        r38   k53 ; k53 = 19
.line	0	loadk        r39  k219 ; k219 = 188
.line	0	loadk        r40  k225 ; k225 = 42
.line	0	loadk        r41   k47 ; k47 = 237
.line	0	loadk        r42  k176 ; k176 = 175
.line	0	call         r30    13     2
.line	0	settable     r29  k213   r30 ; k213 = "ParentFolderID"
.line	0	gettable     r30   r16  k204 ; k204 = "Anim"
.line	0	settable     r29  k214   r30 ; k214 = "FolderType"
.line	0	settable     r29  k215  k216 ; k216 = true
.line	0	newtable     r30     0     5
.line	0	move         r31    r1
.line	0	loadk        r32  k157 ; k157 = 130
.line	0	loadk        r33   k65 ; k65 = 112
.line	0	loadk        r34  k210 ; k210 = 79
.line	0	loadk        r35   k14 ; k14 = 21
.line	0	loadk        r36  k161 ; k161 = 105
.line	0	loadk        r37   k56 ; k56 = 250
.line	0	loadk        r38  k135 ; k135 = 205
.line	0	loadk        r39   k53 ; k53 = 19
.line	0	loadk        r40   k71 ; k71 = 173
.line	0	loadk        r41  k107 ; k107 = 54
.line	0	loadk        r42    k0 ; k0 = 225
.line	0	loadk        r43  k226 ; k226 = 164
.line	0	loadk        r44  k172 ; k172 = 241
.line	0	loadk        r45   k22 ; k22 = 248
.line	0	call         r31    15     2
.line	0	settable     r30  k209   r31 ; k209 = "FolderID"
.line	0	move         r31    r1
.line	0	loadk        r32  k156 ; k156 = 182
.line	0	loadk        r33  k227 ; k227 = 103
.line	0	loadk        r34   k48 ; k48 = 76
.line	0	loadk        r35  k228 ; k228 = 18
.line	0	loadk        r36  k152 ; k152 = 125
.line	0	loadk        r37  k180 ; k180 = 244
.line	0	call         r31     7     2
.line	0	settable     r30  k211   r31 ; k211 = "FolderName"
.line	0	move         r31    r1
.line	0	call         r31     1     2
.line	0	settable     r30  k213   r31 ; k213 = "ParentFolderID"
.line	0	gettable     r31   r16  k206 ; k206 = "Prefab"
.line	0	settable     r30  k214   r31 ; k214 = "FolderType"
.line	0	settable     r30  k215  k216 ; k216 = true
.line	0	newtable     r31     0     5
.line	0	move         r32    r1
.line	0	loadk        r33  k157 ; k157 = 130
.line	0	loadk        r34   k65 ; k65 = 112
.line	0	loadk        r35  k210 ; k210 = 79
.line	0	loadk        r36   k14 ; k14 = 21
.line	0	loadk        r37  k161 ; k161 = 105
.line	0	loadk        r38   k56 ; k56 = 250
.line	0	loadk        r39  k135 ; k135 = 205
.line	0	loadk        r40   k53 ; k53 = 19
.line	0	loadk        r41   k71 ; k71 = 173
.line	0	loadk        r42  k107 ; k107 = 54
.line	0	loadk        r43    k0 ; k0 = 225
.line	0	loadk        r44  k226 ; k226 = 164
.line	0	loadk        r45  k172 ; k172 = 241
.line	0	loadk        r46   k22 ; k22 = 248
.line	0	loadk        r47   k86 ; k86 = 243
.line	0	loadk        r48   k85 ; k85 = 255
.line	0	loadk        r49  k229 ; k229 = 99
.line	0	loadk        r50  k162 ; k162 = 71
.line	0	loadk        r51   k77 ; k77 = 61
.line	0	loadk        r52   k69 ; k69 = 45
.line	0	loadk        r53   k11 ; k11 = 158
.line	0	call         r32    22     2
.line	0	settable     r31  k209   r32 ; k209 = "FolderID"
.line	0	move         r32    r1
.line	0	loadk        r33   k83 ; k83 = 181
.line	0	loadk        r34   k76 ; k76 = 96
.line	0	loadk        r35   k66 ; k66 = 75
.line	0	loadk        r36  k149 ; k149 = 48
.line	0	loadk        r37  k130 ; k130 = 117
.line	0	loadk        r38  k218 ; k218 = 228
.line	0	call         r32     7     2
.line	0	settable     r31  k211   r32 ; k211 = "FolderName"
.line	0	move         r32    r1
.line	0	loadk        r33  k157 ; k157 = 130
.line	0	loadk        r34   k65 ; k65 = 112
.line	0	loadk        r35  k210 ; k210 = 79
.line	0	loadk        r36   k14 ; k14 = 21
.line	0	loadk        r37  k161 ; k161 = 105
.line	0	loadk        r38   k56 ; k56 = 250
.line	0	loadk        r39  k135 ; k135 = 205
.line	0	loadk        r40   k53 ; k53 = 19
.line	0	loadk        r41   k71 ; k71 = 173
.line	0	loadk        r42  k107 ; k107 = 54
.line	0	loadk        r43    k0 ; k0 = 225
.line	0	loadk        r44  k226 ; k226 = 164
.line	0	loadk        r45  k172 ; k172 = 241
.line	0	loadk        r46   k22 ; k22 = 248
.line	0	call         r32    15     2
.line	0	settable     r31  k213   r32 ; k213 = "ParentFolderID"
.line	0	gettable     r32   r16  k206 ; k206 = "Prefab"
.line	0	settable     r31  k214   r32 ; k214 = "FolderType"
.line	0	settable     r31  k215  k216 ; k216 = true
.line	0	newtable     r32     0     5
.line	0	move         r33    r1
.line	0	loadk        r34  k157 ; k157 = 130
.line	0	loadk        r35   k65 ; k65 = 112
.line	0	loadk        r36  k210 ; k210 = 79
.line	0	loadk        r37   k14 ; k14 = 21
.line	0	loadk        r38  k161 ; k161 = 105
.line	0	loadk        r39   k56 ; k56 = 250
.line	0	loadk        r40  k135 ; k135 = 205
.line	0	loadk        r41   k53 ; k53 = 19
.line	0	loadk        r42  k154 ; k154 = 184
.line	0	loadk        r43    k8 ; k8 = 34
.line	0	loadk        r44   k72 ; k72 = 226
.line	0	loadk        r45  k220 ; k220 = 167
.line	0	loadk        r46   k86 ; k86 = 243
.line	0	loadk        r47   k30 ; k30 = 238
.line	0	call         r33    15     2
.line	0	settable     r32  k209   r33 ; k209 = "FolderID"
.line	0	move         r33    r1
.line	0	loadk        r34  k144 ; k144 = 163
.line	0	loadk        r35   k21 ; k21 = 115
.line	0	loadk        r36  k210 ; k210 = 79
.line	0	loadk        r37   k37 ; k37 = 17
.line	0	loadk        r38   k59 ; k59 = 127
.line	0	loadk        r39   k72 ; k72 = 226
.line	0	call         r33     7     2
.line	0	settable     r32  k211   r33 ; k211 = "FolderName"
.line	0	move         r33    r1
.line	0	call         r33     1     2
.line	0	settable     r32  k213   r33 ; k213 = "ParentFolderID"
.line	0	gettable     r33   r16  k207 ; k207 = "Effect"
.line	0	settable     r32  k214   r33 ; k214 = "FolderType"
.line	0	settable     r32  k215  k216 ; k216 = true
.line	0	newtable     r33     0     5
.line	0	move         r34    r1
.line	0	loadk        r35  k157 ; k157 = 130
.line	0	loadk        r36   k65 ; k65 = 112
.line	0	loadk        r37  k210 ; k210 = 79
.line	0	loadk        r38   k14 ; k14 = 21
.line	0	loadk        r39  k161 ; k161 = 105
.line	0	loadk        r40   k56 ; k56 = 250
.line	0	loadk        r41  k135 ; k135 = 205
.line	0	loadk        r42   k53 ; k53 = 19
.line	0	loadk        r43  k154 ; k154 = 184
.line	0	loadk        r44    k8 ; k8 = 34
.line	0	loadk        r45   k72 ; k72 = 226
.line	0	loadk        r46  k220 ; k220 = 167
.line	0	loadk        r47   k86 ; k86 = 243
.line	0	loadk        r48   k30 ; k30 = 238
.line	0	loadk        r49   k86 ; k86 = 243
.line	0	loadk        r50   k85 ; k85 = 255
.line	0	loadk        r51  k229 ; k229 = 99
.line	0	loadk        r52  k162 ; k162 = 71
.line	0	loadk        r53   k77 ; k77 = 61
.line	0	loadk        r54   k69 ; k69 = 45
.line	0	loadk        r55   k11 ; k11 = 158
.line	0	call         r34    22     2
.line	0	settable     r33  k209   r34 ; k209 = "FolderID"
.line	0	move         r34    r1
.line	0	loadk        r35   k83 ; k83 = 181
.line	0	loadk        r36   k76 ; k76 = 96
.line	0	loadk        r37   k66 ; k66 = 75
.line	0	loadk        r38  k149 ; k149 = 48
.line	0	loadk        r39  k130 ; k130 = 117
.line	0	loadk        r40  k218 ; k218 = 228
.line	0	call         r34     7     2
.line	0	settable     r33  k211   r34 ; k211 = "FolderName"
.line	0	move         r34    r1
.line	0	loadk        r35  k157 ; k157 = 130
.line	0	loadk        r36   k65 ; k65 = 112
.line	0	loadk        r37  k210 ; k210 = 79
.line	0	loadk        r38   k14 ; k14 = 21
.line	0	loadk        r39  k161 ; k161 = 105
.line	0	loadk        r40   k56 ; k56 = 250
.line	0	loadk        r41  k135 ; k135 = 205
.line	0	loadk        r42   k53 ; k53 = 19
.line	0	loadk        r43  k154 ; k154 = 184
.line	0	loadk        r44    k8 ; k8 = 34
.line	0	loadk        r45   k72 ; k72 = 226
.line	0	loadk        r46  k220 ; k220 = 167
.line	0	loadk        r47   k86 ; k86 = 243
.line	0	loadk        r48   k30 ; k30 = 238
.line	0	call         r34    15     2
.line	0	settable     r33  k213   r34 ; k213 = "ParentFolderID"
.line	0	gettable     r34   r16  k207 ; k207 = "Effect"
.line	0	settable     r33  k214   r34 ; k214 = "FolderType"
.line	0	settable     r33  k215  k216 ; k216 = true
.line	0	newtable     r34     0    12
.line	0	move         r35    r1
.line	0	loadk        r36  k157 ; k157 = 130
.line	0	loadk        r37   k65 ; k65 = 112
.line	0	loadk        r38  k210 ; k210 = 79
.line	0	loadk        r39   k14 ; k14 = 21
.line	0	loadk        r40  k161 ; k161 = 105
.line	0	loadk        r41   k56 ; k56 = 250
.line	0	loadk        r42  k135 ; k135 = 205
.line	0	loadk        r43   k53 ; k53 = 19
.line	0	loadk        r44  k219 ; k219 = 188
.line	0	loadk        r45  k121 ; k121 = 39
.line	0	loadk        r46   k70 ; k70 = 240
.line	0	loadk        r47   k71 ; k71 = 173
.line	0	loadk        r48   k72 ; k72 = 226
.line	0	loadk        r49   k31 ; k31 = 197
.line	0	loadk        r50  k129 ; k129 = 203
.line	0	loadk        r51   k47 ; k47 = 237
.line	0	loadk        r52  k186 ; k186 = 123
.line	0	loadk        r53  k124 ; k124 = 64
.line	0	loadk        r54  k205 ; k205 = 6
.line	0	loadk        r55  k121 ; k121 = 39
.line	0	loadk        r56  k192 ; k192 = 131
.line	0	loadk        r57  k230 ; k230 = 212
.line	0	loadk        r58    k7 ; k7 = 172
.line	0	call         r35    24     2
.line	0	settable     r34  k209   r35 ; k209 = "FolderID"
.line	0	move         r35    r1
.line	0	loadk        r36   k35 ; k35 = 161
.line	0	loadk        r37   k36 ; k36 = 116
.line	0	loadk        r38   k19 ; k19 = 68
.line	0	loadk        r39   k37 ; k37 = 17
.line	0	loadk        r40  k231 ; k231 = 95
.line	0	loadk        r41   k67 ; k67 = 249
.line	0	loadk        r42  k129 ; k129 = 203
.line	0	loadk        r43   k99 ; k99 = 41
.line	0	call         r35     9     2
.line	0	settable     r34  k211   r35 ; k211 = "FolderName"
.line	0	move         r35    r1
.line	0	loadk        r36  k157 ; k157 = 130
.line	0	loadk        r37   k65 ; k65 = 112
.line	0	loadk        r38  k210 ; k210 = 79
.line	0	loadk        r39   k14 ; k14 = 21
.line	0	loadk        r40  k161 ; k161 = 105
.line	0	loadk        r41   k56 ; k56 = 250
.line	0	loadk        r42  k135 ; k135 = 205
.line	0	loadk        r43   k53 ; k53 = 19
.line	0	loadk        r44  k219 ; k219 = 188
.line	0	loadk        r45  k121 ; k121 = 39
.line	0	loadk        r46   k70 ; k70 = 240
.line	0	loadk        r47   k71 ; k71 = 173
.line	0	loadk        r48   k72 ; k72 = 226
.line	0	call         r35    14     2
.line	0	settable     r34  k213   r35 ; k213 = "ParentFolderID"
.line	0	gettable     r35   r16  k199 ; k199 = "Actor"
.line	0	settable     r34  k214   r35 ; k214 = "FolderType"
.line	0	settable     r34  k215  k216 ; k216 = true
.line	0	settable     r34  k232  k216 ; k216 = true
.line	0	settable     r34  k233  k216 ; k216 = true
.line	0	settable     r34  k234  k216 ; k216 = true
.line	0	settable     r34  k235  k216 ; k216 = true
.line	0	settable     r34  k236  k216 ; k216 = true
.line	0	settable     r34  k237  k216 ; k216 = true
.line	0	settable     r34  k238  k198 ; k198 = 1
.line	0	setlist      r17    17     1
.line	0	newtable     r18     0     8
.line	0	gettable     r19    r7  k239 ; k239 = "CUSTOMUI"
.line	0	gettable     r20   r15  k197 ; k197 = "UMG"
.line	0	settable     r18   r19   r20
.line	0	gettable     r19    r7  k240 ; k240 = "SOUND"
.line	0	gettable     r20   r15  k200 ; k200 = "Audio"
.line	0	settable     r18   r19   r20
.line	0	gettable     r19    r7  k241 ; k241 = "IMAGE"
.line	0	gettable     r20   r15  k202 ; k202 = "Image"
.line	0	settable     r18   r19   r20
.line	0	gettable     r19    r7  k242 ; k242 = "STATICMESH"
.line	0	gettable     r20   r15  k203 ; k203 = "Model"
.line	0	settable     r18   r19   r20
.line	0	gettable     r19    r7  k243 ; k243 = "ANIM"
.line	0	gettable     r20   r15  k204 ; k204 = "Anim"
.line	0	settable     r18   r19   r20
.line	0	gettable     r19    r7  k244 ; k244 = "PREFAB"
.line	0	gettable     r20   r15  k206 ; k206 = "Prefab"
.line	0	settable     r18   r19   r20
.line	0	gettable     r19    r7  k245 ; k245 = "EFFECT"
.line	0	gettable     r20   r15  k207 ; k207 = "Effect"
.line	0	settable     r18   r19   r20
.line	0	gettable     r19    r7  k246 ; k246 = "ACTOR"
.line	0	gettable     r20   r15  k199 ; k199 = "Actor"
.line	0	settable     r18   r19   r20
.line	0	newtable     r19     0     8
.line	0	gettable     r20   r15  k197 ; k197 = "UMG"
.line	0	newtable     r21     0     2
.line	0	move         r22    r1
.line	0	loadk        r23  k157 ; k157 = 130
.line	0	loadk        r24   k65 ; k65 = 112
.line	0	loadk        r25  k210 ; k210 = 79
.line	0	loadk        r26   k14 ; k14 = 21
.line	0	loadk        r27  k161 ; k161 = 105
.line	0	loadk        r28   k56 ; k56 = 250
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30   k53 ; k53 = 19
.line	0	loadk        r31  k111 ; k111 = 168
.line	0	loadk        r32   k99 ; k99 = 41
.line	0	loadk        r33   k39 ; k39 = 227
.line	0	call         r22    12     2
.line	0	settable     r21  k247   r22 ; k247 = "RootFolderID"
.line	0	move         r22    r1
.line	0	loadk        r23  k157 ; k157 = 130
.line	0	loadk        r24   k65 ; k65 = 112
.line	0	loadk        r25  k210 ; k210 = 79
.line	0	loadk        r26   k14 ; k14 = 21
.line	0	loadk        r27  k161 ; k161 = 105
.line	0	loadk        r28   k56 ; k56 = 250
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30   k53 ; k53 = 19
.line	0	loadk        r31  k111 ; k111 = 168
.line	0	loadk        r32   k99 ; k99 = 41
.line	0	loadk        r33   k39 ; k39 = 227
.line	0	loadk        r34   k28 ; k28 = 157
.line	0	loadk        r35   k39 ; k39 = 227
.line	0	loadk        r36  k102 ; k102 = 239
.line	0	loadk        r37   k84 ; k84 = 206
.line	0	loadk        r38   k45 ; k45 = 232
.line	0	loadk        r39   k59 ; k59 = 127
.line	0	loadk        r40  k217 ; k217 = 87
.line	0	call         r22    19     2
.line	0	settable     r21  k248   r22 ; k248 = "DefaultSubFolderID"
.line	0	settable     r19   r20   r21
.line	0	gettable     r20   r15  k199 ; k199 = "Actor"
.line	0	newtable     r21     0     2
.line	0	move         r22    r1
.line	0	loadk        r23  k157 ; k157 = 130
.line	0	loadk        r24   k65 ; k65 = 112
.line	0	loadk        r25  k210 ; k210 = 79
.line	0	loadk        r26   k14 ; k14 = 21
.line	0	loadk        r27  k161 ; k161 = 105
.line	0	loadk        r28   k56 ; k56 = 250
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30   k53 ; k53 = 19
.line	0	loadk        r31  k219 ; k219 = 188
.line	0	loadk        r32  k121 ; k121 = 39
.line	0	loadk        r33   k70 ; k70 = 240
.line	0	loadk        r34   k71 ; k71 = 173
.line	0	loadk        r35   k72 ; k72 = 226
.line	0	call         r22    14     2
.line	0	settable     r21  k247   r22 ; k247 = "RootFolderID"
.line	0	move         r22    r1
.line	0	loadk        r23  k157 ; k157 = 130
.line	0	loadk        r24   k65 ; k65 = 112
.line	0	loadk        r25  k210 ; k210 = 79
.line	0	loadk        r26   k14 ; k14 = 21
.line	0	loadk        r27  k161 ; k161 = 105
.line	0	loadk        r28   k56 ; k56 = 250
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30   k53 ; k53 = 19
.line	0	loadk        r31  k219 ; k219 = 188
.line	0	loadk        r32  k121 ; k121 = 39
.line	0	loadk        r33   k70 ; k70 = 240
.line	0	loadk        r34   k71 ; k71 = 173
.line	0	loadk        r35   k72 ; k72 = 226
.line	0	loadk        r36   k31 ; k31 = 197
.line	0	loadk        r37  k114 ; k114 = 223
.line	0	loadk        r38   k67 ; k67 = 249
.line	0	loadk        r39   k36 ; k36 = 116
.line	0	loadk        r40   k75 ; k75 = 65
.line	0	loadk        r41  k149 ; k149 = 48
.line	0	loadk        r42  k107 ; k107 = 54
.line	0	call         r22    21     2
.line	0	settable     r21  k248   r22 ; k248 = "DefaultSubFolderID"
.line	0	settable     r19   r20   r21
.line	0	gettable     r20   r15  k200 ; k200 = "Audio"
.line	0	newtable     r21     0     2
.line	0	move         r22    r1
.line	0	loadk        r23  k157 ; k157 = 130
.line	0	loadk        r24   k65 ; k65 = 112
.line	0	loadk        r25  k210 ; k210 = 79
.line	0	loadk        r26   k14 ; k14 = 21
.line	0	loadk        r27  k161 ; k161 = 105
.line	0	loadk        r28   k56 ; k56 = 250
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30   k53 ; k53 = 19
.line	0	loadk        r31  k219 ; k219 = 188
.line	0	loadk        r32  k122 ; k122 = 49
.line	0	loadk        r33   k32 ; k32 = 224
.line	0	loadk        r34  k222 ; k222 = 171
.line	0	loadk        r35   k85 ; k85 = 255
.line	0	call         r22    14     2
.line	0	settable     r21  k247   r22 ; k247 = "RootFolderID"
.line	0	move         r22    r1
.line	0	loadk        r23  k157 ; k157 = 130
.line	0	loadk        r24   k65 ; k65 = 112
.line	0	loadk        r25  k210 ; k210 = 79
.line	0	loadk        r26   k14 ; k14 = 21
.line	0	loadk        r27  k161 ; k161 = 105
.line	0	loadk        r28   k56 ; k56 = 250
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30   k53 ; k53 = 19
.line	0	loadk        r31  k219 ; k219 = 188
.line	0	loadk        r32  k122 ; k122 = 49
.line	0	loadk        r33   k32 ; k32 = 224
.line	0	loadk        r34  k222 ; k222 = 171
.line	0	loadk        r35   k85 ; k85 = 255
.line	0	loadk        r36   k31 ; k31 = 197
.line	0	loadk        r37  k114 ; k114 = 223
.line	0	loadk        r38   k67 ; k67 = 249
.line	0	loadk        r39   k36 ; k36 = 116
.line	0	loadk        r40   k75 ; k75 = 65
.line	0	loadk        r41  k149 ; k149 = 48
.line	0	loadk        r42  k107 ; k107 = 54
.line	0	call         r22    21     2
.line	0	settable     r21  k248   r22 ; k248 = "DefaultSubFolderID"
.line	0	settable     r19   r20   r21
.line	0	gettable     r20   r15  k202 ; k202 = "Image"
.line	0	newtable     r21     0     2
.line	0	move         r22    r1
.line	0	loadk        r23  k157 ; k157 = 130
.line	0	loadk        r24   k65 ; k65 = 112
.line	0	loadk        r25  k210 ; k210 = 79
.line	0	loadk        r26   k14 ; k14 = 21
.line	0	loadk        r27  k161 ; k161 = 105
.line	0	loadk        r28   k56 ; k56 = 250
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30   k53 ; k53 = 19
.line	0	loadk        r31   k73 ; k73 = 180
.line	0	loadk        r32   k99 ; k99 = 41
.line	0	loadk        r33   k29 ; k29 = 229
.line	0	loadk        r34  k175 ; k175 = 165
.line	0	loadk        r35   k54 ; k54 = 245
.line	0	call         r22    14     2
.line	0	settable     r21  k247   r22 ; k247 = "RootFolderID"
.line	0	move         r22    r1
.line	0	loadk        r23  k157 ; k157 = 130
.line	0	loadk        r24   k65 ; k65 = 112
.line	0	loadk        r25  k210 ; k210 = 79
.line	0	loadk        r26   k14 ; k14 = 21
.line	0	loadk        r27  k161 ; k161 = 105
.line	0	loadk        r28   k56 ; k56 = 250
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30   k53 ; k53 = 19
.line	0	loadk        r31   k73 ; k73 = 180
.line	0	loadk        r32   k99 ; k99 = 41
.line	0	loadk        r33   k29 ; k29 = 229
.line	0	loadk        r34  k175 ; k175 = 165
.line	0	loadk        r35   k54 ; k54 = 245
.line	0	loadk        r36   k31 ; k31 = 197
.line	0	loadk        r37  k114 ; k114 = 223
.line	0	loadk        r38   k67 ; k67 = 249
.line	0	loadk        r39   k36 ; k36 = 116
.line	0	loadk        r40   k75 ; k75 = 65
.line	0	loadk        r41  k149 ; k149 = 48
.line	0	loadk        r42  k107 ; k107 = 54
.line	0	call         r22    21     2
.line	0	settable     r21  k248   r22 ; k248 = "DefaultSubFolderID"
.line	0	settable     r19   r20   r21
.line	0	gettable     r20   r15  k203 ; k203 = "Model"
.line	0	newtable     r21     0     2
.line	0	move         r22    r1
.line	0	loadk        r23  k157 ; k157 = 130
.line	0	loadk        r24   k65 ; k65 = 112
.line	0	loadk        r25  k210 ; k210 = 79
.line	0	loadk        r26   k14 ; k14 = 21
.line	0	loadk        r27  k161 ; k161 = 105
.line	0	loadk        r28   k56 ; k56 = 250
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30   k53 ; k53 = 19
.line	0	loadk        r31   k92 ; k92 = 176
.line	0	loadk        r32   k26 ; k26 = 43
.line	0	loadk        r33   k32 ; k32 = 224
.line	0	loadk        r34  k220 ; k220 = 167
.line	0	loadk        r35  k128 ; k128 = 252
.line	0	call         r22    14     2
.line	0	settable     r21  k247   r22 ; k247 = "RootFolderID"
.line	0	move         r22    r1
.line	0	loadk        r23  k157 ; k157 = 130
.line	0	loadk        r24   k65 ; k65 = 112
.line	0	loadk        r25  k210 ; k210 = 79
.line	0	loadk        r26   k14 ; k14 = 21
.line	0	loadk        r27  k161 ; k161 = 105
.line	0	loadk        r28   k56 ; k56 = 250
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30   k53 ; k53 = 19
.line	0	loadk        r31   k92 ; k92 = 176
.line	0	loadk        r32   k26 ; k26 = 43
.line	0	loadk        r33   k32 ; k32 = 224
.line	0	loadk        r34  k220 ; k220 = 167
.line	0	loadk        r35  k128 ; k128 = 252
.line	0	loadk        r36   k31 ; k31 = 197
.line	0	loadk        r37  k114 ; k114 = 223
.line	0	loadk        r38   k67 ; k67 = 249
.line	0	loadk        r39   k36 ; k36 = 116
.line	0	loadk        r40   k75 ; k75 = 65
.line	0	loadk        r41  k149 ; k149 = 48
.line	0	loadk        r42  k107 ; k107 = 54
.line	0	call         r22    21     2
.line	0	settable     r21  k248   r22 ; k248 = "DefaultSubFolderID"
.line	0	settable     r19   r20   r21
.line	0	gettable     r20   r15  k204 ; k204 = "Anim"
.line	0	newtable     r21     0     2
.line	0	move         r22    r1
.line	0	loadk        r23  k157 ; k157 = 130
.line	0	loadk        r24   k65 ; k65 = 112
.line	0	loadk        r25  k210 ; k210 = 79
.line	0	loadk        r26   k14 ; k14 = 21
.line	0	loadk        r27  k161 ; k161 = 105
.line	0	loadk        r28   k56 ; k56 = 250
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30   k53 ; k53 = 19
.line	0	loadk        r31  k219 ; k219 = 188
.line	0	loadk        r32  k225 ; k225 = 42
.line	0	loadk        r33   k47 ; k47 = 237
.line	0	loadk        r34  k176 ; k176 = 175
.line	0	call         r22    13     2
.line	0	settable     r21  k247   r22 ; k247 = "RootFolderID"
.line	0	move         r22    r1
.line	0	loadk        r23  k157 ; k157 = 130
.line	0	loadk        r24   k65 ; k65 = 112
.line	0	loadk        r25  k210 ; k210 = 79
.line	0	loadk        r26   k14 ; k14 = 21
.line	0	loadk        r27  k161 ; k161 = 105
.line	0	loadk        r28   k56 ; k56 = 250
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30   k53 ; k53 = 19
.line	0	loadk        r31  k219 ; k219 = 188
.line	0	loadk        r32  k225 ; k225 = 42
.line	0	loadk        r33   k47 ; k47 = 237
.line	0	loadk        r34  k176 ; k176 = 175
.line	0	loadk        r35  k158 ; k158 = 207
.line	0	loadk        r36  k100 ; k100 = 233
.line	0	loadk        r37  k194 ; k194 = 217
.line	0	loadk        r38   k30 ; k30 = 238
.line	0	loadk        r39  k125 ; k125 = 114
.line	0	loadk        r40   k48 ; k48 = 76
.line	0	loadk        r41   k26 ; k26 = 43
.line	0	call         r22    20     2
.line	0	settable     r21  k248   r22 ; k248 = "DefaultSubFolderID"
.line	0	settable     r19   r20   r21
.line	0	gettable     r20   r15  k206 ; k206 = "Prefab"
.line	0	newtable     r21     0     2
.line	0	move         r22    r1
.line	0	loadk        r23  k157 ; k157 = 130
.line	0	loadk        r24   k65 ; k65 = 112
.line	0	loadk        r25  k210 ; k210 = 79
.line	0	loadk        r26   k14 ; k14 = 21
.line	0	loadk        r27  k161 ; k161 = 105
.line	0	loadk        r28   k56 ; k56 = 250
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30   k53 ; k53 = 19
.line	0	loadk        r31   k71 ; k71 = 173
.line	0	loadk        r32  k107 ; k107 = 54
.line	0	loadk        r33    k0 ; k0 = 225
.line	0	loadk        r34  k226 ; k226 = 164
.line	0	loadk        r35  k172 ; k172 = 241
.line	0	loadk        r36   k22 ; k22 = 248
.line	0	call         r22    15     2
.line	0	settable     r21  k247   r22 ; k247 = "RootFolderID"
.line	0	move         r22    r1
.line	0	loadk        r23  k157 ; k157 = 130
.line	0	loadk        r24   k65 ; k65 = 112
.line	0	loadk        r25  k210 ; k210 = 79
.line	0	loadk        r26   k14 ; k14 = 21
.line	0	loadk        r27  k161 ; k161 = 105
.line	0	loadk        r28   k56 ; k56 = 250
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30   k53 ; k53 = 19
.line	0	loadk        r31   k71 ; k71 = 173
.line	0	loadk        r32  k107 ; k107 = 54
.line	0	loadk        r33    k0 ; k0 = 225
.line	0	loadk        r34  k226 ; k226 = 164
.line	0	loadk        r35  k172 ; k172 = 241
.line	0	loadk        r36   k22 ; k22 = 248
.line	0	loadk        r37   k86 ; k86 = 243
.line	0	loadk        r38   k85 ; k85 = 255
.line	0	loadk        r39  k229 ; k229 = 99
.line	0	loadk        r40  k162 ; k162 = 71
.line	0	loadk        r41   k77 ; k77 = 61
.line	0	loadk        r42   k69 ; k69 = 45
.line	0	loadk        r43   k11 ; k11 = 158
.line	0	call         r22    22     2
.line	0	settable     r21  k248   r22 ; k248 = "DefaultSubFolderID"
.line	0	settable     r19   r20   r21
.line	0	gettable     r20   r15  k207 ; k207 = "Effect"
.line	0	newtable     r21     0     2
.line	0	move         r22    r1
.line	0	loadk        r23  k157 ; k157 = 130
.line	0	loadk        r24   k65 ; k65 = 112
.line	0	loadk        r25  k210 ; k210 = 79
.line	0	loadk        r26   k14 ; k14 = 21
.line	0	loadk        r27  k161 ; k161 = 105
.line	0	loadk        r28   k56 ; k56 = 250
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30   k53 ; k53 = 19
.line	0	loadk        r31  k154 ; k154 = 184
.line	0	loadk        r32    k8 ; k8 = 34
.line	0	loadk        r33   k72 ; k72 = 226
.line	0	loadk        r34  k220 ; k220 = 167
.line	0	loadk        r35   k86 ; k86 = 243
.line	0	loadk        r36   k30 ; k30 = 238
.line	0	call         r22    15     2
.line	0	settable     r21  k247   r22 ; k247 = "RootFolderID"
.line	0	move         r22    r1
.line	0	loadk        r23  k157 ; k157 = 130
.line	0	loadk        r24   k65 ; k65 = 112
.line	0	loadk        r25  k210 ; k210 = 79
.line	0	loadk        r26   k14 ; k14 = 21
.line	0	loadk        r27  k161 ; k161 = 105
.line	0	loadk        r28   k56 ; k56 = 250
.line	0	loadk        r29  k135 ; k135 = 205
.line	0	loadk        r30   k53 ; k53 = 19
.line	0	loadk        r31  k154 ; k154 = 184
.line	0	loadk        r32    k8 ; k8 = 34
.line	0	loadk        r33   k72 ; k72 = 226
.line	0	loadk        r34  k220 ; k220 = 167
.line	0	loadk        r35   k86 ; k86 = 243
.line	0	loadk        r36   k30 ; k30 = 238
.line	0	loadk        r37   k86 ; k86 = 243
.line	0	loadk        r38   k85 ; k85 = 255
.line	0	loadk        r39  k229 ; k229 = 99
.line	0	loadk        r40  k162 ; k162 = 71
.line	0	loadk        r41   k77 ; k77 = 61
.line	0	loadk        r42   k69 ; k69 = 45
.line	0	loadk        r43   k11 ; k11 = 158
.line	0	call         r22    22     2
.line	0	settable     r21  k248   r22 ; k248 = "DefaultSubFolderID"
.line	0	settable     r19   r20   r21
.line	0	closure      r20    f1
.line	0	settable      r2  k249   r20 ; k249 = "PostInitialize"
.line	0	closure      r20    f2
.line	0	settable      r2  k250   r20 ; k250 = "RegisterEvent"
.line	0	closure      r20    f3
.line	0	settable      r2  k251   r20 ; k251 = L"OnInstanceDataTreeRe" (truncated)
.line	0	closure      r20    f4
.line	0	settable      r2  k252   r20 ; k252 = "OnHookEnterEditorCom" (truncated)
.line	0	closure      r20    f5
.line	0	settable      r2  k253   r20 ; k253 = "LoadWorkAssetData"
.line	0	closure      r20    f6
.line	0	settable      r2  k254   r20 ; k254 = "EnsureDefaultFolders"
.line	0	closure      r20    f7
.line	0	settable      r2  k255   r20 ; k255 = "GetFolderIDForAssetT" (truncated)
.line	0	loadk        r20  k256 ; k256 = "GetAssetRestrictions"
.line	0	closure      r21    f8
.line	0	settable      r2   r20   r21
.line	0	loadk        r20  k257 ; k257 = "ApplyAssetRestrictio" (truncated)
.line	0	closure      r21    f9
.line	0	settable      r2   r20   r21
.line	0	loadk        r20  k258 ; k258 = "IsAssetInPathMap"
.line	0	closure      r21   f10
.line	0	settable      r2   r20   r21
.line	0	loadk        r20  k259 ; k259 = "IsEffectAsset"
.line	0	closure      r21   f11
.line	0	settable      r2   r20   r21
.line	0	loadk        r20  k260 ; k260 = "SaveFolderTree"
.line	0	closure      r21   f12
.line	0	settable      r2   r20   r21
.line	0	newtable     r20     3     0
.line	0	move         r21    r1
.line	0	loadk        r22  k261 ; k261 = 167
.line	0	loadk        r23  k262 ; k262 = 102
.line	0	loadk        r24  k263 ; k263 = 90
.line	0	loadk        r25  k264 ; k264 = 17
.line	0	loadk        r26  k265 ; k265 = 104
.line	0	loadk        r27  k266 ; k266 = 216
.line	0	loadk        r28  k266 ; k266 = 216
.line	0	loadk        r29  k267 ; k267 = 33
.line	0	loadk        r30  k268 ; k268 = 184
.line	0	call         r21    10     2
.line	0	move         r22    r1
.line	0	loadk        r23  k269 ; k269 = 175
.line	0	loadk        r24  k270 ; k270 = 118
.line	0	loadk        r25  k271 ; k271 = 70
.line	0	loadk        r26   k61 ; k61 = 26
.line	0	call         r22     5     2
.line	0	move         r23    r1
.line	0	loadk        r24  k106 ; k106 = 162
.line	0	loadk        r25  k272 ; k272 = 112
.line	0	loadk        r26  k263 ; k263 = 90
.line	0	loadk        r27  k273 ; k273 = 23
.line	0	call         r23     5     2
.line	0	setlist      r20     3     1
.line	0	closure      r21   f13
.line	0	loadk        r22  k274 ; k274 = "ClampWorkAssetString" (truncated)
.line	0	closure      r23   f14
.line	0	settable      r2   r22   r23
.line	0	newtable     r22     2     0
.line	0	move         r23    r1
.line	0	loadk        r24  k275 ; k275 = 175
.line	0	loadk        r25  k270 ; k270 = 118
.line	0	loadk        r26  k271 ; k271 = 70
.line	0	loadk        r27  k276 ; k276 = 26
.line	0	call         r23     5     2
.line	0	move         r24    r1
.line	0	loadk        r25  k277 ; k277 = 162
.line	0	loadk        r26  k272 ; k272 = 112
.line	0	loadk        r27  k263 ; k263 = 90
.line	0	loadk        r28  k278 ; k278 = 23
.line	0	call         r24     5     2
.line	0	setlist      r22     2     1
.line	0	closure      r23   f15
.line	0	loadk        r24  k279 ; k279 = "SaveAssetPathMap"
.line	0	closure      r25   f16
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k280 ; k280 = "_IsLocalWorkAsset"
.line	0	closure      r25   f17
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k281 ; k281 = "FillWorkAssetDisplay" (truncated)
.line	0	closure      r25   f18
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k282 ; k282 = "OnReqWorkAssetData"
.line	0	closure      r25   f19
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k283 ; k283 = "OnReqMyPrefabMallMet" (truncated)
.line	0	closure      r25   f20
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k284 ; k284 = "SyncMyPrefabMallMeta" (truncated)
.line	0	closure      r25   f21
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k285 ; k285 = "CollectAllLatestAsse" (truncated)
.line	0	closure      r25   f22
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k286 ; k286 = "OnWorkAssetDataChang" (truncated)
.line	0	closure      r25   f23
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k287 ; k287 = "OnUMGInfoMapChanged"
.line	0	closure      r25   f24
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k288 ; k288 = "OnCustomAssetMountSt" (truncated)
.line	0	closure      r25   f25
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k289 ; k289 = "OnCustomAssetMountSt" (truncated)
.line	0	closure      r25   f26
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k290 ; k290 = "OnCustomAssetMountSt" (truncated)
.line	0	closure      r25   f27
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k291 ; k291 = "SyncEffectDataToAsse" (truncated)
.line	0	closure      r25   f28
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k292 ; k292 = "SyncActorDataToAsset" (truncated)
.line	0	closure      r25   f29
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k293 ; k293 = "SyncUMGDataToAssetPa" (truncated)
.line	0	closure      r25   f30
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k294 ; k294 = "OnReqImportWorkAsset"
.line	0	closure      r25   f31
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k295 ; k295 = "AddAssetToPathMapOnI" (truncated)
.line	0	closure      r25   f32
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k296 ; k296 = "OnReqUnloadWorkAsset"
.line	0	closure      r25   f33
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k297 ; k297 = "IsUMGCanvasAsset"
.line	0	closure      r25   f34
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k298 ; k298 = "IsUMGSourceImported"
.line	0	closure      r25   f35
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k299 ; k299 = "IsCanvasHeldByEditSe" (truncated)
.line	0	closure      r25   f36
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k300 ; k300 = "RequestRemoveUMGCanv" (truncated)
.line	0	closure      r25   f37
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k301 ; k301 = "ImportActorsFromPref" (truncated)
.line	0	closure      r25   f38
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k302 ; k302 = "ImportUMGsFromPrefab" (truncated)
.line	0	closure      r25   f39
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k303 ; k303 = "SyncWorkAssetDataToE" (truncated)
.line	0	closure      r25   f40
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k304 ; k304 = "OnReqWorkAssetSave"
.line	0	closure      r25   f41
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k305 ; k305 = "SendSaveResponse"
.line	0	closure      r25   f42
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k306 ; k306 = "CollectMyPrefabMallM" (truncated)
.line	0	closure      r25   f43
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k307 ; k307 = "GetCustomAssetKeyByA" (truncated)
.line	0	closure      r25   f44
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k308 ; k308 = "ReleaseSubMgrInGame"
.line	0	closure      r25   f45
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k309 ; k309 = "OnEnterEditorComplet" (truncated)
.line	0	closure      r25   f46
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k310 ; k310 = "require"
.line	0	gettabup     r24    u0   r24
.line	0	move         r25    r1
.line	0	loadk        r26  k311 ; k311 = 133
.line	0	loadk        r27  k312 ; k312 = 121
.line	0	loadk        r28  k313 ; k313 = 72
.line	0	loadk        r29  k314 ; k314 = 7
.line	0	loadk        r30  k315 ; k315 = 111
.line	0	call         r25     6     2
.line	0	call         r24     2     2
.line	0	loadk        r25  k310 ; k310 = "require"
.line	0	gettabup     r25    u0   r25
.line	0	loadk        r26  k316 ; k316 = "table"
.line	0	gettabup     r26    u0   r26
.line	0	loadk        r27  k317 ; k317 = "concat"
.line	0	gettable     r26   r26   r27
.line	0	newtable     r27     1     0
.line	0	move         r28    r1
.line	0	loadk        r29  k318 ; k318 = 161
.line	0	loadk        r30  k319 ; k319 = 116
.line	0	loadk        r31  k320 ; k320 = 68
.line	0	loadk        r32  k321 ; k321 = 17
.line	0	loadk        r33  k322 ; k322 = 80
.line	0	loadk        r34  k323 ; k323 = 227
.line	0	loadk        r35  k324 ; k324 = 216
.line	0	loadk        r36  k325 ; k325 = 98
.line	0	loadk        r37  k326 ; k326 = 144
.line	0	loadk        r38  k327 ; k327 = 43
.line	0	loadk        r39  k328 ; k328 = 224
.line	0	loadk        r40  k329 ; k329 = 236
.line	0	loadk        r41  k330 ; k330 = 211
.line	0	loadk        r42  k331 ; k331 = 232
.line	0	loadk        r43  k332 ; k332 = 201
.line	0	loadk        r44  k333 ; k333 = 237
.line	0	loadk        r45  k325 ; k325 = 98
.line	0	loadk        r46  k334 ; k334 = 76
.line	0	loadk        r47  k335 ; k335 = 47
.line	0	loadk        r48  k336 ; k336 = 33
.line	0	loadk        r49  k337 ; k337 = 174
.line	0	loadk        r50  k338 ; k338 = 199
.line	0	loadk        r51  k339 ; k339 = 186
.line	0	loadk        r52  k340 ; k340 = 25
.line	0	loadk        r53  k323 ; k323 = 227
.line	0	loadk        r54  k341 ; k341 = 19
.line	0	loadk        r55  k342 ; k342 = 245
.line	0	loadk        r56  k343 ; k343 = 191
.line	0	loadk        r57   k29 ; k29 = 229
.line	0	loadk        r58  k344 ; k344 = 250
.line	0	loadk        r59  k345 ; k345 = 208
.line	0	loadk        r60  k346 ; k346 = 253
.line	0	loadk        r61  k347 ; k347 = 127
.line	0	loadk        r62  k348 ; k348 = 27
.line	0	loadk        r63  k349 ; k349 = 26
.line	0	loadk        r64  k336 ; k336 = 33
.line	0	loadk        r65  k350 ; k350 = 158
.line	0	loadk        r66  k351 ; k351 = 197
.line	0	loadk        r67  k352 ; k352 = 160
.line	0	loadk        r68  k353 ; k353 = 31
.line	0	call         r28    41     2
.line	0	move         r29    r1
.line	0	loadk        r30  k354 ; k354 = 146
.line	0	loadk        r31  k355 ; k355 = 112
.line	0	loadk        r32  k320 ; k320 = 68
.line	0	loadk        r33  k356 ; k356 = 90
.line	0	loadk        r34  k357 ; k357 = 75
.line	0	loadk        r35  k358 ; k358 = 249
.line	0	loadk        r36  k359 ; k359 = 238
.line	0	loadk        r37  k360 ; k360 = 9
.line	0	loadk        r38  k361 ; k361 = 185
.line	0	loadk        r39  k362 ; k362 = 45
.line	0	loadk        r40  k363 ; k363 = 240
.line	0	loadk        r41  k364 ; k364 = 173
.line	0	loadk        r42  k365 ; k365 = 226
.line	0	loadk        r43  k366 ; k366 = 180
.line	0	loadk        r44  k367 ; k367 = 251
.line	0	loadk        r45  k323 ; k323 = 227
.line	0	loadk        r46  k368 ; k368 = 65
.line	0	loadk        r47  k369 ; k369 = 96
.line	0	loadk        r48  k370 ; k370 = 61
.line	0	loadk        r49  k362 ; k362 = 45
.line	0	loadk        r50  k371 ; k371 = 152
.line	0	loadk        r51  k332 ; k332 = 201
.line	0	loadk        r52  k372 ; k372 = 187
.line	0	loadk        r53  k373 ; k373 = 62
.line	0	loadk        r54  k374 ; k374 = 172
.line	0	loadk        r55  k375 ; k375 = 39
.line	0	loadk        r56  k376 ; k376 = 241
.line	0	loadk        r57  k377 ; k377 = 129
.line	0	loadk        r58  k342 ; k342 = 245
.line	0	loadk        r59  k331 ; k331 = 232
.line	0	loadk        r60  k376 ; k376 = 241
.line	0	loadk        r61  k367 ; k367 = 251
.line	0	loadk        r62  k319 ; k319 = 116
.line	0	call         r29    34     0
.line	0	setlist      r27     0     1
.line	0	call         r26     2     2
.line	0	call         r25     2     2
.line	0	move         r26   r24
.line	0	move         r27   r25
.line	0	loadnil      r28     0
.line	0	move         r29    r2
.line	0	tailcall     r26     4
.line	0	return       r26     0
.line	0	return        r0     1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f0

.source	null
.linedefined	2
.lastlinedefined	9
.numparams	0
.is_vararg	1
.maxstacksize	9

.upvalue	"_ENV"	0	false
.upvalue	"U1"	0	true

.constant	k0	1
.constant	k1	"string"
.constant	k2	"char"
.constant	k3	16
.constant	k4	31
.constant	k5	7
.constant	k6	256
.constant	k7	"table"
.constant	k8	"concat"

.line	2	newtable      r0     0     0
.line	2	vararg        r1     0
.line	2	setlist       r0     0     1
.line	2	newtable      r1     0     0
.line	2	loadk         r2    k0 ; k0 = 1
.line	2	len           r3    r0
.line	2	loadk         r4    k0 ; k0 = 1
.line	2	move          r0    r0
.line	2	gettabup      r6    u0    k1 ; k1 = "string"
.line	2	gettable      r6    r6    k2 ; k2 = "char"
.line	2	gettable      r7    r0    r5
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mod           r8    r8    k3 ; k3 = 16
.line	2	add           r8    r8    k0 ; k0 = 1
.line	2	gettabup      r8    u1    r8
.line	2	bxor          r7    r7    r8
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mul           r8    r8    k4 ; k4 = 31
.line	2	add           r8    r8    k5 ; k5 = 7
.line	2	mod           r8    r8    k6 ; k6 = 256
.line	2	bxor          r7    r7    r8
.line	2	mod           r7    r7    k6 ; k6 = 256
.line	2	call          r6     2     2
.line	2	settable      r1    r5    r6
.line	2	move          r0    r0
.line	2	gettabup      r2    u0    k7 ; k7 = "table"
.line	2	gettable      r2    r2    k8 ; k8 = "concat"
.line	2	move          r3    r1
.line	2	tailcall      r2     2
.line	2	return        r2     0
.line	2	return        r0     1
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	return        r0     1

.function	main/f1

.source	null
.linedefined	222
.lastlinedefined	233
.numparams	1
.is_vararg	0
.maxstacksize	42

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	2	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	177
.constant	k3	122
.constant	k4	126
.constant	k5	49
.constant	k6	120
.constant	k7	255
.constant	k8	205
.constant	k9	35
.constant	k10	175
.constant	k11	19
.constant	k12	235
.constant	k13	176
.constant	k14	251
.constant	k15	219
.constant	k16	223
.constant	k17	115
.constant	k18	81
.constant	k19	10
.constant	k20	142
.constant	k21	174
.constant	k22	14
.constant	k23	247
.constant	k24	4
.constant	k25	161
.constant	k26	244
.constant	k27	195
.constant	k28	210
.constant	k29	245
.constant	k30	114
.constant	k31	92
.constant	k32	40
.constant	k33	56
.constant	k34	149
.constant	k35	204
.constant	k36	188
.constant	k37	"__super"
.constant	k38	"PostInitialize"
.constant	k39	"FolderTree"
.constant	k40	"AssetPathMap"
.constant	k41	"ImportingAssetMap"
.constant	k42	"ImportingActorFolderMap"
.constant	k43	"ImportingUMGCanvasInfoMap"
.constant	k44	"ImportingUIAssetMap"
.constant	k45	"UMGCanvasSourceAssetMap"
.constant	k46	"UnloadingAssetIds"

.line	222	gettabup      r1    u0    k0 ; k0 = "print"
.line	222	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	222	test          r2     0
.line	222	jmp            0   l46
.line	222	getupval      r2    u1
.line	222	loadk         r3    k2 ; k2 = 177
.line	222	loadk         r4    k3 ; k3 = 122
.line	222	loadk         r5    k4 ; k4 = 126
.line	222	loadk         r6    k5 ; k5 = 49
.line	222	loadk         r7    k6 ; k6 = 120
.line	222	loadk         r8    k7 ; k7 = 255
.line	222	loadk         r9    k8 ; k8 = 205
.line	222	loadk        r10    k9 ; k9 = 35
.line	222	loadk        r11   k10 ; k10 = 175
.line	222	loadk        r12   k11 ; k11 = 19
.line	222	loadk        r13   k12 ; k12 = 235
.line	222	loadk        r14   k13 ; k13 = 176
.line	222	loadk        r15   k14 ; k14 = 251
.line	222	loadk        r16   k15 ; k15 = 219
.line	222	loadk        r17   k16 ; k16 = 223
.line	222	loadk        r18    k7 ; k7 = 255
.line	222	loadk        r19   k17 ; k17 = 115
.line	222	loadk        r20   k18 ; k18 = 81
.line	222	loadk        r21   k19 ; k19 = 10
.line	222	loadk        r22    k5 ; k5 = 49
.line	222	loadk        r23   k20 ; k20 = 142
.line	222	loadk        r24   k12 ; k12 = 235
.line	222	loadk        r25   k21 ; k21 = 174
.line	222	loadk        r26   k22 ; k22 = 14
.line	222	loadk        r27   k23 ; k23 = 247
.line	222	loadk        r28   k24 ; k24 = 4
.line	222	loadk        r29   k14 ; k14 = 251
.line	222	loadk        r30   k25 ; k25 = 161
.line	222	loadk        r31   k26 ; k26 = 244
.line	222	loadk        r32   k27 ; k27 = 195
.line	222	loadk        r33   k28 ; k28 = 210
.line	222	loadk        r34   k29 ; k29 = 245
.line	222	loadk        r35   k30 ; k30 = 114
.line	222	loadk        r36   k31 ; k31 = 92
.line	222	loadk        r37   k32 ; k32 = 40
.line	222	loadk        r38   k33 ; k33 = 56
.line	222	loadk        r39   k34 ; k34 = 149
.line	222	loadk        r40   k35 ; k35 = 204
.line	222	loadk        r41   k36 ; k36 = 188
.line	222	call          r2    40     2
.label	l46
.line	222	call          r1     2     1
.line	222	gettabup      r1    u2   k37 ; k37 = "__super"
.line	222	gettable      r1    r1   k38 ; k38 = "PostInitialize"
.line	222	move          r2    r0
.line	222	call          r1     2     1
.line	222	newtable      r1     0     0
.line	222	settable      r0   k39    r1 ; k39 = "FolderTree"
.line	222	newtable      r1     0     0
.line	222	settable      r0   k40    r1 ; k40 = "AssetPathMap"
.line	222	newtable      r1     0     0
.line	222	settable      r0   k41    r1 ; k41 = "ImportingAssetMap"
.line	222	newtable      r1     0     0
.line	222	settable      r0   k42    r1 ; k42 = "ImportingActorFolder" (truncated)
.line	222	newtable      r1     0     0
.line	222	settable      r0   k43    r1 ; k43 = "ImportingUMGCanvasIn" (truncated)
.line	222	newtable      r1     0     0
.line	222	settable      r0   k44    r1 ; k44 = "ImportingUIAssetMap"
.line	222	newtable      r1     0     0
.line	222	settable      r0   k45    r1 ; k45 = "UMGCanvasSourceAsset" (truncated)
.line	222	newtable      r1     0     0
.line	222	settable      r0   k46    r1 ; k46 = "UnloadingAssetIds"
.line	222	return        r0     1
.line	222	move          r0    r0
.line	222	return        r0     1

.function	main/f2

.source	null
.linedefined	235
.lastlinedefined	262
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	2	true
.upvalue	"U3"	4	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	177
.constant	k3	122
.constant	k4	126
.constant	k5	49
.constant	k6	120
.constant	k7	255
.constant	k8	205
.constant	k9	35
.constant	k10	175
.constant	k11	19
.constant	k12	235
.constant	k13	176
.constant	k14	251
.constant	k15	219
.constant	k16	223
.constant	k17	115
.constant	k18	81
.constant	k19	10
.constant	k20	142
.constant	k21	174
.constant	k22	14
.constant	k23	247
.constant	k24	6
.constant	k25	241
.constant	k26	181
.constant	k27	233
.constant	k28	249
.constant	k29	200
.constant	k30	116
.constant	k31	112
.constant	k32	63
.constant	k33	146
.constant	k34	194
.constant	k35	"__super"
.constant	k36	"RegisterEvent"
.constant	k37	"AddCommonEvent"
.constant	k38	"EVENTTYPE_WOW_EDITOR"
.constant	k39	"EVENTID_WOW_EDITOR_ENTER_EDITOR_COMPLETE"
.constant	k40	"OnHookEnterEditorComplete"
.constant	k41	"EVENTTYPE_CREATIVE"
.constant	k42	"EVENTID_WORKASSETDATA_CHANGED"
.constant	k43	"OnWorkAssetDataChanged"
.constant	k44	"EVENTTYPE_INGAME_CREATIVE_MODE"
.constant	k45	L"EVENTID_CUSTOM_ASSET_MOUNT_STATE_CHANGE_LIST"
.constant	k46	"EVENTID_CUSTOM_ASSET_MOUNT_STATE_CHANGE"
.constant	k47	"OnCustomAssetMountStateChange"
.constant	k48	"EVENTID_UMGINFO_MAP_CHANGED"
.constant	k49	"OnUMGInfoMapChanged"
.constant	k50	"require"
.constant	k51	"table"
.constant	k52	"concat"
.constant	k53	161
.constant	k54	68
.constant	k55	17
.constant	k56	80
.constant	k57	227
.constant	k58	216
.constant	k59	98
.constant	k60	144
.constant	k61	43
.constant	k62	224
.constant	k63	236
.constant	k64	211
.constant	k65	232
.constant	k66	201
.constant	k67	237
.constant	k68	76
.constant	k69	47
.constant	k70	33
.constant	k71	199
.constant	k72	186
.constant	k73	25
.constant	k74	245
.constant	k75	191
.constant	k76	229
.constant	k77	250
.constant	k78	208
.constant	k79	253
.constant	k80	127
.constant	k81	27
.constant	k82	59
.constant	k83	145
.constant	k84	182
.constant	k85	2
.constant	k86	86
.constant	k87	91
.constant	k88	125
.constant	k89	226
.constant	k90	58
.constant	k91	184
.constant	k92	9
.constant	k93	172
.constant	k94	254
.constant	k95	66
.constant	k96	74
.constant	k97	54
.constant	k98	40
.constant	k99	159
.constant	k100	"InstanceDataTreeIsReplicateComplete"
.constant	k101	"AddTimerOnce"
.constant	k102	"print"
.constant	k103	"bWriteLog"
.constant	k104	"table"
.constant	k105	"concat"
.constant	k106	177
.constant	k107	122
.constant	k108	126
.constant	k109	49
.constant	k110	120
.constant	k111	255
.constant	k112	205
.constant	k113	35
.constant	k114	175
.constant	k115	19
.constant	k116	235
.constant	k117	176
.constant	k118	251
.constant	k119	219
.constant	k120	223
.constant	k121	115
.constant	k122	81
.constant	k123	10
.constant	k124	142
.constant	k125	174
.constant	k126	14
.constant	k127	247
.constant	k128	6
.constant	k129	241
.constant	k130	181
.constant	k131	233
.constant	k132	249
.constant	k133	200
.constant	k134	116
.constant	k135	112
.constant	k136	63
.constant	k137	146
.constant	k138	194
.constant	k139	76
.constant	k140	123
.constant	k141	90
.constant	k142	0
.constant	k143	248
.constant	k144	218
.constant	k145	41
.constant	k146	137
.constant	k147	225
.constant	k148	167
.constant	k149	220
.constant	k150	224
.constant	k151	70
.constant	k152	56
.constant	k153	48
.constant	k154	"ReplicateCompleteCallBackID"
.constant	k155	L"AddInstanceDataTreeReplicateCompleteCallBack"
.constant	k156	L"OnInstanceDataTreeReplicateCompleteHandle"
.constant	k157	37
.constant	k158	136
.constant	k159	102
.constant	k160	93
.constant	k161	21
.constant	k162	114
.constant	k163	24
.constant	k164	216
.constant	k165	64
.constant	k166	133
.constant	k167	197
.constant	k168	168
.constant	k169	8
.constant	k170	180
.constant	k171	238
.constant	k172	188
.constant	k173	101
.constant	k174	84
.constant	k175	158
.constant	k176	215
.constant	k177	7
.constant	k178	198
.constant	k179	"AddMsgEvent"
.constant	k180	"E2G"
.constant	k181	"E2G_ReqWorkAssetData"
.constant	k182	"OnReqWorkAssetData"
.constant	k183	"E2G_ReqWorkAssetSave"
.constant	k184	"OnReqWorkAssetSave"
.constant	k185	"E2G_ReqMyPrefabMallMeta"
.constant	k186	"OnReqMyPrefabMallMeta"
.constant	k187	"E2G_ReqImportWorkAsset"
.constant	k188	"OnReqImportWorkAsset"
.constant	k189	"E2G_ReqUnloadWorkAsset"
.constant	k190	"OnReqUnloadWorkAsset"

.line	235	gettabup      r1    u0    k0 ; k0 = "print"
.line	235	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	235	test          r2     0
.line	235	jmp            0   l45
.line	235	getupval      r2    u1
.line	235	loadk         r3    k2 ; k2 = 177
.line	235	loadk         r4    k3 ; k3 = 122
.line	235	loadk         r5    k4 ; k4 = 126
.line	235	loadk         r6    k5 ; k5 = 49
.line	235	loadk         r7    k6 ; k6 = 120
.line	235	loadk         r8    k7 ; k7 = 255
.line	235	loadk         r9    k8 ; k8 = 205
.line	235	loadk        r10    k9 ; k9 = 35
.line	235	loadk        r11   k10 ; k10 = 175
.line	235	loadk        r12   k11 ; k11 = 19
.line	235	loadk        r13   k12 ; k12 = 235
.line	235	loadk        r14   k13 ; k13 = 176
.line	235	loadk        r15   k14 ; k14 = 251
.line	235	loadk        r16   k15 ; k15 = 219
.line	235	loadk        r17   k16 ; k16 = 223
.line	235	loadk        r18    k7 ; k7 = 255
.line	235	loadk        r19   k17 ; k17 = 115
.line	235	loadk        r20   k18 ; k18 = 81
.line	235	loadk        r21   k19 ; k19 = 10
.line	235	loadk        r22    k5 ; k5 = 49
.line	235	loadk        r23   k20 ; k20 = 142
.line	235	loadk        r24   k12 ; k12 = 235
.line	235	loadk        r25   k21 ; k21 = 174
.line	235	loadk        r26   k22 ; k22 = 14
.line	235	loadk        r27   k23 ; k23 = 247
.line	235	loadk        r28   k24 ; k24 = 6
.line	235	loadk        r29   k25 ; k25 = 241
.line	235	loadk        r30   k26 ; k26 = 181
.line	235	loadk        r31   k27 ; k27 = 233
.line	235	loadk        r32   k28 ; k28 = 249
.line	235	loadk        r33   k29 ; k29 = 200
.line	235	loadk        r34   k28 ; k28 = 249
.line	235	loadk        r35   k30 ; k30 = 116
.line	235	loadk        r36   k31 ; k31 = 112
.line	235	loadk        r37   k32 ; k32 = 63
.line	235	loadk        r38    k5 ; k5 = 49
.line	235	loadk        r39   k33 ; k33 = 146
.line	235	loadk        r40   k34 ; k34 = 194
.line	235	call          r2    39     2
.label	l45
.line	235	call          r1     2     1
.line	235	gettabup      r1    u2   k35 ; k35 = "__super"
.line	235	gettable      r1    r1   k36 ; k36 = "RegisterEvent"
.line	235	move          r2    r0
.line	235	call          r1     2     1
.line	235	self          r1    r0   k37 ; k37 = "AddCommonEvent"
.line	235	gettabup      r3    u0   k38 ; k38 = "EVENTTYPE_WOW_EDITOR"
.line	235	gettabup      r4    u0   k39 ; k39 = "EVENTID_WOW_EDITOR_E" (truncated)
.line	235	gettable      r5    r0   k40 ; k40 = "OnHookEnterEditorCom" (truncated)
.line	235	move          r6    r0
.line	235	call          r1     6     1
.line	235	self          r1    r0   k37 ; k37 = "AddCommonEvent"
.line	235	gettabup      r3    u0   k41 ; k41 = "EVENTTYPE_CREATIVE"
.line	235	gettabup      r4    u0   k42 ; k42 = "EVENTID_WORKASSETDAT" (truncated)
.line	235	gettable      r5    r0   k43 ; k43 = "OnWorkAssetDataChang" (truncated)
.line	235	move          r6    r0
.line	235	call          r1     6     1
.line	235	self          r1    r0   k37 ; k37 = "AddCommonEvent"
.line	235	gettabup      r3    u0   k44 ; k44 = "EVENTTYPE_INGAME_CRE" (truncated)
.line	235	gettabup      r4    u0   k45 ; k45 = L"EVENTID_CUSTOM_ASSET" (truncated)
.line	235	gettable      r5    r0   k43 ; k43 = "OnWorkAssetDataChang" (truncated)
.line	235	move          r6    r0
.line	235	call          r1     6     1
.line	235	self          r1    r0   k37 ; k37 = "AddCommonEvent"
.line	235	gettabup      r3    u0   k44 ; k44 = "EVENTTYPE_INGAME_CRE" (truncated)
.line	235	gettabup      r4    u0   k46 ; k46 = "EVENTID_CUSTOM_ASSET" (truncated)
.line	235	gettable      r5    r0   k47 ; k47 = "OnCustomAssetMountSt" (truncated)
.line	235	move          r6    r0
.line	235	call          r1     6     1
.line	235	self          r1    r0   k37 ; k37 = "AddCommonEvent"
.line	235	gettabup      r3    u0   k41 ; k41 = "EVENTTYPE_CREATIVE"
.line	235	gettabup      r4    u0   k48 ; k48 = "EVENTID_UMGINFO_MAP_" (truncated)
.line	235	gettable      r5    r0   k49 ; k49 = "OnUMGInfoMapChanged"
.line	235	move          r6    r0
.line	235	call          r1     6     1
.line	235	gettabup      r1    u0   k50 ; k50 = "require"
.line	235	gettabup      r2    u0   k51 ; k51 = "table"
.line	235	gettable      r2    r2   k52 ; k52 = "concat"
.line	235	newtable      r3     1     0
.line	235	getupval      r4    u1
.line	235	loadk         r5   k53 ; k53 = 161
.line	235	loadk         r6   k30 ; k30 = 116
.line	235	loadk         r7   k54 ; k54 = 68
.line	235	loadk         r8   k55 ; k55 = 17
.line	235	loadk         r9   k56 ; k56 = 80
.line	235	loadk        r10   k57 ; k57 = 227
.line	235	loadk        r11   k58 ; k58 = 216
.line	235	loadk        r12   k59 ; k59 = 98
.line	235	loadk        r13   k60 ; k60 = 144
.line	235	loadk        r14   k61 ; k61 = 43
.line	235	loadk        r15   k62 ; k62 = 224
.line	235	loadk        r16   k63 ; k63 = 236
.line	235	loadk        r17   k64 ; k64 = 211
.line	235	loadk        r18   k65 ; k65 = 232
.line	235	loadk        r19   k66 ; k66 = 201
.line	235	loadk        r20   k67 ; k67 = 237
.line	235	loadk        r21   k59 ; k59 = 98
.line	235	loadk        r22   k68 ; k68 = 76
.line	235	loadk        r23   k69 ; k69 = 47
.line	235	loadk        r24   k70 ; k70 = 33
.line	235	loadk        r25   k21 ; k21 = 174
.line	235	loadk        r26   k71 ; k71 = 199
.line	235	loadk        r27   k72 ; k72 = 186
.line	235	loadk        r28   k73 ; k73 = 25
.line	235	loadk        r29   k57 ; k57 = 227
.line	235	loadk        r30   k11 ; k11 = 19
.line	235	loadk        r31   k74 ; k74 = 245
.line	235	loadk        r32   k75 ; k75 = 191
.line	235	loadk        r33   k76 ; k76 = 229
.line	235	loadk        r34   k77 ; k77 = 250
.line	235	loadk        r35   k78 ; k78 = 208
.line	235	loadk        r36   k79 ; k79 = 253
.line	235	loadk        r37   k80 ; k80 = 127
.line	235	loadk        r38   k81 ; k81 = 27
.line	235	loadk        r39   k19 ; k19 = 10
.line	235	loadk        r40   k82 ; k82 = 59
.line	235	loadk        r41   k83 ; k83 = 145
.line	235	loadk        r42   k15 ; k15 = 219
.line	235	loadk        r43   k84 ; k84 = 182
.line	235	loadk        r44   k85 ; k85 = 2
.line	235	call          r4    41     2
.line	235	getupval      r5    u1
.line	235	loadk         r6   k29 ; k29 = 200
.line	235	loadk         r7   k86 ; k86 = 86
.line	235	loadk         r8   k87 ; k87 = 91
.line	235	loadk         r9   k55 ; k55 = 17
.line	235	loadk        r10   k88 ; k88 = 125
.line	235	loadk        r11   k89 ; k89 = 226
.line	235	loadk        r12   k78 ; k78 = 208
.line	235	loadk        r13   k90 ; k90 = 58
.line	235	loadk        r14   k91 ; k91 = 184
.line	235	loadk        r15   k92 ; k92 = 9
.line	235	loadk        r16   k76 ; k76 = 229
.line	235	loadk        r17   k93 ; k93 = 172
.line	235	loadk        r18   k25 ; k25 = 241
.line	235	loadk        r19   k79 ; k79 = 253
.line	235	loadk        r20   k66 ; k66 = 201
.line	235	loadk        r21   k94 ; k94 = 254
.line	235	loadk        r22   k95 ; k95 = 66
.line	235	loadk        r23   k96 ; k96 = 74
.line	235	loadk        r24   k97 ; k97 = 54
.line	235	loadk        r25   k98 ; k98 = 40
.line	235	loadk        r26   k99 ; k99 = 159
.line	235	call          r5    22     0
.line	235	setlist       r3     0     1
.line	235	call          r2     2     2
.line	235	call          r1     2     2
.line	235	self          r2    r1  k100 ; k100 = "InstanceDataTreeIsRe" (truncated)
.line	235	call          r2     2     2
.line	235	test          r2     0
.line	235	jmp            0  l237
.line	235	self          r2    r0  k101 ; k101 = "AddTimerOnce"
.line	235	loadk         r4   k85 ; k85 = 2
.line	235	closure       r5    f0
.line	235	call          r2     4     1
.line	235	gettabup      r2    u0  k102 ; k102 = "print"
.line	235	gettabup      r3    u0  k103 ; k103 = "bWriteLog"
.line	235	test          r3     0
.line	235	jmp            0  l235
.line	235	gettabup      r3    u0  k104 ; k104 = "table"
.line	235	gettable      r3    r3  k105 ; k105 = "concat"
.line	235	newtable      r4     1     0
.line	235	getupval      r5    u1
.line	235	loadk         r6  k106 ; k106 = 177
.line	235	loadk         r7  k107 ; k107 = 122
.line	235	loadk         r8  k108 ; k108 = 126
.line	235	loadk         r9  k109 ; k109 = 49
.line	235	loadk        r10  k110 ; k110 = 120
.line	235	loadk        r11  k111 ; k111 = 255
.line	235	loadk        r12  k112 ; k112 = 205
.line	235	loadk        r13  k113 ; k113 = 35
.line	235	loadk        r14  k114 ; k114 = 175
.line	235	loadk        r15  k115 ; k115 = 19
.line	235	loadk        r16  k116 ; k116 = 235
.line	235	loadk        r17  k117 ; k117 = 176
.line	235	loadk        r18  k118 ; k118 = 251
.line	235	loadk        r19  k119 ; k119 = 219
.line	235	loadk        r20  k120 ; k120 = 223
.line	235	loadk        r21  k111 ; k111 = 255
.line	235	loadk        r22  k121 ; k121 = 115
.line	235	loadk        r23  k122 ; k122 = 81
.line	235	loadk        r24  k123 ; k123 = 10
.line	235	loadk        r25  k109 ; k109 = 49
.line	235	loadk        r26  k124 ; k124 = 142
.line	235	loadk        r27  k116 ; k116 = 235
.line	235	loadk        r28  k125 ; k125 = 174
.line	235	loadk        r29  k126 ; k126 = 14
.line	235	loadk        r30  k127 ; k127 = 247
.line	235	loadk        r31  k128 ; k128 = 6
.line	235	loadk        r32  k129 ; k129 = 241
.line	235	loadk        r33  k130 ; k130 = 181
.line	235	loadk        r34  k131 ; k131 = 233
.line	235	loadk        r35  k132 ; k132 = 249
.line	235	loadk        r36  k133 ; k133 = 200
.line	235	loadk        r37  k132 ; k132 = 249
.line	235	loadk        r38  k134 ; k134 = 116
.line	235	loadk        r39  k135 ; k135 = 112
.line	235	loadk        r40  k136 ; k136 = 63
.line	235	loadk        r41  k109 ; k109 = 49
.line	235	loadk        r42  k137 ; k137 = 146
.line	235	loadk        r43  k138 ; k138 = 194
.line	235	loadk        r44  k132 ; k132 = 249
.line	235	loadk        r45  k139 ; k139 = 76
.line	235	call          r5    41     2
.line	235	getupval      r6    u1
.line	235	loadk         r7  k114 ; k114 = 175
.line	235	loadk         r8  k140 ; k140 = 123
.line	235	loadk         r9  k141 ; k141 = 90
.line	235	loadk        r10  k142 ; k142 = 0
.line	235	loadk        r11   k88 ; k88 = 125
.line	235	loadk        r12  k143 ; k143 = 248
.line	235	loadk        r13  k144 ; k144 = 218
.line	235	loadk        r14  k145 ; k145 = 41
.line	235	loadk        r15  k146 ; k146 = 137
.line	235	loadk        r16   k97 ; k97 = 54
.line	235	loadk        r17  k147 ; k147 = 225
.line	235	loadk        r18  k148 ; k148 = 167
.line	235	loadk        r19  k138 ; k138 = 194
.line	235	loadk        r20  k111 ; k111 = 255
.line	235	loadk        r21  k149 ; k149 = 220
.line	235	loadk        r22  k150 ; k150 = 224
.line	235	loadk        r23   k80 ; k80 = 127
.line	235	loadk        r24  k151 ; k151 = 70
.line	235	loadk        r25  k152 ; k152 = 56
.line	235	loadk        r26  k153 ; k153 = 48
.line	235	loadk        r27  k146 ; k146 = 137
.line	235	loadk        r28  k138 ; k138 = 194
.line	235	call          r6    23     0
.line	235	setlist       r4     0     1
.line	235	call          r3     2     2
.label	l235
.line	235	call          r2     2     1
.line	235	jmp            0  l339
.label	l237
.line	235	self          r2    r1  k155 ; k155 = L"AddInstanceDataTreeR" (truncated)
.line	235	gettable      r4    r0  k156 ; k156 = L"OnInstanceDataTreeRe" (truncated)
.line	235	move          r5    r0
.line	235	call          r2     4     2
.line	235	settable      r0  k154    r2 ; k154 = "ReplicateCompleteCal" (truncated)
.line	235	gettabup      r2    u0  k102 ; k102 = "print"
.line	235	gettabup      r3    u0  k103 ; k103 = "bWriteLog"
.line	235	test          r3     0
.line	235	jmp            0  l338
.line	235	gettabup      r3    u0  k104 ; k104 = "table"
.line	235	gettable      r3    r3  k105 ; k105 = "concat"
.line	235	newtable      r4     2     0
.line	235	getupval      r5    u1
.line	235	loadk         r6  k106 ; k106 = 177
.line	235	loadk         r7  k107 ; k107 = 122
.line	235	loadk         r8  k108 ; k108 = 126
.line	235	loadk         r9  k109 ; k109 = 49
.line	235	loadk        r10  k110 ; k110 = 120
.line	235	loadk        r11  k111 ; k111 = 255
.line	235	loadk        r12  k112 ; k112 = 205
.line	235	loadk        r13  k113 ; k113 = 35
.line	235	loadk        r14  k114 ; k114 = 175
.line	235	loadk        r15  k115 ; k115 = 19
.line	235	loadk        r16  k116 ; k116 = 235
.line	235	loadk        r17  k117 ; k117 = 176
.line	235	loadk        r18  k118 ; k118 = 251
.line	235	loadk        r19  k119 ; k119 = 219
.line	235	loadk        r20  k120 ; k120 = 223
.line	235	loadk        r21  k111 ; k111 = 255
.line	235	loadk        r22  k121 ; k121 = 115
.line	235	loadk        r23  k122 ; k122 = 81
.line	235	loadk        r24  k123 ; k123 = 10
.line	235	loadk        r25  k109 ; k109 = 49
.line	235	loadk        r26  k124 ; k124 = 142
.line	235	loadk        r27  k116 ; k116 = 235
.line	235	loadk        r28  k125 ; k125 = 174
.line	235	loadk        r29  k126 ; k126 = 14
.line	235	loadk        r30  k127 ; k127 = 247
.line	235	loadk        r31  k128 ; k128 = 6
.line	235	loadk        r32  k129 ; k129 = 241
.line	235	loadk        r33  k130 ; k130 = 181
.line	235	loadk        r34  k131 ; k131 = 233
.line	235	loadk        r35  k132 ; k132 = 249
.line	235	loadk        r36  k133 ; k133 = 200
.line	235	loadk        r37  k132 ; k132 = 249
.line	235	loadk        r38  k134 ; k134 = 116
.line	235	loadk        r39  k135 ; k135 = 112
.line	235	loadk        r40  k136 ; k136 = 63
.line	235	loadk        r41  k109 ; k109 = 49
.line	235	loadk        r42  k137 ; k137 = 146
.line	235	loadk        r43  k138 ; k138 = 194
.line	235	loadk        r44  k132 ; k132 = 249
.line	235	loadk        r45  k157 ; k157 = 37
.line	235	call          r5    41     2
.line	235	getupval      r6    u1
.line	235	loadk         r7  k158 ; k158 = 136
.line	235	loadk         r8  k159 ; k159 = 102
.line	235	loadk         r9  k160 ; k160 = 93
.line	235	loadk        r10  k161 ; k161 = 21
.line	235	loadk        r11  k162 ; k162 = 114
.line	235	loadk        r12   k74 ; k74 = 245
.line	235	loadk        r13  k149 ; k149 = 220
.line	235	loadk        r14  k163 ; k163 = 24
.line	235	loadk        r15  k114 ; k114 = 175
.line	235	loadk        r16   k70 ; k70 = 33
.line	235	loadk        r17  k147 ; k147 = 225
.line	235	loadk        r18   k89 ; k89 = 226
.line	235	loadk        r19   k94 ; k94 = 254
.line	235	loadk        r20   k74 ; k74 = 245
.line	235	loadk        r21  k164 ; k164 = 216
.line	235	loadk        r22   k93 ; k93 = 172
.line	235	loadk        r23   k54 ; k54 = 68
.line	235	loadk        r24  k165 ; k165 = 64
.line	235	loadk        r25  k145 ; k145 = 41
.line	235	loadk        r26   k98 ; k98 = 40
.line	235	loadk        r27  k166 ; k166 = 133
.line	235	loadk        r28  k167 ; k167 = 197
.line	235	loadk        r29  k168 ; k168 = 168
.line	235	loadk        r30  k169 ; k169 = 8
.line	235	loadk        r31  k168 ; k168 = 168
.line	235	loadk        r32  k153 ; k153 = 48
.line	235	loadk        r33  k170 ; k170 = 180
.line	235	loadk        r34   k94 ; k94 = 254
.line	235	loadk        r35  k147 ; k147 = 225
.line	235	loadk        r36  k171 ; k171 = 238
.line	235	loadk        r37  k164 ; k164 = 216
.line	235	loadk        r38  k172 ; k172 = 188
.line	235	loadk        r39  k173 ; k173 = 101
.line	235	loadk        r40  k174 ; k174 = 84
.line	235	loadk        r41  k157 ; k157 = 37
.line	235	loadk        r42  k152 ; k152 = 56
.line	235	loadk        r43  k175 ; k175 = 158
.line	235	loadk        r44  k176 ; k176 = 215
.line	235	loadk        r45   k72 ; k72 = 186
.line	235	loadk        r46  k177 ; k177 = 7
.line	235	call          r6    41     2
.line	235	getupval      r7    u1
.line	235	loadk         r8  k178 ; k178 = 198
.line	235	call          r7     2     0
.line	235	setlist       r4     0     1
.line	235	call          r3     2     2
.label	l338
.line	235	call          r2     2     1
.label	l339
.line	235	self          r2    r0  k179 ; k179 = "AddMsgEvent"
.line	235	gettabup      r4    u3  k180 ; k180 = "E2G"
.line	235	gettable      r4    r4  k181 ; k181 = "E2G_ReqWorkAssetData"
.line	235	gettable      r5    r0  k182 ; k182 = "OnReqWorkAssetData"
.line	235	move          r6    r0
.line	235	call          r2     5     1
.line	235	self          r2    r0  k179 ; k179 = "AddMsgEvent"
.line	235	gettabup      r4    u3  k180 ; k180 = "E2G"
.line	235	gettable      r4    r4  k183 ; k183 = "E2G_ReqWorkAssetSave"
.line	235	gettable      r5    r0  k184 ; k184 = "OnReqWorkAssetSave"
.line	235	move          r6    r0
.line	235	call          r2     5     1
.line	235	self          r2    r0  k179 ; k179 = "AddMsgEvent"
.line	235	gettabup      r4    u3  k180 ; k180 = "E2G"
.line	235	gettable      r4    r4  k185 ; k185 = "E2G_ReqMyPrefabMallM" (truncated)
.line	235	gettable      r5    r0  k186 ; k186 = "OnReqMyPrefabMallMet" (truncated)
.line	235	move          r6    r0
.line	235	call          r2     5     1
.line	235	self          r2    r0  k179 ; k179 = "AddMsgEvent"
.line	235	gettabup      r4    u3  k180 ; k180 = "E2G"
.line	235	gettable      r4    r4  k187 ; k187 = "E2G_ReqImportWorkAss" (truncated)
.line	235	gettable      r5    r0  k188 ; k188 = "OnReqImportWorkAsset"
.line	235	move          r6    r0
.line	235	call          r2     5     1
.line	235	self          r2    r0  k179 ; k179 = "AddMsgEvent"
.line	235	gettabup      r4    u3  k180 ; k180 = "E2G"
.line	235	gettable      r4    r4  k189 ; k189 = "E2G_ReqUnloadWorkAss" (truncated)
.line	235	gettable      r5    r0  k190 ; k190 = "OnReqUnloadWorkAsset"
.line	235	move          r6    r0
.line	235	call          r2     5     1
.line	235	return        r0     1
.line	235	move          r0    r0
.line	235	move          r0    r0
.line	235	return        r0     1

.function	main/f2/f0

.source	null
.linedefined	245
.lastlinedefined	251
.numparams	0
.is_vararg	0
.maxstacksize	44

.upvalue	"_ENV"	0	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	false

.constant	k0	"ActorDataCompleted"
.constant	k1	true
.constant	k2	"LoadWorkAssetData"
.constant	k3	"EnsureDefaultFolders"
.constant	k4	"OnWorkAssetDataChanged"
.constant	k5	"print"
.constant	k6	"bWriteLog"
.constant	k7	"table"
.constant	k8	"concat"
.constant	k9	177
.constant	k10	122
.constant	k11	126
.constant	k12	49
.constant	k13	120
.constant	k14	255
.constant	k15	205
.constant	k16	35
.constant	k17	175
.constant	k18	19
.constant	k19	235
.constant	k20	176
.constant	k21	251
.constant	k22	219
.constant	k23	223
.constant	k24	115
.constant	k25	81
.constant	k26	10
.constant	k27	142
.constant	k28	174
.constant	k29	14
.constant	k30	247
.constant	k31	6
.constant	k32	241
.constant	k33	181
.constant	k34	233
.constant	k35	249
.constant	k36	200
.constant	k37	116
.constant	k38	112
.constant	k39	63
.constant	k40	146
.constant	k41	194
.constant	k42	76
.constant	k43	167
.constant	k44	118
.constant	k45	93
.constant	k46	27
.constant	k47	110
.constant	k48	210
.constant	k49	216
.constant	k50	56
.constant	k51	188
.constant	k52	7
.constant	k53	224
.constant	k54	246
.constant	k55	201
.constant	k56	248
.constant	k57	65
.constant	k58	121
.constant	k59	204
.constant	k60	187
.constant	k61	9
.constant	k62	168

.line	245	settabup      u0    k0    k1 ; k1 = true
.line	245	getupval      r0    u0
.line	245	self          r0    r0    k2 ; k2 = "LoadWorkAssetData"
.line	245	call          r0     2     1
.line	245	getupval      r0    u0
.line	245	self          r0    r0    k3 ; k3 = "EnsureDefaultFolders"
.line	245	call          r0     2     1
.line	245	getupval      r0    u0
.line	245	self          r0    r0    k4 ; k4 = "OnWorkAssetDataChang" (truncated)
.line	245	loadnil       r2     4
.line	245	loadbool      r7     1     0
.line	245	call          r0     8     1
.line	245	gettabup      r0    u1    k5 ; k5 = "print"
.line	245	gettabup      r1    u1    k6 ; k6 = "bWriteLog"
.line	245	test          r1     0
.line	245	jmp            0   l91
.line	245	gettabup      r1    u1    k7 ; k7 = "table"
.line	245	gettable      r1    r1    k8 ; k8 = "concat"
.line	245	newtable      r2     1     0
.line	245	getupval      r3    u2
.line	245	loadk         r4    k9 ; k9 = 177
.line	245	loadk         r5   k10 ; k10 = 122
.line	245	loadk         r6   k11 ; k11 = 126
.line	245	loadk         r7   k12 ; k12 = 49
.line	245	loadk         r8   k13 ; k13 = 120
.line	245	loadk         r9   k14 ; k14 = 255
.line	245	loadk        r10   k15 ; k15 = 205
.line	245	loadk        r11   k16 ; k16 = 35
.line	245	loadk        r12   k17 ; k17 = 175
.line	245	loadk        r13   k18 ; k18 = 19
.line	245	loadk        r14   k19 ; k19 = 235
.line	245	loadk        r15   k20 ; k20 = 176
.line	245	loadk        r16   k21 ; k21 = 251
.line	245	loadk        r17   k22 ; k22 = 219
.line	245	loadk        r18   k23 ; k23 = 223
.line	245	loadk        r19   k14 ; k14 = 255
.line	245	loadk        r20   k24 ; k24 = 115
.line	245	loadk        r21   k25 ; k25 = 81
.line	245	loadk        r22   k26 ; k26 = 10
.line	245	loadk        r23   k12 ; k12 = 49
.line	245	loadk        r24   k27 ; k27 = 142
.line	245	loadk        r25   k19 ; k19 = 235
.line	245	loadk        r26   k28 ; k28 = 174
.line	245	loadk        r27   k29 ; k29 = 14
.line	245	loadk        r28   k30 ; k30 = 247
.line	245	loadk        r29   k31 ; k31 = 6
.line	245	loadk        r30   k32 ; k32 = 241
.line	245	loadk        r31   k33 ; k33 = 181
.line	245	loadk        r32   k34 ; k34 = 233
.line	245	loadk        r33   k35 ; k35 = 249
.line	245	loadk        r34   k36 ; k36 = 200
.line	245	loadk        r35   k35 ; k35 = 249
.line	245	loadk        r36   k37 ; k37 = 116
.line	245	loadk        r37   k38 ; k38 = 112
.line	245	loadk        r38   k39 ; k39 = 63
.line	245	loadk        r39   k12 ; k12 = 49
.line	245	loadk        r40   k40 ; k40 = 146
.line	245	loadk        r41   k41 ; k41 = 194
.line	245	loadk        r42   k35 ; k35 = 249
.line	245	loadk        r43   k42 ; k42 = 76
.line	245	call          r3    41     2
.line	245	getupval      r4    u2
.line	245	loadk         r5   k43 ; k43 = 167
.line	245	loadk         r6   k44 ; k44 = 118
.line	245	loadk         r7   k45 ; k45 = 93
.line	245	loadk         r8   k46 ; k46 = 27
.line	245	loadk         r9   k47 ; k47 = 110
.line	245	loadk        r10   k48 ; k48 = 210
.line	245	loadk        r11   k49 ; k49 = 216
.line	245	loadk        r12   k50 ; k50 = 56
.line	245	loadk        r13   k51 ; k51 = 188
.line	245	loadk        r14   k52 ; k52 = 7
.line	245	loadk        r15   k19 ; k19 = 235
.line	245	loadk        r16   k17 ; k17 = 175
.line	245	loadk        r17   k53 ; k53 = 224
.line	245	loadk        r18   k54 ; k54 = 246
.line	245	loadk        r19   k55 ; k55 = 201
.line	245	loadk        r20   k56 ; k56 = 248
.line	245	loadk        r21   k24 ; k24 = 115
.line	245	loadk        r22   k57 ; k57 = 65
.line	245	loadk        r23   k58 ; k58 = 121
.line	245	loadk        r24   k58 ; k58 = 121
.line	245	loadk        r25   k59 ; k59 = 204
.line	245	loadk        r26   k48 ; k48 = 210
.line	245	loadk        r27   k60 ; k60 = 187
.line	245	loadk        r28   k61 ; k61 = 9
.line	245	loadk        r29   k62 ; k62 = 168
.line	245	call          r4    26     0
.line	245	setlist       r2     0     1
.line	245	call          r1     2     2
.label	l91
.line	245	call          r0     2     1
.line	245	return        r0     1
.line	245	move          r0    r0
.line	245	move          r0    r0
.line	245	move          r0    r0
.line	245	move          r0    r0
.line	245	return        r0     1

.function	main/f3

.source	null
.linedefined	264
.lastlinedefined	272
.numparams	1
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"AddTimerOnce"
.constant	k1	2

.line	264	self          r1    r0    k0 ; k0 = "AddTimerOnce"
.line	264	loadk         r3    k1 ; k1 = 2
.line	264	closure       r4    f0
.line	264	call          r1     4     1
.line	264	return        r0     1
.line	264	move          r0    r0
.line	264	return        r0     1

.function	main/f3/f0

.source	null
.linedefined	265
.lastlinedefined	271
.numparams	0
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	0	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	177
.constant	k5	122
.constant	k6	126
.constant	k7	49
.constant	k8	120
.constant	k9	255
.constant	k10	205
.constant	k11	35
.constant	k12	175
.constant	k13	19
.constant	k14	235
.constant	k15	176
.constant	k16	251
.constant	k17	219
.constant	k18	223
.constant	k19	115
.constant	k20	81
.constant	k21	10
.constant	k22	142
.constant	k23	174
.constant	k24	14
.constant	k25	247
.constant	k26	27
.constant	k27	250
.constant	k28	155
.constant	k29	238
.constant	k30	249
.constant	k31	200
.constant	k32	253
.constant	k33	104
.constant	k34	86
.constant	k35	44
.constant	k36	16
.constant	k37	157
.constant	k38	194
.constant	k39	184
.constant	k40	56
.constant	k41	148
.constant	k42	112
.constant	k43	76
.constant	k44	38
.constant	k45	121
.constant	k46	230
.constant	k47	213
.constant	k48	37
.constant	k49	190
.constant	k50	240
.constant	k51	167
.constant	k52	211
.constant	k53	245
.constant	k54	193
.constant	k55	252
.constant	k56	64
.constant	k57	45
.constant	k58	33
.constant	k59	164
.constant	k60	199
.constant	k61	24
.constant	k62	161
.constant	k63	180
.constant	k64	242
.constant	k65	233
.constant	k66	243
.constant	k67	116
.constant	k68	113
.constant	k69	40
.constant	k70	32
.constant	k71	182
.constant	k72	1
.constant	k73	150
.constant	k74	0
.constant	k75	153
.constant	k76	48
.constant	k77	246
.constant	k78	183
.constant	k79	"ActorDataCompleted"
.constant	k80	true
.constant	k81	"LoadWorkAssetData"
.constant	k82	"EnsureDefaultFolders"
.constant	k83	"OnWorkAssetDataChanged"

.line	265	gettabup      r0    u0    k0 ; k0 = "print"
.line	265	gettabup      r1    u0    k1 ; k1 = "bWriteLog"
.line	265	test          r1     0
.line	265	jmp            0  l109
.line	265	gettabup      r1    u0    k2 ; k2 = "table"
.line	265	gettable      r1    r1    k3 ; k3 = "concat"
.line	265	newtable      r2     2     0
.line	265	getupval      r3    u1
.line	265	loadk         r4    k4 ; k4 = 177
.line	265	loadk         r5    k5 ; k5 = 122
.line	265	loadk         r6    k6 ; k6 = 126
.line	265	loadk         r7    k7 ; k7 = 49
.line	265	loadk         r8    k8 ; k8 = 120
.line	265	loadk         r9    k9 ; k9 = 255
.line	265	loadk        r10   k10 ; k10 = 205
.line	265	loadk        r11   k11 ; k11 = 35
.line	265	loadk        r12   k12 ; k12 = 175
.line	265	loadk        r13   k13 ; k13 = 19
.line	265	loadk        r14   k14 ; k14 = 235
.line	265	loadk        r15   k15 ; k15 = 176
.line	265	loadk        r16   k16 ; k16 = 251
.line	265	loadk        r17   k17 ; k17 = 219
.line	265	loadk        r18   k18 ; k18 = 223
.line	265	loadk        r19    k9 ; k9 = 255
.line	265	loadk        r20   k19 ; k19 = 115
.line	265	loadk        r21   k20 ; k20 = 81
.line	265	loadk        r22   k21 ; k21 = 10
.line	265	loadk        r23    k7 ; k7 = 49
.line	265	loadk        r24   k22 ; k22 = 142
.line	265	loadk        r25   k14 ; k14 = 235
.line	265	loadk        r26   k23 ; k23 = 174
.line	265	loadk        r27   k24 ; k24 = 14
.line	265	loadk        r28   k25 ; k25 = 247
.line	265	loadk        r29   k26 ; k26 = 27
.line	265	loadk        r30   k27 ; k27 = 250
.line	265	loadk        r31   k28 ; k28 = 155
.line	265	loadk        r32   k29 ; k29 = 238
.line	265	loadk        r33   k30 ; k30 = 249
.line	265	loadk        r34   k31 ; k31 = 200
.line	265	loadk        r35   k32 ; k32 = 253
.line	265	loadk        r36   k33 ; k33 = 104
.line	265	loadk        r37   k34 ; k34 = 86
.line	265	loadk        r38   k35 ; k35 = 44
.line	265	loadk        r39   k36 ; k36 = 16
.line	265	loadk        r40   k37 ; k37 = 157
.line	265	loadk        r41   k38 ; k38 = 194
.line	265	loadk        r42   k39 ; k39 = 184
.line	265	loadk        r43   k40 ; k40 = 56
.line	265	call          r3    41     2
.line	265	getupval      r4    u1
.line	265	loadk         r5   k41 ; k41 = 148
.line	265	loadk         r6   k42 ; k42 = 112
.line	265	loadk         r7   k43 ; k43 = 76
.line	265	loadk         r8   k44 ; k44 = 38
.line	265	loadk         r9   k45 ; k45 = 121
.line	265	loadk        r10   k46 ; k46 = 230
.line	265	loadk        r11   k47 ; k47 = 213
.line	265	loadk        r12   k48 ; k48 = 37
.line	265	loadk        r13   k49 ; k49 = 190
.line	265	loadk        r14   k48 ; k48 = 37
.line	265	loadk        r15   k50 ; k50 = 240
.line	265	loadk        r16   k51 ; k51 = 167
.line	265	loadk        r17   k52 ; k52 = 211
.line	265	loadk        r18   k53 ; k53 = 245
.line	265	loadk        r19   k54 ; k54 = 193
.line	265	loadk        r20   k55 ; k55 = 252
.line	265	loadk        r21    k5 ; k5 = 122
.line	265	loadk        r22   k56 ; k56 = 64
.line	265	loadk        r23   k57 ; k57 = 45
.line	265	loadk        r24   k58 ; k58 = 33
.line	265	loadk        r25   k59 ; k59 = 164
.line	265	loadk        r26   k60 ; k60 = 199
.line	265	loadk        r27   k51 ; k51 = 167
.line	265	loadk        r28   k61 ; k61 = 24
.line	265	loadk        r29   k62 ; k62 = 161
.line	265	loadk        r30    k7 ; k7 = 49
.line	265	loadk        r31   k63 ; k63 = 180
.line	265	loadk        r32   k64 ; k64 = 242
.line	265	loadk        r33   k54 ; k54 = 193
.line	265	loadk        r34   k65 ; k65 = 233
.line	265	loadk        r35   k31 ; k31 = 200
.line	265	loadk        r36   k66 ; k66 = 243
.line	265	loadk        r37   k67 ; k67 = 116
.line	265	loadk        r38   k68 ; k68 = 113
.line	265	loadk        r39   k69 ; k69 = 40
.line	265	loadk        r40   k70 ; k70 = 32
.line	265	loadk        r41   k37 ; k37 = 157
.line	265	loadk        r42   k53 ; k53 = 245
.line	265	loadk        r43   k71 ; k71 = 182
.line	265	loadk        r44   k72 ; k72 = 1
.line	265	call          r4    41     2
.line	265	getupval      r5    u1
.line	265	loadk         r6   k73 ; k73 = 150
.line	265	loadk         r7   k45 ; k45 = 121
.line	265	loadk         r8   k43 ; k43 = 76
.line	265	loadk         r9   k74 ; k74 = 0
.line	265	loadk        r10   k45 ; k45 = 121
.line	265	loadk        r11   k64 ; k64 = 242
.line	265	loadk        r12   k75 ; k75 = 153
.line	265	loadk        r13   k68 ; k68 = 113
.line	265	loadk        r14   k32 ; k32 = 253
.line	265	loadk        r15   k76 ; k76 = 48
.line	265	loadk        r16   k77 ; k77 = 246
.line	265	loadk        r17   k78 ; k78 = 183
.line	265	loadk        r18   k53 ; k53 = 245
.line	265	call          r5    14     0
.line	265	setlist       r2     0     1
.line	265	call          r1     2     2
.label	l109
.line	265	call          r0     2     1
.line	265	settabup      u2   k79   k80 ; k80 = true
.line	265	getupval      r0    u2
.line	265	self          r0    r0   k81 ; k81 = "LoadWorkAssetData"
.line	265	call          r0     2     1
.line	265	getupval      r0    u2
.line	265	self          r0    r0   k82 ; k82 = "EnsureDefaultFolders"
.line	265	call          r0     2     1
.line	265	getupval      r0    u2
.line	265	self          r0    r0   k83 ; k83 = "OnWorkAssetDataChang" (truncated)
.line	265	loadnil       r2     4
.line	265	loadbool      r7     1     0
.line	265	call          r0     8     1
.line	265	return        r0     1
.line	265	move          r0    r0
.line	265	move          r0    r0
.line	265	move          r0    r0
.line	265	return        r0     1

.function	main/f4

.source	null
.linedefined	274
.lastlinedefined	288
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	177
.constant	k5	122
.constant	k6	126
.constant	k7	49
.constant	k8	120
.constant	k9	255
.constant	k10	205
.constant	k11	35
.constant	k12	175
.constant	k13	19
.constant	k14	235
.constant	k15	176
.constant	k16	251
.constant	k17	219
.constant	k18	223
.constant	k19	115
.constant	k20	81
.constant	k21	10
.constant	k22	142
.constant	k23	174
.constant	k24	14
.constant	k25	247
.constant	k26	27
.constant	k27	250
.constant	k28	154
.constant	k29	239
.constant	k30	229
.constant	k31	215
.constant	k32	217
.constant	k33	104
.constant	k34	65
.constant	k35	44
.constant	k36	38
.constant	k37	185
.constant	k38	210
.constant	k39	24
.constant	k40	137
.constant	k41	103
.constant	k42	106
.constant	k43	113
.constant	k44	230
.constant	k45	213
.constant	k46	41
.constant	k47	169
.constant	k48	33
.constant	k49	"LoadWorkAssetData"
.constant	k50	"EnsureDefaultFolders"
.constant	k51	"tonumber"
.constant	k52	"DataMgr"
.constant	k53	"roleData"
.constant	k54	"uid"
.constant	k55	0
.constant	k56	"ModuleManager"
.constant	k57	"GetModule"
.constant	k58	"LobbyModuleConfig"
.constant	k59	"LogicUGCAuthor"
.constant	k60	"RequestAuthorInfo"
.constant	k61	"require"
.constant	k62	133
.constant	k63	121
.constant	k64	64
.constant	k65	17
.constant	k66	114
.constant	k67	226
.constant	k68	151
.constant	k69	34
.constant	k70	184
.constant	k71	48
.constant	k72	243
.constant	k73	173
.constant	k74	241
.constant	k75	130
.constant	k76	220
.constant	k77	100
.constant	k78	74
.constant	k79	45
.constant	k80	43
.constant	k81	143
.constant	k82	201
.constant	k83	165
.constant	k84	82
.constant	k85	152
.constant	k86	245
.constant	k87	232
.constant	k88	208
.constant	k89	117
.constant	k90	93
.constant	k91	1
.constant	k92	53
.constant	k93	146
.constant	k94	181
.constant	k95	9
.constant	k96	148
.constant	k97	L"send_wow_get_user_prefab_summary_data_req"
.constant	k98	"CommonModuleConfig"
.constant	k99	"logic_ugc_prefab_mall"
.constant	k100	"ReqMyShareAndFavoriteMeta"

.line	274	gettabup      r1    u0    k0 ; k0 = "print"
.line	274	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	274	test          r2     0
.line	274	jmp            0   l64
.line	274	gettabup      r2    u0    k2 ; k2 = "table"
.line	274	gettable      r2    r2    k3 ; k3 = "concat"
.line	274	newtable      r3     1     0
.line	274	getupval      r4    u1
.line	274	loadk         r5    k4 ; k4 = 177
.line	274	loadk         r6    k5 ; k5 = 122
.line	274	loadk         r7    k6 ; k6 = 126
.line	274	loadk         r8    k7 ; k7 = 49
.line	274	loadk         r9    k8 ; k8 = 120
.line	274	loadk        r10    k9 ; k9 = 255
.line	274	loadk        r11   k10 ; k10 = 205
.line	274	loadk        r12   k11 ; k11 = 35
.line	274	loadk        r13   k12 ; k12 = 175
.line	274	loadk        r14   k13 ; k13 = 19
.line	274	loadk        r15   k14 ; k14 = 235
.line	274	loadk        r16   k15 ; k15 = 176
.line	274	loadk        r17   k16 ; k16 = 251
.line	274	loadk        r18   k17 ; k17 = 219
.line	274	loadk        r19   k18 ; k18 = 223
.line	274	loadk        r20    k9 ; k9 = 255
.line	274	loadk        r21   k19 ; k19 = 115
.line	274	loadk        r22   k20 ; k20 = 81
.line	274	loadk        r23   k21 ; k21 = 10
.line	274	loadk        r24    k7 ; k7 = 49
.line	274	loadk        r25   k22 ; k22 = 142
.line	274	loadk        r26   k14 ; k14 = 235
.line	274	loadk        r27   k23 ; k23 = 174
.line	274	loadk        r28   k24 ; k24 = 14
.line	274	loadk        r29   k25 ; k25 = 247
.line	274	loadk        r30   k26 ; k26 = 27
.line	274	loadk        r31   k27 ; k27 = 250
.line	274	loadk        r32   k28 ; k28 = 154
.line	274	loadk        r33   k29 ; k29 = 239
.line	274	loadk        r34   k30 ; k30 = 229
.line	274	loadk        r35   k31 ; k31 = 215
.line	274	loadk        r36   k32 ; k32 = 217
.line	274	loadk        r37   k33 ; k33 = 104
.line	274	loadk        r38   k34 ; k34 = 65
.line	274	loadk        r39   k35 ; k35 = 44
.line	274	loadk        r40   k36 ; k36 = 38
.line	274	loadk        r41   k37 ; k37 = 185
.line	274	loadk        r42   k38 ; k38 = 210
.line	274	loadk        r43   k15 ; k15 = 176
.line	274	loadk        r44   k39 ; k39 = 24
.line	274	call          r4    41     2
.line	274	getupval      r5    u1
.line	274	loadk         r6   k40 ; k40 = 137
.line	274	loadk         r7   k41 ; k41 = 103
.line	274	loadk         r8   k42 ; k42 = 106
.line	274	loadk         r9   k26 ; k26 = 27
.line	274	loadk        r10   k43 ; k43 = 113
.line	274	loadk        r11   k44 ; k44 = 230
.line	274	loadk        r12   k45 ; k45 = 213
.line	274	loadk        r13   k46 ; k46 = 41
.line	274	loadk        r14   k47 ; k47 = 169
.line	274	loadk        r15   k48 ; k48 = 33
.line	274	call          r5    11     0
.line	274	setlist       r3     0     1
.line	274	call          r2     2     2
.label	l64
.line	274	call          r1     2     1
.line	274	self          r1    r0   k49 ; k49 = "LoadWorkAssetData"
.line	274	call          r1     2     1
.line	274	self          r1    r0   k50 ; k50 = "EnsureDefaultFolders"
.line	274	call          r1     2     1
.line	274	gettabup      r1    u0   k51 ; k51 = "tonumber"
.line	274	gettabup      r2    u0   k52 ; k52 = "DataMgr"
.line	274	gettable      r2    r2   k53 ; k53 = "roleData"
.line	274	gettable      r2    r2   k54 ; k54 = "uid"
.line	274	call          r1     2     2
.line	274	test          r1     1
.line	274	jmp            0   l77
.line	274	loadk         r1   k55 ; k55 = 0
.label	l77
.line	274	eq             0    r1   k55 ; k55 = 0
.line	274	jmp            0   l80
.line	274	return        r0     1
.label	l80
.line	274	gettabup      r2    u0   k56 ; k56 = "ModuleManager"
.line	274	gettable      r2    r2   k57 ; k57 = "GetModule"
.line	274	gettabup      r3    u0   k56 ; k56 = "ModuleManager"
.line	274	gettable      r3    r3   k58 ; k58 = "LobbyModuleConfig"
.line	274	gettable      r3    r3   k59 ; k59 = "LogicUGCAuthor"
.line	274	call          r2     2     2
.line	274	self          r3    r2   k60 ; k60 = "RequestAuthorInfo"
.line	274	move          r5    r1
.line	274	call          r3     3     1
.line	274	gettabup      r3    u0   k61 ; k61 = "require"
.line	274	gettabup      r4    u0    k2 ; k2 = "table"
.line	274	gettable      r4    r4    k3 ; k3 = "concat"
.line	274	newtable      r5     1     0
.line	274	getupval      r6    u1
.line	274	loadk         r7   k62 ; k62 = 133
.line	274	loadk         r8   k63 ; k63 = 121
.line	274	loadk         r9   k64 ; k64 = 64
.line	274	loadk        r10   k65 ; k65 = 17
.line	274	loadk        r11   k66 ; k66 = 114
.line	274	loadk        r12   k67 ; k67 = 226
.line	274	loadk        r13   k68 ; k68 = 151
.line	274	loadk        r14   k69 ; k69 = 34
.line	274	loadk        r15   k70 ; k70 = 184
.line	274	loadk        r16   k71 ; k71 = 48
.line	274	loadk        r17   k72 ; k72 = 243
.line	274	loadk        r18   k73 ; k73 = 173
.line	274	loadk        r19   k67 ; k67 = 226
.line	274	loadk        r20   k74 ; k74 = 241
.line	274	loadk        r21   k75 ; k75 = 130
.line	274	loadk        r22   k76 ; k76 = 220
.line	274	loadk        r23   k77 ; k77 = 100
.line	274	loadk        r24   k78 ; k78 = 74
.line	274	loadk        r25   k79 ; k79 = 45
.line	274	loadk        r26   k80 ; k80 = 43
.line	274	loadk        r27   k81 ; k81 = 143
.line	274	loadk        r28   k82 ; k82 = 201
.line	274	loadk        r29   k83 ; k83 = 165
.line	274	loadk        r30   k84 ; k84 = 82
.line	274	loadk        r31   k85 ; k85 = 152
.line	274	loadk        r32   k13 ; k13 = 19
.line	274	loadk        r33   k31 ; k31 = 215
.line	274	loadk        r34   k75 ; k75 = 130
.line	274	loadk        r35   k86 ; k86 = 245
.line	274	loadk        r36   k87 ; k87 = 232
.line	274	loadk        r37   k88 ; k88 = 208
.line	274	loadk        r38   k86 ; k86 = 245
.line	274	loadk        r39   k89 ; k89 = 117
.line	274	loadk        r40   k90 ; k90 = 93
.line	274	loadk        r41   k91 ; k91 = 1
.line	274	loadk        r42   k92 ; k92 = 53
.line	274	loadk        r43   k93 ; k93 = 146
.line	274	loadk        r44   k38 ; k38 = 210
.line	274	loadk        r45   k94 ; k94 = 181
.line	274	loadk        r46   k95 ; k95 = 9
.line	274	call          r6    41     2
.line	274	getupval      r7    u1
.line	274	loadk         r8   k96 ; k96 = 148
.line	274	call          r7     2     0
.line	274	setlist       r5     0     1
.line	274	call          r4     2     2
.line	274	call          r3     2     2
.line	274	gettable      r4    r3   k97 ; k97 = L"send_wow_get_user_pr" (truncated)
.line	274	move          r5    r1
.line	274	call          r4     2     1
.line	274	gettabup      r4    u0   k56 ; k56 = "ModuleManager"
.line	274	gettable      r4    r4   k57 ; k57 = "GetModule"
.line	274	gettabup      r5    u0   k56 ; k56 = "ModuleManager"
.line	274	gettable      r5    r5   k98 ; k98 = "CommonModuleConfig"
.line	274	gettable      r5    r5   k99 ; k99 = "logic_ugc_prefab_mal" (truncated)
.line	274	call          r4     2     2
.line	274	self          r5    r4  k100 ; k100 = "ReqMyShareAndFavorit" (truncated)
.line	274	call          r5     2     1
.line	274	return        r0     1
.line	274	move          r0    r0
.line	274	move          r0    r0
.line	274	move          r0    r0
.line	274	return        r0     1

.function	main/f5

.source	null
.linedefined	290
.lastlinedefined	310
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	177
.constant	k5	122
.constant	k6	126
.constant	k7	49
.constant	k8	120
.constant	k9	255
.constant	k10	205
.constant	k11	35
.constant	k12	175
.constant	k13	19
.constant	k14	235
.constant	k15	176
.constant	k16	251
.constant	k17	219
.constant	k18	223
.constant	k19	115
.constant	k20	81
.constant	k21	10
.constant	k22	142
.constant	k23	174
.constant	k24	14
.constant	k25	247
.constant	k26	24
.constant	k27	179
.constant	k28	228
.constant	k29	221
.constant	k30	211
.constant	k31	238
.constant	k32	109
.constant	k33	116
.constant	k34	58
.constant	k35	39
.constant	k36	153
.constant	k37	194
.constant	k38	157
.constant	k39	13
.constant	k40	146
.constant	k41	"GetGameParameterManager"
.constant	k42	9
.constant	k43	89
.constant	k44	60
.constant	k45	198
.constant	k46	216
.constant	k47	62
.constant	k48	188
.constant	k49	41
.constant	k50	225
.constant	k51	182
.constant	k52	245
.constant	k53	232
.constant	k54	237
.constant	k55	68
.constant	k56	33
.constant	k57	158
.constant	k58	134
.constant	k59	160
.constant	k60	18
.constant	k61	187
.constant	k62	53
.constant	k63	248
.constant	k64	"GetGameParameter"
.constant	k65	91
.constant	k66	31
.constant	k67	93
.constant	k68	229
.constant	k69	202
.constant	k70	169
.constant	k71	2
.constant	k72	244
.constant	k73	222
.constant	k74	100
.constant	k75	64
.constant	k76	"Value"
.constant	k77	"type"
.constant	k78	75
.constant	k79	121
.constant	k80	"FolderTree"
.constant	k81	"DeepCopy"
.constant	k82	20
.constant	k83	215
.constant	k84	252
.constant	k85	"AssetPathMap"
.constant	k86	"ClampWorkAssetStringFields"

.line	290	gettabup      r1    u0    k0 ; k0 = "print"
.line	290	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	290	test          r2     0
.line	290	jmp            0   l56
.line	290	gettabup      r2    u0    k2 ; k2 = "table"
.line	290	gettable      r2    r2    k3 ; k3 = "concat"
.line	290	newtable      r3     1     0
.line	290	getupval      r4    u1
.line	290	loadk         r5    k4 ; k4 = 177
.line	290	loadk         r6    k5 ; k5 = 122
.line	290	loadk         r7    k6 ; k6 = 126
.line	290	loadk         r8    k7 ; k7 = 49
.line	290	loadk         r9    k8 ; k8 = 120
.line	290	loadk        r10    k9 ; k9 = 255
.line	290	loadk        r11   k10 ; k10 = 205
.line	290	loadk        r12   k11 ; k11 = 35
.line	290	loadk        r13   k12 ; k12 = 175
.line	290	loadk        r14   k13 ; k13 = 19
.line	290	loadk        r15   k14 ; k14 = 235
.line	290	loadk        r16   k15 ; k15 = 176
.line	290	loadk        r17   k16 ; k16 = 251
.line	290	loadk        r18   k17 ; k17 = 219
.line	290	loadk        r19   k18 ; k18 = 223
.line	290	loadk        r20    k9 ; k9 = 255
.line	290	loadk        r21   k19 ; k19 = 115
.line	290	loadk        r22   k20 ; k20 = 81
.line	290	loadk        r23   k21 ; k21 = 10
.line	290	loadk        r24    k7 ; k7 = 49
.line	290	loadk        r25   k22 ; k22 = 142
.line	290	loadk        r26   k14 ; k14 = 235
.line	290	loadk        r27   k23 ; k23 = 174
.line	290	loadk        r28   k24 ; k24 = 14
.line	290	loadk        r29   k25 ; k25 = 247
.line	290	loadk        r30   k26 ; k26 = 24
.line	290	loadk        r31   k16 ; k16 = 251
.line	290	loadk        r32   k27 ; k27 = 179
.line	290	loadk        r33   k28 ; k28 = 228
.line	290	loadk        r34   k29 ; k29 = 221
.line	290	loadk        r35   k30 ; k30 = 211
.line	290	loadk        r36   k31 ; k31 = 238
.line	290	loadk        r37   k32 ; k32 = 109
.line	290	loadk        r38   k33 ; k33 = 116
.line	290	loadk        r39   k34 ; k34 = 58
.line	290	loadk        r40   k35 ; k35 = 39
.line	290	loadk        r41   k36 ; k36 = 153
.line	290	loadk        r42   k37 ; k37 = 194
.line	290	loadk        r43   k38 ; k38 = 157
.line	290	loadk        r44   k39 ; k39 = 13
.line	290	call          r4    41     2
.line	290	getupval      r5    u1
.line	290	loadk         r6   k40 ; k40 = 146
.line	290	loadk         r7   k33 ; k33 = 116
.line	290	call          r5     3     0
.line	290	setlist       r3     0     1
.line	290	call          r2     2     2
.label	l56
.line	290	call          r1     2     1
.line	290	gettabup      r1    u0   k41 ; k41 = "GetGameParameterMana" (truncated)
.line	290	call          r1     1     2
.line	290	test          r1     1
.line	290	jmp            0  l145
.line	290	gettabup      r2    u0    k0 ; k0 = "print"
.line	290	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	290	test          r3     0
.line	290	jmp            0  l143
.line	290	gettabup      r3    u0    k2 ; k2 = "table"
.line	290	gettable      r3    r3    k3 ; k3 = "concat"
.line	290	newtable      r4     1     0
.line	290	getupval      r5    u1
.line	290	loadk         r6    k4 ; k4 = 177
.line	290	loadk         r7    k5 ; k5 = 122
.line	290	loadk         r8    k6 ; k6 = 126
.line	290	loadk         r9    k7 ; k7 = 49
.line	290	loadk        r10    k8 ; k8 = 120
.line	290	loadk        r11    k9 ; k9 = 255
.line	290	loadk        r12   k10 ; k10 = 205
.line	290	loadk        r13   k11 ; k11 = 35
.line	290	loadk        r14   k12 ; k12 = 175
.line	290	loadk        r15   k13 ; k13 = 19
.line	290	loadk        r16   k14 ; k14 = 235
.line	290	loadk        r17   k15 ; k15 = 176
.line	290	loadk        r18   k16 ; k16 = 251
.line	290	loadk        r19   k17 ; k17 = 219
.line	290	loadk        r20   k18 ; k18 = 223
.line	290	loadk        r21    k9 ; k9 = 255
.line	290	loadk        r22   k19 ; k19 = 115
.line	290	loadk        r23   k20 ; k20 = 81
.line	290	loadk        r24   k21 ; k21 = 10
.line	290	loadk        r25    k7 ; k7 = 49
.line	290	loadk        r26   k22 ; k22 = 142
.line	290	loadk        r27   k14 ; k14 = 235
.line	290	loadk        r28   k23 ; k23 = 174
.line	290	loadk        r29   k24 ; k24 = 14
.line	290	loadk        r30   k25 ; k25 = 247
.line	290	loadk        r31   k26 ; k26 = 24
.line	290	loadk        r32   k16 ; k16 = 251
.line	290	loadk        r33   k27 ; k27 = 179
.line	290	loadk        r34   k28 ; k28 = 228
.line	290	loadk        r35   k29 ; k29 = 221
.line	290	loadk        r36   k30 ; k30 = 211
.line	290	loadk        r37   k31 ; k31 = 238
.line	290	loadk        r38   k32 ; k32 = 109
.line	290	loadk        r39   k33 ; k33 = 116
.line	290	loadk        r40   k34 ; k34 = 58
.line	290	loadk        r41   k35 ; k35 = 39
.line	290	loadk        r42   k36 ; k36 = 153
.line	290	loadk        r43   k37 ; k37 = 194
.line	290	loadk        r44   k38 ; k38 = 157
.line	290	loadk        r45   k39 ; k39 = 13
.line	290	call          r5    41     2
.line	290	getupval      r6    u1
.line	290	loadk         r7   k40 ; k40 = 146
.line	290	loadk         r8   k33 ; k33 = 116
.line	290	loadk         r9   k42 ; k42 = 9
.line	290	loadk        r10   k43 ; k43 = 89
.line	290	loadk        r11   k44 ; k44 = 60
.line	290	loadk        r12   k45 ; k45 = 198
.line	290	loadk        r13   k46 ; k46 = 216
.line	290	loadk        r14   k47 ; k47 = 62
.line	290	loadk        r15   k48 ; k48 = 188
.line	290	loadk        r16   k49 ; k49 = 41
.line	290	loadk        r17   k50 ; k50 = 225
.line	290	loadk        r18   k51 ; k51 = 182
.line	290	loadk        r19   k52 ; k52 = 245
.line	290	loadk        r20   k53 ; k53 = 232
.line	290	loadk        r21   k50 ; k50 = 225
.line	290	loadk        r22   k54 ; k54 = 237
.line	290	loadk        r23    k8 ; k8 = 120
.line	290	loadk        r24   k55 ; k55 = 68
.line	290	loadk        r25   k47 ; k47 = 62
.line	290	loadk        r26   k56 ; k56 = 33
.line	290	loadk        r27   k57 ; k57 = 158
.line	290	loadk        r28   k58 ; k58 = 134
.line	290	loadk        r29   k59 ; k59 = 160
.line	290	loadk        r30   k60 ; k60 = 18
.line	290	loadk        r31   k61 ; k61 = 187
.line	290	loadk        r32   k62 ; k62 = 53
.line	290	loadk        r33   k63 ; k63 = 248
.line	290	loadk        r34   k61 ; k61 = 187
.line	290	loadk        r35   k28 ; k28 = 228
.line	290	call          r6    30     0
.line	290	setlist       r4     0     1
.line	290	call          r3     2     2
.label	l143
.line	290	call          r2     2     1
.line	290	return        r0     1
.label	l145
.line	290	self          r2    r1   k64 ; k64 = "GetGameParameter"
.line	290	getupval      r4    u1
.line	290	loadk         r5    k4 ; k4 = 177
.line	290	loadk         r6    k5 ; k5 = 122
.line	290	loadk         r7   k65 ; k65 = 91
.line	290	loadk         r8   k66 ; k66 = 31
.line	290	loadk         r9   k67 ; k67 = 93
.line	290	loadk        r10   k68 ; k68 = 229
.line	290	loadk        r11   k69 ; k69 = 202
.line	290	loadk        r12   k49 ; k49 = 41
.line	290	loadk        r13   k70 ; k70 = 169
.line	290	loadk        r14   k71 ; k71 = 2
.line	290	loadk        r15   k14 ; k14 = 235
.line	290	loadk        r16   k23 ; k23 = 174
.line	290	loadk        r17   k72 ; k72 = 244
.line	290	loadk        r18    k9 ; k9 = 255
.line	290	loadk        r19   k73 ; k73 = 222
.line	290	loadk        r20   k46 ; k46 = 216
.line	290	loadk        r21   k74 ; k74 = 100
.line	290	loadk        r22   k75 ; k75 = 64
.line	290	loadk        r23   k44 ; k44 = 60
.line	290	call          r4    20     2
.line	290	call          r2     3     2
.line	290	gettable      r2    r2   k76 ; k76 = "Value"
.line	290	test          r2     0
.line	290	jmp            0  l188
.line	290	gettabup      r3    u0   k77 ; k77 = "type"
.line	290	move          r4    r2
.line	290	call          r3     2     2
.line	290	getupval      r4    u1
.line	290	loadk         r5   k40 ; k40 = 146
.line	290	loadk         r6   k33 ; k33 = 116
.line	290	loadk         r7   k78 ; k78 = 75
.line	290	loadk         r8   k26 ; k26 = 24
.line	290	loadk         r9   k79 ; k79 = 121
.line	290	call          r4     6     2
.line	290	eq             0    r3    r4
.line	290	jmp            0  l188
.line	290	gettabup      r3    u0   k81 ; k81 = "DeepCopy"
.line	290	move          r4    r2
.line	290	call          r3     2     2
.line	290	settable      r0   k80    r3 ; k80 = "FolderTree"
.line	290	jmp            0  l190
.label	l188
.line	290	newtable      r3     0     0
.line	290	settable      r0   k80    r3 ; k80 = "FolderTree"
.label	l190
.line	290	self          r3    r1   k64 ; k64 = "GetGameParameter"
.line	290	getupval      r5    u1
.line	290	loadk         r6    k4 ; k4 = 177
.line	290	loadk         r7    k5 ; k5 = 122
.line	290	loadk         r8   k65 ; k65 = 91
.line	290	loadk         r9   k66 ; k66 = 31
.line	290	loadk        r10   k67 ; k67 = 93
.line	290	loadk        r11   k68 ; k68 = 229
.line	290	loadk        r12   k69 ; k69 = 202
.line	290	loadk        r13   k49 ; k49 = 41
.line	290	loadk        r14   k70 ; k70 = 169
.line	290	loadk        r15   k82 ; k82 = 20
.line	290	loadk        r16   k68 ; k68 = 229
.line	290	loadk        r17   k51 ; k51 = 182
.line	290	loadk        r18   k63 ; k63 = 248
.line	290	loadk        r19   k83 ; k83 = 215
.line	290	loadk        r20   k10 ; k10 = 205
.line	290	loadk        r21   k84 ; k84 = 252
.line	290	call          r5    17     2
.line	290	call          r3     3     2
.line	290	gettable      r3    r3   k76 ; k76 = "Value"
.line	290	test          r3     0
.line	290	jmp            0  l230
.line	290	gettabup      r4    u0   k77 ; k77 = "type"
.line	290	move          r5    r3
.line	290	call          r4     2     2
.line	290	getupval      r5    u1
.line	290	loadk         r6   k40 ; k40 = 146
.line	290	loadk         r7   k33 ; k33 = 116
.line	290	loadk         r8   k78 ; k78 = 75
.line	290	loadk         r9   k26 ; k26 = 24
.line	290	loadk        r10   k79 ; k79 = 121
.line	290	call          r5     6     2
.line	290	eq             0    r4    r5
.line	290	jmp            0  l230
.line	290	gettabup      r4    u0   k81 ; k81 = "DeepCopy"
.line	290	move          r5    r3
.line	290	call          r4     2     2
.line	290	settable      r0   k85    r4 ; k85 = "AssetPathMap"
.line	290	jmp            0  l232
.label	l230
.line	290	newtable      r4     0     0
.line	290	settable      r0   k85    r4 ; k85 = "AssetPathMap"
.label	l232
.line	290	self          r4    r0   k86 ; k86 = "ClampWorkAssetString" (truncated)
.line	290	gettable      r6    r0   k85 ; k85 = "AssetPathMap"
.line	290	call          r4     3     1
.line	290	return        r0     1
.line	290	move          r0    r0
.line	290	move          r0    r0
.line	290	move          r0    r0
.line	290	gettabup      r2    u0   k68 ; k68 = 229
.line	290	return        r0     1

.function	main/f6

.source	null
.linedefined	312
.lastlinedefined	339
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	17	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	177
.constant	k5	122
.constant	k6	126
.constant	k7	49
.constant	k8	120
.constant	k9	255
.constant	k10	205
.constant	k11	35
.constant	k12	175
.constant	k13	19
.constant	k14	235
.constant	k15	176
.constant	k16	251
.constant	k17	219
.constant	k18	223
.constant	k19	115
.constant	k20	81
.constant	k21	10
.constant	k22	142
.constant	k23	174
.constant	k24	14
.constant	k25	247
.constant	k26	17
.constant	k27	250
.constant	k28	161
.constant	k29	245
.constant	k30	248
.constant	k31	217
.constant	k32	216
.constant	k33	99
.constant	k34	83
.constant	k35	40
.constant	k36	33
.constant	k37	144
.constant	k38	194
.constant	k39	159
.constant	k40	3
.constant	k41	138
.constant	k42	113
.constant	k43	76
.constant	k44	6
.constant	k45	111
.constant	k46	"ipairs"
.constant	k47	"pairs"
.constant	k48	"FolderTree"
.constant	k49	"FolderID"
.constant	k50	"IsDefault"
.constant	k51	true
.constant	k52	"FolderType"
.constant	k53	"DeepCopy"
.constant	k54	"FolderName"
.constant	k55	181
.constant	k56	96
.constant	k57	75
.constant	k58	48
.constant	k59	117
.constant	k60	228
.constant	k61	"LocUtil"
.constant	k62	"GetLocalizeResStr"
.constant	k63	99010092
.constant	k64	"type"
.constant	k65	136
.constant	k66	68
.constant	k67	22
.constant	k68	121
.constant	k69	"insert"
.constant	k70	"SaveFolderTree"

.line	312	gettabup      r1    u0    k0 ; k0 = "print"
.line	312	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	312	test          r2     0
.line	312	jmp            0   l59
.line	312	gettabup      r2    u0    k2 ; k2 = "table"
.line	312	gettable      r2    r2    k3 ; k3 = "concat"
.line	312	newtable      r3     1     0
.line	312	getupval      r4    u1
.line	312	loadk         r5    k4 ; k4 = 177
.line	312	loadk         r6    k5 ; k5 = 122
.line	312	loadk         r7    k6 ; k6 = 126
.line	312	loadk         r8    k7 ; k7 = 49
.line	312	loadk         r9    k8 ; k8 = 120
.line	312	loadk        r10    k9 ; k9 = 255
.line	312	loadk        r11   k10 ; k10 = 205
.line	312	loadk        r12   k11 ; k11 = 35
.line	312	loadk        r13   k12 ; k12 = 175
.line	312	loadk        r14   k13 ; k13 = 19
.line	312	loadk        r15   k14 ; k14 = 235
.line	312	loadk        r16   k15 ; k15 = 176
.line	312	loadk        r17   k16 ; k16 = 251
.line	312	loadk        r18   k17 ; k17 = 219
.line	312	loadk        r19   k18 ; k18 = 223
.line	312	loadk        r20    k9 ; k9 = 255
.line	312	loadk        r21   k19 ; k19 = 115
.line	312	loadk        r22   k20 ; k20 = 81
.line	312	loadk        r23   k21 ; k21 = 10
.line	312	loadk        r24    k7 ; k7 = 49
.line	312	loadk        r25   k22 ; k22 = 142
.line	312	loadk        r26   k14 ; k14 = 235
.line	312	loadk        r27   k23 ; k23 = 174
.line	312	loadk        r28   k24 ; k24 = 14
.line	312	loadk        r29   k25 ; k25 = 247
.line	312	loadk        r30   k26 ; k26 = 17
.line	312	loadk        r31   k27 ; k27 = 250
.line	312	loadk        r32   k28 ; k28 = 161
.line	312	loadk        r33   k29 ; k29 = 245
.line	312	loadk        r34   k30 ; k30 = 248
.line	312	loadk        r35   k31 ; k31 = 217
.line	312	loadk        r36   k32 ; k32 = 216
.line	312	loadk        r37   k33 ; k33 = 99
.line	312	loadk        r38   k34 ; k34 = 83
.line	312	loadk        r39   k35 ; k35 = 40
.line	312	loadk        r40   k36 ; k36 = 33
.line	312	loadk        r41   k37 ; k37 = 144
.line	312	loadk        r42   k38 ; k38 = 194
.line	312	loadk        r43   k39 ; k39 = 159
.line	312	loadk        r44   k40 ; k40 = 3
.line	312	call          r4    41     2
.line	312	getupval      r5    u1
.line	312	loadk         r6   k41 ; k41 = 138
.line	312	loadk         r7   k42 ; k42 = 113
.line	312	loadk         r8   k43 ; k43 = 76
.line	312	loadk         r9   k44 ; k44 = 6
.line	312	loadk        r10   k45 ; k45 = 111
.line	312	call          r5     6     0
.line	312	setlist       r3     0     1
.line	312	call          r2     2     2
.label	l59
.line	312	call          r1     2     1
.line	312	loadbool      r1     0     0
.line	312	gettabup      r2    u0   k46 ; k46 = "ipairs"
.line	312	getupval      r3    u2
.line	312	call          r2     2     4
.line	312	jmp            0  l127
.line	312	loadbool      r7     0     0
.line	312	gettabup      r8    u0   k47 ; k47 = "pairs"
.line	312	gettable      r9    r0   k48 ; k48 = "FolderTree"
.line	312	call          r8     2     4
.line	312	jmp            0   l79
.line	312	gettable     r13   r12   k49 ; k49 = "FolderID"
.line	312	gettable     r14    r6   k49 ; k49 = "FolderID"
.line	312	eq             0   r13   r14
.line	312	jmp            0   l79
.line	312	loadbool      r7     1     0
.line	312	settable     r12   k50   k51 ; k51 = true
.line	312	gettable     r13    r6   k52 ; k52 = "FolderType"
.line	312	settable     r12   k52   r13 ; k52 = "FolderType"
.line	312	jmp            0   l81
.label	l79
.line	312	move          r0    r0
.line	312	move          r0    r0
.label	l81
.line	312	test          r7     1
.line	312	jmp            0  l127
.line	312	gettabup      r8    u0   k53 ; k53 = "DeepCopy"
.line	312	move          r9    r6
.line	312	call          r8     2     2
.line	312	gettable      r9    r8   k54 ; k54 = "FolderName"
.line	312	getupval     r10    u1
.line	312	loadk        r11   k55 ; k55 = 181
.line	312	loadk        r12   k56 ; k56 = 96
.line	312	loadk        r13   k57 ; k57 = 75
.line	312	loadk        r14   k58 ; k58 = 48
.line	312	loadk        r15   k59 ; k59 = 117
.line	312	loadk        r16   k60 ; k60 = 228
.line	312	call         r10     7     2
.line	312	eq             0    r9   r10
.line	312	jmp            0  l103
.line	312	gettabup      r9    u0   k61 ; k61 = "LocUtil"
.line	312	gettable      r9    r9   k62 ; k62 = "GetLocalizeResStr"
.line	312	loadk        r10   k63 ; k63 = 99010092
.line	312	call          r9     2     2
.line	312	settable      r8   k54    r9 ; k54 = "FolderName"
.line	312	jmp            0  l121
.label	l103
.line	312	gettabup      r9    u0   k64 ; k64 = "type"
.line	312	gettable     r10    r8   k54 ; k54 = "FolderName"
.line	312	call          r9     2     2
.line	312	getupval     r10    u1
.line	312	loadk        r11   k65 ; k65 = 136
.line	312	loadk        r12   k56 ; k56 = 96
.line	312	loadk        r13   k66 ; k66 = 68
.line	312	loadk        r14   k67 ; k67 = 22
.line	312	loadk        r15   k68 ; k68 = 121
.line	312	loadk        r16   k60 ; k60 = 228
.line	312	call         r10     7     2
.line	312	eq             0    r9   r10
.line	312	jmp            0  l121
.line	312	gettabup      r9    u0   k61 ; k61 = "LocUtil"
.line	312	gettable      r9    r9   k62 ; k62 = "GetLocalizeResStr"
.line	312	gettable     r10    r8   k54 ; k54 = "FolderName"
.line	312	call          r9     2     2
.line	312	settable      r8   k54    r9 ; k54 = "FolderName"
.label	l121
.line	312	gettabup      r9    u0    k2 ; k2 = "table"
.line	312	gettable      r9    r9   k69 ; k69 = "insert"
.line	312	gettable     r10    r0   k48 ; k48 = "FolderTree"
.line	312	move         r11    r8
.line	312	call          r9     3     1
.line	312	loadbool      r1     1     0
.label	l127
.line	312	move          r0    r0
.line	312	move          r0    r0
.line	312	test          r1     0
.line	312	jmp            0  l133
.line	312	self          r2    r0   k70 ; k70 = "SaveFolderTree"
.line	312	call          r2     2     1
.label	l133
.line	312	return        r0     1
.line	312	move          r0    r0
.line	312	move          r0    r0
.line	312	move          r0    r0
.line	312	move          r0    r0
.line	312	return        r0     1

.function	main/f7

.source	null
.linedefined	341
.lastlinedefined	354
.numparams	2
.is_vararg	0
.maxstacksize	11

.upvalue	"_ENV"	19	true
.upvalue	"U1"	1	true
.upvalue	"U2"	0	false

.constant	k0	"RootFolderID"
.constant	k1	"DefaultSubFolderID"
.constant	k2	"ipairs"
.constant	k3	"FolderTree"
.constant	k4	"ParentFolderID"
.constant	k5	"DisableDragIn"
.constant	k6	true
.constant	k7	"FolderID"

.line	341	gettabup      r2    u0    r1
.line	341	test          r2     1
.line	341	jmp            0    l7
.line	341	getupval      r3    u1
.line	341	call          r3     1     2
.line	341	return        r3     2
.label	l7
.line	341	gettable      r3    r2    k0 ; k0 = "RootFolderID"
.line	341	gettable      r4    r2    k1 ; k1 = "DefaultSubFolderID"
.line	341	gettabup      r5    u2    k2 ; k2 = "ipairs"
.line	341	gettable      r6    r0    k3 ; k3 = "FolderTree"
.line	341	call          r5     2     4
.line	341	jmp            0   l21
.line	341	gettable     r10    r9    k4 ; k4 = "ParentFolderID"
.line	341	eq             0   r10    r3
.line	341	jmp            0   l21
.line	341	gettable     r10    r9    k5 ; k5 = "DisableDragIn"
.line	341	eq             1   r10    k6 ; k6 = true
.line	341	jmp            0   l21
.line	341	gettable     r10    r9    k7 ; k7 = "FolderID"
.line	341	return       r10     2
.label	l21
.line	341	move          r0    r0
.line	341	move          r0    r0
.line	341	return        r4     2
.line	341	return        r0     1
.line	341	move          r0    r0
.line	341	move          r0    r0
.line	341	move          r0    r0
.line	341	move          r0    r0
.line	341	return        r0     1

.function	main/f8

.source	null
.linedefined	356
.lastlinedefined	389
.numparams	2
.is_vararg	0
.maxstacksize	9

.upvalue	"_ENV"	1	true
.upvalue	"U1"	0	false

.constant	k0	"ipairs"
.constant	k1	"FolderTree"
.constant	k2	"FolderID"
.constant	k3	"DisableDragOut"
.constant	k4	true
.constant	k5	"DisableDrag"
.constant	k6	"DisableDelete"
.constant	k7	"DisableCopy"

.line	356	test          r1     0
.line	356	jmp            0    l7
.line	356	getupval      r2    u0
.line	356	call          r2     1     2
.line	356	eq             0    r1    r2
.line	356	jmp            0    l9
.label	l7
.line	356	loadnil       r2     0
.line	356	return        r2     2
.label	l9
.line	356	loadnil       r2     0
.line	356	gettabup      r3    u1    k0 ; k0 = "ipairs"
.line	356	gettable      r4    r0    k1 ; k1 = "FolderTree"
.line	356	call          r3     2     4
.line	356	jmp            0   l19
.line	356	gettable      r8    r7    k2 ; k2 = "FolderID"
.line	356	eq             0    r8    r1
.line	356	jmp            0   l19
.line	356	move          r2    r7
.line	356	jmp            0   l21
.label	l19
.line	356	move          r0    r0
.line	356	move          r0    r0
.label	l21
.line	356	test          r2     1
.line	356	jmp            0   l25
.line	356	loadnil       r3     0
.line	356	return        r3     2
.label	l25
.line	356	newtable      r3     0     0
.line	356	loadbool      r4     0     0
.line	356	gettable      r5    r2    k3 ; k3 = "DisableDragOut"
.line	356	eq             0    r5    k4 ; k4 = true
.line	356	jmp            0   l32
.line	356	settable      r3    k5    k4 ; k4 = true
.line	356	loadbool      r4     1     0
.label	l32
.line	356	gettable      r5    r2    k6 ; k6 = "DisableDelete"
.line	356	eq             0    r5    k4 ; k4 = true
.line	356	jmp            0   l37
.line	356	settable      r3    k6    k4 ; k4 = true
.line	356	loadbool      r4     1     0
.label	l37
.line	356	gettable      r5    r2    k7 ; k7 = "DisableCopy"
.line	356	eq             0    r5    k4 ; k4 = true
.line	356	jmp            0   l42
.line	356	settable      r3    k7    k4 ; k4 = true
.line	356	loadbool      r4     1     0
.label	l42
.line	356	gettable      r5    r2    k5 ; k5 = "DisableDrag"
.line	356	eq             0    r5    k4 ; k4 = true
.line	356	jmp            0   l47
.line	356	settable      r3    k5    k4 ; k4 = true
.line	356	loadbool      r4     1     0
.label	l47
.line	356	test          r4     0
.line	356	jmp            0   l51
.line	356	testset       r5    r3     1
.line	356	jmp            0   l52
.label	l51
.line	356	loadnil       r5     0
.label	l52
.line	356	return        r5     2
.line	356	return        r0     1
.line	356	move          r0    r0
.line	356	return        r0     1

.function	main/f9

.source	null
.linedefined	391
.lastlinedefined	404
.numparams	3
.is_vararg	0
.maxstacksize	4

.constant	k0	"DisableDelete"
.constant	k1	nil
.constant	k2	"DisableCopy"
.constant	k3	"DisableDrag"

.line	391	test          r2     1
.line	391	jmp            0    l4
.line	391	return        r0     1
.label	l4
.line	391	gettable      r3    r2    k0 ; k0 = "DisableDelete"
.line	391	eq             1    r3    k1 ; k1 = nil
.line	391	jmp            0    l9
.line	391	gettable      r3    r2    k0 ; k0 = "DisableDelete"
.line	391	settable      r1    k0    r3 ; k0 = "DisableDelete"
.label	l9
.line	391	gettable      r3    r2    k2 ; k2 = "DisableCopy"
.line	391	eq             1    r3    k1 ; k1 = nil
.line	391	jmp            0   l14
.line	391	gettable      r3    r2    k2 ; k2 = "DisableCopy"
.line	391	settable      r1    k2    r3 ; k2 = "DisableCopy"
.label	l14
.line	391	gettable      r3    r2    k3 ; k3 = "DisableDrag"
.line	391	eq             1    r3    k1 ; k1 = nil
.line	391	jmp            0   l19
.line	391	gettable      r3    r2    k3 ; k3 = "DisableDrag"
.line	391	settable      r1    k3    r3 ; k3 = "DisableDrag"
.label	l19
.line	391	return        r0     1
.line	391	move          r0    r0
.line	391	move          r0    r0
.line	391	move          r0    r0
.line	391	return        r0     1

.function	main/f10

.source	null
.linedefined	406
.lastlinedefined	416
.numparams	3
.is_vararg	0
.maxstacksize	11

.upvalue	"_ENV"	1	true
.upvalue	"U1"	0	false

.constant	k0	"pairs"
.constant	k1	"AssetPathMap"
.constant	k2	"tonumber"
.constant	k3	"AssetUID"
.constant	k4	nil
.constant	k5	"AssetType"

.line	406	test          r1     0
.line	406	jmp            0    l7
.line	406	getupval      r3    u0
.line	406	call          r3     1     2
.line	406	eq             0    r1    r3
.line	406	jmp            0    l9
.label	l7
.line	406	loadbool      r3     0     0
.line	406	return        r3     2
.label	l9
.line	406	gettabup      r3    u1    k0 ; k0 = "pairs"
.line	406	gettable      r4    r0    k1 ; k1 = "AssetPathMap"
.line	406	call          r3     2     4
.line	406	jmp            0   l28
.line	406	gettabup      r8    u1    k2 ; k2 = "tonumber"
.line	406	gettable      r9    r7    k3 ; k3 = "AssetUID"
.line	406	call          r8     2     2
.line	406	gettabup      r9    u1    k2 ; k2 = "tonumber"
.line	406	move         r10    r1
.line	406	call          r9     2     2
.line	406	eq             0    r8    r9
.line	406	jmp            0   l28
.line	406	eq             1    r2    k4 ; k4 = nil
.line	406	jmp            0   l26
.line	406	gettable      r8    r7    k5 ; k5 = "AssetType"
.line	406	eq             0    r8    r2
.line	406	jmp            0   l28
.label	l26
.line	406	loadbool      r8     1     0
.line	406	return        r8     2
.label	l28
.line	406	move          r0    r0
.line	406	move          r0    r0
.line	406	loadbool      r3     0     0
.line	406	return        r3     2
.line	406	return        r0     1
.line	406	move          r0    r0
.line	406	move          r0    r0
.line	406	return        r0     1

.function	main/f11

.source	null
.linedefined	418
.lastlinedefined	429
.numparams	2
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	0	false
.upvalue	"U1"	15	true

.constant	k0	"tonumber"
.constant	k1	"pairs"
.constant	k2	"AssetPathMap"
.constant	k3	"AssetUID"
.constant	k4	"AssetType"
.constant	k5	"Effect"

.line	418	gettabup      r2    u0    k0 ; k0 = "tonumber"
.line	418	move          r3    r1
.line	418	call          r2     2     2
.line	418	test          r2     1
.line	418	jmp            0    l8
.line	418	loadbool      r3     0     0
.line	418	return        r3     2
.label	l8
.line	418	gettabup      r3    u0    k1 ; k1 = "pairs"
.line	418	gettable      r4    r0    k2 ; k2 = "AssetPathMap"
.line	418	call          r3     2     4
.line	418	jmp            0   l23
.line	418	gettabup      r8    u0    k0 ; k0 = "tonumber"
.line	418	gettable      r9    r7    k3 ; k3 = "AssetUID"
.line	418	call          r8     2     2
.line	418	eq             0    r8    r2
.line	418	jmp            0   l23
.line	418	gettable      r8    r7    k4 ; k4 = "AssetType"
.line	418	gettabup      r9    u1    k5 ; k5 = "Effect"
.line	418	eq             0    r8    r9
.line	418	jmp            0   l23
.line	418	loadbool      r8     1     0
.line	418	return        r8     2
.label	l23
.line	418	move          r0    r0
.line	418	move          r0    r0
.line	418	loadbool      r3     0     0
.line	418	return        r3     2
.line	418	return        r0     1
.line	418	move          r0    r0
.line	418	move          r0    r0
.line	418	move          r0    r0
.line	418	return        r0     1

.function	main/f12

.source	null
.linedefined	431
.lastlinedefined	436
.numparams	1
.is_vararg	0
.maxstacksize	24

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"slua_GameFrontendHUD"
.constant	k1	"GetPlayerController"
.constant	k2	"slua"
.constant	k3	"isValid"
.constant	k4	"CreativeModeBinaryDataEditFeature"
.constant	k5	"SetOneGameParameters"
.constant	k6	177
.constant	k7	122
.constant	k8	91
.constant	k9	31
.constant	k10	93
.constant	k11	229
.constant	k12	202
.constant	k13	41
.constant	k14	169
.constant	k15	2
.constant	k16	235
.constant	k17	174
.constant	k18	244
.constant	k19	255
.constant	k20	222
.constant	k21	216
.constant	k22	100
.constant	k23	64
.constant	k24	60
.constant	k25	"FolderTree"

.line	431	gettabup      r1    u0    k0 ; k0 = "slua_GameFrontendHUD"
.line	431	self          r1    r1    k1 ; k1 = "GetPlayerController"
.line	431	call          r1     2     2
.line	431	gettabup      r2    u0    k2 ; k2 = "slua"
.line	431	gettable      r2    r2    k3 ; k3 = "isValid"
.line	431	move          r3    r1
.line	431	call          r2     2     2
.line	431	test          r2     0
.line	431	jmp            0   l37
.line	431	gettable      r2    r1    k4 ; k4 = "CreativeModeBinaryDa" (truncated)
.line	431	self          r2    r2    k5 ; k5 = "SetOneGameParameters"
.line	431	getupval      r4    u1
.line	431	loadk         r5    k6 ; k6 = 177
.line	431	loadk         r6    k7 ; k7 = 122
.line	431	loadk         r7    k8 ; k8 = 91
.line	431	loadk         r8    k9 ; k9 = 31
.line	431	loadk         r9   k10 ; k10 = 93
.line	431	loadk        r10   k11 ; k11 = 229
.line	431	loadk        r11   k12 ; k12 = 202
.line	431	loadk        r12   k13 ; k13 = 41
.line	431	loadk        r13   k14 ; k14 = 169
.line	431	loadk        r14   k15 ; k15 = 2
.line	431	loadk        r15   k16 ; k16 = 235
.line	431	loadk        r16   k17 ; k17 = 174
.line	431	loadk        r17   k18 ; k18 = 244
.line	431	loadk        r18   k19 ; k19 = 255
.line	431	loadk        r19   k20 ; k20 = 222
.line	431	loadk        r20   k21 ; k21 = 216
.line	431	loadk        r21   k22 ; k22 = 100
.line	431	loadk        r22   k23 ; k23 = 64
.line	431	loadk        r23   k24 ; k24 = 60
.line	431	call          r4    20     2
.line	431	gettable      r5    r0   k25 ; k25 = "FolderTree"
.line	431	loadnil       r6     1
.line	431	loadbool      r8     0     0
.line	431	call          r2     7     1
.label	l37
.line	431	return        r0     1
.line	431	move          r0    r0
.line	431	move          r0    r0
.line	431	return        r0     1

.function	main/f13

.source	null
.linedefined	443
.lastlinedefined	456
.numparams	3
.is_vararg	0
.maxstacksize	23

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	133
.constant	k2	122
.constant	k3	68
.constant	k4	25
.constant	k5	115
.constant	k6	248
.constant	k7	151
.constant	k8	63
.constant	k9	169
.constant	k10	54
.constant	k11	237
.constant	k12	172
.constant	k13	247
.constant	k14	197
.constant	k15	217
.constant	k16	127
.constant	k17	73
.constant	k18	"GetCharactersLength"
.constant	k19	"SubString"
.constant	k20	1

.line	443	gettabup      r3    u0    k0 ; k0 = "require"
.line	443	getupval      r4    u1
.line	443	loadk         r5    k1 ; k1 = 133
.line	443	loadk         r6    k2 ; k2 = 122
.line	443	loadk         r7    k3 ; k3 = 68
.line	443	loadk         r8    k4 ; k4 = 25
.line	443	loadk         r9    k5 ; k5 = 115
.line	443	loadk        r10    k6 ; k6 = 248
.line	443	loadk        r11    k7 ; k7 = 151
.line	443	loadk        r12    k8 ; k8 = 63
.line	443	loadk        r13    k9 ; k9 = 169
.line	443	loadk        r14   k10 ; k10 = 54
.line	443	loadk        r15   k11 ; k11 = 237
.line	443	loadk        r16   k12 ; k12 = 172
.line	443	loadk        r17   k13 ; k13 = 247
.line	443	loadk        r18   k14 ; k14 = 197
.line	443	loadk        r19   k15 ; k15 = 217
.line	443	loadk        r20    k6 ; k6 = 248
.line	443	loadk        r21   k16 ; k16 = 127
.line	443	loadk        r22   k17 ; k17 = 73
.line	443	call          r4    19     2
.line	443	call          r3     2     2
.line	443	gettable      r4    r3   k18 ; k18 = "GetCharactersLength"
.line	443	move          r5    r0
.line	443	move          r6    r2
.line	443	call          r4     3     2
.label	l27
.line	443	lt             0    r1    r4
.line	443	jmp            0   l46
.line	443	gettable      r5    r3   k18 ; k18 = "GetCharactersLength"
.line	443	move          r6    r0
.line	443	call          r5     2     2
.line	443	gettable      r6    r3   k19 ; k19 = "SubString"
.line	443	move          r7    r0
.line	443	loadk         r8   k20 ; k20 = 1
.line	443	sub           r9    r5   k20 ; k20 = 1
.line	443	call          r6     4     2
.line	443	eq             1    r6    r0
.line	443	jmp            0   l46
.line	443	move          r0    r6
.line	443	gettable      r7    r3   k18 ; k18 = "GetCharactersLength"
.line	443	move          r8    r0
.line	443	move          r9    r2
.line	443	call          r7     3     2
.line	443	move          r4    r7
.line	443	jmp            0   l27
.label	l46
.line	443	return        r0     2
.line	443	return        r0     1
.line	443	move          r0    r0
.line	443	move          r0    r0
.line	443	move          r0    r0
.line	443	move          r0    r0
.line	443	return        r0     1

.function	main/f14

.source	null
.linedefined	458
.lastlinedefined	493
.numparams	2
.is_vararg	0
.maxstacksize	62

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	20	true
.upvalue	"U3"	21	true

.constant	k0	"type"
.constant	k1	146
.constant	k2	116
.constant	k3	75
.constant	k4	24
.constant	k5	121
.constant	k6	"require"
.constant	k7	"table"
.constant	k8	"concat"
.constant	k9	161
.constant	k10	68
.constant	k11	17
.constant	k12	80
.constant	k13	227
.constant	k14	216
.constant	k15	98
.constant	k16	144
.constant	k17	43
.constant	k18	224
.constant	k19	236
.constant	k20	211
.constant	k21	232
.constant	k22	201
.constant	k23	237
.constant	k24	76
.constant	k25	47
.constant	k26	33
.constant	k27	174
.constant	k28	199
.constant	k29	186
.constant	k30	25
.constant	k31	19
.constant	k32	245
.constant	k33	191
.constant	k34	229
.constant	k35	250
.constant	k36	208
.constant	k37	253
.constant	k38	127
.constant	k39	27
.constant	k40	10
.constant	k41	59
.constant	k42	176
.constant	k43	11
.constant	k44	200
.constant	k45	82
.constant	k46	72
.constant	k47	198
.constant	k48	62
.constant	k49	188
.constant	k50	41
.constant	k51	225
.constant	k52	182
.constant	k53	130
.constant	k54	207
.constant	k55	100
.constant	k56	64
.constant	k57	56
.constant	k58	48
.constant	k59	133
.constant	k60	172
.constant	k61	49
.constant	k62	162
.constant	k63	241
.constant	k64	149
.constant	k65	231
.constant	k66	217
.constant	k67	204
.constant	k68	103
.constant	k69	71
.constant	k70	40
.constant	k71	57
.constant	k72	153
.constant	k73	194
.constant	k74	30
.constant	k75	165
.constant	k76	115
.constant	k77	78
.constant	k78	"ipairs"
.constant	k79	"GetArrayStructGameParameterConfig"
.constant	k80	177
.constant	k81	122
.constant	k82	91
.constant	k83	31
.constant	k84	93
.constant	k85	202
.constant	k86	169
.constant	k87	20
.constant	k88	248
.constant	k89	215
.constant	k90	205
.constant	k91	252
.constant	k92	"StringMaxChar"
.constant	k93	0
.constant	k94	"ExtraUIConfig"
.constant	k95	"bUseUtf8Length"
.constant	k96	1
.constant	k97	"FieldKey"
.constant	k98	"OverrideCharBytes"
.constant	k99	2
.constant	k100	97
.constant	k101	29
.constant	k102	114
.constant	k103	"print"
.constant	k104	"bWriteLog"
.constant	k105	"string"
.constant	k106	"format"
.constant	k107	126
.constant	k108	120
.constant	k109	255
.constant	k110	35
.constant	k111	175
.constant	k112	235
.constant	k113	251
.constant	k114	219
.constant	k115	223
.constant	k116	81
.constant	k117	142
.constant	k118	14
.constant	k119	247
.constant	k120	23
.constant	k121	179
.constant	k122	243
.constant	k123	94
.constant	k124	8
.constant	k125	39
.constant	k126	143
.constant	k127	173
.constant	k128	63
.constant	k129	26
.constant	k130	123
.constant	k131	32
.constant	k132	226
.constant	k133	228
.constant	k134	117
.constant	k135	45
.constant	k136	131
.constant	k137	92
.constant	k138	140
.constant	k139	183
.constant	k140	244
.constant	k141	60
.constant	k142	16
.constant	k143	58
.constant	k144	145
.constant	k145	86
.constant	k146	195
.constant	k147	102
.constant	k148	"tostring"
.constant	k149	"AssetUID"

.line	458	gettabup      r2    u0    k0 ; k0 = "type"
.line	458	move          r3    r1
.line	458	call          r2     2     2
.line	458	getupval      r3    u1
.line	458	loadk         r4    k1 ; k1 = 146
.line	458	loadk         r5    k2 ; k2 = 116
.line	458	loadk         r6    k3 ; k3 = 75
.line	458	loadk         r7    k4 ; k4 = 24
.line	458	loadk         r8    k5 ; k5 = 121
.line	458	call          r3     6     2
.line	458	eq             1    r2    r3
.line	458	jmp            0   l14
.line	458	return        r0     1
.label	l14
.line	458	gettabup      r2    u0    k6 ; k6 = "require"
.line	458	gettabup      r3    u0    k7 ; k7 = "table"
.line	458	gettable      r3    r3    k8 ; k8 = "concat"
.line	458	newtable      r4     2     0
.line	458	getupval      r5    u1
.line	458	loadk         r6    k9 ; k9 = 161
.line	458	loadk         r7    k2 ; k2 = 116
.line	458	loadk         r8   k10 ; k10 = 68
.line	458	loadk         r9   k11 ; k11 = 17
.line	458	loadk        r10   k12 ; k12 = 80
.line	458	loadk        r11   k13 ; k13 = 227
.line	458	loadk        r12   k14 ; k14 = 216
.line	458	loadk        r13   k15 ; k15 = 98
.line	458	loadk        r14   k16 ; k16 = 144
.line	458	loadk        r15   k17 ; k17 = 43
.line	458	loadk        r16   k18 ; k18 = 224
.line	458	loadk        r17   k19 ; k19 = 236
.line	458	loadk        r18   k20 ; k20 = 211
.line	458	loadk        r19   k21 ; k21 = 232
.line	458	loadk        r20   k22 ; k22 = 201
.line	458	loadk        r21   k23 ; k23 = 237
.line	458	loadk        r22   k15 ; k15 = 98
.line	458	loadk        r23   k24 ; k24 = 76
.line	458	loadk        r24   k25 ; k25 = 47
.line	458	loadk        r25   k26 ; k26 = 33
.line	458	loadk        r26   k27 ; k27 = 174
.line	458	loadk        r27   k28 ; k28 = 199
.line	458	loadk        r28   k29 ; k29 = 186
.line	458	loadk        r29   k30 ; k30 = 25
.line	458	loadk        r30   k13 ; k13 = 227
.line	458	loadk        r31   k31 ; k31 = 19
.line	458	loadk        r32   k32 ; k32 = 245
.line	458	loadk        r33   k33 ; k33 = 191
.line	458	loadk        r34   k34 ; k34 = 229
.line	458	loadk        r35   k35 ; k35 = 250
.line	458	loadk        r36   k36 ; k36 = 208
.line	458	loadk        r37   k37 ; k37 = 253
.line	458	loadk        r38   k38 ; k38 = 127
.line	458	loadk        r39   k39 ; k39 = 27
.line	458	loadk        r40   k40 ; k40 = 10
.line	458	loadk        r41   k41 ; k41 = 59
.line	458	loadk        r42    k1 ; k1 = 146
.line	458	loadk        r43   k36 ; k36 = 208
.line	458	loadk        r44   k42 ; k42 = 176
.line	458	loadk        r45   k43 ; k43 = 11
.line	458	call          r5    41     2
.line	458	getupval      r6    u1
.line	458	loadk         r7   k44 ; k44 = 200
.line	458	loadk         r8   k45 ; k45 = 82
.line	458	loadk         r9   k46 ; k46 = 72
.line	458	loadk        r10   k30 ; k30 = 25
.line	458	loadk        r11    k5 ; k5 = 121
.line	458	loadk        r12   k47 ; k47 = 198
.line	458	loadk        r13   k14 ; k14 = 216
.line	458	loadk        r14   k48 ; k48 = 62
.line	458	loadk        r15   k49 ; k49 = 188
.line	458	loadk        r16   k50 ; k50 = 41
.line	458	loadk        r17   k51 ; k51 = 225
.line	458	loadk        r18   k52 ; k52 = 182
.line	458	loadk        r19   k32 ; k32 = 245
.line	458	loadk        r20   k21 ; k21 = 232
.line	458	loadk        r21   k53 ; k53 = 130
.line	458	loadk        r22   k54 ; k54 = 207
.line	458	loadk        r23   k55 ; k55 = 100
.line	458	loadk        r24   k56 ; k56 = 64
.line	458	loadk        r25   k57 ; k57 = 56
.line	458	loadk        r26   k58 ; k58 = 48
.line	458	loadk        r27   k59 ; k59 = 133
.line	458	loadk        r28   k36 ; k36 = 208
.line	458	loadk        r29   k60 ; k60 = 172
.line	458	loadk        r30   k61 ; k61 = 49
.line	458	loadk        r31   k62 ; k62 = 162
.line	458	loadk        r32   k58 ; k58 = 48
.line	458	loadk        r33   k63 ; k63 = 241
.line	458	loadk        r34   k64 ; k64 = 149
.line	458	loadk        r35   k51 ; k51 = 225
.line	458	loadk        r36   k65 ; k65 = 231
.line	458	loadk        r37   k66 ; k66 = 217
.line	458	loadk        r38   k67 ; k67 = 204
.line	458	loadk        r39   k68 ; k68 = 103
.line	458	loadk        r40   k69 ; k69 = 71
.line	458	loadk        r41   k70 ; k70 = 40
.line	458	loadk        r42   k71 ; k71 = 57
.line	458	loadk        r43   k72 ; k72 = 153
.line	458	loadk        r44   k73 ; k73 = 194
.line	458	loadk        r45   k49 ; k49 = 188
.line	458	loadk        r46   k74 ; k74 = 30
.line	458	call          r6    41     2
.line	458	getupval      r7    u1
.line	458	loadk         r8   k75 ; k75 = 165
.line	458	loadk         r9   k76 ; k76 = 115
.line	458	loadk        r10   k77 ; k77 = 78
.line	458	call          r7     4     0
.line	458	setlist       r4     0     1
.line	458	call          r3     2     2
.line	458	call          r2     2     2
.line	458	newtable      r3     0     0
.line	458	gettabup      r4    u0   k78 ; k78 = "ipairs"
.line	458	getupval      r5    u2
.line	458	call          r4     2     4
.line	458	jmp            0  l167
.line	458	gettable      r9    r2   k79 ; k79 = "GetArrayStructGamePa" (truncated)
.line	458	getupval     r10    u1
.line	458	loadk        r11   k80 ; k80 = 177
.line	458	loadk        r12   k81 ; k81 = 122
.line	458	loadk        r13   k82 ; k82 = 91
.line	458	loadk        r14   k83 ; k83 = 31
.line	458	loadk        r15   k84 ; k84 = 93
.line	458	loadk        r16   k34 ; k34 = 229
.line	458	loadk        r17   k85 ; k85 = 202
.line	458	loadk        r18   k50 ; k50 = 41
.line	458	loadk        r19   k86 ; k86 = 169
.line	458	loadk        r20   k87 ; k87 = 20
.line	458	loadk        r21   k34 ; k34 = 229
.line	458	loadk        r22   k52 ; k52 = 182
.line	458	loadk        r23   k88 ; k88 = 248
.line	458	loadk        r24   k89 ; k89 = 215
.line	458	loadk        r25   k90 ; k90 = 205
.line	458	loadk        r26   k91 ; k91 = 252
.line	458	loadk        r27   k57 ; k57 = 56
.line	458	call         r10    18     2
.line	458	move         r11    r8
.line	458	concat       r10   r10   r11
.line	458	call          r9     2     2
.line	458	test          r9     0
.line	458	jmp            0  l143
.line	458	gettable     r10    r9   k92 ; k92 = "StringMaxChar"
.line	458	test         r10     1
.line	458	jmp            0  l144
.label	l143
.line	458	loadk        r10   k93 ; k93 = 0
.label	l144
.line	458	lt             0   k93   r10 ; k93 = 0
.line	458	jmp            0  l167
.line	458	gettable     r11    r9   k94 ; k94 = "ExtraUIConfig"
.line	458	test         r11     0
.line	458	jmp            0  l153
.line	458	gettable     r11    r9   k94 ; k94 = "ExtraUIConfig"
.line	458	gettable     r11   r11   k95 ; k95 = "bUseUtf8Length"
.line	458	test         r11     1
.line	458	jmp            0  l154
.label	l153
.line	458	loadbool     r11     0     0
.label	l154
.line	458	len          r12    r3
.line	458	add          r12   r12   k96 ; k96 = 1
.line	458	newtable     r13     0     3
.line	458	settable     r13   k97    r8 ; k97 = "FieldKey"
.line	458	settable     r13   k92   r10 ; k92 = "StringMaxChar"
.line	458	test         r11     0
.line	458	jmp            0  l164
.line	458	loadk        r14   k99 ; k99 = 2
.line	458	test         r14     1
.line	458	jmp            0  l165
.label	l164
.line	458	loadk        r14   k96 ; k96 = 1
.label	l165
.line	458	settable     r13   k98   r14 ; k98 = "OverrideCharBytes"
.line	458	settable      r3   r12   r13
.label	l167
.line	458	move          r0    r0
.line	458	move          r0    r0
.line	458	len           r4    r3
.line	458	eq             0    r4   k93 ; k93 = 0
.line	458	jmp            0  l173
.line	458	return        r0     1
.label	l173
.line	458	gettabup      r4    u0   k78 ; k78 = "ipairs"
.line	458	move          r5    r1
.line	458	call          r4     2     4
.line	458	jmp            0  l331
.line	458	gettabup      r9    u0    k0 ; k0 = "type"
.line	458	move         r10    r8
.line	458	call          r9     2     2
.line	458	getupval     r10    u1
.line	458	loadk        r11    k1 ; k1 = 146
.line	458	loadk        r12    k2 ; k2 = 116
.line	458	loadk        r13    k3 ; k3 = 75
.line	458	loadk        r14    k4 ; k4 = 24
.line	458	loadk        r15    k5 ; k5 = 121
.line	458	call         r10     6     2
.line	458	eq             0    r9   r10
.line	458	jmp            0  l331
.line	458	gettabup      r9    u0   k78 ; k78 = "ipairs"
.line	458	move         r10    r3
.line	458	call          r9     2     4
.line	458	jmp            0  l329
.line	458	gettable     r14   r13   k97 ; k97 = "FieldKey"
.line	458	gettable     r14    r8   r14
.line	458	gettabup     r15    u0    k0 ; k0 = "type"
.line	458	move         r16   r14
.line	458	call         r15     2     2
.line	458	getupval     r16    u1
.line	458	loadk        r17   k64 ; k64 = 149
.line	458	loadk        r18  k100 ; k100 = 97
.line	458	loadk        r19   k82 ; k82 = 91
.line	458	loadk        r20  k101 ; k101 = 29
.line	458	loadk        r21  k102 ; k102 = 114
.line	458	loadk        r22   k63 ; k63 = 241
.line	458	call         r16     7     2
.line	458	eq             0   r15   r16
.line	458	jmp            0  l329
.line	458	getupval     r15    u1
.line	458	call         r15     1     2
.line	458	eq             1   r14   r15
.line	458	jmp            0  l329
.line	458	getupval     r15    u3
.line	458	move         r16   r14
.line	458	gettable     r17   r13   k92 ; k92 = "StringMaxChar"
.line	458	gettable     r18   r13   k98 ; k98 = "OverrideCharBytes"
.line	458	call         r15     4     2
.line	458	eq             1   r15   r14
.line	458	jmp            0  l329
.line	458	gettable     r16   r13   k97 ; k97 = "FieldKey"
.line	458	settable      r8   r16   r15
.line	458	gettabup     r16    u0  k103 ; k103 = "print"
.line	458	gettabup     r17    u0  k104 ; k104 = "bWriteLog"
.line	458	test         r17     0
.line	458	jmp            0  l328
.line	458	gettabup     r17    u0  k105 ; k105 = "string"
.line	458	gettable     r17   r17  k106 ; k106 = "format"
.line	458	gettabup     r18    u0    k7 ; k7 = "table"
.line	458	gettable     r18   r18    k8 ; k8 = "concat"
.line	458	newtable     r19     2     0
.line	458	getupval     r20    u1
.line	458	loadk        r21   k80 ; k80 = 177
.line	458	loadk        r22   k81 ; k81 = 122
.line	458	loadk        r23  k107 ; k107 = 126
.line	458	loadk        r24   k61 ; k61 = 49
.line	458	loadk        r25  k108 ; k108 = 120
.line	458	loadk        r26  k109 ; k109 = 255
.line	458	loadk        r27   k90 ; k90 = 205
.line	458	loadk        r28  k110 ; k110 = 35
.line	458	loadk        r29  k111 ; k111 = 175
.line	458	loadk        r30   k31 ; k31 = 19
.line	458	loadk        r31  k112 ; k112 = 235
.line	458	loadk        r32   k42 ; k42 = 176
.line	458	loadk        r33  k113 ; k113 = 251
.line	458	loadk        r34  k114 ; k114 = 219
.line	458	loadk        r35  k115 ; k115 = 223
.line	458	loadk        r36  k109 ; k109 = 255
.line	458	loadk        r37   k76 ; k76 = 115
.line	458	loadk        r38  k116 ; k116 = 81
.line	458	loadk        r39   k40 ; k40 = 10
.line	458	loadk        r40   k61 ; k61 = 49
.line	458	loadk        r41  k117 ; k117 = 142
.line	458	loadk        r42  k112 ; k112 = 235
.line	458	loadk        r43   k27 ; k27 = 174
.line	458	loadk        r44  k118 ; k118 = 14
.line	458	loadk        r45  k119 ; k119 = 247
.line	458	loadk        r46  k120 ; k120 = 23
.line	458	loadk        r47   k88 ; k88 = 248
.line	458	loadk        r48  k121 ; k121 = 179
.line	458	loadk        r49   k23 ; k23 = 237
.line	458	loadk        r50   k35 ; k35 = 250
.line	458	loadk        r51  k112 ; k112 = 235
.line	458	loadk        r52  k122 ; k122 = 243
.line	458	loadk        r53    k2 ; k2 = 116
.line	458	loadk        r54  k123 ; k123 = 94
.line	458	loadk        r55  k124 ; k124 = 8
.line	458	loadk        r56  k125 ; k125 = 39
.line	458	loadk        r57  k126 ; k126 = 143
.line	458	loadk        r58   k20 ; k20 = 211
.line	458	loadk        r59  k127 ; k127 = 173
.line	458	loadk        r60  k128 ; k128 = 63
.line	458	call         r20    41     2
.line	458	getupval     r21    u1
.line	458	loadk        r22    k1 ; k1 = 146
.line	458	loadk        r23   k68 ; k68 = 103
.line	458	loadk        r24   k56 ; k56 = 64
.line	458	loadk        r25  k129 ; k129 = 26
.line	458	loadk        r26  k130 ; k130 = 123
.line	458	loadk        r27   k36 ; k36 = 208
.line	458	loadk        r28   k36 ; k36 = 208
.line	458	loadk        r29   k50 ; k50 = 41
.line	458	loadk        r30   k80 ; k80 = 177
.line	458	loadk        r31  k131 ; k131 = 32
.line	458	loadk        r32  k119 ; k119 = 247
.line	458	loadk        r33  k132 ; k132 = 226
.line	458	loadk        r34  k133 ; k133 = 228
.line	458	loadk        r35   k21 ; k21 = 232
.line	458	loadk        r36   k66 ; k66 = 217
.line	458	loadk        r37  k132 ; k132 = 226
.line	458	loadk        r38  k134 ; k134 = 117
.line	458	loadk        r39   k10 ; k10 = 68
.line	458	loadk        r40  k135 ; k135 = 45
.line	458	loadk        r41   k26 ; k26 = 33
.line	458	loadk        r42   k67 ; k67 = 204
.line	458	loadk        r43  k136 ; k136 = 131
.line	458	loadk        r44   k29 ; k29 = 186
.line	458	loadk        r45  k137 ; k137 = 92
.line	458	loadk        r46  k138 ; k138 = 140
.line	458	loadk        r47  k125 ; k125 = 39
.line	458	loadk        r48   k65 ; k65 = 231
.line	458	loadk        r49  k139 ; k139 = 183
.line	458	loadk        r50  k140 ; k140 = 244
.line	458	loadk        r51  k115 ; k115 = 223
.line	458	loadk        r52   k32 ; k32 = 245
.line	458	loadk        r53   k14 ; k14 = 216
.line	458	loadk        r54  k141 ; k141 = 60
.line	458	loadk        r55  k142 ; k142 = 16
.line	458	loadk        r56  k143 ; k143 = 58
.line	458	loadk        r57    k2 ; k2 = 116
.line	458	loadk        r58  k144 ; k144 = 145
.line	458	loadk        r59   k89 ; k89 = 215
.line	458	loadk        r60    k9 ; k9 = 161
.line	458	loadk        r61  k145 ; k145 = 86
.line	458	call         r21    41     2
.line	458	getupval     r22    u1
.line	458	loadk        r23  k146 ; k146 = 195
.line	458	loadk        r24  k147 ; k147 = 102
.line	458	call         r22     3     0
.line	458	setlist      r19     0     1
.line	458	call         r18     2     2
.line	458	gettable     r19   r13   k97 ; k97 = "FieldKey"
.line	458	gettabup     r20    u0  k148 ; k148 = "tostring"
.line	458	gettable     r21    r8  k149 ; k149 = "AssetUID"
.line	458	call         r20     2     2
.line	458	gettabup     r21    u0  k148 ; k148 = "tostring"
.line	458	gettable     r22   r13   k92 ; k92 = "StringMaxChar"
.line	458	call         r21     2     0
.line	458	call         r17     0     2
.label	l328
.line	458	call         r16     2     1
.label	l329
.line	458	move          r0    r0
.line	458	move          r0    r0
.label	l331
.line	458	move          r0    r0
.line	458	move          r0    r0
.line	458	return        r0     1
.line	458	move          r0    r0
.line	458	move          r0    r0
.line	458	move          r0    r0
.line	458	move          r0    r0
.line	458	return        r0     1

.function	main/f15

.source	null
.linedefined	496
.lastlinedefined	507
.numparams	1
.is_vararg	0
.maxstacksize	13

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	22	true

.constant	k0	"type"
.constant	k1	146
.constant	k2	116
.constant	k3	75
.constant	k4	24
.constant	k5	121
.constant	k6	"pairs"
.constant	k7	"ipairs"

.line	496	gettabup      r1    u0    k0 ; k0 = "type"
.line	496	move          r2    r0
.line	496	call          r1     2     2
.line	496	getupval      r2    u1
.line	496	loadk         r3    k1 ; k1 = 146
.line	496	loadk         r4    k2 ; k2 = 116
.line	496	loadk         r5    k3 ; k3 = 75
.line	496	loadk         r6    k4 ; k4 = 24
.line	496	loadk         r7    k5 ; k5 = 121
.line	496	call          r2     6     2
.line	496	eq             1    r1    r2
.line	496	jmp            0   l14
.line	496	return        r0     1
.label	l14
.line	496	gettabup      r1    u0    k6 ; k6 = "pairs"
.line	496	move          r2    r0
.line	496	call          r1     2     4
.line	496	jmp            0   l39
.line	496	gettabup      r6    u0    k0 ; k0 = "type"
.line	496	move          r7    r5
.line	496	call          r6     2     2
.line	496	getupval      r7    u1
.line	496	loadk         r8    k1 ; k1 = 146
.line	496	loadk         r9    k2 ; k2 = 116
.line	496	loadk        r10    k3 ; k3 = 75
.line	496	loadk        r11    k4 ; k4 = 24
.line	496	loadk        r12    k5 ; k5 = 121
.line	496	call          r7     6     2
.line	496	eq             0    r6    r7
.line	496	jmp            0   l39
.line	496	gettabup      r6    u0    k7 ; k7 = "ipairs"
.line	496	getupval      r7    u2
.line	496	call          r6     2     4
.line	496	jmp            0   l37
.line	496	getupval     r11    u1
.line	496	call         r11     1     2
.line	496	settable      r5   r10   r11
.label	l37
.line	496	move          r0    r0
.line	496	move          r0    r0
.label	l39
.line	496	move          r0    r0
.line	496	move          r0    r0
.line	496	return        r0     1
.line	496	move          r0    r0
.line	496	move          r0    r0
.line	496	move          r0    r0
.line	496	move          r0    r0
.line	496	return        r0     1

.function	main/f16

.source	null
.linedefined	509
.lastlinedefined	516
.numparams	1
.is_vararg	0
.maxstacksize	22

.upvalue	"_ENV"	0	false
.upvalue	"U1"	23	true
.upvalue	"U2"	1	true

.constant	k0	"DeepCopy"
.constant	k1	"AssetPathMap"
.constant	k2	"slua_GameFrontendHUD"
.constant	k3	"GetPlayerController"
.constant	k4	"slua"
.constant	k5	"isValid"
.constant	k6	"CreativeModeBinaryDataEditFeature"
.constant	k7	"SetOneGameParameters"
.constant	k8	177
.constant	k9	122
.constant	k10	91
.constant	k11	31
.constant	k12	93
.constant	k13	229
.constant	k14	202
.constant	k15	41
.constant	k16	169
.constant	k17	20
.constant	k18	182
.constant	k19	248
.constant	k20	215
.constant	k21	205
.constant	k22	252

.line	509	gettabup      r1    u0    k0 ; k0 = "DeepCopy"
.line	509	gettable      r2    r0    k1 ; k1 = "AssetPathMap"
.line	509	test          r2     1
.line	509	jmp            0    l6
.line	509	newtable      r2     0     0
.label	l6
.line	509	call          r1     2     2
.line	509	getupval      r2    u1
.line	509	move          r3    r1
.line	509	call          r2     2     1
.line	509	gettabup      r2    u0    k2 ; k2 = "slua_GameFrontendHUD"
.line	509	self          r2    r2    k3 ; k3 = "GetPlayerController"
.line	509	call          r2     2     2
.line	509	gettabup      r3    u0    k4 ; k4 = "slua"
.line	509	gettable      r3    r3    k5 ; k5 = "isValid"
.line	509	move          r4    r2
.line	509	call          r3     2     2
.line	509	test          r3     0
.line	509	jmp            0   l43
.line	509	gettable      r3    r2    k6 ; k6 = "CreativeModeBinaryDa" (truncated)
.line	509	self          r3    r3    k7 ; k7 = "SetOneGameParameters"
.line	509	getupval      r5    u2
.line	509	loadk         r6    k8 ; k8 = 177
.line	509	loadk         r7    k9 ; k9 = 122
.line	509	loadk         r8   k10 ; k10 = 91
.line	509	loadk         r9   k11 ; k11 = 31
.line	509	loadk        r10   k12 ; k12 = 93
.line	509	loadk        r11   k13 ; k13 = 229
.line	509	loadk        r12   k14 ; k14 = 202
.line	509	loadk        r13   k15 ; k15 = 41
.line	509	loadk        r14   k16 ; k16 = 169
.line	509	loadk        r15   k17 ; k17 = 20
.line	509	loadk        r16   k13 ; k13 = 229
.line	509	loadk        r17   k18 ; k18 = 182
.line	509	loadk        r18   k19 ; k19 = 248
.line	509	loadk        r19   k20 ; k20 = 215
.line	509	loadk        r20   k21 ; k21 = 205
.line	509	loadk        r21   k22 ; k22 = 252
.line	509	call          r5    17     2
.line	509	move          r6    r1
.line	509	loadnil       r7     1
.line	509	loadbool      r9     0     0
.line	509	call          r3     7     1
.label	l43
.line	509	return        r0     1
.line	509	move          r0    r0
.line	509	return        r0     1

.function	main/f17

.source	null
.linedefined	518
.lastlinedefined	526
.numparams	2
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	15	true
.upvalue	"U1"	0	false

.constant	k0	"AssetType"
.constant	k1	"Actor"
.constant	k2	"Effect"
.constant	k3	"UMG"
.constant	k4	"_G"
.constant	k5	"EnableUMGInfoManager"

.line	518	gettable      r2    r1    k0 ; k0 = "AssetType"
.line	518	gettabup      r3    u0    k1 ; k1 = "Actor"
.line	518	eq             1    r2    r3
.line	518	jmp            0    l9
.line	518	gettable      r2    r1    k0 ; k0 = "AssetType"
.line	518	gettabup      r3    u0    k2 ; k2 = "Effect"
.line	518	eq             0    r2    r3
.line	518	jmp            0   l11
.label	l9
.line	518	loadbool      r2     1     0
.line	518	return        r2     2
.label	l11
.line	518	gettable      r2    r1    k0 ; k0 = "AssetType"
.line	518	gettabup      r3    u0    k3 ; k3 = "UMG"
.line	518	eq             0    r2    r3
.line	518	jmp            0   l21
.line	518	gettabup      r2    u1    k4 ; k4 = "_G"
.line	518	gettable      r2    r2    k5 ; k5 = "EnableUMGInfoManager"
.line	518	test          r2     0
.line	518	jmp            0   l21
.line	518	loadbool      r2     1     0
.line	518	return        r2     2
.label	l21
.line	518	loadbool      r2     0     0
.line	518	return        r2     2
.line	518	return        r0     1
.line	518	move          r0    r0
.line	518	move          r0    r0
.line	518	move          r0    r0
.line	518	move          r0    r0
.line	518	return        r0     1

.function	main/f18

.source	null
.linedefined	528
.lastlinedefined	559
.numparams	1
.is_vararg	0
.maxstacksize	57

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true

.constant	k0	"type"
.constant	k1	"AssetPathMap"
.constant	k2	146
.constant	k3	116
.constant	k4	75
.constant	k5	24
.constant	k6	121
.constant	k7	"_WorkAssetMetaMissLogged"
.constant	k8	"ipairs"
.constant	k9	"_IsLocalWorkAsset"
.constant	k10	"tonumber"
.constant	k11	"AssetUID"
.constant	k12	"GetMetaInfoByAssetId"
.constant	k13	"Meta"
.constant	k14	"Name"
.constant	k15	"Pic_Url"
.constant	k16	"Desc"
.constant	k17	"AssetName"
.constant	k18	"Icon"
.constant	k19	"tostring"
.constant	k20	true
.constant	k21	"print"
.constant	k22	"bWriteLog"
.constant	k23	"string"
.constant	k24	"format"
.constant	k25	"table"
.constant	k26	"concat"
.constant	k27	177
.constant	k28	122
.constant	k29	126
.constant	k30	49
.constant	k31	120
.constant	k32	255
.constant	k33	205
.constant	k34	35
.constant	k35	175
.constant	k36	19
.constant	k37	235
.constant	k38	176
.constant	k39	251
.constant	k40	219
.constant	k41	223
.constant	k42	115
.constant	k43	81
.constant	k44	10
.constant	k45	142
.constant	k46	174
.constant	k47	14
.constant	k48	247
.constant	k49	18
.constant	k50	253
.constant	k51	190
.constant	k52	236
.constant	k53	221
.constant	k54	211
.constant	k55	238
.constant	k56	109
.constant	k57	58
.constant	k58	39
.constant	k59	153
.constant	k60	194
.constant	k61	157
.constant	k62	5
.constant	k63	149
.constant	k64	101
.constant	k65	69
.constant	k66	21
.constant	k67	208
.constant	k68	203
.constant	k69	22
.constant	k70	225
.constant	k71	239
.constant	k72	222
.constant	k73	102
.constant	k74	60
.constant	k75	42
.constant	k76	152
.constant	k77	195
.constant	k78	187
.constant	k79	92
.constant	k80	160
.constant	k81	224
.constant	k82	179
.constant	k83	231
.constant	k84	213
.constant	k85	117
.constant	k86	51
.constant	k87	220
.constant	k88	170
.constant	k89	31
.constant	k90	131
.constant	k91	97
.constant	k92	124
.constant	k93	61
.constant	k94	88
.constant	k95	172
.constant	k96	156
.constant	k97	63
.constant	k98	245
.constant	k99	248
.constant	k100	64
.constant	k101	99
.constant	k102	159
.constant	k103	"AssetType"

.line	528	gettabup      r1    u0    k0 ; k0 = "type"
.line	528	gettable      r2    r0    k1 ; k1 = "AssetPathMap"
.line	528	call          r1     2     2
.line	528	getupval      r2    u1
.line	528	loadk         r3    k2 ; k2 = 146
.line	528	loadk         r4    k3 ; k3 = 116
.line	528	loadk         r5    k4 ; k4 = 75
.line	528	loadk         r6    k5 ; k5 = 24
.line	528	loadk         r7    k6 ; k6 = 121
.line	528	call          r2     6     2
.line	528	eq             1    r1    r2
.line	528	jmp            0   l15
.line	528	loadbool      r1     0     0
.line	528	return        r1     2
.label	l15
.line	528	loadbool      r1     0     0
.line	528	gettable      r2    r0    k7 ; k7 = "_WorkAssetMetaMissLo" (truncated)
.line	528	test          r2     1
.line	528	jmp            0   l20
.line	528	newtable      r2     0     0
.label	l20
.line	528	settable      r0    k7    r2 ; k7 = "_WorkAssetMetaMissLo" (truncated)
.line	528	gettabup      r2    u0    k8 ; k8 = "ipairs"
.line	528	gettable      r3    r0    k1 ; k1 = "AssetPathMap"
.line	528	call          r2     2     4
.line	528	jmp            0  l224
.line	528	gettabup      r7    u0    k0 ; k0 = "type"
.line	528	move          r8    r6
.line	528	call          r7     2     2
.line	528	getupval      r8    u1
.line	528	loadk         r9    k2 ; k2 = 146
.line	528	loadk        r10    k3 ; k3 = 116
.line	528	loadk        r11    k4 ; k4 = 75
.line	528	loadk        r12    k5 ; k5 = 24
.line	528	loadk        r13    k6 ; k6 = 121
.line	528	call          r8     6     2
.line	528	eq             0    r7    r8
.line	528	jmp            0  l224
.line	528	self          r7    r0    k9 ; k9 = "_IsLocalWorkAsset"
.line	528	move          r9    r6
.line	528	call          r7     3     2
.line	528	test          r7     1
.line	528	jmp            0  l224
.line	528	gettabup      r7    u0   k10 ; k10 = "tonumber"
.line	528	gettable      r8    r6   k11 ; k11 = "AssetUID"
.line	528	call          r7     2     2
.line	528	test          r7     0
.line	528	jmp            0   l53
.line	528	getupval      r8    u2
.line	528	self          r8    r8   k12 ; k12 = "GetMetaInfoByAssetId"
.line	528	move         r10    r7
.line	528	call          r8     3     2
.line	528	test          r8     1
.line	528	jmp            0   l54
.label	l53
.line	528	loadnil       r8     0
.label	l54
.line	528	test          r8     0
.line	528	jmp            0   l59
.line	528	gettable      r9    r8   k13 ; k13 = "Meta"
.line	528	test          r9     1
.line	528	jmp            0   l60
.label	l59
.line	528	loadnil       r9     0
.label	l60
.line	528	test          r9     0
.line	528	jmp            0   l91
.line	528	gettable     r10    r9   k14 ; k14 = "Name"
.line	528	test         r10     1
.line	528	jmp            0   l67
.line	528	getupval     r10    u1
.line	528	call         r10     1     2
.label	l67
.line	528	gettable     r11    r9   k15 ; k15 = "Pic_Url"
.line	528	test         r11     1
.line	528	jmp            0   l72
.line	528	getupval     r11    u1
.line	528	call         r11     1     2
.label	l72
.line	528	gettable     r12    r9   k16 ; k16 = "Desc"
.line	528	test         r12     1
.line	528	jmp            0   l77
.line	528	getupval     r12    u1
.line	528	call         r12     1     2
.label	l77
.line	528	gettable     r13    r6   k17 ; k17 = "AssetName"
.line	528	eq             0   r13   r10
.line	528	jmp            0   l86
.line	528	gettable     r13    r6   k18 ; k18 = "Icon"
.line	528	eq             0   r13   r11
.line	528	jmp            0   l86
.line	528	gettable     r13    r6   k16 ; k16 = "Desc"
.line	528	eq             1   r13   r12
.line	528	jmp            0  l224
.label	l86
.line	528	settable      r6   k17   r10 ; k17 = "AssetName"
.line	528	settable      r6   k18   r11 ; k18 = "Icon"
.line	528	settable      r6   k16   r12 ; k16 = "Desc"
.line	528	loadbool      r1     1     0
.line	528	jmp            0  l224
.label	l91
.line	528	gettabup     r10    u0   k19 ; k19 = "tostring"
.line	528	gettable     r11    r6   k11 ; k11 = "AssetUID"
.line	528	call         r10     2     2
.line	528	gettable     r11    r0    k7 ; k7 = "_WorkAssetMetaMissLo" (truncated)
.line	528	gettable     r11   r11   r10
.line	528	test         r11     1
.line	528	jmp            0  l224
.line	528	gettable     r11    r0    k7 ; k7 = "_WorkAssetMetaMissLo" (truncated)
.line	528	settable     r11   r10   k20 ; k20 = true
.line	528	gettabup     r11    u0   k21 ; k21 = "print"
.line	528	gettabup     r12    u0   k22 ; k22 = "bWriteLog"
.line	528	test         r12     0
.line	528	jmp            0  l223
.line	528	gettabup     r12    u0   k23 ; k23 = "string"
.line	528	gettable     r12   r12   k24 ; k24 = "format"
.line	528	gettabup     r13    u0   k25 ; k25 = "table"
.line	528	gettable     r13   r13   k26 ; k26 = "concat"
.line	528	newtable     r14     2     0
.line	528	getupval     r15    u1
.line	528	loadk        r16   k27 ; k27 = 177
.line	528	loadk        r17   k28 ; k28 = 122
.line	528	loadk        r18   k29 ; k29 = 126
.line	528	loadk        r19   k30 ; k30 = 49
.line	528	loadk        r20   k31 ; k31 = 120
.line	528	loadk        r21   k32 ; k32 = 255
.line	528	loadk        r22   k33 ; k33 = 205
.line	528	loadk        r23   k34 ; k34 = 35
.line	528	loadk        r24   k35 ; k35 = 175
.line	528	loadk        r25   k36 ; k36 = 19
.line	528	loadk        r26   k37 ; k37 = 235
.line	528	loadk        r27   k38 ; k38 = 176
.line	528	loadk        r28   k39 ; k39 = 251
.line	528	loadk        r29   k40 ; k40 = 219
.line	528	loadk        r30   k41 ; k41 = 223
.line	528	loadk        r31   k32 ; k32 = 255
.line	528	loadk        r32   k42 ; k42 = 115
.line	528	loadk        r33   k43 ; k43 = 81
.line	528	loadk        r34   k44 ; k44 = 10
.line	528	loadk        r35   k30 ; k30 = 49
.line	528	loadk        r36   k45 ; k45 = 142
.line	528	loadk        r37   k37 ; k37 = 235
.line	528	loadk        r38   k46 ; k46 = 174
.line	528	loadk        r39   k47 ; k47 = 14
.line	528	loadk        r40   k48 ; k48 = 247
.line	528	loadk        r41   k49 ; k49 = 18
.line	528	loadk        r42   k50 ; k50 = 253
.line	528	loadk        r43   k51 ; k51 = 190
.line	528	loadk        r44   k52 ; k52 = 236
.line	528	loadk        r45   k53 ; k53 = 221
.line	528	loadk        r46   k54 ; k54 = 211
.line	528	loadk        r47   k55 ; k55 = 238
.line	528	loadk        r48   k56 ; k56 = 109
.line	528	loadk        r49    k3 ; k3 = 116
.line	528	loadk        r50   k57 ; k57 = 58
.line	528	loadk        r51   k58 ; k58 = 39
.line	528	loadk        r52   k59 ; k59 = 153
.line	528	loadk        r53   k60 ; k60 = 194
.line	528	loadk        r54   k61 ; k61 = 157
.line	528	loadk        r55   k62 ; k62 = 5
.line	528	call         r15    41     2
.line	528	getupval     r16    u1
.line	528	loadk        r17   k63 ; k63 = 149
.line	528	loadk        r18   k64 ; k64 = 101
.line	528	loadk        r19   k65 ; k65 = 69
.line	528	loadk        r20   k66 ; k66 = 21
.line	528	loadk        r21   k64 ; k64 = 101
.line	528	loadk        r22   k67 ; k67 = 208
.line	528	loadk        r23   k68 ; k68 = 203
.line	528	loadk        r24   k34 ; k34 = 35
.line	528	loadk        r25   k38 ; k38 = 176
.line	528	loadk        r26   k69 ; k69 = 22
.line	528	loadk        r27   k70 ; k70 = 225
.line	528	loadk        r28   k27 ; k27 = 177
.line	528	loadk        r29   k32 ; k32 = 255
.line	528	loadk        r30   k71 ; k71 = 239
.line	528	loadk        r31   k72 ; k72 = 222
.line	528	loadk        r32   k71 ; k71 = 239
.line	528	loadk        r33   k42 ; k42 = 115
.line	528	loadk        r34   k73 ; k73 = 102
.line	528	loadk        r35   k74 ; k74 = 60
.line	528	loadk        r36   k75 ; k75 = 42
.line	528	loadk        r37   k76 ; k76 = 152
.line	528	loadk        r38   k77 ; k77 = 195
.line	528	loadk        r39   k78 ; k78 = 187
.line	528	loadk        r40   k79 ; k79 = 92
.line	528	loadk        r41   k80 ; k80 = 160
.line	528	loadk        r42   k30 ; k30 = 49
.line	528	loadk        r43   k81 ; k81 = 224
.line	528	loadk        r44   k82 ; k82 = 179
.line	528	loadk        r45   k80 ; k80 = 160
.line	528	loadk        r46   k83 ; k83 = 231
.line	528	loadk        r47   k84 ; k84 = 213
.line	528	loadk        r48   k71 ; k71 = 239
.line	528	loadk        r49   k85 ; k85 = 117
.line	528	loadk        r50   k79 ; k79 = 92
.line	528	loadk        r51   k58 ; k58 = 39
.line	528	loadk        r52   k86 ; k86 = 51
.line	528	loadk        r53   k87 ; k87 = 220
.line	528	loadk        r54   k48 ; k48 = 247
.line	528	loadk        r55   k88 ; k88 = 170
.line	528	loadk        r56   k89 ; k89 = 31
.line	528	call         r16    41     2
.line	528	getupval     r17    u1
.line	528	loadk        r18   k90 ; k90 = 131
.line	528	loadk        r19   k91 ; k91 = 97
.line	528	loadk        r20   k92 ; k92 = 124
.line	528	loadk        r21   k93 ; k93 = 61
.line	528	loadk        r22   k94 ; k94 = 88
.line	528	loadk        r23   k95 ; k95 = 172
.line	528	loadk        r24   k96 ; k96 = 156
.line	528	loadk        r25   k97 ; k97 = 63
.line	528	loadk        r26   k50 ; k50 = 253
.line	528	loadk        r27   k62 ; k62 = 5
.line	528	loadk        r28   k48 ; k48 = 247
.line	528	loadk        r29   k27 ; k27 = 177
.line	528	loadk        r30   k98 ; k98 = 245
.line	528	loadk        r31   k55 ; k55 = 238
.line	528	loadk        r32   k99 ; k99 = 248
.line	528	loadk        r33   k98 ; k98 = 245
.line	528	loadk        r34   k73 ; k73 = 102
.line	528	loadk        r35  k100 ; k100 = 64
.line	528	loadk        r36  k101 ; k101 = 99
.line	528	loadk        r37   k91 ; k91 = 97
.line	528	loadk        r38  k102 ; k102 = 159
.line	528	call         r17    22     0
.line	528	setlist      r14     0     1
.line	528	call         r13     2     2
.line	528	move         r14   r10
.line	528	gettabup     r15    u0   k19 ; k19 = "tostring"
.line	528	gettable     r16    r6  k103 ; k103 = "AssetType"
.line	528	call         r15     2     0
.line	528	call         r12     0     2
.label	l223
.line	528	call         r11     2     1
.label	l224
.line	528	move          r0    r0
.line	528	move          r0    r0
.line	528	return        r1     2
.line	528	return        r0     1
.line	528	move          r0    r0
.line	528	move          r0    r0
.line	528	gettabup      r2    u0   k76 ; k76 = 152
.line	528	return        r0     1

.function	main/f19

.source	null
.linedefined	561
.lastlinedefined	564
.numparams	2
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	177
.constant	k5	122
.constant	k6	126
.constant	k7	49
.constant	k8	120
.constant	k9	255
.constant	k10	205
.constant	k11	35
.constant	k12	175
.constant	k13	19
.constant	k14	235
.constant	k15	176
.constant	k16	251
.constant	k17	219
.constant	k18	223
.constant	k19	115
.constant	k20	81
.constant	k21	10
.constant	k22	142
.constant	k23	174
.constant	k24	14
.constant	k25	247
.constant	k26	27
.constant	k27	250
.constant	k28	128
.constant	k29	229
.constant	k30	243
.constant	k31	116
.constant	k32	94
.constant	k33	8
.constant	k34	39
.constant	k35	143
.constant	k36	211
.constant	k37	173
.constant	k38	40
.constant	k39	135
.constant	k40	97
.constant	k41	72
.constant	k42	"SyncWorkAssetDataToEditor"

.line	561	gettabup      r2    u0    k0 ; k0 = "print"
.line	561	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	561	test          r3     0
.line	561	jmp            0   l57
.line	561	gettabup      r3    u0    k2 ; k2 = "table"
.line	561	gettable      r3    r3    k3 ; k3 = "concat"
.line	561	newtable      r4     1     0
.line	561	getupval      r5    u1
.line	561	loadk         r6    k4 ; k4 = 177
.line	561	loadk         r7    k5 ; k5 = 122
.line	561	loadk         r8    k6 ; k6 = 126
.line	561	loadk         r9    k7 ; k7 = 49
.line	561	loadk        r10    k8 ; k8 = 120
.line	561	loadk        r11    k9 ; k9 = 255
.line	561	loadk        r12   k10 ; k10 = 205
.line	561	loadk        r13   k11 ; k11 = 35
.line	561	loadk        r14   k12 ; k12 = 175
.line	561	loadk        r15   k13 ; k13 = 19
.line	561	loadk        r16   k14 ; k14 = 235
.line	561	loadk        r17   k15 ; k15 = 176
.line	561	loadk        r18   k16 ; k16 = 251
.line	561	loadk        r19   k17 ; k17 = 219
.line	561	loadk        r20   k18 ; k18 = 223
.line	561	loadk        r21    k9 ; k9 = 255
.line	561	loadk        r22   k19 ; k19 = 115
.line	561	loadk        r23   k20 ; k20 = 81
.line	561	loadk        r24   k21 ; k21 = 10
.line	561	loadk        r25    k7 ; k7 = 49
.line	561	loadk        r26   k22 ; k22 = 142
.line	561	loadk        r27   k14 ; k14 = 235
.line	561	loadk        r28   k23 ; k23 = 174
.line	561	loadk        r29   k24 ; k24 = 14
.line	561	loadk        r30   k25 ; k25 = 247
.line	561	loadk        r31   k26 ; k26 = 27
.line	561	loadk        r32   k27 ; k27 = 250
.line	561	loadk        r33   k28 ; k28 = 128
.line	561	loadk        r34   k29 ; k29 = 229
.line	561	loadk        r35   k16 ; k16 = 251
.line	561	loadk        r36   k14 ; k14 = 235
.line	561	loadk        r37   k30 ; k30 = 243
.line	561	loadk        r38   k31 ; k31 = 116
.line	561	loadk        r39   k32 ; k32 = 94
.line	561	loadk        r40   k33 ; k33 = 8
.line	561	loadk        r41   k34 ; k34 = 39
.line	561	loadk        r42   k35 ; k35 = 143
.line	561	loadk        r43   k36 ; k36 = 211
.line	561	loadk        r44   k37 ; k37 = 173
.line	561	loadk        r45   k38 ; k38 = 40
.line	561	call          r5    41     2
.line	561	getupval      r6    u1
.line	561	loadk         r7   k39 ; k39 = 135
.line	561	loadk         r8   k40 ; k40 = 97
.line	561	loadk         r9   k41 ; k41 = 72
.line	561	call          r6     4     0
.line	561	setlist       r4     0     1
.line	561	call          r3     2     2
.label	l57
.line	561	call          r2     2     1
.line	561	self          r2    r0   k42 ; k42 = "SyncWorkAssetDataToE" (truncated)
.line	561	call          r2     2     1
.line	561	return        r0     1
.line	561	move          r0    r0
.line	561	move          r0    r0
.line	561	move          r0    r0
.line	561	return        r0     1

.function	main/f20

.source	null
.linedefined	566
.lastlinedefined	569
.numparams	2
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	177
.constant	k5	122
.constant	k6	126
.constant	k7	49
.constant	k8	120
.constant	k9	255
.constant	k10	205
.constant	k11	35
.constant	k12	175
.constant	k13	19
.constant	k14	235
.constant	k15	176
.constant	k16	251
.constant	k17	219
.constant	k18	223
.constant	k19	115
.constant	k20	81
.constant	k21	10
.constant	k22	142
.constant	k23	174
.constant	k24	14
.constant	k25	247
.constant	k26	27
.constant	k27	250
.constant	k28	128
.constant	k29	229
.constant	k30	241
.constant	k31	86
.constant	k32	71
.constant	k33	44
.constant	k34	50
.constant	k35	157
.constant	k36	212
.constant	k37	148
.constant	k38	13
.constant	k39	138
.constant	k40	121
.constant	k41	100
.constant	k42	17
.constant	k43	104
.constant	k44	"SyncMyPrefabMallMetaToEditor"

.line	566	gettabup      r2    u0    k0 ; k0 = "print"
.line	566	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	566	test          r3     0
.line	566	jmp            0   l60
.line	566	gettabup      r3    u0    k2 ; k2 = "table"
.line	566	gettable      r3    r3    k3 ; k3 = "concat"
.line	566	newtable      r4     1     0
.line	566	getupval      r5    u1
.line	566	loadk         r6    k4 ; k4 = 177
.line	566	loadk         r7    k5 ; k5 = 122
.line	566	loadk         r8    k6 ; k6 = 126
.line	566	loadk         r9    k7 ; k7 = 49
.line	566	loadk        r10    k8 ; k8 = 120
.line	566	loadk        r11    k9 ; k9 = 255
.line	566	loadk        r12   k10 ; k10 = 205
.line	566	loadk        r13   k11 ; k11 = 35
.line	566	loadk        r14   k12 ; k12 = 175
.line	566	loadk        r15   k13 ; k13 = 19
.line	566	loadk        r16   k14 ; k14 = 235
.line	566	loadk        r17   k15 ; k15 = 176
.line	566	loadk        r18   k16 ; k16 = 251
.line	566	loadk        r19   k17 ; k17 = 219
.line	566	loadk        r20   k18 ; k18 = 223
.line	566	loadk        r21    k9 ; k9 = 255
.line	566	loadk        r22   k19 ; k19 = 115
.line	566	loadk        r23   k20 ; k20 = 81
.line	566	loadk        r24   k21 ; k21 = 10
.line	566	loadk        r25    k7 ; k7 = 49
.line	566	loadk        r26   k22 ; k22 = 142
.line	566	loadk        r27   k14 ; k14 = 235
.line	566	loadk        r28   k23 ; k23 = 174
.line	566	loadk        r29   k24 ; k24 = 14
.line	566	loadk        r30   k25 ; k25 = 247
.line	566	loadk        r31   k26 ; k26 = 27
.line	566	loadk        r32   k27 ; k27 = 250
.line	566	loadk        r33   k28 ; k28 = 128
.line	566	loadk        r34   k29 ; k29 = 229
.line	566	loadk        r35   k16 ; k16 = 251
.line	566	loadk        r36   k30 ; k30 = 241
.line	566	loadk        r37   k29 ; k29 = 229
.line	566	loadk        r38   k31 ; k31 = 86
.line	566	loadk        r39   k32 ; k32 = 71
.line	566	loadk        r40   k33 ; k33 = 44
.line	566	loadk        r41   k34 ; k34 = 50
.line	566	loadk        r42   k35 ; k35 = 157
.line	566	loadk        r43   k36 ; k36 = 212
.line	566	loadk        r44   k37 ; k37 = 148
.line	566	loadk        r45   k38 ; k38 = 13
.line	566	call          r5    41     2
.line	566	getupval      r6    u1
.line	566	loadk         r7   k39 ; k39 = 138
.line	566	loadk         r8   k40 ; k40 = 121
.line	566	loadk         r9   k41 ; k41 = 100
.line	566	loadk        r10   k42 ; k42 = 17
.line	566	loadk        r11   k43 ; k43 = 104
.line	566	loadk        r12   k25 ; k25 = 247
.line	566	call          r6     7     0
.line	566	setlist       r4     0     1
.line	566	call          r3     2     2
.label	l60
.line	566	call          r2     2     1
.line	566	self          r2    r0   k44 ; k44 = "SyncMyPrefabMallMeta" (truncated)
.line	566	call          r2     2     1
.line	566	return        r0     1
.line	566	move          r0    r0
.line	566	move          r0    r0
.line	566	move          r0    r0
.line	566	return        r0     1

.function	main/f21

.source	null
.linedefined	571
.lastlinedefined	581
.numparams	1
.is_vararg	0
.maxstacksize	36

.upvalue	"_ENV"	3	true
.upvalue	"U1"	1	true
.upvalue	"U2"	0	false
.upvalue	"U3"	4	true

.constant	k0	"CollectMyPrefabMallMeta"
.constant	k1	"encode"
.constant	k2	"MetaDataJson"
.constant	k3	162
.constant	k4	47
.constant	k5	6
.constant	k6	51
.constant	k7	46
.constant	k8	211
.constant	k9	230
.constant	k10	30
.constant	k11	174
.constant	k12	52
.constant	k13	201
.constant	k14	187
.constant	k15	192
.constant	k16	232
.constant	k17	234
.constant	k18	119
.constant	k19	71
.constant	k20	20
.constant	k21	37
.constant	k22	128
.constant	k23	202
.constant	k24	132
.constant	k25	25
.constant	k26	185
.constant	k27	53
.constant	k28	186
.constant	k29	184
.constant	k30	243
.constant	k31	229
.constant	k32	210
.constant	k33	"gsub"
.constant	k34	198
.constant	k35	"Client"
.constant	k36	"TestSaveStringToFile"
.constant	k37	"format"
.constant	k38	"SendMsgToEditor"
.constant	k39	"G2E"
.constant	k40	"G2E_RspMyPrefabMallMeta"

.line	571	self          r1    r0    k0 ; k0 = "CollectMyPrefabMallM" (truncated)
.line	571	call          r1     2     2
.line	571	gettabup      r2    u0    k1 ; k1 = "encode"
.line	571	testset       r3    r1     1
.line	571	jmp            0    l7
.line	571	newtable      r3     0     0
.label	l7
.line	571	call          r2     2     2
.line	571	newtable      r3     0     1
.line	571	settable      r3    k2    r2 ; k2 = "MetaDataJson"
.line	571	loadbool      r4     0     0
.line	571	test          r4     0
.line	571	jmp            0   l66
.line	571	getupval      r4    u1
.line	571	loadk         r5    k3 ; k3 = 162
.line	571	loadk         r6    k4 ; k4 = 47
.line	571	loadk         r7    k5 ; k5 = 6
.line	571	loadk         r8    k6 ; k6 = 51
.line	571	loadk         r9    k7 ; k7 = 46
.line	571	loadk        r10    k8 ; k8 = 211
.line	571	loadk        r11    k9 ; k9 = 230
.line	571	loadk        r12   k10 ; k10 = 30
.line	571	loadk        r13   k11 ; k11 = 174
.line	571	loadk        r14   k12 ; k12 = 52
.line	571	loadk        r15   k13 ; k13 = 201
.line	571	loadk        r16   k14 ; k14 = 187
.line	571	loadk        r17   k15 ; k15 = 192
.line	571	loadk        r18   k16 ; k16 = 232
.line	571	loadk        r19   k13 ; k13 = 201
.line	571	loadk        r20   k17 ; k17 = 234
.line	571	loadk        r21   k18 ; k18 = 119
.line	571	loadk        r22   k19 ; k19 = 71
.line	571	loadk        r23   k20 ; k20 = 20
.line	571	loadk        r24   k21 ; k21 = 37
.line	571	loadk        r25   k22 ; k22 = 128
.line	571	loadk        r26   k23 ; k23 = 202
.line	571	loadk        r27   k24 ; k24 = 132
.line	571	loadk        r28   k25 ; k25 = 25
.line	571	loadk        r29   k26 ; k26 = 185
.line	571	loadk        r30   k27 ; k27 = 53
.line	571	loadk        r31   k28 ; k28 = 186
.line	571	loadk        r32   k29 ; k29 = 184
.line	571	loadk        r33   k30 ; k30 = 243
.line	571	loadk        r34   k31 ; k31 = 229
.line	571	loadk        r35   k32 ; k32 = 210
.line	571	call          r4    32     2
.line	571	self          r5    r4   k33 ; k33 = "gsub"
.line	571	getupval      r7    u1
.line	571	loadk         r8   k34 ; k34 = 198
.line	571	call          r7     2     2
.line	571	getupval      r8    u1
.line	571	call          r8     1     2
.line	571	call          r5     4     2
.line	571	move          r4    r5
.line	571	gettabup      r5    u2   k35 ; k35 = "Client"
.line	571	gettable      r5    r5   k36 ; k36 = "TestSaveStringToFile"
.line	571	gettabup      r6    u0   k37 ; k37 = "format"
.line	571	gettable      r7    r3    k2 ; k2 = "MetaDataJson"
.line	571	call          r6     2     2
.line	571	getupval      r7    u1
.line	571	loadk         r8    k3 ; k3 = 162
.line	571	loadk         r9    k4 ; k4 = 47
.line	571	loadk        r10    k5 ; k5 = 6
.line	571	call          r7     4     2
.line	571	move          r8    r4
.line	571	call          r5     4     1
.label	l66
.line	571	self          r4    r0   k38 ; k38 = "SendMsgToEditor"
.line	571	gettabup      r6    u3   k39 ; k39 = "G2E"
.line	571	gettable      r6    r6   k40 ; k40 = "G2E_RspMyPrefabMallM" (truncated)
.line	571	move          r7    r3
.line	571	call          r4     4     1
.line	571	return        r0     1
.line	571	move          r0    r0
.line	571	move          r0    r0
.line	571	move          r0    r0
.line	571	move          r0    r0
.line	571	return        r0     1

.function	main/f22

.source	null
.linedefined	583
.lastlinedefined	619
.numparams	2
.is_vararg	0
.maxstacksize	25

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	18	true
.upvalue	"U3"	7	true
.upvalue	"U4"	8	true

.constant	k0	"CollectMyPrefabMallMeta"
.constant	k1	"pairs"
.constant	k2	"type"
.constant	k3	146
.constant	k4	116
.constant	k5	75
.constant	k6	24
.constant	k7	121
.constant	k8	"ACTOR"
.constant	k9	"EFFECT"
.constant	k10	"_G"
.constant	k11	"EnableUMGInfoManager"
.constant	k12	"CUSTOMUI"
.constant	k13	"ipairs"
.constant	k14	"AssetId"
.constant	k15	"GetFolderIDForAssetType"
.constant	k16	"IsAssetReady"
.constant	k17	"tonumber"
.constant	k18	"ImportingAssetMap"
.constant	k19	"AssetUID"
.constant	k20	"AssetName"
.constant	k21	"Name"
.constant	k22	"AssetType"
.constant	k23	"FolderID"
.constant	k24	"Icon"
.constant	k25	"Pic_Url"
.constant	k26	"Desc"
.constant	k27	"IsReady"

.line	583	test          r1     1
.line	583	jmp            0    l6
.line	583	self          r2    r0    k0 ; k0 = "CollectMyPrefabMallM" (truncated)
.line	583	call          r2     2     2
.line	583	move          r1    r2
.label	l6
.line	583	test          r1     1
.line	583	jmp            0   l10
.line	583	newtable      r2     0     0
.line	583	return        r2     2
.label	l10
.line	583	newtable      r2     0     0
.line	583	gettabup      r3    u0    k1 ; k1 = "pairs"
.line	583	move          r4    r1
.line	583	call          r3     2     4
.line	583	jmp            0  l126
.line	583	gettabup      r8    u0    k2 ; k2 = "type"
.line	583	move          r9    r7
.line	583	call          r8     2     2
.line	583	getupval      r9    u1
.line	583	loadk        r10    k3 ; k3 = 146
.line	583	loadk        r11    k4 ; k4 = 116
.line	583	loadk        r12    k5 ; k5 = 75
.line	583	loadk        r13    k6 ; k6 = 24
.line	583	loadk        r14    k7 ; k7 = 121
.line	583	call          r9     6     2
.line	583	eq             0    r8    r9
.line	583	jmp            0  l126
.line	583	gettabup      r8    u0    k1 ; k1 = "pairs"
.line	583	move          r9    r7
.line	583	call          r8     2     4
.line	583	jmp            0  l124
.line	583	gettabup     r13    u2   r11
.line	583	test         r13     0
.line	583	jmp            0  l124
.line	583	gettabup     r14    u0    k2 ; k2 = "type"
.line	583	move         r15   r12
.line	583	call         r14     2     2
.line	583	getupval     r15    u1
.line	583	loadk        r16    k3 ; k3 = 146
.line	583	loadk        r17    k4 ; k4 = 116
.line	583	loadk        r18    k5 ; k5 = 75
.line	583	loadk        r19    k6 ; k6 = 24
.line	583	loadk        r20    k7 ; k7 = 121
.line	583	call         r15     6     2
.line	583	eq             0   r14   r15
.line	583	jmp            0  l124
.line	583	gettabup     r14    u3    k8 ; k8 = "ACTOR"
.line	583	eq             1   r11   r14
.line	583	jmp            0  l124
.line	583	gettabup     r14    u3    k9 ; k9 = "EFFECT"
.line	583	eq             1   r11   r14
.line	583	jmp            0  l124
.line	583	gettabup     r14    u0   k10 ; k10 = "_G"
.line	583	gettable     r14   r14   k11 ; k11 = "EnableUMGInfoManager"
.line	583	test         r14     0
.line	583	jmp            0   l59
.line	583	gettabup     r14    u3   k12 ; k12 = "CUSTOMUI"
.line	583	eq             1   r11   r14
.line	583	jmp            0  l124
.label	l59
.line	583	gettabup     r14    u0   k13 ; k13 = "ipairs"
.line	583	move         r15   r12
.line	583	call         r14     2     4
.line	583	jmp            0  l122
.line	583	gettable     r19   r18   k14 ; k14 = "AssetId"
.line	583	test         r19     0
.line	583	jmp            0  l122
.line	583	getupval     r20    u1
.line	583	call         r20     1     2
.line	583	eq             1   r19   r20
.line	583	jmp            0  l122
.line	583	gettable     r20    r2   r19
.line	583	test         r20     1
.line	583	jmp            0  l122
.line	583	self         r20    r0   k15 ; k15 = "GetFolderIDForAssetT" (truncated)
.line	583	move         r22   r13
.line	583	call         r20     3     2
.line	583	getupval     r21    u4
.line	583	self         r21   r21   k16 ; k16 = "IsAssetReady"
.line	583	gettabup     r23    u0   k17 ; k17 = "tonumber"
.line	583	move         r24   r19
.line	583	call         r23     2     2
.line	583	loadbool     r24     1     0
.line	583	call         r21     4     2
.line	583	gettabup     r22    u0   k17 ; k17 = "tonumber"
.line	583	move         r23   r19
.line	583	call         r22     2     2
.line	583	test         r21     0
.line	583	jmp            0   l99
.line	583	test         r22     0
.line	583	jmp            0   l99
.line	583	gettable     r23    r0   k18 ; k18 = "ImportingAssetMap"
.line	583	test         r23     0
.line	583	jmp            0   l99
.line	583	gettable     r23    r0   k18 ; k18 = "ImportingAssetMap"
.line	583	gettable     r23   r23   r22
.line	583	test         r23     0
.line	583	jmp            0   l99
.line	583	gettable     r23    r0   k18 ; k18 = "ImportingAssetMap"
.line	583	gettable     r20   r23   r22
.label	l99
.line	583	newtable     r23     0     7
.line	583	settable     r23   k19   r19 ; k19 = "AssetUID"
.line	583	gettable     r24   r18   k21 ; k21 = "Name"
.line	583	test         r24     1
.line	583	jmp            0  l105
.line	583	move         r24   r19
.label	l105
.line	583	settable     r23   k20   r24 ; k20 = "AssetName"
.line	583	settable     r23   k22   r13 ; k22 = "AssetType"
.line	583	settable     r23   k23   r20 ; k23 = "FolderID"
.line	583	gettable     r24   r18   k25 ; k25 = "Pic_Url"
.line	583	test         r24     1
.line	583	jmp            0  l113
.line	583	getupval     r24    u1
.line	583	call         r24     1     2
.label	l113
.line	583	settable     r23   k24   r24 ; k24 = "Icon"
.line	583	gettable     r24   r18   k26 ; k26 = "Desc"
.line	583	test         r24     1
.line	583	jmp            0  l119
.line	583	getupval     r24    u1
.line	583	call         r24     1     2
.label	l119
.line	583	settable     r23   k26   r24 ; k26 = "Desc"
.line	583	settable     r23   k27   r21 ; k27 = "IsReady"
.line	583	settable      r2   r19   r23
.label	l122
.line	583	move          r0    r0
.line	583	move          r0    r0
.label	l124
.line	583	move          r0    r0
.line	583	move          r0    r0
.label	l126
.line	583	move          r0    r0
.line	583	move          r0    r0
.line	583	return        r2     2
.line	583	return        r0     1
.line	583	move          r0    r0
.line	583	move          r0    r0
.line	583	move          r0    r0
.line	583	return        r0     1

.function	main/f23

.source	null
.linedefined	621
.lastlinedefined	710
.numparams	7
.is_vararg	0
.maxstacksize	69

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	3	true
.upvalue	"U3"	4	true
.upvalue	"U4"	15	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	177
.constant	k5	122
.constant	k6	126
.constant	k7	49
.constant	k8	120
.constant	k9	255
.constant	k10	205
.constant	k11	35
.constant	k12	175
.constant	k13	19
.constant	k14	235
.constant	k15	176
.constant	k16	251
.constant	k17	219
.constant	k18	223
.constant	k19	115
.constant	k20	81
.constant	k21	10
.constant	k22	142
.constant	k23	174
.constant	k24	14
.constant	k25	247
.constant	k26	27
.constant	k27	250
.constant	k28	133
.constant	k29	239
.constant	k30	248
.constant	k31	215
.constant	k32	221
.constant	k33	117
.constant	k34	70
.constant	k35	44
.constant	k36	32
.constant	k37	184
.constant	k38	173
.constant	k39	13
.constant	k40	165
.constant	k41	125
.constant	k42	72
.constant	k43	26
.constant	k44	123
.constant	k45	243
.constant	k46	"ActorDataCompleted"
.constant	k47	"bInWorkAssetDataChanged"
.constant	k48	"bWorkAssetDataChangedPending"
.constant	k49	true
.constant	k50	"CollectMyPrefabMallMeta"
.constant	k51	108
.constant	k52	240
.constant	k53	100
.constant	k54	199
.constant	k55	252
.constant	k56	246
.constant	k57	201
.constant	k58	98
.constant	k59	104
.constant	k60	20
.constant	k61	158
.constant	k62	195
.constant	k63	29
.constant	k64	25
.constant	k65	245
.constant	k66	190
.constant	k67	236
.constant	k68	217
.constant	k69	232
.constant	k70	103
.constant	k71	21
.constant	k72	59
.constant	k73	136
.constant	k74	171
.constant	k75	2
.constant	k76	131
.constant	k77	113
.constant	k78	9
.constant	k79	false
.constant	k80	"encode"
.constant	k81	"SendMsgToEditor"
.constant	k82	"G2E"
.constant	k83	"G2E_RspMyPrefabMallMeta"
.constant	k84	"MetaDataJson"
.constant	k85	"SyncActorDataToAssetPathMap"
.constant	k86	"SyncEffectDataToAssetPathMap"
.constant	k87	"SyncUMGDataToAssetPathMap"
.constant	k88	"CollectAllLatestAssets"
.constant	k89	"DebugInfo"
.constant	k90	"pairs"
.constant	k91	"AssetName"
.constant	k92	156
.constant	k93	40
.constant	k94	241
.constant	k95	238
.constant	k96	42
.constant	k97	55
.constant	k98	137
.constant	k99	210
.constant	k100	186
.constant	k101	"AssetType"
.constant	k102	"FolderID"
.constant	k103	"tostring"
.constant	k104	"IsReady"
.constant	k105	"require"
.constant	k106	121
.constant	k107	64
.constant	k108	17
.constant	k109	114
.constant	k110	226
.constant	k111	151
.constant	k112	63
.constant	k113	229
.constant	k114	203
.constant	k115	11
.constant	k116	143
.constant	k117	153
.constant	k118	168
.constant	k119	50
.constant	k120	208
.constant	k121	38
.constant	k122	51
.constant	k123	149
.constant	k124	213
.constant	k125	140
.constant	k126	43
.constant	k127	69
.constant	k128	91
.constant	k129	1
.constant	k130	188
.constant	k131	146
.constant	k132	254
.constant	k133	90
.constant	k134	74
.constant	k135	56
.constant	k136	161
.constant	k137	193
.constant	k138	187
.constant	k139	"AssetPathMap"
.constant	k140	-1
.constant	k141	"Actor"
.constant	k142	"Effect"
.constant	k143	"_G"
.constant	k144	"EnableUMGInfoManager"
.constant	k145	"UMG"
.constant	k146	"tonumber"
.constant	k147	"AssetUID"
.constant	k148	"UnloadingAssetIds"
.constant	k149	"ImportingAssetMap"
.constant	k150	"bUnloading"
.constant	k151	"AssetId"
.constant	k152	"insert"
.constant	k153	"AddToPriorLoadSet"
.constant	k154	147
.constant	k155	33
.constant	k156	225
.constant	k157	166
.constant	k158	220
.constant	k159	227
.constant	k160	24
.constant	k161	159
.constant	k162	189
.constant	k163	15
.constant	k164	233
.constant	k165	230
.constant	k166	237
.constant	k167	101
.constant	k168	45
.constant	k169	"remove"
.constant	k170	0
.constant	k171	"OnReqImportWorkAsset"
.constant	k172	"Items"
.constant	k173	"IsAssetInPathMap"
.constant	k174	"Icon"
.constant	k175	"Desc"
.constant	k176	"GetAssetRestrictions"
.constant	k177	"ApplyAssetRestrictions"
.constant	k178	"FillWorkAssetDisplayFromResourceCenter"
.constant	k179	"SaveAssetPathMap"
.constant	k180	"SyncWorkAssetDataToEditor"
.constant	k181	"AddTimerOnce"

.line	621	gettabup      r7    u0    k0 ; k0 = "print"
.line	621	gettabup      r8    u0    k1 ; k1 = "bWriteLog"
.line	621	test          r8     0
.line	621	jmp            0   l61
.line	621	gettabup      r8    u0    k2 ; k2 = "table"
.line	621	gettable      r8    r8    k3 ; k3 = "concat"
.line	621	newtable      r9     1     0
.line	621	getupval     r10    u1
.line	621	loadk        r11    k4 ; k4 = 177
.line	621	loadk        r12    k5 ; k5 = 122
.line	621	loadk        r13    k6 ; k6 = 126
.line	621	loadk        r14    k7 ; k7 = 49
.line	621	loadk        r15    k8 ; k8 = 120
.line	621	loadk        r16    k9 ; k9 = 255
.line	621	loadk        r17   k10 ; k10 = 205
.line	621	loadk        r18   k11 ; k11 = 35
.line	621	loadk        r19   k12 ; k12 = 175
.line	621	loadk        r20   k13 ; k13 = 19
.line	621	loadk        r21   k14 ; k14 = 235
.line	621	loadk        r22   k15 ; k15 = 176
.line	621	loadk        r23   k16 ; k16 = 251
.line	621	loadk        r24   k17 ; k17 = 219
.line	621	loadk        r25   k18 ; k18 = 223
.line	621	loadk        r26    k9 ; k9 = 255
.line	621	loadk        r27   k19 ; k19 = 115
.line	621	loadk        r28   k20 ; k20 = 81
.line	621	loadk        r29   k21 ; k21 = 10
.line	621	loadk        r30    k7 ; k7 = 49
.line	621	loadk        r31   k22 ; k22 = 142
.line	621	loadk        r32   k14 ; k14 = 235
.line	621	loadk        r33   k23 ; k23 = 174
.line	621	loadk        r34   k24 ; k24 = 14
.line	621	loadk        r35   k25 ; k25 = 247
.line	621	loadk        r36   k26 ; k26 = 27
.line	621	loadk        r37   k27 ; k27 = 250
.line	621	loadk        r38   k28 ; k28 = 133
.line	621	loadk        r39   k29 ; k29 = 239
.line	621	loadk        r40   k30 ; k30 = 248
.line	621	loadk        r41   k31 ; k31 = 215
.line	621	loadk        r42   k32 ; k32 = 221
.line	621	loadk        r43   k33 ; k33 = 117
.line	621	loadk        r44   k34 ; k34 = 70
.line	621	loadk        r45   k35 ; k35 = 44
.line	621	loadk        r46   k36 ; k36 = 32
.line	621	loadk        r47   k37 ; k37 = 184
.line	621	loadk        r48   k31 ; k31 = 215
.line	621	loadk        r49   k38 ; k38 = 173
.line	621	loadk        r50   k39 ; k39 = 13
.line	621	call         r10    41     2
.line	621	getupval     r11    u1
.line	621	loadk        r12   k40 ; k40 = 165
.line	621	loadk        r13   k41 ; k41 = 125
.line	621	loadk        r14   k42 ; k42 = 72
.line	621	loadk        r15   k43 ; k43 = 26
.line	621	loadk        r16   k44 ; k44 = 123
.line	621	loadk        r17   k45 ; k45 = 243
.line	621	loadk        r18   k32 ; k32 = 221
.line	621	call         r11     8     0
.line	621	setlist       r9     0     1
.line	621	call          r8     2     2
.label	l61
.line	621	call          r7     2     1
.line	621	gettable      r7    r0   k46 ; k46 = "ActorDataCompleted"
.line	621	test          r7     1
.line	621	jmp            0   l66
.line	621	return        r0     1
.label	l66
.line	621	gettable      r7    r0   k47 ; k47 = "bInWorkAssetDataChan" (truncated)
.line	621	test          r7     0
.line	621	jmp            0   l71
.line	621	settable      r0   k48   k49 ; k49 = true
.line	621	return        r0     1
.label	l71
.line	621	settable      r0   k47   k49 ; k49 = true
.line	621	self          r7    r0   k50 ; k50 = "CollectMyPrefabMallM" (truncated)
.line	621	call          r7     2     2
.line	621	test          r7     1
.line	621	jmp            0  l180
.line	621	gettabup      r8    u0    k0 ; k0 = "print"
.line	621	gettabup      r9    u0    k1 ; k1 = "bWriteLog"
.line	621	test          r9     0
.line	621	jmp            0  l177
.line	621	gettabup      r9    u0    k2 ; k2 = "table"
.line	621	gettable      r9    r9    k3 ; k3 = "concat"
.line	621	newtable     r10     2     0
.line	621	getupval     r11    u1
.line	621	loadk        r12    k4 ; k4 = 177
.line	621	loadk        r13    k5 ; k5 = 122
.line	621	loadk        r14    k6 ; k6 = 126
.line	621	loadk        r15    k7 ; k7 = 49
.line	621	loadk        r16    k8 ; k8 = 120
.line	621	loadk        r17    k9 ; k9 = 255
.line	621	loadk        r18   k10 ; k10 = 205
.line	621	loadk        r19   k11 ; k11 = 35
.line	621	loadk        r20   k12 ; k12 = 175
.line	621	loadk        r21   k13 ; k13 = 19
.line	621	loadk        r22   k14 ; k14 = 235
.line	621	loadk        r23   k15 ; k15 = 176
.line	621	loadk        r24   k16 ; k16 = 251
.line	621	loadk        r25   k17 ; k17 = 219
.line	621	loadk        r26   k18 ; k18 = 223
.line	621	loadk        r27    k9 ; k9 = 255
.line	621	loadk        r28   k19 ; k19 = 115
.line	621	loadk        r29   k20 ; k20 = 81
.line	621	loadk        r30   k21 ; k21 = 10
.line	621	loadk        r31    k7 ; k7 = 49
.line	621	loadk        r32   k22 ; k22 = 142
.line	621	loadk        r33   k14 ; k14 = 235
.line	621	loadk        r34   k23 ; k23 = 174
.line	621	loadk        r35   k24 ; k24 = 14
.line	621	loadk        r36   k25 ; k25 = 247
.line	621	loadk        r37   k26 ; k26 = 27
.line	621	loadk        r38   k27 ; k27 = 250
.line	621	loadk        r39   k28 ; k28 = 133
.line	621	loadk        r40   k29 ; k29 = 239
.line	621	loadk        r41   k30 ; k30 = 248
.line	621	loadk        r42   k31 ; k31 = 215
.line	621	loadk        r43   k32 ; k32 = 221
.line	621	loadk        r44   k33 ; k33 = 117
.line	621	loadk        r45   k34 ; k34 = 70
.line	621	loadk        r46   k35 ; k35 = 44
.line	621	loadk        r47   k36 ; k36 = 32
.line	621	loadk        r48   k37 ; k37 = 184
.line	621	loadk        r49   k31 ; k31 = 215
.line	621	loadk        r50   k38 ; k38 = 173
.line	621	loadk        r51   k39 ; k39 = 13
.line	621	call         r11    41     2
.line	621	getupval     r12    u1
.line	621	loadk        r13   k40 ; k40 = 165
.line	621	loadk        r14   k41 ; k41 = 125
.line	621	loadk        r15   k42 ; k42 = 72
.line	621	loadk        r16   k43 ; k43 = 26
.line	621	loadk        r17   k44 ; k44 = 123
.line	621	loadk        r18   k45 ; k45 = 243
.line	621	loadk        r19   k32 ; k32 = 221
.line	621	loadk        r20   k51 ; k51 = 108
.line	621	loadk        r21   k52 ; k52 = 240
.line	621	loadk        r22   k53 ; k53 = 100
.line	621	loadk        r23   k54 ; k54 = 199
.line	621	loadk        r24   k38 ; k38 = 173
.line	621	loadk        r25   k55 ; k55 = 252
.line	621	loadk        r26   k56 ; k56 = 246
.line	621	loadk        r27   k57 ; k57 = 201
.line	621	loadk        r28   k29 ; k29 = 239
.line	621	loadk        r29   k58 ; k58 = 98
.line	621	loadk        r30   k59 ; k59 = 104
.line	621	loadk        r31   k36 ; k36 = 32
.line	621	loadk        r32   k60 ; k60 = 20
.line	621	loadk        r33   k61 ; k61 = 158
.line	621	loadk        r34   k62 ; k62 = 195
.line	621	loadk        r35   k12 ; k12 = 175
.line	621	loadk        r36   k63 ; k63 = 29
.line	621	loadk        r37   k12 ; k12 = 175
.line	621	loadk        r38   k64 ; k64 = 25
.line	621	loadk        r39   k65 ; k65 = 245
.line	621	loadk        r40   k66 ; k66 = 190
.line	621	loadk        r41   k67 ; k67 = 236
.line	621	loadk        r42   k54 ; k54 = 199
.line	621	loadk        r43   k68 ; k68 = 217
.line	621	loadk        r44   k69 ; k69 = 232
.line	621	loadk        r45   k70 ; k70 = 103
.line	621	loadk        r46   k71 ; k71 = 21
.line	621	loadk        r47   k72 ; k72 = 59
.line	621	loadk        r48    k7 ; k7 = 49
.line	621	loadk        r49   k73 ; k73 = 136
.line	621	loadk        r50   k62 ; k62 = 195
.line	621	loadk        r51   k74 ; k74 = 171
.line	621	loadk        r52   k75 ; k75 = 2
.line	621	call         r12    41     2
.line	621	getupval     r13    u1
.line	621	loadk        r14   k76 ; k76 = 131
.line	621	loadk        r15   k77 ; k77 = 113
.line	621	loadk        r16   k78 ; k78 = 9
.line	621	loadk        r17   k43 ; k43 = 26
.line	621	loadk        r18   k33 ; k33 = 117
.line	621	loadk        r19   k27 ; k27 = 250
.line	621	call         r13     7     0
.line	621	setlist      r10     0     1
.line	621	call          r9     2     2
.label	l177
.line	621	call          r8     2     1
.line	621	settable      r0   k47   k79 ; k79 = false
.line	621	return        r0     1
.label	l180
.line	621	gettabup      r8    u2   k80 ; k80 = "encode"
.line	621	testset       r9    r7     1
.line	621	jmp            0  l184
.line	621	newtable      r9     0     0
.label	l184
.line	621	call          r8     2     2
.line	621	self          r9    r0   k81 ; k81 = "SendMsgToEditor"
.line	621	gettabup     r11    u3   k82 ; k82 = "G2E"
.line	621	gettable     r11   r11   k83 ; k83 = "G2E_RspMyPrefabMallM" (truncated)
.line	621	newtable     r12     0     1
.line	621	settable     r12   k84    r8 ; k84 = "MetaDataJson"
.line	621	call          r9     4     1
.line	621	self          r9    r0   k85 ; k85 = "SyncActorDataToAsset" (truncated)
.line	621	call          r9     2     2
.line	621	self         r10    r0   k86 ; k86 = "SyncEffectDataToAsse" (truncated)
.line	621	call         r10     2     2
.line	621	test          r9     1
.line	621	jmp            0  l198
.line	621	move          r9   r10
.label	l198
.line	621	self         r11    r0   k87 ; k87 = "SyncUMGDataToAssetPa" (truncated)
.line	621	call         r11     2     2
.line	621	test          r9     1
.line	621	jmp            0  l203
.line	621	move          r9   r11
.label	l203
.line	621	self         r12    r0   k88 ; k88 = "CollectAllLatestAsse" (truncated)
.line	621	move         r14    r7
.line	621	call         r12     3     2
.line	621	newtable     r13     0     0
.line	621	settable      r0   k89   r13 ; k89 = "DebugInfo"
.line	621	gettabup     r13    u0   k90 ; k90 = "pairs"
.line	621	move         r14   r12
.line	621	call         r13     2     4
.line	621	jmp            0  l296
.line	621	gettable     r18    r0   k89 ; k89 = "DebugInfo"
.line	621	gettable     r19   r17   k91 ; k91 = "AssetName"
.line	621	settable     r18   r16   r19
.line	621	gettabup     r18    u0    k0 ; k0 = "print"
.line	621	gettabup     r19    u0    k2 ; k2 = "table"
.line	621	gettable     r19   r19    k3 ; k3 = "concat"
.line	621	newtable     r20     1     0
.line	621	getupval     r21    u1
.line	621	loadk        r22    k4 ; k4 = 177
.line	621	loadk        r23    k5 ; k5 = 122
.line	621	loadk        r24    k6 ; k6 = 126
.line	621	loadk        r25    k7 ; k7 = 49
.line	621	loadk        r26    k8 ; k8 = 120
.line	621	loadk        r27    k9 ; k9 = 255
.line	621	loadk        r28   k10 ; k10 = 205
.line	621	loadk        r29   k11 ; k11 = 35
.line	621	loadk        r30   k12 ; k12 = 175
.line	621	loadk        r31   k13 ; k13 = 19
.line	621	loadk        r32   k14 ; k14 = 235
.line	621	loadk        r33   k15 ; k15 = 176
.line	621	loadk        r34   k16 ; k16 = 251
.line	621	loadk        r35   k17 ; k17 = 219
.line	621	loadk        r36   k18 ; k18 = 223
.line	621	loadk        r37    k9 ; k9 = 255
.line	621	loadk        r38   k19 ; k19 = 115
.line	621	loadk        r39   k20 ; k20 = 81
.line	621	loadk        r40   k21 ; k21 = 10
.line	621	loadk        r41    k7 ; k7 = 49
.line	621	loadk        r42   k22 ; k22 = 142
.line	621	loadk        r43   k14 ; k14 = 235
.line	621	loadk        r44   k23 ; k23 = 174
.line	621	loadk        r45   k24 ; k24 = 14
.line	621	loadk        r46   k25 ; k25 = 247
.line	621	loadk        r47   k26 ; k26 = 27
.line	621	loadk        r48   k27 ; k27 = 250
.line	621	loadk        r49   k28 ; k28 = 133
.line	621	loadk        r50   k29 ; k29 = 239
.line	621	loadk        r51   k30 ; k30 = 248
.line	621	loadk        r52   k31 ; k31 = 215
.line	621	loadk        r53   k32 ; k32 = 221
.line	621	loadk        r54   k33 ; k33 = 117
.line	621	loadk        r55   k34 ; k34 = 70
.line	621	loadk        r56   k35 ; k35 = 44
.line	621	loadk        r57   k36 ; k36 = 32
.line	621	loadk        r58   k37 ; k37 = 184
.line	621	loadk        r59   k31 ; k31 = 215
.line	621	loadk        r60   k38 ; k38 = 173
.line	621	loadk        r61   k39 ; k39 = 13
.line	621	call         r21    41     2
.line	621	getupval     r22    u1
.line	621	loadk        r23   k40 ; k40 = 165
.line	621	loadk        r24   k41 ; k41 = 125
.line	621	loadk        r25   k42 ; k42 = 72
.line	621	loadk        r26   k43 ; k43 = 26
.line	621	loadk        r27   k44 ; k44 = 123
.line	621	loadk        r28   k45 ; k45 = 243
.line	621	loadk        r29   k32 ; k32 = 221
.line	621	loadk        r30   k51 ; k51 = 108
.line	621	loadk        r31   k92 ; k92 = 156
.line	621	loadk        r32   k93 ; k93 = 40
.line	621	loadk        r33   k69 ; k69 = 232
.line	621	loadk        r34   k22 ; k22 = 142
.line	621	loadk        r35   k94 ; k94 = 241
.line	621	loadk        r36   k95 ; k95 = 238
.line	621	loadk        r37   k57 ; k57 = 201
.line	621	loadk        r38    k9 ; k9 = 255
.line	621	loadk        r39   k58 ; k58 = 98
.line	621	loadk        r40   k53 ; k53 = 100
.line	621	loadk        r41   k96 ; k96 = 42
.line	621	loadk        r42   k97 ; k97 = 55
.line	621	loadk        r43   k98 ; k98 = 137
.line	621	loadk        r44   k99 ; k99 = 210
.line	621	loadk        r45  k100 ; k100 = 186
.line	621	call         r22    24     0
.line	621	setlist      r20     0     1
.line	621	call         r19     2     2
.line	621	move         r20   r16
.line	621	gettable     r21   r17  k101 ; k101 = "AssetType"
.line	621	gettable     r22   r17  k102 ; k102 = "FolderID"
.line	621	gettabup     r23    u0  k103 ; k103 = "tostring"
.line	621	gettable     r24   r17   k91 ; k91 = "AssetName"
.line	621	call         r23     2     2
.line	621	gettable     r24   r17  k104 ; k104 = "IsReady"
.line	621	call         r18     7     1
.label	l296
.line	621	move          r0    r0
.line	621	move          r0    r0
.line	621	loadbool     r13     0     0
.line	621	newtable     r14     0     0
.line	621	gettabup     r15    u0  k105 ; k105 = "require"
.line	621	gettabup     r16    u0    k2 ; k2 = "table"
.line	621	gettable     r16   r16    k3 ; k3 = "concat"
.line	621	newtable     r17     1     0
.line	621	getupval     r18    u1
.line	621	loadk        r19   k28 ; k28 = 133
.line	621	loadk        r20  k106 ; k106 = 121
.line	621	loadk        r21  k107 ; k107 = 64
.line	621	loadk        r22  k108 ; k108 = 17
.line	621	loadk        r23  k109 ; k109 = 114
.line	621	loadk        r24  k110 ; k110 = 226
.line	621	loadk        r25  k111 ; k111 = 151
.line	621	loadk        r26  k112 ; k112 = 63
.line	621	loadk        r27    k4 ; k4 = 177
.line	621	loadk        r28    k7 ; k7 = 49
.line	621	loadk        r29  k113 ; k113 = 229
.line	621	loadk        r30   k67 ; k67 = 236
.line	621	loadk        r31   k55 ; k55 = 252
.line	621	loadk        r32   k65 ; k65 = 245
.line	621	loadk        r33  k114 ; k114 = 203
.line	621	loadk        r34  k113 ; k113 = 229
.line	621	loadk        r35   k33 ; k33 = 117
.line	621	loadk        r36  k115 ; k115 = 11
.line	621	loadk        r37   k35 ; k35 = 44
.line	621	loadk        r38   k11 ; k11 = 35
.line	621	loadk        r39  k116 ; k116 = 143
.line	621	loadk        r40   k73 ; k73 = 136
.line	621	loadk        r41  k117 ; k117 = 153
.line	621	loadk        r42   k24 ; k24 = 14
.line	621	loadk        r43  k118 ; k118 = 168
.line	621	loadk        r44  k119 ; k119 = 50
.line	621	loadk        r45   k65 ; k65 = 245
.line	621	loadk        r46   k15 ; k15 = 176
.line	621	loadk        r47   k10 ; k10 = 205
.line	621	loadk        r48   k14 ; k14 = 235
.line	621	loadk        r49  k120 ; k120 = 208
.line	621	loadk        r50   k52 ; k52 = 240
.line	621	loadk        r51   k93 ; k93 = 40
.line	621	loadk        r52  k106 ; k106 = 121
.line	621	loadk        r53  k121 ; k121 = 38
.line	621	loadk        r54  k122 ; k122 = 51
.line	621	loadk        r55  k123 ; k123 = 149
.line	621	loadk        r56  k124 ; k124 = 213
.line	621	loadk        r57  k125 ; k125 = 140
.line	621	loadk        r58  k126 ; k126 = 43
.line	621	call         r18    41     2
.line	621	getupval     r19    u1
.line	621	loadk        r20   k40 ; k40 = 165
.line	621	loadk        r21  k127 ; k127 = 69
.line	621	loadk        r22  k128 ; k128 = 91
.line	621	loadk        r23  k108 ; k108 = 17
.line	621	loadk        r24    k5 ; k5 = 122
.line	621	loadk        r25   k25 ; k25 = 247
.line	621	loadk        r26   k17 ; k17 = 219
.line	621	loadk        r27  k129 ; k129 = 1
.line	621	loadk        r28  k130 ; k130 = 188
.line	621	loadk        r29   k93 ; k93 = 40
.line	621	loadk        r30   k69 ; k69 = 232
.line	621	loadk        r31  k131 ; k131 = 146
.line	621	loadk        r32  k110 ; k110 = 226
.line	621	loadk        r33   k45 ; k45 = 243
.line	621	loadk        r34   k62 ; k62 = 195
.line	621	loadk        r35  k132 ; k132 = 254
.line	621	loadk        r36  k133 ; k133 = 90
.line	621	loadk        r37  k134 ; k134 = 74
.line	621	loadk        r38  k135 ; k135 = 56
.line	621	loadk        r39   k36 ; k36 = 32
.line	621	loadk        r40  k136 ; k136 = 161
.line	621	loadk        r41  k137 ; k137 = 193
.line	621	loadk        r42  k138 ; k138 = 187
.line	621	call         r19    24     0
.line	621	setlist      r17     0     1
.line	621	call         r16     2     2
.line	621	call         r15     2     2
.line	621	gettable     r16    r0  k139 ; k139 = "AssetPathMap"
.line	621	len          r16   r16
.line	621	loadk        r17  k129 ; k129 = 1
.line	621	loadk        r18  k140 ; k140 = -1
.line	621	move          r0    r0
.line	621	gettable     r20    r0  k139 ; k139 = "AssetPathMap"
.line	621	gettable     r20   r20   r19
.line	621	gettable     r21   r20  k101 ; k101 = "AssetType"
.line	621	gettabup     r22    u4  k141 ; k141 = "Actor"
.line	621	eq             1   r21   r22
.line	621	jmp            0  l597
.line	621	gettable     r21   r20  k101 ; k101 = "AssetType"
.line	621	gettabup     r22    u4  k142 ; k142 = "Effect"
.line	621	eq             1   r21   r22
.line	621	jmp            0  l597
.line	621	gettabup     r21    u0  k143 ; k143 = "_G"
.line	621	gettable     r21   r21  k144 ; k144 = "EnableUMGInfoManager"
.line	621	test         r21     0
.line	621	jmp            0  l397
.line	621	gettable     r21   r20  k101 ; k101 = "AssetType"
.line	621	gettabup     r22    u4  k145 ; k145 = "UMG"
.line	621	eq             1   r21   r22
.line	621	jmp            0  l597
.label	l397
.line	621	gettabup     r21    u0  k146 ; k146 = "tonumber"
.line	621	gettable     r22   r20  k147 ; k147 = "AssetUID"
.line	621	call         r21     2     2
.line	621	gettable     r21   r12   r21
.line	621	test         r21     0
.line	621	jmp            0  l520
.line	621	gettable     r22    r0  k148 ; k148 = "UnloadingAssetIds"
.line	621	test         r22     0
.line	621	jmp            0  l411
.line	621	gettable     r22    r0  k148 ; k148 = "UnloadingAssetIds"
.line	621	gettabup     r23    u0  k103 ; k103 = "tostring"
.line	621	gettable     r24   r21  k147 ; k147 = "AssetUID"
.line	621	call         r23     2     2
.line	621	gettable     r22   r22   r23
.label	l411
.line	621	gettable     r23    r0  k149 ; k149 = "ImportingAssetMap"
.line	621	test         r23     0
.line	621	jmp            0  l419
.line	621	gettable     r23    r0  k149 ; k149 = "ImportingAssetMap"
.line	621	gettabup     r24    u0  k146 ; k146 = "tonumber"
.line	621	gettable     r25   r21  k147 ; k147 = "AssetUID"
.line	621	call         r24     2     2
.line	621	gettable     r23   r23   r24
.label	l419
.line	621	test         r22     1
.line	621	jmp            0  l597
.line	621	gettable     r24    r0  k150 ; k150 = "bUnloading"
.line	621	test         r24     1
.line	621	jmp            0  l597
.line	621	test         r23     1
.line	621	jmp            0  l597
.line	621	newtable     r24     0     2
.line	621	gettable     r25   r21  k147 ; k147 = "AssetUID"
.line	621	settable     r24  k151   r25 ; k151 = "AssetId"
.line	621	gettable     r25   r21  k102 ; k102 = "FolderID"
.line	621	settable     r24  k102   r25 ; k102 = "FolderID"
.line	621	gettabup     r25    u0    k2 ; k2 = "table"
.line	621	gettable     r25   r25  k152 ; k152 = "insert"
.line	621	move         r26   r14
.line	621	move         r27   r24
.line	621	call         r25     3     1
.line	621	self         r25   r15  k153 ; k153 = "AddToPriorLoadSet"
.line	621	gettabup     r27    u0  k146 ; k146 = "tonumber"
.line	621	gettable     r28   r21  k147 ; k147 = "AssetUID"
.line	621	call         r27     2     2
.line	621	loadbool     r28     1     0
.line	621	call         r25     4     1
.line	621	gettabup     r25    u0    k0 ; k0 = "print"
.line	621	gettabup     r26    u0    k2 ; k2 = "table"
.line	621	gettable     r26   r26    k3 ; k3 = "concat"
.line	621	newtable     r27     1     0
.line	621	getupval     r28    u1
.line	621	loadk        r29    k4 ; k4 = 177
.line	621	loadk        r30    k5 ; k5 = 122
.line	621	loadk        r31    k6 ; k6 = 126
.line	621	loadk        r32    k7 ; k7 = 49
.line	621	loadk        r33    k8 ; k8 = 120
.line	621	loadk        r34    k9 ; k9 = 255
.line	621	loadk        r35   k10 ; k10 = 205
.line	621	loadk        r36   k11 ; k11 = 35
.line	621	loadk        r37   k12 ; k12 = 175
.line	621	loadk        r38   k13 ; k13 = 19
.line	621	loadk        r39   k14 ; k14 = 235
.line	621	loadk        r40   k15 ; k15 = 176
.line	621	loadk        r41   k16 ; k16 = 251
.line	621	loadk        r42   k17 ; k17 = 219
.line	621	loadk        r43   k18 ; k18 = 223
.line	621	loadk        r44    k9 ; k9 = 255
.line	621	loadk        r45   k19 ; k19 = 115
.line	621	loadk        r46   k20 ; k20 = 81
.line	621	loadk        r47   k21 ; k21 = 10
.line	621	loadk        r48    k7 ; k7 = 49
.line	621	loadk        r49   k22 ; k22 = 142
.line	621	loadk        r50   k14 ; k14 = 235
.line	621	loadk        r51   k23 ; k23 = 174
.line	621	loadk        r52   k24 ; k24 = 14
.line	621	loadk        r53   k25 ; k25 = 247
.line	621	loadk        r54   k26 ; k26 = 27
.line	621	loadk        r55   k27 ; k27 = 250
.line	621	loadk        r56   k28 ; k28 = 133
.line	621	loadk        r57   k29 ; k29 = 239
.line	621	loadk        r58   k30 ; k30 = 248
.line	621	loadk        r59   k31 ; k31 = 215
.line	621	loadk        r60   k32 ; k32 = 221
.line	621	loadk        r61   k33 ; k33 = 117
.line	621	loadk        r62   k34 ; k34 = 70
.line	621	loadk        r63   k35 ; k35 = 44
.line	621	loadk        r64   k36 ; k36 = 32
.line	621	loadk        r65   k37 ; k37 = 184
.line	621	loadk        r66   k31 ; k31 = 215
.line	621	loadk        r67   k38 ; k38 = 173
.line	621	loadk        r68   k39 ; k39 = 13
.line	621	call         r28    41     2
.line	621	getupval     r29    u1
.line	621	loadk        r30   k40 ; k40 = 165
.line	621	loadk        r31   k41 ; k41 = 125
.line	621	loadk        r32   k42 ; k42 = 72
.line	621	loadk        r33   k43 ; k43 = 26
.line	621	loadk        r34   k44 ; k44 = 123
.line	621	loadk        r35   k45 ; k45 = 243
.line	621	loadk        r36   k32 ; k32 = 221
.line	621	loadk        r37   k51 ; k51 = 108
.line	621	loadk        r38  k154 ; k154 = 147
.line	621	loadk        r39  k155 ; k155 = 33
.line	621	loadk        r40  k156 ; k156 = 225
.line	621	loadk        r41  k157 ; k157 = 166
.line	621	loadk        r42   k68 ; k68 = 217
.line	621	loadk        r43   k25 ; k25 = 247
.line	621	loadk        r44  k158 ; k158 = 220
.line	621	loadk        r45  k159 ; k159 = 227
.line	621	loadk        r46   k53 ; k53 = 100
.line	621	loadk        r47   k20 ; k20 = 81
.line	621	loadk        r48  k160 ; k160 = 24
.line	621	loadk        r49   k97 ; k97 = 55
.line	621	loadk        r50  k161 ; k161 = 159
.line	621	loadk        r51   k62 ; k62 = 195
.line	621	loadk        r52  k162 ; k162 = 189
.line	621	loadk        r53  k163 ; k163 = 15
.line	621	call         r29    25     0
.line	621	setlist      r27     0     1
.line	621	call         r26     2     2
.line	621	gettable     r27   r21  k147 ; k147 = "AssetUID"
.line	621	gettable     r28   r21  k102 ; k102 = "FolderID"
.line	621	call         r25     4     1
.line	621	jmp            0  l597
.label	l520
.line	621	gettabup     r22    u0    k0 ; k0 = "print"
.line	621	gettabup     r23    u0    k2 ; k2 = "table"
.line	621	gettable     r23   r23    k3 ; k3 = "concat"
.line	621	newtable     r24     1     0
.line	621	getupval     r25    u1
.line	621	loadk        r26    k4 ; k4 = 177
.line	621	loadk        r27    k5 ; k5 = 122
.line	621	loadk        r28    k6 ; k6 = 126
.line	621	loadk        r29    k7 ; k7 = 49
.line	621	loadk        r30    k8 ; k8 = 120
.line	621	loadk        r31    k9 ; k9 = 255
.line	621	loadk        r32   k10 ; k10 = 205
.line	621	loadk        r33   k11 ; k11 = 35
.line	621	loadk        r34   k12 ; k12 = 175
.line	621	loadk        r35   k13 ; k13 = 19
.line	621	loadk        r36   k14 ; k14 = 235
.line	621	loadk        r37   k15 ; k15 = 176
.line	621	loadk        r38   k16 ; k16 = 251
.line	621	loadk        r39   k17 ; k17 = 219
.line	621	loadk        r40   k18 ; k18 = 223
.line	621	loadk        r41    k9 ; k9 = 255
.line	621	loadk        r42   k19 ; k19 = 115
.line	621	loadk        r43   k20 ; k20 = 81
.line	621	loadk        r44   k21 ; k21 = 10
.line	621	loadk        r45    k7 ; k7 = 49
.line	621	loadk        r46   k22 ; k22 = 142
.line	621	loadk        r47   k14 ; k14 = 235
.line	621	loadk        r48   k23 ; k23 = 174
.line	621	loadk        r49   k24 ; k24 = 14
.line	621	loadk        r50   k25 ; k25 = 247
.line	621	loadk        r51   k26 ; k26 = 27
.line	621	loadk        r52   k27 ; k27 = 250
.line	621	loadk        r53   k28 ; k28 = 133
.line	621	loadk        r54   k29 ; k29 = 239
.line	621	loadk        r55   k30 ; k30 = 248
.line	621	loadk        r56   k31 ; k31 = 215
.line	621	loadk        r57   k32 ; k32 = 221
.line	621	loadk        r58   k33 ; k33 = 117
.line	621	loadk        r59   k34 ; k34 = 70
.line	621	loadk        r60   k35 ; k35 = 44
.line	621	loadk        r61   k36 ; k36 = 32
.line	621	loadk        r62   k37 ; k37 = 184
.line	621	loadk        r63   k31 ; k31 = 215
.line	621	loadk        r64   k38 ; k38 = 173
.line	621	loadk        r65   k39 ; k39 = 13
.line	621	call         r25    41     2
.line	621	getupval     r26    u1
.line	621	loadk        r27   k40 ; k40 = 165
.line	621	loadk        r28   k41 ; k41 = 125
.line	621	loadk        r29   k42 ; k42 = 72
.line	621	loadk        r30   k43 ; k43 = 26
.line	621	loadk        r31   k44 ; k44 = 123
.line	621	loadk        r32   k45 ; k45 = 243
.line	621	loadk        r33   k32 ; k32 = 221
.line	621	loadk        r34   k51 ; k51 = 108
.line	621	loadk        r35  k116 ; k116 = 143
.line	621	loadk        r36  k155 ; k155 = 33
.line	621	loadk        r37  k164 ; k164 = 233
.line	621	loadk        r38   k38 ; k38 = 173
.line	621	loadk        r39  k165 ; k165 = 230
.line	621	loadk        r40    k9 ; k9 = 255
.line	621	loadk        r41  k166 ; k166 = 237
.line	621	loadk        r42    k9 ; k9 = 255
.line	621	loadk        r43  k167 ; k167 = 101
.line	621	loadk        r44  k107 ; k107 = 64
.line	621	loadk        r45  k168 ; k168 = 45
.line	621	call         r26    20     0
.line	621	setlist      r24     0     1
.line	621	call         r23     2     2
.line	621	gettable     r24   r20  k147 ; k147 = "AssetUID"
.line	621	call         r22     3     1
.line	621	gettabup     r22    u0    k2 ; k2 = "table"
.line	621	gettable     r22   r22  k169 ; k169 = "remove"
.line	621	gettable     r23    r0  k139 ; k139 = "AssetPathMap"
.line	621	move         r24   r19
.line	621	call         r22     3     1
.line	621	loadbool     r13     1     0
.label	l597
.line	621	move          r0    r0
.line	621	gettable     r16    r0  k150 ; k150 = "bUnloading"
.line	621	test         r16     1
.line	621	jmp            0  l608
.line	621	len          r16   r14
.line	621	lt             0  k170   r16 ; k170 = 0
.line	621	jmp            0  l608
.line	621	self         r16    r0  k171 ; k171 = "OnReqImportWorkAsset"
.line	621	newtable     r18     0     1
.line	621	settable     r18  k172   r14 ; k172 = "Items"
.line	621	call         r16     3     1
.label	l608
.line	621	gettabup     r16    u0   k90 ; k90 = "pairs"
.line	621	move         r17   r12
.line	621	call         r16     2     4
.line	621	jmp            0  l663
.line	621	gettable     r21    r0  k148 ; k148 = "UnloadingAssetIds"
.line	621	test         r21     0
.line	621	jmp            0  l620
.line	621	gettable     r21    r0  k148 ; k148 = "UnloadingAssetIds"
.line	621	gettabup     r22    u0  k103 ; k103 = "tostring"
.line	621	move         r23   r19
.line	621	call         r22     2     2
.line	621	gettable     r21   r21   r22
.label	l620
.line	621	gettable     r22   r20  k104 ; k104 = "IsReady"
.line	621	test         r22     0
.line	621	jmp            0  l663
.line	621	test         r21     1
.line	621	jmp            0  l663
.line	621	self         r22    r0  k173 ; k173 = "IsAssetInPathMap"
.line	621	move         r24   r19
.line	621	gettable     r25   r20  k101 ; k101 = "AssetType"
.line	621	call         r22     4     2
.line	621	test         r22     1
.line	621	jmp            0  l663
.line	621	newtable     r22     0     6
.line	621	gettabup     r23    u0  k103 ; k103 = "tostring"
.line	621	gettable     r24   r20  k147 ; k147 = "AssetUID"
.line	621	call         r23     2     2
.line	621	settable     r22  k147   r23 ; k147 = "AssetUID"
.line	621	gettable     r23   r20   k91 ; k91 = "AssetName"
.line	621	settable     r22   k91   r23 ; k91 = "AssetName"
.line	621	gettable     r23   r20  k101 ; k101 = "AssetType"
.line	621	settable     r22  k101   r23 ; k101 = "AssetType"
.line	621	gettable     r23   r20  k102 ; k102 = "FolderID"
.line	621	settable     r22  k102   r23 ; k102 = "FolderID"
.line	621	gettable     r23   r20  k174 ; k174 = "Icon"
.line	621	settable     r22  k174   r23 ; k174 = "Icon"
.line	621	gettable     r23   r20  k175 ; k175 = "Desc"
.line	621	test         r23     1
.line	621	jmp            0  l649
.line	621	getupval     r23    u1
.line	621	call         r23     1     2
.label	l649
.line	621	settable     r22  k175   r23 ; k175 = "Desc"
.line	621	self         r23    r0  k176 ; k176 = "GetAssetRestrictions"
.line	621	gettable     r25   r20  k102 ; k102 = "FolderID"
.line	621	call         r23     3     2
.line	621	self         r24    r0  k177 ; k177 = "ApplyAssetRestrictio" (truncated)
.line	621	move         r26   r22
.line	621	move         r27   r23
.line	621	call         r24     4     1
.line	621	gettabup     r24    u0    k2 ; k2 = "table"
.line	621	gettable     r24   r24  k152 ; k152 = "insert"
.line	621	gettable     r25    r0  k139 ; k139 = "AssetPathMap"
.line	621	move         r26   r22
.line	621	call         r24     3     1
.line	621	loadbool     r13     1     0
.label	l663
.line	621	move          r0    r0
.line	621	move          r0    r0
.line	621	self         r16    r0  k178 ; k178 = "FillWorkAssetDisplay" (truncated)
.line	621	call         r16     2     2
.line	621	test         r13     1
.line	621	jmp            0  l675
.line	621	test          r9     1
.line	621	jmp            0  l675
.line	621	test          r6     1
.line	621	jmp            0  l675
.line	621	test         r16     0
.line	621	jmp            0  l677
.label	l675
.line	621	self         r17    r0  k179 ; k179 = "SaveAssetPathMap"
.line	621	call         r17     2     1
.label	l677
.line	621	test         r13     1
.line	621	jmp            0  l685
.line	621	test          r9     1
.line	621	jmp            0  l685
.line	621	test          r6     1
.line	621	jmp            0  l685
.line	621	test         r16     0
.line	621	jmp            0  l687
.label	l685
.line	621	self         r17    r0  k180 ; k180 = "SyncWorkAssetDataToE" (truncated)
.line	621	call         r17     2     1
.label	l687
.line	621	settable      r0   k47   k79 ; k79 = false
.line	621	gettable     r17    r0   k48 ; k48 = "bWorkAssetDataChange" (truncated)
.line	621	test         r17     0
.line	621	jmp            0  l696
.line	621	settable      r0   k48   k79 ; k79 = false
.line	621	self         r17    r0  k181 ; k181 = "AddTimerOnce"
.line	621	loadk        r19  k170 ; k170 = 0
.line	621	closure      r20    f0
.line	621	call         r17     4     1
.label	l696
.line	621	return        r0     1
.line	621	move          r0    r0
.line	621	move          r0    r0
.line	621	return        r0     1

.function	main/f23/f0

.source	null
.linedefined	706
.lastlinedefined	708
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	true

.constant	k0	"OnWorkAssetDataChanged"

.line	706	getupval      r0    u0
.line	706	self          r0    r0    k0 ; k0 = "OnWorkAssetDataChang" (truncated)
.line	706	call          r0     2     1
.line	706	return        r0     1
.line	706	move          r0    r0
.line	706	return        r0     1

.function	main/f24

.source	null
.linedefined	712
.lastlinedefined	724
.numparams	1
.is_vararg	0
.maxstacksize	5

.constant	k0	"UMGInfoSyncTimer"
.constant	k1	"AddTimerOnce"
.constant	k2	0.5

.line	712	gettable      r1    r0    k0 ; k0 = "UMGInfoSyncTimer"
.line	712	test          r1     0
.line	712	jmp            0    l5
.line	712	return        r0     1
.label	l5
.line	712	self          r1    r0    k1 ; k1 = "AddTimerOnce"
.line	712	loadk         r3    k2 ; k2 = 0.5
.line	712	closure       r4    f0
.line	712	call          r1     4     2
.line	712	settable      r0    k0    r1 ; k0 = "UMGInfoSyncTimer"
.line	712	return        r0     1
.line	712	move          r0    r0
.line	712	return        r0     1

.function	main/f24/f0

.source	null
.linedefined	716
.lastlinedefined	723
.numparams	0
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	0	true

.constant	k0	"UMGInfoSyncTimer"
.constant	k1	nil
.constant	k2	"SyncUMGDataToAssetPathMap"
.constant	k3	"SyncWorkAssetDataToEditor"
.constant	k4	"SyncMyPrefabMallMetaToEditor"

.line	716	settabup      u0    k0    k1 ; k1 = nil
.line	716	getupval      r0    u0
.line	716	self          r0    r0    k2 ; k2 = "SyncUMGDataToAssetPa" (truncated)
.line	716	call          r0     2     2
.line	716	test          r0     0
.line	716	jmp            0   l13
.line	716	getupval      r1    u0
.line	716	self          r1    r1    k3 ; k3 = "SyncWorkAssetDataToE" (truncated)
.line	716	call          r1     2     1
.line	716	getupval      r1    u0
.line	716	self          r1    r1    k4 ; k4 = "SyncMyPrefabMallMeta" (truncated)
.line	716	call          r1     2     1
.label	l13
.line	716	return        r0     1
.line	716	move          r0    r0
.line	716	return        r0     1

.function	main/f25

.source	null
.linedefined	726
.lastlinedefined	736
.numparams	5
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	177
.constant	k7	122
.constant	k8	126
.constant	k9	49
.constant	k10	120
.constant	k11	255
.constant	k12	205
.constant	k13	35
.constant	k14	175
.constant	k15	19
.constant	k16	235
.constant	k17	176
.constant	k18	251
.constant	k19	219
.constant	k20	223
.constant	k21	115
.constant	k22	81
.constant	k23	10
.constant	k24	142
.constant	k25	174
.constant	k26	14
.constant	k27	247
.constant	k28	27
.constant	k29	250
.constant	k30	145
.constant	k31	245
.constant	k32	249
.constant	k33	200
.constant	k34	243
.constant	k35	107
.constant	k36	116
.constant	k37	58
.constant	k38	39
.constant	k39	153
.constant	k40	194
.constant	k41	148
.constant	k42	3
.constant	k43	147
.constant	k44	123
.constant	k45	93
.constant	k46	104
.constant	k47	41
.constant	k48	158
.constant	k49	44
.constant	k50	229
.constant	k51	172
.constant	k52	140
.constant	k53	207
.constant	k54	99
.constant	k55	86
.constant	k56	45
.constant	k57	43
.constant	k58	129
.constant	k59	231
.constant	k60	186
.constant	k61	15
.constant	k62	168
.constant	k63	32
.constant	k64	183
.constant	k65	239
.constant	k66	38
.constant	k67	42
.constant	k68	149
.constant	k69	217
.constant	k70	56
.constant	k71	159
.constant	k72	101
.constant	k73	76
.constant	k74	78
.constant	k75	57
.constant	k76	"tostring"
.constant	k77	"ActorDataCompleted"
.constant	k78	167
.constant	k79	113
.constant	k80	77
.constant	k81	165
.constant	k82	125
.constant	k83	72
.constant	k84	26
.constant	k85	"OnCustomAssetMountStateChange_Add"
.constant	k86	180
.constant	k87	112
.constant	k88	68
.constant	k89	106
.constant	k90	"OnCustomAssetMountStateChange_Remove"

.line	726	gettabup      r5    u0    k0 ; k0 = "print"
.line	726	gettabup      r6    u0    k1 ; k1 = "bWriteLog"
.line	726	test          r6     0
.line	726	jmp            0  l111
.line	726	gettabup      r6    u0    k2 ; k2 = "string"
.line	726	gettable      r6    r6    k3 ; k3 = "format"
.line	726	gettabup      r7    u0    k4 ; k4 = "table"
.line	726	gettable      r7    r7    k5 ; k5 = "concat"
.line	726	newtable      r8     2     0
.line	726	getupval      r9    u1
.line	726	loadk        r10    k6 ; k6 = 177
.line	726	loadk        r11    k7 ; k7 = 122
.line	726	loadk        r12    k8 ; k8 = 126
.line	726	loadk        r13    k9 ; k9 = 49
.line	726	loadk        r14   k10 ; k10 = 120
.line	726	loadk        r15   k11 ; k11 = 255
.line	726	loadk        r16   k12 ; k12 = 205
.line	726	loadk        r17   k13 ; k13 = 35
.line	726	loadk        r18   k14 ; k14 = 175
.line	726	loadk        r19   k15 ; k15 = 19
.line	726	loadk        r20   k16 ; k16 = 235
.line	726	loadk        r21   k17 ; k17 = 176
.line	726	loadk        r22   k18 ; k18 = 251
.line	726	loadk        r23   k19 ; k19 = 219
.line	726	loadk        r24   k20 ; k20 = 223
.line	726	loadk        r25   k11 ; k11 = 255
.line	726	loadk        r26   k21 ; k21 = 115
.line	726	loadk        r27   k22 ; k22 = 81
.line	726	loadk        r28   k23 ; k23 = 10
.line	726	loadk        r29    k9 ; k9 = 49
.line	726	loadk        r30   k24 ; k24 = 142
.line	726	loadk        r31   k16 ; k16 = 235
.line	726	loadk        r32   k25 ; k25 = 174
.line	726	loadk        r33   k26 ; k26 = 14
.line	726	loadk        r34   k27 ; k27 = 247
.line	726	loadk        r35   k28 ; k28 = 27
.line	726	loadk        r36   k29 ; k29 = 250
.line	726	loadk        r37   k30 ; k30 = 145
.line	726	loadk        r38   k31 ; k31 = 245
.line	726	loadk        r39   k32 ; k32 = 249
.line	726	loadk        r40   k33 ; k33 = 200
.line	726	loadk        r41   k34 ; k34 = 243
.line	726	loadk        r42   k35 ; k35 = 107
.line	726	loadk        r43   k36 ; k36 = 116
.line	726	loadk        r44   k37 ; k37 = 58
.line	726	loadk        r45   k38 ; k38 = 39
.line	726	loadk        r46   k39 ; k39 = 153
.line	726	loadk        r47   k40 ; k40 = 194
.line	726	loadk        r48   k41 ; k41 = 148
.line	726	loadk        r49   k42 ; k42 = 3
.line	726	call          r9    41     2
.line	726	getupval     r10    u1
.line	726	loadk        r11   k43 ; k43 = 147
.line	726	loadk        r12   k44 ; k44 = 123
.line	726	loadk        r13   k45 ; k45 = 93
.line	726	loadk        r14   k38 ; k38 = 39
.line	726	loadk        r15   k46 ; k46 = 104
.line	726	loadk        r16   k27 ; k27 = 247
.line	726	loadk        r17   k12 ; k12 = 205
.line	726	loadk        r18   k47 ; k47 = 41
.line	726	loadk        r19   k48 ; k48 = 158
.line	726	loadk        r20   k49 ; k49 = 44
.line	726	loadk        r21   k50 ; k50 = 229
.line	726	loadk        r22   k51 ; k51 = 172
.line	726	loadk        r23   k27 ; k27 = 247
.line	726	loadk        r24   k11 ; k11 = 255
.line	726	loadk        r25   k52 ; k52 = 140
.line	726	loadk        r26   k53 ; k53 = 207
.line	726	loadk        r27   k54 ; k54 = 99
.line	726	loadk        r28   k55 ; k55 = 86
.line	726	loadk        r29   k56 ; k56 = 45
.line	726	loadk        r30   k57 ; k57 = 43
.line	726	loadk        r31   k58 ; k58 = 129
.line	726	loadk        r32   k59 ; k59 = 231
.line	726	loadk        r33   k60 ; k60 = 186
.line	726	loadk        r34   k61 ; k61 = 15
.line	726	loadk        r35   k62 ; k62 = 168
.line	726	loadk        r36   k63 ; k63 = 32
.line	726	loadk        r37   k20 ; k20 = 223
.line	726	loadk        r38   k64 ; k64 = 183
.line	726	loadk        r39   k32 ; k32 = 249
.line	726	loadk        r40   k17 ; k17 = 176
.line	726	loadk        r41   k39 ; k39 = 153
.line	726	loadk        r42   k65 ; k65 = 239
.line	726	loadk        r43   k66 ; k66 = 38
.line	726	loadk        r44   k36 ; k36 = 116
.line	726	loadk        r45   k67 ; k67 = 42
.line	726	loadk        r46   k63 ; k63 = 32
.line	726	loadk        r47   k68 ; k68 = 149
.line	726	loadk        r48   k69 ; k69 = 217
.line	726	loadk        r49   k64 ; k64 = 183
.line	726	loadk        r50   k70 ; k70 = 56
.line	726	call         r10    41     2
.line	726	getupval     r11    u1
.line	726	loadk        r12   k71 ; k71 = 159
.line	726	loadk        r13   k72 ; k72 = 101
.line	726	loadk        r14   k73 ; k73 = 76
.line	726	loadk        r15   k74 ; k74 = 78
.line	726	loadk        r16   k75 ; k75 = 57
.line	726	loadk        r17   k50 ; k50 = 229
.line	726	call         r11     7     0
.line	726	setlist       r8     0     1
.line	726	call          r7     2     2
.line	726	gettabup      r8    u0   k76 ; k76 = "tostring"
.line	726	move          r9    r3
.line	726	call          r8     2     2
.line	726	gettabup      r9    u0   k76 ; k76 = "tostring"
.line	726	move         r10    r4
.line	726	call          r9     2     0
.line	726	call          r6     0     2
.label	l111
.line	726	call          r5     2     1
.line	726	gettable      r5    r0   k77 ; k77 = "ActorDataCompleted"
.line	726	test          r5     1
.line	726	jmp            0  l116
.line	726	return        r0     1
.label	l116
.line	726	getupval      r5    u1
.line	726	loadk         r6   k78 ; k78 = 167
.line	726	loadk         r7   k79 ; k79 = 113
.line	726	loadk         r8   k80 ; k80 = 77
.line	726	call          r5     4     2
.line	726	eq             1    r4    r5
.line	726	jmp            0  l133
.line	726	getupval      r5    u1
.line	726	loadk         r6   k81 ; k81 = 165
.line	726	loadk         r7   k82 ; k82 = 125
.line	726	loadk         r8   k83 ; k83 = 72
.line	726	loadk         r9   k84 ; k84 = 26
.line	726	loadk        r10   k44 ; k44 = 123
.line	726	loadk        r11   k34 ; k34 = 243
.line	726	call          r5     7     2
.line	726	eq             0    r4    r5
.line	726	jmp            0  l137
.label	l133
.line	726	self          r5    r0   k85 ; k85 = "OnCustomAssetMountSt" (truncated)
.line	726	move          r7    r3
.line	726	call          r5     3     1
.line	726	jmp            0  l150
.label	l137
.line	726	getupval      r5    u1
.line	726	loadk         r6   k86 ; k86 = 180
.line	726	loadk         r7   k87 ; k87 = 112
.line	726	loadk         r8   k88 ; k88 = 68
.line	726	loadk         r9   k28 ; k28 = 27
.line	726	loadk        r10   k89 ; k89 = 106
.line	726	loadk        r11   k34 ; k34 = 243
.line	726	call          r5     7     2
.line	726	eq             0    r4    r5
.line	726	jmp            0  l150
.line	726	self          r5    r0   k90 ; k90 = "OnCustomAssetMountSt" (truncated)
.line	726	move          r7    r3
.line	726	call          r5     3     1
.label	l150
.line	726	return        r0     1
.line	726	move          r0    r0
.line	726	move          r0    r0
.line	726	move          r0    r0
.line	726	move          r0    r0
.line	726	return        r0     1

.function	main/f26

.source	null
.linedefined	738
.lastlinedefined	774
.numparams	2
.is_vararg	0
.maxstacksize	57

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true
.upvalue	"U3"	18	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	177
.constant	k7	122
.constant	k8	126
.constant	k9	49
.constant	k10	120
.constant	k11	255
.constant	k12	205
.constant	k13	35
.constant	k14	175
.constant	k15	19
.constant	k16	235
.constant	k17	176
.constant	k18	251
.constant	k19	219
.constant	k20	223
.constant	k21	115
.constant	k22	81
.constant	k23	10
.constant	k24	142
.constant	k25	174
.constant	k26	14
.constant	k27	247
.constant	k28	27
.constant	k29	250
.constant	k30	145
.constant	k31	245
.constant	k32	249
.constant	k33	200
.constant	k34	243
.constant	k35	107
.constant	k36	116
.constant	k37	58
.constant	k38	39
.constant	k39	153
.constant	k40	194
.constant	k41	148
.constant	k42	3
.constant	k43	147
.constant	k44	123
.constant	k45	93
.constant	k46	104
.constant	k47	41
.constant	k48	158
.constant	k49	44
.constant	k50	229
.constant	k51	172
.constant	k52	114
.constant	k53	65
.constant	k54	121
.constant	k55	7
.constant	k56	213
.constant	k57	189
.constant	k58	160
.constant	k59	21
.constant	k60	231
.constant	k61	161
.constant	k62	254
.constant	k63	127
.constant	k64	15
.constant	k65	108
.constant	k66	"tostring"
.constant	k67	"GetMetaInfoByCustomAssetKey"
.constant	k68	"Meta"
.constant	k69	105
.constant	k70	204
.constant	k71	131
.constant	k72	186
.constant	k73	92
.constant	k74	128
.constant	k75	224
.constant	k76	179
.constant	k77	201
.constant	k78	228
.constant	k79	218
.constant	k80	38
.constant	k81	91
.constant	k82	32
.constant	k83	220
.constant	k84	208
.constant	k85	182
.constant	k86	25
.constant	k87	136
.constant	k88	113
.constant	k89	"PrefabType"
.constant	k90	184
.constant	k91	167
.constant	k92	240
.constant	k93	211
.constant	k94	238
.constant	k95	80
.constant	k96	45
.constant	k97	196
.constant	k98	188
.constant	k99	135
.constant	k100	119
.constant	k101	125
.constant	k102	13
.constant	k103	248
.constant	k104	55
.constant	k105	"AssetId"
.constant	k106	"CollectAllLatestAssets"
.constant	k107	"tonumber"
.constant	k108	"IsReady"
.constant	k109	163
.constant	k110	59
.constant	k111	242
.constant	k112	233
.constant	k113	156
.constant	k114	221
.constant	k115	106
.constant	k116	89
.constant	k117	5
.constant	k118	53
.constant	k119	170
.constant	k120	24
.constant	k121	102
.constant	k122	90
.constant	k123	17
.constant	k124	100
.constant	k125	234
.constant	k126	173
.constant	k127	222
.constant	k128	162
.constant	k129	"UnloadingAssetIds"
.constant	k130	"IsAssetInPathMap"
.constant	k131	56
.constant	k132	230
.constant	k133	183
.constant	k134	225
.constant	k135	197
.constant	k136	111
.constant	k137	143
.constant	k138	28
.constant	k139	"FolderID"
.constant	k140	"GetFolderIDForAssetType"
.constant	k141	"ImportingAssetMap"
.constant	k142	"AddAssetToPathMapOnImport"
.constant	k143	"SyncWorkAssetDataToEditor"
.constant	k144	48
.constant	k145	137
.constant	k146	146
.constant	k147	178
.constant	k148	40
.constant	k149	226
.constant	k150	232
.constant	k151	54
.constant	k152	0
.constant	k153	42

.line	738	gettabup      r2    u0    k0 ; k0 = "print"
.line	738	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	738	test          r3     0
.line	738	jmp            0   l96
.line	738	gettabup      r3    u0    k2 ; k2 = "string"
.line	738	gettable      r3    r3    k3 ; k3 = "format"
.line	738	gettabup      r4    u0    k4 ; k4 = "table"
.line	738	gettable      r4    r4    k5 ; k5 = "concat"
.line	738	newtable      r5     1     0
.line	738	getupval      r6    u1
.line	738	loadk         r7    k6 ; k6 = 177
.line	738	loadk         r8    k7 ; k7 = 122
.line	738	loadk         r9    k8 ; k8 = 126
.line	738	loadk        r10    k9 ; k9 = 49
.line	738	loadk        r11   k10 ; k10 = 120
.line	738	loadk        r12   k11 ; k11 = 255
.line	738	loadk        r13   k12 ; k12 = 205
.line	738	loadk        r14   k13 ; k13 = 35
.line	738	loadk        r15   k14 ; k14 = 175
.line	738	loadk        r16   k15 ; k15 = 19
.line	738	loadk        r17   k16 ; k16 = 235
.line	738	loadk        r18   k17 ; k17 = 176
.line	738	loadk        r19   k18 ; k18 = 251
.line	738	loadk        r20   k19 ; k19 = 219
.line	738	loadk        r21   k20 ; k20 = 223
.line	738	loadk        r22   k11 ; k11 = 255
.line	738	loadk        r23   k21 ; k21 = 115
.line	738	loadk        r24   k22 ; k22 = 81
.line	738	loadk        r25   k23 ; k23 = 10
.line	738	loadk        r26    k9 ; k9 = 49
.line	738	loadk        r27   k24 ; k24 = 142
.line	738	loadk        r28   k16 ; k16 = 235
.line	738	loadk        r29   k25 ; k25 = 174
.line	738	loadk        r30   k26 ; k26 = 14
.line	738	loadk        r31   k27 ; k27 = 247
.line	738	loadk        r32   k28 ; k28 = 27
.line	738	loadk        r33   k29 ; k29 = 250
.line	738	loadk        r34   k30 ; k30 = 145
.line	738	loadk        r35   k31 ; k31 = 245
.line	738	loadk        r36   k32 ; k32 = 249
.line	738	loadk        r37   k33 ; k33 = 200
.line	738	loadk        r38   k34 ; k34 = 243
.line	738	loadk        r39   k35 ; k35 = 107
.line	738	loadk        r40   k36 ; k36 = 116
.line	738	loadk        r41   k37 ; k37 = 58
.line	738	loadk        r42   k38 ; k38 = 39
.line	738	loadk        r43   k39 ; k39 = 153
.line	738	loadk        r44   k40 ; k40 = 194
.line	738	loadk        r45   k41 ; k41 = 148
.line	738	loadk        r46   k42 ; k42 = 3
.line	738	call          r6    41     2
.line	738	getupval      r7    u1
.line	738	loadk         r8   k43 ; k43 = 147
.line	738	loadk         r9   k44 ; k44 = 123
.line	738	loadk        r10   k45 ; k45 = 93
.line	738	loadk        r11   k38 ; k38 = 39
.line	738	loadk        r12   k46 ; k46 = 104
.line	738	loadk        r13   k27 ; k27 = 247
.line	738	loadk        r14   k12 ; k12 = 205
.line	738	loadk        r15   k47 ; k47 = 41
.line	738	loadk        r16   k48 ; k48 = 158
.line	738	loadk        r17   k49 ; k49 = 44
.line	738	loadk        r18   k50 ; k50 = 229
.line	738	loadk        r19   k51 ; k51 = 172
.line	738	loadk        r20   k27 ; k27 = 247
.line	738	loadk        r21   k11 ; k11 = 255
.line	738	loadk        r22   k34 ; k34 = 243
.line	738	loadk        r23   k12 ; k12 = 205
.line	738	loadk        r24   k52 ; k52 = 114
.line	738	loadk        r25   k53 ; k53 = 65
.line	738	loadk        r26   k54 ; k54 = 121
.line	738	loadk        r27   k55 ; k55 = 7
.line	738	loadk        r28   k39 ; k39 = 153
.line	738	loadk        r29   k56 ; k56 = 213
.line	738	loadk        r30   k57 ; k57 = 189
.line	738	loadk        r31   k15 ; k15 = 19
.line	738	loadk        r32   k58 ; k58 = 160
.line	738	loadk        r33   k59 ; k59 = 21
.line	738	loadk        r34   k60 ; k60 = 231
.line	738	loadk        r35   k61 ; k61 = 161
.line	738	loadk        r36   k50 ; k50 = 229
.line	738	loadk        r37   k62 ; k62 = 254
.line	738	loadk        r38   k27 ; k27 = 247
.line	738	loadk        r39   k32 ; k32 = 249
.line	738	loadk        r40   k63 ; k63 = 127
.line	738	loadk        r41   k64 ; k64 = 15
.line	738	loadk        r42   k65 ; k65 = 108
.line	738	loadk        r43   k38 ; k38 = 39
.line	738	call          r7    37     0
.line	738	setlist       r5     0     1
.line	738	call          r4     2     2
.line	738	gettabup      r5    u0   k66 ; k66 = "tostring"
.line	738	move          r6    r1
.line	738	call          r5     2     0
.line	738	call          r3     0     2
.label	l96
.line	738	call          r2     2     1
.line	738	getupval      r2    u2
.line	738	self          r2    r2   k67 ; k67 = "GetMetaInfoByCustomA" (truncated)
.line	738	move          r4    r1
.line	738	call          r2     3     2
.line	738	test          r2     0
.line	738	jmp            0  l106
.line	738	gettable      r3    r2   k68 ; k68 = "Meta"
.line	738	test          r3     1
.line	738	jmp            0  l211
.label	l106
.line	738	gettabup      r3    u0    k0 ; k0 = "print"
.line	738	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	738	test          r4     0
.line	738	jmp            0  l209
.line	738	gettabup      r4    u0    k2 ; k2 = "string"
.line	738	gettable      r4    r4    k3 ; k3 = "format"
.line	738	gettabup      r5    u0    k4 ; k4 = "table"
.line	738	gettable      r5    r5    k5 ; k5 = "concat"
.line	738	newtable      r6     2     0
.line	738	getupval      r7    u1
.line	738	loadk         r8    k6 ; k6 = 177
.line	738	loadk         r9    k7 ; k7 = 122
.line	738	loadk        r10    k8 ; k8 = 126
.line	738	loadk        r11    k9 ; k9 = 49
.line	738	loadk        r12   k10 ; k10 = 120
.line	738	loadk        r13   k11 ; k11 = 255
.line	738	loadk        r14   k12 ; k12 = 205
.line	738	loadk        r15   k13 ; k13 = 35
.line	738	loadk        r16   k14 ; k14 = 175
.line	738	loadk        r17   k15 ; k15 = 19
.line	738	loadk        r18   k16 ; k16 = 235
.line	738	loadk        r19   k17 ; k17 = 176
.line	738	loadk        r20   k18 ; k18 = 251
.line	738	loadk        r21   k19 ; k19 = 219
.line	738	loadk        r22   k20 ; k20 = 223
.line	738	loadk        r23   k11 ; k11 = 255
.line	738	loadk        r24   k21 ; k21 = 115
.line	738	loadk        r25   k22 ; k22 = 81
.line	738	loadk        r26   k23 ; k23 = 10
.line	738	loadk        r27    k9 ; k9 = 49
.line	738	loadk        r28   k24 ; k24 = 142
.line	738	loadk        r29   k16 ; k16 = 235
.line	738	loadk        r30   k25 ; k25 = 174
.line	738	loadk        r31   k26 ; k26 = 14
.line	738	loadk        r32   k27 ; k27 = 247
.line	738	loadk        r33   k28 ; k28 = 27
.line	738	loadk        r34   k29 ; k29 = 250
.line	738	loadk        r35   k30 ; k30 = 145
.line	738	loadk        r36   k31 ; k31 = 245
.line	738	loadk        r37   k32 ; k32 = 249
.line	738	loadk        r38   k33 ; k33 = 200
.line	738	loadk        r39   k34 ; k34 = 243
.line	738	loadk        r40   k35 ; k35 = 107
.line	738	loadk        r41   k36 ; k36 = 116
.line	738	loadk        r42   k37 ; k37 = 58
.line	738	loadk        r43   k38 ; k38 = 39
.line	738	loadk        r44   k39 ; k39 = 153
.line	738	loadk        r45   k40 ; k40 = 194
.line	738	loadk        r46   k41 ; k41 = 148
.line	738	loadk        r47   k42 ; k42 = 3
.line	738	call          r7    41     2
.line	738	getupval      r8    u1
.line	738	loadk         r9   k43 ; k43 = 147
.line	738	loadk        r10   k44 ; k44 = 123
.line	738	loadk        r11   k45 ; k45 = 93
.line	738	loadk        r12   k38 ; k38 = 39
.line	738	loadk        r13   k46 ; k46 = 104
.line	738	loadk        r14   k27 ; k27 = 247
.line	738	loadk        r15   k12 ; k12 = 205
.line	738	loadk        r16   k47 ; k47 = 41
.line	738	loadk        r17   k48 ; k48 = 158
.line	738	loadk        r18   k49 ; k49 = 44
.line	738	loadk        r19   k50 ; k50 = 229
.line	738	loadk        r20   k51 ; k51 = 172
.line	738	loadk        r21   k27 ; k27 = 247
.line	738	loadk        r22   k11 ; k11 = 255
.line	738	loadk        r23   k34 ; k34 = 243
.line	738	loadk        r24   k12 ; k12 = 205
.line	738	loadk        r25   k52 ; k52 = 114
.line	738	loadk        r26   k53 ; k53 = 65
.line	738	loadk        r27   k54 ; k54 = 121
.line	738	loadk        r28   k69 ; k69 = 105
.line	738	loadk        r29   k70 ; k70 = 204
.line	738	loadk        r30   k71 ; k71 = 131
.line	738	loadk        r31   k72 ; k72 = 186
.line	738	loadk        r32   k73 ; k73 = 92
.line	738	loadk        r33   k74 ; k74 = 128
.line	738	loadk        r34    k9 ; k9 = 49
.line	738	loadk        r35   k75 ; k75 = 224
.line	738	loadk        r36   k76 ; k76 = 179
.line	738	loadk        r37   k77 ; k77 = 201
.line	738	loadk        r38   k78 ; k78 = 228
.line	738	loadk        r39   k79 ; k79 = 218
.line	738	loadk        r40   k34 ; k34 = 243
.line	738	loadk        r41   k80 ; k80 = 38
.line	738	loadk        r42   k81 ; k81 = 91
.line	738	loadk        r43   k80 ; k80 = 38
.line	738	loadk        r44   k82 ; k82 = 32
.line	738	loadk        r45   k83 ; k83 = 220
.line	738	loadk        r46   k84 ; k84 = 208
.line	738	loadk        r47   k85 ; k85 = 182
.line	738	loadk        r48   k86 ; k86 = 25
.line	738	call          r8    41     2
.line	738	getupval      r9    u1
.line	738	loadk        r10   k87 ; k87 = 136
.line	738	loadk        r11   k88 ; k88 = 113
.line	738	call          r9     3     0
.line	738	setlist       r6     0     1
.line	738	call          r5     2     2
.line	738	gettabup      r6    u0   k66 ; k66 = "tostring"
.line	738	move          r7    r1
.line	738	call          r6     2     0
.line	738	call          r4     0     2
.label	l209
.line	738	call          r3     2     1
.line	738	return        r0     1
.label	l211
.line	738	gettable      r3    r2   k68 ; k68 = "Meta"
.line	738	gettable      r4    r3   k89 ; k89 = "PrefabType"
.line	738	gettabup      r5    u3    r4
.line	738	test          r5     1
.line	738	jmp            0  l332
.line	738	gettabup      r6    u0    k0 ; k0 = "print"
.line	738	gettabup      r7    u0    k1 ; k1 = "bWriteLog"
.line	738	test          r7     0
.line	738	jmp            0  l330
.line	738	gettabup      r7    u0    k2 ; k2 = "string"
.line	738	gettable      r7    r7    k3 ; k3 = "format"
.line	738	gettabup      r8    u0    k4 ; k4 = "table"
.line	738	gettable      r8    r8    k5 ; k5 = "concat"
.line	738	newtable      r9     2     0
.line	738	getupval     r10    u1
.line	738	loadk        r11    k6 ; k6 = 177
.line	738	loadk        r12    k7 ; k7 = 122
.line	738	loadk        r13    k8 ; k8 = 126
.line	738	loadk        r14    k9 ; k9 = 49
.line	738	loadk        r15   k10 ; k10 = 120
.line	738	loadk        r16   k11 ; k11 = 255
.line	738	loadk        r17   k12 ; k12 = 205
.line	738	loadk        r18   k13 ; k13 = 35
.line	738	loadk        r19   k14 ; k14 = 175
.line	738	loadk        r20   k15 ; k15 = 19
.line	738	loadk        r21   k16 ; k16 = 235
.line	738	loadk        r22   k17 ; k17 = 176
.line	738	loadk        r23   k18 ; k18 = 251
.line	738	loadk        r24   k19 ; k19 = 219
.line	738	loadk        r25   k20 ; k20 = 223
.line	738	loadk        r26   k11 ; k11 = 255
.line	738	loadk        r27   k21 ; k21 = 115
.line	738	loadk        r28   k22 ; k22 = 81
.line	738	loadk        r29   k23 ; k23 = 10
.line	738	loadk        r30    k9 ; k9 = 49
.line	738	loadk        r31   k24 ; k24 = 142
.line	738	loadk        r32   k16 ; k16 = 235
.line	738	loadk        r33   k25 ; k25 = 174
.line	738	loadk        r34   k26 ; k26 = 14
.line	738	loadk        r35   k27 ; k27 = 247
.line	738	loadk        r36   k28 ; k28 = 27
.line	738	loadk        r37   k29 ; k29 = 250
.line	738	loadk        r38   k30 ; k30 = 145
.line	738	loadk        r39   k31 ; k31 = 245
.line	738	loadk        r40   k32 ; k32 = 249
.line	738	loadk        r41   k33 ; k33 = 200
.line	738	loadk        r42   k34 ; k34 = 243
.line	738	loadk        r43   k35 ; k35 = 107
.line	738	loadk        r44   k36 ; k36 = 116
.line	738	loadk        r45   k37 ; k37 = 58
.line	738	loadk        r46   k38 ; k38 = 39
.line	738	loadk        r47   k39 ; k39 = 153
.line	738	loadk        r48   k40 ; k40 = 194
.line	738	loadk        r49   k41 ; k41 = 148
.line	738	loadk        r50   k42 ; k42 = 3
.line	738	call         r10    41     2
.line	738	getupval     r11    u1
.line	738	loadk        r12   k43 ; k43 = 147
.line	738	loadk        r13   k44 ; k44 = 123
.line	738	loadk        r14   k45 ; k45 = 93
.line	738	loadk        r15   k38 ; k38 = 39
.line	738	loadk        r16   k46 ; k46 = 104
.line	738	loadk        r17   k27 ; k27 = 247
.line	738	loadk        r18   k12 ; k12 = 205
.line	738	loadk        r19   k47 ; k47 = 41
.line	738	loadk        r20   k48 ; k48 = 158
.line	738	loadk        r21   k49 ; k49 = 44
.line	738	loadk        r22   k50 ; k50 = 229
.line	738	loadk        r23   k51 ; k51 = 172
.line	738	loadk        r24   k27 ; k27 = 247
.line	738	loadk        r25   k11 ; k11 = 255
.line	738	loadk        r26   k34 ; k34 = 243
.line	738	loadk        r27   k12 ; k12 = 205
.line	738	loadk        r28   k52 ; k52 = 114
.line	738	loadk        r29   k53 ; k53 = 65
.line	738	loadk        r30   k54 ; k54 = 121
.line	738	loadk        r31   k69 ; k69 = 105
.line	738	loadk        r32   k70 ; k70 = 204
.line	738	loadk        r33   k71 ; k71 = 131
.line	738	loadk        r34   k72 ; k72 = 186
.line	738	loadk        r35   k73 ; k73 = 92
.line	738	loadk        r36   k90 ; k90 = 184
.line	738	loadk        r37   k37 ; k37 = 58
.line	738	loadk        r38   k60 ; k60 = 231
.line	738	loadk        r39   k91 ; k91 = 167
.line	738	loadk        r40   k92 ; k92 = 240
.line	738	loadk        r41   k29 ; k29 = 250
.line	738	loadk        r42   k93 ; k93 = 211
.line	738	loadk        r43   k94 ; k94 = 238
.line	738	loadk        r44   k52 ; k52 = 114
.line	738	loadk        r45   k95 ; k95 = 80
.line	738	loadk        r46   k96 ; k96 = 45
.line	738	loadk        r47   k36 ; k36 = 116
.line	738	loadk        r48   k51 ; k51 = 172
.line	738	loadk        r49   k97 ; k97 = 196
.line	738	loadk        r50   k98 ; k98 = 188
.line	738	loadk        r51   k23 ; k23 = 10
.line	738	call         r11    41     2
.line	738	getupval     r12    u1
.line	738	loadk        r13   k99 ; k99 = 135
.line	738	loadk        r14  k100 ; k100 = 119
.line	738	loadk        r15  k101 ; k101 = 125
.line	738	loadk        r16  k102 ; k102 = 13
.line	738	loadk        r17   k65 ; k65 = 108
.line	738	loadk        r18   k34 ; k34 = 243
.line	738	loadk        r19   k71 ; k71 = 131
.line	738	loadk        r20   k65 ; k65 = 108
.line	738	loadk        r21  k103 ; k103 = 248
.line	738	loadk        r22  k104 ; k104 = 55
.line	738	call         r12    11     0
.line	738	setlist       r9     0     1
.line	738	call          r8     2     2
.line	738	gettabup      r9    u0   k66 ; k66 = "tostring"
.line	738	move         r10    r1
.line	738	call          r9     2     2
.line	738	gettabup     r10    u0   k66 ; k66 = "tostring"
.line	738	move         r11    r4
.line	738	call         r10     2     0
.line	738	call          r7     0     2
.label	l330
.line	738	call          r6     2     1
.line	738	return        r0     1
.label	l332
.line	738	gettabup      r6    u0   k66 ; k66 = "tostring"
.line	738	gettable      r7    r3  k105 ; k105 = "AssetId"
.line	738	call          r6     2     2
.line	738	self          r7    r0  k106 ; k106 = "CollectAllLatestAsse" (truncated)
.line	738	call          r7     2     2
.line	738	gettabup      r8    u0  k107 ; k107 = "tonumber"
.line	738	gettable      r9    r3  k105 ; k105 = "AssetId"
.line	738	call          r8     2     2
.line	738	gettable      r8    r7    r8
.line	738	test          r8     1
.line	738	jmp            0  l345
.line	738	gettable      r8    r3  k105 ; k105 = "AssetId"
.line	738	gettable      r8    r7    r8
.label	l345
.line	738	test          r8     0
.line	738	jmp            0  l350
.line	738	gettable      r9    r8  k108 ; k108 = "IsReady"
.line	738	test          r9     1
.line	738	jmp            0  l476
.label	l350
.line	738	gettabup      r9    u0    k0 ; k0 = "print"
.line	738	gettabup     r10    u0    k1 ; k1 = "bWriteLog"
.line	738	test         r10     0
.line	738	jmp            0  l474
.line	738	gettabup     r10    u0    k2 ; k2 = "string"
.line	738	gettable     r10   r10    k3 ; k3 = "format"
.line	738	gettabup     r11    u0    k4 ; k4 = "table"
.line	738	gettable     r11   r11    k5 ; k5 = "concat"
.line	738	newtable     r12     2     0
.line	738	getupval     r13    u1
.line	738	loadk        r14    k6 ; k6 = 177
.line	738	loadk        r15    k7 ; k7 = 122
.line	738	loadk        r16    k8 ; k8 = 126
.line	738	loadk        r17    k9 ; k9 = 49
.line	738	loadk        r18   k10 ; k10 = 120
.line	738	loadk        r19   k11 ; k11 = 255
.line	738	loadk        r20   k12 ; k12 = 205
.line	738	loadk        r21   k13 ; k13 = 35
.line	738	loadk        r22   k14 ; k14 = 175
.line	738	loadk        r23   k15 ; k15 = 19
.line	738	loadk        r24   k16 ; k16 = 235
.line	738	loadk        r25   k17 ; k17 = 176
.line	738	loadk        r26   k18 ; k18 = 251
.line	738	loadk        r27   k19 ; k19 = 219
.line	738	loadk        r28   k20 ; k20 = 223
.line	738	loadk        r29   k11 ; k11 = 255
.line	738	loadk        r30   k21 ; k21 = 115
.line	738	loadk        r31   k22 ; k22 = 81
.line	738	loadk        r32   k23 ; k23 = 10
.line	738	loadk        r33    k9 ; k9 = 49
.line	738	loadk        r34   k24 ; k24 = 142
.line	738	loadk        r35   k16 ; k16 = 235
.line	738	loadk        r36   k25 ; k25 = 174
.line	738	loadk        r37   k26 ; k26 = 14
.line	738	loadk        r38   k27 ; k27 = 247
.line	738	loadk        r39   k28 ; k28 = 27
.line	738	loadk        r40   k29 ; k29 = 250
.line	738	loadk        r41   k30 ; k30 = 145
.line	738	loadk        r42   k31 ; k31 = 245
.line	738	loadk        r43   k32 ; k32 = 249
.line	738	loadk        r44   k33 ; k33 = 200
.line	738	loadk        r45   k34 ; k34 = 243
.line	738	loadk        r46   k35 ; k35 = 107
.line	738	loadk        r47   k36 ; k36 = 116
.line	738	loadk        r48   k37 ; k37 = 58
.line	738	loadk        r49   k38 ; k38 = 39
.line	738	loadk        r50   k39 ; k39 = 153
.line	738	loadk        r51   k40 ; k40 = 194
.line	738	loadk        r52   k41 ; k41 = 148
.line	738	loadk        r53   k42 ; k42 = 3
.line	738	call         r13    41     2
.line	738	getupval     r14    u1
.line	738	loadk        r15   k43 ; k43 = 147
.line	738	loadk        r16   k44 ; k44 = 123
.line	738	loadk        r17   k45 ; k45 = 93
.line	738	loadk        r18   k38 ; k38 = 39
.line	738	loadk        r19   k46 ; k46 = 104
.line	738	loadk        r20   k27 ; k27 = 247
.line	738	loadk        r21   k12 ; k12 = 205
.line	738	loadk        r22   k47 ; k47 = 41
.line	738	loadk        r23   k48 ; k48 = 158
.line	738	loadk        r24   k49 ; k49 = 44
.line	738	loadk        r25   k50 ; k50 = 229
.line	738	loadk        r26   k51 ; k51 = 172
.line	738	loadk        r27   k27 ; k27 = 247
.line	738	loadk        r28   k11 ; k11 = 255
.line	738	loadk        r29   k34 ; k34 = 243
.line	738	loadk        r30   k12 ; k12 = 205
.line	738	loadk        r31   k52 ; k52 = 114
.line	738	loadk        r32   k53 ; k53 = 65
.line	738	loadk        r33   k54 ; k54 = 121
.line	738	loadk        r34   k69 ; k69 = 105
.line	738	loadk        r35   k70 ; k70 = 204
.line	738	loadk        r36   k71 ; k71 = 131
.line	738	loadk        r37   k72 ; k72 = 186
.line	738	loadk        r38   k73 ; k73 = 92
.line	738	loadk        r39  k109 ; k109 = 163
.line	738	loadk        r40  k110 ; k110 = 59
.line	738	loadk        r41   k75 ; k75 = 224
.line	738	loadk        r42  k111 ; k111 = 242
.line	738	loadk        r43  k112 ; k112 = 233
.line	738	loadk        r44   k78 ; k78 = 228
.line	738	loadk        r45  k113 ; k113 = 156
.line	738	loadk        r46  k114 ; k114 = 221
.line	738	loadk        r47  k115 ; k115 = 106
.line	738	loadk        r48  k116 ; k116 = 89
.line	738	loadk        r49  k117 ; k117 = 5
.line	738	loadk        r50  k118 ; k118 = 53
.line	738	loadk        r51   k87 ; k87 = 136
.line	738	loadk        r52   k93 ; k93 = 211
.line	738	loadk        r53  k119 ; k119 = 170
.line	738	loadk        r54  k120 ; k120 = 24
.line	738	call         r14    41     2
.line	738	getupval     r15    u1
.line	738	loadk        r16   k91 ; k91 = 167
.line	738	loadk        r17  k121 ; k121 = 102
.line	738	loadk        r18  k122 ; k122 = 90
.line	738	loadk        r19  k123 ; k123 = 17
.line	738	loadk        r20   k46 ; k46 = 104
.line	738	loadk        r21   k50 ; k50 = 229
.line	738	loadk        r22   k39 ; k39 = 153
.line	738	loadk        r23   k13 ; k13 = 35
.line	738	loadk        r24   k14 ; k14 = 175
.line	738	loadk        r25  k124 ; k124 = 100
.line	738	loadk        r26  k125 ; k125 = 234
.line	738	loadk        r27  k126 ; k126 = 173
.line	738	loadk        r28   k78 ; k78 = 228
.line	738	loadk        r29   k72 ; k72 = 186
.line	738	loadk        r30  k127 ; k127 = 222
.line	738	loadk        r31  k112 ; k112 = 233
.line	738	loadk        r32  k100 ; k100 = 119
.line	738	loadk        r33   k53 ; k53 = 65
.line	738	loadk        r34   k82 ; k82 = 32
.line	738	loadk        r35   k46 ; k46 = 104
.line	738	loadk        r36   k70 ; k70 = 204
.line	738	loadk        r37   k56 ; k56 = 213
.line	738	loadk        r38  k128 ; k128 = 162
.line	738	loadk        r39   k59 ; k59 = 21
.line	738	loadk        r40   k57 ; k57 = 189
.line	738	call         r15    26     0
.line	738	setlist      r12     0     1
.line	738	call         r11     2     2
.line	738	move         r12    r6
.line	738	call         r10     3     2
.label	l474
.line	738	call          r9     2     1
.line	738	return        r0     1
.label	l476
.line	738	gettable      r9    r0  k129 ; k129 = "UnloadingAssetIds"
.line	738	test          r9     0
.line	738	jmp            0  l484
.line	738	gettable      r9    r0  k129 ; k129 = "UnloadingAssetIds"
.line	738	gettable      r9    r9    r6
.line	738	test          r9     0
.line	738	jmp            0  l484
.line	738	return        r0     1
.label	l484
.line	738	self          r9    r0  k130 ; k130 = "IsAssetInPathMap"
.line	738	gettable     r11    r3  k105 ; k105 = "AssetId"
.line	738	move         r12    r5
.line	738	call          r9     4     2
.line	738	test          r9     0
.line	738	jmp            0  l598
.line	738	gettabup      r9    u0    k0 ; k0 = "print"
.line	738	gettabup     r10    u0    k1 ; k1 = "bWriteLog"
.line	738	test         r10     0
.line	738	jmp            0  l596
.line	738	gettabup     r10    u0    k2 ; k2 = "string"
.line	738	gettable     r10   r10    k3 ; k3 = "format"
.line	738	gettabup     r11    u0    k4 ; k4 = "table"
.line	738	gettable     r11   r11    k5 ; k5 = "concat"
.line	738	newtable     r12     2     0
.line	738	getupval     r13    u1
.line	738	loadk        r14    k6 ; k6 = 177
.line	738	loadk        r15    k7 ; k7 = 122
.line	738	loadk        r16    k8 ; k8 = 126
.line	738	loadk        r17    k9 ; k9 = 49
.line	738	loadk        r18   k10 ; k10 = 120
.line	738	loadk        r19   k11 ; k11 = 255
.line	738	loadk        r20   k12 ; k12 = 205
.line	738	loadk        r21   k13 ; k13 = 35
.line	738	loadk        r22   k14 ; k14 = 175
.line	738	loadk        r23   k15 ; k15 = 19
.line	738	loadk        r24   k16 ; k16 = 235
.line	738	loadk        r25   k17 ; k17 = 176
.line	738	loadk        r26   k18 ; k18 = 251
.line	738	loadk        r27   k19 ; k19 = 219
.line	738	loadk        r28   k20 ; k20 = 223
.line	738	loadk        r29   k11 ; k11 = 255
.line	738	loadk        r30   k21 ; k21 = 115
.line	738	loadk        r31   k22 ; k22 = 81
.line	738	loadk        r32   k23 ; k23 = 10
.line	738	loadk        r33    k9 ; k9 = 49
.line	738	loadk        r34   k24 ; k24 = 142
.line	738	loadk        r35   k16 ; k16 = 235
.line	738	loadk        r36   k25 ; k25 = 174
.line	738	loadk        r37   k26 ; k26 = 14
.line	738	loadk        r38   k27 ; k27 = 247
.line	738	loadk        r39   k28 ; k28 = 27
.line	738	loadk        r40   k29 ; k29 = 250
.line	738	loadk        r41   k30 ; k30 = 145
.line	738	loadk        r42   k31 ; k31 = 245
.line	738	loadk        r43   k32 ; k32 = 249
.line	738	loadk        r44   k33 ; k33 = 200
.line	738	loadk        r45   k34 ; k34 = 243
.line	738	loadk        r46   k35 ; k35 = 107
.line	738	loadk        r47   k36 ; k36 = 116
.line	738	loadk        r48   k37 ; k37 = 58
.line	738	loadk        r49   k38 ; k38 = 39
.line	738	loadk        r50   k39 ; k39 = 153
.line	738	loadk        r51   k40 ; k40 = 194
.line	738	loadk        r52   k41 ; k41 = 148
.line	738	loadk        r53   k42 ; k42 = 3
.line	738	call         r13    41     2
.line	738	getupval     r14    u1
.line	738	loadk        r15   k43 ; k43 = 147
.line	738	loadk        r16   k44 ; k44 = 123
.line	738	loadk        r17   k45 ; k45 = 93
.line	738	loadk        r18   k38 ; k38 = 39
.line	738	loadk        r19   k46 ; k46 = 104
.line	738	loadk        r20   k27 ; k27 = 247
.line	738	loadk        r21   k12 ; k12 = 205
.line	738	loadk        r22   k47 ; k47 = 41
.line	738	loadk        r23   k48 ; k48 = 158
.line	738	loadk        r24   k49 ; k49 = 44
.line	738	loadk        r25   k50 ; k50 = 229
.line	738	loadk        r26   k51 ; k51 = 172
.line	738	loadk        r27   k27 ; k27 = 247
.line	738	loadk        r28   k11 ; k11 = 255
.line	738	loadk        r29   k34 ; k34 = 243
.line	738	loadk        r30   k12 ; k12 = 205
.line	738	loadk        r31   k52 ; k52 = 114
.line	738	loadk        r32   k53 ; k53 = 65
.line	738	loadk        r33   k54 ; k54 = 121
.line	738	loadk        r34   k69 ; k69 = 105
.line	738	loadk        r35   k70 ; k70 = 204
.line	738	loadk        r36   k71 ; k71 = 131
.line	738	loadk        r37   k72 ; k72 = 186
.line	738	loadk        r38   k73 ; k73 = 92
.line	738	loadk        r39   k51 ; k51 = 172
.line	738	loadk        r40  k131 ; k131 = 56
.line	738	loadk        r41  k132 ; k132 = 230
.line	738	loadk        r42  k133 ; k133 = 183
.line	738	loadk        r43  k134 ; k134 = 225
.line	738	loadk        r44   k94 ; k94 = 238
.line	738	loadk        r45  k135 ; k135 = 197
.line	738	loadk        r46   k98 ; k98 = 188
.line	738	loadk        r47  k136 ; k136 = 111
.line	738	loadk        r48   k81 ; k81 = 91
.line	738	loadk        r49   k69 ; k69 = 105
.line	738	loadk        r50   k59 ; k59 = 21
.line	738	loadk        r51  k137 ; k137 = 143
.line	738	loadk        r52  k135 ; k135 = 197
.line	738	loadk        r53   k98 ; k98 = 188
.line	738	loadk        r54  k120 ; k120 = 24
.line	738	call         r14    41     2
.line	738	getupval     r15    u1
.line	738	loadk        r16   k85 ; k85 = 182
.line	738	loadk        r17   k36 ; k36 = 116
.line	738	loadk        r18   k45 ; k45 = 93
.line	738	loadk        r19  k138 ; k138 = 28
.line	738	loadk        r20   k22 ; k22 = 81
.line	738	loadk        r21   k27 ; k27 = 247
.line	738	loadk        r22   k77 ; k77 = 201
.line	738	call         r15     8     0
.line	738	setlist      r12     0     1
.line	738	call         r11     2     2
.line	738	move         r12    r6
.line	738	call         r10     3     2
.label	l596
.line	738	call          r9     2     1
.line	738	return        r0     1
.label	l598
.line	738	gettable      r9    r8  k139 ; k139 = "FolderID"
.line	738	test          r9     1
.line	738	jmp            0  l604
.line	738	self          r9    r0  k140 ; k140 = "GetFolderIDForAssetT" (truncated)
.line	738	move         r11    r5
.line	738	call          r9     3     2
.label	l604
.line	738	gettabup     r10    u0  k107 ; k107 = "tonumber"
.line	738	gettable     r11    r3  k105 ; k105 = "AssetId"
.line	738	call         r10     2     2
.line	738	test         r10     0
.line	738	jmp            0  l746
.line	738	gettable     r11    r0  k141 ; k141 = "ImportingAssetMap"
.line	738	test         r11     0
.line	738	jmp            0  l746
.line	738	gettable     r11    r0  k141 ; k141 = "ImportingAssetMap"
.line	738	gettable     r11   r11   r10
.line	738	test         r11     0
.line	738	jmp            0  l746
.line	738	gettable     r11    r0  k141 ; k141 = "ImportingAssetMap"
.line	738	gettable      r9   r11   r10
.line	738	self         r11    r0  k142 ; k142 = "AddAssetToPathMapOnI" (truncated)
.line	738	move         r13    r6
.line	738	move         r14    r9
.line	738	call         r11     4     1
.line	738	self         r11    r0  k143 ; k143 = "SyncWorkAssetDataToE" (truncated)
.line	738	call         r11     2     1
.line	738	gettabup     r11    u0    k0 ; k0 = "print"
.line	738	gettabup     r12    u0    k1 ; k1 = "bWriteLog"
.line	738	test         r12     0
.line	738	jmp            0  l745
.line	738	gettabup     r12    u0    k2 ; k2 = "string"
.line	738	gettable     r12   r12    k3 ; k3 = "format"
.line	738	gettabup     r13    u0    k4 ; k4 = "table"
.line	738	gettable     r13   r13    k5 ; k5 = "concat"
.line	738	newtable     r14     2     0
.line	738	getupval     r15    u1
.line	738	loadk        r16    k6 ; k6 = 177
.line	738	loadk        r17    k7 ; k7 = 122
.line	738	loadk        r18    k8 ; k8 = 126
.line	738	loadk        r19    k9 ; k9 = 49
.line	738	loadk        r20   k10 ; k10 = 120
.line	738	loadk        r21   k11 ; k11 = 255
.line	738	loadk        r22   k12 ; k12 = 205
.line	738	loadk        r23   k13 ; k13 = 35
.line	738	loadk        r24   k14 ; k14 = 175
.line	738	loadk        r25   k15 ; k15 = 19
.line	738	loadk        r26   k16 ; k16 = 235
.line	738	loadk        r27   k17 ; k17 = 176
.line	738	loadk        r28   k18 ; k18 = 251
.line	738	loadk        r29   k19 ; k19 = 219
.line	738	loadk        r30   k20 ; k20 = 223
.line	738	loadk        r31   k11 ; k11 = 255
.line	738	loadk        r32   k21 ; k21 = 115
.line	738	loadk        r33   k22 ; k22 = 81
.line	738	loadk        r34   k23 ; k23 = 10
.line	738	loadk        r35    k9 ; k9 = 49
.line	738	loadk        r36   k24 ; k24 = 142
.line	738	loadk        r37   k16 ; k16 = 235
.line	738	loadk        r38   k25 ; k25 = 174
.line	738	loadk        r39   k26 ; k26 = 14
.line	738	loadk        r40   k27 ; k27 = 247
.line	738	loadk        r41   k28 ; k28 = 27
.line	738	loadk        r42   k29 ; k29 = 250
.line	738	loadk        r43   k30 ; k30 = 145
.line	738	loadk        r44   k31 ; k31 = 245
.line	738	loadk        r45   k32 ; k32 = 249
.line	738	loadk        r46   k33 ; k33 = 200
.line	738	loadk        r47   k34 ; k34 = 243
.line	738	loadk        r48   k35 ; k35 = 107
.line	738	loadk        r49   k36 ; k36 = 116
.line	738	loadk        r50   k37 ; k37 = 58
.line	738	loadk        r51   k38 ; k38 = 39
.line	738	loadk        r52   k39 ; k39 = 153
.line	738	loadk        r53   k40 ; k40 = 194
.line	738	loadk        r54   k41 ; k41 = 148
.line	738	loadk        r55   k42 ; k42 = 3
.line	738	call         r15    41     2
.line	738	getupval     r16    u1
.line	738	loadk        r17   k43 ; k43 = 147
.line	738	loadk        r18   k44 ; k44 = 123
.line	738	loadk        r19   k45 ; k45 = 93
.line	738	loadk        r20   k38 ; k38 = 39
.line	738	loadk        r21   k46 ; k46 = 104
.line	738	loadk        r22   k27 ; k27 = 247
.line	738	loadk        r23   k12 ; k12 = 205
.line	738	loadk        r24   k47 ; k47 = 41
.line	738	loadk        r25   k48 ; k48 = 158
.line	738	loadk        r26   k49 ; k49 = 44
.line	738	loadk        r27   k50 ; k50 = 229
.line	738	loadk        r28   k51 ; k51 = 172
.line	738	loadk        r29   k27 ; k27 = 247
.line	738	loadk        r30   k11 ; k11 = 255
.line	738	loadk        r31   k34 ; k34 = 243
.line	738	loadk        r32   k12 ; k12 = 205
.line	738	loadk        r33   k52 ; k52 = 114
.line	738	loadk        r34   k53 ; k53 = 65
.line	738	loadk        r35   k54 ; k54 = 121
.line	738	loadk        r36   k69 ; k69 = 105
.line	738	loadk        r37   k70 ; k70 = 204
.line	738	loadk        r38   k71 ; k71 = 131
.line	738	loadk        r39   k72 ; k72 = 186
.line	738	loadk        r40   k73 ; k73 = 92
.line	738	loadk        r41   k51 ; k51 = 172
.line	738	loadk        r42  k144 ; k144 = 48
.line	738	loadk        r43   k92 ; k92 = 240
.line	738	loadk        r44  k133 ; k133 = 183
.line	738	loadk        r45   k78 ; k78 = 228
.line	738	loadk        r46  k119 ; k119 = 170
.line	738	loadk        r47   k33 ; k33 = 200
.line	738	loadk        r48   k34 ; k34 = 243
.line	738	loadk        r49   k80 ; k80 = 38
.line	738	loadk        r50   k36 ; k36 = 116
.line	738	loadk        r51   k37 ; k37 = 58
.line	738	loadk        r52   k38 ; k38 = 39
.line	738	loadk        r53   k39 ; k39 = 153
.line	738	loadk        r54   k40 ; k40 = 194
.line	738	loadk        r55  k145 ; k145 = 137
.line	738	loadk        r56  k102 ; k102 = 13
.line	738	call         r16    41     2
.line	738	getupval     r17    u1
.line	738	loadk        r18  k146 ; k146 = 146
.line	738	loadk        r19  k101 ; k101 = 125
.line	738	loadk        r20  k124 ; k124 = 100
.line	738	loadk        r21   k59 ; k59 = 21
.line	738	loadk        r22   k65 ; k65 = 108
.line	738	loadk        r23   k72 ; k72 = 186
.line	738	loadk        r24   k39 ; k39 = 153
.line	738	loadk        r25   k23 ; k23 = 10
.line	738	loadk        r26  k147 ; k147 = 178
.line	738	loadk        r27  k148 ; k148 = 40
.line	738	loadk        r28   k75 ; k75 = 224
.line	738	loadk        r29   k91 ; k91 = 167
.line	738	loadk        r30  k149 ; k149 = 226
.line	738	loadk        r31   k93 ; k93 = 211
.line	738	loadk        r32  k150 ; k150 = 232
.line	738	loadk        r33   k85 ; k85 = 182
.line	738	loadk        r34  k151 ; k151 = 54
.line	738	loadk        r35  k152 ; k152 = 0
.line	738	loadk        r36  k153 ; k153 = 42
.line	738	call         r17    20     0
.line	738	setlist      r14     0     1
.line	738	call         r13     2     2
.line	738	move         r14    r6
.line	738	gettabup     r15    u0   k66 ; k66 = "tostring"
.line	738	move         r16    r9
.line	738	call         r15     2     0
.line	738	call         r12     0     2
.label	l745
.line	738	call         r11     2     1
.label	l746
.line	738	return        r0     1
.line	738	move          r0    r0
.line	738	move          r0    r0
.line	738	move          r0    r0
.line	738	move          r0    r0
.line	738	return        r0     1

.function	main/f27

.source	null
.linedefined	776
.lastlinedefined	813
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true
.upvalue	"U3"	18	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	177
.constant	k7	122
.constant	k8	126
.constant	k9	49
.constant	k10	120
.constant	k11	255
.constant	k12	205
.constant	k13	35
.constant	k14	175
.constant	k15	19
.constant	k16	235
.constant	k17	176
.constant	k18	251
.constant	k19	219
.constant	k20	223
.constant	k21	115
.constant	k22	81
.constant	k23	10
.constant	k24	142
.constant	k25	174
.constant	k26	14
.constant	k27	247
.constant	k28	27
.constant	k29	250
.constant	k30	145
.constant	k31	245
.constant	k32	249
.constant	k33	200
.constant	k34	243
.constant	k35	107
.constant	k36	116
.constant	k37	58
.constant	k38	39
.constant	k39	153
.constant	k40	194
.constant	k41	148
.constant	k42	3
.constant	k43	147
.constant	k44	123
.constant	k45	93
.constant	k46	104
.constant	k47	41
.constant	k48	158
.constant	k49	44
.constant	k50	229
.constant	k51	172
.constant	k52	222
.constant	k53	72
.constant	k54	54
.constant	k55	50
.constant	k56	137
.constant	k57	134
.constant	k58	138
.constant	k59	9
.constant	k60	190
.constant	k61	32
.constant	k62	191
.constant	k63	193
.constant	k64	207
.constant	k65	114
.constant	k66	45
.constant	k67	198
.constant	k68	170
.constant	k69	"tostring"
.constant	k70	"GetMetaInfoByCustomAssetKey"
.constant	k71	"Meta"
.constant	k72	"AssetId"
.constant	k73	"PrefabType"
.constant	k74	"AssetPathMap"
.constant	k75	1
.constant	k76	-1
.constant	k77	"AssetUID"
.constant	k78	nil
.constant	k79	"AssetType"
.constant	k80	"remove"
.constant	k81	"tonumber"
.constant	k82	"ImportingAssetMap"
.constant	k83	"UnloadingAssetIds"
.constant	k84	"CustomAssetKey"
.constant	k85	"SaveAssetPathMap"
.constant	k86	"SyncWorkAssetDataToEditor"

.line	776	gettabup      r2    u0    k0 ; k0 = "print"
.line	776	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	776	test          r3     0
.line	776	jmp            0   l99
.line	776	gettabup      r3    u0    k2 ; k2 = "string"
.line	776	gettable      r3    r3    k3 ; k3 = "format"
.line	776	gettabup      r4    u0    k4 ; k4 = "table"
.line	776	gettable      r4    r4    k5 ; k5 = "concat"
.line	776	newtable      r5     1     0
.line	776	getupval      r6    u1
.line	776	loadk         r7    k6 ; k6 = 177
.line	776	loadk         r8    k7 ; k7 = 122
.line	776	loadk         r9    k8 ; k8 = 126
.line	776	loadk        r10    k9 ; k9 = 49
.line	776	loadk        r11   k10 ; k10 = 120
.line	776	loadk        r12   k11 ; k11 = 255
.line	776	loadk        r13   k12 ; k12 = 205
.line	776	loadk        r14   k13 ; k13 = 35
.line	776	loadk        r15   k14 ; k14 = 175
.line	776	loadk        r16   k15 ; k15 = 19
.line	776	loadk        r17   k16 ; k16 = 235
.line	776	loadk        r18   k17 ; k17 = 176
.line	776	loadk        r19   k18 ; k18 = 251
.line	776	loadk        r20   k19 ; k19 = 219
.line	776	loadk        r21   k20 ; k20 = 223
.line	776	loadk        r22   k11 ; k11 = 255
.line	776	loadk        r23   k21 ; k21 = 115
.line	776	loadk        r24   k22 ; k22 = 81
.line	776	loadk        r25   k23 ; k23 = 10
.line	776	loadk        r26    k9 ; k9 = 49
.line	776	loadk        r27   k24 ; k24 = 142
.line	776	loadk        r28   k16 ; k16 = 235
.line	776	loadk        r29   k25 ; k25 = 174
.line	776	loadk        r30   k26 ; k26 = 14
.line	776	loadk        r31   k27 ; k27 = 247
.line	776	loadk        r32   k28 ; k28 = 27
.line	776	loadk        r33   k29 ; k29 = 250
.line	776	loadk        r34   k30 ; k30 = 145
.line	776	loadk        r35   k31 ; k31 = 245
.line	776	loadk        r36   k32 ; k32 = 249
.line	776	loadk        r37   k33 ; k33 = 200
.line	776	loadk        r38   k34 ; k34 = 243
.line	776	loadk        r39   k35 ; k35 = 107
.line	776	loadk        r40   k36 ; k36 = 116
.line	776	loadk        r41   k37 ; k37 = 58
.line	776	loadk        r42   k38 ; k38 = 39
.line	776	loadk        r43   k39 ; k39 = 153
.line	776	loadk        r44   k40 ; k40 = 194
.line	776	loadk        r45   k41 ; k41 = 148
.line	776	loadk        r46   k42 ; k42 = 3
.line	776	call          r6    41     2
.line	776	getupval      r7    u1
.line	776	loadk         r8   k43 ; k43 = 147
.line	776	loadk         r9   k44 ; k44 = 123
.line	776	loadk        r10   k45 ; k45 = 93
.line	776	loadk        r11   k38 ; k38 = 39
.line	776	loadk        r12   k46 ; k46 = 104
.line	776	loadk        r13   k27 ; k27 = 247
.line	776	loadk        r14   k12 ; k12 = 205
.line	776	loadk        r15   k47 ; k47 = 41
.line	776	loadk        r16   k48 ; k48 = 158
.line	776	loadk        r17   k49 ; k49 = 44
.line	776	loadk        r18   k50 ; k50 = 229
.line	776	loadk        r19   k51 ; k51 = 172
.line	776	loadk        r20   k27 ; k27 = 247
.line	776	loadk        r21   k11 ; k11 = 255
.line	776	loadk        r22   k34 ; k34 = 243
.line	776	loadk        r23   k52 ; k52 = 222
.line	776	loadk        r24   k21 ; k21 = 115
.line	776	loadk        r25   k53 ; k53 = 72
.line	776	loadk        r26   k54 ; k54 = 54
.line	776	loadk        r27   k55 ; k55 = 50
.line	776	loadk        r28   k56 ; k56 = 137
.line	776	loadk        r29   k57 ; k57 = 134
.line	776	loadk        r30   k58 ; k58 = 138
.line	776	loadk        r31   k59 ; k59 = 9
.line	776	loadk        r32   k60 ; k60 = 190
.line	776	loadk        r33   k61 ; k61 = 32
.line	776	loadk        r34   k18 ; k18 = 251
.line	776	loadk        r35   k62 ; k62 = 191
.line	776	loadk        r36   k63 ; k63 = 193
.line	776	loadk        r37   k32 ; k32 = 249
.line	776	loadk        r38   k64 ; k64 = 207
.line	776	loadk        r39   k32 ; k32 = 249
.line	776	loadk        r40   k65 ; k65 = 114
.line	776	loadk        r41    k8 ; k8 = 126
.line	776	loadk        r42   k49 ; k49 = 44
.line	776	loadk        r43   k66 ; k66 = 45
.line	776	loadk        r44   k67 ; k67 = 198
.line	776	loadk        r45   k43 ; k43 = 147
.line	776	loadk        r46   k68 ; k68 = 170
.line	776	call          r7    40     0
.line	776	setlist       r5     0     1
.line	776	call          r4     2     2
.line	776	gettabup      r5    u0   k69 ; k69 = "tostring"
.line	776	move          r6    r1
.line	776	call          r5     2     0
.line	776	call          r3     0     2
.label	l99
.line	776	call          r2     2     1
.line	776	getupval      r2    u2
.line	776	self          r2    r2   k70 ; k70 = "GetMetaInfoByCustomA" (truncated)
.line	776	move          r4    r1
.line	776	call          r2     3     2
.line	776	loadnil       r3     1
.line	776	test          r2     0
.line	776	jmp            0  l118
.line	776	gettable      r5    r2   k71 ; k71 = "Meta"
.line	776	test          r5     0
.line	776	jmp            0  l118
.line	776	gettabup      r5    u0   k69 ; k69 = "tostring"
.line	776	gettable      r6    r2   k71 ; k71 = "Meta"
.line	776	gettable      r6    r6   k72 ; k72 = "AssetId"
.line	776	call          r5     2     2
.line	776	move          r3    r5
.line	776	gettable      r5    r2   k71 ; k71 = "Meta"
.line	776	gettable      r5    r5   k73 ; k73 = "PrefabType"
.line	776	gettabup      r4    u3    r5
.label	l118
.line	776	loadbool      r5     0     0
.line	776	test          r3     0
.line	776	jmp            0  l164
.line	776	gettable      r6    r0   k74 ; k74 = "AssetPathMap"
.line	776	len           r6    r6
.line	776	loadk         r7   k75 ; k75 = 1
.line	776	loadk         r8   k76 ; k76 = -1
.line	776	move          r0    r0
.line	776	gettabup     r10    u0   k69 ; k69 = "tostring"
.line	776	gettable     r11    r0   k74 ; k74 = "AssetPathMap"
.line	776	gettable     r11   r11    r9
.line	776	gettable     r11   r11   k77 ; k77 = "AssetUID"
.line	776	call         r10     2     2
.line	776	eq             0   r10    r3
.line	776	jmp            0  l147
.line	776	eq             1    r4   k78 ; k78 = nil
.line	776	jmp            0  l140
.line	776	gettable     r10    r0   k74 ; k74 = "AssetPathMap"
.line	776	gettable     r10   r10    r9
.line	776	gettable     r10   r10   k79 ; k79 = "AssetType"
.line	776	eq             0   r10    r4
.line	776	jmp            0  l147
.label	l140
.line	776	gettabup     r10    u0    k4 ; k4 = "table"
.line	776	gettable     r10   r10   k80 ; k80 = "remove"
.line	776	gettable     r11    r0   k74 ; k74 = "AssetPathMap"
.line	776	move         r12    r9
.line	776	call         r10     3     1
.line	776	loadbool      r5     1     0
.line	776	jmp            0  l148
.label	l147
.line	776	move          r0    r0
.label	l148
.line	776	gettabup      r6    u0   k81 ; k81 = "tonumber"
.line	776	move          r7    r3
.line	776	call          r6     2     2
.line	776	test          r6     0
.line	776	jmp            0  l158
.line	776	gettable      r7    r0   k82 ; k82 = "ImportingAssetMap"
.line	776	test          r7     0
.line	776	jmp            0  l158
.line	776	gettable      r7    r0   k82 ; k82 = "ImportingAssetMap"
.line	776	settable      r7    r6   k78 ; k78 = nil
.label	l158
.line	776	gettable      r7    r0   k83 ; k83 = "UnloadingAssetIds"
.line	776	test          r7     0
.line	776	jmp            0  l187
.line	776	gettable      r7    r0   k83 ; k83 = "UnloadingAssetIds"
.line	776	settable      r7    r3   k78 ; k78 = nil
.line	776	jmp            0  l187
.label	l164
.line	776	gettable      r6    r0   k74 ; k74 = "AssetPathMap"
.line	776	len           r6    r6
.line	776	loadk         r7   k75 ; k75 = 1
.line	776	loadk         r8   k76 ; k76 = -1
.line	776	move          r0    r0
.line	776	gettabup     r10    u0   k69 ; k69 = "tostring"
.line	776	gettable     r11    r0   k74 ; k74 = "AssetPathMap"
.line	776	gettable     r11   r11    r9
.line	776	gettable     r11   r11   k84 ; k84 = "CustomAssetKey"
.line	776	call         r10     2     2
.line	776	gettabup     r11    u0   k69 ; k69 = "tostring"
.line	776	move         r12    r1
.line	776	call         r11     2     2
.line	776	eq             0   r10   r11
.line	776	jmp            0  l186
.line	776	gettabup     r10    u0    k4 ; k4 = "table"
.line	776	gettable     r10   r10   k80 ; k80 = "remove"
.line	776	gettable     r11    r0   k74 ; k74 = "AssetPathMap"
.line	776	move         r12    r9
.line	776	call         r10     3     1
.line	776	loadbool      r5     1     0
.line	776	jmp            0  l187
.label	l186
.line	776	move          r0    r0
.label	l187
.line	776	test          r5     0
.line	776	jmp            0  l193
.line	776	self          r6    r0   k85 ; k85 = "SaveAssetPathMap"
.line	776	call          r6     2     1
.line	776	self          r6    r0   k86 ; k86 = "SyncWorkAssetDataToE" (truncated)
.line	776	call          r6     2     1
.label	l193
.line	776	return        r0     1
.line	776	move          r0    r0
.line	776	return        r0     1

.function	main/f28

.source	null
.linedefined	815
.lastlinedefined	887
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	11	true
.upvalue	"U3"	12	true
.upvalue	"U4"	15	true
.upvalue	"U5"	10	true
.upvalue	"U6"	13	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	177
.constant	k5	122
.constant	k6	126
.constant	k7	49
.constant	k8	120
.constant	k9	255
.constant	k10	205
.constant	k11	35
.constant	k12	175
.constant	k13	19
.constant	k14	235
.constant	k15	176
.constant	k16	251
.constant	k17	219
.constant	k18	223
.constant	k19	115
.constant	k20	81
.constant	k21	10
.constant	k22	142
.constant	k23	174
.constant	k24	14
.constant	k25	247
.constant	k26	7
.constant	k27	237
.constant	k28	188
.constant	k29	227
.constant	k30	207
.constant	k31	218
.constant	k32	250
.constant	k33	99
.constant	k34	86
.constant	k35	61
.constant	k36	16
.constant	k37	157
.constant	k38	194
.constant	k39	184
.constant	k40	56
.constant	k41	137
.constant	k42	84
.constant	k43	90
.constant	k44	121
.constant	k45	226
.constant	k46	233
.constant	k47	45
.constant	k48	169
.constant	k49	44
.constant	k50	201
.constant	k51	163
.constant	k52	224
.constant	k53	"GetGameParameterManager"
.constant	k54	"GetGameParameter"
.constant	k55	"Value"
.constant	k56	"ipairs"
.constant	k57	"ConfigId"
.constant	k58	"DefaultConfigId"
.constant	k59	"AssetPathMap"
.constant	k60	1
.constant	k61	-1
.constant	k62	"AssetType"
.constant	k63	"Effect"
.constant	k64	"tonumber"
.constant	k65	"AssetUID"
.constant	k66	"remove"
.constant	k67	"pairs"
.constant	k68	"IsAssetInPathMap"
.constant	k69	"GetTemplate"
.constant	k70	"ParticleName"
.constant	k71	0
.constant	k72	"LocUtil"
.constant	k73	"GetLocalizeResStr"
.constant	k74	"IconPath"
.constant	k75	"GetFolderIDForAssetType"
.constant	k76	"tostring"
.constant	k77	"AssetName"
.constant	k78	"FolderID"
.constant	k79	"Icon"
.constant	k80	"Desc"
.constant	k81	"GetAssetRestrictions"
.constant	k82	"ApplyAssetRestrictions"
.constant	k83	"insert"
.constant	k84	"SaveAssetPathMap"

.line	815	gettabup      r1    u0    k0 ; k0 = "print"
.line	815	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	815	test          r2     0
.line	815	jmp            0   l67
.line	815	gettabup      r2    u0    k2 ; k2 = "table"
.line	815	gettable      r2    r2    k3 ; k3 = "concat"
.line	815	newtable      r3     1     0
.line	815	getupval      r4    u1
.line	815	loadk         r5    k4 ; k4 = 177
.line	815	loadk         r6    k5 ; k5 = 122
.line	815	loadk         r7    k6 ; k6 = 126
.line	815	loadk         r8    k7 ; k7 = 49
.line	815	loadk         r9    k8 ; k8 = 120
.line	815	loadk        r10    k9 ; k9 = 255
.line	815	loadk        r11   k10 ; k10 = 205
.line	815	loadk        r12   k11 ; k11 = 35
.line	815	loadk        r13   k12 ; k12 = 175
.line	815	loadk        r14   k13 ; k13 = 19
.line	815	loadk        r15   k14 ; k14 = 235
.line	815	loadk        r16   k15 ; k15 = 176
.line	815	loadk        r17   k16 ; k16 = 251
.line	815	loadk        r18   k17 ; k17 = 219
.line	815	loadk        r19   k18 ; k18 = 223
.line	815	loadk        r20    k9 ; k9 = 255
.line	815	loadk        r21   k19 ; k19 = 115
.line	815	loadk        r22   k20 ; k20 = 81
.line	815	loadk        r23   k21 ; k21 = 10
.line	815	loadk        r24    k7 ; k7 = 49
.line	815	loadk        r25   k22 ; k22 = 142
.line	815	loadk        r26   k14 ; k14 = 235
.line	815	loadk        r27   k23 ; k23 = 174
.line	815	loadk        r28   k24 ; k24 = 14
.line	815	loadk        r29   k25 ; k25 = 247
.line	815	loadk        r30   k26 ; k26 = 7
.line	815	loadk        r31   k27 ; k27 = 237
.line	815	loadk        r32   k28 ; k28 = 188
.line	815	loadk        r33   k29 ; k29 = 227
.line	815	loadk        r34   k30 ; k30 = 207
.line	815	loadk        r35   k31 ; k31 = 218
.line	815	loadk        r36   k32 ; k32 = 250
.line	815	loadk        r37   k33 ; k33 = 99
.line	815	loadk        r38   k34 ; k34 = 86
.line	815	loadk        r39   k35 ; k35 = 61
.line	815	loadk        r40   k36 ; k36 = 16
.line	815	loadk        r41   k37 ; k37 = 157
.line	815	loadk        r42   k38 ; k38 = 194
.line	815	loadk        r43   k39 ; k39 = 184
.line	815	loadk        r44   k40 ; k40 = 56
.line	815	call          r4    41     2
.line	815	getupval      r5    u1
.line	815	loadk         r6   k41 ; k41 = 137
.line	815	loadk         r7   k42 ; k42 = 84
.line	815	loadk         r8   k43 ; k43 = 90
.line	815	loadk         r9   k26 ; k26 = 7
.line	815	loadk        r10   k44 ; k44 = 121
.line	815	loadk        r11   k45 ; k45 = 226
.line	815	loadk        r12   k46 ; k46 = 233
.line	815	loadk        r13   k47 ; k47 = 45
.line	815	loadk        r14   k48 ; k48 = 169
.line	815	loadk        r15   k49 ; k49 = 44
.line	815	loadk        r16   k50 ; k50 = 201
.line	815	loadk        r17   k51 ; k51 = 163
.line	815	loadk        r18   k52 ; k52 = 224
.line	815	call          r5    14     0
.line	815	setlist       r3     0     1
.line	815	call          r2     2     2
.label	l67
.line	815	call          r1     2     1
.line	815	getupval      r1    u2
.line	815	self          r1    r1   k53 ; k53 = "GetGameParameterMana" (truncated)
.line	815	call          r1     2     2
.line	815	test          r1     1
.line	815	jmp            0   l75
.line	815	loadbool      r2     0     0
.line	815	return        r2     2
.label	l75
.line	815	self          r2    r1   k54 ; k54 = "GetGameParameter"
.line	815	getupval      r4    u3
.line	815	call          r2     3     2
.line	815	test          r2     1
.line	815	jmp            0   l82
.line	815	loadbool      r3     0     0
.line	815	return        r3     2
.label	l82
.line	815	gettable      r3    r2   k55 ; k55 = "Value"
.line	815	test          r3     1
.line	815	jmp            0   l86
.line	815	newtable      r3     0     0
.label	l86
.line	815	newtable      r4     0     0
.line	815	gettabup      r5    u0   k56 ; k56 = "ipairs"
.line	815	move          r6    r3
.line	815	call          r5     2     4
.line	815	jmp            0  l100
.line	815	gettable     r10    r9   k57 ; k57 = "ConfigId"
.line	815	test         r10     0
.line	815	jmp            0  l100
.line	815	gettable     r10    r9   k57 ; k57 = "ConfigId"
.line	815	gettable     r11    r9   k58 ; k58 = "DefaultConfigId"
.line	815	eq             1   r10   r11
.line	815	jmp            0  l100
.line	815	gettable     r10    r9   k57 ; k57 = "ConfigId"
.line	815	settable      r4   r10    r9
.label	l100
.line	815	move          r0    r0
.line	815	move          r0    r0
.line	815	loadbool      r5     0     0
.line	815	gettable      r6    r0   k59 ; k59 = "AssetPathMap"
.line	815	len           r6    r6
.line	815	loadk         r7   k60 ; k60 = 1
.line	815	loadk         r8   k61 ; k61 = -1
.line	815	move          r0    r0
.line	815	gettable     r10    r0   k59 ; k59 = "AssetPathMap"
.line	815	gettable     r10   r10    r9
.line	815	gettable     r11   r10   k62 ; k62 = "AssetType"
.line	815	gettabup     r12    u4   k63 ; k63 = "Effect"
.line	815	eq             0   r11   r12
.line	815	jmp            0  l126
.line	815	gettabup     r11    u0   k64 ; k64 = "tonumber"
.line	815	gettable     r12   r10   k65 ; k65 = "AssetUID"
.line	815	call         r11     2     2
.line	815	gettable     r11    r4   r11
.line	815	test         r11     1
.line	815	jmp            0  l126
.line	815	gettabup     r11    u0    k2 ; k2 = "table"
.line	815	gettable     r11   r11   k66 ; k66 = "remove"
.line	815	gettable     r12    r0   k59 ; k59 = "AssetPathMap"
.line	815	move         r13    r9
.line	815	call         r11     3     1
.line	815	loadbool      r5     1     0
.label	l126
.line	815	move          r0    r0
.line	815	gettabup      r6    u0   k67 ; k67 = "pairs"
.line	815	move          r7    r4
.line	815	call          r6     2     4
.line	815	jmp            0  l190
.line	815	self         r11    r0   k68 ; k68 = "IsAssetInPathMap"
.line	815	move         r13    r9
.line	815	gettabup     r14    u4   k63 ; k63 = "Effect"
.line	815	call         r11     4     2
.line	815	test         r11     1
.line	815	jmp            0  l190
.line	815	gettabup     r11    u5   k69 ; k69 = "GetTemplate"
.line	815	gettable     r12   r10   k58 ; k58 = "DefaultConfigId"
.line	815	call         r11     2     2
.line	815	gettable     r12   r10   k70 ; k70 = "ParticleName"
.line	815	test         r12     1
.line	815	jmp            0  l145
.line	815	getupval     r12    u1
.line	815	call         r12     1     2
.label	l145
.line	815	len          r13   r12
.line	815	eq             0   r13   k71 ; k71 = 0
.line	815	jmp            0  l155
.line	815	test         r11     0
.line	815	jmp            0  l155
.line	815	gettabup     r13    u0   k72 ; k72 = "LocUtil"
.line	815	gettable     r13   r13   k73 ; k73 = "GetLocalizeResStr"
.line	815	gettable     r14   r11   k70 ; k70 = "ParticleName"
.line	815	call         r13     2     2
.line	815	move         r12   r13
.label	l155
.line	815	test         r11     0
.line	815	jmp            0  l160
.line	815	gettable     r13   r11   k74 ; k74 = "IconPath"
.line	815	test         r13     1
.line	815	jmp            0  l161
.label	l160
.line	815	getupval     r13    u6
.label	l161
.line	815	self         r14    r0   k75 ; k75 = "GetFolderIDForAssetT" (truncated)
.line	815	gettabup     r16    u4   k63 ; k63 = "Effect"
.line	815	call         r14     3     2
.line	815	newtable     r15     0     6
.line	815	gettabup     r16    u0   k76 ; k76 = "tostring"
.line	815	move         r17    r9
.line	815	call         r16     2     2
.line	815	settable     r15   k65   r16 ; k65 = "AssetUID"
.line	815	settable     r15   k77   r12 ; k77 = "AssetName"
.line	815	gettabup     r16    u4   k63 ; k63 = "Effect"
.line	815	settable     r15   k62   r16 ; k62 = "AssetType"
.line	815	settable     r15   k78   r14 ; k78 = "FolderID"
.line	815	settable     r15   k79   r13 ; k79 = "Icon"
.line	815	getupval     r16    u1
.line	815	call         r16     1     2
.line	815	settable     r15   k80   r16 ; k80 = "Desc"
.line	815	self         r16    r0   k81 ; k81 = "GetAssetRestrictions"
.line	815	move         r18   r14
.line	815	call         r16     3     2
.line	815	self         r17    r0   k82 ; k82 = "ApplyAssetRestrictio" (truncated)
.line	815	move         r19   r15
.line	815	move         r20   r16
.line	815	call         r17     4     1
.line	815	gettabup     r17    u0    k2 ; k2 = "table"
.line	815	gettable     r17   r17   k83 ; k83 = "insert"
.line	815	gettable     r18    r0   k59 ; k59 = "AssetPathMap"
.line	815	move         r19   r15
.line	815	call         r17     3     1
.line	815	loadbool      r5     1     0
.label	l190
.line	815	move          r0    r0
.line	815	move          r0    r0
.line	815	loadk         r6   k60 ; k60 = 1
.line	815	gettable      r7    r0   k59 ; k59 = "AssetPathMap"
.line	815	len           r7    r7
.line	815	loadk         r8   k60 ; k60 = 1
.line	815	move          r0    r0
.line	815	gettable     r10    r0   k59 ; k59 = "AssetPathMap"
.line	815	gettable     r10   r10    r9
.line	815	gettable     r11   r10   k62 ; k62 = "AssetType"
.line	815	gettabup     r12    u4   k63 ; k63 = "Effect"
.line	815	eq             0   r11   r12
.line	815	jmp            0  l242
.line	815	gettabup     r11    u0   k64 ; k64 = "tonumber"
.line	815	gettable     r12   r10   k65 ; k65 = "AssetUID"
.line	815	call         r11     2     2
.line	815	gettable     r12    r4   r11
.line	815	test         r12     0
.line	815	jmp            0  l242
.line	815	gettabup     r13    u5   k69 ; k69 = "GetTemplate"
.line	815	gettable     r14   r12   k58 ; k58 = "DefaultConfigId"
.line	815	call         r13     2     2
.line	815	gettable     r14   r12   k70 ; k70 = "ParticleName"
.line	815	test         r14     1
.line	815	jmp            0  l217
.line	815	getupval     r14    u1
.line	815	call         r14     1     2
.label	l217
.line	815	len          r15   r14
.line	815	eq             0   r15   k71 ; k71 = 0
.line	815	jmp            0  l227
.line	815	test         r13     0
.line	815	jmp            0  l227
.line	815	gettabup     r15    u0   k72 ; k72 = "LocUtil"
.line	815	gettable     r15   r15   k73 ; k73 = "GetLocalizeResStr"
.line	815	gettable     r16   r13   k70 ; k70 = "ParticleName"
.line	815	call         r15     2     2
.line	815	move         r14   r15
.label	l227
.line	815	test         r13     0
.line	815	jmp            0  l232
.line	815	gettable     r15   r13   k74 ; k74 = "IconPath"
.line	815	test         r15     1
.line	815	jmp            0  l233
.label	l232
.line	815	getupval     r15    u6
.label	l233
.line	815	gettable     r16   r10   k77 ; k77 = "AssetName"
.line	815	eq             0   r16   r14
.line	815	jmp            0  l239
.line	815	gettable     r16   r10   k79 ; k79 = "Icon"
.line	815	eq             1   r16   r15
.line	815	jmp            0  l242
.label	l239
.line	815	settable     r10   k77   r14 ; k77 = "AssetName"
.line	815	settable     r10   k79   r15 ; k79 = "Icon"
.line	815	loadbool      r5     1     0
.label	l242
.line	815	move          r0    r0
.line	815	test          r5     0
.line	815	jmp            0  l247
.line	815	self          r6    r0   k84 ; k84 = "SaveAssetPathMap"
.line	815	call          r6     2     1
.label	l247
.line	815	return        r5     2
.line	815	return        r0     1
.line	815	move          r0    r0
.line	815	move          r0    r0
.line	815	return        r0     1

.function	main/f29

.source	null
.linedefined	889
.lastlinedefined	971
.numparams	1
.is_vararg	0
.maxstacksize	60

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	15	true
.upvalue	"U3"	9	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	177
.constant	k5	122
.constant	k6	126
.constant	k7	49
.constant	k8	120
.constant	k9	255
.constant	k10	205
.constant	k11	35
.constant	k12	175
.constant	k13	19
.constant	k14	235
.constant	k15	176
.constant	k16	251
.constant	k17	219
.constant	k18	223
.constant	k19	115
.constant	k20	81
.constant	k21	10
.constant	k22	142
.constant	k23	174
.constant	k24	14
.constant	k25	247
.constant	k26	7
.constant	k27	237
.constant	k28	188
.constant	k29	227
.constant	k30	203
.constant	k31	232
.constant	k32	105
.constant	k33	71
.constant	k34	13
.constant	k35	53
.constant	k36	136
.constant	k37	215
.constant	k38	141
.constant	k39	3
.constant	k40	167
.constant	k41	102
.constant	k42	90
.constant	k43	17
.constant	k44	104
.constant	k45	198
.constant	k46	216
.constant	k47	56
.constant	k48	181
.constant	k49	9
.constant	k50	229
.constant	k51	178
.constant	k52	"GetCreativeActorDataManager"
.constant	k53	"GetAllUserActorIDs"
.constant	k54	1
.constant	k55	true
.constant	k56	"AssetPathMap"
.constant	k57	-1
.constant	k58	"AssetType"
.constant	k59	"Actor"
.constant	k60	"tonumber"
.constant	k61	"AssetUID"
.constant	k62	"remove"
.constant	k63	"require"
.constant	k64	161
.constant	k65	116
.constant	k66	68
.constant	k67	80
.constant	k68	98
.constant	k69	144
.constant	k70	43
.constant	k71	224
.constant	k72	236
.constant	k73	211
.constant	k74	201
.constant	k75	76
.constant	k76	47
.constant	k77	33
.constant	k78	199
.constant	k79	186
.constant	k80	25
.constant	k81	245
.constant	k82	191
.constant	k83	250
.constant	k84	208
.constant	k85	253
.constant	k86	127
.constant	k87	27
.constant	k88	28
.constant	k89	32
.constant	k90	149
.constant	k91	218
.constant	k92	24
.constant	k93	159
.constant	k94	59
.constant	k95	106
.constant	k96	6
.constant	k97	121
.constant	k98	37
.constant	k99	171
.constant	k100	173
.constant	k101	244
.constant	k102	52
.constant	k103	45
.constant	k104	143
.constant	k105	231
.constant	k106	15
.constant	k107	168
.constant	k108	221
.constant	k109	182
.constant	k110	239
.constant	k111	210
.constant	k112	249
.constant	k113	84
.constant	k114	61
.constant	k115	146
.constant	k116	11
.constant	k117	200
.constant	k118	86
.constant	k119	91
.constant	k120	125
.constant	k121	226
.constant	k122	58
.constant	k123	184
.constant	k124	5
.constant	k125	130
.constant	k126	207
.constant	k127	100
.constant	k128	64
.constant	k129	48
.constant	k130	133
.constant	k131	172
.constant	k132	160
.constant	k133	195
.constant	k134	111
.constant	k135	82
.constant	k136	"IsAssetInPathMap"
.constant	k137	"GetActorDataProxyByID"
.constant	k138	"ImportingActorFolderMap"
.constant	k139	nil
.constant	k140	"DefaultAbstractClassConfig"
.constant	k141	"OverrideConfigActorID"
.constant	k142	"ActorID"
.constant	k143	"DefaultAbstractClassID"
.constant	k144	"DefaultSubFolderID"
.constant	k145	"GetFolderIDForAssetType"
.constant	k146	"log_format"
.constant	k147	74
.constant	k148	134
.constant	k149	92
.constant	k150	39
.constant	k151	242
.constant	k152	248
.constant	k153	99
.constant	k154	0
.constant	k155	220
.constant	k156	139
.constant	k157	73
.constant	k158	"tostring"
.constant	k159	"AssetName"
.constant	k160	"DisplayName"
.constant	k161	"FolderID"
.constant	k162	"Icon"
.constant	k163	"ActorIcon"
.constant	k164	"DefaultActorIconPath"
.constant	k165	"Desc"
.constant	k166	"Description"
.constant	k167	118
.constant	k168	93
.constant	k169	110
.constant	k170	41
.constant	k171	"UGCAssetID"
.constant	k172	"Generate"
.constant	k173	"DynamicAssetType"
.constant	k174	"UserActor"
.constant	k175	"GetAssetRestrictions"
.constant	k176	"ApplyAssetRestrictions"
.constant	k177	"DisableRename"
.constant	k178	"DisableBeInherited"
.constant	k179	"insert"
.constant	k180	"SaveAssetPathMap"

.line	889	gettabup      r1    u0    k0 ; k0 = "print"
.line	889	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	889	test          r2     0
.line	889	jmp            0   l66
.line	889	gettabup      r2    u0    k2 ; k2 = "table"
.line	889	gettable      r2    r2    k3 ; k3 = "concat"
.line	889	newtable      r3     1     0
.line	889	getupval      r4    u1
.line	889	loadk         r5    k4 ; k4 = 177
.line	889	loadk         r6    k5 ; k5 = 122
.line	889	loadk         r7    k6 ; k6 = 126
.line	889	loadk         r8    k7 ; k7 = 49
.line	889	loadk         r9    k8 ; k8 = 120
.line	889	loadk        r10    k9 ; k9 = 255
.line	889	loadk        r11   k10 ; k10 = 205
.line	889	loadk        r12   k11 ; k11 = 35
.line	889	loadk        r13   k12 ; k12 = 175
.line	889	loadk        r14   k13 ; k13 = 19
.line	889	loadk        r15   k14 ; k14 = 235
.line	889	loadk        r16   k15 ; k15 = 176
.line	889	loadk        r17   k16 ; k16 = 251
.line	889	loadk        r18   k17 ; k17 = 219
.line	889	loadk        r19   k18 ; k18 = 223
.line	889	loadk        r20    k9 ; k9 = 255
.line	889	loadk        r21   k19 ; k19 = 115
.line	889	loadk        r22   k20 ; k20 = 81
.line	889	loadk        r23   k21 ; k21 = 10
.line	889	loadk        r24    k7 ; k7 = 49
.line	889	loadk        r25   k22 ; k22 = 142
.line	889	loadk        r26   k14 ; k14 = 235
.line	889	loadk        r27   k23 ; k23 = 174
.line	889	loadk        r28   k24 ; k24 = 14
.line	889	loadk        r29   k25 ; k25 = 247
.line	889	loadk        r30   k26 ; k26 = 7
.line	889	loadk        r31   k27 ; k27 = 237
.line	889	loadk        r32   k28 ; k28 = 188
.line	889	loadk        r33   k29 ; k29 = 227
.line	889	loadk        r34   k30 ; k30 = 203
.line	889	loadk        r35   k18 ; k18 = 223
.line	889	loadk        r36   k31 ; k31 = 232
.line	889	loadk        r37   k32 ; k32 = 105
.line	889	loadk        r38   k33 ; k33 = 71
.line	889	loadk        r39   k34 ; k34 = 13
.line	889	loadk        r40   k35 ; k35 = 53
.line	889	loadk        r41   k36 ; k36 = 136
.line	889	loadk        r42   k37 ; k37 = 215
.line	889	loadk        r43   k38 ; k38 = 141
.line	889	loadk        r44   k39 ; k39 = 3
.line	889	call          r4    41     2
.line	889	getupval      r5    u1
.line	889	loadk         r6   k40 ; k40 = 167
.line	889	loadk         r7   k41 ; k41 = 102
.line	889	loadk         r8   k42 ; k42 = 90
.line	889	loadk         r9   k43 ; k43 = 17
.line	889	loadk        r10   k44 ; k44 = 104
.line	889	loadk        r11   k45 ; k45 = 198
.line	889	loadk        r12   k46 ; k46 = 216
.line	889	loadk        r13   k47 ; k47 = 56
.line	889	loadk        r14   k48 ; k48 = 181
.line	889	loadk        r15   k49 ; k49 = 9
.line	889	loadk        r16   k50 ; k50 = 229
.line	889	loadk        r17   k51 ; k51 = 178
.line	889	call          r5    13     0
.line	889	setlist       r3     0     1
.line	889	call          r2     2     2
.label	l66
.line	889	call          r1     2     1
.line	889	gettabup      r1    u0   k52 ; k52 = "GetCreativeActorData" (truncated)
.line	889	call          r1     1     2
.line	889	test          r1     1
.line	889	jmp            0   l72
.line	889	return        r0     1
.label	l72
.line	889	newtable      r2     0     0
.line	889	self          r3    r1   k53 ; k53 = "GetAllUserActorIDs"
.line	889	call          r3     2     2
.line	889	loadk         r4   k54 ; k54 = 1
.line	889	len           r5    r3
.line	889	loadk         r6   k54 ; k54 = 1
.line	889	move          r0    r0
.line	889	gettable      r8    r3    r7
.line	889	settable      r2    r8   k55 ; k55 = true
.line	889	move          r0    r0
.line	889	loadbool      r4     0     0
.line	889	gettable      r5    r0   k56 ; k56 = "AssetPathMap"
.line	889	len           r5    r5
.line	889	loadk         r6   k54 ; k54 = 1
.line	889	loadk         r7   k57 ; k57 = -1
.line	889	move          r0    r0
.line	889	gettable      r9    r0   k56 ; k56 = "AssetPathMap"
.line	889	gettable      r9    r9    r8
.line	889	gettable     r10    r9   k58 ; k58 = "AssetType"
.line	889	gettabup     r11    u2   k59 ; k59 = "Actor"
.line	889	eq             0   r10   r11
.line	889	jmp            0  l106
.line	889	gettabup     r10    u0   k60 ; k60 = "tonumber"
.line	889	gettable     r11    r9   k61 ; k61 = "AssetUID"
.line	889	call         r10     2     2
.line	889	gettable     r10    r2   r10
.line	889	test         r10     1
.line	889	jmp            0  l106
.line	889	gettabup     r10    u0    k2 ; k2 = "table"
.line	889	gettable     r10   r10   k62 ; k62 = "remove"
.line	889	gettable     r11    r0   k56 ; k56 = "AssetPathMap"
.line	889	move         r12    r8
.line	889	call         r10     3     1
.line	889	loadbool      r4     1     0
.label	l106
.line	889	move          r0    r0
.line	889	gettabup      r5    u0   k63 ; k63 = "require"
.line	889	gettabup      r6    u0    k2 ; k2 = "table"
.line	889	gettable      r6    r6    k3 ; k3 = "concat"
.line	889	newtable      r7     1     0
.line	889	getupval      r8    u1
.line	889	loadk         r9   k64 ; k64 = 161
.line	889	loadk        r10   k65 ; k65 = 116
.line	889	loadk        r11   k66 ; k66 = 68
.line	889	loadk        r12   k43 ; k43 = 17
.line	889	loadk        r13   k67 ; k67 = 80
.line	889	loadk        r14   k29 ; k29 = 227
.line	889	loadk        r15   k46 ; k46 = 216
.line	889	loadk        r16   k68 ; k68 = 98
.line	889	loadk        r17   k69 ; k69 = 144
.line	889	loadk        r18   k70 ; k70 = 43
.line	889	loadk        r19   k71 ; k71 = 224
.line	889	loadk        r20   k72 ; k72 = 236
.line	889	loadk        r21   k73 ; k73 = 211
.line	889	loadk        r22   k31 ; k31 = 232
.line	889	loadk        r23   k74 ; k74 = 201
.line	889	loadk        r24   k27 ; k27 = 237
.line	889	loadk        r25   k68 ; k68 = 98
.line	889	loadk        r26   k75 ; k75 = 76
.line	889	loadk        r27   k76 ; k76 = 47
.line	889	loadk        r28   k77 ; k77 = 33
.line	889	loadk        r29   k23 ; k23 = 174
.line	889	loadk        r30   k78 ; k78 = 199
.line	889	loadk        r31   k79 ; k79 = 186
.line	889	loadk        r32   k80 ; k80 = 25
.line	889	loadk        r33   k29 ; k29 = 227
.line	889	loadk        r34   k13 ; k13 = 19
.line	889	loadk        r35   k81 ; k81 = 245
.line	889	loadk        r36   k82 ; k82 = 191
.line	889	loadk        r37   k50 ; k50 = 229
.line	889	loadk        r38   k83 ; k83 = 250
.line	889	loadk        r39   k84 ; k84 = 208
.line	889	loadk        r40   k85 ; k85 = 253
.line	889	loadk        r41   k86 ; k86 = 127
.line	889	loadk        r42   k87 ; k87 = 27
.line	889	loadk        r43   k88 ; k88 = 28
.line	889	loadk        r44   k89 ; k89 = 32
.line	889	loadk        r45   k90 ; k90 = 149
.line	889	loadk        r46   k91 ; k91 = 218
.line	889	loadk        r47   k15 ; k15 = 176
.line	889	loadk        r48   k92 ; k92 = 24
.line	889	call          r8    41     2
.line	889	getupval      r9    u1
.line	889	loadk        r10   k93 ; k93 = 159
.line	889	loadk        r11   k94 ; k94 = 59
.line	889	loadk        r12   k95 ; k95 = 106
.line	889	loadk        r13   k96 ; k96 = 6
.line	889	loadk        r14   k97 ; k97 = 121
.line	889	loadk        r15   k25 ; k25 = 247
.line	889	loadk        r16   k10 ; k10 = 205
.line	889	loadk        r17   k98 ; k98 = 37
.line	889	loadk        r18   k99 ; k99 = 171
.line	889	loadk        r19   k77 ; k77 = 33
.line	889	loadk        r20   k74 ; k74 = 201
.line	889	loadk        r21  k100 ; k100 = 173
.line	889	loadk        r22  k101 ; k101 = 244
.line	889	loadk        r23    k9 ; k9 = 255
.line	889	loadk        r24   k31 ; k31 = 232
.line	889	loadk        r25   k81 ; k81 = 245
.line	889	loadk        r26    k8 ; k8 = 120
.line	889	loadk        r27   k66 ; k66 = 68
.line	889	loadk        r28  k102 ; k102 = 52
.line	889	loadk        r29  k103 ; k103 = 45
.line	889	loadk        r30  k104 ; k104 = 143
.line	889	loadk        r31  k105 ; k105 = 231
.line	889	loadk        r32   k79 ; k79 = 186
.line	889	loadk        r33  k106 ; k106 = 15
.line	889	loadk        r34  k107 ; k107 = 168
.line	889	loadk        r35   k89 ; k89 = 32
.line	889	loadk        r36  k108 ; k108 = 221
.line	889	loadk        r37  k109 ; k109 = 182
.line	889	loadk        r38   k78 ; k78 = 199
.line	889	loadk        r39  k110 ; k110 = 239
.line	889	loadk        r40  k111 ; k111 = 210
.line	889	loadk        r41  k112 ; k112 = 249
.line	889	loadk        r42   k65 ; k65 = 116
.line	889	loadk        r43  k113 ; k113 = 84
.line	889	loadk        r44  k114 ; k114 = 61
.line	889	loadk        r45   k94 ; k94 = 59
.line	889	loadk        r46   k22 ; k22 = 142
.line	889	call          r9    38     0
.line	889	setlist       r7     0     1
.line	889	call          r6     2     2
.line	889	call          r5     2     2
.line	889	gettabup      r6    u0   k63 ; k63 = "require"
.line	889	gettabup      r7    u0    k2 ; k2 = "table"
.line	889	gettable      r7    r7    k3 ; k3 = "concat"
.line	889	newtable      r8     1     0
.line	889	getupval      r9    u1
.line	889	loadk        r10   k64 ; k64 = 161
.line	889	loadk        r11   k65 ; k65 = 116
.line	889	loadk        r12   k66 ; k66 = 68
.line	889	loadk        r13   k43 ; k43 = 17
.line	889	loadk        r14   k67 ; k67 = 80
.line	889	loadk        r15   k29 ; k29 = 227
.line	889	loadk        r16   k46 ; k46 = 216
.line	889	loadk        r17   k68 ; k68 = 98
.line	889	loadk        r18   k69 ; k69 = 144
.line	889	loadk        r19   k70 ; k70 = 43
.line	889	loadk        r20   k71 ; k71 = 224
.line	889	loadk        r21   k72 ; k72 = 236
.line	889	loadk        r22   k73 ; k73 = 211
.line	889	loadk        r23   k31 ; k31 = 232
.line	889	loadk        r24   k74 ; k74 = 201
.line	889	loadk        r25   k27 ; k27 = 237
.line	889	loadk        r26   k68 ; k68 = 98
.line	889	loadk        r27   k75 ; k75 = 76
.line	889	loadk        r28   k76 ; k76 = 47
.line	889	loadk        r29   k77 ; k77 = 33
.line	889	loadk        r30   k23 ; k23 = 174
.line	889	loadk        r31   k78 ; k78 = 199
.line	889	loadk        r32   k79 ; k79 = 186
.line	889	loadk        r33   k80 ; k80 = 25
.line	889	loadk        r34   k29 ; k29 = 227
.line	889	loadk        r35   k13 ; k13 = 19
.line	889	loadk        r36   k81 ; k81 = 245
.line	889	loadk        r37   k82 ; k82 = 191
.line	889	loadk        r38   k50 ; k50 = 229
.line	889	loadk        r39   k83 ; k83 = 250
.line	889	loadk        r40   k84 ; k84 = 208
.line	889	loadk        r41   k85 ; k85 = 253
.line	889	loadk        r42   k86 ; k86 = 127
.line	889	loadk        r43   k87 ; k87 = 27
.line	889	loadk        r44   k21 ; k21 = 10
.line	889	loadk        r45   k94 ; k94 = 59
.line	889	loadk        r46  k115 ; k115 = 146
.line	889	loadk        r47   k84 ; k84 = 208
.line	889	loadk        r48   k15 ; k15 = 176
.line	889	loadk        r49  k116 ; k116 = 11
.line	889	call          r9    41     2
.line	889	getupval     r10    u1
.line	889	loadk        r11  k117 ; k117 = 200
.line	889	loadk        r12  k118 ; k118 = 86
.line	889	loadk        r13  k119 ; k119 = 91
.line	889	loadk        r14   k43 ; k43 = 17
.line	889	loadk        r15  k120 ; k120 = 125
.line	889	loadk        r16  k121 ; k121 = 226
.line	889	loadk        r17   k84 ; k84 = 208
.line	889	loadk        r18  k122 ; k122 = 58
.line	889	loadk        r19  k123 ; k123 = 184
.line	889	loadk        r20  k124 ; k124 = 5
.line	889	loadk        r21  k105 ; k105 = 231
.line	889	loadk        r22  k109 ; k109 = 182
.line	889	loadk        r23    k9 ; k9 = 255
.line	889	loadk        r24   k31 ; k31 = 232
.line	889	loadk        r25  k125 ; k125 = 130
.line	889	loadk        r26  k126 ; k126 = 207
.line	889	loadk        r27  k127 ; k127 = 100
.line	889	loadk        r28  k128 ; k128 = 64
.line	889	loadk        r29   k47 ; k47 = 56
.line	889	loadk        r30  k129 ; k129 = 48
.line	889	loadk        r31  k130 ; k130 = 133
.line	889	loadk        r32   k84 ; k84 = 208
.line	889	loadk        r33  k131 ; k131 = 172
.line	889	loadk        r34  k114 ; k114 = 61
.line	889	loadk        r35   k23 ; k23 = 174
.line	889	loadk        r36   k89 ; k89 = 32
.line	889	loadk        r37   k16 ; k16 = 251
.line	889	loadk        r38  k132 ; k132 = 160
.line	889	loadk        r39  k133 ; k133 = 195
.line	889	loadk        r40   k50 ; k50 = 229
.line	889	loadk        r41  k111 ; k111 = 210
.line	889	loadk        r42   k83 ; k83 = 250
.line	889	loadk        r43  k134 ; k134 = 111
.line	889	loadk        r44  k135 ; k135 = 82
.line	889	call         r10    35     0
.line	889	setlist       r8     0     1
.line	889	call          r7     2     2
.line	889	call          r6     2     2
.line	889	loadk         r7   k54 ; k54 = 1
.line	889	len           r8    r3
.line	889	loadk         r9   k54 ; k54 = 1
.line	889	move          r0    r0
.line	889	gettable     r11    r3   r10
.line	889	self         r12    r0  k136 ; k136 = "IsAssetInPathMap"
.line	889	move         r14   r11
.line	889	gettabup     r15    u2   k59 ; k59 = "Actor"
.line	889	call         r12     4     2
.line	889	test         r12     1
.line	889	jmp            0  l488
.line	889	self         r12    r1  k137 ; k137 = "GetActorDataProxyByI" (truncated)
.line	889	move         r14   r11
.line	889	call         r12     3     2
.line	889	loadnil      r13     0
.line	889	loadbool     r14     0     0
.line	889	gettable     r15    r0  k138 ; k138 = "ImportingActorFolder" (truncated)
.line	889	test         r15     0
.line	889	jmp            0  l305
.line	889	gettable     r15    r0  k138 ; k138 = "ImportingActorFolder" (truncated)
.line	889	gettable     r13   r15   r11
.line	889	test         r13     0
.line	889	jmp            0  l305
.line	889	gettable     r15    r0  k138 ; k138 = "ImportingActorFolder" (truncated)
.line	889	settable     r15   r11  k139 ; k139 = nil
.label	l305
.line	889	test         r13     1
.line	889	jmp            0  l323
.line	889	gettable     r15    r6  k140 ; k140 = "DefaultAbstractClass" (truncated)
.line	889	gettable     r16   r12  k141 ; k141 = "OverrideConfigActorI" (truncated)
.line	889	gettable     r15   r15   r16
.line	889	eq             1   r15  k139 ; k139 = nil
.line	889	jmp            0  l319
.line	889	gettable     r16   r12  k142 ; k142 = "ActorID"
.line	889	gettable     r17   r15  k143 ; k143 = "DefaultAbstractClass" (truncated)
.line	889	eq             0   r16   r17
.line	889	jmp            0  l319
.line	889	loadbool     r14     1     0
.line	889	gettable     r13   r15  k144 ; k144 = "DefaultSubFolderID"
.line	889	jmp            0  l323
.label	l319
.line	889	self         r16    r0  k145 ; k145 = "GetFolderIDForAssetT" (truncated)
.line	889	gettabup     r18    u2   k59 ; k59 = "Actor"
.line	889	call         r16     3     2
.line	889	move         r13   r16
.label	l323
.line	889	gettabup     r15    u0  k146 ; k146 = "log_format"
.line	889	gettabup     r16    u0    k2 ; k2 = "table"
.line	889	gettable     r16   r16    k3 ; k3 = "concat"
.line	889	newtable     r17     2     0
.line	889	getupval     r18    u1
.line	889	loadk        r19    k4 ; k4 = 177
.line	889	loadk        r20    k5 ; k5 = 122
.line	889	loadk        r21    k6 ; k6 = 126
.line	889	loadk        r22    k7 ; k7 = 49
.line	889	loadk        r23    k8 ; k8 = 120
.line	889	loadk        r24    k9 ; k9 = 255
.line	889	loadk        r25   k10 ; k10 = 205
.line	889	loadk        r26   k11 ; k11 = 35
.line	889	loadk        r27   k12 ; k12 = 175
.line	889	loadk        r28   k13 ; k13 = 19
.line	889	loadk        r29   k14 ; k14 = 235
.line	889	loadk        r30   k15 ; k15 = 176
.line	889	loadk        r31   k16 ; k16 = 251
.line	889	loadk        r32   k17 ; k17 = 219
.line	889	loadk        r33   k18 ; k18 = 223
.line	889	loadk        r34    k9 ; k9 = 255
.line	889	loadk        r35   k19 ; k19 = 115
.line	889	loadk        r36   k20 ; k20 = 81
.line	889	loadk        r37   k21 ; k21 = 10
.line	889	loadk        r38    k7 ; k7 = 49
.line	889	loadk        r39   k22 ; k22 = 142
.line	889	loadk        r40   k14 ; k14 = 235
.line	889	loadk        r41   k23 ; k23 = 174
.line	889	loadk        r42   k24 ; k24 = 14
.line	889	loadk        r43   k25 ; k25 = 247
.line	889	loadk        r44   k26 ; k26 = 7
.line	889	loadk        r45   k27 ; k27 = 237
.line	889	loadk        r46   k28 ; k28 = 188
.line	889	loadk        r47   k29 ; k29 = 227
.line	889	loadk        r48   k30 ; k30 = 203
.line	889	loadk        r49   k18 ; k18 = 223
.line	889	loadk        r50   k31 ; k31 = 232
.line	889	loadk        r51   k32 ; k32 = 105
.line	889	loadk        r52   k33 ; k33 = 71
.line	889	loadk        r53   k34 ; k34 = 13
.line	889	loadk        r54   k35 ; k35 = 53
.line	889	loadk        r55   k36 ; k36 = 136
.line	889	loadk        r56   k37 ; k37 = 215
.line	889	loadk        r57   k38 ; k38 = 141
.line	889	loadk        r58   k39 ; k39 = 3
.line	889	call         r18    41     2
.line	889	getupval     r19    u1
.line	889	loadk        r20   k40 ; k40 = 167
.line	889	loadk        r21   k41 ; k41 = 102
.line	889	loadk        r22   k42 ; k42 = 90
.line	889	loadk        r23   k43 ; k43 = 17
.line	889	loadk        r24   k44 ; k44 = 104
.line	889	loadk        r25   k45 ; k45 = 198
.line	889	loadk        r26   k46 ; k46 = 216
.line	889	loadk        r27   k47 ; k47 = 56
.line	889	loadk        r28   k48 ; k48 = 181
.line	889	loadk        r29   k49 ; k49 = 9
.line	889	loadk        r30   k50 ; k50 = 229
.line	889	loadk        r31   k51 ; k51 = 178
.line	889	loadk        r32   k28 ; k28 = 188
.line	889	loadk        r33   k79 ; k79 = 186
.line	889	loadk        r34   k27 ; k27 = 237
.line	889	loadk        r35  k110 ; k110 = 239
.line	889	loadk        r36   k68 ; k68 = 98
.line	889	loadk        r37  k147 ; k147 = 74
.line	889	loadk        r38   k70 ; k70 = 43
.line	889	loadk        r39   k34 ; k34 = 13
.line	889	loadk        r40   k36 ; k36 = 136
.line	889	loadk        r41  k148 ; k148 = 134
.line	889	loadk        r42  k101 ; k101 = 244
.line	889	loadk        r43  k149 ; k149 = 92
.line	889	loadk        r44   k31 ; k31 = 232
.line	889	loadk        r45  k150 ; k150 = 39
.line	889	loadk        r46  k123 ; k123 = 184
.line	889	loadk        r47  k151 ; k151 = 242
.line	889	loadk        r48   k45 ; k45 = 198
.line	889	loadk        r49   k50 ; k50 = 229
.line	889	loadk        r50   k84 ; k84 = 208
.line	889	loadk        r51  k152 ; k152 = 248
.line	889	loadk        r52  k153 ; k153 = 99
.line	889	loadk        r53   k33 ; k33 = 71
.line	889	loadk        r54  k154 ; k154 = 0
.line	889	loadk        r55  k129 ; k129 = 48
.line	889	loadk        r56  k155 ; k155 = 220
.line	889	loadk        r57  k156 ; k156 = 139
.line	889	loadk        r58  k112 ; k112 = 249
.line	889	loadk        r59  k157 ; k157 = 73
.line	889	call         r19    41     2
.line	889	getupval     r20    u1
.line	889	loadk        r21   k90 ; k90 = 149
.line	889	call         r20     2     0
.line	889	setlist      r17     0     1
.line	889	call         r16     2     2
.line	889	gettabup     r17    u0  k158 ; k158 = "tostring"
.line	889	move         r18   r11
.line	889	call         r17     2     2
.line	889	gettabup     r18    u0  k158 ; k158 = "tostring"
.line	889	move         r19   r13
.line	889	call         r18     2     0
.line	889	call         r15     0     1
.line	889	newtable     r15     0     7
.line	889	gettabup     r16    u0  k158 ; k158 = "tostring"
.line	889	move         r17   r11
.line	889	call         r16     2     2
.line	889	settable     r15   k61   r16 ; k61 = "AssetUID"
.line	889	test         r12     0
.line	889	jmp            0  l433
.line	889	gettable     r16   r12  k160 ; k160 = "DisplayName"
.line	889	test         r16     1
.line	889	jmp            0  l434
.label	l433
.line	889	move         r16   r11
.label	l434
.line	889	settable     r15  k159   r16 ; k159 = "AssetName"
.line	889	gettabup     r16    u2   k59 ; k59 = "Actor"
.line	889	settable     r15   k58   r16 ; k58 = "AssetType"
.line	889	settable     r15  k161   r13 ; k161 = "FolderID"
.line	889	test         r12     0
.line	889	jmp            0  l443
.line	889	gettable     r16   r12  k163 ; k163 = "ActorIcon"
.line	889	test         r16     1
.line	889	jmp            0  l444
.label	l443
.line	889	gettabup     r16    u3  k164 ; k164 = "DefaultActorIconPath"
.label	l444
.line	889	settable     r15  k162   r16 ; k162 = "Icon"
.line	889	test         r12     0
.line	889	jmp            0  l452
.line	889	gettabup     r16    u0  k158 ; k158 = "tostring"
.line	889	gettable     r17   r12  k166 ; k166 = "Description"
.line	889	call         r16     2     2
.line	889	test         r16     1
.line	889	jmp            0  l464
.label	l452
.line	889	getupval     r16    u1
.line	889	loadk        r17   k40 ; k40 = 167
.line	889	loadk        r18  k167 ; k167 = 118
.line	889	loadk        r19  k168 ; k168 = 93
.line	889	loadk        r20   k87 ; k87 = 27
.line	889	loadk        r21  k169 ; k169 = 110
.line	889	loadk        r22  k109 ; k109 = 182
.line	889	loadk        r23   k85 ; k85 = 253
.line	889	loadk        r24  k170 ; k170 = 41
.line	889	loadk        r25   k23 ; k23 = 174
.line	889	loadk        r26  k150 ; k150 = 39
.line	889	call         r16    11     2
.label	l464
.line	889	settable     r15  k165   r16 ; k165 = "Desc"
.line	889	gettable     r16    r5  k172 ; k172 = "Generate"
.line	889	gettable     r17    r5  k173 ; k173 = "DynamicAssetType"
.line	889	gettable     r17   r17  k174 ; k174 = "UserActor"
.line	889	move         r18   r11
.line	889	call         r16     3     2
.line	889	settable     r15  k171   r16 ; k171 = "UGCAssetID"
.line	889	self         r16    r0  k175 ; k175 = "GetAssetRestrictions"
.line	889	move         r18   r13
.line	889	call         r16     3     2
.line	889	self         r17    r0  k176 ; k176 = "ApplyAssetRestrictio" (truncated)
.line	889	move         r19   r15
.line	889	move         r20   r16
.line	889	call         r17     4     1
.line	889	test         r14     0
.line	889	jmp            0  l482
.line	889	settable     r15  k177   k55 ; k55 = true
.line	889	settable     r15  k178   k55 ; k55 = true
.label	l482
.line	889	gettabup     r17    u0    k2 ; k2 = "table"
.line	889	gettable     r17   r17  k179 ; k179 = "insert"
.line	889	gettable     r18    r0   k56 ; k56 = "AssetPathMap"
.line	889	move         r19   r15
.line	889	call         r17     3     1
.line	889	loadbool      r4     1     0
.label	l488
.line	889	move          r0    r0
.line	889	loadk         r7   k54 ; k54 = 1
.line	889	gettable      r8    r0   k56 ; k56 = "AssetPathMap"
.line	889	len           r8    r8
.line	889	loadk         r9   k54 ; k54 = 1
.line	889	move          r0    r0
.line	889	gettable     r11    r0   k56 ; k56 = "AssetPathMap"
.line	889	gettable     r11   r11   r10
.line	889	gettable     r12   r11   k58 ; k58 = "AssetType"
.line	889	gettabup     r13    u2   k59 ; k59 = "Actor"
.line	889	eq             0   r12   r13
.line	889	jmp            0  l555
.line	889	gettabup     r12    u0   k60 ; k60 = "tonumber"
.line	889	gettable     r13   r11   k61 ; k61 = "AssetUID"
.line	889	call         r12     2     2
.line	889	self         r13    r1  k137 ; k137 = "GetActorDataProxyByI" (truncated)
.line	889	move         r15   r12
.line	889	call         r13     3     2
.line	889	test         r13     0
.line	889	jmp            0  l555
.line	889	gettable     r14   r11  k162 ; k162 = "Icon"
.line	889	gettable     r15   r13  k163 ; k163 = "ActorIcon"
.line	889	eq             0   r14   r15
.line	889	jmp            0  l520
.line	889	gettable     r14   r11  k165 ; k165 = "Desc"
.line	889	gettable     r15   r13  k166 ; k166 = "Description"
.line	889	eq             0   r14   r15
.line	889	jmp            0  l520
.line	889	gettable     r14   r11  k159 ; k159 = "AssetName"
.line	889	gettable     r15   r13  k160 ; k160 = "DisplayName"
.line	889	eq             1   r14   r15
.line	889	jmp            0  l521
.label	l520
.line	889	loadbool      r4     1     0
.label	l521
.line	889	test         r13     0
.line	889	jmp            0  l526
.line	889	gettable     r14   r13  k163 ; k163 = "ActorIcon"
.line	889	test         r14     1
.line	889	jmp            0  l527
.label	l526
.line	889	gettabup     r14    u3  k164 ; k164 = "DefaultActorIconPath"
.label	l527
.line	889	settable     r11  k162   r14 ; k162 = "Icon"
.line	889	test         r13     0
.line	889	jmp            0  l535
.line	889	gettabup     r14    u0  k158 ; k158 = "tostring"
.line	889	gettable     r15   r13  k166 ; k166 = "Description"
.line	889	call         r14     2     2
.line	889	test         r14     1
.line	889	jmp            0  l547
.label	l535
.line	889	getupval     r14    u1
.line	889	loadk        r15   k40 ; k40 = 167
.line	889	loadk        r16  k167 ; k167 = 118
.line	889	loadk        r17  k168 ; k168 = 93
.line	889	loadk        r18   k87 ; k87 = 27
.line	889	loadk        r19  k169 ; k169 = 110
.line	889	loadk        r20  k109 ; k109 = 182
.line	889	loadk        r21   k85 ; k85 = 253
.line	889	loadk        r22  k170 ; k170 = 41
.line	889	loadk        r23   k23 ; k23 = 174
.line	889	loadk        r24  k150 ; k150 = 39
.line	889	call         r14    11     2
.label	l547
.line	889	settable     r11  k165   r14 ; k165 = "Desc"
.line	889	test         r13     0
.line	889	jmp            0  l553
.line	889	gettable     r14   r13  k160 ; k160 = "DisplayName"
.line	889	test         r14     1
.line	889	jmp            0  l554
.label	l553
.line	889	move         r14   r12
.label	l554
.line	889	settable     r11  k159   r14 ; k159 = "AssetName"
.label	l555
.line	889	move          r0    r0
.line	889	test          r4     0
.line	889	jmp            0  l560
.line	889	self          r7    r0  k180 ; k180 = "SaveAssetPathMap"
.line	889	call          r7     2     1
.label	l560
.line	889	return        r4     2
.line	889	return        r0     1
.line	889	move          r0    r0
.line	889	move          r0    r0
.line	889	move          r0    r0
.line	889	move          r0    r0
.line	889	return        r0     1

.function	main/f30

.source	null
.linedefined	973
.lastlinedefined	1051
.numparams	1
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	15	true
.upvalue	"U3"	14	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	177
.constant	k5	122
.constant	k6	126
.constant	k7	49
.constant	k8	120
.constant	k9	255
.constant	k10	205
.constant	k11	35
.constant	k12	175
.constant	k13	19
.constant	k14	235
.constant	k15	176
.constant	k16	251
.constant	k17	219
.constant	k18	223
.constant	k19	115
.constant	k20	81
.constant	k21	10
.constant	k22	142
.constant	k23	174
.constant	k24	14
.constant	k25	247
.constant	k26	7
.constant	k27	237
.constant	k28	188
.constant	k29	227
.constant	k30	241
.constant	k31	66
.constant	k32	84
.constant	k33	61
.constant	k34	53
.constant	k35	168
.constant	k36	217
.constant	k37	152
.constant	k38	31
.constant	k39	149
.constant	k40	112
.constant	k41	93
.constant	k42	36
.constant	k43	125
.constant	k44	226
.constant	k45	209
.constant	k46	1
.constant	k47	52
.constant	k48	"_G"
.constant	k49	"EnableUMGInfoManager"
.constant	k50	"GetCreativeUMGInfoManager"
.constant	k51	"GetAllUMGInfoTree"
.constant	k52	"pairs"
.constant	k53	"_GetCanvasNodeOfSubTree"
.constant	k54	"UMGCanvasInfo"
.constant	k55	"CanvasType"
.constant	k56	"tonumber"
.constant	k57	"AssetPathMap"
.constant	k58	-1
.constant	k59	"AssetType"
.constant	k60	"UMG"
.constant	k61	"AssetUID"
.constant	k62	"UMGCanvasSourceAssetMap"
.constant	k63	nil
.constant	k64	"remove"
.constant	k65	"require"
.constant	k66	161
.constant	k67	116
.constant	k68	68
.constant	k69	17
.constant	k70	80
.constant	k71	216
.constant	k72	98
.constant	k73	144
.constant	k74	43
.constant	k75	224
.constant	k76	236
.constant	k77	211
.constant	k78	232
.constant	k79	201
.constant	k80	76
.constant	k81	47
.constant	k82	33
.constant	k83	199
.constant	k84	186
.constant	k85	25
.constant	k86	245
.constant	k87	191
.constant	k88	229
.constant	k89	250
.constant	k90	208
.constant	k91	253
.constant	k92	127
.constant	k93	27
.constant	k94	28
.constant	k95	32
.constant	k96	218
.constant	k97	24
.constant	k98	159
.constant	k99	59
.constant	k100	106
.constant	k101	6
.constant	k102	121
.constant	k103	37
.constant	k104	171
.constant	k105	173
.constant	k106	244
.constant	k107	45
.constant	k108	143
.constant	k109	231
.constant	k110	15
.constant	k111	221
.constant	k112	182
.constant	k113	239
.constant	k114	210
.constant	k115	249
.constant	k116	"IsAssetInPathMap"
.constant	k117	"ImportingUMGCanvasInfoMap"
.constant	k118	"FolderID"
.constant	k119	"GetFolderIDForAssetType"
.constant	k120	"SourceAssetId"
.constant	k121	"tostring"
.constant	k122	"AssetName"
.constant	k123	"CanvasName"
.constant	k124	"Icon"
.constant	k125	"Desc"
.constant	k126	"UGCAssetID"
.constant	k127	"Generate"
.constant	k128	"DynamicAssetType"
.constant	k129	"UMGCanvas"
.constant	k130	"DisableRename"
.constant	k131	true
.constant	k132	"GetAssetRestrictions"
.constant	k133	"ApplyAssetRestrictions"
.constant	k134	"insert"
.constant	k135	"SaveAssetPathMap"

.line	973	gettabup      r1    u0    k0 ; k0 = "print"
.line	973	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	973	test          r2     0
.line	973	jmp            0   l64
.line	973	gettabup      r2    u0    k2 ; k2 = "table"
.line	973	gettable      r2    r2    k3 ; k3 = "concat"
.line	973	newtable      r3     1     0
.line	973	getupval      r4    u1
.line	973	loadk         r5    k4 ; k4 = 177
.line	973	loadk         r6    k5 ; k5 = 122
.line	973	loadk         r7    k6 ; k6 = 126
.line	973	loadk         r8    k7 ; k7 = 49
.line	973	loadk         r9    k8 ; k8 = 120
.line	973	loadk        r10    k9 ; k9 = 255
.line	973	loadk        r11   k10 ; k10 = 205
.line	973	loadk        r12   k11 ; k11 = 35
.line	973	loadk        r13   k12 ; k12 = 175
.line	973	loadk        r14   k13 ; k13 = 19
.line	973	loadk        r15   k14 ; k14 = 235
.line	973	loadk        r16   k15 ; k15 = 176
.line	973	loadk        r17   k16 ; k16 = 251
.line	973	loadk        r18   k17 ; k17 = 219
.line	973	loadk        r19   k18 ; k18 = 223
.line	973	loadk        r20    k9 ; k9 = 255
.line	973	loadk        r21   k19 ; k19 = 115
.line	973	loadk        r22   k20 ; k20 = 81
.line	973	loadk        r23   k21 ; k21 = 10
.line	973	loadk        r24    k7 ; k7 = 49
.line	973	loadk        r25   k22 ; k22 = 142
.line	973	loadk        r26   k14 ; k14 = 235
.line	973	loadk        r27   k23 ; k23 = 174
.line	973	loadk        r28   k24 ; k24 = 14
.line	973	loadk        r29   k25 ; k25 = 247
.line	973	loadk        r30   k26 ; k26 = 7
.line	973	loadk        r31   k27 ; k27 = 237
.line	973	loadk        r32   k28 ; k28 = 188
.line	973	loadk        r33   k29 ; k29 = 227
.line	973	loadk        r34   k18 ; k18 = 223
.line	973	loadk        r35   k30 ; k30 = 241
.line	973	loadk        r36   k17 ; k17 = 219
.line	973	loadk        r37   k31 ; k31 = 66
.line	973	loadk        r38   k32 ; k32 = 84
.line	973	loadk        r39   k33 ; k33 = 61
.line	973	loadk        r40   k34 ; k34 = 53
.line	973	loadk        r41   k35 ; k35 = 168
.line	973	loadk        r42   k36 ; k36 = 217
.line	973	loadk        r43   k37 ; k37 = 152
.line	973	loadk        r44   k38 ; k38 = 31
.line	973	call          r4    41     2
.line	973	getupval      r5    u1
.line	973	loadk         r6   k39 ; k39 = 149
.line	973	loadk         r7   k40 ; k40 = 112
.line	973	loadk         r8   k41 ; k41 = 93
.line	973	loadk         r9   k42 ; k42 = 36
.line	973	loadk        r10   k43 ; k43 = 125
.line	973	loadk        r11   k44 ; k44 = 226
.line	973	loadk        r12   k45 ; k45 = 209
.line	973	loadk        r13   k46 ; k46 = 1
.line	973	loadk        r14   k28 ; k28 = 188
.line	973	loadk        r15   k47 ; k47 = 52
.line	973	call          r5    11     0
.line	973	setlist       r3     0     1
.line	973	call          r2     2     2
.label	l64
.line	973	call          r1     2     1
.line	973	gettabup      r1    u0   k48 ; k48 = "_G"
.line	973	gettable      r1    r1   k49 ; k49 = "EnableUMGInfoManager"
.line	973	test          r1     1
.line	973	jmp            0   l71
.line	973	loadbool      r1     0     0
.line	973	return        r1     2
.label	l71
.line	973	gettabup      r1    u0   k50 ; k50 = "GetCreativeUMGInfoMa" (truncated)
.line	973	call          r1     1     2
.line	973	test          r1     1
.line	973	jmp            0   l77
.line	973	loadbool      r2     0     0
.line	973	return        r2     2
.label	l77
.line	973	self          r2    r1   k51 ; k51 = "GetAllUMGInfoTree"
.line	973	call          r2     2     2
.line	973	test          r2     1
.line	973	jmp            0   l82
.line	973	newtable      r2     0     0
.label	l82
.line	973	newtable      r3     0     0
.line	973	gettabup      r4    u0   k52 ; k52 = "pairs"
.line	973	move          r5    r2
.line	973	call          r4     2     4
.line	973	jmp            0  l104
.line	973	self          r9    r1   k53 ; k53 = "_GetCanvasNodeOfSubT" (truncated)
.line	973	move         r11    r8
.line	973	call          r9     3     2
.line	973	test          r9     0
.line	973	jmp            0  l104
.line	973	gettable     r10    r9   k54 ; k54 = "UMGCanvasInfo"
.line	973	test         r10     0
.line	973	jmp            0  l104
.line	973	gettable     r10    r9   k54 ; k54 = "UMGCanvasInfo"
.line	973	gettable     r10   r10   k55 ; k55 = "CanvasType"
.line	973	eq             1   r10   k46 ; k46 = 1
.line	973	jmp            0  l104
.line	973	gettabup     r10    u0   k56 ; k56 = "tonumber"
.line	973	move         r11    r7
.line	973	call         r10     2     2
.line	973	gettable     r11    r9   k54 ; k54 = "UMGCanvasInfo"
.line	973	settable      r3   r10   r11
.label	l104
.line	973	move          r0    r0
.line	973	move          r0    r0
.line	973	loadbool      r4     0     0
.line	973	gettable      r5    r0   k57 ; k57 = "AssetPathMap"
.line	973	len           r5    r5
.line	973	loadk         r6   k46 ; k46 = 1
.line	973	loadk         r7   k58 ; k58 = -1
.line	973	move          r0    r0
.line	973	gettable      r9    r0   k57 ; k57 = "AssetPathMap"
.line	973	gettable      r9    r9    r8
.line	973	gettable     r10    r9   k59 ; k59 = "AssetType"
.line	973	gettabup     r11    u2   k60 ; k60 = "UMG"
.line	973	eq             0   r10   r11
.line	973	jmp            0  l138
.line	973	gettabup     r10    u0   k56 ; k56 = "tonumber"
.line	973	gettable     r11    r9   k61 ; k61 = "AssetUID"
.line	973	call         r10     2     2
.line	973	gettable     r10    r3   r10
.line	973	test         r10     1
.line	973	jmp            0  l138
.line	973	gettable     r10    r0   k62 ; k62 = "UMGCanvasSourceAsset" (truncated)
.line	973	test         r10     0
.line	973	jmp            0  l132
.line	973	gettable     r10    r0   k62 ; k62 = "UMGCanvasSourceAsset" (truncated)
.line	973	gettabup     r11    u0   k56 ; k56 = "tonumber"
.line	973	gettable     r12    r9   k61 ; k61 = "AssetUID"
.line	973	call         r11     2     2
.line	973	settable     r10   r11   k63 ; k63 = nil
.label	l132
.line	973	gettabup     r10    u0    k2 ; k2 = "table"
.line	973	gettable     r10   r10   k64 ; k64 = "remove"
.line	973	gettable     r11    r0   k57 ; k57 = "AssetPathMap"
.line	973	move         r12    r8
.line	973	call         r10     3     1
.line	973	loadbool      r4     1     0
.label	l138
.line	973	move          r0    r0
.line	973	gettabup      r5    u0   k65 ; k65 = "require"
.line	973	gettabup      r6    u0    k2 ; k2 = "table"
.line	973	gettable      r6    r6    k3 ; k3 = "concat"
.line	973	newtable      r7     1     0
.line	973	getupval      r8    u1
.line	973	loadk         r9   k66 ; k66 = 161
.line	973	loadk        r10   k67 ; k67 = 116
.line	973	loadk        r11   k68 ; k68 = 68
.line	973	loadk        r12   k69 ; k69 = 17
.line	973	loadk        r13   k70 ; k70 = 80
.line	973	loadk        r14   k29 ; k29 = 227
.line	973	loadk        r15   k71 ; k71 = 216
.line	973	loadk        r16   k72 ; k72 = 98
.line	973	loadk        r17   k73 ; k73 = 144
.line	973	loadk        r18   k74 ; k74 = 43
.line	973	loadk        r19   k75 ; k75 = 224
.line	973	loadk        r20   k76 ; k76 = 236
.line	973	loadk        r21   k77 ; k77 = 211
.line	973	loadk        r22   k78 ; k78 = 232
.line	973	loadk        r23   k79 ; k79 = 201
.line	973	loadk        r24   k27 ; k27 = 237
.line	973	loadk        r25   k72 ; k72 = 98
.line	973	loadk        r26   k80 ; k80 = 76
.line	973	loadk        r27   k81 ; k81 = 47
.line	973	loadk        r28   k82 ; k82 = 33
.line	973	loadk        r29   k23 ; k23 = 174
.line	973	loadk        r30   k83 ; k83 = 199
.line	973	loadk        r31   k84 ; k84 = 186
.line	973	loadk        r32   k85 ; k85 = 25
.line	973	loadk        r33   k29 ; k29 = 227
.line	973	loadk        r34   k13 ; k13 = 19
.line	973	loadk        r35   k86 ; k86 = 245
.line	973	loadk        r36   k87 ; k87 = 191
.line	973	loadk        r37   k88 ; k88 = 229
.line	973	loadk        r38   k89 ; k89 = 250
.line	973	loadk        r39   k90 ; k90 = 208
.line	973	loadk        r40   k91 ; k91 = 253
.line	973	loadk        r41   k92 ; k92 = 127
.line	973	loadk        r42   k93 ; k93 = 27
.line	973	loadk        r43   k94 ; k94 = 28
.line	973	loadk        r44   k95 ; k95 = 32
.line	973	loadk        r45   k39 ; k39 = 149
.line	973	loadk        r46   k96 ; k96 = 218
.line	973	loadk        r47   k15 ; k15 = 176
.line	973	loadk        r48   k97 ; k97 = 24
.line	973	call          r8    41     2
.line	973	getupval      r9    u1
.line	973	loadk        r10   k98 ; k98 = 159
.line	973	loadk        r11   k99 ; k99 = 59
.line	973	loadk        r12  k100 ; k100 = 106
.line	973	loadk        r13  k101 ; k101 = 6
.line	973	loadk        r14  k102 ; k102 = 121
.line	973	loadk        r15   k25 ; k25 = 247
.line	973	loadk        r16   k10 ; k10 = 205
.line	973	loadk        r17  k103 ; k103 = 37
.line	973	loadk        r18  k104 ; k104 = 171
.line	973	loadk        r19   k82 ; k82 = 33
.line	973	loadk        r20   k79 ; k79 = 201
.line	973	loadk        r21  k105 ; k105 = 173
.line	973	loadk        r22  k106 ; k106 = 244
.line	973	loadk        r23    k9 ; k9 = 255
.line	973	loadk        r24   k78 ; k78 = 232
.line	973	loadk        r25   k86 ; k86 = 245
.line	973	loadk        r26    k8 ; k8 = 120
.line	973	loadk        r27   k68 ; k68 = 68
.line	973	loadk        r28   k47 ; k47 = 52
.line	973	loadk        r29  k107 ; k107 = 45
.line	973	loadk        r30  k108 ; k108 = 143
.line	973	loadk        r31  k109 ; k109 = 231
.line	973	loadk        r32   k84 ; k84 = 186
.line	973	loadk        r33  k110 ; k110 = 15
.line	973	loadk        r34   k35 ; k35 = 168
.line	973	loadk        r35   k95 ; k95 = 32
.line	973	loadk        r36  k111 ; k111 = 221
.line	973	loadk        r37  k112 ; k112 = 182
.line	973	loadk        r38   k83 ; k83 = 199
.line	973	loadk        r39  k113 ; k113 = 239
.line	973	loadk        r40  k114 ; k114 = 210
.line	973	loadk        r41  k115 ; k115 = 249
.line	973	loadk        r42   k67 ; k67 = 116
.line	973	loadk        r43   k32 ; k32 = 84
.line	973	loadk        r44   k33 ; k33 = 61
.line	973	loadk        r45   k99 ; k99 = 59
.line	973	loadk        r46   k22 ; k22 = 142
.line	973	call          r9    38     0
.line	973	setlist       r7     0     1
.line	973	call          r6     2     2
.line	973	call          r5     2     2
.line	973	gettabup      r6    u0   k52 ; k52 = "pairs"
.line	973	move          r7    r3
.line	973	call          r6     2     4
.line	973	jmp            0  l348
.line	973	self         r11    r0  k116 ; k116 = "IsAssetInPathMap"
.line	973	move         r13    r9
.line	973	gettabup     r14    u2   k60 ; k60 = "UMG"
.line	973	call         r11     4     2
.line	973	test         r11     1
.line	973	jmp            0  l348
.line	973	gettable     r11    r0  k117 ; k117 = "ImportingUMGCanvasIn" (truncated)
.line	973	test         r11     0
.line	973	jmp            0  l244
.line	973	gettable     r11    r0  k117 ; k117 = "ImportingUMGCanvasIn" (truncated)
.line	973	gettable     r11   r11    r9
.line	973	test         r11     1
.line	973	jmp            0  l245
.label	l244
.line	973	loadnil      r11     0
.label	l245
.line	973	test         r11     0
.line	973	jmp            0  l249
.line	973	gettable     r12    r0  k117 ; k117 = "ImportingUMGCanvasIn" (truncated)
.line	973	settable     r12    r9   k63 ; k63 = nil
.label	l249
.line	973	test         r11     0
.line	973	jmp            0  l254
.line	973	gettable     r12   r11  k118 ; k118 = "FolderID"
.line	973	test         r12     1
.line	973	jmp            0  l255
.label	l254
.line	973	loadnil      r12     0
.label	l255
.line	973	test         r12     0
.line	973	jmp            0  l261
.line	973	getupval     r13    u1
.line	973	call         r13     1     2
.line	973	eq             0   r12   r13
.line	973	jmp            0  l265
.label	l261
.line	973	self         r13    r0  k119 ; k119 = "GetFolderIDForAssetT" (truncated)
.line	973	gettabup     r15    u2   k60 ; k60 = "UMG"
.line	973	call         r13     3     2
.line	973	move         r12   r13
.label	l265
.line	973	test         r11     0
.line	973	jmp            0  l283
.line	973	gettable     r13   r11  k120 ; k120 = "SourceAssetId"
.line	973	test         r13     0
.line	973	jmp            0  l283
.line	973	gettable     r13    r0   k62 ; k62 = "UMGCanvasSourceAsset" (truncated)
.line	973	test         r13     1
.line	973	jmp            0  l274
.line	973	newtable     r13     0     0
.label	l274
.line	973	settable      r0   k62   r13 ; k62 = "UMGCanvasSourceAsset" (truncated)
.line	973	gettable     r13    r0   k62 ; k62 = "UMGCanvasSourceAsset" (truncated)
.line	973	gettabup     r14    u0   k56 ; k56 = "tonumber"
.line	973	move         r15    r9
.line	973	call         r14     2     2
.line	973	gettabup     r15    u0   k56 ; k56 = "tonumber"
.line	973	gettable     r16   r11  k120 ; k120 = "SourceAssetId"
.line	973	call         r15     2     2
.line	973	settable     r13   r14   r15
.label	l283
.line	973	newtable     r13     0     9
.line	973	gettabup     r14    u0  k121 ; k121 = "tostring"
.line	973	move         r15    r9
.line	973	call         r14     2     2
.line	973	settable     r13   k61   r14 ; k61 = "AssetUID"
.line	973	gettable     r14   r10  k123 ; k123 = "CanvasName"
.line	973	test         r14     1
.line	973	jmp            0  l294
.line	973	gettabup     r14    u0  k121 ; k121 = "tostring"
.line	973	move         r15    r9
.line	973	call         r14     2     2
.label	l294
.line	973	settable     r13  k122   r14 ; k122 = "AssetName"
.line	973	gettabup     r14    u2   k60 ; k60 = "UMG"
.line	973	settable     r13   k59   r14 ; k59 = "AssetType"
.line	973	settable     r13  k118   r12 ; k118 = "FolderID"
.line	973	test         r11     0
.line	973	jmp            0  l311
.line	973	gettable     r14   r11  k124 ; k124 = "Icon"
.line	973	test         r14     0
.line	973	jmp            0  l311
.line	973	gettable     r14   r11  k124 ; k124 = "Icon"
.line	973	getupval     r15    u1
.line	973	call         r15     1     2
.line	973	eq             1   r14   r15
.line	973	jmp            0  l311
.line	973	gettable     r14   r11  k124 ; k124 = "Icon"
.line	973	test         r14     1
.line	973	jmp            0  l312
.label	l311
.line	973	getupval     r14    u3
.label	l312
.line	973	settable     r13  k124   r14 ; k124 = "Icon"
.line	973	test         r11     0
.line	973	jmp            0  l318
.line	973	gettable     r14   r11  k125 ; k125 = "Desc"
.line	973	test         r14     1
.line	973	jmp            0  l320
.label	l318
.line	973	getupval     r14    u1
.line	973	call         r14     1     2
.label	l320
.line	973	settable     r13  k125   r14 ; k125 = "Desc"
.line	973	test         r11     0
.line	973	jmp            0  l326
.line	973	gettable     r14   r11  k120 ; k120 = "SourceAssetId"
.line	973	test         r14     1
.line	973	jmp            0  l327
.label	l326
.line	973	loadnil      r14     0
.label	l327
.line	973	settable     r13  k120   r14 ; k120 = "SourceAssetId"
.line	973	gettable     r14    r5  k127 ; k127 = "Generate"
.line	973	gettable     r15    r5  k128 ; k128 = "DynamicAssetType"
.line	973	gettable     r15   r15  k129 ; k129 = "UMGCanvas"
.line	973	move         r16    r9
.line	973	call         r14     3     2
.line	973	settable     r13  k126   r14 ; k126 = "UGCAssetID"
.line	973	settable     r13  k130  k131 ; k131 = true
.line	973	self         r14    r0  k132 ; k132 = "GetAssetRestrictions"
.line	973	move         r16   r12
.line	973	call         r14     3     2
.line	973	self         r15    r0  k133 ; k133 = "ApplyAssetRestrictio" (truncated)
.line	973	move         r17   r13
.line	973	move         r18   r14
.line	973	call         r15     4     1
.line	973	gettabup     r15    u0    k2 ; k2 = "table"
.line	973	gettable     r15   r15  k134 ; k134 = "insert"
.line	973	gettable     r16    r0   k57 ; k57 = "AssetPathMap"
.line	973	move         r17   r13
.line	973	call         r15     3     1
.line	973	loadbool      r4     1     0
.label	l348
.line	973	move          r0    r0
.line	973	move          r0    r0
.line	973	loadk         r6   k46 ; k46 = 1
.line	973	gettable      r7    r0   k57 ; k57 = "AssetPathMap"
.line	973	len           r7    r7
.line	973	loadk         r8   k46 ; k46 = 1
.line	973	move          r0    r0
.line	973	gettable     r10    r0   k57 ; k57 = "AssetPathMap"
.line	973	gettable     r10   r10    r9
.line	973	gettable     r11   r10   k59 ; k59 = "AssetType"
.line	973	gettabup     r12    u2   k60 ; k60 = "UMG"
.line	973	eq             0   r11   r12
.line	973	jmp            0  l378
.line	973	gettabup     r11    u0   k56 ; k56 = "tonumber"
.line	973	gettable     r12   r10   k61 ; k61 = "AssetUID"
.line	973	call         r11     2     2
.line	973	gettable     r12    r3   r11
.line	973	test         r12     0
.line	973	jmp            0  l378
.line	973	gettable     r13   r12  k123 ; k123 = "CanvasName"
.line	973	test         r13     1
.line	973	jmp            0  l373
.line	973	gettabup     r13    u0  k121 ; k121 = "tostring"
.line	973	move         r14   r11
.line	973	call         r13     2     2
.label	l373
.line	973	gettable     r14   r10  k122 ; k122 = "AssetName"
.line	973	eq             1   r14   r13
.line	973	jmp            0  l378
.line	973	settable     r10  k122   r13 ; k122 = "AssetName"
.line	973	loadbool      r4     1     0
.label	l378
.line	973	move          r0    r0
.line	973	test          r4     0
.line	973	jmp            0  l383
.line	973	self          r6    r0  k135 ; k135 = "SaveAssetPathMap"
.line	973	call          r6     2     1
.label	l383
.line	973	return        r4     2
.line	973	return        r0     1
.line	973	move          r0    r0
.line	973	move          r0    r0
.line	973	move          r0    r0
.line	973	move          r0    r0
.line	973	return        r0     1

.function	main/f31

.source	null
.linedefined	1053
.lastlinedefined	1122
.numparams	2
.is_vararg	0
.maxstacksize	59

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true
.upvalue	"U3"	18	true
.upvalue	"U4"	15	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	177
.constant	k5	122
.constant	k6	126
.constant	k7	49
.constant	k8	120
.constant	k9	255
.constant	k10	205
.constant	k11	35
.constant	k12	175
.constant	k13	19
.constant	k14	235
.constant	k15	176
.constant	k16	251
.constant	k17	219
.constant	k18	223
.constant	k19	115
.constant	k20	81
.constant	k21	10
.constant	k22	142
.constant	k23	174
.constant	k24	14
.constant	k25	247
.constant	k26	27
.constant	k27	250
.constant	k28	128
.constant	k29	229
.constant	k30	245
.constant	k31	241
.constant	k32	118
.constant	k33	90
.constant	k34	59
.constant	k35	32
.constant	k36	171
.constant	k37	217
.constant	k38	7
.constant	k39	167
.constant	k40	102
.constant	k41	17
.constant	k42	104
.constant	k43	"Items"
.constant	k44	0
.constant	k45	182
.constant	k46	148
.constant	k47	108
.constant	k48	180
.constant	k49	42
.constant	k50	242
.constant	k51	163
.constant	k52	252
.constant	k53	243
.constant	k54	200
.constant	k55	172
.constant	k56	95
.constant	k57	60
.constant	k58	41
.constant	k59	159
.constant	k60	"string"
.constant	k61	"format"
.constant	k62	48
.constant	k63	225
.constant	k64	227
.constant	k65	186
.constant	k66	207
.constant	k67	99
.constant	k68	75
.constant	k69	45
.constant	k70	204
.constant	k71	131
.constant	k72	173
.constant	k73	"ipairs"
.constant	k74	"AssetId"
.constant	k75	"FolderID"
.constant	k76	"UnloadingAssetIds"
.constant	k77	"tostring"
.constant	k78	nil
.constant	k79	"ImportingAssetMap"
.constant	k80	"tonumber"
.constant	k81	244
.constant	k82	226
.constant	k83	238
.constant	k84	197
.constant	k85	113
.constant	k86	5
.constant	k87	24
.constant	k88	55
.constant	k89	195
.constant	k90	189
.constant	k91	53
.constant	k92	169
.constant	k93	110
.constant	k94	166
.constant	k95	156
.constant	k96	218
.constant	k97	105
.constant	k98	89
.constant	k99	157
.constant	k100	86
.constant	k101	198
.constant	k102	84
.constant	k103	215
.constant	k104	202
.constant	k105	63
.constant	k106	184
.constant	k107	253
.constant	k108	150
.constant	k109	101
.constant	k110	"DebugInfo"
.constant	k111	"GetMetaInfoByAssetId"
.constant	k112	"Meta"
.constant	k113	"PrefabType"
.constant	k114	"UMG"
.constant	k115	"Actor"
.constant	k116	1
.constant	k117	"_G"
.constant	k118	"EnableUMGInfoManager"
.constant	k119	"MountAsset"
.constant	k120	"AddAssetToPathMapOnImport"
.constant	k121	"ImportActorsFromPrefabMall"
.constant	k122	"ImportUMGsFromPrefabMall"
.constant	k123	"SyncWorkAssetDataToEditor"
.constant	k124	"updateTimer"
.constant	k125	"AddTimerLoop"
.constant	k126	"TIMER_INFINITE"

.line	1053	gettabup      r2    u0    k0 ; k0 = "print"
.line	1053	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1053	test          r3     0
.line	1053	jmp            0   l59
.line	1053	gettabup      r3    u0    k2 ; k2 = "table"
.line	1053	gettable      r3    r3    k3 ; k3 = "concat"
.line	1053	newtable      r4     1     0
.line	1053	getupval      r5    u1
.line	1053	loadk         r6    k4 ; k4 = 177
.line	1053	loadk         r7    k5 ; k5 = 122
.line	1053	loadk         r8    k6 ; k6 = 126
.line	1053	loadk         r9    k7 ; k7 = 49
.line	1053	loadk        r10    k8 ; k8 = 120
.line	1053	loadk        r11    k9 ; k9 = 255
.line	1053	loadk        r12   k10 ; k10 = 205
.line	1053	loadk        r13   k11 ; k11 = 35
.line	1053	loadk        r14   k12 ; k12 = 175
.line	1053	loadk        r15   k13 ; k13 = 19
.line	1053	loadk        r16   k14 ; k14 = 235
.line	1053	loadk        r17   k15 ; k15 = 176
.line	1053	loadk        r18   k16 ; k16 = 251
.line	1053	loadk        r19   k17 ; k17 = 219
.line	1053	loadk        r20   k18 ; k18 = 223
.line	1053	loadk        r21    k9 ; k9 = 255
.line	1053	loadk        r22   k19 ; k19 = 115
.line	1053	loadk        r23   k20 ; k20 = 81
.line	1053	loadk        r24   k21 ; k21 = 10
.line	1053	loadk        r25    k7 ; k7 = 49
.line	1053	loadk        r26   k22 ; k22 = 142
.line	1053	loadk        r27   k14 ; k14 = 235
.line	1053	loadk        r28   k23 ; k23 = 174
.line	1053	loadk        r29   k24 ; k24 = 14
.line	1053	loadk        r30   k25 ; k25 = 247
.line	1053	loadk        r31   k26 ; k26 = 27
.line	1053	loadk        r32   k27 ; k27 = 250
.line	1053	loadk        r33   k28 ; k28 = 128
.line	1053	loadk        r34   k29 ; k29 = 229
.line	1053	loadk        r35   k16 ; k16 = 251
.line	1053	loadk        r36   k30 ; k30 = 245
.line	1053	loadk        r37   k31 ; k31 = 241
.line	1053	loadk        r38   k32 ; k32 = 118
.line	1053	loadk        r39   k33 ; k33 = 90
.line	1053	loadk        r40   k34 ; k34 = 59
.line	1053	loadk        r41   k35 ; k35 = 32
.line	1053	loadk        r42   k36 ; k36 = 171
.line	1053	loadk        r43   k37 ; k37 = 217
.line	1053	loadk        r44   k36 ; k36 = 171
.line	1053	loadk        r45   k38 ; k38 = 7
.line	1053	call          r5    41     2
.line	1053	getupval      r6    u1
.line	1053	loadk         r7   k39 ; k39 = 167
.line	1053	loadk         r8   k40 ; k40 = 102
.line	1053	loadk         r9   k33 ; k33 = 90
.line	1053	loadk        r10   k41 ; k41 = 17
.line	1053	loadk        r11   k42 ; k42 = 104
.line	1053	call          r6     6     0
.line	1053	setlist       r4     0     1
.line	1053	call          r3     2     2
.label	l59
.line	1053	call          r2     2     1
.line	1053	test          r1     0
.line	1053	jmp            0   l69
.line	1053	gettable      r2    r1   k43 ; k43 = "Items"
.line	1053	test          r2     0
.line	1053	jmp            0   l69
.line	1053	gettable      r2    r1   k43 ; k43 = "Items"
.line	1053	len           r2    r2
.line	1053	eq             0    r2   k44 ; k44 = 0
.line	1053	jmp            0  l145
.label	l69
.line	1053	gettabup      r2    u0    k0 ; k0 = "print"
.line	1053	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1053	test          r3     0
.line	1053	jmp            0  l143
.line	1053	gettabup      r3    u0    k2 ; k2 = "table"
.line	1053	gettable      r3    r3    k3 ; k3 = "concat"
.line	1053	newtable      r4     1     0
.line	1053	getupval      r5    u1
.line	1053	loadk         r6    k4 ; k4 = 177
.line	1053	loadk         r7    k5 ; k5 = 122
.line	1053	loadk         r8    k6 ; k6 = 126
.line	1053	loadk         r9    k7 ; k7 = 49
.line	1053	loadk        r10    k8 ; k8 = 120
.line	1053	loadk        r11    k9 ; k9 = 255
.line	1053	loadk        r12   k10 ; k10 = 205
.line	1053	loadk        r13   k11 ; k11 = 35
.line	1053	loadk        r14   k12 ; k12 = 175
.line	1053	loadk        r15   k13 ; k13 = 19
.line	1053	loadk        r16   k14 ; k14 = 235
.line	1053	loadk        r17   k15 ; k15 = 176
.line	1053	loadk        r18   k16 ; k16 = 251
.line	1053	loadk        r19   k17 ; k17 = 219
.line	1053	loadk        r20   k18 ; k18 = 223
.line	1053	loadk        r21    k9 ; k9 = 255
.line	1053	loadk        r22   k19 ; k19 = 115
.line	1053	loadk        r23   k20 ; k20 = 81
.line	1053	loadk        r24   k21 ; k21 = 10
.line	1053	loadk        r25    k7 ; k7 = 49
.line	1053	loadk        r26   k22 ; k22 = 142
.line	1053	loadk        r27   k14 ; k14 = 235
.line	1053	loadk        r28   k23 ; k23 = 174
.line	1053	loadk        r29   k24 ; k24 = 14
.line	1053	loadk        r30   k25 ; k25 = 247
.line	1053	loadk        r31   k26 ; k26 = 27
.line	1053	loadk        r32   k27 ; k27 = 250
.line	1053	loadk        r33   k28 ; k28 = 128
.line	1053	loadk        r34   k29 ; k29 = 229
.line	1053	loadk        r35   k16 ; k16 = 251
.line	1053	loadk        r36   k30 ; k30 = 245
.line	1053	loadk        r37   k31 ; k31 = 241
.line	1053	loadk        r38   k32 ; k32 = 118
.line	1053	loadk        r39   k33 ; k33 = 90
.line	1053	loadk        r40   k34 ; k34 = 59
.line	1053	loadk        r41   k35 ; k35 = 32
.line	1053	loadk        r42   k36 ; k36 = 171
.line	1053	loadk        r43   k37 ; k37 = 217
.line	1053	loadk        r44   k36 ; k36 = 171
.line	1053	loadk        r45   k38 ; k38 = 7
.line	1053	call          r5    41     2
.line	1053	getupval      r6    u1
.line	1053	loadk         r7   k39 ; k39 = 167
.line	1053	loadk         r8   k40 ; k40 = 102
.line	1053	loadk         r9   k33 ; k33 = 90
.line	1053	loadk        r10   k41 ; k41 = 17
.line	1053	loadk        r11   k42 ; k42 = 104
.line	1053	loadk        r12   k45 ; k45 = 182
.line	1053	loadk        r13   k46 ; k46 = 148
.line	1053	loadk        r14   k47 ; k47 = 108
.line	1053	loadk        r15   k48 ; k48 = 180
.line	1053	loadk        r16   k49 ; k49 = 42
.line	1053	loadk        r17   k50 ; k50 = 242
.line	1053	loadk        r18   k51 ; k51 = 163
.line	1053	loadk        r19   k52 ; k52 = 252
.line	1053	loadk        r20   k53 ; k53 = 243
.line	1053	loadk        r21   k54 ; k54 = 200
.line	1053	loadk        r22   k55 ; k55 = 172
.line	1053	loadk        r23   k56 ; k56 = 95
.line	1053	loadk        r24   k20 ; k20 = 81
.line	1053	loadk        r25   k57 ; k57 = 60
.line	1053	loadk        r26   k58 ; k58 = 41
.line	1053	loadk        r27   k59 ; k59 = 159
.line	1053	call          r6    22     0
.line	1053	setlist       r4     0     1
.line	1053	call          r3     2     2
.label	l143
.line	1053	call          r2     2     1
.line	1053	return        r0     1
.label	l145
.line	1053	gettable      r2    r1   k43 ; k43 = "Items"
.line	1053	gettabup      r3    u0    k0 ; k0 = "print"
.line	1053	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	1053	test          r4     0
.line	1053	jmp            0  l226
.line	1053	gettabup      r4    u0   k60 ; k60 = "string"
.line	1053	gettable      r4    r4   k61 ; k61 = "format"
.line	1053	gettabup      r5    u0    k2 ; k2 = "table"
.line	1053	gettable      r5    r5    k3 ; k3 = "concat"
.line	1053	newtable      r6     1     0
.line	1053	getupval      r7    u1
.line	1053	loadk         r8    k4 ; k4 = 177
.line	1053	loadk         r9    k5 ; k5 = 122
.line	1053	loadk        r10    k6 ; k6 = 126
.line	1053	loadk        r11    k7 ; k7 = 49
.line	1053	loadk        r12    k8 ; k8 = 120
.line	1053	loadk        r13    k9 ; k9 = 255
.line	1053	loadk        r14   k10 ; k10 = 205
.line	1053	loadk        r15   k11 ; k11 = 35
.line	1053	loadk        r16   k12 ; k12 = 175
.line	1053	loadk        r17   k13 ; k13 = 19
.line	1053	loadk        r18   k14 ; k14 = 235
.line	1053	loadk        r19   k15 ; k15 = 176
.line	1053	loadk        r20   k16 ; k16 = 251
.line	1053	loadk        r21   k17 ; k17 = 219
.line	1053	loadk        r22   k18 ; k18 = 223
.line	1053	loadk        r23    k9 ; k9 = 255
.line	1053	loadk        r24   k19 ; k19 = 115
.line	1053	loadk        r25   k20 ; k20 = 81
.line	1053	loadk        r26   k21 ; k21 = 10
.line	1053	loadk        r27    k7 ; k7 = 49
.line	1053	loadk        r28   k22 ; k22 = 142
.line	1053	loadk        r29   k14 ; k14 = 235
.line	1053	loadk        r30   k23 ; k23 = 174
.line	1053	loadk        r31   k24 ; k24 = 14
.line	1053	loadk        r32   k25 ; k25 = 247
.line	1053	loadk        r33   k26 ; k26 = 27
.line	1053	loadk        r34   k27 ; k27 = 250
.line	1053	loadk        r35   k28 ; k28 = 128
.line	1053	loadk        r36   k29 ; k29 = 229
.line	1053	loadk        r37   k16 ; k16 = 251
.line	1053	loadk        r38   k30 ; k30 = 245
.line	1053	loadk        r39   k31 ; k31 = 241
.line	1053	loadk        r40   k32 ; k32 = 118
.line	1053	loadk        r41   k33 ; k33 = 90
.line	1053	loadk        r42   k34 ; k34 = 59
.line	1053	loadk        r43   k35 ; k35 = 32
.line	1053	loadk        r44   k36 ; k36 = 171
.line	1053	loadk        r45   k37 ; k37 = 217
.line	1053	loadk        r46   k36 ; k36 = 171
.line	1053	loadk        r47   k38 ; k38 = 7
.line	1053	call          r7    41     2
.line	1053	getupval      r8    u1
.line	1053	loadk         r9   k39 ; k39 = 167
.line	1053	loadk        r10   k40 ; k40 = 102
.line	1053	loadk        r11   k33 ; k33 = 90
.line	1053	loadk        r12   k41 ; k41 = 17
.line	1053	loadk        r13   k42 ; k42 = 104
.line	1053	loadk        r14   k45 ; k45 = 182
.line	1053	loadk        r15   k46 ; k46 = 148
.line	1053	loadk        r16   k47 ; k47 = 108
.line	1053	loadk        r17   k46 ; k46 = 148
.line	1053	loadk        r18   k62 ; k62 = 48
.line	1053	loadk        r19   k63 ; k63 = 225
.line	1053	loadk        r20   k12 ; k12 = 175
.line	1053	loadk        r21   k64 ; k64 = 227
.line	1053	loadk        r22   k65 ; k65 = 186
.line	1053	loadk        r23   k66 ; k66 = 207
.line	1053	loadk        r24   k64 ; k64 = 227
.line	1053	loadk        r25   k67 ; k67 = 99
.line	1053	loadk        r26   k68 ; k68 = 75
.line	1053	loadk        r27   k69 ; k69 = 45
.line	1053	loadk        r28    k6 ; k6 = 126
.line	1053	loadk        r29   k70 ; k70 = 204
.line	1053	loadk        r30   k71 ; k71 = 131
.line	1053	loadk        r31   k72 ; k72 = 173
.line	1053	call          r8    24     0
.line	1053	setlist       r6     0     1
.line	1053	call          r5     2     2
.line	1053	len           r6    r2
.line	1053	call          r4     3     2
.label	l226
.line	1053	call          r3     2     1
.line	1053	newtable      r3     0     0
.line	1053	newtable      r4     0     0
.line	1053	loadbool      r5     0     0
.line	1053	gettabup      r6    u0   k73 ; k73 = "ipairs"
.line	1053	move          r7    r2
.line	1053	call          r6     2     4
.line	1053	jmp            0  l488
.line	1053	gettable     r11   r10   k74 ; k74 = "AssetId"
.line	1053	gettable     r12   r10   k75 ; k75 = "FolderID"
.line	1053	test         r12     1
.line	1053	jmp            0  l240
.line	1053	getupval     r12    u1
.line	1053	call         r12     1     2
.label	l240
.line	1053	test         r11     0
.line	1053	jmp            0  l250
.line	1053	gettable     r13    r0   k76 ; k76 = "UnloadingAssetIds"
.line	1053	test         r13     0
.line	1053	jmp            0  l250
.line	1053	gettable     r13    r0   k76 ; k76 = "UnloadingAssetIds"
.line	1053	gettabup     r14    u0   k77 ; k77 = "tostring"
.line	1053	move         r15   r11
.line	1053	call         r14     2     2
.line	1053	settable     r13   r14   k78 ; k78 = nil
.label	l250
.line	1053	gettable     r13    r0   k79 ; k79 = "ImportingAssetMap"
.line	1053	test         r13     1
.line	1053	jmp            0  l254
.line	1053	newtable     r13     0     0
.label	l254
.line	1053	settable      r0   k79   r13 ; k79 = "ImportingAssetMap"
.line	1053	gettable     r13    r0   k79 ; k79 = "ImportingAssetMap"
.line	1053	gettabup     r14    u0   k80 ; k80 = "tonumber"
.line	1053	move         r15   r11
.line	1053	call         r14     2     2
.line	1053	settable     r13   r14   r12
.line	1053	test         r11     0
.line	1053	jmp            0  l488
.line	1053	getupval     r13    u1
.line	1053	call         r13     1     2
.line	1053	eq             1   r11   r13
.line	1053	jmp            0  l488
.line	1053	gettabup     r13    u0    k0 ; k0 = "print"
.line	1053	gettabup     r14    u0    k1 ; k1 = "bWriteLog"
.line	1053	test         r14     0
.line	1053	jmp            0  l401
.line	1053	gettabup     r14    u0   k60 ; k60 = "string"
.line	1053	gettable     r14   r14   k61 ; k61 = "format"
.line	1053	gettabup     r15    u0    k2 ; k2 = "table"
.line	1053	gettable     r15   r15    k3 ; k3 = "concat"
.line	1053	newtable     r16     2     0
.line	1053	getupval     r17    u1
.line	1053	loadk        r18    k4 ; k4 = 177
.line	1053	loadk        r19    k5 ; k5 = 122
.line	1053	loadk        r20    k6 ; k6 = 126
.line	1053	loadk        r21    k7 ; k7 = 49
.line	1053	loadk        r22    k8 ; k8 = 120
.line	1053	loadk        r23    k9 ; k9 = 255
.line	1053	loadk        r24   k10 ; k10 = 205
.line	1053	loadk        r25   k11 ; k11 = 35
.line	1053	loadk        r26   k12 ; k12 = 175
.line	1053	loadk        r27   k13 ; k13 = 19
.line	1053	loadk        r28   k14 ; k14 = 235
.line	1053	loadk        r29   k15 ; k15 = 176
.line	1053	loadk        r30   k16 ; k16 = 251
.line	1053	loadk        r31   k17 ; k17 = 219
.line	1053	loadk        r32   k18 ; k18 = 223
.line	1053	loadk        r33    k9 ; k9 = 255
.line	1053	loadk        r34   k19 ; k19 = 115
.line	1053	loadk        r35   k20 ; k20 = 81
.line	1053	loadk        r36   k21 ; k21 = 10
.line	1053	loadk        r37    k7 ; k7 = 49
.line	1053	loadk        r38   k22 ; k22 = 142
.line	1053	loadk        r39   k14 ; k14 = 235
.line	1053	loadk        r40   k23 ; k23 = 174
.line	1053	loadk        r41   k24 ; k24 = 14
.line	1053	loadk        r42   k25 ; k25 = 247
.line	1053	loadk        r43   k26 ; k26 = 27
.line	1053	loadk        r44   k27 ; k27 = 250
.line	1053	loadk        r45   k28 ; k28 = 128
.line	1053	loadk        r46   k29 ; k29 = 229
.line	1053	loadk        r47   k16 ; k16 = 251
.line	1053	loadk        r48   k30 ; k30 = 245
.line	1053	loadk        r49   k31 ; k31 = 241
.line	1053	loadk        r50   k32 ; k32 = 118
.line	1053	loadk        r51   k33 ; k33 = 90
.line	1053	loadk        r52   k34 ; k34 = 59
.line	1053	loadk        r53   k35 ; k35 = 32
.line	1053	loadk        r54   k36 ; k36 = 171
.line	1053	loadk        r55   k37 ; k37 = 217
.line	1053	loadk        r56   k36 ; k36 = 171
.line	1053	loadk        r57   k38 ; k38 = 7
.line	1053	call         r17    41     2
.line	1053	getupval     r18    u1
.line	1053	loadk        r19   k39 ; k39 = 167
.line	1053	loadk        r20   k40 ; k40 = 102
.line	1053	loadk        r21   k33 ; k33 = 90
.line	1053	loadk        r22   k41 ; k41 = 17
.line	1053	loadk        r23   k42 ; k42 = 104
.line	1053	loadk        r24   k45 ; k45 = 182
.line	1053	loadk        r25   k46 ; k46 = 148
.line	1053	loadk        r26   k47 ; k47 = 108
.line	1053	loadk        r27   k48 ; k48 = 180
.line	1053	loadk        r28   k58 ; k58 = 41
.line	1053	loadk        r29   k81 ; k81 = 244
.line	1053	loadk        r30   k72 ; k72 = 173
.line	1053	loadk        r31   k82 ; k82 = 226
.line	1053	loadk        r32   k83 ; k83 = 238
.line	1053	loadk        r33   k84 ; k84 = 197
.line	1053	loadk        r34   k82 ; k82 = 226
.line	1053	loadk        r35   k85 ; k85 = 113
.line	1053	loadk        r36   k86 ; k86 = 5
.line	1053	loadk        r37   k87 ; k87 = 24
.line	1053	loadk        r38   k88 ; k88 = 55
.line	1053	loadk        r39   k59 ; k59 = 159
.line	1053	loadk        r40   k89 ; k89 = 195
.line	1053	loadk        r41   k90 ; k90 = 189
.line	1053	loadk        r42   k91 ; k91 = 53
.line	1053	loadk        r43   k92 ; k92 = 169
.line	1053	loadk        r44   k93 ; k93 = 110
.line	1053	loadk        r45   k48 ; k48 = 180
.line	1053	loadk        r46   k25 ; k25 = 247
.line	1053	loadk        r47   k53 ; k53 = 243
.line	1053	loadk        r48   k94 ; k94 = 166
.line	1053	loadk        r49   k95 ; k95 = 156
.line	1053	loadk        r50   k96 ; k96 = 218
.line	1053	loadk        r51   k97 ; k97 = 105
.line	1053	loadk        r52   k98 ; k98 = 89
.line	1053	loadk        r53   k69 ; k69 = 45
.line	1053	loadk        r54    k7 ; k7 = 49
.line	1053	loadk        r55   k22 ; k22 = 142
.line	1053	loadk        r56    k9 ; k9 = 255
.line	1053	loadk        r57   k99 ; k99 = 157
.line	1053	loadk        r58  k100 ; k100 = 86
.line	1053	call         r18    41     2
.line	1053	getupval     r19    u1
.line	1053	loadk        r20  k101 ; k101 = 198
.line	1053	loadk        r21   k62 ; k62 = 48
.line	1053	loadk        r22   k33 ; k33 = 90
.line	1053	loadk        r23  k102 ; k102 = 84
.line	1053	loadk        r24   k62 ; k62 = 48
.line	1053	loadk        r25  k103 ; k103 = 215
.line	1053	loadk        r26  k104 ; k104 = 202
.line	1053	loadk        r27  k105 ; k105 = 63
.line	1053	loadk        r28  k106 ; k106 = 184
.line	1053	loadk        r29   k62 ; k62 = 48
.line	1053	loadk        r30  k104 ; k104 = 202
.line	1053	loadk        r31   k51 ; k51 = 163
.line	1053	loadk        r32  k107 ; k107 = 253
.line	1053	loadk        r33    k9 ; k9 = 255
.line	1053	loadk        r34  k108 ; k108 = 150
.line	1053	loadk        r35   k92 ; k92 = 169
.line	1053	loadk        r36  k109 ; k109 = 101
.line	1053	call         r19    18     0
.line	1053	setlist      r16     0     1
.line	1053	call         r15     2     2
.line	1053	gettabup     r16    u0   k77 ; k77 = "tostring"
.line	1053	move         r17   r11
.line	1053	call         r16     2     2
.line	1053	gettabup     r17    u0   k77 ; k77 = "tostring"
.line	1053	move         r18   r12
.line	1053	call         r17     2     2
.line	1053	gettable     r18    r0  k110 ; k110 = "DebugInfo"
.line	1053	test         r18     0
.line	1053	jmp            0  l398
.line	1053	gettabup     r18    u0   k77 ; k77 = "tostring"
.line	1053	gettable     r19    r0  k110 ; k110 = "DebugInfo"
.line	1053	gettabup     r20    u0   k80 ; k80 = "tonumber"
.line	1053	move         r21   r11
.line	1053	call         r20     2     2
.line	1053	gettable     r19   r19   r20
.line	1053	call         r18     2     2
.line	1053	test         r18     1
.line	1053	jmp            0  l400
.label	l398
.line	1053	getupval     r18    u1
.line	1053	call         r18     1     2
.label	l400
.line	1053	call         r14     5     2
.label	l401
.line	1053	call         r13     2     1
.line	1053	loadbool     r13     0     0
.line	1053	loadbool     r14     0     0
.line	1053	getupval     r15    u2
.line	1053	self         r15   r15  k111 ; k111 = "GetMetaInfoByAssetId"
.line	1053	gettabup     r17    u0   k80 ; k80 = "tonumber"
.line	1053	move         r18   r11
.line	1053	call         r17     2     0
.line	1053	call         r15     0     2
.line	1053	test         r15     0
.line	1053	jmp            0  l430
.line	1053	gettable     r16   r15  k112 ; k112 = "Meta"
.line	1053	test         r16     0
.line	1053	jmp            0  l430
.line	1053	gettable     r16   r15  k112 ; k112 = "Meta"
.line	1053	gettable     r16   r16  k113 ; k113 = "PrefabType"
.line	1053	gettabup     r16    u3   r16
.line	1053	gettabup     r17    u4  k114 ; k114 = "UMG"
.line	1053	eq             0   r16   r17
.line	1053	jmp            0  l423
.line	1053	loadbool     r13     1     0
.line	1053	jmp            0  l430
.label	l423
.line	1053	gettable     r16   r15  k112 ; k112 = "Meta"
.line	1053	gettable     r16   r16  k113 ; k113 = "PrefabType"
.line	1053	gettabup     r16    u3   r16
.line	1053	gettabup     r17    u4  k115 ; k115 = "Actor"
.line	1053	eq             0   r16   r17
.line	1053	jmp            0  l430
.line	1053	loadbool     r14     1     0
.label	l430
.line	1053	test         r14     0
.line	1053	jmp            0  l442
.line	1053	len          r16    r3
.line	1053	add          r16   r16  k116 ; k116 = 1
.line	1053	newtable     r17     0     2
.line	1053	gettabup     r18    u0   k80 ; k80 = "tonumber"
.line	1053	move         r19   r11
.line	1053	call         r18     2     2
.line	1053	settable     r17   k74   r18 ; k74 = "AssetId"
.line	1053	settable     r17   k75   r12 ; k75 = "FolderID"
.line	1053	settable      r3   r16   r17
.line	1053	jmp            0  l488
.label	l442
.line	1053	test         r13     0
.line	1053	jmp            0  l480
.line	1053	gettabup     r16    u0  k117 ; k117 = "_G"
.line	1053	gettable     r16   r16  k118 ; k118 = "EnableUMGInfoManager"
.line	1053	test         r16     0
.line	1053	jmp            0  l466
.line	1053	len          r16    r4
.line	1053	add          r16   r16  k116 ; k116 = 1
.line	1053	newtable     r17     0     2
.line	1053	gettabup     r18    u0   k80 ; k80 = "tonumber"
.line	1053	move         r19   r11
.line	1053	call         r18     2     2
.line	1053	settable     r17   k74   r18 ; k74 = "AssetId"
.line	1053	settable     r17   k75   r12 ; k75 = "FolderID"
.line	1053	settable      r4   r16   r17
.line	1053	getupval     r16    u2
.line	1053	self         r16   r16  k119 ; k119 = "MountAsset"
.line	1053	gettabup     r18    u0   k80 ; k80 = "tonumber"
.line	1053	move         r19   r11
.line	1053	call         r18     2     2
.line	1053	loadbool     r19     1     0
.line	1053	loadbool     r20     1     0
.line	1053	call         r16     5     1
.line	1053	jmp            0  l488
.label	l466
.line	1053	getupval     r16    u2
.line	1053	self         r16   r16  k119 ; k119 = "MountAsset"
.line	1053	gettabup     r18    u0   k80 ; k80 = "tonumber"
.line	1053	move         r19   r11
.line	1053	call         r18     2     2
.line	1053	loadbool     r19     1     0
.line	1053	loadbool     r20     1     0
.line	1053	call         r16     5     1
.line	1053	self         r16    r0  k120 ; k120 = "AddAssetToPathMapOnI" (truncated)
.line	1053	move         r18   r11
.line	1053	move         r19   r12
.line	1053	call         r16     4     1
.line	1053	loadbool      r5     1     0
.line	1053	jmp            0  l488
.label	l480
.line	1053	getupval     r16    u2
.line	1053	self         r16   r16  k119 ; k119 = "MountAsset"
.line	1053	gettabup     r18    u0   k80 ; k80 = "tonumber"
.line	1053	move         r19   r11
.line	1053	call         r18     2     2
.line	1053	loadbool     r19     1     0
.line	1053	loadbool     r20     1     0
.line	1053	call         r16     5     1
.label	l488
.line	1053	move          r0    r0
.line	1053	move          r0    r0
.line	1053	len           r6    r3
.line	1053	lt             0   k44    r6 ; k44 = 0
.line	1053	jmp            0  l496
.line	1053	self          r6    r0  k121 ; k121 = "ImportActorsFromPref" (truncated)
.line	1053	move          r8    r3
.line	1053	call          r6     3     1
.label	l496
.line	1053	len           r6    r4
.line	1053	lt             0   k44    r6 ; k44 = 0
.line	1053	jmp            0  l502
.line	1053	self          r6    r0  k122 ; k122 = "ImportUMGsFromPrefab" (truncated)
.line	1053	move          r8    r4
.line	1053	call          r6     3     1
.label	l502
.line	1053	test          r5     0
.line	1053	jmp            0  l506
.line	1053	self          r6    r0  k123 ; k123 = "SyncWorkAssetDataToE" (truncated)
.line	1053	call          r6     2     1
.label	l506
.line	1053	self          r6    r0  k125 ; k125 = "AddTimerLoop"
.line	1053	loadk         r8  k116 ; k116 = 1
.line	1053	closure       r9    f0
.line	1053	gettabup     r10    u0  k126 ; k126 = "TIMER_INFINITE"
.line	1053	loadk        r11  k116 ; k116 = 1
.line	1053	call          r6     6     2
.line	1053	settable      r0  k124    r6 ; k124 = "updateTimer"
.line	1053	return        r0     1
.line	1053	move          r0    r0
.line	1053	move          r0    r0
.line	1053	move          r0    r0
.line	1053	return        r0     1

.function	main/f31/f0

.source	null
.linedefined	1115
.lastlinedefined	1121
.numparams	0
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	0	true
.upvalue	"U1"	0	false

.constant	k0	"ImportingAssetMap"
.constant	k1	"next"
.constant	k2	"RemoveTimer"
.constant	k3	"updateTimer"
.constant	k4	nil
.constant	k5	"SyncWorkAssetDataToEditor"

.line	1115	gettabup      r0    u0    k0 ; k0 = "ImportingAssetMap"
.line	1115	test          r0     0
.line	1115	jmp            0    l9
.line	1115	gettabup      r0    u1    k1 ; k1 = "next"
.line	1115	gettabup      r1    u0    k0 ; k0 = "ImportingAssetMap"
.line	1115	call          r0     2     2
.line	1115	test          r0     1
.line	1115	jmp            0   l17
.label	l9
.line	1115	getupval      r0    u0
.line	1115	self          r0    r0    k2 ; k2 = "RemoveTimer"
.line	1115	gettabup      r2    u0    k3 ; k3 = "updateTimer"
.line	1115	call          r0     3     1
.line	1115	settabup      u0    k3    k4 ; k4 = nil
.line	1115	getupval      r0    u0
.line	1115	self          r0    r0    k5 ; k5 = "SyncWorkAssetDataToE" (truncated)
.line	1115	call          r0     2     1
.label	l17
.line	1115	return        r0     1
.line	1115	move          r0    r0
.line	1115	move          r0    r0
.line	1115	return        r0     1

.function	main/f32

.source	null
.linedefined	1124
.lastlinedefined	1164
.numparams	3
.is_vararg	0
.maxstacksize	56

.upvalue	"_ENV"	8	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	18	true

.constant	k0	"GetMetaInfoByAssetId"
.constant	k1	"tonumber"
.constant	k2	"Meta"
.constant	k3	"print"
.constant	k4	"bWriteLog"
.constant	k5	"string"
.constant	k6	"format"
.constant	k7	"table"
.constant	k8	"concat"
.constant	k9	177
.constant	k10	122
.constant	k11	126
.constant	k12	49
.constant	k13	120
.constant	k14	255
.constant	k15	205
.constant	k16	35
.constant	k17	175
.constant	k18	19
.constant	k19	235
.constant	k20	176
.constant	k21	251
.constant	k22	219
.constant	k23	223
.constant	k24	115
.constant	k25	81
.constant	k26	10
.constant	k27	142
.constant	k28	174
.constant	k29	14
.constant	k30	247
.constant	k31	21
.constant	k32	240
.constant	k33	182
.constant	k34	193
.constant	k35	249
.constant	k36	207
.constant	k37	114
.constant	k38	97
.constant	k39	38
.constant	k40	4
.constant	k41	157
.constant	k42	194
.constant	k43	33
.constant	k44	135
.constant	k45	101
.constant	k46	102
.constant	k47	26
.constant	k48	85
.constant	k49	201
.constant	k50	48
.constant	k51	164
.constant	k52	239
.constant	k53	191
.constant	k54	172
.constant	k55	91
.constant	k56	64
.constant	k57	45
.constant	k58	37
.constant	k59	165
.constant	k60	200
.constant	k61	237
.constant	k62	58
.constant	k63	166
.constant	k64	160
.constant	k65	236
.constant	k66	211
.constant	k67	233
.constant	k68	104
.constant	k69	"tostring"
.constant	k70	"PrefabType"
.constant	k71	99
.constant	k72	75
.constant	k73	42
.constant	k74	156
.constant	k75	214
.constant	k76	185
.constant	k77	242
.constant	k78	208
.constant	k79	248
.constant	k80	217
.constant	k81	250
.constant	k82	103
.constant	k83	87
.constant	k84	29
.constant	k85	140
.constant	k86	227
.constant	k87	76
.constant	k88	195
.constant	k89	"GetFolderIDForAssetType"
.constant	k90	"IsAssetInPathMap"
.constant	k91	119
.constant	k92	73
.constant	k93	43
.constant	k94	141
.constant	k95	92
.constant	k96	180
.constant	k97	147
.constant	k98	243
.constant	k99	232
.constant	k100	86
.constant	k101	84
.constant	k102	61
.constant	k103	60
.constant	k104	215
.constant	k105	169
.constant	k106	198
.constant	k107	66
.constant	k108	108
.constant	k109	"ImportingAssetMap"
.constant	k110	nil
.constant	k111	"AssetUID"
.constant	k112	"AssetName"
.constant	k113	"Name"
.constant	k114	"AssetType"
.constant	k115	"FolderID"
.constant	k116	"Icon"
.constant	k117	"Pic_Url"
.constant	k118	"Desc"
.constant	k119	"GetAssetRestrictions"
.constant	k120	"ApplyAssetRestrictions"
.constant	k121	"insert"
.constant	k122	"AssetPathMap"
.constant	k123	"SaveAssetPathMap"
.constant	k124	65
.constant	k125	136
.constant	k126	134
.constant	k127	189
.constant	k128	231
.constant	k129	161
.constant	k130	229
.constant	k131	254
.constant	k132	253
.constant	k133	93
.constant	k134	53
.constant	k135	154
.constant	k136	137
.constant	k137	121
.constant	k138	77
.constant	k139	17
.constant	k140	110
.constant	k141	118

.line	1124	getupval      r3    u0
.line	1124	self          r3    r3    k0 ; k0 = "GetMetaInfoByAssetId"
.line	1124	gettabup      r5    u1    k1 ; k1 = "tonumber"
.line	1124	move          r6    r1
.line	1124	call          r5     2     0
.line	1124	call          r3     0     2
.line	1124	test          r3     0
.line	1124	jmp            0   l12
.line	1124	gettable      r4    r3    k2 ; k2 = "Meta"
.line	1124	test          r4     1
.line	1124	jmp            0  l107
.label	l12
.line	1124	gettabup      r4    u1    k3 ; k3 = "print"
.line	1124	gettabup      r5    u1    k4 ; k4 = "bWriteLog"
.line	1124	test          r5     0
.line	1124	jmp            0  l105
.line	1124	gettabup      r5    u1    k5 ; k5 = "string"
.line	1124	gettable      r5    r5    k6 ; k6 = "format"
.line	1124	gettabup      r6    u1    k7 ; k7 = "table"
.line	1124	gettable      r6    r6    k8 ; k8 = "concat"
.line	1124	newtable      r7     1     0
.line	1124	getupval      r8    u2
.line	1124	loadk         r9    k9 ; k9 = 177
.line	1124	loadk        r10   k10 ; k10 = 122
.line	1124	loadk        r11   k11 ; k11 = 126
.line	1124	loadk        r12   k12 ; k12 = 49
.line	1124	loadk        r13   k13 ; k13 = 120
.line	1124	loadk        r14   k14 ; k14 = 255
.line	1124	loadk        r15   k15 ; k15 = 205
.line	1124	loadk        r16   k16 ; k16 = 35
.line	1124	loadk        r17   k17 ; k17 = 175
.line	1124	loadk        r18   k18 ; k18 = 19
.line	1124	loadk        r19   k19 ; k19 = 235
.line	1124	loadk        r20   k20 ; k20 = 176
.line	1124	loadk        r21   k21 ; k21 = 251
.line	1124	loadk        r22   k22 ; k22 = 219
.line	1124	loadk        r23   k23 ; k23 = 223
.line	1124	loadk        r24   k14 ; k14 = 255
.line	1124	loadk        r25   k24 ; k24 = 115
.line	1124	loadk        r26   k25 ; k25 = 81
.line	1124	loadk        r27   k26 ; k26 = 10
.line	1124	loadk        r28   k12 ; k12 = 49
.line	1124	loadk        r29   k27 ; k27 = 142
.line	1124	loadk        r30   k19 ; k19 = 235
.line	1124	loadk        r31   k28 ; k28 = 174
.line	1124	loadk        r32   k29 ; k29 = 14
.line	1124	loadk        r33   k30 ; k30 = 247
.line	1124	loadk        r34   k31 ; k31 = 21
.line	1124	loadk        r35   k32 ; k32 = 240
.line	1124	loadk        r36   k33 ; k33 = 182
.line	1124	loadk        r37   k34 ; k34 = 193
.line	1124	loadk        r38   k35 ; k35 = 249
.line	1124	loadk        r39   k36 ; k36 = 207
.line	1124	loadk        r40   k35 ; k35 = 249
.line	1124	loadk        r41   k37 ; k37 = 114
.line	1124	loadk        r42   k38 ; k38 = 97
.line	1124	loadk        r43   k39 ; k39 = 38
.line	1124	loadk        r44   k40 ; k40 = 4
.line	1124	loadk        r45   k41 ; k41 = 157
.line	1124	loadk        r46   k42 ; k42 = 194
.line	1124	loadk        r47    k9 ; k9 = 177
.line	1124	loadk        r48   k43 ; k43 = 33
.line	1124	call          r8    41     2
.line	1124	getupval      r9    u2
.line	1124	loadk        r10   k44 ; k44 = 135
.line	1124	loadk        r11   k45 ; k45 = 101
.line	1124	loadk        r12   k46 ; k46 = 102
.line	1124	loadk        r13   k47 ; k47 = 26
.line	1124	loadk        r14   k48 ; k48 = 85
.line	1124	loadk        r15   k21 ; k21 = 251
.line	1124	loadk        r16   k49 ; k49 = 201
.line	1124	loadk        r17   k16 ; k16 = 35
.line	1124	loadk        r18   k17 ; k17 = 175
.line	1124	loadk        r19   k50 ; k50 = 48
.line	1124	loadk        r20   k51 ; k51 = 164
.line	1124	loadk        r21   k52 ; k52 = 239
.line	1124	loadk        r22   k20 ; k20 = 176
.line	1124	loadk        r23   k53 ; k53 = 191
.line	1124	loadk        r24   k23 ; k23 = 223
.line	1124	loadk        r25   k54 ; k54 = 172
.line	1124	loadk        r26   k55 ; k55 = 91
.line	1124	loadk        r27   k56 ; k56 = 64
.line	1124	loadk        r28   k57 ; k57 = 45
.line	1124	loadk        r29   k58 ; k58 = 37
.line	1124	loadk        r30   k59 ; k59 = 165
.line	1124	loadk        r31   k60 ; k60 = 200
.line	1124	loadk        r32   k17 ; k17 = 175
.line	1124	loadk        r33   k18 ; k18 = 19
.line	1124	loadk        r34   k61 ; k61 = 237
.line	1124	loadk        r35   k62 ; k62 = 58
.line	1124	loadk        r36   k21 ; k21 = 251
.line	1124	loadk        r37   k63 ; k63 = 166
.line	1124	loadk        r38   k64 ; k64 = 160
.line	1124	loadk        r39   k65 ; k65 = 236
.line	1124	loadk        r40   k66 ; k66 = 211
.line	1124	loadk        r41   k67 ; k67 = 233
.line	1124	loadk        r42   k68 ; k68 = 104
.line	1124	loadk        r43   k25 ; k25 = 81
.line	1124	call          r9    35     0
.line	1124	setlist       r7     0     1
.line	1124	call          r6     2     2
.line	1124	gettabup      r7    u1   k69 ; k69 = "tostring"
.line	1124	move          r8    r1
.line	1124	call          r7     2     0
.line	1124	call          r5     0     2
.label	l105
.line	1124	call          r4     2     1
.line	1124	return        r0     1
.label	l107
.line	1124	gettable      r4    r3    k2 ; k2 = "Meta"
.line	1124	gettable      r5    r4   k70 ; k70 = "PrefabType"
.line	1124	gettabup      r6    u3    r5
.line	1124	test          r6     1
.line	1124	jmp            0  l220
.line	1124	gettabup      r7    u1    k3 ; k3 = "print"
.line	1124	gettabup      r8    u1    k4 ; k4 = "bWriteLog"
.line	1124	test          r8     0
.line	1124	jmp            0  l218
.line	1124	gettabup      r8    u1    k5 ; k5 = "string"
.line	1124	gettable      r8    r8    k6 ; k6 = "format"
.line	1124	gettabup      r9    u1    k7 ; k7 = "table"
.line	1124	gettable      r9    r9    k8 ; k8 = "concat"
.line	1124	newtable     r10     2     0
.line	1124	getupval     r11    u2
.line	1124	loadk        r12    k9 ; k9 = 177
.line	1124	loadk        r13   k10 ; k10 = 122
.line	1124	loadk        r14   k11 ; k11 = 126
.line	1124	loadk        r15   k12 ; k12 = 49
.line	1124	loadk        r16   k13 ; k13 = 120
.line	1124	loadk        r17   k14 ; k14 = 255
.line	1124	loadk        r18   k15 ; k15 = 205
.line	1124	loadk        r19   k16 ; k16 = 35
.line	1124	loadk        r20   k17 ; k17 = 175
.line	1124	loadk        r21   k18 ; k18 = 19
.line	1124	loadk        r22   k19 ; k19 = 235
.line	1124	loadk        r23   k20 ; k20 = 176
.line	1124	loadk        r24   k21 ; k21 = 251
.line	1124	loadk        r25   k22 ; k22 = 219
.line	1124	loadk        r26   k23 ; k23 = 223
.line	1124	loadk        r27   k14 ; k14 = 255
.line	1124	loadk        r28   k24 ; k24 = 115
.line	1124	loadk        r29   k25 ; k25 = 81
.line	1124	loadk        r30   k26 ; k26 = 10
.line	1124	loadk        r31   k12 ; k12 = 49
.line	1124	loadk        r32   k27 ; k27 = 142
.line	1124	loadk        r33   k19 ; k19 = 235
.line	1124	loadk        r34   k28 ; k28 = 174
.line	1124	loadk        r35   k29 ; k29 = 14
.line	1124	loadk        r36   k30 ; k30 = 247
.line	1124	loadk        r37   k31 ; k31 = 21
.line	1124	loadk        r38   k32 ; k32 = 240
.line	1124	loadk        r39   k33 ; k33 = 182
.line	1124	loadk        r40   k34 ; k34 = 193
.line	1124	loadk        r41   k35 ; k35 = 249
.line	1124	loadk        r42   k36 ; k36 = 207
.line	1124	loadk        r43   k35 ; k35 = 249
.line	1124	loadk        r44   k37 ; k37 = 114
.line	1124	loadk        r45   k38 ; k38 = 97
.line	1124	loadk        r46   k39 ; k39 = 38
.line	1124	loadk        r47   k40 ; k40 = 4
.line	1124	loadk        r48   k41 ; k41 = 157
.line	1124	loadk        r49   k42 ; k42 = 194
.line	1124	loadk        r50    k9 ; k9 = 177
.line	1124	loadk        r51   k43 ; k43 = 33
.line	1124	call         r11    41     2
.line	1124	getupval     r12    u2
.line	1124	loadk        r13   k44 ; k44 = 135
.line	1124	loadk        r14   k45 ; k45 = 101
.line	1124	loadk        r15   k46 ; k46 = 102
.line	1124	loadk        r16   k47 ; k47 = 26
.line	1124	loadk        r17   k48 ; k48 = 85
.line	1124	loadk        r18   k21 ; k21 = 251
.line	1124	loadk        r19   k49 ; k49 = 201
.line	1124	loadk        r20   k16 ; k16 = 35
.line	1124	loadk        r21   k17 ; k17 = 175
.line	1124	loadk        r22   k50 ; k50 = 48
.line	1124	loadk        r23   k51 ; k51 = 164
.line	1124	loadk        r24   k52 ; k52 = 239
.line	1124	loadk        r25   k20 ; k20 = 176
.line	1124	loadk        r26   k53 ; k53 = 191
.line	1124	loadk        r27   k23 ; k23 = 223
.line	1124	loadk        r28   k54 ; k54 = 172
.line	1124	loadk        r29   k71 ; k71 = 99
.line	1124	loadk        r30   k72 ; k72 = 75
.line	1124	loadk        r31   k73 ; k73 = 42
.line	1124	loadk        r32   k12 ; k12 = 49
.line	1124	loadk        r33   k74 ; k74 = 156
.line	1124	loadk        r34   k75 ; k75 = 214
.line	1124	loadk        r35   k63 ; k63 = 166
.line	1124	loadk        r36   k29 ; k29 = 14
.line	1124	loadk        r37   k76 ; k76 = 185
.line	1124	loadk        r38   k12 ; k12 = 49
.line	1124	loadk        r39   k32 ; k32 = 240
.line	1124	loadk        r40   k77 ; k77 = 242
.line	1124	loadk        r41   k78 ; k78 = 208
.line	1124	loadk        r42   k79 ; k79 = 248
.line	1124	loadk        r43   k80 ; k80 = 217
.line	1124	loadk        r44   k81 ; k81 = 250
.line	1124	loadk        r45   k82 ; k82 = 103
.line	1124	loadk        r46   k83 ; k83 = 87
.line	1124	loadk        r47   k84 ; k84 = 29
.line	1124	loadk        r48   k57 ; k57 = 45
.line	1124	loadk        r49   k85 ; k85 = 140
.line	1124	loadk        r50   k66 ; k66 = 211
.line	1124	loadk        r51   k86 ; k86 = 227
.line	1124	loadk        r52   k87 ; k87 = 76
.line	1124	call         r12    41     2
.line	1124	getupval     r13    u2
.line	1124	loadk        r14   k88 ; k88 = 195
.line	1124	loadk        r15   k46 ; k46 = 102
.line	1124	call         r13     3     0
.line	1124	setlist      r10     0     1
.line	1124	call          r9     2     2
.line	1124	gettabup     r10    u1   k69 ; k69 = "tostring"
.line	1124	move         r11    r1
.line	1124	call         r10     2     2
.line	1124	gettabup     r11    u1   k69 ; k69 = "tostring"
.line	1124	move         r12    r5
.line	1124	call         r11     2     0
.line	1124	call          r8     0     2
.label	l218
.line	1124	call          r7     2     1
.line	1124	return        r0     1
.label	l220
.line	1124	move          r7    r2
.line	1124	test          r7     0
.line	1124	jmp            0  l227
.line	1124	getupval      r8    u2
.line	1124	call          r8     1     2
.line	1124	eq             0    r7    r8
.line	1124	jmp            0  l231
.label	l227
.line	1124	self          r8    r0   k89 ; k89 = "GetFolderIDForAssetT" (truncated)
.line	1124	move         r10    r6
.line	1124	call          r8     3     2
.line	1124	move          r7    r8
.label	l231
.line	1124	self          r8    r0   k90 ; k90 = "IsAssetInPathMap"
.line	1124	move         r10    r1
.line	1124	move         r11    r6
.line	1124	call          r8     4     2
.line	1124	test          r8     0
.line	1124	jmp            0  l353
.line	1124	gettabup      r8    u1    k3 ; k3 = "print"
.line	1124	gettabup      r9    u1    k4 ; k4 = "bWriteLog"
.line	1124	test          r9     0
.line	1124	jmp            0  l343
.line	1124	gettabup      r9    u1    k5 ; k5 = "string"
.line	1124	gettable      r9    r9    k6 ; k6 = "format"
.line	1124	gettabup     r10    u1    k7 ; k7 = "table"
.line	1124	gettable     r10   r10    k8 ; k8 = "concat"
.line	1124	newtable     r11     2     0
.line	1124	getupval     r12    u2
.line	1124	loadk        r13    k9 ; k9 = 177
.line	1124	loadk        r14   k10 ; k10 = 122
.line	1124	loadk        r15   k11 ; k11 = 126
.line	1124	loadk        r16   k12 ; k12 = 49
.line	1124	loadk        r17   k13 ; k13 = 120
.line	1124	loadk        r18   k14 ; k14 = 255
.line	1124	loadk        r19   k15 ; k15 = 205
.line	1124	loadk        r20   k16 ; k16 = 35
.line	1124	loadk        r21   k17 ; k17 = 175
.line	1124	loadk        r22   k18 ; k18 = 19
.line	1124	loadk        r23   k19 ; k19 = 235
.line	1124	loadk        r24   k20 ; k20 = 176
.line	1124	loadk        r25   k21 ; k21 = 251
.line	1124	loadk        r26   k22 ; k22 = 219
.line	1124	loadk        r27   k23 ; k23 = 223
.line	1124	loadk        r28   k14 ; k14 = 255
.line	1124	loadk        r29   k24 ; k24 = 115
.line	1124	loadk        r30   k25 ; k25 = 81
.line	1124	loadk        r31   k26 ; k26 = 10
.line	1124	loadk        r32   k12 ; k12 = 49
.line	1124	loadk        r33   k27 ; k27 = 142
.line	1124	loadk        r34   k19 ; k19 = 235
.line	1124	loadk        r35   k28 ; k28 = 174
.line	1124	loadk        r36   k29 ; k29 = 14
.line	1124	loadk        r37   k30 ; k30 = 247
.line	1124	loadk        r38   k31 ; k31 = 21
.line	1124	loadk        r39   k32 ; k32 = 240
.line	1124	loadk        r40   k33 ; k33 = 182
.line	1124	loadk        r41   k34 ; k34 = 193
.line	1124	loadk        r42   k35 ; k35 = 249
.line	1124	loadk        r43   k36 ; k36 = 207
.line	1124	loadk        r44   k35 ; k35 = 249
.line	1124	loadk        r45   k37 ; k37 = 114
.line	1124	loadk        r46   k38 ; k38 = 97
.line	1124	loadk        r47   k39 ; k39 = 38
.line	1124	loadk        r48   k40 ; k40 = 4
.line	1124	loadk        r49   k41 ; k41 = 157
.line	1124	loadk        r50   k42 ; k42 = 194
.line	1124	loadk        r51    k9 ; k9 = 177
.line	1124	loadk        r52   k43 ; k43 = 33
.line	1124	call         r12    41     2
.line	1124	getupval     r13    u2
.line	1124	loadk        r14   k44 ; k44 = 135
.line	1124	loadk        r15   k45 ; k45 = 101
.line	1124	loadk        r16   k46 ; k46 = 102
.line	1124	loadk        r17   k47 ; k47 = 26
.line	1124	loadk        r18   k48 ; k48 = 85
.line	1124	loadk        r19   k21 ; k21 = 251
.line	1124	loadk        r20   k49 ; k49 = 201
.line	1124	loadk        r21   k16 ; k16 = 35
.line	1124	loadk        r22   k17 ; k17 = 175
.line	1124	loadk        r23   k50 ; k50 = 48
.line	1124	loadk        r24   k51 ; k51 = 164
.line	1124	loadk        r25   k52 ; k52 = 239
.line	1124	loadk        r26   k20 ; k20 = 176
.line	1124	loadk        r27   k53 ; k53 = 191
.line	1124	loadk        r28   k23 ; k23 = 223
.line	1124	loadk        r29   k54 ; k54 = 172
.line	1124	loadk        r30   k91 ; k91 = 119
.line	1124	loadk        r31   k92 ; k92 = 73
.line	1124	loadk        r32   k93 ; k93 = 43
.line	1124	loadk        r33   k43 ; k43 = 33
.line	1124	loadk        r34   k94 ; k94 = 141
.line	1124	loadk        r35   k42 ; k42 = 194
.line	1124	loadk        r36   k20 ; k20 = 176
.line	1124	loadk        r37   k95 ; k95 = 92
.line	1124	loadk        r38   k51 ; k51 = 164
.line	1124	loadk        r39   k62 ; k62 = 58
.line	1124	loadk        r40   k96 ; k96 = 180
.line	1124	loadk        r41   k97 ; k97 = 147
.line	1124	loadk        r42   k98 ; k98 = 243
.line	1124	loadk        r43   k35 ; k35 = 249
.line	1124	loadk        r44   k80 ; k80 = 217
.line	1124	loadk        r45   k99 ; k99 = 232
.line	1124	loadk        r46  k100 ; k100 = 86
.line	1124	loadk        r47  k101 ; k101 = 84
.line	1124	loadk        r48  k102 ; k102 = 61
.line	1124	loadk        r49  k103 ; k103 = 60
.line	1124	loadk        r50    k9 ; k9 = 177
.line	1124	loadk        r51  k104 ; k104 = 215
.line	1124	loadk        r52  k105 ; k105 = 169
.line	1124	loadk        r53   k56 ; k56 = 64
.line	1124	call         r13    41     2
.line	1124	getupval     r14    u2
.line	1124	loadk        r15  k106 ; k106 = 198
.line	1124	loadk        r16   k46 ; k46 = 102
.line	1124	loadk        r17  k107 ; k107 = 66
.line	1124	loadk        r18   k84 ; k84 = 29
.line	1124	loadk        r19  k108 ; k108 = 108
.line	1124	call         r14     6     0
.line	1124	setlist      r11     0     1
.line	1124	call         r10     2     2
.line	1124	gettabup     r11    u1   k69 ; k69 = "tostring"
.line	1124	move         r12    r1
.line	1124	call         r11     2     0
.line	1124	call          r9     0     2
.label	l343
.line	1124	call          r8     2     1
.line	1124	gettable      r8    r0  k109 ; k109 = "ImportingAssetMap"
.line	1124	test          r8     0
.line	1124	jmp            0  l352
.line	1124	gettable      r8    r0  k109 ; k109 = "ImportingAssetMap"
.line	1124	gettabup      r9    u1    k1 ; k1 = "tonumber"
.line	1124	move         r10    r1
.line	1124	call          r9     2     2
.line	1124	settable      r8    r9  k110 ; k110 = nil
.label	l352
.line	1124	return        r0     1
.label	l353
.line	1124	newtable      r8     0     6
.line	1124	gettabup      r9    u1   k69 ; k69 = "tostring"
.line	1124	move         r10    r1
.line	1124	call          r9     2     2
.line	1124	settable      r8  k111    r9 ; k111 = "AssetUID"
.line	1124	gettable      r9    r4  k113 ; k113 = "Name"
.line	1124	test          r9     1
.line	1124	jmp            0  l362
.line	1124	move          r9    r1
.label	l362
.line	1124	settable      r8  k112    r9 ; k112 = "AssetName"
.line	1124	settable      r8  k114    r6 ; k114 = "AssetType"
.line	1124	settable      r8  k115    r7 ; k115 = "FolderID"
.line	1124	gettable      r9    r4  k117 ; k117 = "Pic_Url"
.line	1124	test          r9     1
.line	1124	jmp            0  l370
.line	1124	getupval      r9    u2
.line	1124	call          r9     1     2
.label	l370
.line	1124	settable      r8  k116    r9 ; k116 = "Icon"
.line	1124	gettable      r9    r4  k118 ; k118 = "Desc"
.line	1124	test          r9     1
.line	1124	jmp            0  l376
.line	1124	getupval      r9    u2
.line	1124	call          r9     1     2
.label	l376
.line	1124	settable      r8  k118    r9 ; k118 = "Desc"
.line	1124	self          r9    r0  k119 ; k119 = "GetAssetRestrictions"
.line	1124	move         r11    r7
.line	1124	call          r9     3     2
.line	1124	self         r10    r0  k120 ; k120 = "ApplyAssetRestrictio" (truncated)
.line	1124	move         r12    r8
.line	1124	move         r13    r9
.line	1124	call         r10     4     1
.line	1124	gettabup     r10    u1    k7 ; k7 = "table"
.line	1124	gettable     r10   r10  k121 ; k121 = "insert"
.line	1124	gettable     r11    r0  k122 ; k122 = "AssetPathMap"
.line	1124	move         r12    r8
.line	1124	call         r10     3     1
.line	1124	gettable     r10    r0  k109 ; k109 = "ImportingAssetMap"
.line	1124	test         r10     0
.line	1124	jmp            0  l397
.line	1124	gettable     r10    r0  k109 ; k109 = "ImportingAssetMap"
.line	1124	gettabup     r11    u1    k1 ; k1 = "tonumber"
.line	1124	move         r12    r1
.line	1124	call         r11     2     2
.line	1124	settable     r10   r11  k110 ; k110 = nil
.label	l397
.line	1124	self         r10    r0  k123 ; k123 = "SaveAssetPathMap"
.line	1124	call         r10     2     1
.line	1124	gettabup     r10    u1    k3 ; k3 = "print"
.line	1124	gettabup     r11    u1    k4 ; k4 = "bWriteLog"
.line	1124	test         r11     0
.line	1124	jmp            0  l514
.line	1124	gettabup     r11    u1    k5 ; k5 = "string"
.line	1124	gettable     r11   r11    k6 ; k6 = "format"
.line	1124	gettabup     r12    u1    k7 ; k7 = "table"
.line	1124	gettable     r12   r12    k8 ; k8 = "concat"
.line	1124	newtable     r13     2     0
.line	1124	getupval     r14    u2
.line	1124	loadk        r15    k9 ; k9 = 177
.line	1124	loadk        r16   k10 ; k10 = 122
.line	1124	loadk        r17   k11 ; k11 = 126
.line	1124	loadk        r18   k12 ; k12 = 49
.line	1124	loadk        r19   k13 ; k13 = 120
.line	1124	loadk        r20   k14 ; k14 = 255
.line	1124	loadk        r21   k15 ; k15 = 205
.line	1124	loadk        r22   k16 ; k16 = 35
.line	1124	loadk        r23   k17 ; k17 = 175
.line	1124	loadk        r24   k18 ; k18 = 19
.line	1124	loadk        r25   k19 ; k19 = 235
.line	1124	loadk        r26   k20 ; k20 = 176
.line	1124	loadk        r27   k21 ; k21 = 251
.line	1124	loadk        r28   k22 ; k22 = 219
.line	1124	loadk        r29   k23 ; k23 = 223
.line	1124	loadk        r30   k14 ; k14 = 255
.line	1124	loadk        r31   k24 ; k24 = 115
.line	1124	loadk        r32   k25 ; k25 = 81
.line	1124	loadk        r33   k26 ; k26 = 10
.line	1124	loadk        r34   k12 ; k12 = 49
.line	1124	loadk        r35   k27 ; k27 = 142
.line	1124	loadk        r36   k19 ; k19 = 235
.line	1124	loadk        r37   k28 ; k28 = 174
.line	1124	loadk        r38   k29 ; k29 = 14
.line	1124	loadk        r39   k30 ; k30 = 247
.line	1124	loadk        r40   k31 ; k31 = 21
.line	1124	loadk        r41   k32 ; k32 = 240
.line	1124	loadk        r42   k33 ; k33 = 182
.line	1124	loadk        r43   k34 ; k34 = 193
.line	1124	loadk        r44   k35 ; k35 = 249
.line	1124	loadk        r45   k36 ; k36 = 207
.line	1124	loadk        r46   k35 ; k35 = 249
.line	1124	loadk        r47   k37 ; k37 = 114
.line	1124	loadk        r48   k38 ; k38 = 97
.line	1124	loadk        r49   k39 ; k39 = 38
.line	1124	loadk        r50   k40 ; k40 = 4
.line	1124	loadk        r51   k41 ; k41 = 157
.line	1124	loadk        r52   k42 ; k42 = 194
.line	1124	loadk        r53    k9 ; k9 = 177
.line	1124	loadk        r54   k43 ; k43 = 33
.line	1124	call         r14    41     2
.line	1124	getupval     r15    u2
.line	1124	loadk        r16   k44 ; k44 = 135
.line	1124	loadk        r17   k45 ; k45 = 101
.line	1124	loadk        r18   k46 ; k46 = 102
.line	1124	loadk        r19   k47 ; k47 = 26
.line	1124	loadk        r20   k48 ; k48 = 85
.line	1124	loadk        r21   k21 ; k21 = 251
.line	1124	loadk        r22   k49 ; k49 = 201
.line	1124	loadk        r23   k16 ; k16 = 35
.line	1124	loadk        r24   k17 ; k17 = 175
.line	1124	loadk        r25   k50 ; k50 = 48
.line	1124	loadk        r26   k51 ; k51 = 164
.line	1124	loadk        r27   k52 ; k52 = 239
.line	1124	loadk        r28   k20 ; k20 = 176
.line	1124	loadk        r29   k53 ; k53 = 191
.line	1124	loadk        r30   k23 ; k23 = 223
.line	1124	loadk        r31   k54 ; k54 = 172
.line	1124	loadk        r32   k91 ; k91 = 119
.line	1124	loadk        r33  k124 ; k124 = 65
.line	1124	loadk        r34  k102 ; k102 = 61
.line	1124	loadk        r35   k43 ; k43 = 33
.line	1124	loadk        r36  k125 ; k125 = 136
.line	1124	loadk        r37  k126 ; k126 = 134
.line	1124	loadk        r38  k127 ; k127 = 189
.line	1124	loadk        r39   k18 ; k18 = 19
.line	1124	loadk        r40   k61 ; k61 = 237
.line	1124	loadk        r41   k31 ; k31 = 21
.line	1124	loadk        r42  k128 ; k128 = 231
.line	1124	loadk        r43  k129 ; k129 = 161
.line	1124	loadk        r44  k130 ; k130 = 229
.line	1124	loadk        r45  k131 ; k131 = 254
.line	1124	loadk        r46   k65 ; k65 = 236
.line	1124	loadk        r47  k132 ; k132 = 253
.line	1124	loadk        r48   k37 ; k37 = 114
.line	1124	loadk        r49  k133 ; k133 = 93
.line	1124	loadk        r50   k40 ; k40 = 4
.line	1124	loadk        r51  k134 ; k134 = 53
.line	1124	loadk        r52   k85 ; k85 = 140
.line	1124	loadk        r53  k135 ; k135 = 154
.line	1124	loadk        r54   k35 ; k35 = 249
.line	1124	loadk        r55   k73 ; k73 = 42
.line	1124	call         r15    41     2
.line	1124	getupval     r16    u2
.line	1124	loadk        r17  k136 ; k136 = 137
.line	1124	loadk        r18  k137 ; k137 = 121
.line	1124	loadk        r19  k138 ; k138 = 77
.line	1124	loadk        r20  k139 ; k139 = 17
.line	1124	loadk        r21  k140 ; k140 = 110
.line	1124	loadk        r22   k23 ; k23 = 223
.line	1124	loadk        r23  k132 ; k132 = 253
.line	1124	loadk        r24  k141 ; k141 = 118
.line	1124	loadk        r25  k132 ; k132 = 253
.line	1124	loadk        r26   k38 ; k38 = 97
.line	1124	loadk        r27   k30 ; k30 = 247
.line	1124	call         r16    12     0
.line	1124	setlist      r13     0     1
.line	1124	call         r12     2     2
.line	1124	gettabup     r13    u1   k69 ; k69 = "tostring"
.line	1124	move         r14    r1
.line	1124	call         r13     2     2
.line	1124	gettabup     r14    u1   k69 ; k69 = "tostring"
.line	1124	move         r15    r7
.line	1124	call         r14     2     0
.line	1124	call         r11     0     2
.label	l514
.line	1124	call         r10     2     1
.line	1124	return        r0     1
.line	1124	move          r0    r0
.line	1124	move          r0    r0
.line	1124	return        r0     1

.function	main/f33

.source	null
.linedefined	1166
.lastlinedefined	1220
.numparams	2
.is_vararg	0
.maxstacksize	56

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	177
.constant	k5	122
.constant	k6	126
.constant	k7	49
.constant	k8	120
.constant	k9	255
.constant	k10	205
.constant	k11	35
.constant	k12	175
.constant	k13	19
.constant	k14	235
.constant	k15	176
.constant	k16	251
.constant	k17	219
.constant	k18	223
.constant	k19	115
.constant	k20	81
.constant	k21	10
.constant	k22	142
.constant	k23	174
.constant	k24	14
.constant	k25	247
.constant	k26	27
.constant	k27	250
.constant	k28	128
.constant	k29	229
.constant	k30	233
.constant	k31	242
.constant	k32	106
.constant	k33	90
.constant	k34	40
.constant	k35	48
.constant	k36	171
.constant	k37	217
.constant	k38	7
.constant	k39	167
.constant	k40	102
.constant	k41	17
.constant	k42	104
.constant	k43	"AssetIds"
.constant	k44	0
.constant	k45	182
.constant	k46	148
.constant	k47	108
.constant	k48	180
.constant	k49	42
.constant	k50	163
.constant	k51	252
.constant	k52	243
.constant	k53	200
.constant	k54	172
.constant	k55	87
.constant	k56	86
.constant	k57	33
.constant	k58	152
.constant	k59	239
.constant	k60	173
.constant	k61	15
.constant	k62	"string"
.constant	k63	"format"
.constant	k64	156
.constant	k65	55
.constant	k66	228
.constant	k67	211
.constant	k68	54
.constant	k69	70
.constant	k70	130
.constant	k71	210
.constant	k72	92
.constant	k73	232
.constant	k74	"bUnloading"
.constant	k75	true
.constant	k76	"UnloadingAssetIds"
.constant	k77	"ipairs"
.constant	k78	"tostring"
.constant	k79	"GetCreativeActorDataManager"
.constant	k80	"SubsystemMgr"
.constant	k81	"Get"
.constant	k82	165
.constant	k83	103
.constant	k84	76
.constant	k85	21
.constant	k86	207
.constant	k87	41
.constant	k88	39
.constant	k89	240
.constant	k90	226
.constant	k91	98
.constant	k92	74
.constant	k93	43
.constant	k94	23
.constant	k95	153
.constant	k96	196
.constant	k97	186
.constant	k98	5
.constant	k99	190
.constant	k100	32
.constant	k101	241
.constant	k102	191
.constant	k103	168
.constant	k104	254
.constant	k105	197
.constant	k106	113
.constant	k107	24
.constant	k108	159
.constant	k109	195
.constant	k110	189
.constant	k111	53
.constant	k112	169
.constant	k113	110
.constant	k114	"IsValidActorID"
.constant	k115	"tonumber"
.constant	k116	"Api_DeleteActorAsync"
.constant	k117	"IsEffectAsset"
.constant	k118	144
.constant	k119	224
.constant	k120	192
.constant	k121	222
.constant	k122	248
.constant	k123	127
.constant	k124	8
.constant	k125	57
.constant	k126	199
.constant	k127	114
.constant	k128	80
.constant	k129	36
.constant	k130	"DeleteCustomParticleConfig"
.constant	k131	"AssetPathMap"
.constant	k132	1
.constant	k133	-1
.constant	k134	"AssetUID"
.constant	k135	"remove"
.constant	k136	"_G"
.constant	k137	"EnableUMGInfoManager"
.constant	k138	"IsUMGCanvasAsset"
.constant	k139	"RequestRemoveUMGCanvas"
.constant	k140	"UnmountAsset"
.constant	k141	false
.constant	k142	"SaveAssetPathMap"
.constant	k143	"SyncWorkAssetDataToEditor"

.line	1166	gettabup      r2    u0    k0 ; k0 = "print"
.line	1166	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1166	test          r3     0
.line	1166	jmp            0   l59
.line	1166	gettabup      r3    u0    k2 ; k2 = "table"
.line	1166	gettable      r3    r3    k3 ; k3 = "concat"
.line	1166	newtable      r4     1     0
.line	1166	getupval      r5    u1
.line	1166	loadk         r6    k4 ; k4 = 177
.line	1166	loadk         r7    k5 ; k5 = 122
.line	1166	loadk         r8    k6 ; k6 = 126
.line	1166	loadk         r9    k7 ; k7 = 49
.line	1166	loadk        r10    k8 ; k8 = 120
.line	1166	loadk        r11    k9 ; k9 = 255
.line	1166	loadk        r12   k10 ; k10 = 205
.line	1166	loadk        r13   k11 ; k11 = 35
.line	1166	loadk        r14   k12 ; k12 = 175
.line	1166	loadk        r15   k13 ; k13 = 19
.line	1166	loadk        r16   k14 ; k14 = 235
.line	1166	loadk        r17   k15 ; k15 = 176
.line	1166	loadk        r18   k16 ; k16 = 251
.line	1166	loadk        r19   k17 ; k17 = 219
.line	1166	loadk        r20   k18 ; k18 = 223
.line	1166	loadk        r21    k9 ; k9 = 255
.line	1166	loadk        r22   k19 ; k19 = 115
.line	1166	loadk        r23   k20 ; k20 = 81
.line	1166	loadk        r24   k21 ; k21 = 10
.line	1166	loadk        r25    k7 ; k7 = 49
.line	1166	loadk        r26   k22 ; k22 = 142
.line	1166	loadk        r27   k14 ; k14 = 235
.line	1166	loadk        r28   k23 ; k23 = 174
.line	1166	loadk        r29   k24 ; k24 = 14
.line	1166	loadk        r30   k25 ; k25 = 247
.line	1166	loadk        r31   k26 ; k26 = 27
.line	1166	loadk        r32   k27 ; k27 = 250
.line	1166	loadk        r33   k28 ; k28 = 128
.line	1166	loadk        r34   k29 ; k29 = 229
.line	1166	loadk        r35   k16 ; k16 = 251
.line	1166	loadk        r36   k30 ; k30 = 233
.line	1166	loadk        r37   k31 ; k31 = 242
.line	1166	loadk        r38   k32 ; k32 = 106
.line	1166	loadk        r39   k33 ; k33 = 90
.line	1166	loadk        r40   k34 ; k34 = 40
.line	1166	loadk        r41   k35 ; k35 = 48
.line	1166	loadk        r42   k36 ; k36 = 171
.line	1166	loadk        r43   k37 ; k37 = 217
.line	1166	loadk        r44   k36 ; k36 = 171
.line	1166	loadk        r45   k38 ; k38 = 7
.line	1166	call          r5    41     2
.line	1166	getupval      r6    u1
.line	1166	loadk         r7   k39 ; k39 = 167
.line	1166	loadk         r8   k40 ; k40 = 102
.line	1166	loadk         r9   k33 ; k33 = 90
.line	1166	loadk        r10   k41 ; k41 = 17
.line	1166	loadk        r11   k42 ; k42 = 104
.line	1166	call          r6     6     0
.line	1166	setlist       r4     0     1
.line	1166	call          r3     2     2
.label	l59
.line	1166	call          r2     2     1
.line	1166	test          r1     0
.line	1166	jmp            0   l69
.line	1166	gettable      r2    r1   k43 ; k43 = "AssetIds"
.line	1166	test          r2     0
.line	1166	jmp            0   l69
.line	1166	gettable      r2    r1   k43 ; k43 = "AssetIds"
.line	1166	len           r2    r2
.line	1166	eq             0    r2   k44 ; k44 = 0
.line	1166	jmp            0  l148
.label	l69
.line	1166	gettabup      r2    u0    k0 ; k0 = "print"
.line	1166	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1166	test          r3     0
.line	1166	jmp            0  l146
.line	1166	gettabup      r3    u0    k2 ; k2 = "table"
.line	1166	gettable      r3    r3    k3 ; k3 = "concat"
.line	1166	newtable      r4     1     0
.line	1166	getupval      r5    u1
.line	1166	loadk         r6    k4 ; k4 = 177
.line	1166	loadk         r7    k5 ; k5 = 122
.line	1166	loadk         r8    k6 ; k6 = 126
.line	1166	loadk         r9    k7 ; k7 = 49
.line	1166	loadk        r10    k8 ; k8 = 120
.line	1166	loadk        r11    k9 ; k9 = 255
.line	1166	loadk        r12   k10 ; k10 = 205
.line	1166	loadk        r13   k11 ; k11 = 35
.line	1166	loadk        r14   k12 ; k12 = 175
.line	1166	loadk        r15   k13 ; k13 = 19
.line	1166	loadk        r16   k14 ; k14 = 235
.line	1166	loadk        r17   k15 ; k15 = 176
.line	1166	loadk        r18   k16 ; k16 = 251
.line	1166	loadk        r19   k17 ; k17 = 219
.line	1166	loadk        r20   k18 ; k18 = 223
.line	1166	loadk        r21    k9 ; k9 = 255
.line	1166	loadk        r22   k19 ; k19 = 115
.line	1166	loadk        r23   k20 ; k20 = 81
.line	1166	loadk        r24   k21 ; k21 = 10
.line	1166	loadk        r25    k7 ; k7 = 49
.line	1166	loadk        r26   k22 ; k22 = 142
.line	1166	loadk        r27   k14 ; k14 = 235
.line	1166	loadk        r28   k23 ; k23 = 174
.line	1166	loadk        r29   k24 ; k24 = 14
.line	1166	loadk        r30   k25 ; k25 = 247
.line	1166	loadk        r31   k26 ; k26 = 27
.line	1166	loadk        r32   k27 ; k27 = 250
.line	1166	loadk        r33   k28 ; k28 = 128
.line	1166	loadk        r34   k29 ; k29 = 229
.line	1166	loadk        r35   k16 ; k16 = 251
.line	1166	loadk        r36   k30 ; k30 = 233
.line	1166	loadk        r37   k31 ; k31 = 242
.line	1166	loadk        r38   k32 ; k32 = 106
.line	1166	loadk        r39   k33 ; k33 = 90
.line	1166	loadk        r40   k34 ; k34 = 40
.line	1166	loadk        r41   k35 ; k35 = 48
.line	1166	loadk        r42   k36 ; k36 = 171
.line	1166	loadk        r43   k37 ; k37 = 217
.line	1166	loadk        r44   k36 ; k36 = 171
.line	1166	loadk        r45   k38 ; k38 = 7
.line	1166	call          r5    41     2
.line	1166	getupval      r6    u1
.line	1166	loadk         r7   k39 ; k39 = 167
.line	1166	loadk         r8   k40 ; k40 = 102
.line	1166	loadk         r9   k33 ; k33 = 90
.line	1166	loadk        r10   k41 ; k41 = 17
.line	1166	loadk        r11   k42 ; k42 = 104
.line	1166	loadk        r12   k45 ; k45 = 182
.line	1166	loadk        r13   k46 ; k46 = 148
.line	1166	loadk        r14   k47 ; k47 = 108
.line	1166	loadk        r15   k48 ; k48 = 180
.line	1166	loadk        r16   k49 ; k49 = 42
.line	1166	loadk        r17   k31 ; k31 = 242
.line	1166	loadk        r18   k50 ; k50 = 163
.line	1166	loadk        r19   k51 ; k51 = 252
.line	1166	loadk        r20   k52 ; k52 = 243
.line	1166	loadk        r21   k53 ; k53 = 200
.line	1166	loadk        r22   k54 ; k54 = 172
.line	1166	loadk        r23   k55 ; k55 = 87
.line	1166	loadk        r24   k56 ; k56 = 86
.line	1166	loadk        r25   k49 ; k49 = 42
.line	1166	loadk        r26   k57 ; k57 = 33
.line	1166	loadk        r27   k58 ; k58 = 152
.line	1166	loadk        r28   k59 ; k59 = 239
.line	1166	loadk        r29   k60 ; k60 = 173
.line	1166	loadk        r30   k61 ; k61 = 15
.line	1166	call          r6    25     0
.line	1166	setlist       r4     0     1
.line	1166	call          r3     2     2
.label	l146
.line	1166	call          r2     2     1
.line	1166	return        r0     1
.label	l148
.line	1166	gettable      r2    r1   k43 ; k43 = "AssetIds"
.line	1166	gettabup      r3    u0    k0 ; k0 = "print"
.line	1166	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	1166	test          r4     0
.line	1166	jmp            0  l232
.line	1166	gettabup      r4    u0   k62 ; k62 = "string"
.line	1166	gettable      r4    r4   k63 ; k63 = "format"
.line	1166	gettabup      r5    u0    k2 ; k2 = "table"
.line	1166	gettable      r5    r5    k3 ; k3 = "concat"
.line	1166	newtable      r6     1     0
.line	1166	getupval      r7    u1
.line	1166	loadk         r8    k4 ; k4 = 177
.line	1166	loadk         r9    k5 ; k5 = 122
.line	1166	loadk        r10    k6 ; k6 = 126
.line	1166	loadk        r11    k7 ; k7 = 49
.line	1166	loadk        r12    k8 ; k8 = 120
.line	1166	loadk        r13    k9 ; k9 = 255
.line	1166	loadk        r14   k10 ; k10 = 205
.line	1166	loadk        r15   k11 ; k11 = 35
.line	1166	loadk        r16   k12 ; k12 = 175
.line	1166	loadk        r17   k13 ; k13 = 19
.line	1166	loadk        r18   k14 ; k14 = 235
.line	1166	loadk        r19   k15 ; k15 = 176
.line	1166	loadk        r20   k16 ; k16 = 251
.line	1166	loadk        r21   k17 ; k17 = 219
.line	1166	loadk        r22   k18 ; k18 = 223
.line	1166	loadk        r23    k9 ; k9 = 255
.line	1166	loadk        r24   k19 ; k19 = 115
.line	1166	loadk        r25   k20 ; k20 = 81
.line	1166	loadk        r26   k21 ; k21 = 10
.line	1166	loadk        r27    k7 ; k7 = 49
.line	1166	loadk        r28   k22 ; k22 = 142
.line	1166	loadk        r29   k14 ; k14 = 235
.line	1166	loadk        r30   k23 ; k23 = 174
.line	1166	loadk        r31   k24 ; k24 = 14
.line	1166	loadk        r32   k25 ; k25 = 247
.line	1166	loadk        r33   k26 ; k26 = 27
.line	1166	loadk        r34   k27 ; k27 = 250
.line	1166	loadk        r35   k28 ; k28 = 128
.line	1166	loadk        r36   k29 ; k29 = 229
.line	1166	loadk        r37   k16 ; k16 = 251
.line	1166	loadk        r38   k30 ; k30 = 233
.line	1166	loadk        r39   k31 ; k31 = 242
.line	1166	loadk        r40   k32 ; k32 = 106
.line	1166	loadk        r41   k33 ; k33 = 90
.line	1166	loadk        r42   k34 ; k34 = 40
.line	1166	loadk        r43   k35 ; k35 = 48
.line	1166	loadk        r44   k36 ; k36 = 171
.line	1166	loadk        r45   k37 ; k37 = 217
.line	1166	loadk        r46   k36 ; k36 = 171
.line	1166	loadk        r47   k38 ; k38 = 7
.line	1166	call          r7    41     2
.line	1166	getupval      r8    u1
.line	1166	loadk         r9   k39 ; k39 = 167
.line	1166	loadk        r10   k40 ; k40 = 102
.line	1166	loadk        r11   k33 ; k33 = 90
.line	1166	loadk        r12   k41 ; k41 = 17
.line	1166	loadk        r13   k42 ; k42 = 104
.line	1166	loadk        r14   k45 ; k45 = 182
.line	1166	loadk        r15   k46 ; k46 = 148
.line	1166	loadk        r16   k47 ; k47 = 108
.line	1166	loadk        r17   k64 ; k64 = 156
.line	1166	loadk        r18   k65 ; k65 = 55
.line	1166	loadk        r19   k25 ; k25 = 247
.line	1166	loadk        r20   k39 ; k39 = 167
.line	1166	loadk        r21   k66 ; k66 = 228
.line	1166	loadk        r22   k67 ; k67 = 211
.line	1166	loadk        r23   k53 ; k53 = 200
.line	1166	loadk        r24    k9 ; k9 = 255
.line	1166	loadk        r25   k68 ; k68 = 54
.line	1166	loadk        r26   k69 ; k69 = 70
.line	1166	loadk        r27   k68 ; k68 = 54
.line	1166	loadk        r28    k7 ; k7 = 49
.line	1166	loadk        r29   k70 ; k70 = 130
.line	1166	loadk        r30   k71 ; k71 = 210
.line	1166	loadk        r31   k52 ; k52 = 243
.line	1166	loadk        r32   k72 ; k72 = 92
.line	1166	loadk        r33   k73 ; k73 = 232
.line	1166	loadk        r34   k35 ; k35 = 48
.line	1166	call          r8    27     0
.line	1166	setlist       r6     0     1
.line	1166	call          r5     2     2
.line	1166	len           r6    r2
.line	1166	call          r4     3     2
.label	l232
.line	1166	call          r3     2     1
.line	1166	loadbool      r3     0     0
.line	1166	settable      r0   k74   k75 ; k75 = true
.line	1166	gettable      r4    r0   k76 ; k76 = "UnloadingAssetIds"
.line	1166	test          r4     1
.line	1166	jmp            0  l239
.line	1166	newtable      r4     0     0
.label	l239
.line	1166	settable      r0   k76    r4 ; k76 = "UnloadingAssetIds"
.line	1166	gettabup      r4    u0   k77 ; k77 = "ipairs"
.line	1166	move          r5    r2
.line	1166	call          r4     2     4
.line	1166	jmp            0  l255
.line	1166	test          r8     0
.line	1166	jmp            0  l255
.line	1166	getupval      r9    u1
.line	1166	call          r9     1     2
.line	1166	eq             1    r8    r9
.line	1166	jmp            0  l255
.line	1166	gettable      r9    r0   k76 ; k76 = "UnloadingAssetIds"
.line	1166	gettabup     r10    u0   k78 ; k78 = "tostring"
.line	1166	move         r11    r8
.line	1166	call         r10     2     2
.line	1166	settable      r9   r10   k75 ; k75 = true
.label	l255
.line	1166	move          r0    r0
.line	1166	move          r0    r0
.line	1166	gettabup      r4    u0   k79 ; k79 = "GetCreativeActorData" (truncated)
.line	1166	call          r4     1     2
.line	1166	gettabup      r5    u0   k80 ; k80 = "SubsystemMgr"
.line	1166	self          r5    r5   k81 ; k81 = "Get"
.line	1166	getupval      r7    u1
.line	1166	loadk         r8   k82 ; k82 = 165
.line	1166	loadk         r9   k83 ; k83 = 103
.line	1166	loadk        r10   k84 ; k84 = 76
.line	1166	loadk        r11   k85 ; k85 = 21
.line	1166	loadk        r12   k42 ; k42 = 104
.line	1166	loadk        r13    k9 ; k9 = 255
.line	1166	loadk        r14   k86 ; k86 = 207
.line	1166	loadk        r15   k87 ; k87 = 41
.line	1166	loadk        r16   k64 ; k64 = 156
.line	1166	loadk        r17   k88 ; k88 = 39
.line	1166	loadk        r18   k89 ; k89 = 240
.line	1166	loadk        r19   k60 ; k60 = 173
.line	1166	loadk        r20   k90 ; k90 = 226
.line	1166	loadk        r21   k18 ; k18 = 223
.line	1166	loadk        r22   k53 ; k53 = 200
.line	1166	loadk        r23   k29 ; k29 = 229
.line	1166	loadk        r24   k91 ; k91 = 98
.line	1166	loadk        r25   k92 ; k92 = 74
.line	1166	loadk        r26   k93 ; k93 = 43
.line	1166	loadk        r27   k94 ; k94 = 23
.line	1166	loadk        r28   k95 ; k95 = 153
.line	1166	loadk        r29   k96 ; k96 = 196
.line	1166	loadk        r30   k97 ; k97 = 186
.line	1166	loadk        r31   k98 ; k98 = 5
.line	1166	loadk        r32   k99 ; k99 = 190
.line	1166	loadk        r33  k100 ; k100 = 32
.line	1166	loadk        r34  k101 ; k101 = 241
.line	1166	loadk        r35  k102 ; k102 = 191
.line	1166	call          r7    29     2
.line	1166	call          r5     3     2
.line	1166	gettabup      r6    u0   k77 ; k77 = "ipairs"
.line	1166	move          r7    r2
.line	1166	call          r6     2     4
.line	1166	jmp            0  l513
.line	1166	test         r10     0
.line	1166	jmp            0  l513
.line	1166	getupval     r11    u1
.line	1166	call         r11     1     2
.line	1166	eq             1   r10   r11
.line	1166	jmp            0  l513
.line	1166	gettabup     r11    u0    k0 ; k0 = "print"
.line	1166	gettabup     r12    u0    k1 ; k1 = "bWriteLog"
.line	1166	test         r12     0
.line	1166	jmp            0  l390
.line	1166	gettabup     r12    u0   k62 ; k62 = "string"
.line	1166	gettable     r12   r12   k63 ; k63 = "format"
.line	1166	gettabup     r13    u0    k2 ; k2 = "table"
.line	1166	gettable     r13   r13    k3 ; k3 = "concat"
.line	1166	newtable     r14     1     0
.line	1166	getupval     r15    u1
.line	1166	loadk        r16    k4 ; k4 = 177
.line	1166	loadk        r17    k5 ; k5 = 122
.line	1166	loadk        r18    k6 ; k6 = 126
.line	1166	loadk        r19    k7 ; k7 = 49
.line	1166	loadk        r20    k8 ; k8 = 120
.line	1166	loadk        r21    k9 ; k9 = 255
.line	1166	loadk        r22   k10 ; k10 = 205
.line	1166	loadk        r23   k11 ; k11 = 35
.line	1166	loadk        r24   k12 ; k12 = 175
.line	1166	loadk        r25   k13 ; k13 = 19
.line	1166	loadk        r26   k14 ; k14 = 235
.line	1166	loadk        r27   k15 ; k15 = 176
.line	1166	loadk        r28   k16 ; k16 = 251
.line	1166	loadk        r29   k17 ; k17 = 219
.line	1166	loadk        r30   k18 ; k18 = 223
.line	1166	loadk        r31    k9 ; k9 = 255
.line	1166	loadk        r32   k19 ; k19 = 115
.line	1166	loadk        r33   k20 ; k20 = 81
.line	1166	loadk        r34   k21 ; k21 = 10
.line	1166	loadk        r35    k7 ; k7 = 49
.line	1166	loadk        r36   k22 ; k22 = 142
.line	1166	loadk        r37   k14 ; k14 = 235
.line	1166	loadk        r38   k23 ; k23 = 174
.line	1166	loadk        r39   k24 ; k24 = 14
.line	1166	loadk        r40   k25 ; k25 = 247
.line	1166	loadk        r41   k26 ; k26 = 27
.line	1166	loadk        r42   k27 ; k27 = 250
.line	1166	loadk        r43   k28 ; k28 = 128
.line	1166	loadk        r44   k29 ; k29 = 229
.line	1166	loadk        r45   k16 ; k16 = 251
.line	1166	loadk        r46   k30 ; k30 = 233
.line	1166	loadk        r47   k31 ; k31 = 242
.line	1166	loadk        r48   k32 ; k32 = 106
.line	1166	loadk        r49   k33 ; k33 = 90
.line	1166	loadk        r50   k34 ; k34 = 40
.line	1166	loadk        r51   k35 ; k35 = 48
.line	1166	loadk        r52   k36 ; k36 = 171
.line	1166	loadk        r53   k37 ; k37 = 217
.line	1166	loadk        r54   k36 ; k36 = 171
.line	1166	loadk        r55   k38 ; k38 = 7
.line	1166	call         r15    41     2
.line	1166	getupval     r16    u1
.line	1166	loadk        r17   k39 ; k39 = 167
.line	1166	loadk        r18   k40 ; k40 = 102
.line	1166	loadk        r19   k33 ; k33 = 90
.line	1166	loadk        r20   k41 ; k41 = 17
.line	1166	loadk        r21   k42 ; k42 = 104
.line	1166	loadk        r22   k45 ; k45 = 182
.line	1166	loadk        r23   k46 ; k46 = 148
.line	1166	loadk        r24   k47 ; k47 = 108
.line	1166	loadk        r25  k103 ; k103 = 168
.line	1166	loadk        r26   k49 ; k49 = 42
.line	1166	loadk        r27   k73 ; k73 = 232
.line	1166	loadk        r28   k60 ; k60 = 173
.line	1166	loadk        r29  k101 ; k101 = 241
.line	1166	loadk        r30  k104 ; k104 = 254
.line	1166	loadk        r31  k105 ; k105 = 197
.line	1166	loadk        r32   k90 ; k90 = 226
.line	1166	loadk        r33  k106 ; k106 = 113
.line	1166	loadk        r34   k98 ; k98 = 5
.line	1166	loadk        r35  k107 ; k107 = 24
.line	1166	loadk        r36   k65 ; k65 = 55
.line	1166	loadk        r37  k108 ; k108 = 159
.line	1166	loadk        r38  k109 ; k109 = 195
.line	1166	loadk        r39  k110 ; k110 = 189
.line	1166	loadk        r40  k111 ; k111 = 53
.line	1166	loadk        r41  k112 ; k112 = 169
.line	1166	loadk        r42  k113 ; k113 = 110
.line	1166	loadk        r43   k48 ; k48 = 180
.line	1166	loadk        r44   k25 ; k25 = 247
.line	1166	loadk        r45   k52 ; k52 = 243
.line	1166	call         r16    30     0
.line	1166	setlist      r14     0     1
.line	1166	call         r13     2     2
.line	1166	gettabup     r14    u0   k78 ; k78 = "tostring"
.line	1166	move         r15   r10
.line	1166	call         r14     2     0
.line	1166	call         r12     0     2
.label	l390
.line	1166	call         r11     2     1
.line	1166	self         r11    r4  k114 ; k114 = "IsValidActorID"
.line	1166	gettabup     r13    u0  k115 ; k115 = "tonumber"
.line	1166	move         r14   r10
.line	1166	call         r13     2     0
.line	1166	call         r11     0     2
.line	1166	test         r11     0
.line	1166	jmp            0  l404
.line	1166	test          r5     0
.line	1166	jmp            0  l404
.line	1166	self         r11    r5  k116 ; k116 = "Api_DeleteActorAsync"
.line	1166	move         r13   r10
.line	1166	call         r11     3     1
.line	1166	jmp            0  l513
.label	l404
.line	1166	self         r11    r0  k117 ; k117 = "IsEffectAsset"
.line	1166	move         r13   r10
.line	1166	call         r11     3     2
.line	1166	test         r11     0
.line	1166	jmp            0  l475
.line	1166	gettabup     r11    u0   k80 ; k80 = "SubsystemMgr"
.line	1166	self         r11   r11   k81 ; k81 = "Get"
.line	1166	getupval     r13    u1
.line	1166	loadk        r14   k82 ; k82 = 165
.line	1166	loadk        r15   k83 ; k83 = 103
.line	1166	loadk        r16   k84 ; k84 = 76
.line	1166	loadk        r17   k85 ; k85 = 21
.line	1166	loadk        r18   k42 ; k42 = 104
.line	1166	loadk        r19    k9 ; k9 = 255
.line	1166	loadk        r20   k86 ; k86 = 207
.line	1166	loadk        r21   k87 ; k87 = 41
.line	1166	loadk        r22  k118 ; k118 = 144
.line	1166	loadk        r23   k93 ; k93 = 43
.line	1166	loadk        r24  k119 ; k119 = 224
.line	1166	loadk        r25   k39 ; k39 = 167
.line	1166	loadk        r26  k120 ; k120 = 192
.line	1166	loadk        r27   k16 ; k16 = 251
.line	1166	loadk        r28  k121 ; k121 = 222
.line	1166	loadk        r29  k122 ; k122 = 248
.line	1166	loadk        r30  k123 ; k123 = 127
.line	1166	loadk        r31   k69 ; k69 = 70
.line	1166	loadk        r32  k111 ; k111 = 53
.line	1166	loadk        r33   k57 ; k57 = 33
.line	1166	loadk        r34  k102 ; k102 = 191
.line	1166	loadk        r35   k18 ; k18 = 223
.line	1166	loadk        r36   k97 ; k97 = 186
.line	1166	loadk        r37  k124 ; k124 = 8
.line	1166	loadk        r38  k103 ; k103 = 168
.line	1166	loadk        r39  k125 ; k125 = 57
.line	1166	loadk        r40  k126 ; k126 = 199
.line	1166	loadk        r41   k39 ; k39 = 167
.line	1166	loadk        r42   k90 ; k90 = 226
.line	1166	loadk        r43   k37 ; k37 = 217
.line	1166	loadk        r44  k105 ; k105 = 197
.line	1166	loadk        r45   k59 ; k59 = 239
.line	1166	loadk        r46  k127 ; k127 = 114
.line	1166	loadk        r47  k128 ; k128 = 80
.line	1166	loadk        r48  k129 ; k129 = 36
.line	1166	call         r13    36     2
.line	1166	call         r11     3     2
.line	1166	test         r11     0
.line	1166	jmp            0  l456
.line	1166	self         r12   r11  k130 ; k130 = "DeleteCustomParticle" (truncated)
.line	1166	gettabup     r14    u0  k115 ; k115 = "tonumber"
.line	1166	move         r15   r10
.line	1166	call         r14     2     0
.line	1166	call         r12     0     1
.label	l456
.line	1166	gettable     r12    r0  k131 ; k131 = "AssetPathMap"
.line	1166	len          r12   r12
.line	1166	loadk        r13  k132 ; k132 = 1
.line	1166	loadk        r14  k133 ; k133 = -1
.line	1166	move          r0    r0
.line	1166	gettable     r16    r0  k131 ; k131 = "AssetPathMap"
.line	1166	gettable     r16   r16   r15
.line	1166	gettable     r16   r16  k134 ; k134 = "AssetUID"
.line	1166	eq             0   r16   r10
.line	1166	jmp            0  l473
.line	1166	gettabup     r16    u0    k2 ; k2 = "table"
.line	1166	gettable     r16   r16  k135 ; k135 = "remove"
.line	1166	gettable     r17    r0  k131 ; k131 = "AssetPathMap"
.line	1166	move         r18   r15
.line	1166	call         r16     3     1
.line	1166	loadbool      r3     1     0
.line	1166	jmp            0  l513
.label	l473
.line	1166	move          r0    r0
.line	1166	jmp            0  l513
.label	l475
.line	1166	gettabup     r11    u0  k136 ; k136 = "_G"
.line	1166	gettable     r11   r11  k137 ; k137 = "EnableUMGInfoManager"
.line	1166	test         r11     0
.line	1166	jmp            0  l488
.line	1166	self         r11    r0  k138 ; k138 = "IsUMGCanvasAsset"
.line	1166	move         r13   r10
.line	1166	call         r11     3     2
.line	1166	test         r11     0
.line	1166	jmp            0  l488
.line	1166	self         r11    r0  k139 ; k139 = "RequestRemoveUMGCanv" (truncated)
.line	1166	move         r13   r10
.line	1166	call         r11     3     1
.line	1166	jmp            0  l513
.label	l488
.line	1166	getupval     r11    u2
.line	1166	self         r11   r11  k140 ; k140 = "UnmountAsset"
.line	1166	gettabup     r13    u0  k115 ; k115 = "tonumber"
.line	1166	move         r14   r10
.line	1166	call         r13     2     2
.line	1166	loadbool     r14     1     0
.line	1166	call         r11     4     1
.line	1166	gettable     r11    r0  k131 ; k131 = "AssetPathMap"
.line	1166	len          r11   r11
.line	1166	loadk        r12  k132 ; k132 = 1
.line	1166	loadk        r13  k133 ; k133 = -1
.line	1166	move          r0    r0
.line	1166	gettable     r15    r0  k131 ; k131 = "AssetPathMap"
.line	1166	gettable     r15   r15   r14
.line	1166	gettable     r15   r15  k134 ; k134 = "AssetUID"
.line	1166	eq             0   r15   r10
.line	1166	jmp            0  l512
.line	1166	gettabup     r15    u0    k2 ; k2 = "table"
.line	1166	gettable     r15   r15  k135 ; k135 = "remove"
.line	1166	gettable     r16    r0  k131 ; k131 = "AssetPathMap"
.line	1166	move         r17   r14
.line	1166	call         r15     3     1
.line	1166	loadbool      r3     1     0
.line	1166	jmp            0  l513
.label	l512
.line	1166	move          r0    r0
.label	l513
.line	1166	move          r0    r0
.line	1166	move          r0    r0
.line	1166	settable      r0   k74  k141 ; k141 = false
.line	1166	test          r3     0
.line	1166	jmp            0  l522
.line	1166	self          r6    r0  k142 ; k142 = "SaveAssetPathMap"
.line	1166	call          r6     2     1
.line	1166	self          r6    r0  k143 ; k143 = "SyncWorkAssetDataToE" (truncated)
.line	1166	call          r6     2     1
.label	l522
.line	1166	return        r0     1
.line	1166	gettabup      r1    u0  k125 ; k125 = 57
.line	1166	gettabup      r1    u1  k104 ; k104 = 254
.line	1166	return        r0     1

.function	main/f34

.source	null
.linedefined	1222
.lastlinedefined	1233
.numparams	2
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	0	false
.upvalue	"U1"	15	true

.constant	k0	"tonumber"
.constant	k1	"pairs"
.constant	k2	"AssetPathMap"
.constant	k3	"AssetUID"
.constant	k4	"AssetType"
.constant	k5	"UMG"

.line	1222	gettabup      r2    u0    k0 ; k0 = "tonumber"
.line	1222	move          r3    r1
.line	1222	call          r2     2     2
.line	1222	test          r2     1
.line	1222	jmp            0    l8
.line	1222	loadbool      r3     0     0
.line	1222	return        r3     2
.label	l8
.line	1222	gettabup      r3    u0    k1 ; k1 = "pairs"
.line	1222	gettable      r4    r0    k2 ; k2 = "AssetPathMap"
.line	1222	call          r3     2     4
.line	1222	jmp            0   l23
.line	1222	gettabup      r8    u0    k0 ; k0 = "tonumber"
.line	1222	gettable      r9    r7    k3 ; k3 = "AssetUID"
.line	1222	call          r8     2     2
.line	1222	eq             0    r8    r2
.line	1222	jmp            0   l23
.line	1222	gettable      r8    r7    k4 ; k4 = "AssetType"
.line	1222	gettabup      r9    u1    k5 ; k5 = "UMG"
.line	1222	eq             0    r8    r9
.line	1222	jmp            0   l23
.line	1222	loadbool      r8     1     0
.line	1222	return        r8     2
.label	l23
.line	1222	move          r0    r0
.line	1222	move          r0    r0
.line	1222	loadbool      r3     0     0
.line	1222	return        r3     2
.line	1222	return        r0     1
.line	1222	move          r0    r0
.line	1222	move          r0    r0
.line	1222	move          r0    r0
.line	1222	move          r0    r0
.line	1222	return        r0     1

.function	main/f35

.source	null
.linedefined	1235
.lastlinedefined	1250
.numparams	2
.is_vararg	0
.maxstacksize	11

.upvalue	"_ENV"	0	false
.upvalue	"U1"	15	true

.constant	k0	"tonumber"
.constant	k1	"AssetPathMap"
.constant	k2	"UMGCanvasSourceAssetMap"
.constant	k3	"ipairs"
.constant	k4	"AssetType"
.constant	k5	"UMG"
.constant	k6	"AssetUID"
.constant	k7	"SourceAssetId"

.line	1235	gettabup      r2    u0    k0 ; k0 = "tonumber"
.line	1235	move          r3    r1
.line	1235	call          r2     2     2
.line	1235	test          r2     0
.line	1235	jmp            0    l9
.line	1235	gettable      r3    r0    k1 ; k1 = "AssetPathMap"
.line	1235	test          r3     1
.line	1235	jmp            0   l11
.label	l9
.line	1235	loadbool      r3     0     0
.line	1235	return        r3     2
.label	l11
.line	1235	gettable      r3    r0    k2 ; k2 = "UMGCanvasSourceAsset" (truncated)
.line	1235	gettabup      r4    u0    k3 ; k3 = "ipairs"
.line	1235	gettable      r5    r0    k1 ; k1 = "AssetPathMap"
.line	1235	call          r4     2     4
.line	1235	jmp            0   l35
.line	1235	gettable      r9    r8    k4 ; k4 = "AssetType"
.line	1235	gettabup     r10    u1    k5 ; k5 = "UMG"
.line	1235	eq             0    r9   r10
.line	1235	jmp            0   l35
.line	1235	test          r3     0
.line	1235	jmp            0   l28
.line	1235	gettabup      r9    u0    k0 ; k0 = "tonumber"
.line	1235	gettable     r10    r8    k6 ; k6 = "AssetUID"
.line	1235	call          r9     2     2
.line	1235	gettable      r9    r3    r9
.line	1235	test          r9     1
.line	1235	jmp            0   l31
.label	l28
.line	1235	gettabup      r9    u0    k0 ; k0 = "tonumber"
.line	1235	gettable     r10    r8    k7 ; k7 = "SourceAssetId"
.line	1235	call          r9     2     2
.label	l31
.line	1235	eq             0    r9    r2
.line	1235	jmp            0   l35
.line	1235	loadbool     r10     1     0
.line	1235	return       r10     2
.label	l35
.line	1235	move          r0    r0
.line	1235	move          r0    r0
.line	1235	loadbool      r4     0     0
.line	1235	return        r4     2
.line	1235	return        r0     1
.line	1235	move          r0    r0
.line	1235	move          r0    r0
.line	1235	move          r0    r0
.line	1235	move          r0    r0
.line	1235	return        r0     1

.function	main/f36

.source	null
.linedefined	1252
.lastlinedefined	1259
.numparams	2
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	false

.constant	k0	"GetInstanceManager"
.constant	k1	"GetInstance"
.constant	k2	nil
.constant	k3	"UMGCanvasInfo"

.line	1252	gettabup      r2    u0    k0 ; k0 = "GetInstanceManager"
.line	1252	call          r2     1     2
.line	1252	test          r2     1
.line	1252	jmp            0    l7
.line	1252	loadbool      r3     0     0
.line	1252	return        r3     2
.label	l7
.line	1252	self          r3    r2    k1 ; k1 = "GetInstance"
.line	1252	move          r5    r1
.line	1252	call          r3     3     2
.line	1252	eq             1    r3    k2 ; k2 = nil
.line	1252	jmp            0   l15
.line	1252	gettable      r4    r3    k3 ; k3 = "UMGCanvasInfo"
.line	1252	eq             0    r4    k2 ; k2 = nil
.line	1252	jmp            0   l16
.label	l15
.line	1252	loadbool      r4     0     1
.label	l16
.line	1252	loadbool      r4     1     0
.line	1252	return        r4     2
.line	1252	return        r0     1
.line	1252	move          r0    r0
.line	1252	move          r0    r0
.line	1252	move          r0    r0
.line	1252	move          r0    r0
.line	1252	return        r0     1

.function	main/f37

.source	null
.linedefined	1261
.lastlinedefined	1276
.numparams	2
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"tonumber"
.constant	k1	"IsCanvasHeldByEditSession"
.constant	k2	"slua_GameFrontendHUD"
.constant	k3	"GetPlayerController"
.constant	k4	"slua"
.constant	k5	"isValid"
.constant	k6	"CreativeModeCustomUIFeature"
.constant	k7	"RequestRemoveUMGInfo"

.line	1261	gettabup      r2    u0    k0 ; k0 = "tonumber"
.line	1261	move          r3    r1
.line	1261	call          r2     2     2
.line	1261	test          r2     1
.line	1261	jmp            0    l7
.line	1261	return        r0     1
.label	l7
.line	1261	self          r3    r0    k1 ; k1 = "IsCanvasHeldByEditSe" (truncated)
.line	1261	move          r5    r2
.line	1261	call          r3     3     2
.line	1261	test          r3     0
.line	1261	jmp            0   l13
.line	1261	return        r0     1
.label	l13
.line	1261	gettabup      r3    u0    k2 ; k2 = "slua_GameFrontendHUD"
.line	1261	test          r3     0
.line	1261	jmp            0   l19
.line	1261	gettabup      r3    u0    k2 ; k2 = "slua_GameFrontendHUD"
.line	1261	self          r3    r3    k3 ; k3 = "GetPlayerController"
.line	1261	call          r3     2     2
.label	l19
.line	1261	gettabup      r4    u0    k4 ; k4 = "slua"
.line	1261	gettable      r4    r4    k5 ; k5 = "isValid"
.line	1261	move          r5    r3
.line	1261	call          r4     2     2
.line	1261	test          r4     0
.line	1261	jmp            0   l28
.line	1261	gettable      r4    r3    k6 ; k6 = "CreativeModeCustomUI" (truncated)
.line	1261	test          r4     1
.line	1261	jmp            0   l29
.label	l28
.line	1261	return        r0     1
.label	l29
.line	1261	gettable      r4    r3    k6 ; k6 = "CreativeModeCustomUI" (truncated)
.line	1261	self          r4    r4    k7 ; k7 = "RequestRemoveUMGInfo"
.line	1261	move          r6    r2
.line	1261	closure       r7    f0
.line	1261	call          r4     4     1
.line	1261	return        r0     1
.line	1261	move          r0    r0
.line	1261	move          r0    r0
.line	1261	move          r0    r0
.line	1261	return        r0     1

.function	main/f37/f0

.source	null
.linedefined	1273
.lastlinedefined	1275
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	2	true

.constant	k0	"log_format"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	177
.constant	k4	122
.constant	k5	126
.constant	k6	49
.constant	k7	120
.constant	k8	255
.constant	k9	205
.constant	k10	35
.constant	k11	175
.constant	k12	19
.constant	k13	235
.constant	k14	176
.constant	k15	251
.constant	k16	219
.constant	k17	223
.constant	k18	115
.constant	k19	81
.constant	k20	10
.constant	k21	142
.constant	k22	174
.constant	k23	14
.constant	k24	247
.constant	k25	6
.constant	k26	241
.constant	k27	163
.constant	k28	245
.constant	k29	239
.constant	k30	207
.constant	k31	232
.constant	k32	84
.constant	k33	80
.constant	k34	36
.constant	k35	59
.constant	k36	138
.constant	k37	211
.constant	k38	140
.constant	k39	33
.constant	k40	161
.constant	k41	86
.constant	k42	72
.constant	k43	26
.constant	k44	106
.constant	k45	202
.constant	k46	108
.constant	k47	240
.constant	k48	100
.constant	k49	224
.constant	k50	173
.constant	k51	254
.constant	k52	128
.constant	k53	172
.constant	k54	85
.constant	k55	68
.constant	k56	55
.constant	k57	50
.constant	k58	141
.constant	k59	213
.constant	k60	56
.constant	k61	116
.constant	k62	170
.constant	k63	249
.constant	k64	238
.constant	k65	90
.constant	k66	23
.constant	k67	147
.constant	k68	210
.constant	k69	188
.constant	k70	198
.constant	k71	48
.constant	k72	"tostring"

.line	1273	gettabup      r1    u0    k0 ; k0 = "log_format"
.line	1273	gettabup      r2    u0    k1 ; k1 = "table"
.line	1273	gettable      r2    r2    k2 ; k2 = "concat"
.line	1273	newtable      r3     2     0
.line	1273	getupval      r4    u1
.line	1273	loadk         r5    k3 ; k3 = 177
.line	1273	loadk         r6    k4 ; k4 = 122
.line	1273	loadk         r7    k5 ; k5 = 126
.line	1273	loadk         r8    k6 ; k6 = 49
.line	1273	loadk         r9    k7 ; k7 = 120
.line	1273	loadk        r10    k8 ; k8 = 255
.line	1273	loadk        r11    k9 ; k9 = 205
.line	1273	loadk        r12   k10 ; k10 = 35
.line	1273	loadk        r13   k11 ; k11 = 175
.line	1273	loadk        r14   k12 ; k12 = 19
.line	1273	loadk        r15   k13 ; k13 = 235
.line	1273	loadk        r16   k14 ; k14 = 176
.line	1273	loadk        r17   k15 ; k15 = 251
.line	1273	loadk        r18   k16 ; k16 = 219
.line	1273	loadk        r19   k17 ; k17 = 223
.line	1273	loadk        r20    k8 ; k8 = 255
.line	1273	loadk        r21   k18 ; k18 = 115
.line	1273	loadk        r22   k19 ; k19 = 81
.line	1273	loadk        r23   k20 ; k20 = 10
.line	1273	loadk        r24    k6 ; k6 = 49
.line	1273	loadk        r25   k21 ; k21 = 142
.line	1273	loadk        r26   k13 ; k13 = 235
.line	1273	loadk        r27   k22 ; k22 = 174
.line	1273	loadk        r28   k23 ; k23 = 14
.line	1273	loadk        r29   k24 ; k24 = 247
.line	1273	loadk        r30   k25 ; k25 = 6
.line	1273	loadk        r31   k26 ; k26 = 241
.line	1273	loadk        r32   k27 ; k27 = 163
.line	1273	loadk        r33   k28 ; k28 = 245
.line	1273	loadk        r34   k29 ; k29 = 239
.line	1273	loadk        r35   k30 ; k30 = 207
.line	1273	loadk        r36   k31 ; k31 = 232
.line	1273	loadk        r37   k32 ; k32 = 84
.line	1273	loadk        r38   k33 ; k33 = 80
.line	1273	loadk        r39   k34 ; k34 = 36
.line	1273	loadk        r40   k35 ; k35 = 59
.line	1273	loadk        r41   k36 ; k36 = 138
.line	1273	loadk        r42   k37 ; k37 = 211
.line	1273	loadk        r43   k38 ; k38 = 140
.line	1273	loadk        r44   k39 ; k39 = 33
.line	1273	call          r4    41     2
.line	1273	getupval      r5    u1
.line	1273	loadk         r6   k40 ; k40 = 161
.line	1273	loadk         r7   k41 ; k41 = 86
.line	1273	loadk         r8   k42 ; k42 = 72
.line	1273	loadk         r9   k43 ; k43 = 26
.line	1273	loadk        r10   k44 ; k44 = 106
.line	1273	loadk        r11   k24 ; k24 = 247
.line	1273	loadk        r12   k45 ; k45 = 202
.line	1273	loadk        r13   k46 ; k46 = 108
.line	1273	loadk        r14   k47 ; k47 = 240
.line	1273	loadk        r15   k48 ; k48 = 100
.line	1273	loadk        r16   k49 ; k49 = 224
.line	1273	loadk        r17   k50 ; k50 = 173
.line	1273	loadk        r18   k51 ; k51 = 254
.line	1273	loadk        r19    k8 ; k8 = 255
.line	1273	loadk        r20   k52 ; k52 = 128
.line	1273	loadk        r21   k53 ; k53 = 172
.line	1273	loadk        r22   k54 ; k54 = 85
.line	1273	loadk        r23   k55 ; k55 = 68
.line	1273	loadk        r24   k56 ; k56 = 55
.line	1273	loadk        r25   k57 ; k57 = 50
.line	1273	loadk        r26   k58 ; k58 = 141
.line	1273	loadk        r27   k59 ; k59 = 213
.line	1273	loadk        r28   k52 ; k52 = 128
.line	1273	loadk        r29   k60 ; k60 = 56
.line	1273	loadk        r30   k24 ; k24 = 247
.line	1273	loadk        r31   k61 ; k61 = 116
.line	1273	loadk        r32    k3 ; k3 = 177
.line	1273	loadk        r33   k40 ; k40 = 161
.line	1273	loadk        r34   k53 ; k53 = 172
.line	1273	loadk        r35   k62 ; k62 = 170
.line	1273	loadk        r36   k63 ; k63 = 249
.line	1273	loadk        r37   k64 ; k64 = 238
.line	1273	loadk        r38   k61 ; k61 = 116
.line	1273	loadk        r39   k65 ; k65 = 90
.line	1273	loadk        r40   k35 ; k35 = 59
.line	1273	loadk        r41   k66 ; k66 = 23
.line	1273	loadk        r42   k67 ; k67 = 147
.line	1273	loadk        r43   k68 ; k68 = 210
.line	1273	loadk        r44   k69 ; k69 = 188
.line	1273	loadk        r45   k41 ; k41 = 86
.line	1273	call          r5    41     2
.line	1273	getupval      r6    u1
.line	1273	loadk         r7   k70 ; k70 = 198
.line	1273	loadk         r8   k71 ; k71 = 48
.line	1273	loadk         r9   k65 ; k65 = 90
.line	1273	call          r6     4     0
.line	1273	setlist       r3     0     1
.line	1273	call          r2     2     2
.line	1273	gettabup      r3    u0   k72 ; k72 = "tostring"
.line	1273	getupval      r4    u2
.line	1273	call          r3     2     2
.line	1273	gettabup      r4    u0   k72 ; k72 = "tostring"
.line	1273	move          r5    r0
.line	1273	call          r4     2     0
.line	1273	call          r1     0     1
.line	1273	return        r0     1
.line	1273	move          r0    r0
.line	1273	move          r0    r0
.line	1273	gettabup      r0    u1   k36 ; k36 = 138
.line	1273	move          r0    r0
.line	1273	return        r0     1

.function	main/f38

.source	null
.linedefined	1278
.lastlinedefined	1300
.numparams	2
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true

.constant	k0	0
.constant	k1	"log_format"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	177
.constant	k5	122
.constant	k6	126
.constant	k7	49
.constant	k8	120
.constant	k9	255
.constant	k10	205
.constant	k11	35
.constant	k12	175
.constant	k13	19
.constant	k14	235
.constant	k15	176
.constant	k16	251
.constant	k17	219
.constant	k18	223
.constant	k19	115
.constant	k20	81
.constant	k21	10
.constant	k22	142
.constant	k23	174
.constant	k24	14
.constant	k25	247
.constant	k26	29
.constant	k27	249
.constant	k28	162
.constant	k29	239
.constant	k30	248
.constant	k31	200
.constant	k32	221
.constant	k33	101
.constant	k34	65
.constant	k35	38
.constant	k36	143
.constant	k37	240
.constant	k38	171
.constant	k39	3
.constant	k40	139
.constant	k41	69
.constant	k42	91
.constant	k43	17
.constant	k44	1
.constant	k45	188
.constant	k46	40
.constant	k47	232
.constant	k48	226
.constant	k49	189
.constant	k50	186
.constant	k51	227
.constant	k52	99
.constant	k53	75
.constant	k54	45
.constant	k55	204
.constant	k56	131
.constant	k57	173
.constant	k58	"ImportActorsFromPrefabMall"

.line	1278	test          r1     0
.line	1278	jmp            0    l6
.line	1278	len           r2    r1
.line	1278	eq             0    r2    k0 ; k0 = 0
.line	1278	jmp            0    l7
.label	l6
.line	1278	return        r0     1
.label	l7
.line	1278	gettabup      r2    u0    k1 ; k1 = "log_format"
.line	1278	gettabup      r3    u0    k2 ; k2 = "table"
.line	1278	gettable      r3    r3    k3 ; k3 = "concat"
.line	1278	newtable      r4     1     0
.line	1278	getupval      r5    u1
.line	1278	loadk         r6    k4 ; k4 = 177
.line	1278	loadk         r7    k5 ; k5 = 122
.line	1278	loadk         r8    k6 ; k6 = 126
.line	1278	loadk         r9    k7 ; k7 = 49
.line	1278	loadk        r10    k8 ; k8 = 120
.line	1278	loadk        r11    k9 ; k9 = 255
.line	1278	loadk        r12   k10 ; k10 = 205
.line	1278	loadk        r13   k11 ; k11 = 35
.line	1278	loadk        r14   k12 ; k12 = 175
.line	1278	loadk        r15   k13 ; k13 = 19
.line	1278	loadk        r16   k14 ; k14 = 235
.line	1278	loadk        r17   k15 ; k15 = 176
.line	1278	loadk        r18   k16 ; k16 = 251
.line	1278	loadk        r19   k17 ; k17 = 219
.line	1278	loadk        r20   k18 ; k18 = 223
.line	1278	loadk        r21    k9 ; k9 = 255
.line	1278	loadk        r22   k19 ; k19 = 115
.line	1278	loadk        r23   k20 ; k20 = 81
.line	1278	loadk        r24   k21 ; k21 = 10
.line	1278	loadk        r25    k7 ; k7 = 49
.line	1278	loadk        r26   k22 ; k22 = 142
.line	1278	loadk        r27   k14 ; k14 = 235
.line	1278	loadk        r28   k23 ; k23 = 174
.line	1278	loadk        r29   k24 ; k24 = 14
.line	1278	loadk        r30   k25 ; k25 = 247
.line	1278	loadk        r31   k26 ; k26 = 29
.line	1278	loadk        r32   k27 ; k27 = 249
.line	1278	loadk        r33   k28 ; k28 = 162
.line	1278	loadk        r34   k29 ; k29 = 239
.line	1278	loadk        r35   k30 ; k30 = 248
.line	1278	loadk        r36   k31 ; k31 = 200
.line	1278	loadk        r37   k32 ; k32 = 221
.line	1278	loadk        r38   k33 ; k33 = 101
.line	1278	loadk        r39   k34 ; k34 = 65
.line	1278	loadk        r40   k35 ; k35 = 38
.line	1278	loadk        r41   k35 ; k35 = 38
.line	1278	loadk        r42   k36 ; k36 = 143
.line	1278	loadk        r43   k37 ; k37 = 240
.line	1278	loadk        r44   k38 ; k38 = 171
.line	1278	loadk        r45   k39 ; k39 = 3
.line	1278	call          r5    41     2
.line	1278	getupval      r6    u1
.line	1278	loadk         r7   k40 ; k40 = 139
.line	1278	loadk         r8   k41 ; k41 = 69
.line	1278	loadk         r9   k42 ; k42 = 91
.line	1278	loadk        r10   k43 ; k43 = 17
.line	1278	loadk        r11    k5 ; k5 = 122
.line	1278	loadk        r12   k25 ; k25 = 247
.line	1278	loadk        r13   k17 ; k17 = 219
.line	1278	loadk        r14   k44 ; k44 = 1
.line	1278	loadk        r15   k45 ; k45 = 188
.line	1278	loadk        r16   k46 ; k46 = 40
.line	1278	loadk        r17   k47 ; k47 = 232
.line	1278	loadk        r18   k48 ; k48 = 226
.line	1278	loadk        r19   k49 ; k49 = 189
.line	1278	loadk        r20   k50 ; k50 = 186
.line	1278	loadk        r21   k29 ; k29 = 239
.line	1278	loadk        r22   k51 ; k51 = 227
.line	1278	loadk        r23   k52 ; k52 = 99
.line	1278	loadk        r24   k53 ; k53 = 75
.line	1278	loadk        r25   k54 ; k54 = 45
.line	1278	loadk        r26    k6 ; k6 = 126
.line	1278	loadk        r27   k55 ; k55 = 204
.line	1278	loadk        r28   k56 ; k56 = 131
.line	1278	loadk        r29   k57 ; k57 = 173
.line	1278	call          r6    24     0
.line	1278	setlist       r4     0     1
.line	1278	call          r3     2     2
.line	1278	len           r4    r1
.line	1278	call          r2     3     1
.line	1278	getupval      r2    u2
.line	1278	self          r2    r2   k58 ; k58 = "ImportActorsFromPref" (truncated)
.line	1278	move          r4    r1
.line	1278	closure       r5    f0
.line	1278	closure       r6    f1
.line	1278	call          r2     5     1
.line	1278	return        r0     1
.line	1278	move          r0    r0
.line	1278	move          r0    r0
.line	1278	move          r0    r0
.line	1278	return        r0     1

.function	main/f38/f0

.source	null
.linedefined	1283
.lastlinedefined	1289
.numparams	4
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	0	true

.constant	k0	"log_format"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	177
.constant	k4	122
.constant	k5	126
.constant	k6	49
.constant	k7	120
.constant	k8	255
.constant	k9	205
.constant	k10	35
.constant	k11	175
.constant	k12	19
.constant	k13	235
.constant	k14	176
.constant	k15	251
.constant	k16	219
.constant	k17	223
.constant	k18	115
.constant	k19	81
.constant	k20	10
.constant	k21	142
.constant	k22	174
.constant	k23	14
.constant	k24	247
.constant	k25	29
.constant	k26	249
.constant	k27	162
.constant	k28	239
.constant	k29	248
.constant	k30	200
.constant	k31	221
.constant	k32	101
.constant	k33	65
.constant	k34	38
.constant	k35	143
.constant	k36	240
.constant	k37	171
.constant	k38	3
.constant	k39	139
.constant	k40	69
.constant	k41	91
.constant	k42	17
.constant	k43	1
.constant	k44	188
.constant	k45	40
.constant	k46	232
.constant	k47	226
.constant	k48	189
.constant	k49	186
.constant	k50	207
.constant	k51	237
.constant	k52	73
.constant	k53	59
.constant	k54	37
.constant	k55	229
.constant	k56	92
.constant	k57	140
.constant	k58	39
.constant	k59	231
.constant	k60	183
.constant	k61	244
.constant	k62	195
.constant	k63	216
.constant	k64	166
.constant	k65	16
.constant	k66	58
.constant	k67	220
.constant	k68	182
.constant	k69	28
.constant	k70	167
.constant	k71	118
.constant	k72	93
.constant	k73	27
.constant	k74	110
.constant	k75	253
.constant	k76	97
.constant	k77	238
.constant	k78	211
.constant	k79	193
.constant	k80	252
.constant	k81	121
.constant	k82	87
.constant	k83	45
.constant	k84	158
.constant	k85	212
.constant	k86	170
.constant	k87	153
.constant	k88	"tostring"
.constant	k89	"log_tree"
.constant	k90	131
.constant	k91	227
.constant	k92	147
.constant	k93	254
.constant	k94	79
.constant	k95	"ImportingAssetMap"
.constant	k96	"tonumber"
.constant	k97	nil

.line	1283	gettabup      r4    u0    k0 ; k0 = "log_format"
.line	1283	gettabup      r5    u0    k1 ; k1 = "table"
.line	1283	gettable      r5    r5    k2 ; k2 = "concat"
.line	1283	newtable      r6     2     0
.line	1283	getupval      r7    u1
.line	1283	loadk         r8    k3 ; k3 = 177
.line	1283	loadk         r9    k4 ; k4 = 122
.line	1283	loadk        r10    k5 ; k5 = 126
.line	1283	loadk        r11    k6 ; k6 = 49
.line	1283	loadk        r12    k7 ; k7 = 120
.line	1283	loadk        r13    k8 ; k8 = 255
.line	1283	loadk        r14    k9 ; k9 = 205
.line	1283	loadk        r15   k10 ; k10 = 35
.line	1283	loadk        r16   k11 ; k11 = 175
.line	1283	loadk        r17   k12 ; k12 = 19
.line	1283	loadk        r18   k13 ; k13 = 235
.line	1283	loadk        r19   k14 ; k14 = 176
.line	1283	loadk        r20   k15 ; k15 = 251
.line	1283	loadk        r21   k16 ; k16 = 219
.line	1283	loadk        r22   k17 ; k17 = 223
.line	1283	loadk        r23    k8 ; k8 = 255
.line	1283	loadk        r24   k18 ; k18 = 115
.line	1283	loadk        r25   k19 ; k19 = 81
.line	1283	loadk        r26   k20 ; k20 = 10
.line	1283	loadk        r27    k6 ; k6 = 49
.line	1283	loadk        r28   k21 ; k21 = 142
.line	1283	loadk        r29   k13 ; k13 = 235
.line	1283	loadk        r30   k22 ; k22 = 174
.line	1283	loadk        r31   k23 ; k23 = 14
.line	1283	loadk        r32   k24 ; k24 = 247
.line	1283	loadk        r33   k25 ; k25 = 29
.line	1283	loadk        r34   k26 ; k26 = 249
.line	1283	loadk        r35   k27 ; k27 = 162
.line	1283	loadk        r36   k28 ; k28 = 239
.line	1283	loadk        r37   k29 ; k29 = 248
.line	1283	loadk        r38   k30 ; k30 = 200
.line	1283	loadk        r39   k31 ; k31 = 221
.line	1283	loadk        r40   k32 ; k32 = 101
.line	1283	loadk        r41   k33 ; k33 = 65
.line	1283	loadk        r42   k34 ; k34 = 38
.line	1283	loadk        r43   k34 ; k34 = 38
.line	1283	loadk        r44   k35 ; k35 = 143
.line	1283	loadk        r45   k36 ; k36 = 240
.line	1283	loadk        r46   k37 ; k37 = 171
.line	1283	loadk        r47   k38 ; k38 = 3
.line	1283	call          r7    41     2
.line	1283	getupval      r8    u1
.line	1283	loadk         r9   k39 ; k39 = 139
.line	1283	loadk        r10   k40 ; k40 = 69
.line	1283	loadk        r11   k41 ; k41 = 91
.line	1283	loadk        r12   k42 ; k42 = 17
.line	1283	loadk        r13    k4 ; k4 = 122
.line	1283	loadk        r14   k24 ; k24 = 247
.line	1283	loadk        r15   k16 ; k16 = 219
.line	1283	loadk        r16   k43 ; k43 = 1
.line	1283	loadk        r17   k44 ; k44 = 188
.line	1283	loadk        r18   k45 ; k45 = 40
.line	1283	loadk        r19   k46 ; k46 = 232
.line	1283	loadk        r20   k47 ; k47 = 226
.line	1283	loadk        r21   k48 ; k48 = 189
.line	1283	loadk        r22   k49 ; k49 = 186
.line	1283	loadk        r23   k50 ; k50 = 207
.line	1283	loadk        r24   k51 ; k51 = 237
.line	1283	loadk        r25    k4 ; k4 = 122
.line	1283	loadk        r26   k52 ; k52 = 73
.line	1283	loadk        r27   k53 ; k53 = 59
.line	1283	loadk        r28   k54 ; k54 = 37
.line	1283	loadk        r29   k35 ; k35 = 143
.line	1283	loadk        r30    k9 ; k9 = 205
.line	1283	loadk        r31   k55 ; k55 = 229
.line	1283	loadk        r32   k56 ; k56 = 92
.line	1283	loadk        r33   k57 ; k57 = 140
.line	1283	loadk        r34   k58 ; k58 = 39
.line	1283	loadk        r35   k59 ; k59 = 231
.line	1283	loadk        r36   k60 ; k60 = 183
.line	1283	loadk        r37   k61 ; k61 = 244
.line	1283	loadk        r38   k62 ; k62 = 195
.line	1283	loadk        r39   k63 ; k63 = 216
.line	1283	loadk        r40   k64 ; k64 = 166
.line	1283	loadk        r41   k34 ; k34 = 38
.line	1283	loadk        r42   k65 ; k65 = 16
.line	1283	loadk        r43   k66 ; k66 = 58
.line	1283	loadk        r44    k7 ; k7 = 120
.line	1283	loadk        r45   k67 ; k67 = 220
.line	1283	loadk        r46   k47 ; k47 = 226
.line	1283	loadk        r47   k68 ; k68 = 182
.line	1283	loadk        r48   k69 ; k69 = 28
.line	1283	call          r8    41     2
.line	1283	getupval      r9    u1
.line	1283	loadk        r10   k70 ; k70 = 167
.line	1283	loadk        r11   k71 ; k71 = 118
.line	1283	loadk        r12   k72 ; k72 = 93
.line	1283	loadk        r13   k73 ; k73 = 27
.line	1283	loadk        r14   k74 ; k74 = 110
.line	1283	loadk        r15   k17 ; k17 = 223
.line	1283	loadk        r16   k31 ; k31 = 221
.line	1283	loadk        r17   k71 ; k71 = 118
.line	1283	loadk        r18   k75 ; k75 = 253
.line	1283	loadk        r19   k76 ; k76 = 97
.line	1283	loadk        r20   k24 ; k24 = 247
.line	1283	loadk        r21   k77 ; k77 = 238
.line	1283	loadk        r22   k14 ; k14 = 176
.line	1283	loadk        r23   k78 ; k78 = 211
.line	1283	loadk        r24   k79 ; k79 = 193
.line	1283	loadk        r25   k80 ; k80 = 252
.line	1283	loadk        r26   k81 ; k81 = 121
.line	1283	loadk        r27   k82 ; k82 = 87
.line	1283	loadk        r28   k83 ; k83 = 45
.line	1283	loadk        r29   k43 ; k43 = 1
.line	1283	loadk        r30   k84 ; k84 = 158
.line	1283	loadk        r31   k85 ; k85 = 212
.line	1283	loadk        r32   k64 ; k64 = 166
.line	1283	loadk        r33   k23 ; k23 = 14
.line	1283	loadk        r34   k21 ; k21 = 142
.line	1283	loadk        r35   k53 ; k53 = 59
.line	1283	loadk        r36   k36 ; k36 = 240
.line	1283	loadk        r37   k60 ; k60 = 183
.line	1283	loadk        r38   k49 ; k49 = 186
.line	1283	loadk        r39   k86 ; k86 = 170
.line	1283	loadk        r40   k87 ; k87 = 153
.line	1283	loadk        r41   k28 ; k28 = 239
.line	1283	call          r9    33     0
.line	1283	setlist       r6     0     1
.line	1283	call          r5     2     2
.line	1283	gettabup      r6    u0   k88 ; k88 = "tostring"
.line	1283	move          r7    r0
.line	1283	call          r6     2     2
.line	1283	gettabup      r7    u0   k88 ; k88 = "tostring"
.line	1283	move          r8    r1
.line	1283	call          r7     2     2
.line	1283	gettabup      r8    u0   k88 ; k88 = "tostring"
.line	1283	move          r9    r2
.line	1283	call          r8     2     0
.line	1283	call          r4     0     1
.line	1283	gettabup      r4    u0   k89 ; k89 = "log_tree"
.line	1283	gettabup      r5    u0    k1 ; k1 = "table"
.line	1283	gettable      r5    r5    k2 ; k2 = "concat"
.line	1283	newtable      r6     1     0
.line	1283	getupval      r7    u1
.line	1283	loadk         r8    k3 ; k3 = 177
.line	1283	loadk         r9    k4 ; k4 = 122
.line	1283	loadk        r10    k5 ; k5 = 126
.line	1283	loadk        r11    k6 ; k6 = 49
.line	1283	loadk        r12    k7 ; k7 = 120
.line	1283	loadk        r13    k8 ; k8 = 255
.line	1283	loadk        r14    k9 ; k9 = 205
.line	1283	loadk        r15   k10 ; k10 = 35
.line	1283	loadk        r16   k11 ; k11 = 175
.line	1283	loadk        r17   k12 ; k12 = 19
.line	1283	loadk        r18   k13 ; k13 = 235
.line	1283	loadk        r19   k14 ; k14 = 176
.line	1283	loadk        r20   k15 ; k15 = 251
.line	1283	loadk        r21   k16 ; k16 = 219
.line	1283	loadk        r22   k17 ; k17 = 223
.line	1283	loadk        r23    k8 ; k8 = 255
.line	1283	loadk        r24   k18 ; k18 = 115
.line	1283	loadk        r25   k19 ; k19 = 81
.line	1283	loadk        r26   k20 ; k20 = 10
.line	1283	loadk        r27    k6 ; k6 = 49
.line	1283	loadk        r28   k21 ; k21 = 142
.line	1283	loadk        r29   k13 ; k13 = 235
.line	1283	loadk        r30   k22 ; k22 = 174
.line	1283	loadk        r31   k23 ; k23 = 14
.line	1283	loadk        r32   k24 ; k24 = 247
.line	1283	loadk        r33   k25 ; k25 = 29
.line	1283	loadk        r34   k26 ; k26 = 249
.line	1283	loadk        r35   k27 ; k27 = 162
.line	1283	loadk        r36   k28 ; k28 = 239
.line	1283	loadk        r37   k29 ; k29 = 248
.line	1283	loadk        r38   k30 ; k30 = 200
.line	1283	loadk        r39   k31 ; k31 = 221
.line	1283	loadk        r40   k32 ; k32 = 101
.line	1283	loadk        r41   k33 ; k33 = 65
.line	1283	loadk        r42   k34 ; k34 = 38
.line	1283	loadk        r43   k34 ; k34 = 38
.line	1283	loadk        r44   k35 ; k35 = 143
.line	1283	loadk        r45   k36 ; k36 = 240
.line	1283	loadk        r46   k37 ; k37 = 171
.line	1283	loadk        r47   k38 ; k38 = 3
.line	1283	call          r7    41     2
.line	1283	getupval      r8    u1
.line	1283	loadk         r9   k39 ; k39 = 139
.line	1283	loadk        r10   k40 ; k40 = 69
.line	1283	loadk        r11   k41 ; k41 = 91
.line	1283	loadk        r12   k42 ; k42 = 17
.line	1283	loadk        r13    k4 ; k4 = 122
.line	1283	loadk        r14   k24 ; k24 = 247
.line	1283	loadk        r15   k16 ; k16 = 219
.line	1283	loadk        r16   k43 ; k43 = 1
.line	1283	loadk        r17   k44 ; k44 = 188
.line	1283	loadk        r18   k45 ; k45 = 40
.line	1283	loadk        r19   k46 ; k46 = 232
.line	1283	loadk        r20   k47 ; k47 = 226
.line	1283	loadk        r21   k48 ; k48 = 189
.line	1283	loadk        r22   k49 ; k49 = 186
.line	1283	loadk        r23   k28 ; k28 = 239
.line	1283	loadk        r24   k51 ; k51 = 237
.line	1283	loadk        r25    k4 ; k4 = 122
.line	1283	loadk        r26   k52 ; k52 = 73
.line	1283	loadk        r27   k53 ; k53 = 59
.line	1283	loadk        r28   k54 ; k54 = 37
.line	1283	loadk        r29   k35 ; k35 = 143
.line	1283	loadk        r30    k9 ; k9 = 205
.line	1283	loadk        r31   k55 ; k55 = 229
.line	1283	loadk        r32   k56 ; k56 = 92
.line	1283	loadk        r33   k90 ; k90 = 131
.line	1283	loadk        r34    k6 ; k6 = 49
.line	1283	loadk        r35   k91 ; k91 = 227
.line	1283	loadk        r36   k92 ; k92 = 147
.line	1283	loadk        r37   k91 ; k91 = 227
.line	1283	loadk        r38   k93 ; k93 = 254
.line	1283	loadk        r39   k78 ; k78 = 211
.line	1283	loadk        r40   k77 ; k77 = 238
.line	1283	loadk        r41   k94 ; k94 = 79
.line	1283	loadk        r42   k19 ; k19 = 81
.line	1283	loadk        r43   k66 ; k66 = 58
.line	1283	loadk        r44   k74 ; k74 = 110
.line	1283	loadk        r45   k67 ; k67 = 220
.line	1283	call          r8    38     0
.line	1283	setlist       r6     0     1
.line	1283	call          r5     2     2
.line	1283	move          r6    r3
.line	1283	call          r4     3     1
.line	1283	gettabup      r4    u2   k95 ; k95 = "ImportingAssetMap"
.line	1283	test          r4     0
.line	1283	jmp            0  l232
.line	1283	gettabup      r4    u2   k95 ; k95 = "ImportingAssetMap"
.line	1283	gettabup      r5    u0   k96 ; k96 = "tonumber"
.line	1283	move          r6    r0
.line	1283	call          r5     2     2
.line	1283	settable      r4    r5   k97 ; k97 = nil
.label	l232
.line	1283	return        r0     1
.line	1283	move          r0    r0
.line	1283	move          r0    r0
.line	1283	return        r0     1

.function	main/f38/f1

.source	null
.linedefined	1289
.lastlinedefined	1299
.numparams	3
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	0	true

.constant	k0	"log_format"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	177
.constant	k4	122
.constant	k5	126
.constant	k6	49
.constant	k7	120
.constant	k8	255
.constant	k9	205
.constant	k10	35
.constant	k11	175
.constant	k12	19
.constant	k13	235
.constant	k14	176
.constant	k15	251
.constant	k16	219
.constant	k17	223
.constant	k18	115
.constant	k19	81
.constant	k20	10
.constant	k21	142
.constant	k22	174
.constant	k23	14
.constant	k24	247
.constant	k25	29
.constant	k26	249
.constant	k27	162
.constant	k28	239
.constant	k29	248
.constant	k30	200
.constant	k31	221
.constant	k32	101
.constant	k33	65
.constant	k34	38
.constant	k35	143
.constant	k36	240
.constant	k37	171
.constant	k38	3
.constant	k39	139
.constant	k40	69
.constant	k41	91
.constant	k42	17
.constant	k43	1
.constant	k44	188
.constant	k45	40
.constant	k46	232
.constant	k47	226
.constant	k48	189
.constant	k49	186
.constant	k50	227
.constant	k51	90
.constant	k52	74
.constant	k53	56
.constant	k54	32
.constant	k55	137
.constant	k56	194
.constant	k57	138
.constant	k58	161
.constant	k59	246
.constant	k60	179
.constant	k61	225
.constant	k62	144
.constant	k63	71
.constant	k64	70
.constant	k65	58
.constant	k66	136
.constant	k67	86
.constant	k68	198
.constant	k69	48
.constant	k70	"tostring"
.constant	k71	"log_tree"
.constant	k72	44
.constant	k73	23
.constant	k74	211
.constant	k75	184
.constant	k76	24
.constant	k77	131
.constant	k78	113
.constant	k79	104
.constant	k80	203
.constant	k81	5
.constant	k82	153
.constant	k83	55
.constant	k84	190
.constant	k85	"ImportingActorFolderMap"
.constant	k86	"ipairs"
.constant	k87	"tonumber"

.line	1289	test          r2     1
.line	1289	jmp            0    l4
.line	1289	return        r0     1
.label	l4
.line	1289	gettabup      r3    u0    k0 ; k0 = "log_format"
.line	1289	gettabup      r4    u0    k1 ; k1 = "table"
.line	1289	gettable      r4    r4    k2 ; k2 = "concat"
.line	1289	newtable      r5     2     0
.line	1289	getupval      r6    u1
.line	1289	loadk         r7    k3 ; k3 = 177
.line	1289	loadk         r8    k4 ; k4 = 122
.line	1289	loadk         r9    k5 ; k5 = 126
.line	1289	loadk        r10    k6 ; k6 = 49
.line	1289	loadk        r11    k7 ; k7 = 120
.line	1289	loadk        r12    k8 ; k8 = 255
.line	1289	loadk        r13    k9 ; k9 = 205
.line	1289	loadk        r14   k10 ; k10 = 35
.line	1289	loadk        r15   k11 ; k11 = 175
.line	1289	loadk        r16   k12 ; k12 = 19
.line	1289	loadk        r17   k13 ; k13 = 235
.line	1289	loadk        r18   k14 ; k14 = 176
.line	1289	loadk        r19   k15 ; k15 = 251
.line	1289	loadk        r20   k16 ; k16 = 219
.line	1289	loadk        r21   k17 ; k17 = 223
.line	1289	loadk        r22    k8 ; k8 = 255
.line	1289	loadk        r23   k18 ; k18 = 115
.line	1289	loadk        r24   k19 ; k19 = 81
.line	1289	loadk        r25   k20 ; k20 = 10
.line	1289	loadk        r26    k6 ; k6 = 49
.line	1289	loadk        r27   k21 ; k21 = 142
.line	1289	loadk        r28   k13 ; k13 = 235
.line	1289	loadk        r29   k22 ; k22 = 174
.line	1289	loadk        r30   k23 ; k23 = 14
.line	1289	loadk        r31   k24 ; k24 = 247
.line	1289	loadk        r32   k25 ; k25 = 29
.line	1289	loadk        r33   k26 ; k26 = 249
.line	1289	loadk        r34   k27 ; k27 = 162
.line	1289	loadk        r35   k28 ; k28 = 239
.line	1289	loadk        r36   k29 ; k29 = 248
.line	1289	loadk        r37   k30 ; k30 = 200
.line	1289	loadk        r38   k31 ; k31 = 221
.line	1289	loadk        r39   k32 ; k32 = 101
.line	1289	loadk        r40   k33 ; k33 = 65
.line	1289	loadk        r41   k34 ; k34 = 38
.line	1289	loadk        r42   k34 ; k34 = 38
.line	1289	loadk        r43   k35 ; k35 = 143
.line	1289	loadk        r44   k36 ; k36 = 240
.line	1289	loadk        r45   k37 ; k37 = 171
.line	1289	loadk        r46   k38 ; k38 = 3
.line	1289	call          r6    41     2
.line	1289	getupval      r7    u1
.line	1289	loadk         r8   k39 ; k39 = 139
.line	1289	loadk         r9   k40 ; k40 = 69
.line	1289	loadk        r10   k41 ; k41 = 91
.line	1289	loadk        r11   k42 ; k42 = 17
.line	1289	loadk        r12    k4 ; k4 = 122
.line	1289	loadk        r13   k24 ; k24 = 247
.line	1289	loadk        r14   k16 ; k16 = 219
.line	1289	loadk        r15   k43 ; k43 = 1
.line	1289	loadk        r16   k44 ; k44 = 188
.line	1289	loadk        r17   k45 ; k45 = 40
.line	1289	loadk        r18   k46 ; k46 = 232
.line	1289	loadk        r19   k47 ; k47 = 226
.line	1289	loadk        r20   k48 ; k48 = 189
.line	1289	loadk        r21   k49 ; k49 = 186
.line	1289	loadk        r22   k50 ; k50 = 227
.line	1289	loadk        r23   k47 ; k47 = 226
.line	1289	loadk        r24   k51 ; k51 = 90
.line	1289	loadk        r25   k52 ; k52 = 74
.line	1289	loadk        r26   k53 ; k53 = 56
.line	1289	loadk        r27   k54 ; k54 = 32
.line	1289	loadk        r28   k55 ; k55 = 137
.line	1289	loadk        r29   k56 ; k56 = 194
.line	1289	loadk        r30   k57 ; k57 = 138
.line	1289	loadk        r31   k25 ; k25 = 29
.line	1289	loadk        r32   k58 ; k58 = 161
.line	1289	loadk        r33   k53 ; k53 = 56
.line	1289	loadk        r34   k59 ; k59 = 246
.line	1289	loadk        r35   k60 ; k60 = 179
.line	1289	loadk        r36   k50 ; k50 = 227
.line	1289	loadk        r37   k61 ; k61 = 225
.line	1289	loadk        r38   k62 ; k62 = 144
.line	1289	loadk        r39   k44 ; k44 = 188
.line	1289	loadk        r40   k63 ; k63 = 71
.line	1289	loadk        r41   k64 ; k64 = 70
.line	1289	loadk        r42   k65 ; k65 = 58
.line	1289	loadk        r43    k6 ; k6 = 49
.line	1289	loadk        r44   k66 ; k66 = 136
.line	1289	loadk        r45    k8 ; k8 = 255
.line	1289	loadk        r46   k48 ; k48 = 189
.line	1289	loadk        r47   k67 ; k67 = 86
.line	1289	call          r7    41     2
.line	1289	getupval      r8    u1
.line	1289	loadk         r9   k68 ; k68 = 198
.line	1289	loadk        r10   k69 ; k69 = 48
.line	1289	loadk        r11   k51 ; k51 = 90
.line	1289	call          r8     4     0
.line	1289	setlist       r5     0     1
.line	1289	call          r4     2     2
.line	1289	gettabup      r5    u0   k70 ; k70 = "tostring"
.line	1289	move          r6    r0
.line	1289	call          r5     2     0
.line	1289	call          r3     0     1
.line	1289	gettabup      r3    u0   k71 ; k71 = "log_tree"
.line	1289	gettabup      r4    u0    k1 ; k1 = "table"
.line	1289	gettable      r4    r4    k2 ; k2 = "concat"
.line	1289	newtable      r5     2     0
.line	1289	getupval      r6    u1
.line	1289	loadk         r7    k3 ; k3 = 177
.line	1289	loadk         r8    k4 ; k4 = 122
.line	1289	loadk         r9    k5 ; k5 = 126
.line	1289	loadk        r10    k6 ; k6 = 49
.line	1289	loadk        r11    k7 ; k7 = 120
.line	1289	loadk        r12    k8 ; k8 = 255
.line	1289	loadk        r13    k9 ; k9 = 205
.line	1289	loadk        r14   k10 ; k10 = 35
.line	1289	loadk        r15   k11 ; k11 = 175
.line	1289	loadk        r16   k12 ; k12 = 19
.line	1289	loadk        r17   k13 ; k13 = 235
.line	1289	loadk        r18   k14 ; k14 = 176
.line	1289	loadk        r19   k15 ; k15 = 251
.line	1289	loadk        r20   k16 ; k16 = 219
.line	1289	loadk        r21   k17 ; k17 = 223
.line	1289	loadk        r22    k8 ; k8 = 255
.line	1289	loadk        r23   k18 ; k18 = 115
.line	1289	loadk        r24   k19 ; k19 = 81
.line	1289	loadk        r25   k20 ; k20 = 10
.line	1289	loadk        r26    k6 ; k6 = 49
.line	1289	loadk        r27   k21 ; k21 = 142
.line	1289	loadk        r28   k13 ; k13 = 235
.line	1289	loadk        r29   k22 ; k22 = 174
.line	1289	loadk        r30   k23 ; k23 = 14
.line	1289	loadk        r31   k24 ; k24 = 247
.line	1289	loadk        r32   k25 ; k25 = 29
.line	1289	loadk        r33   k26 ; k26 = 249
.line	1289	loadk        r34   k27 ; k27 = 162
.line	1289	loadk        r35   k28 ; k28 = 239
.line	1289	loadk        r36   k29 ; k29 = 248
.line	1289	loadk        r37   k30 ; k30 = 200
.line	1289	loadk        r38   k31 ; k31 = 221
.line	1289	loadk        r39   k32 ; k32 = 101
.line	1289	loadk        r40   k33 ; k33 = 65
.line	1289	loadk        r41   k34 ; k34 = 38
.line	1289	loadk        r42   k34 ; k34 = 38
.line	1289	loadk        r43   k35 ; k35 = 143
.line	1289	loadk        r44   k36 ; k36 = 240
.line	1289	loadk        r45   k37 ; k37 = 171
.line	1289	loadk        r46   k38 ; k38 = 3
.line	1289	call          r6    41     2
.line	1289	getupval      r7    u1
.line	1289	loadk         r8   k39 ; k39 = 139
.line	1289	loadk         r9   k40 ; k40 = 69
.line	1289	loadk        r10   k41 ; k41 = 91
.line	1289	loadk        r11   k42 ; k42 = 17
.line	1289	loadk        r12    k4 ; k4 = 122
.line	1289	loadk        r13   k24 ; k24 = 247
.line	1289	loadk        r14   k16 ; k16 = 219
.line	1289	loadk        r15   k43 ; k43 = 1
.line	1289	loadk        r16   k44 ; k44 = 188
.line	1289	loadk        r17   k45 ; k45 = 40
.line	1289	loadk        r18   k46 ; k46 = 232
.line	1289	loadk        r19   k47 ; k47 = 226
.line	1289	loadk        r20   k48 ; k48 = 189
.line	1289	loadk        r21   k49 ; k49 = 186
.line	1289	loadk        r22   k50 ; k50 = 227
.line	1289	loadk        r23   k47 ; k47 = 226
.line	1289	loadk        r24   k51 ; k51 = 90
.line	1289	loadk        r25   k52 ; k52 = 74
.line	1289	loadk        r26   k53 ; k53 = 56
.line	1289	loadk        r27   k54 ; k54 = 32
.line	1289	loadk        r28   k55 ; k55 = 137
.line	1289	loadk        r29   k56 ; k56 = 194
.line	1289	loadk        r30   k57 ; k57 = 138
.line	1289	loadk        r31   k25 ; k25 = 29
.line	1289	loadk        r32   k58 ; k58 = 161
.line	1289	loadk        r33   k53 ; k53 = 56
.line	1289	loadk        r34   k59 ; k59 = 246
.line	1289	loadk        r35   k60 ; k60 = 179
.line	1289	loadk        r36   k50 ; k50 = 227
.line	1289	loadk        r37   k61 ; k61 = 225
.line	1289	loadk        r38   k62 ; k62 = 144
.line	1289	loadk        r39   k44 ; k44 = 188
.line	1289	loadk        r40   k67 ; k67 = 86
.line	1289	loadk        r41   k63 ; k63 = 71
.line	1289	loadk        r42   k72 ; k72 = 44
.line	1289	loadk        r43   k73 ; k73 = 23
.line	1289	loadk        r44   k21 ; k21 = 142
.line	1289	loadk        r45   k74 ; k74 = 211
.line	1289	loadk        r46   k75 ; k75 = 184
.line	1289	loadk        r47   k76 ; k76 = 24
.line	1289	call          r7    41     2
.line	1289	getupval      r8    u1
.line	1289	loadk         r9   k77 ; k77 = 131
.line	1289	loadk        r10   k78 ; k78 = 113
.line	1289	loadk        r11   k79 ; k79 = 104
.line	1289	loadk        r12   k73 ; k73 = 23
.line	1289	loadk        r13   k79 ; k79 = 104
.line	1289	loadk        r14   k26 ; k26 = 249
.line	1289	loadk        r15   k80 ; k80 = 203
.line	1289	loadk        r16   k81 ; k81 = 5
.line	1289	loadk        r17   k82 ; k82 = 153
.line	1289	loadk        r18   k83 ; k83 = 55
.line	1289	loadk        r19   k84 ; k84 = 190
.line	1289	loadk        r20   k47 ; k47 = 226
.line	1289	call          r8    13     0
.line	1289	setlist       r5     0     1
.line	1289	call          r4     2     2
.line	1289	move          r5    r2
.line	1289	call          r3     3     1
.line	1289	gettabup      r3    u2   k85 ; k85 = "ImportingActorFolder" (truncated)
.line	1289	test          r3     1
.line	1289	jmp            0  l213
.line	1289	newtable      r3     0     0
.label	l213
.line	1289	settabup      u2   k85    r3 ; k85 = "ImportingActorFolder" (truncated)
.line	1289	gettabup      r3    u0   k86 ; k86 = "ipairs"
.line	1289	move          r4    r2
.line	1289	call          r3     2     4
.line	1289	jmp            0  l223
.line	1289	gettabup      r8    u2   k85 ; k85 = "ImportingActorFolder" (truncated)
.line	1289	gettabup      r9    u0   k87 ; k87 = "tonumber"
.line	1289	move         r10    r7
.line	1289	call          r9     2     2
.line	1289	settable      r8    r9    r1
.label	l223
.line	1289	move          r0    r0
.line	1289	move          r0    r0
.line	1289	return        r0     1
.line	1289	move          r0    r0
.line	1289	move          r0    r0
.line	1289	move          r0    r0
.line	1289	return        r0     1

.function	main/f39

.source	null
.linedefined	1302
.lastlinedefined	1349
.numparams	2
.is_vararg	0
.maxstacksize	53

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true

.constant	k0	0
.constant	k1	"log_format"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	177
.constant	k5	122
.constant	k6	126
.constant	k7	49
.constant	k8	120
.constant	k9	255
.constant	k10	205
.constant	k11	35
.constant	k12	175
.constant	k13	19
.constant	k14	235
.constant	k15	176
.constant	k16	251
.constant	k17	219
.constant	k18	223
.constant	k19	115
.constant	k20	81
.constant	k21	10
.constant	k22	142
.constant	k23	174
.constant	k24	14
.constant	k25	247
.constant	k26	29
.constant	k27	249
.constant	k28	162
.constant	k29	239
.constant	k30	248
.constant	k31	200
.constant	k32	201
.constant	k33	75
.constant	k34	114
.constant	k35	58
.constant	k36	18
.constant	k37	217
.constant	k38	180
.constant	k39	60
.constant	k40	148
.constant	k41	112
.constant	k42	79
.constant	k43	21
.constant	k44	216
.constant	k45	32
.constant	k46	100
.constant	k47	169
.constant	k48	226
.constant	k49	211
.constant	k50	245
.constant	k51	98
.constant	k52	31
.constant	k53	121
.constant	k54	97
.constant	k55	136
.constant	k56	"ipairs"
.constant	k57	"tonumber"
.constant	k58	"AssetId"
.constant	k59	"IsUMGSourceImported"
.constant	k60	"ImportingUIAssetMap"
.constant	k61	227
.constant	k62	241
.constant	k63	197
.constant	k64	252
.constant	k65	54
.constant	k66	65
.constant	k67	44
.constant	k68	52
.constant	k69	128
.constant	k70	207
.constant	k71	170
.constant	k72	185
.constant	k73	240
.constant	k74	242
.constant	k75	233
.constant	k76	231
.constant	k77	204
.constant	k78	243
.constant	k79	116
.constant	k80	101
.constant	k81	189
.constant	k82	9
.constant	k83	146
.constant	k84	92
.constant	k85	77
.constant	k86	78
.constant	k87	179
.constant	k88	202
.constant	k89	"tostring"
.constant	k90	"ImportingAssetMap"
.constant	k91	nil
.constant	k92	true
.constant	k93	"GetMetaInfoByAssetId"
.constant	k94	"Meta"
.constant	k95	"Pic_Url"
.constant	k96	"Desc"
.constant	k97	"ImportUMGFromPrefabMall"

.line	1302	test          r1     0
.line	1302	jmp            0    l6
.line	1302	len           r2    r1
.line	1302	eq             0    r2    k0 ; k0 = 0
.line	1302	jmp            0    l7
.label	l6
.line	1302	return        r0     1
.label	l7
.line	1302	gettabup      r2    u0    k1 ; k1 = "log_format"
.line	1302	gettabup      r3    u0    k2 ; k2 = "table"
.line	1302	gettable      r3    r3    k3 ; k3 = "concat"
.line	1302	newtable      r4     1     0
.line	1302	getupval      r5    u1
.line	1302	loadk         r6    k4 ; k4 = 177
.line	1302	loadk         r7    k5 ; k5 = 122
.line	1302	loadk         r8    k6 ; k6 = 126
.line	1302	loadk         r9    k7 ; k7 = 49
.line	1302	loadk        r10    k8 ; k8 = 120
.line	1302	loadk        r11    k9 ; k9 = 255
.line	1302	loadk        r12   k10 ; k10 = 205
.line	1302	loadk        r13   k11 ; k11 = 35
.line	1302	loadk        r14   k12 ; k12 = 175
.line	1302	loadk        r15   k13 ; k13 = 19
.line	1302	loadk        r16   k14 ; k14 = 235
.line	1302	loadk        r17   k15 ; k15 = 176
.line	1302	loadk        r18   k16 ; k16 = 251
.line	1302	loadk        r19   k17 ; k17 = 219
.line	1302	loadk        r20   k18 ; k18 = 223
.line	1302	loadk        r21    k9 ; k9 = 255
.line	1302	loadk        r22   k19 ; k19 = 115
.line	1302	loadk        r23   k20 ; k20 = 81
.line	1302	loadk        r24   k21 ; k21 = 10
.line	1302	loadk        r25    k7 ; k7 = 49
.line	1302	loadk        r26   k22 ; k22 = 142
.line	1302	loadk        r27   k14 ; k14 = 235
.line	1302	loadk        r28   k23 ; k23 = 174
.line	1302	loadk        r29   k24 ; k24 = 14
.line	1302	loadk        r30   k25 ; k25 = 247
.line	1302	loadk        r31   k26 ; k26 = 29
.line	1302	loadk        r32   k27 ; k27 = 249
.line	1302	loadk        r33   k28 ; k28 = 162
.line	1302	loadk        r34   k29 ; k29 = 239
.line	1302	loadk        r35   k30 ; k30 = 248
.line	1302	loadk        r36   k31 ; k31 = 200
.line	1302	loadk        r37   k32 ; k32 = 201
.line	1302	loadk        r38   k33 ; k33 = 75
.line	1302	loadk        r39   k34 ; k34 = 114
.line	1302	loadk        r40   k35 ; k35 = 58
.line	1302	loadk        r41   k36 ; k36 = 18
.line	1302	loadk        r42   k22 ; k22 = 142
.line	1302	loadk        r43   k37 ; k37 = 217
.line	1302	loadk        r44   k38 ; k38 = 180
.line	1302	loadk        r45   k39 ; k39 = 60
.line	1302	call          r5    41     2
.line	1302	getupval      r6    u1
.line	1302	loadk         r7   k40 ; k40 = 148
.line	1302	loadk         r8   k41 ; k41 = 112
.line	1302	loadk         r9   k42 ; k42 = 79
.line	1302	loadk        r10   k43 ; k43 = 21
.line	1302	loadk        r11    k6 ; k6 = 126
.line	1302	loadk        r12   k17 ; k17 = 219
.line	1302	loadk        r13   k44 ; k44 = 216
.line	1302	loadk        r14   k45 ; k45 = 32
.line	1302	loadk        r15    k4 ; k4 = 177
.line	1302	loadk        r16   k46 ; k46 = 100
.line	1302	loadk        r17   k47 ; k47 = 169
.line	1302	loadk        r18   k48 ; k48 = 226
.line	1302	loadk        r19   k49 ; k49 = 211
.line	1302	loadk        r20   k50 ; k50 = 245
.line	1302	loadk        r21   k37 ; k37 = 217
.line	1302	loadk        r22   k48 ; k48 = 226
.line	1302	loadk        r23   k51 ; k51 = 98
.line	1302	loadk        r24   k52 ; k52 = 31
.line	1302	loadk        r25   k53 ; k53 = 121
.line	1302	loadk        r26   k54 ; k54 = 97
.line	1302	loadk        r27   k55 ; k55 = 136
.line	1302	call          r6    22     0
.line	1302	setlist       r4     0     1
.line	1302	call          r3     2     2
.line	1302	len           r4    r1
.line	1302	call          r2     3     1
.line	1302	gettabup      r2    u0   k56 ; k56 = "ipairs"
.line	1302	move          r3    r1
.line	1302	call          r2     2     4
.line	1302	jmp            0  l238
.line	1302	gettabup      r7    u0   k57 ; k57 = "tonumber"
.line	1302	gettable      r8    r6   k58 ; k58 = "AssetId"
.line	1302	call          r7     2     2
.line	1302	self          r8    r0   k59 ; k59 = "IsUMGSourceImported"
.line	1302	move         r10    r7
.line	1302	call          r8     3     2
.line	1302	test          r8     1
.line	1302	jmp            0   l99
.line	1302	gettable      r8    r0   k60 ; k60 = "ImportingUIAssetMap"
.line	1302	test          r8     0
.line	1302	jmp            0  l208
.line	1302	gettable      r8    r0   k60 ; k60 = "ImportingUIAssetMap"
.line	1302	gettable      r8    r8    r7
.line	1302	test          r8     0
.line	1302	jmp            0  l208
.label	l99
.line	1302	gettabup      r8    u0    k1 ; k1 = "log_format"
.line	1302	gettabup      r9    u0    k2 ; k2 = "table"
.line	1302	gettable      r9    r9    k3 ; k3 = "concat"
.line	1302	newtable     r10     2     0
.line	1302	getupval     r11    u1
.line	1302	loadk        r12    k4 ; k4 = 177
.line	1302	loadk        r13    k5 ; k5 = 122
.line	1302	loadk        r14    k6 ; k6 = 126
.line	1302	loadk        r15    k7 ; k7 = 49
.line	1302	loadk        r16    k8 ; k8 = 120
.line	1302	loadk        r17    k9 ; k9 = 255
.line	1302	loadk        r18   k10 ; k10 = 205
.line	1302	loadk        r19   k11 ; k11 = 35
.line	1302	loadk        r20   k12 ; k12 = 175
.line	1302	loadk        r21   k13 ; k13 = 19
.line	1302	loadk        r22   k14 ; k14 = 235
.line	1302	loadk        r23   k15 ; k15 = 176
.line	1302	loadk        r24   k16 ; k16 = 251
.line	1302	loadk        r25   k17 ; k17 = 219
.line	1302	loadk        r26   k18 ; k18 = 223
.line	1302	loadk        r27    k9 ; k9 = 255
.line	1302	loadk        r28   k19 ; k19 = 115
.line	1302	loadk        r29   k20 ; k20 = 81
.line	1302	loadk        r30   k21 ; k21 = 10
.line	1302	loadk        r31    k7 ; k7 = 49
.line	1302	loadk        r32   k22 ; k22 = 142
.line	1302	loadk        r33   k14 ; k14 = 235
.line	1302	loadk        r34   k23 ; k23 = 174
.line	1302	loadk        r35   k24 ; k24 = 14
.line	1302	loadk        r36   k25 ; k25 = 247
.line	1302	loadk        r37   k26 ; k26 = 29
.line	1302	loadk        r38   k27 ; k27 = 249
.line	1302	loadk        r39   k28 ; k28 = 162
.line	1302	loadk        r40   k29 ; k29 = 239
.line	1302	loadk        r41   k30 ; k30 = 248
.line	1302	loadk        r42   k31 ; k31 = 200
.line	1302	loadk        r43   k32 ; k32 = 201
.line	1302	loadk        r44   k33 ; k33 = 75
.line	1302	loadk        r45   k34 ; k34 = 114
.line	1302	loadk        r46   k35 ; k35 = 58
.line	1302	loadk        r47   k36 ; k36 = 18
.line	1302	loadk        r48   k22 ; k22 = 142
.line	1302	loadk        r49   k37 ; k37 = 217
.line	1302	loadk        r50   k38 ; k38 = 180
.line	1302	loadk        r51   k39 ; k39 = 60
.line	1302	call         r11    41     2
.line	1302	getupval     r12    u1
.line	1302	loadk        r13   k40 ; k40 = 148
.line	1302	loadk        r14   k41 ; k41 = 112
.line	1302	loadk        r15   k42 ; k42 = 79
.line	1302	loadk        r16   k43 ; k43 = 21
.line	1302	loadk        r17    k6 ; k6 = 126
.line	1302	loadk        r18   k17 ; k17 = 219
.line	1302	loadk        r19   k44 ; k44 = 216
.line	1302	loadk        r20   k45 ; k45 = 32
.line	1302	loadk        r21    k4 ; k4 = 177
.line	1302	loadk        r22   k46 ; k46 = 100
.line	1302	loadk        r23   k47 ; k47 = 169
.line	1302	loadk        r24   k48 ; k48 = 226
.line	1302	loadk        r25   k61 ; k61 = 227
.line	1302	loadk        r26   k62 ; k62 = 241
.line	1302	loadk        r27   k63 ; k63 = 197
.line	1302	loadk        r28   k64 ; k64 = 252
.line	1302	loadk        r29   k65 ; k65 = 54
.line	1302	loadk        r30   k66 ; k66 = 65
.line	1302	loadk        r31   k67 ; k67 = 44
.line	1302	loadk        r32   k68 ; k68 = 52
.line	1302	loadk        r33   k69 ; k69 = 128
.line	1302	loadk        r34   k70 ; k70 = 207
.line	1302	loadk        r35   k71 ; k71 = 170
.line	1302	loadk        r36   k26 ; k26 = 29
.line	1302	loadk        r37   k72 ; k72 = 185
.line	1302	loadk        r38    k7 ; k7 = 49
.line	1302	loadk        r39   k73 ; k73 = 240
.line	1302	loadk        r40   k74 ; k74 = 242
.line	1302	loadk        r41   k75 ; k75 = 233
.line	1302	loadk        r42   k76 ; k76 = 231
.line	1302	loadk        r43   k77 ; k77 = 204
.line	1302	loadk        r44   k78 ; k78 = 243
.line	1302	loadk        r45   k79 ; k79 = 116
.line	1302	loadk        r46   k66 ; k66 = 65
.line	1302	loadk        r47   k80 ; k80 = 101
.line	1302	loadk        r48   k79 ; k79 = 116
.line	1302	loadk        r49   k81 ; k81 = 189
.line	1302	loadk        r50   k63 ; k63 = 197
.line	1302	loadk        r51   k71 ; k71 = 170
.line	1302	loadk        r52   k82 ; k82 = 9
.line	1302	call         r12    41     2
.line	1302	getupval     r13    u1
.line	1302	loadk        r14   k83 ; k83 = 146
.line	1302	loadk        r15   k84 ; k84 = 92
.line	1302	loadk        r16   k85 ; k85 = 77
.line	1302	loadk        r17   k86 ; k86 = 78
.line	1302	loadk        r18   k39 ; k39 = 60
.line	1302	loadk        r19   k87 ; k87 = 179
.line	1302	loadk        r20   k88 ; k88 = 202
.line	1302	call         r13     8     0
.line	1302	setlist      r10     0     1
.line	1302	call          r9     2     2
.line	1302	gettabup     r10    u0   k89 ; k89 = "tostring"
.line	1302	gettable     r11    r6   k58 ; k58 = "AssetId"
.line	1302	call         r10     2     0
.line	1302	call          r8     0     1
.line	1302	gettable      r8    r0   k90 ; k90 = "ImportingAssetMap"
.line	1302	test          r8     0
.line	1302	jmp            6  l238
.line	1302	gettable      r8    r0   k90 ; k90 = "ImportingAssetMap"
.line	1302	settable      r8    r7   k91 ; k91 = nil
.line	1302	jmp            6  l238
.label	l208
.line	1302	gettable      r8    r0   k60 ; k60 = "ImportingUIAssetMap"
.line	1302	test          r8     1
.line	1302	jmp            0  l212
.line	1302	newtable      r8     0     0
.label	l212
.line	1302	settable      r0   k60    r8 ; k60 = "ImportingUIAssetMap"
.line	1302	gettable      r8    r0   k60 ; k60 = "ImportingUIAssetMap"
.line	1302	settable      r8    r7   k92 ; k92 = true
.line	1302	loadnil       r8     1
.line	1302	getupval     r10    u2
.line	1302	self         r10   r10   k93 ; k93 = "GetMetaInfoByAssetId"
.line	1302	gettable     r12    r6   k58 ; k58 = "AssetId"
.line	1302	call         r10     3     2
.line	1302	test         r10     0
.line	1302	jmp            0  l229
.line	1302	gettable     r11   r10   k94 ; k94 = "Meta"
.line	1302	test         r11     0
.line	1302	jmp            0  l229
.line	1302	gettable     r11   r10   k94 ; k94 = "Meta"
.line	1302	gettable      r8   r11   k95 ; k95 = "Pic_Url"
.line	1302	gettable     r11   r10   k94 ; k94 = "Meta"
.line	1302	gettable      r9   r11   k96 ; k96 = "Desc"
.label	l229
.line	1302	getupval     r11    u2
.line	1302	self         r11   r11   k97 ; k97 = "ImportUMGFromPrefabM" (truncated)
.line	1302	gettable     r13    r6   k58 ; k58 = "AssetId"
.line	1302	loadbool     r14     0     0
.line	1302	closure      r15    f0
.line	1302	closure      r16    f1
.line	1302	call         r11     6     1
.line	1302	jmp            6  l238
.line	1302	jmp            6  l238
.label	l238
.line	1302	move          r0    r0
.line	1302	move          r0    r0
.line	1302	return        r0     1
.line	1302	move          r0    r0
.line	1302	move          r0    r0
.line	1302	move          r0    r0
.line	1302	move          r0    r0
.line	1302	return        r0     1

.function	main/f39/f0

.source	null
.linedefined	1323
.lastlinedefined	1331
.numparams	3
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	6	true
.upvalue	"U3"	0	true

.constant	k0	"log_format"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	177
.constant	k4	122
.constant	k5	126
.constant	k6	49
.constant	k7	120
.constant	k8	255
.constant	k9	205
.constant	k10	35
.constant	k11	175
.constant	k12	19
.constant	k13	235
.constant	k14	176
.constant	k15	251
.constant	k16	219
.constant	k17	223
.constant	k18	115
.constant	k19	81
.constant	k20	10
.constant	k21	142
.constant	k22	174
.constant	k23	14
.constant	k24	247
.constant	k25	29
.constant	k26	249
.constant	k27	162
.constant	k28	239
.constant	k29	248
.constant	k30	200
.constant	k31	201
.constant	k32	75
.constant	k33	114
.constant	k34	58
.constant	k35	18
.constant	k36	217
.constant	k37	180
.constant	k38	60
.constant	k39	148
.constant	k40	112
.constant	k41	79
.constant	k42	21
.constant	k43	216
.constant	k44	32
.constant	k45	100
.constant	k46	169
.constant	k47	226
.constant	k48	243
.constant	k49	192
.constant	k50	224
.constant	k51	116
.constant	k52	68
.constant	k53	47
.constant	k54	134
.constant	k55	136
.constant	k56	15
.constant	k57	190
.constant	k58	155
.constant	k59	228
.constant	k60	156
.constant	k61	185
.constant	k62	117
.constant	k63	25
.constant	k64	105
.constant	k65	149
.constant	k66	196
.constant	k67	170
.constant	k68	24
.constant	k69	168
.constant	k70	94
.constant	k71	63
.constant	k72	121
.constant	k73	131
.constant	k74	108
.constant	k75	55
.constant	k76	220
.constant	k77	227
.constant	k78	28
.constant	k79	54
.constant	k80	158
.constant	k81	187
.constant	k82	48
.constant	k83	241
.constant	k84	232
.constant	k85	160
.constant	k86	207
.constant	k87	"tostring"
.constant	k88	"AssetId"
.constant	k89	"ImportingAssetMap"
.constant	k90	"tonumber"
.constant	k91	nil
.constant	k92	"ImportingUIAssetMap"

.line	1323	gettabup      r3    u0    k0 ; k0 = "log_format"
.line	1323	gettabup      r4    u0    k1 ; k1 = "table"
.line	1323	gettable      r4    r4    k2 ; k2 = "concat"
.line	1323	newtable      r5     2     0
.line	1323	getupval      r6    u1
.line	1323	loadk         r7    k3 ; k3 = 177
.line	1323	loadk         r8    k4 ; k4 = 122
.line	1323	loadk         r9    k5 ; k5 = 126
.line	1323	loadk        r10    k6 ; k6 = 49
.line	1323	loadk        r11    k7 ; k7 = 120
.line	1323	loadk        r12    k8 ; k8 = 255
.line	1323	loadk        r13    k9 ; k9 = 205
.line	1323	loadk        r14   k10 ; k10 = 35
.line	1323	loadk        r15   k11 ; k11 = 175
.line	1323	loadk        r16   k12 ; k12 = 19
.line	1323	loadk        r17   k13 ; k13 = 235
.line	1323	loadk        r18   k14 ; k14 = 176
.line	1323	loadk        r19   k15 ; k15 = 251
.line	1323	loadk        r20   k16 ; k16 = 219
.line	1323	loadk        r21   k17 ; k17 = 223
.line	1323	loadk        r22    k8 ; k8 = 255
.line	1323	loadk        r23   k18 ; k18 = 115
.line	1323	loadk        r24   k19 ; k19 = 81
.line	1323	loadk        r25   k20 ; k20 = 10
.line	1323	loadk        r26    k6 ; k6 = 49
.line	1323	loadk        r27   k21 ; k21 = 142
.line	1323	loadk        r28   k13 ; k13 = 235
.line	1323	loadk        r29   k22 ; k22 = 174
.line	1323	loadk        r30   k23 ; k23 = 14
.line	1323	loadk        r31   k24 ; k24 = 247
.line	1323	loadk        r32   k25 ; k25 = 29
.line	1323	loadk        r33   k26 ; k26 = 249
.line	1323	loadk        r34   k27 ; k27 = 162
.line	1323	loadk        r35   k28 ; k28 = 239
.line	1323	loadk        r36   k29 ; k29 = 248
.line	1323	loadk        r37   k30 ; k30 = 200
.line	1323	loadk        r38   k31 ; k31 = 201
.line	1323	loadk        r39   k32 ; k32 = 75
.line	1323	loadk        r40   k33 ; k33 = 114
.line	1323	loadk        r41   k34 ; k34 = 58
.line	1323	loadk        r42   k35 ; k35 = 18
.line	1323	loadk        r43   k21 ; k21 = 142
.line	1323	loadk        r44   k36 ; k36 = 217
.line	1323	loadk        r45   k37 ; k37 = 180
.line	1323	loadk        r46   k38 ; k38 = 60
.line	1323	call          r6    41     2
.line	1323	getupval      r7    u1
.line	1323	loadk         r8   k39 ; k39 = 148
.line	1323	loadk         r9   k40 ; k40 = 112
.line	1323	loadk        r10   k41 ; k41 = 79
.line	1323	loadk        r11   k42 ; k42 = 21
.line	1323	loadk        r12    k5 ; k5 = 126
.line	1323	loadk        r13   k16 ; k16 = 219
.line	1323	loadk        r14   k43 ; k43 = 216
.line	1323	loadk        r15   k44 ; k44 = 32
.line	1323	loadk        r16    k3 ; k3 = 177
.line	1323	loadk        r17   k45 ; k45 = 100
.line	1323	loadk        r18   k46 ; k46 = 169
.line	1323	loadk        r19   k47 ; k47 = 226
.line	1323	loadk        r20   k48 ; k48 = 243
.line	1323	loadk        r21   k15 ; k15 = 251
.line	1323	loadk        r22   k49 ; k49 = 192
.line	1323	loadk        r23   k50 ; k50 = 224
.line	1323	loadk        r24   k51 ; k51 = 116
.line	1323	loadk        r25   k52 ; k52 = 68
.line	1323	loadk        r26   k34 ; k34 = 58
.line	1323	loadk        r27   k53 ; k53 = 47
.line	1323	loadk        r28   k49 ; k49 = 192
.line	1323	loadk        r29   k54 ; k54 = 134
.line	1323	loadk        r30   k55 ; k55 = 136
.line	1323	loadk        r31   k56 ; k56 = 15
.line	1323	loadk        r32   k57 ; k57 = 190
.line	1323	loadk        r33    k6 ; k6 = 49
.line	1323	loadk        r34   k50 ; k50 = 224
.line	1323	loadk        r35   k58 ; k58 = 155
.line	1323	loadk        r36   k59 ; k59 = 228
.line	1323	loadk        r37   k14 ; k14 = 176
.line	1323	loadk        r38   k60 ; k60 = 156
.line	1323	loadk        r39   k61 ; k61 = 185
.line	1323	loadk        r40   k62 ; k62 = 117
.line	1323	loadk        r41   k63 ; k63 = 25
.line	1323	loadk        r42   k64 ; k64 = 105
.line	1323	loadk        r43   k35 ; k35 = 18
.line	1323	loadk        r44   k65 ; k65 = 149
.line	1323	loadk        r45   k66 ; k66 = 196
.line	1323	loadk        r46   k67 ; k67 = 170
.line	1323	loadk        r47   k68 ; k68 = 24
.line	1323	call          r7    41     2
.line	1323	getupval      r8    u1
.line	1323	loadk         r9   k69 ; k69 = 168
.line	1323	loadk        r10   k40 ; k40 = 112
.line	1323	loadk        r11   k70 ; k70 = 94
.line	1323	loadk        r12   k71 ; k71 = 63
.line	1323	loadk        r13   k72 ; k72 = 121
.line	1323	loadk        r14   k28 ; k28 = 239
.line	1323	loadk        r15   k73 ; k73 = 131
.line	1323	loadk        r16   k74 ; k74 = 108
.line	1323	loadk        r17   k29 ; k29 = 248
.line	1323	loadk        r18   k75 ; k75 = 55
.line	1323	loadk        r19   k69 ; k69 = 168
.line	1323	loadk        r20   k47 ; k47 = 226
.line	1323	loadk        r21   k36 ; k36 = 217
.line	1323	loadk        r22   k24 ; k24 = 247
.line	1323	loadk        r23   k76 ; k76 = 220
.line	1323	loadk        r24   k77 ; k77 = 227
.line	1323	loadk        r25   k45 ; k45 = 100
.line	1323	loadk        r26   k19 ; k19 = 81
.line	1323	loadk        r27   k78 ; k78 = 28
.line	1323	loadk        r28   k79 ; k79 = 54
.line	1323	loadk        r29   k80 ; k80 = 158
.line	1323	loadk        r30   k31 ; k31 = 201
.line	1323	loadk        r31   k81 ; k81 = 187
.line	1323	loadk        r32   k71 ; k71 = 63
.line	1323	loadk        r33   k27 ; k27 = 162
.line	1323	loadk        r34   k82 ; k82 = 48
.line	1323	loadk        r35   k83 ; k83 = 241
.line	1323	loadk        r36   k84 ; k84 = 232
.line	1323	loadk        r37   k85 ; k85 = 160
.line	1323	loadk        r38   k11 ; k11 = 175
.line	1323	loadk        r39   k86 ; k86 = 207
.line	1323	call          r8    32     0
.line	1323	setlist       r5     0     1
.line	1323	call          r4     2     2
.line	1323	gettabup      r5    u0   k87 ; k87 = "tostring"
.line	1323	gettabup      r6    u2   k88 ; k88 = "AssetId"
.line	1323	call          r5     2     2
.line	1323	gettabup      r6    u0   k87 ; k87 = "tostring"
.line	1323	move          r7    r0
.line	1323	call          r6     2     2
.line	1323	gettabup      r7    u0   k87 ; k87 = "tostring"
.line	1323	move          r8    r1
.line	1323	call          r7     2     0
.line	1323	call          r3     0     1
.line	1323	gettabup      r3    u3   k89 ; k89 = "ImportingAssetMap"
.line	1323	test          r3     0
.line	1323	jmp            0  l142
.line	1323	gettabup      r3    u3   k89 ; k89 = "ImportingAssetMap"
.line	1323	gettabup      r4    u0   k90 ; k90 = "tonumber"
.line	1323	gettabup      r5    u2   k88 ; k88 = "AssetId"
.line	1323	call          r4     2     2
.line	1323	settable      r3    r4   k91 ; k91 = nil
.label	l142
.line	1323	gettabup      r3    u3   k92 ; k92 = "ImportingUIAssetMap"
.line	1323	test          r3     0
.line	1323	jmp            0  l150
.line	1323	gettabup      r3    u3   k92 ; k92 = "ImportingUIAssetMap"
.line	1323	gettabup      r4    u0   k90 ; k90 = "tonumber"
.line	1323	gettabup      r5    u2   k88 ; k88 = "AssetId"
.line	1323	call          r4     2     2
.line	1323	settable      r3    r4   k91 ; k91 = nil
.label	l150
.line	1323	return        r0     1
.line	1323	move          r0    r0
.line	1323	move          r0    r0
.line	1323	gettabup      r3    u1   k89 ; k89 = "ImportingAssetMap"
.line	1323	return        r0     1

.function	main/f39/f1

.source	null
.linedefined	1331
.lastlinedefined	1346
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	6	true
.upvalue	"U3"	0	true
.upvalue	"U4"	8	true
.upvalue	"U5"	9	true

.constant	k0	"log_format"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	177
.constant	k4	122
.constant	k5	126
.constant	k6	49
.constant	k7	120
.constant	k8	255
.constant	k9	205
.constant	k10	35
.constant	k11	175
.constant	k12	19
.constant	k13	235
.constant	k14	176
.constant	k15	251
.constant	k16	219
.constant	k17	223
.constant	k18	115
.constant	k19	81
.constant	k20	10
.constant	k21	142
.constant	k22	174
.constant	k23	14
.constant	k24	247
.constant	k25	29
.constant	k26	249
.constant	k27	162
.constant	k28	239
.constant	k29	248
.constant	k30	200
.constant	k31	201
.constant	k32	75
.constant	k33	114
.constant	k34	58
.constant	k35	18
.constant	k36	217
.constant	k37	180
.constant	k38	60
.constant	k39	148
.constant	k40	112
.constant	k41	79
.constant	k42	21
.constant	k43	216
.constant	k44	32
.constant	k45	100
.constant	k46	169
.constant	k47	226
.constant	k48	244
.constant	k49	224
.constant	k50	227
.constant	k51	119
.constant	k52	65
.constant	k53	199
.constant	k54	165
.constant	k55	16
.constant	k56	53
.constant	k57	185
.constant	k58	172
.constant	k59	170
.constant	k60	253
.constant	k61	117
.constant	k62	80
.constant	k63	61
.constant	k64	152
.constant	k65	140
.constant	k66	73
.constant	k67	149
.constant	k68	"tostring"
.constant	k69	"AssetId"
.constant	k70	"log_tree"
.constant	k71	236
.constant	k72	238
.constant	k73	99
.constant	k74	118
.constant	k75	59
.constant	k76	157
.constant	k77	194
.constant	k78	188
.constant	k79	8
.constant	k80	173
.constant	k81	7
.constant	k82	38
.constant	k83	182
.constant	k84	"ImportingUMGCanvasInfoMap"
.constant	k85	"ipairs"
.constant	k86	"tonumber"
.constant	k87	"FolderID"
.constant	k88	"Icon"
.constant	k89	"Desc"
.constant	k90	"SourceAssetId"

.line	1331	test          r0     1
.line	1331	jmp            0    l4
.line	1331	return        r0     1
.label	l4
.line	1331	gettabup      r1    u0    k0 ; k0 = "log_format"
.line	1331	gettabup      r2    u0    k1 ; k1 = "table"
.line	1331	gettable      r2    r2    k2 ; k2 = "concat"
.line	1331	newtable      r3     2     0
.line	1331	getupval      r4    u1
.line	1331	loadk         r5    k3 ; k3 = 177
.line	1331	loadk         r6    k4 ; k4 = 122
.line	1331	loadk         r7    k5 ; k5 = 126
.line	1331	loadk         r8    k6 ; k6 = 49
.line	1331	loadk         r9    k7 ; k7 = 120
.line	1331	loadk        r10    k8 ; k8 = 255
.line	1331	loadk        r11    k9 ; k9 = 205
.line	1331	loadk        r12   k10 ; k10 = 35
.line	1331	loadk        r13   k11 ; k11 = 175
.line	1331	loadk        r14   k12 ; k12 = 19
.line	1331	loadk        r15   k13 ; k13 = 235
.line	1331	loadk        r16   k14 ; k14 = 176
.line	1331	loadk        r17   k15 ; k15 = 251
.line	1331	loadk        r18   k16 ; k16 = 219
.line	1331	loadk        r19   k17 ; k17 = 223
.line	1331	loadk        r20    k8 ; k8 = 255
.line	1331	loadk        r21   k18 ; k18 = 115
.line	1331	loadk        r22   k19 ; k19 = 81
.line	1331	loadk        r23   k20 ; k20 = 10
.line	1331	loadk        r24    k6 ; k6 = 49
.line	1331	loadk        r25   k21 ; k21 = 142
.line	1331	loadk        r26   k13 ; k13 = 235
.line	1331	loadk        r27   k22 ; k22 = 174
.line	1331	loadk        r28   k23 ; k23 = 14
.line	1331	loadk        r29   k24 ; k24 = 247
.line	1331	loadk        r30   k25 ; k25 = 29
.line	1331	loadk        r31   k26 ; k26 = 249
.line	1331	loadk        r32   k27 ; k27 = 162
.line	1331	loadk        r33   k28 ; k28 = 239
.line	1331	loadk        r34   k29 ; k29 = 248
.line	1331	loadk        r35   k30 ; k30 = 200
.line	1331	loadk        r36   k31 ; k31 = 201
.line	1331	loadk        r37   k32 ; k32 = 75
.line	1331	loadk        r38   k33 ; k33 = 114
.line	1331	loadk        r39   k34 ; k34 = 58
.line	1331	loadk        r40   k35 ; k35 = 18
.line	1331	loadk        r41   k21 ; k21 = 142
.line	1331	loadk        r42   k36 ; k36 = 217
.line	1331	loadk        r43   k37 ; k37 = 180
.line	1331	loadk        r44   k38 ; k38 = 60
.line	1331	call          r4    41     2
.line	1331	getupval      r5    u1
.line	1331	loadk         r6   k39 ; k39 = 148
.line	1331	loadk         r7   k40 ; k40 = 112
.line	1331	loadk         r8   k41 ; k41 = 79
.line	1331	loadk         r9   k42 ; k42 = 21
.line	1331	loadk        r10    k5 ; k5 = 126
.line	1331	loadk        r11   k16 ; k16 = 219
.line	1331	loadk        r12   k43 ; k43 = 216
.line	1331	loadk        r13   k44 ; k44 = 32
.line	1331	loadk        r14    k3 ; k3 = 177
.line	1331	loadk        r15   k45 ; k45 = 100
.line	1331	loadk        r16   k46 ; k46 = 169
.line	1331	loadk        r17   k47 ; k47 = 226
.line	1331	loadk        r18   k17 ; k17 = 223
.line	1331	loadk        r19   k48 ; k48 = 244
.line	1331	loadk        r20   k49 ; k49 = 224
.line	1331	loadk        r21   k50 ; k50 = 227
.line	1331	loadk        r22   k51 ; k51 = 119
.line	1331	loadk        r23   k52 ; k52 = 65
.line	1331	loadk        r24   k38 ; k38 = 60
.line	1331	loadk        r25   k44 ; k44 = 32
.line	1331	loadk        r26   k11 ; k11 = 175
.line	1331	loadk        r27   k53 ; k53 = 199
.line	1331	loadk        r28   k54 ; k54 = 165
.line	1331	loadk        r29   k55 ; k55 = 16
.line	1331	loadk        r30   k11 ; k11 = 175
.line	1331	loadk        r31   k56 ; k56 = 53
.line	1331	loadk        r32   k24 ; k24 = 247
.line	1331	loadk        r33   k57 ; k57 = 185
.line	1331	loadk        r34   k58 ; k58 = 172
.line	1331	loadk        r35   k59 ; k59 = 170
.line	1331	loadk        r36   k60 ; k60 = 253
.line	1331	loadk        r37   k28 ; k28 = 239
.line	1331	loadk        r38   k61 ; k61 = 117
.line	1331	loadk        r39   k62 ; k62 = 80
.line	1331	loadk        r40   k63 ; k63 = 61
.line	1331	loadk        r41   k25 ; k25 = 29
.line	1331	loadk        r42   k64 ; k64 = 152
.line	1331	loadk        r43   k65 ; k65 = 140
.line	1331	loadk        r44   k26 ; k26 = 249
.line	1331	loadk        r45   k66 ; k66 = 73
.line	1331	call          r5    41     2
.line	1331	getupval      r6    u1
.line	1331	loadk         r7   k67 ; k67 = 149
.line	1331	call          r6     2     0
.line	1331	setlist       r3     0     1
.line	1331	call          r2     2     2
.line	1331	gettabup      r3    u0   k68 ; k68 = "tostring"
.line	1331	gettabup      r4    u2   k69 ; k69 = "AssetId"
.line	1331	call          r3     2     0
.line	1331	call          r1     0     1
.line	1331	gettabup      r1    u0   k70 ; k70 = "log_tree"
.line	1331	gettabup      r2    u0    k1 ; k1 = "table"
.line	1331	gettable      r2    r2    k2 ; k2 = "concat"
.line	1331	newtable      r3     2     0
.line	1331	getupval      r4    u1
.line	1331	loadk         r5    k3 ; k3 = 177
.line	1331	loadk         r6    k4 ; k4 = 122
.line	1331	loadk         r7    k5 ; k5 = 126
.line	1331	loadk         r8    k6 ; k6 = 49
.line	1331	loadk         r9    k7 ; k7 = 120
.line	1331	loadk        r10    k8 ; k8 = 255
.line	1331	loadk        r11    k9 ; k9 = 205
.line	1331	loadk        r12   k10 ; k10 = 35
.line	1331	loadk        r13   k11 ; k11 = 175
.line	1331	loadk        r14   k12 ; k12 = 19
.line	1331	loadk        r15   k13 ; k13 = 235
.line	1331	loadk        r16   k14 ; k14 = 176
.line	1331	loadk        r17   k15 ; k15 = 251
.line	1331	loadk        r18   k16 ; k16 = 219
.line	1331	loadk        r19   k17 ; k17 = 223
.line	1331	loadk        r20    k8 ; k8 = 255
.line	1331	loadk        r21   k18 ; k18 = 115
.line	1331	loadk        r22   k19 ; k19 = 81
.line	1331	loadk        r23   k20 ; k20 = 10
.line	1331	loadk        r24    k6 ; k6 = 49
.line	1331	loadk        r25   k21 ; k21 = 142
.line	1331	loadk        r26   k13 ; k13 = 235
.line	1331	loadk        r27   k22 ; k22 = 174
.line	1331	loadk        r28   k23 ; k23 = 14
.line	1331	loadk        r29   k24 ; k24 = 247
.line	1331	loadk        r30   k25 ; k25 = 29
.line	1331	loadk        r31   k26 ; k26 = 249
.line	1331	loadk        r32   k27 ; k27 = 162
.line	1331	loadk        r33   k28 ; k28 = 239
.line	1331	loadk        r34   k29 ; k29 = 248
.line	1331	loadk        r35   k30 ; k30 = 200
.line	1331	loadk        r36   k31 ; k31 = 201
.line	1331	loadk        r37   k32 ; k32 = 75
.line	1331	loadk        r38   k33 ; k33 = 114
.line	1331	loadk        r39   k34 ; k34 = 58
.line	1331	loadk        r40   k35 ; k35 = 18
.line	1331	loadk        r41   k21 ; k21 = 142
.line	1331	loadk        r42   k36 ; k36 = 217
.line	1331	loadk        r43   k37 ; k37 = 180
.line	1331	loadk        r44   k38 ; k38 = 60
.line	1331	call          r4    41     2
.line	1331	getupval      r5    u1
.line	1331	loadk         r6   k39 ; k39 = 148
.line	1331	loadk         r7   k40 ; k40 = 112
.line	1331	loadk         r8   k41 ; k41 = 79
.line	1331	loadk         r9   k42 ; k42 = 21
.line	1331	loadk        r10    k5 ; k5 = 126
.line	1331	loadk        r11   k16 ; k16 = 219
.line	1331	loadk        r12   k43 ; k43 = 216
.line	1331	loadk        r13   k44 ; k44 = 32
.line	1331	loadk        r14    k3 ; k3 = 177
.line	1331	loadk        r15   k45 ; k45 = 100
.line	1331	loadk        r16   k46 ; k46 = 169
.line	1331	loadk        r17   k47 ; k47 = 226
.line	1331	loadk        r18   k17 ; k17 = 223
.line	1331	loadk        r19   k48 ; k48 = 244
.line	1331	loadk        r20   k49 ; k49 = 224
.line	1331	loadk        r21   k50 ; k50 = 227
.line	1331	loadk        r22   k51 ; k51 = 119
.line	1331	loadk        r23   k52 ; k52 = 65
.line	1331	loadk        r24   k38 ; k38 = 60
.line	1331	loadk        r25   k44 ; k44 = 32
.line	1331	loadk        r26   k11 ; k11 = 175
.line	1331	loadk        r27   k53 ; k53 = 199
.line	1331	loadk        r28   k54 ; k54 = 165
.line	1331	loadk        r29   k55 ; k55 = 16
.line	1331	loadk        r30   k11 ; k11 = 175
.line	1331	loadk        r31   k56 ; k56 = 53
.line	1331	loadk        r32   k24 ; k24 = 247
.line	1331	loadk        r33   k57 ; k57 = 185
.line	1331	loadk        r34   k58 ; k58 = 172
.line	1331	loadk        r35   k59 ; k59 = 170
.line	1331	loadk        r36   k71 ; k71 = 236
.line	1331	loadk        r37   k72 ; k72 = 238
.line	1331	loadk        r38   k73 ; k73 = 99
.line	1331	loadk        r39   k74 ; k74 = 118
.line	1331	loadk        r40   k75 ; k75 = 59
.line	1331	loadk        r41    k6 ; k6 = 49
.line	1331	loadk        r42   k76 ; k76 = 157
.line	1331	loadk        r43   k77 ; k77 = 194
.line	1331	loadk        r44   k78 ; k78 = 188
.line	1331	loadk        r45   k79 ; k79 = 8
.line	1331	call          r5    41     2
.line	1331	getupval      r6    u1
.line	1331	loadk         r7   k80 ; k80 = 173
.line	1331	loadk         r8   k40 ; k40 = 112
.line	1331	loadk         r9   k62 ; k62 = 80
.line	1331	loadk        r10   k81 ; k81 = 7
.line	1331	loadk        r11   k82 ; k82 = 38
.line	1331	loadk        r12   k83 ; k83 = 182
.line	1331	call          r6     7     0
.line	1331	setlist       r3     0     1
.line	1331	call          r2     2     2
.line	1331	move          r3    r0
.line	1331	call          r1     3     1
.line	1331	gettabup      r1    u3   k84 ; k84 = "ImportingUMGCanvasIn" (truncated)
.line	1331	test          r1     1
.line	1331	jmp            0  l205
.line	1331	newtable      r1     0     0
.label	l205
.line	1331	settabup      u3   k84    r1 ; k84 = "ImportingUMGCanvasIn" (truncated)
.line	1331	gettabup      r1    u0   k85 ; k85 = "ipairs"
.line	1331	move          r2    r0
.line	1331	call          r1     2     4
.line	1331	jmp            0  l226
.line	1331	gettabup      r6    u3   k84 ; k84 = "ImportingUMGCanvasIn" (truncated)
.line	1331	gettabup      r7    u0   k86 ; k86 = "tonumber"
.line	1331	move          r8    r5
.line	1331	call          r7     2     2
.line	1331	newtable      r8     0     4
.line	1331	gettabup      r9    u2   k87 ; k87 = "FolderID"
.line	1331	settable      r8   k87    r9 ; k87 = "FolderID"
.line	1331	getupval      r9    u4
.line	1331	settable      r8   k88    r9 ; k88 = "Icon"
.line	1331	getupval      r9    u5
.line	1331	settable      r8   k89    r9 ; k89 = "Desc"
.line	1331	gettabup      r9    u0   k86 ; k86 = "tonumber"
.line	1331	gettabup     r10    u2   k69 ; k69 = "AssetId"
.line	1331	call          r9     2     2
.line	1331	settable      r8   k90    r9 ; k90 = "SourceAssetId"
.line	1331	settable      r6    r7    r8
.label	l226
.line	1331	move          r0    r0
.line	1331	move          r0    r0
.line	1331	return        r0     1
.line	1331	move          r0    r0
.line	1331	move          r0    r0
.line	1331	return        r0     1

.function	main/f40

.source	null
.linedefined	1351
.lastlinedefined	1368
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	3	true
.upvalue	"U3"	4	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	177
.constant	k5	122
.constant	k6	126
.constant	k7	49
.constant	k8	120
.constant	k9	255
.constant	k10	205
.constant	k11	35
.constant	k12	175
.constant	k13	19
.constant	k14	235
.constant	k15	176
.constant	k16	251
.constant	k17	219
.constant	k18	223
.constant	k19	115
.constant	k20	81
.constant	k21	10
.constant	k22	142
.constant	k23	174
.constant	k24	14
.constant	k25	247
.constant	k26	7
.constant	k27	237
.constant	k28	188
.constant	k29	227
.constant	k30	221
.constant	k31	211
.constant	k32	238
.constant	k33	109
.constant	k34	116
.constant	k35	58
.constant	k36	39
.constant	k37	153
.constant	k38	194
.constant	k39	157
.constant	k40	13
.constant	k41	146
.constant	k42	125
.constant	k43	27
.constant	k44	89
.constant	k45	242
.constant	k46	208
.constant	k47	56
.constant	k48	178
.constant	k49	54
.constant	k50	"ClampWorkAssetStringFields"
.constant	k51	"AssetPathMap"
.constant	k52	"FillWorkAssetDisplayFromResourceCenter"
.constant	k53	"FolderTreeJson"
.constant	k54	"encode"
.constant	k55	"FolderTree"
.constant	k56	"AssetPathMapJson"
.constant	k57	162
.constant	k58	47
.constant	k59	6
.constant	k60	51
.constant	k61	46
.constant	k62	230
.constant	k63	31
.constant	k64	164
.constant	k65	42
.constant	k66	231
.constant	k67	149
.constant	k68	232
.constant	k69	199
.constant	k70	101
.constant	k71	86
.constant	k72	60
.constant	k73	48
.constant	k74	168
.constant	k75	189
.constant	k76	29
.constant	k77	18
.constant	k78	190
.constant	k79	228
.constant	k80	239
.constant	k81	206
.constant	k82	200
.constant	k83	80
.constant	k84	44
.constant	k85	30
.constant	k86	143
.constant	k87	217
.constant	k88	183
.constant	k89	66
.constant	k90	140
.constant	k91	102
.constant	k92	70
.constant	k93	26
.constant	k94	"gsub"
.constant	k95	198
.constant	k96	"Client"
.constant	k97	"TestSaveStringToFile"
.constant	k98	"format"
.constant	k99	21
.constant	k100	161
.constant	k101	229
.constant	k102	254
.constant	k103	236
.constant	k104	253
.constant	k105	114
.constant	k106	93
.constant	k107	4
.constant	k108	53
.constant	k109	252
.constant	k110	170
.constant	k111	3
.constant	k112	136
.constant	k113	59
.constant	k114	67
.constant	k115	248
.constant	k116	"SendMsgToEditor"
.constant	k117	"G2E"
.constant	k118	"G2E_SyncWorkAssetData"

.line	1351	gettabup      r1    u0    k0 ; k0 = "print"
.line	1351	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1351	test          r2     0
.line	1351	jmp            0   l64
.line	1351	gettabup      r2    u0    k2 ; k2 = "table"
.line	1351	gettable      r2    r2    k3 ; k3 = "concat"
.line	1351	newtable      r3     1     0
.line	1351	getupval      r4    u1
.line	1351	loadk         r5    k4 ; k4 = 177
.line	1351	loadk         r6    k5 ; k5 = 122
.line	1351	loadk         r7    k6 ; k6 = 126
.line	1351	loadk         r8    k7 ; k7 = 49
.line	1351	loadk         r9    k8 ; k8 = 120
.line	1351	loadk        r10    k9 ; k9 = 255
.line	1351	loadk        r11   k10 ; k10 = 205
.line	1351	loadk        r12   k11 ; k11 = 35
.line	1351	loadk        r13   k12 ; k12 = 175
.line	1351	loadk        r14   k13 ; k13 = 19
.line	1351	loadk        r15   k14 ; k14 = 235
.line	1351	loadk        r16   k15 ; k15 = 176
.line	1351	loadk        r17   k16 ; k16 = 251
.line	1351	loadk        r18   k17 ; k17 = 219
.line	1351	loadk        r19   k18 ; k18 = 223
.line	1351	loadk        r20    k9 ; k9 = 255
.line	1351	loadk        r21   k19 ; k19 = 115
.line	1351	loadk        r22   k20 ; k20 = 81
.line	1351	loadk        r23   k21 ; k21 = 10
.line	1351	loadk        r24    k7 ; k7 = 49
.line	1351	loadk        r25   k22 ; k22 = 142
.line	1351	loadk        r26   k14 ; k14 = 235
.line	1351	loadk        r27   k23 ; k23 = 174
.line	1351	loadk        r28   k24 ; k24 = 14
.line	1351	loadk        r29   k25 ; k25 = 247
.line	1351	loadk        r30   k26 ; k26 = 7
.line	1351	loadk        r31   k27 ; k27 = 237
.line	1351	loadk        r32   k28 ; k28 = 188
.line	1351	loadk        r33   k29 ; k29 = 227
.line	1351	loadk        r34   k30 ; k30 = 221
.line	1351	loadk        r35   k31 ; k31 = 211
.line	1351	loadk        r36   k32 ; k32 = 238
.line	1351	loadk        r37   k33 ; k33 = 109
.line	1351	loadk        r38   k34 ; k34 = 116
.line	1351	loadk        r39   k35 ; k35 = 58
.line	1351	loadk        r40   k36 ; k36 = 39
.line	1351	loadk        r41   k37 ; k37 = 153
.line	1351	loadk        r42   k38 ; k38 = 194
.line	1351	loadk        r43   k39 ; k39 = 157
.line	1351	loadk        r44   k40 ; k40 = 13
.line	1351	call          r4    41     2
.line	1351	getupval      r5    u1
.line	1351	loadk         r6   k41 ; k41 = 146
.line	1351	loadk         r7   k34 ; k34 = 116
.line	1351	loadk         r8   k42 ; k42 = 125
.line	1351	loadk         r9   k43 ; k43 = 27
.line	1351	loadk        r10   k44 ; k44 = 89
.line	1351	loadk        r11   k45 ; k45 = 242
.line	1351	loadk        r12   k46 ; k46 = 208
.line	1351	loadk        r13   k47 ; k47 = 56
.line	1351	loadk        r14   k48 ; k48 = 178
.line	1351	loadk        r15   k49 ; k49 = 54
.line	1351	call          r5    11     0
.line	1351	setlist       r3     0     1
.line	1351	call          r2     2     2
.label	l64
.line	1351	call          r1     2     1
.line	1351	self          r1    r0   k50 ; k50 = "ClampWorkAssetString" (truncated)
.line	1351	gettable      r3    r0   k51 ; k51 = "AssetPathMap"
.line	1351	call          r1     3     1
.line	1351	self          r1    r0   k52 ; k52 = "FillWorkAssetDisplay" (truncated)
.line	1351	call          r1     2     1
.line	1351	newtable      r1     0     2
.line	1351	gettabup      r2    u2   k54 ; k54 = "encode"
.line	1351	gettable      r3    r0   k55 ; k55 = "FolderTree"
.line	1351	test          r3     1
.line	1351	jmp            0   l76
.line	1351	newtable      r3     0     0
.label	l76
.line	1351	call          r2     2     2
.line	1351	settable      r1   k53    r2 ; k53 = "FolderTreeJson"
.line	1351	gettabup      r2    u2   k54 ; k54 = "encode"
.line	1351	gettable      r3    r0   k51 ; k51 = "AssetPathMap"
.line	1351	test          r3     1
.line	1351	jmp            0   l83
.line	1351	newtable      r3     0     0
.label	l83
.line	1351	call          r2     2     2
.line	1351	settable      r1   k56    r2 ; k56 = "AssetPathMapJson"
.line	1351	loadbool      r2     0     0
.line	1351	test          r2     0
.line	1351	jmp            0  l237
.line	1351	gettabup      r2    u0    k2 ; k2 = "table"
.line	1351	gettable      r2    r2    k3 ; k3 = "concat"
.line	1351	newtable      r3     1     0
.line	1351	getupval      r4    u1
.line	1351	loadk         r5   k57 ; k57 = 162
.line	1351	loadk         r6   k58 ; k58 = 47
.line	1351	loadk         r7   k59 ; k59 = 6
.line	1351	loadk         r8   k60 ; k60 = 51
.line	1351	loadk         r9   k61 ; k61 = 46
.line	1351	loadk        r10   k31 ; k31 = 211
.line	1351	loadk        r11   k62 ; k62 = 230
.line	1351	loadk        r12   k63 ; k63 = 31
.line	1351	loadk        r13   k64 ; k64 = 164
.line	1351	loadk        r14   k65 ; k65 = 42
.line	1351	loadk        r15   k66 ; k66 = 231
.line	1351	loadk        r16   k67 ; k67 = 149
.line	1351	loadk        r17    k9 ; k9 = 255
.line	1351	loadk        r18   k68 ; k68 = 232
.line	1351	loadk        r19   k69 ; k69 = 199
.line	1351	loadk        r20   k10 ; k10 = 205
.line	1351	loadk        r21   k70 ; k70 = 101
.line	1351	loadk        r22   k71 ; k71 = 86
.line	1351	loadk        r23   k72 ; k72 = 60
.line	1351	loadk        r24   k73 ; k73 = 48
.line	1351	loadk        r25   k74 ; k74 = 168
.line	1351	loadk        r26   k69 ; k69 = 199
.line	1351	loadk        r27   k75 ; k75 = 189
.line	1351	loadk        r28   k76 ; k76 = 29
.line	1351	loadk        r29   k41 ; k41 = 146
.line	1351	loadk        r30   k77 ; k77 = 18
.line	1351	loadk        r31   k16 ; k16 = 251
.line	1351	loadk        r32   k78 ; k78 = 190
.line	1351	loadk        r33   k79 ; k79 = 228
.line	1351	loadk        r34   k80 ; k80 = 239
.line	1351	loadk        r35   k81 ; k81 = 206
.line	1351	loadk        r36   k82 ; k82 = 200
.line	1351	loadk        r37   k34 ; k34 = 116
.line	1351	loadk        r38   k83 ; k83 = 80
.line	1351	loadk        r39   k84 ; k84 = 44
.line	1351	loadk        r40   k85 ; k85 = 30
.line	1351	loadk        r41   k86 ; k86 = 143
.line	1351	loadk        r42   k87 ; k87 = 217
.line	1351	loadk        r43   k88 ; k88 = 183
.line	1351	loadk        r44   k89 ; k89 = 66
.line	1351	call          r4    41     2
.line	1351	getupval      r5    u1
.line	1351	loadk         r6   k90 ; k90 = 140
.line	1351	loadk         r7   k91 ; k91 = 102
.line	1351	loadk         r8   k92 ; k92 = 70
.line	1351	loadk         r9   k93 ; k93 = 26
.line	1351	call          r5     5     0
.line	1351	setlist       r3     0     1
.line	1351	call          r2     2     2
.line	1351	self          r3    r2   k94 ; k94 = "gsub"
.line	1351	getupval      r5    u1
.line	1351	loadk         r6   k95 ; k95 = 198
.line	1351	call          r5     2     2
.line	1351	getupval      r6    u1
.line	1351	call          r6     1     2
.line	1351	call          r3     4     2
.line	1351	move          r2    r3
.line	1351	gettabup      r3    u0   k96 ; k96 = "Client"
.line	1351	gettable      r3    r3   k97 ; k97 = "TestSaveStringToFile"
.line	1351	gettabup      r4    u2   k98 ; k98 = "format"
.line	1351	gettable      r5    r1   k53 ; k53 = "FolderTreeJson"
.line	1351	call          r4     2     2
.line	1351	getupval      r5    u1
.line	1351	loadk         r6   k57 ; k57 = 162
.line	1351	loadk         r7   k58 ; k58 = 47
.line	1351	loadk         r8   k59 ; k59 = 6
.line	1351	call          r5     4     2
.line	1351	move          r6    r2
.line	1351	call          r3     4     1
.line	1351	gettabup      r3    u0    k2 ; k2 = "table"
.line	1351	gettable      r3    r3    k3 ; k3 = "concat"
.line	1351	newtable      r4     1     0
.line	1351	getupval      r5    u1
.line	1351	loadk         r6   k57 ; k57 = 162
.line	1351	loadk         r7   k58 ; k58 = 47
.line	1351	loadk         r8   k59 ; k59 = 6
.line	1351	loadk         r9   k60 ; k60 = 51
.line	1351	loadk        r10   k61 ; k61 = 46
.line	1351	loadk        r11   k31 ; k31 = 211
.line	1351	loadk        r12   k62 ; k62 = 230
.line	1351	loadk        r13   k63 ; k63 = 31
.line	1351	loadk        r14   k64 ; k64 = 164
.line	1351	loadk        r15   k65 ; k65 = 42
.line	1351	loadk        r16   k66 ; k66 = 231
.line	1351	loadk        r17   k67 ; k67 = 149
.line	1351	loadk        r18    k9 ; k9 = 255
.line	1351	loadk        r19   k68 ; k68 = 232
.line	1351	loadk        r20   k69 ; k69 = 199
.line	1351	loadk        r21   k10 ; k10 = 205
.line	1351	loadk        r22   k70 ; k70 = 101
.line	1351	loadk        r23   k71 ; k71 = 86
.line	1351	loadk        r24   k72 ; k72 = 60
.line	1351	loadk        r25   k73 ; k73 = 48
.line	1351	loadk        r26   k74 ; k74 = 168
.line	1351	loadk        r27   k69 ; k69 = 199
.line	1351	loadk        r28   k75 ; k75 = 189
.line	1351	loadk        r29   k76 ; k76 = 29
.line	1351	loadk        r30   k41 ; k41 = 146
.line	1351	loadk        r31   k99 ; k99 = 21
.line	1351	loadk        r32   k66 ; k66 = 231
.line	1351	loadk        r33  k100 ; k100 = 161
.line	1351	loadk        r34  k101 ; k101 = 229
.line	1351	loadk        r35  k102 ; k102 = 254
.line	1351	loadk        r36  k103 ; k103 = 236
.line	1351	loadk        r37  k104 ; k104 = 253
.line	1351	loadk        r38  k105 ; k105 = 114
.line	1351	loadk        r39  k106 ; k106 = 93
.line	1351	loadk        r40  k107 ; k107 = 4
.line	1351	loadk        r41  k108 ; k108 = 53
.line	1351	loadk        r42   k90 ; k90 = 140
.line	1351	loadk        r43  k109 ; k109 = 252
.line	1351	loadk        r44  k110 ; k110 = 170
.line	1351	loadk        r45  k111 ; k111 = 3
.line	1351	call          r5    41     2
.line	1351	getupval      r6    u1
.line	1351	loadk         r7  k112 ; k112 = 136
.line	1351	loadk         r8  k113 ; k113 = 59
.line	1351	loadk         r9  k114 ; k114 = 67
.line	1351	loadk        r10   k26 ; k26 = 7
.line	1351	loadk        r11   k19 ; k19 = 115
.line	1351	loadk        r12  k115 ; k115 = 248
.line	1351	call          r6     7     0
.line	1351	setlist       r4     0     1
.line	1351	call          r3     2     2
.line	1351	move          r2    r3
.line	1351	self          r3    r2   k94 ; k94 = "gsub"
.line	1351	getupval      r5    u1
.line	1351	loadk         r6   k95 ; k95 = 198
.line	1351	call          r5     2     2
.line	1351	getupval      r6    u1
.line	1351	call          r6     1     2
.line	1351	call          r3     4     2
.line	1351	move          r2    r3
.line	1351	gettabup      r3    u0   k96 ; k96 = "Client"
.line	1351	gettable      r3    r3   k97 ; k97 = "TestSaveStringToFile"
.line	1351	gettabup      r4    u2   k98 ; k98 = "format"
.line	1351	gettable      r5    r1   k56 ; k56 = "AssetPathMapJson"
.line	1351	call          r4     2     2
.line	1351	getupval      r5    u1
.line	1351	loadk         r6   k57 ; k57 = 162
.line	1351	loadk         r7   k58 ; k58 = 47
.line	1351	loadk         r8   k59 ; k59 = 6
.line	1351	call          r5     4     2
.line	1351	move          r6    r2
.line	1351	call          r3     4     1
.label	l237
.line	1351	self          r2    r0  k116 ; k116 = "SendMsgToEditor"
.line	1351	gettabup      r4    u3  k117 ; k117 = "G2E"
.line	1351	gettable      r4    r4  k118 ; k118 = "G2E_SyncWorkAssetDat" (truncated)
.line	1351	move          r5    r1
.line	1351	call          r2     4     1
.line	1351	return        r0     1
.line	1351	move          r0    r0
.line	1351	return        r0     1

.function	main/f41

.source	null
.linedefined	1370
.lastlinedefined	1513
.numparams	2
.is_vararg	0
.maxstacksize	67

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	3	true
.upvalue	"U3"	15	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	177
.constant	k5	122
.constant	k6	126
.constant	k7	49
.constant	k8	120
.constant	k9	255
.constant	k10	205
.constant	k11	35
.constant	k12	175
.constant	k13	19
.constant	k14	235
.constant	k15	176
.constant	k16	251
.constant	k17	219
.constant	k18	223
.constant	k19	115
.constant	k20	81
.constant	k21	10
.constant	k22	142
.constant	k23	174
.constant	k24	14
.constant	k25	247
.constant	k26	27
.constant	k27	250
.constant	k28	128
.constant	k29	229
.constant	k30	243
.constant	k31	116
.constant	k32	94
.constant	k33	8
.constant	k34	39
.constant	k35	143
.constant	k36	211
.constant	k37	173
.constant	k38	63
.constant	k39	135
.constant	k40	99
.constant	k41	76
.constant	k42	84
.constant	k43	182
.constant	k44	41
.constant	k45	172
.constant	k46	9
.constant	k47	165
.constant	k48	210
.constant	k49	245
.constant	k50	200
.constant	k51	54
.constant	k52	55
.constant	k53	50
.constant	k54	141
.constant	k55	202
.constant	k56	160
.constant	k57	24
.constant	k58	"SendSaveResponse"
.constant	k59	180
.constant	k60	112
.constant	k61	88
.constant	k62	57
.constant	k63	111
.constant	k64	241
.constant	k65	185
.constant	k66	61
.constant	k67	164
.constant	k68	171
.constant	k69	254
.constant	k70	236
.constant	k71	224
.constant	k72	127
.constant	k73	65
.constant	k74	"FolderTreeJson"
.constant	k75	"decode"
.constant	k76	"type"
.constant	k77	146
.constant	k78	75
.constant	k79	121
.constant	k80	"FolderTree"
.constant	k81	"SaveFolderTree"
.constant	k82	69
.constant	k83	16
.constant	k84	228
.constant	k85	237
.constant	k86	62
.constant	k87	184
.constant	k88	33
.constant	k89	206
.constant	k90	244
.constant	k91	140
.constant	k92	232
.constant	k93	70
.constant	k94	32
.constant	k95	137
.constant	k96	134
.constant	k97	29
.constant	k98	56
.constant	k99	"AssetPathMapJson"
.constant	k100	"ClampWorkAssetStringFields"
.constant	k101	"SubsystemMgr"
.constant	k102	"Get"
.constant	k103	103
.constant	k104	21
.constant	k105	104
.constant	k106	207
.constant	k107	156
.constant	k108	240
.constant	k109	226
.constant	k110	98
.constant	k111	74
.constant	k112	43
.constant	k113	23
.constant	k114	153
.constant	k115	196
.constant	k116	186
.constant	k117	5
.constant	k118	190
.constant	k119	191
.constant	k120	"ipairs"
.constant	k121	"AssetType"
.constant	k122	"Actor"
.constant	k123	"AssetPathMap"
.constant	k124	"AssetUID"
.constant	k125	nil
.constant	k126	"Api_RenameActor"
.constant	k127	"tonumber"
.constant	k128	"AssetName"
.constant	k129	"Operation"
.constant	k130	180
.constant	k131	71
.constant	k132	113
.constant	k133	243
.constant	k134	"AssetType"
.constant	k135	167
.constant	k136	118
.constant	k137	93
.constant	k138	27
.constant	k139	110
.constant	k140	"ErrorMsg"
.constant	k141	"ErrorCode"
.constant	k142	"encode"
.constant	k143	"Effect"
.constant	k144	"AssetPathMap"
.constant	k145	"AssetUID"
.constant	k146	165
.constant	k147	103
.constant	k148	76
.constant	k149	255
.constant	k150	207
.constant	k151	144
.constant	k152	43
.constant	k153	224
.constant	k154	192
.constant	k155	251
.constant	k156	222
.constant	k157	248
.constant	k158	53
.constant	k159	191
.constant	k160	223
.constant	k161	8
.constant	k162	168
.constant	k163	57
.constant	k164	199
.constant	k165	226
.constant	k166	217
.constant	k167	197
.constant	k168	239
.constant	k169	114
.constant	k170	80
.constant	k171	36
.constant	k172	"GetCustomParticleConfig"
.constant	k173	"ParticleName"
.constant	k174	"SetCustomParticleConfig"
.constant	k175	"ipairs"
.constant	k176	"tostring"
.constant	k177	true
.constant	k178	"GetCreativeActorDataManager"
.constant	k179	"Actor"
.constant	k180	"IsValidActorID"
.constant	k181	"UnloadingAssetIds"
.constant	k182	"table"
.constant	k183	"insert"
.constant	k184	"concat"
.constant	k185	177
.constant	k186	122
.constant	k187	126
.constant	k188	49
.constant	k189	120
.constant	k190	205
.constant	k191	35
.constant	k192	175
.constant	k193	19
.constant	k194	235
.constant	k195	176
.constant	k196	219
.constant	k197	115
.constant	k198	81
.constant	k199	10
.constant	k200	142
.constant	k201	174
.constant	k202	14
.constant	k203	247
.constant	k204	250
.constant	k205	128
.constant	k206	229
.constant	k207	116
.constant	k208	94
.constant	k209	39
.constant	k210	143
.constant	k211	211
.constant	k212	173
.constant	k213	63
.constant	k214	135
.constant	k215	99
.constant	k216	84
.constant	k217	182
.constant	k218	52
.constant	k219	164
.constant	k220	163
.constant	k221	227
.constant	k222	233
.constant	k223	201
.constant	k224	72
.constant	k225	48
.constant	k226	159
.constant	k227	237
.constant	k228	242
.constant	k229	238
.constant	k230	213
.constant	k231	232
.constant	k232	105
.constant	k233	215
.constant	k234	169
.constant	k235	31
.constant	k236	"ImportingAssetMap"
.constant	k237	"SaveAssetPathMap"
.constant	k238	"SyncWorkAssetDataToEditor"
.constant	k239	221
.constant	k240	7
.constant	k241	28
.constant	k242	188
.constant	k243	234
.constant	k244	230
.constant	k245	121
.constant	k246	166
.constant	k247	179
.constant	k248	102
.constant	k249	90
.constant	k250	17
.constant	k251	198
.constant	k252	216
.constant	k253	181
.constant	k254	178
.constant	k255	218
.constant	k256	195
.constant	k257	60
.constant	k258	131
.constant	k259	194
.constant	k260	92
.constant	k261	253
.constant	k262	193
.constant	k263	119
.constant	k264	85
.constant	k265	170
.constant	k266	89
.constant	k267	44

.line	1370	gettabup      r2    u0    k0 ; k0 = "print"
.line	1370	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1370	test          r3     0
.line	1370	jmp            0   l57
.line	1370	gettabup      r3    u0    k2 ; k2 = "table"
.line	1370	gettable      r3    r3    k3 ; k3 = "concat"
.line	1370	newtable      r4     1     0
.line	1370	getupval      r5    u1
.line	1370	loadk         r6    k4 ; k4 = 177
.line	1370	loadk         r7    k5 ; k5 = 122
.line	1370	loadk         r8    k6 ; k6 = 126
.line	1370	loadk         r9    k7 ; k7 = 49
.line	1370	loadk        r10    k8 ; k8 = 120
.line	1370	loadk        r11    k9 ; k9 = 255
.line	1370	loadk        r12   k10 ; k10 = 205
.line	1370	loadk        r13   k11 ; k11 = 35
.line	1370	loadk        r14   k12 ; k12 = 175
.line	1370	loadk        r15   k13 ; k13 = 19
.line	1370	loadk        r16   k14 ; k14 = 235
.line	1370	loadk        r17   k15 ; k15 = 176
.line	1370	loadk        r18   k16 ; k16 = 251
.line	1370	loadk        r19   k17 ; k17 = 219
.line	1370	loadk        r20   k18 ; k18 = 223
.line	1370	loadk        r21    k9 ; k9 = 255
.line	1370	loadk        r22   k19 ; k19 = 115
.line	1370	loadk        r23   k20 ; k20 = 81
.line	1370	loadk        r24   k21 ; k21 = 10
.line	1370	loadk        r25    k7 ; k7 = 49
.line	1370	loadk        r26   k22 ; k22 = 142
.line	1370	loadk        r27   k14 ; k14 = 235
.line	1370	loadk        r28   k23 ; k23 = 174
.line	1370	loadk        r29   k24 ; k24 = 14
.line	1370	loadk        r30   k25 ; k25 = 247
.line	1370	loadk        r31   k26 ; k26 = 27
.line	1370	loadk        r32   k27 ; k27 = 250
.line	1370	loadk        r33   k28 ; k28 = 128
.line	1370	loadk        r34   k29 ; k29 = 229
.line	1370	loadk        r35   k16 ; k16 = 251
.line	1370	loadk        r36   k14 ; k14 = 235
.line	1370	loadk        r37   k30 ; k30 = 243
.line	1370	loadk        r38   k31 ; k31 = 116
.line	1370	loadk        r39   k32 ; k32 = 94
.line	1370	loadk        r40   k33 ; k33 = 8
.line	1370	loadk        r41   k34 ; k34 = 39
.line	1370	loadk        r42   k35 ; k35 = 143
.line	1370	loadk        r43   k36 ; k36 = 211
.line	1370	loadk        r44   k37 ; k37 = 173
.line	1370	loadk        r45   k38 ; k38 = 63
.line	1370	call          r5    41     2
.line	1370	getupval      r6    u1
.line	1370	loadk         r7   k39 ; k39 = 135
.line	1370	loadk         r8   k40 ; k40 = 99
.line	1370	loadk         r9   k41 ; k41 = 76
.line	1370	call          r6     4     0
.line	1370	setlist       r4     0     1
.line	1370	call          r3     2     2
.label	l57
.line	1370	call          r2     2     1
.line	1370	test          r1     1
.line	1370	jmp            0  l162
.line	1370	gettabup      r2    u0    k0 ; k0 = "print"
.line	1370	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1370	test          r3     0
.line	1370	jmp            0  l137
.line	1370	gettabup      r3    u0    k2 ; k2 = "table"
.line	1370	gettable      r3    r3    k3 ; k3 = "concat"
.line	1370	newtable      r4     1     0
.line	1370	getupval      r5    u1
.line	1370	loadk         r6    k4 ; k4 = 177
.line	1370	loadk         r7    k5 ; k5 = 122
.line	1370	loadk         r8    k6 ; k6 = 126
.line	1370	loadk         r9    k7 ; k7 = 49
.line	1370	loadk        r10    k8 ; k8 = 120
.line	1370	loadk        r11    k9 ; k9 = 255
.line	1370	loadk        r12   k10 ; k10 = 205
.line	1370	loadk        r13   k11 ; k11 = 35
.line	1370	loadk        r14   k12 ; k12 = 175
.line	1370	loadk        r15   k13 ; k13 = 19
.line	1370	loadk        r16   k14 ; k14 = 235
.line	1370	loadk        r17   k15 ; k15 = 176
.line	1370	loadk        r18   k16 ; k16 = 251
.line	1370	loadk        r19   k17 ; k17 = 219
.line	1370	loadk        r20   k18 ; k18 = 223
.line	1370	loadk        r21    k9 ; k9 = 255
.line	1370	loadk        r22   k19 ; k19 = 115
.line	1370	loadk        r23   k20 ; k20 = 81
.line	1370	loadk        r24   k21 ; k21 = 10
.line	1370	loadk        r25    k7 ; k7 = 49
.line	1370	loadk        r26   k22 ; k22 = 142
.line	1370	loadk        r27   k14 ; k14 = 235
.line	1370	loadk        r28   k23 ; k23 = 174
.line	1370	loadk        r29   k24 ; k24 = 14
.line	1370	loadk        r30   k25 ; k25 = 247
.line	1370	loadk        r31   k26 ; k26 = 27
.line	1370	loadk        r32   k27 ; k27 = 250
.line	1370	loadk        r33   k28 ; k28 = 128
.line	1370	loadk        r34   k29 ; k29 = 229
.line	1370	loadk        r35   k16 ; k16 = 251
.line	1370	loadk        r36   k14 ; k14 = 235
.line	1370	loadk        r37   k30 ; k30 = 243
.line	1370	loadk        r38   k31 ; k31 = 116
.line	1370	loadk        r39   k32 ; k32 = 94
.line	1370	loadk        r40   k33 ; k33 = 8
.line	1370	loadk        r41   k34 ; k34 = 39
.line	1370	loadk        r42   k35 ; k35 = 143
.line	1370	loadk        r43   k36 ; k36 = 211
.line	1370	loadk        r44   k37 ; k37 = 173
.line	1370	loadk        r45   k38 ; k38 = 63
.line	1370	call          r5    41     2
.line	1370	getupval      r6    u1
.line	1370	loadk         r7   k39 ; k39 = 135
.line	1370	loadk         r8   k40 ; k40 = 99
.line	1370	loadk         r9   k41 ; k41 = 76
.line	1370	loadk        r10   k42 ; k42 = 84
.line	1370	loadk        r11    k7 ; k7 = 49
.line	1370	loadk        r12   k43 ; k43 = 182
.line	1370	loadk        r13   k14 ; k14 = 235
.line	1370	loadk        r14   k44 ; k44 = 41
.line	1370	loadk        r15   k45 ; k45 = 172
.line	1370	loadk        r16   k46 ; k46 = 9
.line	1370	loadk        r17   k25 ; k25 = 247
.line	1370	loadk        r18   k47 ; k47 = 165
.line	1370	loadk        r19   k48 ; k48 = 210
.line	1370	loadk        r20   k49 ; k49 = 245
.line	1370	loadk        r21   k50 ; k50 = 200
.line	1370	loadk        r22   k49 ; k49 = 245
.line	1370	loadk        r23   k51 ; k51 = 54
.line	1370	loadk        r24   k41 ; k41 = 76
.line	1370	loadk        r25   k52 ; k52 = 55
.line	1370	loadk        r26   k53 ; k53 = 50
.line	1370	loadk        r27   k54 ; k54 = 141
.line	1370	loadk        r28   k55 ; k55 = 202
.line	1370	loadk        r29   k56 ; k56 = 160
.line	1370	loadk        r30   k57 ; k57 = 24
.line	1370	call          r6    25     0
.line	1370	setlist       r4     0     1
.line	1370	call          r3     2     2
.label	l137
.line	1370	call          r2     2     1
.line	1370	self          r2    r0   k58 ; k58 = "SendSaveResponse"
.line	1370	loadbool      r4     0     0
.line	1370	getupval      r5    u1
.line	1370	loadk         r6   k59 ; k59 = 180
.line	1370	loadk         r7   k60 ; k60 = 112
.line	1370	loadk         r8   k61 ; k61 = 88
.line	1370	loadk         r9   k62 ; k62 = 57
.line	1370	loadk        r10   k63 ; k63 = 111
.line	1370	loadk        r11   k64 ; k64 = 241
.line	1370	loadk        r12   k16 ; k16 = 251
.line	1370	loadk        r13   k11 ; k11 = 35
.line	1370	loadk        r14   k65 ; k65 = 185
.line	1370	loadk        r15   k66 ; k66 = 61
.line	1370	loadk        r16   k67 ; k67 = 164
.line	1370	loadk        r17   k68 ; k68 = 171
.line	1370	loadk        r18   k69 ; k69 = 254
.line	1370	loadk        r19   k70 ; k70 = 236
.line	1370	loadk        r20   k10 ; k10 = 205
.line	1370	loadk        r21   k71 ; k71 = 224
.line	1370	loadk        r22   k72 ; k72 = 127
.line	1370	loadk        r23   k73 ; k73 = 65
.line	1370	call          r5    19     2
.line	1370	call          r2     4     1
.line	1370	return        r0     1
.label	l162
.line	1370	loadbool      r2     1     0
.line	1370	getupval      r3    u1
.line	1370	call          r3     1     2
.line	1370	loadbool      r4     0     0
.line	1370	loadbool      r5     0     0
.line	1370	gettable      r6    r1   k74 ; k74 = "FolderTreeJson"
.line	1370	test          r6     0
.line	1370	jmp            0  l289
.line	1370	getupval      r7    u1
.line	1370	call          r7     1     2
.line	1370	eq             1    r6    r7
.line	1370	jmp            0  l289
.line	1370	gettabup      r7    u2   k75 ; k75 = "decode"
.line	1370	move          r8    r6
.line	1370	call          r7     2     2
.line	1370	test          r7     0
.line	1370	jmp            0  l195
.line	1370	gettabup      r8    u0   k76 ; k76 = "type"
.line	1370	move          r9    r7
.line	1370	call          r8     2     2
.line	1370	getupval      r9    u1
.line	1370	loadk        r10   k77 ; k77 = 146
.line	1370	loadk        r11   k31 ; k31 = 116
.line	1370	loadk        r12   k78 ; k78 = 75
.line	1370	loadk        r13   k57 ; k57 = 24
.line	1370	loadk        r14   k79 ; k79 = 121
.line	1370	call          r9     6     2
.line	1370	eq             0    r8    r9
.line	1370	jmp            0  l195
.line	1370	settable      r0   k80    r7 ; k80 = "FolderTree"
.line	1370	self          r8    r0   k81 ; k81 = "SaveFolderTree"
.line	1370	call          r8     2     1
.line	1370	jmp            0  l289
.label	l195
.line	1370	loadbool      r2     0     0
.line	1370	getupval      r8    u1
.line	1370	loadk         r9   k56 ; k56 = 160
.line	1370	loadk        r10    k5 ; k5 = 122
.line	1370	loadk        r11   k82 ; k82 = 69
.line	1370	loadk        r12   k83 ; k83 = 16
.line	1370	loadk        r13   k79 ; k79 = 121
.line	1370	loadk        r14   k84 ; k84 = 228
.line	1370	loadk        r15   k85 ; k85 = 237
.line	1370	loadk        r16   k86 ; k86 = 62
.line	1370	loadk        r17   k87 ; k87 = 184
.line	1370	loadk        r18   k88 ; k88 = 33
.line	1370	loadk        r19   k89 ; k89 = 206
.line	1370	loadk        r20    k4 ; k4 = 177
.line	1370	loadk        r21    k9 ; k9 = 255
.line	1370	loadk        r22   k90 ; k90 = 244
.line	1370	loadk        r23   k91 ; k91 = 140
.line	1370	loadk        r24   k92 ; k92 = 232
.line	1370	loadk        r25   k19 ; k19 = 115
.line	1370	loadk        r26   k93 ; k93 = 70
.line	1370	loadk        r27   k51 ; k51 = 54
.line	1370	loadk        r28   k94 ; k94 = 32
.line	1370	loadk        r29   k95 ; k95 = 137
.line	1370	loadk        r30   k96 ; k96 = 134
.line	1370	loadk        r31   k12 ; k12 = 175
.line	1370	loadk        r32   k97 ; k97 = 29
.line	1370	loadk        r33   k67 ; k67 = 164
.line	1370	loadk        r34   k98 ; k98 = 56
.line	1370	loadk        r35   k64 ; k64 = 241
.line	1370	loadk        r36   k43 ; k43 = 182
.line	1370	call          r8    29     2
.line	1370	move          r3    r8
.line	1370	gettabup      r8    u0    k0 ; k0 = "print"
.line	1370	gettabup      r9    u0    k1 ; k1 = "bWriteLog"
.line	1370	test          r9     0
.line	1370	jmp            0  l288
.line	1370	gettabup      r9    u0    k2 ; k2 = "table"
.line	1370	gettable      r9    r9    k3 ; k3 = "concat"
.line	1370	newtable     r10     1     0
.line	1370	getupval     r11    u1
.line	1370	loadk        r12    k4 ; k4 = 177
.line	1370	loadk        r13    k5 ; k5 = 122
.line	1370	loadk        r14    k6 ; k6 = 126
.line	1370	loadk        r15    k7 ; k7 = 49
.line	1370	loadk        r16    k8 ; k8 = 120
.line	1370	loadk        r17    k9 ; k9 = 255
.line	1370	loadk        r18   k10 ; k10 = 205
.line	1370	loadk        r19   k11 ; k11 = 35
.line	1370	loadk        r20   k12 ; k12 = 175
.line	1370	loadk        r21   k13 ; k13 = 19
.line	1370	loadk        r22   k14 ; k14 = 235
.line	1370	loadk        r23   k15 ; k15 = 176
.line	1370	loadk        r24   k16 ; k16 = 251
.line	1370	loadk        r25   k17 ; k17 = 219
.line	1370	loadk        r26   k18 ; k18 = 223
.line	1370	loadk        r27    k9 ; k9 = 255
.line	1370	loadk        r28   k19 ; k19 = 115
.line	1370	loadk        r29   k20 ; k20 = 81
.line	1370	loadk        r30   k21 ; k21 = 10
.line	1370	loadk        r31    k7 ; k7 = 49
.line	1370	loadk        r32   k22 ; k22 = 142
.line	1370	loadk        r33   k14 ; k14 = 235
.line	1370	loadk        r34   k23 ; k23 = 174
.line	1370	loadk        r35   k24 ; k24 = 14
.line	1370	loadk        r36   k25 ; k25 = 247
.line	1370	loadk        r37   k26 ; k26 = 27
.line	1370	loadk        r38   k27 ; k27 = 250
.line	1370	loadk        r39   k28 ; k28 = 128
.line	1370	loadk        r40   k29 ; k29 = 229
.line	1370	loadk        r41   k16 ; k16 = 251
.line	1370	loadk        r42   k14 ; k14 = 235
.line	1370	loadk        r43   k30 ; k30 = 243
.line	1370	loadk        r44   k31 ; k31 = 116
.line	1370	loadk        r45   k32 ; k32 = 94
.line	1370	loadk        r46   k33 ; k33 = 8
.line	1370	loadk        r47   k34 ; k34 = 39
.line	1370	loadk        r48   k35 ; k35 = 143
.line	1370	loadk        r49   k36 ; k36 = 211
.line	1370	loadk        r50   k37 ; k37 = 173
.line	1370	loadk        r51   k38 ; k38 = 63
.line	1370	call         r11    41     2
.line	1370	getupval     r12    u1
.line	1370	loadk        r13   k39 ; k39 = 135
.line	1370	loadk        r14   k40 ; k40 = 99
.line	1370	loadk        r15   k41 ; k41 = 76
.line	1370	loadk        r16   k42 ; k42 = 84
.line	1370	loadk        r17    k7 ; k7 = 49
.line	1370	loadk        r18   k43 ; k43 = 182
.line	1370	call         r12     7     0
.line	1370	setlist      r10     0     1
.line	1370	call          r9     2     2
.line	1370	move         r10    r3
.line	1370	concat        r9    r9   r10
.label	l288
.line	1370	call          r8     2     1
.label	l289
.line	1370	closure       r7    f0
.line	1370	gettable      r8    r1   k99 ; k99 = "AssetPathMapJson"
.line	1370	test          r8     0
.line	1370	jmp            0  l907
.line	1370	getupval      r9    u1
.line	1370	call          r9     1     2
.line	1370	eq             1    r8    r9
.line	1370	jmp            0  l907
.line	1370	gettabup      r9    u2   k75 ; k75 = "decode"
.line	1370	move         r10    r8
.line	1370	call          r9     2     2
.line	1370	test          r9     0
.line	1370	jmp            0  l741
.line	1370	gettabup     r10    u0   k76 ; k76 = "type"
.line	1370	move         r11    r9
.line	1370	call         r10     2     2
.line	1370	getupval     r11    u1
.line	1370	loadk        r12   k77 ; k77 = 146
.line	1370	loadk        r13   k31 ; k31 = 116
.line	1370	loadk        r14   k78 ; k78 = 75
.line	1370	loadk        r15   k57 ; k57 = 24
.line	1370	loadk        r16   k79 ; k79 = 121
.line	1370	call         r11     6     2
.line	1370	eq             0   r10   r11
.line	1370	jmp            0  l741
.line	1370	self         r10    r0  k100 ; k100 = "ClampWorkAssetString" (truncated)
.line	1370	move         r12    r9
.line	1370	call         r10     3     1
.line	1370	gettabup     r10    u0  k101 ; k101 = "SubsystemMgr"
.line	1370	self         r10   r10  k102 ; k102 = "Get"
.line	1370	getupval     r12    u1
.line	1370	loadk        r13   k47 ; k47 = 165
.line	1370	loadk        r14  k103 ; k103 = 103
.line	1370	loadk        r15   k41 ; k41 = 76
.line	1370	loadk        r16  k104 ; k104 = 21
.line	1370	loadk        r17  k105 ; k105 = 104
.line	1370	loadk        r18    k9 ; k9 = 255
.line	1370	loadk        r19  k106 ; k106 = 207
.line	1370	loadk        r20   k44 ; k44 = 41
.line	1370	loadk        r21  k107 ; k107 = 156
.line	1370	loadk        r22   k34 ; k34 = 39
.line	1370	loadk        r23  k108 ; k108 = 240
.line	1370	loadk        r24   k37 ; k37 = 173
.line	1370	loadk        r25  k109 ; k109 = 226
.line	1370	loadk        r26   k18 ; k18 = 223
.line	1370	loadk        r27   k50 ; k50 = 200
.line	1370	loadk        r28   k29 ; k29 = 229
.line	1370	loadk        r29  k110 ; k110 = 98
.line	1370	loadk        r30  k111 ; k111 = 74
.line	1370	loadk        r31  k112 ; k112 = 43
.line	1370	loadk        r32  k113 ; k113 = 23
.line	1370	loadk        r33  k114 ; k114 = 153
.line	1370	loadk        r34  k115 ; k115 = 196
.line	1370	loadk        r35  k116 ; k116 = 186
.line	1370	loadk        r36  k117 ; k117 = 5
.line	1370	loadk        r37  k118 ; k118 = 190
.line	1370	loadk        r38   k94 ; k94 = 32
.line	1370	loadk        r39   k64 ; k64 = 241
.line	1370	loadk        r40  k119 ; k119 = 191
.line	1370	call         r12    29     2
.line	1370	call         r10     3     2
.line	1370	loadbool     r11     0     0
.line	1370	gettabup     r12    u0  k120 ; k120 = "ipairs"
.line	1370	move         r13    r9
.line	1370	call         r12     2     4
.line	1370	jmp            0  l487
.line	1370	gettable     r17   r16  k121 ; k121 = "AssetType"
.line	1370	gettabup     r18    u3  k122 ; k122 = "Actor"
.line	1370	eq             0   r17   r18
.line	1370	jmp            0  l415
.line	1370	move         r17    r7
.line	1370	gettable     r18    r0  k123 ; k123 = "AssetPathMap"
.line	1370	gettable     r19   r16  k124 ; k124 = "AssetUID"
.line	1370	call         r17     3     2
.line	1370	move         r18    r7
.line	1370	move         r19    r9
.line	1370	gettable     r20   r16  k124 ; k124 = "AssetUID"
.line	1370	call         r18     3     2
.line	1370	eq             1   r17  k125 ; k125 = nil
.line	1370	jmp           16  l487
.line	1370	eq             1   r17   r18
.line	1370	jmp           16  l487
.line	1370	test         r10     0
.line	1370	jmp           16  l487
.line	1370	self         r19   r10  k126 ; k126 = "Api_RenameActor"
.line	1370	gettabup     r21    u0  k127 ; k127 = "tonumber"
.line	1370	gettable     r22   r16  k124 ; k124 = "AssetUID"
.line	1370	call         r21     2     2
.line	1370	move         r22   r18
.line	1370	closure      r23    f1
.line	1370	call         r19     5     4
.line	1370	test         r19     1
.line	1370	jmp           16  l487
.line	1370	settable     r16  k128   r17 ; k128 = "AssetName"
.line	1370	loadbool     r11     1     0
.line	1370	newtable     r22     0     4
.line	1370	getupval     r23    u1
.line	1370	loadk        r24  k130 ; k130 = 180
.line	1370	loadk        r25   k60 ; k60 = 112
.line	1370	loadk        r26  k131 ; k131 = 71
.line	1370	loadk        r27  k104 ; k104 = 21
.line	1370	loadk        r28  k132 ; k132 = 113
.line	1370	loadk        r29  k133 ; k133 = 243
.line	1370	call         r23     7     2
.line	1370	settable     r22  k129   r23 ; k129 = "Operation"
.line	1370	getupval     r23    u1
.line	1370	loadk        r24  k135 ; k135 = 167
.line	1370	loadk        r25  k136 ; k136 = 118
.line	1370	loadk        r26  k137 ; k137 = 93
.line	1370	loadk        r27  k138 ; k138 = 27
.line	1370	loadk        r28  k139 ; k139 = 110
.line	1370	call         r23     6     2
.line	1370	settable     r22  k134   r23 ; k134 = "AssetType"
.line	1370	settable     r22  k140   r20 ; k140 = "ErrorMsg"
.line	1370	settable     r22  k141   r21 ; k141 = "ErrorCode"
.line	1370	test          r4     1
.line	1370	jmp           16  l487
.line	1370	loadbool      r4     1     0
.line	1370	self         r23    r0   k58 ; k58 = "SendSaveResponse"
.line	1370	loadbool     r25     0     0
.line	1370	gettabup     r26    u2  k142 ; k142 = "encode"
.line	1370	move         r27   r22
.line	1370	call         r26     2     0
.line	1370	call         r23     0     1
.line	1370	jmp           16  l487
.line	1370	jmp           16  l487
.label	l415
.line	1370	gettable     r17   r16  k134 ; k134 = "AssetType"
.line	1370	gettabup     r18    u3  k143 ; k143 = "Effect"
.line	1370	eq             0   r17   r18
.line	1370	jmp           16  l487
.line	1370	move         r17    r7
.line	1370	gettable     r18    r0  k144 ; k144 = "AssetPathMap"
.line	1370	gettable     r19   r16  k145 ; k145 = "AssetUID"
.line	1370	call         r17     3     2
.line	1370	move         r18    r7
.line	1370	move         r19    r9
.line	1370	gettable     r20   r16  k145 ; k145 = "AssetUID"
.line	1370	call         r18     3     2
.line	1370	eq             1   r17  k125 ; k125 = nil
.line	1370	jmp           16  l487
.line	1370	eq             1   r17   r18
.line	1370	jmp           16  l487
.line	1370	gettabup     r19    u0  k101 ; k101 = "SubsystemMgr"
.line	1370	self         r19   r19  k102 ; k102 = "Get"
.line	1370	getupval     r21    u1
.line	1370	loadk        r22  k146 ; k146 = 165
.line	1370	loadk        r23  k147 ; k147 = 103
.line	1370	loadk        r24  k148 ; k148 = 76
.line	1370	loadk        r25  k104 ; k104 = 21
.line	1370	loadk        r26  k105 ; k105 = 104
.line	1370	loadk        r27  k149 ; k149 = 255
.line	1370	loadk        r28  k150 ; k150 = 207
.line	1370	loadk        r29   k44 ; k44 = 41
.line	1370	loadk        r30  k151 ; k151 = 144
.line	1370	loadk        r31  k152 ; k152 = 43
.line	1370	loadk        r32  k153 ; k153 = 224
.line	1370	loadk        r33  k135 ; k135 = 167
.line	1370	loadk        r34  k154 ; k154 = 192
.line	1370	loadk        r35  k155 ; k155 = 251
.line	1370	loadk        r36  k156 ; k156 = 222
.line	1370	loadk        r37  k157 ; k157 = 248
.line	1370	loadk        r38   k72 ; k72 = 127
.line	1370	loadk        r39   k93 ; k93 = 70
.line	1370	loadk        r40  k158 ; k158 = 53
.line	1370	loadk        r41   k88 ; k88 = 33
.line	1370	loadk        r42  k159 ; k159 = 191
.line	1370	loadk        r43  k160 ; k160 = 223
.line	1370	loadk        r44  k116 ; k116 = 186
.line	1370	loadk        r45  k161 ; k161 = 8
.line	1370	loadk        r46  k162 ; k162 = 168
.line	1370	loadk        r47  k163 ; k163 = 57
.line	1370	loadk        r48  k164 ; k164 = 199
.line	1370	loadk        r49  k135 ; k135 = 167
.line	1370	loadk        r50  k165 ; k165 = 226
.line	1370	loadk        r51  k166 ; k166 = 217
.line	1370	loadk        r52  k167 ; k167 = 197
.line	1370	loadk        r53  k168 ; k168 = 239
.line	1370	loadk        r54  k169 ; k169 = 114
.line	1370	loadk        r55  k170 ; k170 = 80
.line	1370	loadk        r56  k171 ; k171 = 36
.line	1370	call         r21    36     2
.line	1370	call         r19     3     2
.line	1370	test         r19     0
.line	1370	jmp           16  l487
.line	1370	gettabup     r20    u0  k127 ; k127 = "tonumber"
.line	1370	gettable     r21   r16  k145 ; k145 = "AssetUID"
.line	1370	call         r20     2     2
.line	1370	self         r21   r19  k172 ; k172 = "GetCustomParticleCon" (truncated)
.line	1370	move         r23   r20
.line	1370	call         r21     3     2
.line	1370	test         r21     0
.line	1370	jmp           16  l487
.line	1370	settable     r21  k173   r18 ; k173 = "ParticleName"
.line	1370	self         r22   r19  k174 ; k174 = "SetCustomParticleCon" (truncated)
.line	1370	move         r24   r21
.line	1370	loadbool     r25     1     0
.line	1370	call         r22     4     1
.line	1370	jmp           16  l487
.label	l487
.line	1370	move          r0    r0
.line	1370	move          r0    r0
.line	1370	newtable     r12     0     0
.line	1370	gettabup     r13    u0  k175 ; k175 = "ipairs"
.line	1370	move         r14    r9
.line	1370	call         r13     2     4
.line	1370	jmp            0  l498
.line	1370	gettabup     r18    u0  k176 ; k176 = "tostring"
.line	1370	gettable     r19   r17  k145 ; k145 = "AssetUID"
.line	1370	call         r18     2     2
.line	1370	settable     r12   r18  k177 ; k177 = true
.label	l498
.line	1370	move          r0    r0
.line	1370	move          r0    r0
.line	1370	gettabup     r13    u0  k178 ; k178 = "GetCreativeActorData" (truncated)
.line	1370	call         r13     1     2
.line	1370	gettabup     r14    u0  k101 ; k101 = "SubsystemMgr"
.line	1370	self         r14   r14  k102 ; k102 = "Get"
.line	1370	getupval     r16    u1
.line	1370	loadk        r17  k146 ; k146 = 165
.line	1370	loadk        r18  k147 ; k147 = 103
.line	1370	loadk        r19  k148 ; k148 = 76
.line	1370	loadk        r20  k104 ; k104 = 21
.line	1370	loadk        r21  k105 ; k105 = 104
.line	1370	loadk        r22  k149 ; k149 = 255
.line	1370	loadk        r23  k150 ; k150 = 207
.line	1370	loadk        r24   k44 ; k44 = 41
.line	1370	loadk        r25  k151 ; k151 = 144
.line	1370	loadk        r26  k152 ; k152 = 43
.line	1370	loadk        r27  k153 ; k153 = 224
.line	1370	loadk        r28  k135 ; k135 = 167
.line	1370	loadk        r29  k154 ; k154 = 192
.line	1370	loadk        r30  k155 ; k155 = 251
.line	1370	loadk        r31  k156 ; k156 = 222
.line	1370	loadk        r32  k157 ; k157 = 248
.line	1370	loadk        r33   k72 ; k72 = 127
.line	1370	loadk        r34   k93 ; k93 = 70
.line	1370	loadk        r35  k158 ; k158 = 53
.line	1370	loadk        r36   k88 ; k88 = 33
.line	1370	loadk        r37  k159 ; k159 = 191
.line	1370	loadk        r38  k160 ; k160 = 223
.line	1370	loadk        r39  k116 ; k116 = 186
.line	1370	loadk        r40  k161 ; k161 = 8
.line	1370	loadk        r41  k162 ; k162 = 168
.line	1370	loadk        r42  k163 ; k163 = 57
.line	1370	loadk        r43  k164 ; k164 = 199
.line	1370	loadk        r44  k135 ; k135 = 167
.line	1370	loadk        r45  k165 ; k165 = 226
.line	1370	loadk        r46  k166 ; k166 = 217
.line	1370	loadk        r47  k167 ; k167 = 197
.line	1370	loadk        r48  k168 ; k168 = 239
.line	1370	loadk        r49  k169 ; k169 = 114
.line	1370	loadk        r50  k170 ; k170 = 80
.line	1370	loadk        r51  k171 ; k171 = 36
.line	1370	call         r16    36     2
.line	1370	call         r14     3     2
.line	1370	gettabup     r15    u0  k175 ; k175 = "ipairs"
.line	1370	gettable     r16    r0  k144 ; k144 = "AssetPathMap"
.line	1370	call         r15     2     4
.line	1370	jmp            0  l710
.line	1370	gettabup     r20    u0  k176 ; k176 = "tostring"
.line	1370	gettable     r21   r19  k145 ; k145 = "AssetUID"
.line	1370	call         r20     2     2
.line	1370	gettable     r21   r12   r20
.line	1370	test         r21     1
.line	1370	jmp            0  l710
.line	1370	loadbool     r21     1     0
.line	1370	gettable     r22   r19  k134 ; k134 = "AssetType"
.line	1370	gettabup     r23    u3  k179 ; k179 = "Actor"
.line	1370	eq             0   r22   r23
.line	1370	jmp            0  l576
.line	1370	eq             1   r13  k125 ; k125 = nil
.line	1370	jmp            0  l573
.line	1370	self         r22   r13  k180 ; k180 = "IsValidActorID"
.line	1370	gettabup     r24    u0  k127 ; k127 = "tonumber"
.line	1370	move         r25   r20
.line	1370	call         r24     2     0
.line	1370	call         r22     0     2
.line	1370	testset      r21   r22     0
.line	1370	jmp            0  l575
.line	1370	gettable     r22    r0  k181 ; k181 = "UnloadingAssetIds"
.line	1370	test         r22     0
.line	1370	jmp            0  l574
.line	1370	gettable     r22    r0  k181 ; k181 = "UnloadingAssetIds"
.line	1370	gettable     r22   r22   r20
.line	1370	not          r21   r22
.line	1370	jmp            0  l591
.label	l573
.line	1370	loadbool     r21     0     1
.label	l574
.line	1370	loadbool     r21     1     0
.label	l575
.line	1370	jmp            0  l591
.label	l576
.line	1370	gettable     r22   r19  k134 ; k134 = "AssetType"
.line	1370	gettabup     r23    u3  k143 ; k143 = "Effect"
.line	1370	eq             0   r22   r23
.line	1370	jmp            0  l591
.line	1370	eq             1   r14  k125 ; k125 = nil
.line	1370	jmp            0  l589
.line	1370	self         r22   r14  k172 ; k172 = "GetCustomParticleCon" (truncated)
.line	1370	gettabup     r24    u0  k127 ; k127 = "tonumber"
.line	1370	move         r25   r20
.line	1370	call         r24     2     0
.line	1370	call         r22     0     2
.line	1370	eq             0   r22  k125 ; k125 = nil
.line	1370	jmp            0  l590
.label	l589
.line	1370	loadbool     r21     0     1
.label	l590
.line	1370	loadbool     r21     1     0
.label	l591
.line	1370	test         r21     0
.line	1370	jmp            0  l710
.line	1370	gettabup     r22    u0  k182 ; k182 = "table"
.line	1370	gettable     r22   r22  k183 ; k183 = "insert"
.line	1370	move         r23    r9
.line	1370	move         r24   r19
.line	1370	call         r22     3     1
.line	1370	settable     r12   r20  k177 ; k177 = true
.line	1370	gettable     r22   r19  k134 ; k134 = "AssetType"
.line	1370	gettabup     r23    u3  k179 ; k179 = "Actor"
.line	1370	eq             1   r22   r23
.line	1370	jmp            0  l607
.line	1370	gettable     r22   r19  k134 ; k134 = "AssetType"
.line	1370	gettabup     r23    u3  k143 ; k143 = "Effect"
.line	1370	eq             0   r22   r23
.line	1370	jmp            0  l710
.label	l607
.line	1370	gettabup     r22    u0    k0 ; k0 = "print"
.line	1370	gettabup     r23    u0    k1 ; k1 = "bWriteLog"
.line	1370	test         r23     0
.line	1370	jmp            0  l708
.line	1370	gettabup     r23    u0  k182 ; k182 = "table"
.line	1370	gettable     r23   r23  k184 ; k184 = "concat"
.line	1370	newtable     r24     2     0
.line	1370	getupval     r25    u1
.line	1370	loadk        r26  k185 ; k185 = 177
.line	1370	loadk        r27  k186 ; k186 = 122
.line	1370	loadk        r28  k187 ; k187 = 126
.line	1370	loadk        r29  k188 ; k188 = 49
.line	1370	loadk        r30  k189 ; k189 = 120
.line	1370	loadk        r31  k149 ; k149 = 255
.line	1370	loadk        r32  k190 ; k190 = 205
.line	1370	loadk        r33  k191 ; k191 = 35
.line	1370	loadk        r34  k192 ; k192 = 175
.line	1370	loadk        r35  k193 ; k193 = 19
.line	1370	loadk        r36  k194 ; k194 = 235
.line	1370	loadk        r37  k195 ; k195 = 176
.line	1370	loadk        r38  k155 ; k155 = 251
.line	1370	loadk        r39  k196 ; k196 = 219
.line	1370	loadk        r40  k160 ; k160 = 223
.line	1370	loadk        r41  k149 ; k149 = 255
.line	1370	loadk        r42  k197 ; k197 = 115
.line	1370	loadk        r43  k198 ; k198 = 81
.line	1370	loadk        r44  k199 ; k199 = 10
.line	1370	loadk        r45  k188 ; k188 = 49
.line	1370	loadk        r46  k200 ; k200 = 142
.line	1370	loadk        r47  k194 ; k194 = 235
.line	1370	loadk        r48  k201 ; k201 = 174
.line	1370	loadk        r49  k202 ; k202 = 14
.line	1370	loadk        r50  k203 ; k203 = 247
.line	1370	loadk        r51  k138 ; k138 = 27
.line	1370	loadk        r52  k204 ; k204 = 250
.line	1370	loadk        r53  k205 ; k205 = 128
.line	1370	loadk        r54  k206 ; k206 = 229
.line	1370	loadk        r55  k155 ; k155 = 251
.line	1370	loadk        r56  k194 ; k194 = 235
.line	1370	loadk        r57  k133 ; k133 = 243
.line	1370	loadk        r58  k207 ; k207 = 116
.line	1370	loadk        r59  k208 ; k208 = 94
.line	1370	loadk        r60  k161 ; k161 = 8
.line	1370	loadk        r61  k209 ; k209 = 39
.line	1370	loadk        r62  k210 ; k210 = 143
.line	1370	loadk        r63  k211 ; k211 = 211
.line	1370	loadk        r64  k212 ; k212 = 173
.line	1370	loadk        r65  k213 ; k213 = 63
.line	1370	call         r25    41     2
.line	1370	getupval     r26    u1
.line	1370	loadk        r27  k214 ; k214 = 135
.line	1370	loadk        r28  k215 ; k215 = 99
.line	1370	loadk        r29  k148 ; k148 = 76
.line	1370	loadk        r30  k216 ; k216 = 84
.line	1370	loadk        r31  k188 ; k188 = 49
.line	1370	loadk        r32  k217 ; k217 = 182
.line	1370	loadk        r33   k48 ; k48 = 210
.line	1370	loadk        r34   k44 ; k44 = 41
.line	1370	loadk        r35   k87 ; k87 = 184
.line	1370	loadk        r36  k218 ; k218 = 52
.line	1370	loadk        r37  k219 ; k219 = 164
.line	1370	loadk        r38  k220 ; k220 = 163
.line	1370	loadk        r39  k221 ; k221 = 227
.line	1370	loadk        r40  k222 ; k222 = 233
.line	1370	loadk        r41  k223 ; k223 = 201
.line	1370	loadk        r42  k157 ; k157 = 248
.line	1370	loadk        r43   k51 ; k51 = 54
.line	1370	loadk        r44  k224 ; k224 = 72
.line	1370	loadk        r45  k225 ; k225 = 48
.line	1370	loadk        r46   k52 ; k52 = 55
.line	1370	loadk        r47  k226 ; k226 = 159
.line	1370	loadk        r48  k150 ; k150 = 207
.line	1370	loadk        r49  k135 ; k135 = 167
.line	1370	loadk        r50  k138 ; k138 = 27
.line	1370	loadk        r51  k227 ; k227 = 237
.line	1370	loadk        r52   k66 ; k66 = 61
.line	1370	loadk        r53  k204 ; k204 = 250
.line	1370	loadk        r54  k228 ; k228 = 242
.line	1370	loadk        r55  k206 ; k206 = 229
.line	1370	loadk        r56  k229 ; k229 = 238
.line	1370	loadk        r57  k230 ; k230 = 213
.line	1370	loadk        r58  k231 ; k231 = 232
.line	1370	loadk        r59  k232 ; k232 = 105
.line	1370	loadk        r60  k131 ; k131 = 71
.line	1370	loadk        r61  k232 ; k232 = 105
.line	1370	loadk        r62  k209 ; k209 = 39
.line	1370	loadk        r63   k77 ; k77 = 146
.line	1370	loadk        r64  k233 ; k233 = 215
.line	1370	loadk        r65  k234 ; k234 = 169
.line	1370	loadk        r66  k235 ; k235 = 31
.line	1370	call         r26    41     2
.line	1370	getupval     r27    u1
.line	1370	loadk        r28  k200 ; k200 = 142
.line	1370	loadk        r29  k186 ; k186 = 122
.line	1370	loadk        r30  k137 ; k137 = 93
.line	1370	loadk        r31  k216 ; k216 = 84
.line	1370	call         r27     5     0
.line	1370	setlist      r24     0     1
.line	1370	call         r23     2     2
.line	1370	move         r24   r20
.line	1370	concat       r23   r23   r24
.label	l708
.line	1370	call         r22     2     1
.line	1370	loadbool     r11     1     0
.label	l710
.line	1370	move          r0    r0
.line	1370	move          r0    r0
.line	1370	gettable     r15    r0  k236 ; k236 = "ImportingAssetMap"
.line	1370	test         r15     0
.line	1370	jmp            0  l732
.line	1370	gettabup     r15    u0  k175 ; k175 = "ipairs"
.line	1370	move         r16    r9
.line	1370	call         r15     2     4
.line	1370	jmp            0  l730
.line	1370	gettabup     r20    u0  k127 ; k127 = "tonumber"
.line	1370	gettable     r21   r19  k145 ; k145 = "AssetUID"
.line	1370	call         r20     2     2
.line	1370	test         r20     0
.line	1370	jmp            0  l730
.line	1370	gettable     r21    r0  k236 ; k236 = "ImportingAssetMap"
.line	1370	gettable     r21   r21   r20
.line	1370	test         r21     0
.line	1370	jmp            0  l730
.line	1370	gettable     r21    r0  k236 ; k236 = "ImportingAssetMap"
.line	1370	settable     r21   r20  k125 ; k125 = nil
.label	l730
.line	1370	move          r0    r0
.line	1370	move          r0    r0
.label	l732
.line	1370	settable      r0  k144    r9 ; k144 = "AssetPathMap"
.line	1370	self         r15    r0  k237 ; k237 = "SaveAssetPathMap"
.line	1370	call         r15     2     1
.line	1370	test         r11     0
.line	1370	jmp           11  l907
.line	1370	self         r15    r0  k238 ; k238 = "SyncWorkAssetDataToE" (truncated)
.line	1370	call         r15     2     1
.line	1370	jmp           11  l907
.line	1370	jmp            0  l907
.label	l741
.line	1370	loadbool      r2     0     0
.line	1370	getupval     r10    u1
.line	1370	call         r10     1     2
.line	1370	eq             1    r3   r10
.line	1370	jmp            0  l784
.line	1370	move         r10    r3
.line	1370	getupval     r11    u1
.line	1370	loadk        r12  k239 ; k239 = 221
.line	1370	loadk        r13  k158 ; k158 = 53
.line	1370	loadk        r14  k105 ; k105 = 104
.line	1370	loadk        r15  k240 ; k240 = 7
.line	1370	loadk        r16   k63 ; k63 = 111
.line	1370	loadk        r17  k133 ; k133 = 243
.line	1370	loadk        r18  k190 ; k190 = 205
.line	1370	loadk        r19  k241 ; k241 = 28
.line	1370	loadk        r20  k242 ; k242 = 188
.line	1370	loadk        r21  k225 ; k225 = 48
.line	1370	loadk        r22   k70 ; k70 = 236
.line	1370	loadk        r23  k210 ; k210 = 143
.line	1370	loadk        r24   k64 ; k64 = 241
.line	1370	loadk        r25  k243 ; k243 = 234
.line	1370	loadk        r26  k244 ; k244 = 230
.line	1370	loadk        r27  k149 ; k149 = 255
.line	1370	loadk        r28  k245 ; k245 = 121
.line	1370	loadk        r29   k78 ; k78 = 75
.line	1370	loadk        r30  k245 ; k245 = 121
.line	1370	loadk        r31   k94 ; k94 = 32
.line	1370	loadk        r32   k95 ; k95 = 137
.line	1370	loadk        r33  k167 ; k167 = 197
.line	1370	loadk        r34  k246 ; k246 = 166
.line	1370	loadk        r35   k57 ; k57 = 24
.line	1370	loadk        r36  k162 ; k162 = 168
.line	1370	loadk        r37  k207 ; k207 = 116
.line	1370	loadk        r38  k228 ; k228 = 242
.line	1370	loadk        r39  k247 ; k247 = 179
.line	1370	loadk        r40  k222 ; k222 = 233
.line	1370	loadk        r41  k244 ; k244 = 230
.line	1370	loadk        r42  k166 ; k166 = 217
.line	1370	loadk        r43  k157 ; k157 = 248
.line	1370	call         r11    33     2
.line	1370	concat       r10   r10   r11
.line	1370	testset       r3   r10     1
.line	1370	jmp            0  l817
.label	l784
.line	1370	getupval     r10    u1
.line	1370	loadk        r11  k135 ; k135 = 167
.line	1370	loadk        r12  k248 ; k248 = 102
.line	1370	loadk        r13  k249 ; k249 = 90
.line	1370	loadk        r14  k250 ; k250 = 17
.line	1370	loadk        r15  k105 ; k105 = 104
.line	1370	loadk        r16  k251 ; k251 = 198
.line	1370	loadk        r17  k252 ; k252 = 216
.line	1370	loadk        r18   k98 ; k98 = 56
.line	1370	loadk        r19  k253 ; k253 = 181
.line	1370	loadk        r20   k46 ; k46 = 9
.line	1370	loadk        r21  k206 ; k206 = 229
.line	1370	loadk        r22  k254 ; k254 = 178
.line	1370	loadk        r23  k255 ; k255 = 218
.line	1370	loadk        r24  k222 ; k222 = 233
.line	1370	loadk        r25  k256 ; k256 = 195
.line	1370	loadk        r26  k165 ; k165 = 226
.line	1370	loadk        r27   k51 ; k51 = 54
.line	1370	loadk        r28   k73 ; k73 = 65
.line	1370	loadk        r29  k257 ; k257 = 60
.line	1370	loadk        r30  k209 ; k209 = 39
.line	1370	loadk        r31  k258 ; k258 = 131
.line	1370	loadk        r32  k259 ; k259 = 194
.line	1370	loadk        r33   k45 ; k45 = 172
.line	1370	loadk        r34  k260 ; k260 = 92
.line	1370	loadk        r35   k68 ; k68 = 171
.line	1370	loadk        r36  k158 ; k158 = 53
.line	1370	loadk        r37  k261 ; k261 = 253
.line	1370	loadk        r38  k118 ; k118 = 190
.line	1370	loadk        r39  k206 ; k206 = 229
.line	1370	loadk        r40  k229 ; k229 = 238
.line	1370	call         r10    31     2
.line	1370	move          r3   r10
.label	l817
.line	1370	gettabup     r10    u0    k0 ; k0 = "print"
.line	1370	gettabup     r11    u0    k1 ; k1 = "bWriteLog"
.line	1370	test         r11     0
.line	1370	jmp            0  l906
.line	1370	gettabup     r11    u0  k182 ; k182 = "table"
.line	1370	gettable     r11   r11  k184 ; k184 = "concat"
.line	1370	newtable     r12     1     0
.line	1370	getupval     r13    u1
.line	1370	loadk        r14  k185 ; k185 = 177
.line	1370	loadk        r15  k186 ; k186 = 122
.line	1370	loadk        r16  k187 ; k187 = 126
.line	1370	loadk        r17  k188 ; k188 = 49
.line	1370	loadk        r18  k189 ; k189 = 120
.line	1370	loadk        r19  k149 ; k149 = 255
.line	1370	loadk        r20  k190 ; k190 = 205
.line	1370	loadk        r21  k191 ; k191 = 35
.line	1370	loadk        r22  k192 ; k192 = 175
.line	1370	loadk        r23  k193 ; k193 = 19
.line	1370	loadk        r24  k194 ; k194 = 235
.line	1370	loadk        r25  k195 ; k195 = 176
.line	1370	loadk        r26  k155 ; k155 = 251
.line	1370	loadk        r27  k196 ; k196 = 219
.line	1370	loadk        r28  k160 ; k160 = 223
.line	1370	loadk        r29  k149 ; k149 = 255
.line	1370	loadk        r30  k197 ; k197 = 115
.line	1370	loadk        r31  k198 ; k198 = 81
.line	1370	loadk        r32  k199 ; k199 = 10
.line	1370	loadk        r33  k188 ; k188 = 49
.line	1370	loadk        r34  k200 ; k200 = 142
.line	1370	loadk        r35  k194 ; k194 = 235
.line	1370	loadk        r36  k201 ; k201 = 174
.line	1370	loadk        r37  k202 ; k202 = 14
.line	1370	loadk        r38  k203 ; k203 = 247
.line	1370	loadk        r39  k138 ; k138 = 27
.line	1370	loadk        r40  k204 ; k204 = 250
.line	1370	loadk        r41  k205 ; k205 = 128
.line	1370	loadk        r42  k206 ; k206 = 229
.line	1370	loadk        r43  k155 ; k155 = 251
.line	1370	loadk        r44  k194 ; k194 = 235
.line	1370	loadk        r45  k133 ; k133 = 243
.line	1370	loadk        r46  k207 ; k207 = 116
.line	1370	loadk        r47  k208 ; k208 = 94
.line	1370	loadk        r48  k161 ; k161 = 8
.line	1370	loadk        r49  k209 ; k209 = 39
.line	1370	loadk        r50  k210 ; k210 = 143
.line	1370	loadk        r51  k211 ; k211 = 211
.line	1370	loadk        r52  k212 ; k212 = 173
.line	1370	loadk        r53  k213 ; k213 = 63
.line	1370	call         r13    41     2
.line	1370	getupval     r14    u1
.line	1370	loadk        r15  k214 ; k214 = 135
.line	1370	loadk        r16  k215 ; k215 = 99
.line	1370	loadk        r17  k148 ; k148 = 76
.line	1370	loadk        r18  k216 ; k216 = 84
.line	1370	loadk        r19  k188 ; k188 = 49
.line	1370	loadk        r20  k217 ; k217 = 182
.line	1370	loadk        r21  k157 ; k157 = 248
.line	1370	loadk        r22  k213 ; k213 = 63
.line	1370	loadk        r23  k201 ; k201 = 174
.line	1370	loadk        r24   k88 ; k88 = 33
.line	1370	loadk        r25  k108 ; k108 = 240
.line	1370	loadk        r26   k77 ; k77 = 146
.line	1370	loadk        r27   k64 ; k64 = 241
.line	1370	loadk        r28  k229 ; k229 = 238
.line	1370	loadk        r29  k115 ; k115 = 196
.line	1370	loadk        r30  k262 ; k262 = 193
.line	1370	loadk        r31  k263 ; k263 = 119
.line	1370	loadk        r32  k264 ; k264 = 85
.line	1370	loadk        r33  k193 ; k193 = 19
.line	1370	loadk        r34   k52 ; k52 = 55
.line	1370	loadk        r35  k258 ; k258 = 131
.line	1370	loadk        r36   k50 ; k50 = 200
.line	1370	loadk        r37  k222 ; k222 = 233
.line	1370	loadk        r38   k57 ; k57 = 24
.line	1370	loadk        r39  k162 ; k162 = 168
.line	1370	loadk        r40   k52 ; k52 = 55
.line	1370	loadk        r41  k155 ; k155 = 251
.line	1370	loadk        r42  k217 ; k217 = 182
.line	1370	loadk        r43  k206 ; k206 = 229
.line	1370	loadk        r44  k265 ; k265 = 170
.line	1370	loadk        r45  k255 ; k255 = 218
.line	1370	loadk        r46  k261 ; k261 = 253
.line	1370	loadk        r47   k63 ; k63 = 111
.line	1370	loadk        r48  k266 ; k266 = 89
.line	1370	loadk        r49  k267 ; k267 = 44
.line	1370	loadk        r50  k225 ; k225 = 48
.line	1370	call         r14    37     0
.line	1370	setlist      r12     0     1
.line	1370	call         r11     2     2
.label	l906
.line	1370	call         r10     2     1
.label	l907
.line	1370	loadbool      r5     1     0
.line	1370	test          r4     1
.line	1370	jmp            0  l914
.line	1370	self          r9    r0   k58 ; k58 = "SendSaveResponse"
.line	1370	move         r11    r2
.line	1370	move         r12    r3
.line	1370	call          r9     4     1
.label	l914
.line	1370	return        r0     1
.line	1370	gettabup      r1    u0  k242 ; k242 = 188
.line	1370	move          r0    r0
.line	1370	return        r0     1

.function	main/f41/f0

.source	null
.linedefined	1393
.lastlinedefined	1400
.numparams	2
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false

.constant	k0	"ipairs"
.constant	k1	"AssetUID"
.constant	k2	"AssetName"

.line	1393	gettabup      r2    u0    k0 ; k0 = "ipairs"
.line	1393	move          r3    r0
.line	1393	call          r2     2     4
.line	1393	jmp            0   l10
.line	1393	gettable      r7    r6    k1 ; k1 = "AssetUID"
.line	1393	eq             0    r7    r1
.line	1393	jmp            0   l10
.line	1393	gettable      r7    r6    k2 ; k2 = "AssetName"
.line	1393	return        r7     2
.label	l10
.line	1393	move          r0    r0
.line	1393	move          r0    r0
.line	1393	loadnil       r2     0
.line	1393	return        r2     2
.line	1393	return        r0     1
.line	1393	move          r0    r0
.line	1393	move          r0    r0
.line	1393	return        r0     1

.function	main/f41/f1

.source	null
.linedefined	1414
.lastlinedefined	1432
.numparams	3
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	16	true
.upvalue	"U3"	18	true
.upvalue	"U4"	17	true
.upvalue	"U5"	5	true
.upvalue	"U6"	11	true
.upvalue	"U7"	0	true
.upvalue	"U8"	3	false

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	177
.constant	k7	122
.constant	k8	126
.constant	k9	49
.constant	k10	120
.constant	k11	255
.constant	k12	205
.constant	k13	35
.constant	k14	175
.constant	k15	19
.constant	k16	235
.constant	k17	176
.constant	k18	251
.constant	k19	219
.constant	k20	223
.constant	k21	115
.constant	k22	81
.constant	k23	10
.constant	k24	142
.constant	k25	174
.constant	k26	14
.constant	k27	247
.constant	k28	27
.constant	k29	250
.constant	k30	128
.constant	k31	229
.constant	k32	243
.constant	k33	116
.constant	k34	94
.constant	k35	8
.constant	k36	39
.constant	k37	143
.constant	k38	211
.constant	k39	173
.constant	k40	63
.constant	k41	135
.constant	k42	99
.constant	k43	76
.constant	k44	84
.constant	k45	182
.constant	k46	216
.constant	k47	164
.constant	k48	42
.constant	k49	231
.constant	k50	226
.constant	k51	194
.constant	k52	237
.constant	k53	123
.constant	k54	64
.constant	k55	121
.constant	k56	34
.constant	k57	141
.constant	k58	207
.constant	k59	165
.constant	k60	25
.constant	k61	169
.constant	k62	180
.constant	k63	147
.constant	k64	249
.constant	k65	217
.constant	k66	232
.constant	k67	83
.constant	k68	124
.constant	k69	13
.constant	k70	110
.constant	k71	197
.constant	k72	245
.constant	k73	163
.constant	k74	103
.constant	k75	91
.constant	k76	78
.constant	k77	57
.constant	k78	149
.constant	k79	108
.constant	k80	158
.constant	k81	43
.constant	k82	224
.constant	k83	167
.constant	k84	170
.constant	k85	191
.constant	k86	"tostring"
.constant	k87	"AssetUID"
.constant	k88	"AssetName"
.constant	k89	"ipairs"
.constant	k90	"AssetPathMap"
.constant	k91	"AssetType"
.constant	k92	"Actor"
.constant	k93	"SaveAssetPathMap"
.constant	k94	"SyncWorkAssetDataToEditor"

.line	1414	test          r0     1
.line	1414	jmp            0  l171
.line	1414	gettabup      r3    u0    k0 ; k0 = "print"
.line	1414	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	1414	test          r4     0
.line	1414	jmp            0  l125
.line	1414	gettabup      r4    u0    k2 ; k2 = "string"
.line	1414	gettable      r4    r4    k3 ; k3 = "format"
.line	1414	gettabup      r5    u0    k4 ; k4 = "table"
.line	1414	gettable      r5    r5    k5 ; k5 = "concat"
.line	1414	newtable      r6     2     0
.line	1414	getupval      r7    u1
.line	1414	loadk         r8    k6 ; k6 = 177
.line	1414	loadk         r9    k7 ; k7 = 122
.line	1414	loadk        r10    k8 ; k8 = 126
.line	1414	loadk        r11    k9 ; k9 = 49
.line	1414	loadk        r12   k10 ; k10 = 120
.line	1414	loadk        r13   k11 ; k11 = 255
.line	1414	loadk        r14   k12 ; k12 = 205
.line	1414	loadk        r15   k13 ; k13 = 35
.line	1414	loadk        r16   k14 ; k14 = 175
.line	1414	loadk        r17   k15 ; k15 = 19
.line	1414	loadk        r18   k16 ; k16 = 235
.line	1414	loadk        r19   k17 ; k17 = 176
.line	1414	loadk        r20   k18 ; k18 = 251
.line	1414	loadk        r21   k19 ; k19 = 219
.line	1414	loadk        r22   k20 ; k20 = 223
.line	1414	loadk        r23   k11 ; k11 = 255
.line	1414	loadk        r24   k21 ; k21 = 115
.line	1414	loadk        r25   k22 ; k22 = 81
.line	1414	loadk        r26   k23 ; k23 = 10
.line	1414	loadk        r27    k9 ; k9 = 49
.line	1414	loadk        r28   k24 ; k24 = 142
.line	1414	loadk        r29   k16 ; k16 = 235
.line	1414	loadk        r30   k25 ; k25 = 174
.line	1414	loadk        r31   k26 ; k26 = 14
.line	1414	loadk        r32   k27 ; k27 = 247
.line	1414	loadk        r33   k28 ; k28 = 27
.line	1414	loadk        r34   k29 ; k29 = 250
.line	1414	loadk        r35   k30 ; k30 = 128
.line	1414	loadk        r36   k31 ; k31 = 229
.line	1414	loadk        r37   k18 ; k18 = 251
.line	1414	loadk        r38   k16 ; k16 = 235
.line	1414	loadk        r39   k32 ; k32 = 243
.line	1414	loadk        r40   k33 ; k33 = 116
.line	1414	loadk        r41   k34 ; k34 = 94
.line	1414	loadk        r42   k35 ; k35 = 8
.line	1414	loadk        r43   k36 ; k36 = 39
.line	1414	loadk        r44   k37 ; k37 = 143
.line	1414	loadk        r45   k38 ; k38 = 211
.line	1414	loadk        r46   k39 ; k39 = 173
.line	1414	loadk        r47   k40 ; k40 = 63
.line	1414	call          r7    41     2
.line	1414	getupval      r8    u1
.line	1414	loadk         r9   k41 ; k41 = 135
.line	1414	loadk        r10   k42 ; k42 = 99
.line	1414	loadk        r11   k43 ; k43 = 76
.line	1414	loadk        r12   k44 ; k44 = 84
.line	1414	loadk        r13    k9 ; k9 = 49
.line	1414	loadk        r14   k45 ; k45 = 182
.line	1414	loadk        r15   k46 ; k46 = 216
.line	1414	loadk        r16   k40 ; k40 = 63
.line	1414	loadk        r17   k47 ; k47 = 164
.line	1414	loadk        r18   k48 ; k48 = 42
.line	1414	loadk        r19   k49 ; k49 = 231
.line	1414	loadk        r20   k50 ; k50 = 226
.line	1414	loadk        r21   k50 ; k50 = 226
.line	1414	loadk        r22   k11 ; k11 = 255
.line	1414	loadk        r23   k51 ; k51 = 194
.line	1414	loadk        r24   k52 ; k52 = 237
.line	1414	loadk        r25   k53 ; k53 = 123
.line	1414	loadk        r26   k54 ; k54 = 64
.line	1414	loadk        r27   k55 ; k55 = 121
.line	1414	loadk        r28   k56 ; k56 = 34
.line	1414	loadk        r29   k57 ; k57 = 141
.line	1414	loadk        r30   k58 ; k58 = 207
.line	1414	loadk        r31   k59 ; k59 = 165
.line	1414	loadk        r32   k60 ; k60 = 25
.line	1414	loadk        r33   k61 ; k61 = 169
.line	1414	loadk        r34   k10 ; k10 = 120
.line	1414	loadk        r35   k62 ; k62 = 180
.line	1414	loadk        r36   k63 ; k63 = 147
.line	1414	loadk        r37   k32 ; k32 = 243
.line	1414	loadk        r38   k64 ; k64 = 249
.line	1414	loadk        r39   k65 ; k65 = 217
.line	1414	loadk        r40   k66 ; k66 = 232
.line	1414	loadk        r41   k67 ; k67 = 83
.line	1414	loadk        r42   k68 ; k68 = 124
.line	1414	loadk        r43   k69 ; k69 = 13
.line	1414	loadk        r44   k70 ; k70 = 110
.line	1414	loadk        r45   k65 ; k65 = 217
.line	1414	loadk        r46   k71 ; k71 = 197
.line	1414	loadk        r47   k72 ; k72 = 245
.line	1414	loadk        r48   k43 ; k43 = 76
.line	1414	call          r8    41     2
.line	1414	getupval      r9    u1
.line	1414	loadk        r10   k73 ; k73 = 163
.line	1414	loadk        r11   k74 ; k74 = 103
.line	1414	loadk        r12   k75 ; k75 = 91
.line	1414	loadk        r13   k76 ; k76 = 78
.line	1414	loadk        r14   k77 ; k77 = 57
.line	1414	loadk        r15   k31 ; k31 = 229
.line	1414	loadk        r16   k78 ; k78 = 149
.line	1414	loadk        r17   k79 ; k79 = 108
.line	1414	loadk        r18   k80 ; k80 = 158
.line	1414	loadk        r19   k81 ; k81 = 43
.line	1414	loadk        r20   k82 ; k82 = 224
.line	1414	loadk        r21   k83 ; k83 = 167
.line	1414	loadk        r22   k84 ; k84 = 170
.line	1414	loadk        r23   k85 ; k85 = 191
.line	1414	loadk        r24   k20 ; k20 = 223
.line	1414	call          r9    16     0
.line	1414	setlist       r6     0     1
.line	1414	call          r5     2     2
.line	1414	gettabup      r6    u0   k86 ; k86 = "tostring"
.line	1414	gettabup      r7    u2   k87 ; k87 = "AssetUID"
.line	1414	call          r6     2     2
.line	1414	gettabup      r7    u0   k86 ; k86 = "tostring"
.line	1414	move          r8    r1
.line	1414	call          r7     2     2
.line	1414	gettabup      r8    u0   k86 ; k86 = "tostring"
.line	1414	move          r9    r2
.line	1414	call          r8     2     0
.line	1414	call          r4     0     2
.label	l125
.line	1414	call          r3     2     1
.line	1414	gettabup      r3    u2   k88 ; k88 = "AssetName"
.line	1414	getupval      r4    u3
.line	1414	eq             0    r3    r4
.line	1414	jmp            0  l132
.line	1414	getupval      r3    u4
.line	1414	settabup      u2   k88    r3 ; k88 = "AssetName"
.label	l132
.line	1414	getupval      r3    u5
.line	1414	test          r3     1
.line	1414	jmp            0  l138
.line	1414	loadbool      r3     1     0
.line	1414	setupval      r3    u6
.line	1414	return        r0     1
.label	l138
.line	1414	gettabup      r3    u0   k89 ; k89 = "ipairs"
.line	1414	gettabup      r4    u7   k90 ; k90 = "AssetPathMap"
.line	1414	test          r4     1
.line	1414	jmp            0  l143
.line	1414	newtable      r4     0     0
.label	l143
.line	1414	call          r3     2     4
.line	1414	jmp            0  l163
.line	1414	gettable      r8    r7   k91 ; k91 = "AssetType"
.line	1414	gettabup      r9    u8   k92 ; k92 = "Actor"
.line	1414	eq             0    r8    r9
.line	1414	jmp            0  l163
.line	1414	gettabup      r8    u0   k86 ; k86 = "tostring"
.line	1414	gettable      r9    r7   k87 ; k87 = "AssetUID"
.line	1414	call          r8     2     2
.line	1414	gettabup      r9    u0   k86 ; k86 = "tostring"
.line	1414	gettabup     r10    u2   k87 ; k87 = "AssetUID"
.line	1414	call          r9     2     2
.line	1414	eq             0    r8    r9
.line	1414	jmp            0  l163
.line	1414	gettable      r8    r7   k88 ; k88 = "AssetName"
.line	1414	getupval      r9    u3
.line	1414	eq             0    r8    r9
.line	1414	jmp            0  l163
.line	1414	getupval      r8    u4
.line	1414	settable      r7   k88    r8 ; k88 = "AssetName"
.label	l163
.line	1414	move          r0    r0
.line	1414	move          r0    r0
.line	1414	getupval      r3    u7
.line	1414	self          r3    r3   k93 ; k93 = "SaveAssetPathMap"
.line	1414	call          r3     2     1
.line	1414	getupval      r3    u7
.line	1414	self          r3    r3   k94 ; k94 = "SyncWorkAssetDataToE" (truncated)
.line	1414	call          r3     2     1
.label	l171
.line	1414	return        r0     1
.line	1414	move          r0    r0
.line	1414	return        r0     1

.function	main/f42

.source	null
.linedefined	1515
.lastlinedefined	1520
.numparams	3
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	4	true
.upvalue	"U1"	1	true

.constant	k0	"SendMsgToEditor"
.constant	k1	"G2E"
.constant	k2	"G2E_RspWorkAssetSave"
.constant	k3	"Success"
.constant	k4	"ErrMsg"

.line	1515	self          r3    r0    k0 ; k0 = "SendMsgToEditor"
.line	1515	gettabup      r5    u0    k1 ; k1 = "G2E"
.line	1515	gettable      r5    r5    k2 ; k2 = "G2E_RspWorkAssetSave"
.line	1515	newtable      r6     0     2
.line	1515	settable      r6    k3    r1 ; k3 = "Success"
.line	1515	testset       r7    r2     1
.line	1515	jmp            0   l10
.line	1515	getupval      r7    u1
.line	1515	call          r7     1     2
.label	l10
.line	1515	settable      r6    k4    r7 ; k4 = "ErrMsg"
.line	1515	call          r3     4     1
.line	1515	return        r0     1
.line	1515	move          r0    r0
.line	1515	move          r0    r0
.line	1515	return        r0     1

.function	main/f43

.source	null
.linedefined	1522
.lastlinedefined	1576
.numparams	1
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	8	true
.upvalue	"U2"	7	true
.upvalue	"U3"	1	true
.upvalue	"U4"	15	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"CommonModuleConfig"
.constant	k3	"logic_ugc_prefab_mall"
.constant	k4	"ENUM_FILTER_TYPE"
.constant	k5	"MyFavorite"
.constant	k6	"MyShare"
.constant	k7	"MyPrivate"
.constant	k8	"CustomAssetKeys"
.constant	k9	1
.constant	k10	"GetMyPrefabMallMeta"
.constant	k11	"IMAGE"
.constant	k12	"SOUND"
.constant	k13	"STATICMESH"
.constant	k14	"CUSTOMUI"
.constant	k15	"ANIM"
.constant	k16	"PREFAB"
.constant	k17	"EFFECT"
.constant	k18	"ACTOR"
.constant	k19	0
.constant	k20	"ipairs"
.constant	k21	"AssetId"
.constant	k22	"CustomAssetKey"
.constant	k23	"require"
.constant	k24	"table"
.constant	k25	"concat"
.constant	k26	161
.constant	k27	116
.constant	k28	68
.constant	k29	17
.constant	k30	80
.constant	k31	227
.constant	k32	216
.constant	k33	98
.constant	k34	144
.constant	k35	43
.constant	k36	224
.constant	k37	236
.constant	k38	211
.constant	k39	232
.constant	k40	201
.constant	k41	237
.constant	k42	76
.constant	k43	47
.constant	k44	33
.constant	k45	174
.constant	k46	199
.constant	k47	186
.constant	k48	25
.constant	k49	19
.constant	k50	245
.constant	k51	191
.constant	k52	229
.constant	k53	250
.constant	k54	208
.constant	k55	253
.constant	k56	127
.constant	k57	27
.constant	k58	10
.constant	k59	38
.constant	k60	153
.constant	k61	215
.constant	k62	173
.constant	k63	5
.constant	k64	112
.constant	k65	101
.constant	k66	125
.constant	k67	184
.constant	k68	35
.constant	k69	179
.constant	k70	34
.constant	k71	165
.constant	k72	190
.constant	k73	217
.constant	k74	222
.constant	k75	233
.constant	k76	119
.constant	k77	81
.constant	k78	48
.constant	k79	50
.constant	k80	137
.constant	k81	226
.constant	k82	176
.constant	k83	18
.constant	k84	172
.constant	k85	57
.constant	k86	177
.constant	k87	248
.constant	k88	239
.constant	k89	99
.constant	k90	65
.constant	k91	13
.constant	k92	49
.constant	k93	143
.constant	k94	213
.constant	k95	154
.constant	k96	3
.constant	k97	136
.constant	k98	115
.constant	k99	64
.constant	k100	"Enum_DynamicType"
.constant	k101	"PrefabTypeToDynamicType"
.constant	k102	"ImagePreset"
.constant	k103	"SoundPreset"
.constant	k104	"ModelPreset"
.constant	k105	"_G"
.constant	k106	"EnableUMGInfoManager"
.constant	k107	"UMGCanvasPreset"
.constant	k108	"UMGResPreset"
.constant	k109	"ArmedAIAnimationPreset"
.constant	k110	"CreativeGroupAsset"
.constant	k111	"EffectPreset"
.constant	k112	"Actor"
.constant	k113	"ActorPreset"

.line	1522	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	1522	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	1522	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	1522	gettable      r2    r2    k2 ; k2 = "CommonModuleConfig"
.line	1522	gettable      r2    r2    k3 ; k3 = "logic_ugc_prefab_mal" (truncated)
.line	1522	call          r1     2     2
.line	1522	newtable      r2     0     3
.line	1522	gettable      r3    r1    k4 ; k4 = "ENUM_FILTER_TYPE"
.line	1522	gettable      r3    r3    k5 ; k5 = "MyFavorite"
.line	1522	newtable      r4     0     0
.line	1522	settable      r2    r3    r4
.line	1522	gettable      r3    r1    k4 ; k4 = "ENUM_FILTER_TYPE"
.line	1522	gettable      r3    r3    k6 ; k6 = "MyShare"
.line	1522	newtable      r4     0     0
.line	1522	settable      r2    r3    r4
.line	1522	gettable      r3    r1    k4 ; k4 = "ENUM_FILTER_TYPE"
.line	1522	gettable      r3    r3    k7 ; k7 = "MyPrivate"
.line	1522	newtable      r4     0     0
.line	1522	settable      r2    r3    r4
.line	1522	newtable      r3     0     0
.line	1522	settable      r0    k8    r3 ; k8 = "CustomAssetKeys"
.line	1522	gettable      r3    r1    k4 ; k4 = "ENUM_FILTER_TYPE"
.line	1522	gettable      r3    r3    k5 ; k5 = "MyFavorite"
.line	1522	gettable      r4    r1    k4 ; k4 = "ENUM_FILTER_TYPE"
.line	1522	gettable      r4    r4    k7 ; k7 = "MyPrivate"
.line	1522	loadk         r5    k9 ; k9 = 1
.line	1522	move          r0    r0
.line	1522	getupval      r7    u1
.line	1522	self          r7    r7   k10 ; k10 = "GetMyPrefabMallMeta"
.line	1522	move          r9    r6
.line	1522	gettabup     r10    u2   k11 ; k11 = "IMAGE"
.line	1522	call          r7     4     2
.line	1522	getupval      r8    u1
.line	1522	self          r8    r8   k10 ; k10 = "GetMyPrefabMallMeta"
.line	1522	move         r10    r6
.line	1522	gettabup     r11    u2   k12 ; k12 = "SOUND"
.line	1522	call          r8     4     2
.line	1522	getupval      r9    u1
.line	1522	self          r9    r9   k10 ; k10 = "GetMyPrefabMallMeta"
.line	1522	move         r11    r6
.line	1522	gettabup     r12    u2   k13 ; k13 = "STATICMESH"
.line	1522	call          r9     4     2
.line	1522	getupval     r10    u1
.line	1522	self         r10   r10   k10 ; k10 = "GetMyPrefabMallMeta"
.line	1522	move         r12    r6
.line	1522	gettabup     r13    u2   k14 ; k14 = "CUSTOMUI"
.line	1522	call         r10     4     2
.line	1522	getupval     r11    u1
.line	1522	self         r11   r11   k10 ; k10 = "GetMyPrefabMallMeta"
.line	1522	move         r13    r6
.line	1522	gettabup     r14    u2   k15 ; k15 = "ANIM"
.line	1522	call         r11     4     2
.line	1522	getupval     r12    u1
.line	1522	self         r12   r12   k10 ; k10 = "GetMyPrefabMallMeta"
.line	1522	move         r14    r6
.line	1522	gettabup     r15    u2   k16 ; k16 = "PREFAB"
.line	1522	call         r12     4     2
.line	1522	getupval     r13    u1
.line	1522	self         r13   r13   k10 ; k10 = "GetMyPrefabMallMeta"
.line	1522	move         r15    r6
.line	1522	gettabup     r16    u2   k17 ; k17 = "EFFECT"
.line	1522	call         r13     4     2
.line	1522	getupval     r14    u1
.line	1522	self         r14   r14   k10 ; k10 = "GetMyPrefabMallMeta"
.line	1522	move         r16    r6
.line	1522	gettabup     r17    u2   k18 ; k18 = "ACTOR"
.line	1522	call         r14     4     2
.line	1522	gettable     r15    r2    r6
.line	1522	gettabup     r16    u2   k11 ; k11 = "IMAGE"
.line	1522	len          r17    r7
.line	1522	lt             0   k19   r17 ; k19 = 0
.line	1522	jmp            0   l75
.line	1522	testset      r17    r7     1
.line	1522	jmp            0   l76
.label	l75
.line	1522	loadnil      r17     0
.label	l76
.line	1522	settable     r15   r16   r17
.line	1522	gettable     r15    r2    r6
.line	1522	gettabup     r16    u2   k12 ; k12 = "SOUND"
.line	1522	len          r17    r8
.line	1522	lt             0   k19   r17 ; k19 = 0
.line	1522	jmp            0   l84
.line	1522	testset      r17    r8     1
.line	1522	jmp            0   l85
.label	l84
.line	1522	loadnil      r17     0
.label	l85
.line	1522	settable     r15   r16   r17
.line	1522	gettable     r15    r2    r6
.line	1522	gettabup     r16    u2   k13 ; k13 = "STATICMESH"
.line	1522	len          r17    r9
.line	1522	lt             0   k19   r17 ; k19 = 0
.line	1522	jmp            0   l93
.line	1522	testset      r17    r9     1
.line	1522	jmp            0   l94
.label	l93
.line	1522	loadnil      r17     0
.label	l94
.line	1522	settable     r15   r16   r17
.line	1522	gettable     r15    r2    r6
.line	1522	gettabup     r16    u2   k14 ; k14 = "CUSTOMUI"
.line	1522	len          r17   r10
.line	1522	lt             0   k19   r17 ; k19 = 0
.line	1522	jmp            0  l102
.line	1522	testset      r17   r10     1
.line	1522	jmp            0  l103
.label	l102
.line	1522	loadnil      r17     0
.label	l103
.line	1522	settable     r15   r16   r17
.line	1522	gettable     r15    r2    r6
.line	1522	gettabup     r16    u2   k15 ; k15 = "ANIM"
.line	1522	len          r17   r11
.line	1522	lt             0   k19   r17 ; k19 = 0
.line	1522	jmp            0  l111
.line	1522	testset      r17   r11     1
.line	1522	jmp            0  l112
.label	l111
.line	1522	loadnil      r17     0
.label	l112
.line	1522	settable     r15   r16   r17
.line	1522	gettable     r15    r2    r6
.line	1522	gettabup     r16    u2   k16 ; k16 = "PREFAB"
.line	1522	len          r17   r12
.line	1522	lt             0   k19   r17 ; k19 = 0
.line	1522	jmp            0  l120
.line	1522	testset      r17   r12     1
.line	1522	jmp            0  l121
.label	l120
.line	1522	loadnil      r17     0
.label	l121
.line	1522	settable     r15   r16   r17
.line	1522	gettable     r15    r2    r6
.line	1522	gettabup     r16    u2   k17 ; k17 = "EFFECT"
.line	1522	len          r17   r13
.line	1522	lt             0   k19   r17 ; k19 = 0
.line	1522	jmp            0  l129
.line	1522	testset      r17   r13     1
.line	1522	jmp            0  l130
.label	l129
.line	1522	loadnil      r17     0
.label	l130
.line	1522	settable     r15   r16   r17
.line	1522	gettable     r15    r2    r6
.line	1522	gettabup     r16    u2   k18 ; k18 = "ACTOR"
.line	1522	len          r17   r14
.line	1522	lt             0   k19   r17 ; k19 = 0
.line	1522	jmp            0  l138
.line	1522	testset      r17   r14     1
.line	1522	jmp            0  l139
.label	l138
.line	1522	loadnil      r17     0
.label	l139
.line	1522	settable     r15   r16   r17
.line	1522	test         r10     0
.line	1522	jmp            0  l152
.line	1522	gettabup     r15    u0   k20 ; k20 = "ipairs"
.line	1522	move         r16   r10
.line	1522	call         r15     2     4
.line	1522	jmp            0  l150
.line	1522	gettable     r20    r0    k8 ; k8 = "CustomAssetKeys"
.line	1522	gettable     r21   r19   k21 ; k21 = "AssetId"
.line	1522	gettable     r22   r19   k22 ; k22 = "CustomAssetKey"
.line	1522	settable     r20   r21   r22
.label	l150
.line	1522	move          r0    r0
.line	1522	move          r0    r0
.label	l152
.line	1522	test         r12     0
.line	1522	jmp            0  l164
.line	1522	gettabup     r15    u0   k20 ; k20 = "ipairs"
.line	1522	move         r16   r12
.line	1522	call         r15     2     4
.line	1522	jmp            0  l162
.line	1522	gettable     r20    r0    k8 ; k8 = "CustomAssetKeys"
.line	1522	gettable     r21   r19   k21 ; k21 = "AssetId"
.line	1522	gettable     r22   r19   k22 ; k22 = "CustomAssetKey"
.line	1522	settable     r20   r21   r22
.label	l162
.line	1522	move          r0    r0
.line	1522	move          r0    r0
.label	l164
.line	1522	test         r14     0
.line	1522	jmp            0  l176
.line	1522	gettabup     r15    u0   k20 ; k20 = "ipairs"
.line	1522	move         r16   r14
.line	1522	call         r15     2     4
.line	1522	jmp            0  l174
.line	1522	gettable     r20    r0    k8 ; k8 = "CustomAssetKeys"
.line	1522	gettable     r21   r19   k21 ; k21 = "AssetId"
.line	1522	gettable     r22   r19   k22 ; k22 = "CustomAssetKey"
.line	1522	settable     r20   r21   r22
.label	l174
.line	1522	move          r0    r0
.line	1522	move          r0    r0
.label	l176
.line	1522	move          r0    r0
.line	1522	gettabup      r3    u0   k23 ; k23 = "require"
.line	1522	gettabup      r4    u0   k24 ; k24 = "table"
.line	1522	gettable      r4    r4   k25 ; k25 = "concat"
.line	1522	newtable      r5     2     0
.line	1522	getupval      r6    u3
.line	1522	loadk         r7   k26 ; k26 = 161
.line	1522	loadk         r8   k27 ; k27 = 116
.line	1522	loadk         r9   k28 ; k28 = 68
.line	1522	loadk        r10   k29 ; k29 = 17
.line	1522	loadk        r11   k30 ; k30 = 80
.line	1522	loadk        r12   k31 ; k31 = 227
.line	1522	loadk        r13   k32 ; k32 = 216
.line	1522	loadk        r14   k33 ; k33 = 98
.line	1522	loadk        r15   k34 ; k34 = 144
.line	1522	loadk        r16   k35 ; k35 = 43
.line	1522	loadk        r17   k36 ; k36 = 224
.line	1522	loadk        r18   k37 ; k37 = 236
.line	1522	loadk        r19   k38 ; k38 = 211
.line	1522	loadk        r20   k39 ; k39 = 232
.line	1522	loadk        r21   k40 ; k40 = 201
.line	1522	loadk        r22   k41 ; k41 = 237
.line	1522	loadk        r23   k33 ; k33 = 98
.line	1522	loadk        r24   k42 ; k42 = 76
.line	1522	loadk        r25   k43 ; k43 = 47
.line	1522	loadk        r26   k44 ; k44 = 33
.line	1522	loadk        r27   k45 ; k45 = 174
.line	1522	loadk        r28   k46 ; k46 = 199
.line	1522	loadk        r29   k47 ; k47 = 186
.line	1522	loadk        r30   k48 ; k48 = 25
.line	1522	loadk        r31   k31 ; k31 = 227
.line	1522	loadk        r32   k49 ; k49 = 19
.line	1522	loadk        r33   k50 ; k50 = 245
.line	1522	loadk        r34   k51 ; k51 = 191
.line	1522	loadk        r35   k52 ; k52 = 229
.line	1522	loadk        r36   k53 ; k53 = 250
.line	1522	loadk        r37   k54 ; k54 = 208
.line	1522	loadk        r38   k55 ; k55 = 253
.line	1522	loadk        r39   k56 ; k56 = 127
.line	1522	loadk        r40   k57 ; k57 = 27
.line	1522	loadk        r41   k58 ; k58 = 10
.line	1522	loadk        r42   k59 ; k59 = 38
.line	1522	loadk        r43   k60 ; k60 = 153
.line	1522	loadk        r44   k61 ; k61 = 215
.line	1522	loadk        r45   k62 ; k62 = 173
.line	1522	loadk        r46   k63 ; k63 = 5
.line	1522	call          r6    41     2
.line	1522	getupval      r7    u3
.line	1522	loadk         r8   k34 ; k34 = 144
.line	1522	loadk         r9   k64 ; k64 = 112
.line	1522	loadk        r10   k65 ; k65 = 101
.line	1522	loadk        r11    k9 ; k9 = 1
.line	1522	loadk        r12   k66 ; k66 = 125
.line	1522	loadk        r13   k67 ; k67 = 184
.line	1522	loadk        r14   k53 ; k53 = 250
.line	1522	loadk        r15   k68 ; k68 = 35
.line	1522	loadk        r16   k69 ; k69 = 179
.line	1522	loadk        r17   k70 ; k70 = 34
.line	1522	loadk        r18   k41 ; k41 = 237
.line	1522	loadk        r19   k71 ; k71 = 165
.line	1522	loadk        r20   k72 ; k72 = 190
.line	1522	loadk        r21   k73 ; k73 = 217
.line	1522	loadk        r22   k74 ; k74 = 222
.line	1522	loadk        r23   k75 ; k75 = 233
.line	1522	loadk        r24   k76 ; k76 = 119
.line	1522	loadk        r25   k77 ; k77 = 81
.line	1522	loadk        r26   k78 ; k78 = 48
.line	1522	loadk        r27   k79 ; k79 = 50
.line	1522	loadk        r28   k80 ; k80 = 137
.line	1522	loadk        r29   k81 ; k81 = 226
.line	1522	loadk        r30   k82 ; k82 = 176
.line	1522	loadk        r31   k83 ; k83 = 18
.line	1522	loadk        r32   k84 ; k84 = 172
.line	1522	loadk        r33   k85 ; k85 = 57
.line	1522	loadk        r34   k55 ; k55 = 253
.line	1522	loadk        r35   k86 ; k86 = 177
.line	1522	loadk        r36   k54 ; k54 = 208
.line	1522	loadk        r37   k87 ; k87 = 248
.line	1522	loadk        r38   k73 ; k73 = 217
.line	1522	loadk        r39   k88 ; k88 = 239
.line	1522	loadk        r40   k89 ; k89 = 99
.line	1522	loadk        r41   k90 ; k90 = 65
.line	1522	loadk        r42   k91 ; k91 = 13
.line	1522	loadk        r43   k92 ; k92 = 49
.line	1522	loadk        r44   k93 ; k93 = 143
.line	1522	loadk        r45   k94 ; k94 = 213
.line	1522	loadk        r46   k95 ; k95 = 154
.line	1522	loadk        r47   k96 ; k96 = 3
.line	1522	call          r7    41     2
.line	1522	getupval      r8    u3
.line	1522	loadk         r9   k97 ; k97 = 136
.line	1522	loadk        r10   k98 ; k98 = 115
.line	1522	loadk        r11   k99 ; k99 = 64
.line	1522	loadk        r12   k49 ; k49 = 19
.line	1522	call          r8     5     0
.line	1522	setlist       r5     0     1
.line	1522	call          r4     2     2
.line	1522	call          r3     2     2
.line	1522	gettable      r4    r3  k100 ; k100 = "Enum_DynamicType"
.line	1522	newtable      r5     0     8
.line	1522	gettabup      r6    u2   k11 ; k11 = "IMAGE"
.line	1522	gettable      r7    r4  k102 ; k102 = "ImagePreset"
.line	1522	settable      r5    r6    r7
.line	1522	gettabup      r6    u2   k12 ; k12 = "SOUND"
.line	1522	gettable      r7    r4  k103 ; k103 = "SoundPreset"
.line	1522	settable      r5    r6    r7
.line	1522	gettabup      r6    u2   k13 ; k13 = "STATICMESH"
.line	1522	gettable      r7    r4  k104 ; k104 = "ModelPreset"
.line	1522	settable      r5    r6    r7
.line	1522	gettabup      r6    u2   k14 ; k14 = "CUSTOMUI"
.line	1522	gettabup      r7    u0  k105 ; k105 = "_G"
.line	1522	gettable      r7    r7  k106 ; k106 = "EnableUMGInfoManager"
.line	1522	test          r7     0
.line	1522	jmp            0  l293
.line	1522	gettable      r7    r4  k107 ; k107 = "UMGCanvasPreset"
.line	1522	test          r7     1
.line	1522	jmp            0  l294
.label	l293
.line	1522	gettable      r7    r4  k108 ; k108 = "UMGResPreset"
.label	l294
.line	1522	settable      r5    r6    r7
.line	1522	gettabup      r6    u2   k15 ; k15 = "ANIM"
.line	1522	gettable      r7    r4  k109 ; k109 = "ArmedAIAnimationPres" (truncated)
.line	1522	settable      r5    r6    r7
.line	1522	gettabup      r6    u2   k16 ; k16 = "PREFAB"
.line	1522	gettable      r7    r4  k110 ; k110 = "CreativeGroupAsset"
.line	1522	settable      r5    r6    r7
.line	1522	gettabup      r6    u2   k17 ; k17 = "EFFECT"
.line	1522	gettable      r7    r4  k111 ; k111 = "EffectPreset"
.line	1522	settable      r5    r6    r7
.line	1522	gettabup      r6    u4  k112 ; k112 = "Actor"
.line	1522	gettable      r7    r4  k113 ; k113 = "ActorPreset"
.line	1522	settable      r5    r6    r7
.line	1522	settable      r2  k101    r5 ; k101 = "PrefabTypeToDynamicT" (truncated)
.line	1522	return        r2     2
.line	1522	return        r0     1
.line	1522	move          r0    r0
.line	1522	move          r0    r0
.line	1522	move          r0    r0
.line	1522	return        r0     1

.function	main/f44

.source	null
.linedefined	1578
.lastlinedefined	1580
.numparams	2
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	1	true

.constant	k0	"CustomAssetKeys"

.line	1578	gettable      r2    r0    k0 ; k0 = "CustomAssetKeys"
.line	1578	test          r2     0
.line	1578	jmp            0    l8
.line	1578	gettable      r2    r0    k0 ; k0 = "CustomAssetKeys"
.line	1578	gettable      r2    r2    r1
.line	1578	test          r2     1
.line	1578	jmp            0   l10
.label	l8
.line	1578	getupval      r2    u0
.line	1578	call          r2     1     2
.label	l10
.line	1578	return        r2     2
.line	1578	return        r0     1
.line	1578	move          r0    r0
.line	1578	move          r0    r0
.line	1578	move          r0    r0
.line	1578	return        r0     1

.function	main/f45

.source	null
.linedefined	1582
.lastlinedefined	1591
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	2	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	177
.constant	k5	122
.constant	k6	126
.constant	k7	49
.constant	k8	120
.constant	k9	255
.constant	k10	205
.constant	k11	35
.constant	k12	175
.constant	k13	19
.constant	k14	235
.constant	k15	176
.constant	k16	251
.constant	k17	219
.constant	k18	223
.constant	k19	115
.constant	k20	81
.constant	k21	10
.constant	k22	142
.constant	k23	174
.constant	k24	14
.constant	k25	247
.constant	k26	6
.constant	k27	241
.constant	k28	190
.constant	k29	229
.constant	k30	207
.constant	k31	249
.constant	k32	85
.constant	k33	64
.constant	k34	43
.constant	k35	25
.constant	k36	155
.constant	k37	196
.constant	k38	144
.constant	k39	2
.constant	k40	161
.constant	k41	116
.constant	k42	68
.constant	k43	17
.constant	k44	"ReplicateCompleteCallBackID"
.constant	k45	"require"
.constant	k46	80
.constant	k47	227
.constant	k48	216
.constant	k49	98
.constant	k50	224
.constant	k51	236
.constant	k52	211
.constant	k53	232
.constant	k54	201
.constant	k55	237
.constant	k56	76
.constant	k57	47
.constant	k58	33
.constant	k59	199
.constant	k60	186
.constant	k61	245
.constant	k62	191
.constant	k63	250
.constant	k64	208
.constant	k65	253
.constant	k66	127
.constant	k67	27
.constant	k68	59
.constant	k69	145
.constant	k70	182
.constant	k71	200
.constant	k72	86
.constant	k73	91
.constant	k74	125
.constant	k75	226
.constant	k76	58
.constant	k77	184
.constant	k78	9
.constant	k79	172
.constant	k80	254
.constant	k81	66
.constant	k82	74
.constant	k83	54
.constant	k84	40
.constant	k85	159
.constant	k86	L"RemoveInstanceDataTreeReplicateCompleteCallBack"
.constant	k87	nil
.constant	k88	"RemoveAllMsgEvent"
.constant	k89	"__super"
.constant	k90	"ReleaseSubMgrInGame"

.line	1582	gettabup      r1    u0    k0 ; k0 = "print"
.line	1582	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1582	test          r2     0
.line	1582	jmp            0   l58
.line	1582	gettabup      r2    u0    k2 ; k2 = "table"
.line	1582	gettable      r2    r2    k3 ; k3 = "concat"
.line	1582	newtable      r3     1     0
.line	1582	getupval      r4    u1
.line	1582	loadk         r5    k4 ; k4 = 177
.line	1582	loadk         r6    k5 ; k5 = 122
.line	1582	loadk         r7    k6 ; k6 = 126
.line	1582	loadk         r8    k7 ; k7 = 49
.line	1582	loadk         r9    k8 ; k8 = 120
.line	1582	loadk        r10    k9 ; k9 = 255
.line	1582	loadk        r11   k10 ; k10 = 205
.line	1582	loadk        r12   k11 ; k11 = 35
.line	1582	loadk        r13   k12 ; k12 = 175
.line	1582	loadk        r14   k13 ; k13 = 19
.line	1582	loadk        r15   k14 ; k14 = 235
.line	1582	loadk        r16   k15 ; k15 = 176
.line	1582	loadk        r17   k16 ; k16 = 251
.line	1582	loadk        r18   k17 ; k17 = 219
.line	1582	loadk        r19   k18 ; k18 = 223
.line	1582	loadk        r20    k9 ; k9 = 255
.line	1582	loadk        r21   k19 ; k19 = 115
.line	1582	loadk        r22   k20 ; k20 = 81
.line	1582	loadk        r23   k21 ; k21 = 10
.line	1582	loadk        r24    k7 ; k7 = 49
.line	1582	loadk        r25   k22 ; k22 = 142
.line	1582	loadk        r26   k14 ; k14 = 235
.line	1582	loadk        r27   k23 ; k23 = 174
.line	1582	loadk        r28   k24 ; k24 = 14
.line	1582	loadk        r29   k25 ; k25 = 247
.line	1582	loadk        r30   k26 ; k26 = 6
.line	1582	loadk        r31   k27 ; k27 = 241
.line	1582	loadk        r32   k28 ; k28 = 190
.line	1582	loadk        r33   k29 ; k29 = 229
.line	1582	loadk        r34   k14 ; k14 = 235
.line	1582	loadk        r35   k30 ; k30 = 207
.line	1582	loadk        r36   k31 ; k31 = 249
.line	1582	loadk        r37   k32 ; k32 = 85
.line	1582	loadk        r38   k33 ; k33 = 64
.line	1582	loadk        r39   k34 ; k34 = 43
.line	1582	loadk        r40   k35 ; k35 = 25
.line	1582	loadk        r41   k36 ; k36 = 155
.line	1582	loadk        r42   k37 ; k37 = 196
.line	1582	loadk        r43   k38 ; k38 = 144
.line	1582	loadk        r44   k39 ; k39 = 2
.line	1582	call          r4    41     2
.line	1582	getupval      r5    u1
.line	1582	loadk         r6   k40 ; k40 = 161
.line	1582	loadk         r7   k41 ; k41 = 116
.line	1582	loadk         r8   k42 ; k42 = 68
.line	1582	loadk         r9   k43 ; k43 = 17
.line	1582	call          r5     5     0
.line	1582	setlist       r3     0     1
.line	1582	call          r2     2     2
.label	l58
.line	1582	call          r1     2     1
.line	1582	gettable      r1    r0   k44 ; k44 = "ReplicateCompleteCal" (truncated)
.line	1582	test          r1     0
.line	1582	jmp            0  l138
.line	1582	gettabup      r1    u0   k45 ; k45 = "require"
.line	1582	gettabup      r2    u0    k2 ; k2 = "table"
.line	1582	gettable      r2    r2    k3 ; k3 = "concat"
.line	1582	newtable      r3     1     0
.line	1582	getupval      r4    u1
.line	1582	loadk         r5   k40 ; k40 = 161
.line	1582	loadk         r6   k41 ; k41 = 116
.line	1582	loadk         r7   k42 ; k42 = 68
.line	1582	loadk         r8   k43 ; k43 = 17
.line	1582	loadk         r9   k46 ; k46 = 80
.line	1582	loadk        r10   k47 ; k47 = 227
.line	1582	loadk        r11   k48 ; k48 = 216
.line	1582	loadk        r12   k49 ; k49 = 98
.line	1582	loadk        r13   k38 ; k38 = 144
.line	1582	loadk        r14   k34 ; k34 = 43
.line	1582	loadk        r15   k50 ; k50 = 224
.line	1582	loadk        r16   k51 ; k51 = 236
.line	1582	loadk        r17   k52 ; k52 = 211
.line	1582	loadk        r18   k53 ; k53 = 232
.line	1582	loadk        r19   k54 ; k54 = 201
.line	1582	loadk        r20   k55 ; k55 = 237
.line	1582	loadk        r21   k49 ; k49 = 98
.line	1582	loadk        r22   k56 ; k56 = 76
.line	1582	loadk        r23   k57 ; k57 = 47
.line	1582	loadk        r24   k58 ; k58 = 33
.line	1582	loadk        r25   k23 ; k23 = 174
.line	1582	loadk        r26   k59 ; k59 = 199
.line	1582	loadk        r27   k60 ; k60 = 186
.line	1582	loadk        r28   k35 ; k35 = 25
.line	1582	loadk        r29   k47 ; k47 = 227
.line	1582	loadk        r30   k13 ; k13 = 19
.line	1582	loadk        r31   k61 ; k61 = 245
.line	1582	loadk        r32   k62 ; k62 = 191
.line	1582	loadk        r33   k29 ; k29 = 229
.line	1582	loadk        r34   k63 ; k63 = 250
.line	1582	loadk        r35   k64 ; k64 = 208
.line	1582	loadk        r36   k65 ; k65 = 253
.line	1582	loadk        r37   k66 ; k66 = 127
.line	1582	loadk        r38   k67 ; k67 = 27
.line	1582	loadk        r39   k21 ; k21 = 10
.line	1582	loadk        r40   k68 ; k68 = 59
.line	1582	loadk        r41   k69 ; k69 = 145
.line	1582	loadk        r42   k17 ; k17 = 219
.line	1582	loadk        r43   k70 ; k70 = 182
.line	1582	loadk        r44   k39 ; k39 = 2
.line	1582	call          r4    41     2
.line	1582	getupval      r5    u1
.line	1582	loadk         r6   k71 ; k71 = 200
.line	1582	loadk         r7   k72 ; k72 = 86
.line	1582	loadk         r8   k73 ; k73 = 91
.line	1582	loadk         r9   k43 ; k43 = 17
.line	1582	loadk        r10   k74 ; k74 = 125
.line	1582	loadk        r11   k75 ; k75 = 226
.line	1582	loadk        r12   k64 ; k64 = 208
.line	1582	loadk        r13   k76 ; k76 = 58
.line	1582	loadk        r14   k77 ; k77 = 184
.line	1582	loadk        r15   k78 ; k78 = 9
.line	1582	loadk        r16   k29 ; k29 = 229
.line	1582	loadk        r17   k79 ; k79 = 172
.line	1582	loadk        r18   k27 ; k27 = 241
.line	1582	loadk        r19   k65 ; k65 = 253
.line	1582	loadk        r20   k54 ; k54 = 201
.line	1582	loadk        r21   k80 ; k80 = 254
.line	1582	loadk        r22   k81 ; k81 = 66
.line	1582	loadk        r23   k82 ; k82 = 74
.line	1582	loadk        r24   k83 ; k83 = 54
.line	1582	loadk        r25   k84 ; k84 = 40
.line	1582	loadk        r26   k85 ; k85 = 159
.line	1582	call          r5    22     0
.line	1582	setlist       r3     0     1
.line	1582	call          r2     2     2
.line	1582	call          r1     2     2
.line	1582	self          r2    r1   k86 ; k86 = L"RemoveInstanceDataTr" (truncated)
.line	1582	gettable      r4    r0   k44 ; k44 = "ReplicateCompleteCal" (truncated)
.line	1582	call          r2     3     1
.line	1582	settable      r0   k44   k87 ; k87 = nil
.label	l138
.line	1582	self          r1    r0   k88 ; k88 = "RemoveAllMsgEvent"
.line	1582	call          r1     2     1
.line	1582	gettabup      r1    u2   k89 ; k89 = "__super"
.line	1582	gettable      r1    r1   k90 ; k90 = "ReleaseSubMgrInGame"
.line	1582	move          r2    r0
.line	1582	call          r1     2     1
.line	1582	return        r0     1
.line	1582	move          r0    r0
.line	1582	move          r0    r0
.line	1582	return        r0     1

.function	main/f46

.source	null
.linedefined	1593
.lastlinedefined	1596
.numparams	1
.is_vararg	0
.maxstacksize	3

.constant	k0	"LoadFolderTree"
.constant	k1	"LoadAssetPathMap"

.line	1593	self          r1    r0    k0 ; k0 = "LoadFolderTree"
.line	1593	call          r1     2     1
.line	1593	self          r1    r0    k1 ; k1 = "LoadAssetPathMap"
.line	1593	call          r1     2     1
.line	1593	return        r0     1
.line	1593	move          r0    r0
.line	1593	move          r0    r0
.line	1593	return        r0     1

.function	main/f47

.source	"=[V12L:f12184a3f08fc10a:74694d6e4206ea9e]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f48

.source	"=[V11_@Black_MagicYT BlackMagiYT_LBIND_00]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_0_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f49

.source	"=[V11_@Black_MagicYT BlackMagiYT_SYSC_01]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_1_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f50

.source	"=[V11_@Black_MagicYT BlackMagiYT_MRGE_02]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_2_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f51

.source	"=[V11_@Black_MagicYT BlackMagiYT_POOL_03]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_3_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

