local ExitHelicopter = {}
local ESurviveWeaponPropSlot = import("ESurviveWeaponPropSlot")
local ESTEPoseState = import("ESTEPoseState")
local EPawnState = import("EPawnState")
local STAND_LOCK_TIP_ID = 30011
local STAND_CHECK_TOLERANCE = -5
local NEAR_DEATH_BLOCK_STATES = {
  EPawnState.Swim,
  EPawnState.Diving,
  EPawnState.InParachute,
  EPawnState.AirBorne,
  EPawnState.Dizziness,
  EPawnState.Arrest,
  EPawnState.Fishing,
  EPawnState.LeanOutVehicle
}

function ExitHelicopter:ctor()
  self.EscapingPlayer = {}
  self.ClimbTimer = nil
end

function ExitHelicopter:ReceiveBeginPlay()
  local UKismetSystemLibrary = import("KismetSystemLibrary")
  if not UKismetSystemLibrary.IsDedicatedServer(self) then
    self:AddTimer(0.1, function()
      local ECollisionEnabled = import("ECollisionEnabled")
      self.DecalSphere:SetCollisionEnabled(ECollisionEnabled.QueryOnly)
      self:CheckCreateNewDecal()
    end)
  end
  ExitHelicopter.__super.ReceiveBeginPlay(self)
end

function ExitHelicopter:OnTakeDamage(DamageInfo)
  if DamageInfo.DamageType == 13 then
    return
  end
  local uTarget = DamageInfo.Target
  local nDamage = DamageInfo.Damage
  if 0 < nDamage and Game:IsPlayer(uTarget) then
    uTarget:StopSkill(1013120)
    self:InterruptEscaping(uTarget)
  end
end

function ExitHelicopter:OnServerAddOrDeleteComponent(uOtherActor, bAddOrDelete, Component)
  if bAddOrDelete == false and Game:IsPlayer(uOtherActor) then
    self:InterruptEscaping(uOtherActor)
  end
end

function ExitHelicopter:InterruptEscaping(uPlayer)
  if not Game:IsValid(uPlayer) then
    return
  end
  self.EscapingPlayer[uPlayer] = nil
  local uPlayerController = uPlayer:GetPlayerControllerSafety()
  if Game:IsValid(uPlayerController) and Game:IsValid(uPlayerController.LuaTask) then
    local uTaskComp = uPlayerController.LuaTask
    uTaskComp:RPC_Client_ExitTaskArea(self.TaskId)
  end
end

function ExitHelicopter:OnStartedSkillAction(uPlayer, component)
  if self.hasAuthority and Game:IsValid(uPlayer) then
    do
      local nPlayerID = uPlayer.PlayerKey
      local uPlayerController = uPlayer:GetPlayerControllerSafety()
      if Game:IsValid(uPlayerController) and Game:IsValid(uPlayerController.LuaTask) then
        self.EscapingPlayer[uPlayer] = true
        local uTaskComp = uPlayerController.LuaTask
        local InteractiveTimeScale = uPlayer:GetAttrValue("InteractiveTimeScale")
        if math.abs(InteractiveTimeScale) < 1.0E-5 then
          InteractiveTimeScale = 1
        end
        local FinalEscapeTime = self.EscapeTime * InteractiveTimeScale
        uTaskComp:RPC_Client_EnterTaskArea(self.TaskId, FinalEscapeTime)
        uPlayer:SwitchWeaponBySlot(ESurviveWeaponPropSlot.SWPS_None, false, true, true)
        print(bWriteLog and "ExitHelicopter:OnStartedSkillAction")
        goto lbl_60
        uPlayer:StopSkill(1013120)
      end
    end
  end
  ::lbl_60::
end

function ExitHelicopter:OnStoppedSkillAction(uPlayer, reason, skillId, Component)
  if Component and Component.skillId == skillId and Game:IsValid(uPlayer) then
    self:InterruptEscaping(uPlayer)
  end
end

function ExitHelicopter:MustCheckResultAfterSkillFinished(uPlayer, Result, Component)
  if self.hasAuthority and Result and slua.isValid(uPlayer) then
    self:EscapeSuccess(uPlayer)
  end
end

function ExitHelicopter:CanStartEscape(uCharacter)
  if uCharacter:IsNearDeath() then
    for _, nState in ipairs(NEAR_DEATH_BLOCK_STATES) do
      if uCharacter:HasState(nState) then
        return false
      end
    end
    return true
  end
  local nPose = uCharacter.PoseState
  if nPose == ESTEPoseState.Stand or nPose == ESTEPoseState.Sprint then
    return true
  end
  return uCharacter:AllowState(EPawnState.Stand, false) and uCharacter:CheckCanStand(STAND_CHECK_TOLERANCE)
end

function ExitHelicopter:MustCheckResultAfterServerClick(uCharacter, bResult, uComponent, ...)
  if bResult and slua.isValid(uCharacter) and not self:CanStartEscape(uCharacter) then
    local uPC = uCharacter:GetPlayerControllerSafety()
    if slua.isValid(uPC) then
      uPC:ClientDisplayGameTipWithMsgID(STAND_LOCK_TIP_ID)
    end
    return false
  end
  return ExitHelicopter.__super.MustCheckResultAfterServerClick(self, uCharacter, bResult, uComponent, ...)
end

function ExitHelicopter:RescueIfNearDeath(uPlayer)
  if not uPlayer:IsNearDeath() then
    return
  end
  local uNearDeathComp = uPlayer.NearDeatchComponent
  if slua.isValid(uNearDeathComp) then
    uNearDeathComp:RescueFinishSuccessfully()
    uPlayer:SwitchPoseState(ESTEPoseState.Stand, true, true, false, false)
  end
end

function ExitHelicopter:EscapeSuccess(uPlayer)
  if Game:IsValid(uPlayer) then
    self.EscapingPlayer[uPlayer] = nil
    self:RescueIfNearDeath(uPlayer)
    local uPlayerState = uPlayer:GetPlayerStateSafety()
    if slua.isValid(uPlayerState) and uPlayerState.SetIsHelicopter then
      uPlayerState:SetIsHelicopter()
    end
  end
  ExitHelicopter.__super.EscapeSuccess(self, uPlayer, true)
  self:ClimbHelicopter(uPlayer)
end

local ClimbHeight = 4000
local ClimbTime = 3.466667
local ClimbInterval = 0.03333333333333333
local ClimbSetupTime = 7.4
local nHeightPerTick = ClimbHeight / ClimbTime * ClimbInterval
local nClimbSpeed = ClimbHeight / ClimbTime

function ExitHelicopter:ClimbHelicopter(uCharacter)
  if slua.isValid(uCharacter) then
    if Game:IsValid(CGameState) then
      CGameState:BroadcastClimbHelicopter(uCharacter, self)
    end
    uCharacter:SetReplicateMovement(false)
    local nTargetZ = uCharacter:K2_GetActorLocation().Z + ClimbHeight
    local uMovementCompnent = uCharacter.STCharacterMovement
    if slua.isValid(uMovementCompnent) then
      uMovementCompnent:SetActive(false, false)
      uMovementCompnent:SetMovementMode(import("EMovementMode").MOVE_Flying, 0)
      do
        local uExitLocation = self:K2_GetActorLocation()
        if uExitLocation then
          uCharacter:K2_SetActorLocation(uExitLocation, false, nil, false)
        end
        local nTimer
        nTimer = Game:SetTimer(ClimbInterval, true, function()
          if not slua.isValid(uCharacter) then
            Game:ClearTimer(nTimer)
            return
          end
          local uCurrentLocation = uCharacter:K2_GetActorLocation()
          local uTargetLocation = uCurrentLocation + FVector(0, 0, nHeightPerTick)
          uCharacter:K2_SetActorLocation(uTargetLocation, false, nil, false)
          if uCurrentLocation.Z > nTargetZ then
            CGameState:ClimbHelicopterFinish(uCharacter)
            local uPC = uCharacter:GetPlayerControllerSafety()
            Game:SetTimer(2, false, function()
              if Game:IsValid(uPC) and CGameMode then
                uCharacter:SetTargetForViewers()
                CGameMode:DestroyCharacterForPlayerController(uPC)
                CGameMode:RecoardAlivePlayerNum()
              end
            end)
            Game:ClearTimer(nTimer)
            return
          end
        end)
      end
    end
  end
end

function ExitHelicopter:Stop()
  for uPlayer, bEscaping in pairs(self.EscapingPlayer) do
    if Game:IsValid(uPlayer) then
      uPlayer:StopSkill(1013120)
    end
  end
end

function ExitHelicopter:OnAllowToInteract(uCharacter, Component)
  return true
end

local class = require("class")
local CExitInteractiveActor = require("GameLua.Mod.TPlan.ExitInteractiveActor")
local CExitHelicopter = class(CExitInteractiveActor, nil, ExitHelicopter)
return CExitHelicopter
