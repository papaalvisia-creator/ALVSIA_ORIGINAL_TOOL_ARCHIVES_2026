local SkillInstData = {
  Inst = {
    SkillData = {
      SkillTimeScaleAttrName = "InteractiveTimeScale",
      bAllowPlayInNearDeath = true
    },
    [0] = {
      AllowPoseChange01 = {bWidgetEnabled = false}
    },
    [1] = {
      PhaseData = {PhaseDuration = 6.0},
      ["/Script/Addons.UAESkillAction_ShowSkillPrompt"] = {},
      PlayMontage_Pose01 = {
        PoseMontageData = {
          AnimMontage_Stand = "/Game/Mod/TPlanBase/Arts_Player/Helicopter/Helicopter_Prepair.Helicopter_Prepair",
          AnimMontage_Max = "/Game/Mod/TPlanBase/Arts_Player/Helicopter/Helicopter_Prepair.Helicopter_Prepair"
        }
      }
    },
    [2] = {
      PhaseData = {PhaseDuration = 3.5},
      ["/Script/Addons.UAESkillAction_PlayMontage_Pose"] = {
        PoseMontageData = {
          AnimMontage_Stand = "/Game/Mod/TPlanBase/Arts_Player/Helicopter/Helicopter_Climb.Helicopter_Climb",
          AnimMontage_Max = "/Game/Mod/TPlanBase/Arts_Player/Helicopter/Helicopter_Climb.Helicopter_Climb"
        },
        AnimStopAfterPhase = false
      }
    }
  }
}
return SkillInstData
