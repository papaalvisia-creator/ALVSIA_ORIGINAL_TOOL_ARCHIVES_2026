local ModeSelection_Sideber_Main_UIBP = {}
local TAB_ITEM_MODULE = "GameLua.Mod.Lobby.Split.ModeSelection470.umg.Sideber.Item.ModeSelection_Sideber_TabItem_Item_UIBP"
local TableUtil = require("common.table_util")
local mode_selection_category_utils = require("GameLua.Mod.Lobby.Split.ModeSelection470.logic.mode_selection_category_utils")
local mode_selection470_macros = require("GameLua.Mod.Lobby.Split.ModeSelection470.logic.mode_selection470_macros")
local helper = require("GameLua.Mod.Lobby.Split.ModeSelection470.logic.mode_selection470_sideber_helper")
local mode_selection_multi_util = require("GameLua.Mod.Lobby.Split.ModeSelection470.logic.mode_selection_multi_util")
local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
local Category = mode_selection_category_utils.Category
local DETAIL_UIKEY_THEMED_GAMEPLAY = "ModeSelection_Sideber_ThemedGameplay_UIBP"
local DETAIL_UIKEY_BY_CATEGORY = {
  [Category.RankMatch] = "ModeSelection_Sideber_CommonMatch_UIBP",
  [Category.Peak] = "ModeSelection_Sideber_PeakTournament_UIBP",
  [Category.Arena] = "ModeSelection_Sideber_Arena_UIBP",
  [Category.SocialTrainMetro] = DETAIL_UIKEY_THEMED_GAMEPLAY,
  [Category.Other] = "ModeSelection_Sideber_CommonMatch_UIBP"
}
local DETAIL_UIKEY_DEFAULT = "ModeSelection_Sideber_CommonMatch_UIBP"

local function GetDetailUIKey(ui)
  if mode_selection_category_utils.IsIndependentMode(ui.data) then
    return DETAIL_UIKEY_THEMED_GAMEPLAY
  end
  return DETAIL_UIKEY_BY_CATEGORY[ui._category] or DETAIL_UIKEY_DEFAULT
end

local TAB_ICON = {
  DETAIL = "PaperSprite'/Game/Mod/Lobby/Split/ModeSelection_New/Atlas/Sideber/Atlas_Sideber/Frames/Img_Sideber_Detail_png.Img_Sideber_Detail_png'",
  INTRODUCE = "PaperSprite'/Game/Mod/Lobby/Split/ModeSelection_New/Atlas/Sideber/Atlas_Sideber/Frames/Img_Sideber_List_png.Img_Sideber_List_png'",
  TEAM_QUICK = "PaperSprite'/Game/Mod/Lobby/Split/ModeSelection_New/Atlas/Sideber/Atlas_Sideber/Frames/Img_Sideber_TeamQuick_png.Img_Sideber_TeamQuick_png'",
  LEADERBOARD = "PaperSprite'/Game/Mod/Lobby/Split/ModeSelection_New/Atlas/Sideber/Atlas_Sideber/Frames/Img_Sideber_Rank_png.Img_Sideber_Rank_png'",
  FRIEND_STATUS = "PaperSprite'/Game/Mod/Lobby/Split/ModeSelection_New/Atlas/Sideber/Atlas_Sideber/Frames/Img_Sideber_Posts_png.Img_Sideber_Posts_png'"
}
local TAB_CONFIG = {
  {
    key = "DETAIL",
    UIKey = GetDetailUIKey,
    icon = TAB_ICON.DETAIL
  },
  {
    key = "INTRODUCE",
    UIKey = "ModeSelection_Sideber_ContentDescription_UIBP",
    icon = TAB_ICON.INTRODUCE
  },
  {
    key = "TEAM_QUICK",
    UIKey = "ModeSelection_Sideber_TeamQuick_UIBP",
    icon = TAB_ICON.TEAM_QUICK
  },
  {
    key = "LEADERBOARD",
    UIKey = "ModeSelection_Sideber_Leaderboard_UIBP",
    icon = TAB_ICON.LEADERBOARD
  },
  {
    key = "FRIEND_STATUS",
    UIKey = "ModeSelection_Sideber_FriendStatus_UIBP",
    icon = TAB_ICON.FRIEND_STATUS
  }
}
local TAB_VISIBLE_RULE = {
  DETAIL = true,
  INTRODUCE = function(data)
    return mode_selection_category_utils.HasGraphicIntroduce(data)
  end,
  TEAM_QUICK = function(data)
    local SocialSubKind = mode_selection_category_utils.SocialSubKind
    local subKind = mode_selection_category_utils.GetSocialSubKind(data)
    return subKind ~= SocialSubKind.SocialIsland and subKind ~= SocialSubKind.Training
  end,
  LEADERBOARD = function(data, ui)
    if mode_selection_category_utils.IsCategory(data, Category.RankMatch) then
      return ui._bRankedSelected == true
    end
    if mode_selection_category_utils.IsCategory(data, Category.Peak) then
      local LogicPeakGameUtil = require("client.logic.PeakGame.LogicPeakGameUtil")
      return LogicPeakGameUtil.IsInRankOpenTime()
    end
    return false
  end,
  FRIEND_STATUS = function()
    return not PublishRegionMacros.IsBlueholeOperationRegion()
  end
}
local LEADERBOARD_PRELOAD_ASSETS = {
  "/Game/UMG/UI_BP/Common/RankIntegral/RankSmall_Integral_UIBP.RankSmall_Integral_UIBP_C",
  "/Game/UMG/UI_BP/Common/Common_LightBoard_UIBP.Common_LightBoard_UIBP_C"
}
local START_BUTTON_STATE = mode_selection470_macros.ENUM_START_BUTTON_STATE
local NOTICE_SHARE_IN_GAME = 655733
local NOTICE_LEVEL_UNLOCK = 6573
local NOTICE_ARENA_MAP_NOT_DOWNLOAD = 180153
local SWITCHER_PAGE = {RankMatch = 0, AiDifficulty = 1}
local SWITCHER_EXT_INDEX = {
  Ranked = 0,
  Match = 1,
  MatchWithRankLock = 2,
  RankedWithMatchLock = 3
}

function ModeSelection_Sideber_Main_UIBP:ctor(_, data, params)
  self.data = data
  self._initialTabKey = params and params.initialTabKey
  self._category = mode_selection_category_utils.GetCategory(data)
  self._visibleTabs = nil
  self._curTabKey = nil
  printf("ModeSelection_Sideber_Main_UIBP:ctor viewId:%s, category:%s, modeIds:%s", tostring(data and data.id), self._category, table.concat(mode_selection_category_utils.GetModeIdList(data), ","))
  self.filter_info = nil
  self._filterOrigin = nil
  self._bottomUI = nil
  self._personTips = nil
  self._langTips = nil
  self._bPersonPanelOpen = false
  self._bLangPanelOpen = false
  self._bRankedSelected, self._curViewId, self._groupSelectIndex = helper.BuildStartViewContext(data)
  self._bCollected = self:IsCollected()
  self._multiSelectViewIDs = nil
  log_tree("ModeSelection_Sideber_Main_UIBP:ctor", data)
end

function ModeSelection_Sideber_Main_UIBP:GetDataForJumpBack()
  local uiData = {
    curTabKey = self._curTabKey
  }
  local leaderboard = self.LEADERBOARD
  if leaderboard and leaderboard.GetJumpRestoreState then
    uiData.leaderboard = leaderboard:GetJumpRestoreState()
  end
  return {
    ctorData = {
      self.data
    },
    uiData = uiData
  }
end

function ModeSelection_Sideber_Main_UIBP:JumpBack(uiData)
  local tabKey = uiData and uiData.curTabKey
  if not tabKey then
    return
  end
  printf("ModeSelection_Sideber_Main_UIBP:JumpBack tabKey:%s", tabKey)
  self:SelectTabByKey(tabKey)
  local leaderboardState = uiData.leaderboard
  if leaderboardState and self.LEADERBOARD and self.LEADERBOARD.ApplyJumpRestoreState then
    self.LEADERBOARD:ApplyJumpRestoreState(leaderboardState)
  end
end

function ModeSelection_Sideber_Main_UIBP:OnInitialize()
  self.LoopScrollBox_Tab = self:InitChildClassScrollBox(self.UIRoot.ModeSelection_Sideber_Tab_Item_UIBP.LoopScrollBox_Tab, TAB_ITEM_MODULE)
  self:SetWidgetVisible(self.UIRoot.ModeSelection_Sideber_Tab_Item_UIBP, true)
  printf("ModeSelection_Sideber_Main_UIBP:OnInitialize restore tab column visible, viewId:%s", tostring(self.data and self.data.id))
  self.Common_ComboBox_Difficulty = self:InitCommonComboBoxNew(self.UIRoot.Common_ComboBox_WoW)
  self:SetWidgetVisible(self.Common_ComboBox_Difficulty, true)
  self:SetWidgetVisible(self.UIRoot.Button_Share, false, true)
  self:_ApplyRankMatchSwitcherTextOverrides()
  self:_InitMatchSettingChildren()
end

function ModeSelection_Sideber_Main_UIBP:RegistEvents()
  self:AddCommonEvent(EVENTTYPE_MATCH, EVENTID_MATCH_VIEW_FAVOURITE_UPDATE, self.OnViewFavouriteUpdate, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Closure, self.OnClickButton_Closure, self)
  self:AddOnClickedEventByControl(self.UIRoot.Common_UIPopupBG.Button_0, self.OnClickButton_Mask, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Collect, self.OnClickButton_Collect, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Share, self.OnClickButton_Share, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_PlayTogether, self.OnClickButton_PlayTogether, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_0, self.OnClickButton_RankMatchSwitch, self)
  self.Common_ComboBox_Difficulty:SetRefreshOptionCallback(self.OnRefreshComboBox_Difficulty, self)
  self.Common_ComboBox_Difficulty:SetSelectOptionCallback(self.OnSelectComboBox_Difficulty, self)
  self:AddCommonEvent(EVENTTYPE_PEAKGAME, EVENTID_PEAKGAME_INFO_UPDATE, self.OnPeakGameStateChanged, self)
  self:AddCommonEvent(EVENTTYPE_PEAKGAME, EVENTID_PEAKGAME_TIME_UPDATE, self.OnPeakGameStateChanged, self)
  self:_RegistMatchSettingEvents()
end

function ModeSelection_Sideber_Main_UIBP:OnPostInitialize()
  self:_ReportViewHistory()
  helper.RequestViewRelatedSearch(self.data.id)
  local PreloadAssetManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PreloadAssetManager)
  if PreloadAssetManager and PreloadAssetManager.UIAsyncPreloadArray then
    PreloadAssetManager:UIAsyncPreloadArray(LEADERBOARD_PRELOAD_ASSETS)
  end
  self:UpdateUI()
  if self._category == Category.Peak then
    local LogicPeakGame = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicPeakGame)
    if not LogicPeakGame:GetPeakGameCurSeasonTime() then
      local LogicPeakGameHomepage = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicPeakGameHomepage)
      LogicPeakGameHomepage:RequestHomepageShowData()
    end
  end
end

function ModeSelection_Sideber_Main_UIBP:OnClose()
  for _, tab in ipairs(TAB_CONFIG) do
    self[tab.key] = nil
  end
  self._bottomUI = nil
  self._personTips = nil
  self._langTips = nil
  self.filter_info = nil
  self._filterOrigin = nil
  self._multiSelectViewIDs = nil
end

function ModeSelection_Sideber_Main_UIBP:_ReportViewHistory()
  local viewId = self.data and self.data.id
  if not viewId then
    log_warning("ModeSelection_Sideber_Main_UIBP:_ReportViewHistory no viewId")
    return
  end
  helper.ReportViewHistory({view_id = viewId})
end

function ModeSelection_Sideber_Main_UIBP:OnClickButton_PlayTogether()
  self:PlayAudio(sound_config.click_v1)
  printf("ModeSelection_Sideber_Main_UIBP:OnClickButton_PlayTogether")
end

function ModeSelection_Sideber_Main_UIBP:OnClickButton_RankMatchSwitch()
  self:PlayAudio(sound_config.click_v1)
  if not self._bRankedSelected and not mode_selection_multi_util.CheckRankUnlocked() then
    return
  end
  if self._curTabKey == "LEADERBOARD" then
    printf("ModeSelection_Sideber_Main_UIBP:OnClickButton_RankMatchSwitch locked in leaderboard tab, bRanked:%s", tostring(self._bRankedSelected))
    return
  end
  local targetViewId = self:_GetRankMatchTargetViewId(not self._bRankedSelected)
  if not targetViewId then
    ShowDevNotice("##\230\178\161\230\156\137 targetViewId:" .. self.data.id)
    log_warning("ModeSelection_Sideber_Main_UIBP:OnClickButton_RankMatchSwitch no target view, viewId:" .. self.data.id)
    return
  end
  local logic_mode_selection = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection)
  local targetViewInfo = logic_mode_selection:GetSubviewInfoBySubviewID(targetViewId)
  if not targetViewInfo or not self._bRankedSelected and targetViewInfo.is_ranked ~= 1 or self._bRankedSelected and targetViewInfo.is_ranked == 1 then
    ShowDevNotice("##\230\151\160\230\149\136 targetView:" .. tostring(targetViewId))
    log_warning("ModeSelection_Sideber_Main_UIBP:OnClickButton_RankMatchSwitch invalid target view, viewId:" .. tostring(targetViewId))
    return
  end
  self._bRankedSelected = not self._bRankedSelected
  self._curViewId = targetViewId
  self._bCollected = self:IsCollected()
  printf("ModeSelection_Sideber_Main_UIBP:OnClickButton_RankMatchSwitch bRanked:%s, targetViewId:%s, bCollected:%s", tostring(self._bRankedSelected), tostring(self._curViewId), tostring(self._bCollected))
  self:_RefreshRankMatchSwitcherIndex()
  self:_RefreshCollect()
  if self:_RefreshTabList() == 0 and 0 < #self._visibleTabs then
    self.LoopScrollBox_Tab:Select(1)
    self:_SwitchTab(1)
  end
  self:_NotifyTabRankedState(self[self._curTabKey])
  self:RefreshStartButtonState()
end

function ModeSelection_Sideber_Main_UIBP:_GetRankMatchTargetViewId(bRanked)
  local groupViews = self.data.group_view_v2
  if not groupViews then
    return nil
  end
  local curId = self.data.id
  if bRanked == (self.data.is_ranked == 1) then
    return curId
  end
  if #groupViews ~= 2 then
    log_error("ModeSelection_Sideber_Main_UIBP:_GetRankMatchTargetViewId group_view_v2 length not 2")
  end
  for _, v in ipairs(groupViews) do
    if v.view_id and v.view_id ~= curId then
      return v.view_id
    end
  end
  return nil
end

function ModeSelection_Sideber_Main_UIBP:IsRankMatchGroupView()
  local groupViews = self.data and self.data.group_view_v2
  return self._category == Category.RankMatch and groupViews ~= nil and 1 < #groupViews
end

function ModeSelection_Sideber_Main_UIBP:IsCollected()
  if self:IsRankMatchGroupView() then
    return helper.IsViewGroupFavourited(self.data)
  end
  return helper.IsViewFavourited(self.data.id)
end

function ModeSelection_Sideber_Main_UIBP:GetCollectViewId()
  if self:IsRankMatchGroupView() then
    return self._curViewId
  end
  return self.data.id
end

function ModeSelection_Sideber_Main_UIBP:GetUncollectViewId()
  if self:IsRankMatchGroupView() then
    return helper.FindFavouritedViewId(self.data) or self._curViewId
  end
  return self.data.id
end

function ModeSelection_Sideber_Main_UIBP:_NotifyTabRankedState(tabUI)
  if tabUI and tabUI.OnRankedStateChanged then
    tabUI:OnRankedStateChanged()
  end
end

function ModeSelection_Sideber_Main_UIBP:OnRefreshComboBox_Difficulty(Widget, Data, Index)
  if not Data then
    log_warning("ModeSelection_Sideber_Main_UIBP:OnRefreshComboBox_Difficulty invalid data, index:" .. tostring(Index))
    return
  end
  local bLocked = (Data.levelLimit or 0) > DataMgr.roleData.level
  Widget.TextBlock_ItemName:SetText(Data.text or "")
  Widget.TextBlock_ItemName:SetColorAndOpacity(FSlateColor(FLinearColor(1, 1, 1, bLocked and 0.5 or 1)))
end

function ModeSelection_Sideber_Main_UIBP:OnSelectComboBox_Difficulty(Widget, Data, Index)
  self:PlayAudio(sound_config.click_v1)
  if not Data then
    log_warning("ModeSelection_Sideber_Main_UIBP:OnSelectComboBox_Difficulty invalid data, index:" .. tostring(Index))
    return
  end
  if self._groupSelectIndex == Index then
    return
  end
  local logic_mode_selection = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection)
  local selectView = self.data.group_view_v2 and self.data.group_view_v2[Index]
  local viewInfo = selectView and logic_mode_selection:GetSubviewInfoBySubviewID(selectView.view_id)
  if viewInfo and viewInfo.level_limit > DataMgr.roleData.level then
    ShowNotice(LocUtil.LocalizeResFormat(NOTICE_LEVEL_UNLOCK, viewInfo.level_limit))
    self.Common_ComboBox_Difficulty:SelectIndex(self._groupSelectIndex, true)
    return
  end
  printf("ModeSelection_Sideber_Main_UIBP:OnSelectComboBox_Difficulty index:%s", tostring(Index))
  self._groupSelectIndex = Index
  self._curViewId = selectView.view_id
  helper.SaveGroupSelectIndex(self.data.id, Index)
  self:RefreshStartButtonState()
end

function ModeSelection_Sideber_Main_UIBP:OnClickButton_Share()
  self:PlayAudio(sound_config.click_v1)
  if not GameStatus.IsInLobbyOrMainCity() then
    ShowNotice(NOTICE_SHARE_IN_GAME)
    return
  end
  local shareCfg = helper.BuildShareConfig(self.data or {}, self._category, self:_GetShareContent())
  self:OnClickShareFriendImplement(shareCfg, nil)
  local ShareMgr = require("client.logic.share.share_logic")
  ShareMgr.ReportClickShare("OnClickButton_Share")
  ShareMgr.ShareBtnReq(1, ShareBtnTLogShareTypeDefine.ModeSelection470Share, nil, nil)
end

function ModeSelection_Sideber_Main_UIBP:_GetShareContent()
  return helper.GetViewTitleText(self.data)
end

function ModeSelection_Sideber_Main_UIBP:OnClickButton_Collect()
  local collectViewId = self._bCollected and self:GetUncollectViewId() or self:GetCollectViewId()
  printf("ModeSelection_Sideber_Main_UIBP:OnClickButton_Collect viewId:%s, bCollected:%s", collectViewId, self._bCollected)
  self:PlayAudio(sound_config.click_v1)
  local UIUtil = require("client.common.ui_util")
  if not UIUtil.CanClickNow(UIUtil.ClickFrequencyLimit.ModeSelectionSideberCollect) then
    printf("ModeSelection_Sideber_Main_UIBP:OnClickButton_Collect blocked by click cd")
    return
  end
  self._bCollected = not self._bCollected
  helper.SendCollectOp(collectViewId, self._bCollected)
  self:_RefreshCollect()
end

function ModeSelection_Sideber_Main_UIBP:OnClickButton_Closure()
  self:PlayAudio(sound_config.click_v1)
  printf("ModeSelection_Sideber_Main_UIBP:OnClickButton_Closure")
  self:CloseSelf()
end

function ModeSelection_Sideber_Main_UIBP:OnClickButton_Mask()
  printf("ModeSelection_Sideber_Main_UIBP:OnClickButton_Mask")
  self:OnClickButton_Closure()
end

function ModeSelection_Sideber_Main_UIBP:OnViewFavouriteUpdate()
  if not self.data then
    return
  end
  local bCollected = self:IsCollected()
  if bCollected == self._bCollected then
    return
  end
  self._bCollected = bCollected
  self:_RefreshCollect()
end

function ModeSelection_Sideber_Main_UIBP:OnPeakGameStateChanged()
  if self._category ~= Category.Peak or not self.UIRoot then
    return
  end
  printf("ModeSelection_Sideber_Main_UIBP:OnPeakGameStateChanged")
  if self:_RefreshTabList() > 0 then
    return
  end
  if 0 < #self._visibleTabs then
    self.LoopScrollBox_Tab:Select(1)
    self:_SwitchTab(1)
  else
    log_warning("ModeSelection_Sideber_Main_UIBP:OnPeakGameStateChanged no visible tab")
  end
end

function ModeSelection_Sideber_Main_UIBP:UpdateUI()
  log(bWriteLog and "ModeSelection_Sideber_Main_UIBP:UpdateUI")
  self:_RefreshTabList()
  local initialTabKey = self._initialTabKey
  local bSelectedFriendStatus = not initialTabKey and self:_HasPendingFriendStatusView() and self:SelectTabByKey("FRIEND_STATUS")
  if initialTabKey then
    self:SelectInitialTab(initialTabKey)
  elseif not bSelectedFriendStatus then
    if #self._visibleTabs > 0 then
      self.LoopScrollBox_Tab:Select(1)
      self:_SwitchTab(1)
    else
      log_warning("ModeSelection_Sideber_Main_UIBP:UpdateUI no visible tab")
    end
  end
  self:_RefreshTopInfo()
  self:_RefreshMatchSetting()
  self._bottomUI:SetCategory(self._category)
  self._bottomUI:SetSimpleMode(self._category == Category.SocialTrainMetro)
end

function ModeSelection_Sideber_Main_UIBP:_RefreshTopInfo()
  local data = self.data or {}
  self.UIRoot.Text_ModeName:SetText(helper.GetViewTitleText(data) or "")
  if self.UIRoot.UTRichTextBlock_Time then
    local logic_mode_selection = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection)
    local _, timeStr = logic_mode_selection:GetTimeLimitStr(data)
    self.UIRoot.UTRichTextBlock_Time:SetText(timeStr or "")
  end
  self:_RefreshTopSwitcher()
  self:_RefreshCollect()
end

function ModeSelection_Sideber_Main_UIBP:_RefreshTopSwitcher()
  local groupViews = self.data.group_view_v2
  local groupCount = groupViews and #groupViews or 0
  local bRankMatch = self._category == Category.RankMatch and 1 < groupCount
  local bAiMode = self.data.group_type == "group" and 0 < groupCount
  if not bRankMatch and not bAiMode then
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_0, false)
    return
  end
  self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_0, true)
  if bRankMatch then
    self.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(SWITCHER_PAGE.RankMatch)
    self:_RefreshRankMatchSwitcherIndex()
  else
    self.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(SWITCHER_PAGE.AiDifficulty)
    self:_RefreshAiDifficultyCombo()
  end
end

function ModeSelection_Sideber_Main_UIBP:_RefreshRankMatchSwitcherIndex()
  local switcherIndex
  if mode_selection_multi_util.IsRankLocked() then
    switcherIndex = SWITCHER_EXT_INDEX.MatchWithRankLock
  elseif self._bRankedSelected then
    switcherIndex = self._curTabKey == "LEADERBOARD" and SWITCHER_EXT_INDEX.RankedWithMatchLock or SWITCHER_EXT_INDEX.Ranked
  else
    switcherIndex = SWITCHER_EXT_INDEX.Match
  end
  printf("ModeSelection_Sideber_Main_UIBP:_RefreshRankMatchSwitcherIndex index:%s, bRanked:%s, tabKey:%s", tostring(switcherIndex), tostring(self._bRankedSelected), tostring(self._curTabKey))
  self.UIRoot.WidgetSwitcherExt_0:SetActiveWidgetIndex(switcherIndex)
end

function ModeSelection_Sideber_Main_UIBP:_ApplyRankMatchSwitcherTextOverrides()
  local text = LocUtil.GetLocalizeResStr(512213)
  for name, index in pairs(SWITCHER_EXT_INDEX) do
    local bOk = self.UIRoot.WidgetSwitcherExt_0:SetOverrideText(index, self.UIRoot.TextBlock_3, "Text", text)
  end
end

function ModeSelection_Sideber_Main_UIBP:_RefreshAiDifficultyCombo()
  local logic_mode_selection = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection)
  local comboData = {}
  for _, v in ipairs(self.data.group_view_v2 or {}) do
    local viewInfo = logic_mode_selection:GetSubviewInfoBySubviewID(v.view_id)
    comboData[#comboData + 1] = {
      text = LocUtil.GetLocalizeResStr(v.show_name),
      levelLimit = viewInfo and viewInfo.level_limit or 0
    }
  end
  self.Common_ComboBox_Difficulty:SetData(comboData, self._groupSelectIndex, true)
end

function ModeSelection_Sideber_Main_UIBP:_RefreshCollect()
  if self.UIRoot.WidgetSwitcher_Collect then
    self.UIRoot.WidgetSwitcher_Collect:SetActiveWidgetIndex(self._bCollected and 1 or 0)
  end
end

function ModeSelection_Sideber_Main_UIBP:_RefreshTabList()
  self._visibleTabs = {}
  for _, tab in ipairs(TAB_CONFIG) do
    if self:_IsTabVisible(tab) then
      self._visibleTabs[#self._visibleTabs + 1] = tab
    end
  end
  self.LoopScrollBox_Tab:SetData(self._visibleTabs)
  for index, tab in ipairs(self._visibleTabs) do
    if tab.key == self._curTabKey then
      self.LoopScrollBox_Tab:Select(index)
      return index
    end
  end
  return 0
end

function ModeSelection_Sideber_Main_UIBP:_IsTabVisible(tab)
  local rule = TAB_VISIBLE_RULE[tab.key]
  if rule == nil then
    return false
  end
  if rule == true or rule == false then
    return rule
  end
  local bVisible = rule(self.data, self) == true
  printf("ModeSelection_Sideber_Main_UIBP:_IsTabVisible key:%s, visible:%s", tab.key, bVisible)
  return bVisible
end

function ModeSelection_Sideber_Main_UIBP:OnSideberTabClicked(index, tabData)
  printf("ModeSelection_Sideber_Main_UIBP:OnSideberTabClicked index:%s, key:%s", tostring(index), tabData and tostring(tabData.key) or "nil")
  self:_SwitchTab(index)
end

function ModeSelection_Sideber_Main_UIBP:SelectTabByKey(tabKey)
  if not tabKey or not self._visibleTabs then
    return false
  end
  for index, tab in ipairs(self._visibleTabs) do
    if tab.key == tabKey then
      if self.LoopScrollBox_Tab then
        self.LoopScrollBox_Tab:Select(index)
      end
      self:_SwitchTab(index)
      return true
    end
  end
  log_warning("ModeSelection_Sideber_Main_UIBP:SelectTabByKey no tab, key:" .. tostring(tabKey))
  return false
end

function ModeSelection_Sideber_Main_UIBP:SelectInitialTab(tabKey)
  self._initialTabKey = tabKey
  if not self._visibleTabs then
    return false
  end
  self._initialTabKey = nil
  local targetIndex = 1
  for index, tab in ipairs(self._visibleTabs) do
    if tab.key == tabKey then
      targetIndex = index
      break
    end
  end
  if not self._visibleTabs[targetIndex] then
    return false
  end
  self.LoopScrollBox_Tab:Select(targetIndex)
  self:_SwitchTab(targetIndex)
  return true
end

function ModeSelection_Sideber_Main_UIBP:SelectFriendStatusTab(bShowFeed)
  if not TAB_VISIBLE_RULE.FRIEND_STATUS() then
    printf("ModeSelection_Sideber_Main_UIBP:SelectFriendStatusTab disabled in current region, skip")
    return false
  end
  local logic_friendfeed_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friendfeed_data)
  if logic_friendfeed_data and logic_friendfeed_data.SetPendingFriendStatusView then
    logic_friendfeed_data:SetPendingFriendStatusView(bShowFeed)
  end
  if not self._visibleTabs then
    return false
  end
  return self:SelectTabByKey("FRIEND_STATUS")
end

function ModeSelection_Sideber_Main_UIBP:_HasPendingFriendStatusView()
  if not TAB_VISIBLE_RULE.FRIEND_STATUS() then
    return false
  end
  local logic_friendfeed_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friendfeed_data)
  if not logic_friendfeed_data or not logic_friendfeed_data.PeekPendingFriendStatusView then
    return false
  end
  return logic_friendfeed_data:PeekPendingFriendStatusView() ~= nil
end

function ModeSelection_Sideber_Main_UIBP:_RefreshTabListColor(index)
  self.UIRoot.Image_117:SetActiveColorIndex(index == 1 and 0 or 1)
end

function ModeSelection_Sideber_Main_UIBP:_SwitchTab(index)
  local tab = self._visibleTabs and self._visibleTabs[index]
  if not tab then
    log_warning("ModeSelection_Sideber_Main_UIBP:_SwitchTab invalid index:" .. tostring(index))
    return
  end
  self:_RefreshTabListColor(index)
  if self._curTabKey == tab.key then
    self:_NotifyFriendStatusPage(tab)
    return
  end
  if self._curTabKey and self[self._curTabKey] then
    self[self._curTabKey]:Hide()
  end
  local uiKey = self:_GetTabUIKey(tab)
  printf("ModeSelection_Sideber_Main_UIBP:_SwitchTab key:%s, UIKey:%s", tostring(tab.key), tostring(uiKey))
  self:_RefreshTabContentSpacer(uiKey)
  if self[tab.key] then
    self[tab.key]:Show()
  else
    local uiConfig = UIManager.UI_Config[uiKey]
    if uiConfig then
      self[tab.key] = self:CreateChildWindow(self.UIRoot.Panel_TabContent, uiConfig, self.data)
      self:_NotifyTabFilterInfo(self[tab.key])
    else
      log_error("ModeSelection_Sideber_Main_UIBP:_SwitchTab uiConfig not found:" .. tostring(uiKey))
    end
  end
  self._curTabKey = tab.key
  self:_RefreshRankMatchSwitcherIndex()
  self:_NotifyFriendStatusPage(tab)
  self:_PlayTabEnterAnim(self[tab.key])
end

function ModeSelection_Sideber_Main_UIBP:_PlayTabEnterAnim(childUI)
  if not childUI or childUI:IsAsyncLoading() then
    return
  end
  local anim = childUI.UIRoot and childUI.UIRoot.Auto_Fadein
  if not anim then
    log_warning("ModeSelection_Sideber_Main_UIBP:_PlayTabEnterAnim no Auto_Fadein, key:" .. tostring(self._curTabKey))
    return
  end
  childUI:PlayUserWidgetAnimation(anim, 0, 1, 0, 1)
end

function ModeSelection_Sideber_Main_UIBP:_NotifyFriendStatusPage(tab)
  if tab.key ~= "FRIEND_STATUS" then
    return
  end
  local page = self.FRIEND_STATUS
  if page and page.ApplyPendingView then
    page:ApplyPendingView()
  end
end

function ModeSelection_Sideber_Main_UIBP:_GetTabUIKey(tab)
  if type(tab.UIKey) == "function" then
    return tab.UIKey(self)
  end
  return tab.UIKey
end

function ModeSelection_Sideber_Main_UIBP:_RefreshTabContentSpacer(uiKey)
  self:SetWidgetVisible(self.UIRoot.Spacer_1, uiKey ~= DETAIL_UIKEY_THEMED_GAMEPLAY)
end

function ModeSelection_Sideber_Main_UIBP:_InitMatchSettingChildren()
  self.filter_info = helper.BuildFilterInfoCopy(self.data, self._category)
  self._filterOrigin = TableUtil.CopyTable(self.filter_info)
  local UIComponentModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule)
  self._bottomUI = UIComponentModule:InitWithParentComponent(self, UIComponentModule.Config.ModeSelection_Sideber_BottomContent_Item_UIBP, self.UIRoot.BottomContent_Item_UIBP)
  self._personTips = UIComponentModule:InitWithParentComponent(self, UIComponentModule.Config.ModeSelection_Sideber_PersonSetTips_Item_UIBP, self.UIRoot.ModeSelection_Sideber_PersonSetTips_Item_UIBP)
  self._langTips = UIComponentModule:InitWithParentComponent(self, UIComponentModule.Config.ModeSelection_Sideber_LanguageSetTips_Item_UIBP, self.UIRoot.ModeSelection_Sideber_LanguageSetTips_Item_UIBP)
  self:_SetPersonPanelVisible(false)
  self:_SetLangPanelVisible(false)
end

function ModeSelection_Sideber_Main_UIBP:_RegistMatchSettingEvents()
  self:AddCommonEvent(EVENTTYPE_MODE_SELECTION_SIDEBER, EVENTID_MODE_SELECTION_SIDEBER_START_CLICK, self.OnStartButtonClicked, self)
  self:AddCommonEvent(EVENTTYPE_MATCH, EVENTID_MATCH_UPDATE_LANGUAGE, self.OnMatchLanguageUpdated, self)
  self:AddCommonEvent(EVENTTYPE_MATCH, EVENTID_MATCH_UPDATE_LANGUAGE_TEAM, self.OnMatchLanguageUpdated, self)
  self:AddCommonEvent(EVENTTYPE_MATCH, EVENTID_MATCH_VIEW_SELECT_CHANGE, self.OnMatchViewSelectChanged, self)
end

function ModeSelection_Sideber_Main_UIBP:SetMultiSelectViewIDs(viewIDs)
  self._multiSelectViewIDs = viewIDs
end

function ModeSelection_Sideber_Main_UIBP:CommitFilterInfo()
  if not helper.CommitModeSelection(self.data, self._category, self.filter_info, self._filterOrigin, self._curViewId, self._multiSelectViewIDs) then
    return false
  end
  self._filterOrigin = TableUtil.CopyTable(self.filter_info)
  return true
end

function ModeSelection_Sideber_Main_UIBP:CloseModeSelection()
  printf("ModeSelection_Sideber_Main_UIBP:CloseModeSelection")
  self:CloseSelf()
  helper.CloseModeSelectionUI()
end

function ModeSelection_Sideber_Main_UIBP:OnStartButtonClicked(_, _, state)
  printf("ModeSelection_Sideber_Main_UIBP:OnStartButtonClicked, state:%s", tostring(state))
  if state == START_BUTTON_STATE.GO_6 then
    helper.EnterSocialTrainMetroGameplay(self.data, function()
      self:CloseSelf()
    end)
  elseif state == START_BUTTON_STATE.Download_5 then
    helper.ToggleMapDownload(self._curViewId, self.data)
  elseif self:CommitFilterInfo() then
    self:CloseModeSelection()
  end
end

function ModeSelection_Sideber_Main_UIBP:OnMatchSettingClicked()
  self:_SetPersonPanelVisible(not self._bPersonPanelOpen)
end

function ModeSelection_Sideber_Main_UIBP:OnLanguageEntryClicked()
  self:_SetLangPanelVisible(not self._bLangPanelOpen)
end

function ModeSelection_Sideber_Main_UIBP:OnArenaClicked()
  printf("ModeSelection_Sideber_Main_UIBP:OnArenaClicked category:%s", tostring(self._category))
  if not helper.IsArenaMapDownloaded() then
    printf("ModeSelection_Sideber_Main_UIBP:OnArenaClicked arena map not downloaded, skip")
    ShowNotice(NOTICE_ARENA_MAP_NOT_DOWNLOAD)
    return
  end
  local PrepareSchemeSystem = require("client.slua.logic.prepareScheme.logic_prepare_scheme")
  PrepareSchemeSystem.OpenPrepareSchemeMain()
  local tlog_report_utils = require("client.slua.config.tlog.tlog_report_utils")
  tlog_report_utils.ReportTLogEvent(TLogEventDefine.NewModeSelection_ClickArena)
  local ArenaRedDotSystem = require("client.slua.logic.arena.logic_AW_red_dot")
  ArenaRedDotSystem.SetEntranceRedState()
end

function ModeSelection_Sideber_Main_UIBP:_SetPersonPanelVisible(bShow)
  self._bPersonPanelOpen = bShow and true or false
  if self._bPersonPanelOpen then
    self._personTips:SetData(self.filter_info, self.data)
    self._personTips:Show()
  else
    self._personTips:Hide()
  end
end

function ModeSelection_Sideber_Main_UIBP:_SetLangPanelVisible(bShow)
  self._bLangPanelOpen = bShow and true or false
  if self._bLangPanelOpen then
    self._langTips:RefreshLanguage()
    self._langTips:Show()
  else
    self._langTips:Hide()
  end
end

function ModeSelection_Sideber_Main_UIBP:OnPersonTipsClosed()
  self._bPersonPanelOpen = false
end

function ModeSelection_Sideber_Main_UIBP:OnLanguageTipsClosed()
  self._bLangPanelOpen = false
end

function ModeSelection_Sideber_Main_UIBP:OnAutoFillToggled(bWantOn)
  printf("ModeSelection_Sideber_Main_UIBP:OnAutoFillToggled bWantOn:%s", tostring(bWantOn))
  bWantOn = bWantOn and true or false
  if self.filter_info.isEnableFill == false then
    printf("ModeSelection_Sideber_Main_UIBP:OnAutoFillToggled blocked, fill immutable, viewId:%s", tostring(self.data and self.data.id))
    return
  end
  if self.filter_info.bAutoFill == true == bWantOn then
    return
  end
  if not helper.ApplyAutoFill(self.filter_info, bWantOn) then
    self:_RefreshBottomAutoFill()
  end
end

function ModeSelection_Sideber_Main_UIBP:OnLanguageToggled(bWantOn)
  printf("ModeSelection_Sideber_Main_UIBP:OnLanguageToggled bWantOn:%s", tostring(bWantOn))
  if not helper.ToggleLanguageMatch(bWantOn and true or false) then
    self:_RefreshBottomLanguage()
  end
end

function ModeSelection_Sideber_Main_UIBP:OnPersonSettingChanged(kind, value)
  printf("ModeSelection_Sideber_Main_UIBP:OnPersonSettingChanged kind:%s, value:%s", tostring(kind), tostring(value))
  if not helper.ApplyPersonSetting(self.data, self.filter_info, kind, value) then
    return
  end
  self:_RefreshMatchSetting()
  self._personTips:SetData(self.filter_info, self.data)
end

function ModeSelection_Sideber_Main_UIBP:OnMatchLanguageUpdated()
  self:_RefreshBottomLanguage()
  self._langTips:RefreshLanguage()
end

function ModeSelection_Sideber_Main_UIBP:OnMatchViewSelectChanged()
  self.filter_info = helper.BuildFilterInfoCopy(self.data, self._category)
  self:_RefreshMatchSetting()
  if self._bPersonPanelOpen then
    self._personTips:SetData(self.filter_info, self.data)
  end
end

function ModeSelection_Sideber_Main_UIBP:_RefreshMatchSetting()
  self._bottomUI:SetData(self.filter_info)
  self:_NotifyTabFilterInfo(self[self._curTabKey])
  self:RefreshStartButtonState()
end

function ModeSelection_Sideber_Main_UIBP:_NotifyTabFilterInfo(tabUI)
  if tabUI and tabUI.OnFilterInfoChanged then
    tabUI:OnFilterInfoChanged(self.filter_info)
  end
end

function ModeSelection_Sideber_Main_UIBP:_RefreshBottomAutoFill()
  self._bottomUI:RefreshAutoFillToggle()
end

function ModeSelection_Sideber_Main_UIBP:_RefreshBottomLanguage()
  self._bottomUI:RefreshLanguageToggle()
end

function ModeSelection_Sideber_Main_UIBP:RefreshStartButtonState()
  local startUI = self._bottomUI and self._bottomUI:GetStartUI()
  if not startUI then
    return
  end
  startUI:SetMatchContext(self.data, self.filter_info, self._bRankedSelected, self._curViewId, self._multiSelectViewIDs)
end

local Trait = require("common.trait")
local ui_base = require("client.slua_ui_framework.base")
local Traits = {
  require("client.slua.umg.common.share.share_use_trait")
}
return Trait.TraitClass(ui_base, nil, ModeSelection_Sideber_Main_UIBP, Traits)
