do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(96, 11, 35, 100, 31)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 156, 43, 196, 153, 129, 54, 92, 76, 178, 221, 212, 199, 212, 182, 243, 97, 166, 52, 210, 212, 134))), nil, {
  ["ctor"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.type = _ARG_2_
      _ARG_0_.jumpInfo = nil
      _ARG_0_.isOnlyShow = false
      _ARG_0_.curSelectUid = _ENV()
      _ARG_0_.IsRankListClose = false
      _ARG_0_.curParentTab = U1.No
      _ARG_0_.isForJumpShow = nil
      _ARG_0_.foldTab = true
      _ARG_0_.lbsTwoComboUI = nil
      _ARG_0_.continentCountryCfgList = nil
      _ARG_0_.delayShow = true
      _ARG_0_.bWeaponKillRankRegionOpen = false
      _ARG_0_.weaponKillRankRegionSelectIndex = 1
      _ARG_0_.weaponKillRankRegionList = nil
      _ARG_0_.weaponKillRankWeaponTypeList = nil
      _ARG_0_.pendingWeaponKillRankRegion = nil
      _ARG_0_.pendingWeaponKillRankWeaponType = nil
      _ARG_0_.pendingWeaponKillRankWeapon = nil
      _ARG_0_.KillCounterItem = nil
      _ARG_0_.peakGameRankUIBPINSList = {}
      _ARG_0_.DownloadScene = U2.require((U2.table.concat({
        _ENV(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 86, 72, 235, 198, 209, 247, 199, 179, 179, 120, 156, 38, 220, 213, 151, 105, 82, 66, 234, 222, 200, 250),
        _ENV(92, 19, 46, 120, 11)
      }))).Enum_DownloadDoubleConfirmScene.Lobby_Main_Rank
      _ARG_0_.OptForceDownload = true
      _ARG_0_.isDefaultSelect = true
      _ARG_0_.resTypeCallbackMap = {
        [U2.require((_ENV(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 86, 72, 235, 198, 209, 247, 199, 179, 179, 122, 140, 48, 213, 194, 145, 24, 65, 88, 226, 203, 217))).ENUM_ResType.LevelBG] = function()
          _ENV:RefreshLevelBGAfterDownload()
          return
        end
      }
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 236, 217, 186, 57, 91, 83, 245, 201, 209, 241, 220, 178), _ARG_0_)
      U2.__super.OnInitialize(_ARG_0_)
      _ARG_0_.UIRoot.SizeBox_rank:SetWidthOverride(U3.ContentSize.rankWidth)
      _ARG_0_.UIRoot.SizeBox_roleName:SetWidthOverride(U3.ContentSize.avatarWidth)
      _ARG_0_.UIRoot.SizeBox_reward:SetWidthOverride(U3.ContentSize.rewardWidth)
      _ARG_0_.Common_Tab_Vertical_LevelOne_Text_UIBP = _ARG_0_:InitVerticalTextTab(_ARG_0_.UIRoot.Common_Tab_Vertical_LevelOne_Text_UIBP, true, true)
      _ARG_0_.LoopScrollBox_RankList = _ARG_0_:InitChildClassScrollBox(_ARG_0_.UIRoot.LoopScrollBox_RankList, (table.concat({
        U1(68, 6, 47, 114, 32, 237, 172, 134, 251, 168, 233, 52, 165, 41, 193, 213, 138, 121, 97, 87, 240, 193, 201, 182, 244, 182, 243, 97, 215, 35, 222, 192, 205, 21, 67, 89, 231, 231, 225, 225),
        U1(112, 19, 29, 94, 24, 253, 160, 247, 227, 142, 207, 74, 182, 114, 151, 135)
      })))
      _ARG_0_.Common_ComboBox_MemberType = _ARG_0_:InitCommonComboBoxNew(_ARG_0_.UIRoot.Common_ComboBox_MemberType)
      _ARG_0_.Common_ComboBox_PlanPH = _ARG_0_:InitCommonComboBoxNew(_ARG_0_.UIRoot.Common_ComboBox_PlanPH)
      _ARG_0_.Common_ComboBox_WoW = _ARG_0_:InitCommonComboBoxNew(_ARG_0_.UIRoot.Common_ComboBox_WoW)
      _ARG_0_.Common_ComboBox_WeaponType = _ARG_0_:InitCommonComboBoxNew(_ARG_0_.UIRoot.Common_ComboBox_WeaponType)
      _ARG_0_.Common_ComboBox_Weapon = _ARG_0_:InitCommonComboBoxNew(_ARG_0_.UIRoot.Common_ComboBox_Weapon)
      _ARG_0_.Common_ComboBox_ZoneList = _ARG_0_:InitCommonComboBoxNew(_ARG_0_.UIRoot.Common_ComboBox_ZoneList)
      _ARG_0_.Common_ComboBox_Continent = _ARG_0_:InitCommonComboBoxNew(_ARG_0_.UIRoot.Common_ComboBox_Continent)
      _ARG_0_.Common_ComboBox_Country = _ARG_0_:InitCommonComboBoxNew(_ARG_0_.UIRoot.Common_ComboBox_Country)
      _ARG_0_.LoopScrollGrid_WeaponKillRankRegion = _ARG_0_:InitChildClassScrollBox(_ARG_0_.UIRoot.Rank_Career_ComboBox_Item.LoopScrollGrid_0, (table.concat({
        U1(68, 6, 47, 114, 32, 237, 172, 134, 251, 168, 233, 52, 165, 41, 193, 213, 138, 121, 97, 87, 240, 193, 201, 182, 244, 182, 243, 97, 215, 35, 222, 192, 205, 14, 86, 82, 225, 150, 238, 231),
        U1(110, 5, 45, 85, 3, 224, 227, 250, 215, 169, 230, 69, 170, 39, 209, 210, 150, 37, 109, 100, 243, 197, 223, 247, 228, 184, 229, 94, 156, 46, 199, 151, 209, 24, 107, 67, 233, 213)
      })))
      _ARG_0_.LoopScrollGrid_WeaponKillRankWeaponType = _ARG_0_:InitChildClassScrollBox(_ARG_0_.UIRoot.Rank_Career_ComboBox_Item.LoopScrollGrid_2, (table.concat({
        U1(68, 6, 47, 114, 32, 237, 172, 134, 251, 168, 233, 52, 165, 41, 193, 213, 138, 121, 97, 87, 240, 193, 201, 182, 244, 182, 243, 97, 215, 35, 222, 192, 205, 14, 86, 82, 225, 150, 238, 231),
        U1(110, 5, 45, 85, 3, 224, 227, 250, 215, 169, 230, 69, 170, 39, 209, 210, 150, 37, 109, 100, 243, 197, 223, 247, 228, 184, 229, 94, 156, 46, 199, 151, 209, 24, 107, 67, 233, 213)
      })))
      _ARG_0_.LoopScrollGrid_WeaponKillRankWeapon = _ARG_0_:InitChildClassScrollBox(_ARG_0_.UIRoot.Rank_Career_ComboBox_Item.LoopScrollGrid_3, (table.concat({
        U1(68, 6, 47, 114, 32, 237, 172, 134, 251, 168, 233, 52, 165, 41, 193, 213, 138, 121, 97, 87, 240, 193, 201, 182, 244, 182, 243, 97, 215, 35, 222, 192, 205, 14, 86, 82, 225, 150, 238, 231),
        U1(110, 5, 45, 85, 3, 224, 227, 250, 215, 169, 230, 69, 170, 39, 209, 210, 150, 37, 109, 100, 243, 197, 223, 247, 228, 184, 229, 94, 156, 46, 199, 151, 208, 24, 107, 67, 233, 213)
      })))
      if _ARG_0_.UIRoot.CanvasPanel_KillCounter then
        _ARG_0_.KillCounterItem = _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.CanvasPanel_KillCounter, UIManager.UI_Config.Collect_Award_Preview_KillCounter_Item)
      end
      _ARG_0_.Lua_RankListItem_UIBP_C_3 = require((table.concat({
        U1(68, 6, 47, 114, 32, 237, 172, 134, 251, 168, 233, 52, 165, 41, 193, 213, 138, 121, 97, 87, 240, 193, 201, 182, 244, 182, 243, 97, 215, 35, 222, 192, 205, 21, 67, 89, 231, 231, 225, 225),
        U1(112, 19, 29, 94, 24, 253, 160, 247, 227, 142, 207, 74, 182, 114, 151, 135)
      })))()
      if not _ARG_0_.vng18IconUI then
        _ARG_0_.vng18IconUI = require((U1(96, 11, 43, 114, 2, 236, 227, 203, 217, 170, 224, 117, 135, 104, 214, 222, 172, 34, 70, 78, 240))).InitChildWindow18Logo(_ARG_0_, U1(64, 6, 44, 97, 13, 235, 157, 201, 216, 162, 225, 69, 219, 112), 0.15, 0, 0, -20, 100)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      _ARG_0_.Common_Tab_Vertical_LevelOne_Text_UIBP:AddOnTabSelectedCallback(_ARG_0_.OnSelectTab, _ARG_0_)
      _ARG_0_.Common_Tab_Vertical_LevelOne_Text_UIBP:AddOnSubTabSelectedCallback(_ARG_0_.OnSelectSubTab, _ARG_0_)
      _ARG_0_.Common_Tab_Vertical_LevelOne_Text_UIBP:AddOnTabRefreshCallback(_ARG_0_.OnRefreshTab, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostInitialize"] = function(_ARG_0_)
    do
      __super.OnPostInitialize(_ARG_0_)
      U1.SetRankSelectType(_ARG_0_.type)
      U2.BeforeOpening()
      U2.InitRankData()
      U2.ReportHandle()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShow"] = function(_ARG_0_)
    do
      __super.OnShow(_ARG_0_)
      _ARG_0_.bInitShow = false
      _ARG_0_:InitRankUI()
      _ARG_0_:ChangeIsOnlyShow(true)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitRankUI"] = function(_ARG_0_)
    do
      _ARG_0_:SetLocalText(102104, _ARG_0_.UIRoot.TextBlock_Grid_RankIndex)
      _ARG_0_:SetLocalText(102123, _ARG_0_.UIRoot.TextBlock_SwitchRange_All)
      _ARG_0_:SetLocalText(102124, _ARG_0_.UIRoot.TextBlock_SwitchRang_Friend)
      _ARG_0_:SetLocalText(102125, _ARG_0_.UIRoot.TextBlock_77)
      _ARG_0_:SetLocalText(102126, _ARG_0_.UIRoot.TextBlockMe)
      _ARG_0_:SetLocalText(102127, _ARG_0_.UIRoot.RankListItem_UIBP_C_3.TextBlockNoRank)
      _ARG_0_.UIRoot.TextBlock_Grid_PlayerName2:SetText(LocUtil.LocalizeResFormat(43255))
      _ARG_0_:SetLocalText(64747, _ARG_0_.UIRoot.TextBlock_Empty)
      _ARG_0_.UIRoot.TextBlock_FameHall:SetText(LocUtil.LocalizeResFormat(1050634))
      _ARG_0_:InitMemberType()
      _ARG_0_:InitPlanPHType()
      _ARG_0_:InitWoWAuthorType()
      _ARG_0_:RefreshRankUI()
      _ARG_0_:ShowUIHandle()
      _ARG_0_:InitTabs()
      _ARG_0_:PlayUserWidgetAnimation(_ARG_0_.UIRoot.DX_Transitions_Enter, 0, 1, 0, 1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowRewardItem"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 240, 223, 156, 32, 96, 66, 235, 201, 207, 252, 239, 163, 248, 103))
      if _ARG_0_.UIRoot.HideRoleInfoPanel and _ARG_0_.UIRoot.HideRoleInfoPanel:IsVisible() then
        log(bWriteLog and table.concat({
          U1(88, 18, 43, 72, 30, 249, 163, 195, 235, 148, 229, 117, 158, 20, 198, 192, 146, 37, 86, 110, 232, 205, 208, 184, 199, 161, 252, 126, 152, 36, 147, 201, 140, 51, 2, 68, 228, 215, 218, 178),
          U1(35)
        }))
        return
      end
      if not _ARG_1_ then
        return
      end
      if U2.GetRankRewardItem(U2.GetRankSelectType(), _ARG_1_.no, (U2.GetRankPeriodType())) and tonumber((U2.GetRankRewardItem(U2.GetRankSelectType(), _ARG_1_.no, (U2.GetRankPeriodType())))) > 0 and require((table.concat({
        U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 70, 66, 253, 197, 200, 232, 136, 187, 242, 109, 144, 53, 236, 211, 134, 38, 79, 66, 252, 231, 204, 235),
        U1(119, 14, 45, 121)
      }))).GetEffectConfigByItemID((U2.GetRankRewardItem(U2.GetRankSelectType(), _ARG_1_.no, (U2.GetRankPeriodType())))) then
      end
      if U2.GetRankRewardItem2(U2.GetRankSelectType(), _ARG_1_.no, (U2.GetRankPeriodType())) and 0 < tonumber((U2.GetRankRewardItem2(U2.GetRankSelectType(), _ARG_1_.no, (U2.GetRankPeriodType())))) and require((table.concat({
        U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 70, 66, 253, 197, 200, 232, 136, 187, 242, 109, 144, 53, 236, 211, 134, 38, 79, 66, 252, 231, 204, 235),
        U1(119, 14, 45, 121)
      }))).GetEffectConfigByItemID((U2.GetRankRewardItem2(U2.GetRankSelectType(), _ARG_1_.no, (U2.GetRankPeriodType())))) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitTabs"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 234, 217, 154, 35, 102, 70, 254, 219))
      _ARG_0_.UIRoot:SetWidgetVisibility(U2)
      goto lbl_65
      if (132).tabID == U3.GetRankSelectType() then
      else
        if (132).subData then
          goto lbl_61
          if (46).subTabID == U3.GetRankSelectType() then
          else
            ::lbl_61::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
          if 185 then
            goto lbl_67
          end
        end
        ::lbl_65::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_67::
      _ARG_0_.curSubTabIndex = 185 or 1
      if _ARG_0_.curSubTabIndex ~= 1 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUniqueStr"] = function(_ARG_0_)
    do
      do return tostring((_ARG_0_.Common_Tab_Vertical_LevelOne_Text_UIBP:GetSelectedTabIndex())) .. U1(92) .. tostring((_ARG_0_.Common_Tab_Vertical_LevelOne_Text_UIBP:GetSelectedSubTabIndex())) .. U1(92) .. tostring(_ARG_0_.curSelectIndex) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowUIHandle"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshRankListPullBack(true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVerticalTabConfig"] = function(_ARG_0_)
    do
      goto lbl_63
      if not _ARG_0_:GetHideTabMap()[(nil).tabID] then
        if (nil).subData then
          goto lbl_56
          ::lbl_56::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      ::lbl_63::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHideTabMap"] = function(_ARG_0_)
    do
      if 41 > DataMgr.season_id then
      end
      do return {
        [U1.fpp] = true,
        [U1.arena] = true,
        [U1.upass] = true,
        [U1.achievement] = true,
        [U1.career] = true,
        [U1.charisma] = true,
        [U1.planPH] = true,
        [U1.peakgame] = true,
        [U1.peakgame_kd] = true,
        [U1.peakgame_win] = true,
        [U1.wow_author] = true,
        [U1.weapon_usage_score] = true
      } end
      do return end
      _ARG_0_ = U1[90]
      _ARG_0_ = _ENV[138]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCanClickTab"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(88, 53, 35, 121, 7, 199, 152, 225, 244, 151, 210, 46, 221, 118, 254, 151, 186, 36, 113, 70, 242, 235, 209, 241, 197, 188, 201, 107, 155, 108, 147) .. tostring(_ARG_2_))
      if not _ARG_0_.Common_Tab_Vertical_LevelOne_Text_UIBP:GetTabData(_ARG_2_) then
        return
      end
      if _ARG_0_.Common_Tab_Vertical_LevelOne_Text_UIBP:GetTabData(_ARG_2_).tabID == U2.planPH and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_home_switch):CheckHomeLimit(true) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectTab"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(88, 53, 35, 121, 7, 199, 152, 225, 244, 151, 210, 46, 221, 118, 254, 151, 188, 57, 97, 66, 240, 205, 222, 236, 242, 182, 255, 48, 217) .. tostring(_ARG_2_))
      if _ARG_3_ then
        _ARG_0_:PlayAudio(sound_config.tab_v1)
        _ARG_0_.isDefaultSelect = false
      else
        _ARG_0_.isDefaultSelect = true
      end
      if _ARG_1_ == _ARG_2_ then
        return
      end
      if _ARG_0_.curSubTabIndex and _ARG_0_.curSubTabIndex ~= 1 then
        _ARG_0_.curSubTabIndex = nil
        return
      end
      if not _ARG_0_.Common_Tab_Vertical_LevelOne_Text_UIBP:GetTabData(_ARG_2_) then
        return
      end
      if _ARG_0_.Common_Tab_Vertical_LevelOne_Text_UIBP:GetTabData(_ARG_2_).subData then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectSubTab"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(88, 53, 35, 121, 7, 199, 152, 225, 244, 151, 210, 46, 221, 118, 254, 151, 188, 57, 97, 66, 240, 205, 222, 236, 245, 162, 255, 94, 152, 52, 137, 135) .. tostring(_ARG_2_))
      if _ARG_3_ then
        _ARG_0_:PlayAudio(sound_config.click_v1)
        _ARG_0_.isDefaultSelect = false
      else
        _ARG_0_.isDefaultSelect = true
      end
      if not _ARG_0_.Common_Tab_Vertical_LevelOne_Text_UIBP:GetTabData((_ARG_0_.Common_Tab_Vertical_LevelOne_Text_UIBP:GetSelectedTabIndex())) or not _ARG_0_.Common_Tab_Vertical_LevelOne_Text_UIBP:GetTabData((_ARG_0_.Common_Tab_Vertical_LevelOne_Text_UIBP:GetSelectedTabIndex())).subData then
        return
      end
      if not _ARG_0_.Common_Tab_Vertical_LevelOne_Text_UIBP:GetTabData((_ARG_0_.Common_Tab_Vertical_LevelOne_Text_UIBP:GetSelectedTabIndex())).subData[_ARG_2_] then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshTab"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and string.format(U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 236, 217, 161, 50, 84, 85, 249, 219, 213, 204, 199, 181, 189, 39, 217, 63, 221, 195, 134, 63, 24, 18, 255), tostring(_ARG_2_)))
      if not _ARG_0_.Common_Tab_Vertical_LevelOne_Text_UIBP:GetTabData(_ARG_2_) then
        return
      end
      if _ARG_0_.Common_Tab_Vertical_LevelOne_Text_UIBP:GetTabData(_ARG_2_).tabID == U2.weapon_usage_score then
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_rank_reddot):IsShowWeaponStrengthTabReddot() and _ARG_1_ and _ARG_1_.Reddot_Anchor then
      elseif _ARG_1_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitMemberType"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 234, 217, 154, 35, 127, 66, 241, 202, 216, 234, 242, 174, 237, 111, 217, 34, 210, 197, 170, 35, 2, 10, 172) .. tostring(_ARG_1_))
      if _ARG_1_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshComboBox_MemberType"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectComboBox_MemberType"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log(bWriteLog and table.concat({
        U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 236, 217, 160, 50, 94, 66, 255, 220, 254, 247, 203, 181, 242, 72, 150, 46, 236, 234, 134, 42, 64, 82, 254, 236, 212, 248),
        U1(102, 71, 43, 121, 8, 253, 181, 136, 139, 231)
      }) .. tostring(_ARG_3_) .. U1(35, 56, 49, 114, 0, 253, 174, 220, 255, 169, 233, 127, 145, 102, 158, 151) .. tostring(_ARG_4_))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_2_ then
        log(bWriteLog and table.concat({
          U1(88, 53, 35, 121, 7, 199, 152, 225, 244, 151, 210, 46, 221, 118, 254, 151, 157, 62, 94, 7, 248, 201, 201, 249, 134, 177, 242, 120, 217, 53, 220, 202, 129, 40, 2, 85, 227, 192, 141, 229),
          U1(102, 10, 32, 114, 30, 184, 185, 209, 198, 162, 183, 58)
        }) .. tostring(_ARG_3_))
        return
      end
      U2.SetRankSelectMemberType(_ARG_2_.Type)
      if _ARG_0_.bIgnoreReq then
        _ARG_0_.bIgnoreReq = false
      else
        _ARG_0_:EventQueryRank()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_3_ = U1[151]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitPlanPHType"] = function(_ARG_0_)
    do
      _ARG_0_.Common_ComboBox_PlanPH:SetData(PlanPHComboBoxConfig)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshComboBox_PlanPH"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_2_ then
        log(bWriteLog and table.concat({
          U1(118, 14, 29, 101, 13, 246, 166, 231, 216, 149, 232, 124, 155, 35, 208, 223, 176, 56, 95, 69, 243, 234, 210, 224, 249, 135, 241, 107, 151, 6, 251, 135, 135, 38, 86, 86, 172, 209, 222, 168),
          U1(106, 9, 52, 118, 0, 241, 169)
        }) .. tostring(_ARG_3_))
        return
      end
      _ARG_1_.TextBlock_ItemName:SetText(LocUtil.LocalizeResFormat(_ARG_2_.LocID))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectComboBox_PlanPH"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_2_ then
        log(bWriteLog and table.concat({
          U1(118, 14, 29, 101, 13, 246, 166, 231, 216, 149, 232, 124, 155, 35, 208, 223, 176, 56, 95, 69, 243, 234, 210, 224, 249, 135, 241, 107, 151, 6, 251, 135, 135, 38, 86, 86, 172, 209, 222, 168),
          U1(106, 9, 52, 118, 0, 241, 169)
        }) .. tostring(_ARG_3_))
        return
      end
      _ARG_1_.TextBlock_ItemName:SetText(LocUtil.LocalizeResFormat(_ARG_2_.LocID))
      U2.SetPlanPHType(_ARG_2_.Type)
      if U2.GetRankRegionType() == U3.friend then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitWoWAuthorType"] = function(_ARG_0_)
    do
      _ARG_0_.Common_ComboBox_WoW:SetData(WoWAuthorComboBoxConfig)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitWeaponUsageScoreType"] = function(_ARG_0_)
    do
      if _ARG_0_.bInitWeaponComboBox then
        log(bWriteLog and table.concat({
          U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 234, 217, 154, 35, 101, 66, 253, 216, 210, 246, 243, 164, 252, 109, 156, 5, 208, 200, 145, 34, 118, 78, 252, 221, 141, 234),
          U1(74, 9, 43, 99, 59, 253, 172, 216, 217, 169, 206, 117, 132, 36, 204, 245, 156, 47, 18, 78, 239, 136, 201, 234, 211, 178)
        }))
        return
      end
      _ARG_0_.bInitWeaponComboBox = true
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshComboBox_WoW"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_2_ then
        log(bWriteLog and table.concat({
          U1(35, 53, 35, 121, 7, 199, 152, 225, 244, 151, 210, 46, 221, 118, 153, 248, 157, 5, 87, 65, 238, 205, 206, 240, 229, 184, 240, 104, 150, 20, 220, 223, 188, 16, 77, 96, 172, 252, 204, 252),
          U1(98, 71, 43, 100, 76, 241, 163, 222, 215, 171, 228, 126)
        }) .. tostring(_ARG_3_))
        return
      end
      _ARG_1_.TextBlock_ItemName:SetText(LocUtil.LocalizeResFormat(_ARG_2_.LocID))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectComboBox_WoW"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_2_ then
        log(bWriteLog and table.concat({
          U1(35, 53, 35, 121, 7, 199, 152, 225, 244, 151, 210, 46, 221, 118, 153, 248, 157, 4, 87, 75, 249, 203, 201, 219, 201, 186, 255, 101, 187, 57, 203, 248, 180, 40, 117, 23, 200, 217, 217, 233),
          U1(35, 14, 49, 55, 5, 246, 187, 201, 218, 174, 233)
        }) .. tostring(_ARG_3_))
        return
      end
      _ARG_1_.TextBlock_ItemName:SetText(LocUtil.LocalizeResFormat(_ARG_2_.LocID))
      U2.SetWoWAuthorType(_ARG_2_.Type)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.HorizontalBox_period, U3.IsShowWeekSelection())
      if _ARG_2_.Type == U4.WoWAuthorEnum.popularity then
        U2.SetRankPeriodType(U5.week)
      else
        U2.SetRankPeriodType(U5.total)
      end
      _ARG_0_:EventQueryRank()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshComboBox_WeaponType"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_2_ then
        return
      end
      _ARG_0_ = _ARG_0_
      if require((table.concat({
        U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 69, 70, 238, 204, 207, 247, 196, 178, 179, 102, 150, 49, 218, 196, 188, 48, 67, 69, 232, 202, 194, 234),
        U1(102, 56, 37, 98, 2)
      }))):GetGunTypeArray()[U1(102, 56, 37, 98, 2)].TypeID == _ARG_2_.ID then
      else
        _ARG_0_ = _ARG_0_
      end
      if require((table.concat({
        U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 69, 70, 238, 204, 207, 247, 196, 178, 179, 102, 150, 49, 218, 196, 188, 48, 67, 69, 232, 202, 194, 234),
        U1(102, 56, 37, 98, 2)
      }))):GetGunTypeArray()[U1(102, 56, 37, 98, 2)] then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_3_ = U1.TypeName
    end
  end,
  ["OnSelectComboBox_WeaponType"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_2_ then
        return
      end
      _ARG_0_ = _ARG_0_
      if require((table.concat({
        U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 69, 70, 238, 204, 207, 247, 196, 178, 179, 102, 150, 49, 218, 196, 188, 48, 67, 69, 232, 202, 194, 234),
        U1(102, 56, 37, 98, 2)
      }))):GetGunTypeArray()[U1(102, 56, 37, 98, 2)].TypeID == _ARG_2_.ID then
      else
        _ARG_0_ = _ARG_0_
      end
      if require((table.concat({
        U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 69, 70, 238, 204, 207, 247, 196, 178, 179, 102, 150, 49, 218, 196, 188, 48, 67, 69, 232, 202, 194, 234),
        U1(102, 56, 37, 98, 2)
      }))):GetGunTypeArray()[U1(102, 56, 37, 98, 2)] then
      else
      end
      do return end
      _ARG_1_ = _ENV[180]
    end
  end,
  ["OnRefreshComboBox_Weapon"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_2_ then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectComboBox_Weapon"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_2_ then
        return
      end
      U1.SetWeaponRankID(_ARG_2_.RankID)
      U1.SetWeaponID(_ARG_2_.WeaponID)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshComboBox_ZoneList"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_2_ then
        return
      end
      _ARG_1_.TextBlock_ItemName:SetText(_ARG_2_.zone_name)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectComboBox_ZoneList"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_2_ then
        return
      end
      _ARG_1_.TextBlock_ItemName:SetText(_ARG_2_.zone_name)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_LBSSelect, false)
      U1.SetRankZoneId(_ARG_2_.zone_id)
      if _ARG_0_.bInitZoneList then
        U1.SetLBSMode(false)
        _ARG_0_:RefreshLBSSelect()
        _ARG_0_:EventQueryRank()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshComboBox_Continent"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_2_ then
        return
      end
      _ARG_1_.TextBlock_ItemName:SetText(_ARG_2_.continent_name)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectComboBox_Continent"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_2_ then
        return
      end
      _ARG_1_.TextBlock_ItemName:SetText(_ARG_2_.continent_name)
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_lbs_select_region):GetMyContinentId() == _ARG_2_.continent_id then
        goto lbl_79
        if (2).country_cfg.ID == require((U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 94, 69, 239, 134, 209, 247, 193, 190, 254, 85, 149, 52, 192))).GetMyCountry() then
        else
          ::lbl_79::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshComboBox_Country"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_2_ then
        return
      end
      _ARG_1_.TextBlock_ItemName:SetText(_ARG_2_.country_cfg.Name)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectComboBox_Country"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_2_ then
        return
      end
      _ARG_1_.TextBlock_ItemName:SetText(_ARG_2_.country_cfg.Name)
      U1.SetCountryID(_ARG_2_.country_cfg.ID)
      if U1.GetLBSMode() then
        _ARG_0_:EventQueryRank()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectWeaponKillRankFilter"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_3_ then
        return
      end
      if _ARG_1_ == _ENV(113, 2, 37, 126, 3, 246) then
        _ARG_0_.weaponKillRankRegionSelectIndex = _ARG_2_
        _ARG_0_.pendingWeaponKillRankRegion = _ARG_3_
      elseif _ARG_1_ == _ENV(116, 2, 35, 103, 3, 246, 146, 220, 207, 183, 232) then
        _ARG_0_.pendingWeaponKillRankWeaponType = _ARG_3_
        _ARG_0_.pendingWeaponKillRankWeapon = _ARG_0_:GetWeaponKillRankWeaponList(_ARG_3_.TypeID)[1]
      elseif _ARG_1_ == _ENV(116, 2, 35, 103, 3, 246) then
        _ARG_0_.pendingWeaponKillRankWeapon = _ARG_3_
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickWeaponKillRankOK"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_0_.pendingWeaponKillRankRegion then
        U1.SetLBSMode(false)
        U1.SetRankZoneId(_ARG_0_.pendingWeaponKillRankRegion.zone_id)
        log(bWriteLog and string.format(table.concat({
          U2(88, 48, 9, 69, 13, 246, 166, 245, 150, 136, 227, 89, 133, 47, 192, 220, 164, 50, 83, 87, 243, 198, 246, 241, 202, 187, 207, 107, 151, 61, 252, 236, 195, 52, 71, 67, 172, 194, 194, 230),
          U2(102, 56, 43, 115, 81, 189, 190, 132, 150, 183, 232, 116, 141, 47, 205, 208, 161, 50, 85, 78, 243, 198, 128, 189, 213)
        }), tostring(_ARG_0_.pendingWeaponKillRankRegion.zone_id), tostring(_ARG_0_.pendingWeaponKillRankRegion.name)))
      end
      log(bWriteLog and string.format(table.concat({
        U2(88, 48, 9, 69, 13, 246, 166, 245, 150, 136, 227, 89, 133, 47, 192, 220, 164, 50, 83, 87, 243, 198, 246, 241, 202, 187, 207, 107, 151, 61, 252, 236, 195, 38, 68, 67, 233, 202, 141, 251),
        U2(102, 19, 120, 55, 43, 253, 185, 250, 215, 169, 230, 73, 140, 42, 198, 212, 135, 13, 93, 73, 249, 225, 217, 165, 131, 164, 177, 42, 181, 20, 224, 234, 140, 35, 71, 10, 169, 203)
      }), tostring(U1.GetRankSelectZoneId()), tostring(U1.GetLBSMode())))
      if _ARG_0_.pendingWeaponKillRankWeapon then
        U1.SetWeaponRankID(_ARG_0_.pendingWeaponKillRankWeapon.RankID)
        U1.SetWeaponID(_ARG_0_.pendingWeaponKillRankWeapon.WeaponID)
      end
      _ARG_0_:SetWeaponKillRankRegionPanelOpen(false)
      _ARG_0_:RefreshWeaponKillRankModeName()
      _ARG_0_:EventQueryRank()
      _ARG_0_:InitReuseList()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyWeaponKillRankDefaultFilter"] = function(_ARG_0_)
    do
      if _ARG_0_.pendingWeaponKillRankRegion then
        goto lbl_23
        if (nil).zone_id == _ARG_0_.pendingWeaponKillRankRegion.zone_id then
        else
          ::lbl_23::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      elseif _ARG_0_:GetWeaponKillRankRegionList() and _ARG_0_:GetWeaponKillRankRegionList()[1] then
        goto lbl_95
        if (236).zone_id == (U1.GetRankSelectZoneId() and U1.GetRankSelectZoneId() > 0 and U1.GetRankSelectZoneId() or tonumber(require((U2(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 70, 66, 253, 197, 200, 232, 136, 187, 242, 109, 144, 53, 236, 221, 140, 41, 71))).nChooseZoneID) or 0) then
        else
          ::lbl_95::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      if 236 then
        _ARG_0_.weaponKillRankRegionSelectIndex, _ARG_0_.pendingWeaponKillRankRegion = 2, 236, 2, U1.SetRankZoneId((236).zone_id)
      end
      if _ARG_0_.pendingWeaponKillRankWeapon then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshWeaponKillRankModeName"] = function(_ARG_0_)
    do
      if not (_ARG_0_.UIRoot.Button_DropDown1 and _ARG_0_.UIRoot.TextBlock_ModeName) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshWeaponKillRankKillCounter"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.KillCounterItem or not _ARG_0_.KillCounterItem.SetKillCounterItemShowWithNum then
        return
      end
      if not IsWeaponKillRankRanking() then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_KillCounter, false)
        return
      end
      if _ARG_0_.curSelectIndex and _ARG_0_.curSelectIndex > 0 then
      end
      if not _ARG_0_.LoopScrollBox_RankList:GetItemData(_ARG_0_.curSelectIndex) then
        return
      end
      if _ARG_1_ == nil then
      end
      if _ARG_0_.LoopScrollBox_RankList:GetItemData(_ARG_0_.curSelectIndex).score == nil or 0 > _ARG_0_.LoopScrollBox_RankList:GetItemData(_ARG_0_.curSelectIndex).score then
      end
      if GetWeaponID() and 0 < GetWeaponID() then
      end
      if _ARG_0_.curSelectUid and _ARG_0_.curSelectUid ~= U2() and GetWeaponID() and 0 < GetWeaponID() then
      end
      if (not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.curSelectUid).weapon_skin[GetWeaponID()].skin_res_id or 0 >= U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.curSelectUid).weapon_skin[GetWeaponID()].skin_res_id) and _ARG_0_.curSelectUid and U1.tostring(_ARG_0_.curSelectUid) == U1.tostring(U1.DataMgr.roleData.uid) and GetWeaponID() and 0 < GetWeaponID() then
      end
      if not U1.require((U1.table.concat({
        U2(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 69, 70, 238, 204, 207, 247, 196, 178, 179, 102, 150, 49, 218, 196, 188, 48, 67, 69, 232, 202, 194, 234),
        U2(102, 56, 37, 98, 2)
      }))):GetSkinIdByWeaponID((GetWeaponID())) or 0 >= U1.require((U1.table.concat({
        U2(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 69, 70, 238, 204, 207, 247, 196, 178, 179, 102, 150, 49, 218, 196, 188, 48, 67, 69, 232, 202, 194, 234),
        U2(102, 56, 37, 98, 2)
      }))):GetSkinIdByWeaponID((GetWeaponID())) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckFppOpen"] = function(_ARG_0_)
    do
      if LobbySystem.CheckOpen(BP_ENUM_LOBBY_MENU_FPP) then
        _ARG_0_.UIRoot.Fpp_Button_Container:SetWidgetVisibility(U1)
        _ARG_0_.UIRoot.Fpp_Menu_Container:SetWidgetVisibility(U1)
      else
        _ARG_0_.UIRoot.Fpp_Button_Container:SetWidgetVisibility(U2)
        _ARG_0_.UIRoot.Fpp_Menu_Container:SetWidgetVisibility(U2)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetLocalText"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_2_ then
        return
      end
      if _ARG_1_ and _ARG_1_ ~= 0 then
      elseif _ARG_3_ then
        _ARG_0_:SetWidgetVisible(_ARG_2_, true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHeaderText"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_2_ or _ARG_1_ == nil then
        return
      end
      if type(_ARG_1_) == U1(112, 19, 48, 126, 2, 255) then
        if _ARG_1_ ~= U1() then
          _ARG_2_:SetText(_ARG_1_)
          _ARG_0_:SetWidgetVisible(_ARG_2_, true)
        end
        return
      end
      _ARG_0_:SetLocalText(_ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseRankEventHandle"] = function(_ARG_0_)
    do
      _ARG_0_:CloseSelf()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 236, 217, 176, 59, 93, 84, 249, 153, 140, 169))
      _ARG_0_.jumpInfo = nil
      goto lbl_124
      _ARG_0_.resTypeCallbackMap[U1(109, 6, 37, 114, 30)] = nil
      ::lbl_124::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.resTypeCallbackMap = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EventQueryRank"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 230, 193, 150, 57, 70, 118, 233, 205, 207, 225, 244, 182, 243, 97), _ARG_0_.bInitShow)
      if not _ARG_0_.bInitShow then
        return
      end
      if U2.GetRankSelectType() == U4.like then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RankEventHandler"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_1_ ~= EVENTTYPE_RANK then
        return
      end
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 241, 214, 157, 60, 119, 81, 249, 198, 201, 208, 199, 185, 249, 102, 156, 36), _ARG_1_, _ARG_2_, _ARG_3_)
      if _ARG_2_ == EVENTID_RANK_UPDATE_LIST then
        _ARG_0_:RefreshUIEventHandle()
      elseif _ARG_2_ == EVENTID_RANK_UPDATE_SELF then
        _ARG_0_:RefreshSelfEventHandle()
      elseif _ARG_2_ == EVENTID_RANK_UPDATE_ITEM and _ARG_3_ then
        _ARG_0_:UpdateItemEventHandle(_ARG_3_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ValidateRankDataMatchUI"] = function(_ARG_0_)
    do
      if GetRankSelectType() == U1.weapon_usage_score then
        if GetLBSMode() then
          if not GetCountryID() or GetCountryID() <= 0 then
            return false
          end
        elseif _ARG_0_.Common_ComboBox_ZoneList and _ARG_0_.Common_ComboBox_ZoneList:GetSelectData() and _ARG_0_.Common_ComboBox_ZoneList:GetSelectData().zone_id and GetRankSelectZoneId() ~= _ARG_0_.Common_ComboBox_ZoneList:GetSelectData().zone_id then
          return false
        end
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshUIEventHandle"] = function(_ARG_0_)
    do
      _ARG_0_:RemoveRefreshRankUITimer()
      log(bWriteLog and table.concat({
        U1(88, 53, 35, 121, 7, 199, 152, 225, 244, 151, 210, 46, 221, 118, 254, 151, 161, 50, 84, 85, 249, 219, 213, 205, 239, 146, 235, 111, 151, 34, 251, 198, 141, 35, 78, 82, 172, 219, 193, 237),
        U1(98, 21, 98, 120, 0, 252, 237, 219, 194, 166, 249, 127, 201, 36, 198, 209, 156, 37, 87, 7, 238, 205, 219, 234, 195, 164, 245)
      }))
      if not _ARG_0_:ValidateRankDataMatchUI() then
        log(bWriteLog and table.concat({
          U1(88, 53, 35, 121, 7, 199, 152, 225, 244, 151, 210, 46, 221, 118, 254, 151, 161, 50, 84, 85, 249, 219, 213, 205, 239, 146, 235, 111, 151, 34, 251, 198, 141, 35, 78, 82, 182, 152, 201, 233),
          U1(119, 6, 98, 122, 5, 235, 160, 201, 194, 164, 229, 58, 188, 15, 143, 151, 128, 60, 91, 87, 188, 218, 216, 254, 212, 178, 238, 98, 217, 55, 221, 195, 195, 53, 71, 26, 254, 221, 220, 253),
          U1(102, 20, 54)
        }))
        return
      end
      _ARG_0_:RefreshRankUI()
      U2.QueryRankRoleInfoByScroll(1)
      if _ARG_0_.jumpInfo and _ARG_0_.jumpInfo.type == U3.GetRankSelectType() and _ARG_0_.isForJumpShow then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshSelfEventHandle"] = function(_ARG_0_)
    do
      if GetRankRegionType() == U1.friend then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateItemEventHandle"] = function(_ARG_0_, _ARG_1_)
    do
      if type((_ARG_0_.LoopScrollBox_RankList:GetSetData())) ~= U1(119, 6, 32, 123, 9) then
        return
      end
      goto lbl_105
      if U2.IsIntimacy() then
        if (123).no == _ARG_1_.no then
          _ARG_0_.LoopScrollBox_RankList:GetSetData()[32] = require((U1(96, 8, 47, 122, 3, 246, 227, 220, 215, 165, 225, 127, 182, 51, 215, 222, 159))).CopyTable(_ARG_1_)
          _ARG_0_.LoopScrollBox_RankList:GetSetData()[32].uid = _ARG_0_.LoopScrollBox_RankList:GetSetData()[32].ext_data.uid_s
          _ARG_0_.LoopScrollBox_RankList:GetSetData()[32].ext_data.other_uid = _ARG_0_.LoopScrollBox_RankList:GetSetData()[32].ext_data.uid_l
          _ARG_1_.score = math.floor(_ARG_1_.score + 0.5)
          return
        end
      elseif (123).uid == _ARG_1_.uid then
        if U2.GetRankSelectType() == U3.RankSelectEnum.peakgame_kd or U2.GetRankSelectType() == U3.RankSelectEnum.peakgame_win then
        else
          _ARG_1_.score = math.floor(_ARG_1_.score + 0.5)
        end
        return
      end
      ::lbl_105::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCoupleActionPlay"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(113, 6, 44, 124, 86, 203, 168, 220, 245, 168, 248, 106, 133, 35, 226, 212, 135, 62, 93, 73, 204, 196, 220, 225))
      _ARG_0_.canPlayCoupleAction = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearAvatarAndUIState"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(113, 6, 44, 124, 86, 219, 161, 205, 215, 181, 204, 108, 136, 50, 194, 197, 178, 57, 86, 114, 213, 251, 201, 249, 210, 178))
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.CoupleAvatarSystem):GetCoupleAvatar(_ARG_0_.sceneType) then
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_couple_avatar_action) then
      end
      _ARG_0_.curSelectUid = U1()
      _ARG_0_.curSelectIndex = 0
      _ARG_0_.canPlayCoupleAction = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClassicRankButton"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ENV[_ARG_1_] then
        return
      end
      if _ARG_1_ == U3.tpp and _ARG_0_.curParentTab ~= U4.Tpp then
      elseif _ARG_1_ == U3.fpp and _ARG_0_.curParentTab ~= U4.Fpp then
      elseif _ARG_1_ == U3.gift and _ARG_0_.curParentTab ~= U4.Gift then
      elseif _ARG_1_ == U3.peakgame and _ARG_0_.curParentTab ~= U4.peakgame then
      else
        _ARG_0_.foldTab = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectRankButton"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 236, 217, 160, 50, 94, 66, 255, 220, 239, 249, 200, 188, 223, 127, 141, 34, 220, 201))
      _ARG_0_.bInitShow = true
      if not U2[_ARG_1_] then
        return
      end
      if U3.GetRankSelectType() == _ARG_1_ and not _ARG_0_.foldTab then
        _ARG_0_.foldTab = false
        return
      end
      _ARG_0_.foldTab = false
      if _ARG_3_ then
        if _ARG_1_ == U4.popularity or _ARG_1_ == U4.pround or _ARG_1_ == U4.guardian then
        elseif _ARG_1_ == U4.wow_author then
        else
        end
        if _ARG_1_ == U4.peakgame_win then
        end
        if _ARG_1_ == U4.weapon_usage_score or _ARG_1_ == U4.weapon_kill_rank then
          if U7.IsShowButton_LBS() and require((U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 94, 69, 239, 134, 209, 247, 193, 190, 254, 85, 149, 52, 192))).IsSetMyProvince() then
          elseif _ARG_1_ == U4.weapon_kill_rank then
            goto lbl_428
            if require((U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 70, 66, 253, 197, 200, 232, 136, 187, 242, 109, 144, 53, 236, 221, 140, 41, 71))).GetChooseZone() and tonumber(require((U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 70, 66, 253, 197, 200, 232, 136, 187, 242, 109, 144, 53, 236, 221, 140, 41, 71))).GetChooseZone().zone_id) == (tonumber(require((U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 70, 66, 253, 197, 200, 232, 136, 187, 242, 109, 144, 53, 236, 221, 140, 41, 71))).GetChooseZone()) or 0) then
            else
              ::lbl_428::
              _ARG_0_ = _ARG_0_
              _ARG_0_ = _ARG_0_
            end
          else
          end
          if _ARG_1_ == U4.weapon_usage_score then
          elseif _ARG_1_ == U4.weapon_kill_rank then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryRefreshRankUIByTimer"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 247, 197, 138, 5, 87, 65, 238, 205, 206, 240, 244, 182, 243, 97, 172, 31, 241, 222, 183, 46, 79, 82, 254))
      _ARG_0_:RemoveRefreshRankUITimer()
      _ARG_0_.rankUITimer = _ARG_0_:AddTimerOnce(0.2, function()
        printf(table.concat({
          U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 247, 197, 138, 5, 87, 65, 238, 205, 206, 240, 244, 182, 243, 97, 172, 31, 241, 222, 183, 46, 79, 82, 254, 152, 207, 241),
          U1(35, 19, 43, 122, 9, 247, 184, 220, 158, 247, 163, 40, 154, 111, 143, 151, 128, 50, 94, 66, 255, 220, 135, 189, 213)
        }), tostring(U2))
        U3.rankUITimer = nil
        U3:RefreshRankUI()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoveRefreshRankUITimer"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 241, 210, 158, 56, 68, 66, 206, 205, 219, 234, 195, 164, 245, 88, 152, 56, 216, 242, 170, 19, 75, 90, 233, 202))
      if _ARG_0_.rankUITimer then
        _ARG_0_:RemoveTimer(_ARG_0_.rankUITimer)
        _ARG_0_.rankUITimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshRankUI"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPeriodStyle"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == week then
        _ARG_0_.UIRoot.Button_PeriodTotal:SetWidgetVisibility(U1)
        _ARG_0_.UIRoot.Button_PeriodWeek:SetWidgetVisibility(U2)
        _ARG_0_.UIRoot.Button_PeriodWeek:SetIsEnabled(false)
        _ARG_0_.UIRoot.Button_PeriodTotal:SetIsEnabled(true)
        _ARG_0_.UIRoot.TextBlock_PeriodWeek:SetColorAndOpacity(U3.black)
        _ARG_0_.UIRoot.TextBlock_PeriodTotal:SetColorAndOpacity(U3.whiteHalfAlpha)
      else
        _ARG_0_.UIRoot.Button_PeriodWeek:SetWidgetVisibility(U1)
        _ARG_0_.UIRoot.Button_PeriodTotal:SetWidgetVisibility(U2)
        _ARG_0_.UIRoot.Button_PeriodWeek:SetIsEnabled(true)
        _ARG_0_.UIRoot.Button_PeriodTotal:SetIsEnabled(false)
        _ARG_0_.UIRoot.TextBlock_PeriodWeek:SetColorAndOpacity(U3.whiteHalfAlpha)
        _ARG_0_.UIRoot.TextBlock_PeriodTotal:SetColorAndOpacity(U3.black)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitReuseList"] = function(_ARG_0_)
    do
      if not (#ParseRankViewData() <= 0) then
        _ARG_0_.curSelectUid = U2()
        if _ARG_0_.jumpInfo and _ARG_0_.jumpInfo.selectIndex then
          goto lbl_150
          if #ParseRankViewData() <= 0 == _ARG_0_.jumpInfo.selectIndex then
            _ARG_0_.curSelectIndex, _ARG_0_.curSelectUid = #ParseRankViewData() <= 0, GetRankSelectType().uid
            if _ARG_0_.jumpInfo.loopScrollOffset then
            end
          else
            ::lbl_150::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        end
        if _ARG_0_.curSelectUid == U2() then
          _ARG_0_.curSelectUid = ParseRankViewData()[1].uid
          _ARG_0_.curSelectIndex = 1
        end
        if U1.tostring(_ARG_0_.curSelectUid) == U1.tostring(U1.DataMgr.roleData.uid) or IsIntimacy() then
        else
        end
        if _ARG_0_.jumpInfo and _ARG_0_.jumpInfo.selectIndex and _ARG_0_.curSelectUid ~= U2() then
        end
      else
        if U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.CoupleAvatarSystem):GetCoupleAvatar(_ARG_0_.sceneType) then
        end
        _ARG_0_.curSelectUid = U2()
        _ARG_0_.curSelectIndex = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSelectFriendState"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.UIRoot.ButtonAll:SetIsEnabled(not _ARG_1_)
      _ARG_0_.UIRoot.ButtonFriend:SetIsEnabled(_ARG_1_)
      _ARG_0_.UIRoot.TextBlock_SwitchRang_Friend:SetColorAndOpacity(_ARG_1_ and whiteHalfAlpha or black0P7Alpha)
      _ARG_0_.UIRoot.TextBlock_SwitchRange_All:SetColorAndOpacity(_ARG_1_ and black0P7Alpha or whiteHalfAlpha)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsShowWeaponKillRankSeasonalVariation"] = function(_ARG_0_)
    do
      if not IsWeaponKillRankRanking((GetRankSelectType())) then
        return false
      end
      do return GetWeaponKillRankKind() == U1.WeaponKillRankKind.season end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsWeaponKillRankSeasonTab"] = function(_ARG_0_)
    do
      do return _ARG_0_.UIRoot ~= nil and _ARG_0_.UIRoot.Button_1 ~= nil and not _ARG_0_.UIRoot.Button_1:IsEnabled() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LogWeaponKillRankHeaderState"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(88, 48, 9, 69, 13, 246, 166, 224, 211, 166, 233, 127, 155, 27, 131, 212, 134, 37, 97, 66, 240, 205, 222, 236, 155, 242, 238, 42, 139, 55, 221, 204, 176, 34, 78, 82, 239, 204, 249, 241),
        U1(115, 2, 127, 50, 31, 184, 166, 193, 216, 163, 176, 63, 154, 102, 208, 210, 146, 36, 93, 73, 253, 196, 128, 189, 213)
      }), tostring(_ARG_1_), tostring(U2.GetRankSelectType()), tostring(U2.GetWeaponKillRankKind()), tostring(_ARG_2_)))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSeasonalVariationColumnVisible"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetWeaponKillRankKind"] = function(_ARG_0_)
    do
      do return GetWeaponKillRankKind() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshHeaderText"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 241, 210, 149, 37, 87, 84, 244, 224, 216, 249, 194, 178, 239, 94, 156, 46, 199))
      if _ARG_1_ == U2.wow_author then
        if U3.GetWoWAuthorType() == U4.WoWAuthorEnum.level then
          _ARG_1_ = U2.wow_author_level
        elseif U3.GetWoWAuthorType() == U4.WoWAuthorEnum.popularity then
          _ARG_1_ = U2.wow_mod_popularity
        end
      end
      if U3.IsWeaponKillRankRanking(_ARG_1_) then
      end
      if not U5[U3.IsWeaponKillRankRanking(_ARG_1_) and _ARG_0_:IsShowWeaponKillRankSeasonalVariation() and U2.weapon_kill_rank_season or U2.weapon_kill_rank_career] then
        return
      end
      if not (U5[U3.IsWeaponKillRankRanking(_ARG_1_) and _ARG_0_:IsShowWeaponKillRankSeasonalVariation() and U2.weapon_kill_rank_season or U2.weapon_kill_rank_career].Short_HeaderConfig or U5[U3.IsWeaponKillRankRanking(_ARG_1_) and _ARG_0_:IsShowWeaponKillRankSeasonalVariation() and U2.weapon_kill_rank_season or U2.weapon_kill_rank_career].HeaderConfig) then
        return
      end
      if _ARG_1_ == U2.peakgame_kd or _ARG_1_ == U2.popularity or _ARG_1_ == U2.pround or _ARG_1_ == U2.guardian then
        if U3.GetRankRegionType() == U6.friend then
          ;(U5[U3.IsWeaponKillRankRanking(_ARG_1_) and _ARG_0_:IsShowWeaponKillRankSeasonalVariation() and U2.weapon_kill_rank_season or U2.weapon_kill_rank_career].Short_HeaderConfig or U5[U3.IsWeaponKillRankRanking(_ARG_1_) and _ARG_0_:IsShowWeaponKillRankSeasonalVariation() and U2.weapon_kill_rank_season or U2.weapon_kill_rank_career].HeaderConfig).showReward = false
        else
          ;(U5[U3.IsWeaponKillRankRanking(_ARG_1_) and _ARG_0_:IsShowWeaponKillRankSeasonalVariation() and U2.weapon_kill_rank_season or U2.weapon_kill_rank_career].Short_HeaderConfig or U5[U3.IsWeaponKillRankRanking(_ARG_1_) and _ARG_0_:IsShowWeaponKillRankSeasonalVariation() and U2.weapon_kill_rank_season or U2.weapon_kill_rank_career].HeaderConfig).showReward = true
        end
      end
      _ARG_0_.showReward = (U5[U3.IsWeaponKillRankRanking(_ARG_1_) and _ARG_0_:IsShowWeaponKillRankSeasonalVariation() and U2.weapon_kill_rank_season or U2.weapon_kill_rank_career].Short_HeaderConfig or U5[U3.IsWeaponKillRankRanking(_ARG_1_) and _ARG_0_:IsShowWeaponKillRankSeasonalVariation() and U2.weapon_kill_rank_season or U2.weapon_kill_rank_career].HeaderConfig).showReward
      _ARG_0_.ShowContent1 = (U5[U3.IsWeaponKillRankRanking(_ARG_1_) and _ARG_0_:IsShowWeaponKillRankSeasonalVariation() and U2.weapon_kill_rank_season or U2.weapon_kill_rank_career].Short_HeaderConfig or U5[U3.IsWeaponKillRankRanking(_ARG_1_) and _ARG_0_:IsShowWeaponKillRankSeasonalVariation() and U2.weapon_kill_rank_season or U2.weapon_kill_rank_career].HeaderConfig).title1 ~= nil
      _ARG_0_.ShowContent2 = (U5[U3.IsWeaponKillRankRanking(_ARG_1_) and _ARG_0_:IsShowWeaponKillRankSeasonalVariation() and U2.weapon_kill_rank_season or U2.weapon_kill_rank_career].Short_HeaderConfig or U5[U3.IsWeaponKillRankRanking(_ARG_1_) and _ARG_0_:IsShowWeaponKillRankSeasonalVariation() and U2.weapon_kill_rank_season or U2.weapon_kill_rank_career].HeaderConfig).title2 ~= nil
      _ARG_0_.ShowContent3 = (U5[U3.IsWeaponKillRankRanking(_ARG_1_) and _ARG_0_:IsShowWeaponKillRankSeasonalVariation() and U2.weapon_kill_rank_season or U2.weapon_kill_rank_career].Short_HeaderConfig or U5[U3.IsWeaponKillRankRanking(_ARG_1_) and _ARG_0_:IsShowWeaponKillRankSeasonalVariation() and U2.weapon_kill_rank_season or U2.weapon_kill_rank_career].HeaderConfig).title3 ~= nil
      if U3.IsWeaponKillRankRanking(_ARG_1_) and _ARG_0_:IsShowWeaponKillRankSeasonalVariation() then
      else
        if U3.IsWeaponKillRankRanking(_ARG_1_) then
        end
        if U3.IsWeaponKillRankRanking(_ARG_1_) then
        end
      end
      if _ARG_1_ == U2.planPH then
      elseif _ARG_1_ == U2.guardian then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshComboBoxInfo"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 102, 241, 210, 149, 37, 87, 84, 244, 235, 210, 245, 196, 184, 223, 101, 129, 31, 221, 193, 140), _ARG_1_)
      if _ARG_1_ == U3.weapon_kill_rank then
      elseif U4.IsClassicRanking() or U4.IsPeakGameRanking() or U4.IsArenaRanking() then
      elseif (U4.IsWeaponUsageScoreRanking() or U4.IsWeaponKillRankRanking()) and not U5.IsBlueholeOperationRegion() then
      else
      end
      if U2.IsShowButton_LBS() then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_rank_reddot):IsShowTSLSettingReddot() then
        else
        end
      else
      end
      if _ARG_1_ == U3.weapon_kill_rank then
        if not _ARG_0_.bInitWeaponKillRankRegion then
          if _ARG_0_.LoopScrollGrid_WeaponKillRankWeaponType and _ARG_0_.LoopScrollGrid_WeaponKillRankWeaponType.UIRoot then
            if U4.GetWeaponID() and 0 < U4.GetWeaponID() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_weapon_strength):GetWeaponRankConfigByWeaponID((U4.GetWeaponID())) then
              goto lbl_394
              if U1(74, 19, 39, 122, 92, 169, 227, 250, 211, 163, 233, 117, 157, 25, 226, 217, 144, 63, 93, 85, 195, 225, 201, 253, 203, 231, 172).TypeID == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_weapon_strength):GetWeaponRankConfigByWeaponID((U4.GetWeaponID())).Type then
              else
                ::lbl_394::
                _ARG_0_ = _ARG_0_
                _ARG_0_ = _ARG_0_
              end
            end
            _ARG_0_.pendingWeaponKillRankWeaponType = _ARG_0_:GetWeaponKillRankWeaponTypeList()[U1(74, 19, 39, 122, 92, 169, 227, 250, 211, 163, 233, 117, 157, 25, 226, 217, 144, 63, 93, 85, 195, 225, 201, 253, 203, 231, 172)]
          end
          if _ARG_0_.LoopScrollGrid_WeaponKillRankWeapon and _ARG_0_.LoopScrollGrid_WeaponKillRankWeapon.UIRoot then
            if _ARG_0_.pendingWeaponKillRankWeaponType then
              goto lbl_426
              if ipairs((_ARG_0_:GetWeaponKillRankWeaponTypeList())).TypeID == _ARG_0_.pendingWeaponKillRankWeaponType.TypeID then
              else
                ::lbl_426::
                _ARG_0_ = _ARG_0_
                _ARG_0_ = _ARG_0_
              end
            end
            if U4.GetWeaponID() and 0 < U4.GetWeaponID() then
              goto lbl_456
              if U1(74, 19, 39, 122, 92, 169, 227, 250, 211, 163, 233, 117, 157, 25, 226, 217, 144, 63, 93, 85, 195, 225, 201, 253, 203, 231, 172).TypeID.WeaponID == U4.GetWeaponID() then
              else
                ::lbl_456::
                _ARG_0_ = _ARG_0_
                _ARG_0_ = _ARG_0_
              end
            end
            _ARG_0_.pendingWeaponKillRankWeapon = _ARG_0_:GetWeaponKillRankWeaponList(_ARG_0_:GetWeaponKillRankWeaponTypeList()[U1(74, 19, 39, 122, 92, 169, 227, 250, 211, 163, 233, 117, 157, 25, 226, 217, 144, 63, 93, 85, 195, 225, 201, 253, 203, 231, 172)] and _ARG_0_:GetWeaponKillRankWeaponTypeList()[U1(74, 19, 39, 122, 92, 169, 227, 250, 211, 163, 233, 117, 157, 25, 226, 217, 144, 63, 93, 85, 195, 225, 201, 253, 203, 231, 172)].TypeID)[U1(74, 19, 39, 122, 92, 169, 227, 250, 211, 163, 233, 117, 157, 25, 226, 217, 144, 63, 93, 85, 195, 225, 201, 253, 203, 231, 172)]
          end
          _ARG_0_.bInitWeaponKillRankRegion = true
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickDropDown1"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetWeaponKillRankRegionPanelOpen"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.bWeaponKillRankRegionOpen = _ARG_1_
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Rank_Career_ComboBox_Item, _ARG_1_ and true or false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickCareerTab"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.tab_v1)
      _ARG_0_:SwitchWeaponKillRankKind(U1.WeaponKillRankKind.career)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSeasonTab"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.tab_v1)
      _ARG_0_:SwitchWeaponKillRankKind(U1.WeaponKillRankKind.season)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SwitchWeaponKillRankKind"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(88, 48, 9, 69, 13, 246, 166, 245, 150, 148, 250, 115, 157, 37, 203, 224, 150, 54, 66, 72, 242, 227, 212, 244, 202, 133, 252, 100, 146, 29, 218, 201, 135, 103, 73, 94, 226, 220, 144, 173),
        U1(112, 71, 33, 98, 30, 211, 164, 198, 210, 250, 168, 105)
      }), tostring(_ARG_1_), tostring(U2.GetWeaponKillRankKind())))
      if not _ARG_1_ or _ARG_1_ == U2.GetWeaponKillRankKind() then
        log(bWriteLog and table.concat({
          U1(88, 48, 9, 69, 13, 246, 166, 245, 150, 148, 250, 115, 157, 37, 203, 224, 150, 54, 66, 72, 242, 227, 212, 244, 202, 133, 252, 100, 146, 29, 218, 201, 135, 103, 86, 95, 233, 152, 222, 233),
          U1(110, 2, 98, 124, 5, 246, 169, 71, 10, 75, 254, 113, 128, 54)
        }))
        return
      end
      U2.SetWeaponKillRankKind(_ARG_1_)
      _ARG_0_:SetWeaponKillRankKindStyle(_ARG_1_)
      _ARG_0_:RefreshHeaderText(U2.GetRankSelectType())
      _ARG_0_.delayShow = false
      _ARG_0_:InitReuseList()
      _ARG_0_.delayShow = true
      _ARG_0_:EventQueryRank()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetWeaponKillRankKindStyle"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickedListSwitcher"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      _ARG_0_.delayShow = false
      _ARG_0_:RefreshRankListPullBack(not _ARG_0_.IsRankListClose)
      _ARG_0_.delayShow = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshRankListPullBack"] = function(_ARG_0_, _ARG_1_)
    do
      log(U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 241, 210, 149, 37, 87, 84, 244, 250, 220, 246, 205, 155, 244, 121, 141, 6, 198, 203, 143, 5, 67, 84, 231), _ARG_1_)
      _ARG_0_.IsRankListClose = _ARG_1_
      if _ARG_1_ then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSelfItemPullBack"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:RefreshSelfItem()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseRankListRefreshIntimacyAnim"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ and not _ARG_0_.curSelectUid ~= _ENV() then
        _ARG_0_:HideIntimacyAnimUI()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitZoneList"] = function(_ARG_0_)
    do
      if _ARG_0_.bInitZoneList then
        return
      end
      if GlobalData.IsBLUEHOLE() then
      else
        goto lbl_94
        ::lbl_94::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      _ARG_0_.bInitZoneList = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitLBSComboBox"] = function(_ARG_0_)
    do
      if _ARG_0_.bInitLBSComboBox then
        return
      end
      if _ARG_0_.continentCountryCfgList == nil then
        _ARG_0_.continentCountryCfgList = require((U1(96, 8, 47, 122, 3, 246, 227, 220, 215, 165, 225, 127, 182, 51, 215, 222, 159))).CopyTable(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_lbs_select_region):LoadConfig_ContinentAndCountry())
        goto lbl_81
        if (69).continent_id == CDataTable.GetTableData(U1(79, 37, 17, 69, 9, 255, 164, 199, 216, 139, 232, 108, 140, 42, 224, 216, 157, 49, 91, 64), 100001).continent_id then
        else
          ::lbl_81::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      goto lbl_95
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_lbs_select_region):GetMyContinentId() == (17).continent_id then
      else
        ::lbl_95::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      _ARG_0_.bInitLBSComboBox = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetWeaponKillRankRegionList"] = function(_ARG_0_)
    do
      if _ARG_0_.weaponKillRankRegionList == nil then
        _ARG_0_.weaponKillRankRegionList = {}
        if GlobalData.IsBLUEHOLE() then
        elseif U2.IsJapanOrKorea() then
        else
          goto lbl_162
          if not U2.IsGlobalOperationRegion() or 6 ~= require((U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 70, 66, 253, 197, 200, 232, 136, 187, 242, 109, 144, 53, 236, 221, 140, 41, 71))).Enum_ZoneID.KRJP then
          end
          ::lbl_162::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      do return _ARG_0_.weaponKillRankRegionList end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetWeaponKillRankWeaponTypeList"] = function(_ARG_0_)
    do
      if _ARG_0_.weaponKillRankWeaponTypeList == nil then
        _ARG_0_.weaponKillRankWeaponTypeList = {}
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return _ARG_0_.weaponKillRankWeaponTypeList end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetWeaponKillRankWeaponList"] = function(_ARG_0_, _ARG_1_)
    do
      goto lbl_65
      if CDataTable.GetTableData(U1(66, 21, 47, 120, 30, 225, 142, 199, 216, 161, 228, 125), (nil).WeaponID) then
      end
      ::lbl_65::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecoverStatus"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ and _ARG_1_.isOnlyShow ~= nil then
        log(bWriteLog and U1(81, 6, 44, 124, 57, 209, 227, 250, 211, 164, 226, 108, 140, 52, 240, 195, 146, 35, 71, 84, 166) .. tostring(_ARG_1_.isOnlyShow))
        _ARG_0_:ChangeIsOnlyShow(_ARG_1_.isOnlyShow)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetStatus"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(81, 6, 44, 124, 57, 209, 227, 239, 211, 179, 222, 110, 136, 50, 214, 196, 201) .. tostring(_ARG_0_.isOnlyShow))
      do return {
        isOnlyShow = _ARG_0_.isOnlyShow
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeIsOnlyShow"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(81, 6, 44, 124, 57, 209, 227, 235, 222, 166, 227, 125, 140, 15, 208, 248, 157, 59, 75, 116, 244, 199, 202, 162) .. tostring(_ARG_1_))
      _ARG_0_.isOnlyShow = _ARG_1_
      if _ARG_0_.isOnlyShow then
        if _ARG_0_.curSelectUid ~= U1() then
          _ARG_0_:_RankShowAvatar(_ARG_0_.curSelectUid, _ARG_0_.UIRoot.Title_UIBP, _ARG_0_.UIRoot.HideRoleInfoPanel)
        end
        _ARG_0_:OnlyShowUI()
      elseif ModuleManager.GetModule(ModuleManager.CommonModuleConfig.CoupleAvatarSystem):GetCoupleAvatar(_ARG_0_.sceneType) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnlyShowUI"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot:SetWidgetVisibility(_ENV)
      _ARG_0_:PlayUserWidgetAnimation(_ARG_0_.UIRoot.DX_Transitions_Enter, 0, 1, 0, 1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnlyHideUI"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot:SetWidgetVisibility(_ENV)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshSelfItem"] = function(_ARG_0_)
    do
      if not GetRankInfoSelf() then
        return
      end
      if IsIntimacy() and not GetRankInfoSelf().ext_data.uid_s then
        return
      end
      if GetRankSelectType() == U3.guardian and GetRankRegionType() == U4.friend and (not (GetRankInfoSelf().ext_data and GetRankInfoSelf().ext_data.receiver_uid) or 0 >= GetRankInfoSelf().ext_data.receiver_uid) then
      end
      if U2() == U2() or U2() == 0 then
      else
      end
      if GetRankInfoSelf() then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateInspect"] = function(_ARG_0_, _ARG_1_)
    do
      if not require((table.concat({
        U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 64, 70, 242, 195, 147, 244, 201, 176, 244, 105, 166, 36, 210, 201, 136, 24, 75, 89, 255, 200, 200, 235),
        U1(119)
      }))).IsAreaSwitchOpen() then
        return
      end
      if U3.IsTpp() or U3.IsFpp() then
        if _ARG_1_ == nil or _ARG_1_ <= 0 or U3.GetRankRegionType() == U4.friend then
          return
        end
        if require((table.concat({
          U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 64, 70, 242, 195, 147, 244, 201, 176, 244, 105, 166, 36, 210, 201, 136, 24, 75, 89, 255, 200, 200, 235),
          U1(119)
        }))).IsMyFightVideoPublic() then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickNumDetail"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHomeTips"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetDataInfo"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 240, 210, 135, 19, 83, 83, 253, 225, 211, 254, 201))
      if not _ARG_2_ then
        return
      end
      if not require((U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 138, 41, 206, 218, 156, 57, 28, 68, 243, 197, 208, 247, 200, 136, 254, 101, 151, 48, 218, 192))):IsShowAvatarInRank() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowPreviewTeamupEffect"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return
      end
      if _ARG_0_.lastShowActionTime and require((U1(96, 11, 43, 114, 2, 236, 227, 203, 217, 170, 224, 117, 135, 104, 215, 222, 158, 50, 109, 82, 232, 193, 209))).GetServerTimeInSec() - _ARG_0_.lastShowActionTime < U2 then
        return
      end
      _ARG_0_.lastShowActionTime = require((U1(96, 11, 43, 114, 2, 236, 227, 203, 217, 170, 224, 117, 135, 104, 215, 222, 158, 50, 109, 82, 232, 193, 209))).GetServerTimeInSec()
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.CoupleAvatarSystem):GetCoupleAvatar(_ARG_0_.sceneType) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClickItemEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:OnClickItem(_ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSelectImage"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 240, 210, 135, 4, 87, 75, 249, 203, 201, 209, 203, 182, 250, 111))
      if _ARG_2_ then
        _ARG_1_.UIRoot.Image_Selected:SetWidgetVisibility(U2)
      else
        _ARG_1_.UIRoot.Image_Selected:SetWidgetVisibility(U3)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshLevelBGAfterDownload"] = function(_ARG_0_)
    do
      printf((table.concat({
        U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 241, 210, 149, 37, 87, 84, 244, 228, 216, 238, 195, 187, 223, 77, 184, 48, 199, 194, 145, 3, 77, 64, 226, 212, 194, 233),
        U1(103)
      })))
      if _ARG_0_.LoopScrollBox_RankList:GetItemData(_ARG_0_.curSelectIndex) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log_format(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 236, 217, 176, 59, 91, 68, 247, 225, 201, 253, 203, 247, 244, 100, 157, 51, 203, 135, 198, 52), _ARG_2_)
      if _ARG_1_ then
        _ARG_0_:PlayAudio(sound_config.click_v1)
      end
      _ARG_0_:HideIntimacyAnimUI()
      if _ARG_0_.LoopScrollBox_RankList:GetItemData(_ARG_2_) then
        if _ARG_0_.curSelectIndex ~= _ARG_2_ then
          if _ARG_0_.curSelectIndex and _ARG_0_.LoopScrollBox_RankList:GetIndexOfItem(_ARG_0_.curSelectIndex) then
          end
          if _ARG_0_.LoopScrollBox_RankList:GetIndexOfItem(_ARG_2_) then
          end
          if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.CoupleAvatarSystem):GetCoupleAvatar(_ARG_0_.sceneType) then
          end
        end
        _ARG_0_.curSelectUid = _ARG_0_.LoopScrollBox_RankList:GetItemData(_ARG_2_).uid
        _ARG_0_.curSelectIndex = _ARG_2_
        if tostring(_ARG_0_.curSelectUid) == tostring(DataMgr.roleData.uid) or U2.IsIntimacy() then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateSelectImage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_2_ and _ARG_3_ == _ARG_0_.curSelectIndex then
        _ARG_1_.Image_Selected:SetWidgetVisibility(_ENV)
      else
        _ARG_1_.Image_Selected:SetWidgetVisibility(U1)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdatePlayIntimacyAnim"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 246, 199, 151, 54, 70, 66, 204, 196, 220, 225, 239, 185, 233, 99, 148, 55, 208, 222, 162, 41, 75, 90))
      if not _ARG_0_.LoopScrollBox_RankList:GetItemData(_ARG_0_.curSelectIndex) then
        return
      end
      if U2.IsIntimacy() then
        if not _ARG_0_.LoopScrollBox_RankList:GetItemData(_ARG_0_.curSelectIndex).ext_data or not _ARG_0_.LoopScrollBox_RankList:GetItemData(_ARG_0_.curSelectIndex).ext_data.other_uid then
          return
        end
        if tonumber(_ARG_0_.curSelectUid) ~= tonumber(DataMgr.roleData.uid) and not _ARG_1_.bshow then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowIntimacyAnimUI"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_2_.bshow then
        _ARG_0_:HideIntimacyAnimUI()
        log(bWriteLog and table.concat({
          U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 240, 223, 156, 32, 123, 73, 232, 193, 208, 249, 197, 174, 220, 100, 144, 59, 230, 238, 195, 53, 77, 91, 233, 252, 204, 252),
          U1(98, 73, 32, 100, 4, 247, 186, 136, 139, 231, 235, 123, 133, 53, 198)
        }))
        return
      end
      if require((table.concat({
        U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 66, 66, 238, 219, 210, 246, 249, 164, 237, 107, 154, 51, 157, 203, 140, 32, 75, 84, 211, 209, 195, 252),
        U1(106, 10, 35, 116, 21, 199, 172, 223, 215, 181, 233)
      }))).CheckCanShowAnimation(_ARG_1_.ext_data.total_intimacy) then
        if not _ARG_0_.UIRoot or not _ARG_0_.UIRoot.CanvasPanel_42 then
          return
        end
        if not _ARG_0_.intimacyAnim then
          _ARG_0_.intimacyAnim = _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.CanvasPanel_42, UIManager.UI_Config.Rank_Intimacy_UIBP, _ARG_1_)
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideIntimacyAnimUI"] = function(_ARG_0_)
    do
      if _ARG_0_.intimacyAnim then
        log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 235, 222, 151, 50, 123, 73, 232, 193, 208, 249, 197, 174, 220, 100, 144, 59, 230, 238))
        _ARG_0_.intimacyAnim:Close()
        _ARG_0_.intimacyAnim = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateBGLevel"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 246, 199, 151, 54, 70, 66, 222, 239, 241, 253, 208, 178, 241))
      if U2.IsRankEmpty() then
        log(bWriteLog and table.concat({
          U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 246, 199, 151, 54, 70, 66, 222, 239, 241, 253, 208, 178, 241, 42, 171, 55, 221, 204, 167, 38, 86, 86, 193, 223, 223, 166),
          U1(74, 20, 16, 118, 2, 243, 136, 197, 198, 179, 244, 50, 192)
        }))
        return
      end
      if _ARG_1_ and _ARG_2_ == _ARG_0_.curSelectIndex then
        log(bWriteLog and table.concat({
          U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 246, 199, 151, 54, 70, 66, 222, 239, 241, 253, 208, 178, 241, 42, 157, 55, 199, 198, 195, 38, 76, 83, 172, 209, 195, 236),
          U1(102, 31, 98, 42, 81, 184, 190, 205, 218, 161, 163, 121, 156, 52, 240, 210, 159, 50, 81, 83, 213, 198, 217, 253, 222)
        }))
        if _ARG_0_.UIRoot and _ARG_0_.UIRoot.CanvasPanel_DownLoad or nil then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTabStyle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not GetTabStyle(_ARG_1_) then
        return
      end
      if GetTabStyle(_ARG_1_).isPeakgame then
        if U1.CDataTable.GetTableData(U2(81, 2, 37, 126, 3, 246, 138, 218, 217, 178, 253, 89, 134, 40, 197, 222, 148), U1.FuncUtil.GetAccountRegionForBP()) then
          if U1.CDataTable.GetTableData(U2(81, 2, 37, 126, 3, 246, 138, 218, 217, 178, 253, 89, 134, 40, 197, 222, 148), U1.FuncUtil.GetAccountRegionForBP()).CommunityEntranceSwitch == 0 then
          else
          end
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickFameHall"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.close_v1)
      if U1.GetRankSelectType() ~= U2.wow_author and U1.GetRankSelectType() ~= U2.wow_play_level then
        return
      end
      if not UIManager then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHelp"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.close_v1)
      if U1.GetRankSelectType() == U2.weapon_usage_score then
        return
      end
      if U1.GetRankSelectType() == U2.weapon_kill_rank or U1.GetRankSelectType() == U2.weapon_kill_rank_career or U1.GetRankSelectType() == U2.weapon_kill_rank_season then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickWonderfulPlayback"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.close_v1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSendGiftButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.close_v1)
      if U2.IsFITVersion() and require((table.concat({
        U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 86, 72, 235, 198, 209, 247, 199, 179, 179, 122, 140, 48, 213, 194, 145, 105, 82, 66, 234, 222, 200, 250),
        U1(92, 10, 35, 121, 13, 255, 168, 218)
      }))).ShowDownloadTips(require((U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 86, 72, 235, 198, 209, 247, 199, 179, 179, 122, 140, 48, 213, 194, 145, 24, 65, 88, 226, 203, 217))).ENUM_DownloadType.ODPACK, {
        require((U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 86, 72, 235, 198, 209, 247, 199, 179, 179, 122, 140, 48, 213, 194, 145, 24, 65, 88, 226, 203, 217))).EODPackID.SocialLobby
      }) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_LBS1"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.close_v1)
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 236, 217, 176, 59, 91, 68, 247, 234, 200, 236, 210, 184, 243, 85, 181, 20, 224, 150))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_LBS2"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.close_v1)
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 236, 217, 176, 59, 91, 68, 247, 234, 200, 236, 210, 184, 243, 85, 181, 20, 224, 149))
      U2.SetLBSMode(false)
      _ARG_0_:RefreshLBSSelect()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Join"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.close_v1)
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 236, 217, 176, 59, 91, 68, 247, 234, 200, 236, 210, 184, 243, 85, 179, 57, 218, 201))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_ReSetLBS"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.close_v1)
      log(bWriteLog and U1(81, 6, 44, 124, 51, 205, 132, 234, 230, 152, 185, 46, 217, 124, 236, 217, 176, 59, 91, 68, 247, 234, 200, 236, 210, 184, 243, 85, 171, 51, 224, 194, 151, 11, 96, 100))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSeason"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(96, 11, 43, 114, 2, 236, 227, 196, 217, 160, 228, 121, 199, 53, 198, 214, 128, 56, 92, 120, 229, 205, 220, 234, 136, 162, 233, 99, 149, 120, 192, 194, 130, 52, 77, 89, 211, 193, 200, 233),
        U1(113, 56, 55, 99, 5, 244)
      }))).CheckFunctionIsOpen() then
      else
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.level_unlock_manager):IsFeatureUnlocked(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.level_unlock_manager).featureDef.season) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickClose"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.close_v1)
      _ARG_0_:CloseRankEventHandle()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickPeriodWeek"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.tab_v1)
      U1.SetRankPeriodType(U2.week)
      _ARG_0_:EventQueryRank()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickPeriodTotal"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.tab_v1)
      U1.SetRankPeriodType(U2.total)
      _ARG_0_:EventQueryRank()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSelectRegion"] = function(_ARG_0_, _ARG_1_)
    do
      if require((U1(96, 11, 43, 114, 2, 236, 227, 203, 217, 170, 224, 117, 135, 104, 214, 222, 172, 34, 70, 78, 240))).CanClickNow(require((U1(96, 11, 43, 114, 2, 236, 227, 203, 217, 170, 224, 117, 135, 104, 214, 222, 172, 34, 70, 78, 240))).ClickFrequencyLimit.RankTab) then
        if _ARG_1_ == U3.friend then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickInspect"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.tab_v1)
      if require((table.concat({
        U1(96, 11, 43, 114, 2, 236, 227, 219, 218, 178, 236, 52, 133, 41, 196, 222, 144, 121, 64, 70, 242, 195, 147, 244, 201, 176, 244, 105, 166, 36, 210, 201, 136, 24, 75, 89, 255, 200, 200, 235),
        U1(119)
      }))).IsMyFightVideoPublic() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnResSelectResult"] = function(_ARG_0_)
    do
      if GetRankInfoSelf() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateMyLBSZone"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshLBSSelect()
      _ARG_0_:EventQueryRank()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateJoinLbs"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshLBSSelect()
      _ARG_0_:EventQueryRank()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDataForJumpBack"] = function(_ARG_0_)
    do
      do return {
        ctorData = {
          [1] = GetRankSelectType()
        },
        uiData = {
          type = GetRankSelectType(),
          selectIndex = _ARG_0_.curSelectIndex,
          loopScrollOffset = _ARG_0_.LoopScrollBox_RankList:GetItemOffset()
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["JumpBack"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(35, 53, 35, 121, 7, 199, 152, 225, 244, 151, 210, 46, 221, 118, 153, 253, 134, 58, 66, 101, 253, 203, 214))
      if _ARG_1_ then
        _ARG_0_.jumpInfo = DeepCopy(_ARG_1_)
        _ARG_0_.isForJumpShow = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearJumpFlag"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(35, 53, 35, 121, 7, 199, 152, 225, 244, 151, 210, 46, 221, 118, 153, 244, 159, 50, 83, 85, 214, 221, 208, 232, 224, 187, 252, 109))
      _ARG_0_.isForJumpShow = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPeakGameWoderfulPlayBackReddot"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_4_ ~= _ENV(113, 6, 44, 124) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshLBSSelect"] = function(_ARG_0_)
    do
      if not U1.GetLBSMode() or not IsShowButton_LBS() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
