local ModeSelection_Mine_Record_UIBP = {}
local Target = {Segment = 1, PeakSegment = 2}
local RecordTabType = {
  Dynamic = 1,
  ClassicBR = 2,
  UGC = 3
}
local ModeSelection_Mine_Data = require("GameLua.Mod.Lobby.Split.ModeSelection470.logic.ModeSelection_Mine_Data")
local ERecordItemType = ModeSelection_Mine_Data.ERecordItemType
local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")

function ModeSelection_Mine_Record_UIBP:ctor()
end

function ModeSelection_Mine_Record_UIBP:OnInitialize()
  local WowluaItem = "GameLua.Mod.Lobby.Split.ModeSelection470.umg.Mine.Item.ModeSelection_Mine_Record_Text_Item_UIBP"
  local WowluaSubItem = "GameLua.Mod.Lobby.Split.ModeSelection470.umg.Mine.Item.ModeSelection_Mine_Record_UGC_Item_UIBP"
  self.ExtendedLoopScrollGrid_WOW = self:InitExtendedScrollGrid(self.UIRoot.ExtendedLoopScrollGrid_WOW, {WowluaItem, WowluaSubItem})
  local BRluaItem = "GameLua.Mod.Lobby.Split.ModeSelection470.umg.Mine.Item.ModeSelection_Mine_Record_Text_Item_UIBP"
  local BRluaSubItem = "GameLua.Mod.Lobby.Split.ModeSelection470.umg.Mine.Item.ModeSelection_Mine_Record_BR_Item_UIBP"
  self.ExtendedLoopScrollGrid_BR = self:InitExtendedScrollGrid(self.UIRoot.ExtendedLoopScrollGrid_BR, {BRluaItem, BRluaSubItem})
  self.LoopScrollBox_Dynamic = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_Dynamic, "GameLua.Mod.Lobby.Split.ModeSelection470.umg.Mine.Item.ModeSelection_Mine_Record_Dynamic_Item_UIBP")
  self.LoopScrollBox_Record = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_Record, "GameLua.Mod.Lobby.Split.ModeSelection470.umg.Mine.Item.ModeSelection_Mine_RecordBp_Item_UIBP")
  local logic_friendfeed_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friendfeed_data)
  self:_RefreshLikeEntryVisible(0, logic_friendfeed_data)
  if self.UIRoot.Image_RedPoint then
    self:SetWidgetVisible(self.UIRoot.Image_RedPoint, false)
  end
  self:_InitRecordTabs()
end

function ModeSelection_Mine_Record_UIBP:RegistEvents()
  self:AddOnClickedEventByControl(self.UIRoot.Button_Good, self.OnClickButton_Good, self)
  self:AddCommonEvent(EVENTTYPE_ROLEINFO, EVENTID_ROLEINFO_HISTORY_LIST_UI, self._OnMineDataSourceRsp, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_GET_MINE_MODS, self._OnMineDataSourceRsp, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_GET_MOD_BATCH, self._OnUGCModBatchRsp, self)
  if self.ExtendedLoopScrollGrid_WOW and self.ExtendedLoopScrollGrid_WOW.UIRoot then
    local wowGridRoot = self.ExtendedLoopScrollGrid_WOW.UIRoot
    self:AddControlEventByControl(wowGridRoot, "OnUserScrolled", self._OnUGCListScrolled, self)
    self:AddControlEventByControl(wowGridRoot, "OnEndScroll", self._OnUGCListScrolled, self)
  end
  self:AddCommonEvent(EVENTTYPE_FRIEND_FEED, EVENTID_FRIEND_FEED_SELF_RSP, self._OnMineDataSourceRsp, self)
end

function ModeSelection_Mine_Record_UIBP:OnPostInitialize()
  self:UpdateUI()
end

function ModeSelection_Mine_Record_UIBP:OnClose()
  self._ratingTipsCard = nil
  EventSystem:postEvent(EVENTTYPE_CLICK, EVENTID_ICON_SHOW)
end

function ModeSelection_Mine_Record_UIBP:_OnMineDataSourceRsp(...)
  self._bUGCModMetaRequested = nil
  self._ugcNotReqModIdList = nil
  self._bUGCMetaPaging = false
  self:RefreshAllRecordTabsData()
  self:SwitchRecordTab(self._recordTabType or RecordTabType.Dynamic)
  self:RefreshMySegmentRecord()
end

function ModeSelection_Mine_Record_UIBP:_OnUGCModBatchRsp(...)
  if (self._recordTabType or RecordTabType.Dynamic) ~= RecordTabType.UGC then
    return
  end
  self:RefreshRecordListByTab(RecordTabType.UGC)
  self:_TryRequestNextUGCModMetaPage()
end

function ModeSelection_Mine_Record_UIBP:RefreshAllRecordTabsData()
  self:RefreshRecordListByTab(RecordTabType.Dynamic)
  self:RefreshRecordListByTab(RecordTabType.ClassicBR)
  self:RefreshRecordListByTab(RecordTabType.UGC)
end

function ModeSelection_Mine_Record_UIBP:OnClickButton_Good()
  self:PlayAudio(sound_config.click_v1)
  self:_MarkLikeRedPointSeen()
  UIManager.ShowUI(UIManager.UI_Config.ModeSelection_Mine_Good_UIBP)
end

function ModeSelection_Mine_Record_UIBP:NotifyRatingTipsShown(card)
  if self._ratingTipsCard and self._ratingTipsCard ~= card then
    self._ratingTipsCard:HideRatingTips()
  end
  self._ratingTipsCard = card
  EventSystem:postEvent(EVENTTYPE_CLICK, EVENTID_ICON_SHOW)
end

function ModeSelection_Mine_Record_UIBP:NotifyRatingTipsHidden(card)
  if self._ratingTipsCard == card then
    self._ratingTipsCard = nil
  end
  EventSystem:postEvent(EVENTTYPE_CLICK, EVENTID_ICON_SHOW)
end

function ModeSelection_Mine_Record_UIBP:HasRatingTipsCard()
  return self._ratingTipsCard ~= nil
end

function ModeSelection_Mine_Record_UIBP:HideCurrentRatingTips()
  local card = self._ratingTipsCard
  self._ratingTipsCard = nil
  if card then
    card:HideRatingTips()
  end
  EventSystem:postEvent(EVENTTYPE_CLICK, EVENTID_ICON_SHOW)
end

function ModeSelection_Mine_Record_UIBP:_MarkLikeRedPointSeen()
  local logic_friendfeed_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friendfeed_data)
  if logic_friendfeed_data and logic_friendfeed_data.SetLastSeenLikeTotal then
    logic_friendfeed_data:SetLastSeenLikeTotal(self:_CalcLikeTotal())
  end
  if self.UIRoot.Image_RedPoint then
    self:SetWidgetVisible(self.UIRoot.Image_RedPoint, false)
  end
  self._bLikeRedPointChecked = true
  log(bWriteLog and "ModeSelection_Mine_Record_UIBP:_MarkLikeRedPointSeen")
end

function ModeSelection_Mine_Record_UIBP:UpdateUI()
  if self.UIRoot.TextBlock_Empty then
    self.UIRoot.TextBlock_Empty:SetText(LocUtil.LocalizeResFormat(588123))
  end
  self:SwitchRecordTab(RecordTabType.Dynamic)
  self:RefreshMySegmentRecord()
end

function ModeSelection_Mine_Record_UIBP:ScrollToTop()
  if self.LoopScrollBox_Dynamic then
    self.LoopScrollBox_Dynamic:SetItemOffset(0)
  end
  if self.LoopScrollBox_Record then
    self.LoopScrollBox_Record:SetItemOffset(0)
  end
  local grids = {
    self.ExtendedLoopScrollGrid_BR,
    self.ExtendedLoopScrollGrid_WOW
  }
  for i = 1, #grids do
    local grid = grids[i]
    if grid and grid.UIRoot then
      grid.UIRoot:SetScrollOffset(0)
    end
  end
end

function ModeSelection_Mine_Record_UIBP:_CalcLikeTotal(records)
  records = records or self:_BuildDynamicList()
  local total = 0
  for _, rec in ipairs(records or {}) do
    total = total + (tonumber(rec.like_count) or 0)
  end
  return total
end

function ModeSelection_Mine_Record_UIBP:_RefreshLikeEntryVisible(total, logic_friendfeed_data)
  if not self.UIRoot.Button_Good then
    return
  end
  if PublishRegionMacros.IsBlueholeOperationRegion() then
    self:SetWidgetVisible(self.UIRoot.Button_Good, false, true)
    return
  end
  local bUnlocked = logic_friendfeed_data and logic_friendfeed_data.GetHasEverReceivedLike and logic_friendfeed_data:GetHasEverReceivedLike()
  self:SetWidgetVisible(self.UIRoot.Button_Good, bUnlocked == true or 0 < (total or 0), true)
end

function ModeSelection_Mine_Record_UIBP:RefreshLikeTotalText(records)
  local logic_friendfeed_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friendfeed_data)
  local total = self:_CalcLikeTotal(records)
  if self.UIRoot.UTRichTextBlock_Like then
    self.UIRoot.UTRichTextBlock_Like:SetText(LocUtil.LocalizeResFormat(588025, total))
  end
  self:_RefreshLikeEntryVisible(total, logic_friendfeed_data)
  self:_RefreshLikeRedPoint(total, logic_friendfeed_data)
  log(bWriteLog and string.format("ModeSelection_Mine_Record_UIBP:RefreshLikeTotalText total=%d, records=%d", total, records and #records or 0))
end

function ModeSelection_Mine_Record_UIBP:_RefreshLikeRedPoint(total, logic_friendfeed_data)
  if PublishRegionMacros.IsBlueholeOperationRegion() then
    if self.UIRoot.Image_RedPoint then
      self:SetWidgetVisible(self.UIRoot.Image_RedPoint, false)
    end
    return
  end
  if self._bLikeRedPointChecked then
    return
  end
  if not logic_friendfeed_data or not logic_friendfeed_data:GetSelfFriendFeed() then
    return
  end
  self._bLikeRedPointChecked = true
  local lastTotal = logic_friendfeed_data:GetLastSeenLikeTotal() or 0
  local bHasNewLike = total > lastTotal
  if self.UIRoot.Image_RedPoint then
    self:SetWidgetVisible(self.UIRoot.Image_RedPoint, bHasNewLike)
  end
  logic_friendfeed_data:SetLastSeenLikeTotal(total)
  log(bWriteLog and string.format("ModeSelection_Mine_Record_UIBP:_RefreshLikeRedPoint total=%d, lastTotal=%s, redPoint=%s", total, tostring(lastTotal), tostring(bHasNewLike)))
end

function ModeSelection_Mine_Record_UIBP:RefreshMySegmentRecord()
  local list = {}
  local classic = self:_BuildClassicSegmentRecordData()
  local peak = self:_BuildPeakSegmentRecordData()
  if classic then
    classic.item_type = ERecordItemType.Record
    table.insert(list, classic)
  end
  if peak then
    peak.item_type = ERecordItemType.RecordPeak
    table.insert(list, peak)
  end
  local logic_active_exchange_entry = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_active_exchange_entry)
  if logic_active_exchange_entry and logic_active_exchange_entry:IsActivityOpen() then
    table.insert(list, {
      item_type = ERecordItemType.RecordLuckyEgg
    })
  end
  if self.LoopScrollBox_Record then
    self.LoopScrollBox_Record:SetData(list)
  end
end

function ModeSelection_Mine_Record_UIBP:_InitRecordTabs()
  local tabs = {
    {
      widget = "ModeSelection_Common_SwitchBtn_Item_UIBP_C_0",
      nameKey = 588116,
      tabType = RecordTabType.Dynamic
    },
    {
      widget = "ModeSelection_Common_SwitchBtn_Item_UIBP_C_1",
      nameKey = 588117,
      tabType = RecordTabType.ClassicBR
    },
    {
      widget = "ModeSelection_Common_SwitchBtn_Item_UIBP_C_2",
      nameKey = 588118,
      tabType = RecordTabType.UGC
    }
  }
  local UIComponentModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule)
  self._recordTabBtns = {}
  for i, cfg in ipairs(tabs) do
    local btn = self.UIRoot[cfg.widget]
    local ModeSelection_Common_SwitchBtn_Item_UIBP = UIComponentModule:InitWithParentComponent(self, UIComponentModule.Config.ModeSelection_Common_SwitchBtn_Item_UIBP, btn)
    if ModeSelection_Common_SwitchBtn_Item_UIBP then
      ModeSelection_Common_SwitchBtn_Item_UIBP:SetName(cfg.nameKey)
      ModeSelection_Common_SwitchBtn_Item_UIBP:SetSwitchCallback(self.OnRecordTabClick, self, cfg.tabType)
      if i == #tabs and btn and btn.Image_Line then
        self:SetWidgetVisible(btn.Image_Line, false)
      end
      self._recordTabBtns[cfg.tabType] = ModeSelection_Common_SwitchBtn_Item_UIBP
    end
  end
  self._recordTabType = RecordTabType.Dynamic
end

function ModeSelection_Mine_Record_UIBP:_RefreshTabSelectedState(tabType)
  if not self._recordTabBtns then
    return
  end
  for t, btn in pairs(self._recordTabBtns) do
    if btn and btn.SetSelected then
      btn:SetSelected(t == tabType)
    end
  end
end

function ModeSelection_Mine_Record_UIBP:OnRecordTabClick(tabType)
  self:SwitchRecordTab(tabType)
end

function ModeSelection_Mine_Record_UIBP:SwitchRecordTab(tabType)
  self._recordTabType = tabType
  self:_RefreshTabSelectedState(tabType)
  local hasData, grid = self:RefreshRecordListByTab(tabType)
  if self.UIRoot.WidgetSwitcherExt_History then
    local idx = hasData and tabType - 1 or 3
    self.UIRoot.WidgetSwitcherExt_History:SetActiveWidgetIndex(idx)
  end
  if hasData and grid then
    self:AddTimerOnce(0, function()
      if not self.UIRoot then
        return
      end
      self:RefreshRecordListByTab(tabType)
    end)
  end
end

function ModeSelection_Mine_Record_UIBP:_GroupRecordsByDate(records)
  records = records or {}
  local TimeUtil = require("client.common.time_util")
  local groups = {}
  local order = {}
  for _, rec in ipairs(records) do
    local ts = rec.timestamp
    if ts then
      local dayKey = TimeUtil.FormatTime_YMD(ts, true)
      local g = groups[dayKey]
      if not g then
        g = {
          timestamp = ts,
          records = {}
        }
        groups[dayKey] = g
        table.insert(order, dayKey)
      end
      table.insert(g.records, rec)
    end
  end
  local mainList = {}
  for _, dayKey in ipairs(order) do
    table.insert(mainList, groups[dayKey])
  end
  for _, g in ipairs(mainList) do
    table.sort(g.records, function(a, b)
      return (a.timestamp or 0) > (b.timestamp or 0)
    end)
    g.timestamp = g.records[1] and g.records[1].timestamp or g.timestamp
  end
  table.sort(mainList, function(a, b)
    return (a.timestamp or 0) > (b.timestamp or 0)
  end)
  return mainList
end

function ModeSelection_Mine_Record_UIBP:RefreshRecordListByTab(tabType)
  local grid, records
  if tabType == RecordTabType.Dynamic then
    grid = self.LoopScrollBox_Dynamic
    records = self:_BuildDynamicList()
    if not grid then
      return false
    end
    grid:SetData(records)
    self:RefreshLikeTotalText(records)
    return 0 < #records
  elseif tabType == RecordTabType.ClassicBR then
    grid = self.ExtendedLoopScrollGrid_BR
    records = self:_BuildClassicBRList()
  elseif tabType == RecordTabType.UGC then
    grid = self.ExtendedLoopScrollGrid_WOW
    records = self:_BuildUGCList()
    if not self._bUGCModMetaRequested then
      self._bUGCModMetaRequested = true
      self:_RequestUGCModMeta(self._ugcModIdList)
    end
  end
  if not grid then
    return false
  end
  local mainList = self:_GroupRecordsByDate(records)
  grid:SetData(mainList)
  for i = 1, #mainList do
    grid:SetSubData(i, mainList[i].records)
  end
  grid:InvalidateLayoutCache()
  return 0 < #mainList, grid
end

function ModeSelection_Mine_Record_UIBP:_CalcSegmentProgress(rating, minScore, nextScore)
  if not (rating and minScore) or not nextScore then
    return 0
  end
  local span = nextScore - minScore
  if span <= 0 then
    return 1
  end
  local p = (rating - minScore) / span
  if p < 0 then
    p = 0
  end
  if 1 < p then
    p = 1
  end
  return p
end

function ModeSelection_Mine_Record_UIBP:_MapModeIdxToTeamPerspective(modeIdx)
  local MAP = {
    {
      teamNum = 1,
      perspective = ENUM_PerspectiveType.TPP
    },
    {
      teamNum = 2,
      perspective = ENUM_PerspectiveType.TPP
    },
    {
      teamNum = 4,
      perspective = ENUM_PerspectiveType.TPP
    },
    {
      teamNum = 1,
      perspective = ENUM_PerspectiveType.FPP
    },
    {
      teamNum = 2,
      perspective = ENUM_PerspectiveType.FPP
    },
    {
      teamNum = 4,
      perspective = ENUM_PerspectiveType.FPP
    }
  }
  return MAP[modeIdx]
end

function ModeSelection_Mine_Record_UIBP:_GetClassicMaxSegmentAndRating()
  local ZoneSystem = require("client.slua.logic.teamup.logic_zone")
  local zoneID = ZoneSystem.nChooseZoneID
  if not zoneID or zoneID == 0 then
    zoneID = 1
  end
  local segTable = DataMgr.roleData.allzoneSegment
  local ratingTable = DataMgr.roleData.segment_rating
  if not segTable or not segTable[zoneID] then
    return nil, nil, nil
  end
  local segs = segTable[zoneID]
  local ratings = ratingTable and ratingTable[zoneID] or {}
  local maxSegment, maxRating, maxModeIdx
  for i = 1, 6 do
    local seg = segs[i]
    if seg and (not maxSegment or maxSegment < seg) then
      maxSegment = seg
      maxRating = ratings[i]
      maxModeIdx = i
    end
  end
  return maxSegment, maxRating, maxModeIdx
end

function ModeSelection_Mine_Record_UIBP:_BuildClassicSegmentRecordData()
  local data = {
    target = Target.Segment,
    title_id = 5588162
  }
  local ZoneSystem = require("client.slua.logic.teamup.logic_zone")
  local FuncUtil = require("common.func_util")
  local logic_season_const = require("client.logic.season.logic_season_const")
  local segmentLevel, rating, modeIdx = self:_GetClassicMaxSegmentAndRating()
  local curScore = math.floor(tonumber(rating) or 0)
  data.cur_score = curScore
  data.segment = segmentLevel
  if segmentLevel then
    local RankCfg = FuncUtil.GetRankTableData(segmentLevel, DataMgr.season_id)
    if RankCfg then
      local nextScore = math.floor(tonumber(RankCfg.NextIntegralScore) or 0)
      data.segment_name = RankCfg.Name or ""
      data.icon = RankCfg.SmallIcon128
      data.next_score = nextScore
      data.progress = self:_CalcSegmentProgress(rating, RankCfg.MinIntegral, RankCfg.NextIntegralScore)
      data.is_max_segment = RankCfg.IntegralTypeNew == logic_season_const.ClassicSeasonSegmentNewType_Conqueror
      if data.is_max_segment then
        data.progress = 1
        data.next_level_text = ""
      elseif rating and curScore < nextScore then
        data.next_level_text = LocUtil.LocalizeResFormat(588108, nextScore - curScore)
      else
        data.next_level_text = ""
      end
      local zoneID = ZoneSystem.nChooseZoneID
      if not zoneID or zoneID == 0 then
        zoneID = 1
      end
      local m = self:_MapModeIdxToTeamPerspective(modeIdx)
      if m then
        local logic_segment_title = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_segment_title)
        data.seg_title_id = logic_segment_title:GetSelfSegmentTitleIdByTeamNum(zoneID, m.teamNum, m.perspective)
      end
      local SeasonSystem = require("client.logic.season.logic_season")
      local modeStr
      if m then
        if m.perspective == ENUM_PerspectiveType.TPP then
          modeStr = m.teamNum == 1 and "solo" or m.teamNum == 2 and "duo" or m.teamNum == 4 and "squad"
        else
          modeStr = m.teamNum == 1 and "fppsolo" or m.teamNum == 2 and "fppduo" or m.teamNum == 4 and "fppsquad"
        end
      end
      local challengeScore
      if modeStr then
        challengeScore = SeasonSystem.GetChanllengeScoreAndFirstTag(zoneID, modeStr)
      end
      local challengeCfg = SeasonSystem.GetChanllengeCfg(segmentLevel)
      if challengeCfg and challengeScore then
        data.challenge_has = true
        data.challenge_active = challengeScore >= challengeCfg.AbleScore
        data.challenge_rate = SeasonSystem.CalChallengeProgressRate(challengeScore, challengeCfg.MaxScore, challengeCfg.AbleScore)
      else
        data.challenge_has = false
      end
      data.display_type = 1
      return data
    end
  end
  data.display_type = 0
  data.segment_name = ""
  data.next_score = 0
  data.progress = 0
  data.next_level_text = ""
  data.is_max_segment = false
  return data
end

function ModeSelection_Mine_Record_UIBP:_BuildPeakSegmentRecordData()
  local data = {
    target = Target.PeakSegment,
    title_id = 46063
  }
  local LogicPeakGameSegmentUtil = require("client.logic.PeakGame.LogicPeakGameSegmentUtil")
  local LogicPeakGameUtil = require("client.logic.PeakGame.LogicPeakGameUtil")
  local maxRatingInfo = LogicPeakGameSegmentUtil.GetSelfAllZoneCurSeasonMaxRatingInfo()
  local segment_id = maxRatingInfo and maxRatingInfo.segment_id
  local rating = maxRatingInfo and maxRatingInfo.rating
  local curScore = math.floor(tonumber(rating) or 0)
  data.cur_score = curScore
  data.segment = segment_id
  if segment_id then
    local rankCfg = LogicPeakGameUtil.GetPeakRankTableData(segment_id)
    if rankCfg then
      local nextScore = math.floor(tonumber(rankCfg.NextIntegralScore) or 0)
      data.segment_name = rankCfg.Name or ""
      data.icon = rankCfg.SmallIcon
      data.next_score = nextScore
      data.progress = self:_CalcSegmentProgress(rating, rankCfg.MinIntegral, rankCfg.NextIntegralScore)
      if rating and curScore < nextScore then
        data.next_level_text = LocUtil.LocalizeResFormat(588108, nextScore - curScore)
      else
        data.next_level_text = ""
      end
      data.display_type = 2
      return data
    end
  end
  data.segment_name = ""
  data.next_score = 0
  data.progress = 0
  data.next_level_text = ""
  data.display_type = 2
  return data
end

function ModeSelection_Mine_Record_UIBP:_BuildDynamicList()
  local logic_friendfeed_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friendfeed_data)
  if not logic_friendfeed_data or not logic_friendfeed_data.GetSelfFriendFeed then
    return {}
  end
  return logic_friendfeed_data:GetSelfFriendFeed() or {}
end

function ModeSelection_Mine_Record_UIBP:_BuildUGCList()
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  local historyKeyList = LogicUGC:GetHistoryKeyInfoList() or {}
  local historyMatchList = LogicUGC:GetHistoryMatchKeyInfoList() or {}
  local records = {}
  local modIdList = {}
  for mod_id, info in pairs(historyKeyList) do
    table.insert(records, {
      mod_id = mod_id,
      timestamp = info.play_time,
      total_play_time = info.total_play_time or 0,
      modInfo = LogicUGC:GetModByAllCache(mod_id)
    })
    table.insert(modIdList, mod_id)
  end
  for _, info in pairs(historyMatchList) do
    local mod_id = info.ugc_mod_id
    table.insert(records, {
      mod_id = mod_id,
      timestamp = info.play_time,
      total_play_time = info.total_play_time or 0,
      modInfo = LogicUGC:GetModByAllCache(mod_id)
    })
    table.insert(modIdList, mod_id)
  end
  self._ugcModIdList = modIdList
  return records
end

function ModeSelection_Mine_Record_UIBP:_RequestUGCModMeta(modIdList)
  if not modIdList or #modIdList == 0 then
    return
  end
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  if not LogicUGC or not LogicUGC.BatchGetModInfo then
    return
  end
  local _, ReqList, NotReqModList = LogicUGC:BatchGetModInfo(modIdList, LogicUGC.C_ModListTypes.History, nil, {bSplit = true})
  self._ugcNotReqModIdList = NotReqModList and 0 < #NotReqModList and NotReqModList or nil
  if not ReqList or #ReqList == 0 then
    LogicUGC:BatchGetModInfo(modIdList, LogicUGC.C_ModListTypes.History)
    self._ugcNotReqModIdList = nil
  end
end

function ModeSelection_Mine_Record_UIBP:_TryRequestNextUGCModMetaPage()
  if self._bUGCMetaPaging then
    return false
  end
  local pending = self._ugcNotReqModIdList
  if not pending or #pending == 0 then
    return false
  end
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  if not LogicUGC or not LogicUGC.BatchGetModInfo then
    return false
  end
  self._bUGCMetaPaging = true
  local _, ReqList, NotReqModList = LogicUGC:BatchGetModInfo(pending, LogicUGC.C_ModListTypes.History, nil, {bSplit = true})
  self._ugcNotReqModIdList = NotReqModList and 0 < #NotReqModList and NotReqModList or nil
  if not ReqList or #ReqList == 0 then
    LogicUGC:BatchGetModInfo(pending, LogicUGC.C_ModListTypes.History)
    self._ugcNotReqModIdList = nil
  end
  self._bUGCMetaPaging = false
  return true
end

function ModeSelection_Mine_Record_UIBP:_OnUGCListScrolled(offset)
  if not offset or offset <= 0 then
    return
  end
  if not self:_IsUGCListNearBottom(offset) then
    return
  end
  if self:_TryRequestNextUGCModMetaPage() then
    self:RefreshRecordListByTab(RecordTabType.UGC)
  end
end

function ModeSelection_Mine_Record_UIBP:_IsUGCListNearBottom(offset)
  local grid = self.ExtendedLoopScrollGrid_WOW
  if not grid or not grid.UIRoot then
    return true
  end
  local okView, viewSize = pcall(function()
    return grid.UIRoot.GetViewSize and grid.UIRoot:GetViewSize() or nil
  end)
  if not (okView and viewSize) or not viewSize.Y then
    return true
  end
  local okContent, contentSize = pcall(function()
    return grid.UIRoot.GetContentSize and grid.UIRoot:GetContentSize() or nil
  end)
  if not (okContent and contentSize) or not contentSize.Y then
    return true
  end
  local total = contentSize.Y
  local view = viewSize.Y
  return offset + view >= total - view
end

function ModeSelection_Mine_Record_UIBP:_BuildClassicBRList()
  local history_combat_cfg = require("client.logic.combat.history.history_combat_cfg")
  local logic_history_combat = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_history_combat)
  local list = logic_history_combat:GetHistoryList(history_combat_cfg.EBattleType.All)
  return list or {}
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
return class(ui_base, nil, ModeSelection_Mine_Record_UIBP)
