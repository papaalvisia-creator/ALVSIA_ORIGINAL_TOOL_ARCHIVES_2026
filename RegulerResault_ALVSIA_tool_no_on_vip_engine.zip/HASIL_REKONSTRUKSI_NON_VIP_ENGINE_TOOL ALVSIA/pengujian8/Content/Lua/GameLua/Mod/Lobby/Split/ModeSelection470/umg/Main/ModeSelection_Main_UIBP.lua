local ModeSelection_Main_UIBP = {}
local ModeSelection_Explore_Data = require("GameLua.Mod.Lobby.Split.ModeSelection470.logic.ModeSelection_Explore_Data")
local logic_modeselection_frienddata = require("GameLua.Mod.Lobby.Split.ModeSelection470.logic.logic_modeselection_frienddata")
local Config_UGC = require("client.slua.logic.ugc.config_ugc")
local TableUtil = require("common.table_util")
local mode_selection_multi_util = require("GameLua.Mod.Lobby.Split.ModeSelection470.logic.mode_selection_multi_util")
local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
local SearchEntry = require("GameLua.Mod.Lobby.Split.ModeSelection470.umg.Main.ModeSelection_Main_UIBP_SearchEntry")
local MenuLogic = require("GameLua.Mod.Lobby.Split.ModeSelection470.umg.Main.ModeSelection_Main_UIBP_Menu")
local DownGuide = require("GameLua.Mod.Lobby.Split.ModeSelection470.umg.Main.ModeSelection_Main_UIBP_DownGuide")
local BgVideo = require("GameLua.Mod.Lobby.Split.ModeSelection470.umg.Main.ModeSelection_Main_UIBP_BgVideo")
local UGCGuide = require("GameLua.Mod.Lobby.Split.ModeSelection470.umg.Main.ModeSelection_Main_UIBP_UGCGuide")
local RoomEntry = require("GameLua.Mod.Lobby.Split.ModeSelection470.umg.Main.ModeSelection_Main_UIBP_RoomEntry")
local SIDE_TAB_ITEM_MODULE = "GameLua.Mod.Lobby.Split.ModeSelection470.umg.Main.Item.Tab.ModeSelection_Common_SideTab_Item_UIBP"
local TOP_TAB_ITEM_MODULE = "GameLua.Mod.Lobby.Split.ModeSelection470.umg.Main.Item.Tab.ModeSelection_Common_TopTab_Item_UIBP"
ModeSelection_Main_UIBP.MENU1_CONFIG = {
  {
    key = "MINE",
    locId = 588067,
    widget = "CanvasPanel_Mine",
    topTab = logic_modeselection_frienddata.MineTabConfig,
    Icon = "/Game/Mod/Lobby/Split/ModeSelection_New/Atlas/Common/Frames/Img_Common_Mine_png.Img_Common_Mine_png"
  },
  {
    key = "EXPLORE",
    locId = 588068,
    widget = "CanvasPanel_Explore",
    topTab = ModeSelection_Explore_Data.TopTabConfig,
    Icon = "/Game/Mod/Lobby/Split/ModeSelection_New/Atlas/Common/Frames/Img_Common_Find_png.Img_Common_Find_png",
    UIKey = "ModeSelection_Find_Main_UIBP"
  },
  {
    key = "FRIEND",
    locId = 588069,
    widget = "CanvasPanel_Friend",
    topTab = logic_modeselection_frienddata.FriendTabConfig,
    Icon = "/Game/Mod/Lobby/Split/ModeSelection_New/Atlas/Common/Frames/Img_Common_Friend_png.Img_Common_Friend_png",
    hideInBluehole = true
  }
}

function ModeSelection_Main_UIBP.BuildMenu1Config()
  local bBluehole = PublishRegionMacros.IsBlueholeOperationRegion()
  local result = {}
  for _, config in ipairs(ModeSelection_Main_UIBP.MENU1_CONFIG) do
    if not bBluehole or not config.hideInBluehole then
      result[#result + 1] = config
    end
  end
  return result
end

function ModeSelection_Main_UIBP:IsMenu1Available(key)
  for _, config in ipairs(self.MENU1_CONFIG) do
    if config.key == key then
      return true
    end
  end
  return false
end

function ModeSelection_Main_UIBP:ctor(selfType, url_params)
  self.url_params = url_params
  self._exploreUI = nil
  self._curOwner = nil
  self._curMenuIndex = nil
  self._curTopTabIndex = nil
  self._topTabUI = nil
  self._bSkipAutoGuide = false
  self.MENU1_CONFIG = ModeSelection_Main_UIBP.BuildMenu1Config()
end

function ModeSelection_Main_UIBP:OnInitialize()
  self._bSkipAutoGuide = false
  if self.UIRoot then
    self.UIRoot.needAutoPlay = false
  end
  for _, config in ipairs(ModeSelection_Main_UIBP.MENU1_CONFIG) do
    local widget = self.UIRoot[config.widget]
    if widget then
      self:SetWidgetVisible(widget, self:IsMenu1Available(config.key))
    end
  end
  self:SetWidgetVisible(self.UIRoot.LoopScrollBox_Menu2_2, true)
  self:SetWidgetVisible(self.UIRoot.Search, true)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Search, false)
  if self.UIRoot.CanvasPanel_Room then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Room, false)
  end
  self.LoopScrollBox_Menu1 = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_Menu1, SIDE_TAB_ITEM_MODULE)
  self.LoopScrollBox_Menu2_2 = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_Menu2_2, TOP_TAB_ITEM_MODULE)
  self:_PreloadBgVideoAssets()
  self:CheckNeedShowUGCModeGuide()
  self:_StopDownGuide()
end

function ModeSelection_Main_UIBP:RegistEvents()
  self:AddOnClickedEventByControl(self.UIRoot.Button_Close, self.OnClickButton_Close, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Tab, self.OnClickWoWTab, self)
  if self.UIRoot.Search then
    self:AddControlEventByControl(self.UIRoot.Search.message_input, "OnTextChanged", self.OnSearchEntryTextChanged, self)
    self:AddControlEventByControl(self.UIRoot.Search.message_input, "OnTextCommitted", self.OnSearchEntryCommitted, self)
    self:AddOnClickedEventByControl(self.UIRoot.Search.close, self.OnClickSearchEntryClear, self)
    if self.UIRoot.Search.Button_Search then
      self:AddOnClickedEventByControl(self.UIRoot.Search.Button_Search, SearchEntry.OnClickSearchEntrySearch, self)
    end
    if self.UIRoot.Search.Button_Text then
      self:AddOnClickedEventByControl(self.UIRoot.Search.Button_Text, self.OnClickSearchEntry, self)
    end
  end
  if self.UIRoot.Button_Explain then
    self:AddOnClickedEventByControl(self.UIRoot.Button_Explain, self.OnClickButton_Explain, self)
  end
  if self.UIRoot.CanvasPanel_Room then
    if self.UIRoot.Button_Room then
      self:AddOnClickedEventByControl(self.UIRoot.Button_Room, RoomEntry.OnClickButton_Room, self)
    end
    if self.UIRoot.Button_Train then
      self:AddOnClickedEventByControl(self.UIRoot.Button_Train, RoomEntry.OnClickButton_Train, self)
    end
  end
  self:AddCommonEvent(EVENTTYPE_DOWNLOAD, EVENTID_PUFFER_JSON_POSTPROCESS, self._RefreshRoomEntryDownloadState, self)
  self:AddCommonEvent(EVENTTYPE_DOWNLOAD, EVENTID_PUFFER_REFRESH_SOCIALISLAND, self._RefreshRoomEntryDownloadState, self)
  if self.UIRoot.Anim_Down_Disappear then
    self:AddOnAnimationFinishedEvent("Anim_Down_Disappear", self._OnDownGuideAnimationFinished, self)
  end
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_NEWSERCHHITTEXT_MOD, self.OnSearchEntryHitText, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_HOT_SEARCH_RSP, self.OnSearchEntryHotSearch, self)
  self:AddCommonEvent(EVENTTYPE_CLICK, EVENTID_ICON_SHOW, self.OnRatingTipsStateChanged, self)
  if self.UIRoot.Button_TipsMask then
    self:AddOnClickedEventByControl(self.UIRoot.Button_TipsMask, self.OnClickRatingTipsMask, self)
    self:SetWidgetVisible(self.UIRoot.Button_TipsMask, false, true)
  end
end

function ModeSelection_Main_UIBP:OnRatingTipsStateChanged()
  self:_RefreshRatingTipsMask()
end

function ModeSelection_Main_UIBP:OnClickRatingTipsMask()
  self:PlayAudio(sound_config.click_v1)
  local recordUI = UIManager.GetUI(UIManager.UI_Config.ModeSelection_Mine_Record_UIBP)
  if recordUI and recordUI.HideCurrentRatingTips then
    recordUI:HideCurrentRatingTips()
  end
  self:_RefreshRatingTipsMask()
end

function ModeSelection_Main_UIBP:_RefreshRatingTipsMask()
  if not self.UIRoot.Button_TipsMask then
    return
  end
  local bShow = false
  local recordUI = UIManager.GetUI(UIManager.UI_Config.ModeSelection_Mine_Record_UIBP)
  if recordUI and recordUI.HasRatingTipsCard then
    bShow = recordUI:HasRatingTipsCard()
  end
  self:SetWidgetVisible(self.UIRoot.Button_TipsMask, bShow, true)
end

function ModeSelection_Main_UIBP:OpenSearch(Index, HitText)
  SearchEntry.OpenSearch(self, Index, HitText)
end

function ModeSelection_Main_UIBP:CloseSearch()
  SearchEntry.CloseSearch(self)
end

function ModeSelection_Main_UIBP:_OnChildWindowClose(childUI)
  SearchEntry.OnChildWindowClose(self, childUI)
end

function ModeSelection_Main_UIBP:_RestorePageAfterSearch()
  SearchEntry.RestorePageAfterSearch(self)
end

function ModeSelection_Main_UIBP:OnClickSearchEntry()
  SearchEntry.OnClickSearchEntry(self)
end

function ModeSelection_Main_UIBP:OnSearchEntryTextChanged(Text)
  SearchEntry.OnSearchEntryTextChanged(self, Text)
end

function ModeSelection_Main_UIBP:OnSearchEntryCommitted(Text, CommitMethod)
  SearchEntry.OnSearchEntryCommitted(self, Text, CommitMethod)
end

function ModeSelection_Main_UIBP:OnClickSearchEntryClear()
  SearchEntry.OnClickSearchEntryClear(self)
end

function ModeSelection_Main_UIBP:ClearSearchEntryText()
  SearchEntry.ClearSearchEntryText(self)
end

function ModeSelection_Main_UIBP:OnSearchEntryHitText(_, _, Text)
  SearchEntry.OnSearchEntryHitText(self, _, _, Text)
end

function ModeSelection_Main_UIBP:OnSearchEntryHotSearch()
  SearchEntry.OnSearchEntryHotSearch(self)
end

function ModeSelection_Main_UIBP:_SetSearchEntryHint(Text)
  SearchEntry.SetSearchEntryHint(self, Text)
end

function ModeSelection_Main_UIBP:OnPostInitialize()
  self:UpdateUI()
  local logic_ugc_search = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_search)
  self:_SetSearchEntryHint(logic_ugc_search:GetRecommendSearchText())
  logic_ugc_search:ReqGetSearchInfo()
  local tlogUtil = require("GameLua.Mod.Lobby.Split.ModeSelection470.util.ModeSelectionTLogUtil")
  self:AddTimerLoop(0.2, function()
    tlogUtil.ScanMain(self)
  end, TIMER_INFINITE, 0.2)
  self:UpdateUGCLock()
  self.UIRoot.Search.message_input:SetWidgetVisibility(UEnums.ESlateVisibility.HitTestInvisible)
  local openModId = self.url_params and self.url_params.modId
  if openModId then
    self._shareAttr = {
      src = self.url_params.src,
      uid = self.url_params.uid,
      exclusive_share_id = self.url_params.exclusive_share_id
    }
    self.url_params = nil
    self:AddTimerOnce(0, function()
      self:OpenWowModDetail(openModId)
    end)
  end
  local openViewId = self.url_params and tonumber(self.url_params.viewId)
  if openViewId then
    self.url_params = nil
    self:AddTimerOnce(0, function()
      self:OpenViewDetailByViewId(openViewId)
    end)
  end
  local hallParams = self:_GetWoWTabJumpParams(self.url_params)
  if hallParams then
    self._bSkipAutoGuide = true
    self.url_params = nil
    self:AddTimerOnce(0, function()
      self:OnClickWoWTab(nil, hallParams)
    end)
  end
  RoomEntry.Init(self)
  self:InitWOWRedDot()
  self:CheckNeedShowGuide()
  self:_ApplyEnterFadein()
  if not self.vng18IconUI then
    local UIUtil = require("client.common.ui_util")
    self.vng18IconUI = UIUtil.InitChildWindow18Logo(self, "CanvasPanel_0", 0.8, 0, 0, -20, 100)
  end
end

function ModeSelection_Main_UIBP:UpdateJumpData(url_params)
  local viewId = url_params and tonumber(url_params.viewId)
  if viewId then
    self:OpenViewDetailByViewId(viewId)
    return
  end
  local modId = url_params and url_params.modId
  if modId then
    self:OpenWowModDetail(modId)
    return
  end
  local hallParams = self:_GetWoWTabJumpParams(url_params)
  if hallParams then
    self:OnClickWoWTab(nil, hallParams)
  end
end

function ModeSelection_Main_UIBP:OpenWowModDetail(modId)
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  local bOpen, levelLimit = LogicUGC:IsWOWOpen()
  if not bOpen then
    if levelLimit then
      ShowNotice(LocUtil.LocalizeResFormat(31028, levelLimit))
    end
    return
  end
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_WowRedPoint, false)
  self:_SwitchMenu(2)
  local topTabConfig = ModeSelection_Explore_Data.TopTabConfig
  for tabIndex, tabData in ipairs(topTabConfig) do
    if tabData.owner == ModeSelection_Explore_Data.Owner.Discover then
      self.LoopScrollBox_Menu2_2:Select(tabIndex)
      self:OnTopTabClicked(tabIndex, tabData)
      break
    end
  end
  local exploreUI = self.EXPLORE
  if exploreUI and exploreUI.ScrollToWowMod then
    exploreUI:ScrollToWowMod(modId)
  end
  local detailParams = {colorSwitchIndex = 0, bFromModeSelection = true}
  if self._shareAttr and self._shareAttr.src and self._shareAttr.uid then
    detailParams.src = self._shareAttr.src
    detailParams.shareuid = self._shareAttr.uid
    detailParams.exclusive_share_id = self._shareAttr.exclusive_share_id
    local Logic_UGC_Share = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_share)
    if Logic_UGC_Share then
      Logic_UGC_Share.mod_id = tonumber(modId) or modId
    end
  end
  self._shareAttr = nil
  LogicUGC:BatchGetModInfo({
    tonumber(modId) or modId
  }, LogicUGC.C_ModListTypes.HotTheme, function(MetaList)
    local _, Meta = next(MetaList or {})
    local modInfo = Meta and (Meta.pub_mod_meta or Meta) or nil
    if not modInfo then
      log_warning("ModeSelection_Main_UIBP:OpenWowModDetail no modInfo, modId:" .. tostring(modId))
      ShowNotice(70060)
      return
    end
    UIManager.ShowUI(UIManager.UI_Config.UGC_ModDetail_Main, nil, modInfo, detailParams)
  end)
end

function ModeSelection_Main_UIBP:_GetWoWTabJumpParams(url_params)
  if not url_params or not url_params.menuList then
    return nil
  end
  local mode_selection_macro = require("client.slua.logic.mode_selection.mode_selection_macro")
  local StringUtil = require("common.string_util")
  local menuList = StringUtil.Split(tostring(url_params.menuList), "|")
  if tonumber(menuList[1]) ~= mode_selection_macro.Enum_TabID.UGC then
    return nil
  end
  return {
    creationTab = url_params.creationTab,
    openthemeID = url_params.openthemeID,
    openauthorID = url_params.openauthorID,
    homeSubTabID = url_params.homeSubTabID,
    homeRankFilterIndex = url_params.homeRankFilterIndex,
    openUgcSubTabID = url_params.openUgcSubTabID
  }
end

function ModeSelection_Main_UIBP:OpenViewDetailByViewId(viewId)
  if not viewId then
    return false
  end
  local logic_mode_selection = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection)
  local viewInfo = logic_mode_selection and logic_mode_selection:GetSubviewInfoBySubviewID(viewId)
  if not viewInfo then
    log_warning("ModeSelection_Main_UIBP:OpenViewDetailByViewId no view info, viewId=" .. tostring(viewId))
    return false
  end
  local modId = tonumber(viewInfo.mod_id)
  if modId and 0 < modId then
    local logicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
    local meta = logicUGC and logicUGC:GetModByAllCache(modId)
    if meta then
      UIManager.ShowUI(UIManager.UI_Config.UGC_ModDetail_Main, nil, meta, {
        sourceModule = Config_UGC.Source_Open_Detail.UGCMain,
        bFromModeSelection = true
      })
      return true
    end
  end
  viewInfo = TableUtil.LiteCopy(viewInfo, true)
  printf("ModeSelection_Main_UIBP:OpenViewDetailByViewId open sideber, viewId:%s, hasOptions:%s", tostring(viewId), viewInfo.options ~= nil)
  local modeTLog = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_tlog)
  viewInfo.modeTLogContext = modeTLog and modeTLog:ReportCardClick(viewInfo, 0) or nil
  if mode_selection_multi_util.IsClassicMultiGroupView(viewInfo) then
    local groupView = viewInfo.group_view_v2 or {}
    if #groupView <= 1 then
      local groupSource
      for _, candidate in pairs(logic_mode_selection:GetViewDictionary() or {}) do
        local candidateGroup = candidate.group_view_v2 or {}
        if candidate.group_key_v2 == viewInfo.group_key_v2 and #candidateGroup > #groupView and (not groupSource or #candidateGroup > #groupSource.group_view_v2 or #candidateGroup == #groupSource.group_view_v2 and candidate.id < groupSource.id) then
          groupSource = candidate
        end
      end
      if groupSource then
        viewInfo.group_view_v2 = groupSource.group_view_v2
      end
    end
    local isRank = viewInfo.is_ranked == 1
    local _, rankedGroupView, unrankedGroupView = mode_selection_multi_util.BuildMultiGroupView(viewInfo)
    local selectedGroup = isRank and rankedGroupView or unrankedGroupView
    local selectViewIDs = mode_selection_multi_util.TryReuseSelectedViews(selectedGroup)
    UIManager.ShowUI(UIManager.UI_Config.ModeSelection_Sideber_Main_RandomMap_UIBP, viewInfo, {
      selectViewIDs = TableUtil.CopyTable(selectViewIDs),
      isRank = isRank
    })
  else
    UIManager.ShowUI(UIManager.UI_Config.ModeSelection_Sideber_Main_UIBP, viewInfo)
  end
  return true
end

function ModeSelection_Main_UIBP:OnClose()
  self._searchUI = nil
  self._searchPageState = nil
  self:_StopDownGuide()
  local modeTLog = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_tlog)
  modeTLog:SendExposeReq()
  local ugcReport = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCNewTLogReport)
  ugcReport:SendExposeReq()
  self.modeTLogUI = nil
  self:StopFeedBgVideo()
  self:_ReleaseBgVideoPreloadAssets()
  for k, v in pairs(ModeSelection_Main_UIBP.MENU1_CONFIG) do
    self[v.key] = nil
  end
  self._topTabUI = nil
  local logic_ugc_hot_page = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_hot_page)
  logic_ugc_hot_page:Report()
end

function ModeSelection_Main_UIBP:GetDataForJumpBack()
  printf("ModeSelection_Main_UIBP:GetDataForJumpBack menuIndex:%s, topTabIndex:%s", self._curMenuIndex, self._curTopTabIndex)
  return {
    uiData = {
      curMenuIndex = self._curMenuIndex,
      topTabIndex = self._curTopTabIndex
    }
  }
end

function ModeSelection_Main_UIBP:JumpBack(uiData)
  printf("ModeSelection_Main_UIBP:JumpBack hasUiData:%s, savedMenuIndex:%s, savedTopTabIndex:%s, curMenuIndex:%s, curTopTabIndex:%s", uiData ~= nil, uiData and uiData.curMenuIndex, uiData and uiData.topTabIndex, self._curMenuIndex, self._curTopTabIndex)
  if not uiData then
    return
  end
  local menuIndex = uiData.curMenuIndex
  if menuIndex and not self.MENU1_CONFIG[menuIndex] then
    printf("ModeSelection_Main_UIBP:JumpBack menuIndex:%s is hidden in current region, skip restore", menuIndex)
    self:_ApplyEnterFadein()
    return
  end
  if menuIndex and menuIndex ~= self._curMenuIndex then
    self:_SwitchMenu(menuIndex)
  end
  local topTabIndex = uiData.topTabIndex
  local menuConfig = self.MENU1_CONFIG[self._curMenuIndex]
  if topTabIndex and topTabIndex ~= self._curTopTabIndex and menuConfig and menuConfig.topTab and menuConfig.topTab[topTabIndex] then
    self.LoopScrollBox_Menu2_2:Select(topTabIndex)
    self:OnTopTabClicked(topTabIndex, menuConfig.topTab[topTabIndex])
  end
  self:_ApplyEnterFadein()
end

function ModeSelection_Main_UIBP:OnClickButton_Close()
  self:PlayAudio(sound_config.click_v1)
  self:CloseSelf()
end

function ModeSelection_Main_UIBP:OnAndroidBack()
  self:CloseSelf()
end

function ModeSelection_Main_UIBP:OnMenu1TabClicked(index, menuData)
  self:_SwitchMenu(index)
  self:PlayAnimation("Anim_Switch", 0, 1, 0, 1)
end

function ModeSelection_Main_UIBP:OnTopTabClicked(index, tabData)
  if not tabData then
    return
  end
  if tabData.owner ~= ModeSelection_Explore_Data.Owner.Discover then
    local swipeGuideUI = UIManager.GetUI(UIManager.UI_Config.ModeSelection_Guide_SwipeGuide_UIBP)
    if swipeGuideUI then
      swipeGuideUI:CloseSelf()
    end
  end
  self._curTopTabIndex = index
  self:CloseSearch()
  local logic_ugc_search = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_search)
  self:_SetSearchEntryHint(logic_ugc_search:GetRecommendSearchText())
  local tlogUtil = require("GameLua.Mod.Lobby.Split.ModeSelection470.util.ModeSelectionTLogUtil")
  local pages = {
    ModeSelection_Mine_Main_UIBP = TLogEventDefine.MODE_SELECTION_PAGE_MY_MYGAME,
    ModeSelection_Friend_Create_UIBP_2 = TLogEventDefine.MODE_SELECTION_PAGE_FRIEND_PLAYING,
    ModeSelection_Friend_Create_UIBP = TLogEventDefine.MODE_SELECTION_PAGE_FRIEND_CREATED
  }
  local page
  if tabData.UIKey then
    page = pages[tabData.UIKey]
  else
    page = tlogUtil.GetExplorePage(tabData.owner)
  end
  if self.modeTLogPage ~= page then
    local modeTLog = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_tlog)
    modeTLog:UpdateRequestId()
  end
  self.modeTLogPage = page
  if tabData.UIKey then
    self:_SwitchTopTabSubUI(tabData)
    self.modeTLogUI = self._topTabUI and self._topTabUI[tabData.UIKey]
  else
    self.modeTLogUI = self.EXPLORE
    self._curOwner = tabData.owner
    if not tabData.bWithFeed then
      self:StopFeedBgVideo()
    end
    self:_RefreshExploreByOwner(true)
    self:_StartDownGuide()
  end
end

function ModeSelection_Main_UIBP:OnClickWoWTab(openModId, extraHallParams)
  self:PlayAudio(sound_config.click_v1)
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  local bOpen, levelLimit = LogicUGC:IsWOWOpen()
  if not bOpen then
    if levelLimit then
      ShowNotice(LocUtil.LocalizeResFormat(31028, levelLimit))
    end
    return
  end
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_WowRedPoint, false)
  local LogicUGCTemplate = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCTemplate)
  LogicUGCTemplate:ReqTemplates()
  local logic_ugc_WOWPass = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_WOWPass)
  logic_ugc_WOWPass:ReqUGCWOWRedPointInfo()
  if UIManager.IsUIShow(UIManager.UI_Config.UGC_RightPage_UIBP) then
    UIManager.CloseUI(UIManager.UI_Config.UGC_RightPage_UIBP)
    local Lobby_Main_Control = require("client.slua.logic.lobby.Main.Lobby_Main_Control")
    if Lobby_Main_Control.curPage == ENUM_LobbyPageType.Right then
      Lobby_Main_Control.curPage = ENUM_LobbyPageType.Mid
    end
  end
  local hallUI = UIManager.GetUI(UIManager.UI_Config.UGCMainPanelFindWorksHall)
  if hallUI then
    hallUI:SetSkipCloseCallback(true)
    UIManager._ProcessCloseUI(UIManager.UI_Config.UGCMainPanelFindWorksHall)
  end
  local shareHallParams
  if openModId then
    shareHallParams = {modId = openModId}
    if self._shareAttr then
      shareHallParams.src = self._shareAttr.src
      shareHallParams.uid = self._shareAttr.uid
      shareHallParams.exclusive_share_id = self._shareAttr.exclusive_share_id
      log("[share_incentive] ModeSelection470 forward shareAttr to hall: src=" .. tostring(shareHallParams.src) .. " uid=" .. tostring(shareHallParams.uid) .. " exclusive_share_id=" .. tostring(shareHallParams.exclusive_share_id))
      self._shareAttr = nil
    end
  end
  if type(extraHallParams) == "table" then
    shareHallParams = shareHallParams or {}
    for key, value in pairs(extraHallParams) do
      shareHallParams[key] = value
    end
  end
  UIManager.ShowUI(UIManager.UI_Config.UGCMainPanelFindWorksHall, shareHallParams, {
    bFullForm = true,
    onCloseCallback = function()
      UIManager.ShowUI(UIManager.UI_Config.ModeSelection_Main_UIBP)
    end
  })
  self:CloseSelf()
end

function ModeSelection_Main_UIBP:OnClickButton_Explain()
  self:PlayAudio(sound_config.click_v1)
  local logic_modeselection_guide = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_modeselection_guide)
  logic_modeselection_guide:ShowGuide()
end

function ModeSelection_Main_UIBP:UpdateUI()
  log(bWriteLog and "ModeSelection_Main_UIBP:UpdateUI")
  self.LoopScrollBox_Menu1:SetData(self.MENU1_CONFIG)
  self.LoopScrollBox_Menu1:Select(2)
  self:_SwitchMenu(2)
end

function ModeSelection_Main_UIBP:_SwitchMenu(index)
  MenuLogic.SwitchMenu(self, index)
  self:AddTimerOnce(0, function()
    if slua.isValid(self.UIRoot) then
      self:CheckNeedShowGuide()
    end
  end)
end

function ModeSelection_Main_UIBP:_RequestFriendTabData()
  MenuLogic.RequestFriendTabData(self)
end

function ModeSelection_Main_UIBP:_RequestMineTabData()
  MenuLogic.RequestMineTabData(self)
end

function ModeSelection_Main_UIBP:_HideAllMenuContent()
  MenuLogic.HideAllMenuContent(self)
end

function ModeSelection_Main_UIBP:_RefreshExploreByOwner(bForceRefresh)
  if not self.EXPLORE then
    return
  end
  self.EXPLORE:RefreshByOwner(self._curOwner, bForceRefresh)
end

function ModeSelection_Main_UIBP:_IsExploreDiscoverTab()
  local config = self._curMenuIndex and self.MENU1_CONFIG[self._curMenuIndex]
  if not config or config.key ~= "EXPLORE" then
    return false
  end
  return self._curOwner == ModeSelection_Explore_Data.Owner.Discover
end

function ModeSelection_Main_UIBP:_ApplyEnterFadein()
  if not self.UIRoot or not self.UIRoot.Fadein then
    return
  end
  local anim = self.UIRoot.Fadein
  self:StopAnimation("Fadein")
  if self:_IsExploreDiscoverTab() then
    self:PlayUserWidgetAnimation(anim, 0, 1, 0, 1)
  else
    local endTime = anim:GetEndTime()
    if endTime then
      self.UIRoot:PlayAnimationTo(anim, endTime, endTime, 1, 0, 1)
    end
  end
end

function ModeSelection_Main_UIBP:OnTopTabRequestClassicFadein(tabData)
  if self.EXPLORE then
  end
end

function ModeSelection_Main_UIBP:_ConsumePendingClassicFadein()
  if self.EXPLORE then
  end
end

function ModeSelection_Main_UIBP:_IsDownGuidePage()
  return DownGuide.IsDownGuidePage(self)
end

function ModeSelection_Main_UIBP:_StartDownGuide()
  DownGuide.StartDownGuide(self)
end

function ModeSelection_Main_UIBP:_StopDownGuide()
  DownGuide.StopDownGuide(self)
end

function ModeSelection_Main_UIBP:_SyncDownGuide()
  DownGuide.SyncDownGuide(self)
end

function ModeSelection_Main_UIBP:_OnDownGuideAnimationFinished()
  DownGuide.OnDownGuideAnimationFinished(self)
end

function ModeSelection_Main_UIBP:_PreloadBgVideoAssets()
  BgVideo.PreloadBgVideoAssets(self)
end

function ModeSelection_Main_UIBP:_ReleaseBgVideoPreloadAssets()
  BgVideo.ReleaseBgVideoPreloadAssets(self)
end

function ModeSelection_Main_UIBP:_IsExploreMenu()
  local config = self._curMenuIndex and self.MENU1_CONFIG[self._curMenuIndex]
  return not self._searchPageState and config ~= nil and config.key == "EXPLORE"
end

function ModeSelection_Main_UIBP:PlayFeedBgVideo(bgUrl, bgImageLeftUrl, bgImageRightUrl)
  BgVideo.PlayFeedBgVideo(self, bgUrl, bgImageLeftUrl, bgImageRightUrl)
end

function ModeSelection_Main_UIBP:StopFeedBgVideo()
  BgVideo.StopFeedBgVideo(self)
end

function ModeSelection_Main_UIBP:SetFeedBgVideoVisible(bVisible)
  BgVideo.SetFeedBgVideoVisible(self, bVisible)
end

function ModeSelection_Main_UIBP:OnMediaOpened(filePath)
  BgVideo.OnMediaOpened(self, filePath)
end

function ModeSelection_Main_UIBP:OnSetMediaContentResolution()
  BgVideo.OnSetMediaContentResolution(self)
end

function ModeSelection_Main_UIBP:SetFeedBgVideoScrollOffset(offset)
  BgVideo.SetFeedBgVideoScrollOffset(self, offset)
end

function ModeSelection_Main_UIBP:_IsNeedCreateRetryTimer(bRetryWithAndroid)
  return BgVideo.IsNeedCreateRetryTimer(self, bRetryWithAndroid)
end

function ModeSelection_Main_UIBP:_SwitchTopTabSubUI(tabData)
  MenuLogic.SwitchTopTabSubUI(self, tabData)
end

function ModeSelection_Main_UIBP:_RefreshRoomEntryDownloadState()
  RoomEntry.UpdateDownloadState(self)
end

function ModeSelection_Main_UIBP:UpdateUGCLock()
  UGCGuide.UpdateUGCLock(self)
end

function ModeSelection_Main_UIBP:CheckNeedShowGuide()
  UGCGuide.CheckNeedShowGuide(self)
end

function ModeSelection_Main_UIBP:CheckNeedShowUGCModeGuide()
  UGCGuide.CheckNeedShowUGCModeGuide(self)
end

function ModeSelection_Main_UIBP:InitWOWRedDot()
  UGCGuide.InitWOWRedDot(self)
end

local Trait = require("common.trait")
local ui_base = require("client.slua_ui_framework.base")
local Traits = {
  require("client.slua.umg.common.video.video_trait")
}
return Trait.TraitClass(ui_base, nil, ModeSelection_Main_UIBP, Traits)
