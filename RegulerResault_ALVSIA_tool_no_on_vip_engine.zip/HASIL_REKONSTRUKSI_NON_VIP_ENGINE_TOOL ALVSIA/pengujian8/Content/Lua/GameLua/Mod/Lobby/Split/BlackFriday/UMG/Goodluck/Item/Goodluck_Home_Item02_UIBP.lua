local Goodluck_Home_Item02_UIBP = {}
local BlackFridayLuckyCardDisplayConfig = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.BlackFridayLuckyCardDisplayConfig")
local CARD_TIME_STATE = BlackFridayLuckyCardDisplayConfig.CardTimeState
local EXPIRED_TEXT_ID = 9910111
local UPCOMING_TEXT_ID = 18141393
local BENEFIT_ITEM_LUA_PATH = "GameLua.Mod.Lobby.Split.BlackFriday.UMG.Goodluck.Item.Goodluck_Enter_UIBP"
local BENEFIT_ITEM_BP_PATH = "/Game/Mod/Lobby/Split/BlackFriday/Goodluck/Item/Goodluck_Enter_UIBP.Goodluck_Enter_UIBP"
local PREPLACED_BENEFIT_WIDGET_NAMES = {
  "Goodluck_Enter_UIBP",
  "Goodluck_Enter_UIBP_40"
}
local MAX_BENEFIT_COUNT = 3
local CARD_IMAGE_TINT_EXPIRED = 0.4
local SAMSUNG_SUBSCRIBE_TEXT_ID = 187336

local function IsConfiguredString(vValue)
  local sValue = tostring(vValue or "")
  return sValue ~= "" and sValue ~= "0"
end

local function GetDisplayName(vNameTextId)
  local nTextId = tonumber(vNameTextId)
  if nTextId and 0 < nTextId then
    return LocUtil.GetLocalizeResStr(nTextId)
  end
  return tostring(vNameTextId or "")
end

local function FormatDate(sDateTime)
  local TimeUtil = require("client.common.time_util")
  local nTimeStamp = TimeUtil.TimeStringToUnixstamp(tostring(sDateTime or ""), false)
  if nTimeStamp <= 0 then
    return ""
  end
  return TimeUtil.FormatTime_MD(nTimeStamp, false, false)
end

local function FormatDateRange(sStartTime, sEndTime)
  local sStartDate = FormatDate(sStartTime)
  local sEndDate = FormatDate(sEndTime)
  if sStartDate == "" then
    return sEndDate
  end
  if sEndDate == "" or sStartDate == sEndDate then
    return sStartDate
  end
  return string.format("%s-%s", sStartDate, sEndDate)
end

local function BuildDisplayRelations(tRelations, nSelectedGroupId)
  local tDisplayRelations, tByKey = {}, {}
  for _, tRelation in ipairs(tRelations) do
    if nSelectedGroupId == 0 or nSelectedGroupId == tonumber(tRelation.GroupID) then
      local sKey = string.format("%s:%s:%s:%s:%s:%s", tostring(tRelation.CardID), tostring(tRelation.SourceType), tostring(tRelation.SourceID), tostring(tRelation.Slot), tostring(tRelation.BenefitTextID), tostring(tRelation.ExternalBenefitBarRuleTextID or 0))
      local tDisplayRelation = tByKey[sKey]
      if not tDisplayRelation then
        tDisplayRelation = {Relation = tRelation, PlayEnterAnimation = false}
        tByKey[sKey] = tDisplayRelation
        table.insert(tDisplayRelations, tDisplayRelation)
      end
      tDisplayRelation.PlayEnterAnimation = tDisplayRelation.PlayEnterAnimation or nSelectedGroupId ~= 0 and nSelectedGroupId == tonumber(tRelation.GroupID)
    end
  end
  return tDisplayRelations
end

function Goodluck_Home_Item02_UIBP:OnInitialize()
  self.BenefitItems = {}
  local BenefitItemClass = require(BENEFIT_ITEM_LUA_PATH)
  for _, sWidgetName in ipairs(PREPLACED_BENEFIT_WIDGET_NAMES) do
    local uWidget = self.UIRoot[sWidgetName]
    if uWidget then
      local BenefitItem = BenefitItemClass()
      BenefitItem:InitWithParentWidget(self, uWidget)
      table.insert(self.BenefitItems, BenefitItem)
    end
  end
  for _, BenefitItem in ipairs(self.BenefitItems) do
    self:SetWidgetVisible(BenefitItem.UIRoot, false)
  end
end

function Goodluck_Home_Item02_UIBP:RegistEvents()
  self:AddOnClickedEventByControl(self.UIRoot.Button_0, self.OnClickCard, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_1, self.OnClickCard, self)
end

function Goodluck_Home_Item02_UIBP:OnRefresh(tData, _)
  self.data = tData
  local tConfig = tData and tData.Config
  if not tConfig then
    return
  end
  local nTimeState = tData.TimeState or BlackFridayLuckyCardDisplayConfig.GetActivityCardTimeState(tConfig)
  self:RefreshSubscribeRestriction(tConfig)
  local sDisplayName = GetDisplayName(tConfig.NameTextID)
  local bShowBigCardImage = IsConfiguredString(tConfig.BigCardImagePath)
  self.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(nTimeState)
  local uActivePanel = self.UIRoot:GetWidgetFromName("CanvasPanel_9")
  local uUpcomingPanel = self.UIRoot.CanvasPanel_Loading or self.UIRoot:GetWidgetFromName("CanvasPanel_Loading")
  local uExpiredPanel = self.UIRoot:GetWidgetFromName("Border_0")
  self:SetWidgetVisible(uActivePanel, nTimeState == CARD_TIME_STATE.Active)
  uUpcomingPanel:SetVisibility(nTimeState == CARD_TIME_STATE.Upcoming and UEnums.ESlateVisibility.Visible or UEnums.ESlateVisibility.Collapsed)
  uExpiredPanel:SetVisibility(nTimeState == CARD_TIME_STATE.Expired and UEnums.ESlateVisibility.Visible or UEnums.ESlateVisibility.Collapsed)
  self.UIRoot.TextBlock_Loading:SetText(LocUtil.GetLocalizeResStr(UPCOMING_TEXT_ID))
  self.UIRoot.TextBlock_0:SetText(LocUtil.GetLocalizeResStr(EXPIRED_TEXT_ID))
  self.UIRoot.TextBlock_1:SetText(sDisplayName)
  self:SetWidgetVisible(self.UIRoot.Image_5, bShowBigCardImage)
  if bShowBigCardImage then
    self:SetTexture(self.UIRoot.Image_5, tConfig.BigCardImagePath)
  end
  local nTint = nTimeState == CARD_TIME_STATE.Expired and CARD_IMAGE_TINT_EXPIRED or 1
  self.UIRoot.Image_5:SetColorAndOpacity(FLinearColor(nTint, nTint, nTint, 1))
  if nTimeState ~= CARD_TIME_STATE.Active then
    for _, BenefitItem in ipairs(self.BenefitItems or {}) do
      self:SetWidgetVisible(BenefitItem.UIRoot, false)
    end
    return
  end
  self.UIRoot.TextBlock_Date:SetText(FormatDateRange(tConfig.FixedStartTime, tConfig.FixedEndTime))
  self.UIRoot.TextBlock_SpinName:SetText(sDisplayName)
  local nBadgeTextId = tonumber(tConfig.BadgeTextID)
  local bShowBadge = nBadgeTextId ~= nil and 0 < nBadgeTextId
  self:SetWidgetVisible(self.UIRoot.UTRichTextBlock_UC, bShowBadge)
  if bShowBadge then
    self.UIRoot.UTRichTextBlock_UC:SetText(LocUtil.LocalizeResFormat(nBadgeTextId, tConfig.BadgeParam or ""))
  end
  self:SetWidgetVisible(self.UIRoot.Image_111, bShowBigCardImage)
  if bShowBigCardImage then
    self:SetTexture(self.UIRoot.Image_111, tConfig.BigCardImagePath)
  end
  local tRelations = BlackFridayLuckyCardDisplayConfig.GetBenefitRelationsByCard(tConfig.CardID)
  local nSelectedGroupId = tonumber(tData.GroupID) or 0
  local tDisplayRelations = BuildDisplayRelations(tRelations, nSelectedGroupId)
  self:EnsureBenefitItemCount(math.min(#tDisplayRelations, MAX_BENEFIT_COUNT))
  for nIndex, BenefitItem in ipairs(self.BenefitItems or {}) do
    local tDisplayRelation = tDisplayRelations[nIndex]
    local tRelation = tDisplayRelation and tDisplayRelation.Relation
    self:SetWidgetVisible(BenefitItem.UIRoot, tRelation ~= nil)
    if tRelation then
      BenefitItem:Refresh({
        Relation = tRelation,
        PrivilegeTypeID = tonumber(tConfig.PrivilegeTypeID),
        CardID = tonumber(tConfig.CardID),
        PlayEnterAnimation = tDisplayRelation.PlayEnterAnimation,
        TabAnimationToken = tData.TabAnimationToken
      })
    end
  end
  if #tDisplayRelations > #(self.BenefitItems or {}) then
    log_warning(string.format("Goodluck_Home_Item02_UIBP:OnRefresh - insufficient benefit widgets cardId=%s relationCount=%s", tostring(tConfig.CardID), tostring(#tDisplayRelations)))
  end
end

function Goodluck_Home_Item02_UIBP:RefreshSubscribeRestriction(tConfig)
  local uText = self.UIRoot.TextBlock_Dec
  if not uText then
    return
  end
  local bShow = BlackFridayLuckyCardDisplayConfig.IsGlobalSamsungPackage() and BlackFridayLuckyCardDisplayConfig.IsSubscribeCard(tConfig)
  self:SetWidgetVisible(uText, bShow)
  if bShow then
    uText:SetText(LocUtil.GetLocalizeResStr(SAMSUNG_SUBSCRIBE_TEXT_ID))
  end
  log(bWriteLog and string.format("Goodluck_Home_Item02_UIBP:RefreshSubscribeRestriction - cardId=%s show=%s", tostring(tConfig and tConfig.CardID), tostring(bShow)))
end

function Goodluck_Home_Item02_UIBP:EnsureBenefitItemCount(nTargetCount)
  if nTargetCount <= #(self.BenefitItems or {}) then
    return
  end
  local uBenefitContainer = self.UIRoot.VerticalBox_0 or self.UIRoot:GetWidgetFromName("VerticalBox_0")
  if not uBenefitContainer then
    return
  end
  while nTargetCount > #self.BenefitItems do
    local BenefitItem = self:CreateChildWindowWithLuaAndBpPath(uBenefitContainer, nil, BENEFIT_ITEM_LUA_PATH, BENEFIT_ITEM_BP_PATH)
    if not BenefitItem then
      return
    end
    table.insert(self.BenefitItems, BenefitItem)
    self:SetWidgetVisible(BenefitItem.UIRoot, false)
  end
end

function Goodluck_Home_Item02_UIBP:OnClickCard()
  local tConfig = self.data and self.data.Config
  local nTimeState = self.data and self.data.TimeState or BlackFridayLuckyCardDisplayConfig.GetActivityCardTimeState(tConfig)
  if nTimeState ~= CARD_TIME_STATE.Active then
    return
  end
  local sJumpLink = tostring(tConfig and tConfig.JumpLink or "")
  if not IsConfiguredString(sJumpLink) then
    return
  end
  self:PlayAudio(sound_config.click_v1)
  GlobalData.JumpUrl(sJumpLink)
  local LuckyCardModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule)
  local gem_report_utils = require("client.logic.store.gem_report_utils")
  LuckyCardModule:ReportTLog(gem_report_utils.SubEvent_CyberCard010, {
    cardID = tConfig.CardID
  })
end

local class = require("class")
local scroll_box_child_base = require("client.slua_ui_framework.component.scroll_box_child_base")
return class(scroll_box_child_base, nil, Goodluck_Home_Item02_UIBP)
