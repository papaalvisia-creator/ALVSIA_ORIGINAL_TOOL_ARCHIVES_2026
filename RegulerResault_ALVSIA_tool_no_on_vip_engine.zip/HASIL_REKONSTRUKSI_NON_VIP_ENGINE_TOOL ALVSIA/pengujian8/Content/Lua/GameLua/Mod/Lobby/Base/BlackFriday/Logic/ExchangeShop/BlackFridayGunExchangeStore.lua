local BlackFridayExchangeBaseStore = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.ExchangeShop.BlackFridayExchangeBaseStore")
local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
local GLOBAL_ACTIVITY_ID = 147007480
local BlackFridayGunExchangeStore = {
  ActivityId = PublishRegionMacros.IsBlueholeOperationRegion() and 647007480 or PublishRegionMacros.IsJapanOrKorea() and 247007480 or GLOBAL_ACTIVITY_ID,
  PurchaseLimit = 3,
  Implemented = true,
  ItemState = {
    Available = "available",
    NotEnough = "not_enough",
    Possessed = "possessed",
    SoldOut = "sold_out",
    PurchaseLimitReached = "purchase_limit_reached",
    Discount = "discount"
  }
}
BlackFridayGunExchangeStore.__index = BlackFridayGunExchangeStore
setmetatable(BlackFridayGunExchangeStore, {__index = BlackFridayExchangeBaseStore})

local function ToNumber(value, defaultValue)
  local numberValue = tonumber(value)
  if numberValue == nil then
    return defaultValue or 0
  end
  return numberValue
end

local function CloneTable(source)
  local result = {}
  if type(source) ~= "table" then
    return result
  end
  for key, value in pairs(source) do
    result[key] = value
  end
  return result
end

function BlackFridayGunExchangeStore.New(owner)
  return BlackFridayExchangeBaseStore.Create(BlackFridayGunExchangeStore, owner, BlackFridayGunExchangeStore.ActivityId, "gun")
end

function BlackFridayGunExchangeStore:Open()
  return self:Request()
end

function BlackFridayGunExchangeStore:IsWeaponSkinItem(itemId)
  itemId = tonumber(itemId)
  if not itemId then
    return false
  end
  return CDataTable.GetTableData("WeaponSkinMapping", itemId) ~= nil
end

function BlackFridayGunExchangeStore:GetDisplayConfig(itemId)
  local success, config = pcall(CDataTable.GetTableData, "BlackFridayGunExchangeDisplayCfg", tonumber(itemId))
  if not success or not config then
    return nil
  end
  local activityId = ToNumber(config.ActivityID)
  if 0 < activityId and activityId ~= self.ActivityId and activityId ~= GLOBAL_ACTIVITY_ID then
    return nil
  end
  return config
end

function BlackFridayGunExchangeStore:GetItemState(itemData, currencyCount, purchaseLimitReached)
  if itemData.possessed then
    return self.ItemState.Possessed
  end
  if itemData.row_sold_out then
    return self.ItemState.SoldOut
  end
  if purchaseLimitReached then
    return self.ItemState.PurchaseLimitReached
  end
  if ToNumber(itemData.original_price) > ToNumber(itemData.needItemNum) then
    return self.ItemState.Discount
  end
  if currencyCount < ToNumber(itemData.needItemNum) then
    return self.ItemState.NotEnough
  end
  return self.ItemState.Available
end

function BlackFridayGunExchangeStore:GetData()
  local rawItems = self:GetRawItems()
  local currencyId = self:GetCurrencyId(rawItems)
  local currencyCountById = self:GetCurrencyCountById(rawItems)
  local currencyCount = currencyCountById[currencyId] or 0
  local items = {}
  local purchaseCount = 0
  for _, sourceItem in ipairs(rawItems) do
    local itemData = CloneTable(sourceItem)
    itemData.is_weapon_skin = self:IsWeaponSkinItem(itemData.itemId)
    itemData.hasExchangeCount = ToNumber(itemData.hasExchangeCount)
    itemData.timeLimits = ToNumber(itemData.timeLimits)
    itemData.needItemNum = ToNumber(itemData.needItemNum)
    itemData.itemNum = ToNumber(itemData.itemNum, 1)
    itemData.row_sold_out = 0 < itemData.timeLimits and itemData.hasExchangeCount >= itemData.timeLimits
    local displayConfig = self:GetDisplayConfig(itemData.itemId)
    itemData.poster_path = displayConfig and tostring(displayConfig.PosterPath or "") or ""
    if itemData.is_weapon_skin then
      purchaseCount = purchaseCount + itemData.hasExchangeCount
    end
    table.insert(items, itemData)
  end
  local StoreUtils = require("client.slua.logic.store.utils.store_utils")
  local purchaseLimitReached = purchaseCount >= self.PurchaseLimit
  for _, itemData in ipairs(items) do
    local itemCurrencyCount = currencyCountById[ToNumber(itemData.needItemId)] or 0
    itemData.possessed = itemData.is_weapon_skin and StoreUtils.IsPossessed(itemData.itemId) == true
    itemData.enough_currency = itemCurrencyCount >= itemData.needItemNum
    itemData.purchase_limit_reached = itemData.is_weapon_skin and purchaseLimitReached
    itemData.display_state = self:GetItemState(itemData, itemCurrencyCount, itemData.purchase_limit_reached)
    itemData.can_open_confirm = not itemData.possessed and not itemData.row_sold_out and not itemData.purchase_limit_reached
  end
  return {
    activity_id = self.ActivityId,
    implemented = self.Implemented,
    load_state = self:GetLoadState(),
    currency_id = currencyId,
    currency_count = currencyCount,
    purchase_count = purchaseCount,
    purchase_limit = self.PurchaseLimit,
    purchase_limit_reached = purchaseLimitReached,
    items = items
  }
end

return BlackFridayGunExchangeStore
