.version	5.3

.format	0
.int_size	4
.size_t_size	4
.instruction_size	4
.integer_format	8
.float_format	8
.endianness	LITTLE

.function	main

.source	null
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	1
.maxstacksize	57

.upvalue	"_ENV"	0	true

.constant	k0	61
.constant	k1	12
.constant	k2	250
.constant	k3	52
.constant	k4	251
.constant	k5	245
.constant	k6	71
.constant	k7	138
.constant	k8	60
.constant	k9	177
.constant	k10	148
.constant	k11	91
.constant	k12	73
.constant	k13	195
.constant	k14	18
.constant	k15	78
.constant	k16	"require"
.constant	k17	"table"
.constant	k18	"concat"
.constant	k19	125
.constant	k20	75
.constant	k21	210
.constant	k22	53
.constant	k23	34
.constant	k24	231
.constant	k25	68
.constant	k26	142
.constant	k27	192
.constant	k28	205
.constant	k29	41
.constant	k30	126
.constant	k31	54
.constant	k32	201
.constant	k33	244
.constant	k34	179
.constant	k35	141
.constant	k36	1
.constant	k37	2
.constant	k38	216
.constant	k39	30
.constant	k40	188
.constant	k41	200
.constant	k42	215
.constant	k43	123
.constant	k44	77
.constant	k45	40
.constant	k46	223
.constant	k47	227
.constant	k48	168
.constant	k49	36
.constant	k50	170
.constant	k51	29
.constant	k52	255
.constant	k53	89
.constant	k54	162
.constant	k55	37
.constant	k56	211
.constant	k57	63
.constant	k58	25
.constant	k59	51
.constant	k60	217
.constant	k61	39
.constant	k62	198
.constant	k63	199
.constant	k64	88
.constant	k65	103
.constant	k66	16
.constant	k67	233
.constant	k68	149
.constant	k69	94
.constant	k70	237
.constant	k71	19
.constant	k72	147
.constant	k73	186
.constant	k74	14
.constant	k75	236
.constant	k76	11
.constant	k77	174
.constant	k78	20
.constant	k79	"View"
.constant	k80	"Delete"
.constant	k81	"HorizonList"
.constant	k82	"VerticalList"
.constant	k83	"BigImage"
.constant	k84	3
.constant	k85	"FitLobby"
.constant	k86	4
.constant	k87	70
.constant	k88	214
.constant	k89	22
.constant	k90	35
.constant	k91	175
.constant	k92	218
.constant	k93	204
.constant	k94	169
.constant	k95	171
.constant	k96	15
.constant	k97	9
.constant	k98	154
.constant	k99	178
.constant	k100	219
.constant	k101	151
.constant	k102	87
.constant	k103	47
.constant	k104	221
.constant	k105	85
.constant	k106	31
.constant	k107	246
.constant	k108	146
.constant	k109	5
.constant	k110	254
.constant	k111	17
.constant	k112	131
.constant	k113	56
.constant	k114	101
.constant	k115	222
.constant	k116	62
.constant	k117	48
.constant	k118	24
.constant	k119	117
.constant	k120	234
.constant	k121	191
.constant	k122	133
.constant	k123	21
.constant	k124	74
.constant	k125	95
.constant	k126	8
.constant	k127	182
.constant	k128	193
.constant	k129	107
.constant	k130	46
.constant	k131	229
.constant	k132	102
.constant	k133	176
.constant	k134	185
.constant	k135	93
.constant	k136	209
.constant	k137	23
.constant	k138	226
.constant	k139	172
.constant	k140	7
.constant	k141	241
.constant	k142	81
.constant	k143	197
.constant	k144	240
.constant	k145	163
.constant	k146	225
.constant	k147	228
.constant	k148	145
.constant	k149	116
.constant	k150	167
.constant	k151	112
.constant	k152	59
.constant	k153	181
.constant	k154	120
.constant	k155	143
.constant	k156	38
.constant	k157	57
.constant	k158	212
.constant	k159	86
.constant	k160	69
.constant	k161	50
.constant	k162	180
.constant	k163	104
.constant	k164	83
.constant	k165	206
.constant	k166	110
.constant	k167	239
.constant	k168	183
.constant	k169	105
.constant	k170	6
.constant	k171	118
.constant	k172	"ENUM_DownloadState"
.constant	k173	"ENUM_DownloadType"
.constant	k174	"RecommendBundleIDs"
.constant	k175	"pairs"
.constant	k176	true
.constant	k177	"EODPackID"
.constant	k178	"UserCurEquipment"
.constant	k179	"UserWardrobe"
.constant	k180	"FIT_COMMERCIAL_CORE_DEP"
.constant	k181	"ODPAK"
.constant	k182	"ODPACK"
.constant	k183	"UGCPACK"
.constant	k184	0.25
.constant	k185	121
.constant	k186	173
.constant	k187	202
.constant	k188	0
.constant	k189	108
.constant	k190	109
.constant	k191	67
.constant	k192	55
.constant	k193	213
.constant	k194	111
.constant	k195	43
.constant	k196	189
.constant	k197	129
.constant	k198	208
.constant	k199	115
.constant	k200	166
.constant	k201	98
.constant	k202	64
.constant	k203	42
.constant	k204	194
.constant	k205	249
.constant	k206	164
.constant	k207	"ctor"
.constant	k208	"OnInitialize"
.constant	k209	"RegistEvents"
.constant	k210	"OnPostInitialize"
.constant	k211	"OnClose"
.constant	k212	"OnShow"
.constant	k213	"OnVerticalTextTabClickedCallback"
.constant	k214	"OnVerticalTextTabSelectedCallback"
.constant	k215	"OnVerticalTextTabRefreshCallback"
.constant	k216	"OnHorizontalTabNumCallback"
.constant	k217	"OnVerticalTabNumCallback"
.constant	k218	"OnClickButton_Setting"
.constant	k219	"OnClickButton_Delete"
.constant	k220	"OnClickButton_Close"
.constant	k221	"HandleClose"
.constant	k222	"OnClickItemButton_Downlaod"
.constant	k223	"OnClickedLevelOneTab"
.constant	k224	"OnClickShowDownloadSetting"
.constant	k225	"OnClickBackToView"
.constant	k226	"OnClickRecommendReward"
.constant	k227	"OnAutoDownloadCheckChanged"
.constant	k228	"UpdateAutoDownloadIcon"
.constant	k229	"OnClickToggleDownload"
.constant	k230	"OnClickShowCalcTip"
.constant	k231	"ToggleDownloadBundle"
.constant	k232	"ToggleDownload"
.constant	k233	"ToggleDownloadItemData"
.constant	k234	"GetShowTabKeyList"
.constant	k235	"GetItemData"
.constant	k236	"OnClickButton_Download"
.constant	k237	"OnClickButton_DownloadAll"
.constant	k238	"OnIconAutoHelpButtonClick"
.constant	k239	"OnIconAutoSetButtonClick"
.constant	k240	"_ToggleDownloadAll"
.constant	k241	"OnClickUGCAssetHub"
.constant	k242	"OnClickUGCMall"
.constant	k243	"OnClickUGCAssetHubCacheHelp"
.constant	k244	"GetPufferDeleteManager"
.constant	k245	"GetCommonDownloadHandler"
.constant	k246	"UpdateUI"
.constant	k247	"UpdateFitVersionUI"
.constant	k248	"UpdateDownloadAllButtonText"
.constant	k249	"UpdateAutoDownload"
.constant	k250	"CheckShowGuideTips"
.constant	k251	"UpdateDownloadSelectedMap"
.constant	k252	"UpdateAllDownloadSize"
.constant	k253	"GetAllOptionalDeleteSize"
.constant	k254	"UpdateGameSize"
.constant	k255	"UpdateRecommendInfo"
.constant	k256	"UpdateReverseDownloadInfo"
.constant	k257	"OnAndroidBack"
.constant	k258	"InitTabData"
.constant	k259	"RES_AUDIO_HIGH"
.constant	k260	1
.constant	k261	"RES_AUDIO_NORMAL"
.constant	k262	"RES_AUDIO_LOW"
.constant	k263	"res_baltichd"
.constant	k264	2
.constant	k265	"res_commtexmd"
.constant	k266	"SelectTopTab"
.constant	k267	"IsRecommendPage"
.constant	k268	"IsFitLobbyResPage"
.constant	k269	"IsRecommendTabData"
.constant	k270	"UpdateTabContent"
.constant	k271	"UpdateTabExtraContent"
.constant	k272	"OnCleanup"
.constant	k273	"UpdateBigImage"
.constant	k274	"UpdateFitLobby"
.constant	k275	"UpdateDownloadSpeed"
.constant	k276	"UpdateNetworkInfo"
.constant	k277	"UpdateCurTabDownloadInfo"
.constant	k278	"UpdateRecommendType"
.constant	k279	"UpdateUIType"
.constant	k280	"ShowDownload_Loading_Item_UIBP"
.constant	k281	"IsViewMode"
.constant	k282	"BlockEntrances"
.constant	k283	"require"
.constant	k284	89
.constant	k285	70
.constant	k286	222
.constant	k287	35
.constant	k288	11
.constant	k289	214
.constant	k290	22
.constant	k291	168
.constant	k292	25
.constant	k293	175
.constant	k294	218
.constant	k295	200
.constant	k296	88
.constant	k297	71
.constant	k298	48
.constant	k299	244
.constant	k300	240
.constant	k301	184
.constant	k302	123
.constant	k303	162
.constant	k304	5
.constant	k305	255
.constant	k306	8
.constant	k307	132
.constant	k308	49
.constant	k309	253
.constant	k310	221
.constant	k311	216
.constant	k312	100

.line	0	newtable      r0    16     0
.line	0	loadk         r1    k0 ; k0 = 61
.line	0	loadk         r2    k1 ; k1 = 12
.line	0	loadk         r3    k2 ; k2 = 250
.line	0	loadk         r4    k3 ; k3 = 52
.line	0	loadk         r5    k4 ; k4 = 251
.line	0	loadk         r6    k5 ; k5 = 245
.line	0	loadk         r7    k6 ; k6 = 71
.line	0	loadk         r8    k7 ; k7 = 138
.line	0	loadk         r9    k8 ; k8 = 60
.line	0	loadk        r10    k9 ; k9 = 177
.line	0	loadk        r11   k10 ; k10 = 148
.line	0	loadk        r12   k11 ; k11 = 91
.line	0	loadk        r13   k12 ; k12 = 73
.line	0	loadk        r14   k13 ; k13 = 195
.line	0	loadk        r15   k14 ; k14 = 18
.line	0	loadk        r16   k15 ; k15 = 78
.line	0	setlist       r0    16     1
.line	0	closure       r1    f0
.line	0	gettabup      r2    u0   k16 ; k16 = "require"
.line	0	gettabup      r3    u0   k17 ; k17 = "table"
.line	0	gettable      r3    r3   k18 ; k18 = "concat"
.line	0	newtable      r4     1     0
.line	0	move          r5    r1
.line	0	loadk         r6   k19 ; k19 = 125
.line	0	loadk         r7   k20 ; k20 = 75
.line	0	loadk         r8   k21 ; k21 = 210
.line	0	loadk         r9   k22 ; k22 = 53
.line	0	loadk        r10    k3 ; k3 = 52
.line	0	loadk        r11   k23 ; k23 = 34
.line	0	loadk        r12   k24 ; k24 = 231
.line	0	loadk        r13   k25 ; k25 = 68
.line	0	loadk        r14   k26 ; k26 = 142
.line	0	loadk        r15   k27 ; k27 = 192
.line	0	loadk        r16   k28 ; k28 = 205
.line	0	loadk        r17   k29 ; k29 = 41
.line	0	loadk        r18   k30 ; k30 = 126
.line	0	loadk        r19   k31 ; k31 = 54
.line	0	loadk        r20   k32 ; k32 = 201
.line	0	loadk        r21   k33 ; k33 = 244
.line	0	loadk        r22   k34 ; k34 = 179
.line	0	loadk        r23    k3 ; k3 = 52
.line	0	loadk        r24   k35 ; k35 = 141
.line	0	loadk        r25   k36 ; k36 = 1
.line	0	loadk        r26    k4 ; k4 = 251
.line	0	loadk        r27   k37 ; k37 = 2
.line	0	loadk        r28   k38 ; k38 = 216
.line	0	loadk        r29   k39 ; k39 = 30
.line	0	loadk        r30   k40 ; k40 = 188
.line	0	loadk        r31   k41 ; k41 = 200
.line	0	loadk        r32   k42 ; k42 = 215
.line	0	loadk        r33   k43 ; k43 = 123
.line	0	loadk        r34   k44 ; k44 = 77
.line	0	loadk        r35   k45 ; k45 = 40
.line	0	loadk        r36   k46 ; k46 = 223
.line	0	loadk        r37   k47 ; k47 = 227
.line	0	loadk        r38   k48 ; k48 = 168
.line	0	loadk        r39   k49 ; k49 = 36
.line	0	loadk        r40   k50 ; k50 = 170
.line	0	loadk        r41   k51 ; k51 = 29
.line	0	loadk        r42   k52 ; k52 = 255
.line	0	loadk        r43   k53 ; k53 = 89
.line	0	loadk        r44   k54 ; k54 = 162
.line	0	loadk        r45   k55 ; k55 = 37
.line	0	call          r5    41     2
.line	0	move          r6    r1
.line	0	loadk         r7   k44 ; k44 = 77
.line	0	loadk         r8   k25 ; k25 = 68
.line	0	loadk         r9   k56 ; k56 = 211
.line	0	loadk        r10   k57 ; k57 = 63
.line	0	loadk        r11   k58 ; k58 = 25
.line	0	loadk        r12   k59 ; k59 = 51
.line	0	loadk        r13   k60 ; k60 = 217
.line	0	loadk        r14   k61 ; k61 = 39
.line	0	loadk        r15   k54 ; k54 = 162
.line	0	loadk        r16   k62 ; k62 = 198
.line	0	loadk        r17   k63 ; k63 = 199
.line	0	loadk        r18   k64 ; k64 = 88
.line	0	loadk        r19   k65 ; k65 = 103
.line	0	loadk        r20   k66 ; k66 = 16
.line	0	loadk        r21   k67 ; k67 = 233
.line	0	loadk        r22   k62 ; k62 = 198
.line	0	loadk        r23   k68 ; k68 = 149
.line	0	loadk        r24   k69 ; k69 = 94
.line	0	loadk        r25   k50 ; k50 = 170
.line	0	loadk        r26    k1 ; k1 = 12
.line	0	loadk        r27   k70 ; k70 = 237
.line	0	loadk        r28   k71 ; k71 = 19
.line	0	loadk        r29   k72 ; k72 = 147
.line	0	call          r6    24     0
.line	0	setlist       r4     0     1
.line	0	call          r3     2     2
.line	0	call          r2     2     1
.line	0	gettabup      r2    u0   k16 ; k16 = "require"
.line	0	gettabup      r3    u0   k17 ; k17 = "table"
.line	0	gettable      r3    r3   k18 ; k18 = "concat"
.line	0	newtable      r4     1     0
.line	0	move          r5    r1
.line	0	loadk         r6   k19 ; k19 = 125
.line	0	loadk         r7   k20 ; k20 = 75
.line	0	loadk         r8   k21 ; k21 = 210
.line	0	loadk         r9   k22 ; k22 = 53
.line	0	loadk        r10    k3 ; k3 = 52
.line	0	loadk        r11   k23 ; k23 = 34
.line	0	loadk        r12   k24 ; k24 = 231
.line	0	loadk        r13   k25 ; k25 = 68
.line	0	loadk        r14   k26 ; k26 = 142
.line	0	loadk        r15   k27 ; k27 = 192
.line	0	loadk        r16   k28 ; k28 = 205
.line	0	loadk        r17   k29 ; k29 = 41
.line	0	loadk        r18   k30 ; k30 = 126
.line	0	loadk        r19   k31 ; k31 = 54
.line	0	loadk        r20   k32 ; k32 = 201
.line	0	loadk        r21   k33 ; k33 = 244
.line	0	loadk        r22   k34 ; k34 = 179
.line	0	loadk        r23    k3 ; k3 = 52
.line	0	loadk        r24   k35 ; k35 = 141
.line	0	loadk        r25   k36 ; k36 = 1
.line	0	loadk        r26    k4 ; k4 = 251
.line	0	loadk        r27   k37 ; k37 = 2
.line	0	loadk        r28   k38 ; k38 = 216
.line	0	loadk        r29   k39 ; k39 = 30
.line	0	loadk        r30   k40 ; k40 = 188
.line	0	loadk        r31   k41 ; k41 = 200
.line	0	loadk        r32   k42 ; k42 = 215
.line	0	loadk        r33   k43 ; k43 = 123
.line	0	loadk        r34   k44 ; k44 = 77
.line	0	loadk        r35   k45 ; k45 = 40
.line	0	loadk        r36   k46 ; k46 = 223
.line	0	loadk        r37   k47 ; k47 = 227
.line	0	loadk        r38   k48 ; k48 = 168
.line	0	loadk        r39   k49 ; k49 = 36
.line	0	loadk        r40   k50 ; k50 = 170
.line	0	loadk        r41   k51 ; k51 = 29
.line	0	loadk        r42   k52 ; k52 = 255
.line	0	loadk        r43   k53 ; k53 = 89
.line	0	loadk        r44   k54 ; k54 = 162
.line	0	loadk        r45   k55 ; k55 = 37
.line	0	call          r5    41     2
.line	0	move          r6    r1
.line	0	loadk         r7   k44 ; k44 = 77
.line	0	loadk         r8   k25 ; k25 = 68
.line	0	loadk         r9   k56 ; k56 = 211
.line	0	loadk        r10   k57 ; k57 = 63
.line	0	loadk        r11   k58 ; k58 = 25
.line	0	loadk        r12   k59 ; k59 = 51
.line	0	loadk        r13   k60 ; k60 = 217
.line	0	loadk        r14   k61 ; k61 = 39
.line	0	loadk        r15   k54 ; k54 = 162
.line	0	loadk        r16   k62 ; k62 = 198
.line	0	loadk        r17   k63 ; k63 = 199
.line	0	loadk        r18   k64 ; k64 = 88
.line	0	loadk        r19   k65 ; k65 = 103
.line	0	loadk        r20   k66 ; k66 = 16
.line	0	loadk        r21   k67 ; k67 = 233
.line	0	loadk        r22   k62 ; k62 = 198
.line	0	loadk        r23   k68 ; k68 = 149
.line	0	loadk        r24   k64 ; k64 = 88
.line	0	loadk        r25   k73 ; k73 = 186
.line	0	loadk        r26   k74 ; k74 = 14
.line	0	loadk        r27   k75 ; k75 = 236
.line	0	loadk        r28   k76 ; k76 = 11
.line	0	loadk        r29   k72 ; k72 = 147
.line	0	call          r6    24     0
.line	0	setlist       r4     0     1
.line	0	call          r3     2     2
.line	0	call          r2     2     1
.line	0	gettabup      r2    u0   k16 ; k16 = "require"
.line	0	gettabup      r3    u0   k17 ; k17 = "table"
.line	0	gettable      r3    r3   k18 ; k18 = "concat"
.line	0	newtable      r4     1     0
.line	0	move          r5    r1
.line	0	loadk         r6   k19 ; k19 = 125
.line	0	loadk         r7   k20 ; k20 = 75
.line	0	loadk         r8   k21 ; k21 = 210
.line	0	loadk         r9   k22 ; k22 = 53
.line	0	loadk        r10    k3 ; k3 = 52
.line	0	loadk        r11   k23 ; k23 = 34
.line	0	loadk        r12   k24 ; k24 = 231
.line	0	loadk        r13   k25 ; k25 = 68
.line	0	loadk        r14   k26 ; k26 = 142
.line	0	loadk        r15   k27 ; k27 = 192
.line	0	loadk        r16   k28 ; k28 = 205
.line	0	loadk        r17   k29 ; k29 = 41
.line	0	loadk        r18   k30 ; k30 = 126
.line	0	loadk        r19   k31 ; k31 = 54
.line	0	loadk        r20   k32 ; k32 = 201
.line	0	loadk        r21   k33 ; k33 = 244
.line	0	loadk        r22   k34 ; k34 = 179
.line	0	loadk        r23    k3 ; k3 = 52
.line	0	loadk        r24   k35 ; k35 = 141
.line	0	loadk        r25   k36 ; k36 = 1
.line	0	loadk        r26    k4 ; k4 = 251
.line	0	loadk        r27   k37 ; k37 = 2
.line	0	loadk        r28   k38 ; k38 = 216
.line	0	loadk        r29   k39 ; k39 = 30
.line	0	loadk        r30   k40 ; k40 = 188
.line	0	loadk        r31   k41 ; k41 = 200
.line	0	loadk        r32   k42 ; k42 = 215
.line	0	loadk        r33   k43 ; k43 = 123
.line	0	loadk        r34   k44 ; k44 = 77
.line	0	loadk        r35   k45 ; k45 = 40
.line	0	loadk        r36   k46 ; k46 = 223
.line	0	loadk        r37   k47 ; k47 = 227
.line	0	loadk        r38   k48 ; k48 = 168
.line	0	loadk        r39   k49 ; k49 = 36
.line	0	loadk        r40   k50 ; k50 = 170
.line	0	loadk        r41   k51 ; k51 = 29
.line	0	loadk        r42   k52 ; k52 = 255
.line	0	loadk        r43   k53 ; k53 = 89
.line	0	loadk        r44   k54 ; k54 = 162
.line	0	loadk        r45   k55 ; k55 = 37
.line	0	call          r5    41     2
.line	0	move          r6    r1
.line	0	loadk         r7   k44 ; k44 = 77
.line	0	loadk         r8   k25 ; k25 = 68
.line	0	loadk         r9   k56 ; k56 = 211
.line	0	loadk        r10   k57 ; k57 = 63
.line	0	loadk        r11   k58 ; k58 = 25
.line	0	loadk        r12   k59 ; k59 = 51
.line	0	loadk        r13   k60 ; k60 = 217
.line	0	loadk        r14   k61 ; k61 = 39
.line	0	loadk        r15   k54 ; k54 = 162
.line	0	loadk        r16   k62 ; k62 = 198
.line	0	loadk        r17   k63 ; k63 = 199
.line	0	loadk        r18   k64 ; k64 = 88
.line	0	loadk        r19   k65 ; k65 = 103
.line	0	loadk        r20   k66 ; k66 = 16
.line	0	loadk        r21   k67 ; k67 = 233
.line	0	loadk        r22   k62 ; k62 = 198
.line	0	loadk        r23   k68 ; k68 = 149
.line	0	loadk        r24   k69 ; k69 = 94
.line	0	loadk        r25   k77 ; k77 = 174
.line	0	loadk        r26   k78 ; k78 = 20
.line	0	loadk        r27   k67 ; k67 = 233
.line	0	call          r6    22     0
.line	0	setlist       r4     0     1
.line	0	call          r3     2     2
.line	0	call          r2     2     2
.line	0	newtable      r3     0     2
.line	0	settable      r3   k79   k36 ; k36 = 1
.line	0	settable      r3   k80   k37 ; k37 = 2
.line	0	newtable      r4     0     4
.line	0	settable      r4   k81   k36 ; k36 = 1
.line	0	settable      r4   k82   k37 ; k37 = 2
.line	0	settable      r4   k83   k84 ; k84 = 3
.line	0	settable      r4   k85   k86 ; k86 = 4
.line	0	gettabup      r5    u0   k16 ; k16 = "require"
.line	0	move          r6    r1
.line	0	loadk         r7   k53 ; k53 = 89
.line	0	loadk         r8   k87 ; k87 = 70
.line	0	loadk         r9   k88 ; k88 = 214
.line	0	loadk        r10   k22 ; k22 = 53
.line	0	loadk        r11   k89 ; k89 = 22
.line	0	loadk        r12   k90 ; k90 = 35
.line	0	loadk        r13   k48 ; k48 = 168
.line	0	loadk        r14   k58 ; k58 = 25
.line	0	loadk        r15   k91 ; k91 = 175
.line	0	loadk        r16   k92 ; k92 = 218
.line	0	loadk        r17   k41 ; k41 = 200
.line	0	loadk        r18   k29 ; k29 = 41
.line	0	loadk        r19   k69 ; k69 = 94
.line	0	loadk        r20   k31 ; k31 = 54
.line	0	loadk        r21   k93 ; k93 = 204
.line	0	loadk        r22   k52 ; k52 = 255
.line	0	loadk        r23   k94 ; k94 = 169
.line	0	loadk        r24    k3 ; k3 = 52
.line	0	loadk        r25   k95 ; k95 = 171
.line	0	loadk        r26   k96 ; k96 = 15
.line	0	loadk        r27   k52 ; k52 = 255
.line	0	loadk        r28   k97 ; k97 = 9
.line	0	loadk        r29   k98 ; k98 = 154
.line	0	loadk        r30   k22 ; k22 = 53
.line	0	loadk        r31   k99 ; k99 = 178
.line	0	loadk        r32  k100 ; k100 = 219
.line	0	loadk        r33  k101 ; k101 = 151
.line	0	loadk        r34   k65 ; k65 = 103
.line	0	loadk        r35  k102 ; k102 = 87
.line	0	loadk        r36  k103 ; k103 = 47
.line	0	loadk        r37  k104 ; k104 = 221
.line	0	loadk        r38   k47 ; k47 = 227
.line	0	loadk        r39   k48 ; k48 = 168
.line	0	loadk        r40  k105 ; k105 = 85
.line	0	loadk        r41   k40 ; k40 = 188
.line	0	loadk        r42  k106 ; k106 = 31
.line	0	loadk        r43  k107 ; k107 = 246
.line	0	loadk        r44   k86 ; k86 = 4
.line	0	loadk        r45  k108 ; k108 = 146
.line	0	call          r6    40     2
.line	0	call          r5     2     2
.line	0	gettabup      r6    u0   k16 ; k16 = "require"
.line	0	gettabup      r7    u0   k17 ; k17 = "table"
.line	0	gettable      r7    r7   k18 ; k18 = "concat"
.line	0	newtable      r8     1     0
.line	0	move          r9    r1
.line	0	loadk        r10   k53 ; k53 = 89
.line	0	loadk        r11   k87 ; k87 = 70
.line	0	loadk        r12   k88 ; k88 = 214
.line	0	loadk        r13   k22 ; k22 = 53
.line	0	loadk        r14   k89 ; k89 = 22
.line	0	loadk        r15   k90 ; k90 = 35
.line	0	loadk        r16   k48 ; k48 = 168
.line	0	loadk        r17   k58 ; k58 = 25
.line	0	loadk        r18   k91 ; k91 = 175
.line	0	loadk        r19   k92 ; k92 = 218
.line	0	loadk        r20   k41 ; k41 = 200
.line	0	loadk        r21   k29 ; k29 = 41
.line	0	loadk        r22   k69 ; k69 = 94
.line	0	loadk        r23   k31 ; k31 = 54
.line	0	loadk        r24   k93 ; k93 = 204
.line	0	loadk        r25   k52 ; k52 = 255
.line	0	loadk        r26   k94 ; k94 = 169
.line	0	loadk        r27    k3 ; k3 = 52
.line	0	loadk        r28   k95 ; k95 = 171
.line	0	loadk        r29   k96 ; k96 = 15
.line	0	loadk        r30   k52 ; k52 = 255
.line	0	loadk        r31   k97 ; k97 = 9
.line	0	loadk        r32   k98 ; k98 = 154
.line	0	loadk        r33   k22 ; k22 = 53
.line	0	loadk        r34   k99 ; k99 = 178
.line	0	loadk        r35  k100 ; k100 = 219
.line	0	loadk        r36  k101 ; k101 = 151
.line	0	loadk        r37   k65 ; k65 = 103
.line	0	loadk        r38  k102 ; k102 = 87
.line	0	loadk        r39  k103 ; k103 = 47
.line	0	loadk        r40  k104 ; k104 = 221
.line	0	loadk        r41   k47 ; k47 = 227
.line	0	loadk        r42   k48 ; k48 = 168
.line	0	loadk        r43   k49 ; k49 = 36
.line	0	loadk        r44   k91 ; k91 = 175
.line	0	loadk        r45  k109 ; k109 = 5
.line	0	loadk        r46  k110 ; k110 = 254
.line	0	loadk        r47  k111 ; k111 = 17
.line	0	loadk        r48  k112 ; k112 = 131
.line	0	loadk        r49  k113 ; k113 = 56
.line	0	call          r9    41     2
.line	0	move         r10    r1
.line	0	loadk        r11  k114 ; k114 = 101
.line	0	loadk        r12    k6 ; k6 = 71
.line	0	loadk        r13  k115 ; k115 = 222
.line	0	loadk        r14  k116 ; k116 = 62
.line	0	loadk        r15   k58 ; k58 = 25
.line	0	loadk        r16  k117 ; k117 = 48
.line	0	loadk        r17   k47 ; k47 = 227
.line	0	loadk        r18  k118 ; k118 = 24
.line	0	call         r10     9     0
.line	0	setlist       r8     0     1
.line	0	call          r7     2     2
.line	0	call          r6     2     2
.line	0	gettabup      r7    u0   k16 ; k16 = "require"
.line	0	gettabup      r8    u0   k17 ; k17 = "table"
.line	0	gettable      r8    r8   k18 ; k18 = "concat"
.line	0	newtable      r9     1     0
.line	0	move         r10    r1
.line	0	loadk        r11   k53 ; k53 = 89
.line	0	loadk        r12   k87 ; k87 = 70
.line	0	loadk        r13   k88 ; k88 = 214
.line	0	loadk        r14   k22 ; k22 = 53
.line	0	loadk        r15   k89 ; k89 = 22
.line	0	loadk        r16   k90 ; k90 = 35
.line	0	loadk        r17   k48 ; k48 = 168
.line	0	loadk        r18   k58 ; k58 = 25
.line	0	loadk        r19   k91 ; k91 = 175
.line	0	loadk        r20   k92 ; k92 = 218
.line	0	loadk        r21   k41 ; k41 = 200
.line	0	loadk        r22   k29 ; k29 = 41
.line	0	loadk        r23   k69 ; k69 = 94
.line	0	loadk        r24   k31 ; k31 = 54
.line	0	loadk        r25   k93 ; k93 = 204
.line	0	loadk        r26   k52 ; k52 = 255
.line	0	loadk        r27   k94 ; k94 = 169
.line	0	loadk        r28    k3 ; k3 = 52
.line	0	loadk        r29   k95 ; k95 = 171
.line	0	loadk        r30   k96 ; k96 = 15
.line	0	loadk        r31   k52 ; k52 = 255
.line	0	loadk        r32   k97 ; k97 = 9
.line	0	loadk        r33   k98 ; k98 = 154
.line	0	loadk        r34   k22 ; k22 = 53
.line	0	loadk        r35   k99 ; k99 = 178
.line	0	loadk        r36  k100 ; k100 = 219
.line	0	loadk        r37  k101 ; k101 = 151
.line	0	loadk        r38  k119 ; k119 = 117
.line	0	loadk        r39  k102 ; k102 = 87
.line	0	loadk        r40   k61 ; k61 = 39
.line	0	loadk        r41   k46 ; k46 = 223
.line	0	loadk        r42  k120 ; k120 = 234
.line	0	loadk        r43  k121 ; k121 = 191
.line	0	loadk        r44   k49 ; k49 = 36
.line	0	loadk        r45   k34 ; k34 = 179
.line	0	loadk        r46  k106 ; k106 = 31
.line	0	loadk        r47   k52 ; k52 = 255
.line	0	loadk        r48   k39 ; k39 = 30
.line	0	loadk        r49  k122 ; k122 = 133
.line	0	loadk        r50  k123 ; k123 = 21
.line	0	call         r10    41     2
.line	0	move         r11    r1
.line	0	loadk        r12  k124 ; k124 = 74
.line	0	loadk        r13  k125 ; k125 = 95
.line	0	loadk        r14   k60 ; k60 = 217
.line	0	loadk        r15   k31 ; k31 = 54
.line	0	loadk        r16   k51 ; k51 = 29
.line	0	loadk        r17   k55 ; k55 = 37
.line	0	loadk        r18   k60 ; k60 = 217
.line	0	loadk        r19  k126 ; k126 = 8
.line	0	loadk        r20  k127 ; k127 = 182
.line	0	loadk        r21  k128 ; k128 = 193
.line	0	loadk        r22   k28 ; k28 = 205
.line	0	loadk        r23  k129 ; k129 = 107
.line	0	loadk        r24  k102 ; k102 = 87
.line	0	call         r11    14     0
.line	0	setlist       r9     0     1
.line	0	call          r8     2     2
.line	0	call          r7     2     2
.line	0	gettabup      r8    u0   k16 ; k16 = "require"
.line	0	gettabup      r9    u0   k17 ; k17 = "table"
.line	0	gettable      r9    r9   k18 ; k18 = "concat"
.line	0	newtable     r10     1     0
.line	0	move         r11    r1
.line	0	loadk        r12   k53 ; k53 = 89
.line	0	loadk        r13   k87 ; k87 = 70
.line	0	loadk        r14   k88 ; k88 = 214
.line	0	loadk        r15   k22 ; k22 = 53
.line	0	loadk        r16   k89 ; k89 = 22
.line	0	loadk        r17   k90 ; k90 = 35
.line	0	loadk        r18   k48 ; k48 = 168
.line	0	loadk        r19   k58 ; k58 = 25
.line	0	loadk        r20   k91 ; k91 = 175
.line	0	loadk        r21   k92 ; k92 = 218
.line	0	loadk        r22   k41 ; k41 = 200
.line	0	loadk        r23   k29 ; k29 = 41
.line	0	loadk        r24   k69 ; k69 = 94
.line	0	loadk        r25   k31 ; k31 = 54
.line	0	loadk        r26   k93 ; k93 = 204
.line	0	loadk        r27   k52 ; k52 = 255
.line	0	loadk        r28   k94 ; k94 = 169
.line	0	loadk        r29    k3 ; k3 = 52
.line	0	loadk        r30   k95 ; k95 = 171
.line	0	loadk        r31   k96 ; k96 = 15
.line	0	loadk        r32   k52 ; k52 = 255
.line	0	loadk        r33   k97 ; k97 = 9
.line	0	loadk        r34   k98 ; k98 = 154
.line	0	loadk        r35   k22 ; k22 = 53
.line	0	loadk        r36   k99 ; k99 = 178
.line	0	loadk        r37  k100 ; k100 = 219
.line	0	loadk        r38  k101 ; k101 = 151
.line	0	loadk        r39   k43 ; k43 = 123
.line	0	loadk        r40   k44 ; k44 = 77
.line	0	loadk        r41  k130 ; k130 = 46
.line	0	loadk        r42   k21 ; k21 = 210
.line	0	loadk        r43  k131 ; k131 = 229
.line	0	loadk        r44  k122 ; k122 = 133
.line	0	loadk        r45  k132 ; k132 = 102
.line	0	loadk        r46  k133 ; k133 = 176
.line	0	loadk        r47   k14 ; k14 = 18
.line	0	loadk        r48    k2 ; k2 = 250
.line	0	loadk        r49   k74 ; k74 = 14
.line	0	loadk        r50  k134 ; k134 = 185
.line	0	loadk        r51  k130 ; k130 = 46
.line	0	call         r11    41     2
.line	0	move         r12    r1
.line	0	loadk        r13  k105 ; k105 = 85
.line	0	loadk        r14  k135 ; k135 = 93
.line	0	loadk        r15  k136 ; k136 = 209
.line	0	loadk        r16    k8 ; k8 = 60
.line	0	loadk        r17  k137 ; k137 = 23
.line	0	loadk        r18   k31 ; k31 = 54
.line	0	loadk        r19  k138 ; k138 = 226
.line	0	loadk        r20   k96 ; k96 = 15
.line	0	loadk        r21    k9 ; k9 = 177
.line	0	call         r12    10     0
.line	0	setlist      r10     0     1
.line	0	call          r9     2     2
.line	0	call          r8     2     2
.line	0	gettabup      r9    u0   k16 ; k16 = "require"
.line	0	move         r10    r1
.line	0	loadk        r11   k53 ; k53 = 89
.line	0	loadk        r12   k87 ; k87 = 70
.line	0	loadk        r13   k88 ; k88 = 214
.line	0	loadk        r14   k22 ; k22 = 53
.line	0	loadk        r15   k89 ; k89 = 22
.line	0	loadk        r16   k90 ; k90 = 35
.line	0	loadk        r17   k48 ; k48 = 168
.line	0	loadk        r18   k58 ; k58 = 25
.line	0	loadk        r19   k91 ; k91 = 175
.line	0	loadk        r20   k92 ; k92 = 218
.line	0	loadk        r21   k41 ; k41 = 200
.line	0	loadk        r22   k29 ; k29 = 41
.line	0	loadk        r23   k69 ; k69 = 94
.line	0	loadk        r24   k31 ; k31 = 54
.line	0	loadk        r25   k93 ; k93 = 204
.line	0	loadk        r26   k52 ; k52 = 255
.line	0	loadk        r27   k94 ; k94 = 169
.line	0	loadk        r28    k3 ; k3 = 52
.line	0	loadk        r29   k95 ; k95 = 171
.line	0	loadk        r30   k96 ; k96 = 15
.line	0	loadk        r31   k52 ; k52 = 255
.line	0	loadk        r32   k97 ; k97 = 9
.line	0	loadk        r33   k98 ; k98 = 154
.line	0	loadk        r34   k22 ; k22 = 53
.line	0	loadk        r35   k99 ; k99 = 178
.line	0	loadk        r36  k100 ; k100 = 219
.line	0	loadk        r37  k101 ; k101 = 151
.line	0	loadk        r38   k65 ; k65 = 103
.line	0	loadk        r39  k102 ; k102 = 87
.line	0	loadk        r40  k103 ; k103 = 47
.line	0	loadk        r41  k104 ; k104 = 221
.line	0	loadk        r42   k47 ; k47 = 227
.line	0	loadk        r43   k48 ; k48 = 168
.line	0	loadk        r44  k105 ; k105 = 85
.line	0	loadk        r45  k139 ; k139 = 172
.line	0	loadk        r46  k140 ; k140 = 7
.line	0	loadk        r47  k141 ; k141 = 241
.line	0	loadk        r48   k84 ; k84 = 3
.line	0	loadk        r49  k122 ; k122 = 133
.line	0	loadk        r50   k23 ; k23 = 34
.line	0	call         r10    41     2
.line	0	call          r9     2     2
.line	0	gettabup     r10    u0   k16 ; k16 = "require"
.line	0	gettabup     r11    u0   k17 ; k17 = "table"
.line	0	gettable     r11   r11   k18 ; k18 = "concat"
.line	0	newtable     r12     1     0
.line	0	move         r13    r1
.line	0	loadk        r14   k53 ; k53 = 89
.line	0	loadk        r15   k87 ; k87 = 70
.line	0	loadk        r16   k88 ; k88 = 214
.line	0	loadk        r17   k22 ; k22 = 53
.line	0	loadk        r18   k89 ; k89 = 22
.line	0	loadk        r19   k90 ; k90 = 35
.line	0	loadk        r20   k48 ; k48 = 168
.line	0	loadk        r21   k58 ; k58 = 25
.line	0	loadk        r22   k91 ; k91 = 175
.line	0	loadk        r23   k92 ; k92 = 218
.line	0	loadk        r24   k41 ; k41 = 200
.line	0	loadk        r25   k29 ; k29 = 41
.line	0	loadk        r26  k142 ; k142 = 81
.line	0	loadk        r27   k31 ; k31 = 54
.line	0	loadk        r28  k143 ; k143 = 197
.line	0	loadk        r29  k144 ; k144 = 240
.line	0	loadk        r30  k145 ; k145 = 163
.line	0	loadk        r31   k19 ; k19 = 125
.line	0	loadk        r32  k146 ; k146 = 225
.line	0	loadk        r33   k78 ; k78 = 20
.line	0	loadk        r34  k147 ; k147 = 228
.line	0	loadk        r35  k126 ; k126 = 8
.line	0	loadk        r36  k148 ; k148 = 145
.line	0	loadk        r37  k149 ; k149 = 116
.line	0	loadk        r38  k150 ; k150 = 167
.line	0	loadk        r39   k56 ; k56 = 211
.line	0	loadk        r40   k88 ; k88 = 214
.line	0	loadk        r41  k151 ; k151 = 112
.line	0	loadk        r42   k19 ; k19 = 125
.line	0	loadk        r43  k152 ; k152 = 59
.line	0	loadk        r44  k115 ; k115 = 222
.line	0	loadk        r45  k107 ; k107 = 246
.line	0	loadk        r46  k153 ; k153 = 181
.line	0	loadk        r47  k154 ; k154 = 120
.line	0	loadk        r48   k95 ; k95 = 171
.line	0	loadk        r49  k103 ; k103 = 47
.line	0	loadk        r50   k70 ; k70 = 237
.line	0	loadk        r51   k84 ; k84 = 3
.line	0	loadk        r52  k155 ; k155 = 143
.line	0	loadk        r53  k156 ; k156 = 38
.line	0	call         r13    41     2
.line	0	move         r14    r1
.line	0	loadk        r15   k12 ; k12 = 73
.line	0	call         r14     2     0
.line	0	setlist      r12     0     1
.line	0	call         r11     2     2
.line	0	call         r10     2     2
.line	0	gettabup     r11    u0   k16 ; k16 = "require"
.line	0	gettabup     r12    u0   k17 ; k17 = "table"
.line	0	gettable     r12   r12   k18 ; k18 = "concat"
.line	0	newtable     r13     1     0
.line	0	move         r14    r1
.line	0	loadk        r15   k53 ; k53 = 89
.line	0	loadk        r16   k87 ; k87 = 70
.line	0	loadk        r17   k88 ; k88 = 214
.line	0	loadk        r18   k22 ; k22 = 53
.line	0	loadk        r19   k89 ; k89 = 22
.line	0	loadk        r20   k90 ; k90 = 35
.line	0	loadk        r21   k48 ; k48 = 168
.line	0	loadk        r22   k58 ; k58 = 25
.line	0	loadk        r23   k91 ; k91 = 175
.line	0	loadk        r24   k92 ; k92 = 218
.line	0	loadk        r25   k41 ; k41 = 200
.line	0	loadk        r26   k29 ; k29 = 41
.line	0	loadk        r27   k69 ; k69 = 94
.line	0	loadk        r28   k31 ; k31 = 54
.line	0	loadk        r29   k93 ; k93 = 204
.line	0	loadk        r30   k52 ; k52 = 255
.line	0	loadk        r31   k94 ; k94 = 169
.line	0	loadk        r32    k3 ; k3 = 52
.line	0	loadk        r33   k95 ; k95 = 171
.line	0	loadk        r34   k96 ; k96 = 15
.line	0	loadk        r35   k52 ; k52 = 255
.line	0	loadk        r36   k97 ; k97 = 9
.line	0	loadk        r37   k98 ; k98 = 154
.line	0	loadk        r38   k22 ; k22 = 53
.line	0	loadk        r39   k99 ; k99 = 178
.line	0	loadk        r40  k100 ; k100 = 219
.line	0	loadk        r41  k101 ; k101 = 151
.line	0	loadk        r42  k114 ; k114 = 101
.line	0	loadk        r43    k6 ; k6 = 71
.line	0	loadk        r44  k157 ; k157 = 57
.line	0	loadk        r45  k158 ; k158 = 212
.line	0	loadk        r46   k33 ; k33 = 244
.line	0	loadk        r47   k77 ; k77 = 174
.line	0	loadk        r48   k49 ; k49 = 36
.line	0	loadk        r49   k34 ; k34 = 179
.line	0	loadk        r50  k106 ; k106 = 31
.line	0	loadk        r51   k52 ; k52 = 255
.line	0	loadk        r52   k39 ; k39 = 30
.line	0	loadk        r53  k122 ; k122 = 133
.line	0	loadk        r54  k123 ; k123 = 21
.line	0	call         r14    41     2
.line	0	move         r15    r1
.line	0	loadk        r16  k159 ; k159 = 86
.line	0	loadk        r17  k160 ; k160 = 69
.line	0	loadk        r18  k104 ; k104 = 221
.line	0	loadk        r19  k161 ; k161 = 50
.line	0	loadk        r20   k36 ; k36 = 1
.line	0	loadk        r21  k126 ; k126 = 8
.line	0	loadk        r22  k138 ; k138 = 226
.line	0	loadk        r23  k109 ; k109 = 5
.line	0	loadk        r24  k162 ; k162 = 180
.line	0	loadk        r25  k128 ; k128 = 193
.line	0	loadk        r26  k143 ; k143 = 197
.line	0	loadk        r27  k163 ; k163 = 104
.line	0	loadk        r28  k164 ; k164 = 83
.line	0	loadk        r29    k0 ; k0 = 61
.line	0	loadk        r30  k165 ; k165 = 206
.line	0	loadk        r31  k147 ; k147 = 228
.line	0	loadk        r32   k68 ; k68 = 149
.line	0	loadk        r33  k166 ; k166 = 110
.line	0	loadk        r34  k145 ; k145 = 163
.line	0	loadk        r35   k96 ; k96 = 15
.line	0	loadk        r36  k167 ; k167 = 239
.line	0	call         r15    22     0
.line	0	setlist      r13     0     1
.line	0	call         r12     2     2
.line	0	call         r11     2     2
.line	0	gettabup     r12    u0   k16 ; k16 = "require"
.line	0	move         r13    r1
.line	0	loadk        r14   k53 ; k53 = 89
.line	0	loadk        r15  k160 ; k160 = 69
.line	0	loadk        r16   k21 ; k21 = 210
.line	0	loadk        r17    k0 ; k0 = 61
.line	0	loadk        r18  k137 ; k137 = 23
.line	0	loadk        r19  k157 ; k157 = 57
.line	0	loadk        r20   k48 ; k48 = 168
.line	0	loadk        r21   k58 ; k58 = 25
.line	0	loadk        r22  k168 ; k168 = 183
.line	0	loadk        r23  k104 ; k104 = 221
.line	0	loadk        r24   k27 ; k27 = 192
.line	0	loadk        r25  k169 ; k169 = 105
.line	0	loadk        r26  k105 ; k105 = 85
.line	0	loadk        r27  k170 ; k170 = 6
.line	0	loadk        r28  k115 ; k115 = 222
.line	0	loadk        r29  k138 ; k138 = 226
.line	0	loadk        r30  k145 ; k145 = 163
.line	0	loadk        r31  k171 ; k171 = 118
.line	0	call         r13    19     2
.line	0	call         r12     2     2
.line	0	gettable     r13    r5  k172 ; k172 = "ENUM_DownloadState"
.line	0	gettable     r14    r5  k173 ; k173 = "ENUM_DownloadType"
.line	0	gettable     r15    r5  k174 ; k174 = "RecommendBundleIDs"
.line	0	newtable     r16     0     0
.line	0	gettabup     r17    u0  k175 ; k175 = "pairs"
.line	0	move         r18   r15
.line	0	call         r17     2     4
.line	0	jmp            0  l673
.line	0	settable     r16   r21  k176 ; k176 = true
.label	l673
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	newtable     r17     2     0
.line	0	gettable     r18    r5  k177 ; k177 = "EODPackID"
.line	0	gettable     r18   r18  k178 ; k178 = "UserCurEquipment"
.line	0	gettable     r19    r5  k177 ; k177 = "EODPackID"
.line	0	gettable     r19   r19  k179 ; k179 = "UserWardrobe"
.line	0	setlist      r17     2     1
.line	0	newtable     r18     0     2
.line	0	gettable     r19    r5  k177 ; k177 = "EODPackID"
.line	0	gettable     r19   r19  k178 ; k178 = "UserCurEquipment"
.line	0	settable     r18   r19  k176 ; k176 = true
.line	0	gettable     r19    r5  k180 ; k180 = "FIT_COMMERCIAL_CORE_" (truncated)
.line	0	settable     r18   r19  k176 ; k176 = true
.line	0	newtable     r19     0     3
.line	0	gettable     r20   r14  k181 ; k181 = "ODPAK"
.line	0	settable     r19   r20  k176 ; k176 = true
.line	0	gettable     r20   r14  k182 ; k182 = "ODPACK"
.line	0	settable     r19   r20  k176 ; k176 = true
.line	0	gettable     r20   r14  k183 ; k183 = "UGCPACK"
.line	0	settable     r19   r20  k176 ; k176 = true
.line	0	loadk        r20  k161 ; k161 = 50
.line	0	mul          r21   r20   k86 ; k86 = 4
.line	0	loadk        r22  k184 ; k184 = 0.25
.line	0	newtable     r23     3     0
.line	0	move         r24    r1
.line	0	loadk        r25  k185 ; k185 = 121
.line	0	loadk        r26   k20 ; k20 = 75
.line	0	loadk        r27  k136 ; k136 = 209
.line	0	loadk        r28  k156 ; k156 = 38
.line	0	loadk        r29   k58 ; k58 = 25
.line	0	loadk        r30   k49 ; k49 = 36
.line	0	loadk        r31   k88 ; k88 = 214
.line	0	loadk        r32   k76 ; k76 = 11
.line	0	loadk        r33  k186 ; k186 = 173
.line	0	loadk        r34  k187 ; k187 = 202
.line	0	loadk        r35  k143 ; k143 = 197
.line	0	loadk        r36   k64 ; k64 = 88
.line	0	loadk        r37  k188 ; k188 = 0
.line	0	loadk        r38  k189 ; k189 = 108
.line	0	call         r24    15     2
.line	0	move         r25    r1
.line	0	loadk        r26  k190 ; k190 = 109
.line	0	loadk        r27  k191 ; k191 = 67
.line	0	loadk        r28  k100 ; k100 = 219
.line	0	loadk        r29  k192 ; k192 = 55
.line	0	loadk        r30   k51 ; k51 = 29
.line	0	loadk        r31   k90 ; k90 = 35
.line	0	loadk        r32  k193 ; k193 = 213
.line	0	loadk        r33   k51 ; k51 = 29
.line	0	loadk        r34   k50 ; k50 = 170
.line	0	loadk        r35  k100 ; k100 = 219
.line	0	loadk        r36  k187 ; k187 = 202
.line	0	loadk        r37  k194 ; k194 = 111
.line	0	loadk        r38  k102 ; k102 = 87
.line	0	loadk        r39  k195 ; k195 = 43
.line	0	loadk        r40   k33 ; k33 = 244
.line	0	loadk        r41  k143 ; k143 = 197
.line	0	loadk        r42  k150 ; k150 = 167
.line	0	loadk        r43   k43 ; k43 = 123
.line	0	loadk        r44  k196 ; k196 = 189
.line	0	loadk        r45   k78 ; k78 = 20
.line	0	loadk        r46   k93 ; k93 = 204
.line	0	loadk        r47  k126 ; k126 = 8
.line	0	loadk        r48  k197 ; k197 = 129
.line	0	loadk        r49    k3 ; k3 = 52
.line	0	loadk        r50  k121 ; k121 = 191
.line	0	loadk        r51  k198 ; k198 = 208
.line	0	loadk        r52   k38 ; k38 = 216
.line	0	loadk        r53  k199 ; k199 = 115
.line	0	call         r25    29     2
.line	0	move         r26    r1
.line	0	loadk        r27  k154 ; k154 = 120
.line	0	loadk        r28  k160 ; k160 = 69
.line	0	loadk        r29   k28 ; k28 = 205
.line	0	loadk        r30    k3 ; k3 = 52
.line	0	loadk        r31   k51 ; k51 = 29
.line	0	loadk        r32   k55 ; k55 = 37
.line	0	loadk        r33   k60 ; k60 = 217
.line	0	loadk        r34   k49 ; k49 = 36
.line	0	loadk        r35  k200 ; k200 = 166
.line	0	loadk        r36   k38 ; k38 = 216
.line	0	loadk        r37   k52 ; k52 = 255
.line	0	loadk        r38  k201 ; k201 = 98
.line	0	loadk        r39  k202 ; k202 = 64
.line	0	loadk        r40  k203 ; k203 = 42
.line	0	loadk        r41  k204 ; k204 = 194
.line	0	loadk        r42  k205 ; k205 = 249
.line	0	loadk        r43  k206 ; k206 = 164
.line	0	call         r26    18     2
.line	0	setlist      r23     3     1
.line	0	closure      r24    f1
.line	0	settable      r2  k207   r24 ; k207 = "ctor"
.line	0	closure      r24    f2
.line	0	settable      r2  k208   r24 ; k208 = "OnInitialize"
.line	0	closure      r24    f3
.line	0	settable      r2  k209   r24 ; k209 = "RegistEvents"
.line	0	closure      r24    f4
.line	0	settable      r2  k210   r24 ; k210 = "OnPostInitialize"
.line	0	closure      r24    f5
.line	0	settable      r2  k211   r24 ; k211 = "OnClose"
.line	0	closure      r24    f6
.line	0	settable      r2  k212   r24 ; k212 = "OnShow"
.line	0	closure      r24    f7
.line	0	settable      r2  k213   r24 ; k213 = "OnVerticalTextTabCli" (truncated)
.line	0	closure      r24    f8
.line	0	settable      r2  k214   r24 ; k214 = "OnVerticalTextTabSel" (truncated)
.line	0	closure      r24    f9
.line	0	settable      r2  k215   r24 ; k215 = "OnVerticalTextTabRef" (truncated)
.line	0	closure      r24   f10
.line	0	settable      r2  k216   r24 ; k216 = "OnHorizontalTabNumCa" (truncated)
.line	0	closure      r24   f11
.line	0	settable      r2  k217   r24 ; k217 = "OnVerticalTabNumCall" (truncated)
.line	0	closure      r24   f12
.line	0	settable      r2  k218   r24 ; k218 = "OnClickButton_Settin" (truncated)
.line	0	closure      r24   f13
.line	0	settable      r2  k219   r24 ; k219 = "OnClickButton_Delete"
.line	0	closure      r24   f14
.line	0	settable      r2  k220   r24 ; k220 = "OnClickButton_Close"
.line	0	closure      r24   f15
.line	0	settable      r2  k221   r24 ; k221 = "HandleClose"
.line	0	closure      r24   f16
.line	0	settable      r2  k222   r24 ; k222 = "OnClickItemButton_Do" (truncated)
.line	0	closure      r24   f17
.line	0	settable      r2  k223   r24 ; k223 = "OnClickedLevelOneTab"
.line	0	closure      r24   f18
.line	0	settable      r2  k224   r24 ; k224 = "OnClickShowDownloadS" (truncated)
.line	0	closure      r24   f19
.line	0	settable      r2  k225   r24 ; k225 = "OnClickBackToView"
.line	0	closure      r24   f20
.line	0	settable      r2  k226   r24 ; k226 = "OnClickRecommendRewa" (truncated)
.line	0	closure      r24   f21
.line	0	settable      r2  k227   r24 ; k227 = "OnAutoDownloadCheckC" (truncated)
.line	0	closure      r24   f22
.line	0	settable      r2  k228   r24 ; k228 = "UpdateAutoDownloadIc" (truncated)
.line	0	closure      r24   f23
.line	0	settable      r2  k229   r24 ; k229 = "OnClickToggleDownloa" (truncated)
.line	0	closure      r24   f24
.line	0	settable      r2  k230   r24 ; k230 = "OnClickShowCalcTip"
.line	0	closure      r24   f25
.line	0	settable      r2  k231   r24 ; k231 = "ToggleDownloadBundle"
.line	0	closure      r24   f26
.line	0	settable      r2  k232   r24 ; k232 = "ToggleDownload"
.line	0	closure      r24   f27
.line	0	settable      r2  k233   r24 ; k233 = "ToggleDownloadItemDa" (truncated)
.line	0	closure      r24   f28
.line	0	settable      r2  k234   r24 ; k234 = "GetShowTabKeyList"
.line	0	closure      r24   f29
.line	0	settable      r2  k235   r24 ; k235 = "GetItemData"
.line	0	closure      r24   f30
.line	0	settable      r2  k236   r24 ; k236 = "OnClickButton_Downlo" (truncated)
.line	0	closure      r24   f31
.line	0	settable      r2  k237   r24 ; k237 = "OnClickButton_Downlo" (truncated)
.line	0	closure      r24   f32
.line	0	settable      r2  k238   r24 ; k238 = "OnIconAutoHelpButton" (truncated)
.line	0	closure      r24   f33
.line	0	settable      r2  k239   r24 ; k239 = "OnIconAutoSetButtonC" (truncated)
.line	0	closure      r24   f34
.line	0	settable      r2  k240   r24 ; k240 = "_ToggleDownloadAll"
.line	0	closure      r24   f35
.line	0	settable      r2  k241   r24 ; k241 = "OnClickUGCAssetHub"
.line	0	closure      r24   f36
.line	0	settable      r2  k242   r24 ; k242 = "OnClickUGCMall"
.line	0	closure      r24   f37
.line	0	settable      r2  k243   r24 ; k243 = "OnClickUGCAssetHubCa" (truncated)
.line	0	closure      r24   f38
.line	0	settable      r2  k244   r24 ; k244 = "GetPufferDeleteManag" (truncated)
.line	0	closure      r24   f39
.line	0	settable      r2  k245   r24 ; k245 = "GetCommonDownloadHan" (truncated)
.line	0	closure      r24   f40
.line	0	settable      r2  k246   r24 ; k246 = "UpdateUI"
.line	0	closure      r24   f41
.line	0	settable      r2  k247   r24 ; k247 = "UpdateFitVersionUI"
.line	0	closure      r24   f42
.line	0	settable      r2  k248   r24 ; k248 = "UpdateDownloadAllBut" (truncated)
.line	0	closure      r24   f43
.line	0	settable      r2  k249   r24 ; k249 = "UpdateAutoDownload"
.line	0	closure      r24   f44
.line	0	settable      r2  k250   r24 ; k250 = "CheckShowGuideTips"
.line	0	closure      r24   f45
.line	0	settable      r2  k251   r24 ; k251 = "UpdateDownloadSelect" (truncated)
.line	0	closure      r24   f46
.line	0	settable      r2  k252   r24 ; k252 = "UpdateAllDownloadSiz" (truncated)
.line	0	closure      r24   f47
.line	0	settable      r2  k253   r24 ; k253 = "GetAllOptionalDelete" (truncated)
.line	0	closure      r24   f48
.line	0	settable      r2  k254   r24 ; k254 = "UpdateGameSize"
.line	0	closure      r24   f49
.line	0	settable      r2  k255   r24 ; k255 = "UpdateRecommendInfo"
.line	0	loadk        r24  k256 ; k256 = "UpdateReverseDownloa" (truncated)
.line	0	closure      r25   f50
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k257 ; k257 = "OnAndroidBack"
.line	0	closure      r25   f51
.line	0	settable      r2   r24   r25
.line	0	loadk        r24  k258 ; k258 = "InitTabData"
.line	0	closure      r25   f52
.line	0	settable      r2   r24   r25
.line	0	newtable     r24     0     5
.line	0	loadk        r25  k259 ; k259 = "RES_AUDIO_HIGH"
.line	0	gettable     r25    r5   r25
.line	0	loadk        r26  k260 ; k260 = 1
.line	0	settable     r24   r25   r26
.line	0	loadk        r25  k261 ; k261 = "RES_AUDIO_NORMAL"
.line	0	gettable     r25    r5   r25
.line	0	loadk        r26  k260 ; k260 = 1
.line	0	settable     r24   r25   r26
.line	0	loadk        r25  k262 ; k262 = "RES_AUDIO_LOW"
.line	0	gettable     r25    r5   r25
.line	0	loadk        r26  k260 ; k260 = 1
.line	0	settable     r24   r25   r26
.line	0	loadk        r25  k263 ; k263 = "res_baltichd"
.line	0	loadk        r26  k264 ; k264 = 2
.line	0	settable     r24   r25   r26
.line	0	loadk        r25  k265 ; k265 = "res_commtexmd"
.line	0	loadk        r26  k264 ; k264 = 2
.line	0	settable     r24   r25   r26
.line	0	loadk        r25  k266 ; k266 = "SelectTopTab"
.line	0	closure      r26   f53
.line	0	settable      r2   r25   r26
.line	0	loadk        r25  k267 ; k267 = "IsRecommendPage"
.line	0	closure      r26   f54
.line	0	settable      r2   r25   r26
.line	0	loadk        r25  k268 ; k268 = "IsFitLobbyResPage"
.line	0	closure      r26   f55
.line	0	settable      r2   r25   r26
.line	0	loadk        r25  k269 ; k269 = "IsRecommendTabData"
.line	0	closure      r26   f56
.line	0	settable      r2   r25   r26
.line	0	loadk        r25  k270 ; k270 = "UpdateTabContent"
.line	0	closure      r26   f57
.line	0	settable      r2   r25   r26
.line	0	loadk        r25  k271 ; k271 = "UpdateTabExtraConten" (truncated)
.line	0	closure      r26   f58
.line	0	settable      r2   r25   r26
.line	0	loadk        r25  k272 ; k272 = "OnCleanup"
.line	0	closure      r26   f59
.line	0	settable      r2   r25   r26
.line	0	loadk        r25  k273 ; k273 = "UpdateBigImage"
.line	0	closure      r26   f60
.line	0	settable      r2   r25   r26
.line	0	loadk        r25  k274 ; k274 = "UpdateFitLobby"
.line	0	closure      r26   f61
.line	0	settable      r2   r25   r26
.line	0	loadk        r25  k275 ; k275 = "UpdateDownloadSpeed"
.line	0	closure      r26   f62
.line	0	settable      r2   r25   r26
.line	0	loadk        r25  k276 ; k276 = "UpdateNetworkInfo"
.line	0	closure      r26   f63
.line	0	settable      r2   r25   r26
.line	0	loadk        r25  k277 ; k277 = "UpdateCurTabDownload" (truncated)
.line	0	closure      r26   f64
.line	0	settable      r2   r25   r26
.line	0	loadk        r25  k278 ; k278 = "UpdateRecommendType"
.line	0	closure      r26   f65
.line	0	settable      r2   r25   r26
.line	0	loadk        r25  k279 ; k279 = "UpdateUIType"
.line	0	closure      r26   f66
.line	0	settable      r2   r25   r26
.line	0	loadk        r25  k280 ; k280 = "ShowDownload_Loading" (truncated)
.line	0	closure      r26   f67
.line	0	settable      r2   r25   r26
.line	0	loadk        r25  k281 ; k281 = "IsViewMode"
.line	0	closure      r26   f68
.line	0	settable      r2   r25   r26
.line	0	loadk        r25  k282 ; k282 = "BlockEntrances"
.line	0	closure      r26   f69
.line	0	settable      r2   r25   r26
.line	0	loadk        r25  k283 ; k283 = "require"
.line	0	gettabup     r25    u0   r25
.line	0	move         r26    r1
.line	0	loadk        r27  k284 ; k284 = 89
.line	0	loadk        r28  k285 ; k285 = 70
.line	0	loadk        r29  k286 ; k286 = 222
.line	0	loadk        r30  k287 ; k287 = 35
.line	0	loadk        r31  k288 ; k288 = 11
.line	0	call         r26     6     2
.line	0	call         r25     2     2
.line	0	loadk        r26  k283 ; k283 = "require"
.line	0	gettabup     r26    u0   r26
.line	0	move         r27    r1
.line	0	loadk        r28  k284 ; k284 = 89
.line	0	loadk        r29  k285 ; k285 = 70
.line	0	loadk        r30  k289 ; k289 = 214
.line	0	loadk        r31   k22 ; k22 = 53
.line	0	loadk        r32  k290 ; k290 = 22
.line	0	loadk        r33  k287 ; k287 = 35
.line	0	loadk        r34  k291 ; k291 = 168
.line	0	loadk        r35  k292 ; k292 = 25
.line	0	loadk        r36  k293 ; k293 = 175
.line	0	loadk        r37  k294 ; k294 = 218
.line	0	loadk        r38  k295 ; k295 = 200
.line	0	loadk        r39  k296 ; k296 = 88
.line	0	loadk        r40  k297 ; k297 = 71
.line	0	loadk        r41  k298 ; k298 = 48
.line	0	loadk        r42  k299 ; k299 = 244
.line	0	loadk        r43  k300 ; k300 = 240
.line	0	loadk        r44  k301 ; k301 = 184
.line	0	loadk        r45  k302 ; k302 = 123
.line	0	loadk        r46  k303 ; k303 = 162
.line	0	loadk        r47  k304 ; k304 = 5
.line	0	loadk        r48  k305 ; k305 = 255
.line	0	loadk        r49  k306 ; k306 = 8
.line	0	loadk        r50  k307 ; k307 = 132
.line	0	loadk        r51  k308 ; k308 = 49
.line	0	loadk        r52  k309 ; k309 = 253
.line	0	loadk        r53  k310 ; k310 = 221
.line	0	loadk        r54  k311 ; k311 = 216
.line	0	loadk        r55  k312 ; k312 = 100
.line	0	loadk        r56  k297 ; k297 = 71
.line	0	call         r27    30     2
.line	0	call         r26     2     2
.line	0	move         r27   r25
.line	0	move         r28   r26
.line	0	loadnil      r29     0
.line	0	move         r30    r2
.line	0	call         r27     4     2
.line	0	return       r27     2
.line	0	return        r0     1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f0

.source	null
.linedefined	2
.lastlinedefined	9
.numparams	0
.is_vararg	1
.maxstacksize	9

.upvalue	"_ENV"	0	false
.upvalue	"U1"	0	true

.constant	k0	1
.constant	k1	"string"
.constant	k2	"char"
.constant	k3	16
.constant	k4	31
.constant	k5	7
.constant	k6	256
.constant	k7	"table"
.constant	k8	"concat"

.line	2	newtable      r0     0     0
.line	2	vararg        r1     0
.line	2	setlist       r0     0     1
.line	2	newtable      r1     0     0
.line	2	loadk         r2    k0 ; k0 = 1
.line	2	len           r3    r0
.line	2	loadk         r4    k0 ; k0 = 1
.line	2	move          r0    r0
.line	2	gettabup      r6    u0    k1 ; k1 = "string"
.line	2	gettable      r6    r6    k2 ; k2 = "char"
.line	2	gettable      r7    r0    r5
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mod           r8    r8    k3 ; k3 = 16
.line	2	add           r8    r8    k0 ; k0 = 1
.line	2	gettabup      r8    u1    r8
.line	2	bxor          r7    r7    r8
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mul           r8    r8    k4 ; k4 = 31
.line	2	add           r8    r8    k5 ; k5 = 7
.line	2	mod           r8    r8    k6 ; k6 = 256
.line	2	bxor          r7    r7    r8
.line	2	mod           r7    r7    k6 ; k6 = 256
.line	2	call          r6     2     2
.line	2	settable      r1    r5    r6
.line	2	move          r0    r0
.line	2	gettabup      r2    u0    k7 ; k7 = "table"
.line	2	gettable      r2    r2    k8 ; k8 = "concat"
.line	2	move          r3    r1
.line	2	tailcall      r2     2
.line	2	return        r2     0
.line	2	return        r0     1
.line	2	move          r0    r0
.line	2	return        r0     1

.function	main/f1

.source	null
.linedefined	71
.lastlinedefined	124
.numparams	4
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	3	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	5	true
.upvalue	"U4"	7	true
.upvalue	"U5"	15	true

.constant	k0	"deleteTargetSize"
.constant	k1	-1
.constant	k2	"uiType"
.constant	k3	"View"
.constant	k4	"key"
.constant	k5	"jumpKey"
.constant	k6	"tostring"
.constant	k7	"targetSize"
.constant	k8	"Delete"
.constant	k9	"bShowWarningPopUp"
.constant	k10	"log"
.constant	k11	"bWriteLog"
.constant	k12	"string"
.constant	k13	"format"
.constant	k14	126
.constant	k15	69
.constant	k16	200
.constant	k17	62
.constant	k18	20
.constant	k19	56
.constant	k20	231
.constant	k21	14
.constant	k22	156
.constant	k23	226
.constant	k24	110
.constant	k25	92
.constant	k26	6
.constant	k27	254
.constant	k28	223
.constant	k29	136
.constant	k30	74
.constant	k31	245
.constant	k32	3
.constant	k33	252
.constant	k34	8
.constant	k35	132
.constant	k36	116
.constant	k37	243
.constant	k38	203
.constant	k39	216
.constant	k40	101
.constant	k41	44
.constant	k42	207
.constant	k43	213
.constant	k44	179
.constant	k45	112
.constant	k46	186
.constant	k47	77
.constant	k48	189
.constant	k49	4
.constant	k50	"topTabIndex"
.constant	k51	"curVerTabIndex"
.constant	k52	"showTabData"
.constant	k53	nil
.constant	k54	"sumDownloadData"
.constant	k55	"curShowBundleIDs"
.constant	k56	"deleteKey"
.constant	k57	"deleteRes"
.constant	k58	"needCalcData"
.constant	k59	"showDownloadAll"
.constant	k60	false
.constant	k61	"showDownloadIconCheckBox"
.constant	k62	"downloadRecordKey"
.constant	k63	"downloadUIPackIDs"
.constant	k64	"userEquipmentPaks"
.constant	k65	"userWardrobeItems"
.constant	k66	"userWardrobePaks"
.constant	k67	"showPrefetchReddot"
.constant	k68	"smartDownloadSize"
.constant	k69	0
.constant	k70	"mergeBundleDataMap"
.constant	k71	"downloadSelectMap"
.constant	k72	"deleteSelectMap"
.constant	k73	"require"
.constant	k74	"table"
.constant	k75	"concat"
.constant	k76	89
.constant	k77	70
.constant	k78	214
.constant	k79	53
.constant	k80	22
.constant	k81	35
.constant	k82	168
.constant	k83	25
.constant	k84	175
.constant	k85	218
.constant	k86	41
.constant	k87	81
.constant	k88	54
.constant	k89	197
.constant	k90	240
.constant	k91	163
.constant	k92	125
.constant	k93	225
.constant	k94	228
.constant	k95	147
.constant	k96	52
.constant	k97	167
.constant	k98	242
.constant	k99	80
.constant	k100	38
.constant	k101	138
.constant	k102	127
.constant	k103	28
.constant	k104	241
.constant	k105	142
.constant	k106	24
.constant	k107	95
.constant	k108	63
.constant	k109	26
.constant	k110	9
.constant	k111	177
.constant	k112	192
.constant	k113	"isFitVersion"
.constant	k114	"IsFITVersion"
.constant	k115	"fitLobbyResKey"
.constant	k116	"FIT_LOBBY_RES_KEY"
.constant	k117	true
.constant	k118	"GetMixPackDownloadContent"
.constant	k119	"pairs"
.constant	k120	"log_tree"
.constant	k121	204
.constant	k122	220
.constant	k123	123
.constant	k124	68
.constant	k125	103
.constant	k126	221
.constant	k127	239
.constant	k128	174
.constant	k129	176
.constant	k130	18
.constant	k131	250
.constant	k132	180
.constant	k133	47
.constant	k134	73
.constant	k135	97
.constant	k136	88
.constant	k137	106
.constant	k138	166
.constant	k139	"RecommendBundleIDs"

.line	71	settable      r0    k0    k1 ; k1 = -1
.line	71	gettabup      r4    u0    k3 ; k3 = "View"
.line	71	settable      r0    k2    r4 ; k2 = "uiType"
.line	71	test          r2     0
.line	71	jmp            0   l20
.line	71	gettable      r4    r2    k4 ; k4 = "key"
.line	71	test          r4     0
.line	71	jmp            0   l13
.line	71	gettabup      r4    u1    k6 ; k6 = "tostring"
.line	71	gettable      r5    r2    k4 ; k4 = "key"
.line	71	call          r4     2     2
.line	71	settable      r0    k5    r4 ; k5 = "jumpKey"
.label	l13
.line	71	gettable      r4    r2    k7 ; k7 = "targetSize"
.line	71	test          r4     0
.line	71	jmp            0   l20
.line	71	gettable      r4    r2    k7 ; k7 = "targetSize"
.line	71	settable      r0    k0    r4 ; k0 = "deleteTargetSize"
.line	71	gettabup      r4    u0    k8 ; k8 = "Delete"
.line	71	settable      r0    k2    r4 ; k2 = "uiType"
.label	l20
.line	71	settable      r0    k9    r3 ; k9 = "bShowWarningPopUp"
.line	71	gettabup      r4    u1   k10 ; k10 = "log"
.line	71	gettabup      r5    u1   k11 ; k11 = "bWriteLog"
.line	71	test          r5     0
.line	71	jmp            0   l71
.line	71	gettabup      r5    u1   k12 ; k12 = "string"
.line	71	gettable      r5    r5   k13 ; k13 = "format"
.line	71	getupval      r6    u2
.line	71	loadk         r7   k14 ; k14 = 126
.line	71	loadk         r8   k15 ; k15 = 69
.line	71	loadk         r9   k16 ; k16 = 200
.line	71	loadk        r10   k17 ; k17 = 62
.line	71	loadk        r11   k18 ; k18 = 20
.line	71	loadk        r12   k19 ; k19 = 56
.line	71	loadk        r13   k20 ; k20 = 231
.line	71	loadk        r14   k21 ; k21 = 14
.line	71	loadk        r15   k22 ; k22 = 156
.line	71	loadk        r16   k23 ; k23 = 226
.line	71	loadk        r17   k16 ; k16 = 200
.line	71	loadk        r18   k24 ; k24 = 110
.line	71	loadk        r19   k25 ; k25 = 92
.line	71	loadk        r20   k26 ; k26 = 6
.line	71	loadk        r21   k27 ; k27 = 254
.line	71	loadk        r22   k28 ; k28 = 223
.line	71	loadk        r23   k29 ; k29 = 136
.line	71	loadk        r24   k30 ; k30 = 74
.line	71	loadk        r25   k31 ; k31 = 245
.line	71	loadk        r26   k32 ; k32 = 3
.line	71	loadk        r27   k33 ; k33 = 252
.line	71	loadk        r28   k34 ; k34 = 8
.line	71	loadk        r29   k35 ; k35 = 132
.line	71	loadk        r30   k36 ; k36 = 116
.line	71	loadk        r31   k37 ; k37 = 243
.line	71	loadk        r32   k38 ; k38 = 203
.line	71	loadk        r33   k39 ; k39 = 216
.line	71	loadk        r34   k40 ; k40 = 101
.line	71	loadk        r35   k15 ; k15 = 69
.line	71	loadk        r36   k41 ; k41 = 44
.line	71	loadk        r37   k42 ; k42 = 207
.line	71	loadk        r38   k43 ; k43 = 213
.line	71	loadk        r39   k44 ; k44 = 179
.line	71	loadk        r40   k45 ; k45 = 112
.line	71	loadk        r41   k46 ; k46 = 186
.line	71	loadk        r42   k47 ; k47 = 77
.line	71	loadk        r43   k48 ; k48 = 189
.line	71	loadk        r44   k49 ; k49 = 4
.line	71	call          r6    39     2
.line	71	gettabup      r7    u1    k6 ; k6 = "tostring"
.line	71	gettable      r8    r0    k0 ; k0 = "deleteTargetSize"
.line	71	call          r7     2     0
.line	71	call          r5     0     2
.label	l71
.line	71	call          r4     2     1
.line	71	settable      r0   k50    k1 ; k1 = -1
.line	71	settable      r0   k51    k1 ; k1 = -1
.line	71	settable      r0   k52   k53 ; k53 = nil
.line	71	newtable      r4     0     0
.line	71	settable      r0   k54    r4 ; k54 = "sumDownloadData"
.line	71	settable      r0   k55   k53 ; k53 = nil
.line	71	newtable      r4     0     0
.line	71	settable      r0   k56    r4 ; k56 = "deleteKey"
.line	71	newtable      r4     0     0
.line	71	settable      r0   k57    r4 ; k57 = "deleteRes"
.line	71	settable      r0   k58   k53 ; k53 = nil
.line	71	settable      r0   k59   k60 ; k60 = false
.line	71	settable      r0   k61   k60 ; k60 = false
.line	71	newtable      r4     0     0
.line	71	settable      r0   k62    r4 ; k62 = "downloadRecordKey"
.line	71	newtable      r4     0     0
.line	71	settable      r0   k63    r4 ; k63 = "downloadUIPackIDs"
.line	71	newtable      r4     0     0
.line	71	settable      r0   k64    r4 ; k64 = "userEquipmentPaks"
.line	71	newtable      r4     0     0
.line	71	settable      r0   k65    r4 ; k65 = "userWardrobeItems"
.line	71	newtable      r4     0     0
.line	71	settable      r0   k66    r4 ; k66 = "userWardrobePaks"
.line	71	settable      r0   k67   k60 ; k60 = false
.line	71	settable      r0   k68   k69 ; k69 = 0
.line	71	newtable      r4     0     0
.line	71	settable      r0   k70    r4 ; k70 = "mergeBundleDataMap"
.line	71	settable      r0   k71   k53 ; k53 = nil
.line	71	settable      r0   k72   k53 ; k53 = nil
.line	71	gettabup      r4    u1   k73 ; k73 = "require"
.line	71	gettabup      r5    u1   k74 ; k74 = "table"
.line	71	gettable      r5    r5   k75 ; k75 = "concat"
.line	71	newtable      r6     1     0
.line	71	getupval      r7    u2
.line	71	loadk         r8   k76 ; k76 = 89
.line	71	loadk         r9   k77 ; k77 = 70
.line	71	loadk        r10   k78 ; k78 = 214
.line	71	loadk        r11   k79 ; k79 = 53
.line	71	loadk        r12   k80 ; k80 = 22
.line	71	loadk        r13   k81 ; k81 = 35
.line	71	loadk        r14   k82 ; k82 = 168
.line	71	loadk        r15   k83 ; k83 = 25
.line	71	loadk        r16   k84 ; k84 = 175
.line	71	loadk        r17   k85 ; k85 = 218
.line	71	loadk        r18   k16 ; k16 = 200
.line	71	loadk        r19   k86 ; k86 = 41
.line	71	loadk        r20   k87 ; k87 = 81
.line	71	loadk        r21   k88 ; k88 = 54
.line	71	loadk        r22   k89 ; k89 = 197
.line	71	loadk        r23   k90 ; k90 = 240
.line	71	loadk        r24   k91 ; k91 = 163
.line	71	loadk        r25   k92 ; k92 = 125
.line	71	loadk        r26   k93 ; k93 = 225
.line	71	loadk        r27   k81 ; k81 = 35
.line	71	loadk        r28   k94 ; k94 = 228
.line	71	loadk        r29   k21 ; k21 = 14
.line	71	loadk        r30   k95 ; k95 = 147
.line	71	loadk        r31   k96 ; k96 = 52
.line	71	loadk        r32   k97 ; k97 = 167
.line	71	loadk        r33   k98 ; k98 = 242
.line	71	loadk        r34   k39 ; k39 = 216
.line	71	loadk        r35   k36 ; k36 = 116
.line	71	loadk        r36   k99 ; k99 = 80
.line	71	loadk        r37  k100 ; k100 = 38
.line	71	loadk        r38   k16 ; k16 = 200
.line	71	loadk        r39   k82 ; k82 = 168
.line	71	loadk        r40  k101 ; k101 = 138
.line	71	loadk        r41  k102 ; k102 = 127
.line	71	loadk        r42   k48 ; k48 = 189
.line	71	loadk        r43  k103 ; k103 = 28
.line	71	loadk        r44  k104 ; k104 = 241
.line	71	loadk        r45   k49 ; k49 = 4
.line	71	loadk        r46  k105 ; k105 = 142
.line	71	loadk        r47  k106 ; k106 = 24
.line	71	call          r7    41     2
.line	71	getupval      r8    u2
.line	71	loadk         r9  k107 ; k107 = 95
.line	71	loadk        r10   k47 ; k47 = 77
.line	71	loadk        r11   k78 ; k78 = 214
.line	71	loadk        r12  k108 ; k108 = 63
.line	71	loadk        r13   k80 ; k80 = 22
.line	71	loadk        r14  k109 ; k109 = 26
.line	71	loadk        r15   k20 ; k20 = 231
.line	71	loadk        r16  k110 ; k110 = 9
.line	71	loadk        r17  k111 ; k111 = 177
.line	71	loadk        r18  k112 ; k112 = 192
.line	71	loadk        r19   k85 ; k85 = 218
.line	71	call          r8    12     0
.line	71	setlist       r6     0     1
.line	71	call          r5     2     2
.line	71	call          r4     2     2
.line	71	gettable      r5    r4  k114 ; k114 = "IsFITVersion"
.line	71	call          r5     1     2
.line	71	settable      r0  k113    r5 ; k113 = "isFitVersion"
.line	71	newtable      r5     0     0
.line	71	settable      r0  k115    r5 ; k115 = "fitLobbyResKey"
.line	71	gettable      r5    r0  k113 ; k113 = "isFitVersion"
.line	71	test          r5     0
.line	71	jmp            0  l191
.line	71	gettable      r5    r0  k115 ; k115 = "fitLobbyResKey"
.line	71	gettabup      r6    u3  k116 ; k116 = "FIT_LOBBY_RES_KEY"
.line	71	settable      r5    r6  k117 ; k117 = true
.line	71	gettabup      r5    u4  k118 ; k118 = "GetMixPackDownloadCo" (truncated)
.line	71	gettabup      r6    u3  k116 ; k116 = "FIT_LOBBY_RES_KEY"
.line	71	call          r5     2     2
.line	71	gettabup      r6    u1  k119 ; k119 = "pairs"
.line	71	move          r7    r5
.line	71	call          r6     2     4
.line	71	jmp            0  l189
.line	71	gettabup     r11    u1  k119 ; k119 = "pairs"
.line	71	move         r12   r10
.line	71	call         r11     2     4
.line	71	jmp            0  l187
.line	71	gettable     r16    r0  k115 ; k115 = "fitLobbyResKey"
.line	71	settable     r16   r15  k117 ; k117 = true
.label	l187
.line	71	move          r0    r0
.line	71	move          r0    r0
.label	l189
.line	71	move          r0    r0
.line	71	move          r0    r0
.label	l191
.line	71	gettabup      r5    u1  k120 ; k120 = "log_tree"
.line	71	gettabup      r6    u1   k74 ; k74 = "table"
.line	71	gettable      r6    r6   k75 ; k75 = "concat"
.line	71	newtable      r7     1     0
.line	71	getupval      r8    u2
.line	71	loadk         r9   k14 ; k14 = 126
.line	71	loadk        r10   k15 ; k15 = 69
.line	71	loadk        r11   k16 ; k16 = 200
.line	71	loadk        r12   k17 ; k17 = 62
.line	71	loadk        r13   k18 ; k18 = 20
.line	71	loadk        r14   k19 ; k19 = 56
.line	71	loadk        r15   k20 ; k20 = 231
.line	71	loadk        r16   k21 ; k21 = 14
.line	71	loadk        r17   k22 ; k22 = 156
.line	71	loadk        r18   k23 ; k23 = 226
.line	71	loadk        r19   k16 ; k16 = 200
.line	71	loadk        r20   k24 ; k24 = 110
.line	71	loadk        r21   k25 ; k25 = 92
.line	71	loadk        r22   k26 ; k26 = 6
.line	71	loadk        r23   k27 ; k27 = 254
.line	71	loadk        r24   k28 ; k28 = 223
.line	71	loadk        r25   k29 ; k29 = 136
.line	71	loadk        r26   k30 ; k30 = 74
.line	71	loadk        r27   k31 ; k31 = 245
.line	71	loadk        r28   k32 ; k32 = 3
.line	71	loadk        r29   k33 ; k33 = 252
.line	71	loadk        r30   k34 ; k34 = 8
.line	71	loadk        r31   k35 ; k35 = 132
.line	71	loadk        r32   k36 ; k36 = 116
.line	71	loadk        r33   k37 ; k37 = 243
.line	71	loadk        r34  k121 ; k121 = 204
.line	71	loadk        r35  k122 ; k122 = 220
.line	71	loadk        r36  k123 ; k123 = 123
.line	71	loadk        r37  k124 ; k124 = 68
.line	71	loadk        r38  k125 ; k125 = 103
.line	71	loadk        r39  k126 ; k126 = 221
.line	71	loadk        r40  k127 ; k127 = 239
.line	71	loadk        r41  k128 ; k128 = 174
.line	71	loadk        r42   k77 ; k77 = 70
.line	71	loadk        r43  k129 ; k129 = 176
.line	71	loadk        r44  k130 ; k130 = 18
.line	71	loadk        r45  k131 ; k131 = 250
.line	71	loadk        r46   k21 ; k21 = 14
.line	71	loadk        r47  k132 ; k132 = 180
.line	71	loadk        r48  k133 ; k133 = 47
.line	71	call          r8    41     2
.line	71	getupval      r9    u2
.line	71	loadk        r10  k134 ; k134 = 73
.line	71	loadk        r11  k135 ; k135 = 97
.line	71	loadk        r12   k85 ; k85 = 218
.line	71	loadk        r13   k86 ; k86 = 41
.line	71	loadk        r14  k136 ; k136 = 88
.line	71	loadk        r15  k137 ; k137 = 106
.line	71	loadk        r16  k138 ; k138 = 166
.line	71	call          r9     8     0
.line	71	setlist       r7     0     1
.line	71	call          r6     2     2
.line	71	gettable      r7    r0  k115 ; k115 = "fitLobbyResKey"
.line	71	call          r5     3     1
.line	71	getupval      r5    u5
.line	71	eq             0    r5   k53 ; k53 = nil
.line	71	jmp            0  l262
.line	71	newtable      r5     0     0
.line	71	setupval      r5    u5
.line	71	gettabup      r5    u1  k119 ; k119 = "pairs"
.line	71	gettabup      r6    u3  k139 ; k139 = "RecommendBundleIDs"
.line	71	call          r5     2     4
.line	71	jmp            0  l260
.line	71	settabup      u5    r9  k117 ; k117 = true
.label	l260
.line	71	move          r0    r0
.line	71	move          r0    r0
.label	l262
.line	71	return        r0     1
.line	71	gettabup      r0    u1   k93 ; k93 = 225
.line	71	move          r0    r0
.line	71	move          r0    r0
.line	71	return        r0     1

.function	main/f2

.source	null
.linedefined	126
.lastlinedefined	170
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	9	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	126
.constant	k3	69
.constant	k4	200
.constant	k5	62
.constant	k6	20
.constant	k7	56
.constant	k8	231
.constant	k9	14
.constant	k10	156
.constant	k11	226
.constant	k12	110
.constant	k13	92
.constant	k14	6
.constant	k15	254
.constant	k16	223
.constant	k17	136
.constant	k18	74
.constant	k19	245
.constant	k20	47
.constant	k21	230
.constant	k22	46
.constant	k23	152
.constant	k24	51
.constant	k25	167
.constant	k26	214
.constant	k27	216
.constant	k28	123
.constant	k29	75
.constant	k30	222
.constant	k31	168
.constant	k32	250
.constant	k33	"UIRoot"
.constant	k34	"TextBlock_7"
.constant	k35	"SetText"
.constant	k36	"LocUtil"
.constant	k37	"GetLocalizeResStr"
.constant	k38	83200
.constant	k39	"TextBlock_1"
.constant	k40	9413
.constant	k41	"TextBlock_18"
.constant	k42	11685
.constant	k43	"TextBlock_102"
.constant	k44	8500428
.constant	k45	"TextBlock_4"
.constant	k46	7510
.constant	k47	"TextBlock_139"
.constant	k48	83211
.constant	k49	"TextBlock_0"
.constant	k50	83210
.constant	k51	"TextBlock_10"
.constant	k52	83244
.constant	k53	"TextBlock_5"
.constant	k54	83234
.constant	k55	83245
.constant	k56	"TextBlock_2"
.constant	k57	83247
.constant	k58	"Download_Main_Tips_UIBP"
.constant	k59	8800607
.constant	k60	"Common_Tab_Horizontal_LevelOne_Text_UIBP"
.constant	k61	"InitHorizontalLevelOneTextTab"
.constant	k62	"Common_Tab_Vertical_LevelOne_Text_UIBP"
.constant	k63	"InitVerticalTextTab"
.constant	k64	"LoopScrollBox_Hor"
.constant	k65	"InitChildClassScrollBox"
.constant	k66	"LoopScrollBox_1"
.constant	k67	"table"
.constant	k68	"concat"
.constant	k69	125
.constant	k70	210
.constant	k71	53
.constant	k72	52
.constant	k73	34
.constant	k74	68
.constant	k75	142
.constant	k76	192
.constant	k77	205
.constant	k78	41
.constant	k79	54
.constant	k80	201
.constant	k81	244
.constant	k82	179
.constant	k83	141
.constant	k84	1
.constant	k85	251
.constant	k86	2
.constant	k87	30
.constant	k88	188
.constant	k89	215
.constant	k90	77
.constant	k91	40
.constant	k92	227
.constant	k93	36
.constant	k94	170
.constant	k95	29
.constant	k96	255
.constant	k97	89
.constant	k98	143
.constant	k99	95
.constant	k100	71
.constant	k101	145
.constant	k102	23
.constant	k103	32
.constant	k104	232
.constant	k105	172
.constant	k106	206
.constant	k107	88
.constant	k108	48
.constant	k109	149
.constant	k110	83
.constant	k111	161
.constant	k112	237
.constant	k113	21
.constant	k114	144
.constant	k115	59
.constant	k116	176
.constant	k117	218
.constant	k118	94
.constant	k119	86
.constant	k120	44
.constant	k121	217
.constant	k122	67
.constant	k123	157
.constant	k124	"LoopScrollBox_Ver"
.constant	k125	"LoopScrollBox_0"
.constant	k126	97
.constant	k127	175
.constant	k128	119
.constant	k129	35
.constant	k130	9
.constant	k131	130
.constant	k132	63
.constant	k133	189
.constant	k134	203
.constant	k135	202
.constant	k136	72
.constant	k137	107
.constant	k138	61
.constant	k139	235
.constant	k140	133
.constant	k141	150
.constant	k142	50
.constant	k143	"ModuleManager"
.constant	k144	"GetModule"
.constant	k145	"CommonModuleConfig"
.constant	k146	"UIComponentModule"
.constant	k147	"Download_List_Interface_UIBP"
.constant	k148	"InitWithParentComponent"
.constant	k149	"Config"
.constant	k150	"Download_Fit_Lobby_UIBP"
.constant	k151	"showDownloadAll"
.constant	k152	"HDmpveRemote"
.constant	k153	"HDmpveRemoteConfigGetBool"
.constant	k154	208
.constant	k155	39
.constant	k156	22
.constant	k157	233
.constant	k158	11
.constant	k159	240
.constant	k160	236
.constant	k161	105
.constant	k162	199
.constant	k163	243
.constant	k164	153
.constant	k165	114
.constant	k166	160
.constant	k167	204
.constant	k168	8
.constant	k169	129
.constant	k170	191
.constant	k171	115
.constant	k172	99
.constant	k173	37
.constant	k174	"SetWidgetVisible"
.constant	k175	"WidgetSwitcher_SmartDownload"
.constant	k176	"isFitVersion"
.constant	k177	"math"
.constant	k178	"floor"
.constant	k179	"GetFitVerAutoDownloadedSize"
.constant	k180	"LocalizeResFormat"
.constant	k181	33020415
.constant	k182	"TextBlock_22"
.constant	k183	"GetIsDisableFitIconAutoDownload"
.constant	k184	320075
.constant	k185	"GetDownloadShowIconCheckBox"
.constant	k186	"Button_IconAutoHelp"
.constant	k187	"showDownloadIconCheckBox"
.constant	k188	"CanvasPanel_IconAutoSet"
.constant	k189	"Border_0"
.constant	k190	"vng18IconUI"
.constant	k191	"require"
.constant	k192	70
.constant	k193	194
.constant	k194	196
.constant	k195	104
.constant	k196	111
.constant	k197	187
.constant	k198	228
.constant	k199	"InitChildWindow18Logo"
.constant	k200	121
.constant	k201	209
.constant	k202	38
.constant	k203	25
.constant	k204	173
.constant	k205	197
.constant	k206	3
.constant	k207	0
.constant	k208	-300
.constant	k209	-20
.constant	k210	100
.constant	k211	"GameStatus"
.constant	k212	"IsInMainCity"
.constant	k213	"EventSystem"
.constant	k214	"postEvent"
.constant	k215	"EVENTTYPE_MAINCITY"
.constant	k216	"EVENTID_MAINCITY_NEWBIE_GUIDE_INTERRUPT"

.line	126	gettabup      r1    u0    k0 ; k0 = "log"
.line	126	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	126	test          r2     0
.line	126	jmp            0   l40
.line	126	getupval      r2    u1
.line	126	loadk         r3    k2 ; k2 = 126
.line	126	loadk         r4    k3 ; k3 = 69
.line	126	loadk         r5    k4 ; k4 = 200
.line	126	loadk         r6    k5 ; k5 = 62
.line	126	loadk         r7    k6 ; k6 = 20
.line	126	loadk         r8    k7 ; k7 = 56
.line	126	loadk         r9    k8 ; k8 = 231
.line	126	loadk        r10    k9 ; k9 = 14
.line	126	loadk        r11   k10 ; k10 = 156
.line	126	loadk        r12   k11 ; k11 = 226
.line	126	loadk        r13    k4 ; k4 = 200
.line	126	loadk        r14   k12 ; k12 = 110
.line	126	loadk        r15   k13 ; k13 = 92
.line	126	loadk        r16   k14 ; k14 = 6
.line	126	loadk        r17   k15 ; k15 = 254
.line	126	loadk        r18   k16 ; k16 = 223
.line	126	loadk        r19   k17 ; k17 = 136
.line	126	loadk        r20   k18 ; k18 = 74
.line	126	loadk        r21   k19 ; k19 = 245
.line	126	loadk        r22   k20 ; k20 = 47
.line	126	loadk        r23   k21 ; k21 = 230
.line	126	loadk        r24   k22 ; k22 = 46
.line	126	loadk        r25   k23 ; k23 = 152
.line	126	loadk        r26   k24 ; k24 = 51
.line	126	loadk        r27   k25 ; k25 = 167
.line	126	loadk        r28   k26 ; k26 = 214
.line	126	loadk        r29   k27 ; k27 = 216
.line	126	loadk        r30   k28 ; k28 = 123
.line	126	loadk        r31   k29 ; k29 = 75
.line	126	loadk        r32   k24 ; k24 = 51
.line	126	loadk        r33   k30 ; k30 = 222
.line	126	loadk        r34   k31 ; k31 = 168
.line	126	loadk        r35   k32 ; k32 = 250
.line	126	call          r2    34     2
.label	l40
.line	126	call          r1     2     1
.line	126	gettable      r1    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r1    r1   k34 ; k34 = "TextBlock_7"
.line	126	self          r1    r1   k35 ; k35 = "SetText"
.line	126	gettabup      r3    u0   k36 ; k36 = "LocUtil"
.line	126	gettable      r3    r3   k37 ; k37 = "GetLocalizeResStr"
.line	126	loadk         r4   k38 ; k38 = 83200
.line	126	call          r3     2     0
.line	126	call          r1     0     1
.line	126	gettable      r1    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r1    r1   k39 ; k39 = "TextBlock_1"
.line	126	self          r1    r1   k35 ; k35 = "SetText"
.line	126	gettabup      r3    u0   k36 ; k36 = "LocUtil"
.line	126	gettable      r3    r3   k37 ; k37 = "GetLocalizeResStr"
.line	126	loadk         r4   k40 ; k40 = 9413
.line	126	call          r3     2     0
.line	126	call          r1     0     1
.line	126	gettable      r1    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r1    r1   k41 ; k41 = "TextBlock_18"
.line	126	self          r1    r1   k35 ; k35 = "SetText"
.line	126	gettabup      r3    u0   k36 ; k36 = "LocUtil"
.line	126	gettable      r3    r3   k37 ; k37 = "GetLocalizeResStr"
.line	126	loadk         r4   k42 ; k42 = 11685
.line	126	call          r3     2     0
.line	126	call          r1     0     1
.line	126	gettable      r1    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r1    r1   k43 ; k43 = "TextBlock_102"
.line	126	self          r1    r1   k35 ; k35 = "SetText"
.line	126	gettabup      r3    u0   k36 ; k36 = "LocUtil"
.line	126	gettable      r3    r3   k37 ; k37 = "GetLocalizeResStr"
.line	126	loadk         r4   k44 ; k44 = 8500428
.line	126	call          r3     2     0
.line	126	call          r1     0     1
.line	126	gettable      r1    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r1    r1   k45 ; k45 = "TextBlock_4"
.line	126	self          r1    r1   k35 ; k35 = "SetText"
.line	126	gettabup      r3    u0   k36 ; k36 = "LocUtil"
.line	126	gettable      r3    r3   k37 ; k37 = "GetLocalizeResStr"
.line	126	loadk         r4   k46 ; k46 = 7510
.line	126	call          r3     2     0
.line	126	call          r1     0     1
.line	126	gettable      r1    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r1    r1   k47 ; k47 = "TextBlock_139"
.line	126	self          r1    r1   k35 ; k35 = "SetText"
.line	126	gettabup      r3    u0   k36 ; k36 = "LocUtil"
.line	126	gettable      r3    r3   k37 ; k37 = "GetLocalizeResStr"
.line	126	loadk         r4   k48 ; k48 = 83211
.line	126	call          r3     2     0
.line	126	call          r1     0     1
.line	126	gettable      r1    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r1    r1   k49 ; k49 = "TextBlock_0"
.line	126	self          r1    r1   k35 ; k35 = "SetText"
.line	126	gettabup      r3    u0   k36 ; k36 = "LocUtil"
.line	126	gettable      r3    r3   k37 ; k37 = "GetLocalizeResStr"
.line	126	loadk         r4   k50 ; k50 = 83210
.line	126	call          r3     2     0
.line	126	call          r1     0     1
.line	126	gettable      r1    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r1    r1   k51 ; k51 = "TextBlock_10"
.line	126	self          r1    r1   k35 ; k35 = "SetText"
.line	126	gettabup      r3    u0   k36 ; k36 = "LocUtil"
.line	126	gettable      r3    r3   k37 ; k37 = "GetLocalizeResStr"
.line	126	loadk         r4   k52 ; k52 = 83244
.line	126	call          r3     2     0
.line	126	call          r1     0     1
.line	126	gettable      r1    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r1    r1   k53 ; k53 = "TextBlock_5"
.line	126	self          r1    r1   k35 ; k35 = "SetText"
.line	126	gettabup      r3    u0   k36 ; k36 = "LocUtil"
.line	126	gettable      r3    r3   k37 ; k37 = "GetLocalizeResStr"
.line	126	loadk         r4   k54 ; k54 = 83234
.line	126	call          r3     2     0
.line	126	call          r1     0     1
.line	126	gettable      r1    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r1    r1   k51 ; k51 = "TextBlock_10"
.line	126	self          r1    r1   k35 ; k35 = "SetText"
.line	126	gettabup      r3    u0   k36 ; k36 = "LocUtil"
.line	126	gettable      r3    r3   k37 ; k37 = "GetLocalizeResStr"
.line	126	loadk         r4   k55 ; k55 = 83245
.line	126	call          r3     2     0
.line	126	call          r1     0     1
.line	126	gettable      r1    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r1    r1   k56 ; k56 = "TextBlock_2"
.line	126	self          r1    r1   k35 ; k35 = "SetText"
.line	126	gettabup      r3    u0   k36 ; k36 = "LocUtil"
.line	126	gettable      r3    r3   k37 ; k37 = "GetLocalizeResStr"
.line	126	loadk         r4   k57 ; k57 = 83247
.line	126	call          r3     2     0
.line	126	call          r1     0     1
.line	126	gettable      r1    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r1    r1   k58 ; k58 = "Download_Main_Tips_U" (truncated)
.line	126	gettable      r1    r1   k49 ; k49 = "TextBlock_0"
.line	126	self          r1    r1   k35 ; k35 = "SetText"
.line	126	gettabup      r3    u0   k36 ; k36 = "LocUtil"
.line	126	gettable      r3    r3   k37 ; k37 = "GetLocalizeResStr"
.line	126	loadk         r4   k59 ; k59 = 8800607
.line	126	call          r3     2     0
.line	126	call          r1     0     1
.line	126	self          r1    r0   k61 ; k61 = "InitHorizontalLevelO" (truncated)
.line	126	gettable      r3    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r3    r3   k60 ; k60 = "Common_Tab_Horizonta" (truncated)
.line	126	call          r1     3     2
.line	126	settable      r0   k60    r1 ; k60 = "Common_Tab_Horizonta" (truncated)
.line	126	self          r1    r0   k63 ; k63 = "InitVerticalTextTab"
.line	126	gettable      r3    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r3    r3   k62 ; k62 = "Common_Tab_Vertical_" (truncated)
.line	126	loadbool      r4     1     0
.line	126	loadbool      r5     1     0
.line	126	call          r1     5     2
.line	126	settable      r0   k62    r1 ; k62 = "Common_Tab_Vertical_" (truncated)
.line	126	self          r1    r0   k65 ; k65 = "InitChildClassScroll" (truncated)
.line	126	gettable      r3    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r3    r3   k66 ; k66 = "LoopScrollBox_1"
.line	126	gettabup      r4    u0   k67 ; k67 = "table"
.line	126	gettable      r4    r4   k68 ; k68 = "concat"
.line	126	newtable      r5     1     0
.line	126	getupval      r6    u1
.line	126	loadk         r7   k69 ; k69 = 125
.line	126	loadk         r8   k29 ; k29 = 75
.line	126	loadk         r9   k70 ; k70 = 210
.line	126	loadk        r10   k71 ; k71 = 53
.line	126	loadk        r11   k72 ; k72 = 52
.line	126	loadk        r12   k73 ; k73 = 34
.line	126	loadk        r13    k8 ; k8 = 231
.line	126	loadk        r14   k74 ; k74 = 68
.line	126	loadk        r15   k75 ; k75 = 142
.line	126	loadk        r16   k76 ; k76 = 192
.line	126	loadk        r17   k77 ; k77 = 205
.line	126	loadk        r18   k78 ; k78 = 41
.line	126	loadk        r19    k2 ; k2 = 126
.line	126	loadk        r20   k79 ; k79 = 54
.line	126	loadk        r21   k80 ; k80 = 201
.line	126	loadk        r22   k81 ; k81 = 244
.line	126	loadk        r23   k82 ; k82 = 179
.line	126	loadk        r24   k72 ; k72 = 52
.line	126	loadk        r25   k83 ; k83 = 141
.line	126	loadk        r26   k84 ; k84 = 1
.line	126	loadk        r27   k85 ; k85 = 251
.line	126	loadk        r28   k86 ; k86 = 2
.line	126	loadk        r29   k27 ; k27 = 216
.line	126	loadk        r30   k87 ; k87 = 30
.line	126	loadk        r31   k88 ; k88 = 188
.line	126	loadk        r32    k4 ; k4 = 200
.line	126	loadk        r33   k89 ; k89 = 215
.line	126	loadk        r34   k28 ; k28 = 123
.line	126	loadk        r35   k90 ; k90 = 77
.line	126	loadk        r36   k91 ; k91 = 40
.line	126	loadk        r37   k16 ; k16 = 223
.line	126	loadk        r38   k92 ; k92 = 227
.line	126	loadk        r39   k31 ; k31 = 168
.line	126	loadk        r40   k93 ; k93 = 36
.line	126	loadk        r41   k94 ; k94 = 170
.line	126	loadk        r42   k95 ; k95 = 29
.line	126	loadk        r43   k96 ; k96 = 255
.line	126	loadk        r44   k97 ; k97 = 89
.line	126	loadk        r45   k98 ; k98 = 143
.line	126	loadk        r46    k5 ; k5 = 62
.line	126	call          r6    41     2
.line	126	getupval      r7    u1
.line	126	loadk         r8   k99 ; k99 = 95
.line	126	loadk         r9  k100 ; k100 = 71
.line	126	loadk        r10  k101 ; k101 = 145
.line	126	loadk        r11    k6 ; k6 = 20
.line	126	loadk        r12  k102 ; k102 = 23
.line	126	loadk        r13  k103 ; k103 = 32
.line	126	loadk        r14  k104 ; k104 = 232
.line	126	loadk        r15   k14 ; k14 = 6
.line	126	loadk        r16  k105 ; k105 = 172
.line	126	loadk        r17  k106 ; k106 = 206
.line	126	loadk        r18   k77 ; k77 = 205
.line	126	loadk        r19  k107 ; k107 = 88
.line	126	loadk        r20    k2 ; k2 = 126
.line	126	loadk        r21  k108 ; k108 = 48
.line	126	loadk        r22   k27 ; k27 = 216
.line	126	loadk        r23   k11 ; k11 = 226
.line	126	loadk        r24  k109 ; k109 = 149
.line	126	loadk        r25  k110 ; k110 = 83
.line	126	loadk        r26  k111 ; k111 = 161
.line	126	loadk        r27    k6 ; k6 = 20
.line	126	loadk        r28  k112 ; k112 = 237
.line	126	loadk        r29  k113 ; k113 = 21
.line	126	loadk        r30  k114 ; k114 = 144
.line	126	loadk        r31  k115 ; k115 = 59
.line	126	loadk        r32  k116 ; k116 = 176
.line	126	loadk        r33  k117 ; k117 = 218
.line	126	loadk        r34   k21 ; k21 = 230
.line	126	loadk        r35  k118 ; k118 = 94
.line	126	loadk        r36  k119 ; k119 = 86
.line	126	loadk        r37  k120 ; k120 = 44
.line	126	loadk        r38   k26 ; k26 = 214
.line	126	loadk        r39  k121 ; k121 = 217
.line	126	loadk        r40   k98 ; k98 = 143
.line	126	loadk        r41  k122 ; k122 = 67
.line	126	loadk        r42  k123 ; k123 = 157
.line	126	loadk        r43  k103 ; k103 = 32
.line	126	call          r7    37     0
.line	126	setlist       r5     0     1
.line	126	call          r4     2     2
.line	126	call          r1     4     2
.line	126	settable      r0   k64    r1 ; k64 = "LoopScrollBox_Hor"
.line	126	self          r1    r0   k65 ; k65 = "InitChildClassScroll" (truncated)
.line	126	gettable      r3    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r3    r3  k125 ; k125 = "LoopScrollBox_0"
.line	126	gettabup      r4    u0   k67 ; k67 = "table"
.line	126	gettable      r4    r4   k68 ; k68 = "concat"
.line	126	newtable      r5     1     0
.line	126	getupval      r6    u1
.line	126	loadk         r7   k69 ; k69 = 125
.line	126	loadk         r8   k29 ; k29 = 75
.line	126	loadk         r9   k70 ; k70 = 210
.line	126	loadk        r10   k71 ; k71 = 53
.line	126	loadk        r11   k72 ; k72 = 52
.line	126	loadk        r12   k73 ; k73 = 34
.line	126	loadk        r13    k8 ; k8 = 231
.line	126	loadk        r14   k74 ; k74 = 68
.line	126	loadk        r15   k75 ; k75 = 142
.line	126	loadk        r16   k76 ; k76 = 192
.line	126	loadk        r17   k77 ; k77 = 205
.line	126	loadk        r18   k78 ; k78 = 41
.line	126	loadk        r19    k2 ; k2 = 126
.line	126	loadk        r20   k79 ; k79 = 54
.line	126	loadk        r21   k80 ; k80 = 201
.line	126	loadk        r22   k81 ; k81 = 244
.line	126	loadk        r23   k82 ; k82 = 179
.line	126	loadk        r24   k72 ; k72 = 52
.line	126	loadk        r25   k83 ; k83 = 141
.line	126	loadk        r26   k84 ; k84 = 1
.line	126	loadk        r27   k85 ; k85 = 251
.line	126	loadk        r28   k86 ; k86 = 2
.line	126	loadk        r29   k27 ; k27 = 216
.line	126	loadk        r30   k87 ; k87 = 30
.line	126	loadk        r31   k88 ; k88 = 188
.line	126	loadk        r32    k4 ; k4 = 200
.line	126	loadk        r33   k89 ; k89 = 215
.line	126	loadk        r34   k28 ; k28 = 123
.line	126	loadk        r35   k90 ; k90 = 77
.line	126	loadk        r36   k91 ; k91 = 40
.line	126	loadk        r37   k16 ; k16 = 223
.line	126	loadk        r38   k92 ; k92 = 227
.line	126	loadk        r39   k31 ; k31 = 168
.line	126	loadk        r40   k93 ; k93 = 36
.line	126	loadk        r41   k94 ; k94 = 170
.line	126	loadk        r42   k95 ; k95 = 29
.line	126	loadk        r43   k96 ; k96 = 255
.line	126	loadk        r44   k97 ; k97 = 89
.line	126	loadk        r45   k98 ; k98 = 143
.line	126	loadk        r46    k5 ; k5 = 62
.line	126	call          r6    41     2
.line	126	getupval      r7    u1
.line	126	loadk         r8   k99 ; k99 = 95
.line	126	loadk         r9  k100 ; k100 = 71
.line	126	loadk        r10  k101 ; k101 = 145
.line	126	loadk        r11    k6 ; k6 = 20
.line	126	loadk        r12  k102 ; k102 = 23
.line	126	loadk        r13  k103 ; k103 = 32
.line	126	loadk        r14  k104 ; k104 = 232
.line	126	loadk        r15   k14 ; k14 = 6
.line	126	loadk        r16  k105 ; k105 = 172
.line	126	loadk        r17  k106 ; k106 = 206
.line	126	loadk        r18   k77 ; k77 = 205
.line	126	loadk        r19  k107 ; k107 = 88
.line	126	loadk        r20  k126 ; k126 = 97
.line	126	loadk        r21  k103 ; k103 = 32
.line	126	loadk        r22   k27 ; k27 = 216
.line	126	loadk        r23   k11 ; k11 = 226
.line	126	loadk        r24  k127 ; k127 = 175
.line	126	loadk        r25  k128 ; k128 = 119
.line	126	loadk        r26  k114 ; k114 = 144
.line	126	loadk        r27  k129 ; k129 = 35
.line	126	loadk        r28    k8 ; k8 = 231
.line	126	loadk        r29  k130 ; k130 = 9
.line	126	loadk        r30  k131 ; k131 = 130
.line	126	loadk        r31  k132 ; k132 = 63
.line	126	loadk        r32  k133 ; k133 = 189
.line	126	loadk        r33  k134 ; k134 = 203
.line	126	loadk        r34  k135 ; k135 = 202
.line	126	loadk        r35  k136 ; k136 = 72
.line	126	loadk        r36  k137 ; k137 = 107
.line	126	loadk        r37  k138 ; k138 = 61
.line	126	loadk        r38   k30 ; k30 = 222
.line	126	loadk        r39  k139 ; k139 = 235
.line	126	loadk        r40  k140 ; k140 = 133
.line	126	loadk        r41   k99 ; k99 = 95
.line	126	loadk        r42  k141 ; k141 = 150
.line	126	loadk        r43  k142 ; k142 = 50
.line	126	loadk        r44    k4 ; k4 = 200
.line	126	call          r7    38     0
.line	126	setlist       r5     0     1
.line	126	call          r4     2     2
.line	126	call          r1     4     2
.line	126	settable      r0  k124    r1 ; k124 = "LoopScrollBox_Ver"
.line	126	gettabup      r1    u0  k143 ; k143 = "ModuleManager"
.line	126	gettable      r1    r1  k144 ; k144 = "GetModule"
.line	126	gettabup      r2    u0  k143 ; k143 = "ModuleManager"
.line	126	gettable      r2    r2  k145 ; k145 = "CommonModuleConfig"
.line	126	gettable      r2    r2  k146 ; k146 = "UIComponentModule"
.line	126	call          r1     2     2
.line	126	self          r2    r1  k148 ; k148 = "InitWithParentCompon" (truncated)
.line	126	move          r4    r0
.line	126	gettable      r5    r1  k149 ; k149 = "Config"
.line	126	gettable      r5    r5  k147 ; k147 = "Download_List_Interf" (truncated)
.line	126	gettable      r6    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r6    r6  k147 ; k147 = "Download_List_Interf" (truncated)
.line	126	call          r2     5     2
.line	126	settable      r0  k147    r2 ; k147 = "Download_List_Interf" (truncated)
.line	126	self          r2    r1  k148 ; k148 = "InitWithParentCompon" (truncated)
.line	126	move          r4    r0
.line	126	gettable      r5    r1  k149 ; k149 = "Config"
.line	126	gettable      r5    r5  k150 ; k150 = "Download_Fit_Lobby_U" (truncated)
.line	126	gettable      r6    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r6    r6  k150 ; k150 = "Download_Fit_Lobby_U" (truncated)
.line	126	call          r2     5     2
.line	126	settable      r0  k150    r2 ; k150 = "Download_Fit_Lobby_U" (truncated)
.line	126	gettabup      r2    u0  k152 ; k152 = "HDmpveRemote"
.line	126	gettable      r2    r2  k153 ; k153 = "HDmpveRemoteConfigGe" (truncated)
.line	126	getupval      r3    u1
.line	126	loadk         r4   k69 ; k69 = 125
.line	126	loadk         r5   k12 ; k12 = 110
.line	126	loadk         r6  k154 ; k154 = 208
.line	126	loadk         r7  k155 ; k155 = 39
.line	126	loadk         r8  k156 ; k156 = 22
.line	126	loadk         r9  k115 ; k115 = 59
.line	126	loadk        r10  k157 ; k157 = 233
.line	126	loadk        r11  k158 ; k158 = 11
.line	126	loadk        r12   k25 ; k25 = 167
.line	126	loadk        r13  k159 ; k159 = 240
.line	126	loadk        r14  k160 ; k160 = 236
.line	126	loadk        r15  k161 ; k161 = 105
.line	126	loadk        r16  k110 ; k110 = 83
.line	126	loadk        r17  k115 ; k115 = 59
.line	126	loadk        r18  k162 ; k162 = 199
.line	126	loadk        r19  k163 ; k163 = 243
.line	126	loadk        r20  k164 ; k164 = 153
.line	126	loadk        r21  k165 ; k165 = 114
.line	126	loadk        r22  k166 ; k166 = 160
.line	126	loadk        r23  k102 ; k102 = 23
.line	126	loadk        r24  k167 ; k167 = 204
.line	126	loadk        r25  k168 ; k168 = 8
.line	126	loadk        r26  k169 ; k169 = 129
.line	126	loadk        r27   k72 ; k72 = 52
.line	126	loadk        r28  k170 ; k170 = 191
.line	126	loadk        r29  k154 ; k154 = 208
.line	126	loadk        r30   k27 ; k27 = 216
.line	126	loadk        r31  k171 ; k171 = 115
.line	126	loadk        r32  k172 ; k172 = 99
.line	126	loadk        r33  k173 ; k173 = 37
.line	126	loadk        r34   k89 ; k89 = 215
.line	126	call          r3    32     2
.line	126	loadbool      r4     1     0
.line	126	call          r2     3     2
.line	126	settable      r0  k151    r2 ; k151 = "showDownloadAll"
.line	126	self          r2    r0  k174 ; k174 = "SetWidgetVisible"
.line	126	gettable      r4    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r4    r4  k175 ; k175 = "WidgetSwitcher_Smart" (truncated)
.line	126	gettable      r5    r0  k151 ; k151 = "showDownloadAll"
.line	126	call          r2     4     1
.line	126	loadbool      r2     0     0
.line	126	gettable      r3    r0  k176 ; k176 = "isFitVersion"
.line	126	test          r3     0
.line	126	jmp            0  l419
.line	126	gettabup      r3    u0  k177 ; k177 = "math"
.line	126	gettable      r3    r3  k178 ; k178 = "floor"
.line	126	gettabup      r4    u2  k179 ; k179 = "GetFitVerAutoDownloa" (truncated)
.line	126	call          r4     1     0
.line	126	call          r3     0     2
.line	126	gettabup      r4    u0   k36 ; k36 = "LocUtil"
.line	126	gettable      r4    r4  k180 ; k180 = "LocalizeResFormat"
.line	126	loadk         r5  k181 ; k181 = 33020415
.line	126	move          r6    r3
.line	126	call          r4     3     2
.line	126	gettable      r5    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r5    r5  k182 ; k182 = "TextBlock_22"
.line	126	self          r5    r5   k35 ; k35 = "SetText"
.line	126	move          r7    r4
.line	126	call          r5     3     1
.line	126	gettabup      r5    u2  k183 ; k183 = "GetIsDisableFitIconA" (truncated)
.line	126	call          r5     1     2
.line	126	not           r2    r5
.line	126	jmp            0  l436
.label	l419
.line	126	gettable      r3    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r3    r3  k182 ; k182 = "TextBlock_22"
.line	126	self          r3    r3   k35 ; k35 = "SetText"
.line	126	gettabup      r5    u0   k36 ; k36 = "LocUtil"
.line	126	gettable      r5    r5   k37 ; k37 = "GetLocalizeResStr"
.line	126	loadk         r6  k184 ; k184 = 320075
.line	126	call          r5     2     0
.line	126	call          r3     0     1
.line	126	gettabup      r3    u2  k185 ; k185 = "GetDownloadShowIconC" (truncated)
.line	126	call          r3     1     2
.line	126	move          r2    r3
.line	126	self          r3    r0  k174 ; k174 = "SetWidgetVisible"
.line	126	gettable      r5    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r5    r5  k186 ; k186 = "Button_IconAutoHelp"
.line	126	loadbool      r6     0     0
.line	126	loadbool      r7     1     0
.line	126	call          r3     5     1
.label	l436
.line	126	settable      r0  k187    r2 ; k187 = "showDownloadIconChec" (truncated)
.line	126	self          r3    r0  k174 ; k174 = "SetWidgetVisible"
.line	126	gettable      r5    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r5    r5  k188 ; k188 = "CanvasPanel_IconAuto" (truncated)
.line	126	move          r6    r2
.line	126	loadbool      r7     0     0
.line	126	call          r3     5     1
.line	126	self          r3    r0  k174 ; k174 = "SetWidgetVisible"
.line	126	gettable      r5    r0   k33 ; k33 = "UIRoot"
.line	126	gettable      r5    r5  k189 ; k189 = "Border_0"
.line	126	loadbool      r6     0     0
.line	126	call          r3     4     1
.line	126	gettable      r3    r0  k190 ; k190 = "vng18IconUI"
.line	126	test          r3     1
.line	126	jmp            0  l500
.line	126	gettabup      r3    u0  k191 ; k191 = "require"
.line	126	getupval      r4    u1
.line	126	loadk         r5   k97 ; k97 = 89
.line	126	loadk         r6  k192 ; k192 = 70
.line	126	loadk         r7   k26 ; k26 = 214
.line	126	loadk         r8   k71 ; k71 = 53
.line	126	loadk         r9  k156 ; k156 = 22
.line	126	loadk        r10  k129 ; k129 = 35
.line	126	loadk        r11   k31 ; k31 = 168
.line	126	loadk        r12  k130 ; k130 = 9
.line	126	loadk        r13  k105 ; k105 = 172
.line	126	loadk        r14  k193 ; k193 = 194
.line	126	loadk        r15  k194 ; k194 = 196
.line	126	loadk        r16  k195 ; k195 = 104
.line	126	loadk        r17   k13 ; k13 = 92
.line	126	loadk        r18  k128 ; k128 = 119
.line	126	loadk        r19   k30 ; k30 = 222
.line	126	loadk        r20   k96 ; k96 = 255
.line	126	loadk        r21  k109 ; k109 = 149
.line	126	loadk        r22  k196 ; k196 = 111
.line	126	loadk        r23  k197 ; k197 = 187
.line	126	loadk        r24  k130 ; k130 = 9
.line	126	loadk        r25  k198 ; k198 = 228
.line	126	call          r4    22     2
.line	126	call          r3     2     2
.line	126	gettable      r4    r3  k199 ; k199 = "InitChildWindow18Log" (truncated)
.line	126	move          r5    r0
.line	126	getupval      r6    u1
.line	126	loadk         r7  k200 ; k200 = 121
.line	126	loadk         r8   k29 ; k29 = 75
.line	126	loadk         r9  k201 ; k201 = 209
.line	126	loadk        r10  k202 ; k202 = 38
.line	126	loadk        r11  k203 ; k203 = 25
.line	126	loadk        r12   k93 ; k93 = 36
.line	126	loadk        r13   k26 ; k26 = 214
.line	126	loadk        r14  k158 ; k158 = 11
.line	126	loadk        r15  k204 ; k204 = 173
.line	126	loadk        r16  k135 ; k135 = 202
.line	126	loadk        r17  k205 ; k205 = 197
.line	126	loadk        r18  k107 ; k107 = 88
.line	126	loadk        r19  k206 ; k206 = 3
.line	126	call          r6    14     2
.line	126	loadk         r7   k84 ; k84 = 1
.line	126	loadk         r8  k207 ; k207 = 0
.line	126	loadk         r9  k208 ; k208 = -300
.line	126	loadk        r10  k209 ; k209 = -20
.line	126	loadk        r11  k210 ; k210 = 100
.line	126	call          r4     8     2
.line	126	settable      r0  k190    r4 ; k190 = "vng18IconUI"
.label	l500
.line	126	gettabup      r3    u0  k211 ; k211 = "GameStatus"
.line	126	gettable      r3    r3  k212 ; k212 = "IsInMainCity"
.line	126	call          r3     1     2
.line	126	test          r3     0
.line	126	jmp            0  l510
.line	126	gettabup      r3    u0  k213 ; k213 = "EventSystem"
.line	126	self          r3    r3  k214 ; k214 = "postEvent"
.line	126	gettabup      r5    u0  k215 ; k215 = "EVENTTYPE_MAINCITY"
.line	126	gettabup      r6    u0  k216 ; k216 = "EVENTID_MAINCITY_NEW" (truncated)
.line	126	call          r3     4     1
.label	l510
.line	126	return        r0     1
.line	126	gettabup      r0    u1   k33 ; k33 = "UIRoot"
.line	126	move          r0    r0
.line	126	return        r0     1

.function	main/f3

.source	null
.linedefined	172
.lastlinedefined	205
.numparams	1
.is_vararg	0
.maxstacksize	24

.upvalue	"_ENV"	1	true
.upvalue	"U1"	0	false

.constant	k0	"AddOnClickedEventByControl"
.constant	k1	"UIRoot"
.constant	k2	"Button_Download"
.constant	k3	"OnClickButton_Download"
.constant	k4	"Button_4"
.constant	k5	"OnClickToggleDownload"
.constant	k6	"Button_7"
.constant	k7	"OnClickShowCalcTip"
.constant	k8	"Button_3"
.constant	k9	"Button_0"
.constant	k10	"OnClickShowDownloadSetting"
.constant	k11	"Button_1"
.constant	k12	"OnClickBackToView"
.constant	k13	"Button_2"
.constant	k14	"Button_6"
.constant	k15	"OnClickRecommendReward"
.constant	k16	"Button_5"
.constant	k17	"OnClickButton_DeleteConfirm"
.constant	k18	"Button_8"
.constant	k19	"OnClickButton_DownloadAll"
.constant	k20	"Button_IconAutoHelp"
.constant	k21	"OnIconAutoHelpButtonClick"
.constant	k22	"Button_IconAutoSet"
.constant	k23	"OnIconAutoSetButtonClick"
.constant	k24	"AddControlEventByControl"
.constant	k25	"CheckBox_2"
.constant	k26	117
.constant	k27	68
.constant	k28	252
.constant	k29	56
.constant	k30	29
.constant	k31	52
.constant	k32	237
.constant	k33	57
.constant	k34	183
.constant	k35	206
.constant	k36	221
.constant	k37	98
.constant	k38	113
.constant	k39	49
.constant	k40	202
.constant	k41	248
.constant	k42	173
.constant	k43	127
.constant	k44	171
.constant	k45	"OnAutoDownloadCheckChanged"
.constant	k46	"CheckBox"
.constant	k47	"OnSelectAllChanged"
.constant	k48	"Download_List_Interface_UIBP"
.constant	k49	"Button_Downlaod"
.constant	k50	60
.constant	k51	17
.constant	k52	15
.constant	k53	167
.constant	k54	"OnClickItemButton_Downlaod"
.constant	k55	"Download_Fit_Lobby_UIBP"
.constant	k56	"Common_Tab_Horizontal_LevelOne_Text_UIBP"
.constant	k57	"AddOnClickedCallback"
.constant	k58	"OnClickedLevelOneTab"
.constant	k59	"Button_Close"
.constant	k60	"OnClickButton_Close"
.constant	k61	"Button_Delete"
.constant	k62	"OnClickButton_Delete"
.constant	k63	"Button_15"
.constant	k64	"Button_Setting"
.constant	k65	"OnClickButton_Setting"
.constant	k66	"AddTabLabelNumCallback"
.constant	k67	"OnHorizontalTabNumCallback"
.constant	k68	"Common_Tab_Vertical_LevelOne_Text_UIBP"
.constant	k69	"AddOnTabClickedCallback"
.constant	k70	"OnVerticalTextTabClickedCallback"
.constant	k71	"AddOnTabSelectedCallback"
.constant	k72	"OnVerticalTextTabSelectedCallback"
.constant	k73	"AddOnTabRefreshCallback"
.constant	k74	"OnVerticalTextTabRefreshCallback"
.constant	k75	"AddTabNumberCallback"
.constant	k76	"OnVerticalTabNumCallback"
.constant	k77	"Button_Help"
.constant	k78	"OnClickUGCAssetHubCacheHelp"
.constant	k79	"Button_9"
.constant	k80	"OnClickUGCAssetHub"
.constant	k81	"Button_11"
.constant	k82	"OnClickUGCMall"
.constant	k83	"AddCommonEvent"
.constant	k84	"EVENTTYPE_PUFFER"
.constant	k85	"EVENTID_PUFFER_CACHE_DIR_SIZE_COMPLETE"
.constant	k86	"UpdateGameSize"
.constant	k87	"EVENTTYPE_UGC"
.constant	k88	"EVENTID_ASSETHUB_CLEANUP"
.constant	k89	"OnCleanup"
.constant	k90	"EVENTID_ASSETHUB_DATA_UPDATE"

.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3    k2 ; k2 = "Button_Download"
.line	172	gettable      r4    r0    k3 ; k3 = "OnClickButton_Downlo" (truncated)
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3    k4 ; k4 = "Button_4"
.line	172	gettable      r4    r0    k5 ; k5 = "OnClickToggleDownloa" (truncated)
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3    k6 ; k6 = "Button_7"
.line	172	gettable      r4    r0    k7 ; k7 = "OnClickShowCalcTip"
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3    k8 ; k8 = "Button_3"
.line	172	gettable      r4    r0    k5 ; k5 = "OnClickToggleDownloa" (truncated)
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3    k9 ; k9 = "Button_0"
.line	172	gettable      r4    r0   k10 ; k10 = "OnClickShowDownloadS" (truncated)
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3   k11 ; k11 = "Button_1"
.line	172	gettable      r4    r0   k12 ; k12 = "OnClickBackToView"
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3   k13 ; k13 = "Button_2"
.line	172	gettable      r4    r0   k10 ; k10 = "OnClickShowDownloadS" (truncated)
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3   k14 ; k14 = "Button_6"
.line	172	gettable      r4    r0   k15 ; k15 = "OnClickRecommendRewa" (truncated)
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3   k16 ; k16 = "Button_5"
.line	172	gettable      r4    r0   k17 ; k17 = "OnClickButton_Delete" (truncated)
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3   k18 ; k18 = "Button_8"
.line	172	gettable      r4    r0   k19 ; k19 = "OnClickButton_Downlo" (truncated)
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3   k20 ; k20 = "Button_IconAutoHelp"
.line	172	gettable      r4    r0   k21 ; k21 = "OnIconAutoHelpButton" (truncated)
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3   k22 ; k22 = "Button_IconAutoSet"
.line	172	gettable      r4    r0   k23 ; k23 = "OnIconAutoSetButtonC" (truncated)
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	self          r1    r0   k24 ; k24 = "AddControlEventByCon" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3   k25 ; k25 = "CheckBox_2"
.line	172	getupval      r4    u0
.line	172	loadk         r5   k26 ; k26 = 117
.line	172	loadk         r6   k27 ; k27 = 68
.line	172	loadk         r7   k28 ; k28 = 252
.line	172	loadk         r8   k29 ; k29 = 56
.line	172	loadk         r9   k30 ; k30 = 29
.line	172	loadk        r10   k31 ; k31 = 52
.line	172	loadk        r11   k32 ; k32 = 237
.line	172	loadk        r12   k33 ; k33 = 57
.line	172	loadk        r13   k34 ; k34 = 183
.line	172	loadk        r14   k35 ; k35 = 206
.line	172	loadk        r15   k36 ; k36 = 221
.line	172	loadk        r16   k37 ; k37 = 98
.line	172	loadk        r17   k38 ; k38 = 113
.line	172	loadk        r18   k39 ; k39 = 49
.line	172	loadk        r19   k40 ; k40 = 202
.line	172	loadk        r20   k41 ; k41 = 248
.line	172	loadk        r21   k42 ; k42 = 173
.line	172	loadk        r22   k43 ; k43 = 127
.line	172	loadk        r23   k44 ; k44 = 171
.line	172	call          r4    20     2
.line	172	gettable      r5    r0   k45 ; k45 = "OnAutoDownloadCheckC" (truncated)
.line	172	move          r6    r0
.line	172	call          r1     6     1
.line	172	self          r1    r0   k24 ; k24 = "AddControlEventByCon" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3   k46 ; k46 = "CheckBox"
.line	172	getupval      r4    u0
.line	172	loadk         r5   k26 ; k26 = 117
.line	172	loadk         r6   k27 ; k27 = 68
.line	172	loadk         r7   k28 ; k28 = 252
.line	172	loadk         r8   k29 ; k29 = 56
.line	172	loadk         r9   k30 ; k30 = 29
.line	172	loadk        r10   k31 ; k31 = 52
.line	172	loadk        r11   k32 ; k32 = 237
.line	172	loadk        r12   k33 ; k33 = 57
.line	172	loadk        r13   k34 ; k34 = 183
.line	172	loadk        r14   k35 ; k35 = 206
.line	172	loadk        r15   k36 ; k36 = 221
.line	172	loadk        r16   k37 ; k37 = 98
.line	172	loadk        r17   k38 ; k38 = 113
.line	172	loadk        r18   k39 ; k39 = 49
.line	172	loadk        r19   k40 ; k40 = 202
.line	172	loadk        r20   k41 ; k41 = 248
.line	172	loadk        r21   k42 ; k42 = 173
.line	172	loadk        r22   k43 ; k43 = 127
.line	172	loadk        r23   k44 ; k44 = 171
.line	172	call          r4    20     2
.line	172	gettable      r5    r0   k47 ; k47 = "OnSelectAllChanged"
.line	172	move          r6    r0
.line	172	call          r1     6     1
.line	172	self          r1    r0   k24 ; k24 = "AddControlEventByCon" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3   k48 ; k48 = "Download_List_Interf" (truncated)
.line	172	gettable      r3    r3   k49 ; k49 = "Button_Downlaod"
.line	172	getupval      r4    u0
.line	172	loadk         r5   k26 ; k26 = 117
.line	172	loadk         r6   k27 ; k27 = 68
.line	172	loadk         r7   k28 ; k28 = 252
.line	172	loadk         r8   k50 ; k50 = 60
.line	172	loadk         r9   k51 ; k51 = 17
.line	172	loadk        r10   k31 ; k31 = 52
.line	172	loadk        r11   k32 ; k32 = 237
.line	172	loadk        r12   k52 ; k52 = 15
.line	172	loadk        r13   k53 ; k53 = 167
.line	172	call          r4    10     2
.line	172	gettable      r5    r0   k54 ; k54 = "OnClickItemButton_Do" (truncated)
.line	172	move          r6    r0
.line	172	call          r1     6     1
.line	172	self          r1    r0   k24 ; k24 = "AddControlEventByCon" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3   k55 ; k55 = "Download_Fit_Lobby_U" (truncated)
.line	172	gettable      r3    r3   k49 ; k49 = "Button_Downlaod"
.line	172	getupval      r4    u0
.line	172	loadk         r5   k26 ; k26 = 117
.line	172	loadk         r6   k27 ; k27 = 68
.line	172	loadk         r7   k28 ; k28 = 252
.line	172	loadk         r8   k50 ; k50 = 60
.line	172	loadk         r9   k51 ; k51 = 17
.line	172	loadk        r10   k31 ; k31 = 52
.line	172	loadk        r11   k32 ; k32 = 237
.line	172	loadk        r12   k52 ; k52 = 15
.line	172	loadk        r13   k53 ; k53 = 167
.line	172	call          r4    10     2
.line	172	gettable      r5    r0   k54 ; k54 = "OnClickItemButton_Do" (truncated)
.line	172	move          r6    r0
.line	172	call          r1     6     1
.line	172	gettable      r1    r0   k56 ; k56 = "Common_Tab_Horizonta" (truncated)
.line	172	self          r1    r1   k57 ; k57 = "AddOnClickedCallback"
.line	172	gettable      r3    r0   k58 ; k58 = "OnClickedLevelOneTab"
.line	172	move          r4    r0
.line	172	call          r1     4     1
.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3   k59 ; k59 = "Button_Close"
.line	172	gettable      r4    r0   k60 ; k60 = "OnClickButton_Close"
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3   k61 ; k61 = "Button_Delete"
.line	172	gettable      r4    r0   k62 ; k62 = "OnClickButton_Delete"
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3   k63 ; k63 = "Button_15"
.line	172	gettable      r4    r0   k62 ; k62 = "OnClickButton_Delete"
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3   k64 ; k64 = "Button_Setting"
.line	172	gettable      r4    r0   k65 ; k65 = "OnClickButton_Settin" (truncated)
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	gettable      r1    r0   k56 ; k56 = "Common_Tab_Horizonta" (truncated)
.line	172	self          r1    r1   k66 ; k66 = "AddTabLabelNumCallba" (truncated)
.line	172	gettable      r3    r0   k67 ; k67 = "OnHorizontalTabNumCa" (truncated)
.line	172	move          r4    r0
.line	172	call          r1     4     1
.line	172	gettable      r1    r0   k68 ; k68 = "Common_Tab_Vertical_" (truncated)
.line	172	self          r1    r1   k69 ; k69 = "AddOnTabClickedCallb" (truncated)
.line	172	gettable      r3    r0   k70 ; k70 = "OnVerticalTextTabCli" (truncated)
.line	172	move          r4    r0
.line	172	call          r1     4     1
.line	172	gettable      r1    r0   k68 ; k68 = "Common_Tab_Vertical_" (truncated)
.line	172	self          r1    r1   k71 ; k71 = "AddOnTabSelectedCall" (truncated)
.line	172	gettable      r3    r0   k72 ; k72 = "OnVerticalTextTabSel" (truncated)
.line	172	move          r4    r0
.line	172	call          r1     4     1
.line	172	gettable      r1    r0   k68 ; k68 = "Common_Tab_Vertical_" (truncated)
.line	172	self          r1    r1   k73 ; k73 = "AddOnTabRefreshCallb" (truncated)
.line	172	gettable      r3    r0   k74 ; k74 = "OnVerticalTextTabRef" (truncated)
.line	172	move          r4    r0
.line	172	call          r1     4     1
.line	172	gettable      r1    r0   k68 ; k68 = "Common_Tab_Vertical_" (truncated)
.line	172	self          r1    r1   k75 ; k75 = "AddTabNumberCallback"
.line	172	gettable      r3    r0   k76 ; k76 = "OnVerticalTabNumCall" (truncated)
.line	172	move          r4    r0
.line	172	call          r1     4     1
.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3   k77 ; k77 = "Button_Help"
.line	172	gettable      r4    r0   k78 ; k78 = "OnClickUGCAssetHubCa" (truncated)
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3   k79 ; k79 = "Button_9"
.line	172	gettable      r4    r0   k80 ; k80 = "OnClickUGCAssetHub"
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	172	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	172	gettable      r3    r3   k81 ; k81 = "Button_11"
.line	172	gettable      r4    r0   k82 ; k82 = "OnClickUGCMall"
.line	172	move          r5    r0
.line	172	call          r1     5     1
.line	172	self          r1    r0   k83 ; k83 = "AddCommonEvent"
.line	172	gettabup      r3    u1   k84 ; k84 = "EVENTTYPE_PUFFER"
.line	172	gettabup      r4    u1   k85 ; k85 = "EVENTID_PUFFER_CACHE" (truncated)
.line	172	gettable      r5    r0   k86 ; k86 = "UpdateGameSize"
.line	172	move          r6    r0
.line	172	call          r1     6     1
.line	172	self          r1    r0   k83 ; k83 = "AddCommonEvent"
.line	172	gettabup      r3    u1   k87 ; k87 = "EVENTTYPE_UGC"
.line	172	gettabup      r4    u1   k88 ; k88 = "EVENTID_ASSETHUB_CLE" (truncated)
.line	172	gettable      r5    r0   k89 ; k89 = "OnCleanup"
.line	172	move          r6    r0
.line	172	call          r1     6     1
.line	172	self          r1    r0   k83 ; k83 = "AddCommonEvent"
.line	172	gettabup      r3    u1   k87 ; k87 = "EVENTTYPE_UGC"
.line	172	gettabup      r4    u1   k90 ; k90 = "EVENTID_ASSETHUB_DAT" (truncated)
.line	172	gettable      r5    r0   k89 ; k89 = "OnCleanup"
.line	172	move          r6    r0
.line	172	call          r1     6     1
.line	172	return        r0     1
.line	172	move          r0    r0
.line	172	move          r0    r0
.line	172	return        r0     1

.function	main/f4

.source	null
.linedefined	207
.lastlinedefined	213
.numparams	1
.is_vararg	0
.maxstacksize	40

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	126
.constant	k3	69
.constant	k4	200
.constant	k5	62
.constant	k6	20
.constant	k7	56
.constant	k8	231
.constant	k9	14
.constant	k10	156
.constant	k11	226
.constant	k12	110
.constant	k13	92
.constant	k14	6
.constant	k15	254
.constant	k16	223
.constant	k17	136
.constant	k18	74
.constant	k19	245
.constant	k20	47
.constant	k21	230
.constant	k22	55
.constant	k23	153
.constant	k24	41
.constant	k25	167
.constant	k26	246
.constant	k27	215
.constant	k28	86
.constant	k29	32
.constant	k30	218
.constant	k31	234
.constant	k32	179
.constant	k33	112
.constant	k34	186
.constant	k35	94
.constant	k36	184
.constant	k37	"InitTabData"
.constant	k38	"UpdateUIType"
.constant	k39	"uiType"
.constant	k40	"UpdateUI"
.constant	k41	"CheckShowGuideTips"

.line	207	gettabup      r1    u0    k0 ; k0 = "log"
.line	207	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	207	test          r2     0
.line	207	jmp            0   l44
.line	207	getupval      r2    u1
.line	207	loadk         r3    k2 ; k2 = 126
.line	207	loadk         r4    k3 ; k3 = 69
.line	207	loadk         r5    k4 ; k4 = 200
.line	207	loadk         r6    k5 ; k5 = 62
.line	207	loadk         r7    k6 ; k6 = 20
.line	207	loadk         r8    k7 ; k7 = 56
.line	207	loadk         r9    k8 ; k8 = 231
.line	207	loadk        r10    k9 ; k9 = 14
.line	207	loadk        r11   k10 ; k10 = 156
.line	207	loadk        r12   k11 ; k11 = 226
.line	207	loadk        r13    k4 ; k4 = 200
.line	207	loadk        r14   k12 ; k12 = 110
.line	207	loadk        r15   k13 ; k13 = 92
.line	207	loadk        r16   k14 ; k14 = 6
.line	207	loadk        r17   k15 ; k15 = 254
.line	207	loadk        r18   k16 ; k16 = 223
.line	207	loadk        r19   k17 ; k17 = 136
.line	207	loadk        r20   k18 ; k18 = 74
.line	207	loadk        r21   k19 ; k19 = 245
.line	207	loadk        r22   k20 ; k20 = 47
.line	207	loadk        r23   k21 ; k21 = 230
.line	207	loadk        r24   k22 ; k22 = 55
.line	207	loadk        r25   k23 ; k23 = 153
.line	207	loadk        r26   k24 ; k24 = 41
.line	207	loadk        r27   k25 ; k25 = 167
.line	207	loadk        r28   k26 ; k26 = 246
.line	207	loadk        r29   k27 ; k27 = 215
.line	207	loadk        r30    k2 ; k2 = 126
.line	207	loadk        r31   k28 ; k28 = 86
.line	207	loadk        r32   k29 ; k29 = 32
.line	207	loadk        r33   k30 ; k30 = 218
.line	207	loadk        r34   k31 ; k31 = 234
.line	207	loadk        r35   k32 ; k32 = 179
.line	207	loadk        r36   k33 ; k33 = 112
.line	207	loadk        r37   k34 ; k34 = 186
.line	207	loadk        r38   k35 ; k35 = 94
.line	207	loadk        r39   k36 ; k36 = 184
.line	207	call          r2    38     2
.label	l44
.line	207	call          r1     2     1
.line	207	self          r1    r0   k37 ; k37 = "InitTabData"
.line	207	call          r1     2     1
.line	207	self          r1    r0   k38 ; k38 = "UpdateUIType"
.line	207	gettable      r3    r0   k39 ; k39 = "uiType"
.line	207	call          r1     3     1
.line	207	self          r1    r0   k40 ; k40 = "UpdateUI"
.line	207	call          r1     2     1
.line	207	self          r1    r0   k41 ; k41 = "CheckShowGuideTips"
.line	207	call          r1     2     1
.line	207	return        r0     1
.line	207	move          r0    r0
.line	207	move          r0    r0
.line	207	return        r0     1

.function	main/f5

.source	null
.linedefined	215
.lastlinedefined	228
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	2	true
.upvalue	"U2"	1	true

.constant	k0	"UIManager"
.constant	k1	"CloseUI"
.constant	k2	"UI_Config"
.constant	k3	"Download_Loading_Item_UIBP"
.constant	k4	"Download_Delete_Progress_UIBP"
.constant	k5	"__super"
.constant	k6	"OnClose"
.constant	k7	"require"
.constant	k8	"table"
.constant	k9	"concat"
.constant	k10	125
.constant	k11	75
.constant	k12	210
.constant	k13	53
.constant	k14	52
.constant	k15	34
.constant	k16	231
.constant	k17	68
.constant	k18	142
.constant	k19	192
.constant	k20	205
.constant	k21	41
.constant	k22	126
.constant	k23	54
.constant	k24	201
.constant	k25	244
.constant	k26	179
.constant	k27	156
.constant	k28	16
.constant	k29	228
.constant	k30	14
.constant	k31	130
.constant	k32	116
.constant	k33	158
.constant	k34	208
.constant	k35	221
.constant	k36	114
.constant	k37	113
.constant	k38	44
.constant	k39	215
.constant	k40	227
.constant	k41	185
.constant	k42	182
.constant	k43	31
.constant	k44	246
.constant	k45	67
.constant	k46	209
.constant	k47	122
.constant	k48	20
.constant	k49	70
.constant	k50	55
.constant	k51	17
.constant	k52	168
.constant	k53	7
.constant	k54	172
.constant	k55	203
.constant	k56	204
.constant	k57	88
.constant	k58	48
.constant	k59	206
.constant	k60	225
.constant	k61	149
.constant	k62	108
.constant	k63	253
.constant	k64	63
.constant	k65	19
.constant	k66	159
.constant	k67	160
.constant	k68	"GetModeMainUIConfigDefault"
.constant	k69	"GetUI"
.constant	k70	"UpdateDownloadTips"
.constant	k71	"GameStatus"
.constant	k72	"IsInMainCity"
.constant	k73	"EventSystem"
.constant	k74	"postEvent"
.constant	k75	"EVENTTYPE_MAINCITY"
.constant	k76	"EVENTID_MAINCITY_NEWBIE_GUIDE_RESTORE"

.line	215	gettabup      r1    u0    k0 ; k0 = "UIManager"
.line	215	gettable      r1    r1    k1 ; k1 = "CloseUI"
.line	215	gettabup      r2    u0    k0 ; k0 = "UIManager"
.line	215	gettable      r2    r2    k2 ; k2 = "UI_Config"
.line	215	gettable      r2    r2    k3 ; k3 = "Download_Loading_Ite" (truncated)
.line	215	call          r1     2     1
.line	215	gettabup      r1    u0    k0 ; k0 = "UIManager"
.line	215	gettable      r1    r1    k1 ; k1 = "CloseUI"
.line	215	gettabup      r2    u0    k0 ; k0 = "UIManager"
.line	215	gettable      r2    r2    k2 ; k2 = "UI_Config"
.line	215	gettable      r2    r2    k4 ; k4 = "Download_Delete_Prog" (truncated)
.line	215	call          r1     2     1
.line	215	gettabup      r1    u1    k5 ; k5 = "__super"
.line	215	gettable      r1    r1    k6 ; k6 = "OnClose"
.line	215	move          r2    r0
.line	215	call          r1     2     1
.line	215	gettabup      r1    u0    k7 ; k7 = "require"
.line	215	gettabup      r2    u0    k8 ; k8 = "table"
.line	215	gettable      r2    r2    k9 ; k9 = "concat"
.line	215	newtable      r3     1     0
.line	215	getupval      r4    u2
.line	215	loadk         r5   k10 ; k10 = 125
.line	215	loadk         r6   k11 ; k11 = 75
.line	215	loadk         r7   k12 ; k12 = 210
.line	215	loadk         r8   k13 ; k13 = 53
.line	215	loadk         r9   k14 ; k14 = 52
.line	215	loadk        r10   k15 ; k15 = 34
.line	215	loadk        r11   k16 ; k16 = 231
.line	215	loadk        r12   k17 ; k17 = 68
.line	215	loadk        r13   k18 ; k18 = 142
.line	215	loadk        r14   k19 ; k19 = 192
.line	215	loadk        r15   k20 ; k20 = 205
.line	215	loadk        r16   k21 ; k21 = 41
.line	215	loadk        r17   k22 ; k22 = 126
.line	215	loadk        r18   k23 ; k23 = 54
.line	215	loadk        r19   k24 ; k24 = 201
.line	215	loadk        r20   k25 ; k25 = 244
.line	215	loadk        r21   k26 ; k26 = 179
.line	215	loadk        r22   k14 ; k14 = 52
.line	215	loadk        r23   k27 ; k27 = 156
.line	215	loadk        r24   k28 ; k28 = 16
.line	215	loadk        r25   k29 ; k29 = 228
.line	215	loadk        r26   k30 ; k30 = 14
.line	215	loadk        r27   k31 ; k31 = 130
.line	215	loadk        r28   k32 ; k32 = 116
.line	215	loadk        r29   k33 ; k33 = 158
.line	215	loadk        r30   k34 ; k34 = 208
.line	215	loadk        r31   k35 ; k35 = 221
.line	215	loadk        r32   k36 ; k36 = 114
.line	215	loadk        r33   k37 ; k37 = 113
.line	215	loadk        r34   k38 ; k38 = 44
.line	215	loadk        r35   k39 ; k39 = 215
.line	215	loadk        r36   k40 ; k40 = 227
.line	215	loadk        r37   k41 ; k41 = 185
.line	215	loadk        r38   k22 ; k22 = 126
.line	215	loadk        r39   k42 ; k42 = 182
.line	215	loadk        r40   k43 ; k43 = 31
.line	215	loadk        r41   k44 ; k44 = 246
.line	215	loadk        r42   k45 ; k45 = 67
.line	215	loadk        r43   k46 ; k46 = 209
.line	215	loadk        r44   k47 ; k47 = 122
.line	215	call          r4    41     2
.line	215	getupval      r5    u2
.line	215	loadk         r6   k48 ; k48 = 20
.line	215	loadk         r7   k49 ; k49 = 70
.line	215	loadk         r8   k34 ; k34 = 208
.line	215	loadk         r9   k50 ; k50 = 55
.line	215	loadk        r10   k51 ; k51 = 17
.line	215	loadk        r11   k14 ; k14 = 52
.line	215	loadk        r12   k52 ; k52 = 168
.line	215	loadk        r13   k53 ; k53 = 7
.line	215	loadk        r14   k54 ; k54 = 172
.line	215	loadk        r15   k55 ; k55 = 203
.line	215	loadk        r16   k56 ; k56 = 204
.line	215	loadk        r17   k57 ; k57 = 88
.line	215	loadk        r18   k17 ; k17 = 68
.line	215	loadk        r19   k58 ; k58 = 48
.line	215	loadk        r20   k59 ; k59 = 206
.line	215	loadk        r21   k60 ; k60 = 225
.line	215	loadk        r22   k61 ; k61 = 149
.line	215	loadk        r23   k62 ; k62 = 108
.line	215	loadk        r24   k63 ; k63 = 253
.line	215	loadk        r25   k64 ; k64 = 63
.line	215	loadk        r26   k63 ; k63 = 253
.line	215	loadk        r27   k65 ; k65 = 19
.line	215	loadk        r28   k66 ; k66 = 159
.line	215	loadk        r29   k23 ; k23 = 54
.line	215	loadk        r30   k67 ; k67 = 160
.line	215	call          r5    26     0
.line	215	setlist       r3     0     1
.line	215	call          r2     2     2
.line	215	call          r1     2     2
.line	215	gettable      r2    r1   k68 ; k68 = "GetModeMainUIConfigD" (truncated)
.line	215	call          r2     1     2
.line	215	gettabup      r3    u0    k0 ; k0 = "UIManager"
.line	215	gettable      r3    r3   k69 ; k69 = "GetUI"
.line	215	move          r4    r2
.line	215	call          r3     2     2
.line	215	test          r3     0
.line	215	jmp            0  l106
.line	215	gettable      r4    r3   k70 ; k70 = "UpdateDownloadTips"
.line	215	test          r4     0
.line	215	jmp            0  l106
.line	215	self          r4    r3   k70 ; k70 = "UpdateDownloadTips"
.line	215	call          r4     2     1
.label	l106
.line	215	gettabup      r4    u0   k71 ; k71 = "GameStatus"
.line	215	gettable      r4    r4   k72 ; k72 = "IsInMainCity"
.line	215	call          r4     1     2
.line	215	test          r4     0
.line	215	jmp            0  l116
.line	215	gettabup      r4    u0   k73 ; k73 = "EventSystem"
.line	215	self          r4    r4   k74 ; k74 = "postEvent"
.line	215	gettabup      r6    u0   k75 ; k75 = "EVENTTYPE_MAINCITY"
.line	215	gettabup      r7    u0   k76 ; k76 = "EVENTID_MAINCITY_NEW" (truncated)
.line	215	call          r4     4     1
.label	l116
.line	215	return        r0     1
.line	215	move          r0    r0
.line	215	move          r0    r0
.line	215	move          r0    r0
.line	215	move          r0    r0
.line	215	return        r0     1

.function	main/f6

.source	null
.linedefined	230
.lastlinedefined	272
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	9	true
.upvalue	"U3"	5	true
.upvalue	"U4"	22	true

.constant	k0	"GetPufferDeleteManager"
.constant	k1	"log"
.constant	k2	"bWriteLog"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	126
.constant	k6	69
.constant	k7	200
.constant	k8	62
.constant	k9	20
.constant	k10	56
.constant	k11	231
.constant	k12	14
.constant	k13	156
.constant	k14	226
.constant	k15	110
.constant	k16	92
.constant	k17	6
.constant	k18	254
.constant	k19	223
.constant	k20	136
.constant	k21	74
.constant	k22	245
.constant	k23	47
.constant	k24	230
.constant	k25	52
.constant	k26	158
.constant	k27	53
.constant	k28	164
.constant	k29	145
.constant	k30	153
.constant	k31	68
.constant	k32	75
.constant	k33	37
.constant	k34	222
.constant	k35	232
.constant	k36	174
.constant	k37	73
.constant	k38	179
.constant	k39	21
.constant	k40	249
.constant	k41	25
.constant	k42	147
.constant	k43	58
.constant	k44	26
.constant	k45	23
.constant	k46	159
.constant	k47	"tostring"
.constant	k48	"SilentCleanup"
.constant	k49	false
.constant	k50	"ShowNotice"
.constant	k51	83249
.constant	k52	"AutoDownloadCfg"
.constant	k53	"RecommendType"
.constant	k54	"Enum_RecommendType"
.constant	k55	"None"
.constant	k56	"GetRecommendIndex"
.constant	k57	"PlayUserWidgetAnimation"
.constant	k58	"UIRoot"
.constant	k59	"Fadein"
.constant	k60	0
.constant	k61	1
.constant	k62	"AddTimerLoop"
.constant	k63	"TIMER_INFINITE"
.constant	k64	"SaveAutoDownloadSetting"
.constant	k65	"SmartDownloadTipsCfg"
.constant	k66	"DownloadTipsShow"
.constant	k67	"require"
.constant	k68	89
.constant	k69	70
.constant	k70	214
.constant	k71	22
.constant	k72	35
.constant	k73	168
.constant	k74	175
.constant	k75	218
.constant	k76	41
.constant	k77	81
.constant	k78	54
.constant	k79	197
.constant	k80	240
.constant	k81	163
.constant	k82	125
.constant	k83	225
.constant	k84	228
.constant	k85	167
.constant	k86	242
.constant	k87	216
.constant	k88	116
.constant	k89	80
.constant	k90	38
.constant	k91	138
.constant	k92	127
.constant	k93	189
.constant	k94	28
.constant	k95	241
.constant	k96	4
.constant	k97	142
.constant	k98	24
.constant	k99	95
.constant	k100	77
.constant	k101	63
.constant	k102	9
.constant	k103	177
.constant	k104	192
.constant	k105	"IsFITVersion"
.constant	k106	true
.constant	k107	"SetWidgetVisible"
.constant	k108	"Download_Main_Tips_UIBP"
.constant	k109	"AddTimerOnce"
.constant	k110	"SaveSmartDownloadTipsCfg"
.constant	k111	"bShowWarningPopUp"
.constant	k112	"UIManager"
.constant	k113	"ShowUI"
.constant	k114	"UI_Config"
.constant	k115	"WoWEditor_DownloadLobbyTip_Popup"

.line	230	self          r1    r0    k0 ; k0 = "GetPufferDeleteManag" (truncated)
.line	230	call          r1     2     2
.line	230	gettabup      r2    u0    k1 ; k1 = "log"
.line	230	gettabup      r3    u0    k2 ; k2 = "bWriteLog"
.line	230	test          r3     0
.line	230	jmp            0   l63
.line	230	gettabup      r3    u0    k3 ; k3 = "table"
.line	230	gettable      r3    r3    k4 ; k4 = "concat"
.line	230	newtable      r4     1     0
.line	230	getupval      r5    u1
.line	230	loadk         r6    k5 ; k5 = 126
.line	230	loadk         r7    k6 ; k6 = 69
.line	230	loadk         r8    k7 ; k7 = 200
.line	230	loadk         r9    k8 ; k8 = 62
.line	230	loadk        r10    k9 ; k9 = 20
.line	230	loadk        r11   k10 ; k10 = 56
.line	230	loadk        r12   k11 ; k11 = 231
.line	230	loadk        r13   k12 ; k12 = 14
.line	230	loadk        r14   k13 ; k13 = 156
.line	230	loadk        r15   k14 ; k14 = 226
.line	230	loadk        r16    k7 ; k7 = 200
.line	230	loadk        r17   k15 ; k15 = 110
.line	230	loadk        r18   k16 ; k16 = 92
.line	230	loadk        r19   k17 ; k17 = 6
.line	230	loadk        r20   k18 ; k18 = 254
.line	230	loadk        r21   k19 ; k19 = 223
.line	230	loadk        r22   k20 ; k20 = 136
.line	230	loadk        r23   k21 ; k21 = 74
.line	230	loadk        r24   k22 ; k22 = 245
.line	230	loadk        r25   k23 ; k23 = 47
.line	230	loadk        r26   k24 ; k24 = 230
.line	230	loadk        r27   k25 ; k25 = 52
.line	230	loadk        r28   k26 ; k26 = 158
.line	230	loadk        r29   k27 ; k27 = 53
.line	230	loadk        r30   k28 ; k28 = 164
.line	230	loadk        r31   k29 ; k29 = 145
.line	230	loadk        r32   k30 ; k30 = 153
.line	230	loadk        r33   k31 ; k31 = 68
.line	230	loadk        r34   k32 ; k32 = 75
.line	230	loadk        r35   k33 ; k33 = 37
.line	230	loadk        r36   k34 ; k34 = 222
.line	230	loadk        r37   k35 ; k35 = 232
.line	230	loadk        r38   k36 ; k36 = 174
.line	230	loadk        r39   k37 ; k37 = 73
.line	230	loadk        r40   k38 ; k38 = 179
.line	230	loadk        r41   k39 ; k39 = 21
.line	230	loadk        r42   k40 ; k40 = 249
.line	230	loadk        r43   k41 ; k41 = 25
.line	230	loadk        r44   k42 ; k42 = 147
.line	230	loadk        r45   k43 ; k43 = 58
.line	230	call          r5    41     2
.line	230	getupval      r6    u1
.line	230	loadk         r7   k44 ; k44 = 26
.line	230	loadk         r8   k45 ; k45 = 23
.line	230	loadk         r9   k46 ; k46 = 159
.line	230	call          r6     4     0
.line	230	setlist       r4     0     1
.line	230	call          r3     2     2
.line	230	gettabup      r4    u0   k47 ; k47 = "tostring"
.line	230	gettable      r5    r1   k48 ; k48 = "SilentCleanup"
.line	230	call          r4     2     2
.line	230	concat        r3    r3    r4
.label	l63
.line	230	call          r2     2     1
.line	230	gettable      r2    r1   k48 ; k48 = "SilentCleanup"
.line	230	test          r2     0
.line	230	jmp            0   l71
.line	230	settable      r1   k48   k49 ; k49 = false
.line	230	gettabup      r2    u0   k50 ; k50 = "ShowNotice"
.line	230	loadk         r3   k51 ; k51 = 83249
.line	230	call          r2     2     1
.label	l71
.line	230	gettabup      r2    u2   k52 ; k52 = "AutoDownloadCfg"
.line	230	gettable      r2    r2   k53 ; k53 = "RecommendType"
.line	230	gettabup      r3    u3   k54 ; k54 = "Enum_RecommendType"
.line	230	gettable      r3    r3   k55 ; k55 = "None"
.line	230	eq             0    r2    r3
.line	230	jmp            0   l81
.line	230	gettabup      r2    u2   k52 ; k52 = "AutoDownloadCfg"
.line	230	gettabup      r3    u2   k56 ; k56 = "GetRecommendIndex"
.line	230	call          r3     1     2
.line	230	settable      r2   k53    r3 ; k53 = "RecommendType"
.label	l81
.line	230	self          r2    r0   k57 ; k57 = "PlayUserWidgetAnimat" (truncated)
.line	230	gettable      r4    r0   k58 ; k58 = "UIRoot"
.line	230	gettable      r4    r4   k59 ; k59 = "Fadein"
.line	230	loadk         r5   k60 ; k60 = 0
.line	230	loadk         r6   k61 ; k61 = 1
.line	230	loadk         r7   k60 ; k60 = 0
.line	230	loadk         r8   k61 ; k61 = 1
.line	230	call          r2     7     1
.line	230	self          r2    r0   k62 ; k62 = "AddTimerLoop"
.line	230	getupval      r4    u4
.line	230	closure       r5    f0
.line	230	gettabup      r6    u0   k63 ; k63 = "TIMER_INFINITE"
.line	230	getupval      r7    u4
.line	230	call          r2     6     1
.line	230	gettabup      r2    u2   k64 ; k64 = "SaveAutoDownloadSett" (truncated)
.line	230	call          r2     1     1
.line	230	gettabup      r2    u2   k65 ; k65 = "SmartDownloadTipsCfg"
.line	230	gettable      r2    r2   k66 ; k66 = "DownloadTipsShow"
.line	230	gettabup      r3    u0   k67 ; k67 = "require"
.line	230	gettabup      r4    u0    k3 ; k3 = "table"
.line	230	gettable      r4    r4    k4 ; k4 = "concat"
.line	230	newtable      r5     1     0
.line	230	getupval      r6    u1
.line	230	loadk         r7   k68 ; k68 = 89
.line	230	loadk         r8   k69 ; k69 = 70
.line	230	loadk         r9   k70 ; k70 = 214
.line	230	loadk        r10   k27 ; k27 = 53
.line	230	loadk        r11   k71 ; k71 = 22
.line	230	loadk        r12   k72 ; k72 = 35
.line	230	loadk        r13   k73 ; k73 = 168
.line	230	loadk        r14   k41 ; k41 = 25
.line	230	loadk        r15   k74 ; k74 = 175
.line	230	loadk        r16   k75 ; k75 = 218
.line	230	loadk        r17    k7 ; k7 = 200
.line	230	loadk        r18   k76 ; k76 = 41
.line	230	loadk        r19   k77 ; k77 = 81
.line	230	loadk        r20   k78 ; k78 = 54
.line	230	loadk        r21   k79 ; k79 = 197
.line	230	loadk        r22   k80 ; k80 = 240
.line	230	loadk        r23   k81 ; k81 = 163
.line	230	loadk        r24   k82 ; k82 = 125
.line	230	loadk        r25   k83 ; k83 = 225
.line	230	loadk        r26   k72 ; k72 = 35
.line	230	loadk        r27   k84 ; k84 = 228
.line	230	loadk        r28   k12 ; k12 = 14
.line	230	loadk        r29   k42 ; k42 = 147
.line	230	loadk        r30   k25 ; k25 = 52
.line	230	loadk        r31   k85 ; k85 = 167
.line	230	loadk        r32   k86 ; k86 = 242
.line	230	loadk        r33   k87 ; k87 = 216
.line	230	loadk        r34   k88 ; k88 = 116
.line	230	loadk        r35   k89 ; k89 = 80
.line	230	loadk        r36   k90 ; k90 = 38
.line	230	loadk        r37    k7 ; k7 = 200
.line	230	loadk        r38   k73 ; k73 = 168
.line	230	loadk        r39   k91 ; k91 = 138
.line	230	loadk        r40   k92 ; k92 = 127
.line	230	loadk        r41   k93 ; k93 = 189
.line	230	loadk        r42   k94 ; k94 = 28
.line	230	loadk        r43   k95 ; k95 = 241
.line	230	loadk        r44   k96 ; k96 = 4
.line	230	loadk        r45   k97 ; k97 = 142
.line	230	loadk        r46   k98 ; k98 = 24
.line	230	call          r6    41     2
.line	230	getupval      r7    u1
.line	230	loadk         r8   k99 ; k99 = 95
.line	230	loadk         r9  k100 ; k100 = 77
.line	230	loadk        r10   k70 ; k70 = 214
.line	230	loadk        r11  k101 ; k101 = 63
.line	230	loadk        r12   k71 ; k71 = 22
.line	230	loadk        r13   k44 ; k44 = 26
.line	230	loadk        r14   k11 ; k11 = 231
.line	230	loadk        r15  k102 ; k102 = 9
.line	230	loadk        r16  k103 ; k103 = 177
.line	230	loadk        r17  k104 ; k104 = 192
.line	230	loadk        r18   k75 ; k75 = 218
.line	230	call          r7    12     0
.line	230	setlist       r5     0     1
.line	230	call          r4     2     2
.line	230	call          r3     2     2
.line	230	gettable      r4    r3  k105 ; k105 = "IsFITVersion"
.line	230	call          r4     1     2
.line	230	test          r4     0
.line	230	jmp            0  l166
.line	230	loadbool      r2     1     0
.label	l166
.line	230	gettabup      r4    u2   k65 ; k65 = "SmartDownloadTipsCfg"
.line	230	settable      r4   k66  k106 ; k106 = true
.line	230	self          r4    r0  k107 ; k107 = "SetWidgetVisible"
.line	230	gettable      r6    r0   k58 ; k58 = "UIRoot"
.line	230	gettable      r6    r6  k108 ; k108 = "Download_Main_Tips_U" (truncated)
.line	230	not           r7    r2
.line	230	call          r4     4     1
.line	230	test          r2     1
.line	230	jmp            0  l179
.line	230	self          r4    r0  k109 ; k109 = "AddTimerOnce"
.line	230	loadk         r6   k61 ; k61 = 1
.line	230	closure       r7    f1
.line	230	call          r4     4     1
.label	l179
.line	230	gettabup      r4    u2  k110 ; k110 = "SaveSmartDownloadTip" (truncated)
.line	230	call          r4     1     1
.line	230	gettable      r4    r0  k111 ; k111 = "bShowWarningPopUp"
.line	230	test          r4     0
.line	230	jmp            0  l192
.line	230	settable      r0  k111   k49 ; k49 = false
.line	230	gettabup      r4    u0  k112 ; k112 = "UIManager"
.line	230	gettable      r4    r4  k113 ; k113 = "ShowUI"
.line	230	gettabup      r5    u0  k112 ; k112 = "UIManager"
.line	230	gettable      r5    r5  k114 ; k114 = "UI_Config"
.line	230	gettable      r5    r5  k115 ; k115 = "WoWEditor_DownloadLo" (truncated)
.line	230	closure       r6    f2
.line	230	call          r4     3     1
.label	l192
.line	230	return        r0     1
.line	230	move          r0    r0
.line	230	move          r0    r0
.line	230	return        r0     1

.function	main/f6/f0

.source	null
.linedefined	241
.lastlinedefined	249
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	true

.constant	k0	"UpdateReverseDownloadInfo"
.constant	k1	"UpdateCurTabDownloadInfo"
.constant	k2	"UpdateTabContent"
.constant	k3	"UpdateNetworkInfo"
.constant	k4	"UpdateRecommendInfo"
.constant	k5	"CalcAppearanceSize"
.constant	k6	"UpdateAllDownloadSize"

.line	241	getupval      r0    u0
.line	241	self          r0    r0    k0 ; k0 = "UpdateReverseDownloa" (truncated)
.line	241	call          r0     2     1
.line	241	getupval      r0    u0
.line	241	self          r0    r0    k1 ; k1 = "UpdateCurTabDownload" (truncated)
.line	241	call          r0     2     1
.line	241	getupval      r0    u0
.line	241	self          r0    r0    k2 ; k2 = "UpdateTabContent"
.line	241	call          r0     2     1
.line	241	getupval      r0    u0
.line	241	self          r0    r0    k3 ; k3 = "UpdateNetworkInfo"
.line	241	call          r0     2     1
.line	241	getupval      r0    u0
.line	241	self          r0    r0    k4 ; k4 = "UpdateRecommendInfo"
.line	241	call          r0     2     1
.line	241	getupval      r0    u0
.line	241	self          r0    r0    k5 ; k5 = "CalcAppearanceSize"
.line	241	call          r0     2     1
.line	241	getupval      r0    u0
.line	241	self          r0    r0    k6 ; k6 = "UpdateAllDownloadSiz" (truncated)
.line	241	call          r0     2     1
.line	241	return        r0     1
.line	241	move          r0    r0
.line	241	return        r0     1

.function	main/f6/f1

.source	null
.linedefined	259
.lastlinedefined	263
.numparams	0
.is_vararg	0
.maxstacksize	17

.upvalue	"_ENV"	0	false
.upvalue	"U1"	0	true

.constant	k0	"UIManager"
.constant	k1	"ShowUI"
.constant	k2	"UI_Config"
.constant	k3	"NewbieGuide_UIBP"
.constant	k4	6
.constant	k5	"LocUtil"
.constant	k6	"GetLocalizeResStr"
.constant	k7	8800608
.constant	k8	"UIRoot"
.constant	k9	"Button_8"
.constant	k10	1
.constant	k11	"extSize"
.constant	k12	"FVector2D"

.line	259	gettabup      r0    u0    k0 ; k0 = "UIManager"
.line	259	gettable      r0    r0    k1 ; k1 = "ShowUI"
.line	259	gettabup      r1    u0    k0 ; k0 = "UIManager"
.line	259	gettable      r1    r1    k2 ; k2 = "UI_Config"
.line	259	gettable      r1    r1    k3 ; k3 = "NewbieGuide_UIBP"
.line	259	loadk         r2    k4 ; k4 = 6
.line	259	gettabup      r3    u0    k5 ; k5 = "LocUtil"
.line	259	gettable      r3    r3    k6 ; k6 = "GetLocalizeResStr"
.line	259	loadk         r4    k7 ; k7 = 8800608
.line	259	call          r3     2     2
.line	259	gettabup      r4    u1    k8 ; k8 = "UIRoot"
.line	259	gettable      r4    r4    k9 ; k9 = "Button_8"
.line	259	loadnil       r5     0
.line	259	loadbool      r6     0     0
.line	259	loadk         r7   k10 ; k10 = 1
.line	259	loadbool      r8     1     0
.line	259	loadnil       r9     3
.line	259	newtable     r13     0     1
.line	259	gettabup     r14    u0   k12 ; k12 = "FVector2D"
.line	259	loadk        r15    k4 ; k4 = 6
.line	259	loadk        r16    k4 ; k4 = 6
.line	259	call         r14     3     2
.line	259	settable     r13   k11   r14 ; k11 = "extSize"
.line	259	call          r0    14     1
.line	259	return        r0     1
.line	259	move          r0    r0
.line	259	move          r0    r0
.line	259	return        r0     1

.function	main/f6/f2

.source	null
.linedefined	268
.lastlinedefined	270
.numparams	0
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false

.constant	k0	"EventSystem"
.constant	k1	"postEvent"
.constant	k2	"EVENTTYPE_WOW_EDITOR"
.constant	k3	"EVENTID_WOW_EDITOR_DOWNLOAD_LOBBY_RES"

.line	268	gettabup      r0    u0    k0 ; k0 = "EventSystem"
.line	268	self          r0    r0    k1 ; k1 = "postEvent"
.line	268	gettabup      r2    u0    k2 ; k2 = "EVENTTYPE_WOW_EDITOR"
.line	268	gettabup      r3    u0    k3 ; k3 = "EVENTID_WOW_EDITOR_D" (truncated)
.line	268	call          r0     4     1
.line	268	return        r0     1
.line	268	move          r0    r0
.line	268	return        r0     1

.function	main/f7

.source	null
.linedefined	274
.lastlinedefined	277
.numparams	3
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"tab_v1"
.constant	k3	"log"
.constant	k4	"bWriteLog"
.constant	k5	"table"
.constant	k6	"concat"
.constant	k7	126
.constant	k8	69
.constant	k9	200
.constant	k10	62
.constant	k11	20
.constant	k12	56
.constant	k13	231
.constant	k14	14
.constant	k15	156
.constant	k16	226
.constant	k17	110
.constant	k18	92
.constant	k19	6
.constant	k20	254
.constant	k21	223
.constant	k22	136
.constant	k23	74
.constant	k24	245
.constant	k25	47
.constant	k26	230
.constant	k27	49
.constant	k28	147
.constant	k29	40
.constant	k30	167
.constant	k31	214
.constant	k32	218
.constant	k33	118
.constant	k34	78
.constant	k35	29
.constant	k36	222
.constant	k37	174
.constant	k38	94
.constant	k39	190
.constant	k40	18
.constant	k41	219
.constant	k42	27
.constant	k43	143
.constant	k44	41
.constant	k45	81
.constant	k46	79
.constant	k47	19
.constant	k48	25
.constant	k49	59
.constant	k50	234
.constant	k51	8
.constant	k52	162
.constant	k53	204
.constant	k54	194
.constant	k55	39
.constant	k56	91
.constant	k57	55
.constant	k58	207
.constant	k59	243
.constant	k60	178
.constant	k61	58
.constant	k62	242
.constant	k63	64
.constant	k64	"tostring"
.constant	k65	22
.constant	k66	10
.constant	k67	203
.constant	k68	53
.constant	k69	0
.constant	k70	35
.constant	k71	166
.constant	k72	87
.constant	k73	227
.constant	k74	"downloaderData"
.constant	k75	"text"

.line	274	self          r3    r0    k0 ; k0 = "PlayAudio"
.line	274	gettabup      r5    u0    k1 ; k1 = "sound_config"
.line	274	gettable      r5    r5    k2 ; k2 = "tab_v1"
.line	274	call          r3     3     1
.line	274	gettabup      r3    u0    k3 ; k3 = "log"
.line	274	gettabup      r4    u0    k4 ; k4 = "bWriteLog"
.line	274	test          r4     0
.line	274	jmp            0   l98
.line	274	gettabup      r4    u0    k5 ; k5 = "table"
.line	274	gettable      r4    r4    k6 ; k6 = "concat"
.line	274	newtable      r5     1     0
.line	274	getupval      r6    u1
.line	274	loadk         r7    k7 ; k7 = 126
.line	274	loadk         r8    k8 ; k8 = 69
.line	274	loadk         r9    k9 ; k9 = 200
.line	274	loadk        r10   k10 ; k10 = 62
.line	274	loadk        r11   k11 ; k11 = 20
.line	274	loadk        r12   k12 ; k12 = 56
.line	274	loadk        r13   k13 ; k13 = 231
.line	274	loadk        r14   k14 ; k14 = 14
.line	274	loadk        r15   k15 ; k15 = 156
.line	274	loadk        r16   k16 ; k16 = 226
.line	274	loadk        r17    k9 ; k9 = 200
.line	274	loadk        r18   k17 ; k17 = 110
.line	274	loadk        r19   k18 ; k18 = 92
.line	274	loadk        r20   k19 ; k19 = 6
.line	274	loadk        r21   k20 ; k20 = 254
.line	274	loadk        r22   k21 ; k21 = 223
.line	274	loadk        r23   k22 ; k22 = 136
.line	274	loadk        r24   k23 ; k23 = 74
.line	274	loadk        r25   k24 ; k24 = 245
.line	274	loadk        r26   k25 ; k25 = 47
.line	274	loadk        r27   k26 ; k26 = 230
.line	274	loadk        r28   k27 ; k27 = 49
.line	274	loadk        r29   k28 ; k28 = 147
.line	274	loadk        r30   k29 ; k29 = 40
.line	274	loadk        r31   k30 ; k30 = 167
.line	274	loadk        r32   k31 ; k31 = 214
.line	274	loadk        r33   k32 ; k32 = 218
.line	274	loadk        r34   k33 ; k33 = 118
.line	274	loadk        r35   k34 ; k34 = 78
.line	274	loadk        r36   k35 ; k35 = 29
.line	274	loadk        r37   k36 ; k36 = 222
.line	274	loadk        r38   k20 ; k20 = 254
.line	274	loadk        r39   k37 ; k37 = 174
.line	274	loadk        r40   k38 ; k38 = 94
.line	274	loadk        r41   k39 ; k39 = 190
.line	274	loadk        r42   k40 ; k40 = 18
.line	274	loadk        r43   k41 ; k41 = 219
.line	274	loadk        r44   k42 ; k42 = 27
.line	274	loadk        r45   k43 ; k43 = 143
.line	274	loadk        r46   k44 ; k44 = 41
.line	274	call          r6    41     2
.line	274	getupval      r7    u1
.line	274	loadk         r8   k45 ; k45 = 81
.line	274	loadk         r9   k46 ; k46 = 79
.line	274	loadk        r10   k41 ; k41 = 219
.line	274	loadk        r11   k47 ; k47 = 19
.line	274	loadk        r12   k48 ; k48 = 25
.line	274	loadk        r13   k49 ; k49 = 59
.line	274	loadk        r14   k50 ; k50 = 234
.line	274	loadk        r15   k51 ; k51 = 8
.line	274	loadk        r16   k52 ; k52 = 162
.line	274	loadk        r17   k53 ; k53 = 204
.line	274	loadk        r18   k54 ; k54 = 194
.line	274	loadk        r19   k55 ; k55 = 39
.line	274	loadk        r20   k56 ; k56 = 91
.line	274	loadk        r21   k57 ; k57 = 55
.line	274	loadk        r22   k58 ; k58 = 207
.line	274	loadk        r23   k59 ; k59 = 243
.line	274	loadk        r24   k60 ; k60 = 178
.line	274	loadk        r25   k61 ; k61 = 58
.line	274	loadk        r26   k62 ; k62 = 242
.line	274	loadk        r27   k63 ; k63 = 64
.line	274	call          r7    21     0
.line	274	setlist       r5     0     1
.line	274	call          r4     2     2
.line	274	gettabup      r5    u0   k64 ; k64 = "tostring"
.line	274	move          r6    r2
.line	274	call          r5     2     2
.line	274	getupval      r6    u1
.line	274	loadk         r7   k65 ; k65 = 22
.line	274	loadk         r8   k66 ; k66 = 10
.line	274	loadk         r9   k67 ; k67 = 203
.line	274	loadk        r10   k68 ; k68 = 53
.line	274	loadk        r11   k69 ; k69 = 0
.line	274	loadk        r12   k70 ; k70 = 35
.line	274	loadk        r13   k71 ; k71 = 166
.line	274	loadk        r14   k72 ; k72 = 87
.line	274	loadk        r15   k73 ; k73 = 227
.line	274	call          r6    10     2
.line	274	gettabup      r7    u0   k64 ; k64 = "tostring"
.line	274	gettable      r8    r0   k74 ; k74 = "downloaderData"
.line	274	gettable      r8    r8    r2
.line	274	gettable      r8    r8   k75 ; k75 = "text"
.line	274	call          r7     2     2
.line	274	concat        r4    r4    r7
.label	l98
.line	274	call          r3     2     1
.line	274	return        r0     1
.line	274	move          r0    r0
.line	274	move          r0    r0
.line	274	move          r0    r0
.line	274	return        r0     1

.function	main/f8

.source	null
.linedefined	279
.lastlinedefined	331
.numparams	4
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	10	true
.upvalue	"U3"	9	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	126
.constant	k7	69
.constant	k8	200
.constant	k9	62
.constant	k10	20
.constant	k11	56
.constant	k12	231
.constant	k13	14
.constant	k14	156
.constant	k15	226
.constant	k16	110
.constant	k17	92
.constant	k18	6
.constant	k19	254
.constant	k20	223
.constant	k21	136
.constant	k22	74
.constant	k23	245
.constant	k24	47
.constant	k25	230
.constant	k26	49
.constant	k27	147
.constant	k28	40
.constant	k29	167
.constant	k30	214
.constant	k31	218
.constant	k32	118
.constant	k33	78
.constant	k34	29
.constant	k35	222
.constant	k36	174
.constant	k37	94
.constant	k38	190
.constant	k39	18
.constant	k40	203
.constant	k41	138
.constant	k42	89
.constant	k43	52
.constant	k44	59
.constant	k45	54
.constant	k46	234
.constant	k47	161
.constant	k48	206
.constant	k49	202
.constant	k50	108
.constant	k51	28
.constant	k52	121
.constant	k53	199
.constant	k54	247
.constant	k55	185
.constant	k56	134
.constant	k57	236
.constant	k58	2
.constant	k59	142
.constant	k60	103
.constant	k61	246
.constant	k62	204
.constant	k63	149
.constant	k64	55
.constant	k65	75
.constant	k66	39
.constant	k67	227
.constant	k68	162
.constant	k69	250
.constant	k70	3
.constant	k71	180
.constant	k72	87
.constant	k73	132
.constant	k74	12
.constant	k75	72
.constant	k76	210
.constant	k77	19
.constant	k78	229
.constant	k79	1
.constant	k80	"tostring"
.constant	k81	"curVerTabIndex"
.constant	k82	"IsViewMode"
.constant	k83	79
.constant	k84	211
.constant	k85	53
.constant	k86	50
.constant	k87	"ReportTLogEvent"
.constant	k88	"TLogEventDefine"
.constant	k89	"DownloadMainUIPageChanged"
.constant	k90	"isRecommendPage"
.constant	k91	false
.constant	k92	"Common_Tab_Vertical_LevelOne_Text_UIBP"
.constant	k93	"GetTabData"
.constant	k94	"curTabData"
.constant	k95	0
.constant	k96	"tabs"
.constant	k97	"IsRecommendTabData"
.constant	k98	"AutoDownloadCfg"
.constant	k99	"RecommendType"
.constant	k100	"isFitVersion"
.constant	k101	"curShowBundleIDs"
.constant	k102	"bundleIDs"
.constant	k103	true
.constant	k104	"UIRoot"
.constant	k105	"TextBlock_101"
.constant	k106	"SetText"
.constant	k107	"jumpKey"
.constant	k108	"ipairs"
.constant	k109	"bundleData"
.constant	k110	"key"
.constant	k111	"Common_Tab_Horizontal_LevelOne_Text_UIBP"
.constant	k112	"SetTabs"
.constant	k113	nil
.constant	k114	"WidgetSwitcher_0"
.constant	k115	"SetActiveWidgetIndex"
.constant	k116	"SelectTopTab"

.line	279	gettabup      r4    u0    k0 ; k0 = "log"
.line	279	gettabup      r5    u0    k1 ; k1 = "bWriteLog"
.line	279	test          r5     0
.line	279	jmp            0  l119
.line	279	gettabup      r5    u0    k2 ; k2 = "string"
.line	279	gettable      r5    r5    k3 ; k3 = "format"
.line	279	gettabup      r6    u0    k4 ; k4 = "table"
.line	279	gettable      r6    r6    k5 ; k5 = "concat"
.line	279	newtable      r7     2     0
.line	279	getupval      r8    u1
.line	279	loadk         r9    k6 ; k6 = 126
.line	279	loadk        r10    k7 ; k7 = 69
.line	279	loadk        r11    k8 ; k8 = 200
.line	279	loadk        r12    k9 ; k9 = 62
.line	279	loadk        r13   k10 ; k10 = 20
.line	279	loadk        r14   k11 ; k11 = 56
.line	279	loadk        r15   k12 ; k12 = 231
.line	279	loadk        r16   k13 ; k13 = 14
.line	279	loadk        r17   k14 ; k14 = 156
.line	279	loadk        r18   k15 ; k15 = 226
.line	279	loadk        r19    k8 ; k8 = 200
.line	279	loadk        r20   k16 ; k16 = 110
.line	279	loadk        r21   k17 ; k17 = 92
.line	279	loadk        r22   k18 ; k18 = 6
.line	279	loadk        r23   k19 ; k19 = 254
.line	279	loadk        r24   k20 ; k20 = 223
.line	279	loadk        r25   k21 ; k21 = 136
.line	279	loadk        r26   k22 ; k22 = 74
.line	279	loadk        r27   k23 ; k23 = 245
.line	279	loadk        r28   k24 ; k24 = 47
.line	279	loadk        r29   k25 ; k25 = 230
.line	279	loadk        r30   k26 ; k26 = 49
.line	279	loadk        r31   k27 ; k27 = 147
.line	279	loadk        r32   k28 ; k28 = 40
.line	279	loadk        r33   k29 ; k29 = 167
.line	279	loadk        r34   k30 ; k30 = 214
.line	279	loadk        r35   k31 ; k31 = 218
.line	279	loadk        r36   k32 ; k32 = 118
.line	279	loadk        r37   k33 ; k33 = 78
.line	279	loadk        r38   k34 ; k34 = 29
.line	279	loadk        r39   k35 ; k35 = 222
.line	279	loadk        r40   k19 ; k19 = 254
.line	279	loadk        r41   k36 ; k36 = 174
.line	279	loadk        r42   k37 ; k37 = 94
.line	279	loadk        r43   k38 ; k38 = 190
.line	279	loadk        r44   k39 ; k39 = 18
.line	279	loadk        r45   k40 ; k40 = 203
.line	279	loadk        r46   k39 ; k39 = 18
.line	279	loadk        r47   k41 ; k41 = 138
.line	279	loadk        r48   k24 ; k24 = 47
.line	279	call          r8    41     2
.line	279	getupval      r9    u1
.line	279	loadk        r10   k42 ; k42 = 89
.line	279	loadk        r11   k37 ; k37 = 94
.line	279	loadk        r12   k31 ; k31 = 218
.line	279	loadk        r13   k43 ; k43 = 52
.line	279	loadk        r14   k44 ; k44 = 59
.line	279	loadk        r15   k45 ; k45 = 54
.line	279	loadk        r16   k46 ; k46 = 234
.line	279	loadk        r17   k18 ; k18 = 6
.line	279	loadk        r18   k47 ; k47 = 161
.line	279	loadk        r19   k48 ; k48 = 206
.line	279	loadk        r20   k49 ; k49 = 202
.line	279	loadk        r21   k50 ; k50 = 108
.line	279	loadk        r22   k51 ; k51 = 28
.line	279	loadk        r23   k52 ; k52 = 121
.line	279	loadk        r24   k53 ; k53 = 199
.line	279	loadk        r25   k54 ; k54 = 247
.line	279	loadk        r26   k55 ; k55 = 185
.line	279	loadk        r27   k16 ; k16 = 110
.line	279	loadk        r28   k56 ; k56 = 134
.line	279	loadk        r29   k13 ; k13 = 14
.line	279	loadk        r30   k57 ; k57 = 236
.line	279	loadk        r31   k58 ; k58 = 2
.line	279	loadk        r32   k59 ; k59 = 142
.line	279	loadk        r33   k60 ; k60 = 103
.line	279	loadk        r34   k61 ; k61 = 246
.line	279	loadk        r35   k62 ; k62 = 204
.line	279	loadk        r36   k63 ; k63 = 149
.line	279	loadk        r37   k64 ; k64 = 55
.line	279	loadk        r38   k65 ; k65 = 75
.line	279	loadk        r39   k66 ; k66 = 39
.line	279	loadk        r40   k20 ; k20 = 223
.line	279	loadk        r41   k67 ; k67 = 227
.line	279	loadk        r42   k68 ; k68 = 162
.line	279	loadk        r43   k64 ; k64 = 55
.line	279	loadk        r44   k69 ; k69 = 250
.line	279	loadk        r45   k70 ; k70 = 3
.line	279	loadk        r46   k71 ; k71 = 180
.line	279	loadk        r47   k72 ; k72 = 87
.line	279	loadk        r48   k73 ; k73 = 132
.line	279	loadk        r49   k74 ; k74 = 12
.line	279	call          r9    41     2
.line	279	getupval     r10    u1
.line	279	loadk        r11   k75 ; k75 = 72
.line	279	loadk        r12    k7 ; k7 = 69
.line	279	loadk        r13   k76 ; k76 = 210
.line	279	loadk        r14   k77 ; k77 = 19
.line	279	loadk        r15   k10 ; k10 = 20
.line	279	loadk        r16    k9 ; k9 = 62
.line	279	loadk        r17   k78 ; k78 = 229
.line	279	loadk        r18   k79 ; k79 = 1
.line	279	loadk        r19   k19 ; k19 = 254
.line	279	loadk        r20   k41 ; k41 = 138
.line	279	loadk        r21   k31 ; k31 = 218
.line	279	call         r10    12     0
.line	279	setlist       r7     0     1
.line	279	call          r6     2     2
.line	279	gettabup      r7    u0   k80 ; k80 = "tostring"
.line	279	move          r8    r1
.line	279	call          r7     2     2
.line	279	gettabup      r8    u0   k80 ; k80 = "tostring"
.line	279	move          r9    r2
.line	279	call          r8     2     2
.line	279	gettabup      r9    u0   k80 ; k80 = "tostring"
.line	279	move         r10    r3
.line	279	call          r9     2     0
.line	279	call          r5     0     2
.label	l119
.line	279	call          r4     2     1
.line	279	gettable      r4    r0   k81 ; k81 = "curVerTabIndex"
.line	279	eq             0    r4    r2
.line	279	jmp            0  l126
.line	279	test          r3     0
.line	279	jmp            0  l126
.line	279	return        r0     1
.label	l126
.line	279	self          r4    r0   k82 ; k82 = "IsViewMode"
.line	279	call          r4     2     2
.line	279	test          r4     0
.line	279	jmp            0  l142
.line	279	getupval      r4    u1
.line	279	loadk         r5   k37 ; k37 = 94
.line	279	loadk         r6    k7 ; k7 = 69
.line	279	loadk         r7    k8 ; k8 = 200
.line	279	loadk         r8    k9 ; k9 = 62
.line	279	loadk         r9   k10 ; k10 = 20
.line	279	loadk        r10   k11 ; k11 = 56
.line	279	loadk        r11   k12 ; k12 = 231
.line	279	loadk        r12   k13 ; k13 = 14
.line	279	call          r4     9     2
.line	279	test          r4     1
.line	279	jmp            0  l150
.label	l142
.line	279	getupval      r4    u1
.line	279	loadk         r5   k37 ; k37 = 94
.line	279	loadk         r6   k83 ; k83 = 79
.line	279	loadk         r7   k84 ; k84 = 211
.line	279	loadk         r8   k85 ; k85 = 53
.line	279	loadk         r9   k74 ; k74 = 12
.line	279	loadk        r10   k86 ; k86 = 50
.line	279	call          r4     7     2
.label	l150
.line	279	gettabup      r5    u2   k87 ; k87 = "ReportTLogEvent"
.line	279	gettabup      r6    u0   k88 ; k88 = "TLogEventDefine"
.line	279	gettable      r6    r6   k89 ; k89 = "DownloadMainUIPageCh" (truncated)
.line	279	move          r7    r2
.line	279	move          r8    r4
.line	279	call          r5     4     1
.line	279	settable      r0   k81    r2 ; k81 = "curVerTabIndex"
.line	279	settable      r0   k90   k91 ; k91 = false
.line	279	gettable      r5    r0   k92 ; k92 = "Common_Tab_Vertical_" (truncated)
.line	279	self          r5    r5   k93 ; k93 = "GetTabData"
.line	279	move          r7    r2
.line	279	call          r5     3     2
.line	279	settable      r0   k94    r5 ; k94 = "curTabData"
.line	279	test          r5     0
.line	279	jmp            0  l251
.line	279	loadk         r6   k95 ; k95 = 0
.line	279	gettable      r7    r5   k96 ; k96 = "tabs"
.line	279	loadnil       r8     0
.line	279	self          r9    r0   k97 ; k97 = "IsRecommendTabData"
.line	279	move         r11    r5
.line	279	call          r9     3     2
.line	279	test          r9     0
.line	279	jmp            0  l189
.line	279	gettabup      r9    u3   k98 ; k98 = "AutoDownloadCfg"
.line	279	gettable      r9    r9   k99 ; k99 = "RecommendType"
.line	279	gettable     r10    r0  k100 ; k100 = "isFitVersion"
.line	279	test         r10     0
.line	279	jmp            0  l179
.line	279	loadk         r9   k79 ; k79 = 1
.label	l179
.line	279	newtable     r10     1     0
.line	279	gettable     r11    r5  k102 ; k102 = "bundleIDs"
.line	279	gettable     r11   r11    r9
.line	279	setlist      r10     1     1
.line	279	settable      r0  k101   r10 ; k101 = "curShowBundleIDs"
.line	279	testset       r8    r7     0
.line	279	jmp            0  l187
.line	279	gettable      r8    r7    r9
.label	l187
.line	279	settable      r0   k90  k103 ; k103 = true
.line	279	jmp            0  l197
.label	l189
.line	279	gettable      r9    r5  k102 ; k102 = "bundleIDs"
.line	279	settable      r0  k101    r9 ; k101 = "curShowBundleIDs"
.line	279	test          r7     0
.line	279	jmp            0  l197
.line	279	len           r9    r7
.line	279	eq             0    r9   k79 ; k79 = 1
.line	279	jmp            0  l197
.line	279	gettable      r8    r7   k79 ; k79 = 1
.label	l197
.line	279	loadk         r9   k79 ; k79 = 1
.line	279	test          r8     0
.line	279	jmp            0  l206
.line	279	gettable     r10    r0  k104 ; k104 = "UIRoot"
.line	279	gettable     r10   r10  k105 ; k105 = "TextBlock_101"
.line	279	self         r10   r10  k106 ; k106 = "SetText"
.line	279	move         r12    r8
.line	279	call         r10     3     1
.line	279	jmp            0  l241
.label	l206
.line	279	test          r7     0
.line	279	jmp            0  l241
.line	279	loadk         r6   k79 ; k79 = 1
.line	279	gettable     r10    r0  k107 ; k107 = "jumpKey"
.line	279	test         r10     0
.line	279	jmp            0  l236
.line	279	gettabup     r10    u0  k108 ; k108 = "ipairs"
.line	279	gettable     r11    r5  k102 ; k102 = "bundleIDs"
.line	279	call         r10     2     4
.line	279	jmp            0  l234
.line	279	gettabup     r15    u0  k108 ; k108 = "ipairs"
.line	279	gettable     r16    r0  k109 ; k109 = "bundleData"
.line	279	gettable     r16   r16   r14
.line	279	test         r16     1
.line	279	jmp            0  l222
.line	279	newtable     r16     0     0
.label	l222
.line	279	call         r15     2     4
.line	279	jmp            0  l232
.line	279	gettabup     r20    u0   k80 ; k80 = "tostring"
.line	279	gettable     r21   r19  k110 ; k110 = "key"
.line	279	call         r20     2     2
.line	279	gettable     r21    r0  k107 ; k107 = "jumpKey"
.line	279	eq             0   r20   r21
.line	279	jmp            0  l232
.line	279	move          r9   r13
.line	279	jmp            0  l234
.label	l232
.line	279	move          r0    r0
.line	279	move          r0    r0
.label	l234
.line	279	move          r0    r0
.line	279	move          r0    r0
.label	l236
.line	279	gettable     r10    r0  k111 ; k111 = "Common_Tab_Horizonta" (truncated)
.line	279	self         r10   r10  k112 ; k112 = "SetTabs"
.line	279	move         r12    r7
.line	279	move         r13    r9
.line	279	call         r10     4     1
.label	l241
.line	279	settable      r0  k107  k113 ; k113 = nil
.line	279	gettable     r10    r0  k104 ; k104 = "UIRoot"
.line	279	gettable     r10   r10  k114 ; k114 = "WidgetSwitcher_0"
.line	279	self         r10   r10  k115 ; k115 = "SetActiveWidgetIndex"
.line	279	move         r12    r6
.line	279	call         r10     3     1
.line	279	self         r10    r0  k116 ; k116 = "SelectTopTab"
.line	279	move         r12    r9
.line	279	loadbool     r13     1     0
.line	279	call         r10     4     1
.label	l251
.line	279	return        r0     1
.line	279	gettabup      r2    u0   k62 ; k62 = 204
.line	279	return        r0     1

.function	main/f9

.source	null
.linedefined	333
.lastlinedefined	346
.numparams	3
.is_vararg	0
.maxstacksize	7

.constant	k0	nil
.constant	k1	"TextBlock_Name"
.constant	k2	"WrapTextAt"
.constant	k3	135
.constant	k4	"AutoWrapText"
.constant	k5	false
.constant	k6	"isFitVersion"
.constant	k7	"downloaderData"
.constant	k8	"IsRecommendTabData"
.constant	k9	"recommendTabIndex"
.constant	k10	1

.line	333	eq             0    r1    k0 ; k0 = nil
.line	333	jmp            0    l4
.line	333	return        r0     1
.label	l4
.line	333	gettable      r3    r1    k1 ; k1 = "TextBlock_Name"
.line	333	test          r3     1
.line	333	jmp            0    l8
.line	333	return        r0     1
.label	l8
.line	333	settable      r3    k2    k3 ; k3 = 135
.line	333	settable      r3    k4    k5 ; k5 = false
.line	333	gettable      r4    r0    k6 ; k6 = "isFitVersion"
.line	333	test          r4     0
.line	333	jmp            0   l28
.line	333	gettable      r4    r0    k7 ; k7 = "downloaderData"
.line	333	test          r4     0
.line	333	jmp            0   l28
.line	333	gettable      r4    r0    k7 ; k7 = "downloaderData"
.line	333	gettable      r4    r4    r2
.line	333	test          r4     0
.line	333	jmp            0   l28
.line	333	self          r4    r0    k8 ; k8 = "IsRecommendTabData"
.line	333	gettable      r6    r0    k7 ; k7 = "downloaderData"
.line	333	gettable      r6    r6    r2
.line	333	call          r4     3     2
.line	333	test          r4     0
.line	333	jmp            0   l28
.line	333	sub           r4    r2   k10 ; k10 = 1
.line	333	settable      r0    k9    r4 ; k9 = "recommendTabIndex"
.label	l28
.line	333	return        r0     1
.line	333	move          r0    r0
.line	333	return        r0     1

.function	main/f10

.source	null
.linedefined	348
.lastlinedefined	368
.numparams	3
.is_vararg	0
.maxstacksize	13

.upvalue	"_ENV"	0	false

.constant	k0	"IsViewMode"
.constant	k1	"showTabData"
.constant	k2	nil
.constant	k3	0
.constant	k4	"curTabData"
.constant	k5	"bundleIDs"
.constant	k6	"bundleData"
.constant	k7	"pairs"
.constant	k8	"deleteKey"
.constant	k9	"key"
.constant	k10	1

.line	348	self          r3    r0    k0 ; k0 = "IsViewMode"
.line	348	call          r3     2     2
.line	348	test          r3     0
.line	348	jmp            0    l7
.line	348	loadnil       r3     0
.line	348	return        r3     2
.label	l7
.line	348	gettable      r3    r0    k1 ; k1 = "showTabData"
.line	348	eq             0    r3    k2 ; k2 = nil
.line	348	jmp            0   l12
.line	348	loadnil       r3     0
.line	348	return        r3     2
.label	l12
.line	348	loadk         r3    k3 ; k3 = 0
.line	348	gettable      r4    r0    k4 ; k4 = "curTabData"
.line	348	test          r4     0
.line	348	jmp            0   l40
.line	348	gettable      r4    r0    k4 ; k4 = "curTabData"
.line	348	gettable      r4    r4    k5 ; k5 = "bundleIDs"
.line	348	gettable      r4    r4    r2
.line	348	test          r4     0
.line	348	jmp            0   l40
.line	348	gettable      r4    r0    k4 ; k4 = "curTabData"
.line	348	gettable      r4    r4    k5 ; k5 = "bundleIDs"
.line	348	gettable      r4    r4    r2
.line	348	gettable      r5    r0    k6 ; k6 = "bundleData"
.line	348	gettable      r5    r5    r4
.line	348	test          r5     0
.line	348	jmp            0   l40
.line	348	gettabup      r6    u0    k7 ; k7 = "pairs"
.line	348	move          r7    r5
.line	348	call          r6     2     4
.line	348	jmp            0   l38
.line	348	gettable     r11    r0    k8 ; k8 = "deleteKey"
.line	348	gettable     r12   r10    k9 ; k9 = "key"
.line	348	gettable     r11   r11   r12
.line	348	test         r11     0
.line	348	jmp            0   l38
.line	348	add           r3    r3   k10 ; k10 = 1
.label	l38
.line	348	move          r0    r0
.line	348	move          r0    r0
.label	l40
.line	348	return        r3     2
.line	348	return        r0     1
.line	348	move          r0    r0
.line	348	return        r0     1

.function	main/f11

.source	null
.linedefined	370
.lastlinedefined	400
.numparams	3
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	15	true
.upvalue	"U3"	9	true
.upvalue	"U4"	7	true
.upvalue	"U5"	4	true

.constant	k0	"IsViewMode"
.constant	k1	"downloaderData"
.constant	k2	"log"
.constant	k3	"bWriteLog"
.constant	k4	"string"
.constant	k5	"format"
.constant	k6	"table"
.constant	k7	"concat"
.constant	k8	126
.constant	k9	69
.constant	k10	200
.constant	k11	62
.constant	k12	20
.constant	k13	56
.constant	k14	231
.constant	k15	14
.constant	k16	156
.constant	k17	226
.constant	k18	110
.constant	k19	92
.constant	k20	6
.constant	k21	254
.constant	k22	223
.constant	k23	136
.constant	k24	74
.constant	k25	245
.constant	k26	47
.constant	k27	230
.constant	k28	49
.constant	k29	147
.constant	k30	40
.constant	k31	167
.constant	k32	214
.constant	k33	218
.constant	k34	118
.constant	k35	78
.constant	k36	29
.constant	k37	228
.constant	k38	148
.constant	k39	127
.constant	k40	178
.constant	k41	51
.constant	k42	249
.constant	k43	27
.constant	k44	138
.constant	k45	91
.constant	k46	73
.constant	k47	212
.constant	k48	88
.constant	k49	32
.constant	k50	239
.constant	k51	164
.constant	k52	202
.constant	k53	221
.constant	k54	58
.constant	k55	23
.constant	k56	42
.constant	k57	135
.constant	k58	182
.constant	k59	163
.constant	k60	116
.constant	k61	171
.constant	k62	5
.constant	k63	240
.constant	k64	90
.constant	k65	211
.constant	k66	41
.constant	k67	"tostring"
.constant	k68	0
.constant	k69	"bundleIDs"
.constant	k70	"IsRecommendTabData"
.constant	k71	"AutoDownloadCfg"
.constant	k72	"RecommendType"
.constant	k73	"pairs"
.constant	k74	"bundleData"
.constant	k75	"deleteKey"
.constant	k76	"key"
.constant	k77	1
.constant	k78	"GetDownloaderTableData"
.constant	k79	"TabStyle"
.constant	k80	"BigImage"

.line	370	self          r3    r0    k0 ; k0 = "IsViewMode"
.line	370	call          r3     2     2
.line	370	test          r3     0
.line	370	jmp            0    l7
.line	370	loadnil       r3     0
.line	370	return        r3     2
.label	l7
.line	370	gettable      r3    r0    k1 ; k1 = "downloaderData"
.line	370	test          r3     1
.line	370	jmp            0   l12
.line	370	loadnil       r3     0
.line	370	return        r3     2
.label	l12
.line	370	gettabup      r3    u0    k2 ; k2 = "log"
.line	370	gettabup      r4    u0    k3 ; k3 = "bWriteLog"
.line	370	test          r4     0
.line	370	jmp            0   l98
.line	370	gettabup      r4    u0    k4 ; k4 = "string"
.line	370	gettable      r4    r4    k5 ; k5 = "format"
.line	370	gettabup      r5    u0    k6 ; k6 = "table"
.line	370	gettable      r5    r5    k7 ; k7 = "concat"
.line	370	newtable      r6     1     0
.line	370	getupval      r7    u1
.line	370	loadk         r8    k8 ; k8 = 126
.line	370	loadk         r9    k9 ; k9 = 69
.line	370	loadk        r10   k10 ; k10 = 200
.line	370	loadk        r11   k11 ; k11 = 62
.line	370	loadk        r12   k12 ; k12 = 20
.line	370	loadk        r13   k13 ; k13 = 56
.line	370	loadk        r14   k14 ; k14 = 231
.line	370	loadk        r15   k15 ; k15 = 14
.line	370	loadk        r16   k16 ; k16 = 156
.line	370	loadk        r17   k17 ; k17 = 226
.line	370	loadk        r18   k10 ; k10 = 200
.line	370	loadk        r19   k18 ; k18 = 110
.line	370	loadk        r20   k19 ; k19 = 92
.line	370	loadk        r21   k20 ; k20 = 6
.line	370	loadk        r22   k21 ; k21 = 254
.line	370	loadk        r23   k22 ; k22 = 223
.line	370	loadk        r24   k23 ; k23 = 136
.line	370	loadk        r25   k24 ; k24 = 74
.line	370	loadk        r26   k25 ; k25 = 245
.line	370	loadk        r27   k26 ; k26 = 47
.line	370	loadk        r28   k27 ; k27 = 230
.line	370	loadk        r29   k28 ; k28 = 49
.line	370	loadk        r30   k29 ; k29 = 147
.line	370	loadk        r31   k30 ; k30 = 40
.line	370	loadk        r32   k31 ; k31 = 167
.line	370	loadk        r33   k32 ; k32 = 214
.line	370	loadk        r34   k33 ; k33 = 218
.line	370	loadk        r35   k34 ; k34 = 118
.line	370	loadk        r36   k35 ; k35 = 78
.line	370	loadk        r37   k36 ; k36 = 29
.line	370	loadk        r38   k33 ; k33 = 218
.line	370	loadk        r39   k37 ; k37 = 228
.line	370	loadk        r40   k38 ; k38 = 148
.line	370	loadk        r41   k39 ; k39 = 127
.line	370	loadk        r42   k40 ; k40 = 178
.line	370	loadk        r43   k41 ; k41 = 51
.line	370	loadk        r44   k42 ; k42 = 249
.line	370	loadk        r45   k43 ; k43 = 27
.line	370	loadk        r46   k44 ; k44 = 138
.line	370	loadk        r47   k30 ; k30 = 40
.line	370	call          r7    41     2
.line	370	getupval      r8    u1
.line	370	loadk         r9   k45 ; k45 = 91
.line	370	loadk        r10   k46 ; k46 = 73
.line	370	loadk        r11   k47 ; k47 = 212
.line	370	loadk        r12    k8 ; k8 = 126
.line	370	loadk        r13   k48 ; k48 = 88
.line	370	loadk        r14   k49 ; k49 = 32
.line	370	loadk        r15   k50 ; k50 = 239
.line	370	loadk        r16   k15 ; k15 = 14
.line	370	loadk        r17   k51 ; k51 = 164
.line	370	loadk        r18   k52 ; k52 = 202
.line	370	loadk        r19   k53 ; k53 = 221
.line	370	loadk        r20   k54 ; k54 = 58
.line	370	loadk        r21   k55 ; k55 = 23
.line	370	loadk        r22   k56 ; k56 = 42
.line	370	loadk        r23   k57 ; k57 = 135
.line	370	loadk        r24   k58 ; k58 = 182
.line	370	loadk        r25   k59 ; k59 = 163
.line	370	loadk        r26   k60 ; k60 = 116
.line	370	loadk        r27   k61 ; k61 = 171
.line	370	loadk        r28   k62 ; k62 = 5
.line	370	loadk        r29   k63 ; k63 = 240
.line	370	loadk        r30   k64 ; k64 = 90
.line	370	loadk        r31   k65 ; k65 = 211
.line	370	loadk        r32   k66 ; k66 = 41
.line	370	call          r8    25     0
.line	370	setlist       r6     0     1
.line	370	call          r5     2     2
.line	370	gettabup      r6    u0   k67 ; k67 = "tostring"
.line	370	move          r7    r1
.line	370	call          r6     2     2
.line	370	gettabup      r7    u0   k67 ; k67 = "tostring"
.line	370	move          r8    r2
.line	370	call          r7     2     0
.line	370	call          r4     0     2
.label	l98
.line	370	call          r3     2     1
.line	370	loadk         r3   k68 ; k68 = 0
.line	370	gettable      r4    r0    k1 ; k1 = "downloaderData"
.line	370	gettable      r4    r4    r2
.line	370	gettable      r5    r4   k69 ; k69 = "bundleIDs"
.line	370	self          r6    r0   k70 ; k70 = "IsRecommendTabData"
.line	370	move          r8    r4
.line	370	call          r6     3     2
.line	370	test          r6     0
.line	370	jmp            0  l115
.line	370	gettabup      r6    u3   k71 ; k71 = "AutoDownloadCfg"
.line	370	gettable      r6    r6   k72 ; k72 = "RecommendType"
.line	370	gettabup      r6    u2    r6
.line	370	newtable      r7     1     0
.line	370	move          r8    r6
.line	370	setlist       r7     1     1
.line	370	move          r5    r7
.label	l115
.line	370	gettabup      r6    u0   k73 ; k73 = "pairs"
.line	370	move          r7    r5
.line	370	call          r6     2     4
.line	370	jmp            0  l147
.line	370	gettable     r11    r0   k74 ; k74 = "bundleData"
.line	370	gettable     r11   r11   r10
.line	370	test         r11     0
.line	370	jmp            0  l135
.line	370	gettabup     r12    u0   k73 ; k73 = "pairs"
.line	370	move         r13   r11
.line	370	call         r12     2     4
.line	370	jmp            0  l133
.line	370	gettable     r17    r0   k75 ; k75 = "deleteKey"
.line	370	gettable     r18   r16   k76 ; k76 = "key"
.line	370	gettable     r17   r17   r18
.line	370	test         r17     0
.line	370	jmp            0  l133
.line	370	add           r3    r3   k77 ; k77 = 1
.label	l133
.line	370	move          r0    r0
.line	370	move          r0    r0
.label	l135
.line	370	gettabup     r12    u4   k78 ; k78 = "GetDownloaderTableDa" (truncated)
.line	370	move         r13   r10
.line	370	call         r12     2     2
.line	370	test         r12     0
.line	370	jmp            0  l147
.line	370	gettable     r13   r12   k79 ; k79 = "TabStyle"
.line	370	gettabup     r14    u5   k80 ; k80 = "BigImage"
.line	370	eq             0   r13   r14
.line	370	jmp            0  l147
.line	370	lt             0   k77    r3 ; k77 = 1
.line	370	jmp            0  l147
.line	370	loadk         r3   k77 ; k77 = 1
.label	l147
.line	370	move          r0    r0
.line	370	move          r0    r0
.line	370	return        r3     2
.line	370	return        r0     1
.line	370	move          r0    r0
.line	370	return        r0     1

.function	main/f12

.source	null
.linedefined	402
.lastlinedefined	406
.numparams	1
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	0	false

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"SetWidgetVisible"
.constant	k4	"UIRoot"
.constant	k5	"Download_Main_Tips_UIBP"
.constant	k6	"UIManager"
.constant	k7	"ShowUI"
.constant	k8	"UI_Config"
.constant	k9	"Download_Setting_UIBP"

.line	402	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	402	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	402	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	402	call          r1     3     1
.line	402	self          r1    r0    k3 ; k3 = "SetWidgetVisible"
.line	402	gettable      r3    r0    k4 ; k4 = "UIRoot"
.line	402	gettable      r3    r3    k5 ; k5 = "Download_Main_Tips_U" (truncated)
.line	402	loadbool      r4     0     0
.line	402	call          r1     4     1
.line	402	gettabup      r1    u0    k6 ; k6 = "UIManager"
.line	402	gettable      r1    r1    k7 ; k7 = "ShowUI"
.line	402	gettabup      r2    u0    k6 ; k6 = "UIManager"
.line	402	gettable      r2    r2    k8 ; k8 = "UI_Config"
.line	402	gettable      r2    r2    k9 ; k9 = "Download_Setting_UIB" (truncated)
.line	402	call          r1     2     1
.line	402	return        r0     1
.line	402	move          r0    r0
.line	402	move          r0    r0
.line	402	return        r0     1

.function	main/f13

.source	null
.linedefined	408
.lastlinedefined	423
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false
.upvalue	"U1"	6	true
.upvalue	"U2"	1	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"IsWoWEditor"
.constant	k4	"GetPufferDeleteManager"
.constant	k5	"ShowDeleteUI"
.constant	k6	"isFitVersion"
.constant	k7	"ShowDownload_Loading_Item_UIBP"
.constant	k8	"UIManager"
.constant	k9	"ShowUI"
.constant	k10	"UI_Config"
.constant	k11	"Download_Cleanup_Popup_UIBP"

.line	408	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	408	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	408	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	408	call          r1     3     1
.line	408	gettabup      r1    u0    k3 ; k3 = "IsWoWEditor"
.line	408	test          r1     0
.line	408	jmp            0   l13
.line	408	self          r1    r0    k4 ; k4 = "GetPufferDeleteManag" (truncated)
.line	408	call          r1     2     2
.line	408	gettable      r2    r1    k5 ; k5 = "ShowDeleteUI"
.line	408	call          r2     1     1
.line	408	jmp            0   l26
.label	l13
.line	408	gettable      r1    r0    k6 ; k6 = "isFitVersion"
.line	408	test          r1     0
.line	408	jmp            0   l20
.line	408	self          r1    r0    k7 ; k7 = "ShowDownload_Loading" (truncated)
.line	408	closure       r3    f0
.line	408	call          r1     3     1
.line	408	jmp            0   l26
.label	l20
.line	408	gettabup      r1    u0    k8 ; k8 = "UIManager"
.line	408	gettable      r1    r1    k9 ; k9 = "ShowUI"
.line	408	gettabup      r2    u0    k8 ; k8 = "UIManager"
.line	408	gettable      r2    r2   k10 ; k10 = "UI_Config"
.line	408	gettable      r2    r2   k11 ; k11 = "Download_Cleanup_Pop" (truncated)
.line	408	call          r1     2     1
.label	l26
.line	408	return        r0     1
.line	408	move          r0    r0
.line	408	move          r0    r0
.line	408	move          r0    r0
.line	408	return        r0     1

.function	main/f13/f0

.source	null
.linedefined	414
.lastlinedefined	419
.numparams	0
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	1	false
.upvalue	"U1"	0	true
.upvalue	"U2"	0	false
.upvalue	"U3"	2	false

.constant	k0	"PauseAllDownloadTasks"
.constant	k1	"GetAllOptionalDeleteSize"
.constant	k2	"log_format"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	126
.constant	k6	69
.constant	k7	200
.constant	k8	62
.constant	k9	20
.constant	k10	56
.constant	k11	231
.constant	k12	14
.constant	k13	156
.constant	k14	226
.constant	k15	110
.constant	k16	92
.constant	k17	6
.constant	k18	254
.constant	k19	223
.constant	k20	136
.constant	k21	74
.constant	k22	245
.constant	k23	47
.constant	k24	230
.constant	k25	36
.constant	k26	154
.constant	k27	51
.constant	k28	176
.constant	k29	212
.constant	k30	251
.constant	k31	98
.constant	k32	86
.constant	k33	61
.constant	k34	232
.constant	k35	133
.constant	k36	78
.constant	k37	186
.constant	k38	28
.constant	k39	253
.constant	k40	3
.constant	k41	131
.constant	k42	100
.constant	k43	26
.constant	k44	75
.constant	k45	211
.constant	k46	60
.constant	k47	50
.constant	k48	234
.constant	k49	15
.constant	k50	183
.constant	k51	202
.constant	k52	250
.constant	k53	72
.constant	k54	150
.constant	k55	179
.constant	k56	185
.constant	k57	"UIManager"
.constant	k58	"ShowUI"
.constant	k59	"UI_Config"
.constant	k60	"Download_Cleanup_Popup_UIBP"
.constant	k61	"maxDeleteSize"

.line	414	gettabup      r0    u0    k0 ; k0 = "PauseAllDownloadTask" (truncated)
.line	414	call          r0     1     1
.line	414	getupval      r0    u1
.line	414	self          r0    r0    k1 ; k1 = "GetAllOptionalDelete" (truncated)
.line	414	call          r0     2     2
.line	414	gettabup      r1    u2    k2 ; k2 = "log_format"
.line	414	gettabup      r2    u2    k3 ; k3 = "table"
.line	414	gettable      r2    r2    k4 ; k4 = "concat"
.line	414	newtable      r3     1     0
.line	414	getupval      r4    u3
.line	414	loadk         r5    k5 ; k5 = 126
.line	414	loadk         r6    k6 ; k6 = 69
.line	414	loadk         r7    k7 ; k7 = 200
.line	414	loadk         r8    k8 ; k8 = 62
.line	414	loadk         r9    k9 ; k9 = 20
.line	414	loadk        r10   k10 ; k10 = 56
.line	414	loadk        r11   k11 ; k11 = 231
.line	414	loadk        r12   k12 ; k12 = 14
.line	414	loadk        r13   k13 ; k13 = 156
.line	414	loadk        r14   k14 ; k14 = 226
.line	414	loadk        r15    k7 ; k7 = 200
.line	414	loadk        r16   k15 ; k15 = 110
.line	414	loadk        r17   k16 ; k16 = 92
.line	414	loadk        r18   k17 ; k17 = 6
.line	414	loadk        r19   k18 ; k18 = 254
.line	414	loadk        r20   k19 ; k19 = 223
.line	414	loadk        r21   k20 ; k20 = 136
.line	414	loadk        r22   k21 ; k21 = 74
.line	414	loadk        r23   k22 ; k22 = 245
.line	414	loadk        r24   k23 ; k23 = 47
.line	414	loadk        r25   k24 ; k24 = 230
.line	414	loadk        r26   k25 ; k25 = 36
.line	414	loadk        r27   k26 ; k26 = 154
.line	414	loadk        r28   k27 ; k27 = 51
.line	414	loadk        r29   k28 ; k28 = 176
.line	414	loadk        r30   k29 ; k29 = 212
.line	414	loadk        r31   k30 ; k30 = 251
.line	414	loadk        r32   k31 ; k31 = 98
.line	414	loadk        r33   k32 ; k32 = 86
.line	414	loadk        r34   k33 ; k33 = 61
.line	414	loadk        r35   k29 ; k29 = 212
.line	414	loadk        r36   k34 ; k34 = 232
.line	414	loadk        r37   k35 ; k35 = 133
.line	414	loadk        r38   k36 ; k36 = 78
.line	414	loadk        r39   k37 ; k37 = 186
.line	414	loadk        r40   k38 ; k38 = 28
.line	414	loadk        r41   k39 ; k39 = 253
.line	414	loadk        r42   k40 ; k40 = 3
.line	414	loadk        r43   k41 ; k41 = 131
.line	414	loadk        r44   k42 ; k42 = 100
.line	414	call          r4    41     2
.line	414	getupval      r5    u3
.line	414	loadk         r6   k43 ; k43 = 26
.line	414	loadk         r7   k44 ; k44 = 75
.line	414	loadk         r8   k45 ; k45 = 211
.line	414	loadk         r9   k46 ; k46 = 60
.line	414	loadk        r10   k46 ; k46 = 60
.line	414	loadk        r11   k47 ; k47 = 50
.line	414	loadk        r12   k48 ; k48 = 234
.line	414	loadk        r13   k49 ; k49 = 15
.line	414	loadk        r14   k50 ; k50 = 183
.line	414	loadk        r15   k51 ; k51 = 202
.line	414	loadk        r16   k52 ; k52 = 250
.line	414	loadk        r17   k15 ; k15 = 110
.line	414	loadk        r18   k53 ; k53 = 72
.line	414	loadk        r19   k46 ; k46 = 60
.line	414	loadk        r20   k54 ; k54 = 150
.line	414	loadk        r21   k55 ; k55 = 179
.line	414	loadk        r22   k56 ; k56 = 185
.line	414	call          r5    18     0
.line	414	setlist       r3     0     1
.line	414	call          r2     2     2
.line	414	move          r3    r0
.line	414	call          r1     3     1
.line	414	gettabup      r1    u2   k57 ; k57 = "UIManager"
.line	414	gettable      r1    r1   k58 ; k58 = "ShowUI"
.line	414	gettabup      r2    u2   k57 ; k57 = "UIManager"
.line	414	gettable      r2    r2   k59 ; k59 = "UI_Config"
.line	414	gettable      r2    r2   k60 ; k60 = "Download_Cleanup_Pop" (truncated)
.line	414	newtable      r3     0     1
.line	414	settable      r3   k61    r0 ; k61 = "maxDeleteSize"
.line	414	call          r1     3     1
.line	414	return        r0     1
.line	414	move          r0    r0
.line	414	move          r0    r0
.line	414	move          r0    r0
.line	414	return        r0     1

.function	main/f14

.source	null
.linedefined	425
.lastlinedefined	428
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"HandleClose"

.line	425	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	425	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	425	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	425	call          r1     3     1
.line	425	self          r1    r0    k3 ; k3 = "HandleClose"
.line	425	call          r1     2     1
.line	425	return        r0     1
.line	425	move          r0    r0
.line	425	return        r0     1

.function	main/f15

.source	null
.linedefined	430
.lastlinedefined	436
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	3	true

.constant	k0	"uiType"
.constant	k1	"Delete"
.constant	k2	"UpdateUIType"
.constant	k3	"View"
.constant	k4	"CloseSelf"

.line	430	gettable      r1    r0    k0 ; k0 = "uiType"
.line	430	gettabup      r2    u0    k1 ; k1 = "Delete"
.line	430	eq             0    r1    r2
.line	430	jmp            0    l9
.line	430	self          r1    r0    k2 ; k2 = "UpdateUIType"
.line	430	gettabup      r3    u0    k3 ; k3 = "View"
.line	430	call          r1     3     1
.line	430	jmp            0   l11
.label	l9
.line	430	self          r1    r0    k4 ; k4 = "CloseSelf"
.line	430	call          r1     2     1
.label	l11
.line	430	return        r0     1
.line	430	move          r0    r0
.line	430	move          r0    r0
.line	430	move          r0    r0
.line	430	move          r0    r0
.line	430	return        r0     1

.function	main/f16

.source	null
.linedefined	438
.lastlinedefined	441
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"ToggleDownloadBundle"

.line	438	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	438	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	438	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	438	call          r1     3     1
.line	438	self          r1    r0    k3 ; k3 = "ToggleDownloadBundle"
.line	438	call          r1     2     1
.line	438	return        r0     1
.line	438	move          r0    r0
.line	438	move          r0    r0
.line	438	move          r0    r0
.line	438	return        r0     1

.function	main/f17

.source	null
.linedefined	443
.lastlinedefined	447
.numparams	3
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	126
.constant	k5	69
.constant	k6	200
.constant	k7	62
.constant	k8	20
.constant	k9	56
.constant	k10	231
.constant	k11	14
.constant	k12	156
.constant	k13	226
.constant	k14	110
.constant	k15	92
.constant	k16	6
.constant	k17	254
.constant	k18	223
.constant	k19	136
.constant	k20	74
.constant	k21	245
.constant	k22	47
.constant	k23	230
.constant	k24	36
.constant	k25	154
.constant	k26	51
.constant	k27	176
.constant	k28	212
.constant	k29	220
.constant	k30	115
.constant	k31	44
.constant	k32	205
.constant	k33	227
.constant	k34	182
.constant	k35	177
.constant	k36	21
.constant	k37	204
.constant	k38	22
.constant	k39	132
.constant	k40	106
.constant	k41	73
.constant	k42	79
.constant	k43	211
.constant	k44	53
.constant	k45	27
.constant	k46	35
.constant	k47	198
.constant	k48	199
.constant	k49	99
.constant	k50	87
.constant	k51	33
.constant	k52	145
.constant	k53	"tostring"
.constant	k54	"PlayAudio"
.constant	k55	"sound_config"
.constant	k56	"tab_v1"
.constant	k57	"SelectTopTab"

.line	443	gettabup      r3    u0    k0 ; k0 = "log"
.line	443	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	443	test          r4     0
.line	443	jmp            0   l74
.line	443	gettabup      r4    u0    k2 ; k2 = "table"
.line	443	gettable      r4    r4    k3 ; k3 = "concat"
.line	443	newtable      r5     1     0
.line	443	getupval      r6    u1
.line	443	loadk         r7    k4 ; k4 = 126
.line	443	loadk         r8    k5 ; k5 = 69
.line	443	loadk         r9    k6 ; k6 = 200
.line	443	loadk        r10    k7 ; k7 = 62
.line	443	loadk        r11    k8 ; k8 = 20
.line	443	loadk        r12    k9 ; k9 = 56
.line	443	loadk        r13   k10 ; k10 = 231
.line	443	loadk        r14   k11 ; k11 = 14
.line	443	loadk        r15   k12 ; k12 = 156
.line	443	loadk        r16   k13 ; k13 = 226
.line	443	loadk        r17    k6 ; k6 = 200
.line	443	loadk        r18   k14 ; k14 = 110
.line	443	loadk        r19   k15 ; k15 = 92
.line	443	loadk        r20   k16 ; k16 = 6
.line	443	loadk        r21   k17 ; k17 = 254
.line	443	loadk        r22   k18 ; k18 = 223
.line	443	loadk        r23   k19 ; k19 = 136
.line	443	loadk        r24   k20 ; k20 = 74
.line	443	loadk        r25   k21 ; k21 = 245
.line	443	loadk        r26   k22 ; k22 = 47
.line	443	loadk        r27   k23 ; k23 = 230
.line	443	loadk        r28   k24 ; k24 = 36
.line	443	loadk        r29   k25 ; k25 = 154
.line	443	loadk        r30   k26 ; k26 = 51
.line	443	loadk        r31   k27 ; k27 = 176
.line	443	loadk        r32   k28 ; k28 = 212
.line	443	loadk        r33   k29 ; k29 = 220
.line	443	loadk        r34   k30 ; k30 = 115
.line	443	loadk        r35   k14 ; k14 = 110
.line	443	loadk        r36   k31 ; k31 = 44
.line	443	loadk        r37   k32 ; k32 = 205
.line	443	loadk        r38   k33 ; k33 = 227
.line	443	loadk        r39   k34 ; k34 = 182
.line	443	loadk        r40    k5 ; k5 = 69
.line	443	loadk        r41   k35 ; k35 = 177
.line	443	loadk        r42   k36 ; k36 = 21
.line	443	loadk        r43   k37 ; k37 = 204
.line	443	loadk        r44   k38 ; k38 = 22
.line	443	loadk        r45   k39 ; k39 = 132
.line	443	loadk        r46   k40 ; k40 = 106
.line	443	call          r6    41     2
.line	443	getupval      r7    u1
.line	443	loadk         r8   k41 ; k41 = 73
.line	443	loadk         r9   k42 ; k42 = 79
.line	443	loadk        r10   k43 ; k43 = 211
.line	443	loadk        r11   k44 ; k44 = 53
.line	443	loadk        r12   k45 ; k45 = 27
.line	443	loadk        r13   k46 ; k46 = 35
.line	443	loadk        r14   k33 ; k33 = 227
.line	443	loadk        r15   k11 ; k11 = 14
.line	443	loadk        r16   k33 ; k33 = 227
.line	443	loadk        r17   k47 ; k47 = 198
.line	443	loadk        r18   k48 ; k48 = 199
.line	443	loadk        r19   k49 ; k49 = 99
.line	443	loadk        r20   k50 ; k50 = 87
.line	443	loadk        r21   k51 ; k51 = 33
.line	443	loadk        r22   k52 ; k52 = 145
.line	443	loadk        r23   k34 ; k34 = 182
.line	443	call          r7    17     0
.line	443	setlist       r5     0     1
.line	443	call          r4     2     2
.line	443	gettabup      r5    u0   k53 ; k53 = "tostring"
.line	443	move          r6    r2
.line	443	call          r5     2     2
.line	443	concat        r4    r4    r5
.label	l74
.line	443	call          r3     2     1
.line	443	self          r3    r0   k54 ; k54 = "PlayAudio"
.line	443	gettabup      r5    u0   k55 ; k55 = "sound_config"
.line	443	gettable      r5    r5   k56 ; k56 = "tab_v1"
.line	443	call          r3     3     1
.line	443	self          r3    r0   k57 ; k57 = "SelectTopTab"
.line	443	move          r5    r2
.line	443	call          r3     3     1
.line	443	return        r0     1
.line	443	move          r0    r0
.line	443	return        r0     1

.function	main/f18

.source	null
.linedefined	449
.lastlinedefined	452
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"UIManager"
.constant	k4	"ShowUI"
.constant	k5	"UI_Config"
.constant	k6	"Download_Setting_UIBP"

.line	449	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	449	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	449	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	449	call          r1     3     1
.line	449	gettabup      r1    u0    k3 ; k3 = "UIManager"
.line	449	gettable      r1    r1    k4 ; k4 = "ShowUI"
.line	449	gettabup      r2    u0    k3 ; k3 = "UIManager"
.line	449	gettable      r2    r2    k5 ; k5 = "UI_Config"
.line	449	gettable      r2    r2    k6 ; k6 = "Download_Setting_UIB" (truncated)
.line	449	call          r1     2     1
.line	449	return        r0     1
.line	449	move          r0    r0
.line	449	return        r0     1

.function	main/f19

.source	null
.linedefined	454
.lastlinedefined	457
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false
.upvalue	"U1"	3	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"UpdateUIType"
.constant	k4	"View"

.line	454	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	454	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	454	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	454	call          r1     3     1
.line	454	self          r1    r0    k3 ; k3 = "UpdateUIType"
.line	454	gettabup      r3    u1    k4 ; k4 = "View"
.line	454	call          r1     3     1
.line	454	return        r0     1
.line	454	move          r0    r0
.line	454	move          r0    r0
.line	454	move          r0    r0
.line	454	return        r0     1

.function	main/f20

.source	null
.linedefined	459
.lastlinedefined	475
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	5	true
.upvalue	"U2"	1	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"Enum_BundleID"
.constant	k4	"Recommend"
.constant	k5	"PufferDownloader"
.constant	k6	"DownloadRewardCfg"
.constant	k7	"showPrefetchReddot"
.constant	k8	"require"
.constant	k9	"table"
.constant	k10	"concat"
.constant	k11	89
.constant	k12	70
.constant	k13	214
.constant	k14	53
.constant	k15	22
.constant	k16	35
.constant	k17	168
.constant	k18	4
.constant	k19	166
.constant	k20	219
.constant	k21	222
.constant	k22	104
.constant	k23	64
.constant	k24	50
.constant	k25	133
.constant	k26	198
.constant	k27	184
.constant	k28	117
.constant	k29	187
.constant	k30	15
.constant	k31	235
.constant	k32	8
.constant	k33	154
.constant	k34	116
.constant	k35	131
.constant	k36	202
.constant	k37	223
.constant	k38	113
.constant	k39	71
.constant	k40	59
.constant	k41	255
.constant	k42	233
.constant	k43	173
.constant	k44	100
.constant	k45	179
.constant	k46	31
.constant	k47	249
.constant	k48	19
.constant	k49	174
.constant	k50	43
.constant	k51	84
.constant	k52	78
.constant	k53	211
.constant	k54	10
.constant	k55	"send_mini_client_reward_get_req"
.constant	k56	"itemid1"
.constant	k57	nil
.constant	k58	"UIManager"
.constant	k59	"ShowUI"
.constant	k60	"UI_Config"
.constant	k61	"package_preview_panel"

.line	459	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	459	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	459	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	459	call          r1     3     1
.line	459	gettabup      r1    u1    k3 ; k3 = "Enum_BundleID"
.line	459	gettable      r1    r1    k4 ; k4 = "Recommend"
.line	459	gettabup      r2    u0    k5 ; k5 = "PufferDownloader"
.line	459	gettable      r2    r2    k6 ; k6 = "DownloadRewardCfg"
.line	459	gettable      r2    r2    r1
.line	459	test          r2     1
.line	459	jmp            0   l13
.line	459	return        r0     1
.label	l13
.line	459	gettable      r2    r0    k7 ; k7 = "showPrefetchReddot"
.line	459	test          r2     0
.line	459	jmp            0   l76
.line	459	gettabup      r2    u0    k8 ; k8 = "require"
.line	459	gettabup      r3    u0    k9 ; k9 = "table"
.line	459	gettable      r3    r3   k10 ; k10 = "concat"
.line	459	newtable      r4     1     0
.line	459	getupval      r5    u2
.line	459	loadk         r6   k11 ; k11 = 89
.line	459	loadk         r7   k12 ; k12 = 70
.line	459	loadk         r8   k13 ; k13 = 214
.line	459	loadk         r9   k14 ; k14 = 53
.line	459	loadk        r10   k15 ; k15 = 22
.line	459	loadk        r11   k16 ; k16 = 35
.line	459	loadk        r12   k17 ; k17 = 168
.line	459	loadk        r13   k18 ; k18 = 4
.line	459	loadk        r14   k19 ; k19 = 166
.line	459	loadk        r15   k20 ; k20 = 219
.line	459	loadk        r16   k21 ; k21 = 222
.line	459	loadk        r17   k22 ; k22 = 104
.line	459	loadk        r18   k23 ; k23 = 64
.line	459	loadk        r19   k24 ; k24 = 50
.line	459	loadk        r20   k25 ; k25 = 133
.line	459	loadk        r21   k26 ; k26 = 198
.line	459	loadk        r22   k27 ; k27 = 184
.line	459	loadk        r23   k28 ; k28 = 117
.line	459	loadk        r24   k29 ; k29 = 187
.line	459	loadk        r25   k30 ; k30 = 15
.line	459	loadk        r26   k31 ; k31 = 235
.line	459	loadk        r27   k32 ; k32 = 8
.line	459	loadk        r28   k33 ; k33 = 154
.line	459	loadk        r29   k34 ; k34 = 116
.line	459	loadk        r30   k35 ; k35 = 131
.line	459	loadk        r31   k36 ; k36 = 202
.line	459	loadk        r32   k37 ; k37 = 223
.line	459	loadk        r33   k38 ; k38 = 113
.line	459	loadk        r34   k39 ; k39 = 71
.line	459	loadk        r35   k40 ; k40 = 59
.line	459	loadk        r36   k41 ; k41 = 255
.line	459	loadk        r37   k42 ; k42 = 233
.line	459	loadk        r38   k43 ; k43 = 173
.line	459	loadk        r39   k44 ; k44 = 100
.line	459	loadk        r40   k45 ; k45 = 179
.line	459	loadk        r41   k46 ; k46 = 31
.line	459	loadk        r42   k47 ; k47 = 249
.line	459	loadk        r43   k48 ; k48 = 19
.line	459	loadk        r44   k49 ; k49 = 174
.line	459	loadk        r45   k50 ; k50 = 43
.line	459	call          r5    41     2
.line	459	getupval      r6    u2
.line	459	loadk         r7   k51 ; k51 = 84
.line	459	loadk         r8   k52 ; k52 = 78
.line	459	loadk         r9   k53 ; k53 = 211
.line	459	loadk        r10   k14 ; k14 = 53
.line	459	loadk        r11   k54 ; k54 = 10
.line	459	call          r6     6     0
.line	459	setlist       r4     0     1
.line	459	call          r3     2     2
.line	459	call          r2     2     2
.line	459	gettable      r3    r2   k55 ; k55 = "send_mini_client_rew" (truncated)
.line	459	move          r4    r1
.line	459	call          r3     2     1
.line	459	jmp            0   l90
.label	l76
.line	459	gettabup      r2    u0    k5 ; k5 = "PufferDownloader"
.line	459	gettable      r2    r2    k6 ; k6 = "DownloadRewardCfg"
.line	459	gettable      r2    r2    r1
.line	459	gettable      r2    r2   k56 ; k56 = "itemid1"
.line	459	eq             0    r2   k57 ; k57 = nil
.line	459	jmp            0   l83
.line	459	return        r0     1
.label	l83
.line	459	gettabup      r3    u0   k58 ; k58 = "UIManager"
.line	459	gettable      r3    r3   k59 ; k59 = "ShowUI"
.line	459	gettabup      r4    u0   k58 ; k58 = "UIManager"
.line	459	gettable      r4    r4   k60 ; k60 = "UI_Config"
.line	459	gettable      r4    r4   k61 ; k61 = "package_preview_pane" (truncated)
.line	459	move          r5    r2
.line	459	call          r3     3     1
.label	l90
.line	459	return        r0     1
.line	459	move          r0    r0
.line	459	move          r0    r0
.line	459	return        r0     1

.function	main/f21

.source	null
.linedefined	477
.lastlinedefined	480
.numparams	2
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	0	false
.upvalue	"U1"	9	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"toggle_v1"
.constant	k3	"SetAutoDownload"

.line	477	self          r2    r0    k0 ; k0 = "PlayAudio"
.line	477	gettabup      r4    u0    k1 ; k1 = "sound_config"
.line	477	gettable      r4    r4    k2 ; k2 = "toggle_v1"
.line	477	call          r2     3     1
.line	477	gettabup      r2    u1    k3 ; k3 = "SetAutoDownload"
.line	477	move          r3    r1
.line	477	call          r2     2     1
.line	477	return        r0     1
.line	477	move          r0    r0
.line	477	move          r0    r0
.line	477	move          r0    r0
.line	477	move          r0    r0
.line	477	return        r0     1

.function	main/f22

.source	null
.linedefined	482
.lastlinedefined	489
.numparams	1
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	9	true

.constant	k0	"showDownloadIconCheckBox"
.constant	k1	"IsViewMode"
.constant	k2	"SetWidgetVisible"
.constant	k3	"UIRoot"
.constant	k4	"CanvasPanel_IconAutoSet"
.constant	k5	"CheckBox_IconAutoSet"
.constant	k6	"SetIsChecked"
.constant	k7	"AutoDownloadCfg"
.constant	k8	"AutoDownloadIconSwitch"

.line	482	gettable      r1    r0    k0 ; k0 = "showDownloadIconChec" (truncated)
.line	482	test          r1     0
.line	482	jmp            0    l6
.line	482	self          r1    r0    k1 ; k1 = "IsViewMode"
.line	482	call          r1     2     2
.label	l6
.line	482	self          r2    r0    k2 ; k2 = "SetWidgetVisible"
.line	482	gettable      r4    r0    k3 ; k3 = "UIRoot"
.line	482	gettable      r4    r4    k4 ; k4 = "CanvasPanel_IconAuto" (truncated)
.line	482	move          r5    r1
.line	482	loadbool      r6     0     0
.line	482	call          r2     5     1
.line	482	test          r1     1
.line	482	jmp            0   l15
.line	482	return        r0     1
.label	l15
.line	482	gettable      r2    r0    k3 ; k3 = "UIRoot"
.line	482	gettable      r2    r2    k5 ; k5 = "CheckBox_IconAutoSet"
.line	482	self          r2    r2    k6 ; k6 = "SetIsChecked"
.line	482	gettabup      r4    u0    k7 ; k7 = "AutoDownloadCfg"
.line	482	gettable      r4    r4    k8 ; k8 = "AutoDownloadIconSwit" (truncated)
.line	482	call          r2     3     1
.line	482	return        r0     1
.line	482	move          r0    r0
.line	482	return        r0     1

.function	main/f23

.source	null
.linedefined	491
.lastlinedefined	497
.numparams	1
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	false
.upvalue	"U1"	13	true
.upvalue	"U2"	11	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"ToggleDownloadBundle"
.constant	k4	"downloaderData"
.constant	k5	"curVerTabIndex"
.constant	k6	"tabIDs"
.constant	k7	"topTabIndex"
.constant	k8	"sumDownloadData"
.constant	k9	"state"
.constant	k10	"Download"
.constant	k11	"ReportDownloadMainUIDownloadPage"

.line	491	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	491	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	491	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	491	call          r1     3     1
.line	491	self          r1    r0    k3 ; k3 = "ToggleDownloadBundle"
.line	491	call          r1     2     1
.line	491	gettable      r1    r0    k4 ; k4 = "downloaderData"
.line	491	gettable      r2    r0    k5 ; k5 = "curVerTabIndex"
.line	491	gettable      r1    r1    r2
.line	491	gettable      r1    r1    k6 ; k6 = "tabIDs"
.line	491	gettable      r2    r0    k7 ; k7 = "topTabIndex"
.line	491	gettable      r1    r1    r2
.line	491	gettable      r2    r0    k8 ; k8 = "sumDownloadData"
.line	491	gettable      r2    r2    k9 ; k9 = "state"
.line	491	gettabup      r3    u1   k10 ; k10 = "Download"
.line	491	eq             1    r2    r3
.line	491	jmp            0   l19
.line	491	loadbool      r2     0     1
.label	l19
.line	491	loadbool      r2     1     0
.line	491	gettabup      r3    u2   k11 ; k11 = "ReportDownloadMainUI" (truncated)
.line	491	move          r4    r1
.line	491	move          r5    r2
.line	491	call          r3     3     1
.line	491	return        r0     1
.line	491	move          r0    r0
.line	491	return        r0     1

.function	main/f24

.source	null
.linedefined	499
.lastlinedefined	502
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"ShowNotice"
.constant	k4	83246

.line	499	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	499	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	499	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	499	call          r1     3     1
.line	499	gettabup      r1    u0    k3 ; k3 = "ShowNotice"
.line	499	loadk         r2    k4 ; k4 = 83246
.line	499	call          r1     2     1
.line	499	return        r0     1
.line	499	move          r0    r0
.line	499	move          r0    r0
.line	499	move          r0    r0
.line	499	return        r0     1

.function	main/f25

.source	null
.linedefined	504
.lastlinedefined	515
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	13	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"sumDownloadData"
.constant	k1	"state"
.constant	k2	"Download"
.constant	k3	"showTabData"
.constant	k4	"log"
.constant	k5	"bWriteLog"
.constant	k6	"table"
.constant	k7	"concat"
.constant	k8	126
.constant	k9	69
.constant	k10	200
.constant	k11	62
.constant	k12	20
.constant	k13	56
.constant	k14	231
.constant	k15	14
.constant	k16	156
.constant	k17	226
.constant	k18	110
.constant	k19	92
.constant	k20	6
.constant	k21	254
.constant	k22	223
.constant	k23	136
.constant	k24	74
.constant	k25	245
.constant	k26	52
.constant	k27	0
.constant	k28	145
.constant	k29	54
.constant	k30	182
.constant	k31	251
.constant	k32	214
.constant	k33	96
.constant	k34	76
.constant	k35	37
.constant	k36	212
.constant	k37	190
.constant	k38	72
.constant	k39	170
.constant	k40	30
.constant	k41	252
.constant	k42	27
.constant	k43	131
.constant	k44	100
.constant	k45	26
.constant	k46	78
.constant	k47	222
.constant	k48	36
.constant	k49	25
.constant	k50	119
.constant	k51	239
.constant	k52	227
.constant	k53	193
.constant	k54	192
.constant	k55	107
.constant	k56	"ToggleDownload"
.constant	k57	"ModuleManager"
.constant	k58	"GetModule"
.constant	k59	"CommonModuleConfig"
.constant	k60	"puffer_queue"
.constant	k61	"StartDownload"

.line	504	gettable      r1    r0    k0 ; k0 = "sumDownloadData"
.line	504	gettable      r1    r1    k1 ; k1 = "state"
.line	504	gettabup      r2    u0    k2 ; k2 = "Download"
.line	504	eq             1    r1    r2
.line	504	jmp            0    l7
.line	504	loadbool      r1     0     1
.label	l7
.line	504	loadbool      r1     1     0
.line	504	gettable      r2    r0    k3 ; k3 = "showTabData"
.line	504	test          r2     1
.line	504	jmp            0   l78
.line	504	gettabup      r2    u1    k4 ; k4 = "log"
.line	504	gettabup      r3    u1    k5 ; k5 = "bWriteLog"
.line	504	test          r3     0
.line	504	jmp            0   l76
.line	504	gettabup      r3    u1    k6 ; k6 = "table"
.line	504	gettable      r3    r3    k7 ; k7 = "concat"
.line	504	newtable      r4     1     0
.line	504	getupval      r5    u2
.line	504	loadk         r6    k8 ; k8 = 126
.line	504	loadk         r7    k9 ; k9 = 69
.line	504	loadk         r8   k10 ; k10 = 200
.line	504	loadk         r9   k11 ; k11 = 62
.line	504	loadk        r10   k12 ; k12 = 20
.line	504	loadk        r11   k13 ; k13 = 56
.line	504	loadk        r12   k14 ; k14 = 231
.line	504	loadk        r13   k15 ; k15 = 14
.line	504	loadk        r14   k16 ; k16 = 156
.line	504	loadk        r15   k17 ; k17 = 226
.line	504	loadk        r16   k10 ; k10 = 200
.line	504	loadk        r17   k18 ; k18 = 110
.line	504	loadk        r18   k19 ; k19 = 92
.line	504	loadk        r19   k20 ; k20 = 6
.line	504	loadk        r20   k21 ; k21 = 254
.line	504	loadk        r21   k22 ; k22 = 223
.line	504	loadk        r22   k23 ; k23 = 136
.line	504	loadk        r23   k24 ; k24 = 74
.line	504	loadk        r24   k25 ; k25 = 245
.line	504	loadk        r25   k26 ; k26 = 52
.line	504	loadk        r26   k14 ; k14 = 231
.line	504	loadk        r27   k27 ; k27 = 0
.line	504	loadk        r28   k28 ; k28 = 145
.line	504	loadk        r29   k29 ; k29 = 54
.line	504	loadk        r30   k30 ; k30 = 182
.line	504	loadk        r31   k31 ; k31 = 251
.line	504	loadk        r32   k32 ; k32 = 214
.line	504	loadk        r33   k33 ; k33 = 96
.line	504	loadk        r34   k34 ; k34 = 76
.line	504	loadk        r35   k35 ; k35 = 37
.line	504	loadk        r36   k36 ; k36 = 212
.line	504	loadk        r37   k14 ; k14 = 231
.line	504	loadk        r38   k37 ; k37 = 190
.line	504	loadk        r39   k38 ; k38 = 72
.line	504	loadk        r40   k39 ; k39 = 170
.line	504	loadk        r41   k40 ; k40 = 30
.line	504	loadk        r42   k41 ; k41 = 252
.line	504	loadk        r43   k42 ; k42 = 27
.line	504	loadk        r44   k43 ; k43 = 131
.line	504	loadk        r45   k44 ; k44 = 100
.line	504	call          r5    41     2
.line	504	getupval      r6    u2
.line	504	loadk         r7   k45 ; k45 = 26
.line	504	loadk         r8   k46 ; k46 = 78
.line	504	loadk         r9   k47 ; k47 = 222
.line	504	loadk        r10   k48 ; k48 = 36
.line	504	loadk        r11   k49 ; k49 = 25
.line	504	loadk        r12   k50 ; k50 = 119
.line	504	loadk        r13   k51 ; k51 = 239
.line	504	loadk        r14   k49 ; k49 = 25
.line	504	loadk        r15   k52 ; k52 = 227
.line	504	loadk        r16   k53 ; k53 = 193
.line	504	loadk        r17   k54 ; k54 = 192
.line	504	loadk        r18   k55 ; k55 = 107
.line	504	call          r6    13     0
.line	504	setlist       r4     0     1
.line	504	call          r3     2     2
.label	l76
.line	504	call          r2     2     1
.line	504	return        r0     1
.label	l78
.line	504	self          r2    r0   k56 ; k56 = "ToggleDownload"
.line	504	gettable      r4    r0    k3 ; k3 = "showTabData"
.line	504	move          r5    r1
.line	504	call          r2     4     1
.line	504	test          r1     0
.line	504	jmp            0   l92
.line	504	gettabup      r2    u1   k57 ; k57 = "ModuleManager"
.line	504	gettable      r2    r2   k58 ; k58 = "GetModule"
.line	504	gettabup      r3    u1   k57 ; k57 = "ModuleManager"
.line	504	gettable      r3    r3   k59 ; k59 = "CommonModuleConfig"
.line	504	gettable      r3    r3   k60 ; k60 = "puffer_queue"
.line	504	call          r2     2     2
.line	504	self          r3    r2   k61 ; k61 = "StartDownload"
.line	504	call          r3     2     1
.label	l92
.line	504	return        r0     1
.line	504	move          r0    r0
.line	504	return        r0     1

.function	main/f26

.source	null
.linedefined	517
.lastlinedefined	541
.numparams	3
.is_vararg	0
.maxstacksize	54

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	7	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	126
.constant	k7	69
.constant	k8	200
.constant	k9	62
.constant	k10	20
.constant	k11	56
.constant	k12	231
.constant	k13	14
.constant	k14	156
.constant	k15	226
.constant	k16	110
.constant	k17	92
.constant	k18	6
.constant	k19	254
.constant	k20	223
.constant	k21	136
.constant	k22	74
.constant	k23	245
.constant	k24	52
.constant	k25	0
.constant	k26	145
.constant	k27	54
.constant	k28	182
.constant	k29	251
.constant	k30	214
.constant	k31	96
.constant	k32	76
.constant	k33	37
.constant	k34	212
.constant	k35	190
.constant	k36	36
.constant	k37	255
.constant	k38	249
.constant	k39	3
.constant	k40	135
.constant	k41	119
.constant	k42	31
.constant	k43	89
.constant	k44	147
.constant	k45	112
.constant	k46	17
.constant	k47	194
.constant	k48	5
.constant	k49	180
.constant	k50	193
.constant	k51	197
.constant	k52	104
.constant	k53	83
.constant	k54	61
.constant	k55	248
.constant	k56	173
.constant	k57	39
.constant	k58	234
.constant	k59	19
.constant	k60	"tostring"
.constant	k61	"isFitVersion"
.constant	k62	1
.constant	k63	-1
.constant	k64	"GetItemData"
.constant	k65	"ToggleDownloadItemData"
.constant	k66	"fitDepends"
.constant	k67	"ipairs"
.constant	k68	true
.constant	k69	"pairs"
.constant	k70	"log_format"
.constant	k71	253
.constant	k72	7
.constant	k73	131
.constant	k74	94
.constant	k75	97
.constant	k76	218
.constant	k77	41
.constant	k78	114
.constant	k79	70
.constant	k80	227
.constant	k81	198
.constant	k82	67
.constant	k83	93
.constant	k84	46
.constant	k85	250
.constant	k86	165
.constant	k87	123
.constant	k88	171
.constant	k89	9
.constant	k90	230
.constant	k91	203
.constant	k92	127
.constant	k93	160
.constant	k94	"ChooseStopDownloadByType"
.constant	k95	"ChooseDownloadByType"

.line	517	gettabup      r3    u0    k0 ; k0 = "log"
.line	517	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	517	test          r4     0
.line	517	jmp            0   l83
.line	517	gettabup      r4    u0    k2 ; k2 = "string"
.line	517	gettable      r4    r4    k3 ; k3 = "format"
.line	517	gettabup      r5    u0    k4 ; k4 = "table"
.line	517	gettable      r5    r5    k5 ; k5 = "concat"
.line	517	newtable      r6     1     0
.line	517	getupval      r7    u1
.line	517	loadk         r8    k6 ; k6 = 126
.line	517	loadk         r9    k7 ; k7 = 69
.line	517	loadk        r10    k8 ; k8 = 200
.line	517	loadk        r11    k9 ; k9 = 62
.line	517	loadk        r12   k10 ; k10 = 20
.line	517	loadk        r13   k11 ; k11 = 56
.line	517	loadk        r14   k12 ; k12 = 231
.line	517	loadk        r15   k13 ; k13 = 14
.line	517	loadk        r16   k14 ; k14 = 156
.line	517	loadk        r17   k15 ; k15 = 226
.line	517	loadk        r18    k8 ; k8 = 200
.line	517	loadk        r19   k16 ; k16 = 110
.line	517	loadk        r20   k17 ; k17 = 92
.line	517	loadk        r21   k18 ; k18 = 6
.line	517	loadk        r22   k19 ; k19 = 254
.line	517	loadk        r23   k20 ; k20 = 223
.line	517	loadk        r24   k21 ; k21 = 136
.line	517	loadk        r25   k22 ; k22 = 74
.line	517	loadk        r26   k23 ; k23 = 245
.line	517	loadk        r27   k24 ; k24 = 52
.line	517	loadk        r28   k12 ; k12 = 231
.line	517	loadk        r29   k25 ; k25 = 0
.line	517	loadk        r30   k26 ; k26 = 145
.line	517	loadk        r31   k27 ; k27 = 54
.line	517	loadk        r32   k28 ; k28 = 182
.line	517	loadk        r33   k29 ; k29 = 251
.line	517	loadk        r34   k30 ; k30 = 214
.line	517	loadk        r35   k31 ; k31 = 96
.line	517	loadk        r36   k32 ; k32 = 76
.line	517	loadk        r37   k33 ; k33 = 37
.line	517	loadk        r38   k34 ; k34 = 212
.line	517	loadk        r39   k12 ; k12 = 231
.line	517	loadk        r40   k35 ; k35 = 190
.line	517	loadk        r41   k36 ; k36 = 36
.line	517	loadk        r42   k37 ; k37 = 255
.line	517	loadk        r43   k10 ; k10 = 20
.line	517	loadk        r44   k38 ; k38 = 249
.line	517	loadk        r45   k39 ; k39 = 3
.line	517	loadk        r46   k40 ; k40 = 135
.line	517	loadk        r47   k41 ; k41 = 119
.line	517	call          r7    41     2
.line	517	getupval      r8    u1
.line	517	loadk         r9   k42 ; k42 = 31
.line	517	loadk        r10   k43 ; k43 = 89
.line	517	loadk        r11   k44 ; k44 = 147
.line	517	loadk        r12   k45 ; k45 = 112
.line	517	loadk        r13   k46 ; k46 = 17
.line	517	loadk        r14   k36 ; k36 = 36
.line	517	loadk        r15   k47 ; k47 = 194
.line	517	loadk        r16   k48 ; k48 = 5
.line	517	loadk        r17   k49 ; k49 = 180
.line	517	loadk        r18   k50 ; k50 = 193
.line	517	loadk        r19   k51 ; k51 = 197
.line	517	loadk        r20   k52 ; k52 = 104
.line	517	loadk        r21   k53 ; k53 = 83
.line	517	loadk        r22   k54 ; k54 = 61
.line	517	loadk        r23   k47 ; k47 = 194
.line	517	loadk        r24   k55 ; k55 = 248
.line	517	loadk        r25   k56 ; k56 = 173
.line	517	loadk        r26   k57 ; k57 = 39
.line	517	loadk        r27   k58 ; k58 = 234
.line	517	loadk        r28   k59 ; k59 = 19
.line	517	call          r8    21     0
.line	517	setlist       r6     0     1
.line	517	call          r5     2     2
.line	517	gettabup      r6    u0   k60 ; k60 = "tostring"
.line	517	move          r7    r1
.line	517	call          r6     2     2
.line	517	gettabup      r7    u0   k60 ; k60 = "tostring"
.line	517	move          r8    r2
.line	517	call          r7     2     0
.line	517	call          r4     0     2
.label	l83
.line	517	call          r3     2     1
.line	517	len           r3    r1
.line	517	gettable      r4    r0   k61 ; k61 = "isFitVersion"
.line	517	test          r4     0
.line	517	jmp            0   l91
.line	517	newtable      r4     0     0
.line	517	test          r4     1
.line	517	jmp            0   l92
.label	l91
.line	517	loadnil       r4     0
.label	l92
.line	517	move          r5    r3
.line	517	loadk         r6   k62 ; k62 = 1
.line	517	loadk         r7   k63 ; k63 = -1
.line	517	move          r0    r0
.line	517	gettable      r9    r1    r8
.line	517	self         r10    r0   k64 ; k64 = "GetItemData"
.line	517	move         r12    r9
.line	517	call         r10     3     2
.line	517	move          r9   r10
.line	517	self         r10    r0   k65 ; k65 = "ToggleDownloadItemDa" (truncated)
.line	517	move         r12    r9
.line	517	move         r13    r2
.line	517	call         r10     4     1
.line	517	test          r4     0
.line	517	jmp            0  l117
.line	517	gettable     r10    r9   k66 ; k66 = "fitDepends"
.line	517	test         r10     0
.line	517	jmp            0  l117
.line	517	gettabup     r10    u0   k67 ; k67 = "ipairs"
.line	517	gettable     r11    r9   k66 ; k66 = "fitDepends"
.line	517	call         r10     2     4
.line	517	jmp            0  l115
.line	517	settable      r4   r14   k68 ; k68 = true
.label	l115
.line	517	move          r0    r0
.line	517	move          r0    r0
.label	l117
.line	517	move          r0    r0
.line	517	test          r4     0
.line	517	jmp            0  l215
.line	517	gettabup      r5    u0   k69 ; k69 = "pairs"
.line	517	move          r6    r4
.line	517	call          r5     2     4
.line	517	jmp            0  l213
.line	517	gettabup     r10    u0   k70 ; k70 = "log_format"
.line	517	gettabup     r11    u0    k4 ; k4 = "table"
.line	517	gettable     r11   r11    k5 ; k5 = "concat"
.line	517	newtable     r12     1     0
.line	517	getupval     r13    u1
.line	517	loadk        r14    k6 ; k6 = 126
.line	517	loadk        r15    k7 ; k7 = 69
.line	517	loadk        r16    k8 ; k8 = 200
.line	517	loadk        r17    k9 ; k9 = 62
.line	517	loadk        r18   k10 ; k10 = 20
.line	517	loadk        r19   k11 ; k11 = 56
.line	517	loadk        r20   k12 ; k12 = 231
.line	517	loadk        r21   k13 ; k13 = 14
.line	517	loadk        r22   k14 ; k14 = 156
.line	517	loadk        r23   k15 ; k15 = 226
.line	517	loadk        r24    k8 ; k8 = 200
.line	517	loadk        r25   k16 ; k16 = 110
.line	517	loadk        r26   k17 ; k17 = 92
.line	517	loadk        r27   k18 ; k18 = 6
.line	517	loadk        r28   k19 ; k19 = 254
.line	517	loadk        r29   k20 ; k20 = 223
.line	517	loadk        r30   k21 ; k21 = 136
.line	517	loadk        r31   k22 ; k22 = 74
.line	517	loadk        r32   k23 ; k23 = 245
.line	517	loadk        r33   k24 ; k24 = 52
.line	517	loadk        r34   k12 ; k12 = 231
.line	517	loadk        r35   k25 ; k25 = 0
.line	517	loadk        r36   k26 ; k26 = 145
.line	517	loadk        r37   k27 ; k27 = 54
.line	517	loadk        r38   k28 ; k28 = 182
.line	517	loadk        r39   k29 ; k29 = 251
.line	517	loadk        r40   k30 ; k30 = 214
.line	517	loadk        r41   k31 ; k31 = 96
.line	517	loadk        r42   k32 ; k32 = 76
.line	517	loadk        r43   k33 ; k33 = 37
.line	517	loadk        r44   k34 ; k34 = 212
.line	517	loadk        r45   k12 ; k12 = 231
.line	517	loadk        r46   k35 ; k35 = 190
.line	517	loadk        r47   k36 ; k36 = 36
.line	517	loadk        r48   k37 ; k37 = 255
.line	517	loadk        r49   k10 ; k10 = 20
.line	517	loadk        r50   k71 ; k71 = 253
.line	517	loadk        r51   k72 ; k72 = 7
.line	517	loadk        r52   k73 ; k73 = 131
.line	517	loadk        r53   k36 ; k36 = 36
.line	517	call         r13    41     2
.line	517	getupval     r14    u1
.line	517	loadk        r15   k74 ; k74 = 94
.line	517	loadk        r16   k75 ; k75 = 97
.line	517	loadk        r17   k76 ; k76 = 218
.line	517	loadk        r18   k77 ; k77 = 41
.line	517	loadk        r19    k7 ; k7 = 69
.line	517	loadk        r20   k78 ; k78 = 114
.line	517	loadk        r21   k23 ; k23 = 245
.line	517	loadk        r22   k79 ; k79 = 70
.line	517	loadk        r23   k80 ; k80 = 227
.line	517	loadk        r24   k81 ; k81 = 198
.line	517	loadk        r25   k76 ; k76 = 218
.line	517	loadk        r26   k82 ; k82 = 67
.line	517	loadk        r27   k83 ; k83 = 93
.line	517	loadk        r28   k84 ; k84 = 46
.line	517	loadk        r29   k51 ; k51 = 197
.line	517	loadk        r30   k85 ; k85 = 250
.line	517	loadk        r31   k86 ; k86 = 165
.line	517	loadk        r32   k87 ; k87 = 123
.line	517	loadk        r33   k88 ; k88 = 171
.line	517	loadk        r34   k89 ; k89 = 9
.line	517	loadk        r35   k90 ; k90 = 230
.line	517	loadk        r36   k25 ; k25 = 0
.line	517	loadk        r37   k91 ; k91 = 203
.line	517	loadk        r38   k92 ; k92 = 127
.line	517	loadk        r39   k93 ; k93 = 160
.line	517	call         r14    26     0
.line	517	setlist      r12     0     1
.line	517	call         r11     2     2
.line	517	move         r12    r8
.line	517	move         r13    r2
.line	517	call         r10     4     1
.line	517	test          r2     0
.line	517	jmp            0  l208
.line	517	gettabup     r10    u2   k94 ; k94 = "ChooseStopDownloadBy" (truncated)
.line	517	move         r11    r8
.line	517	call         r10     2     1
.line	517	jmp            0  l213
.label	l208
.line	517	gettabup     r10    u2   k95 ; k95 = "ChooseDownloadByType"
.line	517	move         r11    r8
.line	517	loadnil      r12     1
.line	517	gettable     r14    r0   k61 ; k61 = "isFitVersion"
.line	517	call         r10     5     1
.label	l213
.line	517	move          r0    r0
.line	517	move          r0    r0
.label	l215
.line	517	return        r0     1
.line	517	move          r0    r0
.line	517	move          r0    r0
.line	517	return        r0     1

.function	main/f27

.source	null
.linedefined	543
.lastlinedefined	557
.numparams	3
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	14	true
.upvalue	"U3"	12	true
.upvalue	"U4"	5	true
.upvalue	"U5"	7	true

.constant	k0	"printf"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	126
.constant	k4	69
.constant	k5	200
.constant	k6	62
.constant	k7	20
.constant	k8	56
.constant	k9	231
.constant	k10	14
.constant	k11	156
.constant	k12	226
.constant	k13	110
.constant	k14	92
.constant	k15	6
.constant	k16	254
.constant	k17	223
.constant	k18	136
.constant	k19	74
.constant	k20	245
.constant	k21	52
.constant	k22	0
.constant	k23	145
.constant	k24	54
.constant	k25	182
.constant	k26	251
.constant	k27	214
.constant	k28	96
.constant	k29	76
.constant	k30	37
.constant	k31	212
.constant	k32	190
.constant	k33	67
.constant	k34	171
.constant	k35	21
.constant	k36	51
.constant	k37	135
.constant	k38	91
.constant	k39	4
.constant	k40	159
.constant	k41	57
.constant	k42	12
.constant	k43	50
.constant	k44	235
.constant	k45	46
.constant	k46	162
.constant	k47	219
.constant	k48	58
.constant	k49	23
.constant	k50	42
.constant	k51	163
.constant	k52	105
.constant	k53	139
.constant	k54	15
.constant	k55	255
.constant	k56	9
.constant	k57	154
.constant	k58	53
.constant	k59	178
.constant	k60	208
.constant	k61	121
.constant	k62	116
.constant	k63	158
.constant	k64	"tostring"
.constant	k65	"key"
.constant	k66	"downloadType"
.constant	k67	"ODPAK"
.constant	k68	"keyList"
.constant	k69	"type"
.constant	k70	73
.constant	k71	94
.constant	k72	205
.constant	k73	22
.constant	k74	48
.constant	k75	"Starts"
.constant	k76	"PACK_SET_PREFIX"
.constant	k77	"ChooseStopDownloadByType"
.constant	k78	"ChooseDownloadByType"
.constant	k79	"isFitVersion"

.line	543	gettabup      r3    u0    k0 ; k0 = "printf"
.line	543	gettabup      r4    u0    k1 ; k1 = "table"
.line	543	gettable      r4    r4    k2 ; k2 = "concat"
.line	543	newtable      r5     1     0
.line	543	getupval      r6    u1
.line	543	loadk         r7    k3 ; k3 = 126
.line	543	loadk         r8    k4 ; k4 = 69
.line	543	loadk         r9    k5 ; k5 = 200
.line	543	loadk        r10    k6 ; k6 = 62
.line	543	loadk        r11    k7 ; k7 = 20
.line	543	loadk        r12    k8 ; k8 = 56
.line	543	loadk        r13    k9 ; k9 = 231
.line	543	loadk        r14   k10 ; k10 = 14
.line	543	loadk        r15   k11 ; k11 = 156
.line	543	loadk        r16   k12 ; k12 = 226
.line	543	loadk        r17    k5 ; k5 = 200
.line	543	loadk        r18   k13 ; k13 = 110
.line	543	loadk        r19   k14 ; k14 = 92
.line	543	loadk        r20   k15 ; k15 = 6
.line	543	loadk        r21   k16 ; k16 = 254
.line	543	loadk        r22   k17 ; k17 = 223
.line	543	loadk        r23   k18 ; k18 = 136
.line	543	loadk        r24   k19 ; k19 = 74
.line	543	loadk        r25   k20 ; k20 = 245
.line	543	loadk        r26   k21 ; k21 = 52
.line	543	loadk        r27    k9 ; k9 = 231
.line	543	loadk        r28   k22 ; k22 = 0
.line	543	loadk        r29   k23 ; k23 = 145
.line	543	loadk        r30   k24 ; k24 = 54
.line	543	loadk        r31   k25 ; k25 = 182
.line	543	loadk        r32   k26 ; k26 = 251
.line	543	loadk        r33   k27 ; k27 = 214
.line	543	loadk        r34   k28 ; k28 = 96
.line	543	loadk        r35   k29 ; k29 = 76
.line	543	loadk        r36   k30 ; k30 = 37
.line	543	loadk        r37   k31 ; k31 = 212
.line	543	loadk        r38    k9 ; k9 = 231
.line	543	loadk        r39   k32 ; k32 = 190
.line	543	loadk        r40   k33 ; k33 = 67
.line	543	loadk        r41   k34 ; k34 = 171
.line	543	loadk        r42   k35 ; k35 = 21
.line	543	loadk        r43   k20 ; k20 = 245
.line	543	loadk        r44   k36 ; k36 = 51
.line	543	loadk        r45   k37 ; k37 = 135
.line	543	loadk        r46    k6 ; k6 = 62
.line	543	call          r6    41     2
.line	543	getupval      r7    u1
.line	543	loadk         r8   k38 ; k38 = 91
.line	543	loadk         r9   k39 ; k39 = 4
.line	543	loadk        r10   k40 ; k40 = 159
.line	543	loadk        r11   k41 ; k41 = 57
.line	543	loadk        r12   k42 ; k42 = 12
.line	543	loadk        r13   k43 ; k43 = 50
.line	543	loadk        r14   k44 ; k44 = 235
.line	543	loadk        r15   k45 ; k45 = 46
.line	543	loadk        r16   k46 ; k46 = 162
.line	543	loadk        r17   k47 ; k47 = 219
.line	543	loadk        r18    k5 ; k5 = 200
.line	543	loadk        r19   k48 ; k48 = 58
.line	543	loadk        r20   k49 ; k49 = 23
.line	543	loadk        r21   k50 ; k50 = 42
.line	543	loadk        r22   k37 ; k37 = 135
.line	543	loadk        r23   k25 ; k25 = 182
.line	543	loadk        r24   k51 ; k51 = 163
.line	543	loadk        r25   k52 ; k52 = 105
.line	543	loadk        r26   k53 ; k53 = 139
.line	543	loadk        r27   k54 ; k54 = 15
.line	543	loadk        r28   k55 ; k55 = 255
.line	543	loadk        r29   k56 ; k56 = 9
.line	543	loadk        r30   k57 ; k57 = 154
.line	543	loadk        r31   k58 ; k58 = 53
.line	543	loadk        r32   k59 ; k59 = 178
.line	543	loadk        r33   k47 ; k47 = 219
.line	543	loadk        r34   k60 ; k60 = 208
.line	543	loadk        r35   k61 ; k61 = 121
.line	543	loadk        r36    k4 ; k4 = 69
.line	543	loadk        r37   k62 ; k62 = 116
.line	543	loadk        r38   k63 ; k63 = 158
.line	543	loadk        r39   k20 ; k20 = 245
.line	543	call          r7    33     0
.line	543	setlist       r5     0     1
.line	543	call          r4     2     2
.line	543	gettabup      r5    u0   k64 ; k64 = "tostring"
.line	543	gettable      r6    r1   k65 ; k65 = "key"
.line	543	call          r5     2     2
.line	543	gettabup      r6    u0   k64 ; k64 = "tostring"
.line	543	move          r7    r2
.line	543	call          r6     2     0
.line	543	call          r3     0     1
.line	543	loadnil       r3     0
.line	543	gettable      r4    r1   k65 ; k65 = "key"
.line	543	gettable      r5    r1   k66 ; k66 = "downloadType"
.line	543	gettabup      r6    u2   k67 ; k67 = "ODPAK"
.line	543	eq             0    r5    r6
.line	543	jmp            0   l98
.line	543	gettable      r3    r1   k68 ; k68 = "keyList"
.line	543	jmp            0  l118
.label	l98
.line	543	gettabup      r5    u0   k69 ; k69 = "type"
.line	543	gettable      r6    r1   k65 ; k65 = "key"
.line	543	call          r5     2     2
.line	543	getupval      r6    u1
.line	543	loadk         r7   k70 ; k70 = 73
.line	543	loadk         r8   k71 ; k71 = 94
.line	543	loadk         r9   k72 ; k72 = 205
.line	543	loadk        r10   k41 ; k41 = 57
.line	543	loadk        r11   k73 ; k73 = 22
.line	543	loadk        r12   k74 ; k74 = 48
.line	543	call          r6     7     2
.line	543	eq             0    r5    r6
.line	543	jmp            0  l118
.line	543	gettabup      r5    u3   k75 ; k75 = "Starts"
.line	543	gettable      r6    r1   k65 ; k65 = "key"
.line	543	gettabup      r7    u4   k76 ; k76 = "PACK_SET_PREFIX"
.line	543	call          r5     3     2
.line	543	test          r5     0
.line	543	jmp            0  l118
.line	543	gettable      r3    r1   k68 ; k68 = "keyList"
.label	l118
.line	543	test          r2     0
.line	543	jmp            0  l126
.line	543	gettabup      r5    u5   k77 ; k77 = "ChooseStopDownloadBy" (truncated)
.line	543	move          r6    r4
.line	543	loadnil       r7     0
.line	543	move          r8    r3
.line	543	call          r5     4     1
.line	543	jmp            0  l132
.label	l126
.line	543	gettabup      r5    u5   k78 ; k78 = "ChooseDownloadByType"
.line	543	move          r6    r4
.line	543	loadnil       r7     0
.line	543	move          r8    r3
.line	543	gettable      r9    r0   k79 ; k79 = "isFitVersion"
.line	543	call          r5     5     1
.label	l132
.line	543	return        r0     1
.line	543	move          r0    r0
.line	543	return        r0     1

.function	main/f28

.source	null
.linedefined	559
.lastlinedefined	571
.numparams	1
.is_vararg	0
.maxstacksize	11

.upvalue	"_ENV"	0	false

.constant	k0	"showTabData"
.constant	k1	"ipairs"
.constant	k2	"GetItemData"
.constant	k3	"table"
.constant	k4	"insert"
.constant	k5	"key"

.line	559	newtable      r1     0     0
.line	559	gettable      r2    r0    k0 ; k0 = "showTabData"
.line	559	test          r2     1
.line	559	jmp            0    l6
.line	559	return        r1     2
.label	l6
.line	559	gettabup      r2    u0    k1 ; k1 = "ipairs"
.line	559	gettable      r3    r0    k0 ; k0 = "showTabData"
.line	559	call          r2     2     4
.line	559	jmp            0   l20
.line	559	self          r7    r0    k2 ; k2 = "GetItemData"
.line	559	move          r9    r6
.line	559	call          r7     3     2
.line	559	test          r7     0
.line	559	jmp            0   l20
.line	559	gettabup      r8    u0    k3 ; k3 = "table"
.line	559	gettable      r8    r8    k4 ; k4 = "insert"
.line	559	move          r9    r1
.line	559	gettable     r10    r7    k5 ; k5 = "key"
.line	559	call          r8     3     1
.label	l20
.line	559	move          r0    r0
.line	559	move          r0    r0
.line	559	return        r1     2
.line	559	return        r0     1
.line	559	move          r0    r0
.line	559	return        r0     1

.function	main/f29

.source	null
.linedefined	573
.lastlinedefined	582
.numparams	2
.is_vararg	0
.maxstacksize	4

.constant	k0	nil
.constant	k1	"selectIndex"
.constant	k2	"dataArr"

.line	573	eq             0    r1    k0 ; k0 = nil
.line	573	jmp            0    l5
.line	573	loadnil       r2     0
.line	573	return        r2     2
.label	l5
.line	573	gettable      r2    r1    k1 ; k1 = "selectIndex"
.line	573	test          r2     0
.line	573	jmp            0   l16
.line	573	gettable      r2    r1    k2 ; k2 = "dataArr"
.line	573	test          r2     0
.line	573	jmp            0   l16
.line	573	gettable      r2    r1    k2 ; k2 = "dataArr"
.line	573	gettable      r3    r1    k1 ; k1 = "selectIndex"
.line	573	gettable      r2    r2    r3
.line	573	return        r2     2
.line	573	jmp            0   l17
.label	l16
.line	573	return        r1     2
.label	l17
.line	573	return        r0     1
.line	573	move          r0    r0
.line	573	move          r0    r0
.line	573	return        r0     1

.function	main/f30

.source	null
.linedefined	584
.lastlinedefined	606
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	5	true
.upvalue	"U3"	9	true
.upvalue	"U4"	13	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"canGetReverserReward"
.constant	k4	"require"
.constant	k5	"table"
.constant	k6	"concat"
.constant	k7	89
.constant	k8	70
.constant	k9	214
.constant	k10	53
.constant	k11	22
.constant	k12	35
.constant	k13	168
.constant	k14	4
.constant	k15	166
.constant	k16	219
.constant	k17	222
.constant	k18	104
.constant	k19	64
.constant	k20	50
.constant	k21	133
.constant	k22	198
.constant	k23	184
.constant	k24	117
.constant	k25	187
.constant	k26	15
.constant	k27	235
.constant	k28	8
.constant	k29	154
.constant	k30	116
.constant	k31	131
.constant	k32	202
.constant	k33	223
.constant	k34	113
.constant	k35	71
.constant	k36	59
.constant	k37	255
.constant	k38	233
.constant	k39	173
.constant	k40	100
.constant	k41	179
.constant	k42	31
.constant	k43	249
.constant	k44	19
.constant	k45	174
.constant	k46	43
.constant	k47	84
.constant	k48	78
.constant	k49	211
.constant	k50	10
.constant	k51	"send_mini_client_reward_get_req"
.constant	k52	"Enum_BundleID"
.constant	k53	"Prefetch"
.constant	k54	"AutoDownloadPrefetchSwitch"
.constant	k55	"ShowNotice"
.constant	k56	85220
.constant	k57	"ModuleManager"
.constant	k58	"GetModule"
.constant	k59	"CommonModuleConfig"
.constant	k60	"puffer_prefetch_manager"
.constant	k61	"GetState"
.constant	k62	"Done"
.constant	k63	"SetWidgetVisible"
.constant	k64	"UIRoot"
.constant	k65	"ProgressBar_Download"
.constant	k66	"Download"
.constant	k67	"AutoDownloadPrefetch"
.constant	k68	"StopDownloadPrefetch"

.line	584	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	584	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	584	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	584	call          r1     3     1
.line	584	gettable      r1    r0    k3 ; k3 = "canGetReverserReward"
.line	584	test          r1     0
.line	584	jmp            0   l69
.line	584	gettabup      r1    u0    k4 ; k4 = "require"
.line	584	gettabup      r2    u0    k5 ; k5 = "table"
.line	584	gettable      r2    r2    k6 ; k6 = "concat"
.line	584	newtable      r3     1     0
.line	584	getupval      r4    u1
.line	584	loadk         r5    k7 ; k7 = 89
.line	584	loadk         r6    k8 ; k8 = 70
.line	584	loadk         r7    k9 ; k9 = 214
.line	584	loadk         r8   k10 ; k10 = 53
.line	584	loadk         r9   k11 ; k11 = 22
.line	584	loadk        r10   k12 ; k12 = 35
.line	584	loadk        r11   k13 ; k13 = 168
.line	584	loadk        r12   k14 ; k14 = 4
.line	584	loadk        r13   k15 ; k15 = 166
.line	584	loadk        r14   k16 ; k16 = 219
.line	584	loadk        r15   k17 ; k17 = 222
.line	584	loadk        r16   k18 ; k18 = 104
.line	584	loadk        r17   k19 ; k19 = 64
.line	584	loadk        r18   k20 ; k20 = 50
.line	584	loadk        r19   k21 ; k21 = 133
.line	584	loadk        r20   k22 ; k22 = 198
.line	584	loadk        r21   k23 ; k23 = 184
.line	584	loadk        r22   k24 ; k24 = 117
.line	584	loadk        r23   k25 ; k25 = 187
.line	584	loadk        r24   k26 ; k26 = 15
.line	584	loadk        r25   k27 ; k27 = 235
.line	584	loadk        r26   k28 ; k28 = 8
.line	584	loadk        r27   k29 ; k29 = 154
.line	584	loadk        r28   k30 ; k30 = 116
.line	584	loadk        r29   k31 ; k31 = 131
.line	584	loadk        r30   k32 ; k32 = 202
.line	584	loadk        r31   k33 ; k33 = 223
.line	584	loadk        r32   k34 ; k34 = 113
.line	584	loadk        r33   k35 ; k35 = 71
.line	584	loadk        r34   k36 ; k36 = 59
.line	584	loadk        r35   k37 ; k37 = 255
.line	584	loadk        r36   k38 ; k38 = 233
.line	584	loadk        r37   k39 ; k39 = 173
.line	584	loadk        r38   k40 ; k40 = 100
.line	584	loadk        r39   k41 ; k41 = 179
.line	584	loadk        r40   k42 ; k42 = 31
.line	584	loadk        r41   k43 ; k43 = 249
.line	584	loadk        r42   k44 ; k44 = 19
.line	584	loadk        r43   k45 ; k45 = 174
.line	584	loadk        r44   k46 ; k46 = 43
.line	584	call          r4    41     2
.line	584	getupval      r5    u1
.line	584	loadk         r6   k47 ; k47 = 84
.line	584	loadk         r7   k48 ; k48 = 78
.line	584	loadk         r8   k49 ; k49 = 211
.line	584	loadk         r9   k10 ; k10 = 53
.line	584	loadk        r10   k50 ; k50 = 10
.line	584	call          r5     6     0
.line	584	setlist       r3     0     1
.line	584	call          r2     2     2
.line	584	call          r1     2     2
.line	584	gettable      r2    r1   k51 ; k51 = "send_mini_client_rew" (truncated)
.line	584	gettabup      r3    u2   k52 ; k52 = "Enum_BundleID"
.line	584	gettable      r3    r3   k53 ; k53 = "Prefetch"
.line	584	call          r2     2     1
.line	584	return        r0     1
.label	l69
.line	584	gettabup      r1    u3   k54 ; k54 = "AutoDownloadPrefetch" (truncated)
.line	584	test          r1     1
.line	584	jmp            0   l76
.line	584	gettabup      r1    u0   k55 ; k55 = "ShowNotice"
.line	584	loadk         r2   k56 ; k56 = 85220
.line	584	call          r1     2     1
.line	584	return        r0     1
.label	l76
.line	584	gettabup      r1    u0   k57 ; k57 = "ModuleManager"
.line	584	gettable      r1    r1   k58 ; k58 = "GetModule"
.line	584	gettabup      r2    u0   k57 ; k57 = "ModuleManager"
.line	584	gettable      r2    r2   k59 ; k59 = "CommonModuleConfig"
.line	584	gettable      r2    r2   k60 ; k60 = "puffer_prefetch_mana" (truncated)
.line	584	call          r1     2     2
.line	584	self          r2    r1   k61 ; k61 = "GetState"
.line	584	call          r2     2     2
.line	584	gettabup      r3    u4   k62 ; k62 = "Done"
.line	584	eq             0    r2    r3
.line	584	jmp            0   l88
.line	584	return        r0     1
.label	l88
.line	584	self          r3    r0   k63 ; k63 = "SetWidgetVisible"
.line	584	gettable      r5    r0   k64 ; k64 = "UIRoot"
.line	584	gettable      r5    r5   k65 ; k65 = "ProgressBar_Download"
.line	584	gettabup      r6    u4   k66 ; k66 = "Download"
.line	584	eq             0    r2    r6
.line	584	jmp            0   l95
.line	584	loadbool      r6     0     1
.label	l95
.line	584	loadbool      r6     1     0
.line	584	call          r3     4     1
.line	584	gettabup      r3    u4   k66 ; k66 = "Download"
.line	584	eq             1    r2    r3
.line	584	jmp            0  l104
.line	584	self          r3    r1   k67 ; k67 = "AutoDownloadPrefetch"
.line	584	loadbool      r5     0     0
.line	584	call          r3     3     1
.line	584	jmp            0  l106
.label	l104
.line	584	self          r3    r1   k68 ; k68 = "StopDownloadPrefetch"
.line	584	call          r3     2     1
.label	l106
.line	584	return        r0     1
.line	584	move          r0    r0
.line	584	move          r0    r0
.line	584	move          r0    r0
.line	584	return        r0     1

.function	main/f31

.source	null
.linedefined	608
.lastlinedefined	634
.numparams	1
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	0	false
.upvalue	"U1"	9	true
.upvalue	"U2"	11	true
.upvalue	"U3"	1	true

.constant	k0	"tmpDownloadAllState"
.constant	k1	"PlayAudio"
.constant	k2	"sound_config"
.constant	k3	"click_v1"
.constant	k4	"isToggleDownloadingAll"
.constant	k5	"ReportSmartDownloadWakeUp"
.constant	k6	"allTotalSize"
.constant	k7	"allRemainSize"
.constant	k8	"UIManager"
.constant	k9	"ShowUI"
.constant	k10	"UI_Config"
.constant	k11	"Download_Lightweight_Popup_UIBP"
.constant	k12	"smartDownloadSize"
.constant	k13	"SaveSmartDownloadTipsCfg"
.constant	k14	"_ToggleDownloadAll"

.line	608	gettable      r1    r0    k0 ; k0 = "tmpDownloadAllState"
.line	608	test          r1     0
.line	608	jmp            0    l5
.line	608	return        r0     1
.label	l5
.line	608	self          r1    r0    k1 ; k1 = "PlayAudio"
.line	608	gettabup      r3    u0    k2 ; k2 = "sound_config"
.line	608	gettable      r3    r3    k3 ; k3 = "click_v1"
.line	608	call          r1     3     1
.line	608	gettabup      r1    u1    k4 ; k4 = "isToggleDownloadingA" (truncated)
.line	608	test          r1     1
.line	608	jmp            0   l29
.line	608	gettabup      r1    u2    k5 ; k5 = "ReportSmartDownloadW" (truncated)
.line	608	gettable      r2    r0    k6 ; k6 = "allTotalSize"
.line	608	gettable      r3    r0    k7 ; k7 = "allRemainSize"
.line	608	call          r1     3     1
.line	608	gettabup      r1    u0    k8 ; k8 = "UIManager"
.line	608	gettable      r1    r1    k9 ; k9 = "ShowUI"
.line	608	gettabup      r2    u0    k8 ; k8 = "UIManager"
.line	608	gettable      r2    r2   k10 ; k10 = "UI_Config"
.line	608	gettable      r2    r2   k11 ; k11 = "Download_Lightweight" (truncated)
.line	608	gettable      r3    r0    k6 ; k6 = "allTotalSize"
.line	608	gettable      r4    r0    k7 ; k7 = "allRemainSize"
.line	608	gettable      r5    r0   k12 ; k12 = "smartDownloadSize"
.line	608	closure       r6    f0
.line	608	call          r1     6     1
.line	608	gettabup      r1    u1   k13 ; k13 = "SaveSmartDownloadTip" (truncated)
.line	608	call          r1     1     1
.line	608	return        r0     1
.label	l29
.line	608	self          r1    r0   k14 ; k14 = "_ToggleDownloadAll"
.line	608	call          r1     2     1
.line	608	return        r0     1
.line	608	move          r0    r0
.line	608	move          r0    r0
.line	608	move          r0    r0
.line	608	move          r0    r0
.line	608	return        r0     1

.function	main/f31/f0

.source	null
.linedefined	615
.lastlinedefined	629
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	1	false
.upvalue	"U1"	0	true
.upvalue	"U2"	3	false
.upvalue	"U3"	0	false

.constant	k0	"AutoDownloadCfg"
.constant	k1	"RecordDownloadPakID"
.constant	k2	"SaveAutoDownloadSetting"
.constant	k3	"downloadSelectMap"
.constant	k4	nil
.constant	k5	87
.constant	k6	79
.constant	k7	210
.constant	k8	63
.constant	k9	10
.constant	k10	46
.constant	k11	166
.constant	k12	26
.constant	k13	175
.constant	k14	206
.constant	k15	199
.constant	k16	89
.constant	k17	95
.constant	k18	204
.constant	k19	36
.constant	k20	23
.constant	k21	58
.constant	k22	"log"
.constant	k23	"bWriteLog"
.constant	k24	"table"
.constant	k25	"concat"
.constant	k26	126
.constant	k27	69
.constant	k28	200
.constant	k29	62
.constant	k30	20
.constant	k31	56
.constant	k32	231
.constant	k33	14
.constant	k34	156
.constant	k35	226
.constant	k36	110
.constant	k37	92
.constant	k38	6
.constant	k39	254
.constant	k40	223
.constant	k41	136
.constant	k42	74
.constant	k43	245
.constant	k44	47
.constant	k45	230
.constant	k46	154
.constant	k47	51
.constant	k48	176
.constant	k49	212
.constant	k50	251
.constant	k51	98
.constant	k52	86
.constant	k53	61
.constant	k54	232
.constant	k55	133
.constant	k56	78
.constant	k57	7
.constant	k58	246
.constant	k59	27
.constant	k60	137
.constant	k61	43
.constant	k62	94
.constant	k63	107
.constant	k64	211
.constant	k65	60
.constant	k66	119
.constant	k67	29
.constant	k68	170
.constant	k69	219
.constant	k70	202
.constant	k71	111
.constant	k72	18
.constant	k73	45
.constant	k74	196
.constant	k75	"slua"
.constant	k76	"isValid"
.constant	k77	"UIRoot"
.constant	k78	"_ToggleDownloadAll"
.constant	k79	"UIManager"
.constant	k80	"GetUI"
.constant	k81	"UI_Config"
.constant	k82	"Download_Main_UIBP"
.constant	k83	"ShowUI"
.constant	k84	"Download_Preference_Popup_UIBP"

.line	615	gettabup      r2    u0    k0 ; k0 = "AutoDownloadCfg"
.line	615	settable      r2    k1    r0 ; k1 = "RecordDownloadPakID"
.line	615	gettabup      r2    u0    k2 ; k2 = "SaveAutoDownloadSett" (truncated)
.line	615	call          r2     1     1
.line	615	settabup      u1    k3    k4 ; k4 = nil
.line	615	test          r0     0
.line	615	jmp            0   l23
.line	615	getupval      r2    u2
.line	615	loadk         r3    k5 ; k5 = 87
.line	615	loadk         r4    k6 ; k6 = 79
.line	615	loadk         r5    k7 ; k7 = 210
.line	615	loadk         r6    k8 ; k8 = 63
.line	615	loadk         r7    k9 ; k9 = 10
.line	615	loadk         r8   k10 ; k10 = 46
.line	615	loadk         r9   k11 ; k11 = 166
.line	615	loadk        r10   k12 ; k12 = 26
.line	615	loadk        r11   k13 ; k13 = 175
.line	615	loadk        r12   k14 ; k14 = 206
.line	615	loadk        r13   k15 ; k15 = 199
.line	615	call          r2    12     2
.line	615	test          r2     1
.line	615	jmp            0   l36
.label	l23
.line	615	getupval      r2    u2
.line	615	loadk         r3   k16 ; k16 = 89
.line	615	loadk         r4   k17 ; k17 = 95
.line	615	loadk         r5   k18 ; k18 = 204
.line	615	loadk         r6   k19 ; k19 = 36
.line	615	loadk         r7   k20 ; k20 = 23
.line	615	loadk         r8   k21 ; k21 = 58
.line	615	loadk         r9   k11 ; k11 = 166
.line	615	loadk        r10   k12 ; k12 = 26
.line	615	loadk        r11   k13 ; k13 = 175
.line	615	loadk        r12   k14 ; k14 = 206
.line	615	loadk        r13   k15 ; k15 = 199
.line	615	call          r2    12     2
.label	l36
.line	615	gettabup      r3    u3   k22 ; k22 = "log"
.line	615	gettabup      r4    u3   k23 ; k23 = "bWriteLog"
.line	615	test          r4     0
.line	615	jmp            0  l106
.line	615	gettabup      r4    u3   k24 ; k24 = "table"
.line	615	gettable      r4    r4   k25 ; k25 = "concat"
.line	615	newtable      r5     1     0
.line	615	getupval      r6    u2
.line	615	loadk         r7   k26 ; k26 = 126
.line	615	loadk         r8   k27 ; k27 = 69
.line	615	loadk         r9   k28 ; k28 = 200
.line	615	loadk        r10   k29 ; k29 = 62
.line	615	loadk        r11   k30 ; k30 = 20
.line	615	loadk        r12   k31 ; k31 = 56
.line	615	loadk        r13   k32 ; k32 = 231
.line	615	loadk        r14   k33 ; k33 = 14
.line	615	loadk        r15   k34 ; k34 = 156
.line	615	loadk        r16   k35 ; k35 = 226
.line	615	loadk        r17   k28 ; k28 = 200
.line	615	loadk        r18   k36 ; k36 = 110
.line	615	loadk        r19   k37 ; k37 = 92
.line	615	loadk        r20   k38 ; k38 = 6
.line	615	loadk        r21   k39 ; k39 = 254
.line	615	loadk        r22   k40 ; k40 = 223
.line	615	loadk        r23   k41 ; k41 = 136
.line	615	loadk        r24   k42 ; k42 = 74
.line	615	loadk        r25   k43 ; k43 = 245
.line	615	loadk        r26   k44 ; k44 = 47
.line	615	loadk        r27   k45 ; k45 = 230
.line	615	loadk        r28   k19 ; k19 = 36
.line	615	loadk        r29   k46 ; k46 = 154
.line	615	loadk        r30   k47 ; k47 = 51
.line	615	loadk        r31   k48 ; k48 = 176
.line	615	loadk        r32   k49 ; k49 = 212
.line	615	loadk        r33   k50 ; k50 = 251
.line	615	loadk        r34   k51 ; k51 = 98
.line	615	loadk        r35   k52 ; k52 = 86
.line	615	loadk        r36   k53 ; k53 = 61
.line	615	loadk        r37   k49 ; k49 = 212
.line	615	loadk        r38   k54 ; k54 = 232
.line	615	loadk        r39   k55 ; k55 = 133
.line	615	loadk        r40   k56 ; k56 = 78
.line	615	loadk        r41   k48 ; k48 = 176
.line	615	loadk        r42   k57 ; k57 = 7
.line	615	loadk        r43   k58 ; k58 = 246
.line	615	loadk        r44   k59 ; k59 = 27
.line	615	loadk        r45   k60 ; k60 = 137
.line	615	loadk        r46   k61 ; k61 = 43
.line	615	call          r6    41     2
.line	615	getupval      r7    u2
.line	615	loadk         r8   k62 ; k62 = 94
.line	615	loadk         r9   k63 ; k63 = 107
.line	615	loadk        r10   k64 ; k64 = 211
.line	615	loadk        r11   k65 ; k65 = 60
.line	615	loadk        r12   k52 ; k52 = 86
.line	615	loadk        r13   k66 ; k66 = 119
.line	615	loadk        r14   k43 ; k43 = 245
.line	615	loadk        r15   k67 ; k67 = 29
.line	615	loadk        r16   k68 ; k68 = 170
.line	615	loadk        r17   k69 ; k69 = 219
.line	615	loadk        r18   k70 ; k70 = 202
.line	615	loadk        r19   k71 ; k71 = 111
.line	615	loadk        r20   k72 ; k72 = 18
.line	615	loadk        r21   k73 ; k73 = 45
.line	615	loadk        r22   k74 ; k74 = 196
.line	615	call          r7    16     0
.line	615	setlist       r5     0     1
.line	615	call          r4     2     2
.line	615	move          r5    r2
.line	615	concat        r4    r4    r5
.label	l106
.line	615	call          r3     2     1
.line	615	gettabup      r3    u3   k75 ; k75 = "slua"
.line	615	gettable      r3    r3   k76 ; k76 = "isValid"
.line	615	gettabup      r4    u1   k77 ; k77 = "UIRoot"
.line	615	call          r3     2     2
.line	615	test          r3     0
.line	615	jmp            0  l119
.line	615	test          r1     1
.line	615	jmp            0  l119
.line	615	getupval      r3    u1
.line	615	self          r3    r3   k78 ; k78 = "_ToggleDownloadAll"
.line	615	call          r3     2     1
.line	615	jmp            0  l135
.label	l119
.line	615	test          r1     0
.line	615	jmp            0  l135
.line	615	gettabup      r3    u3   k79 ; k79 = "UIManager"
.line	615	gettable      r3    r3   k80 ; k80 = "GetUI"
.line	615	gettabup      r4    u3   k79 ; k79 = "UIManager"
.line	615	gettable      r4    r4   k81 ; k81 = "UI_Config"
.line	615	gettable      r4    r4   k82 ; k82 = "Download_Main_UIBP"
.line	615	call          r3     2     2
.line	615	test          r3     0
.line	615	jmp            0  l135
.line	615	gettabup      r4    u3   k79 ; k79 = "UIManager"
.line	615	gettable      r4    r4   k83 ; k83 = "ShowUI"
.line	615	gettabup      r5    u3   k79 ; k79 = "UIManager"
.line	615	gettable      r5    r5   k81 ; k81 = "UI_Config"
.line	615	gettable      r5    r5   k84 ; k84 = "Download_Preference_" (truncated)
.line	615	call          r4     2     1
.label	l135
.line	615	return        r0     1
.line	615	move          r0    r0
.line	615	move          r0    r0
.line	615	move          r0    r0
.line	615	return        r0     1

.function	main/f32

.source	null
.linedefined	636
.lastlinedefined	641
.numparams	1
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"LocUtil"
.constant	k4	"GetLocalizeResStr"
.constant	k5	6067
.constant	k6	33020417
.constant	k7	"UIManager"
.constant	k8	"ShowUI"
.constant	k9	"UI_Config"
.constant	k10	"HelpTip"
.constant	k11	0

.line	636	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	636	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	636	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	636	call          r1     3     1
.line	636	gettabup      r1    u0    k3 ; k3 = "LocUtil"
.line	636	gettable      r1    r1    k4 ; k4 = "GetLocalizeResStr"
.line	636	loadk         r2    k5 ; k5 = 6067
.line	636	call          r1     2     2
.line	636	gettabup      r2    u0    k3 ; k3 = "LocUtil"
.line	636	gettable      r2    r2    k4 ; k4 = "GetLocalizeResStr"
.line	636	loadk         r3    k6 ; k6 = 33020417
.line	636	call          r2     2     2
.line	636	gettabup      r3    u0    k7 ; k7 = "UIManager"
.line	636	gettable      r3    r3    k8 ; k8 = "ShowUI"
.line	636	gettabup      r4    u0    k7 ; k7 = "UIManager"
.line	636	gettable      r4    r4    k9 ; k9 = "UI_Config"
.line	636	gettable      r4    r4   k10 ; k10 = "HelpTip"
.line	636	loadk         r5   k11 ; k11 = 0
.line	636	move          r6    r1
.line	636	move          r7    r2
.line	636	call          r3     5     1
.line	636	return        r0     1
.line	636	move          r0    r0
.line	636	move          r0    r0
.line	636	move          r0    r0
.line	636	return        r0     1

.function	main/f33

.source	null
.linedefined	643
.lastlinedefined	666
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	9	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"showDownloadIconCheckBox"
.constant	k1	"IsViewMode"
.constant	k2	"AutoDownloadCfg"
.constant	k3	"AutoDownloadIconSwitch"
.constant	k4	"isFitVersion"
.constant	k5	"PlayAudio"
.constant	k6	"sound_config"
.constant	k7	"click_v1"
.constant	k8	"require"
.constant	k9	"table"
.constant	k10	"concat"
.constant	k11	89
.constant	k12	70
.constant	k13	214
.constant	k14	53
.constant	k15	22
.constant	k16	35
.constant	k17	168
.constant	k18	25
.constant	k19	175
.constant	k20	218
.constant	k21	200
.constant	k22	41
.constant	k23	94
.constant	k24	54
.constant	k25	204
.constant	k26	255
.constant	k27	169
.constant	k28	52
.constant	k29	172
.constant	k30	15
.constant	k31	229
.constant	k32	10
.constant	k33	153
.constant	k34	253
.constant	k35	211
.constant	k36	112
.constant	k37	75
.constant	k38	42
.constant	k39	228
.constant	k40	181
.constant	k41	103
.constant	k42	178
.constant	k43	31
.constant	k44	246
.constant	k45	40
.constant	k46	139
.constant	k47	57
.constant	k48	93
.constant	k49	117
.constant	k50	221
.constant	k51	63
.constant	k52	0
.constant	k53	"LocUtil"
.constant	k54	"GetLocalizeResStr"
.constant	k55	5077
.constant	k56	33020416
.constant	k57	"Show"
.constant	k58	2

.line	643	gettable      r1    r0    k0 ; k0 = "showDownloadIconChec" (truncated)
.line	643	test          r1     0
.line	643	jmp            0    l8
.line	643	self          r1    r0    k1 ; k1 = "IsViewMode"
.line	643	call          r1     2     2
.line	643	test          r1     1
.line	643	jmp            0    l9
.label	l8
.line	643	return        r0     1
.label	l9
.line	643	gettabup      r1    u0    k2 ; k2 = "AutoDownloadCfg"
.line	643	gettable      r1    r1    k3 ; k3 = "AutoDownloadIconSwit" (truncated)
.line	643	not           r1    r1
.line	643	closure       r2    f0
.line	643	gettable      r3    r0    k4 ; k4 = "isFitVersion"
.line	643	test          r3     0
.line	643	jmp            0   l93
.line	643	test          r1     0
.line	643	jmp            0   l93
.line	643	self          r3    r0    k5 ; k5 = "PlayAudio"
.line	643	gettabup      r5    u1    k6 ; k6 = "sound_config"
.line	643	gettable      r5    r5    k7 ; k7 = "click_v1"
.line	643	call          r3     3     1
.line	643	gettabup      r3    u1    k8 ; k8 = "require"
.line	643	gettabup      r4    u1    k9 ; k9 = "table"
.line	643	gettable      r4    r4   k10 ; k10 = "concat"
.line	643	newtable      r5     1     0
.line	643	getupval      r6    u2
.line	643	loadk         r7   k11 ; k11 = 89
.line	643	loadk         r8   k12 ; k12 = 70
.line	643	loadk         r9   k13 ; k13 = 214
.line	643	loadk        r10   k14 ; k14 = 53
.line	643	loadk        r11   k15 ; k15 = 22
.line	643	loadk        r12   k16 ; k16 = 35
.line	643	loadk        r13   k17 ; k17 = 168
.line	643	loadk        r14   k18 ; k18 = 25
.line	643	loadk        r15   k19 ; k19 = 175
.line	643	loadk        r16   k20 ; k20 = 218
.line	643	loadk        r17   k21 ; k21 = 200
.line	643	loadk        r18   k22 ; k22 = 41
.line	643	loadk        r19   k23 ; k23 = 94
.line	643	loadk        r20   k24 ; k24 = 54
.line	643	loadk        r21   k25 ; k25 = 204
.line	643	loadk        r22   k26 ; k26 = 255
.line	643	loadk        r23   k27 ; k27 = 169
.line	643	loadk        r24   k28 ; k28 = 52
.line	643	loadk        r25   k29 ; k29 = 172
.line	643	loadk        r26   k30 ; k30 = 15
.line	643	loadk        r27   k31 ; k31 = 229
.line	643	loadk        r28   k32 ; k32 = 10
.line	643	loadk        r29   k33 ; k33 = 153
.line	643	loadk        r30   k28 ; k28 = 52
.line	643	loadk        r31   k34 ; k34 = 253
.line	643	loadk        r32   k35 ; k35 = 211
.line	643	loadk        r33   k13 ; k13 = 214
.line	643	loadk        r34   k36 ; k36 = 112
.line	643	loadk        r35   k37 ; k37 = 75
.line	643	loadk        r36   k38 ; k38 = 42
.line	643	loadk        r37   k39 ; k39 = 228
.line	643	loadk        r38   k31 ; k31 = 229
.line	643	loadk        r39   k40 ; k40 = 181
.line	643	loadk        r40   k41 ; k41 = 103
.line	643	loadk        r41   k42 ; k42 = 178
.line	643	loadk        r42   k43 ; k43 = 31
.line	643	loadk        r43   k44 ; k44 = 246
.line	643	loadk        r44   k45 ; k45 = 40
.line	643	loadk        r45   k46 ; k46 = 139
.line	643	loadk        r46   k47 ; k47 = 57
.line	643	call          r6    41     2
.line	643	getupval      r7    u2
.line	643	loadk         r8   k48 ; k48 = 93
.line	643	loadk         r9   k49 ; k49 = 117
.line	643	loadk        r10   k50 ; k50 = 221
.line	643	loadk        r11   k51 ; k51 = 63
.line	643	loadk        r12   k52 ; k52 = 0
.line	643	call          r7     6     0
.line	643	setlist       r5     0     1
.line	643	call          r4     2     2
.line	643	call          r3     2     2
.line	643	gettabup      r4    u1   k53 ; k53 = "LocUtil"
.line	643	gettable      r4    r4   k54 ; k54 = "GetLocalizeResStr"
.line	643	loadk         r5   k55 ; k55 = 5077
.line	643	call          r4     2     2
.line	643	gettabup      r5    u1   k53 ; k53 = "LocUtil"
.line	643	gettable      r5    r5   k54 ; k54 = "GetLocalizeResStr"
.line	643	loadk         r6   k56 ; k56 = 33020416
.line	643	call          r5     2     2
.line	643	gettable      r6    r3   k57 ; k57 = "Show"
.line	643	loadk         r7   k58 ; k58 = 2
.line	643	move          r8    r4
.line	643	move          r9    r5
.line	643	closure      r10    f1
.line	643	call          r6     5     1
.line	643	return        r0     1
.label	l93
.line	643	move          r3    r2
.line	643	call          r3     1     1
.line	643	return        r0     1
.line	643	move          r0    r0
.line	643	move          r0    r0
.line	643	move          r0    r0
.line	643	return        r0     1

.function	main/f33/f0

.source	null
.linedefined	648
.lastlinedefined	654
.numparams	0
.is_vararg	0
.maxstacksize	44

.upvalue	"_ENV"	0	true
.upvalue	"U1"	1	false
.upvalue	"U2"	1	true
.upvalue	"U3"	0	false
.upvalue	"U4"	2	false

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"toggle_v1"
.constant	k3	"UIRoot"
.constant	k4	"CheckBox_IconAutoSet"
.constant	k5	"SetIsChecked"
.constant	k6	"AutoDownloadCfg"
.constant	k7	"AutoDownloadIconSwitch"
.constant	k8	"log_format"
.constant	k9	"table"
.constant	k10	"concat"
.constant	k11	126
.constant	k12	69
.constant	k13	200
.constant	k14	62
.constant	k15	20
.constant	k16	56
.constant	k17	231
.constant	k18	14
.constant	k19	156
.constant	k20	226
.constant	k21	110
.constant	k22	92
.constant	k23	6
.constant	k24	254
.constant	k25	223
.constant	k26	136
.constant	k27	74
.constant	k28	245
.constant	k29	47
.constant	k30	230
.constant	k31	46
.constant	k32	149
.constant	k33	53
.constant	k34	189
.constant	k35	204
.constant	k36	99
.constant	k37	77
.constant	k38	26
.constant	k39	222
.constant	k40	242
.constant	k41	152
.constant	k42	127
.constant	k43	171
.constant	k44	4
.constant	k45	247
.constant	k46	25
.constant	k47	165
.constant	k48	38
.constant	k49	83
.constant	k50	73
.constant	k51	212
.constant	k52	88
.constant	k53	22
.constant	k54	243
.constant	k55	30
.constant	k56	172
.constant	k57	235
.constant	k58	198
.constant	k59	112
.constant	k60	196
.constant	k61	174
.constant	k62	15
.constant	k63	52
.constant	k64	129
.constant	k65	51
.constant	k66	167
.constant	k67	220
.constant	k68	209
.constant	k69	42
.constant	k70	7
.constant	k71	58
.constant	k72	"tostring"
.constant	k73	"SaveAutoDownloadSetting"

.line	648	getupval      r0    u0
.line	648	self          r0    r0    k0 ; k0 = "PlayAudio"
.line	648	gettabup      r2    u1    k1 ; k1 = "sound_config"
.line	648	gettable      r2    r2    k2 ; k2 = "toggle_v1"
.line	648	call          r0     3     1
.line	648	gettabup      r0    u0    k3 ; k3 = "UIRoot"
.line	648	gettable      r0    r0    k4 ; k4 = "CheckBox_IconAutoSet"
.line	648	self          r0    r0    k5 ; k5 = "SetIsChecked"
.line	648	getupval      r2    u2
.line	648	call          r0     3     1
.line	648	gettabup      r0    u3    k6 ; k6 = "AutoDownloadCfg"
.line	648	getupval      r1    u2
.line	648	settable      r0    k7    r1 ; k7 = "AutoDownloadIconSwit" (truncated)
.line	648	gettabup      r0    u1    k8 ; k8 = "log_format"
.line	648	gettabup      r1    u1    k9 ; k9 = "table"
.line	648	gettable      r1    r1   k10 ; k10 = "concat"
.line	648	newtable      r2     1     0
.line	648	getupval      r3    u4
.line	648	loadk         r4   k11 ; k11 = 126
.line	648	loadk         r5   k12 ; k12 = 69
.line	648	loadk         r6   k13 ; k13 = 200
.line	648	loadk         r7   k14 ; k14 = 62
.line	648	loadk         r8   k15 ; k15 = 20
.line	648	loadk         r9   k16 ; k16 = 56
.line	648	loadk        r10   k17 ; k17 = 231
.line	648	loadk        r11   k18 ; k18 = 14
.line	648	loadk        r12   k19 ; k19 = 156
.line	648	loadk        r13   k20 ; k20 = 226
.line	648	loadk        r14   k13 ; k13 = 200
.line	648	loadk        r15   k21 ; k21 = 110
.line	648	loadk        r16   k22 ; k22 = 92
.line	648	loadk        r17   k23 ; k23 = 6
.line	648	loadk        r18   k24 ; k24 = 254
.line	648	loadk        r19   k25 ; k25 = 223
.line	648	loadk        r20   k26 ; k26 = 136
.line	648	loadk        r21   k27 ; k27 = 74
.line	648	loadk        r22   k28 ; k28 = 245
.line	648	loadk        r23   k29 ; k29 = 47
.line	648	loadk        r24   k30 ; k30 = 230
.line	648	loadk        r25   k31 ; k31 = 46
.line	648	loadk        r26   k32 ; k32 = 149
.line	648	loadk        r27   k33 ; k33 = 53
.line	648	loadk        r28   k34 ; k34 = 189
.line	648	loadk        r29   k24 ; k24 = 254
.line	648	loadk        r30   k35 ; k35 = 204
.line	648	loadk        r31   k36 ; k36 = 99
.line	648	loadk        r32   k37 ; k37 = 77
.line	648	loadk        r33   k38 ; k38 = 26
.line	648	loadk        r34   k39 ; k39 = 222
.line	648	loadk        r35   k40 ; k40 = 242
.line	648	loadk        r36   k41 ; k41 = 152
.line	648	loadk        r37   k42 ; k42 = 127
.line	648	loadk        r38   k43 ; k43 = 171
.line	648	loadk        r39   k44 ; k44 = 4
.line	648	loadk        r40   k45 ; k45 = 247
.line	648	loadk        r41   k46 ; k46 = 25
.line	648	loadk        r42   k47 ; k47 = 165
.line	648	loadk        r43   k48 ; k48 = 38
.line	648	call          r3    41     2
.line	648	getupval      r4    u4
.line	648	loadk         r5   k49 ; k49 = 83
.line	648	loadk         r6   k50 ; k50 = 73
.line	648	loadk         r7   k51 ; k51 = 212
.line	648	loadk         r8   k11 ; k11 = 126
.line	648	loadk         r9   k52 ; k52 = 88
.line	648	loadk        r10   k53 ; k53 = 22
.line	648	loadk        r11   k54 ; k54 = 243
.line	648	loadk        r12   k55 ; k55 = 30
.line	648	loadk        r13   k56 ; k56 = 172
.line	648	loadk        r14   k57 ; k57 = 235
.line	648	loadk        r15   k58 ; k58 = 198
.line	648	loadk        r16   k59 ; k59 = 112
.line	648	loadk        r17   k22 ; k22 = 92
.line	648	loadk        r18   k33 ; k33 = 53
.line	648	loadk        r19   k60 ; k60 = 196
.line	648	loadk        r20   k45 ; k45 = 247
.line	648	loadk        r21   k61 ; k61 = 174
.line	648	loadk        r22   k49 ; k49 = 83
.line	648	loadk        r23   k56 ; k56 = 172
.line	648	loadk        r24   k62 ; k62 = 15
.line	648	loadk        r25   k30 ; k30 = 230
.line	648	loadk        r26   k63 ; k63 = 52
.line	648	loadk        r27   k64 ; k64 = 129
.line	648	loadk        r28   k65 ; k65 = 51
.line	648	loadk        r29   k66 ; k66 = 167
.line	648	loadk        r30   k67 ; k67 = 220
.line	648	loadk        r31   k68 ; k68 = 209
.line	648	loadk        r32   k69 ; k69 = 42
.line	648	loadk        r33   k70 ; k70 = 7
.line	648	loadk        r34   k71 ; k71 = 58
.line	648	call          r4    31     0
.line	648	setlist       r2     0     1
.line	648	call          r1     2     2
.line	648	gettabup      r2    u1   k72 ; k72 = "tostring"
.line	648	getupval      r3    u2
.line	648	call          r2     2     0
.line	648	call          r0     0     1
.line	648	gettabup      r0    u3   k73 ; k73 = "SaveAutoDownloadSett" (truncated)
.line	648	call          r0     1     1
.line	648	return        r0     1
.line	648	move          r0    r0
.line	648	move          r0    r0
.line	648	return        r0     1

.function	main/f33/f1

.source	null
.linedefined	660
.lastlinedefined	662
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	2	true

.line	660	getupval      r0    u0
.line	660	call          r0     1     1
.line	660	return        r0     1
.line	660	move          r0    r0
.line	660	move          r0    r0
.line	660	return        r0     1

.function	main/f34

.source	null
.linedefined	668
.lastlinedefined	730
.numparams	1
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	9	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	10	true
.upvalue	"U4"	13	true

.constant	k0	"isToggleDownloadingAll"
.constant	k1	"log"
.constant	k2	"bWriteLog"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	126
.constant	k6	69
.constant	k7	200
.constant	k8	62
.constant	k9	20
.constant	k10	56
.constant	k11	231
.constant	k12	14
.constant	k13	156
.constant	k14	226
.constant	k15	110
.constant	k16	92
.constant	k17	6
.constant	k18	254
.constant	k19	223
.constant	k20	136
.constant	k21	74
.constant	k22	245
.constant	k23	63
.constant	k24	220
.constant	k25	8
.constant	k26	145
.constant	k27	61
.constant	k28	191
.constant	k29	218
.constant	k30	253
.constant	k31	120
.constant	k32	85
.constant	k33	39
.constant	k34	215
.constant	k35	233
.constant	k36	187
.constant	k37	158
.constant	k38	28
.constant	k39	244
.constant	k40	89
.constant	k41	198
.constant	k42	26
.constant	k43	79
.constant	k44	76
.constant	k45	217
.constant	k46	53
.constant	k47	10
.constant	k48	4
.constant	k49	241
.constant	k50	3
.constant	k51	183
.constant	k52	204
.constant	k53	193
.constant	k54	41
.constant	k55	118
.constant	k56	54
.constant	k57	248
.constant	k58	166
.constant	k59	117
.constant	k60	174
.constant	k61	225
.constant	k62	9
.constant	k63	27
.constant	k64	211
.constant	k65	153
.constant	k66	42
.constant	k67	2
.constant	k68	"tostring"
.constant	k69	"isDownloadingAllInSmartMode"
.constant	k70	true
.constant	k71	"SmartDownloadTipsCfg"
.constant	k72	"FirstClickSmartDownload"
.constant	k73	false
.constant	k74	"SaveSmartDownloadTipsCfg"
.constant	k75	75
.constant	k76	202
.constant	k77	35
.constant	k78	29
.constant	k79	73
.constant	k80	94
.constant	k81	222
.constant	k82	34
.constant	k83	12
.constant	k84	1
.constant	k85	0
.constant	k86	"ReportTLogEvent"
.constant	k87	"TLogEventDefine"
.constant	k88	"DownloadMainUIDownloadAll"
.constant	k89	57
.constant	k90	87
.constant	k91	205
.constant	k92	36
.constant	k93	60
.constant	k94	175
.constant	k95	192
.constant	k96	99
.constant	k97	119
.constant	k98	55
.constant	k99	127
.constant	k100	239
.constant	k101	93
.constant	k102	168
.constant	k103	"UpdateDownloadSelectedMap"
.constant	k104	"downloadAllTimer"
.constant	k105	"RemoveTimer"
.constant	k106	nil
.constant	k107	"ModuleManager"
.constant	k108	"GetModule"
.constant	k109	"CommonModuleConfig"
.constant	k110	"smart_download_monitor"
.constant	k111	"pairs"
.constant	k112	"downloadSelectMap"
.constant	k113	"insert"
.constant	k114	"allItemData"
.constant	k115	"log_tree"
.constant	k116	86
.constant	k117	67
.constant	k118	88
.constant	k119	106
.constant	k120	"tmpDownloadAllState"
.constant	k121	"Pause"
.constant	k122	"slua"
.constant	k123	"getMiliseconds"
.constant	k124	"AddTimerLoop"
.constant	k125	"TIMER_INFINITE"
.constant	k126	0.03

.line	668	gettabup      r1    u0    k0 ; k0 = "isToggleDownloadingA" (truncated)
.line	668	not           r2    r1
.line	668	settabup      u0    k0    r2 ; k0 = "isToggleDownloadingA" (truncated)
.line	668	gettabup      r2    u1    k1 ; k1 = "log"
.line	668	gettabup      r3    u1    k2 ; k2 = "bWriteLog"
.line	668	test          r3     0
.line	668	jmp            0   l90
.line	668	gettabup      r3    u1    k3 ; k3 = "table"
.line	668	gettable      r3    r3    k4 ; k4 = "concat"
.line	668	newtable      r4     1     0
.line	668	getupval      r5    u2
.line	668	loadk         r6    k5 ; k5 = 126
.line	668	loadk         r7    k6 ; k6 = 69
.line	668	loadk         r8    k7 ; k7 = 200
.line	668	loadk         r9    k8 ; k8 = 62
.line	668	loadk        r10    k9 ; k9 = 20
.line	668	loadk        r11   k10 ; k10 = 56
.line	668	loadk        r12   k11 ; k11 = 231
.line	668	loadk        r13   k12 ; k12 = 14
.line	668	loadk        r14   k13 ; k13 = 156
.line	668	loadk        r15   k14 ; k14 = 226
.line	668	loadk        r16    k7 ; k7 = 200
.line	668	loadk        r17   k15 ; k15 = 110
.line	668	loadk        r18   k16 ; k16 = 92
.line	668	loadk        r19   k17 ; k17 = 6
.line	668	loadk        r20   k18 ; k18 = 254
.line	668	loadk        r21   k19 ; k19 = 223
.line	668	loadk        r22   k20 ; k20 = 136
.line	668	loadk        r23   k21 ; k21 = 74
.line	668	loadk        r24   k22 ; k22 = 245
.line	668	loadk        r25   k23 ; k23 = 63
.line	668	loadk        r26   k24 ; k24 = 220
.line	668	loadk        r27   k25 ; k25 = 8
.line	668	loadk        r28   k26 ; k26 = 145
.line	668	loadk        r29   k27 ; k27 = 61
.line	668	loadk        r30   k28 ; k28 = 191
.line	668	loadk        r31   k29 ; k29 = 218
.line	668	loadk        r32   k30 ; k30 = 253
.line	668	loadk        r33   k31 ; k31 = 120
.line	668	loadk        r34   k32 ; k32 = 85
.line	668	loadk        r35   k33 ; k33 = 39
.line	668	loadk        r36   k34 ; k34 = 215
.line	668	loadk        r37   k35 ; k35 = 233
.line	668	loadk        r38   k36 ; k36 = 187
.line	668	loadk        r39   k15 ; k15 = 110
.line	668	loadk        r40   k37 ; k37 = 158
.line	668	loadk        r41   k38 ; k38 = 28
.line	668	loadk        r42   k39 ; k39 = 244
.line	668	loadk        r43   k40 ; k40 = 89
.line	668	loadk        r44   k41 ; k41 = 198
.line	668	loadk        r45   k42 ; k42 = 26
.line	668	call          r5    41     2
.line	668	getupval      r6    u2
.line	668	loadk         r7   k43 ; k43 = 79
.line	668	loadk         r8   k44 ; k44 = 76
.line	668	loadk         r9   k45 ; k45 = 217
.line	668	loadk        r10   k46 ; k46 = 53
.line	668	loadk        r11   k47 ; k47 = 10
.line	668	loadk        r12   k48 ; k48 = 4
.line	668	loadk        r13   k49 ; k49 = 241
.line	668	loadk        r14   k50 ; k50 = 3
.line	668	loadk        r15   k51 ; k51 = 183
.line	668	loadk        r16   k52 ; k52 = 204
.line	668	loadk        r17   k53 ; k53 = 193
.line	668	loadk        r18   k54 ; k54 = 41
.line	668	loadk        r19   k55 ; k55 = 118
.line	668	loadk        r20   k56 ; k56 = 54
.line	668	loadk        r21   k24 ; k24 = 220
.line	668	loadk        r22   k57 ; k57 = 248
.line	668	loadk        r23   k58 ; k58 = 166
.line	668	loadk        r24   k59 ; k59 = 117
.line	668	loadk        r25   k60 ; k60 = 174
.line	668	loadk        r26   k48 ; k48 = 4
.line	668	loadk        r27   k61 ; k61 = 225
.line	668	loadk        r28   k62 ; k62 = 9
.line	668	loadk        r29   k26 ; k26 = 145
.line	668	loadk        r30   k63 ; k63 = 27
.line	668	loadk        r31   k28 ; k28 = 191
.line	668	loadk        r32   k64 ; k64 = 211
.line	668	loadk        r33   k65 ; k65 = 153
.line	668	loadk        r34   k66 ; k66 = 42
.line	668	loadk        r35   k67 ; k67 = 2
.line	668	call          r6    30     0
.line	668	setlist       r4     0     1
.line	668	call          r3     2     2
.line	668	gettabup      r4    u1   k68 ; k68 = "tostring"
.line	668	gettabup      r5    u0    k0 ; k0 = "isToggleDownloadingA" (truncated)
.line	668	call          r4     2     2
.line	668	concat        r3    r3    r4
.label	l90
.line	668	call          r2     2     1
.line	668	gettabup      r2    u0    k0 ; k0 = "isToggleDownloadingA" (truncated)
.line	668	test          r2     0
.line	668	jmp            0   l95
.line	668	settabup      u0   k69   k70 ; k70 = true
.label	l95
.line	668	gettabup      r2    u0   k69 ; k69 = "isDownloadingAllInSm" (truncated)
.line	668	gettabup      r3    u0   k71 ; k71 = "SmartDownloadTipsCfg"
.line	668	settable      r3   k72   k73 ; k73 = false
.line	668	gettabup      r3    u0   k74 ; k74 = "SaveSmartDownloadTip" (truncated)
.line	668	call          r3     1     1
.line	668	test          r1     0
.line	668	jmp            0  l111
.line	668	getupval      r3    u2
.line	668	loadk         r4   k21 ; k21 = 74
.line	668	loadk         r5   k75 ; k75 = 75
.line	668	loadk         r6   k76 ; k76 = 202
.line	668	loadk         r7   k77 ; k77 = 35
.line	668	loadk         r8   k78 ; k78 = 29
.line	668	call          r3     6     2
.line	668	test          r3     1
.line	668	jmp            0  l118
.label	l111
.line	668	getupval      r3    u2
.line	668	loadk         r4   k79 ; k79 = 73
.line	668	loadk         r5   k80 ; k80 = 94
.line	668	loadk         r6   k81 ; k81 = 222
.line	668	loadk         r7   k82 ; k82 = 34
.line	668	loadk         r8   k83 ; k83 = 12
.line	668	call          r3     6     2
.label	l118
.line	668	test          r2     0
.line	668	jmp            0  l123
.line	668	loadk         r4   k84 ; k84 = 1
.line	668	test          r4     1
.line	668	jmp            0  l124
.label	l123
.line	668	loadk         r4   k85 ; k85 = 0
.label	l124
.line	668	gettabup      r5    u3   k86 ; k86 = "ReportTLogEvent"
.line	668	gettabup      r6    u1   k87 ; k87 = "TLogEventDefine"
.line	668	gettable      r6    r6   k88 ; k88 = "DownloadMainUIDownlo" (truncated)
.line	668	move          r7    r4
.line	668	move          r8    r3
.line	668	call          r5     4     1
.line	668	gettabup      r5    u1    k1 ; k1 = "log"
.line	668	gettabup      r6    u1    k2 ; k2 = "bWriteLog"
.line	668	test          r6     0
.line	668	jmp            0  l208
.line	668	gettabup      r6    u1    k3 ; k3 = "table"
.line	668	gettable      r6    r6    k4 ; k4 = "concat"
.line	668	newtable      r7     1     0
.line	668	getupval      r8    u2
.line	668	loadk         r9    k5 ; k5 = 126
.line	668	loadk        r10    k6 ; k6 = 69
.line	668	loadk        r11    k7 ; k7 = 200
.line	668	loadk        r12    k8 ; k8 = 62
.line	668	loadk        r13    k9 ; k9 = 20
.line	668	loadk        r14   k10 ; k10 = 56
.line	668	loadk        r15   k11 ; k11 = 231
.line	668	loadk        r16   k12 ; k12 = 14
.line	668	loadk        r17   k13 ; k13 = 156
.line	668	loadk        r18   k14 ; k14 = 226
.line	668	loadk        r19    k7 ; k7 = 200
.line	668	loadk        r20   k15 ; k15 = 110
.line	668	loadk        r21   k16 ; k16 = 92
.line	668	loadk        r22   k17 ; k17 = 6
.line	668	loadk        r23   k18 ; k18 = 254
.line	668	loadk        r24   k19 ; k19 = 223
.line	668	loadk        r25   k20 ; k20 = 136
.line	668	loadk        r26   k21 ; k21 = 74
.line	668	loadk        r27   k22 ; k22 = 245
.line	668	loadk        r28   k23 ; k23 = 63
.line	668	loadk        r29   k24 ; k24 = 220
.line	668	loadk        r30   k25 ; k25 = 8
.line	668	loadk        r31   k26 ; k26 = 145
.line	668	loadk        r32   k27 ; k27 = 61
.line	668	loadk        r33   k28 ; k28 = 191
.line	668	loadk        r34   k29 ; k29 = 218
.line	668	loadk        r35   k30 ; k30 = 253
.line	668	loadk        r36   k31 ; k31 = 120
.line	668	loadk        r37   k32 ; k32 = 85
.line	668	loadk        r38   k33 ; k33 = 39
.line	668	loadk        r39   k34 ; k34 = 215
.line	668	loadk        r40   k35 ; k35 = 233
.line	668	loadk        r41   k36 ; k36 = 187
.line	668	loadk        r42   k15 ; k15 = 110
.line	668	loadk        r43   k37 ; k37 = 158
.line	668	loadk        r44   k38 ; k38 = 28
.line	668	loadk        r45   k39 ; k39 = 244
.line	668	loadk        r46   k40 ; k40 = 89
.line	668	loadk        r47   k41 ; k41 = 198
.line	668	loadk        r48   k89 ; k89 = 57
.line	668	call          r8    41     2
.line	668	getupval      r9    u2
.line	668	loadk        r10   k90 ; k90 = 87
.line	668	loadk        r11   k75 ; k75 = 75
.line	668	loadk        r12   k91 ; k91 = 205
.line	668	loadk        r13   k92 ; k92 = 36
.line	668	loadk        r14   k93 ; k93 = 60
.line	668	loadk        r15   k10 ; k10 = 56
.line	668	loadk        r16   k49 ; k49 = 241
.line	668	loadk        r17   k48 ; k48 = 4
.line	668	loadk        r18   k94 ; k94 = 175
.line	668	loadk        r19   k95 ; k95 = 192
.line	668	loadk        r20    k7 ; k7 = 200
.line	668	loadk        r21   k96 ; k96 = 99
.line	668	loadk        r22   k97 ; k97 = 119
.line	668	loadk        r23   k98 ; k98 = 55
.line	668	loadk        r24   k76 ; k76 = 202
.line	668	loadk        r25   k39 ; k39 = 244
.line	668	loadk        r26   k58 ; k58 = 166
.line	668	loadk        r27   k99 ; k99 = 127
.line	668	loadk        r28  k100 ; k100 = 239
.line	668	loadk        r29  k101 ; k101 = 93
.line	668	loadk        r30  k102 ; k102 = 168
.line	668	call          r9    22     0
.line	668	setlist       r7     0     1
.line	668	call          r6     2     2
.line	668	gettabup      r7    u1   k68 ; k68 = "tostring"
.line	668	move          r8    r2
.line	668	call          r7     2     2
.line	668	concat        r6    r6    r7
.label	l208
.line	668	call          r5     2     1
.line	668	self          r5    r0  k103 ; k103 = "UpdateDownloadSelect" (truncated)
.line	668	call          r5     2     1
.line	668	gettable      r5    r0  k104 ; k104 = "downloadAllTimer"
.line	668	test          r5     0
.line	668	jmp            0  l218
.line	668	self          r5    r0  k105 ; k105 = "RemoveTimer"
.line	668	gettable      r7    r0  k104 ; k104 = "downloadAllTimer"
.line	668	call          r5     3     1
.line	668	settable      r0  k104  k106 ; k106 = nil
.label	l218
.line	668	gettabup      r5    u1  k107 ; k107 = "ModuleManager"
.line	668	gettable      r5    r5  k108 ; k108 = "GetModule"
.line	668	gettabup      r6    u1  k107 ; k107 = "ModuleManager"
.line	668	gettable      r6    r6  k109 ; k109 = "CommonModuleConfig"
.line	668	gettable      r6    r6  k110 ; k110 = "smart_download_monit" (truncated)
.line	668	call          r5     2     2
.line	668	newtable      r6     0     0
.line	668	gettabup      r7    u1  k111 ; k111 = "pairs"
.line	668	gettable      r8    r0  k112 ; k112 = "downloadSelectMap"
.line	668	call          r7     2     4
.line	668	jmp            0  l235
.line	668	gettabup     r12    u1    k3 ; k3 = "table"
.line	668	gettable     r12   r12  k113 ; k113 = "insert"
.line	668	move         r13    r6
.line	668	gettable     r14    r0  k114 ; k114 = "allItemData"
.line	668	gettable     r14   r14   r10
.line	668	call         r12     3     1
.label	l235
.line	668	move          r0    r0
.line	668	move          r0    r0
.line	668	gettabup      r7    u1  k115 ; k115 = "log_tree"
.line	668	getupval      r8    u2
.line	668	loadk         r9  k116 ; k116 = 86
.line	668	loadk        r10  k117 ; k117 = 67
.line	668	loadk        r11   k52 ; k52 = 204
.line	668	loadk        r12   k92 ; k92 = 36
.line	668	loadk        r13  k118 ; k118 = 88
.line	668	loadk        r14  k119 ; k119 = 106
.line	668	loadk        r15   k58 ; k58 = 166
.line	668	call          r8     8     2
.line	668	move          r9    r6
.line	668	call          r7     3     1
.line	668	len           r7    r6
.line	668	test          r1     0
.line	668	jmp            0  l254
.line	668	gettabup      r8    u4  k121 ; k121 = "Pause"
.line	668	settable      r0  k120    r8 ; k120 = "tmpDownloadAllState"
.label	l254
.line	668	gettabup      r8    u1  k122 ; k122 = "slua"
.line	668	gettable      r8    r8  k123 ; k123 = "getMiliseconds"
.line	668	call          r8     1     2
.line	668	self          r9    r0  k124 ; k124 = "AddTimerLoop"
.line	668	loadk        r11   k85 ; k85 = 0
.line	668	closure      r12    f0
.line	668	gettabup     r13    u1  k125 ; k125 = "TIMER_INFINITE"
.line	668	loadk        r14  k126 ; k126 = 0.03
.line	668	call          r9     6     2
.line	668	settable      r0  k104    r9 ; k104 = "downloadAllTimer"
.line	668	return        r0     1
.line	668	move          r0    r0
.line	668	move          r0    r0
.line	668	move          r0    r0
.line	668	move          r0    r0
.line	668	return        r0     1

.function	main/f34/f0

.source	null
.linedefined	698
.lastlinedefined	729
.numparams	0
.is_vararg	0
.maxstacksize	53

.upvalue	"_ENV"	1	false
.upvalue	"U1"	6	true
.upvalue	"U2"	0	true
.upvalue	"U3"	1	true
.upvalue	"U4"	2	false
.upvalue	"U5"	8	true
.upvalue	"U6"	5	true
.upvalue	"U7"	7	true

.constant	k0	"slua"
.constant	k1	"getMiliseconds"
.constant	k2	25
.constant	k3	"next"
.constant	k4	1
.constant	k5	-1
.constant	k6	"ToggleDownloadItemData"
.constant	k7	"table"
.constant	k8	"remove"
.constant	k9	"log"
.constant	k10	"bWriteLog"
.constant	k11	"concat"
.constant	k12	126
.constant	k13	69
.constant	k14	200
.constant	k15	62
.constant	k16	20
.constant	k17	56
.constant	k18	231
.constant	k19	14
.constant	k20	156
.constant	k21	226
.constant	k22	110
.constant	k23	92
.constant	k24	6
.constant	k25	254
.constant	k26	223
.constant	k27	136
.constant	k28	74
.constant	k29	245
.constant	k30	63
.constant	k31	220
.constant	k32	8
.constant	k33	145
.constant	k34	61
.constant	k35	191
.constant	k36	218
.constant	k37	253
.constant	k38	120
.constant	k39	85
.constant	k40	39
.constant	k41	215
.constant	k42	233
.constant	k43	187
.constant	k44	158
.constant	k45	28
.constant	k46	244
.constant	k47	89
.constant	k48	198
.constant	k49	41
.constant	k50	203
.constant	k51	4
.constant	k52	17
.constant	k53	58
.constant	k54	227
.constant	k55	143
.constant	k56	"tostring"
.constant	k57	94
.constant	k58	222
.constant	k59	60
.constant	k60	59
.constant	k61	30
.constant	k62	151
.constant	k63	196
.constant	k64	98
.constant	k65	18
.constant	k66	100
.constant	k67	139
.constant	k68	"RemoveTimer"
.constant	k69	"downloadAllTimer"
.constant	k70	nil
.constant	k71	"ModuleManager"
.constant	k72	"GetModule"
.constant	k73	"CommonModuleConfig"
.constant	k74	"puffer_queue"
.constant	k75	"StartDownload"
.constant	k76	"OnPauseSmartDownload"
.constant	k77	"OnSmartDownloadQueueBegin"
.constant	k78	"downloadSelectMap"
.constant	k79	"smartDownloadSize"
.constant	k80	"tmpDownloadAllState"
.constant	k81	"UpdateAllDownloadSize"

.line	698	gettabup      r0    u0    k0 ; k0 = "slua"
.line	698	gettable      r0    r0    k1 ; k1 = "getMiliseconds"
.line	698	call          r0     1     2
.line	698	move          r1    r0
.line	698	loadk         r2    k2 ; k2 = 25
.line	698	gettabup      r3    u0    k3 ; k3 = "next"
.line	698	getupval      r4    u1
.line	698	call          r3     2     2
.line	698	test          r3     0
.line	698	jmp            0  l104
.line	698	getupval      r3    u1
.line	698	len           r3    r3
.line	698	loadk         r4    k4 ; k4 = 1
.line	698	loadk         r5    k5 ; k5 = -1
.line	698	move          r0    r0
.line	698	gettabup      r7    u1    r6
.line	698	getupval      r8    u2
.line	698	self          r8    r8    k6 ; k6 = "ToggleDownloadItemDa" (truncated)
.line	698	move         r10    r7
.line	698	getupval     r11    u3
.line	698	call          r8     4     1
.line	698	gettabup      r8    u0    k7 ; k7 = "table"
.line	698	gettable      r8    r8    k8 ; k8 = "remove"
.line	698	getupval      r9    u1
.line	698	move         r10    r6
.line	698	call          r8     3     1
.line	698	sub           r8    r1    r0
.line	698	gettabup      r9    u0    k0 ; k0 = "slua"
.line	698	gettable      r9    r9    k1 ; k1 = "getMiliseconds"
.line	698	call          r9     1     2
.line	698	move          r1    r9
.line	698	lt             0    r2    r8
.line	698	jmp            0  l103
.line	698	gettabup      r9    u0    k9 ; k9 = "log"
.line	698	gettabup     r10    u0   k10 ; k10 = "bWriteLog"
.line	698	test         r10     0
.line	698	jmp            0  l101
.line	698	gettabup     r10    u0    k7 ; k7 = "table"
.line	698	gettable     r10   r10   k11 ; k11 = "concat"
.line	698	newtable     r11     1     0
.line	698	getupval     r12    u4
.line	698	loadk        r13   k12 ; k12 = 126
.line	698	loadk        r14   k13 ; k13 = 69
.line	698	loadk        r15   k14 ; k14 = 200
.line	698	loadk        r16   k15 ; k15 = 62
.line	698	loadk        r17   k16 ; k16 = 20
.line	698	loadk        r18   k17 ; k17 = 56
.line	698	loadk        r19   k18 ; k18 = 231
.line	698	loadk        r20   k19 ; k19 = 14
.line	698	loadk        r21   k20 ; k20 = 156
.line	698	loadk        r22   k21 ; k21 = 226
.line	698	loadk        r23   k14 ; k14 = 200
.line	698	loadk        r24   k22 ; k22 = 110
.line	698	loadk        r25   k23 ; k23 = 92
.line	698	loadk        r26   k24 ; k24 = 6
.line	698	loadk        r27   k25 ; k25 = 254
.line	698	loadk        r28   k26 ; k26 = 223
.line	698	loadk        r29   k27 ; k27 = 136
.line	698	loadk        r30   k28 ; k28 = 74
.line	698	loadk        r31   k29 ; k29 = 245
.line	698	loadk        r32   k30 ; k30 = 63
.line	698	loadk        r33   k31 ; k31 = 220
.line	698	loadk        r34   k32 ; k32 = 8
.line	698	loadk        r35   k33 ; k33 = 145
.line	698	loadk        r36   k34 ; k34 = 61
.line	698	loadk        r37   k35 ; k35 = 191
.line	698	loadk        r38   k36 ; k36 = 218
.line	698	loadk        r39   k37 ; k37 = 253
.line	698	loadk        r40   k38 ; k38 = 120
.line	698	loadk        r41   k39 ; k39 = 85
.line	698	loadk        r42   k40 ; k40 = 39
.line	698	loadk        r43   k41 ; k41 = 215
.line	698	loadk        r44   k42 ; k42 = 233
.line	698	loadk        r45   k43 ; k43 = 187
.line	698	loadk        r46   k22 ; k22 = 110
.line	698	loadk        r47   k44 ; k44 = 158
.line	698	loadk        r48   k45 ; k45 = 28
.line	698	loadk        r49   k46 ; k46 = 244
.line	698	loadk        r50   k47 ; k47 = 89
.line	698	loadk        r51   k48 ; k48 = 198
.line	698	loadk        r52   k49 ; k49 = 41
.line	698	call         r12    41     2
.line	698	getupval     r13    u4
.line	698	loadk        r14   k39 ; k39 = 85
.line	698	loadk        r15   k47 ; k47 = 89
.line	698	loadk        r16   k50 ; k50 = 203
.line	698	loadk        r17   k51 ; k51 = 4
.line	698	loadk        r18   k52 ; k52 = 17
.line	698	loadk        r19   k53 ; k53 = 58
.line	698	loadk        r20   k54 ; k54 = 227
.line	698	loadk        r21   k28 ; k28 = 74
.line	698	loadk        r22   k25 ; k25 = 254
.line	698	loadk        r23   k55 ; k55 = 143
.line	698	call         r13    11     0
.line	698	setlist      r11     0     1
.line	698	call         r10     2     2
.line	698	gettabup     r11    u0   k56 ; k56 = "tostring"
.line	698	move         r12    r8
.line	698	call         r11     2     2
.line	698	concat       r10   r10   r11
.label	l101
.line	698	call          r9     2     1
.line	698	return        r0     1
.label	l103
.line	698	move          r0    r0
.label	l104
.line	698	gettabup      r3    u0    k3 ; k3 = "next"
.line	698	getupval      r4    u1
.line	698	call          r3     2     2
.line	698	test          r3     1
.line	698	jmp            0  l209
.line	698	gettabup      r3    u0    k9 ; k9 = "log"
.line	698	gettabup      r4    u0   k10 ; k10 = "bWriteLog"
.line	698	test          r4     0
.line	698	jmp            0  l182
.line	698	gettabup      r4    u0    k7 ; k7 = "table"
.line	698	gettable      r4    r4   k11 ; k11 = "concat"
.line	698	newtable      r5     1     0
.line	698	getupval      r6    u4
.line	698	loadk         r7   k12 ; k12 = 126
.line	698	loadk         r8   k13 ; k13 = 69
.line	698	loadk         r9   k14 ; k14 = 200
.line	698	loadk        r10   k15 ; k15 = 62
.line	698	loadk        r11   k16 ; k16 = 20
.line	698	loadk        r12   k17 ; k17 = 56
.line	698	loadk        r13   k18 ; k18 = 231
.line	698	loadk        r14   k19 ; k19 = 14
.line	698	loadk        r15   k20 ; k20 = 156
.line	698	loadk        r16   k21 ; k21 = 226
.line	698	loadk        r17   k14 ; k14 = 200
.line	698	loadk        r18   k22 ; k22 = 110
.line	698	loadk        r19   k23 ; k23 = 92
.line	698	loadk        r20   k24 ; k24 = 6
.line	698	loadk        r21   k25 ; k25 = 254
.line	698	loadk        r22   k26 ; k26 = 223
.line	698	loadk        r23   k27 ; k27 = 136
.line	698	loadk        r24   k28 ; k28 = 74
.line	698	loadk        r25   k29 ; k29 = 245
.line	698	loadk        r26   k30 ; k30 = 63
.line	698	loadk        r27   k31 ; k31 = 220
.line	698	loadk        r28   k32 ; k32 = 8
.line	698	loadk        r29   k33 ; k33 = 145
.line	698	loadk        r30   k34 ; k34 = 61
.line	698	loadk        r31   k35 ; k35 = 191
.line	698	loadk        r32   k36 ; k36 = 218
.line	698	loadk        r33   k37 ; k37 = 253
.line	698	loadk        r34   k38 ; k38 = 120
.line	698	loadk        r35   k39 ; k39 = 85
.line	698	loadk        r36   k40 ; k40 = 39
.line	698	loadk        r37   k41 ; k41 = 215
.line	698	loadk        r38   k42 ; k42 = 233
.line	698	loadk        r39   k43 ; k43 = 187
.line	698	loadk        r40   k22 ; k22 = 110
.line	698	loadk        r41   k44 ; k44 = 158
.line	698	loadk        r42   k45 ; k45 = 28
.line	698	loadk        r43   k46 ; k46 = 244
.line	698	loadk        r44   k47 ; k47 = 89
.line	698	loadk        r45   k48 ; k48 = 198
.line	698	loadk        r46   k15 ; k15 = 62
.line	698	call          r6    41     2
.line	698	getupval      r7    u4
.line	698	loadk         r8   k39 ; k39 = 85
.line	698	loadk         r9   k57 ; k57 = 94
.line	698	loadk        r10   k58 ; k58 = 222
.line	698	loadk        r11   k59 ; k59 = 60
.line	698	loadk        r12   k60 ; k60 = 59
.line	698	loadk        r13   k17 ; k17 = 56
.line	698	loadk        r14   k29 ; k29 = 245
.line	698	loadk        r15   k61 ; k61 = 30
.line	698	loadk        r16   k62 ; k62 = 151
.line	698	loadk        r17   k48 ; k48 = 198
.line	698	loadk        r18   k63 ; k63 = 196
.line	698	loadk        r19   k64 ; k64 = 98
.line	698	loadk        r20   k65 ; k65 = 18
.line	698	loadk        r21   k66 ; k66 = 100
.line	698	loadk        r22   k67 ; k67 = 139
.line	698	call          r7    16     0
.line	698	setlist       r5     0     1
.line	698	call          r4     2     2
.line	698	gettabup      r5    u0   k56 ; k56 = "tostring"
.line	698	getupval      r6    u5
.line	698	sub           r6    r1    r6
.line	698	call          r5     2     2
.line	698	concat        r4    r4    r5
.label	l182
.line	698	call          r3     2     1
.line	698	getupval      r3    u2
.line	698	self          r3    r3   k68 ; k68 = "RemoveTimer"
.line	698	gettabup      r5    u2   k69 ; k69 = "downloadAllTimer"
.line	698	call          r3     3     1
.line	698	settabup      u2   k69   k70 ; k70 = nil
.line	698	getupval      r3    u3
.line	698	test          r3     0
.line	698	jmp            0  l203
.line	698	gettabup      r3    u0   k71 ; k71 = "ModuleManager"
.line	698	gettable      r3    r3   k72 ; k72 = "GetModule"
.line	698	gettabup      r4    u0   k71 ; k71 = "ModuleManager"
.line	698	gettable      r4    r4   k73 ; k73 = "CommonModuleConfig"
.line	698	gettable      r4    r4   k74 ; k74 = "puffer_queue"
.line	698	call          r3     2     2
.line	698	self          r4    r3   k75 ; k75 = "StartDownload"
.line	698	call          r4     2     1
.line	698	getupval      r4    u6
.line	698	self          r4    r4   k76 ; k76 = "OnPauseSmartDownload"
.line	698	call          r4     2     1
.line	698	jmp            0  l209
.label	l203
.line	698	getupval      r3    u6
.line	698	self          r3    r3   k77 ; k77 = "OnSmartDownloadQueue" (truncated)
.line	698	gettabup      r5    u2   k78 ; k78 = "downloadSelectMap"
.line	698	gettabup      r6    u2   k79 ; k79 = "smartDownloadSize"
.line	698	getupval      r7    u7
.line	698	call          r3     5     1
.label	l209
.line	698	settabup      u2   k80   k70 ; k70 = nil
.line	698	getupval      r3    u2
.line	698	self          r3    r3   k81 ; k81 = "UpdateAllDownloadSiz" (truncated)
.line	698	call          r3     2     1
.line	698	return        r0     1
.line	698	move          r0    r0
.line	698	move          r0    r0
.line	698	return        r0     1

.function	main/f35

.source	null
.linedefined	732
.lastlinedefined	736
.numparams	1
.is_vararg	0
.maxstacksize	34

.upvalue	"_ENV"	0	false
.upvalue	"U1"	10	true
.upvalue	"U2"	1	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"ReportTLogEvent"
.constant	k4	"TLogEventDefine"
.constant	k5	"DownloadMainUIWowCache"
.constant	k6	0
.constant	k7	111
.constant	k8	109
.constant	k9	252
.constant	k10	15
.constant	k11	57
.constant	k12	36
.constant	k13	245
.constant	k14	183
.constant	k15	231
.constant	k16	220
.constant	k17	101
.constant	k18	26
.constant	k19	199
.constant	k20	243
.constant	k21	171
.constant	k22	104
.constant	k23	144
.constant	k24	48
.constant	k25	23
.constant	k26	131
.constant	k27	42
.constant	k28	140
.constant	k29	234
.constant	k30	240
.constant	k31	85
.constant	k32	114
.constant	k33	"UIManager"
.constant	k34	"ShowUI"
.constant	k35	"UI_Config"
.constant	k36	"UGC_AssetHub_Clear_Popup_UIBP"

.line	732	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	732	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	732	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	732	call          r1     3     1
.line	732	gettabup      r1    u1    k3 ; k3 = "ReportTLogEvent"
.line	732	gettabup      r2    u0    k4 ; k4 = "TLogEventDefine"
.line	732	gettable      r2    r2    k5 ; k5 = "DownloadMainUIWowCac" (truncated)
.line	732	loadk         r3    k6 ; k6 = 0
.line	732	getupval      r4    u2
.line	732	loadk         r5    k7 ; k7 = 111
.line	732	loadk         r6    k8 ; k8 = 109
.line	732	loadk         r7    k9 ; k9 = 252
.line	732	loadk         r8   k10 ; k10 = 15
.line	732	loadk         r9   k11 ; k11 = 57
.line	732	loadk        r10   k12 ; k12 = 36
.line	732	loadk        r11   k13 ; k13 = 245
.line	732	loadk        r12   k10 ; k10 = 15
.line	732	loadk        r13   k14 ; k14 = 183
.line	732	loadk        r14   k15 ; k15 = 231
.line	732	loadk        r15   k16 ; k16 = 220
.line	732	loadk        r16   k17 ; k17 = 101
.line	732	loadk        r17    k8 ; k8 = 109
.line	732	loadk        r18   k18 ; k18 = 26
.line	732	loadk        r19   k19 ; k19 = 199
.line	732	loadk        r20   k20 ; k20 = 243
.line	732	loadk        r21   k21 ; k21 = 171
.line	732	loadk        r22   k22 ; k22 = 104
.line	732	loadk        r23   k23 ; k23 = 144
.line	732	loadk        r24   k24 ; k24 = 48
.line	732	loadk        r25   k15 ; k15 = 231
.line	732	loadk        r26   k25 ; k25 = 23
.line	732	loadk        r27   k26 ; k26 = 131
.line	732	loadk        r28   k27 ; k27 = 42
.line	732	loadk        r29   k28 ; k28 = 140
.line	732	loadk        r30   k29 ; k29 = 234
.line	732	loadk        r31   k30 ; k30 = 240
.line	732	loadk        r32   k31 ; k31 = 85
.line	732	loadk        r33   k32 ; k32 = 114
.line	732	call          r4    30     2
.line	732	call          r1     4     1
.line	732	gettabup      r1    u0   k33 ; k33 = "UIManager"
.line	732	gettable      r1    r1   k34 ; k34 = "ShowUI"
.line	732	gettabup      r2    u0   k33 ; k33 = "UIManager"
.line	732	gettable      r2    r2   k35 ; k35 = "UI_Config"
.line	732	gettable      r2    r2   k36 ; k36 = "UGC_AssetHub_Clear_P" (truncated)
.line	732	call          r1     2     1
.line	732	return        r0     1
.line	732	move          r0    r0
.line	732	return        r0     1

.function	main/f36

.source	null
.linedefined	738
.lastlinedefined	748
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	10	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"require"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	89
.constant	k7	70
.constant	k8	214
.constant	k9	53
.constant	k10	22
.constant	k11	35
.constant	k12	168
.constant	k13	25
.constant	k14	175
.constant	k15	218
.constant	k16	200
.constant	k17	41
.constant	k18	94
.constant	k19	54
.constant	k20	204
.constant	k21	255
.constant	k22	169
.constant	k23	52
.constant	k24	171
.constant	k25	15
.constant	k26	9
.constant	k27	154
.constant	k28	178
.constant	k29	219
.constant	k30	151
.constant	k31	113
.constant	k32	75
.constant	k33	61
.constant	k34	149
.constant	k35	234
.constant	k36	181
.constant	k37	109
.constant	k38	182
.constant	k39	19
.constant	k40	199
.constant	k41	17
.constant	k42	143
.constant	k43	62
.constant	k44	108
.constant	k45	79
.constant	k46	205
.constant	k47	56
.constant	k48	232
.constant	k49	167
.constant	k50	192
.constant	k51	222
.constant	k52	105
.constant	k53	202
.constant	k54	242
.constant	k55	"IfNotFitLobbyResDownloadedShowWindow"
.constant	k56	"CloseSelf"
.constant	k57	"ReportTLogEvent"
.constant	k58	"TLogEventDefine"
.constant	k59	"DownloadMainUIWowCache"
.constant	k60	0
.constant	k61	121
.constant	k62	88
.constant	k63	49
.constant	k64	12
.constant	k65	240
.constant	k66	142
.constant	k67	98
.constant	k68	43
.constant	k69	206
.constant	k70	120
.constant	k71	130
.constant	k72	1
.constant	k73	228
.constant	k74	11
.constant	k75	166
.constant	k76	40
.constant	k77	217
.constant	k78	216
.constant	k79	117
.constant	k80	111
.constant	k81	210
.constant	k82	67
.constant	k83	186
.constant	k84	7
.constant	k85	235
.constant	k86	73
.constant	k87	189
.constant	k88	208
.constant	k89	112
.constant	k90	125
.constant	k91	60
.constant	k92	220
.constant	k93	229
.constant	k94	"UIManager"
.constant	k95	"ShowUI"
.constant	k96	"UI_Config"
.constant	k97	"CreativeModePrefabMallPrefabMainUI"
.constant	k98	"Enum_PrefaMall_ResMgrTagID"
.constant	k99	"MyPrivate"

.line	738	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	738	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	738	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	738	call          r1     3     1
.line	738	gettabup      r1    u0    k3 ; k3 = "require"
.line	738	gettabup      r2    u0    k4 ; k4 = "table"
.line	738	gettable      r2    r2    k5 ; k5 = "concat"
.line	738	newtable      r3     1     0
.line	738	getupval      r4    u1
.line	738	loadk         r5    k6 ; k6 = 89
.line	738	loadk         r6    k7 ; k7 = 70
.line	738	loadk         r7    k8 ; k8 = 214
.line	738	loadk         r8    k9 ; k9 = 53
.line	738	loadk         r9   k10 ; k10 = 22
.line	738	loadk        r10   k11 ; k11 = 35
.line	738	loadk        r11   k12 ; k12 = 168
.line	738	loadk        r12   k13 ; k13 = 25
.line	738	loadk        r13   k14 ; k14 = 175
.line	738	loadk        r14   k15 ; k15 = 218
.line	738	loadk        r15   k16 ; k16 = 200
.line	738	loadk        r16   k17 ; k17 = 41
.line	738	loadk        r17   k18 ; k18 = 94
.line	738	loadk        r18   k19 ; k19 = 54
.line	738	loadk        r19   k20 ; k20 = 204
.line	738	loadk        r20   k21 ; k21 = 255
.line	738	loadk        r21   k22 ; k22 = 169
.line	738	loadk        r22   k23 ; k23 = 52
.line	738	loadk        r23   k24 ; k24 = 171
.line	738	loadk        r24   k25 ; k25 = 15
.line	738	loadk        r25   k21 ; k21 = 255
.line	738	loadk        r26   k26 ; k26 = 9
.line	738	loadk        r27   k27 ; k27 = 154
.line	738	loadk        r28    k9 ; k9 = 53
.line	738	loadk        r29   k28 ; k28 = 178
.line	738	loadk        r30   k29 ; k29 = 219
.line	738	loadk        r31   k30 ; k30 = 151
.line	738	loadk        r32   k31 ; k31 = 113
.line	738	loadk        r33   k32 ; k32 = 75
.line	738	loadk        r34   k33 ; k33 = 61
.line	738	loadk        r35   k34 ; k34 = 149
.line	738	loadk        r36   k35 ; k35 = 234
.line	738	loadk        r37   k36 ; k36 = 181
.line	738	loadk        r38   k37 ; k37 = 109
.line	738	loadk        r39   k38 ; k38 = 182
.line	738	loadk        r40   k39 ; k39 = 19
.line	738	loadk        r41   k40 ; k40 = 199
.line	738	loadk        r42   k41 ; k41 = 17
.line	738	loadk        r43   k42 ; k42 = 143
.line	738	loadk        r44   k43 ; k43 = 62
.line	738	call          r4    41     2
.line	738	getupval      r5    u1
.line	738	loadk         r6   k44 ; k44 = 108
.line	738	loadk         r7   k45 ; k45 = 79
.line	738	loadk         r8   k46 ; k46 = 205
.line	738	loadk         r9   k11 ; k11 = 35
.line	738	loadk        r10   k41 ; k41 = 17
.line	738	loadk        r11   k47 ; k47 = 56
.line	738	loadk        r12   k48 ; k48 = 232
.line	738	loadk        r13    k9 ; k9 = 53
.line	738	loadk        r14   k49 ; k49 = 167
.line	738	loadk        r15   k50 ; k50 = 192
.line	738	loadk        r16   k51 ; k51 = 222
.line	738	loadk        r17   k52 ; k52 = 105
.line	738	loadk        r18   k18 ; k18 = 94
.line	738	loadk        r19   k19 ; k19 = 54
.line	738	loadk        r20   k53 ; k53 = 202
.line	738	loadk        r21   k54 ; k54 = 242
.line	738	call          r5    17     0
.line	738	setlist       r3     0     1
.line	738	call          r2     2     2
.line	738	call          r1     2     2
.line	738	gettable      r2    r1   k55 ; k55 = "IfNotFitLobbyResDown" (truncated)
.line	738	call          r2     1     2
.line	738	test          r2     0
.line	738	jmp            0   l77
.line	738	return        r0     1
.label	l77
.line	738	self          r2    r0   k56 ; k56 = "CloseSelf"
.line	738	call          r2     2     1
.line	738	gettabup      r2    u2   k57 ; k57 = "ReportTLogEvent"
.line	738	gettabup      r3    u0   k58 ; k58 = "TLogEventDefine"
.line	738	gettable      r3    r3   k59 ; k59 = "DownloadMainUIWowCac" (truncated)
.line	738	loadk         r4   k60 ; k60 = 0
.line	738	getupval      r5    u1
.line	738	loadk         r6   k61 ; k61 = 121
.line	738	loadk         r7   k62 ; k62 = 88
.line	738	loadk         r8   k15 ; k15 = 218
.line	738	loadk         r9   k63 ; k63 = 49
.line	738	loadk        r10   k64 ; k64 = 12
.line	738	loadk        r11   k43 ; k43 = 62
.line	738	loadk        r12   k65 ; k65 = 240
.line	738	loadk        r13   k25 ; k25 = 15
.line	738	loadk        r14   k66 ; k66 = 142
.line	738	loadk        r15   k50 ; k50 = 192
.line	738	loadk        r16   k46 ; k46 = 205
.line	738	loadk        r17   k67 ; k67 = 98
.line	738	loadk        r18   k67 ; k67 = 98
.line	738	loadk        r19   k68 ; k68 = 43
.line	738	loadk        r20   k69 ; k69 = 206
.line	738	loadk        r21   k65 ; k65 = 240
.line	738	loadk        r22   k24 ; k24 = 171
.line	738	loadk        r23   k70 ; k70 = 120
.line	738	loadk        r24   k71 ; k71 = 130
.line	738	loadk        r25   k72 ; k72 = 1
.line	738	loadk        r26   k73 ; k73 = 228
.line	738	loadk        r27   k74 ; k74 = 11
.line	738	loadk        r28   k75 ; k75 = 166
.line	738	loadk        r29   k76 ; k76 = 40
.line	738	loadk        r30   k38 ; k38 = 182
.line	738	loadk        r31   k77 ; k77 = 217
.line	738	loadk        r32   k78 ; k78 = 216
.line	738	loadk        r33   k79 ; k79 = 117
.line	738	loadk        r34   k80 ; k80 = 111
.line	738	loadk        r35   k76 ; k76 = 40
.line	738	loadk        r36   k81 ; k81 = 210
.line	738	loadk        r37   k48 ; k48 = 232
.line	738	loadk        r38   k42 ; k42 = 143
.line	738	loadk        r39   k82 ; k82 = 67
.line	738	call          r5    35     2
.line	738	call          r2     4     1
.line	738	gettabup      r2    u0    k3 ; k3 = "require"
.line	738	getupval      r3    u1
.line	738	loadk         r4    k6 ; k6 = 89
.line	738	loadk         r5    k7 ; k7 = 70
.line	738	loadk         r6    k8 ; k8 = 214
.line	738	loadk         r7    k9 ; k9 = 53
.line	738	loadk         r8   k10 ; k10 = 22
.line	738	loadk         r9   k11 ; k11 = 35
.line	738	loadk        r10   k12 ; k12 = 168
.line	738	loadk        r11   k13 ; k13 = 25
.line	738	loadk        r12   k14 ; k14 = 175
.line	738	loadk        r13   k15 ; k15 = 218
.line	738	loadk        r14   k16 ; k16 = 200
.line	738	loadk        r15   k17 ; k17 = 41
.line	738	loadk        r16   k18 ; k18 = 94
.line	738	loadk        r17   k19 ; k19 = 54
.line	738	loadk        r18   k20 ; k20 = 204
.line	738	loadk        r19   k21 ; k21 = 255
.line	738	loadk        r20   k22 ; k22 = 169
.line	738	loadk        r21   k23 ; k23 = 52
.line	738	loadk        r22   k83 ; k83 = 186
.line	738	loadk        r23   k84 ; k84 = 7
.line	738	loadk        r24   k85 ; k85 = 235
.line	738	loadk        r25   k86 ; k86 = 73
.line	738	loadk        r26   k34 ; k34 = 149
.line	738	loadk        r27    k9 ; k9 = 53
.line	738	loadk        r28   k87 ; k87 = 189
.line	738	loadk        r29   k77 ; k77 = 217
.line	738	loadk        r30   k88 ; k88 = 208
.line	738	loadk        r31   k89 ; k89 = 112
.line	738	loadk        r32   k90 ; k90 = 125
.line	738	loadk        r33   k91 ; k91 = 60
.line	738	loadk        r34   k92 ; k92 = 220
.line	738	loadk        r35   k93 ; k93 = 229
.line	738	call          r3    33     2
.line	738	call          r2     2     2
.line	738	gettabup      r3    u0   k94 ; k94 = "UIManager"
.line	738	gettable      r3    r3   k95 ; k95 = "ShowUI"
.line	738	gettabup      r4    u0   k94 ; k94 = "UIManager"
.line	738	gettable      r4    r4   k96 ; k96 = "UI_Config"
.line	738	gettable      r4    r4   k97 ; k97 = "CreativeModePrefabMa" (truncated)
.line	738	gettable      r5    r2   k98 ; k98 = "Enum_PrefaMall_ResMg" (truncated)
.line	738	gettable      r5    r5   k99 ; k99 = "MyPrivate"
.line	738	call          r3     3     1
.line	738	return        r0     1
.line	738	move          r0    r0
.line	738	move          r0    r0
.line	738	move          r0    r0
.line	738	move          r0    r0
.line	738	return        r0     1

.function	main/f37

.source	null
.linedefined	750
.lastlinedefined	758
.numparams	1
.is_vararg	0
.maxstacksize	24

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"require"
.constant	k4	89
.constant	k5	70
.constant	k6	214
.constant	k7	53
.constant	k8	22
.constant	k9	35
.constant	k10	168
.constant	k11	9
.constant	k12	172
.constant	k13	194
.constant	k14	196
.constant	k15	104
.constant	k16	92
.constant	k17	119
.constant	k18	222
.constant	k19	255
.constant	k20	149
.constant	k21	111
.constant	k22	187
.constant	k23	228
.constant	k24	"GetWidgetViewportPos"
.constant	k25	"UIRoot"
.constant	k26	"Button_Help"
.constant	k27	"UIManager"
.constant	k28	"ShowUI"
.constant	k29	"UI_Config"
.constant	k30	"Common_HelpTips_UIBP"
.constant	k31	"ShowPanelStrWithPos"
.constant	k32	"LocUtil"
.constant	k33	"GetLocalizeStrConcatenation"
.constant	k34	468890021
.constant	k35	"X"
.constant	k36	"Y"
.constant	k37	25

.line	750	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	750	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	750	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	750	call          r1     3     1
.line	750	gettabup      r1    u0    k3 ; k3 = "require"
.line	750	getupval      r2    u1
.line	750	loadk         r3    k4 ; k4 = 89
.line	750	loadk         r4    k5 ; k5 = 70
.line	750	loadk         r5    k6 ; k6 = 214
.line	750	loadk         r6    k7 ; k7 = 53
.line	750	loadk         r7    k8 ; k8 = 22
.line	750	loadk         r8    k9 ; k9 = 35
.line	750	loadk         r9   k10 ; k10 = 168
.line	750	loadk        r10   k11 ; k11 = 9
.line	750	loadk        r11   k12 ; k12 = 172
.line	750	loadk        r12   k13 ; k13 = 194
.line	750	loadk        r13   k14 ; k14 = 196
.line	750	loadk        r14   k15 ; k15 = 104
.line	750	loadk        r15   k16 ; k16 = 92
.line	750	loadk        r16   k17 ; k17 = 119
.line	750	loadk        r17   k18 ; k18 = 222
.line	750	loadk        r18   k19 ; k19 = 255
.line	750	loadk        r19   k20 ; k20 = 149
.line	750	loadk        r20   k21 ; k21 = 111
.line	750	loadk        r21   k22 ; k22 = 187
.line	750	loadk        r22   k11 ; k11 = 9
.line	750	loadk        r23   k23 ; k23 = 228
.line	750	call          r2    22     2
.line	750	call          r1     2     2
.line	750	gettable      r2    r1   k24 ; k24 = "GetWidgetViewportPos"
.line	750	gettable      r3    r0   k25 ; k25 = "UIRoot"
.line	750	gettable      r3    r3   k26 ; k26 = "Button_Help"
.line	750	call          r2     2     2
.line	750	gettabup      r3    u0   k27 ; k27 = "UIManager"
.line	750	gettable      r3    r3   k28 ; k28 = "ShowUI"
.line	750	gettabup      r4    u0   k27 ; k27 = "UIManager"
.line	750	gettable      r4    r4   k29 ; k29 = "UI_Config"
.line	750	gettable      r4    r4   k30 ; k30 = "Common_HelpTips_UIBP"
.line	750	call          r3     2     2
.line	750	test          r3     0
.line	750	jmp            0   l53
.line	750	self          r4    r3   k31 ; k31 = "ShowPanelStrWithPos"
.line	750	gettabup      r6    u0   k32 ; k32 = "LocUtil"
.line	750	gettable      r6    r6   k33 ; k33 = "GetLocalizeStrConcat" (truncated)
.line	750	loadk         r7   k34 ; k34 = 468890021
.line	750	call          r6     2     2
.line	750	gettable      r7    r2   k35 ; k35 = "X"
.line	750	gettable      r8    r2   k36 ; k36 = "Y"
.line	750	add           r8    r8   k37 ; k37 = 25
.line	750	loadbool      r9     1     0
.line	750	loadbool     r10     1     0
.line	750	call          r4     7     1
.label	l53
.line	750	return        r0     1
.line	750	move          r0    r0
.line	750	return        r0     1

.function	main/f38

.source	null
.linedefined	760
.lastlinedefined	765
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"_PufferDeleteManager"
.constant	k1	"require"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	89
.constant	k5	70
.constant	k6	214
.constant	k7	53
.constant	k8	22
.constant	k9	35
.constant	k10	168
.constant	k11	25
.constant	k12	175
.constant	k13	218
.constant	k14	200
.constant	k15	41
.constant	k16	94
.constant	k17	54
.constant	k18	204
.constant	k19	255
.constant	k20	169
.constant	k21	52
.constant	k22	171
.constant	k23	15
.constant	k24	9
.constant	k25	154
.constant	k26	178
.constant	k27	219
.constant	k28	151
.constant	k29	115
.constant	k30	71
.constant	k31	37
.constant	k32	222
.constant	k33	242
.constant	k34	191
.constant	k35	36
.constant	k36	5
.constant	k37	254
.constant	k38	17
.constant	k39	131
.constant	k40	56
.constant	k41	101
.constant	k42	78
.constant	k43	60
.constant	k44	29
.constant	k45	227
.constant	k46	174
.constant	k47	206
.constant	k48	199
.constant	k49	102
.constant	k50	85
.constant	k51	217

.line	760	gettable      r1    r0    k0 ; k0 = "_PufferDeleteManager"
.line	760	test          r1     1
.line	760	jmp            0   l71
.line	760	gettabup      r1    u0    k1 ; k1 = "require"
.line	760	gettabup      r2    u0    k2 ; k2 = "table"
.line	760	gettable      r2    r2    k3 ; k3 = "concat"
.line	760	newtable      r3     1     0
.line	760	getupval      r4    u1
.line	760	loadk         r5    k4 ; k4 = 89
.line	760	loadk         r6    k5 ; k5 = 70
.line	760	loadk         r7    k6 ; k6 = 214
.line	760	loadk         r8    k7 ; k7 = 53
.line	760	loadk         r9    k8 ; k8 = 22
.line	760	loadk        r10    k9 ; k9 = 35
.line	760	loadk        r11   k10 ; k10 = 168
.line	760	loadk        r12   k11 ; k11 = 25
.line	760	loadk        r13   k12 ; k12 = 175
.line	760	loadk        r14   k13 ; k13 = 218
.line	760	loadk        r15   k14 ; k14 = 200
.line	760	loadk        r16   k15 ; k15 = 41
.line	760	loadk        r17   k16 ; k16 = 94
.line	760	loadk        r18   k17 ; k17 = 54
.line	760	loadk        r19   k18 ; k18 = 204
.line	760	loadk        r20   k19 ; k19 = 255
.line	760	loadk        r21   k20 ; k20 = 169
.line	760	loadk        r22   k21 ; k21 = 52
.line	760	loadk        r23   k22 ; k22 = 171
.line	760	loadk        r24   k23 ; k23 = 15
.line	760	loadk        r25   k19 ; k19 = 255
.line	760	loadk        r26   k24 ; k24 = 9
.line	760	loadk        r27   k25 ; k25 = 154
.line	760	loadk        r28    k7 ; k7 = 53
.line	760	loadk        r29   k26 ; k26 = 178
.line	760	loadk        r30   k27 ; k27 = 219
.line	760	loadk        r31   k28 ; k28 = 151
.line	760	loadk        r32   k29 ; k29 = 115
.line	760	loadk        r33   k30 ; k30 = 71
.line	760	loadk        r34   k31 ; k31 = 37
.line	760	loadk        r35   k32 ; k32 = 222
.line	760	loadk        r36   k33 ; k33 = 242
.line	760	loadk        r37   k34 ; k34 = 191
.line	760	loadk        r38   k35 ; k35 = 36
.line	760	loadk        r39   k12 ; k12 = 175
.line	760	loadk        r40   k36 ; k36 = 5
.line	760	loadk        r41   k37 ; k37 = 254
.line	760	loadk        r42   k38 ; k38 = 17
.line	760	loadk        r43   k39 ; k39 = 131
.line	760	loadk        r44   k40 ; k40 = 56
.line	760	call          r4    41     2
.line	760	getupval      r5    u1
.line	760	loadk         r6   k41 ; k41 = 101
.line	760	loadk         r7   k42 ; k42 = 78
.line	760	loadk         r8   k13 ; k13 = 218
.line	760	loadk         r9   k43 ; k43 = 60
.line	760	loadk        r10   k44 ; k44 = 29
.line	760	loadk        r11    k9 ; k9 = 35
.line	760	loadk        r12   k45 ; k45 = 227
.line	760	loadk        r13    k7 ; k7 = 53
.line	760	loadk        r14   k46 ; k46 = 174
.line	760	loadk        r15   k47 ; k47 = 206
.line	760	loadk        r16   k48 ; k48 = 199
.line	760	loadk        r17   k49 ; k49 = 102
.line	760	loadk        r18   k50 ; k50 = 85
.line	760	loadk        r19   k43 ; k43 = 60
.line	760	loadk        r20   k51 ; k51 = 217
.line	760	call          r5    16     0
.line	760	setlist       r3     0     1
.line	760	call          r2     2     2
.line	760	call          r1     2     2
.line	760	settable      r0    k0    r1 ; k0 = "_PufferDeleteManager"
.label	l71
.line	760	gettable      r1    r0    k0 ; k0 = "_PufferDeleteManager"
.line	760	return        r1     2
.line	760	return        r0     1
.line	760	move          r0    r0
.line	760	move          r0    r0
.line	760	move          r0    r0
.line	760	move          r0    r0
.line	760	return        r0     1

.function	main/f39

.source	null
.linedefined	767
.lastlinedefined	772
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"_CommonDownloadHandler"
.constant	k1	"require"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	89
.constant	k5	70
.constant	k6	214
.constant	k7	53
.constant	k8	22
.constant	k9	35
.constant	k10	168
.constant	k11	25
.constant	k12	175
.constant	k13	218
.constant	k14	200
.constant	k15	41
.constant	k16	81
.constant	k17	54
.constant	k18	198
.constant	k19	251
.constant	k20	165
.constant	k21	116
.constant	k22	225
.constant	k23	3
.constant	k24	231
.constant	k25	10
.constant	k26	155
.constant	k27	189
.constant	k28	224
.constant	k29	221
.constant	k30	120
.constant	k31	85
.constant	k32	39
.constant	k33	215
.constant	k34	233
.constant	k35	187
.constant	k36	110
.constant	k37	128
.constant	k38	24
.constant	k39	249
.constant	k40	130
.constant	k41	38
.constant	k42	95
.constant	k43	88

.line	767	gettable      r1    r0    k0 ; k0 = "_CommonDownloadHandl" (truncated)
.line	767	test          r1     1
.line	767	jmp            0   l58
.line	767	gettabup      r1    u0    k1 ; k1 = "require"
.line	767	gettabup      r2    u0    k2 ; k2 = "table"
.line	767	gettable      r2    r2    k3 ; k3 = "concat"
.line	767	newtable      r3     1     0
.line	767	getupval      r4    u1
.line	767	loadk         r5    k4 ; k4 = 89
.line	767	loadk         r6    k5 ; k5 = 70
.line	767	loadk         r7    k6 ; k6 = 214
.line	767	loadk         r8    k7 ; k7 = 53
.line	767	loadk         r9    k8 ; k8 = 22
.line	767	loadk        r10    k9 ; k9 = 35
.line	767	loadk        r11   k10 ; k10 = 168
.line	767	loadk        r12   k11 ; k11 = 25
.line	767	loadk        r13   k12 ; k12 = 175
.line	767	loadk        r14   k13 ; k13 = 218
.line	767	loadk        r15   k14 ; k14 = 200
.line	767	loadk        r16   k15 ; k15 = 41
.line	767	loadk        r17   k16 ; k16 = 81
.line	767	loadk        r18   k17 ; k17 = 54
.line	767	loadk        r19   k18 ; k18 = 198
.line	767	loadk        r20   k19 ; k19 = 251
.line	767	loadk        r21   k20 ; k20 = 165
.line	767	loadk        r22   k21 ; k21 = 116
.line	767	loadk        r23   k22 ; k22 = 225
.line	767	loadk        r24   k23 ; k23 = 3
.line	767	loadk        r25   k24 ; k24 = 231
.line	767	loadk        r26   k25 ; k25 = 10
.line	767	loadk        r27   k26 ; k26 = 155
.line	767	loadk        r28    k7 ; k7 = 53
.line	767	loadk        r29   k27 ; k27 = 189
.line	767	loadk        r30   k28 ; k28 = 224
.line	767	loadk        r31   k29 ; k29 = 221
.line	767	loadk        r32   k30 ; k30 = 120
.line	767	loadk        r33   k31 ; k31 = 85
.line	767	loadk        r34   k32 ; k32 = 39
.line	767	loadk        r35   k33 ; k33 = 215
.line	767	loadk        r36   k34 ; k34 = 233
.line	767	loadk        r37   k35 ; k35 = 187
.line	767	loadk        r38   k36 ; k36 = 110
.line	767	loadk        r39   k37 ; k37 = 128
.line	767	loadk        r40   k38 ; k38 = 24
.line	767	loadk        r41   k39 ; k39 = 249
.line	767	loadk        r42   k11 ; k11 = 25
.line	767	loadk        r43   k40 ; k40 = 130
.line	767	loadk        r44   k41 ; k41 = 38
.line	767	call          r4    41     2
.line	767	getupval      r5    u1
.line	767	loadk         r6   k42 ; k42 = 95
.line	767	loadk         r7   k43 ; k43 = 88
.line	767	call          r5     3     0
.line	767	setlist       r3     0     1
.line	767	call          r2     2     2
.line	767	call          r1     2     2
.line	767	settable      r0    k0    r1 ; k0 = "_CommonDownloadHandl" (truncated)
.label	l58
.line	767	gettable      r1    r0    k0 ; k0 = "_CommonDownloadHandl" (truncated)
.line	767	return        r1     2
.line	767	return        r0     1
.line	767	move          r0    r0
.line	767	move          r0    r0
.line	767	return        r0     1

.function	main/f40

.source	null
.linedefined	774
.lastlinedefined	784
.numparams	1
.is_vararg	0
.maxstacksize	30

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	126
.constant	k3	69
.constant	k4	200
.constant	k5	62
.constant	k6	20
.constant	k7	56
.constant	k8	231
.constant	k9	14
.constant	k10	156
.constant	k11	226
.constant	k12	110
.constant	k13	92
.constant	k14	6
.constant	k15	254
.constant	k16	223
.constant	k17	136
.constant	k18	74
.constant	k19	245
.constant	k20	53
.constant	k21	248
.constant	k22	3
.constant	k23	151
.constant	k24	46
.constant	k25	182
.constant	k26	234
.constant	k27	240
.constant	k28	"UpdateDownloadAllButtonText"
.constant	k29	"UpdateReverseDownloadInfo"
.constant	k30	"UpdateNetworkInfo"
.constant	k31	"UpdateRecommendInfo"
.constant	k32	"UpdateGameSize"
.constant	k33	"UpdateAutoDownload"
.constant	k34	"UpdateAutoDownloadIcon"
.constant	k35	"UpdateAllDownloadSize"

.line	774	gettabup      r1    u0    k0 ; k0 = "log"
.line	774	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	774	test          r2     0
.line	774	jmp            0   l34
.line	774	getupval      r2    u1
.line	774	loadk         r3    k2 ; k2 = 126
.line	774	loadk         r4    k3 ; k3 = 69
.line	774	loadk         r5    k4 ; k4 = 200
.line	774	loadk         r6    k5 ; k5 = 62
.line	774	loadk         r7    k6 ; k6 = 20
.line	774	loadk         r8    k7 ; k7 = 56
.line	774	loadk         r9    k8 ; k8 = 231
.line	774	loadk        r10    k9 ; k9 = 14
.line	774	loadk        r11   k10 ; k10 = 156
.line	774	loadk        r12   k11 ; k11 = 226
.line	774	loadk        r13    k4 ; k4 = 200
.line	774	loadk        r14   k12 ; k12 = 110
.line	774	loadk        r15   k13 ; k13 = 92
.line	774	loadk        r16   k14 ; k14 = 6
.line	774	loadk        r17   k15 ; k15 = 254
.line	774	loadk        r18   k16 ; k16 = 223
.line	774	loadk        r19   k17 ; k17 = 136
.line	774	loadk        r20   k18 ; k18 = 74
.line	774	loadk        r21   k19 ; k19 = 245
.line	774	loadk        r22   k20 ; k20 = 53
.line	774	loadk        r23   k21 ; k21 = 248
.line	774	loadk        r24   k22 ; k22 = 3
.line	774	loadk        r25   k23 ; k23 = 151
.line	774	loadk        r26   k24 ; k24 = 46
.line	774	loadk        r27   k25 ; k25 = 182
.line	774	loadk        r28   k26 ; k26 = 234
.line	774	loadk        r29   k27 ; k27 = 240
.line	774	call          r2    28     2
.label	l34
.line	774	call          r1     2     1
.line	774	self          r1    r0   k28 ; k28 = "UpdateDownloadAllBut" (truncated)
.line	774	call          r1     2     1
.line	774	self          r1    r0   k29 ; k29 = "UpdateReverseDownloa" (truncated)
.line	774	call          r1     2     1
.line	774	self          r1    r0   k30 ; k30 = "UpdateNetworkInfo"
.line	774	call          r1     2     1
.line	774	self          r1    r0   k31 ; k31 = "UpdateRecommendInfo"
.line	774	call          r1     2     1
.line	774	self          r1    r0   k32 ; k32 = "UpdateGameSize"
.line	774	call          r1     2     1
.line	774	self          r1    r0   k33 ; k33 = "UpdateAutoDownload"
.line	774	call          r1     2     1
.line	774	self          r1    r0   k34 ; k34 = "UpdateAutoDownloadIc" (truncated)
.line	774	call          r1     2     1
.line	774	self          r1    r0   k35 ; k35 = "UpdateAllDownloadSiz" (truncated)
.line	774	call          r1     2     1
.line	774	return        r0     1
.line	774	move          r0    r0
.line	774	move          r0    r0
.line	774	move          r0    r0
.line	774	return        r0     1

.function	main/f41

.source	null
.linedefined	786
.lastlinedefined	794
.numparams	1
.is_vararg	0
.maxstacksize	41

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	23	true

.constant	k0	"isFitVersion"
.constant	k1	"log_format"
.constant	k2	126
.constant	k3	69
.constant	k4	200
.constant	k5	62
.constant	k6	20
.constant	k7	56
.constant	k8	231
.constant	k9	14
.constant	k10	156
.constant	k11	226
.constant	k12	110
.constant	k13	92
.constant	k14	6
.constant	k15	254
.constant	k16	223
.constant	k17	136
.constant	k18	74
.constant	k19	245
.constant	k20	53
.constant	k21	248
.constant	k22	3
.constant	k23	151
.constant	k24	46
.constant	k25	182
.constant	k26	249
.constant	k27	208
.constant	k28	99
.constant	k29	116
.constant	k30	44
.constant	k31	201
.constant	k32	179
.constant	k33	101
.constant	k34	177
.constant	k35	37
.constant	k36	209
.constant	k37	89
.constant	k38	"ipairs"
.constant	k39	"SetWidgetVisible"
.constant	k40	"UIRoot"

.line	786	gettable      r1    r0    k0 ; k0 = "isFitVersion"
.line	786	test          r1     1
.line	786	jmp            0    l5
.line	786	return        r0     1
.label	l5
.line	786	gettabup      r1    u0    k1 ; k1 = "log_format"
.line	786	getupval      r2    u1
.line	786	loadk         r3    k2 ; k2 = 126
.line	786	loadk         r4    k3 ; k3 = 69
.line	786	loadk         r5    k4 ; k4 = 200
.line	786	loadk         r6    k5 ; k5 = 62
.line	786	loadk         r7    k6 ; k6 = 20
.line	786	loadk         r8    k7 ; k7 = 56
.line	786	loadk         r9    k8 ; k8 = 231
.line	786	loadk        r10    k9 ; k9 = 14
.line	786	loadk        r11   k10 ; k10 = 156
.line	786	loadk        r12   k11 ; k11 = 226
.line	786	loadk        r13    k4 ; k4 = 200
.line	786	loadk        r14   k12 ; k12 = 110
.line	786	loadk        r15   k13 ; k13 = 92
.line	786	loadk        r16   k14 ; k14 = 6
.line	786	loadk        r17   k15 ; k15 = 254
.line	786	loadk        r18   k16 ; k16 = 223
.line	786	loadk        r19   k17 ; k17 = 136
.line	786	loadk        r20   k18 ; k18 = 74
.line	786	loadk        r21   k19 ; k19 = 245
.line	786	loadk        r22   k20 ; k20 = 53
.line	786	loadk        r23   k21 ; k21 = 248
.line	786	loadk        r24   k22 ; k22 = 3
.line	786	loadk        r25   k23 ; k23 = 151
.line	786	loadk        r26   k24 ; k24 = 46
.line	786	loadk        r27   k25 ; k25 = 182
.line	786	loadk        r28   k26 ; k26 = 249
.line	786	loadk        r29   k27 ; k27 = 208
.line	786	loadk        r30   k28 ; k28 = 99
.line	786	loadk        r31   k29 ; k29 = 116
.line	786	loadk        r32   k30 ; k30 = 44
.line	786	loadk        r33   k31 ; k31 = 201
.line	786	loadk        r34   k19 ; k19 = 245
.line	786	loadk        r35   k32 ; k32 = 179
.line	786	loadk        r36   k33 ; k33 = 101
.line	786	loadk        r37   k34 ; k34 = 177
.line	786	loadk        r38   k35 ; k35 = 37
.line	786	loadk        r39   k36 ; k36 = 209
.line	786	loadk        r40   k37 ; k37 = 89
.line	786	call          r2    39     2
.line	786	call          r1     2     1
.line	786	gettabup      r1    u0   k38 ; k38 = "ipairs"
.line	786	getupval      r2    u2
.line	786	call          r1     2     4
.line	786	jmp            0   l57
.line	786	self          r6    r0   k39 ; k39 = "SetWidgetVisible"
.line	786	gettable      r8    r0   k40 ; k40 = "UIRoot"
.line	786	gettable      r8    r8    r5
.line	786	loadbool      r9     0     0
.line	786	loadbool     r10     1     0
.line	786	call          r6     5     1
.label	l57
.line	786	move          r0    r0
.line	786	move          r0    r0
.line	786	return        r0     1
.line	786	move          r0    r0
.line	786	return        r0     1

.function	main/f42

.source	null
.linedefined	796
.lastlinedefined	799
.numparams	1
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	0	false

.constant	k0	"LocUtil"
.constant	k1	"GetLocalizeResStr"
.constant	k2	8800609
.constant	k3	"UIRoot"
.constant	k4	"TextBlock_9"
.constant	k5	"SetText"

.line	796	gettabup      r1    u0    k0 ; k0 = "LocUtil"
.line	796	gettable      r1    r1    k1 ; k1 = "GetLocalizeResStr"
.line	796	loadk         r2    k2 ; k2 = 8800609
.line	796	call          r1     2     2
.line	796	gettable      r2    r0    k3 ; k3 = "UIRoot"
.line	796	gettable      r2    r2    k4 ; k4 = "TextBlock_9"
.line	796	self          r2    r2    k5 ; k5 = "SetText"
.line	796	move          r4    r1
.line	796	call          r2     3     1
.line	796	return        r0     1
.line	796	move          r0    r0
.line	796	return        r0     1

.function	main/f43

.source	null
.linedefined	801
.lastlinedefined	806
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	9	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	126
.constant	k5	69
.constant	k6	200
.constant	k7	62
.constant	k8	20
.constant	k9	56
.constant	k10	231
.constant	k11	14
.constant	k12	156
.constant	k13	226
.constant	k14	110
.constant	k15	92
.constant	k16	6
.constant	k17	254
.constant	k18	223
.constant	k19	136
.constant	k20	74
.constant	k21	245
.constant	k22	53
.constant	k23	248
.constant	k24	3
.constant	k25	151
.constant	k26	46
.constant	k27	182
.constant	k28	204
.constant	k29	99
.constant	k30	77
.constant	k31	13
.constant	k32	212
.constant	k33	241
.constant	k34	180
.constant	k35	102
.constant	k36	176
.constant	k37	17
.constant	k38	252
.constant	k39	89
.constant	k40	198
.constant	k41	26
.constant	k42	79
.constant	k43	76
.constant	k44	217
.constant	k45	10
.constant	k46	4
.constant	k47	183
.constant	k48	193
.constant	k49	41
.constant	k50	98
.constant	k51	43
.constant	k52	206
.constant	k53	240
.constant	k54	137
.constant	k55	124
.constant	k56	168
.constant	k57	19
.constant	k58	166
.constant	k59	38
.constant	k60	131
.constant	k61	188
.constant	k62	251
.constant	k63	214
.constant	k64	96
.constant	k65	37
.constant	k66	190
.constant	k67	152
.constant	k68	35
.constant	k69	239
.constant	k70	30
.constant	k71	146
.constant	k72	82
.constant	k73	130
.constant	k74	112
.constant	k75	"tostring"
.constant	k76	"AutoDownloadCfg"
.constant	k77	"AutoDownload4GSwitch"
.constant	k78	93
.constant	k79	150
.constant	k80	54
.constant	k81	209
.constant	k82	36
.constant	k83	145
.constant	k84	78
.constant	k85	73
.constant	k86	215
.constant	k87	119
.constant	k88	"AutoDownloadWIFISwitch"
.constant	k89	"UIRoot"
.constant	k90	"CheckBox_2"
.constant	k91	"SetIsChecked"

.line	801	gettabup      r1    u0    k0 ; k0 = "log"
.line	801	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	801	test          r2     0
.line	801	jmp            0  l105
.line	801	gettabup      r2    u0    k2 ; k2 = "table"
.line	801	gettable      r2    r2    k3 ; k3 = "concat"
.line	801	newtable      r3     2     0
.line	801	getupval      r4    u1
.line	801	loadk         r5    k4 ; k4 = 126
.line	801	loadk         r6    k5 ; k5 = 69
.line	801	loadk         r7    k6 ; k6 = 200
.line	801	loadk         r8    k7 ; k7 = 62
.line	801	loadk         r9    k8 ; k8 = 20
.line	801	loadk        r10    k9 ; k9 = 56
.line	801	loadk        r11   k10 ; k10 = 231
.line	801	loadk        r12   k11 ; k11 = 14
.line	801	loadk        r13   k12 ; k12 = 156
.line	801	loadk        r14   k13 ; k13 = 226
.line	801	loadk        r15    k6 ; k6 = 200
.line	801	loadk        r16   k14 ; k14 = 110
.line	801	loadk        r17   k15 ; k15 = 92
.line	801	loadk        r18   k16 ; k16 = 6
.line	801	loadk        r19   k17 ; k17 = 254
.line	801	loadk        r20   k18 ; k18 = 223
.line	801	loadk        r21   k19 ; k19 = 136
.line	801	loadk        r22   k20 ; k20 = 74
.line	801	loadk        r23   k21 ; k21 = 245
.line	801	loadk        r24   k22 ; k22 = 53
.line	801	loadk        r25   k23 ; k23 = 248
.line	801	loadk        r26   k24 ; k24 = 3
.line	801	loadk        r27   k25 ; k25 = 151
.line	801	loadk        r28   k26 ; k26 = 46
.line	801	loadk        r29   k27 ; k27 = 182
.line	801	loadk        r30   k17 ; k17 = 254
.line	801	loadk        r31   k28 ; k28 = 204
.line	801	loadk        r32   k29 ; k29 = 99
.line	801	loadk        r33   k30 ; k30 = 77
.line	801	loadk        r34   k31 ; k31 = 13
.line	801	loadk        r35   k32 ; k32 = 212
.line	801	loadk        r36   k33 ; k33 = 241
.line	801	loadk        r37   k34 ; k34 = 180
.line	801	loadk        r38   k35 ; k35 = 102
.line	801	loadk        r39   k36 ; k36 = 176
.line	801	loadk        r40   k37 ; k37 = 17
.line	801	loadk        r41   k38 ; k38 = 252
.line	801	loadk        r42   k39 ; k39 = 89
.line	801	loadk        r43   k40 ; k40 = 198
.line	801	loadk        r44   k41 ; k41 = 26
.line	801	call          r4    41     2
.line	801	getupval      r5    u1
.line	801	loadk         r6   k42 ; k42 = 79
.line	801	loadk         r7   k43 ; k43 = 76
.line	801	loadk         r8   k44 ; k44 = 217
.line	801	loadk         r9   k22 ; k22 = 53
.line	801	loadk        r10   k45 ; k45 = 10
.line	801	loadk        r11   k46 ; k46 = 4
.line	801	loadk        r12   k33 ; k33 = 241
.line	801	loadk        r13   k24 ; k24 = 3
.line	801	loadk        r14   k47 ; k47 = 183
.line	801	loadk        r15   k28 ; k28 = 204
.line	801	loadk        r16   k48 ; k48 = 193
.line	801	loadk        r17   k49 ; k49 = 41
.line	801	loadk        r18   k50 ; k50 = 98
.line	801	loadk        r19   k51 ; k51 = 43
.line	801	loadk        r20   k52 ; k52 = 206
.line	801	loadk        r21   k53 ; k53 = 240
.line	801	loadk        r22   k54 ; k54 = 137
.line	801	loadk        r23   k55 ; k55 = 124
.line	801	loadk        r24   k56 ; k56 = 168
.line	801	loadk        r25   k57 ; k57 = 19
.line	801	loadk        r26   k58 ; k58 = 166
.line	801	loadk        r27   k59 ; k59 = 38
.line	801	loadk        r28   k60 ; k60 = 131
.line	801	loadk        r29   k26 ; k26 = 46
.line	801	loadk        r30   k61 ; k61 = 188
.line	801	loadk        r31   k62 ; k62 = 251
.line	801	loadk        r32   k63 ; k63 = 214
.line	801	loadk        r33   k64 ; k64 = 96
.line	801	loadk        r34   k43 ; k43 = 76
.line	801	loadk        r35   k65 ; k65 = 37
.line	801	loadk        r36   k32 ; k32 = 212
.line	801	loadk        r37   k10 ; k10 = 231
.line	801	loadk        r38   k66 ; k66 = 190
.line	801	loadk        r39    k7 ; k7 = 62
.line	801	loadk        r40   k67 ; k67 = 152
.line	801	loadk        r41   k68 ; k68 = 35
.line	801	loadk        r42   k69 ; k69 = 239
.line	801	loadk        r43   k70 ; k70 = 30
.line	801	loadk        r44   k71 ; k71 = 146
.line	801	loadk        r45   k49 ; k49 = 41
.line	801	call          r5    41     2
.line	801	getupval      r6    u1
.line	801	loadk         r7   k72 ; k72 = 82
.line	801	loadk         r8   k45 ; k45 = 10
.line	801	loadk         r9   k73 ; k73 = 130
.line	801	loadk        r10   k74 ; k74 = 112
.line	801	call          r6     5     0
.line	801	setlist       r3     0     1
.line	801	call          r2     2     2
.line	801	gettabup      r3    u0   k75 ; k75 = "tostring"
.line	801	gettabup      r4    u2   k76 ; k76 = "AutoDownloadCfg"
.line	801	gettable      r4    r4   k77 ; k77 = "AutoDownload4GSwitch"
.line	801	call          r3     2     2
.line	801	concat        r2    r2    r3
.label	l105
.line	801	call          r1     2     1
.line	801	gettabup      r1    u0    k0 ; k0 = "log"
.line	801	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	801	test          r2     0
.line	801	jmp            0  l212
.line	801	gettabup      r2    u0    k2 ; k2 = "table"
.line	801	gettable      r2    r2    k3 ; k3 = "concat"
.line	801	newtable      r3     2     0
.line	801	getupval      r4    u1
.line	801	loadk         r5    k4 ; k4 = 126
.line	801	loadk         r6    k5 ; k5 = 69
.line	801	loadk         r7    k6 ; k6 = 200
.line	801	loadk         r8    k7 ; k7 = 62
.line	801	loadk         r9    k8 ; k8 = 20
.line	801	loadk        r10    k9 ; k9 = 56
.line	801	loadk        r11   k10 ; k10 = 231
.line	801	loadk        r12   k11 ; k11 = 14
.line	801	loadk        r13   k12 ; k12 = 156
.line	801	loadk        r14   k13 ; k13 = 226
.line	801	loadk        r15    k6 ; k6 = 200
.line	801	loadk        r16   k14 ; k14 = 110
.line	801	loadk        r17   k15 ; k15 = 92
.line	801	loadk        r18   k16 ; k16 = 6
.line	801	loadk        r19   k17 ; k17 = 254
.line	801	loadk        r20   k18 ; k18 = 223
.line	801	loadk        r21   k19 ; k19 = 136
.line	801	loadk        r22   k20 ; k20 = 74
.line	801	loadk        r23   k21 ; k21 = 245
.line	801	loadk        r24   k22 ; k22 = 53
.line	801	loadk        r25   k23 ; k23 = 248
.line	801	loadk        r26   k24 ; k24 = 3
.line	801	loadk        r27   k25 ; k25 = 151
.line	801	loadk        r28   k26 ; k26 = 46
.line	801	loadk        r29   k27 ; k27 = 182
.line	801	loadk        r30   k17 ; k17 = 254
.line	801	loadk        r31   k28 ; k28 = 204
.line	801	loadk        r32   k29 ; k29 = 99
.line	801	loadk        r33   k30 ; k30 = 77
.line	801	loadk        r34   k31 ; k31 = 13
.line	801	loadk        r35   k32 ; k32 = 212
.line	801	loadk        r36   k33 ; k33 = 241
.line	801	loadk        r37   k34 ; k34 = 180
.line	801	loadk        r38   k35 ; k35 = 102
.line	801	loadk        r39   k36 ; k36 = 176
.line	801	loadk        r40   k37 ; k37 = 17
.line	801	loadk        r41   k38 ; k38 = 252
.line	801	loadk        r42   k39 ; k39 = 89
.line	801	loadk        r43   k40 ; k40 = 198
.line	801	loadk        r44   k41 ; k41 = 26
.line	801	call          r4    41     2
.line	801	getupval      r5    u1
.line	801	loadk         r6   k42 ; k42 = 79
.line	801	loadk         r7   k43 ; k43 = 76
.line	801	loadk         r8   k44 ; k44 = 217
.line	801	loadk         r9   k22 ; k22 = 53
.line	801	loadk        r10   k45 ; k45 = 10
.line	801	loadk        r11   k46 ; k46 = 4
.line	801	loadk        r12   k33 ; k33 = 241
.line	801	loadk        r13   k24 ; k24 = 3
.line	801	loadk        r14   k47 ; k47 = 183
.line	801	loadk        r15   k28 ; k28 = 204
.line	801	loadk        r16   k48 ; k48 = 193
.line	801	loadk        r17   k49 ; k49 = 41
.line	801	loadk        r18   k50 ; k50 = 98
.line	801	loadk        r19   k51 ; k51 = 43
.line	801	loadk        r20   k52 ; k52 = 206
.line	801	loadk        r21   k53 ; k53 = 240
.line	801	loadk        r22   k54 ; k54 = 137
.line	801	loadk        r23   k55 ; k55 = 124
.line	801	loadk        r24   k56 ; k56 = 168
.line	801	loadk        r25   k57 ; k57 = 19
.line	801	loadk        r26   k58 ; k58 = 166
.line	801	loadk        r27   k59 ; k59 = 38
.line	801	loadk        r28   k60 ; k60 = 131
.line	801	loadk        r29   k26 ; k26 = 46
.line	801	loadk        r30   k61 ; k61 = 188
.line	801	loadk        r31   k62 ; k62 = 251
.line	801	loadk        r32   k63 ; k63 = 214
.line	801	loadk        r33   k64 ; k64 = 96
.line	801	loadk        r34   k43 ; k43 = 76
.line	801	loadk        r35   k65 ; k65 = 37
.line	801	loadk        r36   k32 ; k32 = 212
.line	801	loadk        r37   k10 ; k10 = 231
.line	801	loadk        r38   k66 ; k66 = 190
.line	801	loadk        r39   k78 ; k78 = 93
.line	801	loadk        r40   k79 ; k79 = 150
.line	801	loadk        r41   k80 ; k80 = 54
.line	801	loadk        r42   k81 ; k81 = 209
.line	801	loadk        r43   k82 ; k82 = 36
.line	801	loadk        r44   k83 ; k83 = 145
.line	801	loadk        r45   k68 ; k68 = 35
.line	801	call          r5    41     2
.line	801	getupval      r6    u1
.line	801	loadk         r7   k84 ; k84 = 78
.line	801	loadk         r8   k85 ; k85 = 73
.line	801	loadk         r9   k86 ; k86 = 215
.line	801	loadk        r10   k74 ; k74 = 112
.line	801	loadk        r11    k5 ; k5 = 69
.line	801	loadk        r12   k87 ; k87 = 119
.line	801	call          r6     7     0
.line	801	setlist       r3     0     1
.line	801	call          r2     2     2
.line	801	gettabup      r3    u0   k75 ; k75 = "tostring"
.line	801	gettabup      r4    u2   k76 ; k76 = "AutoDownloadCfg"
.line	801	gettable      r4    r4   k88 ; k88 = "AutoDownloadWIFISwit" (truncated)
.line	801	call          r3     2     2
.line	801	concat        r2    r2    r3
.label	l212
.line	801	call          r1     2     1
.line	801	gettabup      r1    u2   k76 ; k76 = "AutoDownloadCfg"
.line	801	gettable      r1    r1   k77 ; k77 = "AutoDownload4GSwitch"
.line	801	test          r1     1
.line	801	jmp            0  l219
.line	801	gettabup      r1    u2   k76 ; k76 = "AutoDownloadCfg"
.line	801	gettable      r1    r1   k88 ; k88 = "AutoDownloadWIFISwit" (truncated)
.label	l219
.line	801	gettable      r2    r0   k89 ; k89 = "UIRoot"
.line	801	gettable      r2    r2   k90 ; k90 = "CheckBox_2"
.line	801	self          r2    r2   k91 ; k91 = "SetIsChecked"
.line	801	move          r4    r1
.line	801	call          r2     3     1
.line	801	return        r0     1
.line	801	move          r0    r0
.line	801	move          r0    r0
.line	801	return        r0     1

.function	main/f44

.source	null
.linedefined	808
.lastlinedefined	830
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	9	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	126
.constant	k3	69
.constant	k4	200
.constant	k5	62
.constant	k6	20
.constant	k7	56
.constant	k8	231
.constant	k9	14
.constant	k10	156
.constant	k11	226
.constant	k12	110
.constant	k13	92
.constant	k14	6
.constant	k15	254
.constant	k16	223
.constant	k17	136
.constant	k18	74
.constant	k19	245
.constant	k20	35
.constant	k21	224
.constant	k22	2
.constant	k23	149
.constant	k24	49
.constant	k25	128
.constant	k26	215
.constant	k27	214
.constant	k28	96
.constant	k29	101
.constant	k30	60
.constant	k31	210
.constant	k32	191
.constant	k33	94
.constant	k34	182
.constant	k35	0
.constant	k36	235
.constant	k37	89
.constant	k38	"IsViewMode"
.constant	k39	"table"
.constant	k40	"concat"
.constant	k41	198
.constant	k42	36
.constant	k43	85
.constant	k44	159
.constant	k45	38
.constant	k46	17
.constant	k47	50
.constant	k48	241
.constant	k49	174
.constant	k50	192
.constant	k51	205
.constant	k52	98
.constant	k53	"HDmpveRemote"
.constant	k54	"HDmpveRemoteConfigGetBool"
.constant	k55	125
.constant	k56	108
.constant	k57	208
.constant	k58	34
.constant	k59	27
.constant	k60	197
.constant	k61	172
.constant	k62	220
.constant	k63	204
.constant	k64	70
.constant	k65	71
.constant	k66	45
.constant	k67	196
.constant	k68	165
.constant	k69	109
.constant	k70	161
.constant	k71	12
.constant	k72	146
.constant	k73	44
.constant	k74	88
.constant	k75	53
.constant	k76	59
.constant	k77	233
.constant	k78	25
.constant	k79	166
.constant	k80	238
.constant	k81	115
.constant	k82	93
.constant	k83	29
.constant	k84	225
.constant	k85	164
.constant	k86	118
.constant	k87	160
.constant	k88	1
.constant	k89	236
.constant	k90	203
.constant	k91	122
.constant	k92	"tostring"
.constant	k93	"AutoDownloadCfg"
.constant	k94	"NeedShowDownloadSelectGuide"
.constant	k95	95
.constant	k96	79
.constant	k97	219
.constant	k98	3
.constant	k99	16
.constant	k100	143
.constant	k101	"UIManager"
.constant	k102	"ShowUI"
.constant	k103	"UI_Config"
.constant	k104	"Download_Guide_Popup_UIBP"

.line	808	gettabup      r1    u0    k0 ; k0 = "log"
.line	808	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	808	test          r2     0
.line	808	jmp            0   l45
.line	808	getupval      r2    u1
.line	808	loadk         r3    k2 ; k2 = 126
.line	808	loadk         r4    k3 ; k3 = 69
.line	808	loadk         r5    k4 ; k4 = 200
.line	808	loadk         r6    k5 ; k5 = 62
.line	808	loadk         r7    k6 ; k6 = 20
.line	808	loadk         r8    k7 ; k7 = 56
.line	808	loadk         r9    k8 ; k8 = 231
.line	808	loadk        r10    k9 ; k9 = 14
.line	808	loadk        r11   k10 ; k10 = 156
.line	808	loadk        r12   k11 ; k11 = 226
.line	808	loadk        r13    k4 ; k4 = 200
.line	808	loadk        r14   k12 ; k12 = 110
.line	808	loadk        r15   k13 ; k13 = 92
.line	808	loadk        r16   k14 ; k14 = 6
.line	808	loadk        r17   k15 ; k15 = 254
.line	808	loadk        r18   k16 ; k16 = 223
.line	808	loadk        r19   k17 ; k17 = 136
.line	808	loadk        r20   k18 ; k18 = 74
.line	808	loadk        r21   k19 ; k19 = 245
.line	808	loadk        r22   k20 ; k20 = 35
.line	808	loadk        r23   k21 ; k21 = 224
.line	808	loadk        r24   k22 ; k22 = 2
.line	808	loadk        r25   k23 ; k23 = 149
.line	808	loadk        r26   k24 ; k24 = 49
.line	808	loadk        r27   k25 ; k25 = 128
.line	808	loadk        r28   k26 ; k26 = 215
.line	808	loadk        r29   k27 ; k27 = 214
.line	808	loadk        r30   k28 ; k28 = 96
.line	808	loadk        r31   k29 ; k29 = 101
.line	808	loadk        r32   k30 ; k30 = 60
.line	808	loadk        r33   k31 ; k31 = 210
.line	808	loadk        r34   k11 ; k11 = 226
.line	808	loadk        r35   k32 ; k32 = 191
.line	808	loadk        r36   k33 ; k33 = 94
.line	808	loadk        r37   k34 ; k34 = 182
.line	808	loadk        r38   k35 ; k35 = 0
.line	808	loadk        r39   k36 ; k36 = 235
.line	808	loadk        r40   k37 ; k37 = 89
.line	808	call          r2    39     2
.label	l45
.line	808	call          r1     2     1
.line	808	self          r1    r0   k38 ; k38 = "IsViewMode"
.line	808	call          r1     2     2
.line	808	test          r1     1
.line	808	jmp            0  l117
.line	808	gettabup      r1    u0    k0 ; k0 = "log"
.line	808	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	808	test          r2     0
.line	808	jmp            0  l115
.line	808	gettabup      r2    u0   k39 ; k39 = "table"
.line	808	gettable      r2    r2   k40 ; k40 = "concat"
.line	808	newtable      r3     1     0
.line	808	getupval      r4    u1
.line	808	loadk         r5    k2 ; k2 = 126
.line	808	loadk         r6    k3 ; k3 = 69
.line	808	loadk         r7    k4 ; k4 = 200
.line	808	loadk         r8    k5 ; k5 = 62
.line	808	loadk         r9    k6 ; k6 = 20
.line	808	loadk        r10    k7 ; k7 = 56
.line	808	loadk        r11    k8 ; k8 = 231
.line	808	loadk        r12    k9 ; k9 = 14
.line	808	loadk        r13   k10 ; k10 = 156
.line	808	loadk        r14   k11 ; k11 = 226
.line	808	loadk        r15    k4 ; k4 = 200
.line	808	loadk        r16   k12 ; k12 = 110
.line	808	loadk        r17   k13 ; k13 = 92
.line	808	loadk        r18   k14 ; k14 = 6
.line	808	loadk        r19   k15 ; k15 = 254
.line	808	loadk        r20   k16 ; k16 = 223
.line	808	loadk        r21   k17 ; k17 = 136
.line	808	loadk        r22   k18 ; k18 = 74
.line	808	loadk        r23   k19 ; k19 = 245
.line	808	loadk        r24   k20 ; k20 = 35
.line	808	loadk        r25   k21 ; k21 = 224
.line	808	loadk        r26   k22 ; k22 = 2
.line	808	loadk        r27   k23 ; k23 = 149
.line	808	loadk        r28   k24 ; k24 = 49
.line	808	loadk        r29   k25 ; k25 = 128
.line	808	loadk        r30   k26 ; k26 = 215
.line	808	loadk        r31   k27 ; k27 = 214
.line	808	loadk        r32   k28 ; k28 = 96
.line	808	loadk        r33   k29 ; k29 = 101
.line	808	loadk        r34   k30 ; k30 = 60
.line	808	loadk        r35   k31 ; k31 = 210
.line	808	loadk        r36   k11 ; k11 = 226
.line	808	loadk        r37   k32 ; k32 = 191
.line	808	loadk        r38   k33 ; k33 = 94
.line	808	loadk        r39   k34 ; k34 = 182
.line	808	loadk        r40   k35 ; k35 = 0
.line	808	loadk        r41   k36 ; k36 = 235
.line	808	loadk        r42   k37 ; k37 = 89
.line	808	loadk        r43   k41 ; k41 = 198
.line	808	loadk        r44   k42 ; k42 = 36
.line	808	call          r4    41     2
.line	808	getupval      r5    u1
.line	808	loadk         r6   k43 ; k43 = 85
.line	808	loadk         r7   k33 ; k33 = 94
.line	808	loadk         r8   k44 ; k44 = 159
.line	808	loadk         r9   k45 ; k45 = 38
.line	808	loadk        r10   k46 ; k46 = 17
.line	808	loadk        r11   k47 ; k47 = 50
.line	808	loadk        r12   k48 ; k48 = 241
.line	808	loadk        r13   k18 ; k18 = 74
.line	808	loadk        r14   k49 ; k49 = 174
.line	808	loadk        r15   k50 ; k50 = 192
.line	808	loadk        r16   k51 ; k51 = 205
.line	808	loadk        r17   k52 ; k52 = 98
.line	808	call          r5    13     0
.line	808	setlist       r3     0     1
.line	808	call          r2     2     2
.label	l115
.line	808	call          r1     2     1
.line	808	return        r0     1
.label	l117
.line	808	gettabup      r1    u0   k53 ; k53 = "HDmpveRemote"
.line	808	gettable      r1    r1   k54 ; k54 = "HDmpveRemoteConfigGe" (truncated)
.line	808	getupval      r2    u1
.line	808	loadk         r3   k55 ; k55 = 125
.line	808	loadk         r4   k56 ; k56 = 108
.line	808	loadk         r5   k57 ; k57 = 208
.line	808	loadk         r6   k58 ; k58 = 34
.line	808	loadk         r7   k59 ; k59 = 27
.line	808	loadk         r8   k47 ; k47 = 50
.line	808	loadk         r9   k60 ; k60 = 197
.line	808	loadk        r10   k14 ; k14 = 6
.line	808	loadk        r11   k61 ; k61 = 172
.line	808	loadk        r12   k62 ; k62 = 220
.line	808	loadk        r13   k63 ; k63 = 204
.line	808	loadk        r14   k64 ; k64 = 70
.line	808	loadk        r15   k65 ; k65 = 71
.line	808	loadk        r16   k66 ; k66 = 45
.line	808	loadk        r17   k67 ; k67 = 196
.line	808	loadk        r18   k31 ; k31 = 210
.line	808	loadk        r19   k68 ; k68 = 165
.line	808	loadk        r20   k69 ; k69 = 109
.line	808	loadk        r21   k70 ; k70 = 161
.line	808	loadk        r22   k71 ; k71 = 12
.line	808	loadk        r23    k8 ; k8 = 231
.line	808	loadk        r24   k14 ; k14 = 6
.line	808	loadk        r25   k72 ; k72 = 146
.line	808	call          r2    24     2
.line	808	loadbool      r3     0     0
.line	808	call          r1     3     2
.line	808	gettabup      r2    u0    k0 ; k0 = "log"
.line	808	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	808	test          r3     0
.line	808	jmp            0  l227
.line	808	gettabup      r3    u0   k39 ; k39 = "table"
.line	808	gettable      r3    r3   k40 ; k40 = "concat"
.line	808	newtable      r4     1     0
.line	808	getupval      r5    u1
.line	808	loadk         r6    k2 ; k2 = 126
.line	808	loadk         r7    k3 ; k3 = 69
.line	808	loadk         r8    k4 ; k4 = 200
.line	808	loadk         r9    k5 ; k5 = 62
.line	808	loadk        r10    k6 ; k6 = 20
.line	808	loadk        r11    k7 ; k7 = 56
.line	808	loadk        r12    k8 ; k8 = 231
.line	808	loadk        r13    k9 ; k9 = 14
.line	808	loadk        r14   k10 ; k10 = 156
.line	808	loadk        r15   k11 ; k11 = 226
.line	808	loadk        r16    k4 ; k4 = 200
.line	808	loadk        r17   k12 ; k12 = 110
.line	808	loadk        r18   k13 ; k13 = 92
.line	808	loadk        r19   k14 ; k14 = 6
.line	808	loadk        r20   k15 ; k15 = 254
.line	808	loadk        r21   k16 ; k16 = 223
.line	808	loadk        r22   k17 ; k17 = 136
.line	808	loadk        r23   k18 ; k18 = 74
.line	808	loadk        r24   k19 ; k19 = 245
.line	808	loadk        r25   k20 ; k20 = 35
.line	808	loadk        r26   k21 ; k21 = 224
.line	808	loadk        r27   k22 ; k22 = 2
.line	808	loadk        r28   k23 ; k23 = 149
.line	808	loadk        r29   k24 ; k24 = 49
.line	808	loadk        r30   k25 ; k25 = 128
.line	808	loadk        r31   k26 ; k26 = 215
.line	808	loadk        r32   k27 ; k27 = 214
.line	808	loadk        r33   k28 ; k28 = 96
.line	808	loadk        r34   k29 ; k29 = 101
.line	808	loadk        r35   k30 ; k30 = 60
.line	808	loadk        r36   k31 ; k31 = 210
.line	808	loadk        r37   k11 ; k11 = 226
.line	808	loadk        r38   k32 ; k32 = 191
.line	808	loadk        r39   k33 ; k33 = 94
.line	808	loadk        r40   k34 ; k34 = 182
.line	808	loadk        r41   k35 ; k35 = 0
.line	808	loadk        r42   k36 ; k36 = 235
.line	808	loadk        r43   k37 ; k37 = 89
.line	808	loadk        r44   k41 ; k41 = 198
.line	808	loadk        r45   k73 ; k73 = 44
.line	808	call          r5    41     2
.line	808	getupval      r6    u1
.line	808	loadk         r7   k43 ; k43 = 85
.line	808	loadk         r8   k74 ; k74 = 88
.line	808	loadk         r9   k62 ; k62 = 220
.line	808	loadk        r10   k75 ; k75 = 53
.line	808	loadk        r11   k76 ; k76 = 59
.line	808	loadk        r12   k76 ; k76 = 59
.line	808	loadk        r13   k77 ; k77 = 233
.line	808	loadk        r14   k78 ; k78 = 25
.line	808	loadk        r15   k79 ; k79 = 166
.line	808	loadk        r16   k80 ; k80 = 238
.line	808	loadk        r17   k62 ; k62 = 220
.line	808	loadk        r18   k81 ; k81 = 115
.line	808	loadk        r19   k82 ; k82 = 93
.line	808	loadk        r20   k83 ; k83 = 29
.line	808	loadk        r21   k67 ; k67 = 196
.line	808	loadk        r22   k84 ; k84 = 225
.line	808	loadk        r23   k85 ; k85 = 164
.line	808	loadk        r24   k86 ; k86 = 118
.line	808	loadk        r25   k87 ; k87 = 160
.line	808	loadk        r26   k88 ; k88 = 1
.line	808	loadk        r27   k89 ; k89 = 236
.line	808	loadk        r28   k65 ; k65 = 71
.line	808	loadk        r29   k90 ; k90 = 203
.line	808	loadk        r30   k91 ; k91 = 122
.line	808	call          r6    25     0
.line	808	setlist       r4     0     1
.line	808	call          r3     2     2
.line	808	gettabup      r4    u0   k92 ; k92 = "tostring"
.line	808	move          r5    r1
.line	808	call          r4     2     2
.line	808	concat        r3    r3    r4
.label	l227
.line	808	call          r2     2     1
.line	808	test          r1     1
.line	808	jmp            0  l231
.line	808	return        r0     1
.label	l231
.line	808	gettabup      r2    u2   k93 ; k93 = "AutoDownloadCfg"
.line	808	gettable      r2    r2   k94 ; k94 = "NeedShowDownloadSele" (truncated)
.line	808	gettabup      r3    u0    k0 ; k0 = "log"
.line	808	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	808	test          r4     0
.line	808	jmp            0  l300
.line	808	gettabup      r4    u0   k39 ; k39 = "table"
.line	808	gettable      r4    r4   k40 ; k40 = "concat"
.line	808	newtable      r5     1     0
.line	808	getupval      r6    u1
.line	808	loadk         r7    k2 ; k2 = 126
.line	808	loadk         r8    k3 ; k3 = 69
.line	808	loadk         r9    k4 ; k4 = 200
.line	808	loadk        r10    k5 ; k5 = 62
.line	808	loadk        r11    k6 ; k6 = 20
.line	808	loadk        r12    k7 ; k7 = 56
.line	808	loadk        r13    k8 ; k8 = 231
.line	808	loadk        r14    k9 ; k9 = 14
.line	808	loadk        r15   k10 ; k10 = 156
.line	808	loadk        r16   k11 ; k11 = 226
.line	808	loadk        r17    k4 ; k4 = 200
.line	808	loadk        r18   k12 ; k12 = 110
.line	808	loadk        r19   k13 ; k13 = 92
.line	808	loadk        r20   k14 ; k14 = 6
.line	808	loadk        r21   k15 ; k15 = 254
.line	808	loadk        r22   k16 ; k16 = 223
.line	808	loadk        r23   k17 ; k17 = 136
.line	808	loadk        r24   k18 ; k18 = 74
.line	808	loadk        r25   k19 ; k19 = 245
.line	808	loadk        r26   k20 ; k20 = 35
.line	808	loadk        r27   k21 ; k21 = 224
.line	808	loadk        r28   k22 ; k22 = 2
.line	808	loadk        r29   k23 ; k23 = 149
.line	808	loadk        r30   k24 ; k24 = 49
.line	808	loadk        r31   k25 ; k25 = 128
.line	808	loadk        r32   k26 ; k26 = 215
.line	808	loadk        r33   k27 ; k27 = 214
.line	808	loadk        r34   k28 ; k28 = 96
.line	808	loadk        r35   k29 ; k29 = 101
.line	808	loadk        r36   k30 ; k30 = 60
.line	808	loadk        r37   k31 ; k31 = 210
.line	808	loadk        r38   k11 ; k11 = 226
.line	808	loadk        r39   k32 ; k32 = 191
.line	808	loadk        r40   k33 ; k33 = 94
.line	808	loadk        r41   k34 ; k34 = 182
.line	808	loadk        r42   k35 ; k35 = 0
.line	808	loadk        r43   k36 ; k36 = 235
.line	808	loadk        r44   k37 ; k37 = 89
.line	808	loadk        r45   k41 ; k41 = 198
.line	808	loadk        r46   k42 ; k42 = 36
.line	808	call          r6    41     2
.line	808	getupval      r7    u1
.line	808	loadk         r8   k95 ; k95 = 95
.line	808	loadk         r9   k96 ; k96 = 79
.line	808	loadk        r10   k97 ; k97 = 219
.line	808	loadk        r11   k98 ; k98 = 3
.line	808	loadk        r12   k99 ; k99 = 16
.line	808	loadk        r13    k7 ; k7 = 56
.line	808	loadk        r14   k48 ; k48 = 241
.line	808	loadk        r15   k18 ; k18 = 74
.line	808	loadk        r16   k15 ; k15 = 254
.line	808	loadk        r17  k100 ; k100 = 143
.line	808	call          r7    11     0
.line	808	setlist       r5     0     1
.line	808	call          r4     2     2
.line	808	gettabup      r5    u0   k92 ; k92 = "tostring"
.line	808	move          r6    r2
.line	808	call          r5     2     2
.line	808	concat        r4    r4    r5
.label	l300
.line	808	call          r3     2     1
.line	808	test          r2     0
.line	808	jmp            0  l310
.line	808	gettabup      r3    u0  k101 ; k101 = "UIManager"
.line	808	gettable      r3    r3  k102 ; k102 = "ShowUI"
.line	808	gettabup      r4    u0  k101 ; k101 = "UIManager"
.line	808	gettable      r4    r4  k103 ; k103 = "UI_Config"
.line	808	gettable      r4    r4  k104 ; k104 = "Download_Guide_Popup" (truncated)
.line	808	closure       r5    f0
.line	808	call          r3     3     1
.label	l310
.line	808	return        r0     1
.line	808	move          r0    r0
.line	808	move          r0    r0
.line	808	gettabup      r3    u0   k90 ; k90 = 203
.line	808	move          r0    r0
.line	808	return        r0     1

.function	main/f44/f0

.source	null
.linedefined	822
.lastlinedefined	828
.numparams	0
.is_vararg	0
.maxstacksize	44

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	0	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	126
.constant	k5	69
.constant	k6	200
.constant	k7	62
.constant	k8	20
.constant	k9	56
.constant	k10	231
.constant	k11	14
.constant	k12	156
.constant	k13	226
.constant	k14	110
.constant	k15	92
.constant	k16	6
.constant	k17	254
.constant	k18	223
.constant	k19	136
.constant	k20	74
.constant	k21	245
.constant	k22	35
.constant	k23	224
.constant	k24	2
.constant	k25	149
.constant	k26	49
.constant	k27	128
.constant	k28	215
.constant	k29	214
.constant	k30	96
.constant	k31	101
.constant	k32	60
.constant	k33	210
.constant	k34	191
.constant	k35	94
.constant	k36	182
.constant	k37	0
.constant	k38	235
.constant	k39	89
.constant	k40	133
.constant	k41	43
.constant	k42	86
.constant	k43	70
.constant	k44	221
.constant	k45	27
.constant	k46	"slua"
.constant	k47	"isValid"
.constant	k48	"UIRoot"
.constant	k49	"UpdateAutoDownload"

.line	822	gettabup      r0    u0    k0 ; k0 = "log"
.line	822	gettabup      r1    u0    k1 ; k1 = "bWriteLog"
.line	822	test          r1     0
.line	822	jmp            0   l60
.line	822	gettabup      r1    u0    k2 ; k2 = "table"
.line	822	gettable      r1    r1    k3 ; k3 = "concat"
.line	822	newtable      r2     1     0
.line	822	getupval      r3    u1
.line	822	loadk         r4    k4 ; k4 = 126
.line	822	loadk         r5    k5 ; k5 = 69
.line	822	loadk         r6    k6 ; k6 = 200
.line	822	loadk         r7    k7 ; k7 = 62
.line	822	loadk         r8    k8 ; k8 = 20
.line	822	loadk         r9    k9 ; k9 = 56
.line	822	loadk        r10   k10 ; k10 = 231
.line	822	loadk        r11   k11 ; k11 = 14
.line	822	loadk        r12   k12 ; k12 = 156
.line	822	loadk        r13   k13 ; k13 = 226
.line	822	loadk        r14    k6 ; k6 = 200
.line	822	loadk        r15   k14 ; k14 = 110
.line	822	loadk        r16   k15 ; k15 = 92
.line	822	loadk        r17   k16 ; k16 = 6
.line	822	loadk        r18   k17 ; k17 = 254
.line	822	loadk        r19   k18 ; k18 = 223
.line	822	loadk        r20   k19 ; k19 = 136
.line	822	loadk        r21   k20 ; k20 = 74
.line	822	loadk        r22   k21 ; k21 = 245
.line	822	loadk        r23   k22 ; k22 = 35
.line	822	loadk        r24   k23 ; k23 = 224
.line	822	loadk        r25   k24 ; k24 = 2
.line	822	loadk        r26   k25 ; k25 = 149
.line	822	loadk        r27   k26 ; k26 = 49
.line	822	loadk        r28   k27 ; k27 = 128
.line	822	loadk        r29   k28 ; k28 = 215
.line	822	loadk        r30   k29 ; k29 = 214
.line	822	loadk        r31   k30 ; k30 = 96
.line	822	loadk        r32   k31 ; k31 = 101
.line	822	loadk        r33   k32 ; k32 = 60
.line	822	loadk        r34   k33 ; k33 = 210
.line	822	loadk        r35   k13 ; k13 = 226
.line	822	loadk        r36   k34 ; k34 = 191
.line	822	loadk        r37   k35 ; k35 = 94
.line	822	loadk        r38   k36 ; k36 = 182
.line	822	loadk        r39   k37 ; k37 = 0
.line	822	loadk        r40   k38 ; k38 = 235
.line	822	loadk        r41   k39 ; k39 = 89
.line	822	loadk        r42   k40 ; k40 = 133
.line	822	loadk        r43   k41 ; k41 = 43
.line	822	call          r3    41     2
.line	822	getupval      r4    u1
.line	822	loadk         r5   k42 ; k42 = 86
.line	822	loadk         r6   k43 ; k43 = 70
.line	822	loadk         r7   k44 ; k44 = 221
.line	822	loadk         r8   k26 ; k26 = 49
.line	822	loadk         r9   k45 ; k45 = 27
.line	822	loadk        r10   k32 ; k32 = 60
.line	822	call          r4     7     0
.line	822	setlist       r2     0     1
.line	822	call          r1     2     2
.label	l60
.line	822	call          r0     2     1
.line	822	gettabup      r0    u0   k46 ; k46 = "slua"
.line	822	gettable      r0    r0   k47 ; k47 = "isValid"
.line	822	gettabup      r1    u2   k48 ; k48 = "UIRoot"
.line	822	call          r0     2     2
.line	822	test          r0     1
.line	822	jmp            0   l68
.line	822	return        r0     1
.label	l68
.line	822	getupval      r0    u2
.line	822	self          r0    r0   k49 ; k49 = "UpdateAutoDownload"
.line	822	call          r0     2     1
.line	822	return        r0     1
.line	822	move          r0    r0
.line	822	move          r0    r0
.line	822	return        r0     1

.function	main/f45

.source	null
.linedefined	832
.lastlinedefined	849
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	9	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"downloadSelectMap"
.constant	k1	"GetSmartDownloadSelectMap"
.constant	k2	"pairs"
.constant	k3	"mergeBundleDataMap"
.constant	k4	true
.constant	k5	"log_tree"
.constant	k6	"table"
.constant	k7	"concat"
.constant	k8	126
.constant	k9	69
.constant	k10	200
.constant	k11	62
.constant	k12	20
.constant	k13	56
.constant	k14	231
.constant	k15	14
.constant	k16	156
.constant	k17	226
.constant	k18	110
.constant	k19	92
.constant	k20	6
.constant	k21	254
.constant	k22	223
.constant	k23	136
.constant	k24	74
.constant	k25	245
.constant	k26	53
.constant	k27	248
.constant	k28	3
.constant	k29	151
.constant	k30	46
.constant	k31	182
.constant	k32	251
.constant	k33	214
.constant	k34	96
.constant	k35	76
.constant	k36	37
.constant	k37	212
.constant	k38	190
.constant	k39	89
.constant	k40	186
.constant	k41	28
.constant	k42	253
.constant	k43	146
.constant	k44	47
.constant	k45	94
.constant	k46	103
.constant	k47	222
.constant	k48	32
.constant	k49	86
.constant	k50	119
.constant	k51	15
.constant	k52	175
.constant	k53	201
.constant	k54	135
.constant	k55	99
.constant	k56	93
.constant	k57	197
.constant	k58	250
.constant	k59	165
.constant	k60	123
.constant	k61	171
.constant	k62	51
.constant	k63	237
.constant	k64	11
.constant	k65	147
.constant	k66	57
.constant	k67	167
.constant	k68	242
.constant	k69	216
.constant	k70	2
.constant	k71	116

.line	832	gettable      r1    r0    k0 ; k0 = "downloadSelectMap"
.line	832	test          r1     0
.line	832	jmp            0    l5
.line	832	return        r0     1
.label	l5
.line	832	newtable      r1     0     0
.line	832	settable      r0    k0    r1 ; k0 = "downloadSelectMap"
.line	832	gettabup      r1    u0    k1 ; k1 = "GetSmartDownloadSele" (truncated)
.line	832	call          r1     1     2
.line	832	gettabup      r2    u1    k2 ; k2 = "pairs"
.line	832	move          r3    r1
.line	832	call          r2     2     4
.line	832	jmp            0   l28
.line	832	gettable      r7    r0    k3 ; k3 = "mergeBundleDataMap"
.line	832	gettable      r7    r7    r5
.line	832	test          r7     0
.line	832	jmp            0   l26
.line	832	gettabup      r8    u1    k2 ; k2 = "pairs"
.line	832	move          r9    r7
.line	832	call          r8     2     4
.line	832	jmp            0   l23
.line	832	gettable     r13    r0    k0 ; k0 = "downloadSelectMap"
.line	832	settable     r13   r12    k4 ; k4 = true
.label	l23
.line	832	move          r0    r0
.line	832	move          r0    r0
.line	832	jmp            0   l28
.label	l26
.line	832	gettable      r8    r0    k0 ; k0 = "downloadSelectMap"
.line	832	settable      r8    r5    k4 ; k4 = true
.label	l28
.line	832	move          r0    r0
.line	832	move          r0    r0
.line	832	gettabup      r2    u1    k5 ; k5 = "log_tree"
.line	832	gettabup      r3    u1    k6 ; k6 = "table"
.line	832	gettable      r3    r3    k7 ; k7 = "concat"
.line	832	newtable      r4     1     0
.line	832	getupval      r5    u2
.line	832	loadk         r6    k8 ; k8 = 126
.line	832	loadk         r7    k9 ; k9 = 69
.line	832	loadk         r8   k10 ; k10 = 200
.line	832	loadk         r9   k11 ; k11 = 62
.line	832	loadk        r10   k12 ; k12 = 20
.line	832	loadk        r11   k13 ; k13 = 56
.line	832	loadk        r12   k14 ; k14 = 231
.line	832	loadk        r13   k15 ; k15 = 14
.line	832	loadk        r14   k16 ; k16 = 156
.line	832	loadk        r15   k17 ; k17 = 226
.line	832	loadk        r16   k10 ; k10 = 200
.line	832	loadk        r17   k18 ; k18 = 110
.line	832	loadk        r18   k19 ; k19 = 92
.line	832	loadk        r19   k20 ; k20 = 6
.line	832	loadk        r20   k21 ; k21 = 254
.line	832	loadk        r21   k22 ; k22 = 223
.line	832	loadk        r22   k23 ; k23 = 136
.line	832	loadk        r23   k24 ; k24 = 74
.line	832	loadk        r24   k25 ; k25 = 245
.line	832	loadk        r25   k26 ; k26 = 53
.line	832	loadk        r26   k27 ; k27 = 248
.line	832	loadk        r27   k28 ; k28 = 3
.line	832	loadk        r28   k29 ; k29 = 151
.line	832	loadk        r29   k30 ; k30 = 46
.line	832	loadk        r30   k31 ; k31 = 182
.line	832	loadk        r31   k32 ; k32 = 251
.line	832	loadk        r32   k33 ; k33 = 214
.line	832	loadk        r33   k34 ; k34 = 96
.line	832	loadk        r34   k35 ; k35 = 76
.line	832	loadk        r35   k36 ; k36 = 37
.line	832	loadk        r36   k37 ; k37 = 212
.line	832	loadk        r37   k14 ; k14 = 231
.line	832	loadk        r38   k38 ; k38 = 190
.line	832	loadk        r39   k39 ; k39 = 89
.line	832	loadk        r40   k40 ; k40 = 186
.line	832	loadk        r41   k41 ; k41 = 28
.line	832	loadk        r42   k42 ; k42 = 253
.line	832	loadk        r43   k12 ; k12 = 20
.line	832	loadk        r44   k43 ; k43 = 146
.line	832	loadk        r45   k44 ; k44 = 47
.line	832	call          r5    41     2
.line	832	getupval      r6    u2
.line	832	loadk         r7   k45 ; k45 = 94
.line	832	loadk         r8   k46 ; k46 = 103
.line	832	loadk         r9   k47 ; k47 = 222
.line	832	loadk        r10   k48 ; k48 = 32
.line	832	loadk        r11   k49 ; k49 = 86
.line	832	loadk        r12   k50 ; k50 = 119
.line	832	loadk        r13   k25 ; k25 = 245
.line	832	loadk        r14   k51 ; k51 = 15
.line	832	loadk        r15   k52 ; k52 = 175
.line	832	loadk        r16   k53 ; k53 = 201
.line	832	loadk        r17   k54 ; k54 = 135
.line	832	loadk        r18   k55 ; k55 = 99
.line	832	loadk        r19   k56 ; k56 = 93
.line	832	loadk        r20   k30 ; k30 = 46
.line	832	loadk        r21   k57 ; k57 = 197
.line	832	loadk        r22   k58 ; k58 = 250
.line	832	loadk        r23   k59 ; k59 = 165
.line	832	loadk        r24   k60 ; k60 = 123
.line	832	loadk        r25   k61 ; k61 = 171
.line	832	loadk        r26   k62 ; k62 = 51
.line	832	loadk        r27   k63 ; k63 = 237
.line	832	loadk        r28   k64 ; k64 = 11
.line	832	loadk        r29   k65 ; k65 = 147
.line	832	loadk        r30   k66 ; k66 = 57
.line	832	loadk        r31   k67 ; k67 = 167
.line	832	loadk        r32   k68 ; k68 = 242
.line	832	loadk        r33   k69 ; k69 = 216
.line	832	loadk        r34   k46 ; k46 = 103
.line	832	loadk        r35   k70 ; k70 = 2
.line	832	loadk        r36   k71 ; k71 = 116
.line	832	call          r6    31     0
.line	832	setlist       r4     0     1
.line	832	call          r3     2     2
.line	832	gettable      r4    r0    k0 ; k0 = "downloadSelectMap"
.line	832	call          r2     3     1
.line	832	return        r0     1
.line	832	move          r0    r0
.line	832	move          r0    r0
.line	832	move          r0    r0
.line	832	return        r0     1

.function	main/f46

.source	null
.linedefined	851
.lastlinedefined	947
.numparams	1
.is_vararg	0
.maxstacksize	59

.upvalue	"_ENV"	5	true
.upvalue	"U1"	0	false
.upvalue	"U2"	17	true
.upvalue	"U3"	6	true
.upvalue	"U4"	19	true
.upvalue	"U5"	13	true
.upvalue	"U6"	9	true
.upvalue	"U7"	1	true

.constant	k0	"IsViewMode"
.constant	k1	"showDownloadAll"
.constant	k2	"SetWidgetVisible"
.constant	k3	"UIRoot"
.constant	k4	"Button_8"
.constant	k5	"UpdateDownloadSelectedMap"
.constant	k6	"ENUM_DownloadState"
.constant	k7	"Done"
.constant	k8	0
.constant	k9	"pairs"
.constant	k10	"allItemData"
.constant	k11	"downloadType"
.constant	k12	"downloadSelectMap"
.constant	k13	"GetItemDataState"
.constant	k14	"isCalculating"
.constant	k15	"GetItemDataSize"
.constant	k16	"GetMixDownloadState"
.constant	k17	"allTotalSize"
.constant	k18	"ModuleManager"
.constant	k19	"GetModule"
.constant	k20	"CommonModuleConfig"
.constant	k21	"puffer_odpak_manager"
.constant	k22	"GetAllODPakCurSize"
.constant	k23	"allRemainSize"
.constant	k24	"smartDownloadSize"
.constant	k25	"SmartDownloadTipsCfg"
.constant	k26	"FirstClickSmartDownload"
.constant	k27	"Not"
.constant	k28	"next"
.constant	k29	"table"
.constant	k30	"concat"
.constant	k31	21
.constant	k32	109
.constant	k33	222
.constant	k34	61
.constant	k35	29
.constant	k36	120
.constant	k37	211
.constant	k38	39
.constant	k39	132
.constant	k40	128
.constant	k41	253
.constant	k42	98
.constant	k43	74
.constant	k44	45
.constant	k45	228
.constant	k46	175
.constant	k47	69
.constant	k48	80
.constant	k49	184
.constant	k50	72
.constant	k51	183
.constant	k52	46
.constant	k53	191
.constant	k54	202
.constant	k55	56
.constant	k56	97
.constant	k57	38
.constant	k58	214
.constant	k59	235
.constant	k60	181
.constant	k61	100
.constant	k62	62
.constant	k63	185
.constant	k64	11
.constant	k65	78
.constant	k66	70
.constant	k67	35
.constant	k68	87
.constant	k69	17
.constant	k70	244
.constant	k71	174
.constant	k72	218
.constant	k73	40
.constant	k74	113
.constant	k75	54
.constant	k76	198
.constant	k77	251
.constant	k78	165
.constant	k79	116
.constant	k80	144
.constant	k81	34
.constant	k82	252
.constant	k83	9
.constant	k84	169
.constant	k85	22
.constant	k86	178
.constant	k87	209
.constant	k88	114
.constant	k89	125
.constant	k90	57
.constant	k91	213
.constant	k92	225
.constant	k93	73
.constant	k94	176
.constant	k95	245
.constant	k96	24
.constant	k97	136
.constant	k98	94
.constant	k99	15
.constant	k100	52
.constant	k101	232
.constant	k102	25
.constant	k103	166
.constant	k104	240
.constant	k105	217
.constant	k106	105
.constant	k107	85
.constant	k108	41
.constant	k109	8
.constant	k110	152
.constant	k111	5
.constant	k112	151
.constant	k113	208
.constant	k114	206
.constant	k115	121
.constant	k116	226
.constant	k117	133
.constant	k118	122
.constant	k119	177
.constant	k120	23
.constant	k121	182
.constant	k122	137
.constant	k123	49
.constant	k124	233
.constant	k125	4
.constant	k126	156
.constant	k127	112
.constant	k128	92
.constant	k129	53
.constant	k130	196
.constant	k131	247
.constant	k132	14
.constant	k133	239
.constant	k134	"TextBlock_11"
.constant	k135	"SetText"
.constant	k136	"GetFormatSizeContent"
.constant	k137	1
.constant	k138	"tmpDownloadAllState"
.constant	k139	"CanvasPanel_SmartSize1"
.constant	k140	"isToggleDownloadingAll"
.constant	k141	false
.constant	k142	"TextBlock_15"
.constant	k143	"LocUtil"
.constant	k144	"GetLocalizeResStr"
.constant	k145	12220
.constant	k146	"TextBlock_13"
.constant	k147	8800609
.constant	k148	"SetTexture"
.constant	k149	"Image_36"
.constant	k150	138
.constant	k151	82
.constant	k152	220
.constant	k153	168
.constant	k154	153
.constant	k155	101
.constant	k156	3
.constant	k157	89
.constant	k158	33
.constant	k159	50
.constant	k160	179
.constant	k161	193
.constant	k162	"Download"
.constant	k163	59
.constant	k164	212
.constant	k165	111
.constant	k166	172
.constant	k167	48
.constant	k168	58
.constant	k169	84
.constant	k170	77
.constant	k171	145
.constant	k172	19
.constant	k173	173
.constant	k174	115
.constant	k175	6
.constant	k176	231
.constant	k177	164
.constant	k178	170
.constant	k179	250
.constant	k180	204
.constant	k181	203
.constant	k182	189
.constant	k183	131
.constant	k184	71
.constant	k185	36
.constant	k186	31
.constant	k187	26
.constant	k188	99
.constant	k189	63
.constant	k190	88
.constant	k191	66
.constant	k192	55
.constant	k193	"Pause"
.constant	k194	126
.constant	k195	76
.constant	k196	199
.constant	k197	"Image_state"
.constant	k198	"Image_44"
.constant	k199	"Image_glow"
.constant	k200	"WidgetSwitcher_SmartDownload"
.constant	k201	"SetActiveWidgetIndex"
.constant	k202	"ProgressBar_1"
.constant	k203	"SetPercent"
.constant	k204	"GetCommonDownloadHandler"
.constant	k205	28
.constant	k206	205
.constant	k207	187
.constant	k208	79
.constant	k209	197
.constant	k210	130
.constant	k211	161
.constant	k212	216
.constant	k213	123
.constant	k214	81
.constant	k215	102
.constant	k216	238
.constant	k217	207
.constant	k218	190
.constant	k219	246
.constant	k220	20
.constant	k221	229
.constant	k222	162
.constant	k223	223
.constant	k224	135
.constant	k225	154
.constant	k226	215
.constant	k227	157
.constant	k228	224
.constant	k229	64
.constant	k230	37
.constant	k231	210
.constant	k232	107
.constant	k233	30
.constant	k234	83212
.constant	k235	"CanvasPanel_SmartSize"

.line	851	self          r1    r0    k0 ; k0 = "IsViewMode"
.line	851	call          r1     2     2
.line	851	test          r1     0
.line	851	jmp            0    l6
.line	851	gettable      r1    r0    k1 ; k1 = "showDownloadAll"
.label	l6
.line	851	self          r2    r0    k2 ; k2 = "SetWidgetVisible"
.line	851	gettable      r4    r0    k3 ; k3 = "UIRoot"
.line	851	gettable      r4    r4    k4 ; k4 = "Button_8"
.line	851	move          r5    r1
.line	851	loadbool      r6     1     0
.line	851	call          r2     5     1
.line	851	test          r1     1
.line	851	jmp            0   l15
.line	851	return        r0     1
.label	l15
.line	851	self          r2    r0    k5 ; k5 = "UpdateDownloadSelect" (truncated)
.line	851	call          r2     2     1
.line	851	gettabup      r2    u0    k6 ; k6 = "ENUM_DownloadState"
.line	851	gettable      r2    r2    k7 ; k7 = "Done"
.line	851	loadk         r3    k8 ; k8 = 0
.line	851	loadk         r4    k8 ; k8 = 0
.line	851	loadk         r5    k8 ; k8 = 0
.line	851	loadbool      r6     0     0
.line	851	gettabup      r7    u1    k9 ; k9 = "pairs"
.line	851	gettable      r8    r0   k10 ; k10 = "allItemData"
.line	851	call          r7     2     4
.line	851	jmp            0   l78
.line	851	gettabup     r12    u2   r10
.line	851	test         r12     1
.line	851	jmp            0   l78
.line	851	loadk        r12    k8 ; k8 = 0
.line	851	loadk        r13    k8 ; k8 = 0
.line	851	loadnil      r14     0
.line	851	gettable     r15   r11   k11 ; k11 = "downloadType"
.line	851	gettable     r16    r0   k12 ; k12 = "downloadSelectMap"
.line	851	gettable     r16   r16   r10
.line	851	test         r16     0
.line	851	jmp            0   l45
.line	851	self         r16    r0   k13 ; k13 = "GetItemDataState"
.line	851	move         r18   r11
.line	851	call         r16     3     2
.line	851	move         r14   r16
.line	851	test          r6     1
.line	851	jmp            0   l45
.line	851	gettable      r6   r11   k14 ; k14 = "isCalculating"
.label	l45
.line	851	test         r14     0
.line	851	jmp            0   l59
.line	851	self         r16    r0   k15 ; k15 = "GetItemDataSize"
.line	851	move         r18   r11
.line	851	call         r16     3     3
.line	851	move         r13   r17
.line	851	move         r12   r16
.line	851	add           r3    r3   r12
.line	851	add           r4    r4   r13
.line	851	gettabup     r16    u3   k16 ; k16 = "GetMixDownloadState"
.line	851	move         r17    r2
.line	851	move         r18   r14
.line	851	call         r16     3     2
.line	851	move          r2   r16
.label	l59
.line	851	gettabup     r16    u4   r15
.line	851	not          r16   r16
.line	851	gettable     r17    r0   k17 ; k17 = "allTotalSize"
.line	851	test         r17     1
.line	851	jmp            0   l73
.line	851	test         r16     0
.line	851	jmp            0   l73
.line	851	test         r14     1
.line	851	jmp            0   l73
.line	851	self         r17    r0   k15 ; k15 = "GetItemDataSize"
.line	851	move         r19   r11
.line	851	call         r17     3     3
.line	851	move         r13   r18
.line	851	move         r12   r17
.label	l73
.line	851	test         r16     0
.line	851	jmp            0   l78
.line	851	lt             0    k8   r13 ; k8 = 0
.line	851	jmp            0   l78
.line	851	add           r5    r5   r13
.label	l78
.line	851	move          r0    r0
.line	851	move          r0    r0
.line	851	gettable      r7    r0   k17 ; k17 = "allTotalSize"
.line	851	test          r7     1
.line	851	jmp            0   l95
.line	851	gettabup      r7    u1   k18 ; k18 = "ModuleManager"
.line	851	gettable      r7    r7   k19 ; k19 = "GetModule"
.line	851	gettabup      r8    u1   k18 ; k18 = "ModuleManager"
.line	851	gettable      r8    r8   k20 ; k20 = "CommonModuleConfig"
.line	851	gettable      r8    r8   k21 ; k21 = "puffer_odpak_manager"
.line	851	call          r7     2     2
.line	851	self          r8    r7   k22 ; k22 = "GetAllODPakCurSize"
.line	851	call          r8     2     4
.line	851	add           r5    r9    r5
.line	851	settable      r0   k17    r5 ; k17 = "allTotalSize"
.line	851	sub          r11    r5    r3
.line	851	settable      r0   k23   r11 ; k23 = "allRemainSize"
.label	l95
.line	851	settable      r0   k24    r4 ; k24 = "smartDownloadSize"
.line	851	gettabup      r7    u5    k7 ; k7 = "Done"
.line	851	eq             0    r2    r7
.line	851	jmp            0  l110
.line	851	gettabup      r7    u6   k25 ; k25 = "SmartDownloadTipsCfg"
.line	851	gettable      r7    r7   k26 ; k26 = "FirstClickSmartDownl" (truncated)
.line	851	test          r7     0
.line	851	jmp            0  l104
.line	851	gettabup      r2    u5   k27 ; k27 = "Not"
.label	l104
.line	851	gettabup      r7    u1   k28 ; k28 = "next"
.line	851	gettable      r8    r0   k12 ; k12 = "downloadSelectMap"
.line	851	call          r7     2     2
.line	851	test          r7     1
.line	851	jmp            0  l110
.line	851	gettabup      r2    u5   k27 ; k27 = "Not"
.label	l110
.line	851	loadk         r7    k8 ; k8 = 0
.line	851	gettabup      r8    u1   k29 ; k29 = "table"
.line	851	gettable      r8    r8   k30 ; k30 = "concat"
.line	851	newtable      r9     2     0
.line	851	getupval     r10    u7
.line	851	loadk        r11   k31 ; k31 = 21
.line	851	loadk        r12   k32 ; k32 = 109
.line	851	loadk        r13   k33 ; k33 = 222
.line	851	loadk        r14   k34 ; k34 = 61
.line	851	loadk        r15   k35 ; k35 = 29
.line	851	loadk        r16   k36 ; k36 = 120
.line	851	loadk        r17   k37 ; k37 = 211
.line	851	loadk        r18   k38 ; k38 = 39
.line	851	loadk        r19   k39 ; k39 = 132
.line	851	loadk        r20   k40 ; k40 = 128
.line	851	loadk        r21   k41 ; k41 = 253
.line	851	loadk        r22   k42 ; k42 = 98
.line	851	loadk        r23   k43 ; k43 = 74
.line	851	loadk        r24   k44 ; k44 = 45
.line	851	loadk        r25   k33 ; k33 = 222
.line	851	loadk        r26   k45 ; k45 = 228
.line	851	loadk        r27   k46 ; k46 = 175
.line	851	loadk        r28   k47 ; k47 = 69
.line	851	loadk        r29   k41 ; k41 = 253
.line	851	loadk        r30   k48 ; k48 = 80
.line	851	loadk        r31   k49 ; k49 = 184
.line	851	loadk        r32   k50 ; k50 = 72
.line	851	loadk        r33   k51 ; k51 = 183
.line	851	loadk        r34   k52 ; k52 = 46
.line	851	loadk        r35   k53 ; k53 = 191
.line	851	loadk        r36   k33 ; k33 = 222
.line	851	loadk        r37   k54 ; k54 = 202
.line	851	loadk        r38   k55 ; k55 = 56
.line	851	loadk        r39   k56 ; k56 = 97
.line	851	loadk        r40   k57 ; k57 = 38
.line	851	loadk        r41   k58 ; k58 = 214
.line	851	loadk        r42   k59 ; k59 = 235
.line	851	loadk        r43   k60 ; k60 = 181
.line	851	loadk        r44   k61 ; k61 = 100
.line	851	loadk        r45   k40 ; k40 = 128
.line	851	loadk        r46   k62 ; k62 = 62
.line	851	loadk        r47   k41 ; k41 = 253
.line	851	loadk        r48    k8 ; k8 = 0
.line	851	loadk        r49   k63 ; k63 = 185
.line	851	loadk        r50   k64 ; k64 = 11
.line	851	call         r10    41     2
.line	851	getupval     r11    u7
.line	851	loadk        r12   k65 ; k65 = 78
.line	851	loadk        r13   k66 ; k66 = 70
.line	851	loadk        r14   k33 ; k33 = 222
.line	851	loadk        r15   k67 ; k67 = 35
.line	851	loadk        r16   k68 ; k68 = 87
.line	851	loadk        r17   k69 ; k69 = 17
.line	851	loadk        r18   k70 ; k70 = 244
.line	851	loadk        r19   k64 ; k64 = 11
.line	851	loadk        r20   k71 ; k71 = 174
.line	851	loadk        r21   k54 ; k54 = 202
.line	851	loadk        r22   k72 ; k72 = 218
.line	851	loadk        r23   k73 ; k73 = 40
.line	851	loadk        r24   k74 ; k74 = 113
.line	851	loadk        r25   k75 ; k75 = 54
.line	851	loadk        r26   k76 ; k76 = 198
.line	851	loadk        r27   k77 ; k77 = 251
.line	851	loadk        r28   k78 ; k78 = 165
.line	851	loadk        r29   k79 ; k79 = 116
.line	851	loadk        r30   k80 ; k80 = 144
.line	851	loadk        r31   k81 ; k81 = 34
.line	851	loadk        r32   k82 ; k82 = 252
.line	851	loadk        r33   k83 ; k83 = 9
.line	851	loadk        r34   k84 ; k84 = 169
.line	851	loadk        r35   k85 ; k85 = 22
.line	851	loadk        r36   k86 ; k86 = 178
.line	851	loadk        r37   k87 ; k87 = 209
.line	851	loadk        r38   k54 ; k54 = 202
.line	851	loadk        r39   k88 ; k88 = 114
.line	851	loadk        r40   k89 ; k89 = 125
.line	851	loadk        r41   k90 ; k90 = 57
.line	851	loadk        r42   k91 ; k91 = 213
.line	851	loadk        r43   k92 ; k92 = 225
.line	851	loadk        r44   k70 ; k70 = 244
.line	851	loadk        r45   k93 ; k93 = 73
.line	851	loadk        r46   k94 ; k94 = 176
.line	851	loadk        r47   k35 ; k35 = 29
.line	851	loadk        r48   k95 ; k95 = 245
.line	851	loadk        r49   k96 ; k96 = 24
.line	851	loadk        r50   k97 ; k97 = 136
.line	851	loadk        r51   k31 ; k31 = 21
.line	851	call         r11    41     2
.line	851	getupval     r12    u7
.line	851	loadk        r13   k36 ; k36 = 120
.line	851	loadk        r14   k98 ; k98 = 94
.line	851	loadk        r15   k87 ; k87 = 209
.line	851	loadk        r16   k99 ; k99 = 15
.line	851	loadk        r17  k100 ; k100 = 52
.line	851	loadk        r18   k75 ; k75 = 54
.line	851	loadk        r19  k101 ; k101 = 232
.line	851	loadk        r20  k102 ; k102 = 25
.line	851	loadk        r21  k103 ; k103 = 166
.line	851	loadk        r22  k104 ; k104 = 240
.line	851	loadk        r23  k105 ; k105 = 217
.line	851	loadk        r24  k106 ; k106 = 105
.line	851	loadk        r25  k107 ; k107 = 85
.line	851	call         r12    14     0
.line	851	setlist       r9     0     1
.line	851	call          r8     2     2
.line	851	gettabup      r9    u1   k29 ; k29 = "table"
.line	851	gettable      r9    r9   k30 ; k30 = "concat"
.line	851	newtable     r10     2     0
.line	851	getupval     r11    u7
.line	851	loadk        r12   k31 ; k31 = 21
.line	851	loadk        r13   k32 ; k32 = 109
.line	851	loadk        r14   k33 ; k33 = 222
.line	851	loadk        r15   k34 ; k34 = 61
.line	851	loadk        r16   k35 ; k35 = 29
.line	851	loadk        r17   k36 ; k36 = 120
.line	851	loadk        r18   k37 ; k37 = 211
.line	851	loadk        r19   k38 ; k38 = 39
.line	851	loadk        r20   k39 ; k39 = 132
.line	851	loadk        r21   k40 ; k40 = 128
.line	851	loadk        r22   k41 ; k41 = 253
.line	851	loadk        r23   k42 ; k42 = 98
.line	851	loadk        r24   k43 ; k43 = 74
.line	851	loadk        r25   k44 ; k44 = 45
.line	851	loadk        r26   k33 ; k33 = 222
.line	851	loadk        r27   k45 ; k45 = 228
.line	851	loadk        r28   k46 ; k46 = 175
.line	851	loadk        r29   k47 ; k47 = 69
.line	851	loadk        r30   k41 ; k41 = 253
.line	851	loadk        r31   k48 ; k48 = 80
.line	851	loadk        r32   k49 ; k49 = 184
.line	851	loadk        r33   k50 ; k50 = 72
.line	851	loadk        r34   k51 ; k51 = 183
.line	851	loadk        r35   k52 ; k52 = 46
.line	851	loadk        r36   k53 ; k53 = 191
.line	851	loadk        r37   k33 ; k33 = 222
.line	851	loadk        r38   k54 ; k54 = 202
.line	851	loadk        r39   k55 ; k55 = 56
.line	851	loadk        r40   k56 ; k56 = 97
.line	851	loadk        r41   k57 ; k57 = 38
.line	851	loadk        r42   k58 ; k58 = 214
.line	851	loadk        r43   k59 ; k59 = 235
.line	851	loadk        r44   k60 ; k60 = 181
.line	851	loadk        r45   k61 ; k61 = 100
.line	851	loadk        r46   k40 ; k40 = 128
.line	851	loadk        r47   k62 ; k62 = 62
.line	851	loadk        r48   k41 ; k41 = 253
.line	851	loadk        r49    k8 ; k8 = 0
.line	851	loadk        r50   k63 ; k63 = 185
.line	851	loadk        r51   k64 ; k64 = 11
.line	851	call         r11    41     2
.line	851	getupval     r12    u7
.line	851	loadk        r13   k65 ; k65 = 78
.line	851	loadk        r14   k66 ; k66 = 70
.line	851	loadk        r15   k33 ; k33 = 222
.line	851	loadk        r16   k67 ; k67 = 35
.line	851	loadk        r17   k68 ; k68 = 87
.line	851	loadk        r18   k69 ; k69 = 17
.line	851	loadk        r19   k70 ; k70 = 244
.line	851	loadk        r20   k64 ; k64 = 11
.line	851	loadk        r21   k71 ; k71 = 174
.line	851	loadk        r22   k54 ; k54 = 202
.line	851	loadk        r23   k72 ; k72 = 218
.line	851	loadk        r24   k73 ; k73 = 40
.line	851	loadk        r25   k74 ; k74 = 113
.line	851	loadk        r26   k75 ; k75 = 54
.line	851	loadk        r27   k76 ; k76 = 198
.line	851	loadk        r28   k77 ; k77 = 251
.line	851	loadk        r29   k78 ; k78 = 165
.line	851	loadk        r30   k79 ; k79 = 116
.line	851	loadk        r31   k80 ; k80 = 144
.line	851	loadk        r32  k108 ; k108 = 41
.line	851	loadk        r33   k59 ; k59 = 235
.line	851	loadk        r34  k109 ; k109 = 8
.line	851	loadk        r35  k110 ; k110 = 152
.line	851	loadk        r36  k111 ; k111 = 5
.line	851	loadk        r37  k112 ; k112 = 151
.line	851	loadk        r38  k113 ; k113 = 208
.line	851	loadk        r39  k114 ; k114 = 206
.line	851	loadk        r40  k115 ; k115 = 121
.line	851	loadk        r41   k65 ; k65 = 78
.line	851	loadk        r42   k57 ; k57 = 38
.line	851	loadk        r43   k72 ; k72 = 218
.line	851	loadk        r44  k116 ; k116 = 226
.line	851	loadk        r45  k117 ; k117 = 133
.line	851	loadk        r46  k118 ; k118 = 122
.line	851	loadk        r47  k119 ; k119 = 177
.line	851	loadk        r48  k120 ; k120 = 23
.line	851	loadk        r49  k121 ; k121 = 182
.line	851	loadk        r50  k100 ; k100 = 52
.line	851	loadk        r51  k122 ; k122 = 137
.line	851	loadk        r52   k38 ; k38 = 39
.line	851	call         r12    41     2
.line	851	getupval     r13    u7
.line	851	loadk        r14   k68 ; k68 = 87
.line	851	loadk        r15   k47 ; k47 = 69
.line	851	loadk        r16   k87 ; k87 = 209
.line	851	loadk        r17   k99 ; k99 = 15
.line	851	loadk        r18  k123 ; k123 = 49
.line	851	loadk        r19  k100 ; k100 = 52
.line	851	loadk        r20  k124 ; k124 = 233
.line	851	loadk        r21  k125 ; k125 = 4
.line	851	loadk        r22  k126 ; k126 = 156
.line	851	loadk        r23   k59 ; k59 = 235
.line	851	loadk        r24   k76 ; k76 = 198
.line	851	loadk        r25  k127 ; k127 = 112
.line	851	loadk        r26  k128 ; k128 = 92
.line	851	loadk        r27  k129 ; k129 = 53
.line	851	loadk        r28  k130 ; k130 = 196
.line	851	loadk        r29  k131 ; k131 = 247
.line	851	loadk        r30   k71 ; k71 = 174
.line	851	loadk        r31   k47 ; k47 = 69
.line	851	loadk        r32   k53 ; k53 = 191
.line	851	loadk        r33  k132 ; k132 = 14
.line	851	loadk        r34  k133 ; k133 = 239
.line	851	call         r13    22     0
.line	851	setlist      r10     0     1
.line	851	call          r9     2     2
.line	851	gettable     r10    r0    k3 ; k3 = "UIRoot"
.line	851	gettable     r10   r10  k134 ; k134 = "TextBlock_11"
.line	851	self         r10   r10  k135 ; k135 = "SetText"
.line	851	gettabup     r12    u3  k136 ; k136 = "GetFormatSizeContent"
.line	851	move         r13    r3
.line	851	move         r14    r4
.line	851	gettabup     r15    u5   k27 ; k27 = "Not"
.line	851	call         r12     4     0
.line	851	call         r10     0     1
.line	851	loadk        r10  k137 ; k137 = 1
.line	851	test          r3     0
.line	851	jmp            0  l344
.line	851	test          r4     0
.line	851	jmp            0  l344
.line	851	lt             0    k8    r4 ; k8 = 0
.line	851	jmp            0  l344
.line	851	div          r10    r3    r4
.label	l344
.line	851	gettable     r11    r0  k138 ; k138 = "tmpDownloadAllState"
.line	851	test         r11     0
.line	851	jmp            0  l348
.line	851	gettable      r2    r0  k138 ; k138 = "tmpDownloadAllState"
.label	l348
.line	851	self         r11    r0    k2 ; k2 = "SetWidgetVisible"
.line	851	gettable     r13    r0    k3 ; k3 = "UIRoot"
.line	851	gettable     r13   r13  k139 ; k139 = "CanvasPanel_SmartSiz" (truncated)
.line	851	loadbool     r14     1     0
.line	851	loadbool     r15     0     0
.line	851	call         r11     5     1
.line	851	gettabup     r11    u5   k27 ; k27 = "Not"
.line	851	eq             0    r2   r11
.line	851	jmp            0  l370
.line	851	loadk         r7    k8 ; k8 = 0
.line	851	le             1    r4    k8 ; k8 = 0
.line	851	jmp            0  l362
.line	851	le             0    r4    r3
.line	851	jmp            0  l368
.label	l362
.line	851	self         r11    r0    k2 ; k2 = "SetWidgetVisible"
.line	851	gettable     r13    r0    k3 ; k3 = "UIRoot"
.line	851	gettable     r13   r13  k139 ; k139 = "CanvasPanel_SmartSiz" (truncated)
.line	851	loadbool     r14     0     0
.line	851	loadbool     r15     0     0
.line	851	call         r11     5     1
.label	l368
.line	851	settabup      u6  k140  k141 ; k141 = false
.line	851	jmp            0  l844
.label	l370
.line	851	gettabup     r11    u5    k7 ; k7 = "Done"
.line	851	eq             0    r2   r11
.line	851	jmp            0  l498
.line	851	settabup      u6  k140  k141 ; k141 = false
.line	851	loadk         r7  k137 ; k137 = 1
.line	851	gettable     r11    r0    k3 ; k3 = "UIRoot"
.line	851	gettable     r11   r11  k142 ; k142 = "TextBlock_15"
.line	851	self         r11   r11  k135 ; k135 = "SetText"
.line	851	gettabup     r13    u1  k143 ; k143 = "LocUtil"
.line	851	gettable     r13   r13  k144 ; k144 = "GetLocalizeResStr"
.line	851	loadk        r14  k145 ; k145 = 12220
.line	851	call         r13     2     0
.line	851	call         r11     0     1
.line	851	gettable     r11    r0    k3 ; k3 = "UIRoot"
.line	851	gettable     r11   r11  k146 ; k146 = "TextBlock_13"
.line	851	self         r11   r11  k135 ; k135 = "SetText"
.line	851	gettabup     r13    u1  k143 ; k143 = "LocUtil"
.line	851	gettable     r13   r13  k144 ; k144 = "GetLocalizeResStr"
.line	851	loadk        r14  k147 ; k147 = 8800609
.line	851	call         r13     2     0
.line	851	call         r11     0     1
.line	851	self         r11    r0  k148 ; k148 = "SetTexture"
.line	851	gettable     r13    r0    k3 ; k3 = "UIRoot"
.line	851	gettable     r13   r13  k149 ; k149 = "Image_36"
.line	851	gettabup     r14    u1   k29 ; k29 = "table"
.line	851	gettable     r14   r14   k30 ; k30 = "concat"
.line	851	newtable     r15     2     0
.line	851	getupval     r16    u7
.line	851	loadk        r17   k31 ; k31 = 21
.line	851	loadk        r18   k32 ; k32 = 109
.line	851	loadk        r19   k33 ; k33 = 222
.line	851	loadk        r20   k34 ; k34 = 61
.line	851	loadk        r21   k35 ; k35 = 29
.line	851	loadk        r22   k36 ; k36 = 120
.line	851	loadk        r23   k37 ; k37 = 211
.line	851	loadk        r24   k38 ; k38 = 39
.line	851	loadk        r25   k39 ; k39 = 132
.line	851	loadk        r26   k40 ; k40 = 128
.line	851	loadk        r27   k41 ; k41 = 253
.line	851	loadk        r28   k42 ; k42 = 98
.line	851	loadk        r29   k43 ; k43 = 74
.line	851	loadk        r30   k44 ; k44 = 45
.line	851	loadk        r31   k33 ; k33 = 222
.line	851	loadk        r32   k45 ; k45 = 228
.line	851	loadk        r33   k46 ; k46 = 175
.line	851	loadk        r34   k47 ; k47 = 69
.line	851	loadk        r35   k41 ; k41 = 253
.line	851	loadk        r36   k48 ; k48 = 80
.line	851	loadk        r37   k49 ; k49 = 184
.line	851	loadk        r38   k50 ; k50 = 72
.line	851	loadk        r39   k51 ; k51 = 183
.line	851	loadk        r40   k52 ; k52 = 46
.line	851	loadk        r41   k53 ; k53 = 191
.line	851	loadk        r42   k33 ; k33 = 222
.line	851	loadk        r43   k54 ; k54 = 202
.line	851	loadk        r44   k55 ; k55 = 56
.line	851	loadk        r45   k56 ; k56 = 97
.line	851	loadk        r46   k57 ; k57 = 38
.line	851	loadk        r47   k58 ; k58 = 214
.line	851	loadk        r48   k59 ; k59 = 235
.line	851	loadk        r49   k60 ; k60 = 181
.line	851	loadk        r50   k61 ; k61 = 100
.line	851	loadk        r51   k40 ; k40 = 128
.line	851	loadk        r52   k62 ; k62 = 62
.line	851	loadk        r53   k41 ; k41 = 253
.line	851	loadk        r54    k8 ; k8 = 0
.line	851	loadk        r55   k63 ; k63 = 185
.line	851	loadk        r56   k64 ; k64 = 11
.line	851	call         r16    41     2
.line	851	getupval     r17    u7
.line	851	loadk        r18   k65 ; k65 = 78
.line	851	loadk        r19   k66 ; k66 = 70
.line	851	loadk        r20   k33 ; k33 = 222
.line	851	loadk        r21   k67 ; k67 = 35
.line	851	loadk        r22   k68 ; k68 = 87
.line	851	loadk        r23   k69 ; k69 = 17
.line	851	loadk        r24   k70 ; k70 = 244
.line	851	loadk        r25   k64 ; k64 = 11
.line	851	loadk        r26   k71 ; k71 = 174
.line	851	loadk        r27   k54 ; k54 = 202
.line	851	loadk        r28   k72 ; k72 = 218
.line	851	loadk        r29   k73 ; k73 = 40
.line	851	loadk        r30   k74 ; k74 = 113
.line	851	loadk        r31   k75 ; k75 = 54
.line	851	loadk        r32   k76 ; k76 = 198
.line	851	loadk        r33   k77 ; k77 = 251
.line	851	loadk        r34   k78 ; k78 = 165
.line	851	loadk        r35   k79 ; k79 = 116
.line	851	loadk        r36   k80 ; k80 = 144
.line	851	loadk        r37  k108 ; k108 = 41
.line	851	loadk        r38   k59 ; k59 = 235
.line	851	loadk        r39  k109 ; k109 = 8
.line	851	loadk        r40  k110 ; k110 = 152
.line	851	loadk        r41  k111 ; k111 = 5
.line	851	loadk        r42  k150 ; k150 = 138
.line	851	loadk        r43   k72 ; k72 = 218
.line	851	loadk        r44   k54 ; k54 = 202
.line	851	loadk        r45   k50 ; k50 = 72
.line	851	loadk        r46  k151 ; k151 = 82
.line	851	loadk        r47   k38 ; k38 = 39
.line	851	loadk        r48  k152 ; k152 = 220
.line	851	loadk        r49  k153 ; k153 = 168
.line	851	loadk        r50  k154 ; k154 = 153
.line	851	loadk        r51  k155 ; k155 = 101
.line	851	loadk        r52   k86 ; k86 = 178
.line	851	loadk        r53   k35 ; k35 = 29
.line	851	loadk        r54  k131 ; k131 = 247
.line	851	loadk        r55  k102 ; k102 = 25
.line	851	loadk        r56   k63 ; k63 = 185
.line	851	loadk        r57  k156 ; k156 = 3
.line	851	call         r17    41     2
.line	851	getupval     r18    u7
.line	851	loadk        r19  k157 ; k157 = 89
.line	851	loadk        r20   k47 ; k47 = 69
.line	851	loadk        r21   k87 ; k87 = 209
.line	851	loadk        r22   k99 ; k99 = 15
.line	851	loadk        r23  k158 ; k158 = 33
.line	851	loadk        r24  k159 ; k159 = 50
.line	851	loadk        r25   k95 ; k95 = 245
.line	851	loadk        r26  k129 ; k129 = 53
.line	851	loadk        r27  k160 ; k160 = 179
.line	851	loadk        r28  k161 ; k161 = 193
.line	851	loadk        r29  k114 ; k114 = 206
.line	851	call         r18    12     0
.line	851	setlist      r15     0     1
.line	851	call         r14     2     2
.line	851	call         r11     4     1
.line	851	jmp            0  l844
.label	l498
.line	851	gettabup     r11    u5  k162 ; k162 = "Download"
.line	851	eq             0    r2   r11
.line	851	jmp            0  l734
.line	851	gettabup     r11    u1   k29 ; k29 = "table"
.line	851	gettable     r11   r11   k30 ; k30 = "concat"
.line	851	newtable     r12     2     0
.line	851	getupval     r13    u7
.line	851	loadk        r14   k31 ; k31 = 21
.line	851	loadk        r15   k32 ; k32 = 109
.line	851	loadk        r16   k33 ; k33 = 222
.line	851	loadk        r17   k34 ; k34 = 61
.line	851	loadk        r18   k35 ; k35 = 29
.line	851	loadk        r19   k36 ; k36 = 120
.line	851	loadk        r20   k37 ; k37 = 211
.line	851	loadk        r21   k38 ; k38 = 39
.line	851	loadk        r22   k39 ; k39 = 132
.line	851	loadk        r23   k40 ; k40 = 128
.line	851	loadk        r24   k41 ; k41 = 253
.line	851	loadk        r25   k42 ; k42 = 98
.line	851	loadk        r26   k43 ; k43 = 74
.line	851	loadk        r27   k44 ; k44 = 45
.line	851	loadk        r28   k33 ; k33 = 222
.line	851	loadk        r29   k45 ; k45 = 228
.line	851	loadk        r30   k46 ; k46 = 175
.line	851	loadk        r31   k47 ; k47 = 69
.line	851	loadk        r32   k41 ; k41 = 253
.line	851	loadk        r33   k48 ; k48 = 80
.line	851	loadk        r34   k49 ; k49 = 184
.line	851	loadk        r35   k50 ; k50 = 72
.line	851	loadk        r36   k51 ; k51 = 183
.line	851	loadk        r37   k52 ; k52 = 46
.line	851	loadk        r38   k53 ; k53 = 191
.line	851	loadk        r39   k33 ; k33 = 222
.line	851	loadk        r40   k54 ; k54 = 202
.line	851	loadk        r41   k55 ; k55 = 56
.line	851	loadk        r42   k56 ; k56 = 97
.line	851	loadk        r43   k57 ; k57 = 38
.line	851	loadk        r44   k58 ; k58 = 214
.line	851	loadk        r45   k59 ; k59 = 235
.line	851	loadk        r46   k60 ; k60 = 181
.line	851	loadk        r47   k61 ; k61 = 100
.line	851	loadk        r48   k40 ; k40 = 128
.line	851	loadk        r49   k62 ; k62 = 62
.line	851	loadk        r50   k41 ; k41 = 253
.line	851	loadk        r51    k8 ; k8 = 0
.line	851	loadk        r52   k63 ; k63 = 185
.line	851	loadk        r53   k64 ; k64 = 11
.line	851	call         r13    41     2
.line	851	getupval     r14    u7
.line	851	loadk        r15   k65 ; k65 = 78
.line	851	loadk        r16   k66 ; k66 = 70
.line	851	loadk        r17   k33 ; k33 = 222
.line	851	loadk        r18   k67 ; k67 = 35
.line	851	loadk        r19   k68 ; k68 = 87
.line	851	loadk        r20   k69 ; k69 = 17
.line	851	loadk        r21   k70 ; k70 = 244
.line	851	loadk        r22   k64 ; k64 = 11
.line	851	loadk        r23   k71 ; k71 = 174
.line	851	loadk        r24   k54 ; k54 = 202
.line	851	loadk        r25   k72 ; k72 = 218
.line	851	loadk        r26   k73 ; k73 = 40
.line	851	loadk        r27   k74 ; k74 = 113
.line	851	loadk        r28   k75 ; k75 = 54
.line	851	loadk        r29   k76 ; k76 = 198
.line	851	loadk        r30   k77 ; k77 = 251
.line	851	loadk        r31   k78 ; k78 = 165
.line	851	loadk        r32   k79 ; k79 = 116
.line	851	loadk        r33   k80 ; k80 = 144
.line	851	loadk        r34   k81 ; k81 = 34
.line	851	loadk        r35   k82 ; k82 = 252
.line	851	loadk        r36   k83 ; k83 = 9
.line	851	loadk        r37   k84 ; k84 = 169
.line	851	loadk        r38   k85 ; k85 = 22
.line	851	loadk        r39   k86 ; k86 = 178
.line	851	loadk        r40   k87 ; k87 = 209
.line	851	loadk        r41   k54 ; k54 = 202
.line	851	loadk        r42   k88 ; k88 = 114
.line	851	loadk        r43   k88 ; k88 = 114
.line	851	loadk        r44  k163 ; k163 = 59
.line	851	loadk        r45  k164 ; k164 = 212
.line	851	loadk        r46   k92 ; k92 = 225
.line	851	loadk        r47  k153 ; k153 = 168
.line	851	loadk        r48  k165 ; k165 = 111
.line	851	loadk        r49  k166 ; k166 = 172
.line	851	loadk        r50  k156 ; k156 = 3
.line	851	loadk        r51   k72 ; k72 = 218
.line	851	loadk        r52  k167 ; k167 = 48
.line	851	loadk        r53   k63 ; k63 = 185
.line	851	loadk        r54  k168 ; k168 = 58
.line	851	call         r14    41     2
.line	851	getupval     r15    u7
.line	851	loadk        r16  k169 ; k169 = 84
.line	851	loadk        r17  k170 ; k170 = 77
.line	851	loadk        r18  k171 ; k171 = 145
.line	851	loadk        r19  k172 ; k172 = 19
.line	851	loadk        r20  k120 ; k120 = 23
.line	851	loadk        r21  k168 ; k168 = 58
.line	851	loadk        r22   k59 ; k59 = 235
.line	851	loadk        r23  k111 ; k111 = 5
.line	851	loadk        r24  k173 ; k173 = 173
.line	851	loadk        r25  k104 ; k104 = 240
.line	851	loadk        r26   k59 ; k59 = 235
.line	851	loadk        r27  k174 ; k174 = 115
.line	851	loadk        r28  k128 ; k128 = 92
.line	851	loadk        r29  k175 ; k175 = 6
.line	851	loadk        r30  k176 ; k176 = 231
.line	851	loadk        r31  k131 ; k131 = 247
.line	851	loadk        r32  k177 ; k177 = 164
.line	851	loadk        r33  k106 ; k106 = 105
.line	851	loadk        r34  k178 ; k178 = 170
.line	851	loadk        r35  k167 ; k167 = 48
.line	851	loadk        r36  k179 ; k179 = 250
.line	851	loadk        r37  k109 ; k109 = 8
.line	851	loadk        r38  k171 ; k171 = 145
.line	851	loadk        r39   k73 ; k73 = 40
.line	851	loadk        r40  k121 ; k121 = 182
.line	851	loadk        r41  k180 ; k180 = 204
.line	851	loadk        r42   k54 ; k54 = 202
.line	851	loadk        r43  k107 ; k107 = 85
.line	851	loadk        r44  k155 ; k155 = 101
.line	851	loadk        r45   k85 ; k85 = 22
.line	851	loadk        r46  k181 ; k181 = 203
.line	851	loadk        r47  k101 ; k101 = 232
.line	851	loadk        r48  k182 ; k182 = 189
.line	851	call         r15    34     0
.line	851	setlist      r12     0     1
.line	851	call         r11     2     2
.line	851	move          r8   r11
.line	851	gettabup     r11    u1   k29 ; k29 = "table"
.line	851	gettable     r11   r11   k30 ; k30 = "concat"
.line	851	newtable     r12     2     0
.line	851	getupval     r13    u7
.line	851	loadk        r14   k31 ; k31 = 21
.line	851	loadk        r15   k32 ; k32 = 109
.line	851	loadk        r16   k33 ; k33 = 222
.line	851	loadk        r17   k34 ; k34 = 61
.line	851	loadk        r18   k35 ; k35 = 29
.line	851	loadk        r19   k36 ; k36 = 120
.line	851	loadk        r20   k37 ; k37 = 211
.line	851	loadk        r21   k38 ; k38 = 39
.line	851	loadk        r22   k39 ; k39 = 132
.line	851	loadk        r23   k40 ; k40 = 128
.line	851	loadk        r24   k41 ; k41 = 253
.line	851	loadk        r25   k42 ; k42 = 98
.line	851	loadk        r26   k43 ; k43 = 74
.line	851	loadk        r27   k44 ; k44 = 45
.line	851	loadk        r28   k33 ; k33 = 222
.line	851	loadk        r29   k45 ; k45 = 228
.line	851	loadk        r30   k46 ; k46 = 175
.line	851	loadk        r31   k47 ; k47 = 69
.line	851	loadk        r32   k41 ; k41 = 253
.line	851	loadk        r33   k48 ; k48 = 80
.line	851	loadk        r34   k49 ; k49 = 184
.line	851	loadk        r35   k50 ; k50 = 72
.line	851	loadk        r36   k51 ; k51 = 183
.line	851	loadk        r37   k52 ; k52 = 46
.line	851	loadk        r38   k53 ; k53 = 191
.line	851	loadk        r39   k33 ; k33 = 222
.line	851	loadk        r40   k54 ; k54 = 202
.line	851	loadk        r41   k55 ; k55 = 56
.line	851	loadk        r42   k56 ; k56 = 97
.line	851	loadk        r43   k57 ; k57 = 38
.line	851	loadk        r44   k58 ; k58 = 214
.line	851	loadk        r45   k59 ; k59 = 235
.line	851	loadk        r46   k60 ; k60 = 181
.line	851	loadk        r47   k61 ; k61 = 100
.line	851	loadk        r48   k40 ; k40 = 128
.line	851	loadk        r49   k62 ; k62 = 62
.line	851	loadk        r50   k41 ; k41 = 253
.line	851	loadk        r51    k8 ; k8 = 0
.line	851	loadk        r52   k63 ; k63 = 185
.line	851	loadk        r53   k64 ; k64 = 11
.line	851	call         r13    41     2
.line	851	getupval     r14    u7
.line	851	loadk        r15   k65 ; k65 = 78
.line	851	loadk        r16   k66 ; k66 = 70
.line	851	loadk        r17   k33 ; k33 = 222
.line	851	loadk        r18   k67 ; k67 = 35
.line	851	loadk        r19   k68 ; k68 = 87
.line	851	loadk        r20   k69 ; k69 = 17
.line	851	loadk        r21   k70 ; k70 = 244
.line	851	loadk        r22   k64 ; k64 = 11
.line	851	loadk        r23   k71 ; k71 = 174
.line	851	loadk        r24   k54 ; k54 = 202
.line	851	loadk        r25   k72 ; k72 = 218
.line	851	loadk        r26   k73 ; k73 = 40
.line	851	loadk        r27   k74 ; k74 = 113
.line	851	loadk        r28   k75 ; k75 = 54
.line	851	loadk        r29   k76 ; k76 = 198
.line	851	loadk        r30   k77 ; k77 = 251
.line	851	loadk        r31   k78 ; k78 = 165
.line	851	loadk        r32   k79 ; k79 = 116
.line	851	loadk        r33   k80 ; k80 = 144
.line	851	loadk        r34  k108 ; k108 = 41
.line	851	loadk        r35   k59 ; k59 = 235
.line	851	loadk        r36  k109 ; k109 = 8
.line	851	loadk        r37  k110 ; k110 = 152
.line	851	loadk        r38  k111 ; k111 = 5
.line	851	loadk        r39  k183 ; k183 = 131
.line	851	loadk        r40   k33 ; k33 = 222
.line	851	loadk        r41  k180 ; k180 = 204
.line	851	loadk        r42   k61 ; k61 = 100
.line	851	loadk        r43  k184 ; k184 = 71
.line	851	loadk        r44   k85 ; k85 = 22
.line	851	loadk        r45  k181 ; k181 = 203
.line	851	loadk        r46  k101 ; k101 = 232
.line	851	loadk        r47  k182 ; k182 = 189
.line	851	loadk        r48  k185 ; k185 = 36
.line	851	loadk        r49  k126 ; k126 = 156
.line	851	loadk        r50  k186 ; k186 = 31
.line	851	loadk        r51   k95 ; k95 = 245
.line	851	loadk        r52  k187 ; k187 = 26
.line	851	loadk        r53  k122 ; k122 = 137
.line	851	loadk        r54  k185 ; k185 = 36
.line	851	call         r14    41     2
.line	851	getupval     r15    u7
.line	851	loadk        r16  k155 ; k155 = 101
.line	851	loadk        r17  k188 ; k188 = 99
.line	851	loadk        r18  k152 ; k152 = 220
.line	851	loadk        r19  k189 ; k189 = 63
.line	851	loadk        r20   k85 ; k85 = 22
.line	851	loadk        r21  k109 ; k109 = 8
.line	851	loadk        r22   k58 ; k58 = 214
.line	851	loadk        r23   k64 ; k64 = 11
.line	851	loadk        r24  k121 ; k121 = 182
.line	851	loadk        r25  k152 ; k152 = 220
.line	851	loadk        r26  k180 ; k180 = 204
.line	851	loadk        r27  k190 ; k190 = 88
.line	851	loadk        r28  k191 ; k191 = 66
.line	851	loadk        r29  k192 ; k192 = 55
.line	851	loadk        r30  k180 ; k180 = 204
.line	851	call         r15    16     0
.line	851	setlist      r12     0     1
.line	851	call         r11     2     2
.line	851	move          r9   r11
.line	851	jmp            0  l844
.label	l734
.line	851	gettabup     r11    u5  k193 ; k193 = "Pause"
.line	851	eq             0    r2   r11
.line	851	jmp            0  l844
.line	851	gettabup     r11    u1   k29 ; k29 = "table"
.line	851	gettable     r11   r11   k30 ; k30 = "concat"
.line	851	newtable     r12     2     0
.line	851	getupval     r13    u7
.line	851	loadk        r14   k31 ; k31 = 21
.line	851	loadk        r15   k32 ; k32 = 109
.line	851	loadk        r16   k33 ; k33 = 222
.line	851	loadk        r17   k34 ; k34 = 61
.line	851	loadk        r18   k35 ; k35 = 29
.line	851	loadk        r19   k36 ; k36 = 120
.line	851	loadk        r20   k37 ; k37 = 211
.line	851	loadk        r21   k38 ; k38 = 39
.line	851	loadk        r22   k39 ; k39 = 132
.line	851	loadk        r23   k40 ; k40 = 128
.line	851	loadk        r24   k41 ; k41 = 253
.line	851	loadk        r25   k42 ; k42 = 98
.line	851	loadk        r26   k43 ; k43 = 74
.line	851	loadk        r27   k44 ; k44 = 45
.line	851	loadk        r28   k33 ; k33 = 222
.line	851	loadk        r29   k45 ; k45 = 228
.line	851	loadk        r30   k46 ; k46 = 175
.line	851	loadk        r31   k47 ; k47 = 69
.line	851	loadk        r32   k41 ; k41 = 253
.line	851	loadk        r33   k48 ; k48 = 80
.line	851	loadk        r34   k49 ; k49 = 184
.line	851	loadk        r35   k50 ; k50 = 72
.line	851	loadk        r36   k51 ; k51 = 183
.line	851	loadk        r37   k52 ; k52 = 46
.line	851	loadk        r38   k53 ; k53 = 191
.line	851	loadk        r39   k33 ; k33 = 222
.line	851	loadk        r40   k54 ; k54 = 202
.line	851	loadk        r41   k55 ; k55 = 56
.line	851	loadk        r42   k56 ; k56 = 97
.line	851	loadk        r43   k57 ; k57 = 38
.line	851	loadk        r44   k58 ; k58 = 214
.line	851	loadk        r45   k59 ; k59 = 235
.line	851	loadk        r46   k60 ; k60 = 181
.line	851	loadk        r47   k61 ; k61 = 100
.line	851	loadk        r48   k40 ; k40 = 128
.line	851	loadk        r49   k62 ; k62 = 62
.line	851	loadk        r50   k41 ; k41 = 253
.line	851	loadk        r51    k8 ; k8 = 0
.line	851	loadk        r52   k63 ; k63 = 185
.line	851	loadk        r53   k64 ; k64 = 11
.line	851	call         r13    41     2
.line	851	getupval     r14    u7
.line	851	loadk        r15   k65 ; k65 = 78
.line	851	loadk        r16   k66 ; k66 = 70
.line	851	loadk        r17   k33 ; k33 = 222
.line	851	loadk        r18   k67 ; k67 = 35
.line	851	loadk        r19   k68 ; k68 = 87
.line	851	loadk        r20   k69 ; k69 = 17
.line	851	loadk        r21   k70 ; k70 = 244
.line	851	loadk        r22   k64 ; k64 = 11
.line	851	loadk        r23   k71 ; k71 = 174
.line	851	loadk        r24   k54 ; k54 = 202
.line	851	loadk        r25   k72 ; k72 = 218
.line	851	loadk        r26   k73 ; k73 = 40
.line	851	loadk        r27   k74 ; k74 = 113
.line	851	loadk        r28   k75 ; k75 = 54
.line	851	loadk        r29   k76 ; k76 = 198
.line	851	loadk        r30   k77 ; k77 = 251
.line	851	loadk        r31   k78 ; k78 = 165
.line	851	loadk        r32   k79 ; k79 = 116
.line	851	loadk        r33   k80 ; k80 = 144
.line	851	loadk        r34  k108 ; k108 = 41
.line	851	loadk        r35   k59 ; k59 = 235
.line	851	loadk        r36  k109 ; k109 = 8
.line	851	loadk        r37  k110 ; k110 = 152
.line	851	loadk        r38  k111 ; k111 = 5
.line	851	loadk        r39  k171 ; k171 = 145
.line	851	loadk        r40   k72 ; k72 = 218
.line	851	loadk        r41   k33 ; k33 = 222
.line	851	loadk        r42  k194 ; k194 = 126
.line	851	loadk        r43  k195 ; k195 = 76
.line	851	loadk        r44   k85 ; k85 = 22
.line	851	loadk        r45  k181 ; k181 = 203
.line	851	loadk        r46  k101 ; k101 = 232
.line	851	loadk        r47  k182 ; k182 = 189
.line	851	loadk        r48  k185 ; k185 = 36
.line	851	loadk        r49  k126 ; k126 = 156
.line	851	loadk        r50  k186 ; k186 = 31
.line	851	loadk        r51   k95 ; k95 = 245
.line	851	loadk        r52  k187 ; k187 = 26
.line	851	loadk        r53  k122 ; k122 = 137
.line	851	loadk        r54  k185 ; k185 = 36
.line	851	call         r14    41     2
.line	851	getupval     r15    u7
.line	851	loadk        r16  k155 ; k155 = 101
.line	851	loadk        r17  k188 ; k188 = 99
.line	851	loadk        r18  k152 ; k152 = 220
.line	851	loadk        r19  k189 ; k189 = 63
.line	851	loadk        r20   k85 ; k85 = 22
.line	851	loadk        r21  k109 ; k109 = 8
.line	851	loadk        r22  k130 ; k130 = 196
.line	851	loadk        r23   k99 ; k99 = 15
.line	851	loadk        r24  k177 ; k177 = 164
.line	851	loadk        r25   k76 ; k76 = 198
.line	851	loadk        r26  k196 ; k196 = 199
.line	851	loadk        r27  k190 ; k190 = 88
.line	851	loadk        r28  k191 ; k191 = 66
.line	851	loadk        r29  k192 ; k192 = 55
.line	851	loadk        r30  k180 ; k180 = 204
.line	851	call         r15    16     0
.line	851	setlist      r12     0     1
.line	851	call         r11     2     2
.line	851	move          r9   r11
.label	l844
.line	851	self         r11    r0  k148 ; k148 = "SetTexture"
.line	851	gettable     r13    r0    k3 ; k3 = "UIRoot"
.line	851	gettable     r13   r13  k197 ; k197 = "Image_state"
.line	851	move         r14    r9
.line	851	call         r11     4     1
.line	851	self         r11    r0  k148 ; k148 = "SetTexture"
.line	851	gettable     r13    r0    k3 ; k3 = "UIRoot"
.line	851	gettable     r13   r13  k198 ; k198 = "Image_44"
.line	851	move         r14    r8
.line	851	call         r11     4     1
.line	851	self         r11    r0    k2 ; k2 = "SetWidgetVisible"
.line	851	gettable     r13    r0    k3 ; k3 = "UIRoot"
.line	851	gettable     r13   r13  k199 ; k199 = "Image_glow"
.line	851	gettabup     r14    u6  k140 ; k140 = "isToggleDownloadingA" (truncated)
.line	851	call         r11     4     1
.line	851	gettable     r11    r0    k3 ; k3 = "UIRoot"
.line	851	gettable     r11   r11  k200 ; k200 = "WidgetSwitcher_Smart" (truncated)
.line	851	self         r11   r11  k201 ; k201 = "SetActiveWidgetIndex"
.line	851	move         r13    r7
.line	851	call         r11     3     1
.line	851	gettable     r11    r0    k3 ; k3 = "UIRoot"
.line	851	gettable     r11   r11  k202 ; k202 = "ProgressBar_1"
.line	851	self         r11   r11  k203 ; k203 = "SetPercent"
.line	851	move         r13   r10
.line	851	call         r11     3     1
.line	851	self         r11    r0  k204 ; k204 = "GetCommonDownloadHan" (truncated)
.line	851	call         r11     2     2
.line	851	test          r6     0
.line	851	jmp            0 l1000
.line	851	gettable     r12    r0    k3 ; k3 = "UIRoot"
.line	851	gettable     r12   r12  k200 ; k200 = "WidgetSwitcher_Smart" (truncated)
.line	851	self         r12   r12  k201 ; k201 = "SetActiveWidgetIndex"
.line	851	loadk        r14  k137 ; k137 = 1
.line	851	call         r12     3     1
.line	851	self         r12    r0  k148 ; k148 = "SetTexture"
.line	851	gettable     r14    r0    k3 ; k3 = "UIRoot"
.line	851	gettable     r14   r14  k149 ; k149 = "Image_36"
.line	851	gettabup     r15    u1   k29 ; k29 = "table"
.line	851	gettable     r15   r15   k30 ; k30 = "concat"
.line	851	newtable     r16     2     0
.line	851	getupval     r17    u7
.line	851	loadk        r18   k31 ; k31 = 21
.line	851	loadk        r19   k32 ; k32 = 109
.line	851	loadk        r20   k33 ; k33 = 222
.line	851	loadk        r21   k34 ; k34 = 61
.line	851	loadk        r22   k35 ; k35 = 29
.line	851	loadk        r23   k36 ; k36 = 120
.line	851	loadk        r24   k37 ; k37 = 211
.line	851	loadk        r25   k38 ; k38 = 39
.line	851	loadk        r26   k39 ; k39 = 132
.line	851	loadk        r27   k40 ; k40 = 128
.line	851	loadk        r28   k82 ; k82 = 252
.line	851	loadk        r29   k65 ; k65 = 78
.line	851	loadk        r30   k32 ; k32 = 109
.line	851	loadk        r31  k205 ; k205 = 28
.line	851	loadk        r32  k206 ; k206 = 205
.line	851	loadk        r33  k104 ; k104 = 240
.line	851	loadk        r34   k46 ; k46 = 175
.line	851	loadk        r35  k115 ; k115 = 121
.line	851	loadk        r36  k207 ; k207 = 187
.line	851	loadk        r37  k208 ; k208 = 79
.line	851	loadk        r38  k209 ; k209 = 197
.line	851	loadk        r39  k175 ; k175 = 6
.line	851	loadk        r40  k210 ; k210 = 130
.line	851	loadk        r41  k189 ; k189 = 63
.line	851	loadk        r42  k211 ; k211 = 161
.line	851	loadk        r43   k58 ; k58 = 214
.line	851	loadk        r44  k212 ; k212 = 216
.line	851	loadk        r45  k213 ; k213 = 123
.line	851	loadk        r46  k214 ; k214 = 81
.line	851	loadk        r47  k215 ; k215 = 102
.line	851	loadk        r48  k216 ; k216 = 238
.line	851	loadk        r49  k217 ; k217 = 207
.line	851	loadk        r50  k117 ; k117 = 133
.line	851	loadk        r51  k184 ; k184 = 71
.line	851	loadk        r52  k218 ; k218 = 190
.line	851	loadk        r53  k102 ; k102 = 25
.line	851	loadk        r54  k219 ; k219 = 246
.line	851	loadk        r55  k190 ; k190 = 88
.line	851	loadk        r56  k160 ; k160 = 179
.line	851	loadk        r57  k156 ; k156 = 3
.line	851	call         r17    41     2
.line	851	getupval     r18    u7
.line	851	loadk        r19  k155 ; k155 = 101
.line	851	loadk        r20  k118 ; k118 = 122
.line	851	loadk        r21   k54 ; k54 = 202
.line	851	loadk        r22  k159 ; k159 = 50
.line	851	loadk        r23  k220 ; k220 = 20
.line	851	loadk        r24   k62 ; k62 = 62
.line	851	loadk        r25  k221 ; k221 = 229
.line	851	loadk        r26   k38 ; k38 = 39
.line	851	loadk        r27  k222 ; k222 = 162
.line	851	loadk        r28   k76 ; k76 = 198
.line	851	loadk        r29  k196 ; k196 = 199
.line	851	loadk        r30  k190 ; k190 = 88
.line	851	loadk        r31  k213 ; k213 = 123
.line	851	loadk        r32  k192 ; k192 = 55
.line	851	loadk        r33  k223 ; k223 = 223
.line	851	loadk        r34   k63 ; k63 = 185
.line	851	loadk        r35  k224 ; k224 = 135
.line	851	loadk        r36   k47 ; k47 = 69
.line	851	loadk        r37  k225 ; k225 = 154
.line	851	loadk        r38  k108 ; k108 = 41
.line	851	loadk        r39  k226 ; k226 = 215
.line	851	loadk        r40  k108 ; k108 = 41
.line	851	loadk        r41   k49 ; k49 = 184
.line	851	loadk        r42  k220 ; k220 = 20
.line	851	loadk        r43  k227 ; k227 = 157
.line	851	loadk        r44  k228 ; k228 = 224
.line	851	loadk        r45  k124 ; k124 = 233
.line	851	loadk        r46   k42 ; k42 = 98
.line	851	loadk        r47  k229 ; k229 = 64
.line	851	loadk        r48  k230 ; k230 = 37
.line	851	loadk        r49  k231 ; k231 = 210
.line	851	loadk        r50  k221 ; k221 = 229
.line	851	loadk        r51  k112 ; k112 = 151
.line	851	loadk        r52  k232 ; k232 = 107
.line	851	loadk        r53  k121 ; k121 = 182
.line	851	loadk        r54  k233 ; k233 = 30
.line	851	loadk        r55  k196 ; k196 = 199
.line	851	loadk        r56   k62 ; k62 = 62
.line	851	loadk        r57   k97 ; k97 = 136
.line	851	loadk        r58   k62 ; k62 = 62
.line	851	call         r18    41     2
.line	851	getupval     r19    u7
.line	851	loadk        r20  k155 ; k155 = 101
.line	851	loadk        r21  k215 ; k215 = 102
.line	851	loadk        r22  k113 ; k113 = 208
.line	851	loadk        r23  k123 ; k123 = 49
.line	851	loadk        r24  k205 ; k205 = 28
.line	851	call         r19     6     0
.line	851	setlist      r16     0     1
.line	851	call         r15     2     2
.line	851	call         r12     4     1
.line	851	gettable     r12    r0    k3 ; k3 = "UIRoot"
.line	851	gettable     r12   r12  k146 ; k146 = "TextBlock_13"
.line	851	self         r12   r12  k135 ; k135 = "SetText"
.line	851	gettabup     r14    u1  k143 ; k143 = "LocUtil"
.line	851	gettable     r14   r14  k144 ; k144 = "GetLocalizeResStr"
.line	851	loadk        r15  k147 ; k147 = 8800609
.line	851	call         r14     2     0
.line	851	call         r12     0     1
.line	851	gettable     r12    r0    k3 ; k3 = "UIRoot"
.line	851	gettable     r12   r12  k142 ; k142 = "TextBlock_15"
.line	851	self         r12   r12  k135 ; k135 = "SetText"
.line	851	gettabup     r14    u1  k143 ; k143 = "LocUtil"
.line	851	gettable     r14   r14  k144 ; k144 = "GetLocalizeResStr"
.line	851	loadk        r15  k234 ; k234 = 83212
.line	851	call         r14     2     0
.line	851	call         r12     0     1
.line	851	self         r12    r0    k2 ; k2 = "SetWidgetVisible"
.line	851	gettable     r14    r0    k3 ; k3 = "UIRoot"
.line	851	gettable     r14   r14  k235 ; k235 = "CanvasPanel_SmartSiz" (truncated)
.line	851	loadbool     r15     1     0
.line	851	loadbool     r16     0     0
.line	851	call         r12     5     1
.label	l1000
.line	851	return        r0     1
.line	851	move          r0    r0
.line	851	return        r0     1

.function	main/f47

.source	null
.linedefined	949
.lastlinedefined	968
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	18	true
.upvalue	"U3"	5	true

.constant	k0	"needCalcData"
.constant	k1	"isFitVersion"
.constant	k2	0
.constant	k3	"require"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	89
.constant	k7	70
.constant	k8	214
.constant	k9	53
.constant	k10	22
.constant	k11	35
.constant	k12	168
.constant	k13	25
.constant	k14	175
.constant	k15	218
.constant	k16	200
.constant	k17	41
.constant	k18	94
.constant	k19	54
.constant	k20	204
.constant	k21	255
.constant	k22	169
.constant	k23	52
.constant	k24	171
.constant	k25	15
.constant	k26	9
.constant	k27	154
.constant	k28	178
.constant	k29	219
.constant	k30	151
.constant	k31	113
.constant	k32	75
.constant	k33	61
.constant	k34	149
.constant	k35	234
.constant	k36	181
.constant	k37	109
.constant	k38	182
.constant	k39	19
.constant	k40	199
.constant	k41	17
.constant	k42	143
.constant	k43	62
.constant	k44	108
.constant	k45	79
.constant	k46	205
.constant	k47	56
.constant	k48	232
.constant	k49	167
.constant	k50	192
.constant	k51	222
.constant	k52	105
.constant	k53	202
.constant	k54	242
.constant	k55	"IsFitLobbyResDownloaded"
.constant	k56	"pairs"
.constant	k57	"allItemData"
.constant	k58	"FIT_LOBBY_RES_KEY"
.constant	k59	"isCalculating"
.constant	k60	"cSize"
.constant	k61	"GetPufferDeleteManager"
.constant	k62	"GetSavedCacheSize"
.constant	k63	"MB"

.line	949	gettable      r1    r0    k0 ; k0 = "needCalcData"
.line	949	test          r1     1
.line	949	jmp            0    l7
.line	949	gettable      r1    r0    k1 ; k1 = "isFitVersion"
.line	949	test          r1     1
.line	949	jmp            0    l9
.label	l7
.line	949	loadk         r1    k2 ; k2 = 0
.line	949	return        r1     2
.label	l9
.line	949	gettabup      r1    u0    k3 ; k3 = "require"
.line	949	gettabup      r2    u0    k4 ; k4 = "table"
.line	949	gettable      r2    r2    k5 ; k5 = "concat"
.line	949	newtable      r3     1     0
.line	949	getupval      r4    u1
.line	949	loadk         r5    k6 ; k6 = 89
.line	949	loadk         r6    k7 ; k7 = 70
.line	949	loadk         r7    k8 ; k8 = 214
.line	949	loadk         r8    k9 ; k9 = 53
.line	949	loadk         r9   k10 ; k10 = 22
.line	949	loadk        r10   k11 ; k11 = 35
.line	949	loadk        r11   k12 ; k12 = 168
.line	949	loadk        r12   k13 ; k13 = 25
.line	949	loadk        r13   k14 ; k14 = 175
.line	949	loadk        r14   k15 ; k15 = 218
.line	949	loadk        r15   k16 ; k16 = 200
.line	949	loadk        r16   k17 ; k17 = 41
.line	949	loadk        r17   k18 ; k18 = 94
.line	949	loadk        r18   k19 ; k19 = 54
.line	949	loadk        r19   k20 ; k20 = 204
.line	949	loadk        r20   k21 ; k21 = 255
.line	949	loadk        r21   k22 ; k22 = 169
.line	949	loadk        r22   k23 ; k23 = 52
.line	949	loadk        r23   k24 ; k24 = 171
.line	949	loadk        r24   k25 ; k25 = 15
.line	949	loadk        r25   k21 ; k21 = 255
.line	949	loadk        r26   k26 ; k26 = 9
.line	949	loadk        r27   k27 ; k27 = 154
.line	949	loadk        r28    k9 ; k9 = 53
.line	949	loadk        r29   k28 ; k28 = 178
.line	949	loadk        r30   k29 ; k29 = 219
.line	949	loadk        r31   k30 ; k30 = 151
.line	949	loadk        r32   k31 ; k31 = 113
.line	949	loadk        r33   k32 ; k32 = 75
.line	949	loadk        r34   k33 ; k33 = 61
.line	949	loadk        r35   k34 ; k34 = 149
.line	949	loadk        r36   k35 ; k35 = 234
.line	949	loadk        r37   k36 ; k36 = 181
.line	949	loadk        r38   k37 ; k37 = 109
.line	949	loadk        r39   k38 ; k38 = 182
.line	949	loadk        r40   k39 ; k39 = 19
.line	949	loadk        r41   k40 ; k40 = 199
.line	949	loadk        r42   k41 ; k41 = 17
.line	949	loadk        r43   k42 ; k42 = 143
.line	949	loadk        r44   k43 ; k43 = 62
.line	949	call          r4    41     2
.line	949	getupval      r5    u1
.line	949	loadk         r6   k44 ; k44 = 108
.line	949	loadk         r7   k45 ; k45 = 79
.line	949	loadk         r8   k46 ; k46 = 205
.line	949	loadk         r9   k11 ; k11 = 35
.line	949	loadk        r10   k41 ; k41 = 17
.line	949	loadk        r11   k47 ; k47 = 56
.line	949	loadk        r12   k48 ; k48 = 232
.line	949	loadk        r13    k9 ; k9 = 53
.line	949	loadk        r14   k49 ; k49 = 167
.line	949	loadk        r15   k50 ; k50 = 192
.line	949	loadk        r16   k51 ; k51 = 222
.line	949	loadk        r17   k52 ; k52 = 105
.line	949	loadk        r18   k18 ; k18 = 94
.line	949	loadk        r19   k19 ; k19 = 54
.line	949	loadk        r20   k53 ; k53 = 202
.line	949	loadk        r21   k54 ; k54 = 242
.line	949	call          r5    17     0
.line	949	setlist       r3     0     1
.line	949	call          r2     2     2
.line	949	call          r1     2     2
.line	949	gettable      r2    r1   k55 ; k55 = "IsFitLobbyResDownloa" (truncated)
.line	949	call          r2     1     2
.line	949	loadk         r3    k2 ; k2 = 0
.line	949	gettabup      r4    u0   k56 ; k56 = "pairs"
.line	949	gettable      r5    r0   k57 ; k57 = "allItemData"
.line	949	test          r5     1
.line	949	jmp            0   l84
.line	949	newtable      r5     0     0
.label	l84
.line	949	call          r4     2     4
.line	949	jmp            0  l107
.line	949	gettabup      r9    u2    r7
.line	949	test          r9     1
.line	949	jmp            0  l107
.line	949	test          r2     0
.line	949	jmp            0   l94
.line	949	gettabup      r9    u3   k58 ; k58 = "FIT_LOBBY_RES_KEY"
.line	949	eq             1    r7    r9
.line	949	jmp            0  l107
.label	l94
.line	949	gettable      r9    r8   k59 ; k59 = "isCalculating"
.line	949	test          r9     0
.line	949	jmp            0   l99
.line	949	loadk         r9    k2 ; k2 = 0
.line	949	return        r9     2
.label	l99
.line	949	gettable      r9    r8   k60 ; k60 = "cSize"
.line	949	test          r9     0
.line	949	jmp            0  l107
.line	949	gettable      r9    r8   k60 ; k60 = "cSize"
.line	949	lt             0    k2    r9 ; k2 = 0
.line	949	jmp            0  l107
.line	949	gettable      r9    r8   k60 ; k60 = "cSize"
.line	949	add           r3    r3    r9
.label	l107
.line	949	move          r0    r0
.line	949	move          r0    r0
.line	949	self          r4    r0   k61 ; k61 = "GetPufferDeleteManag" (truncated)
.line	949	call          r4     2     2
.line	949	gettable      r5    r4   k62 ; k62 = "GetSavedCacheSize"
.line	949	call          r5     1     2
.line	949	gettabup      r6    u3   k63 ; k63 = "MB"
.line	949	div           r5    r5    r6
.line	949	add           r5    r3    r5
.line	949	return        r5     2
.line	949	return        r0     1
.line	949	move          r0    r0
.line	949	move          r0    r0
.line	949	move          r0    r0
.line	949	move          r0    r0
.line	949	return        r0     1

.function	main/f48

.source	null
.linedefined	970
.lastlinedefined	989
.numparams	1
.is_vararg	0
.maxstacksize	11

.upvalue	"_ENV"	1	true
.upvalue	"U1"	0	false

.constant	k0	"isFitVersion"
.constant	k1	"LocUtil"
.constant	k2	"GetLocalizeResStr"
.constant	k3	11685
.constant	k4	"GetPufferDeleteManager"
.constant	k5	"GetGameSize"
.constant	k6	1000
.constant	k7	"string"
.constant	k8	"format"
.constant	k9	31
.constant	k10	4
.constant	k11	141
.constant	k12	54
.constant	k13	"LocalizeResFormat"
.constant	k14	83203
.constant	k15	83202
.constant	k16	"UIRoot"
.constant	k17	"TextBlock_18"
.constant	k18	"SetText"
.constant	k19	"TextBlock_23"

.line	970	getupval      r1    u0
.line	970	call          r1     1     2
.line	970	gettable      r2    r0    k0 ; k0 = "isFitVersion"
.line	970	test          r2     0
.line	970	jmp            0   l12
.line	970	gettabup      r2    u1    k1 ; k1 = "LocUtil"
.line	970	gettable      r2    r2    k2 ; k2 = "GetLocalizeResStr"
.line	970	loadk         r3    k3 ; k3 = 11685
.line	970	call          r2     2     2
.line	970	move          r1    r2
.line	970	jmp            0   l56
.label	l12
.line	970	self          r2    r0    k4 ; k4 = "GetPufferDeleteManag" (truncated)
.line	970	call          r2     2     2
.line	970	gettable      r3    r2    k5 ; k5 = "GetGameSize"
.line	970	call          r3     1     2
.line	970	getupval      r4    u0
.line	970	call          r4     1     2
.line	970	le             0    k6    r3 ; k6 = 1000
.line	970	jmp            0   l39
.line	970	div           r3    r3    k6 ; k6 = 1000
.line	970	gettabup      r5    u1    k7 ; k7 = "string"
.line	970	gettable      r5    r5    k8 ; k8 = "format"
.line	970	getupval      r6    u0
.line	970	loadk         r7    k9 ; k9 = 31
.line	970	loadk         r8   k10 ; k10 = 4
.line	970	loadk         r9   k11 ; k11 = 141
.line	970	loadk        r10   k12 ; k12 = 54
.line	970	call          r6     5     2
.line	970	move          r7    r3
.line	970	call          r5     3     2
.line	970	move          r4    r5
.line	970	gettabup      r5    u1    k1 ; k1 = "LocUtil"
.line	970	gettable      r5    r5   k13 ; k13 = "LocalizeResFormat"
.line	970	loadk         r6   k14 ; k14 = 83203
.line	970	move          r7    r4
.line	970	call          r5     3     2
.line	970	move          r1    r5
.line	970	jmp            0   l56
.label	l39
.line	970	gettabup      r5    u1    k7 ; k7 = "string"
.line	970	gettable      r5    r5    k8 ; k8 = "format"
.line	970	getupval      r6    u0
.line	970	loadk         r7    k9 ; k9 = 31
.line	970	loadk         r8   k10 ; k10 = 4
.line	970	loadk         r9   k11 ; k11 = 141
.line	970	loadk        r10   k12 ; k12 = 54
.line	970	call          r6     5     2
.line	970	move          r7    r3
.line	970	call          r5     3     2
.line	970	move          r4    r5
.line	970	gettabup      r5    u1    k1 ; k1 = "LocUtil"
.line	970	gettable      r5    r5   k13 ; k13 = "LocalizeResFormat"
.line	970	loadk         r6   k15 ; k15 = 83202
.line	970	move          r7    r4
.line	970	call          r5     3     2
.line	970	move          r1    r5
.label	l56
.line	970	gettable      r2    r0   k16 ; k16 = "UIRoot"
.line	970	gettable      r2    r2   k17 ; k17 = "TextBlock_18"
.line	970	self          r2    r2   k18 ; k18 = "SetText"
.line	970	move          r4    r1
.line	970	call          r2     3     1
.line	970	gettable      r2    r0   k16 ; k16 = "UIRoot"
.line	970	gettable      r2    r2   k19 ; k19 = "TextBlock_23"
.line	970	self          r2    r2   k18 ; k18 = "SetText"
.line	970	move          r4    r1
.line	970	call          r2     3     1
.line	970	return        r0     1
.line	970	move          r0    r0
.line	970	return        r0     1

.function	main/f49

.source	null
.linedefined	991
.lastlinedefined	1038
.numparams	1
.is_vararg	0
.maxstacksize	27

.upvalue	"_ENV"	5	true
.upvalue	"U1"	0	false
.upvalue	"U2"	15	true
.upvalue	"U3"	9	true
.upvalue	"U4"	1	true

.constant	k0	"Enum_BundleID"
.constant	k1	"Recommend"
.constant	k2	"PufferDownloader"
.constant	k3	"DownloadRewardCfg"
.constant	k4	"is_got"
.constant	k5	true
.constant	k6	"SetWidgetVisible"
.constant	k7	"UIRoot"
.constant	k8	"CanvasPanel_31"
.constant	k9	"CanvasPanel_24"
.constant	k10	"IsRecommendPage"
.constant	k11	"TextBlock_139"
.constant	k12	"Button_6"
.constant	k13	"bundleData"
.constant	k14	1
.constant	k15	"AutoDownloadCfg"
.constant	k16	"RecommendType"
.constant	k17	0
.constant	k18	"ipairs"
.constant	k19	"isCalculating"
.constant	k20	"cSize"
.constant	k21	"tSize"
.constant	k22	"IsViewMode"
.constant	k23	"showPrefetchReddot"
.constant	k24	"RecommendReddot"
.constant	k25	"Reddot_Anchor_Item01"
.constant	k26	"Image_29"
.constant	k27	"GetDynamicMaterial"
.constant	k28	"SetScalarParameterValue"
.constant	k29	119
.constant	k30	75
.constant	k31	204
.constant	k32	59
.constant	k33	39
.constant	k34	7
.constant	k35	227
.constant	k36	24
.constant	k37	160
.constant	k38	202
.constant	k39	199
.constant	k40	115
.constant	k41	"isFitVersion"
.constant	k42	"recommendTabIndex"
.constant	k43	"SetRenderTranslation"
.constant	k44	"FVector2D"
.constant	k45	70

.line	991	gettabup      r1    u0    k0 ; k0 = "Enum_BundleID"
.line	991	gettable      r1    r1    k1 ; k1 = "Recommend"
.line	991	gettabup      r2    u1    k2 ; k2 = "PufferDownloader"
.line	991	gettable      r2    r2    k3 ; k3 = "DownloadRewardCfg"
.line	991	gettable      r2    r2    r1
.line	991	loadbool      r3     1     0
.line	991	test          r2     0
.line	991	jmp            0   l12
.line	991	gettable      r4    r2    k4 ; k4 = "is_got"
.line	991	eq             0    r4    k5 ; k5 = true
.line	991	jmp            0   l13
.label	l12
.line	991	loadbool      r3     0     0
.label	l13
.line	991	self          r4    r0    k6 ; k6 = "SetWidgetVisible"
.line	991	gettable      r6    r0    k7 ; k7 = "UIRoot"
.line	991	gettable      r6    r6    k8 ; k8 = "CanvasPanel_31"
.line	991	move          r7    r3
.line	991	call          r4     4     1
.line	991	self          r4    r0    k6 ; k6 = "SetWidgetVisible"
.line	991	gettable      r6    r0    k7 ; k7 = "UIRoot"
.line	991	gettable      r6    r6    k9 ; k9 = "CanvasPanel_24"
.line	991	testset       r7    r3     0
.line	991	jmp            0   l25
.line	991	self          r7    r0   k10 ; k10 = "IsRecommendPage"
.line	991	call          r7     2     2
.label	l25
.line	991	call          r4     4     1
.line	991	self          r4    r0    k6 ; k6 = "SetWidgetVisible"
.line	991	gettable      r6    r0    k7 ; k7 = "UIRoot"
.line	991	gettable      r6    r6   k11 ; k11 = "TextBlock_139"
.line	991	testset       r7    r3     0
.line	991	jmp            0   l33
.line	991	self          r7    r0   k10 ; k10 = "IsRecommendPage"
.line	991	call          r7     2     2
.label	l33
.line	991	call          r4     4     1
.line	991	self          r4    r0    k6 ; k6 = "SetWidgetVisible"
.line	991	gettable      r6    r0    k7 ; k7 = "UIRoot"
.line	991	gettable      r6    r6   k12 ; k12 = "Button_6"
.line	991	move          r7    r3
.line	991	loadbool      r8     1     0
.line	991	call          r4     5     1
.line	991	test          r3     0
.line	991	jmp            0   l45
.line	991	gettable      r4    r0   k13 ; k13 = "bundleData"
.line	991	test          r4     1
.line	991	jmp            0   l46
.label	l45
.line	991	return        r0     1
.label	l46
.line	991	loadk         r4   k14 ; k14 = 1
.line	991	gettabup      r5    u3   k15 ; k15 = "AutoDownloadCfg"
.line	991	gettable      r5    r5   k16 ; k16 = "RecommendType"
.line	991	gettabup      r5    u2    r5
.line	991	gettable      r6    r0   k13 ; k13 = "bundleData"
.line	991	gettable      r6    r6    r5
.line	991	loadk         r7   k17 ; k17 = 0
.line	991	loadk         r8   k17 ; k17 = 0
.line	991	loadbool      r9     0     0
.line	991	test          r6     0
.line	991	jmp            0   l73
.line	991	gettabup     r10    u1   k18 ; k18 = "ipairs"
.line	991	move         r11    r6
.line	991	call         r10     2     4
.line	991	jmp            0   l71
.line	991	gettable     r15   r14   k19 ; k19 = "isCalculating"
.line	991	test         r15     0
.line	991	jmp            0   l67
.line	991	loadbool      r9     1     0
.line	991	jmp            0   l73
.line	991	jmp            0   l71
.label	l67
.line	991	gettable     r15   r14   k20 ; k20 = "cSize"
.line	991	add           r7    r7   r15
.line	991	gettable     r15   r14   k21 ; k21 = "tSize"
.line	991	add           r8    r8   r15
.label	l71
.line	991	move          r0    r0
.line	991	move          r0    r0
.label	l73
.line	991	lt             0   k17    r8 ; k17 = 0
.line	991	jmp            0   l78
.line	991	test          r9     1
.line	991	jmp            0   l78
.line	991	div           r4    r7    r8
.label	l78
.line	991	lt             0    r4   k14 ; k14 = 1
.line	991	jmp            0   l83
.line	991	self         r10    r0   k22 ; k22 = "IsViewMode"
.line	991	call         r10     2     2
.line	991	jmp            0   l85
.label	l83
.line	991	loadbool     r10     0     1
.line	991	loadbool     r10     1     0
.label	l85
.line	991	self         r11    r0    k6 ; k6 = "SetWidgetVisible"
.line	991	gettable     r13    r0    k7 ; k7 = "UIRoot"
.line	991	gettable     r13   r13    k8 ; k8 = "CanvasPanel_31"
.line	991	move         r14   r10
.line	991	call         r11     4     1
.line	991	gettabup     r11    u1    k2 ; k2 = "PufferDownloader"
.line	991	gettable     r11   r11   k24 ; k24 = "RecommendReddot"
.line	991	settable      r0   k23   r11 ; k23 = "showPrefetchReddot"
.line	991	self         r11    r0    k6 ; k6 = "SetWidgetVisible"
.line	991	gettable     r13    r0    k7 ; k7 = "UIRoot"
.line	991	gettable     r13   r13   k25 ; k25 = "Reddot_Anchor_Item01"
.line	991	gettabup     r14    u1    k2 ; k2 = "PufferDownloader"
.line	991	gettable     r14   r14   k24 ; k24 = "RecommendReddot"
.line	991	call         r11     4     1
.line	991	test         r10     0
.line	991	jmp            0  l139
.line	991	gettable     r11    r0    k7 ; k7 = "UIRoot"
.line	991	gettable     r11   r11   k26 ; k26 = "Image_29"
.line	991	self         r11   r11   k27 ; k27 = "GetDynamicMaterial"
.line	991	call         r11     2     2
.line	991	test         r11     0
.line	991	jmp            0  l124
.line	991	self         r12   r11   k28 ; k28 = "SetScalarParameterVa" (truncated)
.line	991	getupval     r14    u4
.line	991	loadk        r15   k29 ; k29 = 119
.line	991	loadk        r16   k30 ; k30 = 75
.line	991	loadk        r17   k31 ; k31 = 204
.line	991	loadk        r18   k32 ; k32 = 59
.line	991	loadk        r19   k33 ; k33 = 39
.line	991	loadk        r20   k34 ; k34 = 7
.line	991	loadk        r21   k35 ; k35 = 227
.line	991	loadk        r22   k36 ; k36 = 24
.line	991	loadk        r23   k37 ; k37 = 160
.line	991	loadk        r24   k38 ; k38 = 202
.line	991	loadk        r25   k39 ; k39 = 199
.line	991	loadk        r26   k40 ; k40 = 115
.line	991	call         r14    13     2
.line	991	sub          r15   k14    r4 ; k14 = 1
.line	991	call         r12     4     1
.label	l124
.line	991	gettable     r12    r0   k41 ; k41 = "isFitVersion"
.line	991	test         r12     0
.line	991	jmp            0  l139
.line	991	gettable     r12    r0   k42 ; k42 = "recommendTabIndex"
.line	991	test         r12     0
.line	991	jmp            0  l139
.line	991	gettable     r12    r0    k7 ; k7 = "UIRoot"
.line	991	gettable     r12   r12    k8 ; k8 = "CanvasPanel_31"
.line	991	self         r12   r12   k43 ; k43 = "SetRenderTranslation"
.line	991	gettabup     r14    u1   k44 ; k44 = "FVector2D"
.line	991	loadk        r15   k17 ; k17 = 0
.line	991	gettable     r16    r0   k42 ; k42 = "recommendTabIndex"
.line	991	mul          r16   r16   k45 ; k45 = 70
.line	991	call         r14     3     0
.line	991	call         r12     0     1
.label	l139
.line	991	return        r0     1
.line	991	move          r0    r0
.line	991	move          r0    r0
.line	991	return        r0     1

.function	main/f50

.source	null
.linedefined	1040
.lastlinedefined	1127
.numparams	1
.is_vararg	0
.maxstacksize	62

.upvalue	"_ENV"	0	false
.upvalue	"U1"	9	true
.upvalue	"U2"	13	true
.upvalue	"U3"	5	true
.upvalue	"U4"	1	true
.upvalue	"U5"	14	true
.upvalue	"U6"	6	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"CommonModuleConfig"
.constant	k3	"puffer_prefetch_manager"
.constant	k4	"GetPrefetchSwitch"
.constant	k5	"HasNewResources"
.constant	k6	"Not"
.constant	k7	"GetState"
.constant	k8	"PufferDownloader"
.constant	k9	"DownloadRewardCfg"
.constant	k10	"PREFETCH_BUNDLE_ID"
.constant	k11	"is_got"
.constant	k12	"GetReserveState"
.constant	k13	"ENUM_ReserveState"
.constant	k14	"CanDownload"
.constant	k15	"log"
.constant	k16	"bWriteLog"
.constant	k17	"string"
.constant	k18	"format"
.constant	k19	"table"
.constant	k20	"concat"
.constant	k21	126
.constant	k22	69
.constant	k23	200
.constant	k24	62
.constant	k25	20
.constant	k26	56
.constant	k27	231
.constant	k28	14
.constant	k29	156
.constant	k30	226
.constant	k31	110
.constant	k32	92
.constant	k33	6
.constant	k34	254
.constant	k35	223
.constant	k36	136
.constant	k37	74
.constant	k38	245
.constant	k39	53
.constant	k40	248
.constant	k41	3
.constant	k42	151
.constant	k43	46
.constant	k44	182
.constant	k45	237
.constant	k46	220
.constant	k47	97
.constant	k48	71
.constant	k49	59
.constant	k50	227
.constant	k51	158
.constant	k52	101
.constant	k53	168
.constant	k54	30
.constant	k55	244
.constant	k56	24
.constant	k57	135
.constant	k58	115
.constant	k59	68
.constant	k60	217
.constant	k61	63
.constant	k62	86
.constant	k63	119
.constant	k64	232
.constant	k65	15
.constant	k66	180
.constant	k67	249
.constant	k68	204
.constant	k69	117
.constant	k70	124
.constant	k71	216
.constant	k72	186
.constant	k73	174
.constant	k74	184
.constant	k75	228
.constant	k76	8
.constant	k77	128
.constant	k78	203
.constant	k79	99
.constant	k80	116
.constant	k81	246
.constant	k82	172
.constant	k83	34
.constant	k84	253
.constant	k85	0
.constant	k86	94
.constant	k87	109
.constant	k88	208
.constant	k89	36
.constant	k90	114
.constant	k91	70
.constant	k92	160
.constant	k93	206
.constant	k94	199
.constant	k95	64
.constant	k96	87
.constant	k97	45
.constant	k98	243
.constant	k99	189
.constant	k100	123
.constant	k101	4
.constant	k102	181
.constant	k103	66
.constant	k104	133
.constant	k105	"tostring"
.constant	k106	"Done"
.constant	k107	2
.constant	k108	"AutoDownloadPrefetchSwitch"
.constant	k109	21
.constant	k110	222
.constant	k111	61
.constant	k112	29
.constant	k113	120
.constant	k114	211
.constant	k115	39
.constant	k116	132
.constant	k117	98
.constant	k118	175
.constant	k119	80
.constant	k120	72
.constant	k121	183
.constant	k122	191
.constant	k123	202
.constant	k124	38
.constant	k125	214
.constant	k126	235
.constant	k127	100
.constant	k128	185
.constant	k129	11
.constant	k130	78
.constant	k131	35
.constant	k132	17
.constant	k133	218
.constant	k134	40
.constant	k135	113
.constant	k136	54
.constant	k137	198
.constant	k138	251
.constant	k139	165
.constant	k140	144
.constant	k141	252
.constant	k142	9
.constant	k143	169
.constant	k144	22
.constant	k145	141
.constant	k146	230
.constant	k147	95
.constant	k148	32
.constant	k149	122
.constant	k150	177
.constant	k151	23
.constant	k152	52
.constant	k153	137
.constant	k154	209
.constant	k155	58
.constant	k156	143
.constant	k157	155
.constant	k158	88
.constant	k159	44
.constant	k160	194
.constant	k161	229
.constant	k162	239
.constant	k163	"Pause"
.constant	k164	1
.constant	k165	"Download"
.constant	k166	138
.constant	k167	176
.constant	k168	234
.constant	k169	18
.constant	k170	149
.constant	k171	57
.constant	k172	224
.constant	k173	48
.constant	k174	41
.constant	k175	196
.constant	k176	104
.constant	k177	233
.constant	k178	164
.constant	k179	131
.constant	k180	190
.constant	k181	47
.constant	k182	121
.constant	k183	50
.constant	k184	150
.constant	k185	93
.constant	k186	"SetTexture"
.constant	k187	"UIRoot"
.constant	k188	"Image_5"
.constant	k189	0.5
.constant	k190	"SetWidgetVisible"
.constant	k191	"ProgressBar_Download"
.constant	k192	"Reddot_Anchor_Item03"
.constant	k193	"Reddot_Anchor_Item05"
.constant	k194	"CanvasPanel_FX"
.constant	k195	"WidgetSwitcher_3"
.constant	k196	"SetActiveWidgetIndex"
.constant	k197	"GetCommonDownloadHandler"
.constant	k198	"UpdateCommonDownloadStateUI"
.constant	k199	"Common_Download_StateUI_7"
.constant	k200	"hideRoundBg"
.constant	k201	true
.constant	k202	"UpdateCommonDownloadStateUIIconColor"
.constant	k203	"FLinearColor"
.constant	k204	0.7
.constant	k205	"LocUtil"
.constant	k206	"GetLocalizeResStr"
.constant	k207	83616
.constant	k208	"GetSize"
.constant	k209	"GetDownloadSize"
.constant	k210	"PREFETCH"
.constant	k211	"GetFormatSizeContent"
.constant	k212	"CanvasPanel_ReverseSize"
.constant	k213	"TextBlock_105"
.constant	k214	"SetText"
.constant	k215	"TextBlock_103"
.constant	k216	"SetOpacity"
.constant	k217	"SetPercent"
.constant	k218	"Border_NewVersion"
.constant	k219	"canGetReverserReward"

.line	1040	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	1040	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	1040	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	1040	gettable      r2    r2    k2 ; k2 = "CommonModuleConfig"
.line	1040	gettable      r2    r2    k3 ; k3 = "puffer_prefetch_mana" (truncated)
.line	1040	call          r1     2     2
.line	1040	gettabup      r2    u1    k4 ; k4 = "GetPrefetchSwitch"
.line	1040	call          r2     1     2
.line	1040	self          r3    r1    k5 ; k5 = "HasNewResources"
.line	1040	call          r3     2     2
.line	1040	testset       r4    r2     0
.line	1040	jmp            0   l14
.line	1040	move          r4    r3
.label	l14
.line	1040	gettabup      r5    u2    k6 ; k6 = "Not"
.line	1040	loadbool      r6     0     0
.line	1040	loadbool      r7     0     0
.line	1040	move          r8    r4
.line	1040	test          r4     0
.line	1040	jmp            0   l23
.line	1040	self          r9    r1    k7 ; k7 = "GetState"
.line	1040	call          r9     2     2
.line	1040	move          r5    r9
.label	l23
.line	1040	gettabup      r9    u0    k8 ; k8 = "PufferDownloader"
.line	1040	gettable      r9    r9    k9 ; k9 = "DownloadRewardCfg"
.line	1040	gettabup     r10    u3   k10 ; k10 = "PREFETCH_BUNDLE_ID"
.line	1040	gettable      r9    r9   r10
.line	1040	testset      r10    r9     0
.line	1040	jmp            0   l30
.line	1040	gettable     r10    r9   k11 ; k11 = "is_got"
.label	l30
.line	1040	testset      r11    r9     0
.line	1040	jmp            0   l43
.line	1040	gettable     r11    r9   k11 ; k11 = "is_got"
.line	1040	test         r11     1
.line	1040	jmp            0   l41
.line	1040	self         r11    r1   k12 ; k12 = "GetReserveState"
.line	1040	call         r11     2     2
.line	1040	gettabup     r12    u3   k13 ; k13 = "ENUM_ReserveState"
.line	1040	gettable     r12   r12   k14 ; k14 = "CanDownload"
.line	1040	eq             1   r11   r12
.line	1040	jmp            0   l42
.label	l41
.line	1040	loadbool     r11     0     1
.label	l42
.line	1040	loadbool     r11     1     0
.label	l43
.line	1040	gettabup     r12    u0   k15 ; k15 = "log"
.line	1040	gettabup     r13    u0   k16 ; k16 = "bWriteLog"
.line	1040	test         r13     0
.line	1040	jmp            0  l176
.line	1040	gettabup     r13    u0   k17 ; k17 = "string"
.line	1040	gettable     r13   r13   k18 ; k18 = "format"
.line	1040	gettabup     r14    u0   k19 ; k19 = "table"
.line	1040	gettable     r14   r14   k20 ; k20 = "concat"
.line	1040	newtable     r15     2     0
.line	1040	getupval     r16    u4
.line	1040	loadk        r17   k21 ; k21 = 126
.line	1040	loadk        r18   k22 ; k22 = 69
.line	1040	loadk        r19   k23 ; k23 = 200
.line	1040	loadk        r20   k24 ; k24 = 62
.line	1040	loadk        r21   k25 ; k25 = 20
.line	1040	loadk        r22   k26 ; k26 = 56
.line	1040	loadk        r23   k27 ; k27 = 231
.line	1040	loadk        r24   k28 ; k28 = 14
.line	1040	loadk        r25   k29 ; k29 = 156
.line	1040	loadk        r26   k30 ; k30 = 226
.line	1040	loadk        r27   k23 ; k23 = 200
.line	1040	loadk        r28   k31 ; k31 = 110
.line	1040	loadk        r29   k32 ; k32 = 92
.line	1040	loadk        r30   k33 ; k33 = 6
.line	1040	loadk        r31   k34 ; k34 = 254
.line	1040	loadk        r32   k35 ; k35 = 223
.line	1040	loadk        r33   k36 ; k36 = 136
.line	1040	loadk        r34   k37 ; k37 = 74
.line	1040	loadk        r35   k38 ; k38 = 245
.line	1040	loadk        r36   k39 ; k39 = 53
.line	1040	loadk        r37   k40 ; k40 = 248
.line	1040	loadk        r38   k41 ; k41 = 3
.line	1040	loadk        r39   k42 ; k42 = 151
.line	1040	loadk        r40   k43 ; k43 = 46
.line	1040	loadk        r41   k44 ; k44 = 182
.line	1040	loadk        r42   k45 ; k45 = 237
.line	1040	loadk        r43   k46 ; k46 = 220
.line	1040	loadk        r44   k47 ; k47 = 97
.line	1040	loadk        r45   k48 ; k48 = 71
.line	1040	loadk        r46   k49 ; k49 = 59
.line	1040	loadk        r47   k23 ; k23 = 200
.line	1040	loadk        r48   k50 ; k50 = 227
.line	1040	loadk        r49   k51 ; k51 = 158
.line	1040	loadk        r50   k52 ; k52 = 101
.line	1040	loadk        r51   k53 ; k53 = 168
.line	1040	loadk        r52   k54 ; k54 = 30
.line	1040	loadk        r53   k55 ; k55 = 244
.line	1040	loadk        r54   k56 ; k56 = 24
.line	1040	loadk        r55   k57 ; k57 = 135
.line	1040	loadk        r56   k43 ; k43 = 46
.line	1040	call         r16    41     2
.line	1040	getupval     r17    u4
.line	1040	loadk        r18   k58 ; k58 = 115
.line	1040	loadk        r19   k59 ; k59 = 68
.line	1040	loadk        r20   k60 ; k60 = 217
.line	1040	loadk        r21   k61 ; k61 = 63
.line	1040	loadk        r22   k62 ; k62 = 86
.line	1040	loadk        r23   k63 ; k63 = 119
.line	1040	loadk        r24   k64 ; k64 = 232
.line	1040	loadk        r25   k65 ; k65 = 15
.line	1040	loadk        r26   k66 ; k66 = 180
.line	1040	loadk        r27   k67 ; k67 = 249
.line	1040	loadk        r28   k68 ; k68 = 204
.line	1040	loadk        r29   k69 ; k69 = 117
.line	1040	loadk        r30   k65 ; k65 = 15
.line	1040	loadk        r31   k70 ; k70 = 124
.line	1040	loadk        r32   k71 ; k71 = 216
.line	1040	loadk        r33   k72 ; k72 = 186
.line	1040	loadk        r34   k73 ; k73 = 174
.line	1040	loadk        r35   k69 ; k69 = 117
.line	1040	loadk        r36   k74 ; k74 = 184
.line	1040	loadk        r37   k28 ; k28 = 14
.line	1040	loadk        r38   k75 ; k75 = 228
.line	1040	loadk        r39   k76 ; k76 = 8
.line	1040	loadk        r40   k42 ; k42 = 151
.line	1040	loadk        r41   k24 ; k24 = 62
.line	1040	loadk        r42   k77 ; k77 = 128
.line	1040	loadk        r43   k78 ; k78 = 203
.line	1040	loadk        r44   k71 ; k71 = 216
.line	1040	loadk        r45   k79 ; k79 = 99
.line	1040	loadk        r46   k48 ; k48 = 71
.line	1040	loadk        r47   k80 ; k80 = 116
.line	1040	loadk        r48   k51 ; k51 = 158
.line	1040	loadk        r49   k38 ; k38 = 245
.line	1040	loadk        r50   k81 ; k81 = 246
.line	1040	loadk        r51   k79 ; k79 = 99
.line	1040	loadk        r52   k82 ; k82 = 172
.line	1040	loadk        r53   k83 ; k83 = 34
.line	1040	loadk        r54   k84 ; k84 = 253
.line	1040	loadk        r55   k85 ; k85 = 0
.line	1040	loadk        r56   k57 ; k57 = 135
.line	1040	loadk        r57   k26 ; k26 = 56
.line	1040	call         r17    41     2
.line	1040	getupval     r18    u4
.line	1040	loadk        r19   k86 ; k86 = 94
.line	1040	loadk        r20   k87 ; k87 = 109
.line	1040	loadk        r21   k88 ; k88 = 208
.line	1040	loadk        r22   k89 ; k89 = 36
.line	1040	loadk        r23   k22 ; k22 = 69
.line	1040	loadk        r24   k90 ; k90 = 114
.line	1040	loadk        r25   k38 ; k38 = 245
.line	1040	loadk        r26   k91 ; k91 = 70
.line	1040	loadk        r27   k92 ; k92 = 160
.line	1040	loadk        r28   k93 ; k93 = 206
.line	1040	loadk        r29   k94 ; k94 = 199
.line	1040	loadk        r30   k95 ; k95 = 64
.line	1040	loadk        r31   k96 ; k96 = 87
.line	1040	loadk        r32   k97 ; k97 = 45
.line	1040	loadk        r33   k67 ; k67 = 249
.line	1040	loadk        r34   k98 ; k98 = 243
.line	1040	loadk        r35   k99 ; k99 = 189
.line	1040	loadk        r36  k100 ; k100 = 123
.line	1040	loadk        r37   k99 ; k99 = 189
.line	1040	loadk        r38  k101 ; k101 = 4
.line	1040	loadk        r39  k102 ; k102 = 181
.line	1040	loadk        r40  k103 ; k103 = 66
.line	1040	loadk        r41  k104 ; k104 = 133
.line	1040	call         r18    24     0
.line	1040	setlist      r15     0     1
.line	1040	call         r14     2     2
.line	1040	gettabup     r15    u0  k105 ; k105 = "tostring"
.line	1040	move         r16    r4
.line	1040	call         r15     2     2
.line	1040	gettabup     r16    u0  k105 ; k105 = "tostring"
.line	1040	move         r17    r5
.line	1040	call         r16     2     2
.line	1040	gettabup     r17    u0  k105 ; k105 = "tostring"
.line	1040	move         r18   r10
.line	1040	call         r17     2     2
.line	1040	gettabup     r18    u0  k105 ; k105 = "tostring"
.line	1040	move         r19   r11
.line	1040	call         r18     2     0
.line	1040	call         r13     0     2
.label	l176
.line	1040	call         r12     2     1
.line	1040	gettabup     r12    u2  k106 ; k106 = "Done"
.line	1040	eq             1    r5   r12
.line	1040	jmp            0  l181
.line	1040	loadbool     r12     0     1
.label	l181
.line	1040	loadbool     r12     1     0
.line	1040	test         r11     0
.line	1040	jmp            0  l187
.line	1040	test         r12     0
.line	1040	jmp            0  l187
.line	1040	loadbool      r7     1     0
.label	l187
.line	1040	loadk        r13  k107 ; k107 = 2
.line	1040	gettabup     r14    u1  k108 ; k108 = "AutoDownloadPrefetch" (truncated)
.line	1040	gettabup     r15    u0   k19 ; k19 = "table"
.line	1040	gettable     r15   r15   k20 ; k20 = "concat"
.line	1040	newtable     r16     2     0
.line	1040	getupval     r17    u4
.line	1040	loadk        r18  k109 ; k109 = 21
.line	1040	loadk        r19   k87 ; k87 = 109
.line	1040	loadk        r20  k110 ; k110 = 222
.line	1040	loadk        r21  k111 ; k111 = 61
.line	1040	loadk        r22  k112 ; k112 = 29
.line	1040	loadk        r23  k113 ; k113 = 120
.line	1040	loadk        r24  k114 ; k114 = 211
.line	1040	loadk        r25  k115 ; k115 = 39
.line	1040	loadk        r26  k116 ; k116 = 132
.line	1040	loadk        r27   k77 ; k77 = 128
.line	1040	loadk        r28   k84 ; k84 = 253
.line	1040	loadk        r29  k117 ; k117 = 98
.line	1040	loadk        r30   k37 ; k37 = 74
.line	1040	loadk        r31   k97 ; k97 = 45
.line	1040	loadk        r32  k110 ; k110 = 222
.line	1040	loadk        r33   k75 ; k75 = 228
.line	1040	loadk        r34  k118 ; k118 = 175
.line	1040	loadk        r35   k22 ; k22 = 69
.line	1040	loadk        r36   k84 ; k84 = 253
.line	1040	loadk        r37  k119 ; k119 = 80
.line	1040	loadk        r38   k74 ; k74 = 184
.line	1040	loadk        r39  k120 ; k120 = 72
.line	1040	loadk        r40  k121 ; k121 = 183
.line	1040	loadk        r41   k43 ; k43 = 46
.line	1040	loadk        r42  k122 ; k122 = 191
.line	1040	loadk        r43  k110 ; k110 = 222
.line	1040	loadk        r44  k123 ; k123 = 202
.line	1040	loadk        r45   k26 ; k26 = 56
.line	1040	loadk        r46   k47 ; k47 = 97
.line	1040	loadk        r47  k124 ; k124 = 38
.line	1040	loadk        r48  k125 ; k125 = 214
.line	1040	loadk        r49  k126 ; k126 = 235
.line	1040	loadk        r50  k102 ; k102 = 181
.line	1040	loadk        r51  k127 ; k127 = 100
.line	1040	loadk        r52   k77 ; k77 = 128
.line	1040	loadk        r53   k24 ; k24 = 62
.line	1040	loadk        r54   k84 ; k84 = 253
.line	1040	loadk        r55   k85 ; k85 = 0
.line	1040	loadk        r56  k128 ; k128 = 185
.line	1040	loadk        r57  k129 ; k129 = 11
.line	1040	call         r17    41     2
.line	1040	getupval     r18    u4
.line	1040	loadk        r19  k130 ; k130 = 78
.line	1040	loadk        r20   k91 ; k91 = 70
.line	1040	loadk        r21  k110 ; k110 = 222
.line	1040	loadk        r22  k131 ; k131 = 35
.line	1040	loadk        r23   k96 ; k96 = 87
.line	1040	loadk        r24  k132 ; k132 = 17
.line	1040	loadk        r25   k55 ; k55 = 244
.line	1040	loadk        r26  k129 ; k129 = 11
.line	1040	loadk        r27   k73 ; k73 = 174
.line	1040	loadk        r28  k123 ; k123 = 202
.line	1040	loadk        r29  k133 ; k133 = 218
.line	1040	loadk        r30  k134 ; k134 = 40
.line	1040	loadk        r31  k135 ; k135 = 113
.line	1040	loadk        r32  k136 ; k136 = 54
.line	1040	loadk        r33  k137 ; k137 = 198
.line	1040	loadk        r34  k138 ; k138 = 251
.line	1040	loadk        r35  k139 ; k139 = 165
.line	1040	loadk        r36   k80 ; k80 = 116
.line	1040	loadk        r37  k140 ; k140 = 144
.line	1040	loadk        r38   k83 ; k83 = 34
.line	1040	loadk        r39  k141 ; k141 = 252
.line	1040	loadk        r40  k142 ; k142 = 9
.line	1040	loadk        r41  k143 ; k143 = 169
.line	1040	loadk        r42  k144 ; k144 = 22
.line	1040	loadk        r43  k139 ; k139 = 165
.line	1040	loadk        r44  k145 ; k145 = 141
.line	1040	loadk        r45  k146 ; k146 = 230
.line	1040	loadk        r46  k147 ; k147 = 95
.line	1040	loadk        r47   k96 ; k96 = 87
.line	1040	loadk        r48  k148 ; k148 = 32
.line	1040	loadk        r49   k23 ; k23 = 200
.line	1040	loadk        r50   k50 ; k50 = 227
.line	1040	loadk        r51  k104 ; k104 = 133
.line	1040	loadk        r52  k149 ; k149 = 122
.line	1040	loadk        r53  k150 ; k150 = 177
.line	1040	loadk        r54  k151 ; k151 = 23
.line	1040	loadk        r55   k44 ; k44 = 182
.line	1040	loadk        r56  k152 ; k152 = 52
.line	1040	loadk        r57  k153 ; k153 = 137
.line	1040	loadk        r58  k115 ; k115 = 39
.line	1040	call         r18    41     2
.line	1040	getupval     r19    u4
.line	1040	loadk        r20   k96 ; k96 = 87
.line	1040	loadk        r21   k22 ; k22 = 69
.line	1040	loadk        r22  k154 ; k154 = 209
.line	1040	loadk        r23   k65 ; k65 = 15
.line	1040	loadk        r24  k155 ; k155 = 58
.line	1040	loadk        r25  k131 ; k131 = 35
.line	1040	loadk        r26   k64 ; k64 = 232
.line	1040	loadk        r27   k39 ; k39 = 53
.line	1040	loadk        r28  k156 ; k156 = 143
.line	1040	loadk        r29   k60 ; k60 = 217
.line	1040	loadk        r30  k157 ; k157 = 155
.line	1040	loadk        r31  k158 ; k158 = 88
.line	1040	loadk        r32  k149 ; k149 = 122
.line	1040	loadk        r33  k159 ; k159 = 44
.line	1040	loadk        r34  k160 ; k160 = 194
.line	1040	loadk        r35  k161 ; k161 = 229
.line	1040	loadk        r36  k118 ; k118 = 175
.line	1040	loadk        r37   k22 ; k22 = 69
.line	1040	loadk        r38  k122 ; k122 = 191
.line	1040	loadk        r39   k28 ; k28 = 14
.line	1040	loadk        r40  k162 ; k162 = 239
.line	1040	call         r19    22     0
.line	1040	setlist      r16     0     1
.line	1040	call         r15     2     2
.line	1040	test         r14     0
.line	1040	jmp            0  l321
.line	1040	test         r12     0
.line	1040	jmp            0  l311
.line	1040	test         r11     0
.line	1040	jmp            0  l309
.line	1040	loadk        r13   k41 ; k41 = 3
.line	1040	jmp            0  l331
.label	l309
.line	1040	loadk        r13  k101 ; k101 = 4
.line	1040	jmp            0  l331
.label	l311
.line	1040	gettabup     r16    u2  k163 ; k163 = "Pause"
.line	1040	eq             0    r5   r16
.line	1040	jmp            0  l316
.line	1040	loadk        r13  k164 ; k164 = 1
.line	1040	jmp            0  l331
.label	l316
.line	1040	gettabup     r16    u2  k165 ; k165 = "Download"
.line	1040	eq             0    r5   r16
.line	1040	jmp            0  l331
.line	1040	loadk        r13   k33 ; k33 = 6
.line	1040	jmp            0  l331
.label	l321
.line	1040	test          r4     0
.line	1040	jmp            0  l331
.line	1040	test         r12     0
.line	1040	jmp            0  l329
.line	1040	test         r11     1
.line	1040	jmp            0  l329
.line	1040	loadk        r13  k101 ; k101 = 4
.line	1040	jmp            0  l330
.label	l329
.line	1040	loadk        r13   k41 ; k41 = 3
.label	l330
.line	1040	not           r6   r12
.label	l331
.line	1040	gettabup     r16    u2  k165 ; k165 = "Download"
.line	1040	eq             0    r5   r16
.line	1040	jmp            0  l469
.line	1040	gettabup     r16    u0   k19 ; k19 = "table"
.line	1040	gettable     r16   r16   k20 ; k20 = "concat"
.line	1040	newtable     r17     3     0
.line	1040	getupval     r18    u4
.line	1040	loadk        r19  k109 ; k109 = 21
.line	1040	loadk        r20   k87 ; k87 = 109
.line	1040	loadk        r21  k110 ; k110 = 222
.line	1040	loadk        r22  k111 ; k111 = 61
.line	1040	loadk        r23  k112 ; k112 = 29
.line	1040	loadk        r24  k113 ; k113 = 120
.line	1040	loadk        r25  k114 ; k114 = 211
.line	1040	loadk        r26  k115 ; k115 = 39
.line	1040	loadk        r27  k116 ; k116 = 132
.line	1040	loadk        r28   k77 ; k77 = 128
.line	1040	loadk        r29   k84 ; k84 = 253
.line	1040	loadk        r30  k117 ; k117 = 98
.line	1040	loadk        r31   k37 ; k37 = 74
.line	1040	loadk        r32   k97 ; k97 = 45
.line	1040	loadk        r33  k110 ; k110 = 222
.line	1040	loadk        r34   k75 ; k75 = 228
.line	1040	loadk        r35  k118 ; k118 = 175
.line	1040	loadk        r36   k22 ; k22 = 69
.line	1040	loadk        r37   k84 ; k84 = 253
.line	1040	loadk        r38  k119 ; k119 = 80
.line	1040	loadk        r39   k74 ; k74 = 184
.line	1040	loadk        r40  k120 ; k120 = 72
.line	1040	loadk        r41  k121 ; k121 = 183
.line	1040	loadk        r42   k43 ; k43 = 46
.line	1040	loadk        r43  k122 ; k122 = 191
.line	1040	loadk        r44  k110 ; k110 = 222
.line	1040	loadk        r45  k123 ; k123 = 202
.line	1040	loadk        r46   k26 ; k26 = 56
.line	1040	loadk        r47   k47 ; k47 = 97
.line	1040	loadk        r48  k124 ; k124 = 38
.line	1040	loadk        r49  k125 ; k125 = 214
.line	1040	loadk        r50  k126 ; k126 = 235
.line	1040	loadk        r51  k102 ; k102 = 181
.line	1040	loadk        r52  k127 ; k127 = 100
.line	1040	loadk        r53   k77 ; k77 = 128
.line	1040	loadk        r54   k24 ; k24 = 62
.line	1040	loadk        r55   k84 ; k84 = 253
.line	1040	loadk        r56   k85 ; k85 = 0
.line	1040	loadk        r57  k128 ; k128 = 185
.line	1040	loadk        r58  k129 ; k129 = 11
.line	1040	call         r18    41     2
.line	1040	getupval     r19    u4
.line	1040	loadk        r20  k130 ; k130 = 78
.line	1040	loadk        r21   k91 ; k91 = 70
.line	1040	loadk        r22  k110 ; k110 = 222
.line	1040	loadk        r23  k131 ; k131 = 35
.line	1040	loadk        r24   k96 ; k96 = 87
.line	1040	loadk        r25  k132 ; k132 = 17
.line	1040	loadk        r26   k55 ; k55 = 244
.line	1040	loadk        r27  k129 ; k129 = 11
.line	1040	loadk        r28   k73 ; k73 = 174
.line	1040	loadk        r29  k123 ; k123 = 202
.line	1040	loadk        r30  k133 ; k133 = 218
.line	1040	loadk        r31  k134 ; k134 = 40
.line	1040	loadk        r32  k135 ; k135 = 113
.line	1040	loadk        r33  k136 ; k136 = 54
.line	1040	loadk        r34  k137 ; k137 = 198
.line	1040	loadk        r35  k138 ; k138 = 251
.line	1040	loadk        r36  k139 ; k139 = 165
.line	1040	loadk        r37   k80 ; k80 = 116
.line	1040	loadk        r38  k140 ; k140 = 144
.line	1040	loadk        r39   k83 ; k83 = 34
.line	1040	loadk        r40  k141 ; k141 = 252
.line	1040	loadk        r41  k142 ; k142 = 9
.line	1040	loadk        r42  k143 ; k143 = 169
.line	1040	loadk        r43  k144 ; k144 = 22
.line	1040	loadk        r44  k139 ; k139 = 165
.line	1040	loadk        r45  k145 ; k145 = 141
.line	1040	loadk        r46  k146 ; k146 = 230
.line	1040	loadk        r47  k147 ; k147 = 95
.line	1040	loadk        r48   k96 ; k96 = 87
.line	1040	loadk        r49  k148 ; k148 = 32
.line	1040	loadk        r50   k23 ; k23 = 200
.line	1040	loadk        r51   k50 ; k50 = 227
.line	1040	loadk        r52  k166 ; k166 = 138
.line	1040	loadk        r53  k113 ; k113 = 120
.line	1040	loadk        r54  k167 ; k167 = 176
.line	1040	loadk        r55  k151 ; k151 = 23
.line	1040	loadk        r56  k168 ; k168 = 234
.line	1040	loadk        r57  k169 ; k169 = 18
.line	1040	loadk        r58  k170 ; k170 = 149
.line	1040	loadk        r59  k171 ; k171 = 57
.line	1040	call         r19    41     2
.line	1040	getupval     r20    u4
.line	1040	loadk        r21  k113 ; k113 = 120
.line	1040	loadk        r22   k87 ; k87 = 109
.line	1040	loadk        r23  k172 ; k172 = 224
.line	1040	loadk        r24  k148 ; k148 = 32
.line	1040	loadk        r25  k144 ; k144 = 22
.line	1040	loadk        r26  k173 ; k173 = 48
.line	1040	loadk        r27   k53 ; k53 = 168
.line	1040	loadk        r28  k174 ; k174 = 41
.line	1040	loadk        r29   k82 ; k82 = 172
.line	1040	loadk        r30  k160 ; k160 = 194
.line	1040	loadk        r31  k175 ; k175 = 196
.line	1040	loadk        r32  k176 ; k176 = 104
.line	1040	loadk        r33   k32 ; k32 = 92
.line	1040	loadk        r34   k33 ; k33 = 6
.line	1040	loadk        r35  k177 ; k177 = 233
.line	1040	loadk        r36   k30 ; k30 = 226
.line	1040	loadk        r37  k178 ; k178 = 164
.line	1040	loadk        r38   k22 ; k22 = 69
.line	1040	loadk        r39  k179 ; k179 = 131
.line	1040	loadk        r40  k144 ; k144 = 22
.line	1040	loadk        r41   k72 ; k72 = 186
.line	1040	loadk        r42   k26 ; k26 = 56
.line	1040	loadk        r43  k180 ; k180 = 190
.line	1040	loadk        r44  k181 ; k181 = 47
.line	1040	loadk        r45   k72 ; k72 = 186
.line	1040	loadk        r46   k68 ; k68 = 204
.line	1040	loadk        r47   k46 ; k46 = 220
.line	1040	loadk        r48   k48 ; k48 = 71
.line	1040	loadk        r49  k119 ; k119 = 80
.line	1040	loadk        r50  k124 ; k124 = 38
.line	1040	loadk        r51   k46 ; k46 = 220
.line	1040	loadk        r52   k55 ; k55 = 244
.line	1040	loadk        r53  k122 ; k122 = 191
.line	1040	loadk        r54  k182 ; k182 = 121
.line	1040	loadk        r55   k82 ; k82 = 172
.line	1040	loadk        r56  k183 ; k183 = 50
.line	1040	loadk        r57   k35 ; k35 = 223
.line	1040	loadk        r58  k134 ; k134 = 40
.line	1040	loadk        r59  k184 ; k184 = 150
.line	1040	loadk        r60   k89 ; k89 = 36
.line	1040	call         r20    41     2
.line	1040	getupval     r21    u4
.line	1040	loadk        r22  k185 ; k185 = 93
.line	1040	call         r21     2     0
.line	1040	setlist      r17     0     1
.line	1040	call         r16     2     2
.line	1040	move         r15   r16
.label	l469
.line	1040	self         r16    r0  k186 ; k186 = "SetTexture"
.line	1040	gettable     r18    r0  k187 ; k187 = "UIRoot"
.line	1040	gettable     r18   r18  k188 ; k188 = "Image_5"
.line	1040	move         r19   r15
.line	1040	call         r16     4     1
.line	1040	gettabup     r16    u0   k19 ; k19 = "table"
.line	1040	gettable     r16   r16   k20 ; k20 = "concat"
.line	1040	newtable     r17     2     0
.line	1040	getupval     r18    u4
.line	1040	loadk        r19  k109 ; k109 = 21
.line	1040	loadk        r20   k87 ; k87 = 109
.line	1040	loadk        r21  k110 ; k110 = 222
.line	1040	loadk        r22  k111 ; k111 = 61
.line	1040	loadk        r23  k112 ; k112 = 29
.line	1040	loadk        r24  k113 ; k113 = 120
.line	1040	loadk        r25  k114 ; k114 = 211
.line	1040	loadk        r26  k115 ; k115 = 39
.line	1040	loadk        r27  k116 ; k116 = 132
.line	1040	loadk        r28   k77 ; k77 = 128
.line	1040	loadk        r29   k84 ; k84 = 253
.line	1040	loadk        r30  k117 ; k117 = 98
.line	1040	loadk        r31   k37 ; k37 = 74
.line	1040	loadk        r32   k97 ; k97 = 45
.line	1040	loadk        r33  k110 ; k110 = 222
.line	1040	loadk        r34   k75 ; k75 = 228
.line	1040	loadk        r35  k118 ; k118 = 175
.line	1040	loadk        r36   k22 ; k22 = 69
.line	1040	loadk        r37   k84 ; k84 = 253
.line	1040	loadk        r38  k119 ; k119 = 80
.line	1040	loadk        r39   k74 ; k74 = 184
.line	1040	loadk        r40  k120 ; k120 = 72
.line	1040	loadk        r41  k121 ; k121 = 183
.line	1040	loadk        r42   k43 ; k43 = 46
.line	1040	loadk        r43  k122 ; k122 = 191
.line	1040	loadk        r44  k110 ; k110 = 222
.line	1040	loadk        r45  k123 ; k123 = 202
.line	1040	loadk        r46   k26 ; k26 = 56
.line	1040	loadk        r47   k47 ; k47 = 97
.line	1040	loadk        r48  k124 ; k124 = 38
.line	1040	loadk        r49  k125 ; k125 = 214
.line	1040	loadk        r50  k126 ; k126 = 235
.line	1040	loadk        r51  k102 ; k102 = 181
.line	1040	loadk        r52  k127 ; k127 = 100
.line	1040	loadk        r53   k77 ; k77 = 128
.line	1040	loadk        r54   k24 ; k24 = 62
.line	1040	loadk        r55   k84 ; k84 = 253
.line	1040	loadk        r56   k85 ; k85 = 0
.line	1040	loadk        r57  k128 ; k128 = 185
.line	1040	loadk        r58  k129 ; k129 = 11
.line	1040	call         r18    41     2
.line	1040	getupval     r19    u4
.line	1040	loadk        r20  k130 ; k130 = 78
.line	1040	loadk        r21   k91 ; k91 = 70
.line	1040	loadk        r22  k110 ; k110 = 222
.line	1040	loadk        r23  k131 ; k131 = 35
.line	1040	loadk        r24   k96 ; k96 = 87
.line	1040	loadk        r25  k132 ; k132 = 17
.line	1040	loadk        r26   k55 ; k55 = 244
.line	1040	loadk        r27  k129 ; k129 = 11
.line	1040	loadk        r28   k73 ; k73 = 174
.line	1040	loadk        r29  k123 ; k123 = 202
.line	1040	loadk        r30  k133 ; k133 = 218
.line	1040	loadk        r31  k134 ; k134 = 40
.line	1040	loadk        r32  k135 ; k135 = 113
.line	1040	loadk        r33  k136 ; k136 = 54
.line	1040	loadk        r34  k137 ; k137 = 198
.line	1040	loadk        r35  k138 ; k138 = 251
.line	1040	loadk        r36  k139 ; k139 = 165
.line	1040	loadk        r37   k80 ; k80 = 116
.line	1040	loadk        r38  k140 ; k140 = 144
.line	1040	loadk        r39   k83 ; k83 = 34
.line	1040	loadk        r40  k141 ; k141 = 252
.line	1040	loadk        r41  k142 ; k142 = 9
.line	1040	loadk        r42  k143 ; k143 = 169
.line	1040	loadk        r43  k144 ; k144 = 22
.line	1040	loadk        r44  k139 ; k139 = 165
.line	1040	loadk        r45  k145 ; k145 = 141
.line	1040	loadk        r46  k146 ; k146 = 230
.line	1040	loadk        r47  k147 ; k147 = 95
.line	1040	loadk        r48   k96 ; k96 = 87
.line	1040	loadk        r49  k148 ; k148 = 32
.line	1040	loadk        r50   k23 ; k23 = 200
.line	1040	loadk        r51   k50 ; k50 = 227
.line	1040	loadk        r52  k104 ; k104 = 133
.line	1040	loadk        r53  k149 ; k149 = 122
.line	1040	loadk        r54  k150 ; k150 = 177
.line	1040	loadk        r55  k151 ; k151 = 23
.line	1040	loadk        r56   k44 ; k44 = 182
.line	1040	loadk        r57  k152 ; k152 = 52
.line	1040	loadk        r58  k153 ; k153 = 137
.line	1040	loadk        r59  k115 ; k115 = 39
.line	1040	call         r19    41     2
.line	1040	getupval     r20    u4
.line	1040	loadk        r21   k96 ; k96 = 87
.line	1040	loadk        r22   k22 ; k22 = 69
.line	1040	loadk        r23  k154 ; k154 = 209
.line	1040	loadk        r24   k65 ; k65 = 15
.line	1040	loadk        r25  k155 ; k155 = 58
.line	1040	loadk        r26  k131 ; k131 = 35
.line	1040	loadk        r27   k64 ; k64 = 232
.line	1040	loadk        r28   k39 ; k39 = 53
.line	1040	loadk        r29  k156 ; k156 = 143
.line	1040	loadk        r30   k60 ; k60 = 217
.line	1040	loadk        r31  k157 ; k157 = 155
.line	1040	loadk        r32  k158 ; k158 = 88
.line	1040	loadk        r33  k149 ; k149 = 122
.line	1040	loadk        r34  k159 ; k159 = 44
.line	1040	loadk        r35  k160 ; k160 = 194
.line	1040	loadk        r36  k161 ; k161 = 229
.line	1040	loadk        r37  k118 ; k118 = 175
.line	1040	loadk        r38   k22 ; k22 = 69
.line	1040	loadk        r39  k122 ; k122 = 191
.line	1040	loadk        r40   k28 ; k28 = 14
.line	1040	loadk        r41  k162 ; k162 = 239
.line	1040	call         r20    22     0
.line	1040	setlist      r17     0     1
.line	1040	call         r16     2     2
.line	1040	loadk        r17  k164 ; k164 = 1
.line	1040	test         r12     0
.line	1040	jmp            0  l703
.line	1040	gettabup     r18    u0   k19 ; k19 = "table"
.line	1040	gettable     r18   r18   k20 ; k20 = "concat"
.line	1040	newtable     r19     2     0
.line	1040	getupval     r20    u4
.line	1040	loadk        r21  k109 ; k109 = 21
.line	1040	loadk        r22   k87 ; k87 = 109
.line	1040	loadk        r23  k110 ; k110 = 222
.line	1040	loadk        r24  k111 ; k111 = 61
.line	1040	loadk        r25  k112 ; k112 = 29
.line	1040	loadk        r26  k113 ; k113 = 120
.line	1040	loadk        r27  k114 ; k114 = 211
.line	1040	loadk        r28  k115 ; k115 = 39
.line	1040	loadk        r29  k116 ; k116 = 132
.line	1040	loadk        r30   k77 ; k77 = 128
.line	1040	loadk        r31   k84 ; k84 = 253
.line	1040	loadk        r32  k117 ; k117 = 98
.line	1040	loadk        r33   k37 ; k37 = 74
.line	1040	loadk        r34   k97 ; k97 = 45
.line	1040	loadk        r35  k110 ; k110 = 222
.line	1040	loadk        r36   k75 ; k75 = 228
.line	1040	loadk        r37  k118 ; k118 = 175
.line	1040	loadk        r38   k22 ; k22 = 69
.line	1040	loadk        r39   k84 ; k84 = 253
.line	1040	loadk        r40  k119 ; k119 = 80
.line	1040	loadk        r41   k74 ; k74 = 184
.line	1040	loadk        r42  k120 ; k120 = 72
.line	1040	loadk        r43  k121 ; k121 = 183
.line	1040	loadk        r44   k43 ; k43 = 46
.line	1040	loadk        r45  k122 ; k122 = 191
.line	1040	loadk        r46  k110 ; k110 = 222
.line	1040	loadk        r47  k123 ; k123 = 202
.line	1040	loadk        r48   k26 ; k26 = 56
.line	1040	loadk        r49   k47 ; k47 = 97
.line	1040	loadk        r50  k124 ; k124 = 38
.line	1040	loadk        r51  k125 ; k125 = 214
.line	1040	loadk        r52  k126 ; k126 = 235
.line	1040	loadk        r53  k102 ; k102 = 181
.line	1040	loadk        r54  k127 ; k127 = 100
.line	1040	loadk        r55   k77 ; k77 = 128
.line	1040	loadk        r56   k24 ; k24 = 62
.line	1040	loadk        r57   k84 ; k84 = 253
.line	1040	loadk        r58   k85 ; k85 = 0
.line	1040	loadk        r59  k128 ; k128 = 185
.line	1040	loadk        r60  k129 ; k129 = 11
.line	1040	call         r20    41     2
.line	1040	getupval     r21    u4
.line	1040	loadk        r22  k130 ; k130 = 78
.line	1040	loadk        r23   k91 ; k91 = 70
.line	1040	loadk        r24  k110 ; k110 = 222
.line	1040	loadk        r25  k131 ; k131 = 35
.line	1040	loadk        r26   k96 ; k96 = 87
.line	1040	loadk        r27  k132 ; k132 = 17
.line	1040	loadk        r28   k55 ; k55 = 244
.line	1040	loadk        r29  k129 ; k129 = 11
.line	1040	loadk        r30   k73 ; k73 = 174
.line	1040	loadk        r31  k123 ; k123 = 202
.line	1040	loadk        r32  k133 ; k133 = 218
.line	1040	loadk        r33  k134 ; k134 = 40
.line	1040	loadk        r34  k135 ; k135 = 113
.line	1040	loadk        r35  k136 ; k136 = 54
.line	1040	loadk        r36  k137 ; k137 = 198
.line	1040	loadk        r37  k138 ; k138 = 251
.line	1040	loadk        r38  k139 ; k139 = 165
.line	1040	loadk        r39   k80 ; k80 = 116
.line	1040	loadk        r40  k140 ; k140 = 144
.line	1040	loadk        r41   k83 ; k83 = 34
.line	1040	loadk        r42  k141 ; k141 = 252
.line	1040	loadk        r43  k142 ; k142 = 9
.line	1040	loadk        r44  k143 ; k143 = 169
.line	1040	loadk        r45  k144 ; k144 = 22
.line	1040	loadk        r46  k139 ; k139 = 165
.line	1040	loadk        r47  k145 ; k145 = 141
.line	1040	loadk        r48  k146 ; k146 = 230
.line	1040	loadk        r49  k147 ; k147 = 95
.line	1040	loadk        r50   k96 ; k96 = 87
.line	1040	loadk        r51  k148 ; k148 = 32
.line	1040	loadk        r52   k23 ; k23 = 200
.line	1040	loadk        r53   k50 ; k50 = 227
.line	1040	loadk        r54  k104 ; k104 = 133
.line	1040	loadk        r55  k149 ; k149 = 122
.line	1040	loadk        r56  k150 ; k150 = 177
.line	1040	loadk        r57  k151 ; k151 = 23
.line	1040	loadk        r58   k44 ; k44 = 182
.line	1040	loadk        r59  k152 ; k152 = 52
.line	1040	loadk        r60  k153 ; k153 = 137
.line	1040	loadk        r61  k115 ; k115 = 39
.line	1040	call         r21    41     2
.line	1040	getupval     r22    u4
.line	1040	loadk        r23   k96 ; k96 = 87
.line	1040	loadk        r24   k22 ; k22 = 69
.line	1040	loadk        r25  k154 ; k154 = 209
.line	1040	loadk        r26   k65 ; k65 = 15
.line	1040	loadk        r27  k155 ; k155 = 58
.line	1040	loadk        r28  k131 ; k131 = 35
.line	1040	loadk        r29   k64 ; k64 = 232
.line	1040	loadk        r30   k39 ; k39 = 53
.line	1040	loadk        r31  k156 ; k156 = 143
.line	1040	loadk        r32   k60 ; k60 = 217
.line	1040	loadk        r33  k157 ; k157 = 155
.line	1040	loadk        r34  k158 ; k158 = 88
.line	1040	loadk        r35  k149 ; k149 = 122
.line	1040	loadk        r36  k159 ; k159 = 44
.line	1040	loadk        r37  k160 ; k160 = 194
.line	1040	loadk        r38  k161 ; k161 = 229
.line	1040	loadk        r39  k118 ; k118 = 175
.line	1040	loadk        r40   k22 ; k22 = 69
.line	1040	loadk        r41  k122 ; k122 = 191
.line	1040	loadk        r42   k28 ; k28 = 14
.line	1040	loadk        r43  k162 ; k162 = 239
.line	1040	call         r22    22     0
.line	1040	setlist      r19     0     1
.line	1040	call         r18     2     2
.line	1040	move         r16   r18
.line	1040	loadk        r17  k189 ; k189 = 0.5
.label	l703
.line	1040	self         r18    r0  k190 ; k190 = "SetWidgetVisible"
.line	1040	gettable     r20    r0  k187 ; k187 = "UIRoot"
.line	1040	gettable     r20   r20  k191 ; k191 = "ProgressBar_Download"
.line	1040	not          r21   r12
.line	1040	call         r18     4     1
.line	1040	self         r18    r0  k186 ; k186 = "SetTexture"
.line	1040	gettable     r20    r0  k187 ; k187 = "UIRoot"
.line	1040	gettable     r20   r20  k188 ; k188 = "Image_5"
.line	1040	move         r21   r16
.line	1040	call         r18     4     1
.line	1040	self         r18    r0  k190 ; k190 = "SetWidgetVisible"
.line	1040	gettable     r20    r0  k187 ; k187 = "UIRoot"
.line	1040	gettable     r20   r20  k192 ; k192 = "Reddot_Anchor_Item03"
.line	1040	testset      r21    r7     0
.line	1040	jmp            0  l719
.line	1040	move         r21    r8
.label	l719
.line	1040	call         r18     4     1
.line	1040	self         r18    r0  k190 ; k190 = "SetWidgetVisible"
.line	1040	gettable     r20    r0  k187 ; k187 = "UIRoot"
.line	1040	gettable     r20   r20  k193 ; k193 = "Reddot_Anchor_Item05"
.line	1040	testset      r21    r6     0
.line	1040	jmp            0  l726
.line	1040	move         r21    r8
.label	l726
.line	1040	call         r18     4     1
.line	1040	self         r18    r0  k190 ; k190 = "SetWidgetVisible"
.line	1040	gettable     r20    r0  k187 ; k187 = "UIRoot"
.line	1040	gettable     r20   r20  k194 ; k194 = "CanvasPanel_FX"
.line	1040	testset      r21    r7     1
.line	1040	jmp            0  l733
.line	1040	move         r21    r6
.label	l733
.line	1040	call         r18     4     1
.line	1040	gettable     r18    r0  k187 ; k187 = "UIRoot"
.line	1040	gettable     r18   r18  k195 ; k195 = "WidgetSwitcher_3"
.line	1040	self         r18   r18  k196 ; k196 = "SetActiveWidgetIndex"
.line	1040	move         r20   r13
.line	1040	call         r18     3     1
.line	1040	self         r18    r0  k197 ; k197 = "GetCommonDownloadHan" (truncated)
.line	1040	call         r18     2     2
.line	1040	gettable     r19   r18  k198 ; k198 = "UpdateCommonDownload" (truncated)
.line	1040	gettable     r20    r0  k187 ; k187 = "UIRoot"
.line	1040	gettable     r20   r20  k199 ; k199 = "Common_Download_Stat" (truncated)
.line	1040	move         r21    r5
.line	1040	newtable     r22     0     1
.line	1040	settable     r22  k200  k201 ; k201 = true
.line	1040	call         r19     4     1
.line	1040	gettable     r19   r18  k202 ; k202 = "UpdateCommonDownload" (truncated)
.line	1040	gettable     r20    r0  k187 ; k187 = "UIRoot"
.line	1040	gettable     r20   r20  k199 ; k199 = "Common_Download_Stat" (truncated)
.line	1040	gettabup     r21    u0  k203 ; k203 = "FLinearColor"
.line	1040	loadk        r22   k85 ; k85 = 0
.line	1040	loadk        r23   k85 ; k85 = 0
.line	1040	loadk        r24   k85 ; k85 = 0
.line	1040	loadk        r25  k204 ; k204 = 0.7
.line	1040	call         r21     5     0
.line	1040	call         r19     0     1
.line	1040	getupval     r19    u4
.line	1040	call         r19     1     2
.line	1040	loadk        r20  k164 ; k164 = 1
.line	1040	test          r4     0
.line	1040	jmp            0  l798
.line	1040	test         r12     0
.line	1040	jmp            0  l771
.line	1040	gettabup     r21    u0  k205 ; k205 = "LocUtil"
.line	1040	gettable     r21   r21  k206 ; k206 = "GetLocalizeResStr"
.line	1040	loadk        r22  k207 ; k207 = 83616
.line	1040	call         r21     2     2
.line	1040	move         r19   r21
.line	1040	jmp            0  l798
.label	l771
.line	1040	self         r21    r1  k208 ; k208 = "GetSize"
.line	1040	call         r21     2     3
.line	1040	self         r23    r0  k209 ; k209 = "GetDownloadSize"
.line	1040	gettabup     r25    u5  k210 ; k210 = "PREFETCH"
.line	1040	move         r26   r21
.line	1040	move         r27   r22
.line	1040	call         r23     5     3
.line	1040	move         r22   r24
.line	1040	move         r21   r23
.line	1040	test         r14     1
.line	1040	jmp            0  l789
.line	1040	gettabup     r23    u6  k211 ; k211 = "GetFormatSizeContent"
.line	1040	loadk        r24   k85 ; k85 = 0
.line	1040	move         r25   r22
.line	1040	gettabup     r26    u2    k6 ; k6 = "Not"
.line	1040	call         r23     4     2
.line	1040	move         r19   r23
.line	1040	jmp            0  l795
.label	l789
.line	1040	gettabup     r23    u6  k211 ; k211 = "GetFormatSizeContent"
.line	1040	move         r24   r21
.line	1040	move         r25   r22
.line	1040	move         r26    r5
.line	1040	call         r23     4     2
.line	1040	move         r19   r23
.label	l795
.line	1040	eq             1   r22   k85 ; k85 = 0
.line	1040	jmp            0  l798
.line	1040	div          r20   r21   r22
.label	l798
.line	1040	self         r21    r0  k190 ; k190 = "SetWidgetVisible"
.line	1040	gettable     r23    r0  k187 ; k187 = "UIRoot"
.line	1040	gettable     r23   r23  k212 ; k212 = "CanvasPanel_ReverseS" (truncated)
.line	1040	getupval     r24    u4
.line	1040	call         r24     1     2
.line	1040	eq             0   r19   r24
.line	1040	jmp            0  l806
.line	1040	loadbool     r24     0     1
.label	l806
.line	1040	loadbool     r24     1     0
.line	1040	call         r21     4     1
.line	1040	gettable     r21    r0  k187 ; k187 = "UIRoot"
.line	1040	gettable     r21   r21  k213 ; k213 = "TextBlock_105"
.line	1040	self         r21   r21  k214 ; k214 = "SetText"
.line	1040	move         r23   r19
.line	1040	call         r21     3     1
.line	1040	gettable     r21    r0  k187 ; k187 = "UIRoot"
.line	1040	gettable     r21   r21  k215 ; k215 = "TextBlock_103"
.line	1040	self         r21   r21  k216 ; k216 = "SetOpacity"
.line	1040	move         r23   r17
.line	1040	call         r21     3     1
.line	1040	gettable     r21    r0  k187 ; k187 = "UIRoot"
.line	1040	gettable     r21   r21  k213 ; k213 = "TextBlock_105"
.line	1040	self         r21   r21  k216 ; k216 = "SetOpacity"
.line	1040	move         r23   r17
.line	1040	call         r21     3     1
.line	1040	gettable     r21    r0  k187 ; k187 = "UIRoot"
.line	1040	gettable     r21   r21  k191 ; k191 = "ProgressBar_Download"
.line	1040	self         r21   r21  k217 ; k217 = "SetPercent"
.line	1040	move         r23   r20
.line	1040	call         r21     3     1
.line	1040	self         r21    r0  k190 ; k190 = "SetWidgetVisible"
.line	1040	gettable     r23    r0  k187 ; k187 = "UIRoot"
.line	1040	gettable     r23   r23  k218 ; k218 = "Border_NewVersion"
.line	1040	move         r24    r8
.line	1040	loadbool     r25     1     0
.line	1040	call         r21     5     1
.line	1040	settable      r0  k219    r7 ; k219 = "canGetReverserReward"
.line	1040	return        r0     1
.line	1040	move          r0    r0
.line	1040	return        r0     1

.function	main/f51

.source	null
.linedefined	1129
.lastlinedefined	1134
.numparams	1
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	0	false

.constant	k0	"UIManager"
.constant	k1	"IsUIShow"
.constant	k2	"UI_Config"
.constant	k3	"Download_Delete_Progress_UIBP"
.constant	k4	"HandleClose"

.line	1129	gettabup      r1    u0    k0 ; k0 = "UIManager"
.line	1129	gettable      r1    r1    k1 ; k1 = "IsUIShow"
.line	1129	gettabup      r2    u0    k0 ; k0 = "UIManager"
.line	1129	gettable      r2    r2    k2 ; k2 = "UI_Config"
.line	1129	gettable      r2    r2    k3 ; k3 = "Download_Delete_Prog" (truncated)
.line	1129	call          r1     2     2
.line	1129	test          r1     0
.line	1129	jmp            0   l10
.line	1129	return        r0     1
.label	l10
.line	1129	self          r1    r0    k4 ; k4 = "HandleClose"
.line	1129	call          r1     2     1
.line	1129	return        r0     1
.line	1129	move          r0    r0
.line	1129	move          r0    r0
.line	1129	return        r0     1

.function	main/f52

.source	null
.linedefined	1136
.lastlinedefined	1195
.numparams	1
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	7	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true
.upvalue	"U3"	8	true
.upvalue	"U4"	9	true

.constant	k0	"GetDownloaderNewTable"
.constant	k1	"downloaderData"
.constant	k2	"bundleData"
.constant	k3	"allItemData"
.constant	k4	"InitAppearancePak"
.constant	k5	"PufferDownloader"
.constant	k6	"LoadDownloadKeyRecord"
.constant	k7	-1
.constant	k8	"pairs"
.constant	k9	"text"
.constant	k10	"BundleID"
.constant	k11	"TabName"
.constant	k12	"InitBundleData"
.constant	k13	"TabStyle"
.constant	k14	"next"
.constant	k15	"tabs"
.constant	k16	"BundleName"
.constant	k17	"bundleIDs"
.constant	k18	"tabIDs"
.constant	k19	"ID"
.constant	k20	"table"
.constant	k21	"insert"
.constant	k22	"jumpKey"
.constant	k23	"ipairs"
.constant	k24	"tostring"
.constant	k25	"key"
.constant	k26	"SaveDownloadKeyRecord"
.constant	k27	"log_tree"
.constant	k28	94
.constant	k29	69
.constant	k30	200
.constant	k31	62
.constant	k32	20
.constant	k33	56
.constant	k34	231
.constant	k35	14
.constant	k36	166
.constant	k37	221
.constant	k38	237
.constant	k39	102
.constant	k40	70
.constant	k41	139
.constant	k42	171
.constant	k43	234
.constant	k44	1
.constant	k45	"log"
.constant	k46	"bWriteLog"
.constant	k47	"concat"
.constant	k48	126
.constant	k49	156
.constant	k50	226
.constant	k51	110
.constant	k52	92
.constant	k53	6
.constant	k54	254
.constant	k55	223
.constant	k56	136
.constant	k57	74
.constant	k58	245
.constant	k59	41
.constant	k60	230
.constant	k61	130
.constant	k62	178
.constant	k63	253
.constant	k64	118
.constant	k65	86
.constant	k66	40
.constant	k67	149
.constant	k68	179
.constant	k69	100
.constant	k70	182
.constant	k71	4
.constant	k72	241
.constant	k73	22
.constant	k74	138
.constant	k75	3
.constant	k76	84
.constant	k77	78
.constant	k78	218
.constant	k79	88
.constant	k80	106
.constant	k81	"Common_Tab_Vertical_LevelOne_Text_UIBP"
.constant	k82	"SetTabs"
.constant	k83	"InitSmartDownloadInfo"
.constant	k84	"mergeBundleDataMap"
.constant	k85	"smartDownloadSize"
.constant	k86	"SmartDownloadSelectSize"

.line	1136	gettabup      r1    u0    k0 ; k0 = "GetDownloaderNewTabl" (truncated)
.line	1136	call          r1     1     2
.line	1136	newtable      r2     0     0
.line	1136	settable      r0    k1    r2 ; k1 = "downloaderData"
.line	1136	newtable      r2     0     0
.line	1136	settable      r0    k2    r2 ; k2 = "bundleData"
.line	1136	newtable      r2     0     0
.line	1136	settable      r0    k3    r2 ; k3 = "allItemData"
.line	1136	newtable      r2     0     0
.line	1136	self          r3    r0    k4 ; k4 = "InitAppearancePak"
.line	1136	move          r5    r2
.line	1136	call          r3     3     1
.line	1136	gettabup      r3    u1    k5 ; k5 = "PufferDownloader"
.line	1136	gettable      r3    r3    k6 ; k6 = "LoadDownloadKeyRecor" (truncated)
.line	1136	call          r3     1     1
.line	1136	loadnil       r3     0
.line	1136	loadk         r4    k7 ; k7 = -1
.line	1136	gettabup      r5    u1    k8 ; k8 = "pairs"
.line	1136	move          r6    r1
.line	1136	call          r5     2     4
.line	1136	jmp            0  l108
.line	1136	testset      r10    r3     0
.line	1136	jmp            0   l25
.line	1136	gettable     r10    r3    k9 ; k9 = "text"
.label	l25
.line	1136	gettable     r11    r9   k10 ; k10 = "BundleID"
.line	1136	gettable     r12    r9   k11 ; k11 = "TabName"
.line	1136	getupval     r13    u2
.line	1136	call         r13     1     2
.line	1136	eq             1   r12   r13
.line	1136	jmp            0  l108
.line	1136	gettable     r12    r0    k2 ; k2 = "bundleData"
.line	1136	gettable     r12   r12   r11
.line	1136	test         r12     1
.line	1136	jmp            0   l43
.line	1136	self         r13    r0   k12 ; k12 = "InitBundleData"
.line	1136	move         r15   r11
.line	1136	move         r16    r2
.line	1136	gettable     r17    r9   k13 ; k13 = "TabStyle"
.line	1136	call         r13     5     2
.line	1136	move         r12   r13
.line	1136	gettable     r13    r0    k2 ; k2 = "bundleData"
.line	1136	settable     r13   r11   r12
.label	l43
.line	1136	gettabup     r13    u1   k14 ; k14 = "next"
.line	1136	move         r14   r12
.line	1136	call         r13     2     2
.line	1136	test         r13     0
.line	1136	jmp            0  l108
.line	1136	gettable     r13    r9   k11 ; k11 = "TabName"
.line	1136	eq             1   r10   r13
.line	1136	jmp            0   l73
.line	1136	newtable     r13     0     4
.line	1136	gettable     r14    r9   k11 ; k11 = "TabName"
.line	1136	settable     r13    k9   r14 ; k9 = "text"
.line	1136	newtable     r14     1     0
.line	1136	gettable     r15    r9   k16 ; k16 = "BundleName"
.line	1136	setlist      r14     1     1
.line	1136	settable     r13   k15   r14 ; k15 = "tabs"
.line	1136	newtable     r14     1     0
.line	1136	gettable     r15    r9   k10 ; k10 = "BundleID"
.line	1136	setlist      r14     1     1
.line	1136	settable     r13   k17   r14 ; k17 = "bundleIDs"
.line	1136	newtable     r14     1     0
.line	1136	gettable     r15    r9   k19 ; k19 = "ID"
.line	1136	setlist      r14     1     1
.line	1136	settable     r13   k18   r14 ; k18 = "tabIDs"
.line	1136	move          r3   r13
.line	1136	gettabup     r13    u1   k20 ; k20 = "table"
.line	1136	gettable     r13   r13   k21 ; k21 = "insert"
.line	1136	gettable     r14    r0    k1 ; k1 = "downloaderData"
.line	1136	move         r15    r3
.line	1136	call         r13     3     1
.line	1136	jmp            0   l88
.label	l73
.line	1136	gettabup     r13    u1   k20 ; k20 = "table"
.line	1136	gettable     r13   r13   k21 ; k21 = "insert"
.line	1136	gettable     r14    r3   k15 ; k15 = "tabs"
.line	1136	gettable     r15    r9   k16 ; k16 = "BundleName"
.line	1136	call         r13     3     1
.line	1136	gettabup     r13    u1   k20 ; k20 = "table"
.line	1136	gettable     r13   r13   k21 ; k21 = "insert"
.line	1136	gettable     r14    r3   k17 ; k17 = "bundleIDs"
.line	1136	gettable     r15    r9   k10 ; k10 = "BundleID"
.line	1136	call         r13     3     1
.line	1136	gettabup     r13    u1   k20 ; k20 = "table"
.line	1136	gettable     r13   r13   k21 ; k21 = "insert"
.line	1136	gettable     r14    r3   k18 ; k18 = "tabIDs"
.line	1136	gettable     r15    r9   k19 ; k19 = "ID"
.line	1136	call         r13     3     1
.label	l88
.line	1136	eq             0    r4    k7 ; k7 = -1
.line	1136	jmp            0  l108
.line	1136	gettable     r13    r0   k22 ; k22 = "jumpKey"
.line	1136	test         r13     0
.line	1136	jmp            0  l108
.line	1136	gettabup     r13    u1   k23 ; k23 = "ipairs"
.line	1136	move         r14   r12
.line	1136	call         r13     2     4
.line	1136	jmp            0  l106
.line	1136	gettabup     r18    u1   k24 ; k24 = "tostring"
.line	1136	gettable     r19   r17   k25 ; k25 = "key"
.line	1136	call         r18     2     2
.line	1136	gettable     r19    r0   k22 ; k22 = "jumpKey"
.line	1136	eq             0   r18   r19
.line	1136	jmp            0  l106
.line	1136	gettable     r18    r0    k1 ; k1 = "downloaderData"
.line	1136	len           r4   r18
.line	1136	jmp            0  l108
.label	l106
.line	1136	move          r0    r0
.line	1136	move          r0    r0
.label	l108
.line	1136	move          r0    r0
.line	1136	move          r0    r0
.line	1136	gettabup      r5    u1    k5 ; k5 = "PufferDownloader"
.line	1136	gettable      r5    r5   k26 ; k26 = "SaveDownloadKeyRecor" (truncated)
.line	1136	call          r5     1     1
.line	1136	gettabup      r5    u1   k27 ; k27 = "log_tree"
.line	1136	getupval      r6    u2
.line	1136	loadk         r7   k28 ; k28 = 94
.line	1136	loadk         r8   k29 ; k29 = 69
.line	1136	loadk         r9   k30 ; k30 = 200
.line	1136	loadk        r10   k31 ; k31 = 62
.line	1136	loadk        r11   k32 ; k32 = 20
.line	1136	loadk        r12   k33 ; k33 = 56
.line	1136	loadk        r13   k34 ; k34 = 231
.line	1136	loadk        r14   k35 ; k35 = 14
.line	1136	loadk        r15   k36 ; k36 = 166
.line	1136	loadk        r16   k37 ; k37 = 221
.line	1136	loadk        r17   k38 ; k38 = 237
.line	1136	loadk        r18   k39 ; k39 = 102
.line	1136	loadk        r19   k40 ; k40 = 70
.line	1136	loadk        r20   k33 ; k33 = 56
.line	1136	loadk        r21   k41 ; k41 = 139
.line	1136	loadk        r22   k42 ; k42 = 171
.line	1136	loadk        r23   k43 ; k43 = 234
.line	1136	call          r6    18     2
.line	1136	gettable      r7    r0    k1 ; k1 = "downloaderData"
.line	1136	call          r5     3     1
.line	1136	eq             0    r4    k7 ; k7 = -1
.line	1136	jmp            0  l138
.line	1136	loadk         r4   k44 ; k44 = 1
.label	l138
.line	1136	gettabup      r5    u1   k45 ; k45 = "log"
.line	1136	gettabup      r6    u1   k46 ; k46 = "bWriteLog"
.line	1136	test          r6     0
.line	1136	jmp            0  l202
.line	1136	gettabup      r6    u1   k20 ; k20 = "table"
.line	1136	gettable      r6    r6   k47 ; k47 = "concat"
.line	1136	newtable      r7     1     0
.line	1136	getupval      r8    u2
.line	1136	loadk         r9   k48 ; k48 = 126
.line	1136	loadk        r10   k29 ; k29 = 69
.line	1136	loadk        r11   k30 ; k30 = 200
.line	1136	loadk        r12   k31 ; k31 = 62
.line	1136	loadk        r13   k32 ; k32 = 20
.line	1136	loadk        r14   k33 ; k33 = 56
.line	1136	loadk        r15   k34 ; k34 = 231
.line	1136	loadk        r16   k35 ; k35 = 14
.line	1136	loadk        r17   k49 ; k49 = 156
.line	1136	loadk        r18   k50 ; k50 = 226
.line	1136	loadk        r19   k30 ; k30 = 200
.line	1136	loadk        r20   k51 ; k51 = 110
.line	1136	loadk        r21   k52 ; k52 = 92
.line	1136	loadk        r22   k53 ; k53 = 6
.line	1136	loadk        r23   k54 ; k54 = 254
.line	1136	loadk        r24   k55 ; k55 = 223
.line	1136	loadk        r25   k56 ; k56 = 136
.line	1136	loadk        r26   k57 ; k57 = 74
.line	1136	loadk        r27   k58 ; k58 = 245
.line	1136	loadk        r28   k59 ; k59 = 41
.line	1136	loadk        r29   k60 ; k60 = 230
.line	1136	loadk        r30   k35 ; k35 = 14
.line	1136	loadk        r31   k61 ; k61 = 130
.line	1136	loadk        r32   k35 ; k35 = 14
.line	1136	loadk        r33   k62 ; k62 = 178
.line	1136	loadk        r34   k37 ; k37 = 221
.line	1136	loadk        r35   k63 ; k63 = 253
.line	1136	loadk        r36   k64 ; k64 = 118
.line	1136	loadk        r37   k65 ; k65 = 86
.line	1136	loadk        r38   k66 ; k66 = 40
.line	1136	loadk        r39   k67 ; k67 = 149
.line	1136	loadk        r40   k36 ; k36 = 166
.line	1136	loadk        r41   k68 ; k68 = 179
.line	1136	loadk        r42   k69 ; k69 = 100
.line	1136	loadk        r43   k70 ; k70 = 182
.line	1136	loadk        r44   k71 ; k71 = 4
.line	1136	loadk        r45   k72 ; k72 = 241
.line	1136	loadk        r46   k73 ; k73 = 22
.line	1136	loadk        r47   k74 ; k74 = 138
.line	1136	loadk        r48   k75 ; k75 = 3
.line	1136	call          r8    41     2
.line	1136	getupval      r9    u2
.line	1136	loadk        r10   k76 ; k76 = 84
.line	1136	loadk        r11   k77 ; k77 = 78
.line	1136	loadk        r12   k78 ; k78 = 218
.line	1136	loadk        r13   k66 ; k66 = 40
.line	1136	loadk        r14   k79 ; k79 = 88
.line	1136	loadk        r15   k80 ; k80 = 106
.line	1136	loadk        r16   k36 ; k36 = 166
.line	1136	call          r9     8     0
.line	1136	setlist       r7     0     1
.line	1136	call          r6     2     2
.line	1136	gettabup      r7    u1   k24 ; k24 = "tostring"
.line	1136	move          r8    r4
.line	1136	call          r7     2     2
.line	1136	concat        r6    r6    r7
.label	l202
.line	1136	call          r5     2     1
.line	1136	gettable      r5    r0   k81 ; k81 = "Common_Tab_Vertical_" (truncated)
.line	1136	self          r5    r5   k82 ; k82 = "SetTabs"
.line	1136	gettable      r7    r0    k1 ; k1 = "downloaderData"
.line	1136	move          r8    r4
.line	1136	loadk         r9   k44 ; k44 = 1
.line	1136	call          r5     5     1
.line	1136	gettabup      r5    u3   k83 ; k83 = "InitSmartDownloadInf" (truncated)
.line	1136	gettable      r6    r0    k3 ; k3 = "allItemData"
.line	1136	gettable      r7    r0   k84 ; k84 = "mergeBundleDataMap"
.line	1136	call          r5     3     1
.line	1136	gettabup      r5    u4   k86 ; k86 = "SmartDownloadSelectS" (truncated)
.line	1136	settable      r0   k85    r5 ; k85 = "smartDownloadSize"
.line	1136	return        r0     1
.line	1136	move          r0    r0
.line	1136	move          r0    r0
.line	1136	return        r0     1

.function	main/f53

.source	null
.linedefined	1205
.lastlinedefined	1288
.numparams	3
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	7	true
.upvalue	"U3"	4	true
.upvalue	"U4"	18	true
.upvalue	"U5"	24	true
.upvalue	"U6"	3	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	126
.constant	k7	69
.constant	k8	200
.constant	k9	62
.constant	k10	20
.constant	k11	56
.constant	k12	231
.constant	k13	14
.constant	k14	156
.constant	k15	226
.constant	k16	110
.constant	k17	92
.constant	k18	6
.constant	k19	254
.constant	k20	223
.constant	k21	136
.constant	k22	74
.constant	k23	245
.constant	k24	51
.constant	k25	237
.constant	k26	11
.constant	k27	147
.constant	k28	57
.constant	k29	167
.constant	k30	235
.constant	k31	214
.constant	k32	103
.constant	k33	118
.constant	k34	40
.constant	k35	217
.constant	k36	168
.constant	k37	250
.constant	k38	99
.constant	k39	177
.constant	k40	253
.constant	k41	15
.constant	k42	219
.constant	k43	111
.constant	k44	73
.constant	k45	"tostring"
.constant	k46	"topTabIndex"
.constant	k47	"showBundleID"
.constant	k48	"curShowBundleIDs"
.constant	k49	121
.constant	k50	183
.constant	k51	31
.constant	k52	239
.constant	k53	53
.constant	k54	36
.constant	k55	94
.constant	k56	70
.constant	k57	218
.constant	k58	25
.constant	k59	60
.constant	k60	119
.constant	k61	187
.constant	k62	"GetDownloaderTableData"
.constant	k63	nil
.constant	k64	105
.constant	k65	185
.constant	k66	23
.constant	k67	184
.constant	k68	30
.constant	k69	149
.constant	k70	106
.constant	k71	84
.constant	k72	67
.constant	k73	211
.constant	k74	"TabStyle"
.constant	k75	"curStyle"
.constant	k76	"FitLobby"
.constant	k77	"Download_Fit_Lobby_UIBP"
.constant	k78	"UpdateTabIndex"
.constant	k79	1
.constant	k80	"UIRoot"
.constant	k81	"WidgetSwitcher_List"
.constant	k82	"SetActiveWidgetIndex"
.constant	k83	"bundleData"
.constant	k84	"IsViewMode"
.constant	k85	"ipairs"
.constant	k86	"key"
.constant	k87	"insert"
.constant	k88	"showTabData"
.constant	k89	"VerticalList"
.constant	k90	true
.constant	k91	"selectIndex"
.constant	k92	"dataArr"
.constant	k93	"UpdateCurTabDownloadInfo"
.constant	k94	"UpdateTabContent"
.constant	k95	"uiType"
.constant	k96	"View"
.constant	k97	"isRecommendPage"
.constant	k98	"require"
.constant	k99	89
.constant	k100	22
.constant	k101	35
.constant	k102	175
.constant	k103	41
.constant	k104	81
.constant	k105	54
.constant	k106	197
.constant	k107	240
.constant	k108	163
.constant	k109	125
.constant	k110	225
.constant	k111	228
.constant	k112	52
.constant	k113	242
.constant	k114	216
.constant	k115	116
.constant	k116	80
.constant	k117	38
.constant	k118	138
.constant	k119	127
.constant	k120	189
.constant	k121	28
.constant	k122	241
.constant	k123	4
.constant	k124	142
.constant	k125	24
.constant	k126	95
.constant	k127	77
.constant	k128	63
.constant	k129	26
.constant	k130	9
.constant	k131	192
.constant	k132	"IsFITVersion"
.constant	k133	"SetWidgetVisible"
.constant	k134	"Button_0"
.constant	k135	"UpdateSelectAllCheckBox"

.line	1205	gettabup      r3    u0    k0 ; k0 = "log"
.line	1205	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	1205	test          r4     0
.line	1205	jmp            0   l61
.line	1205	gettabup      r4    u0    k2 ; k2 = "string"
.line	1205	gettable      r4    r4    k3 ; k3 = "format"
.line	1205	gettabup      r5    u0    k4 ; k4 = "table"
.line	1205	gettable      r5    r5    k5 ; k5 = "concat"
.line	1205	newtable      r6     1     0
.line	1205	getupval      r7    u1
.line	1205	loadk         r8    k6 ; k6 = 126
.line	1205	loadk         r9    k7 ; k7 = 69
.line	1205	loadk        r10    k8 ; k8 = 200
.line	1205	loadk        r11    k9 ; k9 = 62
.line	1205	loadk        r12   k10 ; k10 = 20
.line	1205	loadk        r13   k11 ; k11 = 56
.line	1205	loadk        r14   k12 ; k12 = 231
.line	1205	loadk        r15   k13 ; k13 = 14
.line	1205	loadk        r16   k14 ; k14 = 156
.line	1205	loadk        r17   k15 ; k15 = 226
.line	1205	loadk        r18    k8 ; k8 = 200
.line	1205	loadk        r19   k16 ; k16 = 110
.line	1205	loadk        r20   k17 ; k17 = 92
.line	1205	loadk        r21   k18 ; k18 = 6
.line	1205	loadk        r22   k19 ; k19 = 254
.line	1205	loadk        r23   k20 ; k20 = 223
.line	1205	loadk        r24   k21 ; k21 = 136
.line	1205	loadk        r25   k22 ; k22 = 74
.line	1205	loadk        r26   k23 ; k23 = 245
.line	1205	loadk        r27   k24 ; k24 = 51
.line	1205	loadk        r28   k25 ; k25 = 237
.line	1205	loadk        r29   k26 ; k26 = 11
.line	1205	loadk        r30   k27 ; k27 = 147
.line	1205	loadk        r31   k28 ; k28 = 57
.line	1205	loadk        r32   k29 ; k29 = 167
.line	1205	loadk        r33   k30 ; k30 = 235
.line	1205	loadk        r34   k31 ; k31 = 214
.line	1205	loadk        r35   k32 ; k32 = 103
.line	1205	loadk        r36   k33 ; k33 = 118
.line	1205	loadk        r37   k34 ; k34 = 40
.line	1205	loadk        r38   k35 ; k35 = 217
.line	1205	loadk        r39   k36 ; k36 = 168
.line	1205	loadk        r40   k37 ; k37 = 250
.line	1205	loadk        r41   k38 ; k38 = 99
.line	1205	loadk        r42   k39 ; k39 = 177
.line	1205	loadk        r43   k10 ; k10 = 20
.line	1205	loadk        r44   k40 ; k40 = 253
.line	1205	loadk        r45   k41 ; k41 = 15
.line	1205	loadk        r46   k42 ; k42 = 219
.line	1205	loadk        r47   k43 ; k43 = 111
.line	1205	call          r7    41     2
.line	1205	getupval      r8    u1
.line	1205	loadk         r9   k44 ; k44 = 73
.line	1205	call          r8     2     0
.line	1205	setlist       r6     0     1
.line	1205	call          r5     2     2
.line	1205	gettabup      r6    u0   k45 ; k45 = "tostring"
.line	1205	move          r7    r1
.line	1205	call          r6     2     0
.line	1205	call          r4     0     2
.label	l61
.line	1205	call          r3     2     1
.line	1205	gettable      r3    r0   k46 ; k46 = "topTabIndex"
.line	1205	eq             0    r3    r1
.line	1205	jmp            0   l68
.line	1205	test          r2     1
.line	1205	jmp            0   l68
.line	1205	return        r0     1
.label	l68
.line	1205	gettable      r3    r0   k48 ; k48 = "curShowBundleIDs"
.line	1205	test          r3     0
.line	1205	jmp            0   l73
.line	1205	gettable      r3    r0   k48 ; k48 = "curShowBundleIDs"
.line	1205	gettable      r3    r3    r1
.label	l73
.line	1205	settable      r0   k47    r3 ; k47 = "showBundleID"
.line	1205	gettabup      r3    u0    k0 ; k0 = "log"
.line	1205	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	1205	test          r4     0
.line	1205	jmp            0  l139
.line	1205	gettabup      r4    u0    k4 ; k4 = "table"
.line	1205	gettable      r4    r4    k5 ; k5 = "concat"
.line	1205	newtable      r5     1     0
.line	1205	getupval      r6    u1
.line	1205	loadk         r7    k6 ; k6 = 126
.line	1205	loadk         r8    k7 ; k7 = 69
.line	1205	loadk         r9    k8 ; k8 = 200
.line	1205	loadk        r10    k9 ; k9 = 62
.line	1205	loadk        r11   k10 ; k10 = 20
.line	1205	loadk        r12   k11 ; k11 = 56
.line	1205	loadk        r13   k12 ; k12 = 231
.line	1205	loadk        r14   k13 ; k13 = 14
.line	1205	loadk        r15   k14 ; k14 = 156
.line	1205	loadk        r16   k15 ; k15 = 226
.line	1205	loadk        r17    k8 ; k8 = 200
.line	1205	loadk        r18   k16 ; k16 = 110
.line	1205	loadk        r19   k17 ; k17 = 92
.line	1205	loadk        r20   k18 ; k18 = 6
.line	1205	loadk        r21   k19 ; k19 = 254
.line	1205	loadk        r22   k20 ; k20 = 223
.line	1205	loadk        r23   k21 ; k21 = 136
.line	1205	loadk        r24   k22 ; k22 = 74
.line	1205	loadk        r25   k23 ; k23 = 245
.line	1205	loadk        r26   k24 ; k24 = 51
.line	1205	loadk        r27   k25 ; k25 = 237
.line	1205	loadk        r28   k26 ; k26 = 11
.line	1205	loadk        r29   k27 ; k27 = 147
.line	1205	loadk        r30   k28 ; k28 = 57
.line	1205	loadk        r31   k29 ; k29 = 167
.line	1205	loadk        r32   k30 ; k30 = 235
.line	1205	loadk        r33   k31 ; k31 = 214
.line	1205	loadk        r34   k32 ; k32 = 103
.line	1205	loadk        r35   k33 ; k33 = 118
.line	1205	loadk        r36   k34 ; k34 = 40
.line	1205	loadk        r37   k35 ; k35 = 217
.line	1205	loadk        r38   k36 ; k36 = 168
.line	1205	loadk        r39   k37 ; k37 = 250
.line	1205	loadk        r40   k49 ; k49 = 121
.line	1205	loadk        r41   k50 ; k50 = 183
.line	1205	loadk        r42   k51 ; k51 = 31
.line	1205	loadk        r43   k52 ; k52 = 239
.line	1205	loadk        r44   k53 ; k53 = 53
.line	1205	loadk        r45   k27 ; k27 = 147
.line	1205	loadk        r46   k54 ; k54 = 36
.line	1205	call          r6    41     2
.line	1205	getupval      r7    u1
.line	1205	loadk         r8   k55 ; k55 = 94
.line	1205	loadk         r9   k56 ; k56 = 70
.line	1205	loadk        r10   k57 ; k57 = 218
.line	1205	loadk        r11   k58 ; k58 = 25
.line	1205	loadk        r12   k59 ; k59 = 60
.line	1205	loadk        r13   k60 ; k60 = 119
.line	1205	loadk        r14   k61 ; k61 = 187
.line	1205	loadk        r15   k22 ; k22 = 74
.line	1205	call          r7     9     0
.line	1205	setlist       r5     0     1
.line	1205	call          r4     2     2
.line	1205	gettabup      r5    u0   k45 ; k45 = "tostring"
.line	1205	gettable      r6    r0   k47 ; k47 = "showBundleID"
.line	1205	call          r5     2     2
.line	1205	concat        r4    r4    r5
.label	l139
.line	1205	call          r3     2     1
.line	1205	gettable      r3    r0   k47 ; k47 = "showBundleID"
.line	1205	test          r3     1
.line	1205	jmp            0  l144
.line	1205	return        r0     1
.label	l144
.line	1205	settable      r0   k46    r1 ; k46 = "topTabIndex"
.line	1205	gettabup      r3    u2   k62 ; k62 = "GetDownloaderTableDa" (truncated)
.line	1205	gettable      r4    r0   k47 ; k47 = "showBundleID"
.line	1205	call          r3     2     2
.line	1205	eq             0    r3   k63 ; k63 = nil
.line	1205	jmp            0  l208
.line	1205	gettabup      r4    u0    k0 ; k0 = "log"
.line	1205	gettabup      r5    u0    k1 ; k1 = "bWriteLog"
.line	1205	test          r5     0
.line	1205	jmp            0  l206
.line	1205	gettabup      r5    u0    k4 ; k4 = "table"
.line	1205	gettable      r5    r5    k5 ; k5 = "concat"
.line	1205	newtable      r6     1     0
.line	1205	getupval      r7    u1
.line	1205	loadk         r8    k6 ; k6 = 126
.line	1205	loadk         r9    k7 ; k7 = 69
.line	1205	loadk        r10    k8 ; k8 = 200
.line	1205	loadk        r11    k9 ; k9 = 62
.line	1205	loadk        r12   k10 ; k10 = 20
.line	1205	loadk        r13   k11 ; k11 = 56
.line	1205	loadk        r14   k12 ; k12 = 231
.line	1205	loadk        r15   k13 ; k13 = 14
.line	1205	loadk        r16   k14 ; k14 = 156
.line	1205	loadk        r17   k15 ; k15 = 226
.line	1205	loadk        r18    k8 ; k8 = 200
.line	1205	loadk        r19   k16 ; k16 = 110
.line	1205	loadk        r20   k17 ; k17 = 92
.line	1205	loadk        r21   k18 ; k18 = 6
.line	1205	loadk        r22   k19 ; k19 = 254
.line	1205	loadk        r23   k20 ; k20 = 223
.line	1205	loadk        r24   k21 ; k21 = 136
.line	1205	loadk        r25   k22 ; k22 = 74
.line	1205	loadk        r26   k23 ; k23 = 245
.line	1205	loadk        r27   k24 ; k24 = 51
.line	1205	loadk        r28   k25 ; k25 = 237
.line	1205	loadk        r29   k26 ; k26 = 11
.line	1205	loadk        r30   k27 ; k27 = 147
.line	1205	loadk        r31   k28 ; k28 = 57
.line	1205	loadk        r32   k29 ; k29 = 167
.line	1205	loadk        r33   k30 ; k30 = 235
.line	1205	loadk        r34   k31 ; k31 = 214
.line	1205	loadk        r35   k32 ; k32 = 103
.line	1205	loadk        r36   k33 ; k33 = 118
.line	1205	loadk        r37   k34 ; k34 = 40
.line	1205	loadk        r38   k35 ; k35 = 217
.line	1205	loadk        r39   k36 ; k36 = 168
.line	1205	loadk        r40   k37 ; k37 = 250
.line	1205	loadk        r41   k64 ; k64 = 105
.line	1205	loadk        r42   k65 ; k65 = 185
.line	1205	loadk        r43   k66 ; k66 = 23
.line	1205	loadk        r44   k67 ; k67 = 184
.line	1205	loadk        r45   k68 ; k68 = 30
.line	1205	loadk        r46   k69 ; k69 = 149
.line	1205	loadk        r47   k70 ; k70 = 106
.line	1205	call          r7    41     2
.line	1205	getupval      r8    u1
.line	1205	loadk         r9   k71 ; k71 = 84
.line	1205	loadk        r10   k72 ; k72 = 67
.line	1205	loadk        r11   k73 ; k73 = 211
.line	1205	call          r8     4     0
.line	1205	setlist       r6     0     1
.line	1205	call          r5     2     2
.label	l206
.line	1205	call          r4     2     1
.line	1205	return        r0     1
.label	l208
.line	1205	gettable      r4    r3   k74 ; k74 = "TabStyle"
.line	1205	settable      r0   k75    r4 ; k75 = "curStyle"
.line	1205	gettabup      r5    u3   k76 ; k76 = "FitLobby"
.line	1205	eq             0    r4    r5
.line	1205	jmp            0  l220
.line	1205	gettable      r5    r0   k77 ; k77 = "Download_Fit_Lobby_U" (truncated)
.line	1205	test          r5     0
.line	1205	jmp            0  l220
.line	1205	gettable      r5    r0   k77 ; k77 = "Download_Fit_Lobby_U" (truncated)
.line	1205	self          r5    r5   k78 ; k78 = "UpdateTabIndex"
.line	1205	loadk         r7   k79 ; k79 = 1
.line	1205	call          r5     3     1
.label	l220
.line	1205	test          r4     0
.line	1205	jmp            0  l339
.line	1205	gettable      r5    r0   k80 ; k80 = "UIRoot"
.line	1205	gettable      r5    r5   k81 ; k81 = "WidgetSwitcher_List"
.line	1205	self          r5    r5   k82 ; k82 = "SetActiveWidgetIndex"
.line	1205	sub           r7    r4   k79 ; k79 = 1
.line	1205	call          r5     3     1
.line	1205	gettable      r5    r0   k83 ; k83 = "bundleData"
.line	1205	gettable      r6    r0   k47 ; k47 = "showBundleID"
.line	1205	gettable      r5    r5    r6
.line	1205	self          r6    r0   k84 ; k84 = "IsViewMode"
.line	1205	call          r6     2     2
.line	1205	test          r6     1
.line	1205	jmp            0  l252
.line	1205	newtable      r6     0     0
.line	1205	gettabup      r7    u0   k85 ; k85 = "ipairs"
.line	1205	move          r8    r5
.line	1205	call          r7     2     4
.line	1205	jmp            0  l248
.line	1205	gettable     r12   r11   k86 ; k86 = "key"
.line	1205	gettabup     r12    u4   r12
.line	1205	test         r12     1
.line	1205	jmp            0  l248
.line	1205	gettabup     r12    u0    k4 ; k4 = "table"
.line	1205	gettable     r12   r12   k87 ; k87 = "insert"
.line	1205	move         r13    r6
.line	1205	move         r14   r11
.line	1205	call         r12     3     1
.label	l248
.line	1205	move          r0    r0
.line	1205	move          r0    r0
.line	1205	settable      r0   k88    r6 ; k88 = "showTabData"
.line	1205	jmp            0  l333
.label	l252
.line	1205	gettabup      r6    u3   k89 ; k89 = "VerticalList"
.line	1205	eq             0    r4    r6
.line	1205	jmp            0  l332
.line	1205	self          r6    r0   k84 ; k84 = "IsViewMode"
.line	1205	call          r6     2     2
.line	1205	test          r6     0
.line	1205	jmp            0  l332
.line	1205	newtable      r6     0     0
.line	1205	newtable      r7     0     0
.line	1205	loadbool      r8     0     0
.line	1205	gettabup      r9    u0   k85 ; k85 = "ipairs"
.line	1205	move         r10    r5
.line	1205	call          r9     2     4
.line	1205	jmp            0  l286
.line	1205	gettable     r14   r13   k86 ; k86 = "key"
.line	1205	gettabup     r14    u5   r14
.line	1205	test         r14     0
.line	1205	jmp            0  l286
.line	1205	gettable     r15    r6   r14
.line	1205	test         r15     1
.line	1205	jmp            0  l274
.line	1205	newtable     r15     0     0
.label	l274
.line	1205	gettabup     r16    u0    k4 ; k4 = "table"
.line	1205	gettable     r16   r16   k87 ; k87 = "insert"
.line	1205	move         r17   r15
.line	1205	move         r18   r13
.line	1205	call         r16     3     1
.line	1205	len          r16   r15
.line	1205	lt             0   k79   r16 ; k79 = 1
.line	1205	jmp            0  l285
.line	1205	loadbool      r8     1     0
.line	1205	gettable     r16   r13   k86 ; k86 = "key"
.line	1205	settable      r7   r16   k90 ; k90 = true
.label	l285
.line	1205	settable      r6   r14   r15
.label	l286
.line	1205	move          r0    r0
.line	1205	move          r0    r0
.line	1205	test          r8     0
.line	1205	jmp            0  l332
.line	1205	newtable      r9     0     0
.line	1205	gettabup     r10    u0   k85 ; k85 = "ipairs"
.line	1205	move         r11    r5
.line	1205	call         r10     2     4
.line	1205	jmp            0  l329
.line	1205	gettable     r15   r14   k86 ; k86 = "key"
.line	1205	gettable     r15    r7   r15
.line	1205	test         r15     0
.line	1205	jmp            0  l300
.line	1205	jmp            0  l329
.label	l300
.line	1205	gettable     r15   r14   k86 ; k86 = "key"
.line	1205	gettabup     r15    u5   r15
.line	1205	test         r15     0
.line	1205	jmp            0  l324
.line	1205	gettable     r15   r14   k86 ; k86 = "key"
.line	1205	gettabup     r15    u5   r15
.line	1205	gettable     r15    r6   r15
.line	1205	len          r16   r15
.line	1205	lt             0   k79   r16 ; k79 = 1
.line	1205	jmp            0  l318
.line	1205	gettabup     r16    u0    k4 ; k4 = "table"
.line	1205	gettable     r16   r16   k87 ; k87 = "insert"
.line	1205	move         r17    r9
.line	1205	newtable     r18     0     2
.line	1205	settable     r18   k91   k79 ; k79 = 1
.line	1205	settable     r18   k92   r15 ; k92 = "dataArr"
.line	1205	call         r16     3     1
.line	1205	jmp            0  l329
.label	l318
.line	1205	gettabup     r16    u0    k4 ; k4 = "table"
.line	1205	gettable     r16   r16   k87 ; k87 = "insert"
.line	1205	move         r17    r9
.line	1205	move         r18   r14
.line	1205	call         r16     3     1
.line	1205	jmp            0  l329
.label	l324
.line	1205	gettabup     r15    u0    k4 ; k4 = "table"
.line	1205	gettable     r15   r15   k87 ; k87 = "insert"
.line	1205	move         r16    r9
.line	1205	move         r17   r14
.line	1205	call         r15     3     1
.label	l329
.line	1205	move          r0    r0
.line	1205	move          r0    r0
.line	1205	move          r5    r9
.label	l332
.line	1205	settable      r0   k88    r5 ; k88 = "showTabData"
.label	l333
.line	1205	self          r6    r0   k93 ; k93 = "UpdateCurTabDownload" (truncated)
.line	1205	loadbool      r8     1     0
.line	1205	call          r6     3     1
.line	1205	self          r6    r0   k94 ; k94 = "UpdateTabContent"
.line	1205	loadbool      r8     1     0
.line	1205	call          r6     3     1
.label	l339
.line	1205	gettable      r5    r0   k95 ; k95 = "uiType"
.line	1205	gettabup      r6    u6   k96 ; k96 = "View"
.line	1205	eq             1    r5    r6
.line	1205	jmp            0  l344
.line	1205	loadbool      r5     0     1
.label	l344
.line	1205	loadbool      r5     1     0
.line	1205	gettable      r6    r0   k97 ; k97 = "isRecommendPage"
.line	1205	test          r6     0
.line	1205	jmp            0  l349
.line	1205	move          r6    r5
.label	l349
.line	1205	gettabup      r7    u0   k98 ; k98 = "require"
.line	1205	gettabup      r8    u0    k4 ; k4 = "table"
.line	1205	gettable      r8    r8    k5 ; k5 = "concat"
.line	1205	newtable      r9     1     0
.line	1205	getupval     r10    u1
.line	1205	loadk        r11   k99 ; k99 = 89
.line	1205	loadk        r12   k56 ; k56 = 70
.line	1205	loadk        r13   k31 ; k31 = 214
.line	1205	loadk        r14   k53 ; k53 = 53
.line	1205	loadk        r15  k100 ; k100 = 22
.line	1205	loadk        r16  k101 ; k101 = 35
.line	1205	loadk        r17   k36 ; k36 = 168
.line	1205	loadk        r18   k58 ; k58 = 25
.line	1205	loadk        r19  k102 ; k102 = 175
.line	1205	loadk        r20   k57 ; k57 = 218
.line	1205	loadk        r21    k8 ; k8 = 200
.line	1205	loadk        r22  k103 ; k103 = 41
.line	1205	loadk        r23  k104 ; k104 = 81
.line	1205	loadk        r24  k105 ; k105 = 54
.line	1205	loadk        r25  k106 ; k106 = 197
.line	1205	loadk        r26  k107 ; k107 = 240
.line	1205	loadk        r27  k108 ; k108 = 163
.line	1205	loadk        r28  k109 ; k109 = 125
.line	1205	loadk        r29  k110 ; k110 = 225
.line	1205	loadk        r30  k101 ; k101 = 35
.line	1205	loadk        r31  k111 ; k111 = 228
.line	1205	loadk        r32   k13 ; k13 = 14
.line	1205	loadk        r33   k27 ; k27 = 147
.line	1205	loadk        r34  k112 ; k112 = 52
.line	1205	loadk        r35   k29 ; k29 = 167
.line	1205	loadk        r36  k113 ; k113 = 242
.line	1205	loadk        r37  k114 ; k114 = 216
.line	1205	loadk        r38  k115 ; k115 = 116
.line	1205	loadk        r39  k116 ; k116 = 80
.line	1205	loadk        r40  k117 ; k117 = 38
.line	1205	loadk        r41    k8 ; k8 = 200
.line	1205	loadk        r42   k36 ; k36 = 168
.line	1205	loadk        r43  k118 ; k118 = 138
.line	1205	loadk        r44  k119 ; k119 = 127
.line	1205	loadk        r45  k120 ; k120 = 189
.line	1205	loadk        r46  k121 ; k121 = 28
.line	1205	loadk        r47  k122 ; k122 = 241
.line	1205	loadk        r48  k123 ; k123 = 4
.line	1205	loadk        r49  k124 ; k124 = 142
.line	1205	loadk        r50  k125 ; k125 = 24
.line	1205	call         r10    41     2
.line	1205	getupval     r11    u1
.line	1205	loadk        r12  k126 ; k126 = 95
.line	1205	loadk        r13  k127 ; k127 = 77
.line	1205	loadk        r14   k31 ; k31 = 214
.line	1205	loadk        r15  k128 ; k128 = 63
.line	1205	loadk        r16  k100 ; k100 = 22
.line	1205	loadk        r17  k129 ; k129 = 26
.line	1205	loadk        r18   k12 ; k12 = 231
.line	1205	loadk        r19  k130 ; k130 = 9
.line	1205	loadk        r20   k39 ; k39 = 177
.line	1205	loadk        r21  k131 ; k131 = 192
.line	1205	loadk        r22   k57 ; k57 = 218
.line	1205	call         r11    12     0
.line	1205	setlist       r9     0     1
.line	1205	call          r8     2     2
.line	1205	call          r7     2     2
.line	1205	gettable      r8    r7  k132 ; k132 = "IsFITVersion"
.line	1205	call          r8     1     2
.line	1205	test          r8     0
.line	1205	jmp            0  l416
.line	1205	loadbool      r6     0     0
.label	l416
.line	1205	self          r9    r0  k133 ; k133 = "SetWidgetVisible"
.line	1205	gettable     r11    r0   k80 ; k80 = "UIRoot"
.line	1205	gettable     r11   r11  k134 ; k134 = "Button_0"
.line	1205	move         r12    r6
.line	1205	loadbool     r13     1     0
.line	1205	call          r9     5     1
.line	1205	test          r5     1
.line	1205	jmp            0  l426
.line	1205	self          r9    r0  k135 ; k135 = "UpdateSelectAllCheck" (truncated)
.line	1205	call          r9     2     1
.label	l426
.line	1205	return        r0     1
.line	1205	move          r0    r0
.line	1205	move          r0    r0
.line	1205	move          r0    r0
.line	1205	move          r0    r0
.line	1205	return        r0     1

.function	main/f54

.source	null
.linedefined	1290
.lastlinedefined	1292
.numparams	1
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	16	true

.constant	k0	"showBundleID"

.line	1290	gettable      r1    r0    k0 ; k0 = "showBundleID"
.line	1290	gettabup      r1    u0    r1
.line	1290	return        r1     2
.line	1290	return        r0     1
.line	1290	move          r0    r0
.line	1290	move          r0    r0
.line	1290	move          r0    r0
.line	1290	move          r0    r0
.line	1290	return        r0     1

.function	main/f55

.source	null
.linedefined	1294
.lastlinedefined	1296
.numparams	1
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	5	true

.constant	k0	"showBundleID"
.constant	k1	"Enum_BundleID"
.constant	k2	"FitLobbyRes"

.line	1294	gettable      r1    r0    k0 ; k0 = "showBundleID"
.line	1294	gettabup      r2    u0    k1 ; k1 = "Enum_BundleID"
.line	1294	gettable      r2    r2    k2 ; k2 = "FitLobbyRes"
.line	1294	eq             1    r1    r2
.line	1294	jmp            0    l7
.line	1294	loadbool      r1     0     1
.label	l7
.line	1294	loadbool      r1     1     0
.line	1294	return        r1     2
.line	1294	return        r0     1
.line	1294	move          r0    r0
.line	1294	move          r0    r0
.line	1294	move          r0    r0
.line	1294	move          r0    r0
.line	1294	return        r0     1

.function	main/f56

.source	null
.linedefined	1298
.lastlinedefined	1304
.numparams	2
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	16	true

.constant	k0	"bundleIDs"
.constant	k1	1
.constant	k2	0
.constant	k3	true

.line	1298	test          r1     0
.line	1298	jmp            0    l6
.line	1298	gettable      r2    r1    k0 ; k0 = "bundleIDs"
.line	1298	test          r2     1
.line	1298	jmp            0    l8
.label	l6
.line	1298	loadbool      r2     0     0
.line	1298	return        r2     2
.label	l8
.line	1298	gettable      r2    r1    k0 ; k0 = "bundleIDs"
.line	1298	gettable      r2    r2    k1 ; k1 = 1
.line	1298	test          r2     1
.line	1298	jmp            0   l13
.line	1298	loadk         r2    k2 ; k2 = 0
.label	l13
.line	1298	gettabup      r3    u0    r2
.line	1298	eq             1    r3    k3 ; k3 = true
.line	1298	jmp            0   l17
.line	1298	loadbool      r3     0     1
.label	l17
.line	1298	loadbool      r3     1     0
.line	1298	return        r3     2
.line	1298	return        r0     1
.line	1298	move          r0    r0
.line	1298	move          r0    r0
.line	1298	move          r0    r0
.line	1298	move          r0    r0
.line	1298	return        r0     1

.function	main/f57

.source	null
.linedefined	1306
.lastlinedefined	1336
.numparams	2
.is_vararg	0
.maxstacksize	22

.upvalue	"_ENV"	0	false
.upvalue	"U1"	5	true
.upvalue	"U2"	1	true
.upvalue	"U3"	4	true

.constant	k0	"showTabData"
.constant	k1	"IsViewMode"
.constant	k2	"ipairs"
.constant	k3	"GetItemData"
.constant	k4	"key"
.constant	k5	"MIX_PACK_SET_PREFIX"
.constant	k6	74
.constant	k7	79
.constant	k8	205
.constant	k9	54
.constant	k10	23
.constant	k11	37
.constant	k12	235
.constant	k13	11
.constant	k14	173
.constant	k15	204
.constant	k16	"UpdateItemSize"
.constant	k17	"curStyle"
.constant	k18	"BigImage"
.constant	k19	"UpdateBigImage"
.constant	k20	"FitLobby"
.constant	k21	"UpdateFitLobby"
.constant	k22	"HorizonList"
.constant	k23	"LoopScrollBox_Hor"
.constant	k24	"SetData"
.constant	k25	"ScrollToItem"
.constant	k26	1
.constant	k27	"VerticalList"
.constant	k28	"LoopScrollBox_Ver"
.constant	k29	"UpdateTabExtraContent"

.line	1306	gettable      r2    r0    k0 ; k0 = "showTabData"
.line	1306	test          r2     1
.line	1306	jmp            0    l5
.line	1306	return        r0     1
.label	l5
.line	1306	self          r2    r0    k1 ; k1 = "IsViewMode"
.line	1306	call          r2     2     2
.line	1306	test          r2     1
.line	1306	jmp            0   l41
.line	1306	gettabup      r2    u0    k2 ; k2 = "ipairs"
.line	1306	gettable      r3    r0    k0 ; k0 = "showTabData"
.line	1306	call          r2     2     4
.line	1306	jmp            0   l39
.line	1306	self          r7    r0    k3 ; k3 = "GetItemData"
.line	1306	move          r9    r6
.line	1306	call          r7     3     2
.line	1306	test          r7     0
.line	1306	jmp            0   l39
.line	1306	gettable      r8    r7    k4 ; k4 = "key"
.line	1306	gettabup      r9    u1    k5 ; k5 = "MIX_PACK_SET_PREFIX"
.line	1306	getupval     r10    u2
.line	1306	loadk        r11    k6 ; k6 = 74
.line	1306	loadk        r12    k7 ; k7 = 79
.line	1306	loadk        r13    k8 ; k8 = 205
.line	1306	loadk        r14    k9 ; k9 = 54
.line	1306	loadk        r15   k10 ; k10 = 23
.line	1306	loadk        r16   k11 ; k11 = 37
.line	1306	loadk        r17   k12 ; k12 = 235
.line	1306	loadk        r18   k13 ; k13 = 11
.line	1306	loadk        r19   k14 ; k14 = 173
.line	1306	loadk        r20   k15 ; k15 = 204
.line	1306	loadk        r21   k15 ; k15 = 204
.line	1306	call         r10    12     2
.line	1306	concat        r9    r9   r10
.line	1306	eq             0    r8    r9
.line	1306	jmp            0   l39
.line	1306	self          r8    r0   k16 ; k16 = "UpdateItemSize"
.line	1306	move         r10    r7
.line	1306	call          r8     3     1
.label	l39
.line	1306	move          r0    r0
.line	1306	move          r0    r0
.label	l41
.line	1306	test          r1     0
.line	1306	jmp            0   l45
.line	1306	gettable      r2    r0    k0 ; k0 = "showTabData"
.line	1306	len           r1    r2
.label	l45
.line	1306	gettable      r2    r0   k17 ; k17 = "curStyle"
.line	1306	gettabup      r3    u3   k18 ; k18 = "BigImage"
.line	1306	eq             0    r2    r3
.line	1306	jmp            0   l53
.line	1306	self          r3    r0   k19 ; k19 = "UpdateBigImage"
.line	1306	gettable      r5    r0    k0 ; k0 = "showTabData"
.line	1306	call          r3     3     1
.line	1306	jmp            0   l87
.label	l53
.line	1306	gettabup      r3    u3   k20 ; k20 = "FitLobby"
.line	1306	eq             0    r2    r3
.line	1306	jmp            0   l60
.line	1306	self          r3    r0   k21 ; k21 = "UpdateFitLobby"
.line	1306	gettable      r5    r0    k0 ; k0 = "showTabData"
.line	1306	call          r3     3     1
.line	1306	jmp            0   l87
.label	l60
.line	1306	gettabup      r3    u3   k22 ; k22 = "HorizonList"
.line	1306	eq             0    r2    r3
.line	1306	jmp            0   l74
.line	1306	gettable      r3    r0   k23 ; k23 = "LoopScrollBox_Hor"
.line	1306	self          r3    r3   k24 ; k24 = "SetData"
.line	1306	gettable      r5    r0    k0 ; k0 = "showTabData"
.line	1306	call          r3     3     1
.line	1306	test          r1     0
.line	1306	jmp            0   l87
.line	1306	gettable      r3    r0   k23 ; k23 = "LoopScrollBox_Hor"
.line	1306	self          r3    r3   k25 ; k25 = "ScrollToItem"
.line	1306	loadk         r5   k26 ; k26 = 1
.line	1306	call          r3     3     1
.line	1306	jmp            0   l87
.label	l74
.line	1306	gettabup      r3    u3   k27 ; k27 = "VerticalList"
.line	1306	eq             0    r2    r3
.line	1306	jmp            0   l87
.line	1306	gettable      r3    r0   k28 ; k28 = "LoopScrollBox_Ver"
.line	1306	self          r3    r3   k24 ; k24 = "SetData"
.line	1306	gettable      r5    r0    k0 ; k0 = "showTabData"
.line	1306	call          r3     3     1
.line	1306	test          r1     0
.line	1306	jmp            0   l87
.line	1306	gettable      r3    r0   k28 ; k28 = "LoopScrollBox_Ver"
.line	1306	self          r3    r3   k25 ; k25 = "ScrollToItem"
.line	1306	loadk         r5   k26 ; k26 = 1
.line	1306	call          r3     3     1
.label	l87
.line	1306	self          r3    r0   k29 ; k29 = "UpdateTabExtraConten" (truncated)
.line	1306	call          r3     2     1
.line	1306	return        r0     1
.line	1306	move          r0    r0
.line	1306	move          r0    r0
.line	1306	move          r0    r0
.line	1306	return        r0     1

.function	main/f58

.source	null
.linedefined	1338
.lastlinedefined	1354
.numparams	1
.is_vararg	0
.maxstacksize	13

.upvalue	"_ENV"	5	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"showTabData"
.constant	k1	"showBundleID"
.constant	k2	"Enum_BundleID"
.constant	k3	"WoW"
.constant	k4	"SetWidgetVisible"
.constant	k5	"UIRoot"
.constant	k6	"Border_0"
.constant	k7	"Button_Help"
.constant	k8	"ModuleManager"
.constant	k9	"GetModule"
.constant	k10	"LobbyModuleConfig"
.constant	k11	"LogicUGCAssetHub"
.constant	k12	"GetPublicAndPrivacyStorage"
.constant	k13	"LocUtil"
.constant	k14	"LocalizeResFormat"
.constant	k15	8400005
.constant	k16	"string"
.constant	k17	"format"
.constant	k18	31
.constant	k19	4
.constant	k20	142
.constant	k21	54
.constant	k22	"TextBlock_14"
.constant	k23	"SetText"
.constant	k24	468890017
.constant	k25	"TextBlock_17"
.constant	k26	99010039

.line	1338	gettable      r1    r0    k0 ; k0 = "showTabData"
.line	1338	test          r1     1
.line	1338	jmp            0    l5
.line	1338	return        r0     1
.label	l5
.line	1338	gettable      r1    r0    k1 ; k1 = "showBundleID"
.line	1338	gettabup      r2    u0    k2 ; k2 = "Enum_BundleID"
.line	1338	gettable      r2    r2    k3 ; k3 = "WoW"
.line	1338	eq             0    r1    r2
.line	1338	jmp            0   l76
.line	1338	self          r1    r0    k4 ; k4 = "SetWidgetVisible"
.line	1338	gettable      r3    r0    k5 ; k5 = "UIRoot"
.line	1338	gettable      r3    r3    k6 ; k6 = "Border_0"
.line	1338	loadbool      r4     1     0
.line	1338	call          r1     4     1
.line	1338	self          r1    r0    k4 ; k4 = "SetWidgetVisible"
.line	1338	gettable      r3    r0    k5 ; k5 = "UIRoot"
.line	1338	gettable      r3    r3    k7 ; k7 = "Button_Help"
.line	1338	loadbool      r4     1     0
.line	1338	loadbool      r5     1     0
.line	1338	call          r1     5     1
.line	1338	gettabup      r1    u1    k8 ; k8 = "ModuleManager"
.line	1338	gettable      r1    r1    k9 ; k9 = "GetModule"
.line	1338	gettabup      r2    u1    k8 ; k8 = "ModuleManager"
.line	1338	gettable      r2    r2   k10 ; k10 = "LobbyModuleConfig"
.line	1338	gettable      r2    r2   k11 ; k11 = "LogicUGCAssetHub"
.line	1338	call          r1     2     2
.line	1338	self          r2    r1   k12 ; k12 = "GetPublicAndPrivacyS" (truncated)
.line	1338	call          r2     2     3
.line	1338	gettabup      r4    u1   k13 ; k13 = "LocUtil"
.line	1338	gettable      r4    r4   k14 ; k14 = "LocalizeResFormat"
.line	1338	loadk         r5   k15 ; k15 = 8400005
.line	1338	gettabup      r6    u1   k16 ; k16 = "string"
.line	1338	gettable      r6    r6   k17 ; k17 = "format"
.line	1338	getupval      r7    u2
.line	1338	loadk         r8   k18 ; k18 = 31
.line	1338	loadk         r9   k19 ; k19 = 4
.line	1338	loadk        r10   k20 ; k20 = 142
.line	1338	loadk        r11   k21 ; k21 = 54
.line	1338	call          r7     5     2
.line	1338	move          r8    r2
.line	1338	call          r6     3     0
.line	1338	call          r4     0     2
.line	1338	gettable      r5    r0    k5 ; k5 = "UIRoot"
.line	1338	gettable      r5    r5   k22 ; k22 = "TextBlock_14"
.line	1338	self          r5    r5   k23 ; k23 = "SetText"
.line	1338	gettabup      r7    u1   k13 ; k13 = "LocUtil"
.line	1338	gettable      r7    r7   k14 ; k14 = "LocalizeResFormat"
.line	1338	loadk         r8   k24 ; k24 = 468890017
.line	1338	move          r9    r4
.line	1338	call          r7     3     0
.line	1338	call          r5     0     1
.line	1338	gettabup      r5    u1   k13 ; k13 = "LocUtil"
.line	1338	gettable      r5    r5   k14 ; k14 = "LocalizeResFormat"
.line	1338	loadk         r6   k15 ; k15 = 8400005
.line	1338	gettabup      r7    u1   k16 ; k16 = "string"
.line	1338	gettable      r7    r7   k17 ; k17 = "format"
.line	1338	getupval      r8    u2
.line	1338	loadk         r9   k18 ; k18 = 31
.line	1338	loadk        r10   k19 ; k19 = 4
.line	1338	loadk        r11   k20 ; k20 = 142
.line	1338	loadk        r12   k21 ; k21 = 54
.line	1338	call          r8     5     2
.line	1338	move          r9    r3
.line	1338	call          r7     3     0
.line	1338	call          r5     0     2
.line	1338	gettable      r6    r0    k5 ; k5 = "UIRoot"
.line	1338	gettable      r6    r6   k25 ; k25 = "TextBlock_17"
.line	1338	self          r6    r6   k23 ; k23 = "SetText"
.line	1338	gettabup      r8    u1   k13 ; k13 = "LocUtil"
.line	1338	gettable      r8    r8   k14 ; k14 = "LocalizeResFormat"
.line	1338	loadk         r9   k26 ; k26 = 99010039
.line	1338	move         r10    r5
.line	1338	call          r8     3     0
.line	1338	call          r6     0     1
.line	1338	jmp            0   l81
.label	l76
.line	1338	self          r1    r0    k4 ; k4 = "SetWidgetVisible"
.line	1338	gettable      r3    r0    k5 ; k5 = "UIRoot"
.line	1338	gettable      r3    r3    k6 ; k6 = "Border_0"
.line	1338	loadbool      r4     0     0
.line	1338	call          r1     4     1
.label	l81
.line	1338	return        r0     1
.line	1338	move          r0    r0
.line	1338	return        r0     1

.function	main/f59

.source	null
.linedefined	1356
.lastlinedefined	1358
.numparams	1
.is_vararg	0
.maxstacksize	3

.constant	k0	"UpdateTabExtraContent"

.line	1356	self          r1    r0    k0 ; k0 = "UpdateTabExtraConten" (truncated)
.line	1356	call          r1     2     1
.line	1356	return        r0     1
.line	1356	move          r0    r0
.line	1356	return        r0     1

.function	main/f60

.source	null
.linedefined	1360
.lastlinedefined	1372
.numparams	2
.is_vararg	0
.maxstacksize	22

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Download_List_Interface_UIBP"
.constant	k1	"next"
.constant	k2	1
.constant	k3	"require"
.constant	k4	89
.constant	k5	69
.constant	k6	210
.constant	k7	61
.constant	k8	23
.constant	k9	57
.constant	k10	168
.constant	k11	30
.constant	k12	162
.constant	k13	205
.constant	k14	197
.constant	k15	98
.constant	k16	109
.constant	k17	44
.constant	k18	223
.constant	k19	255
.constant	k20	166
.constant	k21	"CopyTable"
.constant	k22	"state"
.constant	k23	"sumDownloadData"
.constant	k24	"cSize"
.constant	k25	"tSize"
.constant	k26	"data"
.constant	k27	"OnRefresh"

.line	1360	gettable      r2    r0    k0 ; k0 = "Download_List_Interf" (truncated)
.line	1360	test          r2     0
.line	1360	jmp            0   l11
.line	1360	test          r1     0
.line	1360	jmp            0   l11
.line	1360	gettabup      r2    u0    k1 ; k1 = "next"
.line	1360	move          r3    r1
.line	1360	call          r2     2     2
.line	1360	test          r2     1
.line	1360	jmp            0   l12
.label	l11
.line	1360	return        r0     1
.label	l12
.line	1360	gettable      r2    r1    k2 ; k2 = 1
.line	1360	gettabup      r3    u0    k3 ; k3 = "require"
.line	1360	getupval      r4    u1
.line	1360	loadk         r5    k4 ; k4 = 89
.line	1360	loadk         r6    k5 ; k5 = 69
.line	1360	loadk         r7    k6 ; k6 = 210
.line	1360	loadk         r8    k7 ; k7 = 61
.line	1360	loadk         r9    k8 ; k8 = 23
.line	1360	loadk        r10    k9 ; k9 = 57
.line	1360	loadk        r11   k10 ; k10 = 168
.line	1360	loadk        r12   k11 ; k11 = 30
.line	1360	loadk        r13   k12 ; k12 = 162
.line	1360	loadk        r14   k13 ; k13 = 205
.line	1360	loadk        r15   k14 ; k14 = 197
.line	1360	loadk        r16   k15 ; k15 = 98
.line	1360	loadk        r17   k16 ; k16 = 109
.line	1360	loadk        r18   k17 ; k17 = 44
.line	1360	loadk        r19   k18 ; k18 = 223
.line	1360	loadk        r20   k19 ; k19 = 255
.line	1360	loadk        r21   k20 ; k20 = 166
.line	1360	call          r4    18     2
.line	1360	call          r3     2     2
.line	1360	gettable      r4    r3   k21 ; k21 = "CopyTable"
.line	1360	move          r5    r2
.line	1360	call          r4     2     2
.line	1360	move          r2    r4
.line	1360	gettable      r4    r0   k23 ; k23 = "sumDownloadData"
.line	1360	gettable      r4    r4   k22 ; k22 = "state"
.line	1360	settable      r2   k22    r4 ; k22 = "state"
.line	1360	gettable      r4    r0   k23 ; k23 = "sumDownloadData"
.line	1360	gettable      r4    r4   k24 ; k24 = "cSize"
.line	1360	settable      r2   k24    r4 ; k24 = "cSize"
.line	1360	gettable      r4    r0   k23 ; k23 = "sumDownloadData"
.line	1360	gettable      r4    r4   k25 ; k25 = "tSize"
.line	1360	settable      r2   k25    r4 ; k25 = "tSize"
.line	1360	gettable      r4    r0    k0 ; k0 = "Download_List_Interf" (truncated)
.line	1360	settable      r4   k26    r2 ; k26 = "data"
.line	1360	gettable      r4    r0    k0 ; k0 = "Download_List_Interf" (truncated)
.line	1360	self          r4    r4   k27 ; k27 = "OnRefresh"
.line	1360	move          r6    r2
.line	1360	call          r4     3     1
.line	1360	return        r0     1
.line	1360	move          r0    r0
.line	1360	return        r0     1

.function	main/f61

.source	null
.linedefined	1374
.lastlinedefined	1386
.numparams	2
.is_vararg	0
.maxstacksize	22

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Download_Fit_Lobby_UIBP"
.constant	k1	"next"
.constant	k2	1
.constant	k3	"require"
.constant	k4	89
.constant	k5	69
.constant	k6	210
.constant	k7	61
.constant	k8	23
.constant	k9	57
.constant	k10	168
.constant	k11	30
.constant	k12	162
.constant	k13	205
.constant	k14	197
.constant	k15	98
.constant	k16	109
.constant	k17	44
.constant	k18	223
.constant	k19	255
.constant	k20	166
.constant	k21	"CopyTable"
.constant	k22	"state"
.constant	k23	"sumDownloadData"
.constant	k24	"cSize"
.constant	k25	"tSize"
.constant	k26	"data"
.constant	k27	"OnRefresh"

.line	1374	gettable      r2    r0    k0 ; k0 = "Download_Fit_Lobby_U" (truncated)
.line	1374	test          r2     0
.line	1374	jmp            0   l11
.line	1374	test          r1     0
.line	1374	jmp            0   l11
.line	1374	gettabup      r2    u0    k1 ; k1 = "next"
.line	1374	move          r3    r1
.line	1374	call          r2     2     2
.line	1374	test          r2     1
.line	1374	jmp            0   l12
.label	l11
.line	1374	return        r0     1
.label	l12
.line	1374	gettable      r2    r1    k2 ; k2 = 1
.line	1374	gettabup      r3    u0    k3 ; k3 = "require"
.line	1374	getupval      r4    u1
.line	1374	loadk         r5    k4 ; k4 = 89
.line	1374	loadk         r6    k5 ; k5 = 69
.line	1374	loadk         r7    k6 ; k6 = 210
.line	1374	loadk         r8    k7 ; k7 = 61
.line	1374	loadk         r9    k8 ; k8 = 23
.line	1374	loadk        r10    k9 ; k9 = 57
.line	1374	loadk        r11   k10 ; k10 = 168
.line	1374	loadk        r12   k11 ; k11 = 30
.line	1374	loadk        r13   k12 ; k12 = 162
.line	1374	loadk        r14   k13 ; k13 = 205
.line	1374	loadk        r15   k14 ; k14 = 197
.line	1374	loadk        r16   k15 ; k15 = 98
.line	1374	loadk        r17   k16 ; k16 = 109
.line	1374	loadk        r18   k17 ; k17 = 44
.line	1374	loadk        r19   k18 ; k18 = 223
.line	1374	loadk        r20   k19 ; k19 = 255
.line	1374	loadk        r21   k20 ; k20 = 166
.line	1374	call          r4    18     2
.line	1374	call          r3     2     2
.line	1374	gettable      r4    r3   k21 ; k21 = "CopyTable"
.line	1374	move          r5    r2
.line	1374	call          r4     2     2
.line	1374	move          r2    r4
.line	1374	gettable      r4    r0   k23 ; k23 = "sumDownloadData"
.line	1374	gettable      r4    r4   k22 ; k22 = "state"
.line	1374	settable      r2   k22    r4 ; k22 = "state"
.line	1374	gettable      r4    r0   k23 ; k23 = "sumDownloadData"
.line	1374	gettable      r4    r4   k24 ; k24 = "cSize"
.line	1374	settable      r2   k24    r4 ; k24 = "cSize"
.line	1374	gettable      r4    r0   k23 ; k23 = "sumDownloadData"
.line	1374	gettable      r4    r4   k25 ; k25 = "tSize"
.line	1374	settable      r2   k25    r4 ; k25 = "tSize"
.line	1374	gettable      r4    r0    k0 ; k0 = "Download_Fit_Lobby_U" (truncated)
.line	1374	settable      r4   k26    r2 ; k26 = "data"
.line	1374	gettable      r4    r0    k0 ; k0 = "Download_Fit_Lobby_U" (truncated)
.line	1374	self          r4    r4   k27 ; k27 = "OnRefresh"
.line	1374	move          r6    r2
.line	1374	call          r4     3     1
.line	1374	return        r0     1
.line	1374	move          r0    r0
.line	1374	return        r0     1

.function	main/f62

.source	null
.linedefined	1388
.lastlinedefined	1434
.numparams	1
.is_vararg	0
.maxstacksize	57

.upvalue	"_ENV"	0	false
.upvalue	"U1"	6	true
.upvalue	"U2"	13	true
.upvalue	"U3"	1	true
.upvalue	"U4"	7	true
.upvalue	"U5"	5	true
.upvalue	"U6"	9	true

.constant	k0	"isFitVersion"
.constant	k1	"PufferDownloader"
.constant	k2	"FitVersionForceDownloadList"
.constant	k3	"pairs"
.constant	k4	"GetState"
.constant	k5	"Done"
.constant	k6	"log_tree"
.constant	k7	"table"
.constant	k8	"concat"
.constant	k9	126
.constant	k10	69
.constant	k11	200
.constant	k12	62
.constant	k13	20
.constant	k14	56
.constant	k15	231
.constant	k16	14
.constant	k17	156
.constant	k18	226
.constant	k19	110
.constant	k20	92
.constant	k21	6
.constant	k22	254
.constant	k23	223
.constant	k24	136
.constant	k25	74
.constant	k26	245
.constant	k27	53
.constant	k28	248
.constant	k29	3
.constant	k30	151
.constant	k31	46
.constant	k32	182
.constant	k33	251
.constant	k34	214
.constant	k35	96
.constant	k36	76
.constant	k37	37
.constant	k38	212
.constant	k39	190
.constant	k40	89
.constant	k41	175
.constant	k42	21
.constant	k43	253
.constant	k44	19
.constant	k45	106
.constant	k46	84
.constant	k47	203
.constant	k48	112
.constant	k49	28
.constant	k50	232
.constant	k51	15
.constant	k52	237
.constant	k53	143
.constant	k54	194
.constant	k55	98
.constant	k56	75
.constant	k57	229
.constant	k58	58
.constant	k59	242
.constant	k60	64
.constant	k61	"SetWidgetVisible"
.constant	k62	"UIRoot"
.constant	k63	"TextBlock_3"
.constant	k64	"GetBundleState"
.constant	k65	"PREFETCH_BUNDLE_ID"
.constant	k66	"Download"
.constant	k67	"bundleData"
.constant	k68	"Enum_BundleID"
.constant	k69	"FitLobbyRes"
.constant	k70	"log_format"
.constant	k71	88
.constant	k72	95
.constant	k73	209
.constant	k74	52
.constant	k75	50
.constant	k76	207
.constant	k77	138
.constant	k78	218
.constant	k79	"MyAppearance"
.constant	k80	"ipairs"
.constant	k81	"GetItemDataState"
.constant	k82	130
.constant	k83	117
.constant	k84	11
.constant	k85	"key"
.constant	k86	"isToggleDownloadingAll"
.constant	k87	"SetWidgetVisibility"
.constant	k88	"UEnums"
.constant	k89	"ESlateVisibility"
.constant	k90	"SelfHitTestInvisible"
.constant	k91	"GCPufferDownloader"
.constant	k92	"GetCurrentSpeed"
.constant	k93	"Puffer"
.constant	k94	1024
.constant	k95	"string"
.constant	k96	"format"
.constant	k97	31
.constant	k98	4
.constant	k99	142
.constant	k100	54
.constant	k101	"LocUtil"
.constant	k102	"LocalizeResFormat"
.constant	k103	10341
.constant	k104	"SetText"

.line	1388	gettable      r1    r0    k0 ; k0 = "isFitVersion"
.line	1388	test          r1     0
.line	1388	jmp            0  l100
.line	1388	gettabup      r1    u0    k1 ; k1 = "PufferDownloader"
.line	1388	gettable      r1    r1    k2 ; k2 = "FitVersionForceDownl" (truncated)
.line	1388	test          r1     0
.line	1388	jmp            0  l100
.line	1388	gettabup      r1    u0    k3 ; k3 = "pairs"
.line	1388	gettabup      r2    u0    k1 ; k1 = "PufferDownloader"
.line	1388	gettable      r2    r2    k2 ; k2 = "FitVersionForceDownl" (truncated)
.line	1388	call          r1     2     4
.line	1388	jmp            0   l98
.line	1388	gettabup      r6    u1    k4 ; k4 = "GetState"
.line	1388	move          r7    r4
.line	1388	move          r8    r5
.line	1388	call          r6     3     2
.line	1388	gettabup      r7    u2    k5 ; k5 = "Done"
.line	1388	eq             1    r6    r7
.line	1388	jmp            0   l98
.line	1388	gettabup      r6    u0    k6 ; k6 = "log_tree"
.line	1388	gettabup      r7    u0    k7 ; k7 = "table"
.line	1388	gettable      r7    r7    k8 ; k8 = "concat"
.line	1388	newtable      r8     1     0
.line	1388	getupval      r9    u3
.line	1388	loadk        r10    k9 ; k9 = 126
.line	1388	loadk        r11   k10 ; k10 = 69
.line	1388	loadk        r12   k11 ; k11 = 200
.line	1388	loadk        r13   k12 ; k12 = 62
.line	1388	loadk        r14   k13 ; k13 = 20
.line	1388	loadk        r15   k14 ; k14 = 56
.line	1388	loadk        r16   k15 ; k15 = 231
.line	1388	loadk        r17   k16 ; k16 = 14
.line	1388	loadk        r18   k17 ; k17 = 156
.line	1388	loadk        r19   k18 ; k18 = 226
.line	1388	loadk        r20   k11 ; k11 = 200
.line	1388	loadk        r21   k19 ; k19 = 110
.line	1388	loadk        r22   k20 ; k20 = 92
.line	1388	loadk        r23   k21 ; k21 = 6
.line	1388	loadk        r24   k22 ; k22 = 254
.line	1388	loadk        r25   k23 ; k23 = 223
.line	1388	loadk        r26   k24 ; k24 = 136
.line	1388	loadk        r27   k25 ; k25 = 74
.line	1388	loadk        r28   k26 ; k26 = 245
.line	1388	loadk        r29   k27 ; k27 = 53
.line	1388	loadk        r30   k28 ; k28 = 248
.line	1388	loadk        r31   k29 ; k29 = 3
.line	1388	loadk        r32   k30 ; k30 = 151
.line	1388	loadk        r33   k31 ; k31 = 46
.line	1388	loadk        r34   k32 ; k32 = 182
.line	1388	loadk        r35   k33 ; k33 = 251
.line	1388	loadk        r36   k34 ; k34 = 214
.line	1388	loadk        r37   k35 ; k35 = 96
.line	1388	loadk        r38   k36 ; k36 = 76
.line	1388	loadk        r39   k37 ; k37 = 37
.line	1388	loadk        r40   k38 ; k38 = 212
.line	1388	loadk        r41   k15 ; k15 = 231
.line	1388	loadk        r42   k39 ; k39 = 190
.line	1388	loadk        r43   k40 ; k40 = 89
.line	1388	loadk        r44   k41 ; k41 = 175
.line	1388	loadk        r45   k42 ; k42 = 21
.line	1388	loadk        r46   k43 ; k43 = 253
.line	1388	loadk        r47   k44 ; k44 = 19
.line	1388	loadk        r48   k11 ; k11 = 200
.line	1388	loadk        r49   k45 ; k45 = 106
.line	1388	call          r9    41     2
.line	1388	getupval     r10    u3
.line	1388	loadk        r11   k46 ; k46 = 84
.line	1388	loadk        r12   k10 ; k10 = 69
.line	1388	loadk        r13   k47 ; k47 = 203
.line	1388	loadk        r14   k48 ; k48 = 112
.line	1388	loadk        r15   k49 ; k49 = 28
.line	1388	loadk        r16   k14 ; k14 = 56
.line	1388	loadk        r17   k50 ; k50 = 232
.line	1388	loadk        r18   k51 ; k51 = 15
.line	1388	loadk        r19   k52 ; k52 = 237
.line	1388	loadk        r20   k53 ; k53 = 143
.line	1388	loadk        r21   k54 ; k54 = 194
.line	1388	loadk        r22   k55 ; k55 = 98
.line	1388	loadk        r23   k56 ; k56 = 75
.line	1388	loadk        r24   k42 ; k42 = 21
.line	1388	loadk        r25   k54 ; k54 = 194
.line	1388	loadk        r26   k57 ; k57 = 229
.line	1388	loadk        r27   k39 ; k39 = 190
.line	1388	loadk        r28   k58 ; k58 = 58
.line	1388	loadk        r29   k59 ; k59 = 242
.line	1388	loadk        r30   k60 ; k60 = 64
.line	1388	call         r10    21     0
.line	1388	setlist       r8     0     1
.line	1388	call          r7     2     2
.line	1388	move          r8    r5
.line	1388	call          r6     3     1
.line	1388	self          r6    r0   k61 ; k61 = "SetWidgetVisible"
.line	1388	gettable      r8    r0   k62 ; k62 = "UIRoot"
.line	1388	gettable      r8    r8   k63 ; k63 = "TextBlock_3"
.line	1388	loadbool      r9     0     0
.line	1388	call          r6     4     1
.line	1388	return        r0     1
.label	l98
.line	1388	move          r0    r0
.line	1388	move          r0    r0
.label	l100
.line	1388	loadbool      r1     0     0
.line	1388	gettabup      r2    u4   k64 ; k64 = "GetBundleState"
.line	1388	gettabup      r3    u5   k65 ; k65 = "PREFETCH_BUNDLE_ID"
.line	1388	call          r2     2     2
.line	1388	gettabup      r3    u2   k66 ; k66 = "Download"
.line	1388	eq             0    r2    r3
.line	1388	jmp            0  l108
.line	1388	loadbool      r1     1     0
.label	l108
.line	1388	test          r1     1
.line	1388	jmp            0  l270
.line	1388	gettabup      r2    u0    k3 ; k3 = "pairs"
.line	1388	gettable      r3    r0   k67 ; k67 = "bundleData"
.line	1388	call          r2     2     4
.line	1388	jmp            0  l268
.line	1388	gettable      r7    r0    k0 ; k0 = "isFitVersion"
.line	1388	test          r7     0
.line	1388	jmp            0  l193
.line	1388	gettabup      r7    u5   k68 ; k68 = "Enum_BundleID"
.line	1388	gettable      r7    r7   k69 ; k69 = "FitLobbyRes"
.line	1388	eq             0    r5    r7
.line	1388	jmp            0  l193
.line	1388	gettabup      r7    u4   k64 ; k64 = "GetBundleState"
.line	1388	move          r8    r5
.line	1388	call          r7     2     2
.line	1388	gettabup      r8    u2   k66 ; k66 = "Download"
.line	1388	eq             0    r7    r8
.line	1388	jmp            0  l268
.line	1388	loadbool      r1     1     0
.line	1388	gettabup      r8    u0   k70 ; k70 = "log_format"
.line	1388	gettabup      r9    u0    k7 ; k7 = "table"
.line	1388	gettable      r9    r9    k8 ; k8 = "concat"
.line	1388	newtable     r10     1     0
.line	1388	getupval     r11    u3
.line	1388	loadk        r12    k9 ; k9 = 126
.line	1388	loadk        r13   k10 ; k10 = 69
.line	1388	loadk        r14   k11 ; k11 = 200
.line	1388	loadk        r15   k12 ; k12 = 62
.line	1388	loadk        r16   k13 ; k13 = 20
.line	1388	loadk        r17   k14 ; k14 = 56
.line	1388	loadk        r18   k15 ; k15 = 231
.line	1388	loadk        r19   k16 ; k16 = 14
.line	1388	loadk        r20   k17 ; k17 = 156
.line	1388	loadk        r21   k18 ; k18 = 226
.line	1388	loadk        r22   k11 ; k11 = 200
.line	1388	loadk        r23   k19 ; k19 = 110
.line	1388	loadk        r24   k20 ; k20 = 92
.line	1388	loadk        r25   k21 ; k21 = 6
.line	1388	loadk        r26   k22 ; k22 = 254
.line	1388	loadk        r27   k23 ; k23 = 223
.line	1388	loadk        r28   k24 ; k24 = 136
.line	1388	loadk        r29   k25 ; k25 = 74
.line	1388	loadk        r30   k26 ; k26 = 245
.line	1388	loadk        r31   k27 ; k27 = 53
.line	1388	loadk        r32   k28 ; k28 = 248
.line	1388	loadk        r33   k29 ; k29 = 3
.line	1388	loadk        r34   k30 ; k30 = 151
.line	1388	loadk        r35   k31 ; k31 = 46
.line	1388	loadk        r36   k32 ; k32 = 182
.line	1388	loadk        r37   k33 ; k33 = 251
.line	1388	loadk        r38   k34 ; k34 = 214
.line	1388	loadk        r39   k35 ; k35 = 96
.line	1388	loadk        r40   k36 ; k36 = 76
.line	1388	loadk        r41   k37 ; k37 = 37
.line	1388	loadk        r42   k38 ; k38 = 212
.line	1388	loadk        r43   k15 ; k15 = 231
.line	1388	loadk        r44   k39 ; k39 = 190
.line	1388	loadk        r45   k40 ; k40 = 89
.line	1388	loadk        r46   k41 ; k41 = 175
.line	1388	loadk        r47   k42 ; k42 = 21
.line	1388	loadk        r48   k43 ; k43 = 253
.line	1388	loadk        r49   k44 ; k44 = 19
.line	1388	loadk        r50   k11 ; k11 = 200
.line	1388	loadk        r51   k45 ; k45 = 106
.line	1388	call         r11    41     2
.line	1388	getupval     r12    u3
.line	1388	loadk        r13   k71 ; k71 = 88
.line	1388	loadk        r14   k72 ; k72 = 95
.line	1388	loadk        r15   k73 ; k73 = 209
.line	1388	loadk        r16   k74 ; k74 = 52
.line	1388	loadk        r17   k13 ; k13 = 20
.line	1388	loadk        r18   k75 ; k75 = 50
.line	1388	loadk        r19   k76 ; k76 = 207
.line	1388	loadk        r20   k31 ; k31 = 46
.line	1388	loadk        r21   k22 ; k22 = 254
.line	1388	loadk        r22   k77 ; k77 = 138
.line	1388	loadk        r23   k78 ; k78 = 218
.line	1388	call         r12    12     0
.line	1388	setlist      r10     0     1
.line	1388	call          r9     2     2
.line	1388	move         r10    r5
.line	1388	call          r8     3     1
.line	1388	jmp            0  l270
.line	1388	jmp            0  l268
.label	l193
.line	1388	gettabup      r7    u5   k68 ; k68 = "Enum_BundleID"
.line	1388	gettable      r7    r7   k79 ; k79 = "MyAppearance"
.line	1388	eq             1    r5    r7
.line	1388	jmp            0  l268
.line	1388	gettabup      r7    u0   k80 ; k80 = "ipairs"
.line	1388	move          r8    r6
.line	1388	call          r7     2     4
.line	1388	jmp            0  l266
.line	1388	self         r12    r0   k81 ; k81 = "GetItemDataState"
.line	1388	move         r14   r11
.line	1388	call         r12     3     2
.line	1388	gettabup     r13    u2   k66 ; k66 = "Download"
.line	1388	eq             0   r12   r13
.line	1388	jmp            0  l266
.line	1388	loadbool      r1     1     0
.line	1388	gettabup     r13    u0   k70 ; k70 = "log_format"
.line	1388	gettabup     r14    u0    k7 ; k7 = "table"
.line	1388	gettable     r14   r14    k8 ; k8 = "concat"
.line	1388	newtable     r15     1     0
.line	1388	getupval     r16    u3
.line	1388	loadk        r17    k9 ; k9 = 126
.line	1388	loadk        r18   k10 ; k10 = 69
.line	1388	loadk        r19   k11 ; k11 = 200
.line	1388	loadk        r20   k12 ; k12 = 62
.line	1388	loadk        r21   k13 ; k13 = 20
.line	1388	loadk        r22   k14 ; k14 = 56
.line	1388	loadk        r23   k15 ; k15 = 231
.line	1388	loadk        r24   k16 ; k16 = 14
.line	1388	loadk        r25   k17 ; k17 = 156
.line	1388	loadk        r26   k18 ; k18 = 226
.line	1388	loadk        r27   k11 ; k11 = 200
.line	1388	loadk        r28   k19 ; k19 = 110
.line	1388	loadk        r29   k20 ; k20 = 92
.line	1388	loadk        r30   k21 ; k21 = 6
.line	1388	loadk        r31   k22 ; k22 = 254
.line	1388	loadk        r32   k23 ; k23 = 223
.line	1388	loadk        r33   k24 ; k24 = 136
.line	1388	loadk        r34   k25 ; k25 = 74
.line	1388	loadk        r35   k26 ; k26 = 245
.line	1388	loadk        r36   k27 ; k27 = 53
.line	1388	loadk        r37   k28 ; k28 = 248
.line	1388	loadk        r38   k29 ; k29 = 3
.line	1388	loadk        r39   k30 ; k30 = 151
.line	1388	loadk        r40   k31 ; k31 = 46
.line	1388	loadk        r41   k32 ; k32 = 182
.line	1388	loadk        r42   k33 ; k33 = 251
.line	1388	loadk        r43   k34 ; k34 = 214
.line	1388	loadk        r44   k35 ; k35 = 96
.line	1388	loadk        r45   k36 ; k36 = 76
.line	1388	loadk        r46   k37 ; k37 = 37
.line	1388	loadk        r47   k38 ; k38 = 212
.line	1388	loadk        r48   k15 ; k15 = 231
.line	1388	loadk        r49   k39 ; k39 = 190
.line	1388	loadk        r50   k40 ; k40 = 89
.line	1388	loadk        r51   k41 ; k41 = 175
.line	1388	loadk        r52   k42 ; k42 = 21
.line	1388	loadk        r53   k43 ; k43 = 253
.line	1388	loadk        r54   k44 ; k44 = 19
.line	1388	loadk        r55   k11 ; k11 = 200
.line	1388	loadk        r56   k45 ; k45 = 106
.line	1388	call         r16    41     2
.line	1388	getupval     r17    u3
.line	1388	loadk        r18   k36 ; k36 = 76
.line	1388	loadk        r19   k20 ; k20 = 92
.line	1388	loadk        r20   k82 ; k82 = 130
.line	1388	loadk        r21   k83 ; k83 = 117
.line	1388	loadk        r22   k84 ; k84 = 11
.line	1388	call         r17     6     0
.line	1388	setlist      r15     0     1
.line	1388	call         r14     2     2
.line	1388	gettable     r15   r11   k85 ; k85 = "key"
.line	1388	call         r13     3     1
.line	1388	jmp            0  l268
.label	l266
.line	1388	move          r0    r0
.line	1388	move          r0    r0
.label	l268
.line	1388	move          r0    r0
.line	1388	move          r0    r0
.label	l270
.line	1388	gettabup      r2    u6   k86 ; k86 = "isToggleDownloadingA" (truncated)
.line	1388	test          r2     0
.line	1388	jmp            0  l274
.line	1388	loadbool      r1     1     0
.label	l274
.line	1388	self          r2    r0   k61 ; k61 = "SetWidgetVisible"
.line	1388	gettable      r4    r0   k62 ; k62 = "UIRoot"
.line	1388	gettable      r4    r4   k63 ; k63 = "TextBlock_3"
.line	1388	move          r5    r1
.line	1388	call          r2     4     1
.line	1388	test          r1     0
.line	1388	jmp            0  l313
.line	1388	gettable      r2    r0   k62 ; k62 = "UIRoot"
.line	1388	gettable      r2    r2   k63 ; k63 = "TextBlock_3"
.line	1388	self          r2    r2   k87 ; k87 = "SetWidgetVisibility"
.line	1388	gettabup      r4    u0   k88 ; k88 = "UEnums"
.line	1388	gettable      r4    r4   k89 ; k89 = "ESlateVisibility"
.line	1388	gettable      r4    r4   k90 ; k90 = "SelfHitTestInvisible"
.line	1388	call          r2     3     1
.line	1388	gettabup      r2    u0   k91 ; k91 = "GCPufferDownloader"
.line	1388	gettable      r2    r2   k92 ; k92 = "GetCurrentSpeed"
.line	1388	gettabup      r3    u0   k93 ; k93 = "Puffer"
.line	1388	call          r2     2     2
.line	1388	div           r2    r2   k94 ; k94 = 1024
.line	1388	gettabup      r3    u0   k95 ; k95 = "string"
.line	1388	gettable      r3    r3   k96 ; k96 = "format"
.line	1388	getupval      r4    u3
.line	1388	loadk         r5   k97 ; k97 = 31
.line	1388	loadk         r6   k98 ; k98 = 4
.line	1388	loadk         r7   k99 ; k99 = 142
.line	1388	loadk         r8  k100 ; k100 = 54
.line	1388	call          r4     5     2
.line	1388	move          r5    r2
.line	1388	call          r3     3     2
.line	1388	gettabup      r4    u0  k101 ; k101 = "LocUtil"
.line	1388	gettable      r4    r4  k102 ; k102 = "LocalizeResFormat"
.line	1388	loadk         r5  k103 ; k103 = 10341
.line	1388	move          r6    r3
.line	1388	call          r4     3     2
.line	1388	gettable      r5    r0   k62 ; k62 = "UIRoot"
.line	1388	gettable      r5    r5   k63 ; k63 = "TextBlock_3"
.line	1388	self          r5    r5  k104 ; k104 = "SetText"
.line	1388	move          r7    r4
.line	1388	call          r5     3     1
.label	l313
.line	1388	return        r0     1
.line	1388	move          r0    r0
.line	1388	gettabup      r0    u0   k62 ; k62 = "UIRoot"
.line	1388	return        r0     1

.function	main/f63

.source	null
.linedefined	1436
.lastlinedefined	1455
.numparams	1
.is_vararg	0
.maxstacksize	43

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	89
.constant	k2	70
.constant	k3	214
.constant	k4	53
.constant	k5	22
.constant	k6	35
.constant	k7	168
.constant	k8	25
.constant	k9	175
.constant	k10	218
.constant	k11	200
.constant	k12	41
.constant	k13	94
.constant	k14	54
.constant	k15	204
.constant	k16	255
.constant	k17	169
.constant	k18	52
.constant	k19	162
.constant	k20	1
.constant	k21	252
.constant	k22	4
.constant	k23	158
.constant	k24	116
.constant	k25	191
.constant	k26	208
.constant	k27	222
.constant	k28	126
.constant	k29	65
.constant	k30	193
.constant	k31	233
.constant	k32	180
.constant	k33	111
.constant	k34	128
.constant	k35	20
.constant	k36	253
.constant	k37	27
.constant	k38	135
.constant	k39	51
.constant	k40	"GetChoosenZoneDelay"
.constant	k41	10000
.constant	k42	0
.constant	k43	"SetWidgetVisible"
.constant	k44	"UIRoot"
.constant	k45	"WidgetSwitcher_Network"
.constant	k46	"Client"
.constant	k47	"HasActiveWifi"
.constant	k48	"SetActiveWidgetIndex"
.constant	k49	"LocUtil"
.constant	k50	"GetLocalizeResStr"
.constant	k51	320073
.constant	k52	320074
.constant	k53	"UTRichTextBlock_0"
.constant	k54	"SetText"
.constant	k55	"UpdateDownloadSpeed"

.line	1436	gettabup      r1    u0    k0 ; k0 = "require"
.line	1436	getupval      r2    u1
.line	1436	loadk         r3    k1 ; k1 = 89
.line	1436	loadk         r4    k2 ; k2 = 70
.line	1436	loadk         r5    k3 ; k3 = 214
.line	1436	loadk         r6    k4 ; k4 = 53
.line	1436	loadk         r7    k5 ; k5 = 22
.line	1436	loadk         r8    k6 ; k6 = 35
.line	1436	loadk         r9    k7 ; k7 = 168
.line	1436	loadk        r10    k8 ; k8 = 25
.line	1436	loadk        r11    k9 ; k9 = 175
.line	1436	loadk        r12   k10 ; k10 = 218
.line	1436	loadk        r13   k11 ; k11 = 200
.line	1436	loadk        r14   k12 ; k12 = 41
.line	1436	loadk        r15   k13 ; k13 = 94
.line	1436	loadk        r16   k14 ; k14 = 54
.line	1436	loadk        r17   k15 ; k15 = 204
.line	1436	loadk        r18   k16 ; k16 = 255
.line	1436	loadk        r19   k17 ; k17 = 169
.line	1436	loadk        r20   k18 ; k18 = 52
.line	1436	loadk        r21   k19 ; k19 = 162
.line	1436	loadk        r22   k20 ; k20 = 1
.line	1436	loadk        r23   k21 ; k21 = 252
.line	1436	loadk        r24   k22 ; k22 = 4
.line	1436	loadk        r25   k23 ; k23 = 158
.line	1436	loadk        r26   k24 ; k24 = 116
.line	1436	loadk        r27   k25 ; k25 = 191
.line	1436	loadk        r28   k26 ; k26 = 208
.line	1436	loadk        r29   k27 ; k27 = 222
.line	1436	loadk        r30   k28 ; k28 = 126
.line	1436	loadk        r31   k29 ; k29 = 65
.line	1436	loadk        r32    k5 ; k5 = 22
.line	1436	loadk        r33   k30 ; k30 = 193
.line	1436	loadk        r34   k31 ; k31 = 233
.line	1436	loadk        r35   k32 ; k32 = 180
.line	1436	loadk        r36   k33 ; k33 = 111
.line	1436	loadk        r37   k34 ; k34 = 128
.line	1436	loadk        r38   k35 ; k35 = 20
.line	1436	loadk        r39   k36 ; k36 = 253
.line	1436	loadk        r40   k37 ; k37 = 27
.line	1436	loadk        r41   k38 ; k38 = 135
.line	1436	loadk        r42   k39 ; k39 = 51
.line	1436	call          r2    41     2
.line	1436	call          r1     2     2
.line	1436	gettable      r2    r1   k40 ; k40 = "GetChoosenZoneDelay"
.line	1436	loadk         r3   k41 ; k41 = 10000
.line	1436	loadk         r4   k41 ; k41 = 10000
.line	1436	call          r2     3     2
.line	1436	lt             0    r2   k41 ; k41 = 10000
.line	1436	jmp            0   l53
.line	1436	eq             0    r2   k42 ; k42 = 0
.line	1436	jmp            0   l54
.label	l53
.line	1436	loadbool      r3     0     1
.label	l54
.line	1436	loadbool      r3     1     0
.line	1436	getupval      r4    u1
.line	1436	call          r4     1     2
.line	1436	test          r3     0
.line	1436	jmp            0   l91
.line	1436	self          r5    r0   k43 ; k43 = "SetWidgetVisible"
.line	1436	gettable      r7    r0   k44 ; k44 = "UIRoot"
.line	1436	gettable      r7    r7   k45 ; k45 = "WidgetSwitcher_Netwo" (truncated)
.line	1436	loadbool      r8     1     0
.line	1436	call          r5     4     1
.line	1436	gettabup      r5    u0   k46 ; k46 = "Client"
.line	1436	gettable      r5    r5   k47 ; k47 = "HasActiveWifi"
.line	1436	call          r5     1     2
.line	1436	test          r5     0
.line	1436	jmp            0   l80
.line	1436	gettable      r5    r0   k44 ; k44 = "UIRoot"
.line	1436	gettable      r5    r5   k45 ; k45 = "WidgetSwitcher_Netwo" (truncated)
.line	1436	self          r5    r5   k48 ; k48 = "SetActiveWidgetIndex"
.line	1436	loadk         r7   k42 ; k42 = 0
.line	1436	call          r5     3     1
.line	1436	gettabup      r5    u0   k49 ; k49 = "LocUtil"
.line	1436	gettable      r5    r5   k50 ; k50 = "GetLocalizeResStr"
.line	1436	loadk         r6   k51 ; k51 = 320073
.line	1436	call          r5     2     2
.line	1436	move          r4    r5
.line	1436	jmp            0   l96
.label	l80
.line	1436	gettable      r5    r0   k44 ; k44 = "UIRoot"
.line	1436	gettable      r5    r5   k45 ; k45 = "WidgetSwitcher_Netwo" (truncated)
.line	1436	self          r5    r5   k48 ; k48 = "SetActiveWidgetIndex"
.line	1436	loadk         r7   k20 ; k20 = 1
.line	1436	call          r5     3     1
.line	1436	gettabup      r5    u0   k49 ; k49 = "LocUtil"
.line	1436	gettable      r5    r5   k50 ; k50 = "GetLocalizeResStr"
.line	1436	loadk         r6   k52 ; k52 = 320074
.line	1436	call          r5     2     2
.line	1436	move          r4    r5
.line	1436	jmp            0   l96
.label	l91
.line	1436	self          r5    r0   k43 ; k43 = "SetWidgetVisible"
.line	1436	gettable      r7    r0   k44 ; k44 = "UIRoot"
.line	1436	gettable      r7    r7   k45 ; k45 = "WidgetSwitcher_Netwo" (truncated)
.line	1436	loadbool      r8     0     0
.line	1436	call          r5     4     1
.label	l96
.line	1436	gettable      r5    r0   k44 ; k44 = "UIRoot"
.line	1436	gettable      r5    r5   k53 ; k53 = "UTRichTextBlock_0"
.line	1436	self          r5    r5   k54 ; k54 = "SetText"
.line	1436	move          r7    r4
.line	1436	call          r5     3     1
.line	1436	self          r5    r0   k55 ; k55 = "UpdateDownloadSpeed"
.line	1436	call          r5     2     1
.line	1436	return        r0     1
.line	1436	move          r0    r0
.line	1436	move          r0    r0
.line	1436	move          r0    r0
.line	1436	return        r0     1

.function	main/f64

.source	null
.linedefined	1457
.lastlinedefined	1567
.numparams	2
.is_vararg	0
.maxstacksize	61

.upvalue	"_ENV"	13	true
.upvalue	"U1"	0	false
.upvalue	"U2"	5	true
.upvalue	"U3"	1	true
.upvalue	"U4"	6	true

.constant	k0	"IsViewMode"
.constant	k1	"showTabData"
.constant	k2	nil
.constant	k3	0
.constant	k4	"Not"
.constant	k5	468890063
.constant	k6	"IsFitLobbyResPage"
.constant	k7	180157
.constant	k8	"UIRoot"
.constant	k9	"TextBlock_111"
.constant	k10	"SetText"
.constant	k11	"LocUtil"
.constant	k12	"GetLocalizeResStr"
.constant	k13	"TextBlock_138"
.constant	k14	"TextBlock_6"
.constant	k15	"TextBlock_137"
.constant	k16	"slua"
.constant	k17	"getMiliseconds"
.constant	k18	"ipairs"
.constant	k19	"GetItemData"
.constant	k20	"key"
.constant	k21	"EODPackID"
.constant	k22	"UserWardrobe"
.constant	k23	"UserWardrobeUpdateTime"
.constant	k24	1000
.constant	k25	"UpdateItemSize"
.constant	k26	"UserCurEquipment"
.constant	k27	"userEquipmentSize"
.constant	k28	"cSize"
.constant	k29	"isCalculating"
.constant	k30	"tSize"
.constant	k31	"state"
.constant	k32	"Done"
.constant	k33	1
.constant	k34	"Wait"
.constant	k35	"Download"
.constant	k36	"Pause"
.constant	k37	"sumDownloadData"
.constant	k38	"TextBlock_ProgressTips"
.constant	k39	83212
.constant	k40	"SetWidgetVisible"
.constant	k41	"Image_13"
.constant	k42	"WidgetSwitcher_1"
.constant	k43	"SetActiveWidgetIndex"
.constant	k44	3
.constant	k45	"table"
.constant	k46	"concat"
.constant	k47	21
.constant	k48	109
.constant	k49	222
.constant	k50	61
.constant	k51	29
.constant	k52	120
.constant	k53	211
.constant	k54	39
.constant	k55	132
.constant	k56	128
.constant	k57	253
.constant	k58	98
.constant	k59	74
.constant	k60	45
.constant	k61	228
.constant	k62	175
.constant	k63	69
.constant	k64	80
.constant	k65	184
.constant	k66	72
.constant	k67	183
.constant	k68	46
.constant	k69	191
.constant	k70	202
.constant	k71	56
.constant	k72	97
.constant	k73	38
.constant	k74	214
.constant	k75	235
.constant	k76	181
.constant	k77	100
.constant	k78	62
.constant	k79	185
.constant	k80	11
.constant	k81	78
.constant	k82	70
.constant	k83	35
.constant	k84	87
.constant	k85	17
.constant	k86	244
.constant	k87	174
.constant	k88	218
.constant	k89	40
.constant	k90	113
.constant	k91	54
.constant	k92	198
.constant	k93	251
.constant	k94	165
.constant	k95	116
.constant	k96	144
.constant	k97	41
.constant	k98	8
.constant	k99	152
.constant	k100	5
.constant	k101	145
.constant	k102	126
.constant	k103	76
.constant	k104	22
.constant	k105	203
.constant	k106	232
.constant	k107	189
.constant	k108	36
.constant	k109	156
.constant	k110	31
.constant	k111	245
.constant	k112	26
.constant	k113	137
.constant	k114	101
.constant	k115	99
.constant	k116	220
.constant	k117	63
.constant	k118	196
.constant	k119	15
.constant	k120	164
.constant	k121	199
.constant	k122	88
.constant	k123	66
.constant	k124	55
.constant	k125	204
.constant	k126	"GetFormatSizeContent"
.constant	k127	2
.constant	k128	12220
.constant	k129	131
.constant	k130	71
.constant	k131	182
.constant	k132	"ProgressBar_0"
.constant	k133	"SetPercent"
.constant	k134	"SetTexture"
.constant	k135	"Image_43"

.line	1457	self          r2    r0    k0 ; k0 = "IsViewMode"
.line	1457	call          r2     2     2
.line	1457	gettable      r3    r0    k1 ; k1 = "showTabData"
.line	1457	eq             1    r3    k2 ; k2 = nil
.line	1457	jmp            0    l8
.line	1457	test          r2     1
.line	1457	jmp            0   l11
.label	l8
.line	1457	test          r1     1
.line	1457	jmp            0   l11
.line	1457	return        r0     1
.label	l11
.line	1457	loadk         r3    k3 ; k3 = 0
.line	1457	loadk         r4    k3 ; k3 = 0
.line	1457	gettabup      r5    u0    k4 ; k4 = "Not"
.line	1457	loadk         r6    k3 ; k3 = 0
.line	1457	loadk         r7    k3 ; k3 = 0
.line	1457	gettable      r8    r0    k1 ; k1 = "showTabData"
.line	1457	len           r8    r8
.line	1457	loadbool      r9     0     0
.line	1457	loadk        r10    k5 ; k5 = 468890063
.line	1457	self         r11    r0    k6 ; k6 = "IsFitLobbyResPage"
.line	1457	call         r11     2     2
.line	1457	test         r11     0
.line	1457	jmp            0   l25
.line	1457	loadk        r10    k7 ; k7 = 180157
.label	l25
.line	1457	gettable     r11    r0    k8 ; k8 = "UIRoot"
.line	1457	gettable     r11   r11    k9 ; k9 = "TextBlock_111"
.line	1457	self         r11   r11   k10 ; k10 = "SetText"
.line	1457	gettabup     r13    u1   k11 ; k11 = "LocUtil"
.line	1457	gettable     r13   r13   k12 ; k12 = "GetLocalizeResStr"
.line	1457	move         r14   r10
.line	1457	call         r13     2     0
.line	1457	call         r11     0     1
.line	1457	gettable     r11    r0    k8 ; k8 = "UIRoot"
.line	1457	gettable     r11   r11   k13 ; k13 = "TextBlock_138"
.line	1457	self         r11   r11   k10 ; k10 = "SetText"
.line	1457	gettabup     r13    u1   k11 ; k11 = "LocUtil"
.line	1457	gettable     r13   r13   k12 ; k12 = "GetLocalizeResStr"
.line	1457	move         r14   r10
.line	1457	call         r13     2     0
.line	1457	call         r11     0     1
.line	1457	gettable     r11    r0    k8 ; k8 = "UIRoot"
.line	1457	gettable     r11   r11   k14 ; k14 = "TextBlock_6"
.line	1457	self         r11   r11   k10 ; k10 = "SetText"
.line	1457	gettabup     r13    u1   k11 ; k11 = "LocUtil"
.line	1457	gettable     r13   r13   k12 ; k12 = "GetLocalizeResStr"
.line	1457	move         r14   r10
.line	1457	call         r13     2     0
.line	1457	call         r11     0     1
.line	1457	gettable     r11    r0    k8 ; k8 = "UIRoot"
.line	1457	gettable     r11   r11   k15 ; k15 = "TextBlock_137"
.line	1457	self         r11   r11   k10 ; k10 = "SetText"
.line	1457	gettabup     r13    u1   k11 ; k11 = "LocUtil"
.line	1457	gettable     r13   r13   k12 ; k12 = "GetLocalizeResStr"
.line	1457	move         r14   r10
.line	1457	call         r13     2     0
.line	1457	call         r11     0     1
.line	1457	gettabup     r11    u1   k16 ; k16 = "slua"
.line	1457	gettable     r11   r11   k17 ; k17 = "getMiliseconds"
.line	1457	call         r11     1     2
.line	1457	gettabup     r12    u1   k18 ; k18 = "ipairs"
.line	1457	gettable     r13    r0    k1 ; k1 = "showTabData"
.line	1457	call         r12     2     4
.line	1457	jmp            0  l121
.line	1457	self         r17    r0   k19 ; k19 = "GetItemData"
.line	1457	move         r19   r16
.line	1457	call         r17     3     2
.line	1457	gettable     r18   r17   k20 ; k20 = "key"
.line	1457	gettabup     r19    u2   k21 ; k21 = "EODPackID"
.line	1457	gettable     r19   r19   k22 ; k22 = "UserWardrobe"
.line	1457	eq             0   r18   r19
.line	1457	jmp            0   l86
.line	1457	test          r1     1
.line	1457	jmp            0   l86
.line	1457	gettable     r18    r0   k23 ; k23 = "UserWardrobeUpdateTi" (truncated)
.line	1457	test         r18     1
.line	1457	jmp            0   l78
.line	1457	loadk        r18    k3 ; k3 = 0
.label	l78
.line	1457	sub          r19   r11   r18
.line	1457	lt             0   k24   r19 ; k24 = 1000
.line	1457	jmp            0   l96
.line	1457	settable      r0   k23   r11 ; k23 = "UserWardrobeUpdateTi" (truncated)
.line	1457	self         r19    r0   k25 ; k25 = "UpdateItemSize"
.line	1457	move         r21   r17
.line	1457	call         r19     3     1
.line	1457	jmp            0   l96
.label	l86
.line	1457	self         r18    r0   k25 ; k25 = "UpdateItemSize"
.line	1457	move         r20   r17
.line	1457	call         r18     3     1
.line	1457	gettable     r18   r17   k20 ; k20 = "key"
.line	1457	gettabup     r19    u2   k21 ; k21 = "EODPackID"
.line	1457	gettable     r19   r19   k26 ; k26 = "UserCurEquipment"
.line	1457	eq             0   r18   r19
.line	1457	jmp            0   l96
.line	1457	gettable     r18   r17   k28 ; k28 = "cSize"
.line	1457	settable      r0   k27   r18 ; k27 = "userEquipmentSize"
.label	l96
.line	1457	gettable     r18   r17   k29 ; k29 = "isCalculating"
.line	1457	test         r18     0
.line	1457	jmp            0  l100
.line	1457	loadbool      r9     1     0
.label	l100
.line	1457	test          r2     0
.line	1457	jmp            0  l112
.line	1457	gettable     r18   r17   k20 ; k20 = "key"
.line	1457	gettabup     r19    u2   k21 ; k21 = "EODPackID"
.line	1457	gettable     r19   r19   k26 ; k26 = "UserCurEquipment"
.line	1457	eq             1   r18   r19
.line	1457	jmp            0  l121
.line	1457	gettable     r18   r17   k28 ; k28 = "cSize"
.line	1457	add           r6    r6   r18
.line	1457	gettable     r18   r17   k30 ; k30 = "tSize"
.line	1457	add           r7    r7   r18
.line	1457	jmp            0  l121
.label	l112
.line	1457	gettable     r18   r17   k20 ; k20 = "key"
.line	1457	gettabup     r19    u2   k21 ; k21 = "EODPackID"
.line	1457	gettable     r19   r19   k22 ; k22 = "UserWardrobe"
.line	1457	eq             1   r18   r19
.line	1457	jmp            0  l121
.line	1457	gettable     r18   r17   k28 ; k28 = "cSize"
.line	1457	add           r6    r6   r18
.line	1457	gettable     r18   r17   k30 ; k30 = "tSize"
.line	1457	add           r7    r7   r18
.label	l121
.line	1457	move          r0    r0
.line	1457	move          r0    r0
.line	1457	test          r9     1
.line	1457	jmp            0  l170
.line	1457	gettabup     r12    u1   k18 ; k18 = "ipairs"
.line	1457	gettable     r13    r0    k1 ; k1 = "showTabData"
.line	1457	call         r12     2     4
.line	1457	jmp            0  l168
.line	1457	self         r17    r0   k19 ; k19 = "GetItemData"
.line	1457	move         r19   r16
.line	1457	call         r17     3     2
.line	1457	gettable     r18   r17   k31 ; k31 = "state"
.line	1457	gettabup     r19    u0   k32 ; k32 = "Done"
.line	1457	eq             0   r18   r19
.line	1457	jmp            0  l137
.line	1457	add           r3    r3   k33 ; k33 = 1
.label	l137
.line	1457	gettabup     r19    u0   k34 ; k34 = "Wait"
.line	1457	eq             0   r18   r19
.line	1457	jmp            0  l141
.line	1457	add           r4    r4   k33 ; k33 = 1
.label	l141
.line	1457	gettabup     r19    u0   k35 ; k35 = "Download"
.line	1457	eq             0   r18   r19
.line	1457	jmp            0  l147
.line	1457	gettabup      r5    u0   k35 ; k35 = "Download"
.line	1457	jmp            0  l170
.line	1457	jmp            0  l162
.label	l147
.line	1457	gettabup     r19    u0   k36 ; k36 = "Pause"
.line	1457	eq             0   r18   r19
.line	1457	jmp            0  l152
.line	1457	gettabup      r5    u0   k36 ; k36 = "Pause"
.line	1457	jmp            0  l162
.label	l152
.line	1457	eq             0    r3    r8
.line	1457	jmp            0  l156
.line	1457	gettabup      r5    u0   k32 ; k32 = "Done"
.line	1457	jmp            0  l162
.label	l156
.line	1457	sub          r19   r15    r3
.line	1457	eq             0    r4   r19
.line	1457	jmp            0  l161
.line	1457	gettabup      r5    u0   k34 ; k34 = "Wait"
.line	1457	jmp            0  l162
.label	l161
.line	1457	gettabup      r5    u0   k36 ; k36 = "Pause"
.label	l162
.line	1457	eq             0    r6    k3 ; k3 = 0
.line	1457	jmp            0  l168
.line	1457	gettabup     r19    u0   k34 ; k34 = "Wait"
.line	1457	eq             1    r5   r19
.line	1457	jmp            0  l168
.line	1457	gettabup      r5    u0    k4 ; k4 = "Not"
.label	l168
.line	1457	move          r0    r0
.line	1457	move          r0    r0
.label	l170
.line	1457	gettable     r12    r0   k37 ; k37 = "sumDownloadData"
.line	1457	settable     r12   k29    r9 ; k29 = "isCalculating"
.line	1457	gettable     r12    r0   k37 ; k37 = "sumDownloadData"
.line	1457	settable     r12   k31    r5 ; k31 = "state"
.line	1457	gettable     r12    r0   k37 ; k37 = "sumDownloadData"
.line	1457	settable     r12   k28    r6 ; k28 = "cSize"
.line	1457	gettable     r12    r0   k37 ; k37 = "sumDownloadData"
.line	1457	settable     r12   k30    r7 ; k30 = "tSize"
.line	1457	test          r9     0
.line	1457	jmp            0  l199
.line	1457	gettable     r12    r0    k8 ; k8 = "UIRoot"
.line	1457	gettable     r12   r12   k38 ; k38 = "TextBlock_ProgressTi" (truncated)
.line	1457	self         r12   r12   k10 ; k10 = "SetText"
.line	1457	gettabup     r14    u1   k11 ; k11 = "LocUtil"
.line	1457	gettable     r14   r14   k12 ; k12 = "GetLocalizeResStr"
.line	1457	loadk        r15   k39 ; k39 = 83212
.line	1457	call         r14     2     0
.line	1457	call         r12     0     1
.line	1457	self         r12    r0   k40 ; k40 = "SetWidgetVisible"
.line	1457	gettable     r14    r0    k8 ; k8 = "UIRoot"
.line	1457	gettable     r14   r14   k41 ; k41 = "Image_13"
.line	1457	loadbool     r15     0     0
.line	1457	call         r12     4     1
.line	1457	gettable     r12    r0    k8 ; k8 = "UIRoot"
.line	1457	gettable     r12   r12   k42 ; k42 = "WidgetSwitcher_1"
.line	1457	self         r12   r12   k43 ; k43 = "SetActiveWidgetIndex"
.line	1457	loadk        r14   k44 ; k44 = 3
.line	1457	call         r12     3     1
.line	1457	return        r0     1
.label	l199
.line	1457	loadk        r12    k3 ; k3 = 0
.line	1457	gettabup     r13    u1   k45 ; k45 = "table"
.line	1457	gettable     r13   r13   k46 ; k46 = "concat"
.line	1457	newtable     r14     2     0
.line	1457	getupval     r15    u3
.line	1457	loadk        r16   k47 ; k47 = 21
.line	1457	loadk        r17   k48 ; k48 = 109
.line	1457	loadk        r18   k49 ; k49 = 222
.line	1457	loadk        r19   k50 ; k50 = 61
.line	1457	loadk        r20   k51 ; k51 = 29
.line	1457	loadk        r21   k52 ; k52 = 120
.line	1457	loadk        r22   k53 ; k53 = 211
.line	1457	loadk        r23   k54 ; k54 = 39
.line	1457	loadk        r24   k55 ; k55 = 132
.line	1457	loadk        r25   k56 ; k56 = 128
.line	1457	loadk        r26   k57 ; k57 = 253
.line	1457	loadk        r27   k58 ; k58 = 98
.line	1457	loadk        r28   k59 ; k59 = 74
.line	1457	loadk        r29   k60 ; k60 = 45
.line	1457	loadk        r30   k49 ; k49 = 222
.line	1457	loadk        r31   k61 ; k61 = 228
.line	1457	loadk        r32   k62 ; k62 = 175
.line	1457	loadk        r33   k63 ; k63 = 69
.line	1457	loadk        r34   k57 ; k57 = 253
.line	1457	loadk        r35   k64 ; k64 = 80
.line	1457	loadk        r36   k65 ; k65 = 184
.line	1457	loadk        r37   k66 ; k66 = 72
.line	1457	loadk        r38   k67 ; k67 = 183
.line	1457	loadk        r39   k68 ; k68 = 46
.line	1457	loadk        r40   k69 ; k69 = 191
.line	1457	loadk        r41   k49 ; k49 = 222
.line	1457	loadk        r42   k70 ; k70 = 202
.line	1457	loadk        r43   k71 ; k71 = 56
.line	1457	loadk        r44   k72 ; k72 = 97
.line	1457	loadk        r45   k73 ; k73 = 38
.line	1457	loadk        r46   k74 ; k74 = 214
.line	1457	loadk        r47   k75 ; k75 = 235
.line	1457	loadk        r48   k76 ; k76 = 181
.line	1457	loadk        r49   k77 ; k77 = 100
.line	1457	loadk        r50   k56 ; k56 = 128
.line	1457	loadk        r51   k78 ; k78 = 62
.line	1457	loadk        r52   k57 ; k57 = 253
.line	1457	loadk        r53    k3 ; k3 = 0
.line	1457	loadk        r54   k79 ; k79 = 185
.line	1457	loadk        r55   k80 ; k80 = 11
.line	1457	call         r15    41     2
.line	1457	getupval     r16    u3
.line	1457	loadk        r17   k81 ; k81 = 78
.line	1457	loadk        r18   k82 ; k82 = 70
.line	1457	loadk        r19   k49 ; k49 = 222
.line	1457	loadk        r20   k83 ; k83 = 35
.line	1457	loadk        r21   k84 ; k84 = 87
.line	1457	loadk        r22   k85 ; k85 = 17
.line	1457	loadk        r23   k86 ; k86 = 244
.line	1457	loadk        r24   k80 ; k80 = 11
.line	1457	loadk        r25   k87 ; k87 = 174
.line	1457	loadk        r26   k70 ; k70 = 202
.line	1457	loadk        r27   k88 ; k88 = 218
.line	1457	loadk        r28   k89 ; k89 = 40
.line	1457	loadk        r29   k90 ; k90 = 113
.line	1457	loadk        r30   k91 ; k91 = 54
.line	1457	loadk        r31   k92 ; k92 = 198
.line	1457	loadk        r32   k93 ; k93 = 251
.line	1457	loadk        r33   k94 ; k94 = 165
.line	1457	loadk        r34   k95 ; k95 = 116
.line	1457	loadk        r35   k96 ; k96 = 144
.line	1457	loadk        r36   k97 ; k97 = 41
.line	1457	loadk        r37   k75 ; k75 = 235
.line	1457	loadk        r38   k98 ; k98 = 8
.line	1457	loadk        r39   k99 ; k99 = 152
.line	1457	loadk        r40  k100 ; k100 = 5
.line	1457	loadk        r41  k101 ; k101 = 145
.line	1457	loadk        r42   k88 ; k88 = 218
.line	1457	loadk        r43   k49 ; k49 = 222
.line	1457	loadk        r44  k102 ; k102 = 126
.line	1457	loadk        r45  k103 ; k103 = 76
.line	1457	loadk        r46  k104 ; k104 = 22
.line	1457	loadk        r47  k105 ; k105 = 203
.line	1457	loadk        r48  k106 ; k106 = 232
.line	1457	loadk        r49  k107 ; k107 = 189
.line	1457	loadk        r50  k108 ; k108 = 36
.line	1457	loadk        r51  k109 ; k109 = 156
.line	1457	loadk        r52  k110 ; k110 = 31
.line	1457	loadk        r53  k111 ; k111 = 245
.line	1457	loadk        r54  k112 ; k112 = 26
.line	1457	loadk        r55  k113 ; k113 = 137
.line	1457	loadk        r56  k108 ; k108 = 36
.line	1457	call         r16    41     2
.line	1457	getupval     r17    u3
.line	1457	loadk        r18  k114 ; k114 = 101
.line	1457	loadk        r19  k115 ; k115 = 99
.line	1457	loadk        r20  k116 ; k116 = 220
.line	1457	loadk        r21  k117 ; k117 = 63
.line	1457	loadk        r22  k104 ; k104 = 22
.line	1457	loadk        r23   k98 ; k98 = 8
.line	1457	loadk        r24  k118 ; k118 = 196
.line	1457	loadk        r25  k119 ; k119 = 15
.line	1457	loadk        r26  k120 ; k120 = 164
.line	1457	loadk        r27   k92 ; k92 = 198
.line	1457	loadk        r28  k121 ; k121 = 199
.line	1457	loadk        r29  k122 ; k122 = 88
.line	1457	loadk        r30  k123 ; k123 = 66
.line	1457	loadk        r31  k124 ; k124 = 55
.line	1457	loadk        r32  k125 ; k125 = 204
.line	1457	call         r17    16     0
.line	1457	setlist      r14     0     1
.line	1457	call         r13     2     2
.line	1457	gettabup     r14    u0    k4 ; k4 = "Not"
.line	1457	eq             1    r5   r14
.line	1457	jmp            0  l311
.line	1457	testset      r14    r5     1
.line	1457	jmp            0  l312
.label	l311
.line	1457	gettabup     r14    u0   k35 ; k35 = "Download"
.label	l312
.line	1457	gettabup     r15    u4  k126 ; k126 = "GetFormatSizeContent"
.line	1457	move         r16    r6
.line	1457	move         r17    r7
.line	1457	move         r18   r14
.line	1457	call         r15     4     2
.line	1457	loadbool     r16     0     0
.line	1457	gettabup     r17    u0    k4 ; k4 = "Not"
.line	1457	eq             0    r5   r17
.line	1457	jmp            0  l327
.line	1457	gettable     r17    r0    k8 ; k8 = "UIRoot"
.line	1457	gettable     r17   r17   k38 ; k38 = "TextBlock_ProgressTi" (truncated)
.line	1457	self         r17   r17   k10 ; k10 = "SetText"
.line	1457	move         r19   r15
.line	1457	call         r17     3     1
.line	1457	jmp            0  l462
.label	l327
.line	1457	gettabup     r17    u0   k32 ; k32 = "Done"
.line	1457	eq             0    r5   r17
.line	1457	jmp            0  l345
.line	1457	loadk        r12  k127 ; k127 = 2
.line	1457	self         r17    r0   k40 ; k40 = "SetWidgetVisible"
.line	1457	gettable     r19    r0    k8 ; k8 = "UIRoot"
.line	1457	gettable     r19   r19   k41 ; k41 = "Image_13"
.line	1457	loadbool     r20     1     0
.line	1457	call         r17     4     1
.line	1457	gettable     r17    r0    k8 ; k8 = "UIRoot"
.line	1457	gettable     r17   r17   k38 ; k38 = "TextBlock_ProgressTi" (truncated)
.line	1457	self         r17   r17   k10 ; k10 = "SetText"
.line	1457	gettabup     r19    u1   k11 ; k11 = "LocUtil"
.line	1457	gettable     r19   r19   k12 ; k12 = "GetLocalizeResStr"
.line	1457	loadk        r20  k128 ; k128 = 12220
.line	1457	call         r19     2     0
.line	1457	call         r17     0     1
.line	1457	jmp            0  l462
.label	l345
.line	1457	gettabup     r17    u0   k35 ; k35 = "Download"
.line	1457	eq             0    r5   r17
.line	1457	jmp            0  l455
.line	1457	gettabup     r17    u1   k45 ; k45 = "table"
.line	1457	gettable     r17   r17   k46 ; k46 = "concat"
.line	1457	newtable     r18     2     0
.line	1457	getupval     r19    u3
.line	1457	loadk        r20   k47 ; k47 = 21
.line	1457	loadk        r21   k48 ; k48 = 109
.line	1457	loadk        r22   k49 ; k49 = 222
.line	1457	loadk        r23   k50 ; k50 = 61
.line	1457	loadk        r24   k51 ; k51 = 29
.line	1457	loadk        r25   k52 ; k52 = 120
.line	1457	loadk        r26   k53 ; k53 = 211
.line	1457	loadk        r27   k54 ; k54 = 39
.line	1457	loadk        r28   k55 ; k55 = 132
.line	1457	loadk        r29   k56 ; k56 = 128
.line	1457	loadk        r30   k57 ; k57 = 253
.line	1457	loadk        r31   k58 ; k58 = 98
.line	1457	loadk        r32   k59 ; k59 = 74
.line	1457	loadk        r33   k60 ; k60 = 45
.line	1457	loadk        r34   k49 ; k49 = 222
.line	1457	loadk        r35   k61 ; k61 = 228
.line	1457	loadk        r36   k62 ; k62 = 175
.line	1457	loadk        r37   k63 ; k63 = 69
.line	1457	loadk        r38   k57 ; k57 = 253
.line	1457	loadk        r39   k64 ; k64 = 80
.line	1457	loadk        r40   k65 ; k65 = 184
.line	1457	loadk        r41   k66 ; k66 = 72
.line	1457	loadk        r42   k67 ; k67 = 183
.line	1457	loadk        r43   k68 ; k68 = 46
.line	1457	loadk        r44   k69 ; k69 = 191
.line	1457	loadk        r45   k49 ; k49 = 222
.line	1457	loadk        r46   k70 ; k70 = 202
.line	1457	loadk        r47   k71 ; k71 = 56
.line	1457	loadk        r48   k72 ; k72 = 97
.line	1457	loadk        r49   k73 ; k73 = 38
.line	1457	loadk        r50   k74 ; k74 = 214
.line	1457	loadk        r51   k75 ; k75 = 235
.line	1457	loadk        r52   k76 ; k76 = 181
.line	1457	loadk        r53   k77 ; k77 = 100
.line	1457	loadk        r54   k56 ; k56 = 128
.line	1457	loadk        r55   k78 ; k78 = 62
.line	1457	loadk        r56   k57 ; k57 = 253
.line	1457	loadk        r57    k3 ; k3 = 0
.line	1457	loadk        r58   k79 ; k79 = 185
.line	1457	loadk        r59   k80 ; k80 = 11
.line	1457	call         r19    41     2
.line	1457	getupval     r20    u3
.line	1457	loadk        r21   k81 ; k81 = 78
.line	1457	loadk        r22   k82 ; k82 = 70
.line	1457	loadk        r23   k49 ; k49 = 222
.line	1457	loadk        r24   k83 ; k83 = 35
.line	1457	loadk        r25   k84 ; k84 = 87
.line	1457	loadk        r26   k85 ; k85 = 17
.line	1457	loadk        r27   k86 ; k86 = 244
.line	1457	loadk        r28   k80 ; k80 = 11
.line	1457	loadk        r29   k87 ; k87 = 174
.line	1457	loadk        r30   k70 ; k70 = 202
.line	1457	loadk        r31   k88 ; k88 = 218
.line	1457	loadk        r32   k89 ; k89 = 40
.line	1457	loadk        r33   k90 ; k90 = 113
.line	1457	loadk        r34   k91 ; k91 = 54
.line	1457	loadk        r35   k92 ; k92 = 198
.line	1457	loadk        r36   k93 ; k93 = 251
.line	1457	loadk        r37   k94 ; k94 = 165
.line	1457	loadk        r38   k95 ; k95 = 116
.line	1457	loadk        r39   k96 ; k96 = 144
.line	1457	loadk        r40   k97 ; k97 = 41
.line	1457	loadk        r41   k75 ; k75 = 235
.line	1457	loadk        r42   k98 ; k98 = 8
.line	1457	loadk        r43   k99 ; k99 = 152
.line	1457	loadk        r44  k100 ; k100 = 5
.line	1457	loadk        r45  k129 ; k129 = 131
.line	1457	loadk        r46   k49 ; k49 = 222
.line	1457	loadk        r47  k125 ; k125 = 204
.line	1457	loadk        r48   k77 ; k77 = 100
.line	1457	loadk        r49  k130 ; k130 = 71
.line	1457	loadk        r50  k104 ; k104 = 22
.line	1457	loadk        r51  k105 ; k105 = 203
.line	1457	loadk        r52  k106 ; k106 = 232
.line	1457	loadk        r53  k107 ; k107 = 189
.line	1457	loadk        r54  k108 ; k108 = 36
.line	1457	loadk        r55  k109 ; k109 = 156
.line	1457	loadk        r56  k110 ; k110 = 31
.line	1457	loadk        r57  k111 ; k111 = 245
.line	1457	loadk        r58  k112 ; k112 = 26
.line	1457	loadk        r59  k113 ; k113 = 137
.line	1457	loadk        r60  k108 ; k108 = 36
.line	1457	call         r20    41     2
.line	1457	getupval     r21    u3
.line	1457	loadk        r22  k114 ; k114 = 101
.line	1457	loadk        r23  k115 ; k115 = 99
.line	1457	loadk        r24  k116 ; k116 = 220
.line	1457	loadk        r25  k117 ; k117 = 63
.line	1457	loadk        r26  k104 ; k104 = 22
.line	1457	loadk        r27   k98 ; k98 = 8
.line	1457	loadk        r28   k74 ; k74 = 214
.line	1457	loadk        r29   k80 ; k80 = 11
.line	1457	loadk        r30  k131 ; k131 = 182
.line	1457	loadk        r31  k116 ; k116 = 220
.line	1457	loadk        r32  k125 ; k125 = 204
.line	1457	loadk        r33  k122 ; k122 = 88
.line	1457	loadk        r34  k123 ; k123 = 66
.line	1457	loadk        r35  k124 ; k124 = 55
.line	1457	loadk        r36  k125 ; k125 = 204
.line	1457	call         r21    16     0
.line	1457	setlist      r18     0     1
.line	1457	call         r17     2     2
.line	1457	move         r13   r17
.label	l455
.line	1457	loadk        r12   k33 ; k33 = 1
.line	1457	gettable     r17    r0    k8 ; k8 = "UIRoot"
.line	1457	gettable     r17   r17   k38 ; k38 = "TextBlock_ProgressTi" (truncated)
.line	1457	self         r17   r17   k10 ; k10 = "SetText"
.line	1457	move         r19   r15
.line	1457	call         r17     3     1
.line	1457	loadbool     r16     1     0
.label	l462
.line	1457	self         r17    r0   k40 ; k40 = "SetWidgetVisible"
.line	1457	gettable     r19    r0    k8 ; k8 = "UIRoot"
.line	1457	gettable     r19   r19  k132 ; k132 = "ProgressBar_0"
.line	1457	move         r20   r16
.line	1457	call         r17     4     1
.line	1457	test         r16     0
.line	1457	jmp            0  l474
.line	1457	gettable     r17    r0    k8 ; k8 = "UIRoot"
.line	1457	gettable     r17   r17  k132 ; k132 = "ProgressBar_0"
.line	1457	self         r17   r17  k133 ; k133 = "SetPercent"
.line	1457	div          r19    r6    r7
.line	1457	call         r17     3     1
.label	l474
.line	1457	self         r17    r0  k134 ; k134 = "SetTexture"
.line	1457	gettable     r19    r0    k8 ; k8 = "UIRoot"
.line	1457	gettable     r19   r19  k135 ; k135 = "Image_43"
.line	1457	move         r20   r13
.line	1457	call         r17     4     1
.line	1457	gettable     r17    r0    k8 ; k8 = "UIRoot"
.line	1457	gettable     r17   r17   k42 ; k42 = "WidgetSwitcher_1"
.line	1457	self         r17   r17   k43 ; k43 = "SetActiveWidgetIndex"
.line	1457	move         r19   r12
.line	1457	call         r17     3     1
.line	1457	return        r0     1
.line	1457	move          r0    r0
.line	1457	move          r0    r0
.line	1457	move          r0    r0
.line	1457	gettabup      r3    u0  k119 ; k119 = 15
.line	1457	return        r0     1

.function	main/f65

.source	null
.linedefined	1569
.lastlinedefined	1574
.numparams	1
.is_vararg	0
.maxstacksize	6

.constant	k0	"isRecommendPage"
.constant	k1	"OnVerticalTextTabSelectedCallback"
.constant	k2	"curVerTabIndex"

.line	1569	gettable      r1    r0    k0 ; k0 = "isRecommendPage"
.line	1569	test          r1     1
.line	1569	jmp            0    l5
.line	1569	return        r0     1
.label	l5
.line	1569	self          r1    r0    k1 ; k1 = "OnVerticalTextTabSel" (truncated)
.line	1569	gettable      r3    r0    k2 ; k2 = "curVerTabIndex"
.line	1569	gettable      r4    r0    k2 ; k2 = "curVerTabIndex"
.line	1569	loadbool      r5     0     0
.line	1569	call          r1     5     1
.line	1569	return        r0     1
.line	1569	move          r0    r0
.line	1569	move          r0    r0
.line	1569	move          r0    r0
.line	1569	move          r0    r0
.line	1569	return        r0     1

.function	main/f66

.source	null
.linedefined	1576
.lastlinedefined	1606
.numparams	2
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	3	true
.upvalue	"U3"	6	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	126
.constant	k5	69
.constant	k6	200
.constant	k7	62
.constant	k8	20
.constant	k9	56
.constant	k10	231
.constant	k11	14
.constant	k12	156
.constant	k13	226
.constant	k14	110
.constant	k15	92
.constant	k16	6
.constant	k17	254
.constant	k18	223
.constant	k19	136
.constant	k20	74
.constant	k21	245
.constant	k22	53
.constant	k23	248
.constant	k24	3
.constant	k25	151
.constant	k26	46
.constant	k27	182
.constant	k28	234
.constant	k29	240
.constant	k30	67
.constant	k31	91
.constant	k32	57
.constant	k33	222
.constant	k34	168
.constant	k35	250
.constant	k36	166
.constant	k37	0
.constant	k38	253
.constant	k39	195
.constant	k40	"tostring"
.constant	k41	"uiType"
.constant	k42	"View"
.constant	k43	"PauseAllDownloadTasks"
.constant	k44	"SetWidgetVisible"
.constant	k45	"UIRoot"
.constant	k46	"Button_Setting"
.constant	k47	"Button_Delete"
.constant	k48	"Button_15"
.constant	k49	"CanvasPanel_25"
.constant	k50	"UpdateAutoDownloadIcon"
.constant	k51	"CanvasPanel_17"
.constant	k52	"HorizontalBox_2"
.constant	k53	"WidgetSwitcher_2"
.constant	k54	"SetActiveWidgetIndex"
.constant	k55	1
.constant	k56	"WidgetSwitcher_4"
.constant	k57	"SelectTopTab"
.constant	k58	"topTabIndex"
.constant	k59	"IsViewMode"
.constant	k60	"ShowDownload_Loading_Item_UIBP"
.constant	k61	"Common_Tab_Vertical_LevelOne_Text_UIBP"
.constant	k62	"ExtendedLoopScrollBox_Tab"
.constant	k63	"RefreshAllItems"
.constant	k64	"Common_Tab_Horizontal_LevelOne_Text_UIBP"
.constant	k65	"RefreshItemTabNum"
.constant	k66	"BlockEntrances"
.constant	k67	"UpdateFitVersionUI"

.line	1576	gettabup      r2    u0    k0 ; k0 = "log"
.line	1576	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1576	test          r3     0
.line	1576	jmp            0   l53
.line	1576	gettabup      r3    u0    k2 ; k2 = "string"
.line	1576	gettable      r3    r3    k3 ; k3 = "format"
.line	1576	getupval      r4    u1
.line	1576	loadk         r5    k4 ; k4 = 126
.line	1576	loadk         r6    k5 ; k5 = 69
.line	1576	loadk         r7    k6 ; k6 = 200
.line	1576	loadk         r8    k7 ; k7 = 62
.line	1576	loadk         r9    k8 ; k8 = 20
.line	1576	loadk        r10    k9 ; k9 = 56
.line	1576	loadk        r11   k10 ; k10 = 231
.line	1576	loadk        r12   k11 ; k11 = 14
.line	1576	loadk        r13   k12 ; k12 = 156
.line	1576	loadk        r14   k13 ; k13 = 226
.line	1576	loadk        r15    k6 ; k6 = 200
.line	1576	loadk        r16   k14 ; k14 = 110
.line	1576	loadk        r17   k15 ; k15 = 92
.line	1576	loadk        r18   k16 ; k16 = 6
.line	1576	loadk        r19   k17 ; k17 = 254
.line	1576	loadk        r20   k18 ; k18 = 223
.line	1576	loadk        r21   k19 ; k19 = 136
.line	1576	loadk        r22   k20 ; k20 = 74
.line	1576	loadk        r23   k21 ; k21 = 245
.line	1576	loadk        r24   k22 ; k22 = 53
.line	1576	loadk        r25   k23 ; k23 = 248
.line	1576	loadk        r26   k24 ; k24 = 3
.line	1576	loadk        r27   k25 ; k25 = 151
.line	1576	loadk        r28   k26 ; k26 = 46
.line	1576	loadk        r29   k27 ; k27 = 182
.line	1576	loadk        r30   k28 ; k28 = 234
.line	1576	loadk        r31   k29 ; k29 = 240
.line	1576	loadk        r32   k30 ; k30 = 67
.line	1576	loadk        r33   k31 ; k31 = 91
.line	1576	loadk        r34   k32 ; k32 = 57
.line	1576	loadk        r35   k33 ; k33 = 222
.line	1576	loadk        r36   k34 ; k34 = 168
.line	1576	loadk        r37   k35 ; k35 = 250
.line	1576	loadk        r38    k4 ; k4 = 126
.line	1576	loadk        r39   k36 ; k36 = 166
.line	1576	loadk        r40   k37 ; k37 = 0
.line	1576	loadk        r41   k38 ; k38 = 253
.line	1576	loadk        r42   k20 ; k20 = 74
.line	1576	loadk        r43   k39 ; k39 = 195
.line	1576	loadk        r44   k32 ; k32 = 57
.line	1576	call          r4    41     2
.line	1576	gettabup      r5    u0   k40 ; k40 = "tostring"
.line	1576	move          r6    r1
.line	1576	call          r5     2     0
.line	1576	call          r3     0     2
.label	l53
.line	1576	call          r2     2     1
.line	1576	settable      r0   k41    r1 ; k41 = "uiType"
.line	1576	gettabup      r2    u2   k42 ; k42 = "View"
.line	1576	eq             1    r1    r2
.line	1576	jmp            0   l59
.line	1576	loadbool      r2     0     1
.label	l59
.line	1576	loadbool      r2     1     0
.line	1576	test          r2     1
.line	1576	jmp            0   l64
.line	1576	gettabup      r3    u3   k43 ; k43 = "PauseAllDownloadTask" (truncated)
.line	1576	call          r3     1     1
.label	l64
.line	1576	self          r3    r0   k44 ; k44 = "SetWidgetVisible"
.line	1576	gettable      r5    r0   k45 ; k45 = "UIRoot"
.line	1576	gettable      r5    r5   k46 ; k46 = "Button_Setting"
.line	1576	move          r6    r2
.line	1576	loadbool      r7     1     0
.line	1576	call          r3     5     1
.line	1576	self          r3    r0   k44 ; k44 = "SetWidgetVisible"
.line	1576	gettable      r5    r0   k45 ; k45 = "UIRoot"
.line	1576	gettable      r5    r5   k47 ; k47 = "Button_Delete"
.line	1576	loadbool      r6     0     0
.line	1576	loadbool      r7     1     0
.line	1576	call          r3     5     1
.line	1576	self          r3    r0   k44 ; k44 = "SetWidgetVisible"
.line	1576	gettable      r5    r0   k45 ; k45 = "UIRoot"
.line	1576	gettable      r5    r5   k48 ; k48 = "Button_15"
.line	1576	move          r6    r2
.line	1576	loadbool      r7     1     0
.line	1576	call          r3     5     1
.line	1576	self          r3    r0   k44 ; k44 = "SetWidgetVisible"
.line	1576	gettable      r5    r0   k45 ; k45 = "UIRoot"
.line	1576	gettable      r5    r5   k49 ; k49 = "CanvasPanel_25"
.line	1576	move          r6    r2
.line	1576	call          r3     4     1
.line	1576	self          r3    r0   k50 ; k50 = "UpdateAutoDownloadIc" (truncated)
.line	1576	call          r3     2     1
.line	1576	self          r3    r0   k44 ; k44 = "SetWidgetVisible"
.line	1576	gettable      r5    r0   k45 ; k45 = "UIRoot"
.line	1576	gettable      r5    r5   k51 ; k51 = "CanvasPanel_17"
.line	1576	move          r6    r2
.line	1576	call          r3     4     1
.line	1576	self          r3    r0   k44 ; k44 = "SetWidgetVisible"
.line	1576	gettable      r5    r0   k45 ; k45 = "UIRoot"
.line	1576	gettable      r5    r5   k52 ; k52 = "HorizontalBox_2"
.line	1576	move          r6    r2
.line	1576	call          r3     4     1
.line	1576	gettable      r3    r0   k45 ; k45 = "UIRoot"
.line	1576	gettable      r3    r3   k53 ; k53 = "WidgetSwitcher_2"
.line	1576	self          r3    r3   k54 ; k54 = "SetActiveWidgetIndex"
.line	1576	test          r2     0
.line	1576	jmp            0  l107
.line	1576	loadk         r5   k37 ; k37 = 0
.line	1576	test          r5     1
.line	1576	jmp            0  l108
.label	l107
.line	1576	loadk         r5   k55 ; k55 = 1
.label	l108
.line	1576	call          r3     3     1
.line	1576	gettable      r3    r0   k45 ; k45 = "UIRoot"
.line	1576	gettable      r3    r3   k56 ; k56 = "WidgetSwitcher_4"
.line	1576	self          r3    r3   k54 ; k54 = "SetActiveWidgetIndex"
.line	1576	test          r2     0
.line	1576	jmp            0  l117
.line	1576	loadk         r5   k37 ; k37 = 0
.line	1576	test          r5     1
.line	1576	jmp            0  l118
.label	l117
.line	1576	loadk         r5   k55 ; k55 = 1
.label	l118
.line	1576	call          r3     3     1
.line	1576	self          r3    r0   k57 ; k57 = "SelectTopTab"
.line	1576	gettable      r5    r0   k58 ; k58 = "topTabIndex"
.line	1576	loadbool      r6     1     0
.line	1576	call          r3     4     1
.line	1576	self          r3    r0   k59 ; k59 = "IsViewMode"
.line	1576	call          r3     2     2
.line	1576	test          r3     1
.line	1576	jmp            0  l130
.line	1576	self          r3    r0   k60 ; k60 = "ShowDownload_Loading" (truncated)
.line	1576	closure       r5    f0
.line	1576	call          r3     3     1
.label	l130
.line	1576	gettable      r3    r0   k61 ; k61 = "Common_Tab_Vertical_" (truncated)
.line	1576	test          r3     0
.line	1576	jmp            0  l137
.line	1576	gettable      r3    r0   k61 ; k61 = "Common_Tab_Vertical_" (truncated)
.line	1576	gettable      r3    r3   k62 ; k62 = "ExtendedLoopScrollBo" (truncated)
.line	1576	self          r3    r3   k63 ; k63 = "RefreshAllItems"
.line	1576	call          r3     2     1
.label	l137
.line	1576	gettable      r3    r0   k64 ; k64 = "Common_Tab_Horizonta" (truncated)
.line	1576	test          r3     0
.line	1576	jmp            0  l143
.line	1576	gettable      r3    r0   k64 ; k64 = "Common_Tab_Horizonta" (truncated)
.line	1576	self          r3    r3   k65 ; k65 = "RefreshItemTabNum"
.line	1576	call          r3     2     1
.label	l143
.line	1576	self          r3    r0   k66 ; k66 = "BlockEntrances"
.line	1576	call          r3     2     1
.line	1576	self          r3    r0   k67 ; k67 = "UpdateFitVersionUI"
.line	1576	call          r3     2     1
.line	1576	return        r0     1
.line	1576	move          r0    r0
.line	1576	return        r0     1

.function	main/f66/f0

.source	null
.linedefined	1594
.lastlinedefined	1596
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	true

.constant	k0	"SelectTargetDeleteSize"

.line	1594	getupval      r0    u0
.line	1594	self          r0    r0    k0 ; k0 = "SelectTargetDeleteSi" (truncated)
.line	1594	call          r0     2     1
.line	1594	return        r0     1
.line	1594	move          r0    r0
.line	1594	move          r0    r0
.line	1594	return        r0     1

.function	main/f67

.source	null
.linedefined	1608
.lastlinedefined	1624
.numparams	2
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	22	true
.upvalue	"U3"	21	true

.constant	k0	"type"
.constant	k1	92
.constant	k2	95
.constant	k3	209
.constant	k4	51
.constant	k5	12
.constant	k6	62
.constant	k7	233
.constant	k8	4
.constant	k9	"log_format"
.constant	k10	"table"
.constant	k11	"concat"
.constant	k12	126
.constant	k13	69
.constant	k14	200
.constant	k15	20
.constant	k16	56
.constant	k17	231
.constant	k18	14
.constant	k19	156
.constant	k20	226
.constant	k21	110
.constant	k22	6
.constant	k23	254
.constant	k24	223
.constant	k25	136
.constant	k26	74
.constant	k27	245
.constant	k28	224
.constant	k29	8
.constant	k30	129
.constant	k31	30
.constant	k32	188
.constant	k33	215
.constant	k34	123
.constant	k35	77
.constant	k36	40
.constant	k37	217
.constant	k38	150
.constant	k39	101
.constant	k40	190
.constant	k41	241
.constant	k42	25
.constant	k43	21
.constant	k44	115
.constant	k45	94
.constant	k46	218
.constant	k47	61
.constant	k48	39
.constant	k49	2
.constant	k50	207
.constant	k51	147
.constant	k52	137
.constant	k53	97
.constant	k54	71
.constant	k55	55
.constant	k56	182
.constant	k57	163
.constant	k58	105
.constant	k59	239
.constant	k60	19
.constant	k61	214
.constant	k62	60
.constant	k63	166
.constant	k64	99
.constant	k65	75
.constant	k66	38
.constant	k67	213
.constant	k68	"needCalcData"
.constant	k69	"calcNum"
.constant	k70	"calcIndex"
.constant	k71	"math"
.constant	k72	"ceil"
.constant	k73	1
.constant	k74	100
.constant	k75	93
.constant	k76	44
.constant	k77	197
.constant	k78	142
.constant	k79	117
.constant	k80	184
.constant	k81	220
.constant	k82	155
.constant	k83	63
.constant	k84	238
.constant	k85	154
.constant	k86	202
.constant	k87	"UIManager"
.constant	k88	"ShowUI"
.constant	k89	"UI_Config"
.constant	k90	"Download_Loading_Item_UIBP"

.line	1608	gettabup      r2    u0    k0 ; k0 = "type"
.line	1608	move          r3    r1
.line	1608	call          r2     2     2
.line	1608	getupval      r3    u1
.line	1608	loadk         r4    k1 ; k1 = 92
.line	1608	loadk         r5    k2 ; k2 = 95
.line	1608	loadk         r6    k3 ; k3 = 209
.line	1608	loadk         r7    k4 ; k4 = 51
.line	1608	loadk         r8    k5 ; k5 = 12
.line	1608	loadk         r9    k6 ; k6 = 62
.line	1608	loadk        r10    k7 ; k7 = 233
.line	1608	loadk        r11    k8 ; k8 = 4
.line	1608	call          r3     9     2
.line	1608	eq             1    r2    r3
.line	1608	jmp            0   l99
.line	1608	gettabup      r2    u0    k9 ; k9 = "log_format"
.line	1608	gettabup      r3    u0   k10 ; k10 = "table"
.line	1608	gettable      r3    r3   k11 ; k11 = "concat"
.line	1608	newtable      r4     1     0
.line	1608	getupval      r5    u1
.line	1608	loadk         r6   k12 ; k12 = 126
.line	1608	loadk         r7   k13 ; k13 = 69
.line	1608	loadk         r8   k14 ; k14 = 200
.line	1608	loadk         r9    k6 ; k6 = 62
.line	1608	loadk        r10   k15 ; k15 = 20
.line	1608	loadk        r11   k16 ; k16 = 56
.line	1608	loadk        r12   k17 ; k17 = 231
.line	1608	loadk        r13   k18 ; k18 = 14
.line	1608	loadk        r14   k19 ; k19 = 156
.line	1608	loadk        r15   k20 ; k20 = 226
.line	1608	loadk        r16   k14 ; k14 = 200
.line	1608	loadk        r17   k21 ; k21 = 110
.line	1608	loadk        r18    k1 ; k1 = 92
.line	1608	loadk        r19   k22 ; k22 = 6
.line	1608	loadk        r20   k23 ; k23 = 254
.line	1608	loadk        r21   k24 ; k24 = 223
.line	1608	loadk        r22   k25 ; k25 = 136
.line	1608	loadk        r23   k26 ; k26 = 74
.line	1608	loadk        r24   k27 ; k27 = 245
.line	1608	loadk        r25    k4 ; k4 = 51
.line	1608	loadk        r26   k28 ; k28 = 224
.line	1608	loadk        r27   k29 ; k29 = 8
.line	1608	loadk        r28   k30 ; k30 = 129
.line	1608	loadk        r29   k31 ; k31 = 30
.line	1608	loadk        r30   k32 ; k32 = 188
.line	1608	loadk        r31   k14 ; k14 = 200
.line	1608	loadk        r32   k33 ; k33 = 215
.line	1608	loadk        r33   k34 ; k34 = 123
.line	1608	loadk        r34   k35 ; k35 = 77
.line	1608	loadk        r35   k36 ; k36 = 40
.line	1608	loadk        r36   k24 ; k24 = 223
.line	1608	loadk        r37   k37 ; k37 = 217
.line	1608	loadk        r38   k38 ; k38 = 150
.line	1608	loadk        r39   k39 ; k39 = 101
.line	1608	loadk        r40   k40 ; k40 = 190
.line	1608	loadk        r41   k15 ; k15 = 20
.line	1608	loadk        r42   k41 ; k41 = 241
.line	1608	loadk        r43   k42 ; k42 = 25
.line	1608	loadk        r44   k30 ; k30 = 129
.line	1608	loadk        r45   k43 ; k43 = 21
.line	1608	call          r5    41     2
.line	1608	getupval      r6    u1
.line	1608	loadk         r7   k44 ; k44 = 115
.line	1608	loadk         r8   k45 ; k45 = 94
.line	1608	loadk         r9   k46 ; k46 = 218
.line	1608	loadk        r10   k47 ; k47 = 61
.line	1608	loadk        r11   k48 ; k48 = 39
.line	1608	loadk        r12   k49 ; k49 = 2
.line	1608	loadk        r13   k50 ; k50 = 207
.line	1608	loadk        r14   k36 ; k36 = 40
.line	1608	loadk        r15   k51 ; k51 = 147
.line	1608	loadk        r16   k30 ; k30 = 129
.line	1608	loadk        r17   k52 ; k52 = 137
.line	1608	loadk        r18   k53 ; k53 = 97
.line	1608	loadk        r19   k54 ; k54 = 71
.line	1608	loadk        r20   k55 ; k55 = 55
.line	1608	loadk        r21   k14 ; k14 = 200
.line	1608	loadk        r22   k56 ; k56 = 182
.line	1608	loadk        r23   k57 ; k57 = 163
.line	1608	loadk        r24   k58 ; k58 = 105
.line	1608	loadk        r25   k59 ; k59 = 239
.line	1608	loadk        r26   k18 ; k18 = 14
.line	1608	loadk        r27   k17 ; k17 = 231
.line	1608	loadk        r28   k60 ; k60 = 19
.line	1608	loadk        r29   k61 ; k61 = 214
.line	1608	loadk        r30   k62 ; k62 = 60
.line	1608	loadk        r31   k63 ; k63 = 166
.line	1608	loadk        r32    k3 ; k3 = 209
.line	1608	loadk        r33   k46 ; k46 = 218
.line	1608	loadk        r34   k64 ; k64 = 99
.line	1608	loadk        r35   k65 ; k65 = 75
.line	1608	loadk        r36   k66 ; k66 = 38
.line	1608	loadk        r37   k67 ; k67 = 213
.line	1608	call          r6    32     0
.line	1608	setlist       r4     0     1
.line	1608	call          r3     2     2
.line	1608	call          r2     2     1
.line	1608	return        r0     1
.label	l99
.line	1608	gettable      r2    r0   k68 ; k68 = "needCalcData"
.line	1608	test          r2     0
.line	1608	jmp            0  l205
.line	1608	gettable      r2    r0   k68 ; k68 = "needCalcData"
.line	1608	gettable      r2    r2   k69 ; k69 = "calcNum"
.line	1608	gettable      r3    r0   k68 ; k68 = "needCalcData"
.line	1608	gettable      r3    r3   k70 ; k70 = "calcIndex"
.line	1608	sub           r2    r2    r3
.line	1608	gettabup      r3    u0   k71 ; k71 = "math"
.line	1608	gettable      r3    r3   k72 ; k72 = "ceil"
.line	1608	getupval      r4    u2
.line	1608	mul           r4    r2    r4
.line	1608	getupval      r5    u3
.line	1608	div           r4    r4    r5
.line	1608	call          r3     2     2
.line	1608	lt             0    r3   k73 ; k73 = 1
.line	1608	jmp            0  l117
.line	1608	loadk         r3   k73 ; k73 = 1
.label	l117
.line	1608	gettabup      r4    u0    k9 ; k9 = "log_format"
.line	1608	gettabup      r5    u0   k10 ; k10 = "table"
.line	1608	gettable      r5    r5   k11 ; k11 = "concat"
.line	1608	newtable      r6     1     0
.line	1608	getupval      r7    u1
.line	1608	loadk         r8   k12 ; k12 = 126
.line	1608	loadk         r9   k13 ; k13 = 69
.line	1608	loadk        r10   k14 ; k14 = 200
.line	1608	loadk        r11    k6 ; k6 = 62
.line	1608	loadk        r12   k15 ; k15 = 20
.line	1608	loadk        r13   k16 ; k16 = 56
.line	1608	loadk        r14   k17 ; k17 = 231
.line	1608	loadk        r15   k18 ; k18 = 14
.line	1608	loadk        r16   k19 ; k19 = 156
.line	1608	loadk        r17   k20 ; k20 = 226
.line	1608	loadk        r18   k14 ; k14 = 200
.line	1608	loadk        r19   k21 ; k21 = 110
.line	1608	loadk        r20    k1 ; k1 = 92
.line	1608	loadk        r21   k22 ; k22 = 6
.line	1608	loadk        r22   k23 ; k23 = 254
.line	1608	loadk        r23   k24 ; k24 = 223
.line	1608	loadk        r24   k25 ; k25 = 136
.line	1608	loadk        r25   k26 ; k26 = 74
.line	1608	loadk        r26   k27 ; k27 = 245
.line	1608	loadk        r27    k4 ; k4 = 51
.line	1608	loadk        r28   k28 ; k28 = 224
.line	1608	loadk        r29   k29 ; k29 = 8
.line	1608	loadk        r30   k30 ; k30 = 129
.line	1608	loadk        r31   k31 ; k31 = 30
.line	1608	loadk        r32   k32 ; k32 = 188
.line	1608	loadk        r33   k14 ; k14 = 200
.line	1608	loadk        r34   k33 ; k33 = 215
.line	1608	loadk        r35   k34 ; k34 = 123
.line	1608	loadk        r36   k35 ; k35 = 77
.line	1608	loadk        r37   k36 ; k36 = 40
.line	1608	loadk        r38   k24 ; k24 = 223
.line	1608	loadk        r39   k37 ; k37 = 217
.line	1608	loadk        r40   k38 ; k38 = 150
.line	1608	loadk        r41   k39 ; k39 = 101
.line	1608	loadk        r42   k40 ; k40 = 190
.line	1608	loadk        r43   k15 ; k15 = 20
.line	1608	loadk        r44   k41 ; k41 = 241
.line	1608	loadk        r45   k42 ; k42 = 25
.line	1608	loadk        r46   k30 ; k30 = 129
.line	1608	loadk        r47   k43 ; k43 = 21
.line	1608	call          r7    41     2
.line	1608	getupval      r8    u1
.line	1608	loadk         r9   k44 ; k44 = 115
.line	1608	loadk        r10   k45 ; k45 = 94
.line	1608	loadk        r11   k46 ; k46 = 218
.line	1608	loadk        r12   k47 ; k47 = 61
.line	1608	loadk        r13   k48 ; k48 = 39
.line	1608	loadk        r14   k49 ; k49 = 2
.line	1608	loadk        r15   k50 ; k50 = 207
.line	1608	loadk        r16   k36 ; k36 = 40
.line	1608	loadk        r17   k51 ; k51 = 147
.line	1608	loadk        r18   k30 ; k30 = 129
.line	1608	loadk        r19   k52 ; k52 = 137
.line	1608	loadk        r20   k74 ; k74 = 100
.line	1608	loadk        r21   k75 ; k75 = 93
.line	1608	loadk        r22   k76 ; k76 = 44
.line	1608	loadk        r23   k77 ; k77 = 197
.line	1608	loadk        r24   k20 ; k20 = 226
.line	1608	loadk        r25   k78 ; k78 = 142
.line	1608	loadk        r26   k79 ; k79 = 117
.line	1608	loadk        r27   k80 ; k80 = 184
.line	1608	loadk        r28   k18 ; k18 = 14
.line	1608	loadk        r29   k81 ; k81 = 220
.line	1608	loadk        r30   k18 ; k18 = 14
.line	1608	loadk        r31   k82 ; k82 = 155
.line	1608	loadk        r32   k83 ; k83 = 63
.line	1608	loadk        r33   k84 ; k84 = 238
.line	1608	loadk        r34   k85 ; k85 = 154
.line	1608	loadk        r35   k86 ; k86 = 202
.line	1608	call          r8    28     0
.line	1608	setlist       r6     0     1
.line	1608	call          r5     2     2
.line	1608	move          r6    r3
.line	1608	call          r4     3     1
.line	1608	gettabup      r4    u0   k87 ; k87 = "UIManager"
.line	1608	gettable      r4    r4   k88 ; k88 = "ShowUI"
.line	1608	gettabup      r5    u0   k87 ; k87 = "UIManager"
.line	1608	gettable      r5    r5   k89 ; k89 = "UI_Config"
.line	1608	gettable      r5    r5   k90 ; k90 = "Download_Loading_Ite" (truncated)
.line	1608	move          r6    r3
.line	1608	move          r7    r1
.line	1608	call          r4     4     1
.line	1608	jmp            0  l207
.label	l205
.line	1608	move          r2    r1
.line	1608	call          r2     1     1
.label	l207
.line	1608	return        r0     1
.line	1608	move          r0    r0
.line	1608	return        r0     1

.function	main/f68

.source	null
.linedefined	1626
.lastlinedefined	1628
.numparams	1
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	3	true

.constant	k0	"uiType"
.constant	k1	"View"

.line	1626	gettable      r1    r0    k0 ; k0 = "uiType"
.line	1626	gettabup      r2    u0    k1 ; k1 = "View"
.line	1626	eq             1    r1    r2
.line	1626	jmp            0    l6
.line	1626	loadbool      r1     0     1
.label	l6
.line	1626	loadbool      r1     1     0
.line	1626	return        r1     2
.line	1626	return        r0     1
.line	1626	move          r0    r0
.line	1626	return        r0     1

.function	main/f69

.source	null
.linedefined	1630
.lastlinedefined	1639
.numparams	1
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	0	false

.constant	k0	"IsWoWEditor"
.constant	k1	"SetWidgetVisible"
.constant	k2	"UIRoot"
.constant	k3	"Button_Setting"
.constant	k4	"CanvasPanel_17"
.constant	k5	"CanvasPanel_25"
.constant	k6	"WidgetSwitcher_SmartDownload"
.constant	k7	"Button_2"

.line	1630	gettabup      r1    u0    k0 ; k0 = "IsWoWEditor"
.line	1630	test          r1     1
.line	1630	jmp            0    l5
.line	1630	return        r0     1
.label	l5
.line	1630	self          r1    r0    k1 ; k1 = "SetWidgetVisible"
.line	1630	gettable      r3    r0    k2 ; k2 = "UIRoot"
.line	1630	gettable      r3    r3    k3 ; k3 = "Button_Setting"
.line	1630	loadbool      r4     0     0
.line	1630	call          r1     4     1
.line	1630	self          r1    r0    k1 ; k1 = "SetWidgetVisible"
.line	1630	gettable      r3    r0    k2 ; k2 = "UIRoot"
.line	1630	gettable      r3    r3    k4 ; k4 = "CanvasPanel_17"
.line	1630	loadbool      r4     0     0
.line	1630	call          r1     4     1
.line	1630	self          r1    r0    k1 ; k1 = "SetWidgetVisible"
.line	1630	gettable      r3    r0    k2 ; k2 = "UIRoot"
.line	1630	gettable      r3    r3    k5 ; k5 = "CanvasPanel_25"
.line	1630	loadbool      r4     0     0
.line	1630	call          r1     4     1
.line	1630	self          r1    r0    k1 ; k1 = "SetWidgetVisible"
.line	1630	gettable      r3    r0    k2 ; k2 = "UIRoot"
.line	1630	gettable      r3    r3    k6 ; k6 = "WidgetSwitcher_Smart" (truncated)
.line	1630	loadbool      r4     0     0
.line	1630	call          r1     4     1
.line	1630	self          r1    r0    k1 ; k1 = "SetWidgetVisible"
.line	1630	gettable      r3    r0    k2 ; k2 = "UIRoot"
.line	1630	gettable      r3    r3    k7 ; k7 = "Button_2"
.line	1630	loadbool      r4     0     0
.line	1630	call          r1     4     1
.line	1630	return        r0     1
.line	1630	move          r0    r0
.line	1630	move          r0    r0
.line	1630	move          r0    r0
.line	1630	return        r0     1

.function	main/f70

.source	"=[V12L:819dd1dbf39c18cd:21038fe40b97fd2c]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f71

.source	"=[V11_@Black_MagicYT BlackMagiYT_LBIND_00]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_0_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f72

.source	"=[V11_@Black_MagicYT BlackMagiYT_SYSC_01]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_1_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f73

.source	"=[V11_@Black_MagicYT BlackMagiYT_MRGE_02]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_2_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f74

.source	"=[V11_@Black_MagicYT BlackMagiYT_POOL_03]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_3_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

