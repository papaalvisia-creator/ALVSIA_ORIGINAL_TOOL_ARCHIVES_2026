local ModeSelection_Sideber_FriendStatus01_Item_UIBP = {}
ModeSelection_Sideber_FriendStatus01_Item_UIBP.Status = {
  Dynamic = 0,
  Playing = 1,
  Recent = 2
}
local C_LIGHTBOARD_BP_PATH = "/Game/UMG/UI_BP/Common/Common_LightBoard_UIBP.Common_LightBoard_UIBP"
local PRAISE_SWITCH_INDEX = {Unliked = 0, Liked = 1}
local AVATAR_MENU_OFFSET_X = -600
local STATE_WIDGET_NAMES = {
  "ModeSelection_Common_Avatar_Item_UIBP",
  "ScaleBox_LightBoard",
  "Text_Name",
  "SizeBox_NicknameFrame",
  "SizeBox_Gender",
  "Common_Gender_UIBP",
  "UnknowPass_ContinuousBuy_BP",
  "PeakGame_RankIntegralLevel_Small_Switch_UIBP",
  "Button_Birthday",
  "UTRichText_Hint",
  "TextBlock_LastTime",
  "Button_Reserve",
  "TextBlock_Reserve",
  "Button_Praise",
  "Switcher_Praise",
  "TextBlock_PraiseValue",
  "TextBlock_Time"
}

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:ctor()
  self._stateWidgets = nil
  self._curUid = nil
  self._curStatus = nil
  self._curData = nil
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:OnInitialize()
  self._stateWidgets = {}
  for _, status in ipairs({
    self.Status.Dynamic,
    self.Status.Playing,
    self.Status.Recent
  }) do
    self._stateWidgets[status] = self:_InitStateWidgets(status)
  end
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:RegistEvents()
  for _, widgets in pairs(self._stateWidgets or {}) do
    local reserveBtn = widgets.Button_Reserve
    if reserveBtn then
      self:AddOnClickedEventByControl(reserveBtn, self.OnClickButton_Reserve, self)
    end
    local praiseBtn = widgets.Button_Praise
    if praiseBtn then
      self:AddOnClickedEventByControl(praiseBtn, self.OnClickButton_Praise, self)
    end
  end
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:OnClose()
  for status, widgets in pairs(self._stateWidgets or {}) do
    local fieldName = self:_GetNicknameFrameField(status)
    if self[fieldName] then
      self[fieldName]:Close()
      self[fieldName] = nil
    end
    local sizeBox = widgets and widgets.SizeBox_NicknameFrame
    if sizeBox and sizeBox.ClearChildren then
      sizeBox:ClearChildren()
    end
  end
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:OnRefresh(data, selectIndex)
  self:_Refresh(data)
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:OnSubRefresh(data, selectIndex, subSelectIndex)
  self:_Refresh(data)
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_Refresh(data)
  if not data then
    return
  end
  local status = self:_GetStatus(data)
  if self.UIRoot.WidgetSwitcherExt_Status then
    self.UIRoot.WidgetSwitcherExt_Status:SetActiveWidgetIndex(status)
  end
  local widgets = self._stateWidgets and self._stateWidgets[status]
  if not widgets then
    log_warning(string.format("ModeSelection_Sideber_FriendStatus01_Item_UIBP:_Refresh no widgets for status %s", tostring(status)))
    return
  end
  self._curData = data
  self._curUid = self:_GetUid(data)
  self._curStatus = status
  self:_RefreshPlayerInfo(widgets, data)
  self:_RefreshHint(widgets, self._curUid, status, data)
  self:_RefreshReserve(widgets, self._curUid)
  self:_RefreshPraise(widgets, data)
  self:_RefreshTime(widgets, data, status)
  self:_RefreshLastTime(widgets, data, status)
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_GetUid(data)
  return tonumber(data.uid) or tonumber(data.author_uid)
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_OnClickAvatar(uid)
  local nUid = tonumber(uid)
  if not nUid then
    return
  end
  local ChatMenuSystem = require("client.slua.logic.lobby_chat.logic_chat_menu")
  local menuUI = UIManager.ShowUI(UIManager.UI_Config.ChatMenu_BP, {Uid = nUid, IsShowReport = false}, ChatMenuSystem.EShowLocationType.FriendDynamic)
  if menuUI then
    menuUI:SetTipsPosition(AVATAR_MENU_OFFSET_X, 0)
  end
  self:_RequestRankProfile(nUid)
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_RequestRankProfile(uid)
  local logic_profile_get_wrap = require("client.slua.logic.user.profile.logic_profile_get_wrap")
  if not logic_profile_get_wrap or not logic_profile_get_wrap.GetRankProfiles then
    return
  end
  logic_profile_get_wrap.GetRankProfiles(Enum_PROFILE_REPORT_CFG.CHAT_MENU, {uid}, function(listInfo)
    log(bWriteLog and string.format("ModeSelection_Sideber_FriendStatus01_Item_UIBP:_RequestRankProfile done uid=%s, got=%s", tostring(uid), tostring(listInfo and #listInfo or 0)))
    EventSystem:postEvent(EVENTTYPE_CHAT, EVENTID_CHAT_MENU_PROFILE, uid)
  end)
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_RefreshHint(widgets, uid, status, data)
  local hint = widgets.UTRichText_Hint
  if not hint then
    return
  end
  local bShow = status ~= self.Status.Recent
  self:SetWidgetVisible(hint, bShow)
  if not bShow then
    return
  end
  if status == self.Status.Dynamic then
    local logic_friendfeed_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friendfeed_data)
    local content = ""
    if data and logic_friendfeed_data and logic_friendfeed_data.GetFeedContentByItem then
      content = logic_friendfeed_data.GetFeedContentByItem(data) or ""
    end
    hint:SetText(content)
    return
  end
  local PlayerStatusMgr = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr)
  local statusData = uid and PlayerStatusMgr and PlayerStatusMgr:GetStatusData(uid) or nil
  local time_util = require("client.common.time_util")
  local beginTime = tonumber(statusData and statusData.gameBeginTime)
  local elapsed
  if beginTime then
    elapsed = time_util.GetServerTimeInSec() - beginTime
  else
    elapsed = tonumber(statusData and statusData.timeSinceGameBegin)
  end
  local text = ""
  if elapsed and 0 < elapsed then
    local openTimeStr = time_util.GetOpenedTimeStr(elapsed)
    local modeName = DataMgr.GetModeName(statusData.game_sub_mode)
    text = LocUtil.LocalizeResFormat(13121, modeName, openTimeStr, statusData.currentTeamAmount, statusData.maxTeamAmount)
  end
  hint:SetText(text)
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_RefreshTime(widgets, data, status)
  local timeWidget = widgets.TextBlock_Time
  if not timeWidget then
    return
  end
  if status ~= self.Status.Dynamic then
    timeWidget:SetText("")
    self:SetWidgetVisible(timeWidget, false)
    return
  end
  local logic_friendfeed_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friendfeed_data)
  local text = logic_friendfeed_data and logic_friendfeed_data.GetFeedTimeDesc and logic_friendfeed_data.GetFeedTimeDesc(data.create_time) or ""
  timeWidget:SetText(text)
  self:SetWidgetVisible(timeWidget, text ~= "")
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_RefreshLastTime(widgets, data, status)
  local lastTimeWidget = widgets.TextBlock_LastTime
  if not lastTimeWidget then
    return
  end
  if status ~= self.Status.Recent then
    lastTimeWidget:SetText("")
    self:SetWidgetVisible(lastTimeWidget, false)
    return
  end
  local time_util = require("client.common.time_util")
  local playTime = tonumber(data and data.last_play_time)
  local text = playTime and time_util.GetTimeAgoStr(playTime, false) or ""
  lastTimeWidget:SetText(text)
  self:SetWidgetVisible(lastTimeWidget, text ~= "")
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_RefreshReserve(widgets, uid)
  local button = widgets.Button_Reserve
  if not button then
    return
  end
  local textWidget = widgets.TextBlock_Reserve
  local PlayerStatusMgr = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr)
  local status = uid and PlayerStatusMgr and PlayerStatusMgr:GetStatusData(uid) or nil
  if not status then
    self:SetWidgetVisible(button, false)
    return
  end
  local LogicFriend = require("client.slua.logic.friend.logic_new_friend")
  local isSwitchOpen = LogicFriend.IsFriendReserveSwitchOpen(uid)
  local PlayerStatusUtil = require("client.slua.logic.player_status.PlayerStatusUtil")
  local isInBattle = PlayerStatusUtil.IsBattle(status)
  local isHall = PlayerStatusUtil.IsInCollectionHall(status)
  local logic_home_status = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_home_status)
  local bInHome = logic_home_status:IsHomeVisitMode(status.game_sub_mode) or logic_home_status:IsHomeBuildMode(status.game_sub_mode)
  if not (isSwitchOpen and isInBattle) or status.socialland_type ~= 0 or bInHome or PlayerStatusUtil.IsMainCity(status) or isHall or GameStatus.IsCollectionHallMode() then
    self:SetWidgetVisible(button, false)
    return
  end
  local state = LogicFriend.GetReserveState(uid)
  if state == 1 then
    self:SetWidgetVisible(button, true, true)
    if textWidget then
      textWidget:SetText(LocUtil.GetLocalizeResStr(7554))
    end
  elseif state == 2 then
    self:SetWidgetVisible(button, true, true)
    if textWidget then
      textWidget:SetText(LocUtil.GetLocalizeResStr(7554))
    end
  elseif state == 3 then
    self:SetWidgetVisible(button, true, true)
    if textWidget then
      textWidget:SetText(LocUtil.GetLocalizeResStr(7555))
    end
  else
    self:SetWidgetVisible(button, false)
  end
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:OnClickButton_Reserve()
  self:PlayAudio(sound_config.click_v1)
  local uid = self._curUid
  if not uid then
    return
  end
  local LogicFriend = require("client.slua.logic.friend.logic_new_friend")
  if LogicFriend.GetReserveState(uid) ~= 1 then
    return
  end
  local PlayerStatusMgr = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr)
  local status = PlayerStatusMgr:GetStatusData(uid)
  if status and status.game_sub_mode == 26001 then
    ShowNotice(39036)
    return
  end
  local SingleTrainTool = require("GameLua.Mod.SingleTraining.GamePlay.Data.SingleTrainTool")
  if SingleTrainTool.IsSelfInTraining() then
    ShowNotice(43911)
    return
  end
  local widgets = self._stateWidgets and self._stateWidgets[self._curStatus]
  if widgets then
    local textWidget = widgets.TextBlock_Reserve
    if textWidget then
      textWidget:SetText(LocUtil.GetLocalizeResStr(7555))
    end
  end
  self:AddTimerOnce(61.5, function()
    if not self or not self.UIRoot then
      return
    end
    if not self._curUid or self._curUid ~= uid then
      return
    end
    local curWidgets = self._stateWidgets and self._stateWidgets[self._curStatus]
    if curWidgets then
      self:_RefreshReserve(curWidgets, uid)
    end
  end)
  local TeamUpNewSystem = require("client.slua.logic.teamup.logic_team_up")
  LogicFriend.ReserveFriend(uid, TeamUpNewSystem.E_InviteFromType.Appointment)
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_RefreshPraise(widgets, data)
  local switcher = widgets.Switcher_Praise
  local value = widgets.TextBlock_PraiseValue
  if not data or self._curStatus ~= self.Status.Dynamic then
    if switcher then
      switcher:SetActiveWidgetIndex(PRAISE_SWITCH_INDEX.Unliked)
    end
    if value then
      value:SetText("")
    end
    return
  end
  local count = tonumber(data.like_count) or 0
  local bLiked = self:_IsFeedLiked(data)
  if value then
    value:SetText(tostring(count))
  end
  if switcher then
    switcher:SetActiveWidgetIndex(bLiked and PRAISE_SWITCH_INDEX.Liked or PRAISE_SWITCH_INDEX.Unliked)
  end
  log(bWriteLog and string.format("ModeSelection_Sideber_FriendStatus01_Item_UIBP:_RefreshPraise feed_id=%s count=%s liked=%s", tostring(data.feed_id), tostring(count), tostring(bLiked)))
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_IsFeedLiked(data)
  if not data or not data.like_uids then
    return false
  end
  local selfUid = DataMgr and DataMgr.roleData and tonumber(DataMgr.roleData.uid)
  if not selfUid then
    return false
  end
  return data.like_uids[selfUid] ~= nil or data.like_uids[tostring(selfUid)] ~= nil
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:OnClickButton_Praise()
  self:PlayAudio(sound_config.click_v1)
  local data = self._curData
  if not data then
    return
  end
  local feedId = tonumber(data.feed_id)
  local authorUid = tonumber(data.author_uid)
  local modeGroupId = tonumber(data.mode_group_id)
  if not (feedId and authorUid) or not modeGroupId then
    log_warning(string.format("ModeSelection_Sideber_FriendStatus01_Item_UIBP:OnClickButton_Praise invalid feed, feed_id=%s author_uid=%s mode_group_id=%s", tostring(data.feed_id), tostring(data.author_uid), tostring(data.mode_group_id)))
    return
  end
  local isLike = not self:_IsFeedLiked(data)
  local selfUid = DataMgr and DataMgr.roleData and tonumber(DataMgr.roleData.uid)
  if selfUid then
    data.like_uids = data.like_uids or {}
    local count = tonumber(data.like_count) or 0
    if isLike then
      local TimeUtil = require("client.common.time_util")
      data.like_uids[selfUid] = TimeUtil.GetServerTimeInSec()
      count = count + 1
    else
      data.like_uids[selfUid] = nil
      data.like_uids[tostring(selfUid)] = nil
      count = count - 1
      if count < 0 then
        count = 0
      end
    end
    data.like_count = count
  end
  local widgets = self._stateWidgets and self._stateWidgets[self._curStatus]
  if widgets then
    self:_RefreshPraise(widgets, data)
  end
  local logic_friendfeed_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friendfeed_data)
  if logic_friendfeed_data then
    logic_friendfeed_data:send_friend_feed_like_req(authorUid, modeGroupId, feedId, isLike)
  end
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_GetStatus(data)
  return tonumber(data and data.ui_status) or self.Status.Dynamic
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_InitStateWidgets(status)
  local widgets = {status = status}
  for _, widgetName in ipairs(STATE_WIDGET_NAMES) do
    widgets[widgetName] = self:_FindStateWidget(status, widgetName)
    if not widgets[widgetName] then
      log_warning(string.format("ModeSelection_Sideber_FriendStatus01_Item_UIBP:_InitStateWidgets miss widget %s (status=%s)", widgetName, tostring(status)))
    end
  end
  local avatarWidget = widgets.ModeSelection_Common_Avatar_Item_UIBP
  if avatarWidget then
    local UIComponentModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule)
    if UIComponentModule and UIComponentModule.InitWithParentComponent then
      widgets.avatarUI = UIComponentModule:InitWithParentComponent(self, UIComponentModule.Config.ModeSelection_Common_Avatar_Item_UIBP, avatarWidget)
      if widgets.avatarUI and widgets.avatarUI.SetClickCallback then
        widgets.avatarUI:SetClickCallback(self._OnClickAvatar, self)
      end
    end
  end
  local rankWidget = widgets.PeakGame_RankIntegralLevel_Small_Switch_UIBP
  if rankWidget then
    local LogicPeakGameUtil = require("client.logic.PeakGame.LogicPeakGameUtil")
    widgets.rankUI = LogicPeakGameUtil.InitSmallPeakRankIntegralSwitchWidget(self, rankWidget)
  end
  local lightBoardRoot = widgets.ScaleBox_LightBoard
  if lightBoardRoot then
    widgets.lightBoardUI = lightBoardRoot.Common_LightBoard_UIBP
    if not widgets.lightBoardUI then
      widgets.lightBoardUI = self:CreateChildWindowWithBpPath(lightBoardRoot, nil, C_LIGHTBOARD_BP_PATH)
    end
  end
  local birthdayBtn = widgets.Button_Birthday
  if birthdayBtn then
    self:SetWidgetVisible(birthdayBtn, true)
  end
  local lastTime = widgets.TextBlock_LastTime
  if lastTime then
    self:SetWidgetVisible(lastTime, false)
  end
  self:_ResetStateComponents(widgets)
  return widgets
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_ResetStateComponents(widgets)
  if widgets.avatarUI then
    widgets.avatarUI:SetData(nil)
  end
  if widgets.rankUI then
    widgets.rankUI:Collapsed()
  end
  local obj = not widgets.lightBoardUI or widgets.lightBoardUI.UIRoot or widgets.lightBoardUI
  if obj and obj.ShowLightBoard then
    obj:ShowLightBoard(0, widgets.ScaleBox_LightBoard)
  end
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_FindStateWidget(status, widgetName)
  local candidates = {
    string.format("%s_%d", widgetName, status + 1),
    string.format("%s_%d", widgetName, status),
    widgetName
  }
  for _, name in ipairs(candidates) do
    local widget = self.UIRoot[name]
    if widget then
      return widget
    end
  end
  return nil
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_GetNicknameFrameField(status)
  return string.format("_nicknameFrameUI_%d", status)
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_RefreshPlayerInfo(widgets, data)
  local uid = self:_GetUid(data)
  local logic_profile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
  local profile = uid and logic_profile and logic_profile:GetLocalProfile(uid) or nil
  if not profile then
    log_warning(string.format("ModeSelection_Sideber_FriendStatus01_Item_UIBP:_RefreshPlayerInfo no profile, uid=%s", tostring(uid)))
    return
  end
  self:_SetName(widgets, profile)
  self:_SetAvatar(widgets, uid)
  self:_SetGender(widgets, profile)
  self:_SetLightBoard(widgets, uid, profile)
  self:_SetNicknameFrame(widgets, profile)
  self:_SetUnknowPass(widgets, profile)
  self:_SetRankIntegral(widgets, profile)
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_SetName(widgets, profile)
  local textName = widgets.Text_Name
  if not textName then
    return
  end
  textName:SetText(tostring(profile.nickName or ""))
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_SetAvatar(widgets, uid)
  if not widgets.avatarUI then
    return
  end
  widgets.avatarUI:SetVisible(true)
  widgets.avatarUI:SetData(uid)
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_SetGender(widgets, profile)
  local genderUI = widgets.Common_Gender_UIBP
  if not genderUI then
    return
  end
  local sizeBox = widgets.SizeBox_Gender
  local newSex = profile.social_card and profile.social_card.new_sex
  if newSex and 0 < newSex then
    if sizeBox then
      self:SetWidgetVisible(sizeBox, true)
    end
    self:SetWidgetVisible(genderUI, true)
    genderUI:LoadIcon(profile.uid)
  else
    if sizeBox then
      self:SetWidgetVisible(sizeBox, false)
    end
    self:SetWidgetVisible(genderUI, false)
  end
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_SetLightBoard(widgets, uid, profile)
  local scaleBox = widgets.ScaleBox_LightBoard
  if not scaleBox then
    return
  end
  if not profile.light_board_info or not next(profile.light_board_info) then
    self:SetWidgetVisible(scaleBox, false)
    return
  end
  self:SetWidgetVisible(scaleBox, true)
  local obj = not widgets.lightBoardUI or widgets.lightBoardUI.UIRoot or widgets.lightBoardUI
  if obj and obj.ShowLightBoard then
    obj:ShowLightBoard(uid or 0, scaleBox, profile.light_board_info)
  end
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_SetNicknameFrame(widgets, profile)
  local sizeBox = widgets.SizeBox_NicknameFrame
  if not sizeBox then
    return
  end
  if sizeBox.ClearChildren then
    sizeBox:ClearChildren()
  end
  local UIUtil = require("client.common.ui_util")
  UIUtil.UpdateNicknameFrame(self, profile.friend_nickname_skin, sizeBox, false, self:_GetNicknameFrameField(widgets.status))
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_SetUnknowPass(widgets, profile)
  local passUI = widgets.UnknowPass_ContinuousBuy_BP
  if not passUI then
    return
  end
  local LogicFriend = require("client.slua.logic.friend.logic_new_friend")
  local UPassIsBuy, UPassIsShow, UPassKeepBuy, UPassValue, pass_type = LogicFriend.ParsePassInfo(profile.upass)
  self:SetWidgetVisible(passUI, UPassIsShow and true or false)
  if not UPassIsShow then
    return
  end
  passUI:SetTypeData(0, UPassKeepBuy, UPassIsBuy, profile.online or 0, UPassValue, pass_type or 0)
end

function ModeSelection_Sideber_FriendStatus01_Item_UIBP:_SetRankIntegral(widgets, profile)
  if not widgets.rankUI then
    return
  end
  widgets.rankUI:SetSegmentBySegmentType(profile.uid, true)
end

local class = require("class")
local extended_loop_scroll_grid_subItem_base = require("client.slua_ui_framework.component.extended_loop_scroll_grid_subItem_base")
return class(extended_loop_scroll_grid_subItem_base, nil, ModeSelection_Sideber_FriendStatus01_Item_UIBP)
