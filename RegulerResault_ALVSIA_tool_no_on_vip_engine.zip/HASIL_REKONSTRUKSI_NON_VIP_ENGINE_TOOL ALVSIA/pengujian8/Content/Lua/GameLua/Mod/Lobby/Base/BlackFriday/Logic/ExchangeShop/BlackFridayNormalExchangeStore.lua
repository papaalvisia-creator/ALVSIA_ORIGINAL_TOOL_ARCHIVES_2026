local BlackFridayExchangeBaseStore = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.ExchangeShop.BlackFridayExchangeBaseStore")
local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
local LuckyCardConfig = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.BlackFridayLuckyCardConfig")
local BlackFridayNormalExchangeStore = {
  ActivityId = PublishRegionMacros.IsBlueholeOperationRegion() and 647007481 or PublishRegionMacros.IsJapanOrKorea() and 247007481 or 147007481,
  Sheet = {LuckyCard = 1, Normal = 2},
  ItemState = {
    Available = "available",
    NotReady = "not_ready",
    NeedLuckyCard = "need_lucky_card",
    NeedPrivilege = "need_privilege",
    InvalidSheet = "invalid_sheet"
  },
  DisplayState = {
    Available = "available",
    NotEnough = "not_enough",
    Possessed = "possessed",
    SoldOut = "sold_out",
    Discount = "discount"
  }
}
BlackFridayNormalExchangeStore.__index = BlackFridayNormalExchangeStore
setmetatable(BlackFridayNormalExchangeStore, {__index = BlackFridayExchangeBaseStore})

local function ToNumber(value, defaultValue)
  local numberValue = tonumber(value)
  if numberValue == nil then
    return defaultValue or 0
  end
  return numberValue
end

local function CloneTable(source)
  local result = {}
  if type(source) ~= "table" then
    return result
  end
  for key, value in pairs(source) do
    result[key] = value
  end
  return result
end

function BlackFridayNormalExchangeStore.New(owner)
  local store = BlackFridayExchangeBaseStore.Create(BlackFridayNormalExchangeStore, owner, BlackFridayNormalExchangeStore.ActivityId, "normal")
  store:GetExchangeLogic().SetExchangeLimitKeyResolver(store.ActivityId, BlackFridayNormalExchangeStore.GetExchangeLimitKey)
  return store
end

function BlackFridayNormalExchangeStore.GetExchangeLimitKey(itemId, itemNum, validTime, sheetId)
  local key = string.format("%s_%s_%s", itemId, itemNum, validTime)
  if tonumber(sheetId) ~= BlackFridayNormalExchangeStore.Sheet.LuckyCard then
    return key
  end
  local luckyCardModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule)
  if not luckyCardModule:IsReady() then
    return nil
  end
  local benefitId
  for _, benefit in pairs(luckyCardModule:GetBenefits() or {}) do
    local id = tonumber(benefit.privilege_benefit_id)
    if tonumber(benefit.privilege_benefit_type) == LuckyCardConfig.BenefitKind.LuckyCardShop and id and 0 < id then
      if benefitId and benefitId ~= id then
        return nil
      end
      benefitId = id
    end
  end
  return benefitId and string.format("%s_%s", key, benefitId) or nil
end

function BlackFridayNormalExchangeStore:Request(forcePrivilege)
  local luckyCardModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule)
  luckyCardModule:EnsureReady()
  return BlackFridayExchangeBaseStore.Request(self)
end

function BlackFridayNormalExchangeStore:Open(forcePrivilege)
  return self:Request(forcePrivilege)
end

function BlackFridayNormalExchangeStore:OnLuckyCardDataUpdated()
  if self.Requested then
    BlackFridayExchangeBaseStore.Request(self)
  end
end

function BlackFridayNormalExchangeStore:GetSheetPrivilegeState(sheetId)
  sheetId = tonumber(sheetId)
  local ready = self:GetLoadState() == self.LoadState.Ready
  if ready then
    for _, item in ipairs(self:GetRawItems()) do
      if tonumber(item.exchange_sheet_id) == sheetId and item.exchangeLimitReady == false then
        ready = false
        break
      end
    end
  end
  local supported = sheetId == self.Sheet.LuckyCard or sheetId == self.Sheet.Normal
  local privilegeOpen
  local privilegeOpenMap = self:GetSheetPrivilegeOpen()
  if type(privilegeOpenMap) == "table" then
    privilegeOpen = privilegeOpenMap[sheetId]
  end
  local configured = ready and privilegeOpen ~= nil
  local canUse = ready and supported and (privilegeOpen == nil or privilegeOpen == true)
  local reason
  if not ready then
    reason = self.ItemState.NotReady
  elseif not supported then
    reason = self.ItemState.InvalidSheet
  elseif not canUse then
    reason = sheetId == self.Sheet.LuckyCard and self.ItemState.NeedLuckyCard or self.ItemState.NeedPrivilege
  end
  return {
    sheet_id = sheetId,
    ready = ready,
    configured = configured,
    privilege_open = privilegeOpen,
    canUse = canUse,
    reason = reason
  }
end

function BlackFridayNormalExchangeStore:GetPrivilegeState()
  return self:GetSheetPrivilegeState(self.Sheet.LuckyCard)
end

function BlackFridayNormalExchangeStore:CanUseSheet(sheetId)
  return self:GetSheetPrivilegeState(sheetId).canUse == true
end

function BlackFridayNormalExchangeStore:GetItemState(itemData)
  if self:GetLoadState() ~= self.LoadState.Ready or type(itemData) ~= "table" then
    return self.ItemState.NotReady
  end
  local sheetId = tonumber(itemData.exchange_sheet_id)
  if sheetId ~= self.Sheet.LuckyCard and sheetId ~= self.Sheet.Normal then
    return self.ItemState.InvalidSheet
  end
  if itemData.exchangeLimitReady == false then
    return self.ItemState.NotReady
  end
  if self:CanUseSheet(sheetId) then
    return self.ItemState.Available
  end
  if sheetId == self.Sheet.LuckyCard then
    return self.ItemState.NeedLuckyCard
  end
  return self.ItemState.NeedPrivilege
end

function BlackFridayNormalExchangeStore:CanUseItem(itemData)
  return self:GetItemState(itemData) == self.ItemState.Available
end

function BlackFridayNormalExchangeStore:GetDisplayState(itemData, currencyCount)
  if itemData.possessed then
    return self.DisplayState.Possessed
  end
  if itemData.row_sold_out then
    return self.DisplayState.SoldOut
  end
  if ToNumber(itemData.original_price) > ToNumber(itemData.needItemNum) then
    return self.DisplayState.Discount
  end
  if currencyCount < ToNumber(itemData.needItemNum) then
    return self.DisplayState.NotEnough
  end
  return self.DisplayState.Available
end

function BlackFridayNormalExchangeStore:GetData()
  local rawItems = self:GetRawItems()
  local currencyId = self:GetCurrencyId(rawItems)
  local currencyCountById = self:GetCurrencyCountById(rawItems)
  local currencyCount = currencyCountById[currencyId] or 0
  local privilegeState = self:GetPrivilegeState()
  local normalPrivilegeState = self:GetSheetPrivilegeState(self.Sheet.Normal)
  local result = {
    activity_id = self.ActivityId,
    load_state = self:GetLoadState(),
    currency_id = currencyId,
    currency_count = currencyCount,
    privilege_state = privilegeState,
    items = {},
    sheets = {
      [self.Sheet.LuckyCard] = {
        sheet_id = self.Sheet.LuckyCard,
        requires_lucky_card = privilegeState.configured,
        requires_privilege = privilegeState.configured,
        privilege_open = privilegeState.privilege_open,
        privilege_state = privilegeState,
        can_exchange = privilegeState.canUse,
        items = {}
      },
      [self.Sheet.Normal] = {
        sheet_id = self.Sheet.Normal,
        requires_lucky_card = false,
        requires_privilege = normalPrivilegeState.configured,
        privilege_open = normalPrivilegeState.privilege_open,
        privilege_state = normalPrivilegeState,
        can_exchange = normalPrivilegeState.canUse,
        items = {}
      }
    }
  }
  local StoreUtils = require("client.slua.logic.store.utils.store_utils")
  for _, sourceItem in ipairs(rawItems) do
    local itemData = CloneTable(sourceItem)
    local itemCurrencyCount = currencyCountById[ToNumber(itemData.needItemId)] or 0
    itemData.activity_id = self.ActivityId
    itemData.exchange_page = "normal"
    itemData.hasExchangeCount = ToNumber(itemData.hasExchangeCount)
    itemData.timeLimits = ToNumber(itemData.timeLimits)
    itemData.needItemNum = ToNumber(itemData.needItemNum)
    itemData.itemNum = ToNumber(itemData.itemNum, 1)
    itemData.row_sold_out = 0 < itemData.timeLimits and itemData.hasExchangeCount >= itemData.timeLimits
    itemData.possessed = StoreUtils.IsPossessed(itemData.itemId) == true
    itemData.enough_currency = itemCurrencyCount >= itemData.needItemNum
    itemData.display_state = self:GetDisplayState(itemData, itemCurrencyCount)
    local sheetId = ToNumber(itemData.exchange_sheet_id, self.Sheet.LuckyCard)
    local sheetData = result.sheets[sheetId]
    if not sheetData then
      local sheetPrivilegeState = self:GetSheetPrivilegeState(sheetId)
      sheetData = {
        sheet_id = sheetId,
        requires_lucky_card = false,
        requires_privilege = sheetPrivilegeState.configured,
        privilege_open = sheetPrivilegeState.privilege_open,
        privilege_state = sheetPrivilegeState,
        can_exchange = sheetPrivilegeState.canUse,
        items = {}
      }
      result.sheets[sheetId] = sheetData
    end
    itemData.requires_lucky_card = sheetId == self.Sheet.LuckyCard and sheetData.requires_privilege
    itemData.requires_privilege = sheetData.requires_privilege
    itemData.privilege_open = sheetData.privilege_open
    itemData.access_state = self:GetItemState(itemData)
    itemData.can_exchange_by_privilege = itemData.access_state == self.ItemState.Available
    itemData.can_open_confirm = itemData.can_exchange_by_privilege and not itemData.possessed and not itemData.row_sold_out
    table.insert(result.items, itemData)
    table.insert(sheetData.items, itemData)
  end
  return result
end

function BlackFridayNormalExchangeStore:GetSheetData(sheetId)
  return self:GetData().sheets[tonumber(sheetId)]
end

return BlackFridayNormalExchangeStore
