local ModeSelection_Sideber_FriendStatus_UIBP = {}
local mode_selection_category_utils = require("GameLua.Mod.Lobby.Split.ModeSelection470.logic.mode_selection_category_utils")
local KEY_FRIEND_ONLINE = 588011
local KEY_FRIEND_FEED = 588219
local KEY_EMPTY = 588039
local KEY_EMPTY_FEED = 588123
local KEY_ADD_FRIEND = 10169
local KEY_GROUP_PLAYING = 588016
local KEY_GROUP_RECENT = 588017
local SWITCHER_FRIEND_ONLINE = 0
local SWITCHER_FRIEND_FEED = 1
local ITEM_STATUS_DYNAMIC = 0
local ITEM_STATUS_PLAYING = 1
local ITEM_STATUS_RECENT = 2
local ModeSelection_Friend_Util = require("GameLua.Mod.Lobby.Split.ModeSelection470.util.ModeSelection_Friend_Util")

function ModeSelection_Sideber_FriendStatus_UIBP:ctor()
  self._bFriendsOnlineEmpty = false
  self._bFriendsFeedEmpty = false
  self._bShowOnline = true
  self._bUIReady = false
  self._bFriendStatusRefreshScheduled = false
  self._groupSignature = nil
  self._bPendingRebuild = false
  self._pendingProfileUids = nil
  self._bProfileRefreshScheduled = false
end

function ModeSelection_Sideber_FriendStatus_UIBP:OnInitialize()
  local luaItem = "GameLua.Mod.Lobby.Split.ModeSelection470.umg.Sideber.Item.ModeSelection_Sideber_FriendStatustITitle_Item_UIBP"
  local luaSubItem = "GameLua.Mod.Lobby.Split.ModeSelection470.umg.Sideber.Item.ModeSelection_Sideber_FriendStatus01_Item_UIBP"
  self.ExtendedLoopScrollGrid_FriendsOnline = self:InitExtendedScrollGrid(self.UIRoot.ExtendedLoopScrollGrid_FriendsOnline, {luaItem, luaSubItem})
  self.LoopScrollBox_FriendsFeed = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_FriendsFeed, "GameLua.Mod.Lobby.Split.ModeSelection470.umg.Sideber.Item.ModeSelection_Sideber_FriendStatus01_Item_UIBP")
end

function ModeSelection_Sideber_FriendStatus_UIBP:RegistEvents()
  self:AddOnClickedEventByControl(self.UIRoot.Button_Add, self.OnClickButton_Add, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_FriendsOnline, self.OnClickButton_FriendsOnline, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_FriendsFeed, self.OnClickButton_FriendsFeed, self)
  self:AddCommonEvent(EVENTTYPE_FRIEND_FEED, EVENTID_FRIEND_FEED_BATCH_RSP, self.UpdateUI, self)
  self:AddCommonEvent(EVENTTYPE_FRIEND, EVENTID_FRIEND_ADD_DELETE_FRIEND, self.OnFriendAddOrDelete, self)
  self:AddCommonEvent(EVENTTYPE_FRIEND, EVENTID_BATCH_GET_PLAYERSTATUS, self.OnFriendStatusChange, self)
  self:AddCommonEvent(EVENTTYPE_FRIEND, EVENTID_FRIEND_GROUP_ONLINE_CHANGE, self.OnFriendStatusChange, self)
  self:AddCommonEvent(EVENTTYPE_FRIEND, EVENTID_FRIEND_STATUS_CHANGE, self.OnFriendSelfStatusChange, self)
  self:AddCommonEvent(EVENTTYPE_CHAT, EVENTID_CHAT_MENU_PROFILE, self.OnChatMenuProfileReady, self)
end

function ModeSelection_Sideber_FriendStatus_UIBP:OnPostInitialize()
  self:ShowFriendsOnline()
  self:UpdateUI()
  self:ApplyPendingView()
end

function ModeSelection_Sideber_FriendStatus_UIBP:OnClose()
end

function ModeSelection_Sideber_FriendStatus_UIBP:OnClickButton_FriendsFeed()
  self:PlayAudio(sound_config.click_v1)
  self:ShowFriendsFeed()
end

function ModeSelection_Sideber_FriendStatus_UIBP:OnClickButton_FriendsOnline()
  self:PlayAudio(sound_config.click_v1)
  self:ShowFriendsOnline()
end

function ModeSelection_Sideber_FriendStatus_UIBP:ShowFriendsFeed()
  self:_SetFriendStatusIndex(SWITCHER_FRIEND_FEED)
end

function ModeSelection_Sideber_FriendStatus_UIBP:ShowFriendsOnline()
  self:_SetFriendStatusIndex(SWITCHER_FRIEND_ONLINE)
end

function ModeSelection_Sideber_FriendStatus_UIBP:ApplyPendingView()
  self:_FlushPendingRebuild()
  local logic_friendfeed_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friendfeed_data)
  if not logic_friendfeed_data or not logic_friendfeed_data.TakePendingFriendStatusView then
    return
  end
  local bShowFeed = logic_friendfeed_data:TakePendingFriendStatusView()
  if bShowFeed == nil then
    return
  end
  if bShowFeed then
    self:ShowFriendsFeed()
  else
    self:ShowFriendsOnline()
  end
end

function ModeSelection_Sideber_FriendStatus_UIBP:OnClickButton_Add()
  self:PlayAudio(sound_config.click_v1)
  UIManager.ShowUI(UIManager.UI_Config.friend_new_search)
end

function ModeSelection_Sideber_FriendStatus_UIBP:_SetFriendStatusIndex(index)
  local switcher = self.UIRoot.WidgetSwitcherExt_FriendStatus
  if switcher then
    switcher:SetActiveWidgetIndex(index)
  else
    log_warning("ModeSelection_Sideber_FriendStatus_UIBP:_SetFriendStatusIndex no WidgetSwitcherExt_FriendStatus")
  end
  self._bShowOnline = index == SWITCHER_FRIEND_ONLINE
  if self._bShowOnline and self._bUIReady then
    self:_RefreshFriendsOnline(true)
  else
    self:_RefreshFriendStatusVisible()
  end
end

function ModeSelection_Sideber_FriendStatus_UIBP:_RefreshFriendStatusVisible()
  local bOnline = self._bShowOnline
  local bEmpty = self._bFriendsOnlineEmpty
  local bFeedEmpty = self._bFriendsFeedEmpty
  if self.UIRoot.VerticalBox_None then
    self:SetWidgetVisible(self.UIRoot.VerticalBox_None, bOnline and bEmpty or not bOnline and bFeedEmpty)
  end
  if self.UIRoot.TextBlock_Empty then
    self.UIRoot.TextBlock_Empty:SetText(LocUtil.GetLocalizeResStr(bOnline and KEY_EMPTY or KEY_EMPTY_FEED))
  end
  if self.UIRoot.Button_Add then
    self:SetWidgetVisible(self.UIRoot.Button_Add, bOnline and bEmpty and not self:_HasFriend(), true)
  end
  if self.UIRoot.ExtendedLoopScrollGrid_FriendsOnline then
    self:SetWidgetVisible(self.UIRoot.ExtendedLoopScrollGrid_FriendsOnline, bOnline and not bEmpty)
  end
  if self.UIRoot.LoopScrollBox_FriendsFeed then
    self:SetWidgetVisible(self.UIRoot.LoopScrollBox_FriendsFeed, not bOnline and not bFeedEmpty)
  end
end

function ModeSelection_Sideber_FriendStatus_UIBP:_HasFriend()
  local LogicFriend = require("client.slua.logic.friend.logic_new_friend")
  if not LogicFriend or not LogicFriend.GetFriendList then
    return false
  end
  local friendList = LogicFriend.GetFriendList() or {}
  return 0 < #friendList
end

function ModeSelection_Sideber_FriendStatus_UIBP:OnFriendAddOrDelete()
  self:_RefreshFriendStatusVisible()
end

function ModeSelection_Sideber_FriendStatus_UIBP:OnFriendStatusChange()
  self:_ScheduleFriendStatusRefresh()
end

function ModeSelection_Sideber_FriendStatus_UIBP:OnFriendSelfStatusChange()
  if not self.UIRoot then
    return
  end
  self:_RefreshFriendsFeedList()
  if not self._bShowOnline then
    self:_RefreshFriendStatusVisible()
  end
  self:_ScheduleFriendStatusRefresh()
end

function ModeSelection_Sideber_FriendStatus_UIBP:_ScheduleFriendStatusRefresh()
  if self._bFriendStatusRefreshScheduled then
    return
  end
  self._bFriendStatusRefreshScheduled = true
  self:AddTimerOnce(0, function()
    self._bFriendStatusRefreshScheduled = false
    if not self.UIRoot then
      return
    end
    self:_RefreshFriendsOnline()
  end)
end

function ModeSelection_Sideber_FriendStatus_UIBP:OnChatMenuProfileReady(eventType, eventID, uid)
  if not self.UIRoot then
    return
  end
  local nUid = tonumber(uid)
  if not nUid then
    return
  end
  local pending = self._pendingProfileUids or {}
  pending[nUid] = true
  self._pendingProfileUids = pending
  self:_ScheduleProfileItemRefresh()
end

function ModeSelection_Sideber_FriendStatus_UIBP:_ScheduleProfileItemRefresh()
  if self._bProfileRefreshScheduled then
    return
  end
  self._bProfileRefreshScheduled = true
  self:AddTimerOnce(0, function()
    self._bProfileRefreshScheduled = false
    if not self.UIRoot then
      return
    end
    local uidSet = self._pendingProfileUids
    self._pendingProfileUids = nil
    if not uidSet then
      return
    end
    local nOnline = self:_RefreshOnlineItemsByUids(uidSet)
    local nFeed = self:_RefreshFeedItemsByUids(uidSet)
    log(bWriteLog and string.format("ModeSelection_Sideber_FriendStatus_UIBP:_ScheduleProfileItemRefresh onlineItems=%d, feedItems=%d", nOnline, nFeed))
  end)
end

function ModeSelection_Sideber_FriendStatus_UIBP:_RefreshOnlineItemsByUids(uidSet)
  local grid = self.ExtendedLoopScrollGrid_FriendsOnline
  if not grid or not next(uidSet) then
    return 0
  end
  local hitUidSet = {}
  local hitCount = 0
  local i = 1
  while true do
    local records = grid:GetSubItemList(i)
    if not records then
      break
    end
    for k = 1, #records do
      local uid = tonumber(records[k] and records[k].uid)
      if uid and uidSet[uid] then
        hitUidSet[uid] = true
        hitCount = hitCount + 1
        grid:RefreshSubItem(i, k)
      end
    end
    i = i + 1
  end
  local nMiss = 0
  for uid in pairs(uidSet) do
    if not hitUidSet[uid] then
      nMiss = nMiss + 1
    end
  end
  log(bWriteLog and string.format("ModeSelection_Sideber_FriendStatus_UIBP:_RefreshOnlineItemsByUids hit=%d, miss=%d", hitCount, nMiss))
  return hitCount
end

function ModeSelection_Sideber_FriendStatus_UIBP:_RefreshFeedItemsByUids(uidSet)
  local loop = self.LoopScrollBox_FriendsFeed
  if not loop or not next(uidSet) then
    return 0
  end
  local feedList = loop.GetSetData and loop:GetSetData() or nil
  if type(feedList) ~= "table" then
    return 0
  end
  local hitCount = 0
  for i = 1, #feedList do
    local data = feedList[i]
    local uid = tonumber(data and (data.uid or data.author_uid))
    if uid and uidSet[uid] then
      hitCount = hitCount + 1
      loop:RefreshItem(i)
    end
  end
  log(bWriteLog and string.format("ModeSelection_Sideber_FriendStatus_UIBP:_RefreshFeedItemsByUids hit=%d", hitCount))
  return hitCount
end

function ModeSelection_Sideber_FriendStatus_UIBP:OnRankedStateChanged()
  if not self.UIRoot then
    return
  end
  log(bWriteLog and string.format("[SideberFriendStatus] OnRankedStateChanged, rebuild playing list with current view"))
  self:_ScheduleFriendStatusRefresh()
end

function ModeSelection_Sideber_FriendStatus_UIBP:UpdateUI()
  log(bWriteLog and "ModeSelection_Sideber_FriendStatus_UIBP:UpdateUI")
  if self.UIRoot.TextBlock_FriendOnline then
    self.UIRoot.TextBlock_FriendOnline:SetText(LocUtil.GetLocalizeResStr(KEY_FRIEND_ONLINE))
  end
  if self.UIRoot.TextBlock_FriendFeed then
    self.UIRoot.TextBlock_FriendFeed:SetText(LocUtil.GetLocalizeResStr(KEY_FRIEND_FEED))
  end
  if self.UIRoot.TextBlock_Add then
    self.UIRoot.TextBlock_Add:SetText(LocUtil.GetLocalizeResStr(KEY_ADD_FRIEND))
  end
  self:_RefreshFriendsFeedList()
  self:_RefreshFriendsOnline()
  self._bUIReady = true
end

function ModeSelection_Sideber_FriendStatus_UIBP:_RefreshFriendsFeedList()
  local feedList = self:_GetFriendFeedList()
  self.LoopScrollBox_FriendsFeed:SetData(feedList)
  self._bFriendsFeedEmpty = #feedList == 0
end

function ModeSelection_Sideber_FriendStatus_UIBP:_GetFriendFeedList()
  local logic_friendfeed_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friendfeed_data)
  if not logic_friendfeed_data or not logic_friendfeed_data.GetFeedListByRecommendId then
    return {}
  end
  local feedList = logic_friendfeed_data:GetFeedListByRecommendId(self:_GetRecommendId())
  log_tree("ModeSelection_Sideber_FriendStatus_UIBP:_GetFriendFeedList feedList =", feedList)
  return feedList
end

function ModeSelection_Sideber_FriendStatus_UIBP:_BuildGroupSignature(mainList)
  local parts = {}
  for i = 1, #mainList do
    parts[i] = string.format("%s:%d", tostring(mainList[i].title_id), #mainList[i].records)
  end
  return table.concat(parts, "|")
end

function ModeSelection_Sideber_FriendStatus_UIBP:_OverwriteSubRecordsInPlace(grid, mainList)
  for i = 1, #mainList do
    local records = grid:GetSubItemList(i)
    if not records then
      return false
    end
    local newRecords = mainList[i].records
    for k = 1, #records do
      records[k] = nil
    end
    for k = 1, #newRecords do
      records[k] = newRecords[k]
    end
    local group = grid:GetItemData(i)
    if group then
      group.records = records
    end
  end
  return true
end

function ModeSelection_Sideber_FriendStatus_UIBP:_RefreshOnlineGridInPlace(grid, mainList)
  if not self:_OverwriteSubRecordsInPlace(grid, mainList) then
    return false
  end
  local offset = grid:GetItemOffset()
  grid:RefreshAllSubItems()
  if offset and 0 < offset and grid:GetItemOffset() ~= offset then
    grid:SetItemOffset(offset)
    log(bWriteLog and string.format("ModeSelection_Sideber_FriendStatus_UIBP:_RefreshOnlineGridInPlace restore offset %s -> %s", tostring(offset), tostring(grid:GetItemOffset())))
  end
  return true
end

function ModeSelection_Sideber_FriendStatus_UIBP:_RebuildOnlineGrid(grid, mainList, signature)
  grid:SetData(mainList)
  for i = 1, #mainList do
    grid:SetSubData(i, mainList[i].records)
  end
  grid:RefreshAllSubItems()
  self._groupSignature = signature
  self._bPendingRebuild = false
end

function ModeSelection_Sideber_FriendStatus_UIBP:_FlushPendingRebuild()
  if not self._bPendingRebuild then
    return
  end
  self._bPendingRebuild = false
  self:_RefreshFriendsOnline(true)
end

function ModeSelection_Sideber_FriendStatus_UIBP:_RefreshFriendsOnline(bAllowRebuild)
  local playing, recent = self:_SplitFriendsByPlaying()
  local mainList = {}
  if 0 < #playing then
    mainList[#mainList + 1] = {title_id = KEY_GROUP_PLAYING, records = playing}
  end
  if 0 < #recent then
    mainList[#mainList + 1] = {title_id = KEY_GROUP_RECENT, records = recent}
  end
  local grid = self.ExtendedLoopScrollGrid_FriendsOnline
  if grid then
    local signature = self:_BuildGroupSignature(mainList)
    if signature == self._groupSignature then
      if self:_RefreshOnlineGridInPlace(grid, mainList) then
        self._bPendingRebuild = false
      else
        log_warning("ModeSelection_Sideber_FriendStatus_UIBP:_RefreshFriendsOnline in-place failed, rebuild")
        self:_RebuildOnlineGrid(grid, mainList, signature)
      end
    elseif self._groupSignature == nil or self._groupSignature == "" or #mainList == 0 or bAllowRebuild then
      self:_RebuildOnlineGrid(grid, mainList, signature)
    else
      if not self._bPendingRebuild then
        log(bWriteLog and string.format("ModeSelection_Sideber_FriendStatus_UIBP:_RefreshFriendsOnline structure changed, rebuild deferred (old=%s, new=%s)", tostring(self._groupSignature), signature))
      end
      self._bPendingRebuild = true
    end
  end
  self._bFriendsOnlineEmpty = #playing + #recent == 0
  self:_RefreshFriendStatusVisible()
  log(bWriteLog and string.format("ModeSelection_Sideber_FriendStatus_UIBP:_RefreshFriendsOnline playing=%d, recent=%d", #playing, #recent))
end

function ModeSelection_Sideber_FriendStatus_UIBP:_GetRecommendId()
  local parentUI = self:GetParentUI()
  local viewData = parentUI and parentUI.data
  return viewData and tonumber(viewData.recommend_id) or nil
end

function ModeSelection_Sideber_FriendStatus_UIBP:_GetRecommendViews(recommendId)
  local viewSet, viewIdList = {}, {}
  local logic_friendfeed_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friendfeed_data)
  if not logic_friendfeed_data or not logic_friendfeed_data.GetViewIdsByRecommendId then
    return viewSet, viewIdList
  end
  for _, viewId in ipairs(logic_friendfeed_data:GetViewIdsByRecommendId(recommendId) or {}) do
    if not viewSet[viewId] then
      viewSet[viewId] = true
      viewIdList[#viewIdList + 1] = viewId
    end
  end
  return viewSet, viewIdList
end

function ModeSelection_Sideber_FriendStatus_UIBP:_GetViewIdsBySubModeId(subModeId)
  local viewIds = {}
  local logic_mode_selection = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection)
  if not logic_mode_selection then
    return viewIds
  end
  local seenViewId = {}
  
  local function addViewId(viewInfo)
    local nViewId = viewInfo and tonumber(viewInfo.id)
    if nViewId and not seenViewId[nViewId] then
      seenViewId[nViewId] = true
      viewIds[#viewIds + 1] = nViewId
    end
  end
  
  local mutiViewDict = logic_mode_selection.GetMutiViewInfoDictionary and logic_mode_selection:GetMutiViewInfoDictionary()
  for _, viewInfo in pairs(mutiViewDict and mutiViewDict[subModeId] or {}) do
    addViewId(viewInfo)
  end
  local simpleViewDict = logic_mode_selection.GetSimpleViewInfoDictionary and logic_mode_selection:GetSimpleViewInfoDictionary()
  addViewId(simpleViewDict and simpleViewDict[subModeId])
  log(bWriteLog and string.format("ModeSelection_Sideber_FriendStatus_UIBP:_GetViewIdsBySubModeId subModeId=%s, viewIds=[%s]", tostring(subModeId), table.concat(viewIds, ",")))
  return viewIds
end

function ModeSelection_Sideber_FriendStatus_UIBP:_GetRecommendModeIdSet(viewIds)
  local set = {}
  local logic_mode_selection = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection)
  for _, viewId in ipairs(viewIds or {}) do
    local viewInfo = logic_mode_selection and logic_mode_selection:GetSubviewInfoBySubviewID(viewId) or nil
    if viewInfo then
      for _, modeId in ipairs(mode_selection_category_utils.GetModeIdList(viewInfo)) do
        set[tonumber(modeId)] = true
      end
    end
  end
  return set
end

function ModeSelection_Sideber_FriendStatus_UIBP:_FormatGroupViewsForLog(groupViews)
  if not groupViews or #groupViews == 0 then
    return ""
  end
  local logic_mode_selection = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection)
  local parts = {}
  for _, groupView in ipairs(groupViews) do
    local nViewId = tonumber(groupView and groupView.view_id)
    local viewInfo = nViewId and logic_mode_selection and logic_mode_selection:GetSubviewInfoBySubviewID(nViewId)
    parts[#parts + 1] = string.format("%s:%s", tostring(nViewId), tostring(viewInfo and viewInfo.is_ranked))
  end
  return table.concat(parts, " ")
end

function ModeSelection_Sideber_FriendStatus_UIBP:_GetDetailTargets()
  local viewSet, modeSet = {}, {}
  local parentUI = self:GetParentUI()
  local viewData = parentUI and parentUI.data
  local nViewId = tonumber(parentUI and parentUI._curViewId) or tonumber(viewData and viewData.id)
  if not nViewId then
    log_warning("ModeSelection_Sideber_FriendStatus_UIBP:_GetDetailTargets no view id")
    return viewSet, modeSet, false
  end
  viewSet[nViewId] = true
  local logic_mode_selection = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection)
  local viewInfo = logic_mode_selection and logic_mode_selection:GetSubviewInfoBySubviewID(nViewId) or viewData
  local modeIdList = mode_selection_category_utils.GetModeIdList(viewInfo)
  for _, modeId in ipairs(modeIdList) do
    local nModeId = tonumber(modeId)
    if nModeId then
      modeSet[nModeId] = true
    end
  end
  local bRankMatchGroup = false
  local groupViews = viewInfo and viewInfo.group_view_v2
  if groupViews and 1 < #groupViews and logic_mode_selection then
    local bHasRanked, bHasNormal = false, false
    for _, groupView in ipairs(groupViews) do
      local nGroupViewId = tonumber(groupView and groupView.view_id)
      local groupViewInfo = nGroupViewId and logic_mode_selection:GetSubviewInfoBySubviewID(nGroupViewId)
      if groupViewInfo then
        if tonumber(groupViewInfo.is_ranked) == 1 then
          bHasRanked = true
        else
          bHasNormal = true
        end
      end
    end
    bRankMatchGroup = bHasRanked and bHasNormal
  end
  log(bWriteLog and string.format("[SideberFriendStatus] detail targets viewId=%s, is_ranked=%s, rankMatchGroup=%s, modeIds=[%s], groupViews=[%s]", tostring(nViewId), tostring(viewInfo and viewInfo.is_ranked), tostring(bRankMatchGroup), table.concat(modeIdList, ","), self:_FormatGroupViewsForLog(groupViews)))
  return viewSet, modeSet, bRankMatchGroup
end

function ModeSelection_Sideber_FriendStatus_UIBP:_GetSideberFriendUids()
  local logic_teamup_side_bar = require("client.slua.logic.lobby.logic_teamup_side_bar")
  if not logic_teamup_side_bar or not logic_teamup_side_bar.GetFriends then
    return {}
  end
  local uidList = {}
  for _, friend in ipairs(logic_teamup_side_bar.GetFriends() or {}) do
    local uid = tonumber(friend and friend.uid)
    if uid then
      uidList[#uidList + 1] = uid
    end
  end
  return uidList
end

function ModeSelection_Sideber_FriendStatus_UIBP:_IsFriendDoNotDisturb(uid)
  return ModeSelection_Friend_Util.IsFriendDoNotDisturb(uid)
end

function ModeSelection_Sideber_FriendStatus_UIBP:_IsPlayingInRecommend(status, recommendViewSet, recommendModeSet)
  if not status then
    return false
  end
  local subModeId = tonumber(status.game_sub_mode)
  if not subModeId or subModeId <= 0 then
    return false
  end
  for _, viewId in ipairs(self:_GetViewIdsBySubModeId(subModeId)) do
    if recommendViewSet[viewId] then
      return true
    end
  end
  return recommendModeSet[subModeId] == true
end

function ModeSelection_Sideber_FriendStatus_UIBP:_IsPlayingInDetail(status, detailViewSet, detailModeSet, bRankMatchGroup)
  if not status then
    return false
  end
  local subModeId = tonumber(status.game_sub_mode)
  if not subModeId or subModeId <= 0 then
    return false
  end
  local bViewMatched = false
  for _, viewId in ipairs(self:_GetViewIdsBySubModeId(subModeId)) do
    if detailViewSet[viewId] then
      bViewMatched = true
      break
    end
  end
  if not bViewMatched then
    return false
  end
  if not bRankMatchGroup or not next(detailModeSet) then
    return true
  end
  local gameMode = tonumber(status.game_mode)
  if not gameMode or gameMode <= 0 then
    log(bWriteLog and string.format("[SideberFriendStatus] mode layer rejected: game_mode missing. uid=%s game_mode=%s game_sub_mode=%s", tostring(status.uid), tostring(status.game_mode), tostring(status.game_sub_mode)))
    return false
  end
  local bModeMatched = detailModeSet[gameMode] == true
  if not bModeMatched then
    log(bWriteLog and string.format("[SideberFriendStatus] mode layer rejected: not in current view's modeSet. uid=%s game_mode=%s game_sub_mode=%s", tostring(status.uid), tostring(gameMode), tostring(status.game_sub_mode)))
  end
  return bModeMatched
end

function ModeSelection_Sideber_FriendStatus_UIBP:_SplitFriendsByPlaying()
  local playing, recent = {}, {}
  local detailViewSet, detailModeSet, bRankMatchGroup = self:_GetDetailTargets()
  local PlayerStatusMgr = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr)
  local seenUid = {}
  
  local function collect(uidList, bAllowRecent, fnIsPlaying, playTimes)
    for _, uid in ipairs(uidList or {}) do
      local nUid = tonumber(uid)
      if nUid and not seenUid[nUid] and not self:_IsFriendDoNotDisturb(nUid) then
        seenUid[nUid] = true
        local status = PlayerStatusMgr and PlayerStatusMgr:GetStatusData(nUid) or nil
        local bOnline = status and status.online and status.online > 0 and true or false
        local bPlaying = bOnline and fnIsPlaying and fnIsPlaying(status) or false
        if bPlaying then
          log(bWriteLog and string.format("[SideberFriendStatus] playing hit uid=%s game_mode=%s game_sub_mode=%s", tostring(nUid), tostring(status and status.game_mode), tostring(status and status.game_sub_mode)))
        end
        if bPlaying or bAllowRecent then
          local record = {
            uid = nUid,
            bOnline = bOnline,
            bPlaying = bPlaying and true or false,
            ui_status = bPlaying and ITEM_STATUS_PLAYING or ITEM_STATUS_RECENT,
            last_play_time = playTimes and playTimes[nUid] or nil
          }
          if bPlaying then
            playing[#playing + 1] = record
          else
            recent[#recent + 1] = record
          end
        end
      end
    end
  end
  
  collect(self:_GetSideberFriendUids(), false, function(status)
    return self:_IsPlayingInDetail(status, detailViewSet, detailModeSet, bRankMatchGroup)
  end)
  if 1 < #recent then
    local orderOf = {}
    for i = 1, #recent do
      orderOf[recent[i].uid] = i
    end
    table.sort(recent, function(a, b)
      if a.bOnline ~= b.bOnline then
        return a.bOnline
      end
      return (orderOf[a.uid] or 0) < (orderOf[b.uid] or 0)
    end)
  end
  log(bWriteLog and string.format("ModeSelection_Sideber_FriendStatus_UIBP:_SplitFriendsByPlaying playing=%d, recent=%d", #playing, #recent))
  return playing, recent
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
return class(ui_base, nil, ModeSelection_Sideber_FriendStatus_UIBP)
