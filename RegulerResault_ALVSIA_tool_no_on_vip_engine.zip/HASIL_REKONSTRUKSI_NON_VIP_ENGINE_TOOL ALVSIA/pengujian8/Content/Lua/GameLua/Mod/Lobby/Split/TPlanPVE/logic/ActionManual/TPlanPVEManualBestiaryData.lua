local TPlanPVEManualBestiaryData = {
  ENUM_MONSTER_TYPE = {
    ALL = 0,
    DEFAULT = 1,
    BOSS = 2
  }
}

function TPlanPVEManualBestiaryData.GetMonsterList(type)
  type = type or TPlanPVEManualBestiaryData.ENUM_MONSTER_TYPE.ALL
  local result = {}
  local data = CDataTable.GetTable("TPlanXActionManualMonsterBestiary")
  for key, value in pairs(data) do
    local mType = value.MonsterType or 1
    if type == TPlanPVEManualBestiaryData.ENUM_MONSTER_TYPE.ALL or mType == type then
      local item = {
        BestiaryID = value.BestiaryID,
        MonsterName = value.MonsterName,
        MonsterIcon = value.MonsterIcon,
        MonsterDesc = value.MonsterDesc,
        MonsterClue = value.MonsterClue,
        MonsterWeakness = value.MonsterWeakness,
        MonsterType = value.MonsterType,
        MonsterAvatar = value.MonsterAvatar or ""
      }
      table.insert(result, item)
    end
  end
  return result
end

function TPlanPVEManualBestiaryData.GetWeaknessTable(book_id)
  local table_data = CDataTable.GetTableData("TPlanXActionManualMonsterBestiary", book_id)
  if not table_data then
    log(bWriteLog and "TPlanPVEManualBestiaryData.GetWeaknessTable table_data is nil, book_id = " .. tostring(book_id))
    return nil
  end
  local StringUtil = require("common.string_util")
  local strList = StringUtil.Split(table_data.MonsterWeakness, "|")
  local result = {}
  for index, value in ipairs(strList) do
    local paras = StringUtil.SplitToNum(value, ";")
    if #paras < 2 then
      log(bWriteLog and "logic_pve_action_manual:SplitPara error para = " .. value)
    else
      local level = paras[1]
      result[level] = result[level] or {}
      local weaknessID = paras[2]
      local cfg = CDataTable.GetTableData("TPlanXActionManualMonsterWeakness", weaknessID)
      if cfg then
        result[level][cfg.WeaknessPosition] = cfg.WeaknessDesc
      end
    end
  end
  return result
end

function TPlanPVEManualBestiaryData.GetClueListInfo(clueStr)
  local logic_pve_action_manual = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_pve_action_manual)
  local clueList = logic_pve_action_manual:SplitPara(clueStr)
  local result = {}
  for index, value in ipairs(clueList) do
    table.insert(result, TPlanPVEManualBestiaryData.GetClueInfo(value))
  end
  log(bWriteLog and "TPlanPVEManualBestiaryData.GetClueInfo clueStr:" .. clueStr)
  log_tree("TPlanPVEManualBestiaryData.GetClueInfo result:", result)
  return result
end

function TPlanPVEManualBestiaryData.GetClueInfo(clue_id)
  local logic_pve_action_manual = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_pve_action_manual)
  local clueInfo = CDataTable.GetTableData("TPlanXActionManualMonsterClue", clue_id)
  if not clueInfo then
    log(bWriteLog and "TPlanPVEManualBestiaryData.GetClueInfo clueInfo is nil, clueId:" .. clue_id)
    return nil
  end
  local item = {
    ClueID = clueInfo.ClueID,
    ClueText = clueInfo.ClueText,
    AttributeBonus = clueInfo.AttributeBonus,
    ConditionList = logic_pve_action_manual:SplitPara(clueInfo.UnlockCondition),
    Exp = clueInfo.Exp or 0,
    ClueIcon = clueInfo.ClueIcon,
    BeforeTextID = clueInfo.BeforeTextID or 0,
    TypeTag = clueInfo.TypeTag or ""
  }
  return item
end

function TPlanPVEManualBestiaryData.RevealingClues(book_id, cur_clue)
  local logic_pve_action_manual = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_pve_action_manual)
  local monsterData = CDataTable.GetTableData("TPlanXActionManualMonsterBestiary", book_id)
  local mosnterInfo = logic_pve_action_manual:GetBestiaryInfo(book_id)
  if not monsterData then
    log(bWriteLog and "logic_pve_action_manual:RevealingClues monsterData is nil")
    return
  end
  if not mosnterInfo then
    log(bWriteLog and "logic_pve_action_manual:RevealingClues mosnterInfo is nil")
    return
  end
  if mosnterInfo.cur_clue ~= cur_clue then
    log(bWriteLog and "logic_pve_action_manual:RevealingClues cur_clue is over")
    return
  end
  local clueList = logic_pve_action_manual:SplitPara(monsterData.MonsterClue)
  local ClueID = clueList[mosnterInfo.cur_clue + 1]
  logic_pve_action_manual:send_tplanx_codex_reveal_req(book_id, ClueID)
end

function TPlanPVEManualBestiaryData.SetStageInfo(root, index, data)
  local widget = root.UIRoot
  local logic_pve_action_manual = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_pve_action_manual)
  local buffList = logic_pve_action_manual:SplitPara(data.AttributeBonus, true)
  local showExp = data.Exp > 0
  local key = next(buffList)
  local showWeakness = key ~= nil
  local UIUtil = require("client.common.ui_util")
  local r = UIUtil.IsRTL()
  widget.WidgetSwitcher_R:SetActiveWidgetIndex(r and 1 or 0)
  if not r then
    if showWeakness then
      widget.Text_Damage:SetText(LocUtil.LocalizeResFormat(10283, buffList[key]))
    end
    widget.Text_Exp:SetText(data.Exp)
    widget.Text_Title:SetText(LocUtil.LocalizeResFormat(260866015, index))
    root:SetWidgetVisible(widget.Text_Damage, showWeakness)
    root:SetWidgetVisible(widget.Img_Damage, showWeakness)
    root:SetWidgetVisible(widget.Text_Exp, showExp)
    root:SetWidgetVisible(widget.Icon_EXP, showExp)
  else
    if showWeakness then
      widget.Text_Damage_r:SetText(LocUtil.LocalizeResFormat(10283, buffList[key]))
    end
    widget.Text_Exp_r:SetText(data.Exp)
    widget.Text_Title_r:SetText(LocUtil.LocalizeResFormat(260866015, index))
    root:SetWidgetVisible(widget.Text_Damage_r, showWeakness)
    root:SetWidgetVisible(widget.Img_Damage_r, showWeakness)
    root:SetWidgetVisible(widget.Text_Exp_r, showExp)
    root:SetWidgetVisible(widget.Icon_EXP_r, showExp)
  end
end

return TPlanPVEManualBestiaryData
