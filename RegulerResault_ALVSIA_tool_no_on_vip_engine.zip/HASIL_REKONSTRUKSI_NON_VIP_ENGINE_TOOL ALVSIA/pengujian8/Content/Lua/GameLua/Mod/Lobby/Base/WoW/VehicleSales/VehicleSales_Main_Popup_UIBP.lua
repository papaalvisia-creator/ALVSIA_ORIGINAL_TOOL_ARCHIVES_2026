local VehicleSales_Main_Popup_UIBP = {}

function VehicleSales_Main_Popup_UIBP:ctor(_, ctorData)
  self.data = ctorData
  self.act_id = 447270001
  if self.data and self.data.act_id then
    self.act_id = tonumber(self.data.act_id)
  end
  self.get_act_id = 644265100
end

function VehicleSales_Main_Popup_UIBP:OnInitialize()
end

function VehicleSales_Main_Popup_UIBP:RegistEvents()
  if self.UIRoot.VehicleSales_Main_Popup01 and self.UIRoot.VehicleSales_Main_Popup01.close then
    self:AddOnClickedEventByControl(self.UIRoot.VehicleSales_Main_Popup01.close, self.OnClickButton_Close, self)
  end
  if self.UIRoot.Button_21 then
    self:AddOnClickedEventByControl(self.UIRoot.Button_21, self.OnClickButton_21, self)
  end
  if self.UIRoot.Button_Buy then
    self:AddOnClickedEventByControl(self.UIRoot.Button_Buy, self.OnClickButton_Refund, self)
  end
  self:AddCommonEvent(EVENTTYPE_ACTIVITY, EVENTID_VEHICLE_SALES_REFUND_RESULT, self.OnRefundResult, self)
  self:AddCommonEvent(EVENTTYPE_ACTIVITY, EVENTID_VEHICLE_SALES_SHOP_UPDATE, self.OnShopUpdate, self)
end

function VehicleSales_Main_Popup_UIBP:OnPostInitialize()
  self:UpdateUI()
end

function VehicleSales_Main_Popup_UIBP:OnClose()
end

function VehicleSales_Main_Popup_UIBP:OnClickButton_Close()
  self:PlayAudio(sound_config.click_v1)
  self:CloseSelf()
end

function VehicleSales_Main_Popup_UIBP:OnClickButton_21()
  self:PlayAudio(sound_config.click_v1)
  local url = "game://?module=1009665&activityid=447180001&ui=bentley_car_main"
  GlobalData.JumpUrl(url)
  self:CloseSelf()
end

function VehicleSales_Main_Popup_UIBP:UpdateUI()
  if self.UIRoot.VehicleSales_Main_Popup01 and self.UIRoot.VehicleSales_Main_Popup01.Title then
    self.UIRoot.VehicleSales_Main_Popup01.Title:SetText(LocUtil.GetLocalizeResStr(49329))
  end
  local logic = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_vehicle_sales_data)
  if not logic then
    return
  end
  local bUnlocked = self:IsSportsCarUnlocked(logic)
  if self.UIRoot.WidgetSwitcher_0 then
    self.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(bUnlocked and 1 or 0)
  end
  local wowPrice = logic:CalculatePrice(self.act_id, {
    [logic.COND_TYPE.OWN_SPORTS_CAR] = true
  })
  local bReachedFirstTier = self:HasReachedAnyProgressTier(logic)
  if self.UIRoot.TextBlock_11 then
    if bReachedFirstTier then
      self:SetPriceText(self.UIRoot.TextBlock_11, wowPrice)
    else
      self.UIRoot.TextBlock_11:SetText("--")
    end
  end
  local floorPrice = logic:GetFloorPrice(self.act_id)
  self:SetPriceText(self.UIRoot.TextBlock_9, floorPrice)
  self:SetPriceText(self.UIRoot.TextBlock_1, floorPrice)
  local wowFloorPrice = logic:GetFloorPrice(self.act_id)
  if self.UIRoot.AutoScrollTextBlock_21 then
    self.UIRoot.AutoScrollTextBlock_21:SetText(LocUtil.LocalizeResFormat(90070, tostring(wowFloorPrice)))
  end
  if self.UIRoot.ScaleBox_3 then
    self:SetWidgetVisible(self.UIRoot.ScaleBox_3, not bUnlocked)
  end
  self:UpdateRefundArea(logic)
end

function VehicleSales_Main_Popup_UIBP:UpdateRefundArea(logic)
  local shopInfo = logic:GetShopInfo(self.act_id)
  local product = shopInfo and shopInfo.product
  local refundInfo = product and product.refund_info
  local refund = refundInfo or {}
  local bBought = refundInfo ~= nil
  local bCanRefund = bBought and 0 < (refund.refundable or 0)
  if self.UIRoot.TextBlock_4 then
    if bBought then
      self:SetPriceText(self.UIRoot.TextBlock_4, refund.paid_uc or 0)
    else
      self.UIRoot.TextBlock_4:SetText(LocUtil.GetLocalizeResStr(77200))
    end
  end
  if self.UIRoot.TextBlock_5 then
    local priceInfo = product and product.price_info or {}
    self:SetPriceText(self.UIRoot.TextBlock_5, priceInfo.cur_price or 0)
  end
  if self.UIRoot.UTRichTextBlock_20 then
    local refunded = bBought and (refund.refunded_uc or 0) or 0
    self.UIRoot.UTRichTextBlock_20:SetText(LocUtil.LocalizeResFormat(90093, tostring(refunded)))
  end
  if self.UIRoot.UTRichTextBlock_0 then
    local refundable = bBought and (refund.refundable or 0) or 0
    local text = LocUtil.LocalizeResFormat(90094, tostring(refundable))
    text = string.gsub(text, "UC$", "<img src=\"UC_New\"/>")
    self.UIRoot.UTRichTextBlock_0:SetText(text)
  end
  if self.UIRoot.WidgetSwitcher_1 then
    self.UIRoot.WidgetSwitcher_1:SetActiveWidgetIndex(bCanRefund and 0 or 1)
  end
  if self.UIRoot.Button_Buy then
    self:SetButtonEnable(self.UIRoot.Button_Buy, bCanRefund)
  end
end

function VehicleSales_Main_Popup_UIBP:OnRefundResult(_, _, result)
  if result and result.act_id and result.act_id ~= self.act_id then
    return
  end
  local ret = result and result.ret or 0
  if ret == 0 then
    local owed = result and result.owed or 0
    ShowNotice(LocUtil.LocalizeResFormat(19290, tostring(owed)))
  else
    ShowNotice(ret)
  end
end

function VehicleSales_Main_Popup_UIBP:OnShopUpdate(_, _, act_id)
  if act_id and act_id ~= self.act_id then
    return
  end
  local logic = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_vehicle_sales_data)
  if logic then
    self:UpdateRefundArea(logic)
  end
end

function VehicleSales_Main_Popup_UIBP:OnClickButton_Refund()
  self:PlayAudio(sound_config.click_v1)
  local logic = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_vehicle_sales_data)
  if not logic then
    return
  end
  logic:SendTakeDiscountSaleRefund(self.act_id)
end

function VehicleSales_Main_Popup_UIBP:HasReachedAnyProgressTier(logic)
  for _, tier in ipairs(logic:GetTierList(self.act_id)) do
    if tier.cond_type == logic.COND_TYPE.PROGRESS and tier.done then
      return true
    end
  end
  return false
end

function VehicleSales_Main_Popup_UIBP:IsSportsCarUnlocked(logic)
  for _, tier in ipairs(logic:GetTierList(self.act_id)) do
    if tier.cond_type == logic.COND_TYPE.OWN_SPORTS_CAR and tier.status ~= ActivityProgressStatus.Not then
      return true
    end
  end
  return false
end

function VehicleSales_Main_Popup_UIBP:SetPriceText(widget, price)
  if widget and widget.SetText then
    widget:SetText(tostring(price or 0))
  end
end

function VehicleSales_Main_Popup_UIBP:SetButtonEnable(button, bEnable)
  if not button then
    return false
  end
  if button.SetIsEnabled then
    button:SetIsEnabled(bEnable)
  end
  return bEnable
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
return class(ui_base, nil, VehicleSales_Main_Popup_UIBP)
