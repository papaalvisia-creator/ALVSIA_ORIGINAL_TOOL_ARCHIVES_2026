local VehicleSales_Main_UIBP = {}

function VehicleSales_Main_UIBP:ctor(_, ctorData)
  self.data = ctorData
  self.act_id = 447270001
  if self.data and self.data.act_id then
    self.act_id = tonumber(self.data.act_id)
  end
  self.bWaitingBuy = false
  self._discountType = 0
  self._bUserSwitchedTab = false
  self.get_act_id = 644265100
end

function VehicleSales_Main_UIBP:OnInitialize()
  self.ProgressScroll = self:InitScrollBox(self.UIRoot.WoW_VehicleSales_Progress_Item_UIBP.LoopScrollBox_0)
  if self.ProgressScroll then
    self.ProgressScroll:SetRefreshItemCallback(self.OnRefreshProgressNode, self)
  end
end

function VehicleSales_Main_UIBP:RegistEvents()
  if self.UIRoot.Button_Close then
    self:AddOnClickedEventByControl(self.UIRoot.Button_Close, self.OnClickButton_Close, self)
  end
  if self.UIRoot.Button_Buy then
    self:AddOnClickedEventByControl(self.UIRoot.Button_Buy, self.OnClickButton_Buy, self)
  end
  if self.UIRoot.Button_Cashback then
    self:AddOnClickedEventByControl(self.UIRoot.Button_Cashback, self.OnClickButton_Cashback, self)
  end
  if self.UIRoot.Button_UC then
    self:AddOnClickedEventByControl(self.UIRoot.Button_UC, self.OnClickButton_UC, self)
  end
  if self.UIRoot.Button_ActivityPoints then
    self:AddOnClickedEventByControl(self.UIRoot.Button_ActivityPoints, self.OnClickButton_ActivityPoints, self)
  end
  if self.UIRoot.Button_Question then
    self:AddOnClickedEventByControl(self.UIRoot.Button_Question, self.OnClickButton_Question, self)
  end
  if self.UIRoot.Button_Obtain then
    self:AddOnClickedEventByControl(self.UIRoot.Button_Obtain, self.OnClickButton_Obtain, self)
  end
  if self.UIRoot.Button_SprotsCarPreview then
    self:AddOnClickedEventByControl(self.UIRoot.Button_SprotsCarPreview, self.OnClickButton_SprotsCarPreview, self)
  end
  if self.UIRoot.Button_0 then
    self:AddOnClickedEventByControl(self.UIRoot.Button_0, self.OnClickButton_GoGetSportsCar, self)
  end
  if self.UIRoot.Button_9 then
    self:AddOnClickedEventByControl(self.UIRoot.Button_9, self.OnClickButton_9, self)
  end
  if self.UIRoot.Button_10 then
    self:AddOnClickedEventByControl(self.UIRoot.Button_10, self.OnClickButton_10, self)
  end
  self:AddCommonEvent(EVENTTYPE_DATA_MGR, EVENTID_DATAMGR_TICKET_CHANGE, self.OnTicketChange, self)
  self:AddCommonEvent(EVENTTYPE_ACTIVITY, EVENTID_VEHICLE_SALES_SHOP_UPDATE, self.OnShopUpdate, self)
  self:AddCommonEvent(EVENTTYPE_ACTIVITY, EVENTID_VEHICLE_SALES_BUY_RESULT, self.OnBuyResult, self)
  self:AddCommonEvent(EVENTTYPE_ACTIVITY, EVENTID_VEHICLE_SALES_REFUND_RESULT, self.OnRefundResult, self)
  self:AddCommonEvent(EVENTTYPE_ACTIVITY, EVEMTID_DATAMGR_ACTIVITY_REWARDS_COMMON, self.OnActivityRewardTaken, self)
end

function VehicleSales_Main_UIBP:OnPostInitialize()
  local logic_vehicle_sales_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_vehicle_sales_data)
  if logic_vehicle_sales_data then
    logic_vehicle_sales_data:SendGetDiscountSaleShop(self.act_id)
  end
  self:UpdateActDate()
  self:UpdateActTime()
  self:StartCountdownTimer()
  self:UpdateUI()
end

function VehicleSales_Main_UIBP:OnShow()
end

function VehicleSales_Main_UIBP:OnClose()
  if self._nCountdownTimer then
    self:RemoveTimer(self._nCountdownTimer)
    self._nCountdownTimer = nil
  end
  self._bPlayingUnlockAnim = false
end

function VehicleSales_Main_UIBP:OnClickButton_Close()
  self:PlayAudio(sound_config.click_v1)
  self:CloseSelf()
end

function VehicleSales_Main_UIBP:OnClickButton_UC()
  self:PlayAudio(sound_config.click_v1)
  local RechargeSystem = require("client.logic.recharge.logic_recharge")
  if RechargeSystem then
    RechargeSystem.OpenRechargeUI()
  end
end

function VehicleSales_Main_UIBP:OnClickButton_ActivityPoints()
  self:PlayAudio(sound_config.click_v1)
  local points = self:GetActivityPoints(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_vehicle_sales_data))
  UIManager.ShowUI(UIManager.UI_Config.WoW_VehicleSales_ActivityPointsTips_Item_UIBP, {
    act_id = self.act_id,
    points = points,
    anchorWidget = self.UIRoot.Button_ActivityPoints
  })
end

function VehicleSales_Main_UIBP:OnClickButton_Question()
  self:PlayAudio(sound_config.click_v1)
  local title = LocUtil.GetLocalizeResStr(220006)
  local msg = LocUtil.GetLocalizeResStr(90096)
  UIManager.ShowUI(UIManager.UI_Config.common_protocol_msg, 0, title, msg)
end

function VehicleSales_Main_UIBP:OnClickButton_Obtain()
  self:PlayAudio(sound_config.click_v1)
  local jump_utils = require("client.logic.store.jump_utils")
  local url = jump_utils.GenerateGameUrl(BP_ENUM_MODULE_ACTIVITY, {
    id = self.get_act_id
  })
  GlobalData.JumpUrl(url)
end

function VehicleSales_Main_UIBP:OnClickButton_Buy()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and string.format("[VehicleSales][Buy] OnClickButton_Buy enter act_id=%s discountType=%s bWaitingBuy=%s", tostring(self.act_id), tostring(self._discountType), tostring(self.bWaitingBuy)))
  if self.bWaitingBuy then
    log(bWriteLog and string.format("[VehicleSales][Buy] blocked: bWaitingBuy is true, ignore click"))
    return
  end
  local logic_vehicle_sales_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_vehicle_sales_data)
  if not logic_vehicle_sales_data then
    log(bWriteLog and string.format("[VehicleSales][Buy] blocked: logic_vehicle_sales_data is nil"))
    return
  end
  local bBought = logic_vehicle_sales_data:IsBought(self.act_id)
  local bSportsCarUnlocked = self:IsSportsCarUnlocked(logic_vehicle_sales_data)
  local bWowReached = self:IsWowReached(logic_vehicle_sales_data)
  log(bWriteLog and string.format("[VehicleSales][Buy] state bBought=%s bSportsCarUnlocked=%s bWowReached=%s", tostring(bBought), tostring(bSportsCarUnlocked), tostring(bWowReached)))
  if bBought then
    log(bWriteLog and string.format("[VehicleSales][Buy] blocked: already bought, show ERR.LIMIT_BUY=%s", tostring(logic_vehicle_sales_data.ERR.LIMIT_BUY)))
    ShowNotice(logic_vehicle_sales_data.ERR.LIMIT_BUY)
    self:UpdateUI()
    return
  end
  if self._discountType == 1 and not bSportsCarUnlocked then
    log(bWriteLog and string.format("[VehicleSales][Buy] blocked: sportsCar tab selected but not unlocked"))
    return
  end
  if bSportsCarUnlocked and not bWowReached and self._discountType ~= 1 then
    log(bWriteLog and string.format("[VehicleSales][Buy] show sportsCar guide popup, skip send buy req"))
    self:ShowSportsCarGuide()
    return
  end
  local shopInfo = logic_vehicle_sales_data:GetShopInfo(self.act_id)
  local product = shopInfo and shopInfo.product
  local price_info = product and product.price_info
  log(bWriteLog and string.format("[VehicleSales][Buy] shopInfo=%s product=%s base_price=%s cur_price=%s progress=%s", tostring(shopInfo ~= nil), tostring(product ~= nil), tostring(price_info and price_info.base_price), tostring(price_info and price_info.cur_price), tostring(price_info and price_info.progress)))
  self.bWaitingBuy = true
  logic_vehicle_sales_data:SendBuyDiscountSale(self.act_id)
  log(bWriteLog and string.format("[VehicleSales][Buy] SendBuyDiscountSale done act_id=%s count=%s", tostring(self.act_id), tostring(product and product.count)))
end

function VehicleSales_Main_UIBP:ShowSportsCarGuide()
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  local title = LocUtil.GetLocalizeResStr(6177)
  local msg = LocUtil.GetLocalizeResStr(90083)
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_ONE, title, msg, function()
    self._bUserSwitchedTab = true
    self:SwitchDiscountType(1)
    self:RefreshBuyPrice()
  end)
end

function VehicleSales_Main_UIBP:OnClickButton_SprotsCarPreview()
  self:PlayAudio(sound_config.click_v1)
  local logic_vehicle_sales_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_vehicle_sales_data)
  if not logic_vehicle_sales_data then
    return
  end
  local shopInfo = logic_vehicle_sales_data:GetShopInfo(self.act_id)
  local product = shopInfo and shopInfo.product
  if not product or not product.res_id then
    return
  end
  LobbySystem.PlayItemPreviewAnimation(product.res_id, false, nil, nil, nil)
end

function VehicleSales_Main_UIBP:OnClickButton_GoGetSportsCar()
  self:PlayAudio(sound_config.click_v1)
  local logic_vehicle_sales_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_vehicle_sales_data)
  if not logic_vehicle_sales_data then
    return
  end
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  local title = LocUtil.GetLocalizeResStr(101001)
  local msg = LocUtil.GetLocalizeResStr(90084)
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_TWO, title, msg, function()
    self:JumpToSportsCarCollect()
  end)
end

function VehicleSales_Main_UIBP:JumpToSportsCarCollect()
  local url = "game://?module=1009665&activityid=447180001&ui=bentley_car_main"
  log(bWriteLog and "JumpToSportsCarCollect url: " .. url)
  GlobalData.JumpUrl(url)
end

function VehicleSales_Main_UIBP:OnClickButton_9()
  self:PlayAudio(sound_config.click_v1)
  self._bUserSwitchedTab = true
  self:SwitchDiscountType(0)
  self:RefreshBuyPrice()
end

function VehicleSales_Main_UIBP:OnClickButton_10()
  self:PlayAudio(sound_config.click_v1)
  self._bUserSwitchedTab = true
  self:SwitchDiscountType(1)
  self:RefreshBuyPrice()
end

function VehicleSales_Main_UIBP:RefreshBuyPrice()
  local logic_vehicle_sales_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_vehicle_sales_data)
  if not logic_vehicle_sales_data then
    return
  end
  local shopInfo = logic_vehicle_sales_data:GetShopInfo(self.act_id)
  local product = shopInfo and shopInfo.product
  if not product then
    return
  end
  self:UpdateLowestPriceBadge(logic_vehicle_sales_data)
  self:UpdateButtonState(not self.bWaitingBuy, false)
  self:UpdatePrice(product, logic_vehicle_sales_data)
end

function VehicleSales_Main_UIBP:SwitchDiscountType(discountType)
  log(bWriteLog and string.format("[VehicleSales][Buy] SwitchDiscountType %s -> %s", tostring(self._discountType), tostring(discountType)))
  self._discountType = discountType
  if self.UIRoot.WidgetSwitcher_0 then
    self.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(discountType == 0 and 0 or 1)
  end
  if self.UIRoot.WidgetSwitcher_1 then
    self.UIRoot.WidgetSwitcher_1:SetActiveWidgetIndex(discountType == 1 and 0 or 1)
  end
  if self.UIRoot.WidgetSwitcher_DiscountType then
    self.UIRoot.WidgetSwitcher_DiscountType:SetActiveWidgetIndex(discountType)
  end
end

function VehicleSales_Main_UIBP:GetTestState()
  local testCase = 0
  if testCase == 0 then
    return nil
  end
  if testCase == 1 then
    return {progress = 30, sportsCarUnlocked = true}
  end
  if testCase == 2 then
    return {progress = 60, sportsCarUnlocked = true}
  end
  return {progress = 60, sportsCarUnlocked = false}
end

function VehicleSales_Main_UIBP:IsSportsCarUnlocked(logic)
  local bUnlocked = logic:IsCondTypeAllDone(self.act_id, logic.COND_TYPE.OWN_SPORTS_CAR)
  local testState = self:GetTestState()
  if testState then
    bUnlocked = testState.sportsCarUnlocked
  end
  return bUnlocked
end

function VehicleSales_Main_UIBP:UpdateSportsCarUnlockState(logic)
  if self._bPlayingUnlockAnim then
    return
  end
  self:SetUnlockState(self:IsSportsCarUnlocked(logic) and 1 or 0)
end

function VehicleSales_Main_UIBP:SetUnlockState(nIdx)
  if self.UIRoot.WidgetSwitcherExt_Unlock then
    self.UIRoot.WidgetSwitcherExt_Unlock:SetActiveWidgetIndex(nIdx)
  end
  if self.UIRoot.WidgetSwitcher_46 then
    self.UIRoot.WidgetSwitcher_46:SetActiveWidgetIndex(nIdx)
  end
  if self.UIRoot.TextBlock_8 then
    self.UIRoot.TextBlock_8:SetText(LocUtil.GetLocalizeResStr(nIdx == 1 and 90081 or 90080))
  end
end

function VehicleSales_Main_UIBP:TryPlaySportsCarUnlockAnim(logic)
  if self._bTriggeredUnlockAnim or not logic then
    log(bWriteLog and string.format("[VehicleSales][UnlockAnim] skip: triggered=%s logic_nil=%s", tostring(self._bTriggeredUnlockAnim), tostring(logic == nil)))
    return
  end
  local bUnlocked = self:IsSportsCarUnlocked(logic)
  if not bUnlocked then
    log(bWriteLog and string.format("[VehicleSales][UnlockAnim] skip: sports car not unlocked, act_id=%s", tostring(self.act_id)))
    return
  end
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local fileType = PlayerPrefsSystem.ePlayerPrefsType.eVehicleSalesSportsCarUnlockAnim
  local savedData = PlayerPrefsSystem.LoadFileToTable_N(fileType) or {}
  if savedData[tostring(self.act_id)] then
    log(bWriteLog and string.format("[VehicleSales][UnlockAnim] skip: already triggered in PlayerPrefs, act_id=%s", tostring(self.act_id)))
    return
  end
  self._bTriggeredUnlockAnim = true
  self._bUserSwitchedTab = true
  self:SwitchDiscountType(1)
  self:RefreshBuyPrice()
  log(bWriteLog and string.format("[VehicleSales][UnlockAnim] start play, act_id=%s discountType=%s", tostring(self.act_id), tostring(self._discountType)))
  self:PlayUnlockAnim(logic)
end

function VehicleSales_Main_UIBP:PlayUnlockAnim(logic)
  local anim = self.UIRoot and self.UIRoot.Anim_Unlock
  if not anim then
    log(bWriteLog and string.format("[VehicleSales][UnlockAnim] Anim_Unlock is nil, fallback to set final state, act_id=%s", tostring(self.act_id)))
    self:UpdateSportsCarUnlockState(logic)
    return
  end
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local fileType = PlayerPrefsSystem.ePlayerPrefsType.eVehicleSalesSportsCarUnlockAnim
  local savedData = PlayerPrefsSystem.LoadFileToTable_N(fileType) or {}
  savedData[tostring(self.act_id)] = true
  PlayerPrefsSystem.SaveTableToFile_N(savedData, fileType)
  local animEndTime = anim:GetEndTime() or 0
  log(bWriteLog and string.format("[VehicleSales][UnlockAnim] Anim_Unlock found, endTime=%s, start play", tostring(animEndTime)))
  self._bPlayingUnlockAnim = true
  self:SetUnlockState(0)
  self:PlayUserWidgetAnimation(anim, 0, 1, 0, 1)
  self:AddTimerOnce(animEndTime, function()
    log(bWriteLog and string.format("[VehicleSales][UnlockAnim] anim finished, UIRoot_valid=%s", tostring(slua.isValid(self.UIRoot))))
    if not slua.isValid(self.UIRoot) then
      return
    end
    self._bPlayingUnlockAnim = false
    self:UpdateSportsCarUnlockState(logic)
  end)
end

function VehicleSales_Main_UIBP:IsWowReached(logic)
  local bReached = logic:IsCondTypeAllDone(self.act_id, logic.COND_TYPE.LOGIN) and logic:IsCondTypeAllDone(self.act_id, logic.COND_TYPE.PROGRESS)
  local testState = self:GetTestState()
  if testState then
    local maxThreshold = 0
    for _, tier in ipairs(logic:GetTierList(self.act_id)) do
      if tier.cond_type == logic.COND_TYPE.PROGRESS and maxThreshold < (tier.cond_param or 0) then
        maxThreshold = tier.cond_param
      end
    end
    bReached = maxThreshold <= testState.progress
  end
  return bReached
end

function VehicleSales_Main_UIBP:UpdateDiscountTab(logic)
  local bSportsCarUnlocked = self:IsSportsCarUnlocked(logic)
  local bWowReached = self:IsWowReached(logic)
  if not self._bUserSwitchedTab then
    local defaultType = not (not bSportsCarUnlocked or bWowReached) and 1 or 0
    self:SwitchDiscountType(defaultType)
  end
  self:UpdateLowestPriceBadge(logic)
end

function VehicleSales_Main_UIBP:UpdateLowestPriceBadge(logic)
  if not self.UIRoot.CanvasPanel_13 then
    return
  end
  local bShowBadge = self:IsSportsCarUnlocked(logic) and self._discountType ~= 1 and not logic:IsBought(self.act_id)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_13, bShowBadge)
end

function VehicleSales_Main_UIBP:OnClickButton_Cashback()
  self:PlayAudio(sound_config.click_v1)
  UIManager.ShowUI(UIManager.UI_Config.VehicleSales_Main_Popup_UIBP, {
    act_id = self.act_id
  })
end

function VehicleSales_Main_UIBP:OnShopUpdate(_, _, act_id)
  log(bWriteLog and string.format("[VehicleSales][Buy] OnShopUpdate act_id=%s self_act_id=%s", tostring(act_id), tostring(self.act_id)))
  if act_id and act_id ~= self.act_id then
    return
  end
  self.bWaitingBuy = false
  self:UpdateUI()
  local logic_vehicle_sales_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_vehicle_sales_data)
  self:TryPlaySportsCarUnlockAnim(logic_vehicle_sales_data)
end

function VehicleSales_Main_UIBP:OnBuyResult(_, _, item_info, result)
  self.bWaitingBuy = false
  local ret = result and result.ret or 0
  log(bWriteLog and string.format("[VehicleSales][Buy] OnBuyResult ret=%s rsp_act_id=%s self_act_id=%s item_info=%s", tostring(ret), tostring(result and result.act_id), tostring(self.act_id), tostring(item_info ~= nil)))
  if result and result.act_id and result.act_id ~= self.act_id then
    log(bWriteLog and string.format("[VehicleSales][Buy] OnBuyResult ignored: act_id mismatch"))
    return
  end
  local logic_vehicle_sales_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_vehicle_sales_data)
  if ret == 0 then
    if logic_vehicle_sales_data then
      logic_vehicle_sales_data:SendGetDiscountSaleShop(self.act_id)
    end
    log(bWriteLog and string.format("[VehicleSales][Buy] OnBuyResult success, refresh snapshot & show item get"))
    self:ShowBuyItemGet(item_info)
  elseif logic_vehicle_sales_data and ret == logic_vehicle_sales_data.ERR.PRICE_MISMATCH then
    log(bWriteLog and string.format("[VehicleSales][Buy] buy price mismatch(ret=%s), refresh snapshot", tostring(ret)))
  else
    log(bWriteLog and string.format("[VehicleSales][Buy] buy failed ret=%s, show notice", tostring(ret)))
    ShowNotice(ret)
  end
  self:UpdateUI()
end

function VehicleSales_Main_UIBP:ShowBuyItemGet(item_info)
  local itemInfo = item_info and item_info.item_info
  if not itemInfo then
    return
  end
  local itemList = itemInfo
  if itemInfo.resid ~= nil or itemInfo.res_id ~= nil then
    itemList = {itemInfo}
  end
  local tAllItemData = {}
  for _, item in ipairs(itemList) do
    if item and (item.resid ~= nil or item.res_id ~= nil) then
      table.insert(tAllItemData, {
        res_id = item.res_id or item.resid,
        count = item.count or 1
      })
    end
  end
  if #tAllItemData == 0 then
    return
  end
  local Logic_CommonItemGet = require("client.slua.logic.common.CommonItemGet.Logic_CommonItemGet")
  Logic_CommonItemGet.ShowPanel_DefaultStyle(tAllItemData)
end

function VehicleSales_Main_UIBP:OnRefundResult(_, _, result)
  if result and result.act_id and result.act_id ~= self.act_id then
    return
  end
  local ret = result and result.ret or 0
  if ret == 0 then
    log(string.format("[VehicleSales] refund success, owed=%s", tostring(result and result.owed)))
  else
    ShowNotice(ret)
  end
  self:UpdateUI()
end

function VehicleSales_Main_UIBP:OnActivityRewardTaken(_, _, activityId)
  if activityId and activityId ~= self.act_id then
    return
  end
  local logic_vehicle_sales_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_vehicle_sales_data)
  if logic_vehicle_sales_data then
    logic_vehicle_sales_data:SendGetDiscountSaleShop(self.act_id)
  end
  self:UpdateUI()
end

function VehicleSales_Main_UIBP:UpdateUI()
  local logic_vehicle_sales_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_vehicle_sales_data)
  if not logic_vehicle_sales_data then
    log(bWriteLog and string.format("[VehicleSales] UpdateUI: logic_vehicle_sales_data is nil, return"))
    return
  end
  self:UpdateActDate()
  self:UpdateActTime()
  self:UpdateSystemInfo(logic_vehicle_sales_data)
  self:UpdateCurrency(logic_vehicle_sales_data)
  self:UpdateWowSpecialDiscount(logic_vehicle_sales_data)
  self:UpdateDiscountTab(logic_vehicle_sales_data)
  self:UpdateSportsCarUnlockState(logic_vehicle_sales_data)
  local shopInfo = logic_vehicle_sales_data:GetShopInfo(self.act_id)
  local product = shopInfo and shopInfo.product
  if not product then
    self:UpdateButtonState(false, true)
    return
  end
  self:UpdateButtonState(not self.bWaitingBuy, false)
  self:UpdateProduct(product, logic_vehicle_sales_data)
  self:UpdatePrice(product, logic_vehicle_sales_data)
  self:UpdateProgress(product, logic_vehicle_sales_data)
  self:UpdateRefundEntry(product)
end

function VehicleSales_Main_UIBP:UpdateProduct(product, logic)
  local itemCfg = CDataTable.GetTableData("Item", product.res_id)
  if self.UIRoot.TextBlock_3 then
    self.UIRoot.TextBlock_3:SetText(itemCfg and itemCfg.ItemName or "")
  end
  if self.UIRoot.TextBlock_CarCount then
    self.UIRoot.TextBlock_CarCount:SetText("x" .. tostring(product.count or 1))
  end
end

function VehicleSales_Main_UIBP:UpdatePrice(product, logic)
  local price_info = product.price_info or {}
  local basePrice = price_info.base_price or logic:GetBasePrice(self.act_id)
  local curPrice = logic:GetCurPrice(self.act_id)
  if self.UIRoot.TextBlock_11 then
    self.UIRoot.TextBlock_11:SetText(tostring(basePrice))
  end
  if self.UIRoot.TextBlock_6 then
    self.UIRoot.TextBlock_6:SetText(tostring(basePrice))
  end
  if self.UIRoot.TextBlock_9 then
    self.UIRoot.TextBlock_9:SetText(tostring(curPrice))
  end
  if self.UIRoot.AutoScrollTextBlock_LowestPrice then
    local floor = logic:GetFloorPrice(self.act_id)
    self.UIRoot.AutoScrollTextBlock_LowestPrice:SetText(LocUtil.LocalizeResFormat(90070, tostring(floor)))
  end
  if self.UIRoot.AutoScrollTextBlock_0 then
    local text = LocUtil.GetLocalizeResStr(90079)
    self.UIRoot.AutoScrollTextBlock_0:SetText(LocUtil.GetLocalizeResStr(90079))
  end
  if self.UIRoot.AutoScrollTextBlock_63 then
    self.UIRoot.AutoScrollTextBlock_63:SetText(LocUtil.GetLocalizeResStr(90078))
  end
  self:UpdateDiscountTabPrice(product, logic)
end

function VehicleSales_Main_UIBP:UpdateDiscountTabPrice(product, logic)
  local price_info = product.price_info or {}
  local basePrice = price_info.base_price or logic:GetBasePrice(self.act_id)
  local progress = price_info.progress or 0
  local loginDiscountByLayer = {}
  for _, tier in ipairs(logic:GetTierList(self.act_id)) do
    if tier.cond_type == logic.COND_TYPE.LOGIN and tier.discount then
      local layer = tier.layer or 1
      local cur = loginDiscountByLayer[layer]
      if not cur or cur > tier.discount then
        loginDiscountByLayer[layer] = tier.discount
      end
    end
  end
  
  local function ApplyLoginDiscount(price, layer)
    local disc = loginDiscountByLayer[layer or 1]
    if disc and disc < 100 then
      return price * disc / 100
    end
    return price
  end
  
  local wowPrice = basePrice
  local wowLayerMin = {}
  local bWowHasDone = false
  for _, tier in ipairs(logic:GetTierList(self.act_id)) do
    if tier.cond_type == logic.COND_TYPE.PROGRESS and tier.discount then
      local threshold = tier.cond_param or 0
      if progress >= threshold then
        bWowHasDone = true
        local layer = tier.layer or 1
        local cur = wowLayerMin[layer]
        if not cur or cur > tier.discount then
          wowLayerMin[layer] = tier.discount
        end
      end
    end
  end
  for layer, disc in pairs(wowLayerMin) do
    wowPrice = ApplyLoginDiscount(wowPrice * disc / 100, layer)
  end
  for layer, disc in pairs(loginDiscountByLayer) do
    if disc < 100 and not wowLayerMin[layer] then
      wowPrice = wowPrice * disc / 100
    end
  end
  wowPrice = math.floor(wowPrice + 0.5)
  local sportsPrice = basePrice
  local progressPrice = basePrice
  for layer, disc in pairs(wowLayerMin) do
    progressPrice = ApplyLoginDiscount(progressPrice * disc / 100, layer)
  end
  for layer, disc in pairs(loginDiscountByLayer) do
    if disc < 100 and not wowLayerMin[layer] then
      progressPrice = progressPrice * disc / 100
    end
  end
  local bSportsDone = false
  for _, tier in ipairs(logic:GetTierList(self.act_id)) do
    if tier.cond_type == logic.COND_TYPE.OWN_SPORTS_CAR and tier.done and tier.discount then
      sportsPrice = ApplyLoginDiscount(progressPrice * tier.discount / 100, tier.layer)
      bSportsDone = true
      break
    end
  end
  if not bSportsDone then
    sportsPrice = progressPrice
  end
  sportsPrice = math.floor(sportsPrice + 0.5)
  local wowText = LocUtil.LocalizeResFormat(90073, tostring(wowPrice))
  local sportsText = LocUtil.LocalizeResFormat(90073, tostring(sportsPrice))
  if self.UIRoot.AutoScrollTextBlock_24 then
    self.UIRoot.AutoScrollTextBlock_24:SetText(wowText)
  end
  if self.UIRoot.AutoScrollTextBlock_55 then
    self.UIRoot.AutoScrollTextBlock_55:SetText(wowText)
  end
  if self.UIRoot.AutoScrollTextBlock_57 then
    self.UIRoot.AutoScrollTextBlock_57:SetText(sportsText)
  end
  if self.UIRoot.AutoScrollTextBlock_61 then
    self.UIRoot.AutoScrollTextBlock_61:SetText(sportsText)
  end
  if self.UIRoot.AutoScrollTextBlock_22 then
    self.UIRoot.AutoScrollTextBlock_22:SetText(LocUtil.GetLocalizeResStr(90072))
  end
  if self.UIRoot.AutoScrollTextBlock_54 then
    self.UIRoot.AutoScrollTextBlock_54:SetText(LocUtil.GetLocalizeResStr(90072))
  end
  if self.UIRoot.AutoScrollTextBlock_56 then
    self.UIRoot.AutoScrollTextBlock_56:SetText(LocUtil.GetLocalizeResStr(90074))
  end
  if self.UIRoot.AutoScrollTextBlock_60 then
    self.UIRoot.AutoScrollTextBlock_60:SetText(LocUtil.GetLocalizeResStr(90074))
  end
  local displayPrice = self._discountType == 1 and sportsPrice or wowPrice
  if self.UIRoot.TextBlock_2 then
    self.UIRoot.TextBlock_2:SetText(tostring(displayPrice))
    if displayPrice > DataMgr.ticket then
      self.UIRoot.TextBlock_2:SetColorAndOpacity(FSlateColor(FLinearColor(1, 0, 0, 1)))
    else
      self.UIRoot.TextBlock_2:SetColorAndOpacity(FSlateColor(FLinearColor(0, 0, 0, 1)))
    end
  end
  if self.UIRoot.TextBlock_Discount then
    local rate = 0 < basePrice and math.floor((1 - displayPrice / basePrice) * 100 + 0.5) or 0
    if 0 < rate then
      self.UIRoot.TextBlock_Discount:SetText(self:FormatDiscount(rate))
      self:SetWidgetVisible(self.UIRoot.TextBlock_Discount, true)
    else
      self:SetWidgetVisible(self.UIRoot.TextBlock_Discount, false)
    end
  end
end

function VehicleSales_Main_UIBP:FormatDiscount(rate)
  return string.format("-%d%%", rate)
end

function VehicleSales_Main_UIBP:UpdateProgress(product, logic)
  local price_info = product.price_info or {}
  local progress = price_info.progress or 0
  self._progressBasePrice = price_info.base_price or logic:GetBasePrice(self.act_id)
  local tierList = {}
  for _, tier in ipairs(logic:GetTierList(self.act_id)) do
    if tier.cond_type == logic.COND_TYPE.PROGRESS then
      tierList[#tierList + 1] = tier
    end
  end
  local testState = self:GetTestState()
  if testState then
    progress = testState.progress
    for _, tier in ipairs(tierList) do
      local threshold = tier.cond_param or 0
      tier.done = progress >= threshold
      tier.status = tier.done and ActivityProgressStatus.Get or ActivityProgressStatus.Not
    end
  end
  if self.ProgressScroll then
    self.ProgressScroll:SetData(tierList)
    for i = 1, #tierList do
      self.ProgressScroll:RefreshItem(i)
    end
  end
  if self.UIRoot.WoW_VehicleSales_Progress_Item_UIBP.ProgressBar_0 then
    self.UIRoot.WoW_VehicleSales_Progress_Item_UIBP.ProgressBar_0:SetPercent(self:GetProgressPercent(tierList, progress, logic))
  end
end

function VehicleSales_Main_UIBP:OnRefreshProgressNode(widget, index)
  local tier = self.ProgressScroll and self.ProgressScroll:GetItemData(index)
  if not tier then
    return
  end
  local logic_vehicle_sales_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_vehicle_sales_data)
  self:UpdateProgressNode(widget, tier, logic_vehicle_sales_data)
end

function VehicleSales_Main_UIBP:GetProgressPercent(tierList, progress, logic)
  if not tierList or #tierList == 0 then
    return 0
  end
  progress = progress or 0
  local firstThreshold = tierList[1].cond_param or 0
  local lastThreshold = tierList[#tierList].cond_param or 0
  if firstThreshold >= lastThreshold then
    return 0
  end
  return math.min(math.max((progress - firstThreshold) / (lastThreshold - firstThreshold), 0), 1)
end

function VehicleSales_Main_UIBP:UpdateProgressNode(node, tier, logic)
  local stateIdx = 0
  if tier.status == ActivityProgressStatus.Done then
    stateIdx = 1
  elseif tier.status == ActivityProgressStatus.Get then
    stateIdx = 2
  end
  if node.WidgetSwitcherExt_Node then
    node.WidgetSwitcherExt_Node:SetActiveWidgetIndex(stateIdx)
  end
  if node.WidgetSwitcherExt_Currency then
    node.WidgetSwitcherExt_Currency:SetActiveWidgetIndex(0)
  end
  local basePrice = self._progressBasePrice or logic:GetBasePrice(self.act_id)
  local loginDiscount = 100
  for _, t in ipairs(logic:GetTierList(self.act_id)) do
    if t.cond_type == logic.COND_TYPE.LOGIN and t.discount and loginDiscount > t.discount then
      loginDiscount = t.discount
    end
  end
  local discountPrice = 0 < basePrice and math.floor(basePrice * loginDiscount / 100 * (tier.discount or 100) / 100 + 0.5) or 0
  if node.TextBlock_ActivityPoints then
    node.TextBlock_ActivityPoints:SetText(tostring(tier.cond_param or 0))
  end
  if node.TextBlock_UC then
    node.TextBlock_UC:SetText(tostring(discountPrice))
  end
end

function VehicleSales_Main_UIBP:UpdateRefundEntry(product)
  local refund_info = product.refund_info
  local bShowReddot = refund_info ~= nil and 0 < (refund_info.refundable or 0)
  if self.UIRoot.Reddot_Anchor then
    self.UIRoot.Reddot_Anchor:ShowRedPointByPath("/Game/UMG/UI_Logic/Reddot/Reddot_Anchor_Item03.Reddot_Anchor_Item03")
    self:SetWidgetVisible(self.UIRoot.Reddot_Anchor, bShowReddot)
  end
end

function VehicleSales_Main_UIBP:UpdateButtonState(bEnable, bNoProduct)
  local logic_vehicle_sales_data = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_vehicle_sales_data)
  local bBought = logic_vehicle_sales_data and logic_vehicle_sales_data:IsBought(self.act_id) or false
  local bSportsCarUnlocked = logic_vehicle_sales_data and self:IsSportsCarUnlocked(logic_vehicle_sales_data) or false
  local nState = 1
  if bBought then
    nState = 2
  elseif self._discountType == 1 and not bSportsCarUnlocked then
    nState = 0
  else
    nState = 1
  end
  if self.UIRoot.WidgetSwitcherExt_Buy then
    self.UIRoot.WidgetSwitcherExt_Buy:SetActiveWidgetIndex(nState)
  end
  local bCanBuy = bEnable and not bBought and not bNoProduct and (self._discountType ~= 1 or not not bSportsCarUnlocked)
  if self.UIRoot.Button_Buy then
    self:SetButtonEnable(self.UIRoot.Button_Buy, bCanBuy)
  end
  if self.UIRoot.Button_GoObtain then
    self:SetWidgetVisible(self.UIRoot.Button_GoObtain, true)
  end
  if self.UIRoot.CanvasPanel_Tip then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Tip, not bBought)
  end
end

function VehicleSales_Main_UIBP:UpdateActDate()
  if not self.UIRoot.TextBlock_Date then
    return
  end
  local logic_activity_mgr = require("client.slua.logic.activity.logic_activity_mgr")
  local ActivityData = logic_activity_mgr.GetActivityByType(ActivityType.DiscountSale)
  if ActivityData and ActivityData.StartTime and ActivityData.EndTime then
    local TimeUtil = require("client.common.time_util")
    self.UIRoot.TextBlock_Date:SetText(TimeUtil.FormatTime_timeFrame(ActivityData.StartTime, ActivityData.EndTime))
  else
    self.UIRoot.TextBlock_Date:SetText("")
  end
end

function VehicleSales_Main_UIBP:UpdateActTime()
  if not self.UIRoot.TextBlock_Time then
    return
  end
  local logic_activity_mgr = require("client.slua.logic.activity.logic_activity_mgr")
  local ActivityData = logic_activity_mgr.GetActivityByType(ActivityType.DiscountSale)
  if not ActivityData or not ActivityData.EndTime then
    self.UIRoot.TextBlock_Time:SetText("")
    return
  end
  local TimeUtil = require("client.common.time_util")
  local nRemain = ActivityData.EndTime - TimeUtil.GetServerTimeInSec()
  if nRemain <= 0 then
    return
  end
  local nDays = math.floor(nRemain / 86400)
  local nHours = math.floor(math.fmod(nRemain, 86400) / 3600)
  self.UIRoot.TextBlock_Time:SetText(LocUtil.LocalizeResFormat(90068, nDays, nHours))
end

function VehicleSales_Main_UIBP:StartCountdownTimer()
  if self._nCountdownTimer then
    return
  end
  self._nCountdownTimer = self:AddTimerLoop(60, function()
    self:UpdateActTime()
  end, TIMER_INFINITE, 1)
end

function VehicleSales_Main_UIBP:UpdateSystemInfo(logic)
  self:SetWidgetVisible(self.UIRoot.UTRichTextBlock_Title, false)
  if self.UIRoot.UTRichTextBlock_SubTitle then
    self.UIRoot.UTRichTextBlock_SubTitle:SetText(LocUtil.LocalizeResFormat(90067))
  end
end

function VehicleSales_Main_UIBP:GetSystemTitle(logic)
  local data = logic and logic:GetActivityData(self.act_id)
  local cfg = data and data.cfg
  return cfg and cfg.activity_name or ""
end

function VehicleSales_Main_UIBP:GetSystemSubTitle(logic)
  local data = logic and logic:GetActivityData(self.act_id)
  local cfg = data and data.cfg
  return cfg and cfg.activity_desc or ""
end

function VehicleSales_Main_UIBP:UpdateCurrency(logic)
  if self.UIRoot.TextBlock_0 then
    self.UIRoot.TextBlock_0:SetText(tostring(self:GetActivityPoints(logic)))
  end
  if self.UIRoot.TextBlock_1 then
    self.UIRoot.TextBlock_1:SetText(tostring(self:GetActivityPoints(logic)))
  end
  self:UpdateUC()
end

function VehicleSales_Main_UIBP:UpdateUC()
  if self.UIRoot.TextBlock_UC then
    self.UIRoot.TextBlock_UC:SetText(FuncUtil.Conv_Int64ToText(DataMgr.ticket))
  end
end

function VehicleSales_Main_UIBP:OnTicketChange()
  self:UpdateUC()
end

function VehicleSales_Main_UIBP:GetActivityPoints(logic)
  local shopInfo = logic and logic:GetShopInfo(self.act_id)
  local product = shopInfo and shopInfo.product
  local price_info = product and product.price_info
  return price_info and price_info.progress or 0
end

function VehicleSales_Main_UIBP:UpdateWowSpecialDiscount(logic)
  local shopInfo = logic:GetShopInfo(self.act_id)
  local bOpen = shopInfo ~= nil and shopInfo.product ~= nil
  if self.UIRoot.CanvasPanel_WOWContent then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_WOWContent, bOpen)
  end
  if not bOpen then
    return
  end
  self:SetWowBadgePrice(logic:CalculatePrice(self.act_id))
end

function VehicleSales_Main_UIBP:SetWowBadgePrice(price)
  local widget = self.UIRoot.UTRichTextBlock
  if widget and widget.SetText then
    widget:SetText(string.format("WOW%dUC", price or 0))
  end
end

function VehicleSales_Main_UIBP:SetButtonEnable(button, bEnable)
  if not button then
    return false
  end
  if button.SetIsEnabled then
    button:SetIsEnabled(bEnable)
  end
  return bEnable
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
return class(ui_base, nil, VehicleSales_Main_UIBP)
