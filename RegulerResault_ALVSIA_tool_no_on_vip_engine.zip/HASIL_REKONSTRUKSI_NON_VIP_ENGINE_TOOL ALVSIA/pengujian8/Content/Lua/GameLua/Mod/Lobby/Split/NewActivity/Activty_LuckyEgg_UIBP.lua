local Activty_LuckyEgg_UIBP = {}

function Activty_LuckyEgg_UIBP:ctor()
end

function Activty_LuckyEgg_UIBP:OnInitialize()
  self.UIRoot.Text_Title:SetText(LocUtil.GetLocalizeResStr(818359))
  self.UIRoot.Text_Condition:SetText(LocUtil.GetLocalizeResStr(818360))
  self.UIRoot.Btn_Claim:SetBtnText(LocUtil.GetLocalizeResStr(818361))
end

function Activty_LuckyEgg_UIBP:RegistEvents()
  self.UIRoot.Btn_Claim:SetBtnClick(self.OnClickBtn_Claim, self)
end

function Activty_LuckyEgg_UIBP:OnPostInitialize()
  self:UpdateUI()
end

function Activty_LuckyEgg_UIBP:OnClose()
end

function Activty_LuckyEgg_UIBP:OnClickBtn_Claim()
  self:PlayAudio(sound_config.click_v1)
  local active_exchange_config = require("client.slua.logic.lobby_activity.active_exchange.active_exchange_config")
  local logic_active_exchange_entry = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_active_exchange_entry)
  logic_active_exchange_entry:OpenActiveExchangeMainUI(active_exchange_config.E_JumpSource.ActivityBanner)
end

function Activty_LuckyEgg_UIBP:UpdateUI()
  log(bWriteLog and "Activty_LuckyEgg_UIBP:UpdateUI")
  self:UpdateSeasonTimeShow()
  self:UpdateMainUI()
end

function Activty_LuckyEgg_UIBP:UpdateSeasonTimeShow()
  local logic_flash_team_season = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_flash_team_season)
  local seasonStr = logic_flash_team_season:GetSeasonTimeStr()
  if seasonStr ~= "" then
    self:SetWidgetVisible(self.UIRoot.Box_SeasonDuration, true)
    self.UIRoot.TextBlock_TimePeriod:SetText(LocUtil.LocalizeResFormat(817231, seasonStr))
  else
    self:SetWidgetVisible(self.UIRoot.Box_SeasonDuration, false)
  end
end

function Activty_LuckyEgg_UIBP:UpdateMainUI()
  local logic_active_exchange_gift_record = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_active_exchange_gift_record)
  local cfg = logic_active_exchange_gift_record:GetMainUIConfig()
  if not cfg then
    log_format(bWriteLog and "Activty_LuckyEgg_UIBP:UpdateMainUI cfg is nil")
    return
  end
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local actData = ActivityNewSystem.GetActivityByID(cfg.ActivityID)
  if not actData then
    log_format(bWriteLog and "Activty_LuckyEgg_UIBP:UpdateMainUI actData is nil")
    return
  end
  if self.UIRoot.Image_Bg then
    self:SetTexture(self.UIRoot.Image_Bg, actData.ImgUrl)
  end
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
return class(ui_base, nil, Activty_LuckyEgg_UIBP)
