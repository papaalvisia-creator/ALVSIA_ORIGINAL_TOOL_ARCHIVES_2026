local BlackFriday_Main_TItem_UIBP = {}
local TimeUtil = require("client.common.time_util")
local UIUtil = require("client.common.ui_util")
local Macro = require("GameLua.Mod.Lobby.Base.BlackFriday.Logic.BlackFridayMacros")

local function CheckActIsOpen(data)
  if TimeUtil.UnixTimeBetween(data.start_time, data.end_time) ~= 0 then
    return false
  end
  local BlackFridayMainModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayMainModule)
  if not BlackFridayMainModule:HasActivityData(tonumber(data.type)) then
    return false
  end
  return true
end

local function GetActBeginCountDownStr(start_time)
  local timeDis = start_time - TimeUtil.GetServerTimeInSec()
  local timeStr = ""
  if timeDis > Macro.UNIX_DAY * 3 then
    timeStr = TimeUtil.FormatTime_MD(start_time)
  else
    timeStr = TimeUtil.FormatCountDownTime_D_or_HMS(timeDis, 1)
  end
  return LocUtil.LocalizeResFormat(6072, timeStr)
end

local function IsInActBeginCountDown(configData)
  return TimeUtil.GetServerTimeInSec() < configData.start_time
end

local function GetActEndCountDownStr(endTime)
  local timeDis = endTime - TimeUtil.GetServerTimeInSec()
  local timeStr = ""
  if timeDis <= 60 then
    timeStr = TimeUtil.FormatCountDownTime_MS(timeDis, 1)
  else
    timeStr = TimeUtil.FormatCountDownTime_D_or_HM(timeDis, 1)
  end
  return timeStr
end

function BlackFriday_Main_TItem_UIBP:RegistEvents()
  self:AddOnClickedEventByControl(self.UIRoot.Button_Item, self.OnClickedTabItem, self)
end

function BlackFriday_Main_TItem_UIBP:OnClickedTabItem()
  log(bWriteLog and string.format("BlackFriday_Main_UIBP:OnClickedTabItem. index=%s", tostring(self.index)))
  self:PlayAudio(sound_config.click_v1)
  if not UIUtil.CanClickNow(UIUtil.ClickFrequencyLimit.ActivityTab) then
    return
  end
  local LoopScrollBox = self:GetLoopScrollBox()
  local selectedIndex = LoopScrollBox:GetSelectIndex()
  if selectedIndex == self.index then
    return
  end
  local configData = self.data
  if TimeUtil.UnixTimeBetween(configData.start_time, configData.end_time) ~= 0 then
    ShowNotice(9940015)
    return
  end
  local BlackFridayMainModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayMainModule)
  if not BlackFridayMainModule:HasActivityData(tonumber(configData.type)) then
    ShowNotice(7724)
    return
  end
  LoopScrollBox:Select(self.index)
  local ParentUI = self:GetLoopScrollBoxParentUI()
  ParentUI:RefreshActContent(configData)
  ParentUI:RefreshCurrency(configData)
  ParentUI:TLogReportActShow()
end

function BlackFriday_Main_TItem_UIBP:OnRedDotTypeChanged(oldValue, newValue)
  local show = newValue ~= Macro.RedDotType.None
  self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_1, show)
  if show then
    self.UIRoot.WidgetSwitcher_1:SetActiveWidgetIndex(newValue)
  end
end

function BlackFriday_Main_TItem_UIBP:OnRefresh(data, selectIndex)
  local configData = data
  local widget = self.UIRoot
  local timeContainer = widget.TextBlock_Time:GetParent():GetParent()
  local betweenFlag = TimeUtil.UnixTimeBetween(configData.start_time, configData.end_time)
  local isInTime = betweenFlag == 0
  local actIsOpen = CheckActIsOpen(configData)
  local isNearEnding = configData.end_time - TimeUtil.GetServerTimeInSec() <= Macro.UNIX_DAY * 3
  local isActivityAvailable = isInTime and actIsOpen
  self:SetWidgetVisible(timeContainer, isActivityAvailable and isNearEnding)
  self:SetWidgetVisible(widget.Image_Mask, not isActivityAvailable)
  self:SetWidgetVisible(widget.Image_Lock, not isActivityAvailable)
  self:SetWidgetVisible(widget.Image_Day, false)
  self:RemoveCountDownTimer()
  if isActivityAvailable and not isNearEnding then
    self:_SetNormalActivityTime(widget, configData)
  elseif isActivityAvailable and isNearEnding then
    self:_SetEndingCountDown(widget, configData)
  elseif isInTime and not actIsOpen then
    widget.TextBlock_Time:SetText(LocUtil.GetLocalizeResStr(117078))
  elseif not isInTime then
    self:_SetBeginCountDown(widget, configData)
  end
  widget.TextBlock_Name:SetText(LocUtil.GetLocalizeResStr(configData.title_id))
  self:SetWidgetVisible(widget.Common_selected_UIBP, self.index == selectIndex)
  self:SetTexture(widget.Image_banner, configData.imageLink)
  self:RemoveAllDataListener()
  local BlackFridayRedDotModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayRedDotModule)
  local RedDot = BlackFridayRedDotModule:GetActRedDot(configData.type)
  self:SetWidgetVisible(widget.WidgetSwitcher_1, false)
  if RedDot then
    self:AddDataListener(RedDot, "redDotType", self.OnRedDotTypeChanged, self)
  end
end

function BlackFriday_Main_TItem_UIBP:_SetNormalActivityTime(widget, configData)
  local timeStr = TimeUtil.FormatTime_timeFrame(configData.start_time, configData.end_time, false, false, TimeUtil.FormatTime_MD)
  widget.TextBlock_Time:SetText(timeStr)
end

function BlackFriday_Main_TItem_UIBP:_SetEndingCountDown(widget, configData)
  self:SetWidgetVisible(widget.Image_Day, true)
  self.CountDownTimer = self:AddTimerLoop(0, function()
    if configData.end_time - TimeUtil.GetServerTimeInSec() <= Macro.UNIX_DAY * 3 then
      local timeStr = GetActEndCountDownStr(configData.end_time)
      widget.TextBlock_Time:SetText(timeStr)
    else
      self:RemoveCountDownTimer()
      local ParentUI = self:GetLoopScrollBoxParentUI()
      ParentUI:RefreshTabs()
    end
  end, TIMER_INFINITE, 1)
end

function BlackFriday_Main_TItem_UIBP:_SetBeginCountDown(widget, configData)
  self.CountDownTimer = self:AddTimerLoop(0, function()
    if IsInActBeginCountDown(configData) then
      local timeStr = GetActBeginCountDownStr(configData.start_time)
      widget.TextBlock_Time:SetText(timeStr)
    else
      self:RemoveCountDownTimer()
      local ParentUI = self:GetLoopScrollBoxParentUI()
      ParentUI:RefreshTabs()
    end
  end, TIMER_INFINITE, 1)
end

function BlackFriday_Main_TItem_UIBP:RemoveCountDownTimer()
  if self.CountDownTimer then
    self:RemoveTimer(self.CountDownTimer)
    self.CountDownTimer = nil
  end
end

local class = require("class")
local UIBase = require("client.slua_ui_framework.component.scroll_box_child_base")
local CBlackFriday_Main_TItem_UIBP = class(UIBase, nil, BlackFriday_Main_TItem_UIBP)
return CBlackFriday_Main_TItem_UIBP
