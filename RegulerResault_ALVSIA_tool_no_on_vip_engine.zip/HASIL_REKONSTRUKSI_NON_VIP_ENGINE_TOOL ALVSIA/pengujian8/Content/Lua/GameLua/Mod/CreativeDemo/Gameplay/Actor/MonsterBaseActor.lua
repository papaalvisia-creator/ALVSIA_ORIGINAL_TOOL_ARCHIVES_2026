;({
  MulticastRPC = {},
  LuaEventContainer = {
    ((function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(50, 143, 10, 101, 113, 103, 16, 60, 151, 78, 14, 14, 56, 142, 239, 96, 233))
  },
  ["ctor"] = function(_ARG_0_)
    do
      _ARG_0_.nOwnerPlayerKey = 0
      _ARG_0_.OwnerCharacter = nil
      _ARG_0_.OwnerPlayerName = _ENV()
      _ARG_0_.RebirthCount = 0
      _ARG_0_.RebirthLevel = 0
      _ARG_0_.SlotCount = 0
      _ARG_0_.RebirthSlotCount = 0
      _ARG_0_.AdditionSlotCount = 0
      _ARG_0_.PendingAdditionSlotCount = 0
      _ARG_0_.DoorLockDuration = 60
      _ARG_0_.BaseLevel = 1
      _ARG_0_.MoneyReturnRatio = 1.0
      _ARG_0_.StartBudget = 1000
      _ARG_0_.SkinID = U1.BaseParams.CurUseSkin
      _ARG_0_.MeshLoadRequestId = 0
      _ARG_0_.PendingMeshAssetPath = _ENV()
      _ARG_0_.MeshLoadHandleId = nil
      _ARG_0_.OverlapList = {}
      _ARG_0_.LastStealAlertTime = 0
      _ARG_0_.LastIntruderAlertTime = 0
      _ARG_0_.InfraredAlarmIntruders = {}
      _ARG_0_.InfraredAlarmBuffState = 0
      _ARG_0_.InfraredAlarmServerWatchdog = nil
      _ARG_0_.InfraredAlarmFXComp = nil
      _ARG_0_.uInfraredAlarmFX_Steady = nil
      _ARG_0_.uInfraredAlarmFX_Blink = nil
      _ARG_0_.InfraredAlarmFXLoadHandle = nil
      _ARG_0_.GreenPassPlayerKeys = U2.slua.Array(U2.UEnums.EPropertyClass.Int64)
      _ARG_0_.tVisitExpireTimers = {}
      _ARG_0_.MonsterSlots = {}
      _ARG_0_.NetMonsterIdArray = U2.slua.Array(U2.UEnums.EPropertyClass.Struct, U2.import((_ENV(43, 132, 58, 125, 113, 97, 97, 23))))
      _ARG_0_.NetMonsterStarArray = U2.slua.Array(U2.UEnums.EPropertyClass.Struct, U2.import((_ENV(43, 132, 58, 125, 113, 97, 97, 23))))
      _ARG_0_.BoxCollisionSteal = nil
      _ARG_0_.BoxCollisionLock = nil
      _ARG_0_.BoxCollisionLock2 = nil
      _ARG_0_.BoxCollisionDoor = nil
      _ARG_0_.BoxCollisionDoor2 = nil
      _ARG_0_.BoxCollisionSecondFloor = nil
      _ARG_0_.bClientLocalPlayerOnSecondFloor = false
      _ARG_0_.Widget = nil
      _ARG_0_.DoorActor1 = nil
      _ARG_0_.DoorActor2 = nil
      _ARG_0_.DoorsState = U3.Invalid
      _ARG_0_.nUnlockTime = 0
      _ARG_0_.nLastForceUnlockServerTime = 0
      _ARG_0_.nInitialProtectUntilTime = 0
      _ARG_0_.CoinProductionTimer = nil
      _ARG_0_.UnlockCountdownTimer = nil
      _ARG_0_.ClientRemainingTime = 0
      _ARG_0_.BaseScreenMarkID = nil
      _ARG_0_.SlotCoinStates = U2.slua.Array(U2.UEnums.EPropertyClass.Int)
      _ARG_0_.SlotCollectVersions = U2.slua.Array(U2.UEnums.EPropertyClass.Int)
      _ARG_0_.CoinSlotMgr = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLifetimeReplicatedProps"] = function(_ARG_0_)
    do
      do return {
        {
          U1(19, 174, 46, 103, 123, 97, 3, 63, 159, 89, 40, 20, 18, 133, 241),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Int64
        },
        {
          U1(50, 150, 55, 108, 108, 67, 63, 50, 135, 69, 63, 40, 56, 141, 237),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Str
        },
        {
          U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 85, 35, 18),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Int
        },
        {
          U1(46, 141, 54, 125, 93, 124, 38, 61, 138),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Int
        },
        {
          U1(63, 128, 42, 108, 82, 118, 37, 54, 146),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Int
        },
        {
          U1(46, 138, 48, 103, 87, 87),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Int
        },
        {
          U1(57, 142, 54, 123, 109, 64, 39, 50, 138, 69),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Int
        },
        {
          U1(57, 142, 54, 123, 95, 112, 39, 60, 140, 17),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Object
        },
        {
          U1(57, 142, 54, 123, 95, 112, 39, 60, 140, 18),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Object
        },
        {
          U1(19, 180, 55, 101, 113, 112, 56, 7, 151, 77, 40),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Float
        },
        {
          U1(51, 132, 45, 68, 113, 125, 32, 39, 155, 82, 4, 2, 24, 146, 250, 100, 244),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Array,
          import((U1(43, 132, 58, 125, 113, 97, 97, 23)))
        },
        {
          U1(51, 132, 45, 68, 113, 125, 32, 39, 155, 82, 30, 18, 56, 146, 201, 119, 255, 176, 80),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Array,
          import((U1(43, 132, 58, 125, 113, 97, 97, 23)))
        },
        {
          U1(58, 147, 60, 108, 112, 67, 50, 32, 141, 112, 33, 7, 32, 133, 250, 78, 232, 168, 90),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Array,
          UEnums.EPropertyClass.Int64
        },
        {
          U1(52, 143, 63, 123, 127, 97, 54, 55, 191, 76, 44, 20, 52, 162, 253, 99, 235, 130, 93, 88, 154, 70),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Int
        },
        {
          U1(46, 141, 54, 125, 93, 124, 58, 61, 173, 84, 44, 18, 60, 147),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Array,
          UEnums.EPropertyClass.Int
        },
        {
          U1(46, 141, 54, 125, 93, 124, 63, 63, 155, 67, 57, 48, 60, 146, 251, 108, 226, 191, 90),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Array,
          UEnums.EPropertyClass.Int
        },
        {
          U1(47, 132, 59, 96, 108, 103, 59, 31, 155, 86, 40, 10),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Int
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveBeginPlay"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 15, 19, 42, 149, 241, 99, 248, 131, 92, 78, 151, 93, 99, 31),
        U1(28, 152)
      }))
      U2.__super.ReceiveBeginPlay(_ARG_0_)
      _ARG_0_:InitComponents()
      _ARG_0_.CoinSlotMgr = U3.New(_ARG_0_.Object)
      _ARG_0_.CoinSlotMgr:OnBeginPlay()
      _ARG_0_:CreateDoors()
      _ARG_0_:ResetToEmptyBase()
      if not Client then
        _ARG_0_:BindCollisionEvents()
        _ARG_0_:StartCoinProductionTimer()
        _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_AI_STARTGAME_AISERVER_SUCCESS, _ARG_0_.UpdateAllAIPerceptionInfo, _ARG_0_)
      else
        _ARG_0_:ClientBindCollisionEvents()
        _ARG_0_:UpdateBuildingMesh()
        _ARG_0_:UpdateBaseOwnerInfoUI()
        _ARG_0_:UpdateLockAreaUI()
        _ARG_0_:UpdateStealAreaUI()
        _ARG_0_:UpdateBaseTitleWidgetCullDistance()
        _ARG_0_:_ApplyClientParticleFXCullDistance()
        _ARG_0_:UpdateBaseScreenMark()
        if _ARG_0_.nOwnerPlayerKey and _ARG_0_.nOwnerPlayerKey > 0 then
          _ARG_0_:ClientControlGreenPass(_ARG_0_.DoorActor1)
          _ARG_0_:ClientControlGreenPass(_ARG_0_.DoorActor2)
        end
        if _ARG_0_.DoorsState == U4.Locked and _ARG_0_.nUnlockTime and 0 < _ARG_0_.nUnlockTime then
          _ARG_0_.ClientRemainingTime = _ARG_0_:_ClientCalcRemainingTime()
          print(bWriteLog and string.format(table.concat({
            U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 15, 19, 42, 149, 241, 99, 248, 131, 92, 78, 151, 93, 99, 31),
            U1(28, 152, 121, 36, 62, 87, 60, 60, 140, 0, 44, 10, 43, 133, 233, 97, 244, 241, 69, 86, 141, 72, 70, 7, 206, 95, 51, 86, 35, 159, 241, 123, 177, 225, 74, 93, 159, 65, 71, 26),
            U1(19, 134, 121, 106, 113, 102, 61, 39, 154, 79, 58, 8, 121, 134, 250, 106, 224, 241, 12, 23, 220, 69)
          }), _ARG_0_.ClientRemainingTime))
          _ARG_0_:StartUnlockCountdownTimer()
        elseif _ARG_0_.DoorsState == U4.Locked then
          _ARG_0_.ClientRemainingTime = 0
          _ARG_0_:UpdateUnlockTimeUI()
        else
        end
        _ARG_0_:UpdateSlotVisibility()
        _ARG_0_:ClientBindSecondFloorCollision()
        _ARG_0_:SetSecondFloorSlotsVisible(false)
        _ARG_0_:UpdateSecondFloor()
      end
      _ARG_0_:UpdateStairsCoverCollision()
      _ARG_0_:RefreshMonsterGalleryUnlockState()
      if Client then
        _ARG_0_:_StartGalleryUnlockRetryTimer()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetRebirthLevel"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      _ARG_1_ = tonumber(_ARG_1_) or 0
      if _ARG_1_ < 0 then
        _ARG_1_ = 0
      end
      if (_ARG_0_.RebirthLevel or 0) == _ARG_1_ then
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 19, 61, 162, 253, 119, 244, 179, 77, 65, 178, 86, 69, 22),
          U1(17, 193, 116, 41, 107, 125, 48, 59, 159, 78, 42, 3, 61, 187, 173, 97, 208, 253, 9, 74, 133, 74, 83)
        }), _ARG_1_))
        return
      end
      _ARG_0_.RebirthLevel = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_RebirthLevel"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 207, 164, 91, 64, 140, 71, 91, 63),
        U1(24, 151, 60, 101, 62, 62, 115, 29, 155, 87, 22, 67, 61, 189, 168, 74, 250, 191, 76, 75, 190, 79, 66, 26, 139, 66, 22, 19, 48, 171, 189, 113, 192)
      }), _ARG_0_.RebirthLevel or 0, _ARG_0_.nOwnerPlayerKey or 0))
      _ARG_0_:RefreshMonsterGalleryUnlockState()
      if Client and slua.isValid((slua_GameFrontendHUD:GetPlayerController())) and slua_GameFrontendHUD:GetPlayerController().PlayerKey and _ARG_0_.nOwnerPlayerKey and _ARG_0_.nOwnerPlayerKey == slua_GameFrontendHUD:GetPlayerController().PlayerKey and slua_GameFrontendHUD:GetPlayerController().PlayerRebirthFeature and slua_GameFrontendHUD:GetPlayerController().PlayerRebirthFeature.SetRebirthLevel and slua_GameFrontendHUD:GetPlayerController().PlayerRebirthFeature.GetRebirthLevel and (_ARG_0_.RebirthLevel or 0) > (slua_GameFrontendHUD:GetPlayerController().PlayerRebirthFeature:GetRebirthLevel() or 0) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SyncRebirthLevelFromFeature"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if type(_ARG_0_.nOwnerPlayerKey) ~= U1(19, 148, 52, 107, 123, 97) or _ARG_0_.nOwnerPlayerKey <= 0 then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 2, 37, 48, 158, 251, 71, 248, 163, 80, 91, 138, 91, 127, 22),
          U1(11, 132, 53, 79, 108, 124, 62, 21, 155, 65, 57, 19, 43, 133, 168, 40, 173, 191, 70, 25, 129, 84, 77, 6, 156, 16, 36, 19, 61, 220, 184, 102, 246, 168, 73)
        }))
        return
      end
      if not slua.isValid((require((U1(58, 128, 52, 108, 82, 102, 50, 125, 185, 65, 32, 3, 26, 143, 250, 96, 163, 149, 72, 77, 143, 13, 100, 2, 131, 85, 45, 26, 40, 137, 220, 116, 233, 160))).GetPlayerController(_ARG_0_.nOwnerPlayerKey))) or not require((U1(58, 128, 52, 108, 82, 102, 50, 125, 185, 65, 32, 3, 26, 143, 250, 96, 163, 149, 72, 77, 143, 13, 100, 2, 131, 85, 45, 26, 40, 137, 220, 116, 233, 160))).GetPlayerController(_ARG_0_.nOwnerPlayerKey).PlayerRebirthFeature then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshMonsterGalleryUnlockState"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if (_ARG_0_.RebirthLevel or 0) >= ((require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 100, 145, 93, 64, 7),
        U1(24, 147, 26, 102, 112, 117, 58, 52)
      }))).MonsterGalleryUnlockLevelByIndex or {})[U1(24, 147, 26, 102, 112, 117, 58, 52)] or 0) then
        goto lbl_86
        goto lbl_87
        ::lbl_86::
        _ARG_0_ = _ARG_0_
      end
      ::lbl_87::
      if U1(24, 147, 26, 102, 112, 117, 58, 52) < 1 then
      end
      if (require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 100, 145, 93, 64, 7),
        U1(24, 147, 26, 102, 112, 117, 58, 52)
      }))).MonsterGalleryMaxUnlockCount or 4) < 1 then
      end
      _ARG_0_ = _ARG_0_
      if ({
        U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153),
        U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 186),
        U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 187),
        (U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 188))
      })[48] then
        if slua.isValid(_ARG_0_[({
          U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153),
          U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 186),
          U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 187),
          (U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 188))
        })[48]]) then
          if slua.isValid(_ARG_0_[({
            U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153),
            U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 186),
            U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 187),
            (U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 188))
          })[48]].ChildActor) then
            if (require((table.concat({
              U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 100, 145, 93, 64, 7),
              U1(24, 147, 26, 102, 112, 117, 58, 52)
            }))).MonsterGalleryMaxUnlockCount or 4) >= 48 and _ARG_0_[({
              U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153),
              U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 186),
              U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 187),
              (U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 188))
            })[48]].ChildActor._ApplyGalleryProductionRatio and 0 < (_ARG_0_[({
              U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153),
              U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 186),
              U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 187),
              (U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 188))
            })[48]].ChildActor.MonsterID or 0) then
            end
          else
          end
        else
        end
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_StartGalleryUnlockRetryTimer"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      _ARG_0_:_StopGalleryUnlockRetryTimer()
      _ARG_0_.GalleryUnlockRetryCount = 0
      _ARG_0_.GalleryUnlockRetryTimer = _ARG_0_:AddGameTimer(0.5, true, function()
        GalleryUnlockRetryCount = (GalleryUnlockRetryCount or 0) + 1
        if not U1.slua.isValid(Object) then
          _ENV:_StopGalleryUnlockRetryTimer()
          return
        end
        _ENV:RefreshMonsterGalleryUnlockState()
        if 0 < (RebirthLevel or 0) then
          return
        end
        if GalleryUnlockRetryCount >= U3 then
          return
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_StopGalleryUnlockRetryTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.GalleryUnlockRetryTimer then
        _ARG_0_:RemoveGameTimer(_ARG_0_.GalleryUnlockRetryTimer)
        _ARG_0_.GalleryUnlockRetryTimer = nil
      end
      _ARG_0_.GalleryUnlockRetryCount = 0
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddMonster"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return false
      end
      if not slua.isValid(_ARG_1_) then
        print(bWriteLog and string.format((table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 28, 18, 45, 189, 247, 123, 238, 181, 92, 91, 222, 30, 19, 26),
          U1(19, 151, 56, 101, 119, 119, 115, 38, 179, 79, 35, 21, 45, 133, 250, 68, 238, 165, 70, 75)
        }))))
        return false
      end
      if _ARG_2_ == nil then
      end
      if not true then
        if not _ARG_0_:IsValidSlotIndex(_ARG_2_) then
          return false
        end
        if not _ARG_0_.MonsterSlots[_ARG_2_] then
          return false
        end
        if slua.isValid(_ARG_0_.MonsterSlots[_ARG_2_].Monster) then
          return false
        end
        _ARG_0_.MonsterSlots[_ARG_2_].Monster = _ARG_1_
        return true, _ARG_2_
      else
        if not _ARG_0_:GetAvailableSlotIndex() then
          return false
        end
        _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Monster = _ARG_1_
        return true, (_ARG_0_:GetAvailableSlotIndex())
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1[108]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PlaceMonsterAtSlot"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) or not _ARG_2_ then
        return
      end
      _ARG_1_.SlotIndex = _ARG_2_.Index
      if not slua.isValid(_ARG_2_.Mesh) then
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 2, 38, 37, 145, 251, 112, 208, 174, 87, 90, 138, 86, 65, 50),
          U1(9, 178, 53, 102, 106, 51, 126, 115, 173, 76, 34, 18, 2, 197, 236, 88, 173, 188, 76, 74, 134, 3, 74, 13, 152, 81, 49, 31, 45)
        }), _ARG_2_.Index or 0))
        return
      end
      if not _ARG_2_.Mesh:K2_GetComponentToWorld() then
        return
      end
      if not _ARG_2_.Mesh:K2_GetComponentToWorld():GetLocation() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoveMonster"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return false
      end
      if _ARG_2_ ~= nil then
      end
      if _ARG_1_ < 1 or _ARG_1_ > _ARG_0_.SlotCount then
        return false
      end
      if not _ARG_0_.MonsterSlots[_ARG_1_] then
        return false
      end
      if not slua.isValid(_ARG_0_.MonsterSlots[_ARG_1_].Monster) then
        return false
      end
      if 0 > (tonumber(_ARG_0_.MonsterSlots[_ARG_1_].Monster.StarLevel) or 0) then
      end
      if _ARG_2_ then
      end
      _ARG_0_.MonsterSlots[_ARG_1_].Monster = nil
      do return true, _ARG_1_, 0 end
      do return end
      _ARG_0_ = U1[55]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateNetMonsterIdArray"] = function(_ARG_0_)
    do
      _ARG_0_.NetMonsterIdArray:Clear()
      _ARG_0_.NetMonsterStarArray:Clear()
      goto lbl_36
      ::lbl_36::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 211, 164, 77, 100, 145, 93, 64, 7),
        U1(24, 147, 16, 109, 95, 97, 33, 50, 135, 0, 3, 19, 52, 187, 173, 97, 208)
      }), _ARG_0_.NetMonsterIdArray:Num()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HasMonster"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        goto lbl_20
        if slua.isValid((nil).Monster) and (nil).Monster.MonsterID == _ARG_1_ then
          return true
        end
        ::lbl_20::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        return false
      else
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 21, 23, 58, 189, 247, 123, 238, 181, 92, 91, 222, 30, 19, 29),
          U1(48, 142, 55, 122, 106, 118, 33, 26, 186, 123, 104, 2, 4, 192, 198, 96, 249, 156, 70, 87, 157, 87, 70, 17, 167, 84, 28, 4, 59, 145, 225, 78, 184, 165, 100)
        }), _ARG_1_, _ARG_0_.NetMonsterIdArray:Num()))
        goto lbl_217
        if math.floor(_ARG_0_.NetMonsterIdArray:Num().Y) == _ARG_1_ then
          return true
        end
        ::lbl_217::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_SkinID"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 206, 170, 80, 71, 183, 119, 19, 0),
        U1(24, 141, 63, 39, 77, 120, 58, 61, 183, 100, 22, 67, 61, 189)
      }), _ARG_0_.SkinID))
      _ARG_0_:UpdateBuildingMesh()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_NetMonsterIdArray"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 211, 164, 77, 100, 145, 93, 64, 7),
        U1(24, 147, 16, 109, 95, 97, 33, 50, 135, 0, 3, 19, 52, 187, 173, 97, 208)
      }), _ARG_0_.NetMonsterIdArray:Num()))
      if _ARG_0_.CoinSlotMgr then
        _ARG_0_.CoinSlotMgr:OnRep_NetMonsterIdArray()
      end
      EventSystem:postEvent(EVENTTYPE_PLANBT_NORMAL, EVENTID_MONSTER_BASE_NET_MONSTER_ID_ARRAY_CHANGED)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_NetMonsterStarArray"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 211, 164, 77, 100, 145, 93, 64, 7),
        U1(24, 147, 10, 125, 127, 97, 18, 33, 140, 65, 52, 70, 23, 149, 229, 94, 168, 181, 116)
      }), _ARG_0_.NetMonsterStarArray:Num()))
      if _ARG_0_.CoinSlotMgr then
        _ARG_0_.CoinSlotMgr:OnRep_NetMonsterIdArray()
      end
      EventSystem:postEvent(EVENTTYPE_PLANBT_NORMAL, EVENTID_MONSTER_BASE_NET_MONSTER_ID_ARRAY_CHANGED)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_RebirthCount"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 207, 164, 91, 64, 140, 71, 91, 48),
        U1(18, 148, 55, 125, 62, 62, 115, 28, 146, 68, 27, 7, 53, 149, 237, 94, 168, 162, 116, 21, 206, 109, 70, 20, 184, 81, 49, 3, 44, 171, 189, 113, 192)
      }), tostring(_ARG_1_), _ARG_0_.RebirthCount))
      if not CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.RebirthCount) then
        return
      end
      if _ARG_0_.BaseLevel ~= CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.RebirthCount).BasementLevel then
        _ARG_0_.BaseLevel = CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.RebirthCount).BasementLevel
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_nOwnerPlayerKey"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      if slua.isValid((U1.GetPlayerCharacter())) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientControlGreenPass"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        print(bWriteLog and string.format((table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 26, 32, 149, 246, 97, 222, 174, 87, 93, 140, 92, 95, 52),
          U1(15, 132, 60, 103, 78, 114, 32, 32, 222, 13, 109, 15, 55, 150, 233, 105, 228, 181, 9, 76, 170, 76, 76, 17, 175, 83, 41, 25, 59)
        }))))
        return
      end
      if not _ARG_1_.AddOrDeleteGreenPass then
        print(bWriteLog and string.format((table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 26, 32, 149, 246, 97, 222, 174, 87, 93, 140, 92, 95, 52),
          U1(15, 132, 60, 103, 78, 114, 32, 32, 222, 13, 109, 15, 55, 150, 233, 105, 228, 181, 9, 76, 170, 76, 76, 17, 175, 83, 41, 25, 59, 222, 217, 113, 249, 142, 75, 109, 155, 95, 86, 7),
          U1(24, 166, 43, 108, 123, 125, 3, 50, 141, 83)
        }))))
        return
      end
      if _ARG_0_.nOwnerPlayerKey <= 0 then
        print(bWriteLog and string.format((table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 26, 32, 149, 246, 97, 222, 174, 87, 93, 140, 92, 95, 52),
          U1(15, 132, 60, 103, 78, 114, 32, 32, 222, 13, 109, 8, 54, 192, 231, 114, 227, 180, 91)
        }))))
        return
      end
      if slua.isValid((U2.GetPlayerCharacter())) then
        if U2.GetPlayerCharacter().PlayerKey == _ARG_0_.nOwnerPlayerKey or _ARG_0_:_IsPlayerInGreenPassList(U2.GetPlayerCharacter().PlayerKey) then
        else
        end
      else
      end
      if _ARG_0_.GreenPassPlayerKeys then
        _ARG_0_ = _ARG_0_
        if slua.isValid((U2.GetPlayerCharacter((_ARG_0_.GreenPassPlayerKeys:Get({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 26, 32, 149, 246, 97, 222, 174, 87, 93, 140, 92, 95, 52),
          U1(15, 132, 60, 103, 78, 114, 32, 32, 222, 13, 109, 19, 21, 143, 235, 100, 225, 146, 65, 88, 156, 66, 64, 23, 139, 66, 125, 24, 38, 132, 184, 103, 248, 160, 93, 80, 222, 74, 86, 7)
        }))))) and U2.GetPlayerCharacter((_ARG_0_.GreenPassPlayerKeys:Get({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 26, 32, 149, 246, 97, 222, 174, 87, 93, 140, 92, 95, 52),
          U1(15, 132, 60, 103, 78, 114, 32, 32, 222, 13, 109, 19, 21, 143, 235, 100, 225, 146, 65, 88, 156, 66, 64, 23, 139, 66, 125, 24, 38, 132, 184, 103, 248, 160, 93, 80, 222, 74, 86, 7)
        }))) ~= U2.GetPlayerCharacter() then
        else
        end
        _ARG_0_ = _ARG_0_
      end
      if slua.isValid((U2.GetPlayerCharacter(_ARG_0_.nOwnerPlayerKey))) and U2.GetPlayerCharacter(_ARG_0_.nOwnerPlayerKey) ~= U2.GetPlayerCharacter() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_GreenPassPlayerKeys"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 218, 179, 92, 76, 144, 99, 82, 0),
        U1(14, 177, 53, 104, 103, 118, 33, 24, 155, 89, 62, 70, 116, 192, 207, 119, 232, 180, 71, 105, 143, 80, 80, 67, 130, 89, 46, 2, 105, 133, 232, 113, 252, 181, 92, 77, 210, 19, 80, 28),
        U1(8, 143, 45, 52, 59, 119)
      }), _ARG_0_.GreenPassPlayerKeys and _ARG_0_.GreenPassPlayerKeys:Num() or 0))
      if _ARG_1_ then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      _ARG_0_:ClientControlGreenPass(_ARG_0_.DoorActor1)
      _ARG_0_:ClientControlGreenPass(_ARG_0_.DoorActor2)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_IsPlayerInGreenPassList"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.GreenPassPlayerKeys then
        return false
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_.GreenPassPlayerKeys:Get(nil) == _ARG_1_ then
        return true
      end
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddGreenPassPlayer"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      if not _ARG_1_ or _ARG_1_ <= 0 then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 28, 18, 45, 183, 234, 112, 248, 175, 105, 72, 141, 64, 99, 31),
          U1(28, 152, 60, 123, 62, 62, 115, 26, 144, 86, 44, 10, 48, 132, 168, 107, 219, 184, 90, 80, 154, 76, 81, 51, 130, 81, 36, 19, 59, 187, 253, 108)
        }))
        return
      end
      if _ARG_0_:_IsPlayerInGreenPassList(_ARG_1_) then
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 28, 18, 45, 183, 234, 112, 248, 175, 105, 72, 141, 64, 99, 31),
          U1(28, 152, 60, 123, 62, 62, 115, 3, 146, 65, 52, 3, 43, 187, 173, 97, 208, 241, 72, 85, 156, 70, 66, 7, 151, 16, 52, 24, 105, 183, 234, 112, 248, 175, 105, 72, 141, 64, 19, 31),
          U1(20, 146, 45)
        }), _ARG_1_))
        return
      end
      _ARG_0_.GreenPassPlayerKeys:Add(_ARG_1_)
      if slua.isValid(_ARG_2_) then
        if slua.isValid(_ARG_0_.DoorActor1) then
          _ARG_0_.DoorActor1:AddOrDeleteGreenPass(_ARG_2_, true)
        end
        if slua.isValid(_ARG_0_.DoorActor2) then
          _ARG_0_.DoorActor2:AddOrDeleteGreenPass(_ARG_2_, true)
        end
      end
      if _ARG_0_.tVisitExpireTimers and _ARG_0_.tVisitExpireTimers[_ARG_1_] then
        _ARG_0_.tVisitExpireTimers[_ARG_1_] = nil
      end
      if not _ARG_0_.tVisitExpireTimers then
        _ARG_0_.tVisitExpireTimers = {}
      end
      _ARG_0_.tVisitExpireTimers[_ARG_1_] = _ARG_0_:AddGameTimer(require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 127, 151, 64, 90, 7),
        U1(63, 128, 42, 108, 93, 124, 61, 53, 151, 71)
      }))).VisitDurationSeconds or 300, false, function()
        if not slua.isValid(U1.Object) then
          return
        end
        print(bWriteLog and string.format(table.concat({
          U2(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 28, 18, 45, 183, 234, 112, 248, 175, 105, 72, 141, 64, 99, 31),
          U2(28, 152, 60, 123, 62, 62, 115, 5, 151, 83, 36, 18, 121, 132, 253, 119, 236, 165, 64, 86, 128, 3, 70, 27, 158, 89, 47, 19, 45, 208, 254, 122, 239, 225, 105, 69, 159, 74, 86, 1),
          U2(38, 196, 61, 84, 50, 51, 50, 38, 138, 79, 109, 20, 60, 150, 231, 110, 228, 191, 78, 25, 169, 81, 70, 6, 128, 96, 60, 5, 58)
        }), U3))
        U1:RemoveGreenPassPlayer(U3)
        return
      end)
      return
    end
  end,
  ["RemoveGreenPassPlayer"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not _ARG_1_ or _ARG_1_ <= 0 then
        return
      end
      if _ARG_0_.tVisitExpireTimers and _ARG_0_.tVisitExpireTimers[_ARG_1_] then
        _ARG_0_:RemoveGameTimer(_ARG_0_.tVisitExpireTimers[_ARG_1_])
        _ARG_0_.tVisitExpireTimers[_ARG_1_] = nil
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_.GreenPassPlayerKeys:Get(nil) == _ARG_1_ then
      else
        _ARG_0_ = _ARG_0_
      end
      if not true then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoveAllGreenPassPlayers"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.tVisitExpireTimers then
        goto lbl_17
        if nil then
        end
        ::lbl_17::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _ARG_0_.tVisitExpireTimers = {}
      end
      if not _ARG_0_.GreenPassPlayerKeys or _ARG_0_.GreenPassPlayerKeys:Num() == 0 then
        return
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_BaseLevel"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 223, 160, 74, 76, 178, 86, 69, 22),
        U1(17, 193, 116, 41, 81, 127, 55, 5, 159, 76, 56, 3, 2, 197, 251, 88, 161, 241, 103, 92, 153, 117, 66, 15, 155, 85, 6, 83, 45, 173)
      }), tostring(_ARG_1_), _ARG_0_.BaseLevel or 0))
      if Client then
        _ARG_0_:UpdateBuildingMesh()
        _ARG_0_:UpdateSecondFloor()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_SlotCount"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 206, 173, 86, 93, 189, 92, 70, 29),
        U1(9, 193, 116, 41, 81, 127, 55, 5, 159, 76, 56, 3, 2, 197, 251, 88, 161, 241, 103, 92, 153, 117, 66, 15, 155, 85, 6, 83, 45, 173)
      }), tostring(_ARG_1_), _ARG_0_.SlotCount or 0))
      if Client then
        _ARG_0_:UpdateSlotVisibility()
        if _ARG_0_.CoinSlotMgr then
          _ARG_0_.CoinSlotMgr:OnSlotCountChanged()
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRebirth"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_0_.OwnerCharacter) then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 250, 124, 239, 181, 81, 9, 211, 19, 122, 29),
          U1(11, 128, 53, 96, 122, 51, 28, 36, 144, 69, 63, 37, 49, 129, 250, 100, 238, 165, 76, 75)
        }))
        return false
      end
      if _ARG_0_.OwnerCharacter:GetEnsure() then
      else
      end
      if not slua.isValid((_ARG_0_.OwnerCharacter:GetPlayerControllerSafety())) then
        return false
      end
      if not CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount) then
        return false
      end
      if not CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).RebirthLevel or type(CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).RebirthLevel) ~= U1(19, 148, 52, 107, 123, 97) or CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).RebirthLevel < 0 then
        return false
      end
      if not CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).BasementLevel or type(CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).BasementLevel) ~= U1(19, 148, 52, 107, 123, 97) or 0 >= CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).BasementLevel then
        return false
      end
      if not CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).MonsterSpace or type(CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).MonsterSpace) ~= U1(19, 148, 52, 107, 123, 97) or 0 >= CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).MonsterSpace then
        return false
      end
      if not CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).BaseLockTime or type(CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).BaseLockTime) ~= U1(19, 148, 52, 107, 123, 97) or 0 > CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).BaseLockTime then
        return false
      end
      if not CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).MoneyReturnRatio_f or type(CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).MoneyReturnRatio_f) ~= U1(19, 148, 52, 107, 123, 97) or 0 > CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).MoneyReturnRatio_f then
        return false
      end
      _ARG_0_.RebirthCount = CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).RebirthLevel
      goto lbl_984
      ::lbl_984::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.BaseLevel = CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).BasementLevel
      if _ARG_0_.BaseLevel >= 2 and 0 < _ARG_0_.PendingAdditionSlotCount then
        _ARG_0_.PendingAdditionSlotCount = 0
        if _ARG_0_.PendingAdditionSlotCount > _ARG_0_.AdditionSlotCount then
          _ARG_0_.AdditionSlotCount = _ARG_0_.PendingAdditionSlotCount
          _ARG_0_.SlotCount = _ARG_0_.RebirthSlotCount + _ARG_0_.AdditionSlotCount
        end
      end
      _ARG_0_.DoorLockDuration = CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).BaseLockTime
      _ARG_0_.MoneyReturnRatio = CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).MoneyReturnRatio_f
      _ARG_0_.StartBudget = tonumber(CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).StartBudget) or 0
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearMonsterSlot"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:RemoveMonster(_ARG_1_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearCoinSlot"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.CoinSlotMgr then
        _ARG_0_.CoinSlotMgr:ResetSlot(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearSlots"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ConditionalSetSlotCount"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if (tonumber(_ARG_1_) or 0) > _ARG_0_.RebirthSlotCount then
        _ARG_0_.RebirthSlotCount = tonumber(_ARG_1_) or 0
      end
      if 0 < (tonumber(_ARG_2_) or 0) then
        if 2 <= (_ARG_0_.BaseLevel or 1) then
          if (tonumber(_ARG_2_) or 0) > _ARG_0_.AdditionSlotCount then
            _ARG_0_.AdditionSlotCount = tonumber(_ARG_2_) or 0
          end
        elseif (tonumber(_ARG_2_) or 0) > _ARG_0_.PendingAdditionSlotCount then
          _ARG_0_.PendingAdditionSlotCount = tonumber(_ARG_2_) or 0
        end
      end
      _ARG_0_.SlotCount = _ARG_0_.RebirthSlotCount + _ARG_0_.AdditionSlotCount
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSlotCount"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 19, 61, 163, 244, 122, 233, 130, 86, 92, 144, 71, 19, 94),
        U1(93, 168, 55, 91, 123, 113, 58, 33, 138, 72, 22, 67, 42, 189, 168, 76, 227, 144, 77, 93, 135, 87, 74, 12, 128, 107, 120, 5, 20)
      }), tostring(_ARG_1_), tostring(_ARG_2_)))
      _ARG_0_.AdditionSlotCount, _ARG_0_.RebirthSlotCount = tonumber(_ARG_2_) or 0, tonumber(_ARG_1_) or 10, tonumber(_ARG_2_) or 0
      _ARG_0_.SlotCount = _ARG_0_.RebirthSlotCount + _ARG_0_.AdditionSlotCount
      do return end
      _ARG_2_ = U1[136]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateSlotVisibility"] = function(_ARG_0_)
    do
      if not _ARG_0_.BaseLevel or type(_ARG_0_.BaseLevel) ~= U1(19, 148, 52, 107, 123, 97) or _ARG_0_.BaseLevel <= 0 then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 206, 173, 86, 93, 168, 90, 64, 26),
        U1(31, 136, 53, 96, 106, 106, 115, 126, 222, 98, 44, 21, 60, 172, 237, 115, 232, 189, 114, 28, 138, 126, 15, 67, 184, 89, 46, 31, 43, 156, 253, 70, 241, 174, 77, 90, 165, 22, 87, 46)
      }), _ARG_0_.BaseLevel, _ARG_0_.SlotCount))
      _ARG_0_ = _ARG_0_
      if _ARG_0_.MonsterSlots[_ARG_0_.SlotCount] and _ARG_0_.MonsterSlots[_ARG_0_.SlotCount].Mesh and slua.isValid(_ARG_0_.MonsterSlots[_ARG_0_.SlotCount].Mesh) then
        if Client and not (_ARG_0_.SlotCount > _ARG_0_.SlotCount) and _ARG_0_.SlotCount >= (U2.SecondFloorSlotStartIndex or 11) and not _ARG_0_.bClientLocalPlayerOnSecondFloor then
        end
      end
      if _ARG_0_.CoinSlotMgr then
        if Client and not (_ARG_0_.SlotCount > _ARG_0_.SlotCount) and _ARG_0_.SlotCount >= (U2.SecondFloorSlotStartIndex or 11) and not _ARG_0_.bClientLocalPlayerOnSecondFloor then
        end
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetSlotCullDistanceByDeviceLevel"] = function(_ARG_0_)
    do
      do return GetCullDistance() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetInfraredAlarmFXCullDistanceByDeviceLevel"] = function(_ARG_0_)
    do
      if not Client then
        return nil
      end
      if not U1.InfraredAlarmFXCullDistanceByDeviceLevel then
        return nil
      end
      if not slua.isValid((import((U2(46, 181, 28, 113, 106, 97, 50, 20, 159, 77, 40, 47, 55, 147, 252, 100, 227, 178, 76))).GetInstance())) then
        return nil
      end
      if not (U1.InfraredAlarmFXCullDistanceByDeviceLevel[import((U2(46, 181, 28, 113, 106, 97, 50, 20, 159, 77, 40, 47, 55, 147, 252, 100, 227, 178, 76))).GetInstance():GetExactDeviceLevel() or 1] or U1.InfraredAlarmFXCullDistanceByDeviceLevel[1]) or (U1.InfraredAlarmFXCullDistanceByDeviceLevel[import((U2(46, 181, 28, 113, 106, 97, 50, 20, 159, 77, 40, 47, 55, 147, 252, 100, 227, 178, 76))).GetInstance():GetExactDeviceLevel() or 1] or U1.InfraredAlarmFXCullDistanceByDeviceLevel[1]) <= 0 then
        return nil
      end
      do return U1.InfraredAlarmFXCullDistanceByDeviceLevel[import((U2(46, 181, 28, 113, 106, 97, 50, 20, 159, 77, 40, 47, 55, 147, 252, 100, 227, 178, 76))).GetInstance():GetExactDeviceLevel() or 1] or U1.InfraredAlarmFXCullDistanceByDeviceLevel[1] end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetDoorFXCullDistanceByDeviceLevel"] = function(_ARG_0_)
    do
      if not Client then
        return nil
      end
      if not U1.DoorFXCullDistanceByDeviceLevel then
        return nil
      end
      if not slua.isValid((import((U2(46, 181, 28, 113, 106, 97, 50, 20, 159, 77, 40, 47, 55, 147, 252, 100, 227, 178, 76))).GetInstance())) then
        return nil
      end
      if not (U1.DoorFXCullDistanceByDeviceLevel[import((U2(46, 181, 28, 113, 106, 97, 50, 20, 159, 77, 40, 47, 55, 147, 252, 100, 227, 178, 76))).GetInstance():GetExactDeviceLevel() or 1] or U1.DoorFXCullDistanceByDeviceLevel[1]) or (U1.DoorFXCullDistanceByDeviceLevel[import((U2(46, 181, 28, 113, 106, 97, 50, 20, 159, 77, 40, 47, 55, 147, 252, 100, 227, 178, 76))).GetInstance():GetExactDeviceLevel() or 1] or U1.DoorFXCullDistanceByDeviceLevel[1]) <= 0 then
        return nil
      end
      do return U1.DoorFXCullDistanceByDeviceLevel[import((U2(46, 181, 28, 113, 106, 97, 50, 20, 159, 77, 40, 47, 55, 147, 252, 100, 227, 178, 76))).GetInstance():GetExactDeviceLevel() or 1] or U1.DoorFXCullDistanceByDeviceLevel[1] end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ApplyClientParticleFXCullDistance"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if _ARG_0_._bParticleFXCullApplied then
        return
      end
      _ARG_0_._bParticleFXCullApplied = true
      if _ARG_0_:_GetDoorFXCullDistanceByDeviceLevel() and _ARG_0_:_GetDoorFXCullDistanceByDeviceLevel() > 0 then
      end
      if slua.isValid(_ARG_0_.P_PlanBT_UgcBillboard_Lock_01_L3) then
        _ARG_0_.uLockBillboardFX = _ARG_0_.P_PlanBT_UgcBillboard_Lock_01_L3
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitComponents"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if _ARG_0_[string.format(U1(48, 132, 42, 97, 83, 124, 61, 32, 138, 69, 63, 53, 53, 143, 252, 32, 189, 227, 77), nil)] and slua.isValid(_ARG_0_[string.format(U1(48, 132, 42, 97, 83, 124, 61, 32, 138, 69, 63, 53, 53, 143, 252, 32, 189, 227, 77), nil)]) then
      end
      _ARG_0_.MonsterSlots[nil] = {
        Mesh = _ARG_0_[string.format(U1(48, 132, 42, 97, 83, 124, 61, 32, 138, 69, 63, 53, 53, 143, 252, 32, 189, 227, 77), nil)],
        Monster = nil,
        Index = nil
      }
      if _ARG_0_[string.format(U1(48, 132, 42, 97, 83, 124, 61, 32, 138, 69, 63, 53, 53, 143, 252, 32, 189, 227, 77), nil)] then
        if Client and _ARG_0_:_GetSlotCullDistanceByDeviceLevel() or nil then
        end
      else
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_.BoxCollisionSteal and slua.isValid(_ARG_0_.BoxCollisionSteal) then
      else
      end
      if _ARG_0_.BoxCollisionLock and slua.isValid(_ARG_0_.BoxCollisionLock) then
      else
      end
      if _ARG_0_.BoxCollisionLock2 and slua.isValid(_ARG_0_.BoxCollisionLock2) then
      else
      end
      if _ARG_0_.BoxCollisionDoor and slua.isValid(_ARG_0_.BoxCollisionDoor) then
      else
      end
      if _ARG_0_.BoxCollisionDoor2 and slua.isValid(_ARG_0_.BoxCollisionDoor2) then
      else
      end
      if _ARG_0_.BoxCollisionSecondFloor and slua.isValid(_ARG_0_.BoxCollisionSecondFloor) then
      else
      end
      if _ARG_0_.Widget and slua.isValid(_ARG_0_.Widget) then
      else
      end
      do return end
      _ARG_0_ = BoxCollisionLock2
    end
  end,
  ["BindCollisionEvents"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.BoxCollisionSteal and slua.isValid(_ARG_0_.BoxCollisionSteal) then
        _ARG_0_:AddControlEvent(_ARG_0_.BoxCollisionSteal, U1(50, 143, 26, 102, 115, 99, 60, 61, 155, 78, 57, 36, 60, 135, 225, 107, 194, 167, 76, 75, 130, 66, 83), _ARG_0_.OnStealAreaBeginOverlap, _ARG_0_)
      end
      if _ARG_0_.BoxCollisionLock and slua.isValid(_ARG_0_.BoxCollisionLock) then
        _ARG_0_:AddControlEvent(_ARG_0_.BoxCollisionLock, U1(50, 143, 26, 102, 115, 99, 60, 61, 155, 78, 57, 36, 60, 135, 225, 107, 194, 167, 76, 75, 130, 66, 83), _ARG_0_.OnLockAreaBeginOverlap, _ARG_0_)
      end
      if _ARG_0_.BoxCollisionLock2 and slua.isValid(_ARG_0_.BoxCollisionLock2) then
        _ARG_0_:AddControlEvent(_ARG_0_.BoxCollisionLock2, U1(50, 143, 26, 102, 115, 99, 60, 61, 155, 78, 57, 36, 60, 135, 225, 107, 194, 167, 76, 75, 130, 66, 83), _ARG_0_.OnLockAreaBeginOverlap, _ARG_0_)
      end
      if slua.isValid(_ARG_0_.PlayAreaComponent) then
        _ARG_0_:AddControlEvent(_ARG_0_.PlayAreaComponent, U1(50, 143, 26, 102, 115, 99, 60, 61, 155, 78, 57, 36, 60, 135, 225, 107, 194, 167, 76, 75, 130, 66, 83), _ARG_0_.OnPlayAreaBeginOverlapFunc, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_.PlayAreaComponent, U1(50, 143, 26, 102, 115, 99, 60, 61, 155, 78, 57, 35, 55, 132, 199, 115, 232, 163, 69, 88, 158), _ARG_0_.OnPlayAreaEndOverlapFunc, _ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientBindCollisionEvents"] = function(_ARG_0_)
    do
      if (require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 122, 130, 74, 70, 13, 154, 30, 30, 25, 39, 150, 241, 114, 179, 145, 85, 72, 144, 113, 103, 63),
        U1(18, 130, 56, 101, 77, 114, 37, 54)
      }))).GetValue(require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 122, 130, 74, 70, 13, 154, 30, 30, 25, 39, 150, 241, 114, 179, 145, 85, 72, 144, 113, 103, 63),
        U1(18, 130, 56, 101, 77, 114, 37, 54)
      }))).Keys.RecallGuideCount) or 0) >= require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 122, 130, 74, 70, 13, 154, 30, 30, 25, 39, 150, 241, 114, 179, 145, 85, 72, 144, 113, 103, 63),
        U1(18, 130, 56, 101, 77, 114, 37, 54)
      }))).Configs.RECALL_GUIDE_MAX_COUNT then
        return
      end
      _ARG_0_.bClientLocalPlayerInArea = false
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnStealAreaBeginOverlap"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_2_) then
        return
      end
      if not Game:IsClassOf(_ARG_2_, U1) then
        return
      end
      if not _ARG_0_.nOwnerPlayerKey or type(_ARG_0_.nOwnerPlayerKey) ~= U2(19, 148, 52, 107, 123, 97) or _ARG_0_.nOwnerPlayerKey <= 0 then
        return
      end
      if _ARG_0_.nOwnerPlayerKey ~= _ARG_2_.PlayerKey then
        return
      end
      if not _ARG_2_.GetStealingMonster then
        return
      end
      if not slua.isValid((_ARG_2_:GetStealingMonster())) then
        return
      end
      if _ARG_2_:GetStealingMonster().State ~= U3.EState.BeingStolen then
        return
      end
      if (slua.isValid((_ARG_2_:GetControllerSafety())) and _ARG_2_:GetControllerSafety().MonsterWarehouseFeature or nil) and (slua.isValid((_ARG_2_:GetControllerSafety())) and _ARG_2_:GetControllerSafety().MonsterWarehouseFeature or nil):IsWarehouseFull() then
        return
      end
      if not _ARG_0_:GetAvailableSlotIndex() then
        if _ARG_2_.PlayerKey then
        end
        return
      end
      if not _ARG_2_:GetStealingMonster():OnStealSuccess(_ARG_2_, (_ARG_0_:GetAvailableSlotIndex())) then
        return
      end
      if _ARG_2_.PlayerKey then
        if slua.isValid((_ARG_2_:GetControllerSafety())) and _ARG_2_:GetControllerSafety().ClientRPC_OnGetMonster then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_TryHandleGiftDelivery"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_1_.GetHoldingMonster then
        return
      end
      if not slua.isValid((_ARG_1_:GetHoldingMonster())) then
        return
      end
      if _ARG_1_:GetHoldingMonster().State ~= U1.EState.BeingHeld then
        return
      end
      if not _ARG_1_.GiveGiftFeature then
        return
      end
      if U3.Gift.CooldownDuration > 0 and 0 < _ARG_1_.GiveGiftFeature:GetRemainingCooldown() then
        return
      end
      if _ARG_1_:GetHoldingMonster():OnGiftDelivered(_ARG_0_.Object) and U3.Gift.CooldownDuration > 0 then
      elseif not _ARG_1_:GetHoldingMonster():OnGiftDelivered(_ARG_0_.Object) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnStealAreaEndOverlap"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if Client then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLockAreaBeginOverlap"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if Client then
        return
      end
      if not Game:IsClassOf(_ARG_2_, U1) then
        return
      end
      if _ARG_0_.OwnerCharacter ~= _ARG_2_ then
        return
      end
      if CGameState:GetServerWorldTimeSeconds() < _ARG_0_.nUnlockTime then
        if _ARG_0_.OwnerCharacter.PlayerKey and type(_ARG_0_.OwnerCharacter.PlayerKey) == U2(19, 148, 52, 107, 123, 97) and _ARG_0_.OwnerCharacter.PlayerKey > 0 then
        end
        return
      end
      if SubsystemMgr:Get((U2(63, 142, 42, 122, 76, 124, 60, 62, 173, 85, 47, 21, 32, 147, 252, 96, 224))) and SubsystemMgr:Get((U2(63, 142, 42, 122, 76, 124, 60, 62, 173, 85, 47, 21, 32, 147, 252, 96, 224))):IsActivityActive() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLockAreaEndOverlap"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if Client then
        return
      end
      print(bWriteLog and string.format((table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 5, 159, 251, 126, 220, 179, 92, 72, 187, 93, 87, 60),
        U1(11, 132, 43, 101, 127, 99, 115, 126, 222, 97, 46, 18, 54, 146, 168, 105, 232, 183, 93, 25, 130, 76, 64, 8, 206, 81, 47, 19, 40)
      }))))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveEndPlay"] = function(_ARG_0_)
    do
      if _ARG_0_.CoinSlotMgr then
        _ARG_0_.CoinSlotMgr:OnEndPlay()
        _ARG_0_.CoinSlotMgr = nil
      end
      if _ARG_0_.CoinProductionTimer then
        _ARG_0_:RemoveGameTimer(_ARG_0_.CoinProductionTimer)
        _ARG_0_.CoinProductionTimer = nil
      end
      _ARG_0_:StopAICoinReportingTimer()
      _ARG_0_:CancelLoadMesh()
      _ARG_0_:_StopGalleryUnlockRetryTimer()
      if not Client then
        _ARG_0_:RemoveAllGreenPassPlayers()
      end
      _ARG_0_:HideBaseScreenMark()
      _ARG_0_:_ServerForceStopInfraredAlarm()
      _ARG_0_:_ClientStopInfraredAlarmFX()
      _ARG_0_.uInfraredAlarmFX_Steady = nil
      _ARG_0_.uInfraredAlarmFX_Blink = nil
      U1.__super.ReceiveEndPlay(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitByCarryInData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      if not SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))) then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_1_:GetEnsure() and not _ARG_2_ then
        return
      end
      if _ARG_1_:GetEnsure() then
      elseif not slua.isValid((_ARG_1_:GetPlayerControllerSafety())) then
        return
      end
      if not _ARG_1_:GetEnsure() then
        if SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(40, 146, 60, 90, 117, 122, 61))) and _ARG_1_:GetPlayerControllerSafety().SkinFeature then
          if _ARG_1_.PartnerGhostFeature then
          end
        end
      else
      end
      if SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(63, 128, 42, 96, 125))) and SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(63, 128, 42, 96, 125))).nRebirthCount then
      else
      end
      if SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40))) and SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40))).nAdditionSlotCount then
      else
      end
      if SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40))) and SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40))).nPendingAdditionSlotCount then
        _ARG_0_.PendingAdditionSlotCount = SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40))).nPendingAdditionSlotCount
      end
      if CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(63, 128, 42, 96, 125))).nRebirthCount) then
        _ARG_0_.RebirthCount = SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(63, 128, 42, 96, 125))).nRebirthCount
        _ARG_0_.BaseLevel = CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(63, 128, 42, 96, 125))).nRebirthCount).BasementLevel
        _ARG_0_.DoorLockDuration = CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(63, 128, 42, 96, 125))).nRebirthCount).BaseLockTime
        _ARG_0_.MoneyReturnRatio = CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(63, 128, 42, 96, 125))).nRebirthCount).MoneyReturnRatio_f
        _ARG_0_.StartBudget = tonumber(CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(63, 128, 42, 96, 125))).nRebirthCount).StartBudget) or 0
      else
        _ARG_0_.RebirthCount = SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(63, 128, 42, 96, 125))).nRebirthCount
        _ARG_0_.DoorLockDuration = 60
        _ARG_0_.BaseLevel = 1
        _ARG_0_.MoneyReturnRatio = 1.0
        _ARG_0_.StartBudget = 1000
      end
      if SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40))) and SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40))).MonsterSlots then
        if not _ARG_1_:GetEnsure() then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1.PlayerKey
    end
  end,
  ["UpdateBuildingMesh"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Building) then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 223, 180, 80, 69, 154, 90, 93, 20),
          U1(48, 132, 42, 97, 62, 62, 115, 17, 139, 73, 33, 2, 48, 142, 239, 37, 238, 190, 68, 73, 129, 77, 70, 13, 154, 16, 51, 25, 61, 208, 254, 122, 232, 175, 93, 9, 145, 65, 19, 26),
          U1(19, 151, 56, 101, 119, 119)
        }))
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 223, 180, 80, 69, 154, 90, 93, 20),
        U1(48, 132, 42, 97, 62, 62, 115, 0, 149, 73, 35, 47, 29, 187, 173, 97, 208, 241, 107, 88, 157, 70, 111, 6, 152, 85, 49, 45, 108, 148, 197)
      }), _ARG_0_.SkinID, _ARG_0_.BaseLevel))
      if not CDataTable.GetTableData(U1(45, 141, 56, 103, 92, 71, 17, 50, 141, 69, 30, 13, 48, 142, 203, 106, 227, 183, 64, 94), _ARG_0_.SkinID) then
        return
      end
      if _ARG_0_.BaseLevel == 1 then
      elseif _ARG_0_.BaseLevel == 2 then
      end
      if not SubsystemMgr:Get((U1(45, 141, 56, 103, 92, 71, 7, 59, 155, 77, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):OverlayBaseSkin(_ARG_0_.SkinID, (CDataTable.GetTableData(U1(45, 141, 56, 103, 92, 71, 17, 50, 141, 69, 30, 13, 48, 142, 203, 106, 227, 183, 64, 94), _ARG_0_.SkinID))).MeshPathDouble or SubsystemMgr:Get((U1(45, 141, 56, 103, 92, 71, 7, 59, 155, 77, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):OverlayBaseSkin(_ARG_0_.SkinID, (CDataTable.GetTableData(U1(45, 141, 56, 103, 92, 71, 17, 50, 141, 69, 30, 13, 48, 142, 203, 106, 227, 183, 64, 94), _ARG_0_.SkinID))).MeshPathDouble == U1() then
        return
      end
      _ARG_0_.MeshLoadRequestId = _ARG_0_.MeshLoadRequestId + 1
      _ARG_0_.PendingMeshAssetPath = SubsystemMgr:Get((U1(45, 141, 56, 103, 92, 71, 7, 59, 155, 77, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):OverlayBaseSkin(_ARG_0_.SkinID, (CDataTable.GetTableData(U1(45, 141, 56, 103, 92, 71, 17, 50, 141, 69, 30, 13, 48, 142, 203, 106, 227, 183, 64, 94), _ARG_0_.SkinID))).MeshPathDouble, SubsystemMgr:Get((U1(45, 141, 56, 103, 92, 71, 7, 59, 155, 77, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):OverlayBaseSkin(_ARG_0_.SkinID, (CDataTable.GetTableData(U1(45, 141, 56, 103, 92, 71, 17, 50, 141, 69, 30, 13, 48, 142, 203, 106, 227, 183, 64, 94), _ARG_0_.SkinID))), _ARG_0_.MeshLoadRequestId
      if _ARG_0_.MeshLoadHandleId then
        _ARG_0_.MeshLoadHandleId = nil
      end
      _ARG_0_.MeshLoadHandleId = require((U1(30, 142, 52, 100, 113, 125, 125, 50, 141, 83, 40, 18, 6, 149, 252, 108, 225))).GetAssetAsyncOneParam(SubsystemMgr:Get((U1(45, 141, 56, 103, 92, 71, 7, 59, 155, 77, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):OverlayBaseSkin(_ARG_0_.SkinID, (CDataTable.GetTableData(U1(45, 141, 56, 103, 92, 71, 17, 50, 141, 69, 30, 13, 48, 142, 203, 106, 227, 183, 64, 94), _ARG_0_.SkinID))).MeshPathDouble, function(_ARG_0_)
        do
          if _ENV ~= U1.MeshLoadRequestId then
            U2.printf(U2.bWriteLog and U2.table.concat({
              U3(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 223, 180, 80, 69, 154, 90, 93, 20),
              U3(48, 132, 42, 97, 62, 65, 54, 48, 159, 76, 33, 70, 11, 133, 249, 112, 232, 162, 93, 112, 138, 120, 6, 7, 179, 16, 16, 19, 58, 152, 212, 122, 252, 165, 107, 76, 143, 70, 86, 0),
              U3(9, 168, 61, 82, 59, 119, 14, 115, 140, 69, 57, 19, 43, 142)
            }), _ENV, U1.MeshLoadRequestId)
            return
          end
          U1.MeshLoadHandleId = nil
          if not U2.slua.isValid(U1.Building) then
            U2.print(U2.bWriteLog and U2.table.concat({
              U3(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 223, 180, 80, 69, 154, 90, 93, 20),
              U3(48, 132, 42, 97, 62, 65, 54, 48, 159, 76, 33, 70, 27, 149, 225, 105, 233, 184, 71, 94, 206, 74, 77, 21, 143, 92, 52, 18)
            }))
            return
          end
          if not U2.slua.isValid(_ARG_0_) then
            U2.print(U2.bWriteLog and U2.table.concat({
              U3(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 223, 180, 80, 69, 154, 90, 93, 20),
              U3(48, 132, 42, 97, 62, 65, 54, 48, 159, 76, 33, 70, 21, 143, 233, 97, 232, 181, 104, 74, 157, 70, 87, 67, 135, 94, 43, 23, 37, 153, 252)
            }))
            return
          end
          if U1.PendingMeshAssetPath ~= U4 then
            U2.print(U2.bWriteLog and U2.table.concat({
              U3(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 223, 180, 80, 69, 154, 90, 93, 20),
              U3(48, 132, 42, 97, 62, 65, 54, 48, 159, 76, 33, 70, 9, 133, 230, 97, 228, 191, 78, 116, 139, 80, 75, 34, 157, 67, 56, 2, 25, 145, 236, 125, 189, 191, 4, 9, 179, 86, 64, 27),
              U3(45, 128, 45, 97)
            }))
            return
          end
          U1.Building:SetStaticMesh(_ARG_0_)
          U2.printf(U2.bWriteLog and U2.table.concat({
            U3(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 223, 180, 80, 69, 154, 90, 93, 20),
            U3(48, 132, 42, 97, 62, 65, 54, 48, 159, 76, 33, 70, 11, 133, 249, 112, 232, 162, 93, 112, 138, 120, 6, 7, 179, 16, 31, 23, 58, 149, 212, 112, 235, 164, 85, 114, 219, 87, 110, 83),
            U3(46, 138, 48, 103, 87, 87, 8, 118, 154, 125, 109, 43, 60, 147, 224, 85, 236, 165, 65, 98, 203, 80, 126)
          }), _ENV, U1.BaseLevel, U1.SkinID, U4)
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CancelLoadMesh"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 146, 72, 87, 141, 70, 79, 47, 129, 81, 57, 59, 44, 131, 240))
      _ARG_0_.MeshLoadRequestId = _ARG_0_.MeshLoadRequestId + 1
      _ARG_0_.PendingMeshAssetPath = nil
      if _ARG_0_.MeshLoadHandleId then
        print(bWriteLog and table.concat({
          U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 146, 72, 87, 141, 70, 79, 47, 129, 81, 57, 59, 44, 131, 240, 53, 222, 160, 87, 74, 155, 95, 114, 0),
          U1(14, 132, 45, 72, 109, 106, 61, 48)
        }))
        _ARG_0_.MeshLoadHandleId = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[100]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateSecondFloor"] = function(_ARG_0_)
    do
      if _ARG_0_.BaseLevel == 1 then
        if slua.isValid(_ARG_0_.WidgetUnlockTime) and slua.isValid(_ARG_0_.WidgetUnlockTime.Widget) and slua.isValid(_ARG_0_.WidgetUnlockTime.Widget.TextUnlockCountFloor2) then
          _ARG_0_.WidgetUnlockTime.Widget.TextUnlockCountFloor2:SetVisibility(UEnums.ESlateVisibility.Collapsed)
          _ARG_0_.WidgetUnlockTime:RequestRedraw()
        end
        if slua.isValid(_ARG_0_.MeshLock2) then
          _ARG_0_.MeshLock2:SetHiddenInGame(true, true)
        end
        if slua.isValid(_ARG_0_.BoxCollisionLock2) then
          _ARG_0_:RemoveControlEvent(_ARG_0_.BoxCollisionLock2, (U1(50, 143, 26, 102, 115, 99, 60, 61, 155, 78, 57, 36, 60, 135, 225, 107, 194, 167, 76, 75, 130, 66, 83)))
        end
        if slua.isValid(_ARG_0_.DoorFX2) then
          _ARG_0_.DoorFX2:Deactivate()
        end
      elseif _ARG_0_.BaseLevel == 2 then
        if Client then
          _ARG_0_:UpdateUnlockTimeUI()
        end
        if slua.isValid(_ARG_0_.MeshLock2) then
          _ARG_0_.MeshLock2:SetHiddenInGame(false, true)
        end
        if slua.isValid(_ARG_0_.BoxCollisionLock2) then
          _ARG_0_:AddControlEvent(_ARG_0_.BoxCollisionLock2, U1(50, 143, 26, 102, 115, 99, 60, 61, 155, 78, 57, 36, 60, 135, 225, 107, 194, 167, 76, 75, 130, 66, 83), _ARG_0_.OnLockAreaBeginOverlap, _ARG_0_)
        end
        if _ARG_0_.DoorsState == U2.Locked then
          if slua.isValid(_ARG_0_.DoorFX2) then
            _ARG_0_.DoorFX2:Activate(true)
            print(bWriteLog and table.concat({
              U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 206, 164, 90, 70, 144, 87, 117, 31),
              U1(18, 142, 43, 41, 51, 51, 18, 48, 138, 73, 59, 7, 45, 133, 236, 37, 201, 190, 70, 75, 168, 123, 17, 67, 140, 85, 62, 23, 60, 131, 253, 53, 249, 174, 86, 91, 141, 19, 82, 1),
              U1(24, 193, 58, 124, 108, 97, 54, 61, 138, 76, 52, 70, 53, 143, 235, 110, 232, 181)
            }))
          end
        elseif slua.isValid(_ARG_0_.DoorFX2) then
          _ARG_0_.DoorFX2:Deactivate()
        end
        if Client then
          _ARG_0_:ClientBindSecondFloorCollision()
          _ARG_0_:SetSecondFloorSlotsVisible(false)
        end
      end
      _ARG_0_:UpdateStairsCoverCollision()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientBindSecondFloorCollision"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not slua.isValid(_ARG_0_.BoxCollisionSecondFloor) then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 26, 32, 149, 246, 97, 223, 168, 87, 77, 173, 86, 80, 28),
          U1(19, 133, 31, 101, 113, 124, 33, 16, 145, 76, 33, 15, 42, 137, 231, 107, 173, 252, 9, 123, 129, 91, 96, 12, 130, 92, 52, 5, 32, 159, 246, 70, 248, 162, 86, 71, 154, 117, 95, 28),
          U1(18, 147, 121, 103, 113, 103, 115, 53, 145, 85, 35, 2, 121, 143, 250, 37, 228, 191, 95, 88, 130, 74, 71)
        }))
        return
      end
      _ARG_0_:AddControlEvent(_ARG_0_.BoxCollisionSecondFloor, U1(50, 143, 26, 102, 115, 99, 60, 61, 155, 78, 57, 36, 60, 135, 225, 107, 194, 167, 76, 75, 130, 66, 83), _ARG_0_.OnSecondFloorBeginOverlap, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_.BoxCollisionSecondFloor, U1(50, 143, 26, 102, 115, 99, 60, 61, 155, 78, 57, 35, 55, 132, 199, 115, 232, 163, 69, 88, 158), _ARG_0_.OnSecondFloorEndOverlap, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSecondFloorBeginOverlap"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not Client then
        return
      end
      if not slua.isValid((U1.GetPlayerCharacter())) or _ARG_2_ ~= U1.GetPlayerCharacter() then
        return
      end
      _ARG_0_.bClientLocalPlayerOnSecondFloor = true
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSecondFloorEndOverlap"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not Client then
        return
      end
      if not slua.isValid((U1.GetPlayerCharacter())) or _ARG_2_ ~= U1.GetPlayerCharacter() then
        return
      end
      _ARG_0_.bClientLocalPlayerOnSecondFloor = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSecondFloorSlotsVisible"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      _ARG_0_ = _ARG_0_
      if nil <= _ARG_0_.SlotCount then
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateStairsCoverCollision"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.StairsCover) then
        return
      end
      if _ARG_0_.BaseLevel == 2 then
        _ARG_0_.StairsCover:SetCollisionEnabled(U1.QueryAndPhysics)
      else
        _ARG_0_.StairsCover:SetCollisionEnabled(U1.NoCollision)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetOwner"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not _ARG_1_ or not slua.isValid(_ARG_1_) then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 19, 61, 191, 239, 123, 248, 179, 25, 4, 222, 122, 93, 5),
          U1(28, 141, 48, 109, 62, 102, 3, 63, 159, 89, 40, 20, 26, 136, 233, 119, 236, 178, 93, 92, 156)
        }))
        return
      end
      if slua.isValid(_ARG_0_.OwnerCharacter) and _ARG_0_.OwnerCharacter ~= _ARG_1_ then
      end
      _ARG_0_.nOwnerPlayerKey = _ARG_1_.PlayerKey, _ARG_0_.OwnerCharacter, _ARG_0_:RemoveAllGreenPassPlayers()
      _ARG_0_.OwnerCharacter = _ARG_1_
      _ARG_0_.OwnerPlayerName = _ARG_1_.PlayerName
      _ARG_0_.OverlapList = {}
      _ARG_0_.LastStealAlertTime = 0
      goto lbl_400
      ::lbl_400::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SpawnMonstersInSlots"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not _ARG_1_ or type(_ARG_1_) ~= U1(9, 128, 59, 101, 123) then
        return
      end
      _ARG_0_ = _ARG_0_
      if U3(_ARG_1_[123]) then
        if _ARG_0_.MonsterSlots[123] and slua.isValid(_ARG_0_.MonsterSlots[123].Mesh) then
          if _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation() then
            if slua.isValid((U6.SpawnActorRobust(U2.Blueprint.MonsterActor, U4(_ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Z + U2.Spawn.HeightOffset), _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():Rotator() or U5(0.0, 0.0, 0.0), U4(1.0, 1.0, 1.0)))) then
              U6.SpawnActorRobust(U2.Blueprint.MonsterActor, U4(_ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Z + U2.Spawn.HeightOffset), _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():Rotator() or U5(0.0, 0.0, 0.0), U4(1.0, 1.0, 1.0)).SlotIndex = 123, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld(), _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation(), _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():Rotator(), U4(_ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Z + U2.Spawn.HeightOffset), _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():Rotator() or U5(0.0, 0.0, 0.0), U6.SpawnActorRobust(U2.Blueprint.MonsterActor, U4(_ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Z + U2.Spawn.HeightOffset), _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():Rotator() or U5(0.0, 0.0, 0.0), U4(1.0, 1.0, 1.0)), U6.SpawnActorRobust(U2.Blueprint.MonsterActor, U4(_ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Z + U2.Spawn.HeightOffset), _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():Rotator() or U5(0.0, 0.0, 0.0), U4(1.0, 1.0, 1.0)):InitByID(U3(_ARG_1_[123]))
              if not _ARG_0_:AddMonster(U6.SpawnActorRobust(U2.Blueprint.MonsterActor, U4(_ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Z + U2.Spawn.HeightOffset), _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():Rotator() or U5(0.0, 0.0, 0.0), U4(1.0, 1.0, 1.0)), 123) then
              end
            else
            end
          else
          end
        else
        end
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetOwner"] = function(_ARG_0_)
    do
      do return _ARG_0_.OwnerCharacter end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateBaseOwnerInfoUI"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not _ARG_0_.Widget or not slua.isValid(_ARG_0_.Widget) then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 223, 160, 74, 76, 177, 68, 93, 22),
          U1(15, 168, 55, 111, 113, 70, 26, 115, 211, 0, 26, 15, 61, 135, 237, 113, 173, 191, 70, 77, 206, 69, 76, 22, 128, 84, 125, 25, 59, 208, 241, 123, 235, 160, 85, 64, 154)
        }))
        return
      end
      if not slua.isValid(_ARG_0_.Widget.Widget) then
        return
      end
      if _ARG_0_.Widget.Widget.TextMyBase and slua.isValid(_ARG_0_.Widget.Widget.TextMyBase) then
        if _ARG_0_.nOwnerPlayerKey and 0 < _ARG_0_.nOwnerPlayerKey and U2.GetPlayerController().PlayerKey == _ARG_0_.nOwnerPlayerKey then
        else
        end
      end
      if _ARG_0_.Widget.Widget.TextOwnerName and slua.isValid(_ARG_0_.Widget.Widget.TextOwnerName) then
        if _ARG_0_.nOwnerPlayerKey and 0 < _ARG_0_.nOwnerPlayerKey then
          if _ARG_0_.OwnerPlayerName and _ARG_0_.OwnerPlayerName ~= U1() then
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateBaseTitleUI"] = function(_ARG_0_)
    do
      _ARG_0_:UpdateBaseOwnerInfoUI()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateBaseTitleWidgetCullDistance"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not _ARG_0_.Widget or not slua.isValid(_ARG_0_.Widget) then
        return
      end
      if _ARG_0_.nOwnerPlayerKey and _ARG_0_.nOwnerPlayerKey > 0 and U1.GetPlayerController().PlayerKey == _ARG_0_.nOwnerPlayerKey then
      else
      end
      if not U2.MonsterBaseTitleWidgetCullDistanceOtherBase or 0 >= U2.MonsterBaseTitleWidgetCullDistanceOtherBase then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_UpdateLockBillboardFXVisibility"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not _ARG_0_.uLockBillboardFX or not slua.isValid(_ARG_0_.uLockBillboardFX) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateLockAreaUI"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      _ARG_0_:_UpdateLockBillboardFXVisibility()
      if not _ARG_0_.WidgetUnlockTime or not slua.isValid(_ARG_0_.WidgetUnlockTime) then
        return
      end
      if U1.GetPlayerController().PlayerKey == _ARG_0_.nOwnerPlayerKey then
        if slua.isValid(_ARG_0_.WidgetUnlockTime.Widget) and slua.isValid(_ARG_0_.WidgetUnlockTime.Widget.TextToLockBase) then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateStealAreaUI"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not _ARG_0_.Widget or not slua.isValid(_ARG_0_.Widget) then
        return
      end
      if not slua.isValid(_ARG_0_.Widget.Widget) then
        return
      end
      if U1.GetPlayerController().PlayerKey == _ARG_0_.nOwnerPlayerKey then
        if slua.isValid(_ARG_0_.Widget.Widget.TextTotalCoinProfitRatio) then
          if U1.GetPlayerController() and U1.GetPlayerController().CoinFeature or nil then
          else
          end
        else
        end
        if slua.isValid(_ARG_0_.Widget.Widget.TextStealCheckArea) then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateBaseOwnerName"] = function(_ARG_0_)
    do
      _ARG_0_:UpdateBaseOwnerInfoUI()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowBaseScreenMark"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if _ARG_0_.BaseScreenMarkID then
        return
      end
      if not _ARG_0_.Object or not slua.isValid(_ARG_0_.Object) then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 30, 38, 135, 218, 116, 238, 164, 106, 74, 140, 86, 86, 29),
          U1(48, 128, 43, 98, 62, 62, 115, 28, 156, 74, 40, 5, 45, 192, 225, 118, 173, 184, 71, 79, 143, 79, 74, 7)
        }))
        return
      end
      _ARG_0_.BaseScreenMarkID = U2.ClientAddMapMark(4305, _ARG_0_:K2_GetActorLocation(), 0, U1(), UEnums.EAddMarkFlag.EAMF_BothAndScreen, _ARG_0_.Object)
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 30, 38, 135, 218, 116, 238, 164, 106, 74, 140, 86, 86, 29),
        U1(48, 128, 43, 98, 62, 62, 115, 18, 154, 68, 40, 2, 121, 147, 235, 119, 232, 180, 71, 25, 131, 66, 81, 8, 194, 16, 20, 50, 18, 213, 235, 72)
      }), tostring(_ARG_0_.BaseScreenMarkID)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideBaseScreenMark"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if _ARG_0_.BaseScreenMarkID then
        U1.HideMapMark(_ARG_0_.BaseScreenMarkID)
        _ARG_0_.BaseScreenMarkID = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateBaseScreenMark"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not slua.isValid((U1.GetPlayerController())) then
        return
      end
      if _ARG_0_.nOwnerPlayerKey and _ARG_0_.nOwnerPlayerKey > 0 and _ARG_0_.nOwnerPlayerKey == U1.GetPlayerController().PlayerKey then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_OwnerPlayerName"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 210, 182, 87, 76, 140, 99, 95, 18),
        U1(4, 132, 43, 71, 127, 126, 54, 115, 211, 0, 2, 10, 61, 182, 233, 105, 248, 180, 114, 28, 157, 126, 15, 67, 160, 85, 42, 32, 40, 156, 237, 112, 198, 228, 74, 116)
      }), tostring(_ARG_1_ or U1()), tostring(_ARG_0_.OwnerPlayerName or U1())))
      if Client then
        _ARG_0_:UpdateBaseOwnerInfoUI()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSlotCount"] = function(_ARG_0_)
    do
      do return _ARG_0_.SlotCount end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsValidSlotIndex"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ and type(_ARG_1_) == U1(19, 148, 52, 107, 123, 97) then
        return 1 <= _ARG_1_ and _ARG_1_ <= _ARG_0_:GetSlotCount()
      else
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSlotEmpty"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or type(_ARG_1_) ~= U1(19, 148, 52, 107, 123, 97) or _ARG_1_ < 1 or _ARG_1_ > _ARG_0_:GetSlotCount() then
        return false
      end
      if not _ARG_0_.MonsterSlots[_ARG_1_] or not slua.isValid(_ARG_0_.MonsterSlots[_ARG_1_].Mesh) then
        return false
      end
      if not _ARG_0_.MonsterSlots[_ARG_1_].Monster or not slua.isValid(_ARG_0_.MonsterSlots[_ARG_1_].Monster) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAvailableSlotIndex"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if _ARG_0_:IsSlotEmpty(nil) then
        return nil
      end
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAvailableSlotCount"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if _ARG_0_:IsSlotEmpty(nil) then
      end
      _ARG_0_ = _ARG_0_
      do return 0 + 1 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetNearestAvailableSlotIndex"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.OwnerCharacter) then
        return nil
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_:IsSlotEmpty(nil) and _ARG_0_.MonsterSlots[nil] and slua.isValid(_ARG_0_.MonsterSlots[nil].Mesh) and _ARG_0_.MonsterSlots[nil].Mesh:K2_GetComponentToWorld() and math.huge > (_ARG_0_.MonsterSlots[nil].Mesh:K2_GetComponentToWorld():GetLocation().X - _ARG_0_.OwnerCharacter:K2_GetActorLocation().X) * (_ARG_0_.MonsterSlots[nil].Mesh:K2_GetComponentToWorld():GetLocation().X - _ARG_0_.OwnerCharacter:K2_GetActorLocation().X) + (_ARG_0_.MonsterSlots[nil].Mesh:K2_GetComponentToWorld():GetLocation().Y - _ARG_0_.OwnerCharacter:K2_GetActorLocation().Y) * (_ARG_0_.MonsterSlots[nil].Mesh:K2_GetComponentToWorld():GetLocation().Y - _ARG_0_.OwnerCharacter:K2_GetActorLocation().Y) + (_ARG_0_.MonsterSlots[nil].Mesh:K2_GetComponentToWorld():GetLocation().Z - _ARG_0_.OwnerCharacter:K2_GetActorLocation().Z) * (_ARG_0_.MonsterSlots[nil].Mesh:K2_GetComponentToWorld():GetLocation().Z - _ARG_0_.OwnerCharacter:K2_GetActorLocation().Z) then
      end
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetToEmptyBase"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 15, 19, 58, 149, 236, 65, 242, 132, 84, 89, 138, 74, 113, 18),
        U1(14, 132, 121, 36, 62, 65, 54, 32, 155, 84, 57, 15, 55, 135, 168, 103, 236, 162, 76, 25, 154, 76, 3, 6, 131, 64, 41, 15, 105, 131, 236, 116, 233, 164)
      }))
      _ARG_0_:ClearSlots()
      _ARG_0_:_ServerForceStopInfraredAlarm()
      _ARG_0_.nOwnerPlayerKey = 0
      _ARG_0_.OwnerCharacter = nil
      _ARG_0_.OwnerPlayerName = U1()
      _ARG_0_.RebirthCount = 0
      _ARG_0_:SetSlotCount(0, 0)
      _ARG_0_.PendingAdditionSlotCount = 0
      _ARG_0_.DoorLockDuration = 60
      _ARG_0_.BaseLevel = 1
      _ARG_0_.MoneyReturnRatio = 1.0
      _ARG_0_.StartBudget = 1000
      goto lbl_210
      ::lbl_210::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.OverlapList = {}
      _ARG_0_.LastStealAlertTime = 0
      _ARG_0_.StealAlertCD = 10
      _ARG_0_.LastIntruderAlertTime = 0
      _ARG_0_.IntruderAlertCD = 10
      do return end
      _ARG_0_ = BaseParams
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBaseEmpty"] = function(_ARG_0_)
    do
      do return _ARG_0_.nOwnerPlayerKey == 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FillCarryOutData"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not _ARG_0_.nOwnerPlayerKey or _ARG_0_.nOwnerPlayerKey <= 0 then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 27, 31, 37, 156, 219, 116, 239, 179, 64, 102, 139, 71, 119, 18),
          U1(9, 128, 121, 36, 62, 81, 50, 32, 155, 0, 37, 7, 42, 192, 230, 106, 173, 190, 94, 87, 139, 81)
        }))
        return
      end
      if not _ARG_1_ then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 27, 31, 37, 156, 219, 116, 239, 179, 64, 102, 139, 71, 119, 18),
          U1(9, 128, 121, 36, 62, 90, 61, 37, 159, 76, 36, 2, 121, 131, 233, 119, 255, 168, 9, 86, 155, 87, 3, 7, 143, 68, 60, 86, 61, 145, 250, 121, 248)
        }))
        return
      end
      if not _ARG_1_.MonsterBase then
        _ARG_1_.MonsterBase = {}
      end
      _ARG_1_.MonsterBase.MonsterSlots = {}
      _ARG_0_ = _ARG_0_
      if _ARG_0_.MonsterSlots[U1(9, 128, 121, 36, 62, 90, 61, 37, 159, 76, 36, 2, 121, 131, 233, 119, 255, 168, 9, 86, 155, 87, 3, 7, 143, 68, 60, 86, 61, 145, 250, 121, 248)] and _ARG_0_.MonsterSlots[U1(9, 128, 121, 36, 62, 90, 61, 37, 159, 76, 36, 2, 121, 131, 233, 119, 255, 168, 9, 86, 155, 87, 3, 7, 143, 68, 60, 86, 61, 145, 250, 121, 248)].Monster and slua.isValid(_ARG_0_.MonsterSlots[U1(9, 128, 121, 36, 62, 90, 61, 37, 159, 76, 36, 2, 121, 131, 233, 119, 255, 168, 9, 86, 155, 87, 3, 7, 143, 68, 60, 86, 61, 145, 250, 121, 248)].Monster) then
        if _ARG_0_.MonsterSlots[U1(9, 128, 121, 36, 62, 90, 61, 37, 159, 76, 36, 2, 121, 131, 233, 119, 255, 168, 9, 86, 155, 87, 3, 7, 143, 68, 60, 86, 61, 145, 250, 121, 248)].Monster.State == U2.EMonsterState.InBase then
          _ARG_1_.MonsterBase.MonsterSlots[U1(9, 128, 121, 36, 62, 90, 61, 37, 159, 76, 36, 2, 121, 131, 233, 119, 255, 168, 9, 86, 155, 87, 3, 7, 143, 68, 60, 86, 61, 145, 250, 121, 248)] = {
            id = _ARG_0_.MonsterSlots[U1(9, 128, 121, 36, 62, 90, 61, 37, 159, 76, 36, 2, 121, 131, 233, 119, 255, 168, 9, 86, 155, 87, 3, 7, 143, 68, 60, 86, 61, 145, 250, 121, 248)].Monster.MonsterID,
            star = _ARG_0_.MonsterSlots[U1(9, 128, 121, 36, 62, 90, 61, 37, 159, 76, 36, 2, 121, 131, 233, 119, 255, 168, 9, 86, 155, 87, 3, 7, 143, 68, 60, 86, 61, 145, 250, 121, 248)].Monster.StarLevel or 0
          }
        else
        end
      end
      _ARG_0_ = _ARG_0_
      _ARG_1_.MonsterBase.nAdditionSlotCount = _ARG_0_.AdditionSlotCount or 0
      _ARG_1_.MonsterBase.nPendingAdditionSlotCount = _ARG_0_.PendingAdditionSlotCount or 0
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1.star
    end
  end,
  ["CreateDoors"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 4, 44, 145, 236, 112, 217, 174, 86, 91, 141, 19, 30, 83),
        U1(62, 147, 60, 104, 106, 122, 61, 52, 222, 68, 34, 9, 43, 192, 233, 102, 249, 190, 91, 74)
      }))
      if _ARG_0_.BoxCollisionDoor and slua.isValid(_ARG_0_.BoxCollisionDoor) then
        if _ARG_0_.BoxCollisionDoor:K2_GetComponentToWorld() then
          if slua.isValid((U4.SpawnActorRobust(U2.Blueprint.AccessControlDoor, _ARG_0_.BoxCollisionDoor:K2_GetComponentToWorld():GetLocation(), _ARG_0_.BoxCollisionDoor:K2_GetComponentToWorld():Rotator(), (U3(1.0, 1.0, 1.0))))) then
            _ARG_0_.DoorActor1 = U4.SpawnActorRobust(U2.Blueprint.AccessControlDoor, _ARG_0_.BoxCollisionDoor:K2_GetComponentToWorld():GetLocation(), _ARG_0_.BoxCollisionDoor:K2_GetComponentToWorld():Rotator(), (U3(1.0, 1.0, 1.0))), U4.SpawnActorRobust(U2.Blueprint.AccessControlDoor, _ARG_0_.BoxCollisionDoor:K2_GetComponentToWorld():GetLocation(), _ARG_0_.BoxCollisionDoor:K2_GetComponentToWorld():Rotator(), (U3(1.0, 1.0, 1.0))):SetOwnerBase(_ARG_0_.Object)
          else
          end
        else
        end
      else
      end
      if _ARG_0_.BoxCollisionDoor2 and slua.isValid(_ARG_0_.BoxCollisionDoor2) then
        if _ARG_0_.BoxCollisionDoor2:K2_GetComponentToWorld() then
          if slua.isValid((U4.SpawnActorRobust(U2.Blueprint.AccessControlDoor, _ARG_0_.BoxCollisionDoor2:K2_GetComponentToWorld():GetLocation(), _ARG_0_.BoxCollisionDoor2:K2_GetComponentToWorld():Rotator(), (U3(1.0, 1.0, 1.0))))) then
            _ARG_0_.DoorActor2 = U4.SpawnActorRobust(U2.Blueprint.AccessControlDoor, _ARG_0_.BoxCollisionDoor2:K2_GetComponentToWorld():GetLocation(), _ARG_0_.BoxCollisionDoor2:K2_GetComponentToWorld():Rotator(), (U3(1.0, 1.0, 1.0))), U4.SpawnActorRobust(U2.Blueprint.AccessControlDoor, _ARG_0_.BoxCollisionDoor2:K2_GetComponentToWorld():GetLocation(), _ARG_0_.BoxCollisionDoor2:K2_GetComponentToWorld():Rotator(), (U3(1.0, 1.0, 1.0))):SetOwnerBase(_ARG_0_.Object)
          else
          end
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DestroyDoors"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 25, 19, 58, 132, 234, 122, 228, 133, 86, 70, 140, 64, 19, 94),
        U1(93, 165, 60, 122, 106, 97, 60, 42, 151, 78, 42, 70, 61, 143, 231, 119, 173, 176, 74, 77, 129, 81, 80)
      }))
      if _ARG_0_.DoorActor1 and slua.isValid(_ARG_0_.DoorActor1) then
        _ARG_0_.DoorActor1:K2_DestroyActor()
        _ARG_0_.DoorActor1 = nil
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 25, 19, 58, 132, 234, 122, 228, 133, 86, 70, 140, 64, 19, 94),
          U1(93, 165, 54, 102, 108, 51, 98, 115, 154, 69, 62, 18, 43, 143, 241, 96, 233)
        }))
      end
      if _ARG_0_.DoorActor2 and slua.isValid(_ARG_0_.DoorActor2) then
        _ARG_0_.DoorActor2:K2_DestroyActor()
        _ARG_0_.DoorActor2 = nil
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 25, 19, 58, 132, 234, 122, 228, 133, 86, 70, 140, 64, 19, 94),
          U1(93, 165, 54, 102, 108, 51, 97, 115, 154, 69, 62, 18, 43, 143, 241, 96, 233)
        }))
      end
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 25, 19, 58, 132, 234, 122, 228, 133, 86, 70, 140, 64, 19, 94),
        U1(93, 165, 54, 102, 108, 51, 55, 54, 141, 84, 63, 19, 58, 148, 225, 106, 227, 241, 74, 86, 131, 83, 79, 6, 154, 85, 57)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[225]
    end
  end,
  ["IsForceUnlockOnCooldown"] = function(_ARG_0_)
    do
      if (_ARG_0_.nLastForceUnlockServerTime or 0) <= 0 then
        return false
      end
      if Door.BaseForceUnlockCooldownDuration > U1.GetTimeSeconds(U2.CGameWorld) - (_ARG_0_.nLastForceUnlockServerTime or 0) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecordForceUnlockTime"] = function(_ARG_0_)
    do
      _ARG_0_.nLastForceUnlockServerTime = GetTimeSeconds(U1.CGameWorld)
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        U2(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 15, 19, 42, 159, 234, 113, 219, 174, 75, 74, 155, 102, 93, 31),
        U2(18, 130, 50, 93, 119, 126, 54, 115, 211, 0, 31, 3, 58, 143, 250, 97, 232, 181, 9, 77, 135, 78, 70, 56, 203, 30, 111, 16, 20)
      }), _ARG_0_.nLastForceUnlockServerTime))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearForceUnlockTime"] = function(_ARG_0_)
    do
      _ARG_0_.nLastForceUnlockServerTime = 0
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 26, 44, 145, 234, 83, 242, 179, 90, 76, 171, 93, 95, 28),
        U1(30, 138, 13, 96, 115, 118, 115, 126, 222, 99, 33, 3, 56, 146, 237, 97, 173, 183, 70, 75, 141, 70, 3, 22, 128, 92, 50, 21, 34, 208, 251, 122, 242, 173, 93, 70, 137, 93)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInInitialProtect"] = function(_ARG_0_)
    do
      if (_ARG_0_.nInitialProtectUntilTime or 0) <= 0 then
        return false
      end
      if (_ARG_0_.nInitialProtectUntilTime or 0) > GetTimeSeconds(U1.CGameWorld) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartInitialProtect"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or _ARG_1_ <= 0 then
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 2, 40, 130, 236, 92, 243, 168, 77, 64, 159, 95, 99, 1),
          U1(18, 149, 60, 106, 106, 51, 126, 115, 183, 78, 59, 7, 53, 137, 236, 37, 233, 164, 91, 88, 154, 74, 76, 13, 181, 21, 46, 43)
        }), tostring(_ARG_1_)))
        return
      end
      _ARG_0_.nInitialProtectUntilTime = U2.GetTimeSeconds(CGameWorld) + _ARG_1_
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 2, 40, 130, 236, 92, 243, 168, 77, 64, 159, 95, 99, 1),
        U1(18, 149, 60, 106, 106, 51, 126, 115, 173, 84, 44, 20, 45, 133, 236, 41, 173, 181, 92, 75, 143, 87, 74, 12, 128, 107, 120, 18, 20, 131, 180, 53, 232, 175, 77, 64, 146, 104, 22, 93),
        U1(79, 135, 4)
      }), _ARG_1_, _ARG_0_.nInitialProtectUntilTime))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearInitialProtect"] = function(_ARG_0_)
    do
      _ARG_0_.nInitialProtectUntilTime = 0
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 26, 44, 145, 234, 92, 243, 168, 77, 64, 159, 95, 99, 1),
        U1(18, 149, 60, 106, 106, 51, 126, 115, 189, 76, 40, 7, 43, 133, 236, 37, 228, 191, 64, 77, 135, 66, 79, 67, 158, 66, 50, 2, 44, 147, 236, 124, 242, 175)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenDoors"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 6, 44, 158, 220, 122, 242, 179, 74, 9, 211, 19, 124, 3),
        U1(24, 143, 48, 103, 121, 51, 55, 60, 145, 82, 62)
      }))
      _ARG_0_.nUnlockTime = 0
      _ARG_0_.DoorsState = U2.Open
      if slua.isValid(_ARG_0_.DoorActor1) then
        _ARG_0_.DoorActor1:Open()
      end
      if _ARG_0_.BaseLevel > 1 and slua.isValid(_ARG_0_.DoorActor2) then
        _ARG_0_.DoorActor2:Open()
      end
      EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_MLAI_SPECIALZONE_CUSTOM_ATTRIBUTE_CHANGE, _ARG_0_.Object, 2, _ARG_0_.nUnlockTime)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LockDoors"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 17, 25, 42, 155, 220, 122, 242, 179, 74, 9, 211, 19, 127, 28),
        U1(30, 138, 48, 103, 121, 51, 55, 60, 145, 82, 62)
      }))
      _ARG_0_.DoorsState = U2.Locked
      if slua.isValid(_ARG_0_.DoorActor1) then
        _ARG_0_.DoorActor1:Lock()
      end
      if _ARG_0_.BaseLevel > 1 and slua.isValid(_ARG_0_.DoorActor2) then
        _ARG_0_.DoorActor2:Lock()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ForceLockDoorsByActivity"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.OpenDoorsTimer then
        _ARG_0_:RemoveGameTimer(_ARG_0_.OpenDoorsTimer)
        _ARG_0_.OpenDoorsTimer = nil
      end
      _ARG_0_.nUnlockTime = 0
      _ARG_0_:LockDoors()
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 27, 25, 59, 147, 253, 89, 242, 162, 82, 109, 145, 92, 65, 0),
        U1(63, 152, 24, 106, 106, 122, 37, 58, 138, 89, 109, 75, 121, 166, 231, 119, 238, 180, 9, 85, 129, 64, 72, 6, 138, 16, 57, 25, 38, 130, 235, 57, 189, 162, 85, 76, 159, 65, 86, 23),
        U1(93, 128, 53, 101, 62, 102, 61, 63, 145, 67, 38, 70, 45, 137, 229, 96, 255, 162)
      }))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Lock"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not _ARG_1_ or _ARG_1_ <= 0 then
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 17, 25, 42, 155, 184, 56, 189, 136, 87, 95, 159, 95, 90, 23),
          U1(93, 141, 54, 106, 117, 51, 55, 38, 140, 65, 57, 15, 54, 142, 211, 32, 254, 140)
        }), tostring(_ARG_1_)))
        return
      end
      if slua.isValid(_ARG_0_.OwnerCharacter) and slua.isValid((_ARG_0_.OwnerCharacter:GetPlayerControllerSafety())) and _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().HasBaseLockDurationBuff15 and _ARG_0_.OwnerCharacter:GetPlayerControllerSafety():HasBaseLockDurationBuff15() then
        _ARG_1_ = _ARG_1_ + 15
      end
      if not slua.isValid((U2.GetGameState())) then
        return
      end
      _ARG_0_.nUnlockTime = U2.GetGameState():GetServerWorldTimeSeconds() + _ARG_1_
      if _ARG_0_.OpenDoorsTimer then
        _ARG_0_.OpenDoorsTimer = nil
      end
      _ARG_0_.OpenDoorsTimer = _ARG_0_:AddGameTimer(_ARG_1_, false, function()
        OpenDoorsTimer = nil
        _ENV:OpenDoors()
        return
      end)
      if slua.isValid(_ARG_0_.OwnerCharacter) and _ARG_0_.OwnerCharacter.PlayerKey and type(_ARG_0_.OwnerCharacter.PlayerKey) == U1(19, 148, 52, 107, 123, 97) and 0 < _ARG_0_.OwnerCharacter.PlayerKey then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[100]
    end
  end,
  ["OnRep_DoorsState"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 217, 174, 86, 91, 141, 96, 71, 18),
        U1(9, 132, 121, 36, 62, 87, 60, 60, 140, 83, 109, 21, 45, 129, 252, 96, 173, 178, 65, 88, 128, 68, 70, 7, 206, 86, 47, 25, 36, 208, 189, 113, 189, 181, 86, 9, 219, 87)
      }), _ARG_1_, _ARG_0_.DoorsState))
      if _ARG_0_.DoorsState == U2.Open then
        if slua.isValid(_ARG_0_.DoorFX) then
          _ARG_0_.DoorFX:Deactivate()
        end
        if _ARG_0_.BaseLevel > 1 and slua.isValid(_ARG_0_.DoorFX2) then
          _ARG_0_.DoorFX2:Deactivate()
        end
        _ARG_0_:_ClientNotifyPlayerUntrapped()
        if _ARG_0_.UnlockCountdownTimer then
          _ARG_0_:RemoveGameTimer(_ARG_0_.UnlockCountdownTimer)
          _ARG_0_.UnlockCountdownTimer = nil
        end
        _ARG_0_.ClientRemainingTime = 0
        _ARG_0_:UpdateUnlockTimeUI()
      elseif _ARG_0_.DoorsState == U2.Locked then
        if slua.isValid(_ARG_0_.DoorFX) then
          _ARG_0_.DoorFX:Activate(true)
        end
        if _ARG_0_.BaseLevel > 1 and slua.isValid(_ARG_0_.DoorFX2) then
          _ARG_0_.DoorFX2:Activate(true)
        end
        _ARG_0_:ClientControlGreenPass(_ARG_0_.DoorActor1)
        _ARG_0_:ClientControlGreenPass(_ARG_0_.DoorActor2)
        _ARG_0_:_ClientCheckLocalPlayerTrapped()
        if _ARG_0_.nUnlockTime and 0 < _ARG_0_.nUnlockTime then
          _ARG_0_.ClientRemainingTime = _ARG_0_:_ClientCalcRemainingTime()
          print(bWriteLog and string.format(table.concat({
            U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 217, 174, 86, 91, 141, 96, 71, 18),
            U1(9, 132, 121, 36, 62, 87, 60, 60, 140, 0, 33, 9, 58, 139, 237, 97, 161, 241, 90, 77, 143, 81, 87, 10, 128, 87, 125, 21, 38, 133, 246, 97, 249, 174, 78, 71, 222, 85, 65, 28),
            U1(16, 193, 124, 39, 44, 117)
          }), _ARG_0_.ClientRemainingTime))
          _ARG_0_:StartUnlockCountdownTimer()
        else
          _ARG_0_.ClientRemainingTime = 0
          _ARG_0_:UpdateUnlockTimeUI()
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClientCheckLocalPlayerTrapped"] = function(_ARG_0_)
    do
      if not _ARG_0_.bClientLocalPlayerInArea then
        return
      end
      if not U1.slua.isValid((GetPlayerCharacter())) then
        return
      end
      if _ARG_0_.nOwnerPlayerKey and _ARG_0_.nOwnerPlayerKey > 0 and GetPlayerCharacter().PlayerKey == _ARG_0_.nOwnerPlayerKey then
        return
      end
      if _ARG_0_:_IsPlayerInGreenPassList(GetPlayerCharacter().PlayerKey) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClientNotifyPlayerUntrapped"] = function(_ARG_0_)
    do
      if not _ARG_0_.bClientLocalPlayerInArea then
        return
      end
      if not U1.slua.isValid((GetPlayerCharacter())) then
        return
      end
      if _ARG_0_.nOwnerPlayerKey and _ARG_0_.nOwnerPlayerKey > 0 and GetPlayerCharacter().PlayerKey == _ARG_0_.nOwnerPlayerKey then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_DoorActor1"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 217, 174, 86, 91, 191, 80, 71, 28),
        U1(15, 208, 121, 36, 62, 87, 60, 60, 140, 0, 44, 5, 45, 143, 250, 37, 188, 241, 74, 81, 143, 77, 68, 6, 138)
      }))
      _ARG_0_:ClientControlGreenPass(_ARG_0_.DoorActor1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_DoorActor2"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 217, 174, 86, 91, 191, 80, 71, 28),
        U1(15, 211, 121, 36, 62, 87, 60, 60, 140, 0, 44, 5, 45, 143, 250, 37, 191, 241, 74, 81, 143, 77, 68, 6, 138)
      }))
      _ARG_0_:ClientControlGreenPass(_ARG_0_.DoorActor2)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_nUnlockTime"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 243, 148, 87, 69, 145, 80, 88, 39),
        U1(20, 140, 60, 41, 51, 51, 28, 63, 154, 118, 44, 10, 44, 133, 211, 32, 235, 140, 5, 25, 160, 70, 84, 53, 143, 92, 40, 19, 18, 213, 254, 72)
      }), _ARG_1_, _ARG_0_.nUnlockTime))
      if _ARG_0_.nUnlockTime <= 0 then
        if _ARG_0_.UnlockCountdownTimer then
          _ARG_0_:RemoveGameTimer(_ARG_0_.UnlockCountdownTimer)
          _ARG_0_.UnlockCountdownTimer = nil
        end
        _ARG_0_.ClientRemainingTime = 0
        _ARG_0_:UpdateUnlockTimeUI()
        return
      end
      _ARG_0_.ClientRemainingTime = _ARG_0_:_ClientCalcRemainingTime()
      if not _ARG_0_.UnlockCountdownTimer then
        _ARG_0_:StartUnlockCountdownTimer()
      else
        _ARG_0_:UpdateUnlockTimeUI()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_IsServerTimeReady"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetGameState())) then
        return false
      end
      if GetGameState().ReplicatedWorldTimeSeconds == nil or GetGameState().ReplicatedWorldTimeSeconds <= 0 then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClientCalcRemainingTime"] = function(_ARG_0_)
    do
      if not _ARG_0_.nUnlockTime or _ARG_0_.nUnlockTime <= 0 then
        return 0
      end
      if not _ARG_0_:_IsServerTimeReady() then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 2, 53, 37, 153, 253, 123, 233, 130, 88, 69, 157, 97, 86, 30),
          U1(28, 136, 55, 96, 112, 116, 7, 58, 147, 69, 109, 75, 121, 179, 237, 119, 251, 180, 91, 109, 135, 78, 70, 67, 128, 95, 41, 86, 59, 149, 249, 113, 228)
        }))
        return -1
      end
      if 0 > _ARG_0_.nUnlockTime - U2.GetGameState():GetServerWorldTimeSeconds() then
      end
      do return 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartUnlockCountdownTimer"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if _ARG_0_.UnlockCountdownTimer then
        _ARG_0_:RemoveGameTimer(_ARG_0_.UnlockCountdownTimer)
        _ARG_0_.UnlockCountdownTimer = nil
      end
      if _ARG_0_.ClientRemainingTime == 0 then
        _ARG_0_:UpdateUnlockTimeUI()
        return
      end
      _ARG_0_:UpdateUnlockTimeUI()
      _ARG_0_.UnlockCountdownTimer = _ARG_0_:AddGameTimer(1.0, true, function()
        ClientRemainingTime = _ENV:_ClientCalcRemainingTime()
        if ClientRemainingTime < 0 then
          return
        end
        _ENV:UpdateUnlockTimeUI(true)
        if ClientRemainingTime <= 0 and UnlockCountdownTimer then
          _ENV:RemoveGameTimer(UnlockCountdownTimer)
          UnlockCountdownTimer = nil
        end
        return
      end)
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 2, 40, 130, 236, 64, 243, 173, 86, 74, 149, 112, 92, 6),
        U1(19, 149, 61, 102, 105, 125, 7, 58, 147, 69, 63, 70, 116, 192, 219, 113, 236, 163, 93, 92, 138, 3, 64, 12, 155, 94, 41, 18, 38, 135, 246, 53, 233, 168, 84, 76, 140, 31, 19, 26),
        U1(19, 136, 45, 96, 127, 127, 115, 39, 151, 77, 40, 92, 121, 197, 166, 55, 235)
      }), _ARG_0_.ClientRemainingTime))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateUnlockTimeUI"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      if not slua.isValid(_ARG_0_.WidgetUnlockTime) then
        return
      end
      if not slua.isValid(_ARG_0_.WidgetUnlockTime.Widget) then
        return
      end
      _ARG_0_.WidgetUnlockTime:RequestRedraw()
      if not slua.isValid(_ARG_0_.WidgetUnlockTime.Widget.TextUnlockCountFloor1) then
        return
      end
      if _ARG_0_.BaseLevel >= 2 then
        if not slua.isValid(_ARG_0_.WidgetUnlockTime.Widget.TextUnlockCountFloor2) then
          return
        end
      end
      if _ARG_0_.ClientRemainingTime < 0 then
        if _ARG_0_.WidgetUnlockTime.Widget.TextUnlockCountFloor2 then
        end
        return
      end
      if _ARG_0_.ClientRemainingTime <= 0 then
        if _ARG_0_.DoorsState == U2.Locked and not _ARG_1_ then
          if _ARG_0_.WidgetUnlockTime.Widget.TextUnlockCountFloor2 then
          end
          return
        end
        if _ARG_0_.WidgetUnlockTime.Widget.TextUnlockCountFloor2 then
        end
        return
      end
      if _ARG_0_.WidgetUnlockTime.Widget.TextUnlockCountFloor2 then
      end
      if _ARG_0_.WidgetUnlockTime.Widget.TextUnlockCountFloor2 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartCoinProductionTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.CoinProductionTimer then
        _ARG_0_:RemoveGameTimer(_ARG_0_.CoinProductionTimer)
        _ARG_0_.CoinProductionTimer = nil
      end
      _ARG_0_.CoinProductionTimer = _ARG_0_:AddGameTimer(1.0, true, function()
        _ENV:UpdateCoinProduction()
        return
      end)
      _ARG_0_:StartAICoinReportingTimer()
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 2, 40, 130, 236, 86, 242, 168, 87, 121, 140, 92, 87, 6),
        U1(30, 149, 48, 102, 112, 71, 58, 62, 155, 82, 109, 75, 121, 163, 231, 108, 227, 241, 89, 75, 129, 71, 86, 0, 154, 89, 50, 24, 105, 132, 241, 120, 248, 179, 25, 90, 138, 82, 65, 7),
        U1(24, 133)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCoinProduction"] = function(_ARG_0_)
    do
      if not _ARG_0_.nOwnerPlayerKey or _ARG_0_.nOwnerPlayerKey <= 0 then
        return
      end
      if _ARG_0_.CoinSlotMgr then
        _ARG_0_.CoinSlotMgr:TickProductionDS()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SpawnMonsterInAvailableSlot"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return nil, nil
      end
      if not _ARG_1_ or type(_ARG_1_) ~= U1(19, 148, 52, 107, 123, 97) or _ARG_1_ <= 0 then
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 6, 40, 135, 246, 88, 242, 175, 74, 93, 155, 65, 122, 29),
          U1(60, 151, 56, 96, 114, 114, 49, 63, 155, 115, 33, 9, 45, 192, 165, 37, 196, 191, 95, 88, 130, 74, 71, 67, 131, 95, 51, 5, 61, 149, 234, 53, 212, 133, 98, 12, 141, 110)
        }), tostring(_ARG_1_)))
        return nil, nil
      end
      if not _ARG_0_:GetAvailableSlotIndex() then
        return nil, nil
      end
      if not _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()] or not slua.isValid(_ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh) then
        return nil, nil
      end
      if not _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld() then
        return nil, nil
      end
      if not _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation() then
        return nil, nil
      end
      if not slua.isValid((U5.SpawnActorRobust(U4.Blueprint.MonsterActor, U2(_ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Z + 20.0), _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():Rotator() or U3(0.0, 0.0, 0.0), U2(1.0, 1.0, 1.0)))) then
        return nil, nil
      end
      U5.SpawnActorRobust(U4.Blueprint.MonsterActor, U2(_ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Z + 20.0), _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():Rotator() or U3(0.0, 0.0, 0.0), U2(1.0, 1.0, 1.0)).SlotIndex = _ARG_0_:GetAvailableSlotIndex(), _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()], _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld(), _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation(), _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():Rotator(), 20.0, U2(_ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Z + 20.0), _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():Rotator() or U3(0.0, 0.0, 0.0), U4.Blueprint.MonsterActor, U5.SpawnActorRobust(U4.Blueprint.MonsterActor, U2(_ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Z + 20.0), _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():Rotator() or U3(0.0, 0.0, 0.0), U2(1.0, 1.0, 1.0)), U5.SpawnActorRobust(U4.Blueprint.MonsterActor, U2(_ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Z + 20.0), _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():Rotator() or U3(0.0, 0.0, 0.0), U2(1.0, 1.0, 1.0)):InitByID(_ARG_1_, _ARG_2_)
      do return U5.SpawnActorRobust(U4.Blueprint.MonsterActor, U2(_ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Z + 20.0), _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():Rotator() or U3(0.0, 0.0, 0.0), U2(1.0, 1.0, 1.0)), (_ARG_0_:GetAvailableSlotIndex()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[140]
    end
  end,
  ["SpawnMonsterInSlot"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if Client then
        return nil
      end
      if not _ARG_1_ or type(_ARG_1_) ~= U1(19, 148, 52, 107, 123, 97) or _ARG_1_ <= 0 then
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 6, 40, 135, 246, 88, 242, 175, 74, 93, 155, 65, 122, 29),
          U1(46, 141, 54, 125, 62, 62, 115, 26, 144, 86, 44, 10, 48, 132, 168, 104, 226, 191, 90, 77, 139, 81, 3, 42, 170, 107, 120, 5, 20)
        }), tostring(_ARG_1_)))
        return nil
      end
      if not _ARG_0_:IsValidSlotIndex(_ARG_2_) then
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 6, 40, 135, 246, 88, 242, 175, 74, 93, 155, 65, 122, 29),
          U1(46, 141, 54, 125, 62, 62, 115, 26, 144, 86, 44, 10, 48, 132, 168, 118, 225, 190, 93, 25, 135, 77, 71, 6, 150, 107, 120, 5, 20)
        }), tostring(_ARG_2_)))
        return nil
      end
      if not _ARG_0_:IsSlotEmpty(_ARG_2_) then
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 6, 40, 135, 246, 88, 242, 175, 74, 93, 155, 65, 122, 29),
          U1(46, 141, 54, 125, 62, 62, 115, 0, 146, 79, 57, 61, 124, 132, 213, 37, 228, 162, 9, 87, 129, 87, 3, 6, 131, 64, 41, 15)
        }), _ARG_2_))
        return nil
      end
      if not _ARG_0_.MonsterSlots[_ARG_2_] or not slua.isValid(_ARG_0_.MonsterSlots[_ARG_2_].Mesh) then
        return nil
      end
      if not _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld() then
        return nil
      end
      if not _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation() then
        return nil
      end
      if not slua.isValid((U5.SpawnActorRobust(U2.Blueprint.MonsterActor, U3(_ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().Z + (U2.Spawn and U2.Spawn.HeightOffset or 20.0)), _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():Rotator() or U4(0.0, 0.0, 0.0), U3(1.0, 1.0, 1.0)))) then
        return nil
      end
      U5.SpawnActorRobust(U2.Blueprint.MonsterActor, U3(_ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().Z + (U2.Spawn and U2.Spawn.HeightOffset or 20.0)), _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():Rotator() or U4(0.0, 0.0, 0.0), U3(1.0, 1.0, 1.0)).SlotIndex = _ARG_2_
      if not _ARG_0_:AddMonster(U5.SpawnActorRobust(U2.Blueprint.MonsterActor, U3(_ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().Z + (U2.Spawn and U2.Spawn.HeightOffset or 20.0)), _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():Rotator() or U4(0.0, 0.0, 0.0), U3(1.0, 1.0, 1.0)), _ARG_2_) then
        return nil
      end
      do return (U5.SpawnActorRobust(U2.Blueprint.MonsterActor, U3(_ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().Z + (U2.Spawn and U2.Spawn.HeightOffset or 20.0)), _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():Rotator() or U4(0.0, 0.0, 0.0), U3(1.0, 1.0, 1.0))) end
      do return end
      _ARG_2_ = _ENV[36]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSkinID"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if type(_ARG_1_) ~= U1(19, 148, 52, 107, 123, 97) then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 19, 61, 163, 243, 124, 243, 136, 125, 9, 211, 19, 90, 29),
          U1(11, 128, 53, 96, 122, 51, 39, 42, 142, 69)
        }))
        return
      end
      if _ARG_0_.SkinID == _ARG_1_ then
        printf(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 19, 61, 163, 243, 124, 243, 136, 125, 9, 211, 19, 64, 18),
          U1(16, 132, 121, 96, 122)
        }))
        return
      end
      if not U2.GetBaseSkin()[_ARG_1_] then
        return
      end
      _ARG_0_.SkinID = _ARG_1_
      if CDataTable.GetTableData(U1(45, 141, 56, 103, 92, 71, 17, 50, 141, 69, 30, 13, 48, 142, 203, 106, 227, 183, 64, 94), _ARG_0_.SkinID) and CDataTable.GetTableData(U1(45, 141, 56, 103, 92, 71, 17, 50, 141, 69, 30, 13, 48, 142, 203, 106, 227, 183, 64, 94), _ARG_0_.SkinID).BuffRatio_f then
        if slua.isValid((U3.GetPlayerController(_ARG_0_.nOwnerPlayerKey))) then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateMonsterSlotInfo"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CalculateOfflineCoinProduction"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      printf(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 23, 37, 147, 237, 121, 252, 181, 92, 102, 152, 85, 95, 26),
        U1(19, 132, 26, 102, 119, 125, 3, 33, 145, 68, 56, 5, 45, 137, 231, 107, 173, 129, 69, 88, 151, 70, 81, 40, 139, 73, 6, 83, 58, 173)
      }), tostring(_ARG_2_))
      if not slua.isValid(_ARG_0_.OwnerCharacter) then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 23, 37, 147, 237, 121, 252, 181, 92, 102, 152, 85, 95, 26),
          U1(19, 132, 26, 102, 119, 125, 3, 33, 145, 68, 56, 5, 45, 137, 231, 107, 173, 252, 9, 112, 128, 85, 66, 15, 135, 84, 125, 57, 62, 158, 253, 103, 222, 169, 88, 91, 159, 80, 71, 22),
          U1(15)
        }))
        return
      end
      if not slua.isValid((_ARG_0_.OwnerCharacter:GetPlayerControllerSafety())) then
        return
      end
      if not _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().CoinFeature then
        return
      end
      if type((SubsystemMgr:Get((U1(62, 147, 60, 104, 106, 122, 37, 54, 174, 76, 44, 31, 60, 146, 199, 99, 235, 189, 64, 87, 139, 103, 66, 23, 143, 99, 40, 20, 58, 137, 235, 97, 248, 172))):GetPlayerOfflineDuration(_ARG_2_))) ~= U1(19, 148, 52, 107, 123, 97) then
        return
      end
      if math.floor((SubsystemMgr:Get((U1(62, 147, 60, 104, 106, 122, 37, 54, 174, 76, 44, 31, 60, 146, 199, 99, 235, 189, 64, 87, 139, 103, 66, 23, 143, 99, 40, 20, 58, 137, 235, 97, 248, 172))):GetPlayerOfflineDuration(_ARG_2_))) > require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 102, 152, 85, 95, 26),
        U1(19, 132, 26, 102, 119, 125, 16, 60, 144, 70, 36, 1)
      }))).MaxOfflineDuration then
      end
      goto lbl_968
      if 0 < (U2(tostring(require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 102, 152, 85, 95, 26),
        U1(19, 132, 26, 102, 119, 125, 16, 60, 144, 70, 36, 1)
      }))).MaxOfflineDuration)) and U3.CalculateProductionEfficiency(U2(tostring(require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 102, 152, 85, 95, 26),
        U1(19, 132, 26, 102, 119, 125, 16, 60, 144, 70, 36, 1)
      }))).MaxOfflineDuration))) or 0) then
      end
      ::lbl_968::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if (0 + (U2(tostring(require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 102, 152, 85, 95, 26),
        U1(19, 132, 26, 102, 119, 125, 16, 60, 144, 70, 36, 1)
      }))).MaxOfflineDuration)) and U3.CalculateProductionEfficiency(U2(tostring(require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 102, 152, 85, 95, 26),
        U1(19, 132, 26, 102, 119, 125, 16, 60, 144, 70, 36, 1)
      }))).MaxOfflineDuration))) or 0)) / require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 102, 152, 85, 95, 26),
        U1(19, 132, 26, 102, 119, 125, 16, 60, 144, 70, 36, 1)
      }))).DecayFactor * require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 102, 152, 85, 95, 26),
        U1(19, 132, 26, 102, 119, 125, 16, 60, 144, 70, 36, 1)
      }))).MaxOfflineDuration == 0 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateAllAIPerceptionInfo"] = function(_ARG_0_)
    do
      if slua.isValid(_ARG_0_.OwnerCharacter) then
        EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_MLAI_SPECIALZONE_STATECHANGE, _ARG_0_.Object, 0, _ARG_0_.OwnerCharacter.PlayerKey)
      else
        EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_MLAI_SPECIALZONE_STATECHANGE, _ARG_0_.Object, 0, 0)
      end
      EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_MLAI_SPECIALZONE_CUSTOM_ATTRIBUTE_CHANGE, _ARG_0_.Object, 1, _ARG_0_.RebirthCount)
      EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_MLAI_SPECIALZONE_CUSTOM_ATTRIBUTE_CHANGE, _ARG_0_.Object, 2, _ARG_0_.nUnlockTime)
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_0_.CoinSlotMgr then
        _ARG_0_ = _ARG_0_
        if 0 < _ARG_0_.CoinSlotMgr:GetSlotCoinCount((_ARG_0_:UpdateMonsterSlotInfo(_ARG_0_.MonsterSlots[EVENTID_MLAI_SPECIALZONE_CUSTOM_ATTRIBUTE_CHANGE]))) then
        end
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCoinSlotInfo"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      if not _ARG_1_ or _ARG_1_ <= 0 then
        return
      end
      EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_MLAI_SPECIALZONE_CUSTOM_ATTRIBUTE_CHANGE, _ARG_0_.Object, _ARG_1_, _ARG_2_ or 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReportSlotCoinCount"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      if not _ARG_1_ or _ARG_1_ <= 0 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayAreaBeginOverlapFunc"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not Game:IsClassOf(_ARG_2_, (import((table.concat({
        U1(82, 178, 58, 123, 119, 99, 39, 124, 173, 72, 44, 2, 54, 151, 220, 119, 236, 178, 66, 92, 156, 102, 91, 23, 156, 81, 115, 37, 29, 181, 224, 97, 239, 160, 105, 69, 159, 74, 86, 1),
        U1(62, 137, 56, 123, 127, 112, 39, 54, 140)
      }))))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayAreaEndOverlapFunc"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not Game:IsClassOf(_ARG_2_, (import((table.concat({
        U1(82, 178, 58, 123, 119, 99, 39, 124, 173, 72, 44, 2, 54, 151, 220, 119, 236, 178, 66, 92, 156, 102, 91, 23, 156, 81, 115, 37, 29, 181, 224, 97, 239, 160, 105, 69, 159, 74, 86, 1),
        U1(62, 137, 56, 123, 127, 112, 39, 54, 140)
      }))))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientPlayAreaBeginOverlap"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not Game:IsClassOf(_ARG_2_, (import((table.concat({
        U1(82, 178, 58, 123, 119, 99, 39, 124, 173, 72, 44, 2, 54, 151, 220, 119, 236, 178, 66, 92, 156, 102, 91, 23, 156, 81, 115, 37, 29, 181, 224, 97, 239, 160, 105, 69, 159, 74, 86, 1),
        U1(62, 137, 56, 123, 127, 112, 39, 54, 140)
      }))))) then
        return
      end
      if not slua.isValid((U2.GetPlayerCharacter())) or _ARG_2_ ~= U2.GetPlayerCharacter() then
        return
      end
      _ARG_0_.bClientLocalPlayerInArea = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientPlayAreaEndOverlap"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not Game:IsClassOf(_ARG_2_, (import((table.concat({
        U1(82, 178, 58, 123, 119, 99, 39, 124, 173, 72, 44, 2, 54, 151, 220, 119, 236, 178, 66, 92, 156, 102, 91, 23, 156, 81, 115, 37, 29, 181, 224, 97, 239, 160, 105, 69, 159, 74, 86, 1),
        U1(62, 137, 56, 123, 127, 112, 39, 54, 140)
      }))))) then
        return
      end
      if not slua.isValid((U2.GetPlayerCharacter())) or _ARG_2_ ~= U2.GetPlayerCharacter() then
        return
      end
      _ARG_0_.bClientLocalPlayerInArea = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerOnPlayerEnterOrLeave"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_0_.OwnerCharacter) then
        print(bWriteLog and table.concat({
          U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 130, 76, 75, 152, 70, 81, 44, 128, 96, 49, 23, 48, 149, 234, 80, 243, 181, 92, 91, 177, 65, 127, 22),
          U1(28, 151, 60, 41, 81, 100, 61, 54, 140, 99, 37, 7, 43, 129, 235, 113, 232, 163, 9, 80, 128, 85, 66, 15, 135, 84)
        }))
        return
      end
      if _ARG_0_.OwnerCharacter:GetEnsure() then
        print(bWriteLog and table.concat({
          U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 130, 76, 75, 152, 70, 81, 44, 128, 96, 49, 23, 48, 149, 234, 80, 243, 181, 92, 91, 177, 65, 127, 22),
          U1(28, 151, 60, 41, 89, 118, 39, 22, 144, 83, 56, 20, 60)
        }))
        return
      end
      if not slua.isValid(_ARG_1_) then
        print(bWriteLog and table.concat({
          U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 130, 76, 75, 152, 70, 81, 44, 128, 96, 49, 23, 48, 149, 234, 80, 243, 181, 92, 91, 177, 65, 127, 22),
          U1(28, 151, 60, 41, 107, 80, 59, 50, 140, 65, 46, 18, 60, 146, 168, 108, 227, 167, 72, 85, 135, 71)
        }))
        return
      end
      if _ARG_2_ then
        _ARG_0_.OverlapList[_ARG_1_.PlayerKey] = true
        if not _ARG_0_.nOwnerPlayerKey or _ARG_0_.nOwnerPlayerKey <= 0 then
          print(bWriteLog and table.concat({
            U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 130, 76, 75, 152, 70, 81, 44, 128, 96, 49, 23, 48, 149, 234, 80, 243, 181, 92, 91, 177, 65, 127, 22),
            U1(28, 151, 60, 41, 112, 92, 36, 61, 155, 82, 29, 10, 56, 153, 237, 119, 198, 180, 80, 25, 135, 77, 85, 2, 130, 89, 57)
          }))
          return
        end
        print(bWriteLog and string.format(table.concat({
          U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 130, 76, 75, 152, 70, 81, 44, 128, 96, 49, 23, 48, 149, 234, 80, 243, 181, 92, 91, 177, 65, 127, 22),
          U1(28, 151, 60, 41, 124, 86, 61, 39, 155, 82, 119, 67, 42, 192, 253, 70, 229, 176, 91, 88, 141, 87, 70, 17, 212, 21, 46)
        }), tostring(_ARG_2_), _ARG_1_:GetPlayerNameSafety()))
        if _ARG_0_:IsCharacterInvited(_ARG_1_.PlayerKey) then
          return
        end
        if _ARG_0_.OwnerCharacter == _ARG_1_ then
          print(bWriteLog and table.concat({
            U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 130, 76, 75, 152, 70, 81, 44, 128, 96, 49, 23, 48, 149, 234, 80, 243, 181, 92, 91, 177, 65, 127, 22),
            U1(28, 151, 60, 41, 119, 96, 115, 60, 137, 78, 40, 20)
          }))
          return
        end
        if not slua.isValid(_ARG_0_.OwnerCharacter.PlayerState) then
          return
        end
        if not _ARG_0_.OwnerCharacter.PlayerState:CheckIngameBuffValid(U2.StealAlertBuff) then
          return
        end
      else
        print(bWriteLog and string.format(table.concat({
          U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 130, 76, 75, 152, 70, 81, 44, 128, 96, 49, 23, 48, 149, 234, 80, 243, 181, 92, 91, 177, 65, 127, 22),
          U1(28, 151, 60, 41, 124, 86, 61, 39, 155, 82, 119, 67, 42, 192, 253, 70, 229, 176, 91, 88, 141, 87, 70, 17, 212, 21, 46)
        }), tostring(_ARG_2_), _ARG_1_:GetPlayerNameSafety()))
        _ARG_0_.OverlapList[_ARG_1_.PlayerKey] = false
        _ARG_0_:ServerRemoveInfraredAlarmOnIntruder(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StealAlert"] = function(_ARG_0_)
    do
      if CGameState:GetServerWorldTimeSeconds() - _ARG_0_.LastStealAlertTime < _ARG_0_.StealAlertCD then
        return
      end
      _ARG_0_.LastStealAlertTime = CGameState:GetServerWorldTimeSeconds()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckOverlapList"] = function(_ARG_0_)
    do
      goto lbl_15
      if nil and not _ARG_0_:IsCharacterInvited(nil) then
        return
      end
      ::lbl_15::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCharacterInvited"] = function(_ARG_0_, _ARG_1_)
    do
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerStartInfraredAlarmByOwnerBuff"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.InfraredAlarmBuffState ~= U1.Inactive then
        print(bWriteLog and table.concat({
          U2(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 130, 76, 75, 152, 70, 81, 48, 154, 81, 47, 2, 0, 158, 254, 103, 252, 179, 92, 77, 191, 95, 82, 1),
          U2(16, 163, 32, 70, 105, 125, 54, 33, 188, 85, 43, 0, 121, 129, 228, 119, 232, 176, 77, 64, 206, 66, 64, 23, 135, 70, 56)
        }))
        return
      end
      if next(_ARG_0_.InfraredAlarmIntruders) ~= nil then
        _ARG_0_.InfraredAlarmBuffState = U1.Blink
      else
        _ARG_0_.InfraredAlarmBuffState = U1.Steady
      end
      print(bWriteLog and string.format(table.concat({
        U2(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 130, 76, 75, 152, 70, 81, 48, 154, 81, 47, 2, 0, 158, 254, 103, 252, 179, 92, 77, 191, 95, 82, 1),
        U2(16, 163, 32, 70, 105, 125, 54, 33, 188, 85, 43, 0, 121, 147, 252, 100, 249, 180, 114, 28, 138, 126)
      }), _ARG_0_.InfraredAlarmBuffState))
      _ARG_0_:_ServerStartInfraredAlarmWatchdog()
      do return end
      _ARG_0_ = _ENV[176]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerApplyInfraredAlarmOnIntruder"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_1_.PlayerKey or _ARG_1_.PlayerKey <= 0 then
        return
      end
      if _ARG_0_.InfraredAlarmIntruders[_ARG_1_.PlayerKey] then
        return
      end
      _ARG_0_.InfraredAlarmIntruders[_ARG_1_.PlayerKey] = true
      if U3.IntruderAlertTip and 0 < U3.IntruderAlertTip then
        if CGameState:GetServerWorldTimeSeconds() - _ARG_0_.LastIntruderAlertTime < _ARG_0_.IntruderAlertCD then
        else
          _ARG_0_.LastIntruderAlertTime = CGameState:GetServerWorldTimeSeconds()
        end
      end
      if _ARG_0_.InfraredAlarmBuffState == U5.Steady then
        _ARG_0_.InfraredAlarmBuffState = U5.Blink
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerRemoveInfraredAlarmOnIntruder"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_1_.PlayerKey or _ARG_1_.PlayerKey <= 0 then
        return
      end
      if not _ARG_0_.InfraredAlarmIntruders[_ARG_1_.PlayerKey] then
        return
      end
      _ARG_0_.InfraredAlarmIntruders[_ARG_1_.PlayerKey] = nil
      if not next(_ARG_0_.InfraredAlarmIntruders) and _ARG_0_.InfraredAlarmBuffState == U3.Blink then
        _ARG_0_.InfraredAlarmBuffState = U3.Steady
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_InfraredAlarmBuffState"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 158, 71, 107, 139, 83, 124, 42, 128, 86, 47, 23, 59, 149, 252, 84, 241, 160, 75, 68, 188, 70, 85, 21),
        U1(46, 149, 56, 125, 123, 51, 60, 63, 154, 123, 104, 21, 4, 192, 230, 96, 250, 138, 12, 74, 179)
      }), tostring(_ARG_1_), tostring(_ARG_0_.InfraredAlarmBuffState)))
      if _ARG_0_.InfraredAlarmBuffState == U2.Inactive then
        _ARG_0_:_ClientStopInfraredAlarmFX()
      elseif _ARG_0_.InfraredAlarmBuffState == U2.Steady then
        _ARG_0_:_ClientSpawnInfraredAlarmFX(false)
      elseif _ARG_0_.InfraredAlarmBuffState == U2.Blink then
        _ARG_0_:_ClientSpawnInfraredAlarmFX(true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClientStartInfraredAlarmFX"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not _ARG_0_.Object or not slua.isValid(_ARG_0_.Object) then
        return
      end
      if slua.isValid(_ARG_0_.InfraredAlarmFXComp) then
        return
      end
      _ARG_0_:_ClientSpawnInfraredAlarmFX(_ARG_0_.InfraredAlarmBuffState == U1.Blink)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClientStopInfraredAlarmFX"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if _ARG_0_.InfraredAlarmFXComp and slua.isValid(_ARG_0_.InfraredAlarmFXComp) then
        _ARG_0_.InfraredAlarmFXComp:K2_DestroyComponent(_ARG_0_.InfraredAlarmFXComp)
      end
      _ARG_0_.InfraredAlarmFXComp = nil
      if _ARG_0_.InfraredAlarmFXLoadHandle then
        U1.ClearAssetAsync(_ARG_0_.InfraredAlarmFXLoadHandle)
        _ARG_0_.InfraredAlarmFXLoadHandle = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClientSpawnInfraredAlarmFX"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      if not _ARG_0_.Object or not slua.isValid(_ARG_0_.Object) then
        return
      end
      if _ARG_1_ then
      else
      end
      if _ARG_0_.uInfraredAlarmFX_Steady and slua.isValid(_ARG_0_.uInfraredAlarmFX_Steady) then
        return
      end
      if _ARG_0_.InfraredAlarmFXLoadHandle then
        _ARG_0_.InfraredAlarmFXLoadHandle = nil
      end
      _ARG_0_.InfraredAlarmFXLoadHandle = U7.GetAssetAsync(U1.InfraredAlarmFXPath_Steady, function(_ARG_0_)
        do
          InfraredAlarmFXLoadHandle = nil
          if not (_ENV and Object) or not U1.slua.isValid(Object) then
            return
          end
          if not U1.slua.isValid(_ARG_0_) then
            U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
              U2(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 142, 106, 85, 135, 70, 77, 23, 189, 64, 60, 1, 39, 185, 246, 115, 239, 160, 75, 76, 154, 114, 95, 18),
              U2(15, 140, 31, 81, 62, 117, 50, 58, 146, 69, 41, 70, 45, 143, 168, 105, 226, 176, 77, 98, 203, 80, 126)
            }), U1.tostring(U3)))
            return
          end
          if U4 then
            uInfraredAlarmFX_Blink = _ARG_0_
          else
            uInfraredAlarmFX_Steady = _ARG_0_
          end
          if InfraredAlarmBuffState == (U4 and U5.Blink or U5.Steady) then
          end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ServerStartInfraredAlarmWatchdog"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.InfraredAlarmServerWatchdog then
        _ARG_0_:RemoveGameTimer(_ARG_0_.InfraredAlarmServerWatchdog)
        _ARG_0_.InfraredAlarmServerWatchdog = nil
      end
      _ARG_0_.InfraredAlarmServerWatchdog = _ARG_0_:AddGameTimer(1.0, true, function()
        if not (_ENV and Object) or not U1.slua.isValid(Object) then
          return
        end
        if InfraredAlarmBuffState == U2.Inactive then
          return
        end
        if not U1.slua.isValid(OwnerCharacter) then
          _ENV:_ServerForceStopInfraredAlarm()
          return
        end
        if not U1.slua.isValid(OwnerCharacter.PlayerState) then
          return
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ServerStopInfraredAlarmWatchdog"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.InfraredAlarmServerWatchdog then
        _ARG_0_:RemoveGameTimer(_ARG_0_.InfraredAlarmServerWatchdog)
        _ARG_0_.InfraredAlarmServerWatchdog = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ServerForceStopInfraredAlarm"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      goto lbl_27
      ::lbl_27::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.InfraredAlarmIntruders = {}
      if _ARG_0_.InfraredAlarmBuffState ~= U3.Inactive then
        _ARG_0_.InfraredAlarmBuffState = U3.Inactive
      end
      _ARG_0_:_ServerStopInfraredAlarmWatchdog()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MulticastRPC_SyncSlotCoinCount"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.CoinSlotMgr then
        _ARG_0_.CoinSlotMgr:HandleSyncSlotCoinCount(_ARG_1_, _ARG_2_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_SlotCoinStates"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.CoinSlotMgr then
        _ARG_0_.CoinSlotMgr:OnRep_SlotCoinStates(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_SlotCollectVersions"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.CoinSlotMgr then
        _ARG_0_.CoinSlotMgr:OnRep_SlotCollectVersions(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartAICoinReportingTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      _ARG_0_:StopAICoinReportingTimer()
      _ARG_0_.AICoinReportingTimer = _ARG_0_:AddGameTimer(3.0, true, function()
        _ENV:TickAICoinReporting()
        return
      end)
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 2, 40, 130, 236, 84, 212, 130, 86, 64, 144, 97, 86, 3),
        U1(18, 147, 45, 96, 112, 116, 7, 58, 147, 69, 63, 70, 116, 192, 201, 76, 173, 178, 70, 80, 128, 3, 81, 6, 158, 95, 47, 2, 32, 158, 255, 53, 233, 168, 84, 76, 140, 19, 64, 7),
        U1(28, 147, 45, 108, 122, 51, 123, 96, 141, 0, 36, 8, 45, 133, 250, 115, 236, 189, 0)
      }))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopAICoinReportingTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.AICoinReportingTimer then
        _ARG_0_:RemoveGameTimer(_ARG_0_.AICoinReportingTimer)
        _ARG_0_.AICoinReportingTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TickAICoinReporting"] = function(_ARG_0_)
    do
      _ARG_0_:TickSlotCoin()
      goto lbl_95
      ::lbl_95::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TickSlotCoin"] = function(_ARG_0_)
    do
      if not _ARG_0_.nOwnerPlayerKey or _ARG_0_.nOwnerPlayerKey <= 0 then
        return
      end
      if not _ARG_0_.CoinSlotMgr then
        return
      end
      if not _ARG_0_.SlotCoinStates then
        return
      end
      if 0 >= (_ARG_0_.SlotCount or 0) then
        return
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_.SlotCoinStates:Get(_ARG_0_.SlotCoinStates:Num() - 1) == 1 then
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end
}).MulticastRPC.MulticastRPC_SyncSlotCoinCount = {
  Reliable = true,
  Params = {
    UEnums.EPropertyClass.Int,
    UEnums.EPropertyClass.Int64
  }
}
do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(30, 141, 56, 122, 109)))(require((table.concat({
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 27, 129, 251, 96, 192, 190, 77, 23, 173, 76, 78, 14, 129, 94, 115, 53, 38, 130, 253, 59, 220, 162, 77, 70, 140, 113, 82, 0),
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(24)
}))), nil, {
  MulticastRPC = {},
  LuaEventContainer = {
    ((function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(50, 143, 10, 101, 113, 103, 16, 60, 151, 78, 14, 14, 56, 142, 239, 96, 233))
  },
  ["ctor"] = function(_ARG_0_)
    do
      _ARG_0_.nOwnerPlayerKey = 0
      _ARG_0_.OwnerCharacter = nil
      _ARG_0_.OwnerPlayerName = _ENV()
      _ARG_0_.RebirthCount = 0
      _ARG_0_.RebirthLevel = 0
      _ARG_0_.SlotCount = 0
      _ARG_0_.RebirthSlotCount = 0
      _ARG_0_.AdditionSlotCount = 0
      _ARG_0_.PendingAdditionSlotCount = 0
      _ARG_0_.DoorLockDuration = 60
      _ARG_0_.BaseLevel = 1
      _ARG_0_.MoneyReturnRatio = 1.0
      _ARG_0_.StartBudget = 1000
      _ARG_0_.SkinID = U1.BaseParams.CurUseSkin
      _ARG_0_.MeshLoadRequestId = 0
      _ARG_0_.PendingMeshAssetPath = _ENV()
      _ARG_0_.MeshLoadHandleId = nil
      _ARG_0_.OverlapList = {}
      _ARG_0_.LastStealAlertTime = 0
      _ARG_0_.LastIntruderAlertTime = 0
      _ARG_0_.InfraredAlarmIntruders = {}
      _ARG_0_.InfraredAlarmBuffState = 0
      _ARG_0_.InfraredAlarmServerWatchdog = nil
      _ARG_0_.InfraredAlarmFXComp = nil
      _ARG_0_.uInfraredAlarmFX_Steady = nil
      _ARG_0_.uInfraredAlarmFX_Blink = nil
      _ARG_0_.InfraredAlarmFXLoadHandle = nil
      _ARG_0_.GreenPassPlayerKeys = U2.slua.Array(U2.UEnums.EPropertyClass.Int64)
      _ARG_0_.tVisitExpireTimers = {}
      _ARG_0_.MonsterSlots = {}
      _ARG_0_.NetMonsterIdArray = U2.slua.Array(U2.UEnums.EPropertyClass.Struct, U2.import((_ENV(43, 132, 58, 125, 113, 97, 97, 23))))
      _ARG_0_.NetMonsterStarArray = U2.slua.Array(U2.UEnums.EPropertyClass.Struct, U2.import((_ENV(43, 132, 58, 125, 113, 97, 97, 23))))
      _ARG_0_.BoxCollisionSteal = nil
      _ARG_0_.BoxCollisionLock = nil
      _ARG_0_.BoxCollisionLock2 = nil
      _ARG_0_.BoxCollisionDoor = nil
      _ARG_0_.BoxCollisionDoor2 = nil
      _ARG_0_.BoxCollisionSecondFloor = nil
      _ARG_0_.bClientLocalPlayerOnSecondFloor = false
      _ARG_0_.Widget = nil
      _ARG_0_.DoorActor1 = nil
      _ARG_0_.DoorActor2 = nil
      _ARG_0_.DoorsState = U3.Invalid
      _ARG_0_.nUnlockTime = 0
      _ARG_0_.nLastForceUnlockServerTime = 0
      _ARG_0_.nInitialProtectUntilTime = 0
      _ARG_0_.CoinProductionTimer = nil
      _ARG_0_.UnlockCountdownTimer = nil
      _ARG_0_.ClientRemainingTime = 0
      _ARG_0_.BaseScreenMarkID = nil
      _ARG_0_.SlotCoinStates = U2.slua.Array(U2.UEnums.EPropertyClass.Int)
      _ARG_0_.SlotCollectVersions = U2.slua.Array(U2.UEnums.EPropertyClass.Int)
      _ARG_0_.CoinSlotMgr = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLifetimeReplicatedProps"] = function(_ARG_0_)
    do
      do return {
        {
          U1(19, 174, 46, 103, 123, 97, 3, 63, 159, 89, 40, 20, 18, 133, 241),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Int64
        },
        {
          U1(50, 150, 55, 108, 108, 67, 63, 50, 135, 69, 63, 40, 56, 141, 237),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Str
        },
        {
          U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 85, 35, 18),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Int
        },
        {
          U1(46, 141, 54, 125, 93, 124, 38, 61, 138),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Int
        },
        {
          U1(63, 128, 42, 108, 82, 118, 37, 54, 146),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Int
        },
        {
          U1(46, 138, 48, 103, 87, 87),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Int
        },
        {
          U1(57, 142, 54, 123, 109, 64, 39, 50, 138, 69),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Int
        },
        {
          U1(57, 142, 54, 123, 95, 112, 39, 60, 140, 17),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Object
        },
        {
          U1(57, 142, 54, 123, 95, 112, 39, 60, 140, 18),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Object
        },
        {
          U1(19, 180, 55, 101, 113, 112, 56, 7, 151, 77, 40),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Float
        },
        {
          U1(51, 132, 45, 68, 113, 125, 32, 39, 155, 82, 4, 2, 24, 146, 250, 100, 244),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Array,
          import((U1(43, 132, 58, 125, 113, 97, 97, 23)))
        },
        {
          U1(51, 132, 45, 68, 113, 125, 32, 39, 155, 82, 30, 18, 56, 146, 201, 119, 255, 176, 80),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Array,
          import((U1(43, 132, 58, 125, 113, 97, 97, 23)))
        },
        {
          U1(58, 147, 60, 108, 112, 67, 50, 32, 141, 112, 33, 7, 32, 133, 250, 78, 232, 168, 90),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Array,
          UEnums.EPropertyClass.Int64
        },
        {
          U1(52, 143, 63, 123, 127, 97, 54, 55, 191, 76, 44, 20, 52, 162, 253, 99, 235, 130, 93, 88, 154, 70),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Int
        },
        {
          U1(46, 141, 54, 125, 93, 124, 58, 61, 173, 84, 44, 18, 60, 147),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Array,
          UEnums.EPropertyClass.Int
        },
        {
          U1(46, 141, 54, 125, 93, 124, 63, 63, 155, 67, 57, 48, 60, 146, 251, 108, 226, 191, 90),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Array,
          UEnums.EPropertyClass.Int
        },
        {
          U1(47, 132, 59, 96, 108, 103, 59, 31, 155, 86, 40, 10),
          import((U1(56, 173, 48, 111, 123, 103, 58, 62, 155, 99, 34, 8, 61, 137, 252, 108, 226, 191))).COND_None,
          UEnums.EPropertyClass.Int
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveBeginPlay"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 15, 19, 42, 149, 241, 99, 248, 131, 92, 78, 151, 93, 99, 31),
        U1(28, 152)
      }))
      U2.__super.ReceiveBeginPlay(_ARG_0_)
      _ARG_0_:InitComponents()
      _ARG_0_.CoinSlotMgr = U3.New(_ARG_0_.Object)
      _ARG_0_.CoinSlotMgr:OnBeginPlay()
      _ARG_0_:CreateDoors()
      _ARG_0_:ResetToEmptyBase()
      if not Client then
        _ARG_0_:BindCollisionEvents()
        _ARG_0_:StartCoinProductionTimer()
        _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_AI_STARTGAME_AISERVER_SUCCESS, _ARG_0_.UpdateAllAIPerceptionInfo, _ARG_0_)
      else
        _ARG_0_:ClientBindCollisionEvents()
        _ARG_0_:UpdateBuildingMesh()
        _ARG_0_:UpdateBaseOwnerInfoUI()
        _ARG_0_:UpdateLockAreaUI()
        _ARG_0_:UpdateStealAreaUI()
        _ARG_0_:UpdateBaseTitleWidgetCullDistance()
        _ARG_0_:_ApplyClientParticleFXCullDistance()
        _ARG_0_:UpdateBaseScreenMark()
        if _ARG_0_.nOwnerPlayerKey and _ARG_0_.nOwnerPlayerKey > 0 then
          _ARG_0_:ClientControlGreenPass(_ARG_0_.DoorActor1)
          _ARG_0_:ClientControlGreenPass(_ARG_0_.DoorActor2)
        end
        if _ARG_0_.DoorsState == U4.Locked and _ARG_0_.nUnlockTime and 0 < _ARG_0_.nUnlockTime then
          _ARG_0_.ClientRemainingTime = _ARG_0_:_ClientCalcRemainingTime()
          print(bWriteLog and string.format(table.concat({
            U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 15, 19, 42, 149, 241, 99, 248, 131, 92, 78, 151, 93, 99, 31),
            U1(28, 152, 121, 36, 62, 87, 60, 60, 140, 0, 44, 10, 43, 133, 233, 97, 244, 241, 69, 86, 141, 72, 70, 7, 206, 95, 51, 86, 35, 159, 241, 123, 177, 225, 74, 93, 159, 65, 71, 26),
            U1(19, 134, 121, 106, 113, 102, 61, 39, 154, 79, 58, 8, 121, 134, 250, 106, 224, 241, 12, 23, 220, 69)
          }), _ARG_0_.ClientRemainingTime))
          _ARG_0_:StartUnlockCountdownTimer()
        elseif _ARG_0_.DoorsState == U4.Locked then
          _ARG_0_.ClientRemainingTime = 0
          _ARG_0_:UpdateUnlockTimeUI()
        else
        end
        _ARG_0_:UpdateSlotVisibility()
        _ARG_0_:ClientBindSecondFloorCollision()
        _ARG_0_:SetSecondFloorSlotsVisible(false)
        _ARG_0_:UpdateSecondFloor()
      end
      _ARG_0_:UpdateStairsCoverCollision()
      _ARG_0_:RefreshMonsterGalleryUnlockState()
      if Client then
        _ARG_0_:_StartGalleryUnlockRetryTimer()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetRebirthLevel"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      _ARG_1_ = tonumber(_ARG_1_) or 0
      if _ARG_1_ < 0 then
        _ARG_1_ = 0
      end
      if (_ARG_0_.RebirthLevel or 0) == _ARG_1_ then
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 19, 61, 162, 253, 119, 244, 179, 77, 65, 178, 86, 69, 22),
          U1(17, 193, 116, 41, 107, 125, 48, 59, 159, 78, 42, 3, 61, 187, 173, 97, 208, 253, 9, 74, 133, 74, 83)
        }), _ARG_1_))
        return
      end
      _ARG_0_.RebirthLevel = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_RebirthLevel"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 207, 164, 91, 64, 140, 71, 91, 63),
        U1(24, 151, 60, 101, 62, 62, 115, 29, 155, 87, 22, 67, 61, 189, 168, 74, 250, 191, 76, 75, 190, 79, 66, 26, 139, 66, 22, 19, 48, 171, 189, 113, 192)
      }), _ARG_0_.RebirthLevel or 0, _ARG_0_.nOwnerPlayerKey or 0))
      _ARG_0_:RefreshMonsterGalleryUnlockState()
      if Client and slua.isValid((slua_GameFrontendHUD:GetPlayerController())) and slua_GameFrontendHUD:GetPlayerController().PlayerKey and _ARG_0_.nOwnerPlayerKey and _ARG_0_.nOwnerPlayerKey == slua_GameFrontendHUD:GetPlayerController().PlayerKey and slua_GameFrontendHUD:GetPlayerController().PlayerRebirthFeature and slua_GameFrontendHUD:GetPlayerController().PlayerRebirthFeature.SetRebirthLevel and slua_GameFrontendHUD:GetPlayerController().PlayerRebirthFeature.GetRebirthLevel and (_ARG_0_.RebirthLevel or 0) > (slua_GameFrontendHUD:GetPlayerController().PlayerRebirthFeature:GetRebirthLevel() or 0) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SyncRebirthLevelFromFeature"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if type(_ARG_0_.nOwnerPlayerKey) ~= U1(19, 148, 52, 107, 123, 97) or _ARG_0_.nOwnerPlayerKey <= 0 then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 2, 37, 48, 158, 251, 71, 248, 163, 80, 91, 138, 91, 127, 22),
          U1(11, 132, 53, 79, 108, 124, 62, 21, 155, 65, 57, 19, 43, 133, 168, 40, 173, 191, 70, 25, 129, 84, 77, 6, 156, 16, 36, 19, 61, 220, 184, 102, 246, 168, 73)
        }))
        return
      end
      if not slua.isValid((require((U1(58, 128, 52, 108, 82, 102, 50, 125, 185, 65, 32, 3, 26, 143, 250, 96, 163, 149, 72, 77, 143, 13, 100, 2, 131, 85, 45, 26, 40, 137, 220, 116, 233, 160))).GetPlayerController(_ARG_0_.nOwnerPlayerKey))) or not require((U1(58, 128, 52, 108, 82, 102, 50, 125, 185, 65, 32, 3, 26, 143, 250, 96, 163, 149, 72, 77, 143, 13, 100, 2, 131, 85, 45, 26, 40, 137, 220, 116, 233, 160))).GetPlayerController(_ARG_0_.nOwnerPlayerKey).PlayerRebirthFeature then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshMonsterGalleryUnlockState"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if (_ARG_0_.RebirthLevel or 0) >= ((require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 100, 145, 93, 64, 7),
        U1(24, 147, 26, 102, 112, 117, 58, 52)
      }))).MonsterGalleryUnlockLevelByIndex or {})[U1(24, 147, 26, 102, 112, 117, 58, 52)] or 0) then
        goto lbl_86
        goto lbl_87
        ::lbl_86::
        _ARG_0_ = _ARG_0_
      end
      ::lbl_87::
      if U1(24, 147, 26, 102, 112, 117, 58, 52) < 1 then
      end
      if (require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 100, 145, 93, 64, 7),
        U1(24, 147, 26, 102, 112, 117, 58, 52)
      }))).MonsterGalleryMaxUnlockCount or 4) < 1 then
      end
      _ARG_0_ = _ARG_0_
      if ({
        U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153),
        U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 186),
        U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 187),
        (U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 188))
      })[48] then
        if slua.isValid(_ARG_0_[({
          U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153),
          U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 186),
          U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 187),
          (U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 188))
        })[48]]) then
          if slua.isValid(_ARG_0_[({
            U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153),
            U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 186),
            U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 187),
            (U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 188))
          })[48]].ChildActor) then
            if (require((table.concat({
              U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 100, 145, 93, 64, 7),
              U1(24, 147, 26, 102, 112, 117, 58, 52)
            }))).MonsterGalleryMaxUnlockCount or 4) >= 48 and _ARG_0_[({
              U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153),
              U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 186),
              U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 187),
              (U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 188))
            })[48]].ChildActor._ApplyGalleryProductionRatio and 0 < (_ARG_0_[({
              U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153),
              U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 186),
              U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 187),
              (U1(48, 142, 55, 122, 106, 118, 33, 20, 159, 76, 33, 3, 43, 153, 188))
            })[48]].ChildActor.MonsterID or 0) then
            end
          else
          end
        else
        end
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_StartGalleryUnlockRetryTimer"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      _ARG_0_:_StopGalleryUnlockRetryTimer()
      _ARG_0_.GalleryUnlockRetryCount = 0
      _ARG_0_.GalleryUnlockRetryTimer = _ARG_0_:AddGameTimer(0.5, true, function()
        GalleryUnlockRetryCount = (GalleryUnlockRetryCount or 0) + 1
        if not U1.slua.isValid(Object) then
          _ENV:_StopGalleryUnlockRetryTimer()
          return
        end
        _ENV:RefreshMonsterGalleryUnlockState()
        if 0 < (RebirthLevel or 0) then
          return
        end
        if GalleryUnlockRetryCount >= U3 then
          return
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_StopGalleryUnlockRetryTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.GalleryUnlockRetryTimer then
        _ARG_0_:RemoveGameTimer(_ARG_0_.GalleryUnlockRetryTimer)
        _ARG_0_.GalleryUnlockRetryTimer = nil
      end
      _ARG_0_.GalleryUnlockRetryCount = 0
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddMonster"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return false
      end
      if not slua.isValid(_ARG_1_) then
        print(bWriteLog and string.format((table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 28, 18, 45, 189, 247, 123, 238, 181, 92, 91, 222, 30, 19, 26),
          U1(19, 151, 56, 101, 119, 119, 115, 38, 179, 79, 35, 21, 45, 133, 250, 68, 238, 165, 70, 75)
        }))))
        return false
      end
      if _ARG_2_ == nil then
      end
      if not true then
        if not _ARG_0_:IsValidSlotIndex(_ARG_2_) then
          return false
        end
        if not _ARG_0_.MonsterSlots[_ARG_2_] then
          return false
        end
        if slua.isValid(_ARG_0_.MonsterSlots[_ARG_2_].Monster) then
          return false
        end
        _ARG_0_.MonsterSlots[_ARG_2_].Monster = _ARG_1_
        return true, _ARG_2_
      else
        if not _ARG_0_:GetAvailableSlotIndex() then
          return false
        end
        _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Monster = _ARG_1_
        return true, (_ARG_0_:GetAvailableSlotIndex())
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1[108]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PlaceMonsterAtSlot"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) or not _ARG_2_ then
        return
      end
      _ARG_1_.SlotIndex = _ARG_2_.Index
      if not slua.isValid(_ARG_2_.Mesh) then
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 2, 38, 37, 145, 251, 112, 208, 174, 87, 90, 138, 86, 65, 50),
          U1(9, 178, 53, 102, 106, 51, 126, 115, 173, 76, 34, 18, 2, 197, 236, 88, 173, 188, 76, 74, 134, 3, 74, 13, 152, 81, 49, 31, 45)
        }), _ARG_2_.Index or 0))
        return
      end
      if not _ARG_2_.Mesh:K2_GetComponentToWorld() then
        return
      end
      if not _ARG_2_.Mesh:K2_GetComponentToWorld():GetLocation() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoveMonster"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return false
      end
      if _ARG_2_ ~= nil then
      end
      if _ARG_1_ < 1 or _ARG_1_ > _ARG_0_.SlotCount then
        return false
      end
      if not _ARG_0_.MonsterSlots[_ARG_1_] then
        return false
      end
      if not slua.isValid(_ARG_0_.MonsterSlots[_ARG_1_].Monster) then
        return false
      end
      if 0 > (tonumber(_ARG_0_.MonsterSlots[_ARG_1_].Monster.StarLevel) or 0) then
      end
      if _ARG_2_ then
      end
      _ARG_0_.MonsterSlots[_ARG_1_].Monster = nil
      do return true, _ARG_1_, 0 end
      do return end
      _ARG_0_ = U1[55]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateNetMonsterIdArray"] = function(_ARG_0_)
    do
      _ARG_0_.NetMonsterIdArray:Clear()
      _ARG_0_.NetMonsterStarArray:Clear()
      goto lbl_36
      ::lbl_36::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 211, 164, 77, 100, 145, 93, 64, 7),
        U1(24, 147, 16, 109, 95, 97, 33, 50, 135, 0, 3, 19, 52, 187, 173, 97, 208)
      }), _ARG_0_.NetMonsterIdArray:Num()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HasMonster"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        goto lbl_20
        if slua.isValid((nil).Monster) and (nil).Monster.MonsterID == _ARG_1_ then
          return true
        end
        ::lbl_20::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        return false
      else
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 21, 23, 58, 189, 247, 123, 238, 181, 92, 91, 222, 30, 19, 29),
          U1(48, 142, 55, 122, 106, 118, 33, 26, 186, 123, 104, 2, 4, 192, 198, 96, 249, 156, 70, 87, 157, 87, 70, 17, 167, 84, 28, 4, 59, 145, 225, 78, 184, 165, 100)
        }), _ARG_1_, _ARG_0_.NetMonsterIdArray:Num()))
        goto lbl_217
        if math.floor(_ARG_0_.NetMonsterIdArray:Num().Y) == _ARG_1_ then
          return true
        end
        ::lbl_217::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_SkinID"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 206, 170, 80, 71, 183, 119, 19, 0),
        U1(24, 141, 63, 39, 77, 120, 58, 61, 183, 100, 22, 67, 61, 189)
      }), _ARG_0_.SkinID))
      _ARG_0_:UpdateBuildingMesh()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_NetMonsterIdArray"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 211, 164, 77, 100, 145, 93, 64, 7),
        U1(24, 147, 16, 109, 95, 97, 33, 50, 135, 0, 3, 19, 52, 187, 173, 97, 208)
      }), _ARG_0_.NetMonsterIdArray:Num()))
      if _ARG_0_.CoinSlotMgr then
        _ARG_0_.CoinSlotMgr:OnRep_NetMonsterIdArray()
      end
      EventSystem:postEvent(EVENTTYPE_PLANBT_NORMAL, EVENTID_MONSTER_BASE_NET_MONSTER_ID_ARRAY_CHANGED)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_NetMonsterStarArray"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 211, 164, 77, 100, 145, 93, 64, 7),
        U1(24, 147, 10, 125, 127, 97, 18, 33, 140, 65, 52, 70, 23, 149, 229, 94, 168, 181, 116)
      }), _ARG_0_.NetMonsterStarArray:Num()))
      if _ARG_0_.CoinSlotMgr then
        _ARG_0_.CoinSlotMgr:OnRep_NetMonsterIdArray()
      end
      EventSystem:postEvent(EVENTTYPE_PLANBT_NORMAL, EVENTID_MONSTER_BASE_NET_MONSTER_ID_ARRAY_CHANGED)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_RebirthCount"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 207, 164, 91, 64, 140, 71, 91, 48),
        U1(18, 148, 55, 125, 62, 62, 115, 28, 146, 68, 27, 7, 53, 149, 237, 94, 168, 162, 116, 21, 206, 109, 70, 20, 184, 81, 49, 3, 44, 171, 189, 113, 192)
      }), tostring(_ARG_1_), _ARG_0_.RebirthCount))
      if not CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.RebirthCount) then
        return
      end
      if _ARG_0_.BaseLevel ~= CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.RebirthCount).BasementLevel then
        _ARG_0_.BaseLevel = CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.RebirthCount).BasementLevel
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_nOwnerPlayerKey"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      if slua.isValid((U1.GetPlayerCharacter())) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientControlGreenPass"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        print(bWriteLog and string.format((table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 26, 32, 149, 246, 97, 222, 174, 87, 93, 140, 92, 95, 52),
          U1(15, 132, 60, 103, 78, 114, 32, 32, 222, 13, 109, 15, 55, 150, 233, 105, 228, 181, 9, 76, 170, 76, 76, 17, 175, 83, 41, 25, 59)
        }))))
        return
      end
      if not _ARG_1_.AddOrDeleteGreenPass then
        print(bWriteLog and string.format((table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 26, 32, 149, 246, 97, 222, 174, 87, 93, 140, 92, 95, 52),
          U1(15, 132, 60, 103, 78, 114, 32, 32, 222, 13, 109, 15, 55, 150, 233, 105, 228, 181, 9, 76, 170, 76, 76, 17, 175, 83, 41, 25, 59, 222, 217, 113, 249, 142, 75, 109, 155, 95, 86, 7),
          U1(24, 166, 43, 108, 123, 125, 3, 50, 141, 83)
        }))))
        return
      end
      if _ARG_0_.nOwnerPlayerKey <= 0 then
        print(bWriteLog and string.format((table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 26, 32, 149, 246, 97, 222, 174, 87, 93, 140, 92, 95, 52),
          U1(15, 132, 60, 103, 78, 114, 32, 32, 222, 13, 109, 8, 54, 192, 231, 114, 227, 180, 91)
        }))))
        return
      end
      if slua.isValid((U2.GetPlayerCharacter())) then
        if U2.GetPlayerCharacter().PlayerKey == _ARG_0_.nOwnerPlayerKey or _ARG_0_:_IsPlayerInGreenPassList(U2.GetPlayerCharacter().PlayerKey) then
        else
        end
      else
      end
      if _ARG_0_.GreenPassPlayerKeys then
        _ARG_0_ = _ARG_0_
        if slua.isValid((U2.GetPlayerCharacter((_ARG_0_.GreenPassPlayerKeys:Get({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 26, 32, 149, 246, 97, 222, 174, 87, 93, 140, 92, 95, 52),
          U1(15, 132, 60, 103, 78, 114, 32, 32, 222, 13, 109, 19, 21, 143, 235, 100, 225, 146, 65, 88, 156, 66, 64, 23, 139, 66, 125, 24, 38, 132, 184, 103, 248, 160, 93, 80, 222, 74, 86, 7)
        }))))) and U2.GetPlayerCharacter((_ARG_0_.GreenPassPlayerKeys:Get({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 26, 32, 149, 246, 97, 222, 174, 87, 93, 140, 92, 95, 52),
          U1(15, 132, 60, 103, 78, 114, 32, 32, 222, 13, 109, 19, 21, 143, 235, 100, 225, 146, 65, 88, 156, 66, 64, 23, 139, 66, 125, 24, 38, 132, 184, 103, 248, 160, 93, 80, 222, 74, 86, 7)
        }))) ~= U2.GetPlayerCharacter() then
        else
        end
        _ARG_0_ = _ARG_0_
      end
      if slua.isValid((U2.GetPlayerCharacter(_ARG_0_.nOwnerPlayerKey))) and U2.GetPlayerCharacter(_ARG_0_.nOwnerPlayerKey) ~= U2.GetPlayerCharacter() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_GreenPassPlayerKeys"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 218, 179, 92, 76, 144, 99, 82, 0),
        U1(14, 177, 53, 104, 103, 118, 33, 24, 155, 89, 62, 70, 116, 192, 207, 119, 232, 180, 71, 105, 143, 80, 80, 67, 130, 89, 46, 2, 105, 133, 232, 113, 252, 181, 92, 77, 210, 19, 80, 28),
        U1(8, 143, 45, 52, 59, 119)
      }), _ARG_0_.GreenPassPlayerKeys and _ARG_0_.GreenPassPlayerKeys:Num() or 0))
      if _ARG_1_ then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      _ARG_0_:ClientControlGreenPass(_ARG_0_.DoorActor1)
      _ARG_0_:ClientControlGreenPass(_ARG_0_.DoorActor2)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_IsPlayerInGreenPassList"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.GreenPassPlayerKeys then
        return false
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_.GreenPassPlayerKeys:Get(nil) == _ARG_1_ then
        return true
      end
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddGreenPassPlayer"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      if not _ARG_1_ or _ARG_1_ <= 0 then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 28, 18, 45, 183, 234, 112, 248, 175, 105, 72, 141, 64, 99, 31),
          U1(28, 152, 60, 123, 62, 62, 115, 26, 144, 86, 44, 10, 48, 132, 168, 107, 219, 184, 90, 80, 154, 76, 81, 51, 130, 81, 36, 19, 59, 187, 253, 108)
        }))
        return
      end
      if _ARG_0_:_IsPlayerInGreenPassList(_ARG_1_) then
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 28, 18, 45, 183, 234, 112, 248, 175, 105, 72, 141, 64, 99, 31),
          U1(28, 152, 60, 123, 62, 62, 115, 3, 146, 65, 52, 3, 43, 187, 173, 97, 208, 241, 72, 85, 156, 70, 66, 7, 151, 16, 52, 24, 105, 183, 234, 112, 248, 175, 105, 72, 141, 64, 19, 31),
          U1(20, 146, 45)
        }), _ARG_1_))
        return
      end
      _ARG_0_.GreenPassPlayerKeys:Add(_ARG_1_)
      if slua.isValid(_ARG_2_) then
        if slua.isValid(_ARG_0_.DoorActor1) then
          _ARG_0_.DoorActor1:AddOrDeleteGreenPass(_ARG_2_, true)
        end
        if slua.isValid(_ARG_0_.DoorActor2) then
          _ARG_0_.DoorActor2:AddOrDeleteGreenPass(_ARG_2_, true)
        end
      end
      if _ARG_0_.tVisitExpireTimers and _ARG_0_.tVisitExpireTimers[_ARG_1_] then
        _ARG_0_.tVisitExpireTimers[_ARG_1_] = nil
      end
      if not _ARG_0_.tVisitExpireTimers then
        _ARG_0_.tVisitExpireTimers = {}
      end
      _ARG_0_.tVisitExpireTimers[_ARG_1_] = _ARG_0_:AddGameTimer(require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 127, 151, 64, 90, 7),
        U1(63, 128, 42, 108, 93, 124, 61, 53, 151, 71)
      }))).VisitDurationSeconds or 300, false, function()
        if not slua.isValid(U1.Object) then
          return
        end
        print(bWriteLog and string.format(table.concat({
          U2(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 28, 18, 45, 183, 234, 112, 248, 175, 105, 72, 141, 64, 99, 31),
          U2(28, 152, 60, 123, 62, 62, 115, 5, 151, 83, 36, 18, 121, 132, 253, 119, 236, 165, 64, 86, 128, 3, 70, 27, 158, 89, 47, 19, 45, 208, 254, 122, 239, 225, 105, 69, 159, 74, 86, 1),
          U2(38, 196, 61, 84, 50, 51, 50, 38, 138, 79, 109, 20, 60, 150, 231, 110, 228, 191, 78, 25, 169, 81, 70, 6, 128, 96, 60, 5, 58)
        }), U3))
        U1:RemoveGreenPassPlayer(U3)
        return
      end)
      return
    end
  end,
  ["RemoveGreenPassPlayer"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not _ARG_1_ or _ARG_1_ <= 0 then
        return
      end
      if _ARG_0_.tVisitExpireTimers and _ARG_0_.tVisitExpireTimers[_ARG_1_] then
        _ARG_0_:RemoveGameTimer(_ARG_0_.tVisitExpireTimers[_ARG_1_])
        _ARG_0_.tVisitExpireTimers[_ARG_1_] = nil
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_.GreenPassPlayerKeys:Get(nil) == _ARG_1_ then
      else
        _ARG_0_ = _ARG_0_
      end
      if not true then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoveAllGreenPassPlayers"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.tVisitExpireTimers then
        goto lbl_17
        if nil then
        end
        ::lbl_17::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _ARG_0_.tVisitExpireTimers = {}
      end
      if not _ARG_0_.GreenPassPlayerKeys or _ARG_0_.GreenPassPlayerKeys:Num() == 0 then
        return
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_BaseLevel"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 223, 160, 74, 76, 178, 86, 69, 22),
        U1(17, 193, 116, 41, 81, 127, 55, 5, 159, 76, 56, 3, 2, 197, 251, 88, 161, 241, 103, 92, 153, 117, 66, 15, 155, 85, 6, 83, 45, 173)
      }), tostring(_ARG_1_), _ARG_0_.BaseLevel or 0))
      if Client then
        _ARG_0_:UpdateBuildingMesh()
        _ARG_0_:UpdateSecondFloor()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_SlotCount"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 206, 173, 86, 93, 189, 92, 70, 29),
        U1(9, 193, 116, 41, 81, 127, 55, 5, 159, 76, 56, 3, 2, 197, 251, 88, 161, 241, 103, 92, 153, 117, 66, 15, 155, 85, 6, 83, 45, 173)
      }), tostring(_ARG_1_), _ARG_0_.SlotCount or 0))
      if Client then
        _ARG_0_:UpdateSlotVisibility()
        if _ARG_0_.CoinSlotMgr then
          _ARG_0_.CoinSlotMgr:OnSlotCountChanged()
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRebirth"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_0_.OwnerCharacter) then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 250, 124, 239, 181, 81, 9, 211, 19, 122, 29),
          U1(11, 128, 53, 96, 122, 51, 28, 36, 144, 69, 63, 37, 49, 129, 250, 100, 238, 165, 76, 75)
        }))
        return false
      end
      if _ARG_0_.OwnerCharacter:GetEnsure() then
      else
      end
      if not slua.isValid((_ARG_0_.OwnerCharacter:GetPlayerControllerSafety())) then
        return false
      end
      if not CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount) then
        return false
      end
      if not CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).RebirthLevel or type(CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).RebirthLevel) ~= U1(19, 148, 52, 107, 123, 97) or CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).RebirthLevel < 0 then
        return false
      end
      if not CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).BasementLevel or type(CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).BasementLevel) ~= U1(19, 148, 52, 107, 123, 97) or 0 >= CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).BasementLevel then
        return false
      end
      if not CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).MonsterSpace or type(CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).MonsterSpace) ~= U1(19, 148, 52, 107, 123, 97) or 0 >= CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).MonsterSpace then
        return false
      end
      if not CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).BaseLockTime or type(CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).BaseLockTime) ~= U1(19, 148, 52, 107, 123, 97) or 0 > CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).BaseLockTime then
        return false
      end
      if not CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).MoneyReturnRatio_f or type(CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).MoneyReturnRatio_f) ~= U1(19, 148, 52, 107, 123, 97) or 0 > CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).MoneyReturnRatio_f then
        return false
      end
      _ARG_0_.RebirthCount = CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).RebirthLevel
      goto lbl_984
      ::lbl_984::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.BaseLevel = CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).BasementLevel
      if _ARG_0_.BaseLevel >= 2 and 0 < _ARG_0_.PendingAdditionSlotCount then
        _ARG_0_.PendingAdditionSlotCount = 0
        if _ARG_0_.PendingAdditionSlotCount > _ARG_0_.AdditionSlotCount then
          _ARG_0_.AdditionSlotCount = _ARG_0_.PendingAdditionSlotCount
          _ARG_0_.SlotCount = _ARG_0_.RebirthSlotCount + _ARG_0_.AdditionSlotCount
        end
      end
      _ARG_0_.DoorLockDuration = CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).BaseLockTime
      _ARG_0_.MoneyReturnRatio = CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).MoneyReturnRatio_f
      _ARG_0_.StartBudget = tonumber(CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().nRebirthCount).StartBudget) or 0
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearMonsterSlot"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:RemoveMonster(_ARG_1_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearCoinSlot"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.CoinSlotMgr then
        _ARG_0_.CoinSlotMgr:ResetSlot(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearSlots"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ConditionalSetSlotCount"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if (tonumber(_ARG_1_) or 0) > _ARG_0_.RebirthSlotCount then
        _ARG_0_.RebirthSlotCount = tonumber(_ARG_1_) or 0
      end
      if 0 < (tonumber(_ARG_2_) or 0) then
        if 2 <= (_ARG_0_.BaseLevel or 1) then
          if (tonumber(_ARG_2_) or 0) > _ARG_0_.AdditionSlotCount then
            _ARG_0_.AdditionSlotCount = tonumber(_ARG_2_) or 0
          end
        elseif (tonumber(_ARG_2_) or 0) > _ARG_0_.PendingAdditionSlotCount then
          _ARG_0_.PendingAdditionSlotCount = tonumber(_ARG_2_) or 0
        end
      end
      _ARG_0_.SlotCount = _ARG_0_.RebirthSlotCount + _ARG_0_.AdditionSlotCount
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSlotCount"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 19, 61, 163, 244, 122, 233, 130, 86, 92, 144, 71, 19, 94),
        U1(93, 168, 55, 91, 123, 113, 58, 33, 138, 72, 22, 67, 42, 189, 168, 76, 227, 144, 77, 93, 135, 87, 74, 12, 128, 107, 120, 5, 20)
      }), tostring(_ARG_1_), tostring(_ARG_2_)))
      _ARG_0_.AdditionSlotCount, _ARG_0_.RebirthSlotCount = tonumber(_ARG_2_) or 0, tonumber(_ARG_1_) or 10, tonumber(_ARG_2_) or 0
      _ARG_0_.SlotCount = _ARG_0_.RebirthSlotCount + _ARG_0_.AdditionSlotCount
      do return end
      _ARG_2_ = U1[136]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateSlotVisibility"] = function(_ARG_0_)
    do
      if not _ARG_0_.BaseLevel or type(_ARG_0_.BaseLevel) ~= U1(19, 148, 52, 107, 123, 97) or _ARG_0_.BaseLevel <= 0 then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 206, 173, 86, 93, 168, 90, 64, 26),
        U1(31, 136, 53, 96, 106, 106, 115, 126, 222, 98, 44, 21, 60, 172, 237, 115, 232, 189, 114, 28, 138, 126, 15, 67, 184, 89, 46, 31, 43, 156, 253, 70, 241, 174, 77, 90, 165, 22, 87, 46)
      }), _ARG_0_.BaseLevel, _ARG_0_.SlotCount))
      _ARG_0_ = _ARG_0_
      if _ARG_0_.MonsterSlots[_ARG_0_.SlotCount] and _ARG_0_.MonsterSlots[_ARG_0_.SlotCount].Mesh and slua.isValid(_ARG_0_.MonsterSlots[_ARG_0_.SlotCount].Mesh) then
        if Client and not (_ARG_0_.SlotCount > _ARG_0_.SlotCount) and _ARG_0_.SlotCount >= (U2.SecondFloorSlotStartIndex or 11) and not _ARG_0_.bClientLocalPlayerOnSecondFloor then
        end
      end
      if _ARG_0_.CoinSlotMgr then
        if Client and not (_ARG_0_.SlotCount > _ARG_0_.SlotCount) and _ARG_0_.SlotCount >= (U2.SecondFloorSlotStartIndex or 11) and not _ARG_0_.bClientLocalPlayerOnSecondFloor then
        end
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetSlotCullDistanceByDeviceLevel"] = function(_ARG_0_)
    do
      do return GetCullDistance() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetInfraredAlarmFXCullDistanceByDeviceLevel"] = function(_ARG_0_)
    do
      if not Client then
        return nil
      end
      if not U1.InfraredAlarmFXCullDistanceByDeviceLevel then
        return nil
      end
      if not slua.isValid((import((U2(46, 181, 28, 113, 106, 97, 50, 20, 159, 77, 40, 47, 55, 147, 252, 100, 227, 178, 76))).GetInstance())) then
        return nil
      end
      if not (U1.InfraredAlarmFXCullDistanceByDeviceLevel[import((U2(46, 181, 28, 113, 106, 97, 50, 20, 159, 77, 40, 47, 55, 147, 252, 100, 227, 178, 76))).GetInstance():GetExactDeviceLevel() or 1] or U1.InfraredAlarmFXCullDistanceByDeviceLevel[1]) or (U1.InfraredAlarmFXCullDistanceByDeviceLevel[import((U2(46, 181, 28, 113, 106, 97, 50, 20, 159, 77, 40, 47, 55, 147, 252, 100, 227, 178, 76))).GetInstance():GetExactDeviceLevel() or 1] or U1.InfraredAlarmFXCullDistanceByDeviceLevel[1]) <= 0 then
        return nil
      end
      do return U1.InfraredAlarmFXCullDistanceByDeviceLevel[import((U2(46, 181, 28, 113, 106, 97, 50, 20, 159, 77, 40, 47, 55, 147, 252, 100, 227, 178, 76))).GetInstance():GetExactDeviceLevel() or 1] or U1.InfraredAlarmFXCullDistanceByDeviceLevel[1] end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetDoorFXCullDistanceByDeviceLevel"] = function(_ARG_0_)
    do
      if not Client then
        return nil
      end
      if not U1.DoorFXCullDistanceByDeviceLevel then
        return nil
      end
      if not slua.isValid((import((U2(46, 181, 28, 113, 106, 97, 50, 20, 159, 77, 40, 47, 55, 147, 252, 100, 227, 178, 76))).GetInstance())) then
        return nil
      end
      if not (U1.DoorFXCullDistanceByDeviceLevel[import((U2(46, 181, 28, 113, 106, 97, 50, 20, 159, 77, 40, 47, 55, 147, 252, 100, 227, 178, 76))).GetInstance():GetExactDeviceLevel() or 1] or U1.DoorFXCullDistanceByDeviceLevel[1]) or (U1.DoorFXCullDistanceByDeviceLevel[import((U2(46, 181, 28, 113, 106, 97, 50, 20, 159, 77, 40, 47, 55, 147, 252, 100, 227, 178, 76))).GetInstance():GetExactDeviceLevel() or 1] or U1.DoorFXCullDistanceByDeviceLevel[1]) <= 0 then
        return nil
      end
      do return U1.DoorFXCullDistanceByDeviceLevel[import((U2(46, 181, 28, 113, 106, 97, 50, 20, 159, 77, 40, 47, 55, 147, 252, 100, 227, 178, 76))).GetInstance():GetExactDeviceLevel() or 1] or U1.DoorFXCullDistanceByDeviceLevel[1] end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ApplyClientParticleFXCullDistance"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if _ARG_0_._bParticleFXCullApplied then
        return
      end
      _ARG_0_._bParticleFXCullApplied = true
      if _ARG_0_:_GetDoorFXCullDistanceByDeviceLevel() and _ARG_0_:_GetDoorFXCullDistanceByDeviceLevel() > 0 then
      end
      if slua.isValid(_ARG_0_.P_PlanBT_UgcBillboard_Lock_01_L3) then
        _ARG_0_.uLockBillboardFX = _ARG_0_.P_PlanBT_UgcBillboard_Lock_01_L3
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitComponents"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if _ARG_0_[string.format(U1(48, 132, 42, 97, 83, 124, 61, 32, 138, 69, 63, 53, 53, 143, 252, 32, 189, 227, 77), nil)] and slua.isValid(_ARG_0_[string.format(U1(48, 132, 42, 97, 83, 124, 61, 32, 138, 69, 63, 53, 53, 143, 252, 32, 189, 227, 77), nil)]) then
      end
      _ARG_0_.MonsterSlots[nil] = {
        Mesh = _ARG_0_[string.format(U1(48, 132, 42, 97, 83, 124, 61, 32, 138, 69, 63, 53, 53, 143, 252, 32, 189, 227, 77), nil)],
        Monster = nil,
        Index = nil
      }
      if _ARG_0_[string.format(U1(48, 132, 42, 97, 83, 124, 61, 32, 138, 69, 63, 53, 53, 143, 252, 32, 189, 227, 77), nil)] then
        if Client and _ARG_0_:_GetSlotCullDistanceByDeviceLevel() or nil then
        end
      else
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_.BoxCollisionSteal and slua.isValid(_ARG_0_.BoxCollisionSteal) then
      else
      end
      if _ARG_0_.BoxCollisionLock and slua.isValid(_ARG_0_.BoxCollisionLock) then
      else
      end
      if _ARG_0_.BoxCollisionLock2 and slua.isValid(_ARG_0_.BoxCollisionLock2) then
      else
      end
      if _ARG_0_.BoxCollisionDoor and slua.isValid(_ARG_0_.BoxCollisionDoor) then
      else
      end
      if _ARG_0_.BoxCollisionDoor2 and slua.isValid(_ARG_0_.BoxCollisionDoor2) then
      else
      end
      if _ARG_0_.BoxCollisionSecondFloor and slua.isValid(_ARG_0_.BoxCollisionSecondFloor) then
      else
      end
      if _ARG_0_.Widget and slua.isValid(_ARG_0_.Widget) then
      else
      end
      do return end
      _ARG_0_ = BoxCollisionLock2
    end
  end,
  ["BindCollisionEvents"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.BoxCollisionSteal and slua.isValid(_ARG_0_.BoxCollisionSteal) then
        _ARG_0_:AddControlEvent(_ARG_0_.BoxCollisionSteal, U1(50, 143, 26, 102, 115, 99, 60, 61, 155, 78, 57, 36, 60, 135, 225, 107, 194, 167, 76, 75, 130, 66, 83), _ARG_0_.OnStealAreaBeginOverlap, _ARG_0_)
      end
      if _ARG_0_.BoxCollisionLock and slua.isValid(_ARG_0_.BoxCollisionLock) then
        _ARG_0_:AddControlEvent(_ARG_0_.BoxCollisionLock, U1(50, 143, 26, 102, 115, 99, 60, 61, 155, 78, 57, 36, 60, 135, 225, 107, 194, 167, 76, 75, 130, 66, 83), _ARG_0_.OnLockAreaBeginOverlap, _ARG_0_)
      end
      if _ARG_0_.BoxCollisionLock2 and slua.isValid(_ARG_0_.BoxCollisionLock2) then
        _ARG_0_:AddControlEvent(_ARG_0_.BoxCollisionLock2, U1(50, 143, 26, 102, 115, 99, 60, 61, 155, 78, 57, 36, 60, 135, 225, 107, 194, 167, 76, 75, 130, 66, 83), _ARG_0_.OnLockAreaBeginOverlap, _ARG_0_)
      end
      if slua.isValid(_ARG_0_.PlayAreaComponent) then
        _ARG_0_:AddControlEvent(_ARG_0_.PlayAreaComponent, U1(50, 143, 26, 102, 115, 99, 60, 61, 155, 78, 57, 36, 60, 135, 225, 107, 194, 167, 76, 75, 130, 66, 83), _ARG_0_.OnPlayAreaBeginOverlapFunc, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_.PlayAreaComponent, U1(50, 143, 26, 102, 115, 99, 60, 61, 155, 78, 57, 35, 55, 132, 199, 115, 232, 163, 69, 88, 158), _ARG_0_.OnPlayAreaEndOverlapFunc, _ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientBindCollisionEvents"] = function(_ARG_0_)
    do
      if (require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 122, 130, 74, 70, 13, 154, 30, 30, 25, 39, 150, 241, 114, 179, 145, 85, 72, 144, 113, 103, 63),
        U1(18, 130, 56, 101, 77, 114, 37, 54)
      }))).GetValue(require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 122, 130, 74, 70, 13, 154, 30, 30, 25, 39, 150, 241, 114, 179, 145, 85, 72, 144, 113, 103, 63),
        U1(18, 130, 56, 101, 77, 114, 37, 54)
      }))).Keys.RecallGuideCount) or 0) >= require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 122, 130, 74, 70, 13, 154, 30, 30, 25, 39, 150, 241, 114, 179, 145, 85, 72, 144, 113, 103, 63),
        U1(18, 130, 56, 101, 77, 114, 37, 54)
      }))).Configs.RECALL_GUIDE_MAX_COUNT then
        return
      end
      _ARG_0_.bClientLocalPlayerInArea = false
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnStealAreaBeginOverlap"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_2_) then
        return
      end
      if not Game:IsClassOf(_ARG_2_, U1) then
        return
      end
      if not _ARG_0_.nOwnerPlayerKey or type(_ARG_0_.nOwnerPlayerKey) ~= U2(19, 148, 52, 107, 123, 97) or _ARG_0_.nOwnerPlayerKey <= 0 then
        return
      end
      if _ARG_0_.nOwnerPlayerKey ~= _ARG_2_.PlayerKey then
        return
      end
      if not _ARG_2_.GetStealingMonster then
        return
      end
      if not slua.isValid((_ARG_2_:GetStealingMonster())) then
        return
      end
      if _ARG_2_:GetStealingMonster().State ~= U3.EState.BeingStolen then
        return
      end
      if (slua.isValid((_ARG_2_:GetControllerSafety())) and _ARG_2_:GetControllerSafety().MonsterWarehouseFeature or nil) and (slua.isValid((_ARG_2_:GetControllerSafety())) and _ARG_2_:GetControllerSafety().MonsterWarehouseFeature or nil):IsWarehouseFull() then
        return
      end
      if not _ARG_0_:GetAvailableSlotIndex() then
        if _ARG_2_.PlayerKey then
        end
        return
      end
      if not _ARG_2_:GetStealingMonster():OnStealSuccess(_ARG_2_, (_ARG_0_:GetAvailableSlotIndex())) then
        return
      end
      if _ARG_2_.PlayerKey then
        if slua.isValid((_ARG_2_:GetControllerSafety())) and _ARG_2_:GetControllerSafety().ClientRPC_OnGetMonster then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_TryHandleGiftDelivery"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_1_.GetHoldingMonster then
        return
      end
      if not slua.isValid((_ARG_1_:GetHoldingMonster())) then
        return
      end
      if _ARG_1_:GetHoldingMonster().State ~= U1.EState.BeingHeld then
        return
      end
      if not _ARG_1_.GiveGiftFeature then
        return
      end
      if U3.Gift.CooldownDuration > 0 and 0 < _ARG_1_.GiveGiftFeature:GetRemainingCooldown() then
        return
      end
      if _ARG_1_:GetHoldingMonster():OnGiftDelivered(_ARG_0_.Object) and U3.Gift.CooldownDuration > 0 then
      elseif not _ARG_1_:GetHoldingMonster():OnGiftDelivered(_ARG_0_.Object) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnStealAreaEndOverlap"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if Client then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLockAreaBeginOverlap"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if Client then
        return
      end
      if not Game:IsClassOf(_ARG_2_, U1) then
        return
      end
      if _ARG_0_.OwnerCharacter ~= _ARG_2_ then
        return
      end
      if CGameState:GetServerWorldTimeSeconds() < _ARG_0_.nUnlockTime then
        if _ARG_0_.OwnerCharacter.PlayerKey and type(_ARG_0_.OwnerCharacter.PlayerKey) == U2(19, 148, 52, 107, 123, 97) and _ARG_0_.OwnerCharacter.PlayerKey > 0 then
        end
        return
      end
      if SubsystemMgr:Get((U2(63, 142, 42, 122, 76, 124, 60, 62, 173, 85, 47, 21, 32, 147, 252, 96, 224))) and SubsystemMgr:Get((U2(63, 142, 42, 122, 76, 124, 60, 62, 173, 85, 47, 21, 32, 147, 252, 96, 224))):IsActivityActive() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLockAreaEndOverlap"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if Client then
        return
      end
      print(bWriteLog and string.format((table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 5, 159, 251, 126, 220, 179, 92, 72, 187, 93, 87, 60),
        U1(11, 132, 43, 101, 127, 99, 115, 126, 222, 97, 46, 18, 54, 146, 168, 105, 232, 183, 93, 25, 130, 76, 64, 8, 206, 81, 47, 19, 40)
      }))))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveEndPlay"] = function(_ARG_0_)
    do
      if _ARG_0_.CoinSlotMgr then
        _ARG_0_.CoinSlotMgr:OnEndPlay()
        _ARG_0_.CoinSlotMgr = nil
      end
      if _ARG_0_.CoinProductionTimer then
        _ARG_0_:RemoveGameTimer(_ARG_0_.CoinProductionTimer)
        _ARG_0_.CoinProductionTimer = nil
      end
      _ARG_0_:StopAICoinReportingTimer()
      _ARG_0_:CancelLoadMesh()
      _ARG_0_:_StopGalleryUnlockRetryTimer()
      if not Client then
        _ARG_0_:RemoveAllGreenPassPlayers()
      end
      _ARG_0_:HideBaseScreenMark()
      _ARG_0_:_ServerForceStopInfraredAlarm()
      _ARG_0_:_ClientStopInfraredAlarmFX()
      _ARG_0_.uInfraredAlarmFX_Steady = nil
      _ARG_0_.uInfraredAlarmFX_Blink = nil
      U1.__super.ReceiveEndPlay(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitByCarryInData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      if not SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))) then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_1_:GetEnsure() and not _ARG_2_ then
        return
      end
      if _ARG_1_:GetEnsure() then
      elseif not slua.isValid((_ARG_1_:GetPlayerControllerSafety())) then
        return
      end
      if not _ARG_1_:GetEnsure() then
        if SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(40, 146, 60, 90, 117, 122, 61))) and _ARG_1_:GetPlayerControllerSafety().SkinFeature then
          if _ARG_1_.PartnerGhostFeature then
          end
        end
      else
      end
      if SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(63, 128, 42, 96, 125))) and SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(63, 128, 42, 96, 125))).nRebirthCount then
      else
      end
      if SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40))) and SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40))).nAdditionSlotCount then
      else
      end
      if SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40))) and SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40))).nPendingAdditionSlotCount then
        _ARG_0_.PendingAdditionSlotCount = SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40))).nPendingAdditionSlotCount
      end
      if CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(63, 128, 42, 96, 125))).nRebirthCount) then
        _ARG_0_.RebirthCount = SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(63, 128, 42, 96, 125))).nRebirthCount
        _ARG_0_.BaseLevel = CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(63, 128, 42, 96, 125))).nRebirthCount).BasementLevel
        _ARG_0_.DoorLockDuration = CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(63, 128, 42, 96, 125))).nRebirthCount).BaseLockTime
        _ARG_0_.MoneyReturnRatio = CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(63, 128, 42, 96, 125))).nRebirthCount).MoneyReturnRatio_f
        _ARG_0_.StartBudget = tonumber(CDataTable.GetTableData(U1(47, 132, 59, 96, 108, 103, 59, 16, 145, 78, 43, 15, 62), SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(63, 128, 42, 96, 125))).nRebirthCount).StartBudget) or 0
      else
        _ARG_0_.RebirthCount = SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(63, 128, 42, 96, 125))).nRebirthCount
        _ARG_0_.DoorLockDuration = 60
        _ARG_0_.BaseLevel = 1
        _ARG_0_.MoneyReturnRatio = 1.0
        _ARG_0_.StartBudget = 1000
      end
      if SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40))) and SubsystemMgr:Get((U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):GetCarryInData(_ARG_1_:GetPlayerControllerSafety().PlayerKey, (U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40))).MonsterSlots then
        if not _ARG_1_:GetEnsure() then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1.PlayerKey
    end
  end,
  ["UpdateBuildingMesh"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Building) then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 223, 180, 80, 69, 154, 90, 93, 20),
          U1(48, 132, 42, 97, 62, 62, 115, 17, 139, 73, 33, 2, 48, 142, 239, 37, 238, 190, 68, 73, 129, 77, 70, 13, 154, 16, 51, 25, 61, 208, 254, 122, 232, 175, 93, 9, 145, 65, 19, 26),
          U1(19, 151, 56, 101, 119, 119)
        }))
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 223, 180, 80, 69, 154, 90, 93, 20),
        U1(48, 132, 42, 97, 62, 62, 115, 0, 149, 73, 35, 47, 29, 187, 173, 97, 208, 241, 107, 88, 157, 70, 111, 6, 152, 85, 49, 45, 108, 148, 197)
      }), _ARG_0_.SkinID, _ARG_0_.BaseLevel))
      if not CDataTable.GetTableData(U1(45, 141, 56, 103, 92, 71, 17, 50, 141, 69, 30, 13, 48, 142, 203, 106, 227, 183, 64, 94), _ARG_0_.SkinID) then
        return
      end
      if _ARG_0_.BaseLevel == 1 then
      elseif _ARG_0_.BaseLevel == 2 then
      end
      if not SubsystemMgr:Get((U1(45, 141, 56, 103, 92, 71, 7, 59, 155, 77, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):OverlayBaseSkin(_ARG_0_.SkinID, (CDataTable.GetTableData(U1(45, 141, 56, 103, 92, 71, 17, 50, 141, 69, 30, 13, 48, 142, 203, 106, 227, 183, 64, 94), _ARG_0_.SkinID))).MeshPathDouble or SubsystemMgr:Get((U1(45, 141, 56, 103, 92, 71, 7, 59, 155, 77, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):OverlayBaseSkin(_ARG_0_.SkinID, (CDataTable.GetTableData(U1(45, 141, 56, 103, 92, 71, 17, 50, 141, 69, 30, 13, 48, 142, 203, 106, 227, 183, 64, 94), _ARG_0_.SkinID))).MeshPathDouble == U1() then
        return
      end
      _ARG_0_.MeshLoadRequestId = _ARG_0_.MeshLoadRequestId + 1
      _ARG_0_.PendingMeshAssetPath = SubsystemMgr:Get((U1(45, 141, 56, 103, 92, 71, 7, 59, 155, 77, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):OverlayBaseSkin(_ARG_0_.SkinID, (CDataTable.GetTableData(U1(45, 141, 56, 103, 92, 71, 17, 50, 141, 69, 30, 13, 48, 142, 203, 106, 227, 183, 64, 94), _ARG_0_.SkinID))).MeshPathDouble, SubsystemMgr:Get((U1(45, 141, 56, 103, 92, 71, 7, 59, 155, 77, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):OverlayBaseSkin(_ARG_0_.SkinID, (CDataTable.GetTableData(U1(45, 141, 56, 103, 92, 71, 17, 50, 141, 69, 30, 13, 48, 142, 203, 106, 227, 183, 64, 94), _ARG_0_.SkinID))), _ARG_0_.MeshLoadRequestId
      if _ARG_0_.MeshLoadHandleId then
        _ARG_0_.MeshLoadHandleId = nil
      end
      _ARG_0_.MeshLoadHandleId = require((U1(30, 142, 52, 100, 113, 125, 125, 50, 141, 83, 40, 18, 6, 149, 252, 108, 225))).GetAssetAsyncOneParam(SubsystemMgr:Get((U1(45, 141, 56, 103, 92, 71, 7, 59, 155, 77, 40, 53, 44, 130, 251, 124, 254, 165, 76, 84))):OverlayBaseSkin(_ARG_0_.SkinID, (CDataTable.GetTableData(U1(45, 141, 56, 103, 92, 71, 17, 50, 141, 69, 30, 13, 48, 142, 203, 106, 227, 183, 64, 94), _ARG_0_.SkinID))).MeshPathDouble, function(_ARG_0_)
        do
          if _ENV ~= U1.MeshLoadRequestId then
            U2.printf(U2.bWriteLog and U2.table.concat({
              U3(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 223, 180, 80, 69, 154, 90, 93, 20),
              U3(48, 132, 42, 97, 62, 65, 54, 48, 159, 76, 33, 70, 11, 133, 249, 112, 232, 162, 93, 112, 138, 120, 6, 7, 179, 16, 16, 19, 58, 152, 212, 122, 252, 165, 107, 76, 143, 70, 86, 0),
              U3(9, 168, 61, 82, 59, 119, 14, 115, 140, 69, 57, 19, 43, 142)
            }), _ENV, U1.MeshLoadRequestId)
            return
          end
          U1.MeshLoadHandleId = nil
          if not U2.slua.isValid(U1.Building) then
            U2.print(U2.bWriteLog and U2.table.concat({
              U3(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 223, 180, 80, 69, 154, 90, 93, 20),
              U3(48, 132, 42, 97, 62, 65, 54, 48, 159, 76, 33, 70, 27, 149, 225, 105, 233, 184, 71, 94, 206, 74, 77, 21, 143, 92, 52, 18)
            }))
            return
          end
          if not U2.slua.isValid(_ARG_0_) then
            U2.print(U2.bWriteLog and U2.table.concat({
              U3(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 223, 180, 80, 69, 154, 90, 93, 20),
              U3(48, 132, 42, 97, 62, 65, 54, 48, 159, 76, 33, 70, 21, 143, 233, 97, 232, 181, 104, 74, 157, 70, 87, 67, 135, 94, 43, 23, 37, 153, 252)
            }))
            return
          end
          if U1.PendingMeshAssetPath ~= U4 then
            U2.print(U2.bWriteLog and U2.table.concat({
              U3(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 223, 180, 80, 69, 154, 90, 93, 20),
              U3(48, 132, 42, 97, 62, 65, 54, 48, 159, 76, 33, 70, 9, 133, 230, 97, 228, 191, 78, 116, 139, 80, 75, 34, 157, 67, 56, 2, 25, 145, 236, 125, 189, 191, 4, 9, 179, 86, 64, 27),
              U3(45, 128, 45, 97)
            }))
            return
          end
          U1.Building:SetStaticMesh(_ARG_0_)
          U2.printf(U2.bWriteLog and U2.table.concat({
            U3(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 223, 180, 80, 69, 154, 90, 93, 20),
            U3(48, 132, 42, 97, 62, 65, 54, 48, 159, 76, 33, 70, 11, 133, 249, 112, 232, 162, 93, 112, 138, 120, 6, 7, 179, 16, 31, 23, 58, 149, 212, 112, 235, 164, 85, 114, 219, 87, 110, 83),
            U3(46, 138, 48, 103, 87, 87, 8, 118, 154, 125, 109, 43, 60, 147, 224, 85, 236, 165, 65, 98, 203, 80, 126)
          }), _ENV, U1.BaseLevel, U1.SkinID, U4)
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CancelLoadMesh"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 146, 72, 87, 141, 70, 79, 47, 129, 81, 57, 59, 44, 131, 240))
      _ARG_0_.MeshLoadRequestId = _ARG_0_.MeshLoadRequestId + 1
      _ARG_0_.PendingMeshAssetPath = nil
      if _ARG_0_.MeshLoadHandleId then
        print(bWriteLog and table.concat({
          U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 146, 72, 87, 141, 70, 79, 47, 129, 81, 57, 59, 44, 131, 240, 53, 222, 160, 87, 74, 155, 95, 114, 0),
          U1(14, 132, 45, 72, 109, 106, 61, 48)
        }))
        _ARG_0_.MeshLoadHandleId = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[100]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateSecondFloor"] = function(_ARG_0_)
    do
      if _ARG_0_.BaseLevel == 1 then
        if slua.isValid(_ARG_0_.WidgetUnlockTime) and slua.isValid(_ARG_0_.WidgetUnlockTime.Widget) and slua.isValid(_ARG_0_.WidgetUnlockTime.Widget.TextUnlockCountFloor2) then
          _ARG_0_.WidgetUnlockTime.Widget.TextUnlockCountFloor2:SetVisibility(UEnums.ESlateVisibility.Collapsed)
          _ARG_0_.WidgetUnlockTime:RequestRedraw()
        end
        if slua.isValid(_ARG_0_.MeshLock2) then
          _ARG_0_.MeshLock2:SetHiddenInGame(true, true)
        end
        if slua.isValid(_ARG_0_.BoxCollisionLock2) then
          _ARG_0_:RemoveControlEvent(_ARG_0_.BoxCollisionLock2, (U1(50, 143, 26, 102, 115, 99, 60, 61, 155, 78, 57, 36, 60, 135, 225, 107, 194, 167, 76, 75, 130, 66, 83)))
        end
        if slua.isValid(_ARG_0_.DoorFX2) then
          _ARG_0_.DoorFX2:Deactivate()
        end
      elseif _ARG_0_.BaseLevel == 2 then
        if Client then
          _ARG_0_:UpdateUnlockTimeUI()
        end
        if slua.isValid(_ARG_0_.MeshLock2) then
          _ARG_0_.MeshLock2:SetHiddenInGame(false, true)
        end
        if slua.isValid(_ARG_0_.BoxCollisionLock2) then
          _ARG_0_:AddControlEvent(_ARG_0_.BoxCollisionLock2, U1(50, 143, 26, 102, 115, 99, 60, 61, 155, 78, 57, 36, 60, 135, 225, 107, 194, 167, 76, 75, 130, 66, 83), _ARG_0_.OnLockAreaBeginOverlap, _ARG_0_)
        end
        if _ARG_0_.DoorsState == U2.Locked then
          if slua.isValid(_ARG_0_.DoorFX2) then
            _ARG_0_.DoorFX2:Activate(true)
            print(bWriteLog and table.concat({
              U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 206, 164, 90, 70, 144, 87, 117, 31),
              U1(18, 142, 43, 41, 51, 51, 18, 48, 138, 73, 59, 7, 45, 133, 236, 37, 201, 190, 70, 75, 168, 123, 17, 67, 140, 85, 62, 23, 60, 131, 253, 53, 249, 174, 86, 91, 141, 19, 82, 1),
              U1(24, 193, 58, 124, 108, 97, 54, 61, 138, 76, 52, 70, 53, 143, 235, 110, 232, 181)
            }))
          end
        elseif slua.isValid(_ARG_0_.DoorFX2) then
          _ARG_0_.DoorFX2:Deactivate()
        end
        if Client then
          _ARG_0_:ClientBindSecondFloorCollision()
          _ARG_0_:SetSecondFloorSlotsVisible(false)
        end
      end
      _ARG_0_:UpdateStairsCoverCollision()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientBindSecondFloorCollision"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not slua.isValid(_ARG_0_.BoxCollisionSecondFloor) then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 26, 32, 149, 246, 97, 223, 168, 87, 77, 173, 86, 80, 28),
          U1(19, 133, 31, 101, 113, 124, 33, 16, 145, 76, 33, 15, 42, 137, 231, 107, 173, 252, 9, 123, 129, 91, 96, 12, 130, 92, 52, 5, 32, 159, 246, 70, 248, 162, 86, 71, 154, 117, 95, 28),
          U1(18, 147, 121, 103, 113, 103, 115, 53, 145, 85, 35, 2, 121, 143, 250, 37, 228, 191, 95, 88, 130, 74, 71)
        }))
        return
      end
      _ARG_0_:AddControlEvent(_ARG_0_.BoxCollisionSecondFloor, U1(50, 143, 26, 102, 115, 99, 60, 61, 155, 78, 57, 36, 60, 135, 225, 107, 194, 167, 76, 75, 130, 66, 83), _ARG_0_.OnSecondFloorBeginOverlap, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_.BoxCollisionSecondFloor, U1(50, 143, 26, 102, 115, 99, 60, 61, 155, 78, 57, 35, 55, 132, 199, 115, 232, 163, 69, 88, 158), _ARG_0_.OnSecondFloorEndOverlap, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSecondFloorBeginOverlap"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not Client then
        return
      end
      if not slua.isValid((U1.GetPlayerCharacter())) or _ARG_2_ ~= U1.GetPlayerCharacter() then
        return
      end
      _ARG_0_.bClientLocalPlayerOnSecondFloor = true
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSecondFloorEndOverlap"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not Client then
        return
      end
      if not slua.isValid((U1.GetPlayerCharacter())) or _ARG_2_ ~= U1.GetPlayerCharacter() then
        return
      end
      _ARG_0_.bClientLocalPlayerOnSecondFloor = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSecondFloorSlotsVisible"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      _ARG_0_ = _ARG_0_
      if nil <= _ARG_0_.SlotCount then
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateStairsCoverCollision"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.StairsCover) then
        return
      end
      if _ARG_0_.BaseLevel == 2 then
        _ARG_0_.StairsCover:SetCollisionEnabled(U1.QueryAndPhysics)
      else
        _ARG_0_.StairsCover:SetCollisionEnabled(U1.NoCollision)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetOwner"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not _ARG_1_ or not slua.isValid(_ARG_1_) then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 19, 61, 191, 239, 123, 248, 179, 25, 4, 222, 122, 93, 5),
          U1(28, 141, 48, 109, 62, 102, 3, 63, 159, 89, 40, 20, 26, 136, 233, 119, 236, 178, 93, 92, 156)
        }))
        return
      end
      if slua.isValid(_ARG_0_.OwnerCharacter) and _ARG_0_.OwnerCharacter ~= _ARG_1_ then
      end
      _ARG_0_.nOwnerPlayerKey = _ARG_1_.PlayerKey, _ARG_0_.OwnerCharacter, _ARG_0_:RemoveAllGreenPassPlayers()
      _ARG_0_.OwnerCharacter = _ARG_1_
      _ARG_0_.OwnerPlayerName = _ARG_1_.PlayerName
      _ARG_0_.OverlapList = {}
      _ARG_0_.LastStealAlertTime = 0
      goto lbl_400
      ::lbl_400::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SpawnMonstersInSlots"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not _ARG_1_ or type(_ARG_1_) ~= U1(9, 128, 59, 101, 123) then
        return
      end
      _ARG_0_ = _ARG_0_
      if U3(_ARG_1_[123]) then
        if _ARG_0_.MonsterSlots[123] and slua.isValid(_ARG_0_.MonsterSlots[123].Mesh) then
          if _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation() then
            if slua.isValid((U6.SpawnActorRobust(U2.Blueprint.MonsterActor, U4(_ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Z + U2.Spawn.HeightOffset), _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():Rotator() or U5(0.0, 0.0, 0.0), U4(1.0, 1.0, 1.0)))) then
              U6.SpawnActorRobust(U2.Blueprint.MonsterActor, U4(_ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Z + U2.Spawn.HeightOffset), _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():Rotator() or U5(0.0, 0.0, 0.0), U4(1.0, 1.0, 1.0)).SlotIndex = 123, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld(), _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation(), _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():Rotator(), U4(_ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Z + U2.Spawn.HeightOffset), _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():Rotator() or U5(0.0, 0.0, 0.0), U6.SpawnActorRobust(U2.Blueprint.MonsterActor, U4(_ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Z + U2.Spawn.HeightOffset), _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():Rotator() or U5(0.0, 0.0, 0.0), U4(1.0, 1.0, 1.0)), U6.SpawnActorRobust(U2.Blueprint.MonsterActor, U4(_ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Z + U2.Spawn.HeightOffset), _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():Rotator() or U5(0.0, 0.0, 0.0), U4(1.0, 1.0, 1.0)):InitByID(U3(_ARG_1_[123]))
              if not _ARG_0_:AddMonster(U6.SpawnActorRobust(U2.Blueprint.MonsterActor, U4(_ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():GetLocation().Z + U2.Spawn.HeightOffset), _ARG_0_.MonsterSlots[123].Mesh:K2_GetComponentToWorld():Rotator() or U5(0.0, 0.0, 0.0), U4(1.0, 1.0, 1.0)), 123) then
              end
            else
            end
          else
          end
        else
        end
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetOwner"] = function(_ARG_0_)
    do
      do return _ARG_0_.OwnerCharacter end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateBaseOwnerInfoUI"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not _ARG_0_.Widget or not slua.isValid(_ARG_0_.Widget) then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 8, 6, 45, 145, 236, 112, 223, 160, 74, 76, 177, 68, 93, 22),
          U1(15, 168, 55, 111, 113, 70, 26, 115, 211, 0, 26, 15, 61, 135, 237, 113, 173, 191, 70, 77, 206, 69, 76, 22, 128, 84, 125, 25, 59, 208, 241, 123, 235, 160, 85, 64, 154)
        }))
        return
      end
      if not slua.isValid(_ARG_0_.Widget.Widget) then
        return
      end
      if _ARG_0_.Widget.Widget.TextMyBase and slua.isValid(_ARG_0_.Widget.Widget.TextMyBase) then
        if _ARG_0_.nOwnerPlayerKey and 0 < _ARG_0_.nOwnerPlayerKey and U2.GetPlayerController().PlayerKey == _ARG_0_.nOwnerPlayerKey then
        else
        end
      end
      if _ARG_0_.Widget.Widget.TextOwnerName and slua.isValid(_ARG_0_.Widget.Widget.TextOwnerName) then
        if _ARG_0_.nOwnerPlayerKey and 0 < _ARG_0_.nOwnerPlayerKey then
          if _ARG_0_.OwnerPlayerName and _ARG_0_.OwnerPlayerName ~= U1() then
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateBaseTitleUI"] = function(_ARG_0_)
    do
      _ARG_0_:UpdateBaseOwnerInfoUI()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateBaseTitleWidgetCullDistance"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not _ARG_0_.Widget or not slua.isValid(_ARG_0_.Widget) then
        return
      end
      if _ARG_0_.nOwnerPlayerKey and _ARG_0_.nOwnerPlayerKey > 0 and U1.GetPlayerController().PlayerKey == _ARG_0_.nOwnerPlayerKey then
      else
      end
      if not U2.MonsterBaseTitleWidgetCullDistanceOtherBase or 0 >= U2.MonsterBaseTitleWidgetCullDistanceOtherBase then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_UpdateLockBillboardFXVisibility"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not _ARG_0_.uLockBillboardFX or not slua.isValid(_ARG_0_.uLockBillboardFX) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateLockAreaUI"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      _ARG_0_:_UpdateLockBillboardFXVisibility()
      if not _ARG_0_.WidgetUnlockTime or not slua.isValid(_ARG_0_.WidgetUnlockTime) then
        return
      end
      if U1.GetPlayerController().PlayerKey == _ARG_0_.nOwnerPlayerKey then
        if slua.isValid(_ARG_0_.WidgetUnlockTime.Widget) and slua.isValid(_ARG_0_.WidgetUnlockTime.Widget.TextToLockBase) then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateStealAreaUI"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not _ARG_0_.Widget or not slua.isValid(_ARG_0_.Widget) then
        return
      end
      if not slua.isValid(_ARG_0_.Widget.Widget) then
        return
      end
      if U1.GetPlayerController().PlayerKey == _ARG_0_.nOwnerPlayerKey then
        if slua.isValid(_ARG_0_.Widget.Widget.TextTotalCoinProfitRatio) then
          if U1.GetPlayerController() and U1.GetPlayerController().CoinFeature or nil then
          else
          end
        else
        end
        if slua.isValid(_ARG_0_.Widget.Widget.TextStealCheckArea) then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateBaseOwnerName"] = function(_ARG_0_)
    do
      _ARG_0_:UpdateBaseOwnerInfoUI()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowBaseScreenMark"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if _ARG_0_.BaseScreenMarkID then
        return
      end
      if not _ARG_0_.Object or not slua.isValid(_ARG_0_.Object) then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 30, 38, 135, 218, 116, 238, 164, 106, 74, 140, 86, 86, 29),
          U1(48, 128, 43, 98, 62, 62, 115, 28, 156, 74, 40, 5, 45, 192, 225, 118, 173, 184, 71, 79, 143, 79, 74, 7)
        }))
        return
      end
      _ARG_0_.BaseScreenMarkID = U2.ClientAddMapMark(4305, _ARG_0_:K2_GetActorLocation(), 0, U1(), UEnums.EAddMarkFlag.EAMF_BothAndScreen, _ARG_0_.Object)
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 30, 38, 135, 218, 116, 238, 164, 106, 74, 140, 86, 86, 29),
        U1(48, 128, 43, 98, 62, 62, 115, 18, 154, 68, 40, 2, 121, 147, 235, 119, 232, 180, 71, 25, 131, 66, 81, 8, 194, 16, 20, 50, 18, 213, 235, 72)
      }), tostring(_ARG_0_.BaseScreenMarkID)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideBaseScreenMark"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if _ARG_0_.BaseScreenMarkID then
        U1.HideMapMark(_ARG_0_.BaseScreenMarkID)
        _ARG_0_.BaseScreenMarkID = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateBaseScreenMark"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not slua.isValid((U1.GetPlayerController())) then
        return
      end
      if _ARG_0_.nOwnerPlayerKey and _ARG_0_.nOwnerPlayerKey > 0 and _ARG_0_.nOwnerPlayerKey == U1.GetPlayerController().PlayerKey then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_OwnerPlayerName"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 210, 182, 87, 76, 140, 99, 95, 18),
        U1(4, 132, 43, 71, 127, 126, 54, 115, 211, 0, 2, 10, 61, 182, 233, 105, 248, 180, 114, 28, 157, 126, 15, 67, 160, 85, 42, 32, 40, 156, 237, 112, 198, 228, 74, 116)
      }), tostring(_ARG_1_ or U1()), tostring(_ARG_0_.OwnerPlayerName or U1())))
      if Client then
        _ARG_0_:UpdateBaseOwnerInfoUI()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSlotCount"] = function(_ARG_0_)
    do
      do return _ARG_0_.SlotCount end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsValidSlotIndex"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ and type(_ARG_1_) == U1(19, 148, 52, 107, 123, 97) then
        return 1 <= _ARG_1_ and _ARG_1_ <= _ARG_0_:GetSlotCount()
      else
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSlotEmpty"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or type(_ARG_1_) ~= U1(19, 148, 52, 107, 123, 97) or _ARG_1_ < 1 or _ARG_1_ > _ARG_0_:GetSlotCount() then
        return false
      end
      if not _ARG_0_.MonsterSlots[_ARG_1_] or not slua.isValid(_ARG_0_.MonsterSlots[_ARG_1_].Mesh) then
        return false
      end
      if not _ARG_0_.MonsterSlots[_ARG_1_].Monster or not slua.isValid(_ARG_0_.MonsterSlots[_ARG_1_].Monster) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAvailableSlotIndex"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if _ARG_0_:IsSlotEmpty(nil) then
        return nil
      end
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAvailableSlotCount"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if _ARG_0_:IsSlotEmpty(nil) then
      end
      _ARG_0_ = _ARG_0_
      do return 0 + 1 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetNearestAvailableSlotIndex"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.OwnerCharacter) then
        return nil
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_:IsSlotEmpty(nil) and _ARG_0_.MonsterSlots[nil] and slua.isValid(_ARG_0_.MonsterSlots[nil].Mesh) and _ARG_0_.MonsterSlots[nil].Mesh:K2_GetComponentToWorld() and math.huge > (_ARG_0_.MonsterSlots[nil].Mesh:K2_GetComponentToWorld():GetLocation().X - _ARG_0_.OwnerCharacter:K2_GetActorLocation().X) * (_ARG_0_.MonsterSlots[nil].Mesh:K2_GetComponentToWorld():GetLocation().X - _ARG_0_.OwnerCharacter:K2_GetActorLocation().X) + (_ARG_0_.MonsterSlots[nil].Mesh:K2_GetComponentToWorld():GetLocation().Y - _ARG_0_.OwnerCharacter:K2_GetActorLocation().Y) * (_ARG_0_.MonsterSlots[nil].Mesh:K2_GetComponentToWorld():GetLocation().Y - _ARG_0_.OwnerCharacter:K2_GetActorLocation().Y) + (_ARG_0_.MonsterSlots[nil].Mesh:K2_GetComponentToWorld():GetLocation().Z - _ARG_0_.OwnerCharacter:K2_GetActorLocation().Z) * (_ARG_0_.MonsterSlots[nil].Mesh:K2_GetComponentToWorld():GetLocation().Z - _ARG_0_.OwnerCharacter:K2_GetActorLocation().Z) then
      end
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetToEmptyBase"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 15, 19, 58, 149, 236, 65, 242, 132, 84, 89, 138, 74, 113, 18),
        U1(14, 132, 121, 36, 62, 65, 54, 32, 155, 84, 57, 15, 55, 135, 168, 103, 236, 162, 76, 25, 154, 76, 3, 6, 131, 64, 41, 15, 105, 131, 236, 116, 233, 164)
      }))
      _ARG_0_:ClearSlots()
      _ARG_0_:_ServerForceStopInfraredAlarm()
      _ARG_0_.nOwnerPlayerKey = 0
      _ARG_0_.OwnerCharacter = nil
      _ARG_0_.OwnerPlayerName = U1()
      _ARG_0_.RebirthCount = 0
      _ARG_0_:SetSlotCount(0, 0)
      _ARG_0_.PendingAdditionSlotCount = 0
      _ARG_0_.DoorLockDuration = 60
      _ARG_0_.BaseLevel = 1
      _ARG_0_.MoneyReturnRatio = 1.0
      _ARG_0_.StartBudget = 1000
      goto lbl_210
      ::lbl_210::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.OverlapList = {}
      _ARG_0_.LastStealAlertTime = 0
      _ARG_0_.StealAlertCD = 10
      _ARG_0_.LastIntruderAlertTime = 0
      _ARG_0_.IntruderAlertCD = 10
      do return end
      _ARG_0_ = BaseParams
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBaseEmpty"] = function(_ARG_0_)
    do
      do return _ARG_0_.nOwnerPlayerKey == 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FillCarryOutData"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not _ARG_0_.nOwnerPlayerKey or _ARG_0_.nOwnerPlayerKey <= 0 then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 27, 31, 37, 156, 219, 116, 239, 179, 64, 102, 139, 71, 119, 18),
          U1(9, 128, 121, 36, 62, 81, 50, 32, 155, 0, 37, 7, 42, 192, 230, 106, 173, 190, 94, 87, 139, 81)
        }))
        return
      end
      if not _ARG_1_ then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 27, 31, 37, 156, 219, 116, 239, 179, 64, 102, 139, 71, 119, 18),
          U1(9, 128, 121, 36, 62, 90, 61, 37, 159, 76, 36, 2, 121, 131, 233, 119, 255, 168, 9, 86, 155, 87, 3, 7, 143, 68, 60, 86, 61, 145, 250, 121, 248)
        }))
        return
      end
      if not _ARG_1_.MonsterBase then
        _ARG_1_.MonsterBase = {}
      end
      _ARG_1_.MonsterBase.MonsterSlots = {}
      _ARG_0_ = _ARG_0_
      if _ARG_0_.MonsterSlots[U1(9, 128, 121, 36, 62, 90, 61, 37, 159, 76, 36, 2, 121, 131, 233, 119, 255, 168, 9, 86, 155, 87, 3, 7, 143, 68, 60, 86, 61, 145, 250, 121, 248)] and _ARG_0_.MonsterSlots[U1(9, 128, 121, 36, 62, 90, 61, 37, 159, 76, 36, 2, 121, 131, 233, 119, 255, 168, 9, 86, 155, 87, 3, 7, 143, 68, 60, 86, 61, 145, 250, 121, 248)].Monster and slua.isValid(_ARG_0_.MonsterSlots[U1(9, 128, 121, 36, 62, 90, 61, 37, 159, 76, 36, 2, 121, 131, 233, 119, 255, 168, 9, 86, 155, 87, 3, 7, 143, 68, 60, 86, 61, 145, 250, 121, 248)].Monster) then
        if _ARG_0_.MonsterSlots[U1(9, 128, 121, 36, 62, 90, 61, 37, 159, 76, 36, 2, 121, 131, 233, 119, 255, 168, 9, 86, 155, 87, 3, 7, 143, 68, 60, 86, 61, 145, 250, 121, 248)].Monster.State == U2.EMonsterState.InBase then
          _ARG_1_.MonsterBase.MonsterSlots[U1(9, 128, 121, 36, 62, 90, 61, 37, 159, 76, 36, 2, 121, 131, 233, 119, 255, 168, 9, 86, 155, 87, 3, 7, 143, 68, 60, 86, 61, 145, 250, 121, 248)] = {
            id = _ARG_0_.MonsterSlots[U1(9, 128, 121, 36, 62, 90, 61, 37, 159, 76, 36, 2, 121, 131, 233, 119, 255, 168, 9, 86, 155, 87, 3, 7, 143, 68, 60, 86, 61, 145, 250, 121, 248)].Monster.MonsterID,
            star = _ARG_0_.MonsterSlots[U1(9, 128, 121, 36, 62, 90, 61, 37, 159, 76, 36, 2, 121, 131, 233, 119, 255, 168, 9, 86, 155, 87, 3, 7, 143, 68, 60, 86, 61, 145, 250, 121, 248)].Monster.StarLevel or 0
          }
        else
        end
      end
      _ARG_0_ = _ARG_0_
      _ARG_1_.MonsterBase.nAdditionSlotCount = _ARG_0_.AdditionSlotCount or 0
      _ARG_1_.MonsterBase.nPendingAdditionSlotCount = _ARG_0_.PendingAdditionSlotCount or 0
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1.star
    end
  end,
  ["CreateDoors"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 4, 44, 145, 236, 112, 217, 174, 86, 91, 141, 19, 30, 83),
        U1(62, 147, 60, 104, 106, 122, 61, 52, 222, 68, 34, 9, 43, 192, 233, 102, 249, 190, 91, 74)
      }))
      if _ARG_0_.BoxCollisionDoor and slua.isValid(_ARG_0_.BoxCollisionDoor) then
        if _ARG_0_.BoxCollisionDoor:K2_GetComponentToWorld() then
          if slua.isValid((U4.SpawnActorRobust(U2.Blueprint.AccessControlDoor, _ARG_0_.BoxCollisionDoor:K2_GetComponentToWorld():GetLocation(), _ARG_0_.BoxCollisionDoor:K2_GetComponentToWorld():Rotator(), (U3(1.0, 1.0, 1.0))))) then
            _ARG_0_.DoorActor1 = U4.SpawnActorRobust(U2.Blueprint.AccessControlDoor, _ARG_0_.BoxCollisionDoor:K2_GetComponentToWorld():GetLocation(), _ARG_0_.BoxCollisionDoor:K2_GetComponentToWorld():Rotator(), (U3(1.0, 1.0, 1.0))), U4.SpawnActorRobust(U2.Blueprint.AccessControlDoor, _ARG_0_.BoxCollisionDoor:K2_GetComponentToWorld():GetLocation(), _ARG_0_.BoxCollisionDoor:K2_GetComponentToWorld():Rotator(), (U3(1.0, 1.0, 1.0))):SetOwnerBase(_ARG_0_.Object)
          else
          end
        else
        end
      else
      end
      if _ARG_0_.BoxCollisionDoor2 and slua.isValid(_ARG_0_.BoxCollisionDoor2) then
        if _ARG_0_.BoxCollisionDoor2:K2_GetComponentToWorld() then
          if slua.isValid((U4.SpawnActorRobust(U2.Blueprint.AccessControlDoor, _ARG_0_.BoxCollisionDoor2:K2_GetComponentToWorld():GetLocation(), _ARG_0_.BoxCollisionDoor2:K2_GetComponentToWorld():Rotator(), (U3(1.0, 1.0, 1.0))))) then
            _ARG_0_.DoorActor2 = U4.SpawnActorRobust(U2.Blueprint.AccessControlDoor, _ARG_0_.BoxCollisionDoor2:K2_GetComponentToWorld():GetLocation(), _ARG_0_.BoxCollisionDoor2:K2_GetComponentToWorld():Rotator(), (U3(1.0, 1.0, 1.0))), U4.SpawnActorRobust(U2.Blueprint.AccessControlDoor, _ARG_0_.BoxCollisionDoor2:K2_GetComponentToWorld():GetLocation(), _ARG_0_.BoxCollisionDoor2:K2_GetComponentToWorld():Rotator(), (U3(1.0, 1.0, 1.0))):SetOwnerBase(_ARG_0_.Object)
          else
          end
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DestroyDoors"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 25, 19, 58, 132, 234, 122, 228, 133, 86, 70, 140, 64, 19, 94),
        U1(93, 165, 60, 122, 106, 97, 60, 42, 151, 78, 42, 70, 61, 143, 231, 119, 173, 176, 74, 77, 129, 81, 80)
      }))
      if _ARG_0_.DoorActor1 and slua.isValid(_ARG_0_.DoorActor1) then
        _ARG_0_.DoorActor1:K2_DestroyActor()
        _ARG_0_.DoorActor1 = nil
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 25, 19, 58, 132, 234, 122, 228, 133, 86, 70, 140, 64, 19, 94),
          U1(93, 165, 54, 102, 108, 51, 98, 115, 154, 69, 62, 18, 43, 143, 241, 96, 233)
        }))
      end
      if _ARG_0_.DoorActor2 and slua.isValid(_ARG_0_.DoorActor2) then
        _ARG_0_.DoorActor2:K2_DestroyActor()
        _ARG_0_.DoorActor2 = nil
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 25, 19, 58, 132, 234, 122, 228, 133, 86, 70, 140, 64, 19, 94),
          U1(93, 165, 54, 102, 108, 51, 97, 115, 154, 69, 62, 18, 43, 143, 241, 96, 233)
        }))
      end
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 25, 19, 58, 132, 234, 122, 228, 133, 86, 70, 140, 64, 19, 94),
        U1(93, 165, 54, 102, 108, 51, 55, 54, 141, 84, 63, 19, 58, 148, 225, 106, 227, 241, 74, 86, 131, 83, 79, 6, 154, 85, 57)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[225]
    end
  end,
  ["IsForceUnlockOnCooldown"] = function(_ARG_0_)
    do
      if (_ARG_0_.nLastForceUnlockServerTime or 0) <= 0 then
        return false
      end
      if Door.BaseForceUnlockCooldownDuration > U1.GetTimeSeconds(U2.CGameWorld) - (_ARG_0_.nLastForceUnlockServerTime or 0) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecordForceUnlockTime"] = function(_ARG_0_)
    do
      _ARG_0_.nLastForceUnlockServerTime = GetTimeSeconds(U1.CGameWorld)
      U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
        U2(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 15, 19, 42, 159, 234, 113, 219, 174, 75, 74, 155, 102, 93, 31),
        U2(18, 130, 50, 93, 119, 126, 54, 115, 211, 0, 31, 3, 58, 143, 250, 97, 232, 181, 9, 77, 135, 78, 70, 56, 203, 30, 111, 16, 20)
      }), _ARG_0_.nLastForceUnlockServerTime))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearForceUnlockTime"] = function(_ARG_0_)
    do
      _ARG_0_.nLastForceUnlockServerTime = 0
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 26, 44, 145, 234, 83, 242, 179, 90, 76, 171, 93, 95, 28),
        U1(30, 138, 13, 96, 115, 118, 115, 126, 222, 99, 33, 3, 56, 146, 237, 97, 173, 183, 70, 75, 141, 70, 3, 22, 128, 92, 50, 21, 34, 208, 251, 122, 242, 173, 93, 70, 137, 93)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInInitialProtect"] = function(_ARG_0_)
    do
      if (_ARG_0_.nInitialProtectUntilTime or 0) <= 0 then
        return false
      end
      if (_ARG_0_.nInitialProtectUntilTime or 0) > GetTimeSeconds(U1.CGameWorld) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartInitialProtect"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or _ARG_1_ <= 0 then
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 2, 40, 130, 236, 92, 243, 168, 77, 64, 159, 95, 99, 1),
          U1(18, 149, 60, 106, 106, 51, 126, 115, 183, 78, 59, 7, 53, 137, 236, 37, 233, 164, 91, 88, 154, 74, 76, 13, 181, 21, 46, 43)
        }), tostring(_ARG_1_)))
        return
      end
      _ARG_0_.nInitialProtectUntilTime = U2.GetTimeSeconds(CGameWorld) + _ARG_1_
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 2, 40, 130, 236, 92, 243, 168, 77, 64, 159, 95, 99, 1),
        U1(18, 149, 60, 106, 106, 51, 126, 115, 173, 84, 44, 20, 45, 133, 236, 41, 173, 181, 92, 75, 143, 87, 74, 12, 128, 107, 120, 18, 20, 131, 180, 53, 232, 175, 77, 64, 146, 104, 22, 93),
        U1(79, 135, 4)
      }), _ARG_1_, _ARG_0_.nInitialProtectUntilTime))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearInitialProtect"] = function(_ARG_0_)
    do
      _ARG_0_.nInitialProtectUntilTime = 0
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 26, 44, 145, 234, 92, 243, 168, 77, 64, 159, 95, 99, 1),
        U1(18, 149, 60, 106, 106, 51, 126, 115, 189, 76, 40, 7, 43, 133, 236, 37, 228, 191, 64, 77, 135, 66, 79, 67, 158, 66, 50, 2, 44, 147, 236, 124, 242, 175)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenDoors"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 6, 44, 158, 220, 122, 242, 179, 74, 9, 211, 19, 124, 3),
        U1(24, 143, 48, 103, 121, 51, 55, 60, 145, 82, 62)
      }))
      _ARG_0_.nUnlockTime = 0
      _ARG_0_.DoorsState = U2.Open
      if slua.isValid(_ARG_0_.DoorActor1) then
        _ARG_0_.DoorActor1:Open()
      end
      if _ARG_0_.BaseLevel > 1 and slua.isValid(_ARG_0_.DoorActor2) then
        _ARG_0_.DoorActor2:Open()
      end
      EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_MLAI_SPECIALZONE_CUSTOM_ATTRIBUTE_CHANGE, _ARG_0_.Object, 2, _ARG_0_.nUnlockTime)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LockDoors"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 17, 25, 42, 155, 220, 122, 242, 179, 74, 9, 211, 19, 127, 28),
        U1(30, 138, 48, 103, 121, 51, 55, 60, 145, 82, 62)
      }))
      _ARG_0_.DoorsState = U2.Locked
      if slua.isValid(_ARG_0_.DoorActor1) then
        _ARG_0_.DoorActor1:Lock()
      end
      if _ARG_0_.BaseLevel > 1 and slua.isValid(_ARG_0_.DoorActor2) then
        _ARG_0_.DoorActor2:Lock()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ForceLockDoorsByActivity"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.OpenDoorsTimer then
        _ARG_0_:RemoveGameTimer(_ARG_0_.OpenDoorsTimer)
        _ARG_0_.OpenDoorsTimer = nil
      end
      _ARG_0_.nUnlockTime = 0
      _ARG_0_:LockDoors()
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 27, 25, 59, 147, 253, 89, 242, 162, 82, 109, 145, 92, 65, 0),
        U1(63, 152, 24, 106, 106, 122, 37, 58, 138, 89, 109, 75, 121, 166, 231, 119, 238, 180, 9, 85, 129, 64, 72, 6, 138, 16, 57, 25, 38, 130, 235, 57, 189, 162, 85, 76, 159, 65, 86, 23),
        U1(93, 128, 53, 101, 62, 102, 61, 63, 145, 67, 38, 70, 45, 137, 229, 96, 255, 162)
      }))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Lock"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not _ARG_1_ or _ARG_1_ <= 0 then
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 17, 25, 42, 155, 184, 56, 189, 136, 87, 95, 159, 95, 90, 23),
          U1(93, 141, 54, 106, 117, 51, 55, 38, 140, 65, 57, 15, 54, 142, 211, 32, 254, 140)
        }), tostring(_ARG_1_)))
        return
      end
      if slua.isValid(_ARG_0_.OwnerCharacter) and slua.isValid((_ARG_0_.OwnerCharacter:GetPlayerControllerSafety())) and _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().HasBaseLockDurationBuff15 and _ARG_0_.OwnerCharacter:GetPlayerControllerSafety():HasBaseLockDurationBuff15() then
        _ARG_1_ = _ARG_1_ + 15
      end
      if not slua.isValid((U2.GetGameState())) then
        return
      end
      _ARG_0_.nUnlockTime = U2.GetGameState():GetServerWorldTimeSeconds() + _ARG_1_
      if _ARG_0_.OpenDoorsTimer then
        _ARG_0_.OpenDoorsTimer = nil
      end
      _ARG_0_.OpenDoorsTimer = _ARG_0_:AddGameTimer(_ARG_1_, false, function()
        OpenDoorsTimer = nil
        _ENV:OpenDoors()
        return
      end)
      if slua.isValid(_ARG_0_.OwnerCharacter) and _ARG_0_.OwnerCharacter.PlayerKey and type(_ARG_0_.OwnerCharacter.PlayerKey) == U1(19, 148, 52, 107, 123, 97) and 0 < _ARG_0_.OwnerCharacter.PlayerKey then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[100]
    end
  end,
  ["OnRep_DoorsState"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 217, 174, 86, 91, 141, 96, 71, 18),
        U1(9, 132, 121, 36, 62, 87, 60, 60, 140, 83, 109, 21, 45, 129, 252, 96, 173, 178, 65, 88, 128, 68, 70, 7, 206, 86, 47, 25, 36, 208, 189, 113, 189, 181, 86, 9, 219, 87)
      }), _ARG_1_, _ARG_0_.DoorsState))
      if _ARG_0_.DoorsState == U2.Open then
        if slua.isValid(_ARG_0_.DoorFX) then
          _ARG_0_.DoorFX:Deactivate()
        end
        if _ARG_0_.BaseLevel > 1 and slua.isValid(_ARG_0_.DoorFX2) then
          _ARG_0_.DoorFX2:Deactivate()
        end
        _ARG_0_:_ClientNotifyPlayerUntrapped()
        if _ARG_0_.UnlockCountdownTimer then
          _ARG_0_:RemoveGameTimer(_ARG_0_.UnlockCountdownTimer)
          _ARG_0_.UnlockCountdownTimer = nil
        end
        _ARG_0_.ClientRemainingTime = 0
        _ARG_0_:UpdateUnlockTimeUI()
      elseif _ARG_0_.DoorsState == U2.Locked then
        if slua.isValid(_ARG_0_.DoorFX) then
          _ARG_0_.DoorFX:Activate(true)
        end
        if _ARG_0_.BaseLevel > 1 and slua.isValid(_ARG_0_.DoorFX2) then
          _ARG_0_.DoorFX2:Activate(true)
        end
        _ARG_0_:ClientControlGreenPass(_ARG_0_.DoorActor1)
        _ARG_0_:ClientControlGreenPass(_ARG_0_.DoorActor2)
        _ARG_0_:_ClientCheckLocalPlayerTrapped()
        if _ARG_0_.nUnlockTime and 0 < _ARG_0_.nUnlockTime then
          _ARG_0_.ClientRemainingTime = _ARG_0_:_ClientCalcRemainingTime()
          print(bWriteLog and string.format(table.concat({
            U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 217, 174, 86, 91, 141, 96, 71, 18),
            U1(9, 132, 121, 36, 62, 87, 60, 60, 140, 0, 33, 9, 58, 139, 237, 97, 161, 241, 90, 77, 143, 81, 87, 10, 128, 87, 125, 21, 38, 133, 246, 97, 249, 174, 78, 71, 222, 85, 65, 28),
            U1(16, 193, 124, 39, 44, 117)
          }), _ARG_0_.ClientRemainingTime))
          _ARG_0_:StartUnlockCountdownTimer()
        else
          _ARG_0_.ClientRemainingTime = 0
          _ARG_0_:UpdateUnlockTimeUI()
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClientCheckLocalPlayerTrapped"] = function(_ARG_0_)
    do
      if not _ARG_0_.bClientLocalPlayerInArea then
        return
      end
      if not U1.slua.isValid((GetPlayerCharacter())) then
        return
      end
      if _ARG_0_.nOwnerPlayerKey and _ARG_0_.nOwnerPlayerKey > 0 and GetPlayerCharacter().PlayerKey == _ARG_0_.nOwnerPlayerKey then
        return
      end
      if _ARG_0_:_IsPlayerInGreenPassList(GetPlayerCharacter().PlayerKey) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClientNotifyPlayerUntrapped"] = function(_ARG_0_)
    do
      if not _ARG_0_.bClientLocalPlayerInArea then
        return
      end
      if not U1.slua.isValid((GetPlayerCharacter())) then
        return
      end
      if _ARG_0_.nOwnerPlayerKey and _ARG_0_.nOwnerPlayerKey > 0 and GetPlayerCharacter().PlayerKey == _ARG_0_.nOwnerPlayerKey then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_DoorActor1"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 217, 174, 86, 91, 191, 80, 71, 28),
        U1(15, 208, 121, 36, 62, 87, 60, 60, 140, 0, 44, 5, 45, 143, 250, 37, 188, 241, 74, 81, 143, 77, 68, 6, 138)
      }))
      _ARG_0_:ClientControlGreenPass(_ARG_0_.DoorActor1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_DoorActor2"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 217, 174, 86, 91, 191, 80, 71, 28),
        U1(15, 211, 121, 36, 62, 87, 60, 60, 140, 0, 44, 5, 45, 143, 250, 37, 191, 241, 74, 81, 143, 77, 68, 6, 138)
      }))
      _ARG_0_:ClientControlGreenPass(_ARG_0_.DoorActor2)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_nUnlockTime"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 18, 24, 27, 149, 232, 74, 243, 148, 87, 69, 145, 80, 88, 39),
        U1(20, 140, 60, 41, 51, 51, 28, 63, 154, 118, 44, 10, 44, 133, 211, 32, 235, 140, 5, 25, 160, 70, 84, 53, 143, 92, 40, 19, 18, 213, 254, 72)
      }), _ARG_1_, _ARG_0_.nUnlockTime))
      if _ARG_0_.nUnlockTime <= 0 then
        if _ARG_0_.UnlockCountdownTimer then
          _ARG_0_:RemoveGameTimer(_ARG_0_.UnlockCountdownTimer)
          _ARG_0_.UnlockCountdownTimer = nil
        end
        _ARG_0_.ClientRemainingTime = 0
        _ARG_0_:UpdateUnlockTimeUI()
        return
      end
      _ARG_0_.ClientRemainingTime = _ARG_0_:_ClientCalcRemainingTime()
      if not _ARG_0_.UnlockCountdownTimer then
        _ARG_0_:StartUnlockCountdownTimer()
      else
        _ARG_0_:UpdateUnlockTimeUI()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_IsServerTimeReady"] = function(_ARG_0_)
    do
      if not U1.slua.isValid((GetGameState())) then
        return false
      end
      if GetGameState().ReplicatedWorldTimeSeconds == nil or GetGameState().ReplicatedWorldTimeSeconds <= 0 then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClientCalcRemainingTime"] = function(_ARG_0_)
    do
      if not _ARG_0_.nUnlockTime or _ARG_0_.nUnlockTime <= 0 then
        return 0
      end
      if not _ARG_0_:_IsServerTimeReady() then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 2, 53, 37, 153, 253, 123, 233, 130, 88, 69, 157, 97, 86, 30),
          U1(28, 136, 55, 96, 112, 116, 7, 58, 147, 69, 109, 75, 121, 179, 237, 119, 251, 180, 91, 109, 135, 78, 70, 67, 128, 95, 41, 86, 59, 149, 249, 113, 228)
        }))
        return -1
      end
      if 0 > _ARG_0_.nUnlockTime - U2.GetGameState():GetServerWorldTimeSeconds() then
      end
      do return 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartUnlockCountdownTimer"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if _ARG_0_.UnlockCountdownTimer then
        _ARG_0_:RemoveGameTimer(_ARG_0_.UnlockCountdownTimer)
        _ARG_0_.UnlockCountdownTimer = nil
      end
      if _ARG_0_.ClientRemainingTime == 0 then
        _ARG_0_:UpdateUnlockTimeUI()
        return
      end
      _ARG_0_:UpdateUnlockTimeUI()
      _ARG_0_.UnlockCountdownTimer = _ARG_0_:AddGameTimer(1.0, true, function()
        ClientRemainingTime = _ENV:_ClientCalcRemainingTime()
        if ClientRemainingTime < 0 then
          return
        end
        _ENV:UpdateUnlockTimeUI(true)
        if ClientRemainingTime <= 0 and UnlockCountdownTimer then
          _ENV:RemoveGameTimer(UnlockCountdownTimer)
          UnlockCountdownTimer = nil
        end
        return
      end)
      print(bWriteLog and string.format(table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 2, 40, 130, 236, 64, 243, 173, 86, 74, 149, 112, 92, 6),
        U1(19, 149, 61, 102, 105, 125, 7, 58, 147, 69, 63, 70, 116, 192, 219, 113, 236, 163, 93, 92, 138, 3, 64, 12, 155, 94, 41, 18, 38, 135, 246, 53, 233, 168, 84, 76, 140, 31, 19, 26),
        U1(19, 136, 45, 96, 127, 127, 115, 39, 151, 77, 40, 92, 121, 197, 166, 55, 235)
      }), _ARG_0_.ClientRemainingTime))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateUnlockTimeUI"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      if not slua.isValid(_ARG_0_.WidgetUnlockTime) then
        return
      end
      if not slua.isValid(_ARG_0_.WidgetUnlockTime.Widget) then
        return
      end
      _ARG_0_.WidgetUnlockTime:RequestRedraw()
      if not slua.isValid(_ARG_0_.WidgetUnlockTime.Widget.TextUnlockCountFloor1) then
        return
      end
      if _ARG_0_.BaseLevel >= 2 then
        if not slua.isValid(_ARG_0_.WidgetUnlockTime.Widget.TextUnlockCountFloor2) then
          return
        end
      end
      if _ARG_0_.ClientRemainingTime < 0 then
        if _ARG_0_.WidgetUnlockTime.Widget.TextUnlockCountFloor2 then
        end
        return
      end
      if _ARG_0_.ClientRemainingTime <= 0 then
        if _ARG_0_.DoorsState == U2.Locked and not _ARG_1_ then
          if _ARG_0_.WidgetUnlockTime.Widget.TextUnlockCountFloor2 then
          end
          return
        end
        if _ARG_0_.WidgetUnlockTime.Widget.TextUnlockCountFloor2 then
        end
        return
      end
      if _ARG_0_.WidgetUnlockTime.Widget.TextUnlockCountFloor2 then
      end
      if _ARG_0_.WidgetUnlockTime.Widget.TextUnlockCountFloor2 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartCoinProductionTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.CoinProductionTimer then
        _ARG_0_:RemoveGameTimer(_ARG_0_.CoinProductionTimer)
        _ARG_0_.CoinProductionTimer = nil
      end
      _ARG_0_.CoinProductionTimer = _ARG_0_:AddGameTimer(1.0, true, function()
        _ENV:UpdateCoinProduction()
        return
      end)
      _ARG_0_:StartAICoinReportingTimer()
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 2, 40, 130, 236, 86, 242, 168, 87, 121, 140, 92, 87, 6),
        U1(30, 149, 48, 102, 112, 71, 58, 62, 155, 82, 109, 75, 121, 163, 231, 108, 227, 241, 89, 75, 129, 71, 86, 0, 154, 89, 50, 24, 105, 132, 241, 120, 248, 179, 25, 90, 138, 82, 65, 7),
        U1(24, 133)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCoinProduction"] = function(_ARG_0_)
    do
      if not _ARG_0_.nOwnerPlayerKey or _ARG_0_.nOwnerPlayerKey <= 0 then
        return
      end
      if _ARG_0_.CoinSlotMgr then
        _ARG_0_.CoinSlotMgr:TickProductionDS()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SpawnMonsterInAvailableSlot"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return nil, nil
      end
      if not _ARG_1_ or type(_ARG_1_) ~= U1(19, 148, 52, 107, 123, 97) or _ARG_1_ <= 0 then
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 6, 40, 135, 246, 88, 242, 175, 74, 93, 155, 65, 122, 29),
          U1(60, 151, 56, 96, 114, 114, 49, 63, 155, 115, 33, 9, 45, 192, 165, 37, 196, 191, 95, 88, 130, 74, 71, 67, 131, 95, 51, 5, 61, 149, 234, 53, 212, 133, 98, 12, 141, 110)
        }), tostring(_ARG_1_)))
        return nil, nil
      end
      if not _ARG_0_:GetAvailableSlotIndex() then
        return nil, nil
      end
      if not _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()] or not slua.isValid(_ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh) then
        return nil, nil
      end
      if not _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld() then
        return nil, nil
      end
      if not _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation() then
        return nil, nil
      end
      if not slua.isValid((U5.SpawnActorRobust(U4.Blueprint.MonsterActor, U2(_ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Z + 20.0), _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():Rotator() or U3(0.0, 0.0, 0.0), U2(1.0, 1.0, 1.0)))) then
        return nil, nil
      end
      U5.SpawnActorRobust(U4.Blueprint.MonsterActor, U2(_ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Z + 20.0), _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():Rotator() or U3(0.0, 0.0, 0.0), U2(1.0, 1.0, 1.0)).SlotIndex = _ARG_0_:GetAvailableSlotIndex(), _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()], _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld(), _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation(), _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():Rotator(), 20.0, U2(_ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Z + 20.0), _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():Rotator() or U3(0.0, 0.0, 0.0), U4.Blueprint.MonsterActor, U5.SpawnActorRobust(U4.Blueprint.MonsterActor, U2(_ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Z + 20.0), _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():Rotator() or U3(0.0, 0.0, 0.0), U2(1.0, 1.0, 1.0)), U5.SpawnActorRobust(U4.Blueprint.MonsterActor, U2(_ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Z + 20.0), _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():Rotator() or U3(0.0, 0.0, 0.0), U2(1.0, 1.0, 1.0)):InitByID(_ARG_1_, _ARG_2_)
      do return U5.SpawnActorRobust(U4.Blueprint.MonsterActor, U2(_ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():GetLocation().Z + 20.0), _ARG_0_.MonsterSlots[_ARG_0_:GetAvailableSlotIndex()].Mesh:K2_GetComponentToWorld():Rotator() or U3(0.0, 0.0, 0.0), U2(1.0, 1.0, 1.0)), (_ARG_0_:GetAvailableSlotIndex()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[140]
    end
  end,
  ["SpawnMonsterInSlot"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if Client then
        return nil
      end
      if not _ARG_1_ or type(_ARG_1_) ~= U1(19, 148, 52, 107, 123, 97) or _ARG_1_ <= 0 then
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 6, 40, 135, 246, 88, 242, 175, 74, 93, 155, 65, 122, 29),
          U1(46, 141, 54, 125, 62, 62, 115, 26, 144, 86, 44, 10, 48, 132, 168, 104, 226, 191, 90, 77, 139, 81, 3, 42, 170, 107, 120, 5, 20)
        }), tostring(_ARG_1_)))
        return nil
      end
      if not _ARG_0_:IsValidSlotIndex(_ARG_2_) then
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 6, 40, 135, 246, 88, 242, 175, 74, 93, 155, 65, 122, 29),
          U1(46, 141, 54, 125, 62, 62, 115, 26, 144, 86, 44, 10, 48, 132, 168, 118, 225, 190, 93, 25, 135, 77, 71, 6, 150, 107, 120, 5, 20)
        }), tostring(_ARG_2_)))
        return nil
      end
      if not _ARG_0_:IsSlotEmpty(_ARG_2_) then
        print(bWriteLog and string.format(table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 6, 40, 135, 246, 88, 242, 175, 74, 93, 155, 65, 122, 29),
          U1(46, 141, 54, 125, 62, 62, 115, 0, 146, 79, 57, 61, 124, 132, 213, 37, 228, 162, 9, 87, 129, 87, 3, 6, 131, 64, 41, 15)
        }), _ARG_2_))
        return nil
      end
      if not _ARG_0_.MonsterSlots[_ARG_2_] or not slua.isValid(_ARG_0_.MonsterSlots[_ARG_2_].Mesh) then
        return nil
      end
      if not _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld() then
        return nil
      end
      if not _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation() then
        return nil
      end
      if not slua.isValid((U5.SpawnActorRobust(U2.Blueprint.MonsterActor, U3(_ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().Z + (U2.Spawn and U2.Spawn.HeightOffset or 20.0)), _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():Rotator() or U4(0.0, 0.0, 0.0), U3(1.0, 1.0, 1.0)))) then
        return nil
      end
      U5.SpawnActorRobust(U2.Blueprint.MonsterActor, U3(_ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().Z + (U2.Spawn and U2.Spawn.HeightOffset or 20.0)), _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():Rotator() or U4(0.0, 0.0, 0.0), U3(1.0, 1.0, 1.0)).SlotIndex = _ARG_2_
      if not _ARG_0_:AddMonster(U5.SpawnActorRobust(U2.Blueprint.MonsterActor, U3(_ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().Z + (U2.Spawn and U2.Spawn.HeightOffset or 20.0)), _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():Rotator() or U4(0.0, 0.0, 0.0), U3(1.0, 1.0, 1.0)), _ARG_2_) then
        return nil
      end
      do return (U5.SpawnActorRobust(U2.Blueprint.MonsterActor, U3(_ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().X, _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().Y, _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():GetLocation().Z + (U2.Spawn and U2.Spawn.HeightOffset or 20.0)), _ARG_0_.MonsterSlots[_ARG_2_].Mesh:K2_GetComponentToWorld():Rotator() or U4(0.0, 0.0, 0.0), U3(1.0, 1.0, 1.0))) end
      do return end
      _ARG_2_ = _ENV[36]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSkinID"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if type(_ARG_1_) ~= U1(19, 148, 52, 107, 123, 97) then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 19, 61, 163, 243, 124, 243, 136, 125, 9, 211, 19, 90, 29),
          U1(11, 128, 53, 96, 122, 51, 39, 42, 142, 69)
        }))
        return
      end
      if _ARG_0_.SkinID == _ARG_1_ then
        printf(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 19, 61, 163, 243, 124, 243, 136, 125, 9, 211, 19, 64, 18),
          U1(16, 132, 121, 96, 122)
        }))
        return
      end
      if not U2.GetBaseSkin()[_ARG_1_] then
        return
      end
      _ARG_0_.SkinID = _ARG_1_
      if CDataTable.GetTableData(U1(45, 141, 56, 103, 92, 71, 17, 50, 141, 69, 30, 13, 48, 142, 203, 106, 227, 183, 64, 94), _ARG_0_.SkinID) and CDataTable.GetTableData(U1(45, 141, 56, 103, 92, 71, 17, 50, 141, 69, 30, 13, 48, 142, 203, 106, 227, 183, 64, 94), _ARG_0_.SkinID).BuffRatio_f then
        if slua.isValid((U3.GetPlayerController(_ARG_0_.nOwnerPlayerKey))) then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateMonsterSlotInfo"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CalculateOfflineCoinProduction"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      printf(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 23, 37, 147, 237, 121, 252, 181, 92, 102, 152, 85, 95, 26),
        U1(19, 132, 26, 102, 119, 125, 3, 33, 145, 68, 56, 5, 45, 137, 231, 107, 173, 129, 69, 88, 151, 70, 81, 40, 139, 73, 6, 83, 58, 173)
      }), tostring(_ARG_2_))
      if not slua.isValid(_ARG_0_.OwnerCharacter) then
        print(bWriteLog and table.concat({
          U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 30, 23, 37, 147, 237, 121, 252, 181, 92, 102, 152, 85, 95, 26),
          U1(19, 132, 26, 102, 119, 125, 3, 33, 145, 68, 56, 5, 45, 137, 231, 107, 173, 252, 9, 112, 128, 85, 66, 15, 135, 84, 125, 57, 62, 158, 253, 103, 222, 169, 88, 91, 159, 80, 71, 22),
          U1(15)
        }))
        return
      end
      if not slua.isValid((_ARG_0_.OwnerCharacter:GetPlayerControllerSafety())) then
        return
      end
      if not _ARG_0_.OwnerCharacter:GetPlayerControllerSafety().CoinFeature then
        return
      end
      if type((SubsystemMgr:Get((U1(62, 147, 60, 104, 106, 122, 37, 54, 174, 76, 44, 31, 60, 146, 199, 99, 235, 189, 64, 87, 139, 103, 66, 23, 143, 99, 40, 20, 58, 137, 235, 97, 248, 172))):GetPlayerOfflineDuration(_ARG_2_))) ~= U1(19, 148, 52, 107, 123, 97) then
        return
      end
      if math.floor((SubsystemMgr:Get((U1(62, 147, 60, 104, 106, 122, 37, 54, 174, 76, 44, 31, 60, 146, 199, 99, 235, 189, 64, 87, 139, 103, 66, 23, 143, 99, 40, 20, 58, 137, 235, 97, 248, 172))):GetPlayerOfflineDuration(_ARG_2_))) > require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 102, 152, 85, 95, 26),
        U1(19, 132, 26, 102, 119, 125, 16, 60, 144, 70, 36, 1)
      }))).MaxOfflineDuration then
      end
      goto lbl_968
      if 0 < (U2(tostring(require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 102, 152, 85, 95, 26),
        U1(19, 132, 26, 102, 119, 125, 16, 60, 144, 70, 36, 1)
      }))).MaxOfflineDuration)) and U3.CalculateProductionEfficiency(U2(tostring(require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 102, 152, 85, 95, 26),
        U1(19, 132, 26, 102, 119, 125, 16, 60, 144, 70, 36, 1)
      }))).MaxOfflineDuration))) or 0) then
      end
      ::lbl_968::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if (0 + (U2(tostring(require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 102, 152, 85, 95, 26),
        U1(19, 132, 26, 102, 119, 125, 16, 60, 144, 70, 36, 1)
      }))).MaxOfflineDuration)) and U3.CalculateProductionEfficiency(U2(tostring(require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 102, 152, 85, 95, 26),
        U1(19, 132, 26, 102, 119, 125, 16, 60, 144, 70, 36, 1)
      }))).MaxOfflineDuration))) or 0)) / require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 102, 152, 85, 95, 26),
        U1(19, 132, 26, 102, 119, 125, 16, 60, 144, 70, 36, 1)
      }))).DecayFactor * require((table.concat({
        U1(58, 128, 52, 108, 82, 102, 50, 125, 179, 79, 41, 72, 9, 140, 233, 107, 207, 133, 7, 126, 143, 78, 70, 19, 130, 81, 36, 88, 10, 159, 246, 115, 244, 166, 23, 102, 152, 85, 95, 26),
        U1(19, 132, 26, 102, 119, 125, 16, 60, 144, 70, 36, 1)
      }))).MaxOfflineDuration == 0 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateAllAIPerceptionInfo"] = function(_ARG_0_)
    do
      if slua.isValid(_ARG_0_.OwnerCharacter) then
        EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_MLAI_SPECIALZONE_STATECHANGE, _ARG_0_.Object, 0, _ARG_0_.OwnerCharacter.PlayerKey)
      else
        EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_MLAI_SPECIALZONE_STATECHANGE, _ARG_0_.Object, 0, 0)
      end
      EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_MLAI_SPECIALZONE_CUSTOM_ATTRIBUTE_CHANGE, _ARG_0_.Object, 1, _ARG_0_.RebirthCount)
      EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_MLAI_SPECIALZONE_CUSTOM_ATTRIBUTE_CHANGE, _ARG_0_.Object, 2, _ARG_0_.nUnlockTime)
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_0_.CoinSlotMgr then
        _ARG_0_ = _ARG_0_
        if 0 < _ARG_0_.CoinSlotMgr:GetSlotCoinCount((_ARG_0_:UpdateMonsterSlotInfo(_ARG_0_.MonsterSlots[EVENTID_MLAI_SPECIALZONE_CUSTOM_ATTRIBUTE_CHANGE]))) then
        end
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCoinSlotInfo"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      if not _ARG_1_ or _ARG_1_ <= 0 then
        return
      end
      EventSystem:postEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_MLAI_SPECIALZONE_CUSTOM_ATTRIBUTE_CHANGE, _ARG_0_.Object, _ARG_1_, _ARG_2_ or 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReportSlotCoinCount"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if Client then
        return
      end
      if not _ARG_1_ or _ARG_1_ <= 0 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayAreaBeginOverlapFunc"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not Game:IsClassOf(_ARG_2_, (import((table.concat({
        U1(82, 178, 58, 123, 119, 99, 39, 124, 173, 72, 44, 2, 54, 151, 220, 119, 236, 178, 66, 92, 156, 102, 91, 23, 156, 81, 115, 37, 29, 181, 224, 97, 239, 160, 105, 69, 159, 74, 86, 1),
        U1(62, 137, 56, 123, 127, 112, 39, 54, 140)
      }))))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayAreaEndOverlapFunc"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not Game:IsClassOf(_ARG_2_, (import((table.concat({
        U1(82, 178, 58, 123, 119, 99, 39, 124, 173, 72, 44, 2, 54, 151, 220, 119, 236, 178, 66, 92, 156, 102, 91, 23, 156, 81, 115, 37, 29, 181, 224, 97, 239, 160, 105, 69, 159, 74, 86, 1),
        U1(62, 137, 56, 123, 127, 112, 39, 54, 140)
      }))))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientPlayAreaBeginOverlap"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not Game:IsClassOf(_ARG_2_, (import((table.concat({
        U1(82, 178, 58, 123, 119, 99, 39, 124, 173, 72, 44, 2, 54, 151, 220, 119, 236, 178, 66, 92, 156, 102, 91, 23, 156, 81, 115, 37, 29, 181, 224, 97, 239, 160, 105, 69, 159, 74, 86, 1),
        U1(62, 137, 56, 123, 127, 112, 39, 54, 140)
      }))))) then
        return
      end
      if not slua.isValid((U2.GetPlayerCharacter())) or _ARG_2_ ~= U2.GetPlayerCharacter() then
        return
      end
      _ARG_0_.bClientLocalPlayerInArea = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClientPlayAreaEndOverlap"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not Game:IsClassOf(_ARG_2_, (import((table.concat({
        U1(82, 178, 58, 123, 119, 99, 39, 124, 173, 72, 44, 2, 54, 151, 220, 119, 236, 178, 66, 92, 156, 102, 91, 23, 156, 81, 115, 37, 29, 181, 224, 97, 239, 160, 105, 69, 159, 74, 86, 1),
        U1(62, 137, 56, 123, 127, 112, 39, 54, 140)
      }))))) then
        return
      end
      if not slua.isValid((U2.GetPlayerCharacter())) or _ARG_2_ ~= U2.GetPlayerCharacter() then
        return
      end
      _ARG_0_.bClientLocalPlayerInArea = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerOnPlayerEnterOrLeave"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_0_.OwnerCharacter) then
        print(bWriteLog and table.concat({
          U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 130, 76, 75, 152, 70, 81, 44, 128, 96, 49, 23, 48, 149, 234, 80, 243, 181, 92, 91, 177, 65, 127, 22),
          U1(28, 151, 60, 41, 81, 100, 61, 54, 140, 99, 37, 7, 43, 129, 235, 113, 232, 163, 9, 80, 128, 85, 66, 15, 135, 84)
        }))
        return
      end
      if _ARG_0_.OwnerCharacter:GetEnsure() then
        print(bWriteLog and table.concat({
          U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 130, 76, 75, 152, 70, 81, 44, 128, 96, 49, 23, 48, 149, 234, 80, 243, 181, 92, 91, 177, 65, 127, 22),
          U1(28, 151, 60, 41, 89, 118, 39, 22, 144, 83, 56, 20, 60)
        }))
        return
      end
      if not slua.isValid(_ARG_1_) then
        print(bWriteLog and table.concat({
          U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 130, 76, 75, 152, 70, 81, 44, 128, 96, 49, 23, 48, 149, 234, 80, 243, 181, 92, 91, 177, 65, 127, 22),
          U1(28, 151, 60, 41, 107, 80, 59, 50, 140, 65, 46, 18, 60, 146, 168, 108, 227, 167, 72, 85, 135, 71)
        }))
        return
      end
      if _ARG_2_ then
        _ARG_0_.OverlapList[_ARG_1_.PlayerKey] = true
        if not _ARG_0_.nOwnerPlayerKey or _ARG_0_.nOwnerPlayerKey <= 0 then
          print(bWriteLog and table.concat({
            U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 130, 76, 75, 152, 70, 81, 44, 128, 96, 49, 23, 48, 149, 234, 80, 243, 181, 92, 91, 177, 65, 127, 22),
            U1(28, 151, 60, 41, 112, 92, 36, 61, 155, 82, 29, 10, 56, 153, 237, 119, 198, 180, 80, 25, 135, 77, 85, 2, 130, 89, 57)
          }))
          return
        end
        print(bWriteLog and string.format(table.concat({
          U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 130, 76, 75, 152, 70, 81, 44, 128, 96, 49, 23, 48, 149, 234, 80, 243, 181, 92, 91, 177, 65, 127, 22),
          U1(28, 151, 60, 41, 124, 86, 61, 39, 155, 82, 119, 67, 42, 192, 253, 70, 229, 176, 91, 88, 141, 87, 70, 17, 212, 21, 46)
        }), tostring(_ARG_2_), _ARG_1_:GetPlayerNameSafety()))
        if _ARG_0_:IsCharacterInvited(_ARG_1_.PlayerKey) then
          return
        end
        if _ARG_0_.OwnerCharacter == _ARG_1_ then
          print(bWriteLog and table.concat({
            U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 130, 76, 75, 152, 70, 81, 44, 128, 96, 49, 23, 48, 149, 234, 80, 243, 181, 92, 91, 177, 65, 127, 22),
            U1(28, 151, 60, 41, 119, 96, 115, 60, 137, 78, 40, 20)
          }))
          return
        end
        if not slua.isValid(_ARG_0_.OwnerCharacter.PlayerState) then
          return
        end
        if not _ARG_0_.OwnerCharacter.PlayerState:CheckIngameBuffValid(U2.StealAlertBuff) then
          return
        end
      else
        print(bWriteLog and string.format(table.concat({
          U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 130, 76, 75, 152, 70, 81, 44, 128, 96, 49, 23, 48, 149, 234, 80, 243, 181, 92, 91, 177, 65, 127, 22),
          U1(28, 151, 60, 41, 124, 86, 61, 39, 155, 82, 119, 67, 42, 192, 253, 70, 229, 176, 91, 88, 141, 87, 70, 17, 212, 21, 46)
        }), tostring(_ARG_2_), _ARG_1_:GetPlayerNameSafety()))
        _ARG_0_.OverlapList[_ARG_1_.PlayerKey] = false
        _ARG_0_:ServerRemoveInfraredAlarmOnIntruder(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StealAlert"] = function(_ARG_0_)
    do
      if CGameState:GetServerWorldTimeSeconds() - _ARG_0_.LastStealAlertTime < _ARG_0_.StealAlertCD then
        return
      end
      _ARG_0_.LastStealAlertTime = CGameState:GetServerWorldTimeSeconds()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckOverlapList"] = function(_ARG_0_)
    do
      goto lbl_15
      if nil and not _ARG_0_:IsCharacterInvited(nil) then
        return
      end
      ::lbl_15::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCharacterInvited"] = function(_ARG_0_, _ARG_1_)
    do
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerStartInfraredAlarmByOwnerBuff"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.InfraredAlarmBuffState ~= U1.Inactive then
        print(bWriteLog and table.concat({
          U2(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 130, 76, 75, 152, 70, 81, 48, 154, 81, 47, 2, 0, 158, 254, 103, 252, 179, 92, 77, 191, 95, 82, 1),
          U2(16, 163, 32, 70, 105, 125, 54, 33, 188, 85, 43, 0, 121, 129, 228, 119, 232, 176, 77, 64, 206, 66, 64, 23, 135, 70, 56)
        }))
        return
      end
      if next(_ARG_0_.InfraredAlarmIntruders) ~= nil then
        _ARG_0_.InfraredAlarmBuffState = U1.Blink
      else
        _ARG_0_.InfraredAlarmBuffState = U1.Steady
      end
      print(bWriteLog and string.format(table.concat({
        U2(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 130, 76, 75, 152, 70, 81, 48, 154, 81, 47, 2, 0, 158, 254, 103, 252, 179, 92, 77, 191, 95, 82, 1),
        U2(16, 163, 32, 70, 105, 125, 54, 33, 188, 85, 43, 0, 121, 147, 252, 100, 249, 180, 114, 28, 138, 126)
      }), _ARG_0_.InfraredAlarmBuffState))
      _ARG_0_:_ServerStartInfraredAlarmWatchdog()
      do return end
      _ARG_0_ = _ENV[176]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerApplyInfraredAlarmOnIntruder"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_1_.PlayerKey or _ARG_1_.PlayerKey <= 0 then
        return
      end
      if _ARG_0_.InfraredAlarmIntruders[_ARG_1_.PlayerKey] then
        return
      end
      _ARG_0_.InfraredAlarmIntruders[_ARG_1_.PlayerKey] = true
      if U3.IntruderAlertTip and 0 < U3.IntruderAlertTip then
        if CGameState:GetServerWorldTimeSeconds() - _ARG_0_.LastIntruderAlertTime < _ARG_0_.IntruderAlertCD then
        else
          _ARG_0_.LastIntruderAlertTime = CGameState:GetServerWorldTimeSeconds()
        end
      end
      if _ARG_0_.InfraredAlarmBuffState == U5.Steady then
        _ARG_0_.InfraredAlarmBuffState = U5.Blink
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerRemoveInfraredAlarmOnIntruder"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_1_.PlayerKey or _ARG_1_.PlayerKey <= 0 then
        return
      end
      if not _ARG_0_.InfraredAlarmIntruders[_ARG_1_.PlayerKey] then
        return
      end
      _ARG_0_.InfraredAlarmIntruders[_ARG_1_.PlayerKey] = nil
      if not next(_ARG_0_.InfraredAlarmIntruders) and _ARG_0_.InfraredAlarmBuffState == U3.Blink then
        _ARG_0_.InfraredAlarmBuffState = U3.Steady
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_InfraredAlarmBuffState"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      print(bWriteLog and string.format(table.concat({
        U1(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 158, 71, 107, 139, 83, 124, 42, 128, 86, 47, 23, 59, 149, 252, 84, 241, 160, 75, 68, 188, 70, 85, 21),
        U1(46, 149, 56, 125, 123, 51, 60, 63, 154, 123, 104, 21, 4, 192, 230, 96, 250, 138, 12, 74, 179)
      }), tostring(_ARG_1_), tostring(_ARG_0_.InfraredAlarmBuffState)))
      if _ARG_0_.InfraredAlarmBuffState == U2.Inactive then
        _ARG_0_:_ClientStopInfraredAlarmFX()
      elseif _ARG_0_.InfraredAlarmBuffState == U2.Steady then
        _ARG_0_:_ClientSpawnInfraredAlarmFX(false)
      elseif _ARG_0_.InfraredAlarmBuffState == U2.Blink then
        _ARG_0_:_ClientSpawnInfraredAlarmFX(true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClientStartInfraredAlarmFX"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if not _ARG_0_.Object or not slua.isValid(_ARG_0_.Object) then
        return
      end
      if slua.isValid(_ARG_0_.InfraredAlarmFXComp) then
        return
      end
      _ARG_0_:_ClientSpawnInfraredAlarmFX(_ARG_0_.InfraredAlarmBuffState == U1.Blink)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClientStopInfraredAlarmFX"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if _ARG_0_.InfraredAlarmFXComp and slua.isValid(_ARG_0_.InfraredAlarmFXComp) then
        _ARG_0_.InfraredAlarmFXComp:K2_DestroyComponent(_ARG_0_.InfraredAlarmFXComp)
      end
      _ARG_0_.InfraredAlarmFXComp = nil
      if _ARG_0_.InfraredAlarmFXLoadHandle then
        U1.ClearAssetAsync(_ARG_0_.InfraredAlarmFXLoadHandle)
        _ARG_0_.InfraredAlarmFXLoadHandle = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClientSpawnInfraredAlarmFX"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      if not _ARG_0_.Object or not slua.isValid(_ARG_0_.Object) then
        return
      end
      if _ARG_1_ then
      else
      end
      if _ARG_0_.uInfraredAlarmFX_Steady and slua.isValid(_ARG_0_.uInfraredAlarmFX_Steady) then
        return
      end
      if _ARG_0_.InfraredAlarmFXLoadHandle then
        _ARG_0_.InfraredAlarmFXLoadHandle = nil
      end
      _ARG_0_.InfraredAlarmFXLoadHandle = U7.GetAssetAsync(U1.InfraredAlarmFXPath_Steady, function(_ARG_0_)
        do
          InfraredAlarmFXLoadHandle = nil
          if not (_ENV and Object) or not U1.slua.isValid(Object) then
            return
          end
          if not U1.slua.isValid(_ARG_0_) then
            U1.print(U1.bWriteLog and U1.string.format(U1.table.concat({
              U2(48, 142, 55, 122, 106, 118, 33, 17, 159, 83, 40, 39, 58, 148, 231, 119, 183, 142, 106, 85, 135, 70, 77, 23, 189, 64, 60, 1, 39, 185, 246, 115, 239, 160, 75, 76, 154, 114, 95, 18),
              U2(15, 140, 31, 81, 62, 117, 50, 58, 146, 69, 41, 70, 45, 143, 168, 105, 226, 176, 77, 98, 203, 80, 126)
            }), U1.tostring(U3)))
            return
          end
          if U4 then
            uInfraredAlarmFX_Blink = _ARG_0_
          else
            uInfraredAlarmFX_Steady = _ARG_0_
          end
          if InfraredAlarmBuffState == (U4 and U5.Blink or U5.Steady) then
          end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ServerStartInfraredAlarmWatchdog"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.InfraredAlarmServerWatchdog then
        _ARG_0_:RemoveGameTimer(_ARG_0_.InfraredAlarmServerWatchdog)
        _ARG_0_.InfraredAlarmServerWatchdog = nil
      end
      _ARG_0_.InfraredAlarmServerWatchdog = _ARG_0_:AddGameTimer(1.0, true, function()
        if not (_ENV and Object) or not U1.slua.isValid(Object) then
          return
        end
        if InfraredAlarmBuffState == U2.Inactive then
          return
        end
        if not U1.slua.isValid(OwnerCharacter) then
          _ENV:_ServerForceStopInfraredAlarm()
          return
        end
        if not U1.slua.isValid(OwnerCharacter.PlayerState) then
          return
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ServerStopInfraredAlarmWatchdog"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      if _ARG_0_.InfraredAlarmServerWatchdog then
        _ARG_0_:RemoveGameTimer(_ARG_0_.InfraredAlarmServerWatchdog)
        _ARG_0_.InfraredAlarmServerWatchdog = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ServerForceStopInfraredAlarm"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      goto lbl_27
      ::lbl_27::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.InfraredAlarmIntruders = {}
      if _ARG_0_.InfraredAlarmBuffState ~= U3.Inactive then
        _ARG_0_.InfraredAlarmBuffState = U3.Inactive
      end
      _ARG_0_:_ServerStopInfraredAlarmWatchdog()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MulticastRPC_SyncSlotCoinCount"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.CoinSlotMgr then
        _ARG_0_.CoinSlotMgr:HandleSyncSlotCoinCount(_ARG_1_, _ARG_2_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_SlotCoinStates"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.CoinSlotMgr then
        _ARG_0_.CoinSlotMgr:OnRep_SlotCoinStates(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_SlotCollectVersions"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.CoinSlotMgr then
        _ARG_0_.CoinSlotMgr:OnRep_SlotCollectVersions(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartAICoinReportingTimer"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      _ARG_0_:StopAICoinReportingTimer()
      _ARG_0_.AICoinReportingTimer = _ARG_0_:AddGameTimer(3.0, true, function()
        _ENV:TickAICoinReporting()
        return
      end)
      print(bWriteLog and table.concat({
        U1(38, 177, 53, 104, 112, 81, 7, 14, 222, 109, 34, 8, 42, 148, 237, 119, 207, 176, 90, 92, 175, 64, 87, 12, 156, 10, 14, 2, 40, 130, 236, 84, 212, 130, 86, 64, 144, 97, 86, 3),
        U1(18, 147, 45, 96, 112, 116, 7, 58, 147, 69, 63, 70, 116, 192, 201, 76, 173, 178, 70, 80, 128, 3, 81, 6, 158, 95, 47, 2, 32, 158, 255, 53, 233, 168, 84, 76, 140, 19, 64, 7),
        U1(28, 147, 45, 108, 122, 51, 123, 96, 141, 0, 36, 8, 45, 133, 250, 115, 236, 189, 0)
      }))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopAICoinReportingTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.AICoinReportingTimer then
        _ARG_0_:RemoveGameTimer(_ARG_0_.AICoinReportingTimer)
        _ARG_0_.AICoinReportingTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TickAICoinReporting"] = function(_ARG_0_)
    do
      _ARG_0_:TickSlotCoin()
      goto lbl_95
      ::lbl_95::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TickSlotCoin"] = function(_ARG_0_)
    do
      if not _ARG_0_.nOwnerPlayerKey or _ARG_0_.nOwnerPlayerKey <= 0 then
        return
      end
      if not _ARG_0_.CoinSlotMgr then
        return
      end
      if not _ARG_0_.SlotCoinStates then
        return
      end
      if 0 >= (_ARG_0_.SlotCount or 0) then
        return
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_.SlotCoinStates:Get(_ARG_0_.SlotCoinStates:Num() - 1) == 1 then
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
