local TopSquadActor = {}
TopSquadActor.RUNE_TOWER_ACTOR_PATH = "/Game/Mod/IceWorld5/BluePrints/Actor/BP_IceWorld5RuneTower.BP_IceWorld5RuneTower_C"
TopSquadActor.POI_NOT_FINISHED_TIPS_ID = 4701312
TopSquadActor.AUDIO_IGNITE_PATH = "/Game/Mod/IceWorld5/WwiseEvent/IceWorld5_TopTeam_470/Play_IceWorld5_TopTeam_Ignite.Play_IceWorld5_TopTeam_Ignite"
TopSquadActor.AUDIO_FIRE_LOOP_PLAY_PATH = "/Game/Mod/IceWorld5/WwiseEvent/IceWorld5_TopTeam_470/Play_IceWorld5_TopTeam_Fire_Loop.Play_IceWorld5_TopTeam_Fire_Loop"
TopSquadActor.AUDIO_FIRE_LOOP_STOP_PATH = "/Game/Mod/IceWorld5/WwiseEvent/IceWorld5_TopTeam_470/Stop_IceWorld5_TopTeam_Fire_Loop.Stop_IceWorld5_TopTeam_Fire_Loop"
TopSquadActor.AUDIO_STATUE_PATH = "/Game/Mod/IceWorld5/WwiseEvent/IceWorld5_TopTeam_470/Play_IceWorld5_TopTeam_Statue.Play_IceWorld5_TopTeam_Statue"

function TopSquadActor:ctor()
  self.DisableClimbing = true
  self.DisableTweenWhenSM = true
  self.InteractiveEffectPath = {
    {
      "/Game/Mod/IceWorld5/Arts_Effect/Par/P_SM_IceWorld5_SquadPlatform_01_L3.P_SM_IceWorld5_SquadPlatform_01_L3",
      FVector(-205, -380, 200),
      0
    },
    {
      "/Game/Mod/IceWorld5/Arts_Effect/Par/P_SM_IceWorld5_SquadPlatform_01_L3.P_SM_IceWorld5_SquadPlatform_01_L3",
      FVector(205, -380, 200),
      0
    }
  }
  self.ParticleSystemPath = {
    {
      "/Game/Mod/IceWorld5/Arts_Effect/Par/P_SM_IceWorld5_SquadPlatform_03_L4.P_SM_IceWorld5_SquadPlatform_03_L4",
      FVector(0, -430, 200),
      0.25
    },
    {
      "/Game/Mod/IceWorld5/Arts_Effect/Par/P_SM_IceWorld5_SquadPlatform_02_L2.P_SM_IceWorld5_SquadPlatform_02_L2",
      FVector(0, -430, 300),
      0.25
    },
    {
      "/Game/Mod/IceWorld5/Arts_Effect/Par/P_SM_IceWorld5_SquadPlatform_04_L2.P_SM_IceWorld5_SquadPlatform_04_L2",
      FVector(0, -430, 300),
      1.5
    },
    {
      "/Game/Mod/IceWorld5/Arts_Effect/Par/P_SM_IceWorld5_SquadPlatform_05_L3.P_SM_IceWorld5_SquadPlatform_05_L3",
      FVector(0, -230, -40),
      2
    },
    {
      "/Game/Mod/IceWorld5/Arts_Effect/Par/P_SM_IceWorld5_SquadPlatform_06_L4.P_SM_IceWorld5_SquadPlatform_06_L4",
      FVector(0, -230, 0),
      2.25
    }
  }
  self.ParticlePlayedIndex = 0
  self.InteractiveEffectPlayedIndex = 0
  self.ShowPawnDelay = 2
  self.bShowPawnCreated = false
  self.InteractiveEffectCount = 0
  self.bFireLoopAudioOn = false
  self.FireLoopPlayingID = nil
end

function TopSquadActor:ReceiveBeginPlay()
  TopSquadActor.__super.ReceiveBeginPlay(self)
  if Client then
    self:ResumeFireLoopAudioIfNeeded()
    self:ShowInteractiveEffect()
    self:ShowParticleSystem()
  else
    self:SyncInteractiveEffectCountFromRuneTowers()
    self:AddCommonEventWithConditions(EVENTTYPE_INGAME_NORMAL, EVENTID_GAME_MODE_STATE_CHANGE, {
      [1] = "FightingState"
    }, self.HandleEnterFighting, self)
    self:AddCommonEvent(EVENTTYPE_ICEWORLD5_NORMAL, EVENTID_IW5_POI_AREA_FINISHED, self.TryShowMarks, self)
    self:TryShowMarks()
  end
end

function TopSquadActor:BeginPlayImpl()
  TopSquadActor.__super.__super.BeginPlayImpl(self)
  if self.hasAuthority then
    if self.bEnableSM == true then
      self:FlushNetDormancyOnceForReplay()
      self.StateMachine:SetState(self.EState.Spawned)
    end
    self:ReportTreasureTLog(self.ETLogType.TLogSpawn)
  else
    if self.bOpened == true then
      self:OpenChest()
    end
    self:DisableComponentTickFunction()
  end
end

function TopSquadActor:_PostConstruct()
  TopSquadActor.__super._PostConstruct(self)
  print(bWriteLog and "TopSquadActor:_PostConstruct")
end

function TopSquadActor:GetLifetimeReplicatedProps()
  local BaseRepTable = TopSquadActor.__super:GetLifetimeReplicatedProps() or {}
  local ELifetimeCondition = import("/Script/CoreUObject.ELifetimeCondition")
  local RepTable = {
    {
      "InteractiveEffectCount",
      ELifetimeCondition.COND_None,
      UEnums.EPropertyClass.Int
    }
  }
  table.move(BaseRepTable, 1, #BaseRepTable, #RepTable + 1, RepTable)
  return RepTable
end

function TopSquadActor:OnAllowToClickButton(Character, Component)
  local Result = TopSquadActor.__super.OnAllowToClickButton(self, Character, Component)
  if Result == true and CGameState and CGameState.IceWorld5POIAreaFinished == false then
    self:ShowPOINotFinishedTips(Character)
    return false
  end
  return Result
end

function TopSquadActor:ShowPOINotFinishedTips(Character)
  local TipsID = TopSquadActor.POI_NOT_FINISHED_TIPS_ID or 0
  if TipsID <= 0 or Client or not slua.isValid(Character) then
    return
  end
  if Game:IsAI(Character) then
    return
  end
  local PlayerKey = Character.PlayerKey
  if PlayerKey == nil or PlayerKey <= 0 then
    print(bWriteLog and "TopSquadActor:ShowPOINotFinishedTips, bad PlayerKey = " .. tostring(PlayerKey))
    return
  end
  Game:UIShowImageTips(PlayerKey, TipsID)
  print(bWriteLog and "TopSquadActor:ShowPOINotFinishedTips, TipsID = " .. tostring(TipsID) .. ", PlayerKey = " .. tostring(PlayerKey))
end

function TopSquadActor:CanOpenByStateMachine()
  if self.bEnableSM == true then
    return self.StateMachine:GetState() == self.EState.Activated
  else
    return true
  end
end

function TopSquadActor:OnAnimationStateChanged()
  if self.hasAuthority == true then
    local CurrentState = self.StateMachine:GetState()
    print(bWriteLog and "TopSquadActor:OnAnimationStateChanged, CurrentState = " .. tostring(CurrentState))
  else
    local CurrentState = self.StateMachine:GetState()
    print(bWriteLog and "TopSquadActor:OnAnimationStateChanged, CurrentState = " .. tostring(CurrentState))
  end
end

function TopSquadActor:MustCheckResultAfterSkillFinished(Character, Result, Component)
  TopSquadActor.__super.MustCheckResultAfterSkillFinished(self, Character, Result, Component)
  if not Client and Result == true then
    local PlayerKey = Character.PlayerKey
    local TeamID = Character.TeamID
    local PlayerKeyForEffigy = {}
    local SelfPlayerState = Character:GetPlayerStateSafety()
    local TeammatesState = CGame:GetTeamMatePlayerStateList(PlayerKey, false)
    local TeamAttackUtil = require("GameLua.Mod.BaseMod.GamePlay.Core.TeamAttackUtil")
    for index = 0, TeammatesState:Num() - 1 do
      local uTeammatePlayerState = TeammatesState:Get(index)
      if uTeammatePlayerState and slua.isValid(uTeammatePlayerState) and TeamAttackUtil.IsTeammateAttackByPlayerState(SelfPlayerState, uTeammatePlayerState) then
        table.insert(PlayerKeyForEffigy, uTeammatePlayerState.PlayerKey)
        print(bWriteLog and "TopSquadActor:MustCheckResultAfterSkillFinished, Add PlayerKey = " .. tostring(uTeammatePlayerState.PlayerKey))
      end
    end
    if #PlayerKeyForEffigy == 0 then
      table.insert(PlayerKeyForEffigy, PlayerKey)
      print(bWriteLog and "TopSquadActor:MustCheckResultAfterSkillFinished, Add Self PlayerKey = " .. tostring(PlayerKey))
    end
    self.StrongestSquadFeature:ShowVictoryTeam(PlayerKeyForEffigy, TeamID, self.RevivePosition, self.SummonActorLocation)
  end
end

function TopSquadActor:OnRep_bOpened()
  TopSquadActor.__super.OnRep_bOpened(self)
  self:ShowParticleSystem()
end

function TopSquadActor:PlayNextInteractiveEffect()
  if Client then
    return
  end
  self:SetInteractiveEffectCount((self.InteractiveEffectCount or 0) + 1)
end

function TopSquadActor:SyncInteractiveEffectCountFromRuneTowers()
  if Client then
    return
  end
  local ActorTools = require("GameLua.Mod.BaseMod.Common.ActorTools")
  local uTowerArray = ActorTools.GetAllActors(self.Object, TopSquadActor.RUNE_TOWER_ACTOR_PATH)
  if uTowerArray == nil then
    print(bWriteLog and "TopSquadActor:SyncInteractiveEffectCountFromRuneTowers, no rune tower found")
    return
  end
  local ConsumedCount = 0
  for _, uTower in pairs(uTowerArray) do
    if slua.isValid(uTower) and uTower:IsRuneConsumed() == true then
      ConsumedCount = ConsumedCount + 1
    end
  end
  print(bWriteLog and "TopSquadActor:SyncInteractiveEffectCountFromRuneTowers, TowerNum = " .. tostring(uTowerArray:Num()) .. ", ConsumedCount = " .. tostring(ConsumedCount))
  self:SetInteractiveEffectCount(ConsumedCount)
end

function TopSquadActor:SetInteractiveEffectCount(NewCount)
  if Client then
    return
  end
  local MaxCount = self.InteractiveEffectPath and #self.InteractiveEffectPath or 0
  if NewCount > MaxCount then
    NewCount = MaxCount
  end
  local Current = self.InteractiveEffectCount or 0
  if NewCount <= Current then
    print(bWriteLog and "TopSquadActor:SetInteractiveEffectCount, skip, Current = " .. tostring(Current) .. ", NewCount = " .. tostring(NewCount) .. ", MaxCount = " .. tostring(MaxCount))
    return
  end
  self:FlushNetDormancyOnceForReplay()
  self.InteractiveEffectCount = NewCount
  print(bWriteLog and "TopSquadActor:SetInteractiveEffectCount, InteractiveEffectCount = " .. tostring(self.InteractiveEffectCount))
end

function TopSquadActor:OnRep_InteractiveEffectCount(OldValue)
  self:ShowInteractiveEffect()
end

function TopSquadActor:ShowParticleSystem()
  if Client and self.bOpened == true then
    local JustNow = self:IsOpenedJustNow()
    if JustNow == true then
      self:PlayParticleSystemUntil(#self.ParticleSystemPath)
      self:CreateShowPawn(self.ShowPawnDelay)
      self:Play3DAudio(TopSquadActor.AUDIO_STATUE_PATH)
    else
      self:PlayParticleSystemUntil(1)
      self:CreateShowPawn(0)
    end
  end
end

function TopSquadActor:CreateShowPawn(Delay)
  if self.bShowPawnCreated == true then
    return
  end
  self.bShowPawnCreated = true
  if Delay and 0 < Delay then
    self:AddGameTimer(Delay, false, function()
      if self and self.Object and slua.isValid(self.Object) then
        self.StrongestSquadFeature:CreateShowPawnManually()
      end
    end)
  else
    self.StrongestSquadFeature:CreateShowPawnManually()
  end
end

function TopSquadActor:PlayParticleSystemUntil(EndIndex)
  self:PlayEffectListUntil(self.ParticleSystemPath, "ParticlePlayedIndex", EndIndex)
end

function TopSquadActor:ShowInteractiveEffect()
  if Client then
    self:PlayEffectListUntil(self.InteractiveEffectPath, "InteractiveEffectPlayedIndex", self.InteractiveEffectCount, self.OnInteractiveEffectSpawned)
  end
end

function TopSquadActor:OnInteractiveEffectSpawned()
  self:Play3DAudio(TopSquadActor.AUDIO_IGNITE_PATH)
  self:StartFireLoopAudio()
end

function TopSquadActor:Play3DAudio(AudioPath, Callback)
  if not Client or not slua.isValid(self.Object) then
    return
  end
  local audio_util = require("client.common.audio_util")
  audio_util.PlayAudioByActorAsync(AudioPath, self.Object, Callback, true)
end

function TopSquadActor:StartFireLoopAudio()
  if not Client or self.bFireLoopAudioOn == true then
    return
  end
  self.bFireLoopAudioOn = true
  print(bWriteLog and "TopSquadActor:StartFireLoopAudio")
  self:Play3DAudio(TopSquadActor.AUDIO_FIRE_LOOP_PLAY_PATH, function(PlayingID)
    if type(PlayingID) ~= "number" or PlayingID <= 0 then
      return
    end
    if self.bFireLoopAudioOn == true then
      self.FireLoopPlayingID = PlayingID
    else
      local audio_util = require("client.common.audio_util")
      audio_util.StopSound(PlayingID)
    end
  end)
end

function TopSquadActor:ResumeFireLoopAudioIfNeeded()
  if Client and 0 < (self.InteractiveEffectPlayedIndex or 0) then
    self:StartFireLoopAudio()
  end
end

function TopSquadActor:StopFireLoopAudio()
  if not Client or self.bFireLoopAudioOn ~= true then
    return
  end
  self.bFireLoopAudioOn = false
  local PlayingID = self.FireLoopPlayingID
  self.FireLoopPlayingID = nil
  print(bWriteLog and "TopSquadActor:StopFireLoopAudio, PlayingID = " .. tostring(PlayingID))
  local audio_util = require("client.common.audio_util")
  local bStopPosted = false
  if slua.isValid(self.Object) then
    local _, StopID = audio_util.PlayAudioByActor(TopSquadActor.AUDIO_FIRE_LOOP_STOP_PATH, self.Object)
    bStopPosted = type(StopID) == "number" and 0 < StopID
  end
  if not bStopPosted and type(PlayingID) == "number" and 0 < PlayingID then
    audio_util.StopSound(PlayingID)
  end
end

function TopSquadActor:PlayEffectListUntil(EffectList, PlayedIndexKey, EndIndex, OnSpawned)
  if EffectList == nil then
    print(bWriteLog and "TopSquadActor:PlayEffectListUntil, EffectList == nil, Key = " .. tostring(PlayedIndexKey))
    return
  end
  local Count = #EffectList
  if EndIndex == nil or EndIndex > Count then
    EndIndex = Count
  end
  local StartIndex = (self[PlayedIndexKey] or 0) + 1
  if EndIndex < StartIndex then
    print(bWriteLog and "TopSquadActor:PlayEffectListUntil, nothing to play, Key = " .. tostring(PlayedIndexKey) .. ", PlayedIndex = " .. tostring(self[PlayedIndexKey]) .. ", EndIndex = " .. tostring(EndIndex))
    return
  end
  for Index = StartIndex, EndIndex do
    local ParticleInfo = EffectList[Index]
    if ParticleInfo == nil then
      print(bWriteLog and "TopSquadActor:PlayEffectListUntil, ParticleInfo == nil, Index = " .. tostring(Index))
    else
      local EffectPath = ParticleInfo[1]
      local Location = ParticleInfo[2] or FVector(0, 0, 0)
      local Delay = ParticleInfo[3] or 0
      if 0 < Delay then
        self:AddGameTimer(Delay, false, function()
          if self and self.Object and slua.isValid(self.Object) then
            self:ShowEffectByPath(EffectPath, Location, FRotator(0, 0, 0), OnSpawned)
          end
        end)
      else
        self:ShowEffectByPath(EffectPath, Location, FRotator(0, 0, 0), OnSpawned)
      end
    end
  end
  self[PlayedIndexKey] = EndIndex
end

function TopSquadActor:ShowEffectByPath(EffectPath, Location, Rotation, OnSpawned)
  if EffectPath == nil then
    print(bWriteLog and "TopSquadActor:ShowEffectByPath, EffectPath == nil")
    return
  end
  local Util = require("client.slua_ui_framework.util")
  Util.GetAssetAsync(EffectPath, function(uPartcileSystem)
    if uPartcileSystem then
      if self and self.Object and slua.isValid(self.Object) then
        local UGameplayStatics = import("GameplayStatics")
        local EAttachLocation = import("EAttachLocation")
        UGameplayStatics.SpawnEmitterAttachedToActor(uPartcileSystem, self:K2_GetRootComponent(), "None", Location, Rotation, FVector(1, 1, 1), EAttachLocation.KeepRelativeOffset, true)
        print(bWriteLog and "TopSquadActor:ShowEffectByPath, Create")
        if OnSpawned then
          OnSpawned(self)
        end
      else
        print(bWriteLog and "TopSquadActor:ShowEffectByPath, Object invalid")
      end
    else
      print(bWriteLog and "TopSquadActor:ShowEffectByPath, GetAssetAsync failed when path = " .. tostring(EffectPath))
    end
  end)
end

function TopSquadActor:HandleEnterFighting()
  print(bWriteLog and "TopSquadActor:HandleEnterFighting")
end

function TopSquadActor:TryShowMarks()
  if Client or self.bMarkShown == true or not slua.isValid(self.Object) then
    return
  end
  if self.bOpened == true then
    print(bWriteLog and "TopSquadActor:TryShowMarks, skip, bOpened = " .. tostring(self.bOpened))
    return
  end
  if not CGameState or CGameState.IceWorld5POIAreaFinished ~= true then
    print(bWriteLog and "TopSquadActor:TryShowMarks, POI area not finished")
    return
  end
  self.bMarkShown = true
  print(bWriteLog and "TopSquadActor:TryShowMarks, show marks, MapMarkIconID = " .. tostring(self.MapMarkIconID) .. ", ScreenMarkIconID = " .. tostring(self.ScreenMarkIconID))
  local InGameMarkTools = require("GameLua.Mod.BaseMod.Common.InGameMarkTools")
  if self.MapMarkIconID and self.MapMarkIconID > 0 then
    self.ChestMapMarkAction = InGameMarkTools.ServerAddMapMark(self.MapMarkIconID, self:K2_GetActorLocation(), 1)
  end
  if self.ScreenMarkIconID and self.ScreenMarkIconID > 0 then
    self.ScreenMarkHandle = InGameMarkTools.ServerAddMapMark(self.ScreenMarkIconID, self:K2_GetActorLocation(), 1, UEnums.EAddMarkFlag.EAMF_Screen, 0, nil, nil, self.Object)
  end
end

function TopSquadActor:HandleMapMark_Open()
  if not Client then
    TopSquadActor.__super.HandleMapMark_Open(self)
    if self.ScreenMarkHandle then
      local InGameMarkTools = require("GameLua.Mod.BaseMod.Common.InGameMarkTools")
      InGameMarkTools.HideMapMark(self.ScreenMarkHandle)
      self.ScreenMarkHandle = nil
    end
  end
end

function TopSquadActor:HandleMapMark_EndPlay()
  if not Client then
    TopSquadActor.__super.HandleMapMark_EndPlay(self)
    if self.ScreenMarkHandle then
      local InGameMarkTools = require("GameLua.Mod.BaseMod.Common.InGameMarkTools")
      InGameMarkTools.HideMapMark(self.ScreenMarkHandle)
      self.ScreenMarkHandle = nil
    end
  end
end

function TopSquadActor:EndPlayImpl()
  self:RemoveAllGameTimer()
  self:StopFireLoopAudio()
  self.bShowPawnCreated = false
  TopSquadActor.__super.EndPlayImpl(self)
end

function TopSquadActor:ReceiveEndPlay(EndPlayReason)
  print(bWriteLog and "TopSquadActor:ReceiveEndPlay")
  TopSquadActor.__super.ReceiveEndPlay(self, EndPlayReason)
end

local class = require("class")
local base = require("GameLua.Mod.BaseMod.GamePlay.Actor.TreasureChestActor")
local CTopSquadActor = class(base, nil, TopSquadActor)
return require("combine_class").DeclareFeature(CTopSquadActor, {
  {
    StrongestSquadFeature = "GameLua.Mod.Library.GamePlay.Feature.StrongestSquad.ActorStrongestSquadFeature"
  }
}, "TopSquadActor")
