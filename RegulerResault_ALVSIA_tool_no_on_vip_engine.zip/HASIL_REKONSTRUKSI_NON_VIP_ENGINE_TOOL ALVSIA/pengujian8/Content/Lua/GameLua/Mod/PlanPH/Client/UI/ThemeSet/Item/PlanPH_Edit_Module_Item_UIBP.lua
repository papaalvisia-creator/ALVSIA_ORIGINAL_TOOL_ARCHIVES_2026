local PlanPH_Edit_Module_Item_UIBP = {}

local function _GetDownloadUI(self)
  local commonItem = self.UIRoot and self.UIRoot.Common_Item_BP
  local panel = commonItem and commonItem:GetDownloadPanelHandleWidget()
  if not panel or not slua.isValid(panel) then
    return nil
  end
  local downloadUI = require("client.slua.common.common_download_handler").GetDownloadUINodeByParentNode(panel)
  if downloadUI and slua.isValid(downloadUI) then
    return downloadUI
  end
  return nil
end

function PlanPH_Edit_Module_Item_UIBP:RegistEvents()
  PlanPH_Edit_Module_Item_UIBP.__super.RegistEvents(self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Select, self.OnButton_SelectClick, self)
end

function PlanPH_Edit_Module_Item_UIBP:OnButton_SelectClick()
  log(bWriteLog and "[DeanJYT] PlanPH_Edit_Module_Item_UIBP:OnButton_SelectClick")
  if self:TryTriggerThemeSetDownload() then
    return true
  end
  self:PlayAudio(sound_config.click)
  self:GetLoopScrollBoxParentUI():SelectItem(self.data)
end

function PlanPH_Edit_Module_Item_UIBP:CheckIsSelected()
  return self.data == self:GetLoopScrollBoxParentUI().curSelectedThemeID
end

function PlanPH_Edit_Module_Item_UIBP:CheckHasTheme()
  return self:GetLoopScrollBoxParentUI():CheckHasTheme(self.data)
end

function PlanPH_Edit_Module_Item_UIBP:CheckIsThemeInUse()
  return self:GetLoopScrollBoxParentUI():CheckIsThemeInUse(self.data)
end

function PlanPH_Edit_Module_Item_UIBP:TryTriggerThemeSetDownload()
  local ENUM_DownloadState = require("client.slua.logic.download.puffer_const").ENUM_DownloadState
  local logic_home_download = require("client.slua.logic.home.Download.logic_home_download")
  local keyList = logic_home_download.GetThemeSetDownloadKeyList(self.data)
  local state = logic_home_download.GetKeyListDownloadState(keyList)
  if not state or state == ENUM_DownloadState.Done then
    return false
  end
  local downloadUI = _GetDownloadUI(self)
  if downloadUI then
    local uiState = logic_home_download.GetKeyListDownloadState(downloadUI.data)
    if uiState and uiState ~= ENUM_DownloadState.Done then
      state = uiState
    else
      downloadUI = nil
    end
  end
  printf("PlanPH_Edit_Module_Item_UIBP:TryTriggerThemeSetDownload themeID = %s, state = %s, hasDownloadUI = %s", self.data, state, downloadUI ~= nil)
  if state == ENUM_DownloadState.Download or state == ENUM_DownloadState.Wait then
    self:PlayAudio(sound_config.click)
    return true
  end
  if downloadUI then
    downloadUI:OnClickDownload()
    return true
  end
  logic_home_download.StartKeyListDownload(keyList)
  self.UIRoot.Common_Item_BP:UpdateDownloader()
  return true
end

function PlanPH_Edit_Module_Item_UIBP:OnRefresh(data)
  local itemCfg = CDataTable.GetTableData("Item", data)
  local downloadKeyList = require("client.slua.logic.home.Download.logic_home_download").GetThemeSetDownloadKeyList(data)
  self.UIRoot.Common_Item_BP:InitView(data, 0, 4, 0, false, false, {relativeResIdList = downloadKeyList})
  self.UIRoot.Common_Item_BP:SetRenderScale(FVector2D(1, 1))
  self.UIRoot.Common_Item_BP:SetUseCount(0, false)
  self.UIRoot.Common_Item_BP:ShowItemName()
  local bLimit = self:IsShowLimitIcon(data)
  log(bWriteLog and "PlanPH_Edit_Module_Item_UIBP:OnRefresh data = " .. tostring(data) .. " bLimit = " .. tostring(bLimit))
  self.UIRoot.Common_Item_BP:SetTimeLimitIcon(bLimit)
  self.UIRoot.TextBlock_Name:SetText(itemCfg.ItemName)
  self.UIRoot.Common_Item_BP:SetClickItemCallback(self.OnButton_SelectClick, self)
  if self:CheckIsSelected() then
    self:SetWidgetVisible(self.UIRoot.Common_selected_UIBP, true, false)
  else
    self:SetWidgetVisible(self.UIRoot.Common_selected_UIBP, false, false)
  end
  local quality = itemCfg.ItemQuality
  local UIUtil = require("client.common.ui_util")
  local qualityPath = UIUtil.GetBgQualityPath(quality)
  self:SetTexture(self.UIRoot.Image_QualityBG, qualityPath)
  if self.UIRoot.Common_Item_BP.targetUI then
    if self.UIRoot.Common_Item_BP.targetUI.Image_Bg then
      self:SetWidgetVisible(self.UIRoot.Common_Item_BP.targetUI.Image_Bg, false, false)
    end
    if self.UIRoot.Common_Item_BP.targetUI.Image_Quality then
      self:SetWidgetVisible(self.UIRoot.Common_Item_BP.targetUI.Image_Quality, false, false)
    end
  end
  local bHas = self:CheckHasTheme()
  local bUse = self:CheckIsThemeInUse()
  self:SetWidgetVisible(self.UIRoot.Image_CornerSelect, bUse and bHas, false)
  self:SetWidgetVisible(self.UIRoot.Image_Mask, not bHas, false)
  self:SetWidgetVisible(self.UIRoot.Image_Lock, not bHas, false)
  self:SetWidgetVisible(self.UIRoot.HB_Prosperity, false, false)
  self:SetWidgetVisible(self.UIRoot.HB_StyleScore, false, false)
  local PlanPH_ItemCfg = CDataTable.GetTableData("PlanPH_ItemCfg", data)
  if PlanPH_ItemCfg and not bLimit then
    local prosperity = PlanPH_ItemCfg.Prosperity
    if prosperity then
      self:SetWidgetVisible(self.UIRoot.HB_Prosperity, true, false)
      self.UIRoot.TextBlock_Prosperity:SetText(prosperity)
    end
    local styleValue = PlanPH_ItemCfg.StyleValue
    local styleCfg = CDataTable.GetTableData("PlanPH_StructureStyleCfg", PlanPH_ItemCfg.Style)
    local styleIcon
    if styleCfg then
      styleIcon = styleCfg.IconPath3
    end
    if styleValue and styleIcon and styleIcon ~= "" then
      self:SetWidgetVisible(self.UIRoot.HB_StyleScore, true, false)
      self.UIRoot.TextBlock_Style:SetText(styleValue)
      self:SetTexture(self.UIRoot.Image_Style, styleIcon)
    end
  end
end

function PlanPH_Edit_Module_Item_UIBP:IsShowLimitIcon(itemID)
  local LogicPHomeStore = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicPHomeStore)
  local itemExpireList = LogicPHomeStore:GetItemExpireList()
  local itemCountMap = LogicPHomeStore:GetDepotItemCountMap()
  if itemCountMap[itemID] and 0 < itemCountMap[itemID] and itemExpireList[itemID] then
    local TimeUtil = require("client.common.time_util")
    local time = TimeUtil.GetServerTimeInSec()
    if time < itemExpireList[itemID] then
      return true
    end
  end
  return false
end

local class = require("class")
local scroll_box_child_base = require("client.slua_ui_framework.component.scroll_box_child_base")
local CPlanPH_Edit_Module_Item_UIBP = class(scroll_box_child_base, nil, PlanPH_Edit_Module_Item_UIBP)
return CPlanPH_Edit_Module_Item_UIBP
