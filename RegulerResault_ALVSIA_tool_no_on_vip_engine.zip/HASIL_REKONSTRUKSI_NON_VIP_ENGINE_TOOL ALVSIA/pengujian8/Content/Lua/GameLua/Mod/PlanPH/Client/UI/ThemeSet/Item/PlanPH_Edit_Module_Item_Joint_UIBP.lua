local PlanPH_Edit_Module_Item_Joint_UIBP = {}

function PlanPH_Edit_Module_Item_Joint_UIBP:OnButton_SelectClick()
  print(bWriteLog and "[DeanJYT] PlanPH_Edit_Module_Item_Joint_UIBP:OnButton_SelectClick")
  if self:TryTriggerThemeSetDownload() then
    return true
  end
  self:PlayAudio(sound_config.click)
  self:GetLoopScrollBoxParentUI():SelectItem(self.data, true)
end

function PlanPH_Edit_Module_Item_Joint_UIBP:CheckIsSelected()
  return self:GetLoopScrollBoxParentUI().bSelectingJointTheme
end

function PlanPH_Edit_Module_Item_Joint_UIBP:CheckHasTheme()
  return true
end

function PlanPH_Edit_Module_Item_Joint_UIBP:CheckIsThemeInUse()
  return true
end

local class = require("class")
local PlanPH_Edit_Module_Item_UIBP = require("GameLua.Mod.PlanPH.Client.UI.ThemeSet.Item.PlanPH_Edit_Module_Item_UIBP")
local CPlanPH_Edit_Module_Item_UIBP = class(PlanPH_Edit_Module_Item_UIBP, nil, PlanPH_Edit_Module_Item_Joint_UIBP)
return CPlanPH_Edit_Module_Item_UIBP
