if Client then
  return {
    IngameFlow = {
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 38, 163, 135, 253, 151, 63, 96),
      routes = {c2ds_ingame_flow_setting = true}
    },
    IngameRevive = {
      moduleName = table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 13, 99, 233, 190, 62, 230, 33, 21, 162, 126, 240, 21, 177, 140, 180, 251, 58, 100, 227, 189, 6, 205, 58, 92, 148, 112, 167, 50),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(230, 207, 92, 125, 116, 118, 134, 55, 170, 154, 216, 201, 44, 65, 246, 178, 22, 231, 49)
      }),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 50, 170, 158, 227, 207, 42, 44, 234, 185),
      routes = {
        enter_plane = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 215, 101, 103, 112, 91, 140, 50, 138, 134, 254, 220, 61, 82, 246, 186, 29, 236),
        exit_plane = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 215, 101, 103, 112, 91, 140, 50, 138, 144, 227, 205, 31, 110, 251, 181, 22),
        count_down_before_jump = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 215, 118, 100, 100, 76, 157, 4, 160, 159, 228, 251, 42, 100, 245, 169, 22, 195, 48, 86, 145)
      }
    },
    IngameStore = {
      moduleName = table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 13, 99, 233, 190, 62, 230, 33, 21, 162, 126, 240, 21, 177, 140, 180, 224, 49, 117, 235, 166, 6, 202, 33, 68, 131, 103, 219, 16),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(224, 250, 89, 98, 116, 76, 157)
      }),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 51, 187, 135, 248, 220, 97, 114, 248),
      routes = {
        ingame_store_operate_product = true,
        ingame_store_operate_product_msg = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 201, 80, 121, 112, 86, 140, 16, 189, 135, 238, 204, 44, 118, 215, 168, 20),
        ingame_store_operate_product_multi = true,
        ingame_store_operate_product_end = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 201, 80, 121, 112, 86, 140, 16, 189, 135, 238, 204, 44, 118, 223, 181, 23),
        ingame_store_operate_open = true,
        ingame_store_operate_close = true,
        ingame_store_request_buy = true,
        ingame_store_help_buy = true,
        ingame_store_response_help_buy = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 70, 123, 126, 76, 154, 37, 135, 141, 230, 201, 13, 119, 227),
        ingame_store_response_request_buy = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 70, 123, 126, 76, 154, 37, 157, 141, 251, 204, 42, 113, 238, 153, 6, 240)
      }
    },
    Ban = {
      moduleName = table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 13, 99, 233, 190, 62, 230, 33, 21, 162, 126, 240, 21, 177, 140, 180, 235, 62, 124, 164, 136, 15, 240, 48, 69, 133, 64, 232, 14),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(207, 214, 82, 98, 114)
      }),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 34, 174, 134, 164, 201, 45),
      routes = {
        req_ingame_ban_info = true,
        ingame_voice_ban_switch_notify = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 215, 99, 100, 120, 65, 140, 19, 184, 129, 254, 218, 39, 76, 245, 175, 26, 239, 60),
        ingame_voice_ban_notify = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 215, 99, 100, 120, 65, 140, 2, 174, 134, 196, 214, 59, 107, 252, 162)
      }
    },
    IngameLike = {
      moduleName = table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 13, 99, 233, 190, 62, 230, 33, 21, 162, 126, 240, 21, 177, 140, 180, 229, 54, 121, 239, 229, 42, 247, 50, 74, 156, 103, 197, 9),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(232, 220, 118, 103, 120, 71, 135, 52, 131, 135, 237, 208, 44)
      }),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 44, 166, 131, 239, 151, 63, 96),
      routes = {
        ingame_trigger_like = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 86, 110, 120, 84, 140, 20, 166, 154, 237, 222, 42, 112, 214, 178, 24, 236),
        ingame_trigger_watchlike = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 86, 110, 120, 84, 140, 20, 189, 129, 237, 222, 42, 112, 205, 186, 7, 234, 45, 119, 136, 121, 252),
        ingame_like = true,
        ingame_receive_like = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 86, 110, 120, 84, 140, 12, 166, 131, 239),
        ingame_kill_num_change = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 86, 110, 120, 84, 140, 11, 166, 132, 230, 247, 58, 111, 217, 179, 18, 231, 34, 94),
        ingame_respond_like = true,
        ingame_client_ready = true,
        ingame_client_enter_circle = true,
        ingame_like_switch = true,
        ingame_like_progress = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 86, 110, 120, 84, 140, 12, 166, 131, 239, 233, 61, 109, 253, 169, 22, 250, 54),
        ingame_rp_give = true,
        ingame_rp_give_notify = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 86, 110, 120, 84, 140, 18, 191, 175, 227, 207, 42, 76, 245, 175, 26, 239, 60)
      }
    },
    IngameBattleResult = {
      moduleName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(224, 213, 92, 110, 127, 86, 199, 41, 161, 143, 235, 212, 42, 44, 239, 182, 20, 167, 39, 75, 190, 112, 248, 4, 171, 148, 255, 219, 58, 97, 255, 167, 23),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 34, 174, 156, 254, 213, 42, 93, 232, 190, 0, 252, 41, 79, 207, 98, 251),
      routes = {ingame_battle_result_mvp_statue = true}
    },
    SetValTLog = {
      moduleName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 13, 99, 233, 190, 62, 230, 33, 21, 165, 65, 183, 36, 147, 151, 253, 135, 27, 65, 222, 135, 12, 254, 25, 68, 150, 107, 234),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 52, 163, 135, 237, 151, 63, 96),
      routes = {ingame_set_value_tlog = true}
    },
    AddValTLog = {
      moduleName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 13, 99, 233, 190, 62, 230, 33, 21, 165, 65, 183, 36, 147, 151, 253, 135, 27, 65, 222, 135, 12, 254, 25, 68, 150, 107, 234),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 52, 163, 135, 237, 151, 63, 96),
      routes = {ingame_add_value_tlog = true}
    },
    WinFireworks = {
      moduleName = table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(196, 216, 88, 110, 93, 87, 136, 110, 142, 139, 254, 208, 57, 107, 238, 162, 93, 192, 2, 10, 214, 34, 169, 94, 156, 148, 243, 204, 49, 102, 164, 156, 10, 247, 19, 66, 131, 103, 254, 15),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(241, 210, 70, 72, 125, 75, 140, 46, 187, 164, 229, 222, 38, 97)
      }),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 55, 166, 134, 213, 223, 38, 112, 255, 172, 28, 251, 46, 72, 207, 98, 251),
      routes = {
        ingame_win_fireworks_ready = true,
        ingame_show_win_fireworks = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 86, 110, 120, 84, 140, 19, 167, 135, 253, 238, 38, 108, 220, 178, 1, 236, 50, 84, 147, 121, 234)
      }
    },
    inspection_system_protocol = {
      moduleName = table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 13, 99, 233, 190, 62, 230, 33, 21, 162, 126, 240, 21, 177, 140, 180, 224, 49, 97, 250, 174, 0, 237, 60, 68, 159, 81, 240, 19),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(247, 220, 88, 37, 88, 76, 154, 48, 170, 139, 254, 208, 32, 108, 201, 162, 0, 253, 32, 86, 179, 119, 233, 31, 173, 140, 217, 197, 54, 119, 228, 191, 47, 246, 50, 66, 146, 81, 252, 2),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(240, 192, 70, 127, 116, 79)
      }),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 70, 123, 116, 65, 157, 41, 160, 134, 213, 202, 54, 113, 238, 190, 30, 167, 53, 89),
      routes = {
        inspection_system_report_to_inspector = true,
        inspection_system_notify_inspector = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 86, 125, 95, 77, 157, 41, 169, 145, 195, 215, 60, 114, 255, 184, 7, 230, 55),
        inspection_system_kick_out_one_team = true
      }
    },
    CareerFlag = {
      moduleName = table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 3, 107, 248, 169, 18, 251, 60, 21, 162, 126, 240, 21, 177, 140, 180, 234, 62, 96, 239, 174, 17, 183, 22, 74, 131, 103, 236, 18),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(197, 213, 84, 108, 93, 77, 142, 41, 172)
      }),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(224, 216, 71, 110, 116, 80, 182, 38, 163, 137, 237, 151, 63, 96),
      routes = {
        send_Career_UserInfo_notify = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 86, 125, 95, 77, 157, 41, 169, 145, 201, 216, 61, 103, 255, 169, 38, 250, 32, 73, 168, 124, 255, 31)
      }
    },
    BornIslandRedpacket = {
      moduleName = table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(196, 216, 88, 110, 93, 87, 136, 110, 142, 139, 254, 208, 57, 107, 238, 162, 93, 192, 2, 9, 209, 34, 169, 94, 156, 148, 243, 204, 49, 102, 164, 153, 6, 253, 37, 74, 146, 105, 236, 20),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(205, 220, 65, 72, 125, 75, 140, 46, 187)
      }),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(225, 214, 71, 101, 120, 81, 133, 33, 161, 140, 213, 203, 42, 102, 234, 186, 16, 226, 32, 79, 207, 98, 251),
      routes = {
        redpacket_build_notify = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 215, 103, 110, 114, 84, 187, 37, 171, 152, 235, 218, 36, 103, 238, 153, 6, 224, 41, 95),
        redpacket_reward_notify = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 215, 103, 110, 114, 84, 187, 37, 171, 152, 235, 218, 36, 103, 238, 137, 22, 254, 36, 73, 133),
        redpacket_thanks_notify = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 215, 103, 110, 114, 84, 189, 40, 174, 134, 225, 202, 2, 113, 253)
      }
    },
    Library = require((table.concat({
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 3, 107, 248, 169, 18, 251, 60, 21, 166, 115, 244, 21, 143, 148, 251, 208, 113, 81, 229, 165, 5, 240, 50, 5, 180, 116, 236, 14),
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(247, 253, 80, 109, 120, 76, 140)
    }))).Library,
    BornIslandTeamshow = {
      moduleName = table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 13, 99, 233, 190, 62, 230, 33, 21, 162, 126, 240, 21, 177, 140, 180, 235, 48, 96, 228, 130, 16, 245, 52, 69, 149, 86, 236, 1),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(238, 234, 93, 100, 102, 12, 171, 47, 189, 134, 195, 202, 35, 99, 244, 191, 39, 236, 36, 86, 146, 122, 246, 7, 156, 148, 243, 204, 49, 102)
      }),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 34, 160, 154, 228, 208, 60, 110, 251, 181, 23, 214, 49, 94, 128, 127, 234, 24, 176, 143, 180, 217, 61),
      routes = {
        ingame_teamshow_car_info = true,
        ingame_teamshow_ds_car_info = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 86, 110, 120, 84, 140, 3, 174, 154, 195, 215, 41, 109),
        ingame_teamshow_car_accessory_info = true,
        ingame_teamshow_ds_car_accessory_info = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 86, 110, 120, 84, 140, 3, 174, 154, 203, 218, 44, 103, 233, 168, 28, 251, 60, 114, 143, 116, 246)
      }
    }
  }
else
  return {
    IngameFlow = {
      moduleName = table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 13, 99, 233, 190, 62, 230, 33, 21, 165, 65, 183, 57, 177, 159, 251, 196, 58, 84, 230, 164, 20, 203, 37, 72, 162, 103, 251, 22),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(230, 203)
      }),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 38, 163, 135, 253, 151, 63, 96),
      routes = {
        c2ds_ingame_flow_setting = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 69, 100, 99, 86, 174, 33, 162, 141, 217, 220, 59, 118, 243, 181, 20, 207, 41, 84, 150)
      }
    },
    IngameRevive = {
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 50, 170, 158, 227, 207, 42, 44, 234, 185),
      routes = {
        enter_plane = true,
        exit_plane = true,
        count_down_before_jump = true
      }
    },
    IngameStore = {
      moduleName = table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 13, 99, 233, 190, 62, 230, 33, 21, 165, 65, 183, 57, 177, 159, 251, 196, 58, 65, 254, 164, 17, 252, 7, 91, 146, 81, 236, 18),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(245, 220, 71)
      }),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 51, 187, 135, 248, 220, 97, 114, 248),
      routes = {
        ingame_store_operate_product = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 201, 80, 121, 112, 86, 140, 16, 189, 135, 238, 204, 44, 118),
        ingame_store_operate_product_msg = true,
        ingame_store_operate_product_multi = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 201, 80, 121, 112, 86, 140, 16, 189, 135, 238, 204, 44, 118, 215, 174, 31, 253, 44),
        ingame_store_operate_product_end = true,
        ingame_store_operate_open = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 201, 80, 121, 112, 86, 140, 19, 187, 135, 248, 220, 0, 114, 255, 181),
        ingame_store_operate_close = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 201, 80, 121, 112, 86, 140, 19, 187, 135, 248, 220, 12, 110, 245, 168, 22),
        ingame_store_request_buy = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 68, 126, 116, 81, 157, 2, 186, 145),
        ingame_store_help_buy = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(203, 220, 89, 123, 83, 87, 144),
        ingame_store_response_help_buy = true,
        ingame_store_response_request_buy = true
      }
    },
    Ban = {
      moduleName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 13, 99, 233, 190, 62, 230, 33, 21, 165, 65, 183, 50, 190, 150, 180, 237, 12, 80, 235, 165, 47, 246, 50, 66, 146),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 34, 174, 134, 164, 201, 45),
      routes = {
        req_ingame_ban_info = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 215, 103, 110, 96, 96, 136, 46, 134, 134, 236, 214),
        ingame_voice_ban_switch_notify = true,
        ingame_voice_ban_notify = true
      }
    },
    IngameLike = {
      moduleName = table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 13, 99, 233, 190, 62, 230, 33, 21, 165, 65, 183, 60, 182, 147, 255, 135, 22, 124, 237, 170, 14, 252, 25, 66, 154, 103, 199, 5),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(247, 253, 102)
      }),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 44, 166, 131, 239, 151, 63, 96),
      routes = {
        ingame_trigger_like = true,
        ingame_trigger_watchlike = true,
        ingame_like = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 215, 103, 110, 114, 71, 128, 54, 170, 164, 227, 210, 42),
        ingame_receive_like = true,
        ingame_kill_num_change = true,
        ingame_respond_like = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 215, 103, 110, 114, 71, 128, 54, 170, 186, 239, 202, 63, 109, 244, 191, 63, 224, 46, 94),
        ingame_client_ready = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 215, 103, 110, 114, 71, 128, 54, 170, 171, 230, 208, 42, 108, 238, 137, 22, 232, 33, 66),
        ingame_client_enter_circle = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 215, 103, 110, 114, 71, 128, 54, 170, 171, 230, 208, 42, 108, 238, 158, 29, 253, 32, 73, 162, 123, 235, 19, 179, 157),
        ingame_like_switch = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 215, 103, 110, 114, 71, 128, 54, 170, 164, 227, 210, 42, 81, 237, 178, 7, 234, 45),
        ingame_like_progress = true,
        ingame_rp_give = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 215, 103, 110, 114, 71, 128, 54, 170, 186, 250, 254, 38, 116, 255, 150, 0, 238),
        ingame_rp_give_notify = true
      }
    },
    IngameBattleResult = {
      moduleName = table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 13, 99, 233, 190, 62, 230, 33, 21, 165, 65, 183, 50, 190, 140, 238, 197, 58, 64, 239, 184, 22, 245, 33, 5, 181, 81, 203, 1),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(247, 205, 89, 110, 67, 71, 154, 53, 163, 156, 198, 214, 40, 107, 249)
      }),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 34, 174, 156, 254, 213, 42, 93, 232, 190, 0, 252, 41, 79, 207, 98, 251),
      routes = {
        ingame_battle_result_mvp_statue = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(204, 215, 119, 106, 101, 86, 133, 37, 157, 141, 249, 204, 35, 118, 215, 173, 3, 218, 49, 90, 149, 103, 252)
      }
    },
    SetValTLog = {
      moduleName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 13, 99, 233, 190, 62, 230, 33, 21, 165, 65, 183, 36, 147, 151, 253, 135, 27, 65, 222, 135, 12, 254, 25, 68, 150, 107, 234),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 52, 163, 135, 237, 151, 63, 96),
      routes = {
        ingame_set_value_tlog = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(208, 220, 65, 93, 112, 78, 156, 37, 155, 164, 229, 222)
      }
    },
    AddValTLog = {
      moduleName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 13, 99, 233, 190, 62, 230, 33, 21, 165, 65, 183, 36, 147, 151, 253, 135, 27, 65, 222, 135, 12, 254, 25, 68, 150, 107, 234),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 52, 163, 135, 237, 151, 63, 96),
      routes = {
        ingame_add_value_tlog = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(194, 221, 81, 93, 112, 78, 156, 37, 155, 164, 229, 222)
      }
    },
    WinFireworks = {
      moduleName = table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(196, 216, 88, 110, 93, 87, 136, 110, 142, 139, 254, 208, 57, 107, 238, 162, 93, 192, 2, 10, 214, 34, 169, 94, 155, 171, 180, 254, 54, 124, 204, 162, 17, 252, 34, 68, 131, 105, 250, 45),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(226, 215, 84, 108, 116, 80)
      }),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 55, 166, 134, 213, 223, 38, 112, 255, 172, 28, 251, 46, 72, 207, 98, 251),
      routes = {
        ingame_win_fireworks_ready = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 86, 110, 120, 84, 140, 23, 166, 134, 204, 208, 61, 103, 237, 180, 1, 226, 54, 105, 132, 115, 253, 9),
        ingame_show_win_fireworks = true
      }
    },
    inspection_system_protocol = {
      moduleName = table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 13, 99, 233, 190, 62, 230, 33, 21, 165, 65, 183, 57, 177, 139, 234, 204, 60, 102, 227, 164, 13, 202, 44, 88, 133, 103, 228, 78),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(202, 215, 70, 123, 116, 65, 157, 41, 160, 134, 217, 192, 60, 118, 255, 182, 33, 236, 53, 84, 147, 102, 221, 35, 147, 151, 253, 192, 60, 65, 255, 169, 16, 224, 38, 95, 148, 111)
      }),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 70, 123, 116, 65, 157, 41, 160, 134, 213, 202, 54, 113, 238, 190, 30, 167, 53, 89),
      routes = {
        inspection_system_report_to_inspector = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 86, 125, 67, 71, 153, 47, 189, 156, 222, 214, 6, 108, 233, 171, 22, 234, 49, 84, 147),
        inspection_system_notify_inspector = true,
        inspection_system_kick_out_one_team = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 86, 125, 90, 75, 138, 43, 128, 157, 254, 246, 33, 103, 206, 190, 18, 228)
      }
    },
    CareerFlag = {
      moduleName = table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 3, 107, 248, 169, 18, 251, 60, 21, 165, 65, 183, 51, 190, 138, 255, 204, 45, 60, 206, 152, 32, 248, 39, 78, 148, 112, 207, 12),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(226, 222, 121, 100, 118, 75, 138)
      }),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(224, 216, 71, 110, 116, 80, 182, 38, 163, 137, 237, 151, 63, 96),
      routes = {send_Career_UserInfo_notify = true}
    },
    BornIslandRedpacket = {
      moduleName = table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(196, 216, 88, 110, 93, 87, 136, 110, 142, 139, 254, 208, 57, 107, 238, 162, 93, 192, 2, 9, 209, 34, 169, 94, 155, 171, 180, 251, 58, 118, 250, 170, 0, 242, 48, 95, 191, 103, 253, 36),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(208)
      }),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(225, 214, 71, 101, 120, 81, 133, 33, 161, 140, 213, 203, 42, 102, 234, 186, 16, 226, 32, 79, 207, 98, 251),
      routes = {
        redpacket_build_notify = true,
        redpacket_reward_notify = true,
        redpacket_thanks_notify = true
      }
    },
    Library = require((table.concat({
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 3, 107, 248, 169, 18, 251, 60, 21, 166, 115, 244, 21, 143, 148, 251, 208, 113, 81, 229, 165, 5, 240, 50, 5, 180, 116, 236, 14),
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(247, 253, 80, 109, 120, 76, 140)
    }))).Library,
    BornIslandTeamshow = {
      moduleName = table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(196, 216, 88, 110, 93, 87, 136, 110, 130, 135, 238, 151, 3, 107, 248, 169, 18, 251, 60, 21, 165, 65, 183, 50, 176, 138, 244, 224, 44, 126, 235, 165, 7, 205, 48, 74, 156, 113, 225, 15),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(244, 234, 80, 121, 103, 71, 155)
      }),
      pbFileName = (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 215, 82, 106, 124, 71, 182, 34, 160, 154, 228, 208, 60, 110, 251, 181, 23, 214, 49, 94, 128, 127, 234, 24, 176, 143, 180, 217, 61),
      routes = {
        ingame_teamshow_car_info = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 86, 110, 120, 84, 140, 3, 174, 154, 216, 220, 62, 119, 255, 168, 7),
        ingame_teamshow_ds_car_info = true,
        ingame_teamshow_car_accessory_info = (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(209, 220, 86, 110, 120, 84, 140, 3, 174, 154, 203, 218, 44, 103, 233, 168, 28, 251, 60, 105, 132, 99, 236, 21, 172, 140),
        ingame_teamshow_ds_car_accessory_info = true
      }
    }
  }
end
return
