local PMGCFireBalloon = {}
local GameplayData = require("GameLua.GameCore.Data.GameplayData")
local InGameMarkTools = require("GameLua.Mod.BaseMod.Common.InGameMarkTools")
local PMGCAirBalloonConfig = require("GameLua.ExtraModule.PMGC2026.Gameplay.Config.PMGCAirBalloonConfig")
local PMGCAirBalloonShowSpotConfig = require("GameLua.ExtraModule.PMGC2026.Gameplay.Config.PMGCAirBalloonShowSpotConfig")
local IngameTipsTools = require("GameLua.Mod.BaseMod.Common.UI.InGameTipsTools")
local EDollAirBalloonState = import("EDollAirBalloonState")
local EPawnState = import("EPawnState")
local ASTExtraBaseCharacter = import("/Script/ShadowTrackerExtra.STExtraBaseCharacter")
local STExtraFireBalloon = import("STExtraFireBalloon")
local ECollisionChannel = import("ECollisionChannel")
local ECollisionResponse = import("ECollisionResponse")
local UChildActorComponent = import("ChildActorComponent")

function PMGCFireBalloon:ctor()
  self.bBalloonAlive = true
  self.PendingDestroy = false
  self.PassengerNum = 0
  self.IsMoving = false
  self.ShouldShowScreenMark = true
  self.SinglePlayerScreenMark = {}
  self.LiftSpanTime = 5
  self.HasActived = false
  self.bManagedByShowSpot = false
  self.bManagedFuelCountdownStarted = false
  self.bManagedFuelWarningSent = false
  self.SkyTransitionID = 0
  self.AppearanceMaterialIndex = 0
  self.AppearanceMaterialLoadingIndex = nil
  self.PendingDriverPlayerKey = nil
  self.CurrentParachuteStageIndex = 1
  self.bParachuteStagesEnabled = false
end

function PMGCFireBalloon:GetParachuteStages()
  local Stages = {}
  local Components = self:GetComponentsByTag(UChildActorComponent, "StageForParachuteShow")
  for Index = 0, Components:Num() - 1 do
    Stages[Index + 1] = Components:Get(Index).ChildActor
  end
  return Stages
end

function PMGCFireBalloon:InitializeParachuteStages()
  for Index, Stage in ipairs(self:GetParachuteStages()) do
    if slua.isValid(Stage) then
      Stage:SetOwnerBalloon(self.Object)
    else
      print(bWriteLog and string.format("PMGCFireBalloon:InitializeParachuteStages missing stage balloon=%s index=%s", tostring(self.Object), tostring(Index)))
    end
  end
  self:SetParachuteStagesEnabled(false)
end

function PMGCFireBalloon:SetParachuteStagesEnabled(bEnabled)
  self.bParachuteStagesEnabled = bEnabled
  for Index, Stage in ipairs(self:GetParachuteStages()) do
    if slua.isValid(Stage) then
      Stage:_EnableInteractiveComp(bEnabled and Index == self.CurrentParachuteStageIndex and Stage.nPlayShow == 0 and not Stage.bInCoolDown)
    end
  end
end

function PMGCFireBalloon:IsParachuteStageAvailable(Stage)
  return not self.PendingDestroy and self.bParachuteStagesEnabled and self:GetParachuteStages()[self.CurrentParachuteStageIndex] == Stage
end

function PMGCFireBalloon:IsPassengerInParachuteShow(Passenger)
  for _, Stage in ipairs(self:GetParachuteStages()) do
    if slua.isValid(Stage) and (Stage.ShowVehicleBlockedPlayers and Stage.ShowVehicleBlockedPlayers[Passenger] or Stage.ExitedPlayerKeys[Passenger.PlayerKey]) then
      return true
    end
  end
  return false
end

function PMGCFireBalloon:OnParachuteShowStarted(Stage)
  if not self:IsParachuteStageAvailable(Stage) then
    print(bWriteLog and string.format("PMGCFireBalloon:OnParachuteShowStarted unexpected stage balloon=%s stage=%s", tostring(self.Object), tostring(Stage)))
    return
  end
  self.CurrentParachuteStageIndex = self.CurrentParachuteStageIndex + 1
  self:SetParachuteStagesEnabled(true)
  print(bWriteLog and string.format("PMGCFireBalloon:OnParachuteShowStarted balloon=%s nextIndex=%s", tostring(self.Object), tostring(self.CurrentParachuteStageIndex)))
end

function PMGCFireBalloon:_ApplyManagedShowSpotSettings()
  if self.bManagedByShowSpot then
    self.AutoFallOffSpeed = 0
    self.bForbidUpDownMove = true
  end
end

function PMGCFireBalloon:SetManagedByShowSpot(bManaged, nFuel)
  if not Client then
    self.bManagedByShowSpot = bManaged == true
    if self.bManagedByShowSpot then
      local fManagedFuel = nFuel or 120
      self.MaxFuel = fManagedFuel
      self.CurrentFuelFloat = fManagedFuel
      self.CurrentFuel = math.floor(fManagedFuel)
      self.bManagedFuelCountdownStarted = false
      self.bManagedFuelWarningSent = false
      self:SetActorTickEnabled(false)
    end
    self:ForceNetUpdate()
  end
  self:_ApplyManagedShowSpotSettings()
  print(bWriteLog and string.format("PMGCFireBalloon:SetManagedByShowSpot balloon=%s managed=%s fuel=%s autoFallOffSpeed=%s", tostring(self.Object), tostring(self.bManagedByShowSpot), tostring(self.CurrentFuel), tostring(self.AutoFallOffSpeed)))
end

function PMGCFireBalloon:SetAppearanceMaterialIndex(nIndex)
  if Client then
    return
  end
  local nMaterialIndex = math.floor(tonumber(nIndex) or 0)
  if nMaterialIndex <= 0 or self.AppearanceMaterialIndex == nMaterialIndex then
    return
  end
  self.AppearanceMaterialIndex = nMaterialIndex
  self:ForceNetUpdate()
  print(bWriteLog and string.format("[PMGC2026][AirBalloonMaterial] Server set balloon=%s index=%s", tostring(self.Object), tostring(nMaterialIndex)))
end

function PMGCFireBalloon:_ApplyAppearanceMaterial()
  if not Client then
    return
  end
  local nMaterialIndex = self.AppearanceMaterialIndex
  local MaterialPathList = PMGCAirBalloonShowSpotConfig.GroundBalloonAppearanceMaterialPathList
  local sMaterialPath = MaterialPathList and MaterialPathList[nMaterialIndex]
  if not nMaterialIndex or nMaterialIndex <= 0 or not sMaterialPath then
    print(bWriteLog and string.format("[PMGC2026][AirBalloonMaterial] Apply skipped balloon=%s index=%s path=%s", tostring(self.Object), tostring(nMaterialIndex), tostring(sMaterialPath)))
    return
  end
  if self.AppearanceMaterialLoadingIndex == nMaterialIndex then
    return
  end
  self.AppearanceMaterialLoadingIndex = nMaterialIndex
  print(bWriteLog and string.format("[PMGC2026][AirBalloonMaterial] Load request balloon=%s index=%s path=%s", tostring(self.Object), tostring(nMaterialIndex), tostring(sMaterialPath)))
  local Util = require("client.slua_ui_framework.util")
  Util.GetAssetAsync(sMaterialPath, function(uMaterial)
    if self.AppearanceMaterialIndex ~= nMaterialIndex then
      self.AppearanceMaterialLoadingIndex = nil
      return
    end
    if not slua.isValid(uMaterial) or not slua.isValid(self.BalloonMesh) then
      self.AppearanceMaterialLoadingIndex = nil
      print(bWriteLog and string.format("[PMGC2026][AirBalloonMaterial] Apply failed balloon=%s index=%s material=%s mesh=%s", tostring(self.Object), tostring(nMaterialIndex), tostring(slua.isValid(uMaterial)), tostring(slua.isValid(self.BalloonMesh))))
      return
    end
    local sParameterName = PMGCAirBalloonShowSpotConfig.GroundBalloonAppearanceParameterName or "DissolveAmount"
    self.BalloonMesh:SetMaterial(0, uMaterial)
    local uDynamicMaterial = self.BalloonMesh.CreateAndSetMaterialInstanceDynamic and self.BalloonMesh:CreateAndSetMaterialInstanceDynamic(0)
    if slua.isValid(uDynamicMaterial) and uDynamicMaterial.SetScalarParameterValue then
      uDynamicMaterial:SetScalarParameterValue(sParameterName, 1)
    end
    self.AppearanceMaterialLoadingIndex = nil
    print(bWriteLog and string.format("[PMGC2026][AirBalloonMaterial] Apply success balloon=%s index=%s slot=0", tostring(self.Object), tostring(nMaterialIndex)))
  end)
end

function PMGCFireBalloon:SetSkyTransitionID(nStateID)
  if Client then
    return
  end
  self.SkyTransitionID = math.floor(tonumber(nStateID) or 0)
  self:ForceNetUpdate()
  print(bWriteLog and string.format("[PMGC2026][SkyTransition] ServerAssign Balloon=%s StateID=%s", tostring(self.Object), tostring(self.SkyTransitionID)))
end

function PMGCFireBalloon:OnRep_SkyTransitionID()
  print(bWriteLog and string.format("[PMGC2026][SkyTransition] ClientReceive Balloon=%s StateID=%s", tostring(self.Object), tostring(self.SkyTransitionID)))
end

function PMGCFireBalloon:OnRep_AppearanceMaterialIndex()
  self:_ApplyAppearanceMaterial()
end

function PMGCFireBalloon:StartManagedFuelCountdown()
  if not (not Client and self.bManagedByShowSpot) or self.bManagedFuelCountdownStarted then
    return
  end
  self.bManagedFuelCountdownStarted = true
  self:SetActorTickEnabled(true)
  self:ForceNetUpdate()
  print(bWriteLog and "PMGCFireBalloon:StartManagedFuelCountdown balloon=" .. tostring(self.Object))
end

function PMGCFireBalloon:OnRep_bManagedByShowSpot()
  self:_ApplyManagedShowSpotSettings()
end

function PMGCFireBalloon:_ApplyBalloonAudioParams()
  print(bWriteLog and "PMGCFireBalloon:_ApplyBalloonAudioParams")
  self.HeightRTPC = ""
  if slua.isValid(self.AkComponent) then
    self.AkComponent:SetRTPCValue("Ballon_Health", 2.0, 0)
    self.AkComponent:SetRTPCValue("Balloon_Altitude", 100, 0)
  else
    print(bWriteLog and "PMGCFireBalloon:_ApplyBalloonAudioParams AkComponent is not valid")
  end
end

function PMGCFireBalloon:ReceiveBeginPlay()
  PMGCFireBalloon.__super.ReceiveBeginPlay(self)
  self.Super:ReceiveBeginPlay()
  self.CurrentFuel = self.MaxFuel
  self.CurrentFuelFloat = self.MaxFuel
  self.PassengerWindSoundPlay = false
  self.BalloonMesh.ComponentTags:Add("CanPronePlatform")
  self.BalloonSke.ComponentTags:Add("CanPronePlatform")
  self:_ApplyBalloonAudioParams()
  if CGame:IsEditor() then
    self.ActiveTimeConfig = 1
  end
  print(bWriteLog and "PMGCFireBalloon:ReceiveBeginPlay")
  if self:HasAuthority() then
    self:SetNetCullDistanceSquared(400000000)
    self.BalloonState = EDollAirBalloonState.EDollAirBalloon_EmptyAir
    self.BeginLocation = self:K2_GetActorLocation()
    self.TickTimer = self:AddGameTimer(0.5, true, function()
      self:UpdateBallon()
    end)
    if Game:IsValid(self.DriverArea) then
      self:AddControlEvent(self.DriverArea, "OnComponentBeginOverlap", self.OnEnterDriverArea, self)
      self:AddControlEvent(self.DriverArea, "OnComponentEndOverlap", self.OnLeaveDriverArea, self)
    else
      print(bWriteLog and "PMGCFireBalloon:ReceiveBeginPlay self.DriverArea is not valid")
    end
    self:AddCommonEvent(EVENTTYPE_INGAME_NORMAL, EVENTID_GAME_MODE_STATE_CHANGE, self.OnGameModeStateChange, self)
    self.ForceActiveTimer = self:AddGameTimer(0.5, false, function()
      self.ForceActiveTimer = nil
      if slua.isValid(self.Object) and not self._isDisposed then
        self:ForceActive()
      end
    end)
  end
  if Game:IsValid(self.FireBalloonArea) then
    self:AddControlEvent(self.FireBalloonArea, "OnComponentBeginOverlap", self.OnFireBalloonAreaBeginOverlap, self)
    self:AddControlEvent(self.FireBalloonArea, "OnComponentEndOverlap", self.OnFireBalloonAreaEndOverlap, self)
  else
    print(bWriteLog and "PMGCFireBalloon:ReceiveBeginPlay self.FireBalloonArea is not valid, passenger detection will not work")
  end
  if Client then
    if self.DriverArea then
      self.DriverArea.bGenerateOverlapEvents = false
    end
    if slua.isValid(self.BalloonSke) then
      if self.BalloonState >= EDollAirBalloonState.EDollAirBalloon_Blowing then
        local UIUtil = require("client.common.ui_util")
        local gameInstance = UIUtil.GetGameInstance()
        local deviceLevel = gameInstance:GetDeviceLevel()
        if 1 < deviceLevel then
          self.BalloonSke:SetMinLOD(0)
        end
        self.Movement:SetSkipUpdate(false)
      else
        self.BalloonSke:SetMinLOD(1)
        self.Movement:SetSkipUpdate(true)
      end
    end
    self:AddCommonEvent(EVENTTYPE_INGAME_SHOOTINGUI_PANEL, EVENTID_SHOOTINGUI_OPERATION_CHANGE, self.OnSwitchUIOperation, self)
    self:_ApplyAppearanceMaterial()
  end
  self:CloseComponentTick(self.CloudPartical)
  self:CloseComponentTick(self.LowHPEffect1)
  self:CloseComponentTick(self.LowHPEffect2)
  self:CloseComponentTick(self.DeathEffect1)
  self:CloseComponentTick(self.DeathEffect2)
  self:CloseComponentTick(self.PActiveEffect1)
  self:CloseComponentTick(self.PActiveEffect2)
  local ETickingGroup = import("ETickingGroup")
  if slua.isValid(self.AkComponent) then
    self.AkComponent:SetTickGroup(ETickingGroup.TG_PrePhysics)
  end
  self:_SetDriverReserveIgnored(self.Driver, true)
end

function PMGCFireBalloon:_DoEndPlayCleanup()
  if self.PendingDestroy then
    return
  end
  self.PendingDestroy = true
  if Client and slua.isValid(self.Driver) then
    local DriveFeature = self.Driver.PMGCBalloonDriveFeature
    if DriveFeature then
      DriveFeature:LeaveBalloonPerspective()
    end
  end
  self:_SetDriverReserveIgnored(self.Driver, false)
  self:RefreshLocalDriveUI()
  if self.ForceActiveTimer then
    self:RemoveGameTimer(self.ForceActiveTimer)
    self.ForceActiveTimer = nil
  end
  if self.DissolveTimerHandle then
    Game:ClearTimer(self.DissolveTimerHandle)
    self.DissolveTimerHandle = nil
    print(bWriteLog and "PMGCFireBalloon:ReceiveEndPlay1")
  end
  if self.TickTimer then
    self:RemoveGameTimer(self.TickTimer)
    self.TickTimer = nil
  end
  if slua.isValid(self.AkComponent) and self.WindStopSound then
    self.AkComponent:PostAkEvent(self.WindStopSound, "")
  end
  self.PassengerWindSoundPlay = false
  if self.DestroyTimer then
    self:RemoveGameTimer(self.DestroyTimer)
    self.DestroyTimer = nil
  end
  if self.PendingLeaveTimers then
    for uPassenger, Timer in pairs(self.PendingLeaveTimers) do
      if Timer then
        self:RemoveGameTimer(Timer)
      end
      self.PendingLeaveTimers[uPassenger] = nil
    end
    self.PendingLeaveTimers = nil
  end
  for index = self.Passengers:Num() - 1, 0, -1 do
    local Passenger = self.Passengers:Get(index)
    if slua.isValid(Passenger) then
      self:PlayerLeaveFireBalloon(Passenger)
    end
  end
  if Client then
    self:CacheBallonToMapIconSubsystem(false)
  end
  self:UnRegistEvents()
  self:RemoveAllGameTimer()
end

function PMGCFireBalloon:ReceiveEndPlay(_)
  print(bWriteLog and "PMGCFireBalloon:ReceiveEndPlay")
  self:_DoEndPlayCleanup()
  if not Client then
    self:ClearAttachedPickUp()
  end
  PMGCFireBalloon.__super.ReceiveEndPlay(self, _)
end

function PMGCFireBalloon:GetLifetimeReplicatedProps()
  local ELifetimeCondition = import("ELifetimeCondition")
  local RepTable = {
    {
      "bBalloonAlive",
      ELifetimeCondition.COND_None,
      UEnums.EPropertyClass.Bool
    },
    {
      "bManagedByShowSpot",
      ELifetimeCondition.COND_None,
      UEnums.EPropertyClass.Bool
    },
    {
      "SkyTransitionID",
      ELifetimeCondition.COND_None,
      UEnums.EPropertyClass.Int
    },
    {
      "AppearanceMaterialIndex",
      ELifetimeCondition.COND_None,
      UEnums.EPropertyClass.Int
    },
    {
      "PassengerNum",
      ELifetimeCondition.COND_None,
      UEnums.EPropertyClass.Int
    },
    {
      "IsMoving",
      ELifetimeCondition.COND_None,
      UEnums.EPropertyClass.Bool
    },
    {
      "ShouldShowScreenMark",
      ELifetimeCondition.COND_None,
      UEnums.EPropertyClass.Bool
    }
  }
  if PMGCFireBalloon.__super.GetLifetimeReplicatedProps then
    local BaseRepTable = PMGCFireBalloon.__super.GetLifetimeReplicatedProps(self)
    if BaseRepTable then
      table.move(BaseRepTable, 1, #BaseRepTable, #RepTable + 1, RepTable)
    end
  end
  return RepTable
end

function PMGCFireBalloon:CloseComponentTick(uComp)
  if not slua.isValid(uComp) then
    return
  end
  local PrimaryComponentTick = slua.IndexReference(uComp, "PrimaryComponentTick")
  if PrimaryComponentTick then
    PrimaryComponentTick.bCanEverTick = false
  end
end

function PMGCFireBalloon:HandleManagedFuelExhausted()
  if Client or not self.bManagedByShowSpot then
    return
  end
  if slua.isValid(self.Driver) then
    self:SetDriver(nil)
  end
  local Stage = self:GetParachuteStages()[self.CurrentParachuteStageIndex]
  if not slua.isValid(Stage) then
    print(bWriteLog and string.format("PMGCFireBalloon:HandleManagedFuelExhausted no available stage balloon=%s index=%s passengers=%s", tostring(self.Object), tostring(self.CurrentParachuteStageIndex), tostring(self.Passengers:Num())))
    return
  end
  self:SetParachuteStagesEnabled(true)
  Stage:ForceStartShowForAllPassengers()
end

function PMGCFireBalloon:UpdateBallon()
  if self.bManagedByShowSpot then
    if self.CurrentFuel <= 0 then
      self:HandleManagedFuelExhausted()
    else
      self:_TryNotifyManagedFuelWarning()
    end
  end
  if not self.Movement then
    return
  end
  local Velocity = self.Movement.Velocity
  local CurLocation = self:K2_GetActorLocation()
  for _, Passenger in pairs(self.Passengers) do
    if slua.isValid(Passenger) then
      if Velocity:Size() < 300.0 and Passenger:K2_GetActorLocation().Z > CurLocation.Z + 500 and Passenger:K2_GetActorLocation().Z < CurLocation.Z + 5600 and self.TelePortPoint then
        local uCharacterMovement = Passenger.STCharacterMovement
        if slua.isValid(uCharacterMovement) then
          local uMovementBase = uCharacterMovement:GetMovementBase()
          if slua.isValid(uMovementBase) and not uMovementBase:ComponentHasTag("RootCollison") then
            Game:TeleportPawn(Passenger, self.TelePortPoint:K2_GetComponentLocation(), self.TelePortPoint:K2_GetComponentRotation())
          end
        end
      end
      local uCurrentWeapon = Passenger:GetCurrentWeapon()
      if slua.isValid(uCurrentWeapon) and Passenger:GetMovementBaseActor(Passenger) == self.Object then
        Passenger:UnequipCurrentWeaponDelayed()
      end
    end
  end
  self.PassengerNum = self.Passengers:Num()
  self.ShouldShowScreenMark = 0 < self.PassengerNum or self.bManagedByShowSpot
  local CheckIsMoving = Velocity:Size() > 10 and 0 < self.PassengerNum
  if self.IsMoving ~= CheckIsMoving then
    self.IsMoving = CheckIsMoving
  end
  if self.IsMoving then
    self.BalloonState = EDollAirBalloonState.EDollAirBalloon_Flying
  end
end

function PMGCFireBalloon:_TryNotifyManagedFuelWarning()
  if Client or self.bManagedFuelWarningSent then
    return
  end
  local Config = PMGCAirBalloonShowSpotConfig
  local nTipsID = Config.FuelWarningTipsID
  local nThreshold = Config.FuelWarningSeconds or 30
  if not nTipsID or nTipsID <= 0 or nThreshold < self.CurrentFuel then
    return
  end
  self.bManagedFuelWarningSent = true
  print(bWriteLog and string.format("PMGCFireBalloon:_TryNotifyManagedFuelWarning balloon=%s fuel=%s threshold=%s tipsID=%s", tostring(self.Object), tostring(self.CurrentFuel), tostring(nThreshold), tostring(nTipsID)))
  for nIndex = 0, self.Passengers:Num() - 1 do
    local uPassenger = self.Passengers:Get(nIndex)
    if slua.isValid(uPassenger) and uPassenger.PlayerKey then
      IngameTipsTools.BattleGeneralTip(nTipsID, nThreshold, "", uPassenger.PlayerKey, false)
    end
  end
end

function PMGCFireBalloon:OnEnterDriverArea(uOverlappedComp, uOtherActor, uOtherComp, bFromSweep, uSweepResult)
  print(bWriteLog and string.format("PMGCFireBalloon:OnEnterDriverArea : %s", tostring(uOtherActor)))
  if not slua.isValid(uOtherActor) then
    return
  end
  if uOtherActor.GetMovementBaseActor then
    print(bWriteLog and string.format("PMGCFireBalloon:OnEnterDriverArea uOtherActor MovementBaseActor = %s Balloon=%s", tostring(uOtherActor:GetMovementBaseActor(uOtherActor)), tostring(self.Object)))
  end
  local Feature = uOtherActor.PMGCBalloonDriveFeature
  if Feature then
    Feature:SetbIsInBallonDriveArea(not slua.isValid(self.Driver))
  else
    print(bWriteLog and "PMGCFireBalloon:OnEnterDriverArea - uOtherActor.PMGCBalloonDriveFeature is invalid")
  end
end

function PMGCFireBalloon:OnLeaveDriverArea(uOverlappedComp, uOtherActor, uOtherComp, bFromSweep, uSweepResult)
  print(bWriteLog and string.format("PMGCFireBalloon:OnLeaveDriverArea : %s", tostring(uOtherActor)))
  if not slua.isValid(uOtherActor) then
    return
  end
  local Feature = uOtherActor.PMGCBalloonDriveFeature
  if Feature then
    Feature:SetbIsInBallonDriveArea(false)
  else
    print(bWriteLog and "PMGCFireBalloon:OnEnterDriverArea - uOtherActor.PMGCBalloonDriveFeature is invalid")
  end
end

function PMGCFireBalloon:OnFireBalloonAreaBeginOverlap(uOverlappedComp, uOtherActor, uOtherComp, bFromSweep, uSweepResult)
  print(bWriteLog and string.format("PMGCFireBalloon:OnFireBalloonAreaBeginOverlap : %s", tostring(uOtherActor)))
  if not slua.isValid(uOtherActor) then
    print(bWriteLog and "PMGCFireBalloon:OnFireBalloonAreaBeginOverlap uOtherActor is not valid")
    return
  end
  if not Game:IsClassOf(uOtherActor, ASTExtraBaseCharacter) then
    print(bWriteLog and string.format("PMGCFireBalloon:OnFireBalloonAreaBeginOverlap uOtherActor is not STExtraBaseCharacter %s", tostring(uOtherActor:GetClass())))
    return
  end
  self:AddControlEvent(uOtherActor, "OnMovementBaseChanged", self.HandleNearbyPlayerMovementBaseChanged, self)
  self:AddControlEvent(uOtherActor, "OnDestroyed", self.OnNearbyPlayerDestroyed, self)
  self:_RefreshPassengerFromMovementBase(uOtherActor)
  if self.PendingLeaveTimers and self.PendingLeaveTimers[uOtherActor] then
    self:RemoveGameTimer(self.PendingLeaveTimers[uOtherActor])
    self.PendingLeaveTimers[uOtherActor] = nil
  end
end

function PMGCFireBalloon:_RefreshPassengerFromMovementBase(uCharacter)
  if not slua.isValid(uCharacter) or not uCharacter.STCharacterMovement then
    return
  end
  local uMovementBase = uCharacter.STCharacterMovement:GetMovementBase()
  local uBaseOwner = slua.isValid(uMovementBase) and uMovementBase:GetOwner() or nil
  print(bWriteLog and string.format("PMGCFireBalloon:_RefreshPassengerFromMovementBase %s %s %s %s", tostring(uCharacter), tostring(uMovementBase), tostring(uBaseOwner), tostring(self.Object)))
  if slua.isValid(uBaseOwner) and uBaseOwner == self.Object then
    self:HandleNearbyPlayerMovementBaseChanged(uCharacter, uMovementBase, nil)
  end
end

function PMGCFireBalloon:OnFireBalloonAreaEndOverlap(uOverlappedComp, uOtherActor, uOtherComp, bFromSweep)
  print(bWriteLog and string.format("PMGCFireBalloon:OnFireBalloonAreaEndOverlap : %s", tostring(uOtherActor)))
  if not slua.isValid(uOtherActor) then
    print(bWriteLog and "PMGCFireBalloon:OnFireBalloonAreaEndOverlap uOtherActor is not valid")
    return
  end
  if not Game:IsClassOf(uOtherActor, ASTExtraBaseCharacter) then
    return
  end
  self:PostponedRemovePassengers(uOtherActor)
end

function PMGCFireBalloon:PostponedRemovePassengers(uOtherActor)
  self.PendingLeaveTimers = self.PendingLeaveTimers or {}
  if self.PendingLeaveTimers[uOtherActor] then
    return
  end
  self.PendingLeaveTimers[uOtherActor] = self:AddGameTimer(0.5, false, function()
    self.PendingLeaveTimers[uOtherActor] = nil
    self:_ConfirmPlayerLeftBalloonArea(uOtherActor)
  end)
end

function PMGCFireBalloon:_ConfirmPlayerLeftBalloonArea(uOtherActor)
  if not slua.isValid(uOtherActor) then
    return
  end
  local uMovementComponent = uOtherActor.STCharacterMovement
  local uMovementBase = slua.isValid(uMovementComponent) and uMovementComponent:GetMovementBase() or nil
  local uBaseOwner = slua.isValid(uMovementBase) and uMovementBase:GetOwner() or nil
  if slua.isValid(uBaseOwner) and uBaseOwner == self.Object then
    print(bWriteLog and string.format("PMGCFireBalloon:_ConfirmPlayerLeftBalloonArea keep passenger, movement base is back on balloon %s", tostring(uOtherActor)))
    return
  end
  self:RemoveControlEvent(uOtherActor, "OnMovementBaseChanged")
  self:RemoveControlEvent(uOtherActor, "OnDestroyed")
  local bRemoved = false
  for index = self.Passengers:Num() - 1, 0, -1 do
    if self.Passengers:Get(index) == uOtherActor then
      self.Passengers:Remove(index)
      bRemoved = true
      break
    end
  end
  if bRemoved then
    print(bWriteLog and string.format("PMGCFireBalloon:_ConfirmPlayerLeftBalloonArea force remove passenger who left area without leaving balloon %s", tostring(uOtherActor)))
    self:PlayerLeaveFireBalloon(uOtherActor)
  end
  self:UpdateUIVisible()
end

function PMGCFireBalloon:OnNearbyPlayerDestroyed(uDestroyedActor)
  print(bWriteLog and string.format("PMGCFireBalloon:OnNearbyPlayerDestroyed : %s", tostring(uDestroyedActor)))
  if not slua.isValid(uDestroyedActor) or not Game:IsClassOf(uDestroyedActor, ASTExtraBaseCharacter) then
    return
  end
  self:RemoveControlEvent(uDestroyedActor, "OnMovementBaseChanged")
  if self.PendingLeaveTimers and self.PendingLeaveTimers[uDestroyedActor] then
    self:RemoveGameTimer(self.PendingLeaveTimers[uDestroyedActor])
    self.PendingLeaveTimers[uDestroyedActor] = nil
  end
  local bRemoved = false
  for index = self.Passengers:Num() - 1, 0, -1 do
    if self.Passengers:Get(index) == uDestroyedActor then
      self.Passengers:Remove(index)
      bRemoved = true
      break
    end
  end
  if bRemoved then
    self:PlayerLeaveFireBalloon(uDestroyedActor)
  end
end

function PMGCFireBalloon:RequestAutoDriver(uCharacter)
  if not (not Client and slua.isValid(uCharacter)) or not uCharacter.PlayerKey then
    print(bWriteLog and "PMGCFireBalloon:RequestAutoDriver invalid server request")
    return
  end
  self.PendingDriverPlayerKey = uCharacter.PlayerKey
  print(bWriteLog and "PMGCFireBalloon:RequestAutoDriver pending PlayerKey:" .. tostring(uCharacter.PlayerKey))
  self:_TryApplyPendingAutoDriver(uCharacter)
end

function PMGCFireBalloon:_TryApplyPendingAutoDriver(uCharacter)
  if not (not Client and self.PendingDriverPlayerKey and slua.isValid(uCharacter)) or uCharacter.PlayerKey ~= self.PendingDriverPlayerKey then
    return
  end
  local uMovementBaseActor = uCharacter.GetMovementBaseActor and uCharacter:GetMovementBaseActor(uCharacter) or nil
  if uMovementBaseActor ~= self.Object then
    print(bWriteLog and "PMGCFireBalloon:_TryApplyPendingAutoDriver waiting MovementBase PlayerKey:" .. tostring(uCharacter.PlayerKey) .. " Base:" .. tostring(uMovementBaseActor) .. " Balloon:" .. tostring(self.Object))
    return
  end
  local bCanBeDriver = self:CanBeDriver(uCharacter)
  print(bWriteLog and "PMGCFireBalloon:_TryApplyPendingAutoDriver confirmed PlayerKey:" .. tostring(uCharacter.PlayerKey) .. " CanBeDriver:" .. tostring(bCanBeDriver))
  self.PendingDriverPlayerKey = nil
  if not bCanBeDriver then
    return
  end
  self:SetDriver(uCharacter)
  print(bWriteLog and "PMGCFireBalloon:_TryApplyPendingAutoDriver applied PlayerKey:" .. tostring(uCharacter.PlayerKey) .. " Driver:" .. tostring(self.Driver))
end

function PMGCFireBalloon:HandleNearbyPlayerMovementBaseChanged(uCharacter, uNewMovementBase, uOldMovementBase)
  print(bWriteLog and string.format("PMGCFireBalloon:HandleNearbyPlayerMovementBaseChanged uCharacter= %s uNewMovementBase=%s", tostring(uCharacter), tostring(uNewMovementBase)))
  if not slua.isValid(uCharacter) or not Game:IsClassOf(uCharacter, ASTExtraBaseCharacter) then
    print(bWriteLog and "PMGCFireBalloon:HandleNearbyPlayerMovementBaseChanged uCharacter is not valid STExtraBaseCharacter")
    return
  end
  local bAlreadyPassenger = false
  for index = 0, self.Passengers:Num() - 1 do
    if self.Passengers:Get(index) == uCharacter then
      bAlreadyPassenger = true
      break
    end
  end
  if not slua.isValid(uNewMovementBase) then
    print(bWriteLog and "PMGCFireBalloon:HandleNearbyPlayerMovementBaseChanged uNewMovementBase is not valid")
    if bAlreadyPassenger then
      self:PostponedRemovePassengers(uCharacter)
    end
    return
  end
  local uOwner = uNewMovementBase:GetOwner()
  if slua.isValid(uOwner) and uOwner == self.Object then
    if not bAlreadyPassenger then
      self.Passengers:Add(uCharacter)
      print(bWriteLog and string.format("PMGCFireBalloon:HandleNearbyPlayerMovementBaseChanged add passenger %s %s", tostring(uCharacter), tostring("count=" .. tostring(self.Passengers:Num()))))
      self:PlayerEnterFireBalloon(uCharacter)
      self:_TryApplyPendingAutoDriver(uCharacter)
    end
  elseif bAlreadyPassenger then
    self:PostponedRemovePassengers(uCharacter)
  end
end

function PMGCFireBalloon:RemovePassenger(uCharacter)
  for index = self.Passengers:Num() - 1, 0, -1 do
    if self.Passengers:Get(index) == uCharacter then
      print(bWriteLog and string.format("PMGCFireBalloon:RemovePassenger %s %s", tostring(uCharacter), tostring("count=" .. tostring(self.Passengers:Num()))))
      self:PlayerLeaveFireBalloon(uCharacter)
      return
    end
  end
end

function PMGCFireBalloon:ManualEndPlay()
  self:_DoEndPlayCleanup()
end

function PMGCFireBalloon:OnRep_bBalloonAlive()
end

function PMGCFireBalloon:OnRep_IsMoving()
  print(bWriteLog and string.format("PMGCFireBalloon: OnRep_IsMoving %s", tostring(self.IsMoving)))
  if self.IsMoving then
    self:CacheBallonToMapIconSubsystem(true)
  else
    self:CacheBallonToMapIconSubsystem(false)
  end
end

function PMGCFireBalloon:_ResetLocalDriverCamera(uPlayerPawn)
  if not Client or not slua.isValid(uPlayerPawn) then
    return
  end
  local ENetRole = import("ENetRole")
  if uPlayerPawn.Role ~= ENetRole.ROLE_AutonomousProxy then
    return
  end
  local ECameraDataType = import("ECameraDataType")
  if slua.isValid(uPlayerPawn.CustomSpringArm) and uPlayerPawn.CustomSpringArm.SetCameraDataEnable then
    uPlayerPawn.CustomSpringArm:SetCameraDataEnable(ECameraDataType.ECameraDataType_FireBalloon, false)
  end
  local SettingModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.SettingModule)
  local fTpViewValue = SettingModule and SettingModule.GetOptionValue and SettingModule:GetOptionValue("TpViewValue")
  if fTpViewValue == nil or not slua.isValid(uPlayerPawn.Camera) then
    return
  end
  uPlayerPawn.Camera:SetFieldOfView(fTpViewValue)
  uPlayerPawn:SetFovInTPPSpringArm(fTpViewValue)
end

function PMGCFireBalloon:_SetPlayerSkyTransition(uPlayerPawn, bActive)
  if not self:HasAuthority() then
    return
  end
  local nSkyTransitionID = self.SkyTransitionID or 0
  local sAction = bActive and "Activate" or "Deactivate"
  if nSkyTransitionID <= 0 then
    print(bWriteLog and string.format("[PMGC2026][SkyTransition] %sSkipped Balloon=%s StateID=%s", sAction, tostring(self.Object), tostring(nSkyTransitionID)))
    return
  end
  local SkyTransition = uPlayerPawn.SkyTransition
  if not SkyTransition or not SkyTransition.SetStateActive then
    print(bWriteLog and string.format("[PMGC2026][SkyTransition] %sSkippedNoFeature PlayerKey=%s Balloon=%s StateID=%s", sAction, tostring(uPlayerPawn.PlayerKey), tostring(self.Object), tostring(nSkyTransitionID)))
    return
  end
  print(bWriteLog and string.format("[PMGC2026][SkyTransition] %s PlayerKey=%s Balloon=%s StateID=%s", sAction, tostring(uPlayerPawn.PlayerKey), tostring(self.Object), tostring(nSkyTransitionID)))
  SkyTransition:SetStateActive(nSkyTransitionID, bActive)
end

function PMGCFireBalloon:PlayerEnterFireBalloon(uPlayerPawn)
  print(bWriteLog and "PMGCFireBalloon:PlayerEnterFireBalloon")
  if not slua.isValid(uPlayerPawn) then
    return
  end
  if not self.bBalloonAlive then
    return
  end
  if self:HasAuthority() then
    if uPlayerPawn.UnequipCurrentWeaponDelayed then
      uPlayerPawn:UnequipCurrentWeaponDelayed()
    end
    self:_SetPlayerSkyTransition(uPlayerPawn, true)
  end
  self.Super:PlayerEnterFireBalloon(uPlayerPawn)
end

function PMGCFireBalloon:PlayerLeaveFireBalloon(uPlayerPawn)
  print(bWriteLog and "PMGCFireBalloon: PlayerLeaveFireBalloon")
  if not slua.isValid(uPlayerPawn) then
    return
  end
  if self.PendingDriverPlayerKey == uPlayerPawn.PlayerKey then
    self.PendingDriverPlayerKey = nil
    print(bWriteLog and "PMGCFireBalloon:PlayerLeaveFireBalloon clear pending auto driver PlayerKey:" .. tostring(uPlayerPawn.PlayerKey))
  end
  local bCancelledPendingUnequip = false
  local Relative = uPlayerPawn:K2_GetActorLocation() - self:K2_GetActorLocation()
  print(bWriteLog and string.format("PMGCFireBalloon: PlayerLeaveFireBalloon RelativeLoc  %s %s %s", tostring(Relative.X), tostring(Relative.Y), tostring(Relative.Z)))
  local CharacterMovement = uPlayerPawn.STCharacterMovement
  if slua.isValid(CharacterMovement) then
    print(bWriteLog and "PMGCFireBalloon: PlayerLeaveFireBalloon MovementMode " .. tostring(CharacterMovement.MovementMode))
  end
  if self:HasAuthority() then
    if uPlayerPawn.CancelPendingUnequipWeapon then
      bCancelledPendingUnequip = uPlayerPawn:CancelPendingUnequipWeapon()
    end
    self:_SetPlayerSkyTransition(uPlayerPawn, false)
    local WeaponManager = uPlayerPawn:GetWeaponManager()
    if slua.isValid(WeaponManager) then
      local EMovementMode = import("EMovementMode")
      if not bCancelledPendingUnequip and slua.isValid(CharacterMovement) and CharacterMovement.MovementMode ~= EMovementMode.MOVE_Flying and CharacterMovement.MovementMode ~= EMovementMode.MOVE_Custom and uPlayerPawn.RestorePreviousWeapon then
        uPlayerPawn:RestorePreviousWeapon()
      end
    else
      print(bWriteLog and "PMGCFireBalloon: PlayerLeaveFireBalloon WeaponManager is nil")
    end
  end
  self.Super:PlayerLeaveFireBalloon(uPlayerPawn)
end

function PMGCFireBalloon:SetCameraAlpha(NewCameraAlpha)
  print(bWriteLog and string.format("PMGCFireBalloon:SetCameraAlpha %s", tostring(NewCameraAlpha)))
  local ECollisionChannel = import("ECollisionChannel")
  local ECollisionResponse = import("ECollisionResponse")
  if 0.5 < NewCameraAlpha then
    self.BalloonMesh:SetCollisionResponseToChannel(ECollisionChannel.ECC_Camera, ECollisionResponse.ECR_Ignore)
    self.BalloonSke:SetCollisionResponseToChannel(ECollisionChannel.ECC_Camera, ECollisionResponse.ECR_Ignore)
    self.Sphere:SetCollisionResponseToChannel(ECollisionChannel.ECC_Camera, ECollisionResponse.ECR_Ignore)
  else
    self.BalloonMesh:SetCollisionResponseToChannel(ECollisionChannel.ECC_Camera, ECollisionResponse.ECR_Block)
    self.BalloonSke:SetCollisionResponseToChannel(ECollisionChannel.ECC_Camera, ECollisionResponse.ECR_Block)
    self.Sphere:SetCollisionResponseToChannel(ECollisionChannel.ECC_Camera, ECollisionResponse.ECR_Block)
  end
end

function PMGCFireBalloon:PlayerLeaveObservationArea(uPlayerPawn)
  print(bWriteLog and "PMGCFireBalloon: PlayerLeaveObservationArea()")
  self.Super:PlayerLeaveObservationArea(uPlayerPawn)
  if self:IsServer() then
    print(bWriteLog and "PMGCFireBalloon: PlayerLeaveObservationArea self:IsServer()")
    return
  end
  if slua.isValid(uPlayerPawn) and slua.isValid(uPlayerPawn.Camera) then
    local SettingModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.SettingModule)
    local TpViewValue = SettingModule:GetOptionValue("TpViewValue")
    uPlayerPawn.Camera:SetFieldOfView(TpViewValue)
    uPlayerPawn:SetFovInTPPSpringArm(TpViewValue)
  end
end

function PMGCFireBalloon:SetCameraOffsetData(Alpha, bUpdateCameraLocation)
  print(bWriteLog and string.format("PMGCFireBalloon:SetCameraOffsetData: alpha= %s bUpdateCameraLocation=%s", tostring(Alpha), tostring(bUpdateCameraLocation)))
  self:SetCameraAlpha(Alpha)
  self:BPSetPlayCameraOffsetData(Alpha, bUpdateCameraLocation)
  if self.Passengers then
    local ECameraDataType = import("ECameraDataType")
    local ENetRole = import("ENetRole")
    print(bWriteLog and "PMGCFireBalloon:SetCameraOffsetData: 1")
    for _, Passenger in pairs(self.Passengers) do
      print(bWriteLog and "PMGCFireBalloon:SetCameraOffsetData: 2")
      if slua.isValid(Passenger) and Passenger.Role == ENetRole.ROLE_SimulatedProxy then
        if slua.isValid(Passenger.CustomSpringArm) then
          Passenger.CustomSpringArm:SetCameraDataEnable(ECameraDataType.ECameraDataType_FireBalloon, false)
        else
          print(bWriteLog and "PMGCFireBalloon:SetCameraOffsetData: Passenger.CustomSpringArm invalid")
        end
        if slua.isValid(Passenger.Camera) then
          local SettingModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.SettingModule)
          local TpViewValue = SettingModule and SettingModule:GetOptionValue("TpViewValue")
          if TpViewValue ~= nil then
            Passenger.Camera:SetFieldOfView(TpViewValue)
            Passenger:SetFovInTPPSpringArm(TpViewValue)
            print(bWriteLog and "PMGCFireBalloon:SetCameraOffsetData restore passenger FOV=" .. tostring(TpViewValue))
          else
            print(bWriteLog and "PMGCFireBalloon:SetCameraOffsetData TpViewValue unavailable")
          end
        else
          print(bWriteLog and "PMGCFireBalloon:SetCameraOffsetData: Passenger.Camera invalid")
        end
      end
    end
  else
    print(bWriteLog and "PMGCFireBalloon:SetCameraOffsetData: No Passengers")
  end
end

function PMGCFireBalloon:OnGameModeStateChange(_, _, State)
  print(bWriteLog and string.format("PMGCFireBalloon:OnGameModeStateChange: %s", tostring(State)))
  if self:HasAuthority() and State and State == "FinishedState" and not self.bManagedByShowSpot then
    self.CurrentFuel = 0
    self.CurrentFuelFloat = 0
  end
end

function PMGCFireBalloon:ForceActive()
  self.ForceOperation = true
  if not self.bManagedByShowSpot or self.bManagedFuelCountdownStarted then
    self:SetActorTickEnabled(true)
  end
  self:SetActived(true)
  self.Movement:SetSkipUpdate(false)
  self.BalloonState = EDollAirBalloonState.EDollAirBalloon_Idle
end

function PMGCFireBalloon:BPTakeDamage(nDamage, DamageController, DamageCauser)
  if not slua.isValid(DamageController) then
    return
  end
  local DamagePawn = DamageController:K2_GetPawn()
  if not slua.isValid(DamagePawn) then
    return
  end
end

function PMGCFireBalloon:OnLanded()
  if self.PassengerNum <= 0 then
    self.NoPassengerAndLand = true
  end
  if self:HasAuthority() and not self.bManagedByShowSpot and 0 >= self.CurrentFuel then
    if not self.bBalloonAlive then
      return
    end
    if self.DestroyTimer then
      self:RemoveGameTimer(self.DestroyTimer)
      self.DestroyTimer = nil
    end
    self.bBalloonAlive = false
    self.RootCollision.ComponentTags:Clear()
    self:SetLifeSpan(self.LiftSpanTime)
  end
end

function PMGCFireBalloon:RefreshLocalDriveUI()
  if not Client then
    return
  end
  local PC = GameplayData.GetPlayerController()
  local Pawn = slua.isValid(PC) and PC:K2_GetPawn() or nil
  local Feature = slua.isValid(Pawn) and Pawn.PMGCBalloonDriveFeature or nil
  if Feature then
    Feature:RefreshDriveUIState()
  else
    print(bWriteLog and "PMGCFireBalloon:RefreshLocalDriveUI Feature is nil")
  end
end

function PMGCFireBalloon:UpdateUIVisible()
  self:RefreshLocalDriveUI()
end

function PMGCFireBalloon:OnSwitchUIOperation()
  if self.PendingDestroy or not slua.isValid(self.Object) then
    return
  end
  self:AddGameTimer(0.01, false, function()
    if self.PendingDestroy or not slua.isValid(self.Object) then
      return
    end
    local uPlayerController = GameplayData.GetPlayerController()
    local uCharacter = slua.isValid(uPlayerController) and uPlayerController:K2_GetPawn() or nil
    if not (slua.isValid(uCharacter) and uCharacter.GetMovementBaseActor) or uCharacter:GetMovementBaseActor(uCharacter) ~= self.Object then
      return
    end
    self:RefreshLocalDriveUI()
  end)
end

function PMGCFireBalloon:_SetDriverReserveIgnored(Pawn, bIgnore)
  if not slua.isValid(Pawn) or not slua.isValid(Pawn.CapsuleComponent) then
    return
  end
  local Capsules = self:GetComponentsByTag(import("CapsuleComponent"), "PMGC2026_Balloon_DriverReserveCapsule")
  if Capsules:Num() == 1 and slua.isValid(Capsules:Get(0)) then
    Pawn.CapsuleComponent:IgnoreComponentWhenMoving(Capsules:Get(0), bIgnore)
  end
end

function PMGCFireBalloon:_MoveDriverToExitPoint(Pawn)
  if Client or not slua.isValid(Pawn) then
    return
  end
  local bAttached = Pawn:GetAttachParentActor() == self.Object
  local Points = self:GetComponentsByTag(import("SceneComponent"), "BalloonDriveExitPoint")
  local ActorsToIgnore = slua.Array(UEnums.EPropertyClass.Object, import("Actor"))
  ActorsToIgnore:Add(Pawn)
  ActorsToIgnore:Add(self.Object)
  local ObjectTypes = {
    Game:ConvertToObjectType(ECollisionChannel.ECC_Pawn),
    Game:ConvertToObjectType(ECollisionChannel.ECC_WorldDynamic)
  }
  local Radius = Pawn.CapsuleComponent:GetScaledCapsuleRadius() + 1
  local HalfHeight = Pawn.CapsuleComponent:GetScaledCapsuleHalfHeight()
  local Origin = Pawn:K2_GetActorLocation()
  local ExitLocation, NearestDistance
  local KismetSystemLibrary = import("KismetSystemLibrary")
  for i = 0, Points:Num() - 1 do
    local Point = Points:Get(i)
    if slua.isValid(Point) then
      local Location = Point:K2_GetComponentLocation()
      local Distance = (Location - Origin):Size()
      if not NearestDistance or NearestDistance > Distance then
        local bBlocked = KismetSystemLibrary.CapsuleTraceSingleForObjects(self.Object, Location, Location + FVector(0, 0, 1), Radius, HalfHeight, ObjectTypes, false, ActorsToIgnore, 0, nil, true, FLinearColor.Red, FLinearColor.Green, 0)
        if not bBlocked then
          ExitLocation, NearestDistance = Location, Distance
        end
      end
    end
  end
  if bAttached then
    local EDetachmentRule = import("EDetachmentRule")
    Pawn:K2_DetachFromActor(EDetachmentRule.KeepWorld, EDetachmentRule.KeepWorld, EDetachmentRule.KeepWorld)
  end
  local bMoved = false
  if ExitLocation then
    bMoved = Pawn:K2_SetActorLocation(ExitLocation, false, nil, true)
  end
  print(bWriteLog and string.format("PMGCFireBalloon:_MoveDriverToExitPoint PlayerKey=%s fallback=%s", tostring(Pawn.PlayerKey), tostring(not bMoved)))
end

function PMGCFireBalloon:OnDriverAttachToFireBalloon(Pawn)
  print(bWriteLog and "PMGCFireBalloon:OnDriverAttachToFireBalloon")
  self:_SetDriverReserveIgnored(Pawn, true)
  self.Super:OnDriverAttachToFireBalloon(Pawn)
  if self:HasAuthority() then
    self.BalloonState = EDollAirBalloonState.EDollAirBalloon_Flying
  end
end

function PMGCFireBalloon:OnDriverDetachFromFireBalloon(Pawn)
  print(bWriteLog and "PMGCFireBalloon:OnDriverDetachFromFireBalloon")
  self:_MoveDriverToExitPoint(Pawn)
  self.Super:OnDriverDetachFromFireBalloon(Pawn)
  self:_SetDriverReserveIgnored(Pawn, false)
  if self:HasAuthority() then
    self.BalloonState = EDollAirBalloonState.EDollAirBalloon_Idle
  end
end

function PMGCFireBalloon:_CanSetDriverWhilePending(uNewDriver)
  if not (slua.isValid(uNewDriver) and self.PendingDriverPlayerKey) or uNewDriver.PlayerKey == self.PendingDriverPlayerKey then
    return true
  end
  local uPendingPlayer = Game:GetPlayerByPlayerKey(self.PendingDriverPlayerKey)
  local bPendingPlayerInArea = slua.isValid(uPendingPlayer) and slua.isValid(self.FireBalloonArea) and self.FireBalloonArea:IsOverlappingActor(uPendingPlayer) == true
  print(bWriteLog and "PMGCFireBalloon:_CanSetDriverWhilePending pendingPlayer=" .. tostring(self.PendingDriverPlayerKey) .. " candidatePlayer=" .. tostring(uNewDriver.PlayerKey) .. " inFireBalloonArea=" .. tostring(bPendingPlayerInArea))
  if bPendingPlayerInArea then
    print(bWriteLog and "PMGCFireBalloon:_CanSetDriverWhilePending blocked candidate PlayerKey:" .. tostring(uNewDriver.PlayerKey))
    return false
  end
  print(bWriteLog and "PMGCFireBalloon:_CanSetDriverWhilePending pending player not in FireBalloonArea, allow candidate PlayerKey:" .. tostring(uNewDriver.PlayerKey))
  return true
end

function PMGCFireBalloon:SetDriver(NewDriver)
  if not self:_CanSetDriverWhilePending(NewDriver) then
    return
  end
  if slua.isValid(NewDriver) and not NewDriver:AllowState(EPawnState.DriveMovePlatForm, false) then
    print(bWriteLog and string.format("PMGCFireBalloon:SetDriver rejected by pawn state %s", tostring(NewDriver)))
    return
  end
  if slua.isValid(NewDriver) and self.CurrentFuel <= 0 then
    print(bWriteLog and string.format("PMGCFireBalloon:SetDriver rejected by fuel balloon=%s fuel=%s", tostring(self.Object), tostring(self.CurrentFuel)))
    return
  end
  if slua.isValid(NewDriver) then
    local uMovementBaseActor = NewDriver.GetMovementBaseActor and NewDriver:GetMovementBaseActor(NewDriver) or nil
    if uMovementBaseActor ~= self.Object then
      self.PendingDriverPlayerKey = NewDriver.PlayerKey
      print(bWriteLog and "PMGCFireBalloon:SetDriver deferred until MovementBase is balloon" .. " PlayerKey=" .. tostring(NewDriver.PlayerKey) .. " Base=" .. tostring(uMovementBaseActor) .. " Balloon=" .. tostring(self.Object))
      return
    end
    print(bWriteLog and "PMGCFireBalloon:SetDriver MovementBase ready PlayerKey:" .. tostring(NewDriver.PlayerKey))
  end
  local PreDriver = self.Driver
  print(bWriteLog and string.format("PMGCFireBalloon:SetDriver NewDriver = %s", tostring(NewDriver)))
  self.Super:SetDriver(NewDriver)
  if slua.isValid(NewDriver) and NewDriver == self.Driver then
    if self.PendingDriverPlayerKey == NewDriver.PlayerKey then
      self.PendingDriverPlayerKey = nil
      print(bWriteLog and "PMGCFireBalloon:SetDriver clear pending driver PlayerKey:" .. tostring(NewDriver.PlayerKey))
    end
    NewDriver:EnterState(EPawnState.DriveMovePlatForm)
    self:SetNetCullDistanceSquared(3600000000)
    print(bWriteLog and string.format("PMGCFireBalloon:SetDriver New balloon=%s driver=%s fuel=%s managed=%s autoFallOff=%s", tostring(self.Object), tostring(self.Driver), tostring(self.CurrentFuel), tostring(self.bManagedByShowSpot), tostring(self.bAutoFallOff)))
  elseif slua.isValid(PreDriver) and not self.Driver then
    PreDriver:LeaveState(EPawnState.DriveMovePlatForm)
    print(bWriteLog and string.format("PMGCFireBalloon:SetDriver Null balloon=%s driver=%s fuel=%s managed=%s autoFallOff=%s", tostring(self.Object), tostring(PreDriver), tostring(self.CurrentFuel), tostring(self.bManagedByShowSpot), tostring(self.bAutoFallOff)))
  end
end

function PMGCFireBalloon:OnRep_Driver(uPreDrive)
  print(bWriteLog and string.format("PMGCFireBalloon: OnRep_Driver uPreDrive %s", tostring(uPreDrive)))
  print(bWriteLog and string.format("PMGCFireBalloon: OnRep_Driver Driver %s", tostring(self.Driver)))
  local ENetRole = import("ENetRole")
  if slua.isValid(self.Driver) and self.Driver.Role == ENetRole.ROLE_AutonomousProxy then
    local BasedMovement = slua.IndexReference(self.Driver, "BasedMovement")
    BasedMovement.MovementBase = self:K2_GetRootComponent()
    print(bWriteLog and string.format("PMGCFireBalloon: OnRep_Driver Role %s", tostring(self.Driver.Role)))
  end
  if slua.isValid(self.Driver) then
    self:PlayerEnterFireBalloon(self.Driver)
  end
  local SafePrevDriver = slua.isValid(uPreDrive) and uPreDrive or nil
  self.Super:OnRep_Driver(SafePrevDriver)
  self:RefreshLocalDriveUI()
  if slua.isValid(self.Driver) and slua.isValid(self.Driver.STCharacterMovement) then
    print(bWriteLog and "PMGCFireBalloon:OnRep_Driver skip drive animation movement mode")
  end
  if slua.isValid(self.Driver) and self.Driver.ReplicatedBasedMovement then
    if self.PActiveEffect1 then
      self.PActiveEffect1:SetActive(false, false)
    end
    if self.PActiveEffect2 then
      self.PActiveEffect2:SetActive(false, false)
    end
    print(bWriteLog and string.format("PMGCFireBalloon:OnMovementBaseChangedEvent00 %s %s", tostring(self.Driver.ReplicatedBasedMovement.bServerHasBaseComponent), tostring(self.Driver.ReplicatedBasedMovement.MovementBase)))
    if self.Driver.ReplicatedBasedMovement.bServerHasBaseComponent and (self.Driver.ReplicatedBasedMovement.MovementBase == nil or self.Driver:GetMovementBaseActor(self.Driver) ~= self.Object) then
      local ReplicatedBasedMovement = slua.IndexReference(self.Driver, "ReplicatedBasedMovement")
      ReplicatedBasedMovement.MovementBase = self:K2_GetRootComponent()
      print(bWriteLog and string.format("PMGCFireBalloon:OnMovementBaseChangedEvent33 %s", tostring(self.Driver.ReplicatedBasedMovement.MovementBase)))
      self.Driver:OnRep_ReplicatedBasedMovement()
    end
  end
  local uPlayerController = slua_GameFrontendHUD:GetPlayerController()
  if not slua.isValid(uPlayerController) then
    print(bWriteLog and "PMGCFireBalloon: OnRep_Driver slua_GameFrontendHUD:GetPlayerController() returned uPlayerController is invalid")
    return
  end
  local uCharacter = uPlayerController:GetPlayerCharacterSafety()
  if not slua.isValid(uCharacter) then
    print(bWriteLog and "PMGCFireBalloon: OnRep_Driver uPlayerController:GetPlayerCharacterSafety() returned invalid uCharacter")
    return
  end
  if slua.isValid(self.Driver) and uCharacter == self.Driver then
    local CharacterRot = self.Driver:K2_GetActorRotation()
    local DriverArea = self.DriverArea
    local DriverAreaRot = slua.isValid(DriverArea) and DriverArea:K2_GetComponentRotation() or self:K2_GetActorRotation()
    CharacterRot.Yaw = DriverAreaRot.Yaw + 90.0
    local CameraRot = self:K2_GetActorRotation()
    CameraRot.Yaw = CharacterRot.Yaw
    uPlayerController:SetControlRotation(CameraRot, "PMGCFireBalloon")
    print(bWriteLog and "PMGCFireBalloon:OnRep_Driver apply DriverArea rotation" .. " DriverAreaYaw=" .. tostring(DriverAreaRot.Yaw) .. " CharacterYaw=" .. tostring(CharacterRot.Yaw))
    self.Driver:K2_SetActorRotation(CharacterRot, false)
  end
  if slua.isValid(uPreDrive) and uCharacter == uPreDrive and self.Driver ~= uCharacter then
    self:SetCameraOffsetData(0, true)
    self:_ResetLocalDriverCamera(uPreDrive)
    local DriveFeature = uPreDrive.PMGCBalloonDriveFeature
    if DriveFeature then
      DriveFeature:LeaveBalloonPerspective()
    end
    self:RefreshLocalDriveUI()
  end
  if slua.isValid(self.Driver) and self.Driver == uCharacter then
    self:SetCameraOffsetData(1.0, false)
    self:RefreshLocalDriveUI()
    local DriveFeature = uCharacter.PMGCBalloonDriveFeature
    if DriveFeature then
      DriveFeature:EnterBalloonPerspective()
    end
    uCharacter.bUseControllerRotationYaw = false
  end
end

function PMGCFireBalloon:OnRep_BalloonState()
  print(bWriteLog and string.format("PMGCFireBalloon:OnRep_BalloonState %s", tostring(self.BalloonState)))
  if self.BalloonState >= EDollAirBalloonState.EDollAirBalloon_Blowing and self.BalloonSke then
    local UIUtil = require("client.common.ui_util")
    local gameInstance = UIUtil.GetGameInstance()
    local deviceLevel = gameInstance:GetDeviceLevel()
    if 1 < deviceLevel then
      self.BalloonSke:SetMinLOD(0)
    end
    self.Movement:SetSkipUpdate(false)
  end
  local uPlayerController = GameplayData.GetPlayerController()
  if not slua.isValid(uPlayerController) then
    return
  end
  if uPlayerController:IsSpectator() or uPlayerController.bIsForReplay or uPlayerController:IsObserver() then
    self.HasActived = true
  end
  if self.BalloonState == EDollAirBalloonState.EDollAirBalloon_Idle and not slua.isValid(self.Driver) and 0 >= self.PassengerNum and not self.HasActived then
    self.PActiveEffect1:SetActive(true, true)
    self.PActiveEffect2:SetActive(true, true)
    self.HasActived = true
  end
end

function PMGCFireBalloon:CacheBallonToMapIconSubsystem(IsShow)
  return
end

function PMGCFireBalloon:GetAttachedPickUps()
  local PickUps = {}
  local PickUpWrapperClass = import("PickUpWrapperActor")
  local APlayerTombBox = import("PlayerTombBox")
  local AttachedActors = self:GetAttachedActors(slua.Array(UEnums.EPropertyClass.Object, import("Actor")))
  for Index = 0, AttachedActors:Num() - 1 do
    local Actor = AttachedActors:Get(Index)
    if Game:IsValid(Actor) and (Game:IsClassOf(Actor, PickUpWrapperClass) or Game:IsClassOf(Actor, APlayerTombBox)) then
      table.insert(PickUps, Actor)
    end
  end
  return PickUps
end

function PMGCFireBalloon:GetShowHiddenActors()
  local Actors = self:GetAttachedPickUps()
  table.insert(Actors, self.Object)
  return Actors
end

function PMGCFireBalloon:ClearAttachedPickUp()
  for _, PickUp in ipairs(self:GetAttachedPickUps()) do
    PickUp:K2_DestroyActor()
  end
end

function PMGCFireBalloon:GetShowSpotTeleportPoints()
  local Points = {}
  local nIndex = 1
  while true do
    local uPoint = self["ShowSpotTeleportPoint" .. nIndex]
    if not slua.isValid(uPoint) then
      break
    end
    table.insert(Points, uPoint)
    nIndex = nIndex + 1
  end
  return Points
end

local class = require("class")
local CActivityActor = require("GameLua.Mod.BaseMod.Actor.ActivityActor")
local CPMGCFireBalloon = class(CActivityActor, nil, PMGCFireBalloon)
return CPMGCFireBalloon
