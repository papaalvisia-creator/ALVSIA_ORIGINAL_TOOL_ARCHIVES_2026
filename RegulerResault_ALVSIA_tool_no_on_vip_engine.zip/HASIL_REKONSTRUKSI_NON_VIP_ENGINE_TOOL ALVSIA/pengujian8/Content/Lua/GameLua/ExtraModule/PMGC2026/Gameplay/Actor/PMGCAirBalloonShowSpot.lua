local AirBalloonShowSpot = {}
local GameplayData = require("GameLua.GameCore.Data.GameplayData")
local IngameTipsTools = require("GameLua.Mod.BaseMod.Common.UI.InGameTipsTools")
local AirBalloonShowSpotConfig = require("GameLua.ExtraModule.PMGC2026.Gameplay.Config.PMGCAirBalloonShowSpotConfig")
local RewardPackConfig = require("GameLua.ExtraModule.PMGC2026.Gameplay.Config.PMGCRewardPackConfig")
local NoAvailableBalloonHintIntervalSeconds = 5
local JoinTeleportDelaySeconds = 1
local GroundBalloonAppearanceLogTag = "[PMGC2026][GroundBalloonMaterial]"

function AirBalloonShowSpot:ctor(selfType)
  AirBalloonShowSpot.__super.ctor(self, selfType)
  self.OwnedBalloons = {}
  self.LockedBalloonSlotIndices = nil
  self.CurrentShowBalloonSlotIndex = nil
  self.PendingTakeOffPlayers = nil
  self.EmptyBalloonCheckTimer = nil
  self.TakeOffStageUnlockTimer = nil
  self.AvailableBalloonCount = nil
  self.LastAvailableBalloonCount = nil
  self.SlotEmptySeconds = {}
  self.SlotEverOccupied = {}
  self.SlotRetired = {}
  self.NoAvailableBalloonHintTimers = {}
  self.GroundBalloonAppearanceInitialized = false
  self.GroundBalloonAppearanceTween = nil
  self.GeneralShowAreaWelcomePlayerKeys = {}
  self.bGeneralShowAreaEventRegistered = false
  self.RewardPackPlayerKeys = {}
  self.ObservedBalloonPassengers = {}
end

function AirBalloonShowSpot:ReceiveBeginPlay()
  AirBalloonShowSpot.__super.ReceiveBeginPlay(self)
  if Client then
    if self.AkComponent and self.CheerSound then
      self.AkComponent:PostEventInRange(self.CheerSound, 25000000)
    else
      print(bWriteLog and "AirBalloonShowSpot:ReceiveBeginPlay cheer sound missing AkComponent or CheerSound")
    end
    return
  end
  self.NetCullDistanceSquared = 2.25E10
  local Config = self:_GetConfig()
  local BalloonRoster = Config and Config.BalloonRoster
  local nRosterCount = type(BalloonRoster) == "table" and #BalloonRoster or 0
  print(bWriteLog and string.format("AirBalloonShowSpot:ReceiveBeginPlay config RosterCount=%s NoAvailableBalloonTipsID=%s", tostring(nRosterCount), tostring(Config and Config.NoAvailableBalloonTipsID)))
  self.AvailableBalloonCount = 0
  self:_RegisterGeneralShowAreaBeginOverlap()
  self:_SpawnOwnedBalloons()
end

function AirBalloonShowSpot:_RegisterGeneralShowAreaBeginOverlap()
  if Client or self.bGeneralShowAreaEventRegistered then
    return
  end
  if not slua.isValid(self.GeneralShowArea) then
    print(bWriteLog and "AirBalloonShowSpot:_RegisterGeneralShowAreaBeginOverlap invalid GeneralShowArea")
    return
  end
  self:AddControlEvent(self.GeneralShowArea, "OnComponentBeginOverlap", self._OnGeneralShowAreaBeginOverlap, self)
  self.bGeneralShowAreaEventRegistered = true
  print(bWriteLog and "AirBalloonShowSpot:_RegisterGeneralShowAreaBeginOverlap registered")
end

function AirBalloonShowSpot:_OnGeneralShowAreaBeginOverlap(SelfComp, OtherActor)
  if not (not Client and slua.isValid(OtherActor) and OtherActor.PlayerKey) or not Game:IsPlayer(OtherActor) then
    return
  end
  local PlayerKey = OtherActor.PlayerKey
  if self.GeneralShowAreaWelcomePlayerKeys[PlayerKey] then
    return
  end
  local Config = self:_GetConfig()
  local nTipsID = Config and Config.GeneralShowAreaWelcomeTipsID
  if not nTipsID or nTipsID <= 0 then
    print(bWriteLog and string.format("AirBalloonShowSpot:_OnGeneralShowAreaBeginOverlap invalid welcome TipsID %s", tostring(nTipsID)))
    return
  end
  self.GeneralShowAreaWelcomePlayerKeys[PlayerKey] = true
  print(bWriteLog and string.format("AirBalloonShowSpot:_OnGeneralShowAreaBeginOverlap send welcome hint PlayerKey=%s TipsID=%s", tostring(PlayerKey), tostring(nTipsID)))
  self:SendTips(PlayerKey, nTipsID)
end

function AirBalloonShowSpot:_SpawnOwnedBalloons()
  self.OwnedBalloons = {}
  local Config = self:_GetConfig()
  local sBalloonPath = Config and Config.BalloonBlueprintPath
  local BalloonRoster = Config and Config.BalloonRoster
  local nRosterCount = type(BalloonRoster) == "table" and #BalloonRoster or 0
  if not sBalloonPath or sBalloonPath == "" or nRosterCount <= 0 then
    print(bWriteLog and string.format("AirBalloonShowSpot:_SpawnOwnedBalloons invalid config BalloonBlueprintPath=%s RosterCount=%s NoAvailableBalloonTipsID=%s", tostring(sBalloonPath), tostring(nRosterCount), tostring(Config and Config.NoAvailableBalloonTipsID)))
    return
  end
  local uBalloonClass = slua.loadClass(sBalloonPath)
  if not uBalloonClass then
    print(bWriteLog and "AirBalloonShowSpot:_SpawnOwnedBalloons loadClass failed path:" .. tostring(sBalloonPath))
    return
  end
  if not slua.isValid(CGameWorld) then
    print(bWriteLog and "AirBalloonShowSpot:_SpawnOwnedBalloons CGameWorld invalid")
    return
  end
  local BaseLocation = self:K2_GetActorLocation()
  local nManagedBalloonFuel = Config.ManagedBalloonFuel or 120
  for nIndex, SlotConfig in ipairs(BalloonRoster) do
    self.SlotEmptySeconds[nIndex] = 0
    self.SlotEverOccupied[nIndex] = false
    self.SlotRetired[nIndex] = false
    self.ObservedBalloonPassengers[nIndex] = {}
    local fHeight = SlotConfig and SlotConfig.Height or BaseLocation.Z
    local SpawnLocation = FVector(BaseLocation.X, BaseLocation.Y, fHeight)
    local uBalloon = CGameWorld:SpawnActor(uBalloonClass, SpawnLocation, FRotator(0, 0, 0), nil)
    if slua.isValid(uBalloon) then
      table.insert(self.OwnedBalloons, uBalloon)
      if uBalloon.SetManagedByShowSpot then
        uBalloon:SetManagedByShowSpot(true, nManagedBalloonFuel)
      else
        print(bWriteLog and "AirBalloonShowSpot:_SpawnOwnedBalloons missing SetManagedByShowSpot")
      end
      if uBalloon.SetSkyTransitionID then
        uBalloon:SetSkyTransitionID(Config.SkyTransitionID)
      else
        print(bWriteLog and "AirBalloonShowSpot:_SpawnOwnedBalloons missing SetSkyTransitionID")
      end
      if uBalloon.SetAppearanceMaterialIndex then
        uBalloon:SetAppearanceMaterialIndex(nIndex)
      else
        print(bWriteLog and "AirBalloonShowSpot:_SpawnOwnedBalloons missing SetAppearanceMaterialIndex")
      end
      uBalloon:InitializeParachuteStages()
      self:_SetSlotVisible(nIndex, false)
      print(bWriteLog and "AirBalloonShowSpot:_SpawnOwnedBalloons spawned slot:" .. tostring(nIndex) .. " height:" .. tostring(fHeight))
    else
      table.insert(self.OwnedBalloons, false)
      print(bWriteLog and "AirBalloonShowSpot:_SpawnOwnedBalloons spawn FAILED slot:" .. tostring(nIndex))
    end
  end
  self.AvailableBalloonCount = self:GetAvailableBalloonCount()
  self:ForceNetUpdate()
  self:_StartEmptyBalloonCheck()
end

function AirBalloonShowSpot:_GetStageOfBalloon(uBalloon)
  if not slua.isValid(uBalloon) then
    print(bWriteLog and "AirBalloonShowSpot:_GetStageOfBalloon invalid uBalloon, early return")
    return nil
  end
  local Config = self:_GetConfig()
  local sCompName = Config and Config.BalloonStageChildActorCompName
  if not sCompName or sCompName == "" then
    print(bWriteLog and "AirBalloonShowSpot:_GetStageOfBalloon invalid sCompName, early return")
    return nil
  end
  local uComp = uBalloon[sCompName]
  if not slua.isValid(uComp) then
    print(bWriteLog and "AirBalloonShowSpot:_GetStageOfBalloon invalid uComp, early return")
    return nil
  end
  return uComp.ChildActor
end

function AirBalloonShowSpot:ReceiveEndPlay(EndPlayReason)
  if not Client then
    if self.EmptyBalloonCheckTimer then
      self:RemoveGameTimer(self.EmptyBalloonCheckTimer)
      self.EmptyBalloonCheckTimer = nil
    end
    if self.TakeOffStageUnlockTimer then
      self:RemoveGameTimer(self.TakeOffStageUnlockTimer)
      self.TakeOffStageUnlockTimer = nil
    end
    for _, Timer in pairs(self.NoAvailableBalloonHintTimers or {}) do
      if Timer then
        self:RemoveGameTimer(Timer)
      end
    end
    self.NoAvailableBalloonHintTimers = {}
    self.ObservedBalloonPassengers = {}
    for _, uBalloon in ipairs(self.OwnedBalloons or {}) do
      if slua.isValid(uBalloon) and uBalloon.Passengers then
        for PassengerIndex = 0, uBalloon.Passengers:Num() - 1 do
          local Passenger = uBalloon.Passengers:Get(PassengerIndex)
          if slua.isValid(Passenger) and Passenger.PlayerKey then
            self.RewardPackPlayerKeys[Passenger.PlayerKey] = true
          end
        end
      end
      if slua.isValid(uBalloon) then
        uBalloon:K2_DestroyActor()
      end
    end
    self.OwnedBalloons = {}
  end
  self.bCheerSoundPaused = false
  if Client and self.AkComponent then
    self.AkComponent:StopEventInRange()
  else
    print(bWriteLog and "AirBalloonShowSpot:ReceiveEndPlay AkComponent or CheerSoundStop invalid")
  end
  AirBalloonShowSpot.__super.ReceiveEndPlay(self, EndPlayReason)
end

function AirBalloonShowSpot:GetLifetimeReplicatedProps()
  local ELifetimeCondition = import("ELifetimeCondition")
  local RepTable = {
    {
      "LockedBalloonSlotIndices",
      ELifetimeCondition.COND_None,
      UEnums.EPropertyClass.Array,
      UEnums.EPropertyClass.Int64
    },
    {
      "AvailableBalloonCount",
      ELifetimeCondition.COND_None,
      UEnums.EPropertyClass.Int8
    },
    {
      "CurrentShowBalloonSlotIndex",
      ELifetimeCondition.COND_None,
      UEnums.EPropertyClass.Int8
    }
  }
  if AirBalloonShowSpot.__super.GetLifetimeReplicatedProps then
    local BaseRepTable = AirBalloonShowSpot.__super.GetLifetimeReplicatedProps(self)
    if BaseRepTable then
      table.move(BaseRepTable, 1, #BaseRepTable, #RepTable + 1, RepTable)
    end
  end
  return RepTable
end

function AirBalloonShowSpot:_FindAvailableBalloonSlot()
  self.LockedBalloonSlotIndices = self.LockedBalloonSlotIndices or slua.Array(UEnums.EPropertyClass.Int64)
  self.SlotRetired = self.SlotRetired or {}
  for nIndex = 1, #self.OwnedBalloons do
    if slua.isValid(self.OwnedBalloons[nIndex]) and not Game:Contains(self.LockedBalloonSlotIndices, nIndex) and not self.SlotRetired[nIndex] then
      return nIndex
    end
  end
  return nil
end

function AirBalloonShowSpot:GetAvailableBalloonCount()
  self.LockedBalloonSlotIndices = self.LockedBalloonSlotIndices or slua.Array(UEnums.EPropertyClass.Int64)
  local nCount = 0
  for nIndex = 1, #self.OwnedBalloons do
    if slua.isValid(self.OwnedBalloons[nIndex]) and not Game:Contains(self.LockedBalloonSlotIndices, nIndex) then
      nCount = nCount + 1
    end
  end
  return nCount
end

function AirBalloonShowSpot:_RegisterInteractiveCompOverlapEvents()
  AirBalloonShowSpot.__super._RegisterInteractiveCompOverlapEvents(self)
  if Client then
    return
  end
  local UniqueJoinPrimSet = {}
  for uComp, _ in pairs(self.JoinCompMap or {}) do
    for _, uPrim in ipairs(self:_GetPrimitivesOfInteractiveComp(uComp)) do
      UniqueJoinPrimSet[uPrim] = true
    end
  end
  local nRegisteredCount = 0
  for uPrim, _ in pairs(UniqueJoinPrimSet) do
    self:AddControlEvent(uPrim, "OnComponentBeginOverlap", self._OnJoinAreaBeginOverlap, self)
    nRegisteredCount = nRegisteredCount + 1
  end
  print(bWriteLog and "AirBalloonShowSpot:_RegisterInteractiveCompOverlapEvents begin count:" .. tostring(nRegisteredCount))
end

function AirBalloonShowSpot:_OnJoinAreaBeginOverlap(SelfComp, OtherActor)
  if not (not Client and slua.isValid(OtherActor)) or not OtherActor.PlayerKey then
    return
  end
  local nAvailableSlotIndex = self:_FindAvailableBalloonSlot()
  if nAvailableSlotIndex then
    return
  end
  local Config = self:_GetConfig()
  local nTipsID = Config and Config.NoAvailableBalloonTipsID
  local PlayerKey = OtherActor.PlayerKey
  local HintTimer = self.NoAvailableBalloonHintTimers[PlayerKey]
  print(bWriteLog and string.format("AirBalloonShowSpot:_OnJoinAreaBeginOverlap PlayerKey=%s TipsID=%s HintTimer=%s AvailableSlotIndex=%s", tostring(PlayerKey), tostring(nTipsID), tostring(HintTimer), tostring(nAvailableSlotIndex)))
  if not nTipsID or nTipsID <= 0 or HintTimer then
    return
  end
  local Timer
  Timer = self:AddGameTimer(NoAvailableBalloonHintIntervalSeconds, false, function()
    if self.NoAvailableBalloonHintTimers[PlayerKey] == Timer then
      self.NoAvailableBalloonHintTimers[PlayerKey] = nil
    end
    print(bWriteLog and string.format("AirBalloonShowSpot:_OnJoinAreaBeginOverlap hint timer expired PlayerKey=%s", tostring(PlayerKey)))
  end)
  self.NoAvailableBalloonHintTimers[PlayerKey] = Timer
  print(bWriteLog and string.format("AirBalloonShowSpot:_OnJoinAreaBeginOverlap send hint PlayerKey=%s TipsID=%s Interval=%s", tostring(PlayerKey), tostring(nTipsID), tostring(NoAvailableBalloonHintIntervalSeconds)))
  self:SendTips(PlayerKey, nTipsID)
end

function AirBalloonShowSpot:OnAllowToInteract(uCharacter, Component)
  local bIsJoinComponent = self:_IsJoinComponent(Component)
  local nAvailableSlotIndex = bIsJoinComponent and self:_FindAvailableBalloonSlot() or nil
  print(bWriteLog and string.format("AirBalloonShowSpot:OnAllowToInteract IsJoin=%s PlayerKey=%s AvailableSlotIndex=%s Component=%s", tostring(bIsJoinComponent), tostring(slua.isValid(uCharacter) and uCharacter.PlayerKey), tostring(nAvailableSlotIndex), tostring(Component)))
  if bIsJoinComponent and not nAvailableSlotIndex then
    print(bWriteLog and "AirBalloonShowSpot:OnAllowToInteract no available balloon slot, hide Join")
    return false
  end
  return AirBalloonShowSpot.__super.OnAllowToInteract(self, uCharacter, Component)
end

function AirBalloonShowSpot:_ToggleSelfAndTeammateHidden(bHide)
  AirBalloonShowSpot.__super._ToggleSelfAndTeammateHidden(self, bHide)
  if not Client then
    return
  end
  if self.AkComponent and self.CheerSound then
    if bHide and not self.bCheerSoundPaused then
      self.bCheerSoundPaused = true
      self.AkComponent:StopEventInRange()
    elseif not bHide and self.bCheerSoundPaused then
      self.bCheerSoundPaused = false
      self.AkComponent:PostEventInRange(self.CheerSound, 25000000)
    end
  end
  local Config = self:_GetConfig()
  local Names = Config and Config.GroundShowHiddenComponentNames
  if bHide and Names then
    local Controller = GameplayData.GetPlayerController()
    if slua.isValid(Controller) then
      local HiddenList = {}
      for _, Name in ipairs(Names) do
        print(bWriteLog and string.format("AirBalloonShowSpot:_ToggleSelfAndTeammateHidden Name=%s", Name))
        local Component = self:_GetSceneComponentByName(Name)
        if Component then
          print(bWriteLog and string.format("AirBalloonShowSpot:_ToggleSelfAndTeammateHidden Component=%s", Component))
          Controller.HiddenPrimitiveComponents:AddUnique(Component)
          HiddenList[#HiddenList + 1] = Component
        end
      end
      self.ShowHiddenList = HiddenList
      self.ShowHiddenController = Controller
    end
  elseif self.ShowHiddenList then
    if slua.isValid(self.ShowHiddenController) then
      local Hidden = self.ShowHiddenController.HiddenPrimitiveComponents
      for i = #self.ShowHiddenList, 1, -1 do
        for Index = Hidden:Num() - 1, 0, -1 do
          if Hidden:Get(Index) == self.ShowHiddenList[i] then
            Hidden:Remove(Index)
            break
          end
        end
      end
    end
    self.ShowHiddenList = nil
    self.ShowHiddenController = nil
  end
end

function AirBalloonShowSpot:_SetGroundBalloonComponentVisible(sComponentName, bVisible)
  local uComponent = sComponentName and self[sComponentName]
  if not slua.isValid(uComponent) or not uComponent.SetVisibility then
    print(bWriteLog and "AirBalloonShowSpot:_SetGroundBalloonComponentVisible - invalid component")
    return
  end
  uComponent:SetVisibility(bVisible, true)
end

function AirBalloonShowSpot:_ApplyGroundBalloonDisplay(bAnimate)
  local Config = self:_GetConfig()
  local BalloonRoster = Config and Config.BalloonRoster
  local CandidateNames = Config and Config.GroundCandidateBalloonComponentNames
  local nTotal = type(BalloonRoster) == "table" and #BalloonRoster or 0
  local nAvailable = self.AvailableBalloonCount
  if type(nAvailable) ~= "number" then
    nAvailable = nTotal
  end
  nAvailable = math.max(0, math.min(nTotal, nAvailable))
  local nUsed = nTotal - nAvailable
  print(bWriteLog and string.format("%s ApplyDisplay available=%s total=%s used=%s animate=%s initialized=%s", GroundBalloonAppearanceLogTag, tostring(nAvailable), tostring(nTotal), tostring(nUsed), tostring(bAnimate), tostring(self.GroundBalloonAppearanceInitialized)))
  if type(CandidateNames) == "table" then
    for nIndex, sComponentName in ipairs(CandidateNames) do
      self:_SetGroundBalloonComponentVisible(sComponentName, nTotal >= nIndex and nUsed < nIndex)
    end
  end
  if not self.GroundBalloonAppearanceInitialized then
    local MaterialPathList = Config and Config.GroundBalloonAppearanceMaterialPathList
    local nMaterialCount = type(MaterialPathList) == "table" and #MaterialPathList or 0
    if 0 < nMaterialCount then
      local nMaterialIndex = math.min(nUsed + 1, nMaterialCount)
      local fDissolveAmount = nUsed >= nMaterialCount and 0 or 1
      print(bWriteLog and string.format("%s Init materialIndex=%s dissolve=%s materialCount=%s", GroundBalloonAppearanceLogTag, tostring(nMaterialIndex), tostring(fDissolveAmount), tostring(nMaterialCount)))
      self:_SetGroundBalloonAppearanceMaterial(nMaterialIndex, fDissolveAmount)
      self.GroundBalloonAppearanceInitialized = true
    else
      print(bWriteLog and GroundBalloonAppearanceLogTag .. " Init skipped: no material paths")
    end
  elseif bAnimate and 0 < nUsed then
    local MaterialPathList = Config and Config.GroundBalloonAppearanceMaterialPathList
    local nMaterialCount = type(MaterialPathList) == "table" and #MaterialPathList or 0
    if 0 < nMaterialCount then
      local nMaterialIndex = math.min(nUsed, nMaterialCount)
      print(bWriteLog and string.format("%s Transition requested used=%s materialIndex=%s materialCount=%s", GroundBalloonAppearanceLogTag, tostring(nUsed), tostring(nMaterialIndex), tostring(nMaterialCount)))
      self:_PlayGroundBalloonAppearanceTransition(nMaterialIndex)
    else
      print(bWriteLog and GroundBalloonAppearanceLogTag .. " Transition skipped: no material paths")
    end
  elseif bAnimate then
    print(bWriteLog and string.format("%s Transition skipped used=%s", GroundBalloonAppearanceLogTag, tostring(nUsed)))
  end
end

function AirBalloonShowSpot:_LoadGroundBalloonAppearanceMaterial(nMaterialIndex, Callback)
  if not Client or type(Callback) ~= "function" then
    return
  end
  local Config = self:_GetConfig()
  local MaterialPathList = Config and Config.GroundBalloonAppearanceMaterialPathList
  local sMaterialPath = MaterialPathList and MaterialPathList[nMaterialIndex]
  print(bWriteLog and string.format("%s Load request index=%s path=%s", GroundBalloonAppearanceLogTag, tostring(nMaterialIndex), tostring(sMaterialPath)))
  if not sMaterialPath then
    print(bWriteLog and GroundBalloonAppearanceLogTag .. " Load skipped: missing path")
    return
  end
  local Util = require("client.slua_ui_framework.util")
  Util.GetAssetAsync(sMaterialPath, function(uMaterial)
    if slua.isValid(uMaterial) then
      print(bWriteLog and string.format("%s Load success index=%s asset=%s", GroundBalloonAppearanceLogTag, tostring(nMaterialIndex), tostring(uMaterial)))
      Callback(uMaterial)
    else
      print(bWriteLog and string.format("%s Load failed index=%s path=%s", GroundBalloonAppearanceLogTag, tostring(nMaterialIndex), tostring(sMaterialPath)))
    end
  end)
end

function AirBalloonShowSpot:_SetGroundBalloonAppearanceMaterial(nMaterialIndex, fDissolveAmount)
  if not Client then
    return
  end
  local Config = self:_GetConfig()
  local sComponentName = Config and Config.GroundMainBalloonComponentName
  local nMaterialSlot = Config and Config.GroundBalloonAppearanceMaterialSlot or 0
  local sParameterName = Config and Config.GroundBalloonAppearanceParameterName or "DissolveAmount"
  local uMainBalloon = sComponentName and self[sComponentName]
  print(bWriteLog and string.format("%s SetMaterial request index=%s component=%s slot=%s dissolve=%s", GroundBalloonAppearanceLogTag, tostring(nMaterialIndex), tostring(sComponentName), tostring(nMaterialSlot), tostring(fDissolveAmount)))
  if not slua.isValid(uMainBalloon) or not uMainBalloon.SetMaterial then
    print(bWriteLog and GroundBalloonAppearanceLogTag .. " SetMaterial failed: invalid MainBalloon")
    return
  end
  self:_LoadGroundBalloonAppearanceMaterial(nMaterialIndex, function(uMaterial)
    if not slua.isValid(uMainBalloon) then
      print(bWriteLog and GroundBalloonAppearanceLogTag .. " SetMaterial callback skipped: MainBalloon invalid")
      return
    end
    uMainBalloon:SetMaterial(nMaterialSlot, uMaterial)
    local uDynamicMaterial = uMainBalloon.CreateAndSetMaterialInstanceDynamic and uMainBalloon:CreateAndSetMaterialInstanceDynamic(nMaterialSlot)
    if slua.isValid(uDynamicMaterial) and uDynamicMaterial.SetScalarParameterValue then
      uDynamicMaterial:SetScalarParameterValue(sParameterName, fDissolveAmount)
      print(bWriteLog and string.format("%s SetMaterial success index=%s slot=%s parameter=%s dissolve=%s", GroundBalloonAppearanceLogTag, tostring(nMaterialIndex), tostring(nMaterialSlot), tostring(sParameterName), tostring(fDissolveAmount)))
    else
      print(bWriteLog and GroundBalloonAppearanceLogTag .. " SetMaterial failed: dynamic material invalid")
    end
  end)
end

function AirBalloonShowSpot:_PlayGroundBalloonAppearanceTransition(nAppearanceIndex)
  if not Client then
    return
  end
  local Config = self:_GetConfig()
  local sComponentName = Config and Config.GroundMainBalloonComponentName
  local nMaterialSlot = Config and Config.GroundBalloonAppearanceMaterialSlot or 0
  local sParameterName = Config and Config.GroundBalloonAppearanceParameterName or "DissolveAmount"
  local fDuration = Config and Config.GroundBalloonAppearanceTransitionDuration or 1.0
  local uMainBalloon = sComponentName and self[sComponentName]
  print(bWriteLog and string.format("%s Transition start index=%s component=%s slot=%s parameter=%s duration=%s", GroundBalloonAppearanceLogTag, tostring(nAppearanceIndex), tostring(sComponentName), tostring(nMaterialSlot), tostring(sParameterName), tostring(fDuration)))
  if not slua.isValid(uMainBalloon) or not uMainBalloon.SetMaterial then
    print(bWriteLog and GroundBalloonAppearanceLogTag .. " Transition failed: invalid MainBalloon")
    return
  end
  self:_LoadGroundBalloonAppearanceMaterial(nAppearanceIndex, function(uMaterial)
    if not slua.isValid(uMainBalloon) then
      print(bWriteLog and GroundBalloonAppearanceLogTag .. " Transition callback skipped: MainBalloon invalid")
      return
    end
    uMainBalloon:SetMaterial(nMaterialSlot, uMaterial)
    local uDynamicMaterial = uMainBalloon.CreateAndSetMaterialInstanceDynamic and uMainBalloon:CreateAndSetMaterialInstanceDynamic(nMaterialSlot)
    if not slua.isValid(uDynamicMaterial) then
      print(bWriteLog and GroundBalloonAppearanceLogTag .. " Transition failed: dynamic material invalid")
      return
    end
    uDynamicMaterial:SetScalarParameterValue(sParameterName, 1)
    print(bWriteLog and string.format("%s Transition material applied index=%s dissolve=1", GroundBalloonAppearanceLogTag, tostring(nAppearanceIndex)))
    if slua.isValid(self.GroundBalloonAppearanceTween) then
      print(bWriteLog and GroundBalloonAppearanceLogTag .. " Transition cancel previous tween")
      self.GroundBalloonAppearanceTween:DeleteTween()
      self.GroundBalloonAppearanceTween = nil
    end
    local UTweenFloatStandardFactory = import("TweenFloatStandardFactory")
    local UTweenManagerComponentClass = import("TweenManagerComponent")
    local uTweenManager = self:GetComponentByClass(UTweenManagerComponentClass)
    uTweenManager = slua.isValid(uTweenManager) and uTweenManager or Game:AddComponent(UTweenManagerComponentClass, self, "GroundBalloonAppearanceTweenManager")
    local ETweenEaseType = import("ETweenEaseType")
    local ETweenLoopType = import("ETweenLoopType")
    local _, _, Tween = UTweenFloatStandardFactory.BP_CreateTweenMaterialFloatFromTo(uTweenManager, uDynamicMaterial, nil, nil, sParameterName, 1, 0, fDuration, ETweenEaseType.Linear, 1, ETweenLoopType.Restart, 0, 1, -1)
    self.GroundBalloonAppearanceTween = Tween
    print(bWriteLog and string.format("%s Tween created index=%s valid=%s", GroundBalloonAppearanceLogTag, tostring(nAppearanceIndex), tostring(slua.isValid(Tween))))
    if not slua.isValid(Tween) or not Tween.OnTweenEnd then
      print(bWriteLog and GroundBalloonAppearanceLogTag .. " Transition failed: tween or OnTweenEnd invalid")
      return
    end
    Tween.OnTweenEnd:Add(function()
      print(bWriteLog and string.format("%s Tween end index=%s currentTween=%s", GroundBalloonAppearanceLogTag, tostring(nAppearanceIndex), tostring(self.GroundBalloonAppearanceTween == Tween)))
      if self.GroundBalloonAppearanceTween ~= Tween then
        return
      end
      self.GroundBalloonAppearanceTween = nil
      local MaterialPathList = Config and Config.GroundBalloonAppearanceMaterialPathList
      local nNextMaterialIndex = nAppearanceIndex + 1
      if MaterialPathList and MaterialPathList[nNextMaterialIndex] then
        print(bWriteLog and string.format("%s Switch after tween nextIndex=%s resetDissolve=1", GroundBalloonAppearanceLogTag, tostring(nNextMaterialIndex)))
        self:_SetGroundBalloonAppearanceMaterial(nNextMaterialIndex, 1)
      else
        print(bWriteLog and string.format("%s Tween finished final index=%s", GroundBalloonAppearanceLogTag, tostring(nAppearanceIndex)))
      end
    end)
  end)
end

function AirBalloonShowSpot:OnRep_AvailableBalloonCount()
  if not Client then
    return
  end
  local nCurrent = self.AvailableBalloonCount
  local bAnimate = self.LastAvailableBalloonCount ~= nil and self.LastAvailableBalloonCount ~= nCurrent
  print(bWriteLog and string.format("%s OnRep available=%s last=%s animate=%s", GroundBalloonAppearanceLogTag, tostring(nCurrent), tostring(self.LastAvailableBalloonCount), tostring(bAnimate)))
  self:_ApplyGroundBalloonDisplay(bAnimate)
  self.LastAvailableBalloonCount = nCurrent
end

function AirBalloonShowSpot:_EnableInteractiveComp(bEnable)
  if not Client and bEnable then
    self.AvailableBalloonCount = math.max(0, (self.AvailableBalloonCount or 0) - 1)
    print(bWriteLog and string.format("%s Server count consumed available=%s", GroundBalloonAppearanceLogTag, tostring(self.AvailableBalloonCount)))
    self:ForceNetUpdate()
    if not self:_FindAvailableBalloonSlot() then
      bEnable = false
    end
  end
  AirBalloonShowSpot.__super._EnableInteractiveComp(self, bEnable)
end

function AirBalloonShowSpot:OnRep_nPlayShow()
  AirBalloonShowSpot.__super.OnRep_nPlayShow(self)
  if not Client then
    return
  end
  local Config = self:_GetConfig()
  local sComponentName = Config and Config.GroundMainBalloonComponentName
  local uMainBalloon = sComponentName and self[sComponentName]
  if not slua.isValid(uMainBalloon) or not uMainBalloon.SetCollisionEnabled then
    print(bWriteLog and "AirBalloonShowSpot:OnRep_nPlayShow invalid MainBalloon")
    return
  end
  local ECollisionEnabled = import("ECollisionEnabled")
  if self.nPlayShow and self.nPlayShow > 0 then
    if not self.GroundMainBalloonCollisionBackup then
      self.GroundMainBalloonCollisionBackup = uMainBalloon:GetCollisionEnabled()
    end
    uMainBalloon:SetCollisionEnabled(ECollisionEnabled.QueryOnly)
  elseif self.GroundMainBalloonCollisionBackup then
    uMainBalloon:SetCollisionEnabled(self.GroundMainBalloonCollisionBackup)
    self.GroundMainBalloonCollisionBackup = nil
  end
end

function AirBalloonShowSpot:_EndShow()
  if not Client or self.bEndShow then
    return
  end
  local uPlayerController = GameplayData.GetPlayerController()
  local nTipsID = AirBalloonShowSpotConfig.BalloonBoardingTipsID
  local nDuration = AirBalloonShowSpotConfig.ManagedBalloonFuel or 120
  local bCanShowTips = slua.isValid(uPlayerController) and uPlayerController.PlayerKey and nTipsID and 0 < nTipsID
  print(bWriteLog and string.format("AirBalloonShowSpot:_EndShow PlayerKey=%s TipsID=%s Duration=%s CanShowTips=%s", tostring(uPlayerController and uPlayerController.PlayerKey), tostring(nTipsID), tostring(nDuration), tostring(bCanShowTips)))
  AirBalloonShowSpot.__super._EndShow(self)
  local Pawn = slua.isValid(uPlayerController) and uPlayerController:GetPlayerCharacterSafety()
  if slua.isValid(Pawn) and Pawn.PMGCBalloonShowFeature then
    Pawn.PMGCBalloonShowFeature:ServerRPC_ConfirmTakeOffEnd(self.Object, self.CurrentShowBalloonSlotIndex)
  end
  if bCanShowTips then
    print(bWriteLog and string.format("AirBalloonShowSpot:_EndShow show boarding tip. TipsID=%s Duration=%s", tostring(nTipsID), tostring(nDuration)))
    IngameTipsTools.BattleGeneralTip(nTipsID, nDuration)
  end
end

function AirBalloonShowSpot:_UnlockTakeOffStageDelayed()
  if Client or not self.PendingTakeOffPlayers then
    return
  end
  self.PendingTakeOffPlayers = nil
  local Slot = self.CurrentShowBalloonSlotIndex
  self.TakeOffStageUnlockTimer = self:AddGameTimer((self:_GetConfig() or {}).TakeOffStageUnlockDelaySeconds or 0, false, function()
    if self.CurrentShowBalloonSlotIndex ~= Slot then
      return
    end
    local Balloon = self.OwnedBalloons[Slot]
    if slua.isValid(Balloon) then
      Balloon:SetParachuteStagesEnabled(true)
    end
    print(bWriteLog and string.format("AirBalloonShowSpot:_UnlockTakeOffStageDelayed unlock spot=%s slot=%s", tostring(self.Object), tostring(Slot)))
  end)
end

function AirBalloonShowSpot:HandleTakeOffFinished(PlayerKey, Slot)
  local Pending = self.PendingTakeOffPlayers
  if not (not Client and Slot == self.CurrentShowBalloonSlotIndex and Pending) or not Pending[PlayerKey] then
    print(bWriteLog and string.format("AirBalloonShowSpot:HandleTakeOffFinished ignore spot=%s slot=%s player=%s", tostring(self.Object), tostring(Slot), tostring(PlayerKey)))
    return
  end
  Pending[PlayerKey] = nil
  local Remaining = 0
  for _ in pairs(Pending) do
    Remaining = Remaining + 1
  end
  print(bWriteLog and string.format("AirBalloonShowSpot:HandleTakeOffFinished finished spot=%s slot=%s player=%s remaining=%s", tostring(self.Object), tostring(Slot), tostring(PlayerKey), tostring(Remaining)))
  if Remaining == 0 then
    self:_UnlockTakeOffStageDelayed()
  end
end

function AirBalloonShowSpot:_OnServerShowEnd()
  AirBalloonShowSpot.__super._OnServerShowEnd(self)
  self:_UnlockTakeOffStageDelayed()
end

function AirBalloonShowSpot:_OnInteractiveAreaEndOverlap(SelfComp, OtherActor, OtherComp, OtherBodyIndex)
  if self.nPlayShow and self.nPlayShow > 0 or self.bInCoolDown then
    return
  end
  AirBalloonShowSpot.__super._OnInteractiveAreaEndOverlap(self, SelfComp, OtherActor, OtherComp, OtherBodyIndex)
end

function AirBalloonShowSpot:_PickSequenceIndex(nReadyPlayerNum, LevelSequencePathList)
  self.SlotEmptySeconds = self.SlotEmptySeconds or {}
  self.SlotEverOccupied = self.SlotEverOccupied or {}
  self.SlotRetired = self.SlotRetired or {}
  local nSlotIndex = self:_FindAvailableBalloonSlot()
  if not nSlotIndex then
    print(bWriteLog and "AirBalloonShowSpot:_PickSequenceIndex no balloon slot available, abort show")
    return nil
  end
  if not self.LockedBalloonSlotIndices then
    print(bWriteLog and "AirBalloonShowSpot:_PickSequenceIndex LockedBalloonSlotIndices not provisioned yet")
    return nil
  end
  self.LockedBalloonSlotIndices:Add(nSlotIndex)
  self.CurrentShowBalloonSlotIndex = nSlotIndex
  self.PendingTakeOffPlayers = {}
  for Index = 0, self.ReadyPlayerList:Num() - 1 do
    self.PendingTakeOffPlayers[self.ReadyPlayerList:Get(Index)] = true
  end
  self.OwnedBalloons[nSlotIndex]:SetParachuteStagesEnabled(false)
  print(bWriteLog and string.format("AirBalloonShowSpot:_PickSequenceIndex lock spot=%s slot=%s players=%s", tostring(self.Object), tostring(nSlotIndex), tostring(self.ReadyPlayerList:Num())))
  self.SlotEmptySeconds[nSlotIndex] = 0
  self.SlotEverOccupied[nSlotIndex] = false
  self.SlotRetired[nSlotIndex] = false
  print(bWriteLog and "AirBalloonShowSpot:_PickSequenceIndex locked balloon slot:" .. tostring(nSlotIndex))
  if nReadyPlayerNum and LevelSequencePathList and LevelSequencePathList[nReadyPlayerNum] then
    return nReadyPlayerNum
  end
  return 1
end

function AirBalloonShowSpot:_TryStartShow(uCharacter)
  if Client or self.nPlayShow and self.nPlayShow > 0 or self.bInCoolDown then
    return
  end
  local nMainPlayerKey = slua.isValid(uCharacter) and uCharacter.PlayerKey or nil
  AirBalloonShowSpot.__super._TryStartShow(self, uCharacter)
  if not self.nPlayShow or not (self.nPlayShow > 0) then
    return
  end
  if not self.CurrentShowBalloonSlotIndex then
    return
  end
  local nSlotIndex = self.CurrentShowBalloonSlotIndex
  local nPlayShowSnapshot = self.nPlayShow
  self:AddGameTimer(JoinTeleportDelaySeconds, false, function()
    if self.nPlayShow ~= nPlayShowSnapshot or self.CurrentShowBalloonSlotIndex ~= nSlotIndex then
      print(bWriteLog and "AirBalloonShowSpot:_TryStartShow delayed teleport skipped, show changed")
      return
    end
    self:_TeleportReadyListToBalloon(nSlotIndex, nMainPlayerKey)
  end)
end

function AirBalloonShowSpot:OnRewardPackBalloonExit(uPlayer)
  if Client or not slua.isValid(uPlayer) then
    return
  end
  local uGameState = GameplayData.GetGameState()
  if not slua.isValid(uGameState) then
    print(bWriteLog and string.format("AirBalloonShowSpot:OnRewardPackBalloonExit invalid gamestate PlayerKey=%s", tostring(uPlayer.PlayerKey)))
    return false
  end
  if uGameState.RoomType == "match" then
    print(bWriteLog and string.format("AirBalloonShowSpot:OnRewardPackBalloonExit skip reward in match room PlayerKey=%s", tostring(uPlayer.PlayerKey)))
    return false
  end
  print(bWriteLog and string.format("AirBalloonShowSpot:OnRewardPackBalloonExit trying to send reward to PlayerKey=%s", tostring(uPlayer.PlayerKey)))
  local PlayerKey = uPlayer.PlayerKey
  if not PlayerKey or PlayerKey <= 0 or self.RewardPackPlayerKeys[PlayerKey] then
    return false
  end
  if 0 >= RewardPackConfig.ItemID or 0 >= RewardPackConfig.SkillID or 0 >= RewardPackConfig.ItemCount then
    print(bWriteLog and "[PMGC2026][RewardPack] disabled: item/skill ID missing")
    return false
  end
  local Success = Game:AddItemByResID(uPlayer, RewardPackConfig.ItemID, RewardPackConfig.ItemCount)
  if Success then
    self.RewardPackPlayerKeys[PlayerKey] = true
  end
  print(bWriteLog and string.format("[PMGC2026][RewardPack] leave grant %s %s %s %s", tostring(PlayerKey), tostring(RewardPackConfig.ItemID), tostring(RewardPackConfig.ItemCount), tostring(Success)))
  return Success == true
end

function AirBalloonShowSpot:_TeleportReadyListToBalloon(nSlotIndex, nMainPlayerKey)
  local uBalloon = self.OwnedBalloons[nSlotIndex]
  if not slua.isValid(uBalloon) or not uBalloon.GetShowSpotTeleportPoints then
    print(bWriteLog and "AirBalloonShowSpot:_TeleportReadyListToBalloon invalid balloon at slot:" .. tostring(nSlotIndex))
    return
  end
  local TeleportPoints = uBalloon:GetShowSpotTeleportPoints()
  if #TeleportPoints <= 0 then
    print(bWriteLog and "AirBalloonShowSpot:_TeleportReadyListToBalloon balloon has no teleport points, slot:" .. tostring(nSlotIndex))
    return
  end
  self:_SetSlotVisible(nSlotIndex, true)
  self.SlotEmptySeconds = self.SlotEmptySeconds or {}
  self.SlotEmptySeconds[nSlotIndex] = 0
  local Config = self:_GetConfig()
  local nTeleportConfigId = Config and Config.TeleportConfigId
  if not nTeleportConfigId then
    print(bWriteLog and "AirBalloonShowSpot:_TeleportReadyListToBalloon TeleportConfigId not configured")
    return
  end
  local bTeleported = false
  local bMainPlayerTeleported = false
  local EPawnState = import("EPawnState")
  for nIndex = 0, self.ReadyPlayerList:Num() - 1 do
    local nPlayerKey = self.ReadyPlayerList:Get(nIndex)
    local uCharacter = nPlayerKey and Game:GetPlayerByPlayerKey(nPlayerKey)
    local uPoint = TeleportPoints[nIndex + 1]
    local bDead = not slua.isValid(uCharacter) or uCharacter:HasState(EPawnState.Dead) or uCharacter:HasState(EPawnState.Dying)
    if bDead then
      print(bWriteLog and "AirBalloonShowSpot:_TeleportReadyListToBalloon skip dead PlayerKey:" .. tostring(nPlayerKey))
    elseif slua.isValid(uCharacter) and slua.isValid(uPoint) and uCharacter.TeleportPawnFeature then
      print(bWriteLog and "AirBalloonShowSpot:_TeleportReadyListToBalloon BEFORE RemoteTeleport time:" .. tostring(os.clock()) .. " PlayerKey:" .. tostring(nPlayerKey) .. " nPlayShow:" .. tostring(self.nPlayShow))
      local bSuccess = uCharacter.TeleportPawnFeature:RemoteTeleport(uPoint:K2_GetComponentLocation(), uPoint:K2_GetComponentRotation(), nTeleportConfigId)
      local bPlayerTeleported = bSuccess == true
      bTeleported = bTeleported or bPlayerTeleported
      bMainPlayerTeleported = bMainPlayerTeleported or bPlayerTeleported and nPlayerKey == nMainPlayerKey
      print(bWriteLog and "AirBalloonShowSpot:_TeleportReadyListToBalloon AFTER RemoteTeleport time:" .. tostring(os.clock()) .. " PlayerKey:" .. tostring(nPlayerKey) .. " nPlayShow:" .. tostring(self.nPlayShow) .. " point:" .. tostring(nIndex + 1) .. " success:" .. tostring(bSuccess))
    else
      print(bWriteLog and "AirBalloonShowSpot:_TeleportReadyListToBalloon skip PlayerKey:" .. tostring(nPlayerKey) .. " (invalid character/point, or no teleport point for index " .. tostring(nIndex + 1) .. ")")
    end
  end
  if bMainPlayerTeleported then
    local uMainCharacter = Game:GetPlayerByPlayerKey(nMainPlayerKey)
    if slua.isValid(uMainCharacter) and uBalloon.RequestAutoDriver then
      uBalloon:RequestAutoDriver(uMainCharacter)
      print(bWriteLog and "AirBalloonShowSpot:_TeleportReadyListToBalloon request auto driver PlayerKey:" .. tostring(nMainPlayerKey))
    else
      print(bWriteLog and "AirBalloonShowSpot:_TeleportReadyListToBalloon auto driver skipped PlayerKey:" .. tostring(nMainPlayerKey))
    end
  end
  if bTeleported and uBalloon.StartManagedFuelCountdown then
    uBalloon:StartManagedFuelCountdown()
  end
end

function AirBalloonShowSpot:_StartEmptyBalloonCheck()
  if self.EmptyBalloonCheckTimer then
    return
  end
  self.EmptyBalloonCheckTimer = self:AddGameTimer(1, true, function()
    self:_CheckBalloonsToHide()
  end)
end

function AirBalloonShowSpot:_SetSlotVisible(nSlotIndex, bVisible)
  local ENetDormancy = import("ENetDormancy")
  local uBalloon = self.OwnedBalloons[nSlotIndex]
  local Actors = uBalloon:GetParachuteStages()
  table.insert(Actors, uBalloon)
  for _, uActor in ipairs(Actors) do
    if slua.isValid(uActor) then
      if uActor.SetActorEnableCollision then
        uActor:SetActorEnableCollision(bVisible)
      end
      if bVisible then
        uActor:FlushNetDormancy()
        uActor:SetActorHiddenInGame(false)
      else
        uActor:SetActorHiddenInGame(true)
        uActor:SetNetDormancy(ENetDormancy.DORM_DormantAll)
      end
    end
  end
  print(bWriteLog and string.format("AirBalloonShowSpot:_SetSlotVisible slot=%s visible=%s balloon=%s", tostring(nSlotIndex), tostring(bVisible), tostring(uBalloon)))
end

function AirBalloonShowSpot:_CheckBalloonsToHide()
  if Client or not self.LockedBalloonSlotIndices then
    return
  end
  local Config = self:_GetConfig()
  local fDestroyDelaySeconds = Config and Config.UsedBalloonDestroyDelaySeconds or 5
  self.SlotEmptySeconds = self.SlotEmptySeconds or {}
  self.SlotEverOccupied = self.SlotEverOccupied or {}
  self.SlotRetired = self.SlotRetired or {}
  for nIndex = 1, #self.OwnedBalloons do
    local uBalloon = self.OwnedBalloons[nIndex]
    if slua.isValid(uBalloon) and Game:Contains(self.LockedBalloonSlotIndices, nIndex) and not self.SlotRetired[nIndex] then
      local CurrentPassengers = {}
      if uBalloon.Passengers then
        for nPassengerIndex = 0, uBalloon.Passengers:Num() - 1 do
          local uPassenger = uBalloon.Passengers:Get(nPassengerIndex)
          if slua.isValid(uPassenger) and uPassenger.PlayerKey then
            CurrentPassengers[uPassenger.PlayerKey] = true
          end
        end
      end
      local PreviousPassengers = self.ObservedBalloonPassengers[nIndex] or {}
      for PlayerKey in pairs(PreviousPassengers) do
        if not CurrentPassengers[PlayerKey] then
          local uPlayer = Game:GetPlayerByPlayerKey(PlayerKey)
          if slua.isValid(uPlayer) and Game:IsAlive(uPlayer) then
            self:OnRewardPackBalloonExit(uPlayer)
          end
        end
      end
      self.ObservedBalloonPassengers[nIndex] = CurrentPassengers
      local nPassengerNum = 0
      for _ in pairs(CurrentPassengers) do
        nPassengerNum = nPassengerNum + 1
      end
      if 0 < nPassengerNum then
        if not self.SlotEverOccupied[nIndex] then
          print(bWriteLog and "AirBalloonShowSpot:balloon occupied slot:" .. tostring(nIndex) .. " passengers:" .. tostring(nPassengerNum))
        end
        self.SlotEverOccupied[nIndex] = true
        self.SlotEmptySeconds[nIndex] = 0
        if uBalloon.bHidden then
          self:_SetSlotVisible(nIndex, true)
          print(bWriteLog and "AirBalloonShowSpot:restore hidden occupied slot:" .. tostring(nIndex))
        end
      elseif self.nPlayShow and 0 < self.nPlayShow or self.bInCoolDown then
        self.SlotEmptySeconds[nIndex] = 0
        if uBalloon.bHidden then
          self:_SetSlotVisible(nIndex, true)
          print(bWriteLog and "AirBalloonShowSpot:restore hidden active slot:" .. tostring(nIndex))
        end
      elseif self.SlotEverOccupied[nIndex] then
        self.SlotEmptySeconds[nIndex] = (self.SlotEmptySeconds[nIndex] or 0) + 1
        if fDestroyDelaySeconds <= self.SlotEmptySeconds[nIndex] then
          self.SlotRetired[nIndex] = true
          uBalloon:K2_DestroyActor()
          print(bWriteLog and "AirBalloonShowSpot:destroy empty slot:" .. tostring(nIndex) .. " delay=" .. tostring(fDestroyDelaySeconds))
        end
      end
    end
  end
end

local class = require("class")
local CGeneralDummyCheckPointBase = require("GameLua.Mod.BRMod.Gameplay.Actor.GeneralDummyCheckPoint.GeneralDummyCheckPointBase")
local CAirBalloonShowSpot = class(CGeneralDummyCheckPointBase, nil, AirBalloonShowSpot)
return CAirBalloonShowSpot
