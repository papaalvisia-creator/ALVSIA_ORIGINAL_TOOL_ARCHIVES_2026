;({
  ServerRPC = {},
  ClientRPC = {},
  MulticastRPC = {},
  LuaEventContainer = {
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 128, 244, 20, 240, 223, 235, 90, 167, 23, 209, 165, 27, 138, 115, 143, 96, 216),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(72, 65, 165, 248, 4, 244, 234, 208, 72, 189, 18, 222, 147, 54, 157, 100, 137, 109, 254, 201, 246, 198, 152, 214, 87),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(72, 65, 165, 248, 4, 244, 234, 198, 77, 176, 46, 222, 183, 33, 189, 96, 139, 122, 201),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 152, 226, 2, 213, 224, 247, 76, 166, 63, 199, 178, 49, 151),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 136, 233, 15, 237, 238, 240, 87, 145, 24, 212, 179, 59, 140, 68, 139, 114, 207, 196, 228, 192),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 142, 249, 6, 246, 232, 230, 112, 177, 31, 198),
    ((function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 136, 233, 14, 236, 217, 230, 75, 189, 29, 222, 179))
  },
  ["ctor"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.SeatComponent = nil
      _ARG_0_.AvatarComponent = nil
      _ARG_0_.AdvanceAvatarComponent = nil
      _ARG_0_.BP_VehicleDIYComp = nil
      _ARG_0_.ClientUsedAvatarID = 0
      _ARG_0_.CommonComponent = nil
      _ARG_0_.SpringArm = nil
      _ARG_0_.LastOccupiers = {}
      _ARG_0_.AttachedCharacterLocation = {}
      _ARG_0_.AttachedCharacterBlock = {}
      _ARG_0_.OnMeshPhysicsCreateDelegate = _ENV(81, 74, 128, 244, 20, 240, 223, 235, 90, 167, 23, 209, 165, 27, 138, 115, 143, 96, 216)
      _ARG_0_.bCanVehicleExit = true
      _ARG_0_.VehicleRegisterSkills = {}
      _ARG_0_.VehicleProtectionInternalTimer = nil
      _ARG_0_.OriginalCheckStuckInterval = 1
      _ARG_0_.OriginalStuckDuration = 5
      _ARG_0_.UseTimer = nil
      _ARG_0_.DrivingDistance = 0
      _ARG_0_.RecordCharacter = nil
      _ARG_0_.bIsBornIslandVehicle = false
      _ARG_0_.bUGCSkillAirDrop = false
      _ARG_0_.WeddingCarIndex = 0
      _ARG_0_.PassengerEnterShowTextID = nil
      _ARG_0_.PassengerEnterShowIconPath = nil
      _ARG_0_.DriverEnterShowTextID = nil
      _ARG_0_.DriverEnterShowIconPath = nil
      _ARG_0_.LeaveVehicleTextID = nil
      _ARG_0_.LeaveVehicleIconPath = nil
      _ARG_0_.VehicleHPBarName = _ENV()
      _ARG_0_.bUGCInstance = false
      _ARG_0_.UGCInstanceId = 0
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PostConstruct"] = function(_ARG_0_)
    do
      __super._PostConstruct(_ARG_0_)
      _ARG_0_:InitConfig()
      if U1.Client then
        _ARG_0_:AddCommonEvent(U1.EVENTTYPE_INGAME_NORMAL, U1.EVENTID_SEQUENCE_MSG, _ARG_0_.HandleForbidEnterVehicle, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 142, 253, 14, 253, 225, 247, 102, 186, 10, 215, 164, 14, 157, 126, 135, 119, 209, 196, 210, 222, 154, 221, 71), _ARG_0_.ClientHandleEnterVehicle, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 142, 253, 14, 253, 225, 247, 102, 172, 23, 198, 128, 61, 144, 127, 141, 120, 216, 228, 225, 205, 145, 199), _ARG_0_.ClientHandleExitVehicle, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 142, 253, 14, 253, 225, 247, 96, 188, 31, 220, 177, 61, 174, 115, 134, 125, 222, 205, 242, 251, 154, 210, 71, 129, 24, 199, 168, 60), _ARG_0_.ClientHandleChangeVehicleSeat, _ARG_0_)
      else
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 136, 255, 19, 253, 253, 213, 70, 188, 23, 209, 186, 61), _ARG_0_.ServerHandleEnterVehicleResult, _ARG_0_)
      end
      _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 155, 244, 15, 241, 236, 239, 70, 156, 27, 211, 186, 44, 144, 69, 154, 117, 201, 196, 212, 192, 158, 221, 84, 161, 10), _ARG_0_.LuaHandleHealthStateChanged, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 155, 244, 15, 241, 236, 239, 70, 156, 27, 211, 186, 44, 144, 82, 139, 103, 201, 211, 248, 209), _ARG_0_.LuaHandleVehicleHealthDestroy, _ARG_0_)
      if U1.slua.isValid((_ARG_0_:GetAvatarComponent())) then
        _ARG_0_.ClientUsedAvatarID = _ARG_0_:GetAvatarComponent():GetDefaultAvatarID()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PreDestruct"] = function(_ARG_0_)
    do
      if _ARG_0_.Features then
        goto lbl_37
        ::lbl_37::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.VehicleFeatures then
        goto lbl_56
        ::lbl_56::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _ARG_0_.VehicleFeatures = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLifetimeReplicatedProps"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 81, 139, 96, 241, 200, 241, 205, 139, 218, 94, 161, 60, 199, 182, 36, 129, 101, 159, 112, 200, 213, 215, 202, 128, 211),
        U1(109)
      }))
      do return {
        {
          U1(124, 113, 138, 210, 52, 243, 230, 239, 79, 149, 23, 192, 146, 42, 151, 102),
          import((U1(91, 104, 164, 247, 2, 236, 230, 238, 70, 151, 17, 220, 178, 49, 140, 127, 129, 122))).COND_None,
          UEnums.EPropertyClass.Bool
        },
        {
          U1(73, 65, 169, 245, 14, 246, 232, 192, 66, 166, 55, 220, 178, 61, 128),
          import((U1(91, 104, 164, 247, 2, 236, 230, 238, 70, 151, 17, 220, 178, 49, 140, 127, 129, 122))).COND_None,
          UEnums.EPropertyClass.Int
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_bUGCSkillAirDrop"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 202, 170, 244, 112, 151, 5, 203, 170, 36, 169, 111, 140, 64, 223, 222, 247, 148, 207, 236),
        U1(114, 64, 155, 240, 11, 237, 234)
      }) .. tostring(_ARG_1_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_WeddingCarIndex"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 255, 154, 215, 87, 173, 0, 197, 133, 41, 154, 79, 144, 96, 200, 201, 171, 152, 160, 207),
        U1(122, 114, 172, 253, 18, 253)
      }) .. tostring(_ARG_1_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientDriverChangeEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid(_ARG_2_) and _ARG_2_:IsLocallyControlled() and Game:IsValid(_ARG_0_:GetVehicleSpringArm()) and _ARG_0_:GetVehicleSpringArm().bForceInitCameraLagWhenDriverGetOn then
        _ARG_0_:GetVehicleSpringArm().bDoLocationLagInit = false
      end
      _ARG_0_.bBaseAutoMoveForward = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnPlayerCannotExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_0_.uLastCannotExitLocation ~= nil and FVector.Distance(_ARG_0_:K2_GetActorLocation(), _ARG_0_.uLastCannotExitLocation) < 100 then
        return
      end
      _ARG_0_.uLastCannotExitLocation = _ARG_0_:K2_GetActorLocation()
      if 100 < _ARG_0_:GetForwardSpeed() then
        return
      end
      do return end
      _ARG_0_ = _ENV[140]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitConfig"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 128, 125, 201, 226, 248, 198, 153, 218, 84), _ARG_0_.Object)
      if require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 168, 97, 197, 216, 228, 212, 138, 224),
        U1(113, 74, 171, 248, 0)
      }))).GenConfig(_ARG_0_.Object, _ARG_0_.VehicleShapeType) and next((require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 168, 97, 197, 216, 228, 212, 138, 224),
        U1(113, 74, 171, 248, 0)
      }))).GenConfig(_ARG_0_.Object, _ARG_0_.VehicleShapeType))) then
        goto lbl_106
        _ARG_0_[U1(113, 74, 171, 248, 0)] = U1(113, 74, 171, 248, 0)
        ::lbl_106::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleControlUIConfig"] = function(_ARG_0_)
    do
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUIConfig"] = function(_ARG_0_)
    do
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitComponents"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_23
      ::lbl_23::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitComponentAttributes"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_18
      ::lbl_18::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitVehicleFeatures"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_19
      ::lbl_19::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_76
      if slua.IsLuaModuleExists(table.unpack(_ARG_1_[226])) then
        if table.unpack(_ARG_1_[226]) and next(table.unpack(_ARG_1_[226])) then
          goto lbl_68
          require(table.unpack(_ARG_1_[226]))(_ARG_0_.Object)[nil] = nil
          ::lbl_68::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      ::lbl_76::
      _ARG_0_ = _ARG_0_
      _ARG_0_.VehicleFeatures, _ARG_0_ = {
        [226] = require(table.unpack(_ARG_1_[226]))(_ARG_0_.Object)
      }, _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitCustomConfigs"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      _ARG_0_.VehicleCustomConfigs = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearVehicleFeatures"] = function(_ARG_0_)
    do
      if _ARG_0_.VehicleFeatures and next(_ARG_0_.VehicleFeatures) then
        goto lbl_20
        ::lbl_20::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _ARG_0_.VehicleFeatures = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CallFunction"] = function(_ARG_0_, _ARG_1_, _ARG_2_, ...)
    do
      if _ARG_0_[_ARG_1_] then
        if slua.isValid(_ARG_0_[_ARG_1_]) and _ARG_0_[_ARG_1_][_ARG_2_] then
          return _ARG_0_[_ARG_1_][_ARG_2_](_ARG_0_[_ARG_1_], ...)
        end
      else
        _ARG_0_.FunctionCache = _ARG_0_.FunctionCache or {}
        if _ARG_0_.FunctionCache then
          _ARG_0_.FunctionCache[_ARG_1_] = _ARG_0_.FunctionCache[_ARG_1_] or {}
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ExecuteFunctions"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.FunctionCache or not _ARG_0_.FunctionCache[_ARG_1_] then
        return
      end
      goto lbl_23
      ::lbl_23::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveBeginPlay"] = function(_ARG_0_)
    do
      __super.ReceiveBeginPlay(_ARG_0_)
      _ARG_0_:InitOptimizeLeaveVehicle()
      if U1.SubsystemMgr:Get((U2(72, 65, 165, 248, 4, 244, 234, 208, 86, 182, 13, 203, 165, 44, 157, 123))) then
      end
      if U1.Client then
        if U1.slua.isValid((_ARG_0_:GetAdvanceAvatarComponent())) then
        end
      else
        _ARG_0_.bSkipComparePropertiesForReplay = true
        if _ARG_0_:GetProtectionComponent() and U1.slua.isValid((_ARG_0_:GetProtectionComponent())) then
          _ARG_0_.OriginalCheckStuckInterval = _ARG_0_:GetProtectionComponent().CheckStuckInterval
          _ARG_0_.OriginalStuckDuration = _ARG_0_:GetProtectionComponent().StuckDuration
        end
        if U1.slua.isValid(_ARG_0_.VehicleMovement) and _ARG_0_.VehicleMovement.DriftSetup then
          _ARG_0_.VehicleMovement.DriftSetup.MaxOmega = 360
        end
        if U1.slua.isValid((_ARG_0_:GetVehicleSync())) then
          _ARG_0_:GetVehicleSync().VehicleHitRewindThreshold.ValidDeltaSeconds = 0.35
        end
      end
      _ARG_0_.DefaultStartLocation = _ARG_0_:K2_GetActorLocation()
      _ARG_0_.DefaultStartRotation = _ARG_0_:K2_GetActorRotation()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AfterBeginPlay"] = function(_ARG_0_)
    do
      if _ARG_0_.Super.AfterBeginPlay then
        _ARG_0_.Super:AfterBeginPlay()
      end
      if slua.isValid(_ARG_0_.VehicleShootAntiCheat) then
        _ARG_0_.VehicleShootAntiCheat.BoundBoxExtendMoveTime = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetShootVertifyHitBoxScale"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return FVector(2, 2, 2) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerHandleEnterVehicleResult"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_2_ == U1.ESeatType_DriversSeat and slua.isValid(_ARG_0_:GetVehicleSpringArm()) then
        _ARG_0_:GetVehicleSpringArm().bDoCollisionTest = true
      end
      _ARG_1_.ClientSidePoseState = import((U2(91, 119, 153, 212, 55, 247, 252, 230, 112, 160, 31, 198, 179))).Stand
      if slua.isValid((_ARG_1_:GetThirdPersonSpringArm())) then
        _ARG_1_:GetThirdPersonSpringArm().bDoCollisionTest = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      _ARG_1_.ClientSidePoseState = import((U1(91, 119, 153, 212, 55, 247, 252, 230, 112, 160, 31, 198, 179))).Stand
      if Game:IsBioVehicle(_ARG_0_.Object) then
        if slua.isValid(_ARG_0_.CapsuleComponent) and _ARG_0_.CapsuleComponent:ComponentHasTag((U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157))) then
          _ARG_0_ = _ARG_0_
          if _ARG_0_.CapsuleComponent.ComponentTags:Get(81) == U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157) then
          else
            _ARG_0_ = _ARG_0_
          end
          if 81 >= 0 then
          end
        end
        if slua.isValid(_ARG_0_.HeadCapsuleComponent) and _ARG_0_.HeadCapsuleComponent:ComponentHasTag((U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157))) then
          _ARG_0_ = _ARG_0_
          if _ARG_0_.HeadCapsuleComponent.ComponentTags:Get(81) == U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157) then
          else
            _ARG_0_ = _ARG_0_
          end
          if 81 >= 0 then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleChangeVehicleSeat"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEndChangeVehicleItemAvatar"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 81, 211, 197, 212, 192, 158, 221, 84, 161, 56, 199, 174, 33, 139, 106, 155, 77, 217, 212, 234, 249, 153, 194),
        U1(106, 69, 191)
      }))
      _ARG_0_:CheckAvatarDormant()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAvatarDormant"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SpawnBoxComponent"] = function(_ARG_0_)
    do
      if not _ARG_0_:HasAuthority() then
        return
      end
      if import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))) == nil then
        return
      end
      if not Game:IsValid((Game:AddComponent(import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))), _ARG_0_, (U1(90, 65, 172, 245, 49, 253, 231, 234, 64, 184, 27, 240, 185, 32))))) then
        return
      end
      if not Game:AddComponent(import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))), _ARG_0_, (U1(90, 65, 172, 245, 49, 253, 231, 234, 64, 184, 27, 240, 185, 32))):K2_AttachToComponent(_ARG_0_.Mesh, U1(80, 75, 163, 244), import((U1(91, 101, 185, 229, 6, 251, 231, 238, 70, 186, 10, 224, 163, 52, 157))).KeepRelative, import((U1(91, 101, 185, 229, 6, 251, 231, 238, 70, 186, 10, 224, 163, 52, 157))).KeepRelative, import((U1(91, 101, 185, 229, 6, 251, 231, 238, 70, 186, 10, 224, 163, 52, 157))).KeepRelative, false) then
        return
      end
      Game:AddComponent(import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))), _ARG_0_, (U1(90, 65, 172, 245, 49, 253, 231, 234, 64, 184, 27, 240, 185, 32))).bGenerateOverlapEvents = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BPGetQueryIgnoreActors"] = function(_ARG_0_)
    do
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenPhysicForAMoment"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:HasAuthority() then
        return
      end
      if _ARG_0_:IsSimulatePhysics() then
        return
      end
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 158, 113, 211, 241, 255, 209, 140, 218, 80, 130, 1, 208, 135, 5, 135, 107, 155, 106, 217), _ARG_0_.Role)
      _ARG_0_:SetSimulatePhysics(true)
      if _ARG_0_.PhysicTimer ~= nil then
        Game:ClearTimer(_ARG_0_.PhysicTimer)
        _ARG_0_.PhysicTimer = nil
      end
      _ARG_0_.PhysicTimer = Game:SetTimer(_ARG_1_, false, function()
        _ENV:SetSimulatePhysics(false)
        U1.Game:ClearTimer(PhysicTimer)
        PhysicTimer = nil
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveEndPlay"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.PhysicTimer ~= nil then
        Game:ClearTimer(_ARG_0_.PhysicTimer)
        _ARG_0_.PhysicTimer = nil
      end
      _ARG_0_.bIsDeformed = false
      _ARG_0_.VehicleRegisterSkills = {}
      EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_ENDPLAY, _ARG_0_.Object)
      _ARG_0_:ClearVehicleFeatures()
      if _ARG_0_.LuaBroadcast then
        _ARG_0_:LuaBroadcast((U1(72, 65, 165, 248, 4, 244, 234, 198, 77, 176, 46, 222, 183, 33, 189, 96, 139, 122, 201)))
      end
      _ARG_0_.Super:ReceiveEndPlay(_ARG_1_)
      U2.__super.ReceiveEndPlay(_ARG_0_, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMoveComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.MoveComponent) then
        _ARG_0_.MoveComponent = _ARG_0_:GetComponentByClass((import((U1(77, 112, 136, 233, 19, 234, 238, 213, 70, 188, 23, 209, 186, 61, 181, 121, 152, 113, 208, 196, 249, 220, 188, 220, 94, 180, 1, 204, 163, 38, 156, 50, 169)))))
      end
      do return _ARG_0_.MoveComponent end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCommonComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.CommonComponent) then
        _ARG_0_.CommonComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 192, 76, 185, 19, 221, 184, 27, 151, 123, 158, 123, 211, 196, 249, 220)))))
      end
      do return _ARG_0_.CommonComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSeatComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.SeatComponent) and slua.isValid(_ARG_0_.Object) then
        _ARG_0_.SeatComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 208, 70, 181, 10, 241, 185, 53, 136, 121, 128, 113, 211, 213)))))
      end
      do return _ARG_0_.SeatComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAvatarComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.AvatarComponent) then
        _ARG_0_.AvatarComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 194, 85, 181, 10, 211, 164, 27, 151, 123, 158, 123, 211, 196, 249, 220)))))
      end
      do return _ARG_0_.AvatarComponent end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAdvanceAvatarComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.AdvanceAvatarComponent) then
        _ARG_0_.AdvanceAvatarComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 194, 71, 162, 31, 220, 181, 61, 185, 96, 143, 96, 220, 211, 212, 199, 146, 195, 92, 170, 11, 204, 178)))))
      end
      do return _ARG_0_.AdvanceAvatarComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetProtectionComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.ProtectionComponent) then
        _ARG_0_.ProtectionComponent = _ARG_0_:GetComponentByClass((import((U1(73, 76, 168, 244, 11, 253, 235, 213, 70, 188, 23, 209, 186, 61, 168, 100, 129, 96, 216, 194, 227, 193, 144, 221, 112, 171, 3, 210, 169, 38, 141, 104, 138)))))
      end
      do return _ARG_0_.ProtectionComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMotorbikeComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.MotorbikeComponent) then
        _ARG_0_.MotorbikeComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 206, 76, 160, 17, 192, 180, 49, 147, 115, 173, 123, 208, 209, 248, 198, 154, 221, 71)))))
      end
      do return _ARG_0_.MotorbikeComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMusicComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.MusicComponent) then
        _ARG_0_.MusicComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 206, 86, 167, 23, 209, 149, 55, 149, 102, 129, 122, 216, 207, 227)))))
      end
      do return _ARG_0_.MusicComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBuffComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.BuffSystemComp) then
        _ARG_0_.BuffSystemComp = _ARG_0_:GetComponentByClass((import((U1(77, 112, 143, 228, 1, 254, 220, 250, 80, 160, 27, 223, 149, 55, 149, 102, 129, 122, 216, 207, 227)))))
      end
      do return _ARG_0_.BuffSystemComp end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAccelerationComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.AccelerateComponent) then
        _ARG_0_.AccelerateComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 194, 64, 183, 27, 222, 179, 42, 153, 98, 139, 87, 210, 204, 231, 199, 145, 214, 93, 176)))))
      end
      do return _ARG_0_.AccelerateComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPickupComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehiclePickableComponent) then
        _ARG_0_.VehiclePickableComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 211, 74, 183, 21, 211, 180, 52, 157, 85, 129, 121, 205, 206, 249, 205, 145, 199)))))
      end
      do return _ARG_0_.VehiclePickableComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLicenseComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehicleLicenseComponent) then
        _ARG_0_.VehicleLicenseComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 207, 74, 183, 27, 220, 165, 61, 182, 99, 131, 118, 216, 211, 212, 199, 146, 195, 92, 170, 11, 204, 178)))))
      end
      do return _ARG_0_.VehicleLicenseComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleCabrioletComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehicleCabrioletComponent) then
        _ARG_0_.VehicleCabrioletComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 192, 66, 182, 12, 219, 185, 52, 157, 98, 173, 123, 208, 209, 248, 198, 154, 221, 71)))))
      end
      do return _ARG_0_.VehicleCabrioletComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddDynamicComponentLoadCompletedCallbacks"] = function(_ARG_0_, _ARG_1_, ...)
    do
      if _ARG_0_:DynamicComponentAllLoadCompleted() then
      elseif _ARG_0_.DynamicComponentLoadCompletedCallbacks == nil then
        _ARG_0_.DynamicComponentLoadCompletedCallbacks = {}
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ForceExitCharacters"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:HasAuthority() then
        if not slua.isValid((_ARG_0_:GetSeatComponent())) then
          return
        end
        goto lbl_128
        if slua.isValid(nil) then
          if _ARG_1_ == true then
            if slua.isValid(((nil):GetWeaponManager())) and (nil):GetWeaponManager():GetAllInventoryWeaponList(false) then
              goto lbl_126
              ::lbl_126::
              _ARG_0_ = _ARG_0_
              _ARG_0_ = _ARG_0_
            end
          end
        end
        ::lbl_128::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleDriverChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 236, 141, 218, 69, 161, 28, 225, 174, 41, 134, 97, 155, 96))
      _ARG_0_:ResetCandidateAvatarID(_ARG_2_)
      if CGameMode and not CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).Drived then
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).VehicleShapeType = _ARG_0_.VehicleShapeType
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).Drived = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatOccupiersChanged"] = function(_ARG_0_)
    do
      EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_SEAT_OCCUPIERS_CHANGED, _ARG_0_.Object)
      if slua.isValid((_ARG_0_:GetSeatComponent())) then
        if _ARG_0_.LastOccupiers and next(_ARG_0_.LastOccupiers) then
          goto lbl_36
          if slua.isValid(nil) then
          end
          ::lbl_36::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          goto lbl_71
          if slua.isValid(229) and not ({
            [nil] = true
          })[229] then
          end
          ::lbl_71::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if Client and not Client.IsEnableDSGrayPublishFlag(2199023255552) and not Client.IsEditor() and slua.isValid(_ARG_0_.Object) and not _ARG_0_.IsUnmannedVehicle and slua.isValid((_ARG_0_:GetSeatComponent())) then
          goto lbl_274
          if slua.isValid(229) and slua.isValid((229):GetCurrentVehicle()) and slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle()) then
          end
          ::lbl_274::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          goto lbl_461
          if slua.isValid(slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())) and not slua.isValid((slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetCurrentVehicle()) and slua.isValid(((slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetPlayerControllerSafety():GetVehicleUserComp())) and slua.isValid((slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle()) and slua.isValid((_ARG_0_:GetMesh())) and 229 >= 0 and 229 < _ARG_0_:GetSeatComponent().Seats:Num() then
            FVector(0, 0, 0).Z = (slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetSimpleCollisionHalfHeightInStandPose()
          end
          ::lbl_461::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if slua.isValid((_ARG_0_:GetSeatComponent())) then
          goto lbl_647
          ::lbl_647::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      _ARG_0_.LastOccupiers = {}
      goto lbl_663
      _ARG_0_.LastOccupiers[pairs(_ARG_0_:GetSeatComponent().SeatOccupiers)] = U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 210, 71, 139, 13, 193, 179, 56, 129, 99, 140, 119, 238, 217, 230, 214, 136, 198), slua.isValid((U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 210, 71, 139, 13, 193, 179, 56, 129, 99, 140, 119, 238, 217, 230, 214, 136, 198))) and _ARG_0_.LastOccupiers
      ::lbl_663::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetCandidateAvatarID"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(76, 65, 190, 244, 19, 219, 238, 237, 71, 189, 26, 211, 162, 61, 185, 96, 143, 96, 220, 211, 222, 236), _ARG_1_)
      if _ARG_0_:HasAuthority() and not slua.isValid(_ARG_1_) then
        _ARG_0_.CandidateAvatarID = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSeatAvailable"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid((_ARG_0_:GetSeatComponent())) then
        return _ARG_0_:GetSeatComponent():IsSeatIndexAvailable(_ARG_1_)
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayerEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 68, 209, 192, 238, 205, 141, 246, 93, 176, 11, 208, 144, 45, 128, 111, 157, 104, 200), _ARG_1_, _ARG_2_, _ARG_0_.bSkipComparePropertiesForReplay)
      if not Client then
        _ARG_0_.bSkipComparePropertiesForReplay = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayerExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 68, 209, 192, 238, 205, 141, 246, 75, 173, 26, 244, 163, 32, 129, 101, 146, 97), _ARG_1_, _ARG_2_, _ARG_3_, _ARG_0_.bSkipComparePropertiesForReplay)
      if not Client and _ARG_1_ then
        _ARG_0_.bSkipComparePropertiesForReplay = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleServerAvatarEquiped"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 193, 69, 161, 28, 227, 176, 41, 156, 103, 140, 65, 220, 196, 238, 200, 138, 199))
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleVehicleLoadedFPPMesh"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 64, 139, 124, 212, 194, 251, 205, 179, 220, 82, 160, 11, 198, 128, 24, 184, 75, 155, 119, 197))
      _ARG_0_:HandleClientAvatarEquiped()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientAvatarEquiped"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 147, 218, 86, 170, 26, 227, 176, 41, 156, 103, 140, 65, 220, 196, 238, 200, 138, 199))
      if slua.isValid((_ARG_0_:GetAvatarComponent())) then
        if _ARG_0_:GetAvatarComponent():GetCurrentAvatarID() == _ARG_0_.ClientUsedAvatarID then
          return
        end
        _ARG_0_.ClientUsedAvatarID = _ARG_0_:GetAvatarComponent():GetCurrentAvatarID()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientVehicleSwitchEffectEnd"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 147, 218, 86, 170, 26, 244, 163, 32, 129, 101, 146, 97, 254, 198, 238, 204, 140, 203),
        U1(91, 66, 171, 244, 4, 236, 202, 237, 71)
      }))
      _ARG_0_:InitVehicleDIYComponent(_ARG_0_.ClientUsedAvatarID)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientVehicleSlotEquiped"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      if _ARG_0_:GetAvatarComponent().NetHighTireStruct and _ARG_0_:GetAvatarComponent().NetHighTireStruct.bEnableHighTire ~= nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeactiveSkinSpecialEffect"] = function(_ARG_0_)
    do
      _ARG_0_:DeactiveEffect((_ENV(91, 92, 165, 240, 18, 235, 251)))
      _ARG_0_:DeactiveEffect((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222)))
      _ARG_0_:DeactiveEffect((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96)))
      _ARG_0_:DeactiveEffect((_ENV(77, 80, 172, 227, 19, 205, 255, 197, 123)))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleAdvanceAvatarEquipped"] = function(_ARG_0_)
    do
      if _ARG_0_:HasAuthority() then
        _ARG_0_:HandleServerAdvanceAvatarEquipped()
      else
        _ARG_0_:HandleClientAdvanceAvatarEquipped()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAndSetStartUpEffect"] = function(_ARG_0_, _ARG_1_)
    do
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleServerAdvanceAvatarEquipped"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 193, 69, 161, 28, 227, 162, 62, 137, 104, 157, 97, 236, 199, 230, 204, 142, 209),
        U1(91, 85, 184, 248, 23, 232, 234, 231)
      }))
      if not slua.isValid((_ARG_0_:GetAdvanceAvatarComponent())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientAdvanceAvatarEquipped"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetAdvanceAvatarComponent())) then
        return
      end
      if _ARG_0_:GetAdvanceAvatarComponent().VehicleSkinID == _ARG_0_.ClientUsedAvatarID then
        return
      end
      _ARG_0_.ClientUsedAvatarID = _ARG_0_:GetAdvanceAvatarComponent().VehicleSkinID
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleCabrioletStateChanged"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 158, 209, 65, 173, 1, 206, 163, 60, 187, 114, 159, 112, 200, 242, 239, 217, 129, 196),
          U1(123, 64, 237, 248, 9, 238, 238, 239, 74, 176, 94, 220, 179, 47, 187, 119, 140, 102, 212, 206, 251, 205, 139, 224, 71, 165, 26, 199)
        }))
        return
      end
      log(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 158, 209, 65, 173, 1, 206, 163, 60, 187, 114, 159, 112, 200, 242, 239, 217, 129, 196),
        U1(123, 64, 237, 255, 2, 239, 204, 226, 65, 166, 23, 221, 186, 61, 140, 69, 154, 117, 201, 196, 173)
      }) .. tostring(_ARG_1_))
      if Client then
        log(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 158, 209, 65, 173, 1, 206, 163, 60, 187, 114, 159, 112, 200, 242, 239, 217, 129, 196),
          U1(123, 64, 237, 210, 11, 241, 234, 237, 87)
        }))
        return
      end
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      goto lbl_340
      ::lbl_340::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleCabrioletState"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetVehicleCabrioletComponent())) then
        return nil
      end
      do return _ARG_0_:GetVehicleCabrioletComponent():GetCabrioletState() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeAssetByAvatar"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 134, 117, 211, 198, 242, 233, 140, 192, 86, 176, 44, 219, 135, 62, 137, 114, 159, 118, 129, 145, 233, 249, 153, 194),
        U1(106, 69, 191, 216, 35, 184, 178, 163)
      }), _ARG_1_)
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      if not slua.isValid((_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateParticle"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 67, 158, 112, 220, 213, 242, 248, 158, 193, 71, 173, 13, 206, 163, 104, 134, 71, 136, 101, 217, 208, 245, 241, 171) .. tostring(_ARG_1_))
      _ARG_0_:DeactiveSkinSpecialEffect()
      _ARG_0_:ChangeAssetBy(_ARG_1_)
      _ARG_0_:ReActivateExhaustParticle()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeParticles"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      _ARG_0_.RuntimeParticleSoftWrapperMap = _ARG_0_.ParticleSoftWrapperMap
      if slua.isValid((_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_))) and _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).ParticleSfx:Num() > 0 then
        goto lbl_109
        ::lbl_109::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.ReplaceParticleMap:Get(_ARG_1_) and 0 < _ARG_0_.ReplaceParticleMap:Get(_ARG_1_).ParticleSfx:Num() then
        goto lbl_138
        ::lbl_138::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.AdditionalParticleMap:Get(_ARG_1_) and 0 < _ARG_0_.AdditionalParticleMap:Get(_ARG_1_).ParticleSfx:Num() then
        goto lbl_167
        ::lbl_167::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ModifyEnterSocket"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 91, 129, 112, 212, 199, 238, 237, 145, 199, 86, 182, 61, 205, 165, 35, 141, 114), _ARG_1_)
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      if U2.GetTableData(U1(72, 65, 165, 248, 4, 244, 234, 194, 87, 160, 12, 240, 134, 12, 153, 116, 130, 113), _ARG_1_) and U2.GetTableData(U1(72, 65, 165, 248, 4, 244, 234, 194, 87, 160, 12, 240, 134, 12, 153, 116, 130, 113), _ARG_1_).EnterVehicleSocket_an:Num() > 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeCharacterAnim"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) or _ARG_1_.VehCharAnimData:Num() == 0 then
        if slua.isValid((_ARG_0_:GetAvatarComponent())) and slua.isValid(_ARG_0_:GetAvatarComponent().DefaultItemAvatarHandle) and 0 < _ARG_0_:GetAvatarComponent().DefaultItemAvatarHandle.VehCharAnimData:Num() then
          _ARG_1_ = _ARG_0_:GetAvatarComponent().DefaultItemAvatarHandle
        else
          return
        end
      end
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 134, 117, 211, 198, 242, 235, 151, 210, 65, 165, 13, 214, 163, 58, 169, 104, 151, 105, 129, 145, 245, 221, 159, 207),
        U1(127, 71, 168, 177, 4, 240, 238, 241, 66, 183, 10, 215, 164, 120, 153, 120, 135, 121)
      }))
      goto lbl_261
      ::lbl_261::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeCharacterAnimNew"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == nil then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 134, 117, 211, 198, 242, 235, 151, 210, 65, 165, 13, 214, 163, 58, 169, 104, 151, 105, 227, 212, 240, 148, 207, 226),
          U1(104, 69, 185, 240, 21, 209, 203, 163, 74, 167, 94, 220, 191, 52)
        }))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaHandleHealthStateChanged"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaHandleVehicleHealthDestroy"] = function(_ARG_0_)
    do
      _ARG_0_:ClearDecals()
      if CGameMode then
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).VehicleShapeType = _ARG_0_.VehicleShapeType
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).IsDestroyed = true
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).LastAttackedTime = U1.GetTimeSeconds(_ARG_0_)
      end
      if slua.isValid(CGameState) and CGameState.GameModeSubType == import((U2(91, 99, 172, 252, 2, 213, 224, 231, 70, 135, 11, 208, 130, 33, 136, 115))).EPlanDGameMode then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_CandidateAvatar"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 235, 158, 221, 87, 173, 10, 195, 178, 45, 169, 112, 159, 112, 204, 195))
      EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_AVATAR_CHANGE_MSG, _ARG_0_.Object, _ARG_0_.CandidateAvatarID ~= 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:HandleOnSeatChanged(_ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
      if _ARG_1_ and slua.isValid(_ARG_1_) and _ARG_1_.getAvatarComponent2 and slua.isValid(_ARG_1_:getAvatarComponent2()) then
        _ARG_1_:getAvatarComponent2():DoAllAvatarReplaceOnVehicle()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnChangeSeat"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 87, 213, 192, 249, 207, 154, 224, 86, 165, 26), _ARG_1_, _ARG_4_, _ARG_2_, _ARG_3_)
      if _ARG_4_ == U2.ESeatType_DriversSeat then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 87, 213, 192, 249, 207, 154, 224, 86, 165, 26, 130, 165, 36, 141, 103, 140, 36, 219, 212, 239, 209, 140, 207),
          U1(123, 4, 164, 255, 23, 237, 251)
        }))
        _ARG_0_:ClearAllInputState()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 81, 197, 200, 227, 254, 154, 219, 90, 167, 2, 199), _ARG_1_, _ARG_2_)
      if _ARG_2_ == U2.ESeatType_DriversSeat then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 81, 197, 200, 227, 254, 154, 219, 90, 167, 2, 199, 230, 43, 132, 99, 159, 118, 141, 199, 226, 208, 134, 192),
          U1(114, 65, 237, 248, 9, 232, 250, 247)
        }))
        _ARG_0_:ClearAllInputState()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatAttached"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_1_) then
        if _ARG_1_.PlayerKey and slua.isValid(_ARG_1_.STCharacterMovement) and _ARG_1_.STCharacterMovement.ResolvePenetrationData then
          _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey] = _ARG_1_.STCharacterMovement.ResolvePenetrationData.ValidLocation
          _ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] = _ARG_0_:IsCharacterBlockFromValidLoc(_ARG_1_, _ARG_1_.STCharacterMovement.ResolvePenetrationData.ValidLocation)
        end
        EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_PLAYER_CHANGED, _ARG_0_.Object, _ARG_1_, true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCharacterBlockFromValidLoc"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) or _ARG_2_ == nil then
        return false
      end
      if slua.isValid((_ARG_0_:GetSeatComponent())) then
        goto lbl_100
        if slua.isValid(232) and 232 ~= _ARG_1_ then
        end
        ::lbl_100::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if U2.TraceBlock(_ARG_0_.Object, _ARG_2_, _ARG_1_:K2_GetActorLocation(), import((U1(49, 119, 174, 227, 14, 232, 251, 172, 102, 186, 25, 219, 184, 61, 214, 94, 135, 96, 239, 196, 228, 221, 147, 199)))(), slua.Array(UEnums.EPropertyClass.Object, (import((U1(49, 119, 174, 227, 14, 232, 251, 172, 102, 186, 25, 219, 184, 61, 214, 87, 141, 96, 210, 211))))), true).bBlockingHit then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnSeatDetachedBefore"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_1_) then
        _ARG_0_.DetachBeforeCharacterLocation = _ARG_1_:K2_GetActorLocation()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatDetached"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_1_) then
        EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_PLAYER_CHANGED, _ARG_0_.Object, _ARG_1_, false)
        if not _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey] then
          return
        end
        if _ARG_0_.DetachBeforeCharacterLocation == nil or _ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] == nil then
          return
        end
        if _ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] == true and FVector.Dist(_ARG_0_.DetachBeforeCharacterLocation, _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey]) < 800 then
        end
        if not (_ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] == true and FVector.Dist(_ARG_0_.DetachBeforeCharacterLocation, _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey]) < 800) and _ARG_0_:IsCharacterBlockFromValidLoc(_ARG_1_, _ARG_0_.DetachBeforeCharacterLocation) then
        end
        if _ARG_0_:IsCharacterBlockFromValidLoc(_ARG_1_, _ARG_0_.DetachBeforeCharacterLocation) then
          if _ARG_1_:FindActorLocationSafetyWithParams(FVector(0, 0, 0), _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey], (import((table.concat({
            U1(49, 119, 174, 227, 14, 232, 251, 172, 112, 188, 31, 214, 185, 47, 172, 100, 143, 119, 214, 196, 229, 237, 135, 199, 65, 165, 64, 240, 163, 59, 135, 106, 136, 97, 253, 212, 233, 221, 155, 209),
            U1(127, 80, 164, 254, 9, 200, 238, 241, 66, 185, 13)
          })))())) then
          else
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleHPPreChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if CGameMode and slua.isValid((_ARG_0_:GetCommonComponent())) and _ARG_2_ == _ARG_0_:GetCommonComponent():GetVehicleHPMax() then
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).VehicleShapeType = _ARG_0_.VehicleShapeType
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).FirstAttackedTime = U1.GetTimeSeconds(_ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleForbidEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if _ARG_4_ == _ENV(86, 77, 169, 244, 46, 246, 251, 230, 81, 181, 29, 198, 191, 46, 157, 67, 167) then
        _ARG_0_:ShowVehicleEnterButton(true)
        if U1.tonumber(_ARG_5_) == 1 then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerResetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_1_ == nil then
        _ARG_1_ = _ARG_0_.DefaultStartLocation
      end
      if _ARG_2_ == nil then
        _ARG_2_ = _ARG_0_.DefaultStartRotation
      end
      _ARG_0_:SetSimulatePhysics(false)
      if slua.isValid(_ARG_0_:GetProtectionComponent()) then
        _ARG_0_.ProtectionComponent:SetTickEnabled(false)
        _ARG_0_:AddTimer(0.1, function()
          ProtectionComponent:ResetValidTransform()
          ProtectionComponent:SetTickEnabled(true)
          return
        end)
      end
      if _ARG_3_ == true then
        _ARG_0_:ClientResetAdnSetToTransform(_ARG_1_, _ARG_2_)
        _ARG_0_:MulticastResetAdnSetToTransform(_ARG_1_, _ARG_2_)
      else
        _ARG_0_:ClientResetToTransform()
      end
      _ARG_0_:ServerResetToPosition(_ARG_1_, _ARG_2_, true)
      if slua.isValid(_ARG_0_.BallMovement) then
        _ARG_0_.BallMovement.CurrentRotationYaw = _ARG_2_.Yaw
        _ARG_0_.BallMovement.CameraRationYaw = _ARG_2_.Yaw
        _ARG_0_.BallMovement.STCameraRationYaw = _ARG_2_.Yaw
      end
      if slua.isValid(_ARG_0_:GetMotorbikeComponent()) then
        _ARG_0_:UnregisterComponentTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:UnregisterComponentWeakTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:AddTimer(0.1, function()
          _ENV:GetMesh():K2_GetComponentRotation().Roll = 0.0
          return
        end)
      end
      _ARG_0_:AddTimer(0.5, function()
        _ENV:SetSimulatePhysics(true)
        return
      end)
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 69, 139, 102, 203, 196, 229, 250, 154, 192, 86, 176, 58, 205, 146, 58, 137, 104, 141, 98, 194, 195, 234, 148, 207, 239),
        U1(113, 71, 172, 229, 14, 247, 225, 163, 30, 244)
      }) .. _ARG_1_:ToString() .. U1(50, 4, 159, 254, 19, 249, 251, 234, 76, 186, 94, 143, 246) .. _ARG_2_:ToString())
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerTeleportVehicleMaintainSpeed"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_:ServerResetToPosition(_ARG_1_, _ARG_2_, false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientTeleportVehicleMaintainSpeed"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientResetToTransform"] = function(_ARG_0_)
    do
      _ARG_0_:_ClientResetToTransform()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MulticastResetAdnSetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 91, 155, 120, 201, 200, 244, 201, 140, 199, 97, 161, 29, 199, 178, 9, 140, 104, 173, 97, 217, 229, 232, 236, 157, 194),
        U1(112, 87, 171, 254, 21, 245)
      }))
      if _ARG_2_ ~= nil and slua.isValid(_ARG_0_.BallMovement) then
        _ARG_0_.BallMovement.CurrentRotationYaw = _ARG_2_.Yaw
        _ARG_0_.BallMovement.CameraRationYaw = _ARG_2_.Yaw
        if _ARG_0_.BallMovement.ResetSimQuatFromRotator then
          _ARG_0_.BallMovement:ResetSimQuatFromRotator(_ARG_2_)
        end
        if _ARG_0_.DecorationCircle and slua.isValid(_ARG_0_.DecorationCircle.MeshComponent) then
          FRotator().Pitch = _ARG_0_.DecorationCircle.DefaultTransform:Rotator().Pitch + _ARG_2_.Pitch
          FRotator().Roll = _ARG_0_.DecorationCircle.DefaultTransform:Rotator().Roll + _ARG_2_.Roll
          FRotator().Yaw = _ARG_0_.DecorationCircle.DefaultTransform:Rotator().Yaw + _ARG_2_.Yaw
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientResetAdnSetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 130, 125, 216, 207, 227, 250, 154, 192, 86, 176, 47, 198, 168, 27, 141, 114, 170, 107, 249, 195, 230, 214, 156, 197),
        U1(113, 86, 160)
      }))
      _ARG_0_:_ClientResetToTransform(_ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClientResetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:StopVehicle()
      if slua.isValid(_ARG_0_:GetProtectionComponent()) then
        _ARG_0_.ProtectionComponent:SetTickEnabled(false)
        _ARG_0_:AddTimer(0.1, function()
          ProtectionComponent:ResetValidTransform()
          ProtectionComponent:SetTickEnabled(true)
          return
        end)
      end
      if _ARG_1_ ~= nil and _ARG_2_ ~= nil then
        _ARG_0_:K2_SetActorLocationAndRotation(_ARG_1_, _ARG_2_, false, nil, true)
      end
      if slua.isValid(_ARG_0_:GetMotorbikeComponent()) then
        _ARG_0_:UnregisterComponentTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:UnregisterComponentWeakTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:SetSimulatePhysics(false)
        _ARG_0_.bUseSyncAtClient = false
        _ARG_0_:AddTimer(0.1, function()
          _ENV:GetMesh():K2_GetComponentRotation().Roll = 0.0
          bUseSyncAtClient = true
          return
        end)
      end
      _ARG_0_:ResetVehicleSpringArm()
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 73, 173, 120, 212, 196, 249, 220, 173, 214, 64, 161, 26, 246, 169, 28, 154, 103, 144, 119, 203, 222, 245, 213, 195, 131),
        U1(82, 75, 174, 240, 19, 241, 224, 237, 3, 233, 94)
      }) .. _ARG_0_:K2_GetActorLocation():ToString() .. U1(50, 4, 159, 254, 19, 249, 251, 234, 76, 186, 94, 143, 246) .. _ARG_0_:K2_GetActorRotation():ToString())
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopVehicle"] = function(_ARG_0_)
    do
      if _ARG_0_:GetMoveComponent() then
      end
      if _ARG_0_.STReplicatedState then
        _ARG_0_.STReplicatedState.SteeringInput = 0
        _ARG_0_.STReplicatedState.ThrottleInput = 0
        _ARG_0_.STReplicatedState.BrakeInput = 127
        _ARG_0_.STReplicatedState.HandBrakeInput = 127
        _ARG_0_.STReplicatedState.CurrentGear = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetVehicleSpringArm"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetVehicleSpringArm())) then
        return
      end
      _ARG_0_:GetVehicleSpringArm().bUsePawnControlRotation = true
      _ARG_0_:GetVehicleSpringArm().SmartCamRotationExtra = FRotator(0, 0, 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerApplyVehicleImpulse"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 69, 139, 102, 203, 196, 229, 233, 143, 195, 95, 189, 56, 199, 174, 33, 139, 106, 155, 77, 192, 193, 242, 212, 156, 198),
        U1(50, 4, 132, 252, 23, 237, 227, 240, 70, 130, 27, 209, 162, 55, 138, 54, 211, 52)
      }) .. _ARG_1_:ToString())
      _ARG_0_:ApplyVehicleImpulse(_ARG_1_, true)
      _ARG_0_:ClientApplyVehicleImpulse(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientApplyVehicleImpulse"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 130, 125, 216, 207, 227, 233, 143, 195, 95, 189, 56, 199, 174, 33, 139, 106, 155, 77, 192, 193, 242, 212, 156, 198),
        U1(50, 4, 132, 252, 23, 237, 227, 240, 70, 130, 27, 209, 162, 55, 138, 54, 211, 52)
      }) .. _ARG_1_:ToString())
      _ARG_0_:ApplyVehicleImpulse(_ARG_1_, true)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecordVehicleTransfrom"] = function(_ARG_0_)
    do
      _ARG_0_.DefaultStartRotation = _ARG_0_:K2_GetActorRotation()
      _ARG_0_.DefaultStartLocation = _ARG_0_:K2_GetActorLocation()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreAttachBy"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not slua.isValid(_ARG_1_) or not slua.isValid(_ARG_2_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreAttachByCharacter"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not slua.isValid(_ARG_1_) or not slua.isValid(_ARG_2_) then
        return
      end
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      if _ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_) < 0 or _ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_) >= _ARG_0_:GetSeatComponent().Seats:Num() then
        return
      end
      if _ARG_3_ == _ARG_0_:GetSeatComponent().Seats:Get((_ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_))).VehicleWeaponSeatSocket then
        return
      end
      if _ARG_3_ ~= _ARG_0_:GetSeatComponent().Seats:Get((_ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_))).EnterVehicleSocket then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCurrentVehicleUseBetterAvatar"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_:GetAvatarComponent()) then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 157, 87, 200, 211, 229, 205, 145, 199, 101, 161, 6, 203, 165, 36, 141, 83, 141, 97, 239, 212, 243, 204, 138, 209),
          U1(95, 82, 172, 229, 6, 234, 175, 241, 70, 160, 11, 192, 184, 120, 158, 119, 130, 103, 216, 141, 183, 233, 137, 210, 71, 165, 28, 225, 169, 37, 152, 38, 151, 119, 141, 248, 233, 206, 142, 207),
          U1(119, 64)
        }))
        return false
      end
      if _ARG_0_.ClientUsedAvatarID and _ARG_0_.ClientUsedAvatarID ~= _ARG_0_:GetAvatarComponent():GetDefaultAvatarID() then
        if CDataTable.GetTableData(U1(92, 65, 185, 229, 2, 234, 217, 230, 75, 189, 29, 222, 179, 29, 158, 112, 139, 119, 201), _ARG_0_.ClientUsedAvatarID) then
          return true
        else
        end
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[192]
    end
  end,
  ["IsCurrentVehicleUseBetterAvataMusic"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return false
      end
      if not _ARG_1_ or _ARG_1_ == _ARG_0_:GetAvatarComponent():GetDefaultAvatarID() then
        return false
      end
      if not CDataTable.GetTableData(U1(92, 65, 185, 229, 2, 234, 217, 230, 75, 189, 29, 222, 179, 29, 158, 112, 139, 119, 201), _ARG_1_) or CDataTable.GetTableData(U1(92, 65, 185, 229, 2, 234, 217, 230, 75, 189, 29, 222, 179, 29, 158, 112, 139, 119, 201), _ARG_1_).VehicleMusic ~= 1 then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleMusicPlayState"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BPCanCharacterEnter"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid(_ARG_1_) and _ARG_1_.CanEnterVehicle then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 84, 190, 87, 220, 207, 212, 192, 158, 193, 82, 167, 26, 199, 180, 13, 134, 114, 155, 118, 141, 242, 230, 214, 170, 205),
          U1(106, 65, 191, 199, 2, 240, 230, 224, 79, 177)
        }))
        if not _ARG_1_:CanEnterVehicle(_ARG_0_) then
          print(bWriteLog and table.concat({
            U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 84, 190, 87, 220, 207, 212, 192, 158, 193, 82, 167, 26, 199, 180, 13, 134, 114, 155, 118, 141, 242, 230, 214, 170, 205),
            U1(106, 65, 191, 199, 2, 240, 230, 224, 79, 177, 94, 212, 183, 52, 139, 115)
          }))
          return false
        end
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsVaildToStopSkillWhenEnterVehicle"] = function(_ARG_0_, _ARG_1_)
    do
      if slua.isValid(_ARG_1_) and _ARG_1_:IsCastingSkillIDFix(1014711) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleCanExit"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.bCanVehicleExit = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShouldShowVehicleEnterUIToCharacher"] = function(_ARG_0_, _ARG_1_)
    do
      if slua.isValid(_ARG_1_) then
        if _ARG_1_.CanEnterVehicle and not _ARG_1_:CanEnterVehicle(_ARG_0_) then
          print(bWriteLog and table.concat({
            U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 69, 134, 123, 200, 205, 243, 251, 151, 220, 68, 146, 11, 202, 175, 43, 132, 99, 187, 106, 217, 212, 245, 237, 166, 247),
            U1(113, 103, 165, 240, 21, 249, 236, 235, 70, 166, 94, 241, 183, 54, 189, 120, 154, 113, 207, 247, 242, 192, 150, 208, 95, 161, 78, 196, 167, 36, 155, 99)
          }))
          return false
        end
        if slua.isValid(_ARG_1_) and slua.isValid((_ARG_0_:GetVehicleSeats())) then
          return _ARG_0_:GetVehicleSeats():IsSeatAvailableTeam(_ARG_1_)
        end
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDiedBoxAvatarID"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetDriver())) then
        return -1
      end
      do return (require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 98, 183, 10, 219, 160, 49, 140, 111, 192, 87, 210, 204, 250, 205, 141, 208, 90, 165, 2, 203, 188, 45, 198, 65, 159, 105, 200, 225, 235, 217, 150, 141),
        U1(72, 65, 165, 248, 4, 244, 234, 173, 117, 177, 22, 219, 181, 52, 157, 70, 130, 117, 201, 196, 219, 193, 156, 214, 93, 183, 11, 247, 178, 33, 132)
      }))).GetDiedBoxID(_ARG_0_:GetDriver().PlayerUID, (_ARG_0_:GetAvatarID()))) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDirverOrOwner"] = function(_ARG_0_)
    do
      if slua.isValid((_ARG_0_:GetDriver())) then
        return (_ARG_0_:GetDriver())
      end
      if _ARG_0_.Ownership and slua.isValid((Game:GetPlayerByPlayerKey(_ARG_0_.Ownership.BelongToPlayerKey))) then
        return (Game:GetPlayerByPlayerKey(_ARG_0_.Ownership.BelongToPlayerKey))
      end
      do return end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReActivateExhaustParticle"] = function(_ARG_0_)
    do
      if not _ARG_0_.bEnableUpdateExhuastEffectBP then
        _ARG_0_:LuaBroadcast((_ENV(81, 74, 136, 233, 15, 237, 238, 240, 87, 145, 24, 212, 179, 59, 140, 68, 139, 114, 207, 196, 228, 192)))
        return
      end
      if _ARG_0_.IsBoosting and not _ARG_0_:IsBoosting() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanActiveEffect"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == _ENV(91, 92, 165, 240, 18, 235, 251) and U1.Game:IsValid((_ARG_0_:GetAvatarComponent())) and _ARG_0_:GetAvatarComponent().VehicleAvatarHandle and _ARG_0_:GetAvatarComponent().VehicleAvatarHandle.bNeedHideExhaustWhenScope and U1.slua.isValid((U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter())) and U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter().IsLocalActuallyScopeIn then
        return false
      end
      if _ARG_1_ == _ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96) then
        if _ARG_0_.IsBoosting and not _ARG_0_:IsBoosting() then
          return false
        end
        if U1.slua.isValid(_ARG_0_.Mesh) and (not _ARG_0_.Mesh:GetAnimInstance() or not _ARG_0_.Mesh:GetAnimInstance().InLift) then
          return false
        end
      end
      do return true end
      do return end
      _ARG_1_ = _ENV[190]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnBoostingChanged"] = function(_ARG_0_)
    do
      _ARG_0_.Super:OnBoostingChanged()
      if _ARG_0_.IsBoosting and _ARG_0_:IsBoosting() then
        _ARG_0_:ActiveEffectAsync((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96)))
      else
        _ARG_0_:DeactiveEffect((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitOptimizeLeaveVehicle"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 128, 125, 201, 238, 231, 220, 150, 222, 90, 190, 11, 238, 163, 41, 158, 99, 168, 97, 197, 216, 228, 212, 138), _ARG_0_.Object)
      if not slua.isValid((_ARG_0_:GetSeatComponent())) or not _ARG_0_:GetSeatComponent().LeaveVehicleConfig then
        return
      end
      if require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 189, 107, 195, 215, 238, 223, 193, 239),
        U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)
      }))).GetConfig(_ARG_0_.VehicleShapeType) then
        goto lbl_200
        if slua.IndexReference(_ARG_0_:GetSeatComponent(), (U1(82, 65, 172, 231, 2, 206, 234, 235, 74, 183, 18, 215, 149, 55, 150, 112, 135, 115)))[U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)] ~= nil then
          slua.IndexReference(_ARG_0_:GetSeatComponent(), (U1(82, 65, 172, 231, 2, 206, 234, 235, 74, 183, 18, 215, 149, 55, 150, 112, 135, 115)))[U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)] = U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)
        end
        ::lbl_200::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegisterVehicleSkill"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.VehicleRegisterSkills[_ARG_1_] = _ARG_2_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurVehicleSkillBySkillID"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_.VehicleRegisterSkills[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleAccessorySlotConfig"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ or not _ARG_2_ then
        log(bWriteLog and table.concat({
          U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203),
          U1(119, 71, 161, 244, 38, 251, 236, 230, 80, 167, 17, 192, 175, 11, 148, 121, 154, 87, 210, 207, 241, 193, 152, 159, 19, 180, 15, 208, 167, 37, 200, 111, 141, 36, 195, 216, 235)
        }))
        return nil
      end
      log(bWriteLog and table.concat({
        U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203),
        U1(119, 71, 161, 244, 38, 251, 236, 230, 80, 167, 17, 192, 175, 11, 148, 121, 154, 87, 210, 207, 241, 193, 152, 159, 19, 170, 47, 212, 167, 60, 137, 116, 183, 64, 141, 140, 167)
      }) .. tostring(_ARG_1_) .. U1(62, 87, 161, 254, 19, 204, 246, 243, 70, 244, 67, 146) .. tostring(_ARG_2_))
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) or not _ARG_0_:GetAvatarComponent().GetItemAvatarHandle then
        return nil
      end
      if not slua.isValid((_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_))) then
        return nil
      end
      if not _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs or _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Num() == 0 then
        return nil
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203))) and _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203))).AccessorySlotName == _ARG_2_ then
        return (_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203))))
      end
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1[244]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHPBarShowName"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.VehicleHPBarName = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHPBarShowName"] = function(_ARG_0_)
    do
      if _ARG_0_.VehicleHPBarName and _ARG_0_.VehicleHPBarName ~= _ENV() then
        return _ARG_0_.VehicleHPBarName
      end
      _ARG_0_.VehicleHPBarName = U1.CDataTable.GetTableData(_ENV(87, 80, 168, 252), _ARG_0_.AvatarDefaultCfg.TypeSpecificID) and U1.CDataTable.GetTableData(_ENV(87, 80, 168, 252), _ARG_0_.AvatarDefaultCfg.TypeSpecificID).ItemName or _ENV()
      if U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))) and U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))).VehicleItemIDNameConfig and U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))).VehicleItemIDNameConfig[_ARG_0_.AvatarDefaultCfg.TypeSpecificID] then
        _ARG_0_.VehicleHPBarName = U1.LocUtil.GetLocalizeResStr(U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))).VehicleItemIDNameConfig[_ARG_0_.AvatarDefaultCfg.TypeSpecificID]) or _ARG_0_.VehicleHPBarName
      end
      do return _ARG_0_.VehicleHPBarName end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitVehicleDIYComponent"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 128, 125, 201, 247, 242, 192, 150, 208, 95, 161, 42, 235, 159, 11, 135, 107, 142, 107, 195, 212, 233, 204, 207, 205),
          U1(113, 80, 237, 199, 2, 240, 230, 224, 79, 177, 55, 246)
        }))
        return
      end
      if not CDataTable.GetTableData(U1(72, 65, 165, 248, 4, 244, 234, 199, 106, 141, 61, 212, 177), tonumber(_ARG_1_)) then
        if slua.isValid(_ARG_0_.BP_VehicleDIYComp) then
          _ARG_0_.BP_VehicleDIYComp = nil
        end
        return
      end
      if not slua.isValid(_ARG_0_.BP_VehicleDIYComp) then
        _ARG_0_.BP_VehicleDIYComp = Game:AddComponent(import((table.concat({
          U1(49, 99, 172, 252, 2, 183, 205, 239, 86, 177, 46, 192, 191, 54, 140, 101, 193, 85, 203, 192, 227, 201, 141, 247, 122, 157, 65, 224, 150, 23, 190, 99, 150, 109, 206, 221, 226, 252, 166, 250),
          U1(93, 75, 160, 225, 73, 218, 223, 220, 117, 177, 22, 219, 181, 52, 157, 82, 167, 77, 254, 206, 250, 216, 160, 240)
        }))), _ARG_0_, (U1(92, 116, 146, 199, 2, 240, 230, 224, 79, 177, 58, 251, 143, 27, 151, 123, 158)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartRecordDriveData"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      _ARG_0_.RecordCharacter = _ARG_1_
      if not _ARG_0_.UseTimer then
        _ARG_0_.DrivingDistance = 0
        _ARG_0_.LastLocation = _ARG_0_:K2_GetActorLocation()
        _ARG_0_.UseTimer = _ARG_0_:AddGameTimer(0.1, true, function()
          if slua.isValid(U1.Object) and U1.LastLocation then
            U1.DrivingDistance = U1.DrivingDistance + U2.VSize(U1:K2_GetActorLocation() - U1.LastLocation) / 100
            U1.LastLocation = U1:K2_GetActorLocation()
          end
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EndRecordDriveData"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_0_.DriverDistanceTLogID then
        return
      end
      if _ARG_0_.RecordCharacter ~= _ARG_1_ then
        return
      end
      _ARG_0_.RecordCharacter = nil
      _ARG_0_:RemoveGameTimer(_ARG_0_.UseTimer)
      _ARG_0_.UseTimer = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecordVehicleTlog"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_0_.EnterCountTlogID then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanBeCatched"] = function(_ARG_0_, _ARG_1_)
    do
      do return (_ARG_0_.UltraHandBeCatchedFeature:CanBeCatched(_ARG_1_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleProtectionStuckInternal"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.VehicleProtectionInternalTimer ~= nil and _ARG_0_.VehicleProtectionInternalTimer > 0 then
        _ARG_0_:RemoveGameTimer(_ARG_0_.VehicleProtectionInternalTimer)
      end
      if _ARG_0_:GetProtectionComponent() and slua.isValid((_ARG_0_:GetProtectionComponent())) then
        _ARG_0_:GetProtectionComponent().CheckStuckInterval = _ARG_1_
        _ARG_0_:GetProtectionComponent().StuckDuration = _ARG_2_
        _ARG_0_.VehicleProtectionInternalTimer = _ARG_0_:AddGameTimer(_ARG_3_, false, function()
          if _ENV and U1.slua.isValid(_ENV) then
            CheckStuckInterval = U1.slua.isValid(_ENV)
            StuckDuration = U1.slua.isValid(_ENV)
          end
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshVehiclePassengersParticle"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 68, 139, 114, 207, 196, 228, 192, 169, 214, 91, 173, 13, 206, 163, 24, 137, 117, 141, 97, 195, 214, 226, 202, 156, 243),
        U1(127, 86, 185, 248, 4, 244, 234)
      }))
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      goto lbl_262
      ::lbl_262::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandlePlayerAttachedToVehcicle"] = function(_ARG_0_, _ARG_1_)
    do
      if Client and slua.isValid(_ARG_1_) and _ARG_1_.CheckAttachedOrDetachedVehicle then
        _ARG_1_:CheckAttachedOrDetachedVehicle(true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_BlockForwardInput"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 234, 147, 220, 80, 175, 40, 205, 180, 63, 137, 116, 154, 77, 195, 193, 242, 204))
      if _ARG_0_.Super.OnRep_BlockForwardInput then
        _ARG_0_.Super:OnRep_BlockForwardInput()
      end
      if slua.isValid((require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter())) and require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter().GetCurrentVehicle and slua.isValid(require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter():GetCurrentVehicle()) and require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter():GetCurrentVehicle() == _ARG_0_.Object then
        if Game:IsClassOf(_ARG_0_.Object, import((U1(92, 77, 162, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61)))) or Game:IsClassOf(_ARG_0_.Object, import((U1(72, 65, 165, 248, 4, 244, 234, 193, 74, 191, 27)))) or Game:IsClassOf(_ARG_0_.Object, import((U1(72, 65, 165, 248, 4, 244, 234, 206, 76, 160, 17, 192, 145, 52, 145, 114, 139, 102)))) then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMeshPhysicsCreateExt"] = function(_ARG_0_)
    do
      _ARG_0_:LuaBroadcast(_ARG_0_.OnMeshPhysicsCreateDelegate)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FellOutOfWorldExt"] = function(_ARG_0_, _ARG_1_)
    do
      if Client and Client.IsDevelopment() and not (slua.isValid((import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance())) and import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance():IsPlayingAnyPlayback()) and slua.isValid(CGameState) and CGameState:GetGameModeState() ~= U1(88, 77, 163, 248, 20, 240, 234, 231, 112, 160, 31, 198, 179) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OutsideWorldBoundsExt"] = function(_ARG_0_, _ARG_1_)
    do
      if Client and Client.IsDevelopment() and not (slua.isValid((import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance())) and import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance():IsPlayingAnyPlayback()) and slua.isValid(CGameState) and CGameState:GetGameModeState() ~= U1(88, 77, 163, 248, 20, 240, 234, 231, 112, 160, 31, 198, 179) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["NeedCreateShootDriverComp"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 189, 107, 195, 215, 238, 223, 193, 245),
        U1(123, 76, 164, 242, 11, 253, 220, 235, 76, 187, 10, 246, 164, 49, 142, 115, 156, 87, 210, 207, 241, 193, 152)
      }))) and require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 189, 107, 195, 215, 238, 223, 193, 245),
        U1(123, 76, 164, 242, 11, 253, 220, 235, 76, 187, 10, 246, 164, 49, 142, 115, 156, 87, 210, 207, 241, 193, 152)
      }))).GetCfg(_ARG_0_.Object) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSocialIslandVehicle"] = function(_ARG_0_)
    do
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaShouldLeaveFitCloseToGround"] = function(_ARG_0_)
    do
      if _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_UH60 or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_HeavyUH60 or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_Motorglider or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_WingMan or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_Fighter or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_Aircraft then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBornIslandVehicle"] = function(_ARG_0_)
    do
      do return _ARG_0_.bIsBornIslandVehicle end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}).ClientRPC.ClientTeleportVehicleMaintainSpeed = {
  Reliable = true,
  Params = {
    import(((function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(49, 119, 174, 227, 14, 232, 251, 172, 96, 187, 12, 215, 131, 23, 154, 124, 139, 119, 201, 143, 193, 205, 156, 199, 92, 182))),
    import(((function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(49, 119, 174, 227, 14, 232, 251, 172, 96, 187, 12, 215, 131, 23, 154, 124, 139, 119, 201, 143, 197, 199, 139, 210, 71, 171, 28))),
    import(((function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(49, 119, 174, 227, 14, 232, 251, 172, 96, 187, 12, 215, 131, 23, 154, 124, 139, 119, 201, 143, 193, 205, 156, 199, 92, 182)))
  }
}
;({
  ServerRPC = {},
  ClientRPC = {},
  MulticastRPC = {},
  LuaEventContainer = {
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 128, 244, 20, 240, 223, 235, 90, 167, 23, 209, 165, 27, 138, 115, 143, 96, 216),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(72, 65, 165, 248, 4, 244, 234, 208, 72, 189, 18, 222, 147, 54, 157, 100, 137, 109, 254, 201, 246, 198, 152, 214, 87),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(72, 65, 165, 248, 4, 244, 234, 198, 77, 176, 46, 222, 183, 33, 189, 96, 139, 122, 201),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 152, 226, 2, 213, 224, 247, 76, 166, 63, 199, 178, 49, 151),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 136, 233, 15, 237, 238, 240, 87, 145, 24, 212, 179, 59, 140, 68, 139, 114, 207, 196, 228, 192),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 142, 249, 6, 246, 232, 230, 112, 177, 31, 198),
    ((function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 136, 233, 14, 236, 217, 230, 75, 189, 29, 222, 179))
  },
  ["ctor"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.SeatComponent = nil
      _ARG_0_.AvatarComponent = nil
      _ARG_0_.AdvanceAvatarComponent = nil
      _ARG_0_.BP_VehicleDIYComp = nil
      _ARG_0_.ClientUsedAvatarID = 0
      _ARG_0_.CommonComponent = nil
      _ARG_0_.SpringArm = nil
      _ARG_0_.LastOccupiers = {}
      _ARG_0_.AttachedCharacterLocation = {}
      _ARG_0_.AttachedCharacterBlock = {}
      _ARG_0_.OnMeshPhysicsCreateDelegate = _ENV(81, 74, 128, 244, 20, 240, 223, 235, 90, 167, 23, 209, 165, 27, 138, 115, 143, 96, 216)
      _ARG_0_.bCanVehicleExit = true
      _ARG_0_.VehicleRegisterSkills = {}
      _ARG_0_.VehicleProtectionInternalTimer = nil
      _ARG_0_.OriginalCheckStuckInterval = 1
      _ARG_0_.OriginalStuckDuration = 5
      _ARG_0_.UseTimer = nil
      _ARG_0_.DrivingDistance = 0
      _ARG_0_.RecordCharacter = nil
      _ARG_0_.bIsBornIslandVehicle = false
      _ARG_0_.bUGCSkillAirDrop = false
      _ARG_0_.WeddingCarIndex = 0
      _ARG_0_.PassengerEnterShowTextID = nil
      _ARG_0_.PassengerEnterShowIconPath = nil
      _ARG_0_.DriverEnterShowTextID = nil
      _ARG_0_.DriverEnterShowIconPath = nil
      _ARG_0_.LeaveVehicleTextID = nil
      _ARG_0_.LeaveVehicleIconPath = nil
      _ARG_0_.VehicleHPBarName = _ENV()
      _ARG_0_.bUGCInstance = false
      _ARG_0_.UGCInstanceId = 0
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PostConstruct"] = function(_ARG_0_)
    do
      __super._PostConstruct(_ARG_0_)
      _ARG_0_:InitConfig()
      if U1.Client then
        _ARG_0_:AddCommonEvent(U1.EVENTTYPE_INGAME_NORMAL, U1.EVENTID_SEQUENCE_MSG, _ARG_0_.HandleForbidEnterVehicle, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 142, 253, 14, 253, 225, 247, 102, 186, 10, 215, 164, 14, 157, 126, 135, 119, 209, 196, 210, 222, 154, 221, 71), _ARG_0_.ClientHandleEnterVehicle, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 142, 253, 14, 253, 225, 247, 102, 172, 23, 198, 128, 61, 144, 127, 141, 120, 216, 228, 225, 205, 145, 199), _ARG_0_.ClientHandleExitVehicle, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 142, 253, 14, 253, 225, 247, 96, 188, 31, 220, 177, 61, 174, 115, 134, 125, 222, 205, 242, 251, 154, 210, 71, 129, 24, 199, 168, 60), _ARG_0_.ClientHandleChangeVehicleSeat, _ARG_0_)
      else
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 136, 255, 19, 253, 253, 213, 70, 188, 23, 209, 186, 61), _ARG_0_.ServerHandleEnterVehicleResult, _ARG_0_)
      end
      _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 155, 244, 15, 241, 236, 239, 70, 156, 27, 211, 186, 44, 144, 69, 154, 117, 201, 196, 212, 192, 158, 221, 84, 161, 10), _ARG_0_.LuaHandleHealthStateChanged, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 155, 244, 15, 241, 236, 239, 70, 156, 27, 211, 186, 44, 144, 82, 139, 103, 201, 211, 248, 209), _ARG_0_.LuaHandleVehicleHealthDestroy, _ARG_0_)
      if U1.slua.isValid((_ARG_0_:GetAvatarComponent())) then
        _ARG_0_.ClientUsedAvatarID = _ARG_0_:GetAvatarComponent():GetDefaultAvatarID()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PreDestruct"] = function(_ARG_0_)
    do
      if _ARG_0_.Features then
        goto lbl_37
        ::lbl_37::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.VehicleFeatures then
        goto lbl_56
        ::lbl_56::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _ARG_0_.VehicleFeatures = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLifetimeReplicatedProps"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 81, 139, 96, 241, 200, 241, 205, 139, 218, 94, 161, 60, 199, 182, 36, 129, 101, 159, 112, 200, 213, 215, 202, 128, 211),
        U1(109)
      }))
      do return {
        {
          U1(124, 113, 138, 210, 52, 243, 230, 239, 79, 149, 23, 192, 146, 42, 151, 102),
          import((U1(91, 104, 164, 247, 2, 236, 230, 238, 70, 151, 17, 220, 178, 49, 140, 127, 129, 122))).COND_None,
          UEnums.EPropertyClass.Bool
        },
        {
          U1(73, 65, 169, 245, 14, 246, 232, 192, 66, 166, 55, 220, 178, 61, 128),
          import((U1(91, 104, 164, 247, 2, 236, 230, 238, 70, 151, 17, 220, 178, 49, 140, 127, 129, 122))).COND_None,
          UEnums.EPropertyClass.Int
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_bUGCSkillAirDrop"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 202, 170, 244, 112, 151, 5, 203, 170, 36, 169, 111, 140, 64, 223, 222, 247, 148, 207, 236),
        U1(114, 64, 155, 240, 11, 237, 234)
      }) .. tostring(_ARG_1_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_WeddingCarIndex"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 255, 154, 215, 87, 173, 0, 197, 133, 41, 154, 79, 144, 96, 200, 201, 171, 152, 160, 207),
        U1(122, 114, 172, 253, 18, 253)
      }) .. tostring(_ARG_1_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientDriverChangeEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid(_ARG_2_) and _ARG_2_:IsLocallyControlled() and Game:IsValid(_ARG_0_:GetVehicleSpringArm()) and _ARG_0_:GetVehicleSpringArm().bForceInitCameraLagWhenDriverGetOn then
        _ARG_0_:GetVehicleSpringArm().bDoLocationLagInit = false
      end
      _ARG_0_.bBaseAutoMoveForward = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnPlayerCannotExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_0_.uLastCannotExitLocation ~= nil and FVector.Distance(_ARG_0_:K2_GetActorLocation(), _ARG_0_.uLastCannotExitLocation) < 100 then
        return
      end
      _ARG_0_.uLastCannotExitLocation = _ARG_0_:K2_GetActorLocation()
      if 100 < _ARG_0_:GetForwardSpeed() then
        return
      end
      do return end
      _ARG_0_ = _ENV[140]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitConfig"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 128, 125, 201, 226, 248, 198, 153, 218, 84), _ARG_0_.Object)
      if require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 168, 97, 197, 216, 228, 212, 138, 224),
        U1(113, 74, 171, 248, 0)
      }))).GenConfig(_ARG_0_.Object, _ARG_0_.VehicleShapeType) and next((require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 168, 97, 197, 216, 228, 212, 138, 224),
        U1(113, 74, 171, 248, 0)
      }))).GenConfig(_ARG_0_.Object, _ARG_0_.VehicleShapeType))) then
        goto lbl_106
        _ARG_0_[U1(113, 74, 171, 248, 0)] = U1(113, 74, 171, 248, 0)
        ::lbl_106::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleControlUIConfig"] = function(_ARG_0_)
    do
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUIConfig"] = function(_ARG_0_)
    do
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitComponents"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_23
      ::lbl_23::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitComponentAttributes"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_18
      ::lbl_18::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitVehicleFeatures"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_19
      ::lbl_19::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_76
      if slua.IsLuaModuleExists(table.unpack(_ARG_1_[226])) then
        if table.unpack(_ARG_1_[226]) and next(table.unpack(_ARG_1_[226])) then
          goto lbl_68
          require(table.unpack(_ARG_1_[226]))(_ARG_0_.Object)[nil] = nil
          ::lbl_68::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      ::lbl_76::
      _ARG_0_ = _ARG_0_
      _ARG_0_.VehicleFeatures, _ARG_0_ = {
        [226] = require(table.unpack(_ARG_1_[226]))(_ARG_0_.Object)
      }, _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitCustomConfigs"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      _ARG_0_.VehicleCustomConfigs = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearVehicleFeatures"] = function(_ARG_0_)
    do
      if _ARG_0_.VehicleFeatures and next(_ARG_0_.VehicleFeatures) then
        goto lbl_20
        ::lbl_20::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _ARG_0_.VehicleFeatures = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CallFunction"] = function(_ARG_0_, _ARG_1_, _ARG_2_, ...)
    do
      if _ARG_0_[_ARG_1_] then
        if slua.isValid(_ARG_0_[_ARG_1_]) and _ARG_0_[_ARG_1_][_ARG_2_] then
          return _ARG_0_[_ARG_1_][_ARG_2_](_ARG_0_[_ARG_1_], ...)
        end
      else
        _ARG_0_.FunctionCache = _ARG_0_.FunctionCache or {}
        if _ARG_0_.FunctionCache then
          _ARG_0_.FunctionCache[_ARG_1_] = _ARG_0_.FunctionCache[_ARG_1_] or {}
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ExecuteFunctions"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.FunctionCache or not _ARG_0_.FunctionCache[_ARG_1_] then
        return
      end
      goto lbl_23
      ::lbl_23::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveBeginPlay"] = function(_ARG_0_)
    do
      __super.ReceiveBeginPlay(_ARG_0_)
      _ARG_0_:InitOptimizeLeaveVehicle()
      if U1.SubsystemMgr:Get((U2(72, 65, 165, 248, 4, 244, 234, 208, 86, 182, 13, 203, 165, 44, 157, 123))) then
      end
      if U1.Client then
        if U1.slua.isValid((_ARG_0_:GetAdvanceAvatarComponent())) then
        end
      else
        _ARG_0_.bSkipComparePropertiesForReplay = true
        if _ARG_0_:GetProtectionComponent() and U1.slua.isValid((_ARG_0_:GetProtectionComponent())) then
          _ARG_0_.OriginalCheckStuckInterval = _ARG_0_:GetProtectionComponent().CheckStuckInterval
          _ARG_0_.OriginalStuckDuration = _ARG_0_:GetProtectionComponent().StuckDuration
        end
        if U1.slua.isValid(_ARG_0_.VehicleMovement) and _ARG_0_.VehicleMovement.DriftSetup then
          _ARG_0_.VehicleMovement.DriftSetup.MaxOmega = 360
        end
        if U1.slua.isValid((_ARG_0_:GetVehicleSync())) then
          _ARG_0_:GetVehicleSync().VehicleHitRewindThreshold.ValidDeltaSeconds = 0.35
        end
      end
      _ARG_0_.DefaultStartLocation = _ARG_0_:K2_GetActorLocation()
      _ARG_0_.DefaultStartRotation = _ARG_0_:K2_GetActorRotation()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AfterBeginPlay"] = function(_ARG_0_)
    do
      if _ARG_0_.Super.AfterBeginPlay then
        _ARG_0_.Super:AfterBeginPlay()
      end
      if slua.isValid(_ARG_0_.VehicleShootAntiCheat) then
        _ARG_0_.VehicleShootAntiCheat.BoundBoxExtendMoveTime = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetShootVertifyHitBoxScale"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return FVector(2, 2, 2) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerHandleEnterVehicleResult"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_2_ == U1.ESeatType_DriversSeat and slua.isValid(_ARG_0_:GetVehicleSpringArm()) then
        _ARG_0_:GetVehicleSpringArm().bDoCollisionTest = true
      end
      _ARG_1_.ClientSidePoseState = import((U2(91, 119, 153, 212, 55, 247, 252, 230, 112, 160, 31, 198, 179))).Stand
      if slua.isValid((_ARG_1_:GetThirdPersonSpringArm())) then
        _ARG_1_:GetThirdPersonSpringArm().bDoCollisionTest = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      _ARG_1_.ClientSidePoseState = import((U1(91, 119, 153, 212, 55, 247, 252, 230, 112, 160, 31, 198, 179))).Stand
      if Game:IsBioVehicle(_ARG_0_.Object) then
        if slua.isValid(_ARG_0_.CapsuleComponent) and _ARG_0_.CapsuleComponent:ComponentHasTag((U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157))) then
          _ARG_0_ = _ARG_0_
          if _ARG_0_.CapsuleComponent.ComponentTags:Get(81) == U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157) then
          else
            _ARG_0_ = _ARG_0_
          end
          if 81 >= 0 then
          end
        end
        if slua.isValid(_ARG_0_.HeadCapsuleComponent) and _ARG_0_.HeadCapsuleComponent:ComponentHasTag((U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157))) then
          _ARG_0_ = _ARG_0_
          if _ARG_0_.HeadCapsuleComponent.ComponentTags:Get(81) == U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157) then
          else
            _ARG_0_ = _ARG_0_
          end
          if 81 >= 0 then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleChangeVehicleSeat"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEndChangeVehicleItemAvatar"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 81, 211, 197, 212, 192, 158, 221, 84, 161, 56, 199, 174, 33, 139, 106, 155, 77, 217, 212, 234, 249, 153, 194),
        U1(106, 69, 191)
      }))
      _ARG_0_:CheckAvatarDormant()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAvatarDormant"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SpawnBoxComponent"] = function(_ARG_0_)
    do
      if not _ARG_0_:HasAuthority() then
        return
      end
      if import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))) == nil then
        return
      end
      if not Game:IsValid((Game:AddComponent(import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))), _ARG_0_, (U1(90, 65, 172, 245, 49, 253, 231, 234, 64, 184, 27, 240, 185, 32))))) then
        return
      end
      if not Game:AddComponent(import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))), _ARG_0_, (U1(90, 65, 172, 245, 49, 253, 231, 234, 64, 184, 27, 240, 185, 32))):K2_AttachToComponent(_ARG_0_.Mesh, U1(80, 75, 163, 244), import((U1(91, 101, 185, 229, 6, 251, 231, 238, 70, 186, 10, 224, 163, 52, 157))).KeepRelative, import((U1(91, 101, 185, 229, 6, 251, 231, 238, 70, 186, 10, 224, 163, 52, 157))).KeepRelative, import((U1(91, 101, 185, 229, 6, 251, 231, 238, 70, 186, 10, 224, 163, 52, 157))).KeepRelative, false) then
        return
      end
      Game:AddComponent(import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))), _ARG_0_, (U1(90, 65, 172, 245, 49, 253, 231, 234, 64, 184, 27, 240, 185, 32))).bGenerateOverlapEvents = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BPGetQueryIgnoreActors"] = function(_ARG_0_)
    do
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenPhysicForAMoment"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:HasAuthority() then
        return
      end
      if _ARG_0_:IsSimulatePhysics() then
        return
      end
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 158, 113, 211, 241, 255, 209, 140, 218, 80, 130, 1, 208, 135, 5, 135, 107, 155, 106, 217), _ARG_0_.Role)
      _ARG_0_:SetSimulatePhysics(true)
      if _ARG_0_.PhysicTimer ~= nil then
        Game:ClearTimer(_ARG_0_.PhysicTimer)
        _ARG_0_.PhysicTimer = nil
      end
      _ARG_0_.PhysicTimer = Game:SetTimer(_ARG_1_, false, function()
        _ENV:SetSimulatePhysics(false)
        U1.Game:ClearTimer(PhysicTimer)
        PhysicTimer = nil
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveEndPlay"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.PhysicTimer ~= nil then
        Game:ClearTimer(_ARG_0_.PhysicTimer)
        _ARG_0_.PhysicTimer = nil
      end
      _ARG_0_.bIsDeformed = false
      _ARG_0_.VehicleRegisterSkills = {}
      EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_ENDPLAY, _ARG_0_.Object)
      _ARG_0_:ClearVehicleFeatures()
      if _ARG_0_.LuaBroadcast then
        _ARG_0_:LuaBroadcast((U1(72, 65, 165, 248, 4, 244, 234, 198, 77, 176, 46, 222, 183, 33, 189, 96, 139, 122, 201)))
      end
      _ARG_0_.Super:ReceiveEndPlay(_ARG_1_)
      U2.__super.ReceiveEndPlay(_ARG_0_, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMoveComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.MoveComponent) then
        _ARG_0_.MoveComponent = _ARG_0_:GetComponentByClass((import((U1(77, 112, 136, 233, 19, 234, 238, 213, 70, 188, 23, 209, 186, 61, 181, 121, 152, 113, 208, 196, 249, 220, 188, 220, 94, 180, 1, 204, 163, 38, 156, 50, 169)))))
      end
      do return _ARG_0_.MoveComponent end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCommonComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.CommonComponent) then
        _ARG_0_.CommonComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 192, 76, 185, 19, 221, 184, 27, 151, 123, 158, 123, 211, 196, 249, 220)))))
      end
      do return _ARG_0_.CommonComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSeatComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.SeatComponent) and slua.isValid(_ARG_0_.Object) then
        _ARG_0_.SeatComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 208, 70, 181, 10, 241, 185, 53, 136, 121, 128, 113, 211, 213)))))
      end
      do return _ARG_0_.SeatComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAvatarComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.AvatarComponent) then
        _ARG_0_.AvatarComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 194, 85, 181, 10, 211, 164, 27, 151, 123, 158, 123, 211, 196, 249, 220)))))
      end
      do return _ARG_0_.AvatarComponent end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAdvanceAvatarComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.AdvanceAvatarComponent) then
        _ARG_0_.AdvanceAvatarComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 194, 71, 162, 31, 220, 181, 61, 185, 96, 143, 96, 220, 211, 212, 199, 146, 195, 92, 170, 11, 204, 178)))))
      end
      do return _ARG_0_.AdvanceAvatarComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetProtectionComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.ProtectionComponent) then
        _ARG_0_.ProtectionComponent = _ARG_0_:GetComponentByClass((import((U1(73, 76, 168, 244, 11, 253, 235, 213, 70, 188, 23, 209, 186, 61, 168, 100, 129, 96, 216, 194, 227, 193, 144, 221, 112, 171, 3, 210, 169, 38, 141, 104, 138)))))
      end
      do return _ARG_0_.ProtectionComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMotorbikeComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.MotorbikeComponent) then
        _ARG_0_.MotorbikeComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 206, 76, 160, 17, 192, 180, 49, 147, 115, 173, 123, 208, 209, 248, 198, 154, 221, 71)))))
      end
      do return _ARG_0_.MotorbikeComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMusicComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.MusicComponent) then
        _ARG_0_.MusicComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 206, 86, 167, 23, 209, 149, 55, 149, 102, 129, 122, 216, 207, 227)))))
      end
      do return _ARG_0_.MusicComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBuffComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.BuffSystemComp) then
        _ARG_0_.BuffSystemComp = _ARG_0_:GetComponentByClass((import((U1(77, 112, 143, 228, 1, 254, 220, 250, 80, 160, 27, 223, 149, 55, 149, 102, 129, 122, 216, 207, 227)))))
      end
      do return _ARG_0_.BuffSystemComp end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAccelerationComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.AccelerateComponent) then
        _ARG_0_.AccelerateComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 194, 64, 183, 27, 222, 179, 42, 153, 98, 139, 87, 210, 204, 231, 199, 145, 214, 93, 176)))))
      end
      do return _ARG_0_.AccelerateComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPickupComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehiclePickableComponent) then
        _ARG_0_.VehiclePickableComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 211, 74, 183, 21, 211, 180, 52, 157, 85, 129, 121, 205, 206, 249, 205, 145, 199)))))
      end
      do return _ARG_0_.VehiclePickableComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLicenseComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehicleLicenseComponent) then
        _ARG_0_.VehicleLicenseComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 207, 74, 183, 27, 220, 165, 61, 182, 99, 131, 118, 216, 211, 212, 199, 146, 195, 92, 170, 11, 204, 178)))))
      end
      do return _ARG_0_.VehicleLicenseComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleCabrioletComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehicleCabrioletComponent) then
        _ARG_0_.VehicleCabrioletComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 192, 66, 182, 12, 219, 185, 52, 157, 98, 173, 123, 208, 209, 248, 198, 154, 221, 71)))))
      end
      do return _ARG_0_.VehicleCabrioletComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddDynamicComponentLoadCompletedCallbacks"] = function(_ARG_0_, _ARG_1_, ...)
    do
      if _ARG_0_:DynamicComponentAllLoadCompleted() then
      elseif _ARG_0_.DynamicComponentLoadCompletedCallbacks == nil then
        _ARG_0_.DynamicComponentLoadCompletedCallbacks = {}
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ForceExitCharacters"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:HasAuthority() then
        if not slua.isValid((_ARG_0_:GetSeatComponent())) then
          return
        end
        goto lbl_128
        if slua.isValid(nil) then
          if _ARG_1_ == true then
            if slua.isValid(((nil):GetWeaponManager())) and (nil):GetWeaponManager():GetAllInventoryWeaponList(false) then
              goto lbl_126
              ::lbl_126::
              _ARG_0_ = _ARG_0_
              _ARG_0_ = _ARG_0_
            end
          end
        end
        ::lbl_128::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleDriverChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 236, 141, 218, 69, 161, 28, 225, 174, 41, 134, 97, 155, 96))
      _ARG_0_:ResetCandidateAvatarID(_ARG_2_)
      if CGameMode and not CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).Drived then
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).VehicleShapeType = _ARG_0_.VehicleShapeType
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).Drived = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatOccupiersChanged"] = function(_ARG_0_)
    do
      EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_SEAT_OCCUPIERS_CHANGED, _ARG_0_.Object)
      if slua.isValid((_ARG_0_:GetSeatComponent())) then
        if _ARG_0_.LastOccupiers and next(_ARG_0_.LastOccupiers) then
          goto lbl_36
          if slua.isValid(nil) then
          end
          ::lbl_36::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          goto lbl_71
          if slua.isValid(229) and not ({
            [nil] = true
          })[229] then
          end
          ::lbl_71::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if Client and not Client.IsEnableDSGrayPublishFlag(2199023255552) and not Client.IsEditor() and slua.isValid(_ARG_0_.Object) and not _ARG_0_.IsUnmannedVehicle and slua.isValid((_ARG_0_:GetSeatComponent())) then
          goto lbl_274
          if slua.isValid(229) and slua.isValid((229):GetCurrentVehicle()) and slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle()) then
          end
          ::lbl_274::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          goto lbl_461
          if slua.isValid(slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())) and not slua.isValid((slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetCurrentVehicle()) and slua.isValid(((slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetPlayerControllerSafety():GetVehicleUserComp())) and slua.isValid((slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle()) and slua.isValid((_ARG_0_:GetMesh())) and 229 >= 0 and 229 < _ARG_0_:GetSeatComponent().Seats:Num() then
            FVector(0, 0, 0).Z = (slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetSimpleCollisionHalfHeightInStandPose()
          end
          ::lbl_461::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if slua.isValid((_ARG_0_:GetSeatComponent())) then
          goto lbl_647
          ::lbl_647::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      _ARG_0_.LastOccupiers = {}
      goto lbl_663
      _ARG_0_.LastOccupiers[pairs(_ARG_0_:GetSeatComponent().SeatOccupiers)] = U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 210, 71, 139, 13, 193, 179, 56, 129, 99, 140, 119, 238, 217, 230, 214, 136, 198), slua.isValid((U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 210, 71, 139, 13, 193, 179, 56, 129, 99, 140, 119, 238, 217, 230, 214, 136, 198))) and _ARG_0_.LastOccupiers
      ::lbl_663::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetCandidateAvatarID"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(76, 65, 190, 244, 19, 219, 238, 237, 71, 189, 26, 211, 162, 61, 185, 96, 143, 96, 220, 211, 222, 236), _ARG_1_)
      if _ARG_0_:HasAuthority() and not slua.isValid(_ARG_1_) then
        _ARG_0_.CandidateAvatarID = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSeatAvailable"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid((_ARG_0_:GetSeatComponent())) then
        return _ARG_0_:GetSeatComponent():IsSeatIndexAvailable(_ARG_1_)
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayerEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 68, 209, 192, 238, 205, 141, 246, 93, 176, 11, 208, 144, 45, 128, 111, 157, 104, 200), _ARG_1_, _ARG_2_, _ARG_0_.bSkipComparePropertiesForReplay)
      if not Client then
        _ARG_0_.bSkipComparePropertiesForReplay = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayerExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 68, 209, 192, 238, 205, 141, 246, 75, 173, 26, 244, 163, 32, 129, 101, 146, 97), _ARG_1_, _ARG_2_, _ARG_3_, _ARG_0_.bSkipComparePropertiesForReplay)
      if not Client and _ARG_1_ then
        _ARG_0_.bSkipComparePropertiesForReplay = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleServerAvatarEquiped"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 193, 69, 161, 28, 227, 176, 41, 156, 103, 140, 65, 220, 196, 238, 200, 138, 199))
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleVehicleLoadedFPPMesh"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 64, 139, 124, 212, 194, 251, 205, 179, 220, 82, 160, 11, 198, 128, 24, 184, 75, 155, 119, 197))
      _ARG_0_:HandleClientAvatarEquiped()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientAvatarEquiped"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 147, 218, 86, 170, 26, 227, 176, 41, 156, 103, 140, 65, 220, 196, 238, 200, 138, 199))
      if slua.isValid((_ARG_0_:GetAvatarComponent())) then
        if _ARG_0_:GetAvatarComponent():GetCurrentAvatarID() == _ARG_0_.ClientUsedAvatarID then
          return
        end
        _ARG_0_.ClientUsedAvatarID = _ARG_0_:GetAvatarComponent():GetCurrentAvatarID()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientVehicleSwitchEffectEnd"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 147, 218, 86, 170, 26, 244, 163, 32, 129, 101, 146, 97, 254, 198, 238, 204, 140, 203),
        U1(91, 66, 171, 244, 4, 236, 202, 237, 71)
      }))
      _ARG_0_:InitVehicleDIYComponent(_ARG_0_.ClientUsedAvatarID)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientVehicleSlotEquiped"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      if _ARG_0_:GetAvatarComponent().NetHighTireStruct and _ARG_0_:GetAvatarComponent().NetHighTireStruct.bEnableHighTire ~= nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeactiveSkinSpecialEffect"] = function(_ARG_0_)
    do
      _ARG_0_:DeactiveEffect((_ENV(91, 92, 165, 240, 18, 235, 251)))
      _ARG_0_:DeactiveEffect((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222)))
      _ARG_0_:DeactiveEffect((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96)))
      _ARG_0_:DeactiveEffect((_ENV(77, 80, 172, 227, 19, 205, 255, 197, 123)))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleAdvanceAvatarEquipped"] = function(_ARG_0_)
    do
      if _ARG_0_:HasAuthority() then
        _ARG_0_:HandleServerAdvanceAvatarEquipped()
      else
        _ARG_0_:HandleClientAdvanceAvatarEquipped()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAndSetStartUpEffect"] = function(_ARG_0_, _ARG_1_)
    do
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleServerAdvanceAvatarEquipped"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 193, 69, 161, 28, 227, 162, 62, 137, 104, 157, 97, 236, 199, 230, 204, 142, 209),
        U1(91, 85, 184, 248, 23, 232, 234, 231)
      }))
      if not slua.isValid((_ARG_0_:GetAdvanceAvatarComponent())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientAdvanceAvatarEquipped"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetAdvanceAvatarComponent())) then
        return
      end
      if _ARG_0_:GetAdvanceAvatarComponent().VehicleSkinID == _ARG_0_.ClientUsedAvatarID then
        return
      end
      _ARG_0_.ClientUsedAvatarID = _ARG_0_:GetAdvanceAvatarComponent().VehicleSkinID
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleCabrioletStateChanged"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 158, 209, 65, 173, 1, 206, 163, 60, 187, 114, 159, 112, 200, 242, 239, 217, 129, 196),
          U1(123, 64, 237, 248, 9, 238, 238, 239, 74, 176, 94, 220, 179, 47, 187, 119, 140, 102, 212, 206, 251, 205, 139, 224, 71, 165, 26, 199)
        }))
        return
      end
      log(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 158, 209, 65, 173, 1, 206, 163, 60, 187, 114, 159, 112, 200, 242, 239, 217, 129, 196),
        U1(123, 64, 237, 255, 2, 239, 204, 226, 65, 166, 23, 221, 186, 61, 140, 69, 154, 117, 201, 196, 173)
      }) .. tostring(_ARG_1_))
      if Client then
        log(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 158, 209, 65, 173, 1, 206, 163, 60, 187, 114, 159, 112, 200, 242, 239, 217, 129, 196),
          U1(123, 64, 237, 210, 11, 241, 234, 237, 87)
        }))
        return
      end
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      goto lbl_340
      ::lbl_340::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleCabrioletState"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetVehicleCabrioletComponent())) then
        return nil
      end
      do return _ARG_0_:GetVehicleCabrioletComponent():GetCabrioletState() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeAssetByAvatar"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 134, 117, 211, 198, 242, 233, 140, 192, 86, 176, 44, 219, 135, 62, 137, 114, 159, 118, 129, 145, 233, 249, 153, 194),
        U1(106, 69, 191, 216, 35, 184, 178, 163)
      }), _ARG_1_)
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      if not slua.isValid((_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateParticle"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 67, 158, 112, 220, 213, 242, 248, 158, 193, 71, 173, 13, 206, 163, 104, 134, 71, 136, 101, 217, 208, 245, 241, 171) .. tostring(_ARG_1_))
      _ARG_0_:DeactiveSkinSpecialEffect()
      _ARG_0_:ChangeAssetBy(_ARG_1_)
      _ARG_0_:ReActivateExhaustParticle()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeParticles"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      _ARG_0_.RuntimeParticleSoftWrapperMap = _ARG_0_.ParticleSoftWrapperMap
      if slua.isValid((_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_))) and _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).ParticleSfx:Num() > 0 then
        goto lbl_109
        ::lbl_109::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.ReplaceParticleMap:Get(_ARG_1_) and 0 < _ARG_0_.ReplaceParticleMap:Get(_ARG_1_).ParticleSfx:Num() then
        goto lbl_138
        ::lbl_138::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.AdditionalParticleMap:Get(_ARG_1_) and 0 < _ARG_0_.AdditionalParticleMap:Get(_ARG_1_).ParticleSfx:Num() then
        goto lbl_167
        ::lbl_167::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ModifyEnterSocket"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 91, 129, 112, 212, 199, 238, 237, 145, 199, 86, 182, 61, 205, 165, 35, 141, 114), _ARG_1_)
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      if U2.GetTableData(U1(72, 65, 165, 248, 4, 244, 234, 194, 87, 160, 12, 240, 134, 12, 153, 116, 130, 113), _ARG_1_) and U2.GetTableData(U1(72, 65, 165, 248, 4, 244, 234, 194, 87, 160, 12, 240, 134, 12, 153, 116, 130, 113), _ARG_1_).EnterVehicleSocket_an:Num() > 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeCharacterAnim"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) or _ARG_1_.VehCharAnimData:Num() == 0 then
        if slua.isValid((_ARG_0_:GetAvatarComponent())) and slua.isValid(_ARG_0_:GetAvatarComponent().DefaultItemAvatarHandle) and 0 < _ARG_0_:GetAvatarComponent().DefaultItemAvatarHandle.VehCharAnimData:Num() then
          _ARG_1_ = _ARG_0_:GetAvatarComponent().DefaultItemAvatarHandle
        else
          return
        end
      end
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 134, 117, 211, 198, 242, 235, 151, 210, 65, 165, 13, 214, 163, 58, 169, 104, 151, 105, 129, 145, 245, 221, 159, 207),
        U1(127, 71, 168, 177, 4, 240, 238, 241, 66, 183, 10, 215, 164, 120, 153, 120, 135, 121)
      }))
      goto lbl_261
      ::lbl_261::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeCharacterAnimNew"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == nil then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 134, 117, 211, 198, 242, 235, 151, 210, 65, 165, 13, 214, 163, 58, 169, 104, 151, 105, 227, 212, 240, 148, 207, 226),
          U1(104, 69, 185, 240, 21, 209, 203, 163, 74, 167, 94, 220, 191, 52)
        }))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaHandleHealthStateChanged"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaHandleVehicleHealthDestroy"] = function(_ARG_0_)
    do
      _ARG_0_:ClearDecals()
      if CGameMode then
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).VehicleShapeType = _ARG_0_.VehicleShapeType
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).IsDestroyed = true
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).LastAttackedTime = U1.GetTimeSeconds(_ARG_0_)
      end
      if slua.isValid(CGameState) and CGameState.GameModeSubType == import((U2(91, 99, 172, 252, 2, 213, 224, 231, 70, 135, 11, 208, 130, 33, 136, 115))).EPlanDGameMode then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_CandidateAvatar"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 235, 158, 221, 87, 173, 10, 195, 178, 45, 169, 112, 159, 112, 204, 195))
      EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_AVATAR_CHANGE_MSG, _ARG_0_.Object, _ARG_0_.CandidateAvatarID ~= 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:HandleOnSeatChanged(_ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
      if _ARG_1_ and slua.isValid(_ARG_1_) and _ARG_1_.getAvatarComponent2 and slua.isValid(_ARG_1_:getAvatarComponent2()) then
        _ARG_1_:getAvatarComponent2():DoAllAvatarReplaceOnVehicle()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnChangeSeat"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 87, 213, 192, 249, 207, 154, 224, 86, 165, 26), _ARG_1_, _ARG_4_, _ARG_2_, _ARG_3_)
      if _ARG_4_ == U2.ESeatType_DriversSeat then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 87, 213, 192, 249, 207, 154, 224, 86, 165, 26, 130, 165, 36, 141, 103, 140, 36, 219, 212, 239, 209, 140, 207),
          U1(123, 4, 164, 255, 23, 237, 251)
        }))
        _ARG_0_:ClearAllInputState()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 81, 197, 200, 227, 254, 154, 219, 90, 167, 2, 199), _ARG_1_, _ARG_2_)
      if _ARG_2_ == U2.ESeatType_DriversSeat then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 81, 197, 200, 227, 254, 154, 219, 90, 167, 2, 199, 230, 43, 132, 99, 159, 118, 141, 199, 226, 208, 134, 192),
          U1(114, 65, 237, 248, 9, 232, 250, 247)
        }))
        _ARG_0_:ClearAllInputState()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatAttached"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_1_) then
        if _ARG_1_.PlayerKey and slua.isValid(_ARG_1_.STCharacterMovement) and _ARG_1_.STCharacterMovement.ResolvePenetrationData then
          _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey] = _ARG_1_.STCharacterMovement.ResolvePenetrationData.ValidLocation
          _ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] = _ARG_0_:IsCharacterBlockFromValidLoc(_ARG_1_, _ARG_1_.STCharacterMovement.ResolvePenetrationData.ValidLocation)
        end
        EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_PLAYER_CHANGED, _ARG_0_.Object, _ARG_1_, true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCharacterBlockFromValidLoc"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) or _ARG_2_ == nil then
        return false
      end
      if slua.isValid((_ARG_0_:GetSeatComponent())) then
        goto lbl_100
        if slua.isValid(232) and 232 ~= _ARG_1_ then
        end
        ::lbl_100::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if U2.TraceBlock(_ARG_0_.Object, _ARG_2_, _ARG_1_:K2_GetActorLocation(), import((U1(49, 119, 174, 227, 14, 232, 251, 172, 102, 186, 25, 219, 184, 61, 214, 94, 135, 96, 239, 196, 228, 221, 147, 199)))(), slua.Array(UEnums.EPropertyClass.Object, (import((U1(49, 119, 174, 227, 14, 232, 251, 172, 102, 186, 25, 219, 184, 61, 214, 87, 141, 96, 210, 211))))), true).bBlockingHit then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnSeatDetachedBefore"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_1_) then
        _ARG_0_.DetachBeforeCharacterLocation = _ARG_1_:K2_GetActorLocation()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatDetached"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_1_) then
        EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_PLAYER_CHANGED, _ARG_0_.Object, _ARG_1_, false)
        if not _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey] then
          return
        end
        if _ARG_0_.DetachBeforeCharacterLocation == nil or _ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] == nil then
          return
        end
        if _ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] == true and FVector.Dist(_ARG_0_.DetachBeforeCharacterLocation, _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey]) < 800 then
        end
        if not (_ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] == true and FVector.Dist(_ARG_0_.DetachBeforeCharacterLocation, _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey]) < 800) and _ARG_0_:IsCharacterBlockFromValidLoc(_ARG_1_, _ARG_0_.DetachBeforeCharacterLocation) then
        end
        if _ARG_0_:IsCharacterBlockFromValidLoc(_ARG_1_, _ARG_0_.DetachBeforeCharacterLocation) then
          if _ARG_1_:FindActorLocationSafetyWithParams(FVector(0, 0, 0), _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey], (import((table.concat({
            U1(49, 119, 174, 227, 14, 232, 251, 172, 112, 188, 31, 214, 185, 47, 172, 100, 143, 119, 214, 196, 229, 237, 135, 199, 65, 165, 64, 240, 163, 59, 135, 106, 136, 97, 253, 212, 233, 221, 155, 209),
            U1(127, 80, 164, 254, 9, 200, 238, 241, 66, 185, 13)
          })))())) then
          else
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleHPPreChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if CGameMode and slua.isValid((_ARG_0_:GetCommonComponent())) and _ARG_2_ == _ARG_0_:GetCommonComponent():GetVehicleHPMax() then
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).VehicleShapeType = _ARG_0_.VehicleShapeType
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).FirstAttackedTime = U1.GetTimeSeconds(_ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleForbidEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if _ARG_4_ == _ENV(86, 77, 169, 244, 46, 246, 251, 230, 81, 181, 29, 198, 191, 46, 157, 67, 167) then
        _ARG_0_:ShowVehicleEnterButton(true)
        if U1.tonumber(_ARG_5_) == 1 then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerResetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_1_ == nil then
        _ARG_1_ = _ARG_0_.DefaultStartLocation
      end
      if _ARG_2_ == nil then
        _ARG_2_ = _ARG_0_.DefaultStartRotation
      end
      _ARG_0_:SetSimulatePhysics(false)
      if slua.isValid(_ARG_0_:GetProtectionComponent()) then
        _ARG_0_.ProtectionComponent:SetTickEnabled(false)
        _ARG_0_:AddTimer(0.1, function()
          ProtectionComponent:ResetValidTransform()
          ProtectionComponent:SetTickEnabled(true)
          return
        end)
      end
      if _ARG_3_ == true then
        _ARG_0_:ClientResetAdnSetToTransform(_ARG_1_, _ARG_2_)
        _ARG_0_:MulticastResetAdnSetToTransform(_ARG_1_, _ARG_2_)
      else
        _ARG_0_:ClientResetToTransform()
      end
      _ARG_0_:ServerResetToPosition(_ARG_1_, _ARG_2_, true)
      if slua.isValid(_ARG_0_.BallMovement) then
        _ARG_0_.BallMovement.CurrentRotationYaw = _ARG_2_.Yaw
        _ARG_0_.BallMovement.CameraRationYaw = _ARG_2_.Yaw
        _ARG_0_.BallMovement.STCameraRationYaw = _ARG_2_.Yaw
      end
      if slua.isValid(_ARG_0_:GetMotorbikeComponent()) then
        _ARG_0_:UnregisterComponentTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:UnregisterComponentWeakTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:AddTimer(0.1, function()
          _ENV:GetMesh():K2_GetComponentRotation().Roll = 0.0
          return
        end)
      end
      _ARG_0_:AddTimer(0.5, function()
        _ENV:SetSimulatePhysics(true)
        return
      end)
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 69, 139, 102, 203, 196, 229, 250, 154, 192, 86, 176, 58, 205, 146, 58, 137, 104, 141, 98, 194, 195, 234, 148, 207, 239),
        U1(113, 71, 172, 229, 14, 247, 225, 163, 30, 244)
      }) .. _ARG_1_:ToString() .. U1(50, 4, 159, 254, 19, 249, 251, 234, 76, 186, 94, 143, 246) .. _ARG_2_:ToString())
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerTeleportVehicleMaintainSpeed"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_:ServerResetToPosition(_ARG_1_, _ARG_2_, false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientTeleportVehicleMaintainSpeed"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientResetToTransform"] = function(_ARG_0_)
    do
      _ARG_0_:_ClientResetToTransform()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MulticastResetAdnSetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 91, 155, 120, 201, 200, 244, 201, 140, 199, 97, 161, 29, 199, 178, 9, 140, 104, 173, 97, 217, 229, 232, 236, 157, 194),
        U1(112, 87, 171, 254, 21, 245)
      }))
      if _ARG_2_ ~= nil and slua.isValid(_ARG_0_.BallMovement) then
        _ARG_0_.BallMovement.CurrentRotationYaw = _ARG_2_.Yaw
        _ARG_0_.BallMovement.CameraRationYaw = _ARG_2_.Yaw
        if _ARG_0_.BallMovement.ResetSimQuatFromRotator then
          _ARG_0_.BallMovement:ResetSimQuatFromRotator(_ARG_2_)
        end
        if _ARG_0_.DecorationCircle and slua.isValid(_ARG_0_.DecorationCircle.MeshComponent) then
          FRotator().Pitch = _ARG_0_.DecorationCircle.DefaultTransform:Rotator().Pitch + _ARG_2_.Pitch
          FRotator().Roll = _ARG_0_.DecorationCircle.DefaultTransform:Rotator().Roll + _ARG_2_.Roll
          FRotator().Yaw = _ARG_0_.DecorationCircle.DefaultTransform:Rotator().Yaw + _ARG_2_.Yaw
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientResetAdnSetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 130, 125, 216, 207, 227, 250, 154, 192, 86, 176, 47, 198, 168, 27, 141, 114, 170, 107, 249, 195, 230, 214, 156, 197),
        U1(113, 86, 160)
      }))
      _ARG_0_:_ClientResetToTransform(_ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClientResetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:StopVehicle()
      if slua.isValid(_ARG_0_:GetProtectionComponent()) then
        _ARG_0_.ProtectionComponent:SetTickEnabled(false)
        _ARG_0_:AddTimer(0.1, function()
          ProtectionComponent:ResetValidTransform()
          ProtectionComponent:SetTickEnabled(true)
          return
        end)
      end
      if _ARG_1_ ~= nil and _ARG_2_ ~= nil then
        _ARG_0_:K2_SetActorLocationAndRotation(_ARG_1_, _ARG_2_, false, nil, true)
      end
      if slua.isValid(_ARG_0_:GetMotorbikeComponent()) then
        _ARG_0_:UnregisterComponentTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:UnregisterComponentWeakTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:SetSimulatePhysics(false)
        _ARG_0_.bUseSyncAtClient = false
        _ARG_0_:AddTimer(0.1, function()
          _ENV:GetMesh():K2_GetComponentRotation().Roll = 0.0
          bUseSyncAtClient = true
          return
        end)
      end
      _ARG_0_:ResetVehicleSpringArm()
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 73, 173, 120, 212, 196, 249, 220, 173, 214, 64, 161, 26, 246, 169, 28, 154, 103, 144, 119, 203, 222, 245, 213, 195, 131),
        U1(82, 75, 174, 240, 19, 241, 224, 237, 3, 233, 94)
      }) .. _ARG_0_:K2_GetActorLocation():ToString() .. U1(50, 4, 159, 254, 19, 249, 251, 234, 76, 186, 94, 143, 246) .. _ARG_0_:K2_GetActorRotation():ToString())
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopVehicle"] = function(_ARG_0_)
    do
      if _ARG_0_:GetMoveComponent() then
      end
      if _ARG_0_.STReplicatedState then
        _ARG_0_.STReplicatedState.SteeringInput = 0
        _ARG_0_.STReplicatedState.ThrottleInput = 0
        _ARG_0_.STReplicatedState.BrakeInput = 127
        _ARG_0_.STReplicatedState.HandBrakeInput = 127
        _ARG_0_.STReplicatedState.CurrentGear = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetVehicleSpringArm"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetVehicleSpringArm())) then
        return
      end
      _ARG_0_:GetVehicleSpringArm().bUsePawnControlRotation = true
      _ARG_0_:GetVehicleSpringArm().SmartCamRotationExtra = FRotator(0, 0, 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerApplyVehicleImpulse"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 69, 139, 102, 203, 196, 229, 233, 143, 195, 95, 189, 56, 199, 174, 33, 139, 106, 155, 77, 192, 193, 242, 212, 156, 198),
        U1(50, 4, 132, 252, 23, 237, 227, 240, 70, 130, 27, 209, 162, 55, 138, 54, 211, 52)
      }) .. _ARG_1_:ToString())
      _ARG_0_:ApplyVehicleImpulse(_ARG_1_, true)
      _ARG_0_:ClientApplyVehicleImpulse(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientApplyVehicleImpulse"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 130, 125, 216, 207, 227, 233, 143, 195, 95, 189, 56, 199, 174, 33, 139, 106, 155, 77, 192, 193, 242, 212, 156, 198),
        U1(50, 4, 132, 252, 23, 237, 227, 240, 70, 130, 27, 209, 162, 55, 138, 54, 211, 52)
      }) .. _ARG_1_:ToString())
      _ARG_0_:ApplyVehicleImpulse(_ARG_1_, true)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecordVehicleTransfrom"] = function(_ARG_0_)
    do
      _ARG_0_.DefaultStartRotation = _ARG_0_:K2_GetActorRotation()
      _ARG_0_.DefaultStartLocation = _ARG_0_:K2_GetActorLocation()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreAttachBy"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not slua.isValid(_ARG_1_) or not slua.isValid(_ARG_2_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreAttachByCharacter"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not slua.isValid(_ARG_1_) or not slua.isValid(_ARG_2_) then
        return
      end
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      if _ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_) < 0 or _ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_) >= _ARG_0_:GetSeatComponent().Seats:Num() then
        return
      end
      if _ARG_3_ == _ARG_0_:GetSeatComponent().Seats:Get((_ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_))).VehicleWeaponSeatSocket then
        return
      end
      if _ARG_3_ ~= _ARG_0_:GetSeatComponent().Seats:Get((_ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_))).EnterVehicleSocket then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCurrentVehicleUseBetterAvatar"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_:GetAvatarComponent()) then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 157, 87, 200, 211, 229, 205, 145, 199, 101, 161, 6, 203, 165, 36, 141, 83, 141, 97, 239, 212, 243, 204, 138, 209),
          U1(95, 82, 172, 229, 6, 234, 175, 241, 70, 160, 11, 192, 184, 120, 158, 119, 130, 103, 216, 141, 183, 233, 137, 210, 71, 165, 28, 225, 169, 37, 152, 38, 151, 119, 141, 248, 233, 206, 142, 207),
          U1(119, 64)
        }))
        return false
      end
      if _ARG_0_.ClientUsedAvatarID and _ARG_0_.ClientUsedAvatarID ~= _ARG_0_:GetAvatarComponent():GetDefaultAvatarID() then
        if CDataTable.GetTableData(U1(92, 65, 185, 229, 2, 234, 217, 230, 75, 189, 29, 222, 179, 29, 158, 112, 139, 119, 201), _ARG_0_.ClientUsedAvatarID) then
          return true
        else
        end
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[192]
    end
  end,
  ["IsCurrentVehicleUseBetterAvataMusic"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return false
      end
      if not _ARG_1_ or _ARG_1_ == _ARG_0_:GetAvatarComponent():GetDefaultAvatarID() then
        return false
      end
      if not CDataTable.GetTableData(U1(92, 65, 185, 229, 2, 234, 217, 230, 75, 189, 29, 222, 179, 29, 158, 112, 139, 119, 201), _ARG_1_) or CDataTable.GetTableData(U1(92, 65, 185, 229, 2, 234, 217, 230, 75, 189, 29, 222, 179, 29, 158, 112, 139, 119, 201), _ARG_1_).VehicleMusic ~= 1 then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleMusicPlayState"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BPCanCharacterEnter"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid(_ARG_1_) and _ARG_1_.CanEnterVehicle then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 84, 190, 87, 220, 207, 212, 192, 158, 193, 82, 167, 26, 199, 180, 13, 134, 114, 155, 118, 141, 242, 230, 214, 170, 205),
          U1(106, 65, 191, 199, 2, 240, 230, 224, 79, 177)
        }))
        if not _ARG_1_:CanEnterVehicle(_ARG_0_) then
          print(bWriteLog and table.concat({
            U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 84, 190, 87, 220, 207, 212, 192, 158, 193, 82, 167, 26, 199, 180, 13, 134, 114, 155, 118, 141, 242, 230, 214, 170, 205),
            U1(106, 65, 191, 199, 2, 240, 230, 224, 79, 177, 94, 212, 183, 52, 139, 115)
          }))
          return false
        end
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsVaildToStopSkillWhenEnterVehicle"] = function(_ARG_0_, _ARG_1_)
    do
      if slua.isValid(_ARG_1_) and _ARG_1_:IsCastingSkillIDFix(1014711) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleCanExit"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.bCanVehicleExit = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShouldShowVehicleEnterUIToCharacher"] = function(_ARG_0_, _ARG_1_)
    do
      if slua.isValid(_ARG_1_) then
        if _ARG_1_.CanEnterVehicle and not _ARG_1_:CanEnterVehicle(_ARG_0_) then
          print(bWriteLog and table.concat({
            U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 69, 134, 123, 200, 205, 243, 251, 151, 220, 68, 146, 11, 202, 175, 43, 132, 99, 187, 106, 217, 212, 245, 237, 166, 247),
            U1(113, 103, 165, 240, 21, 249, 236, 235, 70, 166, 94, 241, 183, 54, 189, 120, 154, 113, 207, 247, 242, 192, 150, 208, 95, 161, 78, 196, 167, 36, 155, 99)
          }))
          return false
        end
        if slua.isValid(_ARG_1_) and slua.isValid((_ARG_0_:GetVehicleSeats())) then
          return _ARG_0_:GetVehicleSeats():IsSeatAvailableTeam(_ARG_1_)
        end
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDiedBoxAvatarID"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetDriver())) then
        return -1
      end
      do return (require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 98, 183, 10, 219, 160, 49, 140, 111, 192, 87, 210, 204, 250, 205, 141, 208, 90, 165, 2, 203, 188, 45, 198, 65, 159, 105, 200, 225, 235, 217, 150, 141),
        U1(72, 65, 165, 248, 4, 244, 234, 173, 117, 177, 22, 219, 181, 52, 157, 70, 130, 117, 201, 196, 219, 193, 156, 214, 93, 183, 11, 247, 178, 33, 132)
      }))).GetDiedBoxID(_ARG_0_:GetDriver().PlayerUID, (_ARG_0_:GetAvatarID()))) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDirverOrOwner"] = function(_ARG_0_)
    do
      if slua.isValid((_ARG_0_:GetDriver())) then
        return (_ARG_0_:GetDriver())
      end
      if _ARG_0_.Ownership and slua.isValid((Game:GetPlayerByPlayerKey(_ARG_0_.Ownership.BelongToPlayerKey))) then
        return (Game:GetPlayerByPlayerKey(_ARG_0_.Ownership.BelongToPlayerKey))
      end
      do return end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReActivateExhaustParticle"] = function(_ARG_0_)
    do
      if not _ARG_0_.bEnableUpdateExhuastEffectBP then
        _ARG_0_:LuaBroadcast((_ENV(81, 74, 136, 233, 15, 237, 238, 240, 87, 145, 24, 212, 179, 59, 140, 68, 139, 114, 207, 196, 228, 192)))
        return
      end
      if _ARG_0_.IsBoosting and not _ARG_0_:IsBoosting() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanActiveEffect"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == _ENV(91, 92, 165, 240, 18, 235, 251) and U1.Game:IsValid((_ARG_0_:GetAvatarComponent())) and _ARG_0_:GetAvatarComponent().VehicleAvatarHandle and _ARG_0_:GetAvatarComponent().VehicleAvatarHandle.bNeedHideExhaustWhenScope and U1.slua.isValid((U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter())) and U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter().IsLocalActuallyScopeIn then
        return false
      end
      if _ARG_1_ == _ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96) then
        if _ARG_0_.IsBoosting and not _ARG_0_:IsBoosting() then
          return false
        end
        if U1.slua.isValid(_ARG_0_.Mesh) and (not _ARG_0_.Mesh:GetAnimInstance() or not _ARG_0_.Mesh:GetAnimInstance().InLift) then
          return false
        end
      end
      do return true end
      do return end
      _ARG_1_ = _ENV[190]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnBoostingChanged"] = function(_ARG_0_)
    do
      _ARG_0_.Super:OnBoostingChanged()
      if _ARG_0_.IsBoosting and _ARG_0_:IsBoosting() then
        _ARG_0_:ActiveEffectAsync((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96)))
      else
        _ARG_0_:DeactiveEffect((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitOptimizeLeaveVehicle"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 128, 125, 201, 238, 231, 220, 150, 222, 90, 190, 11, 238, 163, 41, 158, 99, 168, 97, 197, 216, 228, 212, 138), _ARG_0_.Object)
      if not slua.isValid((_ARG_0_:GetSeatComponent())) or not _ARG_0_:GetSeatComponent().LeaveVehicleConfig then
        return
      end
      if require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 189, 107, 195, 215, 238, 223, 193, 239),
        U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)
      }))).GetConfig(_ARG_0_.VehicleShapeType) then
        goto lbl_200
        if slua.IndexReference(_ARG_0_:GetSeatComponent(), (U1(82, 65, 172, 231, 2, 206, 234, 235, 74, 183, 18, 215, 149, 55, 150, 112, 135, 115)))[U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)] ~= nil then
          slua.IndexReference(_ARG_0_:GetSeatComponent(), (U1(82, 65, 172, 231, 2, 206, 234, 235, 74, 183, 18, 215, 149, 55, 150, 112, 135, 115)))[U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)] = U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)
        end
        ::lbl_200::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegisterVehicleSkill"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.VehicleRegisterSkills[_ARG_1_] = _ARG_2_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurVehicleSkillBySkillID"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_.VehicleRegisterSkills[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleAccessorySlotConfig"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ or not _ARG_2_ then
        log(bWriteLog and table.concat({
          U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203),
          U1(119, 71, 161, 244, 38, 251, 236, 230, 80, 167, 17, 192, 175, 11, 148, 121, 154, 87, 210, 207, 241, 193, 152, 159, 19, 180, 15, 208, 167, 37, 200, 111, 141, 36, 195, 216, 235)
        }))
        return nil
      end
      log(bWriteLog and table.concat({
        U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203),
        U1(119, 71, 161, 244, 38, 251, 236, 230, 80, 167, 17, 192, 175, 11, 148, 121, 154, 87, 210, 207, 241, 193, 152, 159, 19, 170, 47, 212, 167, 60, 137, 116, 183, 64, 141, 140, 167)
      }) .. tostring(_ARG_1_) .. U1(62, 87, 161, 254, 19, 204, 246, 243, 70, 244, 67, 146) .. tostring(_ARG_2_))
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) or not _ARG_0_:GetAvatarComponent().GetItemAvatarHandle then
        return nil
      end
      if not slua.isValid((_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_))) then
        return nil
      end
      if not _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs or _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Num() == 0 then
        return nil
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203))) and _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203))).AccessorySlotName == _ARG_2_ then
        return (_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203))))
      end
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1[244]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHPBarShowName"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.VehicleHPBarName = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHPBarShowName"] = function(_ARG_0_)
    do
      if _ARG_0_.VehicleHPBarName and _ARG_0_.VehicleHPBarName ~= _ENV() then
        return _ARG_0_.VehicleHPBarName
      end
      _ARG_0_.VehicleHPBarName = U1.CDataTable.GetTableData(_ENV(87, 80, 168, 252), _ARG_0_.AvatarDefaultCfg.TypeSpecificID) and U1.CDataTable.GetTableData(_ENV(87, 80, 168, 252), _ARG_0_.AvatarDefaultCfg.TypeSpecificID).ItemName or _ENV()
      if U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))) and U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))).VehicleItemIDNameConfig and U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))).VehicleItemIDNameConfig[_ARG_0_.AvatarDefaultCfg.TypeSpecificID] then
        _ARG_0_.VehicleHPBarName = U1.LocUtil.GetLocalizeResStr(U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))).VehicleItemIDNameConfig[_ARG_0_.AvatarDefaultCfg.TypeSpecificID]) or _ARG_0_.VehicleHPBarName
      end
      do return _ARG_0_.VehicleHPBarName end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitVehicleDIYComponent"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 128, 125, 201, 247, 242, 192, 150, 208, 95, 161, 42, 235, 159, 11, 135, 107, 142, 107, 195, 212, 233, 204, 207, 205),
          U1(113, 80, 237, 199, 2, 240, 230, 224, 79, 177, 55, 246)
        }))
        return
      end
      if not CDataTable.GetTableData(U1(72, 65, 165, 248, 4, 244, 234, 199, 106, 141, 61, 212, 177), tonumber(_ARG_1_)) then
        if slua.isValid(_ARG_0_.BP_VehicleDIYComp) then
          _ARG_0_.BP_VehicleDIYComp = nil
        end
        return
      end
      if not slua.isValid(_ARG_0_.BP_VehicleDIYComp) then
        _ARG_0_.BP_VehicleDIYComp = Game:AddComponent(import((table.concat({
          U1(49, 99, 172, 252, 2, 183, 205, 239, 86, 177, 46, 192, 191, 54, 140, 101, 193, 85, 203, 192, 227, 201, 141, 247, 122, 157, 65, 224, 150, 23, 190, 99, 150, 109, 206, 221, 226, 252, 166, 250),
          U1(93, 75, 160, 225, 73, 218, 223, 220, 117, 177, 22, 219, 181, 52, 157, 82, 167, 77, 254, 206, 250, 216, 160, 240)
        }))), _ARG_0_, (U1(92, 116, 146, 199, 2, 240, 230, 224, 79, 177, 58, 251, 143, 27, 151, 123, 158)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartRecordDriveData"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      _ARG_0_.RecordCharacter = _ARG_1_
      if not _ARG_0_.UseTimer then
        _ARG_0_.DrivingDistance = 0
        _ARG_0_.LastLocation = _ARG_0_:K2_GetActorLocation()
        _ARG_0_.UseTimer = _ARG_0_:AddGameTimer(0.1, true, function()
          if slua.isValid(U1.Object) and U1.LastLocation then
            U1.DrivingDistance = U1.DrivingDistance + U2.VSize(U1:K2_GetActorLocation() - U1.LastLocation) / 100
            U1.LastLocation = U1:K2_GetActorLocation()
          end
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EndRecordDriveData"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_0_.DriverDistanceTLogID then
        return
      end
      if _ARG_0_.RecordCharacter ~= _ARG_1_ then
        return
      end
      _ARG_0_.RecordCharacter = nil
      _ARG_0_:RemoveGameTimer(_ARG_0_.UseTimer)
      _ARG_0_.UseTimer = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecordVehicleTlog"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_0_.EnterCountTlogID then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanBeCatched"] = function(_ARG_0_, _ARG_1_)
    do
      do return (_ARG_0_.UltraHandBeCatchedFeature:CanBeCatched(_ARG_1_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleProtectionStuckInternal"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.VehicleProtectionInternalTimer ~= nil and _ARG_0_.VehicleProtectionInternalTimer > 0 then
        _ARG_0_:RemoveGameTimer(_ARG_0_.VehicleProtectionInternalTimer)
      end
      if _ARG_0_:GetProtectionComponent() and slua.isValid((_ARG_0_:GetProtectionComponent())) then
        _ARG_0_:GetProtectionComponent().CheckStuckInterval = _ARG_1_
        _ARG_0_:GetProtectionComponent().StuckDuration = _ARG_2_
        _ARG_0_.VehicleProtectionInternalTimer = _ARG_0_:AddGameTimer(_ARG_3_, false, function()
          if _ENV and U1.slua.isValid(_ENV) then
            CheckStuckInterval = U1.slua.isValid(_ENV)
            StuckDuration = U1.slua.isValid(_ENV)
          end
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshVehiclePassengersParticle"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 68, 139, 114, 207, 196, 228, 192, 169, 214, 91, 173, 13, 206, 163, 24, 137, 117, 141, 97, 195, 214, 226, 202, 156, 243),
        U1(127, 86, 185, 248, 4, 244, 234)
      }))
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      goto lbl_262
      ::lbl_262::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandlePlayerAttachedToVehcicle"] = function(_ARG_0_, _ARG_1_)
    do
      if Client and slua.isValid(_ARG_1_) and _ARG_1_.CheckAttachedOrDetachedVehicle then
        _ARG_1_:CheckAttachedOrDetachedVehicle(true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_BlockForwardInput"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 234, 147, 220, 80, 175, 40, 205, 180, 63, 137, 116, 154, 77, 195, 193, 242, 204))
      if _ARG_0_.Super.OnRep_BlockForwardInput then
        _ARG_0_.Super:OnRep_BlockForwardInput()
      end
      if slua.isValid((require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter())) and require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter().GetCurrentVehicle and slua.isValid(require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter():GetCurrentVehicle()) and require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter():GetCurrentVehicle() == _ARG_0_.Object then
        if Game:IsClassOf(_ARG_0_.Object, import((U1(92, 77, 162, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61)))) or Game:IsClassOf(_ARG_0_.Object, import((U1(72, 65, 165, 248, 4, 244, 234, 193, 74, 191, 27)))) or Game:IsClassOf(_ARG_0_.Object, import((U1(72, 65, 165, 248, 4, 244, 234, 206, 76, 160, 17, 192, 145, 52, 145, 114, 139, 102)))) then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMeshPhysicsCreateExt"] = function(_ARG_0_)
    do
      _ARG_0_:LuaBroadcast(_ARG_0_.OnMeshPhysicsCreateDelegate)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FellOutOfWorldExt"] = function(_ARG_0_, _ARG_1_)
    do
      if Client and Client.IsDevelopment() and not (slua.isValid((import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance())) and import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance():IsPlayingAnyPlayback()) and slua.isValid(CGameState) and CGameState:GetGameModeState() ~= U1(88, 77, 163, 248, 20, 240, 234, 231, 112, 160, 31, 198, 179) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OutsideWorldBoundsExt"] = function(_ARG_0_, _ARG_1_)
    do
      if Client and Client.IsDevelopment() and not (slua.isValid((import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance())) and import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance():IsPlayingAnyPlayback()) and slua.isValid(CGameState) and CGameState:GetGameModeState() ~= U1(88, 77, 163, 248, 20, 240, 234, 231, 112, 160, 31, 198, 179) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["NeedCreateShootDriverComp"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 189, 107, 195, 215, 238, 223, 193, 245),
        U1(123, 76, 164, 242, 11, 253, 220, 235, 76, 187, 10, 246, 164, 49, 142, 115, 156, 87, 210, 207, 241, 193, 152)
      }))) and require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 189, 107, 195, 215, 238, 223, 193, 245),
        U1(123, 76, 164, 242, 11, 253, 220, 235, 76, 187, 10, 246, 164, 49, 142, 115, 156, 87, 210, 207, 241, 193, 152)
      }))).GetCfg(_ARG_0_.Object) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSocialIslandVehicle"] = function(_ARG_0_)
    do
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaShouldLeaveFitCloseToGround"] = function(_ARG_0_)
    do
      if _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_UH60 or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_HeavyUH60 or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_Motorglider or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_WingMan or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_Fighter or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_Aircraft then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBornIslandVehicle"] = function(_ARG_0_)
    do
      do return _ARG_0_.bIsBornIslandVehicle end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}).ClientRPC.ClientResetToTransform = {
  Reliable = true,
  Params = {}
}
;({
  ServerRPC = {},
  ClientRPC = {},
  MulticastRPC = {},
  LuaEventContainer = {
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 128, 244, 20, 240, 223, 235, 90, 167, 23, 209, 165, 27, 138, 115, 143, 96, 216),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(72, 65, 165, 248, 4, 244, 234, 208, 72, 189, 18, 222, 147, 54, 157, 100, 137, 109, 254, 201, 246, 198, 152, 214, 87),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(72, 65, 165, 248, 4, 244, 234, 198, 77, 176, 46, 222, 183, 33, 189, 96, 139, 122, 201),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 152, 226, 2, 213, 224, 247, 76, 166, 63, 199, 178, 49, 151),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 136, 233, 15, 237, 238, 240, 87, 145, 24, 212, 179, 59, 140, 68, 139, 114, 207, 196, 228, 192),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 142, 249, 6, 246, 232, 230, 112, 177, 31, 198),
    ((function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 136, 233, 14, 236, 217, 230, 75, 189, 29, 222, 179))
  },
  ["ctor"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.SeatComponent = nil
      _ARG_0_.AvatarComponent = nil
      _ARG_0_.AdvanceAvatarComponent = nil
      _ARG_0_.BP_VehicleDIYComp = nil
      _ARG_0_.ClientUsedAvatarID = 0
      _ARG_0_.CommonComponent = nil
      _ARG_0_.SpringArm = nil
      _ARG_0_.LastOccupiers = {}
      _ARG_0_.AttachedCharacterLocation = {}
      _ARG_0_.AttachedCharacterBlock = {}
      _ARG_0_.OnMeshPhysicsCreateDelegate = _ENV(81, 74, 128, 244, 20, 240, 223, 235, 90, 167, 23, 209, 165, 27, 138, 115, 143, 96, 216)
      _ARG_0_.bCanVehicleExit = true
      _ARG_0_.VehicleRegisterSkills = {}
      _ARG_0_.VehicleProtectionInternalTimer = nil
      _ARG_0_.OriginalCheckStuckInterval = 1
      _ARG_0_.OriginalStuckDuration = 5
      _ARG_0_.UseTimer = nil
      _ARG_0_.DrivingDistance = 0
      _ARG_0_.RecordCharacter = nil
      _ARG_0_.bIsBornIslandVehicle = false
      _ARG_0_.bUGCSkillAirDrop = false
      _ARG_0_.WeddingCarIndex = 0
      _ARG_0_.PassengerEnterShowTextID = nil
      _ARG_0_.PassengerEnterShowIconPath = nil
      _ARG_0_.DriverEnterShowTextID = nil
      _ARG_0_.DriverEnterShowIconPath = nil
      _ARG_0_.LeaveVehicleTextID = nil
      _ARG_0_.LeaveVehicleIconPath = nil
      _ARG_0_.VehicleHPBarName = _ENV()
      _ARG_0_.bUGCInstance = false
      _ARG_0_.UGCInstanceId = 0
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PostConstruct"] = function(_ARG_0_)
    do
      __super._PostConstruct(_ARG_0_)
      _ARG_0_:InitConfig()
      if U1.Client then
        _ARG_0_:AddCommonEvent(U1.EVENTTYPE_INGAME_NORMAL, U1.EVENTID_SEQUENCE_MSG, _ARG_0_.HandleForbidEnterVehicle, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 142, 253, 14, 253, 225, 247, 102, 186, 10, 215, 164, 14, 157, 126, 135, 119, 209, 196, 210, 222, 154, 221, 71), _ARG_0_.ClientHandleEnterVehicle, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 142, 253, 14, 253, 225, 247, 102, 172, 23, 198, 128, 61, 144, 127, 141, 120, 216, 228, 225, 205, 145, 199), _ARG_0_.ClientHandleExitVehicle, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 142, 253, 14, 253, 225, 247, 96, 188, 31, 220, 177, 61, 174, 115, 134, 125, 222, 205, 242, 251, 154, 210, 71, 129, 24, 199, 168, 60), _ARG_0_.ClientHandleChangeVehicleSeat, _ARG_0_)
      else
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 136, 255, 19, 253, 253, 213, 70, 188, 23, 209, 186, 61), _ARG_0_.ServerHandleEnterVehicleResult, _ARG_0_)
      end
      _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 155, 244, 15, 241, 236, 239, 70, 156, 27, 211, 186, 44, 144, 69, 154, 117, 201, 196, 212, 192, 158, 221, 84, 161, 10), _ARG_0_.LuaHandleHealthStateChanged, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 155, 244, 15, 241, 236, 239, 70, 156, 27, 211, 186, 44, 144, 82, 139, 103, 201, 211, 248, 209), _ARG_0_.LuaHandleVehicleHealthDestroy, _ARG_0_)
      if U1.slua.isValid((_ARG_0_:GetAvatarComponent())) then
        _ARG_0_.ClientUsedAvatarID = _ARG_0_:GetAvatarComponent():GetDefaultAvatarID()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PreDestruct"] = function(_ARG_0_)
    do
      if _ARG_0_.Features then
        goto lbl_37
        ::lbl_37::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.VehicleFeatures then
        goto lbl_56
        ::lbl_56::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _ARG_0_.VehicleFeatures = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLifetimeReplicatedProps"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 81, 139, 96, 241, 200, 241, 205, 139, 218, 94, 161, 60, 199, 182, 36, 129, 101, 159, 112, 200, 213, 215, 202, 128, 211),
        U1(109)
      }))
      do return {
        {
          U1(124, 113, 138, 210, 52, 243, 230, 239, 79, 149, 23, 192, 146, 42, 151, 102),
          import((U1(91, 104, 164, 247, 2, 236, 230, 238, 70, 151, 17, 220, 178, 49, 140, 127, 129, 122))).COND_None,
          UEnums.EPropertyClass.Bool
        },
        {
          U1(73, 65, 169, 245, 14, 246, 232, 192, 66, 166, 55, 220, 178, 61, 128),
          import((U1(91, 104, 164, 247, 2, 236, 230, 238, 70, 151, 17, 220, 178, 49, 140, 127, 129, 122))).COND_None,
          UEnums.EPropertyClass.Int
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_bUGCSkillAirDrop"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 202, 170, 244, 112, 151, 5, 203, 170, 36, 169, 111, 140, 64, 223, 222, 247, 148, 207, 236),
        U1(114, 64, 155, 240, 11, 237, 234)
      }) .. tostring(_ARG_1_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_WeddingCarIndex"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 255, 154, 215, 87, 173, 0, 197, 133, 41, 154, 79, 144, 96, 200, 201, 171, 152, 160, 207),
        U1(122, 114, 172, 253, 18, 253)
      }) .. tostring(_ARG_1_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientDriverChangeEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid(_ARG_2_) and _ARG_2_:IsLocallyControlled() and Game:IsValid(_ARG_0_:GetVehicleSpringArm()) and _ARG_0_:GetVehicleSpringArm().bForceInitCameraLagWhenDriverGetOn then
        _ARG_0_:GetVehicleSpringArm().bDoLocationLagInit = false
      end
      _ARG_0_.bBaseAutoMoveForward = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnPlayerCannotExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_0_.uLastCannotExitLocation ~= nil and FVector.Distance(_ARG_0_:K2_GetActorLocation(), _ARG_0_.uLastCannotExitLocation) < 100 then
        return
      end
      _ARG_0_.uLastCannotExitLocation = _ARG_0_:K2_GetActorLocation()
      if 100 < _ARG_0_:GetForwardSpeed() then
        return
      end
      do return end
      _ARG_0_ = _ENV[140]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitConfig"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 128, 125, 201, 226, 248, 198, 153, 218, 84), _ARG_0_.Object)
      if require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 168, 97, 197, 216, 228, 212, 138, 224),
        U1(113, 74, 171, 248, 0)
      }))).GenConfig(_ARG_0_.Object, _ARG_0_.VehicleShapeType) and next((require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 168, 97, 197, 216, 228, 212, 138, 224),
        U1(113, 74, 171, 248, 0)
      }))).GenConfig(_ARG_0_.Object, _ARG_0_.VehicleShapeType))) then
        goto lbl_106
        _ARG_0_[U1(113, 74, 171, 248, 0)] = U1(113, 74, 171, 248, 0)
        ::lbl_106::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleControlUIConfig"] = function(_ARG_0_)
    do
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUIConfig"] = function(_ARG_0_)
    do
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitComponents"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_23
      ::lbl_23::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitComponentAttributes"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_18
      ::lbl_18::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitVehicleFeatures"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_19
      ::lbl_19::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_76
      if slua.IsLuaModuleExists(table.unpack(_ARG_1_[226])) then
        if table.unpack(_ARG_1_[226]) and next(table.unpack(_ARG_1_[226])) then
          goto lbl_68
          require(table.unpack(_ARG_1_[226]))(_ARG_0_.Object)[nil] = nil
          ::lbl_68::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      ::lbl_76::
      _ARG_0_ = _ARG_0_
      _ARG_0_.VehicleFeatures, _ARG_0_ = {
        [226] = require(table.unpack(_ARG_1_[226]))(_ARG_0_.Object)
      }, _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitCustomConfigs"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      _ARG_0_.VehicleCustomConfigs = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearVehicleFeatures"] = function(_ARG_0_)
    do
      if _ARG_0_.VehicleFeatures and next(_ARG_0_.VehicleFeatures) then
        goto lbl_20
        ::lbl_20::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _ARG_0_.VehicleFeatures = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CallFunction"] = function(_ARG_0_, _ARG_1_, _ARG_2_, ...)
    do
      if _ARG_0_[_ARG_1_] then
        if slua.isValid(_ARG_0_[_ARG_1_]) and _ARG_0_[_ARG_1_][_ARG_2_] then
          return _ARG_0_[_ARG_1_][_ARG_2_](_ARG_0_[_ARG_1_], ...)
        end
      else
        _ARG_0_.FunctionCache = _ARG_0_.FunctionCache or {}
        if _ARG_0_.FunctionCache then
          _ARG_0_.FunctionCache[_ARG_1_] = _ARG_0_.FunctionCache[_ARG_1_] or {}
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ExecuteFunctions"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.FunctionCache or not _ARG_0_.FunctionCache[_ARG_1_] then
        return
      end
      goto lbl_23
      ::lbl_23::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveBeginPlay"] = function(_ARG_0_)
    do
      __super.ReceiveBeginPlay(_ARG_0_)
      _ARG_0_:InitOptimizeLeaveVehicle()
      if U1.SubsystemMgr:Get((U2(72, 65, 165, 248, 4, 244, 234, 208, 86, 182, 13, 203, 165, 44, 157, 123))) then
      end
      if U1.Client then
        if U1.slua.isValid((_ARG_0_:GetAdvanceAvatarComponent())) then
        end
      else
        _ARG_0_.bSkipComparePropertiesForReplay = true
        if _ARG_0_:GetProtectionComponent() and U1.slua.isValid((_ARG_0_:GetProtectionComponent())) then
          _ARG_0_.OriginalCheckStuckInterval = _ARG_0_:GetProtectionComponent().CheckStuckInterval
          _ARG_0_.OriginalStuckDuration = _ARG_0_:GetProtectionComponent().StuckDuration
        end
        if U1.slua.isValid(_ARG_0_.VehicleMovement) and _ARG_0_.VehicleMovement.DriftSetup then
          _ARG_0_.VehicleMovement.DriftSetup.MaxOmega = 360
        end
        if U1.slua.isValid((_ARG_0_:GetVehicleSync())) then
          _ARG_0_:GetVehicleSync().VehicleHitRewindThreshold.ValidDeltaSeconds = 0.35
        end
      end
      _ARG_0_.DefaultStartLocation = _ARG_0_:K2_GetActorLocation()
      _ARG_0_.DefaultStartRotation = _ARG_0_:K2_GetActorRotation()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AfterBeginPlay"] = function(_ARG_0_)
    do
      if _ARG_0_.Super.AfterBeginPlay then
        _ARG_0_.Super:AfterBeginPlay()
      end
      if slua.isValid(_ARG_0_.VehicleShootAntiCheat) then
        _ARG_0_.VehicleShootAntiCheat.BoundBoxExtendMoveTime = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetShootVertifyHitBoxScale"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return FVector(2, 2, 2) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerHandleEnterVehicleResult"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_2_ == U1.ESeatType_DriversSeat and slua.isValid(_ARG_0_:GetVehicleSpringArm()) then
        _ARG_0_:GetVehicleSpringArm().bDoCollisionTest = true
      end
      _ARG_1_.ClientSidePoseState = import((U2(91, 119, 153, 212, 55, 247, 252, 230, 112, 160, 31, 198, 179))).Stand
      if slua.isValid((_ARG_1_:GetThirdPersonSpringArm())) then
        _ARG_1_:GetThirdPersonSpringArm().bDoCollisionTest = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      _ARG_1_.ClientSidePoseState = import((U1(91, 119, 153, 212, 55, 247, 252, 230, 112, 160, 31, 198, 179))).Stand
      if Game:IsBioVehicle(_ARG_0_.Object) then
        if slua.isValid(_ARG_0_.CapsuleComponent) and _ARG_0_.CapsuleComponent:ComponentHasTag((U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157))) then
          _ARG_0_ = _ARG_0_
          if _ARG_0_.CapsuleComponent.ComponentTags:Get(81) == U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157) then
          else
            _ARG_0_ = _ARG_0_
          end
          if 81 >= 0 then
          end
        end
        if slua.isValid(_ARG_0_.HeadCapsuleComponent) and _ARG_0_.HeadCapsuleComponent:ComponentHasTag((U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157))) then
          _ARG_0_ = _ARG_0_
          if _ARG_0_.HeadCapsuleComponent.ComponentTags:Get(81) == U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157) then
          else
            _ARG_0_ = _ARG_0_
          end
          if 81 >= 0 then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleChangeVehicleSeat"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEndChangeVehicleItemAvatar"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 81, 211, 197, 212, 192, 158, 221, 84, 161, 56, 199, 174, 33, 139, 106, 155, 77, 217, 212, 234, 249, 153, 194),
        U1(106, 69, 191)
      }))
      _ARG_0_:CheckAvatarDormant()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAvatarDormant"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SpawnBoxComponent"] = function(_ARG_0_)
    do
      if not _ARG_0_:HasAuthority() then
        return
      end
      if import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))) == nil then
        return
      end
      if not Game:IsValid((Game:AddComponent(import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))), _ARG_0_, (U1(90, 65, 172, 245, 49, 253, 231, 234, 64, 184, 27, 240, 185, 32))))) then
        return
      end
      if not Game:AddComponent(import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))), _ARG_0_, (U1(90, 65, 172, 245, 49, 253, 231, 234, 64, 184, 27, 240, 185, 32))):K2_AttachToComponent(_ARG_0_.Mesh, U1(80, 75, 163, 244), import((U1(91, 101, 185, 229, 6, 251, 231, 238, 70, 186, 10, 224, 163, 52, 157))).KeepRelative, import((U1(91, 101, 185, 229, 6, 251, 231, 238, 70, 186, 10, 224, 163, 52, 157))).KeepRelative, import((U1(91, 101, 185, 229, 6, 251, 231, 238, 70, 186, 10, 224, 163, 52, 157))).KeepRelative, false) then
        return
      end
      Game:AddComponent(import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))), _ARG_0_, (U1(90, 65, 172, 245, 49, 253, 231, 234, 64, 184, 27, 240, 185, 32))).bGenerateOverlapEvents = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BPGetQueryIgnoreActors"] = function(_ARG_0_)
    do
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenPhysicForAMoment"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:HasAuthority() then
        return
      end
      if _ARG_0_:IsSimulatePhysics() then
        return
      end
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 158, 113, 211, 241, 255, 209, 140, 218, 80, 130, 1, 208, 135, 5, 135, 107, 155, 106, 217), _ARG_0_.Role)
      _ARG_0_:SetSimulatePhysics(true)
      if _ARG_0_.PhysicTimer ~= nil then
        Game:ClearTimer(_ARG_0_.PhysicTimer)
        _ARG_0_.PhysicTimer = nil
      end
      _ARG_0_.PhysicTimer = Game:SetTimer(_ARG_1_, false, function()
        _ENV:SetSimulatePhysics(false)
        U1.Game:ClearTimer(PhysicTimer)
        PhysicTimer = nil
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveEndPlay"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.PhysicTimer ~= nil then
        Game:ClearTimer(_ARG_0_.PhysicTimer)
        _ARG_0_.PhysicTimer = nil
      end
      _ARG_0_.bIsDeformed = false
      _ARG_0_.VehicleRegisterSkills = {}
      EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_ENDPLAY, _ARG_0_.Object)
      _ARG_0_:ClearVehicleFeatures()
      if _ARG_0_.LuaBroadcast then
        _ARG_0_:LuaBroadcast((U1(72, 65, 165, 248, 4, 244, 234, 198, 77, 176, 46, 222, 183, 33, 189, 96, 139, 122, 201)))
      end
      _ARG_0_.Super:ReceiveEndPlay(_ARG_1_)
      U2.__super.ReceiveEndPlay(_ARG_0_, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMoveComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.MoveComponent) then
        _ARG_0_.MoveComponent = _ARG_0_:GetComponentByClass((import((U1(77, 112, 136, 233, 19, 234, 238, 213, 70, 188, 23, 209, 186, 61, 181, 121, 152, 113, 208, 196, 249, 220, 188, 220, 94, 180, 1, 204, 163, 38, 156, 50, 169)))))
      end
      do return _ARG_0_.MoveComponent end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCommonComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.CommonComponent) then
        _ARG_0_.CommonComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 192, 76, 185, 19, 221, 184, 27, 151, 123, 158, 123, 211, 196, 249, 220)))))
      end
      do return _ARG_0_.CommonComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSeatComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.SeatComponent) and slua.isValid(_ARG_0_.Object) then
        _ARG_0_.SeatComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 208, 70, 181, 10, 241, 185, 53, 136, 121, 128, 113, 211, 213)))))
      end
      do return _ARG_0_.SeatComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAvatarComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.AvatarComponent) then
        _ARG_0_.AvatarComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 194, 85, 181, 10, 211, 164, 27, 151, 123, 158, 123, 211, 196, 249, 220)))))
      end
      do return _ARG_0_.AvatarComponent end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAdvanceAvatarComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.AdvanceAvatarComponent) then
        _ARG_0_.AdvanceAvatarComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 194, 71, 162, 31, 220, 181, 61, 185, 96, 143, 96, 220, 211, 212, 199, 146, 195, 92, 170, 11, 204, 178)))))
      end
      do return _ARG_0_.AdvanceAvatarComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetProtectionComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.ProtectionComponent) then
        _ARG_0_.ProtectionComponent = _ARG_0_:GetComponentByClass((import((U1(73, 76, 168, 244, 11, 253, 235, 213, 70, 188, 23, 209, 186, 61, 168, 100, 129, 96, 216, 194, 227, 193, 144, 221, 112, 171, 3, 210, 169, 38, 141, 104, 138)))))
      end
      do return _ARG_0_.ProtectionComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMotorbikeComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.MotorbikeComponent) then
        _ARG_0_.MotorbikeComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 206, 76, 160, 17, 192, 180, 49, 147, 115, 173, 123, 208, 209, 248, 198, 154, 221, 71)))))
      end
      do return _ARG_0_.MotorbikeComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMusicComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.MusicComponent) then
        _ARG_0_.MusicComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 206, 86, 167, 23, 209, 149, 55, 149, 102, 129, 122, 216, 207, 227)))))
      end
      do return _ARG_0_.MusicComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBuffComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.BuffSystemComp) then
        _ARG_0_.BuffSystemComp = _ARG_0_:GetComponentByClass((import((U1(77, 112, 143, 228, 1, 254, 220, 250, 80, 160, 27, 223, 149, 55, 149, 102, 129, 122, 216, 207, 227)))))
      end
      do return _ARG_0_.BuffSystemComp end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAccelerationComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.AccelerateComponent) then
        _ARG_0_.AccelerateComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 194, 64, 183, 27, 222, 179, 42, 153, 98, 139, 87, 210, 204, 231, 199, 145, 214, 93, 176)))))
      end
      do return _ARG_0_.AccelerateComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPickupComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehiclePickableComponent) then
        _ARG_0_.VehiclePickableComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 211, 74, 183, 21, 211, 180, 52, 157, 85, 129, 121, 205, 206, 249, 205, 145, 199)))))
      end
      do return _ARG_0_.VehiclePickableComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLicenseComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehicleLicenseComponent) then
        _ARG_0_.VehicleLicenseComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 207, 74, 183, 27, 220, 165, 61, 182, 99, 131, 118, 216, 211, 212, 199, 146, 195, 92, 170, 11, 204, 178)))))
      end
      do return _ARG_0_.VehicleLicenseComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleCabrioletComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehicleCabrioletComponent) then
        _ARG_0_.VehicleCabrioletComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 192, 66, 182, 12, 219, 185, 52, 157, 98, 173, 123, 208, 209, 248, 198, 154, 221, 71)))))
      end
      do return _ARG_0_.VehicleCabrioletComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddDynamicComponentLoadCompletedCallbacks"] = function(_ARG_0_, _ARG_1_, ...)
    do
      if _ARG_0_:DynamicComponentAllLoadCompleted() then
      elseif _ARG_0_.DynamicComponentLoadCompletedCallbacks == nil then
        _ARG_0_.DynamicComponentLoadCompletedCallbacks = {}
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ForceExitCharacters"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:HasAuthority() then
        if not slua.isValid((_ARG_0_:GetSeatComponent())) then
          return
        end
        goto lbl_128
        if slua.isValid(nil) then
          if _ARG_1_ == true then
            if slua.isValid(((nil):GetWeaponManager())) and (nil):GetWeaponManager():GetAllInventoryWeaponList(false) then
              goto lbl_126
              ::lbl_126::
              _ARG_0_ = _ARG_0_
              _ARG_0_ = _ARG_0_
            end
          end
        end
        ::lbl_128::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleDriverChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 236, 141, 218, 69, 161, 28, 225, 174, 41, 134, 97, 155, 96))
      _ARG_0_:ResetCandidateAvatarID(_ARG_2_)
      if CGameMode and not CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).Drived then
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).VehicleShapeType = _ARG_0_.VehicleShapeType
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).Drived = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatOccupiersChanged"] = function(_ARG_0_)
    do
      EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_SEAT_OCCUPIERS_CHANGED, _ARG_0_.Object)
      if slua.isValid((_ARG_0_:GetSeatComponent())) then
        if _ARG_0_.LastOccupiers and next(_ARG_0_.LastOccupiers) then
          goto lbl_36
          if slua.isValid(nil) then
          end
          ::lbl_36::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          goto lbl_71
          if slua.isValid(229) and not ({
            [nil] = true
          })[229] then
          end
          ::lbl_71::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if Client and not Client.IsEnableDSGrayPublishFlag(2199023255552) and not Client.IsEditor() and slua.isValid(_ARG_0_.Object) and not _ARG_0_.IsUnmannedVehicle and slua.isValid((_ARG_0_:GetSeatComponent())) then
          goto lbl_274
          if slua.isValid(229) and slua.isValid((229):GetCurrentVehicle()) and slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle()) then
          end
          ::lbl_274::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          goto lbl_461
          if slua.isValid(slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())) and not slua.isValid((slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetCurrentVehicle()) and slua.isValid(((slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetPlayerControllerSafety():GetVehicleUserComp())) and slua.isValid((slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle()) and slua.isValid((_ARG_0_:GetMesh())) and 229 >= 0 and 229 < _ARG_0_:GetSeatComponent().Seats:Num() then
            FVector(0, 0, 0).Z = (slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetSimpleCollisionHalfHeightInStandPose()
          end
          ::lbl_461::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if slua.isValid((_ARG_0_:GetSeatComponent())) then
          goto lbl_647
          ::lbl_647::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      _ARG_0_.LastOccupiers = {}
      goto lbl_663
      _ARG_0_.LastOccupiers[pairs(_ARG_0_:GetSeatComponent().SeatOccupiers)] = U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 210, 71, 139, 13, 193, 179, 56, 129, 99, 140, 119, 238, 217, 230, 214, 136, 198), slua.isValid((U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 210, 71, 139, 13, 193, 179, 56, 129, 99, 140, 119, 238, 217, 230, 214, 136, 198))) and _ARG_0_.LastOccupiers
      ::lbl_663::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetCandidateAvatarID"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(76, 65, 190, 244, 19, 219, 238, 237, 71, 189, 26, 211, 162, 61, 185, 96, 143, 96, 220, 211, 222, 236), _ARG_1_)
      if _ARG_0_:HasAuthority() and not slua.isValid(_ARG_1_) then
        _ARG_0_.CandidateAvatarID = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSeatAvailable"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid((_ARG_0_:GetSeatComponent())) then
        return _ARG_0_:GetSeatComponent():IsSeatIndexAvailable(_ARG_1_)
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayerEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 68, 209, 192, 238, 205, 141, 246, 93, 176, 11, 208, 144, 45, 128, 111, 157, 104, 200), _ARG_1_, _ARG_2_, _ARG_0_.bSkipComparePropertiesForReplay)
      if not Client then
        _ARG_0_.bSkipComparePropertiesForReplay = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayerExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 68, 209, 192, 238, 205, 141, 246, 75, 173, 26, 244, 163, 32, 129, 101, 146, 97), _ARG_1_, _ARG_2_, _ARG_3_, _ARG_0_.bSkipComparePropertiesForReplay)
      if not Client and _ARG_1_ then
        _ARG_0_.bSkipComparePropertiesForReplay = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleServerAvatarEquiped"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 193, 69, 161, 28, 227, 176, 41, 156, 103, 140, 65, 220, 196, 238, 200, 138, 199))
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleVehicleLoadedFPPMesh"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 64, 139, 124, 212, 194, 251, 205, 179, 220, 82, 160, 11, 198, 128, 24, 184, 75, 155, 119, 197))
      _ARG_0_:HandleClientAvatarEquiped()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientAvatarEquiped"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 147, 218, 86, 170, 26, 227, 176, 41, 156, 103, 140, 65, 220, 196, 238, 200, 138, 199))
      if slua.isValid((_ARG_0_:GetAvatarComponent())) then
        if _ARG_0_:GetAvatarComponent():GetCurrentAvatarID() == _ARG_0_.ClientUsedAvatarID then
          return
        end
        _ARG_0_.ClientUsedAvatarID = _ARG_0_:GetAvatarComponent():GetCurrentAvatarID()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientVehicleSwitchEffectEnd"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 147, 218, 86, 170, 26, 244, 163, 32, 129, 101, 146, 97, 254, 198, 238, 204, 140, 203),
        U1(91, 66, 171, 244, 4, 236, 202, 237, 71)
      }))
      _ARG_0_:InitVehicleDIYComponent(_ARG_0_.ClientUsedAvatarID)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientVehicleSlotEquiped"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      if _ARG_0_:GetAvatarComponent().NetHighTireStruct and _ARG_0_:GetAvatarComponent().NetHighTireStruct.bEnableHighTire ~= nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeactiveSkinSpecialEffect"] = function(_ARG_0_)
    do
      _ARG_0_:DeactiveEffect((_ENV(91, 92, 165, 240, 18, 235, 251)))
      _ARG_0_:DeactiveEffect((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222)))
      _ARG_0_:DeactiveEffect((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96)))
      _ARG_0_:DeactiveEffect((_ENV(77, 80, 172, 227, 19, 205, 255, 197, 123)))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleAdvanceAvatarEquipped"] = function(_ARG_0_)
    do
      if _ARG_0_:HasAuthority() then
        _ARG_0_:HandleServerAdvanceAvatarEquipped()
      else
        _ARG_0_:HandleClientAdvanceAvatarEquipped()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAndSetStartUpEffect"] = function(_ARG_0_, _ARG_1_)
    do
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleServerAdvanceAvatarEquipped"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 193, 69, 161, 28, 227, 162, 62, 137, 104, 157, 97, 236, 199, 230, 204, 142, 209),
        U1(91, 85, 184, 248, 23, 232, 234, 231)
      }))
      if not slua.isValid((_ARG_0_:GetAdvanceAvatarComponent())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientAdvanceAvatarEquipped"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetAdvanceAvatarComponent())) then
        return
      end
      if _ARG_0_:GetAdvanceAvatarComponent().VehicleSkinID == _ARG_0_.ClientUsedAvatarID then
        return
      end
      _ARG_0_.ClientUsedAvatarID = _ARG_0_:GetAdvanceAvatarComponent().VehicleSkinID
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleCabrioletStateChanged"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 158, 209, 65, 173, 1, 206, 163, 60, 187, 114, 159, 112, 200, 242, 239, 217, 129, 196),
          U1(123, 64, 237, 248, 9, 238, 238, 239, 74, 176, 94, 220, 179, 47, 187, 119, 140, 102, 212, 206, 251, 205, 139, 224, 71, 165, 26, 199)
        }))
        return
      end
      log(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 158, 209, 65, 173, 1, 206, 163, 60, 187, 114, 159, 112, 200, 242, 239, 217, 129, 196),
        U1(123, 64, 237, 255, 2, 239, 204, 226, 65, 166, 23, 221, 186, 61, 140, 69, 154, 117, 201, 196, 173)
      }) .. tostring(_ARG_1_))
      if Client then
        log(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 158, 209, 65, 173, 1, 206, 163, 60, 187, 114, 159, 112, 200, 242, 239, 217, 129, 196),
          U1(123, 64, 237, 210, 11, 241, 234, 237, 87)
        }))
        return
      end
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      goto lbl_340
      ::lbl_340::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleCabrioletState"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetVehicleCabrioletComponent())) then
        return nil
      end
      do return _ARG_0_:GetVehicleCabrioletComponent():GetCabrioletState() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeAssetByAvatar"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 134, 117, 211, 198, 242, 233, 140, 192, 86, 176, 44, 219, 135, 62, 137, 114, 159, 118, 129, 145, 233, 249, 153, 194),
        U1(106, 69, 191, 216, 35, 184, 178, 163)
      }), _ARG_1_)
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      if not slua.isValid((_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateParticle"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 67, 158, 112, 220, 213, 242, 248, 158, 193, 71, 173, 13, 206, 163, 104, 134, 71, 136, 101, 217, 208, 245, 241, 171) .. tostring(_ARG_1_))
      _ARG_0_:DeactiveSkinSpecialEffect()
      _ARG_0_:ChangeAssetBy(_ARG_1_)
      _ARG_0_:ReActivateExhaustParticle()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeParticles"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      _ARG_0_.RuntimeParticleSoftWrapperMap = _ARG_0_.ParticleSoftWrapperMap
      if slua.isValid((_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_))) and _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).ParticleSfx:Num() > 0 then
        goto lbl_109
        ::lbl_109::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.ReplaceParticleMap:Get(_ARG_1_) and 0 < _ARG_0_.ReplaceParticleMap:Get(_ARG_1_).ParticleSfx:Num() then
        goto lbl_138
        ::lbl_138::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.AdditionalParticleMap:Get(_ARG_1_) and 0 < _ARG_0_.AdditionalParticleMap:Get(_ARG_1_).ParticleSfx:Num() then
        goto lbl_167
        ::lbl_167::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ModifyEnterSocket"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 91, 129, 112, 212, 199, 238, 237, 145, 199, 86, 182, 61, 205, 165, 35, 141, 114), _ARG_1_)
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      if U2.GetTableData(U1(72, 65, 165, 248, 4, 244, 234, 194, 87, 160, 12, 240, 134, 12, 153, 116, 130, 113), _ARG_1_) and U2.GetTableData(U1(72, 65, 165, 248, 4, 244, 234, 194, 87, 160, 12, 240, 134, 12, 153, 116, 130, 113), _ARG_1_).EnterVehicleSocket_an:Num() > 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeCharacterAnim"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) or _ARG_1_.VehCharAnimData:Num() == 0 then
        if slua.isValid((_ARG_0_:GetAvatarComponent())) and slua.isValid(_ARG_0_:GetAvatarComponent().DefaultItemAvatarHandle) and 0 < _ARG_0_:GetAvatarComponent().DefaultItemAvatarHandle.VehCharAnimData:Num() then
          _ARG_1_ = _ARG_0_:GetAvatarComponent().DefaultItemAvatarHandle
        else
          return
        end
      end
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 134, 117, 211, 198, 242, 235, 151, 210, 65, 165, 13, 214, 163, 58, 169, 104, 151, 105, 129, 145, 245, 221, 159, 207),
        U1(127, 71, 168, 177, 4, 240, 238, 241, 66, 183, 10, 215, 164, 120, 153, 120, 135, 121)
      }))
      goto lbl_261
      ::lbl_261::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeCharacterAnimNew"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == nil then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 134, 117, 211, 198, 242, 235, 151, 210, 65, 165, 13, 214, 163, 58, 169, 104, 151, 105, 227, 212, 240, 148, 207, 226),
          U1(104, 69, 185, 240, 21, 209, 203, 163, 74, 167, 94, 220, 191, 52)
        }))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaHandleHealthStateChanged"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaHandleVehicleHealthDestroy"] = function(_ARG_0_)
    do
      _ARG_0_:ClearDecals()
      if CGameMode then
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).VehicleShapeType = _ARG_0_.VehicleShapeType
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).IsDestroyed = true
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).LastAttackedTime = U1.GetTimeSeconds(_ARG_0_)
      end
      if slua.isValid(CGameState) and CGameState.GameModeSubType == import((U2(91, 99, 172, 252, 2, 213, 224, 231, 70, 135, 11, 208, 130, 33, 136, 115))).EPlanDGameMode then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_CandidateAvatar"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 235, 158, 221, 87, 173, 10, 195, 178, 45, 169, 112, 159, 112, 204, 195))
      EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_AVATAR_CHANGE_MSG, _ARG_0_.Object, _ARG_0_.CandidateAvatarID ~= 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:HandleOnSeatChanged(_ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
      if _ARG_1_ and slua.isValid(_ARG_1_) and _ARG_1_.getAvatarComponent2 and slua.isValid(_ARG_1_:getAvatarComponent2()) then
        _ARG_1_:getAvatarComponent2():DoAllAvatarReplaceOnVehicle()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnChangeSeat"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 87, 213, 192, 249, 207, 154, 224, 86, 165, 26), _ARG_1_, _ARG_4_, _ARG_2_, _ARG_3_)
      if _ARG_4_ == U2.ESeatType_DriversSeat then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 87, 213, 192, 249, 207, 154, 224, 86, 165, 26, 130, 165, 36, 141, 103, 140, 36, 219, 212, 239, 209, 140, 207),
          U1(123, 4, 164, 255, 23, 237, 251)
        }))
        _ARG_0_:ClearAllInputState()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 81, 197, 200, 227, 254, 154, 219, 90, 167, 2, 199), _ARG_1_, _ARG_2_)
      if _ARG_2_ == U2.ESeatType_DriversSeat then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 81, 197, 200, 227, 254, 154, 219, 90, 167, 2, 199, 230, 43, 132, 99, 159, 118, 141, 199, 226, 208, 134, 192),
          U1(114, 65, 237, 248, 9, 232, 250, 247)
        }))
        _ARG_0_:ClearAllInputState()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatAttached"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_1_) then
        if _ARG_1_.PlayerKey and slua.isValid(_ARG_1_.STCharacterMovement) and _ARG_1_.STCharacterMovement.ResolvePenetrationData then
          _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey] = _ARG_1_.STCharacterMovement.ResolvePenetrationData.ValidLocation
          _ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] = _ARG_0_:IsCharacterBlockFromValidLoc(_ARG_1_, _ARG_1_.STCharacterMovement.ResolvePenetrationData.ValidLocation)
        end
        EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_PLAYER_CHANGED, _ARG_0_.Object, _ARG_1_, true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCharacterBlockFromValidLoc"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) or _ARG_2_ == nil then
        return false
      end
      if slua.isValid((_ARG_0_:GetSeatComponent())) then
        goto lbl_100
        if slua.isValid(232) and 232 ~= _ARG_1_ then
        end
        ::lbl_100::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if U2.TraceBlock(_ARG_0_.Object, _ARG_2_, _ARG_1_:K2_GetActorLocation(), import((U1(49, 119, 174, 227, 14, 232, 251, 172, 102, 186, 25, 219, 184, 61, 214, 94, 135, 96, 239, 196, 228, 221, 147, 199)))(), slua.Array(UEnums.EPropertyClass.Object, (import((U1(49, 119, 174, 227, 14, 232, 251, 172, 102, 186, 25, 219, 184, 61, 214, 87, 141, 96, 210, 211))))), true).bBlockingHit then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnSeatDetachedBefore"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_1_) then
        _ARG_0_.DetachBeforeCharacterLocation = _ARG_1_:K2_GetActorLocation()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatDetached"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_1_) then
        EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_PLAYER_CHANGED, _ARG_0_.Object, _ARG_1_, false)
        if not _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey] then
          return
        end
        if _ARG_0_.DetachBeforeCharacterLocation == nil or _ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] == nil then
          return
        end
        if _ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] == true and FVector.Dist(_ARG_0_.DetachBeforeCharacterLocation, _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey]) < 800 then
        end
        if not (_ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] == true and FVector.Dist(_ARG_0_.DetachBeforeCharacterLocation, _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey]) < 800) and _ARG_0_:IsCharacterBlockFromValidLoc(_ARG_1_, _ARG_0_.DetachBeforeCharacterLocation) then
        end
        if _ARG_0_:IsCharacterBlockFromValidLoc(_ARG_1_, _ARG_0_.DetachBeforeCharacterLocation) then
          if _ARG_1_:FindActorLocationSafetyWithParams(FVector(0, 0, 0), _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey], (import((table.concat({
            U1(49, 119, 174, 227, 14, 232, 251, 172, 112, 188, 31, 214, 185, 47, 172, 100, 143, 119, 214, 196, 229, 237, 135, 199, 65, 165, 64, 240, 163, 59, 135, 106, 136, 97, 253, 212, 233, 221, 155, 209),
            U1(127, 80, 164, 254, 9, 200, 238, 241, 66, 185, 13)
          })))())) then
          else
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleHPPreChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if CGameMode and slua.isValid((_ARG_0_:GetCommonComponent())) and _ARG_2_ == _ARG_0_:GetCommonComponent():GetVehicleHPMax() then
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).VehicleShapeType = _ARG_0_.VehicleShapeType
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).FirstAttackedTime = U1.GetTimeSeconds(_ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleForbidEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if _ARG_4_ == _ENV(86, 77, 169, 244, 46, 246, 251, 230, 81, 181, 29, 198, 191, 46, 157, 67, 167) then
        _ARG_0_:ShowVehicleEnterButton(true)
        if U1.tonumber(_ARG_5_) == 1 then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerResetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_1_ == nil then
        _ARG_1_ = _ARG_0_.DefaultStartLocation
      end
      if _ARG_2_ == nil then
        _ARG_2_ = _ARG_0_.DefaultStartRotation
      end
      _ARG_0_:SetSimulatePhysics(false)
      if slua.isValid(_ARG_0_:GetProtectionComponent()) then
        _ARG_0_.ProtectionComponent:SetTickEnabled(false)
        _ARG_0_:AddTimer(0.1, function()
          ProtectionComponent:ResetValidTransform()
          ProtectionComponent:SetTickEnabled(true)
          return
        end)
      end
      if _ARG_3_ == true then
        _ARG_0_:ClientResetAdnSetToTransform(_ARG_1_, _ARG_2_)
        _ARG_0_:MulticastResetAdnSetToTransform(_ARG_1_, _ARG_2_)
      else
        _ARG_0_:ClientResetToTransform()
      end
      _ARG_0_:ServerResetToPosition(_ARG_1_, _ARG_2_, true)
      if slua.isValid(_ARG_0_.BallMovement) then
        _ARG_0_.BallMovement.CurrentRotationYaw = _ARG_2_.Yaw
        _ARG_0_.BallMovement.CameraRationYaw = _ARG_2_.Yaw
        _ARG_0_.BallMovement.STCameraRationYaw = _ARG_2_.Yaw
      end
      if slua.isValid(_ARG_0_:GetMotorbikeComponent()) then
        _ARG_0_:UnregisterComponentTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:UnregisterComponentWeakTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:AddTimer(0.1, function()
          _ENV:GetMesh():K2_GetComponentRotation().Roll = 0.0
          return
        end)
      end
      _ARG_0_:AddTimer(0.5, function()
        _ENV:SetSimulatePhysics(true)
        return
      end)
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 69, 139, 102, 203, 196, 229, 250, 154, 192, 86, 176, 58, 205, 146, 58, 137, 104, 141, 98, 194, 195, 234, 148, 207, 239),
        U1(113, 71, 172, 229, 14, 247, 225, 163, 30, 244)
      }) .. _ARG_1_:ToString() .. U1(50, 4, 159, 254, 19, 249, 251, 234, 76, 186, 94, 143, 246) .. _ARG_2_:ToString())
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerTeleportVehicleMaintainSpeed"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_:ServerResetToPosition(_ARG_1_, _ARG_2_, false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientTeleportVehicleMaintainSpeed"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientResetToTransform"] = function(_ARG_0_)
    do
      _ARG_0_:_ClientResetToTransform()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MulticastResetAdnSetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 91, 155, 120, 201, 200, 244, 201, 140, 199, 97, 161, 29, 199, 178, 9, 140, 104, 173, 97, 217, 229, 232, 236, 157, 194),
        U1(112, 87, 171, 254, 21, 245)
      }))
      if _ARG_2_ ~= nil and slua.isValid(_ARG_0_.BallMovement) then
        _ARG_0_.BallMovement.CurrentRotationYaw = _ARG_2_.Yaw
        _ARG_0_.BallMovement.CameraRationYaw = _ARG_2_.Yaw
        if _ARG_0_.BallMovement.ResetSimQuatFromRotator then
          _ARG_0_.BallMovement:ResetSimQuatFromRotator(_ARG_2_)
        end
        if _ARG_0_.DecorationCircle and slua.isValid(_ARG_0_.DecorationCircle.MeshComponent) then
          FRotator().Pitch = _ARG_0_.DecorationCircle.DefaultTransform:Rotator().Pitch + _ARG_2_.Pitch
          FRotator().Roll = _ARG_0_.DecorationCircle.DefaultTransform:Rotator().Roll + _ARG_2_.Roll
          FRotator().Yaw = _ARG_0_.DecorationCircle.DefaultTransform:Rotator().Yaw + _ARG_2_.Yaw
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientResetAdnSetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 130, 125, 216, 207, 227, 250, 154, 192, 86, 176, 47, 198, 168, 27, 141, 114, 170, 107, 249, 195, 230, 214, 156, 197),
        U1(113, 86, 160)
      }))
      _ARG_0_:_ClientResetToTransform(_ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClientResetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:StopVehicle()
      if slua.isValid(_ARG_0_:GetProtectionComponent()) then
        _ARG_0_.ProtectionComponent:SetTickEnabled(false)
        _ARG_0_:AddTimer(0.1, function()
          ProtectionComponent:ResetValidTransform()
          ProtectionComponent:SetTickEnabled(true)
          return
        end)
      end
      if _ARG_1_ ~= nil and _ARG_2_ ~= nil then
        _ARG_0_:K2_SetActorLocationAndRotation(_ARG_1_, _ARG_2_, false, nil, true)
      end
      if slua.isValid(_ARG_0_:GetMotorbikeComponent()) then
        _ARG_0_:UnregisterComponentTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:UnregisterComponentWeakTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:SetSimulatePhysics(false)
        _ARG_0_.bUseSyncAtClient = false
        _ARG_0_:AddTimer(0.1, function()
          _ENV:GetMesh():K2_GetComponentRotation().Roll = 0.0
          bUseSyncAtClient = true
          return
        end)
      end
      _ARG_0_:ResetVehicleSpringArm()
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 73, 173, 120, 212, 196, 249, 220, 173, 214, 64, 161, 26, 246, 169, 28, 154, 103, 144, 119, 203, 222, 245, 213, 195, 131),
        U1(82, 75, 174, 240, 19, 241, 224, 237, 3, 233, 94)
      }) .. _ARG_0_:K2_GetActorLocation():ToString() .. U1(50, 4, 159, 254, 19, 249, 251, 234, 76, 186, 94, 143, 246) .. _ARG_0_:K2_GetActorRotation():ToString())
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopVehicle"] = function(_ARG_0_)
    do
      if _ARG_0_:GetMoveComponent() then
      end
      if _ARG_0_.STReplicatedState then
        _ARG_0_.STReplicatedState.SteeringInput = 0
        _ARG_0_.STReplicatedState.ThrottleInput = 0
        _ARG_0_.STReplicatedState.BrakeInput = 127
        _ARG_0_.STReplicatedState.HandBrakeInput = 127
        _ARG_0_.STReplicatedState.CurrentGear = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetVehicleSpringArm"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetVehicleSpringArm())) then
        return
      end
      _ARG_0_:GetVehicleSpringArm().bUsePawnControlRotation = true
      _ARG_0_:GetVehicleSpringArm().SmartCamRotationExtra = FRotator(0, 0, 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerApplyVehicleImpulse"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 69, 139, 102, 203, 196, 229, 233, 143, 195, 95, 189, 56, 199, 174, 33, 139, 106, 155, 77, 192, 193, 242, 212, 156, 198),
        U1(50, 4, 132, 252, 23, 237, 227, 240, 70, 130, 27, 209, 162, 55, 138, 54, 211, 52)
      }) .. _ARG_1_:ToString())
      _ARG_0_:ApplyVehicleImpulse(_ARG_1_, true)
      _ARG_0_:ClientApplyVehicleImpulse(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientApplyVehicleImpulse"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 130, 125, 216, 207, 227, 233, 143, 195, 95, 189, 56, 199, 174, 33, 139, 106, 155, 77, 192, 193, 242, 212, 156, 198),
        U1(50, 4, 132, 252, 23, 237, 227, 240, 70, 130, 27, 209, 162, 55, 138, 54, 211, 52)
      }) .. _ARG_1_:ToString())
      _ARG_0_:ApplyVehicleImpulse(_ARG_1_, true)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecordVehicleTransfrom"] = function(_ARG_0_)
    do
      _ARG_0_.DefaultStartRotation = _ARG_0_:K2_GetActorRotation()
      _ARG_0_.DefaultStartLocation = _ARG_0_:K2_GetActorLocation()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreAttachBy"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not slua.isValid(_ARG_1_) or not slua.isValid(_ARG_2_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreAttachByCharacter"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not slua.isValid(_ARG_1_) or not slua.isValid(_ARG_2_) then
        return
      end
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      if _ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_) < 0 or _ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_) >= _ARG_0_:GetSeatComponent().Seats:Num() then
        return
      end
      if _ARG_3_ == _ARG_0_:GetSeatComponent().Seats:Get((_ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_))).VehicleWeaponSeatSocket then
        return
      end
      if _ARG_3_ ~= _ARG_0_:GetSeatComponent().Seats:Get((_ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_))).EnterVehicleSocket then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCurrentVehicleUseBetterAvatar"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_:GetAvatarComponent()) then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 157, 87, 200, 211, 229, 205, 145, 199, 101, 161, 6, 203, 165, 36, 141, 83, 141, 97, 239, 212, 243, 204, 138, 209),
          U1(95, 82, 172, 229, 6, 234, 175, 241, 70, 160, 11, 192, 184, 120, 158, 119, 130, 103, 216, 141, 183, 233, 137, 210, 71, 165, 28, 225, 169, 37, 152, 38, 151, 119, 141, 248, 233, 206, 142, 207),
          U1(119, 64)
        }))
        return false
      end
      if _ARG_0_.ClientUsedAvatarID and _ARG_0_.ClientUsedAvatarID ~= _ARG_0_:GetAvatarComponent():GetDefaultAvatarID() then
        if CDataTable.GetTableData(U1(92, 65, 185, 229, 2, 234, 217, 230, 75, 189, 29, 222, 179, 29, 158, 112, 139, 119, 201), _ARG_0_.ClientUsedAvatarID) then
          return true
        else
        end
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[192]
    end
  end,
  ["IsCurrentVehicleUseBetterAvataMusic"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return false
      end
      if not _ARG_1_ or _ARG_1_ == _ARG_0_:GetAvatarComponent():GetDefaultAvatarID() then
        return false
      end
      if not CDataTable.GetTableData(U1(92, 65, 185, 229, 2, 234, 217, 230, 75, 189, 29, 222, 179, 29, 158, 112, 139, 119, 201), _ARG_1_) or CDataTable.GetTableData(U1(92, 65, 185, 229, 2, 234, 217, 230, 75, 189, 29, 222, 179, 29, 158, 112, 139, 119, 201), _ARG_1_).VehicleMusic ~= 1 then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleMusicPlayState"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BPCanCharacterEnter"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid(_ARG_1_) and _ARG_1_.CanEnterVehicle then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 84, 190, 87, 220, 207, 212, 192, 158, 193, 82, 167, 26, 199, 180, 13, 134, 114, 155, 118, 141, 242, 230, 214, 170, 205),
          U1(106, 65, 191, 199, 2, 240, 230, 224, 79, 177)
        }))
        if not _ARG_1_:CanEnterVehicle(_ARG_0_) then
          print(bWriteLog and table.concat({
            U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 84, 190, 87, 220, 207, 212, 192, 158, 193, 82, 167, 26, 199, 180, 13, 134, 114, 155, 118, 141, 242, 230, 214, 170, 205),
            U1(106, 65, 191, 199, 2, 240, 230, 224, 79, 177, 94, 212, 183, 52, 139, 115)
          }))
          return false
        end
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsVaildToStopSkillWhenEnterVehicle"] = function(_ARG_0_, _ARG_1_)
    do
      if slua.isValid(_ARG_1_) and _ARG_1_:IsCastingSkillIDFix(1014711) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleCanExit"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.bCanVehicleExit = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShouldShowVehicleEnterUIToCharacher"] = function(_ARG_0_, _ARG_1_)
    do
      if slua.isValid(_ARG_1_) then
        if _ARG_1_.CanEnterVehicle and not _ARG_1_:CanEnterVehicle(_ARG_0_) then
          print(bWriteLog and table.concat({
            U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 69, 134, 123, 200, 205, 243, 251, 151, 220, 68, 146, 11, 202, 175, 43, 132, 99, 187, 106, 217, 212, 245, 237, 166, 247),
            U1(113, 103, 165, 240, 21, 249, 236, 235, 70, 166, 94, 241, 183, 54, 189, 120, 154, 113, 207, 247, 242, 192, 150, 208, 95, 161, 78, 196, 167, 36, 155, 99)
          }))
          return false
        end
        if slua.isValid(_ARG_1_) and slua.isValid((_ARG_0_:GetVehicleSeats())) then
          return _ARG_0_:GetVehicleSeats():IsSeatAvailableTeam(_ARG_1_)
        end
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDiedBoxAvatarID"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetDriver())) then
        return -1
      end
      do return (require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 98, 183, 10, 219, 160, 49, 140, 111, 192, 87, 210, 204, 250, 205, 141, 208, 90, 165, 2, 203, 188, 45, 198, 65, 159, 105, 200, 225, 235, 217, 150, 141),
        U1(72, 65, 165, 248, 4, 244, 234, 173, 117, 177, 22, 219, 181, 52, 157, 70, 130, 117, 201, 196, 219, 193, 156, 214, 93, 183, 11, 247, 178, 33, 132)
      }))).GetDiedBoxID(_ARG_0_:GetDriver().PlayerUID, (_ARG_0_:GetAvatarID()))) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDirverOrOwner"] = function(_ARG_0_)
    do
      if slua.isValid((_ARG_0_:GetDriver())) then
        return (_ARG_0_:GetDriver())
      end
      if _ARG_0_.Ownership and slua.isValid((Game:GetPlayerByPlayerKey(_ARG_0_.Ownership.BelongToPlayerKey))) then
        return (Game:GetPlayerByPlayerKey(_ARG_0_.Ownership.BelongToPlayerKey))
      end
      do return end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReActivateExhaustParticle"] = function(_ARG_0_)
    do
      if not _ARG_0_.bEnableUpdateExhuastEffectBP then
        _ARG_0_:LuaBroadcast((_ENV(81, 74, 136, 233, 15, 237, 238, 240, 87, 145, 24, 212, 179, 59, 140, 68, 139, 114, 207, 196, 228, 192)))
        return
      end
      if _ARG_0_.IsBoosting and not _ARG_0_:IsBoosting() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanActiveEffect"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == _ENV(91, 92, 165, 240, 18, 235, 251) and U1.Game:IsValid((_ARG_0_:GetAvatarComponent())) and _ARG_0_:GetAvatarComponent().VehicleAvatarHandle and _ARG_0_:GetAvatarComponent().VehicleAvatarHandle.bNeedHideExhaustWhenScope and U1.slua.isValid((U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter())) and U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter().IsLocalActuallyScopeIn then
        return false
      end
      if _ARG_1_ == _ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96) then
        if _ARG_0_.IsBoosting and not _ARG_0_:IsBoosting() then
          return false
        end
        if U1.slua.isValid(_ARG_0_.Mesh) and (not _ARG_0_.Mesh:GetAnimInstance() or not _ARG_0_.Mesh:GetAnimInstance().InLift) then
          return false
        end
      end
      do return true end
      do return end
      _ARG_1_ = _ENV[190]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnBoostingChanged"] = function(_ARG_0_)
    do
      _ARG_0_.Super:OnBoostingChanged()
      if _ARG_0_.IsBoosting and _ARG_0_:IsBoosting() then
        _ARG_0_:ActiveEffectAsync((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96)))
      else
        _ARG_0_:DeactiveEffect((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitOptimizeLeaveVehicle"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 128, 125, 201, 238, 231, 220, 150, 222, 90, 190, 11, 238, 163, 41, 158, 99, 168, 97, 197, 216, 228, 212, 138), _ARG_0_.Object)
      if not slua.isValid((_ARG_0_:GetSeatComponent())) or not _ARG_0_:GetSeatComponent().LeaveVehicleConfig then
        return
      end
      if require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 189, 107, 195, 215, 238, 223, 193, 239),
        U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)
      }))).GetConfig(_ARG_0_.VehicleShapeType) then
        goto lbl_200
        if slua.IndexReference(_ARG_0_:GetSeatComponent(), (U1(82, 65, 172, 231, 2, 206, 234, 235, 74, 183, 18, 215, 149, 55, 150, 112, 135, 115)))[U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)] ~= nil then
          slua.IndexReference(_ARG_0_:GetSeatComponent(), (U1(82, 65, 172, 231, 2, 206, 234, 235, 74, 183, 18, 215, 149, 55, 150, 112, 135, 115)))[U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)] = U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)
        end
        ::lbl_200::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegisterVehicleSkill"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.VehicleRegisterSkills[_ARG_1_] = _ARG_2_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurVehicleSkillBySkillID"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_.VehicleRegisterSkills[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleAccessorySlotConfig"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ or not _ARG_2_ then
        log(bWriteLog and table.concat({
          U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203),
          U1(119, 71, 161, 244, 38, 251, 236, 230, 80, 167, 17, 192, 175, 11, 148, 121, 154, 87, 210, 207, 241, 193, 152, 159, 19, 180, 15, 208, 167, 37, 200, 111, 141, 36, 195, 216, 235)
        }))
        return nil
      end
      log(bWriteLog and table.concat({
        U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203),
        U1(119, 71, 161, 244, 38, 251, 236, 230, 80, 167, 17, 192, 175, 11, 148, 121, 154, 87, 210, 207, 241, 193, 152, 159, 19, 170, 47, 212, 167, 60, 137, 116, 183, 64, 141, 140, 167)
      }) .. tostring(_ARG_1_) .. U1(62, 87, 161, 254, 19, 204, 246, 243, 70, 244, 67, 146) .. tostring(_ARG_2_))
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) or not _ARG_0_:GetAvatarComponent().GetItemAvatarHandle then
        return nil
      end
      if not slua.isValid((_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_))) then
        return nil
      end
      if not _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs or _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Num() == 0 then
        return nil
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203))) and _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203))).AccessorySlotName == _ARG_2_ then
        return (_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203))))
      end
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1[244]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHPBarShowName"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.VehicleHPBarName = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHPBarShowName"] = function(_ARG_0_)
    do
      if _ARG_0_.VehicleHPBarName and _ARG_0_.VehicleHPBarName ~= _ENV() then
        return _ARG_0_.VehicleHPBarName
      end
      _ARG_0_.VehicleHPBarName = U1.CDataTable.GetTableData(_ENV(87, 80, 168, 252), _ARG_0_.AvatarDefaultCfg.TypeSpecificID) and U1.CDataTable.GetTableData(_ENV(87, 80, 168, 252), _ARG_0_.AvatarDefaultCfg.TypeSpecificID).ItemName or _ENV()
      if U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))) and U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))).VehicleItemIDNameConfig and U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))).VehicleItemIDNameConfig[_ARG_0_.AvatarDefaultCfg.TypeSpecificID] then
        _ARG_0_.VehicleHPBarName = U1.LocUtil.GetLocalizeResStr(U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))).VehicleItemIDNameConfig[_ARG_0_.AvatarDefaultCfg.TypeSpecificID]) or _ARG_0_.VehicleHPBarName
      end
      do return _ARG_0_.VehicleHPBarName end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitVehicleDIYComponent"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 128, 125, 201, 247, 242, 192, 150, 208, 95, 161, 42, 235, 159, 11, 135, 107, 142, 107, 195, 212, 233, 204, 207, 205),
          U1(113, 80, 237, 199, 2, 240, 230, 224, 79, 177, 55, 246)
        }))
        return
      end
      if not CDataTable.GetTableData(U1(72, 65, 165, 248, 4, 244, 234, 199, 106, 141, 61, 212, 177), tonumber(_ARG_1_)) then
        if slua.isValid(_ARG_0_.BP_VehicleDIYComp) then
          _ARG_0_.BP_VehicleDIYComp = nil
        end
        return
      end
      if not slua.isValid(_ARG_0_.BP_VehicleDIYComp) then
        _ARG_0_.BP_VehicleDIYComp = Game:AddComponent(import((table.concat({
          U1(49, 99, 172, 252, 2, 183, 205, 239, 86, 177, 46, 192, 191, 54, 140, 101, 193, 85, 203, 192, 227, 201, 141, 247, 122, 157, 65, 224, 150, 23, 190, 99, 150, 109, 206, 221, 226, 252, 166, 250),
          U1(93, 75, 160, 225, 73, 218, 223, 220, 117, 177, 22, 219, 181, 52, 157, 82, 167, 77, 254, 206, 250, 216, 160, 240)
        }))), _ARG_0_, (U1(92, 116, 146, 199, 2, 240, 230, 224, 79, 177, 58, 251, 143, 27, 151, 123, 158)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartRecordDriveData"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      _ARG_0_.RecordCharacter = _ARG_1_
      if not _ARG_0_.UseTimer then
        _ARG_0_.DrivingDistance = 0
        _ARG_0_.LastLocation = _ARG_0_:K2_GetActorLocation()
        _ARG_0_.UseTimer = _ARG_0_:AddGameTimer(0.1, true, function()
          if slua.isValid(U1.Object) and U1.LastLocation then
            U1.DrivingDistance = U1.DrivingDistance + U2.VSize(U1:K2_GetActorLocation() - U1.LastLocation) / 100
            U1.LastLocation = U1:K2_GetActorLocation()
          end
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EndRecordDriveData"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_0_.DriverDistanceTLogID then
        return
      end
      if _ARG_0_.RecordCharacter ~= _ARG_1_ then
        return
      end
      _ARG_0_.RecordCharacter = nil
      _ARG_0_:RemoveGameTimer(_ARG_0_.UseTimer)
      _ARG_0_.UseTimer = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecordVehicleTlog"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_0_.EnterCountTlogID then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanBeCatched"] = function(_ARG_0_, _ARG_1_)
    do
      do return (_ARG_0_.UltraHandBeCatchedFeature:CanBeCatched(_ARG_1_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleProtectionStuckInternal"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.VehicleProtectionInternalTimer ~= nil and _ARG_0_.VehicleProtectionInternalTimer > 0 then
        _ARG_0_:RemoveGameTimer(_ARG_0_.VehicleProtectionInternalTimer)
      end
      if _ARG_0_:GetProtectionComponent() and slua.isValid((_ARG_0_:GetProtectionComponent())) then
        _ARG_0_:GetProtectionComponent().CheckStuckInterval = _ARG_1_
        _ARG_0_:GetProtectionComponent().StuckDuration = _ARG_2_
        _ARG_0_.VehicleProtectionInternalTimer = _ARG_0_:AddGameTimer(_ARG_3_, false, function()
          if _ENV and U1.slua.isValid(_ENV) then
            CheckStuckInterval = U1.slua.isValid(_ENV)
            StuckDuration = U1.slua.isValid(_ENV)
          end
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshVehiclePassengersParticle"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 68, 139, 114, 207, 196, 228, 192, 169, 214, 91, 173, 13, 206, 163, 24, 137, 117, 141, 97, 195, 214, 226, 202, 156, 243),
        U1(127, 86, 185, 248, 4, 244, 234)
      }))
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      goto lbl_262
      ::lbl_262::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandlePlayerAttachedToVehcicle"] = function(_ARG_0_, _ARG_1_)
    do
      if Client and slua.isValid(_ARG_1_) and _ARG_1_.CheckAttachedOrDetachedVehicle then
        _ARG_1_:CheckAttachedOrDetachedVehicle(true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_BlockForwardInput"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 234, 147, 220, 80, 175, 40, 205, 180, 63, 137, 116, 154, 77, 195, 193, 242, 204))
      if _ARG_0_.Super.OnRep_BlockForwardInput then
        _ARG_0_.Super:OnRep_BlockForwardInput()
      end
      if slua.isValid((require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter())) and require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter().GetCurrentVehicle and slua.isValid(require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter():GetCurrentVehicle()) and require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter():GetCurrentVehicle() == _ARG_0_.Object then
        if Game:IsClassOf(_ARG_0_.Object, import((U1(92, 77, 162, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61)))) or Game:IsClassOf(_ARG_0_.Object, import((U1(72, 65, 165, 248, 4, 244, 234, 193, 74, 191, 27)))) or Game:IsClassOf(_ARG_0_.Object, import((U1(72, 65, 165, 248, 4, 244, 234, 206, 76, 160, 17, 192, 145, 52, 145, 114, 139, 102)))) then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMeshPhysicsCreateExt"] = function(_ARG_0_)
    do
      _ARG_0_:LuaBroadcast(_ARG_0_.OnMeshPhysicsCreateDelegate)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FellOutOfWorldExt"] = function(_ARG_0_, _ARG_1_)
    do
      if Client and Client.IsDevelopment() and not (slua.isValid((import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance())) and import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance():IsPlayingAnyPlayback()) and slua.isValid(CGameState) and CGameState:GetGameModeState() ~= U1(88, 77, 163, 248, 20, 240, 234, 231, 112, 160, 31, 198, 179) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OutsideWorldBoundsExt"] = function(_ARG_0_, _ARG_1_)
    do
      if Client and Client.IsDevelopment() and not (slua.isValid((import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance())) and import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance():IsPlayingAnyPlayback()) and slua.isValid(CGameState) and CGameState:GetGameModeState() ~= U1(88, 77, 163, 248, 20, 240, 234, 231, 112, 160, 31, 198, 179) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["NeedCreateShootDriverComp"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 189, 107, 195, 215, 238, 223, 193, 245),
        U1(123, 76, 164, 242, 11, 253, 220, 235, 76, 187, 10, 246, 164, 49, 142, 115, 156, 87, 210, 207, 241, 193, 152)
      }))) and require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 189, 107, 195, 215, 238, 223, 193, 245),
        U1(123, 76, 164, 242, 11, 253, 220, 235, 76, 187, 10, 246, 164, 49, 142, 115, 156, 87, 210, 207, 241, 193, 152)
      }))).GetCfg(_ARG_0_.Object) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSocialIslandVehicle"] = function(_ARG_0_)
    do
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaShouldLeaveFitCloseToGround"] = function(_ARG_0_)
    do
      if _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_UH60 or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_HeavyUH60 or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_Motorglider or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_WingMan or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_Fighter or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_Aircraft then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBornIslandVehicle"] = function(_ARG_0_)
    do
      do return _ARG_0_.bIsBornIslandVehicle end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}).MulticastRPC.MulticastResetAdnSetToTransform = {
  Reliable = true,
  Params = {
    import(((function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(49, 119, 174, 227, 14, 232, 251, 172, 96, 187, 12, 215, 131, 23, 154, 124, 139, 119, 201, 143, 193, 205, 156, 199, 92, 182))),
    import(((function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(49, 119, 174, 227, 14, 232, 251, 172, 96, 187, 12, 215, 131, 23, 154, 124, 139, 119, 201, 143, 197, 199, 139, 210, 71, 171, 28)))
  }
}
;({
  ServerRPC = {},
  ClientRPC = {},
  MulticastRPC = {},
  LuaEventContainer = {
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 128, 244, 20, 240, 223, 235, 90, 167, 23, 209, 165, 27, 138, 115, 143, 96, 216),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(72, 65, 165, 248, 4, 244, 234, 208, 72, 189, 18, 222, 147, 54, 157, 100, 137, 109, 254, 201, 246, 198, 152, 214, 87),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(72, 65, 165, 248, 4, 244, 234, 198, 77, 176, 46, 222, 183, 33, 189, 96, 139, 122, 201),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 152, 226, 2, 213, 224, 247, 76, 166, 63, 199, 178, 49, 151),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 136, 233, 15, 237, 238, 240, 87, 145, 24, 212, 179, 59, 140, 68, 139, 114, 207, 196, 228, 192),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 142, 249, 6, 246, 232, 230, 112, 177, 31, 198),
    ((function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 136, 233, 14, 236, 217, 230, 75, 189, 29, 222, 179))
  },
  ["ctor"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.SeatComponent = nil
      _ARG_0_.AvatarComponent = nil
      _ARG_0_.AdvanceAvatarComponent = nil
      _ARG_0_.BP_VehicleDIYComp = nil
      _ARG_0_.ClientUsedAvatarID = 0
      _ARG_0_.CommonComponent = nil
      _ARG_0_.SpringArm = nil
      _ARG_0_.LastOccupiers = {}
      _ARG_0_.AttachedCharacterLocation = {}
      _ARG_0_.AttachedCharacterBlock = {}
      _ARG_0_.OnMeshPhysicsCreateDelegate = _ENV(81, 74, 128, 244, 20, 240, 223, 235, 90, 167, 23, 209, 165, 27, 138, 115, 143, 96, 216)
      _ARG_0_.bCanVehicleExit = true
      _ARG_0_.VehicleRegisterSkills = {}
      _ARG_0_.VehicleProtectionInternalTimer = nil
      _ARG_0_.OriginalCheckStuckInterval = 1
      _ARG_0_.OriginalStuckDuration = 5
      _ARG_0_.UseTimer = nil
      _ARG_0_.DrivingDistance = 0
      _ARG_0_.RecordCharacter = nil
      _ARG_0_.bIsBornIslandVehicle = false
      _ARG_0_.bUGCSkillAirDrop = false
      _ARG_0_.WeddingCarIndex = 0
      _ARG_0_.PassengerEnterShowTextID = nil
      _ARG_0_.PassengerEnterShowIconPath = nil
      _ARG_0_.DriverEnterShowTextID = nil
      _ARG_0_.DriverEnterShowIconPath = nil
      _ARG_0_.LeaveVehicleTextID = nil
      _ARG_0_.LeaveVehicleIconPath = nil
      _ARG_0_.VehicleHPBarName = _ENV()
      _ARG_0_.bUGCInstance = false
      _ARG_0_.UGCInstanceId = 0
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PostConstruct"] = function(_ARG_0_)
    do
      __super._PostConstruct(_ARG_0_)
      _ARG_0_:InitConfig()
      if U1.Client then
        _ARG_0_:AddCommonEvent(U1.EVENTTYPE_INGAME_NORMAL, U1.EVENTID_SEQUENCE_MSG, _ARG_0_.HandleForbidEnterVehicle, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 142, 253, 14, 253, 225, 247, 102, 186, 10, 215, 164, 14, 157, 126, 135, 119, 209, 196, 210, 222, 154, 221, 71), _ARG_0_.ClientHandleEnterVehicle, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 142, 253, 14, 253, 225, 247, 102, 172, 23, 198, 128, 61, 144, 127, 141, 120, 216, 228, 225, 205, 145, 199), _ARG_0_.ClientHandleExitVehicle, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 142, 253, 14, 253, 225, 247, 96, 188, 31, 220, 177, 61, 174, 115, 134, 125, 222, 205, 242, 251, 154, 210, 71, 129, 24, 199, 168, 60), _ARG_0_.ClientHandleChangeVehicleSeat, _ARG_0_)
      else
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 136, 255, 19, 253, 253, 213, 70, 188, 23, 209, 186, 61), _ARG_0_.ServerHandleEnterVehicleResult, _ARG_0_)
      end
      _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 155, 244, 15, 241, 236, 239, 70, 156, 27, 211, 186, 44, 144, 69, 154, 117, 201, 196, 212, 192, 158, 221, 84, 161, 10), _ARG_0_.LuaHandleHealthStateChanged, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 155, 244, 15, 241, 236, 239, 70, 156, 27, 211, 186, 44, 144, 82, 139, 103, 201, 211, 248, 209), _ARG_0_.LuaHandleVehicleHealthDestroy, _ARG_0_)
      if U1.slua.isValid((_ARG_0_:GetAvatarComponent())) then
        _ARG_0_.ClientUsedAvatarID = _ARG_0_:GetAvatarComponent():GetDefaultAvatarID()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PreDestruct"] = function(_ARG_0_)
    do
      if _ARG_0_.Features then
        goto lbl_37
        ::lbl_37::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.VehicleFeatures then
        goto lbl_56
        ::lbl_56::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _ARG_0_.VehicleFeatures = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLifetimeReplicatedProps"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 81, 139, 96, 241, 200, 241, 205, 139, 218, 94, 161, 60, 199, 182, 36, 129, 101, 159, 112, 200, 213, 215, 202, 128, 211),
        U1(109)
      }))
      do return {
        {
          U1(124, 113, 138, 210, 52, 243, 230, 239, 79, 149, 23, 192, 146, 42, 151, 102),
          import((U1(91, 104, 164, 247, 2, 236, 230, 238, 70, 151, 17, 220, 178, 49, 140, 127, 129, 122))).COND_None,
          UEnums.EPropertyClass.Bool
        },
        {
          U1(73, 65, 169, 245, 14, 246, 232, 192, 66, 166, 55, 220, 178, 61, 128),
          import((U1(91, 104, 164, 247, 2, 236, 230, 238, 70, 151, 17, 220, 178, 49, 140, 127, 129, 122))).COND_None,
          UEnums.EPropertyClass.Int
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_bUGCSkillAirDrop"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 202, 170, 244, 112, 151, 5, 203, 170, 36, 169, 111, 140, 64, 223, 222, 247, 148, 207, 236),
        U1(114, 64, 155, 240, 11, 237, 234)
      }) .. tostring(_ARG_1_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_WeddingCarIndex"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 255, 154, 215, 87, 173, 0, 197, 133, 41, 154, 79, 144, 96, 200, 201, 171, 152, 160, 207),
        U1(122, 114, 172, 253, 18, 253)
      }) .. tostring(_ARG_1_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientDriverChangeEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid(_ARG_2_) and _ARG_2_:IsLocallyControlled() and Game:IsValid(_ARG_0_:GetVehicleSpringArm()) and _ARG_0_:GetVehicleSpringArm().bForceInitCameraLagWhenDriverGetOn then
        _ARG_0_:GetVehicleSpringArm().bDoLocationLagInit = false
      end
      _ARG_0_.bBaseAutoMoveForward = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnPlayerCannotExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_0_.uLastCannotExitLocation ~= nil and FVector.Distance(_ARG_0_:K2_GetActorLocation(), _ARG_0_.uLastCannotExitLocation) < 100 then
        return
      end
      _ARG_0_.uLastCannotExitLocation = _ARG_0_:K2_GetActorLocation()
      if 100 < _ARG_0_:GetForwardSpeed() then
        return
      end
      do return end
      _ARG_0_ = _ENV[140]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitConfig"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 128, 125, 201, 226, 248, 198, 153, 218, 84), _ARG_0_.Object)
      if require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 168, 97, 197, 216, 228, 212, 138, 224),
        U1(113, 74, 171, 248, 0)
      }))).GenConfig(_ARG_0_.Object, _ARG_0_.VehicleShapeType) and next((require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 168, 97, 197, 216, 228, 212, 138, 224),
        U1(113, 74, 171, 248, 0)
      }))).GenConfig(_ARG_0_.Object, _ARG_0_.VehicleShapeType))) then
        goto lbl_106
        _ARG_0_[U1(113, 74, 171, 248, 0)] = U1(113, 74, 171, 248, 0)
        ::lbl_106::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleControlUIConfig"] = function(_ARG_0_)
    do
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUIConfig"] = function(_ARG_0_)
    do
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitComponents"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_23
      ::lbl_23::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitComponentAttributes"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_18
      ::lbl_18::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitVehicleFeatures"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_19
      ::lbl_19::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_76
      if slua.IsLuaModuleExists(table.unpack(_ARG_1_[226])) then
        if table.unpack(_ARG_1_[226]) and next(table.unpack(_ARG_1_[226])) then
          goto lbl_68
          require(table.unpack(_ARG_1_[226]))(_ARG_0_.Object)[nil] = nil
          ::lbl_68::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      ::lbl_76::
      _ARG_0_ = _ARG_0_
      _ARG_0_.VehicleFeatures, _ARG_0_ = {
        [226] = require(table.unpack(_ARG_1_[226]))(_ARG_0_.Object)
      }, _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitCustomConfigs"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      _ARG_0_.VehicleCustomConfigs = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearVehicleFeatures"] = function(_ARG_0_)
    do
      if _ARG_0_.VehicleFeatures and next(_ARG_0_.VehicleFeatures) then
        goto lbl_20
        ::lbl_20::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _ARG_0_.VehicleFeatures = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CallFunction"] = function(_ARG_0_, _ARG_1_, _ARG_2_, ...)
    do
      if _ARG_0_[_ARG_1_] then
        if slua.isValid(_ARG_0_[_ARG_1_]) and _ARG_0_[_ARG_1_][_ARG_2_] then
          return _ARG_0_[_ARG_1_][_ARG_2_](_ARG_0_[_ARG_1_], ...)
        end
      else
        _ARG_0_.FunctionCache = _ARG_0_.FunctionCache or {}
        if _ARG_0_.FunctionCache then
          _ARG_0_.FunctionCache[_ARG_1_] = _ARG_0_.FunctionCache[_ARG_1_] or {}
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ExecuteFunctions"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.FunctionCache or not _ARG_0_.FunctionCache[_ARG_1_] then
        return
      end
      goto lbl_23
      ::lbl_23::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveBeginPlay"] = function(_ARG_0_)
    do
      __super.ReceiveBeginPlay(_ARG_0_)
      _ARG_0_:InitOptimizeLeaveVehicle()
      if U1.SubsystemMgr:Get((U2(72, 65, 165, 248, 4, 244, 234, 208, 86, 182, 13, 203, 165, 44, 157, 123))) then
      end
      if U1.Client then
        if U1.slua.isValid((_ARG_0_:GetAdvanceAvatarComponent())) then
        end
      else
        _ARG_0_.bSkipComparePropertiesForReplay = true
        if _ARG_0_:GetProtectionComponent() and U1.slua.isValid((_ARG_0_:GetProtectionComponent())) then
          _ARG_0_.OriginalCheckStuckInterval = _ARG_0_:GetProtectionComponent().CheckStuckInterval
          _ARG_0_.OriginalStuckDuration = _ARG_0_:GetProtectionComponent().StuckDuration
        end
        if U1.slua.isValid(_ARG_0_.VehicleMovement) and _ARG_0_.VehicleMovement.DriftSetup then
          _ARG_0_.VehicleMovement.DriftSetup.MaxOmega = 360
        end
        if U1.slua.isValid((_ARG_0_:GetVehicleSync())) then
          _ARG_0_:GetVehicleSync().VehicleHitRewindThreshold.ValidDeltaSeconds = 0.35
        end
      end
      _ARG_0_.DefaultStartLocation = _ARG_0_:K2_GetActorLocation()
      _ARG_0_.DefaultStartRotation = _ARG_0_:K2_GetActorRotation()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AfterBeginPlay"] = function(_ARG_0_)
    do
      if _ARG_0_.Super.AfterBeginPlay then
        _ARG_0_.Super:AfterBeginPlay()
      end
      if slua.isValid(_ARG_0_.VehicleShootAntiCheat) then
        _ARG_0_.VehicleShootAntiCheat.BoundBoxExtendMoveTime = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetShootVertifyHitBoxScale"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return FVector(2, 2, 2) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerHandleEnterVehicleResult"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_2_ == U1.ESeatType_DriversSeat and slua.isValid(_ARG_0_:GetVehicleSpringArm()) then
        _ARG_0_:GetVehicleSpringArm().bDoCollisionTest = true
      end
      _ARG_1_.ClientSidePoseState = import((U2(91, 119, 153, 212, 55, 247, 252, 230, 112, 160, 31, 198, 179))).Stand
      if slua.isValid((_ARG_1_:GetThirdPersonSpringArm())) then
        _ARG_1_:GetThirdPersonSpringArm().bDoCollisionTest = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      _ARG_1_.ClientSidePoseState = import((U1(91, 119, 153, 212, 55, 247, 252, 230, 112, 160, 31, 198, 179))).Stand
      if Game:IsBioVehicle(_ARG_0_.Object) then
        if slua.isValid(_ARG_0_.CapsuleComponent) and _ARG_0_.CapsuleComponent:ComponentHasTag((U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157))) then
          _ARG_0_ = _ARG_0_
          if _ARG_0_.CapsuleComponent.ComponentTags:Get(81) == U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157) then
          else
            _ARG_0_ = _ARG_0_
          end
          if 81 >= 0 then
          end
        end
        if slua.isValid(_ARG_0_.HeadCapsuleComponent) and _ARG_0_.HeadCapsuleComponent:ComponentHasTag((U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157))) then
          _ARG_0_ = _ARG_0_
          if _ARG_0_.HeadCapsuleComponent.ComponentTags:Get(81) == U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157) then
          else
            _ARG_0_ = _ARG_0_
          end
          if 81 >= 0 then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleChangeVehicleSeat"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEndChangeVehicleItemAvatar"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 81, 211, 197, 212, 192, 158, 221, 84, 161, 56, 199, 174, 33, 139, 106, 155, 77, 217, 212, 234, 249, 153, 194),
        U1(106, 69, 191)
      }))
      _ARG_0_:CheckAvatarDormant()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAvatarDormant"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SpawnBoxComponent"] = function(_ARG_0_)
    do
      if not _ARG_0_:HasAuthority() then
        return
      end
      if import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))) == nil then
        return
      end
      if not Game:IsValid((Game:AddComponent(import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))), _ARG_0_, (U1(90, 65, 172, 245, 49, 253, 231, 234, 64, 184, 27, 240, 185, 32))))) then
        return
      end
      if not Game:AddComponent(import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))), _ARG_0_, (U1(90, 65, 172, 245, 49, 253, 231, 234, 64, 184, 27, 240, 185, 32))):K2_AttachToComponent(_ARG_0_.Mesh, U1(80, 75, 163, 244), import((U1(91, 101, 185, 229, 6, 251, 231, 238, 70, 186, 10, 224, 163, 52, 157))).KeepRelative, import((U1(91, 101, 185, 229, 6, 251, 231, 238, 70, 186, 10, 224, 163, 52, 157))).KeepRelative, import((U1(91, 101, 185, 229, 6, 251, 231, 238, 70, 186, 10, 224, 163, 52, 157))).KeepRelative, false) then
        return
      end
      Game:AddComponent(import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))), _ARG_0_, (U1(90, 65, 172, 245, 49, 253, 231, 234, 64, 184, 27, 240, 185, 32))).bGenerateOverlapEvents = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BPGetQueryIgnoreActors"] = function(_ARG_0_)
    do
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenPhysicForAMoment"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:HasAuthority() then
        return
      end
      if _ARG_0_:IsSimulatePhysics() then
        return
      end
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 158, 113, 211, 241, 255, 209, 140, 218, 80, 130, 1, 208, 135, 5, 135, 107, 155, 106, 217), _ARG_0_.Role)
      _ARG_0_:SetSimulatePhysics(true)
      if _ARG_0_.PhysicTimer ~= nil then
        Game:ClearTimer(_ARG_0_.PhysicTimer)
        _ARG_0_.PhysicTimer = nil
      end
      _ARG_0_.PhysicTimer = Game:SetTimer(_ARG_1_, false, function()
        _ENV:SetSimulatePhysics(false)
        U1.Game:ClearTimer(PhysicTimer)
        PhysicTimer = nil
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveEndPlay"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.PhysicTimer ~= nil then
        Game:ClearTimer(_ARG_0_.PhysicTimer)
        _ARG_0_.PhysicTimer = nil
      end
      _ARG_0_.bIsDeformed = false
      _ARG_0_.VehicleRegisterSkills = {}
      EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_ENDPLAY, _ARG_0_.Object)
      _ARG_0_:ClearVehicleFeatures()
      if _ARG_0_.LuaBroadcast then
        _ARG_0_:LuaBroadcast((U1(72, 65, 165, 248, 4, 244, 234, 198, 77, 176, 46, 222, 183, 33, 189, 96, 139, 122, 201)))
      end
      _ARG_0_.Super:ReceiveEndPlay(_ARG_1_)
      U2.__super.ReceiveEndPlay(_ARG_0_, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMoveComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.MoveComponent) then
        _ARG_0_.MoveComponent = _ARG_0_:GetComponentByClass((import((U1(77, 112, 136, 233, 19, 234, 238, 213, 70, 188, 23, 209, 186, 61, 181, 121, 152, 113, 208, 196, 249, 220, 188, 220, 94, 180, 1, 204, 163, 38, 156, 50, 169)))))
      end
      do return _ARG_0_.MoveComponent end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCommonComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.CommonComponent) then
        _ARG_0_.CommonComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 192, 76, 185, 19, 221, 184, 27, 151, 123, 158, 123, 211, 196, 249, 220)))))
      end
      do return _ARG_0_.CommonComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSeatComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.SeatComponent) and slua.isValid(_ARG_0_.Object) then
        _ARG_0_.SeatComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 208, 70, 181, 10, 241, 185, 53, 136, 121, 128, 113, 211, 213)))))
      end
      do return _ARG_0_.SeatComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAvatarComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.AvatarComponent) then
        _ARG_0_.AvatarComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 194, 85, 181, 10, 211, 164, 27, 151, 123, 158, 123, 211, 196, 249, 220)))))
      end
      do return _ARG_0_.AvatarComponent end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAdvanceAvatarComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.AdvanceAvatarComponent) then
        _ARG_0_.AdvanceAvatarComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 194, 71, 162, 31, 220, 181, 61, 185, 96, 143, 96, 220, 211, 212, 199, 146, 195, 92, 170, 11, 204, 178)))))
      end
      do return _ARG_0_.AdvanceAvatarComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetProtectionComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.ProtectionComponent) then
        _ARG_0_.ProtectionComponent = _ARG_0_:GetComponentByClass((import((U1(73, 76, 168, 244, 11, 253, 235, 213, 70, 188, 23, 209, 186, 61, 168, 100, 129, 96, 216, 194, 227, 193, 144, 221, 112, 171, 3, 210, 169, 38, 141, 104, 138)))))
      end
      do return _ARG_0_.ProtectionComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMotorbikeComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.MotorbikeComponent) then
        _ARG_0_.MotorbikeComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 206, 76, 160, 17, 192, 180, 49, 147, 115, 173, 123, 208, 209, 248, 198, 154, 221, 71)))))
      end
      do return _ARG_0_.MotorbikeComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMusicComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.MusicComponent) then
        _ARG_0_.MusicComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 206, 86, 167, 23, 209, 149, 55, 149, 102, 129, 122, 216, 207, 227)))))
      end
      do return _ARG_0_.MusicComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBuffComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.BuffSystemComp) then
        _ARG_0_.BuffSystemComp = _ARG_0_:GetComponentByClass((import((U1(77, 112, 143, 228, 1, 254, 220, 250, 80, 160, 27, 223, 149, 55, 149, 102, 129, 122, 216, 207, 227)))))
      end
      do return _ARG_0_.BuffSystemComp end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAccelerationComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.AccelerateComponent) then
        _ARG_0_.AccelerateComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 194, 64, 183, 27, 222, 179, 42, 153, 98, 139, 87, 210, 204, 231, 199, 145, 214, 93, 176)))))
      end
      do return _ARG_0_.AccelerateComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPickupComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehiclePickableComponent) then
        _ARG_0_.VehiclePickableComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 211, 74, 183, 21, 211, 180, 52, 157, 85, 129, 121, 205, 206, 249, 205, 145, 199)))))
      end
      do return _ARG_0_.VehiclePickableComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLicenseComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehicleLicenseComponent) then
        _ARG_0_.VehicleLicenseComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 207, 74, 183, 27, 220, 165, 61, 182, 99, 131, 118, 216, 211, 212, 199, 146, 195, 92, 170, 11, 204, 178)))))
      end
      do return _ARG_0_.VehicleLicenseComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleCabrioletComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehicleCabrioletComponent) then
        _ARG_0_.VehicleCabrioletComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 192, 66, 182, 12, 219, 185, 52, 157, 98, 173, 123, 208, 209, 248, 198, 154, 221, 71)))))
      end
      do return _ARG_0_.VehicleCabrioletComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddDynamicComponentLoadCompletedCallbacks"] = function(_ARG_0_, _ARG_1_, ...)
    do
      if _ARG_0_:DynamicComponentAllLoadCompleted() then
      elseif _ARG_0_.DynamicComponentLoadCompletedCallbacks == nil then
        _ARG_0_.DynamicComponentLoadCompletedCallbacks = {}
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ForceExitCharacters"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:HasAuthority() then
        if not slua.isValid((_ARG_0_:GetSeatComponent())) then
          return
        end
        goto lbl_128
        if slua.isValid(nil) then
          if _ARG_1_ == true then
            if slua.isValid(((nil):GetWeaponManager())) and (nil):GetWeaponManager():GetAllInventoryWeaponList(false) then
              goto lbl_126
              ::lbl_126::
              _ARG_0_ = _ARG_0_
              _ARG_0_ = _ARG_0_
            end
          end
        end
        ::lbl_128::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleDriverChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 236, 141, 218, 69, 161, 28, 225, 174, 41, 134, 97, 155, 96))
      _ARG_0_:ResetCandidateAvatarID(_ARG_2_)
      if CGameMode and not CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).Drived then
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).VehicleShapeType = _ARG_0_.VehicleShapeType
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).Drived = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatOccupiersChanged"] = function(_ARG_0_)
    do
      EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_SEAT_OCCUPIERS_CHANGED, _ARG_0_.Object)
      if slua.isValid((_ARG_0_:GetSeatComponent())) then
        if _ARG_0_.LastOccupiers and next(_ARG_0_.LastOccupiers) then
          goto lbl_36
          if slua.isValid(nil) then
          end
          ::lbl_36::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          goto lbl_71
          if slua.isValid(229) and not ({
            [nil] = true
          })[229] then
          end
          ::lbl_71::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if Client and not Client.IsEnableDSGrayPublishFlag(2199023255552) and not Client.IsEditor() and slua.isValid(_ARG_0_.Object) and not _ARG_0_.IsUnmannedVehicle and slua.isValid((_ARG_0_:GetSeatComponent())) then
          goto lbl_274
          if slua.isValid(229) and slua.isValid((229):GetCurrentVehicle()) and slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle()) then
          end
          ::lbl_274::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          goto lbl_461
          if slua.isValid(slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())) and not slua.isValid((slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetCurrentVehicle()) and slua.isValid(((slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetPlayerControllerSafety():GetVehicleUserComp())) and slua.isValid((slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle()) and slua.isValid((_ARG_0_:GetMesh())) and 229 >= 0 and 229 < _ARG_0_:GetSeatComponent().Seats:Num() then
            FVector(0, 0, 0).Z = (slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetSimpleCollisionHalfHeightInStandPose()
          end
          ::lbl_461::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if slua.isValid((_ARG_0_:GetSeatComponent())) then
          goto lbl_647
          ::lbl_647::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      _ARG_0_.LastOccupiers = {}
      goto lbl_663
      _ARG_0_.LastOccupiers[pairs(_ARG_0_:GetSeatComponent().SeatOccupiers)] = U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 210, 71, 139, 13, 193, 179, 56, 129, 99, 140, 119, 238, 217, 230, 214, 136, 198), slua.isValid((U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 210, 71, 139, 13, 193, 179, 56, 129, 99, 140, 119, 238, 217, 230, 214, 136, 198))) and _ARG_0_.LastOccupiers
      ::lbl_663::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetCandidateAvatarID"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(76, 65, 190, 244, 19, 219, 238, 237, 71, 189, 26, 211, 162, 61, 185, 96, 143, 96, 220, 211, 222, 236), _ARG_1_)
      if _ARG_0_:HasAuthority() and not slua.isValid(_ARG_1_) then
        _ARG_0_.CandidateAvatarID = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSeatAvailable"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid((_ARG_0_:GetSeatComponent())) then
        return _ARG_0_:GetSeatComponent():IsSeatIndexAvailable(_ARG_1_)
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayerEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 68, 209, 192, 238, 205, 141, 246, 93, 176, 11, 208, 144, 45, 128, 111, 157, 104, 200), _ARG_1_, _ARG_2_, _ARG_0_.bSkipComparePropertiesForReplay)
      if not Client then
        _ARG_0_.bSkipComparePropertiesForReplay = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayerExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 68, 209, 192, 238, 205, 141, 246, 75, 173, 26, 244, 163, 32, 129, 101, 146, 97), _ARG_1_, _ARG_2_, _ARG_3_, _ARG_0_.bSkipComparePropertiesForReplay)
      if not Client and _ARG_1_ then
        _ARG_0_.bSkipComparePropertiesForReplay = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleServerAvatarEquiped"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 193, 69, 161, 28, 227, 176, 41, 156, 103, 140, 65, 220, 196, 238, 200, 138, 199))
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleVehicleLoadedFPPMesh"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 64, 139, 124, 212, 194, 251, 205, 179, 220, 82, 160, 11, 198, 128, 24, 184, 75, 155, 119, 197))
      _ARG_0_:HandleClientAvatarEquiped()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientAvatarEquiped"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 147, 218, 86, 170, 26, 227, 176, 41, 156, 103, 140, 65, 220, 196, 238, 200, 138, 199))
      if slua.isValid((_ARG_0_:GetAvatarComponent())) then
        if _ARG_0_:GetAvatarComponent():GetCurrentAvatarID() == _ARG_0_.ClientUsedAvatarID then
          return
        end
        _ARG_0_.ClientUsedAvatarID = _ARG_0_:GetAvatarComponent():GetCurrentAvatarID()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientVehicleSwitchEffectEnd"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 147, 218, 86, 170, 26, 244, 163, 32, 129, 101, 146, 97, 254, 198, 238, 204, 140, 203),
        U1(91, 66, 171, 244, 4, 236, 202, 237, 71)
      }))
      _ARG_0_:InitVehicleDIYComponent(_ARG_0_.ClientUsedAvatarID)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientVehicleSlotEquiped"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      if _ARG_0_:GetAvatarComponent().NetHighTireStruct and _ARG_0_:GetAvatarComponent().NetHighTireStruct.bEnableHighTire ~= nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeactiveSkinSpecialEffect"] = function(_ARG_0_)
    do
      _ARG_0_:DeactiveEffect((_ENV(91, 92, 165, 240, 18, 235, 251)))
      _ARG_0_:DeactiveEffect((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222)))
      _ARG_0_:DeactiveEffect((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96)))
      _ARG_0_:DeactiveEffect((_ENV(77, 80, 172, 227, 19, 205, 255, 197, 123)))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleAdvanceAvatarEquipped"] = function(_ARG_0_)
    do
      if _ARG_0_:HasAuthority() then
        _ARG_0_:HandleServerAdvanceAvatarEquipped()
      else
        _ARG_0_:HandleClientAdvanceAvatarEquipped()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAndSetStartUpEffect"] = function(_ARG_0_, _ARG_1_)
    do
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleServerAdvanceAvatarEquipped"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 193, 69, 161, 28, 227, 162, 62, 137, 104, 157, 97, 236, 199, 230, 204, 142, 209),
        U1(91, 85, 184, 248, 23, 232, 234, 231)
      }))
      if not slua.isValid((_ARG_0_:GetAdvanceAvatarComponent())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientAdvanceAvatarEquipped"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetAdvanceAvatarComponent())) then
        return
      end
      if _ARG_0_:GetAdvanceAvatarComponent().VehicleSkinID == _ARG_0_.ClientUsedAvatarID then
        return
      end
      _ARG_0_.ClientUsedAvatarID = _ARG_0_:GetAdvanceAvatarComponent().VehicleSkinID
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleCabrioletStateChanged"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 158, 209, 65, 173, 1, 206, 163, 60, 187, 114, 159, 112, 200, 242, 239, 217, 129, 196),
          U1(123, 64, 237, 248, 9, 238, 238, 239, 74, 176, 94, 220, 179, 47, 187, 119, 140, 102, 212, 206, 251, 205, 139, 224, 71, 165, 26, 199)
        }))
        return
      end
      log(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 158, 209, 65, 173, 1, 206, 163, 60, 187, 114, 159, 112, 200, 242, 239, 217, 129, 196),
        U1(123, 64, 237, 255, 2, 239, 204, 226, 65, 166, 23, 221, 186, 61, 140, 69, 154, 117, 201, 196, 173)
      }) .. tostring(_ARG_1_))
      if Client then
        log(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 158, 209, 65, 173, 1, 206, 163, 60, 187, 114, 159, 112, 200, 242, 239, 217, 129, 196),
          U1(123, 64, 237, 210, 11, 241, 234, 237, 87)
        }))
        return
      end
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      goto lbl_340
      ::lbl_340::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleCabrioletState"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetVehicleCabrioletComponent())) then
        return nil
      end
      do return _ARG_0_:GetVehicleCabrioletComponent():GetCabrioletState() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeAssetByAvatar"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 134, 117, 211, 198, 242, 233, 140, 192, 86, 176, 44, 219, 135, 62, 137, 114, 159, 118, 129, 145, 233, 249, 153, 194),
        U1(106, 69, 191, 216, 35, 184, 178, 163)
      }), _ARG_1_)
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      if not slua.isValid((_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateParticle"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 67, 158, 112, 220, 213, 242, 248, 158, 193, 71, 173, 13, 206, 163, 104, 134, 71, 136, 101, 217, 208, 245, 241, 171) .. tostring(_ARG_1_))
      _ARG_0_:DeactiveSkinSpecialEffect()
      _ARG_0_:ChangeAssetBy(_ARG_1_)
      _ARG_0_:ReActivateExhaustParticle()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeParticles"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      _ARG_0_.RuntimeParticleSoftWrapperMap = _ARG_0_.ParticleSoftWrapperMap
      if slua.isValid((_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_))) and _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).ParticleSfx:Num() > 0 then
        goto lbl_109
        ::lbl_109::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.ReplaceParticleMap:Get(_ARG_1_) and 0 < _ARG_0_.ReplaceParticleMap:Get(_ARG_1_).ParticleSfx:Num() then
        goto lbl_138
        ::lbl_138::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.AdditionalParticleMap:Get(_ARG_1_) and 0 < _ARG_0_.AdditionalParticleMap:Get(_ARG_1_).ParticleSfx:Num() then
        goto lbl_167
        ::lbl_167::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ModifyEnterSocket"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 91, 129, 112, 212, 199, 238, 237, 145, 199, 86, 182, 61, 205, 165, 35, 141, 114), _ARG_1_)
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      if U2.GetTableData(U1(72, 65, 165, 248, 4, 244, 234, 194, 87, 160, 12, 240, 134, 12, 153, 116, 130, 113), _ARG_1_) and U2.GetTableData(U1(72, 65, 165, 248, 4, 244, 234, 194, 87, 160, 12, 240, 134, 12, 153, 116, 130, 113), _ARG_1_).EnterVehicleSocket_an:Num() > 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeCharacterAnim"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) or _ARG_1_.VehCharAnimData:Num() == 0 then
        if slua.isValid((_ARG_0_:GetAvatarComponent())) and slua.isValid(_ARG_0_:GetAvatarComponent().DefaultItemAvatarHandle) and 0 < _ARG_0_:GetAvatarComponent().DefaultItemAvatarHandle.VehCharAnimData:Num() then
          _ARG_1_ = _ARG_0_:GetAvatarComponent().DefaultItemAvatarHandle
        else
          return
        end
      end
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 134, 117, 211, 198, 242, 235, 151, 210, 65, 165, 13, 214, 163, 58, 169, 104, 151, 105, 129, 145, 245, 221, 159, 207),
        U1(127, 71, 168, 177, 4, 240, 238, 241, 66, 183, 10, 215, 164, 120, 153, 120, 135, 121)
      }))
      goto lbl_261
      ::lbl_261::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeCharacterAnimNew"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == nil then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 134, 117, 211, 198, 242, 235, 151, 210, 65, 165, 13, 214, 163, 58, 169, 104, 151, 105, 227, 212, 240, 148, 207, 226),
          U1(104, 69, 185, 240, 21, 209, 203, 163, 74, 167, 94, 220, 191, 52)
        }))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaHandleHealthStateChanged"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaHandleVehicleHealthDestroy"] = function(_ARG_0_)
    do
      _ARG_0_:ClearDecals()
      if CGameMode then
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).VehicleShapeType = _ARG_0_.VehicleShapeType
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).IsDestroyed = true
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).LastAttackedTime = U1.GetTimeSeconds(_ARG_0_)
      end
      if slua.isValid(CGameState) and CGameState.GameModeSubType == import((U2(91, 99, 172, 252, 2, 213, 224, 231, 70, 135, 11, 208, 130, 33, 136, 115))).EPlanDGameMode then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_CandidateAvatar"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 235, 158, 221, 87, 173, 10, 195, 178, 45, 169, 112, 159, 112, 204, 195))
      EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_AVATAR_CHANGE_MSG, _ARG_0_.Object, _ARG_0_.CandidateAvatarID ~= 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:HandleOnSeatChanged(_ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
      if _ARG_1_ and slua.isValid(_ARG_1_) and _ARG_1_.getAvatarComponent2 and slua.isValid(_ARG_1_:getAvatarComponent2()) then
        _ARG_1_:getAvatarComponent2():DoAllAvatarReplaceOnVehicle()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnChangeSeat"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 87, 213, 192, 249, 207, 154, 224, 86, 165, 26), _ARG_1_, _ARG_4_, _ARG_2_, _ARG_3_)
      if _ARG_4_ == U2.ESeatType_DriversSeat then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 87, 213, 192, 249, 207, 154, 224, 86, 165, 26, 130, 165, 36, 141, 103, 140, 36, 219, 212, 239, 209, 140, 207),
          U1(123, 4, 164, 255, 23, 237, 251)
        }))
        _ARG_0_:ClearAllInputState()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 81, 197, 200, 227, 254, 154, 219, 90, 167, 2, 199), _ARG_1_, _ARG_2_)
      if _ARG_2_ == U2.ESeatType_DriversSeat then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 81, 197, 200, 227, 254, 154, 219, 90, 167, 2, 199, 230, 43, 132, 99, 159, 118, 141, 199, 226, 208, 134, 192),
          U1(114, 65, 237, 248, 9, 232, 250, 247)
        }))
        _ARG_0_:ClearAllInputState()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatAttached"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_1_) then
        if _ARG_1_.PlayerKey and slua.isValid(_ARG_1_.STCharacterMovement) and _ARG_1_.STCharacterMovement.ResolvePenetrationData then
          _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey] = _ARG_1_.STCharacterMovement.ResolvePenetrationData.ValidLocation
          _ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] = _ARG_0_:IsCharacterBlockFromValidLoc(_ARG_1_, _ARG_1_.STCharacterMovement.ResolvePenetrationData.ValidLocation)
        end
        EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_PLAYER_CHANGED, _ARG_0_.Object, _ARG_1_, true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCharacterBlockFromValidLoc"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) or _ARG_2_ == nil then
        return false
      end
      if slua.isValid((_ARG_0_:GetSeatComponent())) then
        goto lbl_100
        if slua.isValid(232) and 232 ~= _ARG_1_ then
        end
        ::lbl_100::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if U2.TraceBlock(_ARG_0_.Object, _ARG_2_, _ARG_1_:K2_GetActorLocation(), import((U1(49, 119, 174, 227, 14, 232, 251, 172, 102, 186, 25, 219, 184, 61, 214, 94, 135, 96, 239, 196, 228, 221, 147, 199)))(), slua.Array(UEnums.EPropertyClass.Object, (import((U1(49, 119, 174, 227, 14, 232, 251, 172, 102, 186, 25, 219, 184, 61, 214, 87, 141, 96, 210, 211))))), true).bBlockingHit then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnSeatDetachedBefore"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_1_) then
        _ARG_0_.DetachBeforeCharacterLocation = _ARG_1_:K2_GetActorLocation()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatDetached"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_1_) then
        EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_PLAYER_CHANGED, _ARG_0_.Object, _ARG_1_, false)
        if not _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey] then
          return
        end
        if _ARG_0_.DetachBeforeCharacterLocation == nil or _ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] == nil then
          return
        end
        if _ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] == true and FVector.Dist(_ARG_0_.DetachBeforeCharacterLocation, _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey]) < 800 then
        end
        if not (_ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] == true and FVector.Dist(_ARG_0_.DetachBeforeCharacterLocation, _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey]) < 800) and _ARG_0_:IsCharacterBlockFromValidLoc(_ARG_1_, _ARG_0_.DetachBeforeCharacterLocation) then
        end
        if _ARG_0_:IsCharacterBlockFromValidLoc(_ARG_1_, _ARG_0_.DetachBeforeCharacterLocation) then
          if _ARG_1_:FindActorLocationSafetyWithParams(FVector(0, 0, 0), _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey], (import((table.concat({
            U1(49, 119, 174, 227, 14, 232, 251, 172, 112, 188, 31, 214, 185, 47, 172, 100, 143, 119, 214, 196, 229, 237, 135, 199, 65, 165, 64, 240, 163, 59, 135, 106, 136, 97, 253, 212, 233, 221, 155, 209),
            U1(127, 80, 164, 254, 9, 200, 238, 241, 66, 185, 13)
          })))())) then
          else
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleHPPreChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if CGameMode and slua.isValid((_ARG_0_:GetCommonComponent())) and _ARG_2_ == _ARG_0_:GetCommonComponent():GetVehicleHPMax() then
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).VehicleShapeType = _ARG_0_.VehicleShapeType
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).FirstAttackedTime = U1.GetTimeSeconds(_ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleForbidEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if _ARG_4_ == _ENV(86, 77, 169, 244, 46, 246, 251, 230, 81, 181, 29, 198, 191, 46, 157, 67, 167) then
        _ARG_0_:ShowVehicleEnterButton(true)
        if U1.tonumber(_ARG_5_) == 1 then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerResetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_1_ == nil then
        _ARG_1_ = _ARG_0_.DefaultStartLocation
      end
      if _ARG_2_ == nil then
        _ARG_2_ = _ARG_0_.DefaultStartRotation
      end
      _ARG_0_:SetSimulatePhysics(false)
      if slua.isValid(_ARG_0_:GetProtectionComponent()) then
        _ARG_0_.ProtectionComponent:SetTickEnabled(false)
        _ARG_0_:AddTimer(0.1, function()
          ProtectionComponent:ResetValidTransform()
          ProtectionComponent:SetTickEnabled(true)
          return
        end)
      end
      if _ARG_3_ == true then
        _ARG_0_:ClientResetAdnSetToTransform(_ARG_1_, _ARG_2_)
        _ARG_0_:MulticastResetAdnSetToTransform(_ARG_1_, _ARG_2_)
      else
        _ARG_0_:ClientResetToTransform()
      end
      _ARG_0_:ServerResetToPosition(_ARG_1_, _ARG_2_, true)
      if slua.isValid(_ARG_0_.BallMovement) then
        _ARG_0_.BallMovement.CurrentRotationYaw = _ARG_2_.Yaw
        _ARG_0_.BallMovement.CameraRationYaw = _ARG_2_.Yaw
        _ARG_0_.BallMovement.STCameraRationYaw = _ARG_2_.Yaw
      end
      if slua.isValid(_ARG_0_:GetMotorbikeComponent()) then
        _ARG_0_:UnregisterComponentTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:UnregisterComponentWeakTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:AddTimer(0.1, function()
          _ENV:GetMesh():K2_GetComponentRotation().Roll = 0.0
          return
        end)
      end
      _ARG_0_:AddTimer(0.5, function()
        _ENV:SetSimulatePhysics(true)
        return
      end)
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 69, 139, 102, 203, 196, 229, 250, 154, 192, 86, 176, 58, 205, 146, 58, 137, 104, 141, 98, 194, 195, 234, 148, 207, 239),
        U1(113, 71, 172, 229, 14, 247, 225, 163, 30, 244)
      }) .. _ARG_1_:ToString() .. U1(50, 4, 159, 254, 19, 249, 251, 234, 76, 186, 94, 143, 246) .. _ARG_2_:ToString())
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerTeleportVehicleMaintainSpeed"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_:ServerResetToPosition(_ARG_1_, _ARG_2_, false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientTeleportVehicleMaintainSpeed"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientResetToTransform"] = function(_ARG_0_)
    do
      _ARG_0_:_ClientResetToTransform()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MulticastResetAdnSetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 91, 155, 120, 201, 200, 244, 201, 140, 199, 97, 161, 29, 199, 178, 9, 140, 104, 173, 97, 217, 229, 232, 236, 157, 194),
        U1(112, 87, 171, 254, 21, 245)
      }))
      if _ARG_2_ ~= nil and slua.isValid(_ARG_0_.BallMovement) then
        _ARG_0_.BallMovement.CurrentRotationYaw = _ARG_2_.Yaw
        _ARG_0_.BallMovement.CameraRationYaw = _ARG_2_.Yaw
        if _ARG_0_.BallMovement.ResetSimQuatFromRotator then
          _ARG_0_.BallMovement:ResetSimQuatFromRotator(_ARG_2_)
        end
        if _ARG_0_.DecorationCircle and slua.isValid(_ARG_0_.DecorationCircle.MeshComponent) then
          FRotator().Pitch = _ARG_0_.DecorationCircle.DefaultTransform:Rotator().Pitch + _ARG_2_.Pitch
          FRotator().Roll = _ARG_0_.DecorationCircle.DefaultTransform:Rotator().Roll + _ARG_2_.Roll
          FRotator().Yaw = _ARG_0_.DecorationCircle.DefaultTransform:Rotator().Yaw + _ARG_2_.Yaw
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientResetAdnSetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 130, 125, 216, 207, 227, 250, 154, 192, 86, 176, 47, 198, 168, 27, 141, 114, 170, 107, 249, 195, 230, 214, 156, 197),
        U1(113, 86, 160)
      }))
      _ARG_0_:_ClientResetToTransform(_ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClientResetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:StopVehicle()
      if slua.isValid(_ARG_0_:GetProtectionComponent()) then
        _ARG_0_.ProtectionComponent:SetTickEnabled(false)
        _ARG_0_:AddTimer(0.1, function()
          ProtectionComponent:ResetValidTransform()
          ProtectionComponent:SetTickEnabled(true)
          return
        end)
      end
      if _ARG_1_ ~= nil and _ARG_2_ ~= nil then
        _ARG_0_:K2_SetActorLocationAndRotation(_ARG_1_, _ARG_2_, false, nil, true)
      end
      if slua.isValid(_ARG_0_:GetMotorbikeComponent()) then
        _ARG_0_:UnregisterComponentTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:UnregisterComponentWeakTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:SetSimulatePhysics(false)
        _ARG_0_.bUseSyncAtClient = false
        _ARG_0_:AddTimer(0.1, function()
          _ENV:GetMesh():K2_GetComponentRotation().Roll = 0.0
          bUseSyncAtClient = true
          return
        end)
      end
      _ARG_0_:ResetVehicleSpringArm()
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 73, 173, 120, 212, 196, 249, 220, 173, 214, 64, 161, 26, 246, 169, 28, 154, 103, 144, 119, 203, 222, 245, 213, 195, 131),
        U1(82, 75, 174, 240, 19, 241, 224, 237, 3, 233, 94)
      }) .. _ARG_0_:K2_GetActorLocation():ToString() .. U1(50, 4, 159, 254, 19, 249, 251, 234, 76, 186, 94, 143, 246) .. _ARG_0_:K2_GetActorRotation():ToString())
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopVehicle"] = function(_ARG_0_)
    do
      if _ARG_0_:GetMoveComponent() then
      end
      if _ARG_0_.STReplicatedState then
        _ARG_0_.STReplicatedState.SteeringInput = 0
        _ARG_0_.STReplicatedState.ThrottleInput = 0
        _ARG_0_.STReplicatedState.BrakeInput = 127
        _ARG_0_.STReplicatedState.HandBrakeInput = 127
        _ARG_0_.STReplicatedState.CurrentGear = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetVehicleSpringArm"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetVehicleSpringArm())) then
        return
      end
      _ARG_0_:GetVehicleSpringArm().bUsePawnControlRotation = true
      _ARG_0_:GetVehicleSpringArm().SmartCamRotationExtra = FRotator(0, 0, 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerApplyVehicleImpulse"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 69, 139, 102, 203, 196, 229, 233, 143, 195, 95, 189, 56, 199, 174, 33, 139, 106, 155, 77, 192, 193, 242, 212, 156, 198),
        U1(50, 4, 132, 252, 23, 237, 227, 240, 70, 130, 27, 209, 162, 55, 138, 54, 211, 52)
      }) .. _ARG_1_:ToString())
      _ARG_0_:ApplyVehicleImpulse(_ARG_1_, true)
      _ARG_0_:ClientApplyVehicleImpulse(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientApplyVehicleImpulse"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 130, 125, 216, 207, 227, 233, 143, 195, 95, 189, 56, 199, 174, 33, 139, 106, 155, 77, 192, 193, 242, 212, 156, 198),
        U1(50, 4, 132, 252, 23, 237, 227, 240, 70, 130, 27, 209, 162, 55, 138, 54, 211, 52)
      }) .. _ARG_1_:ToString())
      _ARG_0_:ApplyVehicleImpulse(_ARG_1_, true)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecordVehicleTransfrom"] = function(_ARG_0_)
    do
      _ARG_0_.DefaultStartRotation = _ARG_0_:K2_GetActorRotation()
      _ARG_0_.DefaultStartLocation = _ARG_0_:K2_GetActorLocation()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreAttachBy"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not slua.isValid(_ARG_1_) or not slua.isValid(_ARG_2_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreAttachByCharacter"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not slua.isValid(_ARG_1_) or not slua.isValid(_ARG_2_) then
        return
      end
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      if _ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_) < 0 or _ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_) >= _ARG_0_:GetSeatComponent().Seats:Num() then
        return
      end
      if _ARG_3_ == _ARG_0_:GetSeatComponent().Seats:Get((_ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_))).VehicleWeaponSeatSocket then
        return
      end
      if _ARG_3_ ~= _ARG_0_:GetSeatComponent().Seats:Get((_ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_))).EnterVehicleSocket then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCurrentVehicleUseBetterAvatar"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_:GetAvatarComponent()) then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 157, 87, 200, 211, 229, 205, 145, 199, 101, 161, 6, 203, 165, 36, 141, 83, 141, 97, 239, 212, 243, 204, 138, 209),
          U1(95, 82, 172, 229, 6, 234, 175, 241, 70, 160, 11, 192, 184, 120, 158, 119, 130, 103, 216, 141, 183, 233, 137, 210, 71, 165, 28, 225, 169, 37, 152, 38, 151, 119, 141, 248, 233, 206, 142, 207),
          U1(119, 64)
        }))
        return false
      end
      if _ARG_0_.ClientUsedAvatarID and _ARG_0_.ClientUsedAvatarID ~= _ARG_0_:GetAvatarComponent():GetDefaultAvatarID() then
        if CDataTable.GetTableData(U1(92, 65, 185, 229, 2, 234, 217, 230, 75, 189, 29, 222, 179, 29, 158, 112, 139, 119, 201), _ARG_0_.ClientUsedAvatarID) then
          return true
        else
        end
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[192]
    end
  end,
  ["IsCurrentVehicleUseBetterAvataMusic"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return false
      end
      if not _ARG_1_ or _ARG_1_ == _ARG_0_:GetAvatarComponent():GetDefaultAvatarID() then
        return false
      end
      if not CDataTable.GetTableData(U1(92, 65, 185, 229, 2, 234, 217, 230, 75, 189, 29, 222, 179, 29, 158, 112, 139, 119, 201), _ARG_1_) or CDataTable.GetTableData(U1(92, 65, 185, 229, 2, 234, 217, 230, 75, 189, 29, 222, 179, 29, 158, 112, 139, 119, 201), _ARG_1_).VehicleMusic ~= 1 then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleMusicPlayState"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BPCanCharacterEnter"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid(_ARG_1_) and _ARG_1_.CanEnterVehicle then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 84, 190, 87, 220, 207, 212, 192, 158, 193, 82, 167, 26, 199, 180, 13, 134, 114, 155, 118, 141, 242, 230, 214, 170, 205),
          U1(106, 65, 191, 199, 2, 240, 230, 224, 79, 177)
        }))
        if not _ARG_1_:CanEnterVehicle(_ARG_0_) then
          print(bWriteLog and table.concat({
            U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 84, 190, 87, 220, 207, 212, 192, 158, 193, 82, 167, 26, 199, 180, 13, 134, 114, 155, 118, 141, 242, 230, 214, 170, 205),
            U1(106, 65, 191, 199, 2, 240, 230, 224, 79, 177, 94, 212, 183, 52, 139, 115)
          }))
          return false
        end
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsVaildToStopSkillWhenEnterVehicle"] = function(_ARG_0_, _ARG_1_)
    do
      if slua.isValid(_ARG_1_) and _ARG_1_:IsCastingSkillIDFix(1014711) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleCanExit"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.bCanVehicleExit = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShouldShowVehicleEnterUIToCharacher"] = function(_ARG_0_, _ARG_1_)
    do
      if slua.isValid(_ARG_1_) then
        if _ARG_1_.CanEnterVehicle and not _ARG_1_:CanEnterVehicle(_ARG_0_) then
          print(bWriteLog and table.concat({
            U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 69, 134, 123, 200, 205, 243, 251, 151, 220, 68, 146, 11, 202, 175, 43, 132, 99, 187, 106, 217, 212, 245, 237, 166, 247),
            U1(113, 103, 165, 240, 21, 249, 236, 235, 70, 166, 94, 241, 183, 54, 189, 120, 154, 113, 207, 247, 242, 192, 150, 208, 95, 161, 78, 196, 167, 36, 155, 99)
          }))
          return false
        end
        if slua.isValid(_ARG_1_) and slua.isValid((_ARG_0_:GetVehicleSeats())) then
          return _ARG_0_:GetVehicleSeats():IsSeatAvailableTeam(_ARG_1_)
        end
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDiedBoxAvatarID"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetDriver())) then
        return -1
      end
      do return (require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 98, 183, 10, 219, 160, 49, 140, 111, 192, 87, 210, 204, 250, 205, 141, 208, 90, 165, 2, 203, 188, 45, 198, 65, 159, 105, 200, 225, 235, 217, 150, 141),
        U1(72, 65, 165, 248, 4, 244, 234, 173, 117, 177, 22, 219, 181, 52, 157, 70, 130, 117, 201, 196, 219, 193, 156, 214, 93, 183, 11, 247, 178, 33, 132)
      }))).GetDiedBoxID(_ARG_0_:GetDriver().PlayerUID, (_ARG_0_:GetAvatarID()))) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDirverOrOwner"] = function(_ARG_0_)
    do
      if slua.isValid((_ARG_0_:GetDriver())) then
        return (_ARG_0_:GetDriver())
      end
      if _ARG_0_.Ownership and slua.isValid((Game:GetPlayerByPlayerKey(_ARG_0_.Ownership.BelongToPlayerKey))) then
        return (Game:GetPlayerByPlayerKey(_ARG_0_.Ownership.BelongToPlayerKey))
      end
      do return end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReActivateExhaustParticle"] = function(_ARG_0_)
    do
      if not _ARG_0_.bEnableUpdateExhuastEffectBP then
        _ARG_0_:LuaBroadcast((_ENV(81, 74, 136, 233, 15, 237, 238, 240, 87, 145, 24, 212, 179, 59, 140, 68, 139, 114, 207, 196, 228, 192)))
        return
      end
      if _ARG_0_.IsBoosting and not _ARG_0_:IsBoosting() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanActiveEffect"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == _ENV(91, 92, 165, 240, 18, 235, 251) and U1.Game:IsValid((_ARG_0_:GetAvatarComponent())) and _ARG_0_:GetAvatarComponent().VehicleAvatarHandle and _ARG_0_:GetAvatarComponent().VehicleAvatarHandle.bNeedHideExhaustWhenScope and U1.slua.isValid((U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter())) and U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter().IsLocalActuallyScopeIn then
        return false
      end
      if _ARG_1_ == _ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96) then
        if _ARG_0_.IsBoosting and not _ARG_0_:IsBoosting() then
          return false
        end
        if U1.slua.isValid(_ARG_0_.Mesh) and (not _ARG_0_.Mesh:GetAnimInstance() or not _ARG_0_.Mesh:GetAnimInstance().InLift) then
          return false
        end
      end
      do return true end
      do return end
      _ARG_1_ = _ENV[190]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnBoostingChanged"] = function(_ARG_0_)
    do
      _ARG_0_.Super:OnBoostingChanged()
      if _ARG_0_.IsBoosting and _ARG_0_:IsBoosting() then
        _ARG_0_:ActiveEffectAsync((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96)))
      else
        _ARG_0_:DeactiveEffect((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitOptimizeLeaveVehicle"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 128, 125, 201, 238, 231, 220, 150, 222, 90, 190, 11, 238, 163, 41, 158, 99, 168, 97, 197, 216, 228, 212, 138), _ARG_0_.Object)
      if not slua.isValid((_ARG_0_:GetSeatComponent())) or not _ARG_0_:GetSeatComponent().LeaveVehicleConfig then
        return
      end
      if require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 189, 107, 195, 215, 238, 223, 193, 239),
        U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)
      }))).GetConfig(_ARG_0_.VehicleShapeType) then
        goto lbl_200
        if slua.IndexReference(_ARG_0_:GetSeatComponent(), (U1(82, 65, 172, 231, 2, 206, 234, 235, 74, 183, 18, 215, 149, 55, 150, 112, 135, 115)))[U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)] ~= nil then
          slua.IndexReference(_ARG_0_:GetSeatComponent(), (U1(82, 65, 172, 231, 2, 206, 234, 235, 74, 183, 18, 215, 149, 55, 150, 112, 135, 115)))[U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)] = U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)
        end
        ::lbl_200::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegisterVehicleSkill"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.VehicleRegisterSkills[_ARG_1_] = _ARG_2_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurVehicleSkillBySkillID"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_.VehicleRegisterSkills[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleAccessorySlotConfig"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ or not _ARG_2_ then
        log(bWriteLog and table.concat({
          U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203),
          U1(119, 71, 161, 244, 38, 251, 236, 230, 80, 167, 17, 192, 175, 11, 148, 121, 154, 87, 210, 207, 241, 193, 152, 159, 19, 180, 15, 208, 167, 37, 200, 111, 141, 36, 195, 216, 235)
        }))
        return nil
      end
      log(bWriteLog and table.concat({
        U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203),
        U1(119, 71, 161, 244, 38, 251, 236, 230, 80, 167, 17, 192, 175, 11, 148, 121, 154, 87, 210, 207, 241, 193, 152, 159, 19, 170, 47, 212, 167, 60, 137, 116, 183, 64, 141, 140, 167)
      }) .. tostring(_ARG_1_) .. U1(62, 87, 161, 254, 19, 204, 246, 243, 70, 244, 67, 146) .. tostring(_ARG_2_))
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) or not _ARG_0_:GetAvatarComponent().GetItemAvatarHandle then
        return nil
      end
      if not slua.isValid((_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_))) then
        return nil
      end
      if not _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs or _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Num() == 0 then
        return nil
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203))) and _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203))).AccessorySlotName == _ARG_2_ then
        return (_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203))))
      end
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1[244]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHPBarShowName"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.VehicleHPBarName = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHPBarShowName"] = function(_ARG_0_)
    do
      if _ARG_0_.VehicleHPBarName and _ARG_0_.VehicleHPBarName ~= _ENV() then
        return _ARG_0_.VehicleHPBarName
      end
      _ARG_0_.VehicleHPBarName = U1.CDataTable.GetTableData(_ENV(87, 80, 168, 252), _ARG_0_.AvatarDefaultCfg.TypeSpecificID) and U1.CDataTable.GetTableData(_ENV(87, 80, 168, 252), _ARG_0_.AvatarDefaultCfg.TypeSpecificID).ItemName or _ENV()
      if U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))) and U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))).VehicleItemIDNameConfig and U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))).VehicleItemIDNameConfig[_ARG_0_.AvatarDefaultCfg.TypeSpecificID] then
        _ARG_0_.VehicleHPBarName = U1.LocUtil.GetLocalizeResStr(U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))).VehicleItemIDNameConfig[_ARG_0_.AvatarDefaultCfg.TypeSpecificID]) or _ARG_0_.VehicleHPBarName
      end
      do return _ARG_0_.VehicleHPBarName end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitVehicleDIYComponent"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 128, 125, 201, 247, 242, 192, 150, 208, 95, 161, 42, 235, 159, 11, 135, 107, 142, 107, 195, 212, 233, 204, 207, 205),
          U1(113, 80, 237, 199, 2, 240, 230, 224, 79, 177, 55, 246)
        }))
        return
      end
      if not CDataTable.GetTableData(U1(72, 65, 165, 248, 4, 244, 234, 199, 106, 141, 61, 212, 177), tonumber(_ARG_1_)) then
        if slua.isValid(_ARG_0_.BP_VehicleDIYComp) then
          _ARG_0_.BP_VehicleDIYComp = nil
        end
        return
      end
      if not slua.isValid(_ARG_0_.BP_VehicleDIYComp) then
        _ARG_0_.BP_VehicleDIYComp = Game:AddComponent(import((table.concat({
          U1(49, 99, 172, 252, 2, 183, 205, 239, 86, 177, 46, 192, 191, 54, 140, 101, 193, 85, 203, 192, 227, 201, 141, 247, 122, 157, 65, 224, 150, 23, 190, 99, 150, 109, 206, 221, 226, 252, 166, 250),
          U1(93, 75, 160, 225, 73, 218, 223, 220, 117, 177, 22, 219, 181, 52, 157, 82, 167, 77, 254, 206, 250, 216, 160, 240)
        }))), _ARG_0_, (U1(92, 116, 146, 199, 2, 240, 230, 224, 79, 177, 58, 251, 143, 27, 151, 123, 158)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartRecordDriveData"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      _ARG_0_.RecordCharacter = _ARG_1_
      if not _ARG_0_.UseTimer then
        _ARG_0_.DrivingDistance = 0
        _ARG_0_.LastLocation = _ARG_0_:K2_GetActorLocation()
        _ARG_0_.UseTimer = _ARG_0_:AddGameTimer(0.1, true, function()
          if slua.isValid(U1.Object) and U1.LastLocation then
            U1.DrivingDistance = U1.DrivingDistance + U2.VSize(U1:K2_GetActorLocation() - U1.LastLocation) / 100
            U1.LastLocation = U1:K2_GetActorLocation()
          end
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EndRecordDriveData"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_0_.DriverDistanceTLogID then
        return
      end
      if _ARG_0_.RecordCharacter ~= _ARG_1_ then
        return
      end
      _ARG_0_.RecordCharacter = nil
      _ARG_0_:RemoveGameTimer(_ARG_0_.UseTimer)
      _ARG_0_.UseTimer = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecordVehicleTlog"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_0_.EnterCountTlogID then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanBeCatched"] = function(_ARG_0_, _ARG_1_)
    do
      do return (_ARG_0_.UltraHandBeCatchedFeature:CanBeCatched(_ARG_1_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleProtectionStuckInternal"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.VehicleProtectionInternalTimer ~= nil and _ARG_0_.VehicleProtectionInternalTimer > 0 then
        _ARG_0_:RemoveGameTimer(_ARG_0_.VehicleProtectionInternalTimer)
      end
      if _ARG_0_:GetProtectionComponent() and slua.isValid((_ARG_0_:GetProtectionComponent())) then
        _ARG_0_:GetProtectionComponent().CheckStuckInterval = _ARG_1_
        _ARG_0_:GetProtectionComponent().StuckDuration = _ARG_2_
        _ARG_0_.VehicleProtectionInternalTimer = _ARG_0_:AddGameTimer(_ARG_3_, false, function()
          if _ENV and U1.slua.isValid(_ENV) then
            CheckStuckInterval = U1.slua.isValid(_ENV)
            StuckDuration = U1.slua.isValid(_ENV)
          end
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshVehiclePassengersParticle"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 68, 139, 114, 207, 196, 228, 192, 169, 214, 91, 173, 13, 206, 163, 24, 137, 117, 141, 97, 195, 214, 226, 202, 156, 243),
        U1(127, 86, 185, 248, 4, 244, 234)
      }))
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      goto lbl_262
      ::lbl_262::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandlePlayerAttachedToVehcicle"] = function(_ARG_0_, _ARG_1_)
    do
      if Client and slua.isValid(_ARG_1_) and _ARG_1_.CheckAttachedOrDetachedVehicle then
        _ARG_1_:CheckAttachedOrDetachedVehicle(true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_BlockForwardInput"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 234, 147, 220, 80, 175, 40, 205, 180, 63, 137, 116, 154, 77, 195, 193, 242, 204))
      if _ARG_0_.Super.OnRep_BlockForwardInput then
        _ARG_0_.Super:OnRep_BlockForwardInput()
      end
      if slua.isValid((require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter())) and require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter().GetCurrentVehicle and slua.isValid(require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter():GetCurrentVehicle()) and require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter():GetCurrentVehicle() == _ARG_0_.Object then
        if Game:IsClassOf(_ARG_0_.Object, import((U1(92, 77, 162, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61)))) or Game:IsClassOf(_ARG_0_.Object, import((U1(72, 65, 165, 248, 4, 244, 234, 193, 74, 191, 27)))) or Game:IsClassOf(_ARG_0_.Object, import((U1(72, 65, 165, 248, 4, 244, 234, 206, 76, 160, 17, 192, 145, 52, 145, 114, 139, 102)))) then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMeshPhysicsCreateExt"] = function(_ARG_0_)
    do
      _ARG_0_:LuaBroadcast(_ARG_0_.OnMeshPhysicsCreateDelegate)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FellOutOfWorldExt"] = function(_ARG_0_, _ARG_1_)
    do
      if Client and Client.IsDevelopment() and not (slua.isValid((import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance())) and import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance():IsPlayingAnyPlayback()) and slua.isValid(CGameState) and CGameState:GetGameModeState() ~= U1(88, 77, 163, 248, 20, 240, 234, 231, 112, 160, 31, 198, 179) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OutsideWorldBoundsExt"] = function(_ARG_0_, _ARG_1_)
    do
      if Client and Client.IsDevelopment() and not (slua.isValid((import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance())) and import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance():IsPlayingAnyPlayback()) and slua.isValid(CGameState) and CGameState:GetGameModeState() ~= U1(88, 77, 163, 248, 20, 240, 234, 231, 112, 160, 31, 198, 179) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["NeedCreateShootDriverComp"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 189, 107, 195, 215, 238, 223, 193, 245),
        U1(123, 76, 164, 242, 11, 253, 220, 235, 76, 187, 10, 246, 164, 49, 142, 115, 156, 87, 210, 207, 241, 193, 152)
      }))) and require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 189, 107, 195, 215, 238, 223, 193, 245),
        U1(123, 76, 164, 242, 11, 253, 220, 235, 76, 187, 10, 246, 164, 49, 142, 115, 156, 87, 210, 207, 241, 193, 152)
      }))).GetCfg(_ARG_0_.Object) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSocialIslandVehicle"] = function(_ARG_0_)
    do
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaShouldLeaveFitCloseToGround"] = function(_ARG_0_)
    do
      if _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_UH60 or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_HeavyUH60 or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_Motorglider or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_WingMan or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_Fighter or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_Aircraft then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBornIslandVehicle"] = function(_ARG_0_)
    do
      do return _ARG_0_.bIsBornIslandVehicle end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}).ClientRPC.ClientResetAdnSetToTransform = {
  Reliable = true,
  Params = {
    import(((function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(49, 119, 174, 227, 14, 232, 251, 172, 96, 187, 12, 215, 131, 23, 154, 124, 139, 119, 201, 143, 193, 205, 156, 199, 92, 182))),
    import(((function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(49, 119, 174, 227, 14, 232, 251, 172, 96, 187, 12, 215, 131, 23, 154, 124, 139, 119, 201, 143, 197, 199, 139, 210, 71, 171, 28)))
  }
}
;({
  ServerRPC = {},
  ClientRPC = {},
  MulticastRPC = {},
  LuaEventContainer = {
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 128, 244, 20, 240, 223, 235, 90, 167, 23, 209, 165, 27, 138, 115, 143, 96, 216),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(72, 65, 165, 248, 4, 244, 234, 208, 72, 189, 18, 222, 147, 54, 157, 100, 137, 109, 254, 201, 246, 198, 152, 214, 87),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(72, 65, 165, 248, 4, 244, 234, 198, 77, 176, 46, 222, 183, 33, 189, 96, 139, 122, 201),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 152, 226, 2, 213, 224, 247, 76, 166, 63, 199, 178, 49, 151),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 136, 233, 15, 237, 238, 240, 87, 145, 24, 212, 179, 59, 140, 68, 139, 114, 207, 196, 228, 192),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 142, 249, 6, 246, 232, 230, 112, 177, 31, 198),
    ((function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 136, 233, 14, 236, 217, 230, 75, 189, 29, 222, 179))
  },
  ["ctor"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.SeatComponent = nil
      _ARG_0_.AvatarComponent = nil
      _ARG_0_.AdvanceAvatarComponent = nil
      _ARG_0_.BP_VehicleDIYComp = nil
      _ARG_0_.ClientUsedAvatarID = 0
      _ARG_0_.CommonComponent = nil
      _ARG_0_.SpringArm = nil
      _ARG_0_.LastOccupiers = {}
      _ARG_0_.AttachedCharacterLocation = {}
      _ARG_0_.AttachedCharacterBlock = {}
      _ARG_0_.OnMeshPhysicsCreateDelegate = _ENV(81, 74, 128, 244, 20, 240, 223, 235, 90, 167, 23, 209, 165, 27, 138, 115, 143, 96, 216)
      _ARG_0_.bCanVehicleExit = true
      _ARG_0_.VehicleRegisterSkills = {}
      _ARG_0_.VehicleProtectionInternalTimer = nil
      _ARG_0_.OriginalCheckStuckInterval = 1
      _ARG_0_.OriginalStuckDuration = 5
      _ARG_0_.UseTimer = nil
      _ARG_0_.DrivingDistance = 0
      _ARG_0_.RecordCharacter = nil
      _ARG_0_.bIsBornIslandVehicle = false
      _ARG_0_.bUGCSkillAirDrop = false
      _ARG_0_.WeddingCarIndex = 0
      _ARG_0_.PassengerEnterShowTextID = nil
      _ARG_0_.PassengerEnterShowIconPath = nil
      _ARG_0_.DriverEnterShowTextID = nil
      _ARG_0_.DriverEnterShowIconPath = nil
      _ARG_0_.LeaveVehicleTextID = nil
      _ARG_0_.LeaveVehicleIconPath = nil
      _ARG_0_.VehicleHPBarName = _ENV()
      _ARG_0_.bUGCInstance = false
      _ARG_0_.UGCInstanceId = 0
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PostConstruct"] = function(_ARG_0_)
    do
      __super._PostConstruct(_ARG_0_)
      _ARG_0_:InitConfig()
      if U1.Client then
        _ARG_0_:AddCommonEvent(U1.EVENTTYPE_INGAME_NORMAL, U1.EVENTID_SEQUENCE_MSG, _ARG_0_.HandleForbidEnterVehicle, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 142, 253, 14, 253, 225, 247, 102, 186, 10, 215, 164, 14, 157, 126, 135, 119, 209, 196, 210, 222, 154, 221, 71), _ARG_0_.ClientHandleEnterVehicle, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 142, 253, 14, 253, 225, 247, 102, 172, 23, 198, 128, 61, 144, 127, 141, 120, 216, 228, 225, 205, 145, 199), _ARG_0_.ClientHandleExitVehicle, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 142, 253, 14, 253, 225, 247, 96, 188, 31, 220, 177, 61, 174, 115, 134, 125, 222, 205, 242, 251, 154, 210, 71, 129, 24, 199, 168, 60), _ARG_0_.ClientHandleChangeVehicleSeat, _ARG_0_)
      else
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 136, 255, 19, 253, 253, 213, 70, 188, 23, 209, 186, 61), _ARG_0_.ServerHandleEnterVehicleResult, _ARG_0_)
      end
      _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 155, 244, 15, 241, 236, 239, 70, 156, 27, 211, 186, 44, 144, 69, 154, 117, 201, 196, 212, 192, 158, 221, 84, 161, 10), _ARG_0_.LuaHandleHealthStateChanged, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 155, 244, 15, 241, 236, 239, 70, 156, 27, 211, 186, 44, 144, 82, 139, 103, 201, 211, 248, 209), _ARG_0_.LuaHandleVehicleHealthDestroy, _ARG_0_)
      if U1.slua.isValid((_ARG_0_:GetAvatarComponent())) then
        _ARG_0_.ClientUsedAvatarID = _ARG_0_:GetAvatarComponent():GetDefaultAvatarID()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PreDestruct"] = function(_ARG_0_)
    do
      if _ARG_0_.Features then
        goto lbl_37
        ::lbl_37::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.VehicleFeatures then
        goto lbl_56
        ::lbl_56::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _ARG_0_.VehicleFeatures = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLifetimeReplicatedProps"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 81, 139, 96, 241, 200, 241, 205, 139, 218, 94, 161, 60, 199, 182, 36, 129, 101, 159, 112, 200, 213, 215, 202, 128, 211),
        U1(109)
      }))
      do return {
        {
          U1(124, 113, 138, 210, 52, 243, 230, 239, 79, 149, 23, 192, 146, 42, 151, 102),
          import((U1(91, 104, 164, 247, 2, 236, 230, 238, 70, 151, 17, 220, 178, 49, 140, 127, 129, 122))).COND_None,
          UEnums.EPropertyClass.Bool
        },
        {
          U1(73, 65, 169, 245, 14, 246, 232, 192, 66, 166, 55, 220, 178, 61, 128),
          import((U1(91, 104, 164, 247, 2, 236, 230, 238, 70, 151, 17, 220, 178, 49, 140, 127, 129, 122))).COND_None,
          UEnums.EPropertyClass.Int
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_bUGCSkillAirDrop"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 202, 170, 244, 112, 151, 5, 203, 170, 36, 169, 111, 140, 64, 223, 222, 247, 148, 207, 236),
        U1(114, 64, 155, 240, 11, 237, 234)
      }) .. tostring(_ARG_1_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_WeddingCarIndex"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 255, 154, 215, 87, 173, 0, 197, 133, 41, 154, 79, 144, 96, 200, 201, 171, 152, 160, 207),
        U1(122, 114, 172, 253, 18, 253)
      }) .. tostring(_ARG_1_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientDriverChangeEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid(_ARG_2_) and _ARG_2_:IsLocallyControlled() and Game:IsValid(_ARG_0_:GetVehicleSpringArm()) and _ARG_0_:GetVehicleSpringArm().bForceInitCameraLagWhenDriverGetOn then
        _ARG_0_:GetVehicleSpringArm().bDoLocationLagInit = false
      end
      _ARG_0_.bBaseAutoMoveForward = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnPlayerCannotExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_0_.uLastCannotExitLocation ~= nil and FVector.Distance(_ARG_0_:K2_GetActorLocation(), _ARG_0_.uLastCannotExitLocation) < 100 then
        return
      end
      _ARG_0_.uLastCannotExitLocation = _ARG_0_:K2_GetActorLocation()
      if 100 < _ARG_0_:GetForwardSpeed() then
        return
      end
      do return end
      _ARG_0_ = _ENV[140]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitConfig"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 128, 125, 201, 226, 248, 198, 153, 218, 84), _ARG_0_.Object)
      if require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 168, 97, 197, 216, 228, 212, 138, 224),
        U1(113, 74, 171, 248, 0)
      }))).GenConfig(_ARG_0_.Object, _ARG_0_.VehicleShapeType) and next((require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 168, 97, 197, 216, 228, 212, 138, 224),
        U1(113, 74, 171, 248, 0)
      }))).GenConfig(_ARG_0_.Object, _ARG_0_.VehicleShapeType))) then
        goto lbl_106
        _ARG_0_[U1(113, 74, 171, 248, 0)] = U1(113, 74, 171, 248, 0)
        ::lbl_106::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleControlUIConfig"] = function(_ARG_0_)
    do
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUIConfig"] = function(_ARG_0_)
    do
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitComponents"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_23
      ::lbl_23::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitComponentAttributes"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_18
      ::lbl_18::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitVehicleFeatures"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_19
      ::lbl_19::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_76
      if slua.IsLuaModuleExists(table.unpack(_ARG_1_[226])) then
        if table.unpack(_ARG_1_[226]) and next(table.unpack(_ARG_1_[226])) then
          goto lbl_68
          require(table.unpack(_ARG_1_[226]))(_ARG_0_.Object)[nil] = nil
          ::lbl_68::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      ::lbl_76::
      _ARG_0_ = _ARG_0_
      _ARG_0_.VehicleFeatures, _ARG_0_ = {
        [226] = require(table.unpack(_ARG_1_[226]))(_ARG_0_.Object)
      }, _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitCustomConfigs"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      _ARG_0_.VehicleCustomConfigs = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearVehicleFeatures"] = function(_ARG_0_)
    do
      if _ARG_0_.VehicleFeatures and next(_ARG_0_.VehicleFeatures) then
        goto lbl_20
        ::lbl_20::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _ARG_0_.VehicleFeatures = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CallFunction"] = function(_ARG_0_, _ARG_1_, _ARG_2_, ...)
    do
      if _ARG_0_[_ARG_1_] then
        if slua.isValid(_ARG_0_[_ARG_1_]) and _ARG_0_[_ARG_1_][_ARG_2_] then
          return _ARG_0_[_ARG_1_][_ARG_2_](_ARG_0_[_ARG_1_], ...)
        end
      else
        _ARG_0_.FunctionCache = _ARG_0_.FunctionCache or {}
        if _ARG_0_.FunctionCache then
          _ARG_0_.FunctionCache[_ARG_1_] = _ARG_0_.FunctionCache[_ARG_1_] or {}
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ExecuteFunctions"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.FunctionCache or not _ARG_0_.FunctionCache[_ARG_1_] then
        return
      end
      goto lbl_23
      ::lbl_23::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveBeginPlay"] = function(_ARG_0_)
    do
      __super.ReceiveBeginPlay(_ARG_0_)
      _ARG_0_:InitOptimizeLeaveVehicle()
      if U1.SubsystemMgr:Get((U2(72, 65, 165, 248, 4, 244, 234, 208, 86, 182, 13, 203, 165, 44, 157, 123))) then
      end
      if U1.Client then
        if U1.slua.isValid((_ARG_0_:GetAdvanceAvatarComponent())) then
        end
      else
        _ARG_0_.bSkipComparePropertiesForReplay = true
        if _ARG_0_:GetProtectionComponent() and U1.slua.isValid((_ARG_0_:GetProtectionComponent())) then
          _ARG_0_.OriginalCheckStuckInterval = _ARG_0_:GetProtectionComponent().CheckStuckInterval
          _ARG_0_.OriginalStuckDuration = _ARG_0_:GetProtectionComponent().StuckDuration
        end
        if U1.slua.isValid(_ARG_0_.VehicleMovement) and _ARG_0_.VehicleMovement.DriftSetup then
          _ARG_0_.VehicleMovement.DriftSetup.MaxOmega = 360
        end
        if U1.slua.isValid((_ARG_0_:GetVehicleSync())) then
          _ARG_0_:GetVehicleSync().VehicleHitRewindThreshold.ValidDeltaSeconds = 0.35
        end
      end
      _ARG_0_.DefaultStartLocation = _ARG_0_:K2_GetActorLocation()
      _ARG_0_.DefaultStartRotation = _ARG_0_:K2_GetActorRotation()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AfterBeginPlay"] = function(_ARG_0_)
    do
      if _ARG_0_.Super.AfterBeginPlay then
        _ARG_0_.Super:AfterBeginPlay()
      end
      if slua.isValid(_ARG_0_.VehicleShootAntiCheat) then
        _ARG_0_.VehicleShootAntiCheat.BoundBoxExtendMoveTime = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetShootVertifyHitBoxScale"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return FVector(2, 2, 2) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerHandleEnterVehicleResult"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_2_ == U1.ESeatType_DriversSeat and slua.isValid(_ARG_0_:GetVehicleSpringArm()) then
        _ARG_0_:GetVehicleSpringArm().bDoCollisionTest = true
      end
      _ARG_1_.ClientSidePoseState = import((U2(91, 119, 153, 212, 55, 247, 252, 230, 112, 160, 31, 198, 179))).Stand
      if slua.isValid((_ARG_1_:GetThirdPersonSpringArm())) then
        _ARG_1_:GetThirdPersonSpringArm().bDoCollisionTest = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      _ARG_1_.ClientSidePoseState = import((U1(91, 119, 153, 212, 55, 247, 252, 230, 112, 160, 31, 198, 179))).Stand
      if Game:IsBioVehicle(_ARG_0_.Object) then
        if slua.isValid(_ARG_0_.CapsuleComponent) and _ARG_0_.CapsuleComponent:ComponentHasTag((U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157))) then
          _ARG_0_ = _ARG_0_
          if _ARG_0_.CapsuleComponent.ComponentTags:Get(81) == U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157) then
          else
            _ARG_0_ = _ARG_0_
          end
          if 81 >= 0 then
          end
        end
        if slua.isValid(_ARG_0_.HeadCapsuleComponent) and _ARG_0_.HeadCapsuleComponent:ComponentHasTag((U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157))) then
          _ARG_0_ = _ARG_0_
          if _ARG_0_.HeadCapsuleComponent.ComponentTags:Get(81) == U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157) then
          else
            _ARG_0_ = _ARG_0_
          end
          if 81 >= 0 then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleChangeVehicleSeat"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEndChangeVehicleItemAvatar"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 81, 211, 197, 212, 192, 158, 221, 84, 161, 56, 199, 174, 33, 139, 106, 155, 77, 217, 212, 234, 249, 153, 194),
        U1(106, 69, 191)
      }))
      _ARG_0_:CheckAvatarDormant()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAvatarDormant"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SpawnBoxComponent"] = function(_ARG_0_)
    do
      if not _ARG_0_:HasAuthority() then
        return
      end
      if import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))) == nil then
        return
      end
      if not Game:IsValid((Game:AddComponent(import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))), _ARG_0_, (U1(90, 65, 172, 245, 49, 253, 231, 234, 64, 184, 27, 240, 185, 32))))) then
        return
      end
      if not Game:AddComponent(import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))), _ARG_0_, (U1(90, 65, 172, 245, 49, 253, 231, 234, 64, 184, 27, 240, 185, 32))):K2_AttachToComponent(_ARG_0_.Mesh, U1(80, 75, 163, 244), import((U1(91, 101, 185, 229, 6, 251, 231, 238, 70, 186, 10, 224, 163, 52, 157))).KeepRelative, import((U1(91, 101, 185, 229, 6, 251, 231, 238, 70, 186, 10, 224, 163, 52, 157))).KeepRelative, import((U1(91, 101, 185, 229, 6, 251, 231, 238, 70, 186, 10, 224, 163, 52, 157))).KeepRelative, false) then
        return
      end
      Game:AddComponent(import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))), _ARG_0_, (U1(90, 65, 172, 245, 49, 253, 231, 234, 64, 184, 27, 240, 185, 32))).bGenerateOverlapEvents = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BPGetQueryIgnoreActors"] = function(_ARG_0_)
    do
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenPhysicForAMoment"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:HasAuthority() then
        return
      end
      if _ARG_0_:IsSimulatePhysics() then
        return
      end
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 158, 113, 211, 241, 255, 209, 140, 218, 80, 130, 1, 208, 135, 5, 135, 107, 155, 106, 217), _ARG_0_.Role)
      _ARG_0_:SetSimulatePhysics(true)
      if _ARG_0_.PhysicTimer ~= nil then
        Game:ClearTimer(_ARG_0_.PhysicTimer)
        _ARG_0_.PhysicTimer = nil
      end
      _ARG_0_.PhysicTimer = Game:SetTimer(_ARG_1_, false, function()
        _ENV:SetSimulatePhysics(false)
        U1.Game:ClearTimer(PhysicTimer)
        PhysicTimer = nil
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveEndPlay"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.PhysicTimer ~= nil then
        Game:ClearTimer(_ARG_0_.PhysicTimer)
        _ARG_0_.PhysicTimer = nil
      end
      _ARG_0_.bIsDeformed = false
      _ARG_0_.VehicleRegisterSkills = {}
      EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_ENDPLAY, _ARG_0_.Object)
      _ARG_0_:ClearVehicleFeatures()
      if _ARG_0_.LuaBroadcast then
        _ARG_0_:LuaBroadcast((U1(72, 65, 165, 248, 4, 244, 234, 198, 77, 176, 46, 222, 183, 33, 189, 96, 139, 122, 201)))
      end
      _ARG_0_.Super:ReceiveEndPlay(_ARG_1_)
      U2.__super.ReceiveEndPlay(_ARG_0_, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMoveComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.MoveComponent) then
        _ARG_0_.MoveComponent = _ARG_0_:GetComponentByClass((import((U1(77, 112, 136, 233, 19, 234, 238, 213, 70, 188, 23, 209, 186, 61, 181, 121, 152, 113, 208, 196, 249, 220, 188, 220, 94, 180, 1, 204, 163, 38, 156, 50, 169)))))
      end
      do return _ARG_0_.MoveComponent end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCommonComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.CommonComponent) then
        _ARG_0_.CommonComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 192, 76, 185, 19, 221, 184, 27, 151, 123, 158, 123, 211, 196, 249, 220)))))
      end
      do return _ARG_0_.CommonComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSeatComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.SeatComponent) and slua.isValid(_ARG_0_.Object) then
        _ARG_0_.SeatComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 208, 70, 181, 10, 241, 185, 53, 136, 121, 128, 113, 211, 213)))))
      end
      do return _ARG_0_.SeatComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAvatarComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.AvatarComponent) then
        _ARG_0_.AvatarComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 194, 85, 181, 10, 211, 164, 27, 151, 123, 158, 123, 211, 196, 249, 220)))))
      end
      do return _ARG_0_.AvatarComponent end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAdvanceAvatarComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.AdvanceAvatarComponent) then
        _ARG_0_.AdvanceAvatarComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 194, 71, 162, 31, 220, 181, 61, 185, 96, 143, 96, 220, 211, 212, 199, 146, 195, 92, 170, 11, 204, 178)))))
      end
      do return _ARG_0_.AdvanceAvatarComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetProtectionComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.ProtectionComponent) then
        _ARG_0_.ProtectionComponent = _ARG_0_:GetComponentByClass((import((U1(73, 76, 168, 244, 11, 253, 235, 213, 70, 188, 23, 209, 186, 61, 168, 100, 129, 96, 216, 194, 227, 193, 144, 221, 112, 171, 3, 210, 169, 38, 141, 104, 138)))))
      end
      do return _ARG_0_.ProtectionComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMotorbikeComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.MotorbikeComponent) then
        _ARG_0_.MotorbikeComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 206, 76, 160, 17, 192, 180, 49, 147, 115, 173, 123, 208, 209, 248, 198, 154, 221, 71)))))
      end
      do return _ARG_0_.MotorbikeComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMusicComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.MusicComponent) then
        _ARG_0_.MusicComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 206, 86, 167, 23, 209, 149, 55, 149, 102, 129, 122, 216, 207, 227)))))
      end
      do return _ARG_0_.MusicComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBuffComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.BuffSystemComp) then
        _ARG_0_.BuffSystemComp = _ARG_0_:GetComponentByClass((import((U1(77, 112, 143, 228, 1, 254, 220, 250, 80, 160, 27, 223, 149, 55, 149, 102, 129, 122, 216, 207, 227)))))
      end
      do return _ARG_0_.BuffSystemComp end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAccelerationComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.AccelerateComponent) then
        _ARG_0_.AccelerateComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 194, 64, 183, 27, 222, 179, 42, 153, 98, 139, 87, 210, 204, 231, 199, 145, 214, 93, 176)))))
      end
      do return _ARG_0_.AccelerateComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPickupComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehiclePickableComponent) then
        _ARG_0_.VehiclePickableComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 211, 74, 183, 21, 211, 180, 52, 157, 85, 129, 121, 205, 206, 249, 205, 145, 199)))))
      end
      do return _ARG_0_.VehiclePickableComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLicenseComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehicleLicenseComponent) then
        _ARG_0_.VehicleLicenseComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 207, 74, 183, 27, 220, 165, 61, 182, 99, 131, 118, 216, 211, 212, 199, 146, 195, 92, 170, 11, 204, 178)))))
      end
      do return _ARG_0_.VehicleLicenseComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleCabrioletComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehicleCabrioletComponent) then
        _ARG_0_.VehicleCabrioletComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 192, 66, 182, 12, 219, 185, 52, 157, 98, 173, 123, 208, 209, 248, 198, 154, 221, 71)))))
      end
      do return _ARG_0_.VehicleCabrioletComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddDynamicComponentLoadCompletedCallbacks"] = function(_ARG_0_, _ARG_1_, ...)
    do
      if _ARG_0_:DynamicComponentAllLoadCompleted() then
      elseif _ARG_0_.DynamicComponentLoadCompletedCallbacks == nil then
        _ARG_0_.DynamicComponentLoadCompletedCallbacks = {}
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ForceExitCharacters"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:HasAuthority() then
        if not slua.isValid((_ARG_0_:GetSeatComponent())) then
          return
        end
        goto lbl_128
        if slua.isValid(nil) then
          if _ARG_1_ == true then
            if slua.isValid(((nil):GetWeaponManager())) and (nil):GetWeaponManager():GetAllInventoryWeaponList(false) then
              goto lbl_126
              ::lbl_126::
              _ARG_0_ = _ARG_0_
              _ARG_0_ = _ARG_0_
            end
          end
        end
        ::lbl_128::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleDriverChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 236, 141, 218, 69, 161, 28, 225, 174, 41, 134, 97, 155, 96))
      _ARG_0_:ResetCandidateAvatarID(_ARG_2_)
      if CGameMode and not CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).Drived then
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).VehicleShapeType = _ARG_0_.VehicleShapeType
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).Drived = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatOccupiersChanged"] = function(_ARG_0_)
    do
      EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_SEAT_OCCUPIERS_CHANGED, _ARG_0_.Object)
      if slua.isValid((_ARG_0_:GetSeatComponent())) then
        if _ARG_0_.LastOccupiers and next(_ARG_0_.LastOccupiers) then
          goto lbl_36
          if slua.isValid(nil) then
          end
          ::lbl_36::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          goto lbl_71
          if slua.isValid(229) and not ({
            [nil] = true
          })[229] then
          end
          ::lbl_71::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if Client and not Client.IsEnableDSGrayPublishFlag(2199023255552) and not Client.IsEditor() and slua.isValid(_ARG_0_.Object) and not _ARG_0_.IsUnmannedVehicle and slua.isValid((_ARG_0_:GetSeatComponent())) then
          goto lbl_274
          if slua.isValid(229) and slua.isValid((229):GetCurrentVehicle()) and slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle()) then
          end
          ::lbl_274::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          goto lbl_461
          if slua.isValid(slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())) and not slua.isValid((slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetCurrentVehicle()) and slua.isValid(((slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetPlayerControllerSafety():GetVehicleUserComp())) and slua.isValid((slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle()) and slua.isValid((_ARG_0_:GetMesh())) and 229 >= 0 and 229 < _ARG_0_:GetSeatComponent().Seats:Num() then
            FVector(0, 0, 0).Z = (slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetSimpleCollisionHalfHeightInStandPose()
          end
          ::lbl_461::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if slua.isValid((_ARG_0_:GetSeatComponent())) then
          goto lbl_647
          ::lbl_647::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      _ARG_0_.LastOccupiers = {}
      goto lbl_663
      _ARG_0_.LastOccupiers[pairs(_ARG_0_:GetSeatComponent().SeatOccupiers)] = U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 210, 71, 139, 13, 193, 179, 56, 129, 99, 140, 119, 238, 217, 230, 214, 136, 198), slua.isValid((U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 210, 71, 139, 13, 193, 179, 56, 129, 99, 140, 119, 238, 217, 230, 214, 136, 198))) and _ARG_0_.LastOccupiers
      ::lbl_663::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetCandidateAvatarID"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(76, 65, 190, 244, 19, 219, 238, 237, 71, 189, 26, 211, 162, 61, 185, 96, 143, 96, 220, 211, 222, 236), _ARG_1_)
      if _ARG_0_:HasAuthority() and not slua.isValid(_ARG_1_) then
        _ARG_0_.CandidateAvatarID = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSeatAvailable"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid((_ARG_0_:GetSeatComponent())) then
        return _ARG_0_:GetSeatComponent():IsSeatIndexAvailable(_ARG_1_)
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayerEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 68, 209, 192, 238, 205, 141, 246, 93, 176, 11, 208, 144, 45, 128, 111, 157, 104, 200), _ARG_1_, _ARG_2_, _ARG_0_.bSkipComparePropertiesForReplay)
      if not Client then
        _ARG_0_.bSkipComparePropertiesForReplay = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayerExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 68, 209, 192, 238, 205, 141, 246, 75, 173, 26, 244, 163, 32, 129, 101, 146, 97), _ARG_1_, _ARG_2_, _ARG_3_, _ARG_0_.bSkipComparePropertiesForReplay)
      if not Client and _ARG_1_ then
        _ARG_0_.bSkipComparePropertiesForReplay = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleServerAvatarEquiped"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 193, 69, 161, 28, 227, 176, 41, 156, 103, 140, 65, 220, 196, 238, 200, 138, 199))
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleVehicleLoadedFPPMesh"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 64, 139, 124, 212, 194, 251, 205, 179, 220, 82, 160, 11, 198, 128, 24, 184, 75, 155, 119, 197))
      _ARG_0_:HandleClientAvatarEquiped()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientAvatarEquiped"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 147, 218, 86, 170, 26, 227, 176, 41, 156, 103, 140, 65, 220, 196, 238, 200, 138, 199))
      if slua.isValid((_ARG_0_:GetAvatarComponent())) then
        if _ARG_0_:GetAvatarComponent():GetCurrentAvatarID() == _ARG_0_.ClientUsedAvatarID then
          return
        end
        _ARG_0_.ClientUsedAvatarID = _ARG_0_:GetAvatarComponent():GetCurrentAvatarID()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientVehicleSwitchEffectEnd"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 147, 218, 86, 170, 26, 244, 163, 32, 129, 101, 146, 97, 254, 198, 238, 204, 140, 203),
        U1(91, 66, 171, 244, 4, 236, 202, 237, 71)
      }))
      _ARG_0_:InitVehicleDIYComponent(_ARG_0_.ClientUsedAvatarID)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientVehicleSlotEquiped"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      if _ARG_0_:GetAvatarComponent().NetHighTireStruct and _ARG_0_:GetAvatarComponent().NetHighTireStruct.bEnableHighTire ~= nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeactiveSkinSpecialEffect"] = function(_ARG_0_)
    do
      _ARG_0_:DeactiveEffect((_ENV(91, 92, 165, 240, 18, 235, 251)))
      _ARG_0_:DeactiveEffect((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222)))
      _ARG_0_:DeactiveEffect((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96)))
      _ARG_0_:DeactiveEffect((_ENV(77, 80, 172, 227, 19, 205, 255, 197, 123)))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleAdvanceAvatarEquipped"] = function(_ARG_0_)
    do
      if _ARG_0_:HasAuthority() then
        _ARG_0_:HandleServerAdvanceAvatarEquipped()
      else
        _ARG_0_:HandleClientAdvanceAvatarEquipped()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAndSetStartUpEffect"] = function(_ARG_0_, _ARG_1_)
    do
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleServerAdvanceAvatarEquipped"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 193, 69, 161, 28, 227, 162, 62, 137, 104, 157, 97, 236, 199, 230, 204, 142, 209),
        U1(91, 85, 184, 248, 23, 232, 234, 231)
      }))
      if not slua.isValid((_ARG_0_:GetAdvanceAvatarComponent())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientAdvanceAvatarEquipped"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetAdvanceAvatarComponent())) then
        return
      end
      if _ARG_0_:GetAdvanceAvatarComponent().VehicleSkinID == _ARG_0_.ClientUsedAvatarID then
        return
      end
      _ARG_0_.ClientUsedAvatarID = _ARG_0_:GetAdvanceAvatarComponent().VehicleSkinID
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleCabrioletStateChanged"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 158, 209, 65, 173, 1, 206, 163, 60, 187, 114, 159, 112, 200, 242, 239, 217, 129, 196),
          U1(123, 64, 237, 248, 9, 238, 238, 239, 74, 176, 94, 220, 179, 47, 187, 119, 140, 102, 212, 206, 251, 205, 139, 224, 71, 165, 26, 199)
        }))
        return
      end
      log(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 158, 209, 65, 173, 1, 206, 163, 60, 187, 114, 159, 112, 200, 242, 239, 217, 129, 196),
        U1(123, 64, 237, 255, 2, 239, 204, 226, 65, 166, 23, 221, 186, 61, 140, 69, 154, 117, 201, 196, 173)
      }) .. tostring(_ARG_1_))
      if Client then
        log(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 158, 209, 65, 173, 1, 206, 163, 60, 187, 114, 159, 112, 200, 242, 239, 217, 129, 196),
          U1(123, 64, 237, 210, 11, 241, 234, 237, 87)
        }))
        return
      end
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      goto lbl_340
      ::lbl_340::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleCabrioletState"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetVehicleCabrioletComponent())) then
        return nil
      end
      do return _ARG_0_:GetVehicleCabrioletComponent():GetCabrioletState() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeAssetByAvatar"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 134, 117, 211, 198, 242, 233, 140, 192, 86, 176, 44, 219, 135, 62, 137, 114, 159, 118, 129, 145, 233, 249, 153, 194),
        U1(106, 69, 191, 216, 35, 184, 178, 163)
      }), _ARG_1_)
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      if not slua.isValid((_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateParticle"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 67, 158, 112, 220, 213, 242, 248, 158, 193, 71, 173, 13, 206, 163, 104, 134, 71, 136, 101, 217, 208, 245, 241, 171) .. tostring(_ARG_1_))
      _ARG_0_:DeactiveSkinSpecialEffect()
      _ARG_0_:ChangeAssetBy(_ARG_1_)
      _ARG_0_:ReActivateExhaustParticle()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeParticles"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      _ARG_0_.RuntimeParticleSoftWrapperMap = _ARG_0_.ParticleSoftWrapperMap
      if slua.isValid((_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_))) and _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).ParticleSfx:Num() > 0 then
        goto lbl_109
        ::lbl_109::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.ReplaceParticleMap:Get(_ARG_1_) and 0 < _ARG_0_.ReplaceParticleMap:Get(_ARG_1_).ParticleSfx:Num() then
        goto lbl_138
        ::lbl_138::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.AdditionalParticleMap:Get(_ARG_1_) and 0 < _ARG_0_.AdditionalParticleMap:Get(_ARG_1_).ParticleSfx:Num() then
        goto lbl_167
        ::lbl_167::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ModifyEnterSocket"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 91, 129, 112, 212, 199, 238, 237, 145, 199, 86, 182, 61, 205, 165, 35, 141, 114), _ARG_1_)
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      if U2.GetTableData(U1(72, 65, 165, 248, 4, 244, 234, 194, 87, 160, 12, 240, 134, 12, 153, 116, 130, 113), _ARG_1_) and U2.GetTableData(U1(72, 65, 165, 248, 4, 244, 234, 194, 87, 160, 12, 240, 134, 12, 153, 116, 130, 113), _ARG_1_).EnterVehicleSocket_an:Num() > 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeCharacterAnim"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) or _ARG_1_.VehCharAnimData:Num() == 0 then
        if slua.isValid((_ARG_0_:GetAvatarComponent())) and slua.isValid(_ARG_0_:GetAvatarComponent().DefaultItemAvatarHandle) and 0 < _ARG_0_:GetAvatarComponent().DefaultItemAvatarHandle.VehCharAnimData:Num() then
          _ARG_1_ = _ARG_0_:GetAvatarComponent().DefaultItemAvatarHandle
        else
          return
        end
      end
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 134, 117, 211, 198, 242, 235, 151, 210, 65, 165, 13, 214, 163, 58, 169, 104, 151, 105, 129, 145, 245, 221, 159, 207),
        U1(127, 71, 168, 177, 4, 240, 238, 241, 66, 183, 10, 215, 164, 120, 153, 120, 135, 121)
      }))
      goto lbl_261
      ::lbl_261::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeCharacterAnimNew"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == nil then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 134, 117, 211, 198, 242, 235, 151, 210, 65, 165, 13, 214, 163, 58, 169, 104, 151, 105, 227, 212, 240, 148, 207, 226),
          U1(104, 69, 185, 240, 21, 209, 203, 163, 74, 167, 94, 220, 191, 52)
        }))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaHandleHealthStateChanged"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaHandleVehicleHealthDestroy"] = function(_ARG_0_)
    do
      _ARG_0_:ClearDecals()
      if CGameMode then
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).VehicleShapeType = _ARG_0_.VehicleShapeType
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).IsDestroyed = true
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).LastAttackedTime = U1.GetTimeSeconds(_ARG_0_)
      end
      if slua.isValid(CGameState) and CGameState.GameModeSubType == import((U2(91, 99, 172, 252, 2, 213, 224, 231, 70, 135, 11, 208, 130, 33, 136, 115))).EPlanDGameMode then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_CandidateAvatar"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 235, 158, 221, 87, 173, 10, 195, 178, 45, 169, 112, 159, 112, 204, 195))
      EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_AVATAR_CHANGE_MSG, _ARG_0_.Object, _ARG_0_.CandidateAvatarID ~= 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:HandleOnSeatChanged(_ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
      if _ARG_1_ and slua.isValid(_ARG_1_) and _ARG_1_.getAvatarComponent2 and slua.isValid(_ARG_1_:getAvatarComponent2()) then
        _ARG_1_:getAvatarComponent2():DoAllAvatarReplaceOnVehicle()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnChangeSeat"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 87, 213, 192, 249, 207, 154, 224, 86, 165, 26), _ARG_1_, _ARG_4_, _ARG_2_, _ARG_3_)
      if _ARG_4_ == U2.ESeatType_DriversSeat then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 87, 213, 192, 249, 207, 154, 224, 86, 165, 26, 130, 165, 36, 141, 103, 140, 36, 219, 212, 239, 209, 140, 207),
          U1(123, 4, 164, 255, 23, 237, 251)
        }))
        _ARG_0_:ClearAllInputState()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 81, 197, 200, 227, 254, 154, 219, 90, 167, 2, 199), _ARG_1_, _ARG_2_)
      if _ARG_2_ == U2.ESeatType_DriversSeat then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 81, 197, 200, 227, 254, 154, 219, 90, 167, 2, 199, 230, 43, 132, 99, 159, 118, 141, 199, 226, 208, 134, 192),
          U1(114, 65, 237, 248, 9, 232, 250, 247)
        }))
        _ARG_0_:ClearAllInputState()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatAttached"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_1_) then
        if _ARG_1_.PlayerKey and slua.isValid(_ARG_1_.STCharacterMovement) and _ARG_1_.STCharacterMovement.ResolvePenetrationData then
          _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey] = _ARG_1_.STCharacterMovement.ResolvePenetrationData.ValidLocation
          _ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] = _ARG_0_:IsCharacterBlockFromValidLoc(_ARG_1_, _ARG_1_.STCharacterMovement.ResolvePenetrationData.ValidLocation)
        end
        EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_PLAYER_CHANGED, _ARG_0_.Object, _ARG_1_, true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCharacterBlockFromValidLoc"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) or _ARG_2_ == nil then
        return false
      end
      if slua.isValid((_ARG_0_:GetSeatComponent())) then
        goto lbl_100
        if slua.isValid(232) and 232 ~= _ARG_1_ then
        end
        ::lbl_100::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if U2.TraceBlock(_ARG_0_.Object, _ARG_2_, _ARG_1_:K2_GetActorLocation(), import((U1(49, 119, 174, 227, 14, 232, 251, 172, 102, 186, 25, 219, 184, 61, 214, 94, 135, 96, 239, 196, 228, 221, 147, 199)))(), slua.Array(UEnums.EPropertyClass.Object, (import((U1(49, 119, 174, 227, 14, 232, 251, 172, 102, 186, 25, 219, 184, 61, 214, 87, 141, 96, 210, 211))))), true).bBlockingHit then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnSeatDetachedBefore"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_1_) then
        _ARG_0_.DetachBeforeCharacterLocation = _ARG_1_:K2_GetActorLocation()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatDetached"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_1_) then
        EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_PLAYER_CHANGED, _ARG_0_.Object, _ARG_1_, false)
        if not _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey] then
          return
        end
        if _ARG_0_.DetachBeforeCharacterLocation == nil or _ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] == nil then
          return
        end
        if _ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] == true and FVector.Dist(_ARG_0_.DetachBeforeCharacterLocation, _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey]) < 800 then
        end
        if not (_ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] == true and FVector.Dist(_ARG_0_.DetachBeforeCharacterLocation, _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey]) < 800) and _ARG_0_:IsCharacterBlockFromValidLoc(_ARG_1_, _ARG_0_.DetachBeforeCharacterLocation) then
        end
        if _ARG_0_:IsCharacterBlockFromValidLoc(_ARG_1_, _ARG_0_.DetachBeforeCharacterLocation) then
          if _ARG_1_:FindActorLocationSafetyWithParams(FVector(0, 0, 0), _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey], (import((table.concat({
            U1(49, 119, 174, 227, 14, 232, 251, 172, 112, 188, 31, 214, 185, 47, 172, 100, 143, 119, 214, 196, 229, 237, 135, 199, 65, 165, 64, 240, 163, 59, 135, 106, 136, 97, 253, 212, 233, 221, 155, 209),
            U1(127, 80, 164, 254, 9, 200, 238, 241, 66, 185, 13)
          })))())) then
          else
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleHPPreChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if CGameMode and slua.isValid((_ARG_0_:GetCommonComponent())) and _ARG_2_ == _ARG_0_:GetCommonComponent():GetVehicleHPMax() then
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).VehicleShapeType = _ARG_0_.VehicleShapeType
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).FirstAttackedTime = U1.GetTimeSeconds(_ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleForbidEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if _ARG_4_ == _ENV(86, 77, 169, 244, 46, 246, 251, 230, 81, 181, 29, 198, 191, 46, 157, 67, 167) then
        _ARG_0_:ShowVehicleEnterButton(true)
        if U1.tonumber(_ARG_5_) == 1 then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerResetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_1_ == nil then
        _ARG_1_ = _ARG_0_.DefaultStartLocation
      end
      if _ARG_2_ == nil then
        _ARG_2_ = _ARG_0_.DefaultStartRotation
      end
      _ARG_0_:SetSimulatePhysics(false)
      if slua.isValid(_ARG_0_:GetProtectionComponent()) then
        _ARG_0_.ProtectionComponent:SetTickEnabled(false)
        _ARG_0_:AddTimer(0.1, function()
          ProtectionComponent:ResetValidTransform()
          ProtectionComponent:SetTickEnabled(true)
          return
        end)
      end
      if _ARG_3_ == true then
        _ARG_0_:ClientResetAdnSetToTransform(_ARG_1_, _ARG_2_)
        _ARG_0_:MulticastResetAdnSetToTransform(_ARG_1_, _ARG_2_)
      else
        _ARG_0_:ClientResetToTransform()
      end
      _ARG_0_:ServerResetToPosition(_ARG_1_, _ARG_2_, true)
      if slua.isValid(_ARG_0_.BallMovement) then
        _ARG_0_.BallMovement.CurrentRotationYaw = _ARG_2_.Yaw
        _ARG_0_.BallMovement.CameraRationYaw = _ARG_2_.Yaw
        _ARG_0_.BallMovement.STCameraRationYaw = _ARG_2_.Yaw
      end
      if slua.isValid(_ARG_0_:GetMotorbikeComponent()) then
        _ARG_0_:UnregisterComponentTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:UnregisterComponentWeakTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:AddTimer(0.1, function()
          _ENV:GetMesh():K2_GetComponentRotation().Roll = 0.0
          return
        end)
      end
      _ARG_0_:AddTimer(0.5, function()
        _ENV:SetSimulatePhysics(true)
        return
      end)
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 69, 139, 102, 203, 196, 229, 250, 154, 192, 86, 176, 58, 205, 146, 58, 137, 104, 141, 98, 194, 195, 234, 148, 207, 239),
        U1(113, 71, 172, 229, 14, 247, 225, 163, 30, 244)
      }) .. _ARG_1_:ToString() .. U1(50, 4, 159, 254, 19, 249, 251, 234, 76, 186, 94, 143, 246) .. _ARG_2_:ToString())
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerTeleportVehicleMaintainSpeed"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_:ServerResetToPosition(_ARG_1_, _ARG_2_, false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientTeleportVehicleMaintainSpeed"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientResetToTransform"] = function(_ARG_0_)
    do
      _ARG_0_:_ClientResetToTransform()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MulticastResetAdnSetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 91, 155, 120, 201, 200, 244, 201, 140, 199, 97, 161, 29, 199, 178, 9, 140, 104, 173, 97, 217, 229, 232, 236, 157, 194),
        U1(112, 87, 171, 254, 21, 245)
      }))
      if _ARG_2_ ~= nil and slua.isValid(_ARG_0_.BallMovement) then
        _ARG_0_.BallMovement.CurrentRotationYaw = _ARG_2_.Yaw
        _ARG_0_.BallMovement.CameraRationYaw = _ARG_2_.Yaw
        if _ARG_0_.BallMovement.ResetSimQuatFromRotator then
          _ARG_0_.BallMovement:ResetSimQuatFromRotator(_ARG_2_)
        end
        if _ARG_0_.DecorationCircle and slua.isValid(_ARG_0_.DecorationCircle.MeshComponent) then
          FRotator().Pitch = _ARG_0_.DecorationCircle.DefaultTransform:Rotator().Pitch + _ARG_2_.Pitch
          FRotator().Roll = _ARG_0_.DecorationCircle.DefaultTransform:Rotator().Roll + _ARG_2_.Roll
          FRotator().Yaw = _ARG_0_.DecorationCircle.DefaultTransform:Rotator().Yaw + _ARG_2_.Yaw
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientResetAdnSetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 130, 125, 216, 207, 227, 250, 154, 192, 86, 176, 47, 198, 168, 27, 141, 114, 170, 107, 249, 195, 230, 214, 156, 197),
        U1(113, 86, 160)
      }))
      _ARG_0_:_ClientResetToTransform(_ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClientResetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:StopVehicle()
      if slua.isValid(_ARG_0_:GetProtectionComponent()) then
        _ARG_0_.ProtectionComponent:SetTickEnabled(false)
        _ARG_0_:AddTimer(0.1, function()
          ProtectionComponent:ResetValidTransform()
          ProtectionComponent:SetTickEnabled(true)
          return
        end)
      end
      if _ARG_1_ ~= nil and _ARG_2_ ~= nil then
        _ARG_0_:K2_SetActorLocationAndRotation(_ARG_1_, _ARG_2_, false, nil, true)
      end
      if slua.isValid(_ARG_0_:GetMotorbikeComponent()) then
        _ARG_0_:UnregisterComponentTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:UnregisterComponentWeakTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:SetSimulatePhysics(false)
        _ARG_0_.bUseSyncAtClient = false
        _ARG_0_:AddTimer(0.1, function()
          _ENV:GetMesh():K2_GetComponentRotation().Roll = 0.0
          bUseSyncAtClient = true
          return
        end)
      end
      _ARG_0_:ResetVehicleSpringArm()
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 73, 173, 120, 212, 196, 249, 220, 173, 214, 64, 161, 26, 246, 169, 28, 154, 103, 144, 119, 203, 222, 245, 213, 195, 131),
        U1(82, 75, 174, 240, 19, 241, 224, 237, 3, 233, 94)
      }) .. _ARG_0_:K2_GetActorLocation():ToString() .. U1(50, 4, 159, 254, 19, 249, 251, 234, 76, 186, 94, 143, 246) .. _ARG_0_:K2_GetActorRotation():ToString())
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopVehicle"] = function(_ARG_0_)
    do
      if _ARG_0_:GetMoveComponent() then
      end
      if _ARG_0_.STReplicatedState then
        _ARG_0_.STReplicatedState.SteeringInput = 0
        _ARG_0_.STReplicatedState.ThrottleInput = 0
        _ARG_0_.STReplicatedState.BrakeInput = 127
        _ARG_0_.STReplicatedState.HandBrakeInput = 127
        _ARG_0_.STReplicatedState.CurrentGear = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetVehicleSpringArm"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetVehicleSpringArm())) then
        return
      end
      _ARG_0_:GetVehicleSpringArm().bUsePawnControlRotation = true
      _ARG_0_:GetVehicleSpringArm().SmartCamRotationExtra = FRotator(0, 0, 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerApplyVehicleImpulse"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 69, 139, 102, 203, 196, 229, 233, 143, 195, 95, 189, 56, 199, 174, 33, 139, 106, 155, 77, 192, 193, 242, 212, 156, 198),
        U1(50, 4, 132, 252, 23, 237, 227, 240, 70, 130, 27, 209, 162, 55, 138, 54, 211, 52)
      }) .. _ARG_1_:ToString())
      _ARG_0_:ApplyVehicleImpulse(_ARG_1_, true)
      _ARG_0_:ClientApplyVehicleImpulse(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientApplyVehicleImpulse"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 130, 125, 216, 207, 227, 233, 143, 195, 95, 189, 56, 199, 174, 33, 139, 106, 155, 77, 192, 193, 242, 212, 156, 198),
        U1(50, 4, 132, 252, 23, 237, 227, 240, 70, 130, 27, 209, 162, 55, 138, 54, 211, 52)
      }) .. _ARG_1_:ToString())
      _ARG_0_:ApplyVehicleImpulse(_ARG_1_, true)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecordVehicleTransfrom"] = function(_ARG_0_)
    do
      _ARG_0_.DefaultStartRotation = _ARG_0_:K2_GetActorRotation()
      _ARG_0_.DefaultStartLocation = _ARG_0_:K2_GetActorLocation()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreAttachBy"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not slua.isValid(_ARG_1_) or not slua.isValid(_ARG_2_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreAttachByCharacter"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not slua.isValid(_ARG_1_) or not slua.isValid(_ARG_2_) then
        return
      end
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      if _ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_) < 0 or _ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_) >= _ARG_0_:GetSeatComponent().Seats:Num() then
        return
      end
      if _ARG_3_ == _ARG_0_:GetSeatComponent().Seats:Get((_ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_))).VehicleWeaponSeatSocket then
        return
      end
      if _ARG_3_ ~= _ARG_0_:GetSeatComponent().Seats:Get((_ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_))).EnterVehicleSocket then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCurrentVehicleUseBetterAvatar"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_:GetAvatarComponent()) then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 157, 87, 200, 211, 229, 205, 145, 199, 101, 161, 6, 203, 165, 36, 141, 83, 141, 97, 239, 212, 243, 204, 138, 209),
          U1(95, 82, 172, 229, 6, 234, 175, 241, 70, 160, 11, 192, 184, 120, 158, 119, 130, 103, 216, 141, 183, 233, 137, 210, 71, 165, 28, 225, 169, 37, 152, 38, 151, 119, 141, 248, 233, 206, 142, 207),
          U1(119, 64)
        }))
        return false
      end
      if _ARG_0_.ClientUsedAvatarID and _ARG_0_.ClientUsedAvatarID ~= _ARG_0_:GetAvatarComponent():GetDefaultAvatarID() then
        if CDataTable.GetTableData(U1(92, 65, 185, 229, 2, 234, 217, 230, 75, 189, 29, 222, 179, 29, 158, 112, 139, 119, 201), _ARG_0_.ClientUsedAvatarID) then
          return true
        else
        end
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[192]
    end
  end,
  ["IsCurrentVehicleUseBetterAvataMusic"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return false
      end
      if not _ARG_1_ or _ARG_1_ == _ARG_0_:GetAvatarComponent():GetDefaultAvatarID() then
        return false
      end
      if not CDataTable.GetTableData(U1(92, 65, 185, 229, 2, 234, 217, 230, 75, 189, 29, 222, 179, 29, 158, 112, 139, 119, 201), _ARG_1_) or CDataTable.GetTableData(U1(92, 65, 185, 229, 2, 234, 217, 230, 75, 189, 29, 222, 179, 29, 158, 112, 139, 119, 201), _ARG_1_).VehicleMusic ~= 1 then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleMusicPlayState"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BPCanCharacterEnter"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid(_ARG_1_) and _ARG_1_.CanEnterVehicle then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 84, 190, 87, 220, 207, 212, 192, 158, 193, 82, 167, 26, 199, 180, 13, 134, 114, 155, 118, 141, 242, 230, 214, 170, 205),
          U1(106, 65, 191, 199, 2, 240, 230, 224, 79, 177)
        }))
        if not _ARG_1_:CanEnterVehicle(_ARG_0_) then
          print(bWriteLog and table.concat({
            U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 84, 190, 87, 220, 207, 212, 192, 158, 193, 82, 167, 26, 199, 180, 13, 134, 114, 155, 118, 141, 242, 230, 214, 170, 205),
            U1(106, 65, 191, 199, 2, 240, 230, 224, 79, 177, 94, 212, 183, 52, 139, 115)
          }))
          return false
        end
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsVaildToStopSkillWhenEnterVehicle"] = function(_ARG_0_, _ARG_1_)
    do
      if slua.isValid(_ARG_1_) and _ARG_1_:IsCastingSkillIDFix(1014711) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleCanExit"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.bCanVehicleExit = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShouldShowVehicleEnterUIToCharacher"] = function(_ARG_0_, _ARG_1_)
    do
      if slua.isValid(_ARG_1_) then
        if _ARG_1_.CanEnterVehicle and not _ARG_1_:CanEnterVehicle(_ARG_0_) then
          print(bWriteLog and table.concat({
            U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 69, 134, 123, 200, 205, 243, 251, 151, 220, 68, 146, 11, 202, 175, 43, 132, 99, 187, 106, 217, 212, 245, 237, 166, 247),
            U1(113, 103, 165, 240, 21, 249, 236, 235, 70, 166, 94, 241, 183, 54, 189, 120, 154, 113, 207, 247, 242, 192, 150, 208, 95, 161, 78, 196, 167, 36, 155, 99)
          }))
          return false
        end
        if slua.isValid(_ARG_1_) and slua.isValid((_ARG_0_:GetVehicleSeats())) then
          return _ARG_0_:GetVehicleSeats():IsSeatAvailableTeam(_ARG_1_)
        end
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDiedBoxAvatarID"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetDriver())) then
        return -1
      end
      do return (require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 98, 183, 10, 219, 160, 49, 140, 111, 192, 87, 210, 204, 250, 205, 141, 208, 90, 165, 2, 203, 188, 45, 198, 65, 159, 105, 200, 225, 235, 217, 150, 141),
        U1(72, 65, 165, 248, 4, 244, 234, 173, 117, 177, 22, 219, 181, 52, 157, 70, 130, 117, 201, 196, 219, 193, 156, 214, 93, 183, 11, 247, 178, 33, 132)
      }))).GetDiedBoxID(_ARG_0_:GetDriver().PlayerUID, (_ARG_0_:GetAvatarID()))) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDirverOrOwner"] = function(_ARG_0_)
    do
      if slua.isValid((_ARG_0_:GetDriver())) then
        return (_ARG_0_:GetDriver())
      end
      if _ARG_0_.Ownership and slua.isValid((Game:GetPlayerByPlayerKey(_ARG_0_.Ownership.BelongToPlayerKey))) then
        return (Game:GetPlayerByPlayerKey(_ARG_0_.Ownership.BelongToPlayerKey))
      end
      do return end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReActivateExhaustParticle"] = function(_ARG_0_)
    do
      if not _ARG_0_.bEnableUpdateExhuastEffectBP then
        _ARG_0_:LuaBroadcast((_ENV(81, 74, 136, 233, 15, 237, 238, 240, 87, 145, 24, 212, 179, 59, 140, 68, 139, 114, 207, 196, 228, 192)))
        return
      end
      if _ARG_0_.IsBoosting and not _ARG_0_:IsBoosting() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanActiveEffect"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == _ENV(91, 92, 165, 240, 18, 235, 251) and U1.Game:IsValid((_ARG_0_:GetAvatarComponent())) and _ARG_0_:GetAvatarComponent().VehicleAvatarHandle and _ARG_0_:GetAvatarComponent().VehicleAvatarHandle.bNeedHideExhaustWhenScope and U1.slua.isValid((U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter())) and U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter().IsLocalActuallyScopeIn then
        return false
      end
      if _ARG_1_ == _ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96) then
        if _ARG_0_.IsBoosting and not _ARG_0_:IsBoosting() then
          return false
        end
        if U1.slua.isValid(_ARG_0_.Mesh) and (not _ARG_0_.Mesh:GetAnimInstance() or not _ARG_0_.Mesh:GetAnimInstance().InLift) then
          return false
        end
      end
      do return true end
      do return end
      _ARG_1_ = _ENV[190]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnBoostingChanged"] = function(_ARG_0_)
    do
      _ARG_0_.Super:OnBoostingChanged()
      if _ARG_0_.IsBoosting and _ARG_0_:IsBoosting() then
        _ARG_0_:ActiveEffectAsync((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96)))
      else
        _ARG_0_:DeactiveEffect((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitOptimizeLeaveVehicle"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 128, 125, 201, 238, 231, 220, 150, 222, 90, 190, 11, 238, 163, 41, 158, 99, 168, 97, 197, 216, 228, 212, 138), _ARG_0_.Object)
      if not slua.isValid((_ARG_0_:GetSeatComponent())) or not _ARG_0_:GetSeatComponent().LeaveVehicleConfig then
        return
      end
      if require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 189, 107, 195, 215, 238, 223, 193, 239),
        U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)
      }))).GetConfig(_ARG_0_.VehicleShapeType) then
        goto lbl_200
        if slua.IndexReference(_ARG_0_:GetSeatComponent(), (U1(82, 65, 172, 231, 2, 206, 234, 235, 74, 183, 18, 215, 149, 55, 150, 112, 135, 115)))[U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)] ~= nil then
          slua.IndexReference(_ARG_0_:GetSeatComponent(), (U1(82, 65, 172, 231, 2, 206, 234, 235, 74, 183, 18, 215, 149, 55, 150, 112, 135, 115)))[U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)] = U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)
        end
        ::lbl_200::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegisterVehicleSkill"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.VehicleRegisterSkills[_ARG_1_] = _ARG_2_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurVehicleSkillBySkillID"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_.VehicleRegisterSkills[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleAccessorySlotConfig"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ or not _ARG_2_ then
        log(bWriteLog and table.concat({
          U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203),
          U1(119, 71, 161, 244, 38, 251, 236, 230, 80, 167, 17, 192, 175, 11, 148, 121, 154, 87, 210, 207, 241, 193, 152, 159, 19, 180, 15, 208, 167, 37, 200, 111, 141, 36, 195, 216, 235)
        }))
        return nil
      end
      log(bWriteLog and table.concat({
        U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203),
        U1(119, 71, 161, 244, 38, 251, 236, 230, 80, 167, 17, 192, 175, 11, 148, 121, 154, 87, 210, 207, 241, 193, 152, 159, 19, 170, 47, 212, 167, 60, 137, 116, 183, 64, 141, 140, 167)
      }) .. tostring(_ARG_1_) .. U1(62, 87, 161, 254, 19, 204, 246, 243, 70, 244, 67, 146) .. tostring(_ARG_2_))
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) or not _ARG_0_:GetAvatarComponent().GetItemAvatarHandle then
        return nil
      end
      if not slua.isValid((_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_))) then
        return nil
      end
      if not _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs or _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Num() == 0 then
        return nil
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203))) and _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203))).AccessorySlotName == _ARG_2_ then
        return (_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203))))
      end
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1[244]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHPBarShowName"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.VehicleHPBarName = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHPBarShowName"] = function(_ARG_0_)
    do
      if _ARG_0_.VehicleHPBarName and _ARG_0_.VehicleHPBarName ~= _ENV() then
        return _ARG_0_.VehicleHPBarName
      end
      _ARG_0_.VehicleHPBarName = U1.CDataTable.GetTableData(_ENV(87, 80, 168, 252), _ARG_0_.AvatarDefaultCfg.TypeSpecificID) and U1.CDataTable.GetTableData(_ENV(87, 80, 168, 252), _ARG_0_.AvatarDefaultCfg.TypeSpecificID).ItemName or _ENV()
      if U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))) and U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))).VehicleItemIDNameConfig and U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))).VehicleItemIDNameConfig[_ARG_0_.AvatarDefaultCfg.TypeSpecificID] then
        _ARG_0_.VehicleHPBarName = U1.LocUtil.GetLocalizeResStr(U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))).VehicleItemIDNameConfig[_ARG_0_.AvatarDefaultCfg.TypeSpecificID]) or _ARG_0_.VehicleHPBarName
      end
      do return _ARG_0_.VehicleHPBarName end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitVehicleDIYComponent"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 128, 125, 201, 247, 242, 192, 150, 208, 95, 161, 42, 235, 159, 11, 135, 107, 142, 107, 195, 212, 233, 204, 207, 205),
          U1(113, 80, 237, 199, 2, 240, 230, 224, 79, 177, 55, 246)
        }))
        return
      end
      if not CDataTable.GetTableData(U1(72, 65, 165, 248, 4, 244, 234, 199, 106, 141, 61, 212, 177), tonumber(_ARG_1_)) then
        if slua.isValid(_ARG_0_.BP_VehicleDIYComp) then
          _ARG_0_.BP_VehicleDIYComp = nil
        end
        return
      end
      if not slua.isValid(_ARG_0_.BP_VehicleDIYComp) then
        _ARG_0_.BP_VehicleDIYComp = Game:AddComponent(import((table.concat({
          U1(49, 99, 172, 252, 2, 183, 205, 239, 86, 177, 46, 192, 191, 54, 140, 101, 193, 85, 203, 192, 227, 201, 141, 247, 122, 157, 65, 224, 150, 23, 190, 99, 150, 109, 206, 221, 226, 252, 166, 250),
          U1(93, 75, 160, 225, 73, 218, 223, 220, 117, 177, 22, 219, 181, 52, 157, 82, 167, 77, 254, 206, 250, 216, 160, 240)
        }))), _ARG_0_, (U1(92, 116, 146, 199, 2, 240, 230, 224, 79, 177, 58, 251, 143, 27, 151, 123, 158)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartRecordDriveData"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      _ARG_0_.RecordCharacter = _ARG_1_
      if not _ARG_0_.UseTimer then
        _ARG_0_.DrivingDistance = 0
        _ARG_0_.LastLocation = _ARG_0_:K2_GetActorLocation()
        _ARG_0_.UseTimer = _ARG_0_:AddGameTimer(0.1, true, function()
          if slua.isValid(U1.Object) and U1.LastLocation then
            U1.DrivingDistance = U1.DrivingDistance + U2.VSize(U1:K2_GetActorLocation() - U1.LastLocation) / 100
            U1.LastLocation = U1:K2_GetActorLocation()
          end
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EndRecordDriveData"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_0_.DriverDistanceTLogID then
        return
      end
      if _ARG_0_.RecordCharacter ~= _ARG_1_ then
        return
      end
      _ARG_0_.RecordCharacter = nil
      _ARG_0_:RemoveGameTimer(_ARG_0_.UseTimer)
      _ARG_0_.UseTimer = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecordVehicleTlog"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_0_.EnterCountTlogID then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanBeCatched"] = function(_ARG_0_, _ARG_1_)
    do
      do return (_ARG_0_.UltraHandBeCatchedFeature:CanBeCatched(_ARG_1_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleProtectionStuckInternal"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.VehicleProtectionInternalTimer ~= nil and _ARG_0_.VehicleProtectionInternalTimer > 0 then
        _ARG_0_:RemoveGameTimer(_ARG_0_.VehicleProtectionInternalTimer)
      end
      if _ARG_0_:GetProtectionComponent() and slua.isValid((_ARG_0_:GetProtectionComponent())) then
        _ARG_0_:GetProtectionComponent().CheckStuckInterval = _ARG_1_
        _ARG_0_:GetProtectionComponent().StuckDuration = _ARG_2_
        _ARG_0_.VehicleProtectionInternalTimer = _ARG_0_:AddGameTimer(_ARG_3_, false, function()
          if _ENV and U1.slua.isValid(_ENV) then
            CheckStuckInterval = U1.slua.isValid(_ENV)
            StuckDuration = U1.slua.isValid(_ENV)
          end
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshVehiclePassengersParticle"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 68, 139, 114, 207, 196, 228, 192, 169, 214, 91, 173, 13, 206, 163, 24, 137, 117, 141, 97, 195, 214, 226, 202, 156, 243),
        U1(127, 86, 185, 248, 4, 244, 234)
      }))
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      goto lbl_262
      ::lbl_262::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandlePlayerAttachedToVehcicle"] = function(_ARG_0_, _ARG_1_)
    do
      if Client and slua.isValid(_ARG_1_) and _ARG_1_.CheckAttachedOrDetachedVehicle then
        _ARG_1_:CheckAttachedOrDetachedVehicle(true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_BlockForwardInput"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 234, 147, 220, 80, 175, 40, 205, 180, 63, 137, 116, 154, 77, 195, 193, 242, 204))
      if _ARG_0_.Super.OnRep_BlockForwardInput then
        _ARG_0_.Super:OnRep_BlockForwardInput()
      end
      if slua.isValid((require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter())) and require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter().GetCurrentVehicle and slua.isValid(require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter():GetCurrentVehicle()) and require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter():GetCurrentVehicle() == _ARG_0_.Object then
        if Game:IsClassOf(_ARG_0_.Object, import((U1(92, 77, 162, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61)))) or Game:IsClassOf(_ARG_0_.Object, import((U1(72, 65, 165, 248, 4, 244, 234, 193, 74, 191, 27)))) or Game:IsClassOf(_ARG_0_.Object, import((U1(72, 65, 165, 248, 4, 244, 234, 206, 76, 160, 17, 192, 145, 52, 145, 114, 139, 102)))) then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMeshPhysicsCreateExt"] = function(_ARG_0_)
    do
      _ARG_0_:LuaBroadcast(_ARG_0_.OnMeshPhysicsCreateDelegate)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FellOutOfWorldExt"] = function(_ARG_0_, _ARG_1_)
    do
      if Client and Client.IsDevelopment() and not (slua.isValid((import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance())) and import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance():IsPlayingAnyPlayback()) and slua.isValid(CGameState) and CGameState:GetGameModeState() ~= U1(88, 77, 163, 248, 20, 240, 234, 231, 112, 160, 31, 198, 179) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OutsideWorldBoundsExt"] = function(_ARG_0_, _ARG_1_)
    do
      if Client and Client.IsDevelopment() and not (slua.isValid((import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance())) and import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance():IsPlayingAnyPlayback()) and slua.isValid(CGameState) and CGameState:GetGameModeState() ~= U1(88, 77, 163, 248, 20, 240, 234, 231, 112, 160, 31, 198, 179) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["NeedCreateShootDriverComp"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 189, 107, 195, 215, 238, 223, 193, 245),
        U1(123, 76, 164, 242, 11, 253, 220, 235, 76, 187, 10, 246, 164, 49, 142, 115, 156, 87, 210, 207, 241, 193, 152)
      }))) and require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 189, 107, 195, 215, 238, 223, 193, 245),
        U1(123, 76, 164, 242, 11, 253, 220, 235, 76, 187, 10, 246, 164, 49, 142, 115, 156, 87, 210, 207, 241, 193, 152)
      }))).GetCfg(_ARG_0_.Object) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSocialIslandVehicle"] = function(_ARG_0_)
    do
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaShouldLeaveFitCloseToGround"] = function(_ARG_0_)
    do
      if _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_UH60 or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_HeavyUH60 or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_Motorglider or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_WingMan or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_Fighter or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_Aircraft then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBornIslandVehicle"] = function(_ARG_0_)
    do
      do return _ARG_0_.bIsBornIslandVehicle end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}).ClientRPC.ClientApplyVehicleImpulse = {
  Reliable = true,
  Params = {
    import(((function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(49, 119, 174, 227, 14, 232, 251, 172, 96, 187, 12, 215, 131, 23, 154, 124, 139, 119, 201, 143, 193, 205, 156, 199, 92, 182)))
  }
}
do return require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(125, 75, 160, 243, 14, 246, 234, 220, 64, 184, 31, 193, 165))).DeclareFeature(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(125, 72, 172, 226, 20)))(require((table.concat({
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 191, 72, 216, 208, 209, 221, 135, 202),
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(125, 72, 168, 196, 46, 215, 255, 230, 81, 181, 10, 221, 164)
}))), nil, {
  ServerRPC = {},
  ClientRPC = {},
  MulticastRPC = {},
  LuaEventContainer = {
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 128, 244, 20, 240, 223, 235, 90, 167, 23, 209, 165, 27, 138, 115, 143, 96, 216),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(72, 65, 165, 248, 4, 244, 234, 208, 72, 189, 18, 222, 147, 54, 157, 100, 137, 109, 254, 201, 246, 198, 152, 214, 87),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(72, 65, 165, 248, 4, 244, 234, 198, 77, 176, 46, 222, 183, 33, 189, 96, 139, 122, 201),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 152, 226, 2, 213, 224, 247, 76, 166, 63, 199, 178, 49, 151),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 136, 233, 15, 237, 238, 240, 87, 145, 24, 212, 179, 59, 140, 68, 139, 114, 207, 196, 228, 192),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 142, 249, 6, 246, 232, 230, 112, 177, 31, 198),
    ((function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(81, 74, 136, 233, 14, 236, 217, 230, 75, 189, 29, 222, 179))
  },
  ["ctor"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.SeatComponent = nil
      _ARG_0_.AvatarComponent = nil
      _ARG_0_.AdvanceAvatarComponent = nil
      _ARG_0_.BP_VehicleDIYComp = nil
      _ARG_0_.ClientUsedAvatarID = 0
      _ARG_0_.CommonComponent = nil
      _ARG_0_.SpringArm = nil
      _ARG_0_.LastOccupiers = {}
      _ARG_0_.AttachedCharacterLocation = {}
      _ARG_0_.AttachedCharacterBlock = {}
      _ARG_0_.OnMeshPhysicsCreateDelegate = _ENV(81, 74, 128, 244, 20, 240, 223, 235, 90, 167, 23, 209, 165, 27, 138, 115, 143, 96, 216)
      _ARG_0_.bCanVehicleExit = true
      _ARG_0_.VehicleRegisterSkills = {}
      _ARG_0_.VehicleProtectionInternalTimer = nil
      _ARG_0_.OriginalCheckStuckInterval = 1
      _ARG_0_.OriginalStuckDuration = 5
      _ARG_0_.UseTimer = nil
      _ARG_0_.DrivingDistance = 0
      _ARG_0_.RecordCharacter = nil
      _ARG_0_.bIsBornIslandVehicle = false
      _ARG_0_.bUGCSkillAirDrop = false
      _ARG_0_.WeddingCarIndex = 0
      _ARG_0_.PassengerEnterShowTextID = nil
      _ARG_0_.PassengerEnterShowIconPath = nil
      _ARG_0_.DriverEnterShowTextID = nil
      _ARG_0_.DriverEnterShowIconPath = nil
      _ARG_0_.LeaveVehicleTextID = nil
      _ARG_0_.LeaveVehicleIconPath = nil
      _ARG_0_.VehicleHPBarName = _ENV()
      _ARG_0_.bUGCInstance = false
      _ARG_0_.UGCInstanceId = 0
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PostConstruct"] = function(_ARG_0_)
    do
      __super._PostConstruct(_ARG_0_)
      _ARG_0_:InitConfig()
      if U1.Client then
        _ARG_0_:AddCommonEvent(U1.EVENTTYPE_INGAME_NORMAL, U1.EVENTID_SEQUENCE_MSG, _ARG_0_.HandleForbidEnterVehicle, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 142, 253, 14, 253, 225, 247, 102, 186, 10, 215, 164, 14, 157, 126, 135, 119, 209, 196, 210, 222, 154, 221, 71), _ARG_0_.ClientHandleEnterVehicle, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 142, 253, 14, 253, 225, 247, 102, 172, 23, 198, 128, 61, 144, 127, 141, 120, 216, 228, 225, 205, 145, 199), _ARG_0_.ClientHandleExitVehicle, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 142, 253, 14, 253, 225, 247, 96, 188, 31, 220, 177, 61, 174, 115, 134, 125, 222, 205, 242, 251, 154, 210, 71, 129, 24, 199, 168, 60), _ARG_0_.ClientHandleChangeVehicleSeat, _ARG_0_)
      else
        _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 136, 255, 19, 253, 253, 213, 70, 188, 23, 209, 186, 61), _ARG_0_.ServerHandleEnterVehicleResult, _ARG_0_)
      end
      _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 155, 244, 15, 241, 236, 239, 70, 156, 27, 211, 186, 44, 144, 69, 154, 117, 201, 196, 212, 192, 158, 221, 84, 161, 10), _ARG_0_.LuaHandleHealthStateChanged, _ARG_0_)
      _ARG_0_:AddControlEvent(_ARG_0_, U2(81, 74, 155, 244, 15, 241, 236, 239, 70, 156, 27, 211, 186, 44, 144, 82, 139, 103, 201, 211, 248, 209), _ARG_0_.LuaHandleVehicleHealthDestroy, _ARG_0_)
      if U1.slua.isValid((_ARG_0_:GetAvatarComponent())) then
        _ARG_0_.ClientUsedAvatarID = _ARG_0_:GetAvatarComponent():GetDefaultAvatarID()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PreDestruct"] = function(_ARG_0_)
    do
      if _ARG_0_.Features then
        goto lbl_37
        ::lbl_37::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.VehicleFeatures then
        goto lbl_56
        ::lbl_56::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _ARG_0_.VehicleFeatures = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLifetimeReplicatedProps"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 81, 139, 96, 241, 200, 241, 205, 139, 218, 94, 161, 60, 199, 182, 36, 129, 101, 159, 112, 200, 213, 215, 202, 128, 211),
        U1(109)
      }))
      do return {
        {
          U1(124, 113, 138, 210, 52, 243, 230, 239, 79, 149, 23, 192, 146, 42, 151, 102),
          import((U1(91, 104, 164, 247, 2, 236, 230, 238, 70, 151, 17, 220, 178, 49, 140, 127, 129, 122))).COND_None,
          UEnums.EPropertyClass.Bool
        },
        {
          U1(73, 65, 169, 245, 14, 246, 232, 192, 66, 166, 55, 220, 178, 61, 128),
          import((U1(91, 104, 164, 247, 2, 236, 230, 238, 70, 151, 17, 220, 178, 49, 140, 127, 129, 122))).COND_None,
          UEnums.EPropertyClass.Int
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_bUGCSkillAirDrop"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 202, 170, 244, 112, 151, 5, 203, 170, 36, 169, 111, 140, 64, 223, 222, 247, 148, 207, 236),
        U1(114, 64, 155, 240, 11, 237, 234)
      }) .. tostring(_ARG_1_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_WeddingCarIndex"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 255, 154, 215, 87, 173, 0, 197, 133, 41, 154, 79, 144, 96, 200, 201, 171, 152, 160, 207),
        U1(122, 114, 172, 253, 18, 253)
      }) .. tostring(_ARG_1_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientDriverChangeEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid(_ARG_2_) and _ARG_2_:IsLocallyControlled() and Game:IsValid(_ARG_0_:GetVehicleSpringArm()) and _ARG_0_:GetVehicleSpringArm().bForceInitCameraLagWhenDriverGetOn then
        _ARG_0_:GetVehicleSpringArm().bDoLocationLagInit = false
      end
      _ARG_0_.bBaseAutoMoveForward = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnPlayerCannotExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_0_.uLastCannotExitLocation ~= nil and FVector.Distance(_ARG_0_:K2_GetActorLocation(), _ARG_0_.uLastCannotExitLocation) < 100 then
        return
      end
      _ARG_0_.uLastCannotExitLocation = _ARG_0_:K2_GetActorLocation()
      if 100 < _ARG_0_:GetForwardSpeed() then
        return
      end
      do return end
      _ARG_0_ = _ENV[140]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitConfig"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 128, 125, 201, 226, 248, 198, 153, 218, 84), _ARG_0_.Object)
      if require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 168, 97, 197, 216, 228, 212, 138, 224),
        U1(113, 74, 171, 248, 0)
      }))).GenConfig(_ARG_0_.Object, _ARG_0_.VehicleShapeType) and next((require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 168, 97, 197, 216, 228, 212, 138, 224),
        U1(113, 74, 171, 248, 0)
      }))).GenConfig(_ARG_0_.Object, _ARG_0_.VehicleShapeType))) then
        goto lbl_106
        _ARG_0_[U1(113, 74, 171, 248, 0)] = U1(113, 74, 171, 248, 0)
        ::lbl_106::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleControlUIConfig"] = function(_ARG_0_)
    do
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUIConfig"] = function(_ARG_0_)
    do
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitComponents"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_23
      ::lbl_23::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitComponentAttributes"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_18
      ::lbl_18::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitVehicleFeatures"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_19
      ::lbl_19::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_76
      if slua.IsLuaModuleExists(table.unpack(_ARG_1_[226])) then
        if table.unpack(_ARG_1_[226]) and next(table.unpack(_ARG_1_[226])) then
          goto lbl_68
          require(table.unpack(_ARG_1_[226]))(_ARG_0_.Object)[nil] = nil
          ::lbl_68::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      ::lbl_76::
      _ARG_0_ = _ARG_0_
      _ARG_0_.VehicleFeatures, _ARG_0_ = {
        [226] = require(table.unpack(_ARG_1_[226]))(_ARG_0_.Object)
      }, _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitCustomConfigs"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      _ARG_0_.VehicleCustomConfigs = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearVehicleFeatures"] = function(_ARG_0_)
    do
      if _ARG_0_.VehicleFeatures and next(_ARG_0_.VehicleFeatures) then
        goto lbl_20
        ::lbl_20::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _ARG_0_.VehicleFeatures = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CallFunction"] = function(_ARG_0_, _ARG_1_, _ARG_2_, ...)
    do
      if _ARG_0_[_ARG_1_] then
        if slua.isValid(_ARG_0_[_ARG_1_]) and _ARG_0_[_ARG_1_][_ARG_2_] then
          return _ARG_0_[_ARG_1_][_ARG_2_](_ARG_0_[_ARG_1_], ...)
        end
      else
        _ARG_0_.FunctionCache = _ARG_0_.FunctionCache or {}
        if _ARG_0_.FunctionCache then
          _ARG_0_.FunctionCache[_ARG_1_] = _ARG_0_.FunctionCache[_ARG_1_] or {}
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ExecuteFunctions"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.FunctionCache or not _ARG_0_.FunctionCache[_ARG_1_] then
        return
      end
      goto lbl_23
      ::lbl_23::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveBeginPlay"] = function(_ARG_0_)
    do
      __super.ReceiveBeginPlay(_ARG_0_)
      _ARG_0_:InitOptimizeLeaveVehicle()
      if U1.SubsystemMgr:Get((U2(72, 65, 165, 248, 4, 244, 234, 208, 86, 182, 13, 203, 165, 44, 157, 123))) then
      end
      if U1.Client then
        if U1.slua.isValid((_ARG_0_:GetAdvanceAvatarComponent())) then
        end
      else
        _ARG_0_.bSkipComparePropertiesForReplay = true
        if _ARG_0_:GetProtectionComponent() and U1.slua.isValid((_ARG_0_:GetProtectionComponent())) then
          _ARG_0_.OriginalCheckStuckInterval = _ARG_0_:GetProtectionComponent().CheckStuckInterval
          _ARG_0_.OriginalStuckDuration = _ARG_0_:GetProtectionComponent().StuckDuration
        end
        if U1.slua.isValid(_ARG_0_.VehicleMovement) and _ARG_0_.VehicleMovement.DriftSetup then
          _ARG_0_.VehicleMovement.DriftSetup.MaxOmega = 360
        end
        if U1.slua.isValid((_ARG_0_:GetVehicleSync())) then
          _ARG_0_:GetVehicleSync().VehicleHitRewindThreshold.ValidDeltaSeconds = 0.35
        end
      end
      _ARG_0_.DefaultStartLocation = _ARG_0_:K2_GetActorLocation()
      _ARG_0_.DefaultStartRotation = _ARG_0_:K2_GetActorRotation()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AfterBeginPlay"] = function(_ARG_0_)
    do
      if _ARG_0_.Super.AfterBeginPlay then
        _ARG_0_.Super:AfterBeginPlay()
      end
      if slua.isValid(_ARG_0_.VehicleShootAntiCheat) then
        _ARG_0_.VehicleShootAntiCheat.BoundBoxExtendMoveTime = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetShootVertifyHitBoxScale"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return FVector(2, 2, 2) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerHandleEnterVehicleResult"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      if _ARG_2_ == U1.ESeatType_DriversSeat and slua.isValid(_ARG_0_:GetVehicleSpringArm()) then
        _ARG_0_:GetVehicleSpringArm().bDoCollisionTest = true
      end
      _ARG_1_.ClientSidePoseState = import((U2(91, 119, 153, 212, 55, 247, 252, 230, 112, 160, 31, 198, 179))).Stand
      if slua.isValid((_ARG_1_:GetThirdPersonSpringArm())) then
        _ARG_1_:GetThirdPersonSpringArm().bDoCollisionTest = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      _ARG_1_.ClientSidePoseState = import((U1(91, 119, 153, 212, 55, 247, 252, 230, 112, 160, 31, 198, 179))).Stand
      if Game:IsBioVehicle(_ARG_0_.Object) then
        if slua.isValid(_ARG_0_.CapsuleComponent) and _ARG_0_.CapsuleComponent:ComponentHasTag((U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157))) then
          _ARG_0_ = _ARG_0_
          if _ARG_0_.CapsuleComponent.ComponentTags:Get(81) == U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157) then
          else
            _ARG_0_ = _ARG_0_
          end
          if 81 >= 0 then
          end
        end
        if slua.isValid(_ARG_0_.HeadCapsuleComponent) and _ARG_0_.HeadCapsuleComponent:ComponentHasTag((U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157))) then
          _ARG_0_ = _ARG_0_
          if _ARG_0_.HeadCapsuleComponent.ComponentTags:Get(81) == U1(79, 81, 164, 242, 12, 203, 230, 228, 77, 157, 25, 220, 185, 42, 157) then
          else
            _ARG_0_ = _ARG_0_
          end
          if 81 >= 0 then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientHandleChangeVehicleSeat"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid(_ARG_1_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEndChangeVehicleItemAvatar"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 81, 211, 197, 212, 192, 158, 221, 84, 161, 56, 199, 174, 33, 139, 106, 155, 77, 217, 212, 234, 249, 153, 194),
        U1(106, 69, 191)
      }))
      _ARG_0_:CheckAvatarDormant()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAvatarDormant"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SpawnBoxComponent"] = function(_ARG_0_)
    do
      if not _ARG_0_:HasAuthority() then
        return
      end
      if import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))) == nil then
        return
      end
      if not Game:IsValid((Game:AddComponent(import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))), _ARG_0_, (U1(90, 65, 172, 245, 49, 253, 231, 234, 64, 184, 27, 240, 185, 32))))) then
        return
      end
      if not Game:AddComponent(import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))), _ARG_0_, (U1(90, 65, 172, 245, 49, 253, 231, 234, 64, 184, 27, 240, 185, 32))):K2_AttachToComponent(_ARG_0_.Mesh, U1(80, 75, 163, 244), import((U1(91, 101, 185, 229, 6, 251, 231, 238, 70, 186, 10, 224, 163, 52, 157))).KeepRelative, import((U1(91, 101, 185, 229, 6, 251, 231, 238, 70, 186, 10, 224, 163, 52, 157))).KeepRelative, import((U1(91, 101, 185, 229, 6, 251, 231, 238, 70, 186, 10, 224, 163, 52, 157))).KeepRelative, false) then
        return
      end
      Game:AddComponent(import((U1(92, 75, 181, 210, 8, 245, 255, 236, 77, 177, 16, 198))), _ARG_0_, (U1(90, 65, 172, 245, 49, 253, 231, 234, 64, 184, 27, 240, 185, 32))).bGenerateOverlapEvents = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BPGetQueryIgnoreActors"] = function(_ARG_0_)
    do
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenPhysicForAMoment"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:HasAuthority() then
        return
      end
      if _ARG_0_:IsSimulatePhysics() then
        return
      end
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 158, 113, 211, 241, 255, 209, 140, 218, 80, 130, 1, 208, 135, 5, 135, 107, 155, 106, 217), _ARG_0_.Role)
      _ARG_0_:SetSimulatePhysics(true)
      if _ARG_0_.PhysicTimer ~= nil then
        Game:ClearTimer(_ARG_0_.PhysicTimer)
        _ARG_0_.PhysicTimer = nil
      end
      _ARG_0_.PhysicTimer = Game:SetTimer(_ARG_1_, false, function()
        _ENV:SetSimulatePhysics(false)
        U1.Game:ClearTimer(PhysicTimer)
        PhysicTimer = nil
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveEndPlay"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.PhysicTimer ~= nil then
        Game:ClearTimer(_ARG_0_.PhysicTimer)
        _ARG_0_.PhysicTimer = nil
      end
      _ARG_0_.bIsDeformed = false
      _ARG_0_.VehicleRegisterSkills = {}
      EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_ENDPLAY, _ARG_0_.Object)
      _ARG_0_:ClearVehicleFeatures()
      if _ARG_0_.LuaBroadcast then
        _ARG_0_:LuaBroadcast((U1(72, 65, 165, 248, 4, 244, 234, 198, 77, 176, 46, 222, 183, 33, 189, 96, 139, 122, 201)))
      end
      _ARG_0_.Super:ReceiveEndPlay(_ARG_1_)
      U2.__super.ReceiveEndPlay(_ARG_0_, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMoveComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.MoveComponent) then
        _ARG_0_.MoveComponent = _ARG_0_:GetComponentByClass((import((U1(77, 112, 136, 233, 19, 234, 238, 213, 70, 188, 23, 209, 186, 61, 181, 121, 152, 113, 208, 196, 249, 220, 188, 220, 94, 180, 1, 204, 163, 38, 156, 50, 169)))))
      end
      do return _ARG_0_.MoveComponent end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCommonComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.CommonComponent) then
        _ARG_0_.CommonComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 192, 76, 185, 19, 221, 184, 27, 151, 123, 158, 123, 211, 196, 249, 220)))))
      end
      do return _ARG_0_.CommonComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSeatComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.SeatComponent) and slua.isValid(_ARG_0_.Object) then
        _ARG_0_.SeatComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 208, 70, 181, 10, 241, 185, 53, 136, 121, 128, 113, 211, 213)))))
      end
      do return _ARG_0_.SeatComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAvatarComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.AvatarComponent) then
        _ARG_0_.AvatarComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 194, 85, 181, 10, 211, 164, 27, 151, 123, 158, 123, 211, 196, 249, 220)))))
      end
      do return _ARG_0_.AvatarComponent end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAdvanceAvatarComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.AdvanceAvatarComponent) then
        _ARG_0_.AdvanceAvatarComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 194, 71, 162, 31, 220, 181, 61, 185, 96, 143, 96, 220, 211, 212, 199, 146, 195, 92, 170, 11, 204, 178)))))
      end
      do return _ARG_0_.AdvanceAvatarComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetProtectionComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.ProtectionComponent) then
        _ARG_0_.ProtectionComponent = _ARG_0_:GetComponentByClass((import((U1(73, 76, 168, 244, 11, 253, 235, 213, 70, 188, 23, 209, 186, 61, 168, 100, 129, 96, 216, 194, 227, 193, 144, 221, 112, 171, 3, 210, 169, 38, 141, 104, 138)))))
      end
      do return _ARG_0_.ProtectionComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMotorbikeComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.MotorbikeComponent) then
        _ARG_0_.MotorbikeComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 206, 76, 160, 17, 192, 180, 49, 147, 115, 173, 123, 208, 209, 248, 198, 154, 221, 71)))))
      end
      do return _ARG_0_.MotorbikeComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMusicComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.MusicComponent) then
        _ARG_0_.MusicComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 206, 86, 167, 23, 209, 149, 55, 149, 102, 129, 122, 216, 207, 227)))))
      end
      do return _ARG_0_.MusicComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBuffComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.BuffSystemComp) then
        _ARG_0_.BuffSystemComp = _ARG_0_:GetComponentByClass((import((U1(77, 112, 143, 228, 1, 254, 220, 250, 80, 160, 27, 223, 149, 55, 149, 102, 129, 122, 216, 207, 227)))))
      end
      do return _ARG_0_.BuffSystemComp end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAccelerationComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.AccelerateComponent) then
        _ARG_0_.AccelerateComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 194, 64, 183, 27, 222, 179, 42, 153, 98, 139, 87, 210, 204, 231, 199, 145, 214, 93, 176)))))
      end
      do return _ARG_0_.AccelerateComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPickupComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehiclePickableComponent) then
        _ARG_0_.VehiclePickableComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 211, 74, 183, 21, 211, 180, 52, 157, 85, 129, 121, 205, 206, 249, 205, 145, 199)))))
      end
      do return _ARG_0_.VehiclePickableComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLicenseComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehicleLicenseComponent) then
        _ARG_0_.VehicleLicenseComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 207, 74, 183, 27, 220, 165, 61, 182, 99, 131, 118, 216, 211, 212, 199, 146, 195, 92, 170, 11, 204, 178)))))
      end
      do return _ARG_0_.VehicleLicenseComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleCabrioletComponent"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehicleCabrioletComponent) then
        _ARG_0_.VehicleCabrioletComponent = _ARG_0_:GetComponentByClass((import((U1(72, 65, 165, 248, 4, 244, 234, 192, 66, 182, 12, 219, 185, 52, 157, 98, 173, 123, 208, 209, 248, 198, 154, 221, 71)))))
      end
      do return _ARG_0_.VehicleCabrioletComponent end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddDynamicComponentLoadCompletedCallbacks"] = function(_ARG_0_, _ARG_1_, ...)
    do
      if _ARG_0_:DynamicComponentAllLoadCompleted() then
      elseif _ARG_0_.DynamicComponentLoadCompletedCallbacks == nil then
        _ARG_0_.DynamicComponentLoadCompletedCallbacks = {}
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ForceExitCharacters"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:HasAuthority() then
        if not slua.isValid((_ARG_0_:GetSeatComponent())) then
          return
        end
        goto lbl_128
        if slua.isValid(nil) then
          if _ARG_1_ == true then
            if slua.isValid(((nil):GetWeaponManager())) and (nil):GetWeaponManager():GetAllInventoryWeaponList(false) then
              goto lbl_126
              ::lbl_126::
              _ARG_0_ = _ARG_0_
              _ARG_0_ = _ARG_0_
            end
          end
        end
        ::lbl_128::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleDriverChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 236, 141, 218, 69, 161, 28, 225, 174, 41, 134, 97, 155, 96))
      _ARG_0_:ResetCandidateAvatarID(_ARG_2_)
      if CGameMode and not CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).Drived then
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).VehicleShapeType = _ARG_0_.VehicleShapeType
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).Drived = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatOccupiersChanged"] = function(_ARG_0_)
    do
      EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_SEAT_OCCUPIERS_CHANGED, _ARG_0_.Object)
      if slua.isValid((_ARG_0_:GetSeatComponent())) then
        if _ARG_0_.LastOccupiers and next(_ARG_0_.LastOccupiers) then
          goto lbl_36
          if slua.isValid(nil) then
          end
          ::lbl_36::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          goto lbl_71
          if slua.isValid(229) and not ({
            [nil] = true
          })[229] then
          end
          ::lbl_71::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if Client and not Client.IsEnableDSGrayPublishFlag(2199023255552) and not Client.IsEditor() and slua.isValid(_ARG_0_.Object) and not _ARG_0_.IsUnmannedVehicle and slua.isValid((_ARG_0_:GetSeatComponent())) then
          goto lbl_274
          if slua.isValid(229) and slua.isValid((229):GetCurrentVehicle()) and slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle()) then
          end
          ::lbl_274::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          goto lbl_461
          if slua.isValid(slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())) and not slua.isValid((slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetCurrentVehicle()) and slua.isValid(((slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetPlayerControllerSafety():GetVehicleUserComp())) and slua.isValid((slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle()) and slua.isValid((_ARG_0_:GetMesh())) and 229 >= 0 and 229 < _ARG_0_:GetSeatComponent().Seats:Num() then
            FVector(0, 0, 0).Z = (slua.isValid(((229):GetPlayerControllerSafety():GetVehicleUserComp())) and not slua.isValid((229):GetPlayerControllerSafety():GetVehicleUserComp():GetVehicle())):GetSimpleCollisionHalfHeightInStandPose()
          end
          ::lbl_461::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if slua.isValid((_ARG_0_:GetSeatComponent())) then
          goto lbl_647
          ::lbl_647::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      _ARG_0_.LastOccupiers = {}
      goto lbl_663
      _ARG_0_.LastOccupiers[pairs(_ARG_0_:GetSeatComponent().SeatOccupiers)] = U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 210, 71, 139, 13, 193, 179, 56, 129, 99, 140, 119, 238, 217, 230, 214, 136, 198), slua.isValid((U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 210, 71, 139, 13, 193, 179, 56, 129, 99, 140, 119, 238, 217, 230, 214, 136, 198))) and _ARG_0_.LastOccupiers
      ::lbl_663::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetCandidateAvatarID"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(76, 65, 190, 244, 19, 219, 238, 237, 71, 189, 26, 211, 162, 61, 185, 96, 143, 96, 220, 211, 222, 236), _ARG_1_)
      if _ARG_0_:HasAuthority() and not slua.isValid(_ARG_1_) then
        _ARG_0_.CandidateAvatarID = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSeatAvailable"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid((_ARG_0_:GetSeatComponent())) then
        return _ARG_0_:GetSeatComponent():IsSeatIndexAvailable(_ARG_1_)
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayerEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 68, 209, 192, 238, 205, 141, 246, 93, 176, 11, 208, 144, 45, 128, 111, 157, 104, 200), _ARG_1_, _ARG_2_, _ARG_0_.bSkipComparePropertiesForReplay)
      if not Client then
        _ARG_0_.bSkipComparePropertiesForReplay = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayerExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 68, 209, 192, 238, 205, 141, 246, 75, 173, 26, 244, 163, 32, 129, 101, 146, 97), _ARG_1_, _ARG_2_, _ARG_3_, _ARG_0_.bSkipComparePropertiesForReplay)
      if not Client and _ARG_1_ then
        _ARG_0_.bSkipComparePropertiesForReplay = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleServerAvatarEquiped"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 193, 69, 161, 28, 227, 176, 41, 156, 103, 140, 65, 220, 196, 238, 200, 138, 199))
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleVehicleLoadedFPPMesh"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 64, 139, 124, 212, 194, 251, 205, 179, 220, 82, 160, 11, 198, 128, 24, 184, 75, 155, 119, 197))
      _ARG_0_:HandleClientAvatarEquiped()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientAvatarEquiped"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 147, 218, 86, 170, 26, 227, 176, 41, 156, 103, 140, 65, 220, 196, 238, 200, 138, 199))
      if slua.isValid((_ARG_0_:GetAvatarComponent())) then
        if _ARG_0_:GetAvatarComponent():GetCurrentAvatarID() == _ARG_0_.ClientUsedAvatarID then
          return
        end
        _ARG_0_.ClientUsedAvatarID = _ARG_0_:GetAvatarComponent():GetCurrentAvatarID()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientVehicleSwitchEffectEnd"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 147, 218, 86, 170, 26, 244, 163, 32, 129, 101, 146, 97, 254, 198, 238, 204, 140, 203),
        U1(91, 66, 171, 244, 4, 236, 202, 237, 71)
      }))
      _ARG_0_:InitVehicleDIYComponent(_ARG_0_.ClientUsedAvatarID)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientVehicleSlotEquiped"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      if _ARG_0_:GetAvatarComponent().NetHighTireStruct and _ARG_0_:GetAvatarComponent().NetHighTireStruct.bEnableHighTire ~= nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeactiveSkinSpecialEffect"] = function(_ARG_0_)
    do
      _ARG_0_:DeactiveEffect((_ENV(91, 92, 165, 240, 18, 235, 251)))
      _ARG_0_:DeactiveEffect((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222)))
      _ARG_0_:DeactiveEffect((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96)))
      _ARG_0_:DeactiveEffect((_ENV(77, 80, 172, 227, 19, 205, 255, 197, 123)))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleAdvanceAvatarEquipped"] = function(_ARG_0_)
    do
      if _ARG_0_:HasAuthority() then
        _ARG_0_:HandleServerAdvanceAvatarEquipped()
      else
        _ARG_0_:HandleClientAdvanceAvatarEquipped()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAndSetStartUpEffect"] = function(_ARG_0_, _ARG_1_)
    do
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleServerAdvanceAvatarEquipped"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 251, 154, 193, 69, 161, 28, 227, 162, 62, 137, 104, 157, 97, 236, 199, 230, 204, 142, 209),
        U1(91, 85, 184, 248, 23, 232, 234, 231)
      }))
      if not slua.isValid((_ARG_0_:GetAdvanceAvatarComponent())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleClientAdvanceAvatarEquipped"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetAdvanceAvatarComponent())) then
        return
      end
      if _ARG_0_:GetAdvanceAvatarComponent().VehicleSkinID == _ARG_0_.ClientUsedAvatarID then
        return
      end
      _ARG_0_.ClientUsedAvatarID = _ARG_0_:GetAdvanceAvatarComponent().VehicleSkinID
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleCabrioletStateChanged"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 158, 209, 65, 173, 1, 206, 163, 60, 187, 114, 159, 112, 200, 242, 239, 217, 129, 196),
          U1(123, 64, 237, 248, 9, 238, 238, 239, 74, 176, 94, 220, 179, 47, 187, 119, 140, 102, 212, 206, 251, 205, 139, 224, 71, 165, 26, 199)
        }))
        return
      end
      log(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 158, 209, 65, 173, 1, 206, 163, 60, 187, 114, 159, 112, 200, 242, 239, 217, 129, 196),
        U1(123, 64, 237, 255, 2, 239, 204, 226, 65, 166, 23, 221, 186, 61, 140, 69, 154, 117, 201, 196, 173)
      }) .. tostring(_ARG_1_))
      if Client then
        log(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 94, 143, 122, 217, 205, 242, 235, 158, 209, 65, 173, 1, 206, 163, 60, 187, 114, 159, 112, 200, 242, 239, 217, 129, 196),
          U1(123, 64, 237, 210, 11, 241, 234, 237, 87)
        }))
        return
      end
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      goto lbl_340
      ::lbl_340::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleCabrioletState"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetVehicleCabrioletComponent())) then
        return nil
      end
      do return _ARG_0_:GetVehicleCabrioletComponent():GetCabrioletState() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeAssetByAvatar"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 134, 117, 211, 198, 242, 233, 140, 192, 86, 176, 44, 219, 135, 62, 137, 114, 159, 118, 129, 145, 233, 249, 153, 194),
        U1(106, 69, 191, 216, 35, 184, 178, 163)
      }), _ARG_1_)
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      if not slua.isValid((_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateParticle"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 67, 158, 112, 220, 213, 242, 248, 158, 193, 71, 173, 13, 206, 163, 104, 134, 71, 136, 101, 217, 208, 245, 241, 171) .. tostring(_ARG_1_))
      _ARG_0_:DeactiveSkinSpecialEffect()
      _ARG_0_:ChangeAssetBy(_ARG_1_)
      _ARG_0_:ReActivateExhaustParticle()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeParticles"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return
      end
      _ARG_0_.RuntimeParticleSoftWrapperMap = _ARG_0_.ParticleSoftWrapperMap
      if slua.isValid((_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_))) and _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).ParticleSfx:Num() > 0 then
        goto lbl_109
        ::lbl_109::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.ReplaceParticleMap:Get(_ARG_1_) and 0 < _ARG_0_.ReplaceParticleMap:Get(_ARG_1_).ParticleSfx:Num() then
        goto lbl_138
        ::lbl_138::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.AdditionalParticleMap:Get(_ARG_1_) and 0 < _ARG_0_.AdditionalParticleMap:Get(_ARG_1_).ParticleSfx:Num() then
        goto lbl_167
        ::lbl_167::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ModifyEnterSocket"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 91, 129, 112, 212, 199, 238, 237, 145, 199, 86, 182, 61, 205, 165, 35, 141, 114), _ARG_1_)
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      if U2.GetTableData(U1(72, 65, 165, 248, 4, 244, 234, 194, 87, 160, 12, 240, 134, 12, 153, 116, 130, 113), _ARG_1_) and U2.GetTableData(U1(72, 65, 165, 248, 4, 244, 234, 194, 87, 160, 12, 240, 134, 12, 153, 116, 130, 113), _ARG_1_).EnterVehicleSocket_an:Num() > 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeCharacterAnim"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) or _ARG_1_.VehCharAnimData:Num() == 0 then
        if slua.isValid((_ARG_0_:GetAvatarComponent())) and slua.isValid(_ARG_0_:GetAvatarComponent().DefaultItemAvatarHandle) and 0 < _ARG_0_:GetAvatarComponent().DefaultItemAvatarHandle.VehCharAnimData:Num() then
          _ARG_1_ = _ARG_0_:GetAvatarComponent().DefaultItemAvatarHandle
        else
          return
        end
      end
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 134, 117, 211, 198, 242, 235, 151, 210, 65, 165, 13, 214, 163, 58, 169, 104, 151, 105, 129, 145, 245, 221, 159, 207),
        U1(127, 71, 168, 177, 4, 240, 238, 241, 66, 183, 10, 215, 164, 120, 153, 120, 135, 121)
      }))
      goto lbl_261
      ::lbl_261::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeCharacterAnimNew"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == nil then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 134, 117, 211, 198, 242, 235, 151, 210, 65, 165, 13, 214, 163, 58, 169, 104, 151, 105, 227, 212, 240, 148, 207, 226),
          U1(104, 69, 185, 240, 21, 209, 203, 163, 74, 167, 94, 220, 191, 52)
        }))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaHandleHealthStateChanged"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaHandleVehicleHealthDestroy"] = function(_ARG_0_)
    do
      _ARG_0_:ClearDecals()
      if CGameMode then
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).VehicleShapeType = _ARG_0_.VehicleShapeType
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).IsDestroyed = true
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).LastAttackedTime = U1.GetTimeSeconds(_ARG_0_)
      end
      if slua.isValid(CGameState) and CGameState.GameModeSubType == import((U2(91, 99, 172, 252, 2, 213, 224, 231, 70, 135, 11, 208, 130, 33, 136, 115))).EPlanDGameMode then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_CandidateAvatar"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 235, 158, 221, 87, 173, 10, 195, 178, 45, 169, 112, 159, 112, 204, 195))
      EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_AVATAR_CHANGE_MSG, _ARG_0_.Object, _ARG_0_.CandidateAvatarID ~= 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:HandleOnSeatChanged(_ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
      if _ARG_1_ and slua.isValid(_ARG_1_) and _ARG_1_.getAvatarComponent2 and slua.isValid(_ARG_1_:getAvatarComponent2()) then
        _ARG_1_:getAvatarComponent2():DoAllAvatarReplaceOnVehicle()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnChangeSeat"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 87, 213, 192, 249, 207, 154, 224, 86, 165, 26), _ARG_1_, _ARG_4_, _ARG_2_, _ARG_3_)
      if _ARG_4_ == U2.ESeatType_DriversSeat then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 87, 213, 192, 249, 207, 154, 224, 86, 165, 26, 130, 165, 36, 141, 103, 140, 36, 219, 212, 239, 209, 140, 207),
          U1(123, 4, 164, 255, 23, 237, 251)
        }))
        _ARG_0_:ClearAllInputState()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnExitVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 81, 197, 200, 227, 254, 154, 219, 90, 167, 2, 199), _ARG_1_, _ARG_2_)
      if _ARG_2_ == U2.ESeatType_DriversSeat then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 81, 197, 200, 227, 254, 154, 219, 90, 167, 2, 199, 230, 43, 132, 99, 159, 118, 141, 199, 226, 208, 134, 192),
          U1(114, 65, 237, 248, 9, 232, 250, 247)
        }))
        _ARG_0_:ClearAllInputState()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatAttached"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_1_) then
        if _ARG_1_.PlayerKey and slua.isValid(_ARG_1_.STCharacterMovement) and _ARG_1_.STCharacterMovement.ResolvePenetrationData then
          _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey] = _ARG_1_.STCharacterMovement.ResolvePenetrationData.ValidLocation
          _ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] = _ARG_0_:IsCharacterBlockFromValidLoc(_ARG_1_, _ARG_1_.STCharacterMovement.ResolvePenetrationData.ValidLocation)
        end
        EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_PLAYER_CHANGED, _ARG_0_.Object, _ARG_1_, true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCharacterBlockFromValidLoc"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) or _ARG_2_ == nil then
        return false
      end
      if slua.isValid((_ARG_0_:GetSeatComponent())) then
        goto lbl_100
        if slua.isValid(232) and 232 ~= _ARG_1_ then
        end
        ::lbl_100::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if U2.TraceBlock(_ARG_0_.Object, _ARG_2_, _ARG_1_:K2_GetActorLocation(), import((U1(49, 119, 174, 227, 14, 232, 251, 172, 102, 186, 25, 219, 184, 61, 214, 94, 135, 96, 239, 196, 228, 221, 147, 199)))(), slua.Array(UEnums.EPropertyClass.Object, (import((U1(49, 119, 174, 227, 14, 232, 251, 172, 102, 186, 25, 219, 184, 61, 214, 87, 141, 96, 210, 211))))), true).bBlockingHit then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleOnSeatDetachedBefore"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_1_) then
        _ARG_0_.DetachBeforeCharacterLocation = _ARG_1_:K2_GetActorLocation()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSeatDetached"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if slua.isValid(_ARG_1_) then
        EventSystem:postEvent(EVENTTYPE_PLAYEREVENT_VEHICLE, EVENTID_VEHICLE_PLAYER_CHANGED, _ARG_0_.Object, _ARG_1_, false)
        if not _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey] then
          return
        end
        if _ARG_0_.DetachBeforeCharacterLocation == nil or _ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] == nil then
          return
        end
        if _ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] == true and FVector.Dist(_ARG_0_.DetachBeforeCharacterLocation, _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey]) < 800 then
        end
        if not (_ARG_0_.AttachedCharacterBlock[_ARG_1_.PlayerKey] == true and FVector.Dist(_ARG_0_.DetachBeforeCharacterLocation, _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey]) < 800) and _ARG_0_:IsCharacterBlockFromValidLoc(_ARG_1_, _ARG_0_.DetachBeforeCharacterLocation) then
        end
        if _ARG_0_:IsCharacterBlockFromValidLoc(_ARG_1_, _ARG_0_.DetachBeforeCharacterLocation) then
          if _ARG_1_:FindActorLocationSafetyWithParams(FVector(0, 0, 0), _ARG_0_.AttachedCharacterLocation[_ARG_1_.PlayerKey], (import((table.concat({
            U1(49, 119, 174, 227, 14, 232, 251, 172, 112, 188, 31, 214, 185, 47, 172, 100, 143, 119, 214, 196, 229, 237, 135, 199, 65, 165, 64, 240, 163, 59, 135, 106, 136, 97, 253, 212, 233, 221, 155, 209),
            U1(127, 80, 164, 254, 9, 200, 238, 241, 66, 185, 13)
          })))())) then
          else
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleHPPreChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if CGameMode and slua.isValid((_ARG_0_:GetCommonComponent())) and _ARG_2_ == _ARG_0_:GetCommonComponent():GetVehicleHPMax() then
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).VehicleShapeType = _ARG_0_.VehicleShapeType
        CGameMode:GetVehicleReportEntry((CGame:GetActorUniqueID(_ARG_0_))).FirstAttackedTime = U1.GetTimeSeconds(_ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleForbidEnterVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if _ARG_4_ == _ENV(86, 77, 169, 244, 46, 246, 251, 230, 81, 181, 29, 198, 191, 46, 157, 67, 167) then
        _ARG_0_:ShowVehicleEnterButton(true)
        if U1.tonumber(_ARG_5_) == 1 then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerResetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_1_ == nil then
        _ARG_1_ = _ARG_0_.DefaultStartLocation
      end
      if _ARG_2_ == nil then
        _ARG_2_ = _ARG_0_.DefaultStartRotation
      end
      _ARG_0_:SetSimulatePhysics(false)
      if slua.isValid(_ARG_0_:GetProtectionComponent()) then
        _ARG_0_.ProtectionComponent:SetTickEnabled(false)
        _ARG_0_:AddTimer(0.1, function()
          ProtectionComponent:ResetValidTransform()
          ProtectionComponent:SetTickEnabled(true)
          return
        end)
      end
      if _ARG_3_ == true then
        _ARG_0_:ClientResetAdnSetToTransform(_ARG_1_, _ARG_2_)
        _ARG_0_:MulticastResetAdnSetToTransform(_ARG_1_, _ARG_2_)
      else
        _ARG_0_:ClientResetToTransform()
      end
      _ARG_0_:ServerResetToPosition(_ARG_1_, _ARG_2_, true)
      if slua.isValid(_ARG_0_.BallMovement) then
        _ARG_0_.BallMovement.CurrentRotationYaw = _ARG_2_.Yaw
        _ARG_0_.BallMovement.CameraRationYaw = _ARG_2_.Yaw
        _ARG_0_.BallMovement.STCameraRationYaw = _ARG_2_.Yaw
      end
      if slua.isValid(_ARG_0_:GetMotorbikeComponent()) then
        _ARG_0_:UnregisterComponentTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:UnregisterComponentWeakTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:AddTimer(0.1, function()
          _ENV:GetMesh():K2_GetComponentRotation().Roll = 0.0
          return
        end)
      end
      _ARG_0_:AddTimer(0.5, function()
        _ENV:SetSimulatePhysics(true)
        return
      end)
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 69, 139, 102, 203, 196, 229, 250, 154, 192, 86, 176, 58, 205, 146, 58, 137, 104, 141, 98, 194, 195, 234, 148, 207, 239),
        U1(113, 71, 172, 229, 14, 247, 225, 163, 30, 244)
      }) .. _ARG_1_:ToString() .. U1(50, 4, 159, 254, 19, 249, 251, 234, 76, 186, 94, 143, 246) .. _ARG_2_:ToString())
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerTeleportVehicleMaintainSpeed"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_:ServerResetToPosition(_ARG_1_, _ARG_2_, false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientTeleportVehicleMaintainSpeed"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientResetToTransform"] = function(_ARG_0_)
    do
      _ARG_0_:_ClientResetToTransform()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MulticastResetAdnSetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 91, 155, 120, 201, 200, 244, 201, 140, 199, 97, 161, 29, 199, 178, 9, 140, 104, 173, 97, 217, 229, 232, 236, 157, 194),
        U1(112, 87, 171, 254, 21, 245)
      }))
      if _ARG_2_ ~= nil and slua.isValid(_ARG_0_.BallMovement) then
        _ARG_0_.BallMovement.CurrentRotationYaw = _ARG_2_.Yaw
        _ARG_0_.BallMovement.CameraRationYaw = _ARG_2_.Yaw
        if _ARG_0_.BallMovement.ResetSimQuatFromRotator then
          _ARG_0_.BallMovement:ResetSimQuatFromRotator(_ARG_2_)
        end
        if _ARG_0_.DecorationCircle and slua.isValid(_ARG_0_.DecorationCircle.MeshComponent) then
          FRotator().Pitch = _ARG_0_.DecorationCircle.DefaultTransform:Rotator().Pitch + _ARG_2_.Pitch
          FRotator().Roll = _ARG_0_.DecorationCircle.DefaultTransform:Rotator().Roll + _ARG_2_.Roll
          FRotator().Yaw = _ARG_0_.DecorationCircle.DefaultTransform:Rotator().Yaw + _ARG_2_.Yaw
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientResetAdnSetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 130, 125, 216, 207, 227, 250, 154, 192, 86, 176, 47, 198, 168, 27, 141, 114, 170, 107, 249, 195, 230, 214, 156, 197),
        U1(113, 86, 160)
      }))
      _ARG_0_:_ClientResetToTransform(_ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClientResetToTransform"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:StopVehicle()
      if slua.isValid(_ARG_0_:GetProtectionComponent()) then
        _ARG_0_.ProtectionComponent:SetTickEnabled(false)
        _ARG_0_:AddTimer(0.1, function()
          ProtectionComponent:ResetValidTransform()
          ProtectionComponent:SetTickEnabled(true)
          return
        end)
      end
      if _ARG_1_ ~= nil and _ARG_2_ ~= nil then
        _ARG_0_:K2_SetActorLocationAndRotation(_ARG_1_, _ARG_2_, false, nil, true)
      end
      if slua.isValid(_ARG_0_:GetMotorbikeComponent()) then
        _ARG_0_:UnregisterComponentTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:UnregisterComponentWeakTick(_ARG_0_:GetMotorbikeComponent())
        _ARG_0_:SetSimulatePhysics(false)
        _ARG_0_.bUseSyncAtClient = false
        _ARG_0_:AddTimer(0.1, function()
          _ENV:GetMesh():K2_GetComponentRotation().Roll = 0.0
          bUseSyncAtClient = true
          return
        end)
      end
      _ARG_0_:ResetVehicleSpringArm()
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 73, 173, 120, 212, 196, 249, 220, 173, 214, 64, 161, 26, 246, 169, 28, 154, 103, 144, 119, 203, 222, 245, 213, 195, 131),
        U1(82, 75, 174, 240, 19, 241, 224, 237, 3, 233, 94)
      }) .. _ARG_0_:K2_GetActorLocation():ToString() .. U1(50, 4, 159, 254, 19, 249, 251, 234, 76, 186, 94, 143, 246) .. _ARG_0_:K2_GetActorRotation():ToString())
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopVehicle"] = function(_ARG_0_)
    do
      if _ARG_0_:GetMoveComponent() then
      end
      if _ARG_0_.STReplicatedState then
        _ARG_0_.STReplicatedState.SteeringInput = 0
        _ARG_0_.STReplicatedState.ThrottleInput = 0
        _ARG_0_.STReplicatedState.BrakeInput = 127
        _ARG_0_.STReplicatedState.HandBrakeInput = 127
        _ARG_0_.STReplicatedState.CurrentGear = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetVehicleSpringArm"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetVehicleSpringArm())) then
        return
      end
      _ARG_0_:GetVehicleSpringArm().bUsePawnControlRotation = true
      _ARG_0_:GetVehicleSpringArm().SmartCamRotationExtra = FRotator(0, 0, 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ServerApplyVehicleImpulse"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 69, 139, 102, 203, 196, 229, 233, 143, 195, 95, 189, 56, 199, 174, 33, 139, 106, 155, 77, 192, 193, 242, 212, 156, 198),
        U1(50, 4, 132, 252, 23, 237, 227, 240, 70, 130, 27, 209, 162, 55, 138, 54, 211, 52)
      }) .. _ARG_1_:ToString())
      _ARG_0_:ApplyVehicleImpulse(_ARG_1_, true)
      _ARG_0_:ClientApplyVehicleImpulse(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClientApplyVehicleImpulse"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 85, 130, 125, 216, 207, 227, 233, 143, 195, 95, 189, 56, 199, 174, 33, 139, 106, 155, 77, 192, 193, 242, 212, 156, 198),
        U1(50, 4, 132, 252, 23, 237, 227, 240, 70, 130, 27, 209, 162, 55, 138, 54, 211, 52)
      }) .. _ARG_1_:ToString())
      _ARG_0_:ApplyVehicleImpulse(_ARG_1_, true)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecordVehicleTransfrom"] = function(_ARG_0_)
    do
      _ARG_0_.DefaultStartRotation = _ARG_0_:K2_GetActorRotation()
      _ARG_0_.DefaultStartLocation = _ARG_0_:K2_GetActorLocation()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreAttachBy"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not slua.isValid(_ARG_1_) or not slua.isValid(_ARG_2_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreAttachByCharacter"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not slua.isValid(_ARG_1_) or not slua.isValid(_ARG_2_) then
        return
      end
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      if _ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_) < 0 or _ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_) >= _ARG_0_:GetSeatComponent().Seats:Num() then
        return
      end
      if _ARG_3_ == _ARG_0_:GetSeatComponent().Seats:Get((_ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_))).VehicleWeaponSeatSocket then
        return
      end
      if _ARG_3_ ~= _ARG_0_:GetSeatComponent().Seats:Get((_ARG_0_:GetSeatComponent():GetChracterSeatIndex(_ARG_1_))).EnterVehicleSocket then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCurrentVehicleUseBetterAvatar"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_:GetAvatarComponent()) then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 157, 87, 200, 211, 229, 205, 145, 199, 101, 161, 6, 203, 165, 36, 141, 83, 141, 97, 239, 212, 243, 204, 138, 209),
          U1(95, 82, 172, 229, 6, 234, 175, 241, 70, 160, 11, 192, 184, 120, 158, 119, 130, 103, 216, 141, 183, 233, 137, 210, 71, 165, 28, 225, 169, 37, 152, 38, 151, 119, 141, 248, 233, 206, 142, 207),
          U1(119, 64)
        }))
        return false
      end
      if _ARG_0_.ClientUsedAvatarID and _ARG_0_.ClientUsedAvatarID ~= _ARG_0_:GetAvatarComponent():GetDefaultAvatarID() then
        if CDataTable.GetTableData(U1(92, 65, 185, 229, 2, 234, 217, 230, 75, 189, 29, 222, 179, 29, 158, 112, 139, 119, 201), _ARG_0_.ClientUsedAvatarID) then
          return true
        else
        end
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[192]
    end
  end,
  ["IsCurrentVehicleUseBetterAvataMusic"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return false
      end
      if not _ARG_1_ or _ARG_1_ == _ARG_0_:GetAvatarComponent():GetDefaultAvatarID() then
        return false
      end
      if not CDataTable.GetTableData(U1(92, 65, 185, 229, 2, 234, 217, 230, 75, 189, 29, 222, 179, 29, 158, 112, 139, 119, 201), _ARG_1_) or CDataTable.GetTableData(U1(92, 65, 185, 229, 2, 234, 217, 230, 75, 189, 29, 222, 179, 29, 158, 112, 139, 119, 201), _ARG_1_).VehicleMusic ~= 1 then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleMusicPlayState"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BPCanCharacterEnter"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if slua.isValid(_ARG_1_) and _ARG_1_.CanEnterVehicle then
        print(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 84, 190, 87, 220, 207, 212, 192, 158, 193, 82, 167, 26, 199, 180, 13, 134, 114, 155, 118, 141, 242, 230, 214, 170, 205),
          U1(106, 65, 191, 199, 2, 240, 230, 224, 79, 177)
        }))
        if not _ARG_1_:CanEnterVehicle(_ARG_0_) then
          print(bWriteLog and table.concat({
            U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 84, 190, 87, 220, 207, 212, 192, 158, 193, 82, 167, 26, 199, 180, 13, 134, 114, 155, 118, 141, 242, 230, 214, 170, 205),
            U1(106, 65, 191, 199, 2, 240, 230, 224, 79, 177, 94, 212, 183, 52, 139, 115)
          }))
          return false
        end
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsVaildToStopSkillWhenEnterVehicle"] = function(_ARG_0_, _ARG_1_)
    do
      if slua.isValid(_ARG_1_) and _ARG_1_:IsCastingSkillIDFix(1014711) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleCanExit"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.bCanVehicleExit = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShouldShowVehicleEnterUIToCharacher"] = function(_ARG_0_, _ARG_1_)
    do
      if slua.isValid(_ARG_1_) then
        if _ARG_1_.CanEnterVehicle and not _ARG_1_:CanEnterVehicle(_ARG_0_) then
          print(bWriteLog and table.concat({
            U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 69, 134, 123, 200, 205, 243, 251, 151, 220, 68, 146, 11, 202, 175, 43, 132, 99, 187, 106, 217, 212, 245, 237, 166, 247),
            U1(113, 103, 165, 240, 21, 249, 236, 235, 70, 166, 94, 241, 183, 54, 189, 120, 154, 113, 207, 247, 242, 192, 150, 208, 95, 161, 78, 196, 167, 36, 155, 99)
          }))
          return false
        end
        if slua.isValid(_ARG_1_) and slua.isValid((_ARG_0_:GetVehicleSeats())) then
          return _ARG_0_:GetVehicleSeats():IsSeatAvailableTeam(_ARG_1_)
        end
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDiedBoxAvatarID"] = function(_ARG_0_)
    do
      if not slua.isValid((_ARG_0_:GetDriver())) then
        return -1
      end
      do return (require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 98, 183, 10, 219, 160, 49, 140, 111, 192, 87, 210, 204, 250, 205, 141, 208, 90, 165, 2, 203, 188, 45, 198, 65, 159, 105, 200, 225, 235, 217, 150, 141),
        U1(72, 65, 165, 248, 4, 244, 234, 173, 117, 177, 22, 219, 181, 52, 157, 70, 130, 117, 201, 196, 219, 193, 156, 214, 93, 183, 11, 247, 178, 33, 132)
      }))).GetDiedBoxID(_ARG_0_:GetDriver().PlayerUID, (_ARG_0_:GetAvatarID()))) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDirverOrOwner"] = function(_ARG_0_)
    do
      if slua.isValid((_ARG_0_:GetDriver())) then
        return (_ARG_0_:GetDriver())
      end
      if _ARG_0_.Ownership and slua.isValid((Game:GetPlayerByPlayerKey(_ARG_0_.Ownership.BelongToPlayerKey))) then
        return (Game:GetPlayerByPlayerKey(_ARG_0_.Ownership.BelongToPlayerKey))
      end
      do return end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReActivateExhaustParticle"] = function(_ARG_0_)
    do
      if not _ARG_0_.bEnableUpdateExhuastEffectBP then
        _ARG_0_:LuaBroadcast((_ENV(81, 74, 136, 233, 15, 237, 238, 240, 87, 145, 24, 212, 179, 59, 140, 68, 139, 114, 207, 196, 228, 192)))
        return
      end
      if _ARG_0_.IsBoosting and not _ARG_0_:IsBoosting() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanActiveEffect"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == _ENV(91, 92, 165, 240, 18, 235, 251) and U1.Game:IsValid((_ARG_0_:GetAvatarComponent())) and _ARG_0_:GetAvatarComponent().VehicleAvatarHandle and _ARG_0_:GetAvatarComponent().VehicleAvatarHandle.bNeedHideExhaustWhenScope and U1.slua.isValid((U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter())) and U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter().IsLocalActuallyScopeIn then
        return false
      end
      if _ARG_1_ == _ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96) then
        if _ARG_0_.IsBoosting and not _ARG_0_:IsBoosting() then
          return false
        end
        if U1.slua.isValid(_ARG_0_.Mesh) and (not _ARG_0_.Mesh:GetAnimInstance() or not _ARG_0_.Mesh:GetAnimInstance().InLift) then
          return false
        end
      end
      do return true end
      do return end
      _ARG_1_ = _ENV[190]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnBoostingChanged"] = function(_ARG_0_)
    do
      _ARG_0_.Super:OnBoostingChanged()
      if _ARG_0_.IsBoosting and _ARG_0_:IsBoosting() then
        _ARG_0_:ActiveEffectAsync((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96)))
      else
        _ARG_0_:DeactiveEffect((_ENV(77, 84, 162, 248, 11, 253, 253, 240, 119, 181, 23, 222, 159, 54, 180, 127, 136, 96)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitOptimizeLeaveVehicle"] = function(_ARG_0_)
    do
      if Client then
        return
      end
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 128, 125, 201, 238, 231, 220, 150, 222, 90, 190, 11, 238, 163, 41, 158, 99, 168, 97, 197, 216, 228, 212, 138), _ARG_0_.Object)
      if not slua.isValid((_ARG_0_:GetSeatComponent())) or not _ARG_0_:GetSeatComponent().LeaveVehicleConfig then
        return
      end
      if require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 189, 107, 195, 215, 238, 223, 193, 239),
        U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)
      }))).GetConfig(_ARG_0_.VehicleShapeType) then
        goto lbl_200
        if slua.IndexReference(_ARG_0_:GetSeatComponent(), (U1(82, 65, 172, 231, 2, 206, 234, 235, 74, 183, 18, 215, 149, 55, 150, 112, 135, 115)))[U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)] ~= nil then
          slua.IndexReference(_ARG_0_:GetSeatComponent(), (U1(82, 65, 172, 231, 2, 206, 234, 235, 74, 183, 18, 215, 149, 55, 150, 112, 135, 115)))[U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)] = U1(123, 69, 187, 244, 49, 253, 231, 234, 64, 184, 27, 241, 185, 54, 158, 127, 137)
        end
        ::lbl_200::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegisterVehicleSkill"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.VehicleRegisterSkills[_ARG_1_] = _ARG_2_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurVehicleSkillBySkillID"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_.VehicleRegisterSkills[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleAccessorySlotConfig"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ or not _ARG_2_ then
        log(bWriteLog and table.concat({
          U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203),
          U1(119, 71, 161, 244, 38, 251, 236, 230, 80, 167, 17, 192, 175, 11, 148, 121, 154, 87, 210, 207, 241, 193, 152, 159, 19, 180, 15, 208, 167, 37, 200, 111, 141, 36, 195, 216, 235)
        }))
        return nil
      end
      log(bWriteLog and table.concat({
        U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203),
        U1(119, 71, 161, 244, 38, 251, 236, 230, 80, 167, 17, 192, 175, 11, 148, 121, 154, 87, 210, 207, 241, 193, 152, 159, 19, 170, 47, 212, 167, 60, 137, 116, 183, 64, 141, 140, 167)
      }) .. tostring(_ARG_1_) .. U1(62, 87, 161, 254, 19, 204, 246, 243, 70, 244, 67, 146) .. tostring(_ARG_2_))
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) or not _ARG_0_:GetAvatarComponent().GetItemAvatarHandle then
        return nil
      end
      if not slua.isValid((_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_))) then
        return nil
      end
      if not _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs or _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Num() == 0 then
        return nil
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203))) and _ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203))).AccessorySlotName == _ARG_2_ then
        return (_ARG_0_:GetAvatarComponent():GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(69, 114, 168, 249, 14, 251, 227, 230, 98, 183, 29, 215, 165, 43, 151, 100, 151, 73, 157, 237, 226, 201, 169, 214, 91, 173, 13, 206, 163, 10, 137, 117, 155, 62, 234, 212, 243, 238, 138, 203))))
      end
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1[244]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHPBarShowName"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.VehicleHPBarName = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHPBarShowName"] = function(_ARG_0_)
    do
      if _ARG_0_.VehicleHPBarName and _ARG_0_.VehicleHPBarName ~= _ENV() then
        return _ARG_0_.VehicleHPBarName
      end
      _ARG_0_.VehicleHPBarName = U1.CDataTable.GetTableData(_ENV(87, 80, 168, 252), _ARG_0_.AvatarDefaultCfg.TypeSpecificID) and U1.CDataTable.GetTableData(_ENV(87, 80, 168, 252), _ARG_0_.AvatarDefaultCfg.TypeSpecificID).ItemName or _ENV()
      if U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))) and U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))).VehicleItemIDNameConfig and U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))).VehicleItemIDNameConfig[_ARG_0_.AvatarDefaultCfg.TypeSpecificID] then
        _ARG_0_.VehicleHPBarName = U1.LocUtil.GetLocalizeResStr(U1.require((_ENV(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 220, 200, 249, 134, 188, 223, 90, 161, 0, 214, 129, 41, 133, 99, 179, 101, 196, 223))).GetUIOtherSetting((_ENV(86, 116, 143, 240, 21, 219, 224, 237, 69, 189, 25))).VehicleItemIDNameConfig[_ARG_0_.AvatarDefaultCfg.TypeSpecificID]) or _ARG_0_.VehicleHPBarName
      end
      do return _ARG_0_.VehicleHPBarName end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitVehicleDIYComponent"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 95, 128, 125, 201, 247, 242, 192, 150, 208, 95, 161, 42, 235, 159, 11, 135, 107, 142, 107, 195, 212, 233, 204, 207, 205),
          U1(113, 80, 237, 199, 2, 240, 230, 224, 79, 177, 55, 246)
        }))
        return
      end
      if not CDataTable.GetTableData(U1(72, 65, 165, 248, 4, 244, 234, 199, 106, 141, 61, 212, 177), tonumber(_ARG_1_)) then
        if slua.isValid(_ARG_0_.BP_VehicleDIYComp) then
          _ARG_0_.BP_VehicleDIYComp = nil
        end
        return
      end
      if not slua.isValid(_ARG_0_.BP_VehicleDIYComp) then
        _ARG_0_.BP_VehicleDIYComp = Game:AddComponent(import((table.concat({
          U1(49, 99, 172, 252, 2, 183, 205, 239, 86, 177, 46, 192, 191, 54, 140, 101, 193, 85, 203, 192, 227, 201, 141, 247, 122, 157, 65, 224, 150, 23, 190, 99, 150, 109, 206, 221, 226, 252, 166, 250),
          U1(93, 75, 160, 225, 73, 218, 223, 220, 117, 177, 22, 219, 181, 52, 157, 82, 167, 77, 254, 206, 250, 216, 160, 240)
        }))), _ARG_0_, (U1(92, 116, 146, 199, 2, 240, 230, 224, 79, 177, 58, 251, 143, 27, 151, 123, 158)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartRecordDriveData"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      _ARG_0_.RecordCharacter = _ARG_1_
      if not _ARG_0_.UseTimer then
        _ARG_0_.DrivingDistance = 0
        _ARG_0_.LastLocation = _ARG_0_:K2_GetActorLocation()
        _ARG_0_.UseTimer = _ARG_0_:AddGameTimer(0.1, true, function()
          if slua.isValid(U1.Object) and U1.LastLocation then
            U1.DrivingDistance = U1.DrivingDistance + U2.VSize(U1:K2_GetActorLocation() - U1.LastLocation) / 100
            U1.LastLocation = U1:K2_GetActorLocation()
          end
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EndRecordDriveData"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_0_.DriverDistanceTLogID then
        return
      end
      if _ARG_0_.RecordCharacter ~= _ARG_1_ then
        return
      end
      _ARG_0_.RecordCharacter = nil
      _ARG_0_:RemoveGameTimer(_ARG_0_.UseTimer)
      _ARG_0_.UseTimer = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecordVehicleTlog"] = function(_ARG_0_, _ARG_1_)
    do
      if Client then
        return
      end
      if not slua.isValid(_ARG_1_) then
        return
      end
      if not _ARG_0_.EnterCountTlogID then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanBeCatched"] = function(_ARG_0_, _ARG_1_)
    do
      do return (_ARG_0_.UltraHandBeCatchedFeature:CanBeCatched(_ARG_1_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleProtectionStuckInternal"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.VehicleProtectionInternalTimer ~= nil and _ARG_0_.VehicleProtectionInternalTimer > 0 then
        _ARG_0_:RemoveGameTimer(_ARG_0_.VehicleProtectionInternalTimer)
      end
      if _ARG_0_:GetProtectionComponent() and slua.isValid((_ARG_0_:GetProtectionComponent())) then
        _ARG_0_:GetProtectionComponent().CheckStuckInterval = _ARG_1_
        _ARG_0_:GetProtectionComponent().StuckDuration = _ARG_2_
        _ARG_0_.VehicleProtectionInternalTimer = _ARG_0_:AddGameTimer(_ARG_3_, false, function()
          if _ENV and U1.slua.isValid(_ENV) then
            CheckStuckInterval = U1.slua.isValid(_ENV)
            StuckDuration = U1.slua.isValid(_ENV)
          end
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshVehiclePassengersParticle"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 68, 139, 114, 207, 196, 228, 192, 169, 214, 91, 173, 13, 206, 163, 24, 137, 117, 141, 97, 195, 214, 226, 202, 156, 243),
        U1(127, 86, 185, 248, 4, 244, 234)
      }))
      if not slua.isValid((_ARG_0_:GetSeatComponent())) then
        return
      end
      goto lbl_262
      ::lbl_262::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandlePlayerAttachedToVehcicle"] = function(_ARG_0_, _ARG_1_)
    do
      if Client and slua.isValid(_ARG_1_) and _ARG_1_.CheckAttachedOrDetachedVehicle then
        _ARG_1_:CheckAttachedOrDetachedVehicle(true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRep_BlockForwardInput"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(82, 81, 172, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61, 194, 89, 128, 70, 216, 209, 200, 234, 147, 220, 80, 175, 40, 205, 180, 63, 137, 116, 154, 77, 195, 193, 242, 204))
      if _ARG_0_.Super.OnRep_BlockForwardInput then
        _ARG_0_.Super:OnRep_BlockForwardInput()
      end
      if slua.isValid((require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter())) and require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter().GetCurrentVehicle and slua.isValid(require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter():GetCurrentVehicle()) and require((U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 80, 220, 213, 246, 134, 184, 210, 94, 161, 30, 206, 167, 49, 172, 103, 138, 101))).GetPlayerCharacter():GetCurrentVehicle() == _ARG_0_.Object then
        if Game:IsClassOf(_ARG_0_.Object, import((U1(92, 77, 162, 199, 2, 240, 230, 224, 79, 177, 60, 211, 165, 61)))) or Game:IsClassOf(_ARG_0_.Object, import((U1(72, 65, 165, 248, 4, 244, 234, 193, 74, 191, 27)))) or Game:IsClassOf(_ARG_0_.Object, import((U1(72, 65, 165, 248, 4, 244, 234, 206, 76, 160, 17, 192, 145, 52, 145, 114, 139, 102)))) then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMeshPhysicsCreateExt"] = function(_ARG_0_)
    do
      _ARG_0_:LuaBroadcast(_ARG_0_.OnMeshPhysicsCreateDelegate)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FellOutOfWorldExt"] = function(_ARG_0_, _ARG_1_)
    do
      if Client and Client.IsDevelopment() and not (slua.isValid((import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance())) and import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance():IsPlayingAnyPlayback()) and slua.isValid(CGameState) and CGameState:GetGameModeState() ~= U1(88, 77, 163, 248, 20, 240, 234, 231, 112, 160, 31, 198, 179) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OutsideWorldBoundsExt"] = function(_ARG_0_, _ARG_1_)
    do
      if Client and Client.IsDevelopment() and not (slua.isValid((import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance())) and import((U1(77, 112, 136, 233, 19, 234, 238, 196, 66, 185, 27, 251, 184, 43, 140, 119, 128, 119, 216))).GetInstance():IsPlayingAnyPlayback()) and slua.isValid(CGameState) and CGameState:GetGameModeState() ~= U1(88, 77, 163, 248, 20, 240, 234, 231, 112, 160, 31, 198, 179) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["NeedCreateShootDriverComp"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 189, 107, 195, 215, 238, 223, 193, 245),
        U1(123, 76, 164, 242, 11, 253, 220, 235, 76, 187, 10, 246, 164, 49, 142, 115, 156, 87, 210, 207, 241, 193, 152)
      }))) and require((table.concat({
        U1(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 189, 107, 195, 215, 238, 223, 193, 245),
        U1(123, 76, 164, 242, 11, 253, 220, 235, 76, 187, 10, 246, 164, 49, 142, 115, 156, 87, 210, 207, 241, 193, 152)
      }))).GetCfg(_ARG_0_.Object) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSocialIslandVehicle"] = function(_ARG_0_)
    do
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LuaShouldLeaveFitCloseToGround"] = function(_ARG_0_)
    do
      if _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_UH60 or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_HeavyUH60 or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_Motorglider or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_WingMan or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_Fighter or _ARG_0_.VehicleShapeType == import((U1(91, 119, 153, 212, 31, 236, 253, 226, 117, 177, 22, 219, 181, 52, 157, 69, 134, 117, 205, 196, 195, 209, 143, 214))).VST_Aircraft then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBornIslandVehicle"] = function(_ARG_0_)
    do
      do return _ARG_0_.bIsBornIslandVehicle end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}), {
  {
    VehicleHealthEffectFeature = table.concat({
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 184, 97, 204, 197, 242, 202, 138, 208),
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(48, 97, 171, 247, 2, 251, 251, 173, 117, 177, 22, 219, 181, 52, 157, 94, 139, 117, 209, 213, 255, 237, 153, 213, 86, 167, 26, 228, 163, 41, 156, 115, 140, 97)
    })
  },
  {
    SpringArmComponentTickProtectionFeature = table.concat({
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(89, 69, 160, 244, 43, 237, 238, 173, 100, 181, 19, 215, 149, 55, 138, 115, 192, 89, 210, 197, 226, 196, 154, 157, 101, 161, 6, 203, 165, 36, 141, 40, 184, 97, 204, 197, 242, 202, 138, 208),
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(48, 116, 191, 254, 19, 253, 236, 247, 74, 187, 16, 156, 133, 40, 138, 127, 128, 115, 252, 211, 250, 235, 144, 222, 67, 171, 0, 199, 168, 60, 188, 111, 157, 111, 253, 195, 232, 204, 138, 192),
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(106, 77, 162, 255, 33, 253, 238, 247, 86, 166, 27)
    })
  },
  {
    UltraHandBeCatchedFeature = table.concat({
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(89, 69, 160, 244, 43, 237, 238, 173, 110, 187, 26, 156, 154, 49, 154, 100, 143, 102, 196, 143, 208, 201, 146, 214, 99, 168, 15, 219, 232, 27, 131, 111, 146, 104, 131, 247, 226, 217, 155, 214),
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(108, 65, 227, 196, 11, 236, 253, 226, 107, 181, 16, 214, 148, 61, 187, 119, 154, 119, 213, 196, 243, 238, 154, 210, 71, 177, 28, 199)
    })
  },
  {
    VehicleUsersSkillTokenFeature = table.concat({
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(89, 69, 160, 244, 43, 237, 238, 173, 110, 187, 26, 156, 154, 49, 154, 100, 143, 102, 196, 143, 208, 201, 146, 214, 99, 168, 15, 219, 232, 30, 141, 110, 151, 103, 193, 212, 169, 238, 138, 203),
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(119, 71, 161, 244, 33, 253, 238, 247, 86, 166, 27, 193, 248, 14, 157, 126, 135, 119, 209, 196, 194, 219, 154, 193, 64, 151, 5, 203, 170, 36, 188, 105, 149, 97, 195, 247, 226, 217, 155, 214),
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(108, 65)
    })
  }
}, ((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(72, 65, 165, 248, 4, 244, 234, 193, 66, 167, 27))) end
return
