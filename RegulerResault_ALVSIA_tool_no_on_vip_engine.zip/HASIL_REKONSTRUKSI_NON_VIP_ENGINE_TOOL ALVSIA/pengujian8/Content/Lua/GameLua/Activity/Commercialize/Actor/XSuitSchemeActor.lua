local XSuitSchemeActor = {}
local DEFAULT_SCHEME_ID = 0

function XSuitSchemeActor:ctor()
  self.CurMesh = nil
  self.CurAnim = nil
  self.OwnerAvatarComp = nil
end

function XSuitSchemeActor:OnReceiveBeginPlay()
  local uOwner = self:GetOwner()
  if slua.isValid(uOwner) then
    self.OwnerAvatarComp = uOwner.CharacterAvatarComp2_BP
  end
  self:AddCommonEvent(EVENTTYPE_PLAYEREVENT_AVATAR, EVENTID_PLAYEREVENT_AVATAR_CLOTH_SCHEME_CHANGED, self.OnClothSchemeChanged, self)
  self:RefreshByBizData()
end

function XSuitSchemeActor:OnClothSchemeChanged(_, _, avatarCompObject)
  if not slua.isValid(self.OwnerAvatarComp) or avatarCompObject ~= self.OwnerAvatarComp then
    return
  end
  self:RefreshByBizData()
end

local function GetResBySchemeID(uMap, nSchemeID)
  if not uMap then
    return nil
  end
  local uRes = uMap:Get(nSchemeID)
  return slua.isValid(uRes) and uRes or nil
end

function XSuitSchemeActor:GetCurSchemeID()
  if not slua.isValid(self.OwnerAvatarComp) or not self.MeshList then
    return DEFAULT_SCHEME_ID
  end
  local tSchemeIDMap = self.OwnerAvatarComp.ClothSchemeIDMap
  if not tSchemeIDMap then
    return DEFAULT_SCHEME_ID
  end
  for nSchemeID in pairs(tSchemeIDMap) do
    if GetResBySchemeID(self.MeshList, nSchemeID) then
      return nSchemeID
    end
  end
  return DEFAULT_SCHEME_ID
end

function XSuitSchemeActor:RefreshByBizData()
  if not slua.isValid(self.Mesh) then
    return
  end
  local nSchemeID = self:GetCurSchemeID()
  local uMesh = GetResBySchemeID(self.MeshList, nSchemeID)
  local uAnim = GetResBySchemeID(self.AnimList, nSchemeID)
  if not uMesh then
    printf("XSuitSchemeActor:RefreshByBizData no mesh for scheme:%s", tostring(nSchemeID))
    return
  end
  if self.CurMesh == uMesh and self.CurAnim == uAnim then
    return
  end
  self.CurMesh = uMesh
  self.CurAnim = uAnim
  self.Mesh:SetSkeletalMesh(uMesh, true)
  if uAnim then
    self.Mesh:PlayAnimation(uAnim, true)
  end
  printf("XSuitSchemeActor:RefreshByBizData scheme:%s, mesh:%s, anim:%s", tostring(nSchemeID), tostring(uMesh), tostring(uAnim))
end

function XSuitSchemeActor:OnReceiveEndPlay()
  log(bWriteLog and "XSuitSchemeActor:OnReceiveEndPlay")
  self.OwnerAvatarComp = nil
end

local class = require("class")
local object = require("GameLua.Mod.BaseMod.Common.Core.ActorBase")
local CXSuitSchemeActor = class(object, nil, XSuitSchemeActor)
return CXSuitSchemeActor
