do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(28, 29, 52, 190, 197)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(28, 30, 56, 160, 217, 49, 183, 192, 160, 158, 250, 206, 86, 168, 7, 72, 236, 46, 75, 137, 39, 6, 135, 241, 167))), nil, {
  ["ctor"] = function(_ARG_0_)
    do
      _ARG_0_.CustomAssetTypeMap = {}
      goto lbl_9
      _ARG_0_.CustomAssetTypeMap[nil] = nil, nil, _ARG_0_.CustomAssetTypeMap
      ::lbl_9::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_._CustomAssetManagerSeq = 1
      _ARG_0_.CustomAssetInfoMap = {}
      _ARG_0_.DeserializerMap = {}
      _ARG_0_.PlatformBuilderMap = {}
      _ARG_0_.uCustomAssetUploader = nil
      _ARG_0_.uCustomAssetDownloader = nil
      _ARG_0_.uCustomAssetCacheManager = nil
      _ARG_0_.LoadSeqToDownloadCompletedInfo = {}
      _ARG_0_.BatchDownloadWaitMap = {}
      _ARG_0_.DeserializeCallbackMap = {}
      _ARG_0_.CustomAssetKeyHashIDCheckMap = {}
      _ARG_0_.CurCustomAssetUploaderInfo = nil
      _ARG_0_.WaitCustomAssetHashIDInfoMap = {}
      _ARG_0_.WaitMappingTimer = nil
      _ARG_0_.UnmountCallBackMap = {}
      _ARG_0_.CurPlatformSuffixType = nil
      _ARG_0_.MapDependencySizeLimit = nil
      _ARG_0_.DsMountableSizeLimit = nil
      _ARG_0_.AutoMountSizeLimit = nil
      _ARG_0_.CallInMountedHandleAssetMap = {}
      _ARG_0_.CallInMountHandleAssetMap = {}
      _ARG_0_.BatchMountWaitMap = {}
      _ARG_0_.BatchAssetKeyMap = {}
      _ARG_0_.AllocPackagePathMap = {}
      _ARG_0_._DsAutoMountReplicateCompleteCallBackMap = {}
      _ARG_0_._CurDsAutoMountCallBackID = 0
      _ARG_0_.CustomAssetKeyListHashToAssetMap = {}
      _ARG_0_.CustomAssetKeyListAssetToHashMap = {}
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveBeginPlay"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 205, 52, 86, 136, 63, 9, 156, 198),
        U1(26, 22, 60, 163, 230, 51, 248, 221, 229, 187, 236, 237, 82, 184, 11, 116, 238, 53, 64, 153, 21, 10, 155, 226, 176, 144, 181)
      }) .. tostring(_ARG_0_:IsDedicatedServer()))
      _ARG_0_.uCustomAssetUploader = _ARG_0_:CreateUtilityObject(U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 252, 71, 176, 13, 118, 235, 36, 87), (U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 252, 71, 176, 13, 118, 235, 36, 87)))
      _ARG_0_.uCustomAssetDownloader = _ARG_0_:CreateUtilityObject(U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 237, 88, 171, 12, 123, 224, 32, 65, 152, 52), (U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 237, 88, 171, 12, 123, 224, 32, 65, 152, 52)))
      _ARG_0_.uCustomAssetCacheManager = _ARG_0_:CreateUtilityObject(U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 234, 86, 191, 10, 114, 194, 32, 75, 156, 33, 10, 155), (U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 234, 86, 191, 10, 114, 194, 32, 75, 156, 33, 10, 155)))
      _ARG_0_.uCustomAssetImageManager = _ARG_0_:CreateUtilityObject(U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 224, 90, 189, 5, 114, 194, 32, 75, 156, 33, 10, 155), (U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 224, 90, 189, 5, 114, 194, 32, 75, 156, 33, 10, 155)))
      _ARG_0_.uCustomAssetAnimManager = _ARG_0_:CreateUtilityObject(U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 232, 89, 181, 15, 90, 238, 47, 68, 154, 35, 29), (U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 232, 89, 181, 15, 90, 238, 47, 68, 154, 35, 29)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceivePostBeginPlay"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 228, 86, 178, 3, 112, 234, 51, 31, 173, 41, 28, 157, 214, 176, 133, 230, 215, 119, 160, 19, 126, 191, 24, 70, 169, 51, 27, 144, 231),
        U1(30, 5, 48, 169, 229, 58, 235, 210, 160, 128, 165)
      }) .. tostring(_ARG_0_:IsDedicatedServer()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveEndPlay"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 205, 52, 86, 136, 63, 9, 156, 193),
        U1(17, 21, 5, 161, 215, 38, 185, 237, 182, 182, 250, 205, 94, 191, 3, 99, 234, 37, 118, 152, 52, 25, 140, 230, 239)
      }) .. tostring(_ARG_0_:IsDedicatedServer()))
      _ARG_0_:DestroyUtilityObject(_ARG_0_.uCustomAssetUploader)
      _ARG_0_.uCustomAssetUploader = nil
      _ARG_0_:DestroyUtilityObject(_ARG_0_.uCustomAssetDownloader)
      _ARG_0_.uCustomAssetDownloader = nil
      _ARG_0_:DestroyUtilityObject(_ARG_0_.uCustomAssetCacheManager)
      _ARG_0_.uCustomAssetCacheManager = nil
      _ARG_0_:DestroyUtilityObject(_ARG_0_.uCustomAssetImageManager)
      _ARG_0_.uCustomAssetImageManager = nil
      _ARG_0_:DestroyUtilityObject(_ARG_0_.uCustomAssetAnimManager)
      _ARG_0_.uCustomAssetAnimManager = nil
      _ARG_0_:DestroyPlatformBuilder()
      _ARG_0_:DestroyAllDeserializer()
      _ARG_0_.MapDependencySizeLimit = nil
      _ARG_0_.DsMountableSizeLimit = nil
      _ARG_0_.AutoMountSizeLimit = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsDedicatedServer"] = function(_ARG_0_)
    do
      if _ARG_0_.CacheIsDedicatedServer == nil then
        _ARG_0_.CacheIsDedicatedServer = _ARG_0_:ReceiveIsDedicatedServer()
      end
      do return _ARG_0_.CacheIsDedicatedServer end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnFightingStatusEnter"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 228, 86, 178, 3, 112, 234, 51, 31, 178, 40, 41, 128, 243, 189, 150, 230, 215, 64, 159, 6, 102, 235, 36, 70, 168, 56, 11, 156, 246))
      _ARG_0_.uCustomAssetUploader:OnFightingStatusEnter()
      _ARG_0_.uCustomAssetDownloader:OnFightingStatusEnter()
      _ARG_0_.uCustomAssetCacheManager:OnFightingStatusEnter()
      _ARG_0_.uCustomAssetImageManager:OnFightingStatusEnter()
      if slua.isValid(_ARG_0_.uCustomAssetAnimManager) then
        _ARG_0_.uCustomAssetAnimManager:OnFightingStatusEnter()
      end
      if not _ARG_0_:IsDedicatedServer() then
        _ARG_0_:BuildCustomAssetKeyListMapping()
      end
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME_CREATIVE_MODE, EVENTID_CUSTOM_ASSET_HASHID_MAPPING_CHANGE, _ARG_0_.OnCustomAssetHashIDMappingChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_INGAME_CREATIVE_MODE, EVENTID_CUSTOM_ASSET_MOUNT_STATE_CHANGE, _ARG_0_.OnMountStateChange, _ARG_0_)
      if not _ARG_0_:IsDedicatedServer() then
        _ARG_0_:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_PREFAB_MALL_FIRST_META_COMPLETE, _ARG_0_.OnPrefabMallDataUpdateCompleted, _ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BuildCustomAssetKeyListMapping"] = function(_ARG_0_)
    do
      _ARG_0_.CustomAssetKeyListHashToAssetMap = {}
      _ARG_0_.CustomAssetKeyListAssetToHashMap = {}
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):IsUGCEditMod() then
        return
      end
      if (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetMatchModID() or 0) == 0 then
        return
      end
      if not U2.GetAllLevelCustomAssetKeyList((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetMatchModID() or 0) or nil).pub_mod_meta.setting) then
        return
      end
      goto lbl_315
      if _ARG_0_:GenerateCustomAssetKeyHashID(U1(12, 5, 24, 172, 198, 47, 240, 202, 162, 210, 241, 198, 23, 191, 23, 100, 251, 46, 72, 162, 39, 28, 154, 241, 161, 189, 228, 220, 94, 147, 30, 110, 236, 37)) and 0 < _ARG_0_:GenerateCustomAssetKeyHashID(U1(12, 5, 24, 172, 198, 47, 240, 202, 162, 210, 241, 198, 23, 191, 23, 100, 251, 46, 72, 162, 39, 28, 154, 241, 161, 189, 228, 220, 94, 147, 30, 110, 236, 37)) then
        _ARG_0_.CustomAssetKeyListHashToAssetMap[_ARG_0_:GenerateCustomAssetKeyHashID(U1(12, 5, 24, 172, 198, 47, 240, 202, 162, 210, 241, 198, 23, 191, 23, 100, 251, 46, 72, 162, 39, 28, 154, 241, 161, 189, 228, 220, 94, 147, 30, 110, 236, 37))] = U1(12, 5, 24, 172, 198, 47, 240, 202, 162, 210, 241, 198, 23, 191, 23, 100, 251, 46, 72, 162, 39, 28, 154, 241, 161, 189, 228, 220, 94, 147, 30, 110, 236, 37)
        _ARG_0_.CustomAssetKeyListAssetToHashMap[U1(12, 5, 24, 172, 198, 47, 240, 202, 162, 210, 241, 198, 23, 191, 23, 100, 251, 46, 72, 162, 39, 28, 154, 241, 161, 189, 228, 220, 94, 147, 30, 110, 236, 37)] = _ARG_0_:GenerateCustomAssetKeyHashID(U1(12, 5, 24, 172, 198, 47, 240, 202, 162, 210, 241, 198, 23, 191, 23, 100, 251, 46, 72, 162, 39, 28, 154, 241, 161, 189, 228, 220, 94, 147, 30, 110, 236, 37)), _ARG_0_.CustomAssetKeyListAssetToHashMap
      end
      ::lbl_315::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnFightingStatusPreExit"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 228, 86, 178, 3, 112, 234, 51, 31, 178, 40, 41, 128, 243, 189, 150, 230, 215, 64, 159, 6, 102, 235, 36, 70, 189, 36, 26, 188, 252),
        U1(22, 5)
      }))
      if slua.isValid(_ARG_0_.uCustomAssetUploader) then
        _ARG_0_.uCustomAssetUploader:OnFightingStatusPreExit()
      end
      if slua.isValid(_ARG_0_.uCustomAssetImageManager) then
        _ARG_0_.uCustomAssetImageManager:OnFightingStatusPreExit()
      end
      if slua.isValid(_ARG_0_.uCustomAssetAnimManager) then
        _ARG_0_.uCustomAssetAnimManager:OnFightingStatusPreExit()
      end
      _ARG_0_.uCustomAssetDownloader:OnFightingStatusPreExit()
      _ARG_0_.uCustomAssetCacheManager:OnFightingStatusPreExit()
      _ARG_0_:DestroyPlatformBuilder()
      _ARG_0_:DestroyAllDeserializer()
      _ARG_0_.WaitCustomAssetHashIDInfoMap = {}
      _ARG_0_.UnmountCallBackMap = {}
      _ARG_0_.BatchAssetKeyMap = {}
      _ARG_0_.BatchMountWaitMap = {}
      _ARG_0_.AllocPackagePathMap = {}
      _ARG_0_.CallInMountedHandleAssetMap = {}
      _ARG_0_.CallInMountHandleAssetMap = {}
      if not _ARG_0_:IsDedicatedServer() then
        _ARG_0_.CustomAssetKeyListHashToAssetMap = {}
        _ARG_0_.CustomAssetKeyListAssetToHashMap = {}
      end
      _ARG_0_._DsAutoMountReplicateCompleteCallBackMap = {}
      _ARG_0_:CheckAndEndWaitCustomAssetHashIDMapping()
      _ARG_0_:RemoveCommonEvent(EVENTTYPE_INGAME_CREATIVE_MODE, EVENTID_CUSTOM_ASSET_HASHID_MAPPING_CHANGE)
      _ARG_0_:RemoveCommonEvent(EVENTTYPE_INGAME_CREATIVE_MODE, EVENTID_CUSTOM_ASSET_MOUNT_STATE_CHANGE)
      if not _ARG_0_:IsDedicatedServer() then
        _ARG_0_:RemoveCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_PREFAB_MALL_FIRST_META_COMPLETE)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnFightingStatusPostExit"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 228, 86, 178, 3, 112, 234, 51, 31, 178, 40, 41, 128, 243, 189, 150, 230, 215, 64, 159, 6, 102, 235, 36, 70, 189, 57, 12, 141, 193),
        U1(7, 24, 33)
      }))
      if slua.isValid(_ARG_0_.uCustomAssetUploader) then
        _ARG_0_.uCustomAssetUploader:OnFightingStatusPostExit()
      end
      if slua.isValid(_ARG_0_.uCustomAssetImageManager) then
        _ARG_0_.uCustomAssetImageManager:OnFightingStatusPostExit()
      end
      if slua.isValid(_ARG_0_.uCustomAssetAnimManager) then
        _ARG_0_.uCustomAssetAnimManager:OnFightingStatusPostExit()
      end
      _ARG_0_.uCustomAssetDownloader:OnFightingStatusPostExit()
      _ARG_0_.uCustomAssetCacheManager:OnFightingStatusPostExit()
      _ARG_0_:PrintAliveCustomAssets()
      _ARG_0_:CleanupAliveCustomAssetObjects()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsReleaseVersion"] = function(_ARG_0_)
    do
      if _ARG_0_._bIsReleaseVersion == nil then
        _ARG_0_._bIsReleaseVersion = false
        if _ARG_0_:IsDedicatedServer() then
          if import((U1(44, 37, 16, 181, 194, 45, 248, 227, 164, 159, 250, 217, 91, 189, 27, 68, 251, 32, 81, 148, 37, 28))) then
          end
          if import((U1(44, 37, 16, 181, 194, 45, 248, 227, 164, 159, 250, 217, 91, 189, 27, 68, 251, 32, 81, 148, 37, 28))).IsShipping() then
            _ARG_0_._bIsReleaseVersion = true
          end
        elseif require((U1(28, 30, 56, 160, 217, 49, 183, 209, 177, 155, 243, 192, 67, 165))).IsReleaseVersion() then
          _ARG_0_._bIsReleaseVersion = true
        end
      end
      do return _ARG_0_._bIsReleaseVersion == true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CreateUtilityObject"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return (U1.CGame:NewObjectFromClass(_ARG_0_.Object, U1.import(_ARG_1_), _ARG_2_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DestroyUtilityObject"] = function(_ARG_0_, _ARG_1_)
    do
      if slua.isValid(_ARG_1_) and _ARG_1_.LuaConditionalBeginDestroy ~= nil then
        _ARG_1_:LuaConditionalBeginDestroy()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAssetDeserializer"] = function(_ARG_0_, _ARG_1_)
    do
      if _ENV[_ARG_1_] == nil then
        return nil
      end
      if not U1.slua.isValid(_ARG_0_.DeserializerMap[_ARG_1_]) and _ENV[_ARG_1_].DeserializerClass ~= nil then
        _ARG_0_:CreateUtilityObject(_ENV[_ARG_1_].DeserializerClass, U2(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 237, 82, 175, 7, 101, 230, 32, 73, 148, 60, 10, 155, 203) .. U1.tostring(_ARG_1_)).DeserializeTimeout = 15.0
        _ARG_0_.DeserializerMap[_ARG_1_] = _ARG_0_:CreateUtilityObject(_ENV[_ARG_1_].DeserializerClass, U2(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 237, 82, 175, 7, 101, 230, 32, 73, 148, 60, 10, 155, 203) .. U1.tostring(_ARG_1_)), _ENV[_ARG_1_].DeserializerClass, _ARG_0_.DeserializerMap
      end
      do return (_ARG_0_:CreateUtilityObject(_ENV[_ARG_1_].DeserializerClass, U2(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 237, 82, 175, 7, 101, 230, 32, 73, 148, 60, 10, 155, 203) .. U1.tostring(_ARG_1_))) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DestroyAllDeserializer"] = function(_ARG_0_)
    do
      goto lbl_8
      ::lbl_8::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.DeserializerMap = {}
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCustomAssetDefaultBytes"] = function(_ARG_0_, _ARG_1_)
    do
      if _ENV[_ARG_1_] == nil then
        return nil
      end
      if _ENV[_ARG_1_].DefaultAsset ~= nil then
        return U1.import((U2(60, 3, 48, 172, 194, 54, 239, 193, 136, 157, 251, 204, 117, 176, 23, 114, 255, 51, 76, 147, 50, 35, 128, 246, 167, 131, 253, 192))).LoadFileToArrayByFullPath(U1.import((U2(44, 37, 16, 181, 194, 45, 248, 230, 169, 135, 250, 217, 69, 181, 12, 99, 201, 52, 75, 158, 50, 6, 134, 250, 153, 139, 237, 203, 70, 190, 11))).ProjectContentDir() .. U3.DefaultAssetDataDirectory .. _ENV[_ARG_1_].DefaultAsset)
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAssetPlatformBuilder"] = function(_ARG_0_, _ARG_1_)
    do
      if _ENV[_ARG_1_] == nil then
        return nil
      end
      if not U1.slua.isValid(_ARG_0_.PlatformBuilderMap[_ARG_1_]) and _ENV[_ARG_1_].PlatformBuilderClass ~= nil then
        _ARG_0_.PlatformBuilderMap[_ARG_1_] = _ARG_0_:CreateUtilityObject(_ENV[_ARG_1_].PlatformBuilderClass, U2(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 249, 91, 189, 22, 113, 224, 51, 72, 191, 51, 6, 133, 240, 176, 144, 208) .. U1.tostring(_ARG_1_)), _ENV[_ARG_1_].PlatformBuilderClass, _ARG_0_.PlatformBuilderMap
      end
      do return (_ARG_0_:CreateUtilityObject(_ENV[_ARG_1_].PlatformBuilderClass, U2(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 249, 91, 189, 22, 113, 224, 51, 72, 191, 51, 6, 133, 240, 176, 144, 208) .. U1.tostring(_ARG_1_))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DestroyPlatformBuilder"] = function(_ARG_0_)
    do
      goto lbl_8
      ::lbl_8::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.PlatformBuilderMap = {}
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PrintDeserializeError"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 207, 35, 92, 131, 34, 59, 156, 247),
        U1(26, 3, 60, 172, 218, 54, 227, 193, 128, 128, 237, 198, 69, 252, 23, 83, 234, 50, 64, 143, 47, 14, 133, 253, 175, 135, 253, 131)
      }) .. tostring(_ARG_1_) .. U1(95, 52, 39, 191, 217, 45, 212, 215, 162, 200) .. tostring(_ARG_1_:GetLastError()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CustomAssetKeyToSimple"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:GetCustomAssetInfo(_ARG_1_) ~= nil and _ARG_0_:GetCustomAssetInfo(_ARG_1_).IsCustomAssetKey == true then
        return _ARG_0_:GetCustomAssetInfo(_ARG_1_).SimpleAssetKey
      end
      do return _ARG_1_ end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCustomAssetInfo"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) == U1(17, 4, 56, 175, 211, 45) then
      end
      if _ARG_0_:GetCustomAssetKeyByHashID(_ARG_1_) == nil or type((_ARG_0_:GetCustomAssetKeyByHashID(_ARG_1_))) ~= U1(12, 5, 39, 164, 216, 56) or _ARG_0_:GetCustomAssetKeyByHashID(_ARG_1_) == U1() then
        return nil
      end
      if _ARG_0_.CustomAssetInfoMap[_ARG_0_:GetCustomAssetKeyByHashID(_ARG_1_)] == nil then
        U2.FastCopyTable(U3).SHA256Arr, U2.FastCopyTable(U3).AssetType, U2.FastCopyTable(U3).AssetSize, U2.FastCopyTable(U3).AssetKey = _ARG_0_:ParseCustomAssetKey((_ARG_0_:GetCustomAssetKeyByHashID(_ARG_1_)))
        if U2.FastCopyTable(U3).AssetType <= 0 or _ARG_0_.CustomAssetTypeMap[U2.FastCopyTable(U3).AssetType] == nil then
        end
        if U2.FastCopyTable(U3).AssetSize <= 0 then
        end
        if U2.FastCopyTable(U3).SHA256Arr == nil or #U2.FastCopyTable(U3).SHA256Arr == 0 then
        else
          _ARG_0_ = _ARG_0_
          if string.len(U2.FastCopyTable(U3).SHA256Arr[nil]) ~= 64 then
          else
            _ARG_0_ = _ARG_0_
          end
        end
        U2.FastCopyTable(U3).IsCustomAssetKey = false
        if false == true then
          if #_ARG_0_:ParseCustomAssetKey((_ARG_0_:GetCustomAssetKeyByHashID(_ARG_1_))) > 1 then
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
            U2.FastCopyTable(U3).SimpleAssetKey = U4.SpliceCustomAssetKey(_ARG_0_:ParseCustomAssetKey((_ARG_0_:GetCustomAssetKeyByHashID(_ARG_1_))))
          else
            U2.FastCopyTable(U3).SimpleAssetKey = _ARG_0_:GetCustomAssetKeyByHashID(_ARG_1_)
          end
        end
        _ARG_0_.CustomAssetInfoMap[_ARG_0_:GetCustomAssetKeyByHashID(_ARG_1_)] = U2.FastCopyTable(U3), _ARG_0_:ParseCustomAssetKey((_ARG_0_:GetCustomAssetKeyByHashID(_ARG_1_)))
      end
      do return (U2.FastCopyTable(U3)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetCustomAssetUseSuffixType"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:GetCustomAssetInfo(_ARG_1_) ~= nil and U1[_ARG_0_:GetCustomAssetInfo(_ARG_1_).AssetType] ~= nil then
        if U1[_ARG_0_:GetCustomAssetInfo(_ARG_1_).AssetType].DefaultSuffixType then
          return U1[_ARG_0_:GetCustomAssetInfo(_ARG_1_).AssetType].DefaultSuffixType
        end
        if U1[_ARG_0_:GetCustomAssetInfo(_ARG_1_).AssetType].PlatformAsset ~= nil then
          if _ARG_0_.CurPlatformSuffixType == nil then
            _ARG_0_.CurPlatformSuffixType = _ARG_0_:GetCurPlatformSuffixType()
          end
          if U1[_ARG_0_:GetCustomAssetInfo(_ARG_1_).AssetType].PlatformAsset[_ARG_0_.CurPlatformSuffixType] == true then
          end
        end
      end
      do return _ARG_0_.CurPlatformSuffixType end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_NewCustomAssetDownloadCompletedInfo"] = function(_ARG_0_)
    do
      do return FastCopyTable(U1) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_NewCustomAssetBatchDownloadCompletedInfo"] = function(_ARG_0_)
    do
      do return FastCopyTable(U1) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_NewCustomAssetUploaderInfo"] = function(_ARG_0_)
    do
      do return FastCopyTable(U1) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetFallbackSuffixType"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_:GetCustomAssetInfo(_ARG_1_) == nil then
        return nil
      end
      if _ENV[_ARG_0_:GetCustomAssetInfo(_ARG_1_).AssetType] == nil or _ENV[_ARG_0_:GetCustomAssetInfo(_ARG_1_).AssetType].SuffixFallbackMap == nil then
        return nil
      end
      if _ENV[_ARG_0_:GetCustomAssetInfo(_ARG_1_).AssetType].SuffixFallbackMap[_ARG_2_] == nil or _ARG_2_ == _ENV[_ARG_0_:GetCustomAssetInfo(_ARG_1_).AssetType].SuffixFallbackMap[_ARG_2_] then
        return nil
      end
      do return _ENV[_ARG_0_:GetCustomAssetInfo(_ARG_1_).AssetType].SuffixFallbackMap[_ARG_2_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_TryFallbackCustomAssetDownload"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      print(table.concat({
        U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 135, 49, 98, 233, 39, 76, 133, 0, 14, 133, 248, 183, 131, 236, 210, 122, 236, 38, 117, 230, 113, 116, 158, 37, 26, 141, 207),
        U1(26, 8, 111)
      }) .. tostring(_ARG_3_) .. U1(95, 53, 58, 186, 216, 51, 246, 197, 161, 161, 234, 202, 13) .. tostring(_ARG_2_) .. U1(95, 34, 32, 171, 208, 54, 225, 240, 188, 130, 250, 147) .. tostring(_ARG_4_) .. U1(95, 57, 52, 190, 225, 62, 240, 208, 140, 156, 249, 198, 13) .. tostring(_ARG_1_ ~= nil) .. U1(95, 37, 39, 164, 211, 59, 163) .. tostring(_ARG_1_ and _ARG_1_.bSuffixFallbackTried))
      if _ARG_2_ == true or _ARG_1_ == nil or _ARG_1_.bSuffixFallbackTried == true then
        return false
      end
      _ARG_1_.SuffixFallbackTriedMap = _ARG_1_.SuffixFallbackTriedMap or {}
      if _ARG_4_ ~= nil then
        if _ARG_1_.SuffixFallbackTriedMap[_ARG_4_] == true then
          print(table.concat({
            U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 135, 49, 98, 233, 39, 76, 133, 0, 14, 133, 248, 183, 131, 236, 210, 122, 236, 33, 108, 246, 33, 21, 159, 51, 15, 156, 229),
            U1(11, 20, 49, 237, 197, 42, 255, 194, 172, 138, 191, 232, 68, 175, 7, 99, 196, 36, 92, 199)
          }) .. tostring(_ARG_3_) .. U1(95, 34, 32, 171, 208, 54, 225, 240, 188, 130, 250, 147) .. tostring(_ARG_4_))
          return false
        end
        _ARG_1_.SuffixFallbackTriedMap[_ARG_4_] = true
      end
      if _ARG_0_:_GetFallbackSuffixType(_ARG_3_, _ARG_4_) == nil then
        return false
      end
      if _ARG_1_.SuffixFallbackTriedMap[_ARG_0_:_GetFallbackSuffixType(_ARG_3_, _ARG_4_)] == true then
        return false
      end
      _ARG_1_.SuffixFallbackTriedMap[_ARG_0_:_GetFallbackSuffixType(_ARG_3_, _ARG_4_)] = true
      _ARG_1_.bSuffixFallbackTried = true
      if _ARG_0_.uCustomAssetCacheManager:IsAssetCached(_ARG_3_, (_ARG_0_:_GetFallbackSuffixType(_ARG_3_, _ARG_4_))) then
      else
        _ARG_1_.DownloadSeq = _ARG_0_.uCustomAssetDownloader:RequestDownloadAsset(_ARG_3_, _ARG_1_.bIsTemp == true, _ARG_0_:_GetFallbackSuffixType(_ARG_3_, _ARG_4_), _ARG_1_.DownloadPriority or U2.LOW, _ARG_0_._CustomAssetDownloadHandle, _ARG_0_, _ARG_1_)
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CustomAssetDownloadHandle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      print(bWriteLog and table.concat({
        U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 228, 86, 178, 3, 112, 234, 51, 31, 162, 5, 26, 154, 224, 186, 143, 206, 202, 84, 169, 6, 67, 240, 38, 91, 129, 57, 30, 157, 204),
        U1(30, 31, 49, 161, 211, 127, 216, 215, 182, 151, 235, 226, 82, 165, 88)
      }) .. tostring(_ARG_3_) .. U1(95, 53, 58, 186, 216, 51, 246, 197, 161, 161, 234, 202, 13) .. tostring(_ARG_2_))
      if type(_ARG_1_) == U1(17, 4, 56, 175, 211, 45) then
      else
      end
      if _ARG_0_:_TryFallbackCustomAssetDownload(_ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_) then
        return
      end
      if _ARG_1_ ~= nil then
        _ARG_0_.LoadSeqToDownloadCompletedInfo[_ARG_1_.LoadSeq] = nil
        if _ARG_1_.DownloadType == U2.CustomAssetDownloadType.DownloadAndLoad then
          if _ARG_1_.Callback ~= nil then
          end
        elseif _ARG_1_.DownloadType == U2.CustomAssetDownloadType.DownloadAndDeserialize then
        elseif _ARG_1_.DownloadType == U2.CustomAssetDownloadType.DownloadOnly and _ARG_1_.Callback ~= nil then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CustomAssetBatchDownloadHandle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and table.concat({
        U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 228, 86, 178, 3, 112, 234, 51, 31, 162, 5, 26, 154, 224, 186, 143, 206, 202, 84, 169, 6, 69, 254, 37, 86, 133, 18, 16, 142, 234),
        U1(19, 30, 52, 169, 254, 62, 247, 192, 169, 151, 191, 235, 86, 168, 1, 127, 203, 46, 82, 147, 42, 0, 136, 240, 134, 135, 254, 131)
      }) .. tostring(_ARG_1_) .. U1(95, 48, 38, 190, 211, 43, 210, 193, 188, 200) .. tostring(_ARG_3_) .. U1(95, 53, 58, 186, 216, 51, 246, 197, 161, 161, 234, 202, 13) .. tostring(_ARG_2_))
      if _ARG_0_.BatchDownloadWaitMap[_ARG_1_] ~= nil then
        _ARG_0_.BatchDownloadWaitMap[_ARG_1_].DownloadMap[_ARG_3_] = _ARG_2_
        goto lbl_153
        if type(_ARG_2_) == U1(17, 4, 56, 175, 211, 45) and 0 < _ARG_2_ then
          goto lbl_155
        elseif _ARG_2_ ~= true then
        end
        ::lbl_153::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        ::lbl_155::
        if false == true then
          _ARG_0_.BatchDownloadWaitMap[_ARG_1_] = nil
          if _ARG_0_.BatchDownloadWaitMap[_ARG_1_].Callback ~= nil then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDeserializeCompletedHandle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and table.concat({
        U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 228, 86, 178, 3, 112, 234, 51, 31, 178, 40, 43, 140, 231, 176, 144, 230, 216, 75, 165, 8, 98, 220, 62, 88, 157, 58, 26, 141, 225),
        U1(27, 57, 52, 163, 210, 51, 252, 132, 129, 151, 236, 204, 69, 181, 3, 123, 230, 59, 64, 174, 35, 30, 211)
      }) .. tostring(_ARG_3_) .. U1(10, 62, 55, 167, 211, 60, 237, 158) .. tostring(_ARG_2_))
      if _ARG_0_.DeserializeCallbackMap[_ARG_3_] == nil then
        return
      end
      _ARG_0_.DeserializeCallbackMap[_ARG_3_] = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlatformBuilderCompletedHandle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and table.concat({
        U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 228, 86, 178, 3, 112, 234, 51, 31, 178, 40, 63, 133, 245, 161, 132, 224, 203, 74, 142, 7, 110, 243, 53, 80, 159, 21, 16, 148, 244),
        U1(19, 20, 33, 168, 210, 23, 248, 202, 161, 158, 250, 137, 117, 169, 11, 123, 235, 36, 87, 174, 35, 30, 211)
      }) .. tostring(_ARG_3_))
      if _ARG_0_.CurCustomAssetUploaderInfo ~= nil and _ARG_3_ == _ARG_0_.CurCustomAssetUploaderInfo.UploaderSeq then
        _ARG_0_.CurCustomAssetUploaderInfo.PlatformCustomAssetInfoList = {}, _ARG_0_.CurCustomAssetUploaderInfo
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUploadCompletedHandle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and table.concat({
        U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 228, 86, 178, 3, 112, 234, 51, 31, 178, 40, 58, 153, 248, 186, 131, 235, 250, 72, 161, 2, 107, 250, 37, 80, 137, 30, 30, 151, 224),
        U1(19, 20, 117, 152, 198, 51, 246, 197, 161, 151, 237, 250, 82, 173, 88)
      }) .. tostring(_ARG_1_) .. U1(95, 48, 38, 190, 211, 43, 210, 193, 188, 200) .. tostring(_ARG_3_) .. U1(95, 36, 37, 161, 217, 62, 253, 247, 176, 145, 165) .. tostring(_ARG_2_))
      if _ARG_0_.CurCustomAssetUploaderInfo ~= nil and _ARG_1_ == _ARG_0_.CurCustomAssetUploaderInfo.UploaderSeq then
        _ARG_0_.CurCustomAssetUploaderInfo = nil
        if _ARG_0_.CurCustomAssetUploaderInfo.UploaderCallback ~= nil then
          if _ARG_2_ then
          else
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_3_ = _ENV[95]
    end
  end,
  ["_GetAuthorLevelSizeLimit"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_0_[_ARG_1_] then
        return _ARG_0_[_ARG_1_]
      end
      if GameStatus.IsInLobbyOrMainCity() then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor) then
        end
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor):GetMineAuthorLevel() == 0 then
          return _ARG_3_
        end
      elseif not (CGameState.GetAuthorLevel and CGameState:GetAuthorLevel() or 0) or (CGameState.GetAuthorLevel and CGameState:GetAuthorLevel() or 0) == 0 then
        return _ARG_3_
      end
      if type(CDataTable.GetTableData(U1(42, 54, 22, 140, 195, 43, 241, 203, 183, 190, 250, 223, 82, 176, 33, 120, 225, 39, 76, 154), CGameState.GetAuthorLevel and CGameState:GetAuthorLevel() or 0) and CDataTable.GetTableData(U1(42, 54, 22, 140, 195, 43, 241, 203, 183, 190, 250, 223, 82, 176, 33, 120, 225, 39, 76, 154), CGameState.GetAuthorLevel and CGameState:GetAuthorLevel() or 0)[_ARG_2_]) == U1(17, 4, 56, 175, 211, 45) then
        _ARG_0_[_ARG_1_] = (CDataTable.GetTableData(U1(42, 54, 22, 140, 195, 43, 241, 203, 183, 190, 250, 223, 82, 176, 33, 120, 225, 39, 76, 154), CGameState.GetAuthorLevel and CGameState:GetAuthorLevel() or 0) and CDataTable.GetTableData(U1(42, 54, 22, 140, 195, 43, 241, 203, 183, 190, 250, 223, 82, 176, 33, 120, 225, 39, 76, 154), CGameState.GetAuthorLevel and CGameState:GetAuthorLevel() or 0)[_ARG_2_]) * U2.MB
        return _ARG_0_[_ARG_1_]
      end
      do return _ARG_3_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_3_ = _ENV[61]
    end
  end,
  ["_GetServerPrefabLimit"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if GameStatus.IsInLobbyOrMainCity() then
        if _ARG_0_[_ARG_2_] then
          return _ARG_0_[_ARG_2_]
        end
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor) then
          _ARG_0_[_ARG_2_] = (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor):GetMineAuthorInfo() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor):GetMineAuthorInfo()[_ARG_2_] or 0) * U1.MB
          return _ARG_0_[_ARG_2_]
        end
      else
        if _ARG_0_[_ARG_1_] then
          return _ARG_0_[_ARG_1_]
        end
        if CGameState.CreativeStateCustomAssetFeature and CGameState.CreativeStateCustomAssetFeature[_ARG_1_] ~= 0 then
          _ARG_0_[_ARG_1_] = CGameState.CreativeStateCustomAssetFeature[_ARG_1_] * U1.MB
          return _ARG_0_[_ARG_1_]
        end
      end
      do return 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMapDependencySizeLimit"] = function(_ARG_0_)
    do
      if import((U1(44, 37, 16, 181, 194, 45, 248, 230, 169, 135, 250, 217, 69, 181, 12, 99, 201, 52, 75, 158, 50, 6, 134, 250, 153, 139, 237, 203, 70, 190, 11))) and import((U1(44, 37, 16, 181, 194, 45, 248, 230, 169, 135, 250, 217, 69, 181, 12, 99, 201, 52, 75, 158, 50, 6, 134, 250, 153, 139, 237, 203, 70, 190, 11))):IsDevelopment() and _ARG_0_.GMMapDependencySizeLimit then
        return _ARG_0_.GMMapDependencySizeLimit
      end
      if _ARG_0_:_GetServerPrefabLimit(U1(47, 3, 48, 171, 215, 61, 205, 203, 177, 147, 243, 252, 68, 185, 46, 126, 226, 40, 81), U1(15, 3, 48, 171, 215, 61, 198, 208, 170, 134, 254, 197, 104, 169, 17, 114, 208, 45, 76, 144, 47, 27), (U1(56, 20, 33, 128, 215, 47, 221, 193, 181, 151, 241, 205, 82, 178, 1, 110, 220, 40, 95, 152, 10, 6, 132, 253, 161))) > 0 then
        return (_ARG_0_:_GetServerPrefabLimit(U1(47, 3, 48, 171, 215, 61, 205, 203, 177, 147, 243, 252, 68, 185, 46, 126, 226, 40, 81), U1(15, 3, 48, 171, 215, 61, 198, 208, 170, 134, 254, 197, 104, 169, 17, 114, 208, 45, 76, 144, 47, 27), (U1(56, 20, 33, 128, 215, 47, 221, 193, 181, 151, 241, 205, 82, 178, 1, 110, 220, 40, 95, 152, 10, 6, 132, 253, 161))))
      end
      do return _ARG_0_:_GetAuthorLevelSizeLimit(U1(50, 16, 37, 137, 211, 47, 252, 202, 161, 151, 241, 202, 78, 143, 11, 109, 234, 13, 76, 144, 47, 27), U1(62, 2, 38, 168, 194, 28, 248, 212, 164, 145, 246, 221, 78, 144, 11, 122, 230, 53), U2.MapDependencySizeLimit, (U1(56, 20, 33, 128, 215, 47, 221, 193, 181, 151, 241, 205, 82, 178, 1, 110, 220, 40, 95, 152, 10, 6, 132, 253, 161))) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAutoMountSizeLimit"] = function(_ARG_0_)
    do
      if _ARG_0_:_GetServerPrefabLimit(_ENV(47, 3, 48, 171, 215, 61, 201, 214, 160, 158, 240, 200, 83, 144, 11, 122, 230, 53), _ENV(15, 3, 48, 171, 215, 61, 198, 212, 183, 151, 243, 198, 86, 184, 61, 123, 230, 44, 76, 137), (_ENV(56, 20, 33, 140, 195, 43, 246, 233, 170, 135, 241, 221, 100, 181, 24, 114, 195, 40, 72, 148, 50))) > 0 then
        return (_ARG_0_:_GetServerPrefabLimit(_ENV(47, 3, 48, 171, 215, 61, 201, 214, 160, 158, 240, 200, 83, 144, 11, 122, 230, 53), _ENV(15, 3, 48, 171, 215, 61, 198, 212, 183, 151, 243, 198, 86, 184, 61, 123, 230, 44, 76, 137), (_ENV(56, 20, 33, 140, 195, 43, 246, 233, 170, 135, 241, 221, 100, 181, 24, 114, 195, 40, 72, 148, 50))))
      end
      do return _ARG_0_:_GetAuthorLevelSizeLimit(_ENV(62, 4, 33, 162, 251, 48, 236, 202, 177, 161, 246, 211, 82, 144, 11, 122, 230, 53), _ENV(62, 2, 38, 168, 194, 19, 246, 197, 161, 190, 246, 196, 94, 168), U1.AutoMountSizeLimit, (_ENV(56, 20, 33, 140, 195, 43, 246, 233, 170, 135, 241, 221, 100, 181, 24, 114, 195, 40, 72, 148, 50))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDsMountableSizeLimit"] = function(_ARG_0_)
    do
      if import((U1(44, 37, 16, 181, 194, 45, 248, 230, 169, 135, 250, 217, 69, 181, 12, 99, 201, 52, 75, 158, 50, 6, 134, 250, 153, 139, 237, 203, 70, 190, 11))) and import((U1(44, 37, 16, 181, 194, 45, 248, 230, 169, 135, 250, 217, 69, 181, 12, 99, 201, 52, 75, 158, 50, 6, 134, 250, 153, 139, 237, 203, 70, 190, 11))):IsDevelopment() and _ARG_0_.GMDsMountableSizeLimit then
        return _ARG_0_.GMDsMountableSizeLimit
      end
      if _ARG_0_:_GetServerPrefabLimit(U1(47, 3, 48, 171, 215, 61, 213, 203, 164, 150, 211, 192, 90, 181, 22), U1(15, 3, 48, 171, 215, 61, 198, 200, 170, 147, 251, 246, 91, 181, 15, 126, 251), (U1(56, 20, 33, 137, 197, 18, 246, 209, 171, 134, 254, 203, 91, 185, 49, 126, 245, 36, 105, 148, 43, 6, 157))) > 0 then
        return (_ARG_0_:_GetServerPrefabLimit(U1(47, 3, 48, 171, 215, 61, 213, 203, 164, 150, 211, 192, 90, 181, 22), U1(15, 3, 48, 171, 215, 61, 198, 200, 170, 147, 251, 246, 91, 181, 15, 126, 251), (U1(56, 20, 33, 137, 197, 18, 246, 209, 171, 134, 254, 203, 91, 185, 49, 126, 245, 36, 105, 148, 43, 6, 157))))
      end
      do return _ARG_0_:_GetAuthorLevelSizeLimit(U1(59, 2, 24, 162, 195, 49, 237, 197, 167, 158, 250, 250, 94, 166, 7, 91, 230, 44, 76, 137), U1(62, 2, 38, 168, 194, 18, 246, 209, 171, 134, 211, 192, 90, 181, 22), U2.DsMountableSizeLimit, (U1(56, 20, 33, 137, 197, 18, 246, 209, 171, 134, 254, 203, 91, 185, 49, 126, 245, 36, 105, 148, 43, 6, 157))) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCustomAssetKey"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if type(_ARG_1_) == U1(17, 4, 56, 175, 211, 45) then
        if _ARG_2_ ~= false then
          return _ARG_0_:IsCustomAssetKeyHashID(_ARG_1_)
        else
          return false
        end
      end
      if _ARG_0_:GetCustomAssetInfo(_ARG_1_) ~= nil then
        return _ARG_0_:GetCustomAssetInfo(_ARG_1_).IsCustomAssetKey == true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCustomAssetSize"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:IsCustomAssetKey(_ARG_1_) then
        return 0
      end
      if _ARG_0_:GetCustomAssetInfo(_ARG_1_) == nil then
        return 0
      end
      do return _ARG_0_:GetCustomAssetInfo(_ARG_1_).AssetSize end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCustomAssetType"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:IsCustomAssetKey(_ARG_1_, _ARG_2_) then
        return Enum_CustomAssetType.None
      end
      if _ARG_0_:GetCustomAssetInfo(_ARG_1_) == nil then
        return Enum_CustomAssetType.None
      end
      do return _ARG_0_:GetCustomAssetInfo(_ARG_1_).AssetType end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCustomAssetBinaryAsset"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetCustomAssetType(_ARG_1_) == Enum_CustomAssetType.BinaryAsset end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCustomAssetMountNeeded"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_:GetCustomAssetType(_ARG_1_, _ARG_2_) then
        return MountNeededType[_ARG_0_:GetCustomAssetType(_ARG_1_, _ARG_2_)]
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GenerateSeq"] = function(_ARG_0_)
    do
      _ARG_0_._CustomAssetManagerSeq = _ARG_0_._CustomAssetManagerSeq + 1
      do return _ARG_0_._CustomAssetManagerSeq end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCustomAssetDownloadState"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:IsCustomAssetKey(_ARG_1_, false) then
        return require((U1(28, 29, 60, 168, 216, 43, 183, 215, 169, 135, 254, 135, 91, 179, 5, 126, 236, 111, 65, 146, 49, 1, 133, 251, 180, 134, 161, 201, 82, 170, 20, 98, 237, 14, 86, 130, 56, 12, 141))).ENUM_DownloadState.Not
      end
      if _ARG_0_:CustomAssetIsCacheed(_ARG_1_) then
        return require((U1(28, 29, 60, 168, 216, 43, 183, 215, 169, 135, 254, 135, 91, 179, 5, 126, 236, 111, 65, 146, 49, 1, 133, 251, 180, 134, 161, 201, 82, 170, 20, 98, 237, 14, 86, 130, 56, 12, 141))).ENUM_DownloadState.Done
      end
      if _ARG_0_.uCustomAssetDownloader:GetDownloadInfo(_ARG_1_, (_ARG_0_:_GetCustomAssetUseSuffixType(_ARG_1_))) ~= nil then
        if _ARG_0_.uCustomAssetDownloader:GetDownloadInfo(_ARG_1_, (_ARG_0_:_GetCustomAssetUseSuffixType(_ARG_1_))).DownloadStatus == U2.Enum_CustomAssetDownloadState.SUCCESS then
          return require((U1(28, 29, 60, 168, 216, 43, 183, 215, 169, 135, 254, 135, 91, 179, 5, 126, 236, 111, 65, 146, 49, 1, 133, 251, 180, 134, 161, 201, 82, 170, 20, 98, 237, 14, 86, 130, 56, 12, 141))).ENUM_DownloadState.Done
        elseif _ARG_0_.uCustomAssetDownloader:GetDownloadInfo(_ARG_1_, (_ARG_0_:_GetCustomAssetUseSuffixType(_ARG_1_))).DownloadStatus == U2.Enum_CustomAssetDownloadState.FAILED then
          if _ARG_0_.uCustomAssetDownloader:GetDownloadInfo(_ARG_1_, (_ARG_0_:_GetCustomAssetUseSuffixType(_ARG_1_))).IsTimeoutFailed == true then
            return require((U1(28, 29, 60, 168, 216, 43, 183, 215, 169, 135, 254, 135, 91, 179, 5, 126, 236, 111, 65, 146, 49, 1, 133, 251, 180, 134, 161, 201, 82, 170, 20, 98, 237, 14, 86, 130, 56, 12, 141))).ENUM_DownloadState.Done
          else
            return require((U1(28, 29, 60, 168, 216, 43, 183, 215, 169, 135, 254, 135, 91, 179, 5, 126, 236, 111, 65, 146, 49, 1, 133, 251, 180, 134, 161, 201, 82, 170, 20, 98, 237, 14, 86, 130, 56, 12, 141))).ENUM_DownloadState.Error
          end
        elseif _ARG_0_.uCustomAssetDownloader:GetDownloadInfo(_ARG_1_, (_ARG_0_:_GetCustomAssetUseSuffixType(_ARG_1_))).DownloadStatus == U2.Enum_CustomAssetDownloadState.DOWNLOADING then
          return require((U1(28, 29, 60, 168, 216, 43, 183, 215, 169, 135, 254, 135, 91, 179, 5, 126, 236, 111, 65, 146, 49, 1, 133, 251, 180, 134, 161, 201, 82, 170, 20, 98, 237, 14, 86, 130, 56, 12, 141))).ENUM_DownloadState.Download
        elseif _ARG_0_.uCustomAssetDownloader:GetDownloadInfo(_ARG_1_, (_ARG_0_:_GetCustomAssetUseSuffixType(_ARG_1_))).DownloadStatus == U2.Enum_CustomAssetDownloadState.WAITING then
          return require((U1(28, 29, 60, 168, 216, 43, 183, 215, 169, 135, 254, 135, 91, 179, 5, 126, 236, 111, 65, 146, 49, 1, 133, 251, 180, 134, 161, 201, 82, 170, 20, 98, 237, 14, 86, 130, 56, 12, 141))).ENUM_DownloadState.Wait
        end
      end
      do return require((U1(28, 29, 60, 168, 216, 43, 183, 215, 169, 135, 254, 135, 91, 179, 5, 126, 236, 111, 65, 146, 49, 1, 133, 251, 180, 134, 161, 201, 82, 170, 20, 98, 237, 14, 86, 130, 56, 12, 141))).ENUM_DownloadState.Not end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AsyncLoadCustomAssetToBytes"] = function(_ARG_0_, _ARG_1_, _ARG_2_, ...)
    do
      print(bWriteLog and table.concat({
        U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 222, 34, 76, 131, 53, 51, 150, 229),
        U1(27, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 99, 179, 32, 110, 251, 36, 86, 221, 15, 1, 168, 231, 166, 135, 251, 242, 66, 181, 72)
      }) .. tostring(_ARG_1_) .. U1(95, 62, 32, 185, 254, 62, 247, 192, 169, 151, 217, 220, 89, 191, 88) .. tostring(_ARG_2_))
      if _ARG_2_ == nil then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AsyncLoadCustomAssetToBytesImplementation"] = function(_ARG_0_, _ARG_1_, _ARG_2_, ...)
    do
      print(bWriteLog and table.concat({
        U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 222, 34, 76, 131, 53, 51, 150, 229),
        U1(27, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 99, 179, 32, 110, 251, 36, 86, 180, 43, 31, 133, 241, 184, 135, 225, 205, 70, 184, 27, 104, 241, 113, 116, 158, 37, 26, 141, 207),
        U1(26, 8, 111)
      }) .. tostring(_ARG_1_) .. U1(95, 62, 32, 185, 254, 62, 247, 192, 169, 151, 217, 220, 89, 191, 88) .. tostring(_ARG_2_))
      if _ARG_2_ == nil then
        return
      end
      if _ARG_1_ == nil then
        return
      end
      if not _ARG_0_.uCustomAssetCacheManager:IsAssetCached(_ARG_1_, (_ARG_0_:_GetCustomAssetUseSuffixType(_ARG_1_))) then
        _ARG_0_:_NewCustomAssetDownloadCompletedInfo().LoadSeq = _ARG_0_:GenerateSeq(), _ARG_0_:_NewCustomAssetDownloadCompletedInfo()
        _ARG_0_:_NewCustomAssetDownloadCompletedInfo().Callback = function(...)
          do return CallCombinationArgs(U1, U2, ...) end
          return
        end
        _ARG_0_:_NewCustomAssetDownloadCompletedInfo().DownloadType = U2.CustomAssetDownloadType.DownloadAndLoad
        _ARG_0_.LoadSeqToDownloadCompletedInfo[_ARG_0_:GenerateSeq()] = _ARG_0_:_NewCustomAssetDownloadCompletedInfo(), require((U1(28, 29, 60, 168, 216, 43, 183, 215, 169, 135, 254, 246, 66, 181, 61, 113, 253, 32, 72, 152, 49, 0, 155, 255, 251, 129, 224, 212, 74, 163, 28))), table.pack(...), function(...)
          do return CallCombinationArgs(U1, U2, ...) end
          return
        end, _ARG_0_.LoadSeqToDownloadCompletedInfo
        _ARG_0_:_NewCustomAssetDownloadCompletedInfo().DownloadSeq = _ARG_0_.uCustomAssetDownloader:RequestDownloadAsset(_ARG_1_, false, _ARG_0_:_GetCustomAssetUseSuffixType(_ARG_1_), U3.LOW, _ARG_0_._CustomAssetDownloadHandle, _ARG_0_, (_ARG_0_:GenerateSeq()))
        return (_ARG_0_:GenerateSeq())
      else
        return 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AsyncLoadCustomAsset"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, ...)
    do
      print(bWriteLog and table.concat({
        U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 222, 34, 76, 131, 53, 51, 150, 229),
        U1(27, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 23, 149, 12, 86, 252, 50, 64, 137, 13, 10, 144, 174)
      }) .. tostring(_ARG_1_) .. U1(95, 62, 32, 185, 254, 62, 247, 192, 169, 151, 217, 220, 89, 191, 88) .. tostring(_ARG_2_))
      if _ARG_2_ == nil then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AsyncLoadCustomAssetImplementation"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, ...)
    do
      print(bWriteLog and table.concat({
        U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 222, 34, 76, 131, 53, 51, 150, 229),
        U1(27, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 126, 177, 18, 123, 234, 44, 64, 147, 50, 14, 157, 253, 186, 140, 175, 248, 84, 191, 23, 115, 212, 52, 76, 215)
      }) .. tostring(_ARG_1_) .. U1(95, 62, 32, 185, 254, 62, 247, 192, 169, 151, 217, 220, 89, 191, 88) .. tostring(_ARG_2_))
      if _ARG_2_ == nil then
        return
      end
      if _ARG_1_ == nil then
        return
      end
      if not _ARG_0_.uCustomAssetCacheManager:IsAssetCached(_ARG_1_, (_ARG_0_:_GetCustomAssetUseSuffixType(_ARG_1_))) then
        if _ARG_0_:GetCustomAssetDefaultBytes(_ARG_0_:GetCustomAssetInfo(_ARG_1_).AssetType) ~= nil then
        end
        _ARG_0_:_NewCustomAssetDownloadCompletedInfo().LoadSeq = _ARG_0_:GenerateSeq(), _ARG_0_:_NewCustomAssetDownloadCompletedInfo()
        _ARG_0_:_NewCustomAssetDownloadCompletedInfo().Callback = function(...)
          do return CallCombinationArgs(U1, U2, ...) end
          return
        end
        _ARG_0_:_NewCustomAssetDownloadCompletedInfo().DownloadType = U2.CustomAssetDownloadType.DownloadAndDeserialize
        _ARG_0_:_NewCustomAssetDownloadCompletedInfo().bIsTemp = false
        _ARG_0_:_NewCustomAssetDownloadCompletedInfo().DownloadPriority = U3.VERY_HIGH
        _ARG_0_.LoadSeqToDownloadCompletedInfo[_ARG_0_:GenerateSeq()] = _ARG_0_:_NewCustomAssetDownloadCompletedInfo(), require((U1(28, 29, 60, 168, 216, 43, 183, 215, 169, 135, 254, 246, 66, 181, 61, 113, 253, 32, 72, 152, 49, 0, 155, 255, 251, 129, 224, 212, 74, 163, 28))), table.pack(...), function(...)
          do return CallCombinationArgs(U1, U2, ...) end
          return
        end, _ARG_0_.LoadSeqToDownloadCompletedInfo
        _ARG_0_:_NewCustomAssetDownloadCompletedInfo().DownloadSeq = _ARG_0_.uCustomAssetDownloader:RequestDownloadAsset(_ARG_1_, _ARG_0_:_NewCustomAssetDownloadCompletedInfo().bIsTemp, _ARG_0_:_GetCustomAssetUseSuffixType(_ARG_1_), _ARG_0_:_NewCustomAssetDownloadCompletedInfo().DownloadPriority, _ARG_0_._CustomAssetDownloadHandle, _ARG_0_, (_ARG_0_:GenerateSeq()))
        return (_ARG_0_:GenerateSeq())
      else
        return 0
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CancelLoadCustomAsset"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 220, 48, 91, 142, 51, 19, 181, 235),
        U1(30, 21, 22, 184, 197, 43, 246, 201, 132, 129, 236, 204, 67, 252, 46, 120, 238, 37, 118, 152, 55, 85)
      }) .. tostring(_ARG_1_))
      if _ARG_0_.LoadSeqToDownloadCompletedInfo[_ARG_1_] ~= nil then
        _ARG_0_.LoadSeqToDownloadCompletedInfo[_ARG_1_] = nil
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeserializeCustomAsset"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, ...)
    do
      print(bWriteLog and table.concat({
        U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 219, 52, 70, 136, 36, 22, 152, 232),
        U1(22, 11, 48, 142, 195, 44, 237, 203, 168, 179, 236, 218, 82, 168, 66, 84, 250, 50, 81, 146, 43, 46, 154, 231, 176, 150, 219, 192, 87, 169, 72)
      }) .. tostring(_ARG_2_))
      if _ARG_4_ == nil or type(_ARG_4_) ~= U1(25, 4, 59, 174, 194, 54, 246, 202) then
        return
      end
      if _ARG_1_ == nil then
        print(bWriteLog and table.concat({
          U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 219, 52, 70, 136, 36, 22, 152, 232),
          U1(22, 11, 48, 142, 195, 44, 237, 203, 168, 179, 236, 218, 82, 168, 66, 86, 252, 50, 64, 137, 4, 22, 157, 241, 166, 194, 230, 202, 7, 162, 27, 107)
        }))
        _ARG_4_((...), nil)
        return
      end
      if _ARG_3_ == nil then
        _ARG_3_ = U2.Enum_CustomAssetSuffixType.Source
        if U3[_ARG_2_] ~= nil then
          if U3[_ARG_2_].DefaultSuffixType then
            _ARG_3_ = U3[_ARG_2_].DefaultSuffixType
          elseif U3[_ARG_2_].PlatformAsset ~= nil then
            if _ARG_0_.CurPlatformSuffixType == nil then
              _ARG_0_.CurPlatformSuffixType = _ARG_0_:GetCurPlatformSuffixType()
            end
            if U3[_ARG_2_].PlatformAsset[_ARG_0_.CurPlatformSuffixType] == true then
              _ARG_3_ = _ARG_0_.CurPlatformSuffixType
            end
          end
        end
      end
      if slua.isValid((_ARG_0_:GetCustomAssetObjectFromTrackedMap((U4.MD5HashByteArray(_ARG_1_))))) then
        return
      end
      if slua.isValid((_ARG_0_:GetAssetDeserializer(_ARG_2_))) then
        _ARG_0_.DeserializeCallbackMap[_ARG_0_:GenerateSeq()] = {
          Callback = function(...)
            do return CallCombinationArgs(U1, U2, ...) end
            return
          end,
          BytesMD5 = U4.MD5HashByteArray(_ARG_1_),
          AsyncLoadStack = U1()
        }, _ARG_0_.DeserializeCallbackMap
        if not _ARG_0_:GetAssetDeserializer(_ARG_2_):Deserialize(_ARG_1_, _ARG_3_, _ARG_0_:GenerateSeq(), _ARG_0_:GetCustomAssetOuter()) then
          return
        end
      else
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UploadCustomAsset"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, ...)
    do
      if not _ARG_0_:CheckSourceBytesIsValid(_ARG_1_, _ARG_2_) then
        print(bWriteLog and table.concat({
          U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 202, 33, 89, 130, 55, 27, 186, 241),
          U1(12, 5, 58, 160, 247, 44, 234, 193, 177, 210, 204, 198, 66, 174, 1, 114, 205, 56, 81, 152, 53, 79, 167, 251, 161, 194, 198, 202, 113, 173, 30, 110, 251)
        }))
        return 0
      end
      if not slua.isValid(_ARG_0_.uCustomAssetUploader) then
        print(bWriteLog and table.concat({
          U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 202, 33, 89, 130, 55, 27, 186, 241),
          U1(12, 5, 58, 160, 247, 44, 234, 193, 177, 210, 234, 234, 66, 175, 22, 120, 226, 0, 86, 142, 35, 27, 188, 228, 185, 141, 238, 221, 66, 190, 82, 73, 240, 37, 21, 132, 37, 41, 152, 232),
          U1(22, 21)
        }))
        return 0
      end
      if _ARG_0_.uCustomAssetUploader:CustomAssetUploading() or _ARG_0_.CurCustomAssetUploaderInfo ~= nil then
        print(bWriteLog and table.concat({
          U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 202, 33, 89, 130, 55, 27, 186, 241),
          U1(12, 5, 58, 160, 247, 44, 234, 193, 177, 210, 220, 220, 68, 168, 13, 122, 206, 50, 86, 152, 50, 58, 153, 248, 186, 131, 235, 208, 73, 171)
        }))
        return 0
      end
      if _ARG_0_:GenerateCustomAssetKey(_ARG_1_, _ARG_2_) == nil then
        return 0
      end
      _ARG_0_.CurCustomAssetUploaderInfo = _ARG_0_:_NewCustomAssetUploaderInfo()
      _ARG_0_.CurCustomAssetUploaderInfo.UploaderSeq = _ARG_0_:GenerateSeq()
      _ARG_0_.CurCustomAssetUploaderInfo.SourceBytes = _ARG_1_
      _ARG_0_.CurCustomAssetUploaderInfo.CustomAssetType = _ARG_2_
      _ARG_0_.CurCustomAssetUploaderInfo.AssetKey = _ARG_0_:GenerateCustomAssetKey(_ARG_1_, _ARG_2_), _ARG_0_.CurCustomAssetUploaderInfo
      _ARG_0_.CurCustomAssetUploaderInfo.PlatformCustomAssetInfoList = _ARG_3_
      _ARG_0_.CurCustomAssetUploaderInfo.IsTempUpload = _ARG_4_
      _ARG_0_.CurCustomAssetUploaderInfo.AssetSuffixType = _ARG_5_ or U2.Enum_CustomAssetSuffixType.Source
      if _ARG_6_ ~= nil then
        _ARG_0_.CurCustomAssetUploaderInfo.UploaderCallback = function(...)
          do return CallCombinationArgs(U1, U2, ...) end
          return
        end, _ARG_0_.CurCustomAssetUploaderInfo
      end
      if _ARG_3_ == nil and slua.isValid((_ARG_0_:GetAssetPlatformBuilder(_ARG_2_))) then
      end
      if true then
      else
      end
      do return _ARG_0_.CurCustomAssetUploaderInfo.UploaderSeq end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1[177]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckSourceBytesIsValid"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_1_ == nil or _ARG_1_ == _ENV() then
        return false
      end
      if U1[_ARG_2_] == nil then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnSourceObjectDeserializeCompletedHandle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 192, 30, 91, 190, 57, 10, 139, 231),
        U1(26, 62, 55, 167, 211, 60, 237, 224, 160, 129, 250, 219, 94, 189, 14, 126, 245, 36, 102, 146, 43, 31, 133, 241, 161, 135, 235, 241, 70, 162, 22, 107, 250, 113, 96, 157, 58, 16, 152, 224),
        U1(26, 3, 6, 168, 199, 101)
      }) .. tostring(_ARG_1_) .. U1(95, 4, 20, 190, 197, 58, 237, 235, 167, 152, 250, 202, 67, 230) .. tostring(_ARG_2_))
      if _ARG_0_.CurCustomAssetUploaderInfo ~= nil and _ARG_1_ == _ARG_0_.CurCustomAssetUploaderInfo.UploaderSeq then
        if slua.isValid((_ARG_0_:GetAssetPlatformBuilder(_ARG_0_.CurCustomAssetUploaderInfo.CustomAssetType))) then
          if not _ARG_0_:GetAssetPlatformBuilder(_ARG_0_.CurCustomAssetUploaderInfo.CustomAssetType):StartBuild(_ARG_0_.CurCustomAssetUploaderInfo.SourceBytes, _ARG_0_.CurCustomAssetUploaderInfo.UploaderSeq, _ARG_2_) then
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RequestUploadAsset"] = function(_ARG_0_)
    do
      if _ARG_0_.CurCustomAssetUploaderInfo ~= nil then
        _ARG_0_.uCustomAssetUploader:RequestUploadAsset(_ARG_0_.CurCustomAssetUploaderInfo.AssetKey, _ARG_0_.CurCustomAssetUploaderInfo.SourceBytes, _ARG_0_.CurCustomAssetUploaderInfo.PlatformCustomAssetInfoList, _ARG_0_.CurCustomAssetUploaderInfo.IsTempUpload, _ARG_0_.CurCustomAssetUploaderInfo.AssetSuffixType, _ARG_0_.OnUploadCompletedHandle, _ARG_0_, _ARG_0_.CurCustomAssetUploaderInfo.UploaderSeq)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CustomAssetIsCacheed"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.uCustomAssetCacheManager:IsAssetCached(_ARG_0_:AdaptiveCustomAssetKey(_ARG_1_), (_ARG_0_:_GetCustomAssetUseSuffixType((_ARG_0_:AdaptiveCustomAssetKey(_ARG_1_))))) then
        return true
      end
      if _ARG_0_:_GetFallbackSuffixType(_ARG_0_:AdaptiveCustomAssetKey(_ARG_1_), (_ARG_0_:_GetCustomAssetUseSuffixType((_ARG_0_:AdaptiveCustomAssetKey(_ARG_1_))))) ~= nil then
        return _ARG_0_.uCustomAssetCacheManager:IsAssetCached(_ARG_0_:AdaptiveCustomAssetKey(_ARG_1_), (_ARG_0_:_GetFallbackSuffixType(_ARG_0_:AdaptiveCustomAssetKey(_ARG_1_), (_ARG_0_:_GetCustomAssetUseSuffixType((_ARG_0_:AdaptiveCustomAssetKey(_ARG_1_)))))))
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCustomAssetCacheMetaList"] = function(_ARG_0_)
    do
      do return _ARG_0_.uCustomAssetCacheManager:GetCustomAssetCacheMetaList() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCustomAssetCacheMetaInfo"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_.uCustomAssetCacheManager:GetCustomAssetCacheMetaInfo(_ARG_1_, (_ARG_0_:_GetCustomAssetUseSuffixType(_ARG_1_))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DownloadCustomAsset"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, ...)
    do
      if not _ARG_0_:IsCustomAssetKey(_ARG_1_, false) then
        if _ARG_4_ ~= nil then
          if ((type(_ARG_3_) == U1(11, 16, 55, 161, 211) and _ARG_3_ or nil) and (type(_ARG_3_) == U1(11, 16, 55, 161, 211) and _ARG_3_ or nil).DownloadType or U2.CustomAssetDownloadType.DownloadOnly) == U2.CustomAssetDownloadType.DownloadAndLoad then
          else
          end
        end
        return 0
      end
      if not _ARG_0_.uCustomAssetCacheManager:IsAssetCached(_ARG_1_, (_ARG_0_:_GetCustomAssetUseSuffixType(_ARG_1_))) then
        if _ARG_4_ ~= nil then
          _ARG_0_:_NewCustomAssetDownloadCompletedInfo().Callback = function(...)
            do return CallCombinationArgs(U1, U2, ...) end
            return
          end
        end
        _ARG_0_:_NewCustomAssetDownloadCompletedInfo().DownloadType = (type(_ARG_3_) == U1(11, 16, 55, 161, 211) and _ARG_3_ or nil) and (type(_ARG_3_) == U1(11, 16, 55, 161, 211) and _ARG_3_ or nil).DownloadType or U2.CustomAssetDownloadType.DownloadOnly
        _ARG_0_:_NewCustomAssetDownloadCompletedInfo().DownloadPriority, _ARG_0_:_NewCustomAssetDownloadCompletedInfo().bIsTemp = (type(_ARG_3_) == U1(11, 16, 55, 161, 211) and _ARG_3_ or nil) and (type(_ARG_3_) == U1(11, 16, 55, 161, 211) and _ARG_3_ or nil).Priority or U3.LOW, _ARG_2_ == true
        _ARG_0_:_NewCustomAssetDownloadCompletedInfo().DownloadSeq = _ARG_0_.uCustomAssetDownloader:RequestDownloadAsset(_ARG_1_, _ARG_0_:_NewCustomAssetDownloadCompletedInfo().bIsTemp, _ARG_0_:_GetCustomAssetUseSuffixType(_ARG_1_), _ARG_0_:_NewCustomAssetDownloadCompletedInfo().DownloadPriority, _ARG_0_._CustomAssetDownloadHandle, _ARG_0_, (_ARG_0_:_NewCustomAssetDownloadCompletedInfo()))
        return _ARG_0_:_NewCustomAssetDownloadCompletedInfo().DownloadSeq
      else
        if _ARG_4_ ~= nil then
          if ((type(_ARG_3_) == U1(11, 16, 55, 161, 211) and _ARG_3_ or nil) and (type(_ARG_3_) == U1(11, 16, 55, 161, 211) and _ARG_3_ or nil).DownloadType or U2.CustomAssetDownloadType.DownloadOnly) == U2.CustomAssetDownloadType.DownloadAndLoad then
          else
          end
        end
        return 0
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DownloadCustomAssetList"] = function(_ARG_0_, _ARG_1_, _ARG_2_, ...)
    do
      print(bWriteLog and table.concat({
        U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 219, 62, 66, 131, 58, 16, 152, 224),
        U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 229, 94, 175, 22, 55, 206, 50, 86, 152, 50, 36, 140, 237, 153, 139, 252, 205, 29)
      }) .. tostring(_ARG_1_))
      if _ARG_1_ ~= nil then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if 0 < #{} then
        _ARG_0_:_NewCustomAssetBatchDownloadCompletedInfo().BatchDownloadSeq = _ARG_0_:GenerateSeq(), _ARG_0_:_NewCustomAssetBatchDownloadCompletedInfo()
        if _ARG_2_ ~= nil then
          _ARG_0_:_NewCustomAssetBatchDownloadCompletedInfo().Callback = function(...)
            do return CallCombinationArgs(U1, U2, ...) end
            return
          end
        end
        _ARG_0_.BatchDownloadWaitMap[_ARG_0_:GenerateSeq()] = _ARG_0_:_NewCustomAssetBatchDownloadCompletedInfo(), _ARG_0_.BatchDownloadWaitMap
        _ARG_0_ = _ARG_0_
        _ARG_0_:_NewCustomAssetBatchDownloadCompletedInfo().DownloadMap[({})[...]] = _ARG_0_:DownloadCustomAsset(({})[...], false, nil, _ARG_0_._CustomAssetBatchDownloadHandle, _ARG_0_, (_ARG_0_:GenerateSeq()))
        _ARG_0_ = _ARG_0_
        return (_ARG_0_:GenerateSeq())
      else
        if _ARG_2_ ~= nil then
        end
        return 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CancelDownloadAsset"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.BatchDownloadWaitMap[_ARG_1_] ~= nil then
        _ARG_0_.BatchDownloadWaitMap[_ARG_1_] = nil
        goto lbl_33
        if type(nil) == U1(17, 4, 56, 175, 211, 45) and 0 < nil then
        end
        ::lbl_33::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        return true, _ARG_0_.BatchDownloadWaitMap[_ARG_1_].DownloadMap
      else
        return (_ARG_0_.uCustomAssetDownloader:CancelDownloadAsset(_ARG_1_))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ForceCancelAllDownload"] = function(_ARG_0_)
    do
      _ARG_0_.uCustomAssetDownloader:ForceCancelAllDownload()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CacheCustomAssetBytes"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_.uCustomAssetCacheManager:CacheAssetToFile(_ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeleteCacheCustomAsset"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:IsCustomAssetKey(_ARG_1_) then
        return
      end
      if GameStatus.IsInFightingNotMainCity() and _G.IsEditor ~= true then
        print(bWriteLog and table.concat({
          U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 228, 86, 178, 3, 112, 234, 51, 31, 185, 35, 3, 140, 224, 176, 161, 238, 218, 79, 169, 49, 114, 236, 37, 90, 128, 23, 12, 138, 225),
          U1(11, 81, 28, 163, 150, 25, 240, 195, 173, 134, 246, 199, 80)
        }))
        return
      end
      _ARG_0_.uCustomAssetCacheManager:DeleteCacheAsset(_ARG_1_, _ARG_2_)
      _ARG_0_.uCustomAssetDownloader:DeleteCacheAsset(_ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[246]
    end
  end,
  ["DeleteCacheCustomAssetList"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == nil then
        return
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_0_:GetCustomAssetInfo(_ARG_1_[nil]) and ({
        [nil] = {TotalCount = 0, TotalSize = 0}
      })[U1[_ARG_0_:GetCustomAssetInfo(_ARG_1_[nil]).AssetType].ToPrefabType] then
        ;({
          [nil] = {TotalCount = 0, TotalSize = 0}
        })[U1[_ARG_0_:GetCustomAssetInfo(_ARG_1_[nil]).AssetType].ToPrefabType].TotalCount = ({
          [nil] = {TotalCount = 0, TotalSize = 0}
        })[U1[_ARG_0_:GetCustomAssetInfo(_ARG_1_[nil]).AssetType].ToPrefabType].TotalCount + 1
        ;({
          [nil] = {TotalCount = 0, TotalSize = 0}
        })[U1[_ARG_0_:GetCustomAssetInfo(_ARG_1_[nil]).AssetType].ToPrefabType].TotalSize = ({
          [nil] = {TotalCount = 0, TotalSize = 0}
        })[U1[_ARG_0_:GetCustomAssetInfo(_ARG_1_[nil]).AssetType].ToPrefabType].TotalSize + _ARG_0_:GetCustomAssetInfo(_ARG_1_[nil]).AssetSize
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRepUnmountCustomAssetHandle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and table.concat({
        U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 228, 86, 178, 3, 112, 234, 51, 31, 178, 40, 61, 140, 228, 128, 140, 226, 214, 82, 162, 6, 68, 234, 34, 65, 130, 59, 62, 138, 247),
        U1(26, 5, 29, 172, 216, 59, 245, 193, 229, 177, 234, 218, 67, 179, 15, 86, 252, 50, 64, 137, 13, 10, 144, 174)
      }) .. tostring(_ARG_1_) .. U1(95, 52, 39, 191, 217, 45, 218, 203, 161, 151, 165) .. tostring(_ARG_3_))
      if _ARG_2_ == true then
        _ARG_0_:_CallUnmountCallBack(_ARG_1_, U2.Enum_CustomAssetErrorCode.None)
      else
        _ARG_0_:_CallUnmountCallBack(_ARG_1_, _ARG_3_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[179]
    end
  end,
  ["_CallUnmountCallBack"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.UnmountCallBackMap[_ARG_1_] = nil
      if _ARG_0_.UnmountCallBackMap[_ARG_1_] ~= nil then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetMountPlayerKey"] = function(_ARG_0_)
    do
      do return (U1.GetPlayerState():GetPlayerKey()) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MountCustomAsset"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and table.concat({
        U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 228, 86, 178, 3, 112, 234, 51, 31, 176, 41, 26, 135, 224, 150, 151, 252, 205, 72, 161, 51, 116, 236, 52, 65, 205, 23, 12, 138, 225),
        U1(11, 58, 48, 180, 140)
      }) .. tostring(_ARG_1_) .. U1(95, 19, 28, 190, 247, 42, 237, 203, 136, 157, 234, 199, 67, 230) .. tostring(_ARG_2_) .. U1(95, 60, 52, 189, 198, 54, 247, 195, 140, 156, 249, 198, 13) .. tostring(_ARG_3_))
      if not _ARG_0_:IsDedicatedServer() and not GameStatus.IsInFightingNotMainCity() then
        return U2.Enum_CustomAssetErrorCode.UnmountCustomAssetError_Normal
      end
      if slua.isValid(CGameState) and CGameState.GetCustomAssetMountStateComponent ~= nil and slua.isValid((CGameState:GetCustomAssetMountStateComponent())) then
        return CGameState:GetCustomAssetMountStateComponent():MountCustomAsset(_ARG_1_, _ARG_2_, _ARG_0_:_GetMountPlayerKey(), _ARG_3_)
      end
      do return U2.Enum_CustomAssetErrorCode.UnmountCustomAssetError_Normal end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CustomAssetBatchMountHandle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and table.concat({
        U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 228, 86, 178, 3, 112, 234, 51, 31, 162, 5, 26, 154, 224, 186, 143, 206, 202, 84, 169, 6, 69, 254, 37, 86, 133, 27, 16, 140, 234),
        U1(11, 57, 52, 163, 210, 51, 252, 132, 135, 147, 235, 202, 95, 145, 13, 98, 225, 53, 118, 152, 55, 85)
      }) .. tostring(_ARG_1_) .. U1(95, 48, 38, 190, 211, 43, 210, 193, 188, 200) .. tostring(_ARG_2_) .. U1(95, 19, 24, 162, 195, 49, 237, 247, 176, 145, 165) .. tostring(_ARG_3_))
      if _ARG_0_.BatchMountWaitMap[_ARG_1_] ~= nil then
        _ARG_0_.BatchMountWaitMap[_ARG_1_].MountMap[_ARG_2_] = _ARG_3_
        goto lbl_145
        if type(_ARG_3_) == U1(17, 4, 56, 175, 211, 45) and 0 < _ARG_3_ then
          goto lbl_147
        elseif _ARG_3_ ~= true then
        end
        ::lbl_145::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        ::lbl_147::
        if false == true then
          _ARG_0_.BatchMountWaitMap[_ARG_1_] = nil
          if _ARG_0_.BatchMountWaitMap[_ARG_1_].Callback ~= nil then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MountCustomAssetList"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_:IsDedicatedServer() and not GameStatus.IsInFightingNotMainCity() then
        return U1.Enum_CustomAssetErrorCode.UnmountCustomAssetError_Normal
      end
      if _ARG_1_ == nil or #_ARG_1_ == 0 then
        return U1.Enum_CustomAssetErrorCode.UnmountCustomAssetError_Normal
      end
      print(bWriteLog and table.concat({
        U2(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 228, 86, 178, 3, 112, 234, 51, 31, 176, 41, 26, 135, 224, 150, 151, 252, 205, 72, 161, 51, 116, 236, 52, 65, 161, 63, 12, 141, 164),
        U2(62, 2, 38, 168, 194, 20, 252, 221, 137, 155, 236, 221, 23, 191, 13, 98, 225, 53, 31)
      }) .. tostring(#_ARG_1_))
      if slua.isValid(CGameState) and CGameState.GetCustomAssetMountStateComponent ~= nil and slua.isValid((CGameState:GetCustomAssetMountStateComponent())) then
        if CGameState:GetCustomAssetMountStateComponent():CheckCanMountCustomAsset(_ARG_1_, _ARG_2_) ~= U1.Enum_CustomAssetErrorCode.None then
          return (CGameState:GetCustomAssetMountStateComponent():CheckCanMountCustomAsset(_ARG_1_, _ARG_2_))
        end
        _ARG_0_.BatchMountSeq = (_ARG_0_.BatchMountSeq or 0) + 1
        _ARG_0_ = _ARG_0_
        ;({
          BatchMountSeq = _ARG_0_.BatchMountSeq,
          MountMap = {},
          Callback = _ARG_3_
        }).MountMap[_ARG_1_[U2(60, 30, 49, 168, 140)]] = 1
        _ARG_0_ = _ARG_0_
        _ARG_0_.BatchMountWaitMap[_ARG_0_.BatchMountSeq] = {
          BatchMountSeq = _ARG_0_.BatchMountSeq,
          MountMap = {},
          Callback = _ARG_3_
        }, _ARG_0_.BatchMountWaitMap
        _ARG_0_ = _ARG_0_
        if _ARG_0_:CustomAssetIsMounted(_ARG_1_[({
          BatchMountSeq = _ARG_0_.BatchMountSeq,
          MountMap = {},
          Callback = _ARG_3_
        }).MountMap]) then
        elseif _ARG_0_.BatchAssetKeyMap[_ARG_1_[({
          BatchMountSeq = _ARG_0_.BatchMountSeq,
          MountMap = {},
          Callback = _ARG_3_
        }).MountMap]] == nil then
          _ARG_0_.BatchAssetKeyMap[_ARG_1_[({
            BatchMountSeq = _ARG_0_.BatchMountSeq,
            MountMap = {},
            Callback = _ARG_3_
          }).MountMap]] = {}
        end
        _ARG_0_ = _ARG_0_
        return U1.Enum_CustomAssetErrorCode.None
      end
      do return U1.Enum_CustomAssetErrorCode.UnmountCustomAssetError_Normal end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UnmountCustomAsset"] = function(_ARG_0_, _ARG_1_, _ARG_2_, ...)
    do
      print(bWriteLog and table.concat({
        U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 228, 86, 178, 3, 112, 234, 51, 31, 168, 40, 2, 134, 225, 187, 150, 204, 204, 84, 184, 29, 106, 222, 34, 70, 136, 34, 95, 184, 247),
        U1(12, 20, 33, 134, 211, 38, 163)
      }) .. tostring(_ARG_1_))
      if not _ARG_0_:IsDedicatedServer() and not GameStatus.IsInFightingNotMainCity() then
        return false
      end
      if _ARG_2_ ~= nil then
        if _ARG_0_.UnmountCallBackMap[_ARG_1_] == nil then
          _ARG_0_.UnmountCallBackMap[_ARG_1_] = {}, _ARG_0_.UnmountCallBackMap
        end
      end
      if slua.isValid(CGameState) and CGameState.GetCustomAssetMountStateComponent ~= nil and slua.isValid((CGameState:GetCustomAssetMountStateComponent())) then
        if CGameState:GetCustomAssetMountStateComponent():UnmountCustomAsset(_ARG_1_, _ARG_0_:_GetMountPlayerKey()) ~= U2.Enum_CustomAssetErrorCode.None then
          return false
        else
          return true
        end
      end
      _ARG_0_:_CallUnmountCallBack(_ARG_1_, U2.Enum_CustomAssetErrorCode.UnmountCustomAssetError_Normal)
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CustomAssetIsMounted"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:IsDedicatedServer() and not GameStatus.IsInFightingNotMainCity() then
        return false
      end
      if slua.isValid(CGameState) and CGameState.GetCustomAssetMountStateComponent ~= nil and slua.isValid((CGameState:GetCustomAssetMountStateComponent())) then
        return CGameState:GetCustomAssetMountStateComponent():CustomAssetIsMounted(_ARG_1_)
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMountedCustomAssetMap"] = function(_ARG_0_)
    do
      if not _ARG_0_:IsDedicatedServer() and not GameStatus.IsInFightingNotMainCity() then
        return {}
      end
      if slua.isValid(CGameState) and CGameState.GetCustomAssetMountStateComponent ~= nil and slua.isValid((CGameState:GetCustomAssetMountStateComponent())) then
        return CGameState:GetCustomAssetMountStateComponent():GetMountedCustomAssetMap()
      end
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMountedCustomSize"] = function(_ARG_0_)
    do
      if _ARG_0_:GetMountedCustomAssetMap() then
        goto lbl_17
        if nil and (nil).CustomAssetInfo then
        end
        ::lbl_17::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return 0 + (nil).CustomAssetInfo.AssetSize end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCustomAssetMountedInfo"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:IsDedicatedServer() and not GameStatus.IsInFightingNotMainCity() then
        return nil
      end
      if slua.isValid(CGameState) and CGameState.GetCustomAssetMountStateComponent ~= nil and slua.isValid((CGameState:GetCustomAssetMountStateComponent())) then
        return CGameState:GetCustomAssetMountStateComponent():GetCustomAssetMountedInfo(_ARG_1_)
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsDsAutoMountReplicateComplete"] = function(_ARG_0_)
    do
      if slua.isValid(CGameState) and CGameState.GetCustomAssetMountStateComponent ~= nil and slua.isValid((CGameState:GetCustomAssetMountStateComponent())) and CGameState:GetCustomAssetMountStateComponent().IsDsAutoMountAllReplicated ~= nil then
        return CGameState:GetCustomAssetMountStateComponent():IsDsAutoMountAllReplicated()
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GenerateDsAutoMountCallBackID"] = function(_ARG_0_)
    do
      _ARG_0_._CurDsAutoMountCallBackID = _ARG_0_._CurDsAutoMountCallBackID + 1
      do return _ARG_0_._CurDsAutoMountCallBackID end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddDsAutoMountReplicateCompleteCallBack"] = function(_ARG_0_, _ARG_1_, ...)
    do
      print(bWriteLog and table.concat({
        U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 222, 53, 81, 169, 37, 62, 140, 240),
        U1(16, 60, 58, 184, 216, 43, 203, 193, 181, 158, 246, 202, 86, 168, 7, 84, 224, 44, 85, 145, 35, 27, 140, 215, 180, 142, 227, 251, 70, 175, 25)
      }))
      if _ARG_0_:IsDsAutoMountReplicateComplete() then
        return -1
      end
      _ARG_0_._DsAutoMountReplicateCompleteCallBackMap[_ARG_0_:_GenerateDsAutoMountCallBackID()] = function(...)
        do return CallCombinationArgs(U1, U2, ...) end
        return
      end, _ARG_0_:_GenerateDsAutoMountCallBackID(), _ARG_0_._DsAutoMountReplicateCompleteCallBackMap
      do return (_ARG_0_:_GenerateDsAutoMountCallBackID()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoveDsAutoMountReplicateCompleteCallBack"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 205, 52, 88, 130, 32, 26, 189, 247),
        U1(62, 4, 33, 162, 251, 48, 236, 202, 177, 160, 250, 217, 91, 181, 1, 118, 251, 36, 102, 146, 43, 31, 133, 241, 161, 135, 204, 216, 75, 160, 48, 102, 252, 58, 21, 174, 55, 19, 149, 198),
        U1(30, 18, 62, 132, 242, 101)
      }) .. tostring(_ARG_1_))
      if _ARG_0_._DsAutoMountReplicateCompleteCallBackMap[_ARG_1_] then
        _ARG_0_._DsAutoMountReplicateCompleteCallBackMap[_ARG_1_] = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDsAutoMountAllReplicated"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 208, 63, 113, 158, 23, 10, 141, 235),
        U1(50, 30, 32, 163, 194, 30, 245, 200, 151, 151, 239, 197, 94, 191, 3, 99, 234, 37)
      }))
      if next(_ARG_0_._DsAutoMountReplicateCompleteCallBackMap) == nil then
        return
      end
      _ARG_0_._DsAutoMountReplicateCompleteCallBackMap = {}
      goto lbl_225
      if not xpcall(160, require((U1(28, 30, 56, 160, 217, 49, 183, 209, 177, 155, 243, 192, 67, 165))).ErrorMessageHandler) then
      end
      ::lbl_225::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPrefabMallDataUpdateCompleted"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 208, 63, 101, 159, 51, 25, 152, 230),
        U1(50, 16, 57, 161, 242, 62, 237, 197, 144, 130, 251, 200, 67, 185, 33, 120, 226, 49, 73, 152, 50, 10, 141)
      }))
      goto lbl_89
      if U1(50, 16, 57, 161, 242, 62, 237, 197, 144, 130, 251, 200, 67, 185, 33, 120, 226, 49, 73, 152, 50, 10, 141).OnPrefabMallDataUpdateCompletedHandle ~= nil then
      end
      ::lbl_89::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMountStateChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_:GetCustomAssetMountedInfo(_ARG_3_) ~= nil then
        if _ARG_0_.CallInMountHandleAssetMap[_ARG_3_] ~= true and _ARG_0_:GetCustomAssetInfo(_ARG_3_) ~= nil and _ENV[_ARG_0_:GetCustomAssetInfo(_ARG_3_).AssetType] ~= nil and _ENV[_ARG_0_:GetCustomAssetInfo(_ARG_3_).AssetType].InMountHandle ~= nil then
          _ARG_0_.CallInMountHandleAssetMap[_ARG_3_] = true
        end
        if _ARG_0_:GetCustomAssetMountedInfo(_ARG_3_).MountStatus == U1.Mounted and _ARG_0_.CallInMountedHandleAssetMap[_ARG_3_] ~= true and _ARG_0_:GetCustomAssetInfo(_ARG_3_) ~= nil and _ENV[_ARG_0_:GetCustomAssetInfo(_ARG_3_).AssetType] ~= nil and _ENV[_ARG_0_:GetCustomAssetInfo(_ARG_3_).AssetType].InMountedHandle ~= nil then
          _ARG_0_.CallInMountedHandleAssetMap[_ARG_3_] = true
        end
      elseif _ARG_0_.CallInMountedHandleAssetMap[_ARG_3_] == true or _ARG_0_.CallInMountHandleAssetMap[_ARG_3_] == true then
        _ARG_0_.CallInMountedHandleAssetMap[_ARG_3_] = nil
        _ARG_0_.CallInMountHandleAssetMap[_ARG_3_] = nil
        if _ARG_0_:GetCustomAssetInfo(_ARG_3_) ~= nil and _ENV[_ARG_0_:GetCustomAssetInfo(_ARG_3_).AssetType] ~= nil and _ENV[_ARG_0_:GetCustomAssetInfo(_ARG_3_).AssetType].OutMountedHandle ~= nil then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_AssetBatchMountStatusCheck"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      print(bWriteLog and table.concat({
        U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 131, 35, 100, 252, 36, 81, 191, 39, 27, 138, 252, 152, 141, 250, 215, 83, 159, 6, 102, 235, 36, 70, 174, 62, 26, 154, 239),
        U1(95, 48, 38, 190, 211, 43, 210, 193, 188, 200)
      }) .. tostring(_ARG_1_))
      if _ARG_0_:GetCustomAssetMountedInfo(_ARG_1_) == nil then
        return
      end
      if _ARG_0_:GetCustomAssetMountedInfo(_ARG_1_) ~= nil and _ARG_0_:GetCustomAssetMountedInfo(_ARG_1_).MountStatus == U2.Mounting then
        return
      end
      if _ARG_0_.BatchAssetKeyMap[_ARG_1_] then
        goto lbl_107
        if _ARG_0_:GetCustomAssetMountedInfo(_ARG_1_) ~= nil and _ARG_0_:GetCustomAssetMountedInfo(_ARG_1_).MountStatus == U2.Mounted then
        end
        ::lbl_107::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _ARG_0_.BatchAssetKeyMap[_ARG_1_] = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCustomAssetHashIDMappingChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      goto lbl_22
      if _ARG_0_:GetCustomAssetKeyByHashID(nil) ~= nil then
        _ARG_0_.WaitCustomAssetHashIDInfoMap[nil] = nil
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_22::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_:CheckAndEndWaitCustomAssetHashIDMapping()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AdaptiveCustomAssetKeyAsync"] = function(_ARG_0_, _ARG_1_, _ARG_2_, ...)
    do
      if _ARG_2_ == nil then
        return
      end
      if _ARG_0_:IsCustomAssetKeyHashID(_ARG_1_) then
        if _ARG_0_:GetCustomAssetKeyByHashID(_ARG_1_) ~= nil then
        elseif _ARG_0_.WaitCustomAssetHashIDInfoMap[_ARG_1_] == nil then
          U2.FastCopyTable(U3).StartWaitTimestamp = U4.GetServerTimeInSeconds()
          _ARG_0_.WaitCustomAssetHashIDInfoMap[_ARG_1_] = U2.FastCopyTable(U3), _ARG_0_.WaitCustomAssetHashIDInfoMap
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartWaitCustomAssetHashIDMapping"] = function(_ARG_0_)
    do
      if _ARG_0_.WaitMappingTimer ~= nil then
        return
      end
      if next(_ARG_0_.WaitCustomAssetHashIDInfoMap) ~= nil then
      end
      if true then
        _ARG_0_.WaitMappingTimer = _ARG_0_:AddGameTimer(1, true, function()
          _ENV:_TickWaitCustomAssetHashIDMapping()
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_TickWaitCustomAssetHashIDMapping"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 228, 86, 178, 3, 112, 234, 51, 31, 162, 18, 6, 138, 255, 130, 131, 230, 205, 100, 185, 1, 115, 240, 60, 116, 158, 37, 26, 141, 204),
        U1(30, 2, 61, 132, 242, 18, 248, 212, 181, 155, 241, 206)
      }))
      goto lbl_90
      if U2.GetServerTimeInSeconds() - U1(30, 2, 61, 132, 242, 18, 248, 212, 181, 155, 241, 206).StartWaitTimestamp >= U3.WaitMappingTime then
        _ARG_0_.WaitCustomAssetHashIDInfoMap[U1(30, 2, 61, 132, 242, 18, 248, 212, 181, 155, 241, 206)] = nil
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_90::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAndEndWaitCustomAssetHashIDMapping"] = function(_ARG_0_)
    do
      if _ARG_0_.WaitMappingTimer == nil then
        return
      end
      if next(_ARG_0_.WaitCustomAssetHashIDInfoMap) ~= nil then
      end
      if false and _ARG_0_.WaitMappingTimer ~= nil then
        _ARG_0_.WaitMappingTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AdaptiveCustomAssetKey"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:IsCustomAssetKeyHashID(_ARG_1_) then
        return _ARG_0_:GetCustomAssetKeyByHashID(_ARG_1_)
      end
      do return _ARG_1_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GenerateCustomAssetKey"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_1_ == nil then
        print(bWriteLog and table.concat({
          U1(36, 50, 32, 190, 194, 48, 244, 229, 182, 129, 250, 221, 106, 159, 23, 100, 251, 46, 72, 188, 53, 28, 140, 224, 152, 131, 225, 216, 64, 169, 0, 61, 216, 52, 91, 136, 36, 30, 141, 225),
          U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 226, 82, 165, 66, 86, 252, 50, 64, 137, 4, 22, 157, 241, 166, 194, 230, 202, 7, 162, 27, 107)
        }))
        return nil
      end
      if _ARG_3_ ~= nil then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      goto lbl_147
      U2[_ARG_3_[164]] = nil
      ::lbl_147::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return (U3.SpliceCustomAssetKey(_ARG_2_, #_ARG_1_, U2)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ParseCustomAssetKey"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == nil then
        return -1, 0, {}
      end
      if type(_ARG_1_) == U1(12, 5, 39, 164, 216, 56) and string.match(_ARG_1_, U1(33) .. U2.CustomAssetKeyTag .. U1(90, 92, 125, 150, 232, 122, 180, 249, 238, 219, 186, 132, 31, 249, 6, 60, 166, 100, 8, 213, 104, 68, 192, 176)) and string.match(_ARG_1_, U1(33) .. U2.CustomAssetKeyTag .. U1(90, 92, 125, 150, 232, 122, 180, 249, 238, 219, 186, 132, 31, 249, 6, 60, 166, 100, 8, 213, 104, 68, 192, 176)) and string.match(_ARG_1_, U1(33) .. U2.CustomAssetKeyTag .. U1(90, 92, 125, 150, 232, 122, 180, 249, 238, 219, 186, 132, 31, 249, 6, 60, 166, 100, 8, 213, 104, 68, 192, 176)) then
        goto lbl_93
        ::lbl_93::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        return tonumber(string.match(_ARG_1_, U1(33) .. U2.CustomAssetKeyTag .. U1(90, 92, 125, 150, 232, 122, 180, 249, 238, 219, 186, 132, 31, 249, 6, 60, 166, 100, 8, 213, 104, 68, 192, 176))) or -1, tonumber(string.match(_ARG_1_, U1(33) .. U2.CustomAssetKeyTag .. U1(90, 92, 125, 150, 232, 122, 180, 249, 238, 219, 186, 132, 31, 249, 6, 60, 166, 100, 8, 213, 104, 68, 192, 176))) or 0, {}
      end
      do return tonumber(string.match(_ARG_1_, U1(33) .. U2.CustomAssetKeyTag .. U1(90, 92, 125, 150, 232, 122, 180, 249, 238, 219, 186, 132, 31, 249, 6, 60, 166, 100, 8, 213, 104, 68, 192, 176))) or -1, tonumber(string.match(_ARG_1_, U1(33) .. U2.CustomAssetKeyTag .. U1(90, 92, 125, 150, 232, 122, 180, 249, 238, 219, 186, 132, 31, 249, 6, 60, 166, 100, 8, 213, 104, 68, 192, 176))) or 0, {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = _ENV[32]
    end
  end,
  ["GenerateCustomAssetKeyHashID"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(12, 5, 39, 164, 216, 56) then
        return 0
      end
      if _ARG_0_:IsCustomAssetKey(_ARG_1_) and _ARG_0_:GetCustomAssetInfo(_ARG_1_) then
        return (_ARG_0_:GenerateHashIDByCustomAssetKey(_ARG_1_, _ARG_0_:GetCustomAssetInfo(_ARG_1_).AssetType, U2.CustomAssetKeyHashIDTag))
      end
      do return 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCustomAssetKeyHashID"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(17, 4, 56, 175, 211, 45) then
        return false
      end
      if _ARG_1_ <= U2 then
        return false
      end
      if _ARG_0_.CustomAssetKeyHashIDCheckMap[_ARG_1_] == nil then
        if _ARG_0_:ParseCustomAssetKeyHashID(_ARG_1_, U3.CustomAssetKeyHashIDTag, 0, 0) and 0 < _ARG_0_:ParseCustomAssetKeyHashID(_ARG_1_, U3.CustomAssetKeyHashIDTag, 0, 0) and _ARG_0_.CustomAssetTypeMap[_ARG_0_:ParseCustomAssetKeyHashID(_ARG_1_, U3.CustomAssetKeyHashIDTag, 0, 0)] ~= nil then
        end
        _ARG_0_.CustomAssetKeyHashIDCheckMap[_ARG_1_] = true, _ARG_0_.CustomAssetKeyHashIDCheckMap
      end
      do return _ARG_0_.CustomAssetKeyHashIDCheckMap[_ARG_1_] == true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCustomAssetKey"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) == U1(17, 4, 56, 175, 211, 45) then
        if _ARG_0_:GetCustomAssetKeyByHashID(_ARG_1_) ~= nil and type((_ARG_0_:GetCustomAssetKeyByHashID(_ARG_1_))) == U1(12, 5, 39, 164, 216, 56) then
          return (_ARG_0_:GetCustomAssetKeyByHashID(_ARG_1_))
        end
      elseif type(_ARG_1_) == U1(12, 5, 39, 164, 216, 56) then
        if _ARG_0_:GetCustomAssetInfo(_ARG_1_) ~= nil and _ARG_0_:GetCustomAssetInfo(_ARG_1_).AssetKey ~= nil then
          return _ARG_0_:GetCustomAssetInfo(_ARG_1_).AssetKey
        end
      else
      end
      do return _ARG_1_ end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCustomAssetKeyByHashID"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:IsCustomAssetKeyHashID(_ARG_1_) then
        return nil
      end
      if not _ARG_0_:IsDedicatedServer() and not GameStatus.IsInFightingNotMainCity() then
        return nil
      end
      if slua.isValid(CGameState) and CGameState.GetCustomAssetMountStateComponent ~= nil and slua.isValid((CGameState:GetCustomAssetMountStateComponent())) then
        return CGameState:GetCustomAssetMountStateComponent():GetCustomAssetKeyByHashID(_ARG_1_)
      end
      if not _ARG_0_:IsDedicatedServer() and _ARG_0_.CustomAssetKeyListHashToAssetMap and _ARG_0_.CustomAssetKeyListHashToAssetMap[_ARG_1_] then
        return _ARG_0_.CustomAssetKeyListHashToAssetMap[_ARG_1_]
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHashIDByCustomAssetKey"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:IsCustomAssetKey(_ARG_1_) then
        return 0
      end
      if not _ARG_0_:IsDedicatedServer() and not GameStatus.IsInFightingNotMainCity() then
        return 0
      end
      if slua.isValid(CGameState) and CGameState.GetCustomAssetMountStateComponent ~= nil and slua.isValid((CGameState:GetCustomAssetMountStateComponent())) then
        return CGameState:GetCustomAssetMountStateComponent():GetHashIDByCustomAssetKey(_ARG_1_)
      end
      if not _ARG_0_:IsDedicatedServer() and _ARG_0_.CustomAssetKeyListAssetToHashMap and _ARG_0_.CustomAssetKeyListAssetToHashMap[_ARG_1_] then
        return _ARG_0_.CustomAssetKeyListAssetToHashMap[_ARG_1_]
      end
      do return 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearUnusedCustomAssetKeyHashIDs"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_1_ ~= nil then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_2_.GameParameterData and _ARG_2_.GameParameterData[_ENV(78)] ~= nil and _ARG_2_.GameParameterData[_ENV(78)].InGameCustomAssetKeyMapping ~= nil and _ARG_2_.GameParameterData[_ENV(78)].InGameCustomAssetKeyMapping.Value ~= nil then
        goto lbl_34
        if not ({
          [_ARG_1_[nil]] = true
        })[nil] then
          _ARG_2_.GameParameterData[_ENV(78)].InGameCustomAssetKeyMapping.Value[nil] = nil
        end
        ::lbl_34::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCustomAssetObjectKey"] = function(_ARG_0_, _ARG_1_)
    do
      do return GetCustomAssetObjectKey(_ARG_1_, (_ARG_0_:_GetCustomAssetUseSuffixType(_ARG_1_))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCustomAssetKeyByHashIDInLobby"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return _ARG_0_:GenerateHashToAssetMap(_ARG_2_) and _ARG_0_:GenerateHashToAssetMap(_ARG_2_)[_ARG_1_] or nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GenerateHashToAssetMap"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return nil
      end
      goto lbl_14
      ::lbl_14::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {
        [_ARG_0_:GenerateCustomAssetKeyHashID(nil)] = nil
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AsyncLoadAndAllocPackagePath"] = function(_ARG_0_, _ARG_1_, _ARG_2_, ...)
    do
      print(bWriteLog and table.concat({
        U1(60, 4, 38, 185, 217, 50, 216, 215, 182, 151, 235, 228, 86, 178, 3, 112, 234, 51, 31, 188, 53, 22, 135, 247, 153, 141, 238, 221, 102, 162, 22, 70, 243, 61, 90, 142, 6, 30, 154, 239),
        U1(30, 22, 48, 157, 215, 43, 241, 132, 134, 135, 236, 221, 88, 177, 35, 100, 252, 36, 81, 182, 35, 22, 211)
      }) .. tostring(_ARG_1_))
      if not _ARG_0_:IsCustomAssetKey(_ARG_1_) then
        return
      end
      if _ARG_0_.AllocPackagePathMap[_ARG_0_:GetCustomAssetInfo(_ARG_1_).AssetKey] ~= nil then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
