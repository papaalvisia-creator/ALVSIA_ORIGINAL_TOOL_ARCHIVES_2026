.version	5.3

.format	0
.int_size	4
.size_t_size	4
.instruction_size	4
.integer_format	8
.float_format	8
.endianness	LITTLE

.function	main

.source	null
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	1
.maxstacksize	93

.upvalue	"_ENV"	0	true

.constant	k0	103
.constant	k1	222
.constant	k2	0
.constant	k3	205
.constant	k4	48
.constant	k5	237
.constant	k6	39
.constant	k7	7
.constant	k8	142
.constant	k9	154
.constant	k10	49
.constant	k11	71
.constant	k12	219
.constant	k13	188
.constant	k14	124
.constant	k15	"require"
.constant	k16	"table"
.constant	k17	"concat"
.constant	k18	3
.constant	k19	148
.constant	k20	44
.constant	k21	204
.constant	k22	221
.constant	k23	59
.constant	k24	200
.constant	k25	94
.constant	k26	229
.constant	k27	198
.constant	k28	67
.constant	k29	95
.constant	k30	46
.constant	k31	107
.constant	k32	194
.constant	k33	249
.constant	k34	175
.constant	k35	27
.constant	k36	218
.constant	k37	47
.constant	k38	22
.constant	k39	243
.constant	k40	115
.constant	k41	156
.constant	k42	214
.constant	k43	30
.constant	k44	62
.constant	k45	102
.constant	k46	208
.constant	k47	173
.constant	k48	58
.constant	k49	28
.constant	k50	238
.constant	k51	5
.constant	k52	159
.constant	k53	2
.constant	k54	135
.constant	k55	78
.constant	k56	138
.constant	k57	255
.constant	k58	212
.constant	k59	"FuncUtil"
.constant	k60	"BitCount"
.constant	k61	32
.constant	k62	"BitValues"
.constant	k63	1
.constant	k64	4
.constant	k65	8
.constant	k66	16
.constant	k67	64
.constant	k68	128
.constant	k69	256
.constant	k70	512
.constant	k71	1024
.constant	k72	2048
.constant	k73	"dayToMin"
.constant	k74	1440
.constant	k75	"hourToMin"
.constant	k76	60
.constant	k77	"arrBanIPAreaList"
.constant	k78	"arrBanStoreList"
.constant	k79	"arrNotGPUpgradeLink"
.constant	k80	"defaultJumpLink"
.constant	k81	"localCountryCode"
.constant	k82	"remoteCfgCountryCode"
.constant	k83	"turnOnClientSpeLabel"
.constant	k84	"remoteCfgBasePreFetch"
.constant	k85	"concatDescriptionSwitch"
.constant	k86	80
.constant	k87	98
.constant	k88	230
.constant	k89	89
.constant	k90	246
.constant	k91	33
.constant	k92	29
.constant	k93	239
.constant	k94	66
.constant	k95	139
.constant	k96	232
.constant	k97	9
.constant	k98	61
.constant	k99	122
.constant	k100	211
.constant	k101	233
.constant	k102	187
.constant	k103	234
.constant	k104	14
.constant	k105	242
.constant	k106	82
.constant	k107	18
.constant	k108	157
.constant	k109	38
.constant	k110	146
.constant	k111	114
.constant	k112	193
.constant	k113	72
.constant	k114	51
.constant	k115	90
.constant	k116	241
.constant	k117	170
.constant	k118	252
.constant	k119	15
.constant	k120	132
.constant	k121	"string"
.constant	k122	"format"
.constant	k123	"gsub"
.constant	k124	"find"
.constant	k125	"sub"
.constant	k126	"len"
.constant	k127	"move"
.constant	k128	"sort"
.constant	k129	"math"
.constant	k130	"max"
.constant	k131	"floor"
.constant	k132	"randomseed"
.constant	k133	"random"
.constant	k134	"abs"
.constant	k135	"type"
.constant	k136	"os"
.constant	k137	"time"
.constant	k138	"select"
.constant	k139	"ipairs"
.constant	k140	"pairs"
.constant	k141	"tonumber"
.constant	k142	"tostring"
.constant	k143	"print"
.constant	k144	"CDataTable"
.constant	k145	"import"
.constant	k146	"UEnums"
.constant	k147	172
.constant	k148	209
.constant	k149	199
.constant	k150	111
.constant	k151	40
.constant	k152	189
.constant	k153	91
.constant	k154	250
.constant	k155	55
.constant	k156	164
.constant	k157	213
.constant	k158	77
.constant	k159	35
.constant	k160	108
.constant	k161	"IsDevelopment"
.constant	k162	"slua"
.constant	k163	"Array"
.constant	k164	"isValid"
.constant	k165	125
.constant	k166	224
.constant	k167	120
.constant	k168	186
.constant	k169	88
.constant	k170	52
.constant	k171	196
.constant	k172	181
.constant	k173	85
.constant	k174	54
.constant	k175	227
.constant	k176	96
.constant	k177	140
.constant	k178	"HDmpveRemoteConfigGetString"
.constant	k179	"HDmpveRemoteConfigGetInt"
.constant	k180	"HDmpveRemoteConfigGetBool"
.constant	k181	151
.constant	k182	220
.constant	k183	201
.constant	k184	50
.constant	k185	73
.constant	k186	53
.constant	k187	"decode"
.constant	k188	"OnLogin"
.constant	k189	"FuncUtil"
.constant	k190	"ShowLoadingToLobby"
.constant	k191	"OnHyperLinkClicked"
.constant	k192	"UnionList"
.constant	k193	"GetHDmpveErrorMsg"
.constant	k194	"GetActivityIdByURL"
.constant	k195	"IsActivityUrlValid"
.constant	k196	"FuncUtil"
.constant	k197	"IsDuringActTime"
.constant	k198	"GetActivityTypeByURL"
.constant	k199	"GetServerTimeInSec"
.constant	k200	"GetSafeNumber"
.constant	k201	"FormatLog"
.constant	k202	"GetFormatText"
.constant	k203	"SafeCallFun"
.constant	k204	"MarkBit"
.constant	k205	"FuncUtil"
.constant	k206	"UnmarkBit"
.constant	k207	"FuncUtil"
.constant	k208	"GetBitMaskValue"
.constant	k209	"FuncUtil"
.constant	k210	"GetMaxSegement"
.constant	k211	"GetCurMaxSegementLevel"
.constant	k212	"FuncUtil"
.constant	k213	"Gen_title"
.constant	k214	"FuncUtil"
.constant	k215	"GenEnterBroadcastMsg"
.constant	k216	"FuncUtil"
.constant	k217	"GetTopResult"
.constant	k218	"bufToInt32"
.constant	k219	"int32ToBufStr"
.constant	k220	5
.constant	k221	6
.constant	k222	"IsUidGlobal"
.constant	k223	"IsUidJPKR"
.constant	k224	"IsPlayerJP"
.constant	k225	"IsPlayerJPKR"
.constant	k226	"GetWithRegion"
.constant	k227	"InitRemoteCfg"
.constant	k228	"FuncUtil"
.constant	k229	"GetCountryIPCode"
.constant	k230	"FuncUtil"
.constant	k231	"IsSpecialBanArea"
.constant	k232	"FuncUtil"
.constant	k233	"IsSpecialBanStore"
.constant	k234	"FuncUtil"
.constant	k235	"IsSpecialBanClient"
.constant	k236	"FuncUtil"
.constant	k237	"GotoNotGPUpgrade"
.constant	k238	"FuncUtil"
.constant	k239	"GetIPRegionForBluePrint"
.constant	k240	"GetAccountRegionForBP"
.constant	k241	"RegisterCountry"
.constant	k242	nil
.constant	k243	"GetRegisterCountry"
.constant	k244	"GetWindowOBState"
.constant	k245	"GetCEHideLobbyUI"
.constant	k246	"FuncUtil"
.constant	k247	"GetItemName"
.constant	k248	"GetLanguageTable"
.constant	k249	"GetLanguageTableName"
.constant	k250	"GetRechargeLevelTable"
.constant	k251	"GetLoginTypeTable"
.constant	k252	"GetRegionConfigTable"
.constant	k253	"pairsByKeys"
.constant	k254	"pairsReversedByKeys"
.constant	k255	"short_code_to_uid"
.constant	k256	"Clamp"
.constant	k257	"FormatNum_Simple"
.constant	k258	"CondOp"
.constant	k259	"JudgeIsSameClient"
.constant	k260	"FuncUtil"
.constant	k261	"CheckNumber"
.constant	k262	"FormatNumberThousands"
.constant	k263	"FuncUtil"
.constant	k264	"GetItemNameWithLimitTime"
.constant	k265	"FuncUtil"
.constant	k266	"TimeNumToTimeS"
.constant	k267	"GetNetworkTypeAsNum"
.constant	k268	"AddToDelegate"
.constant	k269	"RemoveFromDelegate"
.constant	k270	"Reload"
.constant	k271	"GetPriceIconPath"
.constant	k272	"IsTeamMode"
.constant	k273	"IsXmissionTeamMode"
.constant	k274	"IsEscapeMode"
.constant	k275	"IsRankTeamMode"
.constant	k276	"IsTeam8v8"
.constant	k277	"GetPreciseDecimal"
.constant	k278	"GetLuaGlobalUI"
.constant	k279	"TransformNumToFormatStr"
.constant	k280	"FuncUtil"
.constant	k281	"SerializeOneTable"
.constant	k282	"CheckAreaCodeLegal"
.constant	k283	"TransLanguageToImsdkLanguage"
.constant	k284	"UE4ExecuteConsoleCommand"
.constant	k285	"UE4GetConsoleVariableIntValue"
.constant	k286	"GetMaxKD"
.constant	k287	"GetLanguageDisplayName"
.constant	k288	"FuncUtil"
.constant	k289	"AddCrashContextMainFlow"
.constant	k290	"GetDVID"
.constant	k291	"GetAllActorsByTag"
.constant	k292	"ShowHide"
.constant	k293	"IsInXMission"
.constant	k294	"IsLoginSameDay"
.constant	k295	"GetJsonFileToTable"
.constant	k296	"TestAssetLoad"
.constant	k297	"FuncUtil"
.constant	k298	"FloatToShow"
.constant	k299	"GetRankTableData"
.constant	k300	"FuncUtil"
.constant	k301	"GetSegmentNameById"
.constant	k302	"FuncUtil"
.constant	k303	"GetSegmentCfgById"
.constant	k304	"FuncUtil"
.constant	k305	"GetWOWRankTableData"
.constant	k306	"GetWowRankTable"
.constant	k307	"GetOnWowRankTable"
.constant	k308	"GetRankTable"
.constant	k309	"FuncUtil"
.constant	k310	"GetRankTableName"
.constant	k311	"JumpToDownloadApp"
.constant	k312	"GetLbsAreaName"
.constant	k313	"IsFloatEqual"
.constant	k314	"ItemJump"
.constant	k315	"ReplaceIllegalChar"
.constant	k316	"ReplaceEnterChar"
.constant	k317	"LuaArrayToTable"
.constant	k318	"GetDomainByID"
.constant	k319	"GetKeywordByID"
.constant	k320	"ByteList2Int"
.constant	k321	"Int2ByteList"
.constant	k322	"Conv_Int64ToText"
.constant	k323	"Conv_FloatToText"
.constant	k324	"GetHDmpveInstanceId"
.constant	k325	"GetHDmpveRemoteConfig"
.constant	k326	"CompareVersion"
.constant	k327	"IsNewVersion"
.constant	k328	"IsInVersionRange"
.constant	k329	"FuncUtil"
.constant	k330	"OpenFlushAsyncLoading"
.constant	k331	L"CheckBackpackBlueprintDelegateDelayEnable"
.constant	k332	"GetRegisterDay"
.constant	k333	"FuncUtil"
.constant	k334	"GetRegisterYear"
.constant	k335	"table"
.constant	k336	"concat"
.constant	k337	39
.constant	k338	153
.constant	k339	40
.constant	k340	204
.constant	k341	255
.constant	k342	58
.constant	k343	135
.constant	k344	3
.constant	k345	181
.constant	k346	195
.constant	k347	67
.constant	k348	126
.constant	k349	19
.constant	k350	72
.constant	k351	203
.constant	k352	244
.constant	k353	230
.constant	k354	114
.constant	k355	248
.constant	k356	46
.constant	k357	26
.constant	k358	113
.constant	k359	137
.constant	k360	249
.constant	k361	60
.constant	k362	79
.constant	k363	37
.constant	k364	122
.constant	k365	198
.constant	k366	174
.constant	k367	136
.constant	k368	64
.constant	k369	253
.constant	k370	125
.constant	k371	63
.constant	k372	227
.constant	k373	121
.constant	k374	53
.constant	k375	140
.constant	k376	44
.constant	k377	197
.constant	k378	"GetPetPosZ"
.constant	k379	"ConcatDescriptionInDev"
.constant	k380	"FuncUtil"
.constant	k381	"SetConcatDescriptionSwitch"
.constant	k382	"FuncUtil"
.constant	k383	"SafeLoad"
.constant	k384	"SafeLoadAndCall"
.constant	k385	"FuncUtil"

.line	0	newtable      r0    16     0
.line	0	loadk         r1    k0 ; k0 = 103
.line	0	loadk         r2    k1 ; k1 = 222
.line	0	loadk         r3    k2 ; k2 = 0
.line	0	loadk         r4    k3 ; k3 = 205
.line	0	loadk         r5    k4 ; k4 = 48
.line	0	loadk         r6    k5 ; k5 = 237
.line	0	loadk         r7    k6 ; k6 = 39
.line	0	loadk         r8    k3 ; k3 = 205
.line	0	loadk         r9    k7 ; k7 = 7
.line	0	loadk        r10    k8 ; k8 = 142
.line	0	loadk        r11    k9 ; k9 = 154
.line	0	loadk        r12   k10 ; k10 = 49
.line	0	loadk        r13   k11 ; k11 = 71
.line	0	loadk        r14   k12 ; k12 = 219
.line	0	loadk        r15   k13 ; k13 = 188
.line	0	loadk        r16   k14 ; k14 = 124
.line	0	setlist       r0    16     1
.line	0	closure       r1    f0
.line	0	gettabup      r2    u0   k15 ; k15 = "require"
.line	0	gettabup      r3    u0   k16 ; k16 = "table"
.line	0	gettable      r3    r3   k17 ; k17 = "concat"
.line	0	newtable      r4     1     0
.line	0	move          r5    r1
.line	0	loadk         r6   k18 ; k18 = 3
.line	0	loadk         r7   k19 ; k19 = 148
.line	0	loadk         r8   k20 ; k20 = 44
.line	0	loadk         r9   k21 ; k21 = 204
.line	0	loadk        r10   k22 ; k22 = 221
.line	0	loadk        r11   k23 ; k23 = 59
.line	0	loadk        r12   k24 ; k24 = 200
.line	0	loadk        r13   k25 ; k25 = 94
.line	0	loadk        r14   k19 ; k19 = 148
.line	0	loadk        r15   k26 ; k26 = 229
.line	0	loadk        r16   k27 ; k27 = 198
.line	0	loadk        r17   k28 ; k28 = 67
.line	0	loadk        r18   k29 ; k29 = 95
.line	0	loadk        r19   k30 ; k30 = 46
.line	0	loadk        r20   k31 ; k31 = 107
.line	0	loadk        r21   k32 ; k32 = 194
.line	0	loadk        r22   k33 ; k33 = 249
.line	0	loadk        r23   k34 ; k34 = 175
.line	0	loadk        r24   k35 ; k35 = 27
.line	0	loadk        r25   k36 ; k36 = 218
.line	0	loadk        r26   k37 ; k37 = 47
.line	0	loadk        r27   k38 ; k38 = 22
.line	0	loadk        r28   k39 ; k39 = 243
.line	0	loadk        r29   k40 ; k40 = 115
.line	0	loadk        r30   k41 ; k41 = 156
.line	0	loadk        r31    k3 ; k3 = 205
.line	0	loadk        r32   k42 ; k42 = 214
.line	0	loadk        r33   k43 ; k43 = 30
.line	0	loadk        r34   k25 ; k25 = 94
.line	0	loadk        r35   k44 ; k44 = 62
.line	0	loadk        r36   k45 ; k45 = 102
.line	0	loadk        r37    k9 ; k9 = 154
.line	0	loadk        r38   k46 ; k46 = 208
.line	0	loadk        r39   k47 ; k47 = 173
.line	0	loadk        r40   k11 ; k11 = 71
.line	0	loadk        r41   k26 ; k26 = 229
.line	0	loadk        r42   k48 ; k48 = 58
.line	0	loadk        r43   k49 ; k49 = 28
.line	0	loadk        r44   k50 ; k50 = 238
.line	0	loadk        r45   k29 ; k29 = 95
.line	0	call          r5    41     2
.line	0	move          r6    r1
.line	0	loadk         r7   k51 ; k51 = 5
.line	0	loadk         r8   k52 ; k52 = 159
.line	0	loadk         r9   k20 ; k20 = 44
.line	0	loadk        r10   k27 ; k27 = 198
.line	0	loadk        r11   k22 ; k22 = 221
.line	0	loadk        r12   k53 ; k53 = 2
.line	0	loadk        r13   k54 ; k54 = 135
.line	0	loadk        r14   k55 ; k55 = 78
.line	0	loadk        r15   k56 ; k56 = 138
.line	0	loadk        r16   k57 ; k57 = 255
.line	0	loadk        r17   k58 ; k58 = 212
.line	0	call          r6    12     0
.line	0	setlist       r4     0     1
.line	0	call          r3     2     2
.line	0	call          r2     2     2
.line	0	gettabup      r3    u0   k59 ; k59 = "FuncUtil"
.line	0	test          r3     1
.line	0	jmp            0  l118
.line	0	newtable      r3     0    13
.line	0	settable      r3   k60   k61 ; k61 = 32
.line	0	newtable      r4    12     0
.line	0	loadk         r5   k63 ; k63 = 1
.line	0	loadk         r6   k53 ; k53 = 2
.line	0	loadk         r7   k64 ; k64 = 4
.line	0	loadk         r8   k65 ; k65 = 8
.line	0	loadk         r9   k66 ; k66 = 16
.line	0	loadk        r10   k61 ; k61 = 32
.line	0	loadk        r11   k67 ; k67 = 64
.line	0	loadk        r12   k68 ; k68 = 128
.line	0	loadk        r13   k69 ; k69 = 256
.line	0	loadk        r14   k70 ; k70 = 512
.line	0	loadk        r15   k71 ; k71 = 1024
.line	0	loadk        r16   k72 ; k72 = 2048
.line	0	setlist       r4    12     1
.line	0	settable      r3   k62    r4 ; k62 = "BitValues"
.line	0	settable      r3   k73   k74 ; k74 = 1440
.line	0	settable      r3   k75   k76 ; k76 = 60
.line	0	newtable      r4     0     0
.line	0	settable      r3   k77    r4 ; k77 = "arrBanIPAreaList"
.line	0	newtable      r4     0     0
.line	0	settable      r3   k78    r4 ; k78 = "arrBanStoreList"
.line	0	newtable      r4     0     0
.line	0	settable      r3   k79    r4 ; k79 = "arrNotGPUpgradeLink"
.line	0	move          r4    r1
.line	0	call          r4     1     2
.line	0	settable      r3   k80    r4 ; k80 = "defaultJumpLink"
.line	0	settable      r3   k81    k2 ; k2 = 0
.line	0	settable      r3   k82    k2 ; k2 = 0
.line	0	settable      r3   k83    k2 ; k2 = 0
.line	0	settable      r3   k84    k2 ; k2 = 0
.line	0	settable      r3   k85    k2 ; k2 = 0
.label	l118
.line	0	settabup      u0   k59    r3 ; k59 = "FuncUtil"
.line	0	gettabup      r3    u0   k16 ; k16 = "table"
.line	0	gettable      r3    r3   k17 ; k17 = "concat"
.line	0	newtable      r4     1     0
.line	0	move          r5    r1
.line	0	loadk         r6   k18 ; k18 = 3
.line	0	loadk         r7   k19 ; k19 = 148
.line	0	loadk         r8   k20 ; k20 = 44
.line	0	loadk         r9   k21 ; k21 = 204
.line	0	loadk        r10   k22 ; k22 = 221
.line	0	loadk        r11   k23 ; k23 = 59
.line	0	loadk        r12   k24 ; k24 = 200
.line	0	loadk        r13   k25 ; k25 = 94
.line	0	loadk        r14   k19 ; k19 = 148
.line	0	loadk        r15   k26 ; k26 = 229
.line	0	loadk        r16   k27 ; k27 = 198
.line	0	loadk        r17   k28 ; k28 = 67
.line	0	loadk        r18   k86 ; k86 = 80
.line	0	loadk        r19   k30 ; k30 = 46
.line	0	loadk        r20   k87 ; k87 = 98
.line	0	loadk        r21    k3 ; k3 = 205
.line	0	loadk        r22   k39 ; k39 = 243
.line	0	loadk        r23   k88 ; k88 = 230
.line	0	loadk        r24   k89 ; k89 = 89
.line	0	loadk        r25   k90 ; k90 = 246
.line	0	loadk        r26   k91 ; k91 = 33
.line	0	loadk        r27   k92 ; k92 = 29
.line	0	loadk        r28   k93 ; k93 = 239
.line	0	loadk        r29   k94 ; k94 = 66
.line	0	loadk        r30   k95 ; k95 = 139
.line	0	loadk        r31   k96 ; k96 = 232
.line	0	loadk        r32   k42 ; k42 = 214
.line	0	loadk        r33   k97 ; k97 = 9
.line	0	loadk        r34   k53 ; k53 = 2
.line	0	loadk        r35   k98 ; k98 = 61
.line	0	loadk        r36   k99 ; k99 = 122
.line	0	loadk        r37  k100 ; k100 = 211
.line	0	loadk        r38  k101 ; k101 = 233
.line	0	loadk        r39  k102 ; k102 = 187
.line	0	loadk        r40   k99 ; k99 = 122
.line	0	loadk        r41  k103 ; k103 = 234
.line	0	loadk        r42   k23 ; k23 = 59
.line	0	loadk        r43  k104 ; k104 = 14
.line	0	loadk        r44  k105 ; k105 = 242
.line	0	loadk        r45  k106 ; k106 = 82
.line	0	call          r5    41     2
.line	0	move          r6    r1
.line	0	loadk         r7  k107 ; k107 = 18
.line	0	loadk         r8  k108 ; k108 = 157
.line	0	loadk         r9  k109 ; k109 = 38
.line	0	loadk        r10   k12 ; k12 = 219
.line	0	loadk        r11   k27 ; k27 = 198
.line	0	loadk        r12  k109 ; k109 = 38
.line	0	loadk        r13  k110 ; k110 = 146
.line	0	loadk        r14  k111 ; k111 = 114
.line	0	loadk        r15    k9 ; k9 = 154
.line	0	loadk        r16   k26 ; k26 = 229
.line	0	loadk        r17  k112 ; k112 = 193
.line	0	loadk        r18   k43 ; k43 = 30
.line	0	loadk        r19  k113 ; k113 = 72
.line	0	loadk        r20  k114 ; k114 = 51
.line	0	loadk        r21  k115 ; k115 = 90
.line	0	loadk        r22   k46 ; k46 = 208
.line	0	loadk        r23  k116 ; k116 = 241
.line	0	loadk        r24  k117 ; k117 = 170
.line	0	loadk        r25   k89 ; k89 = 89
.line	0	loadk        r26  k118 ; k118 = 252
.line	0	loadk        r27   k49 ; k49 = 28
.line	0	loadk        r28  k119 ; k119 = 15
.line	0	loadk        r29   k33 ; k33 = 249
.line	0	loadk        r30  k111 ; k111 = 114
.line	0	loadk        r31  k120 ; k120 = 132
.line	0	call          r6    26     0
.line	0	setlist       r4     0     1
.line	0	call          r3     2     2
.line	0	gettabup      r4    u0  k121 ; k121 = "string"
.line	0	gettable      r5    r4  k122 ; k122 = "format"
.line	0	gettable      r6    r4  k123 ; k123 = "gsub"
.line	0	gettable      r7    r4  k124 ; k124 = "find"
.line	0	gettable      r8    r4  k125 ; k125 = "sub"
.line	0	gettable      r9    r4  k126 ; k126 = "len"
.line	0	gettabup     r10    u0   k16 ; k16 = "table"
.line	0	gettable     r10   r10  k127 ; k127 = "move"
.line	0	gettabup     r11    u0   k16 ; k16 = "table"
.line	0	gettable     r11   r11  k128 ; k128 = "sort"
.line	0	gettabup     r12    u0  k129 ; k129 = "math"
.line	0	gettable     r12   r12  k130 ; k130 = "max"
.line	0	gettabup     r13    u0  k129 ; k129 = "math"
.line	0	gettable     r13   r13  k131 ; k131 = "floor"
.line	0	gettabup     r14    u0  k129 ; k129 = "math"
.line	0	gettable     r14   r14  k132 ; k132 = "randomseed"
.line	0	gettabup     r15    u0  k129 ; k129 = "math"
.line	0	gettable     r15   r15  k133 ; k133 = "random"
.line	0	gettabup     r16    u0  k129 ; k129 = "math"
.line	0	gettable     r16   r16  k134 ; k134 = "abs"
.line	0	gettabup     r17    u0  k129 ; k129 = "math"
.line	0	gettable     r17   r17  k135 ; k135 = "type"
.line	0	gettabup     r18    u0  k136 ; k136 = "os"
.line	0	gettable     r18   r18  k137 ; k137 = "time"
.line	0	gettabup     r19    u0  k138 ; k138 = "select"
.line	0	gettabup     r20    u0  k139 ; k139 = "ipairs"
.line	0	gettabup     r21    u0  k140 ; k140 = "pairs"
.line	0	gettabup     r22    u0  k135 ; k135 = "type"
.line	0	gettabup     r23    u0  k141 ; k141 = "tonumber"
.line	0	gettabup     r24    u0  k142 ; k142 = "tostring"
.line	0	gettabup     r25    u0   k15 ; k15 = "require"
.line	0	gettabup     r26    u0  k143 ; k143 = "print"
.line	0	gettabup     r27    u0  k144 ; k144 = "CDataTable"
.line	0	gettabup     r28    u0  k145 ; k145 = "import"
.line	0	gettabup     r29    u0  k146 ; k146 = "UEnums"
.line	0	move         r30   r28
.line	0	move         r31    r1
.line	0	loadk        r32  k114 ; k114 = 51
.line	0	loadk        r33  k147 ; k147 = 172
.line	0	loadk        r34    k2 ; k2 = 0
.line	0	loadk        r35  k148 ; k148 = 209
.line	0	loadk        r36  k149 ; k149 = 199
.line	0	loadk        r37   k98 ; k98 = 61
.line	0	loadk        r38   k54 ; k54 = 135
.line	0	loadk        r39  k150 ; k150 = 111
.line	0	loadk        r40   k19 ; k19 = 148
.line	0	loadk        r41   k26 ; k26 = 229
.line	0	loadk        r42   k32 ; k32 = 194
.line	0	loadk        r43   k92 ; k92 = 29
.line	0	loadk        r44   k55 ; k55 = 78
.line	0	loadk        r45  k151 ; k151 = 40
.line	0	loadk        r46   k31 ; k31 = 107
.line	0	loadk        r47   k46 ; k46 = 208
.line	0	loadk        r48   k42 ; k42 = 214
.line	0	loadk        r49  k152 ; k152 = 189
.line	0	loadk        r50  k153 ; k153 = 91
.line	0	loadk        r51  k154 ; k154 = 250
.line	0	loadk        r52  k155 ; k155 = 55
.line	0	loadk        r53   k38 ; k38 = 22
.line	0	loadk        r54   k33 ; k33 = 249
.line	0	loadk        r55   k40 ; k40 = 115
.line	0	loadk        r56  k156 ; k156 = 164
.line	0	loadk        r57  k101 ; k101 = 233
.line	0	loadk        r58  k157 ; k157 = 213
.line	0	loadk        r59  k119 ; k119 = 15
.line	0	loadk        r60  k158 ; k158 = 77
.line	0	loadk        r61  k159 ; k159 = 35
.line	0	loadk        r62  k160 ; k160 = 108
.line	0	call         r31    32     2
.line	0	call         r30     2     2
.line	0	gettable     r31   r30  k161 ; k161 = "IsDevelopment"
.line	0	call         r31     1     2
.line	0	gettabup     r32    u0  k162 ; k162 = "slua"
.line	0	gettable     r32   r32  k163 ; k163 = "Array"
.line	0	gettabup     r33    u0  k162 ; k162 = "slua"
.line	0	gettable     r33   r33  k164 ; k164 = "isValid"
.line	0	move         r34   r25
.line	0	gettabup     r35    u0   k16 ; k16 = "table"
.line	0	gettable     r35   r35   k17 ; k17 = "concat"
.line	0	newtable     r36     1     0
.line	0	move         r37    r1
.line	0	loadk        r38   k18 ; k18 = 3
.line	0	loadk        r39   k19 ; k19 = 148
.line	0	loadk        r40   k20 ; k20 = 44
.line	0	loadk        r41   k21 ; k21 = 204
.line	0	loadk        r42   k22 ; k22 = 221
.line	0	loadk        r43   k23 ; k23 = 59
.line	0	loadk        r44   k24 ; k24 = 200
.line	0	loadk        r45   k25 ; k25 = 94
.line	0	loadk        r46   k19 ; k19 = 148
.line	0	loadk        r47   k26 ; k26 = 229
.line	0	loadk        r48   k27 ; k27 = 198
.line	0	loadk        r49   k28 ; k28 = 67
.line	0	loadk        r50   k86 ; k86 = 80
.line	0	loadk        r51   k30 ; k30 = 46
.line	0	loadk        r52   k87 ; k87 = 98
.line	0	loadk        r53    k3 ; k3 = 205
.line	0	loadk        r54   k39 ; k39 = 243
.line	0	loadk        r55   k88 ; k88 = 230
.line	0	loadk        r56  k165 ; k165 = 125
.line	0	loadk        r57   k22 ; k22 = 221
.line	0	loadk        r58   k30 ; k30 = 46
.line	0	loadk        r59  k119 ; k119 = 15
.line	0	loadk        r60  k166 ; k166 = 224
.line	0	loadk        r61  k167 ; k167 = 120
.line	0	loadk        r62  k168 ; k168 = 186
.line	0	loadk        r63   k26 ; k26 = 229
.line	0	loadk        r64   k36 ; k36 = 218
.line	0	loadk        r65  k107 ; k107 = 18
.line	0	loadk        r66  k169 ; k169 = 88
.line	0	loadk        r67  k170 ; k170 = 52
.line	0	loadk        r68   k23 ; k23 = 59
.line	0	loadk        r69  k118 ; k118 = 252
.line	0	loadk        r70  k171 ; k171 = 196
.line	0	loadk        r71  k172 ; k172 = 181
.line	0	loadk        r72  k173 ; k173 = 85
.line	0	loadk        r73   k57 ; k57 = 255
.line	0	loadk        r74  k174 ; k174 = 54
.line	0	loadk        r75   k98 ; k98 = 61
.line	0	loadk        r76  k175 ; k175 = 227
.line	0	loadk        r77  k176 ; k176 = 96
.line	0	call         r37    41     2
.line	0	move         r38    r1
.line	0	loadk        r39  k119 ; k119 = 15
.line	0	loadk        r40  k177 ; k177 = 140
.line	0	loadk        r41   k61 ; k61 = 32
.line	0	call         r38     4     0
.line	0	setlist      r36     0     1
.line	0	call         r35     2     2
.line	0	call         r34     2     2
.line	0	gettable     r35   r34  k178 ; k178 = "HDmpveRemoteConfigGe" (truncated)
.line	0	gettable     r36   r34  k179 ; k179 = "HDmpveRemoteConfigGe" (truncated)
.line	0	gettable     r37   r34  k180 ; k180 = "HDmpveRemoteConfigGe" (truncated)
.line	0	move         r38   r25
.line	0	move         r39    r1
.line	0	loadk        r40   k18 ; k18 = 3
.line	0	loadk        r41  k181 ; k181 = 151
.line	0	loadk        r42  k151 ; k151 = 40
.line	0	loadk        r43  k171 ; k171 = 196
.line	0	loadk        r44  k182 ; k182 = 220
.line	0	loadk        r45   k91 ; k91 = 33
.line	0	loadk        r46   k24 ; k24 = 200
.line	0	loadk        r47   k11 ; k11 = 71
.line	0	loadk        r48   k95 ; k95 = 139
.line	0	loadk        r49   k57 ; k57 = 255
.line	0	loadk        r50  k183 ; k183 = 201
.line	0	loadk        r51  k184 ; k184 = 50
.line	0	loadk        r52  k185 ; k185 = 73
.line	0	loadk        r53  k186 ; k186 = 53
.line	0	loadk        r54  k160 ; k160 = 108
.line	0	loadk        r55   k24 ; k24 = 200
.line	0	call         r39    17     2
.line	0	call         r38     2     2
.line	0	gettable     r39   r38  k187 ; k187 = "decode"
.line	0	gettabup     r40    u0   k59 ; k59 = "FuncUtil"
.line	0	closure      r41    f1
.line	0	settable     r40  k188   r41 ; k188 = "OnLogin"
.line	0	gettabup     r40    u0  k189 ; k189 = "FuncUtil"
.line	0	closure      r41    f2
.line	0	settable     r40  k190   r41 ; k190 = "ShowLoadingToLobby"
.line	0	closure      r40    f3
.line	0	settabup      u0  k191   r40 ; k191 = "OnHyperLinkClicked"
.line	0	gettabup     r40    u0  k189 ; k189 = "FuncUtil"
.line	0	closure      r41    f4
.line	0	settable     r40  k192   r41 ; k192 = "UnionList"
.line	0	gettabup     r40    u0  k189 ; k189 = "FuncUtil"
.line	0	closure      r41    f5
.line	0	settable     r40  k193   r41 ; k193 = "GetHDmpveErrorMsg"
.line	0	gettabup     r40    u0  k189 ; k189 = "FuncUtil"
.line	0	closure      r41    f6
.line	0	settable     r40  k194   r41 ; k194 = "GetActivityIdByURL"
.line	0	gettabup     r40    u0  k189 ; k189 = "FuncUtil"
.line	0	closure      r41    f7
.line	0	settable     r40  k195   r41 ; k195 = "IsActivityUrlValid"
.line	0	gettabup     r40    u0  k196 ; k196 = "FuncUtil"
.line	0	closure      r41    f8
.line	0	settable     r40  k197   r41 ; k197 = "IsDuringActTime"
.line	0	gettabup     r40    u0  k196 ; k196 = "FuncUtil"
.line	0	closure      r41    f9
.line	0	settable     r40  k198   r41 ; k198 = "GetActivityTypeByURL"
.line	0	gettabup     r40    u0  k196 ; k196 = "FuncUtil"
.line	0	closure      r41   f10
.line	0	settable     r40  k199   r41 ; k199 = "GetServerTimeInSec"
.line	0	closure      r40   f11
.line	0	settabup      u0  k200   r40 ; k200 = "GetSafeNumber"
.line	0	gettabup     r40    u0  k196 ; k196 = "FuncUtil"
.line	0	closure      r41   f12
.line	0	settable     r40  k201   r41 ; k201 = "FormatLog"
.line	0	gettabup     r40    u0  k196 ; k196 = "FuncUtil"
.line	0	closure      r41   f13
.line	0	settable     r40  k202   r41 ; k202 = "GetFormatText"
.line	0	gettabup     r40    u0  k196 ; k196 = "FuncUtil"
.line	0	closure      r41   f14
.line	0	settable     r40  k203   r41 ; k203 = "SafeCallFun"
.line	0	gettabup     r40    u0  k196 ; k196 = "FuncUtil"
.line	0	closure      r41   f15
.line	0	settable     r40  k204   r41 ; k204 = "MarkBit"
.line	0	gettabup     r40    u0  k205 ; k205 = "FuncUtil"
.line	0	closure      r41   f16
.line	0	settable     r40  k206   r41 ; k206 = "UnmarkBit"
.line	0	gettabup     r40    u0  k207 ; k207 = "FuncUtil"
.line	0	closure      r41   f17
.line	0	settable     r40  k208   r41 ; k208 = "GetBitMaskValue"
.line	0	gettabup     r40    u0  k209 ; k209 = "FuncUtil"
.line	0	closure      r41   f18
.line	0	settable     r40  k210   r41 ; k210 = "GetMaxSegement"
.line	0	gettabup     r40    u0  k209 ; k209 = "FuncUtil"
.line	0	closure      r41   f19
.line	0	settable     r40  k211   r41 ; k211 = "GetCurMaxSegementLev" (truncated)
.line	0	gettabup     r40    u0  k212 ; k212 = "FuncUtil"
.line	0	closure      r41   f20
.line	0	settable     r40  k213   r41 ; k213 = "Gen_title"
.line	0	gettabup     r40    u0  k214 ; k214 = "FuncUtil"
.line	0	closure      r41   f21
.line	0	settable     r40  k215   r41 ; k215 = "GenEnterBroadcastMsg"
.line	0	gettabup     r40    u0  k216 ; k216 = "FuncUtil"
.line	0	closure      r41   f22
.line	0	settable     r40  k217   r41 ; k217 = "GetTopResult"
.line	0	closure      r40   f23
.line	0	settabup      u0  k218   r40 ; k218 = "bufToInt32"
.line	0	closure      r40   f24
.line	0	settabup      u0  k219   r40 ; k219 = "int32ToBufStr"
.line	0	loadk        r40  k220 ; k220 = 5
.line	0	loadk        r41  k221 ; k221 = 6
.line	0	gettabup     r42    u0  k216 ; k216 = "FuncUtil"
.line	0	closure      r43   f25
.line	0	settable     r42  k222   r43 ; k222 = "IsUidGlobal"
.line	0	gettabup     r42    u0  k216 ; k216 = "FuncUtil"
.line	0	closure      r43   f26
.line	0	settable     r42  k223   r43 ; k223 = "IsUidJPKR"
.line	0	gettabup     r42    u0  k216 ; k216 = "FuncUtil"
.line	0	closure      r43   f27
.line	0	settable     r42  k224   r43 ; k224 = "IsPlayerJP"
.line	0	gettabup     r42    u0  k216 ; k216 = "FuncUtil"
.line	0	closure      r43   f28
.line	0	settable     r42  k225   r43 ; k225 = "IsPlayerJPKR"
.line	0	gettabup     r42    u0  k216 ; k216 = "FuncUtil"
.line	0	closure      r43   f29
.line	0	settable     r42  k226   r43 ; k226 = "GetWithRegion"
.line	0	gettabup     r42    u0  k216 ; k216 = "FuncUtil"
.line	0	closure      r43   f30
.line	0	settable     r42  k227   r43 ; k227 = "InitRemoteCfg"
.line	0	gettabup     r42    u0  k228 ; k228 = "FuncUtil"
.line	0	closure      r43   f31
.line	0	settable     r42  k229   r43 ; k229 = "GetCountryIPCode"
.line	0	gettabup     r42    u0  k230 ; k230 = "FuncUtil"
.line	0	closure      r43   f32
.line	0	settable     r42  k231   r43 ; k231 = "IsSpecialBanArea"
.line	0	gettabup     r42    u0  k232 ; k232 = "FuncUtil"
.line	0	closure      r43   f33
.line	0	settable     r42  k233   r43 ; k233 = "IsSpecialBanStore"
.line	0	gettabup     r42    u0  k234 ; k234 = "FuncUtil"
.line	0	closure      r43   f34
.line	0	settable     r42  k235   r43 ; k235 = "IsSpecialBanClient"
.line	0	gettabup     r42    u0  k236 ; k236 = "FuncUtil"
.line	0	closure      r43   f35
.line	0	settable     r42  k237   r43 ; k237 = "GotoNotGPUpgrade"
.line	0	gettabup     r42    u0  k238 ; k238 = "FuncUtil"
.line	0	closure      r43   f36
.line	0	settable     r42  k239   r43 ; k239 = "GetIPRegionForBluePr" (truncated)
.line	0	gettabup     r42    u0  k238 ; k238 = "FuncUtil"
.line	0	closure      r43   f37
.line	0	settable     r42  k240   r43 ; k240 = "GetAccountRegionForB" (truncated)
.line	0	gettabup     r42    u0  k238 ; k238 = "FuncUtil"
.line	0	settable     r42  k241  k242 ; k242 = nil
.line	0	gettabup     r42    u0  k238 ; k238 = "FuncUtil"
.line	0	closure      r43   f38
.line	0	settable     r42  k243   r43 ; k243 = "GetRegisterCountry"
.line	0	loadnil      r42     0
.line	0	closure      r43   f39
.line	0	settabup      u0  k244   r43 ; k244 = "GetWindowOBState"
.line	0	loadnil      r43     0
.line	0	closure      r44   f40
.line	0	settabup      u0  k245   r44 ; k245 = "GetCEHideLobbyUI"
.line	0	loadnil      r44     0
.line	0	gettabup     r45    u0  k246 ; k246 = "FuncUtil"
.line	0	closure      r46   f41
.line	0	settable     r45  k247   r46 ; k247 = "GetItemName"
.line	0	gettabup     r45    u0  k246 ; k246 = "FuncUtil"
.line	0	closure      r46   f42
.line	0	settable     r45  k248   r46 ; k248 = "GetLanguageTable"
.line	0	gettabup     r45    u0  k246 ; k246 = "FuncUtil"
.line	0	closure      r46   f43
.line	0	settable     r45  k249   r46 ; k249 = "GetLanguageTableName"
.line	0	gettabup     r45    u0  k246 ; k246 = "FuncUtil"
.line	0	closure      r46   f44
.line	0	settable     r45  k250   r46 ; k250 = "GetRechargeLevelTabl" (truncated)
.line	0	gettabup     r45    u0  k246 ; k246 = "FuncUtil"
.line	0	closure      r46   f45
.line	0	settable     r45  k251   r46 ; k251 = "GetLoginTypeTable"
.line	0	gettabup     r45    u0  k246 ; k246 = "FuncUtil"
.line	0	closure      r46   f46
.line	0	settable     r45  k252   r46 ; k252 = "GetRegionConfigTable"
.line	0	closure      r45   f47
.line	0	settabup      u0  k253   r45 ; k253 = "pairsByKeys"
.line	0	closure      r45   f48
.line	0	settabup      u0  k254   r45 ; k254 = "pairsReversedByKeys"
.line	0	gettabup     r45    u0  k246 ; k246 = "FuncUtil"
.line	0	closure      r46   f49
.line	0	settable     r45  k255   r46 ; k255 = "short_code_to_uid"
.line	0	gettabup     r45    u0  k246 ; k246 = "FuncUtil"
.line	0	loadk        r46  k256 ; k256 = "Clamp"
.line	0	closure      r47   f50
.line	0	settable     r45   r46   r47
.line	0	gettabup     r45    u0  k246 ; k246 = "FuncUtil"
.line	0	loadk        r46  k257 ; k257 = "FormatNum_Simple"
.line	0	closure      r47   f51
.line	0	settable     r45   r46   r47
.line	0	gettabup     r45    u0  k246 ; k246 = "FuncUtil"
.line	0	loadk        r46  k258 ; k258 = "CondOp"
.line	0	closure      r47   f52
.line	0	settable     r45   r46   r47
.line	0	gettabup     r45    u0  k246 ; k246 = "FuncUtil"
.line	0	loadk        r46  k259 ; k259 = "JudgeIsSameClient"
.line	0	closure      r47   f53
.line	0	settable     r45   r46   r47
.line	0	loadk        r45  k260 ; k260 = "FuncUtil"
.line	0	gettabup     r45    u0   r45
.line	0	loadk        r46  k261 ; k261 = "CheckNumber"
.line	0	closure      r47   f54
.line	0	settable     r45   r46   r47
.line	0	loadk        r45  k260 ; k260 = "FuncUtil"
.line	0	gettabup     r45    u0   r45
.line	0	loadk        r46  k262 ; k262 = "FormatNumberThousand" (truncated)
.line	0	closure      r47   f55
.line	0	settable     r45   r46   r47
.line	0	loadk        r45  k263 ; k263 = "FuncUtil"
.line	0	gettabup     r45    u0   r45
.line	0	loadk        r46  k264 ; k264 = "GetItemNameWithLimit" (truncated)
.line	0	closure      r47   f56
.line	0	settable     r45   r46   r47
.line	0	loadk        r45  k265 ; k265 = "FuncUtil"
.line	0	gettabup     r45    u0   r45
.line	0	loadk        r46  k266 ; k266 = "TimeNumToTimeS"
.line	0	closure      r47   f57
.line	0	settable     r45   r46   r47
.line	0	loadk        r45  k265 ; k265 = "FuncUtil"
.line	0	gettabup     r45    u0   r45
.line	0	loadk        r46  k267 ; k267 = "GetNetworkTypeAsNum"
.line	0	closure      r47   f58
.line	0	settable     r45   r46   r47
.line	0	loadk        r45  k265 ; k265 = "FuncUtil"
.line	0	gettabup     r45    u0   r45
.line	0	loadk        r46  k268 ; k268 = "AddToDelegate"
.line	0	closure      r47   f59
.line	0	settable     r45   r46   r47
.line	0	loadk        r45  k265 ; k265 = "FuncUtil"
.line	0	gettabup     r45    u0   r45
.line	0	loadk        r46  k269 ; k269 = "RemoveFromDelegate"
.line	0	closure      r47   f60
.line	0	settable     r45   r46   r47
.line	0	loadk        r45  k270 ; k270 = "Reload"
.line	0	closure      r46   f61
.line	0	settabup      u0   r45   r46
.line	0	loadk        r45  k265 ; k265 = "FuncUtil"
.line	0	gettabup     r45    u0   r45
.line	0	loadk        r46  k271 ; k271 = "GetPriceIconPath"
.line	0	closure      r47   f62
.line	0	settable     r45   r46   r47
.line	0	loadk        r45  k265 ; k265 = "FuncUtil"
.line	0	gettabup     r45    u0   r45
.line	0	loadk        r46  k272 ; k272 = "IsTeamMode"
.line	0	closure      r47   f63
.line	0	settable     r45   r46   r47
.line	0	loadk        r45  k265 ; k265 = "FuncUtil"
.line	0	gettabup     r45    u0   r45
.line	0	loadk        r46  k273 ; k273 = "IsXmissionTeamMode"
.line	0	closure      r47   f64
.line	0	settable     r45   r46   r47
.line	0	loadk        r45  k265 ; k265 = "FuncUtil"
.line	0	gettabup     r45    u0   r45
.line	0	loadk        r46  k274 ; k274 = "IsEscapeMode"
.line	0	closure      r47   f65
.line	0	settable     r45   r46   r47
.line	0	loadk        r45  k265 ; k265 = "FuncUtil"
.line	0	gettabup     r45    u0   r45
.line	0	loadk        r46  k275 ; k275 = "IsRankTeamMode"
.line	0	closure      r47   f66
.line	0	settable     r45   r46   r47
.line	0	loadk        r45  k265 ; k265 = "FuncUtil"
.line	0	gettabup     r45    u0   r45
.line	0	loadk        r46  k276 ; k276 = "IsTeam8v8"
.line	0	closure      r47   f67
.line	0	settable     r45   r46   r47
.line	0	loadk        r45  k265 ; k265 = "FuncUtil"
.line	0	gettabup     r45    u0   r45
.line	0	loadk        r46  k277 ; k277 = "GetPreciseDecimal"
.line	0	closure      r47   f68
.line	0	settable     r45   r46   r47
.line	0	loadk        r45  k265 ; k265 = "FuncUtil"
.line	0	gettabup     r45    u0   r45
.line	0	loadk        r46  k278 ; k278 = "GetLuaGlobalUI"
.line	0	closure      r47   f69
.line	0	settable     r45   r46   r47
.line	0	loadk        r45  k265 ; k265 = "FuncUtil"
.line	0	gettabup     r45    u0   r45
.line	0	loadk        r46  k279 ; k279 = "TransformNumToFormat" (truncated)
.line	0	closure      r47   f70
.line	0	settable     r45   r46   r47
.line	0	closure      r45   f71
.line	0	loadk        r46  k280 ; k280 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k281 ; k281 = "SerializeOneTable"
.line	0	closure      r48   f72
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k280 ; k280 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k282 ; k282 = "CheckAreaCodeLegal"
.line	0	closure      r48   f73
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k280 ; k280 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k283 ; k283 = "TransLanguageToImsdk" (truncated)
.line	0	closure      r48   f74
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k280 ; k280 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k284 ; k284 = "UE4ExecuteConsoleCom" (truncated)
.line	0	closure      r48   f75
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k280 ; k280 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k285 ; k285 = "UE4GetConsoleVariabl" (truncated)
.line	0	closure      r48   f76
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k280 ; k280 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k286 ; k286 = "GetMaxKD"
.line	0	closure      r48   f77
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k280 ; k280 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k287 ; k287 = "GetLanguageDisplayNa" (truncated)
.line	0	closure      r48   f78
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k288 ; k288 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k289 ; k289 = "AddCrashContextMainF" (truncated)
.line	0	closure      r48   f79
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k288 ; k288 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k290 ; k290 = "GetDVID"
.line	0	closure      r48   f80
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k288 ; k288 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k291 ; k291 = "GetAllActorsByTag"
.line	0	closure      r48   f81
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k292 ; k292 = "ShowHide"
.line	0	closure      r47   f82
.line	0	settabup      u0   r46   r47
.line	0	loadk        r46  k288 ; k288 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k293 ; k293 = "IsInXMission"
.line	0	closure      r48   f83
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k288 ; k288 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k294 ; k294 = "IsLoginSameDay"
.line	0	closure      r48   f84
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k288 ; k288 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k295 ; k295 = "GetJsonFileToTable"
.line	0	closure      r48   f85
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k288 ; k288 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k296 ; k296 = "TestAssetLoad"
.line	0	closure      r48   f86
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k297 ; k297 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k298 ; k298 = "FloatToShow"
.line	0	closure      r48   f87
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k297 ; k297 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k299 ; k299 = "GetRankTableData"
.line	0	closure      r48   f88
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k300 ; k300 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k301 ; k301 = "GetSegmentNameById"
.line	0	closure      r48   f89
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k302 ; k302 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k303 ; k303 = "GetSegmentCfgById"
.line	0	closure      r48   f90
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k304 ; k304 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k305 ; k305 = "GetWOWRankTableData"
.line	0	closure      r48   f91
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k304 ; k304 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k306 ; k306 = "GetWowRankTable"
.line	0	closure      r48   f92
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k304 ; k304 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k307 ; k307 = "GetOnWowRankTable"
.line	0	closure      r48   f93
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k304 ; k304 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k308 ; k308 = "GetRankTable"
.line	0	closure      r48   f94
.line	0	settable     r46   r47   r48
.line	0	loadk        r46  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r46    u0   r46
.line	0	loadk        r47  k310 ; k310 = "GetRankTableName"
.line	0	closure      r48   f95
.line	0	settable     r46   r47   r48
.line	0	closure      r46   f96
.line	0	loadk        r47  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r47    u0   r47
.line	0	loadk        r48  k311 ; k311 = "JumpToDownloadApp"
.line	0	closure      r49   f97
.line	0	settable     r47   r48   r49
.line	0	loadk        r47  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r47    u0   r47
.line	0	loadk        r48  k312 ; k312 = "GetLbsAreaName"
.line	0	closure      r49   f98
.line	0	settable     r47   r48   r49
.line	0	loadk        r47  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r47    u0   r47
.line	0	loadk        r48  k313 ; k313 = "IsFloatEqual"
.line	0	closure      r49   f99
.line	0	settable     r47   r48   r49
.line	0	closure      r47  f100
.line	0	closure      r48  f101
.line	0	loadk        r49  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k314 ; k314 = "ItemJump"
.line	0	closure      r51  f102
.line	0	settable     r49   r50   r51
.line	0	loadk        r49  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k315 ; k315 = "ReplaceIllegalChar"
.line	0	closure      r51  f103
.line	0	settable     r49   r50   r51
.line	0	loadk        r49  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k316 ; k316 = "ReplaceEnterChar"
.line	0	closure      r51  f104
.line	0	settable     r49   r50   r51
.line	0	loadk        r49  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k317 ; k317 = "LuaArrayToTable"
.line	0	closure      r51  f105
.line	0	settable     r49   r50   r51
.line	0	loadk        r49  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k318 ; k318 = "GetDomainByID"
.line	0	closure      r51  f106
.line	0	settable     r49   r50   r51
.line	0	loadk        r49  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k319 ; k319 = "GetKeywordByID"
.line	0	closure      r51  f107
.line	0	settable     r49   r50   r51
.line	0	loadk        r49  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k320 ; k320 = "ByteList2Int"
.line	0	closure      r51  f108
.line	0	settable     r49   r50   r51
.line	0	loadk        r49  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k321 ; k321 = "Int2ByteList"
.line	0	closure      r51  f109
.line	0	settable     r49   r50   r51
.line	0	loadk        r49  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k322 ; k322 = "Conv_Int64ToText"
.line	0	closure      r51  f110
.line	0	settable     r49   r50   r51
.line	0	loadk        r49  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k323 ; k323 = "Conv_FloatToText"
.line	0	closure      r51  f111
.line	0	settable     r49   r50   r51
.line	0	loadk        r49  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k324 ; k324 = "GetHDmpveInstanceId"
.line	0	closure      r51  f112
.line	0	settable     r49   r50   r51
.line	0	loadk        r49  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k325 ; k325 = "GetHDmpveRemoteConfi" (truncated)
.line	0	closure      r51  f113
.line	0	settable     r49   r50   r51
.line	0	loadk        r49  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k326 ; k326 = "CompareVersion"
.line	0	closure      r51  f114
.line	0	settable     r49   r50   r51
.line	0	loadk        r49  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k327 ; k327 = "IsNewVersion"
.line	0	closure      r51  f115
.line	0	settable     r49   r50   r51
.line	0	loadk        r49  k309 ; k309 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k328 ; k328 = "IsInVersionRange"
.line	0	closure      r51  f116
.line	0	settable     r49   r50   r51
.line	0	loadk        r49  k329 ; k329 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k330 ; k330 = "OpenFlushAsyncLoadin" (truncated)
.line	0	closure      r51  f117
.line	0	settable     r49   r50   r51
.line	0	loadk        r49  k329 ; k329 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k331 ; k331 = L"CheckBackpackBluepri" (truncated)
.line	0	closure      r51  f118
.line	0	settable     r49   r50   r51
.line	0	loadk        r49  k329 ; k329 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k332 ; k332 = "GetRegisterDay"
.line	0	closure      r51  f119
.line	0	settable     r49   r50   r51
.line	0	loadk        r49  k333 ; k333 = "FuncUtil"
.line	0	gettabup     r49    u0   r49
.line	0	loadk        r50  k334 ; k334 = "GetRegisterYear"
.line	0	closure      r51  f120
.line	0	settable     r49   r50   r51
.line	0	move         r49   r25
.line	0	loadk        r50  k335 ; k335 = "table"
.line	0	gettabup     r50    u0   r50
.line	0	loadk        r51  k336 ; k336 = "concat"
.line	0	gettable     r50   r50   r51
.line	0	newtable     r51     1     0
.line	0	move         r52    r1
.line	0	loadk        r53  k337 ; k337 = 39
.line	0	loadk        r54  k338 ; k338 = 153
.line	0	loadk        r55  k339 ; k339 = 40
.line	0	loadk        r56  k340 ; k340 = 204
.line	0	loadk        r57  k341 ; k341 = 255
.line	0	loadk        r58  k342 ; k342 = 58
.line	0	loadk        r59  k343 ; k343 = 135
.line	0	loadk        r60  k344 ; k344 = 3
.line	0	loadk        r61  k345 ; k345 = 181
.line	0	loadk        r62  k341 ; k341 = 255
.line	0	loadk        r63  k346 ; k346 = 195
.line	0	loadk        r64  k347 ; k347 = 67
.line	0	loadk        r65  k348 ; k348 = 126
.line	0	loadk        r66  k349 ; k349 = 19
.line	0	loadk        r67  k350 ; k350 = 72
.line	0	loadk        r68  k351 ; k351 = 203
.line	0	loadk        r69  k352 ; k352 = 244
.line	0	loadk        r70  k353 ; k353 = 230
.line	0	loadk        r71  k354 ; k354 = 114
.line	0	loadk        r72  k355 ; k355 = 248
.line	0	loadk        r73  k356 ; k356 = 46
.line	0	loadk        r74  k357 ; k357 = 26
.line	0	loadk        r75  k353 ; k353 = 230
.line	0	loadk        r76  k358 ; k358 = 113
.line	0	loadk        r77  k359 ; k359 = 137
.line	0	loadk        r78  k360 ; k360 = 249
.line	0	loadk        r79  k338 ; k338 = 153
.line	0	loadk        r80  k361 ; k361 = 60
.line	0	loadk        r81  k362 ; k362 = 79
.line	0	loadk        r82  k363 ; k363 = 37
.line	0	loadk        r83  k364 ; k364 = 122
.line	0	loadk        r84  k365 ; k365 = 198
.line	0	loadk        r85  k366 ; k366 = 174
.line	0	loadk        r86  k367 ; k367 = 136
.line	0	loadk        r87  k368 ; k368 = 64
.line	0	loadk        r88  k369 ; k369 = 253
.line	0	loadk        r89  k370 ; k370 = 125
.line	0	loadk        r90  k371 ; k371 = 63
.line	0	loadk        r91  k372 ; k372 = 227
.line	0	loadk        r92  k373 ; k373 = 121
.line	0	call         r52    41     2
.line	0	move         r53    r1
.line	0	loadk        r54  k374 ; k374 = 53
.line	0	loadk        r55  k375 ; k375 = 140
.line	0	loadk        r56  k376 ; k376 = 44
.line	0	loadk        r57  k377 ; k377 = 197
.line	0	call         r53     5     0
.line	0	setlist      r51     0     1
.line	0	call         r50     2     2
.line	0	call         r49     2     2
.line	0	loadk        r50  k333 ; k333 = "FuncUtil"
.line	0	gettabup     r50    u0   r50
.line	0	loadk        r51  k378 ; k378 = "GetPetPosZ"
.line	0	closure      r52  f121
.line	0	settable     r50   r51   r52
.line	0	loadk        r50  k333 ; k333 = "FuncUtil"
.line	0	gettabup     r50    u0   r50
.line	0	loadk        r51  k379 ; k379 = "ConcatDescriptionInD" (truncated)
.line	0	closure      r52  f122
.line	0	settable     r50   r51   r52
.line	0	loadk        r50  k380 ; k380 = "FuncUtil"
.line	0	gettabup     r50    u0   r50
.line	0	loadk        r51  k381 ; k381 = "SetConcatDescription" (truncated)
.line	0	closure      r52  f123
.line	0	settable     r50   r51   r52
.line	0	loadk        r50  k382 ; k382 = "FuncUtil"
.line	0	gettabup     r50    u0   r50
.line	0	loadk        r51  k383 ; k383 = "SafeLoad"
.line	0	closure      r52  f124
.line	0	settable     r50   r51   r52
.line	0	closure      r50  f125
.line	0	closure      r51  f126
.line	0	loadk        r52  k382 ; k382 = "FuncUtil"
.line	0	gettabup     r52    u0   r52
.line	0	loadk        r53  k384 ; k384 = "SafeLoadAndCall"
.line	0	closure      r54  f127
.line	0	settable     r52   r53   r54
.line	0	loadk        r52  k385 ; k385 = "FuncUtil"
.line	0	gettabup     r52    u0   r52
.line	0	return       r52     2
.line	0	return        r0     1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	gettabup      r1    u1  k173 ; k173 = 85
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f0

.source	null
.linedefined	2
.lastlinedefined	9
.numparams	0
.is_vararg	1
.maxstacksize	9

.upvalue	"_ENV"	0	false
.upvalue	"U1"	0	true

.constant	k0	1
.constant	k1	"string"
.constant	k2	"char"
.constant	k3	16
.constant	k4	31
.constant	k5	7
.constant	k6	256
.constant	k7	"table"
.constant	k8	"concat"

.line	2	newtable      r0     0     0
.line	2	vararg        r1     0
.line	2	setlist       r0     0     1
.line	2	newtable      r1     0     0
.line	2	loadk         r2    k0 ; k0 = 1
.line	2	len           r3    r0
.line	2	loadk         r4    k0 ; k0 = 1
.line	2	move          r0    r0
.line	2	gettabup      r6    u0    k1 ; k1 = "string"
.line	2	gettable      r6    r6    k2 ; k2 = "char"
.line	2	gettable      r7    r0    r5
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mod           r8    r8    k3 ; k3 = 16
.line	2	add           r8    r8    k0 ; k0 = 1
.line	2	gettabup      r8    u1    r8
.line	2	bxor          r7    r7    r8
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mul           r8    r8    k4 ; k4 = 31
.line	2	add           r8    r8    k5 ; k5 = 7
.line	2	mod           r8    r8    k6 ; k6 = 256
.line	2	bxor          r7    r7    r8
.line	2	mod           r7    r7    k6 ; k6 = 256
.line	2	call          r6     2     2
.line	2	settable      r1    r5    r6
.line	2	move          r0    r0
.line	2	gettabup      r2    u0    k7 ; k7 = "table"
.line	2	gettable      r2    r2    k8 ; k8 = "concat"
.line	2	move          r3    r1
.line	2	tailcall      r2     2
.line	2	return        r2     0
.line	2	return        r0     1
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	return        r0     1

.function	main/f1

.source	null
.linedefined	91
.lastlinedefined	106
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	25	true
.upvalue	"U1"	1	true
.upvalue	"U2"	0	false
.upvalue	"U3"	4	true
.upvalue	"U4"	37	true

.constant	k0	3
.constant	k1	148
.constant	k2	44
.constant	k3	204
.constant	k4	221
.constant	k5	59
.constant	k6	200
.constant	k7	78
.constant	k8	151
.constant	k9	253
.constant	k10	202
.constant	k11	2
.constant	k12	82
.constant	k13	111
.constant	k14	113
.constant	k15	205
.constant	k16	173
.constant	k17	106
.constant	k18	236
.constant	k19	55
.constant	k20	22
.constant	k21	250
.constant	k22	"SetServerTimeInSec"
.constant	k23	"LobbySystem"
.constant	k24	"roleData"
.constant	k25	"svr_time"
.constant	k26	94
.constant	k27	229
.constant	k28	198
.constant	k29	67
.constant	k30	80
.constant	k31	46
.constant	k32	98
.constant	k33	243
.constant	k34	230
.constant	k35	64
.constant	k36	254
.constant	k37	32
.constant	k38	81
.constant	k39	227
.constant	k40	105
.constant	k41	129
.constant	k42	232
.constant	k43	8
.constant	k44	75
.constant	k45	50
.constant	k46	"ReloadCreativeExpiredAssetConfig"
.constant	k47	"Client"
.constant	k48	"SetTMFPTapWhiteListFlag"
.constant	k49	"phone_vibrate_status"
.constant	k50	1
.constant	k51	"table"
.constant	k52	"concat"
.constant	k53	95
.constant	k54	107
.constant	k55	194
.constant	k56	249
.constant	k57	175
.constant	k58	27
.constant	k59	218
.constant	k60	47
.constant	k61	115
.constant	k62	156
.constant	k63	214
.constant	k64	30
.constant	k65	62
.constant	k66	102
.constant	k67	154
.constant	k68	196
.constant	k69	189
.constant	k70	83
.constant	k71	224
.constant	k72	48
.constant	k73	10
.constant	k74	97
.constant	k75	140
.constant	k76	35
.constant	k77	193
.constant	k78	34
.constant	k79	168
.constant	k80	76
.constant	k81	149
.constant	k82	245
.constant	k83	234
.constant	k84	12
.constant	k85	51
.constant	k86	215
.constant	k87	"GetDevicePlatformName"
.constant	k88	"IOS"
.constant	k89	"lower"
.constant	k90	"GetDeviceModel"
.constant	k91	9
.constant	k92	136
.constant	k93	45
.constant	k94	42
.constant	k95	20
.constant	k96	212
.constant	k97	164
.constant	k98	37
.constant	k99	150
.constant	k100	36
.constant	k101	203
.constant	k102	223
.constant	k103	171
.constant	k104	25
.constant	k105	85
.constant	k106	242
.constant	k107	66
.constant	k108	38
.constant	k109	19
.constant	k110	247
.constant	k111	246
.constant	k112	210
.constant	k113	"FuncUtil"
.constant	k114	"UE4ExecuteConsoleCommand"
.constant	k115	16
.constant	k116	155
.constant	k117	238
.constant	k118	61
.constant	k119	137
.constant	k120	125
.constant	k121	145
.constant	k122	235
.constant	k123	118
.constant	k124	199
.constant	k125	241
.constant	k126	184
.constant	k127	41
.constant	k128	255
.constant	k129	120
.constant	k130	159
.constant	k131	17
.constant	k132	77
.constant	k133	124
.constant	k134	248
.constant	k135	54
.constant	k136	135
.constant	k137	146
.constant	k138	68
.constant	k139	4
.constant	k140	89
.constant	k141	87
.constant	k142	252
.constant	k143	169
.constant	k144	65
.constant	k145	240
.constant	k146	53
.constant	k147	26
.constant	k148	182

.line	91	getupval      r1    u0
.line	91	getupval      r2    u1
.line	91	loadk         r3    k0 ; k0 = 3
.line	91	loadk         r4    k1 ; k1 = 148
.line	91	loadk         r5    k2 ; k2 = 44
.line	91	loadk         r6    k3 ; k3 = 204
.line	91	loadk         r7    k4 ; k4 = 221
.line	91	loadk         r8    k5 ; k5 = 59
.line	91	loadk         r9    k6 ; k6 = 200
.line	91	loadk        r10    k7 ; k7 = 78
.line	91	loadk        r11    k8 ; k8 = 151
.line	91	loadk        r12    k9 ; k9 = 253
.line	91	loadk        r13   k10 ; k10 = 202
.line	91	loadk        r14   k11 ; k11 = 2
.line	91	loadk        r15   k12 ; k12 = 82
.line	91	loadk        r16   k13 ; k13 = 111
.line	91	loadk        r17   k14 ; k14 = 113
.line	91	loadk        r18   k15 ; k15 = 205
.line	91	loadk        r19    k9 ; k9 = 253
.line	91	loadk        r20   k16 ; k16 = 173
.line	91	loadk        r21   k17 ; k17 = 106
.line	91	loadk        r22   k18 ; k18 = 236
.line	91	loadk        r23   k19 ; k19 = 55
.line	91	loadk        r24   k20 ; k20 = 22
.line	91	loadk        r25   k21 ; k21 = 250
.line	91	call          r2    24     2
.line	91	call          r1     2     2
.line	91	gettable      r2    r1   k22 ; k22 = "SetServerTimeInSec"
.line	91	gettabup      r3    u2   k23 ; k23 = "LobbySystem"
.line	91	gettable      r3    r3   k24 ; k24 = "roleData"
.line	91	gettable      r3    r3   k25 ; k25 = "svr_time"
.line	91	call          r2     2     1
.line	91	getupval      r2    u0
.line	91	getupval      r3    u1
.line	91	loadk         r4    k0 ; k0 = 3
.line	91	loadk         r5    k1 ; k1 = 148
.line	91	loadk         r6    k2 ; k2 = 44
.line	91	loadk         r7    k3 ; k3 = 204
.line	91	loadk         r8    k4 ; k4 = 221
.line	91	loadk         r9    k5 ; k5 = 59
.line	91	loadk        r10    k6 ; k6 = 200
.line	91	loadk        r11   k26 ; k26 = 94
.line	91	loadk        r12    k1 ; k1 = 148
.line	91	loadk        r13   k27 ; k27 = 229
.line	91	loadk        r14   k28 ; k28 = 198
.line	91	loadk        r15   k29 ; k29 = 67
.line	91	loadk        r16   k30 ; k30 = 80
.line	91	loadk        r17   k31 ; k31 = 46
.line	91	loadk        r18   k32 ; k32 = 98
.line	91	loadk        r19   k15 ; k15 = 205
.line	91	loadk        r20   k33 ; k33 = 243
.line	91	loadk        r21   k34 ; k34 = 230
.line	91	loadk        r22   k35 ; k35 = 64
.line	91	loadk        r23   k36 ; k36 = 254
.line	91	loadk        r24   k37 ; k37 = 32
.line	91	loadk        r25   k38 ; k38 = 81
.line	91	loadk        r26   k39 ; k39 = 227
.line	91	loadk        r27   k40 ; k40 = 105
.line	91	loadk        r28   k41 ; k41 = 129
.line	91	loadk        r29   k18 ; k18 = 236
.line	91	loadk        r30   k42 ; k42 = 232
.line	91	loadk        r31   k43 ; k43 = 8
.line	91	loadk        r32   k44 ; k44 = 75
.line	91	loadk        r33   k45 ; k45 = 50
.line	91	call          r3    31     2
.line	91	call          r2     2     2
.line	91	gettable      r3    r2   k46 ; k46 = "ReloadCreativeExpire" (truncated)
.line	91	call          r3     1     1
.line	91	gettabup      r3    u2   k47 ; k47 = "Client"
.line	91	gettable      r3    r3   k48 ; k48 = "SetTMFPTapWhiteListF" (truncated)
.line	91	gettabup      r4    u2   k23 ; k23 = "LobbySystem"
.line	91	gettable      r4    r4   k24 ; k24 = "roleData"
.line	91	gettable      r4    r4   k49 ; k49 = "phone_vibrate_status"
.line	91	test          r4     1
.line	91	jmp            0   l77
.line	91	loadk         r4   k50 ; k50 = 1
.label	l77
.line	91	call          r3     2     1
.line	91	getupval      r3    u0
.line	91	gettabup      r4    u2   k51 ; k51 = "table"
.line	91	gettable      r4    r4   k52 ; k52 = "concat"
.line	91	newtable      r5     1     0
.line	91	getupval      r6    u1
.line	91	loadk         r7    k0 ; k0 = 3
.line	91	loadk         r8    k1 ; k1 = 148
.line	91	loadk         r9    k2 ; k2 = 44
.line	91	loadk        r10    k3 ; k3 = 204
.line	91	loadk        r11    k4 ; k4 = 221
.line	91	loadk        r12    k5 ; k5 = 59
.line	91	loadk        r13    k6 ; k6 = 200
.line	91	loadk        r14   k26 ; k26 = 94
.line	91	loadk        r15    k1 ; k1 = 148
.line	91	loadk        r16   k27 ; k27 = 229
.line	91	loadk        r17   k28 ; k28 = 198
.line	91	loadk        r18   k29 ; k29 = 67
.line	91	loadk        r19   k53 ; k53 = 95
.line	91	loadk        r20   k31 ; k31 = 46
.line	91	loadk        r21   k54 ; k54 = 107
.line	91	loadk        r22   k55 ; k55 = 194
.line	91	loadk        r23   k56 ; k56 = 249
.line	91	loadk        r24   k57 ; k57 = 175
.line	91	loadk        r25   k58 ; k58 = 27
.line	91	loadk        r26   k59 ; k59 = 218
.line	91	loadk        r27   k60 ; k60 = 47
.line	91	loadk        r28   k20 ; k20 = 22
.line	91	loadk        r29   k33 ; k33 = 243
.line	91	loadk        r30   k61 ; k61 = 115
.line	91	loadk        r31   k62 ; k62 = 156
.line	91	loadk        r32   k15 ; k15 = 205
.line	91	loadk        r33   k63 ; k63 = 214
.line	91	loadk        r34   k64 ; k64 = 30
.line	91	loadk        r35   k26 ; k26 = 94
.line	91	loadk        r36   k65 ; k65 = 62
.line	91	loadk        r37   k66 ; k66 = 102
.line	91	loadk        r38   k67 ; k67 = 154
.line	91	loadk        r39   k68 ; k68 = 196
.line	91	loadk        r40   k69 ; k69 = 189
.line	91	loadk        r41   k70 ; k70 = 83
.line	91	loadk        r42   k71 ; k71 = 224
.line	91	loadk        r43   k72 ; k72 = 48
.line	91	loadk        r44   k73 ; k73 = 10
.line	91	loadk        r45   k63 ; k63 = 214
.line	91	loadk        r46   k74 ; k74 = 97
.line	91	call          r6    41     2
.line	91	getupval      r7    u1
.line	91	loadk         r8   k50 ; k50 = 1
.line	91	loadk         r9   k75 ; k75 = 140
.line	91	loadk        r10   k76 ; k76 = 35
.line	91	loadk        r11   k28 ; k28 = 198
.line	91	loadk        r12   k77 ; k77 = 193
.line	91	loadk        r13   k78 ; k78 = 34
.line	91	loadk        r14   k79 ; k79 = 168
.line	91	loadk        r15   k80 ; k80 = 76
.line	91	loadk        r16   k81 ; k81 = 149
.line	91	loadk        r17   k82 ; k82 = 245
.line	91	loadk        r18   k83 ; k83 = 234
.line	91	loadk        r19   k84 ; k84 = 12
.line	91	loadk        r20   k53 ; k53 = 95
.line	91	loadk        r21   k85 ; k85 = 51
.line	91	loadk        r22   k17 ; k17 = 106
.line	91	loadk        r23   k86 ; k86 = 215
.line	91	call          r7    17     0
.line	91	setlist       r5     0     1
.line	91	call          r4     2     2
.line	91	call          r3     2     2
.line	91	gettabup      r4    u2   k47 ; k47 = "Client"
.line	91	gettable      r4    r4   k87 ; k87 = "GetDevicePlatformNam" (truncated)
.line	91	call          r4     1     2
.line	91	gettable      r5    r3   k88 ; k88 = "IOS"
.line	91	eq             0    r4    r5
.line	91	jmp            0  l275
.line	91	gettabup      r4    u3   k89 ; k89 = "lower"
.line	91	gettabup      r5    u2   k47 ; k47 = "Client"
.line	91	gettable      r5    r5   k90 ; k90 = "GetDeviceModel"
.line	91	call          r5     1     0
.line	91	call          r4     0     2
.line	91	getupval      r5    u1
.line	91	loadk         r6   k91 ; k91 = 9
.line	91	loadk         r7   k92 ; k92 = 136
.line	91	loadk         r8   k93 ; k93 = 45
.line	91	loadk         r9   k28 ; k28 = 198
.line	91	loadk        r10    k4 ; k4 = 221
.line	91	loadk        r11   k94 ; k94 = 42
.line	91	loadk        r12   k86 ; k86 = 215
.line	91	loadk        r13   k95 ; k95 = 20
.line	91	loadk        r14   k96 ; k96 = 212
.line	91	loadk        r15   k97 ; k97 = 164
.line	91	call          r5    11     2
.line	91	eq             1    r4    r5
.line	91	jmp            0  l171
.line	91	loadbool      r4     0     1
.label	l171
.line	91	loadbool      r4     1     0
.line	91	getupval      r5    u4
.line	91	getupval      r6    u1
.line	91	loadk         r7   k98 ; k98 = 37
.line	91	loadk         r8   k99 ; k99 = 150
.line	91	loadk         r9  k100 ; k100 = 36
.line	91	loadk        r10  k101 ; k101 = 203
.line	91	loadk        r11  k102 ; k102 = 223
.line	91	loadk        r12   k94 ; k94 = 42
.line	91	loadk        r13   k57 ; k57 = 175
.line	91	loadk        r14   k32 ; k32 = 98
.line	91	loadk        r15  k103 ; k103 = 171
.line	91	loadk        r16    k4 ; k4 = 221
.line	91	loadk        r17    k6 ; k6 = 200
.line	91	loadk        r18  k104 ; k104 = 25
.line	91	loadk        r19  k105 ; k105 = 85
.line	91	loadk        r20   k31 ; k31 = 46
.line	91	loadk        r21   k54 ; k54 = 107
.line	91	loadk        r22  k106 ; k106 = 242
.line	91	loadk        r23   k56 ; k56 = 249
.line	91	loadk        r24   k16 ; k16 = 173
.line	91	loadk        r25  k107 ; k107 = 66
.line	91	loadk        r26  k101 ; k101 = 203
.line	91	loadk        r27  k108 ; k108 = 38
.line	91	loadk        r28  k109 ; k109 = 19
.line	91	loadk        r29  k110 ; k110 = 247
.line	91	loadk        r30   k40 ; k40 = 105
.line	91	loadk        r31   k41 ; k41 = 129
.line	91	loadk        r32  k111 ; k111 = 246
.line	91	loadk        r33  k112 ; k112 = 210
.line	91	call          r6    28     2
.line	91	move          r7    r4
.line	91	call          r5     3     2
.line	91	test          r5     0
.line	91	jmp            0  l275
.line	91	gettabup      r6    u2  k113 ; k113 = "FuncUtil"
.line	91	gettable      r6    r6  k114 ; k114 = "UE4ExecuteConsoleCom" (truncated)
.line	91	getupval      r7    u1
.line	91	loadk         r8  k115 ; k115 = 16
.line	91	loadk         r9  k116 ; k116 = 155
.line	91	loadk        r10   k54 ; k54 = 107
.line	91	loadk        r11  k117 ; k117 = 238
.line	91	loadk        r12   k10 ; k10 = 202
.line	91	loadk        r13  k118 ; k118 = 61
.line	91	loadk        r14  k119 ; k119 = 137
.line	91	loadk        r15  k120 ; k120 = 125
.line	91	loadk        r16  k121 ; k121 = 145
.line	91	loadk        r17   k36 ; k36 = 254
.line	91	loadk        r18  k122 ; k122 = 235
.line	91	loadk        r19   k84 ; k84 = 12
.line	91	loadk        r20   k12 ; k12 = 82
.line	91	loadk        r21   k98 ; k98 = 37
.line	91	loadk        r22  k123 ; k123 = 118
.line	91	loadk        r23  k124 ; k124 = 199
.line	91	loadk        r24  k125 ; k125 = 241
.line	91	loadk        r25  k126 ; k126 = 184
.line	91	loadk        r26   k30 ; k30 = 80
.line	91	loadk        r27   k63 ; k63 = 214
.line	91	loadk        r28   k93 ; k93 = 45
.line	91	loadk        r29  k127 ; k127 = 41
.line	91	loadk        r30  k128 ; k128 = 255
.line	91	loadk        r31  k129 ; k129 = 120
.line	91	loadk        r32  k130 ; k130 = 159
.line	91	loadk        r33  k112 ; k112 = 210
.line	91	loadk        r34  k112 ; k112 = 210
.line	91	loadk        r35  k131 ; k131 = 17
.line	91	loadk        r36  k132 ; k132 = 77
.line	91	loadk        r37   k98 ; k98 = 37
.line	91	loadk        r38  k133 ; k133 = 124
.line	91	loadk        r39   k55 ; k55 = 194
.line	91	loadk        r40   k27 ; k27 = 229
.line	91	loadk        r41  k134 ; k134 = 248
.line	91	loadk        r42   k95 ; k95 = 20
.line	91	call          r7    36     2
.line	91	call          r6     2     1
.line	91	gettabup      r6    u2  k113 ; k113 = "FuncUtil"
.line	91	gettable      r6    r6  k114 ; k114 = "UE4ExecuteConsoleCom" (truncated)
.line	91	getupval      r7    u1
.line	91	loadk         r8   k91 ; k91 = 9
.line	91	loadk         r9    k8 ; k8 = 151
.line	91	loadk        r10  k135 ; k135 = 54
.line	91	loadk        r11  k136 ; k136 = 135
.line	91	loadk        r12   k36 ; k36 = 254
.line	91	loadk        r13   k37 ; k37 = 32
.line	91	loadk        r14  k137 ; k137 = 146
.line	91	loadk        r15  k138 ; k138 = 68
.line	91	loadk        r16    k8 ; k8 = 151
.line	91	loadk        r17   k36 ; k36 = 254
.line	91	loadk        r18  k125 ; k125 = 241
.line	91	loadk        r19  k139 ; k139 = 4
.line	91	loadk        r20  k140 ; k140 = 89
.line	91	loadk        r21  k135 ; k135 = 54
.line	91	loadk        r22  k141 ; k141 = 87
.line	91	loadk        r23   k77 ; k77 = 193
.line	91	loadk        r24  k142 ; k142 = 252
.line	91	loadk        r25  k143 ; k143 = 169
.line	91	loadk        r26  k144 ; k144 = 65
.line	91	loadk        r27  k145 ; k145 = 240
.line	91	loadk        r28  k146 ; k146 = 53
.line	91	loadk        r29  k147 ; k147 = 26
.line	91	loadk        r30  k148 ; k148 = 182
.line	91	loadk        r31    k2 ; k2 = 44
.line	91	call          r7    25     2
.line	91	call          r6     2     1
.label	l275
.line	91	return        r0     1
.line	91	move          r0    r0
.line	91	return        r0     1

.function	main/f2

.source	null
.linedefined	108
.lastlinedefined	111
.numparams	1
.is_vararg	0
.maxstacksize	42

.upvalue	"_ENV"	25	true
.upvalue	"U1"	1	true

.constant	k0	3
.constant	k1	148
.constant	k2	44
.constant	k3	204
.constant	k4	221
.constant	k5	59
.constant	k6	200
.constant	k7	94
.constant	k8	229
.constant	k9	198
.constant	k10	67
.constant	k11	80
.constant	k12	46
.constant	k13	98
.constant	k14	205
.constant	k15	243
.constant	k16	230
.constant	k17	89
.constant	k18	246
.constant	k19	34
.constant	k20	27
.constant	k21	255
.constant	k22	115
.constant	k23	143
.constant	k24	174
.constant	k25	219
.constant	k26	18
.constant	k27	75
.constant	k28	56
.constant	k29	118
.constant	k30	235
.constant	k31	236
.constant	k32	183
.constant	k33	68
.constant	k34	237
.constant	k35	58
.constant	k36	1
.constant	k37	225
.constant	k38	"ShowLoading"

.line	108	getupval      r1    u0
.line	108	getupval      r2    u1
.line	108	loadk         r3    k0 ; k0 = 3
.line	108	loadk         r4    k1 ; k1 = 148
.line	108	loadk         r5    k2 ; k2 = 44
.line	108	loadk         r6    k3 ; k3 = 204
.line	108	loadk         r7    k4 ; k4 = 221
.line	108	loadk         r8    k5 ; k5 = 59
.line	108	loadk         r9    k6 ; k6 = 200
.line	108	loadk        r10    k7 ; k7 = 94
.line	108	loadk        r11    k1 ; k1 = 148
.line	108	loadk        r12    k8 ; k8 = 229
.line	108	loadk        r13    k9 ; k9 = 198
.line	108	loadk        r14   k10 ; k10 = 67
.line	108	loadk        r15   k11 ; k11 = 80
.line	108	loadk        r16   k12 ; k12 = 46
.line	108	loadk        r17   k13 ; k13 = 98
.line	108	loadk        r18   k14 ; k14 = 205
.line	108	loadk        r19   k15 ; k15 = 243
.line	108	loadk        r20   k16 ; k16 = 230
.line	108	loadk        r21   k17 ; k17 = 89
.line	108	loadk        r22   k18 ; k18 = 246
.line	108	loadk        r23   k19 ; k19 = 34
.line	108	loadk        r24   k20 ; k20 = 27
.line	108	loadk        r25   k21 ; k21 = 255
.line	108	loadk        r26   k22 ; k22 = 115
.line	108	loadk        r27   k23 ; k23 = 143
.line	108	loadk        r28   k24 ; k24 = 174
.line	108	loadk        r29   k25 ; k25 = 219
.line	108	loadk        r30   k26 ; k26 = 18
.line	108	loadk        r31   k27 ; k27 = 75
.line	108	loadk        r32   k28 ; k28 = 56
.line	108	loadk        r33   k29 ; k29 = 118
.line	108	loadk        r34   k30 ; k30 = 235
.line	108	loadk        r35   k31 ; k31 = 236
.line	108	loadk        r36   k32 ; k32 = 183
.line	108	loadk        r37   k33 ; k33 = 68
.line	108	loadk        r38   k34 ; k34 = 237
.line	108	loadk        r39   k35 ; k35 = 58
.line	108	loadk        r40   k36 ; k36 = 1
.line	108	loadk        r41   k37 ; k37 = 225
.line	108	call          r2    40     2
.line	108	call          r1     2     2
.line	108	gettable      r2    r1   k38 ; k38 = "ShowLoading"
.line	108	loadbool      r3     1     0
.line	108	move          r4    r0
.line	108	call          r2     3     1
.line	108	return        r0     1
.line	108	move          r0    r0
.line	108	return        r0     1

.function	main/f3

.source	null
.linedefined	113
.lastlinedefined	122
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	25	true

.constant	k0	"log_tree"
.constant	k1	38
.constant	k2	141
.constant	k3	43
.constant	k4	202
.constant	k5	230
.constant	k6	59
.constant	k7	143
.constant	k8	65
.constant	k9	216
.constant	k10	223
.constant	k11	201
.constant	k12	37
.constant	k13	69
.constant	k14	49
.constant	k15	96
.constant	k16	214
.constant	k17	220
.constant	k18	161
.constant	k19	91
.constant	k20	242
.constant	k21	0
.constant	k22	19
.constant	k23	255
.constant	k24	126
.constant	k25	131
.constant	k26	229
.constant	k27	211
.constant	k28	93
.constant	k29	97
.constant	k30	52
.constant	k31	213
.constant	k32	196
.constant	k33	185
.constant	k34	81
.constant	k35	232
.constant	k36	105
.constant	k37	"id"
.constant	k38	39
.constant	k39	188
.constant	k40	21
.constant	k41	251
.constant	k42	54
.constant	k43	150
.constant	k44	72
.constant	k45	138
.constant	k46	206
.constant	k47	3
.constant	k48	87
.constant	k49	"url"
.constant	k50	16
.constant	k51	44
.constant	k52	210
.constant	k53	159
.constant	k54	"ModuleManager"
.constant	k55	"GetModule"
.constant	k56	"LobbyModuleConfig"
.constant	k57	"long_txt_manager"
.constant	k58	"table"
.constant	k59	"concat"
.constant	k60	148
.constant	k61	204
.constant	k62	221
.constant	k63	200
.constant	k64	94
.constant	k65	198
.constant	k66	67
.constant	k67	80
.constant	k68	46
.constant	k69	98
.constant	k70	205
.constant	k71	243
.constant	k72	86
.constant	k73	246
.constant	k74	18
.constant	k75	249
.constant	k76	115
.constant	k77	236
.constant	k78	26
.constant	k79	50
.constant	k80	74
.constant	k81	215
.constant	k82	239
.constant	k83	181
.constant	k84	61
.constant	k85	48
.constant	k86	234
.constant	k87	104
.constant	k88	7
.constant	k89	153
.constant	k90	41
.constant	k91	222
.constant	k92	60
.constant	k93	129
.constant	k94	"ShowPrivacyPolicy"
.constant	k95	"EventSystem"
.constant	k96	"postEvent"
.constant	k97	"EVENTTYPE_HYPERLINK"
.constant	k98	"EVENTID_HLINK_COMMSGBOXSLUA"

.line	113	gettabup      r1    u0    k0 ; k0 = "log_tree"
.line	113	getupval      r2    u1
.line	113	loadk         r3    k1 ; k1 = 38
.line	113	loadk         r4    k2 ; k2 = 141
.line	113	loadk         r5    k3 ; k3 = 43
.line	113	loadk         r6    k4 ; k4 = 202
.line	113	loadk         r7    k5 ; k5 = 230
.line	113	loadk         r8    k6 ; k6 = 59
.line	113	loadk         r9    k7 ; k7 = 143
.line	113	loadk        r10    k8 ; k8 = 65
.line	113	loadk        r11    k9 ; k9 = 216
.line	113	loadk        r12   k10 ; k10 = 223
.line	113	loadk        r13   k11 ; k11 = 201
.line	113	loadk        r14   k12 ; k12 = 37
.line	113	loadk        r15   k13 ; k13 = 69
.line	113	loadk        r16   k14 ; k14 = 49
.line	113	loadk        r17   k15 ; k15 = 96
.line	113	loadk        r18   k16 ; k16 = 214
.line	113	loadk        r19   k17 ; k17 = 220
.line	113	loadk        r20   k18 ; k18 = 161
.line	113	loadk        r21   k19 ; k19 = 91
.line	113	loadk        r22   k20 ; k20 = 242
.line	113	loadk        r23   k21 ; k21 = 0
.line	113	loadk        r24   k22 ; k22 = 19
.line	113	loadk        r25   k23 ; k23 = 255
.line	113	loadk        r26   k24 ; k24 = 126
.line	113	loadk        r27   k25 ; k25 = 131
.line	113	loadk        r28   k26 ; k26 = 229
.line	113	loadk        r29   k27 ; k27 = 211
.line	113	loadk        r30   k28 ; k28 = 93
.line	113	loadk        r31   k29 ; k29 = 97
.line	113	loadk        r32   k30 ; k30 = 52
.line	113	loadk        r33   k29 ; k29 = 97
.line	113	loadk        r34   k31 ; k31 = 213
.line	113	loadk        r35   k32 ; k32 = 196
.line	113	loadk        r36   k33 ; k33 = 185
.line	113	loadk        r37   k34 ; k34 = 81
.line	113	loadk        r38   k35 ; k35 = 232
.line	113	loadk        r39   k36 ; k36 = 105
.line	113	call          r2    38     2
.line	113	move          r3    r0
.line	113	call          r1     3     1
.line	113	gettable      r1    r0   k37 ; k37 = "id"
.line	113	getupval      r2    u1
.line	113	loadk         r3   k38 ; k38 = 39
.line	113	loadk         r4   k39 ; k39 = 188
.line	113	loadk         r5   k40 ; k40 = 21
.line	113	loadk         r6   k41 ; k41 = 251
.line	113	loadk         r7   k41 ; k41 = 251
.line	113	loadk         r8   k42 ; k42 = 54
.line	113	loadk         r9   k43 ; k43 = 150
.line	113	loadk        r10   k44 ; k44 = 72
.line	113	loadk        r11   k45 ; k45 = 138
.line	113	loadk        r12   k17 ; k17 = 220
.line	113	loadk        r13   k46 ; k46 = 206
.line	113	loadk        r14   k47 ; k47 = 3
.line	113	loadk        r15   k48 ; k48 = 87
.line	113	call          r2    14     2
.line	113	eq             0    r1    r2
.line	113	jmp            0  l140
.line	113	gettable      r1    r0   k49 ; k49 = "url"
.line	113	getupval      r2    u1
.line	113	loadk         r3   k50 ; k50 = 16
.line	113	loadk         r4   k45 ; k45 = 138
.line	113	loadk         r5   k51 ; k51 = 44
.line	113	loadk         r6   k10 ; k10 = 223
.line	113	loadk         r7   k52 ; k52 = 210
.line	113	loadk         r8   k51 ; k51 = 44
.line	113	loadk         r9   k53 ; k53 = 159
.line	113	call          r2     8     2
.line	113	eq             0    r1    r2
.line	113	jmp            0  l140
.line	113	gettabup      r1    u0   k54 ; k54 = "ModuleManager"
.line	113	gettable      r1    r1   k55 ; k55 = "GetModule"
.line	113	gettabup      r2    u0   k54 ; k54 = "ModuleManager"
.line	113	gettable      r2    r2   k56 ; k56 = "LobbyModuleConfig"
.line	113	gettable      r2    r2   k57 ; k57 = "long_txt_manager"
.line	113	call          r1     2     2
.line	113	getupval      r2    u2
.line	113	gettabup      r3    u0   k58 ; k58 = "table"
.line	113	gettable      r3    r3   k59 ; k59 = "concat"
.line	113	newtable      r4     1     0
.line	113	getupval      r5    u1
.line	113	loadk         r6   k47 ; k47 = 3
.line	113	loadk         r7   k60 ; k60 = 148
.line	113	loadk         r8   k51 ; k51 = 44
.line	113	loadk         r9   k61 ; k61 = 204
.line	113	loadk        r10   k62 ; k62 = 221
.line	113	loadk        r11    k6 ; k6 = 59
.line	113	loadk        r12   k63 ; k63 = 200
.line	113	loadk        r13   k64 ; k64 = 94
.line	113	loadk        r14   k60 ; k60 = 148
.line	113	loadk        r15   k26 ; k26 = 229
.line	113	loadk        r16   k65 ; k65 = 198
.line	113	loadk        r17   k66 ; k66 = 67
.line	113	loadk        r18   k67 ; k67 = 80
.line	113	loadk        r19   k68 ; k68 = 46
.line	113	loadk        r20   k69 ; k69 = 98
.line	113	loadk        r21   k70 ; k70 = 205
.line	113	loadk        r22   k71 ; k71 = 243
.line	113	loadk        r23    k5 ; k5 = 230
.line	113	loadk        r24   k72 ; k72 = 86
.line	113	loadk        r25   k73 ; k73 = 246
.line	113	loadk        r26   k68 ; k68 = 46
.line	113	loadk        r27   k74 ; k74 = 18
.line	113	loadk        r28   k75 ; k75 = 249
.line	113	loadk        r29   k76 ; k76 = 115
.line	113	loadk        r30   k65 ; k65 = 198
.line	113	loadk        r31   k77 ; k77 = 236
.line	113	loadk        r32    k9 ; k9 = 216
.line	113	loadk        r33   k78 ; k78 = 26
.line	113	loadk        r34   k13 ; k13 = 69
.line	113	loadk        r35   k79 ; k79 = 50
.line	113	loadk        r36   k80 ; k80 = 74
.line	113	loadk        r37   k81 ; k81 = 215
.line	113	loadk        r38   k82 ; k82 = 239
.line	113	loadk        r39   k83 ; k83 = 181
.line	113	loadk        r40   k44 ; k44 = 72
.line	113	loadk        r41    k5 ; k5 = 230
.line	113	loadk        r42   k84 ; k84 = 61
.line	113	loadk        r43   k85 ; k85 = 48
.line	113	loadk        r44   k86 ; k86 = 234
.line	113	loadk        r45   k87 ; k87 = 104
.line	113	call          r5    41     2
.line	113	getupval      r6    u1
.line	113	loadk         r7   k88 ; k88 = 7
.line	113	loadk         r8   k89 ; k89 = 153
.line	113	loadk         r9   k90 ; k90 = 41
.line	113	loadk        r10   k73 ; k73 = 246
.line	113	loadk        r11   k91 ; k91 = 222
.line	113	loadk        r12   k92 ; k92 = 60
.line	113	loadk        r13   k93 ; k93 = 129
.line	113	call          r6     8     0
.line	113	setlist       r4     0     1
.line	113	call          r3     2     2
.line	113	call          r2     2     2
.line	113	gettable      r3    r2   k94 ; k94 = "ShowPrivacyPolicy"
.line	113	call          r3     1     1
.line	113	return        r0     1
.label	l140
.line	113	gettabup      r1    u0   k95 ; k95 = "EventSystem"
.line	113	self          r1    r1   k96 ; k96 = "postEvent"
.line	113	gettabup      r3    u0   k97 ; k97 = "EVENTTYPE_HYPERLINK"
.line	113	gettabup      r4    u0   k98 ; k98 = "EVENTID_HLINK_COMMSG" (truncated)
.line	113	move          r5    r0
.line	113	call          r1     5     1
.line	113	return        r0     1
.line	113	move          r0    r0
.line	113	return        r0     1

.function	main/f4

.source	null
.linedefined	124
.lastlinedefined	137
.numparams	2
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	10	true
.upvalue	"U1"	21	true

.constant	k0	1
.constant	k1	true

.line	124	newtable      r2     0     0
.line	124	getupval      r3    u0
.line	124	move          r4    r0
.line	124	loadk         r5    k0 ; k0 = 1
.line	124	len           r6    r0
.line	124	loadk         r7    k0 ; k0 = 1
.line	124	move          r8    r2
.line	124	call          r3     6     1
.line	124	newtable      r3     0     0
.line	124	getupval      r4    u1
.line	124	move          r5    r0
.line	124	call          r4     2     4
.line	124	jmp            0   l15
.line	124	settable      r3    r8    k1 ; k1 = true
.label	l15
.line	124	move          r0    r0
.line	124	move          r0    r0
.line	124	getupval      r4    u1
.line	124	move          r5    r1
.line	124	call          r4     2     4
.line	124	jmp            0   l27
.line	124	gettable      r9    r3    r8
.line	124	test          r9     1
.line	124	jmp            0   l27
.line	124	len           r9    r2
.line	124	add           r9    r9    k0 ; k0 = 1
.line	124	settable      r2    r9    r8
.label	l27
.line	124	move          r0    r0
.line	124	move          r0    r0
.line	124	return        r2     2
.line	124	return        r0     1
.line	124	move          r0    r0
.line	124	return        r0     1

.function	main/f5

.source	null
.linedefined	139
.lastlinedefined	186
.numparams	1
.is_vararg	0
.maxstacksize	38

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	24	true
.upvalue	"U3"	25	true

.constant	k0	"LocUtil"
.constant	k1	"GetLocalizeResStr"
.constant	k2	83
.constant	k3	200
.constant	k4	116
.constant	k5	155
.constant	k6	128
.constant	k7	123
.constant	k8	3
.constant	k9	148
.constant	k10	44
.constant	k11	204
.constant	k12	221
.constant	k13	59
.constant	k14	78
.constant	k15	151
.constant	k16	253
.constant	k17	202
.constant	k18	2
.constant	k19	82
.constant	k20	111
.constant	k21	98
.constant	k22	199
.constant	k23	252
.constant	k24	167
.constant	k25	64
.constant	k26	245
.constant	k27	39
.constant	k28	32
.constant	k29	243
.constant	k30	154
.constant	k31	239
.constant	k32	197
.constant	k33	34
.constant	k34	72
.constant	k35	52
.constant	k36	115
.constant	k37	238
.constant	k38	189
.constant	k39	"GCLOULD_ErrorNetworkException"
.constant	k40	81
.constant	k41	118
.constant	k42	153
.constant	k43	130
.constant	k44	122
.constant	k45	"GCLOULD_ErrorTimeout"
.constant	k46	"GCLOULD_ErrorInvalidArgument"
.constant	k47	121
.constant	k48	"GCLOULD_ErrorLengthError"
.constant	k49	120
.constant	k50	"GCLOULD_ErrorEmpty"
.constant	k51	119
.constant	k52	"GCLOULD_ErrorNotInitialized"
.constant	k53	"GCLOULD_ErrorNotSupported"
.constant	k54	135
.constant	k55	127
.constant	k56	"GCLOULD_ErrorNotInstalled"
.constant	k57	126
.constant	k58	"GCLOULD_ErrorSystemError"
.constant	k59	125
.constant	k60	"GCLOULD_ErrorNoPermission"
.constant	k61	124
.constant	k62	"GCLOULD_ErrorInvalidGameId"
.constant	k63	"GCLOULD_ErrorChecking"
.constant	k64	"GCLOULD_ErrorConnectFailed"
.constant	k65	"GCLOULD_ErrorPeerCloseConnection"
.constant	k66	"GCLOULD_ErrorPeerStopSession"
.constant	k67	"GCLOULD_ErrorStayInQueue"
.constant	k68	"GCLOULD_ErrorSvrIsFull"
.constant	k69	134
.constant	k70	"GCLOULD_ErrorTokenSvrError"
.constant	k71	"GCLOULD_ErrorAuthFailed"
.constant	k72	"GCLOULD_ErrorOverflow"
.constant	k73	"GCLOULD_ErrorInvalidToken"
.constant	k74	84
.constant	k75	117
.constant	k76	158

.line	139	gettabup      r1    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r1    r1    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r2    u1
.line	139	loadk         r3    k2 ; k2 = 83
.line	139	loadk         r4    k3 ; k3 = 200
.line	139	loadk         r5    k4 ; k4 = 116
.line	139	loadk         r6    k5 ; k5 = 155
.line	139	loadk         r7    k6 ; k6 = 128
.line	139	loadk         r8    k7 ; k7 = 123
.line	139	call          r2     7     2
.line	139	call          r1     2     2
.line	139	getupval      r2    u2
.line	139	move          r3    r0
.line	139	call          r2     2     2
.line	139	concat        r1    r1    r2
.line	139	getupval      r2    u3
.line	139	getupval      r3    u1
.line	139	loadk         r4    k8 ; k8 = 3
.line	139	loadk         r5    k9 ; k9 = 148
.line	139	loadk         r6   k10 ; k10 = 44
.line	139	loadk         r7   k11 ; k11 = 204
.line	139	loadk         r8   k12 ; k12 = 221
.line	139	loadk         r9   k13 ; k13 = 59
.line	139	loadk        r10    k3 ; k3 = 200
.line	139	loadk        r11   k14 ; k14 = 78
.line	139	loadk        r12   k15 ; k15 = 151
.line	139	loadk        r13   k16 ; k16 = 253
.line	139	loadk        r14   k17 ; k17 = 202
.line	139	loadk        r15   k18 ; k18 = 2
.line	139	loadk        r16   k19 ; k19 = 82
.line	139	loadk        r17   k20 ; k20 = 111
.line	139	loadk        r18   k21 ; k21 = 98
.line	139	loadk        r19   k22 ; k22 = 199
.line	139	loadk        r20   k23 ; k23 = 252
.line	139	loadk        r21   k24 ; k24 = 167
.line	139	loadk        r22   k25 ; k25 = 64
.line	139	loadk        r23   k26 ; k26 = 245
.line	139	loadk        r24   k27 ; k27 = 39
.line	139	loadk        r25   k28 ; k28 = 32
.line	139	loadk        r26   k29 ; k29 = 243
.line	139	loadk        r27   k20 ; k20 = 111
.line	139	loadk        r28   k30 ; k30 = 154
.line	139	loadk        r29   k31 ; k31 = 239
.line	139	loadk        r30   k32 ; k32 = 197
.line	139	loadk        r31   k33 ; k33 = 34
.line	139	loadk        r32   k34 ; k34 = 72
.line	139	loadk        r33   k35 ; k35 = 52
.line	139	loadk        r34   k36 ; k36 = 115
.line	139	loadk        r35   k12 ; k12 = 221
.line	139	loadk        r36   k37 ; k37 = 238
.line	139	loadk        r37   k38 ; k38 = 189
.line	139	call          r3    35     2
.line	139	call          r2     2     2
.line	139	gettable      r3    r2   k39 ; k39 = "GCLOULD_ErrorNetwork" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0   l70
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5   k40 ; k40 = 81
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7   k41 ; k41 = 118
.line	139	loadk         r8   k42 ; k42 = 153
.line	139	loadk         r9   k43 ; k43 = 130
.line	139	loadk        r10   k44 ; k44 = 122
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l70
.line	139	gettable      r3    r2   k45 ; k45 = "GCLOULD_ErrorTimeout"
.line	139	eq             0    r0    r3
.line	139	jmp            0   l86
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9    k6 ; k6 = 128
.line	139	loadk        r10   k44 ; k44 = 122
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l86
.line	139	gettable      r3    r2   k46 ; k46 = "GCLOULD_ErrorInvalid" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0  l102
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9    k6 ; k6 = 128
.line	139	loadk        r10   k47 ; k47 = 121
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l102
.line	139	gettable      r3    r2   k48 ; k48 = "GCLOULD_ErrorLengthE" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0  l118
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9    k6 ; k6 = 128
.line	139	loadk        r10   k49 ; k49 = 120
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l118
.line	139	gettable      r3    r2   k50 ; k50 = "GCLOULD_ErrorEmpty"
.line	139	eq             0    r0    r3
.line	139	jmp            0  l134
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9    k6 ; k6 = 128
.line	139	loadk        r10   k51 ; k51 = 119
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l134
.line	139	gettable      r3    r2   k52 ; k52 = "GCLOULD_ErrorNotInit" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0  l150
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9    k6 ; k6 = 128
.line	139	loadk        r10   k41 ; k41 = 118
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l150
.line	139	gettable      r3    r2   k53 ; k53 = "GCLOULD_ErrorNotSupp" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0  l166
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9   k54 ; k54 = 135
.line	139	loadk        r10   k55 ; k55 = 127
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l166
.line	139	gettable      r3    r2   k56 ; k56 = "GCLOULD_ErrorNotInst" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0  l182
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9   k54 ; k54 = 135
.line	139	loadk        r10   k57 ; k57 = 126
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l182
.line	139	gettable      r3    r2   k58 ; k58 = "GCLOULD_ErrorSystemE" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0  l198
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9   k54 ; k54 = 135
.line	139	loadk        r10   k59 ; k59 = 125
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l198
.line	139	gettable      r3    r2   k60 ; k60 = "GCLOULD_ErrorNoPermi" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0  l214
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9   k54 ; k54 = 135
.line	139	loadk        r10   k61 ; k61 = 124
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l214
.line	139	gettable      r3    r2   k62 ; k62 = "GCLOULD_ErrorInvalid" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0  l230
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9   k54 ; k54 = 135
.line	139	loadk        r10    k7 ; k7 = 123
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l230
.line	139	gettable      r3    r2   k63 ; k63 = "GCLOULD_ErrorCheckin" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0  l246
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9   k54 ; k54 = 135
.line	139	loadk        r10   k44 ; k44 = 122
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l246
.line	139	gettable      r3    r2   k64 ; k64 = "GCLOULD_ErrorConnect" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0  l262
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9   k54 ; k54 = 135
.line	139	loadk        r10   k47 ; k47 = 121
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l262
.line	139	gettable      r3    r2   k65 ; k65 = "GCLOULD_ErrorPeerClo" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0  l278
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9   k54 ; k54 = 135
.line	139	loadk        r10   k49 ; k49 = 120
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l278
.line	139	gettable      r3    r2   k66 ; k66 = "GCLOULD_ErrorPeerSto" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0  l294
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9   k54 ; k54 = 135
.line	139	loadk        r10   k51 ; k51 = 119
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l294
.line	139	gettable      r3    r2   k67 ; k67 = "GCLOULD_ErrorStayInQ" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0  l310
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9   k54 ; k54 = 135
.line	139	loadk        r10   k41 ; k41 = 118
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l310
.line	139	gettable      r3    r2   k68 ; k68 = "GCLOULD_ErrorSvrIsFu" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0  l326
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9   k69 ; k69 = 134
.line	139	loadk        r10   k55 ; k55 = 127
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l326
.line	139	gettable      r3    r2   k70 ; k70 = "GCLOULD_ErrorTokenSv" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0  l342
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9   k69 ; k69 = 134
.line	139	loadk        r10   k57 ; k57 = 126
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l342
.line	139	gettable      r3    r2   k71 ; k71 = "GCLOULD_ErrorAuthFai" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0  l358
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9   k69 ; k69 = 134
.line	139	loadk        r10   k59 ; k59 = 125
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l358
.line	139	gettable      r3    r2   k72 ; k72 = "GCLOULD_ErrorOverflo" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0  l374
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5    k2 ; k2 = 83
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7    k4 ; k4 = 116
.line	139	loadk         r8    k5 ; k5 = 155
.line	139	loadk         r9   k69 ; k69 = 134
.line	139	loadk        r10   k61 ; k61 = 124
.line	139	call          r4     7     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.line	139	jmp            0  l387
.label	l374
.line	139	gettable      r3    r2   k73 ; k73 = "GCLOULD_ErrorInvalid" (truncated)
.line	139	eq             0    r0    r3
.line	139	jmp            0  l387
.line	139	gettabup      r3    u0    k0 ; k0 = "LocUtil"
.line	139	gettable      r3    r3    k1 ; k1 = "GetLocalizeResStr"
.line	139	getupval      r4    u1
.line	139	loadk         r5   k74 ; k74 = 84
.line	139	loadk         r6    k3 ; k3 = 200
.line	139	loadk         r7   k75 ; k75 = 117
.line	139	loadk         r8   k76 ; k76 = 158
.line	139	call          r4     5     2
.line	139	call          r3     2     2
.line	139	move          r1    r3
.label	l387
.line	139	return        r1     2
.line	139	return        r0     1
.line	139	move          r0    r0
.line	139	move          r0    r0
.line	139	move          r0    r0
.line	139	move          r0    r0
.line	139	return        r0     1

.function	main/f6

.source	null
.linedefined	188
.lastlinedefined	193
.numparams	1
.is_vararg	0
.maxstacksize	21

.upvalue	"_ENV"	25	true
.upvalue	"U1"	1	true
.upvalue	"U2"	23	true

.constant	k0	3
.constant	k1	151
.constant	k2	40
.constant	k3	196
.constant	k4	220
.constant	k5	33
.constant	k6	200
.constant	k7	94
.constant	k8	140
.constant	k9	226
.constant	k10	206
.constant	k11	91
.constant	k12	30
.constant	k13	112
.constant	k14	208
.constant	k15	249
.constant	k16	164
.constant	k17	89
.constant	k18	153
.constant	k19	242
.constant	k20	203
.constant	k21	8
.constant	k22	99
.constant	k23	52
.constant	k24	113
.constant	k25	205
.constant	k26	252
.constant	k27	"GetTableValue"
.constant	k28	"ParseURLParams"
.constant	k29	1
.constant	k30	155
.constant	k31	49
.constant	k32	192
.constant	k33	197
.constant	k34	38
.constant	k35	146
.constant	k36	84
.constant	k37	145
.constant	k38	244
.constant	k39	0

.line	188	getupval      r1    u0
.line	188	getupval      r2    u1
.line	188	loadk         r3    k0 ; k0 = 3
.line	188	loadk         r4    k1 ; k1 = 151
.line	188	loadk         r5    k2 ; k2 = 40
.line	188	loadk         r6    k3 ; k3 = 196
.line	188	loadk         r7    k4 ; k4 = 220
.line	188	loadk         r8    k5 ; k5 = 33
.line	188	loadk         r9    k6 ; k6 = 200
.line	188	loadk        r10    k7 ; k7 = 94
.line	188	loadk        r11    k8 ; k8 = 140
.line	188	loadk        r12    k9 ; k9 = 226
.line	188	loadk        r13   k10 ; k10 = 206
.line	188	loadk        r14    k0 ; k0 = 3
.line	188	loadk        r15   k11 ; k11 = 91
.line	188	loadk        r16   k12 ; k12 = 30
.line	188	loadk        r17   k13 ; k13 = 112
.line	188	loadk        r18   k14 ; k14 = 208
.line	188	loadk        r19   k15 ; k15 = 249
.line	188	loadk        r20   k16 ; k16 = 164
.line	188	call          r2    19     2
.line	188	call          r1     2     2
.line	188	getupval      r2    u0
.line	188	getupval      r3    u1
.line	188	loadk         r4    k0 ; k0 = 3
.line	188	loadk         r5    k1 ; k1 = 151
.line	188	loadk         r6    k2 ; k2 = 40
.line	188	loadk         r7    k3 ; k3 = 196
.line	188	loadk         r8    k4 ; k4 = 220
.line	188	loadk         r9    k5 ; k5 = 33
.line	188	loadk        r10    k6 ; k6 = 200
.line	188	loadk        r11   k17 ; k17 = 89
.line	188	loadk        r12   k18 ; k18 = 153
.line	188	loadk        r13   k19 ; k19 = 242
.line	188	loadk        r14   k20 ; k20 = 203
.line	188	loadk        r15   k21 ; k21 = 8
.line	188	loadk        r16   k22 ; k22 = 99
.line	188	loadk        r17   k23 ; k23 = 52
.line	188	loadk        r18   k24 ; k24 = 113
.line	188	loadk        r19   k25 ; k25 = 205
.line	188	loadk        r20   k26 ; k26 = 252
.line	188	call          r3    18     2
.line	188	call          r2     2     2
.line	188	gettable      r3    r2   k27 ; k27 = "GetTableValue"
.line	188	gettable      r4    r1   k28 ; k28 = "ParseURLParams"
.line	188	move          r5    r0
.line	188	call          r4     2     2
.line	188	getupval      r5    u1
.line	188	loadk         r6   k29 ; k29 = 1
.line	188	loadk         r7   k30 ; k30 = 155
.line	188	loadk         r8   k31 ; k31 = 49
.line	188	loadk         r9   k32 ; k32 = 192
.line	188	loadk        r10   k33 ; k33 = 197
.line	188	loadk        r11   k34 ; k34 = 38
.line	188	loadk        r12   k35 ; k35 = 146
.line	188	loadk        r13   k36 ; k36 = 84
.line	188	loadk        r14   k37 ; k37 = 145
.line	188	loadk        r15   k38 ; k38 = 244
.line	188	call          r5    11     2
.line	188	call          r3     3     2
.line	188	test          r3     1
.line	188	jmp            0   l64
.line	188	loadk         r3   k39 ; k39 = 0
.label	l64
.line	188	getupval      r4    u2
.line	188	move          r5    r3
.line	188	tailcall      r4     2
.line	188	return        r4     0
.line	188	return        r0     1
.line	188	move          r0    r0
.line	188	move          r0    r0
.line	188	move          r0    r0
.line	188	return        r0     1

.function	main/f7

.source	null
.linedefined	195
.lastlinedefined	211
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	25	true
.upvalue	"U2"	1	true
.upvalue	"U3"	24	true

.constant	k0	"FuncUtil"
.constant	k1	"GetActivityIdByURL"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	3
.constant	k5	148
.constant	k6	44
.constant	k7	204
.constant	k8	221
.constant	k9	59
.constant	k10	200
.constant	k11	94
.constant	k12	229
.constant	k13	198
.constant	k14	67
.constant	k15	80
.constant	k16	46
.constant	k17	98
.constant	k18	205
.constant	k19	243
.constant	k20	230
.constant	k21	84
.constant	k22	250
.constant	k23	55
.constant	k24	22
.constant	k25	224
.constant	k26	116
.constant	k27	156
.constant	k28	249
.constant	k29	153
.constant	k30	17
.constant	k31	54
.constant	k32	124
.constant	k33	215
.constant	k34	223
.constant	k35	185
.constant	k36	70
.constant	k37	253
.constant	k38	58
.constant	k39	25
.constant	k40	239
.constant	k41	121
.constant	k42	167
.constant	k43	40
.constant	k44	206
.constant	k45	193
.constant	k46	"GetActivityByID"
.constant	k47	"IsDuringActTime"
.constant	k48	"GetActivityTypeByURL"
.constant	k49	0
.constant	k50	"GetActivityByType"
.constant	k51	"log"
.constant	k52	"bWriteLog"
.constant	k53	161
.constant	k54	28
.constant	k55	244
.constant	k56	60
.constant	k57	78
.constant	k58	140
.constant	k59	209
.constant	k60	4
.constant	k61	72
.constant	k62	56
.constant	k63	214
.constant	k64	252
.constant	k65	158
.constant	k66	245
.constant	k67	42
.constant	k68	27
.constant	k69	171
.constant	k70	32
.constant	k71	213
.constant	k72	189
.constant	k73	138

.line	195	gettabup      r1    u0    k0 ; k0 = "FuncUtil"
.line	195	gettable      r1    r1    k1 ; k1 = "GetActivityIdByURL"
.line	195	move          r2    r0
.line	195	call          r1     2     2
.line	195	getupval      r2    u1
.line	195	gettabup      r3    u0    k2 ; k2 = "table"
.line	195	gettable      r3    r3    k3 ; k3 = "concat"
.line	195	newtable      r4     1     0
.line	195	getupval      r5    u2
.line	195	loadk         r6    k4 ; k4 = 3
.line	195	loadk         r7    k5 ; k5 = 148
.line	195	loadk         r8    k6 ; k6 = 44
.line	195	loadk         r9    k7 ; k7 = 204
.line	195	loadk        r10    k8 ; k8 = 221
.line	195	loadk        r11    k9 ; k9 = 59
.line	195	loadk        r12   k10 ; k10 = 200
.line	195	loadk        r13   k11 ; k11 = 94
.line	195	loadk        r14    k5 ; k5 = 148
.line	195	loadk        r15   k12 ; k12 = 229
.line	195	loadk        r16   k13 ; k13 = 198
.line	195	loadk        r17   k14 ; k14 = 67
.line	195	loadk        r18   k15 ; k15 = 80
.line	195	loadk        r19   k16 ; k16 = 46
.line	195	loadk        r20   k17 ; k17 = 98
.line	195	loadk        r21   k18 ; k18 = 205
.line	195	loadk        r22   k19 ; k19 = 243
.line	195	loadk        r23   k20 ; k20 = 230
.line	195	loadk        r24   k21 ; k21 = 84
.line	195	loadk        r25   k22 ; k22 = 250
.line	195	loadk        r26   k23 ; k23 = 55
.line	195	loadk        r27   k24 ; k24 = 22
.line	195	loadk        r28   k25 ; k25 = 224
.line	195	loadk        r29   k26 ; k26 = 116
.line	195	loadk        r30   k27 ; k27 = 156
.line	195	loadk        r31   k28 ; k28 = 249
.line	195	loadk        r32   k29 ; k29 = 153
.line	195	loadk        r33   k30 ; k30 = 17
.line	195	loadk        r34   k14 ; k14 = 67
.line	195	loadk        r35   k31 ; k31 = 54
.line	195	loadk        r36   k32 ; k32 = 124
.line	195	loadk        r37   k33 ; k33 = 215
.line	195	loadk        r38   k34 ; k34 = 223
.line	195	loadk        r39   k35 ; k35 = 185
.line	195	loadk        r40   k36 ; k36 = 70
.line	195	loadk        r41   k37 ; k37 = 253
.line	195	loadk        r42   k38 ; k38 = 58
.line	195	loadk        r43   k39 ; k39 = 25
.line	195	loadk        r44   k40 ; k40 = 239
.line	195	loadk        r45   k41 ; k41 = 121
.line	195	call          r5    41     2
.line	195	getupval      r6    u2
.line	195	loadk         r7   k39 ; k39 = 25
.line	195	loadk         r8   k42 ; k42 = 167
.line	195	loadk         r9   k43 ; k43 = 40
.line	195	loadk        r10   k44 ; k44 = 206
.line	195	loadk        r11   k45 ; k45 = 193
.line	195	call          r6     6     0
.line	195	setlist       r4     0     1
.line	195	call          r3     2     2
.line	195	call          r2     2     2
.line	195	gettable      r3    r2   k46 ; k46 = "GetActivityByID"
.line	195	move          r4    r1
.line	195	call          r3     2     2
.line	195	gettabup      r4    u0    k0 ; k0 = "FuncUtil"
.line	195	gettable      r4    r4   k47 ; k47 = "IsDuringActTime"
.line	195	move          r5    r3
.line	195	call          r4     2     2
.line	195	test          r4     0
.line	195	jmp            0   l72
.line	195	loadbool      r4     1     0
.line	195	return        r4     2
.label	l72
.line	195	gettabup      r4    u0    k0 ; k0 = "FuncUtil"
.line	195	gettable      r4    r4   k48 ; k48 = "GetActivityTypeByURL"
.line	195	move          r5    r0
.line	195	call          r4     2     2
.line	195	lt             0   k49    r4 ; k49 = 0
.line	195	jmp            0  l128
.line	195	gettable      r5    r2   k50 ; k50 = "GetActivityByType"
.line	195	move          r6    r4
.line	195	call          r5     2     2
.line	195	move          r3    r5
.line	195	gettabup      r5    u0   k51 ; k51 = "log"
.line	195	gettabup      r6    u0   k52 ; k52 = "bWriteLog"
.line	195	test          r6     0
.line	195	jmp            0  l119
.line	195	getupval      r6    u2
.line	195	loadk         r7    k9 ; k9 = 59
.line	195	loadk         r8   k53 ; k53 = 161
.line	195	loadk         r9   k54 ; k54 = 28
.line	195	loadk        r10   k55 ; k55 = 244
.line	195	loadk        r11   k22 ; k22 = 250
.line	195	loadk        r12   k56 ; k56 = 60
.line	195	loadk        r13   k42 ; k42 = 167
.line	195	loadk        r14   k57 ; k57 = 78
.line	195	loadk        r15   k58 ; k58 = 140
.line	195	loadk        r16   k28 ; k28 = 249
.line	195	loadk        r17   k59 ; k59 = 209
.line	195	loadk        r18   k60 ; k60 = 4
.line	195	loadk        r19   k61 ; k61 = 72
.line	195	loadk        r20   k62 ; k62 = 56
.line	195	loadk        r21   k15 ; k15 = 80
.line	195	loadk        r22   k63 ; k63 = 214
.line	195	loadk        r23   k64 ; k64 = 252
.line	195	loadk        r24   k65 ; k65 = 158
.line	195	loadk        r25   k21 ; k21 = 84
.line	195	loadk        r26   k66 ; k66 = 245
.line	195	loadk        r27   k67 ; k67 = 42
.line	195	loadk        r28   k68 ; k68 = 27
.line	195	loadk        r29   k69 ; k69 = 171
.line	195	loadk        r30   k70 ; k70 = 32
.line	195	loadk        r31   k71 ; k71 = 213
.line	195	loadk        r32   k72 ; k72 = 189
.line	195	loadk        r33   k73 ; k73 = 138
.line	195	call          r6    28     2
.line	195	getupval      r7    u3
.line	195	move          r8    r4
.line	195	call          r7     2     2
.line	195	concat        r6    r6    r7
.label	l119
.line	195	call          r5     2     1
.line	195	gettabup      r5    u0    k0 ; k0 = "FuncUtil"
.line	195	gettable      r5    r5   k47 ; k47 = "IsDuringActTime"
.line	195	move          r6    r3
.line	195	call          r5     2     2
.line	195	test          r5     0
.line	195	jmp            0  l128
.line	195	loadbool      r5     1     0
.line	195	return        r5     2
.label	l128
.line	195	loadbool      r5     0     0
.line	195	return        r5     2
.line	195	return        r0     1
.line	195	move          r0    r0
.line	195	move          r0    r0
.line	195	return        r0     1

.function	main/f8

.source	null
.linedefined	213
.lastlinedefined	227
.numparams	1
.is_vararg	0
.maxstacksize	26

.upvalue	"_ENV"	25	true
.upvalue	"U1"	1	true

.constant	k0	3
.constant	k1	148
.constant	k2	44
.constant	k3	204
.constant	k4	221
.constant	k5	59
.constant	k6	200
.constant	k7	78
.constant	k8	151
.constant	k9	253
.constant	k10	202
.constant	k11	2
.constant	k12	82
.constant	k13	111
.constant	k14	113
.constant	k15	205
.constant	k16	173
.constant	k17	106
.constant	k18	236
.constant	k19	55
.constant	k20	22
.constant	k21	250
.constant	k22	"GetServerTimeInSec"
.constant	k23	"StartTime"
.constant	k24	0
.constant	k25	"EndTime"

.line	213	test          r0     1
.line	213	jmp            0    l5
.line	213	loadbool      r1     0     0
.line	213	return        r1     2
.label	l5
.line	213	getupval      r1    u0
.line	213	getupval      r2    u1
.line	213	loadk         r3    k0 ; k0 = 3
.line	213	loadk         r4    k1 ; k1 = 148
.line	213	loadk         r5    k2 ; k2 = 44
.line	213	loadk         r6    k3 ; k3 = 204
.line	213	loadk         r7    k4 ; k4 = 221
.line	213	loadk         r8    k5 ; k5 = 59
.line	213	loadk         r9    k6 ; k6 = 200
.line	213	loadk        r10    k7 ; k7 = 78
.line	213	loadk        r11    k8 ; k8 = 151
.line	213	loadk        r12    k9 ; k9 = 253
.line	213	loadk        r13   k10 ; k10 = 202
.line	213	loadk        r14   k11 ; k11 = 2
.line	213	loadk        r15   k12 ; k12 = 82
.line	213	loadk        r16   k13 ; k13 = 111
.line	213	loadk        r17   k14 ; k14 = 113
.line	213	loadk        r18   k15 ; k15 = 205
.line	213	loadk        r19    k9 ; k9 = 253
.line	213	loadk        r20   k16 ; k16 = 173
.line	213	loadk        r21   k17 ; k17 = 106
.line	213	loadk        r22   k18 ; k18 = 236
.line	213	loadk        r23   k19 ; k19 = 55
.line	213	loadk        r24   k20 ; k20 = 22
.line	213	loadk        r25   k21 ; k21 = 250
.line	213	call          r2    24     2
.line	213	call          r1     2     2
.line	213	gettable      r2    r1   k22 ; k22 = "GetServerTimeInSec"
.line	213	call          r2     1     2
.line	213	test          r0     0
.line	213	jmp            0   l50
.line	213	gettable      r3    r0   k23 ; k23 = "StartTime"
.line	213	test          r3     1
.line	213	jmp            0   l40
.line	213	loadk         r3   k24 ; k24 = 0
.label	l40
.line	213	gettable      r4    r0   k25 ; k25 = "EndTime"
.line	213	test          r4     1
.line	213	jmp            0   l44
.line	213	loadk         r4   k24 ; k24 = 0
.label	l44
.line	213	le             0    r3    r2
.line	213	jmp            0   l50
.line	213	le             0    r2    r4
.line	213	jmp            0   l50
.line	213	loadbool      r5     1     0
.line	213	return        r5     2
.label	l50
.line	213	loadbool      r3     0     0
.line	213	return        r3     2
.line	213	return        r0     1
.line	213	move          r0    r0
.line	213	move          r0    r0
.line	213	return        r0     1

.function	main/f9

.source	null
.linedefined	229
.lastlinedefined	238
.numparams	1
.is_vararg	0
.maxstacksize	21

.upvalue	"_ENV"	25	true
.upvalue	"U1"	1	true
.upvalue	"U2"	23	true
.upvalue	"U3"	0	false

.constant	k0	3
.constant	k1	151
.constant	k2	40
.constant	k3	196
.constant	k4	220
.constant	k5	33
.constant	k6	200
.constant	k7	94
.constant	k8	140
.constant	k9	226
.constant	k10	206
.constant	k11	91
.constant	k12	30
.constant	k13	112
.constant	k14	208
.constant	k15	249
.constant	k16	164
.constant	k17	89
.constant	k18	153
.constant	k19	242
.constant	k20	203
.constant	k21	8
.constant	k22	99
.constant	k23	52
.constant	k24	113
.constant	k25	205
.constant	k26	252
.constant	k27	"GetTableValue"
.constant	k28	"ParseURLParams"
.constant	k29	1
.constant	k30	155
.constant	k31	49
.constant	k32	192
.constant	k33	197
.constant	k34	38
.constant	k35	146
.constant	k36	84
.constant	k37	172
.constant	k38	233
.constant	k39	215
.constant	k40	0
.constant	k41	13
.constant	k42	223
.constant	k43	42
.constant	k44	"BP_ENUM_MODULE_SUPPLY"

.line	229	getupval      r1    u0
.line	229	getupval      r2    u1
.line	229	loadk         r3    k0 ; k0 = 3
.line	229	loadk         r4    k1 ; k1 = 151
.line	229	loadk         r5    k2 ; k2 = 40
.line	229	loadk         r6    k3 ; k3 = 196
.line	229	loadk         r7    k4 ; k4 = 220
.line	229	loadk         r8    k5 ; k5 = 33
.line	229	loadk         r9    k6 ; k6 = 200
.line	229	loadk        r10    k7 ; k7 = 94
.line	229	loadk        r11    k8 ; k8 = 140
.line	229	loadk        r12    k9 ; k9 = 226
.line	229	loadk        r13   k10 ; k10 = 206
.line	229	loadk        r14    k0 ; k0 = 3
.line	229	loadk        r15   k11 ; k11 = 91
.line	229	loadk        r16   k12 ; k12 = 30
.line	229	loadk        r17   k13 ; k13 = 112
.line	229	loadk        r18   k14 ; k14 = 208
.line	229	loadk        r19   k15 ; k15 = 249
.line	229	loadk        r20   k16 ; k16 = 164
.line	229	call          r2    19     2
.line	229	call          r1     2     2
.line	229	getupval      r2    u0
.line	229	getupval      r3    u1
.line	229	loadk         r4    k0 ; k0 = 3
.line	229	loadk         r5    k1 ; k1 = 151
.line	229	loadk         r6    k2 ; k2 = 40
.line	229	loadk         r7    k3 ; k3 = 196
.line	229	loadk         r8    k4 ; k4 = 220
.line	229	loadk         r9    k5 ; k5 = 33
.line	229	loadk        r10    k6 ; k6 = 200
.line	229	loadk        r11   k17 ; k17 = 89
.line	229	loadk        r12   k18 ; k18 = 153
.line	229	loadk        r13   k19 ; k19 = 242
.line	229	loadk        r14   k20 ; k20 = 203
.line	229	loadk        r15   k21 ; k21 = 8
.line	229	loadk        r16   k22 ; k22 = 99
.line	229	loadk        r17   k23 ; k23 = 52
.line	229	loadk        r18   k24 ; k24 = 113
.line	229	loadk        r19   k25 ; k25 = 205
.line	229	loadk        r20   k26 ; k26 = 252
.line	229	call          r3    18     2
.line	229	call          r2     2     2
.line	229	gettable      r3    r2   k27 ; k27 = "GetTableValue"
.line	229	gettable      r4    r1   k28 ; k28 = "ParseURLParams"
.line	229	move          r5    r0
.line	229	call          r4     2     2
.line	229	getupval      r5    u1
.line	229	loadk         r6   k29 ; k29 = 1
.line	229	loadk         r7   k30 ; k30 = 155
.line	229	loadk         r8   k31 ; k31 = 49
.line	229	loadk         r9   k32 ; k32 = 192
.line	229	loadk        r10   k33 ; k33 = 197
.line	229	loadk        r11   k34 ; k34 = 38
.line	229	loadk        r12   k35 ; k35 = 146
.line	229	loadk        r13   k36 ; k36 = 84
.line	229	loadk        r14   k37 ; k37 = 172
.line	229	loadk        r15   k38 ; k38 = 233
.line	229	loadk        r16   k39 ; k39 = 215
.line	229	loadk        r17   k21 ; k21 = 8
.line	229	call          r5    13     2
.line	229	call          r3     3     2
.line	229	test          r3     1
.line	229	jmp            0   l66
.line	229	loadk         r3   k40 ; k40 = 0
.label	l66
.line	229	gettable      r4    r2   k27 ; k27 = "GetTableValue"
.line	229	gettable      r5    r1   k28 ; k28 = "ParseURLParams"
.line	229	move          r6    r0
.line	229	call          r5     2     2
.line	229	getupval      r6    u1
.line	229	loadk         r7   k41 ; k41 = 13
.line	229	loadk         r8    k1 ; k1 = 151
.line	229	loadk         r9    k5 ; k5 = 33
.line	229	loadk        r10    k4 ; k4 = 220
.line	229	loadk        r11   k42 ; k42 = 223
.line	229	loadk        r12   k43 ; k43 = 42
.line	229	call          r6     7     2
.line	229	call          r4     3     2
.line	229	test          r4     1
.line	229	jmp            0   l82
.line	229	loadk         r4   k40 ; k40 = 0
.label	l82
.line	229	getupval      r5    u2
.line	229	move          r6    r4
.line	229	call          r5     2     2
.line	229	gettabup      r6    u3   k44 ; k44 = "BP_ENUM_MODULE_SUPPL" (truncated)
.line	229	eq             1    r5    r6
.line	229	jmp            0   l90
.line	229	loadk         r5   k40 ; k40 = 0
.line	229	return        r5     2
.label	l90
.line	229	getupval      r5    u2
.line	229	move          r6    r3
.line	229	tailcall      r5     2
.line	229	return        r5     0
.line	229	return        r0     1
.line	229	move          r0    r0
.line	229	move          r0    r0
.line	229	move          r0    r0
.line	229	return        r0     1

.function	main/f10

.source	null
.linedefined	240
.lastlinedefined	243
.numparams	0
.is_vararg	0
.maxstacksize	25

.upvalue	"_ENV"	25	true
.upvalue	"U1"	1	true

.constant	k0	3
.constant	k1	148
.constant	k2	44
.constant	k3	204
.constant	k4	221
.constant	k5	59
.constant	k6	200
.constant	k7	78
.constant	k8	151
.constant	k9	253
.constant	k10	202
.constant	k11	2
.constant	k12	82
.constant	k13	111
.constant	k14	113
.constant	k15	205
.constant	k16	173
.constant	k17	106
.constant	k18	236
.constant	k19	55
.constant	k20	22
.constant	k21	250
.constant	k22	"GetServerTimeInSec"

.line	240	getupval      r0    u0
.line	240	getupval      r1    u1
.line	240	loadk         r2    k0 ; k0 = 3
.line	240	loadk         r3    k1 ; k1 = 148
.line	240	loadk         r4    k2 ; k2 = 44
.line	240	loadk         r5    k3 ; k3 = 204
.line	240	loadk         r6    k4 ; k4 = 221
.line	240	loadk         r7    k5 ; k5 = 59
.line	240	loadk         r8    k6 ; k6 = 200
.line	240	loadk         r9    k7 ; k7 = 78
.line	240	loadk        r10    k8 ; k8 = 151
.line	240	loadk        r11    k9 ; k9 = 253
.line	240	loadk        r12   k10 ; k10 = 202
.line	240	loadk        r13   k11 ; k11 = 2
.line	240	loadk        r14   k12 ; k12 = 82
.line	240	loadk        r15   k13 ; k13 = 111
.line	240	loadk        r16   k14 ; k14 = 113
.line	240	loadk        r17   k15 ; k15 = 205
.line	240	loadk        r18    k9 ; k9 = 253
.line	240	loadk        r19   k16 ; k16 = 173
.line	240	loadk        r20   k17 ; k17 = 106
.line	240	loadk        r21   k18 ; k18 = 236
.line	240	loadk        r22   k19 ; k19 = 55
.line	240	loadk        r23   k20 ; k20 = 22
.line	240	loadk        r24   k21 ; k21 = 250
.line	240	call          r1    24     2
.line	240	call          r0     2     2
.line	240	gettable      r1    r0   k22 ; k22 = "GetServerTimeInSec"
.line	240	tailcall      r1     1
.line	240	return        r1     0
.line	240	return        r0     1
.line	240	move          r0    r0
.line	240	move          r0    r0
.line	240	move          r0    r0
.line	240	return        r0     1

.function	main/f11

.source	null
.linedefined	245
.lastlinedefined	250
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	nil
.constant	k1	0

.line	245	eq             0    r0    k0 ; k0 = nil
.line	245	jmp            0    l5
.line	245	loadk         r1    k1 ; k1 = 0
.line	245	return        r1     2
.label	l5
.line	245	return        r0     2
.line	245	return        r0     1
.line	245	move          r0    r0
.line	245	move          r0    r0
.line	245	move          r0    r0
.line	245	move          r0    r0
.line	245	return        r0     1

.function	main/f12

.source	null
.linedefined	252
.lastlinedefined	295
.numparams	1
.is_vararg	1
.maxstacksize	16

.upvalue	"_ENV"	0	false
.upvalue	"U1"	31	true
.upvalue	"U2"	22	true
.upvalue	"U3"	1	true
.upvalue	"U4"	12	true
.upvalue	"U5"	8	true
.upvalue	"U6"	5	true
.upvalue	"U7"	26	true
.upvalue	"U8"	19	true

.constant	k0	"bWriteLog"
.constant	k1	19
.constant	k2	140
.constant	k3	55
.constant	k4	192
.constant	k5	221
.constant	k6	40
.constant	k7	"debug"
.constant	k8	"getinfo"
.constant	k9	2
.constant	k10	"name"
.constant	k11	"short_src"
.constant	k12	"reverse"
.constant	k13	"find"
.constant	k14	79
.constant	k15	0
.constant	k16	60
.constant	k17	78
.constant	k18	148
.constant	k19	48
.constant	k20	200
.constant	k21	-4
.constant	k22	3
.constant	k23	1
.constant	k24	-5
.constant	k25	69
.constant	k26	139
.constant	k27	127
.constant	k28	99
.constant	k29	198
.constant	k30	67

.line	252	gettabup      r1    u0    k0 ; k0 = "bWriteLog"
.line	252	test          r1     1
.line	252	jmp            0    l5
.line	252	return        r0     1
.label	l5
.line	252	getupval      r1    u1
.line	252	test          r1     1
.line	252	jmp            0    l9
.line	252	return        r0     1
.label	l9
.line	252	loadbool      r1     1     0
.line	252	getupval      r2    u2
.line	252	move          r3    r0
.line	252	call          r2     2     2
.line	252	getupval      r3    u3
.line	252	loadk         r4    k1 ; k1 = 19
.line	252	loadk         r5    k2 ; k2 = 140
.line	252	loadk         r6    k3 ; k3 = 55
.line	252	loadk         r7    k4 ; k4 = 192
.line	252	loadk         r8    k5 ; k5 = 221
.line	252	loadk         r9    k6 ; k6 = 40
.line	252	call          r3     7     2
.line	252	eq             1    r2    r3
.line	252	jmp            0   l24
.line	252	loadbool      r1     0     0
.label	l24
.line	252	gettabup      r2    u0    k7 ; k7 = "debug"
.line	252	gettable      r2    r2    k8 ; k8 = "getinfo"
.line	252	loadk         r3    k9 ; k9 = 2
.line	252	call          r2     2     2
.line	252	test          r2     1
.line	252	jmp            0   l31
.line	252	return        r0     1
.label	l31
.line	252	getupval      r3    u3
.line	252	call          r3     1     2
.line	252	getupval      r4    u3
.line	252	call          r4     1     2
.line	252	getupval      r5    u2
.line	252	gettable      r6    r2   k10 ; k10 = "name"
.line	252	call          r5     2     2
.line	252	getupval      r6    u3
.line	252	loadk         r7    k1 ; k1 = 19
.line	252	loadk         r8    k2 ; k2 = 140
.line	252	loadk         r9    k3 ; k3 = 55
.line	252	loadk        r10    k4 ; k4 = 192
.line	252	loadk        r11    k5 ; k5 = 221
.line	252	loadk        r12    k6 ; k6 = 40
.line	252	call          r6     7     2
.line	252	eq             0    r5    r6
.line	252	jmp            0   l49
.line	252	gettable      r4    r2   k10 ; k10 = "name"
.label	l49
.line	252	getupval      r5    u2
.line	252	gettable      r6    r2   k11 ; k11 = "short_src"
.line	252	call          r5     2     2
.line	252	getupval      r6    u3
.line	252	loadk         r7    k1 ; k1 = 19
.line	252	loadk         r8    k2 ; k2 = 140
.line	252	loadk         r9    k3 ; k3 = 55
.line	252	loadk        r10    k4 ; k4 = 192
.line	252	loadk        r11    k5 ; k5 = 221
.line	252	loadk        r12    k6 ; k6 = 40
.line	252	call          r6     7     2
.line	252	eq             0    r5    r6
.line	252	jmp            0  l113
.line	252	gettable      r3    r2   k11 ; k11 = "short_src"
.line	252	self          r5    r3   k12 ; k12 = "reverse"
.line	252	call          r5     2     2
.line	252	self          r6    r5   k13 ; k13 = "find"
.line	252	getupval      r8    u3
.line	252	loadk         r9   k14 ; k14 = 79
.line	252	call          r8     2     2
.line	252	call          r6     3     2
.line	252	test          r6     1
.line	252	jmp            0   l73
.line	252	loadk         r6   k15 ; k15 = 0
.label	l73
.line	252	self          r7    r5   k13 ; k13 = "find"
.line	252	getupval      r9    u3
.line	252	loadk        r10   k16 ; k16 = 60
.line	252	call          r9     2     2
.line	252	call          r7     3     2
.line	252	test          r7     1
.line	252	jmp            0   l81
.line	252	loadk         r7   k15 ; k15 = 0
.label	l81
.line	252	getupval      r8    u4
.line	252	move          r9    r6
.line	252	move         r10    r7
.line	252	call          r8     3     2
.line	252	lt             0   k15    r8 ; k15 = 0
.line	252	jmp            0   l94
.line	252	getupval      r9    u5
.line	252	move         r10    r3
.line	252	len          r11    r3
.line	252	sub          r11   r11    r8
.line	252	add          r11   r11    k9 ; k9 = 2
.line	252	call          r9     3     2
.line	252	move          r3    r9
.label	l94
.line	252	self          r9    r3   k13 ; k13 = "find"
.line	252	getupval     r11    u3
.line	252	loadk        r12   k17 ; k17 = 78
.line	252	loadk        r13   k18 ; k18 = 148
.line	252	loadk        r14   k19 ; k19 = 48
.line	252	loadk        r15   k20 ; k20 = 200
.line	252	call         r11     5     2
.line	252	loadk        r12   k21 ; k21 = -4
.line	252	call          r9     4     2
.line	252	len          r10    r3
.line	252	sub          r10   r10   k22 ; k22 = 3
.line	252	eq             0    r9   r10
.line	252	jmp            0  l113
.line	252	getupval      r9    u5
.line	252	move         r10    r3
.line	252	loadk        r11   k23 ; k23 = 1
.line	252	loadk        r12   k24 ; k24 = -5
.line	252	call          r9     4     2
.line	252	move          r3    r9
.label	l113
.line	252	getupval      r5    u6
.line	252	getupval      r6    u3
.line	252	loadk         r7   k25 ; k25 = 69
.line	252	loadk         r8   k26 ; k26 = 139
.line	252	loadk         r9   k27 ; k27 = 127
.line	252	loadk        r10    k2 ; k2 = 140
.line	252	loadk        r11    k4 ; k4 = 192
.line	252	loadk        r12   k28 ; k28 = 99
.line	252	loadk        r13   k29 ; k29 = 198
.line	252	call          r6     8     2
.line	252	move          r7    r3
.line	252	move          r8    r4
.line	252	call          r5     4     2
.line	252	test          r1     1
.line	252	jmp            0  l135
.line	252	getupval      r6    u7
.line	252	gettabup      r7    u0    k0 ; k0 = "bWriteLog"
.line	252	test          r7     0
.line	252	jmp            0  l133
.line	252	move          r7    r5
.label	l133
.line	252	call          r6     2     1
.line	252	return        r0     1
.label	l135
.line	252	move          r6    r5
.line	252	move          r7    r0
.line	252	concat        r0    r6    r7
.line	252	getupval      r6    u8
.line	252	getupval      r7    u3
.line	252	loadk         r8   k30 ; k30 = 67
.line	252	call          r7     2     2
.line	252	vararg        r8     0
.line	252	call          r6     0     2
.line	252	lt             0   k15    r6 ; k15 = 0
.line	252	jmp            0  l151
.line	252	getupval      r6    u6
.line	252	move          r7    r0
.line	252	vararg        r8     0
.line	252	call          r6     0     2
.line	252	move          r0    r6
.label	l151
.line	252	getupval      r6    u7
.line	252	gettabup      r7    u0    k0 ; k0 = "bWriteLog"
.line	252	test          r7     0
.line	252	jmp            0  l156
.line	252	move          r7    r0
.label	l156
.line	252	call          r6     2     1
.line	252	return        r0     1
.line	252	move          r0    r0
.line	252	move          r0    r0
.line	252	move          r0    r0
.line	252	return        r0     1

.function	main/f13

.source	null
.linedefined	297
.lastlinedefined	312
.numparams	1
.is_vararg	1
.maxstacksize	14

.upvalue	"_ENV"	7	true
.upvalue	"U1"	1	true
.upvalue	"U2"	21	true
.upvalue	"U3"	6	true
.upvalue	"U4"	24	true
.upvalue	"U5"	5	true

.constant	k0	27
.constant	k1	200
.constant	k2	56
.constant	k3	1
.constant	k4	29

.line	297	getupval      r1    u0
.line	297	move          r2    r0
.line	297	getupval      r3    u1
.line	297	loadk         r4    k0 ; k0 = 27
.line	297	loadk         r5    k1 ; k1 = 200
.line	297	loadk         r6    k2 ; k2 = 56
.line	297	call          r3     4     2
.line	297	call          r1     3     2
.line	297	getupval      r2    u1
.line	297	call          r2     1     2
.line	297	test          r1     0
.line	297	jmp            0   l39
.line	297	move          r2    r0
.line	297	getupval      r3    u2
.line	297	newtable      r4     0     0
.line	297	vararg        r5     0
.line	297	setlist       r4     0     1
.line	297	call          r3     2     4
.line	297	jmp            0   l36
.line	297	getupval      r8    u1
.line	297	loadk         r9    k0 ; k0 = 27
.line	297	call          r8     2     2
.line	297	sub           r9    r6    k3 ; k3 = 1
.line	297	getupval     r10    u1
.line	297	loadk        r11    k4 ; k4 = 29
.line	297	call         r10     2     2
.line	297	concat        r8    r8   r10
.line	297	getupval      r9    u3
.line	297	move         r10    r2
.line	297	move         r11    r8
.line	297	getupval     r12    u4
.line	297	move         r13    r7
.line	297	call         r12     2     0
.line	297	call          r9     0     2
.line	297	move          r2    r9
.label	l36
.line	297	move          r0    r0
.line	297	move          r0    r0
.line	297	jmp            0   l44
.label	l39
.line	297	getupval      r3    u5
.line	297	move          r4    r0
.line	297	vararg        r5     0
.line	297	call          r3     0     2
.line	297	move          r2    r3
.label	l44
.line	297	return        r2     2
.line	297	return        r0     1
.line	297	move          r0    r0
.line	297	move          r0    r0
.line	297	move          r0    r0
.line	297	return        r0     1

.function	main/f14

.source	null
.linedefined	314
.lastlinedefined	320
.numparams	2
.is_vararg	1
.maxstacksize	21

.upvalue	"_ENV"	25	true
.upvalue	"U1"	1	true
.upvalue	"U2"	22	true

.constant	k0	3
.constant	k1	151
.constant	k2	40
.constant	k3	196
.constant	k4	220
.constant	k5	33
.constant	k6	200
.constant	k7	89
.constant	k8	153
.constant	k9	242
.constant	k10	203
.constant	k11	8
.constant	k12	99
.constant	k13	52
.constant	k14	113
.constant	k15	205
.constant	k16	252
.constant	k17	"GetTableValue"
.constant	k18	6
.constant	k19	141
.constant	k20	43
.constant	k21	202
.constant	k22	199
.constant	k23	38
.constant	k24	137
.constant	k25	67

.line	314	getupval      r2    u0
.line	314	getupval      r3    u1
.line	314	loadk         r4    k0 ; k0 = 3
.line	314	loadk         r5    k1 ; k1 = 151
.line	314	loadk         r6    k2 ; k2 = 40
.line	314	loadk         r7    k3 ; k3 = 196
.line	314	loadk         r8    k4 ; k4 = 220
.line	314	loadk         r9    k5 ; k5 = 33
.line	314	loadk        r10    k6 ; k6 = 200
.line	314	loadk        r11    k7 ; k7 = 89
.line	314	loadk        r12    k8 ; k8 = 153
.line	314	loadk        r13    k9 ; k9 = 242
.line	314	loadk        r14   k10 ; k10 = 203
.line	314	loadk        r15   k11 ; k11 = 8
.line	314	loadk        r16   k12 ; k12 = 99
.line	314	loadk        r17   k13 ; k13 = 52
.line	314	loadk        r18   k14 ; k14 = 113
.line	314	loadk        r19   k15 ; k15 = 205
.line	314	loadk        r20   k16 ; k16 = 252
.line	314	call          r3    18     2
.line	314	call          r2     2     2
.line	314	gettable      r3    r2   k17 ; k17 = "GetTableValue"
.line	314	move          r4    r0
.line	314	move          r5    r1
.line	314	call          r3     3     2
.line	314	getupval      r4    u2
.line	314	move          r5    r3
.line	314	call          r4     2     2
.line	314	getupval      r5    u1
.line	314	loadk         r6   k18 ; k18 = 6
.line	314	loadk         r7   k19 ; k19 = 141
.line	314	loadk         r8   k20 ; k20 = 43
.line	314	loadk         r9   k21 ; k21 = 202
.line	314	loadk        r10   k22 ; k22 = 199
.line	314	loadk        r11   k23 ; k23 = 38
.line	314	loadk        r12   k24 ; k24 = 137
.line	314	loadk        r13   k25 ; k25 = 67
.line	314	call          r5     9     2
.line	314	eq             0    r4    r5
.line	314	jmp            0   l45
.line	314	move          r4    r3
.line	314	vararg        r5     0
.line	314	tailcall      r4     0
.line	314	return        r4     0
.label	l45
.line	314	return        r0     1
.line	314	move          r0    r0
.line	314	move          r0    r0
.line	314	return        r0     1

.function	main/f15

.source	null
.linedefined	322
.lastlinedefined	328
.numparams	2
.is_vararg	0
.maxstacksize	35

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	0
.constant	k1	"FuncUtil"
.constant	k2	"BitCount"
.constant	k3	"log_error"
.constant	k4	38
.constant	k5	141
.constant	k6	43
.constant	k7	202
.constant	k8	230
.constant	k9	59
.constant	k10	143
.constant	k11	65
.constant	k12	214
.constant	k13	221
.constant	k14	198
.constant	k15	31
.constant	k16	87
.constant	k17	3
.constant	k18	108
.constant	k19	208
.constant	k20	176
.constant	k21	161
.constant	k22	91
.constant	k23	253
.constant	k24	7
.constant	k25	182
.constant	k26	116
.constant	k27	134
.constant	k28	246
.constant	k29	17
.constant	k30	69
.constant	k31	53
.constant	k32	true

.line	322	le             1    r1    k0 ; k0 = 0
.line	322	jmp            0    l7
.line	322	gettabup      r2    u0    k1 ; k1 = "FuncUtil"
.line	322	gettable      r2    r2    k2 ; k2 = "BitCount"
.line	322	lt             0    r2    r1
.line	322	jmp            0   l45
.label	l7
.line	322	gettabup      r2    u0    k3 ; k3 = "log_error"
.line	322	getupval      r3    u1
.line	322	loadk         r4    k4 ; k4 = 38
.line	322	loadk         r5    k5 ; k5 = 141
.line	322	loadk         r6    k6 ; k6 = 43
.line	322	loadk         r7    k7 ; k7 = 202
.line	322	loadk         r8    k8 ; k8 = 230
.line	322	loadk         r9    k9 ; k9 = 59
.line	322	loadk        r10   k10 ; k10 = 143
.line	322	loadk        r11   k11 ; k11 = 65
.line	322	loadk        r12   k12 ; k12 = 214
.line	322	loadk        r13   k13 ; k13 = 221
.line	322	loadk        r14   k14 ; k14 = 198
.line	322	loadk        r15   k15 ; k15 = 31
.line	322	loadk        r16   k16 ; k16 = 87
.line	322	loadk        r17   k17 ; k17 = 3
.line	322	loadk        r18   k18 ; k18 = 108
.line	322	loadk        r19   k19 ; k19 = 208
.line	322	loadk        r20   k20 ; k20 = 176
.line	322	loadk        r21   k21 ; k21 = 161
.line	322	loadk        r22   k22 ; k22 = 91
.line	322	loadk        r23   k23 ; k23 = 253
.line	322	loadk        r24    k4 ; k4 = 38
.line	322	loadk        r25   k24 ; k24 = 7
.line	322	loadk        r26   k25 ; k25 = 182
.line	322	loadk        r27   k26 ; k26 = 116
.line	322	loadk        r28   k27 ; k27 = 134
.line	322	loadk        r29   k28 ; k28 = 246
.line	322	loadk        r30   k12 ; k12 = 214
.line	322	loadk        r31   k29 ; k29 = 17
.line	322	loadk        r32   k30 ; k30 = 69
.line	322	loadk        r33   k31 ; k31 = 53
.line	322	loadk        r34   k31 ; k31 = 53
.line	322	call          r3    32     2
.line	322	move          r4    r1
.line	322	concat        r3    r3    r4
.line	322	call          r2     2     1
.line	322	return        r0     1
.label	l45
.line	322	settable      r0    r1   k32 ; k32 = true
.line	322	return        r0     1
.line	322	move          r0    r0
.line	322	move          r0    r0
.line	322	move          r0    r0
.line	322	return        r0     1

.function	main/f16

.source	null
.linedefined	330
.lastlinedefined	336
.numparams	2
.is_vararg	0
.maxstacksize	37

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	0
.constant	k1	"FuncUtil"
.constant	k2	"BitCount"
.constant	k3	"log_error"
.constant	k4	38
.constant	k5	141
.constant	k6	43
.constant	k7	202
.constant	k8	230
.constant	k9	59
.constant	k10	143
.constant	k11	65
.constant	k12	214
.constant	k13	197
.constant	k14	201
.constant	k15	93
.constant	k16	51
.constant	k17	110
.constant	k18	249
.constant	k19	188
.constant	k20	21
.constant	k21	240
.constant	k22	45
.constant	k23	27
.constant	k24	243
.constant	k25	101
.constant	k26	200
.constant	k27	233
.constant	k28	217
.constant	k29	11
.constant	k30	77
.constant	k31	61
.constant	k32	124
.constant	k33	208
.constant	k34	160
.constant	k35	false

.line	330	le             1    r1    k0 ; k0 = 0
.line	330	jmp            0    l7
.line	330	gettabup      r2    u0    k1 ; k1 = "FuncUtil"
.line	330	gettable      r2    r2    k2 ; k2 = "BitCount"
.line	330	lt             0    r2    r1
.line	330	jmp            0   l47
.label	l7
.line	330	gettabup      r2    u0    k3 ; k3 = "log_error"
.line	330	getupval      r3    u1
.line	330	loadk         r4    k4 ; k4 = 38
.line	330	loadk         r5    k5 ; k5 = 141
.line	330	loadk         r6    k6 ; k6 = 43
.line	330	loadk         r7    k7 ; k7 = 202
.line	330	loadk         r8    k8 ; k8 = 230
.line	330	loadk         r9    k9 ; k9 = 59
.line	330	loadk        r10   k10 ; k10 = 143
.line	330	loadk        r11   k11 ; k11 = 65
.line	330	loadk        r12   k12 ; k12 = 214
.line	330	loadk        r13   k13 ; k13 = 197
.line	330	loadk        r14   k14 ; k14 = 201
.line	330	loadk        r15    k0 ; k0 = 0
.line	330	loadk        r16   k15 ; k15 = 93
.line	330	loadk        r17   k16 ; k16 = 51
.line	330	loadk        r18   k17 ; k17 = 110
.line	330	loadk        r19    k8 ; k8 = 230
.line	330	loadk        r20   k18 ; k18 = 249
.line	330	loadk        r21   k19 ; k19 = 188
.line	330	loadk        r22   k20 ; k20 = 21
.line	330	loadk        r23   k21 ; k21 = 240
.line	330	loadk        r24   k22 ; k22 = 45
.line	330	loadk        r25   k23 ; k23 = 27
.line	330	loadk        r26   k24 ; k24 = 243
.line	330	loadk        r27   k25 ; k25 = 101
.line	330	loadk        r28   k26 ; k26 = 200
.line	330	loadk        r29   k27 ; k27 = 233
.line	330	loadk        r30   k28 ; k28 = 217
.line	330	loadk        r31   k29 ; k29 = 11
.line	330	loadk        r32   k30 ; k30 = 77
.line	330	loadk        r33   k31 ; k31 = 61
.line	330	loadk        r34   k32 ; k32 = 124
.line	330	loadk        r35   k33 ; k33 = 208
.line	330	loadk        r36   k34 ; k34 = 160
.line	330	call          r3    34     2
.line	330	move          r4    r1
.line	330	concat        r3    r3    r4
.line	330	call          r2     2     1
.line	330	return        r0     1
.label	l47
.line	330	settable      r0    r1   k35 ; k35 = false
.line	330	return        r0     1
.line	330	move          r0    r0
.line	330	return        r0     1

.function	main/f17

.source	null
.linedefined	338
.lastlinedefined	352
.numparams	1
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false

.constant	k0	0
.constant	k1	1
.constant	k2	"FuncUtil"
.constant	k3	"BitCount"
.constant	k4	"BitValues"
.constant	k5	nil
.constant	k6	2

.line	338	loadk         r1    k0 ; k0 = 0
.line	338	loadk         r2    k0 ; k0 = 0
.line	338	loadk         r3    k1 ; k1 = 1
.line	338	gettabup      r4    u0    k2 ; k2 = "FuncUtil"
.line	338	gettable      r4    r4    k3 ; k3 = "BitCount"
.line	338	loadk         r5    k1 ; k1 = 1
.line	338	move          r0    r0
.line	338	gettable      r7    r0    r6
.line	338	test          r7     0
.line	338	jmp            0   l22
.line	338	gettabup      r7    u0    k2 ; k2 = "FuncUtil"
.line	338	gettable      r7    r7    k4 ; k4 = "BitValues"
.line	338	gettable      r2    r7    r6
.line	338	eq             0    r2    k5 ; k5 = nil
.line	338	jmp            0   l21
.line	338	sub           r7    r6    k1 ; k1 = 1
.line	338	pow           r2    k6    r7 ; k6 = 2
.line	338	gettabup      r7    u0    k2 ; k2 = "FuncUtil"
.line	338	gettable      r7    r7    k4 ; k4 = "BitValues"
.line	338	settable      r7    r6    r2
.label	l21
.line	338	add           r1    r1    r2
.label	l22
.line	338	move          r0    r0
.line	338	return        r1     2
.line	338	return        r0     1
.line	338	move          r0    r0
.line	338	move          r0    r0
.line	338	move          r0    r0
.line	338	return        r0     1

.function	main/f18

.source	null
.linedefined	354
.lastlinedefined	364
.numparams	1
.is_vararg	0
.maxstacksize	13

.upvalue	"_ENV"	21	true
.upvalue	"U1"	12	true

.constant	k0	-1
.constant	k1	1
.constant	k2	0
.constant	k3	4
.constant	k4	2
.constant	k5	5
.constant	k6	3
.constant	k7	6

.line	354	loadk         r1    k0 ; k0 = -1
.line	354	loadk         r2    k0 ; k0 = -1
.line	354	loadk         r3    k0 ; k0 = -1
.line	354	getupval      r4    u0
.line	354	move          r5    r0
.line	354	call          r4     2     4
.line	354	jmp            0   l50
.line	354	getupval      r9    u1
.line	354	move         r10    r1
.line	354	gettable     r11    r0    r7
.line	354	gettable     r11   r11    k1 ; k1 = 1
.line	354	test         r11     1
.line	354	jmp            0   l15
.line	354	loadk        r11    k2 ; k2 = 0
.label	l15
.line	354	gettable     r12    r0    r7
.line	354	gettable     r12   r12    k3 ; k3 = 4
.line	354	test         r12     1
.line	354	jmp            0   l20
.line	354	loadk        r12    k2 ; k2 = 0
.label	l20
.line	354	call          r9     4     2
.line	354	move          r1    r9
.line	354	getupval      r9    u1
.line	354	move         r10    r2
.line	354	gettable     r11    r0    r7
.line	354	gettable     r11   r11    k4 ; k4 = 2
.line	354	test         r11     1
.line	354	jmp            0   l29
.line	354	loadk        r11    k2 ; k2 = 0
.label	l29
.line	354	gettable     r12    r0    r7
.line	354	gettable     r12   r12    k5 ; k5 = 5
.line	354	test         r12     1
.line	354	jmp            0   l34
.line	354	loadk        r12    k2 ; k2 = 0
.label	l34
.line	354	call          r9     4     2
.line	354	move          r2    r9
.line	354	getupval      r9    u1
.line	354	move         r10    r3
.line	354	gettable     r11    r0    r7
.line	354	gettable     r11   r11    k6 ; k6 = 3
.line	354	test         r11     1
.line	354	jmp            0   l43
.line	354	loadk        r11    k2 ; k2 = 0
.label	l43
.line	354	gettable     r12    r0    r7
.line	354	gettable     r12   r12    k7 ; k7 = 6
.line	354	test         r12     1
.line	354	jmp            0   l48
.line	354	loadk        r12    k2 ; k2 = 0
.label	l48
.line	354	call          r9     4     2
.line	354	move          r3    r9
.label	l50
.line	354	move          r0    r0
.line	354	move          r0    r0
.line	354	move          r4    r1
.line	354	move          r5    r2
.line	354	move          r6    r3
.line	354	return        r4     4
.line	354	return        r0     1
.line	354	move          r0    r0
.line	354	move          r0    r0
.line	354	move          r0    r0
.line	354	move          r0    r0
.line	354	return        r0     1

.function	main/f19

.source	null
.linedefined	366
.lastlinedefined	386
.numparams	1
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	2	true
.upvalue	"U1"	0	false
.upvalue	"U2"	12	true

.constant	k0	-1
.constant	k1	"IsBlueholeOperationRegion"
.constant	k2	3
.constant	k3	"ModuleManager"
.constant	k4	"GetModule"
.constant	k5	"CommonModuleConfig"
.constant	k6	"logic_multiple_area"
.constant	k7	"IsConnectToRussiaArea"
.constant	k8	2
.constant	k9	"FuncUtil"
.constant	k10	"GetMaxSegement"

.line	366	loadk         r1    k0 ; k0 = -1
.line	366	loadk         r2    k0 ; k0 = -1
.line	366	loadk         r3    k0 ; k0 = -1
.line	366	gettabup      r4    u0    k1 ; k1 = "IsBlueholeOperationR" (truncated)
.line	366	call          r4     1     2
.line	366	test          r4     0
.line	366	jmp            0   l13
.line	366	newtable      r4     0     1
.line	366	gettable      r5    r0    k2 ; k2 = 3
.line	366	settable      r4    k2    r5 ; k2 = 3
.line	366	move          r0    r4
.line	366	jmp            0   l27
.label	l13
.line	366	gettabup      r4    u1    k3 ; k3 = "ModuleManager"
.line	366	gettable      r4    r4    k4 ; k4 = "GetModule"
.line	366	gettabup      r5    u1    k3 ; k3 = "ModuleManager"
.line	366	gettable      r5    r5    k5 ; k5 = "CommonModuleConfig"
.line	366	gettable      r5    r5    k6 ; k6 = "logic_multiple_area"
.line	366	call          r4     2     2
.line	366	self          r5    r4    k7 ; k7 = "IsConnectToRussiaAre" (truncated)
.line	366	call          r5     2     2
.line	366	test          r5     0
.line	366	jmp            0   l27
.line	366	newtable      r5     0     1
.line	366	gettable      r6    r0    k8 ; k8 = 2
.line	366	settable      r5    k8    r6 ; k8 = 2
.line	366	move          r0    r5
.label	l27
.line	366	test          r0     0
.line	366	jmp            0   l36
.line	366	gettabup      r4    u1    k9 ; k9 = "FuncUtil"
.line	366	gettable      r4    r4   k10 ; k10 = "GetMaxSegement"
.line	366	move          r5    r0
.line	366	call          r4     2     4
.line	366	move          r3    r6
.line	366	move          r2    r5
.line	366	move          r1    r4
.label	l36
.line	366	getupval      r4    u2
.line	366	move          r5    r1
.line	366	move          r6    r2
.line	366	move          r7    r3
.line	366	tailcall      r4     4
.line	366	return        r4     0
.line	366	return        r0     1
.line	366	move          r0    r0
.line	366	return        r0     1

.function	main/f20

.source	null
.linedefined	388
.lastlinedefined	438
.numparams	5
.is_vararg	0
.maxstacksize	53

.upvalue	"_ENV"	1	true
.upvalue	"U1"	27	true
.upvalue	"U2"	0	false
.upvalue	"U3"	24	true
.upvalue	"U4"	25	true

.constant	k0	0
.constant	k1	"GetTableData"
.constant	k2	33
.constant	k3	148
.constant	k4	44
.constant	k5	200
.constant	k6	192
.constant	k7	12
.constant	k8	128
.constant	k9	74
.constant	k10	"log"
.constant	k11	"bWriteLog"
.constant	k12	1
.constant	k13	111
.constant	k14	136
.constant	k15	66
.constant	k16	140
.constant	k17	176
.constant	k18	193
.constant	k19	2
.constant	k20	73
.constant	k21	47
.constant	k22	97
.constant	k23	161
.constant	k24	81
.constant	k25	163
.constant	k26	102
.constant	k27	182
.constant	k28	104
.constant	k29	129
.constant	k30	228
.constant	k31	141
.constant	k32	88
.constant	k33	95
.constant	k34	"AliasName"
.constant	k35	"AliasParam"
.constant	k36	38
.constant	k37	43
.constant	k38	202
.constant	k39	230
.constant	k40	59
.constant	k41	143
.constant	k42	65
.constant	k43	214
.constant	k44	215
.constant	k45	194
.constant	k46	3
.constant	k47	99
.constant	k48	53
.constant	k49	108
.constant	k50	208
.constant	k51	252
.constant	k52	173
.constant	k53	21
.constant	k54	248
.constant	k55	22
.constant	k56	247
.constant	k57	110
.constant	k58	184
.constant	k59	225
.constant	k60	197
.constant	k61	28
.constant	k62	113
.constant	k63	40
.constant	k64	100
.constant	k65	204
.constant	k66	221
.constant	k67	94
.constant	k68	229
.constant	k69	198
.constant	k70	67
.constant	k71	80
.constant	k72	46
.constant	k73	98
.constant	k74	205
.constant	k75	243
.constant	k76	89
.constant	k77	251
.constant	k78	48
.constant	k79	250
.constant	k80	114
.constant	k81	233
.constant	k82	212
.constant	k83	34
.constant	k84	64
.constant	k85	51
.constant	k86	"GetZoneName"
.constant	k87	"LocUtil"
.constant	k88	"LocalizeResFormatByStr"
.constant	k89	"AliasType"
.constant	k90	5
.constant	k91	78
.constant	k92	151
.constant	k93	253
.constant	k94	82
.constant	k95	112
.constant	k96	207
.constant	k97	189
.constant	k98	240
.constant	k99	"partner_name"
.constant	k100	"GetIntimacyRelationName"
.constant	k101	"partner_relation"
.constant	k102	6
.constant	k103	"psmatch_team_name"
.constant	k104	7
.constant	k105	"weapon_power_zone_id"
.constant	k106	"table"
.constant	k107	"concat"
.constant	k108	138
.constant	k109	195
.constant	k110	84
.constant	k111	234
.constant	k112	17
.constant	k113	201
.constant	k114	199
.constant	k115	18
.constant	k116	145
.constant	k117	246
.constant	k118	196
.constant	k119	42
.constant	k120	135
.constant	k121	93
.constant	k122	254
.constant	k123	25
.constant	k124	36
.constant	k125	107
.constant	k126	160
.constant	k127	106
.constant	k128	237
.constant	k129	16
.constant	k130	"GetWeaponStrengthZoneTitle"
.constant	k131	8
.constant	k132	"FuncUtil"
.constant	k133	"GetRegisterYear"
.constant	k134	"registertime"
.constant	k135	"math"
.constant	k136	"max"

.line	388	eq             0    r0    k0 ; k0 = 0
.line	388	jmp            0    l6
.line	388	getupval      r5    u0
.line	388	call          r5     1     2
.line	388	return        r5     2
.label	l6
.line	388	gettabup      r5    u1    k1 ; k1 = "GetTableData"
.line	388	getupval      r6    u0
.line	388	loadk         r7    k2 ; k2 = 33
.line	388	loadk         r8    k3 ; k3 = 148
.line	388	loadk         r9    k4 ; k4 = 44
.line	388	loadk        r10    k5 ; k5 = 200
.line	388	loadk        r11    k6 ; k6 = 192
.line	388	loadk        r12    k7 ; k7 = 12
.line	388	loadk        r13    k8 ; k8 = 128
.line	388	loadk        r14    k9 ; k9 = 74
.line	388	call          r6     9     2
.line	388	move          r7    r0
.line	388	call          r5     3     2
.line	388	test          r5     1
.line	388	jmp            0   l61
.line	388	gettabup      r6    u2   k10 ; k10 = "log"
.line	388	gettabup      r7    u2   k11 ; k11 = "bWriteLog"
.line	388	test          r7     0
.line	388	jmp            0   l56
.line	388	getupval      r7    u0
.line	388	loadk         r8   k12 ; k12 = 1
.line	388	loadk         r9    k3 ; k3 = 148
.line	388	loadk        r10    k4 ; k4 = 44
.line	388	loadk        r11    k5 ; k5 = 200
.line	388	loadk        r12    k6 ; k6 = 192
.line	388	loadk        r13   k13 ; k13 = 111
.line	388	loadk        r14   k14 ; k14 = 136
.line	388	loadk        r15   k15 ; k15 = 66
.line	388	loadk        r16   k16 ; k16 = 140
.line	388	loadk        r17   k17 ; k17 = 176
.line	388	loadk        r18   k18 ; k18 = 193
.line	388	loadk        r19   k19 ; k19 = 2
.line	388	loadk        r20   k20 ; k20 = 73
.line	388	loadk        r21   k21 ; k21 = 47
.line	388	loadk        r22   k22 ; k22 = 97
.line	388	loadk        r23   k14 ; k14 = 136
.line	388	loadk        r24   k17 ; k17 = 176
.line	388	loadk        r25   k23 ; k23 = 161
.line	388	loadk        r26   k24 ; k24 = 81
.line	388	loadk        r27   k25 ; k25 = 163
.line	388	loadk        r28   k26 ; k26 = 102
.line	388	loadk        r29    k7 ; k7 = 12
.line	388	loadk        r30   k27 ; k27 = 182
.line	388	loadk        r31   k28 ; k28 = 104
.line	388	loadk        r32   k29 ; k29 = 129
.line	388	loadk        r33   k30 ; k30 = 228
.line	388	loadk        r34   k31 ; k31 = 141
.line	388	loadk        r35   k32 ; k32 = 88
.line	388	loadk        r36   k33 ; k33 = 95
.line	388	call          r7    30     2
.label	l56
.line	388	move          r8    r0
.line	388	call          r6     3     1
.line	388	getupval      r6    u0
.line	388	call          r6     1     2
.line	388	return        r6     2
.label	l61
.line	388	gettable      r6    r5   k34 ; k34 = "AliasName"
.line	388	test          r1     1
.line	388	jmp            0   l65
.line	388	loadk         r1    k0 ; k0 = 0
.label	l65
.line	388	test          r3     1
.line	388	jmp            0   l68
.line	388	loadk         r3    k0 ; k0 = 0
.label	l68
.line	388	gettable      r7    r5   k35 ; k35 = "AliasParam"
.line	388	gettabup      r8    u2   k10 ; k10 = "log"
.line	388	gettabup      r9    u2   k11 ; k11 = "bWriteLog"
.line	388	test          r9     0
.line	388	jmp            0  l111
.line	388	getupval      r9    u0
.line	388	loadk        r10   k36 ; k36 = 38
.line	388	loadk        r11   k31 ; k31 = 141
.line	388	loadk        r12   k37 ; k37 = 43
.line	388	loadk        r13   k38 ; k38 = 202
.line	388	loadk        r14   k39 ; k39 = 230
.line	388	loadk        r15   k40 ; k40 = 59
.line	388	loadk        r16   k41 ; k41 = 143
.line	388	loadk        r17   k42 ; k42 = 65
.line	388	loadk        r18   k43 ; k43 = 214
.line	388	loadk        r19   k44 ; k44 = 215
.line	388	loadk        r20   k45 ; k45 = 194
.line	388	loadk        r21   k46 ; k46 = 3
.line	388	loadk        r22   k47 ; k47 = 99
.line	388	loadk        r23   k48 ; k48 = 53
.line	388	loadk        r24   k49 ; k49 = 108
.line	388	loadk        r25   k50 ; k50 = 208
.line	388	loadk        r26   k51 ; k51 = 252
.line	388	loadk        r27   k52 ; k52 = 173
.line	388	loadk        r28   k53 ; k53 = 21
.line	388	loadk        r29   k54 ; k54 = 248
.line	388	loadk        r30   k21 ; k21 = 47
.line	388	loadk        r31   k55 ; k55 = 22
.line	388	loadk        r32   k56 ; k56 = 247
.line	388	loadk        r33   k57 ; k57 = 110
.line	388	loadk        r34   k58 ; k58 = 184
.line	388	loadk        r35   k59 ; k59 = 225
.line	388	loadk        r36   k60 ; k60 = 197
.line	388	loadk        r37   k61 ; k61 = 28
.line	388	loadk        r38   k42 ; k42 = 65
.line	388	loadk        r39   k62 ; k62 = 113
.line	388	loadk        r40   k63 ; k63 = 40
.line	388	loadk        r41    k3 ; k3 = 148
.line	388	call          r9    33     2
.line	388	getupval     r10    u3
.line	388	move         r11    r7
.line	388	call         r10     2     2
.line	388	concat        r9    r9   r10
.label	l111
.line	388	call          r8     2     1
.line	388	test          r7     0
.line	388	jmp            0  l116
.line	388	eq             1    r7   k12 ; k12 = 1
.line	388	jmp            0  l120
.label	l116
.line	388	le             0    r1   k64 ; k64 = 100
.line	388	jmp            0  l182
.line	388	lt             0    k0    r1 ; k0 = 0
.line	388	jmp            0  l182
.label	l120
.line	388	lt             0    k0    r3 ; k0 = 0
.line	388	jmp            0  l176
.line	388	move          r8    r4
.line	388	test          r8     0
.line	388	jmp            0  l129
.line	388	getupval      r9    u0
.line	388	call          r9     1     2
.line	388	eq             0    r8    r9
.line	388	jmp            0  l168
.label	l129
.line	388	getupval      r9    u4
.line	388	getupval     r10    u0
.line	388	loadk        r11   k46 ; k46 = 3
.line	388	loadk        r12    k3 ; k3 = 148
.line	388	loadk        r13    k4 ; k4 = 44
.line	388	loadk        r14   k65 ; k65 = 204
.line	388	loadk        r15   k66 ; k66 = 221
.line	388	loadk        r16   k40 ; k40 = 59
.line	388	loadk        r17    k5 ; k5 = 200
.line	388	loadk        r18   k67 ; k67 = 94
.line	388	loadk        r19    k3 ; k3 = 148
.line	388	loadk        r20   k68 ; k68 = 229
.line	388	loadk        r21   k69 ; k69 = 198
.line	388	loadk        r22   k70 ; k70 = 67
.line	388	loadk        r23   k71 ; k71 = 80
.line	388	loadk        r24   k72 ; k72 = 46
.line	388	loadk        r25   k73 ; k73 = 98
.line	388	loadk        r26   k74 ; k74 = 205
.line	388	loadk        r27   k75 ; k75 = 243
.line	388	loadk        r28   k39 ; k39 = 230
.line	388	loadk        r29   k76 ; k76 = 89
.line	388	loadk        r30   k77 ; k77 = 251
.line	388	loadk        r31   k78 ; k78 = 48
.line	388	loadk        r32   k24 ; k24 = 81
.line	388	loadk        r33   k79 ; k79 = 250
.line	388	loadk        r34   k80 ; k80 = 114
.line	388	loadk        r35   k41 ; k41 = 143
.line	388	loadk        r36   k81 ; k81 = 233
.line	388	loadk        r37   k82 ; k82 = 212
.line	388	loadk        r38   k83 ; k83 = 34
.line	388	loadk        r39   k84 ; k84 = 64
.line	388	loadk        r40   k85 ; k85 = 51
.line	388	loadk        r41   k26 ; k26 = 102
.line	388	call         r10    32     2
.line	388	call          r9     2     2
.line	388	gettable     r10    r9   k86 ; k86 = "GetZoneName"
.line	388	move         r11    r3
.line	388	call         r10     2     2
.line	388	move          r8   r10
.label	l168
.line	388	gettabup      r9    u2   k87 ; k87 = "LocUtil"
.line	388	gettable      r9    r9   k88 ; k88 = "LocalizeResFormatByS" (truncated)
.line	388	move         r10    r6
.line	388	move         r11    r1
.line	388	move         r12    r8
.line	388	call          r9     4     2
.line	388	move          r6    r9
.line	388	jmp            0  l182
.label	l176
.line	388	gettabup      r8    u2   k87 ; k87 = "LocUtil"
.line	388	gettable      r8    r8   k88 ; k88 = "LocalizeResFormatByS" (truncated)
.line	388	move          r9    r6
.line	388	move         r10    r1
.line	388	call          r8     3     2
.line	388	move          r6    r8
.label	l182
.line	388	test          r2     0
.line	388	jmp            0  l228
.line	388	gettable      r8    r5   k89 ; k89 = "AliasType"
.line	388	eq             0    r8   k90 ; k90 = 5
.line	388	jmp            0  l228
.line	388	getupval      r8    u4
.line	388	getupval      r9    u0
.line	388	loadk        r10   k46 ; k46 = 3
.line	388	loadk        r11    k3 ; k3 = 148
.line	388	loadk        r12    k4 ; k4 = 44
.line	388	loadk        r13   k65 ; k65 = 204
.line	388	loadk        r14   k66 ; k66 = 221
.line	388	loadk        r15   k40 ; k40 = 59
.line	388	loadk        r16    k5 ; k5 = 200
.line	388	loadk        r17   k91 ; k91 = 78
.line	388	loadk        r18   k92 ; k92 = 151
.line	388	loadk        r19   k93 ; k93 = 253
.line	388	loadk        r20   k38 ; k38 = 202
.line	388	loadk        r21   k19 ; k19 = 2
.line	388	loadk        r22   k94 ; k94 = 82
.line	388	loadk        r23   k13 ; k13 = 111
.line	388	loadk        r24   k95 ; k95 = 112
.line	388	loadk        r25   k74 ; k74 = 205
.line	388	loadk        r26   k96 ; k96 = 207
.line	388	loadk        r27   k97 ; k97 = 189
.line	388	loadk        r28   k42 ; k42 = 65
.line	388	loadk        r29   k98 ; k98 = 240
.line	388	loadk        r30   k21 ; k21 = 47
.line	388	call          r9    22     2
.line	388	call          r8     2     2
.line	388	gettabup      r9    u2   k87 ; k87 = "LocUtil"
.line	388	gettable      r9    r9   k88 ; k88 = "LocalizeResFormatByS" (truncated)
.line	388	move         r10    r6
.line	388	gettable     r11    r2   k99 ; k99 = "partner_name"
.line	388	test         r11     1
.line	388	jmp            0  l220
.line	388	getupval     r11    u0
.line	388	call         r11     1     2
.label	l220
.line	388	gettable     r12    r8  k100 ; k100 = "GetIntimacyRelationN" (truncated)
.line	388	gettable     r13    r2  k101 ; k101 = "partner_relation"
.line	388	test         r13     1
.line	388	jmp            0  l225
.line	388	loadk        r13   k12 ; k12 = 1
.label	l225
.line	388	call         r12     2     0
.line	388	call          r9     0     2
.line	388	move          r6    r9
.label	l228
.line	388	test          r2     0
.line	388	jmp            0  l243
.line	388	gettable      r8    r5   k89 ; k89 = "AliasType"
.line	388	eq             0    r8  k102 ; k102 = 6
.line	388	jmp            0  l243
.line	388	gettabup      r8    u2   k87 ; k87 = "LocUtil"
.line	388	gettable      r8    r8   k88 ; k88 = "LocalizeResFormatByS" (truncated)
.line	388	move          r9    r6
.line	388	gettable     r10    r2  k103 ; k103 = "psmatch_team_name"
.line	388	test         r10     1
.line	388	jmp            0  l241
.line	388	getupval     r10    u0
.line	388	call         r10     1     2
.label	l241
.line	388	call          r8     3     2
.line	388	move          r6    r8
.label	l243
.line	388	gettable      r8    r5   k89 ; k89 = "AliasType"
.line	388	eq             0    r8  k104 ; k104 = 7
.line	388	jmp            0  l422
.line	388	getupval      r8    u0
.line	388	call          r8     1     2
.line	388	test          r2     0
.line	388	jmp            0  l332
.line	388	gettable      r9    r2  k105 ; k105 = "weapon_power_zone_id"
.line	388	test          r9     0
.line	388	jmp            0  l332
.line	388	getupval      r9    u4
.line	388	gettabup     r10    u2  k106 ; k106 = "table"
.line	388	gettable     r10   r10  k107 ; k107 = "concat"
.line	388	newtable     r11     1     0
.line	388	getupval     r12    u0
.line	388	loadk        r13   k46 ; k46 = 3
.line	388	loadk        r14    k3 ; k3 = 148
.line	388	loadk        r15    k4 ; k4 = 44
.line	388	loadk        r16   k65 ; k65 = 204
.line	388	loadk        r17   k66 ; k66 = 221
.line	388	loadk        r18   k40 ; k40 = 59
.line	388	loadk        r19    k5 ; k5 = 200
.line	388	loadk        r20   k67 ; k67 = 94
.line	388	loadk        r21    k3 ; k3 = 148
.line	388	loadk        r22   k68 ; k68 = 229
.line	388	loadk        r23   k69 ; k69 = 198
.line	388	loadk        r24   k70 ; k70 = 67
.line	388	loadk        r25   k20 ; k20 = 73
.line	388	loadk        r26    k4 ; k4 = 44
.line	388	loadk        r27   k73 ; k73 = 98
.line	388	loadk        r28  k108 ; k108 = 138
.line	388	loadk        r29  k109 ; k109 = 195
.line	388	loadk        r30   k52 ; k52 = 173
.line	388	loadk        r31  k110 ; k110 = 84
.line	388	loadk        r32  k111 ; k111 = 234
.line	388	loadk        r33    k4 ; k4 = 44
.line	388	loadk        r34  k112 ; k112 = 17
.line	388	loadk        r35  k113 ; k113 = 201
.line	388	loadk        r36    k9 ; k9 = 74
.line	388	loadk        r37   k31 ; k31 = 141
.line	388	loadk        r38   k59 ; k59 = 225
.line	388	loadk        r39  k114 ; k114 = 199
.line	388	loadk        r40  k115 ; k115 = 18
.line	388	loadk        r41   k15 ; k15 = 66
.line	388	loadk        r42   k19 ; k19 = 2
.line	388	loadk        r43   k22 ; k22 = 97
.line	388	loadk        r44   k69 ; k69 = 198
.line	388	loadk        r45   k68 ; k68 = 229
.line	388	loadk        r46   k27 ; k27 = 182
.line	388	loadk        r47   k15 ; k15 = 66
.line	388	loadk        r48   k93 ; k93 = 253
.line	388	loadk        r49   k40 ; k40 = 59
.line	388	loadk        r50   k42 ; k42 = 65
.line	388	loadk        r51  k111 ; k111 = 234
.line	388	loadk        r52   k73 ; k73 = 98
.line	388	call         r12    41     2
.line	388	getupval     r13    u0
.line	388	loadk        r14  k104 ; k104 = 7
.line	388	loadk        r15  k116 ; k116 = 145
.line	388	loadk        r16   k36 ; k36 = 38
.line	388	loadk        r17  k117 ; k117 = 246
.line	388	loadk        r18  k118 ; k118 = 196
.line	388	loadk        r19  k119 ; k119 = 42
.line	388	loadk        r20  k120 ; k120 = 135
.line	388	loadk        r21  k121 ; k121 = 93
.line	388	loadk        r22   k92 ; k92 = 151
.line	388	loadk        r23  k122 ; k122 = 254
.line	388	loadk        r24   k82 ; k82 = 212
.line	388	loadk        r25  k123 ; k123 = 25
.line	388	loadk        r26   k91 ; k91 = 78
.line	388	loadk        r27  k124 ; k124 = 36
.line	388	loadk        r28  k125 ; k125 = 107
.line	388	loadk        r29  k109 ; k109 = 195
.line	388	loadk        r30   k30 ; k30 = 228
.line	388	loadk        r31  k126 ; k126 = 160
.line	388	loadk        r32  k127 ; k127 = 106
.line	388	loadk        r33  k128 ; k128 = 237
.line	388	loadk        r34    k4 ; k4 = 44
.line	388	loadk        r35  k129 ; k129 = 16
.line	388	loadk        r36   k79 ; k79 = 250
.line	388	call         r13    24     0
.line	388	setlist      r11     0     1
.line	388	call         r10     2     2
.line	388	call          r9     2     2
.line	388	gettable     r10    r9  k130 ; k130 = "GetWeaponStrengthZon" (truncated)
.line	388	gettable     r11    r2  k105 ; k105 = "weapon_power_zone_id"
.line	388	call         r10     2     2
.line	388	move          r8   r10
.line	388	jmp            0  l412
.label	l332
.line	388	test          r3     0
.line	388	jmp            0  l412
.line	388	getupval      r9    u4
.line	388	gettabup     r10    u2  k106 ; k106 = "table"
.line	388	gettable     r10   r10  k107 ; k107 = "concat"
.line	388	newtable     r11     1     0
.line	388	getupval     r12    u0
.line	388	loadk        r13   k46 ; k46 = 3
.line	388	loadk        r14    k3 ; k3 = 148
.line	388	loadk        r15    k4 ; k4 = 44
.line	388	loadk        r16   k65 ; k65 = 204
.line	388	loadk        r17   k66 ; k66 = 221
.line	388	loadk        r18   k40 ; k40 = 59
.line	388	loadk        r19    k5 ; k5 = 200
.line	388	loadk        r20   k67 ; k67 = 94
.line	388	loadk        r21    k3 ; k3 = 148
.line	388	loadk        r22   k68 ; k68 = 229
.line	388	loadk        r23   k69 ; k69 = 198
.line	388	loadk        r24   k70 ; k70 = 67
.line	388	loadk        r25   k20 ; k20 = 73
.line	388	loadk        r26    k4 ; k4 = 44
.line	388	loadk        r27   k73 ; k73 = 98
.line	388	loadk        r28  k108 ; k108 = 138
.line	388	loadk        r29  k109 ; k109 = 195
.line	388	loadk        r30   k52 ; k52 = 173
.line	388	loadk        r31  k110 ; k110 = 84
.line	388	loadk        r32  k111 ; k111 = 234
.line	388	loadk        r33    k4 ; k4 = 44
.line	388	loadk        r34  k112 ; k112 = 17
.line	388	loadk        r35  k113 ; k113 = 201
.line	388	loadk        r36    k9 ; k9 = 74
.line	388	loadk        r37   k31 ; k31 = 141
.line	388	loadk        r38   k59 ; k59 = 225
.line	388	loadk        r39  k114 ; k114 = 199
.line	388	loadk        r40  k115 ; k115 = 18
.line	388	loadk        r41   k15 ; k15 = 66
.line	388	loadk        r42   k19 ; k19 = 2
.line	388	loadk        r43   k22 ; k22 = 97
.line	388	loadk        r44   k69 ; k69 = 198
.line	388	loadk        r45   k68 ; k68 = 229
.line	388	loadk        r46   k27 ; k27 = 182
.line	388	loadk        r47   k15 ; k15 = 66
.line	388	loadk        r48   k93 ; k93 = 253
.line	388	loadk        r49   k40 ; k40 = 59
.line	388	loadk        r50   k42 ; k42 = 65
.line	388	loadk        r51  k111 ; k111 = 234
.line	388	loadk        r52   k73 ; k73 = 98
.line	388	call         r12    41     2
.line	388	getupval     r13    u0
.line	388	loadk        r14  k104 ; k104 = 7
.line	388	loadk        r15  k116 ; k116 = 145
.line	388	loadk        r16   k36 ; k36 = 38
.line	388	loadk        r17  k117 ; k117 = 246
.line	388	loadk        r18  k118 ; k118 = 196
.line	388	loadk        r19  k119 ; k119 = 42
.line	388	loadk        r20  k120 ; k120 = 135
.line	388	loadk        r21  k121 ; k121 = 93
.line	388	loadk        r22   k92 ; k92 = 151
.line	388	loadk        r23  k122 ; k122 = 254
.line	388	loadk        r24   k82 ; k82 = 212
.line	388	loadk        r25  k123 ; k123 = 25
.line	388	loadk        r26   k91 ; k91 = 78
.line	388	loadk        r27  k124 ; k124 = 36
.line	388	loadk        r28  k125 ; k125 = 107
.line	388	loadk        r29  k109 ; k109 = 195
.line	388	loadk        r30   k30 ; k30 = 228
.line	388	loadk        r31  k126 ; k126 = 160
.line	388	loadk        r32  k127 ; k127 = 106
.line	388	loadk        r33  k128 ; k128 = 237
.line	388	loadk        r34    k4 ; k4 = 44
.line	388	loadk        r35  k129 ; k129 = 16
.line	388	loadk        r36   k79 ; k79 = 250
.line	388	call         r13    24     0
.line	388	setlist      r11     0     1
.line	388	call         r10     2     2
.line	388	call          r9     2     2
.line	388	gettable     r10    r9  k130 ; k130 = "GetWeaponStrengthZon" (truncated)
.line	388	move         r11    r3
.line	388	call         r10     2     2
.line	388	move          r8   r10
.label	l412
.line	388	gettabup      r9    u2   k87 ; k87 = "LocUtil"
.line	388	gettable      r9    r9   k88 ; k88 = "LocalizeResFormatByS" (truncated)
.line	388	gettable     r10    r5   k34 ; k34 = "AliasName"
.line	388	move         r11    r1
.line	388	testset      r12    r8     1
.line	388	jmp            0  l420
.line	388	getupval     r12    u0
.line	388	call         r12     1     2
.label	l420
.line	388	call          r9     4     2
.line	388	move          r6    r9
.label	l422
.line	388	gettable      r8    r5   k89 ; k89 = "AliasType"
.line	388	eq             0    r8  k131 ; k131 = 8
.line	388	jmp            0  l443
.line	388	gettabup      r8    u2  k132 ; k132 = "FuncUtil"
.line	388	gettable      r8    r8  k133 ; k133 = "GetRegisterYear"
.line	388	testset       r9    r2     0
.line	388	jmp            0  l430
.line	388	gettable      r9    r2  k134 ; k134 = "registertime"
.label	l430
.line	388	call          r8     2     2
.line	388	gettabup      r9    u2  k135 ; k135 = "math"
.line	388	gettable      r9    r9  k136 ; k136 = "max"
.line	388	move         r10    r8
.line	388	loadk        r11   k12 ; k12 = 1
.line	388	call          r9     3     2
.line	388	move          r8    r9
.line	388	gettabup      r9    u2   k87 ; k87 = "LocUtil"
.line	388	gettable      r9    r9   k88 ; k88 = "LocalizeResFormatByS" (truncated)
.line	388	gettable     r10    r5   k34 ; k34 = "AliasName"
.line	388	move         r11    r8
.line	388	call          r9     3     2
.line	388	move          r6    r9
.label	l443
.line	388	return        r6     2
.line	388	return        r0     1
.line	388	move          r0    r0
.line	388	move          r0    r0
.line	388	move          r0    r0
.line	388	return        r0     1

.function	main/f21

.source	null
.linedefined	440
.lastlinedefined	471
.numparams	3
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	1	true
.upvalue	"U1"	27	true
.upvalue	"U2"	0	false
.upvalue	"U3"	25	true
.upvalue	"U4"	22	true

.constant	k0	"GetTableData"
.constant	k1	33
.constant	k2	148
.constant	k3	44
.constant	k4	200
.constant	k5	192
.constant	k6	12
.constant	k7	128
.constant	k8	74
.constant	k9	nil
.constant	k10	"DataMgr"
.constant	k11	"roleData"
.constant	k12	"nickName"
.constant	k13	"AliasType"
.constant	k14	7
.constant	k15	"table"
.constant	k16	"concat"
.constant	k17	3
.constant	k18	204
.constant	k19	221
.constant	k20	59
.constant	k21	94
.constant	k22	229
.constant	k23	198
.constant	k24	67
.constant	k25	80
.constant	k26	46
.constant	k27	98
.constant	k28	205
.constant	k29	243
.constant	k30	230
.constant	k31	71
.constant	k32	246
.constant	k33	47
.constant	k34	26
.constant	k35	223
.constant	k36	115
.constant	k37	142
.constant	k38	239
.constant	k39	153
.constant	k40	17
.constant	k41	54
.constant	k42	124
.constant	k43	215
.constant	k44	170
.constant	k45	6
.constant	k46	232
.constant	k47	107
.constant	k48	15
.constant	k49	167
.constant	k50	49
.constant	k51	199
.constant	k52	35
.constant	k53	131
.constant	k54	"alias_list_info"
.constant	k55	"title"
.constant	k56	"alias"
.constant	k57	"FuncUtil"
.constant	k58	"Gen_title"
.constant	k59	"rank"
.constant	k60	"ext_info"
.constant	k61	"rank_id"
.constant	k62	14
.constant	k63	141
.constant	k64	40
.constant	k65	203
.constant	k66	214
.constant	k67	61
.constant	k68	"LocUtil"
.constant	k69	"LocalizeResFormat"
.constant	k70	85064
.constant	k71	"ModuleManager"
.constant	k72	"GetModule"
.constant	k73	"LobbyModuleConfig"
.constant	k74	"collect_module"
.constant	k75	"GetSelfCollectScoreByBriefData"
.constant	k76	0
.constant	k77	"GetLevelDataByScore"
.constant	k78	77678
.constant	k79	"log_format"
.constant	k80	38
.constant	k81	43
.constant	k82	202
.constant	k83	143
.constant	k84	65
.constant	k85	194
.constant	k86	121
.constant	k87	113
.constant	k88	193
.constant	k89	226
.constant	k90	138
.constant	k91	34
.constant	k92	27
.constant	k93	245
.constant	k94	155
.constant	k95	244
.constant	k96	250
.constant	k97	75
.constant	k98	127
.constant	k99	53
.constant	k100	249
.constant	k101	191
.constant	k102	24
.constant	k103	172
.constant	k104	32

.line	440	getupval      r3    u0
.line	440	call          r3     1     2
.line	440	gettabup      r4    u1    k0 ; k0 = "GetTableData"
.line	440	getupval      r5    u0
.line	440	loadk         r6    k1 ; k1 = 33
.line	440	loadk         r7    k2 ; k2 = 148
.line	440	loadk         r8    k3 ; k3 = 44
.line	440	loadk         r9    k4 ; k4 = 200
.line	440	loadk        r10    k5 ; k5 = 192
.line	440	loadk        r11    k6 ; k6 = 12
.line	440	loadk        r12    k7 ; k7 = 128
.line	440	loadk        r13    k8 ; k8 = 74
.line	440	call          r5     9     2
.line	440	move          r6    r0
.line	440	call          r4     3     2
.line	440	eq             0    r1    k9 ; k9 = nil
.line	440	jmp            0   l21
.line	440	gettabup      r5    u2   k10 ; k10 = "DataMgr"
.line	440	gettable      r5    r5   k11 ; k11 = "roleData"
.line	440	gettable      r1    r5   k12 ; k12 = "nickName"
.label	l21
.line	440	test          r4     0
.line	440	jmp            0  l131
.line	440	gettable      r5    r4   k13 ; k13 = "AliasType"
.line	440	eq             0    r5   k14 ; k14 = 7
.line	440	jmp            0  l131
.line	440	test          r2     1
.line	440	jmp            0  l104
.line	440	getupval      r5    u3
.line	440	gettabup      r6    u2   k15 ; k15 = "table"
.line	440	gettable      r6    r6   k16 ; k16 = "concat"
.line	440	newtable      r7     1     0
.line	440	getupval      r8    u0
.line	440	loadk         r9   k17 ; k17 = 3
.line	440	loadk        r10    k2 ; k2 = 148
.line	440	loadk        r11    k3 ; k3 = 44
.line	440	loadk        r12   k18 ; k18 = 204
.line	440	loadk        r13   k19 ; k19 = 221
.line	440	loadk        r14   k20 ; k20 = 59
.line	440	loadk        r15    k4 ; k4 = 200
.line	440	loadk        r16   k21 ; k21 = 94
.line	440	loadk        r17    k2 ; k2 = 148
.line	440	loadk        r18   k22 ; k22 = 229
.line	440	loadk        r19   k23 ; k23 = 198
.line	440	loadk        r20   k24 ; k24 = 67
.line	440	loadk        r21   k25 ; k25 = 80
.line	440	loadk        r22   k26 ; k26 = 46
.line	440	loadk        r23   k27 ; k27 = 98
.line	440	loadk        r24   k28 ; k28 = 205
.line	440	loadk        r25   k29 ; k29 = 243
.line	440	loadk        r26   k30 ; k30 = 230
.line	440	loadk        r27   k31 ; k31 = 71
.line	440	loadk        r28   k32 ; k32 = 246
.line	440	loadk        r29   k33 ; k33 = 47
.line	440	loadk        r30   k34 ; k34 = 26
.line	440	loadk        r31   k35 ; k35 = 223
.line	440	loadk        r32   k36 ; k36 = 115
.line	440	loadk        r33   k37 ; k37 = 142
.line	440	loadk        r34   k38 ; k38 = 239
.line	440	loadk        r35   k39 ; k39 = 153
.line	440	loadk        r36   k40 ; k40 = 17
.line	440	loadk        r37   k24 ; k24 = 67
.line	440	loadk        r38   k41 ; k41 = 54
.line	440	loadk        r39   k42 ; k42 = 124
.line	440	loadk        r40   k43 ; k43 = 215
.line	440	loadk        r41   k35 ; k35 = 223
.line	440	loadk        r42   k44 ; k44 = 170
.line	440	loadk        r43    k8 ; k8 = 74
.line	440	loadk        r44   k22 ; k22 = 229
.line	440	loadk        r45   k41 ; k41 = 54
.line	440	loadk        r46   k45 ; k45 = 6
.line	440	loadk        r47   k46 ; k46 = 232
.line	440	loadk        r48   k47 ; k47 = 107
.line	440	call          r8    41     2
.line	440	getupval      r9    u0
.line	440	loadk        r10   k48 ; k48 = 15
.line	440	loadk        r11   k49 ; k49 = 167
.line	440	loadk        r12   k50 ; k50 = 49
.line	440	loadk        r13    k5 ; k5 = 192
.line	440	loadk        r14   k51 ; k51 = 199
.line	440	loadk        r15   k52 ; k52 = 35
.line	440	loadk        r16   k53 ; k53 = 131
.line	440	call          r9     8     0
.line	440	setlist       r7     0     1
.line	440	call          r6     2     2
.line	440	call          r5     2     2
.line	440	gettable      r6    r5   k54 ; k54 = "alias_list_info"
.line	440	gettable      r6    r6    r0
.line	440	test          r6     0
.line	440	jmp            0   l92
.line	440	gettable      r2    r6   k55 ; k55 = "title"
.line	440	jmp            0  l123
.label	l92
.line	440	gettabup      r7    u2   k10 ; k10 = "DataMgr"
.line	440	gettable      r7    r7   k11 ; k11 = "roleData"
.line	440	gettable      r7    r7   k56 ; k56 = "alias"
.line	440	gettabup      r8    u2   k57 ; k57 = "FuncUtil"
.line	440	gettable      r8    r8   k58 ; k58 = "Gen_title"
.line	440	move          r9    r0
.line	440	gettable     r10    r7   k59 ; k59 = "rank"
.line	440	gettable     r11    r7   k60 ; k60 = "ext_info"
.line	440	gettable     r12    r7   k61 ; k61 = "rank_id"
.line	440	call          r8     5     2
.line	440	move          r2    r8
.line	440	jmp            0  l123
.label	l104
.line	440	getupval      r5    u4
.line	440	move          r6    r2
.line	440	call          r5     2     2
.line	440	getupval      r6    u0
.line	440	loadk         r7   k62 ; k62 = 14
.line	440	loadk         r8   k63 ; k63 = 141
.line	440	loadk         r9   k64 ; k64 = 40
.line	440	loadk        r10   k65 ; k65 = 203
.line	440	loadk        r11   k66 ; k66 = 214
.line	440	loadk        r12   k67 ; k67 = 61
.line	440	call          r6     7     2
.line	440	eq             0    r5    r6
.line	440	jmp            0  l123
.line	440	gettabup      r5    u2   k57 ; k57 = "FuncUtil"
.line	440	gettable      r5    r5   k58 ; k58 = "Gen_title"
.line	440	move          r6    r0
.line	440	move          r7    r2
.line	440	call          r5     3     2
.line	440	move          r2    r5
.label	l123
.line	440	gettabup      r5    u2   k68 ; k68 = "LocUtil"
.line	440	gettable      r5    r5   k69 ; k69 = "LocalizeResFormat"
.line	440	loadk         r6   k70 ; k70 = 85064
.line	440	move          r7    r2
.line	440	move          r8    r1
.line	440	call          r5     4     2
.line	440	move          r3    r5
.line	440	jmp            0  l160
.label	l131
.line	440	test          r2     1
.line	440	jmp            0  l144
.line	440	gettabup      r5    u2   k71 ; k71 = "ModuleManager"
.line	440	gettable      r5    r5   k72 ; k72 = "GetModule"
.line	440	gettabup      r6    u2   k71 ; k71 = "ModuleManager"
.line	440	gettable      r6    r6   k73 ; k73 = "LobbyModuleConfig"
.line	440	gettable      r6    r6   k74 ; k74 = "collect_module"
.line	440	call          r5     2     2
.line	440	self          r6    r5   k75 ; k75 = "GetSelfCollectScoreB" (truncated)
.line	440	call          r6     2     2
.line	440	testset       r2    r6     1
.line	440	jmp            0  l144
.line	440	loadk         r2   k76 ; k76 = 0
.label	l144
.line	440	gettabup      r5    u2   k71 ; k71 = "ModuleManager"
.line	440	gettable      r5    r5   k72 ; k72 = "GetModule"
.line	440	gettabup      r6    u2   k71 ; k71 = "ModuleManager"
.line	440	gettable      r6    r6   k73 ; k73 = "LobbyModuleConfig"
.line	440	gettable      r6    r6   k74 ; k74 = "collect_module"
.line	440	call          r5     2     2
.line	440	self          r6    r5   k77 ; k77 = "GetLevelDataByScore"
.line	440	move          r8    r2
.line	440	call          r6     3     3
.line	440	gettabup      r8    u2   k68 ; k68 = "LocUtil"
.line	440	gettable      r8    r8   k69 ; k69 = "LocalizeResFormat"
.line	440	loadk         r9   k78 ; k78 = 77678
.line	440	move         r10    r6
.line	440	move         r11    r1
.line	440	call          r8     4     2
.line	440	move          r3    r8
.label	l160
.line	440	gettabup      r5    u2   k79 ; k79 = "log_format"
.line	440	getupval      r6    u0
.line	440	loadk         r7   k80 ; k80 = 38
.line	440	loadk         r8   k63 ; k63 = 141
.line	440	loadk         r9   k81 ; k81 = 43
.line	440	loadk        r10   k82 ; k82 = 202
.line	440	loadk        r11   k30 ; k30 = 230
.line	440	loadk        r12   k20 ; k20 = 59
.line	440	loadk        r13   k83 ; k83 = 143
.line	440	loadk        r14   k84 ; k84 = 65
.line	440	loadk        r15   k66 ; k66 = 214
.line	440	loadk        r16   k43 ; k43 = 215
.line	440	loadk        r17   k85 ; k85 = 194
.line	440	loadk        r18   k17 ; k17 = 3
.line	440	loadk        r19   k86 ; k86 = 121
.line	440	loadk        r20   k33 ; k33 = 47
.line	440	loadk        r21   k87 ; k87 = 113
.line	440	loadk        r22   k88 ; k88 = 193
.line	440	loadk        r23   k89 ; k89 = 226
.line	440	loadk        r24   k90 ; k90 = 138
.line	440	loadk        r25   k31 ; k31 = 71
.line	440	loadk        r26   k32 ; k32 = 246
.line	440	loadk        r27   k91 ; k91 = 34
.line	440	loadk        r28   k92 ; k92 = 27
.line	440	loadk        r29   k93 ; k93 = 245
.line	440	loadk        r30   k42 ; k42 = 124
.line	440	loadk        r31   k94 ; k94 = 155
.line	440	loadk        r32   k95 ; k95 = 244
.line	440	loadk        r33   k96 ; k96 = 250
.line	440	loadk        r34   k62 ; k62 = 14
.line	440	loadk        r35   k97 ; k97 = 75
.line	440	loadk        r36   k98 ; k98 = 127
.line	440	loadk        r37   k99 ; k99 = 53
.line	440	loadk        r38  k100 ; k100 = 249
.line	440	loadk        r39   k29 ; k29 = 243
.line	440	loadk        r40  k101 ; k101 = 191
.line	440	loadk        r41  k102 ; k102 = 24
.line	440	loadk        r42  k103 ; k103 = 172
.line	440	loadk        r43  k104 ; k104 = 32
.line	440	call          r6    38     2
.line	440	move          r7    r3
.line	440	call          r5     3     1
.line	440	return        r3     2
.line	440	return        r0     1
.line	440	move          r0    r0
.line	440	return        r0     1

.function	main/f22

.source	null
.linedefined	473
.lastlinedefined	486
.numparams	1
.is_vararg	0
.maxstacksize	41

.upvalue	"_ENV"	21	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	0
.constant	k1	"totalusetime"
.constant	k2	"total_score"
.constant	k3	"fin_power_count"
.constant	k4	"delta_score"
.constant	k5	"weapon_power_add_count"
.constant	k6	"weapon_id"
.constant	k7	"log_tree"
.constant	k8	38
.constant	k9	141
.constant	k10	43
.constant	k11	202
.constant	k12	230
.constant	k13	59
.constant	k14	143
.constant	k15	65
.constant	k16	214
.constant	k17	215
.constant	k18	194
.constant	k19	25
.constant	k20	104
.constant	k21	46
.constant	k22	117
.constant	k23	246
.constant	k24	245
.constant	k25	187
.constant	k26	64
.constant	k27	55
.constant	k28	81
.constant	k29	182
.constant	k30	105
.constant	k31	135
.constant	k32	240
.constant	k33	232
.constant	k34	15
.constant	k35	73
.constant	k36	34
.constant	k37	96
.constant	k38	216
.constant	k39	244
.constant	k40	248
.constant	k41	24
.constant	k42	169

.line	473	newtable      r1     0     0
.line	473	loadk         r2    k0 ; k0 = 0
.line	473	getupval      r3    u0
.line	473	move          r4    r0
.line	473	call          r3     2     4
.line	473	jmp            0   l16
.line	473	gettable      r8    r7    k1 ; k1 = "totalusetime"
.line	473	le             0    r2    r8
.line	473	jmp            0   l16
.line	473	gettable      r8    r7    k3 ; k3 = "fin_power_count"
.line	473	settable      r1    k2    r8 ; k2 = "total_score"
.line	473	gettable      r8    r7    k5 ; k5 = "weapon_power_add_cou" (truncated)
.line	473	settable      r1    k4    r8 ; k4 = "delta_score"
.line	473	settable      r1    k6    r6 ; k6 = "weapon_id"
.line	473	gettable      r2    r7    k1 ; k1 = "totalusetime"
.label	l16
.line	473	move          r0    r0
.line	473	move          r0    r0
.line	473	gettabup      r3    u1    k7 ; k7 = "log_tree"
.line	473	getupval      r4    u2
.line	473	loadk         r5    k8 ; k8 = 38
.line	473	loadk         r6    k9 ; k9 = 141
.line	473	loadk         r7   k10 ; k10 = 43
.line	473	loadk         r8   k11 ; k11 = 202
.line	473	loadk         r9   k12 ; k12 = 230
.line	473	loadk        r10   k13 ; k13 = 59
.line	473	loadk        r11   k14 ; k14 = 143
.line	473	loadk        r12   k15 ; k15 = 65
.line	473	loadk        r13   k16 ; k16 = 214
.line	473	loadk        r14   k17 ; k17 = 215
.line	473	loadk        r15   k18 ; k18 = 194
.line	473	loadk        r16   k19 ; k19 = 25
.line	473	loadk        r17   k20 ; k20 = 104
.line	473	loadk        r18   k21 ; k21 = 46
.line	473	loadk        r19   k22 ; k22 = 117
.line	473	loadk        r20   k23 ; k23 = 246
.line	473	loadk        r21   k24 ; k24 = 245
.line	473	loadk        r22   k25 ; k25 = 187
.line	473	loadk        r23   k26 ; k26 = 64
.line	473	loadk        r24   k24 ; k24 = 245
.line	473	loadk        r25   k27 ; k27 = 55
.line	473	loadk        r26   k28 ; k28 = 81
.line	473	loadk        r27   k29 ; k29 = 182
.line	473	loadk        r28   k30 ; k30 = 105
.line	473	loadk        r29   k31 ; k31 = 135
.line	473	loadk        r30   k32 ; k32 = 240
.line	473	loadk        r31   k33 ; k33 = 232
.line	473	loadk        r32   k34 ; k34 = 15
.line	473	loadk        r33   k35 ; k35 = 73
.line	473	loadk        r34   k36 ; k36 = 34
.line	473	loadk        r35   k37 ; k37 = 96
.line	473	loadk        r36   k38 ; k38 = 216
.line	473	loadk        r37   k39 ; k39 = 244
.line	473	loadk        r38   k40 ; k40 = 248
.line	473	loadk        r39   k41 ; k41 = 24
.line	473	loadk        r40   k42 ; k42 = 169
.line	473	call          r4    37     2
.line	473	move          r5    r1
.line	473	call          r3     3     1
.line	473	return        r1     2
.line	473	return        r0     1
.line	473	move          r0    r0
.line	473	gettabup      r1    u1   k41 ; k41 = 24
.line	473	return        r0     1

.function	main/f23

.source	null
.linedefined	488
.lastlinedefined	495
.numparams	4
.is_vararg	0
.maxstacksize	6

.constant	k0	0
.constant	k1	24
.constant	k2	16
.constant	k3	8

.line	488	loadk         r4    k0 ; k0 = 0
.line	488	shl           r0    r0    k1 ; k1 = 24
.line	488	shl           r1    r1    k2 ; k2 = 16
.line	488	shl           r2    r2    k3 ; k3 = 8
.line	488	add           r5    r0    r1
.line	488	add           r5    r5    r2
.line	488	add           r4    r5    r3
.line	488	return        r4     2
.line	488	return        r0     1
.line	488	move          r0    r0
.line	488	move          r0    r0
.line	488	return        r0     1

.function	main/f24

.source	null
.linedefined	497
.lastlinedefined	505
.numparams	1
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	25	true
.upvalue	"U1"	3	true

.constant	k0	"Get"
.constant	k1	1
.constant	k2	4278190080
.constant	k3	24
.constant	k4	16711680
.constant	k5	16
.constant	k6	65280
.constant	k7	8
.constant	k8	255

.line	497	getupval      r1    u0
.line	497	getupval      r2    u1
.line	497	call          r1     2     2
.line	497	gettable      r2    r1    k0 ; k0 = "Get"
.line	497	call          r2     1     2
.line	497	len           r3    r2
.line	497	add           r3    r3    k1 ; k1 = 1
.line	497	band          r4    r0    k2 ; k2 = 4278190080
.line	497	shr           r4    r4    k3 ; k3 = 24
.line	497	settable      r2    r3    r4
.line	497	len           r3    r2
.line	497	add           r3    r3    k1 ; k1 = 1
.line	497	band          r4    r0    k4 ; k4 = 16711680
.line	497	shr           r4    r4    k5 ; k5 = 16
.line	497	settable      r2    r3    r4
.line	497	len           r3    r2
.line	497	add           r3    r3    k1 ; k1 = 1
.line	497	band          r4    r0    k6 ; k6 = 65280
.line	497	shr           r4    r4    k7 ; k7 = 8
.line	497	settable      r2    r3    r4
.line	497	len           r3    r2
.line	497	add           r3    r3    k1 ; k1 = 1
.line	497	band          r4    r0    k8 ; k8 = 255
.line	497	settable      r2    r3    r4
.line	497	return        r2     2
.line	497	return        r0     1
.line	497	move          r0    r0
.line	497	return        r0     1

.function	main/f25

.source	null
.linedefined	510
.lastlinedefined	512
.numparams	1
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	23	true
.upvalue	"U1"	8	true
.upvalue	"U2"	40	true

.constant	k0	1

.line	510	getupval      r1    u0
.line	510	getupval      r2    u1
.line	510	move          r3    r0
.line	510	loadk         r4    k0 ; k0 = 1
.line	510	loadk         r5    k0 ; k0 = 1
.line	510	call          r2     4     0
.line	510	call          r1     0     2
.line	510	getupval      r2    u2
.line	510	eq             1    r1    r2
.line	510	jmp            0   l12
.line	510	loadbool      r1     0     1
.label	l12
.line	510	loadbool      r1     1     0
.line	510	return        r1     2
.line	510	return        r0     1
.line	510	move          r0    r0
.line	510	move          r0    r0
.line	510	move          r0    r0
.line	510	return        r0     1

.function	main/f26

.source	null
.linedefined	514
.lastlinedefined	516
.numparams	1
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	23	true
.upvalue	"U1"	8	true
.upvalue	"U2"	41	true

.constant	k0	1

.line	514	getupval      r1    u0
.line	514	getupval      r2    u1
.line	514	move          r3    r0
.line	514	loadk         r4    k0 ; k0 = 1
.line	514	loadk         r5    k0 ; k0 = 1
.line	514	call          r2     4     0
.line	514	call          r1     0     2
.line	514	getupval      r2    u2
.line	514	eq             1    r1    r2
.line	514	jmp            0   l12
.line	514	loadbool      r1     0     1
.label	l12
.line	514	loadbool      r1     1     0
.line	514	return        r1     2
.line	514	return        r0     1
.line	514	move          r0    r0
.line	514	move          r0    r0
.line	514	return        r0     1

.function	main/f27

.source	null
.linedefined	518
.lastlinedefined	524
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	2	true

.constant	k0	"GetOperationRegion"
.constant	k1	"OperationRegion"
.constant	k2	"JAPAN"

.line	518	gettabup      r0    u0    k0 ; k0 = "GetOperationRegion"
.line	518	call          r0     1     2
.line	518	gettabup      r1    u0    k1 ; k1 = "OperationRegion"
.line	518	gettable      r1    r1    k2 ; k2 = "JAPAN"
.line	518	eq             0    r0    r1
.line	518	jmp            0    l9
.line	518	loadbool      r1     1     0
.line	518	return        r1     2
.label	l9
.line	518	loadbool      r1     0     0
.line	518	return        r1     2
.line	518	return        r0     1
.line	518	move          r0    r0
.line	518	move          r0    r0
.line	518	return        r0     1

.function	main/f28

.source	null
.linedefined	526
.lastlinedefined	531
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	2	true

.constant	k0	"IsJapanOrKorea"

.line	526	gettabup      r0    u0    k0 ; k0 = "IsJapanOrKorea"
.line	526	call          r0     1     2
.line	526	test          r0     0
.line	526	jmp            0    l7
.line	526	loadbool      r0     1     0
.line	526	return        r0     2
.label	l7
.line	526	loadbool      r0     0     0
.line	526	return        r0     2
.line	526	return        r0     1
.line	526	move          r0    r0
.line	526	move          r0    r0
.line	526	return        r0     1

.function	main/f29

.source	null
.linedefined	533
.lastlinedefined	541
.numparams	3
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	2	true

.constant	k0	"GetOperationRegion"
.constant	k1	"OperationRegion"
.constant	k2	"KOREA"
.constant	k3	"JAPAN"

.line	533	gettabup      r3    u0    k0 ; k0 = "GetOperationRegion"
.line	533	call          r3     1     2
.line	533	gettabup      r4    u0    k1 ; k1 = "OperationRegion"
.line	533	gettable      r4    r4    k2 ; k2 = "KOREA"
.line	533	eq             0    r3    r4
.line	533	jmp            0    l9
.line	533	return        r2     2
.line	533	jmp            0   l14
.label	l9
.line	533	gettabup      r4    u0    k1 ; k1 = "OperationRegion"
.line	533	gettable      r4    r4    k3 ; k3 = "JAPAN"
.line	533	eq             0    r3    r4
.line	533	jmp            0   l14
.line	533	return        r1     2
.label	l14
.line	533	return        r0     2
.line	533	return        r0     1
.line	533	move          r0    r0
.line	533	move          r0    r0
.line	533	return        r0     1

.function	main/f30

.source	null
.linedefined	543
.lastlinedefined	604
.numparams	0
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	35	true
.upvalue	"U3"	24	true
.upvalue	"U4"	22	true
.upvalue	"U5"	39	true
.upvalue	"U6"	23	true
.upvalue	"U7"	36	true
.upvalue	"U8"	25	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	38
.constant	k3	141
.constant	k4	43
.constant	k5	202
.constant	k6	230
.constant	k7	59
.constant	k8	143
.constant	k9	65
.constant	k10	214
.constant	k11	217
.constant	k12	201
.constant	k13	4
.constant	k14	72
.constant	k15	19
.constant	k16	96
.constant	k17	255
.constant	k18	188
.constant	k19	80
.constant	k20	218
.constant	k21	37
.constant	k22	24
.constant	k23	34
.constant	k24	153
.constant	k25	232
.constant	k26	193
.constant	k27	42
.constant	k28	135
.constant	k29	110
.constant	k30	151
.constant	k31	244
.constant	k32	194
.constant	k33	46
.constant	k34	83
.constant	k35	47
.constant	k36	99
.constant	k37	205
.constant	k38	247
.constant	k39	"table"
.constant	k40	"concat"
.constant	k41	182
.constant	k42	61
.constant	k43	170
.constant	k44	225
.constant	k45	60
.constant	k46	94
.constant	k47	52
.constant	k48	116
.constant	k49	239
.constant	k50	64
.constant	k51	1
.constant	k52	224
.constant	k53	100
.constant	k54	7
.constant	k55	nil
.constant	k56	140
.constant	k57	55
.constant	k58	192
.constant	k59	221
.constant	k60	40
.constant	k61	2
.constant	k62	"FuncUtil"
.constant	k63	"arrBanIPAreaList"
.constant	k64	137
.constant	k65	242
.constant	k66	197
.constant	k67	63
.constant	k68	77
.constant	k69	92
.constant	k70	228
.constant	k71	31
.constant	k72	6
.constant	k73	245
.constant	k74	121
.constant	k75	90
.constant	k76	250
.constant	k77	199
.constant	k78	32
.constant	k79	148
.constant	k80	180
.constant	k81	249
.constant	k82	212
.constant	k83	25
.constant	k84	127
.constant	k85	107
.constant	k86	175
.constant	k87	88
.constant	k88	62
.constant	k89	103
.constant	k90	209
.constant	k91	204
.constant	k92	177
.constant	k93	86
.constant	k94	253
.constant	k95	16
.constant	k96	0
.constant	k97	9
.constant	k98	159
.constant	k99	"arrBanStoreList"
.constant	k100	70
.constant	k101	58
.constant	k102	28
.constant	k103	35
.constant	k104	44
.constant	k105	179
.constant	k106	93
.constant	k107	226
.constant	k108	198
.constant	k109	89
.constant	k110	13
.constant	k111	108
.constant	k112	251
.constant	k113	139
.constant	k114	22
.constant	k115	241
.constant	k116	171
.constant	k117	236
.constant	k118	222
.constant	k119	66
.constant	k120	196
.constant	k121	231
.constant	k122	68
.constant	k123	237
.constant	k124	54
.constant	k125	11
.constant	k126	187
.constant	k127	213
.constant	k128	129
.constant	k129	23
.constant	k130	"arrNotGPUpgradeLink"
.constant	k131	51
.constant	k132	67
.constant	k133	82
.constant	k134	168
.constant	k135	50
.constant	k136	227
.constant	k137	150
.constant	k138	147
.constant	k139	"remoteCfgCountryCode"
.constant	k140	157
.constant	k141	165
.constant	k142	75
.constant	k143	211
.constant	k144	200
.constant	k145	53
.constant	k146	119
.constant	k147	167
.constant	k148	81
.constant	k149	252
.constant	k150	"turnOnClientSpeLabel"
.constant	k151	33
.constant	k152	145
.constant	k153	111
.constant	k154	49
.constant	k155	"remoteCfgBasePreFetch"
.constant	k156	210
.constant	k157	30
.constant	k158	17
.constant	k159	173
.constant	k160	"PufferDownloader"
.constant	k161	"SetEnableBackpackCache"
.constant	k162	"defaultJumpLink"
.constant	k163	"GetDomainByID"
.constant	k164	3366055
.constant	k165	36
.constant	k166	146
.constant	k167	215
.constant	k168	85
.constant	k169	3
.constant	k170	206
.constant	k171	14
.constant	k172	18
.constant	k173	106
.constant	k174	195
.constant	k175	101
.constant	k176	243
.constant	k177	184
.constant	k178	27
.constant	k179	95
.constant	k180	216
.constant	k181	161
.constant	k182	29
.constant	k183	"LoadFileToTable_N"
.constant	k184	"ePlayerPrefsType"
.constant	k185	"eLoginBackUpLastCountryNo"
.constant	k186	"LastCountryNo"
.constant	k187	"localCountryCode"
.constant	k188	"Client"
.constant	k189	"GetIPRegion"
.constant	k190	"SaveTableToFile_N"
.constant	k191	78
.constant	k192	246
.constant	k193	12
.constant	k194	155
.constant	k195	74
.constant	k196	154
.constant	k197	229
.constant	k198	156
.constant	k199	233
.constant	k200	189
.constant	k201	164

.line	543	gettabup      r0    u0    k0 ; k0 = "log"
.line	543	gettabup      r1    u0    k1 ; k1 = "bWriteLog"
.line	543	test          r1     0
.line	543	jmp            0   l29
.line	543	getupval      r1    u1
.line	543	loadk         r2    k2 ; k2 = 38
.line	543	loadk         r3    k3 ; k3 = 141
.line	543	loadk         r4    k4 ; k4 = 43
.line	543	loadk         r5    k5 ; k5 = 202
.line	543	loadk         r6    k6 ; k6 = 230
.line	543	loadk         r7    k7 ; k7 = 59
.line	543	loadk         r8    k8 ; k8 = 143
.line	543	loadk         r9    k9 ; k9 = 65
.line	543	loadk        r10   k10 ; k10 = 214
.line	543	loadk        r11   k11 ; k11 = 217
.line	543	loadk        r12   k12 ; k12 = 201
.line	543	loadk        r13   k13 ; k13 = 4
.line	543	loadk        r14   k14 ; k14 = 72
.line	543	loadk        r15   k15 ; k15 = 19
.line	543	loadk        r16   k16 ; k16 = 96
.line	543	loadk        r17   k12 ; k12 = 201
.line	543	loadk        r18   k17 ; k17 = 255
.line	543	loadk        r19   k18 ; k18 = 188
.line	543	loadk        r20   k19 ; k19 = 80
.line	543	loadk        r21   k20 ; k20 = 218
.line	543	loadk        r22   k21 ; k21 = 37
.line	543	loadk        r23   k22 ; k22 = 24
.line	543	call          r1    23     2
.label	l29
.line	543	call          r0     2     1
.line	543	getupval      r0    u2
.line	543	getupval      r1    u1
.line	543	loadk         r2   k23 ; k23 = 34
.line	543	loadk         r3   k24 ; k24 = 153
.line	543	loadk         r4    k4 ; k4 = 43
.line	543	loadk         r5   k25 ; k25 = 232
.line	543	loadk         r6   k26 ; k26 = 193
.line	543	loadk         r7   k27 ; k27 = 42
.line	543	loadk         r8   k28 ; k28 = 135
.line	543	loadk         r9   k29 ; k29 = 110
.line	543	loadk        r10   k30 ; k30 = 151
.line	543	loadk        r11   k31 ; k31 = 244
.line	543	loadk        r12   k32 ; k32 = 194
.line	543	loadk        r13   k33 ; k33 = 46
.line	543	loadk        r14   k34 ; k34 = 83
.line	543	loadk        r15   k35 ; k35 = 47
.line	543	loadk        r16   k36 ; k36 = 99
.line	543	loadk        r17   k37 ; k37 = 205
.line	543	loadk        r18   k38 ; k38 = 247
.line	543	call          r1    18     2
.line	543	getupval      r2    u1
.line	543	call          r2     1     2
.line	543	call          r0     3     2
.line	543	gettabup      r1    u0    k0 ; k0 = "log"
.line	543	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	543	test          r2     0
.line	543	jmp            0  l112
.line	543	gettabup      r2    u0   k39 ; k39 = "table"
.line	543	gettable      r2    r2   k40 ; k40 = "concat"
.line	543	newtable      r3     1     0
.line	543	getupval      r4    u1
.line	543	loadk         r5    k2 ; k2 = 38
.line	543	loadk         r6    k3 ; k3 = 141
.line	543	loadk         r7    k4 ; k4 = 43
.line	543	loadk         r8    k5 ; k5 = 202
.line	543	loadk         r9    k6 ; k6 = 230
.line	543	loadk        r10    k7 ; k7 = 59
.line	543	loadk        r11    k8 ; k8 = 143
.line	543	loadk        r12    k9 ; k9 = 65
.line	543	loadk        r13   k10 ; k10 = 214
.line	543	loadk        r14   k11 ; k11 = 217
.line	543	loadk        r15   k12 ; k12 = 201
.line	543	loadk        r16   k13 ; k13 = 4
.line	543	loadk        r17   k14 ; k14 = 72
.line	543	loadk        r18   k15 ; k15 = 19
.line	543	loadk        r19   k16 ; k16 = 96
.line	543	loadk        r20   k12 ; k12 = 201
.line	543	loadk        r21   k17 ; k17 = 255
.line	543	loadk        r22   k18 ; k18 = 188
.line	543	loadk        r23   k19 ; k19 = 80
.line	543	loadk        r24   k20 ; k20 = 218
.line	543	loadk        r25   k21 ; k21 = 37
.line	543	loadk        r26   k22 ; k22 = 24
.line	543	loadk        r27   k41 ; k41 = 182
.line	543	loadk        r28   k42 ; k42 = 61
.line	543	loadk        r29   k43 ; k43 = 170
.line	543	loadk        r30   k44 ; k44 = 225
.line	543	loadk        r31   k11 ; k11 = 217
.line	543	loadk        r32   k45 ; k45 = 60
.line	543	loadk        r33   k46 ; k46 = 94
.line	543	loadk        r34   k47 ; k47 = 52
.line	543	loadk        r35   k48 ; k48 = 116
.line	543	loadk        r36   k38 ; k38 = 247
.line	543	loadk        r37   k49 ; k49 = 239
.line	543	loadk        r38   k18 ; k18 = 188
.line	543	loadk        r39   k50 ; k50 = 64
.line	543	loadk        r40    k5 ; k5 = 202
.line	543	loadk        r41   k45 ; k45 = 60
.line	543	loadk        r42   k51 ; k51 = 1
.line	543	loadk        r43   k52 ; k52 = 224
.line	543	loadk        r44   k53 ; k53 = 100
.line	543	call          r4    41     2
.line	543	getupval      r5    u1
.line	543	loadk         r6   k54 ; k54 = 7
.line	543	loadk         r7   k32 ; k32 = 194
.line	543	call          r5     3     0
.line	543	setlist       r3     0     1
.line	543	call          r2     2     2
.line	543	getupval      r3    u3
.line	543	move          r4    r0
.line	543	call          r3     2     2
.line	543	concat        r2    r2    r3
.label	l112
.line	543	call          r1     2     1
.line	543	eq             1    r0   k55 ; k55 = nil
.line	543	jmp            0  l152
.line	543	getupval      r1    u4
.line	543	move          r2    r0
.line	543	call          r1     2     2
.line	543	getupval      r2    u1
.line	543	loadk         r3   k15 ; k15 = 19
.line	543	loadk         r4   k56 ; k56 = 140
.line	543	loadk         r5   k57 ; k57 = 55
.line	543	loadk         r6   k58 ; k58 = 192
.line	543	loadk         r7   k59 ; k59 = 221
.line	543	loadk         r8   k60 ; k60 = 40
.line	543	call          r2     7     2
.line	543	eq             0    r1    r2
.line	543	jmp            0  l152
.line	543	len           r1    r0
.line	543	lt             0   k61    r1 ; k61 = 2
.line	543	jmp            0  l152
.line	543	getupval      r1    u5
.line	543	move          r2    r0
.line	543	call          r1     2     2
.line	543	loadk         r2   k51 ; k51 = 1
.line	543	len           r3    r1
.line	543	loadk         r4   k51 ; k51 = 1
.line	543	move          r0    r0
.line	543	getupval      r6    u6
.line	543	gettable      r7    r1    r5
.line	543	call          r6     2     2
.line	543	test          r6     0
.line	543	jmp            0  l150
.line	543	gettabup      r7    u0   k62 ; k62 = "FuncUtil"
.line	543	gettable      r7    r7   k63 ; k63 = "arrBanIPAreaList"
.line	543	gettabup      r8    u0   k62 ; k62 = "FuncUtil"
.line	543	gettable      r8    r8   k63 ; k63 = "arrBanIPAreaList"
.line	543	len           r8    r8
.line	543	add           r8    r8   k51 ; k51 = 1
.line	543	settable      r7    r8    r6
.label	l150
.line	543	move          r0    r0
.line	543	jmp            0  l152
.label	l152
.line	543	gettabup      r1    u0    k0 ; k0 = "log"
.line	543	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	543	test          r2     0
.line	543	jmp            0  l212
.line	543	gettabup      r2    u0   k39 ; k39 = "table"
.line	543	gettable      r2    r2   k40 ; k40 = "concat"
.line	543	newtable      r3     1     0
.line	543	getupval      r4    u1
.line	543	loadk         r5    k2 ; k2 = 38
.line	543	loadk         r6    k3 ; k3 = 141
.line	543	loadk         r7    k4 ; k4 = 43
.line	543	loadk         r8    k5 ; k5 = 202
.line	543	loadk         r9    k6 ; k6 = 230
.line	543	loadk        r10    k7 ; k7 = 59
.line	543	loadk        r11    k8 ; k8 = 143
.line	543	loadk        r12    k9 ; k9 = 65
.line	543	loadk        r13   k10 ; k10 = 214
.line	543	loadk        r14   k11 ; k11 = 217
.line	543	loadk        r15   k12 ; k12 = 201
.line	543	loadk        r16   k13 ; k13 = 4
.line	543	loadk        r17   k14 ; k14 = 72
.line	543	loadk        r18   k15 ; k15 = 19
.line	543	loadk        r19   k16 ; k16 = 96
.line	543	loadk        r20   k12 ; k12 = 201
.line	543	loadk        r21   k17 ; k17 = 255
.line	543	loadk        r22   k18 ; k18 = 188
.line	543	loadk        r23   k19 ; k19 = 80
.line	543	loadk        r24   k20 ; k20 = 218
.line	543	loadk        r25   k21 ; k21 = 37
.line	543	loadk        r26   k22 ; k22 = 24
.line	543	loadk        r27   k41 ; k41 = 182
.line	543	loadk        r28   k42 ; k42 = 61
.line	543	loadk        r29   k64 ; k64 = 137
.line	543	loadk        r30   k65 ; k65 = 242
.line	543	loadk        r31   k66 ; k66 = 197
.line	543	loadk        r32   k67 ; k67 = 63
.line	543	loadk        r33   k68 ; k68 = 77
.line	543	loadk        r34   k67 ; k67 = 63
.line	543	loadk        r35   k69 ; k69 = 92
.line	543	loadk        r36   k70 ; k70 = 228
.line	543	loadk        r37   k26 ; k26 = 193
.line	543	loadk        r38   k43 ; k43 = 170
.line	543	loadk        r39   k50 ; k50 = 64
.line	543	loadk        r40   k25 ; k25 = 232
.line	543	loadk        r41   k71 ; k71 = 31
.line	543	loadk        r42   k72 ; k72 = 6
.line	543	loadk        r43   k73 ; k73 = 245
.line	543	loadk        r44   k74 ; k74 = 121
.line	543	call          r4    41     2
.line	543	getupval      r5    u1
.line	543	loadk         r6   k75 ; k75 = 90
.line	543	call          r5     2     0
.line	543	setlist       r3     0     1
.line	543	call          r2     2     2
.line	543	getupval      r3    u3
.line	543	gettabup      r4    u0   k62 ; k62 = "FuncUtil"
.line	543	gettable      r4    r4   k63 ; k63 = "arrBanIPAreaList"
.line	543	len           r4    r4
.line	543	call          r3     2     2
.line	543	concat        r2    r2    r3
.label	l212
.line	543	call          r1     2     1
.line	543	getupval      r1    u2
.line	543	getupval      r2    u1
.line	543	loadk         r3   k23 ; k23 = 34
.line	543	loadk         r4   k24 ; k24 = 153
.line	543	loadk         r5    k4 ; k4 = 43
.line	543	loadk         r6   k76 ; k76 = 250
.line	543	loadk         r7   k77 ; k77 = 199
.line	543	loadk         r8   k78 ; k78 = 32
.line	543	loadk         r9   k79 ; k79 = 148
.line	543	loadk        r10   k14 ; k14 = 72
.line	543	loadk        r11   k80 ; k80 = 180
.line	543	loadk        r12   k81 ; k81 = 249
.line	543	loadk        r13   k82 ; k82 = 212
.line	543	loadk        r14   k83 ; k83 = 25
.line	543	loadk        r15   k84 ; k84 = 127
.line	543	loadk        r16   k33 ; k33 = 46
.line	543	loadk        r17   k85 ; k85 = 107
.line	543	loadk        r18   k32 ; k32 = 194
.line	543	loadk        r19   k81 ; k81 = 249
.line	543	loadk        r20   k86 ; k86 = 175
.line	543	call          r2    19     2
.line	543	getupval      r3    u1
.line	543	call          r3     1     2
.line	543	call          r1     3     2
.line	543	move          r0    r1
.line	543	gettabup      r1    u0    k0 ; k0 = "log"
.line	543	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	543	test          r2     0
.line	543	jmp            0  l298
.line	543	gettabup      r2    u0   k39 ; k39 = "table"
.line	543	gettable      r2    r2   k40 ; k40 = "concat"
.line	543	newtable      r3     1     0
.line	543	getupval      r4    u1
.line	543	loadk         r5    k2 ; k2 = 38
.line	543	loadk         r6    k3 ; k3 = 141
.line	543	loadk         r7    k4 ; k4 = 43
.line	543	loadk         r8    k5 ; k5 = 202
.line	543	loadk         r9    k6 ; k6 = 230
.line	543	loadk        r10    k7 ; k7 = 59
.line	543	loadk        r11    k8 ; k8 = 143
.line	543	loadk        r12    k9 ; k9 = 65
.line	543	loadk        r13   k10 ; k10 = 214
.line	543	loadk        r14   k11 ; k11 = 217
.line	543	loadk        r15   k12 ; k12 = 201
.line	543	loadk        r16   k13 ; k13 = 4
.line	543	loadk        r17   k14 ; k14 = 72
.line	543	loadk        r18   k15 ; k15 = 19
.line	543	loadk        r19   k16 ; k16 = 96
.line	543	loadk        r20   k12 ; k12 = 201
.line	543	loadk        r21   k17 ; k17 = 255
.line	543	loadk        r22   k18 ; k18 = 188
.line	543	loadk        r23   k19 ; k19 = 80
.line	543	loadk        r24   k20 ; k20 = 218
.line	543	loadk        r25   k21 ; k21 = 37
.line	543	loadk        r26   k22 ; k22 = 24
.line	543	loadk        r27   k41 ; k41 = 182
.line	543	loadk        r28   k42 ; k42 = 61
.line	543	loadk        r29   k43 ; k43 = 170
.line	543	loadk        r30   k44 ; k44 = 225
.line	543	loadk        r31   k11 ; k11 = 217
.line	543	loadk        r32   k33 ; k33 = 46
.line	543	loadk        r33   k87 ; k87 = 88
.line	543	loadk        r34   k88 ; k88 = 62
.line	543	loadk        r35   k89 ; k89 = 103
.line	543	loadk        r36   k90 ; k90 = 209
.line	543	loadk        r37   k91 ; k91 = 204
.line	543	loadk        r38   k92 ; k92 = 177
.line	543	loadk        r39   k93 ; k93 = 86
.line	543	loadk        r40   k94 ; k94 = 253
.line	543	loadk        r41   k95 ; k95 = 16
.line	543	loadk        r42   k96 ; k96 = 0
.line	543	loadk        r43   k25 ; k25 = 232
.line	543	loadk        r44   k85 ; k85 = 107
.line	543	call          r4    41     2
.line	543	getupval      r5    u1
.line	543	loadk         r6   k97 ; k97 = 9
.line	543	loadk         r7   k98 ; k98 = 159
.line	543	loadk         r8   k84 ; k84 = 127
.line	543	call          r5     4     0
.line	543	setlist       r3     0     1
.line	543	call          r2     2     2
.line	543	getupval      r3    u3
.line	543	move          r4    r0
.line	543	call          r3     2     2
.line	543	concat        r2    r2    r3
.label	l298
.line	543	call          r1     2     1
.line	543	eq             1    r0   k55 ; k55 = nil
.line	543	jmp            0  l334
.line	543	getupval      r1    u4
.line	543	move          r2    r0
.line	543	call          r1     2     2
.line	543	getupval      r2    u1
.line	543	loadk         r3   k15 ; k15 = 19
.line	543	loadk         r4   k56 ; k56 = 140
.line	543	loadk         r5   k57 ; k57 = 55
.line	543	loadk         r6   k58 ; k58 = 192
.line	543	loadk         r7   k59 ; k59 = 221
.line	543	loadk         r8   k60 ; k60 = 40
.line	543	call          r2     7     2
.line	543	eq             0    r1    r2
.line	543	jmp            0  l334
.line	543	len           r1    r0
.line	543	lt             0   k61    r1 ; k61 = 2
.line	543	jmp            0  l334
.line	543	getupval      r1    u5
.line	543	move          r2    r0
.line	543	call          r1     2     2
.line	543	loadk         r2   k51 ; k51 = 1
.line	543	len           r3    r1
.line	543	loadk         r4   k51 ; k51 = 1
.line	543	move          r0    r0
.line	543	gettabup      r6    u0   k62 ; k62 = "FuncUtil"
.line	543	gettable      r6    r6   k99 ; k99 = "arrBanStoreList"
.line	543	gettabup      r7    u0   k62 ; k62 = "FuncUtil"
.line	543	gettable      r7    r7   k99 ; k99 = "arrBanStoreList"
.line	543	len           r7    r7
.line	543	add           r7    r7   k51 ; k51 = 1
.line	543	gettable      r8    r1    r5
.line	543	settable      r6    r7    r8
.line	543	move          r0    r0
.line	543	jmp            0  l334
.label	l334
.line	543	gettabup      r1    u0    k0 ; k0 = "log"
.line	543	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	543	test          r2     0
.line	543	jmp            0  l386
.line	543	getupval      r2    u1
.line	543	loadk         r3    k2 ; k2 = 38
.line	543	loadk         r4    k3 ; k3 = 141
.line	543	loadk         r5    k4 ; k4 = 43
.line	543	loadk         r6    k5 ; k5 = 202
.line	543	loadk         r7    k6 ; k6 = 230
.line	543	loadk         r8    k7 ; k7 = 59
.line	543	loadk         r9    k8 ; k8 = 143
.line	543	loadk        r10    k9 ; k9 = 65
.line	543	loadk        r11   k10 ; k10 = 214
.line	543	loadk        r12   k11 ; k11 = 217
.line	543	loadk        r13   k12 ; k12 = 201
.line	543	loadk        r14   k13 ; k13 = 4
.line	543	loadk        r15   k14 ; k14 = 72
.line	543	loadk        r16   k15 ; k15 = 19
.line	543	loadk        r17   k16 ; k16 = 96
.line	543	loadk        r18   k12 ; k12 = 201
.line	543	loadk        r19   k17 ; k17 = 255
.line	543	loadk        r20   k18 ; k18 = 188
.line	543	loadk        r21   k19 ; k19 = 80
.line	543	loadk        r22   k20 ; k20 = 218
.line	543	loadk        r23   k21 ; k21 = 37
.line	543	loadk        r24   k22 ; k22 = 24
.line	543	loadk        r25   k41 ; k41 = 182
.line	543	loadk        r26   k42 ; k42 = 61
.line	543	loadk        r27   k64 ; k64 = 137
.line	543	loadk        r28   k65 ; k65 = 242
.line	543	loadk        r29   k66 ; k66 = 197
.line	543	loadk        r30   k67 ; k67 = 63
.line	543	loadk        r31   k68 ; k68 = 77
.line	543	loadk        r32   k67 ; k67 = 63
.line	543	loadk        r33  k100 ; k100 = 70
.line	543	loadk        r34   k58 ; k58 = 192
.line	543	loadk        r35   k49 ; k49 = 239
.line	543	loadk        r36   k43 ; k43 = 170
.line	543	loadk        r37   k50 ; k50 = 64
.line	543	loadk        r38   k66 ; k66 = 197
.line	543	loadk        r39  k101 ; k101 = 58
.line	543	loadk        r40  k102 ; k102 = 28
.line	543	loadk        r41   k65 ; k65 = 242
.line	543	loadk        r42   k57 ; k57 = 55
.line	543	call          r2    41     2
.line	543	getupval      r3    u3
.line	543	gettabup      r4    u0   k62 ; k62 = "FuncUtil"
.line	543	gettable      r4    r4   k63 ; k63 = "arrBanIPAreaList"
.line	543	len           r4    r4
.line	543	call          r3     2     2
.line	543	concat        r2    r2    r3
.label	l386
.line	543	call          r1     2     1
.line	543	getupval      r1    u2
.line	543	getupval      r2    u1
.line	543	loadk         r3  k103 ; k103 = 35
.line	543	loadk         r4   k79 ; k79 = 148
.line	543	loadk         r5  k104 ; k104 = 44
.line	543	loadk         r6   k91 ; k91 = 204
.line	543	loadk         r7   k59 ; k59 = 221
.line	543	loadk         r8    k7 ; k7 = 59
.line	543	loadk         r9  k105 ; k105 = 179
.line	543	loadk        r10  k106 ; k106 = 93
.line	543	loadk        r11   k98 ; k98 = 159
.line	543	loadk        r12  k107 ; k107 = 226
.line	543	loadk        r13  k108 ; k108 = 198
.line	543	loadk        r14   k97 ; k97 = 9
.line	543	loadk        r15  k109 ; k109 = 89
.line	543	loadk        r16  k110 ; k110 = 13
.line	543	loadk        r17  k111 ; k111 = 108
.line	543	loadk        r18    k5 ; k5 = 202
.line	543	loadk        r19  k112 ; k112 = 251
.line	543	loadk        r20  k113 ; k113 = 139
.line	543	loadk        r21   k75 ; k75 = 90
.line	543	loadk        r22   k38 ; k38 = 247
.line	543	loadk        r23   k21 ; k21 = 37
.line	543	loadk        r24  k114 ; k114 = 22
.line	543	loadk        r25  k115 ; k115 = 241
.line	543	call          r2    24     2
.line	543	getupval      r3    u1
.line	543	call          r3     1     2
.line	543	call          r1     3     2
.line	543	move          r0    r1
.line	543	gettabup      r1    u0    k0 ; k0 = "log"
.line	543	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	543	test          r2     0
.line	543	jmp            0  l482
.line	543	gettabup      r2    u0   k39 ; k39 = "table"
.line	543	gettable      r2    r2   k40 ; k40 = "concat"
.line	543	newtable      r3     1     0
.line	543	getupval      r4    u1
.line	543	loadk         r5    k2 ; k2 = 38
.line	543	loadk         r6    k3 ; k3 = 141
.line	543	loadk         r7    k4 ; k4 = 43
.line	543	loadk         r8    k5 ; k5 = 202
.line	543	loadk         r9    k6 ; k6 = 230
.line	543	loadk        r10    k7 ; k7 = 59
.line	543	loadk        r11    k8 ; k8 = 143
.line	543	loadk        r12    k9 ; k9 = 65
.line	543	loadk        r13   k10 ; k10 = 214
.line	543	loadk        r14   k11 ; k11 = 217
.line	543	loadk        r15   k12 ; k12 = 201
.line	543	loadk        r16   k13 ; k13 = 4
.line	543	loadk        r17   k14 ; k14 = 72
.line	543	loadk        r18   k15 ; k15 = 19
.line	543	loadk        r19   k16 ; k16 = 96
.line	543	loadk        r20   k12 ; k12 = 201
.line	543	loadk        r21   k17 ; k17 = 255
.line	543	loadk        r22   k18 ; k18 = 188
.line	543	loadk        r23   k19 ; k19 = 80
.line	543	loadk        r24   k20 ; k20 = 218
.line	543	loadk        r25   k21 ; k21 = 37
.line	543	loadk        r26   k22 ; k22 = 24
.line	543	loadk        r27   k41 ; k41 = 182
.line	543	loadk        r28   k42 ; k42 = 61
.line	543	loadk        r29  k116 ; k116 = 171
.line	543	loadk        r30  k117 ; k117 = 236
.line	543	loadk        r31  k118 ; k118 = 222
.line	543	loadk        r32   k22 ; k22 = 24
.line	543	loadk        r33  k119 ; k119 = 66
.line	543	loadk        r34   k21 ; k21 = 37
.line	543	loadk        r35   k50 ; k50 = 64
.line	543	loadk        r36  k120 ; k120 = 196
.line	543	loadk        r37  k121 ; k121 = 231
.line	543	loadk        r38   k43 ; k43 = 170
.line	543	loadk        r39  k122 ; k122 = 68
.line	543	loadk        r40  k123 ; k123 = 237
.line	543	loadk        r41  k124 ; k124 = 54
.line	543	loadk        r42  k103 ; k103 = 35
.line	543	loadk        r43   k49 ; k49 = 239
.line	543	loadk        r44   k36 ; k36 = 99
.line	543	call          r4    41     2
.line	543	getupval      r5    u1
.line	543	loadk         r6  k125 ; k125 = 11
.line	543	loadk         r7  k126 ; k126 = 187
.line	543	loadk         r8   k27 ; k27 = 42
.line	543	loadk         r9   k77 ; k77 = 199
.line	543	loadk        r10  k127 ; k127 = 213
.line	543	loadk        r11    k2 ; k2 = 38
.line	543	loadk        r12  k128 ; k128 = 129
.line	543	loadk        r13  k129 ; k129 = 23
.line	543	call          r5     9     0
.line	543	setlist       r3     0     1
.line	543	call          r2     2     2
.line	543	getupval      r3    u3
.line	543	move          r4    r0
.line	543	call          r3     2     2
.line	543	concat        r2    r2    r3
.label	l482
.line	543	call          r1     2     1
.line	543	eq             1    r0   k55 ; k55 = nil
.line	543	jmp            0  l518
.line	543	getupval      r1    u4
.line	543	move          r2    r0
.line	543	call          r1     2     2
.line	543	getupval      r2    u1
.line	543	loadk         r3   k15 ; k15 = 19
.line	543	loadk         r4   k56 ; k56 = 140
.line	543	loadk         r5   k57 ; k57 = 55
.line	543	loadk         r6   k58 ; k58 = 192
.line	543	loadk         r7   k59 ; k59 = 221
.line	543	loadk         r8   k60 ; k60 = 40
.line	543	call          r2     7     2
.line	543	eq             0    r1    r2
.line	543	jmp            0  l518
.line	543	len           r1    r0
.line	543	lt             0   k61    r1 ; k61 = 2
.line	543	jmp            0  l518
.line	543	getupval      r1    u5
.line	543	move          r2    r0
.line	543	call          r1     2     2
.line	543	loadk         r2   k51 ; k51 = 1
.line	543	len           r3    r1
.line	543	loadk         r4   k51 ; k51 = 1
.line	543	move          r0    r0
.line	543	gettabup      r6    u0   k62 ; k62 = "FuncUtil"
.line	543	gettable      r6    r6  k130 ; k130 = "arrNotGPUpgradeLink"
.line	543	gettabup      r7    u0   k62 ; k62 = "FuncUtil"
.line	543	gettable      r7    r7  k130 ; k130 = "arrNotGPUpgradeLink"
.line	543	len           r7    r7
.line	543	add           r7    r7   k51 ; k51 = 1
.line	543	gettable      r8    r1    r5
.line	543	settable      r6    r7    r8
.line	543	move          r0    r0
.line	543	jmp            0  l518
.label	l518
.line	543	gettabup      r1    u0    k0 ; k0 = "log"
.line	543	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	543	test          r2     0
.line	543	jmp            0  l581
.line	543	gettabup      r2    u0   k39 ; k39 = "table"
.line	543	gettable      r2    r2   k40 ; k40 = "concat"
.line	543	newtable      r3     1     0
.line	543	getupval      r4    u1
.line	543	loadk         r5    k2 ; k2 = 38
.line	543	loadk         r6    k3 ; k3 = 141
.line	543	loadk         r7    k4 ; k4 = 43
.line	543	loadk         r8    k5 ; k5 = 202
.line	543	loadk         r9    k6 ; k6 = 230
.line	543	loadk        r10    k7 ; k7 = 59
.line	543	loadk        r11    k8 ; k8 = 143
.line	543	loadk        r12    k9 ; k9 = 65
.line	543	loadk        r13   k10 ; k10 = 214
.line	543	loadk        r14   k11 ; k11 = 217
.line	543	loadk        r15   k12 ; k12 = 201
.line	543	loadk        r16   k13 ; k13 = 4
.line	543	loadk        r17   k14 ; k14 = 72
.line	543	loadk        r18   k15 ; k15 = 19
.line	543	loadk        r19   k16 ; k16 = 96
.line	543	loadk        r20   k12 ; k12 = 201
.line	543	loadk        r21   k17 ; k17 = 255
.line	543	loadk        r22   k18 ; k18 = 188
.line	543	loadk        r23   k19 ; k19 = 80
.line	543	loadk        r24   k20 ; k20 = 218
.line	543	loadk        r25   k21 ; k21 = 37
.line	543	loadk        r26   k22 ; k22 = 24
.line	543	loadk        r27   k41 ; k41 = 182
.line	543	loadk        r28   k42 ; k42 = 61
.line	543	loadk        r29   k64 ; k64 = 137
.line	543	loadk        r30   k65 ; k65 = 242
.line	543	loadk        r31   k66 ; k66 = 197
.line	543	loadk        r32  k131 ; k131 = 51
.line	543	loadk        r33  k132 ; k132 = 67
.line	543	loadk        r34   k21 ; k21 = 37
.line	543	loadk        r35  k133 ; k133 = 82
.line	543	loadk        r36   k70 ; k70 = 228
.line	543	loadk        r37  k127 ; k127 = 213
.line	543	loadk        r38  k134 ; k134 = 168
.line	543	loadk        r39  k119 ; k119 = 66
.line	543	loadk        r40  k112 ; k112 = 251
.line	543	loadk        r41  k135 ; k135 = 50
.line	543	loadk        r42  k125 ; k125 = 11
.line	543	loadk        r43  k136 ; k136 = 227
.line	543	loadk        r44    k9 ; k9 = 65
.line	543	call          r4    41     2
.line	543	getupval      r5    u1
.line	543	loadk         r6   k97 ; k97 = 9
.line	543	loadk         r7  k137 ; k137 = 150
.line	543	loadk         r8   k33 ; k33 = 46
.line	543	loadk         r9  k138 ; k138 = 147
.line	543	call          r5     5     0
.line	543	setlist       r3     0     1
.line	543	call          r2     2     2
.line	543	getupval      r3    u3
.line	543	gettabup      r4    u0   k62 ; k62 = "FuncUtil"
.line	543	gettable      r4    r4  k130 ; k130 = "arrNotGPUpgradeLink"
.line	543	len           r4    r4
.line	543	call          r3     2     2
.line	543	concat        r2    r2    r3
.label	l581
.line	543	call          r1     2     1
.line	543	gettabup      r1    u0   k62 ; k62 = "FuncUtil"
.line	543	getupval      r2    u7
.line	543	getupval      r3    u1
.line	543	loadk         r4  k135 ; k135 = 50
.line	543	loadk         r5  k140 ; k140 = 157
.line	543	loadk         r6   k60 ; k60 = 40
.line	543	loadk         r7  k108 ; k108 = 198
.line	543	loadk         r8   k77 ; k77 = 199
.line	543	loadk         r9   k27 ; k27 = 42
.line	543	loadk        r10  k141 ; k141 = 165
.line	543	loadk        r11  k142 ; k142 = 75
.line	543	loadk        r12   k98 ; k98 = 159
.line	543	loadk        r13  k143 ; k143 = 211
.line	543	loadk        r14  k144 ; k144 = 200
.line	543	loadk        r15   k22 ; k22 = 24
.line	543	loadk        r16  k133 ; k133 = 82
.line	543	loadk        r17  k145 ; k145 = 53
.line	543	loadk        r18  k146 ; k146 = 119
.line	543	loadk        r19   k59 ; k59 = 221
.line	543	loadk        r20  k143 ; k143 = 211
.line	543	loadk        r21  k147 ; k147 = 167
.line	543	loadk        r22  k148 ; k148 = 81
.line	543	loadk        r23  k149 ; k149 = 252
.line	543	call          r3    21     2
.line	543	loadk         r4   k96 ; k96 = 0
.line	543	call          r2     3     2
.line	543	settable      r1  k139    r2 ; k139 = "remoteCfgCountryCode"
.line	543	gettabup      r1    u0   k62 ; k62 = "FuncUtil"
.line	543	getupval      r2    u7
.line	543	getupval      r3    u1
.line	543	loadk         r4   k47 ; k47 = 52
.line	543	loadk         r5    k3 ; k3 = 141
.line	543	loadk         r6   k57 ; k57 = 55
.line	543	loadk         r7   k77 ; k77 = 199
.line	543	loadk         r8  k149 ; k149 = 252
.line	543	loadk         r9  k151 ; k151 = 33
.line	543	loadk        r10  k141 ; k141 = 165
.line	543	loadk        r11    k9 ; k9 = 65
.line	543	loadk        r12  k152 ; k152 = 145
.line	543	loadk        r13   k73 ; k73 = 245
.line	543	loadk        r14   k12 ; k12 = 201
.line	543	loadk        r15   k83 ; k83 = 25
.line	543	loadk        r16  k153 ; k153 = 111
.line	543	loadk        r17  k154 ; k154 = 49
.line	543	loadk        r18   k16 ; k16 = 96
.line	543	loadk        r19   k25 ; k25 = 232
.line	543	loadk        r20  k115 ; k115 = 241
.line	543	loadk        r21   k43 ; k43 = 170
.line	543	loadk        r22   k19 ; k19 = 80
.line	543	loadk        r23   k73 ; k73 = 245
.line	543	call          r3    21     2
.line	543	loadk         r4   k96 ; k96 = 0
.line	543	call          r2     3     2
.line	543	settable      r1  k150    r2 ; k150 = "turnOnClientSpeLabel"
.line	543	gettabup      r1    u0   k62 ; k62 = "FuncUtil"
.line	543	getupval      r2    u7
.line	543	getupval      r3    u1
.line	543	loadk         r4  k135 ; k135 = 50
.line	543	loadk         r5  k140 ; k140 = 157
.line	543	loadk         r6   k60 ; k60 = 40
.line	543	loadk         r7  k108 ; k108 = 198
.line	543	loadk         r8   k77 ; k77 = 199
.line	543	loadk         r9   k27 ; k27 = 42
.line	543	loadk        r10  k141 ; k141 = 165
.line	543	loadk        r11  k142 ; k142 = 75
.line	543	loadk        r12   k98 ; k98 = 159
.line	543	loadk        r13  k156 ; k156 = 210
.line	543	loadk        r14  k108 ; k108 = 198
.line	543	loadk        r15  k157 ; k157 = 30
.line	543	loadk        r16  k109 ; k109 = 89
.line	543	loadk        r17  k158 ; k158 = 17
.line	543	loadk        r18  k146 ; k146 = 119
.line	543	loadk        r19   k26 ; k26 = 193
.line	543	loadk        r20   k10 ; k10 = 214
.line	543	loadk        r21  k159 ; k159 = 173
.line	543	loadk        r22    k9 ; k9 = 65
.line	543	loadk        r23   k76 ; k76 = 250
.line	543	loadk        r24    k4 ; k4 = 43
.line	543	call          r3    22     2
.line	543	loadk         r4   k96 ; k96 = 0
.line	543	call          r2     3     2
.line	543	settable      r1  k155    r2 ; k155 = "remoteCfgBasePreFetc" (truncated)
.line	543	gettabup      r1    u0  k160 ; k160 = "PufferDownloader"
.line	543	gettable      r1    r1  k161 ; k161 = "SetEnableBackpackCac" (truncated)
.line	543	loadk         r2   k96 ; k96 = 0
.line	543	call          r1     2     1
.line	543	gettabup      r1    u0   k62 ; k62 = "FuncUtil"
.line	543	gettable      r1    r1  k162 ; k162 = "defaultJumpLink"
.line	543	test          r1     0
.line	543	jmp            0  l678
.line	543	gettabup      r1    u0   k62 ; k62 = "FuncUtil"
.line	543	gettable      r1    r1  k162 ; k162 = "defaultJumpLink"
.line	543	getupval      r2    u1
.line	543	call          r2     1     2
.line	543	eq             0    r1    r2
.line	543	jmp            0  l688
.label	l678
.line	543	gettabup      r1    u0   k62 ; k62 = "FuncUtil"
.line	543	gettabup      r2    u0   k62 ; k62 = "FuncUtil"
.line	543	gettable      r2    r2  k163 ; k163 = "GetDomainByID"
.line	543	loadk         r3  k164 ; k164 = 3366055
.line	543	call          r2     2     2
.line	543	test          r2     1
.line	543	jmp            0  l687
.line	543	getupval      r2    u1
.line	543	call          r2     1     2
.label	l687
.line	543	settable      r1  k162    r2 ; k162 = "defaultJumpLink"
.label	l688
.line	543	getupval      r1    u2
.line	543	getupval      r2    u1
.line	543	loadk         r3  k165 ; k165 = 36
.line	543	loadk         r4  k140 ; k140 = 157
.line	543	loadk         r5  k103 ; k103 = 35
.line	543	loadk         r6  k144 ; k144 = 200
.line	543	loadk         r7  k108 ; k108 = 198
.line	543	loadk         r8  k103 ; k103 = 35
.line	543	loadk         r9  k166 ; k166 = 146
.line	543	loadk        r10   k89 ; k89 = 103
.line	543	loadk        r11    k3 ; k3 = 141
.line	543	loadk        r12   k94 ; k94 = 253
.line	543	loadk        r13  k167 ; k167 = 215
.line	543	loadk        r14  k151 ; k151 = 33
.line	543	loadk        r15  k168 ; k168 = 85
.line	543	loadk        r16   k35 ; k35 = 47
.line	543	loadk        r17   k29 ; k29 = 110
.line	543	call          r2    16     2
.line	543	getupval      r3    u1
.line	543	call          r3     1     2
.line	543	call          r1     3     2
.line	543	getupval      r2    u1
.line	543	call          r2     1     2
.line	543	eq             1    r2    r1
.line	543	jmp            0  l715
.line	543	gettabup      r2    u0   k62 ; k62 = "FuncUtil"
.line	543	settable      r2  k162    r1 ; k162 = "defaultJumpLink"
.label	l715
.line	543	getupval      r2    u8
.line	543	gettabup      r3    u0   k39 ; k39 = "table"
.line	543	gettable      r3    r3   k40 ; k40 = "concat"
.line	543	newtable      r4     1     0
.line	543	getupval      r5    u1
.line	543	loadk         r6  k169 ; k169 = 3
.line	543	loadk         r7   k79 ; k79 = 148
.line	543	loadk         r8  k104 ; k104 = 44
.line	543	loadk         r9   k91 ; k91 = 204
.line	543	loadk        r10   k59 ; k59 = 221
.line	543	loadk        r11    k7 ; k7 = 59
.line	543	loadk        r12  k144 ; k144 = 200
.line	543	loadk        r13    k9 ; k9 = 65
.line	543	loadk        r14   k30 ; k30 = 151
.line	543	loadk        r15   k38 ; k38 = 247
.line	543	loadk        r16  k170 ; k170 = 206
.line	543	loadk        r17  k171 ; k171 = 14
.line	543	loadk        r18  k172 ; k172 = 18
.line	543	loadk        r19  k110 ; k110 = 13
.line	543	loadk        r20  k173 ; k173 = 106
.line	543	loadk        r21  k174 ; k174 = 195
.line	543	loadk        r22   k81 ; k81 = 249
.line	543	loadk        r23  k116 ; k116 = 171
.line	543	loadk        r24  k175 ; k175 = 101
.line	543	loadk        r25   k73 ; k73 = 245
.line	543	loadk        r26   k23 ; k23 = 34
.line	543	loadk        r27   k72 ; k72 = 6
.line	543	loadk        r28  k176 ; k176 = 243
.line	543	loadk        r29  k153 ; k153 = 111
.line	543	loadk        r30  k177 ; k177 = 184
.line	543	loadk        r31   k65 ; k65 = 242
.line	543	loadk        r32  k156 ; k156 = 210
.line	543	loadk        r33  k178 ; k178 = 27
.line	543	loadk        r34  k179 ; k179 = 95
.line	543	loadk        r35   k84 ; k84 = 127
.line	543	loadk        r36  k175 ; k175 = 101
.line	543	loadk        r37  k180 ; k180 = 216
.line	543	loadk        r38   k44 ; k44 = 225
.line	543	loadk        r39  k181 ; k181 = 161
.line	543	loadk        r40   k50 ; k50 = 64
.line	543	loadk        r41  k112 ; k112 = 251
.line	543	loadk        r42  k103 ; k103 = 35
.line	543	loadk        r43  k182 ; k182 = 29
.line	543	loadk        r44  k136 ; k136 = 227
.line	543	loadk        r45   k85 ; k85 = 107
.line	543	call          r5    41     2
.line	543	getupval      r6    u1
.line	543	loadk         r7   k15 ; k15 = 19
.line	543	call          r6     2     0
.line	543	setlist       r4     0     1
.line	543	call          r3     2     2
.line	543	call          r2     2     2
.line	543	gettable      r3    r2  k183 ; k183 = "LoadFileToTable_N"
.line	543	gettable      r4    r2  k184 ; k184 = "ePlayerPrefsType"
.line	543	gettable      r4    r4  k185 ; k185 = "eLoginBackUpLastCoun" (truncated)
.line	543	call          r3     2     2
.line	543	eq             1    r3   k55 ; k55 = nil
.line	543	jmp            0  l783
.line	543	getupval      r4    u6
.line	543	gettable      r5    r3  k186 ; k186 = "LastCountryNo"
.line	543	call          r4     2     2
.line	543	eq             1    r4   k55 ; k55 = nil
.line	543	jmp            0  l783
.line	543	gettabup      r4    u0   k62 ; k62 = "FuncUtil"
.line	543	getupval      r5    u6
.line	543	gettable      r6    r3  k186 ; k186 = "LastCountryNo"
.line	543	call          r5     2     2
.line	543	settable      r4  k187    r5 ; k187 = "localCountryCode"
.label	l783
.line	543	gettabup      r4    u0  k188 ; k188 = "Client"
.line	543	gettable      r4    r4  k189 ; k189 = "GetIPRegion"
.line	543	call          r4     1     2
.line	543	lt             0   k96    r4 ; k96 = 0
.line	543	jmp            0  l860
.line	543	gettabup      r5    u0   k62 ; k62 = "FuncUtil"
.line	543	gettable      r5    r5  k187 ; k187 = "localCountryCode"
.line	543	le             0    r5   k96 ; k96 = 0
.line	543	jmp            0  l860
.line	543	newtable      r5     0     0
.line	543	settable      r5  k186    r4 ; k186 = "LastCountryNo"
.line	543	gettable      r6    r2  k190 ; k190 = "SaveTableToFile_N"
.line	543	move          r7    r5
.line	543	gettable      r8    r2  k184 ; k184 = "ePlayerPrefsType"
.line	543	gettable      r8    r8  k185 ; k185 = "eLoginBackUpLastCoun" (truncated)
.line	543	call          r6     3     1
.line	543	gettabup      r6    u0    k0 ; k0 = "log"
.line	543	gettabup      r7    u0    k1 ; k1 = "bWriteLog"
.line	543	test          r7     0
.line	543	jmp            0  l859
.line	543	gettabup      r7    u0   k39 ; k39 = "table"
.line	543	gettable      r7    r7   k40 ; k40 = "concat"
.line	543	newtable      r8     1     0
.line	543	getupval      r9    u1
.line	543	loadk        r10    k2 ; k2 = 38
.line	543	loadk        r11    k3 ; k3 = 141
.line	543	loadk        r12    k4 ; k4 = 43
.line	543	loadk        r13    k5 ; k5 = 202
.line	543	loadk        r14    k6 ; k6 = 230
.line	543	loadk        r15    k7 ; k7 = 59
.line	543	loadk        r16    k8 ; k8 = 143
.line	543	loadk        r17    k9 ; k9 = 65
.line	543	loadk        r18   k10 ; k10 = 214
.line	543	loadk        r19   k11 ; k11 = 217
.line	543	loadk        r20   k12 ; k12 = 201
.line	543	loadk        r21   k13 ; k13 = 4
.line	543	loadk        r22   k14 ; k14 = 72
.line	543	loadk        r23   k15 ; k15 = 19
.line	543	loadk        r24   k16 ; k16 = 96
.line	543	loadk        r25   k12 ; k12 = 201
.line	543	loadk        r26   k17 ; k17 = 255
.line	543	loadk        r27   k18 ; k18 = 188
.line	543	loadk        r28   k19 ; k19 = 80
.line	543	loadk        r29   k20 ; k20 = 218
.line	543	loadk        r30   k21 ; k21 = 37
.line	543	loadk        r31   k22 ; k22 = 24
.line	543	loadk        r32   k41 ; k41 = 182
.line	543	loadk        r33  k191 ; k191 = 78
.line	543	loadk        r34   k64 ; k64 = 137
.line	543	loadk        r35  k192 ; k192 = 246
.line	543	loadk        r36  k156 ; k156 = 210
.line	543	loadk        r37   k83 ; k83 = 25
.line	543	loadk        r38  k193 ; k193 = 12
.line	543	loadk        r39  k182 ; k182 = 29
.line	543	loadk        r40   k48 ; k48 = 116
.line	543	loadk        r41   k77 ; k77 = 199
.line	543	loadk        r42   k31 ; k31 = 244
.line	543	loadk        r43  k194 ; k194 = 155
.line	543	loadk        r44  k195 ; k195 = 74
.line	543	loadk        r45  k149 ; k149 = 252
.line	543	loadk        r46   k42 ; k42 = 61
.line	543	loadk        r47  k178 ; k178 = 27
.line	543	loadk        r48   k31 ; k31 = 244
.line	543	loadk        r49   k48 ; k48 = 116
.line	543	call          r9    41     2
.line	543	getupval     r10    u1
.line	543	loadk        r11   k33 ; k33 = 46
.line	543	loadk        r12   k30 ; k30 = 151
.line	543	loadk        r13   k84 ; k84 = 127
.line	543	call         r10     4     0
.line	543	setlist       r8     0     1
.line	543	call          r7     2     2
.line	543	getupval      r8    u3
.line	543	gettable      r9    r5  k186 ; k186 = "LastCountryNo"
.line	543	call          r8     2     2
.line	543	concat        r7    r7    r8
.label	l859
.line	543	call          r6     2     1
.label	l860
.line	543	gettabup      r5    u0    k0 ; k0 = "log"
.line	543	gettabup      r6    u0    k1 ; k1 = "bWriteLog"
.line	543	test          r6     0
.line	543	jmp            0  l923
.line	543	gettabup      r6    u0   k39 ; k39 = "table"
.line	543	gettable      r6    r6   k40 ; k40 = "concat"
.line	543	newtable      r7     1     0
.line	543	getupval      r8    u1
.line	543	loadk         r9    k2 ; k2 = 38
.line	543	loadk        r10    k3 ; k3 = 141
.line	543	loadk        r11    k4 ; k4 = 43
.line	543	loadk        r12    k5 ; k5 = 202
.line	543	loadk        r13    k6 ; k6 = 230
.line	543	loadk        r14    k7 ; k7 = 59
.line	543	loadk        r15    k8 ; k8 = 143
.line	543	loadk        r16    k9 ; k9 = 65
.line	543	loadk        r17   k10 ; k10 = 214
.line	543	loadk        r18   k11 ; k11 = 217
.line	543	loadk        r19   k12 ; k12 = 201
.line	543	loadk        r20   k13 ; k13 = 4
.line	543	loadk        r21   k14 ; k14 = 72
.line	543	loadk        r22   k15 ; k15 = 19
.line	543	loadk        r23   k16 ; k16 = 96
.line	543	loadk        r24   k12 ; k12 = 201
.line	543	loadk        r25   k17 ; k17 = 255
.line	543	loadk        r26   k18 ; k18 = 188
.line	543	loadk        r27   k19 ; k19 = 80
.line	543	loadk        r28   k20 ; k20 = 218
.line	543	loadk        r29   k21 ; k21 = 37
.line	543	loadk        r30   k22 ; k22 = 24
.line	543	loadk        r31   k41 ; k41 = 182
.line	543	loadk        r32   k42 ; k42 = 61
.line	543	loadk        r33  k196 ; k196 = 154
.line	543	loadk        r34  k197 ; k197 = 229
.line	543	loadk        r35   k20 ; k20 = 218
.line	543	loadk        r36  k172 ; k172 = 18
.line	543	loadk        r37   k87 ; k87 = 88
.line	543	loadk        r38   k47 ; k47 = 52
.line	543	loadk        r39   k93 ; k93 = 86
.line	543	loadk        r40  k156 ; k156 = 210
.line	543	loadk        r41  k121 ; k121 = 231
.line	543	loadk        r42  k194 ; k194 = 155
.line	543	loadk        r43  k195 ; k195 = 74
.line	543	loadk        r44  k149 ; k149 = 252
.line	543	loadk        r45   k42 ; k42 = 61
.line	543	loadk        r46  k178 ; k178 = 27
.line	543	loadk        r47   k31 ; k31 = 244
.line	543	loadk        r48   k48 ; k48 = 116
.line	543	call          r8    41     2
.line	543	getupval      r9    u1
.line	543	loadk        r10  k103 ; k103 = 35
.line	543	loadk        r11   k30 ; k30 = 151
.line	543	loadk        r12  k151 ; k151 = 33
.line	543	loadk        r13   k91 ; k91 = 204
.line	543	loadk        r14   k64 ; k64 = 137
.line	543	call          r9     6     0
.line	543	setlist       r7     0     1
.line	543	call          r6     2     2
.line	543	getupval      r7    u3
.line	543	gettabup      r8    u0   k62 ; k62 = "FuncUtil"
.line	543	gettable      r8    r8  k139 ; k139 = "remoteCfgCountryCode"
.line	543	call          r7     2     2
.line	543	concat        r6    r6    r7
.label	l923
.line	543	call          r5     2     1
.line	543	gettabup      r5    u0    k0 ; k0 = "log"
.line	543	gettabup      r6    u0    k1 ; k1 = "bWriteLog"
.line	543	test          r6     0
.line	543	jmp            0  l987
.line	543	gettabup      r6    u0   k39 ; k39 = "table"
.line	543	gettable      r6    r6   k40 ; k40 = "concat"
.line	543	newtable      r7     1     0
.line	543	getupval      r8    u1
.line	543	loadk         r9    k2 ; k2 = 38
.line	543	loadk        r10    k3 ; k3 = 141
.line	543	loadk        r11    k4 ; k4 = 43
.line	543	loadk        r12    k5 ; k5 = 202
.line	543	loadk        r13    k6 ; k6 = 230
.line	543	loadk        r14    k7 ; k7 = 59
.line	543	loadk        r15    k8 ; k8 = 143
.line	543	loadk        r16    k9 ; k9 = 65
.line	543	loadk        r17   k10 ; k10 = 214
.line	543	loadk        r18   k11 ; k11 = 217
.line	543	loadk        r19   k12 ; k12 = 201
.line	543	loadk        r20   k13 ; k13 = 4
.line	543	loadk        r21   k14 ; k14 = 72
.line	543	loadk        r22   k15 ; k15 = 19
.line	543	loadk        r23   k16 ; k16 = 96
.line	543	loadk        r24   k12 ; k12 = 201
.line	543	loadk        r25   k17 ; k17 = 255
.line	543	loadk        r26   k18 ; k18 = 188
.line	543	loadk        r27   k19 ; k19 = 80
.line	543	loadk        r28   k20 ; k20 = 218
.line	543	loadk        r29   k21 ; k21 = 37
.line	543	loadk        r30   k22 ; k22 = 24
.line	543	loadk        r31   k41 ; k41 = 182
.line	543	loadk        r32   k42 ; k42 = 61
.line	543	loadk        r33  k198 ; k198 = 156
.line	543	loadk        r34   k73 ; k73 = 245
.line	543	loadk        r35   k66 ; k66 = 197
.line	543	loadk        r36   k15 ; k15 = 19
.line	543	loadk        r37   k36 ; k36 = 99
.line	543	loadk        r38   k67 ; k67 = 63
.line	543	loadk        r39   k93 ; k93 = 86
.line	543	loadk        r40  k180 ; k180 = 216
.line	543	loadk        r41  k199 ; k199 = 233
.line	543	loadk        r42  k200 ; k200 = 189
.line	543	loadk        r43  k142 ; k142 = 75
.line	543	loadk        r44   k94 ; k94 = 253
.line	543	loadk        r45   k96 ; k96 = 0
.line	543	loadk        r46   k71 ; k71 = 31
.line	543	loadk        r47  k136 ; k136 = 227
.line	543	loadk        r48    k9 ; k9 = 65
.line	543	call          r8    41     2
.line	543	getupval      r9    u1
.line	543	loadk        r10   k51 ; k51 = 1
.line	543	loadk        r11  k196 ; k196 = 154
.line	543	loadk        r12   k78 ; k78 = 32
.line	543	loadk        r13   k66 ; k66 = 197
.line	543	loadk        r14   k64 ; k64 = 137
.line	543	call          r9     6     0
.line	543	setlist       r7     0     1
.line	543	call          r6     2     2
.line	543	getupval      r7    u3
.line	543	gettabup      r8    u0   k62 ; k62 = "FuncUtil"
.line	543	gettable      r8    r8  k150 ; k150 = "turnOnClientSpeLabel"
.line	543	call          r7     2     2
.line	543	concat        r6    r6    r7
.label	l987
.line	543	call          r5     2     1
.line	543	gettabup      r5    u0    k0 ; k0 = "log"
.line	543	gettabup      r6    u0    k1 ; k1 = "bWriteLog"
.line	543	test          r6     0
.line	543	jmp            0 l1037
.line	543	getupval      r6    u1
.line	543	loadk         r7    k2 ; k2 = 38
.line	543	loadk         r8    k3 ; k3 = 141
.line	543	loadk         r9    k4 ; k4 = 43
.line	543	loadk        r10    k5 ; k5 = 202
.line	543	loadk        r11    k6 ; k6 = 230
.line	543	loadk        r12    k7 ; k7 = 59
.line	543	loadk        r13    k8 ; k8 = 143
.line	543	loadk        r14    k9 ; k9 = 65
.line	543	loadk        r15   k10 ; k10 = 214
.line	543	loadk        r16   k11 ; k11 = 217
.line	543	loadk        r17   k12 ; k12 = 201
.line	543	loadk        r18   k13 ; k13 = 4
.line	543	loadk        r19   k14 ; k14 = 72
.line	543	loadk        r20   k15 ; k15 = 19
.line	543	loadk        r21   k16 ; k16 = 96
.line	543	loadk        r22   k12 ; k12 = 201
.line	543	loadk        r23   k17 ; k17 = 255
.line	543	loadk        r24   k18 ; k18 = 188
.line	543	loadk        r25   k19 ; k19 = 80
.line	543	loadk        r26   k20 ; k20 = 218
.line	543	loadk        r27   k21 ; k21 = 37
.line	543	loadk        r28   k22 ; k22 = 24
.line	543	loadk        r29   k41 ; k41 = 182
.line	543	loadk        r30   k42 ; k42 = 61
.line	543	loadk        r31  k201 ; k201 = 164
.line	543	loadk        r32   k44 ; k44 = 225
.line	543	loadk        r33  k120 ; k120 = 196
.line	543	loadk        r34   k97 ; k97 = 9
.line	543	loadk        r35  k153 ; k153 = 111
.line	543	loadk        r36   k88 ; k88 = 62
.line	543	loadk        r37   k16 ; k16 = 96
.line	543	loadk        r38   k20 ; k20 = 218
.line	543	loadk        r39   k31 ; k31 = 244
.line	543	loadk        r40   k43 ; k43 = 170
.line	543	loadk        r41   k69 ; k69 = 92
.line	543	loadk        r42   k77 ; k77 = 199
.line	543	loadk        r43   k45 ; k45 = 60
.line	543	loadk        r44  k168 ; k168 = 85
.line	543	call          r6    39     2
.line	543	getupval      r7    u3
.line	543	gettabup      r8    u0   k62 ; k62 = "FuncUtil"
.line	543	gettable      r8    r8  k187 ; k187 = "localCountryCode"
.line	543	call          r7     2     2
.line	543	concat        r6    r6    r7
.label	l1037
.line	543	call          r5     2     1
.line	543	return        r0     1
.line	543	gettabup      r0    u1   k62 ; k62 = "FuncUtil"
.line	543	move          r0    r0
.line	543	move          r0    r0
.line	543	return        r0     1

.function	main/f31

.source	null
.linedefined	606
.lastlinedefined	626
.numparams	0
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	23	true
.upvalue	"U2"	1	true
.upvalue	"U3"	24	true

.constant	k0	0
.constant	k1	"FuncUtil"
.constant	k2	"turnOnClientSpeLabel"
.constant	k3	"Client"
.constant	k4	"GetAreaIPNo"
.constant	k5	"log"
.constant	k6	"bWriteLog"
.constant	k7	38
.constant	k8	141
.constant	k9	43
.constant	k10	202
.constant	k11	230
.constant	k12	59
.constant	k13	143
.constant	k14	65
.constant	k15	214
.constant	k16	215
.constant	k17	194
.constant	k18	25
.constant	k19	127
.constant	k20	46
.constant	k21	112
.constant	k22	228
.constant	k23	186
.constant	k24	76
.constant	k25	208
.constant	k26	19
.constant	k27	60
.constant	k28	249
.constant	k29	121
.constant	k30	160
.constant	k31	151
.constant	k32	40
.constant	k33	95
.constant	k34	52
.constant	k35	53
.constant	k36	248
.constant	k37	225
.constant	k38	64
.constant	k39	229
.constant	k40	105
.constant	k41	79
.constant	k42	"GetIPRegion"
.constant	k43	221
.constant	k44	212
.constant	k45	183
.constant	k46	85
.constant	k47	179
.constant	k48	115
.constant	k49	"remoteCfgCountryCode"
.constant	k50	181
.constant	k51	74
.constant	k52	253
.constant	k53	54
.constant	k54	166
.constant	k55	"localCountryCode"
.constant	k56	239
.constant	k57	187
.constant	k58	68
.constant	k59	"table"
.constant	k60	"concat"
.constant	k61	14
.constant	k62	67
.constant	k63	63
.constant	k64	114
.constant	k65	243
.constant	k66	87
.constant	k67	236
.constant	k68	39
.constant	k69	26
.constant	k70	244
.constant	k71	99
.constant	k72	90
.constant	k73	216

.line	606	loadk         r0    k0 ; k0 = 0
.line	606	gettabup      r1    u0    k1 ; k1 = "FuncUtil"
.line	606	gettable      r1    r1    k2 ; k2 = "turnOnClientSpeLabel"
.line	606	lt             0    k0    r1 ; k0 = 0
.line	606	jmp            0   l61
.line	606	getupval      r1    u1
.line	606	gettabup      r2    u0    k3 ; k3 = "Client"
.line	606	gettable      r2    r2    k4 ; k4 = "GetAreaIPNo"
.line	606	call          r2     1     0
.line	606	call          r1     0     2
.line	606	move          r0    r1
.line	606	gettabup      r1    u0    k5 ; k5 = "log"
.line	606	gettabup      r2    u0    k6 ; k6 = "bWriteLog"
.line	606	test          r2     0
.line	606	jmp            0   l60
.line	606	getupval      r2    u2
.line	606	loadk         r3    k7 ; k7 = 38
.line	606	loadk         r4    k8 ; k8 = 141
.line	606	loadk         r5    k9 ; k9 = 43
.line	606	loadk         r6   k10 ; k10 = 202
.line	606	loadk         r7   k11 ; k11 = 230
.line	606	loadk         r8   k12 ; k12 = 59
.line	606	loadk         r9   k13 ; k13 = 143
.line	606	loadk        r10   k14 ; k14 = 65
.line	606	loadk        r11   k15 ; k15 = 214
.line	606	loadk        r12   k16 ; k16 = 215
.line	606	loadk        r13   k17 ; k17 = 194
.line	606	loadk        r14   k18 ; k18 = 25
.line	606	loadk        r15   k19 ; k19 = 127
.line	606	loadk        r16   k20 ; k20 = 46
.line	606	loadk        r17   k21 ; k21 = 112
.line	606	loadk        r18   k10 ; k10 = 202
.line	606	loadk        r19   k22 ; k22 = 228
.line	606	loadk        r20   k23 ; k23 = 186
.line	606	loadk        r21   k24 ; k24 = 76
.line	606	loadk        r22   k25 ; k25 = 208
.line	606	loadk        r23   k26 ; k26 = 19
.line	606	loadk        r24   k27 ; k27 = 60
.line	606	loadk        r25   k28 ; k28 = 249
.line	606	loadk        r26   k29 ; k29 = 121
.line	606	loadk        r27    k8 ; k8 = 141
.line	606	loadk        r28   k30 ; k30 = 160
.line	606	loadk        r29   k31 ; k31 = 151
.line	606	loadk        r30   k32 ; k32 = 40
.line	606	loadk        r31   k33 ; k33 = 95
.line	606	loadk        r32   k34 ; k34 = 52
.line	606	loadk        r33   k35 ; k35 = 53
.line	606	loadk        r34   k36 ; k36 = 248
.line	606	loadk        r35   k37 ; k37 = 225
.line	606	loadk        r36   k23 ; k23 = 186
.line	606	loadk        r37   k38 ; k38 = 64
.line	606	loadk        r38   k39 ; k39 = 229
.line	606	loadk        r39   k40 ; k40 = 105
.line	606	loadk        r40   k41 ; k41 = 79
.line	606	call          r2    39     2
.line	606	getupval      r3    u3
.line	606	move          r4    r0
.line	606	call          r3     2     2
.line	606	concat        r2    r2    r3
.label	l60
.line	606	call          r1     2     1
.label	l61
.line	606	eq             0    k0    r0 ; k0 = 0
.line	606	jmp            0  l115
.line	606	gettabup      r1    u0    k3 ; k3 = "Client"
.line	606	gettable      r1    r1   k42 ; k42 = "GetIPRegion"
.line	606	call          r1     1     2
.line	606	move          r0    r1
.line	606	gettabup      r1    u0    k5 ; k5 = "log"
.line	606	gettabup      r2    u0    k6 ; k6 = "bWriteLog"
.line	606	test          r2     0
.line	606	jmp            0  l114
.line	606	getupval      r2    u2
.line	606	loadk         r3    k7 ; k7 = 38
.line	606	loadk         r4    k8 ; k8 = 141
.line	606	loadk         r5    k9 ; k9 = 43
.line	606	loadk         r6   k10 ; k10 = 202
.line	606	loadk         r7   k11 ; k11 = 230
.line	606	loadk         r8   k12 ; k12 = 59
.line	606	loadk         r9   k13 ; k13 = 143
.line	606	loadk        r10   k14 ; k14 = 65
.line	606	loadk        r11   k15 ; k15 = 214
.line	606	loadk        r12   k16 ; k16 = 215
.line	606	loadk        r13   k17 ; k17 = 194
.line	606	loadk        r14   k18 ; k18 = 25
.line	606	loadk        r15   k19 ; k19 = 127
.line	606	loadk        r16   k20 ; k20 = 46
.line	606	loadk        r17   k21 ; k21 = 112
.line	606	loadk        r18   k10 ; k10 = 202
.line	606	loadk        r19   k22 ; k22 = 228
.line	606	loadk        r20   k23 ; k23 = 186
.line	606	loadk        r21   k24 ; k24 = 76
.line	606	loadk        r22   k25 ; k25 = 208
.line	606	loadk        r23   k26 ; k26 = 19
.line	606	loadk        r24   k27 ; k27 = 60
.line	606	loadk        r25   k28 ; k28 = 249
.line	606	loadk        r26   k29 ; k29 = 121
.line	606	loadk        r27    k8 ; k8 = 141
.line	606	loadk        r28   k30 ; k30 = 160
.line	606	loadk        r29   k31 ; k31 = 151
.line	606	loadk        r30   k32 ; k32 = 40
.line	606	loadk        r31   k33 ; k33 = 95
.line	606	loadk        r32   k34 ; k34 = 52
.line	606	loadk        r33   k35 ; k35 = 53
.line	606	loadk        r34   k43 ; k43 = 221
.line	606	loadk        r35   k44 ; k44 = 212
.line	606	loadk        r36   k45 ; k45 = 183
.line	606	loadk        r37   k46 ; k46 = 85
.line	606	loadk        r38   k47 ; k47 = 179
.line	606	loadk        r39   k48 ; k48 = 115
.line	606	call          r2    38     2
.line	606	getupval      r3    u3
.line	606	move          r4    r0
.line	606	call          r3     2     2
.line	606	concat        r2    r2    r3
.label	l114
.line	606	call          r1     2     1
.label	l115
.line	606	eq             0    k0    r0 ; k0 = 0
.line	606	jmp            0  l169
.line	606	gettabup      r1    u0    k1 ; k1 = "FuncUtil"
.line	606	gettable      r0    r1   k49 ; k49 = "remoteCfgCountryCode"
.line	606	gettabup      r1    u0    k5 ; k5 = "log"
.line	606	gettabup      r2    u0    k6 ; k6 = "bWriteLog"
.line	606	test          r2     0
.line	606	jmp            0  l168
.line	606	getupval      r2    u2
.line	606	loadk         r3    k7 ; k7 = 38
.line	606	loadk         r4    k8 ; k8 = 141
.line	606	loadk         r5    k9 ; k9 = 43
.line	606	loadk         r6   k10 ; k10 = 202
.line	606	loadk         r7   k11 ; k11 = 230
.line	606	loadk         r8   k12 ; k12 = 59
.line	606	loadk         r9   k13 ; k13 = 143
.line	606	loadk        r10   k14 ; k14 = 65
.line	606	loadk        r11   k15 ; k15 = 214
.line	606	loadk        r12   k16 ; k16 = 215
.line	606	loadk        r13   k17 ; k17 = 194
.line	606	loadk        r14   k18 ; k18 = 25
.line	606	loadk        r15   k19 ; k19 = 127
.line	606	loadk        r16   k20 ; k20 = 46
.line	606	loadk        r17   k21 ; k21 = 112
.line	606	loadk        r18   k10 ; k10 = 202
.line	606	loadk        r19   k22 ; k22 = 228
.line	606	loadk        r20   k23 ; k23 = 186
.line	606	loadk        r21   k24 ; k24 = 76
.line	606	loadk        r22   k25 ; k25 = 208
.line	606	loadk        r23   k26 ; k26 = 19
.line	606	loadk        r24   k27 ; k27 = 60
.line	606	loadk        r25   k28 ; k28 = 249
.line	606	loadk        r26   k29 ; k29 = 121
.line	606	loadk        r27    k8 ; k8 = 141
.line	606	loadk        r28   k30 ; k30 = 160
.line	606	loadk        r29   k31 ; k31 = 151
.line	606	loadk        r30   k32 ; k32 = 40
.line	606	loadk        r31   k33 ; k33 = 95
.line	606	loadk        r32   k34 ; k34 = 52
.line	606	loadk        r33   k35 ; k35 = 53
.line	606	loadk        r34   k11 ; k11 = 230
.line	606	loadk        r35   k39 ; k39 = 229
.line	606	loadk        r36   k50 ; k50 = 181
.line	606	loadk        r37   k51 ; k51 = 74
.line	606	loadk        r38   k52 ; k52 = 253
.line	606	loadk        r39   k53 ; k53 = 54
.line	606	loadk        r40   k46 ; k46 = 85
.line	606	loadk        r41   k54 ; k54 = 166
.line	606	call          r2    40     2
.line	606	getupval      r3    u3
.line	606	move          r4    r0
.line	606	call          r3     2     2
.line	606	concat        r2    r2    r3
.label	l168
.line	606	call          r1     2     1
.label	l169
.line	606	eq             0    k0    r0 ; k0 = 0
.line	606	jmp            0  l222
.line	606	gettabup      r1    u0    k1 ; k1 = "FuncUtil"
.line	606	gettable      r0    r1   k55 ; k55 = "localCountryCode"
.line	606	gettabup      r1    u0    k5 ; k5 = "log"
.line	606	gettabup      r2    u0    k6 ; k6 = "bWriteLog"
.line	606	test          r2     0
.line	606	jmp            0  l221
.line	606	getupval      r2    u2
.line	606	loadk         r3    k7 ; k7 = 38
.line	606	loadk         r4    k8 ; k8 = 141
.line	606	loadk         r5    k9 ; k9 = 43
.line	606	loadk         r6   k10 ; k10 = 202
.line	606	loadk         r7   k11 ; k11 = 230
.line	606	loadk         r8   k12 ; k12 = 59
.line	606	loadk         r9   k13 ; k13 = 143
.line	606	loadk        r10   k14 ; k14 = 65
.line	606	loadk        r11   k15 ; k15 = 214
.line	606	loadk        r12   k16 ; k16 = 215
.line	606	loadk        r13   k17 ; k17 = 194
.line	606	loadk        r14   k18 ; k18 = 25
.line	606	loadk        r15   k19 ; k19 = 127
.line	606	loadk        r16   k20 ; k20 = 46
.line	606	loadk        r17   k21 ; k21 = 112
.line	606	loadk        r18   k10 ; k10 = 202
.line	606	loadk        r19   k22 ; k22 = 228
.line	606	loadk        r20   k23 ; k23 = 186
.line	606	loadk        r21   k24 ; k24 = 76
.line	606	loadk        r22   k25 ; k25 = 208
.line	606	loadk        r23   k26 ; k26 = 19
.line	606	loadk        r24   k27 ; k27 = 60
.line	606	loadk        r25   k28 ; k28 = 249
.line	606	loadk        r26   k29 ; k29 = 121
.line	606	loadk        r27    k8 ; k8 = 141
.line	606	loadk        r28   k30 ; k30 = 160
.line	606	loadk        r29   k31 ; k31 = 151
.line	606	loadk        r30   k32 ; k32 = 40
.line	606	loadk        r31   k33 ; k33 = 95
.line	606	loadk        r32   k34 ; k34 = 52
.line	606	loadk        r33   k35 ; k35 = 53
.line	606	loadk        r34   k36 ; k36 = 248
.line	606	loadk        r35   k56 ; k56 = 239
.line	606	loadk        r36   k57 ; k57 = 187
.line	606	loadk        r37   k58 ; k58 = 68
.line	606	loadk        r38   k39 ; k39 = 229
.line	606	loadk        r39   k40 ; k40 = 105
.line	606	loadk        r40   k41 ; k41 = 79
.line	606	call          r2    39     2
.line	606	getupval      r3    u3
.line	606	move          r4    r0
.line	606	call          r3     2     2
.line	606	concat        r2    r2    r3
.label	l221
.line	606	call          r1     2     1
.label	l222
.line	606	gettabup      r1    u0    k5 ; k5 = "log"
.line	606	gettabup      r2    u0    k6 ; k6 = "bWriteLog"
.line	606	test          r2     0
.line	606	jmp            0  l281
.line	606	gettabup      r2    u0   k59 ; k59 = "table"
.line	606	gettable      r2    r2   k60 ; k60 = "concat"
.line	606	newtable      r3     1     0
.line	606	getupval      r4    u2
.line	606	loadk         r5    k7 ; k7 = 38
.line	606	loadk         r6    k8 ; k8 = 141
.line	606	loadk         r7    k9 ; k9 = 43
.line	606	loadk         r8   k10 ; k10 = 202
.line	606	loadk         r9   k11 ; k11 = 230
.line	606	loadk        r10   k12 ; k12 = 59
.line	606	loadk        r11   k13 ; k13 = 143
.line	606	loadk        r12   k14 ; k14 = 65
.line	606	loadk        r13   k15 ; k15 = 214
.line	606	loadk        r14   k16 ; k16 = 215
.line	606	loadk        r15   k17 ; k17 = 194
.line	606	loadk        r16   k18 ; k18 = 25
.line	606	loadk        r17   k19 ; k19 = 127
.line	606	loadk        r18   k20 ; k20 = 46
.line	606	loadk        r19   k21 ; k21 = 112
.line	606	loadk        r20   k10 ; k10 = 202
.line	606	loadk        r21   k22 ; k22 = 228
.line	606	loadk        r22   k23 ; k23 = 186
.line	606	loadk        r23   k24 ; k24 = 76
.line	606	loadk        r24   k25 ; k25 = 208
.line	606	loadk        r25   k26 ; k26 = 19
.line	606	loadk        r26   k27 ; k27 = 60
.line	606	loadk        r27   k28 ; k28 = 249
.line	606	loadk        r28   k29 ; k29 = 121
.line	606	loadk        r29    k8 ; k8 = 141
.line	606	loadk        r30   k30 ; k30 = 160
.line	606	loadk        r31   k31 ; k31 = 151
.line	606	loadk        r32   k61 ; k61 = 14
.line	606	loadk        r33   k62 ; k62 = 67
.line	606	loadk        r34   k63 ; k63 = 63
.line	606	loadk        r35   k64 ; k64 = 114
.line	606	loadk        r36   k65 ; k65 = 243
.line	606	loadk        r37   k44 ; k44 = 212
.line	606	loadk        r38   k36 ; k36 = 248
.line	606	loadk        r39   k66 ; k66 = 87
.line	606	loadk        r40   k67 ; k67 = 236
.line	606	loadk        r41   k68 ; k68 = 39
.line	606	loadk        r42   k69 ; k69 = 26
.line	606	loadk        r43   k70 ; k70 = 244
.line	606	loadk        r44   k71 ; k71 = 99
.line	606	call          r4    41     2
.line	606	getupval      r5    u2
.line	606	loadk         r6   k72 ; k72 = 90
.line	606	loadk         r7   k73 ; k73 = 216
.line	606	call          r5     3     0
.line	606	setlist       r3     0     1
.line	606	call          r2     2     2
.line	606	getupval      r3    u3
.line	606	move          r4    r0
.line	606	call          r3     2     2
.line	606	concat        r2    r2    r3
.label	l281
.line	606	call          r1     2     1
.line	606	return        r0     2
.line	606	return        r0     1
.line	606	move          r0    r0
.line	606	move          r0    r0
.line	606	return        r0     1

.function	main/f32

.source	null
.linedefined	628
.lastlinedefined	639
.numparams	0
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	20	true
.upvalue	"U2"	1	true

.constant	k0	"CountryIPCode"
.constant	k1	"FuncUtil"
.constant	k2	"GetCountryIPCode"
.constant	k3	"arrBanIPAreaList"
.constant	k4	"log"
.constant	k5	"bWriteLog"
.constant	k6	38
.constant	k7	141
.constant	k8	43
.constant	k9	202
.constant	k10	230
.constant	k11	59
.constant	k12	143
.constant	k13	65
.constant	k14	214
.constant	k15	217
.constant	k16	212
.constant	k17	62
.constant	k18	76
.constant	k19	36
.constant	k20	102
.constant	k21	205
.constant	k22	241
.constant	k23	164
.constant	k24	119
.constant	k25	248
.constant	k26	45
.constant	k27	228
.constant	k28	120
.constant	k29	137
.constant	k30	160
.constant	k31	196
.constant	k32	18
.constant	k33	66
.constant	k34	54
.constant	k35	82
.constant	k36	224
.constant	k37	172
.constant	k38	87
.constant	k39	252

.line	628	loadbool      r0     0     0
.line	628	gettabup      r1    u0    k1 ; k1 = "FuncUtil"
.line	628	gettable      r1    r1    k2 ; k2 = "GetCountryIPCode"
.line	628	call          r1     1     2
.line	628	settabup      u0    k0    r1 ; k0 = "CountryIPCode"
.line	628	getupval      r1    u1
.line	628	gettabup      r2    u0    k1 ; k1 = "FuncUtil"
.line	628	gettable      r2    r2    k3 ; k3 = "arrBanIPAreaList"
.line	628	call          r1     2     4
.line	628	jmp            0   l60
.line	628	gettabup      r6    u0    k0 ; k0 = "CountryIPCode"
.line	628	eq             0    r5    r6
.line	628	jmp            0   l60
.line	628	gettabup      r6    u0    k4 ; k4 = "log"
.line	628	gettabup      r7    u0    k5 ; k5 = "bWriteLog"
.line	628	test          r7     0
.line	628	jmp            0   l57
.line	628	getupval      r7    u2
.line	628	loadk         r8    k6 ; k6 = 38
.line	628	loadk         r9    k7 ; k7 = 141
.line	628	loadk        r10    k8 ; k8 = 43
.line	628	loadk        r11    k9 ; k9 = 202
.line	628	loadk        r12   k10 ; k10 = 230
.line	628	loadk        r13   k11 ; k11 = 59
.line	628	loadk        r14   k12 ; k12 = 143
.line	628	loadk        r15   k13 ; k13 = 65
.line	628	loadk        r16   k14 ; k14 = 214
.line	628	loadk        r17   k15 ; k15 = 217
.line	628	loadk        r18   k16 ; k16 = 212
.line	628	loadk        r19   k17 ; k17 = 62
.line	628	loadk        r20   k18 ; k18 = 76
.line	628	loadk        r21   k19 ; k19 = 36
.line	628	loadk        r22   k20 ; k20 = 102
.line	628	loadk        r23   k21 ; k21 = 205
.line	628	loadk        r24   k22 ; k22 = 241
.line	628	loadk        r25   k23 ; k23 = 164
.line	628	loadk        r26   k24 ; k24 = 119
.line	628	loadk        r27   k25 ; k25 = 248
.line	628	loadk        r28   k26 ; k26 = 45
.line	628	loadk        r29   k17 ; k17 = 62
.line	628	loadk        r30   k27 ; k27 = 228
.line	628	loadk        r31   k28 ; k28 = 120
.line	628	loadk        r32   k29 ; k29 = 137
.line	628	loadk        r33   k30 ; k30 = 160
.line	628	loadk        r34   k31 ; k31 = 196
.line	628	loadk        r35   k32 ; k32 = 18
.line	628	loadk        r36   k33 ; k33 = 66
.line	628	loadk        r37   k34 ; k34 = 54
.line	628	loadk        r38   k35 ; k35 = 82
.line	628	loadk        r39   k36 ; k36 = 224
.line	628	loadk        r40   k30 ; k30 = 160
.line	628	loadk        r41   k37 ; k37 = 172
.line	628	loadk        r42   k38 ; k38 = 87
.line	628	loadk        r43   k39 ; k39 = 252
.line	628	loadk        r44   k34 ; k34 = 54
.line	628	call          r7    38     2
.label	l57
.line	628	call          r6     2     1
.line	628	loadbool      r0     1     0
.line	628	jmp            0   l62
.label	l60
.line	628	move          r0    r0
.line	628	move          r0    r0
.label	l62
.line	628	return        r0     2
.line	628	return        r0     1
.line	628	move          r0    r0
.line	628	move          r0    r0
.line	628	move          r0    r0
.line	628	return        r0     1

.function	main/f33

.source	null
.linedefined	641
.lastlinedefined	651
.numparams	0
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	20	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"FuncUtil"
.constant	k1	"arrBanStoreList"
.constant	k2	"Client"
.constant	k3	"GetAOSSHOP"
.constant	k4	"log"
.constant	k5	"bWriteLog"
.constant	k6	38
.constant	k7	141
.constant	k8	43
.constant	k9	202
.constant	k10	230
.constant	k11	59
.constant	k12	143
.constant	k13	65
.constant	k14	214
.constant	k15	217
.constant	k16	212
.constant	k17	62
.constant	k18	76
.constant	k19	36
.constant	k20	102
.constant	k21	205
.constant	k22	241
.constant	k23	164
.constant	k24	119
.constant	k25	248
.constant	k26	45
.constant	k27	44
.constant	k28	226
.constant	k29	114
.constant	k30	154
.constant	k31	229
.constant	k32	151
.constant	k33	14
.constant	k34	67
.constant	k35	63
.constant	k36	243
.constant	k37	81
.constant	k38	251
.constant	k39	10

.line	641	loadbool      r0     0     0
.line	641	getupval      r1    u0
.line	641	gettabup      r2    u1    k0 ; k0 = "FuncUtil"
.line	641	gettable      r2    r2    k1 ; k1 = "arrBanStoreList"
.line	641	call          r1     2     4
.line	641	jmp            0   l59
.line	641	gettabup      r6    u1    k2 ; k2 = "Client"
.line	641	gettable      r6    r6    k3 ; k3 = "GetAOSSHOP"
.line	641	call          r6     1     2
.line	641	eq             0    r5    r6
.line	641	jmp            0   l59
.line	641	gettabup      r6    u1    k4 ; k4 = "log"
.line	641	gettabup      r7    u1    k5 ; k5 = "bWriteLog"
.line	641	test          r7     0
.line	641	jmp            0   l56
.line	641	getupval      r7    u2
.line	641	loadk         r8    k6 ; k6 = 38
.line	641	loadk         r9    k7 ; k7 = 141
.line	641	loadk        r10    k8 ; k8 = 43
.line	641	loadk        r11    k9 ; k9 = 202
.line	641	loadk        r12   k10 ; k10 = 230
.line	641	loadk        r13   k11 ; k11 = 59
.line	641	loadk        r14   k12 ; k12 = 143
.line	641	loadk        r15   k13 ; k13 = 65
.line	641	loadk        r16   k14 ; k14 = 214
.line	641	loadk        r17   k15 ; k15 = 217
.line	641	loadk        r18   k16 ; k16 = 212
.line	641	loadk        r19   k17 ; k17 = 62
.line	641	loadk        r20   k18 ; k18 = 76
.line	641	loadk        r21   k19 ; k19 = 36
.line	641	loadk        r22   k20 ; k20 = 102
.line	641	loadk        r23   k21 ; k21 = 205
.line	641	loadk        r24   k22 ; k22 = 241
.line	641	loadk        r25   k23 ; k23 = 164
.line	641	loadk        r26   k24 ; k24 = 119
.line	641	loadk        r27   k25 ; k25 = 248
.line	641	loadk        r28   k26 ; k26 = 45
.line	641	loadk        r29   k27 ; k27 = 44
.line	641	loadk        r30   k28 ; k28 = 226
.line	641	loadk        r31   k29 ; k29 = 114
.line	641	loadk        r32   k30 ; k30 = 154
.line	641	loadk        r33   k31 ; k31 = 229
.line	641	loadk        r34   k32 ; k32 = 151
.line	641	loadk        r35   k33 ; k33 = 14
.line	641	loadk        r36   k34 ; k34 = 67
.line	641	loadk        r37   k35 ; k35 = 63
.line	641	loadk        r38   k29 ; k29 = 114
.line	641	loadk        r39   k36 ; k36 = 243
.line	641	loadk        r40   k16 ; k16 = 212
.line	641	loadk        r41   k25 ; k25 = 248
.line	641	loadk        r42   k37 ; k37 = 81
.line	641	loadk        r43   k38 ; k38 = 251
.line	641	loadk        r44    k6 ; k6 = 38
.line	641	loadk        r45   k39 ; k39 = 10
.line	641	call          r7    39     2
.label	l56
.line	641	call          r6     2     1
.line	641	loadbool      r0     1     0
.line	641	jmp            0   l61
.label	l59
.line	641	move          r0    r0
.line	641	move          r0    r0
.label	l61
.line	641	return        r0     2
.line	641	return        r0     1
.line	641	move          r0    r0
.line	641	move          r0    r0
.line	641	move          r0    r0
.line	641	return        r0     1

.function	main/f34

.source	null
.linedefined	653
.lastlinedefined	655
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	false

.constant	k0	"FuncUtil"
.constant	k1	"IsSpecialBanArea"
.constant	k2	"IsSpecialBanStore"

.line	653	gettabup      r0    u0    k0 ; k0 = "FuncUtil"
.line	653	gettable      r0    r0    k1 ; k1 = "IsSpecialBanArea"
.line	653	call          r0     1     2
.line	653	test          r0     0
.line	653	jmp            0    l9
.line	653	gettabup      r0    u0    k0 ; k0 = "FuncUtil"
.line	653	gettable      r0    r0    k2 ; k2 = "IsSpecialBanStore"
.line	653	call          r0     1     2
.label	l9
.line	653	return        r0     2
.line	653	return        r0     1
.line	653	move          r0    r0
.line	653	move          r0    r0
.line	653	move          r0    r0
.line	653	move          r0    r0
.line	653	return        r0     1

.function	main/f35

.source	null
.linedefined	657
.lastlinedefined	677
.numparams	0
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	14	true
.upvalue	"U3"	18	true
.upvalue	"U4"	15	true
.upvalue	"U5"	24	true

.constant	k0	"FuncUtil"
.constant	k1	"arrNotGPUpgradeLink"
.constant	k2	0
.constant	k3	"defaultJumpLink"
.constant	k4	"GetDomainByID"
.constant	k5	3366055
.constant	k6	"Client"
.constant	k7	"LaunchUrl"
.constant	k8	1000
.constant	k9	"log"
.constant	k10	"bWriteLog"
.constant	k11	"table"
.constant	k12	"concat"
.constant	k13	38
.constant	k14	141
.constant	k15	43
.constant	k16	202
.constant	k17	230
.constant	k18	59
.constant	k19	143
.constant	k20	65
.constant	k21	214
.constant	k22	215
.constant	k23	200
.constant	k24	25
.constant	k25	83
.constant	k26	15
.constant	k27	106
.constant	k28	208
.constant	k29	152
.constant	k30	96
.constant	k31	233
.constant	k32	36
.constant	k33	13
.constant	k34	247
.constant	k35	121
.constant	k36	160
.constant	k37	196
.constant	k38	18
.constant	k39	66
.constant	k40	54
.constant	k41	82
.constant	k42	224
.constant	k43	138
.constant	k44	68
.constant	k45	231
.constant	k46	55
.constant	k47	63
.constant	k48	126
.constant	k49	90
.constant	k50	216
.constant	k51	148
.constant	k52	76
.constant	k53	56
.constant	k54	33
.constant	k55	243
.constant	k56	1
.constant	k57	49
.constant	k58	219
.constant	k59	198
.constant	k60	42
.constant	k61	35
.constant	k62	223
.constant	k63	60
.constant	k64	131

.line	657	gettabup      r0    u0    k0 ; k0 = "FuncUtil"
.line	657	gettable      r0    r0    k1 ; k1 = "arrNotGPUpgradeLink"
.line	657	len           r0    r0
.line	657	le             0    r0    k2 ; k2 = 0
.line	657	jmp            0   l32
.line	657	gettabup      r1    u0    k0 ; k0 = "FuncUtil"
.line	657	gettable      r1    r1    k3 ; k3 = "defaultJumpLink"
.line	657	test          r1     0
.line	657	jmp            0   l16
.line	657	gettabup      r1    u0    k0 ; k0 = "FuncUtil"
.line	657	gettable      r1    r1    k3 ; k3 = "defaultJumpLink"
.line	657	getupval      r2    u1
.line	657	call          r2     1     2
.line	657	eq             0    r1    r2
.line	657	jmp            0   l26
.label	l16
.line	657	gettabup      r1    u0    k0 ; k0 = "FuncUtil"
.line	657	gettabup      r2    u0    k0 ; k0 = "FuncUtil"
.line	657	gettable      r2    r2    k4 ; k4 = "GetDomainByID"
.line	657	loadk         r3    k5 ; k5 = 3366055
.line	657	call          r2     2     2
.line	657	test          r2     1
.line	657	jmp            0   l25
.line	657	getupval      r2    u1
.line	657	call          r2     1     2
.label	l25
.line	657	settable      r1    k3    r2 ; k3 = "defaultJumpLink"
.label	l26
.line	657	gettabup      r1    u0    k6 ; k6 = "Client"
.line	657	gettable      r1    r1    k7 ; k7 = "LaunchUrl"
.line	657	gettabup      r2    u0    k0 ; k0 = "FuncUtil"
.line	657	gettable      r2    r2    k3 ; k3 = "defaultJumpLink"
.line	657	call          r1     2     1
.line	657	jmp            0  l295
.label	l32
.line	657	getupval      r1    u2
.line	657	getupval      r2    u3
.line	657	call          r2     1     0
.line	657	call          r1     0     1
.line	657	getupval      r1    u4
.line	657	loadk         r2    k2 ; k2 = 0
.line	657	loadk         r3    k8 ; k8 = 1000
.line	657	call          r1     3     2
.line	657	mod           r1    r1    r0
.line	657	gettabup      r2    u0    k9 ; k9 = "log"
.line	657	gettabup      r3    u0   k10 ; k10 = "bWriteLog"
.line	657	test          r3     0
.line	657	jmp            0  l100
.line	657	gettabup      r3    u0   k11 ; k11 = "table"
.line	657	gettable      r3    r3   k12 ; k12 = "concat"
.line	657	newtable      r4     1     0
.line	657	getupval      r5    u1
.line	657	loadk         r6   k13 ; k13 = 38
.line	657	loadk         r7   k14 ; k14 = 141
.line	657	loadk         r8   k15 ; k15 = 43
.line	657	loadk         r9   k16 ; k16 = 202
.line	657	loadk        r10   k17 ; k17 = 230
.line	657	loadk        r11   k18 ; k18 = 59
.line	657	loadk        r12   k19 ; k19 = 143
.line	657	loadk        r13   k20 ; k20 = 65
.line	657	loadk        r14   k21 ; k21 = 214
.line	657	loadk        r15   k22 ; k22 = 215
.line	657	loadk        r16   k23 ; k23 = 200
.line	657	loadk        r17   k24 ; k24 = 25
.line	657	loadk        r18   k25 ; k25 = 83
.line	657	loadk        r19   k26 ; k26 = 15
.line	657	loadk        r20   k27 ; k27 = 106
.line	657	loadk        r21   k28 ; k28 = 208
.line	657	loadk        r22   k22 ; k22 = 215
.line	657	loadk        r23   k29 ; k29 = 152
.line	657	loadk        r24   k30 ; k30 = 96
.line	657	loadk        r25   k31 ; k31 = 233
.line	657	loadk        r26   k32 ; k32 = 36
.line	657	loadk        r27   k33 ; k33 = 13
.line	657	loadk        r28   k34 ; k34 = 247
.line	657	loadk        r29   k35 ; k35 = 121
.line	657	loadk        r30   k14 ; k14 = 141
.line	657	loadk        r31   k36 ; k36 = 160
.line	657	loadk        r32   k37 ; k37 = 196
.line	657	loadk        r33   k38 ; k38 = 18
.line	657	loadk        r34   k39 ; k39 = 66
.line	657	loadk        r35   k40 ; k40 = 54
.line	657	loadk        r36   k41 ; k41 = 82
.line	657	loadk        r37   k42 ; k42 = 224
.line	657	loadk        r38   k36 ; k36 = 160
.line	657	loadk        r39   k43 ; k43 = 138
.line	657	loadk        r40   k44 ; k44 = 68
.line	657	loadk        r41   k45 ; k45 = 231
.line	657	loadk        r42   k46 ; k46 = 55
.line	657	loadk        r43   k47 ; k47 = 63
.line	657	loadk        r44   k31 ; k31 = 233
.line	657	loadk        r45   k48 ; k48 = 126
.line	657	call          r5    41     2
.line	657	getupval      r6    u1
.line	657	loadk         r7   k49 ; k49 = 90
.line	657	loadk         r8   k50 ; k50 = 216
.line	657	call          r6     3     0
.line	657	setlist       r4     0     1
.line	657	call          r3     2     2
.line	657	getupval      r4    u5
.line	657	move          r5    r1
.line	657	call          r4     2     2
.line	657	concat        r3    r3    r4
.label	l100
.line	657	call          r2     2     1
.line	657	gettabup      r2    u0    k9 ; k9 = "log"
.line	657	gettabup      r3    u0   k10 ; k10 = "bWriteLog"
.line	657	test          r3     0
.line	657	jmp            0  l160
.line	657	gettabup      r3    u0   k11 ; k11 = "table"
.line	657	gettable      r3    r3   k12 ; k12 = "concat"
.line	657	newtable      r4     1     0
.line	657	getupval      r5    u1
.line	657	loadk         r6   k13 ; k13 = 38
.line	657	loadk         r7   k14 ; k14 = 141
.line	657	loadk         r8   k15 ; k15 = 43
.line	657	loadk         r9   k16 ; k16 = 202
.line	657	loadk        r10   k17 ; k17 = 230
.line	657	loadk        r11   k18 ; k18 = 59
.line	657	loadk        r12   k19 ; k19 = 143
.line	657	loadk        r13   k20 ; k20 = 65
.line	657	loadk        r14   k21 ; k21 = 214
.line	657	loadk        r15   k22 ; k22 = 215
.line	657	loadk        r16   k23 ; k23 = 200
.line	657	loadk        r17   k24 ; k24 = 25
.line	657	loadk        r18   k25 ; k25 = 83
.line	657	loadk        r19   k26 ; k26 = 15
.line	657	loadk        r20   k27 ; k27 = 106
.line	657	loadk        r21   k28 ; k28 = 208
.line	657	loadk        r22   k22 ; k22 = 215
.line	657	loadk        r23   k29 ; k29 = 152
.line	657	loadk        r24   k30 ; k30 = 96
.line	657	loadk        r25   k31 ; k31 = 233
.line	657	loadk        r26   k32 ; k32 = 36
.line	657	loadk        r27   k33 ; k33 = 13
.line	657	loadk        r28   k34 ; k34 = 247
.line	657	loadk        r29   k35 ; k35 = 121
.line	657	loadk        r30   k14 ; k14 = 141
.line	657	loadk        r31   k36 ; k36 = 160
.line	657	loadk        r32   k37 ; k37 = 196
.line	657	loadk        r33   k38 ; k38 = 18
.line	657	loadk        r34   k39 ; k39 = 66
.line	657	loadk        r35   k40 ; k40 = 54
.line	657	loadk        r36   k41 ; k41 = 82
.line	657	loadk        r37   k42 ; k42 = 224
.line	657	loadk        r38   k36 ; k36 = 160
.line	657	loadk        r39   k51 ; k51 = 148
.line	657	loadk        r40   k52 ; k52 = 76
.line	657	loadk        r41   k45 ; k45 = 231
.line	657	loadk        r42   k53 ; k53 = 56
.line	657	loadk        r43   k54 ; k54 = 33
.line	657	loadk        r44   k55 ; k55 = 243
.line	657	loadk        r45   k30 ; k30 = 96
.line	657	call          r5    41     2
.line	657	getupval      r6    u1
.line	657	loadk         r7   k49 ; k49 = 90
.line	657	loadk         r8   k50 ; k50 = 216
.line	657	call          r6     3     0
.line	657	setlist       r4     0     1
.line	657	call          r3     2     2
.line	657	getupval      r4    u5
.line	657	move          r5    r0
.line	657	call          r4     2     2
.line	657	concat        r3    r3    r4
.label	l160
.line	657	call          r2     2     1
.line	657	lt             0    r1    r0
.line	657	jmp            0  l234
.line	657	gettabup      r2    u0    k0 ; k0 = "FuncUtil"
.line	657	gettable      r2    r2    k1 ; k1 = "arrNotGPUpgradeLink"
.line	657	add           r3    r1   k56 ; k56 = 1
.line	657	gettable      r2    r2    r3
.line	657	gettabup      r3    u0    k9 ; k9 = "log"
.line	657	gettabup      r4    u0   k10 ; k10 = "bWriteLog"
.line	657	test          r4     0
.line	657	jmp            0  l228
.line	657	gettabup      r4    u0   k11 ; k11 = "table"
.line	657	gettable      r4    r4   k12 ; k12 = "concat"
.line	657	newtable      r5     1     0
.line	657	getupval      r6    u1
.line	657	loadk         r7   k13 ; k13 = 38
.line	657	loadk         r8   k14 ; k14 = 141
.line	657	loadk         r9   k15 ; k15 = 43
.line	657	loadk        r10   k16 ; k16 = 202
.line	657	loadk        r11   k17 ; k17 = 230
.line	657	loadk        r12   k18 ; k18 = 59
.line	657	loadk        r13   k19 ; k19 = 143
.line	657	loadk        r14   k20 ; k20 = 65
.line	657	loadk        r15   k21 ; k21 = 214
.line	657	loadk        r16   k22 ; k22 = 215
.line	657	loadk        r17   k23 ; k23 = 200
.line	657	loadk        r18   k24 ; k24 = 25
.line	657	loadk        r19   k25 ; k25 = 83
.line	657	loadk        r20   k26 ; k26 = 15
.line	657	loadk        r21   k27 ; k27 = 106
.line	657	loadk        r22   k28 ; k28 = 208
.line	657	loadk        r23   k22 ; k22 = 215
.line	657	loadk        r24   k29 ; k29 = 152
.line	657	loadk        r25   k30 ; k30 = 96
.line	657	loadk        r26   k31 ; k31 = 233
.line	657	loadk        r27   k32 ; k32 = 36
.line	657	loadk        r28   k33 ; k33 = 13
.line	657	loadk        r29   k34 ; k34 = 247
.line	657	loadk        r30   k35 ; k35 = 121
.line	657	loadk        r31   k14 ; k14 = 141
.line	657	loadk        r32   k36 ; k36 = 160
.line	657	loadk        r33   k37 ; k37 = 196
.line	657	loadk        r34   k38 ; k38 = 18
.line	657	loadk        r35   k39 ; k39 = 66
.line	657	loadk        r36   k40 ; k40 = 54
.line	657	loadk        r37   k41 ; k41 = 82
.line	657	loadk        r38   k42 ; k42 = 224
.line	657	loadk        r39   k36 ; k36 = 160
.line	657	loadk        r40   k43 ; k43 = 138
.line	657	loadk        r41   k44 ; k44 = 68
.line	657	loadk        r42   k45 ; k45 = 231
.line	657	loadk        r43   k46 ; k46 = 55
.line	657	loadk        r44   k47 ; k47 = 63
.line	657	loadk        r45   k31 ; k31 = 233
.line	657	loadk        r46   k48 ; k48 = 126
.line	657	call          r6    41     2
.line	657	getupval      r7    u1
.line	657	loadk         r8   k49 ; k49 = 90
.line	657	loadk         r9   k50 ; k50 = 216
.line	657	loadk        r10   k57 ; k57 = 49
.line	657	loadk        r11   k58 ; k58 = 219
.line	657	loadk        r12   k59 ; k59 = 198
.line	657	loadk        r13   k60 ; k60 = 42
.line	657	call          r7     7     0
.line	657	setlist       r5     0     1
.line	657	call          r4     2     2
.line	657	move          r5    r2
.line	657	concat        r4    r4    r5
.label	l228
.line	657	call          r3     2     1
.line	657	gettabup      r3    u0    k6 ; k6 = "Client"
.line	657	gettable      r3    r3    k7 ; k7 = "LaunchUrl"
.line	657	move          r4    r2
.line	657	call          r3     2     1
.line	657	jmp            0  l295
.label	l234
.line	657	gettabup      r2    u0    k9 ; k9 = "log"
.line	657	gettabup      r3    u0   k10 ; k10 = "bWriteLog"
.line	657	test          r3     0
.line	657	jmp            0  l294
.line	657	gettabup      r3    u0   k11 ; k11 = "table"
.line	657	gettable      r3    r3   k12 ; k12 = "concat"
.line	657	newtable      r4     1     0
.line	657	getupval      r5    u1
.line	657	loadk         r6   k13 ; k13 = 38
.line	657	loadk         r7   k14 ; k14 = 141
.line	657	loadk         r8   k15 ; k15 = 43
.line	657	loadk         r9   k16 ; k16 = 202
.line	657	loadk        r10   k17 ; k17 = 230
.line	657	loadk        r11   k18 ; k18 = 59
.line	657	loadk        r12   k19 ; k19 = 143
.line	657	loadk        r13   k20 ; k20 = 65
.line	657	loadk        r14   k21 ; k21 = 214
.line	657	loadk        r15   k22 ; k22 = 215
.line	657	loadk        r16   k23 ; k23 = 200
.line	657	loadk        r17   k24 ; k24 = 25
.line	657	loadk        r18   k25 ; k25 = 83
.line	657	loadk        r19   k26 ; k26 = 15
.line	657	loadk        r20   k27 ; k27 = 106
.line	657	loadk        r21   k28 ; k28 = 208
.line	657	loadk        r22   k22 ; k22 = 215
.line	657	loadk        r23   k29 ; k29 = 152
.line	657	loadk        r24   k30 ; k30 = 96
.line	657	loadk        r25   k31 ; k31 = 233
.line	657	loadk        r26   k32 ; k32 = 36
.line	657	loadk        r27   k33 ; k33 = 13
.line	657	loadk        r28   k34 ; k34 = 247
.line	657	loadk        r29   k35 ; k35 = 121
.line	657	loadk        r30   k14 ; k14 = 141
.line	657	loadk        r31   k36 ; k36 = 160
.line	657	loadk        r32   k37 ; k37 = 196
.line	657	loadk        r33   k38 ; k38 = 18
.line	657	loadk        r34   k39 ; k39 = 66
.line	657	loadk        r35   k40 ; k40 = 54
.line	657	loadk        r36   k41 ; k41 = 82
.line	657	loadk        r37   k42 ; k42 = 224
.line	657	loadk        r38   k36 ; k36 = 160
.line	657	loadk        r39   k43 ; k43 = 138
.line	657	loadk        r40   k44 ; k44 = 68
.line	657	loadk        r41   k45 ; k45 = 231
.line	657	loadk        r42   k46 ; k46 = 55
.line	657	loadk        r43   k47 ; k47 = 63
.line	657	loadk        r44   k31 ; k31 = 233
.line	657	loadk        r45   k48 ; k48 = 126
.line	657	call          r5    41     2
.line	657	getupval      r6    u1
.line	657	loadk         r7   k49 ; k49 = 90
.line	657	loadk         r8   k50 ; k50 = 216
.line	657	loadk         r9   k61 ; k61 = 35
.line	657	loadk        r10   k23 ; k23 = 200
.line	657	loadk        r11   k62 ; k62 = 223
.line	657	loadk        r12   k63 ; k63 = 60
.line	657	loadk        r13   k64 ; k64 = 131
.line	657	call          r6     8     0
.line	657	setlist       r4     0     1
.line	657	call          r3     2     2
.label	l294
.line	657	call          r2     2     1
.label	l295
.line	657	return        r0     1
.line	657	move          r0    r0
.line	657	return        r0     1

.function	main/f36

.source	null
.linedefined	679
.lastlinedefined	681
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	false

.constant	k0	"Client"
.constant	k1	"GetIPRegion"

.line	679	gettabup      r0    u0    k0 ; k0 = "Client"
.line	679	gettable      r0    r0    k1 ; k1 = "GetIPRegion"
.line	679	tailcall      r0     1
.line	679	return        r0     0
.line	679	return        r0     1
.line	679	move          r0    r0
.line	679	move          r0    r0
.line	679	return        r0     1

.function	main/f37

.source	null
.linedefined	683
.lastlinedefined	688
.numparams	0
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"DataMgr"
.constant	k1	"RegionData"
.constant	k2	"region"
.constant	k3	43
.constant	k4	170

.line	683	gettabup      r0    u0    k0 ; k0 = "DataMgr"
.line	683	gettable      r0    r0    k1 ; k1 = "RegionData"
.line	683	gettable      r0    r0    k2 ; k2 = "region"
.line	683	test          r0     1
.line	683	jmp            0    l6
.label	l6
.line	683	gettabup      r0    u0    k0 ; k0 = "DataMgr"
.line	683	gettable      r0    r0    k1 ; k1 = "RegionData"
.line	683	gettable      r0    r0    k2 ; k2 = "region"
.line	683	test          r0     1
.line	683	jmp            0   l15
.line	683	getupval      r0    u1
.line	683	loadk         r1    k3 ; k3 = 43
.line	683	loadk         r2    k4 ; k4 = 170
.line	683	call          r0     3     2
.label	l15
.line	683	return        r0     2
.line	683	return        r0     1
.line	683	move          r0    r0
.line	683	move          r0    r0
.line	683	move          r0    r0
.line	683	move          r0    r0
.line	683	return        r0     1

.function	main/f38

.source	null
.linedefined	692
.lastlinedefined	697
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"FuncUtil"
.constant	k1	"RegisterCountry"
.constant	k2	"GetAccountRegionForBP"

.line	692	gettabup      r0    u0    k0 ; k0 = "FuncUtil"
.line	692	gettable      r0    r0    k1 ; k1 = "RegisterCountry"
.line	692	test          r0     0
.line	692	jmp            0   l14
.line	692	gettabup      r0    u0    k0 ; k0 = "FuncUtil"
.line	692	gettable      r0    r0    k1 ; k1 = "RegisterCountry"
.line	692	getupval      r1    u1
.line	692	call          r1     1     2
.line	692	eq             1    r0    r1
.line	692	jmp            0   l14
.line	692	gettabup      r0    u0    k0 ; k0 = "FuncUtil"
.line	692	gettable      r0    r0    k1 ; k1 = "RegisterCountry"
.line	692	return        r0     2
.label	l14
.line	692	gettabup      r0    u0    k0 ; k0 = "FuncUtil"
.line	692	gettable      r0    r0    k2 ; k2 = "GetAccountRegionForB" (truncated)
.line	692	tailcall      r0     1
.line	692	return        r0     0
.line	692	return        r0     1
.line	692	move          r0    r0
.line	692	move          r0    r0
.line	692	move          r0    r0
.line	692	return        r0     1

.function	main/f39

.source	null
.linedefined	701
.lastlinedefined	706
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	42	true
.upvalue	"U1"	0	false

.constant	k0	nil
.constant	k1	"Client"
.constant	k2	"IsWindowOB"

.line	701	getupval      r0    u0
.line	701	eq             0    r0    k0 ; k0 = nil
.line	701	jmp            0    l8
.line	701	gettabup      r0    u1    k1 ; k1 = "Client"
.line	701	gettable      r0    r0    k2 ; k2 = "IsWindowOB"
.line	701	call          r0     1     2
.line	701	setupval      r0    u0
.label	l8
.line	701	getupval      r0    u0
.line	701	return        r0     2
.line	701	return        r0     1
.line	701	move          r0    r0
.line	701	return        r0     1

.function	main/f40

.source	null
.linedefined	710
.lastlinedefined	715
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	43	true
.upvalue	"U1"	0	false

.constant	k0	nil
.constant	k1	"Client"
.constant	k2	"IsCEHideLobbyUI"
.constant	k3	"GameFrontendHUD"

.line	710	getupval      r0    u0
.line	710	eq             0    r0    k0 ; k0 = nil
.line	710	jmp            0    l9
.line	710	gettabup      r0    u1    k1 ; k1 = "Client"
.line	710	gettable      r0    r0    k2 ; k2 = "IsCEHideLobbyUI"
.line	710	gettabup      r1    u1    k3 ; k3 = "GameFrontendHUD"
.line	710	call          r0     2     2
.line	710	setupval      r0    u0
.label	l9
.line	710	getupval      r0    u0
.line	710	return        r0     2
.line	710	return        r0     1
.line	710	move          r0    r0
.line	710	move          r0    r0
.line	710	return        r0     1

.function	main/f41

.source	null
.linedefined	719
.lastlinedefined	733
.numparams	4
.is_vararg	0
.maxstacksize	24

.upvalue	"_ENV"	44	true
.upvalue	"U1"	0	false
.upvalue	"U2"	27	true
.upvalue	"U3"	1	true
.upvalue	"U4"	5	true

.constant	k0	nil
.constant	k1	"LocUtil"
.constant	k2	"GetLocalizeResStr"
.constant	k3	6227
.constant	k4	100
.constant	k5	0
.constant	k6	"LocalizeResFormatByStr"
.constant	k7	"GetTableData"
.constant	k8	36
.constant	k9	145
.constant	k10	60
.constant	k11	250
.constant	k12	198
.constant	k13	38
.constant	k14	146
.constant	k15	110
.constant	k16	151
.constant	k17	252
.constant	k18	200
.constant	k19	31
.constant	k20	127
.constant	k21	46
.constant	k22	107
.constant	k23	194
.constant	k24	249
.constant	k25	175
.constant	k26	"ColorName"

.line	719	getupval      r4    u0
.line	719	eq             0    r4    k0 ; k0 = nil
.line	719	jmp            0    l9
.line	719	gettabup      r4    u1    k1 ; k1 = "LocUtil"
.line	719	gettable      r4    r4    k2 ; k2 = "GetLocalizeResStr"
.line	719	loadk         r5    k3 ; k3 = 6227
.line	719	call          r4     2     2
.line	719	setupval      r4    u0
.label	l9
.line	719	eq             1    r3    k0 ; k0 = nil
.line	719	jmp            0   l21
.line	719	le             0    r3    k4 ; k4 = 100
.line	719	jmp            0   l21
.line	719	lt             0    k5    r3 ; k5 = 0
.line	719	jmp            0   l21
.line	719	gettabup      r4    u1    k1 ; k1 = "LocUtil"
.line	719	gettable      r4    r4    k6 ; k6 = "LocalizeResFormatByS" (truncated)
.line	719	move          r5    r0
.line	719	move          r6    r3
.line	719	call          r4     3     2
.line	719	move          r0    r4
.label	l21
.line	719	eq             1    r1    k0 ; k0 = nil
.line	719	jmp            0   l56
.line	719	eq             1    r1    k5 ; k5 = 0
.line	719	jmp            0   l56
.line	719	gettabup      r4    u2    k7 ; k7 = "GetTableData"
.line	719	getupval      r5    u3
.line	719	loadk         r6    k8 ; k8 = 36
.line	719	loadk         r7    k9 ; k9 = 145
.line	719	loadk         r8   k10 ; k10 = 60
.line	719	loadk         r9   k11 ; k11 = 250
.line	719	loadk        r10   k12 ; k12 = 198
.line	719	loadk        r11   k13 ; k13 = 38
.line	719	loadk        r12   k14 ; k14 = 146
.line	719	loadk        r13   k15 ; k15 = 110
.line	719	loadk        r14   k16 ; k16 = 151
.line	719	loadk        r15   k17 ; k17 = 252
.line	719	loadk        r16   k18 ; k18 = 200
.line	719	loadk        r17   k19 ; k19 = 31
.line	719	loadk        r18   k20 ; k20 = 127
.line	719	loadk        r19   k21 ; k21 = 46
.line	719	loadk        r20   k22 ; k22 = 107
.line	719	loadk        r21   k23 ; k23 = 194
.line	719	loadk        r22   k24 ; k24 = 249
.line	719	loadk        r23   k25 ; k25 = 175
.line	719	call          r5    19     2
.line	719	move          r6    r1
.line	719	call          r4     3     2
.line	719	test          r4     0
.line	719	jmp            0   l56
.line	719	getupval      r5    u4
.line	719	getupval      r6    u0
.line	719	move          r7    r0
.line	719	gettable      r8    r4   k26 ; k26 = "ColorName"
.line	719	tailcall      r5     4
.line	719	return        r5     0
.label	l56
.line	719	return        r0     2
.line	719	return        r0     1
.line	719	move          r0    r0
.line	719	move          r0    r0
.line	719	move          r0    r0
.line	719	return        r0     1

.function	main/f42

.source	null
.linedefined	735
.lastlinedefined	748
.numparams	0
.is_vararg	0
.maxstacksize	30

.upvalue	"_ENV"	2	true
.upvalue	"U1"	27	true
.upvalue	"U2"	1	true

.constant	k0	"GetOperationRegion"
.constant	k1	"IsJapanOrKorea"
.constant	k2	"GetTable"
.constant	k3	52
.constant	k4	138
.constant	k5	36
.constant	k6	199
.constant	k7	192
.constant	k8	28
.constant	k9	147
.constant	k10	93
.constant	k11	136
.constant	k12	255
.constant	k13	213
.constant	k14	25
.constant	k15	127
.constant	k16	46
.constant	k17	107
.constant	k18	194
.constant	k19	249
.constant	k20	175
.constant	k21	106
.constant	k22	211
.constant	k23	8
.constant	k24	"OperationRegion"
.constant	k25	"VNG"
.constant	k26	207
.constant	k27	13
.constant	k28	56
.constant	k29	"TW"
.constant	k30	205
.constant	k31	20
.constant	k32	"IsBlueholeOperationRegion"
.constant	k33	219
.constant	k34	15
.constant	k35	42
.constant	k36	85
.constant	k37	167
.constant	k38	204
.constant	k39	242
.constant	k40	222
.constant	k41	48
.constant	k42	212
.constant	k43	92
.constant	k44	164

.line	735	gettabup      r0    u0    k0 ; k0 = "GetOperationRegion"
.line	735	call          r0     1     2
.line	735	gettabup      r1    u0    k1 ; k1 = "IsJapanOrKorea"
.line	735	call          r1     1     2
.line	735	test          r1     0
.line	735	jmp            0   l34
.line	735	gettabup      r1    u1    k2 ; k2 = "GetTable"
.line	735	getupval      r2    u2
.line	735	loadk         r3    k3 ; k3 = 52
.line	735	loadk         r4    k4 ; k4 = 138
.line	735	loadk         r5    k5 ; k5 = 36
.line	735	loadk         r6    k6 ; k6 = 199
.line	735	loadk         r7    k7 ; k7 = 192
.line	735	loadk         r8    k8 ; k8 = 28
.line	735	loadk         r9    k9 ; k9 = 147
.line	735	loadk        r10   k10 ; k10 = 93
.line	735	loadk        r11   k11 ; k11 = 136
.line	735	loadk        r12   k12 ; k12 = 255
.line	735	loadk        r13   k13 ; k13 = 213
.line	735	loadk        r14   k14 ; k14 = 25
.line	735	loadk        r15   k15 ; k15 = 127
.line	735	loadk        r16   k16 ; k16 = 46
.line	735	loadk        r17   k17 ; k17 = 107
.line	735	loadk        r18   k18 ; k18 = 194
.line	735	loadk        r19   k19 ; k19 = 249
.line	735	loadk        r20   k20 ; k20 = 175
.line	735	loadk        r21   k21 ; k21 = 106
.line	735	loadk        r22   k22 ; k22 = 211
.line	735	loadk        r23   k23 ; k23 = 8
.line	735	call          r2    22     2
.line	735	tailcall      r1     2
.line	735	return        r1     0
.line	735	jmp            0  l164
.label	l34
.line	735	gettabup      r1    u0   k24 ; k24 = "OperationRegion"
.line	735	gettable      r1    r1   k25 ; k25 = "VNG"
.line	735	eq             0    r0    r1
.line	735	jmp            0   l66
.line	735	gettabup      r1    u1    k2 ; k2 = "GetTable"
.line	735	getupval      r2    u2
.line	735	loadk         r3    k3 ; k3 = 52
.line	735	loadk         r4    k4 ; k4 = 138
.line	735	loadk         r5    k5 ; k5 = 36
.line	735	loadk         r6    k6 ; k6 = 199
.line	735	loadk         r7    k7 ; k7 = 192
.line	735	loadk         r8    k8 ; k8 = 28
.line	735	loadk         r9    k9 ; k9 = 147
.line	735	loadk        r10   k10 ; k10 = 93
.line	735	loadk        r11   k11 ; k11 = 136
.line	735	loadk        r12   k12 ; k12 = 255
.line	735	loadk        r13   k13 ; k13 = 213
.line	735	loadk        r14   k14 ; k14 = 25
.line	735	loadk        r15   k15 ; k15 = 127
.line	735	loadk        r16   k16 ; k16 = 46
.line	735	loadk        r17   k17 ; k17 = 107
.line	735	loadk        r18   k18 ; k18 = 194
.line	735	loadk        r19   k19 ; k19 = 249
.line	735	loadk        r20   k20 ; k20 = 175
.line	735	loadk        r21   k21 ; k21 = 106
.line	735	loadk        r22   k26 ; k26 = 207
.line	735	loadk        r23   k27 ; k27 = 13
.line	735	loadk        r24   k28 ; k28 = 56
.line	735	call          r2    23     2
.line	735	tailcall      r1     2
.line	735	return        r1     0
.line	735	jmp            0  l164
.label	l66
.line	735	gettabup      r1    u0   k24 ; k24 = "OperationRegion"
.line	735	gettable      r1    r1   k29 ; k29 = "TW"
.line	735	eq             0    r0    r1
.line	735	jmp            0   l97
.line	735	gettabup      r1    u1    k2 ; k2 = "GetTable"
.line	735	getupval      r2    u2
.line	735	loadk         r3    k3 ; k3 = 52
.line	735	loadk         r4    k4 ; k4 = 138
.line	735	loadk         r5    k5 ; k5 = 36
.line	735	loadk         r6    k6 ; k6 = 199
.line	735	loadk         r7    k7 ; k7 = 192
.line	735	loadk         r8    k8 ; k8 = 28
.line	735	loadk         r9    k9 ; k9 = 147
.line	735	loadk        r10   k10 ; k10 = 93
.line	735	loadk        r11   k11 ; k11 = 136
.line	735	loadk        r12   k12 ; k12 = 255
.line	735	loadk        r13   k13 ; k13 = 213
.line	735	loadk        r14   k14 ; k14 = 25
.line	735	loadk        r15   k15 ; k15 = 127
.line	735	loadk        r16   k16 ; k16 = 46
.line	735	loadk        r17   k17 ; k17 = 107
.line	735	loadk        r18   k18 ; k18 = 194
.line	735	loadk        r19   k19 ; k19 = 249
.line	735	loadk        r20   k20 ; k20 = 175
.line	735	loadk        r21   k21 ; k21 = 106
.line	735	loadk        r22   k30 ; k30 = 205
.line	735	loadk        r23   k31 ; k31 = 20
.line	735	call          r2    22     2
.line	735	tailcall      r1     2
.line	735	return        r1     0
.line	735	jmp            0  l164
.label	l97
.line	735	gettabup      r1    u0   k32 ; k32 = "IsBlueholeOperationR" (truncated)
.line	735	call          r1     1     2
.line	735	test          r1     0
.line	735	jmp            0  l134
.line	735	gettabup      r1    u1    k2 ; k2 = "GetTable"
.line	735	getupval      r2    u2
.line	735	loadk         r3    k3 ; k3 = 52
.line	735	loadk         r4    k4 ; k4 = 138
.line	735	loadk         r5    k5 ; k5 = 36
.line	735	loadk         r6    k6 ; k6 = 199
.line	735	loadk         r7    k7 ; k7 = 192
.line	735	loadk         r8    k8 ; k8 = 28
.line	735	loadk         r9    k9 ; k9 = 147
.line	735	loadk        r10   k10 ; k10 = 93
.line	735	loadk        r11   k11 ; k11 = 136
.line	735	loadk        r12   k12 ; k12 = 255
.line	735	loadk        r13   k13 ; k13 = 213
.line	735	loadk        r14   k14 ; k14 = 25
.line	735	loadk        r15   k15 ; k15 = 127
.line	735	loadk        r16   k16 ; k16 = 46
.line	735	loadk        r17   k17 ; k17 = 107
.line	735	loadk        r18   k18 ; k18 = 194
.line	735	loadk        r19   k19 ; k19 = 249
.line	735	loadk        r20   k20 ; k20 = 175
.line	735	loadk        r21   k21 ; k21 = 106
.line	735	loadk        r22   k33 ; k33 = 219
.line	735	loadk        r23   k34 ; k34 = 15
.line	735	loadk        r24   k35 ; k35 = 42
.line	735	loadk        r25   k22 ; k22 = 211
.line	735	loadk        r26   k36 ; k36 = 85
.line	735	loadk        r27   k37 ; k37 = 167
.line	735	loadk        r28   k38 ; k38 = 204
.line	735	loadk        r29   k39 ; k39 = 242
.line	735	call          r2    28     2
.line	735	tailcall      r1     2
.line	735	return        r1     0
.line	735	jmp            0  l164
.label	l134
.line	735	gettabup      r1    u1    k2 ; k2 = "GetTable"
.line	735	getupval      r2    u2
.line	735	loadk         r3    k3 ; k3 = 52
.line	735	loadk         r4    k4 ; k4 = 138
.line	735	loadk         r5    k5 ; k5 = 36
.line	735	loadk         r6    k6 ; k6 = 199
.line	735	loadk         r7    k7 ; k7 = 192
.line	735	loadk         r8    k8 ; k8 = 28
.line	735	loadk         r9    k9 ; k9 = 147
.line	735	loadk        r10   k10 ; k10 = 93
.line	735	loadk        r11   k11 ; k11 = 136
.line	735	loadk        r12   k12 ; k12 = 255
.line	735	loadk        r13   k13 ; k13 = 213
.line	735	loadk        r14   k14 ; k14 = 25
.line	735	loadk        r15   k15 ; k15 = 127
.line	735	loadk        r16   k16 ; k16 = 46
.line	735	loadk        r17   k17 ; k17 = 107
.line	735	loadk        r18   k18 ; k18 = 194
.line	735	loadk        r19   k19 ; k19 = 249
.line	735	loadk        r20   k20 ; k20 = 175
.line	735	loadk        r21   k21 ; k21 = 106
.line	735	loadk        r22   k40 ; k40 = 222
.line	735	loadk        r23   k34 ; k34 = 15
.line	735	loadk        r24   k41 ; k41 = 48
.line	735	loadk        r25   k42 ; k42 = 212
.line	735	loadk        r26   k43 ; k43 = 92
.line	735	loadk        r27   k44 ; k44 = 164
.line	735	call          r2    26     2
.line	735	tailcall      r1     2
.line	735	return        r1     0
.label	l164
.line	735	return        r0     1
.line	735	move          r0    r0
.line	735	return        r0     1

.function	main/f43

.source	null
.linedefined	750
.lastlinedefined	766
.numparams	0
.is_vararg	0
.maxstacksize	29

.upvalue	"_ENV"	2	true
.upvalue	"U1"	1	true

.constant	k0	"IsCEOperationRegion"
.constant	k1	52
.constant	k2	138
.constant	k3	36
.constant	k4	199
.constant	k5	192
.constant	k6	28
.constant	k7	147
.constant	k8	93
.constant	k9	136
.constant	k10	255
.constant	k11	213
.constant	k12	25
.constant	k13	127
.constant	k14	46
.constant	k15	107
.constant	k16	194
.constant	k17	249
.constant	k18	175
.constant	k19	106
.constant	k20	218
.constant	k21	6
.constant	k22	"GetOperationRegion"
.constant	k23	"IsJapanOrKorea"
.constant	k24	211
.constant	k25	8
.constant	k26	"OperationRegion"
.constant	k27	"VNG"
.constant	k28	207
.constant	k29	13
.constant	k30	56
.constant	k31	"TW"
.constant	k32	205
.constant	k33	20
.constant	k34	"IsBlueholeOperationRegion"
.constant	k35	219
.constant	k36	15
.constant	k37	42
.constant	k38	85
.constant	k39	167
.constant	k40	204
.constant	k41	242
.constant	k42	222
.constant	k43	48
.constant	k44	212
.constant	k45	92
.constant	k46	164

.line	750	gettabup      r0    u0    k0 ; k0 = "IsCEOperationRegion"
.line	750	call          r0     1     2
.line	750	test          r0     0
.line	750	jmp            0   l30
.line	750	getupval      r0    u1
.line	750	loadk         r1    k1 ; k1 = 52
.line	750	loadk         r2    k2 ; k2 = 138
.line	750	loadk         r3    k3 ; k3 = 36
.line	750	loadk         r4    k4 ; k4 = 199
.line	750	loadk         r5    k5 ; k5 = 192
.line	750	loadk         r6    k6 ; k6 = 28
.line	750	loadk         r7    k7 ; k7 = 147
.line	750	loadk         r8    k8 ; k8 = 93
.line	750	loadk         r9    k9 ; k9 = 136
.line	750	loadk        r10   k10 ; k10 = 255
.line	750	loadk        r11   k11 ; k11 = 213
.line	750	loadk        r12   k12 ; k12 = 25
.line	750	loadk        r13   k13 ; k13 = 127
.line	750	loadk        r14   k14 ; k14 = 46
.line	750	loadk        r15   k15 ; k15 = 107
.line	750	loadk        r16   k16 ; k16 = 194
.line	750	loadk        r17   k17 ; k17 = 249
.line	750	loadk        r18   k18 ; k18 = 175
.line	750	loadk        r19   k19 ; k19 = 106
.line	750	loadk        r20   k20 ; k20 = 218
.line	750	loadk        r21   k21 ; k21 = 6
.line	750	call          r0    22     2
.line	750	return        r0     2
.line	750	jmp            0  l154
.label	l30
.line	750	gettabup      r0    u0   k22 ; k22 = "GetOperationRegion"
.line	750	call          r0     1     2
.line	750	gettabup      r1    u0   k23 ; k23 = "IsJapanOrKorea"
.line	750	call          r1     1     2
.line	750	test          r1     0
.line	750	jmp            0   l61
.line	750	getupval      r1    u1
.line	750	loadk         r2    k1 ; k1 = 52
.line	750	loadk         r3    k2 ; k2 = 138
.line	750	loadk         r4    k3 ; k3 = 36
.line	750	loadk         r5    k4 ; k4 = 199
.line	750	loadk         r6    k5 ; k5 = 192
.line	750	loadk         r7    k6 ; k6 = 28
.line	750	loadk         r8    k7 ; k7 = 147
.line	750	loadk         r9    k8 ; k8 = 93
.line	750	loadk        r10    k9 ; k9 = 136
.line	750	loadk        r11   k10 ; k10 = 255
.line	750	loadk        r12   k11 ; k11 = 213
.line	750	loadk        r13   k12 ; k12 = 25
.line	750	loadk        r14   k13 ; k13 = 127
.line	750	loadk        r15   k14 ; k14 = 46
.line	750	loadk        r16   k15 ; k15 = 107
.line	750	loadk        r17   k16 ; k16 = 194
.line	750	loadk        r18   k17 ; k17 = 249
.line	750	loadk        r19   k18 ; k18 = 175
.line	750	loadk        r20   k19 ; k19 = 106
.line	750	loadk        r21   k24 ; k24 = 211
.line	750	loadk        r22   k25 ; k25 = 8
.line	750	call          r1    22     2
.line	750	return        r1     2
.line	750	jmp            0  l154
.label	l61
.line	750	gettabup      r1    u0   k26 ; k26 = "OperationRegion"
.line	750	gettable      r1    r1   k27 ; k27 = "VNG"
.line	750	eq             0    r0    r1
.line	750	jmp            0   l91
.line	750	getupval      r1    u1
.line	750	loadk         r2    k1 ; k1 = 52
.line	750	loadk         r3    k2 ; k2 = 138
.line	750	loadk         r4    k3 ; k3 = 36
.line	750	loadk         r5    k4 ; k4 = 199
.line	750	loadk         r6    k5 ; k5 = 192
.line	750	loadk         r7    k6 ; k6 = 28
.line	750	loadk         r8    k7 ; k7 = 147
.line	750	loadk         r9    k8 ; k8 = 93
.line	750	loadk        r10    k9 ; k9 = 136
.line	750	loadk        r11   k10 ; k10 = 255
.line	750	loadk        r12   k11 ; k11 = 213
.line	750	loadk        r13   k12 ; k12 = 25
.line	750	loadk        r14   k13 ; k13 = 127
.line	750	loadk        r15   k14 ; k14 = 46
.line	750	loadk        r16   k15 ; k15 = 107
.line	750	loadk        r17   k16 ; k16 = 194
.line	750	loadk        r18   k17 ; k17 = 249
.line	750	loadk        r19   k18 ; k18 = 175
.line	750	loadk        r20   k19 ; k19 = 106
.line	750	loadk        r21   k28 ; k28 = 207
.line	750	loadk        r22   k29 ; k29 = 13
.line	750	loadk        r23   k30 ; k30 = 56
.line	750	call          r1    23     2
.line	750	return        r1     2
.line	750	jmp            0  l154
.label	l91
.line	750	gettabup      r1    u0   k26 ; k26 = "OperationRegion"
.line	750	gettable      r1    r1   k31 ; k31 = "TW"
.line	750	eq             0    r0    r1
.line	750	jmp            0  l120
.line	750	getupval      r1    u1
.line	750	loadk         r2    k1 ; k1 = 52
.line	750	loadk         r3    k2 ; k2 = 138
.line	750	loadk         r4    k3 ; k3 = 36
.line	750	loadk         r5    k4 ; k4 = 199
.line	750	loadk         r6    k5 ; k5 = 192
.line	750	loadk         r7    k6 ; k6 = 28
.line	750	loadk         r8    k7 ; k7 = 147
.line	750	loadk         r9    k8 ; k8 = 93
.line	750	loadk        r10    k9 ; k9 = 136
.line	750	loadk        r11   k10 ; k10 = 255
.line	750	loadk        r12   k11 ; k11 = 213
.line	750	loadk        r13   k12 ; k12 = 25
.line	750	loadk        r14   k13 ; k13 = 127
.line	750	loadk        r15   k14 ; k14 = 46
.line	750	loadk        r16   k15 ; k15 = 107
.line	750	loadk        r17   k16 ; k16 = 194
.line	750	loadk        r18   k17 ; k17 = 249
.line	750	loadk        r19   k18 ; k18 = 175
.line	750	loadk        r20   k19 ; k19 = 106
.line	750	loadk        r21   k32 ; k32 = 205
.line	750	loadk        r22   k33 ; k33 = 20
.line	750	call          r1    22     2
.line	750	return        r1     2
.line	750	jmp            0  l154
.label	l120
.line	750	gettabup      r1    u0   k34 ; k34 = "IsBlueholeOperationR" (truncated)
.line	750	call          r1     1     2
.line	750	test          r1     0
.line	750	jmp            0  l154
.line	750	getupval      r1    u1
.line	750	loadk         r2    k1 ; k1 = 52
.line	750	loadk         r3    k2 ; k2 = 138
.line	750	loadk         r4    k3 ; k3 = 36
.line	750	loadk         r5    k4 ; k4 = 199
.line	750	loadk         r6    k5 ; k5 = 192
.line	750	loadk         r7    k6 ; k6 = 28
.line	750	loadk         r8    k7 ; k7 = 147
.line	750	loadk         r9    k8 ; k8 = 93
.line	750	loadk        r10    k9 ; k9 = 136
.line	750	loadk        r11   k10 ; k10 = 255
.line	750	loadk        r12   k11 ; k11 = 213
.line	750	loadk        r13   k12 ; k12 = 25
.line	750	loadk        r14   k13 ; k13 = 127
.line	750	loadk        r15   k14 ; k14 = 46
.line	750	loadk        r16   k15 ; k15 = 107
.line	750	loadk        r17   k16 ; k16 = 194
.line	750	loadk        r18   k17 ; k17 = 249
.line	750	loadk        r19   k18 ; k18 = 175
.line	750	loadk        r20   k19 ; k19 = 106
.line	750	loadk        r21   k35 ; k35 = 219
.line	750	loadk        r22   k36 ; k36 = 15
.line	750	loadk        r23   k37 ; k37 = 42
.line	750	loadk        r24   k24 ; k24 = 211
.line	750	loadk        r25   k38 ; k38 = 85
.line	750	loadk        r26   k39 ; k39 = 167
.line	750	loadk        r27   k40 ; k40 = 204
.line	750	loadk        r28   k41 ; k41 = 242
.line	750	call          r1    28     2
.line	750	return        r1     2
.label	l154
.line	750	getupval      r0    u1
.line	750	loadk         r1    k1 ; k1 = 52
.line	750	loadk         r2    k2 ; k2 = 138
.line	750	loadk         r3    k3 ; k3 = 36
.line	750	loadk         r4    k4 ; k4 = 199
.line	750	loadk         r5    k5 ; k5 = 192
.line	750	loadk         r6    k6 ; k6 = 28
.line	750	loadk         r7    k7 ; k7 = 147
.line	750	loadk         r8    k8 ; k8 = 93
.line	750	loadk         r9    k9 ; k9 = 136
.line	750	loadk        r10   k10 ; k10 = 255
.line	750	loadk        r11   k11 ; k11 = 213
.line	750	loadk        r12   k12 ; k12 = 25
.line	750	loadk        r13   k13 ; k13 = 127
.line	750	loadk        r14   k14 ; k14 = 46
.line	750	loadk        r15   k15 ; k15 = 107
.line	750	loadk        r16   k16 ; k16 = 194
.line	750	loadk        r17   k17 ; k17 = 249
.line	750	loadk        r18   k18 ; k18 = 175
.line	750	loadk        r19   k19 ; k19 = 106
.line	750	loadk        r20   k42 ; k42 = 222
.line	750	loadk        r21   k36 ; k36 = 15
.line	750	loadk        r22   k43 ; k43 = 48
.line	750	loadk        r23   k44 ; k44 = 212
.line	750	loadk        r24   k45 ; k45 = 92
.line	750	loadk        r25   k46 ; k46 = 164
.line	750	call          r0    26     2
.line	750	return        r0     2
.line	750	return        r0     1
.line	750	move          r0    r0
.line	750	return        r0     1

.function	main/f44

.source	null
.linedefined	768
.lastlinedefined	842
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	2	true
.upvalue	"U1"	25	true
.upvalue	"U2"	0	false
.upvalue	"U3"	1	true
.upvalue	"U4"	27	true

.constant	k0	"GetPackageType"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	3
.constant	k4	148
.constant	k5	44
.constant	k6	204
.constant	k7	221
.constant	k8	59
.constant	k9	200
.constant	k10	94
.constant	k11	229
.constant	k12	198
.constant	k13	67
.constant	k14	95
.constant	k15	46
.constant	k16	107
.constant	k17	194
.constant	k18	249
.constant	k19	175
.constant	k20	27
.constant	k21	218
.constant	k22	47
.constant	k23	22
.constant	k24	243
.constant	k25	115
.constant	k26	156
.constant	k27	205
.constant	k28	214
.constant	k29	30
.constant	k30	62
.constant	k31	102
.constant	k32	154
.constant	k33	196
.constant	k34	189
.constant	k35	83
.constant	k36	224
.constant	k37	48
.constant	k38	10
.constant	k39	97
.constant	k40	1
.constant	k41	140
.constant	k42	35
.constant	k43	193
.constant	k44	34
.constant	k45	168
.constant	k46	76
.constant	k47	149
.constant	k48	245
.constant	k49	234
.constant	k50	12
.constant	k51	51
.constant	k52	106
.constant	k53	215
.constant	k54	"Client"
.constant	k55	"GetDevicePlatformName"
.constant	k56	"IOS"
.constant	k57	"IsJapanOrKorea"
.constant	k58	"GetTable"
.constant	k59	53
.constant	k60	191
.constant	k61	6
.constant	k62	251
.constant	k63	142
.constant	k64	138
.constant	k65	247
.constant	k66	33
.constant	k67	89
.constant	k68	55
.constant	k69	96
.constant	k70	207
.constant	k71	129
.constant	k72	122
.constant	k73	202
.constant	k74	28
.constant	k75	"PackageType"
.constant	k76	"VNG"
.constant	k77	41
.constant	k78	216
.constant	k79	90
.constant	k80	"TW"
.constant	k81	43
.constant	k82	"IsBGMILITE"
.constant	k83	61
.constant	k84	209
.constant	k85	80
.constant	k86	161
.constant	k87	254
.constant	k88	105
.constant	k89	"IsBLUEHOLE"
.constant	k90	72
.constant	k91	173
.constant	k92	248
.constant	k93	49
.constant	k94	"LIGHT_GLOBAL"
.constant	k95	57
.constant	k96	223
.constant	k97	73
.constant	k98	56
.constant	k99	82
.constant	k100	170
.constant	k101	50
.constant	k102	157
.constant	k103	38
.constant	k104	210
.constant	k105	180
.constant	k106	8
.constant	k107	235
.constant	k108	195
.constant	k109	151
.constant	k110	127
.constant	k111	99
.constant	k112	4
.constant	k113	206
.constant	k114	119
.constant	k115	222
.constant	k116	14
.constant	k117	54
.constant	k118	84
.constant	k119	188
.constant	k120	197
.constant	k121	213
.constant	k122	58
.constant	k123	164
.constant	k124	208
.constant	k125	23
.constant	k126	114
.constant	k127	81
.constant	k128	"Android"
.constant	k129	137
.constant	k130	91
.constant	k131	253
.constant	k132	16
.constant	k133	255
.constant	k134	121
.constant	k135	183
.constant	k136	252
.constant	k137	212
.constant	k138	240
.constant	k139	101
.constant	k140	29
.constant	k141	92
.constant	k142	40
.constant	k143	25
.constant	k144	199
.constant	k145	110
.constant	k146	68
.constant	k147	244
.constant	k148	186
.constant	k149	39
.constant	k150	32
.constant	k151	220
.constant	k152	86
.constant	k153	192
.constant	k154	74
.constant	k155	165
.constant	k156	201
.constant	k157	52
.constant	k158	120
.constant	k159	20
.constant	k160	167
.constant	k161	246

.line	768	loadnil       r1     0
.line	768	gettabup      r2    u0    k0 ; k0 = "GetPackageType"
.line	768	call          r2     1     2
.line	768	getupval      r3    u1
.line	768	gettabup      r4    u2    k1 ; k1 = "table"
.line	768	gettable      r4    r4    k2 ; k2 = "concat"
.line	768	newtable      r5     1     0
.line	768	getupval      r6    u3
.line	768	loadk         r7    k3 ; k3 = 3
.line	768	loadk         r8    k4 ; k4 = 148
.line	768	loadk         r9    k5 ; k5 = 44
.line	768	loadk        r10    k6 ; k6 = 204
.line	768	loadk        r11    k7 ; k7 = 221
.line	768	loadk        r12    k8 ; k8 = 59
.line	768	loadk        r13    k9 ; k9 = 200
.line	768	loadk        r14   k10 ; k10 = 94
.line	768	loadk        r15    k4 ; k4 = 148
.line	768	loadk        r16   k11 ; k11 = 229
.line	768	loadk        r17   k12 ; k12 = 198
.line	768	loadk        r18   k13 ; k13 = 67
.line	768	loadk        r19   k14 ; k14 = 95
.line	768	loadk        r20   k15 ; k15 = 46
.line	768	loadk        r21   k16 ; k16 = 107
.line	768	loadk        r22   k17 ; k17 = 194
.line	768	loadk        r23   k18 ; k18 = 249
.line	768	loadk        r24   k19 ; k19 = 175
.line	768	loadk        r25   k20 ; k20 = 27
.line	768	loadk        r26   k21 ; k21 = 218
.line	768	loadk        r27   k22 ; k22 = 47
.line	768	loadk        r28   k23 ; k23 = 22
.line	768	loadk        r29   k24 ; k24 = 243
.line	768	loadk        r30   k25 ; k25 = 115
.line	768	loadk        r31   k26 ; k26 = 156
.line	768	loadk        r32   k27 ; k27 = 205
.line	768	loadk        r33   k28 ; k28 = 214
.line	768	loadk        r34   k29 ; k29 = 30
.line	768	loadk        r35   k10 ; k10 = 94
.line	768	loadk        r36   k30 ; k30 = 62
.line	768	loadk        r37   k31 ; k31 = 102
.line	768	loadk        r38   k32 ; k32 = 154
.line	768	loadk        r39   k33 ; k33 = 196
.line	768	loadk        r40   k34 ; k34 = 189
.line	768	loadk        r41   k35 ; k35 = 83
.line	768	loadk        r42   k36 ; k36 = 224
.line	768	loadk        r43   k37 ; k37 = 48
.line	768	loadk        r44   k38 ; k38 = 10
.line	768	loadk        r45   k28 ; k28 = 214
.line	768	loadk        r46   k39 ; k39 = 97
.line	768	call          r6    41     2
.line	768	getupval      r7    u3
.line	768	loadk         r8   k40 ; k40 = 1
.line	768	loadk         r9   k41 ; k41 = 140
.line	768	loadk        r10   k42 ; k42 = 35
.line	768	loadk        r11   k12 ; k12 = 198
.line	768	loadk        r12   k43 ; k43 = 193
.line	768	loadk        r13   k44 ; k44 = 34
.line	768	loadk        r14   k45 ; k45 = 168
.line	768	loadk        r15   k46 ; k46 = 76
.line	768	loadk        r16   k47 ; k47 = 149
.line	768	loadk        r17   k48 ; k48 = 245
.line	768	loadk        r18   k49 ; k49 = 234
.line	768	loadk        r19   k50 ; k50 = 12
.line	768	loadk        r20   k14 ; k14 = 95
.line	768	loadk        r21   k51 ; k51 = 51
.line	768	loadk        r22   k52 ; k52 = 106
.line	768	loadk        r23   k53 ; k53 = 215
.line	768	call          r7    17     0
.line	768	setlist       r5     0     1
.line	768	call          r4     2     2
.line	768	call          r3     2     2
.line	768	gettabup      r4    u2   k54 ; k54 = "Client"
.line	768	gettable      r4    r4   k55 ; k55 = "GetDevicePlatformNam" (truncated)
.line	768	call          r4     1     2
.line	768	gettable      r5    r3   k56 ; k56 = "IOS"
.line	768	eq             0    r4    r5
.line	768	jmp            0  l548
.line	768	test          r0     0
.line	768	jmp            0  l324
.line	768	gettabup      r4    u0   k57 ; k57 = "IsJapanOrKorea"
.line	768	call          r4     1     2
.line	768	test          r4     0
.line	768	jmp            0  l112
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6   k59 ; k59 = 53
.line	768	loadk         r7   k60 ; k60 = 191
.line	768	loadk         r8   k61 ; k61 = 6
.line	768	loadk         r9   k62 ; k62 = 251
.line	768	loadk        r10   k28 ; k28 = 214
.line	768	loadk        r11    k5 ; k5 = 44
.line	768	loadk        r12   k63 ; k63 = 142
.line	768	loadk        r13   k46 ; k46 = 76
.line	768	loadk        r14   k64 ; k64 = 138
.line	768	loadk        r15   k65 ; k65 = 247
.line	768	loadk        r16   k17 ; k17 = 194
.line	768	loadk        r17   k66 ; k66 = 33
.line	768	loadk        r18   k67 ; k67 = 89
.line	768	loadk        r19   k68 ; k68 = 55
.line	768	loadk        r20   k69 ; k69 = 96
.line	768	loadk        r21    k9 ; k9 = 200
.line	768	loadk        r22   k70 ; k70 = 207
.line	768	loadk        r23   k71 ; k71 = 129
.line	768	loadk        r24   k72 ; k72 = 122
.line	768	loadk        r25   k73 ; k73 = 202
.line	768	loadk        r26   k74 ; k74 = 28
.line	768	loadk        r27   k59 ; k59 = 53
.line	768	loadk        r28    k7 ; k7 = 221
.line	768	call          r5    24     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l112
.line	768	gettabup      r4    u0   k75 ; k75 = "PackageType"
.line	768	gettable      r4    r4   k76 ; k76 = "VNG"
.line	768	eq             0    r2    r4
.line	768	jmp            0  l146
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6   k59 ; k59 = 53
.line	768	loadk         r7   k60 ; k60 = 191
.line	768	loadk         r8   k61 ; k61 = 6
.line	768	loadk         r9   k62 ; k62 = 251
.line	768	loadk        r10   k28 ; k28 = 214
.line	768	loadk        r11    k5 ; k5 = 44
.line	768	loadk        r12   k63 ; k63 = 142
.line	768	loadk        r13   k46 ; k46 = 76
.line	768	loadk        r14   k64 ; k64 = 138
.line	768	loadk        r15   k65 ; k65 = 247
.line	768	loadk        r16   k17 ; k17 = 194
.line	768	loadk        r17   k66 ; k66 = 33
.line	768	loadk        r18   k67 ; k67 = 89
.line	768	loadk        r19   k68 ; k68 = 55
.line	768	loadk        r20   k69 ; k69 = 96
.line	768	loadk        r21    k9 ; k9 = 200
.line	768	loadk        r22   k70 ; k70 = 207
.line	768	loadk        r23   k71 ; k71 = 129
.line	768	loadk        r24   k72 ; k72 = 122
.line	768	loadk        r25   k73 ; k73 = 202
.line	768	loadk        r26   k74 ; k74 = 28
.line	768	loadk        r27   k77 ; k77 = 41
.line	768	loadk        r28   k78 ; k78 = 216
.line	768	loadk        r29   k79 ; k79 = 90
.line	768	call          r5    25     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l146
.line	768	gettabup      r4    u0   k75 ; k75 = "PackageType"
.line	768	gettable      r4    r4   k80 ; k80 = "TW"
.line	768	eq             0    r2    r4
.line	768	jmp            0  l179
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6   k59 ; k59 = 53
.line	768	loadk         r7   k60 ; k60 = 191
.line	768	loadk         r8   k61 ; k61 = 6
.line	768	loadk         r9   k62 ; k62 = 251
.line	768	loadk        r10   k28 ; k28 = 214
.line	768	loadk        r11    k5 ; k5 = 44
.line	768	loadk        r12   k63 ; k63 = 142
.line	768	loadk        r13   k46 ; k46 = 76
.line	768	loadk        r14   k64 ; k64 = 138
.line	768	loadk        r15   k65 ; k65 = 247
.line	768	loadk        r16   k17 ; k17 = 194
.line	768	loadk        r17   k66 ; k66 = 33
.line	768	loadk        r18   k67 ; k67 = 89
.line	768	loadk        r19   k68 ; k68 = 55
.line	768	loadk        r20   k69 ; k69 = 96
.line	768	loadk        r21    k9 ; k9 = 200
.line	768	loadk        r22   k70 ; k70 = 207
.line	768	loadk        r23   k71 ; k71 = 129
.line	768	loadk        r24   k72 ; k72 = 122
.line	768	loadk        r25   k73 ; k73 = 202
.line	768	loadk        r26   k74 ; k74 = 28
.line	768	loadk        r27   k81 ; k81 = 43
.line	768	loadk        r28   k43 ; k43 = 193
.line	768	call          r5    24     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l179
.line	768	gettabup      r4    u0   k82 ; k82 = "IsBGMILITE"
.line	768	call          r4     1     2
.line	768	test          r4     0
.line	768	jmp            0  l218
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6   k59 ; k59 = 53
.line	768	loadk         r7   k60 ; k60 = 191
.line	768	loadk         r8   k61 ; k61 = 6
.line	768	loadk         r9   k62 ; k62 = 251
.line	768	loadk        r10   k28 ; k28 = 214
.line	768	loadk        r11    k5 ; k5 = 44
.line	768	loadk        r12   k63 ; k63 = 142
.line	768	loadk        r13   k46 ; k46 = 76
.line	768	loadk        r14   k64 ; k64 = 138
.line	768	loadk        r15   k65 ; k65 = 247
.line	768	loadk        r16   k17 ; k17 = 194
.line	768	loadk        r17   k66 ; k66 = 33
.line	768	loadk        r18   k67 ; k67 = 89
.line	768	loadk        r19   k68 ; k68 = 55
.line	768	loadk        r20   k69 ; k69 = 96
.line	768	loadk        r21    k9 ; k9 = 200
.line	768	loadk        r22   k70 ; k70 = 207
.line	768	loadk        r23   k71 ; k71 = 129
.line	768	loadk        r24   k72 ; k72 = 122
.line	768	loadk        r25   k73 ; k73 = 202
.line	768	loadk        r26   k74 ; k74 = 28
.line	768	loadk        r27   k83 ; k83 = 61
.line	768	loadk        r28   k84 ; k84 = 209
.line	768	loadk        r29   k85 ; k85 = 80
.line	768	loadk        r30   k86 ; k86 = 161
.line	768	loadk        r31    k6 ; k6 = 204
.line	768	loadk        r32   k87 ; k87 = 254
.line	768	loadk        r33   k77 ; k77 = 41
.line	768	loadk        r34   k88 ; k88 = 105
.line	768	call          r5    30     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l218
.line	768	gettabup      r4    u0   k89 ; k89 = "IsBLUEHOLE"
.line	768	call          r4     1     2
.line	768	test          r4     0
.line	768	jmp            0  l257
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6   k59 ; k59 = 53
.line	768	loadk         r7   k60 ; k60 = 191
.line	768	loadk         r8   k61 ; k61 = 6
.line	768	loadk         r9   k62 ; k62 = 251
.line	768	loadk        r10   k28 ; k28 = 214
.line	768	loadk        r11    k5 ; k5 = 44
.line	768	loadk        r12   k63 ; k63 = 142
.line	768	loadk        r13   k46 ; k46 = 76
.line	768	loadk        r14   k64 ; k64 = 138
.line	768	loadk        r15   k65 ; k65 = 247
.line	768	loadk        r16   k17 ; k17 = 194
.line	768	loadk        r17   k66 ; k66 = 33
.line	768	loadk        r18   k67 ; k67 = 89
.line	768	loadk        r19   k68 ; k68 = 55
.line	768	loadk        r20   k69 ; k69 = 96
.line	768	loadk        r21    k9 ; k9 = 200
.line	768	loadk        r22   k70 ; k70 = 207
.line	768	loadk        r23   k71 ; k71 = 129
.line	768	loadk        r24   k72 ; k72 = 122
.line	768	loadk        r25   k73 ; k73 = 202
.line	768	loadk        r26   k74 ; k74 = 28
.line	768	loadk        r27   k83 ; k83 = 61
.line	768	loadk        r28   k21 ; k21 = 218
.line	768	loadk        r29   k90 ; k90 = 72
.line	768	loadk        r30   k91 ; k91 = 173
.line	768	loadk        r31    k9 ; k9 = 200
.line	768	loadk        r32   k92 ; k92 = 248
.line	768	loadk        r33   k93 ; k93 = 49
.line	768	loadk        r34   k88 ; k88 = 105
.line	768	call          r5    30     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l257
.line	768	gettabup      r4    u0   k75 ; k75 = "PackageType"
.line	768	gettable      r4    r4   k94 ; k94 = "LIGHT_GLOBAL"
.line	768	eq             0    r2    r4
.line	768	jmp            0  l291
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6   k59 ; k59 = 53
.line	768	loadk         r7   k60 ; k60 = 191
.line	768	loadk         r8   k61 ; k61 = 6
.line	768	loadk         r9   k62 ; k62 = 251
.line	768	loadk        r10   k28 ; k28 = 214
.line	768	loadk        r11    k5 ; k5 = 44
.line	768	loadk        r12   k63 ; k63 = 142
.line	768	loadk        r13   k46 ; k46 = 76
.line	768	loadk        r14   k64 ; k64 = 138
.line	768	loadk        r15   k65 ; k65 = 247
.line	768	loadk        r16   k17 ; k17 = 194
.line	768	loadk        r17   k66 ; k66 = 33
.line	768	loadk        r18   k67 ; k67 = 89
.line	768	loadk        r19   k68 ; k68 = 55
.line	768	loadk        r20   k69 ; k69 = 96
.line	768	loadk        r21    k9 ; k9 = 200
.line	768	loadk        r22   k70 ; k70 = 207
.line	768	loadk        r23   k71 ; k71 = 129
.line	768	loadk        r24   k72 ; k72 = 122
.line	768	loadk        r25   k73 ; k73 = 202
.line	768	loadk        r26   k74 ; k74 = 28
.line	768	loadk        r27   k95 ; k95 = 57
.line	768	loadk        r28   k96 ; k96 = 223
.line	768	loadk        r29   k97 ; k97 = 73
.line	768	call          r5    25     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l291
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6   k59 ; k59 = 53
.line	768	loadk         r7   k60 ; k60 = 191
.line	768	loadk         r8   k61 ; k61 = 6
.line	768	loadk         r9   k62 ; k62 = 251
.line	768	loadk        r10   k28 ; k28 = 214
.line	768	loadk        r11    k5 ; k5 = 44
.line	768	loadk        r12   k63 ; k63 = 142
.line	768	loadk        r13   k46 ; k46 = 76
.line	768	loadk        r14   k64 ; k64 = 138
.line	768	loadk        r15   k65 ; k65 = 247
.line	768	loadk        r16   k17 ; k17 = 194
.line	768	loadk        r17   k66 ; k66 = 33
.line	768	loadk        r18   k67 ; k67 = 89
.line	768	loadk        r19   k68 ; k68 = 55
.line	768	loadk        r20   k69 ; k69 = 96
.line	768	loadk        r21    k9 ; k9 = 200
.line	768	loadk        r22   k70 ; k70 = 207
.line	768	loadk        r23   k71 ; k71 = 129
.line	768	loadk        r24   k72 ; k72 = 122
.line	768	loadk        r25   k73 ; k73 = 202
.line	768	loadk        r26   k74 ; k74 = 28
.line	768	loadk        r27   k98 ; k98 = 56
.line	768	loadk        r28   k21 ; k21 = 218
.line	768	loadk        r29   k99 ; k99 = 82
.line	768	loadk        r30  k100 ; k100 = 170
.line	768	loadk        r31   k43 ; k43 = 193
.line	768	loadk        r32   k62 ; k62 = 251
.line	768	call          r5    28     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l324
.line	768	gettabup      r4    u0   k57 ; k57 = "IsJapanOrKorea"
.line	768	call          r4     1     2
.line	768	test          r4     0
.line	768	jmp            0  l354
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6  k101 ; k101 = 50
.line	768	loadk         r7  k102 ; k102 = 157
.line	768	loadk         r8  k103 ; k103 = 38
.line	768	loadk         r9   k43 ; k43 = 193
.line	768	loadk        r10  k104 ; k104 = 210
.line	768	loadk        r11   k83 ; k83 = 61
.line	768	loadk        r12   k71 ; k71 = 129
.line	768	loadk        r13   k90 ; k90 = 72
.line	768	loadk        r14  k105 ; k105 = 180
.line	768	loadk        r15   k48 ; k48 = 245
.line	768	loadk        r16   k84 ; k84 = 209
.line	768	loadk        r17  k106 ; k106 = 8
.line	768	loadk        r18   k85 ; k85 = 80
.line	768	loadk        r19   k29 ; k29 = 30
.line	768	loadk        r20   k46 ; k46 = 76
.line	768	loadk        r21  k107 ; k107 = 235
.line	768	loadk        r22  k108 ; k108 = 195
.line	768	loadk        r23  k109 ; k109 = 151
.line	768	loadk        r24  k110 ; k110 = 127
.line	768	loadk        r25  k104 ; k104 = 210
.line	768	call          r5    21     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l354
.line	768	gettabup      r4    u0   k75 ; k75 = "PackageType"
.line	768	gettable      r4    r4   k76 ; k76 = "VNG"
.line	768	eq             0    r2    r4
.line	768	jmp            0  l385
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6  k101 ; k101 = 50
.line	768	loadk         r7  k102 ; k102 = 157
.line	768	loadk         r8  k103 ; k103 = 38
.line	768	loadk         r9   k43 ; k43 = 193
.line	768	loadk        r10  k104 ; k104 = 210
.line	768	loadk        r11   k83 ; k83 = 61
.line	768	loadk        r12   k71 ; k71 = 129
.line	768	loadk        r13   k90 ; k90 = 72
.line	768	loadk        r14  k105 ; k105 = 180
.line	768	loadk        r15   k48 ; k48 = 245
.line	768	loadk        r16   k84 ; k84 = 209
.line	768	loadk        r17  k106 ; k106 = 8
.line	768	loadk        r18   k85 ; k85 = 80
.line	768	loadk        r19   k29 ; k29 = 30
.line	768	loadk        r20   k46 ; k46 = 76
.line	768	loadk        r21  k107 ; k107 = 235
.line	768	loadk        r22  k108 ; k108 = 195
.line	768	loadk        r23  k109 ; k109 = 151
.line	768	loadk        r24  k111 ; k111 = 99
.line	768	loadk        r25   k53 ; k53 = 215
.line	768	loadk        r26  k112 ; k112 = 4
.line	768	call          r5    22     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l385
.line	768	gettabup      r4    u0   k75 ; k75 = "PackageType"
.line	768	gettable      r4    r4   k80 ; k80 = "TW"
.line	768	eq             0    r2    r4
.line	768	jmp            0  l415
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6  k101 ; k101 = 50
.line	768	loadk         r7  k102 ; k102 = 157
.line	768	loadk         r8  k103 ; k103 = 38
.line	768	loadk         r9   k43 ; k43 = 193
.line	768	loadk        r10  k104 ; k104 = 210
.line	768	loadk        r11   k83 ; k83 = 61
.line	768	loadk        r12   k71 ; k71 = 129
.line	768	loadk        r13   k90 ; k90 = 72
.line	768	loadk        r14  k105 ; k105 = 180
.line	768	loadk        r15   k48 ; k48 = 245
.line	768	loadk        r16   k84 ; k84 = 209
.line	768	loadk        r17  k106 ; k106 = 8
.line	768	loadk        r18   k85 ; k85 = 80
.line	768	loadk        r19   k29 ; k29 = 30
.line	768	loadk        r20   k46 ; k46 = 76
.line	768	loadk        r21  k107 ; k107 = 235
.line	768	loadk        r22  k108 ; k108 = 195
.line	768	loadk        r23  k109 ; k109 = 151
.line	768	loadk        r24   k39 ; k39 = 97
.line	768	loadk        r25  k113 ; k113 = 206
.line	768	call          r5    21     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l415
.line	768	gettabup      r4    u0   k82 ; k82 = "IsBGMILITE"
.line	768	call          r4     1     2
.line	768	test          r4     0
.line	768	jmp            0  l451
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6  k101 ; k101 = 50
.line	768	loadk         r7  k102 ; k102 = 157
.line	768	loadk         r8  k103 ; k103 = 38
.line	768	loadk         r9   k43 ; k43 = 193
.line	768	loadk        r10  k104 ; k104 = 210
.line	768	loadk        r11   k83 ; k83 = 61
.line	768	loadk        r12   k71 ; k71 = 129
.line	768	loadk        r13   k90 ; k90 = 72
.line	768	loadk        r14  k105 ; k105 = 180
.line	768	loadk        r15   k48 ; k48 = 245
.line	768	loadk        r16   k84 ; k84 = 209
.line	768	loadk        r17  k106 ; k106 = 8
.line	768	loadk        r18   k85 ; k85 = 80
.line	768	loadk        r19   k29 ; k29 = 30
.line	768	loadk        r20   k46 ; k46 = 76
.line	768	loadk        r21  k107 ; k107 = 235
.line	768	loadk        r22  k108 ; k108 = 195
.line	768	loadk        r23  k109 ; k109 = 151
.line	768	loadk        r24  k114 ; k114 = 119
.line	768	loadk        r25  k115 ; k115 = 222
.line	768	loadk        r26  k116 ; k116 = 14
.line	768	loadk        r27  k117 ; k117 = 54
.line	768	loadk        r28   k21 ; k21 = 218
.line	768	loadk        r29  k118 ; k118 = 84
.line	768	loadk        r30  k119 ; k119 = 188
.line	768	loadk        r31  k120 ; k120 = 197
.line	768	call          r5    27     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l451
.line	768	gettabup      r4    u0   k89 ; k89 = "IsBLUEHOLE"
.line	768	call          r4     1     2
.line	768	test          r4     0
.line	768	jmp            0  l487
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6  k101 ; k101 = 50
.line	768	loadk         r7  k102 ; k102 = 157
.line	768	loadk         r8  k103 ; k103 = 38
.line	768	loadk         r9   k43 ; k43 = 193
.line	768	loadk        r10  k104 ; k104 = 210
.line	768	loadk        r11   k83 ; k83 = 61
.line	768	loadk        r12   k71 ; k71 = 129
.line	768	loadk        r13   k90 ; k90 = 72
.line	768	loadk        r14  k105 ; k105 = 180
.line	768	loadk        r15   k48 ; k48 = 245
.line	768	loadk        r16   k84 ; k84 = 209
.line	768	loadk        r17  k106 ; k106 = 8
.line	768	loadk        r18   k85 ; k85 = 80
.line	768	loadk        r19   k29 ; k29 = 30
.line	768	loadk        r20   k46 ; k46 = 76
.line	768	loadk        r21  k107 ; k107 = 235
.line	768	loadk        r22  k108 ; k108 = 195
.line	768	loadk        r23  k109 ; k109 = 151
.line	768	loadk        r24  k114 ; k114 = 119
.line	768	loadk        r25  k121 ; k121 = 213
.line	768	loadk        r26   k23 ; k23 = 22
.line	768	loadk        r27  k122 ; k122 = 58
.line	768	loadk        r28  k115 ; k115 = 222
.line	768	loadk        r29   k99 ; k99 = 82
.line	768	loadk        r30  k123 ; k123 = 164
.line	768	loadk        r31  k120 ; k120 = 197
.line	768	call          r5    27     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l487
.line	768	gettabup      r4    u0   k75 ; k75 = "PackageType"
.line	768	gettable      r4    r4   k94 ; k94 = "LIGHT_GLOBAL"
.line	768	eq             0    r2    r4
.line	768	jmp            0  l518
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6  k101 ; k101 = 50
.line	768	loadk         r7  k102 ; k102 = 157
.line	768	loadk         r8  k103 ; k103 = 38
.line	768	loadk         r9   k43 ; k43 = 193
.line	768	loadk        r10  k104 ; k104 = 210
.line	768	loadk        r11   k83 ; k83 = 61
.line	768	loadk        r12   k71 ; k71 = 129
.line	768	loadk        r13   k90 ; k90 = 72
.line	768	loadk        r14  k105 ; k105 = 180
.line	768	loadk        r15   k48 ; k48 = 245
.line	768	loadk        r16   k84 ; k84 = 209
.line	768	loadk        r17  k106 ; k106 = 8
.line	768	loadk        r18   k85 ; k85 = 80
.line	768	loadk        r19   k29 ; k29 = 30
.line	768	loadk        r20   k46 ; k46 = 76
.line	768	loadk        r21  k107 ; k107 = 235
.line	768	loadk        r22  k108 ; k108 = 195
.line	768	loadk        r23  k109 ; k109 = 151
.line	768	loadk        r24   k25 ; k25 = 115
.line	768	loadk        r25  k124 ; k124 = 208
.line	768	loadk        r26  k125 ; k125 = 23
.line	768	call          r5    22     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l518
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6  k101 ; k101 = 50
.line	768	loadk         r7  k102 ; k102 = 157
.line	768	loadk         r8  k103 ; k103 = 38
.line	768	loadk         r9   k43 ; k43 = 193
.line	768	loadk        r10  k104 ; k104 = 210
.line	768	loadk        r11   k83 ; k83 = 61
.line	768	loadk        r12   k71 ; k71 = 129
.line	768	loadk        r13   k90 ; k90 = 72
.line	768	loadk        r14  k105 ; k105 = 180
.line	768	loadk        r15   k48 ; k48 = 245
.line	768	loadk        r16   k84 ; k84 = 209
.line	768	loadk        r17  k106 ; k106 = 8
.line	768	loadk        r18   k85 ; k85 = 80
.line	768	loadk        r19   k29 ; k29 = 30
.line	768	loadk        r20   k46 ; k46 = 76
.line	768	loadk        r21  k107 ; k107 = 235
.line	768	loadk        r22  k108 ; k108 = 195
.line	768	loadk        r23  k109 ; k109 = 151
.line	768	loadk        r24  k126 ; k126 = 114
.line	768	loadk        r25  k121 ; k121 = 213
.line	768	loadk        r26   k50 ; k50 = 12
.line	768	loadk        r27   k83 ; k83 = 61
.line	768	loadk        r28   k53 ; k53 = 215
.line	768	loadk        r29  k127 ; k127 = 81
.line	768	call          r5    25     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l548
.line	768	gettabup      r4    u2   k54 ; k54 = "Client"
.line	768	gettable      r4    r4   k55 ; k55 = "GetDevicePlatformNam" (truncated)
.line	768	call          r4     1     2
.line	768	gettable      r5    r3  k128 ; k128 = "Android"
.line	768	eq             0    r4    r5
.line	768	jmp            0 l1081
.line	768	test          r0     0
.line	768	jmp            0  l829
.line	768	gettabup      r4    u0   k57 ; k57 = "IsJapanOrKorea"
.line	768	call          r4     1     2
.line	768	test          r4     0
.line	768	jmp            0  l593
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6   k59 ; k59 = 53
.line	768	loadk         r7   k60 ; k60 = 191
.line	768	loadk         r8   k61 ; k61 = 6
.line	768	loadk         r9   k62 ; k62 = 251
.line	768	loadk        r10   k28 ; k28 = 214
.line	768	loadk        r11    k5 ; k5 = 44
.line	768	loadk        r12   k63 ; k63 = 142
.line	768	loadk        r13   k46 ; k46 = 76
.line	768	loadk        r14   k64 ; k64 = 138
.line	768	loadk        r15   k65 ; k65 = 247
.line	768	loadk        r16   k17 ; k17 = 194
.line	768	loadk        r17   k66 ; k66 = 33
.line	768	loadk        r18   k67 ; k67 = 89
.line	768	loadk        r19   k68 ; k68 = 55
.line	768	loadk        r20   k69 ; k69 = 96
.line	768	loadk        r21    k9 ; k9 = 200
.line	768	loadk        r22   k70 ; k70 = 207
.line	768	loadk        r23  k129 ; k129 = 137
.line	768	loadk        r24  k130 ; k130 = 91
.line	768	loadk        r25  k131 ; k131 = 253
.line	768	loadk        r26   k93 ; k93 = 49
.line	768	loadk        r27  k132 ; k132 = 16
.line	768	loadk        r28  k133 ; k133 = 255
.line	768	loadk        r29  k134 ; k134 = 121
.line	768	loadk        r30  k135 ; k135 = 183
.line	768	loadk        r31   k73 ; k73 = 202
.line	768	loadk        r32  k136 ; k136 = 252
.line	768	call          r5    28     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l593
.line	768	gettabup      r4    u0   k75 ; k75 = "PackageType"
.line	768	gettable      r4    r4   k76 ; k76 = "VNG"
.line	768	eq             0    r2    r4
.line	768	jmp            0  l631
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6   k59 ; k59 = 53
.line	768	loadk         r7   k60 ; k60 = 191
.line	768	loadk         r8   k61 ; k61 = 6
.line	768	loadk         r9   k62 ; k62 = 251
.line	768	loadk        r10   k28 ; k28 = 214
.line	768	loadk        r11    k5 ; k5 = 44
.line	768	loadk        r12   k63 ; k63 = 142
.line	768	loadk        r13   k46 ; k46 = 76
.line	768	loadk        r14   k64 ; k64 = 138
.line	768	loadk        r15   k65 ; k65 = 247
.line	768	loadk        r16   k17 ; k17 = 194
.line	768	loadk        r17   k66 ; k66 = 33
.line	768	loadk        r18   k67 ; k67 = 89
.line	768	loadk        r19   k68 ; k68 = 55
.line	768	loadk        r20   k69 ; k69 = 96
.line	768	loadk        r21    k9 ; k9 = 200
.line	768	loadk        r22   k70 ; k70 = 207
.line	768	loadk        r23  k129 ; k129 = 137
.line	768	loadk        r24  k130 ; k130 = 91
.line	768	loadk        r25  k131 ; k131 = 253
.line	768	loadk        r26   k93 ; k93 = 49
.line	768	loadk        r27  k132 ; k132 = 16
.line	768	loadk        r28  k133 ; k133 = 255
.line	768	loadk        r29  k134 ; k134 = 121
.line	768	loadk        r30  k135 ; k135 = 183
.line	768	loadk        r31   k28 ; k28 = 214
.line	768	loadk        r32   k18 ; k18 = 249
.line	768	loadk        r33  k122 ; k122 = 58
.line	768	call          r5    29     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l631
.line	768	gettabup      r4    u0   k75 ; k75 = "PackageType"
.line	768	gettable      r4    r4   k80 ; k80 = "TW"
.line	768	eq             0    r2    r4
.line	768	jmp            0  l668
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6   k59 ; k59 = 53
.line	768	loadk         r7   k60 ; k60 = 191
.line	768	loadk         r8   k61 ; k61 = 6
.line	768	loadk         r9   k62 ; k62 = 251
.line	768	loadk        r10   k28 ; k28 = 214
.line	768	loadk        r11    k5 ; k5 = 44
.line	768	loadk        r12   k63 ; k63 = 142
.line	768	loadk        r13   k46 ; k46 = 76
.line	768	loadk        r14   k64 ; k64 = 138
.line	768	loadk        r15   k65 ; k65 = 247
.line	768	loadk        r16   k17 ; k17 = 194
.line	768	loadk        r17   k66 ; k66 = 33
.line	768	loadk        r18   k67 ; k67 = 89
.line	768	loadk        r19   k68 ; k68 = 55
.line	768	loadk        r20   k69 ; k69 = 96
.line	768	loadk        r21    k9 ; k9 = 200
.line	768	loadk        r22   k70 ; k70 = 207
.line	768	loadk        r23  k129 ; k129 = 137
.line	768	loadk        r24  k130 ; k130 = 91
.line	768	loadk        r25  k131 ; k131 = 253
.line	768	loadk        r26   k93 ; k93 = 49
.line	768	loadk        r27  k132 ; k132 = 16
.line	768	loadk        r28  k133 ; k133 = 255
.line	768	loadk        r29  k134 ; k134 = 121
.line	768	loadk        r30  k135 ; k135 = 183
.line	768	loadk        r31  k137 ; k137 = 212
.line	768	loadk        r32   k36 ; k36 = 224
.line	768	call          r5    28     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l668
.line	768	gettabup      r4    u0   k82 ; k82 = "IsBGMILITE"
.line	768	call          r4     1     2
.line	768	test          r4     0
.line	768	jmp            0  l711
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6   k59 ; k59 = 53
.line	768	loadk         r7   k60 ; k60 = 191
.line	768	loadk         r8   k61 ; k61 = 6
.line	768	loadk         r9   k62 ; k62 = 251
.line	768	loadk        r10   k28 ; k28 = 214
.line	768	loadk        r11    k5 ; k5 = 44
.line	768	loadk        r12   k63 ; k63 = 142
.line	768	loadk        r13   k46 ; k46 = 76
.line	768	loadk        r14   k64 ; k64 = 138
.line	768	loadk        r15   k65 ; k65 = 247
.line	768	loadk        r16   k17 ; k17 = 194
.line	768	loadk        r17   k66 ; k66 = 33
.line	768	loadk        r18   k67 ; k67 = 89
.line	768	loadk        r19   k68 ; k68 = 55
.line	768	loadk        r20   k69 ; k69 = 96
.line	768	loadk        r21    k9 ; k9 = 200
.line	768	loadk        r22   k70 ; k70 = 207
.line	768	loadk        r23  k129 ; k129 = 137
.line	768	loadk        r24  k130 ; k130 = 91
.line	768	loadk        r25  k131 ; k131 = 253
.line	768	loadk        r26   k93 ; k93 = 49
.line	768	loadk        r27  k132 ; k132 = 16
.line	768	loadk        r28  k133 ; k133 = 255
.line	768	loadk        r29  k134 ; k134 = 121
.line	768	loadk        r30  k135 ; k135 = 183
.line	768	loadk        r31   k17 ; k17 = 194
.line	768	loadk        r32  k138 ; k138 = 240
.line	768	loadk        r33   k37 ; k37 = 48
.line	768	loadk        r34  k139 ; k139 = 101
.line	768	loadk        r35  k140 ; k140 = 29
.line	768	loadk        r36  k141 ; k141 = 92
.line	768	loadk        r37   k36 ; k36 = 224
.line	768	loadk        r38  k120 ; k120 = 197
.line	768	call          r5    34     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l711
.line	768	gettabup      r4    u0   k89 ; k89 = "IsBLUEHOLE"
.line	768	call          r4     1     2
.line	768	test          r4     0
.line	768	jmp            0  l754
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6   k59 ; k59 = 53
.line	768	loadk         r7   k60 ; k60 = 191
.line	768	loadk         r8   k61 ; k61 = 6
.line	768	loadk         r9   k62 ; k62 = 251
.line	768	loadk        r10   k28 ; k28 = 214
.line	768	loadk        r11    k5 ; k5 = 44
.line	768	loadk        r12   k63 ; k63 = 142
.line	768	loadk        r13   k46 ; k46 = 76
.line	768	loadk        r14   k64 ; k64 = 138
.line	768	loadk        r15   k65 ; k65 = 247
.line	768	loadk        r16   k17 ; k17 = 194
.line	768	loadk        r17   k66 ; k66 = 33
.line	768	loadk        r18   k67 ; k67 = 89
.line	768	loadk        r19   k68 ; k68 = 55
.line	768	loadk        r20   k69 ; k69 = 96
.line	768	loadk        r21    k9 ; k9 = 200
.line	768	loadk        r22   k70 ; k70 = 207
.line	768	loadk        r23  k129 ; k129 = 137
.line	768	loadk        r24  k130 ; k130 = 91
.line	768	loadk        r25  k131 ; k131 = 253
.line	768	loadk        r26   k93 ; k93 = 49
.line	768	loadk        r27  k132 ; k132 = 16
.line	768	loadk        r28  k133 ; k133 = 255
.line	768	loadk        r29  k134 ; k134 = 121
.line	768	loadk        r30  k135 ; k135 = 183
.line	768	loadk        r31   k17 ; k17 = 194
.line	768	loadk        r32   k62 ; k62 = 251
.line	768	loadk        r33  k142 ; k142 = 40
.line	768	loadk        r34   k88 ; k88 = 105
.line	768	loadk        r35  k143 ; k143 = 25
.line	768	loadk        r36   k79 ; k79 = 90
.line	768	loadk        r37   k92 ; k92 = 248
.line	768	loadk        r38  k120 ; k120 = 197
.line	768	call          r5    34     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l754
.line	768	gettabup      r4    u0   k75 ; k75 = "PackageType"
.line	768	gettable      r4    r4   k94 ; k94 = "LIGHT_GLOBAL"
.line	768	eq             0    r2    r4
.line	768	jmp            0  l792
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6   k59 ; k59 = 53
.line	768	loadk         r7   k60 ; k60 = 191
.line	768	loadk         r8   k61 ; k61 = 6
.line	768	loadk         r9   k62 ; k62 = 251
.line	768	loadk        r10   k28 ; k28 = 214
.line	768	loadk        r11    k5 ; k5 = 44
.line	768	loadk        r12   k63 ; k63 = 142
.line	768	loadk        r13   k46 ; k46 = 76
.line	768	loadk        r14   k64 ; k64 = 138
.line	768	loadk        r15   k65 ; k65 = 247
.line	768	loadk        r16   k17 ; k17 = 194
.line	768	loadk        r17   k66 ; k66 = 33
.line	768	loadk        r18   k67 ; k67 = 89
.line	768	loadk        r19   k68 ; k68 = 55
.line	768	loadk        r20   k69 ; k69 = 96
.line	768	loadk        r21    k9 ; k9 = 200
.line	768	loadk        r22   k70 ; k70 = 207
.line	768	loadk        r23  k129 ; k129 = 137
.line	768	loadk        r24  k130 ; k130 = 91
.line	768	loadk        r25  k131 ; k131 = 253
.line	768	loadk        r26   k93 ; k93 = 49
.line	768	loadk        r27  k132 ; k132 = 16
.line	768	loadk        r28  k133 ; k133 = 255
.line	768	loadk        r29  k134 ; k134 = 121
.line	768	loadk        r30  k135 ; k135 = 183
.line	768	loadk        r31   k12 ; k12 = 198
.line	768	loadk        r32   k87 ; k87 = 254
.line	768	loadk        r33   k77 ; k77 = 41
.line	768	call          r5    29     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l792
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6   k59 ; k59 = 53
.line	768	loadk         r7   k60 ; k60 = 191
.line	768	loadk         r8   k61 ; k61 = 6
.line	768	loadk         r9   k62 ; k62 = 251
.line	768	loadk        r10   k28 ; k28 = 214
.line	768	loadk        r11    k5 ; k5 = 44
.line	768	loadk        r12   k63 ; k63 = 142
.line	768	loadk        r13   k46 ; k46 = 76
.line	768	loadk        r14   k64 ; k64 = 138
.line	768	loadk        r15   k65 ; k65 = 247
.line	768	loadk        r16   k17 ; k17 = 194
.line	768	loadk        r17   k66 ; k66 = 33
.line	768	loadk        r18   k67 ; k67 = 89
.line	768	loadk        r19   k68 ; k68 = 55
.line	768	loadk        r20   k69 ; k69 = 96
.line	768	loadk        r21    k9 ; k9 = 200
.line	768	loadk        r22   k70 ; k70 = 207
.line	768	loadk        r23  k129 ; k129 = 137
.line	768	loadk        r24  k130 ; k130 = 91
.line	768	loadk        r25  k131 ; k131 = 253
.line	768	loadk        r26   k93 ; k93 = 49
.line	768	loadk        r27  k132 ; k132 = 16
.line	768	loadk        r28  k133 ; k133 = 255
.line	768	loadk        r29  k134 ; k134 = 121
.line	768	loadk        r30  k135 ; k135 = 183
.line	768	loadk        r31  k144 ; k144 = 199
.line	768	loadk        r32   k62 ; k62 = 251
.line	768	loadk        r33  k101 ; k101 = 50
.line	768	loadk        r34  k145 ; k145 = 110
.line	768	loadk        r35  k132 ; k132 = 16
.line	768	loadk        r36   k67 ; k67 = 89
.line	768	call          r5    32     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l829
.line	768	gettabup      r4    u0   k57 ; k57 = "IsJapanOrKorea"
.line	768	call          r4     1     2
.line	768	test          r4     0
.line	768	jmp            0  l863
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6  k101 ; k101 = 50
.line	768	loadk         r7  k102 ; k102 = 157
.line	768	loadk         r8  k103 ; k103 = 38
.line	768	loadk         r9   k43 ; k43 = 193
.line	768	loadk        r10  k104 ; k104 = 210
.line	768	loadk        r11   k83 ; k83 = 61
.line	768	loadk        r12   k71 ; k71 = 129
.line	768	loadk        r13   k90 ; k90 = 72
.line	768	loadk        r14  k105 ; k105 = 180
.line	768	loadk        r15   k48 ; k48 = 245
.line	768	loadk        r16   k84 ; k84 = 209
.line	768	loadk        r17  k106 ; k106 = 8
.line	768	loadk        r18   k85 ; k85 = 80
.line	768	loadk        r19   k29 ; k29 = 30
.line	768	loadk        r20  k146 ; k146 = 68
.line	768	loadk        r21   k73 ; k73 = 202
.line	768	loadk        r22  k147 ; k147 = 244
.line	768	loadk        r23  k148 ; k148 = 186
.line	768	loadk        r24   k79 ; k79 = 90
.line	768	loadk        r25  k138 ; k138 = 240
.line	768	loadk        r26  k149 ; k149 = 39
.line	768	loadk        r27  k150 ; k150 = 32
.line	768	loadk        r28  k151 ; k151 = 220
.line	768	loadk        r29  k152 ; k152 = 86
.line	768	call          r5    25     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l863
.line	768	gettabup      r4    u0   k75 ; k75 = "PackageType"
.line	768	gettable      r4    r4   k76 ; k76 = "VNG"
.line	768	eq             0    r2    r4
.line	768	jmp            0  l898
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6  k101 ; k101 = 50
.line	768	loadk         r7  k102 ; k102 = 157
.line	768	loadk         r8  k103 ; k103 = 38
.line	768	loadk         r9   k43 ; k43 = 193
.line	768	loadk        r10  k104 ; k104 = 210
.line	768	loadk        r11   k83 ; k83 = 61
.line	768	loadk        r12   k71 ; k71 = 129
.line	768	loadk        r13   k90 ; k90 = 72
.line	768	loadk        r14  k105 ; k105 = 180
.line	768	loadk        r15   k48 ; k48 = 245
.line	768	loadk        r16   k84 ; k84 = 209
.line	768	loadk        r17  k106 ; k106 = 8
.line	768	loadk        r18   k85 ; k85 = 80
.line	768	loadk        r19   k29 ; k29 = 30
.line	768	loadk        r20  k146 ; k146 = 68
.line	768	loadk        r21   k73 ; k73 = 202
.line	768	loadk        r22  k147 ; k147 = 244
.line	768	loadk        r23  k148 ; k148 = 186
.line	768	loadk        r24   k79 ; k79 = 90
.line	768	loadk        r25  k138 ; k138 = 240
.line	768	loadk        r26  k149 ; k149 = 39
.line	768	loadk        r27  k150 ; k150 = 32
.line	768	loadk        r28  k153 ; k153 = 192
.line	768	loadk        r29   k35 ; k35 = 83
.line	768	loadk        r30   k19 ; k19 = 175
.line	768	call          r5    26     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l898
.line	768	gettabup      r4    u0   k75 ; k75 = "PackageType"
.line	768	gettable      r4    r4   k80 ; k80 = "TW"
.line	768	eq             0    r2    r4
.line	768	jmp            0  l932
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6  k101 ; k101 = 50
.line	768	loadk         r7  k102 ; k102 = 157
.line	768	loadk         r8  k103 ; k103 = 38
.line	768	loadk         r9   k43 ; k43 = 193
.line	768	loadk        r10  k104 ; k104 = 210
.line	768	loadk        r11   k83 ; k83 = 61
.line	768	loadk        r12   k71 ; k71 = 129
.line	768	loadk        r13   k90 ; k90 = 72
.line	768	loadk        r14  k105 ; k105 = 180
.line	768	loadk        r15   k48 ; k48 = 245
.line	768	loadk        r16   k84 ; k84 = 209
.line	768	loadk        r17  k106 ; k106 = 8
.line	768	loadk        r18   k85 ; k85 = 80
.line	768	loadk        r19   k29 ; k29 = 30
.line	768	loadk        r20  k146 ; k146 = 68
.line	768	loadk        r21   k73 ; k73 = 202
.line	768	loadk        r22  k147 ; k147 = 244
.line	768	loadk        r23  k148 ; k148 = 186
.line	768	loadk        r24   k79 ; k79 = 90
.line	768	loadk        r25  k138 ; k138 = 240
.line	768	loadk        r26  k149 ; k149 = 39
.line	768	loadk        r27  k150 ; k150 = 32
.line	768	loadk        r28   k17 ; k17 = 194
.line	768	loadk        r29  k154 ; k154 = 74
.line	768	call          r5    25     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l932
.line	768	gettabup      r4    u0   k82 ; k82 = "IsBGMILITE"
.line	768	call          r4     1     2
.line	768	test          r4     0
.line	768	jmp            0  l972
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6  k101 ; k101 = 50
.line	768	loadk         r7  k102 ; k102 = 157
.line	768	loadk         r8  k103 ; k103 = 38
.line	768	loadk         r9   k43 ; k43 = 193
.line	768	loadk        r10  k104 ; k104 = 210
.line	768	loadk        r11   k83 ; k83 = 61
.line	768	loadk        r12   k71 ; k71 = 129
.line	768	loadk        r13   k90 ; k90 = 72
.line	768	loadk        r14  k105 ; k105 = 180
.line	768	loadk        r15   k48 ; k48 = 245
.line	768	loadk        r16   k84 ; k84 = 209
.line	768	loadk        r17  k106 ; k106 = 8
.line	768	loadk        r18   k85 ; k85 = 80
.line	768	loadk        r19   k29 ; k29 = 30
.line	768	loadk        r20  k146 ; k146 = 68
.line	768	loadk        r21   k73 ; k73 = 202
.line	768	loadk        r22  k147 ; k147 = 244
.line	768	loadk        r23  k148 ; k148 = 186
.line	768	loadk        r24   k79 ; k79 = 90
.line	768	loadk        r25  k138 ; k138 = 240
.line	768	loadk        r26  k149 ; k149 = 39
.line	768	loadk        r27  k150 ; k150 = 32
.line	768	loadk        r28  k137 ; k137 = 212
.line	768	loadk        r29   k79 ; k79 = 90
.line	768	loadk        r30  k155 ; k155 = 165
.line	768	loadk        r31  k156 ; k156 = 201
.line	768	loadk        r32   k62 ; k62 = 251
.line	768	loadk        r33  k157 ; k157 = 52
.line	768	loadk        r34  k158 ; k158 = 120
.line	768	loadk        r35  k159 ; k159 = 20
.line	768	call          r5    31     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l972
.line	768	gettabup      r4    u0   k89 ; k89 = "IsBLUEHOLE"
.line	768	call          r4     1     2
.line	768	test          r4     0
.line	768	jmp            0 l1012
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6  k101 ; k101 = 50
.line	768	loadk         r7  k102 ; k102 = 157
.line	768	loadk         r8  k103 ; k103 = 38
.line	768	loadk         r9   k43 ; k43 = 193
.line	768	loadk        r10  k104 ; k104 = 210
.line	768	loadk        r11   k83 ; k83 = 61
.line	768	loadk        r12   k71 ; k71 = 129
.line	768	loadk        r13   k90 ; k90 = 72
.line	768	loadk        r14  k105 ; k105 = 180
.line	768	loadk        r15   k48 ; k48 = 245
.line	768	loadk        r16   k84 ; k84 = 209
.line	768	loadk        r17  k106 ; k106 = 8
.line	768	loadk        r18   k85 ; k85 = 80
.line	768	loadk        r19   k29 ; k29 = 30
.line	768	loadk        r20  k146 ; k146 = 68
.line	768	loadk        r21   k73 ; k73 = 202
.line	768	loadk        r22  k147 ; k147 = 244
.line	768	loadk        r23  k148 ; k148 = 186
.line	768	loadk        r24   k79 ; k79 = 90
.line	768	loadk        r25  k138 ; k138 = 240
.line	768	loadk        r26  k149 ; k149 = 39
.line	768	loadk        r27  k150 ; k150 = 32
.line	768	loadk        r28  k137 ; k137 = 212
.line	768	loadk        r29  k127 ; k127 = 81
.line	768	loadk        r30   k34 ; k34 = 189
.line	768	loadk        r31  k120 ; k120 = 197
.line	768	loadk        r32  k133 ; k133 = 255
.line	768	loadk        r33  k101 ; k101 = 50
.line	768	loadk        r34   k69 ; k69 = 96
.line	768	loadk        r35  k159 ; k159 = 20
.line	768	call          r5    31     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l1012
.line	768	gettabup      r4    u0   k75 ; k75 = "PackageType"
.line	768	gettable      r4    r4   k94 ; k94 = "LIGHT_GLOBAL"
.line	768	eq             0    r2    r4
.line	768	jmp            0 l1047
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6  k101 ; k101 = 50
.line	768	loadk         r7  k102 ; k102 = 157
.line	768	loadk         r8  k103 ; k103 = 38
.line	768	loadk         r9   k43 ; k43 = 193
.line	768	loadk        r10  k104 ; k104 = 210
.line	768	loadk        r11   k83 ; k83 = 61
.line	768	loadk        r12   k71 ; k71 = 129
.line	768	loadk        r13   k90 ; k90 = 72
.line	768	loadk        r14  k105 ; k105 = 180
.line	768	loadk        r15   k48 ; k48 = 245
.line	768	loadk        r16   k84 ; k84 = 209
.line	768	loadk        r17  k106 ; k106 = 8
.line	768	loadk        r18   k85 ; k85 = 80
.line	768	loadk        r19   k29 ; k29 = 30
.line	768	loadk        r20  k146 ; k146 = 68
.line	768	loadk        r21   k73 ; k73 = 202
.line	768	loadk        r22  k147 ; k147 = 244
.line	768	loadk        r23  k148 ; k148 = 186
.line	768	loadk        r24   k79 ; k79 = 90
.line	768	loadk        r25  k138 ; k138 = 240
.line	768	loadk        r26  k149 ; k149 = 39
.line	768	loadk        r27  k150 ; k150 = 32
.line	768	loadk        r28  k124 ; k124 = 208
.line	768	loadk        r29  k118 ; k118 = 84
.line	768	loadk        r30  k119 ; k119 = 188
.line	768	call          r5    26     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l1047
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6  k101 ; k101 = 50
.line	768	loadk         r7  k102 ; k102 = 157
.line	768	loadk         r8  k103 ; k103 = 38
.line	768	loadk         r9   k43 ; k43 = 193
.line	768	loadk        r10  k104 ; k104 = 210
.line	768	loadk        r11   k83 ; k83 = 61
.line	768	loadk        r12   k71 ; k71 = 129
.line	768	loadk        r13   k90 ; k90 = 72
.line	768	loadk        r14  k105 ; k105 = 180
.line	768	loadk        r15   k48 ; k48 = 245
.line	768	loadk        r16   k84 ; k84 = 209
.line	768	loadk        r17  k106 ; k106 = 8
.line	768	loadk        r18   k85 ; k85 = 80
.line	768	loadk        r19   k29 ; k29 = 30
.line	768	loadk        r20  k146 ; k146 = 68
.line	768	loadk        r21   k73 ; k73 = 202
.line	768	loadk        r22  k147 ; k147 = 244
.line	768	loadk        r23  k148 ; k148 = 186
.line	768	loadk        r24   k79 ; k79 = 90
.line	768	loadk        r25  k138 ; k138 = 240
.line	768	loadk        r26  k149 ; k149 = 39
.line	768	loadk        r27  k150 ; k150 = 32
.line	768	loadk        r28   k84 ; k84 = 209
.line	768	loadk        r29  k127 ; k127 = 81
.line	768	loadk        r30  k160 ; k160 = 167
.line	768	loadk        r31   k17 ; k17 = 194
.line	768	loadk        r32  k161 ; k161 = 246
.line	768	loadk        r33   k93 ; k93 = 49
.line	768	call          r5    29     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l1081
.line	768	test          r0     0
.line	768	jmp            0 l1116
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6   k59 ; k59 = 53
.line	768	loadk         r7   k60 ; k60 = 191
.line	768	loadk         r8   k61 ; k61 = 6
.line	768	loadk         r9   k62 ; k62 = 251
.line	768	loadk        r10   k28 ; k28 = 214
.line	768	loadk        r11    k5 ; k5 = 44
.line	768	loadk        r12   k63 ; k63 = 142
.line	768	loadk        r13   k46 ; k46 = 76
.line	768	loadk        r14   k64 ; k64 = 138
.line	768	loadk        r15   k65 ; k65 = 247
.line	768	loadk        r16   k17 ; k17 = 194
.line	768	loadk        r17   k66 ; k66 = 33
.line	768	loadk        r18   k67 ; k67 = 89
.line	768	loadk        r19   k68 ; k68 = 55
.line	768	loadk        r20   k69 ; k69 = 96
.line	768	loadk        r21    k9 ; k9 = 200
.line	768	loadk        r22   k70 ; k70 = 207
.line	768	loadk        r23   k71 ; k71 = 129
.line	768	loadk        r24   k72 ; k72 = 122
.line	768	loadk        r25   k73 ; k73 = 202
.line	768	loadk        r26   k74 ; k74 = 28
.line	768	loadk        r27   k98 ; k98 = 56
.line	768	loadk        r28   k21 ; k21 = 218
.line	768	loadk        r29   k99 ; k99 = 82
.line	768	loadk        r30  k100 ; k100 = 170
.line	768	loadk        r31   k43 ; k43 = 193
.line	768	loadk        r32   k62 ; k62 = 251
.line	768	call          r5    28     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.line	768	jmp            0 l1145
.label	l1116
.line	768	gettabup      r4    u4   k58 ; k58 = "GetTable"
.line	768	getupval      r5    u3
.line	768	loadk         r6  k101 ; k101 = 50
.line	768	loadk         r7  k102 ; k102 = 157
.line	768	loadk         r8  k103 ; k103 = 38
.line	768	loadk         r9   k43 ; k43 = 193
.line	768	loadk        r10  k104 ; k104 = 210
.line	768	loadk        r11   k83 ; k83 = 61
.line	768	loadk        r12   k71 ; k71 = 129
.line	768	loadk        r13   k90 ; k90 = 72
.line	768	loadk        r14  k105 ; k105 = 180
.line	768	loadk        r15   k48 ; k48 = 245
.line	768	loadk        r16   k84 ; k84 = 209
.line	768	loadk        r17  k106 ; k106 = 8
.line	768	loadk        r18   k85 ; k85 = 80
.line	768	loadk        r19   k29 ; k29 = 30
.line	768	loadk        r20   k46 ; k46 = 76
.line	768	loadk        r21  k107 ; k107 = 235
.line	768	loadk        r22  k108 ; k108 = 195
.line	768	loadk        r23  k109 ; k109 = 151
.line	768	loadk        r24  k126 ; k126 = 114
.line	768	loadk        r25  k121 ; k121 = 213
.line	768	loadk        r26   k50 ; k50 = 12
.line	768	loadk        r27   k83 ; k83 = 61
.line	768	loadk        r28   k53 ; k53 = 215
.line	768	loadk        r29  k127 ; k127 = 81
.line	768	call          r5    25     2
.line	768	call          r4     2     2
.line	768	move          r1    r4
.label	l1145
.line	768	return        r1     2
.line	768	return        r0     1
.line	768	move          r0    r0
.line	768	move          r0    r0
.line	768	move          r0    r0
.line	768	return        r0     1

.function	main/f45

.source	null
.linedefined	844
.lastlinedefined	861
.numparams	1
.is_vararg	0
.maxstacksize	21

.upvalue	"_ENV"	27	true
.upvalue	"U1"	1	true
.upvalue	"U2"	0	false
.upvalue	"U3"	21	true

.constant	k0	"GetTable"
.constant	k1	44
.constant	k2	151
.constant	k3	34
.constant	k4	192
.constant	k5	221
.constant	k6	27
.constant	k7	159
.constant	k8	93
.constant	k9	157
.constant	k10	220
.constant	k11	206
.constant	k12	30
.constant	k13	72
.constant	k14	2
.constant	k15	99
.constant	k16	195
.constant	k17	"Client"
.constant	k18	"GetCurrentLanguage"
.constant	k19	"ModuleManager"
.constant	k20	"GetModule"
.constant	k21	"CommonModuleConfig"
.constant	k22	"logic_cloud_game"
.constant	k23	"IsCloudVersion"
.constant	k24	35
.constant	k25	180
.constant	k26	10
.constant	k27	252
.constant	k28	247
.constant	k29	"ID"
.constant	k30	"language"
.constant	k31	4
.constant	k32	200
.constant	k33	198
.constant	k34	146

.line	844	gettabup      r1    u0    k0 ; k0 = "GetTable"
.line	844	getupval      r2    u1
.line	844	loadk         r3    k1 ; k1 = 44
.line	844	loadk         r4    k2 ; k2 = 151
.line	844	loadk         r5    k3 ; k3 = 34
.line	844	loadk         r6    k4 ; k4 = 192
.line	844	loadk         r7    k5 ; k5 = 221
.line	844	loadk         r8    k6 ; k6 = 27
.line	844	loadk         r9    k7 ; k7 = 159
.line	844	loadk        r10    k8 ; k8 = 93
.line	844	loadk        r11    k9 ; k9 = 157
.line	844	loadk        r12   k10 ; k10 = 220
.line	844	loadk        r13   k11 ; k11 = 206
.line	844	loadk        r14   k12 ; k12 = 30
.line	844	loadk        r15   k13 ; k13 = 72
.line	844	loadk        r16   k14 ; k14 = 2
.line	844	loadk        r17   k15 ; k15 = 99
.line	844	loadk        r18   k16 ; k16 = 195
.line	844	call          r2    17     2
.line	844	call          r1     2     2
.line	844	loadnil       r2     0
.line	844	gettabup      r3    u2   k17 ; k17 = "Client"
.line	844	gettable      r3    r3   k18 ; k18 = "GetCurrentLanguage"
.line	844	call          r3     1     2
.line	844	gettabup      r4    u2   k19 ; k19 = "ModuleManager"
.line	844	gettable      r4    r4   k20 ; k20 = "GetModule"
.line	844	gettabup      r5    u2   k19 ; k19 = "ModuleManager"
.line	844	gettable      r5    r5   k21 ; k21 = "CommonModuleConfig"
.line	844	gettable      r5    r5   k22 ; k22 = "logic_cloud_game"
.line	844	call          r4     2     2
.line	844	self          r5    r4   k23 ; k23 = "IsCloudVersion"
.line	844	call          r5     2     2
.line	844	test          r5     0
.line	844	jmp            0   l44
.line	844	getupval      r6    u1
.line	844	loadk         r7   k24 ; k24 = 35
.line	844	loadk         r8   k25 ; k25 = 180
.line	844	loadk         r9   k26 ; k26 = 10
.line	844	loadk        r10   k27 ; k27 = 252
.line	844	loadk        r11   k28 ; k28 = 247
.line	844	call          r6     6     2
.line	844	test          r6     1
.line	844	jmp            0   l45
.label	l44
.line	844	move          r6    r0
.label	l45
.line	844	getupval      r7    u3
.line	844	move          r8    r1
.line	844	call          r7     2     4
.line	844	jmp            0   l70
.line	844	gettable     r12   r11   k29 ; k29 = "ID"
.line	844	eq             0   r12    r6
.line	844	jmp            0   l70
.line	844	gettable     r12   r11   k30 ; k30 = "language"
.line	844	eq             0   r12    r3
.line	844	jmp            0   l57
.line	844	return       r11     2
.line	844	jmp            0   l70
.label	l57
.line	844	gettable     r12   r11   k30 ; k30 = "language"
.line	844	getupval     r13    u1
.line	844	loadk        r14   k31 ; k31 = 4
.line	844	loadk        r15    k9 ; k9 = 157
.line	844	loadk        r16   k24 ; k24 = 35
.line	844	loadk        r17   k32 ; k32 = 200
.line	844	loadk        r18   k33 ; k33 = 198
.line	844	loadk        r19   k24 ; k24 = 35
.line	844	loadk        r20   k34 ; k34 = 146
.line	844	call         r13     8     2
.line	844	eq             0   r12   r13
.line	844	jmp            0   l70
.line	844	move          r2   r11
.label	l70
.line	844	move          r0    r0
.line	844	move          r0    r0
.line	844	return        r2     2
.line	844	return        r0     1
.line	844	move          r0    r0
.line	844	move          r0    r0
.line	844	return        r0     1

.function	main/f46

.source	null
.linedefined	863
.lastlinedefined	865
.numparams	0
.is_vararg	0
.maxstacksize	14

.upvalue	"_ENV"	27	true
.upvalue	"U1"	1	true

.constant	k0	"GetTable"
.constant	k1	50
.constant	k2	157
.constant	k3	34
.constant	k4	192
.constant	k5	220
.constant	k6	33
.constant	k7	165
.constant	k8	66
.constant	k9	150
.constant	k10	246
.constant	k11	206
.constant	k12	10

.line	863	gettabup      r0    u0    k0 ; k0 = "GetTable"
.line	863	getupval      r1    u1
.line	863	loadk         r2    k1 ; k1 = 50
.line	863	loadk         r3    k2 ; k2 = 157
.line	863	loadk         r4    k3 ; k3 = 34
.line	863	loadk         r5    k4 ; k4 = 192
.line	863	loadk         r6    k5 ; k5 = 220
.line	863	loadk         r7    k6 ; k6 = 33
.line	863	loadk         r8    k7 ; k7 = 165
.line	863	loadk         r9    k8 ; k8 = 66
.line	863	loadk        r10    k9 ; k9 = 150
.line	863	loadk        r11   k10 ; k10 = 246
.line	863	loadk        r12   k11 ; k11 = 206
.line	863	loadk        r13   k12 ; k12 = 10
.line	863	call          r1    13     2
.line	863	tailcall      r0     2
.line	863	return        r0     0
.line	863	return        r0     1
.line	863	move          r0    r0
.line	863	move          r0    r0
.line	863	move          r0    r0
.line	863	move          r0    r0
.line	863	return        r0     1

.function	main/f47

.source	null
.linedefined	867
.lastlinedefined	878
.numparams	1
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	21	true
.upvalue	"U1"	11	true

.constant	k0	1
.constant	k1	0

.line	867	newtable      r1     0     0
.line	867	getupval      r2    u0
.line	867	move          r3    r0
.line	867	call          r2     2     4
.line	867	jmp            0    l9
.line	867	len           r7    r1
.line	867	add           r7    r7    k0 ; k0 = 1
.line	867	settable      r1    r7    r5
.label	l9
.line	867	move          r0    r0
.line	867	move          r0    r0
.line	867	getupval      r2    u1
.line	867	move          r3    r1
.line	867	call          r2     2     1
.line	867	loadk         r2    k1 ; k1 = 0
.line	867	closure       r3    f0
.line	867	return        r3     2
.line	867	return        r0     1
.line	867	move          r0    r0
.line	867	move          r0    r0
.line	867	move          r0    r0
.line	867	return        r0     1

.function	main/f47/f0

.source	null
.linedefined	874
.lastlinedefined	877
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	2	true
.upvalue	"U1"	1	true
.upvalue	"U2"	0	true

.constant	k0	1

.line	874	getupval      r0    u0
.line	874	add           r0    r0    k0 ; k0 = 1
.line	874	setupval      r0    u0
.line	874	getupval      r0    u0
.line	874	gettabup      r0    u1    r0
.line	874	getupval      r1    u0
.line	874	gettabup      r1    u1    r1
.line	874	move          r0    r0
.line	874	return        r0     3
.line	874	return        r0     1
.line	874	move          r0    r0
.line	874	move          r0    r0
.line	874	return        r0     1

.function	main/f48

.source	null
.linedefined	880
.lastlinedefined	891
.numparams	1
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	21	true
.upvalue	"U1"	11	true

.constant	k0	1

.line	880	newtable      r1     0     0
.line	880	getupval      r2    u0
.line	880	move          r3    r0
.line	880	call          r2     2     4
.line	880	jmp            0    l9
.line	880	len           r7    r1
.line	880	add           r7    r7    k0 ; k0 = 1
.line	880	settable      r1    r7    r5
.label	l9
.line	880	move          r0    r0
.line	880	move          r0    r0
.line	880	getupval      r2    u1
.line	880	move          r3    r1
.line	880	call          r2     2     1
.line	880	len           r2    r1
.line	880	add           r2    r2    k0 ; k0 = 1
.line	880	closure       r3    f0
.line	880	return        r3     2
.line	880	return        r0     1
.line	880	move          r0    r0
.line	880	move          r0    r0
.line	880	return        r0     1

.function	main/f48/f0

.source	null
.linedefined	887
.lastlinedefined	890
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	2	true
.upvalue	"U1"	1	true
.upvalue	"U2"	0	true

.constant	k0	1

.line	887	getupval      r0    u0
.line	887	sub           r0    r0    k0 ; k0 = 1
.line	887	setupval      r0    u0
.line	887	getupval      r0    u0
.line	887	gettabup      r0    u1    r0
.line	887	getupval      r1    u0
.line	887	gettabup      r1    u1    r1
.line	887	move          r0    r0
.line	887	return        r0     3
.line	887	return        r0     1
.line	887	move          r0    r0
.line	887	return        r0     1

.function	main/f49

.source	null
.linedefined	893
.lastlinedefined	895
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	23	true

.constant	k0	36

.line	893	getupval      r1    u0
.line	893	move          r2    r0
.line	893	loadk         r3    k0 ; k0 = 36
.line	893	tailcall      r1     3
.line	893	return        r1     0
.line	893	return        r0     1
.line	893	move          r0    r0
.line	893	move          r0    r0
.line	893	return        r0     1

.function	main/f50

.source	null
.linedefined	897
.lastlinedefined	905
.numparams	3
.is_vararg	0
.maxstacksize	3

.line	897	lt             0    r0    r1
.line	897	jmp            0    l5
.line	897	return        r1     2
.line	897	jmp            0   l10
.label	l5
.line	897	lt             0    r2    r0
.line	897	jmp            0    l9
.line	897	return        r2     2
.line	897	jmp            0   l10
.label	l9
.line	897	return        r0     2
.label	l10
.line	897	return        r0     1
.line	897	move          r0    r0
.line	897	move          r0    r0
.line	897	move          r0    r0
.line	897	return        r0     1

.function	main/f51

.source	null
.linedefined	907
.lastlinedefined	914
.numparams	1
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	13	true
.upvalue	"U1"	5	true
.upvalue	"U2"	1	true
.upvalue	"U3"	24	true

.constant	k0	1000.0
.constant	k1	100.0
.constant	k2	69
.constant	k3	214
.constant	k4	116
.constant	k5	207
.constant	k6	10
.constant	k7	43

.line	907	le             0    k0    r0 ; k0 = 1000.0
.line	907	jmp            0   l22
.line	907	getupval      r1    u0
.line	907	div           r2    r0    k1 ; k1 = 100.0
.line	907	call          r1     2     2
.line	907	move          r0    r1
.line	907	getupval      r1    u1
.line	907	getupval      r2    u2
.line	907	loadk         r3    k2 ; k2 = 69
.line	907	loadk         r4    k3 ; k3 = 214
.line	907	loadk         r5    k4 ; k4 = 116
.line	907	loadk         r6    k5 ; k5 = 207
.line	907	call          r2     5     2
.line	907	div           r3    r0    k6 ; k6 = 10
.line	907	call          r1     3     2
.line	907	getupval      r2    u2
.line	907	loadk         r3    k7 ; k7 = 43
.line	907	call          r2     2     2
.line	907	concat        r1    r1    r2
.line	907	return        r1     2
.line	907	jmp            0   l26
.label	l22
.line	907	getupval      r1    u3
.line	907	move          r2    r0
.line	907	tailcall      r1     2
.line	907	return        r1     0
.label	l26
.line	907	return        r0     1
.line	907	move          r0    r0
.line	907	return        r0     1

.function	main/f52

.source	null
.linedefined	916
.lastlinedefined	922
.numparams	3
.is_vararg	0
.maxstacksize	3

.line	916	test          r0     0
.line	916	jmp            0    l5
.line	916	return        r1     2
.line	916	jmp            0    l6
.label	l5
.line	916	return        r2     2
.label	l6
.line	916	return        r0     1
.line	916	move          r0    r0
.line	916	move          r0    r0
.line	916	move          r0    r0
.line	916	return        r0     1

.function	main/f53

.source	null
.linedefined	924
.lastlinedefined	934
.numparams	1
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	24	true
.upvalue	"U1"	0	false

.constant	k0	"FuncUtil"
.constant	k1	"IsPlayerJPKR"
.constant	k2	"IsUidGlobal"
.constant	k3	"IsUidJPKR"

.line	924	getupval      r1    u0
.line	924	move          r2    r0
.line	924	call          r1     2     2
.line	924	move          r0    r1
.line	924	gettabup      r1    u1    k0 ; k0 = "FuncUtil"
.line	924	gettable      r1    r1    k1 ; k1 = "IsPlayerJPKR"
.line	924	call          r1     1     2
.line	924	test          r1     1
.line	924	jmp            0   l19
.line	924	gettabup      r1    u1    k0 ; k0 = "FuncUtil"
.line	924	gettable      r1    r1    k2 ; k2 = "IsUidGlobal"
.line	924	move          r2    r0
.line	924	call          r1     2     2
.line	924	test          r1     0
.line	924	jmp            0   l27
.line	924	loadbool      r1     1     0
.line	924	return        r1     2
.line	924	jmp            0   l27
.label	l19
.line	924	gettabup      r1    u1    k0 ; k0 = "FuncUtil"
.line	924	gettable      r1    r1    k3 ; k3 = "IsUidJPKR"
.line	924	move          r2    r0
.line	924	call          r1     2     2
.line	924	test          r1     0
.line	924	jmp            0   l27
.line	924	loadbool      r1     1     0
.line	924	return        r1     2
.label	l27
.line	924	loadbool      r1     0     0
.line	924	return        r1     2
.line	924	return        r0     1
.line	924	move          r0    r0
.line	924	move          r0    r0
.line	924	move          r0    r0
.line	924	return        r0     1

.function	main/f54

.source	null
.linedefined	936
.lastlinedefined	938
.numparams	2
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	23	true

.constant	k0	0

.line	936	getupval      r2    u0
.line	936	move          r3    r0
.line	936	move          r4    r1
.line	936	call          r2     3     2
.line	936	test          r2     1
.line	936	jmp            0    l8
.line	936	loadk         r2    k0 ; k0 = 0
.label	l8
.line	936	return        r2     2
.line	936	return        r0     1
.line	936	move          r0    r0
.line	936	move          r0    r0
.line	936	return        r0     1

.function	main/f55

.source	null
.linedefined	940
.lastlinedefined	950
.numparams	1
.is_vararg	0
.maxstacksize	22

.upvalue	"_ENV"	24	true
.upvalue	"U1"	0	false
.upvalue	"U2"	6	true
.upvalue	"U3"	1	true

.constant	k0	"FuncUtil"
.constant	k1	"CheckNumber"
.constant	k2	62
.constant	k3	208
.constant	k4	104
.constant	k5	150
.constant	k6	43
.constant	k7	205
.constant	k8	4
.constant	k9	181
.constant	k10	195
.constant	k11	72
.constant	k12	88
.constant	k13	100
.constant	k14	97
.constant	k15	141
.constant	k16	69
.constant	k17	201
.constant	k18	105
.constant	k19	140
.constant	k20	129
.constant	k21	0

.line	940	getupval      r1    u0
.line	940	gettabup      r2    u1    k0 ; k0 = "FuncUtil"
.line	940	gettable      r2    r2    k1 ; k1 = "CheckNumber"
.line	940	move          r3    r0
.line	940	call          r2     2     0
.line	940	call          r1     0     2
.line	940	loadnil       r2     0
.label	l8
.line	940	getupval      r3    u2
.line	940	move          r4    r1
.line	940	getupval      r5    u3
.line	940	loadk         r6    k2 ; k2 = 62
.line	940	loadk         r7    k3 ; k3 = 208
.line	940	loadk         r8    k4 ; k4 = 104
.line	940	loadk         r9    k5 ; k5 = 150
.line	940	loadk        r10    k5 ; k5 = 150
.line	940	loadk        r11    k6 ; k6 = 43
.line	940	loadk        r12    k7 ; k7 = 205
.line	940	loadk        r13    k8 ; k8 = 4
.line	940	loadk        r14    k3 ; k3 = 208
.line	940	loadk        r15    k9 ; k9 = 181
.line	940	loadk        r16   k10 ; k10 = 195
.line	940	loadk        r17   k11 ; k11 = 72
.line	940	loadk        r18   k12 ; k12 = 88
.line	940	loadk        r19   k13 ; k13 = 100
.line	940	loadk        r20   k14 ; k14 = 97
.line	940	loadk        r21   k15 ; k15 = 141
.line	940	call          r5    17     2
.line	940	getupval      r6    u3
.line	940	loadk         r7   k16 ; k16 = 69
.line	940	loadk         r8   k17 ; k17 = 201
.line	940	loadk         r9   k18 ; k18 = 105
.line	940	loadk        r10   k19 ; k19 = 140
.line	940	loadk        r11   k20 ; k20 = 129
.line	940	call          r6     6     2
.line	940	call          r3     4     3
.line	940	move          r2    r4
.line	940	move          r1    r3
.line	940	eq             1    r2   k21 ; k21 = 0
.line	940	jmp            0   l41
.line	940	jmp            0    l8
.label	l41
.line	940	return        r1     2
.line	940	return        r0     1
.line	940	move          r0    r0
.line	940	move          r0    r0
.line	940	return        r0     1

.function	main/f56

.source	null
.linedefined	952
.lastlinedefined	962
.numparams	2
.is_vararg	0
.maxstacksize	15

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	0
.constant	k1	"FuncUtil"
.constant	k2	"TimeNumToTimeS"
.constant	k3	"LocUtil"
.constant	k4	"LocalizeResFormatByStr"
.constant	k5	27
.constant	k6	200
.constant	k7	56
.constant	k8	137
.constant	k9	232
.constant	k10	52
.constant	k11	215
.constant	k12	80
.constant	k13	165

.line	952	loadnil       r2     0
.line	952	test          r1     0
.line	952	jmp            0   l11
.line	952	lt             0    k0    r1 ; k0 = 0
.line	952	jmp            0   l11
.line	952	gettabup      r3    u0    k1 ; k1 = "FuncUtil"
.line	952	gettable      r3    r3    k2 ; k2 = "TimeNumToTimeS"
.line	952	move          r4    r1
.line	952	call          r3     2     2
.line	952	move          r2    r3
.label	l11
.line	952	move          r3    r0
.line	952	test          r2     0
.line	952	jmp            0   l31
.line	952	gettabup      r4    u0    k3 ; k3 = "LocUtil"
.line	952	gettable      r4    r4    k4 ; k4 = "LocalizeResFormatByS" (truncated)
.line	952	getupval      r5    u1
.line	952	loadk         r6    k5 ; k5 = 27
.line	952	loadk         r7    k6 ; k6 = 200
.line	952	loadk         r8    k7 ; k7 = 56
.line	952	loadk         r9    k8 ; k8 = 137
.line	952	loadk        r10    k9 ; k9 = 232
.line	952	loadk        r11   k10 ; k10 = 52
.line	952	loadk        r12   k11 ; k11 = 215
.line	952	loadk        r13   k12 ; k12 = 80
.line	952	loadk        r14   k13 ; k13 = 165
.line	952	call          r5    10     2
.line	952	move          r6    r0
.line	952	move          r7    r2
.line	952	call          r4     4     2
.line	952	move          r3    r4
.label	l31
.line	952	return        r3     2
.line	952	return        r0     1
.line	952	move          r0    r0
.line	952	move          r0    r0
.line	952	return        r0     1

.function	main/f57

.source	null
.linedefined	964
.lastlinedefined	975
.numparams	1
.is_vararg	0
.maxstacksize	39

.upvalue	"_ENV"	1	true
.upvalue	"U1"	22	true
.upvalue	"U2"	0	false
.upvalue	"U3"	24	true

.constant	k0	nil
.constant	k1	14
.constant	k2	141
.constant	k3	40
.constant	k4	203
.constant	k5	214
.constant	k6	61
.constant	k7	0
.constant	k8	24
.constant	k9	"LocUtil"
.constant	k10	"LocalizeResFormat"
.constant	k11	4795
.constant	k12	4409
.constant	k13	"math"
.constant	k14	"modf"
.constant	k15	"log"
.constant	k16	"bWriteLog"
.constant	k17	38
.constant	k18	43
.constant	k19	202
.constant	k20	230
.constant	k21	59
.constant	k22	143
.constant	k23	65
.constant	k24	196
.constant	k25	206
.constant	k26	89
.constant	k27	15
.constant	k28	112
.constant	k29	201
.constant	k30	167
.constant	k31	97
.constant	k32	240
.constant	k33	46
.constant	k34	26
.constant	k35	197
.constant	k36	49
.constant	k37	200
.constant	k38	244
.constant	k39	222
.constant	k40	16
.constant	k41	73
.constant	k42	31
.constant	k43	96
.constant	k44	217
.constant	k45	160
.constant	k46	229
.constant	k47	5
.constant	k48	76
.constant	k49	216
.constant	k50	55
.constant	k51	204
.constant	k52	192
.constant	k53	58
.constant	k54	138
.constant	k55	173
.constant	k56	135

.line	964	getupval      r1    u0
.line	964	call          r1     1     2
.line	964	eq             1    r0    k0 ; k0 = nil
.line	964	jmp            0   l42
.line	964	getupval      r2    u1
.line	964	move          r3    r0
.line	964	call          r2     2     2
.line	964	getupval      r3    u0
.line	964	loadk         r4    k1 ; k1 = 14
.line	964	loadk         r5    k2 ; k2 = 141
.line	964	loadk         r6    k3 ; k3 = 40
.line	964	loadk         r7    k4 ; k4 = 203
.line	964	loadk         r8    k5 ; k5 = 214
.line	964	loadk         r9    k6 ; k6 = 61
.line	964	call          r3     7     2
.line	964	eq             0    r2    r3
.line	964	jmp            0   l42
.line	964	lt             0    k7    r0 ; k7 = 0
.line	964	jmp            0   l42
.line	964	lt             0    r0    k8 ; k8 = 24
.line	964	jmp            0   l31
.line	964	gettabup      r2    u2    k9 ; k9 = "LocUtil"
.line	964	gettable      r2    r2   k10 ; k10 = "LocalizeResFormat"
.line	964	loadk         r3   k11 ; k11 = 4795
.line	964	getupval      r4    u3
.line	964	move          r5    r0
.line	964	call          r4     2     0
.line	964	call          r2     0     2
.line	964	move          r1    r2
.line	964	jmp            0   l42
.label	l31
.line	964	gettabup      r2    u2    k9 ; k9 = "LocUtil"
.line	964	gettable      r2    r2   k10 ; k10 = "LocalizeResFormat"
.line	964	loadk         r3   k12 ; k12 = 4409
.line	964	getupval      r4    u3
.line	964	gettabup      r5    u2   k13 ; k13 = "math"
.line	964	gettable      r5    r5   k14 ; k14 = "modf"
.line	964	div           r6    r0    k8 ; k8 = 24
.line	964	call          r5     2     0
.line	964	call          r4     0     0
.line	964	call          r2     0     2
.line	964	move          r1    r2
.label	l42
.line	964	gettabup      r2    u2   k15 ; k15 = "log"
.line	964	gettabup      r3    u2   k16 ; k16 = "bWriteLog"
.line	964	test          r3     0
.line	964	jmp            0  l103
.line	964	getupval      r3    u0
.line	964	loadk         r4   k17 ; k17 = 38
.line	964	loadk         r5    k2 ; k2 = 141
.line	964	loadk         r6   k18 ; k18 = 43
.line	964	loadk         r7   k19 ; k19 = 202
.line	964	loadk         r8   k20 ; k20 = 230
.line	964	loadk         r9   k21 ; k21 = 59
.line	964	loadk        r10   k22 ; k22 = 143
.line	964	loadk        r11   k23 ; k23 = 65
.line	964	loadk        r12    k5 ; k5 = 214
.line	964	loadk        r13   k24 ; k24 = 196
.line	964	loadk        r14   k25 ; k25 = 206
.line	964	loadk        r15    k7 ; k7 = 0
.line	964	loadk        r16   k26 ; k26 = 89
.line	964	loadk        r17   k27 ; k27 = 15
.line	964	loadk        r18   k28 ; k28 = 112
.line	964	loadk        r19   k29 ; k29 = 201
.line	964	loadk        r20   k24 ; k24 = 196
.line	964	loadk        r21   k30 ; k30 = 167
.line	964	loadk        r22   k31 ; k31 = 97
.line	964	loadk        r23   k32 ; k32 = 240
.line	964	loadk        r24   k33 ; k33 = 46
.line	964	loadk        r25   k34 ; k34 = 26
.line	964	loadk        r26   k35 ; k35 = 197
.line	964	loadk        r27   k36 ; k36 = 49
.line	964	loadk        r28   k37 ; k37 = 200
.line	964	loadk        r29   k38 ; k38 = 244
.line	964	loadk        r30   k39 ; k39 = 222
.line	964	loadk        r31   k40 ; k40 = 16
.line	964	loadk        r32   k41 ; k41 = 73
.line	964	loadk        r33   k42 ; k42 = 31
.line	964	loadk        r34   k43 ; k43 = 96
.line	964	loadk        r35   k44 ; k44 = 217
.line	964	loadk        r36   k45 ; k45 = 160
.line	964	loadk        r37   k46 ; k46 = 229
.line	964	loadk        r38   k47 ; k47 = 5
.line	964	call          r3    36     2
.line	964	getupval      r4    u3
.line	964	move          r5    r0
.line	964	call          r4     2     2
.line	964	getupval      r5    u0
.line	964	loadk         r6   k48 ; k48 = 76
.line	964	loadk         r7   k49 ; k49 = 216
.line	964	loadk         r8   k50 ; k50 = 55
.line	964	loadk         r9   k51 ; k51 = 204
.line	964	loadk        r10   k52 ; k52 = 192
.line	964	loadk        r11   k53 ; k53 = 58
.line	964	loadk        r12   k54 ; k54 = 138
.line	964	loadk        r13   k26 ; k26 = 89
.line	964	loadk        r14   k49 ; k49 = 216
.line	964	loadk        r15   k55 ; k55 = 173
.line	964	loadk        r16   k56 ; k56 = 135
.line	964	call          r5    12     2
.line	964	getupval      r6    u3
.line	964	move          r7    r1
.line	964	call          r6     2     2
.line	964	concat        r3    r3    r6
.label	l103
.line	964	call          r2     2     1
.line	964	return        r1     2
.line	964	return        r0     1
.line	964	move          r0    r0
.line	964	return        r0     1

.function	main/f58

.source	null
.linedefined	977
.lastlinedefined	998
.numparams	0
.is_vararg	0
.maxstacksize	36

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"Client"
.constant	k1	"GetNetWorkType"
.constant	k2	"Wifi"
.constant	k3	1
.constant	k4	82
.constant	k5	191
.constant	k6	4
.constant	k7	83
.constant	k8	5
.constant	k9	84
.constant	k10	6
.constant	k11	85
.constant	k12	8
.constant	k13	"ETHERNET"
.constant	k14	9
.constant	k15	"VPN"
.constant	k16	17
.constant	k17	"BLUETOOTH"
.constant	k18	7
.constant	k19	"Other"
.constant	k20	0
.constant	k21	"error"
.constant	k22	-1
.constant	k23	"NULL"
.constant	k24	-2
.constant	k25	"log_warning"
.constant	k26	35
.constant	k27	153
.constant	k28	43
.constant	k29	142
.constant	k30	199
.constant	k31	111
.constant	k32	129
.constant	k33	72
.constant	k34	140
.constant	k35	176
.constant	k36	201
.constant	k37	54
.constant	k38	106
.constant	k39	214
.constant	k40	251
.constant	k41	232
.constant	k42	65
.constant	k43	224
.constant	k44	51
.constant	k45	26
.constant	k46	182
.constant	k47	123
.constant	k48	154
.constant	k49	239
.constant	k50	218
.constant	k51	93
.constant	k52	122
.constant	k53	62

.line	977	gettabup      r0    u0    k0 ; k0 = "Client"
.line	977	gettable      r0    r0    k1 ; k1 = "GetNetWorkType"
.line	977	call          r0     1     2
.line	977	newtable      r1     0    11
.line	977	settable      r1    k2    k3 ; k3 = 1
.line	977	getupval      r2    u1
.line	977	loadk         r3    k4 ; k4 = 82
.line	977	loadk         r4    k5 ; k5 = 191
.line	977	call          r2     3     2
.line	977	settable      r1    r2    k6 ; k6 = 4
.line	977	getupval      r2    u1
.line	977	loadk         r3    k7 ; k7 = 83
.line	977	loadk         r4    k5 ; k5 = 191
.line	977	call          r2     3     2
.line	977	settable      r1    r2    k8 ; k8 = 5
.line	977	getupval      r2    u1
.line	977	loadk         r3    k9 ; k9 = 84
.line	977	loadk         r4    k5 ; k5 = 191
.line	977	call          r2     3     2
.line	977	settable      r1    r2   k10 ; k10 = 6
.line	977	getupval      r2    u1
.line	977	loadk         r3   k11 ; k11 = 85
.line	977	loadk         r4    k5 ; k5 = 191
.line	977	call          r2     3     2
.line	977	settable      r1    r2   k12 ; k12 = 8
.line	977	settable      r1   k13   k14 ; k14 = 9
.line	977	settable      r1   k15   k16 ; k16 = 17
.line	977	settable      r1   k17   k18 ; k18 = 7
.line	977	settable      r1   k19   k20 ; k20 = 0
.line	977	settable      r1   k21   k22 ; k22 = -1
.line	977	settable      r1   k23   k24 ; k24 = -2
.line	977	gettable      r2    r1    r0
.line	977	test          r2     1
.line	977	jmp            0   l71
.line	977	gettabup      r3    u0   k25 ; k25 = "log_warning"
.line	977	getupval      r4    u1
.line	977	loadk         r5   k26 ; k26 = 35
.line	977	loadk         r6   k27 ; k27 = 153
.line	977	loadk         r7   k28 ; k28 = 43
.line	977	loadk         r8   k29 ; k29 = 142
.line	977	loadk         r9   k30 ; k30 = 199
.line	977	loadk        r10   k31 ; k31 = 111
.line	977	loadk        r11   k32 ; k32 = 129
.line	977	loadk        r12   k33 ; k33 = 72
.line	977	loadk        r13   k34 ; k34 = 140
.line	977	loadk        r14   k35 ; k35 = 176
.line	977	loadk        r15   k36 ; k36 = 201
.line	977	loadk        r16   k12 ; k12 = 8
.line	977	loadk        r17   k33 ; k33 = 72
.line	977	loadk        r18   k37 ; k37 = 54
.line	977	loadk        r19   k38 ; k38 = 106
.line	977	loadk        r20   k39 ; k39 = 214
.line	977	loadk        r21   k40 ; k40 = 251
.line	977	loadk        r22   k41 ; k41 = 232
.line	977	loadk        r23   k42 ; k42 = 65
.line	977	loadk        r24   k43 ; k43 = 224
.line	977	loadk        r25   k44 ; k44 = 51
.line	977	loadk        r26   k45 ; k45 = 26
.line	977	loadk        r27   k46 ; k46 = 182
.line	977	loadk        r28   k47 ; k47 = 123
.line	977	loadk        r29   k48 ; k48 = 154
.line	977	loadk        r30   k49 ; k49 = 239
.line	977	loadk        r31   k50 ; k50 = 218
.line	977	loadk        r32   k51 ; k51 = 93
.line	977	loadk        r33   k31 ; k31 = 111
.line	977	loadk        r34   k52 ; k52 = 122
.line	977	loadk        r35   k53 ; k53 = 62
.line	977	call          r4    32     2
.line	977	call          r3     2     1
.line	977	loadk         r2   k24 ; k24 = -2
.label	l71
.line	977	return        r2     2
.line	977	return        r0     1
.line	977	move          r0    r0
.line	977	move          r0    r0
.line	977	return        r0     1

.function	main/f59

.source	null
.linedefined	1000
.lastlinedefined	1004
.numparams	2
.is_vararg	0
.maxstacksize	5

.constant	k0	"Add"

.line	1000	test          r0     0
.line	1000	jmp            0   l12
.line	1000	gettable      r2    r0    k0 ; k0 = "Add"
.line	1000	test          r2     0
.line	1000	jmp            0   l12
.line	1000	test          r1     0
.line	1000	jmp            0   l12
.line	1000	self          r2    r0    k0 ; k0 = "Add"
.line	1000	move          r4    r1
.line	1000	tailcall      r2     3
.line	1000	return        r2     0
.label	l12
.line	1000	return        r0     1
.line	1000	move          r0    r0
.line	1000	move          r0    r0
.line	1000	move          r0    r0
.line	1000	move          r0    r0
.line	1000	return        r0     1

.function	main/f60

.source	null
.linedefined	1006
.lastlinedefined	1010
.numparams	2
.is_vararg	0
.maxstacksize	5

.constant	k0	"Remove"

.line	1006	test          r0     0
.line	1006	jmp            0   l12
.line	1006	gettable      r2    r0    k0 ; k0 = "Remove"
.line	1006	test          r2     0
.line	1006	jmp            0   l12
.line	1006	test          r1     0
.line	1006	jmp            0   l12
.line	1006	self          r2    r0    k0 ; k0 = "Remove"
.line	1006	move          r4    r1
.line	1006	tailcall      r2     3
.line	1006	return        r2     0
.label	l12
.line	1006	return        r0     1
.line	1006	move          r0    r0
.line	1006	move          r0    r0
.line	1006	move          r0    r0
.line	1006	return        r0     1

.function	main/f61

.source	null
.linedefined	1012
.lastlinedefined	1037
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	1	true
.upvalue	"U1"	0	false
.upvalue	"U2"	4	true
.upvalue	"U3"	21	true
.upvalue	"U4"	22	true

.constant	k0	"ShowDevNotice"
.constant	k1	67
.constant	k2	219
.constant	k3	102
.constant	k4	65
.constant	k5	28
.constant	k6	248
.constant	k7	14
.constant	k8	147
.constant	k9	107
.constant	k10	117
.constant	k11	34
.constant	k12	200
.constant	k13	218
.constant	k14	233
.constant	k15	164
.constant	k16	13
.constant	k17	95
.constant	k18	208
.constant	k19	9
.constant	k20	206
.constant	k21	83
.constant	k22	112
.constant	k23	137
.constant	k24	71
.constant	k25	59
.constant	k26	252
.constant	k27	202
.constant	k28	249
.constant	k29	180
.constant	k30	51
.constant	k31	82
.constant	k32	192
.constant	k33	5
.constant	k34	234
.constant	k35	134
.constant	k36	3
.constant	k37	128
.constant	k38	"lower"
.constant	k39	"package"
.constant	k40	"loaded"
.constant	k41	19
.constant	k42	140
.constant	k43	55
.constant	k44	221
.constant	k45	40
.constant	k46	"find"
.constant	k47	"table"
.constant	k48	"insert"
.constant	k49	10
.constant	k50	"concat"
.constant	k51	214
.constant	k52	35
.constant	k53	76
.constant	k54	156
.constant	k55	120
.constant	k56	17
.constant	k57	232
.constant	k58	212
.constant	k59	254
.constant	k60	130
.constant	k61	64
.constant	k62	42
.constant	k63	78
.constant	k64	4
.constant	k65	169
.constant	k66	167
.constant	k67	199
.constant	k68	60
.constant	k69	251
.constant	k70	126
.constant	k71	7
.constant	k72	198
.constant	k73	154
.constant	k74	181
.constant	k75	175
.constant	k76	50
.constant	k77	172
.constant	k78	48
.constant	k79	138
.constant	k80	62
.constant	k81	187
.constant	k82	209
.constant	k83	21
.constant	k84	229
.constant	k85	93
.constant	k86	163
.constant	k87	170
.constant	k88	66
.constant	k89	183
.constant	k90	31
.constant	k91	136
.constant	k92	176
.constant	k93	236
.constant	k94	33
.constant	k95	29
.constant	k96	32
.constant	k97	20
.constant	k98	"RequireBlackList"
.constant	k99	2
.constant	k100	148
.constant	k101	36
.constant	k102	216
.constant	k103	143
.constant	k104	94
.constant	k105	190
.constant	k106	213
.constant	k107	8
.constant	k108	80
.constant	k109	46
.constant	k110	100
.constant	k111	186
.constant	k112	245
.constant	k113	44
.constant	k114	30
.constant	k115	242
.constant	k116	"Reload"

.line	1012	getupval      r1    u0
.line	1012	call          r1     1     2
.line	1012	eq             0    r0    r1
.line	1012	jmp            0   l50
.line	1012	gettabup      r1    u1    k0 ; k0 = "ShowDevNotice"
.line	1012	getupval      r2    u0
.line	1012	loadk         r3    k1 ; k1 = 67
.line	1012	loadk         r4    k2 ; k2 = 219
.line	1012	loadk         r5    k3 ; k3 = 102
.line	1012	loadk         r6    k4 ; k4 = 65
.line	1012	loadk         r7    k5 ; k5 = 28
.line	1012	loadk         r8    k6 ; k6 = 248
.line	1012	loadk         r9    k7 ; k7 = 14
.line	1012	loadk        r10    k8 ; k8 = 147
.line	1012	loadk        r11    k9 ; k9 = 107
.line	1012	loadk        r12   k10 ; k10 = 117
.line	1012	loadk        r13   k11 ; k11 = 34
.line	1012	loadk        r14   k12 ; k12 = 200
.line	1012	loadk        r15   k13 ; k13 = 218
.line	1012	loadk        r16   k14 ; k14 = 233
.line	1012	loadk        r17   k15 ; k15 = 164
.line	1012	loadk        r18    k4 ; k4 = 65
.line	1012	loadk        r19   k16 ; k16 = 13
.line	1012	loadk        r20   k17 ; k17 = 95
.line	1012	loadk        r21   k18 ; k18 = 208
.line	1012	loadk        r22   k19 ; k19 = 9
.line	1012	loadk        r23   k20 ; k20 = 206
.line	1012	loadk        r24   k21 ; k21 = 83
.line	1012	loadk        r25   k22 ; k22 = 112
.line	1012	loadk        r26   k23 ; k23 = 137
.line	1012	loadk        r27   k24 ; k24 = 71
.line	1012	loadk        r28    k3 ; k3 = 102
.line	1012	loadk        r29   k25 ; k25 = 59
.line	1012	loadk        r30   k26 ; k26 = 252
.line	1012	loadk        r31   k27 ; k27 = 202
.line	1012	loadk        r32   k28 ; k28 = 249
.line	1012	loadk        r33   k29 ; k29 = 180
.line	1012	loadk        r34   k21 ; k21 = 83
.line	1012	loadk        r35   k30 ; k30 = 51
.line	1012	loadk        r36   k31 ; k31 = 82
.line	1012	loadk        r37   k32 ; k32 = 192
.line	1012	loadk        r38   k33 ; k33 = 5
.line	1012	loadk        r39   k34 ; k34 = 234
.line	1012	loadk        r40   k35 ; k35 = 134
.line	1012	loadk        r41   k36 ; k36 = 3
.line	1012	loadk        r42   k37 ; k37 = 128
.line	1012	call          r2    41     2
.line	1012	call          r1     2     1
.line	1012	return        r0     1
.label	l50
.line	1012	gettabup      r1    u2   k38 ; k38 = "lower"
.line	1012	move          r2    r0
.line	1012	call          r1     2     2
.line	1012	newtable      r2     0     0
.line	1012	gettabup      r3    u1   k39 ; k39 = "package"
.line	1012	test          r3     0
.line	1012	jmp            0   l95
.line	1012	gettabup      r3    u1   k39 ; k39 = "package"
.line	1012	gettable      r3    r3   k40 ; k40 = "loaded"
.line	1012	test          r3     0
.line	1012	jmp            0   l95
.line	1012	getupval      r3    u3
.line	1012	gettabup      r4    u1   k39 ; k39 = "package"
.line	1012	gettable      r4    r4   k40 ; k40 = "loaded"
.line	1012	call          r3     2     4
.line	1012	jmp            0   l93
.line	1012	getupval      r8    u4
.line	1012	move          r9    r6
.line	1012	call          r8     2     2
.line	1012	getupval      r9    u0
.line	1012	loadk        r10   k41 ; k41 = 19
.line	1012	loadk        r11   k42 ; k42 = 140
.line	1012	loadk        r12   k43 ; k43 = 55
.line	1012	loadk        r13   k32 ; k32 = 192
.line	1012	loadk        r14   k44 ; k44 = 221
.line	1012	loadk        r15   k45 ; k45 = 40
.line	1012	call          r9     7     2
.line	1012	eq             0    r8    r9
.line	1012	jmp            0   l93
.line	1012	gettabup      r8    u2   k38 ; k38 = "lower"
.line	1012	move          r9    r6
.line	1012	call          r8     2     2
.line	1012	gettable      r8    r8   k46 ; k46 = "find"
.line	1012	move          r9    r6
.line	1012	move         r10    r1
.line	1012	call          r8     3     2
.line	1012	test          r8     0
.line	1012	jmp            0   l93
.line	1012	gettabup      r8    u1   k47 ; k47 = "table"
.line	1012	gettable      r8    r8   k48 ; k48 = "insert"
.line	1012	move          r9    r2
.line	1012	move         r10    r6
.line	1012	call          r8     3     1
.label	l93
.line	1012	move          r0    r0
.line	1012	move          r0    r0
.label	l95
.line	1012	len           r3    r2
.line	1012	lt             0   k49    r3 ; k49 = 10
.line	1012	jmp            0  l170
.line	1012	gettabup      r3    u1    k0 ; k0 = "ShowDevNotice"
.line	1012	gettabup      r4    u1   k47 ; k47 = "table"
.line	1012	gettable      r4    r4   k50 ; k50 = "concat"
.line	1012	newtable      r5     1     0
.line	1012	getupval      r6    u0
.line	1012	loadk         r7    k1 ; k1 = 67
.line	1012	loadk         r8    k2 ; k2 = 219
.line	1012	loadk         r9    k3 ; k3 = 102
.line	1012	loadk        r10    k2 ; k2 = 219
.line	1012	loadk        r11   k51 ; k51 = 214
.line	1012	loadk        r12   k52 ; k52 = 35
.line	1012	loadk        r13   k23 ; k23 = 137
.line	1012	loadk        r14   k53 ; k53 = 76
.line	1012	loadk        r15   k54 ; k54 = 156
.line	1012	loadk        r16   k55 ; k55 = 120
.line	1012	loadk        r17   k56 ; k56 = 17
.line	1012	loadk        r18   k57 ; k57 = 232
.line	1012	loadk        r19   k58 ; k58 = 212
.line	1012	loadk        r20   k59 ; k59 = 254
.line	1012	loadk        r21   k60 ; k60 = 130
.line	1012	loadk        r22   k61 ; k61 = 64
.line	1012	loadk        r23   k62 ; k62 = 42
.line	1012	loadk        r24   k63 ; k63 = 78
.line	1012	loadk        r25   k64 ; k64 = 4
.line	1012	loadk        r26   k65 ; k65 = 169
.line	1012	loadk        r27   k66 ; k66 = 167
.line	1012	loadk        r28   k67 ; k67 = 199
.line	1012	loadk        r29   k68 ; k68 = 60
.line	1012	loadk        r30   k69 ; k69 = 251
.line	1012	loadk        r31   k70 ; k70 = 126
.line	1012	loadk        r32   k71 ; k71 = 7
.line	1012	loadk        r33   k21 ; k21 = 83
.line	1012	loadk        r34   k72 ; k72 = 198
.line	1012	loadk        r35   k73 ; k73 = 154
.line	1012	loadk        r36   k74 ; k74 = 181
.line	1012	loadk        r37   k75 ; k75 = 175
.line	1012	loadk        r38   k76 ; k76 = 50
.line	1012	loadk        r39   k77 ; k77 = 172
.line	1012	loadk        r40   k78 ; k78 = 48
.line	1012	loadk        r41   k79 ; k79 = 138
.line	1012	loadk        r42   k80 ; k80 = 62
.line	1012	loadk        r43   k81 ; k81 = 187
.line	1012	loadk        r44   k82 ; k82 = 209
.line	1012	loadk        r45   k83 ; k83 = 21
.line	1012	loadk        r46   k57 ; k57 = 232
.line	1012	call          r6    41     2
.line	1012	getupval      r7    u0
.line	1012	loadk         r8   k84 ; k84 = 229
.line	1012	loadk         r9   k85 ; k85 = 93
.line	1012	loadk        r10   k86 ; k86 = 163
.line	1012	loadk        r11   k76 ; k76 = 50
.line	1012	loadk        r12   k71 ; k71 = 7
.line	1012	loadk        r13   k87 ; k87 = 170
.line	1012	loadk        r14   k88 ; k88 = 66
.line	1012	loadk        r15   k89 ; k89 = 183
.line	1012	loadk        r16   k90 ; k90 = 31
.line	1012	loadk        r17   k49 ; k49 = 10
.line	1012	loadk        r18   k52 ; k52 = 35
.line	1012	loadk        r19   k91 ; k91 = 136
.line	1012	loadk        r20   k92 ; k92 = 176
.line	1012	loadk        r21    k6 ; k6 = 248
.line	1012	loadk        r22   k93 ; k93 = 236
.line	1012	loadk        r23   k94 ; k94 = 33
.line	1012	loadk        r24   k95 ; k95 = 29
.line	1012	loadk        r25   k96 ; k96 = 32
.line	1012	loadk        r26   k73 ; k73 = 154
.line	1012	loadk        r27   k97 ; k97 = 20
.line	1012	call          r7    21     0
.line	1012	setlist       r5     0     1
.line	1012	call          r4     2     2
.line	1012	call          r3     2     1
.line	1012	return        r0     1
.label	l170
.line	1012	closure       r3    f0
.line	1012	gettabup      r4    u1   k98 ; k98 = "RequireBlackList"
.line	1012	getupval      r5    u0
.line	1012	loadk         r6   k99 ; k99 = 2
.line	1012	loadk         r7  k100 ; k100 = 148
.line	1012	loadk         r8  k101 ; k101 = 36
.line	1012	loadk         r9   k27 ; k27 = 202
.line	1012	loadk        r10  k102 ; k102 = 216
.line	1012	loadk        r11   k52 ; k52 = 35
.line	1012	loadk        r12  k103 ; k103 = 143
.line	1012	loadk        r13  k104 ; k104 = 94
.line	1012	loadk        r14   k42 ; k42 = 140
.line	1012	loadk        r15  k105 ; k105 = 190
.line	1012	loadk        r16  k106 ; k106 = 213
.line	1012	loadk        r17  k107 ; k107 = 8
.line	1012	loadk        r18  k108 ; k108 = 80
.line	1012	loadk        r19  k109 ; k109 = 46
.line	1012	loadk        r20  k110 ; k110 = 100
.line	1012	loadk        r21   k32 ; k32 = 192
.line	1012	loadk        r22  k105 ; k105 = 190
.line	1012	loadk        r23  k111 ; k111 = 186
.line	1012	loadk        r24  k108 ; k108 = 80
.line	1012	loadk        r25  k112 ; k112 = 245
.line	1012	loadk        r26  k113 ; k113 = 44
.line	1012	loadk        r27  k114 ; k114 = 30
.line	1012	loadk        r28  k115 ; k115 = 242
.line	1012	call          r5    24     2
.line	1012	call          r4     2     2
.line	1012	test          r4     0
.line	1012	jmp            0  l205
.line	1012	gettable      r5    r4  k116 ; k116 = "Reload"
.line	1012	move          r6    r2
.line	1012	move          r7    r3
.line	1012	move          r8    r3
.line	1012	call          r5     4     1
.label	l205
.line	1012	return        r0     1
.line	1012	gettabup      r1    u1  k102 ; k102 = 216
.line	1012	return        r0     1

.function	main/f61/f0

.source	null
.linedefined	1030
.lastlinedefined	1032
.numparams	1
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	1	false

.constant	k0	"ShowNotice"

.line	1030	gettabup      r1    u0    k0 ; k0 = "ShowNotice"
.line	1030	move          r2    r0
.line	1030	call          r1     2     1
.line	1030	return        r0     1
.line	1030	move          r0    r0
.line	1030	move          r0    r0
.line	1030	return        r0     1

.function	main/f62

.source	null
.linedefined	1039
.lastlinedefined	1057
.numparams	1
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	1	true
.upvalue	"U1"	0	false
.upvalue	"U2"	27	true

.constant	k0	"StoreConst"
.constant	k1	"label_price_type_bp"
.constant	k2	"GetTableData"
.constant	k3	41
.constant	k4	140
.constant	k5	32
.constant	k6	196
.constant	k7	1000
.constant	k8	"ItemSmallIcon"
.constant	k9	"label_price_type_chip"
.constant	k10	1001
.constant	k11	"label_price_type_uc"
.constant	k12	1006
.constant	k13	"label_price_type_fp"
.constant	k14	1101
.constant	k15	"label_price_type_gold_chip"
.constant	k16	1104
.constant	k17	"label_price_type_battle"
.constant	k18	1103
.constant	k19	"label_price_type_iap"
.constant	k20	"SInAppPurchase"

.line	1039	getupval      r1    u0
.line	1039	call          r1     1     2
.line	1039	gettabup      r2    u1    k0 ; k0 = "StoreConst"
.line	1039	gettable      r2    r2    k1 ; k1 = "label_price_type_bp"
.line	1039	eq             0    r0    r2
.line	1039	jmp            0   l18
.line	1039	gettabup      r2    u2    k2 ; k2 = "GetTableData"
.line	1039	getupval      r3    u0
.line	1039	loadk         r4    k3 ; k3 = 41
.line	1039	loadk         r5    k4 ; k4 = 140
.line	1039	loadk         r6    k5 ; k5 = 32
.line	1039	loadk         r7    k6 ; k6 = 196
.line	1039	call          r3     5     2
.line	1039	loadk         r4    k7 ; k7 = 1000
.line	1039	call          r2     3     2
.line	1039	gettable      r1    r2    k8 ; k8 = "ItemSmallIcon"
.line	1039	jmp            0   l98
.label	l18
.line	1039	gettabup      r2    u1    k0 ; k0 = "StoreConst"
.line	1039	gettable      r2    r2    k9 ; k9 = "label_price_type_chi" (truncated)
.line	1039	eq             0    r0    r2
.line	1039	jmp            0   l33
.line	1039	gettabup      r2    u2    k2 ; k2 = "GetTableData"
.line	1039	getupval      r3    u0
.line	1039	loadk         r4    k3 ; k3 = 41
.line	1039	loadk         r5    k4 ; k4 = 140
.line	1039	loadk         r6    k5 ; k5 = 32
.line	1039	loadk         r7    k6 ; k6 = 196
.line	1039	call          r3     5     2
.line	1039	loadk         r4   k10 ; k10 = 1001
.line	1039	call          r2     3     2
.line	1039	gettable      r1    r2    k8 ; k8 = "ItemSmallIcon"
.line	1039	jmp            0   l98
.label	l33
.line	1039	gettabup      r2    u1    k0 ; k0 = "StoreConst"
.line	1039	gettable      r2    r2   k11 ; k11 = "label_price_type_uc"
.line	1039	eq             0    r0    r2
.line	1039	jmp            0   l48
.line	1039	gettabup      r2    u2    k2 ; k2 = "GetTableData"
.line	1039	getupval      r3    u0
.line	1039	loadk         r4    k3 ; k3 = 41
.line	1039	loadk         r5    k4 ; k4 = 140
.line	1039	loadk         r6    k5 ; k5 = 32
.line	1039	loadk         r7    k6 ; k6 = 196
.line	1039	call          r3     5     2
.line	1039	loadk         r4   k12 ; k12 = 1006
.line	1039	call          r2     3     2
.line	1039	gettable      r1    r2    k8 ; k8 = "ItemSmallIcon"
.line	1039	jmp            0   l98
.label	l48
.line	1039	gettabup      r2    u1    k0 ; k0 = "StoreConst"
.line	1039	gettable      r2    r2   k13 ; k13 = "label_price_type_fp"
.line	1039	eq             0    r0    r2
.line	1039	jmp            0   l63
.line	1039	gettabup      r2    u2    k2 ; k2 = "GetTableData"
.line	1039	getupval      r3    u0
.line	1039	loadk         r4    k3 ; k3 = 41
.line	1039	loadk         r5    k4 ; k4 = 140
.line	1039	loadk         r6    k5 ; k5 = 32
.line	1039	loadk         r7    k6 ; k6 = 196
.line	1039	call          r3     5     2
.line	1039	loadk         r4   k14 ; k14 = 1101
.line	1039	call          r2     3     2
.line	1039	gettable      r1    r2    k8 ; k8 = "ItemSmallIcon"
.line	1039	jmp            0   l98
.label	l63
.line	1039	gettabup      r2    u1    k0 ; k0 = "StoreConst"
.line	1039	gettable      r2    r2   k15 ; k15 = "label_price_type_gol" (truncated)
.line	1039	eq             0    r0    r2
.line	1039	jmp            0   l78
.line	1039	gettabup      r2    u2    k2 ; k2 = "GetTableData"
.line	1039	getupval      r3    u0
.line	1039	loadk         r4    k3 ; k3 = 41
.line	1039	loadk         r5    k4 ; k4 = 140
.line	1039	loadk         r6    k5 ; k5 = 32
.line	1039	loadk         r7    k6 ; k6 = 196
.line	1039	call          r3     5     2
.line	1039	loadk         r4   k16 ; k16 = 1104
.line	1039	call          r2     3     2
.line	1039	gettable      r1    r2    k8 ; k8 = "ItemSmallIcon"
.line	1039	jmp            0   l98
.label	l78
.line	1039	gettabup      r2    u1    k0 ; k0 = "StoreConst"
.line	1039	gettable      r2    r2   k17 ; k17 = "label_price_type_bat" (truncated)
.line	1039	eq             0    r0    r2
.line	1039	jmp            0   l93
.line	1039	gettabup      r2    u2    k2 ; k2 = "GetTableData"
.line	1039	getupval      r3    u0
.line	1039	loadk         r4    k3 ; k3 = 41
.line	1039	loadk         r5    k4 ; k4 = 140
.line	1039	loadk         r6    k5 ; k5 = 32
.line	1039	loadk         r7    k6 ; k6 = 196
.line	1039	call          r3     5     2
.line	1039	loadk         r4   k18 ; k18 = 1103
.line	1039	call          r2     3     2
.line	1039	gettable      r1    r2    k8 ; k8 = "ItemSmallIcon"
.line	1039	jmp            0   l98
.label	l93
.line	1039	gettabup      r2    u1    k0 ; k0 = "StoreConst"
.line	1039	gettable      r2    r2   k19 ; k19 = "label_price_type_iap"
.line	1039	eq             0    r0    r2
.line	1039	jmp            0   l98
.line	1039	gettabup      r1    u1   k20 ; k20 = "SInAppPurchase"
.label	l98
.line	1039	return        r1     2
.line	1039	return        r0     1
.line	1039	move          r0    r0
.line	1039	move          r0    r0
.line	1039	move          r0    r0
.line	1039	move          r0    r0
.line	1039	return        r0     1

.function	main/f63

.source	null
.linedefined	1059
.lastlinedefined	1061
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	703
.constant	k1	713
.constant	k2	723
.constant	k3	733
.constant	k4	13703
.constant	k5	1703
.constant	k6	1713
.constant	k7	2703
.constant	k8	2713

.line	1059	eq             1    r0    k0 ; k0 = 703
.line	1059	jmp            0   l20
.line	1059	eq             1    r0    k1 ; k1 = 713
.line	1059	jmp            0   l20
.line	1059	eq             1    r0    k2 ; k2 = 723
.line	1059	jmp            0   l20
.line	1059	eq             1    r0    k3 ; k3 = 733
.line	1059	jmp            0   l20
.line	1059	eq             1    r0    k4 ; k4 = 13703
.line	1059	jmp            0   l20
.line	1059	eq             1    r0    k5 ; k5 = 1703
.line	1059	jmp            0   l20
.line	1059	eq             1    r0    k6 ; k6 = 1713
.line	1059	jmp            0   l20
.line	1059	eq             1    r0    k7 ; k7 = 2703
.line	1059	jmp            0   l20
.line	1059	eq             1    r0    k8 ; k8 = 2713
.line	1059	jmp            0   l20
.line	1059	loadbool      r1     0     1
.label	l20
.line	1059	loadbool      r1     1     0
.line	1059	return        r1     2
.line	1059	return        r0     1
.line	1059	move          r0    r0
.line	1059	move          r0    r0
.line	1059	move          r0    r0
.line	1059	move          r0    r0
.line	1059	return        r0     1

.function	main/f64

.source	null
.linedefined	1063
.lastlinedefined	1065
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	23713

.line	1063	testset       r1    r0     0
.line	1063	jmp            0    l7
.line	1063	eq             1    r0    k0 ; k0 = 23713
.line	1063	jmp            0    l6
.line	1063	loadbool      r1     0     1
.label	l6
.line	1063	loadbool      r1     1     0
.label	l7
.line	1063	return        r1     2
.line	1063	return        r0     1
.line	1063	move          r0    r0
.line	1063	move          r0    r0
.line	1063	move          r0    r0
.line	1063	move          r0    r0
.line	1063	return        r0     1

.function	main/f65

.source	null
.linedefined	1067
.lastlinedefined	1069
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	64814

.line	1067	testset       r1    r0     0
.line	1067	jmp            0    l7
.line	1067	eq             1    r0    k0 ; k0 = 64814
.line	1067	jmp            0    l6
.line	1067	loadbool      r1     0     1
.label	l6
.line	1067	loadbool      r1     1     0
.label	l7
.line	1067	return        r1     2
.line	1067	return        r0     1
.line	1067	move          r0    r0
.line	1067	move          r0    r0
.line	1067	move          r0    r0
.line	1067	return        r0     1

.function	main/f66

.source	null
.linedefined	1071
.lastlinedefined	1073
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	723
.constant	k1	733

.line	1071	eq             1    r0    k0 ; k0 = 723
.line	1071	jmp            0    l6
.line	1071	eq             1    r0    k1 ; k1 = 733
.line	1071	jmp            0    l6
.line	1071	loadbool      r1     0     1
.label	l6
.line	1071	loadbool      r1     1     0
.line	1071	return        r1     2
.line	1071	return        r0     1
.line	1071	move          r0    r0
.line	1071	move          r0    r0
.line	1071	return        r0     1

.function	main/f67

.source	null
.linedefined	1075
.lastlinedefined	1077
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	1703
.constant	k1	1713

.line	1075	eq             1    r0    k0 ; k0 = 1703
.line	1075	jmp            0    l6
.line	1075	eq             1    r0    k1 ; k1 = 1713
.line	1075	jmp            0    l6
.line	1075	loadbool      r1     0     1
.label	l6
.line	1075	loadbool      r1     1     0
.line	1075	return        r1     2
.line	1075	return        r0     1
.line	1075	move          r0    r0
.line	1075	move          r0    r0
.line	1075	move          r0    r0
.line	1075	move          r0    r0
.line	1075	return        r0     1

.function	main/f68

.source	null
.linedefined	1079
.lastlinedefined	1092
.numparams	2
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	22	true
.upvalue	"U1"	1	true
.upvalue	"U2"	13	true

.constant	k0	14
.constant	k1	141
.constant	k2	40
.constant	k3	203
.constant	k4	214
.constant	k5	61
.constant	k6	0
.constant	k7	10

.line	1079	getupval      r2    u0
.line	1079	move          r3    r0
.line	1079	call          r2     2     2
.line	1079	getupval      r3    u1
.line	1079	loadk         r4    k0 ; k0 = 14
.line	1079	loadk         r5    k1 ; k1 = 141
.line	1079	loadk         r6    k2 ; k2 = 40
.line	1079	loadk         r7    k3 ; k3 = 203
.line	1079	loadk         r8    k4 ; k4 = 214
.line	1079	loadk         r9    k5 ; k5 = 61
.line	1079	call          r3     7     2
.line	1079	eq             1    r2    r3
.line	1079	jmp            0   l15
.line	1079	return        r0     2
.label	l15
.line	1079	test          r1     1
.line	1079	jmp            0   l18
.line	1079	loadk         r1    k6 ; k6 = 0
.label	l18
.line	1079	getupval      r2    u2
.line	1079	move          r3    r1
.line	1079	call          r2     2     2
.line	1079	move          r1    r2
.line	1079	lt             0    r1    k6 ; k6 = 0
.line	1079	jmp            0   l25
.line	1079	loadk         r1    k6 ; k6 = 0
.label	l25
.line	1079	pow           r2    k7    r1 ; k7 = 10
.line	1079	getupval      r3    u2
.line	1079	mul           r4    r0    r2
.line	1079	call          r3     2     2
.line	1079	div           r4    r3    r2
.line	1079	return        r4     2
.line	1079	return        r0     1
.line	1079	move          r0    r0
.line	1079	move          r0    r0
.line	1079	return        r0     1

.function	main/f69

.source	null
.linedefined	1094
.lastlinedefined	1098
.numparams	0
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	0	false

.constant	k0	"UIManager"
.constant	k1	"GetUI"
.constant	k2	"UI_Config"
.constant	k3	"lua_global_ui"
.constant	k4	"ShowUI"
.constant	k5	"UIRoot"

.line	1094	gettabup      r0    u0    k0 ; k0 = "UIManager"
.line	1094	gettable      r0    r0    k1 ; k1 = "GetUI"
.line	1094	gettabup      r1    u0    k0 ; k0 = "UIManager"
.line	1094	gettable      r1    r1    k2 ; k2 = "UI_Config"
.line	1094	gettable      r1    r1    k3 ; k3 = "lua_global_ui"
.line	1094	call          r0     2     2
.line	1094	test          r0     1
.line	1094	jmp            0   l16
.line	1094	gettabup      r1    u0    k0 ; k0 = "UIManager"
.line	1094	gettable      r1    r1    k4 ; k4 = "ShowUI"
.line	1094	gettabup      r2    u0    k0 ; k0 = "UIManager"
.line	1094	gettable      r2    r2    k2 ; k2 = "UI_Config"
.line	1094	gettable      r2    r2    k3 ; k3 = "lua_global_ui"
.line	1094	call          r1     2     2
.line	1094	move          r0    r1
.label	l16
.line	1094	gettable      r1    r0    k5 ; k5 = "UIRoot"
.line	1094	return        r1     2
.line	1094	return        r0     1
.line	1094	move          r0    r0
.line	1094	move          r0    r0
.line	1094	return        r0     1

.function	main/f70

.source	null
.linedefined	1100
.lastlinedefined	1140
.numparams	1
.is_vararg	0
.maxstacksize	43

.upvalue	"_ENV"	22	true
.upvalue	"U1"	1	true
.upvalue	"U2"	0	false
.upvalue	"U3"	24	true
.upvalue	"U4"	13	true
.upvalue	"U5"	5	true
.upvalue	"U6"	9	true
.upvalue	"U7"	8	true

.constant	k0	14
.constant	k1	141
.constant	k2	40
.constant	k3	203
.constant	k4	214
.constant	k5	61
.constant	k6	"log_error"
.constant	k7	52
.constant	k8	138
.constant	k9	36
.constant	k10	199
.constant	k11	192
.constant	k12	41
.constant	k13	137
.constant	k14	95
.constant	k15	149
.constant	k16	222
.constant	k17	210
.constant	k18	0
.constant	k19	104
.constant	k20	46
.constant	k21	67
.constant	k22	226
.constant	k23	165
.constant	k24	84
.constant	k25	237
.constant	k26	16
.constant	k27	11
.constant	k28	228
.constant	k29	129
.constant	k30	238
.constant	k31	193
.constant	k32	28
.constant	k33	64
.constant	k34	56
.constant	k35	113
.constant	k36	148
.constant	k37	233
.constant	k38	182
.constant	k39	85
.constant	k40	252
.constant	k41	39
.constant	k42	78
.constant	k43	167
.constant	k44	44
.constant	k45	77
.constant	k46	"FuncUtil"
.constant	k47	"TransformNumToFormatStr"
.constant	k48	1000
.constant	k49	1000000
.constant	k50	80
.constant	k51	200
.constant	k52	117
.constant	k53	100
.constant	k54	10
.constant	k55	221
.constant	k56	33
.constant	k57	96
.constant	k58	205
.constant	k59	69
.constant	k60	156
.constant	k61	105
.constant	k62	140
.constant	k63	-1
.constant	k64	1
.constant	k65	3
.constant	k66	76
.constant	k67	139
.constant	k68	218
.constant	k69	43
.constant	k70	107
.constant	k71	215
.constant	k72	106

.line	1100	test          r0     0
.line	1100	jmp            0   l16
.line	1100	getupval      r1    u0
.line	1100	move          r2    r0
.line	1100	call          r1     2     2
.line	1100	getupval      r2    u1
.line	1100	loadk         r3    k0 ; k0 = 14
.line	1100	loadk         r4    k1 ; k1 = 141
.line	1100	loadk         r5    k2 ; k2 = 40
.line	1100	loadk         r6    k3 ; k3 = 203
.line	1100	loadk         r7    k4 ; k4 = 214
.line	1100	loadk         r8    k5 ; k5 = 61
.line	1100	call          r2     7     2
.line	1100	eq             1    r1    r2
.line	1100	jmp            0   l63
.label	l16
.line	1100	gettabup      r1    u2    k6 ; k6 = "log_error"
.line	1100	getupval      r2    u1
.line	1100	loadk         r3    k7 ; k7 = 52
.line	1100	loadk         r4    k8 ; k8 = 138
.line	1100	loadk         r5    k9 ; k9 = 36
.line	1100	loadk         r6   k10 ; k10 = 199
.line	1100	loadk         r7   k11 ; k11 = 192
.line	1100	loadk         r8   k12 ; k12 = 41
.line	1100	loadk         r9   k13 ; k13 = 137
.line	1100	loadk        r10   k14 ; k14 = 95
.line	1100	loadk        r11   k15 ; k15 = 149
.line	1100	loadk        r12   k16 ; k16 = 222
.line	1100	loadk        r13   k17 ; k17 = 210
.line	1100	loadk        r14   k18 ; k18 = 0
.line	1100	loadk        r15   k19 ; k19 = 104
.line	1100	loadk        r16   k20 ; k20 = 46
.line	1100	loadk        r17   k21 ; k21 = 67
.line	1100	loadk        r18    k3 ; k3 = 203
.line	1100	loadk        r19   k22 ; k22 = 226
.line	1100	loadk        r20   k23 ; k23 = 165
.line	1100	loadk        r21   k24 ; k24 = 84
.line	1100	loadk        r22   k25 ; k25 = 237
.line	1100	loadk        r23   k26 ; k26 = 16
.line	1100	loadk        r24   k27 ; k27 = 11
.line	1100	loadk        r25   k28 ; k28 = 228
.line	1100	loadk        r26    k5 ; k5 = 61
.line	1100	loadk        r27   k29 ; k29 = 129
.line	1100	loadk        r28   k30 ; k30 = 238
.line	1100	loadk        r29   k31 ; k31 = 193
.line	1100	loadk        r30   k32 ; k32 = 28
.line	1100	loadk        r31   k33 ; k33 = 64
.line	1100	loadk        r32   k34 ; k34 = 56
.line	1100	loadk        r33   k35 ; k35 = 113
.line	1100	loadk        r34   k36 ; k36 = 148
.line	1100	loadk        r35   k37 ; k37 = 233
.line	1100	loadk        r36   k38 ; k38 = 182
.line	1100	loadk        r37   k39 ; k39 = 85
.line	1100	loadk        r38   k40 ; k40 = 252
.line	1100	loadk        r39   k41 ; k41 = 39
.line	1100	loadk        r40   k42 ; k42 = 78
.line	1100	loadk        r41   k43 ; k43 = 167
.line	1100	loadk        r42   k44 ; k44 = 44
.line	1100	call          r2    41     2
.line	1100	call          r1     2     1
.line	1100	getupval      r1    u1
.line	1100	call          r1     1     2
.line	1100	return        r1     2
.label	l63
.line	1100	lt             0    r0   k18 ; k18 = 0
.line	1100	jmp            0   l75
.line	1100	getupval      r1    u1
.line	1100	loadk         r2   k45 ; k45 = 77
.line	1100	call          r1     2     2
.line	1100	gettabup      r2    u2   k46 ; k46 = "FuncUtil"
.line	1100	gettable      r2    r2   k47 ; k47 = "TransformNumToFormat" (truncated)
.line	1100	unm           r3    r0
.line	1100	call          r2     2     2
.line	1100	concat        r1    r1    r2
.line	1100	return        r1     2
.line	1100	jmp            0  l205
.label	l75
.line	1100	lt             0    r0   k48 ; k48 = 1000
.line	1100	jmp            0   l82
.line	1100	getupval      r1    u3
.line	1100	move          r2    r0
.line	1100	tailcall      r1     2
.line	1100	return        r1     0
.line	1100	jmp            0  l205
.label	l82
.line	1100	lt             0    r0   k49 ; k49 = 1000000
.line	1100	jmp            0  l136
.line	1100	getupval      r1    u4
.line	1100	mod           r2    r0   k48 ; k48 = 1000
.line	1100	call          r1     2     2
.line	1100	getupval      r2    u1
.line	1100	loadk         r3   k50 ; k50 = 80
.line	1100	loadk         r4   k51 ; k51 = 200
.line	1100	loadk         r5   k52 ; k52 = 117
.line	1100	call          r2     4     2
.line	1100	le             0   k53    r1 ; k53 = 100
.line	1100	jmp            0   l99
.line	1100	getupval      r3    u3
.line	1100	move          r4    r1
.line	1100	call          r3     2     2
.line	1100	move          r2    r3
.line	1100	jmp            0  l121
.label	l99
.line	1100	le             0   k54    r1 ; k54 = 10
.line	1100	jmp            0  l111
.line	1100	getupval      r3    u5
.line	1100	getupval      r4    u1
.line	1100	loadk         r5   k50 ; k50 = 80
.line	1100	loadk         r6   k55 ; k55 = 221
.line	1100	loadk         r7   k56 ; k56 = 33
.line	1100	call          r4     4     2
.line	1100	move          r5    r1
.line	1100	call          r3     3     2
.line	1100	move          r2    r3
.line	1100	jmp            0  l121
.label	l111
.line	1100	getupval      r3    u5
.line	1100	getupval      r4    u1
.line	1100	loadk         r5   k50 ; k50 = 80
.line	1100	loadk         r6   k51 ; k51 = 200
.line	1100	loadk         r7   k57 ; k57 = 96
.line	1100	loadk         r8   k58 ; k58 = 205
.line	1100	call          r4     5     2
.line	1100	move          r5    r1
.line	1100	call          r3     3     2
.line	1100	move          r2    r3
.label	l121
.line	1100	getupval      r3    u5
.line	1100	getupval      r4    u1
.line	1100	loadk         r5   k59 ; k59 = 69
.line	1100	loadk         r6   k60 ; k60 = 156
.line	1100	loadk         r7   k61 ; k61 = 105
.line	1100	loadk         r8   k62 ; k62 = 140
.line	1100	loadk         r9   k11 ; k11 = 192
.line	1100	call          r4     6     2
.line	1100	getupval      r5    u4
.line	1100	div           r6    r0   k48 ; k48 = 1000
.line	1100	call          r5     2     2
.line	1100	move          r6    r2
.line	1100	tailcall      r3     4
.line	1100	return        r3     0
.line	1100	jmp            0  l205
.label	l136
.line	1100	getupval      r1    u4
.line	1100	div           r2    r0   k53 ; k53 = 100
.line	1100	call          r1     2     2
.line	1100	getupval      r2    u4
.line	1100	div           r3    r0   k48 ; k48 = 1000
.line	1100	call          r2     2     2
.line	1100	mod           r3    r1    r2
.line	1100	getupval      r4    u6
.line	1100	move          r5    r2
.line	1100	call          r4     2     2
.line	1100	getupval      r5    u1
.line	1100	call          r5     1     2
.line	1100	loadk         r6   k18 ; k18 = 0
.line	1100	move          r7    r4
.line	1100	loadk         r8   k18 ; k18 = 0
.line	1100	loadk         r9   k63 ; k63 = -1
.line	1100	move          r0    r0
.line	1100	add           r6    r6   k64 ; k64 = 1
.line	1100	getupval     r11    u7
.line	1100	move         r12    r2
.line	1100	move         r13   r10
.line	1100	move         r14   r10
.line	1100	call         r11     4     2
.line	1100	move         r12    r5
.line	1100	concat        r5   r11   r12
.line	1100	mod          r11    r6   k65 ; k65 = 3
.line	1100	eq             0   r11   k18 ; k18 = 0
.line	1100	jmp            0  l171
.line	1100	lt             0   k64   r10 ; k64 = 1
.line	1100	jmp            0  l171
.line	1100	getupval     r11    u1
.line	1100	loadk        r12   k66 ; k66 = 76
.line	1100	call         r11     2     2
.line	1100	move         r12    r5
.line	1100	concat        r5   r11   r12
.label	l171
.line	1100	move          r0    r0
.line	1100	eq             0    r3   k18 ; k18 = 0
.line	1100	jmp            0  l188
.line	1100	getupval      r7    u5
.line	1100	getupval      r8    u1
.line	1100	loadk         r9   k59 ; k59 = 69
.line	1100	loadk        r10   k67 ; k67 = 139
.line	1100	loadk        r11   k57 ; k57 = 96
.line	1100	loadk        r12   k68 ; k68 = 218
.line	1100	call          r8     5     2
.line	1100	move          r9    r5
.line	1100	getupval     r10    u1
.line	1100	loadk        r11   k69 ; k69 = 43
.line	1100	call         r10     2     2
.line	1100	tailcall      r7     4
.line	1100	return        r7     0
.line	1100	jmp            0  l205
.label	l188
.line	1100	getupval      r7    u5
.line	1100	getupval      r8    u1
.line	1100	loadk         r9   k59 ; k59 = 69
.line	1100	loadk        r10   k67 ; k67 = 139
.line	1100	loadk        r11   k70 ; k70 = 107
.line	1100	loadk        r12   k62 ; k62 = 140
.line	1100	loadk        r13   k71 ; k71 = 215
.line	1100	loadk        r14   k72 ; k72 = 106
.line	1100	loadk        r15   k15 ; k15 = 149
.line	1100	call          r8     8     2
.line	1100	move          r9    r5
.line	1100	move         r10    r3
.line	1100	getupval     r11    u1
.line	1100	loadk        r12   k69 ; k69 = 43
.line	1100	call         r11     2     2
.line	1100	tailcall      r7     5
.line	1100	return        r7     0
.label	l205
.line	1100	return        r0     1
.line	1100	move          r0    r0
.line	1100	move          r0    r0
.line	1100	move          r0    r0
.line	1100	return        r0     1

.function	main/f71

.source	null
.linedefined	1142
.lastlinedefined	1153
.numparams	1
.is_vararg	0
.maxstacksize	14

.upvalue	"_ENV"	1	true
.upvalue	"U1"	21	true
.upvalue	"U2"	24	true
.upvalue	"U3"	22	true
.upvalue	"U4"	45	true

.constant	k0	20
.constant	k1	153
.constant	k2	39
.constant	k3	197
.constant	k4	214

.line	1142	getupval      r1    u0
.line	1142	call          r1     1     2
.line	1142	getupval      r2    u1
.line	1142	move          r3    r0
.line	1142	call          r2     2     4
.line	1142	jmp            0   l35
.line	1142	move          r7    r1
.line	1142	getupval      r8    u2
.line	1142	move          r9    r5
.line	1142	call          r8     2     2
.line	1142	concat        r1    r7    r8
.line	1142	getupval      r7    u3
.line	1142	move          r8    r6
.line	1142	call          r7     2     2
.line	1142	getupval      r8    u0
.line	1142	loadk         r9    k0 ; k0 = 20
.line	1142	loadk        r10    k1 ; k1 = 153
.line	1142	loadk        r11    k2 ; k2 = 39
.line	1142	loadk        r12    k3 ; k3 = 197
.line	1142	loadk        r13    k4 ; k4 = 214
.line	1142	call          r8     6     2
.line	1142	eq             0    r7    r8
.line	1142	jmp            0   l30
.line	1142	move          r7    r1
.line	1142	getupval      r8    u4
.line	1142	move          r9    r6
.line	1142	call          r8     2     2
.line	1142	concat        r1    r7    r8
.line	1142	jmp            0   l35
.label	l30
.line	1142	move          r7    r1
.line	1142	getupval      r8    u2
.line	1142	move          r9    r6
.line	1142	call          r8     2     2
.line	1142	concat        r1    r7    r8
.label	l35
.line	1142	move          r0    r0
.line	1142	move          r0    r0
.line	1142	return        r1     2
.line	1142	return        r0     1
.line	1142	move          r0    r0
.line	1142	move          r0    r0
.line	1142	return        r0     1

.function	main/f72

.source	null
.linedefined	1155
.lastlinedefined	1157
.numparams	1
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	45	true

.line	1155	getupval      r1    u0
.line	1155	move          r2    r0
.line	1155	tailcall      r1     2
.line	1155	return        r1     0
.line	1155	return        r0     1
.line	1155	move          r0    r0
.line	1155	return        r0     1

.function	main/f73

.source	null
.linedefined	1159
.lastlinedefined	1167
.numparams	1
.is_vararg	0
.maxstacksize	20

.upvalue	"_ENV"	27	true
.upvalue	"U1"	1	true
.upvalue	"U2"	21	true

.constant	k0	"GetTable"
.constant	k1	37
.constant	k2	141
.constant	k3	55
.constant	k4	198
.constant	k5	195
.constant	k6	42
.constant	k7	135
.constant	k8	67
.constant	k9	187
.constant	k10	255
.constant	k11	210
.constant	k12	3
.constant	k13	72
.constant	k14	51
.constant	k15	108
.constant	k16	193
.constant	k17	227
.constant	k18	"AreaCode"
.constant	k19	"IsEEU"
.constant	k20	true

.line	1159	gettabup      r1    u0    k0 ; k0 = "GetTable"
.line	1159	getupval      r2    u1
.line	1159	loadk         r3    k1 ; k1 = 37
.line	1159	loadk         r4    k2 ; k2 = 141
.line	1159	loadk         r5    k3 ; k3 = 55
.line	1159	loadk         r6    k4 ; k4 = 198
.line	1159	loadk         r7    k5 ; k5 = 195
.line	1159	loadk         r8    k6 ; k6 = 42
.line	1159	loadk         r9    k7 ; k7 = 135
.line	1159	loadk        r10    k8 ; k8 = 67
.line	1159	loadk        r11    k9 ; k9 = 187
.line	1159	loadk        r12   k10 ; k10 = 255
.line	1159	loadk        r13   k11 ; k11 = 210
.line	1159	loadk        r14   k12 ; k12 = 3
.line	1159	loadk        r15   k13 ; k13 = 72
.line	1159	loadk        r16   k14 ; k14 = 51
.line	1159	loadk        r17   k15 ; k15 = 108
.line	1159	loadk        r18   k16 ; k16 = 193
.line	1159	loadk        r19   k17 ; k17 = 227
.line	1159	call          r2    18     2
.line	1159	call          r1     2     2
.line	1159	getupval      r2    u2
.line	1159	move          r3    r1
.line	1159	call          r2     2     4
.line	1159	jmp            0   l34
.line	1159	gettable      r7    r6   k18 ; k18 = "AreaCode"
.line	1159	eq             0    r7    r0
.line	1159	jmp            0   l34
.line	1159	gettable      r7    r6   k19 ; k19 = "IsEEU"
.line	1159	eq             0    r7   k20 ; k20 = true
.line	1159	jmp            0   l34
.line	1159	loadbool      r7     0     0
.line	1159	return        r7     2
.label	l34
.line	1159	move          r0    r0
.line	1159	move          r0    r0
.line	1159	loadbool      r2     1     0
.line	1159	return        r2     2
.line	1159	return        r0     1
.line	1159	move          r0    r0
.line	1159	move          r0    r0
.line	1159	move          r0    r0
.line	1159	return        r0     1

.function	main/f74

.source	null
.linedefined	1169
.lastlinedefined	1213
.numparams	0
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	25	true
.upvalue	"U2"	1	true
.upvalue	"U3"	24	true

.constant	k0	"Client"
.constant	k1	"GetCurrentLanguage"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	3
.constant	k5	148
.constant	k6	44
.constant	k7	204
.constant	k8	221
.constant	k9	59
.constant	k10	200
.constant	k11	94
.constant	k12	229
.constant	k13	198
.constant	k14	67
.constant	k15	95
.constant	k16	46
.constant	k17	107
.constant	k18	194
.constant	k19	249
.constant	k20	175
.constant	k21	27
.constant	k22	218
.constant	k23	47
.constant	k24	22
.constant	k25	243
.constant	k26	115
.constant	k27	156
.constant	k28	205
.constant	k29	214
.constant	k30	30
.constant	k31	62
.constant	k32	102
.constant	k33	154
.constant	k34	185
.constant	k35	75
.constant	k36	238
.constant	k37	38
.constant	k38	14
.constant	k39	225
.constant	k40	104
.constant	k41	45
.constant	k42	153
.constant	k43	219
.constant	k44	220
.constant	k45	60
.constant	k46	"log"
.constant	k47	"bWriteLog"
.constant	k48	52
.constant	k49	138
.constant	k50	36
.constant	k51	199
.constant	k52	192
.constant	k53	135
.constant	k54	159
.constant	k55	10
.constant	k56	89
.constant	k57	21
.constant	k58	106
.constant	k59	237
.constant	k60	253
.constant	k61	187
.constant	k62	81
.constant	k63	242
.constant	k64	15
.constant	k65	248
.constant	k66	122
.constant	k67	157
.constant	k68	208
.constant	k69	24
.constant	k70	12
.constant	k71	61
.constant	k72	116
.constant	k73	231
.constant	k74	169
.constant	k75	"AR"
.constant	k76	1
.constant	k77	26
.constant	k78	232
.constant	k79	246
.constant	k80	"JA"
.constant	k81	227
.constant	k82	"KO"
.constant	k83	11
.constant	k84	151
.constant	k85	226
.constant	k86	"RU"
.constant	k87	18
.constant	k88	141
.constant	k89	251
.constant	k90	230
.constant	k91	"PT"
.constant	k92	16
.constant	k93	140
.constant	k94	"TH"
.constant	k95	5
.constant	k96	150
.constant	k97	"ZH"
.constant	k98	144
.constant	k99	234
.constant	k100	"HK"
.constant	k101	"TW"
.constant	k102	228
.constant	k103	"DE"
.constant	k104	4
.constant	k105	"ID"
.constant	k106	224
.constant	k107	247
.constant	k108	"FR"
.constant	k109	6
.constant	k110	239
.constant	k111	"ES"
.constant	k112	139
.constant	k113	"TR"
.constant	k114	20
.constant	k115	"HI"
.constant	k116	8
.constant	k117	145
.constant	k118	"MS"
.constant	k119	13
.constant	k120	"UZ"
.constant	k121	130
.constant	k122	252
.constant	k123	233
.constant	k124	"UR"
.constant	k125	"MY"
.constant	k126	129
.constant	k127	254

.line	1169	gettabup      r0    u0    k0 ; k0 = "Client"
.line	1169	gettable      r0    r0    k1 ; k1 = "GetCurrentLanguage"
.line	1169	call          r0     1     2
.line	1169	getupval      r1    u1
.line	1169	gettabup      r2    u0    k2 ; k2 = "table"
.line	1169	gettable      r2    r2    k3 ; k3 = "concat"
.line	1169	newtable      r3     1     0
.line	1169	getupval      r4    u2
.line	1169	loadk         r5    k4 ; k4 = 3
.line	1169	loadk         r6    k5 ; k5 = 148
.line	1169	loadk         r7    k6 ; k6 = 44
.line	1169	loadk         r8    k7 ; k7 = 204
.line	1169	loadk         r9    k8 ; k8 = 221
.line	1169	loadk        r10    k9 ; k9 = 59
.line	1169	loadk        r11   k10 ; k10 = 200
.line	1169	loadk        r12   k11 ; k11 = 94
.line	1169	loadk        r13    k5 ; k5 = 148
.line	1169	loadk        r14   k12 ; k12 = 229
.line	1169	loadk        r15   k13 ; k13 = 198
.line	1169	loadk        r16   k14 ; k14 = 67
.line	1169	loadk        r17   k15 ; k15 = 95
.line	1169	loadk        r18   k16 ; k16 = 46
.line	1169	loadk        r19   k17 ; k17 = 107
.line	1169	loadk        r20   k18 ; k18 = 194
.line	1169	loadk        r21   k19 ; k19 = 249
.line	1169	loadk        r22   k20 ; k20 = 175
.line	1169	loadk        r23   k21 ; k21 = 27
.line	1169	loadk        r24   k22 ; k22 = 218
.line	1169	loadk        r25   k23 ; k23 = 47
.line	1169	loadk        r26   k24 ; k24 = 22
.line	1169	loadk        r27   k25 ; k25 = 243
.line	1169	loadk        r28   k26 ; k26 = 115
.line	1169	loadk        r29   k27 ; k27 = 156
.line	1169	loadk        r30   k28 ; k28 = 205
.line	1169	loadk        r31   k29 ; k29 = 214
.line	1169	loadk        r32   k30 ; k30 = 30
.line	1169	loadk        r33   k11 ; k11 = 94
.line	1169	loadk        r34   k31 ; k31 = 62
.line	1169	loadk        r35   k32 ; k32 = 102
.line	1169	loadk        r36   k33 ; k33 = 154
.line	1169	loadk        r37    k7 ; k7 = 204
.line	1169	loadk        r38   k34 ; k34 = 185
.line	1169	loadk        r39   k35 ; k35 = 75
.line	1169	loadk        r40   k36 ; k36 = 238
.line	1169	loadk        r41   k37 ; k37 = 38
.line	1169	loadk        r42   k38 ; k38 = 14
.line	1169	loadk        r43   k39 ; k39 = 225
.line	1169	loadk        r44   k40 ; k40 = 104
.line	1169	call          r4    41     2
.line	1169	getupval      r5    u2
.line	1169	loadk         r6   k41 ; k41 = 45
.line	1169	loadk         r7   k42 ; k42 = 153
.line	1169	loadk         r8   k37 ; k37 = 38
.line	1169	loadk         r9   k43 ; k43 = 219
.line	1169	loadk        r10   k44 ; k44 = 220
.line	1169	loadk        r11   k45 ; k45 = 60
.line	1169	call          r5     7     0
.line	1169	setlist       r3     0     1
.line	1169	call          r2     2     2
.line	1169	call          r1     2     2
.line	1169	gettabup      r2    u0   k46 ; k46 = "log"
.line	1169	gettabup      r3    u0   k47 ; k47 = "bWriteLog"
.line	1169	test          r3     0
.line	1169	jmp            0  l107
.line	1169	getupval      r3    u2
.line	1169	loadk         r4   k48 ; k48 = 52
.line	1169	loadk         r5   k49 ; k49 = 138
.line	1169	loadk         r6   k50 ; k50 = 36
.line	1169	loadk         r7   k51 ; k51 = 199
.line	1169	loadk         r8   k52 ; k52 = 192
.line	1169	loadk         r9    k4 ; k4 = 3
.line	1169	loadk        r10   k53 ; k53 = 135
.line	1169	loadk        r11   k14 ; k14 = 67
.line	1169	loadk        r12   k54 ; k54 = 159
.line	1169	loadk        r13   k12 ; k12 = 229
.line	1169	loadk        r14   k13 ; k13 = 198
.line	1169	loadk        r15   k55 ; k55 = 10
.line	1169	loadk        r16   k56 ; k56 = 89
.line	1169	loadk        r17   k57 ; k57 = 21
.line	1169	loadk        r18   k58 ; k58 = 106
.line	1169	loadk        r19   k59 ; k59 = 237
.line	1169	loadk        r20   k60 ; k60 = 253
.line	1169	loadk        r21   k61 ; k61 = 187
.line	1169	loadk        r22   k62 ; k62 = 81
.line	1169	loadk        r23   k63 ; k63 = 242
.line	1169	loadk        r24   k64 ; k64 = 15
.line	1169	loadk        r25   k30 ; k30 = 30
.line	1169	loadk        r26   k65 ; k65 = 248
.line	1169	loadk        r27   k66 ; k66 = 122
.line	1169	loadk        r28   k67 ; k67 = 157
.line	1169	loadk        r29   k39 ; k39 = 225
.line	1169	loadk        r30   k68 ; k68 = 208
.line	1169	loadk        r31   k69 ; k69 = 24
.line	1169	loadk        r32   k70 ; k70 = 12
.line	1169	loadk        r33   k71 ; k71 = 61
.line	1169	loadk        r34   k72 ; k72 = 116
.line	1169	loadk        r35   k22 ; k22 = 218
.line	1169	loadk        r36   k73 ; k73 = 231
.line	1169	loadk        r37   k65 ; k65 = 248
.line	1169	loadk        r38   k69 ; k69 = 24
.line	1169	loadk        r39   k74 ; k74 = 169
.line	1169	call          r3    37     2
.line	1169	getupval      r4    u3
.line	1169	move          r5    r0
.line	1169	call          r4     2     2
.line	1169	concat        r3    r3    r4
.label	l107
.line	1169	call          r2     2     1
.line	1169	gettable      r2    r1   k75 ; k75 = "AR"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l120
.line	1169	getupval      r2    u2
.line	1169	loadk         r3   k76 ; k76 = 1
.line	1169	loadk         r4   k49 ; k49 = 138
.line	1169	loadk         r5   k77 ; k77 = 26
.line	1169	loadk         r6   k78 ; k78 = 232
.line	1169	loadk         r7   k79 ; k79 = 246
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	jmp            0  l335
.label	l120
.line	1169	gettable      r2    r1   k80 ; k80 = "JA"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l132
.line	1169	getupval      r2    u2
.line	1169	loadk         r3   k55 ; k55 = 10
.line	1169	loadk         r4   k42 ; k42 = 153
.line	1169	loadk         r5   k77 ; k77 = 26
.line	1169	loadk         r6   k81 ; k81 = 227
.line	1169	loadk         r7   k81 ; k81 = 227
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	jmp            0  l335
.label	l132
.line	1169	gettable      r2    r1   k82 ; k82 = "KO"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l144
.line	1169	getupval      r2    u2
.line	1169	loadk         r3   k83 ; k83 = 11
.line	1169	loadk         r4   k84 ; k84 = 151
.line	1169	loadk         r5   k77 ; k77 = 26
.line	1169	loadk         r6   k85 ; k85 = 226
.line	1169	loadk         r7   k39 ; k39 = 225
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	jmp            0  l335
.label	l144
.line	1169	gettable      r2    r1   k86 ; k86 = "RU"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l156
.line	1169	getupval      r2    u2
.line	1169	loadk         r3   k87 ; k87 = 18
.line	1169	loadk         r4   k88 ; k88 = 141
.line	1169	loadk         r5   k77 ; k77 = 26
.line	1169	loadk         r6   k89 ; k89 = 251
.line	1169	loadk         r7   k90 ; k90 = 230
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	jmp            0  l335
.label	l156
.line	1169	gettable      r2    r1   k91 ; k91 = "PT"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l168
.line	1169	getupval      r2    u2
.line	1169	loadk         r3   k92 ; k92 = 16
.line	1169	loadk         r4   k93 ; k93 = 140
.line	1169	loadk         r5   k77 ; k77 = 26
.line	1169	loadk         r6   k19 ; k19 = 249
.line	1169	loadk         r7   k73 ; k73 = 231
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	jmp            0  l335
.label	l168
.line	1169	gettable      r2    r1   k94 ; k94 = "TH"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l180
.line	1169	getupval      r2    u2
.line	1169	loadk         r3   k95 ; k95 = 5
.line	1169	loadk         r4   k96 ; k96 = 150
.line	1169	loadk         r5   k77 ; k77 = 26
.line	1169	loadk         r6   k60 ; k60 = 253
.line	1169	loadk         r7   k89 ; k89 = 251
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	jmp            0  l335
.label	l180
.line	1169	gettable      r2    r1   k97 ; k97 = "ZH"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l192
.line	1169	getupval      r2    u2
.line	1169	loadk         r3   k77 ; k77 = 26
.line	1169	loadk         r4   k98 ; k98 = 144
.line	1169	loadk         r5   k77 ; k77 = 26
.line	1169	loadk         r6   k99 ; k99 = 234
.line	1169	loadk         r7   k60 ; k60 = 253
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	jmp            0  l335
.label	l192
.line	1169	gettable      r2    r1  k100 ; k100 = "HK"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l204
.line	1169	getupval      r2    u2
.line	1169	loadk         r3   k77 ; k77 = 26
.line	1169	loadk         r4   k98 ; k98 = 144
.line	1169	loadk         r5   k40 ; k40 = 104
.line	1169	loadk         r6   k39 ; k39 = 225
.line	1169	loadk         r7   k65 ; k65 = 248
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	jmp            0  l335
.label	l204
.line	1169	gettable      r2    r1  k101 ; k101 = "TW"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l216
.line	1169	getupval      r2    u2
.line	1169	loadk         r3   k77 ; k77 = 26
.line	1169	loadk         r4   k98 ; k98 = 144
.line	1169	loadk         r5   k77 ; k77 = 26
.line	1169	loadk         r6   k60 ; k60 = 253
.line	1169	loadk         r7  k102 ; k102 = 228
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	jmp            0  l335
.label	l216
.line	1169	gettable      r2    r1  k103 ; k103 = "DE"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l228
.line	1169	getupval      r2    u2
.line	1169	loadk         r3  k104 ; k104 = 4
.line	1169	loadk         r4   k67 ; k67 = 157
.line	1169	loadk         r5   k77 ; k77 = 26
.line	1169	loadk         r6   k59 ; k59 = 237
.line	1169	loadk         r7   k79 ; k79 = 246
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	jmp            0  l335
.label	l228
.line	1169	gettable      r2    r1  k105 ; k105 = "ID"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l240
.line	1169	getupval      r2    u2
.line	1169	loadk         r3   k95 ; k95 = 5
.line	1169	loadk         r4   k96 ; k96 = 150
.line	1169	loadk         r5   k77 ; k77 = 26
.line	1169	loadk         r6  k106 ; k106 = 224
.line	1169	loadk         r7  k107 ; k107 = 247
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	jmp            0  l335
.label	l240
.line	1169	gettable      r2    r1  k108 ; k108 = "FR"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l252
.line	1169	getupval      r2    u2
.line	1169	loadk         r3  k109 ; k109 = 6
.line	1169	loadk         r4   k49 ; k49 = 138
.line	1169	loadk         r5   k77 ; k77 = 26
.line	1169	loadk         r6  k110 ; k110 = 239
.line	1169	loadk         r7   k39 ; k39 = 225
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	jmp            0  l335
.label	l252
.line	1169	gettable      r2    r1  k111 ; k111 = "ES"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l264
.line	1169	getupval      r2    u2
.line	1169	loadk         r3   k95 ; k95 = 5
.line	1169	loadk         r4  k112 ; k112 = 139
.line	1169	loadk         r5   k77 ; k77 = 26
.line	1169	loadk         r6   k12 ; k12 = 229
.line	1169	loadk         r7   k63 ; k63 = 242
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	jmp            0  l335
.label	l264
.line	1169	gettable      r2    r1  k113 ; k113 = "TR"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l276
.line	1169	getupval      r2    u2
.line	1169	loadk         r3  k114 ; k114 = 20
.line	1169	loadk         r4   k49 ; k49 = 138
.line	1169	loadk         r5   k77 ; k77 = 26
.line	1169	loadk         r6   k60 ; k60 = 253
.line	1169	loadk         r7   k39 ; k39 = 225
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	jmp            0  l335
.label	l276
.line	1169	gettable      r2    r1  k115 ; k115 = "HI"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l288
.line	1169	getupval      r2    u2
.line	1169	loadk         r3  k116 ; k116 = 8
.line	1169	loadk         r4  k117 ; k117 = 145
.line	1169	loadk         r5   k40 ; k40 = 104
.line	1169	loadk         r6  k106 ; k106 = 224
.line	1169	loadk         r7   k60 ; k60 = 253
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	jmp            0  l335
.label	l288
.line	1169	gettable      r2    r1  k118 ; k118 = "MS"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l300
.line	1169	getupval      r2    u2
.line	1169	loadk         r3  k119 ; k119 = 13
.line	1169	loadk         r4  k112 ; k112 = 139
.line	1169	loadk         r5   k77 ; k77 = 26
.line	1169	loadk         r6  k102 ; k102 = 228
.line	1169	loadk         r7   k99 ; k99 = 234
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	jmp            0  l335
.label	l300
.line	1169	gettable      r2    r1  k120 ; k120 = "UZ"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l312
.line	1169	getupval      r2    u2
.line	1169	loadk         r3   k57 ; k57 = 21
.line	1169	loadk         r4  k121 ; k121 = 130
.line	1169	loadk         r5   k40 ; k40 = 104
.line	1169	loadk         r6  k122 ; k122 = 252
.line	1169	loadk         r7  k123 ; k123 = 233
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	jmp            0  l335
.label	l312
.line	1169	gettable      r2    r1  k124 ; k124 = "UR"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l324
.line	1169	getupval      r2    u2
.line	1169	loadk         r3   k57 ; k57 = 21
.line	1169	loadk         r4   k49 ; k49 = 138
.line	1169	loadk         r5   k40 ; k40 = 104
.line	1169	loadk         r6   k19 ; k19 = 249
.line	1169	loadk         r7   k65 ; k65 = 248
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	jmp            0  l335
.label	l324
.line	1169	gettable      r2    r1  k125 ; k125 = "MY"
.line	1169	eq             0    r0    r2
.line	1169	jmp            0  l335
.line	1169	getupval      r2    u2
.line	1169	loadk         r3  k119 ; k119 = 13
.line	1169	loadk         r4  k126 ; k126 = 129
.line	1169	loadk         r5   k40 ; k40 = 104
.line	1169	loadk         r6  k102 ; k102 = 228
.line	1169	loadk         r7  k127 ; k127 = 254
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.label	l335
.line	1169	getupval      r2    u2
.line	1169	loadk         r3   k95 ; k95 = 5
.line	1169	loadk         r4   k96 ; k96 = 150
.line	1169	loadk         r5   k77 ; k77 = 26
.line	1169	loadk         r6  k122 ; k122 = 252
.line	1169	loadk         r7  k106 ; k106 = 224
.line	1169	call          r2     6     2
.line	1169	return        r2     2
.line	1169	return        r0     1
.line	1169	move          r0    r0
.line	1169	move          r0    r0
.line	1169	move          r0    r0
.line	1169	gettabup      r3    u0  k108 ; k108 = "FR"
.line	1169	return        r0     1

.function	main/f75

.source	null
.linedefined	1215
.lastlinedefined	1219
.numparams	1
.is_vararg	0
.maxstacksize	25

.upvalue	"_ENV"	28	true
.upvalue	"U1"	1	true
.upvalue	"U2"	25	true

.constant	k0	43
.constant	k1	145
.constant	k2	54
.constant	k3	196
.constant	k4	214
.constant	k5	59
.constant	k6	181
.constant	k7	84
.constant	k8	139
.constant	k9	228
.constant	k10	194
.constant	k11	0
.constant	k12	112
.constant	k13	40
.constant	k14	103
.constant	k15	241
.constant	k16	186
.constant	k17	76
.constant	k18	3
.constant	k19	148
.constant	k20	44
.constant	k21	204
.constant	k22	221
.constant	k23	200
.constant	k24	78
.constant	k25	151
.constant	k26	253
.constant	k27	202
.constant	k28	2
.constant	k29	82
.constant	k30	111
.constant	k31	205
.constant	k32	207
.constant	k33	189
.constant	k34	65
.constant	k35	240
.constant	k36	47
.constant	k37	"ExecuteConsoleCommand"
.constant	k38	"GetGameInstance"

.line	1215	getupval      r1    u0
.line	1215	getupval      r2    u1
.line	1215	loadk         r3    k0 ; k0 = 43
.line	1215	loadk         r4    k1 ; k1 = 145
.line	1215	loadk         r5    k2 ; k2 = 54
.line	1215	loadk         r6    k3 ; k3 = 196
.line	1215	loadk         r7    k4 ; k4 = 214
.line	1215	loadk         r8    k5 ; k5 = 59
.line	1215	loadk         r9    k6 ; k6 = 181
.line	1215	loadk        r10    k7 ; k7 = 84
.line	1215	loadk        r11    k8 ; k8 = 139
.line	1215	loadk        r12    k9 ; k9 = 228
.line	1215	loadk        r13   k10 ; k10 = 194
.line	1215	loadk        r14   k11 ; k11 = 0
.line	1215	loadk        r15   k12 ; k12 = 112
.line	1215	loadk        r16   k13 ; k13 = 40
.line	1215	loadk        r17   k14 ; k14 = 103
.line	1215	loadk        r18    k4 ; k4 = 214
.line	1215	loadk        r19   k15 ; k15 = 241
.line	1215	loadk        r20   k16 ; k16 = 186
.line	1215	loadk        r21   k17 ; k17 = 76
.line	1215	call          r2    20     2
.line	1215	call          r1     2     2
.line	1215	getupval      r2    u2
.line	1215	getupval      r3    u1
.line	1215	loadk         r4   k18 ; k18 = 3
.line	1215	loadk         r5   k19 ; k19 = 148
.line	1215	loadk         r6   k20 ; k20 = 44
.line	1215	loadk         r7   k21 ; k21 = 204
.line	1215	loadk         r8   k22 ; k22 = 221
.line	1215	loadk         r9    k5 ; k5 = 59
.line	1215	loadk        r10   k23 ; k23 = 200
.line	1215	loadk        r11   k24 ; k24 = 78
.line	1215	loadk        r12   k25 ; k25 = 151
.line	1215	loadk        r13   k26 ; k26 = 253
.line	1215	loadk        r14   k27 ; k27 = 202
.line	1215	loadk        r15   k28 ; k28 = 2
.line	1215	loadk        r16   k29 ; k29 = 82
.line	1215	loadk        r17   k30 ; k30 = 111
.line	1215	loadk        r18   k12 ; k12 = 112
.line	1215	loadk        r19   k31 ; k31 = 205
.line	1215	loadk        r20   k32 ; k32 = 207
.line	1215	loadk        r21   k33 ; k33 = 189
.line	1215	loadk        r22   k34 ; k34 = 65
.line	1215	loadk        r23   k35 ; k35 = 240
.line	1215	loadk        r24   k36 ; k36 = 47
.line	1215	call          r3    22     2
.line	1215	call          r2     2     2
.line	1215	gettable      r3    r1   k37 ; k37 = "ExecuteConsoleComman" (truncated)
.line	1215	gettable      r4    r2   k38 ; k38 = "GetGameInstance"
.line	1215	call          r4     1     2
.line	1215	move          r5    r0
.line	1215	loadnil       r6     0
.line	1215	call          r3     4     1
.line	1215	return        r0     1
.line	1215	move          r0    r0
.line	1215	move          r0    r0
.line	1215	return        r0     1

.function	main/f76

.source	null
.linedefined	1221
.lastlinedefined	1224
.numparams	1
.is_vararg	0
.maxstacksize	22

.upvalue	"_ENV"	28	true
.upvalue	"U1"	1	true

.constant	k0	43
.constant	k1	145
.constant	k2	54
.constant	k3	196
.constant	k4	214
.constant	k5	59
.constant	k6	181
.constant	k7	84
.constant	k8	139
.constant	k9	228
.constant	k10	194
.constant	k11	0
.constant	k12	112
.constant	k13	40
.constant	k14	103
.constant	k15	241
.constant	k16	186
.constant	k17	76
.constant	k18	"GetConsoleVariableIntValue"

.line	1221	getupval      r1    u0
.line	1221	getupval      r2    u1
.line	1221	loadk         r3    k0 ; k0 = 43
.line	1221	loadk         r4    k1 ; k1 = 145
.line	1221	loadk         r5    k2 ; k2 = 54
.line	1221	loadk         r6    k3 ; k3 = 196
.line	1221	loadk         r7    k4 ; k4 = 214
.line	1221	loadk         r8    k5 ; k5 = 59
.line	1221	loadk         r9    k6 ; k6 = 181
.line	1221	loadk        r10    k7 ; k7 = 84
.line	1221	loadk        r11    k8 ; k8 = 139
.line	1221	loadk        r12    k9 ; k9 = 228
.line	1221	loadk        r13   k10 ; k10 = 194
.line	1221	loadk        r14   k11 ; k11 = 0
.line	1221	loadk        r15   k12 ; k12 = 112
.line	1221	loadk        r16   k13 ; k13 = 40
.line	1221	loadk        r17   k14 ; k14 = 103
.line	1221	loadk        r18    k4 ; k4 = 214
.line	1221	loadk        r19   k15 ; k15 = 241
.line	1221	loadk        r20   k16 ; k16 = 186
.line	1221	loadk        r21   k17 ; k17 = 76
.line	1221	call          r2    20     2
.line	1221	call          r1     2     2
.line	1221	gettable      r2    r1   k18 ; k18 = "GetConsoleVariableIn" (truncated)
.line	1221	move          r3    r0
.line	1221	tailcall      r2     2
.line	1221	return        r2     0
.line	1221	return        r0     1
.line	1221	move          r0    r0
.line	1221	return        r0     1

.function	main/f77

.source	null
.linedefined	1226
.lastlinedefined	1238
.numparams	1
.is_vararg	0
.maxstacksize	14

.upvalue	"_ENV"	21	true
.upvalue	"U1"	0	false

.constant	k0	0
.constant	k1	"struct_SegmentType"
.constant	k2	"kd_v2"
.constant	k3	"kd"

.line	1226	loadk         r1    k0 ; k0 = 0
.line	1226	getupval      r2    u0
.line	1226	move          r3    r0
.line	1226	call          r2     2     4
.line	1226	jmp            0   l20
.line	1226	getupval      r7    u0
.line	1226	gettabup      r8    u1    k1 ; k1 = "struct_SegmentType"
.line	1226	call          r7     2     4
.line	1226	jmp            0   l18
.line	1226	gettable     r12    r6   r11
.line	1226	gettable     r13   r12    k2 ; k2 = "kd_v2"
.line	1226	test         r13     1
.line	1226	jmp            0   l15
.line	1226	gettable     r13   r12    k3 ; k3 = "kd"
.label	l15
.line	1226	lt             0    r1   r13
.line	1226	jmp            0   l18
.line	1226	move          r1   r13
.label	l18
.line	1226	move          r0    r0
.line	1226	move          r0    r0
.label	l20
.line	1226	move          r0    r0
.line	1226	move          r0    r0
.line	1226	return        r1     2
.line	1226	return        r0     1
.line	1226	move          r0    r0
.line	1226	return        r0     1

.function	main/f78

.source	null
.linedefined	1240
.lastlinedefined	1258
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	1	true
.upvalue	"U1"	25	true
.upvalue	"U2"	0	false
.upvalue	"U3"	21	true

.constant	k0	"table"
.constant	k1	"concat"
.constant	k2	3
.constant	k3	148
.constant	k4	44
.constant	k5	204
.constant	k6	221
.constant	k7	59
.constant	k8	200
.constant	k9	94
.constant	k10	229
.constant	k11	198
.constant	k12	67
.constant	k13	95
.constant	k14	46
.constant	k15	107
.constant	k16	194
.constant	k17	249
.constant	k18	175
.constant	k19	27
.constant	k20	218
.constant	k21	47
.constant	k22	22
.constant	k23	243
.constant	k24	115
.constant	k25	156
.constant	k26	205
.constant	k27	214
.constant	k28	30
.constant	k29	62
.constant	k30	102
.constant	k31	154
.constant	k32	185
.constant	k33	75
.constant	k34	238
.constant	k35	38
.constant	k36	14
.constant	k37	225
.constant	k38	104
.constant	k39	45
.constant	k40	153
.constant	k41	219
.constant	k42	220
.constant	k43	60
.constant	k44	"HK"
.constant	k45	26
.constant	k46	144
.constant	k47	248
.constant	k48	"TW"
.constant	k49	253
.constant	k50	228
.constant	k51	"FuncUtil"
.constant	k52	"GetLanguageTable"
.constant	k53	"languageCode"
.constant	k54	"displayName"

.line	1240	getupval      r1    u0
.line	1240	call          r1     1     2
.line	1240	getupval      r2    u0
.line	1240	call          r2     1     2
.line	1240	getupval      r3    u1
.line	1240	gettabup      r4    u2    k0 ; k0 = "table"
.line	1240	gettable      r4    r4    k1 ; k1 = "concat"
.line	1240	newtable      r5     1     0
.line	1240	getupval      r6    u0
.line	1240	loadk         r7    k2 ; k2 = 3
.line	1240	loadk         r8    k3 ; k3 = 148
.line	1240	loadk         r9    k4 ; k4 = 44
.line	1240	loadk        r10    k5 ; k5 = 204
.line	1240	loadk        r11    k6 ; k6 = 221
.line	1240	loadk        r12    k7 ; k7 = 59
.line	1240	loadk        r13    k8 ; k8 = 200
.line	1240	loadk        r14    k9 ; k9 = 94
.line	1240	loadk        r15    k3 ; k3 = 148
.line	1240	loadk        r16   k10 ; k10 = 229
.line	1240	loadk        r17   k11 ; k11 = 198
.line	1240	loadk        r18   k12 ; k12 = 67
.line	1240	loadk        r19   k13 ; k13 = 95
.line	1240	loadk        r20   k14 ; k14 = 46
.line	1240	loadk        r21   k15 ; k15 = 107
.line	1240	loadk        r22   k16 ; k16 = 194
.line	1240	loadk        r23   k17 ; k17 = 249
.line	1240	loadk        r24   k18 ; k18 = 175
.line	1240	loadk        r25   k19 ; k19 = 27
.line	1240	loadk        r26   k20 ; k20 = 218
.line	1240	loadk        r27   k21 ; k21 = 47
.line	1240	loadk        r28   k22 ; k22 = 22
.line	1240	loadk        r29   k23 ; k23 = 243
.line	1240	loadk        r30   k24 ; k24 = 115
.line	1240	loadk        r31   k25 ; k25 = 156
.line	1240	loadk        r32   k26 ; k26 = 205
.line	1240	loadk        r33   k27 ; k27 = 214
.line	1240	loadk        r34   k28 ; k28 = 30
.line	1240	loadk        r35    k9 ; k9 = 94
.line	1240	loadk        r36   k29 ; k29 = 62
.line	1240	loadk        r37   k30 ; k30 = 102
.line	1240	loadk        r38   k31 ; k31 = 154
.line	1240	loadk        r39    k5 ; k5 = 204
.line	1240	loadk        r40   k32 ; k32 = 185
.line	1240	loadk        r41   k33 ; k33 = 75
.line	1240	loadk        r42   k34 ; k34 = 238
.line	1240	loadk        r43   k35 ; k35 = 38
.line	1240	loadk        r44   k36 ; k36 = 14
.line	1240	loadk        r45   k37 ; k37 = 225
.line	1240	loadk        r46   k38 ; k38 = 104
.line	1240	call          r6    41     2
.line	1240	getupval      r7    u0
.line	1240	loadk         r8   k39 ; k39 = 45
.line	1240	loadk         r9   k40 ; k40 = 153
.line	1240	loadk        r10   k35 ; k35 = 38
.line	1240	loadk        r11   k41 ; k41 = 219
.line	1240	loadk        r12   k42 ; k42 = 220
.line	1240	loadk        r13   k43 ; k43 = 60
.line	1240	call          r7     7     0
.line	1240	setlist       r5     0     1
.line	1240	call          r4     2     2
.line	1240	call          r3     2     2
.line	1240	gettable      r4    r3   k44 ; k44 = "HK"
.line	1240	eq             0    r0    r4
.line	1240	jmp            0   l74
.line	1240	getupval      r4    u0
.line	1240	loadk         r5   k45 ; k45 = 26
.line	1240	loadk         r6   k46 ; k46 = 144
.line	1240	loadk         r7   k38 ; k38 = 104
.line	1240	loadk         r8   k37 ; k37 = 225
.line	1240	loadk         r9   k47 ; k47 = 248
.line	1240	call          r4     6     2
.line	1240	move          r1    r4
.line	1240	jmp            0   l87
.label	l74
.line	1240	gettable      r4    r3   k48 ; k48 = "TW"
.line	1240	eq             0    r0    r4
.line	1240	jmp            0   l86
.line	1240	getupval      r4    u0
.line	1240	loadk         r5   k45 ; k45 = 26
.line	1240	loadk         r6   k46 ; k46 = 144
.line	1240	loadk         r7   k38 ; k38 = 104
.line	1240	loadk         r8   k49 ; k49 = 253
.line	1240	loadk         r9   k50 ; k50 = 228
.line	1240	call          r4     6     2
.line	1240	move          r1    r4
.line	1240	jmp            0   l87
.label	l86
.line	1240	move          r1    r0
.label	l87
.line	1240	getupval      r4    u3
.line	1240	gettabup      r5    u2   k51 ; k51 = "FuncUtil"
.line	1240	gettable      r5    r5   k52 ; k52 = "GetLanguageTable"
.line	1240	call          r5     1     0
.line	1240	call          r4     0     4
.line	1240	jmp            0   l98
.line	1240	gettable      r9    r8   k53 ; k53 = "languageCode"
.line	1240	eq             0    r9    r1
.line	1240	jmp            0   l98
.line	1240	gettable      r2    r8   k54 ; k54 = "displayName"
.line	1240	jmp            0  l100
.label	l98
.line	1240	move          r0    r0
.line	1240	move          r0    r0
.label	l100
.line	1240	return        r2     2
.line	1240	return        r0     1
.line	1240	move          r0    r0
.line	1240	move          r0    r0
.line	1240	move          r0    r0
.line	1240	return        r0     1

.function	main/f79

.source	null
.linedefined	1260
.lastlinedefined	1269
.numparams	2
.is_vararg	0
.maxstacksize	32

.upvalue	"_ENV"	1	true
.upvalue	"U1"	24	true
.upvalue	"U2"	5	true
.upvalue	"U3"	0	false

.constant	k0	nil
.constant	k1	69
.constant	k2	139
.constant	k3	30
.constant	k4	140
.constant	k5	192
.constant	k6	18
.constant	k7	"log"
.constant	k8	"bWriteLog"
.constant	k9	35
.constant	k10	138
.constant	k11	36
.constant	k12	218
.constant	k13	219
.constant	k14	12
.constant	k15	136
.constant	k16	89
.constant	k17	128
.constant	k18	228
.constant	k19	245
.constant	k20	8
.constant	k21	76
.constant	k22	46
.constant	k23	119
.constant	k24	208
.constant	k25	176
.constant	k26	133
.constant	k27	84
.constant	k28	240
.constant	k29	45
.constant	k30	57
.constant	k31	250
.constant	k32	114
.constant	k33	159
.constant	k34	186
.constant	k35	151
.constant	k36	"Client"
.constant	k37	"AddCrashContextData"
.constant	k38	2003
.constant	k39	100

.line	1260	getupval      r2    u0
.line	1260	call          r2     1     2
.line	1260	eq             0    r1    k0 ; k0 = nil
.line	1260	jmp            0   l10
.line	1260	getupval      r3    u1
.line	1260	move          r4    r0
.line	1260	call          r3     2     2
.line	1260	move          r2    r3
.line	1260	jmp            0   l23
.label	l10
.line	1260	getupval      r3    u2
.line	1260	getupval      r4    u0
.line	1260	loadk         r5    k1 ; k1 = 69
.line	1260	loadk         r6    k2 ; k2 = 139
.line	1260	loadk         r7    k3 ; k3 = 30
.line	1260	loadk         r8    k4 ; k4 = 140
.line	1260	loadk         r9    k5 ; k5 = 192
.line	1260	loadk        r10    k6 ; k6 = 18
.line	1260	call          r4     7     2
.line	1260	move          r5    r0
.line	1260	move          r6    r1
.line	1260	call          r3     4     2
.line	1260	move          r2    r3
.label	l23
.line	1260	gettabup      r3    u3    k7 ; k7 = "log"
.line	1260	gettabup      r4    u3    k8 ; k8 = "bWriteLog"
.line	1260	test          r4     0
.line	1260	jmp            0   l58
.line	1260	getupval      r4    u0
.line	1260	loadk         r5    k9 ; k9 = 35
.line	1260	loadk         r6   k10 ; k10 = 138
.line	1260	loadk         r7   k11 ; k11 = 36
.line	1260	loadk         r8   k12 ; k12 = 218
.line	1260	loadk         r9   k13 ; k13 = 219
.line	1260	loadk        r10   k14 ; k14 = 12
.line	1260	loadk        r11   k15 ; k15 = 136
.line	1260	loadk        r12   k16 ; k16 = 89
.line	1260	loadk        r13   k17 ; k17 = 128
.line	1260	loadk        r14   k18 ; k18 = 228
.line	1260	loadk        r15   k19 ; k19 = 245
.line	1260	loadk        r16   k20 ; k20 = 8
.line	1260	loadk        r17   k21 ; k21 = 76
.line	1260	loadk        r18   k22 ; k22 = 46
.line	1260	loadk        r19   k23 ; k23 = 119
.line	1260	loadk        r20   k24 ; k24 = 208
.line	1260	loadk        r21   k25 ; k25 = 176
.line	1260	loadk        r22   k26 ; k26 = 133
.line	1260	loadk        r23   k27 ; k27 = 84
.line	1260	loadk        r24   k28 ; k28 = 240
.line	1260	loadk        r25   k29 ; k29 = 45
.line	1260	loadk        r26   k30 ; k30 = 57
.line	1260	loadk        r27   k31 ; k31 = 250
.line	1260	loadk        r28   k32 ; k32 = 114
.line	1260	loadk        r29   k33 ; k33 = 159
.line	1260	loadk        r30   k34 ; k34 = 186
.line	1260	loadk        r31   k35 ; k35 = 151
.line	1260	call          r4    28     2
.line	1260	move          r5    r2
.line	1260	concat        r4    r4    r5
.label	l58
.line	1260	call          r3     2     1
.line	1260	gettabup      r3    u3   k36 ; k36 = "Client"
.line	1260	gettable      r3    r3   k37 ; k37 = "AddCrashContextData"
.line	1260	loadk         r4   k38 ; k38 = 2003
.line	1260	move          r5    r2
.line	1260	loadbool      r6     0     0
.line	1260	loadk         r7   k39 ; k39 = 100
.line	1260	call          r3     5     1
.line	1260	return        r0     1
.line	1260	move          r0    r0
.line	1260	return        r0     1

.function	main/f80

.source	null
.linedefined	1271
.lastlinedefined	1290
.numparams	0
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	1	true
.upvalue	"U1"	25	true
.upvalue	"U2"	0	false
.upvalue	"U3"	18	true
.upvalue	"U4"	14	true
.upvalue	"U5"	15	true
.upvalue	"U6"	24	true

.constant	k0	"table"
.constant	k1	"concat"
.constant	k2	3
.constant	k3	148
.constant	k4	44
.constant	k5	204
.constant	k6	221
.constant	k7	59
.constant	k8	200
.constant	k9	65
.constant	k10	151
.constant	k11	247
.constant	k12	206
.constant	k13	14
.constant	k14	18
.constant	k15	13
.constant	k16	106
.constant	k17	195
.constant	k18	249
.constant	k19	171
.constant	k20	101
.constant	k21	245
.constant	k22	34
.constant	k23	6
.constant	k24	243
.constant	k25	111
.constant	k26	184
.constant	k27	242
.constant	k28	210
.constant	k29	27
.constant	k30	95
.constant	k31	127
.constant	k32	216
.constant	k33	225
.constant	k34	161
.constant	k35	64
.constant	k36	251
.constant	k37	35
.constant	k38	29
.constant	k39	227
.constant	k40	107
.constant	k41	19
.constant	k42	"LoadFileToTable_N"
.constant	k43	"ePlayerPrefsType"
.constant	k44	"eDefault"
.constant	k45	nil
.constant	k46	"dvid"
.constant	k47	10000
.constant	k48	99999
.constant	k49	"SaveTableToFile_N"
.constant	k50	"log"
.constant	k51	"bWriteLog"
.constant	k52	138
.constant	k53	32
.constant	k54	199
.constant	k55	42
.constant	k56	198
.constant	k57	73
.constant	k58	142
.constant	k59	87
.constant	k60	28
.constant	k61	38
.constant	k62	141
.constant	k63	43
.constant	k64	202
.constant	k65	230
.constant	k66	143
.constant	k67	214
.constant	k68	215
.constant	k69	194
.constant	k70	25
.constant	k71	120
.constant	k72	23
.constant	k73	76
.constant	k74	224
.constant	k75	21
.constant	k76	235
.constant	k77	11
.constant	k78	134
.constant	k79	186

.line	1271	getupval      r0    u0
.line	1271	call          r0     1     2
.line	1271	getupval      r1    u1
.line	1271	gettabup      r2    u2    k0 ; k0 = "table"
.line	1271	gettable      r2    r2    k1 ; k1 = "concat"
.line	1271	newtable      r3     1     0
.line	1271	getupval      r4    u0
.line	1271	loadk         r5    k2 ; k2 = 3
.line	1271	loadk         r6    k3 ; k3 = 148
.line	1271	loadk         r7    k4 ; k4 = 44
.line	1271	loadk         r8    k5 ; k5 = 204
.line	1271	loadk         r9    k6 ; k6 = 221
.line	1271	loadk        r10    k7 ; k7 = 59
.line	1271	loadk        r11    k8 ; k8 = 200
.line	1271	loadk        r12    k9 ; k9 = 65
.line	1271	loadk        r13   k10 ; k10 = 151
.line	1271	loadk        r14   k11 ; k11 = 247
.line	1271	loadk        r15   k12 ; k12 = 206
.line	1271	loadk        r16   k13 ; k13 = 14
.line	1271	loadk        r17   k14 ; k14 = 18
.line	1271	loadk        r18   k15 ; k15 = 13
.line	1271	loadk        r19   k16 ; k16 = 106
.line	1271	loadk        r20   k17 ; k17 = 195
.line	1271	loadk        r21   k18 ; k18 = 249
.line	1271	loadk        r22   k19 ; k19 = 171
.line	1271	loadk        r23   k20 ; k20 = 101
.line	1271	loadk        r24   k21 ; k21 = 245
.line	1271	loadk        r25   k22 ; k22 = 34
.line	1271	loadk        r26   k23 ; k23 = 6
.line	1271	loadk        r27   k24 ; k24 = 243
.line	1271	loadk        r28   k25 ; k25 = 111
.line	1271	loadk        r29   k26 ; k26 = 184
.line	1271	loadk        r30   k27 ; k27 = 242
.line	1271	loadk        r31   k28 ; k28 = 210
.line	1271	loadk        r32   k29 ; k29 = 27
.line	1271	loadk        r33   k30 ; k30 = 95
.line	1271	loadk        r34   k31 ; k31 = 127
.line	1271	loadk        r35   k20 ; k20 = 101
.line	1271	loadk        r36   k32 ; k32 = 216
.line	1271	loadk        r37   k33 ; k33 = 225
.line	1271	loadk        r38   k34 ; k34 = 161
.line	1271	loadk        r39   k35 ; k35 = 64
.line	1271	loadk        r40   k36 ; k36 = 251
.line	1271	loadk        r41   k37 ; k37 = 35
.line	1271	loadk        r42   k38 ; k38 = 29
.line	1271	loadk        r43   k39 ; k39 = 227
.line	1271	loadk        r44   k40 ; k40 = 107
.line	1271	call          r4    41     2
.line	1271	getupval      r5    u0
.line	1271	loadk         r6   k41 ; k41 = 19
.line	1271	call          r5     2     0
.line	1271	setlist       r3     0     1
.line	1271	call          r2     2     2
.line	1271	call          r1     2     2
.line	1271	gettable      r2    r1   k42 ; k42 = "LoadFileToTable_N"
.line	1271	gettable      r3    r1   k43 ; k43 = "ePlayerPrefsType"
.line	1271	gettable      r3    r3   k44 ; k44 = "eDefault"
.line	1271	call          r2     2     2
.line	1271	eq             0    r2   k45 ; k45 = nil
.line	1271	jmp            0   l63
.line	1271	newtable      r3     0     0
.line	1271	move          r2    r3
.label	l63
.line	1271	gettable      r3    r2   k46 ; k46 = "dvid"
.line	1271	eq             0    r3   k45 ; k45 = nil
.line	1271	jmp            0  l112
.line	1271	getupval      r3    u3
.line	1271	call          r3     1     2
.line	1271	getupval      r4    u4
.line	1271	move          r5    r3
.line	1271	call          r4     2     1
.line	1271	getupval      r4    u5
.line	1271	loadk         r5   k47 ; k47 = 10000
.line	1271	loadk         r6   k48 ; k48 = 99999
.line	1271	call          r4     3     2
.line	1271	getupval      r5    u6
.line	1271	move          r6    r4
.line	1271	call          r5     2     2
.line	1271	getupval      r6    u6
.line	1271	move          r7    r3
.line	1271	call          r6     2     2
.line	1271	concat        r5    r5    r6
.line	1271	settable      r2   k46    r5 ; k46 = "dvid"
.line	1271	gettable      r6    r1   k49 ; k49 = "SaveTableToFile_N"
.line	1271	move          r7    r2
.line	1271	gettable      r8    r1   k43 ; k43 = "ePlayerPrefsType"
.line	1271	gettable      r8    r8   k44 ; k44 = "eDefault"
.line	1271	call          r6     3     1
.line	1271	gettabup      r6    u2   k50 ; k50 = "log"
.line	1271	gettabup      r7    u2   k51 ; k51 = "bWriteLog"
.line	1271	test          r7     0
.line	1271	jmp            0  l111
.line	1271	getupval      r7    u0
.line	1271	loadk         r8   k37 ; k37 = 35
.line	1271	loadk         r9   k52 ; k52 = 138
.line	1271	loadk        r10   k53 ; k53 = 32
.line	1271	loadk        r11    k8 ; k8 = 200
.line	1271	loadk        r12   k54 ; k54 = 199
.line	1271	loadk        r13   k55 ; k55 = 42
.line	1271	loadk        r14   k56 ; k56 = 198
.line	1271	loadk        r15   k57 ; k57 = 73
.line	1271	loadk        r16   k58 ; k58 = 142
.line	1271	loadk        r17   k18 ; k18 = 249
.line	1271	loadk        r18   k17 ; k17 = 195
.line	1271	loadk        r19   k59 ; k59 = 87
.line	1271	loadk        r20   k60 ; k60 = 28
.line	1271	call          r7    14     2
.line	1271	getupval      r8    u6
.line	1271	move          r9    r5
.line	1271	call          r8     2     2
.line	1271	concat        r7    r7    r8
.label	l111
.line	1271	call          r6     2     1
.label	l112
.line	1271	gettable      r0    r2   k46 ; k46 = "dvid"
.line	1271	gettabup      r3    u2   k50 ; k50 = "log"
.line	1271	gettabup      r4    u2   k51 ; k51 = "bWriteLog"
.line	1271	test          r4     0
.line	1271	jmp            0  l150
.line	1271	getupval      r4    u0
.line	1271	loadk         r5   k61 ; k61 = 38
.line	1271	loadk         r6   k62 ; k62 = 141
.line	1271	loadk         r7   k63 ; k63 = 43
.line	1271	loadk         r8   k64 ; k64 = 202
.line	1271	loadk         r9   k65 ; k65 = 230
.line	1271	loadk        r10    k7 ; k7 = 59
.line	1271	loadk        r11   k66 ; k66 = 143
.line	1271	loadk        r12    k9 ; k9 = 65
.line	1271	loadk        r13   k67 ; k67 = 214
.line	1271	loadk        r14   k68 ; k68 = 215
.line	1271	loadk        r15   k69 ; k69 = 194
.line	1271	loadk        r16   k70 ; k70 = 25
.line	1271	loadk        r17   k71 ; k71 = 120
.line	1271	loadk        r18   k72 ; k72 = 23
.line	1271	loadk        r19   k73 ; k73 = 76
.line	1271	loadk        r20   k74 ; k74 = 224
.line	1271	loadk        r21   k26 ; k26 = 184
.line	1271	loadk        r22   k33 ; k33 = 225
.line	1271	loadk        r23   k75 ; k75 = 21
.line	1271	loadk        r24   k76 ; k76 = 235
.line	1271	loadk        r25   k61 ; k61 = 38
.line	1271	loadk        r26   k77 ; k77 = 11
.line	1271	loadk        r27   k39 ; k39 = 227
.line	1271	loadk        r28   k25 ; k25 = 111
.line	1271	loadk        r29   k78 ; k78 = 134
.line	1271	loadk        r30   k79 ; k79 = 186
.line	1271	loadk        r31   k10 ; k10 = 151
.line	1271	call          r4    28     2
.line	1271	getupval      r5    u6
.line	1271	move          r6    r0
.line	1271	call          r5     2     2
.line	1271	concat        r4    r4    r5
.label	l150
.line	1271	call          r3     2     1
.line	1271	return        r0     2
.line	1271	return        r0     1
.line	1271	move          r0    r0
.line	1271	move          r0    r0
.line	1271	move          r0    r0
.line	1271	move          r0    r0
.line	1271	return        r0     1

.function	main/f81

.source	null
.linedefined	1292
.lastlinedefined	1305
.numparams	2
.is_vararg	0
.maxstacksize	28

.upvalue	"_ENV"	28	true
.upvalue	"U1"	1	true
.upvalue	"U2"	25	true
.upvalue	"U3"	32	true
.upvalue	"U4"	29	true
.upvalue	"U5"	21	true
.upvalue	"U6"	33	true

.constant	k0	39
.constant	k1	153
.constant	k2	40
.constant	k3	204
.constant	k4	195
.constant	k5	35
.constant	k6	135
.constant	k7	84
.constant	k8	171
.constant	k9	228
.constant	k10	198
.constant	k11	25
.constant	k12	85
.constant	k13	34
.constant	k14	118
.constant	k15	79
.constant	k16	38
.constant	k17	219
.constant	k18	218
.constant	k19	63
.constant	k20	146
.constant	k21	2
.constant	k22	189
.constant	k23	254
.constant	k24	192
.constant	k25	4
.constant	k26	82
.constant	k27	36
.constant	k28	43
.constant	k29	229
.constant	k30	243
.constant	k31	188
.constant	k32	90
.constant	k33	235
.constant	k34	3
.constant	k35	148
.constant	k36	44
.constant	k37	221
.constant	k38	59
.constant	k39	200
.constant	k40	78
.constant	k41	151
.constant	k42	253
.constant	k43	202
.constant	k44	111
.constant	k45	112
.constant	k46	205
.constant	k47	207
.constant	k48	65
.constant	k49	240
.constant	k50	47
.constant	k51	"GetAllActorsOfClass"
.constant	k52	"GetGameInstance"
.constant	k53	"EPropertyClass"
.constant	k54	"Object"
.constant	k55	"ActorHasTag"
.constant	k56	"Add"

.line	1292	getupval      r2    u0
.line	1292	getupval      r3    u1
.line	1292	loadk         r4    k0 ; k0 = 39
.line	1292	loadk         r5    k1 ; k1 = 153
.line	1292	loadk         r6    k2 ; k2 = 40
.line	1292	loadk         r7    k3 ; k3 = 204
.line	1292	loadk         r8    k4 ; k4 = 195
.line	1292	loadk         r9    k5 ; k5 = 35
.line	1292	loadk        r10    k6 ; k6 = 135
.line	1292	loadk        r11    k7 ; k7 = 84
.line	1292	loadk        r12    k8 ; k8 = 171
.line	1292	loadk        r13    k9 ; k9 = 228
.line	1292	loadk        r14   k10 ; k10 = 198
.line	1292	loadk        r15   k11 ; k11 = 25
.line	1292	loadk        r16   k12 ; k12 = 85
.line	1292	loadk        r17   k13 ; k13 = 34
.line	1292	loadk        r18   k14 ; k14 = 118
.line	1292	call          r3    16     2
.line	1292	call          r2     2     2
.line	1292	getupval      r3    u0
.line	1292	getupval      r4    u1
.line	1292	loadk         r5   k15 ; k15 = 79
.line	1292	loadk         r6    k8 ; k8 = 171
.line	1292	loadk         r7   k16 ; k16 = 38
.line	1292	loadk         r8   k17 ; k17 = 219
.line	1292	loadk         r9   k18 ; k18 = 218
.line	1292	loadk        r10   k19 ; k19 = 63
.line	1292	loadk        r11   k20 ; k20 = 146
.line	1292	loadk        r12   k21 ; k21 = 2
.line	1292	loadk        r13   k22 ; k22 = 189
.line	1292	loadk        r14   k23 ; k23 = 254
.line	1292	loadk        r15   k24 ; k24 = 192
.line	1292	loadk        r16   k25 ; k25 = 4
.line	1292	loadk        r17   k26 ; k26 = 82
.line	1292	loadk        r18   k27 ; k27 = 36
.line	1292	loadk        r19   k28 ; k28 = 43
.line	1292	loadk        r20   k29 ; k29 = 229
.line	1292	loadk        r21   k30 ; k30 = 243
.line	1292	loadk        r22   k31 ; k31 = 188
.line	1292	loadk        r23   k32 ; k32 = 90
.line	1292	loadk        r24   k33 ; k33 = 235
.line	1292	call          r4    21     2
.line	1292	call          r3     2     2
.line	1292	getupval      r4    u0
.line	1292	move          r5    r0
.line	1292	call          r4     2     2
.line	1292	getupval      r5    u2
.line	1292	getupval      r6    u1
.line	1292	loadk         r7   k34 ; k34 = 3
.line	1292	loadk         r8   k35 ; k35 = 148
.line	1292	loadk         r9   k36 ; k36 = 44
.line	1292	loadk        r10    k3 ; k3 = 204
.line	1292	loadk        r11   k37 ; k37 = 221
.line	1292	loadk        r12   k38 ; k38 = 59
.line	1292	loadk        r13   k39 ; k39 = 200
.line	1292	loadk        r14   k40 ; k40 = 78
.line	1292	loadk        r15   k41 ; k41 = 151
.line	1292	loadk        r16   k42 ; k42 = 253
.line	1292	loadk        r17   k43 ; k43 = 202
.line	1292	loadk        r18   k21 ; k21 = 2
.line	1292	loadk        r19   k26 ; k26 = 82
.line	1292	loadk        r20   k44 ; k44 = 111
.line	1292	loadk        r21   k45 ; k45 = 112
.line	1292	loadk        r22   k46 ; k46 = 205
.line	1292	loadk        r23   k47 ; k47 = 207
.line	1292	loadk        r24   k22 ; k22 = 189
.line	1292	loadk        r25   k48 ; k48 = 65
.line	1292	loadk        r26   k49 ; k49 = 240
.line	1292	loadk        r27   k50 ; k50 = 47
.line	1292	call          r6    22     2
.line	1292	call          r5     2     2
.line	1292	gettable      r6    r2   k51 ; k51 = "GetAllActorsOfClass"
.line	1292	gettable      r7    r5   k52 ; k52 = "GetGameInstance"
.line	1292	call          r7     1     2
.line	1292	move          r8    r4
.line	1292	getupval      r9    u3
.line	1292	gettabup     r10    u4   k53 ; k53 = "EPropertyClass"
.line	1292	gettable     r10   r10   k54 ; k54 = "Object"
.line	1292	move         r11    r3
.line	1292	call          r9     3     0
.line	1292	call          r6     0     2
.line	1292	getupval      r7    u3
.line	1292	gettabup      r8    u4   k53 ; k53 = "EPropertyClass"
.line	1292	gettable      r8    r8   k54 ; k54 = "Object"
.line	1292	move          r9    r3
.line	1292	call          r7     3     2
.line	1292	getupval      r8    u5
.line	1292	move          r9    r6
.line	1292	call          r8     2     4
.line	1292	jmp            0  l106
.line	1292	test         r12     0
.line	1292	jmp            0  l106
.line	1292	getupval     r13    u6
.line	1292	move         r14   r12
.line	1292	call         r13     2     2
.line	1292	test         r13     0
.line	1292	jmp            0  l106
.line	1292	self         r13   r12   k55 ; k55 = "ActorHasTag"
.line	1292	move         r15    r1
.line	1292	call         r13     3     2
.line	1292	test         r13     0
.line	1292	jmp            0  l106
.line	1292	self         r13    r7   k56 ; k56 = "Add"
.line	1292	move         r15   r12
.line	1292	call         r13     3     1
.label	l106
.line	1292	move          r0    r0
.line	1292	move          r0    r0
.line	1292	return        r7     2
.line	1292	return        r0     1
.line	1292	move          r0    r0
.line	1292	move          r0    r0
.line	1292	return        r0     1

.function	main/f82

.source	null
.linedefined	1307
.lastlinedefined	1314
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false

.constant	k0	"UIManager"
.constant	k1	"GetUI"
.constant	k2	"UI_Config"
.constant	k3	"CloseUI"
.constant	k4	"ShowUI"

.line	1307	gettabup      r1    u0    k0 ; k0 = "UIManager"
.line	1307	gettable      r1    r1    k1 ; k1 = "GetUI"
.line	1307	gettabup      r2    u0    k0 ; k0 = "UIManager"
.line	1307	gettable      r2    r2    k2 ; k2 = "UI_Config"
.line	1307	gettable      r2    r2    r0
.line	1307	call          r1     2     2
.line	1307	test          r1     0
.line	1307	jmp            0   l16
.line	1307	gettabup      r2    u0    k0 ; k0 = "UIManager"
.line	1307	gettable      r2    r2    k3 ; k3 = "CloseUI"
.line	1307	gettabup      r3    u0    k0 ; k0 = "UIManager"
.line	1307	gettable      r3    r3    k2 ; k2 = "UI_Config"
.line	1307	gettable      r3    r3    r0
.line	1307	call          r2     2     1
.line	1307	jmp            0   l22
.label	l16
.line	1307	gettabup      r2    u0    k0 ; k0 = "UIManager"
.line	1307	gettable      r2    r2    k4 ; k4 = "ShowUI"
.line	1307	gettabup      r3    u0    k0 ; k0 = "UIManager"
.line	1307	gettable      r3    r3    k2 ; k2 = "UI_Config"
.line	1307	gettable      r3    r3    r0
.line	1307	call          r2     2     1
.label	l22
.line	1307	return        r0     1
.line	1307	move          r0    r0
.line	1307	move          r0    r0
.line	1307	move          r0    r0
.line	1307	move          r0    r0
.line	1307	return        r0     1

.function	main/f83

.source	null
.linedefined	1316
.lastlinedefined	1319
.numparams	0
.is_vararg	0
.maxstacksize	44

.upvalue	"_ENV"	25	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"table"
.constant	k1	"concat"
.constant	k2	3
.constant	k3	148
.constant	k4	44
.constant	k5	204
.constant	k6	221
.constant	k7	59
.constant	k8	200
.constant	k9	94
.constant	k10	229
.constant	k11	198
.constant	k12	67
.constant	k13	80
.constant	k14	46
.constant	k15	98
.constant	k16	205
.constant	k17	243
.constant	k18	230
.constant	k19	97
.constant	k20	225
.constant	k21	14
.constant	k22	22
.constant	k23	110
.constant	k24	129
.constant	k25	239
.constant	k26	217
.constant	k27	83
.constant	k28	64
.constant	k29	62
.constant	k30	114
.constant	k31	227
.constant	k32	135
.constant	k33	93
.constant	k34	228
.constant	k35	58
.constant	k36	28
.constant	k37	245
.constant	k38	100
.constant	k39	15
.constant	k40	150
.constant	k41	26
.constant	k42	196
.constant	k43	210
.constant	k44	38
.constant	k45	136
.constant	k46	"IsInXMission"

.line	1316	getupval      r0    u0
.line	1316	gettabup      r1    u1    k0 ; k0 = "table"
.line	1316	gettable      r1    r1    k1 ; k1 = "concat"
.line	1316	newtable      r2     1     0
.line	1316	getupval      r3    u2
.line	1316	loadk         r4    k2 ; k2 = 3
.line	1316	loadk         r5    k3 ; k3 = 148
.line	1316	loadk         r6    k4 ; k4 = 44
.line	1316	loadk         r7    k5 ; k5 = 204
.line	1316	loadk         r8    k6 ; k6 = 221
.line	1316	loadk         r9    k7 ; k7 = 59
.line	1316	loadk        r10    k8 ; k8 = 200
.line	1316	loadk        r11    k9 ; k9 = 94
.line	1316	loadk        r12    k3 ; k3 = 148
.line	1316	loadk        r13   k10 ; k10 = 229
.line	1316	loadk        r14   k11 ; k11 = 198
.line	1316	loadk        r15   k12 ; k12 = 67
.line	1316	loadk        r16   k13 ; k13 = 80
.line	1316	loadk        r17   k14 ; k14 = 46
.line	1316	loadk        r18   k15 ; k15 = 98
.line	1316	loadk        r19   k16 ; k16 = 205
.line	1316	loadk        r20   k17 ; k17 = 243
.line	1316	loadk        r21   k18 ; k18 = 230
.line	1316	loadk        r22   k19 ; k19 = 97
.line	1316	loadk        r23   k20 ; k20 = 225
.line	1316	loadk        r24   k21 ; k21 = 14
.line	1316	loadk        r25   k22 ; k22 = 22
.line	1316	loadk        r26   k10 ; k10 = 229
.line	1316	loadk        r27   k23 ; k23 = 110
.line	1316	loadk        r28   k24 ; k24 = 129
.line	1316	loadk        r29   k25 ; k25 = 239
.line	1316	loadk        r30   k26 ; k26 = 217
.line	1316	loadk        r31   k27 ; k27 = 83
.line	1316	loadk        r32   k28 ; k28 = 64
.line	1316	loadk        r33   k29 ; k29 = 62
.line	1316	loadk        r34   k30 ; k30 = 114
.line	1316	loadk        r35    k6 ; k6 = 221
.line	1316	loadk        r36   k31 ; k31 = 227
.line	1316	loadk        r37   k32 ; k32 = 135
.line	1316	loadk        r38   k33 ; k33 = 93
.line	1316	loadk        r39   k34 ; k34 = 228
.line	1316	loadk        r40   k35 ; k35 = 58
.line	1316	loadk        r41   k36 ; k36 = 28
.line	1316	loadk        r42   k37 ; k37 = 245
.line	1316	loadk        r43   k38 ; k38 = 100
.line	1316	call          r3    41     2
.line	1316	getupval      r4    u2
.line	1316	loadk         r5   k39 ; k39 = 15
.line	1316	loadk         r6   k40 ; k40 = 150
.line	1316	loadk         r7   k41 ; k41 = 26
.line	1316	loadk         r8   k42 ; k42 = 196
.line	1316	loadk         r9   k43 ; k43 = 210
.line	1316	loadk        r10   k44 ; k44 = 38
.line	1316	loadk        r11   k45 ; k45 = 136
.line	1316	call          r4     8     0
.line	1316	setlist       r2     0     1
.line	1316	call          r1     2     2
.line	1316	call          r0     2     2
.line	1316	gettable      r1    r0   k46 ; k46 = "IsInXMission"
.line	1316	tailcall      r1     1
.line	1316	return        r1     0
.line	1316	return        r0     1
.line	1316	move          r0    r0
.line	1316	move          r0    r0
.line	1316	move          r0    r0
.line	1316	move          r0    r0
.line	1316	return        r0     1

.function	main/f84

.source	null
.linedefined	1321
.lastlinedefined	1330
.numparams	0
.is_vararg	0
.maxstacksize	25

.upvalue	"_ENV"	25	true
.upvalue	"U1"	1	true
.upvalue	"U2"	0	false

.constant	k0	3
.constant	k1	148
.constant	k2	44
.constant	k3	204
.constant	k4	221
.constant	k5	59
.constant	k6	200
.constant	k7	78
.constant	k8	151
.constant	k9	253
.constant	k10	202
.constant	k11	2
.constant	k12	82
.constant	k13	111
.constant	k14	113
.constant	k15	205
.constant	k16	173
.constant	k17	106
.constant	k18	236
.constant	k19	55
.constant	k20	22
.constant	k21	250
.constant	k22	40
.constant	k23	196
.constant	k24	220
.constant	k25	33
.constant	k26	89
.constant	k27	153
.constant	k28	242
.constant	k29	203
.constant	k30	8
.constant	k31	99
.constant	k32	52
.constant	k33	252
.constant	k34	"GetTableValue"
.constant	k35	"DataMgr"
.constant	k36	18
.constant	k37	41
.constant	k38	247
.constant	k39	46
.constant	k40	146
.constant	k41	76
.constant	k42	15
.constant	k43	246
.constant	k44	223
.constant	k45	149
.constant	k46	167
.constant	k47	10
.constant	k48	85
.constant	k49	47
.constant	k50	90
.constant	k51	208
.constant	k52	249
.constant	k53	165
.constant	k54	80
.constant	k55	nil
.constant	k56	0
.constant	k57	"GetServerTimeInSec"
.constant	k58	"IsSameDay"

.line	1321	getupval      r0    u0
.line	1321	getupval      r1    u1
.line	1321	loadk         r2    k0 ; k0 = 3
.line	1321	loadk         r3    k1 ; k1 = 148
.line	1321	loadk         r4    k2 ; k2 = 44
.line	1321	loadk         r5    k3 ; k3 = 204
.line	1321	loadk         r6    k4 ; k4 = 221
.line	1321	loadk         r7    k5 ; k5 = 59
.line	1321	loadk         r8    k6 ; k6 = 200
.line	1321	loadk         r9    k7 ; k7 = 78
.line	1321	loadk        r10    k8 ; k8 = 151
.line	1321	loadk        r11    k9 ; k9 = 253
.line	1321	loadk        r12   k10 ; k10 = 202
.line	1321	loadk        r13   k11 ; k11 = 2
.line	1321	loadk        r14   k12 ; k12 = 82
.line	1321	loadk        r15   k13 ; k13 = 111
.line	1321	loadk        r16   k14 ; k14 = 113
.line	1321	loadk        r17   k15 ; k15 = 205
.line	1321	loadk        r18    k9 ; k9 = 253
.line	1321	loadk        r19   k16 ; k16 = 173
.line	1321	loadk        r20   k17 ; k17 = 106
.line	1321	loadk        r21   k18 ; k18 = 236
.line	1321	loadk        r22   k19 ; k19 = 55
.line	1321	loadk        r23   k20 ; k20 = 22
.line	1321	loadk        r24   k21 ; k21 = 250
.line	1321	call          r1    24     2
.line	1321	call          r0     2     2
.line	1321	getupval      r1    u0
.line	1321	getupval      r2    u1
.line	1321	loadk         r3    k0 ; k0 = 3
.line	1321	loadk         r4    k8 ; k8 = 151
.line	1321	loadk         r5   k22 ; k22 = 40
.line	1321	loadk         r6   k23 ; k23 = 196
.line	1321	loadk         r7   k24 ; k24 = 220
.line	1321	loadk         r8   k25 ; k25 = 33
.line	1321	loadk         r9    k6 ; k6 = 200
.line	1321	loadk        r10   k26 ; k26 = 89
.line	1321	loadk        r11   k27 ; k27 = 153
.line	1321	loadk        r12   k28 ; k28 = 242
.line	1321	loadk        r13   k29 ; k29 = 203
.line	1321	loadk        r14   k30 ; k30 = 8
.line	1321	loadk        r15   k31 ; k31 = 99
.line	1321	loadk        r16   k32 ; k32 = 52
.line	1321	loadk        r17   k14 ; k14 = 113
.line	1321	loadk        r18   k15 ; k15 = 205
.line	1321	loadk        r19   k33 ; k33 = 252
.line	1321	call          r2    18     2
.line	1321	call          r1     2     2
.line	1321	gettable      r2    r1   k34 ; k34 = "GetTableValue"
.line	1321	gettabup      r3    u2   k35 ; k35 = "DataMgr"
.line	1321	getupval      r4    u1
.line	1321	loadk         r5   k36 ; k36 = 18
.line	1321	loadk         r6    k8 ; k8 = 151
.line	1321	loadk         r7   k37 ; k37 = 41
.line	1321	loadk         r8    k3 ; k3 = 204
.line	1321	loadk         r9   k38 ; k38 = 247
.line	1321	loadk        r10   k39 ; k39 = 46
.line	1321	loadk        r11   k40 ; k40 = 146
.line	1321	loadk        r12   k41 ; k41 = 76
.line	1321	call          r4     9     2
.line	1321	getupval      r5    u1
.line	1321	loadk         r6   k42 ; k42 = 15
.line	1321	loadk         r7    k1 ; k1 = 148
.line	1321	loadk         r8   k25 ; k25 = 33
.line	1321	loadk         r9   k43 ; k43 = 246
.line	1321	loadk        r10   k44 ; k44 = 223
.line	1321	loadk        r11   k39 ; k39 = 46
.line	1321	loadk        r12   k45 ; k45 = 149
.line	1321	loadk        r13   k26 ; k26 = 89
.line	1321	loadk        r14   k46 ; k46 = 167
.line	1321	loadk        r15   k33 ; k33 = 252
.line	1321	loadk        r16    k6 ; k6 = 200
.line	1321	loadk        r17   k47 ; k47 = 10
.line	1321	loadk        r18   k48 ; k48 = 85
.line	1321	loadk        r19   k49 ; k49 = 47
.line	1321	loadk        r20   k50 ; k50 = 90
.line	1321	loadk        r21   k51 ; k51 = 208
.line	1321	loadk        r22   k52 ; k52 = 249
.line	1321	loadk        r23   k53 ; k53 = 165
.line	1321	loadk        r24   k54 ; k54 = 80
.line	1321	call          r5    20     2
.line	1321	call          r2     4     2
.line	1321	eq             0    r2   k55 ; k55 = nil
.line	1321	jmp            0   l86
.line	1321	loadk         r2   k56 ; k56 = 0
.label	l86
.line	1321	gettable      r3    r0   k57 ; k57 = "GetServerTimeInSec"
.line	1321	call          r3     1     2
.line	1321	gettable      r4    r0   k58 ; k58 = "IsSameDay"
.line	1321	move          r5    r2
.line	1321	move          r6    r3
.line	1321	tailcall      r4     3
.line	1321	return        r4     0
.line	1321	return        r0     1
.line	1321	move          r0    r0
.line	1321	move          r0    r0
.line	1321	move          r0    r0
.line	1321	return        r0     1

.function	main/f85

.source	null
.linedefined	1332
.lastlinedefined	1339
.numparams	1
.is_vararg	0
.maxstacksize	25

.upvalue	"_ENV"	5	true
.upvalue	"U1"	1	true
.upvalue	"U2"	0	false
.upvalue	"U3"	39	true

.constant	k0	48
.constant	k1	153
.constant	k2	46
.constant	k3	218
.constant	k4	156
.constant	k5	28
.constant	k6	135
.constant	k7	91
.constant	k8	157
.constant	k9	215
.constant	k10	198
.constant	k11	0
.constant	k12	89
.constant	k13	50
.constant	k14	42
.constant	k15	129
.constant	k16	227
.constant	k17	230
.constant	k18	95
.constant	k19	234
.constant	k20	44
.constant	k21	17
.constant	k22	"Client"
.constant	k23	"LoadFileToString"
.constant	k24	nil

.line	1332	getupval      r1    u0
.line	1332	getupval      r2    u1
.line	1332	loadk         r3    k0 ; k0 = 48
.line	1332	loadk         r4    k1 ; k1 = 153
.line	1332	loadk         r5    k2 ; k2 = 46
.line	1332	loadk         r6    k3 ; k3 = 218
.line	1332	loadk         r7    k4 ; k4 = 156
.line	1332	loadk         r8    k5 ; k5 = 28
.line	1332	loadk         r9    k6 ; k6 = 135
.line	1332	loadk        r10    k7 ; k7 = 91
.line	1332	loadk        r11    k8 ; k8 = 157
.line	1332	loadk        r12    k9 ; k9 = 215
.line	1332	loadk        r13   k10 ; k10 = 198
.line	1332	loadk        r14   k11 ; k11 = 0
.line	1332	loadk        r15   k12 ; k12 = 89
.line	1332	loadk        r16   k13 ; k13 = 50
.line	1332	loadk        r17   k14 ; k14 = 42
.line	1332	loadk        r18   k15 ; k15 = 129
.line	1332	loadk        r19   k16 ; k16 = 227
.line	1332	loadk        r20   k17 ; k17 = 230
.line	1332	loadk        r21   k18 ; k18 = 95
.line	1332	loadk        r22   k19 ; k19 = 234
.line	1332	loadk        r23   k20 ; k20 = 44
.line	1332	loadk        r24   k21 ; k21 = 17
.line	1332	call          r2    23     2
.line	1332	move          r3    r0
.line	1332	call          r1     3     2
.line	1332	gettabup      r2    u2   k22 ; k22 = "Client"
.line	1332	gettable      r2    r2   k23 ; k23 = "LoadFileToString"
.line	1332	move          r3    r1
.line	1332	call          r2     2     2
.line	1332	eq             1    r2   k24 ; k24 = nil
.line	1332	jmp            0   l38
.line	1332	getupval      r3    u1
.line	1332	call          r3     1     2
.line	1332	eq             0    r2    r3
.line	1332	jmp            0   l40
.label	l38
.line	1332	loadnil       r3     0
.line	1332	return        r3     2
.label	l40
.line	1332	getupval      r3    u3
.line	1332	move          r4    r2
.line	1332	tailcall      r3     2
.line	1332	return        r3     0
.line	1332	return        r0     1
.line	1332	move          r0    r0
.line	1332	move          r0    r0
.line	1332	move          r0    r0
.line	1332	return        r0     1

.function	main/f86

.source	null
.linedefined	1341
.lastlinedefined	1356
.numparams	1
.is_vararg	0
.maxstacksize	30

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	25	true
.upvalue	"U3"	21	true

.constant	k0	"FuncUtil"
.constant	k1	"GetJsonFileToTable"
.constant	k2	"log"
.constant	k3	"bWriteLog"
.constant	k4	44
.constant	k5	151
.constant	k6	36
.constant	k7	205
.constant	k8	147
.constant	k9	128
.constant	k10	74
.constant	k11	216
.constant	k12	246
.constant	k13	198
.constant	k14	4
.constant	k15	80
.constant	k16	97
.constant	k17	158
.constant	k18	176
.constant	k19	"Client"
.constant	k20	"TPerforPlatMarkTime"
.constant	k21	50001
.constant	k22	3
.constant	k23	40
.constant	k24	196
.constant	k25	220
.constant	k26	33
.constant	k27	200
.constant	k28	76
.constant	k29	139
.constant	k30	227
.constant	k31	194
.constant	k32	25
.constant	k33	99
.constant	k34	52
.constant	k35	113
.constant	k36	252
.constant	k37	148
.constant	k38	204
.constant	k39	221
.constant	k40	59
.constant	k41	78
.constant	k42	253
.constant	k43	202
.constant	k44	2
.constant	k45	82
.constant	k46	111
.constant	k47	117
.constant	k48	197
.constant	k49	251
.constant	k50	64
.constant	k51	237
.constant	k52	42
.constant	k53	19
.constant	k54	"IsFileExist"
.constant	k55	"GetAssetSync"
.constant	k56	"TPerforPlatReport"
.constant	k57	54
.constant	k58	199
.constant	k59	170
.constant	k60	66
.constant	k61	153
.constant	k62	244
.constant	k63	135
.constant	k64	89
.constant	k65	50
.constant	k66	132
.constant	k67	245
.constant	k68	166
.constant	k69	81
.constant	k70	183
.constant	k71	109

.line	1341	gettabup      r1    u0    k0 ; k0 = "FuncUtil"
.line	1341	gettable      r1    r1    k1 ; k1 = "GetJsonFileToTable"
.line	1341	move          r2    r0
.line	1341	call          r1     2     2
.line	1341	test          r1     1
.line	1341	jmp            0   l34
.line	1341	gettabup      r2    u0    k2 ; k2 = "log"
.line	1341	gettabup      r3    u0    k3 ; k3 = "bWriteLog"
.line	1341	test          r3     0
.line	1341	jmp            0   l32
.line	1341	getupval      r3    u1
.line	1341	loadk         r4    k4 ; k4 = 44
.line	1341	loadk         r5    k5 ; k5 = 151
.line	1341	loadk         r6    k6 ; k6 = 36
.line	1341	loadk         r7    k7 ; k7 = 205
.line	1341	loadk         r8    k8 ; k8 = 147
.line	1341	loadk         r9    k4 ; k4 = 44
.line	1341	loadk        r10    k9 ; k9 = 128
.line	1341	loadk        r11   k10 ; k10 = 74
.line	1341	loadk        r12   k11 ; k11 = 216
.line	1341	loadk        r13   k12 ; k12 = 246
.line	1341	loadk        r14   k13 ; k13 = 198
.line	1341	loadk        r15   k14 ; k14 = 4
.line	1341	loadk        r16   k15 ; k15 = 80
.line	1341	loadk        r17    k6 ; k6 = 36
.line	1341	loadk        r18   k16 ; k16 = 97
.line	1341	loadk        r19   k17 ; k17 = 158
.line	1341	loadk        r20   k18 ; k18 = 176
.line	1341	call          r3    18     2
.line	1341	move          r4    r0
.line	1341	concat        r3    r3    r4
.label	l32
.line	1341	call          r2     2     1
.line	1341	return        r0     1
.label	l34
.line	1341	gettabup      r2    u0   k19 ; k19 = "Client"
.line	1341	gettable      r2    r2   k20 ; k20 = "TPerforPlatMarkTime"
.line	1341	loadk         r3   k21 ; k21 = 50001
.line	1341	call          r2     2     1
.line	1341	getupval      r2    u2
.line	1341	getupval      r3    u1
.line	1341	loadk         r4   k22 ; k22 = 3
.line	1341	loadk         r5    k5 ; k5 = 151
.line	1341	loadk         r6   k23 ; k23 = 40
.line	1341	loadk         r7   k24 ; k24 = 196
.line	1341	loadk         r8   k25 ; k25 = 220
.line	1341	loadk         r9   k26 ; k26 = 33
.line	1341	loadk        r10   k27 ; k27 = 200
.line	1341	loadk        r11   k28 ; k28 = 76
.line	1341	loadk        r12   k29 ; k29 = 139
.line	1341	loadk        r13   k30 ; k30 = 227
.line	1341	loadk        r14   k31 ; k31 = 194
.line	1341	loadk        r15   k32 ; k32 = 25
.line	1341	loadk        r16   k33 ; k33 = 99
.line	1341	loadk        r17   k34 ; k34 = 52
.line	1341	loadk        r18   k35 ; k35 = 113
.line	1341	loadk        r19    k7 ; k7 = 205
.line	1341	loadk        r20   k36 ; k36 = 252
.line	1341	call          r3    18     2
.line	1341	call          r2     2     2
.line	1341	getupval      r3    u2
.line	1341	getupval      r4    u1
.line	1341	loadk         r5   k22 ; k22 = 3
.line	1341	loadk         r6   k37 ; k37 = 148
.line	1341	loadk         r7    k4 ; k4 = 44
.line	1341	loadk         r8   k38 ; k38 = 204
.line	1341	loadk         r9   k39 ; k39 = 221
.line	1341	loadk        r10   k40 ; k40 = 59
.line	1341	loadk        r11   k27 ; k27 = 200
.line	1341	loadk        r12   k41 ; k41 = 78
.line	1341	loadk        r13    k5 ; k5 = 151
.line	1341	loadk        r14   k42 ; k42 = 253
.line	1341	loadk        r15   k43 ; k43 = 202
.line	1341	loadk        r16   k44 ; k44 = 2
.line	1341	loadk        r17   k45 ; k45 = 82
.line	1341	loadk        r18   k46 ; k46 = 111
.line	1341	loadk        r19   k47 ; k47 = 117
.line	1341	loadk        r20   k48 ; k48 = 197
.line	1341	loadk        r21   k49 ; k49 = 251
.line	1341	loadk        r22    k5 ; k5 = 151
.line	1341	loadk        r23   k50 ; k50 = 64
.line	1341	loadk        r24   k51 ; k51 = 237
.line	1341	loadk        r25   k52 ; k52 = 42
.line	1341	loadk        r26   k53 ; k53 = 19
.line	1341	call          r4    23     2
.line	1341	call          r3     2     2
.line	1341	getupval      r4    u3
.line	1341	move          r5    r1
.line	1341	call          r4     2     4
.line	1341	jmp            0   l97
.line	1341	gettable      r9    r3   k54 ; k54 = "IsFileExist"
.line	1341	move         r10    r8
.line	1341	call          r9     2     2
.line	1341	test          r9     0
.line	1341	jmp            0   l97
.line	1341	gettable      r9    r2   k55 ; k55 = "GetAssetSync"
.line	1341	move         r10    r8
.line	1341	call          r9     2     1
.label	l97
.line	1341	move          r0    r0
.line	1341	move          r0    r0
.line	1341	gettabup      r4    u0   k19 ; k19 = "Client"
.line	1341	gettable      r4    r4   k56 ; k56 = "TPerforPlatReport"
.line	1341	loadk         r5   k21 ; k21 = 50001
.line	1341	move          r6    r0
.line	1341	getupval      r7    u1
.line	1341	loadk         r8   k26 ; k26 = 33
.line	1341	loadk         r9   k29 ; k29 = 139
.line	1341	loadk        r10   k57 ; k57 = 54
.line	1341	loadk        r11   k38 ; k38 = 204
.line	1341	loadk        r12   k58 ; k58 = 199
.line	1341	loadk        r13   k46 ; k46 = 111
.line	1341	loadk        r14   k59 ; k59 = 170
.line	1341	loadk        r15   k60 ; k60 = 66
.line	1341	loadk        r16   k61 ; k61 = 153
.line	1341	loadk        r17   k62 ; k62 = 244
.line	1341	loadk        r18   k63 ; k63 = 135
.line	1341	loadk        r19   k32 ; k32 = 25
.line	1341	loadk        r20   k64 ; k64 = 89
.line	1341	loadk        r21   k65 ; k65 = 50
.line	1341	loadk        r22   k35 ; k35 = 113
.line	1341	loadk        r23   k66 ; k66 = 132
.line	1341	loadk        r24   k67 ; k67 = 245
.line	1341	loadk        r25   k68 ; k68 = 166
.line	1341	loadk        r26   k69 ; k69 = 81
.line	1341	loadk        r27   k70 ; k70 = 183
.line	1341	loadk        r28   k71 ; k71 = 109
.line	1341	loadk        r29   k69 ; k69 = 81
.line	1341	call          r7    23     2
.line	1341	concat        r6    r6    r7
.line	1341	call          r4     3     1
.line	1341	return        r0     1
.line	1341	move          r0    r0
.line	1341	move          r0    r0
.line	1341	move          r0    r0
.line	1341	move          r0    r0
.line	1341	return        r0     1

.function	main/f87

.source	null
.linedefined	1358
.lastlinedefined	1369
.numparams	2
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	13	true
.upvalue	"U1"	16	true
.upvalue	"U2"	1	true
.upvalue	"U3"	5	true

.constant	k0	0
.constant	k1	0.1
.constant	k2	69
.constant	k3	214
.constant	k4	6

.line	1358	getupval      r2    u0
.line	1358	move          r3    r0
.line	1358	call          r2     2     2
.line	1358	le             0    r1    k0 ; k0 = 0
.line	1358	jmp            0    l7
.line	1358	return        r2     2
.label	l7
.line	1358	getupval      r3    u1
.line	1358	sub           r4    r0    r2
.line	1358	call          r3     2     2
.line	1358	pow           r4    k1    r1 ; k1 = 0.1
.line	1358	lt             0    r3    r4
.line	1358	jmp            0   l15
.line	1358	return        r2     2
.line	1358	jmp            0   l29
.label	l15
.line	1358	getupval      r3    u2
.line	1358	loadk         r4    k2 ; k2 = 69
.line	1358	loadk         r5    k3 ; k3 = 214
.line	1358	call          r3     3     2
.line	1358	move          r4    r1
.line	1358	getupval      r5    u2
.line	1358	loadk         r6    k4 ; k4 = 6
.line	1358	call          r5     2     2
.line	1358	concat        r3    r3    r5
.line	1358	getupval      r4    u3
.line	1358	move          r5    r3
.line	1358	move          r6    r0
.line	1358	tailcall      r4     3
.line	1358	return        r4     0
.label	l29
.line	1358	return        r0     1
.line	1358	move          r0    r0
.line	1358	move          r0    r0
.line	1358	return        r0     1

.function	main/f88

.source	null
.linedefined	1371
.lastlinedefined	1391
.numparams	3
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	27	true
.upvalue	"U3"	24	true

.constant	k0	0
.constant	k1	"FuncUtil"
.constant	k2	"GetRankTableName"
.constant	k3	"log"
.constant	k4	"bWriteLog"
.constant	k5	"table"
.constant	k6	"concat"
.constant	k7	38
.constant	k8	141
.constant	k9	43
.constant	k10	202
.constant	k11	230
.constant	k12	59
.constant	k13	143
.constant	k14	65
.constant	k15	214
.constant	k16	215
.constant	k17	194
.constant	k18	25
.constant	k19	110
.constant	k20	32
.constant	k21	107
.constant	k22	207
.constant	k23	196
.constant	k24	169
.constant	k25	87
.constant	k26	245
.constant	k27	247
.constant	k28	105
.constant	k29	137
.constant	k30	160
.constant	k31	197
.constant	k32	28
.constant	k33	66
.constant	k34	58
.constant	k35	213
.constant	k36	226
.constant	k37	180
.constant	k38	64
.constant	k39	199
.constant	k40	50
.constant	k41	2
.constant	k42	227
.constant	k43	45
.constant	k44	9
.constant	k45	139
.constant	k46	101
.constant	k47	218
.constant	k48	35
.constant	k49	"GetTableData"
.constant	k50	"IsRankInvalid"
.constant	k51	15
.constant	k52	85
.constant	k53	113
.constant	k54	97
.constant	k55	219
.constant	k56	191
.constant	k57	253
.constant	k58	115
.constant	k59	6
.constant	k60	232
.constant	k61	123
.constant	k62	1
.constant	k63	148
.constant	k64	44
.constant	k65	205
.constant	k66	147
.constant	k67	60
.constant	k68	131
.constant	k69	74
.constant	k70	149
.constant	k71	201
.constant	k72	40
.constant	k73	136
.constant	k74	176
.constant	k75	187
.constant	k76	80
.constant	k77	254
.constant	k78	46
.constant	k79	26
.constant	k80	248
.constant	k81	200
.constant	k82	233
.constant	k83	211
.constant	k84	93
.constant	k85	69
.constant	k86	34
.constant	k87	47
.constant	k88	nil
.constant	k89	3
.constant	k90	231
.constant	k91	126
.constant	k92	20
.constant	k93	216
.constant	k94	54
.constant	k95	204
.constant	k96	210
.constant	k97	67
.constant	k98	198
.constant	k99	242
.constant	k100	164
.constant	k101	"GetRankTableData"

.line	1371	test          r0     1
.line	1371	jmp            0    l5
.line	1371	loadnil       r3     0
.line	1371	return        r3     2
.label	l5
.line	1371	testset       r3    r1     1
.line	1371	jmp            0    l8
.line	1371	loadk         r3    k0 ; k0 = 0
.label	l8
.line	1371	gettabup      r4    u0    k1 ; k1 = "FuncUtil"
.line	1371	gettable      r4    r4    k2 ; k2 = "GetRankTableName"
.line	1371	move          r5    r3
.line	1371	call          r4     2     2
.line	1371	test          r4     1
.line	1371	jmp            0   l77
.line	1371	gettabup      r5    u0    k3 ; k3 = "log"
.line	1371	gettabup      r6    u0    k4 ; k4 = "bWriteLog"
.line	1371	test          r6     0
.line	1371	jmp            0   l74
.line	1371	gettabup      r6    u0    k5 ; k5 = "table"
.line	1371	gettable      r6    r6    k6 ; k6 = "concat"
.line	1371	newtable      r7     1     0
.line	1371	getupval      r8    u1
.line	1371	loadk         r9    k7 ; k7 = 38
.line	1371	loadk        r10    k8 ; k8 = 141
.line	1371	loadk        r11    k9 ; k9 = 43
.line	1371	loadk        r12   k10 ; k10 = 202
.line	1371	loadk        r13   k11 ; k11 = 230
.line	1371	loadk        r14   k12 ; k12 = 59
.line	1371	loadk        r15   k13 ; k13 = 143
.line	1371	loadk        r16   k14 ; k14 = 65
.line	1371	loadk        r17   k15 ; k15 = 214
.line	1371	loadk        r18   k16 ; k16 = 215
.line	1371	loadk        r19   k17 ; k17 = 194
.line	1371	loadk        r20   k18 ; k18 = 25
.line	1371	loadk        r21   k19 ; k19 = 110
.line	1371	loadk        r22   k20 ; k20 = 32
.line	1371	loadk        r23   k21 ; k21 = 107
.line	1371	loadk        r24   k22 ; k22 = 207
.line	1371	loadk        r25   k23 ; k23 = 196
.line	1371	loadk        r26   k24 ; k24 = 169
.line	1371	loadk        r27   k25 ; k25 = 87
.line	1371	loadk        r28   k26 ; k26 = 245
.line	1371	loadk        r29    k7 ; k7 = 38
.line	1371	loadk        r30   k12 ; k12 = 59
.line	1371	loadk        r31   k27 ; k27 = 247
.line	1371	loadk        r32   k28 ; k28 = 105
.line	1371	loadk        r33   k29 ; k29 = 137
.line	1371	loadk        r34   k30 ; k30 = 160
.line	1371	loadk        r35   k31 ; k31 = 197
.line	1371	loadk        r36   k32 ; k32 = 28
.line	1371	loadk        r37   k33 ; k33 = 66
.line	1371	loadk        r38   k34 ; k34 = 58
.line	1371	loadk        r39   k14 ; k14 = 65
.line	1371	loadk        r40   k35 ; k35 = 213
.line	1371	loadk        r41   k36 ; k36 = 226
.line	1371	loadk        r42   k37 ; k37 = 180
.line	1371	loadk        r43   k38 ; k38 = 64
.line	1371	loadk        r44   k39 ; k39 = 199
.line	1371	loadk        r45   k40 ; k40 = 50
.line	1371	loadk        r46   k41 ; k41 = 2
.line	1371	loadk        r47   k42 ; k42 = 227
.line	1371	loadk        r48   k43 ; k43 = 45
.line	1371	call          r8    41     2
.line	1371	getupval      r9    u1
.line	1371	loadk        r10   k44 ; k44 = 9
.line	1371	loadk        r11   k45 ; k45 = 139
.line	1371	loadk        r12   k46 ; k46 = 101
.line	1371	loadk        r13   k39 ; k39 = 199
.line	1371	loadk        r14   k47 ; k47 = 218
.line	1371	loadk        r15   k48 ; k48 = 35
.line	1371	loadk        r16   k39 ; k39 = 199
.line	1371	call          r9     8     0
.line	1371	setlist       r7     0     1
.line	1371	call          r6     2     2
.label	l74
.line	1371	call          r5     2     1
.line	1371	loadnil       r5     0
.line	1371	return        r5     2
.label	l77
.line	1371	gettabup      r5    u2   k49 ; k49 = "GetTableData"
.line	1371	move          r6    r4
.line	1371	move          r7    r0
.line	1371	call          r5     3     2
.line	1371	test          r5     0
.line	1371	jmp            0  l177
.line	1371	gettable      r6    r5   k50 ; k50 = "IsRankInvalid"
.line	1371	test          r6     0
.line	1371	jmp            0  l177
.line	1371	gettabup      r6    u0    k3 ; k3 = "log"
.line	1371	gettabup      r7    u0    k4 ; k4 = "bWriteLog"
.line	1371	test          r7     0
.line	1371	jmp            0  l175
.line	1371	gettabup      r7    u0    k5 ; k5 = "table"
.line	1371	gettable      r7    r7    k6 ; k6 = "concat"
.line	1371	newtable      r8     1     0
.line	1371	getupval      r9    u1
.line	1371	loadk        r10    k7 ; k7 = 38
.line	1371	loadk        r11    k8 ; k8 = 141
.line	1371	loadk        r12    k9 ; k9 = 43
.line	1371	loadk        r13   k10 ; k10 = 202
.line	1371	loadk        r14   k11 ; k11 = 230
.line	1371	loadk        r15   k12 ; k12 = 59
.line	1371	loadk        r16   k13 ; k13 = 143
.line	1371	loadk        r17   k14 ; k14 = 65
.line	1371	loadk        r18   k15 ; k15 = 214
.line	1371	loadk        r19   k16 ; k16 = 215
.line	1371	loadk        r20   k17 ; k17 = 194
.line	1371	loadk        r21   k18 ; k18 = 25
.line	1371	loadk        r22   k19 ; k19 = 110
.line	1371	loadk        r23   k20 ; k20 = 32
.line	1371	loadk        r24   k21 ; k21 = 107
.line	1371	loadk        r25   k22 ; k22 = 207
.line	1371	loadk        r26   k23 ; k23 = 196
.line	1371	loadk        r27   k24 ; k24 = 169
.line	1371	loadk        r28   k25 ; k25 = 87
.line	1371	loadk        r29   k26 ; k26 = 245
.line	1371	loadk        r30    k7 ; k7 = 38
.line	1371	loadk        r31   k12 ; k12 = 59
.line	1371	loadk        r32   k27 ; k27 = 247
.line	1371	loadk        r33   k28 ; k28 = 105
.line	1371	loadk        r34   k29 ; k29 = 137
.line	1371	loadk        r35   k30 ; k30 = 160
.line	1371	loadk        r36   k42 ; k42 = 227
.line	1371	loadk        r37   k51 ; k51 = 15
.line	1371	loadk        r38   k52 ; k52 = 85
.line	1371	loadk        r39   k53 ; k53 = 113
.line	1371	loadk        r40   k54 ; k54 = 97
.line	1371	loadk        r41   k55 ; k55 = 219
.line	1371	loadk        r42   k30 ; k30 = 160
.line	1371	loadk        r43   k56 ; k56 = 191
.line	1371	loadk        r44   k38 ; k38 = 64
.line	1371	loadk        r45   k57 ; k57 = 253
.line	1371	loadk        r46   k58 ; k58 = 115
.line	1371	loadk        r47   k59 ; k59 = 6
.line	1371	loadk        r48   k60 ; k60 = 232
.line	1371	loadk        r49   k61 ; k61 = 123
.line	1371	call          r9    41     2
.line	1371	getupval     r10    u1
.line	1371	loadk        r11   k62 ; k62 = 1
.line	1371	loadk        r12   k63 ; k63 = 148
.line	1371	loadk        r13   k64 ; k64 = 44
.line	1371	loadk        r14   k65 ; k65 = 205
.line	1371	loadk        r15   k66 ; k66 = 147
.line	1371	loadk        r16   k67 ; k67 = 60
.line	1371	loadk        r17   k68 ; k68 = 131
.line	1371	loadk        r18   k69 ; k69 = 74
.line	1371	loadk        r19   k70 ; k70 = 149
.line	1371	loadk        r20   k26 ; k26 = 245
.line	1371	loadk        r21   k71 ; k71 = 201
.line	1371	loadk        r22   k18 ; k18 = 25
.line	1371	loadk        r23   k32 ; k32 = 28
.line	1371	loadk        r24   k72 ; k72 = 40
.line	1371	loadk        r25   k54 ; k54 = 97
.line	1371	loadk        r26   k73 ; k73 = 136
.line	1371	loadk        r27   k74 ; k74 = 176
.line	1371	loadk        r28   k75 ; k75 = 187
.line	1371	loadk        r29   k76 ; k76 = 80
.line	1371	loadk        r30   k77 ; k77 = 254
.line	1371	loadk        r31   k78 ; k78 = 46
.line	1371	loadk        r32   k79 ; k79 = 26
.line	1371	loadk        r33   k80 ; k80 = 248
.line	1371	loadk        r34   k28 ; k28 = 105
.line	1371	loadk        r35   k81 ; k81 = 200
.line	1371	loadk        r36   k82 ; k82 = 233
.line	1371	loadk        r37   k83 ; k83 = 211
.line	1371	loadk        r38   k84 ; k84 = 93
.line	1371	loadk        r39   k85 ; k85 = 69
.line	1371	loadk        r40   k86 ; k86 = 34
.line	1371	loadk        r41   k87 ; k87 = 47
.line	1371	loadk        r42   k63 ; k63 = 148
.line	1371	call         r10    33     0
.line	1371	setlist       r8     0     1
.line	1371	call          r7     2     2
.line	1371	getupval      r8    u3
.line	1371	move          r9    r0
.line	1371	call          r8     2     2
.line	1371	concat        r7    r7    r8
.label	l175
.line	1371	call          r6     2     1
.line	1371	loadnil       r5     0
.label	l177
.line	1371	eq             0    r5   k88 ; k88 = nil
.line	1371	jmp            0  l263
.line	1371	le             0    k0    r3 ; k0 = 0
.line	1371	jmp            0  l263
.line	1371	test          r2     1
.line	1371	jmp            0  l263
.line	1371	gettabup      r6    u0    k3 ; k3 = "log"
.line	1371	gettabup      r7    u0    k4 ; k4 = "bWriteLog"
.line	1371	test          r7     0
.line	1371	jmp            0  l255
.line	1371	gettabup      r7    u0    k5 ; k5 = "table"
.line	1371	gettable      r7    r7    k6 ; k6 = "concat"
.line	1371	newtable      r8     1     0
.line	1371	getupval      r9    u1
.line	1371	loadk        r10    k7 ; k7 = 38
.line	1371	loadk        r11    k8 ; k8 = 141
.line	1371	loadk        r12    k9 ; k9 = 43
.line	1371	loadk        r13   k10 ; k10 = 202
.line	1371	loadk        r14   k11 ; k11 = 230
.line	1371	loadk        r15   k12 ; k12 = 59
.line	1371	loadk        r16   k13 ; k13 = 143
.line	1371	loadk        r17   k14 ; k14 = 65
.line	1371	loadk        r18   k15 ; k15 = 214
.line	1371	loadk        r19   k16 ; k16 = 215
.line	1371	loadk        r20   k17 ; k17 = 194
.line	1371	loadk        r21   k18 ; k18 = 25
.line	1371	loadk        r22   k19 ; k19 = 110
.line	1371	loadk        r23   k20 ; k20 = 32
.line	1371	loadk        r24   k21 ; k21 = 107
.line	1371	loadk        r25   k22 ; k22 = 207
.line	1371	loadk        r26   k23 ; k23 = 196
.line	1371	loadk        r27   k24 ; k24 = 169
.line	1371	loadk        r28   k25 ; k25 = 87
.line	1371	loadk        r29   k26 ; k26 = 245
.line	1371	loadk        r30    k7 ; k7 = 38
.line	1371	loadk        r31   k12 ; k12 = 59
.line	1371	loadk        r32   k27 ; k27 = 247
.line	1371	loadk        r33   k28 ; k28 = 105
.line	1371	loadk        r34   k29 ; k29 = 137
.line	1371	loadk        r35   k30 ; k30 = 160
.line	1371	loadk        r36   k42 ; k42 = 227
.line	1371	loadk        r37   k51 ; k51 = 15
.line	1371	loadk        r38   k52 ; k52 = 85
.line	1371	loadk        r39   k53 ; k53 = 113
.line	1371	loadk        r40   k54 ; k54 = 97
.line	1371	loadk        r41   k55 ; k55 = 219
.line	1371	loadk        r42   k30 ; k30 = 160
.line	1371	loadk        r43   k56 ; k56 = 191
.line	1371	loadk        r44   k38 ; k38 = 64
.line	1371	loadk        r45   k57 ; k57 = 253
.line	1371	loadk        r46   k58 ; k58 = 115
.line	1371	loadk        r47   k89 ; k89 = 3
.line	1371	loadk        r48   k90 ; k90 = 231
.line	1371	loadk        r49   k91 ; k91 = 126
.line	1371	call          r9    41     2
.line	1371	getupval     r10    u1
.line	1371	loadk        r11   k92 ; k92 = 20
.line	1371	loadk        r12   k93 ; k93 = 216
.line	1371	loadk        r13   k94 ; k94 = 54
.line	1371	loadk        r14   k95 ; k95 = 204
.line	1371	loadk        r15   k96 ; k96 = 210
.line	1371	loadk        r16   k67 ; k67 = 60
.line	1371	loadk        r17   k29 ; k29 = 137
.line	1371	loadk        r18   k97 ; k97 = 67
.line	1371	loadk        r19   k93 ; k93 = 216
.line	1371	loadk        r20   k36 ; k36 = 226
.line	1371	loadk        r21   k98 ; k98 = 198
.line	1371	loadk        r22   k89 ; k89 = 3
.line	1371	loadk        r23   k25 ; k25 = 87
.line	1371	loadk        r24   k54 ; k54 = 97
.line	1371	loadk        r25   k53 ; k53 = 113
.line	1371	loadk        r26   k31 ; k31 = 197
.line	1371	loadk        r27   k99 ; k99 = 242
.line	1371	loadk        r28  k100 ; k100 = 164
.line	1371	loadk        r29   k76 ; k76 = 80
.line	1371	call         r10    20     0
.line	1371	setlist       r8     0     1
.line	1371	call          r7     2     2
.label	l255
.line	1371	call          r6     2     1
.line	1371	gettabup      r6    u0    k1 ; k1 = "FuncUtil"
.line	1371	gettable      r6    r6  k101 ; k101 = "GetRankTableData"
.line	1371	move          r7    r0
.line	1371	sub           r8    r3   k62 ; k62 = 1
.line	1371	loadbool      r9     1     0
.line	1371	tailcall      r6     4
.line	1371	return        r6     0
.label	l263
.line	1371	return        r5     2
.line	1371	return        r0     1
.line	1371	move          r0    r0
.line	1371	gettabup      r2    u1   k94 ; k94 = 54
.line	1371	return        r0     1

.function	main/f89

.source	null
.linedefined	1393
.lastlinedefined	1396
.numparams	3
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"FuncUtil"
.constant	k1	"GetSegmentCfgById"
.constant	k2	"Name"

.line	1393	gettabup      r3    u0    k0 ; k0 = "FuncUtil"
.line	1393	gettable      r3    r3    k1 ; k1 = "GetSegmentCfgById"
.line	1393	move          r4    r0
.line	1393	move          r5    r1
.line	1393	move          r6    r2
.line	1393	call          r3     4     2
.line	1393	test          r3     0
.line	1393	jmp            0   l12
.line	1393	gettable      r4    r3    k2 ; k2 = "Name"
.line	1393	test          r4     1
.line	1393	jmp            0   l14
.label	l12
.line	1393	getupval      r4    u1
.line	1393	call          r4     1     2
.label	l14
.line	1393	return        r4     2
.line	1393	return        r0     1
.line	1393	move          r0    r0
.line	1393	move          r0    r0
.line	1393	move          r0    r0
.line	1393	return        r0     1

.function	main/f90

.source	null
.linedefined	1398
.lastlinedefined	1408
.numparams	3
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	23	true
.upvalue	"U1"	25	true
.upvalue	"U2"	1	true
.upvalue	"U3"	0	false

.constant	k0	3
.constant	k1	148
.constant	k2	44
.constant	k3	204
.constant	k4	221
.constant	k5	59
.constant	k6	200
.constant	k7	65
.constant	k8	151
.constant	k9	247
.constant	k10	206
.constant	k11	14
.constant	k12	18
.constant	k13	17
.constant	k14	96
.constant	k15	197
.constant	k16	251
.constant	k17	143
.constant	k18	84
.constant	k19	244
.constant	k20	38
.constant	k21	81
.constant	k22	218
.constant	k23	114
.constant	k24	233
.constant	k25	212
.constant	k26	45
.constant	k27	73
.constant	k28	48
.constant	k29	126
.constant	k30	243
.constant	k31	225
.constant	k32	181
.constant	k33	64
.constant	k34	220
.constant	k35	39
.constant	k36	6
.constant	k37	234
.constant	k38	"GetPeakRankTableData"
.constant	k39	"FuncUtil"
.constant	k40	"GetRankTableData"
.constant	k41	"DataMgr"
.constant	k42	"season_id"

.line	1398	getupval      r3    u0
.line	1398	move          r4    r0
.line	1398	call          r3     2     2
.line	1398	test          r3     1
.line	1398	jmp            0    l8
.line	1398	loadnil       r4     0
.line	1398	return        r4     2
.label	l8
.line	1398	test          r1     0
.line	1398	jmp            0   l57
.line	1398	getupval      r4    u1
.line	1398	getupval      r5    u2
.line	1398	loadk         r6    k0 ; k0 = 3
.line	1398	loadk         r7    k1 ; k1 = 148
.line	1398	loadk         r8    k2 ; k2 = 44
.line	1398	loadk         r9    k3 ; k3 = 204
.line	1398	loadk        r10    k4 ; k4 = 221
.line	1398	loadk        r11    k5 ; k5 = 59
.line	1398	loadk        r12    k6 ; k6 = 200
.line	1398	loadk        r13    k7 ; k7 = 65
.line	1398	loadk        r14    k8 ; k8 = 151
.line	1398	loadk        r15    k9 ; k9 = 247
.line	1398	loadk        r16   k10 ; k10 = 206
.line	1398	loadk        r17   k11 ; k11 = 14
.line	1398	loadk        r18   k12 ; k12 = 18
.line	1398	loadk        r19   k13 ; k13 = 17
.line	1398	loadk        r20   k14 ; k14 = 96
.line	1398	loadk        r21   k15 ; k15 = 197
.line	1398	loadk        r22   k16 ; k16 = 251
.line	1398	loadk        r23   k17 ; k17 = 143
.line	1398	loadk        r24   k18 ; k18 = 84
.line	1398	loadk        r25   k19 ; k19 = 244
.line	1398	loadk        r26   k20 ; k20 = 38
.line	1398	loadk        r27   k21 ; k21 = 81
.line	1398	loadk        r28   k22 ; k22 = 218
.line	1398	loadk        r29   k23 ; k23 = 114
.line	1398	loadk        r30   k17 ; k17 = 143
.line	1398	loadk        r31   k24 ; k24 = 233
.line	1398	loadk        r32   k25 ; k25 = 212
.line	1398	loadk        r33   k26 ; k26 = 45
.line	1398	loadk        r34   k27 ; k27 = 73
.line	1398	loadk        r35   k28 ; k28 = 48
.line	1398	loadk        r36   k29 ; k29 = 126
.line	1398	loadk        r37   k30 ; k30 = 243
.line	1398	loadk        r38   k31 ; k31 = 225
.line	1398	loadk        r39   k32 ; k32 = 181
.line	1398	loadk        r40   k33 ; k33 = 64
.line	1398	loadk        r41   k34 ; k34 = 220
.line	1398	loadk        r42   k35 ; k35 = 39
.line	1398	loadk        r43   k36 ; k36 = 6
.line	1398	loadk        r44   k37 ; k37 = 234
.line	1398	call          r5    40     2
.line	1398	call          r4     2     2
.line	1398	gettable      r5    r4   k38 ; k38 = "GetPeakRankTableData"
.line	1398	move          r6    r3
.line	1398	tailcall      r5     2
.line	1398	return        r5     0
.label	l57
.line	1398	gettabup      r4    u3   k39 ; k39 = "FuncUtil"
.line	1398	gettable      r4    r4   k40 ; k40 = "GetRankTableData"
.line	1398	move          r5    r3
.line	1398	testset       r6    r2     1
.line	1398	jmp            0   l64
.line	1398	gettabup      r6    u3   k41 ; k41 = "DataMgr"
.line	1398	gettable      r6    r6   k42 ; k42 = "season_id"
.label	l64
.line	1398	tailcall      r4     3
.line	1398	return        r4     0
.line	1398	return        r0     1
.line	1398	move          r0    r0
.line	1398	move          r0    r0
.line	1398	return        r0     1

.function	main/f91

.source	null
.linedefined	1410
.lastlinedefined	1416
.numparams	1
.is_vararg	0
.maxstacksize	17

.upvalue	"_ENV"	27	true
.upvalue	"U1"	1	true

.constant	k0	"GetTableData"
.constant	k1	53
.constant	k2	191
.constant	k3	6
.constant	k4	250
.constant	k5	214
.constant	k6	40
.constant	k7	139
.constant	k8	72
.constant	k9	150
.constant	k10	228
.constant	k11	227
.constant	k12	12
.constant	k13	32

.line	1410	test          r0     1
.line	1410	jmp            0    l4
.line	1410	return        r0     1
.label	l4
.line	1410	gettabup      r1    u0    k0 ; k0 = "GetTableData"
.line	1410	getupval      r2    u1
.line	1410	loadk         r3    k1 ; k1 = 53
.line	1410	loadk         r4    k2 ; k2 = 191
.line	1410	loadk         r5    k3 ; k3 = 6
.line	1410	loadk         r6    k4 ; k4 = 250
.line	1410	loadk         r7    k5 ; k5 = 214
.line	1410	loadk         r8    k6 ; k6 = 40
.line	1410	loadk         r9    k7 ; k7 = 139
.line	1410	loadk        r10    k8 ; k8 = 72
.line	1410	loadk        r11    k9 ; k9 = 150
.line	1410	loadk        r12   k10 ; k10 = 228
.line	1410	loadk        r13   k11 ; k11 = 227
.line	1410	loadk        r14   k12 ; k12 = 12
.line	1410	loadk        r15    k8 ; k8 = 72
.line	1410	loadk        r16   k13 ; k13 = 32
.line	1410	call          r2    15     2
.line	1410	move          r3    r0
.line	1410	call          r1     3     2
.line	1410	return        r1     2
.line	1410	return        r0     1
.line	1410	move          r0    r0
.line	1410	move          r0    r0
.line	1410	move          r0    r0
.line	1410	return        r0     1

.function	main/f92

.source	null
.linedefined	1418
.lastlinedefined	1421
.numparams	0
.is_vararg	0
.maxstacksize	16

.upvalue	"_ENV"	27	true
.upvalue	"U1"	1	true

.constant	k0	"GetTable"
.constant	k1	53
.constant	k2	191
.constant	k3	6
.constant	k4	250
.constant	k5	214
.constant	k6	40
.constant	k7	139
.constant	k8	72
.constant	k9	150
.constant	k10	228
.constant	k11	227
.constant	k12	12
.constant	k13	32

.line	1418	gettabup      r0    u0    k0 ; k0 = "GetTable"
.line	1418	getupval      r1    u1
.line	1418	loadk         r2    k1 ; k1 = 53
.line	1418	loadk         r3    k2 ; k2 = 191
.line	1418	loadk         r4    k3 ; k3 = 6
.line	1418	loadk         r5    k4 ; k4 = 250
.line	1418	loadk         r6    k5 ; k5 = 214
.line	1418	loadk         r7    k6 ; k6 = 40
.line	1418	loadk         r8    k7 ; k7 = 139
.line	1418	loadk         r9    k8 ; k8 = 72
.line	1418	loadk        r10    k9 ; k9 = 150
.line	1418	loadk        r11   k10 ; k10 = 228
.line	1418	loadk        r12   k11 ; k11 = 227
.line	1418	loadk        r13   k12 ; k12 = 12
.line	1418	loadk        r14    k8 ; k8 = 72
.line	1418	loadk        r15   k13 ; k13 = 32
.line	1418	call          r1    15     2
.line	1418	call          r0     2     2
.line	1418	return        r0     2
.line	1418	return        r0     1
.line	1418	move          r0    r0
.line	1418	move          r0    r0
.line	1418	return        r0     1

.function	main/f93

.source	null
.linedefined	1423
.lastlinedefined	1429
.numparams	1
.is_vararg	0
.maxstacksize	17

.upvalue	"_ENV"	27	true
.upvalue	"U1"	1	true

.constant	k0	"GetTable"
.constant	k1	53
.constant	k2	191
.constant	k3	6
.constant	k4	250
.constant	k5	214
.constant	k6	40
.constant	k7	139
.constant	k8	72
.constant	k9	150
.constant	k10	228
.constant	k11	227
.constant	k12	12
.constant	k13	32
.constant	k14	"next_segment_score"

.line	1423	gettabup      r1    u0    k0 ; k0 = "GetTable"
.line	1423	getupval      r2    u1
.line	1423	loadk         r3    k1 ; k1 = 53
.line	1423	loadk         r4    k2 ; k2 = 191
.line	1423	loadk         r5    k3 ; k3 = 6
.line	1423	loadk         r6    k4 ; k4 = 250
.line	1423	loadk         r7    k5 ; k5 = 214
.line	1423	loadk         r8    k6 ; k6 = 40
.line	1423	loadk         r9    k7 ; k7 = 139
.line	1423	loadk        r10    k8 ; k8 = 72
.line	1423	loadk        r11    k9 ; k9 = 150
.line	1423	loadk        r12   k10 ; k10 = 228
.line	1423	loadk        r13   k11 ; k11 = 227
.line	1423	loadk        r14   k12 ; k12 = 12
.line	1423	loadk        r15    k8 ; k8 = 72
.line	1423	loadk        r16   k13 ; k13 = 32
.line	1423	call          r2    15     2
.line	1423	call          r1     2     2
.line	1423	lt             0    k3    r0 ; k3 = 6
.line	1423	jmp            0   l22
.line	1423	loadk         r0    k3 ; k3 = 6
.label	l22
.line	1423	gettable      r2    r1    r0
.line	1423	gettable      r2    r2   k14 ; k14 = "next_segment_score"
.line	1423	return        r2     2
.line	1423	return        r0     1
.line	1423	move          r0    r0
.line	1423	move          r0    r0
.line	1423	move          r0    r0
.line	1423	move          r0    r0
.line	1423	return        r0     1

.function	main/f94

.source	null
.linedefined	1431
.lastlinedefined	1438
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	27	true

.constant	k0	"FuncUtil"
.constant	k1	"GetRankTableName"
.constant	k2	"log"
.constant	k3	"bWriteLog"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	38
.constant	k7	141
.constant	k8	43
.constant	k9	202
.constant	k10	230
.constant	k11	59
.constant	k12	143
.constant	k13	65
.constant	k14	214
.constant	k15	215
.constant	k16	194
.constant	k17	25
.constant	k18	110
.constant	k19	32
.constant	k20	107
.constant	k21	207
.constant	k22	196
.constant	k23	169
.constant	k24	87
.constant	k25	245
.constant	k26	95
.constant	k27	228
.constant	k28	124
.constant	k29	134
.constant	k30	235
.constant	k31	227
.constant	k32	28
.constant	k33	78
.constant	k34	61
.constant	k35	112
.constant	k36	250
.constant	k37	225
.constant	k38	181
.constant	k39	64
.constant	k40	58
.constant	k41	166
.constant	k42	99
.constant	k43	9
.constant	k44	148
.constant	k45	100
.constant	k46	"GetTableByFilter"
.constant	k47	41
.constant	k48	139
.constant	k49	23
.constant	k50	200
.constant	k51	221
.constant	k52	36
.constant	k53	175
.constant	k54	67
.constant	k55	142
.constant	k56	241
.constant	k57	203
.constant	k58	4
.constant	k59	88

.line	1431	gettabup      r1    u0    k0 ; k0 = "FuncUtil"
.line	1431	gettable      r1    r1    k1 ; k1 = "GetRankTableName"
.line	1431	move          r2    r0
.line	1431	call          r1     2     2
.line	1431	test          r1     1
.line	1431	jmp            0   l66
.line	1431	gettabup      r2    u0    k2 ; k2 = "log"
.line	1431	gettabup      r3    u0    k3 ; k3 = "bWriteLog"
.line	1431	test          r3     0
.line	1431	jmp            0   l63
.line	1431	gettabup      r3    u0    k4 ; k4 = "table"
.line	1431	gettable      r3    r3    k5 ; k5 = "concat"
.line	1431	newtable      r4     1     0
.line	1431	getupval      r5    u1
.line	1431	loadk         r6    k6 ; k6 = 38
.line	1431	loadk         r7    k7 ; k7 = 141
.line	1431	loadk         r8    k8 ; k8 = 43
.line	1431	loadk         r9    k9 ; k9 = 202
.line	1431	loadk        r10   k10 ; k10 = 230
.line	1431	loadk        r11   k11 ; k11 = 59
.line	1431	loadk        r12   k12 ; k12 = 143
.line	1431	loadk        r13   k13 ; k13 = 65
.line	1431	loadk        r14   k14 ; k14 = 214
.line	1431	loadk        r15   k15 ; k15 = 215
.line	1431	loadk        r16   k16 ; k16 = 194
.line	1431	loadk        r17   k17 ; k17 = 25
.line	1431	loadk        r18   k18 ; k18 = 110
.line	1431	loadk        r19   k19 ; k19 = 32
.line	1431	loadk        r20   k20 ; k20 = 107
.line	1431	loadk        r21   k21 ; k21 = 207
.line	1431	loadk        r22   k22 ; k22 = 196
.line	1431	loadk        r23   k23 ; k23 = 169
.line	1431	loadk        r24   k24 ; k24 = 87
.line	1431	loadk        r25   k25 ; k25 = 245
.line	1431	loadk        r26    k6 ; k6 = 38
.line	1431	loadk        r27   k26 ; k26 = 95
.line	1431	loadk        r28   k27 ; k27 = 228
.line	1431	loadk        r29   k28 ; k28 = 124
.line	1431	loadk        r30   k29 ; k29 = 134
.line	1431	loadk        r31   k30 ; k30 = 235
.line	1431	loadk        r32   k31 ; k31 = 227
.line	1431	loadk        r33   k32 ; k32 = 28
.line	1431	loadk        r34   k33 ; k33 = 78
.line	1431	loadk        r35   k34 ; k34 = 61
.line	1431	loadk        r36   k35 ; k35 = 112
.line	1431	loadk        r37   k36 ; k36 = 250
.line	1431	loadk        r38   k37 ; k37 = 225
.line	1431	loadk        r39   k38 ; k38 = 181
.line	1431	loadk        r40   k39 ; k39 = 64
.line	1431	loadk        r41   k23 ; k23 = 169
.line	1431	loadk        r42   k40 ; k40 = 58
.line	1431	loadk        r43   k32 ; k32 = 28
.line	1431	loadk        r44   k41 ; k41 = 166
.line	1431	loadk        r45   k42 ; k42 = 99
.line	1431	call          r5    41     2
.line	1431	getupval      r6    u1
.line	1431	loadk         r7   k43 ; k43 = 9
.line	1431	loadk         r8   k44 ; k44 = 148
.line	1431	loadk         r9   k45 ; k45 = 100
.line	1431	call          r6     4     0
.line	1431	setlist       r4     0     1
.line	1431	call          r3     2     2
.label	l63
.line	1431	call          r2     2     1
.line	1431	newtable      r2     0     0
.line	1431	return        r2     2
.label	l66
.line	1431	gettabup      r2    u2   k46 ; k46 = "GetTableByFilter"
.line	1431	move          r3    r1
.line	1431	getupval      r4    u1
.line	1431	loadk         r5   k47 ; k47 = 41
.line	1431	loadk         r6   k48 ; k48 = 139
.line	1431	loadk         r7   k49 ; k49 = 23
.line	1431	loadk         r8   k50 ; k50 = 200
.line	1431	loadk         r9   k51 ; k51 = 221
.line	1431	loadk        r10   k52 ; k52 = 36
.line	1431	loadk        r11   k53 ; k53 = 175
.line	1431	loadk        r12   k54 ; k54 = 67
.line	1431	loadk        r13   k55 ; k55 = 142
.line	1431	loadk        r14   k56 ; k56 = 241
.line	1431	loadk        r15   k57 ; k57 = 203
.line	1431	loadk        r16   k58 ; k58 = 4
.line	1431	loadk        r17   k59 ; k59 = 88
.line	1431	call          r4    14     2
.line	1431	loadbool      r5     0     0
.line	1431	tailcall      r2     4
.line	1431	return        r2     0
.line	1431	return        r0     1
.line	1431	move          r0    r0
.line	1431	gettabup      r0    u0   k43 ; k43 = 9
.line	1431	gettabup      r1    u0   k33 ; k33 = 78
.line	1431	move          r0    r0
.line	1431	return        r0     1

.function	main/f95

.source	null
.linedefined	1440
.lastlinedefined	1453
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	27	true
.upvalue	"U2"	1	true

.constant	k0	0
.constant	k1	"DataMgr"
.constant	k2	"season_id"
.constant	k3	-1
.constant	k4	1
.constant	k5	"GetTableData"
.constant	k6	51
.constant	k7	157
.constant	k8	36
.constant	k9	218
.constant	k10	220
.constant	k11	33
.constant	k12	175
.constant	k13	67
.constant	k14	158
.constant	k15	255
.constant	k16	"log"
.constant	k17	"bWriteLog"
.constant	k18	"table"
.constant	k19	"concat"
.constant	k20	38
.constant	k21	141
.constant	k22	43
.constant	k23	202
.constant	k24	230
.constant	k25	59
.constant	k26	143
.constant	k27	65
.constant	k28	214
.constant	k29	215
.constant	k30	194
.constant	k31	25
.constant	k32	110
.constant	k33	32
.constant	k34	107
.constant	k35	207
.constant	k36	196
.constant	k37	169
.constant	k38	87
.constant	k39	245
.constant	k40	49
.constant	k41	247
.constant	k42	112
.constant	k43	160
.constant	k44	228
.constant	k45	24
.constant	k46	95
.constant	k47	48
.constant	k48	122
.constant	k49	195
.constant	k50	183
.constant	k51	75
.constant	k52	239
.constant	k53	58
.constant	k54	8
.constant	k55	166
.constant	k56	100
.constant	k57	19
.constant	k58	216
.constant	k59	192
.constant	k60	223
.constant	k61	"RankTableName"

.line	1440	testset       r1    r0     1
.line	1440	jmp            0    l4
.line	1440	loadk         r1    k0 ; k0 = 0
.label	l4
.line	1440	eq             0    r1    k0 ; k0 = 0
.line	1440	jmp            0    l9
.line	1440	gettabup      r2    u0    k1 ; k1 = "DataMgr"
.line	1440	gettable      r1    r2    k2 ; k2 = "season_id"
.line	1440	jmp            0   l14
.label	l9
.line	1440	eq             0    r1    k3 ; k3 = -1
.line	1440	jmp            0   l14
.line	1440	gettabup      r2    u0    k1 ; k1 = "DataMgr"
.line	1440	gettable      r2    r2    k2 ; k2 = "season_id"
.line	1440	sub           r1    r2    k4 ; k4 = 1
.label	l14
.line	1440	gettabup      r2    u1    k5 ; k5 = "GetTableData"
.line	1440	getupval      r3    u2
.line	1440	loadk         r4    k6 ; k6 = 51
.line	1440	loadk         r5    k7 ; k7 = 157
.line	1440	loadk         r6    k8 ; k8 = 36
.line	1440	loadk         r7    k9 ; k9 = 218
.line	1440	loadk         r8   k10 ; k10 = 220
.line	1440	loadk         r9   k11 ; k11 = 33
.line	1440	loadk        r10   k12 ; k12 = 175
.line	1440	loadk        r11   k13 ; k13 = 67
.line	1440	loadk        r12   k14 ; k14 = 158
.line	1440	loadk        r13   k15 ; k15 = 255
.line	1440	call          r3    11     2
.line	1440	move          r4    r1
.line	1440	call          r2     3     2
.line	1440	test          r2     1
.line	1440	jmp            0   l92
.line	1440	gettabup      r3    u0   k16 ; k16 = "log"
.line	1440	gettabup      r4    u0   k17 ; k17 = "bWriteLog"
.line	1440	test          r4     0
.line	1440	jmp            0   l90
.line	1440	gettabup      r4    u0   k18 ; k18 = "table"
.line	1440	gettable      r4    r4   k19 ; k19 = "concat"
.line	1440	newtable      r5     1     0
.line	1440	getupval      r6    u2
.line	1440	loadk         r7   k20 ; k20 = 38
.line	1440	loadk         r8   k21 ; k21 = 141
.line	1440	loadk         r9   k22 ; k22 = 43
.line	1440	loadk        r10   k23 ; k23 = 202
.line	1440	loadk        r11   k24 ; k24 = 230
.line	1440	loadk        r12   k25 ; k25 = 59
.line	1440	loadk        r13   k26 ; k26 = 143
.line	1440	loadk        r14   k27 ; k27 = 65
.line	1440	loadk        r15   k28 ; k28 = 214
.line	1440	loadk        r16   k29 ; k29 = 215
.line	1440	loadk        r17   k30 ; k30 = 194
.line	1440	loadk        r18   k31 ; k31 = 25
.line	1440	loadk        r19   k32 ; k32 = 110
.line	1440	loadk        r20   k33 ; k33 = 32
.line	1440	loadk        r21   k34 ; k34 = 107
.line	1440	loadk        r22   k35 ; k35 = 207
.line	1440	loadk        r23   k36 ; k36 = 196
.line	1440	loadk        r24   k37 ; k37 = 169
.line	1440	loadk        r25   k38 ; k38 = 87
.line	1440	loadk        r26   k39 ; k39 = 245
.line	1440	loadk        r27   k20 ; k20 = 38
.line	1440	loadk        r28   k40 ; k40 = 49
.line	1440	loadk        r29   k41 ; k41 = 247
.line	1440	loadk        r30   k42 ; k42 = 112
.line	1440	loadk        r31   k21 ; k21 = 141
.line	1440	loadk        r32   k43 ; k43 = 160
.line	1440	loadk        r33   k44 ; k44 = 228
.line	1440	loadk        r34   k45 ; k45 = 24
.line	1440	loadk        r35   k46 ; k46 = 95
.line	1440	loadk        r36   k47 ; k47 = 48
.line	1440	loadk        r37   k48 ; k48 = 122
.line	1440	loadk        r38    k9 ; k9 = 218
.line	1440	loadk        r39   k49 ; k49 = 195
.line	1440	loadk        r40   k50 ; k50 = 183
.line	1440	loadk        r41   k51 ; k51 = 75
.line	1440	loadk        r42   k52 ; k52 = 239
.line	1440	loadk        r43   k53 ; k53 = 58
.line	1440	loadk        r44   k54 ; k54 = 8
.line	1440	loadk        r45   k55 ; k55 = 166
.line	1440	loadk        r46   k56 ; k56 = 100
.line	1440	call          r6    41     2
.line	1440	getupval      r7    u2
.line	1440	loadk         r8   k57 ; k57 = 19
.line	1440	loadk         r9   k58 ; k58 = 216
.line	1440	loadk        r10   k22 ; k22 = 43
.line	1440	loadk        r11   k59 ; k59 = 192
.line	1440	loadk        r12   k60 ; k60 = 223
.line	1440	loadk        r13   k32 ; k32 = 110
.line	1440	call          r7     7     0
.line	1440	setlist       r5     0     1
.line	1440	call          r4     2     2
.label	l90
.line	1440	call          r3     2     1
.line	1440	return        r0     1
.label	l92
.line	1440	gettable      r3    r2   k61 ; k61 = "RankTableName"
.line	1440	return        r3     2
.line	1440	return        r0     1
.line	1440	gettabup      r0    u0   k57 ; k57 = 19
.line	1440	move          r0    r0
.line	1440	move          r0    r0
.line	1440	move          r0    r0
.line	1440	return        r0     1

.function	main/f96

.source	null
.linedefined	1455
.lastlinedefined	1463
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	24	true
.upvalue	"U3"	25	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	64
.constant	k3	216
.constant	k4	127
.constant	k5	137
.constant	k6	249
.constant	k7	58
.constant	k8	139
.constant	k9	93
.constant	k10	185
.constant	k11	224
.constant	k12	215
.constant	k13	62
.constant	k14	72
.constant	k15	46
.constant	k16	119
.constant	k17	193
.constant	k18	176
.constant	k19	189
.constant	k20	71
.constant	k21	245
.constant	k22	99
.constant	k23	"table"
.constant	k24	"concat"
.constant	k25	3
.constant	k26	148
.constant	k27	44
.constant	k28	204
.constant	k29	221
.constant	k30	59
.constant	k31	200
.constant	k32	94
.constant	k33	229
.constant	k34	198
.constant	k35	67
.constant	k36	95
.constant	k37	107
.constant	k38	194
.constant	k39	175
.constant	k40	27
.constant	k41	218
.constant	k42	47
.constant	k43	22
.constant	k44	243
.constant	k45	115
.constant	k46	156
.constant	k47	205
.constant	k48	214
.constant	k49	30
.constant	k50	102
.constant	k51	154
.constant	k52	196
.constant	k53	83
.constant	k54	48
.constant	k55	10
.constant	k56	97
.constant	k57	1
.constant	k58	140
.constant	k59	35
.constant	k60	34
.constant	k61	168
.constant	k62	76
.constant	k63	149
.constant	k64	234
.constant	k65	12
.constant	k66	51
.constant	k67	106
.constant	k68	"Client"
.constant	k69	"GetDevicePlatformName"
.constant	k70	"IOS"
.constant	k71	"OpenURLInSDK"
.constant	k72	133
.constant	k73	"LaunchUrl"

.line	1455	gettabup      r1    u0    k0 ; k0 = "log"
.line	1455	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1455	test          r2     0
.line	1455	jmp            0   l32
.line	1455	getupval      r2    u1
.line	1455	loadk         r3    k2 ; k2 = 64
.line	1455	loadk         r4    k3 ; k3 = 216
.line	1455	loadk         r5    k4 ; k4 = 127
.line	1455	loadk         r6    k5 ; k5 = 137
.line	1455	loadk         r7    k6 ; k6 = 249
.line	1455	loadk         r8    k7 ; k7 = 58
.line	1455	loadk         r9    k8 ; k8 = 139
.line	1455	loadk        r10    k9 ; k9 = 93
.line	1455	loadk        r11   k10 ; k10 = 185
.line	1455	loadk        r12   k11 ; k11 = 224
.line	1455	loadk        r13   k12 ; k12 = 215
.line	1455	loadk        r14   k13 ; k13 = 62
.line	1455	loadk        r15   k14 ; k14 = 72
.line	1455	loadk        r16   k15 ; k15 = 46
.line	1455	loadk        r17   k16 ; k16 = 119
.line	1455	loadk        r18   k17 ; k17 = 193
.line	1455	loadk        r19   k18 ; k18 = 176
.line	1455	loadk        r20   k19 ; k19 = 189
.line	1455	loadk        r21   k20 ; k20 = 71
.line	1455	loadk        r22   k21 ; k21 = 245
.line	1455	loadk        r23   k22 ; k22 = 99
.line	1455	call          r2    22     2
.line	1455	getupval      r3    u2
.line	1455	move          r4    r0
.line	1455	call          r3     2     2
.line	1455	concat        r2    r2    r3
.label	l32
.line	1455	call          r1     2     1
.line	1455	getupval      r1    u3
.line	1455	gettabup      r2    u0   k23 ; k23 = "table"
.line	1455	gettable      r2    r2   k24 ; k24 = "concat"
.line	1455	newtable      r3     1     0
.line	1455	getupval      r4    u1
.line	1455	loadk         r5   k25 ; k25 = 3
.line	1455	loadk         r6   k26 ; k26 = 148
.line	1455	loadk         r7   k27 ; k27 = 44
.line	1455	loadk         r8   k28 ; k28 = 204
.line	1455	loadk         r9   k29 ; k29 = 221
.line	1455	loadk        r10   k30 ; k30 = 59
.line	1455	loadk        r11   k31 ; k31 = 200
.line	1455	loadk        r12   k32 ; k32 = 94
.line	1455	loadk        r13   k26 ; k26 = 148
.line	1455	loadk        r14   k33 ; k33 = 229
.line	1455	loadk        r15   k34 ; k34 = 198
.line	1455	loadk        r16   k35 ; k35 = 67
.line	1455	loadk        r17   k36 ; k36 = 95
.line	1455	loadk        r18   k15 ; k15 = 46
.line	1455	loadk        r19   k37 ; k37 = 107
.line	1455	loadk        r20   k38 ; k38 = 194
.line	1455	loadk        r21    k6 ; k6 = 249
.line	1455	loadk        r22   k39 ; k39 = 175
.line	1455	loadk        r23   k40 ; k40 = 27
.line	1455	loadk        r24   k41 ; k41 = 218
.line	1455	loadk        r25   k42 ; k42 = 47
.line	1455	loadk        r26   k43 ; k43 = 22
.line	1455	loadk        r27   k44 ; k44 = 243
.line	1455	loadk        r28   k45 ; k45 = 115
.line	1455	loadk        r29   k46 ; k46 = 156
.line	1455	loadk        r30   k47 ; k47 = 205
.line	1455	loadk        r31   k48 ; k48 = 214
.line	1455	loadk        r32   k49 ; k49 = 30
.line	1455	loadk        r33   k32 ; k32 = 94
.line	1455	loadk        r34   k13 ; k13 = 62
.line	1455	loadk        r35   k50 ; k50 = 102
.line	1455	loadk        r36   k51 ; k51 = 154
.line	1455	loadk        r37   k52 ; k52 = 196
.line	1455	loadk        r38   k19 ; k19 = 189
.line	1455	loadk        r39   k53 ; k53 = 83
.line	1455	loadk        r40   k11 ; k11 = 224
.line	1455	loadk        r41   k54 ; k54 = 48
.line	1455	loadk        r42   k55 ; k55 = 10
.line	1455	loadk        r43   k48 ; k48 = 214
.line	1455	loadk        r44   k56 ; k56 = 97
.line	1455	call          r4    41     2
.line	1455	getupval      r5    u1
.line	1455	loadk         r6   k57 ; k57 = 1
.line	1455	loadk         r7   k58 ; k58 = 140
.line	1455	loadk         r8   k59 ; k59 = 35
.line	1455	loadk         r9   k34 ; k34 = 198
.line	1455	loadk        r10   k17 ; k17 = 193
.line	1455	loadk        r11   k60 ; k60 = 34
.line	1455	loadk        r12   k61 ; k61 = 168
.line	1455	loadk        r13   k62 ; k62 = 76
.line	1455	loadk        r14   k63 ; k63 = 149
.line	1455	loadk        r15   k21 ; k21 = 245
.line	1455	loadk        r16   k64 ; k64 = 234
.line	1455	loadk        r17   k65 ; k65 = 12
.line	1455	loadk        r18   k36 ; k36 = 95
.line	1455	loadk        r19   k66 ; k66 = 51
.line	1455	loadk        r20   k67 ; k67 = 106
.line	1455	loadk        r21   k12 ; k12 = 215
.line	1455	call          r5    17     0
.line	1455	setlist       r3     0     1
.line	1455	call          r2     2     2
.line	1455	call          r1     2     2
.line	1455	gettabup      r2    u0   k68 ; k68 = "Client"
.line	1455	gettable      r2    r2   k69 ; k69 = "GetDevicePlatformNam" (truncated)
.line	1455	call          r2     1     2
.line	1455	gettable      r3    r1   k70 ; k70 = "IOS"
.line	1455	eq             0    r2    r3
.line	1455	jmp            0  l118
.line	1455	gettabup      r2    u0   k68 ; k68 = "Client"
.line	1455	gettable      r2    r2   k71 ; k71 = "OpenURLInSDK"
.line	1455	move          r3    r0
.line	1455	loadbool      r4     0     0
.line	1455	loadbool      r5     1     0
.line	1455	loadbool      r6     0     0
.line	1455	getupval      r7    u1
.line	1455	loadk         r8   k40 ; k40 = 27
.line	1455	loadk         r9   k72 ; k72 = 133
.line	1455	call          r7     3     2
.line	1455	call          r2     6     1
.line	1455	jmp            0  l122
.label	l118
.line	1455	gettabup      r2    u0   k68 ; k68 = "Client"
.line	1455	gettable      r2    r2   k73 ; k73 = "LaunchUrl"
.line	1455	move          r3    r0
.line	1455	call          r2     2     1
.label	l122
.line	1455	return        r0     1
.line	1455	move          r0    r0
.line	1455	move          r0    r0
.line	1455	move          r0    r0
.line	1455	move          r0    r0
.line	1455	return        r0     1

.function	main/f97

.source	null
.linedefined	1465
.lastlinedefined	1476
.numparams	0
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	25	true
.upvalue	"U2"	1	true
.upvalue	"U3"	24	true
.upvalue	"U4"	46	true

.constant	k0	"LobbySystem"
.constant	k1	"CloseOtherMenu"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	3
.constant	k5	148
.constant	k6	44
.constant	k7	204
.constant	k8	221
.constant	k9	59
.constant	k10	200
.constant	k11	94
.constant	k12	229
.constant	k13	198
.constant	k14	67
.constant	k15	73
.constant	k16	98
.constant	k17	138
.constant	k18	222
.constant	k19	173
.constant	k20	66
.constant	k21	51
.constant	k22	27
.constant	k23	247
.constant	k24	105
.constant	k25	141
.constant	k26	174
.constant	k27	211
.constant	k28	18
.constant	k29	64
.constant	k30	33
.constant	k31	125
.constant	k32	238
.constant	k33	135
.constant	k34	80
.constant	k35	249
.constant	k36	55
.constant	k37	14
.constant	k38	242
.constant	k39	104
.constant	k40	167
.constant	k41	38
.constant	k42	41
.constant	k43	143
.constant	k44	74
.constant	k45	"GetAppStoreUrl"
.constant	k46	"log"
.constant	k47	"bWriteLog"
.constant	k48	43
.constant	k49	202
.constant	k50	230
.constant	k51	65
.constant	k52	214
.constant	k53	218
.constant	k54	210
.constant	k55	0
.constant	k56	76
.constant	k57	21
.constant	k58	106
.constant	k59	224
.constant	k60	255
.constant	k61	191
.constant	k62	91
.constant	k63	245
.constant	k64	30
.constant	k65	92
.constant	k66	152
.constant	k67	240
.constant	k68	151
.constant	k69	8
.constant	k70	61
.constant	k71	53
.constant	k72	137
.constant	k73	160
.constant	k74	"Client"
.constant	k75	"GetDevicePlatformName"
.constant	k76	172
.constant	k77	4
.constant	k78	114
.constant	k79	219
.constant	k80	16
.constant	k81	190
.constant	k82	201
.constant	k83	108
.constant	k84	130
.constant	k85	244
.constant	k86	89
.constant	k87	217
.constant	k88	17
.constant	k89	48
.constant	k90	113
.constant	k91	168
.constant	k92	5
.constant	k93	236
.constant	k94	62
.constant	k95	31
.constant	k96	116
.constant	k97	197
.constant	k98	159
.constant	k99	111
.constant	k100	150
.constant	k101	153
.constant	k102	228
.constant	k103	193
.constant	k104	2
.constant	k105	78
.constant	k106	63
.constant	k107	132

.line	1465	gettabup      r0    u0    k0 ; k0 = "LobbySystem"
.line	1465	gettable      r0    r0    k1 ; k1 = "CloseOtherMenu"
.line	1465	call          r0     1     1
.line	1465	getupval      r0    u1
.line	1465	gettabup      r1    u0    k2 ; k2 = "table"
.line	1465	gettable      r1    r1    k3 ; k3 = "concat"
.line	1465	newtable      r2     1     0
.line	1465	getupval      r3    u2
.line	1465	loadk         r4    k4 ; k4 = 3
.line	1465	loadk         r5    k5 ; k5 = 148
.line	1465	loadk         r6    k6 ; k6 = 44
.line	1465	loadk         r7    k7 ; k7 = 204
.line	1465	loadk         r8    k8 ; k8 = 221
.line	1465	loadk         r9    k9 ; k9 = 59
.line	1465	loadk        r10   k10 ; k10 = 200
.line	1465	loadk        r11   k11 ; k11 = 94
.line	1465	loadk        r12    k5 ; k5 = 148
.line	1465	loadk        r13   k12 ; k12 = 229
.line	1465	loadk        r14   k13 ; k13 = 198
.line	1465	loadk        r15   k14 ; k14 = 67
.line	1465	loadk        r16   k15 ; k15 = 73
.line	1465	loadk        r17    k6 ; k6 = 44
.line	1465	loadk        r18   k16 ; k16 = 98
.line	1465	loadk        r19   k17 ; k17 = 138
.line	1465	loadk        r20   k18 ; k18 = 222
.line	1465	loadk        r21   k19 ; k19 = 173
.line	1465	loadk        r22   k20 ; k20 = 66
.line	1465	loadk        r23    k7 ; k7 = 204
.line	1465	loadk        r24   k21 ; k21 = 51
.line	1465	loadk        r25   k22 ; k22 = 27
.line	1465	loadk        r26   k23 ; k23 = 247
.line	1465	loadk        r27   k24 ; k24 = 105
.line	1465	loadk        r28   k25 ; k25 = 141
.line	1465	loadk        r29   k26 ; k26 = 174
.line	1465	loadk        r30   k27 ; k27 = 211
.line	1465	loadk        r31   k28 ; k28 = 18
.line	1465	loadk        r32   k29 ; k29 = 64
.line	1465	loadk        r33   k30 ; k30 = 33
.line	1465	loadk        r34   k31 ; k31 = 125
.line	1465	loadk        r35    k8 ; k8 = 221
.line	1465	loadk        r36   k32 ; k32 = 238
.line	1465	loadk        r37   k33 ; k33 = 135
.line	1465	loadk        r38   k34 ; k34 = 80
.line	1465	loadk        r39   k35 ; k35 = 249
.line	1465	loadk        r40   k36 ; k36 = 55
.line	1465	loadk        r41   k37 ; k37 = 14
.line	1465	loadk        r42   k38 ; k38 = 242
.line	1465	loadk        r43   k39 ; k39 = 104
.line	1465	call          r3    41     2
.line	1465	getupval      r4    u2
.line	1465	loadk         r5   k28 ; k28 = 18
.line	1465	loadk         r6   k40 ; k40 = 167
.line	1465	loadk         r7   k41 ; k41 = 38
.line	1465	loadk         r8   k13 ; k13 = 198
.line	1465	loadk         r9    k8 ; k8 = 221
.line	1465	loadk        r10   k42 ; k42 = 41
.line	1465	loadk        r11   k43 ; k43 = 143
.line	1465	loadk        r12   k44 ; k44 = 74
.line	1465	call          r4     9     0
.line	1465	setlist       r2     0     1
.line	1465	call          r1     2     2
.line	1465	call          r0     2     2
.line	1465	self          r1    r0   k45 ; k45 = "GetAppStoreUrl"
.line	1465	call          r1     2     2
.line	1465	gettabup      r2    u0   k46 ; k46 = "log"
.line	1465	gettabup      r3    u0   k47 ; k47 = "bWriteLog"
.line	1465	test          r3     0
.line	1465	jmp            0  l108
.line	1465	getupval      r3    u2
.line	1465	loadk         r4   k41 ; k41 = 38
.line	1465	loadk         r5   k25 ; k25 = 141
.line	1465	loadk         r6   k48 ; k48 = 43
.line	1465	loadk         r7   k49 ; k49 = 202
.line	1465	loadk         r8   k50 ; k50 = 230
.line	1465	loadk         r9    k9 ; k9 = 59
.line	1465	loadk        r10   k43 ; k43 = 143
.line	1465	loadk        r11   k51 ; k51 = 65
.line	1465	loadk        r12   k52 ; k52 = 214
.line	1465	loadk        r13   k53 ; k53 = 218
.line	1465	loadk        r14   k54 ; k54 = 210
.line	1465	loadk        r15   k55 ; k55 = 0
.line	1465	loadk        r16   k56 ; k56 = 76
.line	1465	loadk        r17   k57 ; k57 = 21
.line	1465	loadk        r18   k58 ; k58 = 106
.line	1465	loadk        r19   k59 ; k59 = 224
.line	1465	loadk        r20   k60 ; k60 = 255
.line	1465	loadk        r21   k61 ; k61 = 191
.line	1465	loadk        r22   k62 ; k62 = 91
.line	1465	loadk        r23   k63 ; k63 = 245
.line	1465	loadk        r24    k6 ; k6 = 44
.line	1465	loadk        r25   k64 ; k64 = 30
.line	1465	loadk        r26   k38 ; k38 = 242
.line	1465	loadk        r27   k65 ; k65 = 92
.line	1465	loadk        r28   k66 ; k66 = 152
.line	1465	loadk        r29   k67 ; k67 = 240
.line	1465	loadk        r30   k68 ; k68 = 151
.line	1465	loadk        r31   k69 ; k69 = 8
.line	1465	loadk        r32   k11 ; k11 = 94
.line	1465	loadk        r33   k70 ; k70 = 61
.line	1465	loadk        r34   k71 ; k71 = 53
.line	1465	loadk        r35   k72 ; k72 = 137
.line	1465	loadk        r36   k73 ; k73 = 160
.line	1465	call          r3    34     2
.line	1465	getupval      r4    u3
.line	1465	move          r5    r1
.line	1465	call          r4     2     2
.line	1465	concat        r3    r3    r4
.label	l108
.line	1465	call          r2     2     1
.line	1465	test          r1     0
.line	1465	jmp            0  l115
.line	1465	getupval      r2    u2
.line	1465	call          r2     1     2
.line	1465	eq             0    r1    r2
.line	1465	jmp            0  l193
.label	l115
.line	1465	gettabup      r2    u0   k74 ; k74 = "Client"
.line	1465	gettable      r2    r2   k75 ; k75 = "GetDevicePlatformNam" (truncated)
.line	1465	call          r2     1     2
.line	1465	gettabup      r3    u0   k46 ; k46 = "log"
.line	1465	gettabup      r4    u0   k47 ; k47 = "bWriteLog"
.line	1465	test          r4     0
.line	1465	jmp            0  l191
.line	1465	gettabup      r4    u0    k2 ; k2 = "table"
.line	1465	gettable      r4    r4    k3 ; k3 = "concat"
.line	1465	newtable      r5     1     0
.line	1465	getupval      r6    u2
.line	1465	loadk         r7    k9 ; k9 = 59
.line	1465	loadk         r8   k76 ; k76 = 172
.line	1465	loadk         r9   k77 ; k77 = 4
.line	1465	loadk        r10   k12 ; k12 = 229
.line	1465	loadk        r11   k32 ; k32 = 238
.line	1465	loadk        r12   k78 ; k78 = 114
.line	1465	loadk        r13   k79 ; k79 = 219
.line	1465	loadk        r14   k80 ; k80 = 16
.line	1465	loadk        r15   k81 ; k81 = 190
.line	1465	loadk        r16   k12 ; k12 = 229
.line	1465	loadk        r17   k82 ; k82 = 201
.line	1465	loadk        r18   k37 ; k37 = 14
.line	1465	loadk        r19   k24 ; k24 = 105
.line	1465	loadk        r20   k71 ; k71 = 53
.line	1465	loadk        r21   k83 ; k83 = 108
.line	1465	loadk        r22   k10 ; k10 = 200
.line	1465	loadk        r23   k81 ; k81 = 190
.line	1465	loadk        r24   k84 ; k84 = 130
.line	1465	loadk        r25   k29 ; k29 = 64
.line	1465	loadk        r26   k85 ; k85 = 244
.line	1465	loadk        r27   k21 ; k21 = 51
.line	1465	loadk        r28   k48 ; k48 = 43
.line	1465	loadk        r29   k35 ; k35 = 249
.line	1465	loadk        r30   k86 ; k86 = 89
.line	1465	loadk        r31   k33 ; k33 = 135
.line	1465	loadk        r32   k23 ; k23 = 247
.line	1465	loadk        r33   k87 ; k87 = 217
.line	1465	loadk        r34   k88 ; k88 = 17
.line	1465	loadk        r35   k14 ; k14 = 67
.line	1465	loadk        r36   k89 ; k89 = 48
.line	1465	loadk        r37   k90 ; k90 = 113
.line	1465	loadk        r38   k63 ; k63 = 245
.line	1465	loadk        r39   k67 ; k67 = 240
.line	1465	loadk        r40   k91 ; k91 = 168
.line	1465	loadk        r41   k92 ; k92 = 5
.line	1465	loadk        r42   k93 ; k93 = 236
.line	1465	loadk        r43   k94 ; k94 = 62
.line	1465	loadk        r44   k95 ; k95 = 31
.line	1465	loadk        r45   k38 ; k38 = 242
.line	1465	loadk        r46   k96 ; k96 = 116
.line	1465	call          r6    41     2
.line	1465	getupval      r7    u2
.line	1465	loadk         r8   k29 ; k29 = 64
.line	1465	loadk         r9   k25 ; k25 = 141
.line	1465	loadk        r10   k36 ; k36 = 55
.line	1465	loadk        r11   k97 ; k97 = 197
.line	1465	loadk        r12   k98 ; k98 = 159
.line	1465	loadk        r13   k99 ; k99 = 111
.line	1465	loadk        r14  k100 ; k100 = 150
.line	1465	loadk        r15   k51 ; k51 = 65
.line	1465	loadk        r16  k101 ; k101 = 153
.line	1465	loadk        r17  k102 ; k102 = 228
.line	1465	loadk        r18  k103 ; k103 = 193
.line	1465	loadk        r19  k104 ; k104 = 2
.line	1465	loadk        r20  k105 ; k105 = 78
.line	1465	loadk        r21    k6 ; k6 = 44
.line	1465	loadk        r22  k106 ; k106 = 63
.line	1465	loadk        r23  k107 ; k107 = 132
.line	1465	call          r7    17     0
.line	1465	setlist       r5     0     1
.line	1465	call          r4     2     2
.line	1465	getupval      r5    u3
.line	1465	move          r6    r2
.line	1465	call          r5     2     2
.line	1465	concat        r4    r4    r5
.label	l191
.line	1465	call          r3     2     1
.line	1465	return        r0     1
.label	l193
.line	1465	getupval      r2    u4
.line	1465	move          r3    r1
.line	1465	call          r2     2     1
.line	1465	return        r0     1
.line	1465	move          r0    r0
.line	1465	move          r0    r0
.line	1465	move          r0    r0
.line	1465	return        r0     1

.function	main/f98

.source	null
.linedefined	1478
.lastlinedefined	1482
.numparams	1
.is_vararg	0
.maxstacksize	36

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	24	true
.upvalue	"U3"	25	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	38
.constant	k3	141
.constant	k4	43
.constant	k5	202
.constant	k6	230
.constant	k7	59
.constant	k8	143
.constant	k9	65
.constant	k10	214
.constant	k11	215
.constant	k12	194
.constant	k13	25
.constant	k14	112
.constant	k15	35
.constant	k16	118
.constant	k17	229
.constant	k18	226
.constant	k19	173
.constant	k20	84
.constant	k21	34
.constant	k22	18
.constant	k23	243
.constant	k24	61
.constant	k25	154
.constant	k26	225
.constant	k27	217
.constant	k28	22
.constant	k29	72
.constant	k30	14
.constant	k31	124
.constant	k32	208
.constant	k33	186
.constant	k34	3
.constant	k35	148
.constant	k36	44
.constant	k37	204
.constant	k38	221
.constant	k39	200
.constant	k40	94
.constant	k41	198
.constant	k42	67
.constant	k43	80
.constant	k44	46
.constant	k45	98
.constant	k46	205
.constant	k47	89
.constant	k48	251
.constant	k49	48
.constant	k50	81
.constant	k51	250
.constant	k52	114
.constant	k53	233
.constant	k54	212
.constant	k55	64
.constant	k56	51
.constant	k57	102
.constant	k58	"GetZoneName"

.line	1478	gettabup      r1    u0    k0 ; k0 = "log"
.line	1478	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1478	test          r2     0
.line	1478	jmp            0   l44
.line	1478	getupval      r2    u1
.line	1478	loadk         r3    k2 ; k2 = 38
.line	1478	loadk         r4    k3 ; k3 = 141
.line	1478	loadk         r5    k4 ; k4 = 43
.line	1478	loadk         r6    k5 ; k5 = 202
.line	1478	loadk         r7    k6 ; k6 = 230
.line	1478	loadk         r8    k7 ; k7 = 59
.line	1478	loadk         r9    k8 ; k8 = 143
.line	1478	loadk        r10    k9 ; k9 = 65
.line	1478	loadk        r11   k10 ; k10 = 214
.line	1478	loadk        r12   k11 ; k11 = 215
.line	1478	loadk        r13   k12 ; k12 = 194
.line	1478	loadk        r14   k13 ; k13 = 25
.line	1478	loadk        r15   k14 ; k14 = 112
.line	1478	loadk        r16   k15 ; k15 = 35
.line	1478	loadk        r17   k16 ; k16 = 118
.line	1478	loadk        r18   k17 ; k17 = 229
.line	1478	loadk        r19   k18 ; k18 = 226
.line	1478	loadk        r20   k19 ; k19 = 173
.line	1478	loadk        r21   k20 ; k20 = 84
.line	1478	loadk        r22   k11 ; k11 = 215
.line	1478	loadk        r23   k21 ; k21 = 34
.line	1478	loadk        r24   k22 ; k22 = 18
.line	1478	loadk        r25   k23 ; k23 = 243
.line	1478	loadk        r26   k24 ; k24 = 61
.line	1478	loadk        r27   k25 ; k25 = 154
.line	1478	loadk        r28   k26 ; k26 = 225
.line	1478	loadk        r29   k27 ; k27 = 217
.line	1478	loadk        r30   k28 ; k28 = 22
.line	1478	loadk        r31   k29 ; k29 = 72
.line	1478	loadk        r32   k30 ; k30 = 14
.line	1478	loadk        r33   k31 ; k31 = 124
.line	1478	loadk        r34   k32 ; k32 = 208
.line	1478	loadk        r35   k33 ; k33 = 186
.line	1478	call          r2    34     2
.line	1478	getupval      r3    u2
.line	1478	move          r4    r0
.line	1478	call          r3     2     2
.line	1478	concat        r2    r2    r3
.label	l44
.line	1478	call          r1     2     1
.line	1478	getupval      r1    u3
.line	1478	getupval      r2    u1
.line	1478	loadk         r3   k34 ; k34 = 3
.line	1478	loadk         r4   k35 ; k35 = 148
.line	1478	loadk         r5   k36 ; k36 = 44
.line	1478	loadk         r6   k37 ; k37 = 204
.line	1478	loadk         r7   k38 ; k38 = 221
.line	1478	loadk         r8    k7 ; k7 = 59
.line	1478	loadk         r9   k39 ; k39 = 200
.line	1478	loadk        r10   k40 ; k40 = 94
.line	1478	loadk        r11   k35 ; k35 = 148
.line	1478	loadk        r12   k17 ; k17 = 229
.line	1478	loadk        r13   k41 ; k41 = 198
.line	1478	loadk        r14   k42 ; k42 = 67
.line	1478	loadk        r15   k43 ; k43 = 80
.line	1478	loadk        r16   k44 ; k44 = 46
.line	1478	loadk        r17   k45 ; k45 = 98
.line	1478	loadk        r18   k46 ; k46 = 205
.line	1478	loadk        r19   k23 ; k23 = 243
.line	1478	loadk        r20    k6 ; k6 = 230
.line	1478	loadk        r21   k47 ; k47 = 89
.line	1478	loadk        r22   k48 ; k48 = 251
.line	1478	loadk        r23   k49 ; k49 = 48
.line	1478	loadk        r24   k50 ; k50 = 81
.line	1478	loadk        r25   k51 ; k51 = 250
.line	1478	loadk        r26   k52 ; k52 = 114
.line	1478	loadk        r27    k8 ; k8 = 143
.line	1478	loadk        r28   k53 ; k53 = 233
.line	1478	loadk        r29   k54 ; k54 = 212
.line	1478	loadk        r30   k21 ; k21 = 34
.line	1478	loadk        r31   k55 ; k55 = 64
.line	1478	loadk        r32   k56 ; k56 = 51
.line	1478	loadk        r33   k57 ; k57 = 102
.line	1478	call          r2    32     2
.line	1478	call          r1     2     2
.line	1478	gettable      r2    r1   k58 ; k58 = "GetZoneName"
.line	1478	move          r3    r0
.line	1478	tailcall      r2     2
.line	1478	return        r2     0
.line	1478	return        r0     1
.line	1478	move          r0    r0
.line	1478	move          r0    r0
.line	1478	move          r0    r0
.line	1478	return        r0     1

.function	main/f99

.source	null
.linedefined	1484
.lastlinedefined	1487
.numparams	2
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	16	true

.constant	k0	1.0E-7

.line	1484	loadk         r2    k0 ; k0 = 1.0E-7
.line	1484	getupval      r3    u0
.line	1484	sub           r4    r0    r1
.line	1484	call          r3     2     2
.line	1484	lt             1    r3    r2
.line	1484	jmp            0    l8
.line	1484	loadbool      r3     0     1
.label	l8
.line	1484	loadbool      r3     1     0
.line	1484	return        r3     2
.line	1484	return        r0     1
.line	1484	move          r0    r0
.line	1484	move          r0    r0
.line	1484	move          r0    r0
.line	1484	move          r0    r0
.line	1484	return        r0     1

.function	main/f100

.source	null
.linedefined	1489
.lastlinedefined	1498
.numparams	2
.is_vararg	0
.maxstacksize	33

.upvalue	"_ENV"	25	true
.upvalue	"U1"	1	true
.upvalue	"U2"	0	false

.constant	k0	3
.constant	k1	148
.constant	k2	44
.constant	k3	204
.constant	k4	221
.constant	k5	59
.constant	k6	200
.constant	k7	65
.constant	k8	151
.constant	k9	247
.constant	k10	206
.constant	k11	14
.constant	k12	18
.constant	k13	50
.constant	k14	113
.constant	k15	203
.constant	k16	226
.constant	k17	173
.constant	k18	27
.constant	k19	243
.constant	k20	54
.constant	k21	230
.constant	k22	66
.constant	k23	157
.constant	k24	244
.constant	k25	222
.constant	k26	17
.constant	k27	95
.constant	k28	"IsPanDoraJumpUrl"
.constant	k29	"GlobalData"
.constant	k30	"JumpUrl"

.line	1489	test          r1     0
.line	1489	jmp            0   l43
.line	1489	getupval      r2    u0
.line	1489	getupval      r3    u1
.line	1489	loadk         r4    k0 ; k0 = 3
.line	1489	loadk         r5    k1 ; k1 = 148
.line	1489	loadk         r6    k2 ; k2 = 44
.line	1489	loadk         r7    k3 ; k3 = 204
.line	1489	loadk         r8    k4 ; k4 = 221
.line	1489	loadk         r9    k5 ; k5 = 59
.line	1489	loadk        r10    k6 ; k6 = 200
.line	1489	loadk        r11    k7 ; k7 = 65
.line	1489	loadk        r12    k8 ; k8 = 151
.line	1489	loadk        r13    k9 ; k9 = 247
.line	1489	loadk        r14   k10 ; k10 = 206
.line	1489	loadk        r15   k11 ; k11 = 14
.line	1489	loadk        r16   k12 ; k12 = 18
.line	1489	loadk        r17   k13 ; k13 = 50
.line	1489	loadk        r18   k14 ; k14 = 113
.line	1489	loadk        r19   k15 ; k15 = 203
.line	1489	loadk        r20   k16 ; k16 = 226
.line	1489	loadk        r21   k17 ; k17 = 173
.line	1489	loadk        r22   k18 ; k18 = 27
.line	1489	loadk        r23   k19 ; k19 = 243
.line	1489	loadk        r24   k20 ; k20 = 54
.line	1489	loadk        r25   k12 ; k12 = 18
.line	1489	loadk        r26   k21 ; k21 = 230
.line	1489	loadk        r27   k22 ; k22 = 66
.line	1489	loadk        r28   k23 ; k23 = 157
.line	1489	loadk        r29   k24 ; k24 = 244
.line	1489	loadk        r30   k25 ; k25 = 222
.line	1489	loadk        r31   k26 ; k26 = 17
.line	1489	loadk        r32   k27 ; k27 = 95
.line	1489	call          r3    30     2
.line	1489	call          r2     2     2
.line	1489	gettable      r3    r2   k28 ; k28 = "IsPanDoraJumpUrl"
.line	1489	move          r4    r0
.line	1489	call          r3     2     2
.line	1489	test          r3     0
.line	1489	jmp            0   l43
.line	1489	loadbool      r3     0     0
.line	1489	return        r3     2
.label	l43
.line	1489	gettabup      r2    u2   k29 ; k29 = "GlobalData"
.line	1489	gettable      r2    r2   k30 ; k30 = "JumpUrl"
.line	1489	move          r3    r0
.line	1489	call          r2     2     1
.line	1489	loadbool      r2     1     0
.line	1489	return        r2     2
.line	1489	return        r0     1
.line	1489	move          r0    r0
.line	1489	return        r0     1

.function	main/f101

.source	null
.linedefined	1499
.lastlinedefined	1503
.numparams	1
.is_vararg	0
.maxstacksize	33

.upvalue	"_ENV"	25	true
.upvalue	"U1"	1	true
.upvalue	"U2"	0	false

.constant	k0	"itemId"
.constant	k1	3
.constant	k2	148
.constant	k3	44
.constant	k4	204
.constant	k5	221
.constant	k6	59
.constant	k7	200
.constant	k8	65
.constant	k9	151
.constant	k10	247
.constant	k11	206
.constant	k12	14
.constant	k13	18
.constant	k14	50
.constant	k15	113
.constant	k16	203
.constant	k17	226
.constant	k18	173
.constant	k19	27
.constant	k20	243
.constant	k21	54
.constant	k22	230
.constant	k23	66
.constant	k24	157
.constant	k25	244
.constant	k26	222
.constant	k27	17
.constant	k28	95
.constant	k29	"OpenJumpModule"
.constant	k30	"BP_ENUM_MODULE_WARDROBE"

.line	1499	newtable      r1     0     1
.line	1499	settable      r1    k0    r0 ; k0 = "itemId"
.line	1499	getupval      r2    u0
.line	1499	getupval      r3    u1
.line	1499	loadk         r4    k1 ; k1 = 3
.line	1499	loadk         r5    k2 ; k2 = 148
.line	1499	loadk         r6    k3 ; k3 = 44
.line	1499	loadk         r7    k4 ; k4 = 204
.line	1499	loadk         r8    k5 ; k5 = 221
.line	1499	loadk         r9    k6 ; k6 = 59
.line	1499	loadk        r10    k7 ; k7 = 200
.line	1499	loadk        r11    k8 ; k8 = 65
.line	1499	loadk        r12    k9 ; k9 = 151
.line	1499	loadk        r13   k10 ; k10 = 247
.line	1499	loadk        r14   k11 ; k11 = 206
.line	1499	loadk        r15   k12 ; k12 = 14
.line	1499	loadk        r16   k13 ; k13 = 18
.line	1499	loadk        r17   k14 ; k14 = 50
.line	1499	loadk        r18   k15 ; k15 = 113
.line	1499	loadk        r19   k16 ; k16 = 203
.line	1499	loadk        r20   k17 ; k17 = 226
.line	1499	loadk        r21   k18 ; k18 = 173
.line	1499	loadk        r22   k19 ; k19 = 27
.line	1499	loadk        r23   k20 ; k20 = 243
.line	1499	loadk        r24   k21 ; k21 = 54
.line	1499	loadk        r25   k13 ; k13 = 18
.line	1499	loadk        r26   k22 ; k22 = 230
.line	1499	loadk        r27   k23 ; k23 = 66
.line	1499	loadk        r28   k24 ; k24 = 157
.line	1499	loadk        r29   k25 ; k25 = 244
.line	1499	loadk        r30   k26 ; k26 = 222
.line	1499	loadk        r31   k27 ; k27 = 17
.line	1499	loadk        r32   k28 ; k28 = 95
.line	1499	call          r3    30     2
.line	1499	call          r2     2     2
.line	1499	gettable      r3    r2   k29 ; k29 = "OpenJumpModule"
.line	1499	gettabup      r4    u2   k30 ; k30 = "BP_ENUM_MODULE_WARDR" (truncated)
.line	1499	move          r5    r1
.line	1499	call          r3     3     1
.line	1499	return        r0     1
.line	1499	move          r0    r0
.line	1499	move          r0    r0
.line	1499	move          r0    r0
.line	1499	move          r0    r0
.line	1499	return        r0     1

.function	main/f102

.source	null
.linedefined	1505
.lastlinedefined	1514
.numparams	1
.is_vararg	0
.maxstacksize	24

.upvalue	"_ENV"	27	true
.upvalue	"U1"	1	true
.upvalue	"U2"	48	true
.upvalue	"U3"	47	true
.upvalue	"U4"	2	true

.constant	k0	"GetTableData"
.constant	k1	42
.constant	k2	141
.constant	k3	40
.constant	k4	217
.constant	k5	246
.constant	k6	55
.constant	k7	133
.constant	k8	69
.constant	k9	153
.constant	k10	254
.constant	k11	192
.constant	k12	8
.constant	k13	105
.constant	k14	51
.constant	k15	231
.constant	k16	255
.constant	k17	166
.constant	k18	83
.constant	k19	240
.constant	k20	36
.constant	k21	"JumpExchangeUrl"
.constant	k22	"IsBlueholeOperationRegion"

.line	1505	gettabup      r1    u0    k0 ; k0 = "GetTableData"
.line	1505	getupval      r2    u1
.line	1505	loadk         r3    k1 ; k1 = 42
.line	1505	loadk         r4    k2 ; k2 = 141
.line	1505	loadk         r5    k3 ; k3 = 40
.line	1505	loadk         r6    k4 ; k4 = 217
.line	1505	loadk         r7    k5 ; k5 = 246
.line	1505	loadk         r8    k6 ; k6 = 55
.line	1505	loadk         r9    k7 ; k7 = 133
.line	1505	loadk        r10    k8 ; k8 = 69
.line	1505	loadk        r11    k9 ; k9 = 153
.line	1505	loadk        r12   k10 ; k10 = 254
.line	1505	loadk        r13   k11 ; k11 = 192
.line	1505	loadk        r14   k12 ; k12 = 8
.line	1505	loadk        r15   k13 ; k13 = 105
.line	1505	loadk        r16   k14 ; k14 = 51
.line	1505	loadk        r17   k13 ; k13 = 105
.line	1505	loadk        r18   k15 ; k15 = 231
.line	1505	loadk        r19   k16 ; k16 = 255
.line	1505	loadk        r20   k17 ; k17 = 166
.line	1505	loadk        r21   k18 ; k18 = 83
.line	1505	loadk        r22   k19 ; k19 = 240
.line	1505	loadk        r23   k20 ; k20 = 36
.line	1505	call          r2    22     2
.line	1505	move          r3    r0
.line	1505	call          r1     3     2
.line	1505	test          r1     1
.line	1505	jmp            0   l33
.line	1505	getupval      r2    u2
.line	1505	move          r3    r0
.line	1505	call          r2     2     1
.line	1505	return        r0     1
.label	l33
.line	1505	getupval      r2    u3
.line	1505	gettable      r3    r1   k21 ; k21 = "JumpExchangeUrl"
.line	1505	gettabup      r4    u4   k22 ; k22 = "IsBlueholeOperationR" (truncated)
.line	1505	call          r4     1     0
.line	1505	call          r2     0     2
.line	1505	test          r2     1
.line	1505	jmp            0   l43
.line	1505	getupval      r2    u2
.line	1505	move          r3    r0
.line	1505	call          r2     2     1
.label	l43
.line	1505	return        r0     1
.line	1505	move          r0    r0
.line	1505	move          r0    r0
.line	1505	move          r0    r0
.line	1505	return        r0     1

.function	main/f103

.source	null
.linedefined	1516
.lastlinedefined	1524
.numparams	2
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	22	true
.upvalue	"U1"	1	true
.upvalue	"U2"	6	true

.constant	k0	19
.constant	k1	140
.constant	k2	55
.constant	k3	192
.constant	k4	221
.constant	k5	40
.constant	k6	91
.constant	k7	109
.constant	k8	242
.constant	k9	28

.line	1516	test          r0     0
.line	1516	jmp            0   l20
.line	1516	getupval      r2    u0
.line	1516	move          r3    r0
.line	1516	call          r2     2     2
.line	1516	getupval      r3    u1
.line	1516	loadk         r4    k0 ; k0 = 19
.line	1516	loadk         r5    k1 ; k1 = 140
.line	1516	loadk         r6    k2 ; k2 = 55
.line	1516	loadk         r7    k3 ; k3 = 192
.line	1516	loadk         r8    k4 ; k4 = 221
.line	1516	loadk         r9    k5 ; k5 = 40
.line	1516	call          r3     7     2
.line	1516	eq             0    r2    r3
.line	1516	jmp            0   l20
.line	1516	getupval      r2    u1
.line	1516	call          r2     1     2
.line	1516	eq             0    r0    r2
.line	1516	jmp            0   l21
.label	l20
.line	1516	return        r0     2
.label	l21
.line	1516	test          r1     1
.line	1516	jmp            0   l27
.line	1516	getupval      r2    u1
.line	1516	loadk         r3    k6 ; k6 = 91
.line	1516	call          r2     2     2
.line	1516	move          r1    r2
.label	l27
.line	1516	getupval      r2    u2
.line	1516	move          r3    r0
.line	1516	getupval      r4    u1
.line	1516	loadk         r5    k7 ; k7 = 109
.line	1516	loadk         r6    k8 ; k8 = 242
.line	1516	call          r4     3     2
.line	1516	move          r5    r1
.line	1516	call          r2     4     2
.line	1516	move          r0    r2
.line	1516	getupval      r2    u2
.line	1516	move          r3    r0
.line	1516	getupval      r4    u1
.line	1516	loadk         r5    k9 ; k9 = 28
.line	1516	call          r4     2     2
.line	1516	move          r5    r1
.line	1516	call          r2     4     2
.line	1516	move          r0    r2
.line	1516	return        r0     2
.line	1516	return        r0     1
.line	1516	move          r0    r0
.line	1516	move          r0    r0
.line	1516	return        r0     1

.function	main/f104

.source	null
.linedefined	1526
.lastlinedefined	1535
.numparams	2
.is_vararg	0
.maxstacksize	20

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	22	true
.upvalue	"U3"	6	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	50
.constant	k3	157
.constant	k4	53
.constant	k5	197
.constant	k6	210
.constant	k7	44
.constant	k8	131
.constant	k9	104
.constant	k10	150
.constant	k11	228
.constant	k12	194
.constant	k13	31
.constant	k14	127
.constant	k15	41
.constant	k16	100
.constant	k17	214
.constant	k18	19
.constant	k19	140
.constant	k20	55
.constant	k21	192
.constant	k22	221
.constant	k23	40
.constant	k24	109
.constant	k25	106

.line	1526	gettabup      r2    u0    k0 ; k0 = "log"
.line	1526	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1526	test          r3     0
.line	1526	jmp            0   l23
.line	1526	getupval      r3    u1
.line	1526	loadk         r4    k2 ; k2 = 50
.line	1526	loadk         r5    k3 ; k3 = 157
.line	1526	loadk         r6    k4 ; k4 = 53
.line	1526	loadk         r7    k5 ; k5 = 197
.line	1526	loadk         r8    k6 ; k6 = 210
.line	1526	loadk         r9    k7 ; k7 = 44
.line	1526	loadk        r10    k8 ; k8 = 131
.line	1526	loadk        r11    k9 ; k9 = 104
.line	1526	loadk        r12   k10 ; k10 = 150
.line	1526	loadk        r13   k11 ; k11 = 228
.line	1526	loadk        r14   k12 ; k12 = 194
.line	1526	loadk        r15   k13 ; k13 = 31
.line	1526	loadk        r16   k14 ; k14 = 127
.line	1526	loadk        r17   k15 ; k15 = 41
.line	1526	loadk        r18   k16 ; k16 = 100
.line	1526	loadk        r19   k17 ; k17 = 214
.line	1526	call          r3    17     2
.label	l23
.line	1526	call          r2     2     1
.line	1526	test          r0     0
.line	1526	jmp            0   l43
.line	1526	getupval      r2    u2
.line	1526	move          r3    r0
.line	1526	call          r2     2     2
.line	1526	getupval      r3    u1
.line	1526	loadk         r4   k18 ; k18 = 19
.line	1526	loadk         r5   k19 ; k19 = 140
.line	1526	loadk         r6   k20 ; k20 = 55
.line	1526	loadk         r7   k21 ; k21 = 192
.line	1526	loadk         r8   k22 ; k22 = 221
.line	1526	loadk         r9   k23 ; k23 = 40
.line	1526	call          r3     7     2
.line	1526	eq             0    r2    r3
.line	1526	jmp            0   l43
.line	1526	getupval      r2    u1
.line	1526	call          r2     1     2
.line	1526	eq             0    r0    r2
.line	1526	jmp            0   l44
.label	l43
.line	1526	return        r0     2
.label	l44
.line	1526	test          r1     1
.line	1526	jmp            0   l49
.line	1526	getupval      r2    u1
.line	1526	call          r2     1     2
.line	1526	move          r1    r2
.label	l49
.line	1526	getupval      r2    u3
.line	1526	move          r3    r0
.line	1526	getupval      r4    u1
.line	1526	loadk         r5   k24 ; k24 = 109
.line	1526	call          r4     2     2
.line	1526	move          r5    r1
.line	1526	call          r2     4     2
.line	1526	move          r0    r2
.line	1526	getupval      r2    u3
.line	1526	move          r3    r0
.line	1526	getupval      r4    u1
.line	1526	loadk         r5   k25 ; k25 = 106
.line	1526	call          r4     2     2
.line	1526	move          r5    r1
.line	1526	call          r2     4     2
.line	1526	move          r0    r2
.line	1526	return        r0     2
.line	1526	return        r0     1
.line	1526	move          r0    r0
.line	1526	move          r0    r0
.line	1526	move          r0    r0
.line	1526	move          r0    r0
.line	1526	return        r0     1

.function	main/f105

.source	null
.linedefined	1537
.lastlinedefined	1543
.numparams	1
.is_vararg	0
.maxstacksize	10

.constant	k0	0
.constant	k1	"Num"
.constant	k2	1
.constant	k3	"Get"

.line	1537	newtable      r1     0     0
.line	1537	loadk         r2    k0 ; k0 = 0
.line	1537	self          r3    r0    k1 ; k1 = "Num"
.line	1537	call          r3     2     2
.line	1537	sub           r3    r3    k2 ; k2 = 1
.line	1537	loadk         r4    k2 ; k2 = 1
.line	1537	move          r0    r0
.line	1537	len           r6    r1
.line	1537	add           r6    r6    k2 ; k2 = 1
.line	1537	self          r7    r0    k3 ; k3 = "Get"
.line	1537	move          r9    r5
.line	1537	call          r7     3     2
.line	1537	settable      r1    r6    r7
.line	1537	move          r0    r0
.line	1537	return        r1     2
.line	1537	return        r0     1
.line	1537	move          r0    r0
.line	1537	move          r0    r0
.line	1537	move          r0    r0
.line	1537	return        r0     1

.function	main/f106

.source	null
.linedefined	1545
.lastlinedefined	1548
.numparams	1
.is_vararg	0
.maxstacksize	12

.upvalue	"_ENV"	27	true
.upvalue	"U1"	1	true

.constant	k0	"GetTableData"
.constant	k1	36
.constant	k2	151
.constant	k3	40
.constant	k4	200
.constant	k5	218
.constant	k6	33
.constant	k7	165
.constant	k8	75
.constant	k9	159
.constant	k10	"Domain"

.line	1545	gettabup      r1    u0    k0 ; k0 = "GetTableData"
.line	1545	getupval      r2    u1
.line	1545	loadk         r3    k1 ; k1 = 36
.line	1545	loadk         r4    k2 ; k2 = 151
.line	1545	loadk         r5    k3 ; k3 = 40
.line	1545	loadk         r6    k4 ; k4 = 200
.line	1545	loadk         r7    k5 ; k5 = 218
.line	1545	loadk         r8    k6 ; k6 = 33
.line	1545	loadk         r9    k7 ; k7 = 165
.line	1545	loadk        r10    k8 ; k8 = 75
.line	1545	loadk        r11    k9 ; k9 = 159
.line	1545	call          r2    10     2
.line	1545	move          r3    r0
.line	1545	call          r1     3     2
.line	1545	test          r1     0
.line	1545	jmp            0   l20
.line	1545	gettable      r2    r1   k10 ; k10 = "Domain"
.line	1545	test          r2     1
.line	1545	jmp            0   l22
.label	l20
.line	1545	getupval      r2    u1
.line	1545	call          r2     1     2
.label	l22
.line	1545	return        r2     2
.line	1545	return        r0     1
.line	1545	move          r0    r0
.line	1545	move          r0    r0
.line	1545	move          r0    r0
.line	1545	move          r0    r0
.line	1545	return        r0     1

.function	main/f107

.source	null
.linedefined	1550
.lastlinedefined	1557
.numparams	1
.is_vararg	0
.maxstacksize	32

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	27	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	38
.constant	k3	141
.constant	k4	43
.constant	k5	202
.constant	k6	230
.constant	k7	59
.constant	k8	143
.constant	k9	65
.constant	k10	214
.constant	k11	215
.constant	k12	194
.constant	k13	25
.constant	k14	119
.constant	k15	36
.constant	k16	124
.constant	k17	211
.constant	k18	255
.constant	k19	186
.constant	k20	81
.constant	k21	219
.constant	k22	58
.constant	k23	54
.constant	k24	210
.constant	k25	61
.constant	k26	134
.constant	k27	239
.constant	k28	151
.constant	k29	20
.constant	k30	72
.constant	k31	"GetTableData"
.constant	k32	157
.constant	k33	60
.constant	k34	222
.constant	k35	220
.constant	k36	130
.constant	k37	110
.constant	k38	254
.constant	k39	193
.constant	k40	4
.constant	k41	91
.constant	k42	"Keyword"

.line	1550	test          r0     1
.line	1550	jmp            0   l42
.line	1550	gettabup      r1    u0    k0 ; k0 = "log"
.line	1550	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1550	test          r2     0
.line	1550	jmp            0   l38
.line	1550	getupval      r2    u1
.line	1550	loadk         r3    k2 ; k2 = 38
.line	1550	loadk         r4    k3 ; k3 = 141
.line	1550	loadk         r5    k4 ; k4 = 43
.line	1550	loadk         r6    k5 ; k5 = 202
.line	1550	loadk         r7    k6 ; k6 = 230
.line	1550	loadk         r8    k7 ; k7 = 59
.line	1550	loadk         r9    k8 ; k8 = 143
.line	1550	loadk        r10    k9 ; k9 = 65
.line	1550	loadk        r11   k10 ; k10 = 214
.line	1550	loadk        r12   k11 ; k11 = 215
.line	1550	loadk        r13   k12 ; k12 = 194
.line	1550	loadk        r14   k13 ; k13 = 25
.line	1550	loadk        r15   k14 ; k14 = 119
.line	1550	loadk        r16   k15 ; k15 = 36
.line	1550	loadk        r17   k16 ; k16 = 124
.line	1550	loadk        r18   k17 ; k17 = 211
.line	1550	loadk        r19   k18 ; k18 = 255
.line	1550	loadk        r20   k19 ; k19 = 186
.line	1550	loadk        r21   k20 ; k20 = 81
.line	1550	loadk        r22   k21 ; k21 = 219
.line	1550	loadk        r23   k22 ; k22 = 58
.line	1550	loadk        r24   k23 ; k23 = 54
.line	1550	loadk        r25   k24 ; k24 = 210
.line	1550	loadk        r26   k25 ; k25 = 61
.line	1550	loadk        r27   k26 ; k26 = 134
.line	1550	loadk        r28   k27 ; k27 = 239
.line	1550	loadk        r29   k28 ; k28 = 151
.line	1550	loadk        r30   k29 ; k29 = 20
.line	1550	loadk        r31   k30 ; k30 = 72
.line	1550	call          r2    30     2
.label	l38
.line	1550	call          r1     2     1
.line	1550	getupval      r1    u1
.line	1550	call          r1     1     2
.line	1550	return        r1     2
.label	l42
.line	1550	gettabup      r1    u2   k31 ; k31 = "GetTableData"
.line	1550	getupval      r2    u1
.line	1550	loadk         r3    k4 ; k4 = 43
.line	1550	loadk         r4   k32 ; k32 = 157
.line	1550	loadk         r5   k33 ; k33 = 60
.line	1550	loadk         r6   k34 ; k34 = 222
.line	1550	loadk         r7   k35 ; k35 = 220
.line	1550	loadk         r8   k25 ; k25 = 61
.line	1550	loadk         r9   k36 ; k36 = 130
.line	1550	loadk        r10   k37 ; k37 = 110
.line	1550	loadk        r11   k28 ; k28 = 151
.line	1550	loadk        r12   k38 ; k38 = 254
.line	1550	loadk        r13   k39 ; k39 = 193
.line	1550	loadk        r14   k40 ; k40 = 4
.line	1550	loadk        r15   k41 ; k41 = 91
.line	1550	call          r2    14     2
.line	1550	move          r3    r0
.line	1550	call          r1     3     2
.line	1550	test          r1     0
.line	1550	jmp            0   l65
.line	1550	gettable      r2    r1   k42 ; k42 = "Keyword"
.line	1550	test          r2     1
.line	1550	jmp            0   l67
.label	l65
.line	1550	getupval      r2    u1
.line	1550	call          r2     1     2
.label	l67
.line	1550	return        r2     2
.line	1550	return        r0     1
.line	1550	move          r0    r0
.line	1550	return        r0     1

.function	main/f108

.source	null
.linedefined	1559
.lastlinedefined	1571
.numparams	1
.is_vararg	0
.maxstacksize	43

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	20	true

.constant	k0	"log_tree"
.constant	k1	"bWriteLog"
.constant	k2	59
.constant	k3	157
.constant	k4	33
.constant	k5	222
.constant	k6	210
.constant	k7	61
.constant	k8	130
.constant	k9	112
.constant	k10	216
.constant	k11	214
.constant	k12	3
.constant	k13	95
.constant	k14	20
.constant	k15	113
.constant	k16	205
.constant	k17	252
.constant	k18	230
.constant	k19	121
.constant	k20	240
.constant	k21	48
.constant	k22	11
.constant	k23	164
.constant	k24	129
.constant	k25	244
.constant	k26	218
.constant	k27	28
.constant	k28	92
.constant	k29	125
.constant	k30	53
.constant	k31	229
.constant	k32	190
.constant	k33	74
.constant	k34	251
.constant	k35	54
.constant	k36	79
.constant	k37	187
.constant	k38	45
.constant	k39	0
.constant	k40	32
.constant	k41	1
.constant	k42	"log"
.constant	k43	213
.constant	k44	172
.constant	k45	64
.constant	k46	115
.constant	k47	82
.constant	k48	166

.line	1559	gettabup      r1    u0    k0 ; k0 = "log_tree"
.line	1559	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1559	test          r2     0
.line	1559	jmp            0   l47
.line	1559	getupval      r2    u1
.line	1559	loadk         r3    k2 ; k2 = 59
.line	1559	loadk         r4    k3 ; k3 = 157
.line	1559	loadk         r5    k4 ; k4 = 33
.line	1559	loadk         r6    k5 ; k5 = 222
.line	1559	loadk         r7    k6 ; k6 = 210
.line	1559	loadk         r8    k7 ; k7 = 61
.line	1559	loadk         r9    k8 ; k8 = 130
.line	1559	loadk        r10    k9 ; k9 = 112
.line	1559	loadk        r11   k10 ; k10 = 216
.line	1559	loadk        r12   k11 ; k11 = 214
.line	1559	loadk        r13    k6 ; k6 = 210
.line	1559	loadk        r14   k12 ; k12 = 3
.line	1559	loadk        r15   k13 ; k13 = 95
.line	1559	loadk        r16   k14 ; k14 = 20
.line	1559	loadk        r17   k15 ; k15 = 113
.line	1559	loadk        r18   k16 ; k16 = 205
.line	1559	loadk        r19   k17 ; k17 = 252
.line	1559	loadk        r20   k18 ; k18 = 230
.line	1559	loadk        r21   k19 ; k19 = 121
.line	1559	loadk        r22   k20 ; k20 = 240
.line	1559	loadk        r23   k21 ; k21 = 48
.line	1559	loadk        r24   k22 ; k22 = 11
.line	1559	loadk        r25   k23 ; k23 = 164
.line	1559	loadk        r26   k13 ; k13 = 95
.line	1559	loadk        r27   k24 ; k24 = 129
.line	1559	loadk        r28   k25 ; k25 = 244
.line	1559	loadk        r29   k26 ; k26 = 218
.line	1559	loadk        r30   k27 ; k27 = 28
.line	1559	loadk        r31   k28 ; k28 = 92
.line	1559	loadk        r32   k29 ; k29 = 125
.line	1559	loadk        r33   k30 ; k30 = 53
.line	1559	loadk        r34   k11 ; k11 = 214
.line	1559	loadk        r35   k31 ; k31 = 229
.line	1559	loadk        r36   k32 ; k32 = 190
.line	1559	loadk        r37   k33 ; k33 = 74
.line	1559	loadk        r38   k34 ; k34 = 251
.line	1559	loadk        r39   k35 ; k35 = 54
.line	1559	loadk        r40   k36 ; k36 = 79
.line	1559	loadk        r41   k37 ; k37 = 187
.line	1559	loadk        r42   k38 ; k38 = 45
.line	1559	call          r2    41     2
.label	l47
.line	1559	move          r3    r0
.line	1559	call          r1     3     1
.line	1559	loadk         r1   k39 ; k39 = 0
.line	1559	getupval      r2    u2
.line	1559	move          r3    r0
.line	1559	call          r2     2     4
.line	1559	jmp            0   l61
.line	1559	mod           r7    r6   k40 ; k40 = 32
.line	1559	eq             0    r7   k39 ; k39 = 0
.line	1559	jmp            0   l58
.line	1559	loadk         r7   k40 ; k40 = 32
.label	l58
.line	1559	sub           r8    r7   k41 ; k41 = 1
.line	1559	shl           r8   k41    r8 ; k41 = 1
.line	1559	add           r1    r1    r8
.label	l61
.line	1559	move          r0    r0
.line	1559	move          r0    r0
.line	1559	gettabup      r2    u0   k42 ; k42 = "log"
.line	1559	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1559	test          r3     0
.line	1559	jmp            0  l110
.line	1559	getupval      r3    u1
.line	1559	loadk         r4    k2 ; k2 = 59
.line	1559	loadk         r5    k3 ; k3 = 157
.line	1559	loadk         r6    k4 ; k4 = 33
.line	1559	loadk         r7    k5 ; k5 = 222
.line	1559	loadk         r8    k6 ; k6 = 210
.line	1559	loadk         r9    k7 ; k7 = 61
.line	1559	loadk        r10    k8 ; k8 = 130
.line	1559	loadk        r11    k9 ; k9 = 112
.line	1559	loadk        r12   k10 ; k10 = 216
.line	1559	loadk        r13   k11 ; k11 = 214
.line	1559	loadk        r14    k6 ; k6 = 210
.line	1559	loadk        r15   k12 ; k12 = 3
.line	1559	loadk        r16   k13 ; k13 = 95
.line	1559	loadk        r17   k14 ; k14 = 20
.line	1559	loadk        r18   k15 ; k15 = 113
.line	1559	loadk        r19   k16 ; k16 = 205
.line	1559	loadk        r20   k17 ; k17 = 252
.line	1559	loadk        r21   k18 ; k18 = 230
.line	1559	loadk        r22   k19 ; k19 = 121
.line	1559	loadk        r23   k20 ; k20 = 240
.line	1559	loadk        r24   k21 ; k21 = 48
.line	1559	loadk        r25   k22 ; k22 = 11
.line	1559	loadk        r26   k23 ; k23 = 164
.line	1559	loadk        r27   k13 ; k13 = 95
.line	1559	loadk        r28   k24 ; k24 = 129
.line	1559	loadk        r29   k25 ; k25 = 244
.line	1559	loadk        r30   k26 ; k26 = 218
.line	1559	loadk        r31   k27 ; k27 = 28
.line	1559	loadk        r32   k28 ; k28 = 92
.line	1559	loadk        r33   k29 ; k29 = 125
.line	1559	loadk        r34   k30 ; k30 = 53
.line	1559	loadk        r35   k43 ; k43 = 213
.line	1559	loadk        r36   k18 ; k18 = 230
.line	1559	loadk        r37   k44 ; k44 = 172
.line	1559	loadk        r38   k45 ; k45 = 64
.line	1559	loadk        r39   k34 ; k34 = 251
.line	1559	loadk        r40   k46 ; k46 = 115
.line	1559	loadk        r41   k47 ; k47 = 82
.line	1559	loadk        r42   k48 ; k48 = 166
.line	1559	call          r3    40     2
.line	1559	move          r4    r1
.line	1559	concat        r3    r3    r4
.label	l110
.line	1559	call          r2     2     1
.line	1559	return        r1     2
.line	1559	return        r0     1
.line	1559	move          r0    r0
.line	1559	move          r0    r0
.line	1559	move          r0    r0
.line	1559	move          r0    r0
.line	1559	return        r0     1

.function	main/f109

.source	null
.linedefined	1573
.lastlinedefined	1592
.numparams	2
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	59
.constant	k5	157
.constant	k6	33
.constant	k7	222
.constant	k8	210
.constant	k9	61
.constant	k10	130
.constant	k11	112
.constant	k12	216
.constant	k13	214
.constant	k14	3
.constant	k15	95
.constant	k16	20
.constant	k17	113
.constant	k18	205
.constant	k19	252
.constant	k20	230
.constant	k21	119
.constant	k22	240
.constant	k23	55
.constant	k24	18
.constant	k25	247
.constant	k26	109
.constant	k27	218
.constant	k28	204
.constant	k29	14
.constant	k30	88
.constant	k31	125
.constant	k32	53
.constant	k33	229
.constant	k34	190
.constant	k35	74
.constant	k36	251
.constant	k37	54
.constant	k38	67
.constant	k39	166
.constant	k40	126
.constant	k41	9
.constant	k42	32
.constant	k43	137
.constant	k44	142
.constant	k45	111
.constant	k46	"log_error"
.constant	k47	101
.constant	k48	213
.constant	k49	242
.constant	k50	185
.constant	k51	72
.constant	k52	169
.constant	k53	58
.constant	k54	28
.constant	k55	104
.constant	k56	138
.constant	k57	42
.constant	k58	219
.constant	k59	147
.constant	k60	0
.constant	k61	1
.constant	k62	"log_tree"
.constant	k63	172
.constant	k64	64
.constant	k65	115
.constant	k66	82

.line	1573	gettabup      r2    u0    k0 ; k0 = "log"
.line	1573	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1573	test          r3     0
.line	1573	jmp            0   l60
.line	1573	gettabup      r3    u0    k2 ; k2 = "table"
.line	1573	gettable      r3    r3    k3 ; k3 = "concat"
.line	1573	newtable      r4     1     0
.line	1573	getupval      r5    u1
.line	1573	loadk         r6    k4 ; k4 = 59
.line	1573	loadk         r7    k5 ; k5 = 157
.line	1573	loadk         r8    k6 ; k6 = 33
.line	1573	loadk         r9    k7 ; k7 = 222
.line	1573	loadk        r10    k8 ; k8 = 210
.line	1573	loadk        r11    k9 ; k9 = 61
.line	1573	loadk        r12   k10 ; k10 = 130
.line	1573	loadk        r13   k11 ; k11 = 112
.line	1573	loadk        r14   k12 ; k12 = 216
.line	1573	loadk        r15   k13 ; k13 = 214
.line	1573	loadk        r16    k8 ; k8 = 210
.line	1573	loadk        r17   k14 ; k14 = 3
.line	1573	loadk        r18   k15 ; k15 = 95
.line	1573	loadk        r19   k16 ; k16 = 20
.line	1573	loadk        r20   k17 ; k17 = 113
.line	1573	loadk        r21   k18 ; k18 = 205
.line	1573	loadk        r22   k19 ; k19 = 252
.line	1573	loadk        r23   k20 ; k20 = 230
.line	1573	loadk        r24   k21 ; k21 = 119
.line	1573	loadk        r25   k22 ; k22 = 240
.line	1573	loadk        r26   k23 ; k23 = 55
.line	1573	loadk        r27   k24 ; k24 = 18
.line	1573	loadk        r28   k25 ; k25 = 247
.line	1573	loadk        r29   k26 ; k26 = 109
.line	1573	loadk        r30   k27 ; k27 = 218
.line	1573	loadk        r31   k28 ; k28 = 204
.line	1573	loadk        r32    k7 ; k7 = 222
.line	1573	loadk        r33   k29 ; k29 = 14
.line	1573	loadk        r34   k30 ; k30 = 88
.line	1573	loadk        r35   k31 ; k31 = 125
.line	1573	loadk        r36   k32 ; k32 = 53
.line	1573	loadk        r37   k13 ; k13 = 214
.line	1573	loadk        r38   k33 ; k33 = 229
.line	1573	loadk        r39   k34 ; k34 = 190
.line	1573	loadk        r40   k35 ; k35 = 74
.line	1573	loadk        r41   k36 ; k36 = 251
.line	1573	loadk        r42   k37 ; k37 = 54
.line	1573	loadk        r43   k38 ; k38 = 67
.line	1573	loadk        r44   k39 ; k39 = 166
.line	1573	loadk        r45   k40 ; k40 = 126
.line	1573	call          r5    41     2
.line	1573	getupval      r6    u1
.line	1573	loadk         r7   k41 ; k41 = 9
.line	1573	loadk         r8   k10 ; k10 = 130
.line	1573	loadk         r9   k42 ; k42 = 32
.line	1573	loadk        r10   k43 ; k43 = 137
.line	1573	loadk        r11   k44 ; k44 = 142
.line	1573	loadk        r12   k45 ; k45 = 111
.line	1573	call          r6     7     0
.line	1573	setlist       r4     0     1
.line	1573	call          r3     2     2
.label	l60
.line	1573	move          r4    r0
.line	1573	move          r5    r1
.line	1573	call          r2     4     1
.line	1573	test          r0     1
.line	1573	jmp            0  l126
.line	1573	gettabup      r2    u0   k46 ; k46 = "log_error"
.line	1573	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1573	test          r3     0
.line	1573	jmp            0  l124
.line	1573	gettabup      r3    u0    k2 ; k2 = "table"
.line	1573	gettable      r3    r3    k3 ; k3 = "concat"
.line	1573	newtable      r4     1     0
.line	1573	getupval      r5    u1
.line	1573	loadk         r6    k4 ; k4 = 59
.line	1573	loadk         r7    k5 ; k5 = 157
.line	1573	loadk         r8    k6 ; k6 = 33
.line	1573	loadk         r9    k7 ; k7 = 222
.line	1573	loadk        r10    k8 ; k8 = 210
.line	1573	loadk        r11    k9 ; k9 = 61
.line	1573	loadk        r12   k10 ; k10 = 130
.line	1573	loadk        r13   k11 ; k11 = 112
.line	1573	loadk        r14   k12 ; k12 = 216
.line	1573	loadk        r15   k13 ; k13 = 214
.line	1573	loadk        r16    k8 ; k8 = 210
.line	1573	loadk        r17   k14 ; k14 = 3
.line	1573	loadk        r18   k15 ; k15 = 95
.line	1573	loadk        r19   k16 ; k16 = 20
.line	1573	loadk        r20   k17 ; k17 = 113
.line	1573	loadk        r21   k18 ; k18 = 205
.line	1573	loadk        r22   k19 ; k19 = 252
.line	1573	loadk        r23   k20 ; k20 = 230
.line	1573	loadk        r24   k21 ; k21 = 119
.line	1573	loadk        r25   k22 ; k22 = 240
.line	1573	loadk        r26   k23 ; k23 = 55
.line	1573	loadk        r27   k24 ; k24 = 18
.line	1573	loadk        r28   k25 ; k25 = 247
.line	1573	loadk        r29   k26 ; k26 = 109
.line	1573	loadk        r30   k27 ; k27 = 218
.line	1573	loadk        r31   k28 ; k28 = 204
.line	1573	loadk        r32    k7 ; k7 = 222
.line	1573	loadk        r33   k29 ; k29 = 14
.line	1573	loadk        r34   k30 ; k30 = 88
.line	1573	loadk        r35   k17 ; k17 = 113
.line	1573	loadk        r36   k47 ; k47 = 101
.line	1573	loadk        r37   k48 ; k48 = 213
.line	1573	loadk        r38   k49 ; k49 = 242
.line	1573	loadk        r39   k50 ; k50 = 185
.line	1573	loadk        r40   k51 ; k51 = 72
.line	1573	loadk        r41   k52 ; k52 = 169
.line	1573	loadk        r42   k53 ; k53 = 58
.line	1573	loadk        r43   k54 ; k54 = 28
.line	1573	loadk        r44   k39 ; k39 = 166
.line	1573	loadk        r45   k55 ; k55 = 104
.line	1573	call          r5    41     2
.line	1573	getupval      r6    u1
.line	1573	loadk         r7   k24 ; k24 = 18
.line	1573	loadk         r8   k56 ; k56 = 138
.line	1573	loadk         r9   k57 ; k57 = 42
.line	1573	loadk        r10   k58 ; k58 = 219
.line	1573	loadk        r11   k59 ; k59 = 147
.line	1573	loadk        r12   k40 ; k40 = 126
.line	1573	call          r6     7     0
.line	1573	setlist       r4     0     1
.line	1573	call          r3     2     2
.label	l124
.line	1573	call          r2     2     1
.line	1573	return        r0     1
.label	l126
.line	1573	le             0    r0   k60 ; k60 = 0
.line	1573	jmp            0  l189
.line	1573	gettabup      r2    u0   k46 ; k46 = "log_error"
.line	1573	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1573	test          r3     0
.line	1573	jmp            0  l187
.line	1573	gettabup      r3    u0    k2 ; k2 = "table"
.line	1573	gettable      r3    r3    k3 ; k3 = "concat"
.line	1573	newtable      r4     1     0
.line	1573	getupval      r5    u1
.line	1573	loadk         r6    k4 ; k4 = 59
.line	1573	loadk         r7    k5 ; k5 = 157
.line	1573	loadk         r8    k6 ; k6 = 33
.line	1573	loadk         r9    k7 ; k7 = 222
.line	1573	loadk        r10    k8 ; k8 = 210
.line	1573	loadk        r11    k9 ; k9 = 61
.line	1573	loadk        r12   k10 ; k10 = 130
.line	1573	loadk        r13   k11 ; k11 = 112
.line	1573	loadk        r14   k12 ; k12 = 216
.line	1573	loadk        r15   k13 ; k13 = 214
.line	1573	loadk        r16    k8 ; k8 = 210
.line	1573	loadk        r17   k14 ; k14 = 3
.line	1573	loadk        r18   k15 ; k15 = 95
.line	1573	loadk        r19   k16 ; k16 = 20
.line	1573	loadk        r20   k17 ; k17 = 113
.line	1573	loadk        r21   k18 ; k18 = 205
.line	1573	loadk        r22   k19 ; k19 = 252
.line	1573	loadk        r23   k20 ; k20 = 230
.line	1573	loadk        r24   k21 ; k21 = 119
.line	1573	loadk        r25   k22 ; k22 = 240
.line	1573	loadk        r26   k23 ; k23 = 55
.line	1573	loadk        r27   k24 ; k24 = 18
.line	1573	loadk        r28   k25 ; k25 = 247
.line	1573	loadk        r29   k26 ; k26 = 109
.line	1573	loadk        r30   k27 ; k27 = 218
.line	1573	loadk        r31   k28 ; k28 = 204
.line	1573	loadk        r32    k7 ; k7 = 222
.line	1573	loadk        r33   k29 ; k29 = 14
.line	1573	loadk        r34   k30 ; k30 = 88
.line	1573	loadk        r35   k17 ; k17 = 113
.line	1573	loadk        r36   k47 ; k47 = 101
.line	1573	loadk        r37   k48 ; k48 = 213
.line	1573	loadk        r38   k49 ; k49 = 242
.line	1573	loadk        r39   k50 ; k50 = 185
.line	1573	loadk        r40   k51 ; k51 = 72
.line	1573	loadk        r41   k52 ; k52 = 169
.line	1573	loadk        r42   k53 ; k53 = 58
.line	1573	loadk        r43   k54 ; k54 = 28
.line	1573	loadk        r44   k39 ; k39 = 166
.line	1573	loadk        r45   k55 ; k55 = 104
.line	1573	call          r5    41     2
.line	1573	getupval      r6    u1
.line	1573	loadk         r7   k24 ; k24 = 18
.line	1573	loadk         r8   k56 ; k56 = 138
.line	1573	loadk         r9   k57 ; k57 = 42
.line	1573	loadk        r10   k58 ; k58 = 219
.line	1573	loadk        r11   k59 ; k59 = 147
.line	1573	loadk        r12   k31 ; k31 = 125
.line	1573	call          r6     7     0
.line	1573	setlist       r4     0     1
.line	1573	call          r3     2     2
.label	l187
.line	1573	call          r2     2     1
.line	1573	return        r0     1
.label	l189
.line	1573	test          r1     1
.line	1573	jmp            0  l192
.line	1573	loadk         r1   k42 ; k42 = 32
.label	l192
.line	1573	newtable      r2     0     0
.line	1573	loadk         r3   k61 ; k61 = 1
.line	1573	move          r4    r1
.line	1573	loadk         r5   k61 ; k61 = 1
.line	1573	move          r0    r0
.line	1573	sub           r7    r6   k61 ; k61 = 1
.line	1573	shl           r7   k61    r7 ; k61 = 1
.line	1573	band          r7    r7    r0
.line	1573	lt             0   k60    r7 ; k60 = 0
.line	1573	jmp            0  l205
.line	1573	len           r7    r2
.line	1573	add           r7    r7   k61 ; k61 = 1
.line	1573	settable      r2    r7    r6
.label	l205
.line	1573	move          r0    r0
.line	1573	gettabup      r3    u0   k62 ; k62 = "log_tree"
.line	1573	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	1573	test          r4     0
.line	1573	jmp            0  l251
.line	1573	getupval      r4    u1
.line	1573	loadk         r5    k4 ; k4 = 59
.line	1573	loadk         r6    k5 ; k5 = 157
.line	1573	loadk         r7    k6 ; k6 = 33
.line	1573	loadk         r8    k7 ; k7 = 222
.line	1573	loadk         r9    k8 ; k8 = 210
.line	1573	loadk        r10    k9 ; k9 = 61
.line	1573	loadk        r11   k10 ; k10 = 130
.line	1573	loadk        r12   k11 ; k11 = 112
.line	1573	loadk        r13   k12 ; k12 = 216
.line	1573	loadk        r14   k13 ; k13 = 214
.line	1573	loadk        r15    k8 ; k8 = 210
.line	1573	loadk        r16   k14 ; k14 = 3
.line	1573	loadk        r17   k15 ; k15 = 95
.line	1573	loadk        r18   k16 ; k16 = 20
.line	1573	loadk        r19   k17 ; k17 = 113
.line	1573	loadk        r20   k18 ; k18 = 205
.line	1573	loadk        r21   k19 ; k19 = 252
.line	1573	loadk        r22   k20 ; k20 = 230
.line	1573	loadk        r23   k21 ; k21 = 119
.line	1573	loadk        r24   k22 ; k22 = 240
.line	1573	loadk        r25   k23 ; k23 = 55
.line	1573	loadk        r26   k24 ; k24 = 18
.line	1573	loadk        r27   k25 ; k25 = 247
.line	1573	loadk        r28   k26 ; k26 = 109
.line	1573	loadk        r29   k27 ; k27 = 218
.line	1573	loadk        r30   k28 ; k28 = 204
.line	1573	loadk        r31    k7 ; k7 = 222
.line	1573	loadk        r32   k29 ; k29 = 14
.line	1573	loadk        r33   k30 ; k30 = 88
.line	1573	loadk        r34   k31 ; k31 = 125
.line	1573	loadk        r35   k32 ; k32 = 53
.line	1573	loadk        r36   k48 ; k48 = 213
.line	1573	loadk        r37   k20 ; k20 = 230
.line	1573	loadk        r38   k63 ; k63 = 172
.line	1573	loadk        r39   k64 ; k64 = 64
.line	1573	loadk        r40   k36 ; k36 = 251
.line	1573	loadk        r41   k65 ; k65 = 115
.line	1573	loadk        r42   k66 ; k66 = 82
.line	1573	loadk        r43   k39 ; k39 = 166
.line	1573	call          r4    40     2
.label	l251
.line	1573	move          r5    r2
.line	1573	call          r3     3     1
.line	1573	return        r2     2
.line	1573	return        r0     1
.line	1573	move          r0    r0
.line	1573	move          r0    r0
.line	1573	move          r0    r0
.line	1573	return        r0     1

.function	main/f110

.source	null
.linedefined	1594
.lastlinedefined	1601
.numparams	1
.is_vararg	0
.maxstacksize	34

.upvalue	"_ENV"	17	true
.upvalue	"U1"	1	true
.upvalue	"U2"	0	false
.upvalue	"U3"	24	true
.upvalue	"U4"	28	true

.constant	k0	9
.constant	k1	150
.constant	k2	49
.constant	k3	204
.constant	k4	212
.constant	k5	42
.constant	k6	148
.constant	k7	"log_error"
.constant	k8	38
.constant	k9	141
.constant	k10	43
.constant	k11	202
.constant	k12	230
.constant	k13	59
.constant	k14	143
.constant	k15	65
.constant	k16	214
.constant	k17	211
.constant	k18	200
.constant	k19	3
.constant	k20	74
.constant	k21	30
.constant	k22	76
.constant	k23	228
.constant	k24	254
.constant	k25	1
.constant	k26	205
.constant	k27	44
.constant	k28	243
.constant	k29	101
.constant	k30	156
.constant	k31	160
.constant	k32	222
.constant	k33	51
.constant	k34	89
.constant	k35	60
.constant	k36	47
.constant	k37	145
.constant	k38	54
.constant	k39	196
.constant	k40	178
.constant	k41	72
.constant	k42	128
.constant	k43	235
.constant	k44	4
.constant	k45	94
.constant	k46	100
.constant	k47	233
.constant	k48	"Conv_Int64ToText"
.constant	k49	324

.line	1594	getupval      r1    u0
.line	1594	move          r2    r0
.line	1594	call          r1     2     2
.line	1594	getupval      r2    u1
.line	1594	loadk         r3    k0 ; k0 = 9
.line	1594	loadk         r4    k1 ; k1 = 150
.line	1594	loadk         r5    k2 ; k2 = 49
.line	1594	loadk         r6    k3 ; k3 = 204
.line	1594	loadk         r7    k4 ; k4 = 212
.line	1594	loadk         r8    k5 ; k5 = 42
.line	1594	loadk         r9    k6 ; k6 = 148
.line	1594	call          r2     8     2
.line	1594	eq             1    r1    r2
.line	1594	jmp            0   l55
.line	1594	gettabup      r1    u2    k7 ; k7 = "log_error"
.line	1594	getupval      r2    u1
.line	1594	loadk         r3    k8 ; k8 = 38
.line	1594	loadk         r4    k9 ; k9 = 141
.line	1594	loadk         r5   k10 ; k10 = 43
.line	1594	loadk         r6   k11 ; k11 = 202
.line	1594	loadk         r7   k12 ; k12 = 230
.line	1594	loadk         r8   k13 ; k13 = 59
.line	1594	loadk         r9   k14 ; k14 = 143
.line	1594	loadk        r10   k15 ; k15 = 65
.line	1594	loadk        r11   k16 ; k16 = 214
.line	1594	loadk        r12   k17 ; k17 = 211
.line	1594	loadk        r13   k18 ; k18 = 200
.line	1594	loadk        r14   k19 ; k19 = 3
.line	1594	loadk        r15   k20 ; k20 = 74
.line	1594	loadk        r16   k21 ; k21 = 30
.line	1594	loadk        r17   k22 ; k22 = 76
.line	1594	loadk        r18   k11 ; k11 = 202
.line	1594	loadk        r19   k23 ; k23 = 228
.line	1594	loadk        r20   k24 ; k24 = 254
.line	1594	loadk        r21   k25 ; k25 = 1
.line	1594	loadk        r22   k26 ; k26 = 205
.line	1594	loadk        r23   k27 ; k27 = 44
.line	1594	loadk        r24   k10 ; k10 = 43
.line	1594	loadk        r25   k28 ; k28 = 243
.line	1594	loadk        r26   k29 ; k29 = 101
.line	1594	loadk        r27   k30 ; k30 = 156
.line	1594	loadk        r28   k31 ; k31 = 160
.line	1594	loadk        r29   k32 ; k32 = 222
.line	1594	loadk        r30   k33 ; k33 = 51
.line	1594	loadk        r31   k34 ; k34 = 89
.line	1594	loadk        r32   k35 ; k35 = 60
.line	1594	loadk        r33   k36 ; k36 = 47
.line	1594	call          r2    32     2
.line	1594	getupval      r3    u3
.line	1594	move          r4    r0
.line	1594	call          r3     2     2
.line	1594	concat        r2    r2    r3
.line	1594	call          r1     2     1
.line	1594	return        r0     2
.label	l55
.line	1594	getupval      r1    u4
.line	1594	getupval      r2    u1
.line	1594	loadk         r3   k10 ; k10 = 43
.line	1594	loadk         r4   k37 ; k37 = 145
.line	1594	loadk         r5   k38 ; k38 = 54
.line	1594	loadk         r6   k39 ; k39 = 196
.line	1594	loadk         r7   k16 ; k16 = 214
.line	1594	loadk         r8   k13 ; k13 = 59
.line	1594	loadk         r9   k40 ; k40 = 178
.line	1594	loadk        r10   k41 ; k41 = 72
.line	1594	loadk        r11   k42 ; k42 = 128
.line	1594	loadk        r12   k23 ; k23 = 228
.line	1594	loadk        r13   k43 ; k43 = 235
.line	1594	loadk        r14   k44 ; k44 = 4
.line	1594	loadk        r15   k45 ; k45 = 94
.line	1594	loadk        r16   k33 ; k33 = 51
.line	1594	loadk        r17   k46 ; k46 = 100
.line	1594	loadk        r18   k16 ; k16 = 214
.line	1594	loadk        r19   k47 ; k47 = 233
.line	1594	call          r2    18     2
.line	1594	call          r1     2     2
.line	1594	gettable      r2    r1   k48 ; k48 = "Conv_Int64ToText"
.line	1594	move          r3    r0
.line	1594	loadbool      r4     1     0
.line	1594	loadk         r5   k25 ; k25 = 1
.line	1594	loadk         r6   k49 ; k49 = 324
.line	1594	tailcall      r2     5
.line	1594	return        r2     0
.line	1594	return        r0     1
.line	1594	move          r0    r0
.line	1594	gettabup      r3    u0   k47 ; k47 = 233
.line	1594	move          r0    r0
.line	1594	move          r0    r0
.line	1594	return        r0     1

.function	main/f111

.source	null
.linedefined	1603
.lastlinedefined	1616
.numparams	2
.is_vararg	0
.maxstacksize	35

.upvalue	"_ENV"	17	true
.upvalue	"U1"	1	true
.upvalue	"U2"	0	false
.upvalue	"U3"	24	true
.upvalue	"U4"	28	true

.constant	k0	6
.constant	k1	148
.constant	k2	42
.constant	k3	200
.constant	k4	199
.constant	k5	"log_error"
.constant	k6	38
.constant	k7	141
.constant	k8	43
.constant	k9	202
.constant	k10	230
.constant	k11	59
.constant	k12	143
.constant	k13	65
.constant	k14	214
.constant	k15	211
.constant	k16	3
.constant	k17	74
.constant	k18	30
.constant	k19	67
.constant	k20	255
.constant	k21	169
.constant	k22	205
.constant	k23	44
.constant	k24	243
.constant	k25	101
.constant	k26	156
.constant	k27	160
.constant	k28	209
.constant	k29	51
.constant	k30	89
.constant	k31	60
.constant	k32	47
.constant	k33	9
.constant	k34	150
.constant	k35	49
.constant	k36	204
.constant	k37	212
.constant	k38	145
.constant	k39	54
.constant	k40	196
.constant	k41	178
.constant	k42	72
.constant	k43	128
.constant	k44	228
.constant	k45	235
.constant	k46	4
.constant	k47	94
.constant	k48	100
.constant	k49	233
.constant	k50	"Conv_Int64ToText"
.constant	k51	1
.constant	k52	324
.constant	k53	37
.constant	k54	170
.constant	k55	220
.constant	k56	221
.constant	k57	159
.constant	k58	"Conv_FloatToText"
.constant	k59	"HalfToEven"

.line	1603	getupval      r2    u0
.line	1603	move          r3    r0
.line	1603	call          r2     2     2
.line	1603	getupval      r3    u1
.line	1603	loadk         r4    k0 ; k0 = 6
.line	1603	loadk         r5    k1 ; k1 = 148
.line	1603	loadk         r6    k2 ; k2 = 42
.line	1603	loadk         r7    k3 ; k3 = 200
.line	1603	loadk         r8    k4 ; k4 = 199
.line	1603	call          r3     6     2
.line	1603	eq             1    r2    r3
.line	1603	jmp            0   l96
.line	1603	gettabup      r2    u2    k5 ; k5 = "log_error"
.line	1603	getupval      r3    u1
.line	1603	loadk         r4    k6 ; k6 = 38
.line	1603	loadk         r5    k7 ; k7 = 141
.line	1603	loadk         r6    k8 ; k8 = 43
.line	1603	loadk         r7    k9 ; k9 = 202
.line	1603	loadk         r8   k10 ; k10 = 230
.line	1603	loadk         r9   k11 ; k11 = 59
.line	1603	loadk        r10   k12 ; k12 = 143
.line	1603	loadk        r11   k13 ; k13 = 65
.line	1603	loadk        r12   k14 ; k14 = 214
.line	1603	loadk        r13   k15 ; k15 = 211
.line	1603	loadk        r14    k3 ; k3 = 200
.line	1603	loadk        r15   k16 ; k16 = 3
.line	1603	loadk        r16   k17 ; k17 = 74
.line	1603	loadk        r17   k18 ; k18 = 30
.line	1603	loadk        r18   k19 ; k19 = 67
.line	1603	loadk        r19    k3 ; k3 = 200
.line	1603	loadk        r20   k20 ; k20 = 255
.line	1603	loadk        r21   k21 ; k21 = 169
.line	1603	loadk        r22   k13 ; k13 = 65
.line	1603	loadk        r23   k22 ; k22 = 205
.line	1603	loadk        r24   k23 ; k23 = 44
.line	1603	loadk        r25    k8 ; k8 = 43
.line	1603	loadk        r26   k24 ; k24 = 243
.line	1603	loadk        r27   k25 ; k25 = 101
.line	1603	loadk        r28   k26 ; k26 = 156
.line	1603	loadk        r29   k27 ; k27 = 160
.line	1603	loadk        r30   k28 ; k28 = 209
.line	1603	loadk        r31   k29 ; k29 = 51
.line	1603	loadk        r32   k30 ; k30 = 89
.line	1603	loadk        r33   k31 ; k31 = 60
.line	1603	loadk        r34   k32 ; k32 = 47
.line	1603	call          r3    32     2
.line	1603	getupval      r4    u3
.line	1603	move          r5    r0
.line	1603	call          r4     2     2
.line	1603	concat        r3    r3    r4
.line	1603	call          r2     2     1
.line	1603	getupval      r2    u0
.line	1603	move          r3    r0
.line	1603	call          r2     2     2
.line	1603	getupval      r3    u1
.line	1603	loadk         r4   k33 ; k33 = 9
.line	1603	loadk         r5   k34 ; k34 = 150
.line	1603	loadk         r6   k35 ; k35 = 49
.line	1603	loadk         r7   k36 ; k36 = 204
.line	1603	loadk         r8   k37 ; k37 = 212
.line	1603	loadk         r9    k2 ; k2 = 42
.line	1603	loadk        r10    k1 ; k1 = 148
.line	1603	call          r3     8     2
.line	1603	eq             0    r2    r3
.line	1603	jmp            0   l95
.line	1603	getupval      r2    u4
.line	1603	getupval      r3    u1
.line	1603	loadk         r4    k8 ; k8 = 43
.line	1603	loadk         r5   k38 ; k38 = 145
.line	1603	loadk         r6   k39 ; k39 = 54
.line	1603	loadk         r7   k40 ; k40 = 196
.line	1603	loadk         r8   k14 ; k14 = 214
.line	1603	loadk         r9   k11 ; k11 = 59
.line	1603	loadk        r10   k41 ; k41 = 178
.line	1603	loadk        r11   k42 ; k42 = 72
.line	1603	loadk        r12   k43 ; k43 = 128
.line	1603	loadk        r13   k44 ; k44 = 228
.line	1603	loadk        r14   k45 ; k45 = 235
.line	1603	loadk        r15   k46 ; k46 = 4
.line	1603	loadk        r16   k47 ; k47 = 94
.line	1603	loadk        r17   k29 ; k29 = 51
.line	1603	loadk        r18   k48 ; k48 = 100
.line	1603	loadk        r19   k14 ; k14 = 214
.line	1603	loadk        r20   k49 ; k49 = 233
.line	1603	call          r3    18     2
.line	1603	call          r2     2     2
.line	1603	gettable      r3    r2   k50 ; k50 = "Conv_Int64ToText"
.line	1603	move          r4    r0
.line	1603	loadbool      r5     1     0
.line	1603	loadk         r6   k51 ; k51 = 1
.line	1603	loadk         r7   k52 ; k52 = 324
.line	1603	tailcall      r3     5
.line	1603	return        r3     0
.line	1603	jmp            0   l96
.label	l95
.line	1603	return        r0     2
.label	l96
.line	1603	getupval      r2    u4
.line	1603	getupval      r3    u1
.line	1603	loadk         r4    k8 ; k8 = 43
.line	1603	loadk         r5   k38 ; k38 = 145
.line	1603	loadk         r6   k39 ; k39 = 54
.line	1603	loadk         r7   k40 ; k40 = 196
.line	1603	loadk         r8   k14 ; k14 = 214
.line	1603	loadk         r9   k11 ; k11 = 59
.line	1603	loadk        r10   k41 ; k41 = 178
.line	1603	loadk        r11   k42 ; k42 = 72
.line	1603	loadk        r12   k43 ; k43 = 128
.line	1603	loadk        r13   k44 ; k44 = 228
.line	1603	loadk        r14   k45 ; k45 = 235
.line	1603	loadk        r15   k46 ; k46 = 4
.line	1603	loadk        r16   k47 ; k47 = 94
.line	1603	loadk        r17   k29 ; k29 = 51
.line	1603	loadk        r18   k48 ; k48 = 100
.line	1603	loadk        r19   k14 ; k14 = 214
.line	1603	loadk        r20   k49 ; k49 = 233
.line	1603	call          r3    18     2
.line	1603	call          r2     2     2
.line	1603	getupval      r3    u4
.line	1603	getupval      r4    u1
.line	1603	loadk         r5   k53 ; k53 = 37
.line	1603	loadk         r6   k54 ; k54 = 170
.line	1603	loadk         r7    k2 ; k2 = 42
.line	1603	loadk         r8   k55 ; k55 = 220
.line	1603	loadk         r9   k56 ; k56 = 221
.line	1603	loadk        r10    k8 ; k8 = 43
.line	1603	loadk        r11   k12 ; k12 = 143
.line	1603	loadk        r12   k19 ; k19 = 67
.line	1603	loadk        r13   k57 ; k57 = 159
.line	1603	loadk        r14   k56 ; k56 = 221
.line	1603	loadk        r15    k3 ; k3 = 200
.line	1603	loadk        r16   k33 ; k33 = 9
.line	1603	loadk        r17   k30 ; k30 = 89
.line	1603	call          r4    14     2
.line	1603	call          r3     2     2
.line	1603	gettable      r4    r2   k58 ; k58 = "Conv_FloatToText"
.line	1603	move          r5    r0
.line	1603	gettable      r6    r3   k59 ; k59 = "HalfToEven"
.line	1603	loadbool      r7     1     0
.line	1603	loadk         r8   k51 ; k51 = 1
.line	1603	loadk         r9   k52 ; k52 = 324
.line	1603	move         r10    r1
.line	1603	move         r11    r1
.line	1603	tailcall      r4     8
.line	1603	return        r4     0
.line	1603	return        r0     1
.line	1603	move          r0    r0
.line	1603	gettabup      r3    u1   k52 ; k52 = 324
.line	1603	return        r0     1

.function	main/f112

.source	null
.linedefined	1618
.lastlinedefined	1627
.numparams	0
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	37	true
.upvalue	"U1"	1	true
.upvalue	"U2"	0	false
.upvalue	"U3"	24	true

.constant	k0	40
.constant	k1	188
.constant	k2	217
.constant	k3	197
.constant	k4	42
.constant	k5	175
.constant	k6	67
.constant	k7	139
.constant	k8	228
.constant	k9	198
.constant	k10	3
.constant	k11	95
.constant	k12	36
.constant	k13	76
.constant	k14	192
.constant	k15	195
.constant	k16	191
.constant	k17	92
.constant	k18	237
.constant	k19	32
.constant	k20	23
.constant	k21	"log"
.constant	k22	"bWriteLog"
.constant	k23	"table"
.constant	k24	"concat"
.constant	k25	38
.constant	k26	141
.constant	k27	43
.constant	k28	202
.constant	k29	230
.constant	k30	59
.constant	k31	143
.constant	k32	65
.constant	k33	214
.constant	k34	215
.constant	k35	194
.constant	k36	25
.constant	k37	116
.constant	k38	5
.constant	k39	104
.constant	k40	212
.constant	k41	173
.constant	k42	124
.constant	k43	247
.constant	k44	48
.constant	k45	11
.constant	k46	115
.constant	k47	229
.constant	k48	254
.constant	k49	0
.constant	k50	113
.constant	k51	93
.constant	k52	240
.constant	k53	168
.constant	k54	83
.constant	k55	236
.constant	k56	26
.constant	k57	1
.constant	k58	245
.constant	k59	121
.constant	k60	150
.constant	k61	204
.constant	k62	250
.constant	k63	181
.constant	k64	90
.constant	k65	145
.constant	k66	196
.constant	k67	6
.constant	k68	97
.constant	k69	"Client"
.constant	k70	"GetHDmpveInstanceId"
.constant	k71	220
.constant	k72	13
.constant	k73	46
.constant	k74	151
.constant	k75	12
.constant	k76	205

.line	1618	getupval      r0    u0
.line	1618	getupval      r1    u1
.line	1618	loadk         r2    k0 ; k0 = 40
.line	1618	loadk         r3    k1 ; k1 = 188
.line	1618	loadk         r4    k0 ; k0 = 40
.line	1618	loadk         r5    k2 ; k2 = 217
.line	1618	loadk         r6    k3 ; k3 = 197
.line	1618	loadk         r7    k4 ; k4 = 42
.line	1618	loadk         r8    k5 ; k5 = 175
.line	1618	loadk         r9    k6 ; k6 = 67
.line	1618	loadk        r10    k7 ; k7 = 139
.line	1618	loadk        r11    k8 ; k8 = 228
.line	1618	loadk        r12    k9 ; k9 = 198
.line	1618	loadk        r13   k10 ; k10 = 3
.line	1618	loadk        r14   k11 ; k11 = 95
.line	1618	loadk        r15   k12 ; k12 = 36
.line	1618	loadk        r16   k13 ; k13 = 76
.line	1618	loadk        r17   k14 ; k14 = 192
.line	1618	loadk        r18   k15 ; k15 = 195
.line	1618	loadk        r19   k16 ; k16 = 191
.line	1618	loadk        r20   k17 ; k17 = 92
.line	1618	loadk        r21   k18 ; k18 = 237
.line	1618	loadk        r22   k19 ; k19 = 32
.line	1618	loadk        r23   k20 ; k20 = 23
.line	1618	call          r1    23     2
.line	1618	loadbool      r2     0     0
.line	1618	call          r0     3     2
.line	1618	gettabup      r1    u2   k21 ; k21 = "log"
.line	1618	gettabup      r2    u2   k22 ; k22 = "bWriteLog"
.line	1618	test          r2     0
.line	1618	jmp            0   l99
.line	1618	gettabup      r2    u2   k23 ; k23 = "table"
.line	1618	gettable      r2    r2   k24 ; k24 = "concat"
.line	1618	newtable      r3     1     0
.line	1618	getupval      r4    u1
.line	1618	loadk         r5   k25 ; k25 = 38
.line	1618	loadk         r6   k26 ; k26 = 141
.line	1618	loadk         r7   k27 ; k27 = 43
.line	1618	loadk         r8   k28 ; k28 = 202
.line	1618	loadk         r9   k29 ; k29 = 230
.line	1618	loadk        r10   k30 ; k30 = 59
.line	1618	loadk        r11   k31 ; k31 = 143
.line	1618	loadk        r12   k32 ; k32 = 65
.line	1618	loadk        r13   k33 ; k33 = 214
.line	1618	loadk        r14   k34 ; k34 = 215
.line	1618	loadk        r15   k35 ; k35 = 194
.line	1618	loadk        r16   k36 ; k36 = 25
.line	1618	loadk        r17   k37 ; k37 = 116
.line	1618	loadk        r18   k38 ; k38 = 5
.line	1618	loadk        r19   k39 ; k39 = 104
.line	1618	loadk        r20   k40 ; k40 = 212
.line	1618	loadk        r21   k29 ; k29 = 230
.line	1618	loadk        r22   k41 ; k41 = 173
.line	1618	loadk        r23   k42 ; k42 = 124
.line	1618	loadk        r24   k43 ; k43 = 247
.line	1618	loadk        r25   k44 ; k44 = 48
.line	1618	loadk        r26   k45 ; k45 = 11
.line	1618	loadk        r27   k43 ; k43 = 247
.line	1618	loadk        r28   k46 ; k46 = 115
.line	1618	loadk        r29    k7 ; k7 = 139
.line	1618	loadk        r30   k47 ; k47 = 229
.line	1618	loadk        r31   k48 ; k48 = 254
.line	1618	loadk        r32   k36 ; k36 = 25
.line	1618	loadk        r33   k49 ; k49 = 0
.line	1618	loadk        r34   k50 ; k50 = 113
.line	1618	loadk        r35   k51 ; k51 = 93
.line	1618	loadk        r36   k52 ; k52 = 240
.line	1618	loadk        r37   k18 ; k18 = 237
.line	1618	loadk        r38   k53 ; k53 = 168
.line	1618	loadk        r39   k54 ; k54 = 83
.line	1618	loadk        r40   k55 ; k55 = 236
.line	1618	loadk        r41   k56 ; k56 = 26
.line	1618	loadk        r42   k57 ; k57 = 1
.line	1618	loadk        r43   k58 ; k58 = 245
.line	1618	loadk        r44   k59 ; k59 = 121
.line	1618	call          r4    41     2
.line	1618	getupval      r5    u1
.line	1618	loadk         r6   k57 ; k57 = 1
.line	1618	loadk         r7   k60 ; k60 = 150
.line	1618	loadk         r8   k25 ; k25 = 38
.line	1618	loadk         r9   k61 ; k61 = 204
.line	1618	loadk        r10   k62 ; k62 = 250
.line	1618	loadk        r11   k27 ; k27 = 43
.line	1618	loadk        r12   k63 ; k63 = 181
.line	1618	loadk        r13   k64 ; k64 = 90
.line	1618	loadk        r14   k65 ; k65 = 145
.line	1618	loadk        r15    k8 ; k8 = 228
.line	1618	loadk        r16   k66 ; k66 = 196
.line	1618	loadk        r17   k38 ; k38 = 5
.line	1618	loadk        r18   k67 ; k67 = 6
.line	1618	loadk        r19   k68 ; k68 = 97
.line	1618	call          r5    15     0
.line	1618	setlist       r3     0     1
.line	1618	call          r2     2     2
.line	1618	getupval      r3    u3
.line	1618	move          r4    r0
.line	1618	call          r3     2     2
.line	1618	concat        r2    r2    r3
.label	l99
.line	1618	call          r1     2     1
.line	1618	test          r0     0
.line	1618	jmp            0  l174
.line	1618	gettabup      r1    u2   k69 ; k69 = "Client"
.line	1618	gettable      r1    r1   k70 ; k70 = "GetHDmpveInstanceId"
.line	1618	test          r1     0
.line	1618	jmp            0  l174
.line	1618	gettabup      r1    u2   k69 ; k69 = "Client"
.line	1618	gettable      r1    r1   k70 ; k70 = "GetHDmpveInstanceId"
.line	1618	call          r1     1     2
.line	1618	gettabup      r2    u2   k21 ; k21 = "log"
.line	1618	gettabup      r3    u2   k22 ; k22 = "bWriteLog"
.line	1618	test          r3     0
.line	1618	jmp            0  l172
.line	1618	gettabup      r3    u2   k23 ; k23 = "table"
.line	1618	gettable      r3    r3   k24 ; k24 = "concat"
.line	1618	newtable      r4     1     0
.line	1618	getupval      r5    u1
.line	1618	loadk         r6   k25 ; k25 = 38
.line	1618	loadk         r7   k26 ; k26 = 141
.line	1618	loadk         r8   k27 ; k27 = 43
.line	1618	loadk         r9   k28 ; k28 = 202
.line	1618	loadk        r10   k29 ; k29 = 230
.line	1618	loadk        r11   k30 ; k30 = 59
.line	1618	loadk        r12   k31 ; k31 = 143
.line	1618	loadk        r13   k32 ; k32 = 65
.line	1618	loadk        r14   k33 ; k33 = 214
.line	1618	loadk        r15   k34 ; k34 = 215
.line	1618	loadk        r16   k35 ; k35 = 194
.line	1618	loadk        r17   k36 ; k36 = 25
.line	1618	loadk        r18   k37 ; k37 = 116
.line	1618	loadk        r19   k38 ; k38 = 5
.line	1618	loadk        r20   k39 ; k39 = 104
.line	1618	loadk        r21   k40 ; k40 = 212
.line	1618	loadk        r22   k29 ; k29 = 230
.line	1618	loadk        r23   k41 ; k41 = 173
.line	1618	loadk        r24   k42 ; k42 = 124
.line	1618	loadk        r25   k43 ; k43 = 247
.line	1618	loadk        r26   k44 ; k44 = 48
.line	1618	loadk        r27   k45 ; k45 = 11
.line	1618	loadk        r28   k43 ; k43 = 247
.line	1618	loadk        r29   k46 ; k46 = 115
.line	1618	loadk        r30    k7 ; k7 = 139
.line	1618	loadk        r31   k47 ; k47 = 229
.line	1618	loadk        r32   k48 ; k48 = 254
.line	1618	loadk        r33   k36 ; k36 = 25
.line	1618	loadk        r34   k49 ; k49 = 0
.line	1618	loadk        r35   k50 ; k50 = 113
.line	1618	loadk        r36   k51 ; k51 = 93
.line	1618	loadk        r37   k52 ; k52 = 240
.line	1618	loadk        r38   k18 ; k18 = 237
.line	1618	loadk        r39   k53 ; k53 = 168
.line	1618	loadk        r40   k54 ; k54 = 83
.line	1618	loadk        r41   k55 ; k55 = 236
.line	1618	loadk        r42   k56 ; k56 = 26
.line	1618	loadk        r43   k57 ; k57 = 1
.line	1618	loadk        r44   k58 ; k58 = 245
.line	1618	loadk        r45   k59 ; k59 = 121
.line	1618	call          r5    41     2
.line	1618	getupval      r6    u1
.line	1618	loadk         r7   k57 ; k57 = 1
.line	1618	loadk         r8   k60 ; k60 = 150
.line	1618	loadk         r9   k25 ; k25 = 38
.line	1618	loadk        r10   k61 ; k61 = 204
.line	1618	loadk        r11   k62 ; k62 = 250
.line	1618	loadk        r12   k27 ; k27 = 43
.line	1618	loadk        r13   k71 ; k71 = 220
.line	1618	loadk        r14   k72 ; k72 = 13
.line	1618	call          r6     9     0
.line	1618	setlist       r4     0     1
.line	1618	call          r3     2     2
.line	1618	move          r4    r1
.line	1618	concat        r3    r3    r4
.label	l172
.line	1618	call          r2     2     1
.line	1618	return        r1     2
.label	l174
.line	1618	getupval      r1    u1
.line	1618	loadk         r2   k73 ; k73 = 46
.line	1618	loadk         r3   k74 ; k74 = 151
.line	1618	loadk         r4   k75 ; k75 = 12
.line	1618	loadk         r5   k76 ; k76 = 205
.line	1618	call          r1     5     2
.line	1618	return        r1     2
.line	1618	return        r0     1
.line	1618	gettabup      r0    u1   k55 ; k55 = 236
.line	1618	move          r0    r0
.line	1618	return        r0     1

.function	main/f113

.source	null
.linedefined	1629
.lastlinedefined	1638
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	4	true
.upvalue	"U2"	1	true
.upvalue	"U3"	24	true
.upvalue	"U4"	37	true

.constant	k0	nil
.constant	k1	"log"
.constant	k2	"bWriteLog"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	38
.constant	k7	141
.constant	k8	43
.constant	k9	202
.constant	k10	230
.constant	k11	59
.constant	k12	143
.constant	k13	65
.constant	k14	214
.constant	k15	215
.constant	k16	194
.constant	k17	25
.constant	k18	116
.constant	k19	5
.constant	k20	104
.constant	k21	212
.constant	k22	173
.constant	k23	103
.constant	k24	252
.constant	k25	46
.constant	k26	16
.constant	k27	226
.constant	k28	120
.constant	k29	171
.constant	k30	239
.constant	k31	217
.constant	k32	27
.constant	k33	69
.constant	k34	54
.constant	k35	148
.constant	k36	235
.constant	k37	189
.constant	k38	92
.constant	k39	180
.constant	k40	118
.constant	k41	28
.constant	k42	170
.constant	k43	45
.constant	k44	4
.constant	k45	157
.constant	k46	35
.constant	k47	200
.constant	k48	198
.constant	k49	146
.constant	k50	123
.constant	k51	153
.constant	k52	154
.constant	k53	72
.constant	k54	79

.line	1629	eq             0    r1    k0 ; k0 = nil
.line	1629	jmp            0    l4
.line	1629	loadbool      r1     0     0
.label	l4
.line	1629	gettabup      r2    u0    k1 ; k1 = "log"
.line	1629	gettabup      r3    u0    k2 ; k2 = "bWriteLog"
.line	1629	test          r3     0
.line	1629	jmp            0   l78
.line	1629	gettabup      r3    u1    k3 ; k3 = "format"
.line	1629	gettabup      r4    u0    k4 ; k4 = "table"
.line	1629	gettable      r4    r4    k5 ; k5 = "concat"
.line	1629	newtable      r5     1     0
.line	1629	getupval      r6    u2
.line	1629	loadk         r7    k6 ; k6 = 38
.line	1629	loadk         r8    k7 ; k7 = 141
.line	1629	loadk         r9    k8 ; k8 = 43
.line	1629	loadk        r10    k9 ; k9 = 202
.line	1629	loadk        r11   k10 ; k10 = 230
.line	1629	loadk        r12   k11 ; k11 = 59
.line	1629	loadk        r13   k12 ; k12 = 143
.line	1629	loadk        r14   k13 ; k13 = 65
.line	1629	loadk        r15   k14 ; k14 = 214
.line	1629	loadk        r16   k15 ; k15 = 215
.line	1629	loadk        r17   k16 ; k16 = 194
.line	1629	loadk        r18   k17 ; k17 = 25
.line	1629	loadk        r19   k18 ; k18 = 116
.line	1629	loadk        r20   k19 ; k19 = 5
.line	1629	loadk        r21   k20 ; k20 = 104
.line	1629	loadk        r22   k21 ; k21 = 212
.line	1629	loadk        r23   k10 ; k10 = 230
.line	1629	loadk        r24   k22 ; k22 = 173
.line	1629	loadk        r25   k23 ; k23 = 103
.line	1629	loadk        r26   k24 ; k24 = 252
.line	1629	loadk        r27   k25 ; k25 = 46
.line	1629	loadk        r28   k26 ; k26 = 16
.line	1629	loadk        r29   k27 ; k27 = 226
.line	1629	loadk        r30   k28 ; k28 = 120
.line	1629	loadk        r31   k29 ; k29 = 171
.line	1629	loadk        r32   k30 ; k30 = 239
.line	1629	loadk        r33   k31 ; k31 = 217
.line	1629	loadk        r34   k32 ; k32 = 27
.line	1629	loadk        r35   k33 ; k33 = 69
.line	1629	loadk        r36   k34 ; k34 = 54
.line	1629	loadk        r37   k11 ; k11 = 59
.line	1629	loadk        r38   k35 ; k35 = 148
.line	1629	loadk        r39   k36 ; k36 = 235
.line	1629	loadk        r40   k37 ; k37 = 189
.line	1629	loadk        r41   k38 ; k38 = 92
.line	1629	loadk        r42   k39 ; k39 = 180
.line	1629	loadk        r43   k40 ; k40 = 118
.line	1629	loadk        r44   k41 ; k41 = 28
.line	1629	loadk        r45   k42 ; k42 = 170
.line	1629	loadk        r46   k43 ; k43 = 45
.line	1629	call          r6    41     2
.line	1629	getupval      r7    u2
.line	1629	loadk         r8   k44 ; k44 = 4
.line	1629	loadk         r9   k45 ; k45 = 157
.line	1629	loadk        r10   k46 ; k46 = 35
.line	1629	loadk        r11   k47 ; k47 = 200
.line	1629	loadk        r12   k48 ; k48 = 198
.line	1629	loadk        r13   k46 ; k46 = 35
.line	1629	loadk        r14   k49 ; k49 = 146
.line	1629	loadk        r15   k50 ; k50 = 123
.line	1629	loadk        r16   k51 ; k51 = 153
.line	1629	loadk        r17   k24 ; k24 = 252
.line	1629	loadk        r18   k52 ; k52 = 154
.line	1629	loadk        r19   k53 ; k53 = 72
.line	1629	loadk        r20   k54 ; k54 = 79
.line	1629	call          r7    14     0
.line	1629	setlist       r5     0     1
.line	1629	call          r4     2     2
.line	1629	getupval      r5    u3
.line	1629	move          r6    r0
.line	1629	call          r5     2     2
.line	1629	getupval      r6    u3
.line	1629	move          r7    r1
.line	1629	call          r6     2     0
.line	1629	call          r3     0     2
.label	l78
.line	1629	call          r2     2     1
.line	1629	eq             0    r0    k0 ; k0 = nil
.line	1629	jmp            0   l82
.line	1629	return        r1     2
.label	l82
.line	1629	getupval      r2    u4
.line	1629	move          r3    r0
.line	1629	move          r4    r1
.line	1629	tailcall      r2     3
.line	1629	return        r2     0
.line	1629	return        r0     1
.line	1629	move          r0    r0
.line	1629	move          r0    r0
.line	1629	return        r0     1

.function	main/f114

.source	null
.linedefined	1640
.lastlinedefined	1664
.numparams	2
.is_vararg	0
.maxstacksize	12

.upvalue	"_ENV"	1	true
.upvalue	"U1"	0	false
.upvalue	"U2"	23	true

.constant	k0	1
.constant	k1	"math"
.constant	k2	"max"
.constant	k3	0

.line	1640	test          r0     0
.line	1640	jmp            0    l7
.line	1640	getupval      r2    u0
.line	1640	call          r2     1     2
.line	1640	eq             0    r0    r2
.line	1640	jmp            0    l9
.label	l7
.line	1640	loadbool      r2     0     0
.line	1640	return        r2     2
.label	l9
.line	1640	test          r1     0
.line	1640	jmp            0   l15
.line	1640	getupval      r2    u0
.line	1640	call          r2     1     2
.line	1640	eq             0    r1    r2
.line	1640	jmp            0   l17
.label	l15
.line	1640	loadbool      r2     1     0
.line	1640	return        r2     2
.label	l17
.line	1640	closure       r2    f0
.line	1640	move          r3    r2
.line	1640	move          r4    r0
.line	1640	call          r3     2     2
.line	1640	move          r4    r2
.line	1640	move          r5    r1
.line	1640	call          r4     2     2
.line	1640	loadk         r5    k0 ; k0 = 1
.line	1640	gettabup      r6    u1    k1 ; k1 = "math"
.line	1640	gettable      r6    r6    k2 ; k2 = "max"
.line	1640	len           r7    r3
.line	1640	len           r8    r4
.line	1640	call          r6     3     2
.line	1640	loadk         r7    k0 ; k0 = 1
.line	1640	move          r0    r0
.line	1640	gettable      r9    r3    r8
.line	1640	test          r9     1
.line	1640	jmp            0   l36
.line	1640	loadk         r9    k3 ; k3 = 0
.label	l36
.line	1640	gettable     r10    r4    r8
.line	1640	test         r10     1
.line	1640	jmp            0   l40
.line	1640	loadk        r10    k3 ; k3 = 0
.label	l40
.line	1640	eq             1    r9   r10
.line	1640	jmp            0   l47
.line	1640	le             1   r10    r9
.line	1640	jmp            0   l45
.line	1640	loadbool     r11     0     1
.label	l45
.line	1640	loadbool     r11     1     0
.line	1640	return       r11     2
.label	l47
.line	1640	move          r0    r0
.line	1640	loadbool      r5     0     0
.line	1640	return        r5     2
.line	1640	return        r0     1
.line	1640	move          r0    r0
.line	1640	move          r0    r0
.line	1640	move          r0    r0
.line	1640	return        r0     1

.function	main/f114/f0

.source	null
.linedefined	1647
.lastlinedefined	1653
.numparams	1
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	2	false

.constant	k0	"gmatch"
.constant	k1	72
.constant	k2	221
.constant	k3	33
.constant	k4	130
.constant	k5	154
.constant	k6	"table"
.constant	k7	"insert"

.line	1647	newtable      r1     0     0
.line	1647	self          r2    r0    k0 ; k0 = "gmatch"
.line	1647	getupval      r4    u0
.line	1647	loadk         r5    k1 ; k1 = 72
.line	1647	loadk         r6    k2 ; k2 = 221
.line	1647	loadk         r7    k3 ; k3 = 33
.line	1647	loadk         r8    k4 ; k4 = 130
.line	1647	loadk         r9    k5 ; k5 = 154
.line	1647	call          r4     6     2
.line	1647	call          r2     3     4
.line	1647	jmp            0   l19
.line	1647	gettabup      r6    u1    k6 ; k6 = "table"
.line	1647	gettable      r6    r6    k7 ; k7 = "insert"
.line	1647	move          r7    r1
.line	1647	getupval      r8    u2
.line	1647	move          r9    r5
.line	1647	call          r8     2     0
.line	1647	call          r6     0     1
.label	l19
.line	1647	move          r0    r0
.line	1647	move          r0    r0
.line	1647	return        r1     2
.line	1647	return        r0     1
.line	1647	move          r0    r0
.line	1647	return        r0     1

.function	main/f115

.source	null
.linedefined	1666
.lastlinedefined	1688
.numparams	1
.is_vararg	0
.maxstacksize	12

.upvalue	"_ENV"	1	true
.upvalue	"U1"	0	false
.upvalue	"U2"	23	true

.constant	k0	"Client"
.constant	k1	"GetApplicationVersion"
.constant	k2	1
.constant	k3	"math"
.constant	k4	"max"
.constant	k5	0

.line	1666	test          r0     0
.line	1666	jmp            0    l7
.line	1666	getupval      r1    u0
.line	1666	call          r1     1     2
.line	1666	eq             0    r0    r1
.line	1666	jmp            0    l9
.label	l7
.line	1666	loadbool      r1     0     0
.line	1666	return        r1     2
.label	l9
.line	1666	closure       r1    f0
.line	1666	gettabup      r2    u1    k0 ; k0 = "Client"
.line	1666	gettable      r2    r2    k1 ; k1 = "GetApplicationVersio" (truncated)
.line	1666	call          r2     1     2
.line	1666	move          r3    r1
.line	1666	move          r4    r0
.line	1666	call          r3     2     2
.line	1666	move          r4    r1
.line	1666	move          r5    r2
.line	1666	call          r4     2     2
.line	1666	loadk         r5    k2 ; k2 = 1
.line	1666	gettabup      r6    u1    k3 ; k3 = "math"
.line	1666	gettable      r6    r6    k4 ; k4 = "max"
.line	1666	len           r7    r3
.line	1666	len           r8    r4
.line	1666	call          r6     3     2
.line	1666	loadk         r7    k2 ; k2 = 1
.line	1666	move          r0    r0
.line	1666	gettable      r9    r3    r8
.line	1666	test          r9     1
.line	1666	jmp            0   l31
.line	1666	loadk         r9    k5 ; k5 = 0
.label	l31
.line	1666	gettable     r10    r4    r8
.line	1666	test         r10     1
.line	1666	jmp            0   l35
.line	1666	loadk        r10    k5 ; k5 = 0
.label	l35
.line	1666	eq             1    r9   r10
.line	1666	jmp            0   l42
.line	1666	lt             1   r10    r9
.line	1666	jmp            0   l40
.line	1666	loadbool     r11     0     1
.label	l40
.line	1666	loadbool     r11     1     0
.line	1666	return       r11     2
.label	l42
.line	1666	move          r0    r0
.line	1666	loadbool      r5     0     0
.line	1666	return        r5     2
.line	1666	return        r0     1
.line	1666	move          r0    r0
.line	1666	move          r0    r0
.line	1666	move          r0    r0
.line	1666	move          r0    r0
.line	1666	return        r0     1

.function	main/f115/f0

.source	null
.linedefined	1670
.lastlinedefined	1676
.numparams	1
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	2	false

.constant	k0	"gmatch"
.constant	k1	72
.constant	k2	221
.constant	k3	33
.constant	k4	130
.constant	k5	154
.constant	k6	"table"
.constant	k7	"insert"

.line	1670	newtable      r1     0     0
.line	1670	self          r2    r0    k0 ; k0 = "gmatch"
.line	1670	getupval      r4    u0
.line	1670	loadk         r5    k1 ; k1 = 72
.line	1670	loadk         r6    k2 ; k2 = 221
.line	1670	loadk         r7    k3 ; k3 = 33
.line	1670	loadk         r8    k4 ; k4 = 130
.line	1670	loadk         r9    k5 ; k5 = 154
.line	1670	call          r4     6     2
.line	1670	call          r2     3     4
.line	1670	jmp            0   l19
.line	1670	gettabup      r6    u1    k6 ; k6 = "table"
.line	1670	gettable      r6    r6    k7 ; k7 = "insert"
.line	1670	move          r7    r1
.line	1670	getupval      r8    u2
.line	1670	move          r9    r5
.line	1670	call          r8     2     0
.line	1670	call          r6     0     1
.label	l19
.line	1670	move          r0    r0
.line	1670	move          r0    r0
.line	1670	return        r1     2
.line	1670	return        r0     1
.line	1670	move          r0    r0
.line	1670	move          r0    r0
.line	1670	move          r0    r0
.line	1670	move          r0    r0
.line	1670	return        r0     1

.function	main/f116

.source	null
.linedefined	1690
.lastlinedefined	1698
.numparams	2
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	0	false

.constant	k0	"FuncUtil"
.constant	k1	"CompareVersion"
.constant	k2	"Client"
.constant	k3	"GetApplicationVersion"

.line	1690	gettabup      r2    u0    k0 ; k0 = "FuncUtil"
.line	1690	gettable      r2    r2    k1 ; k1 = "CompareVersion"
.line	1690	move          r3    r1
.line	1690	move          r4    r0
.line	1690	call          r2     3     2
.line	1690	test          r2     1
.line	1690	jmp            0   l10
.line	1690	loadbool      r2     0     0
.line	1690	return        r2     2
.label	l10
.line	1690	gettabup      r2    u0    k2 ; k2 = "Client"
.line	1690	gettable      r2    r2    k3 ; k3 = "GetApplicationVersio" (truncated)
.line	1690	call          r2     1     2
.line	1690	gettabup      r3    u0    k0 ; k0 = "FuncUtil"
.line	1690	gettable      r3    r3    k1 ; k1 = "CompareVersion"
.line	1690	move          r4    r2
.line	1690	move          r5    r0
.line	1690	call          r3     3     2
.line	1690	gettabup      r4    u0    k0 ; k0 = "FuncUtil"
.line	1690	gettable      r4    r4    k1 ; k1 = "CompareVersion"
.line	1690	move          r5    r1
.line	1690	move          r6    r2
.line	1690	call          r4     3     2
.line	1690	testset       r5    r3     0
.line	1690	jmp            0   l26
.line	1690	move          r5    r4
.label	l26
.line	1690	return        r5     2
.line	1690	return        r0     1
.line	1690	move          r0    r0
.line	1690	move          r0    r0
.line	1690	move          r0    r0
.line	1690	move          r0    r0
.line	1690	return        r0     1

.function	main/f117

.source	null
.linedefined	1700
.lastlinedefined	1719
.numparams	2
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	34	true
.upvalue	"U1"	1	true
.upvalue	"U2"	0	false
.upvalue	"U3"	24	true
.upvalue	"U4"	28	true

.constant	k0	"HDmpveRemoteConfigGetBool"
.constant	k1	37
.constant	k2	150
.constant	k3	36
.constant	k4	203
.constant	k5	223
.constant	k6	42
.constant	k7	160
.constant	k8	65
.constant	k9	141
.constant	k10	227
.constant	k11	207
.constant	k12	44
.constant	k13	79
.constant	k14	56
.constant	k15	107
.constant	k16	199
.constant	k17	220
.constant	k18	167
.constant	k19	84
.constant	k20	253
.constant	k21	17
.constant	k22	241
.constant	k23	"HDmpveRemoteConfigGetInt"
.constant	k24	38
.constant	k25	148
.constant	k26	48
.constant	k27	218
.constant	k28	219
.constant	k29	14
.constant	k30	149
.constant	k31	243
.constant	k32	235
.constant	k33	2
.constant	k34	93
.constant	k35	108
.constant	k36	202
.constant	k37	247
.constant	k38	132
.constant	k39	90
.constant	k40	254
.constant	k41	15
.constant	k42	26
.constant	k43	224
.constant	k44	120
.constant	k45	0
.constant	k46	"log"
.constant	k47	"bWriteLog"
.constant	k48	"table"
.constant	k49	"concat"
.constant	k50	43
.constant	k51	230
.constant	k52	59
.constant	k53	143
.constant	k54	214
.constant	k55	215
.constant	k56	8
.constant	k57	82
.constant	k58	7
.constant	k59	105
.constant	k60	209
.constant	k61	116
.constant	k62	234
.constant	k63	58
.constant	k64	245
.constant	k65	81
.constant	k66	135
.constant	k67	225
.constant	k68	211
.constant	k69	20
.constant	k70	66
.constant	k71	54
.constant	k72	53
.constant	k73	238
.constant	k74	185
.constant	k75	71
.constant	k76	229
.constant	k77	41
.constant	k78	19
.constant	k79	144
.constant	k80	4
.constant	k81	33
.constant	k82	133
.constant	k83	97
.constant	k84	151
.constant	k85	195
.constant	k86	63
.constant	k87	64
.constant	k88	190
.constant	k89	192
.constant	k90	39
.constant	k91	94
.constant	k92	129
.constant	k93	196
.constant	k94	83
.constant	k95	32
.constant	k96	205
.constant	k97	175
.constant	k98	121
.constant	k99	246
.constant	k100	51
.constant	k101	236
.constant	k102	172
.constant	k103	216
.constant	k104	9
.constant	k105	76
.constant	k106	157
.constant	k107	154
.constant	k108	10
.constant	k109	217
.constant	k110	61
.constant	k111	106
.constant	k112	153
.constant	k113	194
.constant	k114	50
.constant	k115	113
.constant	k116	197
.constant	k117	171
.constant	k118	80
.constant	k119	"GetInstance"
.constant	k120	"ExecuteCMD"
.constant	k121	85
.constant	k122	249
.constant	k123	240
.constant	k124	55
.constant	k125	6
.constant	k126	1
.constant	k127	114
.constant	k128	124
.constant	k129	212
.constant	k130	222
.constant	k131	30

.line	1700	gettabup      r2    u0    k0 ; k0 = "HDmpveRemoteConfigGe" (truncated)
.line	1700	getupval      r3    u1
.line	1700	loadk         r4    k1 ; k1 = 37
.line	1700	loadk         r5    k2 ; k2 = 150
.line	1700	loadk         r6    k3 ; k3 = 36
.line	1700	loadk         r7    k4 ; k4 = 203
.line	1700	loadk         r8    k5 ; k5 = 223
.line	1700	loadk         r9    k6 ; k6 = 42
.line	1700	loadk        r10    k7 ; k7 = 160
.line	1700	loadk        r11    k8 ; k8 = 65
.line	1700	loadk        r12    k9 ; k9 = 141
.line	1700	loadk        r13   k10 ; k10 = 227
.line	1700	loadk        r14   k11 ; k11 = 207
.line	1700	loadk        r15   k12 ; k12 = 44
.line	1700	loadk        r16   k13 ; k13 = 79
.line	1700	loadk        r17   k14 ; k14 = 56
.line	1700	loadk        r18   k15 ; k15 = 107
.line	1700	loadk        r19   k16 ; k16 = 199
.line	1700	loadk        r20   k17 ; k17 = 220
.line	1700	loadk        r21   k18 ; k18 = 167
.line	1700	loadk        r22   k19 ; k19 = 84
.line	1700	loadk        r23   k20 ; k20 = 253
.line	1700	loadk        r24    k6 ; k6 = 42
.line	1700	loadk        r25   k21 ; k21 = 17
.line	1700	loadk        r26   k22 ; k22 = 241
.line	1700	call          r3    24     2
.line	1700	loadbool      r4     0     0
.line	1700	call          r2     3     2
.line	1700	gettabup      r3    u0   k23 ; k23 = "HDmpveRemoteConfigGe" (truncated)
.line	1700	getupval      r4    u1
.line	1700	loadk         r5   k24 ; k24 = 38
.line	1700	loadk         r6   k25 ; k25 = 148
.line	1700	loadk         r7   k26 ; k26 = 48
.line	1700	loadk         r8   k27 ; k27 = 218
.line	1700	loadk         r9   k28 ; k28 = 219
.line	1700	loadk        r10   k29 ; k29 = 14
.line	1700	loadk        r11   k30 ; k30 = 149
.line	1700	loadk        r12   k19 ; k19 = 84
.line	1700	loadk        r13    k2 ; k2 = 150
.line	1700	loadk        r14   k31 ; k31 = 243
.line	1700	loadk        r15   k32 ; k32 = 235
.line	1700	loadk        r16   k33 ; k33 = 2
.line	1700	loadk        r17   k34 ; k34 = 93
.line	1700	loadk        r18    k1 ; k1 = 37
.line	1700	loadk        r19   k35 ; k35 = 108
.line	1700	loadk        r20   k36 ; k36 = 202
.line	1700	loadk        r21   k37 ; k37 = 247
.line	1700	loadk        r22   k38 ; k38 = 132
.line	1700	loadk        r23   k39 ; k39 = 90
.line	1700	loadk        r24   k40 ; k40 = 254
.line	1700	loadk        r25   k41 ; k41 = 15
.line	1700	loadk        r26   k42 ; k42 = 26
.line	1700	loadk        r27   k43 ; k43 = 224
.line	1700	loadk        r28   k44 ; k44 = 120
.line	1700	loadk        r29   k38 ; k38 = 132
.line	1700	call          r4    26     2
.line	1700	loadk         r5   k45 ; k45 = 0
.line	1700	call          r3     3     2
.line	1700	test          r1     1
.line	1700	jmp            0   l62
.line	1700	loadk         r1   k45 ; k45 = 0
.label	l62
.line	1700	gettabup      r4    u2   k46 ; k46 = "log"
.line	1700	gettabup      r5    u2   k47 ; k47 = "bWriteLog"
.line	1700	test          r5     0
.line	1700	jmp            0  l194
.line	1700	gettabup      r5    u2   k48 ; k48 = "table"
.line	1700	gettable      r5    r5   k49 ; k49 = "concat"
.line	1700	newtable      r6     1     0
.line	1700	getupval      r7    u1
.line	1700	loadk         r8   k24 ; k24 = 38
.line	1700	loadk         r9    k9 ; k9 = 141
.line	1700	loadk        r10   k50 ; k50 = 43
.line	1700	loadk        r11   k36 ; k36 = 202
.line	1700	loadk        r12   k51 ; k51 = 230
.line	1700	loadk        r13   k52 ; k52 = 59
.line	1700	loadk        r14   k53 ; k53 = 143
.line	1700	loadk        r15    k8 ; k8 = 65
.line	1700	loadk        r16   k54 ; k54 = 214
.line	1700	loadk        r17    k5 ; k5 = 223
.line	1700	loadk        r18   k55 ; k55 = 215
.line	1700	loadk        r19   k56 ; k56 = 8
.line	1700	loadk        r20   k57 ; k57 = 82
.line	1700	loadk        r21   k58 ; k58 = 7
.line	1700	loadk        r22   k59 ; k59 = 105
.line	1700	loadk        r23   k60 ; k60 = 209
.line	1700	loadk        r24   k10 ; k10 = 227
.line	1700	loadk        r25    k7 ; k7 = 160
.line	1700	loadk        r26   k61 ; k61 = 116
.line	1700	loadk        r27   k62 ; k62 = 234
.line	1700	loadk        r28   k63 ; k63 = 58
.line	1700	loadk        r29   k21 ; k21 = 17
.line	1700	loadk        r30   k64 ; k64 = 245
.line	1700	loadk        r31   k65 ; k65 = 81
.line	1700	loadk        r32   k66 ; k66 = 135
.line	1700	loadk        r33   k67 ; k67 = 225
.line	1700	loadk        r34   k68 ; k68 = 211
.line	1700	loadk        r35   k69 ; k69 = 20
.line	1700	loadk        r36   k70 ; k70 = 66
.line	1700	loadk        r37   k71 ; k71 = 54
.line	1700	loadk        r38   k72 ; k72 = 53
.line	1700	loadk        r39   k22 ; k22 = 241
.line	1700	loadk        r40   k73 ; k73 = 238
.line	1700	loadk        r41   k74 ; k74 = 185
.line	1700	loadk        r42   k75 ; k75 = 71
.line	1700	loadk        r43   k76 ; k76 = 229
.line	1700	loadk        r44   k71 ; k71 = 54
.line	1700	loadk        r45   k77 ; k77 = 41
.line	1700	loadk        r46   k62 ; k62 = 234
.line	1700	loadk        r47   k44 ; k44 = 120
.line	1700	call          r7    41     2
.line	1700	getupval      r8    u1
.line	1700	loadk         r9   k78 ; k78 = 19
.line	1700	loadk        r10   k79 ; k79 = 144
.line	1700	loadk        r11   k80 ; k80 = 4
.line	1700	loadk        r12   k27 ; k27 = 218
.line	1700	loadk        r13   k36 ; k36 = 202
.line	1700	loadk        r14   k81 ; k81 = 33
.line	1700	loadk        r15   k82 ; k82 = 133
.line	1700	loadk        r16   k83 ; k83 = 97
.line	1700	loadk        r17   k84 ; k84 = 151
.line	1700	loadk        r18   k22 ; k22 = 241
.line	1700	loadk        r19   k85 ; k85 = 195
.line	1700	loadk        r20   k80 ; k80 = 4
.line	1700	loadk        r21   k57 ; k57 = 82
.line	1700	loadk        r22   k24 ; k24 = 38
.line	1700	loadk        r23   k86 ; k86 = 63
.line	1700	call          r8    16     0
.line	1700	setlist       r6     0     1
.line	1700	call          r5     2     2
.line	1700	getupval      r6    u3
.line	1700	move          r7    r2
.line	1700	call          r6     2     2
.line	1700	getupval      r7    u1
.line	1700	loadk         r8   k87 ; k87 = 64
.line	1700	loadk         r9   k88 ; k88 = 190
.line	1700	loadk        r10   k77 ; k77 = 41
.line	1700	loadk        r11   k17 ; k17 = 220
.line	1700	loadk        r12   k89 ; k89 = 192
.line	1700	loadk        r13   k90 ; k90 = 39
.line	1700	loadk        r14   k18 ; k18 = 167
.line	1700	loadk        r15   k91 ; k91 = 94
.line	1700	loadk        r16   k92 ; k92 = 129
.line	1700	loadk        r17   k40 ; k40 = 254
.line	1700	loadk        r18   k93 ; k93 = 196
.line	1700	loadk        r19   k81 ; k81 = 33
.line	1700	loadk        r20   k94 ; k94 = 83
.line	1700	loadk        r21   k95 ; k95 = 32
.line	1700	loadk        r22   k83 ; k83 = 97
.line	1700	loadk        r23   k96 ; k96 = 205
.line	1700	loadk        r24   k40 ; k40 = 254
.line	1700	loadk        r25   k97 ; k97 = 175
.line	1700	loadk        r26   k98 ; k98 = 121
.line	1700	loadk        r27   k99 ; k99 = 246
.line	1700	loadk        r28    k3 ; k3 = 36
.line	1700	loadk        r29  k100 ; k100 = 51
.line	1700	loadk        r30   k31 ; k31 = 243
.line	1700	loadk        r31   k15 ; k15 = 107
.line	1700	loadk        r32    k9 ; k9 = 141
.line	1700	loadk        r33  k101 ; k101 = 236
.line	1700	loadk        r34    k9 ; k9 = 141
.line	1700	call          r7    28     2
.line	1700	getupval      r8    u3
.line	1700	move          r9    r3
.line	1700	call          r8     2     2
.line	1700	getupval      r9    u1
.line	1700	loadk        r10   k87 ; k87 = 64
.line	1700	loadk        r11  k102 ; k102 = 172
.line	1700	loadk        r12   k12 ; k12 = 44
.line	1700	loadk        r13   k36 ; k36 = 202
.line	1700	loadk        r14  k103 ; k103 = 216
.line	1700	loadk        r15  k104 ; k104 = 9
.line	1700	loadk        r16   k25 ; k25 = 148
.line	1700	loadk        r17  k105 ; k105 = 76
.line	1700	loadk        r18   k30 ; k30 = 149
.line	1700	loadk        r19   k64 ; k64 = 245
.line	1700	loadk        r20  k106 ; k106 = 157
.line	1700	call          r9    12     2
.line	1700	getupval     r10    u3
.line	1700	move         r11    r1
.line	1700	call         r10     2     2
.line	1700	getupval     r11    u1
.line	1700	loadk        r12   k87 ; k87 = 64
.line	1700	loadk        r13  k107 ; k107 = 154
.line	1700	loadk        r14  k108 ; k108 = 10
.line	1700	loadk        r15  k109 ; k109 = 217
.line	1700	loadk        r16   k54 ; k54 = 214
.line	1700	loadk        r17   k81 ; k81 = 33
.line	1700	loadk        r18   k17 ; k17 = 220
.line	1700	call         r11     8     2
.line	1700	getupval     r12    u3
.line	1700	move         r13    r0
.line	1700	call         r12     2     2
.line	1700	concat        r5    r5   r12
.label	l194
.line	1700	call          r4     2     1
.line	1700	test          r2     1
.line	1700	jmp            0  l198
.line	1700	return        r0     1
.label	l198
.line	1700	getupval      r4    u4
.line	1700	getupval      r5    u1
.line	1700	loadk         r6  k100 ; k100 = 51
.line	1700	loadk         r7  k102 ; k102 = 172
.line	1700	loadk         r8   k45 ; k45 = 0
.line	1700	loadk         r9   k60 ; k60 = 209
.line	1700	loadk        r10   k16 ; k16 = 199
.line	1700	loadk        r11  k110 ; k110 = 61
.line	1700	loadk        r12   k66 ; k66 = 135
.line	1700	loadk        r13  k111 ; k111 = 106
.line	1700	loadk        r14  k112 ; k112 = 153
.line	1700	loadk        r15   k20 ; k20 = 253
.line	1700	loadk        r16  k113 ; k113 = 194
.line	1700	loadk        r17    k3 ; k3 = 36
.line	1700	loadk        r18   k57 ; k57 = 82
.line	1700	loadk        r19  k114 ; k114 = 50
.line	1700	loadk        r20  k115 ; k115 = 113
.line	1700	loadk        r21  k116 ; k116 = 197
.line	1700	loadk        r22   k40 ; k40 = 254
.line	1700	loadk        r23  k117 ; k117 = 171
.line	1700	loadk        r24  k118 ; k118 = 80
.line	1700	call          r5    20     2
.line	1700	call          r4     2     2
.line	1700	gettable      r5    r4  k119 ; k119 = "GetInstance"
.line	1700	call          r5     1     2
.line	1700	test          r0     0
.line	1700	jmp            0  l317
.line	1700	self          r6    r5  k120 ; k120 = "ExecuteCMD"
.line	1700	getupval      r8    u1
.line	1700	loadk         r9   k78 ; k78 = 19
.line	1700	loadk        r10   k54 ; k54 = 214
.line	1700	loadk        r11   k80 ; k80 = 4
.line	1700	loadk        r12   k27 ; k27 = 218
.line	1700	loadk        r13   k36 ; k36 = 202
.line	1700	loadk        r14   k81 ; k81 = 33
.line	1700	loadk        r15   k82 ; k82 = 133
.line	1700	loadk        r16   k83 ; k83 = 97
.line	1700	loadk        r17   k84 ; k84 = 151
.line	1700	loadk        r18   k22 ; k22 = 241
.line	1700	loadk        r19   k85 ; k85 = 195
.line	1700	loadk        r20   k80 ; k80 = 4
.line	1700	loadk        r21   k57 ; k57 = 82
.line	1700	loadk        r22   k24 ; k24 = 38
.line	1700	loadk        r23  k121 ; k121 = 85
.line	1700	loadk        r24   k54 ; k54 = 214
.line	1700	loadk        r25  k122 ; k122 = 249
.line	1700	loadk        r26   k18 ; k18 = 167
.line	1700	loadk        r27   k75 ; k75 = 71
.line	1700	loadk        r28  k123 ; k123 = 240
.line	1700	loadk        r29  k124 ; k124 = 55
.line	1700	loadk        r30  k125 ; k125 = 6
.line	1700	call          r8    23     2
.line	1700	loadk         r9  k126 ; k126 = 1
.line	1700	call          r6     4     1
.line	1700	self          r6    r5  k120 ; k120 = "ExecuteCMD"
.line	1700	getupval      r8    u1
.line	1700	loadk         r9   k78 ; k78 = 19
.line	1700	loadk        r10   k54 ; k54 = 214
.line	1700	loadk        r11   k80 ; k80 = 4
.line	1700	loadk        r12   k27 ; k27 = 218
.line	1700	loadk        r13   k36 ; k36 = 202
.line	1700	loadk        r14   k81 ; k81 = 33
.line	1700	loadk        r15   k82 ; k82 = 133
.line	1700	loadk        r16   k83 ; k83 = 97
.line	1700	loadk        r17   k84 ; k84 = 151
.line	1700	loadk        r18   k22 ; k22 = 241
.line	1700	loadk        r19   k85 ; k85 = 195
.line	1700	loadk        r20   k80 ; k80 = 4
.line	1700	loadk        r21   k57 ; k57 = 82
.line	1700	loadk        r22   k24 ; k24 = 38
.line	1700	loadk        r23  k121 ; k121 = 85
.line	1700	loadk        r24   k54 ; k54 = 214
.line	1700	loadk        r25  k122 ; k122 = 249
.line	1700	loadk        r26   k18 ; k18 = 167
.line	1700	loadk        r27   k75 ; k75 = 71
.line	1700	loadk        r28  k123 ; k123 = 240
.line	1700	loadk        r29  k124 ; k124 = 55
.line	1700	loadk        r30  k125 ; k125 = 6
.line	1700	loadk        r31   k27 ; k27 = 218
.line	1700	loadk        r32  k127 ; k127 = 114
.line	1700	loadk        r33   k53 ; k53 = 143
.line	1700	call          r8    26     2
.line	1700	move          r9    r3
.line	1700	call          r6     4     1
.line	1700	self          r6    r5  k120 ; k120 = "ExecuteCMD"
.line	1700	getupval      r8    u1
.line	1700	loadk         r9   k78 ; k78 = 19
.line	1700	loadk        r10   k54 ; k54 = 214
.line	1700	loadk        r11   k80 ; k80 = 4
.line	1700	loadk        r12   k27 ; k27 = 218
.line	1700	loadk        r13   k36 ; k36 = 202
.line	1700	loadk        r14   k81 ; k81 = 33
.line	1700	loadk        r15   k82 ; k82 = 133
.line	1700	loadk        r16   k83 ; k83 = 97
.line	1700	loadk        r17   k84 ; k84 = 151
.line	1700	loadk        r18   k22 ; k22 = 241
.line	1700	loadk        r19   k85 ; k85 = 195
.line	1700	loadk        r20   k80 ; k80 = 4
.line	1700	loadk        r21   k57 ; k57 = 82
.line	1700	loadk        r22   k24 ; k24 = 38
.line	1700	loadk        r23  k121 ; k121 = 85
.line	1700	loadk        r24   k54 ; k54 = 214
.line	1700	loadk        r25  k122 ; k122 = 249
.line	1700	loadk        r26   k18 ; k18 = 167
.line	1700	loadk        r27   k75 ; k75 = 71
.line	1700	loadk        r28  k123 ; k123 = 240
.line	1700	loadk        r29  k124 ; k124 = 55
.line	1700	loadk        r30  k125 ; k125 = 6
.line	1700	loadk        r31   k28 ; k28 = 219
.line	1700	loadk        r32  k128 ; k128 = 124
.line	1700	loadk        r33   k79 ; k79 = 144
.line	1700	loadk        r34  k129 ; k129 = 212
.line	1700	loadk        r35  k130 ; k130 = 222
.line	1700	loadk        r36  k131 ; k131 = 30
.line	1700	loadk        r37   k75 ; k75 = 71
.line	1700	call          r8    30     2
.line	1700	move          r9    r1
.line	1700	call          r6     4     1
.line	1700	jmp            0  l408
.label	l317
.line	1700	self          r6    r5  k120 ; k120 = "ExecuteCMD"
.line	1700	getupval      r8    u1
.line	1700	loadk         r9   k78 ; k78 = 19
.line	1700	loadk        r10   k54 ; k54 = 214
.line	1700	loadk        r11   k80 ; k80 = 4
.line	1700	loadk        r12   k27 ; k27 = 218
.line	1700	loadk        r13   k36 ; k36 = 202
.line	1700	loadk        r14   k81 ; k81 = 33
.line	1700	loadk        r15   k82 ; k82 = 133
.line	1700	loadk        r16   k83 ; k83 = 97
.line	1700	loadk        r17   k84 ; k84 = 151
.line	1700	loadk        r18   k22 ; k22 = 241
.line	1700	loadk        r19   k85 ; k85 = 195
.line	1700	loadk        r20   k80 ; k80 = 4
.line	1700	loadk        r21   k57 ; k57 = 82
.line	1700	loadk        r22   k24 ; k24 = 38
.line	1700	loadk        r23  k121 ; k121 = 85
.line	1700	loadk        r24   k54 ; k54 = 214
.line	1700	loadk        r25  k122 ; k122 = 249
.line	1700	loadk        r26   k18 ; k18 = 167
.line	1700	loadk        r27   k75 ; k75 = 71
.line	1700	loadk        r28  k123 ; k123 = 240
.line	1700	loadk        r29  k124 ; k124 = 55
.line	1700	loadk        r30  k125 ; k125 = 6
.line	1700	call          r8    23     2
.line	1700	loadk         r9   k45 ; k45 = 0
.line	1700	call          r6     4     1
.line	1700	self          r6    r5  k120 ; k120 = "ExecuteCMD"
.line	1700	getupval      r8    u1
.line	1700	loadk         r9   k78 ; k78 = 19
.line	1700	loadk        r10   k54 ; k54 = 214
.line	1700	loadk        r11   k80 ; k80 = 4
.line	1700	loadk        r12   k27 ; k27 = 218
.line	1700	loadk        r13   k36 ; k36 = 202
.line	1700	loadk        r14   k81 ; k81 = 33
.line	1700	loadk        r15   k82 ; k82 = 133
.line	1700	loadk        r16   k83 ; k83 = 97
.line	1700	loadk        r17   k84 ; k84 = 151
.line	1700	loadk        r18   k22 ; k22 = 241
.line	1700	loadk        r19   k85 ; k85 = 195
.line	1700	loadk        r20   k80 ; k80 = 4
.line	1700	loadk        r21   k57 ; k57 = 82
.line	1700	loadk        r22   k24 ; k24 = 38
.line	1700	loadk        r23  k121 ; k121 = 85
.line	1700	loadk        r24   k54 ; k54 = 214
.line	1700	loadk        r25  k122 ; k122 = 249
.line	1700	loadk        r26   k18 ; k18 = 167
.line	1700	loadk        r27   k75 ; k75 = 71
.line	1700	loadk        r28  k123 ; k123 = 240
.line	1700	loadk        r29  k124 ; k124 = 55
.line	1700	loadk        r30  k125 ; k125 = 6
.line	1700	loadk        r31   k27 ; k27 = 218
.line	1700	loadk        r32  k127 ; k127 = 114
.line	1700	loadk        r33   k53 ; k53 = 143
.line	1700	call          r8    26     2
.line	1700	loadk         r9   k45 ; k45 = 0
.line	1700	call          r6     4     1
.line	1700	self          r6    r5  k120 ; k120 = "ExecuteCMD"
.line	1700	getupval      r8    u1
.line	1700	loadk         r9   k78 ; k78 = 19
.line	1700	loadk        r10   k54 ; k54 = 214
.line	1700	loadk        r11   k80 ; k80 = 4
.line	1700	loadk        r12   k27 ; k27 = 218
.line	1700	loadk        r13   k36 ; k36 = 202
.line	1700	loadk        r14   k81 ; k81 = 33
.line	1700	loadk        r15   k82 ; k82 = 133
.line	1700	loadk        r16   k83 ; k83 = 97
.line	1700	loadk        r17   k84 ; k84 = 151
.line	1700	loadk        r18   k22 ; k22 = 241
.line	1700	loadk        r19   k85 ; k85 = 195
.line	1700	loadk        r20   k80 ; k80 = 4
.line	1700	loadk        r21   k57 ; k57 = 82
.line	1700	loadk        r22   k24 ; k24 = 38
.line	1700	loadk        r23  k121 ; k121 = 85
.line	1700	loadk        r24   k54 ; k54 = 214
.line	1700	loadk        r25  k122 ; k122 = 249
.line	1700	loadk        r26   k18 ; k18 = 167
.line	1700	loadk        r27   k75 ; k75 = 71
.line	1700	loadk        r28  k123 ; k123 = 240
.line	1700	loadk        r29  k124 ; k124 = 55
.line	1700	loadk        r30  k125 ; k125 = 6
.line	1700	loadk        r31   k28 ; k28 = 219
.line	1700	loadk        r32  k128 ; k128 = 124
.line	1700	loadk        r33   k79 ; k79 = 144
.line	1700	loadk        r34  k129 ; k129 = 212
.line	1700	loadk        r35  k130 ; k130 = 222
.line	1700	loadk        r36  k131 ; k131 = 30
.line	1700	loadk        r37   k75 ; k75 = 71
.line	1700	call          r8    30     2
.line	1700	loadk         r9   k45 ; k45 = 0
.line	1700	call          r6     4     1
.label	l408
.line	1700	return        r0     1
.line	1700	move          r0    r0
.line	1700	move          r0    r0
.line	1700	return        r0     1

.function	main/f118

.source	null
.linedefined	1721
.lastlinedefined	1737
.numparams	0
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	34	true
.upvalue	"U1"	1	true
.upvalue	"U2"	0	false
.upvalue	"U3"	24	true
.upvalue	"U4"	28	true

.constant	k0	"HDmpveRemoteConfigGetBool"
.constant	k1	34
.constant	k2	153
.constant	k3	38
.constant	k4	194
.constant	k5	195
.constant	k6	46
.constant	k7	133
.constant	k8	70
.constant	k9	186
.constant	k10	252
.constant	k11	210
.constant	k12	8
.constant	k13	76
.constant	k14	51
.constant	k15	108
.constant	k16	202
.constant	k17	228
.constant	k18	140
.constant	k19	80
.constant	k20	245
.constant	k21	24
.constant	k22	247
.constant	k23	105
.constant	k24	141
.constant	k25	196
.constant	k26	17
.constant	k27	77
.constant	k28	40
.constant	k29	218
.constant	k30	225
.constant	k31	73
.constant	k32	236
.constant	k33	"HDmpveRemoteConfigGetInt"
.constant	k34	"table"
.constant	k35	"concat"
.constant	k36	219
.constant	k37	35
.constant	k38	88
.constant	k39	221
.constant	k40	238
.constant	k41	158
.constant	k42	87
.constant	k43	232
.constant	k44	62
.constant	k45	10
.constant	k46	197
.constant	k47	99
.constant	k48	20
.constant	k49	211
.constant	k50	214
.constant	k51	27
.constant	k52	23
.constant	k53	69
.constant	k54	231
.constant	k55	30
.constant	k56	212
.constant	k57	28
.constant	k58	64
.constant	k59	52
.constant	k60	71
.constant	k61	213
.constant	k62	244
.constant	k63	177
.constant	k64	74
.constant	k65	"log"
.constant	k66	"bWriteLog"
.constant	k67	43
.constant	k68	230
.constant	k69	59
.constant	k70	143
.constant	k71	65
.constant	k72	207
.constant	k73	95
.constant	k74	42
.constant	k75	243
.constant	k76	163
.constant	k77	248
.constant	k78	32
.constant	k79	113
.constant	k80	157
.constant	k81	229
.constant	k82	199
.constant	k83	15
.constant	k84	63
.constant	k85	97
.constant	k86	240
.constant	k87	180
.constant	k88	50
.constant	k89	227
.constant	k90	5
.constant	k91	148
.constant	k92	36
.constant	k93	208
.constant	k94	246
.constant	k95	33
.constant	k96	135
.constant	k97	79
.constant	k98	47
.constant	k99	93
.constant	k100	110
.constant	k101	241
.constant	k102	171
.constant	k103	94
.constant	k104	109
.constant	k105	154
.constant	k106	233
.constant	k107	217
.constant	k108	9
.constant	k109	104
.constant	k110	121
.constant	k111	209
.constant	k112	185
.constant	k113	81
.constant	k114	234
.constant	k115	25
.constant	k116	189
.constant	k117	200
.constant	k118	131
.constant	k119	216
.constant	k120	78
.constant	k121	147
.constant	k122	203
.constant	k123	89
.constant	k124	49
.constant	k125	119
.constant	k126	205
.constant	k127	254
.constant	k128	188
.constant	k129	26
.constant	k130	124
.constant	k131	156
.constant	k132	48
.constant	k133	103
.constant	k134	249
.constant	k135	182
.constant	k136	251
.constant	k137	2
.constant	k138	14
.constant	k139	127
.constant	k140	83
.constant	k141	226
.constant	k142	61
.constant	k143	112
.constant	k144	172
.constant	k145	0
.constant	k146	106
.constant	k147	253
.constant	k148	82
.constant	k149	"GetInstance"
.constant	k150	"ExecuteCMD"
.constant	k151	19
.constant	k152	45
.constant	k153	138
.constant	k154	72
.constant	k155	6
.constant	k156	102
.constant	k157	164
.constant	k158	13
.constant	k159	255
.constant	k160	115
.constant	k161	54
.constant	k162	116
.constant	k163	192
.constant	k164	22
.constant	k165	1
.constant	k166	7
.constant	k167	150
.constant	k168	155
.constant	k169	117
.constant	k170	166
.constant	k171	122
.constant	k172	137
.constant	k173	198
.constant	k174	75
.constant	k175	235
.constant	k176	55
.constant	k177	242
.constant	k178	139
.constant	k179	224
.constant	k180	60

.line	1721	gettabup      r0    u0    k0 ; k0 = "HDmpveRemoteConfigGe" (truncated)
.line	1721	getupval      r1    u1
.line	1721	loadk         r2    k1 ; k1 = 34
.line	1721	loadk         r3    k2 ; k2 = 153
.line	1721	loadk         r4    k3 ; k3 = 38
.line	1721	loadk         r5    k4 ; k4 = 194
.line	1721	loadk         r6    k5 ; k5 = 195
.line	1721	loadk         r7    k6 ; k6 = 46
.line	1721	loadk         r8    k7 ; k7 = 133
.line	1721	loadk         r9    k8 ; k8 = 70
.line	1721	loadk        r10    k9 ; k9 = 186
.line	1721	loadk        r11   k10 ; k10 = 252
.line	1721	loadk        r12   k11 ; k11 = 210
.line	1721	loadk        r13   k12 ; k12 = 8
.line	1721	loadk        r14   k13 ; k13 = 76
.line	1721	loadk        r15   k14 ; k14 = 51
.line	1721	loadk        r16   k15 ; k15 = 108
.line	1721	loadk        r17   k16 ; k16 = 202
.line	1721	loadk        r18   k17 ; k17 = 228
.line	1721	loadk        r19   k18 ; k18 = 140
.line	1721	loadk        r20   k19 ; k19 = 80
.line	1721	loadk        r21   k20 ; k20 = 245
.line	1721	loadk        r22    k3 ; k3 = 38
.line	1721	loadk        r23   k21 ; k21 = 24
.line	1721	loadk        r24   k22 ; k22 = 247
.line	1721	loadk        r25   k23 ; k23 = 105
.line	1721	loadk        r26   k24 ; k24 = 141
.line	1721	loadk        r27   k25 ; k25 = 196
.line	1721	loadk        r28   k11 ; k11 = 210
.line	1721	loadk        r29   k26 ; k26 = 17
.line	1721	loadk        r30   k27 ; k27 = 77
.line	1721	loadk        r31   k28 ; k28 = 40
.line	1721	loadk        r32   k19 ; k19 = 80
.line	1721	loadk        r33   k29 ; k29 = 218
.line	1721	loadk        r34   k30 ; k30 = 225
.line	1721	loadk        r35    k9 ; k9 = 186
.line	1721	loadk        r36   k31 ; k31 = 73
.line	1721	loadk        r37   k32 ; k32 = 236
.line	1721	call          r1    37     2
.line	1721	loadbool      r2     0     0
.line	1721	call          r0     3     2
.line	1721	gettabup      r1    u0   k33 ; k33 = "HDmpveRemoteConfigGe" (truncated)
.line	1721	gettabup      r2    u2   k34 ; k34 = "table"
.line	1721	gettable      r2    r2   k35 ; k35 = "concat"
.line	1721	newtable      r3     1     0
.line	1721	getupval      r4    u1
.line	1721	loadk         r5    k1 ; k1 = 34
.line	1721	loadk         r6    k2 ; k2 = 153
.line	1721	loadk         r7    k3 ; k3 = 38
.line	1721	loadk         r8    k4 ; k4 = 194
.line	1721	loadk         r9    k5 ; k5 = 195
.line	1721	loadk        r10    k6 ; k6 = 46
.line	1721	loadk        r11    k7 ; k7 = 133
.line	1721	loadk        r12    k8 ; k8 = 70
.line	1721	loadk        r13    k9 ; k9 = 186
.line	1721	loadk        r14   k10 ; k10 = 252
.line	1721	loadk        r15   k11 ; k11 = 210
.line	1721	loadk        r16   k12 ; k12 = 8
.line	1721	loadk        r17   k13 ; k13 = 76
.line	1721	loadk        r18   k14 ; k14 = 51
.line	1721	loadk        r19   k15 ; k15 = 108
.line	1721	loadk        r20   k16 ; k16 = 202
.line	1721	loadk        r21   k17 ; k17 = 228
.line	1721	loadk        r22   k18 ; k18 = 140
.line	1721	loadk        r23   k19 ; k19 = 80
.line	1721	loadk        r24   k20 ; k20 = 245
.line	1721	loadk        r25    k3 ; k3 = 38
.line	1721	loadk        r26   k21 ; k21 = 24
.line	1721	loadk        r27   k22 ; k22 = 247
.line	1721	loadk        r28   k23 ; k23 = 105
.line	1721	loadk        r29   k24 ; k24 = 141
.line	1721	loadk        r30    k5 ; k5 = 195
.line	1721	loadk        r31   k36 ; k36 = 219
.line	1721	loadk        r32   k21 ; k21 = 24
.line	1721	loadk        r33   k27 ; k27 = 77
.line	1721	loadk        r34   k37 ; k37 = 35
.line	1721	loadk        r35   k38 ; k38 = 88
.line	1721	loadk        r36   k39 ; k39 = 221
.line	1721	loadk        r37   k40 ; k40 = 238
.line	1721	loadk        r38   k41 ; k41 = 158
.line	1721	loadk        r39   k42 ; k42 = 87
.line	1721	loadk        r40   k43 ; k43 = 232
.line	1721	loadk        r41   k44 ; k44 = 62
.line	1721	loadk        r42   k45 ; k45 = 10
.line	1721	loadk        r43   k46 ; k46 = 197
.line	1721	loadk        r44   k47 ; k47 = 99
.line	1721	call          r4    41     2
.line	1721	getupval      r5    u1
.line	1721	loadk         r6   k48 ; k48 = 20
.line	1721	call          r5     2     0
.line	1721	setlist       r3     0     1
.line	1721	call          r2     2     2
.line	1721	loadk         r3   k48 ; k48 = 20
.line	1721	call          r1     3     2
.line	1721	gettabup      r2    u0   k33 ; k33 = "HDmpveRemoteConfigGe" (truncated)
.line	1721	getupval      r3    u1
.line	1721	loadk         r4    k1 ; k1 = 34
.line	1721	loadk         r5    k2 ; k2 = 153
.line	1721	loadk         r6    k3 ; k3 = 38
.line	1721	loadk         r7    k4 ; k4 = 194
.line	1721	loadk         r8    k5 ; k5 = 195
.line	1721	loadk         r9    k6 ; k6 = 46
.line	1721	loadk        r10    k7 ; k7 = 133
.line	1721	loadk        r11    k8 ; k8 = 70
.line	1721	loadk        r12    k9 ; k9 = 186
.line	1721	loadk        r13   k10 ; k10 = 252
.line	1721	loadk        r14   k11 ; k11 = 210
.line	1721	loadk        r15   k12 ; k12 = 8
.line	1721	loadk        r16   k13 ; k13 = 76
.line	1721	loadk        r17   k14 ; k14 = 51
.line	1721	loadk        r18   k15 ; k15 = 108
.line	1721	loadk        r19   k16 ; k16 = 202
.line	1721	loadk        r20   k17 ; k17 = 228
.line	1721	loadk        r21   k18 ; k18 = 140
.line	1721	loadk        r22   k19 ; k19 = 80
.line	1721	loadk        r23   k20 ; k20 = 245
.line	1721	loadk        r24    k3 ; k3 = 38
.line	1721	loadk        r25   k21 ; k21 = 24
.line	1721	loadk        r26   k22 ; k22 = 247
.line	1721	loadk        r27   k23 ; k23 = 105
.line	1721	loadk        r28   k24 ; k24 = 141
.line	1721	loadk        r29   k49 ; k49 = 211
.line	1721	loadk        r30   k50 ; k50 = 214
.line	1721	loadk        r31   k51 ; k51 = 27
.line	1721	loadk        r32   k31 ; k31 = 73
.line	1721	loadk        r33   k52 ; k52 = 23
.line	1721	loadk        r34   k53 ; k53 = 69
.line	1721	loadk        r35   k54 ; k54 = 231
.line	1721	call          r3    33     2
.line	1721	loadk         r4   k55 ; k55 = 30
.line	1721	call          r2     3     2
.line	1721	gettabup      r3    u0   k33 ; k33 = "HDmpveRemoteConfigGe" (truncated)
.line	1721	getupval      r4    u1
.line	1721	loadk         r5    k1 ; k1 = 34
.line	1721	loadk         r6    k2 ; k2 = 153
.line	1721	loadk         r7    k3 ; k3 = 38
.line	1721	loadk         r8    k4 ; k4 = 194
.line	1721	loadk         r9    k5 ; k5 = 195
.line	1721	loadk        r10    k6 ; k6 = 46
.line	1721	loadk        r11    k7 ; k7 = 133
.line	1721	loadk        r12    k8 ; k8 = 70
.line	1721	loadk        r13    k9 ; k9 = 186
.line	1721	loadk        r14   k10 ; k10 = 252
.line	1721	loadk        r15   k11 ; k11 = 210
.line	1721	loadk        r16   k12 ; k12 = 8
.line	1721	loadk        r17   k13 ; k13 = 76
.line	1721	loadk        r18   k14 ; k14 = 51
.line	1721	loadk        r19   k15 ; k15 = 108
.line	1721	loadk        r20   k16 ; k16 = 202
.line	1721	loadk        r21   k17 ; k17 = 228
.line	1721	loadk        r22   k18 ; k18 = 140
.line	1721	loadk        r23   k19 ; k19 = 80
.line	1721	loadk        r24   k20 ; k20 = 245
.line	1721	loadk        r25    k3 ; k3 = 38
.line	1721	loadk        r26   k21 ; k21 = 24
.line	1721	loadk        r27   k22 ; k22 = 247
.line	1721	loadk        r28   k23 ; k23 = 105
.line	1721	loadk        r29   k24 ; k24 = 141
.line	1721	loadk        r30   k49 ; k49 = 211
.line	1721	loadk        r31   k56 ; k56 = 212
.line	1721	loadk        r32   k57 ; k57 = 28
.line	1721	loadk        r33   k58 ; k58 = 64
.line	1721	loadk        r34   k59 ; k59 = 52
.line	1721	loadk        r35   k60 ; k60 = 71
.line	1721	loadk        r36   k61 ; k61 = 213
.line	1721	loadk        r37   k62 ; k62 = 244
.line	1721	loadk        r38   k63 ; k63 = 177
.line	1721	loadk        r39   k64 ; k64 = 74
.line	1721	call          r4    36     2
.line	1721	loadk         r5   k48 ; k48 = 20
.line	1721	call          r3     3     2
.line	1721	gettabup      r4    u2   k65 ; k65 = "log"
.line	1721	gettabup      r5    u2   k66 ; k66 = "bWriteLog"
.line	1721	test          r5     0
.line	1721	jmp            0  l415
.line	1721	gettabup      r5    u2   k34 ; k34 = "table"
.line	1721	gettable      r5    r5   k35 ; k35 = "concat"
.line	1721	newtable      r6     2     0
.line	1721	getupval      r7    u1
.line	1721	loadk         r8    k3 ; k3 = 38
.line	1721	loadk         r9   k24 ; k24 = 141
.line	1721	loadk        r10   k67 ; k67 = 43
.line	1721	loadk        r11   k16 ; k16 = 202
.line	1721	loadk        r12   k68 ; k68 = 230
.line	1721	loadk        r13   k69 ; k69 = 59
.line	1721	loadk        r14   k70 ; k70 = 143
.line	1721	loadk        r15   k71 ; k71 = 65
.line	1721	loadk        r16   k50 ; k50 = 214
.line	1721	loadk        r17   k49 ; k49 = 211
.line	1721	loadk        r18   k72 ; k72 = 207
.line	1721	loadk        r19   k12 ; k12 = 8
.line	1721	loadk        r20   k73 ; k73 = 95
.line	1721	loadk        r21   k74 ; k74 = 42
.line	1721	loadk        r22   k60 ; k60 = 71
.line	1721	loadk        r23   k46 ; k46 = 197
.line	1721	loadk        r24   k75 ; k75 = 243
.line	1721	loadk        r25   k76 ; k76 = 163
.line	1721	loadk        r26   k53 ; k53 = 69
.line	1721	loadk        r27   k77 ; k77 = 248
.line	1721	loadk        r28   k78 ; k78 = 32
.line	1721	loadk        r29   k48 ; k48 = 20
.line	1721	loadk        r30   k56 ; k56 = 212
.line	1721	loadk        r31   k79 ; k79 = 113
.line	1721	loadk        r32   k80 ; k80 = 157
.line	1721	loadk        r33   k81 ; k81 = 229
.line	1721	loadk        r34   k82 ; k82 = 199
.line	1721	loadk        r35   k83 ; k83 = 15
.line	1721	loadk        r36   k53 ; k53 = 69
.line	1721	loadk        r37   k84 ; k84 = 63
.line	1721	loadk        r38   k85 ; k85 = 97
.line	1721	loadk        r39   k86 ; k86 = 240
.line	1721	loadk        r40   k81 ; k81 = 229
.line	1721	loadk        r41   k87 ; k87 = 180
.line	1721	loadk        r42   k58 ; k58 = 64
.line	1721	loadk        r43   k40 ; k40 = 238
.line	1721	loadk        r44   k88 ; k88 = 50
.line	1721	loadk        r45   k51 ; k51 = 27
.line	1721	loadk        r46   k89 ; k89 = 227
.line	1721	loadk        r47   k31 ; k31 = 73
.line	1721	call          r7    41     2
.line	1721	getupval      r8    u1
.line	1721	loadk         r9   k90 ; k90 = 5
.line	1721	loadk        r10   k91 ; k91 = 148
.line	1721	loadk        r11   k92 ; k92 = 36
.line	1721	loadk        r12   k93 ; k93 = 208
.line	1721	loadk        r13   k94 ; k94 = 246
.line	1721	loadk        r14   k95 ; k95 = 33
.line	1721	loadk        r15   k96 ; k96 = 135
.line	1721	loadk        r16   k97 ; k97 = 79
.line	1721	loadk        r17   k91 ; k91 = 148
.line	1721	loadk        r18   k20 ; k20 = 245
.line	1721	loadk        r19   k96 ; k96 = 135
.line	1721	loadk        r20   k98 ; k98 = 47
.line	1721	loadk        r21   k99 ; k99 = 93
.line	1721	loadk        r22    k1 ; k1 = 34
.line	1721	loadk        r23  k100 ; k100 = 110
.line	1721	loadk        r24   k56 ; k56 = 212
.line	1721	loadk        r25  k101 ; k101 = 241
.line	1721	loadk        r26  k102 ; k102 = 171
.line	1721	loadk        r27  k103 ; k103 = 94
.line	1721	loadk        r28   k36 ; k36 = 219
.line	1721	loadk        r29   k98 ; k98 = 47
.line	1721	loadk        r30   k45 ; k45 = 10
.line	1721	loadk        r31   k75 ; k75 = 243
.line	1721	loadk        r32  k104 ; k104 = 109
.line	1721	loadk        r33  k105 ; k105 = 154
.line	1721	loadk        r34  k106 ; k106 = 233
.line	1721	loadk        r35  k107 ; k107 = 217
.line	1721	loadk        r36  k108 ; k108 = 9
.line	1721	loadk        r37  k109 ; k109 = 104
.line	1721	loadk        r38   k59 ; k59 = 52
.line	1721	loadk        r39  k110 ; k110 = 121
.line	1721	loadk        r40  k111 ; k111 = 209
.line	1721	loadk        r41   k54 ; k54 = 231
.line	1721	loadk        r42  k112 ; k112 = 185
.line	1721	loadk        r43  k113 ; k113 = 81
.line	1721	loadk        r44   k32 ; k32 = 236
.line	1721	loadk        r45   k52 ; k52 = 23
.line	1721	loadk        r46   k45 ; k45 = 10
.line	1721	loadk        r47  k114 ; k114 = 234
.line	1721	loadk        r48   k15 ; k15 = 108
.line	1721	call          r8    41     2
.line	1721	getupval      r9    u1
.line	1721	loadk        r10  k115 ; k115 = 25
.line	1721	loadk        r11  k116 ; k116 = 189
.line	1721	loadk        r12   k67 ; k67 = 43
.line	1721	loadk        r13  k117 ; k117 = 200
.line	1721	loadk        r14  k111 ; k111 = 209
.line	1721	loadk        r15   k37 ; k37 = 35
.line	1721	loadk        r16  k118 ; k118 = 131
.line	1721	loadk        r17   k52 ; k52 = 23
.line	1721	call          r9     9     0
.line	1721	setlist       r6     0     1
.line	1721	call          r5     2     2
.line	1721	getupval      r6    u3
.line	1721	move          r7    r0
.line	1721	call          r6     2     2
.line	1721	gettabup      r7    u2   k34 ; k34 = "table"
.line	1721	gettable      r7    r7   k35 ; k35 = "concat"
.line	1721	newtable      r8     1     0
.line	1721	getupval      r9    u1
.line	1721	loadk        r10   k58 ; k58 = 64
.line	1721	loadk        r11    k9 ; k9 = 186
.line	1721	loadk        r12   k92 ; k92 = 36
.line	1721	loadk        r13   k16 ; k16 = 202
.line	1721	loadk        r14  k119 ; k119 = 216
.line	1721	loadk        r15   k84 ; k84 = 63
.line	1721	loadk        r16   k96 ; k96 = 135
.line	1721	loadk        r17  k120 ; k120 = 78
.line	1721	loadk        r18  k121 ; k121 = 147
.line	1721	loadk        r19   k11 ; k11 = 210
.line	1721	loadk        r20  k122 ; k122 = 203
.line	1721	loadk        r21   k21 ; k21 = 24
.line	1721	loadk        r22  k123 ; k123 = 89
.line	1721	loadk        r23  k124 ; k124 = 49
.line	1721	loadk        r24  k125 ; k125 = 119
.line	1721	loadk        r25  k126 ; k126 = 205
.line	1721	loadk        r26  k127 ; k127 = 254
.line	1721	loadk        r27  k128 ; k128 = 188
.line	1721	loadk        r28   k79 ; k79 = 113
.line	1721	loadk        r29   k10 ; k10 = 252
.line	1721	loadk        r30   k98 ; k98 = 47
.line	1721	loadk        r31  k129 ; k129 = 26
.line	1721	loadk        r32  k101 ; k101 = 241
.line	1721	loadk        r33  k130 ; k130 = 124
.line	1721	loadk        r34  k131 ; k131 = 156
.line	1721	loadk        r35   k81 ; k81 = 229
.line	1721	loadk        r36   k62 ; k62 = 244
.line	1721	loadk        r37   k26 ; k26 = 17
.line	1721	loadk        r38   k31 ; k31 = 73
.line	1721	loadk        r39  k132 ; k132 = 48
.line	1721	loadk        r40  k133 ; k133 = 103
.line	1721	loadk        r41  k134 ; k134 = 249
.line	1721	loadk        r42  k106 ; k106 = 233
.line	1721	loadk        r43  k135 ; k135 = 182
.line	1721	loadk        r44   k47 ; k47 = 99
.line	1721	loadk        r45  k136 ; k136 = 251
.line	1721	loadk        r46   k88 ; k88 = 50
.line	1721	loadk        r47  k137 ; k137 = 2
.line	1721	loadk        r48   k89 ; k89 = 227
.line	1721	loadk        r49  k120 ; k120 = 78
.line	1721	call          r9    41     2
.line	1721	getupval     r10    u1
.line	1721	loadk        r11  k138 ; k138 = 14
.line	1721	loadk        r12   k18 ; k18 = 140
.line	1721	loadk        r13  k139 ; k139 = 127
.line	1721	call         r10     4     0
.line	1721	setlist       r8     0     1
.line	1721	call          r7     2     2
.line	1721	getupval      r8    u3
.line	1721	move          r9    r1
.line	1721	call          r8     2     2
.line	1721	getupval      r9    u1
.line	1721	loadk        r10   k58 ; k58 = 64
.line	1721	loadk        r11    k9 ; k9 = 186
.line	1721	loadk        r12   k92 ; k92 = 36
.line	1721	loadk        r13   k16 ; k16 = 202
.line	1721	loadk        r14  k119 ; k119 = 216
.line	1721	loadk        r15   k84 ; k84 = 63
.line	1721	loadk        r16   k96 ; k96 = 135
.line	1721	loadk        r17  k120 ; k120 = 78
.line	1721	loadk        r18  k121 ; k121 = 147
.line	1721	loadk        r19   k11 ; k11 = 210
.line	1721	loadk        r20  k122 ; k122 = 203
.line	1721	loadk        r21   k21 ; k21 = 24
.line	1721	loadk        r22  k123 ; k123 = 89
.line	1721	loadk        r23  k124 ; k124 = 49
.line	1721	loadk        r24  k125 ; k125 = 119
.line	1721	loadk        r25  k126 ; k126 = 205
.line	1721	loadk        r26  k127 ; k127 = 254
.line	1721	loadk        r27  k128 ; k128 = 188
.line	1721	loadk        r28   k79 ; k79 = 113
.line	1721	loadk        r29   k10 ; k10 = 252
.line	1721	loadk        r30   k98 ; k98 = 47
.line	1721	loadk        r31  k129 ; k129 = 26
.line	1721	loadk        r32  k101 ; k101 = 241
.line	1721	loadk        r33  k130 ; k130 = 124
.line	1721	loadk        r34  k131 ; k131 = 156
.line	1721	loadk        r35   k81 ; k81 = 229
.line	1721	loadk        r36   k17 ; k17 = 228
.line	1721	loadk        r37   k57 ; k57 = 28
.line	1721	loadk        r38   k64 ; k64 = 74
.line	1721	loadk        r39   k59 ; k59 = 52
.line	1721	loadk        r40  k140 ; k140 = 83
.line	1721	loadk        r41   k17 ; k17 = 228
.line	1721	loadk        r42   k49 ; k49 = 211
.line	1721	loadk        r43  k141 ; k141 = 226
.line	1721	call          r9    35     2
.line	1721	getupval     r10    u3
.line	1721	move         r11    r2
.line	1721	call         r10     2     2
.line	1721	getupval     r11    u1
.line	1721	loadk        r12   k58 ; k58 = 64
.line	1721	loadk        r13    k9 ; k9 = 186
.line	1721	loadk        r14   k92 ; k92 = 36
.line	1721	loadk        r15   k16 ; k16 = 202
.line	1721	loadk        r16  k119 ; k119 = 216
.line	1721	loadk        r17   k84 ; k84 = 63
.line	1721	loadk        r18   k96 ; k96 = 135
.line	1721	loadk        r19  k120 ; k120 = 78
.line	1721	loadk        r20  k121 ; k121 = 147
.line	1721	loadk        r21   k11 ; k11 = 210
.line	1721	loadk        r22  k122 ; k122 = 203
.line	1721	loadk        r23   k21 ; k21 = 24
.line	1721	loadk        r24  k123 ; k123 = 89
.line	1721	loadk        r25  k124 ; k124 = 49
.line	1721	loadk        r26  k125 ; k125 = 119
.line	1721	loadk        r27  k126 ; k126 = 205
.line	1721	loadk        r28  k127 ; k127 = 254
.line	1721	loadk        r29  k128 ; k128 = 188
.line	1721	loadk        r30   k79 ; k79 = 113
.line	1721	loadk        r31   k10 ; k10 = 252
.line	1721	loadk        r32   k98 ; k98 = 47
.line	1721	loadk        r33  k129 ; k129 = 26
.line	1721	loadk        r34  k101 ; k101 = 241
.line	1721	loadk        r35  k130 ; k130 = 124
.line	1721	loadk        r36  k131 ; k131 = 156
.line	1721	loadk        r37   k81 ; k81 = 229
.line	1721	loadk        r38   k17 ; k17 = 228
.line	1721	loadk        r39   k55 ; k55 = 30
.line	1721	loadk        r40   k27 ; k27 = 77
.line	1721	loadk        r41  k142 ; k142 = 61
.line	1721	loadk        r42  k143 ; k143 = 112
.line	1721	loadk        r43   k68 ; k68 = 230
.line	1721	loadk        r44   k30 ; k30 = 225
.line	1721	loadk        r45  k144 ; k144 = 172
.line	1721	loadk        r46   k13 ; k13 = 76
.line	1721	loadk        r47   k68 ; k68 = 230
.line	1721	loadk        r48   k23 ; k23 = 105
.line	1721	call         r11    38     2
.line	1721	getupval     r12    u3
.line	1721	move         r13    r3
.line	1721	call         r12     2     2
.line	1721	concat        r5    r5   r12
.label	l415
.line	1721	call          r4     2     1
.line	1721	getupval      r4    u4
.line	1721	getupval      r5    u1
.line	1721	loadk         r6   k14 ; k14 = 51
.line	1721	loadk         r7  k144 ; k144 = 172
.line	1721	loadk         r8  k145 ; k145 = 0
.line	1721	loadk         r9  k111 ; k111 = 209
.line	1721	loadk        r10   k82 ; k82 = 199
.line	1721	loadk        r11  k142 ; k142 = 61
.line	1721	loadk        r12   k96 ; k96 = 135
.line	1721	loadk        r13  k146 ; k146 = 106
.line	1721	loadk        r14    k2 ; k2 = 153
.line	1721	loadk        r15  k147 ; k147 = 253
.line	1721	loadk        r16    k4 ; k4 = 194
.line	1721	loadk        r17   k92 ; k92 = 36
.line	1721	loadk        r18  k148 ; k148 = 82
.line	1721	loadk        r19   k88 ; k88 = 50
.line	1721	loadk        r20   k79 ; k79 = 113
.line	1721	loadk        r21   k46 ; k46 = 197
.line	1721	loadk        r22  k127 ; k127 = 254
.line	1721	loadk        r23  k102 ; k102 = 171
.line	1721	loadk        r24   k19 ; k19 = 80
.line	1721	call          r5    20     2
.line	1721	call          r4     2     2
.line	1721	gettable      r5    r4  k149 ; k149 = "GetInstance"
.line	1721	call          r5     1     2
.line	1721	test          r0     0
.line	1721	jmp            0  l623
.line	1721	self          r6    r5  k150 ; k150 = "ExecuteCMD"
.line	1721	getupval      r8    u1
.line	1721	loadk         r9  k151 ; k151 = 19
.line	1721	loadk        r10   k50 ; k50 = 214
.line	1721	loadk        r11  k145 ; k145 = 0
.line	1721	loadk        r12   k82 ; k82 = 199
.line	1721	loadk        r13   k11 ; k11 = 210
.line	1721	loadk        r14  k152 ; k152 = 45
.line	1721	loadk        r15  k153 ; k153 = 138
.line	1721	loadk        r16  k154 ; k154 = 72
.line	1721	loadk        r17    k9 ; k9 = 186
.line	1721	loadk        r18  k101 ; k101 = 241
.line	1721	loadk        r19   k25 ; k25 = 196
.line	1721	loadk        r20  k155 ; k155 = 6
.line	1721	loadk        r21   k13 ; k13 = 76
.line	1721	loadk        r22   k78 ; k78 = 32
.line	1721	loadk        r23  k156 ; k156 = 102
.line	1721	loadk        r24   k72 ; k72 = 207
.line	1721	loadk        r25   k11 ; k11 = 210
.line	1721	loadk        r26  k157 ; k157 = 164
.line	1721	loadk        r27   k58 ; k58 = 64
.line	1721	loadk        r28   k10 ; k10 = 252
.line	1721	loadk        r29   k14 ; k14 = 51
.line	1721	loadk        r30  k158 ; k158 = 13
.line	1721	loadk        r31  k159 ; k159 = 255
.line	1721	loadk        r32  k160 ; k160 = 115
.line	1721	loadk        r33  k131 ; k131 = 156
.line	1721	loadk        r34   k25 ; k25 = 196
.line	1721	loadk        r35   k11 ; k11 = 210
.line	1721	loadk        r36   k26 ; k26 = 17
.line	1721	loadk        r37   k31 ; k31 = 73
.line	1721	loadk        r38  k161 ; k161 = 54
.line	1721	loadk        r39  k162 ; k162 = 116
.line	1721	loadk        r40  k163 ; k163 = 192
.line	1721	loadk        r41   k81 ; k81 = 229
.line	1721	loadk        r42  k131 ; k131 = 156
.line	1721	loadk        r43   k58 ; k58 = 64
.line	1721	loadk        r44   k81 ; k81 = 229
.line	1721	loadk        r45   k88 ; k88 = 50
.line	1721	loadk        r46  k164 ; k164 = 22
.line	1721	call          r8    39     2
.line	1721	loadk         r9  k165 ; k165 = 1
.line	1721	call          r6     4     1
.line	1721	self          r6    r5  k150 ; k150 = "ExecuteCMD"
.line	1721	gettabup      r8    u2   k34 ; k34 = "table"
.line	1721	gettable      r8    r8   k35 ; k35 = "concat"
.line	1721	newtable      r9     1     0
.line	1721	getupval     r10    u1
.line	1721	loadk        r11  k151 ; k151 = 19
.line	1721	loadk        r12   k50 ; k50 = 214
.line	1721	loadk        r13  k166 ; k166 = 7
.line	1721	loadk        r14  k117 ; k117 = 200
.line	1721	loadk        r15   k93 ; k93 = 208
.line	1721	loadk        r16   k92 ; k92 = 36
.line	1721	loadk        r17  k167 ; k167 = 150
.line	1721	loadk        r18   k13 ; k13 = 76
.line	1721	loadk        r19  k168 ; k168 = 155
.line	1721	loadk        r20  k136 ; k136 = 251
.line	1721	loadk        r21   k81 ; k81 = 229
.line	1721	loadk        r22  k165 ; k165 = 1
.line	1721	loadk        r23   k31 ; k31 = 73
.line	1721	loadk        r24   k92 ; k92 = 36
.line	1721	loadk        r25  k169 ; k169 = 117
.line	1721	loadk        r26   k50 ; k50 = 214
.line	1721	loadk        r27  k134 ; k134 = 249
.line	1721	loadk        r28  k170 ; k170 = 166
.line	1721	loadk        r29   k71 ; k71 = 65
.line	1721	loadk        r30   k39 ; k39 = 221
.line	1721	loadk        r31    k3 ; k3 = 38
.line	1721	loadk        r32  k151 ; k151 = 19
.line	1721	loadk        r33   k75 ; k75 = 243
.line	1721	loadk        r34  k171 ; k171 = 122
.line	1721	loadk        r35  k172 ; k172 = 137
.line	1721	loadk        r36   k62 ; k62 = 244
.line	1721	loadk        r37   k11 ; k11 = 210
.line	1721	loadk        r38   k44 ; k44 = 62
.line	1721	loadk        r39   k58 ; k58 = 64
.line	1721	loadk        r40   k59 ; k59 = 52
.line	1721	loadk        r41  k162 ; k162 = 116
.line	1721	loadk        r42  k173 ; k173 = 198
.line	1721	loadk        r43  k126 ; k126 = 205
.line	1721	loadk        r44   k63 ; k63 = 177
.line	1721	loadk        r45  k174 ; k174 = 75
.line	1721	loadk        r46   k72 ; k72 = 207
.line	1721	loadk        r47   k95 ; k95 = 33
.line	1721	loadk        r48  k138 ; k138 = 14
.line	1721	loadk        r49  k175 ; k175 = 235
.line	1721	loadk        r50  k109 ; k109 = 104
.line	1721	call         r10    41     2
.line	1721	getupval     r11    u1
.line	1721	loadk        r12   k37 ; k37 = 35
.line	1721	loadk        r13  k167 ; k167 = 150
.line	1721	loadk        r14  k124 ; k124 = 49
.line	1721	call         r11     4     0
.line	1721	setlist       r9     0     1
.line	1721	call          r8     2     2
.line	1721	move          r9    r1
.line	1721	call          r6     4     1
.line	1721	self          r6    r5  k150 ; k150 = "ExecuteCMD"
.line	1721	getupval      r8    u1
.line	1721	loadk         r9  k151 ; k151 = 19
.line	1721	loadk        r10   k50 ; k50 = 214
.line	1721	loadk        r11  k166 ; k166 = 7
.line	1721	loadk        r12  k117 ; k117 = 200
.line	1721	loadk        r13   k93 ; k93 = 208
.line	1721	loadk        r14   k92 ; k92 = 36
.line	1721	loadk        r15  k167 ; k167 = 150
.line	1721	loadk        r16   k13 ; k13 = 76
.line	1721	loadk        r17  k168 ; k168 = 155
.line	1721	loadk        r18  k136 ; k136 = 251
.line	1721	loadk        r19   k81 ; k81 = 229
.line	1721	loadk        r20  k165 ; k165 = 1
.line	1721	loadk        r21   k31 ; k31 = 73
.line	1721	loadk        r22   k92 ; k92 = 36
.line	1721	loadk        r23  k169 ; k169 = 117
.line	1721	loadk        r24   k50 ; k50 = 214
.line	1721	loadk        r25  k134 ; k134 = 249
.line	1721	loadk        r26  k170 ; k170 = 166
.line	1721	loadk        r27   k71 ; k71 = 65
.line	1721	loadk        r28   k39 ; k39 = 221
.line	1721	loadk        r29    k3 ; k3 = 38
.line	1721	loadk        r30  k151 ; k151 = 19
.line	1721	loadk        r31   k75 ; k75 = 243
.line	1721	loadk        r32  k171 ; k171 = 122
.line	1721	loadk        r33  k172 ; k172 = 137
.line	1721	loadk        r34   k62 ; k62 = 244
.line	1721	loadk        r35   k11 ; k11 = 210
.line	1721	loadk        r36    k6 ; k6 = 46
.line	1721	loadk        r37   k27 ; k27 = 77
.line	1721	loadk        r38  k176 ; k176 = 55
.line	1721	loadk        r39  k143 ; k143 = 112
.line	1721	loadk        r40  k177 ; k177 = 242
.line	1721	loadk        r41   k93 ; k93 = 208
.line	1721	loadk        r42  k178 ; k178 = 139
.line	1721	call          r8    35     2
.line	1721	move          r9    r2
.line	1721	call          r6     4     1
.line	1721	self          r6    r5  k150 ; k150 = "ExecuteCMD"
.line	1721	getupval      r8    u1
.line	1721	loadk         r9  k151 ; k151 = 19
.line	1721	loadk        r10   k50 ; k50 = 214
.line	1721	loadk        r11  k166 ; k166 = 7
.line	1721	loadk        r12  k117 ; k117 = 200
.line	1721	loadk        r13   k93 ; k93 = 208
.line	1721	loadk        r14   k92 ; k92 = 36
.line	1721	loadk        r15  k167 ; k167 = 150
.line	1721	loadk        r16   k13 ; k13 = 76
.line	1721	loadk        r17  k168 ; k168 = 155
.line	1721	loadk        r18  k136 ; k136 = 251
.line	1721	loadk        r19   k81 ; k81 = 229
.line	1721	loadk        r20  k165 ; k165 = 1
.line	1721	loadk        r21   k31 ; k31 = 73
.line	1721	loadk        r22   k92 ; k92 = 36
.line	1721	loadk        r23  k169 ; k169 = 117
.line	1721	loadk        r24   k50 ; k50 = 214
.line	1721	loadk        r25  k134 ; k134 = 249
.line	1721	loadk        r26  k170 ; k170 = 166
.line	1721	loadk        r27   k71 ; k71 = 65
.line	1721	loadk        r28   k39 ; k39 = 221
.line	1721	loadk        r29    k3 ; k3 = 38
.line	1721	loadk        r30  k151 ; k151 = 19
.line	1721	loadk        r31   k75 ; k75 = 243
.line	1721	loadk        r32  k171 ; k171 = 122
.line	1721	loadk        r33  k172 ; k172 = 137
.line	1721	loadk        r34   k62 ; k62 = 244
.line	1721	loadk        r35   k11 ; k11 = 210
.line	1721	loadk        r36    k6 ; k6 = 46
.line	1721	loadk        r37   k97 ; k97 = 79
.line	1721	loadk        r38  k132 ; k132 = 48
.line	1721	loadk        r39  k110 ; k110 = 121
.line	1721	loadk        r40  k111 ; k111 = 209
.line	1721	loadk        r41   k11 ; k11 = 210
.line	1721	loadk        r42  k112 ; k112 = 185
.line	1721	loadk        r43  k113 ; k113 = 81
.line	1721	loadk        r44  k179 ; k179 = 224
.line	1721	loadk        r45  k180 ; k180 = 60
.line	1721	call          r8    38     2
.line	1721	move          r9    r3
.line	1721	call          r6     4     1
.line	1721	jmp            0  l666
.label	l623
.line	1721	self          r6    r5  k150 ; k150 = "ExecuteCMD"
.line	1721	getupval      r8    u1
.line	1721	loadk         r9  k151 ; k151 = 19
.line	1721	loadk        r10   k50 ; k50 = 214
.line	1721	loadk        r11  k145 ; k145 = 0
.line	1721	loadk        r12   k82 ; k82 = 199
.line	1721	loadk        r13   k11 ; k11 = 210
.line	1721	loadk        r14  k152 ; k152 = 45
.line	1721	loadk        r15  k153 ; k153 = 138
.line	1721	loadk        r16  k154 ; k154 = 72
.line	1721	loadk        r17    k9 ; k9 = 186
.line	1721	loadk        r18  k101 ; k101 = 241
.line	1721	loadk        r19   k25 ; k25 = 196
.line	1721	loadk        r20  k155 ; k155 = 6
.line	1721	loadk        r21   k13 ; k13 = 76
.line	1721	loadk        r22   k78 ; k78 = 32
.line	1721	loadk        r23  k156 ; k156 = 102
.line	1721	loadk        r24   k72 ; k72 = 207
.line	1721	loadk        r25   k11 ; k11 = 210
.line	1721	loadk        r26  k157 ; k157 = 164
.line	1721	loadk        r27   k58 ; k58 = 64
.line	1721	loadk        r28   k10 ; k10 = 252
.line	1721	loadk        r29   k14 ; k14 = 51
.line	1721	loadk        r30  k158 ; k158 = 13
.line	1721	loadk        r31  k159 ; k159 = 255
.line	1721	loadk        r32  k160 ; k160 = 115
.line	1721	loadk        r33  k131 ; k131 = 156
.line	1721	loadk        r34   k25 ; k25 = 196
.line	1721	loadk        r35   k11 ; k11 = 210
.line	1721	loadk        r36   k26 ; k26 = 17
.line	1721	loadk        r37   k31 ; k31 = 73
.line	1721	loadk        r38  k161 ; k161 = 54
.line	1721	loadk        r39  k162 ; k162 = 116
.line	1721	loadk        r40  k163 ; k163 = 192
.line	1721	loadk        r41   k81 ; k81 = 229
.line	1721	loadk        r42  k131 ; k131 = 156
.line	1721	loadk        r43   k58 ; k58 = 64
.line	1721	loadk        r44   k81 ; k81 = 229
.line	1721	loadk        r45   k88 ; k88 = 50
.line	1721	loadk        r46  k164 ; k164 = 22
.line	1721	call          r8    39     2
.line	1721	loadk         r9  k145 ; k145 = 0
.line	1721	call          r6     4     1
.label	l666
.line	1721	return        r0     1
.line	1721	move          r0    r0
.line	1721	move          r0    r0
.line	1721	return        r0     1

.function	main/f119

.source	null
.linedefined	1739
.lastlinedefined	1749
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false

.constant	k0	0
.constant	k1	"FuncUtil"
.constant	k2	"GetServerTimeInSec"
.constant	k3	"DataMgr"
.constant	k4	"registertime"
.constant	k5	nil
.constant	k6	86400
.constant	k7	"roleData"
.constant	k8	"back_user_data"
.constant	k9	"rejoin_start_time"

.line	1739	loadk         r1    k0 ; k0 = 0
.line	1739	gettabup      r2    u0    k1 ; k1 = "FuncUtil"
.line	1739	gettable      r2    r2    k2 ; k2 = "GetServerTimeInSec"
.line	1739	call          r2     1     2
.line	1739	gettabup      r3    u0    k3 ; k3 = "DataMgr"
.line	1739	gettable      r3    r3    k4 ; k4 = "registertime"
.line	1739	eq             1    r3    k5 ; k5 = nil
.line	1739	jmp            0   l17
.line	1739	gettabup      r3    u0    k3 ; k3 = "DataMgr"
.line	1739	gettable      r3    r3    k4 ; k4 = "registertime"
.line	1739	lt             0    k0    r3 ; k0 = 0
.line	1739	jmp            0   l17
.line	1739	gettabup      r3    u0    k3 ; k3 = "DataMgr"
.line	1739	gettable      r3    r3    k4 ; k4 = "registertime"
.line	1739	sub           r3    r2    r3
.line	1739	div           r1    r3    k6 ; k6 = 86400
.label	l17
.line	1739	test          r0     0
.line	1739	jmp            0   l40
.line	1739	gettabup      r3    u0    k3 ; k3 = "DataMgr"
.line	1739	gettable      r3    r3    k7 ; k7 = "roleData"
.line	1739	test          r3     0
.line	1739	jmp            0   l40
.line	1739	gettabup      r3    u0    k3 ; k3 = "DataMgr"
.line	1739	gettable      r3    r3    k7 ; k7 = "roleData"
.line	1739	gettable      r3    r3    k8 ; k8 = "back_user_data"
.line	1739	test          r3     0
.line	1739	jmp            0   l40
.line	1739	gettabup      r3    u0    k3 ; k3 = "DataMgr"
.line	1739	gettable      r3    r3    k7 ; k7 = "roleData"
.line	1739	gettable      r3    r3    k8 ; k8 = "back_user_data"
.line	1739	gettable      r3    r3    k9 ; k9 = "rejoin_start_time"
.line	1739	test          r3     0
.line	1739	jmp            0   l40
.line	1739	gettabup      r3    u0    k3 ; k3 = "DataMgr"
.line	1739	gettable      r3    r3    k7 ; k7 = "roleData"
.line	1739	gettable      r3    r3    k8 ; k8 = "back_user_data"
.line	1739	gettable      r3    r3    k9 ; k9 = "rejoin_start_time"
.line	1739	sub           r3    r2    r3
.line	1739	div           r1    r3    k6 ; k6 = 86400
.label	l40
.line	1739	return        r1     2
.line	1739	return        r0     1
.line	1739	move          r0    r0
.line	1739	move          r0    r0
.line	1739	move          r0    r0
.line	1739	move          r0    r0
.line	1739	return        r0     1

.function	main/f120

.source	null
.linedefined	1751
.lastlinedefined	1757
.numparams	1
.is_vararg	0
.maxstacksize	26

.upvalue	"_ENV"	0	false
.upvalue	"U1"	25	true
.upvalue	"U2"	1	true

.constant	k0	"DataMgr"
.constant	k1	"registertime"
.constant	k2	0
.constant	k3	3
.constant	k4	148
.constant	k5	44
.constant	k6	204
.constant	k7	221
.constant	k8	59
.constant	k9	200
.constant	k10	78
.constant	k11	151
.constant	k12	253
.constant	k13	202
.constant	k14	2
.constant	k15	82
.constant	k16	111
.constant	k17	113
.constant	k18	205
.constant	k19	173
.constant	k20	106
.constant	k21	236
.constant	k22	55
.constant	k23	22
.constant	k24	250
.constant	k25	"GetServerTimeInSec"
.constant	k26	"math"
.constant	k27	"floor"
.constant	k28	86400
.constant	k29	1
.constant	k30	365
.constant	k31	0.5

.line	1751	test          r0     1
.line	1751	jmp            0    l8
.line	1751	gettabup      r1    u0    k0 ; k0 = "DataMgr"
.line	1751	gettable      r1    r1    k1 ; k1 = "registertime"
.line	1751	testset       r0    r1     1
.line	1751	jmp            0    l8
.line	1751	loadk         r0    k2 ; k2 = 0
.label	l8
.line	1751	getupval      r1    u1
.line	1751	getupval      r2    u2
.line	1751	loadk         r3    k3 ; k3 = 3
.line	1751	loadk         r4    k4 ; k4 = 148
.line	1751	loadk         r5    k5 ; k5 = 44
.line	1751	loadk         r6    k6 ; k6 = 204
.line	1751	loadk         r7    k7 ; k7 = 221
.line	1751	loadk         r8    k8 ; k8 = 59
.line	1751	loadk         r9    k9 ; k9 = 200
.line	1751	loadk        r10   k10 ; k10 = 78
.line	1751	loadk        r11   k11 ; k11 = 151
.line	1751	loadk        r12   k12 ; k12 = 253
.line	1751	loadk        r13   k13 ; k13 = 202
.line	1751	loadk        r14   k14 ; k14 = 2
.line	1751	loadk        r15   k15 ; k15 = 82
.line	1751	loadk        r16   k16 ; k16 = 111
.line	1751	loadk        r17   k17 ; k17 = 113
.line	1751	loadk        r18   k18 ; k18 = 205
.line	1751	loadk        r19   k12 ; k12 = 253
.line	1751	loadk        r20   k19 ; k19 = 173
.line	1751	loadk        r21   k20 ; k20 = 106
.line	1751	loadk        r22   k21 ; k21 = 236
.line	1751	loadk        r23   k22 ; k22 = 55
.line	1751	loadk        r24   k23 ; k23 = 22
.line	1751	loadk        r25   k24 ; k24 = 250
.line	1751	call          r2    24     2
.line	1751	call          r1     2     2
.line	1751	gettable      r2    r1   k25 ; k25 = "GetServerTimeInSec"
.line	1751	call          r2     1     2
.line	1751	gettabup      r3    u0   k26 ; k26 = "math"
.line	1751	gettable      r3    r3   k27 ; k27 = "floor"
.line	1751	sub           r4    r2    r0
.line	1751	div           r4    r4   k28 ; k28 = 86400
.line	1751	add           r4    r4   k29 ; k29 = 1
.line	1751	call          r3     2     2
.line	1751	gettabup      r4    u0   k26 ; k26 = "math"
.line	1751	gettable      r4    r4   k27 ; k27 = "floor"
.line	1751	div           r5    r3   k30 ; k30 = 365
.line	1751	add           r5    r5   k31 ; k31 = 0.5
.line	1751	tailcall      r4     2
.line	1751	return        r4     0
.line	1751	return        r0     1
.line	1751	move          r0    r0
.line	1751	move          r0    r0
.line	1751	return        r0     1

.function	main/f121

.source	null
.linedefined	1761
.lastlinedefined	1774
.numparams	1
.is_vararg	0
.maxstacksize	30

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	24	true
.upvalue	"U3"	23	true
.upvalue	"U4"	49	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	38
.constant	k3	141
.constant	k4	43
.constant	k5	202
.constant	k6	230
.constant	k7	59
.constant	k8	143
.constant	k9	65
.constant	k10	214
.constant	k11	215
.constant	k12	194
.constant	k13	25
.constant	k14	108
.constant	k15	36
.constant	k16	113
.constant	k17	244
.constant	k18	255
.constant	k19	187
.constant	k20	111
.constant	k21	183
.constant	k22	99
.constant	k23	20
.constant	k24	243
.constant	k25	100
.constant	k26	210
.constant	k27	160
.constant	k28	"Game"
.constant	k29	"GetPlayerByPlayerKey"
.constant	k30	0
.constant	k31	"GetController"
.constant	k32	"IsSpecialBird"
.constant	k33	"FlyStartPosZ"
.constant	k34	5
.constant	k35	172
.constant	k36	61

.line	1761	gettabup      r1    u0    k0 ; k0 = "log"
.line	1761	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1761	test          r2     0
.line	1761	jmp            0   l37
.line	1761	getupval      r2    u1
.line	1761	loadk         r3    k2 ; k2 = 38
.line	1761	loadk         r4    k3 ; k3 = 141
.line	1761	loadk         r5    k4 ; k4 = 43
.line	1761	loadk         r6    k5 ; k5 = 202
.line	1761	loadk         r7    k6 ; k6 = 230
.line	1761	loadk         r8    k7 ; k7 = 59
.line	1761	loadk         r9    k8 ; k8 = 143
.line	1761	loadk        r10    k9 ; k9 = 65
.line	1761	loadk        r11   k10 ; k10 = 214
.line	1761	loadk        r12   k11 ; k11 = 215
.line	1761	loadk        r13   k12 ; k12 = 194
.line	1761	loadk        r14   k13 ; k13 = 25
.line	1761	loadk        r15   k14 ; k14 = 108
.line	1761	loadk        r16   k15 ; k15 = 36
.line	1761	loadk        r17   k16 ; k16 = 113
.line	1761	loadk        r18   k17 ; k17 = 244
.line	1761	loadk        r19   k18 ; k18 = 255
.line	1761	loadk        r20   k19 ; k19 = 187
.line	1761	loadk        r21   k20 ; k20 = 111
.line	1761	loadk        r22   k21 ; k21 = 183
.line	1761	loadk        r23   k22 ; k22 = 99
.line	1761	loadk        r24   k23 ; k23 = 20
.line	1761	loadk        r25   k24 ; k24 = 243
.line	1761	loadk        r26   k25 ; k25 = 100
.line	1761	loadk        r27   k26 ; k26 = 210
.line	1761	loadk        r28   k27 ; k27 = 160
.line	1761	call          r2    27     2
.line	1761	getupval      r3    u2
.line	1761	move          r4    r0
.line	1761	call          r3     2     2
.line	1761	concat        r2    r2    r3
.label	l37
.line	1761	call          r1     2     1
.line	1761	gettabup      r1    u0   k28 ; k28 = "Game"
.line	1761	self          r1    r1   k29 ; k29 = "GetPlayerByPlayerKey"
.line	1761	getupval      r3    u3
.line	1761	move          r4    r0
.line	1761	call          r3     2     0
.line	1761	call          r1     0     2
.line	1761	test          r1     1
.line	1761	jmp            0   l48
.line	1761	loadk         r2   k30 ; k30 = 0
.line	1761	return        r2     2
.label	l48
.line	1761	self          r2    r1   k31 ; k31 = "GetController"
.line	1761	call          r2     2     2
.line	1761	loadk         r3   k30 ; k30 = 0
.line	1761	gettabup      r4    u4   k32 ; k32 = "IsSpecialBird"
.line	1761	move          r5    r2
.line	1761	call          r4     2     2
.line	1761	test          r4     0
.line	1761	jmp            0   l57
.line	1761	gettabup      r3    u4   k33 ; k33 = "FlyStartPosZ"
.label	l57
.line	1761	gettabup      r4    u0    k0 ; k0 = "log"
.line	1761	gettabup      r5    u0    k1 ; k1 = "bWriteLog"
.line	1761	test          r5     0
.line	1761	jmp            0   l91
.line	1761	getupval      r5    u1
.line	1761	loadk         r6    k2 ; k2 = 38
.line	1761	loadk         r7    k3 ; k3 = 141
.line	1761	loadk         r8    k4 ; k4 = 43
.line	1761	loadk         r9    k5 ; k5 = 202
.line	1761	loadk        r10    k6 ; k6 = 230
.line	1761	loadk        r11    k7 ; k7 = 59
.line	1761	loadk        r12    k8 ; k8 = 143
.line	1761	loadk        r13    k9 ; k9 = 65
.line	1761	loadk        r14   k10 ; k10 = 214
.line	1761	loadk        r15   k11 ; k11 = 215
.line	1761	loadk        r16   k12 ; k12 = 194
.line	1761	loadk        r17   k13 ; k13 = 25
.line	1761	loadk        r18   k14 ; k14 = 108
.line	1761	loadk        r19   k15 ; k15 = 36
.line	1761	loadk        r20   k16 ; k16 = 113
.line	1761	loadk        r21   k17 ; k17 = 244
.line	1761	loadk        r22   k18 ; k18 = 255
.line	1761	loadk        r23   k19 ; k19 = 187
.line	1761	loadk        r24   k20 ; k20 = 111
.line	1761	loadk        r25   k21 ; k21 = 183
.line	1761	loadk        r26   k22 ; k22 = 99
.line	1761	loadk        r27   k34 ; k34 = 5
.line	1761	loadk        r28   k35 ; k35 = 172
.line	1761	loadk        r29   k36 ; k36 = 61
.line	1761	call          r5    25     2
.line	1761	getupval      r6    u2
.line	1761	move          r7    r3
.line	1761	call          r6     2     2
.line	1761	concat        r5    r5    r6
.label	l91
.line	1761	call          r4     2     1
.line	1761	return        r3     2
.line	1761	return        r0     1
.line	1761	move          r0    r0
.line	1761	return        r0     1

.function	main/f122

.source	null
.linedefined	1776
.lastlinedefined	1788
.numparams	3
.is_vararg	0
.maxstacksize	18

.upvalue	"_ENV"	0	false
.upvalue	"U1"	2	true
.upvalue	"U2"	1	true
.upvalue	"U3"	4	true

.constant	k0	"FuncUtil"
.constant	k1	"concatDescriptionSwitch"
.constant	k2	0
.constant	k3	"GlobalData"
.constant	k4	"IsIOSCheck"
.constant	k5	"GetOperationRegion"
.constant	k6	69
.constant	k7	139
.constant	k8	101
.constant	k9	253
.constant	k10	210
.constant	k11	60
.constant	k12	141
.constant	k13	100
.constant	k14	188
.constant	k15	176
.constant	k16	154
.constant	k17	77
.constant	k18	25
.constant	k19	37
.constant	k20	"format"

.line	1776	gettabup      r3    u0    k0 ; k0 = "FuncUtil"
.line	1776	gettable      r3    r3    k1 ; k1 = "concatDescriptionSwi" (truncated)
.line	1776	eq             0    r3    k2 ; k2 = 0
.line	1776	jmp            0    l6
.line	1776	return        r0     2
.label	l6
.line	1776	gettabup      r3    u0    k3 ; k3 = "GlobalData"
.line	1776	gettable      r3    r3    k4 ; k4 = "IsIOSCheck"
.line	1776	call          r3     1     2
.line	1776	test          r3     0
.line	1776	jmp            0   l12
.line	1776	return        r0     2
.label	l12
.line	1776	test          r2     0
.line	1776	jmp            0   l19
.line	1776	gettabup      r3    u1    k5 ; k5 = "GetOperationRegion"
.line	1776	call          r3     1     2
.line	1776	eq             1    r3    r2
.line	1776	jmp            0   l19
.line	1776	return        r0     2
.label	l19
.line	1776	getupval      r3    u2
.line	1776	loadk         r4    k6 ; k6 = 69
.line	1776	loadk         r5    k7 ; k7 = 139
.line	1776	loadk         r6    k8 ; k8 = 101
.line	1776	loadk         r7    k9 ; k9 = 253
.line	1776	loadk         r8   k10 ; k10 = 210
.line	1776	loadk         r9   k11 ; k11 = 60
.line	1776	loadk        r10   k12 ; k12 = 141
.line	1776	loadk        r11   k13 ; k13 = 100
.line	1776	loadk        r12   k14 ; k14 = 188
.line	1776	loadk        r13   k15 ; k15 = 176
.line	1776	loadk        r14   k16 ; k16 = 154
.line	1776	loadk        r15   k17 ; k17 = 77
.line	1776	loadk        r16   k18 ; k18 = 25
.line	1776	loadk        r17   k19 ; k19 = 37
.line	1776	call          r3    15     2
.line	1776	gettabup      r4    u3   k20 ; k20 = "format"
.line	1776	move          r5    r3
.line	1776	move          r6    r0
.line	1776	move          r7    r1
.line	1776	tailcall      r4     4
.line	1776	return        r4     0
.line	1776	return        r0     1
.line	1776	move          r0    r0
.line	1776	move          r0    r0
.line	1776	move          r0    r0
.line	1776	return        r0     1

.function	main/f123

.source	null
.linedefined	1790
.lastlinedefined	1793
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	24	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	38
.constant	k5	141
.constant	k6	43
.constant	k7	202
.constant	k8	230
.constant	k9	59
.constant	k10	143
.constant	k11	65
.constant	k12	214
.constant	k13	195
.constant	k14	194
.constant	k15	25
.constant	k16	127
.constant	k17	46
.constant	k18	107
.constant	k19	199
.constant	k20	241
.constant	k21	188
.constant	k22	113
.constant	k23	252
.constant	k24	48
.constant	k25	28
.constant	k26	228
.constant	k27	116
.constant	k28	152
.constant	k29	244
.constant	k30	222
.constant	k31	18
.constant	k32	66
.constant	k33	2
.constant	k34	98
.constant	k35	221
.constant	k36	187
.constant	k37	77
.constant	k38	167
.constant	k39	115
.constant	k40	6
.constant	k41	245
.constant	k42	16
.constant	k43	157
.constant	k44	147
.constant	k45	"FuncUtil"
.constant	k46	"concatDescriptionSwitch"
.constant	k47	1
.constant	k48	0

.line	1790	gettabup      r1    u0    k0 ; k0 = "log"
.line	1790	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1790	test          r2     0
.line	1790	jmp            0   l63
.line	1790	gettabup      r2    u0    k2 ; k2 = "table"
.line	1790	gettable      r2    r2    k3 ; k3 = "concat"
.line	1790	newtable      r3     1     0
.line	1790	getupval      r4    u1
.line	1790	loadk         r5    k4 ; k4 = 38
.line	1790	loadk         r6    k5 ; k5 = 141
.line	1790	loadk         r7    k6 ; k6 = 43
.line	1790	loadk         r8    k7 ; k7 = 202
.line	1790	loadk         r9    k8 ; k8 = 230
.line	1790	loadk        r10    k9 ; k9 = 59
.line	1790	loadk        r11   k10 ; k10 = 143
.line	1790	loadk        r12   k11 ; k11 = 65
.line	1790	loadk        r13   k12 ; k12 = 214
.line	1790	loadk        r14   k13 ; k13 = 195
.line	1790	loadk        r15   k14 ; k14 = 194
.line	1790	loadk        r16   k15 ; k15 = 25
.line	1790	loadk        r17   k16 ; k16 = 127
.line	1790	loadk        r18   k17 ; k17 = 46
.line	1790	loadk        r19   k18 ; k18 = 107
.line	1790	loadk        r20   k19 ; k19 = 199
.line	1790	loadk        r21   k20 ; k20 = 241
.line	1790	loadk        r22   k21 ; k21 = 188
.line	1790	loadk        r23   k22 ; k22 = 113
.line	1790	loadk        r24   k23 ; k23 = 252
.line	1790	loadk        r25   k24 ; k24 = 48
.line	1790	loadk        r26   k25 ; k25 = 28
.line	1790	loadk        r27   k26 ; k26 = 228
.line	1790	loadk        r28   k27 ; k27 = 116
.line	1790	loadk        r29   k28 ; k28 = 152
.line	1790	loadk        r30   k29 ; k29 = 244
.line	1790	loadk        r31   k30 ; k30 = 222
.line	1790	loadk        r32   k31 ; k31 = 18
.line	1790	loadk        r33   k32 ; k32 = 66
.line	1790	loadk        r34   k33 ; k33 = 2
.line	1790	loadk        r35   k34 ; k34 = 98
.line	1790	loadk        r36   k35 ; k35 = 221
.line	1790	loadk        r37   k29 ; k29 = 244
.line	1790	loadk        r38   k36 ; k36 = 187
.line	1790	loadk        r39   k37 ; k37 = 77
.line	1790	loadk        r40   k38 ; k38 = 167
.line	1790	loadk        r41   k39 ; k39 = 115
.line	1790	loadk        r42   k40 ; k40 = 6
.line	1790	loadk        r43   k41 ; k41 = 245
.line	1790	loadk        r44   k32 ; k32 = 66
.line	1790	call          r4    41     2
.line	1790	getupval      r5    u1
.line	1790	loadk         r6   k42 ; k42 = 16
.line	1790	loadk         r7   k43 ; k43 = 157
.line	1790	loadk         r8    k6 ; k6 = 43
.line	1790	loadk         r9   k44 ; k44 = 147
.line	1790	loadk        r10   k44 ; k44 = 147
.line	1790	call          r5     6     0
.line	1790	setlist       r3     0     1
.line	1790	call          r2     2     2
.line	1790	getupval      r3    u2
.line	1790	move          r4    r0
.line	1790	call          r3     2     2
.line	1790	concat        r2    r2    r3
.label	l63
.line	1790	call          r1     2     1
.line	1790	gettabup      r1    u0   k45 ; k45 = "FuncUtil"
.line	1790	test          r0     0
.line	1790	jmp            0   l70
.line	1790	loadk         r2   k47 ; k47 = 1
.line	1790	test          r2     1
.line	1790	jmp            0   l71
.label	l70
.line	1790	loadk         r2   k48 ; k48 = 0
.label	l71
.line	1790	settable      r1   k46    r2 ; k46 = "concatDescriptionSwi" (truncated)
.line	1790	return        r0     1
.line	1790	move          r0    r0
.line	1790	move          r0    r0
.line	1790	return        r0     1

.function	main/f124

.source	null
.linedefined	1795
.lastlinedefined	1808
.numparams	2
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	22	true
.upvalue	"U1"	1	true
.upvalue	"U2"	5	true
.upvalue	"U3"	0	false
.upvalue	"U4"	24	true

.constant	k0	19
.constant	k1	140
.constant	k2	55
.constant	k3	192
.constant	k4	221
.constant	k5	40
.constant	k6	"table"
.constant	k7	"concat"
.constant	k8	38
.constant	k9	141
.constant	k10	43
.constant	k11	202
.constant	k12	230
.constant	k13	59
.constant	k14	143
.constant	k15	65
.constant	k16	214
.constant	k17	195
.constant	k18	198
.constant	k19	11
.constant	k20	89
.constant	k21	13
.constant	k22	106
.constant	k23	197
.constant	k24	244
.constant	k25	232
.constant	k26	86
.constant	k27	241
.constant	k28	54
.constant	k29	17
.constant	k30	253
.constant	k31	61
.constant	k32	133
.constant	k33	245
.constant	k34	196
.constant	k35	9
.constant	k36	12
.constant	k37	51
.constant	k38	112
.constant	k39	148
.constant	k40	225
.constant	k41	248
.constant	k42	33
.constant	k43	6
.constant	k44	76
.constant	k45	216
.constant	k46	34
.constant	k47	199
.constant	k48	111
.constant	k49	193
.constant	k50	8
.constant	k51	139
.constant	k52	183
.constant	k53	137
.constant	k54	77
.constant	k55	95
.constant	k56	41
.constant	k57	251
.constant	k58	242
.constant	k59	21
.constant	k60	188
.constant	k61	48
.constant	k62	"log_error"
.constant	k63	"load"
.constant	k64	20
.constant	k65	246
.constant	k66	46
.constant	k67	15
.constant	k68	255
.constant	k69	113
.constant	k70	160
.constant	k71	209
.constant	k72	28
.constant	k73	69
.constant	k74	208
.constant	k75	174
.constant	k76	70
.constant	k77	1
.constant	k78	237
.constant	k79	64
.constant	k80	147
.constant	k81	42
.constant	k82	194
.constant	k83	176
.constant	k84	130
.constant	k85	30

.line	1795	getupval      r2    u0
.line	1795	move          r3    r0
.line	1795	call          r2     2     2
.line	1795	getupval      r3    u1
.line	1795	loadk         r4    k0 ; k0 = 19
.line	1795	loadk         r5    k1 ; k1 = 140
.line	1795	loadk         r6    k2 ; k2 = 55
.line	1795	loadk         r7    k3 ; k3 = 192
.line	1795	loadk         r8    k4 ; k4 = 221
.line	1795	loadk         r9    k5 ; k5 = 40
.line	1795	call          r3     7     2
.line	1795	eq             1    r2    r3
.line	1795	jmp            0   l98
.line	1795	getupval      r2    u2
.line	1795	gettabup      r3    u3    k6 ; k6 = "table"
.line	1795	gettable      r3    r3    k7 ; k7 = "concat"
.line	1795	newtable      r4     1     0
.line	1795	getupval      r5    u1
.line	1795	loadk         r6    k8 ; k8 = 38
.line	1795	loadk         r7    k9 ; k9 = 141
.line	1795	loadk         r8   k10 ; k10 = 43
.line	1795	loadk         r9   k11 ; k11 = 202
.line	1795	loadk        r10   k12 ; k12 = 230
.line	1795	loadk        r11   k13 ; k13 = 59
.line	1795	loadk        r12   k14 ; k14 = 143
.line	1795	loadk        r13   k15 ; k15 = 65
.line	1795	loadk        r14   k16 ; k16 = 214
.line	1795	loadk        r15   k17 ; k17 = 195
.line	1795	loadk        r16   k18 ; k18 = 198
.line	1795	loadk        r17   k19 ; k19 = 11
.line	1795	loadk        r18   k20 ; k20 = 89
.line	1795	loadk        r19   k21 ; k21 = 13
.line	1795	loadk        r20   k22 ; k22 = 106
.line	1795	loadk        r21   k23 ; k23 = 197
.line	1795	loadk        r22   k24 ; k24 = 244
.line	1795	loadk        r23   k25 ; k25 = 232
.line	1795	loadk        r24   k26 ; k26 = 86
.line	1795	loadk        r25   k27 ; k27 = 241
.line	1795	loadk        r26   k28 ; k28 = 54
.line	1795	loadk        r27   k29 ; k29 = 17
.line	1795	loadk        r28   k30 ; k30 = 253
.line	1795	loadk        r29   k31 ; k31 = 61
.line	1795	loadk        r30   k32 ; k32 = 133
.line	1795	loadk        r31   k33 ; k33 = 245
.line	1795	loadk        r32   k34 ; k34 = 196
.line	1795	loadk        r33   k35 ; k35 = 9
.line	1795	loadk        r34   k36 ; k36 = 12
.line	1795	loadk        r35   k37 ; k37 = 51
.line	1795	loadk        r36   k38 ; k38 = 112
.line	1795	loadk        r37   k39 ; k39 = 148
.line	1795	loadk        r38   k40 ; k40 = 225
.line	1795	loadk        r39   k41 ; k41 = 248
.line	1795	loadk        r40   k26 ; k26 = 86
.line	1795	loadk        r41   k30 ; k30 = 253
.line	1795	loadk        r42   k42 ; k42 = 33
.line	1795	loadk        r43   k43 ; k43 = 6
.line	1795	loadk        r44   k25 ; k25 = 232
.line	1795	loadk        r45   k22 ; k22 = 106
.line	1795	call          r5    41     2
.line	1795	getupval      r6    u1
.line	1795	loadk         r7   k44 ; k44 = 76
.line	1795	loadk         r8   k45 ; k45 = 216
.line	1795	loadk         r9   k46 ; k46 = 34
.line	1795	loadk        r10   k18 ; k18 = 198
.line	1795	loadk        r11   k47 ; k47 = 199
.line	1795	loadk        r12   k48 ; k48 = 111
.line	1795	loadk        r13   k49 ; k49 = 193
.line	1795	loadk        r14   k50 ; k50 = 8
.line	1795	loadk        r15   k51 ; k51 = 139
.line	1795	loadk        r16   k52 ; k52 = 183
.line	1795	loadk        r17   k53 ; k53 = 137
.line	1795	loadk        r18   k54 ; k54 = 77
.line	1795	loadk        r19   k55 ; k55 = 95
.line	1795	loadk        r20   k56 ; k56 = 41
.line	1795	loadk        r21   k38 ; k38 = 112
.line	1795	loadk        r22   k11 ; k11 = 202
.line	1795	loadk        r23   k57 ; k57 = 251
.line	1795	loadk        r24   k58 ; k58 = 242
.line	1795	loadk        r25   k59 ; k59 = 21
.line	1795	loadk        r26   k60 ; k60 = 188
.line	1795	loadk        r27   k61 ; k61 = 48
.line	1795	call          r6    22     0
.line	1795	setlist       r4     0     1
.line	1795	call          r3     2     2
.line	1795	getupval      r4    u0
.line	1795	move          r5    r0
.line	1795	call          r4     2     2
.line	1795	getupval      r5    u4
.line	1795	move          r6    r1
.line	1795	call          r5     2     0
.line	1795	call          r2     0     2
.line	1795	gettabup      r3    u3   k62 ; k62 = "log_error"
.line	1795	move          r4    r2
.line	1795	call          r3     2     1
.line	1795	loadnil       r3     0
.line	1795	move          r4    r2
.line	1795	return        r3     3
.label	l98
.line	1795	gettabup      r2    u3   k63 ; k63 = "load"
.line	1795	move          r3    r0
.line	1795	move          r4    r1
.line	1795	getupval      r5    u1
.line	1795	loadk         r6   k64 ; k64 = 20
.line	1795	call          r5     2     2
.line	1795	newtable      r6     0     0
.line	1795	call          r2     5     3
.line	1795	test          r2     1
.line	1795	jmp            0  l184
.line	1795	getupval      r4    u2
.line	1795	gettabup      r5    u3    k6 ; k6 = "table"
.line	1795	gettable      r5    r5    k7 ; k7 = "concat"
.line	1795	newtable      r6     1     0
.line	1795	getupval      r7    u1
.line	1795	loadk         r8    k8 ; k8 = 38
.line	1795	loadk         r9    k9 ; k9 = 141
.line	1795	loadk        r10   k10 ; k10 = 43
.line	1795	loadk        r11   k11 ; k11 = 202
.line	1795	loadk        r12   k12 ; k12 = 230
.line	1795	loadk        r13   k13 ; k13 = 59
.line	1795	loadk        r14   k14 ; k14 = 143
.line	1795	loadk        r15   k15 ; k15 = 65
.line	1795	loadk        r16   k16 ; k16 = 214
.line	1795	loadk        r17   k17 ; k17 = 195
.line	1795	loadk        r18   k18 ; k18 = 198
.line	1795	loadk        r19   k19 ; k19 = 11
.line	1795	loadk        r20   k20 ; k20 = 89
.line	1795	loadk        r21   k21 ; k21 = 13
.line	1795	loadk        r22   k22 ; k22 = 106
.line	1795	loadk        r23   k23 ; k23 = 197
.line	1795	loadk        r24   k24 ; k24 = 244
.line	1795	loadk        r25   k25 ; k25 = 232
.line	1795	loadk        r26   k26 ; k26 = 86
.line	1795	loadk        r27   k65 ; k65 = 246
.line	1795	loadk        r28   k66 ; k66 = 46
.line	1795	loadk        r29   k67 ; k67 = 15
.line	1795	loadk        r30   k68 ; k68 = 255
.line	1795	loadk        r31   k69 ; k69 = 113
.line	1795	loadk        r32    k9 ; k9 = 141
.line	1795	loadk        r33   k70 ; k70 = 160
.line	1795	loadk        r34   k71 ; k71 = 209
.line	1795	loadk        r35   k72 ; k72 = 28
.line	1795	loadk        r36   k73 ; k73 = 69
.line	1795	loadk        r37   k31 ; k31 = 61
.line	1795	loadk        r38   k38 ; k38 = 112
.line	1795	loadk        r39   k74 ; k74 = 208
.line	1795	loadk        r40   k75 ; k75 = 174
.line	1795	loadk        r41   k41 ; k41 = 248
.line	1795	loadk        r42   k76 ; k76 = 70
.line	1795	loadk        r43   k40 ; k40 = 225
.line	1795	loadk        r44    k8 ; k8 = 38
.line	1795	loadk        r45   k77 ; k77 = 1
.line	1795	loadk        r46   k78 ; k78 = 237
.line	1795	loadk        r47    k2 ; k2 = 55
.line	1795	call          r7    41     2
.line	1795	getupval      r8    u1
.line	1795	loadk         r9   k79 ; k79 = 64
.line	1795	loadk        r10    k4 ; k4 = 221
.line	1795	loadk        r11   k28 ; k28 = 54
.line	1795	loadk        r12   k32 ; k32 = 133
.line	1795	loadk        r13   k80 ; k80 = 147
.line	1795	loadk        r14   k81 ; k81 = 42
.line	1795	loadk        r15   k39 ; k39 = 148
.line	1795	loadk        r16   k55 ; k55 = 95
.line	1795	loadk        r17   k82 ; k82 = 194
.line	1795	loadk        r18   k83 ; k83 = 176
.line	1795	loadk        r19   k84 ; k84 = 130
.line	1795	loadk        r20   k85 ; k85 = 30
.line	1795	call          r8    13     0
.line	1795	setlist       r6     0     1
.line	1795	call          r5     2     2
.line	1795	getupval      r6    u4
.line	1795	move          r7    r1
.line	1795	call          r6     2     2
.line	1795	getupval      r7    u4
.line	1795	move          r8    r3
.line	1795	call          r7     2     0
.line	1795	call          r4     0     2
.line	1795	move          r3    r4
.line	1795	gettabup      r4    u3   k62 ; k62 = "log_error"
.line	1795	move          r5    r3
.line	1795	call          r4     2     1
.line	1795	loadnil       r4     0
.line	1795	move          r5    r3
.line	1795	return        r4     3
.label	l184
.line	1795	return        r2     2
.line	1795	return        r0     1
.line	1795	move          r0    r0
.line	1795	move          r0    r0
.line	1795	return        r0     1

.function	main/f125

.source	null
.linedefined	1810
.lastlinedefined	1812
.numparams	1
.is_vararg	0
.maxstacksize	41

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	24	true

.constant	k0	"log_error"
.constant	k1	38
.constant	k2	141
.constant	k3	43
.constant	k4	202
.constant	k5	230
.constant	k6	59
.constant	k7	143
.constant	k8	65
.constant	k9	214
.constant	k10	195
.constant	k11	198
.constant	k12	11
.constant	k13	89
.constant	k14	13
.constant	k15	106
.constant	k16	197
.constant	k17	244
.constant	k18	137
.constant	k19	91
.constant	k20	253
.constant	k21	0
.constant	k22	30
.constant	k23	250
.constant	k24	113
.constant	k25	200
.constant	k26	227
.constant	k27	223
.constant	k28	8
.constant	k29	66
.constant	k30	58
.constant	k31	53
.constant	k32	209
.constant	k33	242
.constant	k34	170
.constant	k35	74
.constant	k36	251
.constant	k37	105
.constant	k38	79

.line	1810	gettabup      r1    u0    k0 ; k0 = "log_error"
.line	1810	getupval      r2    u1
.line	1810	loadk         r3    k1 ; k1 = 38
.line	1810	loadk         r4    k2 ; k2 = 141
.line	1810	loadk         r5    k3 ; k3 = 43
.line	1810	loadk         r6    k4 ; k4 = 202
.line	1810	loadk         r7    k5 ; k5 = 230
.line	1810	loadk         r8    k6 ; k6 = 59
.line	1810	loadk         r9    k7 ; k7 = 143
.line	1810	loadk        r10    k8 ; k8 = 65
.line	1810	loadk        r11    k9 ; k9 = 214
.line	1810	loadk        r12   k10 ; k10 = 195
.line	1810	loadk        r13   k11 ; k11 = 198
.line	1810	loadk        r14   k12 ; k12 = 11
.line	1810	loadk        r15   k13 ; k13 = 89
.line	1810	loadk        r16   k14 ; k14 = 13
.line	1810	loadk        r17   k15 ; k15 = 106
.line	1810	loadk        r18   k16 ; k16 = 197
.line	1810	loadk        r19   k17 ; k17 = 244
.line	1810	loadk        r20   k18 ; k18 = 137
.line	1810	loadk        r21   k19 ; k19 = 91
.line	1810	loadk        r22   k20 ; k20 = 253
.line	1810	loadk        r23   k21 ; k21 = 0
.line	1810	loadk        r24   k22 ; k22 = 30
.line	1810	loadk        r25   k23 ; k23 = 250
.line	1810	loadk        r26   k24 ; k24 = 113
.line	1810	loadk        r27   k25 ; k25 = 200
.line	1810	loadk        r28   k26 ; k26 = 227
.line	1810	loadk        r29   k27 ; k27 = 223
.line	1810	loadk        r30   k28 ; k28 = 8
.line	1810	loadk        r31   k29 ; k29 = 66
.line	1810	loadk        r32   k30 ; k30 = 58
.line	1810	loadk        r33   k31 ; k31 = 53
.line	1810	loadk        r34   k32 ; k32 = 209
.line	1810	loadk        r35   k33 ; k33 = 242
.line	1810	loadk        r36   k34 ; k34 = 170
.line	1810	loadk        r37   k35 ; k35 = 74
.line	1810	loadk        r38   k36 ; k36 = 251
.line	1810	loadk        r39   k37 ; k37 = 105
.line	1810	loadk        r40   k38 ; k38 = 79
.line	1810	call          r2    39     2
.line	1810	getupval      r3    u2
.line	1810	move          r4    r0
.line	1810	call          r3     2     2
.line	1810	concat        r2    r2    r3
.line	1810	call          r1     2     1
.line	1810	return        r0     1
.line	1810	move          r0    r0
.line	1810	move          r0    r0
.line	1810	move          r0    r0
.line	1810	return        r0     1

.function	main/f126

.source	null
.linedefined	1813
.lastlinedefined	1823
.numparams	0
.is_vararg	0
.maxstacksize	12

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	22	true

.constant	k0	"rawget"
.constant	k1	"_G"
.constant	k2	51
.constant	k3	157
.constant	k4	55
.constant	k5	223
.constant	k6	214
.constant	k7	61
.constant	k8	20
.constant	k9	153
.constant	k10	39
.constant	k11	197
.constant	k12	"IsShipping"
.constant	k13	6
.constant	k14	141
.constant	k15	43
.constant	k16	202
.constant	k17	199
.constant	k18	38
.constant	k19	137
.constant	k20	67
.constant	k21	8
.constant	k22	2
.constant	k23	35
.constant	k24	148
.constant	k25	44
.constant	k26	204
.constant	k27	221
.constant	k28	59
.constant	k29	"IsDevelopment"

.line	1813	gettabup      r0    u0    k0 ; k0 = "rawget"
.line	1813	gettabup      r1    u0    k1 ; k1 = "_G"
.line	1813	getupval      r2    u1
.line	1813	loadk         r3    k2 ; k2 = 51
.line	1813	loadk         r4    k3 ; k3 = 157
.line	1813	loadk         r5    k4 ; k4 = 55
.line	1813	loadk         r6    k5 ; k5 = 223
.line	1813	loadk         r7    k6 ; k6 = 214
.line	1813	loadk         r8    k7 ; k7 = 61
.line	1813	call          r2     7     2
.line	1813	call          r0     3     2
.line	1813	getupval      r1    u2
.line	1813	move          r2    r0
.line	1813	call          r1     2     2
.line	1813	getupval      r2    u1
.line	1813	loadk         r3    k8 ; k8 = 20
.line	1813	loadk         r4    k9 ; k9 = 153
.line	1813	loadk         r5   k10 ; k10 = 39
.line	1813	loadk         r6   k11 ; k11 = 197
.line	1813	loadk         r7    k6 ; k6 = 214
.line	1813	call          r2     6     2
.line	1813	eq             0    r1    r2
.line	1813	jmp            0   l48
.line	1813	getupval      r1    u2
.line	1813	gettable      r2    r0   k12 ; k12 = "IsShipping"
.line	1813	call          r1     2     2
.line	1813	getupval      r2    u1
.line	1813	loadk         r3   k13 ; k13 = 6
.line	1813	loadk         r4   k14 ; k14 = 141
.line	1813	loadk         r5   k15 ; k15 = 43
.line	1813	loadk         r6   k16 ; k16 = 202
.line	1813	loadk         r7   k17 ; k17 = 199
.line	1813	loadk         r8   k18 ; k18 = 38
.line	1813	loadk         r9   k19 ; k19 = 137
.line	1813	loadk        r10   k20 ; k20 = 67
.line	1813	call          r2     9     2
.line	1813	eq             0    r1    r2
.line	1813	jmp            0   l48
.line	1813	gettable      r1    r0   k12 ; k12 = "IsShipping"
.line	1813	call          r1     1     2
.line	1813	test          r1     0
.line	1813	jmp            0   l46
.line	1813	loadk         r1   k21 ; k21 = 8
.line	1813	test          r1     1
.line	1813	jmp            0   l47
.label	l46
.line	1813	loadk         r1   k22 ; k22 = 2
.label	l47
.line	1813	return        r1     2
.label	l48
.line	1813	gettabup      r1    u0    k0 ; k0 = "rawget"
.line	1813	gettabup      r2    u0    k1 ; k1 = "_G"
.line	1813	getupval      r3    u1
.line	1813	loadk         r4   k23 ; k23 = 35
.line	1813	loadk         r5   k24 ; k24 = 148
.line	1813	loadk         r6   k25 ; k25 = 44
.line	1813	loadk         r7   k26 ; k26 = 204
.line	1813	loadk         r8   k27 ; k27 = 221
.line	1813	loadk         r9   k28 ; k28 = 59
.line	1813	call          r3     7     2
.line	1813	call          r1     3     2
.line	1813	getupval      r2    u2
.line	1813	move          r3    r1
.line	1813	call          r2     2     2
.line	1813	getupval      r3    u1
.line	1813	loadk         r4    k8 ; k8 = 20
.line	1813	loadk         r5    k9 ; k9 = 153
.line	1813	loadk         r6   k10 ; k10 = 39
.line	1813	loadk         r7   k11 ; k11 = 197
.line	1813	loadk         r8    k6 ; k6 = 214
.line	1813	call          r3     6     2
.line	1813	eq             0    r2    r3
.line	1813	jmp            0   l95
.line	1813	getupval      r2    u2
.line	1813	gettable      r3    r1   k29 ; k29 = "IsDevelopment"
.line	1813	call          r2     2     2
.line	1813	getupval      r3    u1
.line	1813	loadk         r4   k13 ; k13 = 6
.line	1813	loadk         r5   k14 ; k14 = 141
.line	1813	loadk         r6   k15 ; k15 = 43
.line	1813	loadk         r7   k16 ; k16 = 202
.line	1813	loadk         r8   k17 ; k17 = 199
.line	1813	loadk         r9   k18 ; k18 = 38
.line	1813	loadk        r10   k19 ; k19 = 137
.line	1813	loadk        r11   k20 ; k20 = 67
.line	1813	call          r3     9     2
.line	1813	eq             0    r2    r3
.line	1813	jmp            0   l95
.line	1813	gettable      r2    r1   k29 ; k29 = "IsDevelopment"
.line	1813	call          r2     1     2
.line	1813	test          r2     0
.line	1813	jmp            0   l93
.line	1813	loadk         r2   k22 ; k22 = 2
.line	1813	test          r2     1
.line	1813	jmp            0   l94
.label	l93
.line	1813	loadk         r2   k21 ; k21 = 8
.label	l94
.line	1813	return        r2     2
.label	l95
.line	1813	loadk         r2   k21 ; k21 = 8
.line	1813	return        r2     2
.line	1813	return        r0     1
.line	1813	move          r0    r0
.line	1813	move          r0    r0
.line	1813	move          r0    r0
.line	1813	return        r0     1

.function	main/f127

.source	null
.linedefined	1825
.lastlinedefined	1864
.numparams	3
.is_vararg	1
.maxstacksize	53

.upvalue	"_ENV"	0	false
.upvalue	"U1"	51	true
.upvalue	"U2"	22	true
.upvalue	"U3"	1	true
.upvalue	"U4"	5	true
.upvalue	"U5"	24	true
.upvalue	"U6"	50	true

.constant	k0	"FuncUtil"
.constant	k1	"SafeLoad"
.constant	k2	nil
.constant	k3	14
.constant	k4	141
.constant	k5	40
.constant	k6	203
.constant	k7	214
.constant	k8	61
.constant	k9	0
.constant	k10	"table"
.constant	k11	"concat"
.constant	k12	38
.constant	k13	43
.constant	k14	202
.constant	k15	230
.constant	k16	59
.constant	k17	143
.constant	k18	65
.constant	k19	195
.constant	k20	198
.constant	k21	11
.constant	k22	89
.constant	k23	13
.constant	k24	106
.constant	k25	197
.constant	k26	244
.constant	k27	137
.constant	k28	91
.constant	k29	253
.constant	k30	30
.constant	k31	250
.constant	k32	113
.constant	k33	200
.constant	k34	222
.constant	k35	16
.constant	k36	73
.constant	k37	29
.constant	k38	124
.constant	k39	217
.constant	k40	233
.constant	k41	172
.constant	k42	5
.constant	k43	228
.constant	k44	28
.constant	k45	242
.constant	k46	45
.constant	k47	2
.constant	k48	157
.constant	k49	101
.constant	k50	147
.constant	k51	63
.constant	k52	94
.constant	k53	145
.constant	k54	206
.constant	k55	27
.constant	k56	97
.constant	k57	107
.constant	k58	209
.constant	k59	170
.constant	k60	80
.constant	k61	235
.constant	k62	111
.constant	k63	95
.constant	k64	241
.constant	k65	114
.constant	k66	156
.constant	k67	160
.constant	k68	144
.constant	k69	88
.constant	k70	118
.constant	k71	148
.constant	k72	227
.constant	k73	176
.constant	k74	231
.constant	k75	56
.constant	k76	85
.constant	k77	166
.constant	k78	19
.constant	k79	"log_error"
.constant	k80	"slua"
.constant	k81	20
.constant	k82	153
.constant	k83	39
.constant	k84	"pcall"
.constant	k85	6
.constant	k86	199
.constant	k87	67
.constant	k88	"TimeoutIgnoreHookFlagIncrement"
.constant	k89	"pack"
.constant	k90	"TimeoutIgnoreHookFlagDecrement"
.constant	k91	3
.constant	k92	1
.constant	k93	true
.constant	k94	62
.constant	k95	96
.constant	k96	192
.constant	k97	185
.constant	k98	54
.constant	k99	139
.constant	k100	208
.constant	k101	135
.constant	k102	72
.constant	k103	79
.constant	k104	64
.constant	k105	52
.constant	k106	154
.constant	k107	187
.constant	k108	77
.constant	k109	252
.constant	k110	4
.constant	k111	188
.constant	k112	69
.constant	k113	105
.constant	k114	23
.constant	k115	216
.constant	k116	181
.constant	k117	212
.constant	k118	"unpack"
.constant	k119	"n"

.line	1825	gettabup      r3    u0    k0 ; k0 = "FuncUtil"
.line	1825	gettable      r3    r3    k1 ; k1 = "SafeLoad"
.line	1825	move          r4    r0
.line	1825	move          r5    r1
.line	1825	call          r3     3     3
.line	1825	test          r3     1
.line	1825	jmp            0   l12
.line	1825	loadbool      r5     0     0
.line	1825	loadbool      r6     0     0
.line	1825	move          r7    r4
.line	1825	return        r5     4
.label	l12
.line	1825	eq             0    r2    k2 ; k2 = nil
.line	1825	jmp            0   l18
.line	1825	getupval      r5    u1
.line	1825	call          r5     1     2
.line	1825	move          r2    r5
.line	1825	jmp            0  l141
.label	l18
.line	1825	getupval      r5    u2
.line	1825	move          r6    r2
.line	1825	call          r5     2     2
.line	1825	getupval      r6    u3
.line	1825	loadk         r7    k3 ; k3 = 14
.line	1825	loadk         r8    k4 ; k4 = 141
.line	1825	loadk         r9    k5 ; k5 = 40
.line	1825	loadk        r10    k6 ; k6 = 203
.line	1825	loadk        r11    k7 ; k7 = 214
.line	1825	loadk        r12    k8 ; k8 = 61
.line	1825	call          r6     7     2
.line	1825	eq             0    r5    r6
.line	1825	jmp            0   l33
.line	1825	le             0    r2    k9 ; k9 = 0
.line	1825	jmp            0  l141
.label	l33
.line	1825	getupval      r5    u4
.line	1825	gettabup      r6    u0   k10 ; k10 = "table"
.line	1825	gettable      r6    r6   k11 ; k11 = "concat"
.line	1825	newtable      r7     2     0
.line	1825	getupval      r8    u3
.line	1825	loadk         r9   k12 ; k12 = 38
.line	1825	loadk        r10    k4 ; k4 = 141
.line	1825	loadk        r11   k13 ; k13 = 43
.line	1825	loadk        r12   k14 ; k14 = 202
.line	1825	loadk        r13   k15 ; k15 = 230
.line	1825	loadk        r14   k16 ; k16 = 59
.line	1825	loadk        r15   k17 ; k17 = 143
.line	1825	loadk        r16   k18 ; k18 = 65
.line	1825	loadk        r17    k7 ; k7 = 214
.line	1825	loadk        r18   k19 ; k19 = 195
.line	1825	loadk        r19   k20 ; k20 = 198
.line	1825	loadk        r20   k21 ; k21 = 11
.line	1825	loadk        r21   k22 ; k22 = 89
.line	1825	loadk        r22   k23 ; k23 = 13
.line	1825	loadk        r23   k24 ; k24 = 106
.line	1825	loadk        r24   k25 ; k25 = 197
.line	1825	loadk        r25   k26 ; k26 = 244
.line	1825	loadk        r26   k27 ; k27 = 137
.line	1825	loadk        r27   k28 ; k28 = 91
.line	1825	loadk        r28   k29 ; k29 = 253
.line	1825	loadk        r29    k9 ; k9 = 0
.line	1825	loadk        r30   k30 ; k30 = 30
.line	1825	loadk        r31   k31 ; k31 = 250
.line	1825	loadk        r32   k32 ; k32 = 113
.line	1825	loadk        r33   k33 ; k33 = 200
.line	1825	loadk        r34   k26 ; k26 = 244
.line	1825	loadk        r35   k34 ; k34 = 222
.line	1825	loadk        r36   k35 ; k35 = 16
.line	1825	loadk        r37   k36 ; k36 = 73
.line	1825	loadk        r38   k37 ; k37 = 29
.line	1825	loadk        r39   k38 ; k38 = 124
.line	1825	loadk        r40   k39 ; k39 = 217
.line	1825	loadk        r41   k40 ; k40 = 233
.line	1825	loadk        r42   k41 ; k41 = 172
.line	1825	loadk        r43   k42 ; k42 = 5
.line	1825	loadk        r44   k43 ; k43 = 228
.line	1825	loadk        r45   k12 ; k12 = 38
.line	1825	loadk        r46   k44 ; k44 = 28
.line	1825	loadk        r47   k45 ; k45 = 242
.line	1825	loadk        r48   k46 ; k46 = 45
.line	1825	call          r8    41     2
.line	1825	getupval      r9    u3
.line	1825	loadk        r10   k47 ; k47 = 2
.line	1825	loadk        r11   k48 ; k48 = 157
.line	1825	loadk        r12   k49 ; k49 = 101
.line	1825	loadk        r13   k33 ; k33 = 200
.line	1825	loadk        r14   k50 ; k50 = 147
.line	1825	loadk        r15   k51 ; k51 = 63
.line	1825	loadk        r16   k27 ; k27 = 137
.line	1825	loadk        r17   k52 ; k52 = 94
.line	1825	loadk        r18   k53 ; k53 = 145
.line	1825	loadk        r19   k43 ; k43 = 228
.line	1825	loadk        r20   k54 ; k54 = 206
.line	1825	loadk        r21   k55 ; k55 = 27
.line	1825	loadk        r22   k22 ; k22 = 89
.line	1825	loadk        r23   k56 ; k56 = 97
.line	1825	loadk        r24   k57 ; k57 = 107
.line	1825	loadk        r25   k58 ; k58 = 209
.line	1825	loadk        r26   k29 ; k29 = 253
.line	1825	loadk        r27   k59 ; k59 = 170
.line	1825	loadk        r28   k60 ; k60 = 80
.line	1825	loadk        r29   k61 ; k61 = 235
.line	1825	loadk        r30   k62 ; k62 = 111
.line	1825	loadk        r31   k63 ; k63 = 95
.line	1825	loadk        r32   k64 ; k64 = 241
.line	1825	loadk        r33   k65 ; k65 = 114
.line	1825	loadk        r34   k66 ; k66 = 156
.line	1825	loadk        r35   k67 ; k67 = 160
.line	1825	loadk        r36   k68 ; k68 = 144
.line	1825	loadk        r37   k69 ; k69 = 88
.line	1825	loadk        r38   k63 ; k63 = 95
.line	1825	loadk        r39   k70 ; k70 = 118
.line	1825	loadk        r40   k16 ; k16 = 59
.line	1825	loadk        r41   k71 ; k71 = 148
.line	1825	loadk        r42   k72 ; k72 = 227
.line	1825	loadk        r43   k73 ; k73 = 176
.line	1825	loadk        r44   k60 ; k60 = 80
.line	1825	loadk        r45   k74 ; k74 = 231
.line	1825	loadk        r46   k75 ; k75 = 56
.line	1825	loadk        r47   k76 ; k76 = 85
.line	1825	loadk        r48   k77 ; k77 = 166
.line	1825	loadk        r49    k5 ; k5 = 40
.line	1825	call          r9    41     2
.line	1825	getupval     r10    u3
.line	1825	loadk        r11   k78 ; k78 = 19
.line	1825	call         r10     2     0
.line	1825	setlist       r7     0     1
.line	1825	call          r6     2     2
.line	1825	getupval      r7    u5
.line	1825	move          r8    r2
.line	1825	call          r7     2     2
.line	1825	getupval      r8    u5
.line	1825	move          r9    r1
.line	1825	call          r8     2     0
.line	1825	call          r5     0     2
.line	1825	move          r4    r5
.line	1825	gettabup      r5    u0   k79 ; k79 = "log_error"
.line	1825	move          r6    r4
.line	1825	call          r5     2     1
.line	1825	loadbool      r5     0     0
.line	1825	loadbool      r6     0     0
.line	1825	move          r7    r4
.line	1825	return        r5     4
.label	l141
.line	1825	loadnil       r5     1
.line	1825	getupval      r7    u2
.line	1825	gettabup      r8    u0   k80 ; k80 = "slua"
.line	1825	call          r7     2     2
.line	1825	getupval      r8    u3
.line	1825	loadk         r9   k81 ; k81 = 20
.line	1825	loadk        r10   k82 ; k82 = 153
.line	1825	loadk        r11   k83 ; k83 = 39
.line	1825	loadk        r12   k25 ; k25 = 197
.line	1825	loadk        r13    k7 ; k7 = 214
.line	1825	call          r8     6     2
.line	1825	eq             0    r7    r8
.line	1825	jmp            0  l197
.line	1825	getupval      r7    u2
.line	1825	gettabup      r8    u0   k80 ; k80 = "slua"
.line	1825	gettable      r8    r8   k84 ; k84 = "pcall"
.line	1825	call          r7     2     2
.line	1825	getupval      r8    u3
.line	1825	loadk         r9   k85 ; k85 = 6
.line	1825	loadk        r10    k4 ; k4 = 141
.line	1825	loadk        r11   k13 ; k13 = 43
.line	1825	loadk        r12   k14 ; k14 = 202
.line	1825	loadk        r13   k86 ; k86 = 199
.line	1825	loadk        r14   k12 ; k12 = 38
.line	1825	loadk        r15   k27 ; k27 = 137
.line	1825	loadk        r16   k87 ; k87 = 67
.line	1825	call          r8     9     2
.line	1825	eq             0    r7    r8
.line	1825	jmp            0  l197
.line	1825	gettabup      r7    u0   k80 ; k80 = "slua"
.line	1825	gettable      r7    r7   k88 ; k88 = "TimeoutIgnoreHookFla" (truncated)
.line	1825	test          r7     0
.line	1825	jmp            0  l177
.line	1825	gettabup      r7    u0   k80 ; k80 = "slua"
.line	1825	gettable      r7    r7   k88 ; k88 = "TimeoutIgnoreHookFla" (truncated)
.line	1825	call          r7     1     1
.label	l177
.line	1825	gettabup      r7    u0   k10 ; k10 = "table"
.line	1825	gettable      r7    r7   k89 ; k89 = "pack"
.line	1825	gettabup      r8    u0   k80 ; k80 = "slua"
.line	1825	gettable      r8    r8   k84 ; k84 = "pcall"
.line	1825	getupval      r9    u6
.line	1825	move         r10    r3
.line	1825	move         r11    r2
.line	1825	vararg       r12     0
.line	1825	call          r8     0     0
.line	1825	call          r7     0     2
.line	1825	move          r5    r7
.line	1825	gettabup      r7    u0   k80 ; k80 = "slua"
.line	1825	gettable      r7    r7   k90 ; k90 = "TimeoutIgnoreHookFla" (truncated)
.line	1825	test          r7     0
.line	1825	jmp            0  l195
.line	1825	gettabup      r7    u0   k80 ; k80 = "slua"
.line	1825	gettable      r7    r7   k90 ; k90 = "TimeoutIgnoreHookFla" (truncated)
.line	1825	call          r7     1     1
.label	l195
.line	1825	loadk         r6   k91 ; k91 = 3
.line	1825	jmp            0  l206
.label	l197
.line	1825	gettabup      r7    u0   k10 ; k10 = "table"
.line	1825	gettable      r7    r7   k89 ; k89 = "pack"
.line	1825	gettabup      r8    u0   k84 ; k84 = "pcall"
.line	1825	move          r9    r3
.line	1825	vararg       r10     0
.line	1825	call          r8     0     0
.line	1825	call          r7     0     2
.line	1825	move          r5    r7
.line	1825	loadk         r6   k47 ; k47 = 2
.label	l206
.line	1825	gettable      r7    r5   k92 ; k92 = 1
.line	1825	eq             0    r6   k91 ; k91 = 3
.line	1825	jmp            0  l212
.line	1825	gettable      r8    r5   k47 ; k47 = 2
.line	1825	eq             1    r8   k93 ; k93 = true
.line	1825	jmp            0  l215
.label	l212
.line	1825	loadbool      r8     0     0
.line	1825	jmp            0  l216
.line	1825	loadbool      r8     0     1
.label	l215
.line	1825	loadbool      r8     1     0
.label	l216
.line	1825	test          r8     0
.line	1825	jmp            0  l296
.line	1825	getupval      r9    u4
.line	1825	gettabup     r10    u0   k10 ; k10 = "table"
.line	1825	gettable     r10   r10   k11 ; k11 = "concat"
.line	1825	newtable     r11     1     0
.line	1825	getupval     r12    u3
.line	1825	loadk        r13   k12 ; k12 = 38
.line	1825	loadk        r14    k4 ; k4 = 141
.line	1825	loadk        r15   k13 ; k13 = 43
.line	1825	loadk        r16   k14 ; k14 = 202
.line	1825	loadk        r17   k15 ; k15 = 230
.line	1825	loadk        r18   k16 ; k16 = 59
.line	1825	loadk        r19   k17 ; k17 = 143
.line	1825	loadk        r20   k18 ; k18 = 65
.line	1825	loadk        r21    k7 ; k7 = 214
.line	1825	loadk        r22   k19 ; k19 = 195
.line	1825	loadk        r23   k20 ; k20 = 198
.line	1825	loadk        r24   k21 ; k21 = 11
.line	1825	loadk        r25   k22 ; k22 = 89
.line	1825	loadk        r26   k23 ; k23 = 13
.line	1825	loadk        r27   k24 ; k24 = 106
.line	1825	loadk        r28   k25 ; k25 = 197
.line	1825	loadk        r29   k26 ; k26 = 244
.line	1825	loadk        r30   k27 ; k27 = 137
.line	1825	loadk        r31   k28 ; k28 = 91
.line	1825	loadk        r32   k29 ; k29 = 253
.line	1825	loadk        r33    k9 ; k9 = 0
.line	1825	loadk        r34   k30 ; k30 = 30
.line	1825	loadk        r35   k31 ; k31 = 250
.line	1825	loadk        r36   k32 ; k32 = 113
.line	1825	loadk        r37   k33 ; k33 = 200
.line	1825	loadk        r38   k26 ; k26 = 244
.line	1825	loadk        r39   k34 ; k34 = 222
.line	1825	loadk        r40   k35 ; k35 = 16
.line	1825	loadk        r41   k36 ; k36 = 73
.line	1825	loadk        r42   k94 ; k94 = 62
.line	1825	loadk        r43   k95 ; k95 = 96
.line	1825	loadk        r44   k96 ; k96 = 192
.line	1825	loadk        r45   k67 ; k67 = 160
.line	1825	loadk        r46   k97 ; k97 = 185
.line	1825	loadk        r47   k87 ; k87 = 67
.line	1825	loadk        r48   k29 ; k29 = 253
.line	1825	loadk        r49   k98 ; k98 = 54
.line	1825	loadk        r50   k37 ; k37 = 29
.line	1825	loadk        r51   k77 ; k77 = 166
.line	1825	loadk        r52    k5 ; k5 = 40
.line	1825	call         r12    41     2
.line	1825	getupval     r13    u3
.line	1825	loadk        r14   k78 ; k78 = 19
.line	1825	loadk        r15   k99 ; k99 = 139
.line	1825	loadk        r16   k57 ; k57 = 107
.line	1825	loadk        r17   k27 ; k27 = 137
.line	1825	loadk        r18  k100 ; k100 = 208
.line	1825	loadk        r19   k83 ; k83 = 39
.line	1825	loadk        r20   k50 ; k50 = 147
.line	1825	loadk        r21   k87 ; k87 = 67
.line	1825	loadk        r22   k50 ; k50 = 147
.line	1825	loadk        r23   k59 ; k59 = 170
.line	1825	loadk        r24  k101 ; k101 = 135
.line	1825	loadk        r25  k102 ; k102 = 72
.line	1825	loadk        r26  k103 ; k103 = 79
.line	1825	call         r13    14     0
.line	1825	setlist      r11     0     1
.line	1825	call         r10     2     2
.line	1825	getupval     r11    u5
.line	1825	move         r12    r2
.line	1825	call         r11     2     2
.line	1825	getupval     r12    u5
.line	1825	move         r13    r1
.line	1825	call         r12     2     0
.line	1825	call          r9     0     2
.line	1825	move          r4    r9
.line	1825	gettabup      r9    u0   k79 ; k79 = "log_error"
.line	1825	move         r10    r4
.line	1825	call          r9     2     1
.line	1825	loadbool      r9     0     0
.line	1825	loadbool     r10     1     0
.line	1825	move         r11    r4
.line	1825	return        r9     4
.label	l296
.line	1825	test          r7     1
.line	1825	jmp            0  l374
.line	1825	getupval      r9    u4
.line	1825	gettabup     r10    u0   k10 ; k10 = "table"
.line	1825	gettable     r10   r10   k11 ; k11 = "concat"
.line	1825	newtable     r11     1     0
.line	1825	getupval     r12    u3
.line	1825	loadk        r13   k12 ; k12 = 38
.line	1825	loadk        r14    k4 ; k4 = 141
.line	1825	loadk        r15   k13 ; k13 = 43
.line	1825	loadk        r16   k14 ; k14 = 202
.line	1825	loadk        r17   k15 ; k15 = 230
.line	1825	loadk        r18   k16 ; k16 = 59
.line	1825	loadk        r19   k17 ; k17 = 143
.line	1825	loadk        r20   k18 ; k18 = 65
.line	1825	loadk        r21    k7 ; k7 = 214
.line	1825	loadk        r22   k19 ; k19 = 195
.line	1825	loadk        r23   k20 ; k20 = 198
.line	1825	loadk        r24   k21 ; k21 = 11
.line	1825	loadk        r25   k22 ; k22 = 89
.line	1825	loadk        r26   k23 ; k23 = 13
.line	1825	loadk        r27   k24 ; k24 = 106
.line	1825	loadk        r28   k25 ; k25 = 197
.line	1825	loadk        r29   k26 ; k26 = 244
.line	1825	loadk        r30   k27 ; k27 = 137
.line	1825	loadk        r31   k28 ; k28 = 91
.line	1825	loadk        r32   k29 ; k29 = 253
.line	1825	loadk        r33    k9 ; k9 = 0
.line	1825	loadk        r34   k30 ; k30 = 30
.line	1825	loadk        r35   k31 ; k31 = 250
.line	1825	loadk        r36   k32 ; k32 = 113
.line	1825	loadk        r37   k33 ; k33 = 200
.line	1825	loadk        r38   k15 ; k15 = 230
.line	1825	loadk        r39    k7 ; k7 = 214
.line	1825	loadk        r40   k81 ; k81 = 20
.line	1825	loadk        r41  k104 ; k104 = 64
.line	1825	loadk        r42  k105 ; k105 = 52
.line	1825	loadk        r43   k32 ; k32 = 113
.line	1825	loadk        r44  k106 ; k106 = 154
.line	1825	loadk        r45   k67 ; k67 = 160
.line	1825	loadk        r46  k107 ; k107 = 187
.line	1825	loadk        r47  k108 ; k108 = 77
.line	1825	loadk        r48  k109 ; k109 = 252
.line	1825	loadk        r49    k8 ; k8 = 61
.line	1825	loadk        r50  k110 ; k110 = 4
.line	1825	loadk        r51  k111 ; k111 = 188
.line	1825	loadk        r52   k46 ; k46 = 45
.line	1825	call         r12    41     2
.line	1825	getupval     r13    u3
.line	1825	loadk        r14  k112 ; k112 = 69
.line	1825	loadk        r15   k99 ; k99 = 139
.line	1825	loadk        r16  k113 ; k113 = 105
.line	1825	loadk        r17   k27 ; k27 = 137
.line	1825	loadk        r18    k7 ; k7 = 214
.line	1825	loadk        r19    k8 ; k8 = 61
.line	1825	loadk        r20   k71 ; k71 = 148
.line	1825	loadk        r21  k114 ; k114 = 23
.line	1825	loadk        r22  k115 ; k115 = 216
.line	1825	loadk        r23  k116 ; k116 = 181
.line	1825	loadk        r24  k117 ; k117 = 212
.line	1825	call         r13    12     0
.line	1825	setlist      r11     0     1
.line	1825	call         r10     2     2
.line	1825	getupval     r11    u5
.line	1825	move         r12    r1
.line	1825	call         r11     2     2
.line	1825	getupval     r12    u5
.line	1825	gettable     r13    r5    r6
.line	1825	call         r12     2     0
.line	1825	call          r9     0     2
.line	1825	move          r4    r9
.line	1825	gettabup      r9    u0   k79 ; k79 = "log_error"
.line	1825	move         r10    r4
.line	1825	call          r9     2     1
.line	1825	loadbool      r9     0     0
.line	1825	loadbool     r10     0     0
.line	1825	gettable     r11    r5    r6
.line	1825	return        r9     4
.label	l374
.line	1825	loadbool      r9     1     0
.line	1825	loadbool     r10     0     0
.line	1825	gettabup     r11    u0   k10 ; k10 = "table"
.line	1825	gettable     r11   r11  k118 ; k118 = "unpack"
.line	1825	move         r12    r5
.line	1825	move         r13    r6
.line	1825	gettable     r14    r5  k119 ; k119 = "n"
.line	1825	call         r11     4     0
.line	1825	return        r9     0
.line	1825	return        r0     1
.line	1825	gettabup      r3    u1   k55 ; k55 = 27
.line	1825	move          r0    r0
.line	1825	move          r0    r0
.line	1825	return        r0     1

.function	main/f128

.source	"=[V12L:324e6be84cf78189:e94b2d2862c771d3]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f129

.source	"=[V11_@Black_MagicYT BlackMagiYT_LBIND_00]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_0_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f130

.source	"=[V11_@Black_MagicYT BlackMagiYT_SYSC_01]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_1_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f131

.source	"=[V11_@Black_MagicYT BlackMagiYT_MRGE_02]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_2_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f132

.source	"=[V11_@Black_MagicYT BlackMagiYT_POOL_03]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_3_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

