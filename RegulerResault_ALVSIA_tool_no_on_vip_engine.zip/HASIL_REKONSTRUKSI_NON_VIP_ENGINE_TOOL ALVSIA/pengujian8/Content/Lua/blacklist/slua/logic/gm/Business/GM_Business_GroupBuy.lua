local GM_HELPER_PATH = "blacklist.slua.logic.gm.Business.GM_Business_GroupBuy_Helper"

local function _ParseNumberArgs(cmdArgsTable, expect_count)
  if not cmdArgsTable or expect_count > #cmdArgsTable then
    return nil
  end
  local args = {}
  for i = 1, expect_count do
    local n = tonumber(cmdArgsTable[i])
    if not n then
      return nil
    end
    args[i] = n
  end
  return args
end

local function _TipUsage(gmUI, usage)
  if gmUI and gmUI.SetTips then
    gmUI:SetTips("input invalid, expect: " .. usage)
  end
end

local GM_Business_GroupBuy = {
  {
    strButtonName = "\229\165\189\229\143\139\229\184\174\230\136\145\231\160\141\228\184\128\229\136\128",
    searchName = "",
    cmd = "gm_new_bargain_help_bargain_id bargain_id amount order_index",
    tips = "amount \239\188\155<=0 \232\161\168\231\164\186\231\160\141\229\136\176\229\186\149\228\187\183\227\128\130order_index \232\174\162\229\141\149\231\180\162\229\188\149(1=\231\172\172\228\184\128\228\184\170)\239\188\155bargain_id\228\184\186\231\169\186\239\188\136\229\141\179\232\139\177\230\150\135\229\143\140\229\188\149\229\143\183\239\188\137\229\136\153\230\140\137\231\180\162\229\188\149\232\135\170\229\138\168\229\143\150\227\128\130\232\135\170\229\138\168\231\148\168\229\165\189\229\143\139\229\136\151\232\161\168\233\135\140\231\172\172\228\184\128\228\184\170\229\165\189\229\143\139\231\154\132 uid",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local bargain_id = cmdArgsTable and cmdArgsTable[1]
      if bargain_id ~= "" then
      end
      bargain_id = nil
      local amount = tonumber(cmdArgsTable and cmdArgsTable[2])
      if not amount then
        _TipUsage(gmUI, "bargain_id (string) amount (number) [order_index (number)]")
        return false
      end
      local order_index = tonumber(cmdArgsTable and cmdArgsTable[3]) or 1
      local Logic_GMHelper = require(GM_HELPER_PATH)
      Logic_GMHelper.SendGMHelpCut(bargain_id, amount, order_index, gmUI)
      return false
    end
  },
  {
    strButtonName = "\229\165\189\229\143\139\229\184\174\230\136\145\231\160\141\229\136\176\229\186\149\228\187\183",
    searchName = "",
    cmd = "gm_new_bargain_help_cut_to_floor bargain_id order_index",
    tips = "order_index \232\174\162\229\141\149\231\180\162\229\188\149(1=\231\172\172\228\184\128\228\184\170)\239\188\155bargain_id \231\149\153\231\169\186\239\188\136\229\141\179\232\139\177\230\150\135\229\143\140\229\188\149\229\143\183\239\188\137\229\136\153\230\140\137\231\180\162\229\188\149\232\135\170\229\138\168\229\143\150\227\128\130\232\135\170\229\138\168\231\148\168\229\165\189\229\143\139\229\136\151\232\161\168\233\135\140\231\172\172\228\184\128\228\184\170\229\165\189\229\143\139\231\154\132 uid",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local bargain_id = cmdArgsTable and cmdArgsTable[1]
      if bargain_id ~= "" then
      end
      bargain_id = nil
      local order_index = tonumber(cmdArgsTable and cmdArgsTable[2]) or 1
      local Logic_GMHelper = require(GM_HELPER_PATH)
      Logic_GMHelper.SendGMHelpCutToFloor(bargain_id, order_index, gmUI)
      return false
    end
  },
  {
    strButtonName = "\231\160\141\228\187\183\229\143\141\233\166\136\230\176\148\230\179\161",
    searchName = "",
    cmd = "bargain_popup mode",
    tips = "mode=1 \231\160\141\232\135\179\229\186\149\228\187\183\239\188\140mode=2 \230\142\165\232\191\145\229\186\149\228\187\183\239\188\140mode=3 \229\165\189\229\143\139\229\184\174\231\160\141\227\128\130\232\135\170\229\138\168\231\148\168\231\160\141\228\187\183\229\136\151\232\161\168\231\172\172\228\184\128\228\184\170\232\174\162\229\141\149",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local mode = tonumber(cmdArgsTable and cmdArgsTable[1]) or 1
      if mode ~= 1 and mode ~= 2 and mode ~= 3 then
        _TipUsage(gmUI, "mode (1=\231\160\141\232\135\179\229\186\149\228\187\183, 2=\230\142\165\232\191\145\229\186\149\228\187\183, 3=\229\165\189\229\143\139\229\184\174\231\160\141)")
        return false
      end
      local Logic_GMHelper = require(GM_HELPER_PATH)
      Logic_GMHelper.ShowBargainPopupByMode(mode, gmUI)
      return false
    end
  },
  {
    strButtonName = "\231\160\141\228\187\183\229\143\141\233\166\136\229\188\185\231\170\151",
    searchName = "",
    cmd = "discount_feedback_popup mode",
    tips = "mode=1 \231\160\141\232\135\179\230\156\128\228\189\142\228\187\183\239\188\140mode=2 \230\142\165\232\191\145\229\186\149\228\187\183\227\128\130\232\135\170\229\138\168\231\148\168\231\160\141\228\187\183\229\136\151\232\161\168\231\172\172\228\184\128\228\184\170\232\174\162\229\141\149",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local mode = tonumber(cmdArgsTable and cmdArgsTable[1]) or 1
      if mode ~= 1 and mode ~= 2 then
        _TipUsage(gmUI, "mode (1=\231\160\141\232\135\179\230\156\128\228\189\142\228\187\183, 2=\230\142\165\232\191\145\229\186\149\228\187\183)")
        return false
      end
      local Logic_GMHelper = require(GM_HELPER_PATH)
      Logic_GMHelper.OpenDiscountFeedbackPopup(mode, gmUI)
      return false
    end
  },
  {
    strButtonName = "\229\184\174\231\160\141\229\143\141\233\166\136\229\188\185\231\170\151",
    searchName = "",
    cmd = "discount_bargain_popup mode",
    tips = "mode=1 \230\153\174\233\128\154\231\160\141\228\187\183\239\188\140mode=2 \229\164\167\233\162\157\231\160\141\228\187\183\227\128\130\232\135\170\229\138\168\231\148\168\231\160\141\228\187\183\229\136\151\232\161\168\231\172\172\228\184\128\228\184\170\232\174\162\229\141\149",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local mode = tonumber(cmdArgsTable and cmdArgsTable[1]) or 1
      if mode ~= 1 and mode ~= 2 then
        _TipUsage(gmUI, "mode (1=\230\153\174\233\128\154\231\160\141\228\187\183, 2=\229\164\167\233\162\157\231\160\141\228\187\183)")
        return false
      end
      local Logic_GMHelper = require(GM_HELPER_PATH)
      Logic_GMHelper.OpenBargainPopup(mode, gmUI)
      return false
    end
  },
  {
    strButtonName = "\233\135\141\231\189\174\230\136\145\231\154\132\231\160\141\228\187\183\232\174\162\229\141\149",
    searchName = "gm_new_bargain_clear",
    cmd = "gm_new_bargain_clear",
    tips = "\230\184\133\231\169\186\230\136\145\230\137\128\230\156\137 ACTIVE \232\174\162\229\141\149, \228\184\139\230\172\161\230\139\137\229\143\150\230\151\182\231\148\177\230\156\141\229\138\161\231\171\175\230\140\137 region \233\135\141\229\187\186",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local Logic_GMHelper = require(GM_HELPER_PATH)
      Logic_GMHelper.ResetBargainOrders(gmUI)
      return false
    end
  },
  {
    strButtonName = "\230\184\133\233\153\164\231\160\141\228\187\183\231\186\162\231\130\185",
    searchName = "",
    cmd = "bargain_clear_reddot",
    tips = "\233\135\141\231\189\174\232\174\162\229\141\149\229\144\142\231\186\162\231\130\185\230\174\139\231\149\153\230\151\182\228\189\191\231\148\168\239\188\140\230\184\133\233\153\164\230\137\128\230\156\137\231\160\141\228\187\183\231\186\162\231\130\185",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local Logic_GMHelper = require(GM_HELPER_PATH)
      Logic_GMHelper.ClearBargainRedDot(gmUI)
      return false
    end
  },
  {
    strButtonName = "\230\184\133\233\153\164\228\187\187\229\138\161\231\160\141\228\187\183\229\188\149\229\175\188\231\188\147\229\173\152",
    searchName = "",
    tips = "\230\184\133\233\153\164\230\136\144\229\138\159",
    fHandle = function(gmUI)
      local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
      PlayerPrefsSystem.SaveTableToFile_N({}, PlayerPrefsSystem.ePlayerPrefsType.eBargainTaskActGuide)
    end
  },
  {
    strButtonName = "\230\184\133\233\153\164\231\160\141\228\187\183\229\188\185\231\170\151\231\188\147\229\173\152",
    searchName = "",
    tips = "\230\184\133\233\153\164\230\136\144\229\138\159",
    fHandle = function(gmUI)
      local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
      PlayerPrefsSystem.SaveTableToFile_N({}, PlayerPrefsSystem.ePlayerPrefsType.eBargainRedSuc)
    end
  },
  {
    strButtonName = "\230\184\133\233\153\164\230\142\168\233\128\129\231\188\147\229\173\152",
    searchName = "",
    tips = "1=\229\155\162\232\180\173\231\188\147\229\173\152(\233\187\152\232\174\164) 2=\231\160\141\228\187\183\231\188\147\229\173\152",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
      local param = tonumber(cmdArgsTable and cmdArgsTable[1]) or 1
      if param == 2 then
        PlayerPrefsSystem.SaveTableToFile_N({}, PlayerPrefsSystem.ePlayerPrefsType.eBargainPush)
        if gmUI and gmUI.SetTips then
          gmUI:SetTips("\229\183\178\230\184\133\233\153\164\231\160\141\228\187\183\230\142\168\233\128\129\231\188\147\229\173\152")
        end
      else
        PlayerPrefsSystem.SaveTableToFile_N({}, PlayerPrefsSystem.ePlayerPrefsType.eGroupBuyPush)
        if gmUI and gmUI.SetTips then
          gmUI:SetTips("\229\183\178\230\184\133\233\153\164\229\155\162\232\180\173\230\142\168\233\128\129\231\188\147\229\173\152")
        end
      end
      return false
    end
  },
  {
    strButtonName = "\229\184\174\231\160\141\231\161\174\232\174\164\229\188\185\231\170\151\229\188\128\229\133\179",
    searchName = "",
    tips = "\229\136\135\230\141\162\229\184\174\231\160\141\231\161\174\232\174\164\229\188\185\231\170\151 GM \229\188\128\229\133\179\239\188\136\233\187\152\232\174\164\229\133\179\233\151\173\239\188\140\230\137\147\229\188\128\229\144\142\230\151\160\232\174\186\230\152\175\229\144\166\229\164\150\233\147\190\232\183\179\232\189\172\233\131\189\228\188\154\229\188\185\229\135\186\231\161\174\232\174\164\229\188\185\231\170\151\239\188\137",
    fHandle = function(gmUI)
      local Logic_GMHelper = require(GM_HELPER_PATH)
    end
  },
  {
    strButtonName = "\231\148\159\230\136\144Facebook\229\164\150\233\147\190",
    searchName = "",
    tips = "\229\174\140\230\149\180\232\181\176\231\148\159\228\186\167\233\147\190\232\183\175\239\188\154\229\143\150\232\174\162\229\141\149->\228\184\139\232\189\189\232\131\140\230\153\175\229\155\190->\228\184\138\228\188\160S3->GetDefaultShareUrl\230\139\188\232\163\133->\232\190\147\229\135\186Facebook\229\136\134\228\186\171\229\164\150\233\147\190\239\188\136\228\184\141\232\181\176\231\159\173\233\147\190\239\188\137",
    fHandle = function(gmUI)
      local Logic_GMHelper = require(GM_HELPER_PATH)
      Logic_GMHelper.GenerateFacebookShareUrl(gmUI)
    end
  },
  {
    strButtonName = "\229\188\185\229\135\186\229\133\168\229\177\143\230\129\173\229\150\156\232\142\183\229\190\151",
    searchName = "",
    cmd = "item_id",
    tips = "\229\143\130\230\149\176\228\184\186\231\137\169\229\147\129ID\239\188\140\229\188\185\229\135\186\229\133\168\229\177\143\230\129\173\229\150\156\232\142\183\229\190\151\231\149\140\233\157\162\229\177\149\231\164\186\232\175\165\231\137\169\229\147\129",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local item_id = tonumber(cmdArgsTable and cmdArgsTable[1])
      if not item_id or item_id <= 0 then
        gmUI:SetTips("\232\175\183\232\190\147\229\133\165\230\156\137\230\149\136\231\154\132\231\137\169\229\147\129ID")
        return false
      end
      local Logic_GMHelper = require(GM_HELPER_PATH)
      Logic_GMHelper.ShowFullScreenCongrats(gmUI, item_id)
      return false
    end
  },
  {
    strButtonName = "\230\148\190\229\188\128\232\174\161\230\149\176\229\153\168\230\166\156\232\181\155\229\173\163\233\153\144\229\136\182",
    searchName = "gm_weapon_kill_rank_open",
    cmd = "gm_weapon_kill_rank_open",
    tips = "\230\148\190\229\188\128\229\188\128\230\148\190\232\181\155\229\173\163\233\153\144\229\136\182\239\188\140\232\167\163\229\134\179 19210005\239\188\136\230\166\156\229\141\149\230\156\170\229\188\128\230\148\190\239\188\137\227\128\130\229\143\175\229\184\166\229\143\130\230\149\176\230\140\135\229\174\154\232\181\155\229\173\163\239\188\140\229\166\130 gm_weapon_kill_rank_open(51)\227\128\130\228\184\141\228\188\160\233\187\152\232\174\164\230\148\190\229\188\128\229\189\147\229\137\141",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local Logic_GMHelper = require(GM_HELPER_PATH)
      Logic_GMHelper.OpenWeaponKillRank(gmUI, cmdArgsTable and cmdArgsTable[1])
      return false
    end
  },
  {
    strButtonName = "\230\159\165\232\175\162\232\174\161\230\149\176\229\153\168\230\166\156\231\138\182\230\128\129",
    searchName = "gm_weapon_kill_rank_status",
    cmd = "gm_weapon_kill_rank_status weapon_id",
    tips = "\230\137\147\229\141\176\230\166\156\229\141\149\230\142\146\230\159\165\228\191\161\230\129\175\239\188\136is_open/ver_ok/armed \231\173\137\239\188\137\227\128\130\228\184\141\228\188\160 weapon_id \229\143\170\230\137\147\229\141\176\229\133\168\229\177\128\231\138\182\230\128\129\239\188\155\228\188\160\228\186\134\229\143\175\231\156\139\230\140\135\229\174\154\230\158\170\230\162\176\229\173\144\230\166\156\232\175\166\230\131\133",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local Logic_GMHelper = require(GM_HELPER_PATH)
      Logic_GMHelper.StatusWeaponKillRank(gmUI, cmdArgsTable and cmdArgsTable[1])
      return false
    end
  },
  {
    strButtonName = "\233\129\141\229\142\134\230\137\147\229\141\176\230\137\128\230\156\137\230\158\170\228\184\138\230\166\156\231\138\182\230\128\129",
    searchName = "gm_weapon_kill_rank_status_all",
    cmd = "gm_weapon_kill_rank_status_all",
    tips = "\233\129\141\229\142\134\230\137\128\230\156\137\229\184\166\232\174\161\230\149\176\229\153\168\231\137\185\230\128\167\231\154\132\230\158\170\239\188\140\233\128\144\230\138\138\229\143\145 gm_weapon_kill_rank_status(weapon_id)\239\188\140\230\156\141\229\138\161\231\171\175\230\137\147\229\141\176\230\175\143\230\138\138\230\158\170\231\154\132 armed/my_total/season_base\239\188\140\230\142\146\230\159\165\229\147\170\230\138\138\230\158\170\230\178\161\230\149\176\230\141\174",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local Logic_GMHelper = require(GM_HELPER_PATH)
      Logic_GMHelper.StatusAllWeaponKillRank(gmUI)
      return false
    end
  },
  {
    strButtonName = "\231\148\159\230\136\144\230\137\128\230\156\137\230\158\170\230\162\176\232\174\161\230\149\176\229\153\168\230\166\156\230\149\176\230\141\174",
    searchName = "gm_weapon_kill_rank_fill",
    cmd = "gm_weapon_kill_rank_fill count",
    tips = "\233\129\141\229\142\134\230\137\128\230\156\137\229\184\166\232\174\161\230\149\176\229\153\168\231\137\185\230\128\167\231\154\132\230\158\170\230\162\176\239\188\140\233\128\144\230\138\138\232\176\131\231\148\168 gm_weapon_kill_rank_fill(weapon_id, count) \233\128\160\229\129\135\231\142\169\229\174\182\229\161\171\230\166\156\239\188\136\231\148\159\230\182\175\230\166\156+\232\181\155\229\173\163\230\166\156\233\131\189\229\161\171\239\188\137\227\128\130count \233\187\152\232\174\164\228\184\186 20",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local Logic_GMHelper = require(GM_HELPER_PATH)
      Logic_GMHelper.FillAllWeaponKillRank(gmUI, cmdArgsTable and cmdArgsTable[1])
      return false
    end
  },
  {
    strButtonName = "\230\184\133\233\153\164\230\137\128\230\156\137\230\158\170\230\162\176\232\174\161\230\149\176\229\153\168\230\166\156\229\129\135\230\149\176\230\141\174",
    searchName = "gm_weapon_kill_rank_clear_fake",
    cmd = "gm_weapon_kill_rank_clear_fake count",
    tips = "\233\129\141\229\142\134\230\137\128\230\156\137\229\184\166\232\174\161\230\149\176\229\153\168\231\137\185\230\128\167\231\154\132\230\158\170\230\162\176\239\188\140\233\128\144\230\138\138\232\176\131\231\148\168 gm_weapon_kill_rank_clear_fake(weapon_id, count) \230\184\133\230\142\137\229\129\135\230\149\176\230\141\174\227\128\130count \233\187\152\232\174\164\228\184\186 20",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local Logic_GMHelper = require(GM_HELPER_PATH)
      Logic_GMHelper.ClearAllWeaponKillRankFake(gmUI, cmdArgsTable and cmdArgsTable[1])
      return false
    end
  },
  {
    strButtonName = "\232\183\179\232\189\172\232\174\161\230\149\176\229\153\168\230\166\156",
    searchName = "",
    cmd = "jump_weapon_kill_rank",
    tips = "\230\148\190\229\188\128\230\173\166\229\153\168\230\136\152\229\138\155/\232\174\161\230\149\176\229\153\168\230\166\156\229\188\128\230\148\190\230\163\128\230\159\165\239\188\136bIsfake=true\239\188\137\229\185\182\231\155\180\230\142\165\232\183\179\232\189\172\230\142\146\232\161\140\230\166\156\232\174\161\230\149\176\229\153\168\230\166\156\239\188\140\231\148\168\228\186\142\230\181\139\232\175\149\230\151\182\231\187\149\232\191\135\232\181\155\229\173\163/\229\188\128\229\133\179\233\153\144\229\136\182",
    fHandle = function(gmUI)
      local Logic_GMHelper = require(GM_HELPER_PATH)
      UIManager.CloseUI(UIManager.UI_Config.Lobby_GM)
      Logic_GMHelper.JumpWeaponKillRank(gmUI)
    end
  },
  {
    strButtonName = "\230\137\147\229\188\128\232\189\189\229\133\183\229\148\174\229\141\150\228\184\187\231\149\140\233\157\162",
    searchName = "",
    tips = "\231\155\180\230\142\165\230\137\147\229\188\128 WOW \232\189\189\229\133\183\229\148\174\229\141\150\230\180\187\229\138\168\228\184\187\231\149\140\233\157\162\239\188\136VehicleSales_Main_UIBP\239\188\137\239\188\140\231\148\168\228\186\142\230\181\139\232\175\149",
    fHandle = function(gmUI)
      UIManager.CloseUI(UIManager.UI_Config.Lobby_GM)
      UIManager.ShowUI(UIManager.UI_Config.VehicleSales_Main_UIBP, {})
    end
  },
  {
    strButtonName = "\230\184\133\233\153\164\232\189\189\229\133\183\229\148\174\229\141\150\232\167\163\233\148\129\229\138\168\231\148\187\231\188\147\229\173\152",
    searchName = "",
    tips = "\230\184\133\233\153\164 eVehicleSalesSportsCarUnlockAnim \230\156\172\229\156\176\230\160\135\232\174\176\239\188\140\233\135\141\232\191\155\232\189\189\229\133\183\229\148\174\229\141\150\228\184\187\231\149\140\233\157\162\229\143\175\229\134\141\230\172\161\232\167\166\229\143\145\232\183\145\232\189\166\232\167\163\233\148\129\229\138\168\231\148\187",
    fHandle = function(gmUI)
      local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
      PlayerPrefsSystem.SaveTableToFile_N({}, PlayerPrefsSystem.ePlayerPrefsType.eVehicleSalesSportsCarUnlockAnim)
      if gmUI and gmUI.SetTips then
        gmUI:SetTips("\229\183\178\230\184\133\233\153\164\232\189\189\229\133\183\229\148\174\229\141\150\232\167\163\233\148\129\229\138\168\231\148\187\231\188\147\229\173\152")
      end
    end
  },
  {
    strButtonName = "\230\137\185\233\135\143\232\142\183\229\143\150\230\183\152\230\177\176\232\174\161\230\149\176\229\153\168(\229\133\168\230\158\170\230\162\176)",
    searchName = "gm_add_kill_counter_all",
    cmd = "gm_add_kill_counter_all count",
    tips = "\230\137\185\233\135\143\229\143\145\230\148\190 61920001~61920013 \229\133\177 13 \228\184\170\230\183\152\230\177\176\232\174\161\230\149\176\229\153\168\239\188\136M416/AKM/SCAR-L/Kar98k/UZI/M249/UMP45/M24/AWM/M762/Vector/ACE32/AUG\239\188\137\227\128\130count \233\187\152\232\174\164\228\184\186 1",
    OnPreSendCallBack = function(gmUI, cmdArgsTable)
      local count = tonumber(cmdArgsTable and cmdArgsTable[1]) or 1
      if count <= 0 then
        gmUI:SetTips("count \229\191\133\233\161\187\229\164\167\228\186\142 0")
        return false
      end
      local gm_execute = RequireBlackList("blacklist.slua.logic.gm.logic_gm_execute")
      local KillCounterItemIds = {
        61920001,
        61920002,
        61920003,
        61920004,
        61920005,
        61920006,
        61920007,
        61920008,
        61920009,
        61920010,
        61920011,
        61920012,
        61920013
      }
      for _, itemId in ipairs(KillCounterItemIds) do
        gm_execute.GMCmd(string.format("gm_add_item %d %d", itemId, count))
      end
      gmUI:SetTips(string.format("\229\183\178\230\137\185\233\135\143\229\143\145\230\148\190 %d \228\184\170\230\183\152\230\177\176\232\174\161\230\149\176\229\153\168\239\188\140\230\175\143\228\184\170 x%d", #KillCounterItemIds, count))
      return false
    end
  },
  {
    strButtonName = "\229\148\164\232\181\183\230\139\188\229\155\162\230\136\144\229\138\159\229\188\185\231\170\151",
    searchName = "",
    tips = "\231\148\168\230\139\188\229\155\162\232\174\162\229\141\149\229\136\151\232\161\168\231\172\172\228\184\128\228\184\170\229\155\162\229\148\164\232\181\183 GroupBuying_Succeed_Popup_UIBP\239\188\136\230\151\160\232\174\162\229\141\149\229\136\153\230\143\144\231\164\186\239\188\137",
    fHandle = function(gmUI)
      local logic_group_buying = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying)
      local list = logic_group_buying:GetInGroupList()
      local group_info = list and list[1]
      if not group_info then
        for _, v in pairs(logic_group_buying.group_list or {}) do
          group_info = v[1]
          break
        end
      end
      if not group_info then
        if gmUI and gmUI.SetTips then
          gmUI:SetTips("\230\178\161\230\156\137\229\143\175\231\148\168\230\139\188\229\155\162\232\174\162\229\141\149")
        end
        return
      end
      UIManager.CloseUI(UIManager.UI_Config.Lobby_GM)
      UIManager.ShowUI(UIManager.UI_Config.GroupBuying_Succeed_Popup_UIBP, group_info)
    end
  }
}
return GM_Business_GroupBuy
