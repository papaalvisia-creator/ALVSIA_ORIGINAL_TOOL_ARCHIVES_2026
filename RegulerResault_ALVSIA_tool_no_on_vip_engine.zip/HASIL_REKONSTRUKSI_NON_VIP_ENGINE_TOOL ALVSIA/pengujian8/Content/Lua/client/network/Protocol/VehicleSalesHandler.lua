local NetManager = require("client.network.comm.NetManager")
local VehicleSalesHandler = {}

function VehicleSalesHandler.send_get_discount_sale_shop_req(act_id)
  NetManager.SendPkg(1870443751, act_id)
end

function VehicleSalesHandler.on_get_discount_sale_shop_rsp(ret, act_id, product)
  if ret ~= 0 then
    ShowNotice(ret)
  end
  local logic = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_vehicle_sales_data)
  if logic then
    logic:OnGetDiscountSaleShopRsp(ret, act_id, product)
  end
end

function VehicleSalesHandler.send_buy_discount_sale_req(act_id, client_price)
  log_format(bWriteLog and "[VehicleSales][Buy] send_buy_discount_sale_req pkg=2125517963 act_id=%s client_price=%s", tostring(act_id), tostring(client_price))
  NetManager.SendPkg(2125517963, act_id, client_price)
end

function VehicleSalesHandler.on_buy_discount_sale_rsp(ret, act_id, item_info, price_info)
  log_format(bWriteLog and "[VehicleSales][Buy] recv on_buy_discount_sale_rsp ret=%s act_id=%s item_info=%s price_info=%s", tostring(ret), tostring(act_id), tostring(item_info ~= nil), tostring(price_info ~= nil))
  if ret ~= 0 then
    ShowNotice(ret)
  end
  local logic = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_vehicle_sales_data)
  if logic then
    logic:OnBuyDiscountSaleRsp(ret, act_id, item_info, price_info)
  else
    log_format(bWriteLog and "[VehicleSales][Buy] on_buy_discount_sale_rsp: logic module is nil, rsp dropped")
  end
end

function VehicleSalesHandler.send_take_discount_sale_refund_req(act_id)
  NetManager.SendPkg(2098310427, act_id)
end

function VehicleSalesHandler.on_take_discount_sale_refund_rsp(ret, act_id, owed)
  if ret ~= 0 then
    ShowNotice(ret)
  end
  local logic = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_vehicle_sales_data)
  if logic then
    logic:OnTakeDiscountSaleRefundRsp(ret, act_id, owed)
  end
end

return VehicleSalesHandler
