_G.Net = _G.ScriptHelperNetInterface
_G.Client = _G.ScriptHelperClient
_G.Tss = _G.TssManager
if not Client then
  return
end
if IsEditor or IsWoWEditor and Client.IsDevelopment() then
  GameInstanceID = GameInstanceID or 0
  if _G.IsEnableMockGameSvr then
    GameInstanceID = GameInstanceID + 1
  end
end

function Client.GetTable(...)
  error((U1(114, 173, 64, 66, 72, 185, 225, 101, 151, 253, 48, 80, 13, 211, 136, 41, 178, 154, 1, 51, 153, 161, 149, 1, 143, 215, 50, 86, 20, 199, 210, 95)))
  return
end

function Client.GetTableData(...)
  error((U1(114, 173, 64, 66, 72, 185, 225, 101, 151, 253, 48, 80, 13, 211, 136, 41, 178, 154, 1, 51, 153, 161, 149, 101, 135, 205, 32, 2, 24, 200, 197, 10, 162, 159, 33, 99)))
  return
end

Client.bEditorSkipDownload = IsEditor and not Client.IsSplitMapPakVersion()
if not Client.IsShipping() then
else
  function assert(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_ then
        _ARG_1_ = _ARG_1_ or _ENV(70, 173, 86, 7, 121, 137, 233, 126, 152, 137, 55, 83, 8, 218, 195, 10, 246)
        
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
end
if Client.IsDevelopment() then
  if RequireBlackList((table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(69, 178, 68, 1, 96, 145, 233, 98, 130, 135, 52, 86, 8, 194, 201, 28, 249, 156, 32, 60, 143, 164, 157, 68, 185, 218, 41, 71, 18, 205, 152, 50, 178, 159, 4, 18, 162, 137, 137, 92),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(66, 138, 87, 3, 104, 152, 242)
  }))) then
  end
end
_G.UnrealNet = UnrealNet or {}
_G.NetUtil = NetUtil or {
  s2cNeedWaiting = {},
  tNetDisconnected = 0,
  tNetConnecting = 0,
  tNetConnected = 0,
  nDSTimeOutShowBitMask = 0,
  DSTimeOutLong = 1,
  DSTimeOutShort = 2,
  NetUnstableReport = {
    Enabled = false,
    HistoryMaxSize = 128,
    History = {},
    HistoryHeadIndex = 1,
    HistoryCount = 0,
    LastRecordedUnstable = nil
  }
}
NetUtil.ConnectSDKTimeOutSeconds = 15
NetUtil.ConnectLuaTimeOutSeconds = 20
NetUtil.SendTime = NetUtil.SendTime or 0
NetUtil.SendOneTime = NetUtil.SendOneTime or 0
NetUtil.LobbyDelaySendTime = NetUtil.LobbyDelaySendTime or 0
NetUtil.LobbyDelayRecvTime = NetUtil.LobbyDelayRecvTime or 0
NetUtil.gameTick = NetUtil.gameTick or false
NetUtil.showConnectionMsgTimes = NetUtil.showConnectionMsgTimes or 0
NetUtil.hasTryConnectForNetworkError = NetUtil.hasTryConnectForNetworkError or false
NetUtil.hasTryConnectForNetworkErrorTimes = NetUtil.hasTryConnectForNetworkErrorTimes or 0
NetUtil.isWattingDelayReconnect = NetUtil.isWattingDelayReconnect or false
NetUtil.checkWaitingReEnterGameNotify = NetUtil.checkWaitingReEnterGameNotify or false
NetUtil.waitingReEnterGameStartTime = NetUtil.waitingReEnterGameStartTime or 0
NetUtil.checkConnectingInFighting = false
NetUtil.checkConnectingInFightingTimes = 0
NetUtil.checkConnectingInFightingRandomInterval = 0
NetUtil.waitingConnectSuccessStartTime = NetUtil.waitingConnectSuccessStartTime or 0
NetUtil.checkEnterBattle = false
NetUtil.waitingEnterBattleStartTime = NetUtil.waitingEnterBattleStartTime or 0
NetUtil.LoadingTimeOut = 70
NetUtil.EnterBattleLoadingTime = 0
NetUtil.checkLoginOtherLobbyServer = false
NetUtil.checkLoginRsp = NetUtil.checkLoginRsp or false
NetUtil.checkLoginRetryTime = NetUtil.checkLoginRetryTime or 0
NetUtil.checkBattleLoginRetryTime = NetUtil.checkBattleLoginRetryTime or 0
NetUtil.sendLoginTime = NetUtil.sendLoginTime or 0
NetUtil.dsTimeOutRetryTimes = NetUtil.dsTimeOutRetryTimes or 0
NetUtil.dsTimeOutTipsUIShowing = NetUtil.dsTimeOutTipsUIShowing or false
NetUtil.CurTickTime = NetUtil.CurTickTime or 0
NetUtil.LastTickTime = NetUtil.LastTickTime or 0
NetUtil.needInitCentauriWhenLogin = NetUtil.needInitCentauriWhenLogin or false
NetUtil.noRefreshLogout = NetUtil.noRefreshLogout or false
NetUtil.LobbyResultMonitor = NetUtil.LobbyResultMonitor or {
  gameover = false,
  gamemode = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(),
  lobbyReconnTimes = 0
}
NetUtil.ResultMonitorStarTime = 0
NetUtil.BResultMonitorOpen = false
NetUtil.BBattleResultRecieved = false
NetUtil.PleaseReloginTimer = nil
NetUtil.EnterBattleGameID = (function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)()
NetUtil.STOP_CONNECT = false
NetUtil.EnterBattleTimeOutGameID = 0
NetUtil.EnterBattleStageDelegate = nil
NetUtil.EnterBattleTime = 0

function OnClientGameOver()
  if NetUtil.BBattleResultRecieved then
    return
  end
  NetUtil.BResultMonitorOpen = true
  NetUtil.ResultMonitorStarTime = U2.OSTime()
  NetUtil.LobbyResultMonitor.gameover = true
  NetUtil.LobbyResultMonitor.gamemode = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game):GetSubModeId(), NetUtil.LobbyResultMonitor
  return
end

function ResetResultMonitor()
  NetUtil.ResultMonitorStarTime = 0
  NetUtil.BResultMonitorOpen = false
  NetUtil.LobbyResultMonitor = {
    gameover = false,
    gamemode = 0,
    lobbyReconnTimes = 0
  }
  log_tree(U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 7, 55, 136, 168, 132, 115, 131, 202, 52, 78, 5, 235, 217, 16, 174, 138, 42, 48), NetUtil.LobbyResultMonitor)
  return
end

function UpdateResultMonitor()
  if not NetUtil.BResultMonitorOpen then
    return
  end
  if not NetUtil.LobbyResultMonitor then
    return
  end
  if not NetUtil.LobbyResultMonitor.gameover then
    return
  end
  if U1.OSTime() - NetUtil.ResultMonitorStarTime < 2 then
    return
  end
  NetUtil.ResultMonitorStarTime = U1.OSTime()
  NetUtil.LobbyResultMonitor.lobbyReconnTimes = NetUtil.LobbyResultMonitor.lobbyReconnTimes + 1
  if NetUtil.LobbyResultMonitor.lobbyReconnTimes < 5 then
    return
  end
  if Client.IsEditorDedicatedServer() then
    log(bWriteLog and table.concat({
      U2(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 0, 34, 159, 172, 132, 68, 180, 220, 50, 87, 29, 210, 251, 17, 169, 151, 49, 45, 153, 253, 169, 66),
      U2(98, 186, 76, 22, 100, 143, 196, 116, 146, 192, 50, 83, 21, 211, 194, 61, 178, 156, 35, 55, 137, 237, 130, 68, 146, 204, 51, 76)
    }))
    return
  end
  log(bWriteLog and table.concat({
    U2(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 0, 34, 159, 172, 132, 68, 180, 220, 50, 87, 29, 210, 251, 17, 169, 151, 49, 45, 153, 253, 192, 119),
    U2(72, 172, 70, 7, 43, 159, 225, 114, 157, 137, 37, 93, 65, 218, 201, 12, 181, 151)
  }))
  do return end
  return
end

function Tick(_ARG_0_)
  do
    NetUtil.CurTickTime = NetUtil.CurTickTime + _ARG_0_
    U1.nLocalTimeTick = U1.nLocalTimeTick + _ARG_0_
    if NetUtil.CurTickTime - NetUtil.LastTickTime > 5 then
      NetUtil.LastTickTime = NetUtil.CurTickTime
    end
    NetUtil.CheckTime()
    NetUtil.OnTick(U1.OSTime())
    U2.Tick(_ARG_0_)
    do return end
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.GEMReportSubEvent(_ARG_0_, _ARG_1_)
  do
    do return Client.GEMReportSubEvent(GameFrontendHUD, U1(101, 191, 81, 22, 103, 152, 206, 116, 130, 222, 62, 64, 10, 243, 208, 11, 185, 154), _ARG_0_, _ARG_1_) end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.DispatchPacket(_ARG_0_, ...)
  do
    if not ProcRespondMsg then
      return
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.SendTss()
  if Tss then
    Tss.SendSkdData(LuaStateWrapper, NetInterface, (U1(72, 176, 122, 16, 110, 158, 246, 78, 149, 197, 56, 87, 15, 194, 249, 10, 182, 154, 52)))
  else
    log_shipping_client((U1(105, 187, 81, 55, 127, 148, 236, 63, 165, 204, 63, 86, 53, 197, 213, 78, 131, 157, 38, 114, 146, 190, 208, 79, 143, 213)))
  end
  return
end

function NetUtil.OnTssRsp(_ARG_0_, _ARG_1_)
  do
    if Tss then
      Tss.OnRecvData(_ARG_0_, _ARG_1_)
    else
      log_shipping_client((U1(105, 187, 81, 55, 127, 148, 236, 63, 185, 199, 5, 65, 18, 228, 213, 30, 247, 186, 38, 33, 219, 164, 131, 1, 136, 208, 45)))
    end
    do return end
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.SendPkg(_ARG_0_, ...)
  do
    if _ENV and isLogMsgAfterLogin then
      if logMsgMap[_ARG_0_] then
        logMsgMap[_ARG_0_] = logMsgMap[_ARG_0_] + 1
      else
        logMsgMap[_ARG_0_] = 1
      end
    end
    _ARG_0_ = _ARG_0_
    if U3(U1.select(...), U2(70, 172, 66) .. ..., 0) then
      return
    end
    _ARG_0_ = _ARG_0_
    if U1.Client.IsConnected(U1.NetInterface) then
    else
    end
    do return end
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.ConnectToURL(_ARG_0_)
  do
    if not _ARG_0_ then
      return
    end
    if Client.IsDevelopment() and NetUtil.STOP_CONNECT then
      log(bWriteLog and U1(105, 187, 81, 55, 127, 148, 236, 63, 181, 198, 63, 92, 4, 213, 210, 58, 184, 187, 7, 30, 219, 158, 167, 104, 178, 250, 9, 2, 37, 227, 229, 42, 231, 172, 0, 22, 190, 143, 174))
      return
    end
    if HDmpveRemote.HDmpveRemoteConfigGetString(U1(111, 138, 113, 50, 79, 179, 211), (U1())) ~= U1(98, 176, 68, 0, 103, 152, 200, 69, 162, 249, 21, 124, 50) then
      return NetUtil.ConnectToURLDirectly(_ARG_0_)
    else
      return NetUtil.ConnectToURLWithDNSProxy(_ARG_0_)
    end
    do return end
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.ConnectToURLDirectly(_ARG_0_)
  do
    log(bWriteLog and U1(105, 187, 81, 55, 127, 148, 236, 63, 181, 198, 63, 92, 4, 213, 210, 58, 184, 187, 7, 30, 191, 164, 130, 68, 133, 205, 45, 91, 93, 134, 195, 12, 171, 222, 120, 98) .. tostring(_ARG_0_) .. U1(11, 254, 81, 11, 102, 152, 160, 44, 214) .. tostring(U2.OSTime()))
    log_shipping_client(U1(124, 146, 74, 5, 98, 147, 160, 97, 132, 198, 50, 87, 18, 197, 251, 78, 153, 139, 33, 7, 143, 164, 156, 15, 165, 214, 47, 76, 20, 197, 194, 42, 168, 171, 23, 14, 203) .. U1(11, 254, 81, 11, 102, 152) .. tostring(U2.OSTime()))
    NetUtil.SetWindowEditorLoginTokenIndex()
    Client.ConnectToURL(NetInterface, _ARG_0_, NetUtil.ConnectSDKTimeOutSeconds)
    do return end
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.SetWindowEditorLoginTokenIndex()
  return
end

function NetUtil.ConnectToURLWithDNSProxy(_ARG_0_)
  do
    do return end
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.Disconnect()
  log_shipping_client((U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 27, 55, 143, 152, 132, 72, 138, 151, 5, 75, 2, 197, 217, 16, 169, 155, 38, 54, 195, 244)))
  Client.Disconnect(NetInterface)
  return
end

function NetUtil.MountPakOfMode(_ARG_0_, _ARG_1_)
  do
    if require((U1(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 13, 217, 193, 7, 180, 192, 56, 51, 143, 174, 152, 15, 138, 214, 38, 75, 18, 249, 219, 17, 163, 155, 26, 47, 140, 175))).GetMapKeyBySubMode(_ARG_0_, _ARG_1_) then
      goto lbl_236
      ::lbl_236::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager):GetDependMapFiles(require((U1(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 13, 217, 193, 7, 180, 192, 56, 51, 143, 174, 152, 15, 138, 214, 38, 75, 18, 249, 219, 17, 163, 155, 26, 47, 140, 175))).GetMapKeyBySubMode(_ARG_0_, _ARG_1_), _ARG_0_, _ARG_1_) and next((ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager):GetDependMapFiles(require((U1(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 13, 217, 193, 7, 180, 192, 56, 51, 143, 174, 152, 15, 138, 214, 38, 75, 18, 249, 219, 17, 163, 155, 26, 47, 140, 175))).GetMapKeyBySubMode(_ARG_0_, _ARG_1_), _ARG_0_, _ARG_1_))) then
        goto lbl_570
        if not Client.IsFileExistsWithOutPakCheck(Client.ProjectSavedDir() .. U1(119, 191, 78, 17, 36) .. log(bWriteLog and string.format(U1(105, 187, 81, 55, 127, 148, 236, 63, 187, 198, 36, 92, 21, 230, 199, 5, 152, 136, 24, 61, 159, 168, 208, 76, 135, 201, 7, 75, 29, 195, 248, 31, 170, 155, 127, 103, 152), _ARG_0_))) then
          if require((U1(68, 177, 72, 15, 100, 147, 174, 98, 130, 219, 56, 92, 6, 233, 211, 26, 190, 130))).Split(log(bWriteLog and string.format(U1(105, 187, 81, 55, 127, 148, 236, 63, 187, 198, 36, 92, 21, 230, 199, 5, 152, 136, 24, 61, 159, 168, 208, 76, 135, 201, 7, 75, 29, 195, 248, 31, 170, 155, 127, 103, 152), _ARG_0_)), (U1(9)))[1] and require((U1(68, 177, 72, 15, 100, 147, 174, 98, 130, 219, 56, 92, 6, 233, 211, 26, 190, 130))).Split(log(bWriteLog and string.format(U1(105, 187, 81, 55, 127, 148, 236, 63, 187, 198, 36, 92, 21, 230, 199, 5, 152, 136, 24, 61, 159, 168, 208, 76, 135, 201, 7, 75, 29, 195, 248, 31, 170, 155, 127, 103, 152), _ARG_0_)), (U1(9)))[2] then
            goto lbl_385
            if string.find(98, require((U1(68, 177, 72, 15, 100, 147, 174, 98, 130, 219, 56, 92, 6, 233, 211, 26, 190, 130))).Split(log(bWriteLog and string.format(U1(105, 187, 81, 55, 127, 148, 236, 63, 187, 198, 36, 92, 21, 230, 199, 5, 152, 136, 24, 61, 159, 168, 208, 76, 135, 201, 7, 75, 29, 195, 248, 31, 170, 155, 127, 103, 152), _ARG_0_)), (U1(9)))[1] .. U1(9) .. require((U1(68, 177, 72, 15, 100, 147, 174, 98, 130, 219, 56, 92, 6, 233, 211, 26, 190, 130))).Split(log(bWriteLog and string.format(U1(105, 187, 81, 55, 127, 148, 236, 63, 187, 198, 36, 92, 21, 230, 199, 5, 152, 136, 24, 61, 159, 168, 208, 76, 135, 201, 7, 75, 29, 195, 248, 31, 170, 155, 127, 103, 152), _ARG_0_)), (U1(9)))[2]) and (U1() == U1() or 98 > U1()) then
            end
            ::lbl_385::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
            if 98 ~= U1() and not Client.IsMounted(Client.ProjectSavedDir() .. U1(119, 191, 78, 17, 36) .. 98) then
            end
          end
        elseif not Client.IsMounted(Client.ProjectSavedDir() .. U1(119, 191, 78, 17, 36) .. 98) then
        else
        end
        ::lbl_570::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.EnterBattleStandAlone(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
  do
    if _ARG_6_ == nil then
      _ARG_6_ = _ENV()
    elseif _ARG_6_:sub(1, 1) ~= _ENV(24) then
      _ARG_6_ = _ENV(24) .. _ARG_6_
    end
    U1.NetUtil.MountPakOfMode(_ARG_4_)
    U1._G.ModeID = _ARG_4_
    if U1.require((_ENV(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))).GetGameFrontendHUD() ~= nil then
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.SetEnterBattleGameID(_ARG_0_)
  do
    if _ARG_0_ ~= nil and NetUtil.EnterBattleGameID ~= _ARG_0_ then
      NetUtil.EnterBattleGameID = _ARG_0_
      log_shipping_client(U1(107, 177, 66, 32, 106, 137, 244, 125, 147, 231, 52, 70, 39, 218, 201, 25, 251, 206, 117, 21, 154, 160, 149, 104, 130, 131, 97) .. tostring(_ARG_0_))
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.OnConnected(_ARG_0_, _ARG_1_)
  do
    if _G.IsEnableMockGameSvr then
      log(bWriteLog and U1(105, 187, 81, 55, 127, 148, 236, 63, 185, 199, 18, 93, 15, 216, 195, 13, 163, 139, 49, 122, 178, 190, 181, 79, 135, 219, 45, 71, 60, 201, 213, 21, 128, 159, 40, 39, 184, 171, 146, 24))
      return
    end
    if not _ARG_0_ then
    end
    if Client.SetTssNetworkStatus ~= nil then
      if _ARG_0_ then
      elseif _ARG_1_ == 100 then
      end
    end
    if _ARG_0_ == false and (GameStatus.GetGameStatus() == GameStatus.Login or GameStatus.IsInLobbyOrMainCity()) and (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ban_login_module).hasKickOut or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module).bHasLogout or NetUtil.checkLoginOtherLobbyServer) == false then
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module):reconnectGateway() then
        return
      else
      end
    elseif _ARG_0_ == false and (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ban_login_module).hasKickOut or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module).bHasLogout or NetUtil.checkLoginOtherLobbyServer) == false then
    end
    if _ARG_0_ then
      NetUtil.hasTryConnectForNetworkError = false
      NetUtil.hasTryConnectForNetworkErrorTimes = 0
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ban_login_module).hasKickOut then
        NetUtil.gameTick = false
      else
        if Client.IsMatchNoAuthMode and Client.IsMatchNoAuthMode() then
          if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module).bIsInitLogin == false and GameStatus.GetGameStatus() == GameStatus.Login then
          else
          end
        else
          NetUtil.ConnectReason = nil
        end
        NetUtil.gameTick = true
      end
      NetUtil.showConnectionMsgTimes = 0
      NetUtil.SendTime = U3.OSTime()
      NetUtil.LobbyDelaySendTime = U3.GetMiliseconds()
      NetUtil.LobbyDelayRecvTime = U3.GetMiliseconds()
      NetUtil.s2cNeedWaiting = {}
      NetUtil.checkConnectingInFighting = false
      NetUtil.checkConnectingInFightingTimes = 0
    else
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ban_login_module).hasKickOut or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module).bHasLogout or NetUtil.checkLoginOtherLobbyServer then
        NetUtil.gameTick = false
        return
      end
      if GameStatus.IsInFightingNotSocialNotMainCityNotHome() then
        if not NetUtil.checkConnectingInFighting then
          NetUtil.checkConnectingInFighting = true
          NetUtil.waitingConnectSuccessStartTime = U3.OSTime()
        end
      elseif _ARG_1_ == -1 or _ARG_1_ == require((U1(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 193, 13, 187, 129, 32, 62, 159, 146, 149, 83, 148, 214, 51, 125, 21, 195, 208, 23, 169, 155))).GCLOULD_ErrorNetworkException or _ARG_1_ == require((U1(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 193, 13, 187, 129, 32, 62, 159, 146, 149, 83, 148, 214, 51, 125, 21, 195, 208, 23, 169, 155))).GCLOULD_ErrorTimeout or _ARG_1_ == require((U1(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 193, 13, 187, 129, 32, 62, 159, 146, 149, 83, 148, 214, 51, 125, 21, 195, 208, 23, 169, 155))).GCLOULD_ErrorChecking or _ARG_1_ == require((U1(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 193, 13, 187, 129, 32, 62, 159, 146, 149, 83, 148, 214, 51, 125, 21, 195, 208, 23, 169, 155))).GCLOULD_ErrorConnectFailed then
        if not NetUtil.AutoReconnectParam then
          NetUtil.AutoReconnectParam = NetUtil.GetAutoReconnectParam()
        end
        if NetUtil.hasTryConnectForNetworkErrorTimes < NetUtil.AutoReconnectParam.times then
          if NetUtil.isWattingDelayReconnect == false then
            NetUtil.isWattingDelayReconnect = true
            NetUtil.hasTryConnectForNetworkErrorTimes = NetUtil.hasTryConnectForNetworkErrorTimes + 1
            NetUtil.autoReconnectTimer = require((U1(68, 177, 72, 15, 100, 147, 174, 101, 159, 196, 52, 109, 21, 223, 197, 5, 178, 156))).AddTimerOnce(1, function()
              log(bWriteLog and table.concat({
                U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 27, 55, 143, 152, 132, 72, 138, 151, 14, 76, 50, 201, 216, 16, 162, 157, 49, 39, 143, 253, 161, 68),
                U1(83, 177, 5, 48, 110, 158, 239, 127, 152, 204, 50, 70, 65, 226, 207, 3, 178, 156, 117, 58, 154, 163, 148, 77, 131, 203)
              }))
              NetUtil.tryConnect(Enum_LOGIN_REPORT_CFG.NET_CONNECT_ERR)
              NetUtil.isWattingDelayReconnect = false
              return
            end)
          end
        else
          NetUtil.showConnectionMsgTimes = NetUtil.showConnectionMsgTimes + 1
        end
      else
        NetUtil.gameTick = false
      end
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.OnStateChange(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
  do
    log_shipping_client(U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 26, 60, 168, 185, 145, 85, 131, 250, 41, 67, 31, 193, 211, 94, 148, 138, 36, 54, 142, 231) .. _ARG_0_ .. U1(11, 254, 117, 3, 121, 156, 237, 32, 204) .. _ARG_1_ .. U1(11, 254, 117, 3, 121, 156, 237, 35, 204) .. _ARG_2_ .. U1(11, 254, 117, 3, 121, 156, 237, 34, 204) .. _ARG_3_)
    if _ARG_0_ == 0 then
      log(bWriteLog and table.concat({
        U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 29, 22, 150, 189, 134, 68, 220, 131, 2, 77, 31, 200, 140, 68, 172, 189, 42, 44, 133, 184, 131, 69),
        U1(72, 172, 118, 22, 106, 137, 229, 67, 131, 199, 63, 91, 15, 209)
      }))
    elseif _ARG_0_ == 1 then
      log(bWriteLog and table.concat({
        U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 29, 22, 150, 189, 134, 68, 220, 131, 2, 77, 31, 200, 140, 68, 172, 189, 42, 44, 133, 184, 131, 69),
        U1(72, 172, 118, 22, 106, 137, 229, 67, 147, 202, 62, 92, 15, 211, 197, 26, 190, 128, 50, 124, 213, 227, 222, 15, 200, 151)
      }))
      NetUtil.ProcOnConnecting()
    elseif _ARG_0_ == 2 then
      log(bWriteLog and table.concat({
        U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 29, 22, 150, 189, 134, 68, 220, 131, 2, 77, 31, 200, 140, 68, 172, 189, 42, 44, 133, 184, 131, 69),
        U1(72, 172, 118, 22, 106, 137, 229, 67, 147, 202, 62, 92, 15, 211, 197, 26, 178, 138, 117, 59, 136, 142, 159, 79, 136, 220, 34, 86, 75)
      }) .. _ARG_1_)
      NetUtil.ProcOnConnected()
      if NetUtil.CheckSpecialDeviceNetFlash() then
        log(bWriteLog and table.concat({
          U1(105, 187, 81, 55, 127, 148, 236, 63, 185, 199, 2, 70, 0, 194, 195, 45, 191, 143, 59, 53, 158, 237, 147, 73, 131, 218, 42, 2, 2, 214, 211, 29, 174, 159, 41, 98, 143, 184, 150, 88),
          U1(68, 187, 5, 12, 110, 137, 160, 119, 154, 200, 34, 90)
        }))
        logic_connection_waiting:Hide(1)
      else
        NetUtil.OnConnected(_ARG_1_ == 0, _ARG_1_)
      end
    elseif _ARG_0_ == 3 then
      log(bWriteLog and table.concat({
        U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 29, 22, 150, 189, 134, 68, 220, 131, 2, 77, 31, 200, 140, 68, 172, 189, 42, 44, 133, 184, 131, 69),
        U1(72, 172, 118, 22, 106, 137, 229, 66, 130, 200, 40, 123, 15, 231, 211, 11, 162, 139)
      }))
      U2 = true
      NetUtil.gameTick = false
      if not GameStatus.IsInFightingNotSocialNotMainCityNotHome() then
      end
    elseif _ARG_0_ == 4 then
      log(bWriteLog and table.concat({
        U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 29, 22, 150, 189, 134, 68, 220, 131, 2, 77, 31, 200, 140, 68, 172, 189, 42, 44, 133, 184, 131, 69),
        U1(72, 172, 118, 22, 106, 137, 229, 84, 132, 219, 62, 64, 65)
      }))
      NetUtil.ProcOnDisconnected()
      if _ARG_1_ == 207 or _ARG_1_ == 205 then
      elseif _ARG_2_ == 7 then
      else
      end
    end
    do return end
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.OnDisconnected(_ARG_0_)
  do
    log_error(U1(105, 187, 81, 55, 127, 148, 236, 63, 185, 199, 21, 91, 18, 213, 201, 0, 185, 139, 54, 38, 158, 169, 208, 79, 180, 220, 32, 81, 30, 200, 89, 194, 93) .. _ARG_0_)
    log(bWriteLog and table.concat({
      U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 27, 55, 143, 152, 132, 72, 138, 151, 14, 76, 53, 207, 197, 29, 168, 144, 43, 39, 136, 169, 133, 85),
      U1(7, 176, 119, 7, 106, 142, 239, 127, 25, 21, 203)
    }) .. _ARG_0_)
    do return end
    _ARG_0_ = _ENV[53]
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

NET_UTIL_LOGIN_WAIT_TIME = 8

function NetUtil.CheckTime()
  if NetUtil.checkLoginRsp and NetUtil.sendLoginTime > 0 and U1.OSTime() - NetUtil.sendLoginTime >= NET_UTIL_LOGIN_WAIT_TIME then
    if NetUtil.checkLoginRetryTime == 0 then
      NetUtil.checkLoginRetryTime = NetUtil.checkLoginRetryTime + 1
    else
    end
    if GameStatus.IsInFightingNotSocialNotMainCityNotHome() then
      if NetUtil.checkBattleLoginRetryTime == 0 or NetUtil.checkBattleLoginRetryTime == 2 or NetUtil.checkBattleLoginRetryTime == 5 then
      end
      NetUtil.checkBattleLoginRetryTime = NetUtil.checkBattleLoginRetryTime + 1
    end
  end
  if NetUtil.checkEnterBattle and U1.OSTime() - NetUtil.waitingEnterBattleStartTime > NetUtil.LoadingTimeOut then
    if import((U2(116, 179, 68, 16, 127, 191, 229, 112, 132, 204, 35, 127, 0, 216, 199, 9, 178, 156, 25, 39, 154, 143, 130, 72, 130, 222, 36))) ~= nil then
    end
    if import((U2(116, 179, 68, 16, 127, 191, 229, 112, 132, 204, 35, 127, 0, 216, 199, 9, 178, 156, 25, 39, 154, 143, 130, 72, 130, 222, 36))).IsClientBackEndSwitcherBEnable(1) then
      if require((U2(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))) ~= nil and require((U2(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))).GetGameFrontendHUD() ~= nil then
      end
      if (require((U2(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))).GetGameFrontendHUD():GetClientEnterBattleStage() == U2(105, 147, 113, 61, 92, 152, 236, 114, 153, 196, 52, 109, 51, 211, 197, 11, 190, 152, 48, 54) or require((U2(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))).GetGameFrontendHUD():GetClientEnterBattleStage() == U2(107, 177, 68, 6, 70, 156, 240, 82, 153, 196, 33, 94, 4, 194, 195, 10) or require((U2(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))).GetGameFrontendHUD():GetClientEnterBattleStage() == U2(105, 187, 81, 21, 100, 143, 235, 84, 133, 221, 48, 80, 13, 223, 213, 6, 178, 138)) and NetUtil.EnterBattleTimeOutGameID ~= g_game_id then
        NetUtil.EnterBattleTimeOutGameID = g_game_id
        NetUtil.LoadingTimeOut = NetUtil.LoadingTimeOut + 20
        return
      end
    end
    if LobbySystem.isWaittingEnterBattle then
      if GameStatus.IsInLobbyOrMainCity() then
      else
        require((table.concat({
          U2(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 13, 217, 193, 7, 180, 192, 57, 61, 153, 175, 137, 15, 171, 216, 40, 76, 50, 207, 194, 7, 233, 178, 42, 32, 137, 164, 191, 124),
          U2(70, 183, 75, 61, 72, 148, 244, 104, 169, 236, 63, 70, 4, 196)
        }))).bEnterGameFromMainCity = false
      end
      if not U4.bConnected and LobbySystem.CheckOpen(BP_ENUM_IS_QUERY_PLAYER_STETE_AFTER_LOADING) then
      else
      end
    end
  end
  if NetUtil.checkWaitingReEnterGameNotify and 5 < U1.OSTime() - NetUtil.waitingReEnterGameStartTime then
    if LobbySystem.isWaittingEnterBattle then
      if GameStatus.IsInLobbyOrMainCity() then
        return
      end
    elseif GameStatus.IsInFightingStatus() and not BattleResult.IgnoreDSError and not Client.IsInReplayState(GameFrontendHUD) then
      if GameStatus.IsInLobbyOrMainCity() then
        return
      end
      if tonumber(Client.GetGameModeID(GameFrontendHUD)) == require((U2(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 13, 217, 193, 7, 180, 192, 61, 61, 150, 168, 222, 73, 137, 212, 36, 125, 28, 199, 213, 12, 168, 141))).Home_SubMode.Visit then
      elseif tonumber(Client.GetGameModeID(GameFrontendHUD)) == require((table.concat({
        U2(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 13, 217, 193, 7, 180, 192, 22, 61, 151, 161, 149, 66, 146, 208, 46, 76, 57, 199, 218, 18, 233, 178, 42, 37, 130, 190, 191, 97),
        U2(75, 191, 75, 33, 67, 176, 225, 114, 132, 198, 34)
      }))).CollectionHall_SubMode.Visit then
      else
      end
    end
  end
  if NetUtil.checkConnectingInFighting then
    if NetUtil.checkConnectingInFightingTimes == 0 or NetUtil.checkConnectingInFightingTimes == 1 then
    elseif NetUtil.checkConnectingInFightingTimes == 2 then
    elseif NetUtil.checkConnectingInFightingTimes == 3 then
    else
    end
    if NetUtil.checkConnectingInFightingRandomInterval < U1.OSTime() - NetUtil.waitingReEnterGameStartTime then
      if not Client.IsConnected(NetInterface) and GameStatus.IsInFightingStatus() then
        if require((U2(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 13, 217, 193, 7, 180, 192, 56, 51, 143, 174, 152, 15, 138, 214, 38, 75, 18, 249, 219, 17, 163, 155, 26, 47, 140, 175))) and require((U2(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 13, 217, 193, 7, 180, 192, 56, 51, 143, 174, 152, 15, 138, 214, 38, 75, 18, 249, 219, 17, 163, 155, 26, 47, 140, 175))).IsSocialIslandMode(true) and 3 < NetUtil.checkConnectingInFightingTimes then
        else
          NetUtil.checkConnectingInFightingTimes = NetUtil.checkConnectingInFightingTimes + 1
          NetUtil.checkConnectingInFightingRandomInterval = math.random(30, 40)
        end
      else
        NetUtil.checkConnectingInFighting = false
        NetUtil.waitingReEnterGameStartTime = 0
        NetUtil.checkConnectingInFightingTimes = 0
      end
      NetUtil.waitingReEnterGameStartTime = U1.OSTime()
    end
  end
  return
end

function NetUtil.StopCheckLoginOtherLobbyServer()
  log(bWriteLog and table.concat({
    U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 117, 1, 143, 162, 128, 98, 142, 220, 34, 73, 61, 201, 209, 23, 169, 177, 49, 42, 142, 175, 172, 94),
    U1(69, 188, 92, 49, 110, 143, 246, 116, 132)
  }))
  if NetUtil.checkLoginOtherLobbyServer then
    logic_connection_waiting:Hide(1)
  end
  log_warning(bWriteLog and table.concat({
    U1(105, 187, 81, 55, 127, 148, 236, 63, 165, 221, 62, 66, 34, 222, 195, 13, 188, 162, 58, 53, 146, 163, 191, 85, 142, 220, 51, 110, 30, 196, 212, 7, 148, 155, 55, 52, 142, 175, 192, 82),
    U1(79, 187, 70, 9, 71, 146, 231, 120, 152, 230, 37, 90, 4, 196, 234, 1, 181, 140, 44, 1, 158, 191, 134, 68, 148, 153, 39, 67, 29, 213, 211)
  }))
  NetUtil.checkLoginOtherLobbyServer = false
  return
end

function NetUtil.OnEnterBattleStageDelegate(_ARG_0_)
  do
    if require((U1(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 13, 217, 193, 7, 180, 192, 57, 61, 154, 169, 153, 79, 129, 151, 45, 77, 16, 194, 223, 16, 160, 161, 40, 35, 136, 175, 143))).EnterBattleStagePercentMap[_ARG_0_] ~= nil then
      if LobbySystem.is_DeathMatchMode == true then
      end
    else
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.OnEnterBattleStageDelegate_MainCity(_ARG_0_)
  do
    log(bWriteLog and table.concat({
      U1(105, 187, 81, 55, 127, 148, 236, 63, 185, 199, 20, 92, 21, 211, 212, 44, 182, 154, 33, 62, 158, 158, 132, 64, 129, 220, 5, 71, 29, 195, 209, 31, 179, 155, 26, 15, 138, 180, 142, 114),
      U1(78, 170, 92, 66, 88, 137, 225, 118, 147, 147, 113)
    }) .. tostring(_ARG_0_))
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.BindEnterBattleStageDelegate(_ARG_0_)
  do
    log(bWriteLog and table.concat({
      U1(105, 187, 81, 55, 127, 148, 236, 63, 180, 192, 63, 86, 36, 216, 210, 11, 165, 172, 52, 38, 143, 161, 149, 114, 146, 216, 38, 71, 53, 195, 218, 27, 160, 159, 49, 39, 203, 174, 149, 83),
      U1(120, 179, 74, 6, 110, 199, 160)
    }) .. tostring(_ARG_0_))
    NetUtil.RemoveEnterBattleStageDelegate()
    if NetUtil.EnterBattleStageDelegate == nil and require((U1(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))).GetGameFrontendHUD() ~= nil then
      if require((table.concat({
        U1(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 13, 217, 193, 7, 180, 192, 57, 61, 153, 175, 137, 15, 171, 216, 40, 76, 50, 207, 194, 7, 233, 178, 42, 32, 137, 164, 191, 124),
        U1(70, 183, 75, 61, 72, 148, 244, 104)
      }))).IsMainCitySubMode(_ARG_0_) then
        NetUtil.EnterBattleStageDelegate = require((U1(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))).GetGameFrontendHUD().EnterBattleStageDelegate:Add(function(_ARG_0_)
          do
            NetUtil.OnEnterBattleStageDelegate_MainCity(_ARG_0_)
            do return end
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        end)
      else
        NetUtil.EnterBattleStageDelegate = require((U1(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))).GetGameFrontendHUD().EnterBattleStageDelegate:Add(function(_ARG_0_)
          do
            NetUtil.OnEnterBattleStageDelegate(_ARG_0_)
            do return end
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        end)
      end
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.RemoveEnterBattleStageDelegate()
  log(bWriteLog and U1(105, 187, 81, 55, 127, 148, 236, 63, 164, 204, 60, 93, 23, 211, 227, 0, 163, 139, 39, 16, 154, 185, 132, 77, 131, 234, 53, 67, 22, 195, 242, 27, 171, 155, 34, 35, 159, 184))
  if NetUtil.EnterBattleStageDelegate ~= nil then
    if require((U1(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))).GetGameFrontendHUD() ~= nil then
    end
    NetUtil.EnterBattleStageDelegate = nil
  end
  return
end

function NetUtil.StartCheckLoginRsp()
  log(bWriteLog and table.concat({
    U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 27, 55, 143, 152, 132, 72, 138, 151, 18, 86, 16, 212, 194, 61, 175, 155, 38, 41, 167, 178, 135, 88),
    U1(73, 140, 86, 18, 37, 211, 174, 63, 216, 135)
  }))
  NetUtil.checkLoginRsp = true
  NetUtil.sendLoginTime = U2.OSTime()
  return
end

function NetUtil.StopCheckLoginRsp()
  log(bWriteLog and table.concat({
    U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 27, 55, 143, 152, 132, 72, 138, 151, 18, 86, 30, 214, 245, 22, 162, 157, 46, 14, 132, 186, 137, 95),
    U1(117, 173, 85, 67, 42, 220, 161, 48)
  }))
  NetUtil.checkLoginRsp = false
  NetUtil.sendLoginTime = 0
  NetUtil.checkLoginRetryTime = 0
  if 0 < NetUtil.checkBattleLoginRetryTime then
    if NetUtil.checkBattleLoginRetryTime > 2 then
    elseif NetUtil.checkBattleLoginRetryTime > 5 then
    end
  end
  NetUtil.checkBattleLoginRetryTime = 0
  NetUtil.bIsTimeOutReconnect = 0
  return
end

function NetUtil.StartCheckDSActive()
  log(bWriteLog and U1(105, 187, 81, 55, 127, 148, 236, 63, 165, 221, 48, 64, 21, 245, 206, 11, 180, 133, 17, 1, 186, 174, 132, 72, 144, 220))
  if LobbySystem.isWaittingEnterBattle and NetUtil.EnterBattleTime > 0 and 0 < NetUtil.waitingEnterBattleStartTime and NetUtil.EnterBattleTime >= NetUtil.waitingEnterBattleStartTime then
    return
  end
  if (LobbySystem.isWaittingEnterBattle or LuaClassObj.GetGameStatus(bp_global) == GameStatus.Fighting) and Client.GetUnrealNetworkStatus(GameFrontendHUD) ~= U1(104, 176, 73, 11, 101, 152) and NetUtil.checkWaitingReEnterGameNotify == false then
    NetUtil.checkWaitingReEnterGameNotify = true
    NetUtil.waitingReEnterGameStartTime = U2.OSTime()
  end
  return
end

function NetUtil.StopCheckDSActive()
  log(bWriteLog and U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 117, 1, 143, 162, 128, 98, 142, 220, 34, 73, 53, 245, 247, 29, 179, 151, 51, 39))
  NetUtil.checkWaitingReEnterGameNotify = false
  NetUtil.waitingReEnterGameStartTime = 0
  return
end

function NetUtil.StartCheckEnterBattle(_ARG_0_)
  do
    if LobbySystem.isWaittingEnterBattle then
      NetUtil.checkEnterBattle = true
      NetUtil.waitingEnterBattleStartTime = U1.OSTime()
      if CDataTable.GetTableData(U2(101, 138, 104, 13, 111, 152), _ARG_0_) and CDataTable.GetTableData(U2(101, 138, 104, 13, 111, 152), _ARG_0_).LoadingTimeOut and CDataTable.GetTableData(U2(101, 138, 104, 13, 111, 152), _ARG_0_).LoadingTimeOut > 70 then
        NetUtil.LoadingTimeOut = CDataTable.GetTableData(U2(101, 138, 104, 13, 111, 152), _ARG_0_).LoadingTimeOut
      else
        NetUtil.LoadingTimeOut = 70
      end
      if Client.IsAsanVersion() then
        NetUtil.LoadingTimeOut = 1000
      end
      if LobbySystem.is_DeathMatchMode == true then
      else
      end
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.StopCheckEnterBattle()
  log(bWriteLog and table.concat({
    U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 117, 1, 143, 162, 128, 98, 142, 220, 34, 73, 52, 200, 194, 27, 181, 188, 36, 54, 159, 177, 133, 17),
    U1(98, 176, 81, 7, 121, 191, 225, 101, 130, 197, 52, 126, 14, 215, 194, 7, 185, 137, 1, 59, 150, 168, 202)
  }), NetUtil.EnterBattleLoadingTime)
  NetUtil.checkEnterBattle = false
  NetUtil.waitingEnterBattleStartTime = 0
  NetUtil.LoadingTimeOut = 70
  NetUtil.RemoveEnterBattleStageDelegate()
  return
end

function NetUtil.OnTick(_ARG_0_)
  do
    if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ban_login_module).hasKickOut then
      return
    end
    if NetUtil.gameTick then
      if _ARG_0_ - NetUtil.SendTime >= 5 then
        NetUtil.SendTime = _ARG_0_
        NetUtil.LobbyDelaySendTime = U1.GetMiliseconds()
      end
      if _ARG_0_ - NetUtil.SendOneTime >= 1 then
        NetUtil.SendOneTime = _ARG_0_
      end
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.OnChangeLobbyServerNotify(_ARG_0_, _ARG_1_)
  do
    log(bWriteLog and table.concat({
      U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 26, 60, 184, 165, 145, 79, 129, 220, 13, 77, 19, 196, 207, 45, 162, 140, 51, 39, 153, 147, 143, 69),
      U1(78, 184, 92, 66, 121, 152, 236, 126, 145, 192, 63, 109, 18, 211, 197, 1, 185, 138, 38, 104)
    }) .. tostring(_ARG_0_) .. U1(7, 172, 64, 3, 120, 146, 238, 43) .. tostring(_ARG_1_))
    if _ARG_1_ and type(_ARG_1_) == U1(84, 170, 87, 11, 101, 154) and _ARG_1_ == U1(67, 191, 81, 3, 38, 144, 233, 118, 132, 200, 37, 91, 14, 216) then
    end
    if 0 < _ARG_0_ then
      if NetUtil.PleaseReloginTimer then
        NetUtil.PleaseReloginTimer = nil
      end
      NetUtil.PleaseReloginTimer = require((U1(68, 177, 72, 15, 100, 147, 174, 101, 159, 196, 52, 109, 21, 223, 197, 5, 178, 156))).AddTimerOnce(_ARG_0_, function()
        log_warning(bWriteLog and table.concat({
          U1(105, 187, 81, 55, 127, 148, 236, 63, 185, 199, 18, 90, 0, 216, 193, 11, 155, 129, 55, 48, 130, 158, 149, 83, 144, 220, 51, 108, 30, 210, 223, 24, 190, 222, 38, 42, 142, 190, 139, 125),
          U1(72, 185, 76, 12, 68, 137, 232, 116, 132, 229, 62, 80, 3, 207, 245, 11, 165, 152, 48, 32, 219, 185, 130, 84, 131)
        }))
        NetUtil.checkLoginOtherLobbyServer = true
        NetUtil.Disconnect()
        return
      end)
    else
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.Please_Relogin_Req()
  log(bWriteLog and table.concat({
    U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 5, 62, 158, 172, 131, 68, 185, 235, 36, 78, 30, 193, 223, 16, 152, 172, 32, 51, 203, 163, 158, 79),
    U1(89, 160, 91, 28)
  }))
  log_warning(bWriteLog and table.concat({
    U1(105, 187, 81, 55, 127, 148, 236, 63, 166, 197, 52, 83, 18, 211, 249, 60, 178, 130, 58, 53, 146, 163, 175, 115, 131, 200, 97, 65, 25, 195, 213, 21, 139, 145, 34, 43, 133, 146, 148, 89),
    U1(66, 172, 105, 13, 105, 159, 249, 66, 147, 219, 39, 87, 19, 150, 210, 28, 162, 139)
  }))
  NetUtil.checkLoginOtherLobbyServer = true
  NetUtil.Disconnect()
  NetUtil.tryConnect(Enum_LOGIN_REPORT_CFG.NET_RELOGIN)
  return
end

function NetUtil.OnHeartBeatRsp(_ARG_0_)
  do
    SetServerTimeInSec(_ARG_0_)
    U1.NetUtil.LobbyDelayRecvTime = GetMiliseconds()
    do return end
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.GetZoneValue()
  if not (require((U1(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 13, 217, 193, 7, 180, 192, 33, 55, 154, 160, 133, 81, 200, 213, 46, 69, 24, 197, 233, 4, 168, 144, 32))).nChooseZoneID and require((U1(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 13, 217, 193, 7, 180, 192, 33, 55, 154, 160, 133, 81, 200, 213, 46, 69, 24, 197, 233, 4, 168, 144, 32))).chooseZoneList) or #require((U1(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 13, 217, 193, 7, 180, 192, 33, 55, 154, 160, 133, 81, 200, 213, 46, 69, 24, 197, 233, 4, 168, 144, 32))).chooseZoneList <= 0 then
    return 10000
  end
  goto lbl_62
  if require((U1(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 13, 217, 193, 7, 180, 192, 33, 55, 154, 160, 133, 81, 200, 213, 46, 69, 24, 197, 233, 4, 168, 144, 32))).nChooseZoneID == (174).zone_id then
  else
    ::lbl_62::
  end
  if (174).tpingsvr_ip ~= U1() then
  end
  if 10000 < slua_GameFrontendHUD.UDPPingCollector:GetZoneServerDelay((174).tpingsvr_ip) then
  end
  do return 80 end
  return
end

function NetUtil.IsGrowthGuideSubMode(_ARG_0_)
  do
    if _ARG_0_ == require((table.concat({
      U1(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 13, 217, 193, 7, 180, 192, 50, 32, 148, 186, 132, 73, 185, 201, 51, 77, 27, 195, 213, 10, 233, 155, 43, 54, 142, 175, 191, 86),
      U1(82, 183, 65, 7)
    }))).MatchId then
      return true
    else
      return false
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.ShowConnectionMsgBox(_ARG_0_, _ARG_1_)
  do
    log(bWriteLog and table.concat({
      U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 117, 28, 158, 185, 165, 85, 143, 213, 111, 113, 25, 201, 193, 61, 168, 144, 43, 39, 136, 169, 137, 94),
      U1(73, 147, 86, 5, 73, 146, 248, 43, 214)
    }) .. _ARG_0_ .. U1(11, 254, 70, 23, 121, 174, 244, 112, 130, 220, 34, 8) .. GameStatus.GetGameStatus() .. U1(11, 254, 64, 16, 121, 146, 242, 92, 133, 206, 113, 15, 65) .. tostring(_ARG_1_))
    NetUtil.gameTick = false
    if _ARG_0_ == 2 then
    elseif _ARG_0_ == 3 then
    else
    end
    if _ARG_0_ < 4 then
    else
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.tryConnect(_ARG_0_)
  do
    NetUtil.gameTick = false
    NetUtil.SendTime = U2.OSTime()
    NetUtil.ConnectReason = _ARG_0_
    if NetUtil.ConnectReason == Enum_LOGIN_REPORT_CFG.NET_MSG_TIME_OUT then
      NetUtil.bIsTimeOutReconnect = 1
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.OnNetworkEvent(_ARG_0_, _ARG_1_, _ARG_2_)
  do
    if _ARG_0_ == 1 then
    elseif _ARG_0_ == 2 then
      if U3.IsGlobalOperationRegion() then
        return
      end
      U1.NetUtil.noRefreshLogout = false
      if _ARG_1_ ~= 0 then
        if _ARG_1_ ~= 106 and _ARG_1_ ~= 611 and _ARG_1_ ~= 701 and _ARG_1_ ~= 2 then
        end
        if U1.require((U2(68, 178, 76, 7, 101, 137, 174, 125, 153, 206, 56, 81, 79, 218, 201, 9, 190, 128, 123, 62, 148, 170, 153, 66, 185, 223, 35, 125, 6, 195, 212, 33, 171, 145, 34, 43, 133))):HandleLoginFail(_ARG_1_, _ARG_2_) then
          return
        end
      end
      if _ARG_1_ == 0 then
        if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.version_up_module).bAlreadyGrayUpdate then
        else
        end
        U1.NetUtil.needInitCentauriWhenLogin = true
      elseif _ARG_1_ == 3 then
      elseif _ARG_1_ == 106 then
      elseif _ARG_1_ == 701 then
        if U1.GameStatus.GetGameStatus() == U1.GameStatus.Login then
        end
      elseif _ARG_1_ == 1001 or _ARG_1_ == 1002 then
      elseif (_ARG_1_ == 211 or _ARG_1_ == 9999) and _ARG_2_ == 2146 then
        if U1.GameStatus.GetGameStatus() == U1.GameStatus.Login then
        end
      elseif U5[_ARG_1_] and _ENV[_ARG_2_] then
      elseif (_ARG_1_ == 211 or _ARG_1_ == 9999) and _ARG_2_ == U1.require((U1.table.concat({
        U2(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 2, 217, 200, 8, 190, 137, 123, 17, 151, 164, 149, 79, 146, 244, 32, 65, 3, 201, 197, 80, 148, 186, 14, 15, 138, 190, 146, 94),
        U2(84)
      }))).IMSDKServerErrorCode.CHANNEL_OPENID_BANED then
        if U1.json.decode((U1.import((U2(110, 147, 118, 38, 64, 181, 229, 125, 134, 204, 35))).GetInstance():GetLastLoginResultJson())).thirdRetCode == U1.require((U1.table.concat({
          U2(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 2, 217, 200, 8, 190, 137, 123, 17, 151, 164, 149, 79, 146, 244, 32, 65, 3, 201, 197, 80, 148, 186, 14, 15, 138, 190, 146, 94),
          U2(84)
        }))).IMSDKServerErrorCode.CHANNEL_OPENID_BANED then
        end
      elseif _ARG_1_ >= 9999 and _ARG_1_ <= 100000 then
        if U1.GameStatus.GetGameStatus() == U1.GameStatus.Login then
        end
      elseif _ARG_1_ == 611 then
        if U1.require((U1.table.concat({
          U2(68, 178, 76, 7, 101, 137, 174, 125, 153, 206, 56, 81, 79, 245, 202, 7, 178, 128, 33, 23, 149, 185, 130, 88, 200, 218, 45, 75, 20, 200, 194, 33, 174, 147, 54, 38, 128, 130, 133, 71),
          U2(66, 176, 81, 18, 106, 143, 225, 124)
        }))).channel2ItopErrorCodeTable[U1.Client.GetLoginChannel(U1.NetInterface)] then
          return
        else
        end
      else
        if _ARG_1_ ~= -1 and _ARG_1_ ~= 6 and _ARG_1_ ~= 7 and _ARG_1_ ~= 106 and _ARG_1_ ~= 107 and _ARG_1_ ~= 109 and _ARG_1_ ~= 200 then
          if U1.GameStatus.GetGameStatus() ~= U1.GameStatus.Login then
            return
          end
          return
        end
        if _ARG_1_ == 7 and U1.require((U1.table.concat({
          U2(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 2, 217, 200, 8, 190, 137, 123, 17, 151, 164, 149, 79, 146, 244, 32, 65, 3, 201, 197, 80, 131, 155, 51, 43, 136, 184, 176, 93),
          U2(70, 170, 67, 13, 121, 144, 206, 112, 155, 204, 28, 83, 2, 196, 201, 29)
        }))).IsPC() then
        end
      end
    elseif _ARG_0_ == 3 then
      if U1.NetUtil.noRefreshLogout ~= true then
      end
      U1.NetUtil.noRefreshLogout = false
    elseif _ARG_0_ == 4 then
      if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.webModule):GetURLForComebackAfterShare() ~= nil then
      end
    elseif _ARG_0_ == 253 then
      if U1.UIManager.GetUI(U1.UIManager.UI_Config.data_migration) ~= nil then
      end
      if _ARG_1_ == 1 then
      elseif _ARG_1_ == -741 then
      elseif _ARG_1_ == 2 then
      else
      end
    elseif _ARG_0_ == 255 then
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ENV[30]
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.ShowUnifiedAccountException()
  return
end

function NetUtil.ShowMsgCommonMsg(_ARG_0_)
  do
    log(bWriteLog and U1(7, 254, 107, 7, 127, 168, 244, 120, 154, 135, 2, 90, 14, 193, 235, 29, 176, 173, 58, 63, 150, 162, 158, 108, 149, 222, 111, 2, 31, 201, 194, 23, 164, 155, 12, 6, 209, 253) .. tostring(_ARG_0_))
    _ARG_0_ = _ARG_0_ or 778877
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.GetSDKErrorNotice(_ARG_0_, _ARG_1_)
  do
    if _ARG_0_ == 11016 then
    elseif _ARG_0_ == 11500 then
    elseif _ARG_0_ == 11005 then
    elseif _ARG_0_ == 11020 then
    elseif _ARG_0_ == 11003 then
    elseif _ARG_0_ == 11001 then
    elseif _ARG_0_ == 11002 then
    elseif _ARG_0_ == 20002 then
    elseif _ARG_1_ == 2001 then
    elseif _ARG_0_ == 9999 and Client.GetLoginChannel(NetInterface) == BP_ENUM_PLAYFORM_TWITTER and Client.GetDevicePlatformName() == require((table.concat({
      U2(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 2, 217, 200, 8, 190, 137, 123, 17, 151, 164, 149, 79, 146, 244, 32, 65, 3, 201, 197, 80, 131, 155, 51, 43, 136, 184, 176, 93),
      U2(70, 170, 67, 13, 121, 144, 206, 112, 155, 204, 28, 83, 2, 196, 201, 29)
    }))).Android and Client.IsInstallTwitter(NetInterface) == false then
    end
    do return (LocUtil.GetLocalizeResStr(7496)) end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.ShowSDKErrorNotice(_ARG_0_, _ARG_1_)
  do
    if Client.GetLoginChannel(NetInterface) == BP_ENUM_PLAYFORM_UnifiedAccountByiTOP then
    else
    end
    if _ARG_1_ == 2001 then
    elseif _ARG_1_ == -566 then
    end
    if LocUtil.GetLocalizeResStr(75472) ~= U1() then
      if _ARG_1_ ~= 2001 and _ARG_1_ ~= -566 then
      end
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.OnDSServerConnectionErrorNotify(_ARG_0_, _ARG_1_)
  do
    log(bWriteLog and table.concat({
      U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 117, 29, 149, 137, 163, 114, 131, 203, 55, 71, 3, 229, 217, 16, 169, 155, 38, 54, 130, 178, 142, 116),
      U1(85, 172, 74, 16, 69, 146, 244, 120, 144, 208, 113, 31, 76, 155, 139, 67, 250, 195, 120, 114, 156, 172, 157, 68, 175, 253, 123)
    }) .. _ARG_0_ .. U1(11, 254, 87, 7, 106, 142, 239, 127, 204) .. _ARG_1_ .. U1(11, 254, 103, 3, 127, 137, 236, 116, 164, 204, 34, 71, 13, 194, 156) .. tostring(BattleResult.IgnoreDSError))
    if BattleResult.IgnoreDSError then
      log(bWriteLog and table.concat({
        U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 117, 16, 154, 185, 132, 77, 131, 235, 36, 81, 4, 202, 194, 80, 142, 153, 43, 45, 153, 184, 164, 98),
        U1(98, 172, 87, 13, 121, 221, 242, 116, 130, 220, 35, 92, 142, 10, 39, 129, 107, 111, 186, 238, 122, 34, 76, 160)
      }))
      return
    end
    if _ARG_1_ == U1(75, 177, 68, 6, 84, 136, 231, 114, 169, 204, 35, 64) then
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD):GetIsEditMod() then
      else
      end
    end
    if LuaClassObj.GetGameStatus(bp_global) ~= GameStatus.Fighting then
      if true then
      end
    end
    if GameStatus.IsInLobbyOrMainCity() then
      if slua_GameFrontendHUD and slua_GameFrontendHUD.UnrealNetworkStatus then
        if g_game_id and _ARG_0_ and g_game_id == _ARG_0_ then
          slua_GameFrontendHUD.UnrealNetworkStatus = U1(104, 184, 67, 14, 98, 147, 229)
        end
      end
      return
    end
    if LuaClassObj.GetGameStatus(bp_global) ~= GameStatus.Fighting then
      return
    end
    if _ARG_1_ == U1(83, 183, 72, 7, 100, 136, 244) then
    elseif _ARG_1_ == U1(70, 189, 81, 11, 125, 152, 173, 101, 159, 196, 52, 93, 20, 194) then
    end
    do return end
    _ARG_1_ = U1[86]
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.LogOut()
  log(bWriteLog and U1(100, 178, 76, 7, 101, 137, 197, 127, 130, 219, 40, 18, 76, 155, 139, 67, 250, 206, 27, 55, 143, 152, 132, 72, 138, 151, 13, 77, 22, 233, 195, 10, 239, 215))
  NetUtil.SendPkg((U1(75, 177, 66, 13, 126, 137)))
  if NetUtil.PleaseReloginTimer then
    NetUtil.PleaseReloginTimer = nil
  end
  return
end

function NetUtil.sync_time(_ARG_0_)
  do
    log(bWriteLog and string.format(U1(84, 167, 75, 1, 84, 137, 233, 124, 147, 137, 107, 23, 18), U2.FormatTime_YMDHMS(_ARG_0_, true)))
    U2.SetServerTimeInSec(_ARG_0_)
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.LogoutNoRefresh()
  NetUtil.noRefreshLogout = true
  return
end

function NetUtil.ProcOnDisconnected()
  NetUtil.tNetDisconnected = U1.OSTime()
  return
end

function NetUtil.ProcOnConnecting()
  NetUtil.tNetConnecting = U1.OSTime()
  return
end

function NetUtil.ProcOnConnected()
  NetUtil.tNetConnected = U1.OSTime()
  return
end

function NetUtil.CheckSpecialDeviceNetFlash()
  if not (NetUtil.tNetDisconnected > 0 and NetUtil.tNetConnecting > NetUtil.tNetDisconnected and NetUtil.tNetConnected > NetUtil.tNetConnecting and NetUtil.tNetConnecting - NetUtil.tNetDisconnected <= 1) or NetUtil.tNetConnected - NetUtil.tNetDisconnected <= 1 then
  end
  do return false end
  return
end

function NetUtil.MoveFollowTarget(_ARG_0_, _ARG_1_)
  do
    _ARG_1_ = _ARG_1_ or 0
    Client.MoveFollowTarget(GameFrontendHUD, _ARG_0_, _ARG_1_)
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.check_dh_packet_key(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
  do
    log(bWriteLog and U1(105, 187, 81, 55, 127, 148, 236, 63, 149, 193, 52, 81, 10, 233, 194, 6, 136, 158, 52, 49, 144, 168, 132, 126, 141, 220, 56))
    if type(_ARG_0_) ~= U1(84, 170, 87, 11, 101, 154) then
      sandbox.LogError(U1(105, 187, 81, 55, 127, 148, 236, 63, 149, 193, 52, 81, 10, 233, 194, 6, 136, 158, 52, 49, 144, 168, 132, 126, 141, 220, 56, 2, 1, 199, 213, 21, 162, 138, 26, 41, 142, 164, 221) .. tostring(_ARG_0_))
      return
    end
    if type(_ARG_1_) ~= U1(84, 170, 87, 11, 101, 154) then
      sandbox.LogError(table.concat({
        U1(105, 187, 81, 55, 127, 148, 236, 63, 149, 193, 52, 81, 10, 233, 194, 6, 136, 158, 52, 49, 144, 168, 132, 126, 141, 220, 56, 2, 2, 208, 196, 33, 183, 159, 38, 41, 142, 169, 191, 90),
        U1(66, 167, 122, 15, 111, 200, 189)
      }) .. tostring(_ARG_1_))
      return
    end
    _ARG_3_.packet_key_md5 = Client.MD5LuaString(_ARG_0_)
    _ARG_3_.svr_packet_key_md5 = _ARG_1_
    if _ARG_4_ or string.lower((Client.MD5LuaString(_ARG_0_))) ~= string.lower(_ARG_1_) then
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.DecXorForBattle(_ARG_0_, _ARG_1_)
  do
    if _ARG_0_ == nil then
      sandbox.LogError((U1(97, 171, 75, 1, 94, 137, 233, 125, 216, 237, 52, 81, 57, 217, 212, 40, 184, 156, 23, 51, 143, 185, 156, 68, 198, 202, 51, 65, 81, 155, 139, 94, 169, 151, 41, 99)))
      return
    end
    if _ARG_1_ == nil then
      sandbox.LogError((U1(97, 171, 75, 1, 94, 137, 233, 125, 216, 237, 52, 81, 57, 217, 212, 40, 184, 156, 23, 51, 143, 185, 156, 68, 198, 210, 36, 91, 81, 155, 139, 94, 169, 151, 41, 99)))
      return
    end
    if string.len((tostring(_ARG_0_))) == 0 then
      return
    end
    if string.len((tostring(_ARG_1_))) == 0 then
      return
    end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    do return table.concat({}) end
    do return end
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.ShowDSTimeOutTipsUI(_ARG_0_, _ARG_1_)
  do
    if NetUtil.nDSTimeOutShowBitMask & NetUtil.DSTimeOutLong > 0 and _ARG_1_ > NetUtil.DSTimeOutLong then
      return
    end
    if UIManager.UI_Config_InGame == nil or UIManager.UI_Config_InGame.WeakNetworkUI == nil then
      return
    end
    if _ARG_0_ then
      if not NetUtil.dsTimeOutTipsUIShowing then
        if UIManager.GetUI(UIManager.UI_Config_InGame.WeakNetworkUI) == nil then
        else
        end
        NetUtil.nDSTimeOutShowBitMask = NetUtil.nDSTimeOutShowBitMask | _ARG_1_
        NetUtil.dsTimeOutTipsUIShowing = true
      end
    else
      if UIManager.GetUI(UIManager.UI_Config_InGame.WeakNetworkUI) ~= nil then
      end
      NetUtil.dsTimeOutTipsUIShowing = false
      NetUtil.nDSTimeOutShowBitMask = NetUtil.nDSTimeOutShowBitMask & ~_ARG_1_
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.GetAutoReconnectParam()
  log(bWriteLog and U1(105, 187, 81, 55, 127, 148, 236, 63, 177, 204, 37, 115, 20, 194, 201, 60, 178, 141, 58, 60, 149, 168, 147, 85, 182, 216, 51, 67, 28))
  goto lbl_62
  if (127).checkFunc() then
  else
    ::lbl_62::
  end
  do return {
    times = 2,
    showFunc = nil,
    clearFunc = nil
  } end
  return
end

function NetUtil.ClearAutoReconnectParam()
  if not NetUtil.AutoReconnectParam then
    return
  end
  log(bWriteLog and U1(105, 187, 81, 55, 127, 148, 236, 63, 181, 197, 52, 83, 19, 247, 211, 26, 184, 188, 48, 49, 148, 163, 158, 68, 133, 205, 17, 67, 3, 199, 219))
  NetUtil.ClearAutoReconnectTimer()
  if NetUtil.AutoReconnectParam.clearFunc then
    NetUtil.AutoReconnectParam.clearFunc()
  end
  NetUtil.AutoReconnectParam = nil
  return
end

function NetUtil.ClearAutoReconnectTimer()
  if NetUtil.autoReconnectTimer then
    NetUtil.autoReconnectTimer = nil
  end
  return
end

function NetUtil.NetUnstableReport.RecordChange(_ARG_0_)
  do
    if not NetUtil.NetUnstableReport.Enabled then
      return
    end
    if NetUtil.NetUnstableReport.LastRecordedUnstable == _ARG_0_ then
      return
    end
    NetUtil.NetUnstableReport.LastRecordedUnstable = _ARG_0_
    NetUtil.NetUnstableReport.History[NetUtil.NetUnstableReport.HistoryHeadIndex] = {
      Time = os.time(),
      Unstable = _ARG_0_
    }
    if NetUtil.NetUnstableReport.HistoryMaxSize <= NetUtil.NetUnstableReport.HistoryHeadIndex then
      NetUtil.NetUnstableReport.HistoryHeadIndex = 1
    else
      NetUtil.NetUnstableReport.HistoryHeadIndex = NetUtil.NetUnstableReport.HistoryHeadIndex + 1
    end
    if NetUtil.NetUnstableReport.HistoryMaxSize > NetUtil.NetUnstableReport.HistoryCount then
      NetUtil.NetUnstableReport.HistoryCount = NetUtil.NetUnstableReport.HistoryCount + 1
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function NetUtil.NetUnstableReport.IsNetUnstableAtTime(_ARG_0_)
  do
    if type(_ARG_0_) ~= U1(73, 171, 72, 0, 110, 143) then
      return false
    end
    if not NetUtil.NetUnstableReport.Enabled then
      return false
    end
    if 0 >= NetUtil.NetUnstableReport.HistoryCount then
      return false
    end
    if NetUtil.NetUnstableReport.HistoryHeadIndex - 1 < 1 then
    end
    _ARG_0_ = _ARG_0_
    if NetUtil.NetUnstableReport.HistoryMaxSize - 143 < 1 then
    end
    if NetUtil.NetUnstableReport.History[NetUtil.NetUnstableReport.HistoryMaxSize - 143 + NetUtil.NetUnstableReport.HistoryMaxSize] ~= nil and _ARG_0_ >= NetUtil.NetUnstableReport.History[NetUtil.NetUnstableReport.HistoryMaxSize - 143 + NetUtil.NetUnstableReport.HistoryMaxSize].Time then
      return NetUtil.NetUnstableReport.History[NetUtil.NetUnstableReport.HistoryMaxSize - 143 + NetUtil.NetUnstableReport.HistoryMaxSize].Unstable
    end
    _ARG_0_ = _ARG_0_
    do return false end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

if _G.IsEnableMockGameSvr then
  function NetUtil.SendMsgToMockGameSvr(_ARG_0_, ...)
    do
      print(bWriteLog and string.format(U1(105, 187, 81, 55, 127, 148, 236, 63, 186, 198, 54, 91, 15, 251, 201, 13, 188, 169, 52, 63, 158, 158, 134, 83, 198, 244, 50, 69, 37, 223, 198, 27, 231, 195, 101, 103, 152), _ARG_0_))
      
      if _ARG_0_ == U1(75, 177, 66, 11, 101) then
        NetUtil.SendPkg(U1(74, 177, 70, 9, 108, 156, 237, 116, 133, 223, 35, 109, 13, 217, 193, 7, 185), ...)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end
end
UnrealNet.NetworkStatus = {
  Offline = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(104, 184, 67, 14, 98, 147, 229),
  Connecting = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(100, 177, 75, 12, 110, 158, 244, 120, 152, 206),
  Online = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(104, 176, 73, 11, 101, 152),
  Lost = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(107, 177, 86, 22),
  RecoverableLost = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(117, 187, 70, 13, 125, 152, 242, 112, 148, 197, 52, 126, 14, 197, 210)
}
UnrealNet.NetworkEvent = {
  RemoteHostResolved = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(117, 187, 72, 13, 127, 152, 200, 126, 133, 221, 3, 87, 18, 217, 202, 24, 178, 138),
  NetworkEstablished = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(105, 187, 81, 21, 100, 143, 235, 84, 133, 221, 48, 80, 13, 223, 213, 6, 178, 138),
  NetworkRecovered = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(105, 187, 81, 21, 100, 143, 235, 67, 147, 202, 62, 68, 4, 196, 195, 10)
}
UnrealNet.NetworkException = {
  FailureReceived = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(97, 191, 76, 14, 126, 143, 229, 67, 147, 202, 52, 91, 23, 211, 194),
  ConnectionLost = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(100, 177, 75, 12, 110, 158, 244, 120, 153, 199, 29, 93, 18, 194),
  ConnectionTimeout = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(100, 177, 75, 12, 110, 158, 244, 120, 153, 199, 5, 91, 12, 211, 201, 27, 163),
  ConnectionLongTimeNoReceived = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(100, 177, 75, 12, 110, 158, 244, 120, 153, 199, 29, 93, 15, 209, 242, 7, 186, 139, 27, 61, 169, 168, 147, 68, 143, 207, 36, 70),
  ConnectingTimeout = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(100, 177, 75, 12, 110, 158, 244, 120, 152, 206, 5, 91, 12, 211, 201, 27, 163),
  PendingConnectionFailure = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(119, 187, 75, 6, 98, 147, 231, 82, 153, 199, 63, 87, 2, 194, 207, 1, 185, 168, 52, 59, 151, 184, 130, 68),
  CriticalSocketError = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(100, 172, 76, 22, 98, 158, 225, 125, 165, 198, 50, 89, 4, 194, 227, 28, 165, 129, 39),
  ActorChannelError = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(102, 189, 81, 13, 121, 190, 232, 112, 152, 199, 52, 94, 36, 196, 212, 1, 165)
}
UnrealNet.FailureReceivedReason = {
  CharacterDead = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(100, 182, 68, 16, 106, 158, 244, 116, 132, 237, 52, 83, 5),
  TeammatesAllDead = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(115, 187, 68, 15, 102, 156, 244, 116, 133, 232, 61, 94, 37, 211, 199, 10),
  GameOver = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(96, 191, 72, 7, 68, 139, 229, 99),
  TrainingOver = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(115, 172, 68, 11, 101, 148, 238, 118, 185, 223, 52, 64),
  CheatDetected = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(100, 182, 64, 3, 127, 185, 229, 101, 147, 202, 37, 87, 5),
  WatchedPlayerGone = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(112, 191, 81, 1, 99, 152, 228, 65, 154, 200, 40, 87, 19, 241, 201, 0, 178),
  NormalNetDriverShutdown = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(105, 177, 87, 15, 106, 145, 223, 95, 147, 221, 21, 64, 8, 192, 195, 28, 132, 134, 32, 38, 159, 162, 135, 79),
  HostClosedConnection = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(111, 177, 86, 22, 43, 158, 236, 126, 133, 204, 53, 18, 21, 222, 195, 78, 180, 129, 59, 60, 158, 174, 132, 72, 137, 215, 111)
}

function UnrealNet.HandleNetworkEvent(_ARG_0_, _ARG_1_, ...)
  do
    _ARG_1_ = _ARG_1_ or _ENV()
    U1.NetUtil.SendPkg(_ENV(85, 187, 85, 13, 121, 137, 223, 100, 152, 219, 52, 83, 13, 216, 195, 26, 136, 139, 35, 55, 149, 185), U1.g_game_id, _ARG_0_, _ARG_1_)
    if _ARG_0_ == U1.UnrealNet.NetworkEvent.RemoteHostResolved then
      return
    end
    if _ARG_0_ == _ENV(105, 187, 81, 21, 100, 143, 235, 84, 133, 221, 48, 80, 13, 223, 213, 6, 178, 138) or _ARG_0_ == _ENV(105, 187, 81, 21, 100, 143, 235, 67, 147, 202, 62, 68, 4, 196, 195, 10) then
      U1.NetUtil.dsTimeOutRetryTimes = 0
      U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_main_city_reconnect).maincity_dsTimeOutRetryTimes = 0
    end
    do return end
    _ARG_0_ = _ARG_0_
  end
end

function UnrealNet.FilterNetworkException(_ARG_0_, _ARG_1_)
  do
    if _ARG_0_ == UnrealNet.NetworkException.FailureReceived then
      if string.find(_ARG_1_, UnrealNet.FailureReceivedReason.NormalNetDriverShutdown) ~= nil then
        return false
      end
      if string.find(_ARG_1_, UnrealNet.FailureReceivedReason.HostClosedConnection) == 1 then
        return false
      end
    end
    if string.find(_ARG_1_, (U1(116, 169, 76, 22, 104, 149, 201, 98, 154, 200, 63, 86))) == 1 then
      log(bWriteLog and U1(116, 169, 76, 22, 104, 149, 201, 98, 154, 200, 63, 86, 65, 223, 213, 78, 163, 156, 32, 55))
      return false
    elseif string.find(_ARG_1_, (U1(105, 177, 87, 15, 106, 145, 223, 82, 158, 200, 63, 92, 4, 218, 229, 2, 178, 143, 59, 7, 139))) ~= nil then
      if LuaClassObj.GetGameStatus(bp_global) == GameStatus.Login or LuaClassObj.GetGameStatus(bp_global) == GameStatus.Loading then
        return false
      end
      if LobbySystem and LobbySystem.isWaitToEnterGame then
        return false
      end
    end
    do return true end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function UnrealNet.NetworkExceptionAddEnterBattleStage(_ARG_0_)
  do
    if U1.require((_ENV(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))).GetGameFrontendHUD() ~= nil then
    end
    if _ARG_0_ == nil or #_ARG_0_ == 0 then
    else
    end
    do return (_ENV(116, 170, 68, 5, 110, 199, 160) .. U1.require((_ENV(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))).GetGameFrontendHUD():GetClientEnterBattleStage()) .. _ENV(7) .. _ARG_0_ end
    do return end
    _ARG_0_ = _ARG_0_
  end
end

function UnrealNet.HandleNetworkExceptionReport(_ARG_0_, _ARG_1_, _ARG_2_)
  do
    if require((U1(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))).GetGameFrontendHUD() ~= nil then
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function UnrealNet.HandleNetworkConnectionClosed(_ARG_0_, _ARG_1_)
  do
    if _ARG_0_ == UnrealNet.FailureReceivedReason.NormalNetDriverShutdown and _ARG_1_ == U1() or _ARG_0_ == U1(105, 177, 87, 15, 106, 145, 223, 82, 158, 200, 63, 92, 4, 218, 229, 2, 178, 143, 59, 7, 139) and _ARG_1_ == U1() then
      return
    end
    do return end
    _ARG_0_ = _ARG_0_
  end
end

function UnrealNet.HandleSpectateException(_ARG_0_, _ARG_1_)
  do
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function UnrealNet.HandleNetworkException(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, ...)
  do
    if _ARG_0_ == UnrealNet.NetworkException.ActorChannelError then
      return
    end
    if _ARG_0_ == UnrealNet.NetworkException.FailureReceived and string.find(_ARG_2_ .. _ARG_1_, UnrealNet.FailureReceivedReason.TrainingOver) == 1 then
      return
    end
    if LuaClassObj.GetGameStatus(bp_global) == GameStatus.Login then
      return
    end
    if LuaClassObj.GetGameStatus(bp_global) == GameStatus.Fighting and (require((U1(68, 178, 76, 7, 101, 137, 174, 125, 153, 206, 56, 81, 79, 218, 201, 9, 190, 128, 123, 62, 148, 170, 153, 66, 185, 213, 46, 64, 19, 223))).isWaitToEnterGame or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):IsInUGCWaitingEnterGame()) then
      return
    end
    if require((U1(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))) ~= nil and require((U1(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))).GetGameFrontendHUD() ~= nil then
    end
    if not GameStatus.IsInLobbyOrMainCity() and not require((table.concat({
      U1(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 13, 217, 193, 7, 180, 192, 57, 61, 153, 175, 137, 15, 171, 216, 40, 76, 50, 207, 194, 7, 233, 178, 42, 32, 137, 164, 191, 124),
      U1(70, 183, 75, 61, 72, 148, 244, 104)
    }))).IsRecentMainCityGameID(g_game_id) and require((U1(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))).GetGameFrontendHUD():GetClientEnterBattleStage() ~= U1(98, 176, 81, 7, 121, 191, 225, 101, 130, 197, 52, 97, 20, 213, 197, 11, 164, 157) and _ARG_0_ == U1(100, 177, 75, 12, 110, 158, 244, 120, 153, 199, 29, 93, 15, 209, 242, 7, 186, 139, 27, 61, 169, 168, 147, 68, 143, 207, 36, 70) then
      return
    end
    if GameStatus.IsInLobbyOrMainCity() or not require((table.concat({
      U1(68, 178, 76, 7, 101, 137, 174, 98, 154, 220, 48, 28, 13, 217, 193, 7, 180, 192, 57, 61, 153, 175, 137, 15, 171, 216, 40, 76, 50, 207, 194, 7, 233, 178, 42, 32, 137, 164, 191, 124),
      U1(70, 183, 75, 61, 72, 148, 244, 104)
    }))).IsRecentMainCityGameID(g_game_id) and require((U1(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))).GetGameFrontendHUD():GetClientEnterBattleStage() ~= U1(98, 176, 81, 7, 121, 191, 225, 101, 130, 197, 52, 97, 20, 213, 197, 11, 164, 157) and (_ARG_0_ == U1(100, 177, 75, 12, 110, 158, 244, 120, 153, 199, 5, 91, 12, 211, 201, 27, 163) or _ARG_0_ == U1(100, 172, 76, 22, 98, 158, 225, 125, 165, 198, 50, 89, 4, 194, 227, 28, 165, 129, 39)) then
      return
    end
    if _ARG_0_ == U1(97, 191, 76, 14, 126, 143, 229, 67, 147, 202, 52, 91, 23, 211, 194) and (string.find(_ARG_2_ .. _ARG_1_, (U1(116, 169, 76, 22, 104, 149, 201, 98, 154, 200, 63, 86))) == 1 or string.find(_ARG_2_ .. _ARG_1_, (U1(84, 169, 76, 22, 104, 149, 223, 125, 147, 223, 52, 94, 62, 211, 222, 7, 163))) == 1) then
    else
    end
    if _ARG_0_ == U1(97, 191, 76, 14, 126, 143, 229, 67, 147, 202, 52, 91, 23, 211, 194) then
      if string.find(_ARG_2_ .. _ARG_1_, (U1(100, 182, 68, 16, 106, 158, 244, 116, 132, 237, 52, 83, 5))) == 1 then
      elseif string.find(_ARG_2_ .. _ARG_1_, (U1(116, 169, 76, 22, 104, 149, 201, 98, 154, 200, 63, 86))) == 1 then
        return
      elseif string.find(_ARG_2_ .. _ARG_1_, (U1(84, 169, 76, 22, 104, 149, 223, 125, 147, 223, 52, 94, 62, 211, 222, 7, 163))) == 1 then
        return
      elseif string.find(_ARG_2_ .. _ARG_1_, (U1(110, 186, 76, 18, 73, 156, 238))) == 1 then
        goto lbl_1187
        ::lbl_1187::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if ({
          [15] = 251
        }).banType and ({
          [15] = 251
        }).banInfo and ({
          [15] = 251
        }).banTime ~= nil then
          return
        end
      end
    end
    require((U1(68, 178, 76, 7, 101, 137, 174, 125, 153, 206, 56, 81, 79, 218, 201, 9, 190, 128, 123, 62, 148, 170, 153, 66, 185, 213, 46, 64, 19, 223))).enterGameTimeOutParams = table.pack(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    if UIManager.IsUIShow(UIManager.UI_Config.xmission_main) then
    else
    end
    if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game).InGameReEnterGameInfo ~= nil and 11 <= #ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game).InGameReEnterGameInfo and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game).InGameReEnterGameInfo[11] ~= nil then
    end
    if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game).InGameReEnterGameInfo[11] ~= 0 then
    end
    if CDataTable.GetTableData(U1(101, 138, 104, 13, 111, 152), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game).InGameReEnterGameInfo[11]) and CDataTable.GetTableData(U1(101, 138, 104, 13, 111, 152), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game).InGameReEnterGameInfo[11]).ModType ~= U1(115, 154, 104) then
    end
    if true == true then
    end
    if import((U1(116, 179, 68, 16, 127, 191, 229, 112, 132, 204, 35, 127, 0, 216, 199, 9, 178, 156, 25, 39, 154, 143, 130, 72, 130, 222, 36))) ~= nil then
      if import((U1(116, 179, 68, 16, 127, 191, 229, 112, 132, 204, 35, 127, 0, 216, 199, 9, 178, 156, 25, 39, 154, 143, 130, 72, 130, 222, 36))).IsClientBackEndSwitcherBEnable(9) then
      end
      if import((U1(116, 179, 68, 16, 127, 191, 229, 112, 132, 204, 35, 127, 0, 216, 199, 9, 178, 156, 25, 39, 154, 143, 130, 72, 130, 222, 36))).IsClientBackEndSwitcherBEnable(10) then
      end
      if import((U1(116, 179, 68, 16, 127, 191, 229, 112, 132, 204, 35, 127, 0, 216, 199, 9, 178, 156, 25, 39, 154, 143, 130, 72, 130, 222, 36))).IsClientBackEndSwitcherBEnable(5) then
      else
      end
    end
    if not _G.IsEditor and true then
    end
    if LuaClassObj.GetGameStatus(bp_global) == GameStatus.Fighting and _ARG_3_ == true and 0 > NetUtil.dsTimeOutRetryTimes and not BattleResult.IgnoreDSError then
      NetUtil.dsTimeOutRetryTimes = NetUtil.dsTimeOutRetryTimes + 1
      if NetUtil.dsTimeOutRetryTimes == 1 then
      end
      require((U1(68, 178, 76, 7, 101, 137, 174, 125, 153, 206, 56, 81, 79, 218, 201, 9, 190, 128, 123, 62, 148, 170, 153, 66, 185, 213, 46, 64, 19, 223))).enterGameTimeOutParams = nil
      if NetUtil.dsTimeOutRetryTimes == 1 then
      end
      return
    end
    if _ARG_0_ == U1(97, 191, 76, 14, 126, 143, 229, 67, 147, 202, 52, 91, 23, 211, 194) or _ARG_0_ == UnrealNet.NetworkException.PendingConnectionFailure then
      if string.find(_ARG_2_ .. _ARG_1_, (U1(100, 182, 68, 16, 106, 158, 244, 116, 132, 237, 52, 83, 5))) == 1 then
      elseif string.find(_ARG_2_ .. _ARG_1_, (U1(115, 187, 68, 15, 102, 156, 244, 116, 133, 232, 61, 94, 37, 211, 199, 10))) == 1 then
      elseif string.find(_ARG_2_ .. _ARG_1_, (U1(96, 191, 72, 7, 68, 139, 229, 99))) == 1 then
      elseif string.find(_ARG_2_ .. _ARG_1_, UnrealNet.FailureReceivedReason.WatchedPlayerGone) == 1 then
      elseif string.find(_ARG_2_ .. _ARG_1_, (U1(116, 177, 70, 3, 98, 145, 201, 98, 154, 200, 63, 86, 40, 216, 199, 13, 163, 135, 35, 55))) == 1 then
      elseif string.find(_ARG_2_ .. _ARG_1_, (U1(116, 177, 70, 3, 98, 145, 201, 98, 154, 200, 63, 86, 34, 218, 201, 29, 178))) == 1 then
      elseif string.find(_ARG_2_ .. _ARG_1_, (U1(119, 178, 68, 12, 91, 181, 200, 126, 155, 204, 18, 94, 14, 197, 195))) == 1 then
      elseif string.find(_ARG_2_ .. _ARG_1_, (U1(119, 178, 68, 12, 72, 181, 200, 112, 154, 197, 18, 94, 14, 197, 195))) == 1 then
      elseif string.find(_ARG_2_ .. _ARG_1_, (U1(104, 169, 75, 7, 121, 182, 233, 114, 157, 198, 36, 70))) == 1 then
      elseif string.find(_ARG_2_ .. _ARG_1_, (U1(110, 173, 73, 3, 101, 153, 195, 125, 153, 218, 52))) == 1 then
      elseif string.find(_ARG_2_ .. _ARG_1_, (U1(110, 186, 76, 18, 64, 148, 227, 122, 185, 220, 37, 113, 13, 223, 195, 0, 163, 220, 16, 42, 146, 185))) == 1 then
      elseif string.find(_ARG_2_ .. _ARG_1_, (U1(100, 137, 106, 53, 72, 145, 239, 98, 147))) == 1 then
      elseif string.find(_ARG_2_ .. _ARG_1_, (U1(100, 137, 106, 53, 66, 147, 225, 114, 130, 192, 39, 87))) == 1 then
      elseif string.find(_ARG_2_ .. _ARG_1_, (U1(74, 191, 75, 13, 121, 162, 235, 120, 149, 194, 62, 71, 21, 233, 199, 2, 187, 177, 35, 59, 136, 164, 132, 78, 148))) == 1 then
        if string.find(_ARG_2_ .. _ARG_1_, (U1(74, 191, 75, 13, 121, 162, 234, 126, 159, 199, 37, 109, 21, 211, 212, 3, 190, 128, 52, 38, 158))) then
          return
        elseif string.find(_ARG_2_ .. _ARG_1_, (U1(74, 191, 75, 13, 121, 162, 234, 126, 159, 199, 37))) then
        else
        end
      elseif string.find(_ARG_2_ .. _ARG_1_, (U1(74, 191, 75, 13, 121, 162, 225, 117, 146, 246, 51, 94, 0, 213, 205))) == 1 then
      elseif string.find(_ARG_2_ .. _ARG_1_, (U1(74, 191, 75, 13, 121, 162, 235, 120, 149, 194, 62, 71, 21, 233, 201, 2, 179, 135, 59, 33, 143, 146, 134, 72, 149, 208, 53, 77, 3))) == 1 then
      end
    elseif _ARG_0_ == U1(100, 177, 75, 12, 110, 158, 244, 120, 153, 199, 5, 91, 12, 211, 201, 27, 163) then
    elseif _ARG_0_ == U1(100, 177, 75, 12, 110, 158, 244, 120, 152, 206, 5, 91, 12, 211, 201, 27, 163) then
    else
    end
    if BattleResult.IgnoreDSError then
      require((U1(68, 178, 76, 7, 101, 137, 174, 125, 153, 206, 56, 81, 79, 218, 201, 9, 190, 128, 123, 62, 148, 170, 153, 66, 185, 213, 46, 64, 19, 223))).enterGameTimeOutParams = nil
      return
    end
    if require((U1(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))) ~= nil and require((U1(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))).GetGameFrontendHUD() ~= nil then
    end
    if true == true and LuaClassObj.GetGameStatus(bp_global) == GameStatus.Fighting and require((U1(68, 178, 76, 7, 101, 137, 174, 114, 153, 196, 60, 93, 15, 152, 211, 7, 136, 155, 33, 59, 151))).GetGameFrontendHUD():GetClientEnterBattleStage() == U1(98, 176, 81, 7, 121, 191, 225, 101, 130, 197, 52, 97, 20, 213, 197, 11, 164, 157) and (_ARG_0_ == U1(100, 177, 75, 12, 110, 158, 244, 120, 153, 199, 5, 91, 12, 211, 201, 27, 163) or _ARG_0_ == U1(100, 177, 75, 12, 110, 158, 244, 120, 153, 199, 29, 93, 15, 209, 242, 7, 186, 139, 27, 61, 169, 168, 147, 68, 143, 207, 36, 70) or _ARG_0_ == U1(100, 172, 76, 22, 98, 158, 225, 125, 165, 198, 50, 89, 4, 194, 227, 28, 165, 129, 39)) and UnrealNet.IsNeedShowMsgBox(_ARG_2_ .. _ARG_1_) then
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game) then
        ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game).InGameShowingReEnter = true
      end
    else
    end
    do return end
    _ARG_1_ = SetIsDirectShow
  end
end

function UnrealNet.RepListMismatchDetectTrigger(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
  do
    log(bWriteLog and U1(114, 176, 87, 7, 106, 145, 206, 116, 130, 135, 3, 87, 17, 250, 207, 29, 163, 163, 60, 33, 150, 172, 132, 66, 142, 253, 36, 86, 20, 197, 194, 42, 181, 151, 34, 37, 142, 175))
    if not slua.isValid(_ARG_2_) or not slua.isValid(_ARG_3_) then
      return
    end
    if string.find(_ARG_5_, (U1(117, 187, 70, 7, 98, 139, 229, 117, 180, 220, 63, 81, 9, 150, 224, 47, 158, 162, 16, 22))) then
    end
    if _ARG_0_ and true then
    end
    if string.find(_ARG_5_, (U1(117, 187, 68, 6, 72, 146, 238, 101, 147, 199, 37, 112, 13, 217, 197, 5, 135, 143, 44, 62, 148, 172, 148, 103, 135, 208, 45, 71, 21))) then
    end
    if _ARG_1_ and true then
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function UnrealNet.IsNeedShowMsgBox(_ARG_0_)
  do
    if string.find(_ARG_0_, (U1(74, 191, 81, 1, 99, 162, 233, 98, 153, 197, 48, 70, 8, 217, 200, 49, 187, 143, 55, 55, 151))) == 1 then
      return false
    end
    if string.find(_ARG_0_, (U1(74, 191, 75, 13, 121, 162, 234, 126, 159, 199, 37, 109, 21, 211, 212, 3, 190, 128, 52, 38, 158))) then
      return false
    end
    do return true end
    do return end
    _ARG_0_ = _ARG_0_
  end
end

function UnrealNet.RetrunToLobbyFromDisconnect(_ARG_0_)
  do
    do return end
    _ARG_0_ = _ARG_0_
  end
end

function UnrealNet.HandleBattleExceptionReport(_ARG_0_, _ARG_1_, _ARG_2_, ...)
  do
    _ARG_0_ = FuncUtil.ReplaceIllegalChar(_ARG_0_)
    _ARG_1_ = FuncUtil.ReplaceIllegalChar(_ARG_1_)
    UnrealNet.HandleNetworkExceptionReport(_ARG_0_, U1(), _ARG_1_)
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

function UnrealNet.OnNetRepSerializeError(_ARG_0_, _ARG_1_)
  do
    if _ARG_0_ == 2 then
    end
    do return end
    _ARG_0_ = _ARG_0_
    _ARG_0_ = _ARG_0_
  end
end

if Client.GetDevicePlatformName() == (function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(102, 176, 65, 16, 100, 148, 228) or Client.GetDevicePlatformName() == (function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(110, 145, 118) then
end
if HDmpveRemote.HDmpveRemoteConfigGetInt((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(96, 191, 76, 12, 72, 143, 225, 98, 158, 229, 62, 85, 40, 216, 192, 1, 149, 143, 54, 57, 156, 191, 159, 84, 136, 221, 14, 76, 56, 200, 223, 10), 0) ~= 0 then
  if HDmpveRemote.HDmpveRemoteConfigGetInt((function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(96, 191, 76, 12, 72, 143, 225, 98, 158, 229, 62, 85, 40, 216, 192, 1, 149, 143, 54, 57, 156, 191, 159, 84, 136, 221, 14, 76, 56, 200, 223, 10), 0) & 1 ~= 0 then
  end
  if HDmpveRemote.HDmpveRemoteConfigGetInt((function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(96, 191, 76, 12, 72, 143, 225, 98, 158, 229, 62, 85, 40, 216, 192, 1, 149, 143, 54, 57, 156, 191, 159, 84, 136, 221, 14, 76, 56, 200, 223, 10), 0) & 2 ~= 0 then
  end
end
return
