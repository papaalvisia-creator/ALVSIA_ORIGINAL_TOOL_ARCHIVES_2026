do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(178, 125, 52, 6, 69)))(require((table.concat({
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(178, 125, 60, 16, 88, 160, 220, 227, 173, 146, 53, 125, 207, 113, 221, 192, 78, 79, 64, 43, 178, 202, 235, 212, 180, 154, 106, 10, 200, 107, 205, 227, 89, 88, 89, 49, 164, 145, 252, 158),
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(146, 126, 56, 24, 89, 186, 187, 228, 164, 138, 11, 6, 229, 92, 209, 195, 68)
}))), nil, {
  ["EItemSource"] = {Default = 0, Wardrobe = 1},
  ["ctor"] = function(_ARG_0_)
    do
      _ARG_0_._nItemId = nil
      _ARG_0_._nLastShowItemId = nil
      _ARG_0_._nCount = nil
      _ARG_0_._nValidTime = nil
      _ARG_0_._tExtraData = nil
      _ARG_0_._uObj_itemCfg = nil
      _ARG_0_._bIsPlayingDecomposeAni = false
      _ARG_0_._nCountOriginalFontSize = nil
      _ARG_0_._tCountScaleSlotOriginalSize = nil
      _ARG_0_._nShowIconTimerId = nil
      _ARG_0_._bIconWaitingDownload = false
      _ARG_0_._cObj_downloadUI = nil
      _ARG_0_._bIsChangeCountScale = false
      _ARG_0_._bIsChangeFontSize = false
      _ARG_0_._bIsCustomSize = false
      _ARG_0_._bInitIconShow = false
      _ARG_0_._CDNImageDownloadIndex = nil
      _ARG_0_._ShowIconPath = nil
      _ARG_0_._sOriginalPath = _ENV()
      _ARG_0_._gifWidget = nil
      _ARG_0_._gifWidget = nil
      _ARG_0_._decomposeItemID = nil
      _ARG_0_._eItemSource = U1.EItemSource.Default
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      __super.OnInitialize(_ARG_0_)
      _ARG_0_._nCountOriginalFontSize = _ARG_0_.UIRoot.RichText_ItemCount.Font.Size
      _ARG_0_._tCountScaleSlotOriginalSize = {
        _ARG_0_.UIRoot.ScaleBox_Count.Slot:GetOffsets().Left,
        _ARG_0_.UIRoot.ScaleBox_Count.Slot:GetOffsets().Top,
        _ARG_0_.UIRoot.ScaleBox_Count.Slot:GetOffsets().Right,
        _ARG_0_.UIRoot.ScaleBox_Count.Slot:GetOffsets().Bottom
      }
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      __super.RegistEvents(_ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Item, _ARG_0_.OnItemBtnClick, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostInitialize"] = function(_ARG_0_)
    do
      __super.OnPostInitialize(_ARG_0_)
      _ARG_0_:RestoreUIOperation()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      if not _ARG_0_:IsAsyncLoading() then
        _ARG_0_:_ResetSizeShow()
        _ARG_0_:_ResetScaleCountSize()
        _ARG_0_:_ResetFontSize()
        _ARG_0_:SetIconAndQualityAlpha(1)
        _ARG_0_:_ClearAvatarIcon(true)
        _ARG_0_:_ResetIconScaleAndRotation()
        if _ARG_0_._tExtraData and _ARG_0_._tExtraData.bIsIconSpacerShow then
          _ARG_0_:SetIconSpacerShow(false)
        end
        if _ARG_0_._tExtraData and _ARG_0_._tExtraData.bIsAvatarIcon then
          _ARG_0_:SetIconPaddingByIsAvatar(false)
        end
      end
      _ARG_0_._cObj_downloadUI = nil
      _ARG_0_._CDNImageDownloadIndex = nil
      _ARG_0_._ShowIconPath = nil
      if _ARG_0_._downloadPollTimer then
        _ARG_0_:RemoveTimer(_ARG_0_._downloadPollTimer)
        _ARG_0_._downloadPollTimer = nil
      end
      _ARG_0_:_UpdateIconWaitingDownload(nil, false)
      __super.OnClose(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnItemBtnClick"] = function(_ARG_0_)
    do
      if not _ARG_0_._tExtraData then
        return
      end
      if _ARG_0_._tExtraData.bDisableClick then
        return
      end
      if not _ARG_0_._nItemId then
        return
      end
      if _ARG_0_._tExtraData.fClickItemCallback and _ARG_0_._tExtraData.fClickItemCallback(table.unpack(_ARG_0_._tExtraData.tClickItemCallbackParam or {})) then
        return
      end
      if not _ARG_0_:_GetItemCfg() then
        return
      end
      if _ARG_0_:_GetItemCfg().ItemType == ENUM_ITEM_TYPE.Applique then
        return
      end
      if _ARG_0_:_ShowSpecialItemTip(_ARG_0_:_GetItemCfg(), _ARG_0_._tExtraData) then
        return
      end
      if _ARG_0_:_ShowPreviewView() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetIconPadding"] = function(_ARG_0_, _ARG_1_)
    do
      if not CDataTable.GetTableData(U1(152, 101, 48, 24), _ARG_1_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClearShowIconTimer"] = function(_ARG_0_)
    do
      if _ARG_0_._nShowIconTimerId then
        _ARG_0_:RemoveTimer(_ARG_0_._nShowIconTimerId)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CancelCDNImageDownload"] = function(_ARG_0_)
    do
      if _ARG_0_._CDNImageDownloadIndex and _ARG_0_._CDNImageDownloadIndex > 0 then
        _ARG_0_:CancelImageDownloadByIndex(_ARG_0_._CDNImageDownloadIndex)
        _ARG_0_._CDNImageDownloadIndex = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReSetIconFromItemId"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:_SetIconTextureByItemId(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ForceRefreshIcon"] = function(_ARG_0_)
    do
      _ARG_0_:UIOperation(function()
        _nLastShowItemId = nil
        _sLastOverrideIconPath = nil
        _ShowIconPath = nil
        _sOriginalPath = U1()
        _ENV:_RefreshIconShow()
        _ENV:_RefreshDownloadUI()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshIconTextureOnly"] = function(_ARG_0_)
    do
      _ARG_0_:UIOperation(function()
        if _ENV[U1.Decompose] then
        end
        if not _sOriginalPath or _sOriginalPath == U2() or _ShowIconPath == _sOriginalPath then
          return
        end
        _ShowIconPath = _sOriginalPath
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_IsFallbackIconReadyToRefresh"] = function(_ARG_0_)
    do
      if not _ENV then
        return false
      end
      if not _ARG_0_._sOriginalPath or _ARG_0_._sOriginalPath == U1() or _ARG_0_._ShowIconPath == _ARG_0_._sOriginalPath then
        return false
      end
      do return U2.require((U1(178, 125, 60, 16, 88, 160, 220, 243, 174, 138, 57, 60, 194, 48, 192, 209, 74, 126, 80, 49, 175, 136))).IsPufferDownloaded(_ARG_0_._sOriginalPath) == true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_UpdateIconWaitingDownload"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ENV then
        return
      end
      if not _ARG_2_ and not _ARG_0_._bIconWaitingDownload then
        return
      end
      _ARG_0_._bIconWaitingDownload = U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.CommonItem_IconRefreshMgr):Update(_ARG_0_, _ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetIconTextureByItemId"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_._sOriginalPath = _ENV()
      if not U1.CDataTable.GetTableData(_ENV(152, 101, 48, 24), _ARG_1_) then
        return
      end
      if _ARG_0_._tExtraData.bIconCdnShow then
        return
      end
      if (_ARG_0_._tExtraData or {}).sOverrideIconPath and (_ARG_0_._tExtraData or {}).sOverrideIconPath ~= _ENV() then
        _ARG_0_._ShowIconPath = (_ARG_0_._tExtraData or {}).sOverrideIconPath, _ARG_0_.UIRoot.Image_Icon:SetColorAndOpacity(U1.FLinearColor(1, 1, 1, 1))
        return
      end
      if U1.require((U1.table.concat({
        _ENV(178, 125, 60, 16, 88, 160, 220, 227, 173, 146, 53, 125, 217, 115, 215, 158, 118, 68, 68, 53, 169, 138, 198, 233, 136, 217, 51, 38, 221, 126, 207, 206, 110, 85, 92, 44, 137, 129, 230, 217),
        _ENV(189, 98)
      }))):IsDiyColor(_ARG_1_) then
      else
        if not U3.GetIconPath(_ARG_1_, U1.CDataTable.GetTableData(_ENV(152, 101, 48, 24), _ARG_1_), _ARG_0_.UIRoot.Image_Icon, (_ARG_0_._tExtraData or {}).bIsShowBigIcon, (_ARG_0_._tExtraData or {}).bIsShowBigIcon2, U4, {
          bContinueDefaultIcon = U2.IsFITVersion()
        }) then
          return
        end
        _ARG_0_._ShowIconPath = U3.GetIconPath(_ARG_1_, U1.CDataTable.GetTableData(_ENV(152, 101, 48, 24), _ARG_1_), _ARG_0_.UIRoot.Image_Icon, (_ARG_0_._tExtraData or {}).bIsShowBigIcon, (_ARG_0_._tExtraData or {}).bIsShowBigIcon2, U4, {
          bContinueDefaultIcon = U2.IsFITVersion()
        })
        _ARG_0_._sOriginalPath = U3.GetIconPath(_ARG_1_, U1.CDataTable.GetTableData(_ENV(152, 101, 48, 24), _ARG_1_), _ARG_0_.UIRoot.Image_Icon, (_ARG_0_._tExtraData or {}).bIsShowBigIcon, (_ARG_0_._tExtraData or {}).bIsShowBigIcon2, U4, {
          bContinueDefaultIcon = U2.IsFITVersion()
        }) or _ENV()
        _ARG_0_._bInitIconShow = true
        if not _ARG_0_._bInitIconShow or (_ARG_0_._tExtraData or {}).bIconShowNoDelay then
          if not U4 and (_ARG_0_._tExtraData or {}).fCheckIconScaleCallback then
            if ((_ARG_0_._tExtraData or {}).bIsShowBigIcon or (_ARG_0_._tExtraData or {}).bIsShowBigIcon2) and ((_ARG_0_._tExtraData or {}).bIsShowBigIcon2 and U1.CDataTable.GetTableData(_ENV(152, 101, 48, 24), _ARG_1_).ItemBigIcon2 ~= _ENV() and U1.CDataTable.GetTableData(_ENV(152, 101, 48, 24), _ARG_1_).ItemBigIcon2 or U1.CDataTable.GetTableData(_ENV(152, 101, 48, 24), _ARG_1_).ItemBigIcon) ~= U3.GetIconPath(_ARG_1_, U1.CDataTable.GetTableData(_ENV(152, 101, 48, 24), _ARG_1_), _ARG_0_.UIRoot.Image_Icon, (_ARG_0_._tExtraData or {}).bIsShowBigIcon, (_ARG_0_._tExtraData or {}).bIsShowBigIcon2, U4, {
              bContinueDefaultIcon = U2.IsFITVersion()
            }) then
              _ARG_0_._downloadPollTimer = _ARG_0_:AddTimerLoop(0.5, function()
                if U2 and require((U1(178, 125, 60, 16, 88, 160, 220, 243, 174, 138, 57, 60, 194, 48, 192, 209, 74, 126, 80, 49, 175, 136))).IsFileExist(U2) then
                  U3._downloadPollTimer = nil
                end
                return
              end, U1.TIMER_INFINITE, 0.5)
            end
          else
          end
        else
          _ARG_0_._nShowIconTimerId = _ARG_0_:AddTimerOnce((not _ARG_0_._bInitIconShow or (_ARG_0_._tExtraData or {}).bIconShowNoDelay) and 0.1 or 0, function()
            _ENV:SetTexture(U1.Image_Icon, U2, U3)
            if not U4 and U5.fCheckIconScaleCallback then
              U5.fCheckIconScaleCallback(U6, U2, U1.Image_Icon)
              if (U5.bIsShowBigIcon or U5.bIsShowBigIcon2) and (U5.bIsShowBigIcon2 and U7.ItemBigIcon2 ~= U8() and U7.ItemBigIcon2 or U7.ItemBigIcon) ~= U2 then
                _downloadPollTimer = _ENV:AddTimerLoop(0.5, function()
                  if U3 and require((U1(178, 125, 60, 16, 88, 160, 220, 243, 174, 138, 57, 60, 194, 48, 192, 209, 74, 126, 80, 49, 175, 136))).IsFileExist(U3) then
                    U4._downloadPollTimer = nil
                  end
                  return
                end, U9.TIMER_INFINITE, 0.5)
              end
            else
              _ENV:_ResetIconScaleAndRotation()
            end
            return
          end)
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_IsCanShowValidTimeIcon"] = function(_ARG_0_)
    do
      if GetState(U1.ENUM_DownloadType.ODPAK, (_ARG_0_:_GetDownloadList())) == U1.ENUM_DownloadState.Done then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetDownloadList"] = function(_ARG_0_)
    do
      if (_ARG_0_._tExtraData or {}).bIsSkipDownload then
        return {}, false
      end
      if GetDownloadIconPathList(_ARG_0_._nItemId, _ARG_0_._sOriginalPath, _ARG_0_:_GetItemCfg() and _ARG_0_:_GetItemCfg().SpecialIcon) and U1.next((GetDownloadIconPathList(_ARG_0_._nItemId, _ARG_0_._sOriginalPath, _ARG_0_:_GetItemCfg() and _ARG_0_:_GetItemCfg().SpecialIcon))) then
        return GetDownloadIconPathList(_ARG_0_._nItemId, _ARG_0_._sOriginalPath, _ARG_0_:_GetItemCfg() and _ARG_0_:_GetItemCfg().SpecialIcon), true
      end
      if (_ARG_0_._tExtraData or {}).relativeResIdList and U1.next((_ARG_0_._tExtraData or {}).relativeResIdList) then
        goto lbl_82
        ::lbl_82::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if (_ARG_0_._tExtraData or {}) and not U3 and (_ARG_0_._tExtraData or {}).fCheckIconScaleCallback and U1.CDataTable.GetTableData(U2(152, 101, 48, 24), _ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil) and U1.CDataTable.GetTableData(U2(152, 101, 48, 24), _ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil).ItemBigIcon then
        ;(_ARG_0_._tExtraData or {}).enableAutoDownloadMultipleItems = true
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory) and (_ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil) and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetTabIDDigits(_ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil) and 0 < U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetTabIDDigits(_ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil) and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetSubTabIDDigits(_ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil) and 0 < U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetSubTabIDDigits(_ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil) and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):FindTabIndexByTabId((U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetTabIDDigits(_ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil))) and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):FindSubTabIndexBySubTabId(U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):FindTabIndexByTabId((U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetTabIDDigits(_ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil))), (U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetSubTabIDDigits(_ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil))) and U1.require((U2(178, 125, 60, 16, 88, 160, 220, 227, 173, 146, 53, 125, 192, 113, 215, 217, 66, 15, 80, 34, 165, 202, 247, 199, 178, 168, 13, 45, 202, 107, 206, 212, 94, 67, 76))).InventoryList[U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):FindTabIndexByTabId((U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetTabIDDigits(_ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil)))] and U1.require((U2(178, 125, 60, 16, 88, 160, 220, 227, 173, 146, 53, 125, 192, 113, 215, 217, 66, 15, 80, 34, 165, 202, 247, 199, 178, 168, 13, 45, 202, 107, 206, 212, 94, 67, 76))).InventoryList[U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):FindTabIndexByTabId((U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetTabIDDigits(_ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil)))][U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):FindSubTabIndexBySubTabId(U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):FindTabIndexByTabId((U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetTabIDDigits(_ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil))), (U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetSubTabIDDigits(_ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil)))] and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetDownloadList((U1.CDataTable.GetTableData(U1.require((U2(178, 125, 60, 16, 88, 160, 220, 227, 173, 146, 53, 125, 192, 113, 215, 217, 66, 15, 80, 34, 165, 202, 247, 199, 178, 168, 13, 45, 202, 107, 206, 212, 94, 67, 76))).InventoryList[U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):FindTabIndexByTabId((U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetTabIDDigits(_ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil)))][U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):FindSubTabIndexBySubTabId(U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):FindTabIndexByTabId((U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetTabIDDigits(_ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil))), (U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetSubTabIDDigits(_ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil)))].DataName, _ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil))) and U1.next((U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetDownloadList((U1.CDataTable.GetTableData(U1.require((U2(178, 125, 60, 16, 88, 160, 220, 227, 173, 146, 53, 125, 192, 113, 215, 217, 66, 15, 80, 34, 165, 202, 247, 199, 178, 168, 13, 45, 202, 107, 206, 212, 94, 67, 76))).InventoryList[U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):FindTabIndexByTabId((U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetTabIDDigits(_ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil)))][U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):FindSubTabIndexBySubTabId(U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):FindTabIndexByTabId((U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetTabIDDigits(_ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil))), (U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetSubTabIDDigits(_ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil)))].DataName, _ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil))))) then
        goto lbl_273
        ::lbl_273::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return {
        _ARG_0_._nItemId > 0 and _ARG_0_._nItemId or nil
      }, false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetItemCfg"] = function(_ARG_0_)
    do
      if not _ARG_0_._nItemId then
        return
      end
      if not _ARG_0_._uObj_itemCfg then
        if not _ARG_0_._nItemId then
          return
        end
        _ARG_0_._uObj_itemCfg = CDataTable.GetTableData(U1(152, 101, 48, 24), _ARG_0_._nItemId)
      end
      do return _ARG_0_._uObj_itemCfg end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ShowSpecialItemTip"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_.bIsShowPersonalizedItemPreview and require((table.concat({
        U1(178, 125, 60, 16, 88, 160, 220, 252, 174, 128, 61, 48, 130, 108, 223, 220, 68, 72, 75, 35, 169, 202, 238, 207, 182, 158, 39, 28, 206, 97, 204, 197, 88, 95, 83, 58, 137, 132, 247, 194),
        U1(162, 126, 59, 20, 90, 189, 136, 241, 181, 142, 59, 61, 243, 107, 196, 217, 77)
      }))).CheckAndShowPersonalizedItemPreview(_ARG_1_) then
        return true
      end
      if _ARG_2_.bIsShowPartnerItemPreview and require((table.concat({
        U1(178, 125, 60, 16, 88, 160, 220, 227, 173, 146, 53, 125, 192, 113, 215, 217, 66, 15, 73, 42, 164, 134, 251, 142, 157, 146, 34, 55, 146, 98, 207, 199, 88, 82, 106, 54, 185, 129, 226, 220),
        U1(180, 78, 52, 3, 87, 160, 147, 226, 158, 146, 32, 58, 192)
      }))).CheckIfCouplePoseItem(_ARG_1_) and require((table.concat({
        U1(178, 125, 60, 16, 88, 160, 220, 227, 173, 146, 53, 125, 192, 113, 215, 217, 66, 15, 73, 42, 164, 134, 251, 142, 157, 146, 34, 55, 146, 98, 207, 199, 88, 82, 106, 54, 185, 129, 226, 220),
        U1(180, 78, 52, 3, 87, 160, 147, 226, 158, 146, 32, 58, 192)
      }))).ShowPartnerItemPreview(_ARG_0_._nItemId) == true then
        return true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ShowPreviewView"] = function(_ARG_0_)
    do
      if _ARG_0_._tExtraData.affixs and next(_ARG_0_._tExtraData.affixs) then
        return false
      end
      if not _ARG_0_._tExtraData or not _ARG_0_._tExtraData.bIsShowItemPreview then
        return false
      end
      if not UIManager.GetUI(UIManager.UI_Config.Social_Person_Space_UIBP) and (require((table.concat({
        U1(178, 125, 60, 16, 88, 160, 220, 227, 173, 146, 53, 125, 192, 113, 215, 217, 66, 15, 76, 49, 163, 137, 221, 208, 163, 146, 50, 42, 217, 121, 142, 204, 94, 86, 92, 54, 137, 157, 230, 213),
        U1(188, 65, 39, 16, 64, 189, 151, 231)
      }))).IsNeedShow(_ARG_0_._nItemId) or LobbySystem.CheckShowPackagePreview(_ARG_0_._nItemId)) and LobbySystem.PlayItemPreviewAnimation(_ARG_0_._nItemId, false, _ARG_0_._tExtraData.nShowPreviewType, _ARG_0_._tExtraData.tShowPreviewParams, _ARG_0_._nValidTime, {
        fromSelf = _ARG_0_._tExtraData.bPreviewFromSelf
      }) then
        return true
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ResetSizeShow"] = function(_ARG_0_)
    do
      if not _ARG_0_._bIsCustomSize then
        return
      end
      _ARG_0_._bIsCustomSize = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ResetScaleCountSize"] = function(_ARG_0_)
    do
      if not _ARG_0_._bIsChangeCountScale or not _ARG_0_._tCountScaleSlotOriginalSize then
        return
      end
      _ARG_0_._bIsChangeCountScale = false
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ResetFontSize"] = function(_ARG_0_)
    do
      if not _ARG_0_._bIsChangeFontSize then
        return
      end
      _ARG_0_.UIRoot.RichText_ItemCount.Font.Size = _ARG_0_._nCountOriginalFontSize or 18
      _ARG_0_._bIsChangeFontSize = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ResetIconScaleAndRotation"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClearAvatarIcon"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_._nItemId then
      end
      if _ARG_1_ or _ARG_0_._nLastShowItemId ~= ((_ARG_0_._tExtraData or {}).displayResId or _ARG_0_._nItemId) then
        _ARG_0_._gifWidget = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_InitResetShow"] = function(_ARG_0_)
    do
      _ARG_0_:SetIconIsShow(true)
      _ARG_0_._uObj_itemCfg = nil
      _ARG_0_._bIsPlayingDecomposeAni = false
      _ARG_0_._bIsChangeFontSize = false
      _ARG_0_._bIsChangeCountScale = false
      if tSpecialItemShowJumpCfg[_ARG_0_._nItemId] then
      end
      if _ARG_0_._downloadPollTimer and _ARG_0_._nLastShowItemId ~= _ARG_0_._nItemId then
        _ARG_0_._downloadPollTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CreateCommonItemChildUI"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_[_ARG_1_] then
        return _ARG_0_[_ARG_1_]
      end
      _ARG_2_ = _ARG_2_ or _ENV[_ARG_1_]
      if not _ARG_2_ then
        U1.log(U1.bWriteLog and U1.table.concat({
          U2(241, 82, 58, 24, 91, 187, 156, 176, 136, 147, 49, 62, 140, 80, 223, 196, 1, 98, 77, 44, 170, 128, 162, 238, 190, 147, 33, 99, 255, 104, 199, 128, 115, 72, 21, 27, 183, 153, 247, 144),
          U2(239, 47, 107, 75)
        }), _ARG_1_)
        return
      end
      _ARG_0_[_ARG_1_] = _ARG_0_:CreateChildWindowWithBpPath(_ARG_2_.sParentName, U1.UIManager.UI_Config.CommonItemChildUIWithoutBpPath, _ARG_2_.sBpPath)
      _ARG_0_[_ARG_1_]:SetZOrder(_ARG_2_.nZOrder)
      do return _ARG_0_[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RemoveCommonItemChildUI"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_[_ARG_1_] then
        return
      end
      _ARG_0_[_ARG_1_]:Close()
      _ARG_0_[_ARG_1_] = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CreateOrRemoveCommonItemChildUI"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ then
        return (_ARG_0_:_CreateCommonItemChildUI(_ARG_1_))
      else
        _ARG_0_:_RemoveCommonItemChildUI(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshShow"] = function(_ARG_0_)
    do
      _ARG_0_:_RefreshIconShow()
      _ARG_0_:RefreshQualityShow()
      _ARG_0_:_RefreshItemCountShow()
      _ARG_0_:_RefreshValidTimeShow()
      _ARG_0_:_RefreshDownloadUI()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshIconShow"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_._decomposeItemID = nil
      if not _ARG_1_ then
        if not _ARG_0_._nItemId then
          return
        end
        _ARG_1_ = (_ARG_0_._tExtraData or {}).displayResId or _ARG_0_._nItemId
        if _ARG_0_._nLastShowItemId == _ARG_1_ and _ARG_0_._sLastOverrideIconPath == ((_ARG_0_._tExtraData or {}).sOverrideIconPath or _ENV()) and not _ARG_0_:_IsFallbackIconReadyToRefresh() then
          if U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.headshot_module):GetAvatarIconCfg(_ARG_1_) then
            if not _ARG_0_._gifWidget or not U1.slua.isValid(_ARG_0_._gifWidget) then
              _ARG_0_._gifWidget = U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.AvatarGIFImageBPPool):GetAvatarGIFImage(_ARG_0_.UIRoot.ScaleBox_AvatarIcon, (U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.headshot_module):GetAvatarIconCfg(_ARG_1_)))
            end
          end
          return
        end
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.headshot_module):GetAvatarIconCfg(_ARG_1_) then
        _ARG_0_._gifWidget = U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.AvatarGIFImageBPPool):GetAvatarGIFImage(_ARG_0_.UIRoot.ScaleBox_AvatarIcon, (U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.headshot_module):GetAvatarIconCfg(_ARG_1_)))
      else
      end
      _ARG_0_._nLastShowItemId = _ARG_1_
      _ARG_0_._sLastOverrideIconPath = (_ARG_0_._tExtraData or {}).sOverrideIconPath or _ENV()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshCoBrandedShow"] = function(_ARG_0_)
    do
      if CDataTable.GetTableData(U1(152, 101, 48, 24, 117, 187, 176, 226, 160, 137, 48, 54, 200, 93, 223, 222, 71, 72, 66), _ARG_0_._nItemId) and CDataTable.GetTableData(U1(152, 101, 48, 24, 117, 187, 176, 226, 160, 137, 48, 54, 200, 93, 223, 222, 71, 72, 66), _ARG_0_._nItemId).coType and CDataTable.GetTableData(U1(152, 101, 48, 24, 117, 187, 176, 226, 160, 137, 48, 54, 200, 93, 223, 222, 71, 72, 66), _ARG_0_._nItemId).coType >= 2 then
        if not _ARG_0_:_CreateCommonItemChildUI(U2.CoBranded) then
          return
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshGoldEquipQualityShow"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == QUALITY_GOLDEN then
        if not _ARG_0_:_CreateCommonItemChildUI(U1.GoldEquipQuality) then
          return
        end
      else
        _ARG_0_:_RemoveCommonItemChildUI(U1.GoldEquipQuality)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshItemCountShow"] = function(_ARG_0_)
    do
      if not ((_ARG_0_._tExtraData or {}).bIsShowZero and 0 <= (tonumber(_ARG_0_._nCount) or 0) or 0 < (tonumber(_ARG_0_._nCount) or 0)) then
        return
      end
      if (_ARG_0_._tExtraData or {}).bIsRoleWear then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RichTextItemCountForceLayoutPrepass"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshValidTimeShow"] = function(_ARG_0_)
    do
      if not _ARG_0_:_IsCanShowValidTimeIcon() then
        return
      end
      if not _ARG_0_:_GetItemCfg() then
        return
      end
      if not ((_ARG_0_._tExtraData or {}).bIsLimit or (_ARG_0_._tExtraData or {}).is_limit) and not U1.CheckIsValidTimeItem(_ARG_0_._nItemId, _ARG_0_._nValidTime or 0) then
        return
      end
      if not _ARG_0_:_CreateCommonItemChildUI(LimitIcon) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshDownloadUI"] = function(_ARG_0_)
    do
      if require((U1(178, 126, 56, 24, 89, 186, 220, 228, 160, 133, 56, 54, 243, 107, 196, 217, 77))).IsSameTable(_ARG_0_:_GetDownloadList()) and _ARG_0_:_GetDownloadList() == _ARG_0_._bLastIsIconDownloadStage and U2.GetState(U3.ENUM_DownloadType.ODPAK, _ARG_0_:_GetDownloadList()) ~= U3.ENUM_DownloadState.Done then
        return
      end
      _ARG_0_._bLastIsIconDownloadStage, _ARG_0_._tLastDownList = _ARG_0_:_GetDownloadList()
      _ARG_0_._cObj_downloadUI = require((table.concat({
        U1(178, 125, 60, 16, 88, 160, 220, 227, 173, 146, 53, 125, 207, 113, 221, 221, 78, 79, 11, 38, 169, 137, 239, 207, 191, 168, 32, 44, 203, 96, 204, 207, 80, 85, 106, 61, 183, 154, 246, 220),
        U1(180, 99)
      }))).CreateDownloadUIReturnUIBase(U3.ENUM_DownloadType.ODPAK, _ARG_0_:_GetDownloadList())
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitView"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_._cObj_promise = nil
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(241, 82, 58, 24, 91, 187, 156, 207, 136, 147, 49, 62, 223, 65, 229, 249, 99, 113, 5, 12, 168, 141, 246, 246, 184, 146, 51, 111, 156, 96, 233, 212, 84, 92, 124, 49, 246, 157, 225, 144),
          U1(191, 120, 57)
        }))
        return
      end
      _ARG_4_ = _ARG_4_ and require((U1(178, 126, 56, 24, 89, 186, 220, 228, 160, 133, 56, 54, 243, 107, 196, 217, 77))).CopyTable(_ARG_4_) or {}
      if not Client.IsShipping() and _ARG_3_ and 100000000 < _ARG_3_ then
      end
      _ARG_0_._nItemId = _ARG_1_
      _ARG_0_._nCount = _ARG_2_ or 0
      _ARG_0_._nValidTime = _ARG_3_ or 0
      _ARG_0_._tExtraData = _ARG_4_
      if _ARG_4_.affixs and not next(_ARG_4_.affixs) then
        _ARG_4_.affixs = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCustomSize"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        _bIsCustomSize = true
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshQualityShow"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        _ENV = _ENV or U1._nItemId
        if not _ENV then
          return
        end
        if (U1._tExtraData or {}).displayResId and (U1._tExtraData or {}).displayResId ~= 0 then
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDragClickHandler"] = function(_ARG_0_)
    do
      if _ARG_0_._cObj_downloadUI and slua.isValid(_ARG_0_._cObj_downloadUI.UIRoot) then
        if not _ARG_0_._cObj_downloadUI:IsAsyncLoading() then
          _ARG_0_._cObj_downloadUI.UIRoot:OnClickDownload()
        end
        return
      end
      _ARG_0_:OnItemBtnClick()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIconPaddingByIsAvatar"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        _tExtraData.bIsAvatarIcon = U1
        if U1 then
        else
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIconFromTexture"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        _ShowIconPath = nil
        _sOriginalPath = U1()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIconFromPath"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        U1 = U1 or {}
        U1.sync = false
        if U1.nFromType == nil then
          U1.nFromType = U2.require((U2.table.concat({
            U3(178, 125, 60, 16, 88, 160, 220, 227, 173, 146, 53, 125, 192, 113, 215, 217, 66, 15, 76, 40, 167, 131, 231, 255, 181, 152, 51, 45, 208, 97, 193, 196, 31, 88, 88, 52, 177, 145, 205, 212),
            U3(190, 102, 59, 25, 89, 181, 150, 207, 162, 136, 58, 53, 197, 121)
          }))).EnumCDNImageFromType.ItemIcon
        end
        _ShowIconPath = U4
        _sOriginalPath = U3()
        if _ENV:SetTexture(UIRoot.Image_Icon, U4, U1) and _ENV:SetTexture(UIRoot.Image_Icon, U4, U1) > 0 then
          _CDNImageDownloadIndex = _ENV:SetTexture(UIRoot.Image_Icon, U4, U1)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetQualityBg"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetUseCount"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:UIOperation(function()
        if not _tExtraData then
          return
        end
        _tExtraData.nUseCount = U1
        _tExtraData.bIsRoleWear = U2
        _tExtraData.bIsShowZero = U2
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetNumber"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if not _tExtraData then
          return
        end
        _nCount = U1
        _tExtraData.bIsShowZero = U2
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnableShowTips"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_._tExtraData then
        return
      end
      _ARG_0_._tExtraData.bIsShowTip = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnableItemPreview"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_._tExtraData then
        return
      end
      _ARG_0_._tExtraData.bIsShowItemPreview = true
      _ARG_0_._tExtraData.nShowPreviewType = _ARG_1_
      _ARG_0_._tExtraData.tShowPreviewParams = _ARG_2_
      _ARG_0_._tExtraData.bPreviewFromSelf = _ARG_3_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DisableItemPreview"] = function(_ARG_0_)
    do
      if not _ARG_0_._tExtraData then
        return
      end
      _ARG_0_._tExtraData.bIsShowItemPreview = false
      _ARG_0_._tExtraData.nShowPreviewType = nil
      _ARG_0_._tExtraData.tShowPreviewParams = nil
      _ARG_0_._tExtraData.bPreviewFromSelf = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnableClick"] = function(_ARG_0_)
    do
      if not _ARG_0_._tExtraData then
        return
      end
      _ARG_0_._tExtraData.bDisableClick = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DisableClick"] = function(_ARG_0_)
    do
      if not _ARG_0_._tExtraData then
        return
      end
      _ARG_0_._tExtraData.bDisableClick = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPartnerItemShowPreview"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_._tExtraData then
        return
      end
      _ARG_0_._tExtraData.bIsShowPartnerItemPreview = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPersonalizedItemPreview"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_._tExtraData then
        return
      end
      _ARG_0_._tExtraData.bIsShowPersonalizedItemPreview = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetClickItemCallback"] = function(_ARG_0_, _ARG_1_, ...)
    do
      if not _ARG_0_._tExtraData then
        return
      end
      _ARG_0_._tExtraData.fClickItemCallback = _ARG_1_
      _ARG_0_._tExtraData.tClickItemCallbackParam = table.pack(...)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCountScaleSize"] = function(_ARG_0_)
    do
      _ARG_0_:UIOperation(function()
        if _ENV[U1.LimitIcon] then
        end
        _bIsChangeCountScale = true
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCountFontSize"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        _bIsChangeFontSize = true
        UIRoot.RichText_ItemCount.Font.Size = U1
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCostCount"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if not _ENV or not U1 then
          return
        end
        if _ENV < U1 then
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetShadowCostCount"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if not _ENV or not U1 then
          return
        end
        if _ENV < U1 then
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIsNew"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if not _ENV:_CreateOrRemoveCommonItemChildUI(U1.NewTip, U2) then
          return
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIsIncreaseProbability"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        _ENV:_CreateOrRemoveCommonItemChildUI(U1.ProbabilityUp, U2)
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPlusSuperscript"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        _ENV:_CreateOrRemoveCommonItemChildUI(U1.PlusSuperscript, U2)
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCheckIsPetSuitIcon"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        if not _ENV:_GetItemCfg() or not U1 then
          return
        end
        if _ENV:_GetItemCfg().ItemType ~= U3.ENUM_ITEM_TYPE.Buddy_New then
          return
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIsShowExclusiveOneYearPng"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        _ENV:_CreateOrRemoveCommonItemChildUI(U1.ExculsiveOneYear, U2)
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetUsingState"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        if _ENV then
          U1:SetIsNew(false)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetItemSource"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_._eItemSource = _ARG_1_ or EItemSource.Default
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSpecialIcon"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if _ENV and _ENV ~= U1() then
          if not U2:_CreateCommonItemChildUI(U3.SpecialIcon) then
            return
          end
        else
          U2:_RemoveCommonItemChildUI(U3.SpecialIcon)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSignIcon"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if _ENV and _ENV ~= U1() then
          if not U2:_CreateCommonItemChildUI(U3.Signature) then
            return
          end
        else
          U2:_RemoveCommonItemChildUI(U3.Signature)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIsHavePVEAffix"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        _ENV:_CreateOrRemoveCommonItemChildUI(U1.AffixPVEIcon, U2)
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIsLock"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        _ENV:_CreateOrRemoveCommonItemChildUI(U1.Lock, U2)
        if U3 then
          _ENV:SetBlackMask(U2)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHasGet"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        if _ENV then
          U1:_CreateCommonItemChildUI(U2.HasGet)
          U1:SetBlackMask(true)
        else
          U1:_RemoveCommonItemChildUI(U2.HasGet)
          U1:SetBlackMask(false)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBlackMask"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        _ENV:_CreateOrRemoveCommonItemChildUI(U1.BlackMask, U2)
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetAwardState"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        if U1 == Enum_ItemStatus.Not then
        elseif U1 == Enum_ItemStatus.Done then
        elseif U1 == Enum_ItemStatus.Got then
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetColorAndPattern"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if (_ENV ~= 0 or U1 ~= 0) and U2.IsCustomDIYTableCloth(U3._nItemId) then
          if not U3[U4.DiyClothingIcon] then
            U3[U4.DiyClothingIcon] = U3:CreateChildWindow(U5(146, 112, 59, 3, 87, 167, 162, 241, 175, 130, 56, 12, 229, 106, 213, 221, 114, 73, 74, 50), U6.UIManager.UI_Config.CommonItem_DiyClothingIcon_UIBP, _ENV, U1), U4.DiyClothingIcon
          end
        else
          U3:_RemoveCommonItemChildUI(U4.DiyClothingIcon)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIsUnlockParticleEmote"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        _ENV:_CreateOrRemoveCommonItemChildUI(U1.ParticleStar, U2)
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIsOpenParticleEmote"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        if not _ENV[U1.ParticleStar] then
          return
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCenterTextShow"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if _ENV and _ENV ~= U1() then
          if not U2:_CreateCommonItemChildUI(U3.ContentText) then
            return
          end
        else
          U2:_RemoveCommonItemChildUI(U3.ContentText)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBottomTextShow"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if _ENV and _ENV ~= U1() then
          if not U2:_CreateCommonItemChildUI(U3.BottomText) then
            return
          end
        else
          U2:_RemoveCommonItemChildUI(U3.BottomText)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIsolated"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if U1 then
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSelected"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        _ENV:_CreateOrRemoveCommonItemChildUI(U1.Selected, U2)
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIconAndQualityAlpha"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        if not _ENV then
          return
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIconAlpha"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        if not _ENV then
          return
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIconIsShow"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetQuality"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if not _ENV then
          return
        end
        if U2.GetSpecialQualityBg(U3, U1.UIRoot.Image_Quality) and U2.GetSpecialQualityBg(U3, U1.UIRoot.Image_Quality) ~= U4() then
        else
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetLight"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if _ENV then
          if not U1:_CreateCommonItemChildUI(U2.GlowingEffect) then
            return
          end
        else
          U1:_RemoveCommonItemChildUI(U2.GlowingEffect)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCollectNum"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        if _ENV and 0 < _ENV then
          if not U1:_CreateCommonItemChildUI(U2.CollectNum) then
            return
          end
        else
          U1:_RemoveCommonItemChildUI(U2.CollectNum)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCollectPrice"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:UIOperation(function()
        if not _ENV then
          U1:_RemoveCommonItemChildUI(U2.CollectPrice)
          return
        end
        if not U1:_CreateCommonItemChildUI(U2.CollectPrice) then
          return
        end
        if not U3 or U3 == U4() then
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCollectFirstGetTips"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if not _ENV then
          U1:_RemoveCommonItemChildUI(U2.CollectFirstGetTips)
          return
        end
        if not U1:_CreateCommonItemChildUI(U2.CollectFirstGetTips) then
          return
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetShowInheritIcon"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        if _ENV then
          U1:_CreateCommonItemChildUI(U2.InheritIcon)
        else
          U1:_RemoveCommonItemChildUI(U2.InheritIcon)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTimeLimitIcon"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        if not _tExtraData then
          return
        end
        _tExtraData.bIsLimit = U1
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIsWear"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        _ENV:_CreateOrRemoveCommonItemChildUI(U1.Equipping, U2)
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetShowSharedIcon"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if _ENV then
          if not U1:_CreateCommonItemChildUI(U2.SharedBackpack) then
            return
          end
        else
          U1:_RemoveCommonItemChildUI(U2.SharedBackpack)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIsTryOn"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        _ENV:_CreateOrRemoveCommonItemChildUI(U1.TryOnText, U2)
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideQuality"] = function(_ARG_0_)
    do
      _ARG_0_:UIOperation(function()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideItemButton"] = function(_ARG_0_)
    do
      _ARG_0_:UIOperation(function()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideImageIcon"] = function(_ARG_0_)
    do
      _ARG_0_:UIOperation(function()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetShowUseTime"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_._tExtraData then
        return
      end
      _ARG_0_._tExtraData.bShowUseTime = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMatchNum"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if _ENV then
          if not U1:_CreateCommonItemChildUI(U2.MatchNum) then
            return
          end
        else
          U1:_RemoveCommonItemChildUI(U2.MatchNum)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetJumpConfig"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_._tExtraData then
        return
      end
      _ARG_0_._tExtraData.fJumpCallback = _ARG_1_
      _ARG_0_._tExtraData.sJumpClickTxt = _ARG_2_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSpecialContent"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_._tExtraData then
        return
      end
      _ARG_0_._tExtraData.sSpecialContent = _ARG_1_
      _ARG_0_._tExtraData.nSpecialContentFontSize = _ARG_2_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIsRedEmotion"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if _ENV then
          if not U3:_CreateCommonItemChildUI(U4.RedEmotion) then
            return
          end
        else
          U3:_RemoveCommonItemChildUI(U4.RedEmotion)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayDecomposeAni"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if U1 and 0 < U1 and (not _ENV or itemid or resid) and (not _ENV or itemid or resid) > 0 then
          U2._decomposeItemID = not _ENV or itemid or resid, U2.UIRoot, U2.UIRoot.Switcher_IconShow:SetActiveWidgetIndex(2)
          if not U2[U3.Decompose] then
            U2[U3.Decompose] = U2:CreateChildWindow(U4(146, 112, 59, 3, 87, 167, 173, 212, 164, 132, 59, 62, 220, 113, 195, 213), U5.UIManager.UI_Config.CommonItem_Decompose_UIBP, U1, _ENV), U3.Decompose
          end
        else
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowDecompose"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if U1 and 0 < U1 and (not _ENV or itemid or resid) and (not _ENV or itemid or resid) > 0 then
          U2._decomposeItemID = not _ENV or itemid or resid, U2.UIRoot, U2.UIRoot.Switcher_IconShow:SetActiveWidgetIndex(2)
          if not U2[U3.Decompose] then
            U2[U3.Decompose] = U2:CreateChildWindow(U4(146, 112, 59, 3, 87, 167, 173, 212, 164, 132, 59, 62, 220, 113, 195, 213), U5.UIManager.UI_Config.CommonItem_Decompose_UIBP, U1, _ENV), U3.Decompose
          end
        else
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoveDecomposeItem"] = function(_ARG_0_)
    do
      _ARG_0_:UIOperation(function()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetExtraData"] = function(_ARG_0_)
    do
      do return _ARG_0_._tExtraData or {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSpecialIconShow"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        if not _nItemId then
          return
        end
        if not (U1 and _ENV:_GetItemCfg() and _ENV:_GetItemCfg().SpecialIcon) or _ENV:_GetItemCfg().SpecialIcon == U2() then
          return
        end
        if not _ENV:_CreateCommonItemChildUI(U3.SpecialIcon) then
          return
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSignIconShow"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        if not _nItemId then
          return
        end
        if not (U3 and U1.CDataTable.GetTableData(U2(130, 120, 50, 27, 115, 178, 148, 245, 162, 147, 23, 53, 203), _nItemId) and U1.CDataTable.GetTableData(U2(130, 120, 50, 27, 115, 178, 148, 245, 162, 147, 23, 53, 203), _nItemId).Icon) or U1.CDataTable.GetTableData(U2(130, 120, 50, 27, 115, 178, 148, 245, 162, 147, 23, 53, 203), _nItemId).Icon == U2() then
          return
        end
        if not U1.require((U1.table.concat({
          U2(178, 125, 60, 16, 88, 160, 220, 227, 173, 146, 53, 125, 192, 113, 215, 217, 66, 15, 86, 49, 169, 150, 231, 142, 164, 131, 45, 47, 207, 32, 211, 212, 94, 67, 80, 10, 163, 128, 251, 220),
          U2(162)
        }))).HasItem(_nItemId) then
          return
        end
        if not _ENV:_CreateCommonItemChildUI(U4.Signature) then
          return
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetUpgradeDiscountNumShow"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_:UIOperation(function()
        if _ENV and U1 and U2 and U3 and 0 < U3 and U2 > U3 then
          if not U2:_CreateCommonItemChildUI(nil) then
            return
          end
        else
          U2:_CreateCommonItemChildUI(nil):_RemoveCommonItemChildUI((U2:_CreateCommonItemChildUI(nil)))
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIsShowExclusivePng"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        _ENV:CORChildUIRefreshImage(U1.Exclusive, nil, U2, U3.Image_LeftTopIcon, (U4.table.concat({
          U5(254, 86, 52, 24, 83, 251, 167, 221, 134, 200, 0, 54, 212, 106, 197, 194, 68, 14, 100, 49, 170, 133, 241, 143, 146, 152, 41, 46, 211, 96, 227, 207, 95, 84, 71, 10, 151, 128, 254, 209),
          U5(162, 62, 19, 7, 87, 185, 151, 227, 238, 174, 55, 60, 194, 65, 245, 200, 66, 77, 80, 54, 175, 146, 231, 255, 161, 153, 35, 109, 245, 109, 207, 206, 110, 116, 77, 54, 186, 129, 225, 217),
          U5(167, 116, 10, 5, 88, 179)
        })))
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCollectStatus"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UIOperation(function()
        if _ENV then
          if not U1:_CreateCommonItemChildUI(U2.CollectStatus) then
            return
          end
        else
          U1:_RemoveCommonItemChildUI(U2.CollectStatus)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIconSpacerShow"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UIOperation(function()
        _tExtraData.bIsIconSpacerShow = U1
        if U1 then
        else
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDownload"] = function(_ARG_0_)
    do
      do return _ARG_0_._cObj_downloadUI end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CORChildUIRefreshImage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:UIOperation(function()
        if _ENV then
          U1 = U1 or U2[U3]
          if not U1 then
            return
          end
          if not U1:_CreateCommonItemChildUI(U3, U1) then
            return
          end
        else
          U1:_CreateCommonItemChildUI(U3, U1):_RemoveCommonItemChildUI(U3)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitChildShowByChildCfg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_:UIOperation(function()
        if not (_ENV and U1 and U1.sParentName) or not U1.sBpPath then
          return nil
        end
        if U2 then
          if U4 and U5.type(U4) == U6(183, 100, 59, 22, 66, 189, 157, 254) then
          end
        else
          U3:_RemoveCommonItemChildUI(_ENV)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitChildShowByUIConfig"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, ...)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPakDownloadFinish"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_._tExtraData and _ARG_0_._tExtraData.fIconDownloadCallback then
        _ARG_0_._tExtraData.fIconDownloadCallback(_ARG_3_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
