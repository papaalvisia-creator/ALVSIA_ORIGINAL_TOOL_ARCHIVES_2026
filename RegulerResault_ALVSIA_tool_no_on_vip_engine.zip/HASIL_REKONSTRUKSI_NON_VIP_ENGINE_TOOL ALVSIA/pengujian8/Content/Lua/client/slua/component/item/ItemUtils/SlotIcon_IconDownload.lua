local SlotIcon_IconDownload = {}
local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")

function SlotIcon_IconDownload.IsIconPending(nItemId)
  if not PublishRegionMacros.IsFITVersion() then
    return false
  end
  local uObj_itemCfg = CDataTable.GetTableData("Item", nItemId)
  local sIconPath = uObj_itemCfg and uObj_itemCfg.ItemSmallIcon or ""
  if sIconPath == "" then
    return false
  end
  local pak_util = require("client.common.pak_util")
  return not pak_util.IsTextureDownloadedByPath(sIconPath, false)
end

function SlotIcon_IconDownload.ClearStreaming(iconWidget)
  local ScriptHelperClient = import("ScriptHelperClient")
  if slua.isValid(iconWidget) and ScriptHelperClient.RemoveKnownMissingPackageRefObjectByObj then
    ScriptHelperClient.RemoveKnownMissingPackageRefObjectByObj(iconWidget)
  end
end

function SlotIcon_IconDownload.Paint(ui, iconWidget, nItemId, tWaiting)
  tWaiting = tWaiting or {}
  SlotIcon_IconDownload.ClearStreaming(iconWidget)
  local UIUtil = require("client.common.ui_util")
  local sIconPath, bHasAddKnownMissing = UIUtil.GetItemSmallIcon(nItemId, iconWidget)
  log(bWriteLog and string.format("SlotIcon_IconDownload:Paint iconWidget:%s, nItemId:%s, sIconPath:%s, bHasAddKnownMissing:%s", iconWidget, nItemId, sIconPath, bHasAddKnownMissing))
  ui:SetTexture(iconWidget, sIconPath, {
    sync = true,
    bHasAddKnownMissing = bHasAddKnownMissing,
    defaultIcon = UIUtil.GetDefaultIcon(nItemId),
    bMatchSize = true
  })
  if SlotIcon_IconDownload.IsIconPending(nItemId) then
    tWaiting[nItemId] = true
  else
    tWaiting[nItemId] = nil
  end
  return tWaiting
end

function SlotIcon_IconDownload.ConsumeReady(tWaiting)
  if not tWaiting or not next(tWaiting) then
    return false
  end
  local bNeedRefresh = false
  for nItemId, _ in pairs(tWaiting) do
    if not SlotIcon_IconDownload.IsIconPending(nItemId) then
      tWaiting[nItemId] = nil
      bNeedRefresh = true
      printf("SlotIcon_IconDownload:ConsumeReady icon ready, itemId:%s", tostring(nItemId))
    end
  end
  return bNeedRefresh
end

return SlotIcon_IconDownload
